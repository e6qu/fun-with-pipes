
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-explicit:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001310 <_init>:
    1310:	d503201f 	nop
    1314:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1318:	910003fd 	mov	x29, sp
    131c:	94000186 	bl	1934 <call_weak_fn>
    1320:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1324:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001330 <.plt>:
    1330:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1334:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1338:	f946fe11 	ldr	x17, [x16, #3576]
    133c:	9137e210 	add	x16, x16, #0xdf8
    1340:	d61f0220 	br	x17
    1344:	d503201f 	nop
    1348:	d503201f 	nop
    134c:	d503201f 	nop

0000000000001350 <memcpy@plt>:
    1350:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1354:	f9470211 	ldr	x17, [x16, #3584]
    1358:	91380210 	add	x16, x16, #0xe00
    135c:	d61f0220 	br	x17

0000000000001360 <sigaltstack@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1364:	f9470611 	ldr	x17, [x16, #3592]
    1368:	91382210 	add	x16, x16, #0xe08
    136c:	d61f0220 	br	x17

0000000000001370 <_exit@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1374:	f9470a11 	ldr	x17, [x16, #3600]
    1378:	91384210 	add	x16, x16, #0xe10
    137c:	d61f0220 	br	x17

0000000000001380 <strlen@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1384:	f9470e11 	ldr	x17, [x16, #3608]
    1388:	91386210 	add	x16, x16, #0xe18
    138c:	d61f0220 	br	x17

0000000000001390 <__sprintf_chk@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1394:	f9471211 	ldr	x17, [x16, #3616]
    1398:	91388210 	add	x16, x16, #0xe20
    139c:	d61f0220 	br	x17

00000000000013a0 <exit@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    13a4:	f9471611 	ldr	x17, [x16, #3624]
    13a8:	9138a210 	add	x16, x16, #0xe28
    13ac:	d61f0220 	br	x17

00000000000013b0 <__libc_start_main@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    13b4:	f9471a11 	ldr	x17, [x16, #3632]
    13b8:	9138c210 	add	x16, x16, #0xe30
    13bc:	d61f0220 	br	x17

00000000000013c0 <strtoll@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    13c4:	f9471e11 	ldr	x17, [x16, #3640]
    13c8:	9138e210 	add	x16, x16, #0xe38
    13cc:	d61f0220 	br	x17

00000000000013d0 <strtod@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    13d4:	f9472211 	ldr	x17, [x16, #3648]
    13d8:	91390210 	add	x16, x16, #0xe40
    13dc:	d61f0220 	br	x17

00000000000013e0 <__cxa_finalize@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    13e4:	f9472611 	ldr	x17, [x16, #3656]
    13e8:	91392210 	add	x16, x16, #0xe48
    13ec:	d61f0220 	br	x17

00000000000013f0 <__cxa_atexit@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    13f4:	f9472a11 	ldr	x17, [x16, #3664]
    13f8:	91394210 	add	x16, x16, #0xe50
    13fc:	d61f0220 	br	x17

0000000000001400 <pthread_attr_init@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1404:	f9472e11 	ldr	x17, [x16, #3672]
    1408:	91396210 	add	x16, x16, #0xe58
    140c:	d61f0220 	br	x17

0000000000001410 <fputc@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1414:	f9473211 	ldr	x17, [x16, #3680]
    1418:	91398210 	add	x16, x16, #0xe60
    141c:	d61f0220 	br	x17

0000000000001420 <clock_gettime@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1424:	f9473611 	ldr	x17, [x16, #3688]
    1428:	9139a210 	add	x16, x16, #0xe68
    142c:	d61f0220 	br	x17

0000000000001430 <setvbuf@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1434:	f9473a11 	ldr	x17, [x16, #3696]
    1438:	9139c210 	add	x16, x16, #0xe70
    143c:	d61f0220 	br	x17

0000000000001440 <__memcpy_chk@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1444:	f9473e11 	ldr	x17, [x16, #3704]
    1448:	9139e210 	add	x16, x16, #0xe78
    144c:	d61f0220 	br	x17

0000000000001450 <signal@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1454:	f9474211 	ldr	x17, [x16, #3712]
    1458:	913a0210 	add	x16, x16, #0xe80
    145c:	d61f0220 	br	x17

0000000000001460 <__snprintf_chk@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1464:	f9474611 	ldr	x17, [x16, #3720]
    1468:	913a2210 	add	x16, x16, #0xe88
    146c:	d61f0220 	br	x17

0000000000001470 <fclose@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1474:	f9474a11 	ldr	x17, [x16, #3728]
    1478:	913a4210 	add	x16, x16, #0xe90
    147c:	d61f0220 	br	x17

0000000000001480 <fopen@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1484:	f9474e11 	ldr	x17, [x16, #3736]
    1488:	913a6210 	add	x16, x16, #0xe98
    148c:	d61f0220 	br	x17

0000000000001490 <malloc@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1494:	f9475211 	ldr	x17, [x16, #3744]
    1498:	913a8210 	add	x16, x16, #0xea0
    149c:	d61f0220 	br	x17

00000000000014a0 <pthread_attr_destroy@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    14a4:	f9475611 	ldr	x17, [x16, #3752]
    14a8:	913aa210 	add	x16, x16, #0xea8
    14ac:	d61f0220 	br	x17

00000000000014b0 <sigemptyset@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    14b4:	f9475a11 	ldr	x17, [x16, #3760]
    14b8:	913ac210 	add	x16, x16, #0xeb0
    14bc:	d61f0220 	br	x17

00000000000014c0 <memset@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    14c4:	f9475e11 	ldr	x17, [x16, #3768]
    14c8:	913ae210 	add	x16, x16, #0xeb8
    14cc:	d61f0220 	br	x17

00000000000014d0 <calloc@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    14d4:	f9476211 	ldr	x17, [x16, #3776]
    14d8:	913b0210 	add	x16, x16, #0xec0
    14dc:	d61f0220 	br	x17

00000000000014e0 <realloc@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    14e4:	f9476611 	ldr	x17, [x16, #3784]
    14e8:	913b2210 	add	x16, x16, #0xec8
    14ec:	d61f0220 	br	x17

00000000000014f0 <__stack_chk_fail@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    14f4:	f9476a11 	ldr	x17, [x16, #3792]
    14f8:	913b4210 	add	x16, x16, #0xed0
    14fc:	d61f0220 	br	x17

0000000000001500 <close@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1504:	f9476e11 	ldr	x17, [x16, #3800]
    1508:	913b6210 	add	x16, x16, #0xed8
    150c:	d61f0220 	br	x17

0000000000001510 <sigaction@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1514:	f9477211 	ldr	x17, [x16, #3808]
    1518:	913b8210 	add	x16, x16, #0xee0
    151c:	d61f0220 	br	x17

0000000000001520 <__gmon_start__@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1524:	f9477611 	ldr	x17, [x16, #3816]
    1528:	913ba210 	add	x16, x16, #0xee8
    152c:	d61f0220 	br	x17

0000000000001530 <write@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1534:	f9477a11 	ldr	x17, [x16, #3824]
    1538:	913bc210 	add	x16, x16, #0xef0
    153c:	d61f0220 	br	x17

0000000000001540 <abort@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1544:	f9477e11 	ldr	x17, [x16, #3832]
    1548:	913be210 	add	x16, x16, #0xef8
    154c:	d61f0220 	br	x17

0000000000001550 <swapcontext@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1554:	f9478211 	ldr	x17, [x16, #3840]
    1558:	913c0210 	add	x16, x16, #0xf00
    155c:	d61f0220 	br	x17

0000000000001560 <__fprintf_chk@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1564:	f9478611 	ldr	x17, [x16, #3848]
    1568:	913c2210 	add	x16, x16, #0xf08
    156c:	d61f0220 	br	x17

0000000000001570 <strcmp@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1574:	f9478a11 	ldr	x17, [x16, #3856]
    1578:	913c4210 	add	x16, x16, #0xf10
    157c:	d61f0220 	br	x17

0000000000001580 <mmap@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1584:	f9478e11 	ldr	x17, [x16, #3864]
    1588:	913c6210 	add	x16, x16, #0xf18
    158c:	d61f0220 	br	x17

0000000000001590 <strtol@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1594:	f9479211 	ldr	x17, [x16, #3872]
    1598:	913c8210 	add	x16, x16, #0xf20
    159c:	d61f0220 	br	x17

00000000000015a0 <strtof@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    15a4:	f9479611 	ldr	x17, [x16, #3880]
    15a8:	913ca210 	add	x16, x16, #0xf28
    15ac:	d61f0220 	br	x17

00000000000015b0 <free@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    15b4:	f9479a11 	ldr	x17, [x16, #3888]
    15b8:	913cc210 	add	x16, x16, #0xf30
    15bc:	d61f0220 	br	x17

00000000000015c0 <nanosleep@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    15c4:	f9479e11 	ldr	x17, [x16, #3896]
    15c8:	913ce210 	add	x16, x16, #0xf38
    15cc:	d61f0220 	br	x17

00000000000015d0 <strchr@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    15d4:	f947a211 	ldr	x17, [x16, #3904]
    15d8:	913d0210 	add	x16, x16, #0xf40
    15dc:	d61f0220 	br	x17

00000000000015e0 <strtoull@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    15e4:	f947a611 	ldr	x17, [x16, #3912]
    15e8:	913d2210 	add	x16, x16, #0xf48
    15ec:	d61f0220 	br	x17

00000000000015f0 <fwrite@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    15f4:	f947aa11 	ldr	x17, [x16, #3920]
    15f8:	913d4210 	add	x16, x16, #0xf50
    15fc:	d61f0220 	br	x17

0000000000001600 <pthread_create@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1604:	f947ae11 	ldr	x17, [x16, #3928]
    1608:	913d6210 	add	x16, x16, #0xf58
    160c:	d61f0220 	br	x17

0000000000001610 <munmap@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1614:	f947b211 	ldr	x17, [x16, #3936]
    1618:	913d8210 	add	x16, x16, #0xf60
    161c:	d61f0220 	br	x17

0000000000001620 <fflush@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1624:	f947b611 	ldr	x17, [x16, #3944]
    1628:	913da210 	add	x16, x16, #0xf68
    162c:	d61f0220 	br	x17

0000000000001630 <strcpy@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1634:	f947ba11 	ldr	x17, [x16, #3952]
    1638:	913dc210 	add	x16, x16, #0xf70
    163c:	d61f0220 	br	x17

0000000000001640 <sysconf@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1644:	f947be11 	ldr	x17, [x16, #3960]
    1648:	913de210 	add	x16, x16, #0xf78
    164c:	d61f0220 	br	x17

0000000000001650 <strstr@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1654:	f947c211 	ldr	x17, [x16, #3968]
    1658:	913e0210 	add	x16, x16, #0xf80
    165c:	d61f0220 	br	x17

0000000000001660 <_Exit@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1664:	f947c611 	ldr	x17, [x16, #3976]
    1668:	913e2210 	add	x16, x16, #0xf88
    166c:	d61f0220 	br	x17

0000000000001670 <pthread_join@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1674:	f947ca11 	ldr	x17, [x16, #3984]
    1678:	913e4210 	add	x16, x16, #0xf90
    167c:	d61f0220 	br	x17

0000000000001680 <getenv@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1684:	f947ce11 	ldr	x17, [x16, #3992]
    1688:	913e6210 	add	x16, x16, #0xf98
    168c:	d61f0220 	br	x17

0000000000001690 <mprotect@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    1694:	f947d211 	ldr	x17, [x16, #4000]
    1698:	913e8210 	add	x16, x16, #0xfa0
    169c:	d61f0220 	br	x17

00000000000016a0 <fgets@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    16a4:	f947d611 	ldr	x17, [x16, #4008]
    16a8:	913ea210 	add	x16, x16, #0xfa8
    16ac:	d61f0220 	br	x17

00000000000016b0 <pthread_attr_setstacksize@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x13c68>
    16b4:	f947da11 	ldr	x17, [x16, #4016]
    16b8:	913ec210 	add	x16, x16, #0xfb0
    16bc:	d61f0220 	br	x17

Disassembly of section .text:

00000000000016c0 <fwp_trap_overflow.constprop.0>:
    16c0:	d10243ff 	sub	sp, sp, #0x90
    16c4:	d2800c03 	mov	x3, #0x60                  	// #96
    16c8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x13c68>
    16cc:	f947f421 	ldr	x1, [x1, #4072]
    16d0:	90000045 	adrp	x5, 9000 <f0+0x2610>
    16d4:	a9077bfd 	stp	x29, x30, [sp, #112]
    16d8:	9101c3fd 	add	x29, sp, #0x70
    16dc:	913780a5 	add	x5, x5, #0xde0
    16e0:	90000044 	adrp	x4, 9000 <f0+0x2610>
    16e4:	f90043f3 	str	x19, [sp, #128]
    16e8:	9137a084 	add	x4, x4, #0xde8
    16ec:	910023f3 	add	x19, sp, #0x8
    16f0:	f9400022 	ldr	x2, [x1]
    16f4:	f90037e2 	str	x2, [sp, #104]
    16f8:	d2800002 	mov	x2, #0x0                   	// #0
    16fc:	aa0303e1 	mov	x1, x3
    1700:	52800042 	mov	w2, #0x2                   	// #2
    1704:	aa1303e0 	mov	x0, x19
    1708:	97ffff56 	bl	1460 <__snprintf_chk@plt>
    170c:	aa1303e0 	mov	x0, x19
    1710:	94000284 	bl	2120 <fwp_trap>
    1714:	d503201f 	nop
    1718:	d503201f 	nop
    171c:	d503201f 	nop

0000000000001720 <main>:
    1720:	d10243ff 	sub	sp, sp, #0x90
    1724:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    1728:	f947f400 	ldr	x0, [x0, #4072]
    172c:	a9067bfd 	stp	x29, x30, [sp, #96]
    1730:	910183fd 	add	x29, sp, #0x60
    1734:	a90753f3 	stp	x19, x20, [sp, #112]
    1738:	f00000f3 	adrp	x19, 20000 <__data_start>
    173c:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x13c68>
    1740:	f947ee94 	ldr	x20, [x20, #4056]
    1744:	f9400281 	ldr	x1, [x20]
    1748:	f90043f5 	str	x21, [sp, #128]
    174c:	f9400002 	ldr	x2, [x0]
    1750:	f9002fe2 	str	x2, [sp, #88]
    1754:	d2800002 	mov	x2, #0x0                   	// #0
    1758:	f9001a61 	str	x1, [x19, #48]
    175c:	94000281 	bl	2160 <fwp_now_ns>
    1760:	b0000040 	adrp	x0, a000 <_IO_stdin_used+0x380>
    1764:	9100e000 	add	x0, x0, #0x38
    1768:	97ffffc6 	bl	1680 <getenv@plt>
    176c:	b4000080 	cbz	x0, 177c <main+0x5c>
    1770:	39400001 	ldrb	w1, [x0]
    1774:	aa0003f5 	mov	x21, x0
    1778:	35000801 	cbnz	w1, 1878 <main+0x158>
    177c:	910023e1 	add	x1, sp, #0x8
    1780:	52800000 	mov	w0, #0x0                   	// #0
    1784:	97ffff27 	bl	1420 <clock_gettime@plt>
    1788:	35000900 	cbnz	w0, 18a8 <main+0x188>
    178c:	a9408be0 	ldp	x0, x2, [sp, #8]
    1790:	d2994003 	mov	x3, #0xca00                	// #51712
    1794:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    1798:	9b037c01 	mul	x1, x0, x3
    179c:	9b437c00 	smulh	x0, x0, x3
    17a0:	ab020021 	adds	x1, x1, x2
    17a4:	937ffc42 	asr	x2, x2, #63
    17a8:	9a020000 	adc	x0, x0, x2
    17ac:	f100003f 	cmp	x1, #0x0
    17b0:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    17b4:	b50009a0 	cbnz	x0, 18e8 <main+0x1c8>
    17b8:	f9400280 	ldr	x0, [x20]
    17bc:	d2a00023 	mov	x3, #0x10000               	// #65536
    17c0:	52800002 	mov	w2, #0x0                   	// #0
    17c4:	d2800001 	mov	x1, #0x0                   	// #0
    17c8:	910063f5 	add	x21, sp, #0x18
    17cc:	97ffff19 	bl	1430 <setvbuf@plt>
    17d0:	d2800021 	mov	x1, #0x1                   	// #1
    17d4:	528001a0 	mov	w0, #0xd                   	// #13
    17d8:	97ffff1e 	bl	1450 <signal@plt>
    17dc:	aa1503e0 	mov	x0, x21
    17e0:	97ffff08 	bl	1400 <pthread_attr_init@plt>
    17e4:	350007c0 	cbnz	w0, 18dc <main+0x1bc>
    17e8:	aa1503e0 	mov	x0, x21
    17ec:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    17f0:	97ffffb0 	bl	16b0 <pthread_attr_setstacksize@plt>
    17f4:	35000680 	cbnz	w0, 18c4 <main+0x1a4>
    17f8:	aa1503e1 	mov	x1, x21
    17fc:	910023e0 	add	x0, sp, #0x8
    1800:	90000042 	adrp	x2, 9000 <f0+0x2610>
    1804:	d2800003 	mov	x3, #0x0                   	// #0
    1808:	91008042 	add	x2, x2, #0x20
    180c:	97ffff7d 	bl	1600 <pthread_create@plt>
    1810:	2a0003e1 	mov	w1, w0
    1814:	aa1503e0 	mov	x0, x21
    1818:	2a0103f5 	mov	w21, w1
    181c:	97ffff21 	bl	14a0 <pthread_attr_destroy@plt>
    1820:	350006a0 	cbnz	w0, 18f4 <main+0x1d4>
    1824:	350004b5 	cbnz	w21, 18b8 <main+0x198>
    1828:	f94007e0 	ldr	x0, [sp, #8]
    182c:	d2800001 	mov	x1, #0x0                   	// #0
    1830:	97ffff90 	bl	1670 <pthread_join@plt>
    1834:	35000600 	cbnz	w0, 18f4 <main+0x1d4>
    1838:	f9400280 	ldr	x0, [x20]
    183c:	9100c273 	add	x19, x19, #0x30
    1840:	97ffff78 	bl	1620 <fflush@plt>
    1844:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x13c68>
    1848:	f947f421 	ldr	x1, [x1, #4072]
    184c:	b942a260 	ldr	w0, [x19, #672]
    1850:	f9402fe3 	ldr	x3, [sp, #88]
    1854:	f9400022 	ldr	x2, [x1]
    1858:	eb020063 	subs	x3, x3, x2
    185c:	d2800002 	mov	x2, #0x0                   	// #0
    1860:	540002a1 	b.ne	18b4 <main+0x194>  // b.any
    1864:	a9467bfd 	ldp	x29, x30, [sp, #96]
    1868:	a94753f3 	ldp	x19, x20, [sp, #112]
    186c:	f94043f5 	ldr	x21, [sp, #128]
    1870:	910243ff 	add	sp, sp, #0x90
    1874:	d65f03c0 	ret
    1878:	910003e1 	mov	x1, sp
    187c:	52800142 	mov	w2, #0xa                   	// #10
    1880:	97ffff58 	bl	15e0 <strtoull@plt>
    1884:	f94003e0 	ldr	x0, [sp]
    1888:	39400000 	ldrb	w0, [x0]
    188c:	35fff780 	cbnz	w0, 177c <main+0x5c>
    1890:	394002a0 	ldrb	w0, [x21]
    1894:	52801fa1 	mov	w1, #0xfd                  	// #253
    1898:	5100ac00 	sub	w0, w0, #0x2b
    189c:	6a01001f 	tst	w0, w1
    18a0:	54fff6e0 	b.eq	177c <main+0x5c>  // b.none
    18a4:	17ffffc5 	b	17b8 <main+0x98>
    18a8:	b0000040 	adrp	x0, a000 <_IO_stdin_used+0x380>
    18ac:	91012000 	add	x0, x0, #0x48
    18b0:	9400021c 	bl	2120 <fwp_trap>
    18b4:	97ffff0f 	bl	14f0 <__stack_chk_fail@plt>
    18b8:	b0000040 	adrp	x0, a000 <_IO_stdin_used+0x380>
    18bc:	9103a000 	add	x0, x0, #0xe8
    18c0:	94000218 	bl	2120 <fwp_trap>
    18c4:	aa1503e0 	mov	x0, x21
    18c8:	97fffef6 	bl	14a0 <pthread_attr_destroy@plt>
    18cc:	35000140 	cbnz	w0, 18f4 <main+0x1d4>
    18d0:	b0000040 	adrp	x0, a000 <_IO_stdin_used+0x380>
    18d4:	91030000 	add	x0, x0, #0xc0
    18d8:	94000212 	bl	2120 <fwp_trap>
    18dc:	b0000040 	adrp	x0, a000 <_IO_stdin_used+0x380>
    18e0:	91024000 	add	x0, x0, #0x90
    18e4:	9400020f 	bl	2120 <fwp_trap>
    18e8:	b0000040 	adrp	x0, a000 <_IO_stdin_used+0x380>
    18ec:	9101a000 	add	x0, x0, #0x68
    18f0:	9400020c 	bl	2120 <fwp_trap>
    18f4:	97ffff13 	bl	1540 <abort@plt>
    18f8:	d503201f 	nop
    18fc:	d503201f 	nop

0000000000001900 <_start>:
    1900:	d503201f 	nop
    1904:	d280001d 	mov	x29, #0x0                   	// #0
    1908:	d280001e 	mov	x30, #0x0                   	// #0
    190c:	aa0003e5 	mov	x5, x0
    1910:	f94003e1 	ldr	x1, [sp]
    1914:	910023e2 	add	x2, sp, #0x8
    1918:	910003e6 	mov	x6, sp
    191c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    1920:	f947f800 	ldr	x0, [x0, #4080]
    1924:	d2800003 	mov	x3, #0x0                   	// #0
    1928:	d2800004 	mov	x4, #0x0                   	// #0
    192c:	97fffea1 	bl	13b0 <__libc_start_main@plt>
    1930:	97ffff04 	bl	1540 <abort@plt>

0000000000001934 <call_weak_fn>:
    1934:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    1938:	f947f000 	ldr	x0, [x0, #4064]
    193c:	b4000040 	cbz	x0, 1944 <call_weak_fn+0x10>
    1940:	17fffef8 	b	1520 <__gmon_start__@plt>
    1944:	d65f03c0 	ret
    1948:	d503201f 	nop
    194c:	d503201f 	nop

0000000000001950 <deregister_tm_clones>:
    1950:	f00000e0 	adrp	x0, 20000 <__data_start>
    1954:	91006000 	add	x0, x0, #0x18
    1958:	f00000e1 	adrp	x1, 20000 <__data_start>
    195c:	91006021 	add	x1, x1, #0x18
    1960:	eb00003f 	cmp	x1, x0
    1964:	540000c0 	b.eq	197c <deregister_tm_clones+0x2c>  // b.none
    1968:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x13c68>
    196c:	f947e021 	ldr	x1, [x1, #4032]
    1970:	b4000061 	cbz	x1, 197c <deregister_tm_clones+0x2c>
    1974:	aa0103f0 	mov	x16, x1
    1978:	d61f0200 	br	x16
    197c:	d65f03c0 	ret

0000000000001980 <register_tm_clones>:
    1980:	f00000e0 	adrp	x0, 20000 <__data_start>
    1984:	91006000 	add	x0, x0, #0x18
    1988:	f00000e1 	adrp	x1, 20000 <__data_start>
    198c:	91006021 	add	x1, x1, #0x18
    1990:	cb000021 	sub	x1, x1, x0
    1994:	d37ffc22 	lsr	x2, x1, #63
    1998:	8b810c41 	add	x1, x2, x1, asr #3
    199c:	9341fc21 	asr	x1, x1, #1
    19a0:	b40000c1 	cbz	x1, 19b8 <register_tm_clones+0x38>
    19a4:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x13c68>
    19a8:	f947fc42 	ldr	x2, [x2, #4088]
    19ac:	b4000062 	cbz	x2, 19b8 <register_tm_clones+0x38>
    19b0:	aa0203f0 	mov	x16, x2
    19b4:	d61f0200 	br	x16
    19b8:	d65f03c0 	ret
    19bc:	d503201f 	nop

00000000000019c0 <__do_global_dtors_aux>:
    19c0:	d503233f 	paciasp
    19c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    19c8:	910003fd 	mov	x29, sp
    19cc:	f9000bf3 	str	x19, [sp, #16]
    19d0:	f00000f3 	adrp	x19, 20000 <__data_start>
    19d4:	39408260 	ldrb	w0, [x19, #32]
    19d8:	37000140 	tbnz	w0, #0, 1a00 <__do_global_dtors_aux+0x40>
    19dc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    19e0:	f947e400 	ldr	x0, [x0, #4040]
    19e4:	b4000080 	cbz	x0, 19f4 <__do_global_dtors_aux+0x34>
    19e8:	f00000e0 	adrp	x0, 20000 <__data_start>
    19ec:	f9400400 	ldr	x0, [x0, #8]
    19f0:	97fffe7c 	bl	13e0 <__cxa_finalize@plt>
    19f4:	97ffffd7 	bl	1950 <deregister_tm_clones>
    19f8:	52800020 	mov	w0, #0x1                   	// #1
    19fc:	39008260 	strb	w0, [x19, #32]
    1a00:	f9400bf3 	ldr	x19, [sp, #16]
    1a04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a08:	d50323bf 	autiasp
    1a0c:	d65f03c0 	ret

0000000000001a10 <frame_dummy>:
    1a10:	d503245f 	bti	c
    1a14:	17ffffdb 	b	1980 <register_tm_clones>
    1a18:	d503201f 	nop
    1a1c:	d503201f 	nop

0000000000001a20 <fwp_fmt_u128>:
    1a20:	d10183ff 	sub	sp, sp, #0x60
    1a24:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x13c68>
    1a28:	f947f421 	ldr	x1, [x1, #4072]
    1a2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    1a30:	910143fd 	add	x29, sp, #0x50
    1a34:	f9400024 	ldr	x4, [x1]
    1a38:	f90027e4 	str	x4, [sp, #72]
    1a3c:	d2800004 	mov	x4, #0x0                   	// #0
    1a40:	aa030041 	orr	x1, x2, x3
    1a44:	b5000361 	cbnz	x1, 1ab0 <fwp_fmt_u128+0x90>
    1a48:	910023e9 	add	x9, sp, #0x8
    1a4c:	52800601 	mov	w1, #0x30                  	// #48
    1a50:	5280002d 	mov	w13, #0x1                   	// #1
    1a54:	390023e1 	strb	w1, [sp, #8]
    1a58:	93407dad 	sxtw	x13, w13
    1a5c:	aa0d03e1 	mov	x1, x13
    1a60:	8b0d0004 	add	x4, x0, x13
    1a64:	d503201f 	nop
    1a68:	8b010123 	add	x3, x9, x1
    1a6c:	cb0103e2 	neg	x2, x1
    1a70:	d1000421 	sub	x1, x1, #0x1
    1a74:	385ff063 	ldurb	w3, [x3, #-1]
    1a78:	38226883 	strb	w3, [x4, x2]
    1a7c:	35ffff61 	cbnz	w1, 1a68 <fwp_fmt_u128+0x48>
    1a80:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x13c68>
    1a84:	f947f421 	ldr	x1, [x1, #4072]
    1a88:	382d681f 	strb	wzr, [x0, x13]
    1a8c:	aa0103e0 	mov	x0, x1
    1a90:	f94027e2 	ldr	x2, [sp, #72]
    1a94:	f9400001 	ldr	x1, [x0]
    1a98:	eb010042 	subs	x2, x2, x1
    1a9c:	d2800001 	mov	x1, #0x0                   	// #0
    1aa0:	54000561 	b.ne	1b4c <fwp_fmt_u128+0x12c>  // b.any
    1aa4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1aa8:	910183ff 	add	sp, sp, #0x60
    1aac:	d65f03c0 	ret
    1ab0:	b0000041 	adrp	x1, a000 <_IO_stdin_used+0x380>
    1ab4:	91068021 	add	x1, x1, #0x1a0
    1ab8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1abc:	910023e9 	add	x9, sp, #0x8
    1ac0:	d2800027 	mov	x7, #0x1                   	// #1
    1ac4:	f29999af 	movk	x15, #0xcccd
    1ac8:	a9402826 	ldp	x6, x10, [x1]
    1acc:	d503201f 	nop
    1ad0:	ab030041 	adds	x1, x2, x3
    1ad4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1ad8:	aa0303eb 	mov	x11, x3
    1adc:	8b070128 	add	x8, x9, x7
    1ae0:	aa0203ee 	mov	x14, x2
    1ae4:	aa0703ed 	mov	x13, x7
    1ae8:	910004e7 	add	x7, x7, #0x1
    1aec:	9bcf7c24 	umulh	x4, x1, x15
    1af0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1af4:	8b4408a4 	add	x4, x5, x4, lsr #2
    1af8:	cb040021 	sub	x1, x1, x4
    1afc:	eb010041 	subs	x1, x2, x1
    1b00:	da1f0063 	sbc	x3, x3, xzr
    1b04:	9bc67c24 	umulh	x4, x1, x6
    1b08:	9b061064 	madd	x4, x3, x6, x4
    1b0c:	9b067c2c 	mul	x12, x1, x6
    1b10:	9b0a1024 	madd	x4, x1, x10, x4
    1b14:	9bc67c25 	umulh	x5, x1, x6
    1b18:	9b061465 	madd	x5, x3, x6, x5
    1b1c:	9b0a1425 	madd	x5, x1, x10, x5
    1b20:	93cc0484 	extr	x4, x4, x12, #1
    1b24:	8b040884 	add	x4, x4, x4, lsl #2
    1b28:	d341fca3 	lsr	x3, x5, #1
    1b2c:	cb040444 	sub	x4, x2, x4, lsl #1
    1b30:	93cc04a2 	extr	x2, x5, x12, #1
    1b34:	1100c084 	add	w4, w4, #0x30
    1b38:	381ff104 	sturb	w4, [x8, #-1]
    1b3c:	b5fffcab 	cbnz	x11, 1ad0 <fwp_fmt_u128+0xb0>
    1b40:	f10025df 	cmp	x14, #0x9
    1b44:	54fffc68 	b.hi	1ad0 <fwp_fmt_u128+0xb0>  // b.pmore
    1b48:	17ffffc4 	b	1a58 <fwp_fmt_u128+0x38>
    1b4c:	97fffe69 	bl	14f0 <__stack_chk_fail@plt>

0000000000001b50 <fwp_range_release>:
    1b50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b54:	910003fd 	mov	x29, sp
    1b58:	f9400801 	ldr	x1, [x0, #16]
    1b5c:	f9000bf3 	str	x19, [sp, #16]
    1b60:	aa0003f3 	mov	x19, x0
    1b64:	b4000061 	cbz	x1, 1b70 <fwp_range_release+0x20>
    1b68:	f9400400 	ldr	x0, [x0, #8]
    1b6c:	d63f0020 	blr	x1
    1b70:	f9400260 	ldr	x0, [x19]
    1b74:	f9400e61 	ldr	x1, [x19, #24]
    1b78:	f9400bf3 	ldr	x19, [sp, #16]
    1b7c:	aa0103f0 	mov	x16, x1
    1b80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1b84:	d61f0200 	br	x16
    1b88:	d503201f 	nop
    1b8c:	d503201f 	nop

0000000000001b90 <fwp_owned_entry32>:
    1b90:	6d400001 	ldp	d1, d0, [x0]
    1b94:	1e613800 	fsub	d0, d0, d1
    1b98:	9e660000 	fmov	x0, d0
    1b9c:	d65f03c0 	ret

0000000000001ba0 <fwp_args32>:
    1ba0:	d65f03c0 	ret

0000000000001ba4 <fwp_owned_entry45>:
    1ba4:	6d400400 	ldp	d0, d1, [x0]
    1ba8:	1e612800 	fadd	d0, d0, d1
    1bac:	9e660000 	fmov	x0, d0
    1bb0:	d65f03c0 	ret

0000000000001bb4 <fwp_owned_entry69>:
    1bb4:	b0000041 	adrp	x1, a000 <_IO_stdin_used+0x380>
    1bb8:	fd400001 	ldr	d1, [x0]
    1bbc:	fd40e820 	ldr	d0, [x1, #464]
    1bc0:	1e610800 	fmul	d0, d0, d1
    1bc4:	9e660000 	fmov	x0, d0
    1bc8:	d65f03c0 	ret
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_flush>:
    1bd0:	f00000e0 	adrp	x0, 20000 <__data_start>
    1bd4:	f9401800 	ldr	x0, [x0, #48]
    1bd8:	b4000120 	cbz	x0, 1bfc <fwp_flush+0x2c>
    1bdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1be0:	910003fd 	mov	x29, sp
    1be4:	97fffe8f 	bl	1620 <fflush@plt>
    1be8:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    1bec:	f947ec00 	ldr	x0, [x0, #4056]
    1bf0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1bf4:	f9400000 	ldr	x0, [x0]
    1bf8:	17fffe8a 	b	1620 <fflush@plt>
    1bfc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    1c00:	f947ec00 	ldr	x0, [x0, #4056]
    1c04:	f9400000 	ldr	x0, [x0]
    1c08:	17fffe86 	b	1620 <fflush@plt>
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_heap_oom>:
    1c10:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x13c68>
    1c14:	f947e863 	ldr	x3, [x3, #4048]
    1c18:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1c1c:	d2800262 	mov	x2, #0x13                  	// #19
    1c20:	910003fd 	mov	x29, sp
    1c24:	f9400063 	ldr	x3, [x3]
    1c28:	d2800021 	mov	x1, #0x1                   	// #1
    1c2c:	90000040 	adrp	x0, 9000 <f0+0x2610>
    1c30:	91322000 	add	x0, x0, #0xc88
    1c34:	97fffe6f 	bl	15f0 <fwrite@plt>
    1c38:	d2800000 	mov	x0, #0x0                   	// #0
    1c3c:	97fffe79 	bl	1620 <fflush@plt>
    1c40:	52800cc0 	mov	w0, #0x66                  	// #102
    1c44:	97fffe87 	bl	1660 <_Exit@plt>
    1c48:	d503201f 	nop
    1c4c:	d503201f 	nop

0000000000001c50 <fwp_segv>:
    1c50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c54:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c58:	9100c043 	add	x3, x2, #0x30
    1c5c:	910003fd 	mov	x29, sp
    1c60:	a90153f3 	stp	x19, x20, [sp, #16]
    1c64:	2a0003f3 	mov	w19, w0
    1c68:	f9400460 	ldr	x0, [x3, #8]
    1c6c:	f90013f5 	str	x21, [sp, #32]
    1c70:	f9400835 	ldr	x21, [x1, #16]
    1c74:	b4000280 	cbz	x0, 1cc4 <fwp_segv+0x74>
    1c78:	f9400814 	ldr	x20, [x0, #16]
    1c7c:	b4000254 	cbz	x20, 1cc4 <fwp_segv+0x74>
    1c80:	528003c0 	mov	w0, #0x1e                  	// #30
    1c84:	97fffe6f 	bl	1640 <sysconf@plt>
    1c88:	f144029f 	cmp	x20, #0x100, lsl #12
    1c8c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c90:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c94:	8b000294 	add	x20, x20, x0
    1c98:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c9c:	eb0102bf 	cmp	x21, x1
    1ca0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1ca4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1ca8:	35000240 	cbnz	w0, 1cf0 <fwp_segv+0xa0>
    1cac:	f94013f5 	ldr	x21, [sp, #32]
    1cb0:	2a1303e0 	mov	w0, w19
    1cb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1cb8:	d2800001 	mov	x1, #0x0                   	// #0
    1cbc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1cc0:	17fffde4 	b	1450 <signal@plt>
    1cc4:	9100c042 	add	x2, x2, #0x30
    1cc8:	f9400840 	ldr	x0, [x2, #16]
    1ccc:	b4ffff00 	cbz	x0, 1cac <fwp_segv+0x5c>
    1cd0:	f9400c41 	ldr	x1, [x2, #24]
    1cd4:	cb010000 	sub	x0, x0, x1
    1cd8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1cdc:	91440000 	add	x0, x0, #0x100, lsl #12
    1ce0:	eb15003f 	cmp	x1, x21
    1ce4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1ce8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1cec:	34fffe00 	cbz	w0, 1cac <fwp_segv+0x5c>
    1cf0:	97ffffb8 	bl	1bd0 <fwp_flush>
    1cf4:	b0000041 	adrp	x1, a000 <_IO_stdin_used+0x380>
    1cf8:	91060021 	add	x1, x1, #0x180
    1cfc:	d2800342 	mov	x2, #0x1a                  	// #26
    1d00:	52800040 	mov	w0, #0x2                   	// #2
    1d04:	97fffe0b 	bl	1530 <write@plt>
    1d08:	52800ca0 	mov	w0, #0x65                  	// #101
    1d0c:	97fffd99 	bl	1370 <_exit@plt>

0000000000001d10 <fwp_heap_chunks>:
    1d10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d14:	910003fd 	mov	x29, sp
    1d18:	a90153f3 	stp	x19, x20, [sp, #16]
    1d1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1d20:	90000195 	adrp	x21, 31000 <fwp_root_context+0xd10>
    1d24:	911342a1 	add	x1, x21, #0x4d0
    1d28:	f100041f 	cmp	x0, #0x1
    1d2c:	54000ca0 	b.eq	1ec0 <fwp_heap_chunks+0x1b0>  // b.none
    1d30:	f949f822 	ldr	x2, [x1, #5104]
    1d34:	b0000185 	adrp	x5, 32000 <fwp_heap+0xb30>
    1d38:	912300a5 	add	x5, x5, #0x8c0
    1d3c:	911342a1 	add	x1, x21, #0x4d0
    1d40:	f949ec34 	ldr	x20, [x1, #5080]
    1d44:	eb14005f 	cmp	x2, x20
    1d48:	54000c42 	b.cs	1ed0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1d4c:	f949fc23 	ldr	x3, [x1, #5112]
    1d50:	8b020841 	add	x1, x2, x2, lsl #2
    1d54:	d2800004 	mov	x4, #0x0                   	// #0
    1d58:	8b010c61 	add	x1, x3, x1, lsl #3
    1d5c:	14000009 	b	1d80 <fwp_heap_chunks+0x70>
    1d60:	91000483 	add	x3, x4, #0x1
    1d64:	eb03001f 	cmp	x0, x3
    1d68:	54000940 	b.eq	1e90 <fwp_heap_chunks+0x180>  // b.none
    1d6c:	91000442 	add	x2, x2, #0x1
    1d70:	aa0303e4 	mov	x4, x3
    1d74:	9100a021 	add	x1, x1, #0x28
    1d78:	eb02029f 	cmp	x20, x2
    1d7c:	54000100 	b.eq	1d9c <fwp_heap_chunks+0x8c>  // b.none
    1d80:	39400023 	ldrb	w3, [x1]
    1d84:	34fffee3 	cbz	w3, 1d60 <fwp_heap_chunks+0x50>
    1d88:	91000442 	add	x2, x2, #0x1
    1d8c:	9100a021 	add	x1, x1, #0x28
    1d90:	d2800004 	mov	x4, #0x0                   	// #0
    1d94:	eb02029f 	cmp	x20, x2
    1d98:	54ffff41 	b.ne	1d80 <fwp_heap_chunks+0x70>  // b.any
    1d9c:	cb040294 	sub	x20, x20, x4
    1da0:	f9001bf7 	str	x23, [sp, #48]
    1da4:	911342b7 	add	x23, x21, #0x4d0
    1da8:	8b140013 	add	x19, x0, x20
    1dac:	f94a1ae1 	ldr	x1, [x23, #5168]
    1db0:	f949f2e0 	ldr	x0, [x23, #5088]
    1db4:	cb040021 	sub	x1, x1, x4
    1db8:	f90a1ae1 	str	x1, [x23, #5168]
    1dbc:	eb00027f 	cmp	x19, x0
    1dc0:	54000429 	b.ls	1e44 <fwp_heap_chunks+0x134>  // b.plast
    1dc4:	f949eae1 	ldr	x1, [x23, #5072]
    1dc8:	eb01027f 	cmp	x19, x1
    1dcc:	54000888 	b.hi	1edc <fwp_heap_chunks+0x1cc>  // b.pmore
    1dd0:	91010276 	add	x22, x19, #0x40
    1dd4:	52800062 	mov	w2, #0x3                   	// #3
    1dd8:	f949dae3 	ldr	x3, [x23, #5040]
    1ddc:	eb0102df 	cmp	x22, x1
    1de0:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1de4:	cb0002c1 	sub	x1, x22, x0
    1de8:	8b004060 	add	x0, x3, x0, lsl #16
    1dec:	d370bc21 	lsl	x1, x1, #16
    1df0:	97fffe28 	bl	1690 <mprotect@plt>
    1df4:	35000740 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1df8:	528003c0 	mov	w0, #0x1e                  	// #30
    1dfc:	97fffe11 	bl	1640 <sysconf@plt>
    1e00:	f949f2e2 	ldr	x2, [x23, #5088]
    1e04:	cb0003e5 	neg	x5, x0
    1e08:	aa0003e4 	mov	x4, x0
    1e0c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e10:	f949fee0 	ldr	x0, [x23, #5112]
    1e14:	8b020843 	add	x3, x2, x2, lsl #2
    1e18:	52800062 	mov	w2, #0x3                   	// #3
    1e1c:	8b010c01 	add	x1, x0, x1, lsl #3
    1e20:	8b030c03 	add	x3, x0, x3, lsl #3
    1e24:	d1000421 	sub	x1, x1, #0x1
    1e28:	8a050060 	and	x0, x3, x5
    1e2c:	8b040021 	add	x1, x1, x4
    1e30:	8a050021 	and	x1, x1, x5
    1e34:	cb000021 	sub	x1, x1, x0
    1e38:	97fffe16 	bl	1690 <mprotect@plt>
    1e3c:	35000500 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1e40:	f909f2f6 	str	x22, [x23, #5088]
    1e44:	911342b5 	add	x21, x21, #0x4d0
    1e48:	d370be60 	lsl	x0, x19, #16
    1e4c:	f949e6a1 	ldr	x1, [x21, #5064]
    1e50:	f909eeb3 	str	x19, [x21, #5080]
    1e54:	eb01001f 	cmp	x0, x1
    1e58:	540000e8 	b.hi	1e74 <fwp_heap_chunks+0x164>  // b.pmore
    1e5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e60:	aa1403e0 	mov	x0, x20
    1e64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e68:	f9401bf7 	ldr	x23, [sp, #48]
    1e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e70:	d65f03c0 	ret
    1e74:	f9401bf7 	ldr	x23, [sp, #48]
    1e78:	f909e6a0 	str	x0, [x21, #5064]
    1e7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e80:	aa1403e0 	mov	x0, x20
    1e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e88:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e8c:	d65f03c0 	ret
    1e90:	911342b5 	add	x21, x21, #0x4d0
    1e94:	91000441 	add	x1, x2, #0x1
    1e98:	f90000a1 	str	x1, [x5]
    1e9c:	cb040054 	sub	x20, x2, x4
    1ea0:	f94a1aa1 	ldr	x1, [x21, #5168]
    1ea4:	cb000020 	sub	x0, x1, x0
    1ea8:	f90a1aa0 	str	x0, [x21, #5168]
    1eac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1eb0:	aa1403e0 	mov	x0, x20
    1eb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1eb8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ebc:	d65f03c0 	ret
    1ec0:	f949f422 	ldr	x2, [x1, #5096]
    1ec4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xb30>
    1ec8:	9122e0a5 	add	x5, x5, #0x8b8
    1ecc:	17ffff9c 	b	1d3c <fwp_heap_chunks+0x2c>
    1ed0:	d2800004 	mov	x4, #0x0                   	// #0
    1ed4:	f9001bf7 	str	x23, [sp, #48]
    1ed8:	17ffffb3 	b	1da4 <fwp_heap_chunks+0x94>
    1edc:	97ffff4d 	bl	1c10 <fwp_heap_oom>

0000000000001ee0 <buf_grow>:
    1ee0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1ee4:	910003fd 	mov	x29, sp
    1ee8:	a90153f3 	stp	x19, x20, [sp, #16]
    1eec:	aa0003f4 	mov	x20, x0
    1ef0:	f9400400 	ldr	x0, [x0, #8]
    1ef4:	b100041f 	cmn	x0, #0x1
    1ef8:	54000400 	b.eq	1f78 <buf_grow+0x98>  // b.none
    1efc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    1f00:	cb000042 	sub	x2, x2, x0
    1f04:	eb01005f 	cmp	x2, x1
    1f08:	54000383 	b.cc	1f78 <buf_grow+0x98>  // b.lo, b.ul, b.last
    1f0c:	f9400a82 	ldr	x2, [x20, #16]
    1f10:	91000421 	add	x1, x1, #0x1
    1f14:	8b000033 	add	x19, x1, x0
    1f18:	eb13005f 	cmp	x2, x19
    1f1c:	54000242 	b.cs	1f64 <buf_grow+0x84>  // b.hs, b.nlast
    1f20:	f100005f 	cmp	x2, #0x0
    1f24:	b5000262 	cbnz	x2, 1f70 <buf_grow+0x90>
    1f28:	d2800802 	mov	x2, #0x40                  	// #64
    1f2c:	eb02027f 	cmp	x19, x2
    1f30:	54000068 	b.hi	1f3c <buf_grow+0x5c>  // b.pmore
    1f34:	14000005 	b	1f48 <buf_grow+0x68>
    1f38:	b7f800a2 	tbnz	x2, #63, 1f4c <buf_grow+0x6c>
    1f3c:	d37ff842 	lsl	x2, x2, #1
    1f40:	eb02027f 	cmp	x19, x2
    1f44:	54ffffa8 	b.hi	1f38 <buf_grow+0x58>  // b.pmore
    1f48:	aa0203f3 	mov	x19, x2
    1f4c:	f9400280 	ldr	x0, [x20]
    1f50:	aa1303e1 	mov	x1, x19
    1f54:	97fffd63 	bl	14e0 <realloc@plt>
    1f58:	b4000100 	cbz	x0, 1f78 <buf_grow+0x98>
    1f5c:	f9000280 	str	x0, [x20]
    1f60:	f9000a93 	str	x19, [x20, #16]
    1f64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f68:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1f6c:	d65f03c0 	ret
    1f70:	54fffe6a 	b.ge	1f3c <buf_grow+0x5c>  // b.tcont
    1f74:	17fffff6 	b	1f4c <buf_grow+0x6c>
    1f78:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x13c68>
    1f7c:	f947e863 	ldr	x3, [x3, #4048]
    1f80:	d2800262 	mov	x2, #0x13                  	// #19
    1f84:	d2800021 	mov	x1, #0x1                   	// #1
    1f88:	90000040 	adrp	x0, 9000 <f0+0x2610>
    1f8c:	91322000 	add	x0, x0, #0xc88
    1f90:	f9400063 	ldr	x3, [x3]
    1f94:	97fffd97 	bl	15f0 <fwrite@plt>
    1f98:	d2800000 	mov	x0, #0x0                   	// #0
    1f9c:	97fffda1 	bl	1620 <fflush@plt>
    1fa0:	52800cc0 	mov	w0, #0x66                  	// #102
    1fa4:	97fffdaf 	bl	1660 <_Exit@plt>
    1fa8:	d503201f 	nop
    1fac:	d503201f 	nop

0000000000001fb0 <buf_put>:
    1fb0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1fb4:	910003fd 	mov	x29, sp
    1fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    1fbc:	aa0003f4 	mov	x20, x0
    1fc0:	aa0203f3 	mov	x19, x2
    1fc4:	f90013f5 	str	x21, [sp, #32]
    1fc8:	aa0103f5 	mov	x21, x1
    1fcc:	aa0203e1 	mov	x1, x2
    1fd0:	97ffffc4 	bl	1ee0 <buf_grow>
    1fd4:	a9400283 	ldp	x3, x0, [x20]
    1fd8:	aa1503e1 	mov	x1, x21
    1fdc:	aa1303e2 	mov	x2, x19
    1fe0:	8b000060 	add	x0, x3, x0
    1fe4:	97fffcdb 	bl	1350 <memcpy@plt>
    1fe8:	a9400680 	ldp	x0, x1, [x20]
    1fec:	8b010273 	add	x19, x19, x1
    1ff0:	f9000693 	str	x19, [x20, #8]
    1ff4:	3833681f 	strb	wzr, [x0, x19]
    1ff8:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ffc:	f94013f5 	ldr	x21, [sp, #32]
    2000:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2004:	d65f03c0 	ret
    2008:	d503201f 	nop
    200c:	d503201f 	nop

0000000000002010 <fwp_cancel_tree.part.0>:
    2010:	d00000e1 	adrp	x1, 20000 <__data_start>
    2014:	9100c022 	add	x2, x1, #0x30
    2018:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    201c:	52800023 	mov	w3, #0x1                   	// #1
    2020:	910003fd 	mov	x29, sp
    2024:	f9400444 	ldr	x4, [x2, #8]
    2028:	f9000bf3 	str	x19, [sp, #16]
    202c:	39014403 	strb	w3, [x0, #81]
    2030:	eb04001f 	cmp	x0, x4
    2034:	54000160 	b.eq	2060 <fwp_cancel_tree.part.0+0x50>  // b.none
    2038:	f9402804 	ldr	x4, [x0, #80]
    203c:	f2001c9f 	tst	x4, #0xff000000ff
    2040:	54000101 	b.ne	2060 <fwp_cancel_tree.part.0+0x50>  // b.any
    2044:	f9401044 	ldr	x4, [x2, #32]
    2048:	39015003 	strb	w3, [x0, #84]
    204c:	f900801f 	str	xzr, [x0, #256]
    2050:	b40001e4 	cbz	x4, 208c <fwp_cancel_tree.part.0+0x7c>
    2054:	f9008080 	str	x0, [x4, #256]
    2058:	9100c021 	add	x1, x1, #0x30
    205c:	f9001020 	str	x0, [x1, #32]
    2060:	f9401413 	ldr	x19, [x0, #40]
    2064:	b40000f3 	cbz	x19, 2080 <fwp_cancel_tree.part.0+0x70>
    2068:	39414261 	ldrb	w1, [x19, #80]
    206c:	aa1303e0 	mov	x0, x19
    2070:	37000041 	tbnz	w1, #0, 2078 <fwp_cancel_tree.part.0+0x68>
    2074:	97ffffe7 	bl	2010 <fwp_cancel_tree.part.0>
    2078:	f9401a73 	ldr	x19, [x19, #48]
    207c:	b5ffff73 	cbnz	x19, 2068 <fwp_cancel_tree.part.0+0x58>
    2080:	f9400bf3 	ldr	x19, [sp, #16]
    2084:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2088:	d65f03c0 	ret
    208c:	f9001440 	str	x0, [x2, #40]
    2090:	17fffff2 	b	2058 <fwp_cancel_tree.part.0+0x48>

0000000000002094 <fwp_finish_float>:
    2094:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2098:	528005c1 	mov	w1, #0x2e                  	// #46
    209c:	910003fd 	mov	x29, sp
    20a0:	f9000bf3 	str	x19, [sp, #16]
    20a4:	aa0003f3 	mov	x19, x0
    20a8:	97fffd4a 	bl	15d0 <strchr@plt>
    20ac:	b4000080 	cbz	x0, 20bc <fwp_finish_float+0x28>
    20b0:	f9400bf3 	ldr	x19, [sp, #16]
    20b4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    20b8:	d65f03c0 	ret
    20bc:	aa1303e0 	mov	x0, x19
    20c0:	52800ca1 	mov	w1, #0x65                  	// #101
    20c4:	97fffd43 	bl	15d0 <strchr@plt>
    20c8:	b5ffff40 	cbnz	x0, 20b0 <fwp_finish_float+0x1c>
    20cc:	f0000021 	adrp	x1, 9000 <f0+0x2610>
    20d0:	aa1303e0 	mov	x0, x19
    20d4:	91328021 	add	x1, x1, #0xca0
    20d8:	97fffd5e 	bl	1650 <strstr@plt>
    20dc:	b5fffea0 	cbnz	x0, 20b0 <fwp_finish_float+0x1c>
    20e0:	f0000021 	adrp	x1, 9000 <f0+0x2610>
    20e4:	aa1303e0 	mov	x0, x19
    20e8:	9132a021 	add	x1, x1, #0xca8
    20ec:	97fffd59 	bl	1650 <strstr@plt>
    20f0:	b5fffe00 	cbnz	x0, 20b0 <fwp_finish_float+0x1c>
    20f4:	aa1303e0 	mov	x0, x19
    20f8:	97fffca2 	bl	1380 <strlen@plt>
    20fc:	f0000021 	adrp	x1, 9000 <f0+0x2610>
    2100:	9132c021 	add	x1, x1, #0xcb0
    2104:	8b000262 	add	x2, x19, x0
    2108:	79400023 	ldrh	w3, [x1]
    210c:	39400821 	ldrb	w1, [x1, #2]
    2110:	78206a63 	strh	w3, [x19, x0]
    2114:	39000841 	strb	w1, [x2, #2]
    2118:	17ffffe6 	b	20b0 <fwp_finish_float+0x1c>
    211c:	d503201f 	nop

0000000000002120 <fwp_trap>:
    2120:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2124:	910003fd 	mov	x29, sp
    2128:	f9000bf3 	str	x19, [sp, #16]
    212c:	aa0003f3 	mov	x19, x0
    2130:	97fffea8 	bl	1bd0 <fwp_flush>
    2134:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x13c68>
    2138:	f947e884 	ldr	x4, [x4, #4048]
    213c:	aa1303e3 	mov	x3, x19
    2140:	f0000022 	adrp	x2, 9000 <f0+0x2610>
    2144:	9132e042 	add	x2, x2, #0xcb8
    2148:	52800041 	mov	w1, #0x2                   	// #2
    214c:	f9400080 	ldr	x0, [x4]
    2150:	97fffd04 	bl	1560 <__fprintf_chk@plt>
    2154:	52800ca0 	mov	w0, #0x65                  	// #101
    2158:	97fffc92 	bl	13a0 <exit@plt>
    215c:	d503201f 	nop

0000000000002160 <fwp_now_ns>:
    2160:	d100c3ff 	sub	sp, sp, #0x30
    2164:	52800020 	mov	w0, #0x1                   	// #1
    2168:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x13c68>
    216c:	f947f442 	ldr	x2, [x2, #4072]
    2170:	910023e1 	add	x1, sp, #0x8
    2174:	a9027bfd 	stp	x29, x30, [sp, #32]
    2178:	910083fd 	add	x29, sp, #0x20
    217c:	f9400043 	ldr	x3, [x2]
    2180:	f9000fe3 	str	x3, [sp, #24]
    2184:	d2800003 	mov	x3, #0x0                   	// #0
    2188:	97fffca6 	bl	1420 <clock_gettime@plt>
    218c:	350002c0 	cbnz	w0, 21e4 <fwp_now_ns+0x84>
    2190:	a9408be1 	ldp	x1, x2, [sp, #8]
    2194:	d2994003 	mov	x3, #0xca00                	// #51712
    2198:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    219c:	9b037c20 	mul	x0, x1, x3
    21a0:	9b437c21 	smulh	x1, x1, x3
    21a4:	ab020000 	adds	x0, x0, x2
    21a8:	937ffc42 	asr	x2, x2, #63
    21ac:	9a020021 	adc	x1, x1, x2
    21b0:	f100001f 	cmp	x0, #0x0
    21b4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    21b8:	b50001e1 	cbnz	x1, 21f4 <fwp_now_ns+0x94>
    21bc:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x13c68>
    21c0:	f947f421 	ldr	x1, [x1, #4072]
    21c4:	f9400fe3 	ldr	x3, [sp, #24]
    21c8:	f9400022 	ldr	x2, [x1]
    21cc:	eb020063 	subs	x3, x3, x2
    21d0:	d2800002 	mov	x2, #0x0                   	// #0
    21d4:	540000e1 	b.ne	21f0 <fwp_now_ns+0x90>  // b.any
    21d8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    21dc:	9100c3ff 	add	sp, sp, #0x30
    21e0:	d65f03c0 	ret
    21e4:	f0000020 	adrp	x0, 9000 <f0+0x2610>
    21e8:	91332000 	add	x0, x0, #0xcc8
    21ec:	97ffffcd 	bl	2120 <fwp_trap>
    21f0:	97fffcc0 	bl	14f0 <__stack_chk_fail@plt>
    21f4:	f0000020 	adrp	x0, 9000 <f0+0x2610>
    21f8:	9133a000 	add	x0, x0, #0xce8
    21fc:	97ffffc9 	bl	2120 <fwp_trap>

0000000000002200 <fwp_args74>:
    2200:	d65f03c0 	ret

0000000000002204 <fwp_format_g.constprop.0>:
    2204:	d10483ff 	sub	sp, sp, #0x120
    2208:	f0000024 	adrp	x4, 9000 <f0+0x2610>
    220c:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x13c68>
    2210:	f947f442 	ldr	x2, [x2, #4072]
    2214:	91344084 	add	x4, x4, #0xd10
    2218:	a90b7bfd 	stp	x29, x30, [sp, #176]
    221c:	9102c3fd 	add	x29, sp, #0xb0
    2220:	d2800803 	mov	x3, #0x40                  	// #64
    2224:	a90e63f7 	stp	x23, x24, [sp, #224]
    2228:	93407c38 	sxtw	x24, w1
    222c:	aa0303e1 	mov	x1, x3
    2230:	fd008be8 	str	d8, [sp, #272]
    2234:	1e604008 	fmov	d8, d0
    2238:	a90c53f3 	stp	x19, x20, [sp, #192]
    223c:	910083f4 	add	x20, sp, #0x20
    2240:	a90d5bf5 	stp	x21, x22, [sp, #208]
    2244:	aa0003f5 	mov	x21, x0
    2248:	a91073fb 	stp	x27, x28, [sp, #256]
    224c:	5100071c 	sub	w28, w24, #0x1
    2250:	2a1c03e5 	mov	w5, w28
    2254:	f9400040 	ldr	x0, [x2]
    2258:	f90057e0 	str	x0, [sp, #168]
    225c:	d2800000 	mov	x0, #0x0                   	// #0
    2260:	52800042 	mov	w2, #0x2                   	// #2
    2264:	aa1403e0 	mov	x0, x20
    2268:	97fffc7e 	bl	1460 <__snprintf_chk@plt>
    226c:	52800ca1 	mov	w1, #0x65                  	// #101
    2270:	aa1403e0 	mov	x0, x20
    2274:	97fffcd7 	bl	15d0 <strchr@plt>
    2278:	aa0003f3 	mov	x19, x0
    227c:	52800142 	mov	w2, #0xa                   	// #10
    2280:	91000400 	add	x0, x0, #0x1
    2284:	d2800001 	mov	x1, #0x0                   	// #0
    2288:	97fffcc2 	bl	1590 <strtol@plt>
    228c:	aa0003f7 	mov	x23, x0
    2290:	11001400 	add	w0, w0, #0x5
    2294:	7100541f 	cmp	w0, #0x15
    2298:	54000d88 	b.hi	2448 <fwp_format_g.constprop.0+0x244>  // b.pmore
    229c:	4b170385 	sub	w5, w28, w23
    22a0:	710000bf 	cmp	w5, #0x0
    22a4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    22a8:	54000ba0 	b.eq	241c <fwp_format_g.constprop.0+0x218>  // b.none
    22ac:	394083e0 	ldrb	w0, [sp, #32]
    22b0:	cb180273 	sub	x19, x19, x24
    22b4:	91000673 	add	x19, x19, #0x1
    22b8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    22bc:	7100b41f 	cmp	w0, #0x2d
    22c0:	9a941681 	cinc	x1, x20, eq	// eq = none
    22c4:	1a9f17e4 	cset	w4, eq	// eq = none
    22c8:	cb010266 	sub	x6, x19, x1
    22cc:	d10004da 	sub	x26, x6, #0x1
    22d0:	540018c0 	b.eq	25e8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    22d4:	910183f9 	add	x25, sp, #0x60
    22d8:	d280091b 	mov	x27, #0x48                  	// #72
    22dc:	aa1903e7 	mov	x7, x25
    22e0:	91000423 	add	x3, x1, #0x1
    22e4:	91011cc6 	add	x6, x6, #0x47
    22e8:	910004f6 	add	x22, x7, #0x1
    22ec:	37f81017 	tbnz	w23, #31, 24ec <fwp_format_g.constprop.0+0x2e8>
    22f0:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    22f4:	93407ef7 	sxtw	x23, w23
    22f8:	390000e4 	strb	w4, [x7]
    22fc:	aa1303e1 	mov	x1, x19
    2300:	aa1703e2 	mov	x2, x23
    2304:	aa1603e0 	mov	x0, x22
    2308:	b9000be5 	str	w5, [sp, #8]
    230c:	cb170374 	sub	x20, x27, x23
    2310:	a9011be3 	stp	x3, x6, [sp, #16]
    2314:	97fffc0f 	bl	1350 <memcpy@plt>
    2318:	d1000694 	sub	x20, x20, #0x1
    231c:	f9400be3 	ldr	x3, [sp, #16]
    2320:	8b1702d6 	add	x22, x22, x23
    2324:	aa1603e0 	mov	x0, x22
    2328:	aa1a03e2 	mov	x2, x26
    232c:	aa0303e1 	mov	x1, x3
    2330:	aa1403e3 	mov	x3, x20
    2334:	97fffc43 	bl	1440 <__memcpy_chk@plt>
    2338:	8b1a02d6 	add	x22, x22, x26
    233c:	f9400fe6 	ldr	x6, [sp, #24]
    2340:	d2800900 	mov	x0, #0x48                  	// #72
    2344:	b9400be5 	ldr	w5, [sp, #8]
    2348:	8b170261 	add	x1, x19, x23
    234c:	cb1400c3 	sub	x3, x6, x20
    2350:	cb060294 	sub	x20, x20, x6
    2354:	f101207f 	cmp	x3, #0x48
    2358:	93407cb8 	sxtw	x24, w5
    235c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2360:	aa1803e2 	mov	x2, x24
    2364:	8b1802d3 	add	x19, x22, x24
    2368:	8b140063 	add	x3, x3, x20
    236c:	aa1603e0 	mov	x0, x22
    2370:	97fffc34 	bl	1440 <__memcpy_chk@plt>
    2374:	cb190273 	sub	x19, x19, x25
    2378:	d28031e0 	mov	x0, #0x18f                 	// #399
    237c:	eb00027f 	cmp	x19, x0
    2380:	aa1903e1 	mov	x1, x25
    2384:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    2388:	aa1503e0 	mov	x0, x21
    238c:	aa1303e2 	mov	x2, x19
    2390:	97fffbf0 	bl	1350 <memcpy@plt>
    2394:	38336abf 	strb	wzr, [x21, x19]
    2398:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    239c:	aa1503e0 	mov	x0, x21
    23a0:	97fffbf8 	bl	1380 <strlen@plt>
    23a4:	aa0003f3 	mov	x19, x0
    23a8:	528005c1 	mov	w1, #0x2e                  	// #46
    23ac:	aa1503e0 	mov	x0, x21
    23b0:	97fffc88 	bl	15d0 <strchr@plt>
    23b4:	b4000160 	cbz	x0, 23e0 <fwp_format_g.constprop.0+0x1dc>
    23b8:	b4000153 	cbz	x19, 23e0 <fwp_format_g.constprop.0+0x1dc>
    23bc:	d503201f 	nop
    23c0:	aa1303e1 	mov	x1, x19
    23c4:	d1000673 	sub	x19, x19, #0x1
    23c8:	38736aa0 	ldrb	w0, [x21, x19]
    23cc:	7100c01f 	cmp	w0, #0x30
    23d0:	54001001 	b.ne	25d0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    23d4:	38336abf 	strb	wzr, [x21, x19]
    23d8:	b5ffff53 	cbnz	x19, 23c0 <fwp_format_g.constprop.0+0x1bc>
    23dc:	d503201f 	nop
    23e0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    23e4:	f947f400 	ldr	x0, [x0, #4072]
    23e8:	f94057e2 	ldr	x2, [sp, #168]
    23ec:	f9400001 	ldr	x1, [x0]
    23f0:	eb010042 	subs	x2, x2, x1
    23f4:	d2800001 	mov	x1, #0x0                   	// #0
    23f8:	54001061 	b.ne	2604 <fwp_format_g.constprop.0+0x400>  // b.any
    23fc:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2400:	a94c53f3 	ldp	x19, x20, [sp, #192]
    2404:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2408:	a94e63f7 	ldp	x23, x24, [sp, #224]
    240c:	a95073fb 	ldp	x27, x28, [sp, #256]
    2410:	fd408be8 	ldr	d8, [sp, #272]
    2414:	910483ff 	add	sp, sp, #0x120
    2418:	d65f03c0 	ret
    241c:	1e604100 	fmov	d0, d8
    2420:	710000bf 	cmp	w5, #0x0
    2424:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2428:	aa1503e0 	mov	x0, x21
    242c:	f0000024 	adrp	x4, 9000 <f0+0x2610>
    2430:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2434:	9134a084 	add	x4, x4, #0xd28
    2438:	52800042 	mov	w2, #0x2                   	// #2
    243c:	d2803201 	mov	x1, #0x190                 	// #400
    2440:	97fffc08 	bl	1460 <__snprintf_chk@plt>
    2444:	17ffffd6 	b	239c <fwp_format_g.constprop.0+0x198>
    2448:	cb140273 	sub	x19, x19, x20
    244c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2450:	910183f9 	add	x25, sp, #0x60
    2454:	aa1303e2 	mov	x2, x19
    2458:	aa1403e1 	mov	x1, x20
    245c:	aa1903e0 	mov	x0, x25
    2460:	d2800803 	mov	x3, #0x40                  	// #64
    2464:	97fffbf7 	bl	1440 <__memcpy_chk@plt>
    2468:	38336b3f 	strb	wzr, [x25, x19]
    246c:	aa1903e0 	mov	x0, x25
    2470:	528005c1 	mov	w1, #0x2e                  	// #46
    2474:	97fffc57 	bl	15d0 <strchr@plt>
    2478:	b40001c0 	cbz	x0, 24b0 <fwp_format_g.constprop.0+0x2ac>
    247c:	b50000b3 	cbnz	x19, 2490 <fwp_format_g.constprop.0+0x28c>
    2480:	1400000c 	b	24b0 <fwp_format_g.constprop.0+0x2ac>
    2484:	381ff01f 	sturb	wzr, [x0, #-1]
    2488:	f1000673 	subs	x19, x19, #0x1
    248c:	54000120 	b.eq	24b0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    2490:	8b130320 	add	x0, x25, x19
    2494:	385ff001 	ldurb	w1, [x0, #-1]
    2498:	7100c03f 	cmp	w1, #0x30
    249c:	54ffff40 	b.eq	2484 <fwp_format_g.constprop.0+0x280>  // b.none
    24a0:	d1000673 	sub	x19, x19, #0x1
    24a4:	38736b20 	ldrb	w0, [x25, x19]
    24a8:	7100b81f 	cmp	w0, #0x2e
    24ac:	54000a80 	b.eq	25fc <fwp_format_g.constprop.0+0x3f8>  // b.none
    24b0:	710002ff 	cmp	w23, #0x0
    24b4:	528005a1 	mov	w1, #0x2d                  	// #45
    24b8:	aa1903e5 	mov	x5, x25
    24bc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    24c0:	aa1503e0 	mov	x0, x21
    24c4:	52800566 	mov	w6, #0x2b                  	// #43
    24c8:	f0000024 	adrp	x4, 9000 <f0+0x2610>
    24cc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    24d0:	91346084 	add	x4, x4, #0xd18
    24d4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    24d8:	52800042 	mov	w2, #0x2                   	// #2
    24dc:	d2803201 	mov	x1, #0x190                 	// #400
    24e0:	97fffbe0 	bl	1460 <__snprintf_chk@plt>
    24e4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    24e8:	17ffffbe 	b	23e0 <fwp_format_g.constprop.0+0x1dc>
    24ec:	52800605 	mov	w5, #0x30                  	// #48
    24f0:	390000e5 	strb	w5, [x7]
    24f4:	d100077b 	sub	x27, x27, #0x1
    24f8:	aa0303e1 	mov	x1, x3
    24fc:	aa1603e0 	mov	x0, x22
    2500:	aa1b03e3 	mov	x3, x27
    2504:	aa1a03e2 	mov	x2, x26
    2508:	f90007e6 	str	x6, [sp, #8]
    250c:	b90013e4 	str	w4, [sp, #16]
    2510:	8b1a02d6 	add	x22, x22, x26
    2514:	b9001be5 	str	w5, [sp, #24]
    2518:	97fffbca 	bl	1440 <__memcpy_chk@plt>
    251c:	f94007e6 	ldr	x6, [sp, #8]
    2520:	2a3703e7 	mvn	w7, w23
    2524:	b94013e4 	ldr	w4, [sp, #16]
    2528:	cb1b00c1 	sub	x1, x6, x27
    252c:	cb06037b 	sub	x27, x27, x6
    2530:	f101203f 	cmp	x1, #0x48
    2534:	d2800906 	mov	x6, #0x48                  	// #72
    2538:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    253c:	8b1b0023 	add	x3, x1, x27
    2540:	310006ff 	cmn	w23, #0x1
    2544:	54000220 	b.eq	2588 <fwp_format_g.constprop.0+0x384>  // b.none
    2548:	b9401be5 	ldr	w5, [sp, #24]
    254c:	d2800001 	mov	x1, #0x0                   	// #0
    2550:	f101207f 	cmp	x3, #0x48
    2554:	d1000462 	sub	x2, x3, #0x1
    2558:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    255c:	38216ac5 	strb	w5, [x22, x1]
    2560:	cb030003 	sub	x3, x0, x3
    2564:	91000421 	add	x1, x1, #0x1
    2568:	91000463 	add	x3, x3, #0x1
    256c:	eb00007f 	cmp	x3, x0
    2570:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2574:	cb000063 	sub	x3, x3, x0
    2578:	8b020063 	add	x3, x3, x2
    257c:	6b0100ff 	cmp	w7, w1
    2580:	54fffe8c 	b.gt	2550 <fwp_format_g.constprop.0+0x34c>
    2584:	8b2742d6 	add	x22, x22, w7, uxtw
    2588:	f101207f 	cmp	x3, #0x48
    258c:	d2800905 	mov	x5, #0x48                  	// #72
    2590:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    2594:	aa1603e0 	mov	x0, x22
    2598:	cb0300a1 	sub	x1, x5, x3
    259c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    25a0:	91000421 	add	x1, x1, #0x1
    25a4:	d1000463 	sub	x3, x3, #0x1
    25a8:	eb05003f 	cmp	x1, x5
    25ac:	38001402 	strb	w2, [x0], #1
    25b0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    25b4:	93407f82 	sxtw	x2, w28
    25b8:	cb050025 	sub	x5, x1, x5
    25bc:	aa1303e1 	mov	x1, x19
    25c0:	8b0300a3 	add	x3, x5, x3
    25c4:	8b1802d3 	add	x19, x22, x24
    25c8:	97fffb9e 	bl	1440 <__memcpy_chk@plt>
    25cc:	17ffff6a 	b	2374 <fwp_format_g.constprop.0+0x170>
    25d0:	d1000421 	sub	x1, x1, #0x1
    25d4:	38616aa0 	ldrb	w0, [x21, x1]
    25d8:	7100b81f 	cmp	w0, #0x2e
    25dc:	54fff021 	b.ne	23e0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    25e0:	38216abf 	strb	wzr, [x21, x1]
    25e4:	17ffff7f 	b	23e0 <fwp_format_g.constprop.0+0x1dc>
    25e8:	910187e7 	add	x7, sp, #0x61
    25ec:	910183f9 	add	x25, sp, #0x60
    25f0:	d28008fb 	mov	x27, #0x47                  	// #71
    25f4:	390183e0 	strb	w0, [sp, #96]
    25f8:	17ffff3a 	b	22e0 <fwp_format_g.constprop.0+0xdc>
    25fc:	38336b3f 	strb	wzr, [x25, x19]
    2600:	17ffffac 	b	24b0 <fwp_format_g.constprop.0+0x2ac>
    2604:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2608:	97fffbba 	bl	14f0 <__stack_chk_fail@plt>
    260c:	d503201f 	nop

0000000000002610 <fwp_heap_report>:
    2610:	d105c3ff 	sub	sp, sp, #0x170
    2614:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    2618:	91134042 	add	x2, x2, #0x4d0
    261c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x13c68>
    2620:	f947e821 	ldr	x1, [x1, #4048]
    2624:	a9117bfd 	stp	x29, x30, [sp, #272]
    2628:	910443fd 	add	x29, sp, #0x110
    262c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    2630:	f947f400 	ldr	x0, [x0, #4072]
    2634:	a9135bf5 	stp	x21, x22, [sp, #304]
    2638:	a91463f7 	stp	x23, x24, [sp, #320]
    263c:	a9156bf9 	stp	x25, x26, [sp, #336]
    2640:	6d1627e8 	stp	d8, d9, [sp, #352]
    2644:	fd4a1c48 	ldr	d8, [x2, #5176]
    2648:	fd4a2049 	ldr	d9, [x2, #5184]
    264c:	f9400036 	ldr	x22, [x1]
    2650:	f9400001 	ldr	x1, [x0]
    2654:	f90087e1 	str	x1, [sp, #264]
    2658:	d2800001 	mov	x1, #0x0                   	// #0
    265c:	f949e459 	ldr	x25, [x2, #5064]
    2660:	f0000021 	adrp	x1, 9000 <f0+0x2610>
    2664:	f94a1057 	ldr	x23, [x2, #5152]
    2668:	f0000020 	adrp	x0, 9000 <f0+0x2610>
    266c:	f94a1458 	ldr	x24, [x2, #5160]
    2670:	9134c021 	add	x1, x1, #0xd30
    2674:	9134e000 	add	x0, x0, #0xd38
    2678:	97fffb82 	bl	1480 <fopen@plt>
    267c:	b4000740 	cbz	x0, 2764 <fwp_heap_report+0x154>
    2680:	528daad5 	mov	w21, #0x6d56                	// #27990
    2684:	a91253f3 	stp	x19, x20, [sp, #288]
    2688:	aa0003f4 	mov	x20, x0
    268c:	910023f3 	add	x19, sp, #0x8
    2690:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2694:	72aae915 	movk	w21, #0x5748, lsl #16
    2698:	aa1403e2 	mov	x2, x20
    269c:	aa1303e0 	mov	x0, x19
    26a0:	52802001 	mov	w1, #0x100                 	// #256
    26a4:	97fffbff 	bl	16a0 <fgets@plt>
    26a8:	b4000280 	cbz	x0, 26f8 <fwp_heap_report+0xe8>
    26ac:	b9400261 	ldr	w1, [x19]
    26b0:	6b15003f 	cmp	w1, w21
    26b4:	54ffff21 	b.ne	2698 <fwp_heap_report+0x88>  // b.any
    26b8:	39401260 	ldrb	w0, [x19, #4]
    26bc:	7101341f 	cmp	w0, #0x4d
    26c0:	54fffec1 	b.ne	2698 <fwp_heap_report+0x88>  // b.any
    26c4:	394037e0 	ldrb	w0, [sp, #13]
    26c8:	7100e81f 	cmp	w0, #0x3a
    26cc:	54fffe61 	b.ne	2698 <fwp_heap_report+0x88>  // b.any
    26d0:	52800142 	mov	w2, #0xa                   	// #10
    26d4:	d2800001 	mov	x1, #0x0                   	// #0
    26d8:	91003be0 	add	x0, sp, #0xe
    26dc:	97fffbad 	bl	1590 <strtol@plt>
    26e0:	aa1403e2 	mov	x2, x20
    26e4:	aa0003fa 	mov	x26, x0
    26e8:	52802001 	mov	w1, #0x100                 	// #256
    26ec:	aa1303e0 	mov	x0, x19
    26f0:	97fffbec 	bl	16a0 <fgets@plt>
    26f4:	b5fffdc0 	cbnz	x0, 26ac <fwp_heap_report+0x9c>
    26f8:	aa1403e0 	mov	x0, x20
    26fc:	97fffb5d 	bl	1470 <fclose@plt>
    2700:	a95253f3 	ldp	x19, x20, [sp, #288]
    2704:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    2708:	f947f400 	ldr	x0, [x0, #4072]
    270c:	f94087e2 	ldr	x2, [sp, #264]
    2710:	f9400001 	ldr	x1, [x0]
    2714:	eb010042 	subs	x2, x2, x1
    2718:	d2800001 	mov	x1, #0x0                   	// #0
    271c:	54000281 	b.ne	276c <fwp_heap_report+0x15c>  // b.any
    2720:	a9517bfd 	ldp	x29, x30, [sp, #272]
    2724:	aa1a03e6 	mov	x6, x26
    2728:	aa1903e5 	mov	x5, x25
    272c:	aa1803e4 	mov	x4, x24
    2730:	a9556bf9 	ldp	x25, x26, [sp, #336]
    2734:	aa1703e3 	mov	x3, x23
    2738:	a95463f7 	ldp	x23, x24, [sp, #320]
    273c:	aa1603e0 	mov	x0, x22
    2740:	a9535bf5 	ldp	x21, x22, [sp, #304]
    2744:	1e604121 	fmov	d1, d9
    2748:	1e604100 	fmov	d0, d8
    274c:	f0000022 	adrp	x2, 9000 <f0+0x2610>
    2750:	6d5627e8 	ldp	d8, d9, [sp, #352]
    2754:	91356042 	add	x2, x2, #0xd58
    2758:	9105c3ff 	add	sp, sp, #0x170
    275c:	52800041 	mov	w1, #0x2                   	// #2
    2760:	17fffb80 	b	1560 <__fprintf_chk@plt>
    2764:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2768:	17ffffe7 	b	2704 <fwp_heap_report+0xf4>
    276c:	a91253f3 	stp	x19, x20, [sp, #288]
    2770:	97fffb60 	bl	14f0 <__stack_chk_fail@plt>

0000000000002774 <fwp_heap_init>:
    2774:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2778:	90000183 	adrp	x3, 32000 <fwp_heap+0xb30>
    277c:	910f4061 	add	x1, x3, #0x3d0
    2780:	910003fd 	mov	x29, sp
    2784:	a90153f3 	stp	x19, x20, [sp, #16]
    2788:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xd10>
    278c:	91134262 	add	x2, x19, #0x4d0
    2790:	a9025bf5 	stp	x21, x22, [sp, #32]
    2794:	52800024 	mov	w4, #0x1                   	// #1
    2798:	52800200 	mov	w0, #0x10                  	// #16
    279c:	b913a444 	str	w4, [x2, #5028]
    27a0:	b8004420 	str	w0, [x1], #4
    27a4:	11004000 	add	w0, w0, #0x10
    27a8:	7104401f 	cmp	w0, #0x110
    27ac:	54ffffa1 	b.ne	27a0 <fwp_heap_init+0x2c>  // b.any
    27b0:	90000042 	adrp	x2, a000 <_IO_stdin_used+0x380>
    27b4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    27b8:	90000181 	adrp	x1, 32000 <fwp_heap+0xb30>
    27bc:	91104021 	add	x1, x1, #0x410
    27c0:	3dc06c43 	ldr	q3, [x2, #432]
    27c4:	d2800000 	mov	x0, #0x0                   	// #0
    27c8:	4e040401 	dup	v1.4s, v0.s[0]
    27cc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    27d0:	0f215400 	shl	v0.2s, v0.2s, #1
    27d4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    27d8:	3ca06821 	str	q1, [x1, x0]
    27dc:	91004000 	add	x0, x0, #0x10
    27e0:	f101801f 	cmp	x0, #0x60
    27e4:	54ffff21 	b.ne	27c8 <fwp_heap_init+0x54>  // b.any
    27e8:	90000184 	adrp	x4, 32000 <fwp_heap+0xb30>
    27ec:	910f4063 	add	x3, x3, #0x3d0
    27f0:	9111c084 	add	x4, x4, #0x470
    27f4:	91134266 	add	x6, x19, #0x4d0
    27f8:	d2800002 	mov	x2, #0x0                   	// #0
    27fc:	d2800000 	mov	x0, #0x0                   	// #0
    2800:	d2880205 	mov	x5, #0x4010                	// #16400
    2804:	d503201f 	nop
    2808:	910f0001 	add	x1, x0, #0x3c0
    280c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2810:	eb02003f 	cmp	x1, x2
    2814:	540000a2 	b.cs	2828 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    2818:	91000400 	add	x0, x0, #0x1
    281c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2820:	eb02003f 	cmp	x1, x2
    2824:	54ffffa3 	b.cc	2818 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    2828:	91004042 	add	x2, x2, #0x10
    282c:	38001480 	strb	w0, [x4], #1
    2830:	eb05005f 	cmp	x2, x5
    2834:	54fffea1 	b.ne	2808 <fwp_heap_init+0x94>  // b.any
    2838:	528000b5 	mov	w21, #0x5                   	// #5
    283c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    2840:	14000004 	b	2850 <fwp_heap_init+0xdc>
    2844:	d342fe94 	lsr	x20, x20, #2
    2848:	710006b5 	subs	w21, w21, #0x1
    284c:	54000720 	b.eq	2930 <fwp_heap_init+0x1bc>  // b.none
    2850:	91404296 	add	x22, x20, #0x10, lsl #12
    2854:	d2800005 	mov	x5, #0x0                   	// #0
    2858:	aa1603e1 	mov	x1, x22
    285c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2860:	52880443 	mov	w3, #0x4022                	// #16418
    2864:	52800002 	mov	w2, #0x0                   	// #0
    2868:	d2800000 	mov	x0, #0x0                   	// #0
    286c:	97fffb45 	bl	1580 <mmap@plt>
    2870:	aa0003e6 	mov	x6, x0
    2874:	b100041f 	cmn	x0, #0x1
    2878:	54fffe60 	b.eq	2844 <fwp_heap_init+0xd0>  // b.none
    287c:	b40005a0 	cbz	x0, 2930 <fwp_heap_init+0x1bc>
    2880:	d350fe94 	lsr	x20, x20, #16
    2884:	d29fffe0 	mov	x0, #0xffff                	// #65535
    2888:	8b0000c7 	add	x7, x6, x0
    288c:	91134275 	add	x21, x19, #0x4d0
    2890:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    2894:	8b140a81 	add	x1, x20, x20, lsl #2
    2898:	d2800005 	mov	x5, #0x0                   	// #0
    289c:	12800004 	mov	w4, #0xffffffff            	// #-1
    28a0:	d37df021 	lsl	x1, x1, #3
    28a4:	52880443 	mov	w3, #0x4022                	// #16418
    28a8:	52800002 	mov	w2, #0x0                   	// #0
    28ac:	d2800000 	mov	x0, #0x0                   	// #0
    28b0:	f909daa7 	str	x7, [x21, #5040]
    28b4:	f909dea6 	str	x6, [x21, #5048]
    28b8:	f909e2b6 	str	x22, [x21, #5056]
    28bc:	f909eab4 	str	x20, [x21, #5072]
    28c0:	f90a02a1 	str	x1, [x21, #5120]
    28c4:	97fffb2f 	bl	1580 <mmap@plt>
    28c8:	aa0003e1 	mov	x1, x0
    28cc:	b100041f 	cmn	x0, #0x1
    28d0:	54000300 	b.eq	2930 <fwp_heap_init+0x1bc>  // b.none
    28d4:	f0000020 	adrp	x0, 9000 <f0+0x2610>
    28d8:	91382000 	add	x0, x0, #0xe08
    28dc:	f909fea1 	str	x1, [x21, #5112]
    28e0:	97fffb68 	bl	1680 <getenv@plt>
    28e4:	52800002 	mov	w2, #0x0                   	// #0
    28e8:	aa0003e1 	mov	x1, x0
    28ec:	b40000e0 	cbz	x0, 2908 <fwp_heap_init+0x194>
    28f0:	39400000 	ldrb	w0, [x0]
    28f4:	340000a0 	cbz	w0, 2908 <fwp_heap_init+0x194>
    28f8:	7100c000 	subs	w0, w0, #0x30
    28fc:	54000120 	b.eq	2920 <fwp_heap_init+0x1ac>  // b.none
    2900:	7100001f 	cmp	w0, #0x0
    2904:	1a9f07e2 	cset	w2, ne	// ne = any
    2908:	91134273 	add	x19, x19, #0x4d0
    290c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2910:	b913aa62 	str	w2, [x19, #5032]
    2914:	a94153f3 	ldp	x19, x20, [sp, #16]
    2918:	a8c37bfd 	ldp	x29, x30, [sp], #48
    291c:	d65f03c0 	ret
    2920:	39400420 	ldrb	w0, [x1, #1]
    2924:	7100001f 	cmp	w0, #0x0
    2928:	1a9f07e2 	cset	w2, ne	// ne = any
    292c:	17fffff7 	b	2908 <fwp_heap_init+0x194>
    2930:	97fffcb8 	bl	1c10 <fwp_heap_oom>

0000000000002934 <fwp_args45>:
    2934:	d65f03c0 	ret
    2938:	d503201f 	nop
    293c:	d503201f 	nop

0000000000002940 <fwp_args69>:
    2940:	d65f03c0 	ret

0000000000002944 <fwp_wake_io>:
    2944:	d00000e9 	adrp	x9, 20000 <__data_start>
    2948:	9100c122 	add	x2, x9, #0x30
    294c:	f9400001 	ldr	x1, [x0]
    2950:	5280000a 	mov	w10, #0x0                   	// #0
    2954:	f9401046 	ldr	x6, [x2, #32]
    2958:	52800008 	mov	w8, #0x0                   	// #0
    295c:	4f000400 	movi	v0.4s, #0x0
    2960:	52800027 	mov	w7, #0x1                   	// #1
    2964:	aa0103e2 	mov	x2, x1
    2968:	b4000321 	cbz	x1, 29cc <fwp_wake_io+0x88>
    296c:	f9408c25 	ldr	x5, [x1, #280]
    2970:	39015c27 	strb	w7, [x1, #87]
    2974:	b4000165 	cbz	x5, 29a0 <fwp_wake_io+0x5c>
    2978:	a9520c24 	ldp	x4, x3, [x1, #288]
    297c:	b4000364 	cbz	x4, 29e8 <fwp_wake_io+0xa4>
    2980:	f9009483 	str	x3, [x4, #296]
    2984:	f9409423 	ldr	x3, [x1, #296]
    2988:	b4000043 	cbz	x3, 2990 <fwp_wake_io+0x4c>
    298c:	f9009064 	str	x4, [x3, #288]
    2990:	91080023 	add	x3, x1, #0x200
    2994:	f900943f 	str	xzr, [x1, #296]
    2998:	3c918060 	stur	q0, [x3, #-232]
    299c:	f9400001 	ldr	x1, [x0]
    29a0:	f9402843 	ldr	x3, [x2, #80]
    29a4:	f2001c7f 	tst	x3, #0xff000000ff
    29a8:	54fffde1 	b.ne	2964 <fwp_wake_io+0x20>  // b.any
    29ac:	39015047 	strb	w7, [x2, #84]
    29b0:	f900805f 	str	xzr, [x2, #256]
    29b4:	b40001e6 	cbz	x6, 29f0 <fwp_wake_io+0xac>
    29b8:	f90080c2 	str	x2, [x6, #256]
    29bc:	aa0203e6 	mov	x6, x2
    29c0:	52800028 	mov	w8, #0x1                   	// #1
    29c4:	aa0103e2 	mov	x2, x1
    29c8:	b5fffd21 	cbnz	x1, 296c <fwp_wake_io+0x28>
    29cc:	3400006a 	cbz	w10, 29d8 <fwp_wake_io+0x94>
    29d0:	9100c120 	add	x0, x9, #0x30
    29d4:	f900140b 	str	x11, [x0, #40]
    29d8:	34000068 	cbz	w8, 29e4 <fwp_wake_io+0xa0>
    29dc:	9100c129 	add	x9, x9, #0x30
    29e0:	f9001126 	str	x6, [x9, #32]
    29e4:	d65f03c0 	ret
    29e8:	f90000a3 	str	x3, [x5]
    29ec:	17ffffe7 	b	2988 <fwp_wake_io+0x44>
    29f0:	aa0203eb 	mov	x11, x2
    29f4:	5280002a 	mov	w10, #0x1                   	// #1
    29f8:	17fffff1 	b	29bc <fwp_wake_io+0x78>
    29fc:	d503201f 	nop

0000000000002a00 <fwp_poll_events>:
    2a00:	d10103ff 	sub	sp, sp, #0x40
    2a04:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    2a08:	f947f400 	ldr	x0, [x0, #4072]
    2a0c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2a10:	910083fd 	add	x29, sp, #0x20
    2a14:	a90353f3 	stp	x19, x20, [sp, #48]
    2a18:	d00000f4 	adrp	x20, 20000 <__data_start>
    2a1c:	f9400001 	ldr	x1, [x0]
    2a20:	f9000fe1 	str	x1, [sp, #24]
    2a24:	d2800001 	mov	x1, #0x0                   	// #0
    2a28:	97fffdce 	bl	2160 <fwp_now_ns>
    2a2c:	9100c281 	add	x1, x20, #0x30
    2a30:	f9401833 	ldr	x19, [x1, #48]
    2a34:	b4000e93 	cbz	x19, 2c04 <fwp_poll_events+0x204>
    2a38:	aa1303e1 	mov	x1, x19
    2a3c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2a40:	14000005 	b	2a54 <fwp_poll_events+0x54>
    2a44:	f9408821 	ldr	x1, [x1, #272]
    2a48:	eb03005f 	cmp	x2, x3
    2a4c:	9a83d042 	csel	x2, x2, x3, le
    2a50:	b40000c1 	cbz	x1, 2a68 <fwp_poll_events+0x68>
    2a54:	f9403423 	ldr	x3, [x1, #104]
    2a58:	b6ffff62 	tbz	x2, #63, 2a44 <fwp_poll_events+0x44>
    2a5c:	f9408821 	ldr	x1, [x1, #272]
    2a60:	aa0303e2 	mov	x2, x3
    2a64:	b5ffff81 	cbnz	x1, 2a54 <fwp_poll_events+0x54>
    2a68:	b7f80ce2 	tbnz	x2, #63, 2c04 <fwp_poll_events+0x204>
    2a6c:	cb000042 	sub	x2, x2, x0
    2a70:	f100005f 	cmp	x2, #0x0
    2a74:	540005cd 	b.le	2b2c <fwp_poll_events+0x12c>
    2a78:	d2869b60 	mov	x0, #0x34db                	// #13531
    2a7c:	d2884801 	mov	x1, #0x4240                	// #16960
    2a80:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2a84:	f2a001e1 	movk	x1, #0xf, lsl #16
    2a88:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2a8c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2a90:	f2e86360 	movk	x0, #0x431b, lsl #48
    2a94:	9b407c40 	smulh	x0, x2, x0
    2a98:	9352fc00 	asr	x0, x0, #18
    2a9c:	cb82fc00 	sub	x0, x0, x2, asr #63
    2aa0:	9b018802 	msub	x2, x0, x1, x2
    2aa4:	f100005f 	cmp	x2, #0x0
    2aa8:	9a800400 	cinc	x0, x0, ne	// ne = any
    2aac:	eb03001f 	cmp	x0, x3
    2ab0:	54000a0c 	b.gt	2bf0 <fwp_poll_events+0x1f0>
    2ab4:	340003c0 	cbz	w0, 2b2c <fwp_poll_events+0x12c>
    2ab8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2abc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2ac0:	72a20c42 	movk	w2, #0x1062, lsl #16
    2ac4:	9ba27c02 	umull	x2, w0, w2
    2ac8:	d366fc43 	lsr	x3, x2, #38
    2acc:	aa0303e2 	mov	x2, x3
    2ad0:	1b048063 	msub	w3, w3, w4, w0
    2ad4:	9b217c63 	smull	x3, w3, w1
    2ad8:	d2800001 	mov	x1, #0x0                   	// #0
    2adc:	910023e0 	add	x0, sp, #0x8
    2ae0:	a9008fe2 	stp	x2, x3, [sp, #8]
    2ae4:	97fffab7 	bl	15c0 <nanosleep@plt>
    2ae8:	9100c280 	add	x0, x20, #0x30
    2aec:	f9401813 	ldr	x19, [x0, #48]
    2af0:	97fffd9c 	bl	2160 <fwp_now_ns>
    2af4:	aa0003e6 	mov	x6, x0
    2af8:	b50001f3 	cbnz	x19, 2b34 <fwp_poll_events+0x134>
    2afc:	d503201f 	nop
    2b00:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    2b04:	f947f400 	ldr	x0, [x0, #4072]
    2b08:	f9400fe2 	ldr	x2, [sp, #24]
    2b0c:	f9400001 	ldr	x1, [x0]
    2b10:	eb010042 	subs	x2, x2, x1
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	540008c1 	b.ne	2c30 <fwp_poll_events+0x230>  // b.any
    2b1c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2b20:	a94353f3 	ldp	x19, x20, [sp, #48]
    2b24:	910103ff 	add	sp, sp, #0x40
    2b28:	d65f03c0 	ret
    2b2c:	97fffd8d 	bl	2160 <fwp_now_ns>
    2b30:	aa0003e6 	mov	x6, x0
    2b34:	4f000400 	movi	v0.4s, #0x0
    2b38:	9100c288 	add	x8, x20, #0x30
    2b3c:	52800027 	mov	w7, #0x1                   	// #1
    2b40:	f9403661 	ldr	x1, [x19, #104]
    2b44:	aa1303e5 	mov	x5, x19
    2b48:	f9408a73 	ldr	x19, [x19, #272]
    2b4c:	eb06003f 	cmp	x1, x6
    2b50:	5400032c 	b.gt	2bb4 <fwp_poll_events+0x1b4>
    2b54:	394154a0 	ldrb	w0, [x5, #85]
    2b58:	36000120 	tbz	w0, #0, 2b7c <fwp_poll_events+0x17c>
    2b5c:	f94084a0 	ldr	x0, [x5, #264]
    2b60:	b40003c0 	cbz	x0, 2bd8 <fwp_poll_events+0x1d8>
    2b64:	f9008813 	str	x19, [x0, #272]
    2b68:	b4000053 	cbz	x19, 2b70 <fwp_poll_events+0x170>
    2b6c:	f9008660 	str	x0, [x19, #264]
    2b70:	910800a0 	add	x0, x5, #0x200
    2b74:	390154bf 	strb	wzr, [x5, #85]
    2b78:	3c908000 	stur	q0, [x0, #-248]
    2b7c:	f94030a0 	ldr	x0, [x5, #96]
    2b80:	390158a7 	strb	w7, [x5, #86]
    2b84:	f100001f 	cmp	x0, #0x0
    2b88:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2b8c:	5400018d 	b.le	2bbc <fwp_poll_events+0x1bc>
    2b90:	f94028a0 	ldr	x0, [x5, #80]
    2b94:	f2001c1f 	tst	x0, #0xff000000ff
    2b98:	540000e1 	b.ne	2bb4 <fwp_poll_events+0x1b4>  // b.any
    2b9c:	f9401100 	ldr	x0, [x8, #32]
    2ba0:	390150a7 	strb	w7, [x5, #84]
    2ba4:	f90080bf 	str	xzr, [x5, #256]
    2ba8:	b40001e0 	cbz	x0, 2be4 <fwp_poll_events+0x1e4>
    2bac:	f9001105 	str	x5, [x8, #32]
    2bb0:	f9008005 	str	x5, [x0, #256]
    2bb4:	b5fffc73 	cbnz	x19, 2b40 <fwp_poll_events+0x140>
    2bb8:	17ffffd2 	b	2b00 <fwp_poll_events+0x100>
    2bbc:	394144a0 	ldrb	w0, [x5, #81]
    2bc0:	3707fe80 	tbnz	w0, #0, 2b90 <fwp_poll_events+0x190>
    2bc4:	394140a0 	ldrb	w0, [x5, #80]
    2bc8:	3707fe40 	tbnz	w0, #0, 2b90 <fwp_poll_events+0x190>
    2bcc:	aa0503e0 	mov	x0, x5
    2bd0:	97fffd10 	bl	2010 <fwp_cancel_tree.part.0>
    2bd4:	17ffffef 	b	2b90 <fwp_poll_events+0x190>
    2bd8:	9100c281 	add	x1, x20, #0x30
    2bdc:	f9001833 	str	x19, [x1, #48]
    2be0:	17ffffe2 	b	2b68 <fwp_poll_events+0x168>
    2be4:	f9001105 	str	x5, [x8, #32]
    2be8:	f9001505 	str	x5, [x8, #40]
    2bec:	17fffff2 	b	2bb4 <fwp_poll_events+0x1b4>
    2bf0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2bf4:	d2989362 	mov	x2, #0xc49b                	// #50331
    2bf8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2bfc:	f2a00402 	movk	x2, #0x20, lsl #16
    2c00:	17ffffb6 	b	2ad8 <fwp_poll_events+0xd8>
    2c04:	97fffbf3 	bl	1bd0 <fwp_flush>
    2c08:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x13c68>
    2c0c:	f947e863 	ldr	x3, [x3, #4048]
    2c10:	d2800562 	mov	x2, #0x2b                  	// #43
    2c14:	d2800021 	mov	x1, #0x1                   	// #1
    2c18:	f0000020 	adrp	x0, 9000 <f0+0x2610>
    2c1c:	91386000 	add	x0, x0, #0xe18
    2c20:	f9400063 	ldr	x3, [x3]
    2c24:	97fffa73 	bl	15f0 <fwrite@plt>
    2c28:	52800ca0 	mov	w0, #0x65                  	// #101
    2c2c:	97fff9dd 	bl	13a0 <exit@plt>
    2c30:	97fffa30 	bl	14f0 <__stack_chk_fail@plt>

0000000000002c34 <fwp_rc_wide_dup>:
    2c34:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2c38:	910003fd 	mov	x29, sp
    2c3c:	a90153f3 	stp	x19, x20, [sp, #16]
    2c40:	aa0003f3 	mov	x19, x0
    2c44:	ca404400 	eor	x0, x0, x0, lsr #17
    2c48:	f90013f5 	str	x21, [sp, #32]
    2c4c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    2c50:	ca402400 	eor	x0, x0, x0, lsr #9
    2c54:	911342a2 	add	x2, x21, #0x4d0
    2c58:	92401c00 	and	x0, x0, #0xff
    2c5c:	910a2403 	add	x3, x0, #0x289
    2c60:	8b000c40 	add	x0, x2, x0, lsl #3
    2c64:	8b030c54 	add	x20, x2, x3, lsl #3
    2c68:	f94a2401 	ldr	x1, [x0, #5192]
    2c6c:	b50000a1 	cbnz	x1, 2c80 <fwp_rc_wide_dup+0x4c>
    2c70:	1400002d 	b	2d24 <fwp_rc_wide_dup+0xf0>
    2c74:	91004034 	add	x20, x1, #0x10
    2c78:	f9400821 	ldr	x1, [x1, #16]
    2c7c:	b4000241 	cbz	x1, 2cc4 <fwp_rc_wide_dup+0x90>
    2c80:	f9400022 	ldr	x2, [x1]
    2c84:	eb02027f 	cmp	x19, x2
    2c88:	54ffff61 	b.ne	2c74 <fwp_rc_wide_dup+0x40>  // b.any
    2c8c:	f9400281 	ldr	x1, [x20]
    2c90:	39400260 	ldrb	w0, [x19]
    2c94:	7103f81f 	cmp	w0, #0xfe
    2c98:	54000220 	b.eq	2cdc <fwp_rc_wide_dup+0xa8>  // b.none
    2c9c:	b40001a1 	cbz	x1, 2cd0 <fwp_rc_wide_dup+0x9c>
    2ca0:	f9400420 	ldr	x0, [x1, #8]
    2ca4:	b100041f 	cmn	x0, #0x1
    2ca8:	540004a0 	b.eq	2d3c <fwp_rc_wide_dup+0x108>  // b.none
    2cac:	91000400 	add	x0, x0, #0x1
    2cb0:	f9000420 	str	x0, [x1, #8]
    2cb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    2cb8:	f94013f5 	ldr	x21, [sp, #32]
    2cbc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2cc0:	d65f03c0 	ret
    2cc4:	39400260 	ldrb	w0, [x19]
    2cc8:	7103f81f 	cmp	w0, #0xfe
    2ccc:	540000a0 	b.eq	2ce0 <fwp_rc_wide_dup+0xac>  // b.none
    2cd0:	f0000020 	adrp	x0, 9000 <f0+0x2610>
    2cd4:	9139c000 	add	x0, x0, #0xe70
    2cd8:	97fffd12 	bl	2120 <fwp_trap>
    2cdc:	b5000281 	cbnz	x1, 2d2c <fwp_rc_wide_dup+0xf8>
    2ce0:	d2800300 	mov	x0, #0x18                  	// #24
    2ce4:	97fff9eb 	bl	1490 <malloc@plt>
    2ce8:	b4000280 	cbz	x0, 2d38 <fwp_rc_wide_dup+0x104>
    2cec:	d2801fe1 	mov	x1, #0xff                  	// #255
    2cf0:	a9000413 	stp	x19, x1, [x0]
    2cf4:	911342b5 	add	x21, x21, #0x4d0
    2cf8:	f900081f 	str	xzr, [x0, #16]
    2cfc:	12800001 	mov	w1, #0xffffffff            	// #-1
    2d00:	f9000280 	str	x0, [x20]
    2d04:	39000261 	strb	w1, [x19]
    2d08:	f94e26a0 	ldr	x0, [x21, #7240]
    2d0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d10:	91000400 	add	x0, x0, #0x1
    2d14:	f90e26a0 	str	x0, [x21, #7240]
    2d18:	f94013f5 	ldr	x21, [sp, #32]
    2d1c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d20:	d65f03c0 	ret
    2d24:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    2d28:	17ffffda 	b	2c90 <fwp_rc_wide_dup+0x5c>
    2d2c:	f0000020 	adrp	x0, 9000 <f0+0x2610>
    2d30:	91392000 	add	x0, x0, #0xe48
    2d34:	97fffcfb 	bl	2120 <fwp_trap>
    2d38:	97fffbb6 	bl	1c10 <fwp_heap_oom>
    2d3c:	f0000020 	adrp	x0, 9000 <f0+0x2610>
    2d40:	913a6000 	add	x0, x0, #0xe98
    2d44:	97fffcf7 	bl	2120 <fwp_trap>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <fwp_rc_forget_slot>:
    2d50:	aa0003e1 	mov	x1, x0
    2d54:	39400000 	ldrb	w0, [x0]
    2d58:	7103fc1f 	cmp	w0, #0xff
    2d5c:	54000040 	b.eq	2d64 <fwp_rc_forget_slot+0x14>  // b.none
    2d60:	d65f03c0 	ret
    2d64:	ca414420 	eor	x0, x1, x1, lsr #17
    2d68:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d6c:	ca402400 	eor	x0, x0, x0, lsr #9
    2d70:	910003fd 	mov	x29, sp
    2d74:	92401c00 	and	x0, x0, #0xff
    2d78:	f9000bf3 	str	x19, [sp, #16]
    2d7c:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xd10>
    2d80:	91134262 	add	x2, x19, #0x4d0
    2d84:	910a2403 	add	x3, x0, #0x289
    2d88:	8b000c40 	add	x0, x2, x0, lsl #3
    2d8c:	8b030c43 	add	x3, x2, x3, lsl #3
    2d90:	f94a2400 	ldr	x0, [x0, #5192]
    2d94:	b50000a0 	cbnz	x0, 2da8 <fwp_rc_forget_slot+0x58>
    2d98:	14000011 	b	2ddc <fwp_rc_forget_slot+0x8c>
    2d9c:	91004003 	add	x3, x0, #0x10
    2da0:	f9400800 	ldr	x0, [x0, #16]
    2da4:	b40001c0 	cbz	x0, 2ddc <fwp_rc_forget_slot+0x8c>
    2da8:	f9400002 	ldr	x2, [x0]
    2dac:	eb02003f 	cmp	x1, x2
    2db0:	54ffff61 	b.ne	2d9c <fwp_rc_forget_slot+0x4c>  // b.any
    2db4:	f9400801 	ldr	x1, [x0, #16]
    2db8:	91134273 	add	x19, x19, #0x4d0
    2dbc:	f9000061 	str	x1, [x3]
    2dc0:	97fff9fc 	bl	15b0 <free@plt>
    2dc4:	f94e2660 	ldr	x0, [x19, #7240]
    2dc8:	d1000400 	sub	x0, x0, #0x1
    2dcc:	f90e2660 	str	x0, [x19, #7240]
    2dd0:	f9400bf3 	ldr	x19, [sp, #16]
    2dd4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2dd8:	d65f03c0 	ret
    2ddc:	f0000020 	adrp	x0, 9000 <f0+0x2610>
    2de0:	9139c000 	add	x0, x0, #0xe70
    2de4:	97fffccf 	bl	2120 <fwp_trap>
    2de8:	d503201f 	nop
    2dec:	d503201f 	nop

0000000000002df0 <fwp_rc_prepare_chunk>:
    2df0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2df4:	910003fd 	mov	x29, sp
    2df8:	a9025bf5 	stp	x21, x22, [sp, #32]
    2dfc:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xd10>
    2e00:	911342c2 	add	x2, x22, #0x4d0
    2e04:	b9401c03 	ldr	w3, [x0, #28]
    2e08:	aa0103f5 	mov	x21, x1
    2e0c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e10:	aa0003f4 	mov	x20, x0
    2e14:	f94e2440 	ldr	x0, [x2, #7240]
    2e18:	b4000440 	cbz	x0, 2ea0 <fwp_rc_prepare_chunk+0xb0>
    2e1c:	d2800013 	mov	x19, #0x0                   	// #0
    2e20:	35000203 	cbnz	w3, 2e60 <fwp_rc_prepare_chunk+0x70>
    2e24:	b4000361 	cbz	x1, 2e90 <fwp_rc_prepare_chunk+0xa0>
    2e28:	f9401280 	ldr	x0, [x20, #32]
    2e2c:	97fff9e1 	bl	15b0 <free@plt>
    2e30:	aa1503e0 	mov	x0, x21
    2e34:	d2800021 	mov	x1, #0x1                   	// #1
    2e38:	97fff9a6 	bl	14d0 <calloc@plt>
    2e3c:	f9001280 	str	x0, [x20, #32]
    2e40:	b5000460 	cbnz	x0, 2ecc <fwp_rc_prepare_chunk+0xdc>
    2e44:	97fffb73 	bl	1c10 <fwp_heap_oom>
    2e48:	97ffffc2 	bl	2d50 <fwp_rc_forget_slot>
    2e4c:	91000673 	add	x19, x19, #0x1
    2e50:	b9401e83 	ldr	w3, [x20, #28]
    2e54:	eb13007f 	cmp	x3, x19
    2e58:	54000169 	b.ls	2e84 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2e5c:	d503201f 	nop
    2e60:	f9401283 	ldr	x3, [x20, #32]
    2e64:	8b130060 	add	x0, x3, x19
    2e68:	38736863 	ldrb	w3, [x3, x19]
    2e6c:	7103fc7f 	cmp	w3, #0xff
    2e70:	54fffec0 	b.eq	2e48 <fwp_rc_prepare_chunk+0x58>  // b.none
    2e74:	b9401e83 	ldr	w3, [x20, #28]
    2e78:	91000673 	add	x19, x19, #0x1
    2e7c:	eb13007f 	cmp	x3, x19
    2e80:	54ffff08 	b.hi	2e60 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2e84:	eb0302bf 	cmp	x21, x3
    2e88:	54000121 	b.ne	2eac <fwp_rc_prepare_chunk+0xbc>  // b.any
    2e8c:	b5000335 	cbnz	x21, 2ef0 <fwp_rc_prepare_chunk+0x100>
    2e90:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e94:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2e9c:	d65f03c0 	ret
    2ea0:	2a0303e3 	mov	w3, w3
    2ea4:	eb0302bf 	cmp	x21, x3
    2ea8:	54ffff20 	b.eq	2e8c <fwp_rc_prepare_chunk+0x9c>  // b.none
    2eac:	911342c2 	add	x2, x22, #0x4d0
    2eb0:	f9401280 	ldr	x0, [x20, #32]
    2eb4:	f94e2841 	ldr	x1, [x2, #7248]
    2eb8:	cb030021 	sub	x1, x1, x3
    2ebc:	f90e2841 	str	x1, [x2, #7248]
    2ec0:	97fff9bc 	bl	15b0 <free@plt>
    2ec4:	b5fffb75 	cbnz	x21, 2e30 <fwp_rc_prepare_chunk+0x40>
    2ec8:	f900129f 	str	xzr, [x20, #32]
    2ecc:	911342d6 	add	x22, x22, #0x4d0
    2ed0:	f94e2ac0 	ldr	x0, [x22, #7248]
    2ed4:	b9001e95 	str	w21, [x20, #28]
    2ed8:	a94153f3 	ldp	x19, x20, [sp, #16]
    2edc:	8b150000 	add	x0, x0, x21
    2ee0:	f90e2ac0 	str	x0, [x22, #7248]
    2ee4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ee8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2eec:	d65f03c0 	ret
    2ef0:	f9401280 	ldr	x0, [x20, #32]
    2ef4:	aa1503e2 	mov	x2, x21
    2ef8:	a94153f3 	ldp	x19, x20, [sp, #16]
    2efc:	52800001 	mov	w1, #0x0                   	// #0
    2f00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f08:	17fff96e 	b	14c0 <memset@plt>
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_heap_refill>:
    2f10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2f14:	910003fd 	mov	x29, sp
    2f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    2f1c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    2f20:	911342b5 	add	x21, x21, #0x4d0
    2f24:	aa0003f6 	mov	x22, x0
    2f28:	d2800020 	mov	x0, #0x1                   	// #1
    2f2c:	a90153f3 	stp	x19, x20, [sp, #16]
    2f30:	a90363f7 	stp	x23, x24, [sp, #48]
    2f34:	2a0103f7 	mov	w23, w1
    2f38:	2a0203f8 	mov	w24, w2
    2f3c:	97fffb75 	bl	1d10 <fwp_heap_chunks>
    2f40:	aa0003f3 	mov	x19, x0
    2f44:	f949fea2 	ldr	x2, [x21, #5112]
    2f48:	8b000800 	add	x0, x0, x0, lsl #2
    2f4c:	2a1703e1 	mov	w1, w23
    2f50:	52800025 	mov	w5, #0x1                   	// #1
    2f54:	d37df000 	lsl	x0, x0, #3
    2f58:	910f0021 	add	x1, x1, #0x3c0
    2f5c:	8b000054 	add	x20, x2, x0
    2f60:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2f64:	52a00024 	mov	w4, #0x10000               	// #65536
    2f68:	38206845 	strb	w5, [x2, x0]
    2f6c:	aa1403e0 	mov	x0, x20
    2f70:	39000698 	strb	w24, [x20, #1]
    2f74:	39000a97 	strb	w23, [x20, #2]
    2f78:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2f7c:	b9000681 	str	w1, [x20, #4]
    2f80:	2a0103e5 	mov	w5, w1
    2f84:	8b0300a2 	add	x2, x5, x3
    2f88:	1ac10881 	udiv	w1, w4, w1
    2f8c:	9ac50842 	udiv	x2, x2, x5
    2f90:	b9000a81 	str	w1, [x20, #8]
    2f94:	92404021 	and	x1, x1, #0x1ffff
    2f98:	b9001a82 	str	w2, [x20, #24]
    2f9c:	97ffff95 	bl	2df0 <fwp_rc_prepare_chunk>
    2fa0:	f949daa0 	ldr	x0, [x21, #5040]
    2fa4:	29408a81 	ldp	w1, w2, [x20, #4]
    2fa8:	8b134000 	add	x0, x0, x19, lsl #16
    2fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    2fb0:	8b214003 	add	x3, x0, w1, uxtw
    2fb4:	9ba20021 	umaddl	x1, w1, w2, x0
    2fb8:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fbc:	a90086c3 	stp	x3, x1, [x22, #8]
    2fc0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2fc4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2fc8:	d65f03c0 	ret
    2fcc:	d503201f 	nop

0000000000002fd0 <fwp_mem_free>:
    2fd0:	b40003c0 	cbz	x0, 3048 <fwp_mem_free+0x78>
    2fd4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2fd8:	910003fd 	mov	x29, sp
    2fdc:	a9025bf5 	stp	x21, x22, [sp, #32]
    2fe0:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    2fe4:	911342a1 	add	x1, x21, #0x4d0
    2fe8:	a90153f3 	stp	x19, x20, [sp, #16]
    2fec:	aa0003f3 	mov	x19, x0
    2ff0:	f949d823 	ldr	x3, [x1, #5040]
    2ff4:	f949ec22 	ldr	x2, [x1, #5080]
    2ff8:	cb030000 	sub	x0, x0, x3
    2ffc:	eb02401f 	cmp	x0, x2, lsl #16
    3000:	540001c2 	b.cs	3038 <fwp_mem_free+0x68>  // b.hs, b.nlast
    3004:	d350fc16 	lsr	x22, x0, #16
    3008:	a90363f7 	stp	x23, x24, [sp, #48]
    300c:	f949fc22 	ldr	x2, [x1, #5112]
    3010:	8b160ad4 	add	x20, x22, x22, lsl #2
    3014:	d37df294 	lsl	x20, x20, #3
    3018:	ab140057 	adds	x23, x2, x20
    301c:	540000c0 	b.eq	3034 <fwp_mem_free+0x64>  // b.none
    3020:	38746842 	ldrb	w2, [x2, x20]
    3024:	7100045f 	cmp	w2, #0x1
    3028:	54000120 	b.eq	304c <fwp_mem_free+0x7c>  // b.none
    302c:	7100085f 	cmp	w2, #0x2
    3030:	540005e0 	b.eq	30ec <fwp_mem_free+0x11c>  // b.none
    3034:	a94363f7 	ldp	x23, x24, [sp, #48]
    3038:	a94153f3 	ldp	x19, x20, [sp, #16]
    303c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3040:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3044:	d65f03c0 	ret
    3048:	d65f03c0 	ret
    304c:	f94012f8 	ldr	x24, [x23, #32]
    3050:	b94006e1 	ldr	w1, [x23, #4]
    3054:	f90023f9 	str	x25, [sp, #64]
    3058:	2a0103e2 	mov	w2, w1
    305c:	394006f9 	ldrb	w25, [x23, #1]
    3060:	39400af4 	ldrb	w20, [x23, #2]
    3064:	b4000158 	cbz	x24, 308c <fwp_mem_free+0xbc>
    3068:	92403e76 	and	x22, x19, #0xffff
    306c:	9ac20ad6 	udiv	x22, x22, x2
    3070:	38766b01 	ldrb	w1, [x24, x22]
    3074:	8b160300 	add	x0, x24, x22
    3078:	7103fc3f 	cmp	w1, #0xff
    307c:	54000980 	b.eq	31ac <fwp_mem_free+0x1dc>  // b.none
    3080:	38366b1f 	strb	wzr, [x24, x22]
    3084:	b94006e1 	ldr	w1, [x23, #4]
    3088:	2a0103e2 	mov	w2, w1
    308c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    3090:	d37f1e83 	ubfiz	x3, x20, #1, #8
    3094:	cb390000 	sub	x0, x0, w25, uxtb
    3098:	8b340074 	add	x20, x3, w20, uxtb
    309c:	911342b5 	add	x21, x21, #0x4d0
    30a0:	1e630021 	ucvtf	d1, w1
    30a4:	d37ae400 	lsl	x0, x0, #6
    30a8:	8b140c14 	add	x20, x0, x20, lsl #3
    30ac:	a94363f7 	ldp	x23, x24, [sp, #48]
    30b0:	f8746aa0 	ldr	x0, [x21, x20]
    30b4:	f94023f9 	ldr	x25, [sp, #64]
    30b8:	aa2003e0 	mvn	x0, x0
    30bc:	fd4a22a0 	ldr	d0, [x21, #5184]
    30c0:	f9000260 	str	x0, [x19]
    30c4:	f8346ab3 	str	x19, [x21, x20]
    30c8:	f94a12a0 	ldr	x0, [x21, #5152]
    30cc:	1e612800 	fadd	d0, d0, d1
    30d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d4:	cb020000 	sub	x0, x0, x2
    30d8:	f90a12a0 	str	x0, [x21, #5152]
    30dc:	fd0a22a0 	str	d0, [x21, #5184]
    30e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    30e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    30e8:	d65f03c0 	ret
    30ec:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    30f0:	8b000063 	add	x3, x3, x0
    30f4:	eb03027f 	cmp	x19, x3
    30f8:	54fff9e1 	b.ne	3034 <fwp_mem_free+0x64>  // b.any
    30fc:	fd400ae1 	ldr	d1, [x23, #16]
    3100:	fd4a2020 	ldr	d0, [x1, #5184]
    3104:	f9400ae0 	ldr	x0, [x23, #16]
    3108:	7e61d821 	ucvtf	d1, d1
    310c:	f94a1022 	ldr	x2, [x1, #5152]
    3110:	f94012f3 	ldr	x19, [x23, #32]
    3114:	1e612800 	fadd	d0, d0, d1
    3118:	cb000042 	sub	x2, x2, x0
    311c:	f90a1022 	str	x2, [x1, #5152]
    3120:	fd0a2020 	str	d0, [x1, #5184]
    3124:	b40000b3 	cbz	x19, 3138 <fwp_mem_free+0x168>
    3128:	39400260 	ldrb	w0, [x19]
    312c:	7103fc1f 	cmp	w0, #0xff
    3130:	54000380 	b.eq	31a0 <fwp_mem_free+0x1d0>  // b.none
    3134:	3900027f 	strb	wzr, [x19]
    3138:	b9400ee2 	ldr	w2, [x23, #12]
    313c:	b4000142 	cbz	x2, 3164 <fwp_mem_free+0x194>
    3140:	911342a1 	add	x1, x21, #0x4d0
    3144:	8b160040 	add	x0, x2, x22
    3148:	8b000800 	add	x0, x0, x0, lsl #2
    314c:	f949fc21 	ldr	x1, [x1, #5112]
    3150:	8b140034 	add	x20, x1, x20
    3154:	8b000c20 	add	x0, x1, x0, lsl #3
    3158:	3802869f 	strb	wzr, [x20], #40
    315c:	eb00029f 	cmp	x20, x0
    3160:	54ffffc1 	b.ne	3158 <fwp_mem_free+0x188>  // b.any
    3164:	911342a0 	add	x0, x21, #0x4d0
    3168:	f94a1801 	ldr	x1, [x0, #5168]
    316c:	f949f803 	ldr	x3, [x0, #5104]
    3170:	8b020021 	add	x1, x1, x2
    3174:	f90a1801 	str	x1, [x0, #5168]
    3178:	eb16007f 	cmp	x3, x22
    317c:	54000049 	b.ls	3184 <fwp_mem_free+0x1b4>  // b.plast
    3180:	f909f816 	str	x22, [x0, #5104]
    3184:	911342b5 	add	x21, x21, #0x4d0
    3188:	f949f6a0 	ldr	x0, [x21, #5096]
    318c:	eb16001f 	cmp	x0, x22
    3190:	54fff529 	b.ls	3034 <fwp_mem_free+0x64>  // b.plast
    3194:	a94363f7 	ldp	x23, x24, [sp, #48]
    3198:	f909f6b6 	str	x22, [x21, #5096]
    319c:	17ffffa7 	b	3038 <fwp_mem_free+0x68>
    31a0:	aa1303e0 	mov	x0, x19
    31a4:	97fffeeb 	bl	2d50 <fwp_rc_forget_slot>
    31a8:	17ffffe3 	b	3134 <fwp_mem_free+0x164>
    31ac:	97fffee9 	bl	2d50 <fwp_rc_forget_slot>
    31b0:	17ffffb4 	b	3080 <fwp_mem_free+0xb0>

00000000000031b4 <fwp_heap_alloc_big>:
    31b4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    31b8:	910003fd 	mov	x29, sp
    31bc:	a90153f3 	stp	x19, x20, [sp, #16]
    31c0:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c4:	a90363f7 	stp	x23, x24, [sp, #48]
    31c8:	aa0003f7 	mov	x23, x0
    31cc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    31d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    31d4:	eb0002ff 	cmp	x23, x0
    31d8:	54000888 	b.hi	32e8 <fwp_heap_alloc_big+0x134>  // b.pmore
    31dc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    31e0:	8b0002f4 	add	x20, x23, x0
    31e4:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xd10>
    31e8:	91134359 	add	x25, x26, #0x4d0
    31ec:	d350fe94 	lsr	x20, x20, #16
    31f0:	2a0103f5 	mov	w21, w1
    31f4:	aa1403e0 	mov	x0, x20
    31f8:	97fffac6 	bl	1d10 <fwp_heap_chunks>
    31fc:	f949ff22 	ldr	x2, [x25, #5112]
    3200:	8b000813 	add	x19, x0, x0, lsl #2
    3204:	aa0003f8 	mov	x24, x0
    3208:	52800043 	mov	w3, #0x2                   	// #2
    320c:	d37df273 	lsl	x19, x19, #3
    3210:	d2800021 	mov	x1, #0x1                   	// #1
    3214:	8b130040 	add	x0, x2, x19
    3218:	38336843 	strb	w3, [x2, x19]
    321c:	39000415 	strb	w21, [x0, #1]
    3220:	b9000c14 	str	w20, [x0, #12]
    3224:	f9000817 	str	x23, [x0, #16]
    3228:	97fffef2 	bl	2df0 <fwp_rc_prepare_chunk>
    322c:	f100069f 	cmp	x20, #0x1
    3230:	54000269 	b.ls	327c <fwp_heap_alloc_big+0xc8>  // b.plast
    3234:	8b180294 	add	x20, x20, x24
    3238:	9100a273 	add	x19, x19, #0x28
    323c:	a90573fb 	stp	x27, x28, [sp, #80]
    3240:	5280007b 	mov	w27, #0x3                   	// #3
    3244:	8b140a94 	add	x20, x20, x20, lsl #2
    3248:	2a1803fc 	mov	w28, w24
    324c:	9adb2296 	lsl	x22, x20, x27
    3250:	f949ff35 	ldr	x21, [x25, #5112]
    3254:	d2800001 	mov	x1, #0x0                   	// #0
    3258:	8b1302b4 	add	x20, x21, x19
    325c:	aa1403e0 	mov	x0, x20
    3260:	97fffee4 	bl	2df0 <fwp_rc_prepare_chunk>
    3264:	38336abb 	strb	w27, [x21, x19]
    3268:	9100a273 	add	x19, x19, #0x28
    326c:	b9000e9c 	str	w28, [x20, #12]
    3270:	eb1302df 	cmp	x22, x19
    3274:	54fffee1 	b.ne	3250 <fwp_heap_alloc_big+0x9c>  // b.any
    3278:	a94573fb 	ldp	x27, x28, [sp, #80]
    327c:	91134353 	add	x19, x26, #0x4d0
    3280:	aa1703e2 	mov	x2, x23
    3284:	52800001 	mov	w1, #0x0                   	// #0
    3288:	f949da60 	ldr	x0, [x19, #5040]
    328c:	8b184018 	add	x24, x0, x24, lsl #16
    3290:	aa1803e0 	mov	x0, x24
    3294:	97fff88b 	bl	14c0 <memset@plt>
    3298:	f94a1260 	ldr	x0, [x19, #5152]
    329c:	ab170000 	adds	x0, x0, x23
    32a0:	54000242 	b.cs	32e8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    32a4:	f94a1661 	ldr	x1, [x19, #5160]
    32a8:	f90a1260 	str	x0, [x19, #5152]
    32ac:	eb01001f 	cmp	x0, x1
    32b0:	54000049 	b.ls	32b8 <fwp_heap_alloc_big+0x104>  // b.plast
    32b4:	f90a1660 	str	x0, [x19, #5160]
    32b8:	9113435a 	add	x26, x26, #0x4d0
    32bc:	9e6202e0 	scvtf	d0, x23
    32c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32c4:	aa1803e0 	mov	x0, x24
    32c8:	fd4a1f41 	ldr	d1, [x26, #5176]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	1e602820 	fadd	d0, d1, d0
    32d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    32d8:	fd0a1f40 	str	d0, [x26, #5176]
    32dc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    32e0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    32e4:	d65f03c0 	ret
    32e8:	a90573fb 	stp	x27, x28, [sp, #80]
    32ec:	97fffa49 	bl	1c10 <fwp_heap_oom>

00000000000032f0 <fwp_heap_alloc_slow>:
    32f0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32f4:	910003fd 	mov	x29, sp
    32f8:	a90153f3 	stp	x19, x20, [sp, #16]
    32fc:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xd10>
    3300:	91134262 	add	x2, x19, #0x4d0
    3304:	a9025bf5 	stp	x21, x22, [sp, #32]
    3308:	aa0003f5 	mov	x21, x0
    330c:	2a0103f4 	mov	w20, w1
    3310:	b953a440 	ldr	w0, [x2, #5028]
    3314:	34000600 	cbz	w0, 33d4 <fwp_heap_alloc_slow+0xe4>
    3318:	f14012bf 	cmp	x21, #0x4, lsl #12
    331c:	54000628 	b.hi	33e0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3320:	91003ea0 	add	x0, x21, #0xf
    3324:	91134262 	add	x2, x19, #0x4d0
    3328:	f9001bf7 	str	x23, [sp, #48]
    332c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3330:	8b401040 	add	x0, x2, x0, lsr #4
    3334:	cb34c084 	sub	x4, x4, w20, sxtw
    3338:	d37ae484 	lsl	x4, x4, #6
    333c:	397e8003 	ldrb	w3, [x0, #4000]
    3340:	910f0060 	add	x0, x3, #0x3c0
    3344:	aa0303e1 	mov	x1, x3
    3348:	8b030463 	add	x3, x3, x3, lsl #1
    334c:	8b030c83 	add	x3, x4, x3, lsl #3
    3350:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3354:	2a1703f6 	mov	w22, w23
    3358:	f8636844 	ldr	x4, [x2, x3]
    335c:	b40004e4 	cbz	x4, 33f8 <fwp_heap_alloc_slow+0x108>
    3360:	f9400080 	ldr	x0, [x4]
    3364:	aa2003e0 	mvn	x0, x0
    3368:	f8236840 	str	x0, [x2, x3]
    336c:	7100069f 	cmp	w20, #0x1
    3370:	aa0403e0 	mov	x0, x4
    3374:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    3378:	52800001 	mov	w1, #0x0                   	// #0
    337c:	97fff851 	bl	14c0 <memset@plt>
    3380:	aa0003e4 	mov	x4, x0
    3384:	91134260 	add	x0, x19, #0x4d0
    3388:	f94a1001 	ldr	x1, [x0, #5152]
    338c:	ab160021 	adds	x1, x1, x22
    3390:	540005c2 	b.cs	3448 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    3394:	f94a1402 	ldr	x2, [x0, #5160]
    3398:	f90a1001 	str	x1, [x0, #5152]
    339c:	eb02003f 	cmp	x1, x2
    33a0:	54000049 	b.ls	33a8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    33a4:	f90a1401 	str	x1, [x0, #5160]
    33a8:	91134273 	add	x19, x19, #0x4d0
    33ac:	1e6302e1 	ucvtf	d1, w23
    33b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33b4:	aa0403e0 	mov	x0, x4
    33b8:	fd4a1e60 	ldr	d0, [x19, #5176]
    33bc:	f9401bf7 	ldr	x23, [sp, #48]
    33c0:	1e612800 	fadd	d0, d0, d1
    33c4:	fd0a1e60 	str	d0, [x19, #5176]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    33d0:	d65f03c0 	ret
    33d4:	97fffce8 	bl	2774 <fwp_heap_init>
    33d8:	f14012bf 	cmp	x21, #0x4, lsl #12
    33dc:	54fffa29 	b.ls	3320 <fwp_heap_alloc_slow+0x30>  // b.plast
    33e0:	2a1403e1 	mov	w1, w20
    33e4:	aa1503e0 	mov	x0, x21
    33e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33f0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    33f4:	17ffff70 	b	31b4 <fwp_heap_alloc_big>
    33f8:	8b030042 	add	x2, x2, x3
    33fc:	f9400444 	ldr	x4, [x2, #8]
    3400:	b4000104 	cbz	x4, 3420 <fwp_heap_alloc_slow+0x130>
    3404:	f9400840 	ldr	x0, [x2, #16]
    3408:	cb040000 	sub	x0, x0, x4
    340c:	eb16001f 	cmp	x0, x22
    3410:	54000083 	b.cc	3420 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3414:	8b160080 	add	x0, x4, x22
    3418:	f9000440 	str	x0, [x2, #8]
    341c:	17ffffd4 	b	336c <fwp_heap_alloc_slow+0x7c>
    3420:	52800302 	mov	w2, #0x18                  	// #24
    3424:	52807804 	mov	w4, #0x3c0                 	// #960
    3428:	91134260 	add	x0, x19, #0x4d0
    342c:	9ba27c23 	umull	x3, w1, w2
    3430:	2a1403e2 	mov	w2, w20
    3434:	9b240e84 	smaddl	x4, w20, w4, x3
    3438:	8b040000 	add	x0, x0, x4
    343c:	97fffeb5 	bl	2f10 <fwp_heap_refill>
    3440:	aa0003e4 	mov	x4, x0
    3444:	17ffffca 	b	336c <fwp_heap_alloc_slow+0x7c>
    3448:	97fff9f2 	bl	1c10 <fwp_heap_oom>
    344c:	d503201f 	nop

0000000000003450 <fwp_rc_share>:
    3450:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    3454:	91134042 	add	x2, x2, #0x4d0
    3458:	f949d843 	ldr	x3, [x2, #5040]
    345c:	f949ec41 	ldr	x1, [x2, #5080]
    3460:	cb030000 	sub	x0, x0, x3
    3464:	eb01401f 	cmp	x0, x1, lsl #16
    3468:	540002c2 	b.cs	34c0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    346c:	d350fc01 	lsr	x1, x0, #16
    3470:	f949fc44 	ldr	x4, [x2, #5112]
    3474:	8b010821 	add	x1, x1, x1, lsl #2
    3478:	d37df021 	lsl	x1, x1, #3
    347c:	8b010083 	add	x3, x4, x1
    3480:	f9401062 	ldr	x2, [x3, #32]
    3484:	b40001e2 	cbz	x2, 34c0 <fwp_rc_share+0x70>
    3488:	38616881 	ldrb	w1, [x4, x1]
    348c:	7100083f 	cmp	w1, #0x2
    3490:	540001a0 	b.eq	34c4 <fwp_rc_share+0x74>  // b.none
    3494:	7100043f 	cmp	w1, #0x1
    3498:	54000141 	b.ne	34c0 <fwp_rc_share+0x70>  // b.any
    349c:	29430464 	ldp	w4, w1, [x3, #24]
    34a0:	92403c00 	and	x0, x0, #0xffff
    34a4:	9b047c00 	mul	x0, x0, x4
    34a8:	d360fc00 	lsr	x0, x0, #32
    34ac:	eb01001f 	cmp	x0, x1
    34b0:	54000082 	b.cs	34c0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    34b4:	8b000042 	add	x2, x2, x0
    34b8:	39400040 	ldrb	w0, [x2]
    34bc:	350000a0 	cbnz	w0, 34d0 <fwp_rc_share+0x80>
    34c0:	d65f03c0 	ret
    34c4:	72003c1f 	tst	w0, #0xffff
    34c8:	54ffff80 	b.eq	34b8 <fwp_rc_share+0x68>  // b.none
    34cc:	d65f03c0 	ret
    34d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    34d4:	d0000020 	adrp	x0, 9000 <f0+0x2610>
    34d8:	913ae000 	add	x0, x0, #0xeb8
    34dc:	910003fd 	mov	x29, sp
    34e0:	97fffb10 	bl	2120 <fwp_trap>

00000000000034e4 <e69>:
    34e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34e8:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x380>
    34ec:	910003fd 	mov	x29, sp
    34f0:	fd400001 	ldr	d1, [x0]
    34f4:	f9000bf3 	str	x19, [sp, #16]
    34f8:	fd40e820 	ldr	d0, [x1, #464]
    34fc:	1e610800 	fmul	d0, d0, d1
    3500:	9e660013 	fmov	x19, d0
    3504:	aa1303e0 	mov	x0, x19
    3508:	97ffffd2 	bl	3450 <fwp_rc_share>
    350c:	aa1303e0 	mov	x0, x19
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	d503201f 	nop

0000000000003520 <e45>:
    3520:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3524:	910003fd 	mov	x29, sp
    3528:	6d400001 	ldp	d1, d0, [x0]
    352c:	f9000bf3 	str	x19, [sp, #16]
    3530:	1e612800 	fadd	d0, d0, d1
    3534:	9e660013 	fmov	x19, d0
    3538:	aa1303e0 	mov	x0, x19
    353c:	97ffffc5 	bl	3450 <fwp_rc_share>
    3540:	aa1303e0 	mov	x0, x19
    3544:	f9400bf3 	ldr	x19, [sp, #16]
    3548:	a8c27bfd 	ldp	x29, x30, [sp], #32
    354c:	d65f03c0 	ret

0000000000003550 <e32>:
    3550:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3554:	910003fd 	mov	x29, sp
    3558:	6d400001 	ldp	d1, d0, [x0]
    355c:	f9000bf3 	str	x19, [sp, #16]
    3560:	1e613800 	fsub	d0, d0, d1
    3564:	9e660013 	fmov	x19, d0
    3568:	aa1303e0 	mov	x0, x19
    356c:	97ffffb9 	bl	3450 <fwp_rc_share>
    3570:	aa1303e0 	mov	x0, x19
    3574:	f9400bf3 	ldr	x19, [sp, #16]
    3578:	a8c27bfd 	ldp	x29, x30, [sp], #32
    357c:	d65f03c0 	ret

0000000000003580 <fwp_rc_fresh>:
    3580:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3584:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3588:	91134063 	add	x3, x3, #0x4d0
    358c:	910003fd 	mov	x29, sp
    3590:	a90153f3 	stp	x19, x20, [sp, #16]
    3594:	aa0003f3 	mov	x19, x0
    3598:	f949d861 	ldr	x1, [x3, #5040]
    359c:	f949ec60 	ldr	x0, [x3, #5080]
    35a0:	cb010261 	sub	x1, x19, x1
    35a4:	eb00403f 	cmp	x1, x0, lsl #16
    35a8:	54000322 	b.cs	360c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    35ac:	d350fc22 	lsr	x2, x1, #16
    35b0:	f949fc63 	ldr	x3, [x3, #5112]
    35b4:	8b020842 	add	x2, x2, x2, lsl #2
    35b8:	d37df042 	lsl	x2, x2, #3
    35bc:	8b020060 	add	x0, x3, x2
    35c0:	f9401014 	ldr	x20, [x0, #32]
    35c4:	b4000254 	cbz	x20, 360c <fwp_rc_fresh+0x8c>
    35c8:	38626862 	ldrb	w2, [x3, x2]
    35cc:	7100085f 	cmp	w2, #0x2
    35d0:	54000260 	b.eq	361c <fwp_rc_fresh+0x9c>  // b.none
    35d4:	7100045f 	cmp	w2, #0x1
    35d8:	540001a1 	b.ne	360c <fwp_rc_fresh+0x8c>  // b.any
    35dc:	29430002 	ldp	w2, w0, [x0, #24]
    35e0:	92403c21 	and	x1, x1, #0xffff
    35e4:	9b027c21 	mul	x1, x1, x2
    35e8:	d360fc21 	lsr	x1, x1, #32
    35ec:	eb00003f 	cmp	x1, x0
    35f0:	540000e2 	b.cs	360c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    35f4:	8b010294 	add	x20, x20, x1
    35f8:	39400280 	ldrb	w0, [x20]
    35fc:	7103fc1f 	cmp	w0, #0xff
    3600:	540001a0 	b.eq	3634 <fwp_rc_fresh+0xb4>  // b.none
    3604:	52800020 	mov	w0, #0x1                   	// #1
    3608:	39000280 	strb	w0, [x20]
    360c:	aa1303e0 	mov	x0, x19
    3610:	a94153f3 	ldp	x19, x20, [sp, #16]
    3614:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3618:	d65f03c0 	ret
    361c:	72003c3f 	tst	w1, #0xffff
    3620:	54fffec0 	b.eq	35f8 <fwp_rc_fresh+0x78>  // b.none
    3624:	aa1303e0 	mov	x0, x19
    3628:	a94153f3 	ldp	x19, x20, [sp, #16]
    362c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3630:	d65f03c0 	ret
    3634:	aa1403e0 	mov	x0, x20
    3638:	97fffdc6 	bl	2d50 <fwp_rc_forget_slot>
    363c:	17fffff2 	b	3604 <fwp_rc_fresh+0x84>

0000000000003640 <fwp_rc_dup>:
    3640:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    3644:	91134042 	add	x2, x2, #0x4d0
    3648:	f949d841 	ldr	x1, [x2, #5040]
    364c:	f949ec43 	ldr	x3, [x2, #5080]
    3650:	cb010001 	sub	x1, x0, x1
    3654:	eb03403f 	cmp	x1, x3, lsl #16
    3658:	54000342 	b.cs	36c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    365c:	d350fc20 	lsr	x0, x1, #16
    3660:	f949fc44 	ldr	x4, [x2, #5112]
    3664:	8b000800 	add	x0, x0, x0, lsl #2
    3668:	d37df002 	lsl	x2, x0, #3
    366c:	8b020083 	add	x3, x4, x2
    3670:	f9401060 	ldr	x0, [x3, #32]
    3674:	b4000260 	cbz	x0, 36c0 <fwp_rc_dup+0x80>
    3678:	38626882 	ldrb	w2, [x4, x2]
    367c:	7100085f 	cmp	w2, #0x2
    3680:	54000220 	b.eq	36c4 <fwp_rc_dup+0x84>  // b.none
    3684:	7100045f 	cmp	w2, #0x1
    3688:	540001c1 	b.ne	36c0 <fwp_rc_dup+0x80>  // b.any
    368c:	29430864 	ldp	w4, w2, [x3, #24]
    3690:	92403c21 	and	x1, x1, #0xffff
    3694:	9b047c21 	mul	x1, x1, x4
    3698:	d360fc21 	lsr	x1, x1, #32
    369c:	eb02003f 	cmp	x1, x2
    36a0:	54000102 	b.cs	36c0 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    36a4:	8b010000 	add	x0, x0, x1
    36a8:	39400001 	ldrb	w1, [x0]
    36ac:	340000a1 	cbz	w1, 36c0 <fwp_rc_dup+0x80>
    36b0:	7103f43f 	cmp	w1, #0xfd
    36b4:	540000e8 	b.hi	36d0 <fwp_rc_dup+0x90>  // b.pmore
    36b8:	11000421 	add	w1, w1, #0x1
    36bc:	39000001 	strb	w1, [x0]
    36c0:	d65f03c0 	ret
    36c4:	72003c3f 	tst	w1, #0xffff
    36c8:	54ffff00 	b.eq	36a8 <fwp_rc_dup+0x68>  // b.none
    36cc:	d65f03c0 	ret
    36d0:	17fffd59 	b	2c34 <fwp_rc_wide_dup>

00000000000036d4 <fwp_task_dispose>:
    36d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36d8:	910003fd 	mov	x29, sp
    36dc:	f9000bf3 	str	x19, [sp, #16]
    36e0:	aa0003f3 	mov	x19, x0
    36e4:	39414000 	ldrb	w0, [x0, #80]
    36e8:	36000720 	tbz	w0, #0, 37cc <fwp_task_dispose+0xf8>
    36ec:	f9400a60 	ldr	x0, [x19, #16]
    36f0:	b50006e0 	cbnz	x0, 37cc <fwp_task_dispose+0xf8>
    36f4:	a9478660 	ldp	x0, x1, [x19, #120]
    36f8:	39014e7f 	strb	wzr, [x19, #83]
    36fc:	f9003e7f 	str	xzr, [x19, #120]
    3700:	f100003f 	cmp	x1, #0x0
    3704:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3708:	54000040 	b.eq	3710 <fwp_task_dispose+0x3c>  // b.none
    370c:	d63f0020 	blr	x1
    3710:	f9405660 	ldr	x0, [x19, #168]
    3714:	97fffe2f 	bl	2fd0 <fwp_mem_free>
    3718:	f900567f 	str	xzr, [x19, #168]
    371c:	b9405e60 	ldr	w0, [x19, #92]
    3720:	7100041f 	cmp	w0, #0x1
    3724:	54000420 	b.eq	37a8 <fwp_task_dispose+0xd4>  // b.none
    3728:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    372c:	91134042 	add	x2, x2, #0x4d0
    3730:	f949d840 	ldr	x0, [x2, #5040]
    3734:	f949ec41 	ldr	x1, [x2, #5080]
    3738:	cb000260 	sub	x0, x19, x0
    373c:	eb01401f 	cmp	x0, x1, lsl #16
    3740:	540002e2 	b.cs	379c <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3744:	d350fc01 	lsr	x1, x0, #16
    3748:	f949fc44 	ldr	x4, [x2, #5112]
    374c:	8b010821 	add	x1, x1, x1, lsl #2
    3750:	d37df021 	lsl	x1, x1, #3
    3754:	8b010083 	add	x3, x4, x1
    3758:	f9401062 	ldr	x2, [x3, #32]
    375c:	b4000202 	cbz	x2, 379c <fwp_task_dispose+0xc8>
    3760:	38616881 	ldrb	w1, [x4, x1]
    3764:	7100083f 	cmp	w1, #0x2
    3768:	54000280 	b.eq	37b8 <fwp_task_dispose+0xe4>  // b.none
    376c:	7100043f 	cmp	w1, #0x1
    3770:	54000161 	b.ne	379c <fwp_task_dispose+0xc8>  // b.any
    3774:	29430464 	ldp	w4, w1, [x3, #24]
    3778:	92403c00 	and	x0, x0, #0xffff
    377c:	9b047c00 	mul	x0, x0, x4
    3780:	d360fc00 	lsr	x0, x0, #32
    3784:	eb01001f 	cmp	x0, x1
    3788:	540000a2 	b.cs	379c <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    378c:	8b000042 	add	x2, x2, x0
    3790:	39400040 	ldrb	w0, [x2]
    3794:	7100041f 	cmp	w0, #0x1
    3798:	54000080 	b.eq	37a8 <fwp_task_dispose+0xd4>  // b.none
    379c:	f9400bf3 	ldr	x19, [sp, #16]
    37a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37a4:	d65f03c0 	ret
    37a8:	aa1303e0 	mov	x0, x19
    37ac:	f9400bf3 	ldr	x19, [sp, #16]
    37b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37b4:	17fffe07 	b	2fd0 <fwp_mem_free>
    37b8:	72003c1f 	tst	w0, #0xffff
    37bc:	54fffea0 	b.eq	3790 <fwp_task_dispose+0xbc>  // b.none
    37c0:	f9400bf3 	ldr	x19, [sp, #16]
    37c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37c8:	d65f03c0 	ret
    37cc:	97fff75d 	bl	1540 <abort@plt>

00000000000037d0 <fwp_free_zombie>:
    37d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37d4:	910003fd 	mov	x29, sp
    37d8:	a90153f3 	stp	x19, x20, [sp, #16]
    37dc:	b00000f4 	adrp	x20, 20000 <__data_start>
    37e0:	9100c281 	add	x1, x20, #0x30
    37e4:	f9401c33 	ldr	x19, [x1, #56]
    37e8:	b4000333 	cbz	x19, 384c <fwp_free_zombie+0x7c>
    37ec:	f9400420 	ldr	x0, [x1, #8]
    37f0:	eb00027f 	cmp	x19, x0
    37f4:	540002c0 	b.eq	384c <fwp_free_zombie+0x7c>  // b.none
    37f8:	b9404022 	ldr	w2, [x1, #64]
    37fc:	f9400a60 	ldr	x0, [x19, #16]
    3800:	7100fc5f 	cmp	w2, #0x3f
    3804:	5400078c 	b.gt	38f4 <fwp_free_zombie+0x124>
    3808:	91014023 	add	x3, x1, #0x50
    380c:	11000444 	add	w4, w2, #0x1
    3810:	b9004024 	str	w4, [x1, #64]
    3814:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3818:	f822d860 	str	x0, [x3, w2, sxtw #3]
    381c:	a9530261 	ldp	x1, x0, [x19, #304]
    3820:	b4000741 	cbz	x1, 3908 <fwp_free_zombie+0x138>
    3824:	f9009c20 	str	x0, [x1, #312]
    3828:	b4000040 	cbz	x0, 3830 <fwp_free_zombie+0x60>
    382c:	f9009801 	str	x1, [x0, #304]
    3830:	9100c294 	add	x20, x20, #0x30
    3834:	b9405e60 	ldr	w0, [x19, #92]
    3838:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    383c:	f9001e9f 	str	xzr, [x20, #56]
    3840:	34000140 	cbz	w0, 3868 <fwp_free_zombie+0x98>
    3844:	7100041f 	cmp	w0, #0x1
    3848:	54000080 	b.eq	3858 <fwp_free_zombie+0x88>  // b.none
    384c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3850:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3854:	d65f03c0 	ret
    3858:	aa1303e0 	mov	x0, x19
    385c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3860:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3864:	17ffff9c 	b	36d4 <fwp_task_dispose>
    3868:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xd10>
    386c:	91134082 	add	x2, x4, #0x4d0
    3870:	f949d841 	ldr	x1, [x2, #5040]
    3874:	f949ec40 	ldr	x0, [x2, #5080]
    3878:	cb010261 	sub	x1, x19, x1
    387c:	eb00403f 	cmp	x1, x0, lsl #16
    3880:	54fffe62 	b.cs	384c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3884:	d350fc20 	lsr	x0, x1, #16
    3888:	f949fc43 	ldr	x3, [x2, #5112]
    388c:	8b000800 	add	x0, x0, x0, lsl #2
    3890:	d37df000 	lsl	x0, x0, #3
    3894:	8b000062 	add	x2, x3, x0
    3898:	f9401054 	ldr	x20, [x2, #32]
    389c:	b4fffd94 	cbz	x20, 384c <fwp_free_zombie+0x7c>
    38a0:	38606860 	ldrb	w0, [x3, x0]
    38a4:	7100081f 	cmp	w0, #0x2
    38a8:	54000360 	b.eq	3914 <fwp_free_zombie+0x144>  // b.none
    38ac:	7100041f 	cmp	w0, #0x1
    38b0:	54fffce1 	b.ne	384c <fwp_free_zombie+0x7c>  // b.any
    38b4:	29430043 	ldp	w3, w0, [x2, #24]
    38b8:	92403c21 	and	x1, x1, #0xffff
    38bc:	9b037c21 	mul	x1, x1, x3
    38c0:	d360fc21 	lsr	x1, x1, #32
    38c4:	eb00003f 	cmp	x1, x0
    38c8:	54fffc22 	b.cs	384c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    38cc:	8b010294 	add	x20, x20, x1
    38d0:	39400280 	ldrb	w0, [x20]
    38d4:	34fffbc0 	cbz	w0, 384c <fwp_free_zombie+0x7c>
    38d8:	7100041f 	cmp	w0, #0x1
    38dc:	54fffbe0 	b.eq	3858 <fwp_free_zombie+0x88>  // b.none
    38e0:	7103fc1f 	cmp	w0, #0xff
    38e4:	540001e0 	b.eq	3920 <fwp_free_zombie+0x150>  // b.none
    38e8:	51000400 	sub	w0, w0, #0x1
    38ec:	39000280 	strb	w0, [x20]
    38f0:	17ffffd7 	b	384c <fwp_free_zombie+0x7c>
    38f4:	f9400e61 	ldr	x1, [x19, #24]
    38f8:	97fff746 	bl	1610 <munmap@plt>
    38fc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3900:	a9530261 	ldp	x1, x0, [x19, #304]
    3904:	b5fff901 	cbnz	x1, 3824 <fwp_free_zombie+0x54>
    3908:	9100c282 	add	x2, x20, #0x30
    390c:	f9012840 	str	x0, [x2, #592]
    3910:	17ffffc6 	b	3828 <fwp_free_zombie+0x58>
    3914:	72003c3f 	tst	w1, #0xffff
    3918:	54fff9a1 	b.ne	384c <fwp_free_zombie+0x7c>  // b.any
    391c:	17ffffed 	b	38d0 <fwp_free_zombie+0x100>
    3920:	ca544680 	eor	x0, x20, x20, lsr #17
    3924:	91134084 	add	x4, x4, #0x4d0
    3928:	ca402400 	eor	x0, x0, x0, lsr #9
    392c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3930:	f94a2400 	ldr	x0, [x0, #5192]
    3934:	b5000080 	cbnz	x0, 3944 <fwp_free_zombie+0x174>
    3938:	14000010 	b	3978 <fwp_free_zombie+0x1a8>
    393c:	f9400800 	ldr	x0, [x0, #16]
    3940:	b40001c0 	cbz	x0, 3978 <fwp_free_zombie+0x1a8>
    3944:	f9400001 	ldr	x1, [x0]
    3948:	eb14003f 	cmp	x1, x20
    394c:	54ffff81 	b.ne	393c <fwp_free_zombie+0x16c>  // b.any
    3950:	f9400401 	ldr	x1, [x0, #8]
    3954:	d1000421 	sub	x1, x1, #0x1
    3958:	f9000401 	str	x1, [x0, #8]
    395c:	f103f83f 	cmp	x1, #0xfe
    3960:	54fff761 	b.ne	384c <fwp_free_zombie+0x7c>  // b.any
    3964:	aa1403e0 	mov	x0, x20
    3968:	97fffcfa 	bl	2d50 <fwp_rc_forget_slot>
    396c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3970:	39000280 	strb	w0, [x20]
    3974:	17ffffb6 	b	384c <fwp_free_zombie+0x7c>
    3978:	d0000020 	adrp	x0, 9000 <f0+0x2610>
    397c:	9139c000 	add	x0, x0, #0xe70
    3980:	97fff9e8 	bl	2120 <fwp_trap>

0000000000003984 <fwp_block>:
    3984:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3988:	910003fd 	mov	x29, sp
    398c:	a90153f3 	stp	x19, x20, [sp, #16]
    3990:	b00000f3 	adrp	x19, 20000 <__data_start>
    3994:	9100c274 	add	x20, x19, #0x30
    3998:	f9401682 	ldr	x2, [x20, #40]
    399c:	b4000622 	cbz	x2, 3a60 <fwp_block+0xdc>
    39a0:	9100c261 	add	x1, x19, #0x30
    39a4:	f9408040 	ldr	x0, [x2, #256]
    39a8:	f9001420 	str	x0, [x1, #40]
    39ac:	b4000680 	cbz	x0, 3a7c <fwp_block+0xf8>
    39b0:	9100c263 	add	x3, x19, #0x30
    39b4:	3901505f 	strb	wzr, [x2, #84]
    39b8:	f9400464 	ldr	x4, [x3, #8]
    39bc:	eb02009f 	cmp	x4, x2
    39c0:	54000440 	b.eq	3a48 <fwp_block+0xc4>  // b.none
    39c4:	f9412c65 	ldr	x5, [x3, #600]
    39c8:	f9000462 	str	x2, [x3, #8]
    39cc:	f9400441 	ldr	x1, [x2, #8]
    39d0:	f9004885 	str	x5, [x4, #144]
    39d4:	f9413065 	ldr	x5, [x3, #608]
    39d8:	f9004c85 	str	x5, [x4, #152]
    39dc:	f9413465 	ldr	x5, [x3, #616]
    39e0:	f9005085 	str	x5, [x4, #160]
    39e4:	f9413865 	ldr	x5, [x3, #624]
    39e8:	f9005485 	str	x5, [x4, #168]
    39ec:	f9413c65 	ldr	x5, [x3, #632]
    39f0:	f9005885 	str	x5, [x4, #176]
    39f4:	f9414065 	ldr	x5, [x3, #640]
    39f8:	f9005c85 	str	x5, [x4, #184]
    39fc:	f9414465 	ldr	x5, [x3, #648]
    3a00:	f9006085 	str	x5, [x4, #192]
    3a04:	f9400480 	ldr	x0, [x4, #8]
    3a08:	f9404844 	ldr	x4, [x2, #144]
    3a0c:	f9012c64 	str	x4, [x3, #600]
    3a10:	f9404c44 	ldr	x4, [x2, #152]
    3a14:	f9013064 	str	x4, [x3, #608]
    3a18:	f9405044 	ldr	x4, [x2, #160]
    3a1c:	f9013464 	str	x4, [x3, #616]
    3a20:	f9405444 	ldr	x4, [x2, #168]
    3a24:	f9013864 	str	x4, [x3, #624]
    3a28:	f9405844 	ldr	x4, [x2, #176]
    3a2c:	f9013c64 	str	x4, [x3, #632]
    3a30:	a94b8844 	ldp	x4, x2, [x2, #184]
    3a34:	f9014064 	str	x4, [x3, #640]
    3a38:	f9014462 	str	x2, [x3, #648]
    3a3c:	97fff6c5 	bl	1550 <swapcontext@plt>
    3a40:	97ffff64 	bl	37d0 <fwp_free_zombie>
    3a44:	d503201f 	nop
    3a48:	9100c260 	add	x0, x19, #0x30
    3a4c:	b9429000 	ldr	w0, [x0, #656]
    3a50:	340001a0 	cbz	w0, 3a84 <fwp_block+0x100>
    3a54:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a58:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3a5c:	d65f03c0 	ret
    3a60:	97fffbe8 	bl	2a00 <fwp_poll_events>
    3a64:	f9401682 	ldr	x2, [x20, #40]
    3a68:	b4ffffc2 	cbz	x2, 3a60 <fwp_block+0xdc>
    3a6c:	9100c261 	add	x1, x19, #0x30
    3a70:	f9408040 	ldr	x0, [x2, #256]
    3a74:	f9001420 	str	x0, [x1, #40]
    3a78:	b5fff9c0 	cbnz	x0, 39b0 <fwp_block+0x2c>
    3a7c:	f900103f 	str	xzr, [x1, #32]
    3a80:	17ffffcc 	b	39b0 <fwp_block+0x2c>
    3a84:	d0000020 	adrp	x0, 9000 <f0+0x2610>
    3a88:	913ba000 	add	x0, x0, #0xee8
    3a8c:	97fff6fd 	bl	1680 <getenv@plt>
    3a90:	5284e202 	mov	w2, #0x2710                	// #10000
    3a94:	b4000060 	cbz	x0, 3aa0 <fwp_block+0x11c>
    3a98:	39400001 	ldrb	w1, [x0]
    3a9c:	350000c1 	cbnz	w1, 3ab4 <fwp_block+0x130>
    3aa0:	9100c273 	add	x19, x19, #0x30
    3aa4:	b9029262 	str	w2, [x19, #656]
    3aa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3aac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3ab0:	d65f03c0 	ret
    3ab4:	52800142 	mov	w2, #0xa                   	// #10
    3ab8:	d2800001 	mov	x1, #0x0                   	// #0
    3abc:	97fff641 	bl	13c0 <strtoll@plt>
    3ac0:	d1000403 	sub	x3, x0, #0x1
    3ac4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3ac8:	eb02007f 	cmp	x3, x2
    3acc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3ad0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3ad4:	17fffff3 	b	3aa0 <fwp_block+0x11c>
    3ad8:	d503201f 	nop
    3adc:	d503201f 	nop

0000000000003ae0 <fwp_map_items>:
    3ae0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3ae4:	910003fd 	mov	x29, sp
    3ae8:	a90153f3 	stp	x19, x20, [sp, #16]
    3aec:	aa0003f3 	mov	x19, x0
    3af0:	b4000a80 	cbz	x0, 3c40 <fwp_map_items+0x160>
    3af4:	aa0003e2 	mov	x2, x0
    3af8:	d2800000 	mov	x0, #0x0                   	// #0
    3afc:	d503201f 	nop
    3b00:	f9400842 	ldr	x2, [x2, #16]
    3b04:	aa0003e3 	mov	x3, x0
    3b08:	91000400 	add	x0, x0, #0x1
    3b0c:	b5ffffa2 	cbnz	x2, 3b00 <fwp_map_items+0x20>
    3b10:	f9000020 	str	x0, [x1]
    3b14:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    3b18:	a9025bf5 	stp	x21, x22, [sp, #32]
    3b1c:	eb01001f 	cmp	x0, x1
    3b20:	540009c8 	b.hi	3c58 <fwp_map_items+0x178>  // b.pmore
    3b24:	91000860 	add	x0, x3, #0x2
    3b28:	d37df000 	lsl	x0, x0, #3
    3b2c:	f140101f 	cmp	x0, #0x4, lsl #12
    3b30:	1a9f87e2 	cset	w2, ls	// ls = plast
    3b34:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    3b38:	911342b4 	add	x20, x21, #0x4d0
    3b3c:	b953a681 	ldr	w1, [x20, #5028]
    3b40:	7100003f 	cmp	w1, #0x0
    3b44:	7a401844 	ccmp	w2, #0x0, #0x4, ne	// ne = any
    3b48:	54000680 	b.eq	3c18 <fwp_map_items+0x138>  // b.none
    3b4c:	91003c01 	add	x1, x0, #0xf
    3b50:	f9001bf7 	str	x23, [sp, #48]
    3b54:	8b411281 	add	x1, x20, x1, lsr #4
    3b58:	397e8021 	ldrb	w1, [x1, #4000]
    3b5c:	910f0022 	add	x2, x1, #0x3c0
    3b60:	8b010421 	add	x1, x1, x1, lsl #1
    3b64:	8b010e83 	add	x3, x20, x1, lsl #3
    3b68:	b8627a97 	ldr	w23, [x20, x2, lsl #2]
    3b6c:	2a1703f6 	mov	w22, w23
    3b70:	f943c064 	ldr	x4, [x3, #1920]
    3b74:	b4000444 	cbz	x4, 3bfc <fwp_map_items+0x11c>
    3b78:	f9400085 	ldr	x5, [x4]
    3b7c:	aa1603e2 	mov	x2, x22
    3b80:	aa0403e0 	mov	x0, x4
    3b84:	52800001 	mov	w1, #0x0                   	// #0
    3b88:	aa2503e5 	mvn	x5, x5
    3b8c:	f903c065 	str	x5, [x3, #1920]
    3b90:	97fff64c 	bl	14c0 <memset@plt>
    3b94:	aa0003e4 	mov	x4, x0
    3b98:	f94a1280 	ldr	x0, [x20, #5152]
    3b9c:	ab160000 	adds	x0, x0, x22
    3ba0:	540005a2 	b.cs	3c54 <fwp_map_items+0x174>  // b.hs, b.nlast
    3ba4:	f94a1681 	ldr	x1, [x20, #5160]
    3ba8:	f90a1280 	str	x0, [x20, #5152]
    3bac:	eb01001f 	cmp	x0, x1
    3bb0:	54000049 	b.ls	3bb8 <fwp_map_items+0xd8>  // b.plast
    3bb4:	f90a1680 	str	x0, [x20, #5160]
    3bb8:	911342b5 	add	x21, x21, #0x4d0
    3bbc:	1e6302e1 	ucvtf	d1, w23
    3bc0:	f9401bf7 	ldr	x23, [sp, #48]
    3bc4:	fd4a1ea0 	ldr	d0, [x21, #5176]
    3bc8:	1e612800 	fadd	d0, d0, d1
    3bcc:	fd0a1ea0 	str	d0, [x21, #5176]
    3bd0:	aa0403e1 	mov	x1, x4
    3bd4:	b40000b3 	cbz	x19, 3be8 <fwp_map_items+0x108>
    3bd8:	f9400662 	ldr	x2, [x19, #8]
    3bdc:	f8008422 	str	x2, [x1], #8
    3be0:	f9400a73 	ldr	x19, [x19, #16]
    3be4:	b5ffffb3 	cbnz	x19, 3bd8 <fwp_map_items+0xf8>
    3be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3bec:	aa0403e0 	mov	x0, x4
    3bf0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3bf4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3bf8:	d65f03c0 	ret
    3bfc:	f943c464 	ldr	x4, [x3, #1928]
    3c00:	b40000a4 	cbz	x4, 3c14 <fwp_map_items+0x134>
    3c04:	f943c861 	ldr	x1, [x3, #1936]
    3c08:	cb040021 	sub	x1, x1, x4
    3c0c:	eb0102df 	cmp	x22, x1
    3c10:	540000c9 	b.ls	3c28 <fwp_map_items+0x148>  // b.plast
    3c14:	f9401bf7 	ldr	x23, [sp, #48]
    3c18:	52800041 	mov	w1, #0x2                   	// #2
    3c1c:	97fffdb5 	bl	32f0 <fwp_heap_alloc_slow>
    3c20:	aa0003e4 	mov	x4, x0
    3c24:	17ffffeb 	b	3bd0 <fwp_map_items+0xf0>
    3c28:	8b160085 	add	x5, x4, x22
    3c2c:	aa1603e2 	mov	x2, x22
    3c30:	aa0403e0 	mov	x0, x4
    3c34:	52800001 	mov	w1, #0x0                   	// #0
    3c38:	f903c465 	str	x5, [x3, #1928]
    3c3c:	17ffffd5 	b	3b90 <fwp_map_items+0xb0>
    3c40:	a9025bf5 	stp	x21, x22, [sp, #32]
    3c44:	52800022 	mov	w2, #0x1                   	// #1
    3c48:	d2800100 	mov	x0, #0x8                   	// #8
    3c4c:	f900003f 	str	xzr, [x1]
    3c50:	17ffffb9 	b	3b34 <fwp_map_items+0x54>
    3c54:	97fff7ef 	bl	1c10 <fwp_heap_oom>
    3c58:	d0000020 	adrp	x0, 9000 <f0+0x2610>
    3c5c:	913be000 	add	x0, x0, #0xef8
    3c60:	f9001bf7 	str	x23, [sp, #48]
    3c64:	97fff92f 	bl	2120 <fwp_trap>
    3c68:	d503201f 	nop
    3c6c:	d503201f 	nop

0000000000003c70 <fwp_caps74>:
    3c70:	34000041 	cbz	w1, 3c78 <fwp_caps74+0x8>
    3c74:	d65f03c0 	ret
    3c78:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3c7c:	91134063 	add	x3, x3, #0x4d0
    3c80:	f949d861 	ldr	x1, [x3, #5040]
    3c84:	f949ec62 	ldr	x2, [x3, #5080]
    3c88:	cb010001 	sub	x1, x0, x1
    3c8c:	eb02403f 	cmp	x1, x2, lsl #16
    3c90:	54ffff22 	b.cs	3c74 <fwp_caps74+0x4>  // b.hs, b.nlast
    3c94:	d350fc22 	lsr	x2, x1, #16
    3c98:	f949fc65 	ldr	x5, [x3, #5112]
    3c9c:	8b020842 	add	x2, x2, x2, lsl #2
    3ca0:	d37df042 	lsl	x2, x2, #3
    3ca4:	8b0200a4 	add	x4, x5, x2
    3ca8:	f9401083 	ldr	x3, [x4, #32]
    3cac:	b4fffe43 	cbz	x3, 3c74 <fwp_caps74+0x4>
    3cb0:	386268a2 	ldrb	w2, [x5, x2]
    3cb4:	7100085f 	cmp	w2, #0x2
    3cb8:	540001c0 	b.eq	3cf0 <fwp_caps74+0x80>  // b.none
    3cbc:	7100045f 	cmp	w2, #0x1
    3cc0:	54fffda1 	b.ne	3c74 <fwp_caps74+0x4>  // b.any
    3cc4:	29430885 	ldp	w5, w2, [x4, #24]
    3cc8:	92403c21 	and	x1, x1, #0xffff
    3ccc:	9b057c21 	mul	x1, x1, x5
    3cd0:	d360fc21 	lsr	x1, x1, #32
    3cd4:	eb02003f 	cmp	x1, x2
    3cd8:	54fffce2 	b.cs	3c74 <fwp_caps74+0x4>  // b.hs, b.nlast
    3cdc:	8b010063 	add	x3, x3, x1
    3ce0:	39400061 	ldrb	w1, [x3]
    3ce4:	7100043f 	cmp	w1, #0x1
    3ce8:	54fffc61 	b.ne	3c74 <fwp_caps74+0x4>  // b.any
    3cec:	17fffcb9 	b	2fd0 <fwp_mem_free>
    3cf0:	72003c3f 	tst	w1, #0xffff
    3cf4:	54ffff60 	b.eq	3ce0 <fwp_caps74+0x70>  // b.none
    3cf8:	d65f03c0 	ret
    3cfc:	d503201f 	nop

0000000000003d00 <fwp_caps32>:
    3d00:	34000041 	cbz	w1, 3d08 <fwp_caps32+0x8>
    3d04:	d65f03c0 	ret
    3d08:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3d0c:	91134063 	add	x3, x3, #0x4d0
    3d10:	f949d861 	ldr	x1, [x3, #5040]
    3d14:	f949ec62 	ldr	x2, [x3, #5080]
    3d18:	cb010001 	sub	x1, x0, x1
    3d1c:	eb02403f 	cmp	x1, x2, lsl #16
    3d20:	54ffff22 	b.cs	3d04 <fwp_caps32+0x4>  // b.hs, b.nlast
    3d24:	d350fc22 	lsr	x2, x1, #16
    3d28:	f949fc65 	ldr	x5, [x3, #5112]
    3d2c:	8b020842 	add	x2, x2, x2, lsl #2
    3d30:	d37df042 	lsl	x2, x2, #3
    3d34:	8b0200a4 	add	x4, x5, x2
    3d38:	f9401083 	ldr	x3, [x4, #32]
    3d3c:	b4fffe43 	cbz	x3, 3d04 <fwp_caps32+0x4>
    3d40:	386268a2 	ldrb	w2, [x5, x2]
    3d44:	7100085f 	cmp	w2, #0x2
    3d48:	540001c0 	b.eq	3d80 <fwp_caps32+0x80>  // b.none
    3d4c:	7100045f 	cmp	w2, #0x1
    3d50:	54fffda1 	b.ne	3d04 <fwp_caps32+0x4>  // b.any
    3d54:	29430885 	ldp	w5, w2, [x4, #24]
    3d58:	92403c21 	and	x1, x1, #0xffff
    3d5c:	9b057c21 	mul	x1, x1, x5
    3d60:	d360fc21 	lsr	x1, x1, #32
    3d64:	eb02003f 	cmp	x1, x2
    3d68:	54fffce2 	b.cs	3d04 <fwp_caps32+0x4>  // b.hs, b.nlast
    3d6c:	8b010063 	add	x3, x3, x1
    3d70:	39400061 	ldrb	w1, [x3]
    3d74:	7100043f 	cmp	w1, #0x1
    3d78:	54fffc61 	b.ne	3d04 <fwp_caps32+0x4>  // b.any
    3d7c:	17fffc95 	b	2fd0 <fwp_mem_free>
    3d80:	72003c3f 	tst	w1, #0xffff
    3d84:	54ffff60 	b.eq	3d70 <fwp_caps32+0x70>  // b.none
    3d88:	d65f03c0 	ret
    3d8c:	d503201f 	nop

0000000000003d90 <fwp_caps69>:
    3d90:	34000041 	cbz	w1, 3d98 <fwp_caps69+0x8>
    3d94:	d65f03c0 	ret
    3d98:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3d9c:	91134063 	add	x3, x3, #0x4d0
    3da0:	f949d861 	ldr	x1, [x3, #5040]
    3da4:	f949ec62 	ldr	x2, [x3, #5080]
    3da8:	cb010001 	sub	x1, x0, x1
    3dac:	eb02403f 	cmp	x1, x2, lsl #16
    3db0:	54ffff22 	b.cs	3d94 <fwp_caps69+0x4>  // b.hs, b.nlast
    3db4:	d350fc22 	lsr	x2, x1, #16
    3db8:	f949fc65 	ldr	x5, [x3, #5112]
    3dbc:	8b020842 	add	x2, x2, x2, lsl #2
    3dc0:	d37df042 	lsl	x2, x2, #3
    3dc4:	8b0200a4 	add	x4, x5, x2
    3dc8:	f9401083 	ldr	x3, [x4, #32]
    3dcc:	b4fffe43 	cbz	x3, 3d94 <fwp_caps69+0x4>
    3dd0:	386268a2 	ldrb	w2, [x5, x2]
    3dd4:	7100085f 	cmp	w2, #0x2
    3dd8:	540001c0 	b.eq	3e10 <fwp_caps69+0x80>  // b.none
    3ddc:	7100045f 	cmp	w2, #0x1
    3de0:	54fffda1 	b.ne	3d94 <fwp_caps69+0x4>  // b.any
    3de4:	29430885 	ldp	w5, w2, [x4, #24]
    3de8:	92403c21 	and	x1, x1, #0xffff
    3dec:	9b057c21 	mul	x1, x1, x5
    3df0:	d360fc21 	lsr	x1, x1, #32
    3df4:	eb02003f 	cmp	x1, x2
    3df8:	54fffce2 	b.cs	3d94 <fwp_caps69+0x4>  // b.hs, b.nlast
    3dfc:	8b010063 	add	x3, x3, x1
    3e00:	39400061 	ldrb	w1, [x3]
    3e04:	7100043f 	cmp	w1, #0x1
    3e08:	54fffc61 	b.ne	3d94 <fwp_caps69+0x4>  // b.any
    3e0c:	17fffc71 	b	2fd0 <fwp_mem_free>
    3e10:	72003c3f 	tst	w1, #0xffff
    3e14:	54ffff60 	b.eq	3e00 <fwp_caps69+0x70>  // b.none
    3e18:	d65f03c0 	ret
    3e1c:	d503201f 	nop

0000000000003e20 <fwp_caps45>:
    3e20:	34000041 	cbz	w1, 3e28 <fwp_caps45+0x8>
    3e24:	d65f03c0 	ret
    3e28:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3e2c:	91134063 	add	x3, x3, #0x4d0
    3e30:	f949d861 	ldr	x1, [x3, #5040]
    3e34:	f949ec62 	ldr	x2, [x3, #5080]
    3e38:	cb010001 	sub	x1, x0, x1
    3e3c:	eb02403f 	cmp	x1, x2, lsl #16
    3e40:	54ffff22 	b.cs	3e24 <fwp_caps45+0x4>  // b.hs, b.nlast
    3e44:	d350fc22 	lsr	x2, x1, #16
    3e48:	f949fc65 	ldr	x5, [x3, #5112]
    3e4c:	8b020842 	add	x2, x2, x2, lsl #2
    3e50:	d37df042 	lsl	x2, x2, #3
    3e54:	8b0200a4 	add	x4, x5, x2
    3e58:	f9401083 	ldr	x3, [x4, #32]
    3e5c:	b4fffe43 	cbz	x3, 3e24 <fwp_caps45+0x4>
    3e60:	386268a2 	ldrb	w2, [x5, x2]
    3e64:	7100085f 	cmp	w2, #0x2
    3e68:	540001c0 	b.eq	3ea0 <fwp_caps45+0x80>  // b.none
    3e6c:	7100045f 	cmp	w2, #0x1
    3e70:	54fffda1 	b.ne	3e24 <fwp_caps45+0x4>  // b.any
    3e74:	29430885 	ldp	w5, w2, [x4, #24]
    3e78:	92403c21 	and	x1, x1, #0xffff
    3e7c:	9b057c21 	mul	x1, x1, x5
    3e80:	d360fc21 	lsr	x1, x1, #32
    3e84:	eb02003f 	cmp	x1, x2
    3e88:	54fffce2 	b.cs	3e24 <fwp_caps45+0x4>  // b.hs, b.nlast
    3e8c:	8b010063 	add	x3, x3, x1
    3e90:	39400061 	ldrb	w1, [x3]
    3e94:	7100043f 	cmp	w1, #0x1
    3e98:	54fffc61 	b.ne	3e24 <fwp_caps45+0x4>  // b.any
    3e9c:	17fffc4d 	b	2fd0 <fwp_mem_free>
    3ea0:	72003c3f 	tst	w1, #0xffff
    3ea4:	54ffff60 	b.eq	3e90 <fwp_caps45+0x70>  // b.none
    3ea8:	d65f03c0 	ret
    3eac:	d503201f 	nop

0000000000003eb0 <fwp_heap_alloc>:
    3eb0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3eb4:	f140101f 	cmp	x0, #0x4, lsl #12
    3eb8:	910003fd 	mov	x29, sp
    3ebc:	a90153f3 	stp	x19, x20, [sp, #16]
    3ec0:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xd10>
    3ec4:	91134293 	add	x19, x20, #0x4d0
    3ec8:	b953a662 	ldr	w2, [x19, #5028]
    3ecc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3ed0:	54000640 	b.eq	3f98 <fwp_heap_alloc+0xe8>  // b.none
    3ed4:	91003c03 	add	x3, x0, #0xf
    3ed8:	a9025bf5 	stp	x21, x22, [sp, #32]
    3edc:	937c7c22 	sbfiz	x2, x1, #4, #32
    3ee0:	8b431263 	add	x3, x19, x3, lsr #4
    3ee4:	cb21c042 	sub	x2, x2, w1, sxtw
    3ee8:	d37ae442 	lsl	x2, x2, #6
    3eec:	397e8063 	ldrb	w3, [x3, #4000]
    3ef0:	910f0064 	add	x4, x3, #0x3c0
    3ef4:	8b030463 	add	x3, x3, x3, lsl #1
    3ef8:	8b030c43 	add	x3, x2, x3, lsl #3
    3efc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    3f00:	2a1603f5 	mov	w21, w22
    3f04:	f8636a64 	ldr	x4, [x19, x3]
    3f08:	b4000384 	cbz	x4, 3f78 <fwp_heap_alloc+0xc8>
    3f0c:	f9400085 	ldr	x5, [x4]
    3f10:	7100043f 	cmp	w1, #0x1
    3f14:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    3f18:	aa0403e0 	mov	x0, x4
    3f1c:	aa2503e5 	mvn	x5, x5
    3f20:	52800001 	mov	w1, #0x0                   	// #0
    3f24:	f8236a65 	str	x5, [x19, x3]
    3f28:	97fff566 	bl	14c0 <memset@plt>
    3f2c:	aa0003e4 	mov	x4, x0
    3f30:	f94a1260 	ldr	x0, [x19, #5152]
    3f34:	ab150000 	adds	x0, x0, x21
    3f38:	54000442 	b.cs	3fc0 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    3f3c:	f94a1661 	ldr	x1, [x19, #5160]
    3f40:	f90a1260 	str	x0, [x19, #5152]
    3f44:	eb01001f 	cmp	x0, x1
    3f48:	54000049 	b.ls	3f50 <fwp_heap_alloc+0xa0>  // b.plast
    3f4c:	f90a1660 	str	x0, [x19, #5160]
    3f50:	91134294 	add	x20, x20, #0x4d0
    3f54:	1e6302c1 	ucvtf	d1, w22
    3f58:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f5c:	aa0403e0 	mov	x0, x4
    3f60:	fd4a1e80 	ldr	d0, [x20, #5176]
    3f64:	1e612800 	fadd	d0, d0, d1
    3f68:	fd0a1e80 	str	d0, [x20, #5176]
    3f6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f70:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f74:	d65f03c0 	ret
    3f78:	8b030263 	add	x3, x19, x3
    3f7c:	f9400464 	ldr	x4, [x3, #8]
    3f80:	b40000a4 	cbz	x4, 3f94 <fwp_heap_alloc+0xe4>
    3f84:	f9400862 	ldr	x2, [x3, #16]
    3f88:	cb040042 	sub	x2, x2, x4
    3f8c:	eb15005f 	cmp	x2, x21
    3f90:	540000a2 	b.cs	3fa4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    3f94:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f98:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f9c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fa0:	17fffcd4 	b	32f0 <fwp_heap_alloc_slow>
    3fa4:	7100043f 	cmp	w1, #0x1
    3fa8:	8b150085 	add	x5, x4, x21
    3fac:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    3fb0:	52800001 	mov	w1, #0x0                   	// #0
    3fb4:	aa0403e0 	mov	x0, x4
    3fb8:	f9000465 	str	x5, [x3, #8]
    3fbc:	17ffffdb 	b	3f28 <fwp_heap_alloc+0x78>
    3fc0:	97fff714 	bl	1c10 <fwp_heap_oom>

0000000000003fc4 <fwp_data.part.0.constprop.0>:
    3fc4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3fc8:	910003fd 	mov	x29, sp
    3fcc:	a90153f3 	stp	x19, x20, [sp, #16]
    3fd0:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xd10>
    3fd4:	91134283 	add	x3, x20, #0x4d0
    3fd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    3fdc:	aa0103f5 	mov	x21, x1
    3fe0:	b953a461 	ldr	w1, [x3, #5028]
    3fe4:	a90363f7 	stp	x23, x24, [sp, #48]
    3fe8:	2a0003f8 	mov	w24, w0
    3fec:	34000701 	cbz	w1, 40cc <fwp_data.part.0.constprop.0+0x108>
    3ff0:	397e8862 	ldrb	w2, [x3, #4002]
    3ff4:	910f0040 	add	x0, x2, #0x3c0
    3ff8:	8b020442 	add	x2, x2, x2, lsl #1
    3ffc:	d37df042 	lsl	x2, x2, #3
    4000:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4004:	2a1703f6 	mov	w22, w23
    4008:	f8626873 	ldr	x19, [x3, x2]
    400c:	b40004d3 	cbz	x19, 40a4 <fwp_data.part.0.constprop.0+0xe0>
    4010:	f9400260 	ldr	x0, [x19]
    4014:	aa2003e0 	mvn	x0, x0
    4018:	f8226860 	str	x0, [x3, x2]
    401c:	f10062df 	cmp	x22, #0x18
    4020:	540000e9 	b.ls	403c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4024:	d10066c2 	sub	x2, x22, #0x19
    4028:	91006260 	add	x0, x19, #0x18
    402c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4030:	52800001 	mov	w1, #0x0                   	// #0
    4034:	91002042 	add	x2, x2, #0x8
    4038:	97fff522 	bl	14c0 <memset@plt>
    403c:	91134282 	add	x2, x20, #0x4d0
    4040:	f94a1041 	ldr	x1, [x2, #5152]
    4044:	ab160021 	adds	x1, x1, x22
    4048:	540004c2 	b.cs	40e0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    404c:	f94a1440 	ldr	x0, [x2, #5160]
    4050:	f90a1041 	str	x1, [x2, #5152]
    4054:	eb00003f 	cmp	x1, x0
    4058:	54000049 	b.ls	4060 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    405c:	f90a1441 	str	x1, [x2, #5160]
    4060:	91134294 	add	x20, x20, #0x4d0
    4064:	1e6302e1 	ucvtf	d1, w23
    4068:	fd4a1e80 	ldr	d0, [x20, #5176]
    406c:	1e612800 	fadd	d0, d0, d1
    4070:	fd0a1e80 	str	d0, [x20, #5176]
    4074:	52800041 	mov	w1, #0x2                   	// #2
    4078:	29000678 	stp	w24, w1, [x19]
    407c:	aa1303e0 	mov	x0, x19
    4080:	f94002a1 	ldr	x1, [x21]
    4084:	f9000661 	str	x1, [x19, #8]
    4088:	f94006a1 	ldr	x1, [x21, #8]
    408c:	f9000a61 	str	x1, [x19, #16]
    4090:	a94153f3 	ldp	x19, x20, [sp, #16]
    4094:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4098:	a94363f7 	ldp	x23, x24, [sp, #48]
    409c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    40a0:	d65f03c0 	ret
    40a4:	8b020063 	add	x3, x3, x2
    40a8:	f9400473 	ldr	x19, [x3, #8]
    40ac:	b4000113 	cbz	x19, 40cc <fwp_data.part.0.constprop.0+0x108>
    40b0:	f9400860 	ldr	x0, [x3, #16]
    40b4:	cb130000 	sub	x0, x0, x19
    40b8:	eb0002df 	cmp	x22, x0
    40bc:	54000088 	b.hi	40cc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    40c0:	8b160260 	add	x0, x19, x22
    40c4:	f9000460 	str	x0, [x3, #8]
    40c8:	17ffffd5 	b	401c <fwp_data.part.0.constprop.0+0x58>
    40cc:	52800001 	mov	w1, #0x0                   	// #0
    40d0:	d2800300 	mov	x0, #0x18                  	// #24
    40d4:	97ffff77 	bl	3eb0 <fwp_heap_alloc>
    40d8:	aa0003f3 	mov	x19, x0
    40dc:	17ffffe6 	b	4074 <fwp_data.part.0.constprop.0+0xb0>
    40e0:	97fff6cc 	bl	1c10 <fwp_heap_oom>

00000000000040e4 <fwp_map_finish_protected.isra.0>:
    40e4:	d10183ff 	sub	sp, sp, #0x60
    40e8:	a9027bfd 	stp	x29, x30, [sp, #32]
    40ec:	910083fd 	add	x29, sp, #0x20
    40f0:	a90563f7 	stp	x23, x24, [sp, #80]
    40f4:	aa0003f7 	mov	x23, x0
    40f8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    40fc:	f947f400 	ldr	x0, [x0, #4072]
    4100:	a9045bf5 	stp	x21, x22, [sp, #64]
    4104:	a940d6e2 	ldp	x2, x21, [x23, #8]
    4108:	f9400001 	ldr	x1, [x0]
    410c:	f9000fe1 	str	x1, [sp, #24]
    4110:	d2800001 	mov	x1, #0x0                   	// #0
    4114:	b4000602 	cbz	x2, 41d4 <fwp_map_finish_protected.isra.0+0xf0>
    4118:	b0000178 	adrp	x24, 31000 <fwp_root_context+0xd10>
    411c:	91134318 	add	x24, x24, #0x4d0
    4120:	a90353f3 	stp	x19, x20, [sp, #48]
    4124:	910023f3 	add	x19, sp, #0x8
    4128:	52800034 	mov	w20, #0x1                   	// #1
    412c:	d503201f 	nop
    4130:	f94002e3 	ldr	x3, [x23]
    4134:	aa1303e1 	mov	x1, x19
    4138:	52800020 	mov	w0, #0x1                   	// #1
    413c:	8b020c62 	add	x2, x3, x2, lsl #3
    4140:	f85f8042 	ldur	x2, [x2, #-8]
    4144:	a900d7e2 	stp	x2, x21, [sp, #8]
    4148:	97ffff9f 	bl	3fc4 <fwp_data.part.0.constprop.0>
    414c:	aa0003f5 	mov	x21, x0
    4150:	f949db01 	ldr	x1, [x24, #5040]
    4154:	f949ef02 	ldr	x2, [x24, #5080]
    4158:	cb010001 	sub	x1, x0, x1
    415c:	eb02403f 	cmp	x1, x2, lsl #16
    4160:	54000302 	b.cs	41c0 <fwp_map_finish_protected.isra.0+0xdc>  // b.hs, b.nlast
    4164:	d350fc22 	lsr	x2, x1, #16
    4168:	f949ff04 	ldr	x4, [x24, #5112]
    416c:	8b020842 	add	x2, x2, x2, lsl #2
    4170:	d37df042 	lsl	x2, x2, #3
    4174:	8b020083 	add	x3, x4, x2
    4178:	f9401076 	ldr	x22, [x3, #32]
    417c:	b4000236 	cbz	x22, 41c0 <fwp_map_finish_protected.isra.0+0xdc>
    4180:	38626882 	ldrb	w2, [x4, x2]
    4184:	7100085f 	cmp	w2, #0x2
    4188:	540004a0 	b.eq	421c <fwp_map_finish_protected.isra.0+0x138>  // b.none
    418c:	7100045f 	cmp	w2, #0x1
    4190:	54000181 	b.ne	41c0 <fwp_map_finish_protected.isra.0+0xdc>  // b.any
    4194:	29430062 	ldp	w2, w0, [x3, #24]
    4198:	92403c21 	and	x1, x1, #0xffff
    419c:	9b027c21 	mul	x1, x1, x2
    41a0:	d360fc21 	lsr	x1, x1, #32
    41a4:	eb00003f 	cmp	x1, x0
    41a8:	540000c2 	b.cs	41c0 <fwp_map_finish_protected.isra.0+0xdc>  // b.hs, b.nlast
    41ac:	8b0102d6 	add	x22, x22, x1
    41b0:	394002c0 	ldrb	w0, [x22]
    41b4:	7103fc1f 	cmp	w0, #0xff
    41b8:	540002c0 	b.eq	4210 <fwp_map_finish_protected.isra.0+0x12c>  // b.none
    41bc:	390002d4 	strb	w20, [x22]
    41c0:	f94006e2 	ldr	x2, [x23, #8]
    41c4:	d1000442 	sub	x2, x2, #0x1
    41c8:	a900d6e2 	stp	x2, x21, [x23, #8]
    41cc:	b5fffb22 	cbnz	x2, 4130 <fwp_map_finish_protected.isra.0+0x4c>
    41d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    41d4:	f94002e0 	ldr	x0, [x23]
    41d8:	97fffb7e 	bl	2fd0 <fwp_mem_free>
    41dc:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    41e0:	f947f400 	ldr	x0, [x0, #4072]
    41e4:	f9400fe2 	ldr	x2, [sp, #24]
    41e8:	f9400001 	ldr	x1, [x0]
    41ec:	eb010042 	subs	x2, x2, x1
    41f0:	d2800001 	mov	x1, #0x0                   	// #0
    41f4:	540001a1 	b.ne	4228 <fwp_map_finish_protected.isra.0+0x144>  // b.any
    41f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    41fc:	aa1503e0 	mov	x0, x21
    4200:	a9445bf5 	ldp	x21, x22, [sp, #64]
    4204:	a94563f7 	ldp	x23, x24, [sp, #80]
    4208:	910183ff 	add	sp, sp, #0x60
    420c:	d65f03c0 	ret
    4210:	aa1603e0 	mov	x0, x22
    4214:	97fffacf 	bl	2d50 <fwp_rc_forget_slot>
    4218:	17ffffe9 	b	41bc <fwp_map_finish_protected.isra.0+0xd8>
    421c:	72003c3f 	tst	w1, #0xffff
    4220:	54fffd01 	b.ne	41c0 <fwp_map_finish_protected.isra.0+0xdc>  // b.any
    4224:	17ffffe3 	b	41b0 <fwp_map_finish_protected.isra.0+0xcc>
    4228:	a90353f3 	stp	x19, x20, [sp, #48]
    422c:	97fff4b1 	bl	14f0 <__stack_chk_fail@plt>

0000000000004230 <fwp_drop4>:
    4230:	b0000165 	adrp	x5, 31000 <fwp_root_context+0xd10>
    4234:	911340a3 	add	x3, x5, #0x4d0
    4238:	f949d861 	ldr	x1, [x3, #5040]
    423c:	f949ec62 	ldr	x2, [x3, #5080]
    4240:	cb010001 	sub	x1, x0, x1
    4244:	eb02403f 	cmp	x1, x2, lsl #16
    4248:	54000542 	b.cs	42f0 <fwp_drop4+0xc0>  // b.hs, b.nlast
    424c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4250:	d350fc22 	lsr	x2, x1, #16
    4254:	910003fd 	mov	x29, sp
    4258:	8b020842 	add	x2, x2, x2, lsl #2
    425c:	f949fc64 	ldr	x4, [x3, #5112]
    4260:	d37df042 	lsl	x2, x2, #3
    4264:	f9000bf3 	str	x19, [sp, #16]
    4268:	8b020083 	add	x3, x4, x2
    426c:	f9401073 	ldr	x19, [x3, #32]
    4270:	b40002b3 	cbz	x19, 42c4 <fwp_drop4+0x94>
    4274:	38626882 	ldrb	w2, [x4, x2]
    4278:	7100085f 	cmp	w2, #0x2
    427c:	540002a0 	b.eq	42d0 <fwp_drop4+0xa0>  // b.none
    4280:	7100045f 	cmp	w2, #0x1
    4284:	54000201 	b.ne	42c4 <fwp_drop4+0x94>  // b.any
    4288:	29430864 	ldp	w4, w2, [x3, #24]
    428c:	92403c21 	and	x1, x1, #0xffff
    4290:	9b047c21 	mul	x1, x1, x4
    4294:	d360fc21 	lsr	x1, x1, #32
    4298:	eb02003f 	cmp	x1, x2
    429c:	54000142 	b.cs	42c4 <fwp_drop4+0x94>  // b.hs, b.nlast
    42a0:	8b010273 	add	x19, x19, x1
    42a4:	39400261 	ldrb	w1, [x19]
    42a8:	340000e1 	cbz	w1, 42c4 <fwp_drop4+0x94>
    42ac:	7100043f 	cmp	w1, #0x1
    42b0:	540001a0 	b.eq	42e4 <fwp_drop4+0xb4>  // b.none
    42b4:	7103fc3f 	cmp	w1, #0xff
    42b8:	540001e0 	b.eq	42f4 <fwp_drop4+0xc4>  // b.none
    42bc:	51000421 	sub	w1, w1, #0x1
    42c0:	39000261 	strb	w1, [x19]
    42c4:	f9400bf3 	ldr	x19, [sp, #16]
    42c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    42cc:	d65f03c0 	ret
    42d0:	72003c3f 	tst	w1, #0xffff
    42d4:	54fffe80 	b.eq	42a4 <fwp_drop4+0x74>  // b.none
    42d8:	f9400bf3 	ldr	x19, [sp, #16]
    42dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    42e0:	d65f03c0 	ret
    42e4:	f9400bf3 	ldr	x19, [sp, #16]
    42e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    42ec:	17fffb39 	b	2fd0 <fwp_mem_free>
    42f0:	d65f03c0 	ret
    42f4:	ca534660 	eor	x0, x19, x19, lsr #17
    42f8:	911340a5 	add	x5, x5, #0x4d0
    42fc:	ca402400 	eor	x0, x0, x0, lsr #9
    4300:	8b200ca0 	add	x0, x5, w0, uxtb #3
    4304:	f94a2400 	ldr	x0, [x0, #5192]
    4308:	b5000080 	cbnz	x0, 4318 <fwp_drop4+0xe8>
    430c:	14000010 	b	434c <fwp_drop4+0x11c>
    4310:	f9400800 	ldr	x0, [x0, #16]
    4314:	b40001c0 	cbz	x0, 434c <fwp_drop4+0x11c>
    4318:	f9400001 	ldr	x1, [x0]
    431c:	eb13003f 	cmp	x1, x19
    4320:	54ffff81 	b.ne	4310 <fwp_drop4+0xe0>  // b.any
    4324:	f9400401 	ldr	x1, [x0, #8]
    4328:	d1000421 	sub	x1, x1, #0x1
    432c:	f9000401 	str	x1, [x0, #8]
    4330:	f103f83f 	cmp	x1, #0xfe
    4334:	54fffc81 	b.ne	42c4 <fwp_drop4+0x94>  // b.any
    4338:	aa1303e0 	mov	x0, x19
    433c:	97fffa85 	bl	2d50 <fwp_rc_forget_slot>
    4340:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4344:	39000260 	strb	w0, [x19]
    4348:	17ffffdf 	b	42c4 <fwp_drop4+0x94>
    434c:	b0000020 	adrp	x0, 9000 <f0+0x2610>
    4350:	9139c000 	add	x0, x0, #0xe70
    4354:	97fff773 	bl	2120 <fwp_trap>
    4358:	d503201f 	nop
    435c:	d503201f 	nop

0000000000004360 <fwp_owned_entry50>:
    4360:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4364:	910003fd 	mov	x29, sp
    4368:	f9400000 	ldr	x0, [x0]
    436c:	f9000bf3 	str	x19, [sp, #16]
    4370:	f9400813 	ldr	x19, [x0, #16]
    4374:	97ffffaf 	bl	4230 <fwp_drop4>
    4378:	aa1303e0 	mov	x0, x19
    437c:	f9400bf3 	ldr	x19, [sp, #16]
    4380:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4384:	d65f03c0 	ret
    4388:	d503201f 	nop
    438c:	d503201f 	nop

0000000000004390 <fwp_owned_entry47>:
    4390:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4394:	910003fd 	mov	x29, sp
    4398:	f9400000 	ldr	x0, [x0]
    439c:	f9000bf3 	str	x19, [sp, #16]
    43a0:	f9400413 	ldr	x19, [x0, #8]
    43a4:	97ffffa3 	bl	4230 <fwp_drop4>
    43a8:	aa1303e0 	mov	x0, x19
    43ac:	f9400bf3 	ldr	x19, [sp, #16]
    43b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43b4:	d65f03c0 	ret
    43b8:	d503201f 	nop
    43bc:	d503201f 	nop

00000000000043c0 <fwp_arg_drop47>:
    43c0:	7100003f 	cmp	w1, #0x0
    43c4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    43c8:	54000041 	b.ne	43d0 <fwp_arg_drop47+0x10>  // b.any
    43cc:	d65f03c0 	ret
    43d0:	f9400000 	ldr	x0, [x0]
    43d4:	17ffff97 	b	4230 <fwp_drop4>
    43d8:	d503201f 	nop
    43dc:	d503201f 	nop

00000000000043e0 <e50>:
    43e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    43e4:	910003fd 	mov	x29, sp
    43e8:	a90153f3 	stp	x19, x20, [sp, #16]
    43ec:	f9400013 	ldr	x19, [x0]
    43f0:	aa1303e0 	mov	x0, x19
    43f4:	97fffc17 	bl	3450 <fwp_rc_share>
    43f8:	f9400a74 	ldr	x20, [x19, #16]
    43fc:	aa1303e0 	mov	x0, x19
    4400:	97ffff8c 	bl	4230 <fwp_drop4>
    4404:	aa1403e0 	mov	x0, x20
    4408:	97fffc12 	bl	3450 <fwp_rc_share>
    440c:	aa1403e0 	mov	x0, x20
    4410:	a94153f3 	ldp	x19, x20, [sp, #16]
    4414:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4418:	d65f03c0 	ret
    441c:	d503201f 	nop

0000000000004420 <e47>:
    4420:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4424:	910003fd 	mov	x29, sp
    4428:	a90153f3 	stp	x19, x20, [sp, #16]
    442c:	f9400013 	ldr	x19, [x0]
    4430:	aa1303e0 	mov	x0, x19
    4434:	97fffc07 	bl	3450 <fwp_rc_share>
    4438:	f9400674 	ldr	x20, [x19, #8]
    443c:	aa1303e0 	mov	x0, x19
    4440:	97ffff7c 	bl	4230 <fwp_drop4>
    4444:	aa1403e0 	mov	x0, x20
    4448:	97fffc02 	bl	3450 <fwp_rc_share>
    444c:	aa1403e0 	mov	x0, x20
    4450:	a94153f3 	ldp	x19, x20, [sp, #16]
    4454:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4458:	d65f03c0 	ret
    445c:	d503201f 	nop

0000000000004460 <fwp_arg_drop50>:
    4460:	7100003f 	cmp	w1, #0x0
    4464:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4468:	54000041 	b.ne	4470 <fwp_arg_drop50+0x10>  // b.any
    446c:	d65f03c0 	ret
    4470:	f9400000 	ldr	x0, [x0]
    4474:	17ffff6f 	b	4230 <fwp_drop4>
    4478:	d503201f 	nop
    447c:	d503201f 	nop

0000000000004480 <fwp_args50>:
    4480:	7100003f 	cmp	w1, #0x0
    4484:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4488:	54000041 	b.ne	4490 <fwp_args50+0x10>  // b.any
    448c:	d65f03c0 	ret
    4490:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    4494:	91134042 	add	x2, x2, #0x4d0
    4498:	f9400001 	ldr	x1, [x0]
    449c:	f949d843 	ldr	x3, [x2, #5040]
    44a0:	f949ec40 	ldr	x0, [x2, #5080]
    44a4:	cb030021 	sub	x1, x1, x3
    44a8:	eb00403f 	cmp	x1, x0, lsl #16
    44ac:	54ffff02 	b.cs	448c <fwp_args50+0xc>  // b.hs, b.nlast
    44b0:	d350fc20 	lsr	x0, x1, #16
    44b4:	f949fc44 	ldr	x4, [x2, #5112]
    44b8:	8b000800 	add	x0, x0, x0, lsl #2
    44bc:	d37df002 	lsl	x2, x0, #3
    44c0:	8b020083 	add	x3, x4, x2
    44c4:	f9401060 	ldr	x0, [x3, #32]
    44c8:	b4fffe20 	cbz	x0, 448c <fwp_args50+0xc>
    44cc:	38626882 	ldrb	w2, [x4, x2]
    44d0:	7100085f 	cmp	w2, #0x2
    44d4:	54000220 	b.eq	4518 <fwp_args50+0x98>  // b.none
    44d8:	7100045f 	cmp	w2, #0x1
    44dc:	54fffd81 	b.ne	448c <fwp_args50+0xc>  // b.any
    44e0:	29430864 	ldp	w4, w2, [x3, #24]
    44e4:	92403c21 	and	x1, x1, #0xffff
    44e8:	9b047c21 	mul	x1, x1, x4
    44ec:	d360fc21 	lsr	x1, x1, #32
    44f0:	eb02003f 	cmp	x1, x2
    44f4:	54fffcc2 	b.cs	448c <fwp_args50+0xc>  // b.hs, b.nlast
    44f8:	8b010000 	add	x0, x0, x1
    44fc:	39400001 	ldrb	w1, [x0]
    4500:	34fffc61 	cbz	w1, 448c <fwp_args50+0xc>
    4504:	7103f43f 	cmp	w1, #0xfd
    4508:	540000e8 	b.hi	4524 <fwp_args50+0xa4>  // b.pmore
    450c:	11000421 	add	w1, w1, #0x1
    4510:	39000001 	strb	w1, [x0]
    4514:	d65f03c0 	ret
    4518:	72003c3f 	tst	w1, #0xffff
    451c:	54ffff00 	b.eq	44fc <fwp_args50+0x7c>  // b.none
    4520:	d65f03c0 	ret
    4524:	17fff9c4 	b	2c34 <fwp_rc_wide_dup>
    4528:	d503201f 	nop
    452c:	d503201f 	nop

0000000000004530 <fwp_args47>:
    4530:	7100003f 	cmp	w1, #0x0
    4534:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4538:	54000041 	b.ne	4540 <fwp_args47+0x10>  // b.any
    453c:	d65f03c0 	ret
    4540:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    4544:	91134042 	add	x2, x2, #0x4d0
    4548:	f9400001 	ldr	x1, [x0]
    454c:	f949d843 	ldr	x3, [x2, #5040]
    4550:	f949ec40 	ldr	x0, [x2, #5080]
    4554:	cb030021 	sub	x1, x1, x3
    4558:	eb00403f 	cmp	x1, x0, lsl #16
    455c:	54ffff02 	b.cs	453c <fwp_args47+0xc>  // b.hs, b.nlast
    4560:	d350fc20 	lsr	x0, x1, #16
    4564:	f949fc44 	ldr	x4, [x2, #5112]
    4568:	8b000800 	add	x0, x0, x0, lsl #2
    456c:	d37df002 	lsl	x2, x0, #3
    4570:	8b020083 	add	x3, x4, x2
    4574:	f9401060 	ldr	x0, [x3, #32]
    4578:	b4fffe20 	cbz	x0, 453c <fwp_args47+0xc>
    457c:	38626882 	ldrb	w2, [x4, x2]
    4580:	7100085f 	cmp	w2, #0x2
    4584:	54000220 	b.eq	45c8 <fwp_args47+0x98>  // b.none
    4588:	7100045f 	cmp	w2, #0x1
    458c:	54fffd81 	b.ne	453c <fwp_args47+0xc>  // b.any
    4590:	29430864 	ldp	w4, w2, [x3, #24]
    4594:	92403c21 	and	x1, x1, #0xffff
    4598:	9b047c21 	mul	x1, x1, x4
    459c:	d360fc21 	lsr	x1, x1, #32
    45a0:	eb02003f 	cmp	x1, x2
    45a4:	54fffcc2 	b.cs	453c <fwp_args47+0xc>  // b.hs, b.nlast
    45a8:	8b010000 	add	x0, x0, x1
    45ac:	39400001 	ldrb	w1, [x0]
    45b0:	34fffc61 	cbz	w1, 453c <fwp_args47+0xc>
    45b4:	7103f43f 	cmp	w1, #0xfd
    45b8:	540000e8 	b.hi	45d4 <fwp_args47+0xa4>  // b.pmore
    45bc:	11000421 	add	w1, w1, #0x1
    45c0:	39000001 	strb	w1, [x0]
    45c4:	d65f03c0 	ret
    45c8:	72003c3f 	tst	w1, #0xffff
    45cc:	54ffff00 	b.eq	45ac <fwp_args47+0x7c>  // b.none
    45d0:	d65f03c0 	ret
    45d4:	17fff998 	b	2c34 <fwp_rc_wide_dup>
    45d8:	d503201f 	nop
    45dc:	d503201f 	nop

00000000000045e0 <fwp_caps47>:
    45e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    45e4:	910003fd 	mov	x29, sp
    45e8:	f9000bf3 	str	x19, [sp, #16]
    45ec:	aa0003f3 	mov	x19, x0
    45f0:	b9400400 	ldr	w0, [x0, #4]
    45f4:	340004a0 	cbz	w0, 4688 <fwp_caps47+0xa8>
    45f8:	f9400660 	ldr	x0, [x19, #8]
    45fc:	350004e1 	cbnz	w1, 4698 <fwp_caps47+0xb8>
    4600:	97ffff0c 	bl	4230 <fwp_drop4>
    4604:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    4608:	91134042 	add	x2, x2, #0x4d0
    460c:	f949d840 	ldr	x0, [x2, #5040]
    4610:	f949ec41 	ldr	x1, [x2, #5080]
    4614:	cb000260 	sub	x0, x19, x0
    4618:	eb01401f 	cmp	x0, x1, lsl #16
    461c:	54000382 	b.cs	468c <fwp_caps47+0xac>  // b.hs, b.nlast
    4620:	d350fc01 	lsr	x1, x0, #16
    4624:	f949fc44 	ldr	x4, [x2, #5112]
    4628:	8b010821 	add	x1, x1, x1, lsl #2
    462c:	d37df021 	lsl	x1, x1, #3
    4630:	8b010083 	add	x3, x4, x1
    4634:	f9401062 	ldr	x2, [x3, #32]
    4638:	b40002a2 	cbz	x2, 468c <fwp_caps47+0xac>
    463c:	38616881 	ldrb	w1, [x4, x1]
    4640:	7100083f 	cmp	w1, #0x2
    4644:	540006c0 	b.eq	471c <fwp_caps47+0x13c>  // b.none
    4648:	7100043f 	cmp	w1, #0x1
    464c:	54000201 	b.ne	468c <fwp_caps47+0xac>  // b.any
    4650:	29430464 	ldp	w4, w1, [x3, #24]
    4654:	92403c00 	and	x0, x0, #0xffff
    4658:	9b047c00 	mul	x0, x0, x4
    465c:	d360fc00 	lsr	x0, x0, #32
    4660:	eb01001f 	cmp	x0, x1
    4664:	54000142 	b.cs	468c <fwp_caps47+0xac>  // b.hs, b.nlast
    4668:	8b000042 	add	x2, x2, x0
    466c:	39400040 	ldrb	w0, [x2]
    4670:	7100041f 	cmp	w0, #0x1
    4674:	540000c1 	b.ne	468c <fwp_caps47+0xac>  // b.any
    4678:	aa1303e0 	mov	x0, x19
    467c:	f9400bf3 	ldr	x19, [sp, #16]
    4680:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4684:	17fffa53 	b	2fd0 <fwp_mem_free>
    4688:	34fffbe1 	cbz	w1, 4604 <fwp_caps47+0x24>
    468c:	f9400bf3 	ldr	x19, [sp, #16]
    4690:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4694:	d65f03c0 	ret
    4698:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    469c:	91134042 	add	x2, x2, #0x4d0
    46a0:	f949d843 	ldr	x3, [x2, #5040]
    46a4:	f949ec41 	ldr	x1, [x2, #5080]
    46a8:	cb030000 	sub	x0, x0, x3
    46ac:	eb01401f 	cmp	x0, x1, lsl #16
    46b0:	54fffee2 	b.cs	468c <fwp_caps47+0xac>  // b.hs, b.nlast
    46b4:	d350fc01 	lsr	x1, x0, #16
    46b8:	f949fc44 	ldr	x4, [x2, #5112]
    46bc:	8b010821 	add	x1, x1, x1, lsl #2
    46c0:	d37df021 	lsl	x1, x1, #3
    46c4:	8b010083 	add	x3, x4, x1
    46c8:	f9401062 	ldr	x2, [x3, #32]
    46cc:	b4fffe02 	cbz	x2, 468c <fwp_caps47+0xac>
    46d0:	38616881 	ldrb	w1, [x4, x1]
    46d4:	7100083f 	cmp	w1, #0x2
    46d8:	54000280 	b.eq	4728 <fwp_caps47+0x148>  // b.none
    46dc:	7100043f 	cmp	w1, #0x1
    46e0:	54fffd61 	b.ne	468c <fwp_caps47+0xac>  // b.any
    46e4:	92403c01 	and	x1, x0, #0xffff
    46e8:	29430064 	ldp	w4, w0, [x3, #24]
    46ec:	9b047c21 	mul	x1, x1, x4
    46f0:	d360fc21 	lsr	x1, x1, #32
    46f4:	eb00003f 	cmp	x1, x0
    46f8:	54fffca2 	b.cs	468c <fwp_caps47+0xac>  // b.hs, b.nlast
    46fc:	8b010042 	add	x2, x2, x1
    4700:	39400040 	ldrb	w0, [x2]
    4704:	34fffc40 	cbz	w0, 468c <fwp_caps47+0xac>
    4708:	7103f41f 	cmp	w0, #0xfd
    470c:	54000148 	b.hi	4734 <fwp_caps47+0x154>  // b.pmore
    4710:	11000400 	add	w0, w0, #0x1
    4714:	39000040 	strb	w0, [x2]
    4718:	17ffffdd 	b	468c <fwp_caps47+0xac>
    471c:	72003c1f 	tst	w0, #0xffff
    4720:	54fffb61 	b.ne	468c <fwp_caps47+0xac>  // b.any
    4724:	17ffffd2 	b	466c <fwp_caps47+0x8c>
    4728:	72003c1f 	tst	w0, #0xffff
    472c:	54fffb01 	b.ne	468c <fwp_caps47+0xac>  // b.any
    4730:	17fffff4 	b	4700 <fwp_caps47+0x120>
    4734:	f9400bf3 	ldr	x19, [sp, #16]
    4738:	aa0203e0 	mov	x0, x2
    473c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4740:	17fff93d 	b	2c34 <fwp_rc_wide_dup>

0000000000004744 <fwp_caps50>:
    4744:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4748:	910003fd 	mov	x29, sp
    474c:	f9000bf3 	str	x19, [sp, #16]
    4750:	aa0003f3 	mov	x19, x0
    4754:	b9400400 	ldr	w0, [x0, #4]
    4758:	340004a0 	cbz	w0, 47ec <fwp_caps50+0xa8>
    475c:	f9400660 	ldr	x0, [x19, #8]
    4760:	350004e1 	cbnz	w1, 47fc <fwp_caps50+0xb8>
    4764:	97fffeb3 	bl	4230 <fwp_drop4>
    4768:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    476c:	91134042 	add	x2, x2, #0x4d0
    4770:	f949d840 	ldr	x0, [x2, #5040]
    4774:	f949ec41 	ldr	x1, [x2, #5080]
    4778:	cb000260 	sub	x0, x19, x0
    477c:	eb01401f 	cmp	x0, x1, lsl #16
    4780:	54000382 	b.cs	47f0 <fwp_caps50+0xac>  // b.hs, b.nlast
    4784:	d350fc01 	lsr	x1, x0, #16
    4788:	f949fc44 	ldr	x4, [x2, #5112]
    478c:	8b010821 	add	x1, x1, x1, lsl #2
    4790:	d37df021 	lsl	x1, x1, #3
    4794:	8b010083 	add	x3, x4, x1
    4798:	f9401062 	ldr	x2, [x3, #32]
    479c:	b40002a2 	cbz	x2, 47f0 <fwp_caps50+0xac>
    47a0:	38616881 	ldrb	w1, [x4, x1]
    47a4:	7100083f 	cmp	w1, #0x2
    47a8:	540006c0 	b.eq	4880 <fwp_caps50+0x13c>  // b.none
    47ac:	7100043f 	cmp	w1, #0x1
    47b0:	54000201 	b.ne	47f0 <fwp_caps50+0xac>  // b.any
    47b4:	29430464 	ldp	w4, w1, [x3, #24]
    47b8:	92403c00 	and	x0, x0, #0xffff
    47bc:	9b047c00 	mul	x0, x0, x4
    47c0:	d360fc00 	lsr	x0, x0, #32
    47c4:	eb01001f 	cmp	x0, x1
    47c8:	54000142 	b.cs	47f0 <fwp_caps50+0xac>  // b.hs, b.nlast
    47cc:	8b000042 	add	x2, x2, x0
    47d0:	39400040 	ldrb	w0, [x2]
    47d4:	7100041f 	cmp	w0, #0x1
    47d8:	540000c1 	b.ne	47f0 <fwp_caps50+0xac>  // b.any
    47dc:	aa1303e0 	mov	x0, x19
    47e0:	f9400bf3 	ldr	x19, [sp, #16]
    47e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    47e8:	17fff9fa 	b	2fd0 <fwp_mem_free>
    47ec:	34fffbe1 	cbz	w1, 4768 <fwp_caps50+0x24>
    47f0:	f9400bf3 	ldr	x19, [sp, #16]
    47f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    47f8:	d65f03c0 	ret
    47fc:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    4800:	91134042 	add	x2, x2, #0x4d0
    4804:	f949d843 	ldr	x3, [x2, #5040]
    4808:	f949ec41 	ldr	x1, [x2, #5080]
    480c:	cb030000 	sub	x0, x0, x3
    4810:	eb01401f 	cmp	x0, x1, lsl #16
    4814:	54fffee2 	b.cs	47f0 <fwp_caps50+0xac>  // b.hs, b.nlast
    4818:	d350fc01 	lsr	x1, x0, #16
    481c:	f949fc44 	ldr	x4, [x2, #5112]
    4820:	8b010821 	add	x1, x1, x1, lsl #2
    4824:	d37df021 	lsl	x1, x1, #3
    4828:	8b010083 	add	x3, x4, x1
    482c:	f9401062 	ldr	x2, [x3, #32]
    4830:	b4fffe02 	cbz	x2, 47f0 <fwp_caps50+0xac>
    4834:	38616881 	ldrb	w1, [x4, x1]
    4838:	7100083f 	cmp	w1, #0x2
    483c:	54000280 	b.eq	488c <fwp_caps50+0x148>  // b.none
    4840:	7100043f 	cmp	w1, #0x1
    4844:	54fffd61 	b.ne	47f0 <fwp_caps50+0xac>  // b.any
    4848:	92403c01 	and	x1, x0, #0xffff
    484c:	29430064 	ldp	w4, w0, [x3, #24]
    4850:	9b047c21 	mul	x1, x1, x4
    4854:	d360fc21 	lsr	x1, x1, #32
    4858:	eb00003f 	cmp	x1, x0
    485c:	54fffca2 	b.cs	47f0 <fwp_caps50+0xac>  // b.hs, b.nlast
    4860:	8b010042 	add	x2, x2, x1
    4864:	39400040 	ldrb	w0, [x2]
    4868:	34fffc40 	cbz	w0, 47f0 <fwp_caps50+0xac>
    486c:	7103f41f 	cmp	w0, #0xfd
    4870:	54000148 	b.hi	4898 <fwp_caps50+0x154>  // b.pmore
    4874:	11000400 	add	w0, w0, #0x1
    4878:	39000040 	strb	w0, [x2]
    487c:	17ffffdd 	b	47f0 <fwp_caps50+0xac>
    4880:	72003c1f 	tst	w0, #0xffff
    4884:	54fffb61 	b.ne	47f0 <fwp_caps50+0xac>  // b.any
    4888:	17ffffd2 	b	47d0 <fwp_caps50+0x8c>
    488c:	72003c1f 	tst	w0, #0xffff
    4890:	54fffb01 	b.ne	47f0 <fwp_caps50+0xac>  // b.any
    4894:	17fffff4 	b	4864 <fwp_caps50+0x120>
    4898:	f9400bf3 	ldr	x19, [sp, #16]
    489c:	aa0203e0 	mov	x0, x2
    48a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    48a4:	17fff8e4 	b	2c34 <fwp_rc_wide_dup>
    48a8:	d503201f 	nop
    48ac:	d503201f 	nop

00000000000048b0 <fwp_drop0>:
    48b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    48b4:	910003fd 	mov	x29, sp
    48b8:	a90153f3 	stp	x19, x20, [sp, #16]
    48bc:	f90013f5 	str	x21, [sp, #32]
    48c0:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    48c4:	911342b4 	add	x20, x21, #0x4d0
    48c8:	f949da81 	ldr	x1, [x20, #5040]
    48cc:	f949ee82 	ldr	x2, [x20, #5080]
    48d0:	cb010001 	sub	x1, x0, x1
    48d4:	eb02403f 	cmp	x1, x2, lsl #16
    48d8:	54000382 	b.cs	4948 <fwp_drop0+0x98>  // b.hs, b.nlast
    48dc:	d350fc22 	lsr	x2, x1, #16
    48e0:	f949fe83 	ldr	x3, [x20, #5112]
    48e4:	8b020842 	add	x2, x2, x2, lsl #2
    48e8:	d37df042 	lsl	x2, x2, #3
    48ec:	8b020064 	add	x4, x3, x2
    48f0:	f9401093 	ldr	x19, [x4, #32]
    48f4:	b40002b3 	cbz	x19, 4948 <fwp_drop0+0x98>
    48f8:	38626862 	ldrb	w2, [x3, x2]
    48fc:	7100085f 	cmp	w2, #0x2
    4900:	540002c0 	b.eq	4958 <fwp_drop0+0xa8>  // b.none
    4904:	7100045f 	cmp	w2, #0x1
    4908:	54000201 	b.ne	4948 <fwp_drop0+0x98>  // b.any
    490c:	29430885 	ldp	w5, w2, [x4, #24]
    4910:	92403c21 	and	x1, x1, #0xffff
    4914:	9b057c21 	mul	x1, x1, x5
    4918:	d360fc21 	lsr	x1, x1, #32
    491c:	eb02003f 	cmp	x1, x2
    4920:	54000142 	b.cs	4948 <fwp_drop0+0x98>  // b.hs, b.nlast
    4924:	8b010273 	add	x19, x19, x1
    4928:	39400261 	ldrb	w1, [x19]
    492c:	340000e1 	cbz	w1, 4948 <fwp_drop0+0x98>
    4930:	7100043f 	cmp	w1, #0x1
    4934:	540001e0 	b.eq	4970 <fwp_drop0+0xc0>  // b.none
    4938:	7103fc3f 	cmp	w1, #0xff
    493c:	540006e0 	b.eq	4a18 <fwp_drop0+0x168>  // b.none
    4940:	51000421 	sub	w1, w1, #0x1
    4944:	39000261 	strb	w1, [x19]
    4948:	a94153f3 	ldp	x19, x20, [sp, #16]
    494c:	f94013f5 	ldr	x21, [sp, #32]
    4950:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4954:	d65f03c0 	ret
    4958:	72003c3f 	tst	w1, #0xffff
    495c:	54fffe60 	b.eq	4928 <fwp_drop0+0x78>  // b.none
    4960:	a94153f3 	ldp	x19, x20, [sp, #16]
    4964:	f94013f5 	ldr	x21, [sp, #32]
    4968:	a8c37bfd 	ldp	x29, x30, [sp], #48
    496c:	d65f03c0 	ret
    4970:	911342a1 	add	x1, x21, #0x4d0
    4974:	f9400813 	ldr	x19, [x0, #16]
    4978:	f949ec25 	ldr	x5, [x1, #5080]
    497c:	f949d821 	ldr	x1, [x1, #5040]
    4980:	d370bca5 	lsl	x5, x5, #16
    4984:	cb010002 	sub	x2, x0, x1
    4988:	eb05005f 	cmp	x2, x5
    498c:	54000362 	b.cs	49f8 <fwp_drop0+0x148>  // b.hs, b.nlast
    4990:	d350fc44 	lsr	x4, x2, #16
    4994:	8b040884 	add	x4, x4, x4, lsl #2
    4998:	d37df084 	lsl	x4, x4, #3
    499c:	8b040067 	add	x7, x3, x4
    49a0:	f94010e6 	ldr	x6, [x7, #32]
    49a4:	b40002a6 	cbz	x6, 49f8 <fwp_drop0+0x148>
    49a8:	38646863 	ldrb	w3, [x3, x4]
    49ac:	7100087f 	cmp	w3, #0x2
    49b0:	540002e0 	b.eq	4a0c <fwp_drop0+0x15c>  // b.none
    49b4:	7100047f 	cmp	w3, #0x1
    49b8:	54000201 	b.ne	49f8 <fwp_drop0+0x148>  // b.any
    49bc:	29430ce4 	ldp	w4, w3, [x7, #24]
    49c0:	92403c42 	and	x2, x2, #0xffff
    49c4:	9b047c42 	mul	x2, x2, x4
    49c8:	d360fc42 	lsr	x2, x2, #32
    49cc:	eb03005f 	cmp	x2, x3
    49d0:	54000142 	b.cs	49f8 <fwp_drop0+0x148>  // b.hs, b.nlast
    49d4:	8b0200c6 	add	x6, x6, x2
    49d8:	394000c2 	ldrb	w2, [x6]
    49dc:	7100045f 	cmp	w2, #0x1
    49e0:	540000c1 	b.ne	49f8 <fwp_drop0+0x148>  // b.any
    49e4:	97fff97b 	bl	2fd0 <fwp_mem_free>
    49e8:	911342a0 	add	x0, x21, #0x4d0
    49ec:	f949ec05 	ldr	x5, [x0, #5080]
    49f0:	f949d801 	ldr	x1, [x0, #5040]
    49f4:	d370bca5 	lsl	x5, x5, #16
    49f8:	cb010261 	sub	x1, x19, x1
    49fc:	eb05003f 	cmp	x1, x5
    4a00:	54fffa42 	b.cs	4948 <fwp_drop0+0x98>  // b.hs, b.nlast
    4a04:	aa1303e0 	mov	x0, x19
    4a08:	17ffffb5 	b	48dc <fwp_drop0+0x2c>
    4a0c:	72003c5f 	tst	w2, #0xffff
    4a10:	54ffff41 	b.ne	49f8 <fwp_drop0+0x148>  // b.any
    4a14:	17fffff1 	b	49d8 <fwp_drop0+0x128>
    4a18:	ca534661 	eor	x1, x19, x19, lsr #17
    4a1c:	911342a0 	add	x0, x21, #0x4d0
    4a20:	ca412421 	eor	x1, x1, x1, lsr #9
    4a24:	8b210c01 	add	x1, x0, w1, uxtb #3
    4a28:	f94a2420 	ldr	x0, [x1, #5192]
    4a2c:	b5000080 	cbnz	x0, 4a3c <fwp_drop0+0x18c>
    4a30:	14000010 	b	4a70 <fwp_drop0+0x1c0>
    4a34:	f9400800 	ldr	x0, [x0, #16]
    4a38:	b40001c0 	cbz	x0, 4a70 <fwp_drop0+0x1c0>
    4a3c:	f9400001 	ldr	x1, [x0]
    4a40:	eb13003f 	cmp	x1, x19
    4a44:	54ffff81 	b.ne	4a34 <fwp_drop0+0x184>  // b.any
    4a48:	f9400401 	ldr	x1, [x0, #8]
    4a4c:	d1000421 	sub	x1, x1, #0x1
    4a50:	f9000401 	str	x1, [x0, #8]
    4a54:	f103f83f 	cmp	x1, #0xfe
    4a58:	54fff781 	b.ne	4948 <fwp_drop0+0x98>  // b.any
    4a5c:	aa1303e0 	mov	x0, x19
    4a60:	97fff8bc 	bl	2d50 <fwp_rc_forget_slot>
    4a64:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4a68:	39000260 	strb	w0, [x19]
    4a6c:	17ffffb7 	b	4948 <fwp_drop0+0x98>
    4a70:	b0000020 	adrp	x0, 9000 <f0+0x2610>
    4a74:	9139c000 	add	x0, x0, #0xe70
    4a78:	97fff5aa 	bl	2120 <fwp_trap>
    4a7c:	d503201f 	nop

0000000000004a80 <fwp_drop1>:
    4a80:	17ffff8c 	b	48b0 <fwp_drop0>

0000000000004a84 <fwp_drop6>:
    4a84:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a88:	910003fd 	mov	x29, sp
    4a8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a90:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xd10>
    4a94:	911342d5 	add	x21, x22, #0x4d0
    4a98:	a90153f3 	stp	x19, x20, [sp, #16]
    4a9c:	aa0003f3 	mov	x19, x0
    4aa0:	f949daa1 	ldr	x1, [x21, #5040]
    4aa4:	f949eea0 	ldr	x0, [x21, #5080]
    4aa8:	cb010261 	sub	x1, x19, x1
    4aac:	eb00403f 	cmp	x1, x0, lsl #16
    4ab0:	54000382 	b.cs	4b20 <fwp_drop6+0x9c>  // b.hs, b.nlast
    4ab4:	d350fc22 	lsr	x2, x1, #16
    4ab8:	f949fea3 	ldr	x3, [x21, #5112]
    4abc:	8b020842 	add	x2, x2, x2, lsl #2
    4ac0:	d37df042 	lsl	x2, x2, #3
    4ac4:	8b020060 	add	x0, x3, x2
    4ac8:	f9401014 	ldr	x20, [x0, #32]
    4acc:	b40002b4 	cbz	x20, 4b20 <fwp_drop6+0x9c>
    4ad0:	38626862 	ldrb	w2, [x3, x2]
    4ad4:	7100085f 	cmp	w2, #0x2
    4ad8:	540002c0 	b.eq	4b30 <fwp_drop6+0xac>  // b.none
    4adc:	7100045f 	cmp	w2, #0x1
    4ae0:	54000201 	b.ne	4b20 <fwp_drop6+0x9c>  // b.any
    4ae4:	29430002 	ldp	w2, w0, [x0, #24]
    4ae8:	92403c21 	and	x1, x1, #0xffff
    4aec:	9b027c21 	mul	x1, x1, x2
    4af0:	d360fc21 	lsr	x1, x1, #32
    4af4:	eb00003f 	cmp	x1, x0
    4af8:	54000142 	b.cs	4b20 <fwp_drop6+0x9c>  // b.hs, b.nlast
    4afc:	8b010294 	add	x20, x20, x1
    4b00:	39400280 	ldrb	w0, [x20]
    4b04:	340000e0 	cbz	w0, 4b20 <fwp_drop6+0x9c>
    4b08:	7100041f 	cmp	w0, #0x1
    4b0c:	540001e0 	b.eq	4b48 <fwp_drop6+0xc4>  // b.none
    4b10:	7103fc1f 	cmp	w0, #0xff
    4b14:	54000760 	b.eq	4c00 <fwp_drop6+0x17c>  // b.none
    4b18:	51000400 	sub	w0, w0, #0x1
    4b1c:	39000280 	strb	w0, [x20]
    4b20:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b2c:	d65f03c0 	ret
    4b30:	72003c3f 	tst	w1, #0xffff
    4b34:	54fffe60 	b.eq	4b00 <fwp_drop6+0x7c>  // b.none
    4b38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b3c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b44:	d65f03c0 	ret
    4b48:	f9400660 	ldr	x0, [x19, #8]
    4b4c:	97fffdb9 	bl	4230 <fwp_drop4>
    4b50:	911342c4 	add	x4, x22, #0x4d0
    4b54:	f9400a74 	ldr	x20, [x19, #16]
    4b58:	f949ec83 	ldr	x3, [x4, #5080]
    4b5c:	f949d881 	ldr	x1, [x4, #5040]
    4b60:	d370bc63 	lsl	x3, x3, #16
    4b64:	cb010262 	sub	x2, x19, x1
    4b68:	eb03005f 	cmp	x2, x3
    4b6c:	540003a2 	b.cs	4be0 <fwp_drop6+0x15c>  // b.hs, b.nlast
    4b70:	d350fc40 	lsr	x0, x2, #16
    4b74:	f949fc86 	ldr	x6, [x4, #5112]
    4b78:	8b000800 	add	x0, x0, x0, lsl #2
    4b7c:	d37df000 	lsl	x0, x0, #3
    4b80:	8b0000c5 	add	x5, x6, x0
    4b84:	f94010a4 	ldr	x4, [x5, #32]
    4b88:	b40002c4 	cbz	x4, 4be0 <fwp_drop6+0x15c>
    4b8c:	386068c0 	ldrb	w0, [x6, x0]
    4b90:	7100081f 	cmp	w0, #0x2
    4b94:	54000300 	b.eq	4bf4 <fwp_drop6+0x170>  // b.none
    4b98:	7100041f 	cmp	w0, #0x1
    4b9c:	54000221 	b.ne	4be0 <fwp_drop6+0x15c>  // b.any
    4ba0:	92403c40 	and	x0, x2, #0xffff
    4ba4:	294308a6 	ldp	w6, w2, [x5, #24]
    4ba8:	9b067c00 	mul	x0, x0, x6
    4bac:	d360fc00 	lsr	x0, x0, #32
    4bb0:	eb02001f 	cmp	x0, x2
    4bb4:	54000162 	b.cs	4be0 <fwp_drop6+0x15c>  // b.hs, b.nlast
    4bb8:	8b000084 	add	x4, x4, x0
    4bbc:	39400080 	ldrb	w0, [x4]
    4bc0:	7100041f 	cmp	w0, #0x1
    4bc4:	540000e1 	b.ne	4be0 <fwp_drop6+0x15c>  // b.any
    4bc8:	aa1303e0 	mov	x0, x19
    4bcc:	97fff901 	bl	2fd0 <fwp_mem_free>
    4bd0:	911342c0 	add	x0, x22, #0x4d0
    4bd4:	f949ec03 	ldr	x3, [x0, #5080]
    4bd8:	f949d801 	ldr	x1, [x0, #5040]
    4bdc:	d370bc63 	lsl	x3, x3, #16
    4be0:	cb010281 	sub	x1, x20, x1
    4be4:	eb01007f 	cmp	x3, x1
    4be8:	54fff9c9 	b.ls	4b20 <fwp_drop6+0x9c>  // b.plast
    4bec:	aa1403f3 	mov	x19, x20
    4bf0:	17ffffb1 	b	4ab4 <fwp_drop6+0x30>
    4bf4:	72003c5f 	tst	w2, #0xffff
    4bf8:	54ffff41 	b.ne	4be0 <fwp_drop6+0x15c>  // b.any
    4bfc:	17fffff0 	b	4bbc <fwp_drop6+0x138>
    4c00:	ca544681 	eor	x1, x20, x20, lsr #17
    4c04:	911342c0 	add	x0, x22, #0x4d0
    4c08:	ca412421 	eor	x1, x1, x1, lsr #9
    4c0c:	8b210c01 	add	x1, x0, w1, uxtb #3
    4c10:	f94a2420 	ldr	x0, [x1, #5192]
    4c14:	b5000080 	cbnz	x0, 4c24 <fwp_drop6+0x1a0>
    4c18:	14000010 	b	4c58 <fwp_drop6+0x1d4>
    4c1c:	f9400800 	ldr	x0, [x0, #16]
    4c20:	b40001c0 	cbz	x0, 4c58 <fwp_drop6+0x1d4>
    4c24:	f9400001 	ldr	x1, [x0]
    4c28:	eb14003f 	cmp	x1, x20
    4c2c:	54ffff81 	b.ne	4c1c <fwp_drop6+0x198>  // b.any
    4c30:	f9400401 	ldr	x1, [x0, #8]
    4c34:	d1000421 	sub	x1, x1, #0x1
    4c38:	f9000401 	str	x1, [x0, #8]
    4c3c:	f103f83f 	cmp	x1, #0xfe
    4c40:	54fff701 	b.ne	4b20 <fwp_drop6+0x9c>  // b.any
    4c44:	aa1403e0 	mov	x0, x20
    4c48:	97fff842 	bl	2d50 <fwp_rc_forget_slot>
    4c4c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4c50:	39000280 	strb	w0, [x20]
    4c54:	17ffffb3 	b	4b20 <fwp_drop6+0x9c>
    4c58:	b0000020 	adrp	x0, 9000 <f0+0x2610>
    4c5c:	9139c000 	add	x0, x0, #0xe70
    4c60:	97fff530 	bl	2120 <fwp_trap>

0000000000004c64 <fwp_owned_entry74>:
    4c64:	d10103ff 	sub	sp, sp, #0x40
    4c68:	aa0003e2 	mov	x2, x0
    4c6c:	d2f80f21 	mov	x1, #0xc079000000000000    	// #-4577627546245398528
    4c70:	1e6e1002 	fmov	d2, #1.000000000000000000e+00
    4c74:	9e670020 	fmov	d0, x1
    4c78:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    4c7c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4c80:	910083fd 	add	x29, sp, #0x20
    4c84:	9e670004 	fmov	d4, x0
    4c88:	fd400043 	ldr	d3, [x2]
    4c8c:	fd400441 	ldr	d1, [x2, #8]
    4c90:	a90353f3 	stp	x19, x20, [sp, #48]
    4c94:	1e630865 	fmul	d5, d3, d3
    4c98:	1e600860 	fmul	d0, d3, d0
    4c9c:	1e633842 	fsub	d2, d2, d3
    4ca0:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x13c68>
    4ca4:	f947f442 	ldr	x2, [x2, #4072]
    4ca8:	910023e1 	add	x1, sp, #0x8
    4cac:	1e653821 	fsub	d1, d1, d5
    4cb0:	52800000 	mov	w0, #0x0                   	// #0
    4cb4:	1e622842 	fadd	d2, d2, d2
    4cb8:	f9400043 	ldr	x3, [x2]
    4cbc:	f9000fe3 	str	x3, [sp, #24]
    4cc0:	d2800003 	mov	x3, #0x0                   	// #0
    4cc4:	1e610800 	fmul	d0, d0, d1
    4cc8:	1e640821 	fmul	d1, d1, d4
    4ccc:	1e623800 	fsub	d0, d0, d2
    4cd0:	6d0087e0 	stp	d0, d1, [sp, #8]
    4cd4:	97fffcbc 	bl	3fc4 <fwp_data.part.0.constprop.0>
    4cd8:	b0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    4cdc:	91134063 	add	x3, x3, #0x4d0
    4ce0:	aa0003f3 	mov	x19, x0
    4ce4:	f949d861 	ldr	x1, [x3, #5040]
    4ce8:	f949ec60 	ldr	x0, [x3, #5080]
    4cec:	cb010261 	sub	x1, x19, x1
    4cf0:	eb00403f 	cmp	x1, x0, lsl #16
    4cf4:	54000322 	b.cs	4d58 <fwp_owned_entry74+0xf4>  // b.hs, b.nlast
    4cf8:	d350fc22 	lsr	x2, x1, #16
    4cfc:	f949fc63 	ldr	x3, [x3, #5112]
    4d00:	8b020842 	add	x2, x2, x2, lsl #2
    4d04:	d37df042 	lsl	x2, x2, #3
    4d08:	8b020060 	add	x0, x3, x2
    4d0c:	f9401014 	ldr	x20, [x0, #32]
    4d10:	b4000254 	cbz	x20, 4d58 <fwp_owned_entry74+0xf4>
    4d14:	38626862 	ldrb	w2, [x3, x2]
    4d18:	7100085f 	cmp	w2, #0x2
    4d1c:	54000360 	b.eq	4d88 <fwp_owned_entry74+0x124>  // b.none
    4d20:	7100045f 	cmp	w2, #0x1
    4d24:	540001a1 	b.ne	4d58 <fwp_owned_entry74+0xf4>  // b.any
    4d28:	29430002 	ldp	w2, w0, [x0, #24]
    4d2c:	92403c21 	and	x1, x1, #0xffff
    4d30:	9b027c21 	mul	x1, x1, x2
    4d34:	d360fc21 	lsr	x1, x1, #32
    4d38:	eb00003f 	cmp	x1, x0
    4d3c:	540000e2 	b.cs	4d58 <fwp_owned_entry74+0xf4>  // b.hs, b.nlast
    4d40:	8b010294 	add	x20, x20, x1
    4d44:	39400280 	ldrb	w0, [x20]
    4d48:	7103fc1f 	cmp	w0, #0xff
    4d4c:	54000240 	b.eq	4d94 <fwp_owned_entry74+0x130>  // b.none
    4d50:	52800020 	mov	w0, #0x1                   	// #1
    4d54:	39000280 	strb	w0, [x20]
    4d58:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    4d5c:	f947f400 	ldr	x0, [x0, #4072]
    4d60:	f9400fe2 	ldr	x2, [sp, #24]
    4d64:	f9400001 	ldr	x1, [x0]
    4d68:	eb010042 	subs	x2, x2, x1
    4d6c:	d2800001 	mov	x1, #0x0                   	// #0
    4d70:	54000181 	b.ne	4da0 <fwp_owned_entry74+0x13c>  // b.any
    4d74:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4d78:	aa1303e0 	mov	x0, x19
    4d7c:	a94353f3 	ldp	x19, x20, [sp, #48]
    4d80:	910103ff 	add	sp, sp, #0x40
    4d84:	d65f03c0 	ret
    4d88:	72003c3f 	tst	w1, #0xffff
    4d8c:	54fffe61 	b.ne	4d58 <fwp_owned_entry74+0xf4>  // b.any
    4d90:	17ffffed 	b	4d44 <fwp_owned_entry74+0xe0>
    4d94:	aa1403e0 	mov	x0, x20
    4d98:	97fff7ee 	bl	2d50 <fwp_rc_forget_slot>
    4d9c:	17ffffed 	b	4d50 <fwp_owned_entry74+0xec>
    4da0:	97fff1d4 	bl	14f0 <__stack_chk_fail@plt>

0000000000004da4 <e74>:
    4da4:	d10103ff 	sub	sp, sp, #0x40
    4da8:	aa0003e2 	mov	x2, x0
    4dac:	d2f80f21 	mov	x1, #0xc079000000000000    	// #-4577627546245398528
    4db0:	1e6e1002 	fmov	d2, #1.000000000000000000e+00
    4db4:	9e670020 	fmov	d0, x1
    4db8:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    4dbc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4dc0:	910083fd 	add	x29, sp, #0x20
    4dc4:	9e670004 	fmov	d4, x0
    4dc8:	fd400043 	ldr	d3, [x2]
    4dcc:	fd400441 	ldr	d1, [x2, #8]
    4dd0:	a90353f3 	stp	x19, x20, [sp, #48]
    4dd4:	1e630865 	fmul	d5, d3, d3
    4dd8:	1e600860 	fmul	d0, d3, d0
    4ddc:	1e633842 	fsub	d2, d2, d3
    4de0:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x13c68>
    4de4:	f947f442 	ldr	x2, [x2, #4072]
    4de8:	910023e1 	add	x1, sp, #0x8
    4dec:	1e653821 	fsub	d1, d1, d5
    4df0:	52800000 	mov	w0, #0x0                   	// #0
    4df4:	1e622842 	fadd	d2, d2, d2
    4df8:	f9400043 	ldr	x3, [x2]
    4dfc:	f9000fe3 	str	x3, [sp, #24]
    4e00:	d2800003 	mov	x3, #0x0                   	// #0
    4e04:	1e610800 	fmul	d0, d0, d1
    4e08:	1e640821 	fmul	d1, d1, d4
    4e0c:	1e623800 	fsub	d0, d0, d2
    4e10:	6d0087e0 	stp	d0, d1, [sp, #8]
    4e14:	97fffc6c 	bl	3fc4 <fwp_data.part.0.constprop.0>
    4e18:	b0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    4e1c:	91134063 	add	x3, x3, #0x4d0
    4e20:	aa0003f3 	mov	x19, x0
    4e24:	f949d861 	ldr	x1, [x3, #5040]
    4e28:	f949ec60 	ldr	x0, [x3, #5080]
    4e2c:	cb010261 	sub	x1, x19, x1
    4e30:	eb00403f 	cmp	x1, x0, lsl #16
    4e34:	54000322 	b.cs	4e98 <e74+0xf4>  // b.hs, b.nlast
    4e38:	d350fc22 	lsr	x2, x1, #16
    4e3c:	f949fc63 	ldr	x3, [x3, #5112]
    4e40:	8b020842 	add	x2, x2, x2, lsl #2
    4e44:	d37df042 	lsl	x2, x2, #3
    4e48:	8b020060 	add	x0, x3, x2
    4e4c:	f9401014 	ldr	x20, [x0, #32]
    4e50:	b4000254 	cbz	x20, 4e98 <e74+0xf4>
    4e54:	38626862 	ldrb	w2, [x3, x2]
    4e58:	7100085f 	cmp	w2, #0x2
    4e5c:	540003a0 	b.eq	4ed0 <e74+0x12c>  // b.none
    4e60:	7100045f 	cmp	w2, #0x1
    4e64:	540001a1 	b.ne	4e98 <e74+0xf4>  // b.any
    4e68:	29430002 	ldp	w2, w0, [x0, #24]
    4e6c:	92403c21 	and	x1, x1, #0xffff
    4e70:	9b027c21 	mul	x1, x1, x2
    4e74:	d360fc21 	lsr	x1, x1, #32
    4e78:	eb00003f 	cmp	x1, x0
    4e7c:	540000e2 	b.cs	4e98 <e74+0xf4>  // b.hs, b.nlast
    4e80:	8b010294 	add	x20, x20, x1
    4e84:	39400280 	ldrb	w0, [x20]
    4e88:	7103fc1f 	cmp	w0, #0xff
    4e8c:	54000280 	b.eq	4edc <e74+0x138>  // b.none
    4e90:	52800020 	mov	w0, #0x1                   	// #1
    4e94:	39000280 	strb	w0, [x20]
    4e98:	aa1303e0 	mov	x0, x19
    4e9c:	97fff96d 	bl	3450 <fwp_rc_share>
    4ea0:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    4ea4:	f947f400 	ldr	x0, [x0, #4072]
    4ea8:	f9400fe2 	ldr	x2, [sp, #24]
    4eac:	f9400001 	ldr	x1, [x0]
    4eb0:	eb010042 	subs	x2, x2, x1
    4eb4:	d2800001 	mov	x1, #0x0                   	// #0
    4eb8:	54000181 	b.ne	4ee8 <e74+0x144>  // b.any
    4ebc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4ec0:	aa1303e0 	mov	x0, x19
    4ec4:	a94353f3 	ldp	x19, x20, [sp, #48]
    4ec8:	910103ff 	add	sp, sp, #0x40
    4ecc:	d65f03c0 	ret
    4ed0:	72003c3f 	tst	w1, #0xffff
    4ed4:	54fffe21 	b.ne	4e98 <e74+0xf4>  // b.any
    4ed8:	17ffffeb 	b	4e84 <e74+0xe0>
    4edc:	aa1403e0 	mov	x0, x20
    4ee0:	97fff79c 	bl	2d50 <fwp_rc_forget_slot>
    4ee4:	17ffffeb 	b	4e90 <e74+0xec>
    4ee8:	97fff182 	bl	14f0 <__stack_chk_fail@plt>
    4eec:	d503201f 	nop

0000000000004ef0 <fwp_loop_fields68.constprop.0>:
    4ef0:	d104c3ff 	sub	sp, sp, #0x130
    4ef4:	f00000c1 	adrp	x1, 1f000 <__FRAME_END__+0x13c68>
    4ef8:	f947f421 	ldr	x1, [x1, #4072]
    4efc:	a90b7bfd 	stp	x29, x30, [sp, #176]
    4f00:	9102c3fd 	add	x29, sp, #0xb0
    4f04:	a90c53f3 	stp	x19, x20, [sp, #192]
    4f08:	a90d5bf5 	stp	x21, x22, [sp, #208]
    4f0c:	910143f6 	add	x22, sp, #0x50
    4f10:	a90e63f7 	stp	x23, x24, [sp, #224]
    4f14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4f18:	aa0003f9 	mov	x25, x0
    4f1c:	a91073fb 	stp	x27, x28, [sp, #256]
    4f20:	6d1127e8 	stp	d8, d9, [sp, #272]
    4f24:	6d122fea 	stp	d10, d11, [sp, #288]
    4f28:	f9400020 	ldr	x0, [x1]
    4f2c:	f90057e0 	str	x0, [sp, #168]
    4f30:	d2800000 	mov	x0, #0x0                   	// #0
    4f34:	b0000160 	adrp	x0, 31000 <fwp_root_context+0xd10>
    4f38:	9113401b 	add	x27, x0, #0x4d0
    4f3c:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    4f40:	9e670009 	fmov	d9, x0
    4f44:	d28018c0 	mov	x0, #0xc6                  	// #198
    4f48:	f9000fe0 	str	x0, [sp, #24]
    4f4c:	910103e0 	add	x0, sp, #0x40
    4f50:	f90013e0 	str	x0, [sp, #32]
    4f54:	910123e0 	add	x0, sp, #0x48
    4f58:	f90007e0 	str	x0, [sp, #8]
    4f5c:	910203e0 	add	x0, sp, #0x80
    4f60:	f9001fe0 	str	x0, [sp, #56]
    4f64:	d0000020 	adrp	x0, a000 <_IO_stdin_used+0x380>
    4f68:	d2f80f21 	mov	x1, #0xc079000000000000    	// #-4577627546245398528
    4f6c:	9e67002a 	fmov	d10, x1
    4f70:	fd40e80b 	ldr	d11, [x0, #464]
    4f74:	b4004259 	cbz	x25, 57bc <fwp_loop_fields68.constprop.0+0x8cc>
    4f78:	f9400b20 	ldr	x0, [x25, #16]
    4f7c:	f9000be0 	str	x0, [sp, #16]
    4f80:	f9400be2 	ldr	x2, [sp, #16]
    4f84:	f949db61 	ldr	x1, [x27, #5040]
    4f88:	f949ef60 	ldr	x0, [x27, #5080]
    4f8c:	cb010041 	sub	x1, x2, x1
    4f90:	eb00403f 	cmp	x1, x0, lsl #16
    4f94:	54000342 	b.cs	4ffc <fwp_loop_fields68.constprop.0+0x10c>  // b.hs, b.nlast
    4f98:	d350fc20 	lsr	x0, x1, #16
    4f9c:	f949ff65 	ldr	x5, [x27, #5112]
    4fa0:	8b000800 	add	x0, x0, x0, lsl #2
    4fa4:	d37df003 	lsl	x3, x0, #3
    4fa8:	8b0300a4 	add	x4, x5, x3
    4fac:	f9401080 	ldr	x0, [x4, #32]
    4fb0:	b4000260 	cbz	x0, 4ffc <fwp_loop_fields68.constprop.0+0x10c>
    4fb4:	386368a3 	ldrb	w3, [x5, x3]
    4fb8:	7100087f 	cmp	w3, #0x2
    4fbc:	54004460 	b.eq	5848 <fwp_loop_fields68.constprop.0+0x958>  // b.none
    4fc0:	7100047f 	cmp	w3, #0x1
    4fc4:	540001c1 	b.ne	4ffc <fwp_loop_fields68.constprop.0+0x10c>  // b.any
    4fc8:	29430c85 	ldp	w5, w3, [x4, #24]
    4fcc:	92403c21 	and	x1, x1, #0xffff
    4fd0:	9b057c21 	mul	x1, x1, x5
    4fd4:	d360fc21 	lsr	x1, x1, #32
    4fd8:	eb03003f 	cmp	x1, x3
    4fdc:	54000102 	b.cs	4ffc <fwp_loop_fields68.constprop.0+0x10c>  // b.hs, b.nlast
    4fe0:	8b010000 	add	x0, x0, x1
    4fe4:	39400001 	ldrb	w1, [x0]
    4fe8:	340000a1 	cbz	w1, 4ffc <fwp_loop_fields68.constprop.0+0x10c>
    4fec:	7103f43f 	cmp	w1, #0xfd
    4ff0:	54004f48 	b.hi	59d8 <fwp_loop_fields68.constprop.0+0xae8>  // b.pmore
    4ff4:	11000421 	add	w1, w1, #0x1
    4ff8:	39000001 	strb	w1, [x0]
    4ffc:	f9400be0 	ldr	x0, [sp, #16]
    5000:	910263f4 	add	x20, sp, #0x98
    5004:	f94013e1 	ldr	x1, [sp, #32]
    5008:	d2800017 	mov	x23, #0x0                   	// #0
    500c:	52800035 	mov	w21, #0x1                   	// #1
    5010:	97fffab4 	bl	3ae0 <fwp_map_items>
    5014:	aa0003fc 	mov	x28, x0
    5018:	f94007e1 	ldr	x1, [sp, #8]
    501c:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x3c>
    5020:	9108c005 	add	x5, x0, #0x230
    5024:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x3c>
    5028:	912a1003 	add	x3, x0, #0xa84
    502c:	aa1903e0 	mov	x0, x25
    5030:	f9002bfc 	str	x28, [sp, #80]
    5034:	a905ffff 	stp	xzr, xzr, [sp, #88]
    5038:	a9068fe5 	stp	x5, x3, [sp, #104]
    503c:	97fffaa9 	bl	3ae0 <fwp_map_items>
    5040:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    5044:	a9444fe1 	ldp	x1, x19, [sp, #64]
    5048:	aa0003f8 	mov	x24, x0
    504c:	eb01027f 	cmp	x19, x1
    5050:	9a819273 	csel	x19, x19, x1, ls	// ls = plast
    5054:	b4003d33 	cbz	x19, 57f8 <fwp_loop_fields68.constprop.0+0x908>
    5058:	fc777b00 	ldr	d0, [x24, x23, lsl #3]
    505c:	aa1403e1 	mov	x1, x20
    5060:	fc777b81 	ldr	d1, [x28, x23, lsl #3]
    5064:	52800000 	mov	w0, #0x0                   	// #0
    5068:	1e600803 	fmul	d3, d0, d0
    506c:	1e6a0802 	fmul	d2, d0, d10
    5070:	1e603900 	fsub	d0, d8, d0
    5074:	1e633821 	fsub	d1, d1, d3
    5078:	1e602800 	fadd	d0, d0, d0
    507c:	1e610842 	fmul	d2, d2, d1
    5080:	1e690821 	fmul	d1, d1, d9
    5084:	1e603840 	fsub	d0, d2, d0
    5088:	6d0987e0 	stp	d0, d1, [sp, #152]
    508c:	97fffbce 	bl	3fc4 <fwp_data.part.0.constprop.0>
    5090:	aa0003fa 	mov	x26, x0
    5094:	f949db61 	ldr	x1, [x27, #5040]
    5098:	f949ef60 	ldr	x0, [x27, #5080]
    509c:	cb010341 	sub	x1, x26, x1
    50a0:	eb00403f 	cmp	x1, x0, lsl #16
    50a4:	54000302 	b.cs	5104 <fwp_loop_fields68.constprop.0+0x214>  // b.hs, b.nlast
    50a8:	d350fc23 	lsr	x3, x1, #16
    50ac:	f949ff67 	ldr	x7, [x27, #5112]
    50b0:	8b030863 	add	x3, x3, x3, lsl #2
    50b4:	d37df063 	lsl	x3, x3, #3
    50b8:	8b0300e6 	add	x6, x7, x3
    50bc:	f94010c0 	ldr	x0, [x6, #32]
    50c0:	b4000220 	cbz	x0, 5104 <fwp_loop_fields68.constprop.0+0x214>
    50c4:	386368e3 	ldrb	w3, [x7, x3]
    50c8:	7100087f 	cmp	w3, #0x2
    50cc:	54003840 	b.eq	57d4 <fwp_loop_fields68.constprop.0+0x8e4>  // b.none
    50d0:	7100047f 	cmp	w3, #0x1
    50d4:	54000181 	b.ne	5104 <fwp_loop_fields68.constprop.0+0x214>  // b.any
    50d8:	29430cc7 	ldp	w7, w3, [x6, #24]
    50dc:	92403c21 	and	x1, x1, #0xffff
    50e0:	9b077c21 	mul	x1, x1, x7
    50e4:	d360fc21 	lsr	x1, x1, #32
    50e8:	eb03003f 	cmp	x1, x3
    50ec:	540000c2 	b.cs	5104 <fwp_loop_fields68.constprop.0+0x214>  // b.hs, b.nlast
    50f0:	8b010000 	add	x0, x0, x1
    50f4:	39400001 	ldrb	w1, [x0]
    50f8:	7103fc3f 	cmp	w1, #0xff
    50fc:	54003640 	b.eq	57c4 <fwp_loop_fields68.constprop.0+0x8d4>  // b.none
    5100:	39000015 	strb	w21, [x0]
    5104:	f8377b9a 	str	x26, [x28, x23, lsl #3]
    5108:	910006f7 	add	x23, x23, #0x1
    510c:	f9002ff7 	str	x23, [sp, #88]
    5110:	eb17027f 	cmp	x19, x23
    5114:	54fffa21 	b.ne	5058 <fwp_loop_fields68.constprop.0+0x168>  // b.any
    5118:	aa1803e0 	mov	x0, x24
    511c:	97fff7ad 	bl	2fd0 <fwp_mem_free>
    5120:	aa1603e0 	mov	x0, x22
    5124:	97fffbf0 	bl	40e4 <fwp_map_finish_protected.isra.0>
    5128:	aa0003f7 	mov	x23, x0
    512c:	f9400be0 	ldr	x0, [sp, #16]
    5130:	97fffde0 	bl	48b0 <fwp_drop0>
    5134:	a9087fff 	stp	xzr, xzr, [sp, #128]
    5138:	52800020 	mov	w0, #0x1                   	// #1
    513c:	f9401fe1 	ldr	x1, [sp, #56]
    5140:	97fffba1 	bl	3fc4 <fwp_data.part.0.constprop.0>
    5144:	aa0003e2 	mov	x2, x0
    5148:	f949db61 	ldr	x1, [x27, #5040]
    514c:	f9000be2 	str	x2, [sp, #16]
    5150:	f949ef60 	ldr	x0, [x27, #5080]
    5154:	cb010041 	sub	x1, x2, x1
    5158:	eb00403f 	cmp	x1, x0, lsl #16
    515c:	54000322 	b.cs	51c0 <fwp_loop_fields68.constprop.0+0x2d0>  // b.hs, b.nlast
    5160:	d350fc20 	lsr	x0, x1, #16
    5164:	f949ff64 	ldr	x4, [x27, #5112]
    5168:	8b000800 	add	x0, x0, x0, lsl #2
    516c:	d37df003 	lsl	x3, x0, #3
    5170:	8b030080 	add	x0, x4, x3
    5174:	f9401013 	ldr	x19, [x0, #32]
    5178:	b4000253 	cbz	x19, 51c0 <fwp_loop_fields68.constprop.0+0x2d0>
    517c:	38636883 	ldrb	w3, [x4, x3]
    5180:	7100087f 	cmp	w3, #0x2
    5184:	54003520 	b.eq	5828 <fwp_loop_fields68.constprop.0+0x938>  // b.none
    5188:	7100047f 	cmp	w3, #0x1
    518c:	540001a1 	b.ne	51c0 <fwp_loop_fields68.constprop.0+0x2d0>  // b.any
    5190:	29430003 	ldp	w3, w0, [x0, #24]
    5194:	92403c21 	and	x1, x1, #0xffff
    5198:	9b037c21 	mul	x1, x1, x3
    519c:	d360fc21 	lsr	x1, x1, #32
    51a0:	eb00003f 	cmp	x1, x0
    51a4:	540000e2 	b.cs	51c0 <fwp_loop_fields68.constprop.0+0x2d0>  // b.hs, b.nlast
    51a8:	8b010273 	add	x19, x19, x1
    51ac:	39400260 	ldrb	w0, [x19]
    51b0:	7103fc1f 	cmp	w0, #0xff
    51b4:	54003440 	b.eq	583c <fwp_loop_fields68.constprop.0+0x94c>  // b.none
    51b8:	52800020 	mov	w0, #0x1                   	// #1
    51bc:	39000260 	strb	w0, [x19]
    51c0:	f94007e1 	ldr	x1, [sp, #8]
    51c4:	aa1703e0 	mov	x0, x23
    51c8:	d2800014 	mov	x20, #0x0                   	// #0
    51cc:	97fffa45 	bl	3ae0 <fwp_map_items>
    51d0:	aa0003fa 	mov	x26, x0
    51d4:	f94027f3 	ldr	x19, [sp, #72]
    51d8:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x3c>
    51dc:	9122c000 	add	x0, x0, #0x8b0
    51e0:	f9002bfa 	str	x26, [sp, #80]
    51e4:	a905ffff 	stp	xzr, xzr, [sp, #88]
    51e8:	a90683ff 	stp	xzr, x0, [sp, #104]
    51ec:	b5000333 	cbnz	x19, 5250 <fwp_loop_fields68.constprop.0+0x360>
    51f0:	14000032 	b	52b8 <fwp_loop_fields68.constprop.0+0x3c8>
    51f4:	7100047f 	cmp	w3, #0x1
    51f8:	540001c1 	b.ne	5230 <fwp_loop_fields68.constprop.0+0x340>  // b.any
    51fc:	29430c85 	ldp	w5, w3, [x4, #24]
    5200:	92403c21 	and	x1, x1, #0xffff
    5204:	9b057c21 	mul	x1, x1, x5
    5208:	d360fc21 	lsr	x1, x1, #32
    520c:	eb03003f 	cmp	x1, x3
    5210:	54000102 	b.cs	5230 <fwp_loop_fields68.constprop.0+0x340>  // b.hs, b.nlast
    5214:	8b010000 	add	x0, x0, x1
    5218:	39400001 	ldrb	w1, [x0]
    521c:	340000a1 	cbz	w1, 5230 <fwp_loop_fields68.constprop.0+0x340>
    5220:	7103f43f 	cmp	w1, #0xfd
    5224:	54002f88 	b.hi	5814 <fwp_loop_fields68.constprop.0+0x924>  // b.pmore
    5228:	11000421 	add	w1, w1, #0x1
    522c:	39000001 	strb	w1, [x0]
    5230:	f94006b8 	ldr	x24, [x21, #8]
    5234:	aa1503e0 	mov	x0, x21
    5238:	97fffbfe 	bl	4230 <fwp_drop4>
    523c:	f8347b58 	str	x24, [x26, x20, lsl #3]
    5240:	91000694 	add	x20, x20, #0x1
    5244:	f9002ff4 	str	x20, [sp, #88]
    5248:	eb13029f 	cmp	x20, x19
    524c:	54000360 	b.eq	52b8 <fwp_loop_fields68.constprop.0+0x3c8>  // b.none
    5250:	f8747b55 	ldr	x21, [x26, x20, lsl #3]
    5254:	f949db61 	ldr	x1, [x27, #5040]
    5258:	f949ef60 	ldr	x0, [x27, #5080]
    525c:	cb0102a1 	sub	x1, x21, x1
    5260:	eb00403f 	cmp	x1, x0, lsl #16
    5264:	54fffe62 	b.cs	5230 <fwp_loop_fields68.constprop.0+0x340>  // b.hs, b.nlast
    5268:	d350fc23 	lsr	x3, x1, #16
    526c:	f949ff65 	ldr	x5, [x27, #5112]
    5270:	8b030863 	add	x3, x3, x3, lsl #2
    5274:	d37df063 	lsl	x3, x3, #3
    5278:	8b0300a4 	add	x4, x5, x3
    527c:	f9401080 	ldr	x0, [x4, #32]
    5280:	b4fffd80 	cbz	x0, 5230 <fwp_loop_fields68.constprop.0+0x340>
    5284:	386368a3 	ldrb	w3, [x5, x3]
    5288:	7100087f 	cmp	w3, #0x2
    528c:	54fffb41 	b.ne	51f4 <fwp_loop_fields68.constprop.0+0x304>  // b.any
    5290:	72003c3f 	tst	w1, #0xffff
    5294:	54fffc20 	b.eq	5218 <fwp_loop_fields68.constprop.0+0x328>  // b.none
    5298:	f94006b8 	ldr	x24, [x21, #8]
    529c:	aa1503e0 	mov	x0, x21
    52a0:	97fffbe4 	bl	4230 <fwp_drop4>
    52a4:	f8347b58 	str	x24, [x26, x20, lsl #3]
    52a8:	91000694 	add	x20, x20, #0x1
    52ac:	f9002ff4 	str	x20, [sp, #88]
    52b0:	eb13029f 	cmp	x20, x19
    52b4:	54fffce1 	b.ne	5250 <fwp_loop_fields68.constprop.0+0x360>  // b.any
    52b8:	aa1603e0 	mov	x0, x22
    52bc:	97fffb8a 	bl	40e4 <fwp_map_finish_protected.isra.0>
    52c0:	aa1603e1 	mov	x1, x22
    52c4:	f9001be0 	str	x0, [sp, #48]
    52c8:	97fffa06 	bl	3ae0 <fwp_map_items>
    52cc:	f90017e0 	str	x0, [sp, #40]
    52d0:	f9400be2 	ldr	x2, [sp, #16]
    52d4:	f949db61 	ldr	x1, [x27, #5040]
    52d8:	f949ef60 	ldr	x0, [x27, #5080]
    52dc:	cb010041 	sub	x1, x2, x1
    52e0:	eb00403f 	cmp	x1, x0, lsl #16
    52e4:	54000342 	b.cs	534c <fwp_loop_fields68.constprop.0+0x45c>  // b.hs, b.nlast
    52e8:	d350fc20 	lsr	x0, x1, #16
    52ec:	f949ff65 	ldr	x5, [x27, #5112]
    52f0:	8b000800 	add	x0, x0, x0, lsl #2
    52f4:	d37df003 	lsl	x3, x0, #3
    52f8:	8b0300a4 	add	x4, x5, x3
    52fc:	f9401080 	ldr	x0, [x4, #32]
    5300:	b4000260 	cbz	x0, 534c <fwp_loop_fields68.constprop.0+0x45c>
    5304:	386368a3 	ldrb	w3, [x5, x3]
    5308:	7100087f 	cmp	w3, #0x2
    530c:	54002880 	b.eq	581c <fwp_loop_fields68.constprop.0+0x92c>  // b.none
    5310:	7100047f 	cmp	w3, #0x1
    5314:	540001c1 	b.ne	534c <fwp_loop_fields68.constprop.0+0x45c>  // b.any
    5318:	29430c85 	ldp	w5, w3, [x4, #24]
    531c:	92403c21 	and	x1, x1, #0xffff
    5320:	9b057c21 	mul	x1, x1, x5
    5324:	d360fc21 	lsr	x1, x1, #32
    5328:	eb03003f 	cmp	x1, x3
    532c:	54000102 	b.cs	534c <fwp_loop_fields68.constprop.0+0x45c>  // b.hs, b.nlast
    5330:	8b010000 	add	x0, x0, x1
    5334:	39400001 	ldrb	w1, [x0]
    5338:	340000a1 	cbz	w1, 534c <fwp_loop_fields68.constprop.0+0x45c>
    533c:	7103f43f 	cmp	w1, #0xfd
    5340:	54003508 	b.hi	59e0 <fwp_loop_fields68.constprop.0+0xaf0>  // b.pmore
    5344:	11000421 	add	w1, w1, #0x1
    5348:	39000001 	strb	w1, [x0]
    534c:	f9402bf8 	ldr	x24, [sp, #80]
    5350:	f9400bf3 	ldr	x19, [sp, #16]
    5354:	b4000538 	cbz	x24, 53f8 <fwp_loop_fields68.constprop.0+0x508>
    5358:	f94017e0 	ldr	x0, [sp, #40]
    535c:	910263f4 	add	x20, sp, #0x98
    5360:	5280003a 	mov	w26, #0x1                   	// #1
    5364:	d1002015 	sub	x21, x0, #0x8
    5368:	f8787aa3 	ldr	x3, [x21, x24, lsl #3]
    536c:	aa1403e1 	mov	x1, x20
    5370:	52800020 	mov	w0, #0x1                   	// #1
    5374:	a909cfe3 	stp	x3, x19, [sp, #152]
    5378:	97fffb13 	bl	3fc4 <fwp_data.part.0.constprop.0>
    537c:	aa0003f3 	mov	x19, x0
    5380:	f949db61 	ldr	x1, [x27, #5040]
    5384:	f949ef60 	ldr	x0, [x27, #5080]
    5388:	cb010261 	sub	x1, x19, x1
    538c:	eb00403f 	cmp	x1, x0, lsl #16
    5390:	54000302 	b.cs	53f0 <fwp_loop_fields68.constprop.0+0x500>  // b.hs, b.nlast
    5394:	d350fc20 	lsr	x0, x1, #16
    5398:	f949ff66 	ldr	x6, [x27, #5112]
    539c:	8b000800 	add	x0, x0, x0, lsl #2
    53a0:	d37df003 	lsl	x3, x0, #3
    53a4:	8b0300c5 	add	x5, x6, x3
    53a8:	f94010bc 	ldr	x28, [x5, #32]
    53ac:	b400023c 	cbz	x28, 53f0 <fwp_loop_fields68.constprop.0+0x500>
    53b0:	386368c3 	ldrb	w3, [x6, x3]
    53b4:	7100087f 	cmp	w3, #0x2
    53b8:	540021a0 	b.eq	57ec <fwp_loop_fields68.constprop.0+0x8fc>  // b.none
    53bc:	7100047f 	cmp	w3, #0x1
    53c0:	54000181 	b.ne	53f0 <fwp_loop_fields68.constprop.0+0x500>  // b.any
    53c4:	29430ca6 	ldp	w6, w3, [x5, #24]
    53c8:	92403c21 	and	x1, x1, #0xffff
    53cc:	9b067c21 	mul	x1, x1, x6
    53d0:	d360fc21 	lsr	x1, x1, #32
    53d4:	eb03003f 	cmp	x1, x3
    53d8:	540000c2 	b.cs	53f0 <fwp_loop_fields68.constprop.0+0x500>  // b.hs, b.nlast
    53dc:	8b01039c 	add	x28, x28, x1
    53e0:	39400381 	ldrb	w1, [x28]
    53e4:	7103fc3f 	cmp	w1, #0xff
    53e8:	54001fc0 	b.eq	57e0 <fwp_loop_fields68.constprop.0+0x8f0>  // b.none
    53ec:	3900039a 	strb	w26, [x28]
    53f0:	f1000718 	subs	x24, x24, #0x1
    53f4:	54fffba1 	b.ne	5368 <fwp_loop_fields68.constprop.0+0x478>  // b.any
    53f8:	f94017e0 	ldr	x0, [sp, #40]
    53fc:	b4000040 	cbz	x0, 5404 <fwp_loop_fields68.constprop.0+0x514>
    5400:	97fff6f4 	bl	2fd0 <fwp_mem_free>
    5404:	f9400be0 	ldr	x0, [sp, #16]
    5408:	d2800015 	mov	x21, #0x0                   	// #0
    540c:	97fffd29 	bl	48b0 <fwp_drop0>
    5410:	f9401be0 	ldr	x0, [sp, #48]
    5414:	97fffd27 	bl	48b0 <fwp_drop0>
    5418:	f94007e1 	ldr	x1, [sp, #8]
    541c:	aa1703e0 	mov	x0, x23
    5420:	97fff9b0 	bl	3ae0 <fwp_map_items>
    5424:	aa0003fa 	mov	x26, x0
    5428:	f94027f4 	ldr	x20, [sp, #72]
    542c:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x3c>
    5430:	9122c000 	add	x0, x0, #0x8b0
    5434:	f9002bfa 	str	x26, [sp, #80]
    5438:	a905ffff 	stp	xzr, xzr, [sp, #88]
    543c:	a90683ff 	stp	xzr, x0, [sp, #104]
    5440:	b5000334 	cbnz	x20, 54a4 <fwp_loop_fields68.constprop.0+0x5b4>
    5444:	14000033 	b	5510 <fwp_loop_fields68.constprop.0+0x620>
    5448:	7100047f 	cmp	w3, #0x1
    544c:	540001c1 	b.ne	5484 <fwp_loop_fields68.constprop.0+0x594>  // b.any
    5450:	29430c85 	ldp	w5, w3, [x4, #24]
    5454:	92403c21 	and	x1, x1, #0xffff
    5458:	9b057c21 	mul	x1, x1, x5
    545c:	d360fc21 	lsr	x1, x1, #32
    5460:	eb03003f 	cmp	x1, x3
    5464:	54000102 	b.cs	5484 <fwp_loop_fields68.constprop.0+0x594>  // b.hs, b.nlast
    5468:	8b010000 	add	x0, x0, x1
    546c:	39400001 	ldrb	w1, [x0]
    5470:	340000a1 	cbz	w1, 5484 <fwp_loop_fields68.constprop.0+0x594>
    5474:	7103f43f 	cmp	w1, #0xfd
    5478:	54001ca8 	b.hi	580c <fwp_loop_fields68.constprop.0+0x91c>  // b.pmore
    547c:	11000421 	add	w1, w1, #0x1
    5480:	39000001 	strb	w1, [x0]
    5484:	f9400b1c 	ldr	x28, [x24, #16]
    5488:	aa1803e0 	mov	x0, x24
    548c:	97fffb69 	bl	4230 <fwp_drop4>
    5490:	f8357b5c 	str	x28, [x26, x21, lsl #3]
    5494:	910006b5 	add	x21, x21, #0x1
    5498:	f9002ff5 	str	x21, [sp, #88]
    549c:	eb1402bf 	cmp	x21, x20
    54a0:	54000380 	b.eq	5510 <fwp_loop_fields68.constprop.0+0x620>  // b.none
    54a4:	f8757b58 	ldr	x24, [x26, x21, lsl #3]
    54a8:	f949db61 	ldr	x1, [x27, #5040]
    54ac:	f949ef60 	ldr	x0, [x27, #5080]
    54b0:	cb010301 	sub	x1, x24, x1
    54b4:	eb00403f 	cmp	x1, x0, lsl #16
    54b8:	54fffe62 	b.cs	5484 <fwp_loop_fields68.constprop.0+0x594>  // b.hs, b.nlast
    54bc:	d350fc23 	lsr	x3, x1, #16
    54c0:	f949ff65 	ldr	x5, [x27, #5112]
    54c4:	8b030863 	add	x3, x3, x3, lsl #2
    54c8:	d37df063 	lsl	x3, x3, #3
    54cc:	8b0300a4 	add	x4, x5, x3
    54d0:	f9401080 	ldr	x0, [x4, #32]
    54d4:	b4fffd80 	cbz	x0, 5484 <fwp_loop_fields68.constprop.0+0x594>
    54d8:	386368a3 	ldrb	w3, [x5, x3]
    54dc:	7100087f 	cmp	w3, #0x2
    54e0:	54fffb41 	b.ne	5448 <fwp_loop_fields68.constprop.0+0x558>  // b.any
    54e4:	72003c3f 	tst	w1, #0xffff
    54e8:	54fffc20 	b.eq	546c <fwp_loop_fields68.constprop.0+0x57c>  // b.none
    54ec:	f9400b1c 	ldr	x28, [x24, #16]
    54f0:	aa1803e0 	mov	x0, x24
    54f4:	97fffb4f 	bl	4230 <fwp_drop4>
    54f8:	f8357b5c 	str	x28, [x26, x21, lsl #3]
    54fc:	910006b5 	add	x21, x21, #0x1
    5500:	f9002ff5 	str	x21, [sp, #88]
    5504:	eb1402bf 	cmp	x21, x20
    5508:	54fffce1 	b.ne	54a4 <fwp_loop_fields68.constprop.0+0x5b4>  // b.any
    550c:	d503201f 	nop
    5510:	aa1603e0 	mov	x0, x22
    5514:	97fffaf4 	bl	40e4 <fwp_map_finish_protected.isra.0>
    5518:	f949db61 	ldr	x1, [x27, #5040]
    551c:	aa0003f5 	mov	x21, x0
    5520:	f949ef60 	ldr	x0, [x27, #5080]
    5524:	cb0102e1 	sub	x1, x23, x1
    5528:	eb00403f 	cmp	x1, x0, lsl #16
    552c:	540003a2 	b.cs	55a0 <fwp_loop_fields68.constprop.0+0x6b0>  // b.hs, b.nlast
    5530:	d350fc23 	lsr	x3, x1, #16
    5534:	f949ff64 	ldr	x4, [x27, #5112]
    5538:	8b030863 	add	x3, x3, x3, lsl #2
    553c:	d37df063 	lsl	x3, x3, #3
    5540:	8b030080 	add	x0, x4, x3
    5544:	f9401014 	ldr	x20, [x0, #32]
    5548:	b40002d4 	cbz	x20, 55a0 <fwp_loop_fields68.constprop.0+0x6b0>
    554c:	38636883 	ldrb	w3, [x4, x3]
    5550:	7100087f 	cmp	w3, #0x2
    5554:	54001560 	b.eq	5800 <fwp_loop_fields68.constprop.0+0x910>  // b.none
    5558:	7100047f 	cmp	w3, #0x1
    555c:	54000221 	b.ne	55a0 <fwp_loop_fields68.constprop.0+0x6b0>  // b.any
    5560:	29430003 	ldp	w3, w0, [x0, #24]
    5564:	92403c21 	and	x1, x1, #0xffff
    5568:	9b037c21 	mul	x1, x1, x3
    556c:	d360fc21 	lsr	x1, x1, #32
    5570:	eb00003f 	cmp	x1, x0
    5574:	54000162 	b.cs	55a0 <fwp_loop_fields68.constprop.0+0x6b0>  // b.hs, b.nlast
    5578:	8b010294 	add	x20, x20, x1
    557c:	39400280 	ldrb	w0, [x20]
    5580:	34000100 	cbz	w0, 55a0 <fwp_loop_fields68.constprop.0+0x6b0>
    5584:	7100041f 	cmp	w0, #0x1
    5588:	540016c0 	b.eq	5860 <fwp_loop_fields68.constprop.0+0x970>  // b.none
    558c:	7103fc1f 	cmp	w0, #0xff
    5590:	54001f60 	b.eq	597c <fwp_loop_fields68.constprop.0+0xa8c>  // b.none
    5594:	51000400 	sub	w0, w0, #0x1
    5598:	39000280 	strb	w0, [x20]
    559c:	d503201f 	nop
    55a0:	910263e1 	add	x1, sp, #0x98
    55a4:	52800020 	mov	w0, #0x1                   	// #1
    55a8:	a909d7ff 	stp	xzr, x21, [sp, #152]
    55ac:	97fffa86 	bl	3fc4 <fwp_data.part.0.constprop.0>
    55b0:	aa0003f4 	mov	x20, x0
    55b4:	f949db61 	ldr	x1, [x27, #5040]
    55b8:	f949ef60 	ldr	x0, [x27, #5080]
    55bc:	cb010281 	sub	x1, x20, x1
    55c0:	eb00403f 	cmp	x1, x0, lsl #16
    55c4:	54000322 	b.cs	5628 <fwp_loop_fields68.constprop.0+0x738>  // b.hs, b.nlast
    55c8:	d350fc20 	lsr	x0, x1, #16
    55cc:	f949ff64 	ldr	x4, [x27, #5112]
    55d0:	8b000800 	add	x0, x0, x0, lsl #2
    55d4:	d37df003 	lsl	x3, x0, #3
    55d8:	8b030080 	add	x0, x4, x3
    55dc:	f9401015 	ldr	x21, [x0, #32]
    55e0:	b4000255 	cbz	x21, 5628 <fwp_loop_fields68.constprop.0+0x738>
    55e4:	38636883 	ldrb	w3, [x4, x3]
    55e8:	7100087f 	cmp	w3, #0x2
    55ec:	54001340 	b.eq	5854 <fwp_loop_fields68.constprop.0+0x964>  // b.none
    55f0:	7100047f 	cmp	w3, #0x1
    55f4:	540001a1 	b.ne	5628 <fwp_loop_fields68.constprop.0+0x738>  // b.any
    55f8:	29430003 	ldp	w3, w0, [x0, #24]
    55fc:	92403c21 	and	x1, x1, #0xffff
    5600:	9b037c21 	mul	x1, x1, x3
    5604:	d360fc21 	lsr	x1, x1, #32
    5608:	eb00003f 	cmp	x1, x0
    560c:	540000e2 	b.cs	5628 <fwp_loop_fields68.constprop.0+0x738>  // b.hs, b.nlast
    5610:	8b0102b5 	add	x21, x21, x1
    5614:	394002a0 	ldrb	w0, [x21]
    5618:	7103fc1f 	cmp	w0, #0xff
    561c:	54001a40 	b.eq	5964 <fwp_loop_fields68.constprop.0+0xa74>  // b.none
    5620:	52800020 	mov	w0, #0x1                   	// #1
    5624:	390002a0 	strb	w0, [x21]
    5628:	f94013e1 	ldr	x1, [sp, #32]
    562c:	aa1403e0 	mov	x0, x20
    5630:	97fff92c 	bl	3ae0 <fwp_map_items>
    5634:	aa0003f5 	mov	x21, x0
    5638:	f94007e1 	ldr	x1, [sp, #8]
    563c:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x3c>
    5640:	9122c003 	add	x3, x0, #0x8b0
    5644:	aa1303e0 	mov	x0, x19
    5648:	f9002bf5 	str	x21, [sp, #80]
    564c:	a905ffff 	stp	xzr, xzr, [sp, #88]
    5650:	a9068fff 	stp	xzr, x3, [sp, #104]
    5654:	97fff923 	bl	3ae0 <fwp_map_items>
    5658:	a9440fe1 	ldp	x1, x3, [sp, #64]
    565c:	eb01007f 	cmp	x3, x1
    5660:	9a819063 	csel	x3, x3, x1, ls	// ls = plast
    5664:	b40017c3 	cbz	x3, 595c <fwp_loop_fields68.constprop.0+0xa6c>
    5668:	d2800001 	mov	x1, #0x0                   	// #0
    566c:	d503201f 	nop
    5670:	fc617800 	ldr	d0, [x0, x1, lsl #3]
    5674:	fc617aa1 	ldr	d1, [x21, x1, lsl #3]
    5678:	1e612800 	fadd	d0, d0, d1
    567c:	fc217aa0 	str	d0, [x21, x1, lsl #3]
    5680:	91000421 	add	x1, x1, #0x1
    5684:	eb01007f 	cmp	x3, x1
    5688:	54ffff41 	b.ne	5670 <fwp_loop_fields68.constprop.0+0x780>  // b.any
    568c:	f9002fe3 	str	x3, [sp, #88]
    5690:	97fff650 	bl	2fd0 <fwp_mem_free>
    5694:	aa1603e0 	mov	x0, x22
    5698:	97fffa93 	bl	40e4 <fwp_map_finish_protected.isra.0>
    569c:	aa0003e1 	mov	x1, x0
    56a0:	aa1303e0 	mov	x0, x19
    56a4:	aa0103f3 	mov	x19, x1
    56a8:	97fffc82 	bl	48b0 <fwp_drop0>
    56ac:	aa1403e0 	mov	x0, x20
    56b0:	97fffc80 	bl	48b0 <fwp_drop0>
    56b4:	f94007e1 	ldr	x1, [sp, #8]
    56b8:	aa1303e0 	mov	x0, x19
    56bc:	97fff909 	bl	3ae0 <fwp_map_items>
    56c0:	f9002be0 	str	x0, [sp, #80]
    56c4:	f94027e3 	ldr	x3, [sp, #72]
    56c8:	f0ffffe1 	adrp	x1, 4000 <fwp_data.part.0.constprop.0+0x3c>
    56cc:	9122c021 	add	x1, x1, #0x8b0
    56d0:	a905ffff 	stp	xzr, xzr, [sp, #88]
    56d4:	a90687ff 	stp	xzr, x1, [sp, #104]
    56d8:	b4000103 	cbz	x3, 56f8 <fwp_loop_fields68.constprop.0+0x808>
    56dc:	8b030c01 	add	x1, x0, x3, lsl #3
    56e0:	fd400000 	ldr	d0, [x0]
    56e4:	1e600960 	fmul	d0, d11, d0
    56e8:	fc008400 	str	d0, [x0], #8
    56ec:	eb01001f 	cmp	x0, x1
    56f0:	54ffff81 	b.ne	56e0 <fwp_loop_fields68.constprop.0+0x7f0>  // b.any
    56f4:	f9002fe3 	str	x3, [sp, #88]
    56f8:	aa1603e0 	mov	x0, x22
    56fc:	97fffa7a 	bl	40e4 <fwp_map_finish_protected.isra.0>
    5700:	aa0003e1 	mov	x1, x0
    5704:	aa1303e0 	mov	x0, x19
    5708:	aa0103f3 	mov	x19, x1
    570c:	97fffc69 	bl	48b0 <fwp_drop0>
    5710:	f94013e1 	ldr	x1, [sp, #32]
    5714:	aa1903e0 	mov	x0, x25
    5718:	97fff8f2 	bl	3ae0 <fwp_map_items>
    571c:	aa0003f4 	mov	x20, x0
    5720:	f94007e1 	ldr	x1, [sp, #8]
    5724:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x3c>
    5728:	9122c003 	add	x3, x0, #0x8b0
    572c:	aa1303e0 	mov	x0, x19
    5730:	f9002bf4 	str	x20, [sp, #80]
    5734:	a905ffff 	stp	xzr, xzr, [sp, #88]
    5738:	a9068fff 	stp	xzr, x3, [sp, #104]
    573c:	97fff8e9 	bl	3ae0 <fwp_map_items>
    5740:	a9440fe1 	ldp	x1, x3, [sp, #64]
    5744:	eb01007f 	cmp	x3, x1
    5748:	9a819063 	csel	x3, x3, x1, ls	// ls = plast
    574c:	b4001043 	cbz	x3, 5954 <fwp_loop_fields68.constprop.0+0xa64>
    5750:	d2800001 	mov	x1, #0x0                   	// #0
    5754:	d503201f 	nop
    5758:	fc617a80 	ldr	d0, [x20, x1, lsl #3]
    575c:	fc617801 	ldr	d1, [x0, x1, lsl #3]
    5760:	1e613800 	fsub	d0, d0, d1
    5764:	fc217a80 	str	d0, [x20, x1, lsl #3]
    5768:	91000421 	add	x1, x1, #0x1
    576c:	eb01007f 	cmp	x3, x1
    5770:	54ffff41 	b.ne	5758 <fwp_loop_fields68.constprop.0+0x868>  // b.any
    5774:	f9002fe3 	str	x3, [sp, #88]
    5778:	97fff616 	bl	2fd0 <fwp_mem_free>
    577c:	aa1603e0 	mov	x0, x22
    5780:	97fffa59 	bl	40e4 <fwp_map_finish_protected.isra.0>
    5784:	aa0003e1 	mov	x1, x0
    5788:	aa1303e0 	mov	x0, x19
    578c:	aa0103f3 	mov	x19, x1
    5790:	97fffc48 	bl	48b0 <fwp_drop0>
    5794:	aa1903e0 	mov	x0, x25
    5798:	97fffc46 	bl	48b0 <fwp_drop0>
    579c:	f9400fe0 	ldr	x0, [sp, #24]
    57a0:	b4000b60 	cbz	x0, 590c <fwp_loop_fields68.constprop.0+0xa1c>
    57a4:	f9400fe0 	ldr	x0, [sp, #24]
    57a8:	f1000400 	subs	x0, x0, #0x1
    57ac:	f9000fe0 	str	x0, [sp, #24]
    57b0:	54001246 	b.vs	59f8 <fwp_loop_fields68.constprop.0+0xb08>
    57b4:	aa1303f9 	mov	x25, x19
    57b8:	b5ffbe19 	cbnz	x25, 4f78 <fwp_loop_fields68.constprop.0+0x88>
    57bc:	f9000bff 	str	xzr, [sp, #16]
    57c0:	17fffdf0 	b	4f80 <fwp_loop_fields68.constprop.0+0x90>
    57c4:	f90017e0 	str	x0, [sp, #40]
    57c8:	97fff562 	bl	2d50 <fwp_rc_forget_slot>
    57cc:	f94017e0 	ldr	x0, [sp, #40]
    57d0:	17fffe4c 	b	5100 <fwp_loop_fields68.constprop.0+0x210>
    57d4:	72003c3f 	tst	w1, #0xffff
    57d8:	54ffc961 	b.ne	5104 <fwp_loop_fields68.constprop.0+0x214>  // b.any
    57dc:	17fffe46 	b	50f4 <fwp_loop_fields68.constprop.0+0x204>
    57e0:	aa1c03e0 	mov	x0, x28
    57e4:	97fff55b 	bl	2d50 <fwp_rc_forget_slot>
    57e8:	17ffff01 	b	53ec <fwp_loop_fields68.constprop.0+0x4fc>
    57ec:	72003c3f 	tst	w1, #0xffff
    57f0:	54ffe001 	b.ne	53f0 <fwp_loop_fields68.constprop.0+0x500>  // b.any
    57f4:	17fffefb 	b	53e0 <fwp_loop_fields68.constprop.0+0x4f0>
    57f8:	b4ffc940 	cbz	x0, 5120 <fwp_loop_fields68.constprop.0+0x230>
    57fc:	17fffe47 	b	5118 <fwp_loop_fields68.constprop.0+0x228>
    5800:	72003c3f 	tst	w1, #0xffff
    5804:	54ffece1 	b.ne	55a0 <fwp_loop_fields68.constprop.0+0x6b0>  // b.any
    5808:	17ffff5d 	b	557c <fwp_loop_fields68.constprop.0+0x68c>
    580c:	97fff50a 	bl	2c34 <fwp_rc_wide_dup>
    5810:	17ffff1d 	b	5484 <fwp_loop_fields68.constprop.0+0x594>
    5814:	97fff508 	bl	2c34 <fwp_rc_wide_dup>
    5818:	17fffe86 	b	5230 <fwp_loop_fields68.constprop.0+0x340>
    581c:	72003c3f 	tst	w1, #0xffff
    5820:	54ffd961 	b.ne	534c <fwp_loop_fields68.constprop.0+0x45c>  // b.any
    5824:	17fffec4 	b	5334 <fwp_loop_fields68.constprop.0+0x444>
    5828:	72003c3f 	tst	w1, #0xffff
    582c:	54ffcca1 	b.ne	51c0 <fwp_loop_fields68.constprop.0+0x2d0>  // b.any
    5830:	39400260 	ldrb	w0, [x19]
    5834:	7103fc1f 	cmp	w0, #0xff
    5838:	54ffcc01 	b.ne	51b8 <fwp_loop_fields68.constprop.0+0x2c8>  // b.any
    583c:	aa1303e0 	mov	x0, x19
    5840:	97fff544 	bl	2d50 <fwp_rc_forget_slot>
    5844:	17fffe5d 	b	51b8 <fwp_loop_fields68.constprop.0+0x2c8>
    5848:	72003c3f 	tst	w1, #0xffff
    584c:	54ffbd81 	b.ne	4ffc <fwp_loop_fields68.constprop.0+0x10c>  // b.any
    5850:	17fffde5 	b	4fe4 <fwp_loop_fields68.constprop.0+0xf4>
    5854:	72003c3f 	tst	w1, #0xffff
    5858:	54ffee81 	b.ne	5628 <fwp_loop_fields68.constprop.0+0x738>  // b.any
    585c:	17ffff6e 	b	5614 <fwp_loop_fields68.constprop.0+0x724>
    5860:	f94006e0 	ldr	x0, [x23, #8]
    5864:	97fffa73 	bl	4230 <fwp_drop4>
    5868:	f949ef64 	ldr	x4, [x27, #5080]
    586c:	f949db61 	ldr	x1, [x27, #5040]
    5870:	d370bc84 	lsl	x4, x4, #16
    5874:	cb0102e3 	sub	x3, x23, x1
    5878:	f9400af4 	ldr	x20, [x23, #16]
    587c:	eb04007f 	cmp	x3, x4
    5880:	540003c2 	b.cs	58f8 <fwp_loop_fields68.constprop.0+0xa08>  // b.hs, b.nlast
    5884:	d350fc60 	lsr	x0, x3, #16
    5888:	f949ff67 	ldr	x7, [x27, #5112]
    588c:	8b000800 	add	x0, x0, x0, lsl #2
    5890:	d37df000 	lsl	x0, x0, #3
    5894:	8b0000e6 	add	x6, x7, x0
    5898:	f94010c5 	ldr	x5, [x6, #32]
    589c:	b40002e5 	cbz	x5, 58f8 <fwp_loop_fields68.constprop.0+0xa08>
    58a0:	386068e0 	ldrb	w0, [x7, x0]
    58a4:	7100081f 	cmp	w0, #0x2
    58a8:	54000640 	b.eq	5970 <fwp_loop_fields68.constprop.0+0xa80>  // b.none
    58ac:	7100041f 	cmp	w0, #0x1
    58b0:	54000241 	b.ne	58f8 <fwp_loop_fields68.constprop.0+0xa08>  // b.any
    58b4:	92403c60 	and	x0, x3, #0xffff
    58b8:	29430cc7 	ldp	w7, w3, [x6, #24]
    58bc:	9b077c00 	mul	x0, x0, x7
    58c0:	d360fc00 	lsr	x0, x0, #32
    58c4:	eb03001f 	cmp	x0, x3
    58c8:	54000182 	b.cs	58f8 <fwp_loop_fields68.constprop.0+0xa08>  // b.hs, b.nlast
    58cc:	8b0000a5 	add	x5, x5, x0
    58d0:	394000a0 	ldrb	w0, [x5]
    58d4:	7100041f 	cmp	w0, #0x1
    58d8:	54000101 	b.ne	58f8 <fwp_loop_fields68.constprop.0+0xa08>  // b.any
    58dc:	aa1703e0 	mov	x0, x23
    58e0:	97fff5bc 	bl	2fd0 <fwp_mem_free>
    58e4:	90000160 	adrp	x0, 31000 <fwp_root_context+0xd10>
    58e8:	91134000 	add	x0, x0, #0x4d0
    58ec:	f949ec04 	ldr	x4, [x0, #5080]
    58f0:	f949d801 	ldr	x1, [x0, #5040]
    58f4:	d370bc84 	lsl	x4, x4, #16
    58f8:	cb010281 	sub	x1, x20, x1
    58fc:	eb01009f 	cmp	x4, x1
    5900:	54ffe509 	b.ls	55a0 <fwp_loop_fields68.constprop.0+0x6b0>  // b.plast
    5904:	aa1403f7 	mov	x23, x20
    5908:	17ffff0a 	b	5530 <fwp_loop_fields68.constprop.0+0x640>
    590c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    5910:	f947f400 	ldr	x0, [x0, #4072]
    5914:	f94057e2 	ldr	x2, [sp, #168]
    5918:	f9400001 	ldr	x1, [x0]
    591c:	eb010042 	subs	x2, x2, x1
    5920:	d2800001 	mov	x1, #0x0                   	// #0
    5924:	54000681 	b.ne	59f4 <fwp_loop_fields68.constprop.0+0xb04>  // b.any
    5928:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    592c:	aa1303e0 	mov	x0, x19
    5930:	a94c53f3 	ldp	x19, x20, [sp, #192]
    5934:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    5938:	a94e63f7 	ldp	x23, x24, [sp, #224]
    593c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    5940:	a95073fb 	ldp	x27, x28, [sp, #256]
    5944:	6d5127e8 	ldp	d8, d9, [sp, #272]
    5948:	6d522fea 	ldp	d10, d11, [sp, #288]
    594c:	9104c3ff 	add	sp, sp, #0x130
    5950:	d65f03c0 	ret
    5954:	b4fff140 	cbz	x0, 577c <fwp_loop_fields68.constprop.0+0x88c>
    5958:	17ffff88 	b	5778 <fwp_loop_fields68.constprop.0+0x888>
    595c:	b4ffe9c0 	cbz	x0, 5694 <fwp_loop_fields68.constprop.0+0x7a4>
    5960:	17ffff4c 	b	5690 <fwp_loop_fields68.constprop.0+0x7a0>
    5964:	aa1503e0 	mov	x0, x21
    5968:	97fff4fa 	bl	2d50 <fwp_rc_forget_slot>
    596c:	17ffff2d 	b	5620 <fwp_loop_fields68.constprop.0+0x730>
    5970:	72003c7f 	tst	w3, #0xffff
    5974:	54fffc21 	b.ne	58f8 <fwp_loop_fields68.constprop.0+0xa08>  // b.any
    5978:	17ffffd6 	b	58d0 <fwp_loop_fields68.constprop.0+0x9e0>
    597c:	ca544680 	eor	x0, x20, x20, lsr #17
    5980:	90000161 	adrp	x1, 31000 <fwp_root_context+0xd10>
    5984:	91134021 	add	x1, x1, #0x4d0
    5988:	ca402400 	eor	x0, x0, x0, lsr #9
    598c:	8b200c20 	add	x0, x1, w0, uxtb #3
    5990:	f94a2400 	ldr	x0, [x0, #5192]
    5994:	b5000080 	cbnz	x0, 59a4 <fwp_loop_fields68.constprop.0+0xab4>
    5998:	14000014 	b	59e8 <fwp_loop_fields68.constprop.0+0xaf8>
    599c:	f9400800 	ldr	x0, [x0, #16]
    59a0:	b4000240 	cbz	x0, 59e8 <fwp_loop_fields68.constprop.0+0xaf8>
    59a4:	f9400001 	ldr	x1, [x0]
    59a8:	eb01029f 	cmp	x20, x1
    59ac:	54ffff81 	b.ne	599c <fwp_loop_fields68.constprop.0+0xaac>  // b.any
    59b0:	f9400401 	ldr	x1, [x0, #8]
    59b4:	d1000421 	sub	x1, x1, #0x1
    59b8:	f9000401 	str	x1, [x0, #8]
    59bc:	f103f83f 	cmp	x1, #0xfe
    59c0:	54ffdf01 	b.ne	55a0 <fwp_loop_fields68.constprop.0+0x6b0>  // b.any
    59c4:	aa1403e0 	mov	x0, x20
    59c8:	97fff4e2 	bl	2d50 <fwp_rc_forget_slot>
    59cc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    59d0:	39000280 	strb	w0, [x20]
    59d4:	17fffef3 	b	55a0 <fwp_loop_fields68.constprop.0+0x6b0>
    59d8:	97fff497 	bl	2c34 <fwp_rc_wide_dup>
    59dc:	17fffd88 	b	4ffc <fwp_loop_fields68.constprop.0+0x10c>
    59e0:	97fff495 	bl	2c34 <fwp_rc_wide_dup>
    59e4:	17fffe5a 	b	534c <fwp_loop_fields68.constprop.0+0x45c>
    59e8:	90000020 	adrp	x0, 9000 <f0+0x2610>
    59ec:	9139c000 	add	x0, x0, #0xe70
    59f0:	97fff1cc 	bl	2120 <fwp_trap>
    59f4:	97ffeebf 	bl	14f0 <__stack_chk_fail@plt>
    59f8:	97ffef32 	bl	16c0 <fwp_trap_overflow.constprop.0>
    59fc:	d503201f 	nop

0000000000005a00 <fwp_write>:
    5a00:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5a04:	910003fd 	mov	x29, sp
    5a08:	d00000c4 	adrp	x4, 1f000 <__FRAME_END__+0x13c68>
    5a0c:	f947f484 	ldr	x4, [x4, #4072]
    5a10:	a90153f3 	stp	x19, x20, [sp, #16]
    5a14:	d10943ff 	sub	sp, sp, #0x250
    5a18:	b9400045 	ldr	w5, [x2]
    5a1c:	aa0003f4 	mov	x20, x0
    5a20:	f9400080 	ldr	x0, [x4]
    5a24:	f90127e0 	str	x0, [sp, #584]
    5a28:	d2800000 	mov	x0, #0x0                   	// #0
    5a2c:	710064bf 	cmp	w5, #0x19
    5a30:	54000408 	b.hi	5ab0 <fwp_write+0xb0>  // b.pmore
    5a34:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x380>
    5a38:	aa0103f3 	mov	x19, x1
    5a3c:	91050000 	add	x0, x0, #0x140
    5a40:	f9013bf5 	str	x21, [sp, #624]
    5a44:	f9013ff6 	str	x22, [sp, #632]
    5a48:	f90153fb 	str	x27, [sp, #672]
    5a4c:	f90157fc 	str	x28, [sp, #680]
    5a50:	aa0203fc 	mov	x28, x2
    5a54:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    5a58:	10000061 	adr	x1, 5a64 <fwp_write+0x64>
    5a5c:	8b20a820 	add	x0, x1, w0, sxth #2
    5a60:	d61f0000 	br	x0
    5a64:	910123e0 	add	x0, sp, #0x48
    5a68:	aa1303e5 	mov	x5, x19
    5a6c:	90000024 	adrp	x4, 9000 <f0+0x2610>
    5a70:	aa0003f3 	mov	x19, x0
    5a74:	913d0084 	add	x4, x4, #0xf40
    5a78:	d2804003 	mov	x3, #0x200                 	// #512
    5a7c:	aa0303e1 	mov	x1, x3
    5a80:	52800042 	mov	w2, #0x2                   	// #2
    5a84:	97ffee77 	bl	1460 <__snprintf_chk@plt>
    5a88:	aa1303e0 	mov	x0, x19
    5a8c:	97ffee3d 	bl	1380 <strlen@plt>
    5a90:	aa1303e1 	mov	x1, x19
    5a94:	aa0003e2 	mov	x2, x0
    5a98:	aa1403e0 	mov	x0, x20
    5a9c:	97fff145 	bl	1fb0 <buf_put>
    5aa0:	f9413bf5 	ldr	x21, [sp, #624]
    5aa4:	f9413ff6 	ldr	x22, [sp, #632]
    5aa8:	f94153fb 	ldr	x27, [sp, #672]
    5aac:	f94157fc 	ldr	x28, [sp, #680]
    5ab0:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    5ab4:	f947f400 	ldr	x0, [x0, #4072]
    5ab8:	f94127e2 	ldr	x2, [sp, #584]
    5abc:	f9400001 	ldr	x1, [x0]
    5ac0:	eb010042 	subs	x2, x2, x1
    5ac4:	d2800001 	mov	x1, #0x0                   	// #0
    5ac8:	540077c1 	b.ne	69c0 <fwp_write+0xfc0>  // b.any
    5acc:	910943ff 	add	sp, sp, #0x250
    5ad0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ad4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5ad8:	d65f03c0 	ret
    5adc:	910123e0 	add	x0, sp, #0x48
    5ae0:	aa1303e5 	mov	x5, x19
    5ae4:	90000024 	adrp	x4, 9000 <f0+0x2610>
    5ae8:	aa0003f3 	mov	x19, x0
    5aec:	913ce084 	add	x4, x4, #0xf38
    5af0:	d2804003 	mov	x3, #0x200                 	// #512
    5af4:	17ffffe2 	b	5a7c <fwp_write+0x7c>
    5af8:	71004cbf 	cmp	w5, #0x13
    5afc:	90000020 	adrp	x0, 9000 <f0+0x2610>
    5b00:	90000021 	adrp	x1, 9000 <f0+0x2610>
    5b04:	913ca000 	add	x0, x0, #0xf28
    5b08:	913cc021 	add	x1, x1, #0xf30
    5b0c:	d2800082 	mov	x2, #0x4                   	// #4
    5b10:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    5b14:	aa1403e0 	mov	x0, x20
    5b18:	f90143f7 	str	x23, [sp, #640]
    5b1c:	d2800016 	mov	x22, #0x0                   	// #0
    5b20:	f90147f8 	str	x24, [sp, #648]
    5b24:	97fff123 	bl	1fb0 <buf_put>
    5b28:	f9400260 	ldr	x0, [x19]
    5b2c:	90000037 	adrp	x23, 9000 <f0+0x2610>
    5b30:	d2800015 	mov	x21, #0x0                   	// #0
    5b34:	913ec2f7 	add	x23, x23, #0xfb0
    5b38:	b40047a0 	cbz	x0, 642c <fwp_write+0xa2c>
    5b3c:	b9400380 	ldr	w0, [x28]
    5b40:	52800003 	mov	w3, #0x0                   	// #0
    5b44:	f9401f82 	ldr	x2, [x28, #56]
    5b48:	71004c1f 	cmp	w0, #0x13
    5b4c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    5b50:	aa1403e0 	mov	x0, x20
    5b54:	8b010e61 	add	x1, x19, x1, lsl #3
    5b58:	f9400421 	ldr	x1, [x1, #8]
    5b5c:	97ffffa9 	bl	5a00 <fwp_write>
    5b60:	b9400380 	ldr	w0, [x28]
    5b64:	7100481f 	cmp	w0, #0x12
    5b68:	54004b40 	b.eq	64d0 <fwp_write+0xad0>  // b.none
    5b6c:	f9400260 	ldr	x0, [x19]
    5b70:	910006b5 	add	x21, x21, #0x1
    5b74:	91000ad6 	add	x22, x22, #0x2
    5b78:	eb15001f 	cmp	x0, x21
    5b7c:	54004589 	b.ls	642c <fwp_write+0xa2c>  // b.plast
    5b80:	aa1703e1 	mov	x1, x23
    5b84:	aa1403e0 	mov	x0, x20
    5b88:	d2800042 	mov	x2, #0x2                   	// #2
    5b8c:	97fff109 	bl	1fb0 <buf_put>
    5b90:	17ffffeb 	b	5b3c <fwp_write+0x13c>
    5b94:	90000021 	adrp	x1, 9000 <f0+0x2610>
    5b98:	913da021 	add	x1, x1, #0xf68
    5b9c:	d28000c2 	mov	x2, #0x6                   	// #6
    5ba0:	aa1403e0 	mov	x0, x20
    5ba4:	91004273 	add	x19, x19, #0x10
    5ba8:	97fff102 	bl	1fb0 <buf_put>
    5bac:	aa1303e0 	mov	x0, x19
    5bb0:	97ffedf4 	bl	1380 <strlen@plt>
    5bb4:	aa1303e1 	mov	x1, x19
    5bb8:	aa0003e2 	mov	x2, x0
    5bbc:	aa1403e0 	mov	x0, x20
    5bc0:	97fff0fc 	bl	1fb0 <buf_put>
    5bc4:	528007c3 	mov	w3, #0x3e                  	// #62
    5bc8:	aa1403e0 	mov	x0, x20
    5bcc:	91001fe1 	add	x1, sp, #0x7
    5bd0:	d2800022 	mov	x2, #0x1                   	// #1
    5bd4:	39001fe3 	strb	w3, [sp, #7]
    5bd8:	17ffffb1 	b	5a9c <fwp_write+0x9c>
    5bdc:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    5be0:	f947f400 	ldr	x0, [x0, #4072]
    5be4:	f94127e2 	ldr	x2, [sp, #584]
    5be8:	f9400001 	ldr	x1, [x0]
    5bec:	eb010042 	subs	x2, x2, x1
    5bf0:	d2800001 	mov	x1, #0x0                   	// #0
    5bf4:	540034e1 	b.ne	6290 <fwp_write+0x890>  // b.any
    5bf8:	f9413bf5 	ldr	x21, [sp, #624]
    5bfc:	90000021 	adrp	x1, 9000 <f0+0x2610>
    5c00:	f9413ff6 	ldr	x22, [sp, #632]
    5c04:	aa1403e0 	mov	x0, x20
    5c08:	913d2021 	add	x1, x1, #0xf48
    5c0c:	d2800142 	mov	x2, #0xa                   	// #10
    5c10:	f94153fb 	ldr	x27, [sp, #672]
    5c14:	f94157fc 	ldr	x28, [sp, #680]
    5c18:	910943ff 	add	sp, sp, #0x250
    5c1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c20:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5c24:	17fff0e3 	b	1fb0 <buf_put>
    5c28:	f9400456 	ldr	x22, [x2, #8]
    5c2c:	f90143f7 	str	x23, [sp, #640]
    5c30:	f90147f8 	str	x24, [sp, #648]
    5c34:	b4005b16 	cbz	x22, 6794 <fwp_write+0xd94>
    5c38:	aa1603e0 	mov	x0, x22
    5c3c:	90000021 	adrp	x1, 9000 <f0+0x2610>
    5c40:	913f2021 	add	x1, x1, #0xfc8
    5c44:	97ffee4b 	bl	1570 <strcmp@plt>
    5c48:	2a0003f5 	mov	w21, w0
    5c4c:	34005fe0 	cbz	w0, 6848 <fwp_write+0xe48>
    5c50:	aa1603e0 	mov	x0, x22
    5c54:	97ffedcb 	bl	1380 <strlen@plt>
    5c58:	aa1603e1 	mov	x1, x22
    5c5c:	aa0003e2 	mov	x2, x0
    5c60:	aa1403e0 	mov	x0, x20
    5c64:	97fff0d3 	bl	1fb0 <buf_put>
    5c68:	52800403 	mov	w3, #0x20                  	// #32
    5c6c:	91001ff5 	add	x21, sp, #0x7
    5c70:	aa1503e1 	mov	x1, x21
    5c74:	aa1403e0 	mov	x0, x20
    5c78:	d2800022 	mov	x2, #0x1                   	// #1
    5c7c:	39001fe3 	strb	w3, [sp, #7]
    5c80:	97fff0cc 	bl	1fb0 <buf_put>
    5c84:	52800f63 	mov	w3, #0x7b                  	// #123
    5c88:	aa1403e0 	mov	x0, x20
    5c8c:	aa1503e1 	mov	x1, x21
    5c90:	d2800022 	mov	x2, #0x1                   	// #1
    5c94:	39001fe3 	strb	w3, [sp, #7]
    5c98:	97fff0c6 	bl	1fb0 <buf_put>
    5c9c:	b9401380 	ldr	w0, [x28, #16]
    5ca0:	52800018 	mov	w24, #0x0                   	// #0
    5ca4:	7100001f 	cmp	w0, #0x0
    5ca8:	54003aad 	b.le	63fc <fwp_write+0x9fc>
    5cac:	f9014bf9 	str	x25, [sp, #656]
    5cb0:	90000039 	adrp	x25, 9000 <f0+0x2610>
    5cb4:	913fc339 	add	x25, x25, #0xff0
    5cb8:	f9014ffa 	str	x26, [sp, #664]
    5cbc:	9000003a 	adrp	x26, 9000 <f0+0x2610>
    5cc0:	913ec35a 	add	x26, x26, #0xfb0
    5cc4:	91002276 	add	x22, x19, #0x8
    5cc8:	d2800013 	mov	x19, #0x0                   	// #0
    5ccc:	b5003e93 	cbnz	x19, 649c <fwp_write+0xa9c>
    5cd0:	d37df277 	lsl	x23, x19, #3
    5cd4:	34003cb8 	cbz	w24, 6468 <fwp_write+0xa68>
    5cd8:	f9401382 	ldr	x2, [x28, #32]
    5cdc:	aa1403e0 	mov	x0, x20
    5ce0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    5ce4:	52800003 	mov	w3, #0x0                   	// #0
    5ce8:	f8776842 	ldr	x2, [x2, x23]
    5cec:	91000673 	add	x19, x19, #0x1
    5cf0:	97ffff44 	bl	5a00 <fwp_write>
    5cf4:	b9401380 	ldr	w0, [x28, #16]
    5cf8:	6b13001f 	cmp	w0, w19
    5cfc:	54fffe8c 	b.gt	5ccc <fwp_write+0x2cc>
    5d00:	f9414bf9 	ldr	x25, [sp, #656]
    5d04:	f9414ffa 	ldr	x26, [sp, #664]
    5d08:	340037b8 	cbz	w24, 63fc <fwp_write+0x9fc>
    5d0c:	52800523 	mov	w3, #0x29                  	// #41
    5d10:	aa1503e1 	mov	x1, x21
    5d14:	aa1403e0 	mov	x0, x20
    5d18:	d2800022 	mov	x2, #0x1                   	// #1
    5d1c:	39001fe3 	strb	w3, [sp, #7]
    5d20:	97fff0a4 	bl	1fb0 <buf_put>
    5d24:	f9413bf5 	ldr	x21, [sp, #624]
    5d28:	f9413ff6 	ldr	x22, [sp, #632]
    5d2c:	f94143f7 	ldr	x23, [sp, #640]
    5d30:	f94147f8 	ldr	x24, [sp, #648]
    5d34:	f94153fb 	ldr	x27, [sp, #672]
    5d38:	f94157fc 	ldr	x28, [sp, #680]
    5d3c:	17ffff5d 	b	5ab0 <fwp_write+0xb0>
    5d40:	b9404855 	ldr	w21, [x2, #72]
    5d44:	aa1403e0 	mov	x0, x20
    5d48:	93407eb6 	sxtw	x22, w21
    5d4c:	91000ac1 	add	x1, x22, #0x2
    5d50:	97fff064 	bl	1ee0 <buf_grow>
    5d54:	a9400281 	ldp	x1, x0, [x20]
    5d58:	528e8603 	mov	w3, #0x7430                	// #29744
    5d5c:	78206823 	strh	w3, [x1, x0]
    5d60:	8b000022 	add	x2, x1, x0
    5d64:	710002bf 	cmp	w21, #0x0
    5d68:	540036cd 	b.le	6440 <fwp_write+0xa40>
    5d6c:	110006a3 	add	w3, w21, #0x1
    5d70:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    5d74:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    5d78:	91000449 	add	x9, x2, #0x1
    5d7c:	8b23c043 	add	x3, x2, w3, sxtw
    5d80:	f28aaac6 	movk	x6, #0x5556
    5d84:	f2955568 	movk	x8, #0xaaab
    5d88:	1400000d 	b	5dbc <fwp_write+0x3bc>
    5d8c:	d2800021 	mov	x1, #0x1                   	// #1
    5d90:	528005a5 	mov	w5, #0x2d                  	// #45
    5d94:	f100001f 	cmp	x0, #0x0
    5d98:	9b467e60 	smulh	x0, x19, x6
    5d9c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    5da0:	381ff465 	strb	w5, [x3], #-1
    5da4:	cb040000 	sub	x0, x0, x4
    5da8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    5dac:	cb020000 	sub	x0, x0, x2
    5db0:	8b010013 	add	x19, x0, x1
    5db4:	eb03013f 	cmp	x9, x3
    5db8:	54003440 	b.eq	6440 <fwp_write+0xa40>  // b.none
    5dbc:	9b467e60 	smulh	x0, x19, x6
    5dc0:	937ffe64 	asr	x4, x19, #63
    5dc4:	52800605 	mov	w5, #0x30                  	// #48
    5dc8:	cb040000 	sub	x0, x0, x4
    5dcc:	8b000400 	add	x0, x0, x0, lsl #1
    5dd0:	cb000260 	sub	x0, x19, x0
    5dd4:	91000c01 	add	x1, x0, #0x3
    5dd8:	9bc87c22 	umulh	x2, x1, x8
    5ddc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    5de0:	8b4204e2 	add	x2, x7, x2, lsr #1
    5de4:	eb020021 	subs	x1, x1, x2
    5de8:	54fffd60 	b.eq	5d94 <fwp_write+0x394>  // b.none
    5dec:	f100043f 	cmp	x1, #0x1
    5df0:	54fffce1 	b.ne	5d8c <fwp_write+0x38c>  // b.any
    5df4:	d2800001 	mov	x1, #0x0                   	// #0
    5df8:	52800565 	mov	w5, #0x2b                  	// #43
    5dfc:	17ffffe6 	b	5d94 <fwp_write+0x394>
    5e00:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    5e04:	f947f400 	ldr	x0, [x0, #4072]
    5e08:	f94127e2 	ldr	x2, [sp, #584]
    5e0c:	f9400001 	ldr	x1, [x0]
    5e10:	eb010042 	subs	x2, x2, x1
    5e14:	d2800001 	mov	x1, #0x0                   	// #0
    5e18:	540023c1 	b.ne	6290 <fwp_write+0x890>  // b.any
    5e1c:	f9413bf5 	ldr	x21, [sp, #624]
    5e20:	90000021 	adrp	x1, 9000 <f0+0x2610>
    5e24:	f9413ff6 	ldr	x22, [sp, #632]
    5e28:	aa1403e0 	mov	x0, x20
    5e2c:	913d6021 	add	x1, x1, #0xf58
    5e30:	d2800102 	mov	x2, #0x8                   	// #8
    5e34:	17ffff77 	b	5c10 <fwp_write+0x210>
    5e38:	aa1403e0 	mov	x0, x20
    5e3c:	90000021 	adrp	x1, 9000 <f0+0x2610>
    5e40:	d28000c2 	mov	x2, #0x6                   	// #6
    5e44:	913ee021 	add	x1, x1, #0xfb8
    5e48:	97fff05a 	bl	1fb0 <buf_put>
    5e4c:	d2800015 	mov	x21, #0x0                   	// #0
    5e50:	f9400263 	ldr	x3, [x19]
    5e54:	f240f87f 	tst	x3, #0x7fffffffffffffff
    5e58:	54002c60 	b.eq	63e4 <fwp_write+0x9e4>  // b.none
    5e5c:	f9401f82 	ldr	x2, [x28, #56]
    5e60:	f90143f7 	str	x23, [sp, #640]
    5e64:	f90147f8 	str	x24, [sp, #648]
    5e68:	d2800857 	mov	x23, #0x42                  	// #66
    5e6c:	f9014bf9 	str	x25, [sp, #656]
    5e70:	90000036 	adrp	x22, 9000 <f0+0x2610>
    5e74:	f9014ffa 	str	x26, [sp, #664]
    5e78:	913ec2d6 	add	x22, x22, #0xfb0
    5e7c:	d2800038 	mov	x24, #0x1                   	// #1
    5e80:	f2a18017 	movk	x23, #0xc00, lsl #16
    5e84:	d2809099 	mov	x25, #0x484                 	// #1156
    5e88:	b40004a2 	cbz	x2, 5f1c <fwp_write+0x51c>
    5e8c:	b9400040 	ldr	w0, [x2]
    5e90:	7100701f 	cmp	w0, #0x1c
    5e94:	540042c0 	b.eq	66ec <fwp_write+0xcec>  // b.none
    5e98:	71006c1f 	cmp	w0, #0x1b
    5e9c:	54000408 	b.hi	5f1c <fwp_write+0x51c>  // b.pmore
    5ea0:	9ac02301 	lsl	x1, x24, x0
    5ea4:	ea17003f 	tst	x1, x23
    5ea8:	540036a1 	b.ne	657c <fwp_write+0xb7c>  // b.any
    5eac:	ea19003f 	tst	x1, x25
    5eb0:	54003521 	b.ne	6554 <fwp_write+0xb54>  // b.any
    5eb4:	d2800424 	mov	x4, #0x21                  	// #33
    5eb8:	ea04003f 	tst	x1, x4
    5ebc:	54000300 	b.eq	5f1c <fwp_write+0x51c>  // b.none
    5ec0:	b7f849c3 	tbnz	x3, #63, 67f8 <fwp_write+0xdf8>
    5ec4:	91002261 	add	x1, x19, #0x8
    5ec8:	8b150021 	add	x1, x1, x21
    5ecc:	39400021 	ldrb	w1, [x1]
    5ed0:	7100001f 	cmp	w0, #0x0
    5ed4:	93401c23 	sxtb	x3, w1
    5ed8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    5edc:	d503201f 	nop
    5ee0:	aa1403e0 	mov	x0, x20
    5ee4:	52800003 	mov	w3, #0x0                   	// #0
    5ee8:	97fffec6 	bl	5a00 <fwp_write>
    5eec:	910006b5 	add	x21, x21, #0x1
    5ef0:	f9400260 	ldr	x0, [x19]
    5ef4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    5ef8:	eb0002bf 	cmp	x21, x0
    5efc:	540026c2 	b.cs	63d4 <fwp_write+0x9d4>  // b.hs, b.nlast
    5f00:	d2800042 	mov	x2, #0x2                   	// #2
    5f04:	aa1603e1 	mov	x1, x22
    5f08:	aa1403e0 	mov	x0, x20
    5f0c:	97fff029 	bl	1fb0 <buf_put>
    5f10:	f9401f82 	ldr	x2, [x28, #56]
    5f14:	f9400263 	ldr	x3, [x19]
    5f18:	b5fffba2 	cbnz	x2, 5e8c <fwp_write+0x48c>
    5f1c:	d37df2a0 	lsl	x0, x21, #3
    5f20:	b7f83f03 	tbnz	x3, #63, 6700 <fwp_write+0xd00>
    5f24:	91002261 	add	x1, x19, #0x8
    5f28:	8b000020 	add	x0, x1, x0
    5f2c:	f9400001 	ldr	x1, [x0]
    5f30:	17ffffec 	b	5ee0 <fwp_write+0x4e0>
    5f34:	a9400e62 	ldp	x2, x3, [x19]
    5f38:	b7f83ca3 	tbnz	x3, #63, 66cc <fwp_write+0xccc>
    5f3c:	910123f5 	add	x21, sp, #0x48
    5f40:	aa1503e0 	mov	x0, x21
    5f44:	97ffeeb7 	bl	1a20 <fwp_fmt_u128>
    5f48:	aa1503e0 	mov	x0, x21
    5f4c:	97ffed0d 	bl	1380 <strlen@plt>
    5f50:	aa1503e1 	mov	x1, x21
    5f54:	aa0003e2 	mov	x2, x0
    5f58:	17fffed0 	b	5a98 <fwp_write+0x98>
    5f5c:	fd015be8 	str	d8, [sp, #688]
    5f60:	1e270268 	fmov	s8, w19
    5f64:	fd015fe9 	str	d9, [sp, #696]
    5f68:	1e282100 	fcmp	s8, s8
    5f6c:	54004d26 	b.vs	6910 <fwp_write+0xf10>
    5f70:	1e20c101 	fabs	s1, s8
    5f74:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    5f78:	1e270000 	fmov	s0, w0
    5f7c:	1e202020 	fcmp	s1, s0
    5f80:	54002c0d 	b.le	6500 <fwp_write+0xb00>
    5f84:	1e202118 	fcmpe	s8, #0.0
    5f88:	90000022 	adrp	x2, 9000 <f0+0x2610>
    5f8c:	91328042 	add	x2, x2, #0xca0
    5f90:	910123f5 	add	x21, sp, #0x48
    5f94:	90000021 	adrp	x1, 9000 <f0+0x2610>
    5f98:	913c2021 	add	x1, x1, #0xf08
    5f9c:	aa1503e0 	mov	x0, x21
    5fa0:	9a81c041 	csel	x1, x2, x1, gt
    5fa4:	97ffeda3 	bl	1630 <strcpy@plt>
    5fa8:	aa1503e0 	mov	x0, x21
    5fac:	97ffecf5 	bl	1380 <strlen@plt>
    5fb0:	aa1503e1 	mov	x1, x21
    5fb4:	aa0003e2 	mov	x2, x0
    5fb8:	aa1403e0 	mov	x0, x20
    5fbc:	97ffeffd 	bl	1fb0 <buf_put>
    5fc0:	f9413bf5 	ldr	x21, [sp, #624]
    5fc4:	f9413ff6 	ldr	x22, [sp, #632]
    5fc8:	f94153fb 	ldr	x27, [sp, #672]
    5fcc:	f94157fc 	ldr	x28, [sp, #680]
    5fd0:	fd415be8 	ldr	d8, [sp, #688]
    5fd4:	fd415fe9 	ldr	d9, [sp, #696]
    5fd8:	17fffeb6 	b	5ab0 <fwp_write+0xb0>
    5fdc:	f9400276 	ldr	x22, [x19]
    5fe0:	34002e03 	cbz	w3, 65a0 <fwp_write+0xba0>
    5fe4:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    5fe8:	f947f400 	ldr	x0, [x0, #4072]
    5fec:	f94127e2 	ldr	x2, [sp, #584]
    5ff0:	f9400001 	ldr	x1, [x0]
    5ff4:	eb010042 	subs	x2, x2, x1
    5ff8:	d2800001 	mov	x1, #0x0                   	// #0
    5ffc:	540014a1 	b.ne	6290 <fwp_write+0x890>  // b.any
    6000:	aa1603e2 	mov	x2, x22
    6004:	91002261 	add	x1, x19, #0x8
    6008:	f9413bf5 	ldr	x21, [sp, #624]
    600c:	aa1403e0 	mov	x0, x20
    6010:	f9413ff6 	ldr	x22, [sp, #632]
    6014:	17fffeff 	b	5c10 <fwp_write+0x210>
    6018:	fd015be8 	str	d8, [sp, #688]
    601c:	9e670268 	fmov	d8, x19
    6020:	fd015fe9 	str	d9, [sp, #696]
    6024:	1e682100 	fcmp	d8, d8
    6028:	54004746 	b.vs	6910 <fwp_write+0xf10>
    602c:	1e60c101 	fabs	d1, d8
    6030:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    6034:	9e670000 	fmov	d0, x0
    6038:	910123f5 	add	x21, sp, #0x48
    603c:	52800033 	mov	w19, #0x1                   	// #1
    6040:	1e602020 	fcmp	d1, d0
    6044:	540001ad 	b.le	6078 <fwp_write+0x678>
    6048:	1e602118 	fcmpe	d8, #0.0
    604c:	f0000002 	adrp	x2, 9000 <f0+0x2610>
    6050:	91328042 	add	x2, x2, #0xca0
    6054:	f0000001 	adrp	x1, 9000 <f0+0x2610>
    6058:	913c2021 	add	x1, x1, #0xf08
    605c:	aa1503e0 	mov	x0, x21
    6060:	9a81c041 	csel	x1, x2, x1, gt
    6064:	97ffed73 	bl	1630 <strcpy@plt>
    6068:	17ffffd0 	b	5fa8 <fwp_write+0x5a8>
    606c:	11000673 	add	w19, w19, #0x1
    6070:	71004a7f 	cmp	w19, #0x12
    6074:	54003860 	b.eq	6780 <fwp_write+0xd80>  // b.none
    6078:	1e604100 	fmov	d0, d8
    607c:	2a1303e1 	mov	w1, w19
    6080:	aa1503e0 	mov	x0, x21
    6084:	97fff060 	bl	2204 <fwp_format_g.constprop.0>
    6088:	aa1503e0 	mov	x0, x21
    608c:	d2800001 	mov	x1, #0x0                   	// #0
    6090:	97ffecd0 	bl	13d0 <strtod@plt>
    6094:	1e602100 	fcmp	d8, d0
    6098:	54fffea1 	b.ne	606c <fwp_write+0x66c>  // b.any
    609c:	aa1503e0 	mov	x0, x21
    60a0:	97ffeffd 	bl	2094 <fwp_finish_float>
    60a4:	17ffffc1 	b	5fa8 <fwp_write+0x5a8>
    60a8:	a9400e62 	ldp	x2, x3, [x19]
    60ac:	910123f3 	add	x19, sp, #0x48
    60b0:	aa1303e0 	mov	x0, x19
    60b4:	97ffee5b 	bl	1a20 <fwp_fmt_u128>
    60b8:	17fffe74 	b	5a88 <fwp_write+0x88>
    60bc:	f90143f7 	str	x23, [sp, #640]
    60c0:	f90147f8 	str	x24, [sp, #648]
    60c4:	2a1303f8 	mov	w24, w19
    60c8:	f9014bf9 	str	x25, [sp, #656]
    60cc:	f9014ffa 	str	x26, [sp, #664]
    60d0:	f13ffe7f 	cmp	x19, #0xfff
    60d4:	54000049 	b.ls	60dc <fwp_write+0x6dc>  // b.plast
    60d8:	b9400278 	ldr	w24, [x19]
    60dc:	f9400f80 	ldr	x0, [x28, #24]
    60e0:	2a1803f5 	mov	w21, w24
    60e4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    60e8:	d37ef6b9 	lsl	x25, x21, #2
    60ec:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    60f0:	aa1603e0 	mov	x0, x22
    60f4:	97ffeca3 	bl	1380 <strlen@plt>
    60f8:	aa1603e1 	mov	x1, x22
    60fc:	aa0003e2 	mov	x2, x0
    6100:	aa1403e0 	mov	x0, x20
    6104:	97ffefab 	bl	1fb0 <buf_put>
    6108:	f9401780 	ldr	x0, [x28, #40]
    610c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    6110:	7100001f 	cmp	w0, #0x0
    6114:	5400068d 	b.le	61e4 <fwp_write+0x7e4>
    6118:	91002276 	add	x22, x19, #0x8
    611c:	91001ff5 	add	x21, sp, #0x7
    6120:	d280001b 	mov	x27, #0x0                   	// #0
    6124:	5280041a 	mov	w26, #0x20                  	// #32
    6128:	f9401b80 	ldr	x0, [x28, #48]
    612c:	aa1503e1 	mov	x1, x21
    6130:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    6134:	d2800022 	mov	x2, #0x1                   	// #1
    6138:	f8786803 	ldr	x3, [x0, x24]
    613c:	aa1403e0 	mov	x0, x20
    6140:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    6144:	39001ffa 	strb	w26, [sp, #7]
    6148:	97ffef9a 	bl	1fb0 <buf_put>
    614c:	f13ffeff 	cmp	x23, #0xfff
    6150:	b9400261 	ldr	w1, [x19]
    6154:	1a9f97e0 	cset	w0, hi	// hi = pmore
    6158:	7100383f 	cmp	w1, #0xe
    615c:	54000160 	b.eq	6188 <fwp_write+0x788>  // b.none
    6160:	7100403f 	cmp	w1, #0x10
    6164:	54001a60 	b.eq	64b0 <fwp_write+0xab0>  // b.none
    6168:	7100283f 	cmp	w1, #0xa
    616c:	54002aa0 	b.eq	66c0 <fwp_write+0xcc0>  // b.none
    6170:	540014ac 	b.gt	6404 <fwp_write+0xa04>
    6174:	71000c3f 	cmp	w1, #0x3
    6178:	540029ac 	b.gt	66ac <fwp_write+0xcac>
    617c:	d37ffee0 	lsr	x0, x23, #63
    6180:	37f814a1 	tbnz	w1, #31, 6414 <fwp_write+0xa14>
    6184:	d503201f 	nop
    6188:	34001460 	cbz	w0, 6414 <fwp_write+0xa14>
    618c:	52800503 	mov	w3, #0x28                  	// #40
    6190:	aa1503e1 	mov	x1, x21
    6194:	aa1403e0 	mov	x0, x20
    6198:	d2800022 	mov	x2, #0x1                   	// #1
    619c:	39001fe3 	strb	w3, [sp, #7]
    61a0:	97ffef84 	bl	1fb0 <buf_put>
    61a4:	aa1303e2 	mov	x2, x19
    61a8:	aa1703e1 	mov	x1, x23
    61ac:	aa1403e0 	mov	x0, x20
    61b0:	52800003 	mov	w3, #0x0                   	// #0
    61b4:	97fffe13 	bl	5a00 <fwp_write>
    61b8:	52800523 	mov	w3, #0x29                  	// #41
    61bc:	aa1503e1 	mov	x1, x21
    61c0:	aa1403e0 	mov	x0, x20
    61c4:	d2800022 	mov	x2, #0x1                   	// #1
    61c8:	39001fe3 	strb	w3, [sp, #7]
    61cc:	97ffef79 	bl	1fb0 <buf_put>
    61d0:	f9401780 	ldr	x0, [x28, #40]
    61d4:	9100077b 	add	x27, x27, #0x1
    61d8:	b8796800 	ldr	w0, [x0, x25]
    61dc:	6b1b001f 	cmp	w0, w27
    61e0:	54fffa4c 	b.gt	6128 <fwp_write+0x728>
    61e4:	f9413bf5 	ldr	x21, [sp, #624]
    61e8:	f9413ff6 	ldr	x22, [sp, #632]
    61ec:	f94143f7 	ldr	x23, [sp, #640]
    61f0:	f94147f8 	ldr	x24, [sp, #648]
    61f4:	f9414bf9 	ldr	x25, [sp, #656]
    61f8:	f9414ffa 	ldr	x26, [sp, #664]
    61fc:	f94153fb 	ldr	x27, [sp, #672]
    6200:	f94157fc 	ldr	x28, [sp, #680]
    6204:	17fffe2b 	b	5ab0 <fwp_write+0xb0>
    6208:	52800783 	mov	w3, #0x3c                  	// #60
    620c:	91001ff3 	add	x19, sp, #0x7
    6210:	aa1303e1 	mov	x1, x19
    6214:	d2800022 	mov	x2, #0x1                   	// #1
    6218:	aa1403e0 	mov	x0, x20
    621c:	39001fe3 	strb	w3, [sp, #7]
    6220:	97ffef64 	bl	1fb0 <buf_put>
    6224:	f9400795 	ldr	x21, [x28, #8]
    6228:	aa1503e0 	mov	x0, x21
    622c:	97ffec55 	bl	1380 <strlen@plt>
    6230:	aa1503e1 	mov	x1, x21
    6234:	aa0003e2 	mov	x2, x0
    6238:	aa1403e0 	mov	x0, x20
    623c:	97ffef5d 	bl	1fb0 <buf_put>
    6240:	528007c3 	mov	w3, #0x3e                  	// #62
    6244:	aa1303e1 	mov	x1, x19
    6248:	aa1403e0 	mov	x0, x20
    624c:	d2800022 	mov	x2, #0x1                   	// #1
    6250:	39001fe3 	strb	w3, [sp, #7]
    6254:	17fffe12 	b	5a9c <fwp_write+0x9c>
    6258:	f100067f 	cmp	x19, #0x1
    625c:	540025a0 	b.eq	6710 <fwp_write+0xd10>  // b.none
    6260:	b100067f 	cmn	x19, #0x1
    6264:	54002bc0 	b.eq	67dc <fwp_write+0xddc>  // b.none
    6268:	f0000001 	adrp	x1, 9000 <f0+0x2610>
    626c:	913c4021 	add	x1, x1, #0xf10
    6270:	d2800022 	mov	x2, #0x1                   	// #1
    6274:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    6278:	f947f400 	ldr	x0, [x0, #4072]
    627c:	f94127e4 	ldr	x4, [sp, #584]
    6280:	f9400003 	ldr	x3, [x0]
    6284:	eb030084 	subs	x4, x4, x3
    6288:	d2800003 	mov	x3, #0x0                   	// #0
    628c:	54ffebe0 	b.eq	6008 <fwp_write+0x608>  // b.none
    6290:	f90143f7 	str	x23, [sp, #640]
    6294:	f90147f8 	str	x24, [sp, #648]
    6298:	f9014bf9 	str	x25, [sp, #656]
    629c:	f9014ffa 	str	x26, [sp, #664]
    62a0:	fd015be8 	str	d8, [sp, #688]
    62a4:	fd015fe9 	str	d9, [sp, #696]
    62a8:	97ffec92 	bl	14f0 <__stack_chk_fail@plt>
    62ac:	52800b63 	mov	w3, #0x5b                  	// #91
    62b0:	91001ff5 	add	x21, sp, #0x7
    62b4:	aa1503e1 	mov	x1, x21
    62b8:	aa1403e0 	mov	x0, x20
    62bc:	d2800022 	mov	x2, #0x1                   	// #1
    62c0:	f0000016 	adrp	x22, 9000 <f0+0x2610>
    62c4:	913ec2d6 	add	x22, x22, #0xfb0
    62c8:	39001fe3 	strb	w3, [sp, #7]
    62cc:	97ffef39 	bl	1fb0 <buf_put>
    62d0:	b4000273 	cbz	x19, 631c <fwp_write+0x91c>
    62d4:	f9400661 	ldr	x1, [x19, #8]
    62d8:	aa1403e0 	mov	x0, x20
    62dc:	f9401f82 	ldr	x2, [x28, #56]
    62e0:	52800003 	mov	w3, #0x0                   	// #0
    62e4:	97fffdc7 	bl	5a00 <fwp_write>
    62e8:	f9400a73 	ldr	x19, [x19, #16]
    62ec:	b4000193 	cbz	x19, 631c <fwp_write+0x91c>
    62f0:	aa1603e1 	mov	x1, x22
    62f4:	aa1403e0 	mov	x0, x20
    62f8:	d2800042 	mov	x2, #0x2                   	// #2
    62fc:	97ffef2d 	bl	1fb0 <buf_put>
    6300:	f9400661 	ldr	x1, [x19, #8]
    6304:	aa1403e0 	mov	x0, x20
    6308:	f9401f82 	ldr	x2, [x28, #56]
    630c:	52800003 	mov	w3, #0x0                   	// #0
    6310:	97fffdbc 	bl	5a00 <fwp_write>
    6314:	f9400a73 	ldr	x19, [x19, #16]
    6318:	b5fffed3 	cbnz	x19, 62f0 <fwp_write+0x8f0>
    631c:	52800ba3 	mov	w3, #0x5d                  	// #93
    6320:	aa1503e1 	mov	x1, x21
    6324:	aa1403e0 	mov	x0, x20
    6328:	d2800022 	mov	x2, #0x1                   	// #1
    632c:	39001fe3 	strb	w3, [sp, #7]
    6330:	17fffddb 	b	5a9c <fwp_write+0x9c>
    6334:	aa1403e0 	mov	x0, x20
    6338:	f0000001 	adrp	x1, 9000 <f0+0x2610>
    633c:	d28000c2 	mov	x2, #0x6                   	// #6
    6340:	913e8021 	add	x1, x1, #0xfa0
    6344:	97ffef1b 	bl	1fb0 <buf_put>
    6348:	f9400260 	ldr	x0, [x19]
    634c:	b40004c0 	cbz	x0, 63e4 <fwp_write+0x9e4>
    6350:	910123f5 	add	x21, sp, #0x48
    6354:	91002276 	add	x22, x19, #0x8
    6358:	f90143f7 	str	x23, [sp, #640]
    635c:	d2800017 	mov	x23, #0x0                   	// #0
    6360:	f90147f8 	str	x24, [sp, #648]
    6364:	f0000018 	adrp	x24, 9000 <f0+0x2610>
    6368:	913ea318 	add	x24, x24, #0xfa8
    636c:	f9014bf9 	str	x25, [sp, #656]
    6370:	f0000019 	adrp	x25, 9000 <f0+0x2610>
    6374:	913ec339 	add	x25, x25, #0xfb0
    6378:	f9014ffa 	str	x26, [sp, #664]
    637c:	14000005 	b	6390 <fwp_write+0x990>
    6380:	aa1903e1 	mov	x1, x25
    6384:	aa1403e0 	mov	x0, x20
    6388:	d2800042 	mov	x2, #0x2                   	// #2
    638c:	97ffef09 	bl	1fb0 <buf_put>
    6390:	38776ac5 	ldrb	w5, [x22, x23]
    6394:	d2804003 	mov	x3, #0x200                 	// #512
    6398:	aa1803e4 	mov	x4, x24
    639c:	aa0303e1 	mov	x1, x3
    63a0:	52800042 	mov	w2, #0x2                   	// #2
    63a4:	aa1503e0 	mov	x0, x21
    63a8:	910006f7 	add	x23, x23, #0x1
    63ac:	97ffec2d 	bl	1460 <__snprintf_chk@plt>
    63b0:	aa1503e0 	mov	x0, x21
    63b4:	97ffebf3 	bl	1380 <strlen@plt>
    63b8:	aa1503e1 	mov	x1, x21
    63bc:	aa0003e2 	mov	x2, x0
    63c0:	aa1403e0 	mov	x0, x20
    63c4:	97ffeefb 	bl	1fb0 <buf_put>
    63c8:	f9400260 	ldr	x0, [x19]
    63cc:	eb17001f 	cmp	x0, x23
    63d0:	54fffd88 	b.hi	6380 <fwp_write+0x980>  // b.pmore
    63d4:	f94143f7 	ldr	x23, [sp, #640]
    63d8:	f94147f8 	ldr	x24, [sp, #648]
    63dc:	f9414bf9 	ldr	x25, [sp, #656]
    63e0:	f9414ffa 	ldr	x26, [sp, #664]
    63e4:	52800ba3 	mov	w3, #0x5d                  	// #93
    63e8:	aa1403e0 	mov	x0, x20
    63ec:	91001fe1 	add	x1, sp, #0x7
    63f0:	d2800022 	mov	x2, #0x1                   	// #1
    63f4:	39001fe3 	strb	w3, [sp, #7]
    63f8:	17fffda9 	b	5a9c <fwp_write+0x9c>
    63fc:	52800fa3 	mov	w3, #0x7d                  	// #125
    6400:	17fffe44 	b	5d10 <fwp_write+0x310>
    6404:	f10002ff 	cmp	x23, #0x0
    6408:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    640c:	71002c3f 	cmp	w1, #0xb
    6410:	54ffebc0 	b.eq	6188 <fwp_write+0x788>  // b.none
    6414:	aa1303e2 	mov	x2, x19
    6418:	aa1703e1 	mov	x1, x23
    641c:	aa1403e0 	mov	x0, x20
    6420:	52800003 	mov	w3, #0x0                   	// #0
    6424:	97fffd77 	bl	5a00 <fwp_write>
    6428:	17ffff6a 	b	61d0 <fwp_write+0x7d0>
    642c:	aa1403e0 	mov	x0, x20
    6430:	91001fe1 	add	x1, sp, #0x7
    6434:	52800fa3 	mov	w3, #0x7d                  	// #125
    6438:	d2800022 	mov	x2, #0x1                   	// #1
    643c:	17fffe38 	b	5d1c <fwp_write+0x31c>
    6440:	a9400281 	ldp	x1, x0, [x20]
    6444:	91000800 	add	x0, x0, #0x2
    6448:	8b160000 	add	x0, x0, x22
    644c:	f9000680 	str	x0, [x20, #8]
    6450:	3820683f 	strb	wzr, [x1, x0]
    6454:	f9413bf5 	ldr	x21, [sp, #624]
    6458:	f9413ff6 	ldr	x22, [sp, #632]
    645c:	f94153fb 	ldr	x27, [sp, #672]
    6460:	f94157fc 	ldr	x28, [sp, #680]
    6464:	17fffd93 	b	5ab0 <fwp_write+0xb0>
    6468:	f9400f80 	ldr	x0, [x28, #24]
    646c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    6470:	aa1b03e0 	mov	x0, x27
    6474:	97ffebc3 	bl	1380 <strlen@plt>
    6478:	aa1b03e1 	mov	x1, x27
    647c:	aa0003e2 	mov	x2, x0
    6480:	aa1403e0 	mov	x0, x20
    6484:	97ffeecb 	bl	1fb0 <buf_put>
    6488:	aa1903e1 	mov	x1, x25
    648c:	aa1403e0 	mov	x0, x20
    6490:	d2800062 	mov	x2, #0x3                   	// #3
    6494:	97ffeec7 	bl	1fb0 <buf_put>
    6498:	17fffe10 	b	5cd8 <fwp_write+0x2d8>
    649c:	aa1a03e1 	mov	x1, x26
    64a0:	aa1403e0 	mov	x0, x20
    64a4:	d2800042 	mov	x2, #0x2                   	// #2
    64a8:	97ffeec2 	bl	1fb0 <buf_put>
    64ac:	17fffe09 	b	5cd0 <fwp_write+0x2d0>
    64b0:	f9400660 	ldr	x0, [x19, #8]
    64b4:	b4fffb00 	cbz	x0, 6414 <fwp_write+0xa14>
    64b8:	f0000001 	adrp	x1, 9000 <f0+0x2610>
    64bc:	913f2021 	add	x1, x1, #0xfc8
    64c0:	97ffec2c 	bl	1570 <strcmp@plt>
    64c4:	7100001f 	cmp	w0, #0x0
    64c8:	1a9f07e0 	cset	w0, ne	// ne = any
    64cc:	17ffff2f 	b	6188 <fwp_write+0x788>
    64d0:	aa1403e0 	mov	x0, x20
    64d4:	d2800042 	mov	x2, #0x2                   	// #2
    64d8:	f0000001 	adrp	x1, 9000 <f0+0x2610>
    64dc:	913f0021 	add	x1, x1, #0xfc0
    64e0:	97ffeeb4 	bl	1fb0 <buf_put>
    64e4:	91004261 	add	x1, x19, #0x10
    64e8:	aa1403e0 	mov	x0, x20
    64ec:	f9402382 	ldr	x2, [x28, #64]
    64f0:	52800003 	mov	w3, #0x0                   	// #0
    64f4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    64f8:	97fffd42 	bl	5a00 <fwp_write>
    64fc:	17fffd9c 	b	5b6c <fwp_write+0x16c>
    6500:	1e22c109 	fcvt	d9, s8
    6504:	910123f5 	add	x21, sp, #0x48
    6508:	52800033 	mov	w19, #0x1                   	// #1
    650c:	d503201f 	nop
    6510:	1e604120 	fmov	d0, d9
    6514:	2a1303e1 	mov	w1, w19
    6518:	aa1503e0 	mov	x0, x21
    651c:	97ffef3a 	bl	2204 <fwp_format_g.constprop.0>
    6520:	aa1503e0 	mov	x0, x21
    6524:	d2800001 	mov	x1, #0x0                   	// #0
    6528:	97ffec1e 	bl	15a0 <strtof@plt>
    652c:	1e202100 	fcmp	s8, s0
    6530:	54ffdb60 	b.eq	609c <fwp_write+0x69c>  // b.none
    6534:	11000673 	add	w19, w19, #0x1
    6538:	71002a7f 	cmp	w19, #0xa
    653c:	54fffea1 	b.ne	6510 <fwp_write+0xb10>  // b.any
    6540:	1e604120 	fmov	d0, d9
    6544:	aa1503e0 	mov	x0, x21
    6548:	52800121 	mov	w1, #0x9                   	// #9
    654c:	97ffef2e 	bl	2204 <fwp_format_g.constprop.0>
    6550:	17fffed3 	b	609c <fwp_write+0x69c>
    6554:	d37ef6a1 	lsl	x1, x21, #2
    6558:	b7f81563 	tbnz	x3, #63, 6804 <fwp_write+0xe04>
    655c:	91002263 	add	x3, x19, #0x8
    6560:	8b010061 	add	x1, x3, x1
    6564:	b9400023 	ldr	w3, [x1]
    6568:	7100081f 	cmp	w0, #0x2
    656c:	2a0303e1 	mov	w1, w3
    6570:	93407c63 	sxtw	x3, w3
    6574:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    6578:	17fffe5a 	b	5ee0 <fwp_write+0x4e0>
    657c:	d37ffaa1 	lsl	x1, x21, #1
    6580:	b7f81363 	tbnz	x3, #63, 67ec <fwp_write+0xdec>
    6584:	91002263 	add	x3, x19, #0x8
    6588:	8b010061 	add	x1, x3, x1
    658c:	79400021 	ldrh	w1, [x1]
    6590:	7100041f 	cmp	w0, #0x1
    6594:	93403c23 	sxth	x3, w1
    6598:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    659c:	17fffe51 	b	5ee0 <fwp_write+0x4e0>
    65a0:	52800443 	mov	w3, #0x22                  	// #34
    65a4:	91001ff5 	add	x21, sp, #0x7
    65a8:	91002273 	add	x19, x19, #0x8
    65ac:	aa1503e1 	mov	x1, x21
    65b0:	aa1403e0 	mov	x0, x20
    65b4:	d2800022 	mov	x2, #0x1                   	// #1
    65b8:	39001fe3 	strb	w3, [sp, #7]
    65bc:	f90143f7 	str	x23, [sp, #640]
    65c0:	8b160277 	add	x23, x19, x22
    65c4:	f90147f8 	str	x24, [sp, #648]
    65c8:	97ffee7a 	bl	1fb0 <buf_put>
    65cc:	b4000696 	cbz	x22, 669c <fwp_write+0xc9c>
    65d0:	f0000018 	adrp	x24, 9000 <f0+0x2610>
    65d4:	913dc318 	add	x24, x24, #0xf70
    65d8:	f9014bf9 	str	x25, [sp, #656]
    65dc:	f0000019 	adrp	x25, 9000 <f0+0x2610>
    65e0:	913e4339 	add	x25, x25, #0xf90
    65e4:	f9014ffa 	str	x26, [sp, #664]
    65e8:	1400000d 	b	661c <fwp_write+0xc1c>
    65ec:	710024bf 	cmp	w5, #0x9
    65f0:	54000460 	b.eq	667c <fwp_write+0xc7c>  // b.none
    65f4:	710028bf 	cmp	w5, #0xa
    65f8:	54000a61 	b.ne	6744 <fwp_write+0xd44>  // b.any
    65fc:	f0000001 	adrp	x1, 9000 <f0+0x2610>
    6600:	aa1403e0 	mov	x0, x20
    6604:	913e0021 	add	x1, x1, #0xf80
    6608:	d2800042 	mov	x2, #0x2                   	// #2
    660c:	97ffee69 	bl	1fb0 <buf_put>
    6610:	91000673 	add	x19, x19, #0x1
    6614:	eb17027f 	cmp	x19, x23
    6618:	540003e0 	b.eq	6694 <fwp_write+0xc94>  // b.none
    661c:	39400265 	ldrb	w5, [x19]
    6620:	710034bf 	cmp	w5, #0xd
    6624:	54000180 	b.eq	6654 <fwp_write+0xc54>  // b.none
    6628:	54fffe29 	b.ls	65ec <fwp_write+0xbec>  // b.plast
    662c:	710088bf 	cmp	w5, #0x22
    6630:	540001c0 	b.eq	6668 <fwp_write+0xc68>  // b.none
    6634:	710170bf 	cmp	w5, #0x5c
    6638:	54000741 	b.ne	6720 <fwp_write+0xd20>  // b.any
    663c:	aa1403e0 	mov	x0, x20
    6640:	f0000001 	adrp	x1, 9000 <f0+0x2610>
    6644:	d2800042 	mov	x2, #0x2                   	// #2
    6648:	913de021 	add	x1, x1, #0xf78
    664c:	97ffee59 	bl	1fb0 <buf_put>
    6650:	17fffff0 	b	6610 <fwp_write+0xc10>
    6654:	aa1903e1 	mov	x1, x25
    6658:	aa1403e0 	mov	x0, x20
    665c:	d2800042 	mov	x2, #0x2                   	// #2
    6660:	97ffee54 	bl	1fb0 <buf_put>
    6664:	17ffffeb 	b	6610 <fwp_write+0xc10>
    6668:	aa1803e1 	mov	x1, x24
    666c:	aa1403e0 	mov	x0, x20
    6670:	d2800042 	mov	x2, #0x2                   	// #2
    6674:	97ffee4f 	bl	1fb0 <buf_put>
    6678:	17ffffe6 	b	6610 <fwp_write+0xc10>
    667c:	aa1403e0 	mov	x0, x20
    6680:	f0000001 	adrp	x1, 9000 <f0+0x2610>
    6684:	d2800042 	mov	x2, #0x2                   	// #2
    6688:	913e2021 	add	x1, x1, #0xf88
    668c:	97ffee49 	bl	1fb0 <buf_put>
    6690:	17ffffe0 	b	6610 <fwp_write+0xc10>
    6694:	f9414bf9 	ldr	x25, [sp, #656]
    6698:	f9414ffa 	ldr	x26, [sp, #664]
    669c:	aa1503e1 	mov	x1, x21
    66a0:	aa1403e0 	mov	x0, x20
    66a4:	52800443 	mov	w3, #0x22                  	// #34
    66a8:	17fffd9c 	b	5d18 <fwp_write+0x318>
    66ac:	7100103f 	cmp	w1, #0x4
    66b0:	54ffeb21 	b.ne	6414 <fwp_write+0xa14>  // b.any
    66b4:	f94006e0 	ldr	x0, [x23, #8]
    66b8:	d37ffc00 	lsr	x0, x0, #63
    66bc:	17fffeb3 	b	6188 <fwp_write+0x788>
    66c0:	710002ff 	cmp	w23, #0x0
    66c4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    66c8:	17fffeb0 	b	6188 <fwp_write+0x788>
    66cc:	528005a1 	mov	w1, #0x2d                  	// #45
    66d0:	eb0203e2 	negs	x2, x2
    66d4:	da0303e3 	ngc	x3, x3
    66d8:	910127e0 	add	x0, sp, #0x49
    66dc:	910123f5 	add	x21, sp, #0x48
    66e0:	390123e1 	strb	w1, [sp, #72]
    66e4:	97ffeccf 	bl	1a20 <fwp_fmt_u128>
    66e8:	17fffe18 	b	5f48 <fwp_write+0x548>
    66ec:	d37ceea1 	lsl	x1, x21, #4
    66f0:	b7f810a3 	tbnz	x3, #63, 6904 <fwp_write+0xf04>
    66f4:	91002260 	add	x0, x19, #0x8
    66f8:	8b010001 	add	x1, x0, x1
    66fc:	17fffdf9 	b	5ee0 <fwp_write+0x4e0>
    6700:	f9400a61 	ldr	x1, [x19, #16]
    6704:	8b010000 	add	x0, x0, x1
    6708:	f9400001 	ldr	x1, [x0]
    670c:	17fffdf5 	b	5ee0 <fwp_write+0x4e0>
    6710:	f0000001 	adrp	x1, 9000 <f0+0x2610>
    6714:	d2800042 	mov	x2, #0x2                   	// #2
    6718:	913c6021 	add	x1, x1, #0xf18
    671c:	17fffed6 	b	6274 <fwp_write+0x874>
    6720:	7101fcbf 	cmp	w5, #0x7f
    6724:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    6728:	540000e9 	b.ls	6744 <fwp_write+0xd44>  // b.plast
    672c:	aa1503e1 	mov	x1, x21
    6730:	aa1403e0 	mov	x0, x20
    6734:	d2800022 	mov	x2, #0x1                   	// #1
    6738:	39001fe5 	strb	w5, [sp, #7]
    673c:	97ffee1d 	bl	1fb0 <buf_put>
    6740:	17ffffb4 	b	6610 <fwp_write+0xc10>
    6744:	d2800203 	mov	x3, #0x10                  	// #16
    6748:	f0000004 	adrp	x4, 9000 <f0+0x2610>
    674c:	aa0303e1 	mov	x1, x3
    6750:	913e6084 	add	x4, x4, #0xf98
    6754:	910123f6 	add	x22, sp, #0x48
    6758:	52800042 	mov	w2, #0x2                   	// #2
    675c:	aa1603e0 	mov	x0, x22
    6760:	97ffeb40 	bl	1460 <__snprintf_chk@plt>
    6764:	aa1603e0 	mov	x0, x22
    6768:	97ffeb06 	bl	1380 <strlen@plt>
    676c:	aa1603e1 	mov	x1, x22
    6770:	aa0003e2 	mov	x2, x0
    6774:	aa1403e0 	mov	x0, x20
    6778:	97ffee0e 	bl	1fb0 <buf_put>
    677c:	17ffffa5 	b	6610 <fwp_write+0xc10>
    6780:	1e604100 	fmov	d0, d8
    6784:	aa1503e0 	mov	x0, x21
    6788:	52800221 	mov	w1, #0x11                  	// #17
    678c:	97ffee9e 	bl	2204 <fwp_format_g.constprop.0>
    6790:	17fffe43 	b	609c <fwp_write+0x69c>
    6794:	b9401040 	ldr	w0, [x2, #16]
    6798:	350003c0 	cbnz	w0, 6810 <fwp_write+0xe10>
    679c:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    67a0:	f947f400 	ldr	x0, [x0, #4072]
    67a4:	f94127e2 	ldr	x2, [sp, #584]
    67a8:	f9400001 	ldr	x1, [x0]
    67ac:	eb010042 	subs	x2, x2, x1
    67b0:	d2800001 	mov	x1, #0x0                   	// #0
    67b4:	54ffd721 	b.ne	6298 <fwp_write+0x898>  // b.any
    67b8:	f9413bf5 	ldr	x21, [sp, #624]
    67bc:	f0000001 	adrp	x1, 9000 <f0+0x2610>
    67c0:	f9413ff6 	ldr	x22, [sp, #632]
    67c4:	aa1403e0 	mov	x0, x20
    67c8:	f94143f7 	ldr	x23, [sp, #640]
    67cc:	913fa021 	add	x1, x1, #0xfe8
    67d0:	f94147f8 	ldr	x24, [sp, #648]
    67d4:	d2800042 	mov	x2, #0x2                   	// #2
    67d8:	17fffd0e 	b	5c10 <fwp_write+0x210>
    67dc:	f0000001 	adrp	x1, 9000 <f0+0x2610>
    67e0:	d2800042 	mov	x2, #0x2                   	// #2
    67e4:	913c8021 	add	x1, x1, #0xf20
    67e8:	17fffea3 	b	6274 <fwp_write+0x874>
    67ec:	f9400a63 	ldr	x3, [x19, #16]
    67f0:	8b030021 	add	x1, x1, x3
    67f4:	17ffff66 	b	658c <fwp_write+0xb8c>
    67f8:	f9400a61 	ldr	x1, [x19, #16]
    67fc:	8b0102a1 	add	x1, x21, x1
    6800:	17fffdb3 	b	5ecc <fwp_write+0x4cc>
    6804:	f9400a63 	ldr	x3, [x19, #16]
    6808:	8b030021 	add	x1, x1, x3
    680c:	17ffff56 	b	6564 <fwp_write+0xb64>
    6810:	b9404840 	ldr	w0, [x2, #72]
    6814:	91001ff5 	add	x21, sp, #0x7
    6818:	34ffa360 	cbz	w0, 5c84 <fwp_write+0x284>
    681c:	52800503 	mov	w3, #0x28                  	// #40
    6820:	aa1403e0 	mov	x0, x20
    6824:	aa1503e1 	mov	x1, x21
    6828:	d2800022 	mov	x2, #0x1                   	// #1
    682c:	39001fe3 	strb	w3, [sp, #7]
    6830:	97ffede0 	bl	1fb0 <buf_put>
    6834:	b9401380 	ldr	w0, [x28, #16]
    6838:	52800038 	mov	w24, #0x1                   	// #1
    683c:	7100001f 	cmp	w0, #0x0
    6840:	54ffa36c 	b.gt	5cac <fwp_write+0x2ac>
    6844:	17fffd32 	b	5d0c <fwp_write+0x30c>
    6848:	f9014bf9 	str	x25, [sp, #656]
    684c:	b00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x13c68>
    6850:	f9014ffa 	str	x26, [sp, #664]
    6854:	f9400676 	ldr	x22, [x19, #8]
    6858:	912ae333 	add	x19, x25, #0xab8
    685c:	91002273 	add	x19, x19, #0x8
    6860:	937ffed8 	asr	x24, x22, #63
    6864:	aa1802c0 	orr	x0, x22, x24
    6868:	b5000320 	cbnz	x0, 68cc <fwp_write+0xecc>
    686c:	110006b5 	add	w21, w21, #0x1
    6870:	710016bf 	cmp	w21, #0x5
    6874:	54ffffc1 	b.ne	686c <fwp_write+0xe6c>  // b.any
    6878:	b7f80578 	tbnz	x24, #63, 6924 <fwp_write+0xf24>
    687c:	910023f3 	add	x19, sp, #0x8
    6880:	aa1603e2 	mov	x2, x22
    6884:	aa1303e0 	mov	x0, x19
    6888:	d2800003 	mov	x3, #0x0                   	// #0
    688c:	97ffec65 	bl	1a20 <fwp_fmt_u128>
    6890:	910123f5 	add	x21, sp, #0x48
    6894:	f0000003 	adrp	x3, 9000 <f0+0x2610>
    6898:	aa1303e4 	mov	x4, x19
    689c:	aa1503e0 	mov	x0, x21
    68a0:	913f8063 	add	x3, x3, #0xfe0
    68a4:	d2804002 	mov	x2, #0x200                 	// #512
    68a8:	52800041 	mov	w1, #0x2                   	// #2
    68ac:	97ffeab9 	bl	1390 <__sprintf_chk@plt>
    68b0:	aa1503e0 	mov	x0, x21
    68b4:	97ffeab3 	bl	1380 <strlen@plt>
    68b8:	aa1503e1 	mov	x1, x21
    68bc:	aa0003e2 	mov	x2, x0
    68c0:	aa1403e0 	mov	x0, x20
    68c4:	97ffedbb 	bl	1fb0 <buf_put>
    68c8:	17fffe47 	b	61e4 <fwp_write+0x7e4>
    68cc:	f9400277 	ldr	x23, [x19]
    68d0:	aa1603e0 	mov	x0, x22
    68d4:	aa1803e1 	mov	x1, x24
    68d8:	aa1703e2 	mov	x2, x23
    68dc:	937ffefa 	asr	x26, x23, #63
    68e0:	aa1a03e3 	mov	x3, x26
    68e4:	94000bff 	bl	98e0 <__modti3>
    68e8:	aa010000 	orr	x0, x0, x1
    68ec:	b40002c0 	cbz	x0, 6944 <fwp_write+0xf44>
    68f0:	110006b5 	add	w21, w21, #0x1
    68f4:	91004273 	add	x19, x19, #0x10
    68f8:	710016bf 	cmp	w21, #0x5
    68fc:	54fffe81 	b.ne	68cc <fwp_write+0xecc>  // b.any
    6900:	17ffffde 	b	6878 <fwp_write+0xe78>
    6904:	f9400a60 	ldr	x0, [x19, #16]
    6908:	8b000021 	add	x1, x1, x0
    690c:	17fffd75 	b	5ee0 <fwp_write+0x4e0>
    6910:	528c29c0 	mov	w0, #0x614e                	// #24910
    6914:	910123f5 	add	x21, sp, #0x48
    6918:	72a009c0 	movk	w0, #0x4e, lsl #16
    691c:	b9004be0 	str	w0, [sp, #72]
    6920:	17fffda2 	b	5fa8 <fwp_write+0x5a8>
    6924:	528005a1 	mov	w1, #0x2d                  	// #45
    6928:	eb1603e2 	negs	x2, x22
    692c:	da1803e3 	ngc	x3, x24
    6930:	910027e0 	add	x0, sp, #0x9
    6934:	910023f3 	add	x19, sp, #0x8
    6938:	390023e1 	strb	w1, [sp, #8]
    693c:	97ffec39 	bl	1a20 <fwp_fmt_u128>
    6940:	17ffffd4 	b	6890 <fwp_write+0xe90>
    6944:	aa1703e2 	mov	x2, x23
    6948:	aa1a03e3 	mov	x3, x26
    694c:	aa1603e0 	mov	x0, x22
    6950:	aa1803e1 	mov	x1, x24
    6954:	94000b03 	bl	9560 <__divti3>
    6958:	aa0003e2 	mov	x2, x0
    695c:	aa0103e3 	mov	x3, x1
    6960:	b7f80201 	tbnz	x1, #63, 69a0 <fwp_write+0xfa0>
    6964:	910023f3 	add	x19, sp, #0x8
    6968:	aa1303e0 	mov	x0, x19
    696c:	97ffec2d 	bl	1a20 <fwp_fmt_u128>
    6970:	937c7ea1 	sbfiz	x1, x21, #4, #32
    6974:	912ae339 	add	x25, x25, #0xab8
    6978:	910123f5 	add	x21, sp, #0x48
    697c:	aa1303e4 	mov	x4, x19
    6980:	aa1503e0 	mov	x0, x21
    6984:	f0000003 	adrp	x3, 9000 <f0+0x2610>
    6988:	f8616b25 	ldr	x5, [x25, x1]
    698c:	913f6063 	add	x3, x3, #0xfd8
    6990:	d2804002 	mov	x2, #0x200                 	// #512
    6994:	52800041 	mov	w1, #0x2                   	// #2
    6998:	97ffea7e 	bl	1390 <__sprintf_chk@plt>
    699c:	17ffffc5 	b	68b0 <fwp_write+0xeb0>
    69a0:	528005a4 	mov	w4, #0x2d                  	// #45
    69a4:	eb0003e2 	negs	x2, x0
    69a8:	da0103e3 	ngc	x3, x1
    69ac:	910027e0 	add	x0, sp, #0x9
    69b0:	910023f3 	add	x19, sp, #0x8
    69b4:	390023e4 	strb	w4, [sp, #8]
    69b8:	97ffec1a 	bl	1a20 <fwp_fmt_u128>
    69bc:	17ffffed 	b	6970 <fwp_write+0xf70>
    69c0:	f9013bf5 	str	x21, [sp, #624]
    69c4:	f9013ff6 	str	x22, [sp, #632]
    69c8:	f90143f7 	str	x23, [sp, #640]
    69cc:	f90147f8 	str	x24, [sp, #648]
    69d0:	f9014bf9 	str	x25, [sp, #656]
    69d4:	f9014ffa 	str	x26, [sp, #664]
    69d8:	f90153fb 	str	x27, [sp, #672]
    69dc:	f90157fc 	str	x28, [sp, #680]
    69e0:	fd015be8 	str	d8, [sp, #688]
    69e4:	fd015fe9 	str	d9, [sp, #696]
    69e8:	97ffeac2 	bl	14f0 <__stack_chk_fail@plt>
    69ec:	d503201f 	nop

00000000000069f0 <f0>:
    69f0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    69f4:	910003fd 	mov	x29, sp
    69f8:	a90153f3 	stp	x19, x20, [sp, #16]
    69fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    6a00:	a90363f7 	stp	x23, x24, [sp, #48]
    6a04:	a9046bf9 	stp	x25, x26, [sp, #64]
    6a08:	a90573fb 	stp	x27, x28, [sp, #80]
    6a0c:	d12203ff 	sub	sp, sp, #0x880
    6a10:	f90203ff 	str	xzr, [sp, #1024]
    6a14:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    6a18:	f947f400 	ldr	x0, [x0, #4072]
    6a1c:	d00000d5 	adrp	x21, 20000 <__data_start>
    6a20:	9100c2a3 	add	x3, x21, #0x30
    6a24:	910103e4 	add	x4, sp, #0x40
    6a28:	f9400001 	ldr	x1, [x0]
    6a2c:	f9043fe1 	str	x1, [sp, #2168]
    6a30:	d2800001 	mov	x1, #0x0                   	// #0
    6a34:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xd10>
    6a38:	9100a3e0 	add	x0, sp, #0x28
    6a3c:	d0ffffe1 	adrp	x1, 4000 <fwp_data.part.0.constprop.0+0x3c>
    6a40:	f9413065 	ldr	x5, [x3, #608]
    6a44:	912a0021 	add	x1, x1, #0xa80
    6a48:	f0ffffc2 	adrp	x2, 1000 <__abi_tag+0xd88>
    6a4c:	91134279 	add	x25, x19, #0x4d0
    6a50:	912d4042 	add	x2, x2, #0xb50
    6a54:	9121a3f7 	add	x23, sp, #0x868
    6a58:	d2800014 	mov	x20, #0x0                   	// #0
    6a5c:	d280011a 	mov	x26, #0x8                   	// #8
    6a60:	d2800016 	mov	x22, #0x0                   	// #0
    6a64:	f90007e4 	str	x4, [sp, #8]
    6a68:	a9028be5 	stp	x5, x2, [sp, #40]
    6a6c:	a903ffe4 	stp	x4, xzr, [sp, #56]
    6a70:	a90507ff 	stp	xzr, x1, [sp, #80]
    6a74:	f9013060 	str	x0, [x3, #608]
    6a78:	14000012 	b	6ac0 <f0+0xd0>
    6a7c:	7100045f 	cmp	w2, #0x1
    6a80:	540001a1 	b.ne	6ab4 <f0+0xc4>  // b.any
    6a84:	29430002 	ldp	w2, w0, [x0, #24]
    6a88:	92403c21 	and	x1, x1, #0xffff
    6a8c:	9b027c21 	mul	x1, x1, x2
    6a90:	d360fc21 	lsr	x1, x1, #32
    6a94:	eb00003f 	cmp	x1, x0
    6a98:	540000e2 	b.cs	6ab4 <f0+0xc4>  // b.hs, b.nlast
    6a9c:	8b01039c 	add	x28, x28, x1
    6aa0:	39400380 	ldrb	w0, [x28]
    6aa4:	7103fc1f 	cmp	w0, #0xff
    6aa8:	54010fa0 	b.eq	8c9c <f0+0x22ac>  // b.none
    6aac:	52800020 	mov	w0, #0x1                   	// #1
    6ab0:	39000380 	strb	w0, [x28]
    6ab4:	f90023f4 	str	x20, [sp, #64]
    6ab8:	aa18037b 	orr	x27, x27, x24
    6abc:	b400043b 	cbz	x27, 6b40 <f0+0x150>
    6ac0:	f100075b 	subs	x27, x26, #0x1
    6ac4:	aa1703e1 	mov	x1, x23
    6ac8:	da1f02d8 	sbc	x24, x22, xzr
    6acc:	52800020 	mov	w0, #0x1                   	// #1
    6ad0:	f90027fb 	str	x27, [sp, #72]
    6ad4:	aa1b03fa 	mov	x26, x27
    6ad8:	f90437fb 	str	x27, [sp, #2152]
    6adc:	aa1803f6 	mov	x22, x24
    6ae0:	f9043bf4 	str	x20, [sp, #2160]
    6ae4:	97fff538 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6ae8:	f949db21 	ldr	x1, [x25, #5040]
    6aec:	aa0003f4 	mov	x20, x0
    6af0:	f949ef20 	ldr	x0, [x25, #5080]
    6af4:	cb010281 	sub	x1, x20, x1
    6af8:	eb00403f 	cmp	x1, x0, lsl #16
    6afc:	54fffdc2 	b.cs	6ab4 <f0+0xc4>  // b.hs, b.nlast
    6b00:	d350fc20 	lsr	x0, x1, #16
    6b04:	f949ff25 	ldr	x5, [x25, #5112]
    6b08:	8b000800 	add	x0, x0, x0, lsl #2
    6b0c:	d37df002 	lsl	x2, x0, #3
    6b10:	8b0200a0 	add	x0, x5, x2
    6b14:	f940101c 	ldr	x28, [x0, #32]
    6b18:	b4fffcfc 	cbz	x28, 6ab4 <f0+0xc4>
    6b1c:	386268a2 	ldrb	w2, [x5, x2]
    6b20:	7100085f 	cmp	w2, #0x2
    6b24:	54fffac1 	b.ne	6a7c <f0+0x8c>  // b.any
    6b28:	72003c3f 	tst	w1, #0xffff
    6b2c:	54fffba0 	b.eq	6aa0 <f0+0xb0>  // b.none
    6b30:	f90023f4 	str	x20, [sp, #64]
    6b34:	aa18037b 	orr	x27, x27, x24
    6b38:	b5fffc5b 	cbnz	x27, 6ac0 <f0+0xd0>
    6b3c:	d503201f 	nop
    6b40:	90000020 	adrp	x0, a000 <_IO_stdin_used+0x380>
    6b44:	9100c2a2 	add	x2, x21, #0x30
    6b48:	f94017e3 	ldr	x3, [sp, #40]
    6b4c:	910183e1 	add	x1, sp, #0x60
    6b50:	3dc07000 	ldr	q0, [x0, #448]
    6b54:	52800020 	mov	w0, #0x1                   	// #1
    6b58:	f9013043 	str	x3, [x2, #608]
    6b5c:	3d801be0 	str	q0, [sp, #96]
    6b60:	97fff519 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6b64:	97fff287 	bl	3580 <fwp_rc_fresh>
    6b68:	9101e3e1 	add	x1, sp, #0x78
    6b6c:	aa0003e2 	mov	x2, x0
    6b70:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    6b74:	52800020 	mov	w0, #0x1                   	// #1
    6b78:	a9078be3 	stp	x3, x2, [sp, #120]
    6b7c:	97fff512 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6b80:	97fff280 	bl	3580 <fwp_rc_fresh>
    6b84:	aa0003e2 	mov	x2, x0
    6b88:	90000023 	adrp	x3, a000 <_IO_stdin_used+0x380>
    6b8c:	910223e1 	add	x1, sp, #0x88
    6b90:	52800020 	mov	w0, #0x1                   	// #1
    6b94:	f9004be2 	str	x2, [sp, #144]
    6b98:	3dc07060 	ldr	q0, [x3, #448]
    6b9c:	fd0047e0 	str	d0, [sp, #136]
    6ba0:	97fff509 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6ba4:	91134263 	add	x3, x19, #0x4d0
    6ba8:	aa0003f9 	mov	x25, x0
    6bac:	f949d861 	ldr	x1, [x3, #5040]
    6bb0:	f949ec60 	ldr	x0, [x3, #5080]
    6bb4:	cb010321 	sub	x1, x25, x1
    6bb8:	eb00403f 	cmp	x1, x0, lsl #16
    6bbc:	54000322 	b.cs	6c20 <f0+0x230>  // b.hs, b.nlast
    6bc0:	d350fc22 	lsr	x2, x1, #16
    6bc4:	f949fc63 	ldr	x3, [x3, #5112]
    6bc8:	8b020842 	add	x2, x2, x2, lsl #2
    6bcc:	d37df042 	lsl	x2, x2, #3
    6bd0:	8b020060 	add	x0, x3, x2
    6bd4:	f9401016 	ldr	x22, [x0, #32]
    6bd8:	b4000256 	cbz	x22, 6c20 <f0+0x230>
    6bdc:	38626862 	ldrb	w2, [x3, x2]
    6be0:	7100085f 	cmp	w2, #0x2
    6be4:	540107a0 	b.eq	8cd8 <f0+0x22e8>  // b.none
    6be8:	7100045f 	cmp	w2, #0x1
    6bec:	540001a1 	b.ne	6c20 <f0+0x230>  // b.any
    6bf0:	29430002 	ldp	w2, w0, [x0, #24]
    6bf4:	92403c21 	and	x1, x1, #0xffff
    6bf8:	9b027c21 	mul	x1, x1, x2
    6bfc:	d360fc21 	lsr	x1, x1, #32
    6c00:	eb00003f 	cmp	x1, x0
    6c04:	540000e2 	b.cs	6c20 <f0+0x230>  // b.hs, b.nlast
    6c08:	8b0102d6 	add	x22, x22, x1
    6c0c:	394002c0 	ldrb	w0, [x22]
    6c10:	7103fc1f 	cmp	w0, #0xff
    6c14:	540112e0 	b.eq	8e70 <f0+0x2480>  // b.none
    6c18:	52800020 	mov	w0, #0x1                   	// #1
    6c1c:	390002c0 	strb	w0, [x22]
    6c20:	910263e1 	add	x1, sp, #0x98
    6c24:	d2e7fe16 	mov	x22, #0x3ff0000000000000    	// #4607182418800017408
    6c28:	52800020 	mov	w0, #0x1                   	// #1
    6c2c:	a909e7f6 	stp	x22, x25, [sp, #152]
    6c30:	97fff4e5 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6c34:	97fff253 	bl	3580 <fwp_rc_fresh>
    6c38:	aa0003e2 	mov	x2, x0
    6c3c:	9102a3e1 	add	x1, sp, #0xa8
    6c40:	b200e7f9 	mov	x25, #0x3333333333333333    	// #3689348814741910323
    6c44:	f2f7fe79 	movk	x25, #0xbff3, lsl #48
    6c48:	52800020 	mov	w0, #0x1                   	// #1
    6c4c:	a90a8bf9 	stp	x25, x2, [sp, #168]
    6c50:	97fff4dd 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6c54:	97fff24b 	bl	3580 <fwp_rc_fresh>
    6c58:	aa0003e2 	mov	x2, x0
    6c5c:	9102e3e1 	add	x1, sp, #0xb8
    6c60:	52800020 	mov	w0, #0x1                   	// #1
    6c64:	a90b8bf6 	stp	x22, x2, [sp, #184]
    6c68:	97fff4d7 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6c6c:	97fff245 	bl	3580 <fwp_rc_fresh>
    6c70:	aa0003e2 	mov	x2, x0
    6c74:	910323e1 	add	x1, sp, #0xc8
    6c78:	52800020 	mov	w0, #0x1                   	// #1
    6c7c:	a90c8bf9 	stp	x25, x2, [sp, #200]
    6c80:	97fff4d1 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6c84:	97fff23f 	bl	3580 <fwp_rc_fresh>
    6c88:	aa0003e2 	mov	x2, x0
    6c8c:	910363e1 	add	x1, sp, #0xd8
    6c90:	52800020 	mov	w0, #0x1                   	// #1
    6c94:	a90d8bf6 	stp	x22, x2, [sp, #216]
    6c98:	97fff4cb 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6c9c:	97fff239 	bl	3580 <fwp_rc_fresh>
    6ca0:	aa0003e2 	mov	x2, x0
    6ca4:	9103a3e1 	add	x1, sp, #0xe8
    6ca8:	52800020 	mov	w0, #0x1                   	// #1
    6cac:	a90e8bf9 	stp	x25, x2, [sp, #232]
    6cb0:	97fff4c5 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6cb4:	97fff233 	bl	3580 <fwp_rc_fresh>
    6cb8:	aa0003e2 	mov	x2, x0
    6cbc:	9103e3e1 	add	x1, sp, #0xf8
    6cc0:	52800020 	mov	w0, #0x1                   	// #1
    6cc4:	a90f8bf6 	stp	x22, x2, [sp, #248]
    6cc8:	97fff4bf 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6ccc:	97fff22d 	bl	3580 <fwp_rc_fresh>
    6cd0:	aa0003e2 	mov	x2, x0
    6cd4:	910423e1 	add	x1, sp, #0x108
    6cd8:	52800020 	mov	w0, #0x1                   	// #1
    6cdc:	a9108bf9 	stp	x25, x2, [sp, #264]
    6ce0:	97fff4b9 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6ce4:	97fff227 	bl	3580 <fwp_rc_fresh>
    6ce8:	aa0003e2 	mov	x2, x0
    6cec:	910463e1 	add	x1, sp, #0x118
    6cf0:	52800020 	mov	w0, #0x1                   	// #1
    6cf4:	a9118bf6 	stp	x22, x2, [sp, #280]
    6cf8:	97fff4b3 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6cfc:	91134263 	add	x3, x19, #0x4d0
    6d00:	aa0003f6 	mov	x22, x0
    6d04:	f949d861 	ldr	x1, [x3, #5040]
    6d08:	f949ec60 	ldr	x0, [x3, #5080]
    6d0c:	cb0102c1 	sub	x1, x22, x1
    6d10:	eb00403f 	cmp	x1, x0, lsl #16
    6d14:	54000322 	b.cs	6d78 <f0+0x388>  // b.hs, b.nlast
    6d18:	d350fc22 	lsr	x2, x1, #16
    6d1c:	f949fc63 	ldr	x3, [x3, #5112]
    6d20:	8b020842 	add	x2, x2, x2, lsl #2
    6d24:	d37df042 	lsl	x2, x2, #3
    6d28:	8b020060 	add	x0, x3, x2
    6d2c:	f9401019 	ldr	x25, [x0, #32]
    6d30:	b4000259 	cbz	x25, 6d78 <f0+0x388>
    6d34:	38626862 	ldrb	w2, [x3, x2]
    6d38:	7100085f 	cmp	w2, #0x2
    6d3c:	5400fc80 	b.eq	8ccc <f0+0x22dc>  // b.none
    6d40:	7100045f 	cmp	w2, #0x1
    6d44:	540001a1 	b.ne	6d78 <f0+0x388>  // b.any
    6d48:	29430002 	ldp	w2, w0, [x0, #24]
    6d4c:	92403c21 	and	x1, x1, #0xffff
    6d50:	9b027c21 	mul	x1, x1, x2
    6d54:	d360fc21 	lsr	x1, x1, #32
    6d58:	eb00003f 	cmp	x1, x0
    6d5c:	540000e2 	b.cs	6d78 <f0+0x388>  // b.hs, b.nlast
    6d60:	8b010339 	add	x25, x25, x1
    6d64:	39400320 	ldrb	w0, [x25]
    6d68:	7103fc1f 	cmp	w0, #0xff
    6d6c:	54010880 	b.eq	8e7c <f0+0x248c>  // b.none
    6d70:	52800020 	mov	w0, #0x1                   	// #1
    6d74:	39000320 	strb	w0, [x25]
    6d78:	9104a3e1 	add	x1, sp, #0x128
    6d7c:	b200e7f9 	mov	x25, #0x3333333333333333    	// #3689348814741910323
    6d80:	f2f7fe79 	movk	x25, #0xbff3, lsl #48
    6d84:	52800020 	mov	w0, #0x1                   	// #1
    6d88:	a912dbf9 	stp	x25, x22, [sp, #296]
    6d8c:	97fff48e 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6d90:	97fff1fc 	bl	3580 <fwp_rc_fresh>
    6d94:	aa0003e2 	mov	x2, x0
    6d98:	9104e3e1 	add	x1, sp, #0x138
    6d9c:	d2e7fe16 	mov	x22, #0x3ff0000000000000    	// #4607182418800017408
    6da0:	52800020 	mov	w0, #0x1                   	// #1
    6da4:	a9138bf6 	stp	x22, x2, [sp, #312]
    6da8:	97fff487 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6dac:	97fff1f5 	bl	3580 <fwp_rc_fresh>
    6db0:	aa0003e2 	mov	x2, x0
    6db4:	910523e1 	add	x1, sp, #0x148
    6db8:	52800020 	mov	w0, #0x1                   	// #1
    6dbc:	a9148bf9 	stp	x25, x2, [sp, #328]
    6dc0:	97fff481 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6dc4:	97fff1ef 	bl	3580 <fwp_rc_fresh>
    6dc8:	aa0003e2 	mov	x2, x0
    6dcc:	910563e1 	add	x1, sp, #0x158
    6dd0:	52800020 	mov	w0, #0x1                   	// #1
    6dd4:	a9158bf6 	stp	x22, x2, [sp, #344]
    6dd8:	97fff47b 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6ddc:	97fff1e9 	bl	3580 <fwp_rc_fresh>
    6de0:	aa0003e2 	mov	x2, x0
    6de4:	9105a3e1 	add	x1, sp, #0x168
    6de8:	52800020 	mov	w0, #0x1                   	// #1
    6dec:	a9168bf9 	stp	x25, x2, [sp, #360]
    6df0:	97fff475 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6df4:	97fff1e3 	bl	3580 <fwp_rc_fresh>
    6df8:	aa0003e2 	mov	x2, x0
    6dfc:	9105e3e1 	add	x1, sp, #0x178
    6e00:	52800020 	mov	w0, #0x1                   	// #1
    6e04:	a9178bf6 	stp	x22, x2, [sp, #376]
    6e08:	97fff46f 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6e0c:	97fff1dd 	bl	3580 <fwp_rc_fresh>
    6e10:	aa0003e2 	mov	x2, x0
    6e14:	910623e1 	add	x1, sp, #0x188
    6e18:	52800020 	mov	w0, #0x1                   	// #1
    6e1c:	a9188bf9 	stp	x25, x2, [sp, #392]
    6e20:	97fff469 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6e24:	97fff1d7 	bl	3580 <fwp_rc_fresh>
    6e28:	aa0003e2 	mov	x2, x0
    6e2c:	910663e1 	add	x1, sp, #0x198
    6e30:	52800020 	mov	w0, #0x1                   	// #1
    6e34:	a9198bf6 	stp	x22, x2, [sp, #408]
    6e38:	97fff463 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6e3c:	91134263 	add	x3, x19, #0x4d0
    6e40:	aa0003f9 	mov	x25, x0
    6e44:	f949d861 	ldr	x1, [x3, #5040]
    6e48:	f949ec60 	ldr	x0, [x3, #5080]
    6e4c:	cb010321 	sub	x1, x25, x1
    6e50:	eb00403f 	cmp	x1, x0, lsl #16
    6e54:	54000322 	b.cs	6eb8 <f0+0x4c8>  // b.hs, b.nlast
    6e58:	d350fc22 	lsr	x2, x1, #16
    6e5c:	f949fc63 	ldr	x3, [x3, #5112]
    6e60:	8b020842 	add	x2, x2, x2, lsl #2
    6e64:	d37df042 	lsl	x2, x2, #3
    6e68:	8b020060 	add	x0, x3, x2
    6e6c:	f9401016 	ldr	x22, [x0, #32]
    6e70:	b4000256 	cbz	x22, 6eb8 <f0+0x4c8>
    6e74:	38626862 	ldrb	w2, [x3, x2]
    6e78:	7100085f 	cmp	w2, #0x2
    6e7c:	5400f220 	b.eq	8cc0 <f0+0x22d0>  // b.none
    6e80:	7100045f 	cmp	w2, #0x1
    6e84:	540001a1 	b.ne	6eb8 <f0+0x4c8>  // b.any
    6e88:	29430002 	ldp	w2, w0, [x0, #24]
    6e8c:	92403c21 	and	x1, x1, #0xffff
    6e90:	9b027c21 	mul	x1, x1, x2
    6e94:	d360fc21 	lsr	x1, x1, #32
    6e98:	eb00003f 	cmp	x1, x0
    6e9c:	540000e2 	b.cs	6eb8 <f0+0x4c8>  // b.hs, b.nlast
    6ea0:	8b0102d6 	add	x22, x22, x1
    6ea4:	394002c0 	ldrb	w0, [x22]
    6ea8:	7103fc1f 	cmp	w0, #0xff
    6eac:	5400fee0 	b.eq	8e88 <f0+0x2498>  // b.none
    6eb0:	52800020 	mov	w0, #0x1                   	// #1
    6eb4:	390002c0 	strb	w0, [x22]
    6eb8:	9106a3e1 	add	x1, sp, #0x1a8
    6ebc:	b200e7f6 	mov	x22, #0x3333333333333333    	// #3689348814741910323
    6ec0:	f2f7fe76 	movk	x22, #0xbff3, lsl #48
    6ec4:	52800020 	mov	w0, #0x1                   	// #1
    6ec8:	a91ae7f6 	stp	x22, x25, [sp, #424]
    6ecc:	97fff43e 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6ed0:	97fff1ac 	bl	3580 <fwp_rc_fresh>
    6ed4:	aa0003e2 	mov	x2, x0
    6ed8:	9106e3e1 	add	x1, sp, #0x1b8
    6edc:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    6ee0:	52800020 	mov	w0, #0x1                   	// #1
    6ee4:	a91b8bf9 	stp	x25, x2, [sp, #440]
    6ee8:	97fff437 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6eec:	97fff1a5 	bl	3580 <fwp_rc_fresh>
    6ef0:	aa0003e2 	mov	x2, x0
    6ef4:	910723e1 	add	x1, sp, #0x1c8
    6ef8:	52800020 	mov	w0, #0x1                   	// #1
    6efc:	a91c8bf6 	stp	x22, x2, [sp, #456]
    6f00:	97fff431 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6f04:	97fff19f 	bl	3580 <fwp_rc_fresh>
    6f08:	aa0003e2 	mov	x2, x0
    6f0c:	910763e1 	add	x1, sp, #0x1d8
    6f10:	52800020 	mov	w0, #0x1                   	// #1
    6f14:	a91d8bf9 	stp	x25, x2, [sp, #472]
    6f18:	97fff42b 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6f1c:	97fff199 	bl	3580 <fwp_rc_fresh>
    6f20:	aa0003e2 	mov	x2, x0
    6f24:	9107a3e1 	add	x1, sp, #0x1e8
    6f28:	52800020 	mov	w0, #0x1                   	// #1
    6f2c:	a91e8bf6 	stp	x22, x2, [sp, #488]
    6f30:	97fff425 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6f34:	97fff193 	bl	3580 <fwp_rc_fresh>
    6f38:	aa0003e2 	mov	x2, x0
    6f3c:	9107e3e1 	add	x1, sp, #0x1f8
    6f40:	52800020 	mov	w0, #0x1                   	// #1
    6f44:	a91f8bf9 	stp	x25, x2, [sp, #504]
    6f48:	97fff41f 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6f4c:	97fff18d 	bl	3580 <fwp_rc_fresh>
    6f50:	aa0003e2 	mov	x2, x0
    6f54:	910823e1 	add	x1, sp, #0x208
    6f58:	52800020 	mov	w0, #0x1                   	// #1
    6f5c:	f90107f6 	str	x22, [sp, #520]
    6f60:	f9010be2 	str	x2, [sp, #528]
    6f64:	97fff418 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6f68:	97fff186 	bl	3580 <fwp_rc_fresh>
    6f6c:	aa0003e2 	mov	x2, x0
    6f70:	910863e1 	add	x1, sp, #0x218
    6f74:	52800020 	mov	w0, #0x1                   	// #1
    6f78:	f9010ff9 	str	x25, [sp, #536]
    6f7c:	f90113e2 	str	x2, [sp, #544]
    6f80:	97fff411 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6f84:	97fff17f 	bl	3580 <fwp_rc_fresh>
    6f88:	aa0003e2 	mov	x2, x0
    6f8c:	9108a3e1 	add	x1, sp, #0x228
    6f90:	52800020 	mov	w0, #0x1                   	// #1
    6f94:	f90117f6 	str	x22, [sp, #552]
    6f98:	f9011be2 	str	x2, [sp, #560]
    6f9c:	97fff40a 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6fa0:	97fff178 	bl	3580 <fwp_rc_fresh>
    6fa4:	aa0003e2 	mov	x2, x0
    6fa8:	9108e3e1 	add	x1, sp, #0x238
    6fac:	52800020 	mov	w0, #0x1                   	// #1
    6fb0:	f9011ff9 	str	x25, [sp, #568]
    6fb4:	f90123e2 	str	x2, [sp, #576]
    6fb8:	97fff403 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6fbc:	97fff171 	bl	3580 <fwp_rc_fresh>
    6fc0:	aa0003e2 	mov	x2, x0
    6fc4:	910923e1 	add	x1, sp, #0x248
    6fc8:	52800020 	mov	w0, #0x1                   	// #1
    6fcc:	f90127f6 	str	x22, [sp, #584]
    6fd0:	f9012be2 	str	x2, [sp, #592]
    6fd4:	97fff3fc 	bl	3fc4 <fwp_data.part.0.constprop.0>
    6fd8:	91134263 	add	x3, x19, #0x4d0
    6fdc:	aa0003f6 	mov	x22, x0
    6fe0:	f949d861 	ldr	x1, [x3, #5040]
    6fe4:	f949ec60 	ldr	x0, [x3, #5080]
    6fe8:	cb0102c1 	sub	x1, x22, x1
    6fec:	eb00403f 	cmp	x1, x0, lsl #16
    6ff0:	54000322 	b.cs	7054 <f0+0x664>  // b.hs, b.nlast
    6ff4:	d350fc22 	lsr	x2, x1, #16
    6ff8:	f949fc63 	ldr	x3, [x3, #5112]
    6ffc:	8b020842 	add	x2, x2, x2, lsl #2
    7000:	d37df042 	lsl	x2, x2, #3
    7004:	8b020060 	add	x0, x3, x2
    7008:	f9401019 	ldr	x25, [x0, #32]
    700c:	b4000259 	cbz	x25, 7054 <f0+0x664>
    7010:	38626862 	ldrb	w2, [x3, x2]
    7014:	7100085f 	cmp	w2, #0x2
    7018:	5400e9c0 	b.eq	8d50 <f0+0x2360>  // b.none
    701c:	7100045f 	cmp	w2, #0x1
    7020:	540001a1 	b.ne	7054 <f0+0x664>  // b.any
    7024:	29430002 	ldp	w2, w0, [x0, #24]
    7028:	92403c21 	and	x1, x1, #0xffff
    702c:	9b027c21 	mul	x1, x1, x2
    7030:	d360fc21 	lsr	x1, x1, #32
    7034:	eb00003f 	cmp	x1, x0
    7038:	540000e2 	b.cs	7054 <f0+0x664>  // b.hs, b.nlast
    703c:	8b010339 	add	x25, x25, x1
    7040:	39400320 	ldrb	w0, [x25]
    7044:	7103fc1f 	cmp	w0, #0xff
    7048:	5400f260 	b.eq	8e94 <f0+0x24a4>  // b.none
    704c:	52800020 	mov	w0, #0x1                   	// #1
    7050:	39000320 	strb	w0, [x25]
    7054:	910963e1 	add	x1, sp, #0x258
    7058:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    705c:	52800020 	mov	w0, #0x1                   	// #1
    7060:	f9012ff9 	str	x25, [sp, #600]
    7064:	f90133f6 	str	x22, [sp, #608]
    7068:	97fff3d7 	bl	3fc4 <fwp_data.part.0.constprop.0>
    706c:	97fff145 	bl	3580 <fwp_rc_fresh>
    7070:	aa0003e2 	mov	x2, x0
    7074:	9109a3e1 	add	x1, sp, #0x268
    7078:	b200e7f6 	mov	x22, #0x3333333333333333    	// #3689348814741910323
    707c:	f2f7fe76 	movk	x22, #0xbff3, lsl #48
    7080:	52800020 	mov	w0, #0x1                   	// #1
    7084:	f90137f6 	str	x22, [sp, #616]
    7088:	f9013be2 	str	x2, [sp, #624]
    708c:	97fff3ce 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7090:	97fff13c 	bl	3580 <fwp_rc_fresh>
    7094:	aa0003e2 	mov	x2, x0
    7098:	9109e3e1 	add	x1, sp, #0x278
    709c:	52800020 	mov	w0, #0x1                   	// #1
    70a0:	f9013ff9 	str	x25, [sp, #632]
    70a4:	f90143e2 	str	x2, [sp, #640]
    70a8:	97fff3c7 	bl	3fc4 <fwp_data.part.0.constprop.0>
    70ac:	97fff135 	bl	3580 <fwp_rc_fresh>
    70b0:	aa0003e2 	mov	x2, x0
    70b4:	910a23e1 	add	x1, sp, #0x288
    70b8:	52800020 	mov	w0, #0x1                   	// #1
    70bc:	f90147f6 	str	x22, [sp, #648]
    70c0:	f9014be2 	str	x2, [sp, #656]
    70c4:	97fff3c0 	bl	3fc4 <fwp_data.part.0.constprop.0>
    70c8:	91134263 	add	x3, x19, #0x4d0
    70cc:	aa0003f6 	mov	x22, x0
    70d0:	f949d861 	ldr	x1, [x3, #5040]
    70d4:	f949ec60 	ldr	x0, [x3, #5080]
    70d8:	cb0102c1 	sub	x1, x22, x1
    70dc:	eb00403f 	cmp	x1, x0, lsl #16
    70e0:	54000322 	b.cs	7144 <f0+0x754>  // b.hs, b.nlast
    70e4:	d350fc22 	lsr	x2, x1, #16
    70e8:	f949fc63 	ldr	x3, [x3, #5112]
    70ec:	8b020842 	add	x2, x2, x2, lsl #2
    70f0:	d37df042 	lsl	x2, x2, #3
    70f4:	8b020060 	add	x0, x3, x2
    70f8:	f9401019 	ldr	x25, [x0, #32]
    70fc:	b4000259 	cbz	x25, 7144 <f0+0x754>
    7100:	38626862 	ldrb	w2, [x3, x2]
    7104:	7100085f 	cmp	w2, #0x2
    7108:	5400e1e0 	b.eq	8d44 <f0+0x2354>  // b.none
    710c:	7100045f 	cmp	w2, #0x1
    7110:	540001a1 	b.ne	7144 <f0+0x754>  // b.any
    7114:	29430002 	ldp	w2, w0, [x0, #24]
    7118:	92403c21 	and	x1, x1, #0xffff
    711c:	9b027c21 	mul	x1, x1, x2
    7120:	d360fc21 	lsr	x1, x1, #32
    7124:	eb00003f 	cmp	x1, x0
    7128:	540000e2 	b.cs	7144 <f0+0x754>  // b.hs, b.nlast
    712c:	8b010339 	add	x25, x25, x1
    7130:	39400320 	ldrb	w0, [x25]
    7134:	7103fc1f 	cmp	w0, #0xff
    7138:	5400eb40 	b.eq	8ea0 <f0+0x24b0>  // b.none
    713c:	52800020 	mov	w0, #0x1                   	// #1
    7140:	39000320 	strb	w0, [x25]
    7144:	910a63e1 	add	x1, sp, #0x298
    7148:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    714c:	52800020 	mov	w0, #0x1                   	// #1
    7150:	f9014ff9 	str	x25, [sp, #664]
    7154:	f90153f6 	str	x22, [sp, #672]
    7158:	97fff39b 	bl	3fc4 <fwp_data.part.0.constprop.0>
    715c:	97fff109 	bl	3580 <fwp_rc_fresh>
    7160:	aa0003e2 	mov	x2, x0
    7164:	910aa3e1 	add	x1, sp, #0x2a8
    7168:	b200e7f6 	mov	x22, #0x3333333333333333    	// #3689348814741910323
    716c:	f2f7fe76 	movk	x22, #0xbff3, lsl #48
    7170:	52800020 	mov	w0, #0x1                   	// #1
    7174:	f90157f6 	str	x22, [sp, #680]
    7178:	f9015be2 	str	x2, [sp, #688]
    717c:	97fff392 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7180:	97fff100 	bl	3580 <fwp_rc_fresh>
    7184:	aa0003e2 	mov	x2, x0
    7188:	910ae3e1 	add	x1, sp, #0x2b8
    718c:	52800020 	mov	w0, #0x1                   	// #1
    7190:	f9015ff9 	str	x25, [sp, #696]
    7194:	f90163e2 	str	x2, [sp, #704]
    7198:	97fff38b 	bl	3fc4 <fwp_data.part.0.constprop.0>
    719c:	97fff0f9 	bl	3580 <fwp_rc_fresh>
    71a0:	aa0003e2 	mov	x2, x0
    71a4:	910b23e1 	add	x1, sp, #0x2c8
    71a8:	52800020 	mov	w0, #0x1                   	// #1
    71ac:	f90167f6 	str	x22, [sp, #712]
    71b0:	f9016be2 	str	x2, [sp, #720]
    71b4:	97fff384 	bl	3fc4 <fwp_data.part.0.constprop.0>
    71b8:	91134263 	add	x3, x19, #0x4d0
    71bc:	aa0003f6 	mov	x22, x0
    71c0:	f949d861 	ldr	x1, [x3, #5040]
    71c4:	f949ec60 	ldr	x0, [x3, #5080]
    71c8:	cb0102c1 	sub	x1, x22, x1
    71cc:	eb00403f 	cmp	x1, x0, lsl #16
    71d0:	54000322 	b.cs	7234 <f0+0x844>  // b.hs, b.nlast
    71d4:	d350fc22 	lsr	x2, x1, #16
    71d8:	f949fc63 	ldr	x3, [x3, #5112]
    71dc:	8b020842 	add	x2, x2, x2, lsl #2
    71e0:	d37df042 	lsl	x2, x2, #3
    71e4:	8b020060 	add	x0, x3, x2
    71e8:	f9401019 	ldr	x25, [x0, #32]
    71ec:	b4000259 	cbz	x25, 7234 <f0+0x844>
    71f0:	38626862 	ldrb	w2, [x3, x2]
    71f4:	7100085f 	cmp	w2, #0x2
    71f8:	5400db80 	b.eq	8d68 <f0+0x2378>  // b.none
    71fc:	7100045f 	cmp	w2, #0x1
    7200:	540001a1 	b.ne	7234 <f0+0x844>  // b.any
    7204:	29430002 	ldp	w2, w0, [x0, #24]
    7208:	92403c21 	and	x1, x1, #0xffff
    720c:	9b027c21 	mul	x1, x1, x2
    7210:	d360fc21 	lsr	x1, x1, #32
    7214:	eb00003f 	cmp	x1, x0
    7218:	540000e2 	b.cs	7234 <f0+0x844>  // b.hs, b.nlast
    721c:	8b010339 	add	x25, x25, x1
    7220:	39400320 	ldrb	w0, [x25]
    7224:	7103fc1f 	cmp	w0, #0xff
    7228:	5400e420 	b.eq	8eac <f0+0x24bc>  // b.none
    722c:	52800020 	mov	w0, #0x1                   	// #1
    7230:	39000320 	strb	w0, [x25]
    7234:	910b63e1 	add	x1, sp, #0x2d8
    7238:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    723c:	52800020 	mov	w0, #0x1                   	// #1
    7240:	f9016fe2 	str	x2, [sp, #728]
    7244:	f90173f6 	str	x22, [sp, #736]
    7248:	97fff35f 	bl	3fc4 <fwp_data.part.0.constprop.0>
    724c:	97fff0cd 	bl	3580 <fwp_rc_fresh>
    7250:	aa0003e2 	mov	x2, x0
    7254:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7258:	910ba3e1 	add	x1, sp, #0x2e8
    725c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7260:	52800020 	mov	w0, #0x1                   	// #1
    7264:	f90177e3 	str	x3, [sp, #744]
    7268:	f9017be2 	str	x2, [sp, #752]
    726c:	97fff356 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7270:	91134263 	add	x3, x19, #0x4d0
    7274:	aa0003f6 	mov	x22, x0
    7278:	f949d861 	ldr	x1, [x3, #5040]
    727c:	f949ec60 	ldr	x0, [x3, #5080]
    7280:	cb0102c1 	sub	x1, x22, x1
    7284:	eb00403f 	cmp	x1, x0, lsl #16
    7288:	54000322 	b.cs	72ec <f0+0x8fc>  // b.hs, b.nlast
    728c:	d350fc22 	lsr	x2, x1, #16
    7290:	f949fc63 	ldr	x3, [x3, #5112]
    7294:	8b020842 	add	x2, x2, x2, lsl #2
    7298:	d37df042 	lsl	x2, x2, #3
    729c:	8b020060 	add	x0, x3, x2
    72a0:	f9401019 	ldr	x25, [x0, #32]
    72a4:	b4000259 	cbz	x25, 72ec <f0+0x8fc>
    72a8:	38626862 	ldrb	w2, [x3, x2]
    72ac:	7100085f 	cmp	w2, #0x2
    72b0:	5400d560 	b.eq	8d5c <f0+0x236c>  // b.none
    72b4:	7100045f 	cmp	w2, #0x1
    72b8:	540001a1 	b.ne	72ec <f0+0x8fc>  // b.any
    72bc:	29430002 	ldp	w2, w0, [x0, #24]
    72c0:	92403c21 	and	x1, x1, #0xffff
    72c4:	9b027c21 	mul	x1, x1, x2
    72c8:	d360fc21 	lsr	x1, x1, #32
    72cc:	eb00003f 	cmp	x1, x0
    72d0:	540000e2 	b.cs	72ec <f0+0x8fc>  // b.hs, b.nlast
    72d4:	8b010339 	add	x25, x25, x1
    72d8:	39400320 	ldrb	w0, [x25]
    72dc:	7103fc1f 	cmp	w0, #0xff
    72e0:	5400dec0 	b.eq	8eb8 <f0+0x24c8>  // b.none
    72e4:	52800020 	mov	w0, #0x1                   	// #1
    72e8:	39000320 	strb	w0, [x25]
    72ec:	910be3e1 	add	x1, sp, #0x2f8
    72f0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    72f4:	52800020 	mov	w0, #0x1                   	// #1
    72f8:	f9017fe2 	str	x2, [sp, #760]
    72fc:	f90183f6 	str	x22, [sp, #768]
    7300:	97fff331 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7304:	97fff09f 	bl	3580 <fwp_rc_fresh>
    7308:	aa0003e2 	mov	x2, x0
    730c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7310:	910c23e1 	add	x1, sp, #0x308
    7314:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7318:	52800020 	mov	w0, #0x1                   	// #1
    731c:	f90187e3 	str	x3, [sp, #776]
    7320:	f9018be2 	str	x2, [sp, #784]
    7324:	97fff328 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7328:	91134263 	add	x3, x19, #0x4d0
    732c:	aa0003f6 	mov	x22, x0
    7330:	f949d861 	ldr	x1, [x3, #5040]
    7334:	f949ec60 	ldr	x0, [x3, #5080]
    7338:	cb0102c1 	sub	x1, x22, x1
    733c:	eb00403f 	cmp	x1, x0, lsl #16
    7340:	54000322 	b.cs	73a4 <f0+0x9b4>  // b.hs, b.nlast
    7344:	d350fc22 	lsr	x2, x1, #16
    7348:	f949fc63 	ldr	x3, [x3, #5112]
    734c:	8b020842 	add	x2, x2, x2, lsl #2
    7350:	d37df042 	lsl	x2, x2, #3
    7354:	8b020060 	add	x0, x3, x2
    7358:	f9401019 	ldr	x25, [x0, #32]
    735c:	b4000259 	cbz	x25, 73a4 <f0+0x9b4>
    7360:	38626862 	ldrb	w2, [x3, x2]
    7364:	7100085f 	cmp	w2, #0x2
    7368:	5400d0c0 	b.eq	8d80 <f0+0x2390>  // b.none
    736c:	7100045f 	cmp	w2, #0x1
    7370:	540001a1 	b.ne	73a4 <f0+0x9b4>  // b.any
    7374:	29430002 	ldp	w2, w0, [x0, #24]
    7378:	92403c21 	and	x1, x1, #0xffff
    737c:	9b027c21 	mul	x1, x1, x2
    7380:	d360fc21 	lsr	x1, x1, #32
    7384:	eb00003f 	cmp	x1, x0
    7388:	540000e2 	b.cs	73a4 <f0+0x9b4>  // b.hs, b.nlast
    738c:	8b010339 	add	x25, x25, x1
    7390:	39400320 	ldrb	w0, [x25]
    7394:	7103fc1f 	cmp	w0, #0xff
    7398:	5400d960 	b.eq	8ec4 <f0+0x24d4>  // b.none
    739c:	52800020 	mov	w0, #0x1                   	// #1
    73a0:	39000320 	strb	w0, [x25]
    73a4:	910c63e1 	add	x1, sp, #0x318
    73a8:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    73ac:	52800020 	mov	w0, #0x1                   	// #1
    73b0:	f9018ff9 	str	x25, [sp, #792]
    73b4:	f90193f6 	str	x22, [sp, #800]
    73b8:	97fff303 	bl	3fc4 <fwp_data.part.0.constprop.0>
    73bc:	97fff071 	bl	3580 <fwp_rc_fresh>
    73c0:	aa0003e2 	mov	x2, x0
    73c4:	910ca3e1 	add	x1, sp, #0x328
    73c8:	b200e7f6 	mov	x22, #0x3333333333333333    	// #3689348814741910323
    73cc:	f2f7fe76 	movk	x22, #0xbff3, lsl #48
    73d0:	52800020 	mov	w0, #0x1                   	// #1
    73d4:	f90197f6 	str	x22, [sp, #808]
    73d8:	f9019be2 	str	x2, [sp, #816]
    73dc:	97fff2fa 	bl	3fc4 <fwp_data.part.0.constprop.0>
    73e0:	97fff068 	bl	3580 <fwp_rc_fresh>
    73e4:	aa0003e2 	mov	x2, x0
    73e8:	910ce3e1 	add	x1, sp, #0x338
    73ec:	52800020 	mov	w0, #0x1                   	// #1
    73f0:	f9019ff9 	str	x25, [sp, #824]
    73f4:	f901a3e2 	str	x2, [sp, #832]
    73f8:	97fff2f3 	bl	3fc4 <fwp_data.part.0.constprop.0>
    73fc:	97fff061 	bl	3580 <fwp_rc_fresh>
    7400:	aa0003e2 	mov	x2, x0
    7404:	910d23e1 	add	x1, sp, #0x348
    7408:	52800020 	mov	w0, #0x1                   	// #1
    740c:	f901a7f6 	str	x22, [sp, #840]
    7410:	f901abe2 	str	x2, [sp, #848]
    7414:	97fff2ec 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7418:	91134263 	add	x3, x19, #0x4d0
    741c:	aa0003f6 	mov	x22, x0
    7420:	f949d861 	ldr	x1, [x3, #5040]
    7424:	f949ec60 	ldr	x0, [x3, #5080]
    7428:	cb0102c1 	sub	x1, x22, x1
    742c:	eb00403f 	cmp	x1, x0, lsl #16
    7430:	54000322 	b.cs	7494 <f0+0xaa4>  // b.hs, b.nlast
    7434:	d350fc22 	lsr	x2, x1, #16
    7438:	f949fc63 	ldr	x3, [x3, #5112]
    743c:	8b020842 	add	x2, x2, x2, lsl #2
    7440:	d37df042 	lsl	x2, x2, #3
    7444:	8b020060 	add	x0, x3, x2
    7448:	f9401019 	ldr	x25, [x0, #32]
    744c:	b4000259 	cbz	x25, 7494 <f0+0xaa4>
    7450:	38626862 	ldrb	w2, [x3, x2]
    7454:	7100085f 	cmp	w2, #0x2
    7458:	5400c8e0 	b.eq	8d74 <f0+0x2384>  // b.none
    745c:	7100045f 	cmp	w2, #0x1
    7460:	540001a1 	b.ne	7494 <f0+0xaa4>  // b.any
    7464:	29430002 	ldp	w2, w0, [x0, #24]
    7468:	92403c21 	and	x1, x1, #0xffff
    746c:	9b027c21 	mul	x1, x1, x2
    7470:	d360fc21 	lsr	x1, x1, #32
    7474:	eb00003f 	cmp	x1, x0
    7478:	540000e2 	b.cs	7494 <f0+0xaa4>  // b.hs, b.nlast
    747c:	8b010339 	add	x25, x25, x1
    7480:	39400320 	ldrb	w0, [x25]
    7484:	7103fc1f 	cmp	w0, #0xff
    7488:	5400d240 	b.eq	8ed0 <f0+0x24e0>  // b.none
    748c:	52800020 	mov	w0, #0x1                   	// #1
    7490:	39000320 	strb	w0, [x25]
    7494:	910d63e1 	add	x1, sp, #0x358
    7498:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    749c:	52800020 	mov	w0, #0x1                   	// #1
    74a0:	f901aff9 	str	x25, [sp, #856]
    74a4:	f901b3f6 	str	x22, [sp, #864]
    74a8:	97fff2c7 	bl	3fc4 <fwp_data.part.0.constprop.0>
    74ac:	97fff035 	bl	3580 <fwp_rc_fresh>
    74b0:	aa0003e2 	mov	x2, x0
    74b4:	910da3e1 	add	x1, sp, #0x368
    74b8:	b200e7f6 	mov	x22, #0x3333333333333333    	// #3689348814741910323
    74bc:	f2f7fe76 	movk	x22, #0xbff3, lsl #48
    74c0:	52800020 	mov	w0, #0x1                   	// #1
    74c4:	f901b7f6 	str	x22, [sp, #872]
    74c8:	f901bbe2 	str	x2, [sp, #880]
    74cc:	97fff2be 	bl	3fc4 <fwp_data.part.0.constprop.0>
    74d0:	97fff02c 	bl	3580 <fwp_rc_fresh>
    74d4:	aa0003e2 	mov	x2, x0
    74d8:	910de3e1 	add	x1, sp, #0x378
    74dc:	52800020 	mov	w0, #0x1                   	// #1
    74e0:	f901bff9 	str	x25, [sp, #888]
    74e4:	f901c3e2 	str	x2, [sp, #896]
    74e8:	97fff2b7 	bl	3fc4 <fwp_data.part.0.constprop.0>
    74ec:	97fff025 	bl	3580 <fwp_rc_fresh>
    74f0:	aa0003e2 	mov	x2, x0
    74f4:	910e23e1 	add	x1, sp, #0x388
    74f8:	52800020 	mov	w0, #0x1                   	// #1
    74fc:	f901c7f6 	str	x22, [sp, #904]
    7500:	f901cbe2 	str	x2, [sp, #912]
    7504:	97fff2b0 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7508:	91134263 	add	x3, x19, #0x4d0
    750c:	aa0003f6 	mov	x22, x0
    7510:	f949d861 	ldr	x1, [x3, #5040]
    7514:	f949ec60 	ldr	x0, [x3, #5080]
    7518:	cb0102c1 	sub	x1, x22, x1
    751c:	eb00403f 	cmp	x1, x0, lsl #16
    7520:	54000322 	b.cs	7584 <f0+0xb94>  // b.hs, b.nlast
    7524:	d350fc22 	lsr	x2, x1, #16
    7528:	f949fc63 	ldr	x3, [x3, #5112]
    752c:	8b020842 	add	x2, x2, x2, lsl #2
    7530:	d37df042 	lsl	x2, x2, #3
    7534:	8b020060 	add	x0, x3, x2
    7538:	f9401019 	ldr	x25, [x0, #32]
    753c:	b4000259 	cbz	x25, 7584 <f0+0xb94>
    7540:	38626862 	ldrb	w2, [x3, x2]
    7544:	7100085f 	cmp	w2, #0x2
    7548:	5400c280 	b.eq	8d98 <f0+0x23a8>  // b.none
    754c:	7100045f 	cmp	w2, #0x1
    7550:	540001a1 	b.ne	7584 <f0+0xb94>  // b.any
    7554:	29430002 	ldp	w2, w0, [x0, #24]
    7558:	92403c21 	and	x1, x1, #0xffff
    755c:	9b027c21 	mul	x1, x1, x2
    7560:	d360fc21 	lsr	x1, x1, #32
    7564:	eb00003f 	cmp	x1, x0
    7568:	540000e2 	b.cs	7584 <f0+0xb94>  // b.hs, b.nlast
    756c:	8b010339 	add	x25, x25, x1
    7570:	39400320 	ldrb	w0, [x25]
    7574:	7103fc1f 	cmp	w0, #0xff
    7578:	5400cb20 	b.eq	8edc <f0+0x24ec>  // b.none
    757c:	52800020 	mov	w0, #0x1                   	// #1
    7580:	39000320 	strb	w0, [x25]
    7584:	910e63e1 	add	x1, sp, #0x398
    7588:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    758c:	52800020 	mov	w0, #0x1                   	// #1
    7590:	f901cff9 	str	x25, [sp, #920]
    7594:	f901d3f6 	str	x22, [sp, #928]
    7598:	97fff28b 	bl	3fc4 <fwp_data.part.0.constprop.0>
    759c:	97ffeff9 	bl	3580 <fwp_rc_fresh>
    75a0:	aa0003e2 	mov	x2, x0
    75a4:	910ea3e1 	add	x1, sp, #0x3a8
    75a8:	b200e7f6 	mov	x22, #0x3333333333333333    	// #3689348814741910323
    75ac:	f2f7fe76 	movk	x22, #0xbff3, lsl #48
    75b0:	52800020 	mov	w0, #0x1                   	// #1
    75b4:	f901d7f6 	str	x22, [sp, #936]
    75b8:	f901dbe2 	str	x2, [sp, #944]
    75bc:	97fff282 	bl	3fc4 <fwp_data.part.0.constprop.0>
    75c0:	97ffeff0 	bl	3580 <fwp_rc_fresh>
    75c4:	aa0003e2 	mov	x2, x0
    75c8:	910ee3e1 	add	x1, sp, #0x3b8
    75cc:	52800020 	mov	w0, #0x1                   	// #1
    75d0:	f901dff9 	str	x25, [sp, #952]
    75d4:	f901e3e2 	str	x2, [sp, #960]
    75d8:	97fff27b 	bl	3fc4 <fwp_data.part.0.constprop.0>
    75dc:	97ffefe9 	bl	3580 <fwp_rc_fresh>
    75e0:	aa0003e2 	mov	x2, x0
    75e4:	910f23e1 	add	x1, sp, #0x3c8
    75e8:	52800020 	mov	w0, #0x1                   	// #1
    75ec:	f901e7f6 	str	x22, [sp, #968]
    75f0:	f901ebe2 	str	x2, [sp, #976]
    75f4:	97fff274 	bl	3fc4 <fwp_data.part.0.constprop.0>
    75f8:	97ffefe2 	bl	3580 <fwp_rc_fresh>
    75fc:	aa0003e2 	mov	x2, x0
    7600:	910f63e1 	add	x1, sp, #0x3d8
    7604:	52800020 	mov	w0, #0x1                   	// #1
    7608:	f901eff9 	str	x25, [sp, #984]
    760c:	f901f3e2 	str	x2, [sp, #992]
    7610:	97fff26d 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7614:	97ffefdb 	bl	3580 <fwp_rc_fresh>
    7618:	aa0003e2 	mov	x2, x0
    761c:	910fa3e1 	add	x1, sp, #0x3e8
    7620:	52800020 	mov	w0, #0x1                   	// #1
    7624:	f901f7f6 	str	x22, [sp, #1000]
    7628:	f901fbe2 	str	x2, [sp, #1008]
    762c:	97fff266 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7630:	97ffefd4 	bl	3580 <fwp_rc_fresh>
    7634:	aa0003e2 	mov	x2, x0
    7638:	910fe3e1 	add	x1, sp, #0x3f8
    763c:	52800020 	mov	w0, #0x1                   	// #1
    7640:	f901fff9 	str	x25, [sp, #1016]
    7644:	f90203e2 	str	x2, [sp, #1024]
    7648:	97fff25f 	bl	3fc4 <fwp_data.part.0.constprop.0>
    764c:	91134263 	add	x3, x19, #0x4d0
    7650:	aa0003f6 	mov	x22, x0
    7654:	f949d861 	ldr	x1, [x3, #5040]
    7658:	f949ec60 	ldr	x0, [x3, #5080]
    765c:	cb0102c1 	sub	x1, x22, x1
    7660:	eb00403f 	cmp	x1, x0, lsl #16
    7664:	54000322 	b.cs	76c8 <f0+0xcd8>  // b.hs, b.nlast
    7668:	d350fc22 	lsr	x2, x1, #16
    766c:	f949fc63 	ldr	x3, [x3, #5112]
    7670:	8b020842 	add	x2, x2, x2, lsl #2
    7674:	d37df042 	lsl	x2, x2, #3
    7678:	8b020060 	add	x0, x3, x2
    767c:	f9401019 	ldr	x25, [x0, #32]
    7680:	b4000259 	cbz	x25, 76c8 <f0+0xcd8>
    7684:	38626862 	ldrb	w2, [x3, x2]
    7688:	7100085f 	cmp	w2, #0x2
    768c:	5400b800 	b.eq	8d8c <f0+0x239c>  // b.none
    7690:	7100045f 	cmp	w2, #0x1
    7694:	540001a1 	b.ne	76c8 <f0+0xcd8>  // b.any
    7698:	29430002 	ldp	w2, w0, [x0, #24]
    769c:	92403c21 	and	x1, x1, #0xffff
    76a0:	9b027c21 	mul	x1, x1, x2
    76a4:	d360fc21 	lsr	x1, x1, #32
    76a8:	eb00003f 	cmp	x1, x0
    76ac:	540000e2 	b.cs	76c8 <f0+0xcd8>  // b.hs, b.nlast
    76b0:	8b010339 	add	x25, x25, x1
    76b4:	39400320 	ldrb	w0, [x25]
    76b8:	7103fc1f 	cmp	w0, #0xff
    76bc:	5400c160 	b.eq	8ee8 <f0+0x24f8>  // b.none
    76c0:	52800020 	mov	w0, #0x1                   	// #1
    76c4:	39000320 	strb	w0, [x25]
    76c8:	911023e1 	add	x1, sp, #0x408
    76cc:	b200e7f9 	mov	x25, #0x3333333333333333    	// #3689348814741910323
    76d0:	f2f7fe79 	movk	x25, #0xbff3, lsl #48
    76d4:	52800020 	mov	w0, #0x1                   	// #1
    76d8:	f90207f9 	str	x25, [sp, #1032]
    76dc:	f9020bf6 	str	x22, [sp, #1040]
    76e0:	97fff239 	bl	3fc4 <fwp_data.part.0.constprop.0>
    76e4:	97ffefa7 	bl	3580 <fwp_rc_fresh>
    76e8:	aa0003e2 	mov	x2, x0
    76ec:	911063e1 	add	x1, sp, #0x418
    76f0:	d2e7fe16 	mov	x22, #0x3ff0000000000000    	// #4607182418800017408
    76f4:	52800020 	mov	w0, #0x1                   	// #1
    76f8:	f9020ff6 	str	x22, [sp, #1048]
    76fc:	f90213e2 	str	x2, [sp, #1056]
    7700:	97fff231 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7704:	97ffef9f 	bl	3580 <fwp_rc_fresh>
    7708:	aa0003e2 	mov	x2, x0
    770c:	9110a3e1 	add	x1, sp, #0x428
    7710:	52800020 	mov	w0, #0x1                   	// #1
    7714:	f90217f9 	str	x25, [sp, #1064]
    7718:	f9021be2 	str	x2, [sp, #1072]
    771c:	97fff22a 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7720:	97ffef98 	bl	3580 <fwp_rc_fresh>
    7724:	aa0003e2 	mov	x2, x0
    7728:	9110e3e1 	add	x1, sp, #0x438
    772c:	52800020 	mov	w0, #0x1                   	// #1
    7730:	f9021ff6 	str	x22, [sp, #1080]
    7734:	f90223e2 	str	x2, [sp, #1088]
    7738:	97fff223 	bl	3fc4 <fwp_data.part.0.constprop.0>
    773c:	97ffef91 	bl	3580 <fwp_rc_fresh>
    7740:	aa0003e2 	mov	x2, x0
    7744:	911123e1 	add	x1, sp, #0x448
    7748:	52800020 	mov	w0, #0x1                   	// #1
    774c:	f90227f9 	str	x25, [sp, #1096]
    7750:	f9022be2 	str	x2, [sp, #1104]
    7754:	97fff21c 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7758:	91134263 	add	x3, x19, #0x4d0
    775c:	aa0003f6 	mov	x22, x0
    7760:	f949d861 	ldr	x1, [x3, #5040]
    7764:	f949ec60 	ldr	x0, [x3, #5080]
    7768:	cb0102c1 	sub	x1, x22, x1
    776c:	eb00403f 	cmp	x1, x0, lsl #16
    7770:	54000322 	b.cs	77d4 <f0+0xde4>  // b.hs, b.nlast
    7774:	d350fc22 	lsr	x2, x1, #16
    7778:	f949fc63 	ldr	x3, [x3, #5112]
    777c:	8b020842 	add	x2, x2, x2, lsl #2
    7780:	d37df042 	lsl	x2, x2, #3
    7784:	8b020060 	add	x0, x3, x2
    7788:	f9401019 	ldr	x25, [x0, #32]
    778c:	b4000259 	cbz	x25, 77d4 <f0+0xde4>
    7790:	38626862 	ldrb	w2, [x3, x2]
    7794:	7100085f 	cmp	w2, #0x2
    7798:	5400aac0 	b.eq	8cf0 <f0+0x2300>  // b.none
    779c:	7100045f 	cmp	w2, #0x1
    77a0:	540001a1 	b.ne	77d4 <f0+0xde4>  // b.any
    77a4:	29430002 	ldp	w2, w0, [x0, #24]
    77a8:	92403c21 	and	x1, x1, #0xffff
    77ac:	9b027c21 	mul	x1, x1, x2
    77b0:	d360fc21 	lsr	x1, x1, #32
    77b4:	eb00003f 	cmp	x1, x0
    77b8:	540000e2 	b.cs	77d4 <f0+0xde4>  // b.hs, b.nlast
    77bc:	8b010339 	add	x25, x25, x1
    77c0:	39400320 	ldrb	w0, [x25]
    77c4:	7103fc1f 	cmp	w0, #0xff
    77c8:	5400b960 	b.eq	8ef4 <f0+0x2504>  // b.none
    77cc:	52800020 	mov	w0, #0x1                   	// #1
    77d0:	39000320 	strb	w0, [x25]
    77d4:	911163e1 	add	x1, sp, #0x458
    77d8:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    77dc:	52800020 	mov	w0, #0x1                   	// #1
    77e0:	f9022ff9 	str	x25, [sp, #1112]
    77e4:	f90233f6 	str	x22, [sp, #1120]
    77e8:	97fff1f7 	bl	3fc4 <fwp_data.part.0.constprop.0>
    77ec:	97ffef65 	bl	3580 <fwp_rc_fresh>
    77f0:	aa0003e2 	mov	x2, x0
    77f4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    77f8:	9111a3e1 	add	x1, sp, #0x468
    77fc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7800:	52800020 	mov	w0, #0x1                   	// #1
    7804:	f90237e3 	str	x3, [sp, #1128]
    7808:	f9023be2 	str	x2, [sp, #1136]
    780c:	97fff1ee 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7810:	97ffef5c 	bl	3580 <fwp_rc_fresh>
    7814:	aa0003e2 	mov	x2, x0
    7818:	9111e3e1 	add	x1, sp, #0x478
    781c:	52800020 	mov	w0, #0x1                   	// #1
    7820:	f9023ff9 	str	x25, [sp, #1144]
    7824:	f90243e2 	str	x2, [sp, #1152]
    7828:	97fff1e7 	bl	3fc4 <fwp_data.part.0.constprop.0>
    782c:	91134263 	add	x3, x19, #0x4d0
    7830:	aa0003f6 	mov	x22, x0
    7834:	f949d861 	ldr	x1, [x3, #5040]
    7838:	f949ec60 	ldr	x0, [x3, #5080]
    783c:	cb0102c1 	sub	x1, x22, x1
    7840:	eb00403f 	cmp	x1, x0, lsl #16
    7844:	54000322 	b.cs	78a8 <f0+0xeb8>  // b.hs, b.nlast
    7848:	d350fc22 	lsr	x2, x1, #16
    784c:	f949fc63 	ldr	x3, [x3, #5112]
    7850:	8b020842 	add	x2, x2, x2, lsl #2
    7854:	d37df042 	lsl	x2, x2, #3
    7858:	8b020060 	add	x0, x3, x2
    785c:	f9401019 	ldr	x25, [x0, #32]
    7860:	b4000259 	cbz	x25, 78a8 <f0+0xeb8>
    7864:	38626862 	ldrb	w2, [x3, x2]
    7868:	7100085f 	cmp	w2, #0x2
    786c:	5400a3c0 	b.eq	8ce4 <f0+0x22f4>  // b.none
    7870:	7100045f 	cmp	w2, #0x1
    7874:	540001a1 	b.ne	78a8 <f0+0xeb8>  // b.any
    7878:	29430002 	ldp	w2, w0, [x0, #24]
    787c:	92403c21 	and	x1, x1, #0xffff
    7880:	9b027c21 	mul	x1, x1, x2
    7884:	d360fc21 	lsr	x1, x1, #32
    7888:	eb00003f 	cmp	x1, x0
    788c:	540000e2 	b.cs	78a8 <f0+0xeb8>  // b.hs, b.nlast
    7890:	8b010339 	add	x25, x25, x1
    7894:	39400320 	ldrb	w0, [x25]
    7898:	7103fc1f 	cmp	w0, #0xff
    789c:	5400b320 	b.eq	8f00 <f0+0x2510>  // b.none
    78a0:	52800020 	mov	w0, #0x1                   	// #1
    78a4:	39000320 	strb	w0, [x25]
    78a8:	911223e1 	add	x1, sp, #0x488
    78ac:	b200e7f9 	mov	x25, #0x3333333333333333    	// #3689348814741910323
    78b0:	f2f7fe79 	movk	x25, #0xbff3, lsl #48
    78b4:	52800020 	mov	w0, #0x1                   	// #1
    78b8:	f90247f9 	str	x25, [sp, #1160]
    78bc:	f9024bf6 	str	x22, [sp, #1168]
    78c0:	97fff1c1 	bl	3fc4 <fwp_data.part.0.constprop.0>
    78c4:	97ffef2f 	bl	3580 <fwp_rc_fresh>
    78c8:	aa0003e2 	mov	x2, x0
    78cc:	911263e1 	add	x1, sp, #0x498
    78d0:	d2e7fe16 	mov	x22, #0x3ff0000000000000    	// #4607182418800017408
    78d4:	52800020 	mov	w0, #0x1                   	// #1
    78d8:	f9024ff6 	str	x22, [sp, #1176]
    78dc:	f90253e2 	str	x2, [sp, #1184]
    78e0:	97fff1b9 	bl	3fc4 <fwp_data.part.0.constprop.0>
    78e4:	97ffef27 	bl	3580 <fwp_rc_fresh>
    78e8:	aa0003e2 	mov	x2, x0
    78ec:	9112a3e1 	add	x1, sp, #0x4a8
    78f0:	52800020 	mov	w0, #0x1                   	// #1
    78f4:	f90257f9 	str	x25, [sp, #1192]
    78f8:	f9025be2 	str	x2, [sp, #1200]
    78fc:	97fff1b2 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7900:	97ffef20 	bl	3580 <fwp_rc_fresh>
    7904:	aa0003e2 	mov	x2, x0
    7908:	9112e3e1 	add	x1, sp, #0x4b8
    790c:	52800020 	mov	w0, #0x1                   	// #1
    7910:	f9025ff6 	str	x22, [sp, #1208]
    7914:	f90263e2 	str	x2, [sp, #1216]
    7918:	97fff1ab 	bl	3fc4 <fwp_data.part.0.constprop.0>
    791c:	97ffef19 	bl	3580 <fwp_rc_fresh>
    7920:	aa0003e2 	mov	x2, x0
    7924:	911323e1 	add	x1, sp, #0x4c8
    7928:	52800020 	mov	w0, #0x1                   	// #1
    792c:	f90267f9 	str	x25, [sp, #1224]
    7930:	f9026be2 	str	x2, [sp, #1232]
    7934:	97fff1a4 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7938:	91134263 	add	x3, x19, #0x4d0
    793c:	aa0003f6 	mov	x22, x0
    7940:	f949d861 	ldr	x1, [x3, #5040]
    7944:	f949ec60 	ldr	x0, [x3, #5080]
    7948:	cb0102c1 	sub	x1, x22, x1
    794c:	eb00403f 	cmp	x1, x0, lsl #16
    7950:	54000322 	b.cs	79b4 <f0+0xfc4>  // b.hs, b.nlast
    7954:	d350fc22 	lsr	x2, x1, #16
    7958:	f949fc63 	ldr	x3, [x3, #5112]
    795c:	8b020842 	add	x2, x2, x2, lsl #2
    7960:	d37df042 	lsl	x2, x2, #3
    7964:	8b020060 	add	x0, x3, x2
    7968:	f9401019 	ldr	x25, [x0, #32]
    796c:	b4000259 	cbz	x25, 79b4 <f0+0xfc4>
    7970:	38626862 	ldrb	w2, [x3, x2]
    7974:	7100085f 	cmp	w2, #0x2
    7978:	54009c80 	b.eq	8d08 <f0+0x2318>  // b.none
    797c:	7100045f 	cmp	w2, #0x1
    7980:	540001a1 	b.ne	79b4 <f0+0xfc4>  // b.any
    7984:	29430002 	ldp	w2, w0, [x0, #24]
    7988:	92403c21 	and	x1, x1, #0xffff
    798c:	9b027c21 	mul	x1, x1, x2
    7990:	d360fc21 	lsr	x1, x1, #32
    7994:	eb00003f 	cmp	x1, x0
    7998:	540000e2 	b.cs	79b4 <f0+0xfc4>  // b.hs, b.nlast
    799c:	8b010339 	add	x25, x25, x1
    79a0:	39400320 	ldrb	w0, [x25]
    79a4:	7103fc1f 	cmp	w0, #0xff
    79a8:	5400ab20 	b.eq	8f0c <f0+0x251c>  // b.none
    79ac:	52800020 	mov	w0, #0x1                   	// #1
    79b0:	39000320 	strb	w0, [x25]
    79b4:	911363e1 	add	x1, sp, #0x4d8
    79b8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    79bc:	52800020 	mov	w0, #0x1                   	// #1
    79c0:	f9026fe2 	str	x2, [sp, #1240]
    79c4:	f90273f6 	str	x22, [sp, #1248]
    79c8:	97fff17f 	bl	3fc4 <fwp_data.part.0.constprop.0>
    79cc:	97ffeeed 	bl	3580 <fwp_rc_fresh>
    79d0:	aa0003e2 	mov	x2, x0
    79d4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    79d8:	9113a3e1 	add	x1, sp, #0x4e8
    79dc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    79e0:	52800020 	mov	w0, #0x1                   	// #1
    79e4:	f90277e3 	str	x3, [sp, #1256]
    79e8:	f9027be2 	str	x2, [sp, #1264]
    79ec:	97fff176 	bl	3fc4 <fwp_data.part.0.constprop.0>
    79f0:	91134263 	add	x3, x19, #0x4d0
    79f4:	aa0003f6 	mov	x22, x0
    79f8:	f949d861 	ldr	x1, [x3, #5040]
    79fc:	f949ec60 	ldr	x0, [x3, #5080]
    7a00:	cb0102c1 	sub	x1, x22, x1
    7a04:	eb00403f 	cmp	x1, x0, lsl #16
    7a08:	54000322 	b.cs	7a6c <f0+0x107c>  // b.hs, b.nlast
    7a0c:	d350fc22 	lsr	x2, x1, #16
    7a10:	f949fc63 	ldr	x3, [x3, #5112]
    7a14:	8b020842 	add	x2, x2, x2, lsl #2
    7a18:	d37df042 	lsl	x2, x2, #3
    7a1c:	8b020060 	add	x0, x3, x2
    7a20:	f9401019 	ldr	x25, [x0, #32]
    7a24:	b4000259 	cbz	x25, 7a6c <f0+0x107c>
    7a28:	38626862 	ldrb	w2, [x3, x2]
    7a2c:	7100085f 	cmp	w2, #0x2
    7a30:	54009660 	b.eq	8cfc <f0+0x230c>  // b.none
    7a34:	7100045f 	cmp	w2, #0x1
    7a38:	540001a1 	b.ne	7a6c <f0+0x107c>  // b.any
    7a3c:	29430002 	ldp	w2, w0, [x0, #24]
    7a40:	92403c21 	and	x1, x1, #0xffff
    7a44:	9b027c21 	mul	x1, x1, x2
    7a48:	d360fc21 	lsr	x1, x1, #32
    7a4c:	eb00003f 	cmp	x1, x0
    7a50:	540000e2 	b.cs	7a6c <f0+0x107c>  // b.hs, b.nlast
    7a54:	8b010339 	add	x25, x25, x1
    7a58:	39400320 	ldrb	w0, [x25]
    7a5c:	7103fc1f 	cmp	w0, #0xff
    7a60:	5400a5c0 	b.eq	8f18 <f0+0x2528>  // b.none
    7a64:	52800020 	mov	w0, #0x1                   	// #1
    7a68:	39000320 	strb	w0, [x25]
    7a6c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7a70:	9113e3e1 	add	x1, sp, #0x4f8
    7a74:	52800020 	mov	w0, #0x1                   	// #1
    7a78:	f9027fe2 	str	x2, [sp, #1272]
    7a7c:	f90283f6 	str	x22, [sp, #1280]
    7a80:	97fff151 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7a84:	91134263 	add	x3, x19, #0x4d0
    7a88:	aa0003f6 	mov	x22, x0
    7a8c:	f949d861 	ldr	x1, [x3, #5040]
    7a90:	f949ec60 	ldr	x0, [x3, #5080]
    7a94:	cb0102c1 	sub	x1, x22, x1
    7a98:	eb00403f 	cmp	x1, x0, lsl #16
    7a9c:	54000322 	b.cs	7b00 <f0+0x1110>  // b.hs, b.nlast
    7aa0:	d350fc22 	lsr	x2, x1, #16
    7aa4:	f949fc63 	ldr	x3, [x3, #5112]
    7aa8:	8b020842 	add	x2, x2, x2, lsl #2
    7aac:	d37df042 	lsl	x2, x2, #3
    7ab0:	8b020060 	add	x0, x3, x2
    7ab4:	f9401019 	ldr	x25, [x0, #32]
    7ab8:	b4000259 	cbz	x25, 7b00 <f0+0x1110>
    7abc:	38626862 	ldrb	w2, [x3, x2]
    7ac0:	7100085f 	cmp	w2, #0x2
    7ac4:	540092e0 	b.eq	8d20 <f0+0x2330>  // b.none
    7ac8:	7100045f 	cmp	w2, #0x1
    7acc:	540001a1 	b.ne	7b00 <f0+0x1110>  // b.any
    7ad0:	29430002 	ldp	w2, w0, [x0, #24]
    7ad4:	92403c21 	and	x1, x1, #0xffff
    7ad8:	9b027c21 	mul	x1, x1, x2
    7adc:	d360fc21 	lsr	x1, x1, #32
    7ae0:	eb00003f 	cmp	x1, x0
    7ae4:	540000e2 	b.cs	7b00 <f0+0x1110>  // b.hs, b.nlast
    7ae8:	8b010339 	add	x25, x25, x1
    7aec:	39400320 	ldrb	w0, [x25]
    7af0:	7103fc1f 	cmp	w0, #0xff
    7af4:	5400a180 	b.eq	8f24 <f0+0x2534>  // b.none
    7af8:	52800020 	mov	w0, #0x1                   	// #1
    7afc:	39000320 	strb	w0, [x25]
    7b00:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7b04:	911423e1 	add	x1, sp, #0x508
    7b08:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7b0c:	52800020 	mov	w0, #0x1                   	// #1
    7b10:	f90287e2 	str	x2, [sp, #1288]
    7b14:	f9028bf6 	str	x22, [sp, #1296]
    7b18:	97fff12b 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7b1c:	91134263 	add	x3, x19, #0x4d0
    7b20:	aa0003f6 	mov	x22, x0
    7b24:	f949d861 	ldr	x1, [x3, #5040]
    7b28:	f949ec60 	ldr	x0, [x3, #5080]
    7b2c:	cb0102c1 	sub	x1, x22, x1
    7b30:	eb00403f 	cmp	x1, x0, lsl #16
    7b34:	54000322 	b.cs	7b98 <f0+0x11a8>  // b.hs, b.nlast
    7b38:	d350fc22 	lsr	x2, x1, #16
    7b3c:	f949fc63 	ldr	x3, [x3, #5112]
    7b40:	8b020842 	add	x2, x2, x2, lsl #2
    7b44:	d37df042 	lsl	x2, x2, #3
    7b48:	8b020060 	add	x0, x3, x2
    7b4c:	f9401019 	ldr	x25, [x0, #32]
    7b50:	b4000259 	cbz	x25, 7b98 <f0+0x11a8>
    7b54:	38626862 	ldrb	w2, [x3, x2]
    7b58:	7100085f 	cmp	w2, #0x2
    7b5c:	54008dc0 	b.eq	8d14 <f0+0x2324>  // b.none
    7b60:	7100045f 	cmp	w2, #0x1
    7b64:	540001a1 	b.ne	7b98 <f0+0x11a8>  // b.any
    7b68:	29430002 	ldp	w2, w0, [x0, #24]
    7b6c:	92403c21 	and	x1, x1, #0xffff
    7b70:	9b027c21 	mul	x1, x1, x2
    7b74:	d360fc21 	lsr	x1, x1, #32
    7b78:	eb00003f 	cmp	x1, x0
    7b7c:	540000e2 	b.cs	7b98 <f0+0x11a8>  // b.hs, b.nlast
    7b80:	8b010339 	add	x25, x25, x1
    7b84:	39400320 	ldrb	w0, [x25]
    7b88:	7103fc1f 	cmp	w0, #0xff
    7b8c:	54009d20 	b.eq	8f30 <f0+0x2540>  // b.none
    7b90:	52800020 	mov	w0, #0x1                   	// #1
    7b94:	39000320 	strb	w0, [x25]
    7b98:	911463e1 	add	x1, sp, #0x518
    7b9c:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    7ba0:	52800020 	mov	w0, #0x1                   	// #1
    7ba4:	f9028ff9 	str	x25, [sp, #1304]
    7ba8:	f90293f6 	str	x22, [sp, #1312]
    7bac:	97fff106 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7bb0:	97ffee74 	bl	3580 <fwp_rc_fresh>
    7bb4:	aa0003e2 	mov	x2, x0
    7bb8:	9114a3e1 	add	x1, sp, #0x528
    7bbc:	b200e7f6 	mov	x22, #0x3333333333333333    	// #3689348814741910323
    7bc0:	f2f7fe76 	movk	x22, #0xbff3, lsl #48
    7bc4:	52800020 	mov	w0, #0x1                   	// #1
    7bc8:	f90297f6 	str	x22, [sp, #1320]
    7bcc:	f9029be2 	str	x2, [sp, #1328]
    7bd0:	97fff0fd 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7bd4:	97ffee6b 	bl	3580 <fwp_rc_fresh>
    7bd8:	aa0003e2 	mov	x2, x0
    7bdc:	9114e3e1 	add	x1, sp, #0x538
    7be0:	52800020 	mov	w0, #0x1                   	// #1
    7be4:	f9029ff9 	str	x25, [sp, #1336]
    7be8:	f902a3e2 	str	x2, [sp, #1344]
    7bec:	97fff0f6 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7bf0:	97ffee64 	bl	3580 <fwp_rc_fresh>
    7bf4:	aa0003e2 	mov	x2, x0
    7bf8:	911523e1 	add	x1, sp, #0x548
    7bfc:	52800020 	mov	w0, #0x1                   	// #1
    7c00:	f902a7f6 	str	x22, [sp, #1352]
    7c04:	f902abe2 	str	x2, [sp, #1360]
    7c08:	97fff0ef 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7c0c:	97ffee5d 	bl	3580 <fwp_rc_fresh>
    7c10:	aa0003e2 	mov	x2, x0
    7c14:	911563e1 	add	x1, sp, #0x558
    7c18:	52800020 	mov	w0, #0x1                   	// #1
    7c1c:	f902aff9 	str	x25, [sp, #1368]
    7c20:	f902b3e2 	str	x2, [sp, #1376]
    7c24:	97fff0e8 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7c28:	97ffee56 	bl	3580 <fwp_rc_fresh>
    7c2c:	aa0003e2 	mov	x2, x0
    7c30:	9115a3e1 	add	x1, sp, #0x568
    7c34:	52800020 	mov	w0, #0x1                   	// #1
    7c38:	f902b7f6 	str	x22, [sp, #1384]
    7c3c:	f902bbe2 	str	x2, [sp, #1392]
    7c40:	97fff0e1 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7c44:	97ffee4f 	bl	3580 <fwp_rc_fresh>
    7c48:	aa0003e2 	mov	x2, x0
    7c4c:	9115e3e1 	add	x1, sp, #0x578
    7c50:	52800020 	mov	w0, #0x1                   	// #1
    7c54:	f902bff9 	str	x25, [sp, #1400]
    7c58:	f902c3e2 	str	x2, [sp, #1408]
    7c5c:	97fff0da 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7c60:	91134263 	add	x3, x19, #0x4d0
    7c64:	aa0003f6 	mov	x22, x0
    7c68:	f949d861 	ldr	x1, [x3, #5040]
    7c6c:	f949ec60 	ldr	x0, [x3, #5080]
    7c70:	cb0102c1 	sub	x1, x22, x1
    7c74:	eb00403f 	cmp	x1, x0, lsl #16
    7c78:	54000322 	b.cs	7cdc <f0+0x12ec>  // b.hs, b.nlast
    7c7c:	d350fc22 	lsr	x2, x1, #16
    7c80:	f949fc63 	ldr	x3, [x3, #5112]
    7c84:	8b020842 	add	x2, x2, x2, lsl #2
    7c88:	d37df042 	lsl	x2, x2, #3
    7c8c:	8b020060 	add	x0, x3, x2
    7c90:	f9401019 	ldr	x25, [x0, #32]
    7c94:	b4000259 	cbz	x25, 7cdc <f0+0x12ec>
    7c98:	38626862 	ldrb	w2, [x3, x2]
    7c9c:	7100085f 	cmp	w2, #0x2
    7ca0:	540084c0 	b.eq	8d38 <f0+0x2348>  // b.none
    7ca4:	7100045f 	cmp	w2, #0x1
    7ca8:	540001a1 	b.ne	7cdc <f0+0x12ec>  // b.any
    7cac:	29430002 	ldp	w2, w0, [x0, #24]
    7cb0:	92403c21 	and	x1, x1, #0xffff
    7cb4:	9b027c21 	mul	x1, x1, x2
    7cb8:	d360fc21 	lsr	x1, x1, #32
    7cbc:	eb00003f 	cmp	x1, x0
    7cc0:	540000e2 	b.cs	7cdc <f0+0x12ec>  // b.hs, b.nlast
    7cc4:	8b010339 	add	x25, x25, x1
    7cc8:	39400320 	ldrb	w0, [x25]
    7ccc:	7103fc1f 	cmp	w0, #0xff
    7cd0:	54009360 	b.eq	8f3c <f0+0x254c>  // b.none
    7cd4:	52800020 	mov	w0, #0x1                   	// #1
    7cd8:	39000320 	strb	w0, [x25]
    7cdc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7ce0:	911623e1 	add	x1, sp, #0x588
    7ce4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7ce8:	52800020 	mov	w0, #0x1                   	// #1
    7cec:	f902c7e2 	str	x2, [sp, #1416]
    7cf0:	f902cbf6 	str	x22, [sp, #1424]
    7cf4:	97fff0b4 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7cf8:	91134263 	add	x3, x19, #0x4d0
    7cfc:	aa0003f6 	mov	x22, x0
    7d00:	f949d861 	ldr	x1, [x3, #5040]
    7d04:	f949ec60 	ldr	x0, [x3, #5080]
    7d08:	cb0102c1 	sub	x1, x22, x1
    7d0c:	eb00403f 	cmp	x1, x0, lsl #16
    7d10:	54000322 	b.cs	7d74 <f0+0x1384>  // b.hs, b.nlast
    7d14:	d350fc22 	lsr	x2, x1, #16
    7d18:	f949fc63 	ldr	x3, [x3, #5112]
    7d1c:	8b020842 	add	x2, x2, x2, lsl #2
    7d20:	d37df042 	lsl	x2, x2, #3
    7d24:	8b020060 	add	x0, x3, x2
    7d28:	f9401019 	ldr	x25, [x0, #32]
    7d2c:	b4000259 	cbz	x25, 7d74 <f0+0x1384>
    7d30:	38626862 	ldrb	w2, [x3, x2]
    7d34:	7100085f 	cmp	w2, #0x2
    7d38:	54007fa0 	b.eq	8d2c <f0+0x233c>  // b.none
    7d3c:	7100045f 	cmp	w2, #0x1
    7d40:	540001a1 	b.ne	7d74 <f0+0x1384>  // b.any
    7d44:	29430002 	ldp	w2, w0, [x0, #24]
    7d48:	92403c21 	and	x1, x1, #0xffff
    7d4c:	9b027c21 	mul	x1, x1, x2
    7d50:	d360fc21 	lsr	x1, x1, #32
    7d54:	eb00003f 	cmp	x1, x0
    7d58:	540000e2 	b.cs	7d74 <f0+0x1384>  // b.hs, b.nlast
    7d5c:	8b010339 	add	x25, x25, x1
    7d60:	39400320 	ldrb	w0, [x25]
    7d64:	7103fc1f 	cmp	w0, #0xff
    7d68:	54008f00 	b.eq	8f48 <f0+0x2558>  // b.none
    7d6c:	52800020 	mov	w0, #0x1                   	// #1
    7d70:	39000320 	strb	w0, [x25]
    7d74:	911663e1 	add	x1, sp, #0x598
    7d78:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7d7c:	52800020 	mov	w0, #0x1                   	// #1
    7d80:	f902cfe2 	str	x2, [sp, #1432]
    7d84:	f902d3f6 	str	x22, [sp, #1440]
    7d88:	97fff08f 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7d8c:	97ffedfd 	bl	3580 <fwp_rc_fresh>
    7d90:	aa0003e2 	mov	x2, x0
    7d94:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7d98:	9116a3e1 	add	x1, sp, #0x5a8
    7d9c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7da0:	52800020 	mov	w0, #0x1                   	// #1
    7da4:	f902d7e3 	str	x3, [sp, #1448]
    7da8:	f902dbe2 	str	x2, [sp, #1456]
    7dac:	97fff086 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7db0:	91134263 	add	x3, x19, #0x4d0
    7db4:	aa0003f6 	mov	x22, x0
    7db8:	f949d861 	ldr	x1, [x3, #5040]
    7dbc:	f949ec60 	ldr	x0, [x3, #5080]
    7dc0:	cb0102c1 	sub	x1, x22, x1
    7dc4:	eb00403f 	cmp	x1, x0, lsl #16
    7dc8:	54000322 	b.cs	7e2c <f0+0x143c>  // b.hs, b.nlast
    7dcc:	d350fc22 	lsr	x2, x1, #16
    7dd0:	f949fc63 	ldr	x3, [x3, #5112]
    7dd4:	8b020842 	add	x2, x2, x2, lsl #2
    7dd8:	d37df042 	lsl	x2, x2, #3
    7ddc:	8b020060 	add	x0, x3, x2
    7de0:	f9401019 	ldr	x25, [x0, #32]
    7de4:	b4000259 	cbz	x25, 7e2c <f0+0x143c>
    7de8:	38626862 	ldrb	w2, [x3, x2]
    7dec:	7100085f 	cmp	w2, #0x2
    7df0:	54008100 	b.eq	8e10 <f0+0x2420>  // b.none
    7df4:	7100045f 	cmp	w2, #0x1
    7df8:	540001a1 	b.ne	7e2c <f0+0x143c>  // b.any
    7dfc:	29430002 	ldp	w2, w0, [x0, #24]
    7e00:	92403c21 	and	x1, x1, #0xffff
    7e04:	9b027c21 	mul	x1, x1, x2
    7e08:	d360fc21 	lsr	x1, x1, #32
    7e0c:	eb00003f 	cmp	x1, x0
    7e10:	540000e2 	b.cs	7e2c <f0+0x143c>  // b.hs, b.nlast
    7e14:	8b010339 	add	x25, x25, x1
    7e18:	39400320 	ldrb	w0, [x25]
    7e1c:	7103fc1f 	cmp	w0, #0xff
    7e20:	540089a0 	b.eq	8f54 <f0+0x2564>  // b.none
    7e24:	52800020 	mov	w0, #0x1                   	// #1
    7e28:	39000320 	strb	w0, [x25]
    7e2c:	9116e3e1 	add	x1, sp, #0x5b8
    7e30:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7e34:	52800020 	mov	w0, #0x1                   	// #1
    7e38:	f902dfe2 	str	x2, [sp, #1464]
    7e3c:	f902e3f6 	str	x22, [sp, #1472]
    7e40:	97fff061 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7e44:	97ffedcf 	bl	3580 <fwp_rc_fresh>
    7e48:	aa0003e2 	mov	x2, x0
    7e4c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7e50:	911723e1 	add	x1, sp, #0x5c8
    7e54:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7e58:	52800020 	mov	w0, #0x1                   	// #1
    7e5c:	f902e7e3 	str	x3, [sp, #1480]
    7e60:	f902ebe2 	str	x2, [sp, #1488]
    7e64:	97fff058 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7e68:	91134263 	add	x3, x19, #0x4d0
    7e6c:	aa0003f6 	mov	x22, x0
    7e70:	f949d861 	ldr	x1, [x3, #5040]
    7e74:	f949ec60 	ldr	x0, [x3, #5080]
    7e78:	cb0102c1 	sub	x1, x22, x1
    7e7c:	eb00403f 	cmp	x1, x0, lsl #16
    7e80:	54000322 	b.cs	7ee4 <f0+0x14f4>  // b.hs, b.nlast
    7e84:	d350fc22 	lsr	x2, x1, #16
    7e88:	f949fc63 	ldr	x3, [x3, #5112]
    7e8c:	8b020842 	add	x2, x2, x2, lsl #2
    7e90:	d37df042 	lsl	x2, x2, #3
    7e94:	8b020060 	add	x0, x3, x2
    7e98:	f9401019 	ldr	x25, [x0, #32]
    7e9c:	b4000259 	cbz	x25, 7ee4 <f0+0x14f4>
    7ea0:	38626862 	ldrb	w2, [x3, x2]
    7ea4:	7100085f 	cmp	w2, #0x2
    7ea8:	54007ae0 	b.eq	8e04 <f0+0x2414>  // b.none
    7eac:	7100045f 	cmp	w2, #0x1
    7eb0:	540001a1 	b.ne	7ee4 <f0+0x14f4>  // b.any
    7eb4:	29430002 	ldp	w2, w0, [x0, #24]
    7eb8:	92403c21 	and	x1, x1, #0xffff
    7ebc:	9b027c21 	mul	x1, x1, x2
    7ec0:	d360fc21 	lsr	x1, x1, #32
    7ec4:	eb00003f 	cmp	x1, x0
    7ec8:	540000e2 	b.cs	7ee4 <f0+0x14f4>  // b.hs, b.nlast
    7ecc:	8b010339 	add	x25, x25, x1
    7ed0:	39400320 	ldrb	w0, [x25]
    7ed4:	7103fc1f 	cmp	w0, #0xff
    7ed8:	54008440 	b.eq	8f60 <f0+0x2570>  // b.none
    7edc:	52800020 	mov	w0, #0x1                   	// #1
    7ee0:	39000320 	strb	w0, [x25]
    7ee4:	911763e1 	add	x1, sp, #0x5d8
    7ee8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7eec:	52800020 	mov	w0, #0x1                   	// #1
    7ef0:	f902efe2 	str	x2, [sp, #1496]
    7ef4:	f902f3f6 	str	x22, [sp, #1504]
    7ef8:	97fff033 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7efc:	97ffeda1 	bl	3580 <fwp_rc_fresh>
    7f00:	aa0003e2 	mov	x2, x0
    7f04:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7f08:	9117a3e1 	add	x1, sp, #0x5e8
    7f0c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7f10:	52800020 	mov	w0, #0x1                   	// #1
    7f14:	f902f7e3 	str	x3, [sp, #1512]
    7f18:	f902fbe2 	str	x2, [sp, #1520]
    7f1c:	97fff02a 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7f20:	91134263 	add	x3, x19, #0x4d0
    7f24:	aa0003f6 	mov	x22, x0
    7f28:	f949d861 	ldr	x1, [x3, #5040]
    7f2c:	f949ec60 	ldr	x0, [x3, #5080]
    7f30:	cb0102c1 	sub	x1, x22, x1
    7f34:	eb00403f 	cmp	x1, x0, lsl #16
    7f38:	54000322 	b.cs	7f9c <f0+0x15ac>  // b.hs, b.nlast
    7f3c:	d350fc22 	lsr	x2, x1, #16
    7f40:	f949fc63 	ldr	x3, [x3, #5112]
    7f44:	8b020842 	add	x2, x2, x2, lsl #2
    7f48:	d37df042 	lsl	x2, x2, #3
    7f4c:	8b020060 	add	x0, x3, x2
    7f50:	f9401019 	ldr	x25, [x0, #32]
    7f54:	b4000259 	cbz	x25, 7f9c <f0+0x15ac>
    7f58:	38626862 	ldrb	w2, [x3, x2]
    7f5c:	7100085f 	cmp	w2, #0x2
    7f60:	54007640 	b.eq	8e28 <f0+0x2438>  // b.none
    7f64:	7100045f 	cmp	w2, #0x1
    7f68:	540001a1 	b.ne	7f9c <f0+0x15ac>  // b.any
    7f6c:	29430002 	ldp	w2, w0, [x0, #24]
    7f70:	92403c21 	and	x1, x1, #0xffff
    7f74:	9b027c21 	mul	x1, x1, x2
    7f78:	d360fc21 	lsr	x1, x1, #32
    7f7c:	eb00003f 	cmp	x1, x0
    7f80:	540000e2 	b.cs	7f9c <f0+0x15ac>  // b.hs, b.nlast
    7f84:	8b010339 	add	x25, x25, x1
    7f88:	39400320 	ldrb	w0, [x25]
    7f8c:	7103fc1f 	cmp	w0, #0xff
    7f90:	54007ee0 	b.eq	8f6c <f0+0x257c>  // b.none
    7f94:	52800020 	mov	w0, #0x1                   	// #1
    7f98:	39000320 	strb	w0, [x25]
    7f9c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7fa0:	9117e3e1 	add	x1, sp, #0x5f8
    7fa4:	52800020 	mov	w0, #0x1                   	// #1
    7fa8:	f902ffe2 	str	x2, [sp, #1528]
    7fac:	f90303f6 	str	x22, [sp, #1536]
    7fb0:	97fff005 	bl	3fc4 <fwp_data.part.0.constprop.0>
    7fb4:	91134263 	add	x3, x19, #0x4d0
    7fb8:	aa0003f6 	mov	x22, x0
    7fbc:	f949d861 	ldr	x1, [x3, #5040]
    7fc0:	f949ec60 	ldr	x0, [x3, #5080]
    7fc4:	cb0102c1 	sub	x1, x22, x1
    7fc8:	eb00403f 	cmp	x1, x0, lsl #16
    7fcc:	54000322 	b.cs	8030 <f0+0x1640>  // b.hs, b.nlast
    7fd0:	d350fc22 	lsr	x2, x1, #16
    7fd4:	f949fc63 	ldr	x3, [x3, #5112]
    7fd8:	8b020842 	add	x2, x2, x2, lsl #2
    7fdc:	d37df042 	lsl	x2, x2, #3
    7fe0:	8b020060 	add	x0, x3, x2
    7fe4:	f9401019 	ldr	x25, [x0, #32]
    7fe8:	b4000259 	cbz	x25, 8030 <f0+0x1640>
    7fec:	38626862 	ldrb	w2, [x3, x2]
    7ff0:	7100085f 	cmp	w2, #0x2
    7ff4:	54007140 	b.eq	8e1c <f0+0x242c>  // b.none
    7ff8:	7100045f 	cmp	w2, #0x1
    7ffc:	540001a1 	b.ne	8030 <f0+0x1640>  // b.any
    8000:	29430002 	ldp	w2, w0, [x0, #24]
    8004:	92403c21 	and	x1, x1, #0xffff
    8008:	9b027c21 	mul	x1, x1, x2
    800c:	d360fc21 	lsr	x1, x1, #32
    8010:	eb00003f 	cmp	x1, x0
    8014:	540000e2 	b.cs	8030 <f0+0x1640>  // b.hs, b.nlast
    8018:	8b010339 	add	x25, x25, x1
    801c:	39400320 	ldrb	w0, [x25]
    8020:	7103fc1f 	cmp	w0, #0xff
    8024:	54007aa0 	b.eq	8f78 <f0+0x2588>  // b.none
    8028:	52800020 	mov	w0, #0x1                   	// #1
    802c:	39000320 	strb	w0, [x25]
    8030:	911823e1 	add	x1, sp, #0x608
    8034:	b200e7f9 	mov	x25, #0x3333333333333333    	// #3689348814741910323
    8038:	f2f7fe79 	movk	x25, #0xbff3, lsl #48
    803c:	52800020 	mov	w0, #0x1                   	// #1
    8040:	f90307f9 	str	x25, [sp, #1544]
    8044:	f9030bf6 	str	x22, [sp, #1552]
    8048:	97ffefdf 	bl	3fc4 <fwp_data.part.0.constprop.0>
    804c:	97ffed4d 	bl	3580 <fwp_rc_fresh>
    8050:	aa0003e2 	mov	x2, x0
    8054:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    8058:	911863e1 	add	x1, sp, #0x618
    805c:	52800020 	mov	w0, #0x1                   	// #1
    8060:	f9030fe3 	str	x3, [sp, #1560]
    8064:	f90313e2 	str	x2, [sp, #1568]
    8068:	97ffefd7 	bl	3fc4 <fwp_data.part.0.constprop.0>
    806c:	97ffed45 	bl	3580 <fwp_rc_fresh>
    8070:	aa0003e2 	mov	x2, x0
    8074:	9118a3e1 	add	x1, sp, #0x628
    8078:	52800020 	mov	w0, #0x1                   	// #1
    807c:	f90317f9 	str	x25, [sp, #1576]
    8080:	f9031be2 	str	x2, [sp, #1584]
    8084:	97ffefd0 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8088:	91134263 	add	x3, x19, #0x4d0
    808c:	aa0003f6 	mov	x22, x0
    8090:	f949d861 	ldr	x1, [x3, #5040]
    8094:	f949ec60 	ldr	x0, [x3, #5080]
    8098:	cb0102c1 	sub	x1, x22, x1
    809c:	eb00403f 	cmp	x1, x0, lsl #16
    80a0:	54000322 	b.cs	8104 <f0+0x1714>  // b.hs, b.nlast
    80a4:	d350fc22 	lsr	x2, x1, #16
    80a8:	f949fc63 	ldr	x3, [x3, #5112]
    80ac:	8b020842 	add	x2, x2, x2, lsl #2
    80b0:	d37df042 	lsl	x2, x2, #3
    80b4:	8b020060 	add	x0, x3, x2
    80b8:	f9401019 	ldr	x25, [x0, #32]
    80bc:	b4000259 	cbz	x25, 8104 <f0+0x1714>
    80c0:	38626862 	ldrb	w2, [x3, x2]
    80c4:	7100085f 	cmp	w2, #0x2
    80c8:	54006bc0 	b.eq	8e40 <f0+0x2450>  // b.none
    80cc:	7100045f 	cmp	w2, #0x1
    80d0:	540001a1 	b.ne	8104 <f0+0x1714>  // b.any
    80d4:	29430002 	ldp	w2, w0, [x0, #24]
    80d8:	92403c21 	and	x1, x1, #0xffff
    80dc:	9b027c21 	mul	x1, x1, x2
    80e0:	d360fc21 	lsr	x1, x1, #32
    80e4:	eb00003f 	cmp	x1, x0
    80e8:	540000e2 	b.cs	8104 <f0+0x1714>  // b.hs, b.nlast
    80ec:	8b010339 	add	x25, x25, x1
    80f0:	39400320 	ldrb	w0, [x25]
    80f4:	7103fc1f 	cmp	w0, #0xff
    80f8:	54007460 	b.eq	8f84 <f0+0x2594>  // b.none
    80fc:	52800020 	mov	w0, #0x1                   	// #1
    8100:	39000320 	strb	w0, [x25]
    8104:	9118e3e1 	add	x1, sp, #0x638
    8108:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    810c:	52800020 	mov	w0, #0x1                   	// #1
    8110:	f9031ff9 	str	x25, [sp, #1592]
    8114:	f90323f6 	str	x22, [sp, #1600]
    8118:	97ffefab 	bl	3fc4 <fwp_data.part.0.constprop.0>
    811c:	97ffed19 	bl	3580 <fwp_rc_fresh>
    8120:	aa0003e2 	mov	x2, x0
    8124:	911923e1 	add	x1, sp, #0x648
    8128:	b200e7f6 	mov	x22, #0x3333333333333333    	// #3689348814741910323
    812c:	f2f7fe76 	movk	x22, #0xbff3, lsl #48
    8130:	52800020 	mov	w0, #0x1                   	// #1
    8134:	f90327f6 	str	x22, [sp, #1608]
    8138:	f9032be2 	str	x2, [sp, #1616]
    813c:	97ffefa2 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8140:	97ffed10 	bl	3580 <fwp_rc_fresh>
    8144:	aa0003e2 	mov	x2, x0
    8148:	911963e1 	add	x1, sp, #0x658
    814c:	52800020 	mov	w0, #0x1                   	// #1
    8150:	f9032ff9 	str	x25, [sp, #1624]
    8154:	f90333e2 	str	x2, [sp, #1632]
    8158:	97ffef9b 	bl	3fc4 <fwp_data.part.0.constprop.0>
    815c:	97ffed09 	bl	3580 <fwp_rc_fresh>
    8160:	aa0003e2 	mov	x2, x0
    8164:	9119a3e1 	add	x1, sp, #0x668
    8168:	52800020 	mov	w0, #0x1                   	// #1
    816c:	f90337f6 	str	x22, [sp, #1640]
    8170:	f9033be2 	str	x2, [sp, #1648]
    8174:	97ffef94 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8178:	97ffed02 	bl	3580 <fwp_rc_fresh>
    817c:	aa0003e2 	mov	x2, x0
    8180:	9119e3e1 	add	x1, sp, #0x678
    8184:	52800020 	mov	w0, #0x1                   	// #1
    8188:	f9033ff9 	str	x25, [sp, #1656]
    818c:	f90343e2 	str	x2, [sp, #1664]
    8190:	97ffef8d 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8194:	91134263 	add	x3, x19, #0x4d0
    8198:	aa0003f6 	mov	x22, x0
    819c:	f949d861 	ldr	x1, [x3, #5040]
    81a0:	f949ec60 	ldr	x0, [x3, #5080]
    81a4:	cb0102c1 	sub	x1, x22, x1
    81a8:	eb00403f 	cmp	x1, x0, lsl #16
    81ac:	54000322 	b.cs	8210 <f0+0x1820>  // b.hs, b.nlast
    81b0:	d350fc22 	lsr	x2, x1, #16
    81b4:	f949fc63 	ldr	x3, [x3, #5112]
    81b8:	8b020842 	add	x2, x2, x2, lsl #2
    81bc:	d37df042 	lsl	x2, x2, #3
    81c0:	8b020060 	add	x0, x3, x2
    81c4:	f9401019 	ldr	x25, [x0, #32]
    81c8:	b4000259 	cbz	x25, 8210 <f0+0x1820>
    81cc:	38626862 	ldrb	w2, [x3, x2]
    81d0:	7100085f 	cmp	w2, #0x2
    81d4:	54006300 	b.eq	8e34 <f0+0x2444>  // b.none
    81d8:	7100045f 	cmp	w2, #0x1
    81dc:	540001a1 	b.ne	8210 <f0+0x1820>  // b.any
    81e0:	29430002 	ldp	w2, w0, [x0, #24]
    81e4:	92403c21 	and	x1, x1, #0xffff
    81e8:	9b027c21 	mul	x1, x1, x2
    81ec:	d360fc21 	lsr	x1, x1, #32
    81f0:	eb00003f 	cmp	x1, x0
    81f4:	540000e2 	b.cs	8210 <f0+0x1820>  // b.hs, b.nlast
    81f8:	8b010339 	add	x25, x25, x1
    81fc:	39400320 	ldrb	w0, [x25]
    8200:	7103fc1f 	cmp	w0, #0xff
    8204:	54006c60 	b.eq	8f90 <f0+0x25a0>  // b.none
    8208:	52800020 	mov	w0, #0x1                   	// #1
    820c:	39000320 	strb	w0, [x25]
    8210:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8214:	911a23e1 	add	x1, sp, #0x688
    8218:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    821c:	52800020 	mov	w0, #0x1                   	// #1
    8220:	f90347e2 	str	x2, [sp, #1672]
    8224:	f9034bf6 	str	x22, [sp, #1680]
    8228:	97ffef67 	bl	3fc4 <fwp_data.part.0.constprop.0>
    822c:	91134263 	add	x3, x19, #0x4d0
    8230:	aa0003f6 	mov	x22, x0
    8234:	f949d861 	ldr	x1, [x3, #5040]
    8238:	f949ec60 	ldr	x0, [x3, #5080]
    823c:	cb0102c1 	sub	x1, x22, x1
    8240:	eb00403f 	cmp	x1, x0, lsl #16
    8244:	54000322 	b.cs	82a8 <f0+0x18b8>  // b.hs, b.nlast
    8248:	d350fc22 	lsr	x2, x1, #16
    824c:	f949fc63 	ldr	x3, [x3, #5112]
    8250:	8b020842 	add	x2, x2, x2, lsl #2
    8254:	d37df042 	lsl	x2, x2, #3
    8258:	8b020060 	add	x0, x3, x2
    825c:	f9401019 	ldr	x25, [x0, #32]
    8260:	b4000259 	cbz	x25, 82a8 <f0+0x18b8>
    8264:	38626862 	ldrb	w2, [x3, x2]
    8268:	7100085f 	cmp	w2, #0x2
    826c:	54005f60 	b.eq	8e58 <f0+0x2468>  // b.none
    8270:	7100045f 	cmp	w2, #0x1
    8274:	540001a1 	b.ne	82a8 <f0+0x18b8>  // b.any
    8278:	29430002 	ldp	w2, w0, [x0, #24]
    827c:	92403c21 	and	x1, x1, #0xffff
    8280:	9b027c21 	mul	x1, x1, x2
    8284:	d360fc21 	lsr	x1, x1, #32
    8288:	eb00003f 	cmp	x1, x0
    828c:	540000e2 	b.cs	82a8 <f0+0x18b8>  // b.hs, b.nlast
    8290:	8b010339 	add	x25, x25, x1
    8294:	39400320 	ldrb	w0, [x25]
    8298:	7103fc1f 	cmp	w0, #0xff
    829c:	54006800 	b.eq	8f9c <f0+0x25ac>  // b.none
    82a0:	52800020 	mov	w0, #0x1                   	// #1
    82a4:	39000320 	strb	w0, [x25]
    82a8:	911a63e1 	add	x1, sp, #0x698
    82ac:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    82b0:	52800020 	mov	w0, #0x1                   	// #1
    82b4:	f9034fe2 	str	x2, [sp, #1688]
    82b8:	f90353f6 	str	x22, [sp, #1696]
    82bc:	97ffef42 	bl	3fc4 <fwp_data.part.0.constprop.0>
    82c0:	97ffecb0 	bl	3580 <fwp_rc_fresh>
    82c4:	aa0003e2 	mov	x2, x0
    82c8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    82cc:	911aa3e1 	add	x1, sp, #0x6a8
    82d0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    82d4:	52800020 	mov	w0, #0x1                   	// #1
    82d8:	f90357e3 	str	x3, [sp, #1704]
    82dc:	f9035be2 	str	x2, [sp, #1712]
    82e0:	97ffef39 	bl	3fc4 <fwp_data.part.0.constprop.0>
    82e4:	91134263 	add	x3, x19, #0x4d0
    82e8:	aa0003f6 	mov	x22, x0
    82ec:	f949d861 	ldr	x1, [x3, #5040]
    82f0:	f949ec60 	ldr	x0, [x3, #5080]
    82f4:	cb0102c1 	sub	x1, x22, x1
    82f8:	eb00403f 	cmp	x1, x0, lsl #16
    82fc:	54000322 	b.cs	8360 <f0+0x1970>  // b.hs, b.nlast
    8300:	d350fc22 	lsr	x2, x1, #16
    8304:	f949fc63 	ldr	x3, [x3, #5112]
    8308:	8b020842 	add	x2, x2, x2, lsl #2
    830c:	d37df042 	lsl	x2, x2, #3
    8310:	8b020060 	add	x0, x3, x2
    8314:	f9401019 	ldr	x25, [x0, #32]
    8318:	b4000259 	cbz	x25, 8360 <f0+0x1970>
    831c:	38626862 	ldrb	w2, [x3, x2]
    8320:	7100085f 	cmp	w2, #0x2
    8324:	54005940 	b.eq	8e4c <f0+0x245c>  // b.none
    8328:	7100045f 	cmp	w2, #0x1
    832c:	540001a1 	b.ne	8360 <f0+0x1970>  // b.any
    8330:	29430002 	ldp	w2, w0, [x0, #24]
    8334:	92403c21 	and	x1, x1, #0xffff
    8338:	9b027c21 	mul	x1, x1, x2
    833c:	d360fc21 	lsr	x1, x1, #32
    8340:	eb00003f 	cmp	x1, x0
    8344:	540000e2 	b.cs	8360 <f0+0x1970>  // b.hs, b.nlast
    8348:	8b010339 	add	x25, x25, x1
    834c:	39400320 	ldrb	w0, [x25]
    8350:	7103fc1f 	cmp	w0, #0xff
    8354:	540062a0 	b.eq	8fa8 <f0+0x25b8>  // b.none
    8358:	52800020 	mov	w0, #0x1                   	// #1
    835c:	39000320 	strb	w0, [x25]
    8360:	911ae3e1 	add	x1, sp, #0x6b8
    8364:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8368:	52800020 	mov	w0, #0x1                   	// #1
    836c:	f9035fe2 	str	x2, [sp, #1720]
    8370:	f90363f6 	str	x22, [sp, #1728]
    8374:	97ffef14 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8378:	97ffec82 	bl	3580 <fwp_rc_fresh>
    837c:	aa0003e2 	mov	x2, x0
    8380:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8384:	911b23e1 	add	x1, sp, #0x6c8
    8388:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    838c:	52800020 	mov	w0, #0x1                   	// #1
    8390:	f90367e3 	str	x3, [sp, #1736]
    8394:	f9036be2 	str	x2, [sp, #1744]
    8398:	97ffef0b 	bl	3fc4 <fwp_data.part.0.constprop.0>
    839c:	91134263 	add	x3, x19, #0x4d0
    83a0:	aa0003f6 	mov	x22, x0
    83a4:	f949d861 	ldr	x1, [x3, #5040]
    83a8:	f949ec60 	ldr	x0, [x3, #5080]
    83ac:	cb0102c1 	sub	x1, x22, x1
    83b0:	eb00403f 	cmp	x1, x0, lsl #16
    83b4:	54000322 	b.cs	8418 <f0+0x1a28>  // b.hs, b.nlast
    83b8:	d350fc22 	lsr	x2, x1, #16
    83bc:	f949fc63 	ldr	x3, [x3, #5112]
    83c0:	8b020842 	add	x2, x2, x2, lsl #2
    83c4:	d37df042 	lsl	x2, x2, #3
    83c8:	8b020060 	add	x0, x3, x2
    83cc:	f9401019 	ldr	x25, [x0, #32]
    83d0:	b4000259 	cbz	x25, 8418 <f0+0x1a28>
    83d4:	38626862 	ldrb	w2, [x3, x2]
    83d8:	7100085f 	cmp	w2, #0x2
    83dc:	54004ea0 	b.eq	8db0 <f0+0x23c0>  // b.none
    83e0:	7100045f 	cmp	w2, #0x1
    83e4:	540001a1 	b.ne	8418 <f0+0x1a28>  // b.any
    83e8:	29430002 	ldp	w2, w0, [x0, #24]
    83ec:	92403c21 	and	x1, x1, #0xffff
    83f0:	9b027c21 	mul	x1, x1, x2
    83f4:	d360fc21 	lsr	x1, x1, #32
    83f8:	eb00003f 	cmp	x1, x0
    83fc:	540000e2 	b.cs	8418 <f0+0x1a28>  // b.hs, b.nlast
    8400:	8b010339 	add	x25, x25, x1
    8404:	39400320 	ldrb	w0, [x25]
    8408:	7103fc1f 	cmp	w0, #0xff
    840c:	54005d40 	b.eq	8fb4 <f0+0x25c4>  // b.none
    8410:	52800020 	mov	w0, #0x1                   	// #1
    8414:	39000320 	strb	w0, [x25]
    8418:	911b63e1 	add	x1, sp, #0x6d8
    841c:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    8420:	52800020 	mov	w0, #0x1                   	// #1
    8424:	f9036ff9 	str	x25, [sp, #1752]
    8428:	f90373f6 	str	x22, [sp, #1760]
    842c:	97ffeee6 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8430:	97ffec54 	bl	3580 <fwp_rc_fresh>
    8434:	aa0003e2 	mov	x2, x0
    8438:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    843c:	911ba3e1 	add	x1, sp, #0x6e8
    8440:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8444:	52800020 	mov	w0, #0x1                   	// #1
    8448:	f90377e3 	str	x3, [sp, #1768]
    844c:	f9037be2 	str	x2, [sp, #1776]
    8450:	97ffeedd 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8454:	97ffec4b 	bl	3580 <fwp_rc_fresh>
    8458:	aa0003e2 	mov	x2, x0
    845c:	911be3e1 	add	x1, sp, #0x6f8
    8460:	52800020 	mov	w0, #0x1                   	// #1
    8464:	f9037ff9 	str	x25, [sp, #1784]
    8468:	f90383e2 	str	x2, [sp, #1792]
    846c:	97ffeed6 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8470:	91134263 	add	x3, x19, #0x4d0
    8474:	aa0003f6 	mov	x22, x0
    8478:	f949d861 	ldr	x1, [x3, #5040]
    847c:	f949ec60 	ldr	x0, [x3, #5080]
    8480:	cb0102c1 	sub	x1, x22, x1
    8484:	eb00403f 	cmp	x1, x0, lsl #16
    8488:	54000322 	b.cs	84ec <f0+0x1afc>  // b.hs, b.nlast
    848c:	d350fc22 	lsr	x2, x1, #16
    8490:	f949fc63 	ldr	x3, [x3, #5112]
    8494:	8b020842 	add	x2, x2, x2, lsl #2
    8498:	d37df042 	lsl	x2, x2, #3
    849c:	8b020060 	add	x0, x3, x2
    84a0:	f9401019 	ldr	x25, [x0, #32]
    84a4:	b4000259 	cbz	x25, 84ec <f0+0x1afc>
    84a8:	38626862 	ldrb	w2, [x3, x2]
    84ac:	7100085f 	cmp	w2, #0x2
    84b0:	540047a0 	b.eq	8da4 <f0+0x23b4>  // b.none
    84b4:	7100045f 	cmp	w2, #0x1
    84b8:	540001a1 	b.ne	84ec <f0+0x1afc>  // b.any
    84bc:	29430002 	ldp	w2, w0, [x0, #24]
    84c0:	92403c21 	and	x1, x1, #0xffff
    84c4:	9b027c21 	mul	x1, x1, x2
    84c8:	d360fc21 	lsr	x1, x1, #32
    84cc:	eb00003f 	cmp	x1, x0
    84d0:	540000e2 	b.cs	84ec <f0+0x1afc>  // b.hs, b.nlast
    84d4:	8b010339 	add	x25, x25, x1
    84d8:	39400320 	ldrb	w0, [x25]
    84dc:	7103fc1f 	cmp	w0, #0xff
    84e0:	54005700 	b.eq	8fc0 <f0+0x25d0>  // b.none
    84e4:	52800020 	mov	w0, #0x1                   	// #1
    84e8:	39000320 	strb	w0, [x25]
    84ec:	911c23e1 	add	x1, sp, #0x708
    84f0:	b200e7f9 	mov	x25, #0x3333333333333333    	// #3689348814741910323
    84f4:	f2f7fe79 	movk	x25, #0xbff3, lsl #48
    84f8:	52800020 	mov	w0, #0x1                   	// #1
    84fc:	f90387f9 	str	x25, [sp, #1800]
    8500:	f9038bf6 	str	x22, [sp, #1808]
    8504:	97ffeeb0 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8508:	97ffec1e 	bl	3580 <fwp_rc_fresh>
    850c:	aa0003e2 	mov	x2, x0
    8510:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    8514:	911c63e1 	add	x1, sp, #0x718
    8518:	52800020 	mov	w0, #0x1                   	// #1
    851c:	f9038fe3 	str	x3, [sp, #1816]
    8520:	f90393e2 	str	x2, [sp, #1824]
    8524:	97ffeea8 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8528:	97ffec16 	bl	3580 <fwp_rc_fresh>
    852c:	aa0003e2 	mov	x2, x0
    8530:	911ca3e1 	add	x1, sp, #0x728
    8534:	52800020 	mov	w0, #0x1                   	// #1
    8538:	f90397f9 	str	x25, [sp, #1832]
    853c:	f9039be2 	str	x2, [sp, #1840]
    8540:	97ffeea1 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8544:	91134263 	add	x3, x19, #0x4d0
    8548:	aa0003f6 	mov	x22, x0
    854c:	f949d861 	ldr	x1, [x3, #5040]
    8550:	f949ec60 	ldr	x0, [x3, #5080]
    8554:	cb0102c1 	sub	x1, x22, x1
    8558:	eb00403f 	cmp	x1, x0, lsl #16
    855c:	54000322 	b.cs	85c0 <f0+0x1bd0>  // b.hs, b.nlast
    8560:	d350fc22 	lsr	x2, x1, #16
    8564:	f949fc63 	ldr	x3, [x3, #5112]
    8568:	8b020842 	add	x2, x2, x2, lsl #2
    856c:	d37df042 	lsl	x2, x2, #3
    8570:	8b020060 	add	x0, x3, x2
    8574:	f9401019 	ldr	x25, [x0, #32]
    8578:	b4000259 	cbz	x25, 85c0 <f0+0x1bd0>
    857c:	38626862 	ldrb	w2, [x3, x2]
    8580:	7100085f 	cmp	w2, #0x2
    8584:	54004220 	b.eq	8dc8 <f0+0x23d8>  // b.none
    8588:	7100045f 	cmp	w2, #0x1
    858c:	540001a1 	b.ne	85c0 <f0+0x1bd0>  // b.any
    8590:	29430002 	ldp	w2, w0, [x0, #24]
    8594:	92403c21 	and	x1, x1, #0xffff
    8598:	9b027c21 	mul	x1, x1, x2
    859c:	d360fc21 	lsr	x1, x1, #32
    85a0:	eb00003f 	cmp	x1, x0
    85a4:	540000e2 	b.cs	85c0 <f0+0x1bd0>  // b.hs, b.nlast
    85a8:	8b010339 	add	x25, x25, x1
    85ac:	39400320 	ldrb	w0, [x25]
    85b0:	7103fc1f 	cmp	w0, #0xff
    85b4:	540050c0 	b.eq	8fcc <f0+0x25dc>  // b.none
    85b8:	52800020 	mov	w0, #0x1                   	// #1
    85bc:	39000320 	strb	w0, [x25]
    85c0:	911ce3e1 	add	x1, sp, #0x738
    85c4:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    85c8:	52800020 	mov	w0, #0x1                   	// #1
    85cc:	f9039ff9 	str	x25, [sp, #1848]
    85d0:	f903a3f6 	str	x22, [sp, #1856]
    85d4:	97ffee7c 	bl	3fc4 <fwp_data.part.0.constprop.0>
    85d8:	97ffebea 	bl	3580 <fwp_rc_fresh>
    85dc:	aa0003e2 	mov	x2, x0
    85e0:	911d23e1 	add	x1, sp, #0x748
    85e4:	b200e7f6 	mov	x22, #0x3333333333333333    	// #3689348814741910323
    85e8:	f2f7fe76 	movk	x22, #0xbff3, lsl #48
    85ec:	52800020 	mov	w0, #0x1                   	// #1
    85f0:	f903a7f6 	str	x22, [sp, #1864]
    85f4:	f903abe2 	str	x2, [sp, #1872]
    85f8:	97ffee73 	bl	3fc4 <fwp_data.part.0.constprop.0>
    85fc:	97ffebe1 	bl	3580 <fwp_rc_fresh>
    8600:	aa0003e2 	mov	x2, x0
    8604:	911d63e1 	add	x1, sp, #0x758
    8608:	52800020 	mov	w0, #0x1                   	// #1
    860c:	f903aff9 	str	x25, [sp, #1880]
    8610:	f903b3e2 	str	x2, [sp, #1888]
    8614:	97ffee6c 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8618:	97ffebda 	bl	3580 <fwp_rc_fresh>
    861c:	aa0003e2 	mov	x2, x0
    8620:	911da3e1 	add	x1, sp, #0x768
    8624:	52800020 	mov	w0, #0x1                   	// #1
    8628:	f903b7f6 	str	x22, [sp, #1896]
    862c:	f903bbe2 	str	x2, [sp, #1904]
    8630:	97ffee65 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8634:	97ffebd3 	bl	3580 <fwp_rc_fresh>
    8638:	aa0003e2 	mov	x2, x0
    863c:	911de3e1 	add	x1, sp, #0x778
    8640:	52800020 	mov	w0, #0x1                   	// #1
    8644:	f903bff9 	str	x25, [sp, #1912]
    8648:	f903c3e2 	str	x2, [sp, #1920]
    864c:	97ffee5e 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8650:	91134263 	add	x3, x19, #0x4d0
    8654:	aa0003f6 	mov	x22, x0
    8658:	f949d861 	ldr	x1, [x3, #5040]
    865c:	f949ec60 	ldr	x0, [x3, #5080]
    8660:	cb0102c1 	sub	x1, x22, x1
    8664:	eb00403f 	cmp	x1, x0, lsl #16
    8668:	54000322 	b.cs	86cc <f0+0x1cdc>  // b.hs, b.nlast
    866c:	d350fc22 	lsr	x2, x1, #16
    8670:	f949fc63 	ldr	x3, [x3, #5112]
    8674:	8b020842 	add	x2, x2, x2, lsl #2
    8678:	d37df042 	lsl	x2, x2, #3
    867c:	8b020060 	add	x0, x3, x2
    8680:	f9401019 	ldr	x25, [x0, #32]
    8684:	b4000259 	cbz	x25, 86cc <f0+0x1cdc>
    8688:	38626862 	ldrb	w2, [x3, x2]
    868c:	7100085f 	cmp	w2, #0x2
    8690:	54003960 	b.eq	8dbc <f0+0x23cc>  // b.none
    8694:	7100045f 	cmp	w2, #0x1
    8698:	540001a1 	b.ne	86cc <f0+0x1cdc>  // b.any
    869c:	29430002 	ldp	w2, w0, [x0, #24]
    86a0:	92403c21 	and	x1, x1, #0xffff
    86a4:	9b027c21 	mul	x1, x1, x2
    86a8:	d360fc21 	lsr	x1, x1, #32
    86ac:	eb00003f 	cmp	x1, x0
    86b0:	540000e2 	b.cs	86cc <f0+0x1cdc>  // b.hs, b.nlast
    86b4:	8b010339 	add	x25, x25, x1
    86b8:	39400320 	ldrb	w0, [x25]
    86bc:	7103fc1f 	cmp	w0, #0xff
    86c0:	540048c0 	b.eq	8fd8 <f0+0x25e8>  // b.none
    86c4:	52800020 	mov	w0, #0x1                   	// #1
    86c8:	39000320 	strb	w0, [x25]
    86cc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    86d0:	911e23e1 	add	x1, sp, #0x788
    86d4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    86d8:	52800020 	mov	w0, #0x1                   	// #1
    86dc:	f903c7e2 	str	x2, [sp, #1928]
    86e0:	f903cbf6 	str	x22, [sp, #1936]
    86e4:	97ffee38 	bl	3fc4 <fwp_data.part.0.constprop.0>
    86e8:	91134263 	add	x3, x19, #0x4d0
    86ec:	aa0003f6 	mov	x22, x0
    86f0:	f949d861 	ldr	x1, [x3, #5040]
    86f4:	f949ec60 	ldr	x0, [x3, #5080]
    86f8:	cb0102c1 	sub	x1, x22, x1
    86fc:	eb00403f 	cmp	x1, x0, lsl #16
    8700:	54000322 	b.cs	8764 <f0+0x1d74>  // b.hs, b.nlast
    8704:	d350fc22 	lsr	x2, x1, #16
    8708:	f949fc63 	ldr	x3, [x3, #5112]
    870c:	8b020842 	add	x2, x2, x2, lsl #2
    8710:	d37df042 	lsl	x2, x2, #3
    8714:	8b020060 	add	x0, x3, x2
    8718:	f9401019 	ldr	x25, [x0, #32]
    871c:	b4000259 	cbz	x25, 8764 <f0+0x1d74>
    8720:	38626862 	ldrb	w2, [x3, x2]
    8724:	7100085f 	cmp	w2, #0x2
    8728:	540035c0 	b.eq	8de0 <f0+0x23f0>  // b.none
    872c:	7100045f 	cmp	w2, #0x1
    8730:	540001a1 	b.ne	8764 <f0+0x1d74>  // b.any
    8734:	29430002 	ldp	w2, w0, [x0, #24]
    8738:	92403c21 	and	x1, x1, #0xffff
    873c:	9b027c21 	mul	x1, x1, x2
    8740:	d360fc21 	lsr	x1, x1, #32
    8744:	eb00003f 	cmp	x1, x0
    8748:	540000e2 	b.cs	8764 <f0+0x1d74>  // b.hs, b.nlast
    874c:	8b010339 	add	x25, x25, x1
    8750:	39400320 	ldrb	w0, [x25]
    8754:	7103fc1f 	cmp	w0, #0xff
    8758:	54004460 	b.eq	8fe4 <f0+0x25f4>  // b.none
    875c:	52800020 	mov	w0, #0x1                   	// #1
    8760:	39000320 	strb	w0, [x25]
    8764:	911e63e1 	add	x1, sp, #0x798
    8768:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    876c:	52800020 	mov	w0, #0x1                   	// #1
    8770:	f903cfe2 	str	x2, [sp, #1944]
    8774:	f903d3f6 	str	x22, [sp, #1952]
    8778:	97ffee13 	bl	3fc4 <fwp_data.part.0.constprop.0>
    877c:	97ffeb81 	bl	3580 <fwp_rc_fresh>
    8780:	aa0003e2 	mov	x2, x0
    8784:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8788:	911ea3e1 	add	x1, sp, #0x7a8
    878c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8790:	52800020 	mov	w0, #0x1                   	// #1
    8794:	f903d7e3 	str	x3, [sp, #1960]
    8798:	f903dbe2 	str	x2, [sp, #1968]
    879c:	97ffee0a 	bl	3fc4 <fwp_data.part.0.constprop.0>
    87a0:	91134263 	add	x3, x19, #0x4d0
    87a4:	aa0003f6 	mov	x22, x0
    87a8:	f949d861 	ldr	x1, [x3, #5040]
    87ac:	f949ec60 	ldr	x0, [x3, #5080]
    87b0:	cb0102c1 	sub	x1, x22, x1
    87b4:	eb00403f 	cmp	x1, x0, lsl #16
    87b8:	54000322 	b.cs	881c <f0+0x1e2c>  // b.hs, b.nlast
    87bc:	d350fc22 	lsr	x2, x1, #16
    87c0:	f949fc63 	ldr	x3, [x3, #5112]
    87c4:	8b020842 	add	x2, x2, x2, lsl #2
    87c8:	d37df042 	lsl	x2, x2, #3
    87cc:	8b020060 	add	x0, x3, x2
    87d0:	f9401019 	ldr	x25, [x0, #32]
    87d4:	b4000259 	cbz	x25, 881c <f0+0x1e2c>
    87d8:	38626862 	ldrb	w2, [x3, x2]
    87dc:	7100085f 	cmp	w2, #0x2
    87e0:	54002fa0 	b.eq	8dd4 <f0+0x23e4>  // b.none
    87e4:	7100045f 	cmp	w2, #0x1
    87e8:	540001a1 	b.ne	881c <f0+0x1e2c>  // b.any
    87ec:	29430002 	ldp	w2, w0, [x0, #24]
    87f0:	92403c21 	and	x1, x1, #0xffff
    87f4:	9b027c21 	mul	x1, x1, x2
    87f8:	d360fc21 	lsr	x1, x1, #32
    87fc:	eb00003f 	cmp	x1, x0
    8800:	540000e2 	b.cs	881c <f0+0x1e2c>  // b.hs, b.nlast
    8804:	8b010339 	add	x25, x25, x1
    8808:	39400320 	ldrb	w0, [x25]
    880c:	7103fc1f 	cmp	w0, #0xff
    8810:	54003f00 	b.eq	8ff0 <f0+0x2600>  // b.none
    8814:	52800020 	mov	w0, #0x1                   	// #1
    8818:	39000320 	strb	w0, [x25]
    881c:	911ee3e1 	add	x1, sp, #0x7b8
    8820:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8824:	52800020 	mov	w0, #0x1                   	// #1
    8828:	f903dfe2 	str	x2, [sp, #1976]
    882c:	f903e3f6 	str	x22, [sp, #1984]
    8830:	97ffede5 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8834:	97ffeb53 	bl	3580 <fwp_rc_fresh>
    8838:	aa0003e2 	mov	x2, x0
    883c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8840:	911f23e1 	add	x1, sp, #0x7c8
    8844:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8848:	52800020 	mov	w0, #0x1                   	// #1
    884c:	f903e7e3 	str	x3, [sp, #1992]
    8850:	f903ebe2 	str	x2, [sp, #2000]
    8854:	97ffeddc 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8858:	91134263 	add	x3, x19, #0x4d0
    885c:	aa0003f6 	mov	x22, x0
    8860:	f949d861 	ldr	x1, [x3, #5040]
    8864:	f949ec60 	ldr	x0, [x3, #5080]
    8868:	cb0102c1 	sub	x1, x22, x1
    886c:	eb00403f 	cmp	x1, x0, lsl #16
    8870:	54000322 	b.cs	88d4 <f0+0x1ee4>  // b.hs, b.nlast
    8874:	d350fc22 	lsr	x2, x1, #16
    8878:	f949fc63 	ldr	x3, [x3, #5112]
    887c:	8b020842 	add	x2, x2, x2, lsl #2
    8880:	d37df042 	lsl	x2, x2, #3
    8884:	8b020060 	add	x0, x3, x2
    8888:	f9401019 	ldr	x25, [x0, #32]
    888c:	b4000259 	cbz	x25, 88d4 <f0+0x1ee4>
    8890:	38626862 	ldrb	w2, [x3, x2]
    8894:	7100085f 	cmp	w2, #0x2
    8898:	54002b00 	b.eq	8df8 <f0+0x2408>  // b.none
    889c:	7100045f 	cmp	w2, #0x1
    88a0:	540001a1 	b.ne	88d4 <f0+0x1ee4>  // b.any
    88a4:	29430002 	ldp	w2, w0, [x0, #24]
    88a8:	92403c21 	and	x1, x1, #0xffff
    88ac:	9b027c21 	mul	x1, x1, x2
    88b0:	d360fc21 	lsr	x1, x1, #32
    88b4:	eb00003f 	cmp	x1, x0
    88b8:	540000e2 	b.cs	88d4 <f0+0x1ee4>  // b.hs, b.nlast
    88bc:	8b010339 	add	x25, x25, x1
    88c0:	39400320 	ldrb	w0, [x25]
    88c4:	7103fc1f 	cmp	w0, #0xff
    88c8:	540039a0 	b.eq	8ffc <f0+0x260c>  // b.none
    88cc:	52800020 	mov	w0, #0x1                   	// #1
    88d0:	39000320 	strb	w0, [x25]
    88d4:	911f63e1 	add	x1, sp, #0x7d8
    88d8:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    88dc:	52800020 	mov	w0, #0x1                   	// #1
    88e0:	f903eff9 	str	x25, [sp, #2008]
    88e4:	f903f3f6 	str	x22, [sp, #2016]
    88e8:	97ffedb7 	bl	3fc4 <fwp_data.part.0.constprop.0>
    88ec:	97ffeb25 	bl	3580 <fwp_rc_fresh>
    88f0:	aa0003e2 	mov	x2, x0
    88f4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    88f8:	911fa3e1 	add	x1, sp, #0x7e8
    88fc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8900:	52800020 	mov	w0, #0x1                   	// #1
    8904:	f903f7e3 	str	x3, [sp, #2024]
    8908:	f903fbe2 	str	x2, [sp, #2032]
    890c:	97ffedae 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8910:	97ffeb1c 	bl	3580 <fwp_rc_fresh>
    8914:	aa0003e2 	mov	x2, x0
    8918:	911fe3e1 	add	x1, sp, #0x7f8
    891c:	52800020 	mov	w0, #0x1                   	// #1
    8920:	f903fff9 	str	x25, [sp, #2040]
    8924:	f90403e2 	str	x2, [sp, #2048]
    8928:	97ffeda7 	bl	3fc4 <fwp_data.part.0.constprop.0>
    892c:	91134263 	add	x3, x19, #0x4d0
    8930:	aa0003f9 	mov	x25, x0
    8934:	f949d861 	ldr	x1, [x3, #5040]
    8938:	f949ec60 	ldr	x0, [x3, #5080]
    893c:	cb010321 	sub	x1, x25, x1
    8940:	eb00403f 	cmp	x1, x0, lsl #16
    8944:	54000322 	b.cs	89a8 <f0+0x1fb8>  // b.hs, b.nlast
    8948:	d350fc22 	lsr	x2, x1, #16
    894c:	f949fc63 	ldr	x3, [x3, #5112]
    8950:	8b020842 	add	x2, x2, x2, lsl #2
    8954:	d37df042 	lsl	x2, x2, #3
    8958:	8b020060 	add	x0, x3, x2
    895c:	f9401016 	ldr	x22, [x0, #32]
    8960:	b4000256 	cbz	x22, 89a8 <f0+0x1fb8>
    8964:	38626862 	ldrb	w2, [x3, x2]
    8968:	7100085f 	cmp	w2, #0x2
    896c:	54002400 	b.eq	8dec <f0+0x23fc>  // b.none
    8970:	7100045f 	cmp	w2, #0x1
    8974:	540001a1 	b.ne	89a8 <f0+0x1fb8>  // b.any
    8978:	29430002 	ldp	w2, w0, [x0, #24]
    897c:	92403c21 	and	x1, x1, #0xffff
    8980:	9b027c21 	mul	x1, x1, x2
    8984:	d360fc21 	lsr	x1, x1, #32
    8988:	eb00003f 	cmp	x1, x0
    898c:	540000e2 	b.cs	89a8 <f0+0x1fb8>  // b.hs, b.nlast
    8990:	8b0102d6 	add	x22, x22, x1
    8994:	394002c0 	ldrb	w0, [x22]
    8998:	7103fc1f 	cmp	w0, #0xff
    899c:	54002640 	b.eq	8e64 <f0+0x2474>  // b.none
    89a0:	52800020 	mov	w0, #0x1                   	// #1
    89a4:	390002c0 	strb	w0, [x22]
    89a8:	912023e1 	add	x1, sp, #0x808
    89ac:	b200e7f6 	mov	x22, #0x3333333333333333    	// #3689348814741910323
    89b0:	f2f7fe76 	movk	x22, #0xbff3, lsl #48
    89b4:	52800020 	mov	w0, #0x1                   	// #1
    89b8:	f90407f6 	str	x22, [sp, #2056]
    89bc:	f9040bf9 	str	x25, [sp, #2064]
    89c0:	97ffed81 	bl	3fc4 <fwp_data.part.0.constprop.0>
    89c4:	97ffeaef 	bl	3580 <fwp_rc_fresh>
    89c8:	aa0003e2 	mov	x2, x0
    89cc:	912063e1 	add	x1, sp, #0x818
    89d0:	d2e7fe19 	mov	x25, #0x3ff0000000000000    	// #4607182418800017408
    89d4:	52800020 	mov	w0, #0x1                   	// #1
    89d8:	f9040ff9 	str	x25, [sp, #2072]
    89dc:	f90413e2 	str	x2, [sp, #2080]
    89e0:	97ffed79 	bl	3fc4 <fwp_data.part.0.constprop.0>
    89e4:	97ffeae7 	bl	3580 <fwp_rc_fresh>
    89e8:	aa0003e2 	mov	x2, x0
    89ec:	9120a3e1 	add	x1, sp, #0x828
    89f0:	52800020 	mov	w0, #0x1                   	// #1
    89f4:	f90417f6 	str	x22, [sp, #2088]
    89f8:	f9041be2 	str	x2, [sp, #2096]
    89fc:	97ffed72 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8a00:	97ffeae0 	bl	3580 <fwp_rc_fresh>
    8a04:	aa0003e2 	mov	x2, x0
    8a08:	9120e3e1 	add	x1, sp, #0x838
    8a0c:	52800020 	mov	w0, #0x1                   	// #1
    8a10:	f9041ff9 	str	x25, [sp, #2104]
    8a14:	f90423e2 	str	x2, [sp, #2112]
    8a18:	97ffed6b 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8a1c:	97ffead9 	bl	3580 <fwp_rc_fresh>
    8a20:	aa0003e2 	mov	x2, x0
    8a24:	912123e1 	add	x1, sp, #0x848
    8a28:	52800020 	mov	w0, #0x1                   	// #1
    8a2c:	f90427f6 	str	x22, [sp, #2120]
    8a30:	f9042be2 	str	x2, [sp, #2128]
    8a34:	97ffed64 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8a38:	97ffead2 	bl	3580 <fwp_rc_fresh>
    8a3c:	aa0003e2 	mov	x2, x0
    8a40:	912163e1 	add	x1, sp, #0x858
    8a44:	52800020 	mov	w0, #0x1                   	// #1
    8a48:	f9042ff9 	str	x25, [sp, #2136]
    8a4c:	f00000b9 	adrp	x25, 1f000 <__FRAME_END__+0x13c68>
    8a50:	f90433e2 	str	x2, [sp, #2144]
    8a54:	97ffed5c 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8a58:	97ffeaca 	bl	3580 <fwp_rc_fresh>
    8a5c:	aa0003e2 	mov	x2, x0
    8a60:	aa1703e1 	mov	x1, x23
    8a64:	52800020 	mov	w0, #0x1                   	// #1
    8a68:	f90437f6 	str	x22, [sp, #2152]
    8a6c:	aa1403f6 	mov	x22, x20
    8a70:	f9043be2 	str	x2, [sp, #2160]
    8a74:	97ffed54 	bl	3fc4 <fwp_data.part.0.constprop.0>
    8a78:	97ffeac2 	bl	3580 <fwp_rc_fresh>
    8a7c:	aa0003f7 	mov	x23, x0
    8a80:	b4000e74 	cbz	x20, 8c4c <f0+0x225c>
    8a84:	912ae339 	add	x25, x25, #0xab8
    8a88:	b000001a 	adrp	x26, 9000 <f0+0x2610>
    8a8c:	91014320 	add	x0, x25, #0x50
    8a90:	9113427b 	add	x27, x19, #0x4d0
    8a94:	913d835a 	add	x26, x26, #0xf60
    8a98:	f9000be0 	str	x0, [sp, #16]
    8a9c:	14000057 	b	8bf8 <f0+0x2208>
    8aa0:	7100045f 	cmp	w2, #0x1
    8aa4:	540001c1 	b.ne	8adc <f0+0x20ec>  // b.any
    8aa8:	29430865 	ldp	w5, w2, [x3, #24]
    8aac:	92403c21 	and	x1, x1, #0xffff
    8ab0:	9b057c21 	mul	x1, x1, x5
    8ab4:	d360fc21 	lsr	x1, x1, #32
    8ab8:	eb02003f 	cmp	x1, x2
    8abc:	54000102 	b.cs	8adc <f0+0x20ec>  // b.hs, b.nlast
    8ac0:	8b010000 	add	x0, x0, x1
    8ac4:	39400001 	ldrb	w1, [x0]
    8ac8:	340000a1 	cbz	w1, 8adc <f0+0x20ec>
    8acc:	7103f43f 	cmp	w1, #0xfd
    8ad0:	54000f48 	b.hi	8cb8 <f0+0x22c8>  // b.pmore
    8ad4:	11000421 	add	w1, w1, #0x1
    8ad8:	39000001 	strb	w1, [x0]
    8adc:	aa1703e0 	mov	x0, x23
    8ae0:	97fff104 	bl	4ef0 <fwp_loop_fields68.constprop.0>
    8ae4:	aa0003e1 	mov	x1, x0
    8ae8:	aa0003f3 	mov	x19, x0
    8aec:	a9408be0 	ldp	x0, x2, [sp, #8]
    8af0:	52800023 	mov	w3, #0x1                   	// #1
    8af4:	a9047fff 	stp	xzr, xzr, [sp, #64]
    8af8:	f9002bff 	str	xzr, [sp, #80]
    8afc:	97fff3c1 	bl	5a00 <fwp_write>
    8b00:	a94463f9 	ldp	x25, x24, [sp, #64]
    8b04:	f100033f 	cmp	x25, #0x0
    8b08:	9a990359 	csel	x25, x26, x25, eq	// eq = none
    8b0c:	b1002b1f 	cmn	x24, #0xa
    8b10:	540027c8 	b.hi	9008 <f0+0x2618>  // b.pmore
    8b14:	52800021 	mov	w1, #0x1                   	// #1
    8b18:	91002700 	add	x0, x24, #0x9
    8b1c:	97ffece5 	bl	3eb0 <fwp_heap_alloc>
    8b20:	aa0003fc 	mov	x28, x0
    8b24:	aa1903e1 	mov	x1, x25
    8b28:	aa0003f9 	mov	x25, x0
    8b2c:	aa1803e2 	mov	x2, x24
    8b30:	f8008738 	str	x24, [x25], #8
    8b34:	aa1903e0 	mov	x0, x25
    8b38:	97ffe206 	bl	1350 <memcpy@plt>
    8b3c:	8b180382 	add	x2, x28, x24
    8b40:	3900205f 	strb	wzr, [x2, #8]
    8b44:	f94023e0 	ldr	x0, [sp, #64]
    8b48:	97ffe29a 	bl	15b0 <free@plt>
    8b4c:	f949db61 	ldr	x1, [x27, #5040]
    8b50:	f949ef60 	ldr	x0, [x27, #5080]
    8b54:	cb010381 	sub	x1, x28, x1
    8b58:	eb00403f 	cmp	x1, x0, lsl #16
    8b5c:	54000322 	b.cs	8bc0 <f0+0x21d0>  // b.hs, b.nlast
    8b60:	d350fc20 	lsr	x0, x1, #16
    8b64:	f949ff66 	ldr	x6, [x27, #5112]
    8b68:	8b000800 	add	x0, x0, x0, lsl #2
    8b6c:	d37df002 	lsl	x2, x0, #3
    8b70:	8b0200c5 	add	x5, x6, x2
    8b74:	f94010a0 	ldr	x0, [x5, #32]
    8b78:	b4000240 	cbz	x0, 8bc0 <f0+0x21d0>
    8b7c:	386268c2 	ldrb	w2, [x6, x2]
    8b80:	7100085f 	cmp	w2, #0x2
    8b84:	540005e0 	b.eq	8c40 <f0+0x2250>  // b.none
    8b88:	7100045f 	cmp	w2, #0x1
    8b8c:	540001a1 	b.ne	8bc0 <f0+0x21d0>  // b.any
    8b90:	294308a6 	ldp	w6, w2, [x5, #24]
    8b94:	92403c21 	and	x1, x1, #0xffff
    8b98:	9b067c21 	mul	x1, x1, x6
    8b9c:	d360fc21 	lsr	x1, x1, #32
    8ba0:	eb02003f 	cmp	x1, x2
    8ba4:	540000e2 	b.cs	8bc0 <f0+0x21d0>  // b.hs, b.nlast
    8ba8:	8b010000 	add	x0, x0, x1
    8bac:	39400001 	ldrb	w1, [x0]
    8bb0:	7103fc3f 	cmp	w1, #0xff
    8bb4:	540007a0 	b.eq	8ca8 <f0+0x22b8>  // b.none
    8bb8:	52800021 	mov	w1, #0x1                   	// #1
    8bbc:	39000001 	strb	w1, [x0]
    8bc0:	aa1303e0 	mov	x0, x19
    8bc4:	97ffef3b 	bl	48b0 <fwp_drop0>
    8bc8:	f9400382 	ldr	x2, [x28]
    8bcc:	d2800021 	mov	x1, #0x1                   	// #1
    8bd0:	f9401aa3 	ldr	x3, [x21, #48]
    8bd4:	aa1903e0 	mov	x0, x25
    8bd8:	97ffe286 	bl	15f0 <fwrite@plt>
    8bdc:	f9401aa1 	ldr	x1, [x21, #48]
    8be0:	52800140 	mov	w0, #0xa                   	// #10
    8be4:	97ffe20b 	bl	1410 <fputc@plt>
    8be8:	aa1c03e0 	mov	x0, x28
    8bec:	97ffed91 	bl	4230 <fwp_drop4>
    8bf0:	f9400ad6 	ldr	x22, [x22, #16]
    8bf4:	b40002d6 	cbz	x22, 8c4c <f0+0x225c>
    8bf8:	f949db61 	ldr	x1, [x27, #5040]
    8bfc:	f949ef60 	ldr	x0, [x27, #5080]
    8c00:	cb0102e1 	sub	x1, x23, x1
    8c04:	eb00403f 	cmp	x1, x0, lsl #16
    8c08:	54fff6a2 	b.cs	8adc <f0+0x20ec>  // b.hs, b.nlast
    8c0c:	d350fc20 	lsr	x0, x1, #16
    8c10:	f949ff65 	ldr	x5, [x27, #5112]
    8c14:	8b000800 	add	x0, x0, x0, lsl #2
    8c18:	d37df002 	lsl	x2, x0, #3
    8c1c:	8b0200a3 	add	x3, x5, x2
    8c20:	f9401060 	ldr	x0, [x3, #32]
    8c24:	b4fff5c0 	cbz	x0, 8adc <f0+0x20ec>
    8c28:	386268a2 	ldrb	w2, [x5, x2]
    8c2c:	7100085f 	cmp	w2, #0x2
    8c30:	54fff381 	b.ne	8aa0 <f0+0x20b0>  // b.any
    8c34:	72003c3f 	tst	w1, #0xffff
    8c38:	54fff521 	b.ne	8adc <f0+0x20ec>  // b.any
    8c3c:	17ffffa2 	b	8ac4 <f0+0x20d4>
    8c40:	72003c3f 	tst	w1, #0xffff
    8c44:	54fffbe1 	b.ne	8bc0 <f0+0x21d0>  // b.any
    8c48:	17ffffd9 	b	8bac <f0+0x21bc>
    8c4c:	aa1703e0 	mov	x0, x23
    8c50:	97ffef18 	bl	48b0 <fwp_drop0>
    8c54:	aa1403e0 	mov	x0, x20
    8c58:	97ffef16 	bl	48b0 <fwp_drop0>
    8c5c:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    8c60:	f947f400 	ldr	x0, [x0, #4072]
    8c64:	f9443fe2 	ldr	x2, [sp, #2168]
    8c68:	f9400001 	ldr	x1, [x0]
    8c6c:	eb010042 	subs	x2, x2, x1
    8c70:	d2800001 	mov	x1, #0x0                   	// #0
    8c74:	54001d01 	b.ne	9014 <f0+0x2624>  // b.any
    8c78:	912203ff 	add	sp, sp, #0x880
    8c7c:	d2800000 	mov	x0, #0x0                   	// #0
    8c80:	a94153f3 	ldp	x19, x20, [sp, #16]
    8c84:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8c88:	a94363f7 	ldp	x23, x24, [sp, #48]
    8c8c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    8c90:	a94573fb 	ldp	x27, x28, [sp, #80]
    8c94:	a8c67bfd 	ldp	x29, x30, [sp], #96
    8c98:	d65f03c0 	ret
    8c9c:	aa1c03e0 	mov	x0, x28
    8ca0:	97ffe82c 	bl	2d50 <fwp_rc_forget_slot>
    8ca4:	17fff782 	b	6aac <f0+0xbc>
    8ca8:	f9000fe0 	str	x0, [sp, #24]
    8cac:	97ffe829 	bl	2d50 <fwp_rc_forget_slot>
    8cb0:	f9400fe0 	ldr	x0, [sp, #24]
    8cb4:	17ffffc1 	b	8bb8 <f0+0x21c8>
    8cb8:	97ffe7df 	bl	2c34 <fwp_rc_wide_dup>
    8cbc:	17ffff88 	b	8adc <f0+0x20ec>
    8cc0:	72003c3f 	tst	w1, #0xffff
    8cc4:	54ff0fa1 	b.ne	6eb8 <f0+0x4c8>  // b.any
    8cc8:	17fff877 	b	6ea4 <f0+0x4b4>
    8ccc:	72003c3f 	tst	w1, #0xffff
    8cd0:	54ff0541 	b.ne	6d78 <f0+0x388>  // b.any
    8cd4:	17fff824 	b	6d64 <f0+0x374>
    8cd8:	72003c3f 	tst	w1, #0xffff
    8cdc:	54fefa21 	b.ne	6c20 <f0+0x230>  // b.any
    8ce0:	17fff7cb 	b	6c0c <f0+0x21c>
    8ce4:	72003c3f 	tst	w1, #0xffff
    8ce8:	54ff5e01 	b.ne	78a8 <f0+0xeb8>  // b.any
    8cec:	17fffaea 	b	7894 <f0+0xea4>
    8cf0:	72003c3f 	tst	w1, #0xffff
    8cf4:	54ff5701 	b.ne	77d4 <f0+0xde4>  // b.any
    8cf8:	17fffab2 	b	77c0 <f0+0xdd0>
    8cfc:	72003c3f 	tst	w1, #0xffff
    8d00:	54ff6b61 	b.ne	7a6c <f0+0x107c>  // b.any
    8d04:	17fffb55 	b	7a58 <f0+0x1068>
    8d08:	72003c3f 	tst	w1, #0xffff
    8d0c:	54ff6541 	b.ne	79b4 <f0+0xfc4>  // b.any
    8d10:	17fffb24 	b	79a0 <f0+0xfb0>
    8d14:	72003c3f 	tst	w1, #0xffff
    8d18:	54ff7401 	b.ne	7b98 <f0+0x11a8>  // b.any
    8d1c:	17fffb9a 	b	7b84 <f0+0x1194>
    8d20:	72003c3f 	tst	w1, #0xffff
    8d24:	54ff6ee1 	b.ne	7b00 <f0+0x1110>  // b.any
    8d28:	17fffb71 	b	7aec <f0+0x10fc>
    8d2c:	72003c3f 	tst	w1, #0xffff
    8d30:	54ff8221 	b.ne	7d74 <f0+0x1384>  // b.any
    8d34:	17fffc0b 	b	7d60 <f0+0x1370>
    8d38:	72003c3f 	tst	w1, #0xffff
    8d3c:	54ff7d01 	b.ne	7cdc <f0+0x12ec>  // b.any
    8d40:	17fffbe2 	b	7cc8 <f0+0x12d8>
    8d44:	72003c3f 	tst	w1, #0xffff
    8d48:	54ff1fe1 	b.ne	7144 <f0+0x754>  // b.any
    8d4c:	17fff8f9 	b	7130 <f0+0x740>
    8d50:	72003c3f 	tst	w1, #0xffff
    8d54:	54ff1801 	b.ne	7054 <f0+0x664>  // b.any
    8d58:	17fff8ba 	b	7040 <f0+0x650>
    8d5c:	72003c3f 	tst	w1, #0xffff
    8d60:	54ff2c61 	b.ne	72ec <f0+0x8fc>  // b.any
    8d64:	17fff95d 	b	72d8 <f0+0x8e8>
    8d68:	72003c3f 	tst	w1, #0xffff
    8d6c:	54ff2641 	b.ne	7234 <f0+0x844>  // b.any
    8d70:	17fff92c 	b	7220 <f0+0x830>
    8d74:	72003c3f 	tst	w1, #0xffff
    8d78:	54ff38e1 	b.ne	7494 <f0+0xaa4>  // b.any
    8d7c:	17fff9c1 	b	7480 <f0+0xa90>
    8d80:	72003c3f 	tst	w1, #0xffff
    8d84:	54ff3101 	b.ne	73a4 <f0+0x9b4>  // b.any
    8d88:	17fff982 	b	7390 <f0+0x9a0>
    8d8c:	72003c3f 	tst	w1, #0xffff
    8d90:	54ff49c1 	b.ne	76c8 <f0+0xcd8>  // b.any
    8d94:	17fffa48 	b	76b4 <f0+0xcc4>
    8d98:	72003c3f 	tst	w1, #0xffff
    8d9c:	54ff3f41 	b.ne	7584 <f0+0xb94>  // b.any
    8da0:	17fff9f4 	b	7570 <f0+0xb80>
    8da4:	72003c3f 	tst	w1, #0xffff
    8da8:	54ffba21 	b.ne	84ec <f0+0x1afc>  // b.any
    8dac:	17fffdcb 	b	84d8 <f0+0x1ae8>
    8db0:	72003c3f 	tst	w1, #0xffff
    8db4:	54ffb321 	b.ne	8418 <f0+0x1a28>  // b.any
    8db8:	17fffd93 	b	8404 <f0+0x1a14>
    8dbc:	72003c3f 	tst	w1, #0xffff
    8dc0:	54ffc861 	b.ne	86cc <f0+0x1cdc>  // b.any
    8dc4:	17fffe3d 	b	86b8 <f0+0x1cc8>
    8dc8:	72003c3f 	tst	w1, #0xffff
    8dcc:	54ffbfa1 	b.ne	85c0 <f0+0x1bd0>  // b.any
    8dd0:	17fffdf7 	b	85ac <f0+0x1bbc>
    8dd4:	72003c3f 	tst	w1, #0xffff
    8dd8:	54ffd221 	b.ne	881c <f0+0x1e2c>  // b.any
    8ddc:	17fffe8b 	b	8808 <f0+0x1e18>
    8de0:	72003c3f 	tst	w1, #0xffff
    8de4:	54ffcc01 	b.ne	8764 <f0+0x1d74>  // b.any
    8de8:	17fffe5a 	b	8750 <f0+0x1d60>
    8dec:	72003c3f 	tst	w1, #0xffff
    8df0:	54ffddc1 	b.ne	89a8 <f0+0x1fb8>  // b.any
    8df4:	17fffee8 	b	8994 <f0+0x1fa4>
    8df8:	72003c3f 	tst	w1, #0xffff
    8dfc:	54ffd6c1 	b.ne	88d4 <f0+0x1ee4>  // b.any
    8e00:	17fffeb0 	b	88c0 <f0+0x1ed0>
    8e04:	72003c3f 	tst	w1, #0xffff
    8e08:	54ff86e1 	b.ne	7ee4 <f0+0x14f4>  // b.any
    8e0c:	17fffc31 	b	7ed0 <f0+0x14e0>
    8e10:	72003c3f 	tst	w1, #0xffff
    8e14:	54ff80c1 	b.ne	7e2c <f0+0x143c>  // b.any
    8e18:	17fffc00 	b	7e18 <f0+0x1428>
    8e1c:	72003c3f 	tst	w1, #0xffff
    8e20:	54ff9081 	b.ne	8030 <f0+0x1640>  // b.any
    8e24:	17fffc7e 	b	801c <f0+0x162c>
    8e28:	72003c3f 	tst	w1, #0xffff
    8e2c:	54ff8b81 	b.ne	7f9c <f0+0x15ac>  // b.any
    8e30:	17fffc56 	b	7f88 <f0+0x1598>
    8e34:	72003c3f 	tst	w1, #0xffff
    8e38:	54ff9ec1 	b.ne	8210 <f0+0x1820>  // b.any
    8e3c:	17fffcf0 	b	81fc <f0+0x180c>
    8e40:	72003c3f 	tst	w1, #0xffff
    8e44:	54ff9601 	b.ne	8104 <f0+0x1714>  // b.any
    8e48:	17fffcaa 	b	80f0 <f0+0x1700>
    8e4c:	72003c3f 	tst	w1, #0xffff
    8e50:	54ffa881 	b.ne	8360 <f0+0x1970>  // b.any
    8e54:	17fffd3e 	b	834c <f0+0x195c>
    8e58:	72003c3f 	tst	w1, #0xffff
    8e5c:	54ffa261 	b.ne	82a8 <f0+0x18b8>  // b.any
    8e60:	17fffd0d 	b	8294 <f0+0x18a4>
    8e64:	aa1603e0 	mov	x0, x22
    8e68:	97ffe7ba 	bl	2d50 <fwp_rc_forget_slot>
    8e6c:	17fffecd 	b	89a0 <f0+0x1fb0>
    8e70:	aa1603e0 	mov	x0, x22
    8e74:	97ffe7b7 	bl	2d50 <fwp_rc_forget_slot>
    8e78:	17fff768 	b	6c18 <f0+0x228>
    8e7c:	aa1903e0 	mov	x0, x25
    8e80:	97ffe7b4 	bl	2d50 <fwp_rc_forget_slot>
    8e84:	17fff7bb 	b	6d70 <f0+0x380>
    8e88:	aa1603e0 	mov	x0, x22
    8e8c:	97ffe7b1 	bl	2d50 <fwp_rc_forget_slot>
    8e90:	17fff808 	b	6eb0 <f0+0x4c0>
    8e94:	aa1903e0 	mov	x0, x25
    8e98:	97ffe7ae 	bl	2d50 <fwp_rc_forget_slot>
    8e9c:	17fff86c 	b	704c <f0+0x65c>
    8ea0:	aa1903e0 	mov	x0, x25
    8ea4:	97ffe7ab 	bl	2d50 <fwp_rc_forget_slot>
    8ea8:	17fff8a5 	b	713c <f0+0x74c>
    8eac:	aa1903e0 	mov	x0, x25
    8eb0:	97ffe7a8 	bl	2d50 <fwp_rc_forget_slot>
    8eb4:	17fff8de 	b	722c <f0+0x83c>
    8eb8:	aa1903e0 	mov	x0, x25
    8ebc:	97ffe7a5 	bl	2d50 <fwp_rc_forget_slot>
    8ec0:	17fff909 	b	72e4 <f0+0x8f4>
    8ec4:	aa1903e0 	mov	x0, x25
    8ec8:	97ffe7a2 	bl	2d50 <fwp_rc_forget_slot>
    8ecc:	17fff934 	b	739c <f0+0x9ac>
    8ed0:	aa1903e0 	mov	x0, x25
    8ed4:	97ffe79f 	bl	2d50 <fwp_rc_forget_slot>
    8ed8:	17fff96d 	b	748c <f0+0xa9c>
    8edc:	aa1903e0 	mov	x0, x25
    8ee0:	97ffe79c 	bl	2d50 <fwp_rc_forget_slot>
    8ee4:	17fff9a6 	b	757c <f0+0xb8c>
    8ee8:	aa1903e0 	mov	x0, x25
    8eec:	97ffe799 	bl	2d50 <fwp_rc_forget_slot>
    8ef0:	17fff9f4 	b	76c0 <f0+0xcd0>
    8ef4:	aa1903e0 	mov	x0, x25
    8ef8:	97ffe796 	bl	2d50 <fwp_rc_forget_slot>
    8efc:	17fffa34 	b	77cc <f0+0xddc>
    8f00:	aa1903e0 	mov	x0, x25
    8f04:	97ffe793 	bl	2d50 <fwp_rc_forget_slot>
    8f08:	17fffa66 	b	78a0 <f0+0xeb0>
    8f0c:	aa1903e0 	mov	x0, x25
    8f10:	97ffe790 	bl	2d50 <fwp_rc_forget_slot>
    8f14:	17fffaa6 	b	79ac <f0+0xfbc>
    8f18:	aa1903e0 	mov	x0, x25
    8f1c:	97ffe78d 	bl	2d50 <fwp_rc_forget_slot>
    8f20:	17fffad1 	b	7a64 <f0+0x1074>
    8f24:	aa1903e0 	mov	x0, x25
    8f28:	97ffe78a 	bl	2d50 <fwp_rc_forget_slot>
    8f2c:	17fffaf3 	b	7af8 <f0+0x1108>
    8f30:	aa1903e0 	mov	x0, x25
    8f34:	97ffe787 	bl	2d50 <fwp_rc_forget_slot>
    8f38:	17fffb16 	b	7b90 <f0+0x11a0>
    8f3c:	aa1903e0 	mov	x0, x25
    8f40:	97ffe784 	bl	2d50 <fwp_rc_forget_slot>
    8f44:	17fffb64 	b	7cd4 <f0+0x12e4>
    8f48:	aa1903e0 	mov	x0, x25
    8f4c:	97ffe781 	bl	2d50 <fwp_rc_forget_slot>
    8f50:	17fffb87 	b	7d6c <f0+0x137c>
    8f54:	aa1903e0 	mov	x0, x25
    8f58:	97ffe77e 	bl	2d50 <fwp_rc_forget_slot>
    8f5c:	17fffbb2 	b	7e24 <f0+0x1434>
    8f60:	aa1903e0 	mov	x0, x25
    8f64:	97ffe77b 	bl	2d50 <fwp_rc_forget_slot>
    8f68:	17fffbdd 	b	7edc <f0+0x14ec>
    8f6c:	aa1903e0 	mov	x0, x25
    8f70:	97ffe778 	bl	2d50 <fwp_rc_forget_slot>
    8f74:	17fffc08 	b	7f94 <f0+0x15a4>
    8f78:	aa1903e0 	mov	x0, x25
    8f7c:	97ffe775 	bl	2d50 <fwp_rc_forget_slot>
    8f80:	17fffc2a 	b	8028 <f0+0x1638>
    8f84:	aa1903e0 	mov	x0, x25
    8f88:	97ffe772 	bl	2d50 <fwp_rc_forget_slot>
    8f8c:	17fffc5c 	b	80fc <f0+0x170c>
    8f90:	aa1903e0 	mov	x0, x25
    8f94:	97ffe76f 	bl	2d50 <fwp_rc_forget_slot>
    8f98:	17fffc9c 	b	8208 <f0+0x1818>
    8f9c:	aa1903e0 	mov	x0, x25
    8fa0:	97ffe76c 	bl	2d50 <fwp_rc_forget_slot>
    8fa4:	17fffcbf 	b	82a0 <f0+0x18b0>
    8fa8:	aa1903e0 	mov	x0, x25
    8fac:	97ffe769 	bl	2d50 <fwp_rc_forget_slot>
    8fb0:	17fffcea 	b	8358 <f0+0x1968>
    8fb4:	aa1903e0 	mov	x0, x25
    8fb8:	97ffe766 	bl	2d50 <fwp_rc_forget_slot>
    8fbc:	17fffd15 	b	8410 <f0+0x1a20>
    8fc0:	aa1903e0 	mov	x0, x25
    8fc4:	97ffe763 	bl	2d50 <fwp_rc_forget_slot>
    8fc8:	17fffd47 	b	84e4 <f0+0x1af4>
    8fcc:	aa1903e0 	mov	x0, x25
    8fd0:	97ffe760 	bl	2d50 <fwp_rc_forget_slot>
    8fd4:	17fffd79 	b	85b8 <f0+0x1bc8>
    8fd8:	aa1903e0 	mov	x0, x25
    8fdc:	97ffe75d 	bl	2d50 <fwp_rc_forget_slot>
    8fe0:	17fffdb9 	b	86c4 <f0+0x1cd4>
    8fe4:	aa1903e0 	mov	x0, x25
    8fe8:	97ffe75a 	bl	2d50 <fwp_rc_forget_slot>
    8fec:	17fffddc 	b	875c <f0+0x1d6c>
    8ff0:	aa1903e0 	mov	x0, x25
    8ff4:	97ffe757 	bl	2d50 <fwp_rc_forget_slot>
    8ff8:	17fffe07 	b	8814 <f0+0x1e24>
    8ffc:	aa1903e0 	mov	x0, x25
    9000:	97ffe754 	bl	2d50 <fwp_rc_forget_slot>
    9004:	17fffe32 	b	88cc <f0+0x1edc>
    9008:	90000000 	adrp	x0, 9000 <f0+0x2610>
    900c:	913fe000 	add	x0, x0, #0xff8
    9010:	97ffe444 	bl	2120 <fwp_trap>
    9014:	97ffe137 	bl	14f0 <__stack_chk_fail@plt>
    9018:	d503201f 	nop
    901c:	d503201f 	nop

0000000000009020 <fwp_main_thread>:
    9020:	d10443ff 	sub	sp, sp, #0x110
    9024:	d00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    9028:	f947f400 	ldr	x0, [x0, #4072]
    902c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    9030:	910303fd 	add	x29, sp, #0xc0
    9034:	a90d53f3 	stp	x19, x20, [sp, #208]
    9038:	90000153 	adrp	x19, 31000 <fwp_root_context+0xd10>
    903c:	91134261 	add	x1, x19, #0x4d0
    9040:	a90e5bf5 	stp	x21, x22, [sp, #224]
    9044:	b953a421 	ldr	w1, [x1, #5028]
    9048:	f9400002 	ldr	x2, [x0]
    904c:	f9005fe2 	str	x2, [sp, #184]
    9050:	d2800002 	mov	x2, #0x0                   	// #0
    9054:	34002581 	cbz	w1, 9504 <fwp_main_thread+0x4e4>
    9058:	91134273 	add	x19, x19, #0x4d0
    905c:	b953aa60 	ldr	w0, [x19, #5032]
    9060:	350024a0 	cbnz	w0, 94f4 <fwp_main_thread+0x4d4>
    9064:	91001fe2 	add	x2, sp, #0x7
    9068:	f00000b5 	adrp	x21, 20000 <__data_start>
    906c:	f00000a3 	adrp	x3, 20000 <__data_start>
    9070:	9100c2b3 	add	x19, x21, #0x30
    9074:	910bc063 	add	x3, x3, #0x2f0
    9078:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    907c:	d2a00025 	mov	x5, #0x10000               	// #65536
    9080:	910023e0 	add	x0, sp, #0x8
    9084:	d2800001 	mov	x1, #0x0                   	// #0
    9088:	f90007e3 	str	x3, [sp, #8]
    908c:	a9011262 	stp	x2, x4, [x19, #16]
    9090:	b90013ff 	str	wzr, [sp, #16]
    9094:	f9000fe5 	str	x5, [sp, #24]
    9098:	97ffe0b2 	bl	1360 <sigaltstack@plt>
    909c:	350024e0 	cbnz	w0, 9538 <fwp_main_thread+0x518>
    90a0:	4f000400 	movi	v0.4s, #0x0
    90a4:	9100a3e0 	add	x0, sp, #0x28
    90a8:	90ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    90ac:	52800082 	mov	w2, #0x4                   	// #4
    90b0:	91314021 	add	x1, x1, #0xc50
    90b4:	72a10002 	movk	w2, #0x800, lsl #16
    90b8:	910083f4 	add	x20, sp, #0x20
    90bc:	f90013e1 	str	x1, [sp, #32]
    90c0:	3d802000 	str	q0, [x0, #128]
    90c4:	b900abe2 	str	w2, [sp, #168]
    90c8:	ad000000 	stp	q0, q0, [x0]
    90cc:	ad010000 	stp	q0, q0, [x0, #32]
    90d0:	ad020000 	stp	q0, q0, [x0, #64]
    90d4:	ad030000 	stp	q0, q0, [x0, #96]
    90d8:	97ffe0f6 	bl	14b0 <sigemptyset@plt>
    90dc:	350022e0 	cbnz	w0, 9538 <fwp_main_thread+0x518>
    90e0:	aa1403e1 	mov	x1, x20
    90e4:	d2800002 	mov	x2, #0x0                   	// #0
    90e8:	52800160 	mov	w0, #0xb                   	// #11
    90ec:	97ffe109 	bl	1510 <sigaction@plt>
    90f0:	35002240 	cbnz	w0, 9538 <fwp_main_thread+0x518>
    90f4:	aa1403e1 	mov	x1, x20
    90f8:	d2800002 	mov	x2, #0x0                   	// #0
    90fc:	528000e0 	mov	w0, #0x7                   	// #7
    9100:	97ffe104 	bl	1510 <sigaction@plt>
    9104:	350021a0 	cbnz	w0, 9538 <fwp_main_thread+0x518>
    9108:	b9429660 	ldr	w0, [x19, #660]
    910c:	a90f63f7 	stp	x23, x24, [sp, #240]
    9110:	34001fe0 	cbz	w0, 950c <fwp_main_thread+0x4ec>
    9114:	9100c2b6 	add	x22, x21, #0x30
    9118:	f94006d4 	ldr	x20, [x22, #8]
    911c:	b40010d4 	cbz	x20, 9334 <fwp_main_thread+0x314>
    9120:	aa1403f3 	mov	x19, x20
    9124:	91010297 	add	x23, x20, #0x40
    9128:	f90083f9 	str	x25, [sp, #256]
    912c:	52800038 	mov	w24, #0x1                   	// #1
    9130:	39414a99 	ldrb	w25, [x20, #82]
    9134:	39014a98 	strb	w24, [x20, #82]
    9138:	f9401680 	ldr	x0, [x20, #40]
    913c:	b4000620 	cbz	x0, 9200 <fwp_main_thread+0x1e0>
    9140:	f9403281 	ldr	x1, [x20, #96]
    9144:	39414680 	ldrb	w0, [x20, #81]
    9148:	b4000b41 	cbz	x1, 92b0 <fwp_main_thread+0x290>
    914c:	36000a80 	tbz	w0, #0, 929c <fwp_main_thread+0x27c>
    9150:	39414a62 	ldrb	w2, [x19, #82]
    9154:	f9402280 	ldr	x0, [x20, #64]
    9158:	37000d62 	tbnz	w2, #0, 9304 <fwp_main_thread+0x2e4>
    915c:	f9403261 	ldr	x1, [x19, #96]
    9160:	a911fe77 	stp	x23, xzr, [x19, #280]
    9164:	f9009660 	str	x0, [x19, #296]
    9168:	b4000040 	cbz	x0, 9170 <fwp_main_thread+0x150>
    916c:	f9009013 	str	x19, [x0, #288]
    9170:	f9002293 	str	x19, [x20, #64]
    9174:	b4000101 	cbz	x1, 9194 <fwp_main_thread+0x174>
    9178:	f9401ac0 	ldr	x0, [x22, #48]
    917c:	39015678 	strb	w24, [x19, #85]
    9180:	f9003661 	str	x1, [x19, #104]
    9184:	a910827f 	stp	xzr, x0, [x19, #264]
    9188:	b4000040 	cbz	x0, 9190 <fwp_main_thread+0x170>
    918c:	f9008413 	str	x19, [x0, #264]
    9190:	f9001ad3 	str	x19, [x22, #48]
    9194:	39015a7f 	strb	wzr, [x19, #86]
    9198:	97ffe9fb 	bl	3984 <fwp_block>
    919c:	f9408e62 	ldr	x2, [x19, #280]
    91a0:	b4000142 	cbz	x2, 91c8 <fwp_main_thread+0x1a8>
    91a4:	a9520261 	ldp	x1, x0, [x19, #288]
    91a8:	b4000ba1 	cbz	x1, 931c <fwp_main_thread+0x2fc>
    91ac:	f9009420 	str	x0, [x1, #296]
    91b0:	f9409660 	ldr	x0, [x19, #296]
    91b4:	b4000040 	cbz	x0, 91bc <fwp_main_thread+0x19c>
    91b8:	f9009001 	str	x1, [x0, #288]
    91bc:	91080260 	add	x0, x19, #0x200
    91c0:	f900967f 	str	xzr, [x19, #296]
    91c4:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    91c8:	39415660 	ldrb	w0, [x19, #85]
    91cc:	f94006c2 	ldr	x2, [x22, #8]
    91d0:	36000960 	tbz	w0, #0, 92fc <fwp_main_thread+0x2dc>
    91d4:	a9508261 	ldp	x1, x0, [x19, #264]
    91d8:	b4000a61 	cbz	x1, 9324 <fwp_main_thread+0x304>
    91dc:	f9008820 	str	x0, [x1, #272]
    91e0:	b4000040 	cbz	x0, 91e8 <fwp_main_thread+0x1c8>
    91e4:	f9008401 	str	x1, [x0, #264]
    91e8:	91080260 	add	x0, x19, #0x200
    91ec:	3901567f 	strb	wzr, [x19, #85]
    91f0:	aa0203f3 	mov	x19, x2
    91f4:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    91f8:	f9401680 	ldr	x0, [x20, #40]
    91fc:	b5fffa20 	cbnz	x0, 9140 <fwp_main_thread+0x120>
    9200:	9100c2a0 	add	x0, x21, #0x30
    9204:	39014a99 	strb	w25, [x20, #82]
    9208:	f94083f9 	ldr	x25, [sp, #256]
    920c:	f9413c00 	ldr	x0, [x0, #632]
    9210:	b4001520 	cbz	x0, 94b4 <fwp_main_thread+0x494>
    9214:	9100c2a0 	add	x0, x21, #0x30
    9218:	f9415401 	ldr	x1, [x0, #680]
    921c:	b902a01f 	str	wzr, [x0, #672]
    9220:	eb13003f 	cmp	x1, x19
    9224:	54001641 	b.ne	94ec <fwp_main_thread+0x4cc>  // b.any
    9228:	b4000913 	cbz	x19, 9348 <fwp_main_thread+0x328>
    922c:	9100c2a0 	add	x0, x21, #0x30
    9230:	52800021 	mov	w1, #0x1                   	// #1
    9234:	39014a61 	strb	w1, [x19, #82]
    9238:	f9412805 	ldr	x5, [x0, #592]
    923c:	b4000865 	cbz	x5, 9348 <fwp_main_thread+0x328>
    9240:	394140a0 	ldrb	w0, [x5, #80]
    9244:	37000060 	tbnz	w0, #0, 9250 <fwp_main_thread+0x230>
    9248:	aa0503e0 	mov	x0, x5
    924c:	97ffe371 	bl	2010 <fwp_cancel_tree.part.0>
    9250:	f9409ca5 	ldr	x5, [x5, #312]
    9254:	b5ffff65 	cbnz	x5, 9240 <fwp_main_thread+0x220>
    9258:	9100c2b4 	add	x20, x21, #0x30
    925c:	52800036 	mov	w22, #0x1                   	// #1
    9260:	f9402a60 	ldr	x0, [x19, #80]
    9264:	f2001c1f 	tst	x0, #0xff000000ff
    9268:	540000e1 	b.ne	9284 <fwp_main_thread+0x264>  // b.any
    926c:	f9401280 	ldr	x0, [x20, #32]
    9270:	39015276 	strb	w22, [x19, #84]
    9274:	f900827f 	str	xzr, [x19, #256]
    9278:	b40005a0 	cbz	x0, 932c <fwp_main_thread+0x30c>
    927c:	f9008013 	str	x19, [x0, #256]
    9280:	f9001293 	str	x19, [x20, #32]
    9284:	97ffe9c0 	bl	3984 <fwp_block>
    9288:	97ffe952 	bl	37d0 <fwp_free_zombie>
    928c:	f9412a80 	ldr	x0, [x20, #592]
    9290:	b40005c0 	cbz	x0, 9348 <fwp_main_thread+0x328>
    9294:	f9415693 	ldr	x19, [x20, #680]
    9298:	17fffff2 	b	9260 <fwp_main_thread+0x240>
    929c:	97ffe3b1 	bl	2160 <fwp_now_ns>
    92a0:	f9403281 	ldr	x1, [x20, #96]
    92a4:	eb01001f 	cmp	x0, x1
    92a8:	54000f8a 	b.ge	9498 <fwp_main_thread+0x478>  // b.tcont
    92ac:	39414680 	ldrb	w0, [x20, #81]
    92b0:	39414a62 	ldrb	w2, [x19, #82]
    92b4:	3707f500 	tbnz	w0, #0, 9154 <fwp_main_thread+0x134>
    92b8:	f9403281 	ldr	x1, [x20, #96]
    92bc:	370001c2 	tbnz	w2, #0, 92f4 <fwp_main_thread+0x2d4>
    92c0:	f9403260 	ldr	x0, [x19, #96]
    92c4:	b4000180 	cbz	x0, 92f4 <fwp_main_thread+0x2d4>
    92c8:	b4000061 	cbz	x1, 92d4 <fwp_main_thread+0x2b4>
    92cc:	eb01001f 	cmp	x0, x1
    92d0:	9a81d000 	csel	x0, x0, x1, le
    92d4:	f9402281 	ldr	x1, [x20, #64]
    92d8:	a911fe77 	stp	x23, xzr, [x19, #280]
    92dc:	f9009661 	str	x1, [x19, #296]
    92e0:	b4001201 	cbz	x1, 9520 <fwp_main_thread+0x500>
    92e4:	f9009033 	str	x19, [x1, #288]
    92e8:	aa0003e1 	mov	x1, x0
    92ec:	f9002293 	str	x19, [x20, #64]
    92f0:	17ffffa2 	b	9178 <fwp_main_thread+0x158>
    92f4:	f9402280 	ldr	x0, [x20, #64]
    92f8:	17ffff9a 	b	9160 <fwp_main_thread+0x140>
    92fc:	aa0203f3 	mov	x19, x2
    9300:	17ffff8e 	b	9138 <fwp_main_thread+0x118>
    9304:	a911fe77 	stp	x23, xzr, [x19, #280]
    9308:	f9009660 	str	x0, [x19, #296]
    930c:	b4000040 	cbz	x0, 9314 <fwp_main_thread+0x2f4>
    9310:	f9009013 	str	x19, [x0, #288]
    9314:	f9002293 	str	x19, [x20, #64]
    9318:	17ffff9f 	b	9194 <fwp_main_thread+0x174>
    931c:	f9000040 	str	x0, [x2]
    9320:	17ffffa5 	b	91b4 <fwp_main_thread+0x194>
    9324:	f9001ac0 	str	x0, [x22, #48]
    9328:	17ffffae 	b	91e0 <fwp_main_thread+0x1c0>
    932c:	f9001693 	str	x19, [x20, #40]
    9330:	17ffffd4 	b	9280 <fwp_main_thread+0x260>
    9334:	f9413ec0 	ldr	x0, [x22, #632]
    9338:	b4000bc0 	cbz	x0, 94b0 <fwp_main_thread+0x490>
    933c:	f94156c0 	ldr	x0, [x22, #680]
    9340:	b902a2df 	str	wzr, [x22, #672]
    9344:	b5000d40 	cbnz	x0, 94ec <fwp_main_thread+0x4cc>
    9348:	9100c2b4 	add	x20, x21, #0x30
    934c:	97ffe921 	bl	37d0 <fwp_free_zombie>
    9350:	f9401680 	ldr	x0, [x20, #40]
    9354:	b5000cc0 	cbnz	x0, 94ec <fwp_main_thread+0x4cc>
    9358:	f9401a80 	ldr	x0, [x20, #48]
    935c:	b5000c80 	cbnz	x0, 94ec <fwp_main_thread+0x4cc>
    9360:	b9404293 	ldr	w19, [x20, #64]
    9364:	340001d3 	cbz	w19, 939c <fwp_main_thread+0x37c>
    9368:	93407e76 	sxtw	x22, w19
    936c:	51000673 	sub	w19, w19, #0x1
    9370:	d1000ad6 	sub	x22, x22, #0x2
    9374:	91014297 	add	x23, x20, #0x50
    9378:	cb3342d6 	sub	x22, x22, w19, uxtw
    937c:	93407e73 	sxtw	x19, w19
    9380:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    9384:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    9388:	b9004293 	str	w19, [x20, #64]
    938c:	d1000673 	sub	x19, x19, #0x1
    9390:	97ffe0a0 	bl	1610 <munmap@plt>
    9394:	eb16027f 	cmp	x19, x22
    9398:	54ffff41 	b.ne	9380 <fwp_main_thread+0x360>  // b.any
    939c:	f00000b3 	adrp	x19, 20000 <__data_start>
    93a0:	b9401260 	ldr	w0, [x19, #16]
    93a4:	37f80040 	tbnz	w0, #31, 93ac <fwp_main_thread+0x38c>
    93a8:	97ffe056 	bl	1500 <close@plt>
    93ac:	9100c2a0 	add	x0, x21, #0x30
    93b0:	12800001 	mov	w1, #0xffffffff            	// #-1
    93b4:	b9001261 	str	w1, [x19, #16]
    93b8:	d2800013 	mov	x19, #0x0                   	// #0
    93bc:	f9415816 	ldr	x22, [x0, #688]
    93c0:	f9415c14 	ldr	x20, [x0, #696]
    93c4:	b4000176 	cbz	x22, 93f0 <fwp_main_thread+0x3d0>
    93c8:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    93cc:	b40000c0 	cbz	x0, 93e4 <fwp_main_thread+0x3c4>
    93d0:	f9400001 	ldr	x1, [x0]
    93d4:	b50008c1 	cbnz	x1, 94ec <fwp_main_thread+0x4cc>
    93d8:	f9400401 	ldr	x1, [x0, #8]
    93dc:	b5000881 	cbnz	x1, 94ec <fwp_main_thread+0x4cc>
    93e0:	97ffe6fc 	bl	2fd0 <fwp_mem_free>
    93e4:	91000673 	add	x19, x19, #0x1
    93e8:	eb16027f 	cmp	x19, x22
    93ec:	54fffee1 	b.ne	93c8 <fwp_main_thread+0x3a8>  // b.any
    93f0:	aa1403e0 	mov	x0, x20
    93f4:	97ffe6f7 	bl	2fd0 <fwp_mem_free>
    93f8:	9100c2a0 	add	x0, x21, #0x30
    93fc:	f9415413 	ldr	x19, [x0, #680]
    9400:	f901581f 	str	xzr, [x0, #688]
    9404:	f9015c1f 	str	xzr, [x0, #696]
    9408:	b40001f3 	cbz	x19, 9444 <fwp_main_thread+0x424>
    940c:	f9401661 	ldr	x1, [x19, #40]
    9410:	b50006e1 	cbnz	x1, 94ec <fwp_main_thread+0x4cc>
    9414:	f9405661 	ldr	x1, [x19, #168]
    9418:	b50006a1 	cbnz	x1, 94ec <fwp_main_thread+0x4cc>
    941c:	f9413c01 	ldr	x1, [x0, #632]
    9420:	b5000661 	cbnz	x1, 94ec <fwp_main_thread+0x4cc>
    9424:	f9414400 	ldr	x0, [x0, #648]
    9428:	b5000620 	cbnz	x0, 94ec <fwp_main_thread+0x4cc>
    942c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9430:	f0000120 	adrp	x0, 30000 <alt.4+0xfd10>
    9434:	910bc000 	add	x0, x0, #0x2f0
    9438:	97ffe022 	bl	14c0 <memset@plt>
    943c:	aa1303e0 	mov	x0, x19
    9440:	97ffe6e4 	bl	2fd0 <fwp_mem_free>
    9444:	d00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    9448:	f947ec00 	ldr	x0, [x0, #4056]
    944c:	9100c2b5 	add	x21, x21, #0x30
    9450:	f9400000 	ldr	x0, [x0]
    9454:	f90006bf 	str	xzr, [x21, #8]
    9458:	f90156bf 	str	xzr, [x21, #680]
    945c:	97ffe071 	bl	1620 <fflush@plt>
    9460:	d00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x13c68>
    9464:	f947f400 	ldr	x0, [x0, #4072]
    9468:	f9405fe2 	ldr	x2, [sp, #184]
    946c:	f9400001 	ldr	x1, [x0]
    9470:	eb010042 	subs	x2, x2, x1
    9474:	d2800001 	mov	x1, #0x0                   	// #0
    9478:	540006a1 	b.ne	954c <fwp_main_thread+0x52c>  // b.any
    947c:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    9480:	d2800000 	mov	x0, #0x0                   	// #0
    9484:	a94d53f3 	ldp	x19, x20, [sp, #208]
    9488:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    948c:	a94f63f7 	ldp	x23, x24, [sp, #240]
    9490:	910443ff 	add	sp, sp, #0x110
    9494:	d65f03c0 	ret
    9498:	39414280 	ldrb	w0, [x20, #80]
    949c:	3707f080 	tbnz	w0, #0, 92ac <fwp_main_thread+0x28c>
    94a0:	aa1403e0 	mov	x0, x20
    94a4:	97ffe2db 	bl	2010 <fwp_cancel_tree.part.0>
    94a8:	39414680 	ldrb	w0, [x20, #81]
    94ac:	17ffff81 	b	92b0 <fwp_main_thread+0x290>
    94b0:	d2800013 	mov	x19, #0x0                   	// #0
    94b4:	9100c2b4 	add	x20, x21, #0x30
    94b8:	f9414680 	ldr	x0, [x20, #648]
    94bc:	b5ffeac0 	cbnz	x0, 9214 <fwp_main_thread+0x1f4>
    94c0:	f9413a80 	ldr	x0, [x20, #624]
    94c4:	97ffe6c3 	bl	2fd0 <fwp_mem_free>
    94c8:	f9013a9f 	str	xzr, [x20, #624]
    94cc:	f901429f 	str	xzr, [x20, #640]
    94d0:	f9415680 	ldr	x0, [x20, #680]
    94d4:	b40002d3 	cbz	x19, 952c <fwp_main_thread+0x50c>
    94d8:	f900567f 	str	xzr, [x19, #168]
    94dc:	f9005e7f 	str	xzr, [x19, #184]
    94e0:	b902a29f 	str	wzr, [x20, #672]
    94e4:	eb00027f 	cmp	x19, x0
    94e8:	54ffea20 	b.eq	922c <fwp_main_thread+0x20c>  // b.none
    94ec:	f90083f9 	str	x25, [sp, #256]
    94f0:	97ffe014 	bl	1540 <abort@plt>
    94f4:	b0ffffc0 	adrp	x0, 2000 <buf_put+0x50>
    94f8:	91184000 	add	x0, x0, #0x610
    94fc:	940001d5 	bl	9c50 <atexit>
    9500:	17fffed9 	b	9064 <fwp_main_thread+0x44>
    9504:	97ffe49c 	bl	2774 <fwp_heap_init>
    9508:	17fffed4 	b	9058 <fwp_main_thread+0x38>
    950c:	97fff539 	bl	69f0 <f0>
    9510:	f9014e60 	str	x0, [x19, #664]
    9514:	52800021 	mov	w1, #0x1                   	// #1
    9518:	b9029661 	str	w1, [x19, #660]
    951c:	17fffefe 	b	9114 <fwp_main_thread+0xf4>
    9520:	aa0003e1 	mov	x1, x0
    9524:	f9002293 	str	x19, [x20, #64]
    9528:	17ffff14 	b	9178 <fwp_main_thread+0x158>
    952c:	b902a29f 	str	wzr, [x20, #672]
    9530:	b4fff0c0 	cbz	x0, 9348 <fwp_main_thread+0x328>
    9534:	17ffffee 	b	94ec <fwp_main_thread+0x4cc>
    9538:	b0000000 	adrp	x0, a000 <_IO_stdin_used+0x380>
    953c:	91004000 	add	x0, x0, #0x10
    9540:	a90f63f7 	stp	x23, x24, [sp, #240]
    9544:	f90083f9 	str	x25, [sp, #256]
    9548:	97ffe2f6 	bl	2120 <fwp_trap>
    954c:	f90083f9 	str	x25, [sp, #256]
    9550:	97ffdfe8 	bl	14f0 <__stack_chk_fail@plt>
    9554:	d503201f 	nop
    9558:	d503201f 	nop
    955c:	d503201f 	nop

0000000000009560 <__divti3>:
    9560:	d503245f 	bti	c
    9564:	d2800004 	mov	x4, #0x0                   	// #0
    9568:	b7f80721 	tbnz	x1, #63, 964c <__divti3+0xec>
    956c:	b6f80083 	tbz	x3, #63, 957c <__divti3+0x1c>
    9570:	eb0203e2 	negs	x2, x2
    9574:	aa2403e4 	mvn	x4, x4
    9578:	da0303e3 	ngc	x3, x3
    957c:	aa0203e6 	mov	x6, x2
    9580:	aa0003e7 	mov	x7, x0
    9584:	aa0103e5 	mov	x5, x1
    9588:	b5000583 	cbnz	x3, 9638 <__divti3+0xd8>
    958c:	eb01005f 	cmp	x2, x1
    9590:	54000e69 	b.ls	975c <__divti3+0x1fc>  // b.plast
    9594:	dac01040 	clz	x0, x2
    9598:	b40000e0 	cbz	x0, 95b4 <__divti3+0x54>
    959c:	4b0003e1 	neg	w1, w0
    95a0:	9ac020a5 	lsl	x5, x5, x0
    95a4:	9ac02046 	lsl	x6, x2, x0
    95a8:	9ac124e1 	lsr	x1, x7, x1
    95ac:	aa050025 	orr	x5, x1, x5
    95b0:	9ac020e7 	lsl	x7, x7, x0
    95b4:	d360fcc8 	lsr	x8, x6, #32
    95b8:	92407cc2 	and	x2, x6, #0xffffffff
    95bc:	9ac808a3 	udiv	x3, x5, x8
    95c0:	9b089465 	msub	x5, x3, x8, x5
    95c4:	aa0303e0 	mov	x0, x3
    95c8:	9b037c41 	mul	x1, x2, x3
    95cc:	93c780a5 	extr	x5, x5, x7, #32
    95d0:	eb05003f 	cmp	x1, x5
    95d4:	540000a9 	b.ls	95e8 <__divti3+0x88>  // b.plast
    95d8:	ab0500c5 	adds	x5, x6, x5
    95dc:	d1000460 	sub	x0, x3, #0x1
    95e0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    95e4:	540015a8 	b.hi	9898 <__divti3+0x338>  // b.pmore
    95e8:	cb0100a5 	sub	x5, x5, x1
    95ec:	9ac808a3 	udiv	x3, x5, x8
    95f0:	9b089465 	msub	x5, x3, x8, x5
    95f4:	aa0303e1 	mov	x1, x3
    95f8:	9b037c42 	mul	x2, x2, x3
    95fc:	aa0703e3 	mov	x3, x7
    9600:	b3607ca3 	bfi	x3, x5, #32, #32
    9604:	eb03005f 	cmp	x2, x3
    9608:	540000c9 	b.ls	9620 <__divti3+0xc0>  // b.plast
    960c:	ab0300c3 	adds	x3, x6, x3
    9610:	d1000425 	sub	x5, x1, #0x1
    9614:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9618:	d1000821 	sub	x1, x1, #0x2
    961c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    9620:	aa008020 	orr	x0, x1, x0, lsl #32
    9624:	d2800001 	mov	x1, #0x0                   	// #0
    9628:	b4000064 	cbz	x4, 9634 <__divti3+0xd4>
    962c:	eb0003e0 	negs	x0, x0
    9630:	da0103e1 	ngc	x1, x1
    9634:	d65f03c0 	ret
    9638:	eb01007f 	cmp	x3, x1
    963c:	54000109 	b.ls	965c <__divti3+0xfc>  // b.plast
    9640:	d2800001 	mov	x1, #0x0                   	// #0
    9644:	d2800000 	mov	x0, #0x0                   	// #0
    9648:	17fffff8 	b	9628 <__divti3+0xc8>
    964c:	eb0003e0 	negs	x0, x0
    9650:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9654:	da0103e1 	ngc	x1, x1
    9658:	17ffffc5 	b	956c <__divti3+0xc>
    965c:	dac01067 	clz	x7, x3
    9660:	b40010e7 	cbz	x7, 987c <__divti3+0x31c>
    9664:	d2800805 	mov	x5, #0x40                  	// #64
    9668:	cb0700a5 	sub	x5, x5, x7
    966c:	9ac72063 	lsl	x3, x3, x7
    9670:	9ac52448 	lsr	x8, x2, x5
    9674:	aa030108 	orr	x8, x8, x3
    9678:	9ac52426 	lsr	x6, x1, x5
    967c:	92407d0a 	and	x10, x8, #0xffffffff
    9680:	d360fd09 	lsr	x9, x8, #32
    9684:	9ac52403 	lsr	x3, x0, x5
    9688:	9ac72021 	lsl	x1, x1, x7
    968c:	aa010063 	orr	x3, x3, x1
    9690:	9ac72042 	lsl	x2, x2, x7
    9694:	9ac908cb 	udiv	x11, x6, x9
    9698:	9b099965 	msub	x5, x11, x9, x6
    969c:	aa0b03e1 	mov	x1, x11
    96a0:	9b0b7d46 	mul	x6, x10, x11
    96a4:	93c380a5 	extr	x5, x5, x3, #32
    96a8:	eb0500df 	cmp	x6, x5
    96ac:	540000a9 	b.ls	96c0 <__divti3+0x160>  // b.plast
    96b0:	ab050105 	adds	x5, x8, x5
    96b4:	d1000561 	sub	x1, x11, #0x1
    96b8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    96bc:	54000f48 	b.hi	98a4 <__divti3+0x344>  // b.pmore
    96c0:	cb0600a6 	sub	x6, x5, x6
    96c4:	9ac908cb 	udiv	x11, x6, x9
    96c8:	9b099969 	msub	x9, x11, x9, x6
    96cc:	aa0b03e5 	mov	x5, x11
    96d0:	9b0b7d4a 	mul	x10, x10, x11
    96d4:	b3607d23 	bfi	x3, x9, #32, #32
    96d8:	eb03015f 	cmp	x10, x3
    96dc:	540000a9 	b.ls	96f0 <__divti3+0x190>  // b.plast
    96e0:	ab030103 	adds	x3, x8, x3
    96e4:	d1000565 	sub	x5, x11, #0x1
    96e8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    96ec:	54000e28 	b.hi	98b0 <__divti3+0x350>  // b.pmore
    96f0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    96f4:	92407c48 	and	x8, x2, #0xffffffff
    96f8:	2a0503e5 	mov	w5, w5
    96fc:	d360fc42 	lsr	x2, x2, #32
    9700:	d360fc26 	lsr	x6, x1, #32
    9704:	cb0a0063 	sub	x3, x3, x10
    9708:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    970c:	9b087caa 	mul	x10, x5, x8
    9710:	9b087cc8 	mul	x8, x6, x8
    9714:	9b0220a5 	madd	x5, x5, x2, x8
    9718:	9b027cc6 	mul	x6, x6, x2
    971c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    9720:	8b0900c5 	add	x5, x6, x9
    9724:	eb02011f 	cmp	x8, x2
    9728:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    972c:	8b4280c6 	add	x6, x6, x2, lsr #32
    9730:	eb06007f 	cmp	x3, x6
    9734:	540000e3 	b.cc	9750 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    9738:	92407d4a 	and	x10, x10, #0xffffffff
    973c:	9ac72000 	lsl	x0, x0, x7
    9740:	8b028142 	add	x2, x10, x2, lsl #32
    9744:	eb02001f 	cmp	x0, x2
    9748:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    974c:	54000a01 	b.ne	988c <__divti3+0x32c>  // b.any
    9750:	d1000420 	sub	x0, x1, #0x1
    9754:	d2800001 	mov	x1, #0x0                   	// #0
    9758:	17ffffb4 	b	9628 <__divti3+0xc8>
    975c:	b5000062 	cbnz	x2, 9768 <__divti3+0x208>
    9760:	d2800022 	mov	x2, #0x1                   	// #1
    9764:	9ac30846 	udiv	x6, x2, x3
    9768:	dac010c8 	clz	x8, x6
    976c:	b5000408 	cbnz	x8, 97ec <__divti3+0x28c>
    9770:	d360fcc9 	lsr	x9, x6, #32
    9774:	92407cc5 	and	x5, x6, #0xffffffff
    9778:	cb060023 	sub	x3, x1, x6
    977c:	d2800021 	mov	x1, #0x1                   	// #1
    9780:	9ac90868 	udiv	x8, x3, x9
    9784:	9b098d03 	msub	x3, x8, x9, x3
    9788:	aa0803e0 	mov	x0, x8
    978c:	9b057d02 	mul	x2, x8, x5
    9790:	93c78063 	extr	x3, x3, x7, #32
    9794:	eb03005f 	cmp	x2, x3
    9798:	540000a9 	b.ls	97ac <__divti3+0x24c>  // b.plast
    979c:	ab0300c3 	adds	x3, x6, x3
    97a0:	d1000500 	sub	x0, x8, #0x1
    97a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    97a8:	54000968 	b.hi	98d4 <__divti3+0x374>  // b.pmore
    97ac:	cb020063 	sub	x3, x3, x2
    97b0:	9ac90862 	udiv	x2, x3, x9
    97b4:	aa0203e8 	mov	x8, x2
    97b8:	9b098c42 	msub	x2, x2, x9, x3
    97bc:	aa0703e3 	mov	x3, x7
    97c0:	9b057d05 	mul	x5, x8, x5
    97c4:	b3607c43 	bfi	x3, x2, #32, #32
    97c8:	eb0300bf 	cmp	x5, x3
    97cc:	540000c9 	b.ls	97e4 <__divti3+0x284>  // b.plast
    97d0:	ab0300c2 	adds	x2, x6, x3
    97d4:	d1000503 	sub	x3, x8, #0x1
    97d8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    97dc:	d1000908 	sub	x8, x8, #0x2
    97e0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    97e4:	aa008100 	orr	x0, x8, x0, lsl #32
    97e8:	17ffff90 	b	9628 <__divti3+0xc8>
    97ec:	9ac820c6 	lsl	x6, x6, x8
    97f0:	d2800803 	mov	x3, #0x40                  	// #64
    97f4:	cb080063 	sub	x3, x3, x8
    97f8:	d360fcc9 	lsr	x9, x6, #32
    97fc:	9ac82027 	lsl	x7, x1, x8
    9800:	92407cc5 	and	x5, x6, #0xffffffff
    9804:	9ac32422 	lsr	x2, x1, x3
    9808:	9ac32403 	lsr	x3, x0, x3
    980c:	aa070063 	orr	x3, x3, x7
    9810:	9ac9084a 	udiv	x10, x2, x9
    9814:	9ac82007 	lsl	x7, x0, x8
    9818:	9b098940 	msub	x0, x10, x9, x2
    981c:	aa0a03e1 	mov	x1, x10
    9820:	9b0a7ca2 	mul	x2, x5, x10
    9824:	93c38000 	extr	x0, x0, x3, #32
    9828:	eb00005f 	cmp	x2, x0
    982c:	540000a9 	b.ls	9840 <__divti3+0x2e0>  // b.plast
    9830:	ab0000c0 	adds	x0, x6, x0
    9834:	d1000541 	sub	x1, x10, #0x1
    9838:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    983c:	54000468 	b.hi	98c8 <__divti3+0x368>  // b.pmore
    9840:	cb020000 	sub	x0, x0, x2
    9844:	9ac9080a 	udiv	x10, x0, x9
    9848:	9b098140 	msub	x0, x10, x9, x0
    984c:	aa0a03e2 	mov	x2, x10
    9850:	9b0a7ca8 	mul	x8, x5, x10
    9854:	b3607c03 	bfi	x3, x0, #32, #32
    9858:	eb03011f 	cmp	x8, x3
    985c:	540000a9 	b.ls	9870 <__divti3+0x310>  // b.plast
    9860:	ab0300c3 	adds	x3, x6, x3
    9864:	d1000542 	sub	x2, x10, #0x1
    9868:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    986c:	54000288 	b.hi	98bc <__divti3+0x35c>  // b.pmore
    9870:	cb080063 	sub	x3, x3, x8
    9874:	aa018041 	orr	x1, x2, x1, lsl #32
    9878:	17ffffc2 	b	9780 <__divti3+0x220>
    987c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    9880:	d2800001 	mov	x1, #0x0                   	// #0
    9884:	9a9f87e0 	cset	x0, ls	// ls = plast
    9888:	17ffff68 	b	9628 <__divti3+0xc8>
    988c:	aa0103e0 	mov	x0, x1
    9890:	d2800001 	mov	x1, #0x0                   	// #0
    9894:	17ffff65 	b	9628 <__divti3+0xc8>
    9898:	d1000860 	sub	x0, x3, #0x2
    989c:	8b0600a5 	add	x5, x5, x6
    98a0:	17ffff52 	b	95e8 <__divti3+0x88>
    98a4:	d1000961 	sub	x1, x11, #0x2
    98a8:	8b0800a5 	add	x5, x5, x8
    98ac:	17ffff85 	b	96c0 <__divti3+0x160>
    98b0:	d1000965 	sub	x5, x11, #0x2
    98b4:	8b080063 	add	x3, x3, x8
    98b8:	17ffff8e 	b	96f0 <__divti3+0x190>
    98bc:	d1000942 	sub	x2, x10, #0x2
    98c0:	8b060063 	add	x3, x3, x6
    98c4:	17ffffeb 	b	9870 <__divti3+0x310>
    98c8:	d1000941 	sub	x1, x10, #0x2
    98cc:	8b060000 	add	x0, x0, x6
    98d0:	17ffffdc 	b	9840 <__divti3+0x2e0>
    98d4:	d1000900 	sub	x0, x8, #0x2
    98d8:	8b060063 	add	x3, x3, x6
    98dc:	17ffffb4 	b	97ac <__divti3+0x24c>

00000000000098e0 <__modti3>:
    98e0:	d503245f 	bti	c
    98e4:	d2800004 	mov	x4, #0x0                   	// #0
    98e8:	b6f80081 	tbz	x1, #63, 98f8 <__modti3+0x18>
    98ec:	eb0003e0 	negs	x0, x0
    98f0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    98f4:	da0103e1 	ngc	x1, x1
    98f8:	f100007f 	cmp	x3, #0x0
    98fc:	5400128b 	b.lt	9b4c <__modti3+0x26c>  // b.tstop
    9900:	aa0003e7 	mov	x7, x0
    9904:	aa0103e6 	mov	x6, x1
    9908:	540004e1 	b.ne	99a4 <__modti3+0xc4>  // b.any
    990c:	eb02003f 	cmp	x1, x2
    9910:	54000dc2 	b.cs	9ac8 <__modti3+0x1e8>  // b.hs, b.nlast
    9914:	dac01043 	clz	x3, x2
    9918:	aa0303e5 	mov	x5, x3
    991c:	b40000e3 	cbz	x3, 9938 <__modti3+0x58>
    9920:	4b0303e6 	neg	w6, w3
    9924:	9ac32021 	lsl	x1, x1, x3
    9928:	9ac32042 	lsl	x2, x2, x3
    992c:	9ac62406 	lsr	x6, x0, x6
    9930:	aa0100c6 	orr	x6, x6, x1
    9934:	9ac32007 	lsl	x7, x0, x3
    9938:	d360fc40 	lsr	x0, x2, #32
    993c:	92407c43 	and	x3, x2, #0xffffffff
    9940:	9ac008c1 	udiv	x1, x6, x0
    9944:	9b009826 	msub	x6, x1, x0, x6
    9948:	9b017c61 	mul	x1, x3, x1
    994c:	93c780c6 	extr	x6, x6, x7, #32
    9950:	eb06003f 	cmp	x1, x6
    9954:	540000a9 	b.ls	9968 <__modti3+0x88>  // b.plast
    9958:	ab060046 	adds	x6, x2, x6
    995c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    9960:	8b0200c8 	add	x8, x6, x2
    9964:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    9968:	cb0100c6 	sub	x6, x6, x1
    996c:	9ac008c8 	udiv	x8, x6, x0
    9970:	9b009901 	msub	x1, x8, x0, x6
    9974:	aa0703e0 	mov	x0, x7
    9978:	9b087c63 	mul	x3, x3, x8
    997c:	b3607c20 	bfi	x0, x1, #32, #32
    9980:	eb00007f 	cmp	x3, x0
    9984:	54001088 	b.hi	9b94 <__modti3+0x2b4>  // b.pmore
    9988:	cb030000 	sub	x0, x0, x3
    998c:	9ac52400 	lsr	x0, x0, x5
    9990:	d2800001 	mov	x1, #0x0                   	// #0
    9994:	b4000064 	cbz	x4, 99a0 <__modti3+0xc0>
    9998:	eb0003e0 	negs	x0, x0
    999c:	da0103e1 	ngc	x1, x1
    99a0:	d65f03c0 	ret
    99a4:	dac01066 	clz	x6, x3
    99a8:	eb03003f 	cmp	x1, x3
    99ac:	54ffff43 	b.cc	9994 <__modti3+0xb4>  // b.lo, b.ul, b.last
    99b0:	93407cc5 	sxtw	x5, w6
    99b4:	d2800808 	mov	x8, #0x40                  	// #64
    99b8:	cb050108 	sub	x8, x8, x5
    99bc:	9ac62063 	lsl	x3, x3, x6
    99c0:	9ac62025 	lsl	x5, x1, x6
    99c4:	9ac82447 	lsr	x7, x2, x8
    99c8:	aa0300e7 	orr	x7, x7, x3
    99cc:	9ac82423 	lsr	x3, x1, x8
    99d0:	92407cec 	and	x12, x7, #0xffffffff
    99d4:	d360fcea 	lsr	x10, x7, #32
    99d8:	9ac82401 	lsr	x1, x0, x8
    99dc:	aa050021 	orr	x1, x1, x5
    99e0:	9ac62042 	lsl	x2, x2, x6
    99e4:	9ac62000 	lsl	x0, x0, x6
    99e8:	9aca086b 	udiv	x11, x3, x10
    99ec:	9b0a8d63 	msub	x3, x11, x10, x3
    99f0:	aa0b03e5 	mov	x5, x11
    99f4:	9b0b7d89 	mul	x9, x12, x11
    99f8:	93c18063 	extr	x3, x3, x1, #32
    99fc:	eb03013f 	cmp	x9, x3
    9a00:	540000a9 	b.ls	9a14 <__modti3+0x134>  // b.plast
    9a04:	ab0300e3 	adds	x3, x7, x3
    9a08:	d1000565 	sub	x5, x11, #0x1
    9a0c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    9a10:	54001168 	b.hi	9c3c <__modti3+0x35c>  // b.pmore
    9a14:	cb090063 	sub	x3, x3, x9
    9a18:	9aca086b 	udiv	x11, x3, x10
    9a1c:	9b0a8d6a 	msub	x10, x11, x10, x3
    9a20:	aa0b03e9 	mov	x9, x11
    9a24:	9b0b7d8c 	mul	x12, x12, x11
    9a28:	b3607d41 	bfi	x1, x10, #32, #32
    9a2c:	eb01019f 	cmp	x12, x1
    9a30:	540000a9 	b.ls	9a44 <__modti3+0x164>  // b.plast
    9a34:	ab0100e1 	adds	x1, x7, x1
    9a38:	d1000569 	sub	x9, x11, #0x1
    9a3c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    9a40:	54000f88 	b.hi	9c30 <__modti3+0x350>  // b.pmore
    9a44:	aa058123 	orr	x3, x9, x5, lsl #32
    9a48:	92407c4b 	and	x11, x2, #0xffffffff
    9a4c:	2a0903e9 	mov	w9, w9
    9a50:	d360fc4a 	lsr	x10, x2, #32
    9a54:	d360fc63 	lsr	x3, x3, #32
    9a58:	cb0c0021 	sub	x1, x1, x12
    9a5c:	aa0a03ec 	mov	x12, x10
    9a60:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    9a64:	9b0b7d25 	mul	x5, x9, x11
    9a68:	9b0b7c6b 	mul	x11, x3, x11
    9a6c:	9b0a2d29 	madd	x9, x9, x10, x11
    9a70:	92407caa 	and	x10, x5, #0xffffffff
    9a74:	9b0c7c63 	mul	x3, x3, x12
    9a78:	8b458125 	add	x5, x9, x5, lsr #32
    9a7c:	8b0d0069 	add	x9, x3, x13
    9a80:	eb05017f 	cmp	x11, x5
    9a84:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    9a88:	8b058149 	add	x9, x10, x5, lsl #32
    9a8c:	8b458063 	add	x3, x3, x5, lsr #32
    9a90:	eb03003f 	cmp	x1, x3
    9a94:	54000063 	b.cc	9aa0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    9a98:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    9a9c:	54000082 	b.cs	9aac <__modti3+0x1cc>  // b.hs, b.nlast
    9aa0:	eb020129 	subs	x9, x9, x2
    9aa4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    9aa8:	cb070063 	sub	x3, x3, x7
    9aac:	eb090000 	subs	x0, x0, x9
    9ab0:	da030021 	sbc	x1, x1, x3
    9ab4:	9ac62400 	lsr	x0, x0, x6
    9ab8:	9ac82028 	lsl	x8, x1, x8
    9abc:	aa000100 	orr	x0, x8, x0
    9ac0:	9ac62421 	lsr	x1, x1, x6
    9ac4:	17ffffb4 	b	9994 <__modti3+0xb4>
    9ac8:	b5000062 	cbnz	x2, 9ad4 <__modti3+0x1f4>
    9acc:	d2800023 	mov	x3, #0x1                   	// #1
    9ad0:	9ac20862 	udiv	x2, x3, x2
    9ad4:	dac01048 	clz	x8, x2
    9ad8:	aa0803e5 	mov	x5, x8
    9adc:	b5000668 	cbnz	x8, 9ba8 <__modti3+0x2c8>
    9ae0:	cb020020 	sub	x0, x1, x2
    9ae4:	d360fc49 	lsr	x9, x2, #32
    9ae8:	92407c4a 	and	x10, x2, #0xffffffff
    9aec:	9ac90801 	udiv	x1, x0, x9
    9af0:	9b098020 	msub	x0, x1, x9, x0
    9af4:	9b0a7c21 	mul	x1, x1, x10
    9af8:	93c78000 	extr	x0, x0, x7, #32
    9afc:	eb00003f 	cmp	x1, x0
    9b00:	540000a9 	b.ls	9b14 <__modti3+0x234>  // b.plast
    9b04:	ab000040 	adds	x0, x2, x0
    9b08:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9b0c:	8b020003 	add	x3, x0, x2
    9b10:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9b14:	cb010001 	sub	x1, x0, x1
    9b18:	9ac90820 	udiv	x0, x1, x9
    9b1c:	9b098403 	msub	x3, x0, x9, x1
    9b20:	aa0703e1 	mov	x1, x7
    9b24:	9b0a7c00 	mul	x0, x0, x10
    9b28:	b3607c61 	bfi	x1, x3, #32, #32
    9b2c:	eb01001f 	cmp	x0, x1
    9b30:	540000a9 	b.ls	9b44 <__modti3+0x264>  // b.plast
    9b34:	ab010041 	adds	x1, x2, x1
    9b38:	8b020022 	add	x2, x1, x2
    9b3c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9b40:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9b44:	cb000020 	sub	x0, x1, x0
    9b48:	17ffff91 	b	998c <__modti3+0xac>
    9b4c:	eb0203e5 	negs	x5, x2
    9b50:	aa0003e7 	mov	x7, x0
    9b54:	da0303e8 	ngc	x8, x3
    9b58:	aa0503e2 	mov	x2, x5
    9b5c:	aa0803e3 	mov	x3, x8
    9b60:	aa0103e6 	mov	x6, x1
    9b64:	b4ffed48 	cbz	x8, 990c <__modti3+0x2c>
    9b68:	eb01011f 	cmp	x8, x1
    9b6c:	54fff148 	b.hi	9994 <__modti3+0xb4>  // b.pmore
    9b70:	dac01109 	clz	x9, x8
    9b74:	2a0903e6 	mov	w6, w9
    9b78:	b5fff1c9 	cbnz	x9, 99b0 <__modti3+0xd0>
    9b7c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9b80:	54000068 	b.hi	9b8c <__modti3+0x2ac>  // b.pmore
    9b84:	eb050007 	subs	x7, x0, x5
    9b88:	da080021 	sbc	x1, x1, x8
    9b8c:	aa0703e0 	mov	x0, x7
    9b90:	17ffff81 	b	9994 <__modti3+0xb4>
    9b94:	ab000040 	adds	x0, x2, x0
    9b98:	8b020002 	add	x2, x0, x2
    9b9c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    9ba0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    9ba4:	17ffff79 	b	9988 <__modti3+0xa8>
    9ba8:	9ac82042 	lsl	x2, x2, x8
    9bac:	d2800803 	mov	x3, #0x40                  	// #64
    9bb0:	cb080063 	sub	x3, x3, x8
    9bb4:	d360fc49 	lsr	x9, x2, #32
    9bb8:	9ac82027 	lsl	x7, x1, x8
    9bbc:	92407c4a 	and	x10, x2, #0xffffffff
    9bc0:	9ac32426 	lsr	x6, x1, x3
    9bc4:	9ac32403 	lsr	x3, x0, x3
    9bc8:	aa070063 	orr	x3, x3, x7
    9bcc:	9ac908c1 	udiv	x1, x6, x9
    9bd0:	9ac82007 	lsl	x7, x0, x8
    9bd4:	9b099820 	msub	x0, x1, x9, x6
    9bd8:	9b017d41 	mul	x1, x10, x1
    9bdc:	93c38000 	extr	x0, x0, x3, #32
    9be0:	eb00003f 	cmp	x1, x0
    9be4:	540000a9 	b.ls	9bf8 <__modti3+0x318>  // b.plast
    9be8:	ab000040 	adds	x0, x2, x0
    9bec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9bf0:	8b020006 	add	x6, x0, x2
    9bf4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    9bf8:	cb010000 	sub	x0, x0, x1
    9bfc:	9ac90801 	udiv	x1, x0, x9
    9c00:	9b098026 	msub	x6, x1, x9, x0
    9c04:	aa0303e0 	mov	x0, x3
    9c08:	9b017d41 	mul	x1, x10, x1
    9c0c:	b3607cc0 	bfi	x0, x6, #32, #32
    9c10:	eb00003f 	cmp	x1, x0
    9c14:	540000a9 	b.ls	9c28 <__modti3+0x348>  // b.plast
    9c18:	ab000040 	adds	x0, x2, x0
    9c1c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9c20:	8b020003 	add	x3, x0, x2
    9c24:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9c28:	cb010000 	sub	x0, x0, x1
    9c2c:	17ffffb0 	b	9aec <__modti3+0x20c>
    9c30:	d1000969 	sub	x9, x11, #0x2
    9c34:	8b070021 	add	x1, x1, x7
    9c38:	17ffff83 	b	9a44 <__modti3+0x164>
    9c3c:	d1000965 	sub	x5, x11, #0x2
    9c40:	8b070063 	add	x3, x3, x7
    9c44:	17ffff74 	b	9a14 <__modti3+0x134>
    9c48:	d503201f 	nop
    9c4c:	d503201f 	nop

0000000000009c50 <atexit>:
    9c50:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9c54:	f00000a2 	adrp	x2, 20000 <__data_start>
    9c58:	d2800001 	mov	x1, #0x0                   	// #0
    9c5c:	910003fd 	mov	x29, sp
    9c60:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9c64:	f9400442 	ldr	x2, [x2, #8]
    9c68:	17ffdde2 	b	13f0 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000009c6c <_fini>:
    9c6c:	d503201f 	nop
    9c70:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9c74:	910003fd 	mov	x29, sp
    9c78:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9c7c:	d65f03c0 	ret
