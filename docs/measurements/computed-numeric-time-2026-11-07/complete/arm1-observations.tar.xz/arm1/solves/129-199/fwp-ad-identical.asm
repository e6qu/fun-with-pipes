
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-ad-identical:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002620 <_init>:
    2620:	d503201f 	nop
    2624:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2628:	910003fd 	mov	x29, sp
    262c:	940001a2 	bl	2cb4 <call_weak_fn>
    2630:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2634:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2648:	f946fe11 	ldr	x17, [x16, #3576]
    264c:	9137e210 	add	x16, x16, #0xdf8
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <_exit@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <strlen@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <exit@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <__libc_start_main@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtoll@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtod@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_finalize@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_atexit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <pthread_attr_init@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <fputc@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <clock_gettime@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <setvbuf@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <__memcpy_chk@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <signal@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <__snprintf_chk@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fclose@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <fopen@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <malloc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_destroy@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <sigemptyset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <memset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <calloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <realloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <__stack_chk_fail@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <close@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <sigaction@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <__gmon_start__@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <write@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <abort@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <swapcontext@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <__fprintf_chk@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <strcmp@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <mmap@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtol@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtof@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <free@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <nanosleep@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strchr@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <strtoull@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <fwrite@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <pthread_create@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <munmap@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <fflush@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <strcpy@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <sysconf@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <strstr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <_Exit@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <pthread_join@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <getenv@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	f0000045 	adrp	x5, d000 <__modti3+0x2c0>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	910ea0a5 	add	x5, x5, #0x3a8
    2a20:	f0000044 	adrp	x4, d000 <__modti3+0x2c0>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	910ec084 	add	x4, x4, #0x3b0
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4a 	bl	2770 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940004ec 	bl	3e00 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc88>
    2a7c:	f947ee94 	ldr	x20, [x20, #4056]
    2a80:	f9400282 	ldr	x2, [x20]
    2a84:	f90043f5 	str	x21, [sp, #128]
    2a88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2a8c:	9100c2a1 	add	x1, x21, #0x30
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xee98>
    2aa0:	910de000 	add	x0, x0, #0x378
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9003420 	str	x0, [x1, #104]
    2aac:	940006f5 	bl	4680 <fwp_now_ns>
    2ab0:	f0000040 	adrp	x0, d000 <__modti3+0x2c0>
    2ab4:	911b0000 	add	x0, x0, #0x6c0
    2ab8:	97ffffb6 	bl	2990 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f3 	mov	x19, x0
    2ac8:	350008c1 	cbnz	w1, 2be0 <main+0x180>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff17 	bl	2730 <clock_gettime@plt>
    2ad8:	350007e0 	cbnz	w0, 2bd4 <main+0x174>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b5000620 	cbnz	x0, 2bc8 <main+0x168>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f3 	add	x19, sp, #0x18
    2b1c:	97ffff09 	bl	2740 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0e 	bl	2760 <signal@plt>
    2b2c:	aa1303e0 	mov	x0, x19
    2b30:	97fffef8 	bl	2710 <pthread_attr_init@plt>
    2b34:	350007a0 	cbnz	w0, 2c28 <main+0x1c8>
    2b38:	aa1303e0 	mov	x0, x19
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000660 	cbnz	w0, 2c10 <main+0x1b0>
    2b48:	aa1303e1 	mov	x1, x19
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000042 	adrp	x2, c000 <f0+0x21dc>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91129042 	add	x2, x2, #0x4a4
    2b5c:	97ffff6d 	bl	2910 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1303e0 	mov	x0, x19
    2b68:	2a0103f3 	mov	w19, w1
    2b6c:	97ffff11 	bl	27b0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	35000613 	cbnz	w19, 2c34 <main+0x1d4>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff80 	bl	2980 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	9100c2b5 	add	x21, x21, #0x30
    2b90:	97ffff68 	bl	2930 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b942faa0 	ldr	w0, [x21, #760]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	54000481 	b.ne	2c40 <main+0x1e0>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	f0000040 	adrp	x0, d000 <__modti3+0x2c0>
    2bcc:	911bc000 	add	x0, x0, #0x6f0
    2bd0:	9400048c 	bl	3e00 <fwp_trap>
    2bd4:	f0000040 	adrp	x0, d000 <__modti3+0x2c0>
    2bd8:	911b4000 	add	x0, x0, #0x6d0
    2bdc:	94000489 	bl	3e00 <fwp_trap>
    2be0:	910003e1 	mov	x1, sp
    2be4:	52800142 	mov	w2, #0xa                   	// #10
    2be8:	97ffff42 	bl	28f0 <strtoull@plt>
    2bec:	f94003e0 	ldr	x0, [sp]
    2bf0:	39400000 	ldrb	w0, [x0]
    2bf4:	35fff6c0 	cbnz	w0, 2acc <main+0x6c>
    2bf8:	39400260 	ldrb	w0, [x19]
    2bfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c00:	5100ac00 	sub	w0, w0, #0x2b
    2c04:	6a01001f 	tst	w0, w1
    2c08:	54fff620 	b.eq	2acc <main+0x6c>  // b.none
    2c0c:	17ffffbf 	b	2b08 <main+0xa8>
    2c10:	aa1303e0 	mov	x0, x19
    2c14:	97fffee7 	bl	27b0 <pthread_attr_destroy@plt>
    2c18:	35000160 	cbnz	w0, 2c44 <main+0x1e4>
    2c1c:	f0000040 	adrp	x0, d000 <__modti3+0x2c0>
    2c20:	911d2000 	add	x0, x0, #0x748
    2c24:	94000477 	bl	3e00 <fwp_trap>
    2c28:	f0000040 	adrp	x0, d000 <__modti3+0x2c0>
    2c2c:	911c6000 	add	x0, x0, #0x718
    2c30:	94000474 	bl	3e00 <fwp_trap>
    2c34:	f0000040 	adrp	x0, d000 <__modti3+0x2c0>
    2c38:	911dc000 	add	x0, x0, #0x770
    2c3c:	94000471 	bl	3e00 <fwp_trap>
    2c40:	97fffef0 	bl	2800 <__stack_chk_fail@plt>
    2c44:	97ffff03 	bl	2850 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe85 	bl	26c0 <__libc_start_main@plt>
    2cb0:	97fffee8 	bl	2850 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffedc 	b	2830 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91008000 	add	x0, x0, #0x20
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91008021 	add	x1, x1, #0x20
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91008000 	add	x0, x0, #0x20
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91008021 	add	x1, x1, #0x20
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39408260 	ldrb	w0, [x19, #32]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe60 	bl	26f0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39008260 	strb	w0, [x19, #32]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	f0000041 	adrp	x1, d000 <__modti3+0x2c0>
    2e34:	91364021 	add	x1, x1, #0xd90
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe4d 	bl	2800 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402003 	ldr	x3, [x0, #64]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	29490402 	ldp	w2, w1, [x0, #72]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800b03 	mov	w3, #0x58                  	// #88
    2f28:	f9401884 	ldr	x4, [x4, #48]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9004c61 	str	w1, [x3, #76]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800b04 	mov	w4, #0x58                  	// #88
    2f40:	f9401863 	ldr	x3, [x3, #48]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9004822 	str	w2, [x1, #72]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900201f 	str	xzr, [x0, #64]
    2f54:	fd002400 	str	d0, [x0, #72]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args173>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9401c00 	ldr	x0, [x0, #56]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe6b 	bl	2930 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe66 	b	2930 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe62 	b	2930 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	f0000040 	adrp	x0, d000 <__modti3+0x2c0>
    2fd0:	9103a000 	add	x0, x0, #0xe8
    2fd4:	97fffe4b 	bl	2900 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe55 	bl	2930 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe63 	bl	2970 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	9100c043 	add	x3, x2, #0x30
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe4b 	bl	2950 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdc0 	b	2760 <signal@plt>
    3064:	9100c042 	add	x2, x2, #0x30
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	d0000041 	adrp	x1, d000 <__modti3+0x2c0>
    3098:	9135c021 	add	x1, x1, #0xd70
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde7 	bl	2840 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd75 	bl	2680 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    30c4:	9114c2a1 	add	x1, x21, #0x530
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xad0>
    30d8:	912480a5 	add	x5, x5, #0x920
    30dc:	9114c2a1 	add	x1, x21, #0x530
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	9114c2b7 	add	x23, x21, #0x530
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffded 	bl	2950 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	9114c2b5 	add	x21, x21, #0x530
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	9114c2b5 	add	x21, x21, #0x530
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xad0>
    3268:	912460a5 	add	x5, x5, #0x918
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd8b 	bl	28c0 <free@plt>
    3298:	f9400660 	ldr	x0, [x19, #8]
    329c:	97fffd89 	bl	28c0 <free@plt>
    32a0:	f9400a60 	ldr	x0, [x19, #16]
    32a4:	97fffd87 	bl	28c0 <free@plt>
    32a8:	a9007e7f 	stp	xzr, xzr, [x19]
    32ac:	a9017e7f 	stp	xzr, xzr, [x19, #16]
    32b0:	f900127f 	str	xzr, [x19, #32]
    32b4:	f9400bf3 	ldr	x19, [sp, #16]
    32b8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32bc:	d65f03c0 	ret

00000000000032c0 <buf_grow>:
    32c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c4:	910003fd 	mov	x29, sp
    32c8:	a90153f3 	stp	x19, x20, [sp, #16]
    32cc:	aa0003f4 	mov	x20, x0
    32d0:	f9400400 	ldr	x0, [x0, #8]
    32d4:	b100041f 	cmn	x0, #0x1
    32d8:	54000400 	b.eq	3358 <buf_grow+0x98>  // b.none
    32dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e0:	cb000042 	sub	x2, x2, x0
    32e4:	eb01005f 	cmp	x2, x1
    32e8:	54000383 	b.cc	3358 <buf_grow+0x98>  // b.lo, b.ul, b.last
    32ec:	f9400a82 	ldr	x2, [x20, #16]
    32f0:	91000421 	add	x1, x1, #0x1
    32f4:	8b000033 	add	x19, x1, x0
    32f8:	eb13005f 	cmp	x2, x19
    32fc:	54000242 	b.cs	3344 <buf_grow+0x84>  // b.hs, b.nlast
    3300:	f100005f 	cmp	x2, #0x0
    3304:	b5000262 	cbnz	x2, 3350 <buf_grow+0x90>
    3308:	d2800802 	mov	x2, #0x40                  	// #64
    330c:	eb02027f 	cmp	x19, x2
    3310:	54000068 	b.hi	331c <buf_grow+0x5c>  // b.pmore
    3314:	14000005 	b	3328 <buf_grow+0x68>
    3318:	b7f800a2 	tbnz	x2, #63, 332c <buf_grow+0x6c>
    331c:	d37ff842 	lsl	x2, x2, #1
    3320:	eb02027f 	cmp	x19, x2
    3324:	54ffffa8 	b.hi	3318 <buf_grow+0x58>  // b.pmore
    3328:	aa0203f3 	mov	x19, x2
    332c:	f9400280 	ldr	x0, [x20]
    3330:	aa1303e1 	mov	x1, x19
    3334:	97fffd2f 	bl	27f0 <realloc@plt>
    3338:	b4000100 	cbz	x0, 3358 <buf_grow+0x98>
    333c:	f9000280 	str	x0, [x20]
    3340:	f9000a93 	str	x19, [x20, #16]
    3344:	a94153f3 	ldp	x19, x20, [sp, #16]
    3348:	a8c27bfd 	ldp	x29, x30, [sp], #32
    334c:	d65f03c0 	ret
    3350:	54fffe6a 	b.ge	331c <buf_grow+0x5c>  // b.tcont
    3354:	17fffff6 	b	332c <buf_grow+0x6c>
    3358:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    335c:	f947e863 	ldr	x3, [x3, #4048]
    3360:	d2800262 	mov	x2, #0x13                  	// #19
    3364:	d2800021 	mov	x1, #0x1                   	// #1
    3368:	d0000040 	adrp	x0, d000 <__modti3+0x2c0>
    336c:	9103a000 	add	x0, x0, #0xe8
    3370:	f9400063 	ldr	x3, [x3]
    3374:	97fffd63 	bl	2900 <fwrite@plt>
    3378:	d2800000 	mov	x0, #0x0                   	// #0
    337c:	97fffd6d 	bl	2930 <fflush@plt>
    3380:	52800cc0 	mov	w0, #0x66                  	// #102
    3384:	97fffd7b 	bl	2970 <_Exit@plt>
    3388:	d503201f 	nop
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc4 	bl	32c0 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffca7 	bl	2660 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	9100c022 	add	x2, x1, #0x30
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	9100c021 	add	x1, x1, #0x30
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd16 	bl	28e0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0f 	bl	28e0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	d0000041 	adrp	x1, d000 <__modti3+0x2c0>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	91040021 	add	x1, x1, #0x100
    34b8:	97fffd2a 	bl	2960 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	d0000041 	adrp	x1, d000 <__modti3+0x2c0>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	91042021 	add	x1, x1, #0x108
    34cc:	97fffd25 	bl	2960 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6e 	bl	2690 <strlen@plt>
    34dc:	d0000041 	adrp	x1, d000 <__modti3+0x2c0>
    34e0:	91044021 	add	x1, x1, #0x110
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_format_g.constprop.0>:
    3500:	d10483ff 	sub	sp, sp, #0x120
    3504:	d0000044 	adrp	x4, d000 <__modti3+0x2c0>
    3508:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    350c:	f947f442 	ldr	x2, [x2, #4072]
    3510:	91046084 	add	x4, x4, #0x118
    3514:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3518:	9102c3fd 	add	x29, sp, #0xb0
    351c:	d2800803 	mov	x3, #0x40                  	// #64
    3520:	a90e63f7 	stp	x23, x24, [sp, #224]
    3524:	93407c38 	sxtw	x24, w1
    3528:	aa0303e1 	mov	x1, x3
    352c:	fd008be8 	str	d8, [sp, #272]
    3530:	1e604008 	fmov	d8, d0
    3534:	a90c53f3 	stp	x19, x20, [sp, #192]
    3538:	910083f4 	add	x20, sp, #0x20
    353c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3540:	aa0003f5 	mov	x21, x0
    3544:	a91073fb 	stp	x27, x28, [sp, #256]
    3548:	5100071c 	sub	w28, w24, #0x1
    354c:	2a1c03e5 	mov	w5, w28
    3550:	f9400040 	ldr	x0, [x2]
    3554:	f90057e0 	str	x0, [sp, #168]
    3558:	d2800000 	mov	x0, #0x0                   	// #0
    355c:	52800042 	mov	w2, #0x2                   	// #2
    3560:	aa1403e0 	mov	x0, x20
    3564:	97fffc83 	bl	2770 <__snprintf_chk@plt>
    3568:	52800ca1 	mov	w1, #0x65                  	// #101
    356c:	aa1403e0 	mov	x0, x20
    3570:	97fffcdc 	bl	28e0 <strchr@plt>
    3574:	aa0003f3 	mov	x19, x0
    3578:	52800142 	mov	w2, #0xa                   	// #10
    357c:	91000400 	add	x0, x0, #0x1
    3580:	d2800001 	mov	x1, #0x0                   	// #0
    3584:	97fffcc7 	bl	28a0 <strtol@plt>
    3588:	aa0003f7 	mov	x23, x0
    358c:	11001400 	add	w0, w0, #0x5
    3590:	7100541f 	cmp	w0, #0x15
    3594:	54000d68 	b.hi	3740 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3598:	4b170385 	sub	w5, w28, w23
    359c:	710000bf 	cmp	w5, #0x0
    35a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    35a4:	54000b80 	b.eq	3714 <fwp_format_g.constprop.0+0x214>  // b.none
    35a8:	394083e0 	ldrb	w0, [sp, #32]
    35ac:	cb180273 	sub	x19, x19, x24
    35b0:	91000673 	add	x19, x19, #0x1
    35b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    35b8:	7100b41f 	cmp	w0, #0x2d
    35bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    35c0:	1a9f17e4 	cset	w4, eq	// eq = none
    35c4:	cb010266 	sub	x6, x19, x1
    35c8:	d10004da 	sub	x26, x6, #0x1
    35cc:	540018a0 	b.eq	38e0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    35d0:	910183f9 	add	x25, sp, #0x60
    35d4:	d280091b 	mov	x27, #0x48                  	// #72
    35d8:	aa1903e7 	mov	x7, x25
    35dc:	91000423 	add	x3, x1, #0x1
    35e0:	91011cc6 	add	x6, x6, #0x47
    35e4:	910004f6 	add	x22, x7, #0x1
    35e8:	37f80ff7 	tbnz	w23, #31, 37e4 <fwp_format_g.constprop.0+0x2e4>
    35ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    35f0:	93407ef7 	sxtw	x23, w23
    35f4:	390000e4 	strb	w4, [x7]
    35f8:	aa1303e1 	mov	x1, x19
    35fc:	aa1703e2 	mov	x2, x23
    3600:	aa1603e0 	mov	x0, x22
    3604:	b9000be5 	str	w5, [sp, #8]
    3608:	cb170374 	sub	x20, x27, x23
    360c:	a9011be3 	stp	x3, x6, [sp, #16]
    3610:	97fffc14 	bl	2660 <memcpy@plt>
    3614:	d1000694 	sub	x20, x20, #0x1
    3618:	f9400be3 	ldr	x3, [sp, #16]
    361c:	8b1702d6 	add	x22, x22, x23
    3620:	aa1603e0 	mov	x0, x22
    3624:	aa1a03e2 	mov	x2, x26
    3628:	aa0303e1 	mov	x1, x3
    362c:	aa1403e3 	mov	x3, x20
    3630:	97fffc48 	bl	2750 <__memcpy_chk@plt>
    3634:	8b1a02d6 	add	x22, x22, x26
    3638:	f9400fe6 	ldr	x6, [sp, #24]
    363c:	d2800900 	mov	x0, #0x48                  	// #72
    3640:	b9400be5 	ldr	w5, [sp, #8]
    3644:	8b170261 	add	x1, x19, x23
    3648:	cb1400c3 	sub	x3, x6, x20
    364c:	cb060294 	sub	x20, x20, x6
    3650:	f101207f 	cmp	x3, #0x48
    3654:	93407cb8 	sxtw	x24, w5
    3658:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    365c:	aa1803e2 	mov	x2, x24
    3660:	8b1802d3 	add	x19, x22, x24
    3664:	8b140063 	add	x3, x3, x20
    3668:	aa1603e0 	mov	x0, x22
    366c:	97fffc39 	bl	2750 <__memcpy_chk@plt>
    3670:	cb190273 	sub	x19, x19, x25
    3674:	d28031e0 	mov	x0, #0x18f                 	// #399
    3678:	eb00027f 	cmp	x19, x0
    367c:	aa1903e1 	mov	x1, x25
    3680:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3684:	aa1503e0 	mov	x0, x21
    3688:	aa1303e2 	mov	x2, x19
    368c:	97fffbf5 	bl	2660 <memcpy@plt>
    3690:	38336abf 	strb	wzr, [x21, x19]
    3694:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3698:	aa1503e0 	mov	x0, x21
    369c:	97fffbfd 	bl	2690 <strlen@plt>
    36a0:	aa0003f3 	mov	x19, x0
    36a4:	528005c1 	mov	w1, #0x2e                  	// #46
    36a8:	aa1503e0 	mov	x0, x21
    36ac:	97fffc8d 	bl	28e0 <strchr@plt>
    36b0:	b4000140 	cbz	x0, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b4:	b4000133 	cbz	x19, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b8:	aa1303e1 	mov	x1, x19
    36bc:	d1000673 	sub	x19, x19, #0x1
    36c0:	38736aa0 	ldrb	w0, [x21, x19]
    36c4:	7100c01f 	cmp	w0, #0x30
    36c8:	54001001 	b.ne	38c8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    36cc:	38336abf 	strb	wzr, [x21, x19]
    36d0:	b5ffff53 	cbnz	x19, 36b8 <fwp_format_g.constprop.0+0x1b8>
    36d4:	d503201f 	nop
    36d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    36dc:	f947f400 	ldr	x0, [x0, #4072]
    36e0:	f94057e2 	ldr	x2, [sp, #168]
    36e4:	f9400001 	ldr	x1, [x0]
    36e8:	eb010042 	subs	x2, x2, x1
    36ec:	d2800001 	mov	x1, #0x0                   	// #0
    36f0:	54001061 	b.ne	38fc <fwp_format_g.constprop.0+0x3fc>  // b.any
    36f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    36f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    36fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3700:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3704:	a95073fb 	ldp	x27, x28, [sp, #256]
    3708:	fd408be8 	ldr	d8, [sp, #272]
    370c:	910483ff 	add	sp, sp, #0x120
    3710:	d65f03c0 	ret
    3714:	1e604100 	fmov	d0, d8
    3718:	710000bf 	cmp	w5, #0x0
    371c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3720:	aa1503e0 	mov	x0, x21
    3724:	d0000044 	adrp	x4, d000 <__modti3+0x2c0>
    3728:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    372c:	9104c084 	add	x4, x4, #0x130
    3730:	52800042 	mov	w2, #0x2                   	// #2
    3734:	d2803201 	mov	x1, #0x190                 	// #400
    3738:	97fffc0e 	bl	2770 <__snprintf_chk@plt>
    373c:	17ffffd7 	b	3698 <fwp_format_g.constprop.0+0x198>
    3740:	cb140273 	sub	x19, x19, x20
    3744:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3748:	910183f9 	add	x25, sp, #0x60
    374c:	aa1303e2 	mov	x2, x19
    3750:	aa1403e1 	mov	x1, x20
    3754:	aa1903e0 	mov	x0, x25
    3758:	d2800803 	mov	x3, #0x40                  	// #64
    375c:	97fffbfd 	bl	2750 <__memcpy_chk@plt>
    3760:	38336b3f 	strb	wzr, [x25, x19]
    3764:	aa1903e0 	mov	x0, x25
    3768:	528005c1 	mov	w1, #0x2e                  	// #46
    376c:	97fffc5d 	bl	28e0 <strchr@plt>
    3770:	b40001c0 	cbz	x0, 37a8 <fwp_format_g.constprop.0+0x2a8>
    3774:	b50000b3 	cbnz	x19, 3788 <fwp_format_g.constprop.0+0x288>
    3778:	1400000c 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    377c:	381ff01f 	sturb	wzr, [x0, #-1]
    3780:	f1000673 	subs	x19, x19, #0x1
    3784:	54000120 	b.eq	37a8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3788:	8b130320 	add	x0, x25, x19
    378c:	385ff001 	ldurb	w1, [x0, #-1]
    3790:	7100c03f 	cmp	w1, #0x30
    3794:	54ffff40 	b.eq	377c <fwp_format_g.constprop.0+0x27c>  // b.none
    3798:	d1000673 	sub	x19, x19, #0x1
    379c:	38736b20 	ldrb	w0, [x25, x19]
    37a0:	7100b81f 	cmp	w0, #0x2e
    37a4:	54000a80 	b.eq	38f4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    37a8:	710002ff 	cmp	w23, #0x0
    37ac:	528005a1 	mov	w1, #0x2d                  	// #45
    37b0:	aa1903e5 	mov	x5, x25
    37b4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    37b8:	aa1503e0 	mov	x0, x21
    37bc:	52800566 	mov	w6, #0x2b                  	// #43
    37c0:	d0000044 	adrp	x4, d000 <__modti3+0x2c0>
    37c4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    37c8:	91048084 	add	x4, x4, #0x120
    37cc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    37d0:	52800042 	mov	w2, #0x2                   	// #2
    37d4:	d2803201 	mov	x1, #0x190                 	// #400
    37d8:	97fffbe6 	bl	2770 <__snprintf_chk@plt>
    37dc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    37e0:	17ffffbe 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    37e4:	52800605 	mov	w5, #0x30                  	// #48
    37e8:	390000e5 	strb	w5, [x7]
    37ec:	d100077b 	sub	x27, x27, #0x1
    37f0:	aa0303e1 	mov	x1, x3
    37f4:	aa1603e0 	mov	x0, x22
    37f8:	aa1b03e3 	mov	x3, x27
    37fc:	aa1a03e2 	mov	x2, x26
    3800:	f90007e6 	str	x6, [sp, #8]
    3804:	b90013e4 	str	w4, [sp, #16]
    3808:	8b1a02d6 	add	x22, x22, x26
    380c:	b9001be5 	str	w5, [sp, #24]
    3810:	97fffbd0 	bl	2750 <__memcpy_chk@plt>
    3814:	f94007e6 	ldr	x6, [sp, #8]
    3818:	2a3703e7 	mvn	w7, w23
    381c:	b94013e4 	ldr	w4, [sp, #16]
    3820:	cb1b00c1 	sub	x1, x6, x27
    3824:	cb06037b 	sub	x27, x27, x6
    3828:	f101203f 	cmp	x1, #0x48
    382c:	d2800906 	mov	x6, #0x48                  	// #72
    3830:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3834:	8b1b0023 	add	x3, x1, x27
    3838:	310006ff 	cmn	w23, #0x1
    383c:	54000220 	b.eq	3880 <fwp_format_g.constprop.0+0x380>  // b.none
    3840:	b9401be5 	ldr	w5, [sp, #24]
    3844:	d2800001 	mov	x1, #0x0                   	// #0
    3848:	f101207f 	cmp	x3, #0x48
    384c:	d1000462 	sub	x2, x3, #0x1
    3850:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3854:	38216ac5 	strb	w5, [x22, x1]
    3858:	cb030003 	sub	x3, x0, x3
    385c:	91000421 	add	x1, x1, #0x1
    3860:	91000463 	add	x3, x3, #0x1
    3864:	eb00007f 	cmp	x3, x0
    3868:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    386c:	cb000063 	sub	x3, x3, x0
    3870:	8b020063 	add	x3, x3, x2
    3874:	6b0100ff 	cmp	w7, w1
    3878:	54fffe8c 	b.gt	3848 <fwp_format_g.constprop.0+0x348>
    387c:	8b2742d6 	add	x22, x22, w7, uxtw
    3880:	f101207f 	cmp	x3, #0x48
    3884:	d2800905 	mov	x5, #0x48                  	// #72
    3888:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    388c:	aa1603e0 	mov	x0, x22
    3890:	cb0300a1 	sub	x1, x5, x3
    3894:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3898:	91000421 	add	x1, x1, #0x1
    389c:	d1000463 	sub	x3, x3, #0x1
    38a0:	eb05003f 	cmp	x1, x5
    38a4:	38001402 	strb	w2, [x0], #1
    38a8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    38ac:	93407f82 	sxtw	x2, w28
    38b0:	cb050025 	sub	x5, x1, x5
    38b4:	aa1303e1 	mov	x1, x19
    38b8:	8b0300a3 	add	x3, x5, x3
    38bc:	8b1802d3 	add	x19, x22, x24
    38c0:	97fffba4 	bl	2750 <__memcpy_chk@plt>
    38c4:	17ffff6b 	b	3670 <fwp_format_g.constprop.0+0x170>
    38c8:	d1000421 	sub	x1, x1, #0x1
    38cc:	38616aa0 	ldrb	w0, [x21, x1]
    38d0:	7100b81f 	cmp	w0, #0x2e
    38d4:	54fff021 	b.ne	36d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    38d8:	38216abf 	strb	wzr, [x21, x1]
    38dc:	17ffff7f 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    38e0:	910187e7 	add	x7, sp, #0x61
    38e4:	910183f9 	add	x25, sp, #0x60
    38e8:	d28008fb 	mov	x27, #0x47                  	// #71
    38ec:	390183e0 	strb	w0, [sp, #96]
    38f0:	17ffff3b 	b	35dc <fwp_format_g.constprop.0+0xdc>
    38f4:	38336b3f 	strb	wzr, [x25, x19]
    38f8:	17ffffac 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    38fc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3900:	97fffbc0 	bl	2800 <__stack_chk_fail@plt>

0000000000003904 <fwp_heap_report>:
    3904:	d105c3ff 	sub	sp, sp, #0x170
    3908:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    390c:	9114c042 	add	x2, x2, #0x530
    3910:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    3914:	f947e821 	ldr	x1, [x1, #4048]
    3918:	a9117bfd 	stp	x29, x30, [sp, #272]
    391c:	910443fd 	add	x29, sp, #0x110
    3920:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3924:	f947f400 	ldr	x0, [x0, #4072]
    3928:	a9135bf5 	stp	x21, x22, [sp, #304]
    392c:	a91463f7 	stp	x23, x24, [sp, #320]
    3930:	a9156bf9 	stp	x25, x26, [sp, #336]
    3934:	6d1627e8 	stp	d8, d9, [sp, #352]
    3938:	fd4a1c48 	ldr	d8, [x2, #5176]
    393c:	fd4a2049 	ldr	d9, [x2, #5184]
    3940:	f9400036 	ldr	x22, [x1]
    3944:	f9400001 	ldr	x1, [x0]
    3948:	f90087e1 	str	x1, [sp, #264]
    394c:	d2800001 	mov	x1, #0x0                   	// #0
    3950:	f949e459 	ldr	x25, [x2, #5064]
    3954:	d0000041 	adrp	x1, d000 <__modti3+0x2c0>
    3958:	f94a1057 	ldr	x23, [x2, #5152]
    395c:	d0000040 	adrp	x0, d000 <__modti3+0x2c0>
    3960:	f94a1458 	ldr	x24, [x2, #5160]
    3964:	9104e021 	add	x1, x1, #0x138
    3968:	91050000 	add	x0, x0, #0x140
    396c:	97fffb89 	bl	2790 <fopen@plt>
    3970:	b4000760 	cbz	x0, 3a5c <fwp_heap_report+0x158>
    3974:	528daad5 	mov	w21, #0x6d56                	// #27990
    3978:	a91253f3 	stp	x19, x20, [sp, #288]
    397c:	aa0003f4 	mov	x20, x0
    3980:	910023f3 	add	x19, sp, #0x8
    3984:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3988:	72aae915 	movk	w21, #0x5748, lsl #16
    398c:	d503201f 	nop
    3990:	aa1403e2 	mov	x2, x20
    3994:	aa1303e0 	mov	x0, x19
    3998:	52802001 	mov	w1, #0x100                 	// #256
    399c:	97fffc05 	bl	29b0 <fgets@plt>
    39a0:	b4000280 	cbz	x0, 39f0 <fwp_heap_report+0xec>
    39a4:	b9400261 	ldr	w1, [x19]
    39a8:	6b15003f 	cmp	w1, w21
    39ac:	54ffff21 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39b0:	39401260 	ldrb	w0, [x19, #4]
    39b4:	7101341f 	cmp	w0, #0x4d
    39b8:	54fffec1 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39bc:	394037e0 	ldrb	w0, [sp, #13]
    39c0:	7100e81f 	cmp	w0, #0x3a
    39c4:	54fffe61 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39c8:	52800142 	mov	w2, #0xa                   	// #10
    39cc:	d2800001 	mov	x1, #0x0                   	// #0
    39d0:	91003be0 	add	x0, sp, #0xe
    39d4:	97fffbb3 	bl	28a0 <strtol@plt>
    39d8:	aa1403e2 	mov	x2, x20
    39dc:	aa0003fa 	mov	x26, x0
    39e0:	52802001 	mov	w1, #0x100                 	// #256
    39e4:	aa1303e0 	mov	x0, x19
    39e8:	97fffbf2 	bl	29b0 <fgets@plt>
    39ec:	b5fffdc0 	cbnz	x0, 39a4 <fwp_heap_report+0xa0>
    39f0:	aa1403e0 	mov	x0, x20
    39f4:	97fffb63 	bl	2780 <fclose@plt>
    39f8:	a95253f3 	ldp	x19, x20, [sp, #288]
    39fc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3a00:	f947f400 	ldr	x0, [x0, #4072]
    3a04:	f94087e2 	ldr	x2, [sp, #264]
    3a08:	f9400001 	ldr	x1, [x0]
    3a0c:	eb010042 	subs	x2, x2, x1
    3a10:	d2800001 	mov	x1, #0x0                   	// #0
    3a14:	54000281 	b.ne	3a64 <fwp_heap_report+0x160>  // b.any
    3a18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3a1c:	aa1a03e6 	mov	x6, x26
    3a20:	aa1903e5 	mov	x5, x25
    3a24:	aa1803e4 	mov	x4, x24
    3a28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3a2c:	aa1703e3 	mov	x3, x23
    3a30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3a3c:	1e604121 	fmov	d1, d9
    3a40:	1e604100 	fmov	d0, d8
    3a44:	d0000042 	adrp	x2, d000 <__modti3+0x2c0>
    3a48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3a4c:	91058042 	add	x2, x2, #0x160
    3a50:	9105c3ff 	add	sp, sp, #0x170
    3a54:	52800041 	mov	w1, #0x2                   	// #2
    3a58:	17fffb86 	b	2870 <__fprintf_chk@plt>
    3a5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3a60:	17ffffe7 	b	39fc <fwp_heap_report+0xf8>
    3a64:	a91253f3 	stp	x19, x20, [sp, #288]
    3a68:	97fffb66 	bl	2800 <__stack_chk_fail@plt>
    3a6c:	d503201f 	nop

0000000000003a70 <fwp_heap_init>:
    3a70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xad0>
    3a78:	9110c061 	add	x1, x3, #0x430
    3a7c:	910003fd 	mov	x29, sp
    3a80:	a90153f3 	stp	x19, x20, [sp, #16]
    3a84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    3a88:	9114c262 	add	x2, x19, #0x530
    3a8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3a90:	52800024 	mov	w4, #0x1                   	// #1
    3a94:	52800200 	mov	w0, #0x10                  	// #16
    3a98:	b913a444 	str	w4, [x2, #5028]
    3a9c:	d503201f 	nop
    3aa0:	b8004420 	str	w0, [x1], #4
    3aa4:	11004000 	add	w0, w0, #0x10
    3aa8:	7104401f 	cmp	w0, #0x110
    3aac:	54ffffa1 	b.ne	3aa0 <fwp_heap_init+0x30>  // b.any
    3ab0:	d0000042 	adrp	x2, d000 <__modti3+0x2c0>
    3ab4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ab8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xad0>
    3abc:	9111c021 	add	x1, x1, #0x470
    3ac0:	3dc36843 	ldr	q3, [x2, #3488]
    3ac4:	d2800000 	mov	x0, #0x0                   	// #0
    3ac8:	4e040401 	dup	v1.4s, v0.s[0]
    3acc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ad0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ad4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ad8:	3ca06821 	str	q1, [x1, x0]
    3adc:	91004000 	add	x0, x0, #0x10
    3ae0:	f101801f 	cmp	x0, #0x60
    3ae4:	54ffff21 	b.ne	3ac8 <fwp_heap_init+0x58>  // b.any
    3ae8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xad0>
    3aec:	9110c063 	add	x3, x3, #0x430
    3af0:	91134084 	add	x4, x4, #0x4d0
    3af4:	9114c266 	add	x6, x19, #0x530
    3af8:	d2800002 	mov	x2, #0x0                   	// #0
    3afc:	d2800000 	mov	x0, #0x0                   	// #0
    3b00:	d2880205 	mov	x5, #0x4010                	// #16400
    3b04:	d503201f 	nop
    3b08:	910f0001 	add	x1, x0, #0x3c0
    3b0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3b10:	eb02003f 	cmp	x1, x2
    3b14:	540000a2 	b.cs	3b28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3b18:	91000400 	add	x0, x0, #0x1
    3b1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3b20:	eb02003f 	cmp	x1, x2
    3b24:	54ffffa3 	b.cc	3b18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3b28:	91004042 	add	x2, x2, #0x10
    3b2c:	38001480 	strb	w0, [x4], #1
    3b30:	eb05005f 	cmp	x2, x5
    3b34:	54fffea1 	b.ne	3b08 <fwp_heap_init+0x98>  // b.any
    3b38:	528000b5 	mov	w21, #0x5                   	// #5
    3b3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3b40:	14000004 	b	3b50 <fwp_heap_init+0xe0>
    3b44:	d342fe94 	lsr	x20, x20, #2
    3b48:	710006b5 	subs	w21, w21, #0x1
    3b4c:	54000720 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3b50:	91404296 	add	x22, x20, #0x10, lsl #12
    3b54:	d2800005 	mov	x5, #0x0                   	// #0
    3b58:	aa1603e1 	mov	x1, x22
    3b5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3b60:	52880443 	mov	w3, #0x4022                	// #16418
    3b64:	52800002 	mov	w2, #0x0                   	// #0
    3b68:	d2800000 	mov	x0, #0x0                   	// #0
    3b6c:	97fffb49 	bl	2890 <mmap@plt>
    3b70:	aa0003e6 	mov	x6, x0
    3b74:	b100041f 	cmn	x0, #0x1
    3b78:	54fffe60 	b.eq	3b44 <fwp_heap_init+0xd4>  // b.none
    3b7c:	b40005a0 	cbz	x0, 3c30 <fwp_heap_init+0x1c0>
    3b80:	d350fe94 	lsr	x20, x20, #16
    3b84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3b88:	8b0000c7 	add	x7, x6, x0
    3b8c:	9114c275 	add	x21, x19, #0x530
    3b90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3b94:	8b140a81 	add	x1, x20, x20, lsl #2
    3b98:	d2800005 	mov	x5, #0x0                   	// #0
    3b9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ba0:	d37df021 	lsl	x1, x1, #3
    3ba4:	52880443 	mov	w3, #0x4022                	// #16418
    3ba8:	52800002 	mov	w2, #0x0                   	// #0
    3bac:	d2800000 	mov	x0, #0x0                   	// #0
    3bb0:	f909daa7 	str	x7, [x21, #5040]
    3bb4:	f909dea6 	str	x6, [x21, #5048]
    3bb8:	f909e2b6 	str	x22, [x21, #5056]
    3bbc:	f909eab4 	str	x20, [x21, #5072]
    3bc0:	f90a02a1 	str	x1, [x21, #5120]
    3bc4:	97fffb33 	bl	2890 <mmap@plt>
    3bc8:	aa0003e1 	mov	x1, x0
    3bcc:	b100041f 	cmn	x0, #0x1
    3bd0:	54000300 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3bd4:	d0000040 	adrp	x0, d000 <__modti3+0x2c0>
    3bd8:	9107a000 	add	x0, x0, #0x1e8
    3bdc:	f909fea1 	str	x1, [x21, #5112]
    3be0:	97fffb6c 	bl	2990 <getenv@plt>
    3be4:	52800002 	mov	w2, #0x0                   	// #0
    3be8:	aa0003e1 	mov	x1, x0
    3bec:	b40000e0 	cbz	x0, 3c08 <fwp_heap_init+0x198>
    3bf0:	39400000 	ldrb	w0, [x0]
    3bf4:	340000a0 	cbz	w0, 3c08 <fwp_heap_init+0x198>
    3bf8:	7100c000 	subs	w0, w0, #0x30
    3bfc:	54000120 	b.eq	3c20 <fwp_heap_init+0x1b0>  // b.none
    3c00:	7100001f 	cmp	w0, #0x0
    3c04:	1a9f07e2 	cset	w2, ne	// ne = any
    3c08:	9114c273 	add	x19, x19, #0x530
    3c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3c10:	b913aa62 	str	w2, [x19, #5032]
    3c14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3c1c:	d65f03c0 	ret
    3c20:	39400420 	ldrb	w0, [x1, #1]
    3c24:	7100001f 	cmp	w0, #0x0
    3c28:	1a9f07e2 	cset	w2, ne	// ne = any
    3c2c:	17fffff7 	b	3c08 <fwp_heap_init+0x198>
    3c30:	97fffce0 	bl	2fb0 <fwp_heap_oom>

0000000000003c34 <fwp_wake_io>:
    3c34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3c38:	9100c122 	add	x2, x9, #0x30
    3c3c:	f9400001 	ldr	x1, [x0]
    3c40:	5280000a 	mov	w10, #0x0                   	// #0
    3c44:	f9401446 	ldr	x6, [x2, #40]
    3c48:	52800008 	mov	w8, #0x0                   	// #0
    3c4c:	4f000400 	movi	v0.4s, #0x0
    3c50:	52800027 	mov	w7, #0x1                   	// #1
    3c54:	aa0103e2 	mov	x2, x1
    3c58:	b4000321 	cbz	x1, 3cbc <fwp_wake_io+0x88>
    3c5c:	f9408c25 	ldr	x5, [x1, #280]
    3c60:	39015c27 	strb	w7, [x1, #87]
    3c64:	b4000165 	cbz	x5, 3c90 <fwp_wake_io+0x5c>
    3c68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3c6c:	b4000364 	cbz	x4, 3cd8 <fwp_wake_io+0xa4>
    3c70:	f9009483 	str	x3, [x4, #296]
    3c74:	f9409423 	ldr	x3, [x1, #296]
    3c78:	b4000043 	cbz	x3, 3c80 <fwp_wake_io+0x4c>
    3c7c:	f9009064 	str	x4, [x3, #288]
    3c80:	91080023 	add	x3, x1, #0x200
    3c84:	f900943f 	str	xzr, [x1, #296]
    3c88:	3c918060 	stur	q0, [x3, #-232]
    3c8c:	f9400001 	ldr	x1, [x0]
    3c90:	f9402843 	ldr	x3, [x2, #80]
    3c94:	f2001c7f 	tst	x3, #0xff000000ff
    3c98:	54fffde1 	b.ne	3c54 <fwp_wake_io+0x20>  // b.any
    3c9c:	39015047 	strb	w7, [x2, #84]
    3ca0:	f900805f 	str	xzr, [x2, #256]
    3ca4:	b40001e6 	cbz	x6, 3ce0 <fwp_wake_io+0xac>
    3ca8:	f90080c2 	str	x2, [x6, #256]
    3cac:	aa0203e6 	mov	x6, x2
    3cb0:	52800028 	mov	w8, #0x1                   	// #1
    3cb4:	aa0103e2 	mov	x2, x1
    3cb8:	b5fffd21 	cbnz	x1, 3c5c <fwp_wake_io+0x28>
    3cbc:	3400006a 	cbz	w10, 3cc8 <fwp_wake_io+0x94>
    3cc0:	9100c120 	add	x0, x9, #0x30
    3cc4:	f900180b 	str	x11, [x0, #48]
    3cc8:	34000068 	cbz	w8, 3cd4 <fwp_wake_io+0xa0>
    3ccc:	9100c129 	add	x9, x9, #0x30
    3cd0:	f9001526 	str	x6, [x9, #40]
    3cd4:	d65f03c0 	ret
    3cd8:	f90000a3 	str	x3, [x5]
    3cdc:	17ffffe7 	b	3c78 <fwp_wake_io+0x44>
    3ce0:	aa0203eb 	mov	x11, x2
    3ce4:	5280002a 	mov	w10, #0x1                   	// #1
    3ce8:	17fffff1 	b	3cac <fwp_wake_io+0x78>
    3cec:	d503201f 	nop

0000000000003cf0 <fwp_tape_buffers_release>:
    3cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3cf4:	910003fd 	mov	x29, sp
    3cf8:	a90153f3 	stp	x19, x20, [sp, #16]
    3cfc:	aa0003f3 	mov	x19, x0
    3d00:	f9400c00 	ldr	x0, [x0, #24]
    3d04:	b7f80700 	tbnz	x0, #63, 3de4 <fwp_tape_buffers_release+0xf4>
    3d08:	f9401261 	ldr	x1, [x19, #32]
    3d0c:	b7f80301 	tbnz	x1, #63, 3d6c <fwp_tape_buffers_release+0x7c>
    3d10:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    3d14:	eb02001f 	cmp	x0, x2
    3d18:	540002a8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d1c:	8b000400 	add	x0, x0, x0, lsl #1
    3d20:	d2a00102 	mov	x2, #0x80000               	// #524288
    3d24:	d37df000 	lsl	x0, x0, #3
    3d28:	cb000042 	sub	x2, x2, x0
    3d2c:	eb420c3f 	cmp	x1, x2, lsr #3
    3d30:	540001e8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d34:	8b010c14 	add	x20, x0, x1, lsl #3
    3d38:	d0000040 	adrp	x0, d000 <__modti3+0x2c0>
    3d3c:	9107e000 	add	x0, x0, #0x1f8
    3d40:	97fffb14 	bl	2990 <getenv@plt>
    3d44:	b4000240 	cbz	x0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d48:	39400001 	ldrb	w1, [x0]
    3d4c:	7100c03f 	cmp	w1, #0x30
    3d50:	540001e1 	b.ne	3d8c <fwp_tape_buffers_release+0x9c>  // b.any
    3d54:	39400400 	ldrb	w0, [x0, #1]
    3d58:	350001a0 	cbnz	w0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d5c:	aa1303e0 	mov	x0, x19
    3d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d64:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3d68:	17fffd46 	b	3280 <fwp_tape_buffers_dispose>
    3d6c:	d0000040 	adrp	x0, d000 <__modti3+0x2c0>
    3d70:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3d74:	9107e000 	add	x0, x0, #0x1f8
    3d78:	97fffb06 	bl	2990 <getenv@plt>
    3d7c:	b4ffff00 	cbz	x0, 3d5c <fwp_tape_buffers_release+0x6c>
    3d80:	39400001 	ldrb	w1, [x0]
    3d84:	7100c03f 	cmp	w1, #0x30
    3d88:	54fffe60 	b.eq	3d54 <fwp_tape_buffers_release+0x64>  // b.none
    3d8c:	d1000681 	sub	x1, x20, #0x1
    3d90:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    3d94:	eb00003f 	cmp	x1, x0
    3d98:	54fffe28 	b.hi	3d5c <fwp_tape_buffers_release+0x6c>  // b.pmore
    3d9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3da0:	b00000f6 	adrp	x22, 20000 <__data_start>
    3da4:	9100c2d6 	add	x22, x22, #0x30
    3da8:	9100e2d5 	add	x21, x22, #0x38
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffd34 	bl	3280 <fwp_tape_buffers_dispose>
    3db4:	ad400660 	ldp	q0, q1, [x19]
    3db8:	f90032d4 	str	x20, [x22, #96]
    3dbc:	ad0006a0 	stp	q0, q1, [x21]
    3dc0:	f9401260 	ldr	x0, [x19, #32]
    3dc4:	f90012a0 	str	x0, [x21, #32]
    3dc8:	a9007e7f 	stp	xzr, xzr, [x19]
    3dcc:	a9017e7f 	stp	xzr, xzr, [x19, #16]
    3dd0:	f900127f 	str	xzr, [x19, #32]
    3dd4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3dd8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3ddc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3de0:	d65f03c0 	ret
    3de4:	d0000040 	adrp	x0, d000 <__modti3+0x2c0>
    3de8:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3dec:	9107e000 	add	x0, x0, #0x1f8
    3df0:	97fffae8 	bl	2990 <getenv@plt>
    3df4:	b5fffaa0 	cbnz	x0, 3d48 <fwp_tape_buffers_release+0x58>
    3df8:	17ffffd9 	b	3d5c <fwp_tape_buffers_release+0x6c>
    3dfc:	d503201f 	nop

0000000000003e00 <fwp_trap>:
    3e00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e04:	b00000e2 	adrp	x2, 20000 <__data_start>
    3e08:	d53bd041 	mrs	x1, tpidr_el0
    3e0c:	910003fd 	mov	x29, sp
    3e10:	f9401c42 	ldr	x2, [x2, #56]
    3e14:	91400021 	add	x1, x1, #0x0, lsl #12
    3e18:	91004021 	add	x1, x1, #0x10
    3e1c:	a90153f3 	stp	x19, x20, [sp, #16]
    3e20:	aa0003f3 	mov	x19, x0
    3e24:	f9400034 	ldr	x20, [x1]
    3e28:	b4000062 	cbz	x2, 3e34 <fwp_trap+0x34>
    3e2c:	aa0203e0 	mov	x0, x2
    3e30:	97fffac0 	bl	2930 <fflush@plt>
    3e34:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3e38:	f947ec00 	ldr	x0, [x0, #4056]
    3e3c:	f9400000 	ldr	x0, [x0]
    3e40:	97fffabc 	bl	2930 <fflush@plt>
    3e44:	aa1303e3 	mov	x3, x19
    3e48:	d0000042 	adrp	x2, d000 <__modti3+0x2c0>
    3e4c:	900000f3 	adrp	x19, 1f000 <fwp_fn_table+0xc88>
    3e50:	f947ea73 	ldr	x19, [x19, #4048]
    3e54:	91084042 	add	x2, x2, #0x210
    3e58:	52800041 	mov	w1, #0x2                   	// #2
    3e5c:	f9400260 	ldr	x0, [x19]
    3e60:	97fffa84 	bl	2870 <__fprintf_chk@plt>
    3e64:	b40000b4 	cbz	x20, 3e78 <fwp_trap+0x78>
    3e68:	f9400260 	ldr	x0, [x19]
    3e6c:	97fffab1 	bl	2930 <fflush@plt>
    3e70:	52800ca0 	mov	w0, #0x65                  	// #101
    3e74:	97fffabf 	bl	2970 <_Exit@plt>
    3e78:	52800ca0 	mov	w0, #0x65                  	// #101
    3e7c:	97fffa0d 	bl	26b0 <exit@plt>

0000000000003e80 <fwp_rc_forget_slot.part.0>:
    3e80:	ca404401 	eor	x1, x0, x0, lsr #17
    3e84:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e88:	ca412421 	eor	x1, x1, x1, lsr #9
    3e8c:	910003fd 	mov	x29, sp
    3e90:	92401c21 	and	x1, x1, #0xff
    3e94:	f9000bf3 	str	x19, [sp, #16]
    3e98:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    3e9c:	9114c262 	add	x2, x19, #0x530
    3ea0:	910a2423 	add	x3, x1, #0x289
    3ea4:	8b010c41 	add	x1, x2, x1, lsl #3
    3ea8:	8b030c43 	add	x3, x2, x3, lsl #3
    3eac:	f94a2421 	ldr	x1, [x1, #5192]
    3eb0:	b50000a1 	cbnz	x1, 3ec4 <fwp_rc_forget_slot.part.0+0x44>
    3eb4:	14000012 	b	3efc <fwp_rc_forget_slot.part.0+0x7c>
    3eb8:	91004023 	add	x3, x1, #0x10
    3ebc:	f9400821 	ldr	x1, [x1, #16]
    3ec0:	b40001e1 	cbz	x1, 3efc <fwp_rc_forget_slot.part.0+0x7c>
    3ec4:	f9400022 	ldr	x2, [x1]
    3ec8:	eb02001f 	cmp	x0, x2
    3ecc:	54ffff61 	b.ne	3eb8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    3ed0:	f9400060 	ldr	x0, [x3]
    3ed4:	9114c273 	add	x19, x19, #0x530
    3ed8:	f9400801 	ldr	x1, [x0, #16]
    3edc:	f9000061 	str	x1, [x3]
    3ee0:	97fffa78 	bl	28c0 <free@plt>
    3ee4:	f94e2660 	ldr	x0, [x19, #7240]
    3ee8:	d1000400 	sub	x0, x0, #0x1
    3eec:	f90e2660 	str	x0, [x19, #7240]
    3ef0:	f9400bf3 	ldr	x19, [sp, #16]
    3ef4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3ef8:	d65f03c0 	ret
    3efc:	d0000040 	adrp	x0, d000 <__modti3+0x2c0>
    3f00:	91088000 	add	x0, x0, #0x220
    3f04:	97ffffbf 	bl	3e00 <fwp_trap>
    3f08:	d503201f 	nop
    3f0c:	d503201f 	nop

0000000000003f10 <fwp_rc_prepare_chunk>:
    3f10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3f14:	910003fd 	mov	x29, sp
    3f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    3f1c:	d0000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    3f20:	9114c2c2 	add	x2, x22, #0x530
    3f24:	b9401c03 	ldr	w3, [x0, #28]
    3f28:	aa0103f5 	mov	x21, x1
    3f2c:	a90153f3 	stp	x19, x20, [sp, #16]
    3f30:	aa0003f4 	mov	x20, x0
    3f34:	f94e2440 	ldr	x0, [x2, #7240]
    3f38:	b4000440 	cbz	x0, 3fc0 <fwp_rc_prepare_chunk+0xb0>
    3f3c:	d2800013 	mov	x19, #0x0                   	// #0
    3f40:	35000203 	cbnz	w3, 3f80 <fwp_rc_prepare_chunk+0x70>
    3f44:	b4000361 	cbz	x1, 3fb0 <fwp_rc_prepare_chunk+0xa0>
    3f48:	f9401280 	ldr	x0, [x20, #32]
    3f4c:	97fffa5d 	bl	28c0 <free@plt>
    3f50:	aa1503e0 	mov	x0, x21
    3f54:	d2800021 	mov	x1, #0x1                   	// #1
    3f58:	97fffa22 	bl	27e0 <calloc@plt>
    3f5c:	f9001280 	str	x0, [x20, #32]
    3f60:	b5000460 	cbnz	x0, 3fec <fwp_rc_prepare_chunk+0xdc>
    3f64:	97fffc13 	bl	2fb0 <fwp_heap_oom>
    3f68:	97ffffc6 	bl	3e80 <fwp_rc_forget_slot.part.0>
    3f6c:	91000673 	add	x19, x19, #0x1
    3f70:	b9401e83 	ldr	w3, [x20, #28]
    3f74:	eb13007f 	cmp	x3, x19
    3f78:	54000169 	b.ls	3fa4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    3f7c:	d503201f 	nop
    3f80:	f9401283 	ldr	x3, [x20, #32]
    3f84:	8b130060 	add	x0, x3, x19
    3f88:	38736863 	ldrb	w3, [x3, x19]
    3f8c:	7103fc7f 	cmp	w3, #0xff
    3f90:	54fffec0 	b.eq	3f68 <fwp_rc_prepare_chunk+0x58>  // b.none
    3f94:	b9401e83 	ldr	w3, [x20, #28]
    3f98:	91000673 	add	x19, x19, #0x1
    3f9c:	eb13007f 	cmp	x3, x19
    3fa0:	54ffff08 	b.hi	3f80 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    3fa4:	eb0302bf 	cmp	x21, x3
    3fa8:	54000121 	b.ne	3fcc <fwp_rc_prepare_chunk+0xbc>  // b.any
    3fac:	b5000335 	cbnz	x21, 4010 <fwp_rc_prepare_chunk+0x100>
    3fb0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fb4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fb8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fbc:	d65f03c0 	ret
    3fc0:	2a0303e3 	mov	w3, w3
    3fc4:	eb0302bf 	cmp	x21, x3
    3fc8:	54ffff20 	b.eq	3fac <fwp_rc_prepare_chunk+0x9c>  // b.none
    3fcc:	9114c2c2 	add	x2, x22, #0x530
    3fd0:	f9401280 	ldr	x0, [x20, #32]
    3fd4:	f94e2841 	ldr	x1, [x2, #7248]
    3fd8:	cb030021 	sub	x1, x1, x3
    3fdc:	f90e2841 	str	x1, [x2, #7248]
    3fe0:	97fffa38 	bl	28c0 <free@plt>
    3fe4:	b5fffb75 	cbnz	x21, 3f50 <fwp_rc_prepare_chunk+0x40>
    3fe8:	f900129f 	str	xzr, [x20, #32]
    3fec:	9114c2d6 	add	x22, x22, #0x530
    3ff0:	f94e2ac0 	ldr	x0, [x22, #7248]
    3ff4:	b9001e95 	str	w21, [x20, #28]
    3ff8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3ffc:	8b150000 	add	x0, x0, x21
    4000:	f90e2ac0 	str	x0, [x22, #7248]
    4004:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4008:	a8c37bfd 	ldp	x29, x30, [sp], #48
    400c:	d65f03c0 	ret
    4010:	f9401280 	ldr	x0, [x20, #32]
    4014:	aa1503e2 	mov	x2, x21
    4018:	a94153f3 	ldp	x19, x20, [sp, #16]
    401c:	52800001 	mov	w1, #0x0                   	// #0
    4020:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4024:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4028:	17fff9ea 	b	27d0 <memset@plt>
    402c:	d503201f 	nop

0000000000004030 <fwp_heap_refill>:
    4030:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4034:	910003fd 	mov	x29, sp
    4038:	a9025bf5 	stp	x21, x22, [sp, #32]
    403c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4040:	9114c2b5 	add	x21, x21, #0x530
    4044:	aa0003f6 	mov	x22, x0
    4048:	d2800020 	mov	x0, #0x1                   	// #1
    404c:	a90153f3 	stp	x19, x20, [sp, #16]
    4050:	a90363f7 	stp	x23, x24, [sp, #48]
    4054:	2a0103f7 	mov	w23, w1
    4058:	2a0203f8 	mov	w24, w2
    405c:	97fffc15 	bl	30b0 <fwp_heap_chunks>
    4060:	aa0003f3 	mov	x19, x0
    4064:	f949fea2 	ldr	x2, [x21, #5112]
    4068:	8b000800 	add	x0, x0, x0, lsl #2
    406c:	2a1703e1 	mov	w1, w23
    4070:	52800025 	mov	w5, #0x1                   	// #1
    4074:	d37df000 	lsl	x0, x0, #3
    4078:	910f0021 	add	x1, x1, #0x3c0
    407c:	8b000054 	add	x20, x2, x0
    4080:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4084:	52a00024 	mov	w4, #0x10000               	// #65536
    4088:	38206845 	strb	w5, [x2, x0]
    408c:	aa1403e0 	mov	x0, x20
    4090:	39000698 	strb	w24, [x20, #1]
    4094:	39000a97 	strb	w23, [x20, #2]
    4098:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    409c:	b9000681 	str	w1, [x20, #4]
    40a0:	2a0103e5 	mov	w5, w1
    40a4:	8b0300a2 	add	x2, x5, x3
    40a8:	1ac10881 	udiv	w1, w4, w1
    40ac:	9ac50842 	udiv	x2, x2, x5
    40b0:	b9000a81 	str	w1, [x20, #8]
    40b4:	92404021 	and	x1, x1, #0x1ffff
    40b8:	b9001a82 	str	w2, [x20, #24]
    40bc:	97ffff95 	bl	3f10 <fwp_rc_prepare_chunk>
    40c0:	f949daa0 	ldr	x0, [x21, #5040]
    40c4:	29408a81 	ldp	w1, w2, [x20, #4]
    40c8:	8b134000 	add	x0, x0, x19, lsl #16
    40cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    40d0:	8b214003 	add	x3, x0, w1, uxtw
    40d4:	9ba20021 	umaddl	x1, w1, w2, x0
    40d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    40dc:	a90086c3 	stp	x3, x1, [x22, #8]
    40e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    40e8:	d65f03c0 	ret
    40ec:	d503201f 	nop

00000000000040f0 <fwp_mem_free>:
    40f0:	b40003c0 	cbz	x0, 4168 <fwp_mem_free+0x78>
    40f4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    40f8:	910003fd 	mov	x29, sp
    40fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4100:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4104:	9114c2a1 	add	x1, x21, #0x530
    4108:	a90153f3 	stp	x19, x20, [sp, #16]
    410c:	aa0003f3 	mov	x19, x0
    4110:	f949d823 	ldr	x3, [x1, #5040]
    4114:	f949ec22 	ldr	x2, [x1, #5080]
    4118:	cb030000 	sub	x0, x0, x3
    411c:	eb02401f 	cmp	x0, x2, lsl #16
    4120:	540001c2 	b.cs	4158 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4124:	d350fc16 	lsr	x22, x0, #16
    4128:	a90363f7 	stp	x23, x24, [sp, #48]
    412c:	f949fc22 	ldr	x2, [x1, #5112]
    4130:	8b160ad4 	add	x20, x22, x22, lsl #2
    4134:	d37df294 	lsl	x20, x20, #3
    4138:	ab140057 	adds	x23, x2, x20
    413c:	540000c0 	b.eq	4154 <fwp_mem_free+0x64>  // b.none
    4140:	38746842 	ldrb	w2, [x2, x20]
    4144:	7100045f 	cmp	w2, #0x1
    4148:	54000120 	b.eq	416c <fwp_mem_free+0x7c>  // b.none
    414c:	7100085f 	cmp	w2, #0x2
    4150:	540005e0 	b.eq	420c <fwp_mem_free+0x11c>  // b.none
    4154:	a94363f7 	ldp	x23, x24, [sp, #48]
    4158:	a94153f3 	ldp	x19, x20, [sp, #16]
    415c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4160:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4164:	d65f03c0 	ret
    4168:	d65f03c0 	ret
    416c:	f94012f8 	ldr	x24, [x23, #32]
    4170:	b94006e1 	ldr	w1, [x23, #4]
    4174:	f90023f9 	str	x25, [sp, #64]
    4178:	2a0103e2 	mov	w2, w1
    417c:	394006f9 	ldrb	w25, [x23, #1]
    4180:	39400af4 	ldrb	w20, [x23, #2]
    4184:	b4000158 	cbz	x24, 41ac <fwp_mem_free+0xbc>
    4188:	92403e76 	and	x22, x19, #0xffff
    418c:	9ac20ad6 	udiv	x22, x22, x2
    4190:	38766b01 	ldrb	w1, [x24, x22]
    4194:	8b160300 	add	x0, x24, x22
    4198:	7103fc3f 	cmp	w1, #0xff
    419c:	54000980 	b.eq	42cc <fwp_mem_free+0x1dc>  // b.none
    41a0:	38366b1f 	strb	wzr, [x24, x22]
    41a4:	b94006e1 	ldr	w1, [x23, #4]
    41a8:	2a0103e2 	mov	w2, w1
    41ac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    41b0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    41b4:	cb390000 	sub	x0, x0, w25, uxtb
    41b8:	8b340074 	add	x20, x3, w20, uxtb
    41bc:	9114c2b5 	add	x21, x21, #0x530
    41c0:	1e630021 	ucvtf	d1, w1
    41c4:	d37ae400 	lsl	x0, x0, #6
    41c8:	8b140c14 	add	x20, x0, x20, lsl #3
    41cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    41d0:	f8746aa0 	ldr	x0, [x21, x20]
    41d4:	f94023f9 	ldr	x25, [sp, #64]
    41d8:	aa2003e0 	mvn	x0, x0
    41dc:	fd4a22a0 	ldr	d0, [x21, #5184]
    41e0:	f9000260 	str	x0, [x19]
    41e4:	f8346ab3 	str	x19, [x21, x20]
    41e8:	f94a12a0 	ldr	x0, [x21, #5152]
    41ec:	1e612800 	fadd	d0, d0, d1
    41f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41f4:	cb020000 	sub	x0, x0, x2
    41f8:	f90a12a0 	str	x0, [x21, #5152]
    41fc:	fd0a22a0 	str	d0, [x21, #5184]
    4200:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4204:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4208:	d65f03c0 	ret
    420c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4210:	8b000063 	add	x3, x3, x0
    4214:	eb03027f 	cmp	x19, x3
    4218:	54fff9e1 	b.ne	4154 <fwp_mem_free+0x64>  // b.any
    421c:	fd400ae1 	ldr	d1, [x23, #16]
    4220:	fd4a2020 	ldr	d0, [x1, #5184]
    4224:	f9400ae0 	ldr	x0, [x23, #16]
    4228:	7e61d821 	ucvtf	d1, d1
    422c:	f94a1022 	ldr	x2, [x1, #5152]
    4230:	f94012f3 	ldr	x19, [x23, #32]
    4234:	1e612800 	fadd	d0, d0, d1
    4238:	cb000042 	sub	x2, x2, x0
    423c:	f90a1022 	str	x2, [x1, #5152]
    4240:	fd0a2020 	str	d0, [x1, #5184]
    4244:	b40000b3 	cbz	x19, 4258 <fwp_mem_free+0x168>
    4248:	39400260 	ldrb	w0, [x19]
    424c:	7103fc1f 	cmp	w0, #0xff
    4250:	54000380 	b.eq	42c0 <fwp_mem_free+0x1d0>  // b.none
    4254:	3900027f 	strb	wzr, [x19]
    4258:	b9400ee2 	ldr	w2, [x23, #12]
    425c:	b4000142 	cbz	x2, 4284 <fwp_mem_free+0x194>
    4260:	9114c2a1 	add	x1, x21, #0x530
    4264:	8b160040 	add	x0, x2, x22
    4268:	8b000800 	add	x0, x0, x0, lsl #2
    426c:	f949fc21 	ldr	x1, [x1, #5112]
    4270:	8b140034 	add	x20, x1, x20
    4274:	8b000c20 	add	x0, x1, x0, lsl #3
    4278:	3802869f 	strb	wzr, [x20], #40
    427c:	eb00029f 	cmp	x20, x0
    4280:	54ffffc1 	b.ne	4278 <fwp_mem_free+0x188>  // b.any
    4284:	9114c2a0 	add	x0, x21, #0x530
    4288:	f94a1801 	ldr	x1, [x0, #5168]
    428c:	f949f803 	ldr	x3, [x0, #5104]
    4290:	8b020021 	add	x1, x1, x2
    4294:	f90a1801 	str	x1, [x0, #5168]
    4298:	eb16007f 	cmp	x3, x22
    429c:	54000049 	b.ls	42a4 <fwp_mem_free+0x1b4>  // b.plast
    42a0:	f909f816 	str	x22, [x0, #5104]
    42a4:	9114c2b5 	add	x21, x21, #0x530
    42a8:	f949f6a0 	ldr	x0, [x21, #5096]
    42ac:	eb16001f 	cmp	x0, x22
    42b0:	54fff529 	b.ls	4154 <fwp_mem_free+0x64>  // b.plast
    42b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    42b8:	f909f6b6 	str	x22, [x21, #5096]
    42bc:	17ffffa7 	b	4158 <fwp_mem_free+0x68>
    42c0:	aa1303e0 	mov	x0, x19
    42c4:	97fffeef 	bl	3e80 <fwp_rc_forget_slot.part.0>
    42c8:	17ffffe3 	b	4254 <fwp_mem_free+0x164>
    42cc:	97fffeed 	bl	3e80 <fwp_rc_forget_slot.part.0>
    42d0:	17ffffb4 	b	41a0 <fwp_mem_free+0xb0>

00000000000042d4 <fwp_rc_wide_dup>:
    42d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    42d8:	910003fd 	mov	x29, sp
    42dc:	a90153f3 	stp	x19, x20, [sp, #16]
    42e0:	aa0003f3 	mov	x19, x0
    42e4:	ca404400 	eor	x0, x0, x0, lsr #17
    42e8:	f90013f5 	str	x21, [sp, #32]
    42ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    42f0:	ca402400 	eor	x0, x0, x0, lsr #9
    42f4:	9114c2a2 	add	x2, x21, #0x530
    42f8:	92401c00 	and	x0, x0, #0xff
    42fc:	910a2403 	add	x3, x0, #0x289
    4300:	8b000c40 	add	x0, x2, x0, lsl #3
    4304:	8b030c54 	add	x20, x2, x3, lsl #3
    4308:	f94a2401 	ldr	x1, [x0, #5192]
    430c:	b50000a1 	cbnz	x1, 4320 <fwp_rc_wide_dup+0x4c>
    4310:	14000033 	b	43dc <fwp_rc_wide_dup+0x108>
    4314:	91004034 	add	x20, x1, #0x10
    4318:	f9400821 	ldr	x1, [x1, #16]
    431c:	b4000241 	cbz	x1, 4364 <fwp_rc_wide_dup+0x90>
    4320:	f9400022 	ldr	x2, [x1]
    4324:	eb02027f 	cmp	x19, x2
    4328:	54ffff61 	b.ne	4314 <fwp_rc_wide_dup+0x40>  // b.any
    432c:	f9400281 	ldr	x1, [x20]
    4330:	39400260 	ldrb	w0, [x19]
    4334:	7103f81f 	cmp	w0, #0xfe
    4338:	54000220 	b.eq	437c <fwp_rc_wide_dup+0xa8>  // b.none
    433c:	b40001a1 	cbz	x1, 4370 <fwp_rc_wide_dup+0x9c>
    4340:	f9400420 	ldr	x0, [x1, #8]
    4344:	b100041f 	cmn	x0, #0x1
    4348:	54000440 	b.eq	43d0 <fwp_rc_wide_dup+0xfc>  // b.none
    434c:	91000400 	add	x0, x0, #0x1
    4350:	f9000420 	str	x0, [x1, #8]
    4354:	a94153f3 	ldp	x19, x20, [sp, #16]
    4358:	f94013f5 	ldr	x21, [sp, #32]
    435c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4360:	d65f03c0 	ret
    4364:	39400260 	ldrb	w0, [x19]
    4368:	7103f81f 	cmp	w0, #0xfe
    436c:	54000100 	b.eq	438c <fwp_rc_wide_dup+0xb8>  // b.none
    4370:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    4374:	91088000 	add	x0, x0, #0x220
    4378:	97fffea2 	bl	3e00 <fwp_trap>
    437c:	b4000081 	cbz	x1, 438c <fwp_rc_wide_dup+0xb8>
    4380:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    4384:	91092000 	add	x0, x0, #0x248
    4388:	97fffe9e 	bl	3e00 <fwp_trap>
    438c:	d2800300 	mov	x0, #0x18                  	// #24
    4390:	97fff904 	bl	27a0 <malloc@plt>
    4394:	b4000280 	cbz	x0, 43e4 <fwp_rc_wide_dup+0x110>
    4398:	d2801fe1 	mov	x1, #0xff                  	// #255
    439c:	a9000413 	stp	x19, x1, [x0]
    43a0:	9114c2b5 	add	x21, x21, #0x530
    43a4:	f900081f 	str	xzr, [x0, #16]
    43a8:	12800001 	mov	w1, #0xffffffff            	// #-1
    43ac:	f9000280 	str	x0, [x20]
    43b0:	39000261 	strb	w1, [x19]
    43b4:	f94e26a0 	ldr	x0, [x21, #7240]
    43b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    43bc:	91000400 	add	x0, x0, #0x1
    43c0:	f90e26a0 	str	x0, [x21, #7240]
    43c4:	f94013f5 	ldr	x21, [sp, #32]
    43c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43cc:	d65f03c0 	ret
    43d0:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    43d4:	9109c000 	add	x0, x0, #0x270
    43d8:	97fffe8a 	bl	3e00 <fwp_trap>
    43dc:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    43e0:	17ffffd4 	b	4330 <fwp_rc_wide_dup+0x5c>
    43e4:	97fffaf3 	bl	2fb0 <fwp_heap_oom>
    43e8:	d503201f 	nop
    43ec:	d503201f 	nop

00000000000043f0 <fwp_closure_drop_push>:
    43f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    43f4:	910003fd 	mov	x29, sp
    43f8:	a90153f3 	stp	x19, x20, [sp, #16]
    43fc:	aa0003f3 	mov	x19, x0
    4400:	a9408014 	ldp	x20, x0, [x0, #8]
    4404:	a9025bf5 	stp	x21, x22, [sp, #32]
    4408:	aa0103f5 	mov	x21, x1
    440c:	a90363f7 	stp	x23, x24, [sp, #48]
    4410:	eb00029f 	cmp	x20, x0
    4414:	54000160 	b.eq	4440 <fwp_closure_drop_push+0x50>  // b.none
    4418:	f9400276 	ldr	x22, [x19]
    441c:	d37df297 	lsl	x23, x20, #3
    4420:	91000694 	add	x20, x20, #0x1
    4424:	f9000674 	str	x20, [x19, #8]
    4428:	a94153f3 	ldp	x19, x20, [sp, #16]
    442c:	f8376ad5 	str	x21, [x22, x23]
    4430:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4434:	a94363f7 	ldp	x23, x24, [sp, #48]
    4438:	a8c57bfd 	ldp	x29, x30, [sp], #80
    443c:	d65f03c0 	ret
    4440:	a9046bf9 	stp	x25, x26, [sp, #64]
    4444:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4448:	eb00029f 	cmp	x20, x0
    444c:	540003e8 	b.hi	44c8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4450:	d37cee99 	lsl	x25, x20, #4
    4454:	d37ffa9a 	lsl	x26, x20, #1
    4458:	aa1903e0 	mov	x0, x25
    445c:	97fff8d1 	bl	27a0 <malloc@plt>
    4460:	aa0003f6 	mov	x22, x0
    4464:	b4000380 	cbz	x0, 44d4 <fwp_closure_drop_push+0xe4>
    4468:	aa1303f8 	mov	x24, x19
    446c:	aa1903e3 	mov	x3, x25
    4470:	d37df297 	lsl	x23, x20, #3
    4474:	aa1703e2 	mov	x2, x23
    4478:	f8418719 	ldr	x25, [x24], #24
    447c:	aa1903e1 	mov	x1, x25
    4480:	97fff8b4 	bl	2750 <__memcpy_chk@plt>
    4484:	eb18033f 	cmp	x25, x24
    4488:	540000a0 	b.eq	449c <fwp_closure_drop_push+0xac>  // b.none
    448c:	aa1903e0 	mov	x0, x25
    4490:	97fff90c 	bl	28c0 <free@plt>
    4494:	f9400674 	ldr	x20, [x19, #8]
    4498:	d37df297 	lsl	x23, x20, #3
    449c:	91000694 	add	x20, x20, #0x1
    44a0:	f9000276 	str	x22, [x19]
    44a4:	f9000a7a 	str	x26, [x19, #16]
    44a8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    44ac:	f9000674 	str	x20, [x19, #8]
    44b0:	f8376ad5 	str	x21, [x22, x23]
    44b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44c0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44c4:	d65f03c0 	ret
    44c8:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    44cc:	910a4000 	add	x0, x0, #0x290
    44d0:	97fffe4c 	bl	3e00 <fwp_trap>
    44d4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    44d8:	f947e863 	ldr	x3, [x3, #4048]
    44dc:	d2800262 	mov	x2, #0x13                  	// #19
    44e0:	d2800021 	mov	x1, #0x1                   	// #1
    44e4:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    44e8:	9103a000 	add	x0, x0, #0xe8
    44ec:	f9400063 	ldr	x3, [x3]
    44f0:	97fff904 	bl	2900 <fwrite@plt>
    44f4:	d2800000 	mov	x0, #0x0                   	// #0
    44f8:	97fff90e 	bl	2930 <fflush@plt>
    44fc:	52800cc0 	mov	w0, #0x66                  	// #102
    4500:	97fff91c 	bl	2970 <_Exit@plt>

0000000000004504 <fwp_closure_drop.part.0>:
    4504:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4508:	b0000041 	adrp	x1, d000 <__modti3+0x2c0>
    450c:	910003fd 	mov	x29, sp
    4510:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    4514:	f947f463 	ldr	x3, [x3, #4072]
    4518:	a90153f3 	stp	x19, x20, [sp, #16]
    451c:	d10883ff 	sub	sp, sp, #0x220
    4520:	910003e2 	mov	x2, sp
    4524:	d53bd053 	mrs	x19, tpidr_el0
    4528:	910063f4 	add	x20, sp, #0x18
    452c:	3dc36c20 	ldr	q0, [x1, #3504]
    4530:	91400264 	add	x4, x19, #0x0, lsl #12
    4534:	91004084 	add	x4, x4, #0x10
    4538:	aa0003e1 	mov	x1, x0
    453c:	aa0203e0 	mov	x0, x2
    4540:	f9400062 	ldr	x2, [x3]
    4544:	f9010fe2 	str	x2, [sp, #536]
    4548:	d2800002 	mov	x2, #0x0                   	// #0
    454c:	f90003f4 	str	x20, [sp]
    4550:	f9000080 	str	x0, [x4]
    4554:	3c8083e0 	stur	q0, [sp, #8]
    4558:	97ffffa6 	bl	43f0 <fwp_closure_drop_push>
    455c:	f94007e0 	ldr	x0, [sp, #8]
    4560:	b40002e0 	cbz	x0, 45bc <fwp_closure_drop.part.0+0xb8>
    4564:	f90123f5 	str	x21, [sp, #576]
    4568:	900000f5 	adrp	x21, 20000 <__data_start>
    456c:	9100c2b5 	add	x21, x21, #0x30
    4570:	14000006 	b	4588 <fwp_closure_drop.part.0+0x84>
    4574:	f9400422 	ldr	x2, [x1, #8]
    4578:	52800001 	mov	w1, #0x0                   	// #0
    457c:	d63f0040 	blr	x2
    4580:	f94007e0 	ldr	x0, [sp, #8]
    4584:	b40001a0 	cbz	x0, 45b8 <fwp_closure_drop.part.0+0xb4>
    4588:	f94003e1 	ldr	x1, [sp]
    458c:	d1000400 	sub	x0, x0, #0x1
    4590:	f90007e0 	str	x0, [sp, #8]
    4594:	f94036a2 	ldr	x2, [x21, #104]
    4598:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    459c:	b9400001 	ldr	w1, [x0]
    45a0:	8b011441 	add	x1, x2, x1, lsl #5
    45a4:	f9400c21 	ldr	x1, [x1, #24]
    45a8:	b5fffe61 	cbnz	x1, 4574 <fwp_closure_drop.part.0+0x70>
    45ac:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    45b0:	910ac000 	add	x0, x0, #0x2b0
    45b4:	97fffe13 	bl	3e00 <fwp_trap>
    45b8:	f94123f5 	ldr	x21, [sp, #576]
    45bc:	91400273 	add	x19, x19, #0x0, lsl #12
    45c0:	91004273 	add	x19, x19, #0x10
    45c4:	f94003e0 	ldr	x0, [sp]
    45c8:	f900027f 	str	xzr, [x19]
    45cc:	eb14001f 	cmp	x0, x20
    45d0:	54000040 	b.eq	45d8 <fwp_closure_drop.part.0+0xd4>  // b.none
    45d4:	97fff8bb 	bl	28c0 <free@plt>
    45d8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    45dc:	f947f400 	ldr	x0, [x0, #4072]
    45e0:	f9410fe2 	ldr	x2, [sp, #536]
    45e4:	f9400001 	ldr	x1, [x0]
    45e8:	eb010042 	subs	x2, x2, x1
    45ec:	d2800001 	mov	x1, #0x0                   	// #0
    45f0:	540000a1 	b.ne	4604 <fwp_closure_drop.part.0+0x100>  // b.any
    45f4:	910883ff 	add	sp, sp, #0x220
    45f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    45fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4600:	d65f03c0 	ret
    4604:	f90123f5 	str	x21, [sp, #576]
    4608:	97fff87e 	bl	2800 <__stack_chk_fail@plt>
    460c:	d503201f 	nop

0000000000004610 <fwp_tape_of>:
    4610:	aa0003e1 	mov	x1, x0
    4614:	92403c00 	and	x0, x0, #0xffff
    4618:	b40000e0 	cbz	x0, 4634 <fwp_tape_of+0x24>
    461c:	d1000403 	sub	x3, x0, #0x1
    4620:	900000e0 	adrp	x0, 20000 <__data_start>
    4624:	9100c002 	add	x2, x0, #0x30
    4628:	f9403842 	ldr	x2, [x2, #112]
    462c:	eb03005f 	cmp	x2, x3
    4630:	540000cc 	b.gt	4648 <fwp_tape_of+0x38>
    4634:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4638:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    463c:	910b8000 	add	x0, x0, #0x2e0
    4640:	910003fd 	mov	x29, sp
    4644:	97fffdef 	bl	3e00 <fwp_trap>
    4648:	8b030462 	add	x2, x3, x3, lsl #1
    464c:	f9401804 	ldr	x4, [x0, #48]
    4650:	d37ef442 	lsl	x2, x2, #2
    4654:	cb030042 	sub	x2, x2, x3
    4658:	d37df042 	lsl	x2, x2, #3
    465c:	8b020080 	add	x0, x4, x2
    4660:	b9400403 	ldr	w3, [x0, #4]
    4664:	34fffe83 	cbz	w3, 4634 <fwp_tape_of+0x24>
    4668:	b8626882 	ldr	w2, [x4, x2]
    466c:	9350fc21 	asr	x1, x1, #16
    4670:	6b01005f 	cmp	w2, w1
    4674:	54fffe01 	b.ne	4634 <fwp_tape_of+0x24>  // b.any
    4678:	d65f03c0 	ret
    467c:	d503201f 	nop

0000000000004680 <fwp_now_ns>:
    4680:	d100c3ff 	sub	sp, sp, #0x30
    4684:	52800020 	mov	w0, #0x1                   	// #1
    4688:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    468c:	f947f442 	ldr	x2, [x2, #4072]
    4690:	910023e1 	add	x1, sp, #0x8
    4694:	a9027bfd 	stp	x29, x30, [sp, #32]
    4698:	910083fd 	add	x29, sp, #0x20
    469c:	f9400043 	ldr	x3, [x2]
    46a0:	f9000fe3 	str	x3, [sp, #24]
    46a4:	d2800003 	mov	x3, #0x0                   	// #0
    46a8:	97fff822 	bl	2730 <clock_gettime@plt>
    46ac:	350002c0 	cbnz	w0, 4704 <fwp_now_ns+0x84>
    46b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    46b4:	d2994003 	mov	x3, #0xca00                	// #51712
    46b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    46bc:	9b037c20 	mul	x0, x1, x3
    46c0:	9b437c21 	smulh	x1, x1, x3
    46c4:	ab020000 	adds	x0, x0, x2
    46c8:	937ffc42 	asr	x2, x2, #63
    46cc:	9a020021 	adc	x1, x1, x2
    46d0:	f100001f 	cmp	x0, #0x0
    46d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    46d8:	b50001c1 	cbnz	x1, 4710 <fwp_now_ns+0x90>
    46dc:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    46e0:	f947f421 	ldr	x1, [x1, #4072]
    46e4:	f9400fe3 	ldr	x3, [sp, #24]
    46e8:	f9400022 	ldr	x2, [x1]
    46ec:	eb020063 	subs	x3, x3, x2
    46f0:	d2800002 	mov	x2, #0x0                   	// #0
    46f4:	54000141 	b.ne	471c <fwp_now_ns+0x9c>  // b.any
    46f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    46fc:	9100c3ff 	add	sp, sp, #0x30
    4700:	d65f03c0 	ret
    4704:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    4708:	910cc000 	add	x0, x0, #0x330
    470c:	97fffdbd 	bl	3e00 <fwp_trap>
    4710:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    4714:	910d4000 	add	x0, x0, #0x350
    4718:	97fffdba 	bl	3e00 <fwp_trap>
    471c:	97fff839 	bl	2800 <__stack_chk_fail@plt>

0000000000004720 <fwp_poll_events>:
    4720:	d10103ff 	sub	sp, sp, #0x40
    4724:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4728:	f947f400 	ldr	x0, [x0, #4072]
    472c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4730:	910083fd 	add	x29, sp, #0x20
    4734:	f9001bf3 	str	x19, [sp, #48]
    4738:	900000f3 	adrp	x19, 20000 <__data_start>
    473c:	f9400001 	ldr	x1, [x0]
    4740:	f9000fe1 	str	x1, [sp, #24]
    4744:	d2800001 	mov	x1, #0x0                   	// #0
    4748:	97ffffce 	bl	4680 <fwp_now_ns>
    474c:	9100c261 	add	x1, x19, #0x30
    4750:	f9403c21 	ldr	x1, [x1, #120]
    4754:	b4000e01 	cbz	x1, 4914 <fwp_poll_events+0x1f4>
    4758:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    475c:	14000005 	b	4770 <fwp_poll_events+0x50>
    4760:	f9408821 	ldr	x1, [x1, #272]
    4764:	eb03005f 	cmp	x2, x3
    4768:	9a83d042 	csel	x2, x2, x3, le
    476c:	b40000c1 	cbz	x1, 4784 <fwp_poll_events+0x64>
    4770:	f9403423 	ldr	x3, [x1, #104]
    4774:	b6ffff62 	tbz	x2, #63, 4760 <fwp_poll_events+0x40>
    4778:	f9408821 	ldr	x1, [x1, #272]
    477c:	aa0303e2 	mov	x2, x3
    4780:	b5ffff81 	cbnz	x1, 4770 <fwp_poll_events+0x50>
    4784:	b7f80c82 	tbnz	x2, #63, 4914 <fwp_poll_events+0x1f4>
    4788:	cb000042 	sub	x2, x2, x0
    478c:	f100005f 	cmp	x2, #0x0
    4790:	540003ad 	b.le	4804 <fwp_poll_events+0xe4>
    4794:	d2869b60 	mov	x0, #0x34db                	// #13531
    4798:	d2884804 	mov	x4, #0x4240                	// #16960
    479c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    47a0:	f2a001e4 	movk	x4, #0xf, lsl #16
    47a4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    47a8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    47ac:	f2e86360 	movk	x0, #0x431b, lsl #48
    47b0:	9b407c40 	smulh	x0, x2, x0
    47b4:	9352fc00 	asr	x0, x0, #18
    47b8:	cb82fc00 	sub	x0, x0, x2, asr #63
    47bc:	9b048802 	msub	x2, x0, x4, x2
    47c0:	f100005f 	cmp	x2, #0x0
    47c4:	9a800400 	cinc	x0, x0, ne	// ne = any
    47c8:	eb01001f 	cmp	x0, x1
    47cc:	5400098c 	b.gt	48fc <fwp_poll_events+0x1dc>
    47d0:	340001a0 	cbz	w0, 4804 <fwp_poll_events+0xe4>
    47d4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    47d8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    47dc:	72a20c41 	movk	w1, #0x1062, lsl #16
    47e0:	9ba17c01 	umull	x1, w0, w1
    47e4:	d366fc23 	lsr	x3, x1, #38
    47e8:	aa0303e2 	mov	x2, x3
    47ec:	1b058063 	msub	w3, w3, w5, w0
    47f0:	9b247c63 	smull	x3, w3, w4
    47f4:	910023e0 	add	x0, sp, #0x8
    47f8:	d2800001 	mov	x1, #0x0                   	// #0
    47fc:	a9008fe2 	stp	x2, x3, [sp, #8]
    4800:	97fff834 	bl	28d0 <nanosleep@plt>
    4804:	97ffff9f 	bl	4680 <fwp_now_ns>
    4808:	9100c268 	add	x8, x19, #0x30
    480c:	aa0003e7 	mov	x7, x0
    4810:	4f000400 	movi	v0.4s, #0x0
    4814:	52800029 	mov	w9, #0x1                   	// #1
    4818:	f9403d06 	ldr	x6, [x8, #120]
    481c:	d503201f 	nop
    4820:	b40003e6 	cbz	x6, 489c <fwp_poll_events+0x17c>
    4824:	f94034c1 	ldr	x1, [x6, #104]
    4828:	aa0603e5 	mov	x5, x6
    482c:	f94088c6 	ldr	x6, [x6, #272]
    4830:	eb07003f 	cmp	x1, x7
    4834:	54ffff6c 	b.gt	4820 <fwp_poll_events+0x100>
    4838:	394154a0 	ldrb	w0, [x5, #85]
    483c:	36000120 	tbz	w0, #0, 4860 <fwp_poll_events+0x140>
    4840:	f94084a0 	ldr	x0, [x5, #264]
    4844:	b4000560 	cbz	x0, 48f0 <fwp_poll_events+0x1d0>
    4848:	f9008806 	str	x6, [x0, #272]
    484c:	b4000046 	cbz	x6, 4854 <fwp_poll_events+0x134>
    4850:	f90084c0 	str	x0, [x6, #264]
    4854:	910800a0 	add	x0, x5, #0x200
    4858:	390154bf 	strb	wzr, [x5, #85]
    485c:	3c908000 	stur	q0, [x0, #-248]
    4860:	f94030a0 	ldr	x0, [x5, #96]
    4864:	390158a9 	strb	w9, [x5, #86]
    4868:	f100001f 	cmp	x0, #0x0
    486c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4870:	540002cd 	b.le	48c8 <fwp_poll_events+0x1a8>
    4874:	f94028a0 	ldr	x0, [x5, #80]
    4878:	f2001c1f 	tst	x0, #0xff000000ff
    487c:	54fffd21 	b.ne	4820 <fwp_poll_events+0x100>  // b.any
    4880:	f9401500 	ldr	x0, [x8, #40]
    4884:	390150a9 	strb	w9, [x5, #84]
    4888:	f90080bf 	str	xzr, [x5, #256]
    488c:	b40002c0 	cbz	x0, 48e4 <fwp_poll_events+0x1c4>
    4890:	f9001505 	str	x5, [x8, #40]
    4894:	f9008005 	str	x5, [x0, #256]
    4898:	b5fffc66 	cbnz	x6, 4824 <fwp_poll_events+0x104>
    489c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    48a0:	f947f400 	ldr	x0, [x0, #4072]
    48a4:	f9400fe2 	ldr	x2, [sp, #24]
    48a8:	f9400001 	ldr	x1, [x0]
    48ac:	eb010042 	subs	x2, x2, x1
    48b0:	d2800001 	mov	x1, #0x0                   	// #0
    48b4:	540002e1 	b.ne	4910 <fwp_poll_events+0x1f0>  // b.any
    48b8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    48bc:	f9401bf3 	ldr	x19, [sp, #48]
    48c0:	910103ff 	add	sp, sp, #0x40
    48c4:	d65f03c0 	ret
    48c8:	394144a0 	ldrb	w0, [x5, #81]
    48cc:	3707fd40 	tbnz	w0, #0, 4874 <fwp_poll_events+0x154>
    48d0:	394140a0 	ldrb	w0, [x5, #80]
    48d4:	3707fd00 	tbnz	w0, #0, 4874 <fwp_poll_events+0x154>
    48d8:	aa0503e0 	mov	x0, x5
    48dc:	97fffac5 	bl	33f0 <fwp_cancel_tree.part.0>
    48e0:	17ffffe5 	b	4874 <fwp_poll_events+0x154>
    48e4:	f9001505 	str	x5, [x8, #40]
    48e8:	f9001905 	str	x5, [x8, #48]
    48ec:	17ffffeb 	b	4898 <fwp_poll_events+0x178>
    48f0:	9100c261 	add	x1, x19, #0x30
    48f4:	f9003c26 	str	x6, [x1, #120]
    48f8:	17ffffd5 	b	484c <fwp_poll_events+0x12c>
    48fc:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4900:	d2989362 	mov	x2, #0xc49b                	// #50331
    4904:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4908:	f2a00402 	movk	x2, #0x20, lsl #16
    490c:	17ffffba 	b	47f4 <fwp_poll_events+0xd4>
    4910:	97fff7bc 	bl	2800 <__stack_chk_fail@plt>
    4914:	97fff997 	bl	2f70 <fwp_flush>
    4918:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    491c:	f947e863 	ldr	x3, [x3, #4048]
    4920:	d2800562 	mov	x2, #0x2b                  	// #43
    4924:	d2800021 	mov	x1, #0x1                   	// #1
    4928:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    492c:	910de000 	add	x0, x0, #0x378
    4930:	f9400063 	ldr	x3, [x3]
    4934:	97fff7f3 	bl	2900 <fwrite@plt>
    4938:	52800ca0 	mov	w0, #0x65                  	// #101
    493c:	97fff75d 	bl	26b0 <exit@plt>

0000000000004940 <fwp_heap_alloc_big>:
    4940:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4944:	910003fd 	mov	x29, sp
    4948:	a90153f3 	stp	x19, x20, [sp, #16]
    494c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4950:	a90363f7 	stp	x23, x24, [sp, #48]
    4954:	aa0003f7 	mov	x23, x0
    4958:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    495c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4960:	eb0002ff 	cmp	x23, x0
    4964:	540008a8 	b.hi	4a78 <fwp_heap_alloc_big+0x138>  // b.pmore
    4968:	d29fffe0 	mov	x0, #0xffff                	// #65535
    496c:	8b0002f4 	add	x20, x23, x0
    4970:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xcb0>
    4974:	9114c359 	add	x25, x26, #0x530
    4978:	d350fe94 	lsr	x20, x20, #16
    497c:	2a0103f5 	mov	w21, w1
    4980:	aa1403e0 	mov	x0, x20
    4984:	97fff9cb 	bl	30b0 <fwp_heap_chunks>
    4988:	f949ff22 	ldr	x2, [x25, #5112]
    498c:	8b000813 	add	x19, x0, x0, lsl #2
    4990:	aa0003f8 	mov	x24, x0
    4994:	52800043 	mov	w3, #0x2                   	// #2
    4998:	d37df273 	lsl	x19, x19, #3
    499c:	d2800021 	mov	x1, #0x1                   	// #1
    49a0:	8b130040 	add	x0, x2, x19
    49a4:	38336843 	strb	w3, [x2, x19]
    49a8:	39000415 	strb	w21, [x0, #1]
    49ac:	b9000c14 	str	w20, [x0, #12]
    49b0:	f9000817 	str	x23, [x0, #16]
    49b4:	97fffd57 	bl	3f10 <fwp_rc_prepare_chunk>
    49b8:	f100069f 	cmp	x20, #0x1
    49bc:	54000289 	b.ls	4a0c <fwp_heap_alloc_big+0xcc>  // b.plast
    49c0:	8b180294 	add	x20, x20, x24
    49c4:	9100a273 	add	x19, x19, #0x28
    49c8:	a90573fb 	stp	x27, x28, [sp, #80]
    49cc:	5280007b 	mov	w27, #0x3                   	// #3
    49d0:	8b140a94 	add	x20, x20, x20, lsl #2
    49d4:	2a1803fc 	mov	w28, w24
    49d8:	9adb2296 	lsl	x22, x20, x27
    49dc:	d503201f 	nop
    49e0:	f949ff35 	ldr	x21, [x25, #5112]
    49e4:	d2800001 	mov	x1, #0x0                   	// #0
    49e8:	8b1302b4 	add	x20, x21, x19
    49ec:	aa1403e0 	mov	x0, x20
    49f0:	97fffd48 	bl	3f10 <fwp_rc_prepare_chunk>
    49f4:	38336abb 	strb	w27, [x21, x19]
    49f8:	9100a273 	add	x19, x19, #0x28
    49fc:	b9000e9c 	str	w28, [x20, #12]
    4a00:	eb1302df 	cmp	x22, x19
    4a04:	54fffee1 	b.ne	49e0 <fwp_heap_alloc_big+0xa0>  // b.any
    4a08:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a0c:	9114c353 	add	x19, x26, #0x530
    4a10:	aa1703e2 	mov	x2, x23
    4a14:	52800001 	mov	w1, #0x0                   	// #0
    4a18:	f949da60 	ldr	x0, [x19, #5040]
    4a1c:	8b184018 	add	x24, x0, x24, lsl #16
    4a20:	aa1803e0 	mov	x0, x24
    4a24:	97fff76b 	bl	27d0 <memset@plt>
    4a28:	f94a1260 	ldr	x0, [x19, #5152]
    4a2c:	ab170000 	adds	x0, x0, x23
    4a30:	54000242 	b.cs	4a78 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4a34:	f94a1661 	ldr	x1, [x19, #5160]
    4a38:	f90a1260 	str	x0, [x19, #5152]
    4a3c:	eb01001f 	cmp	x0, x1
    4a40:	54000049 	b.ls	4a48 <fwp_heap_alloc_big+0x108>  // b.plast
    4a44:	f90a1660 	str	x0, [x19, #5160]
    4a48:	9114c35a 	add	x26, x26, #0x530
    4a4c:	9e6202e0 	scvtf	d0, x23
    4a50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a54:	aa1803e0 	mov	x0, x24
    4a58:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a60:	1e602820 	fadd	d0, d1, d0
    4a64:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a68:	fd0a1f40 	str	d0, [x26, #5176]
    4a6c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a70:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a74:	d65f03c0 	ret
    4a78:	a90573fb 	stp	x27, x28, [sp, #80]
    4a7c:	97fff94d 	bl	2fb0 <fwp_heap_oom>

0000000000004a80 <fwp_heap_alloc_slow>:
    4a80:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a84:	910003fd 	mov	x29, sp
    4a88:	a90153f3 	stp	x19, x20, [sp, #16]
    4a8c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    4a90:	9114c262 	add	x2, x19, #0x530
    4a94:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a98:	aa0003f5 	mov	x21, x0
    4a9c:	2a0103f4 	mov	w20, w1
    4aa0:	b953a440 	ldr	w0, [x2, #5028]
    4aa4:	34000600 	cbz	w0, 4b64 <fwp_heap_alloc_slow+0xe4>
    4aa8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4aac:	54000628 	b.hi	4b70 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ab0:	91003ea0 	add	x0, x21, #0xf
    4ab4:	9114c262 	add	x2, x19, #0x530
    4ab8:	f9001bf7 	str	x23, [sp, #48]
    4abc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ac0:	8b401040 	add	x0, x2, x0, lsr #4
    4ac4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ac8:	d37ae484 	lsl	x4, x4, #6
    4acc:	397e8003 	ldrb	w3, [x0, #4000]
    4ad0:	910f0060 	add	x0, x3, #0x3c0
    4ad4:	aa0303e1 	mov	x1, x3
    4ad8:	8b030463 	add	x3, x3, x3, lsl #1
    4adc:	8b030c83 	add	x3, x4, x3, lsl #3
    4ae0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4ae4:	2a1703f6 	mov	w22, w23
    4ae8:	f8636844 	ldr	x4, [x2, x3]
    4aec:	b40004e4 	cbz	x4, 4b88 <fwp_heap_alloc_slow+0x108>
    4af0:	f9400080 	ldr	x0, [x4]
    4af4:	aa2003e0 	mvn	x0, x0
    4af8:	f8236840 	str	x0, [x2, x3]
    4afc:	7100069f 	cmp	w20, #0x1
    4b00:	aa0403e0 	mov	x0, x4
    4b04:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b08:	52800001 	mov	w1, #0x0                   	// #0
    4b0c:	97fff731 	bl	27d0 <memset@plt>
    4b10:	aa0003e4 	mov	x4, x0
    4b14:	9114c260 	add	x0, x19, #0x530
    4b18:	f94a1001 	ldr	x1, [x0, #5152]
    4b1c:	ab160021 	adds	x1, x1, x22
    4b20:	540005c2 	b.cs	4bd8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b24:	f94a1402 	ldr	x2, [x0, #5160]
    4b28:	f90a1001 	str	x1, [x0, #5152]
    4b2c:	eb02003f 	cmp	x1, x2
    4b30:	54000049 	b.ls	4b38 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b34:	f90a1401 	str	x1, [x0, #5160]
    4b38:	9114c273 	add	x19, x19, #0x530
    4b3c:	1e6302e1 	ucvtf	d1, w23
    4b40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b44:	aa0403e0 	mov	x0, x4
    4b48:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b4c:	f9401bf7 	ldr	x23, [sp, #48]
    4b50:	1e612800 	fadd	d0, d0, d1
    4b54:	fd0a1e60 	str	d0, [x19, #5176]
    4b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b60:	d65f03c0 	ret
    4b64:	97fffbc3 	bl	3a70 <fwp_heap_init>
    4b68:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b6c:	54fffa29 	b.ls	4ab0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b70:	2a1403e1 	mov	w1, w20
    4b74:	aa1503e0 	mov	x0, x21
    4b78:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b80:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b84:	17ffff6f 	b	4940 <fwp_heap_alloc_big>
    4b88:	8b030042 	add	x2, x2, x3
    4b8c:	f9400444 	ldr	x4, [x2, #8]
    4b90:	b4000104 	cbz	x4, 4bb0 <fwp_heap_alloc_slow+0x130>
    4b94:	f9400840 	ldr	x0, [x2, #16]
    4b98:	cb040000 	sub	x0, x0, x4
    4b9c:	eb16001f 	cmp	x0, x22
    4ba0:	54000083 	b.cc	4bb0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4ba4:	8b160080 	add	x0, x4, x22
    4ba8:	f9000440 	str	x0, [x2, #8]
    4bac:	17ffffd4 	b	4afc <fwp_heap_alloc_slow+0x7c>
    4bb0:	52800302 	mov	w2, #0x18                  	// #24
    4bb4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bb8:	9114c260 	add	x0, x19, #0x530
    4bbc:	9ba27c23 	umull	x3, w1, w2
    4bc0:	2a1403e2 	mov	w2, w20
    4bc4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bc8:	8b040000 	add	x0, x0, x4
    4bcc:	97fffd19 	bl	4030 <fwp_heap_refill>
    4bd0:	aa0003e4 	mov	x4, x0
    4bd4:	17ffffca 	b	4afc <fwp_heap_alloc_slow+0x7c>
    4bd8:	97fff8f6 	bl	2fb0 <fwp_heap_oom>
    4bdc:	d503201f 	nop

0000000000004be0 <fwp_heap_alloc>:
    4be0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4be4:	f140101f 	cmp	x0, #0x4, lsl #12
    4be8:	910003fd 	mov	x29, sp
    4bec:	a90153f3 	stp	x19, x20, [sp, #16]
    4bf0:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    4bf4:	9114c293 	add	x19, x20, #0x530
    4bf8:	b953a662 	ldr	w2, [x19, #5028]
    4bfc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c00:	54000640 	b.eq	4cc8 <fwp_heap_alloc+0xe8>  // b.none
    4c04:	91003c03 	add	x3, x0, #0xf
    4c08:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c0c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c10:	8b431263 	add	x3, x19, x3, lsr #4
    4c14:	cb21c042 	sub	x2, x2, w1, sxtw
    4c18:	d37ae442 	lsl	x2, x2, #6
    4c1c:	397e8063 	ldrb	w3, [x3, #4000]
    4c20:	910f0064 	add	x4, x3, #0x3c0
    4c24:	8b030463 	add	x3, x3, x3, lsl #1
    4c28:	8b030c43 	add	x3, x2, x3, lsl #3
    4c2c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c30:	2a1603f5 	mov	w21, w22
    4c34:	f8636a64 	ldr	x4, [x19, x3]
    4c38:	b4000384 	cbz	x4, 4ca8 <fwp_heap_alloc+0xc8>
    4c3c:	f9400085 	ldr	x5, [x4]
    4c40:	7100043f 	cmp	w1, #0x1
    4c44:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c48:	aa0403e0 	mov	x0, x4
    4c4c:	aa2503e5 	mvn	x5, x5
    4c50:	52800001 	mov	w1, #0x0                   	// #0
    4c54:	f8236a65 	str	x5, [x19, x3]
    4c58:	97fff6de 	bl	27d0 <memset@plt>
    4c5c:	aa0003e4 	mov	x4, x0
    4c60:	f94a1260 	ldr	x0, [x19, #5152]
    4c64:	ab150000 	adds	x0, x0, x21
    4c68:	54000442 	b.cs	4cf0 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c6c:	f94a1661 	ldr	x1, [x19, #5160]
    4c70:	f90a1260 	str	x0, [x19, #5152]
    4c74:	eb01001f 	cmp	x0, x1
    4c78:	54000049 	b.ls	4c80 <fwp_heap_alloc+0xa0>  // b.plast
    4c7c:	f90a1660 	str	x0, [x19, #5160]
    4c80:	9114c294 	add	x20, x20, #0x530
    4c84:	1e6302c1 	ucvtf	d1, w22
    4c88:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c8c:	aa0403e0 	mov	x0, x4
    4c90:	fd4a1e80 	ldr	d0, [x20, #5176]
    4c94:	1e612800 	fadd	d0, d0, d1
    4c98:	fd0a1e80 	str	d0, [x20, #5176]
    4c9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ca0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ca4:	d65f03c0 	ret
    4ca8:	8b030263 	add	x3, x19, x3
    4cac:	f9400464 	ldr	x4, [x3, #8]
    4cb0:	b40000a4 	cbz	x4, 4cc4 <fwp_heap_alloc+0xe4>
    4cb4:	f9400862 	ldr	x2, [x3, #16]
    4cb8:	cb040042 	sub	x2, x2, x4
    4cbc:	eb15005f 	cmp	x2, x21
    4cc0:	540000a2 	b.cs	4cd4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cc4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ccc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cd0:	17ffff6c 	b	4a80 <fwp_heap_alloc_slow>
    4cd4:	7100043f 	cmp	w1, #0x1
    4cd8:	8b150085 	add	x5, x4, x21
    4cdc:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	aa0403e0 	mov	x0, x4
    4ce8:	f9000465 	str	x5, [x3, #8]
    4cec:	17ffffdb 	b	4c58 <fwp_heap_alloc+0x78>
    4cf0:	97fff8b0 	bl	2fb0 <fwp_heap_oom>

0000000000004cf4 <fwp_data.part.0.constprop.0>:
    4cf4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4cf8:	910003fd 	mov	x29, sp
    4cfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4d00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    4d04:	9114c283 	add	x3, x20, #0x530
    4d08:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d0c:	aa0103f5 	mov	x21, x1
    4d10:	b953a461 	ldr	w1, [x3, #5028]
    4d14:	a90363f7 	stp	x23, x24, [sp, #48]
    4d18:	2a0003f8 	mov	w24, w0
    4d1c:	34000701 	cbz	w1, 4dfc <fwp_data.part.0.constprop.0+0x108>
    4d20:	397e8862 	ldrb	w2, [x3, #4002]
    4d24:	910f0040 	add	x0, x2, #0x3c0
    4d28:	8b020442 	add	x2, x2, x2, lsl #1
    4d2c:	d37df042 	lsl	x2, x2, #3
    4d30:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4d34:	2a1703f6 	mov	w22, w23
    4d38:	f8626873 	ldr	x19, [x3, x2]
    4d3c:	b40004d3 	cbz	x19, 4dd4 <fwp_data.part.0.constprop.0+0xe0>
    4d40:	f9400260 	ldr	x0, [x19]
    4d44:	aa2003e0 	mvn	x0, x0
    4d48:	f8226860 	str	x0, [x3, x2]
    4d4c:	f10062df 	cmp	x22, #0x18
    4d50:	540000e9 	b.ls	4d6c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4d54:	d10066c2 	sub	x2, x22, #0x19
    4d58:	91006260 	add	x0, x19, #0x18
    4d5c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4d60:	52800001 	mov	w1, #0x0                   	// #0
    4d64:	91002042 	add	x2, x2, #0x8
    4d68:	97fff69a 	bl	27d0 <memset@plt>
    4d6c:	9114c282 	add	x2, x20, #0x530
    4d70:	f94a1041 	ldr	x1, [x2, #5152]
    4d74:	ab160021 	adds	x1, x1, x22
    4d78:	540004c2 	b.cs	4e10 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4d7c:	f94a1440 	ldr	x0, [x2, #5160]
    4d80:	f90a1041 	str	x1, [x2, #5152]
    4d84:	eb00003f 	cmp	x1, x0
    4d88:	54000049 	b.ls	4d90 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4d8c:	f90a1441 	str	x1, [x2, #5160]
    4d90:	9114c294 	add	x20, x20, #0x530
    4d94:	1e6302e1 	ucvtf	d1, w23
    4d98:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d9c:	1e612800 	fadd	d0, d0, d1
    4da0:	fd0a1e80 	str	d0, [x20, #5176]
    4da4:	52800041 	mov	w1, #0x2                   	// #2
    4da8:	29000678 	stp	w24, w1, [x19]
    4dac:	aa1303e0 	mov	x0, x19
    4db0:	f94002a1 	ldr	x1, [x21]
    4db4:	f9000661 	str	x1, [x19, #8]
    4db8:	f94006a1 	ldr	x1, [x21, #8]
    4dbc:	f9000a61 	str	x1, [x19, #16]
    4dc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4dc4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4dc8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dcc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4dd0:	d65f03c0 	ret
    4dd4:	8b020063 	add	x3, x3, x2
    4dd8:	f9400473 	ldr	x19, [x3, #8]
    4ddc:	b4000113 	cbz	x19, 4dfc <fwp_data.part.0.constprop.0+0x108>
    4de0:	f9400860 	ldr	x0, [x3, #16]
    4de4:	cb130000 	sub	x0, x0, x19
    4de8:	eb0002df 	cmp	x22, x0
    4dec:	54000088 	b.hi	4dfc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4df0:	8b160260 	add	x0, x19, x22
    4df4:	f9000460 	str	x0, [x3, #8]
    4df8:	17ffffd5 	b	4d4c <fwp_data.part.0.constprop.0+0x58>
    4dfc:	52800001 	mov	w1, #0x0                   	// #0
    4e00:	d2800300 	mov	x0, #0x18                  	// #24
    4e04:	97ffff77 	bl	4be0 <fwp_heap_alloc>
    4e08:	aa0003f3 	mov	x19, x0
    4e0c:	17ffffe6 	b	4da4 <fwp_data.part.0.constprop.0+0xb0>
    4e10:	97fff868 	bl	2fb0 <fwp_heap_oom>

0000000000004e14 <fwp_tape_grow.constprop.0>:
    4e14:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4e18:	d2800802 	mov	x2, #0x40                  	// #64
    4e1c:	910003fd 	mov	x29, sp
    4e20:	a90153f3 	stp	x19, x20, [sp, #16]
    4e24:	aa0003f4 	mov	x20, x0
    4e28:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    4e2c:	f9400e93 	ldr	x19, [x20, #24]
    4e30:	f100027f 	cmp	x19, #0x0
    4e34:	9a821273 	csel	x19, x19, x2, ne	// ne = any
    4e38:	eb13003f 	cmp	x1, x19
    4e3c:	540000ed 	b.le	4e58 <fwp_tape_grow.constprop.0+0x44>
    4e40:	eb00027f 	cmp	x19, x0
    4e44:	5400064d 	b.le	4f0c <fwp_tape_grow.constprop.0+0xf8>
    4e48:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    4e4c:	eb13003f 	cmp	x1, x19
    4e50:	5400004d 	b.le	4e58 <fwp_tape_grow.constprop.0+0x44>
    4e54:	14000000 	b	4e54 <fwp_tape_grow.constprop.0+0x40>
    4e58:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e5c:	f9402a95 	ldr	x21, [x20, #80]
    4e60:	b40005b5 	cbz	x21, 4f14 <fwp_tape_grow.constprop.0+0x100>
    4e64:	f9401680 	ldr	x0, [x20, #40]
    4e68:	d37df261 	lsl	x1, x19, #3
    4e6c:	97fff661 	bl	27f0 <realloc@plt>
    4e70:	b40006e0 	cbz	x0, 4f4c <fwp_tape_grow.constprop.0+0x138>
    4e74:	f94032b6 	ldr	x22, [x21, #96]
    4e78:	f9001680 	str	x0, [x20, #40]
    4e7c:	eb1302df 	cmp	x22, x19
    4e80:	540003ca 	b.ge	4ef8 <fwp_tape_grow.constprop.0+0xe4>  // b.tcont
    4e84:	a90363f7 	stp	x23, x24, [sp, #48]
    4e88:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    4e8c:	f90023f9 	str	x25, [sp, #64]
    4e90:	eb00027f 	cmp	x19, x0
    4e94:	54000568 	b.hi	4f40 <fwp_tape_grow.constprop.0+0x12c>  // b.pmore
    4e98:	f94022b8 	ldr	x24, [x21, #64]
    4e9c:	d37cee79 	lsl	x25, x19, #4
    4ea0:	aa1903e0 	mov	x0, x25
    4ea4:	52800041 	mov	w1, #0x2                   	// #2
    4ea8:	97ffff4e 	bl	4be0 <fwp_heap_alloc>
    4eac:	aa0003f7 	mov	x23, x0
    4eb0:	b4000118 	cbz	x24, 4ed0 <fwp_tape_grow.constprop.0+0xbc>
    4eb4:	d37ceed6 	lsl	x22, x22, #4
    4eb8:	aa1803e1 	mov	x1, x24
    4ebc:	eb1902df 	cmp	x22, x25
    4ec0:	9a9992c2 	csel	x2, x22, x25, ls	// ls = plast
    4ec4:	97fff5e7 	bl	2660 <memcpy@plt>
    4ec8:	aa1803e0 	mov	x0, x24
    4ecc:	97fffc89 	bl	40f0 <fwp_mem_free>
    4ed0:	f94032a0 	ldr	x0, [x21, #96]
    4ed4:	52800001 	mov	w1, #0x0                   	// #0
    4ed8:	cb000262 	sub	x2, x19, x0
    4edc:	8b0012e0 	add	x0, x23, x0, lsl #4
    4ee0:	d37cec42 	lsl	x2, x2, #4
    4ee4:	97fff63b 	bl	27d0 <memset@plt>
    4ee8:	f94023f9 	ldr	x25, [sp, #64]
    4eec:	f90022b7 	str	x23, [x21, #64]
    4ef0:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ef4:	f90032b3 	str	x19, [x21, #96]
    4ef8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4efc:	f9000e93 	str	x19, [x20, #24]
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4f08:	d65f03c0 	ret
    4f0c:	d37ffa73 	lsl	x19, x19, #1
    4f10:	17ffffca 	b	4e38 <fwp_tape_grow.constprop.0+0x24>
    4f14:	f9401280 	ldr	x0, [x20, #32]
    4f18:	8b130661 	add	x1, x19, x19, lsl #1
    4f1c:	d37df021 	lsl	x1, x1, #3
    4f20:	97fff634 	bl	27f0 <realloc@plt>
    4f24:	b4000140 	cbz	x0, 4f4c <fwp_tape_grow.constprop.0+0x138>
    4f28:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f2c:	f9000e93 	str	x19, [x20, #24]
    4f30:	f9001280 	str	x0, [x20, #32]
    4f34:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f38:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4f3c:	d65f03c0 	ret
    4f40:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    4f44:	910f4000 	add	x0, x0, #0x3d0
    4f48:	97fffbae 	bl	3e00 <fwp_trap>
    4f4c:	aa1403e0 	mov	x0, x20
    4f50:	a90363f7 	stp	x23, x24, [sp, #48]
    4f54:	f90023f9 	str	x25, [sp, #64]
    4f58:	97fff7ee 	bl	2f10 <fwp_tape_unlink_scope>
    4f5c:	f9401280 	ldr	x0, [x20, #32]
    4f60:	97fff658 	bl	28c0 <free@plt>
    4f64:	f9401680 	ldr	x0, [x20, #40]
    4f68:	97fff656 	bl	28c0 <free@plt>
    4f6c:	f9401a80 	ldr	x0, [x20, #48]
    4f70:	97fff654 	bl	28c0 <free@plt>
    4f74:	f9000e9f 	str	xzr, [x20, #24]
    4f78:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    4f7c:	f947e821 	ldr	x1, [x1, #4048]
    4f80:	a9037e9f 	stp	xzr, xzr, [x20, #48]
    4f84:	d2800262 	mov	x2, #0x13                  	// #19
    4f88:	4f000400 	movi	v0.4s, #0x0
    4f8c:	b0000040 	adrp	x0, d000 <__modti3+0x2c0>
    4f90:	f9400023 	ldr	x3, [x1]
    4f94:	b900069f 	str	wzr, [x20, #4]
    4f98:	d2800021 	mov	x1, #0x1                   	// #1
    4f9c:	9103a000 	add	x0, x0, #0xe8
    4fa0:	3c808280 	stur	q0, [x20, #8]
    4fa4:	3d800a80 	str	q0, [x20, #32]
    4fa8:	97fff656 	bl	2900 <fwrite@plt>
    4fac:	d2800000 	mov	x0, #0x0                   	// #0
    4fb0:	97fff660 	bl	2930 <fflush@plt>
    4fb4:	52800cc0 	mov	w0, #0x66                  	// #102
    4fb8:	97fff66e 	bl	2970 <_Exit@plt>
    4fbc:	d503201f 	nop

0000000000004fc0 <w123>:
    4fc0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4fc4:	910003fd 	mov	x29, sp
    4fc8:	6d0427e8 	stp	d8, d9, [sp, #64]
    4fcc:	1e612808 	fadd	d8, d0, d1
    4fd0:	ea01001f 	tst	x0, x1
    4fd4:	54000b44 	b.mi	513c <w123+0x17c>  // b.first
    4fd8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fdc:	aa0003f4 	mov	x20, x0
    4fe0:	aa0103f3 	mov	x19, x1
    4fe4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fe8:	aa010000 	orr	x0, x0, x1
    4fec:	aa0203f5 	mov	x21, x2
    4ff0:	f9001bf7 	str	x23, [sp, #48]
    4ff4:	b7f80200 	tbnz	x0, #63, 5034 <w123+0x74>
    4ff8:	9360fc37 	asr	x23, x1, #32
    4ffc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5000:	eb9482ff 	cmp	x23, x20, asr #32
    5004:	54000a61 	b.ne	5150 <w123+0x190>  // b.any
    5008:	f94002a0 	ldr	x0, [x21]
    500c:	eb17001f 	cmp	x0, x23
    5010:	54000220 	b.eq	5054 <w123+0x94>  // b.none
    5014:	aa1703e0 	mov	x0, x23
    5018:	97fffd7e 	bl	4610 <fwp_tape_of>
    501c:	aa0003f6 	mov	x22, x0
    5020:	f9402800 	ldr	x0, [x0, #80]
    5024:	b40002e0 	cbz	x0, 5080 <w123+0xc0>
    5028:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    502c:	9110e000 	add	x0, x0, #0x438
    5030:	97fffb74 	bl	3e00 <fwp_trap>
    5034:	b6f80214 	tbz	x20, #63, 5074 <w123+0xb4>
    5038:	f94002a0 	ldr	x0, [x21]
    503c:	9360fc37 	asr	x23, x1, #32
    5040:	2f00e409 	movi	d9, #0x0
    5044:	aa0103f4 	mov	x20, x1
    5048:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    504c:	eb17001f 	cmp	x0, x23
    5050:	54fffe21 	b.ne	5014 <w123+0x54>  // b.any
    5054:	f94006b6 	ldr	x22, [x21, #8]
    5058:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    505c:	f9400ad7 	ldr	x23, [x22, #16]
    5060:	eb0002ff 	cmp	x23, x0
    5064:	5400018d 	b.le	5094 <w123+0xd4>
    5068:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    506c:	910f4000 	add	x0, x0, #0x3d0
    5070:	97fffb64 	bl	3e00 <fwp_trap>
    5074:	9360fe97 	asr	x23, x20, #32
    5078:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    507c:	17ffffe3 	b	5008 <w123+0x48>
    5080:	a9005ab7 	stp	x23, x22, [x21]
    5084:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5088:	f9400ad7 	ldr	x23, [x22, #16]
    508c:	eb0002ff 	cmp	x23, x0
    5090:	54fffecc 	b.gt	5068 <w123+0xa8>
    5094:	eb3442ff 	cmp	x23, w20, uxtw
    5098:	540004cd 	b.le	5130 <w123+0x170>
    509c:	b7f80073 	tbnz	x19, #63, 50a8 <w123+0xe8>
    50a0:	eb3342ff 	cmp	x23, w19, uxtw
    50a4:	5400046d 	b.le	5130 <w123+0x170>
    50a8:	f94006d5 	ldr	x21, [x22, #8]
    50ac:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    50b0:	cb1502f5 	sub	x21, x23, x21
    50b4:	910006a1 	add	x1, x21, #0x1
    50b8:	eb00003f 	cmp	x1, x0
    50bc:	54fffd68 	b.hi	5068 <w123+0xa8>  // b.pmore
    50c0:	f9400ec0 	ldr	x0, [x22, #24]
    50c4:	eb00003f 	cmp	x1, x0
    50c8:	5400006d 	b.le	50d4 <w123+0x114>
    50cc:	aa1603e0 	mov	x0, x22
    50d0:	97ffff51 	bl	4e14 <fwp_tape_grow.constprop.0>
    50d4:	f100027f 	cmp	x19, #0x0
    50d8:	9e670282 	fmov	d2, x20
    50dc:	da9fa273 	csinv	x19, x19, xzr, ge	// ge = tcont
    50e0:	8b1506b5 	add	x21, x21, x21, lsl #1
    50e4:	f94012c2 	ldr	x2, [x22, #32]
    50e8:	4e181e62 	mov	v2.d[1], x19
    50ec:	d37df2b5 	lsl	x21, x21, #3
    50f0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    50f4:	8b150040 	add	x0, x2, x21
    50f8:	92607e81 	and	x1, x20, #0xffffffff00000000
    50fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5100:	aa170021 	orr	x1, x1, x23
    5104:	0ea12842 	xtn	v2.2s, v2.2d
    5108:	910006f7 	add	x23, x23, #0x1
    510c:	fc356842 	str	d2, [x2, x21]
    5110:	6d00a400 	stp	d0, d9, [x0, #8]
    5114:	9e660100 	fmov	x0, d8
    5118:	f9000ad7 	str	x23, [x22, #16]
    511c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5120:	f9401bf7 	ldr	x23, [sp, #48]
    5124:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5128:	a8c57bfd 	ldp	x29, x30, [sp], #80
    512c:	d65f03c0 	ret
    5130:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    5134:	9111a000 	add	x0, x0, #0x468
    5138:	97fffb32 	bl	3e00 <fwp_trap>
    513c:	9e660100 	fmov	x0, d8
    5140:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    5144:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5148:	a8c57bfd 	ldp	x29, x30, [sp], #80
    514c:	d65f03c0 	ret
    5150:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    5154:	910fc000 	add	x0, x0, #0x3f0
    5158:	97fffb2a 	bl	3e00 <fwp_trap>
    515c:	d503201f 	nop

0000000000005160 <w120>:
    5160:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5164:	910003fd 	mov	x29, sp
    5168:	a90153f3 	stp	x19, x20, [sp, #16]
    516c:	aa0203f3 	mov	x19, x2
    5170:	a9025bf5 	stp	x21, x22, [sp, #32]
    5174:	aa0003f6 	mov	x22, x0
    5178:	aa0103f5 	mov	x21, x1
    517c:	a90363f7 	stp	x23, x24, [sp, #48]
    5180:	f90023f9 	str	x25, [sp, #64]
    5184:	fd0027ea 	str	d10, [sp, #72]
    5188:	1e60080a 	fmul	d10, d0, d0
    518c:	6d0527e8 	stp	d8, d9, [sp, #80]
    5190:	1e604008 	fmov	d8, d0
    5194:	1e604029 	fmov	d9, d1
    5198:	b7f82500 	tbnz	x0, #63, 5638 <w120+0x4d8>
    519c:	9360fc14 	asr	x20, x0, #32
    51a0:	f9400040 	ldr	x0, [x2]
    51a4:	eb14001f 	cmp	x0, x20
    51a8:	54002340 	b.eq	5610 <w120+0x4b0>  // b.none
    51ac:	aa1403e0 	mov	x0, x20
    51b0:	97fffd18 	bl	4610 <fwp_tape_of>
    51b4:	aa0003f7 	mov	x23, x0
    51b8:	f9402800 	ldr	x0, [x0, #80]
    51bc:	b4000080 	cbz	x0, 51cc <w120+0x6c>
    51c0:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    51c4:	9110e000 	add	x0, x0, #0x438
    51c8:	97fffb0e 	bl	3e00 <fwp_trap>
    51cc:	a9005e74 	stp	x20, x23, [x19]
    51d0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    51d4:	f9400af8 	ldr	x24, [x23, #16]
    51d8:	eb00031f 	cmp	x24, x0
    51dc:	5400210c 	b.gt	55fc <w120+0x49c>
    51e0:	eb36431f 	cmp	x24, w22, uxtw
    51e4:	5400206d 	b.le	55f0 <w120+0x490>
    51e8:	f94006f4 	ldr	x20, [x23, #8]
    51ec:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    51f0:	cb140314 	sub	x20, x24, x20
    51f4:	91000681 	add	x1, x20, #0x1
    51f8:	eb00003f 	cmp	x1, x0
    51fc:	54002008 	b.hi	55fc <w120+0x49c>  // b.pmore
    5200:	f9400ee0 	ldr	x0, [x23, #24]
    5204:	eb00003f 	cmp	x1, x0
    5208:	5400006d 	b.le	5214 <w120+0xb4>
    520c:	aa1703e0 	mov	x0, x23
    5210:	97ffff01 	bl	4e14 <fwp_tape_grow.constprop.0>
    5214:	8b140681 	add	x1, x20, x20, lsl #1
    5218:	92607ed4 	and	x20, x22, #0xffffffff00000000
    521c:	f94012e2 	ldr	x2, [x23, #32]
    5220:	d37df021 	lsl	x1, x1, #3
    5224:	aa180294 	orr	x20, x20, x24
    5228:	91000718 	add	x24, x24, #0x1
    522c:	8b010040 	add	x0, x2, x1
    5230:	b8216856 	str	w22, [x2, x1]
    5234:	9360fe99 	asr	x25, x20, #32
    5238:	b9000416 	str	w22, [x0, #4]
    523c:	6d00a008 	stp	d8, d8, [x0, #8]
    5240:	f9000af8 	str	x24, [x23, #16]
    5244:	b7f80075 	tbnz	x21, #63, 5250 <w120+0xf0>
    5248:	eb95833f 	cmp	x25, x21, asr #32
    524c:	540021c1 	b.ne	5684 <w120+0x524>  // b.any
    5250:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    5254:	1e6a3929 	fsub	d9, d9, d10
    5258:	3dc37400 	ldr	q0, [x0, #3536]
    525c:	3d801be0 	str	q0, [sp, #96]
    5260:	f9400260 	ldr	x0, [x19]
    5264:	eb19001f 	cmp	x0, x25
    5268:	54001d00 	b.eq	5608 <w120+0x4a8>  // b.none
    526c:	aa1903e0 	mov	x0, x25
    5270:	97fffce8 	bl	4610 <fwp_tape_of>
    5274:	aa0003f8 	mov	x24, x0
    5278:	f9402800 	ldr	x0, [x0, #80]
    527c:	b5fffa20 	cbnz	x0, 51c0 <w120+0x60>
    5280:	a9006279 	stp	x25, x24, [x19]
    5284:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5288:	f9400b19 	ldr	x25, [x24, #16]
    528c:	eb00033f 	cmp	x25, x0
    5290:	54001b6c 	b.gt	55fc <w120+0x49c>
    5294:	eb34433f 	cmp	x25, w20, uxtw
    5298:	54001acd 	b.le	55f0 <w120+0x490>
    529c:	b7f80075 	tbnz	x21, #63, 52a8 <w120+0x148>
    52a0:	eb35433f 	cmp	x25, w21, uxtw
    52a4:	54001a6d 	b.le	55f0 <w120+0x490>
    52a8:	f9400717 	ldr	x23, [x24, #8]
    52ac:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    52b0:	cb170337 	sub	x23, x25, x23
    52b4:	910006e1 	add	x1, x23, #0x1
    52b8:	eb00003f 	cmp	x1, x0
    52bc:	54001a08 	b.hi	55fc <w120+0x49c>  // b.pmore
    52c0:	f9400f00 	ldr	x0, [x24, #24]
    52c4:	eb00003f 	cmp	x1, x0
    52c8:	5400006d 	b.le	52d4 <w120+0x174>
    52cc:	aa1803e0 	mov	x0, x24
    52d0:	97fffed1 	bl	4e14 <fwp_tape_grow.constprop.0>
    52d4:	f10002bf 	cmp	x21, #0x0
    52d8:	9e670282 	fmov	d2, x20
    52dc:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    52e0:	9a81a2b5 	csel	x21, x21, x1, ge	// ge = tcont
    52e4:	f9401300 	ldr	x0, [x24, #32]
    52e8:	4e181ea2 	mov	v2.d[1], x21
    52ec:	8b1706f7 	add	x23, x23, x23, lsl #1
    52f0:	91000722 	add	x2, x25, #0x1
    52f4:	3dc01be0 	ldr	q0, [sp, #96]
    52f8:	d37df2f7 	lsl	x23, x23, #3
    52fc:	0ea12842 	xtn	v2.2s, v2.2d
    5300:	8b170003 	add	x3, x0, x23
    5304:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5308:	92607e94 	and	x20, x20, #0xffffffff00000000
    530c:	aa190294 	orr	x20, x20, x25
    5310:	1e68394a 	fsub	d10, d10, d8
    5314:	fc376802 	str	d2, [x0, x23]
    5318:	3c808060 	stur	q0, [x3, #8]
    531c:	f9000b02 	str	x2, [x24, #16]
    5320:	b7f81b96 	tbnz	x22, #63, 5690 <w120+0x530>
    5324:	f9400260 	ldr	x0, [x19]
    5328:	9360fed5 	asr	x21, x22, #32
    532c:	eb15001f 	cmp	x0, x21
    5330:	54001800 	b.eq	5630 <w120+0x4d0>  // b.none
    5334:	aa1503e0 	mov	x0, x21
    5338:	97fffcb6 	bl	4610 <fwp_tape_of>
    533c:	aa0003f7 	mov	x23, x0
    5340:	f9402800 	ldr	x0, [x0, #80]
    5344:	b5fff3e0 	cbnz	x0, 51c0 <w120+0x60>
    5348:	a9005e75 	stp	x21, x23, [x19]
    534c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5350:	f9400af8 	ldr	x24, [x23, #16]
    5354:	eb00031f 	cmp	x24, x0
    5358:	5400152c 	b.gt	55fc <w120+0x49c>
    535c:	eb36431f 	cmp	x24, w22, uxtw
    5360:	5400148d 	b.le	55f0 <w120+0x490>
    5364:	f94006f5 	ldr	x21, [x23, #8]
    5368:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    536c:	cb150315 	sub	x21, x24, x21
    5370:	910006a1 	add	x1, x21, #0x1
    5374:	eb00003f 	cmp	x1, x0
    5378:	54001428 	b.hi	55fc <w120+0x49c>  // b.pmore
    537c:	f9400ee0 	ldr	x0, [x23, #24]
    5380:	eb00003f 	cmp	x1, x0
    5384:	5400006d 	b.le	5390 <w120+0x230>
    5388:	aa1703e0 	mov	x0, x23
    538c:	97fffea2 	bl	4e14 <fwp_tape_grow.constprop.0>
    5390:	8b1506b5 	add	x21, x21, x21, lsl #1
    5394:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    5398:	f94012e2 	ldr	x2, [x23, #32]
    539c:	d37df2a1 	lsl	x1, x21, #3
    53a0:	3dc37400 	ldr	q0, [x0, #3536]
    53a4:	8b010040 	add	x0, x2, x1
    53a8:	b8216856 	str	w22, [x2, x1]
    53ac:	92607ec3 	and	x3, x22, #0xffffffff00000000
    53b0:	12800001 	mov	w1, #0xffffffff            	// #-1
    53b4:	aa180075 	orr	x21, x3, x24
    53b8:	b9000401 	str	w1, [x0, #4]
    53bc:	91000718 	add	x24, x24, #0x1
    53c0:	3c808000 	stur	q0, [x0, #8]
    53c4:	f9000af8 	str	x24, [x23, #16]
    53c8:	f9400260 	ldr	x0, [x19]
    53cc:	9360fe96 	asr	x22, x20, #32
    53d0:	1e690928 	fmul	d8, d9, d9
    53d4:	eb16001f 	cmp	x0, x22
    53d8:	54001280 	b.eq	5628 <w120+0x4c8>  // b.none
    53dc:	aa1603e0 	mov	x0, x22
    53e0:	97fffc8c 	bl	4610 <fwp_tape_of>
    53e4:	aa0003f7 	mov	x23, x0
    53e8:	f9402800 	ldr	x0, [x0, #80]
    53ec:	b5ffeea0 	cbnz	x0, 51c0 <w120+0x60>
    53f0:	a9005e76 	stp	x22, x23, [x19]
    53f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    53f8:	f9400af9 	ldr	x25, [x23, #16]
    53fc:	eb00033f 	cmp	x25, x0
    5400:	54000fec 	b.gt	55fc <w120+0x49c>
    5404:	eb34433f 	cmp	x25, w20, uxtw
    5408:	54000f4d 	b.le	55f0 <w120+0x490>
    540c:	f94006f6 	ldr	x22, [x23, #8]
    5410:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5414:	cb160336 	sub	x22, x25, x22
    5418:	910006c1 	add	x1, x22, #0x1
    541c:	eb00003f 	cmp	x1, x0
    5420:	54000ee8 	b.hi	55fc <w120+0x49c>  // b.pmore
    5424:	f9400ee0 	ldr	x0, [x23, #24]
    5428:	eb00003f 	cmp	x1, x0
    542c:	5400006d 	b.le	5438 <w120+0x2d8>
    5430:	aa1703e0 	mov	x0, x23
    5434:	97fffe78 	bl	4e14 <fwp_tape_grow.constprop.0>
    5438:	8b1606d6 	add	x22, x22, x22, lsl #1
    543c:	92607e98 	and	x24, x20, #0xffffffff00000000
    5440:	f94012e0 	ldr	x0, [x23, #32]
    5444:	d37df2d6 	lsl	x22, x22, #3
    5448:	f9400262 	ldr	x2, [x19]
    544c:	8b160001 	add	x1, x0, x22
    5450:	b8366814 	str	w20, [x0, x22]
    5454:	aa190318 	orr	x24, x24, x25
    5458:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    545c:	9e670000 	fmov	d0, x0
    5460:	b9000434 	str	w20, [x1, #4]
    5464:	91000739 	add	x25, x25, #0x1
    5468:	6d00a429 	stp	d9, d9, [x1, #8]
    546c:	9360ff14 	asr	x20, x24, #32
    5470:	1e600908 	fmul	d8, d8, d0
    5474:	f9000af9 	str	x25, [x23, #16]
    5478:	eb14005f 	cmp	x2, x20
    547c:	54000d20 	b.eq	5620 <w120+0x4c0>  // b.none
    5480:	aa1403e0 	mov	x0, x20
    5484:	97fffc63 	bl	4610 <fwp_tape_of>
    5488:	aa0003f6 	mov	x22, x0
    548c:	f9402800 	ldr	x0, [x0, #80]
    5490:	b5ffe980 	cbnz	x0, 51c0 <w120+0x60>
    5494:	a9005a74 	stp	x20, x22, [x19]
    5498:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    549c:	f9400ad7 	ldr	x23, [x22, #16]
    54a0:	eb0002ff 	cmp	x23, x0
    54a4:	54000acc 	b.gt	55fc <w120+0x49c>
    54a8:	eb3842ff 	cmp	x23, w24, uxtw
    54ac:	54000a2d 	b.le	55f0 <w120+0x490>
    54b0:	f94006d4 	ldr	x20, [x22, #8]
    54b4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54b8:	cb1402f4 	sub	x20, x23, x20
    54bc:	91000681 	add	x1, x20, #0x1
    54c0:	eb00003f 	cmp	x1, x0
    54c4:	540009c8 	b.hi	55fc <w120+0x49c>  // b.pmore
    54c8:	f9400ec0 	ldr	x0, [x22, #24]
    54cc:	eb00003f 	cmp	x1, x0
    54d0:	5400006d 	b.le	54dc <w120+0x37c>
    54d4:	aa1603e0 	mov	x0, x22
    54d8:	97fffe4f 	bl	4e14 <fwp_tape_grow.constprop.0>
    54dc:	8b140694 	add	x20, x20, x20, lsl #1
    54e0:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    54e4:	f94012c1 	ldr	x1, [x22, #32]
    54e8:	d37df294 	lsl	x20, x20, #3
    54ec:	3dc37800 	ldr	q0, [x0, #3552]
    54f0:	8b140020 	add	x0, x1, x20
    54f4:	b8346838 	str	w24, [x1, x20]
    54f8:	12800002 	mov	w2, #0xffffffff            	// #-1
    54fc:	92607f18 	and	x24, x24, #0xffffffff00000000
    5500:	910006e1 	add	x1, x23, #0x1
    5504:	b9000402 	str	w2, [x0, #4]
    5508:	1e6a0949 	fmul	d9, d10, d10
    550c:	3c808000 	stur	q0, [x0, #8]
    5510:	aa170318 	orr	x24, x24, x23
    5514:	aa1503e0 	mov	x0, x21
    5518:	f9000ac1 	str	x1, [x22, #16]
    551c:	b10006bf 	cmn	x21, #0x1
    5520:	540004e0 	b.eq	55bc <w120+0x45c>  // b.none
    5524:	f9400260 	ldr	x0, [x19]
    5528:	9360feb4 	asr	x20, x21, #32
    552c:	eb14001f 	cmp	x0, x20
    5530:	54000740 	b.eq	5618 <w120+0x4b8>  // b.none
    5534:	aa1403e0 	mov	x0, x20
    5538:	97fffc36 	bl	4610 <fwp_tape_of>
    553c:	aa0003f6 	mov	x22, x0
    5540:	f9402800 	ldr	x0, [x0, #80]
    5544:	b5ffe3e0 	cbnz	x0, 51c0 <w120+0x60>
    5548:	a9005a74 	stp	x20, x22, [x19]
    554c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5550:	f9400ad7 	ldr	x23, [x22, #16]
    5554:	eb0002ff 	cmp	x23, x0
    5558:	5400052c 	b.gt	55fc <w120+0x49c>
    555c:	eb3542ff 	cmp	x23, w21, uxtw
    5560:	5400048d 	b.le	55f0 <w120+0x490>
    5564:	f94006d4 	ldr	x20, [x22, #8]
    5568:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    556c:	cb1402f4 	sub	x20, x23, x20
    5570:	91000681 	add	x1, x20, #0x1
    5574:	eb00003f 	cmp	x1, x0
    5578:	54000428 	b.hi	55fc <w120+0x49c>  // b.pmore
    557c:	f9400ec0 	ldr	x0, [x22, #24]
    5580:	eb00003f 	cmp	x1, x0
    5584:	5400006d 	b.le	5590 <w120+0x430>
    5588:	aa1603e0 	mov	x0, x22
    558c:	97fffe22 	bl	4e14 <fwp_tape_grow.constprop.0>
    5590:	8b140694 	add	x20, x20, x20, lsl #1
    5594:	92607ea0 	and	x0, x21, #0xffffffff00000000
    5598:	f94012c2 	ldr	x2, [x22, #32]
    559c:	d37df294 	lsl	x20, x20, #3
    55a0:	aa170000 	orr	x0, x0, x23
    55a4:	910006f7 	add	x23, x23, #0x1
    55a8:	8b140041 	add	x1, x2, x20
    55ac:	b8346855 	str	w21, [x2, x20]
    55b0:	b9000435 	str	w21, [x1, #4]
    55b4:	6d00a82a 	stp	d10, d10, [x1, #8]
    55b8:	f9000ad7 	str	x23, [x22, #16]
    55bc:	1e604101 	fmov	d1, d8
    55c0:	1e604120 	fmov	d0, d9
    55c4:	aa1303e2 	mov	x2, x19
    55c8:	aa1803e1 	mov	x1, x24
    55cc:	97fffe7d 	bl	4fc0 <w123>
    55d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    55d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    55dc:	f94023f9 	ldr	x25, [sp, #64]
    55e0:	fd4027ea 	ldr	d10, [sp, #72]
    55e4:	6d4527e8 	ldp	d8, d9, [sp, #80]
    55e8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    55ec:	d65f03c0 	ret
    55f0:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    55f4:	9111a000 	add	x0, x0, #0x468
    55f8:	97fffa02 	bl	3e00 <fwp_trap>
    55fc:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    5600:	910f4000 	add	x0, x0, #0x3d0
    5604:	97fff9ff 	bl	3e00 <fwp_trap>
    5608:	f9400678 	ldr	x24, [x19, #8]
    560c:	17ffff1e 	b	5284 <w120+0x124>
    5610:	f9400457 	ldr	x23, [x2, #8]
    5614:	17fffeef 	b	51d0 <w120+0x70>
    5618:	f9400676 	ldr	x22, [x19, #8]
    561c:	17ffffcc 	b	554c <w120+0x3ec>
    5620:	f9400676 	ldr	x22, [x19, #8]
    5624:	17ffff9d 	b	5498 <w120+0x338>
    5628:	f9400677 	ldr	x23, [x19, #8]
    562c:	17ffff72 	b	53f4 <w120+0x294>
    5630:	f9400677 	ldr	x23, [x19, #8]
    5634:	17ffff46 	b	534c <w120+0x1ec>
    5638:	1e6a3829 	fsub	d9, d1, d10
    563c:	b6f80161 	tbz	x1, #63, 5668 <w120+0x508>
    5640:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5644:	1e690921 	fmul	d1, d9, d9
    5648:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    564c:	9e670002 	fmov	d2, x0
    5650:	1e683809 	fsub	d9, d0, d8
    5654:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5658:	aa1803e0 	mov	x0, x24
    565c:	1e620828 	fmul	d8, d1, d2
    5660:	1e690929 	fmul	d9, d9, d9
    5664:	17ffffd6 	b	55bc <w120+0x45c>
    5668:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    566c:	9360fc39 	asr	x25, x1, #32
    5670:	aa0103f4 	mov	x20, x1
    5674:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5678:	3dc37000 	ldr	q0, [x0, #3520]
    567c:	3d801be0 	str	q0, [sp, #96]
    5680:	17fffef8 	b	5260 <w120+0x100>
    5684:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    5688:	910fc000 	add	x0, x0, #0x3f0
    568c:	97fff9dd 	bl	3e00 <fwp_trap>
    5690:	aa0103f5 	mov	x21, x1
    5694:	17ffff4d 	b	53c8 <w120+0x268>
    5698:	d503201f 	nop
    569c:	d503201f 	nop

00000000000056a0 <w176.constprop.0>:
    56a0:	d10183ff 	sub	sp, sp, #0x60
    56a4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    56a8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    56ac:	f947f421 	ldr	x1, [x1, #4072]
    56b0:	a9027bfd 	stp	x29, x30, [sp, #32]
    56b4:	910083fd 	add	x29, sp, #0x20
    56b8:	a9045bf5 	stp	x21, x22, [sp, #64]
    56bc:	f9400015 	ldr	x21, [x0]
    56c0:	f9400023 	ldr	x3, [x1]
    56c4:	f9000fe3 	str	x3, [sp, #24]
    56c8:	d2800003 	mov	x3, #0x0                   	// #0
    56cc:	a900ffe2 	stp	x2, xzr, [sp, #8]
    56d0:	b4000435 	cbz	x21, 5754 <w176.constprop.0+0xb4>
    56d4:	2f00e400 	movi	d0, #0x0
    56d8:	91004016 	add	x22, x0, #0x10
    56dc:	a90353f3 	stp	x19, x20, [sp, #48]
    56e0:	91002014 	add	x20, x0, #0x8
    56e4:	d2800013 	mov	x19, #0x0                   	// #0
    56e8:	f9002bf7 	str	x23, [sp, #80]
    56ec:	910023f7 	add	x23, sp, #0x8
    56f0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    56f4:	aa0203e0 	mov	x0, x2
    56f8:	fc737a81 	ldr	d1, [x20, x19, lsl #3]
    56fc:	aa1703e2 	mov	x2, x23
    5700:	91000a73 	add	x19, x19, #0x2
    5704:	97fffe2f 	bl	4fc0 <w123>
    5708:	aa0103e2 	mov	x2, x1
    570c:	9e670000 	fmov	d0, x0
    5710:	eb1302bf 	cmp	x21, x19
    5714:	54fffee8 	b.hi	56f0 <w176.constprop.0+0x50>  // b.pmore
    5718:	a94353f3 	ldp	x19, x20, [sp, #48]
    571c:	f9402bf7 	ldr	x23, [sp, #80]
    5720:	9e660000 	fmov	x0, d0
    5724:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    5728:	f947f421 	ldr	x1, [x1, #4072]
    572c:	f9400fe4 	ldr	x4, [sp, #24]
    5730:	f9400023 	ldr	x3, [x1]
    5734:	eb030084 	subs	x4, x4, x3
    5738:	d2800003 	mov	x3, #0x0                   	// #0
    573c:	54000101 	b.ne	575c <w176.constprop.0+0xbc>  // b.any
    5740:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5744:	aa0203e1 	mov	x1, x2
    5748:	a9445bf5 	ldp	x21, x22, [sp, #64]
    574c:	910183ff 	add	sp, sp, #0x60
    5750:	d65f03c0 	ret
    5754:	2f00e400 	movi	d0, #0x0
    5758:	17fffff2 	b	5720 <w176.constprop.0+0x80>
    575c:	a90353f3 	stp	x19, x20, [sp, #48]
    5760:	f9002bf7 	str	x23, [sp, #80]
    5764:	97fff427 	bl	2800 <__stack_chk_fail@plt>
    5768:	d503201f 	nop
    576c:	d503201f 	nop

0000000000005770 <fwp_rc_share>:
    5770:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5774:	9114c042 	add	x2, x2, #0x530
    5778:	f949d843 	ldr	x3, [x2, #5040]
    577c:	f949ec41 	ldr	x1, [x2, #5080]
    5780:	cb030000 	sub	x0, x0, x3
    5784:	eb01401f 	cmp	x0, x1, lsl #16
    5788:	540003a2 	b.cs	57fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    578c:	d350fc01 	lsr	x1, x0, #16
    5790:	f949fc44 	ldr	x4, [x2, #5112]
    5794:	8b010821 	add	x1, x1, x1, lsl #2
    5798:	d37df021 	lsl	x1, x1, #3
    579c:	8b010083 	add	x3, x4, x1
    57a0:	f9401062 	ldr	x2, [x3, #32]
    57a4:	b40002c2 	cbz	x2, 57fc <fwp_rc_share+0x8c>
    57a8:	38616881 	ldrb	w1, [x4, x1]
    57ac:	7100083f 	cmp	w1, #0x2
    57b0:	54000220 	b.eq	57f4 <fwp_rc_share+0x84>  // b.none
    57b4:	7100043f 	cmp	w1, #0x1
    57b8:	54000221 	b.ne	57fc <fwp_rc_share+0x8c>  // b.any
    57bc:	29430464 	ldp	w4, w1, [x3, #24]
    57c0:	92403c00 	and	x0, x0, #0xffff
    57c4:	9b047c00 	mul	x0, x0, x4
    57c8:	d360fc00 	lsr	x0, x0, #32
    57cc:	eb01001f 	cmp	x0, x1
    57d0:	54000162 	b.cs	57fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    57d4:	8b000042 	add	x2, x2, x0
    57d8:	39400040 	ldrb	w0, [x2]
    57dc:	34000100 	cbz	w0, 57fc <fwp_rc_share+0x8c>
    57e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    57e4:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    57e8:	91122000 	add	x0, x0, #0x488
    57ec:	910003fd 	mov	x29, sp
    57f0:	97fff984 	bl	3e00 <fwp_trap>
    57f4:	72003c1f 	tst	w0, #0xffff
    57f8:	54ffff00 	b.eq	57d8 <fwp_rc_share+0x68>  // b.none
    57fc:	d65f03c0 	ret

0000000000005800 <fwp_rc_fresh>:
    5800:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5804:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    5808:	9114c063 	add	x3, x3, #0x530
    580c:	910003fd 	mov	x29, sp
    5810:	a90153f3 	stp	x19, x20, [sp, #16]
    5814:	aa0003f3 	mov	x19, x0
    5818:	f949d861 	ldr	x1, [x3, #5040]
    581c:	f949ec60 	ldr	x0, [x3, #5080]
    5820:	cb010261 	sub	x1, x19, x1
    5824:	eb00403f 	cmp	x1, x0, lsl #16
    5828:	54000322 	b.cs	588c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    582c:	d350fc22 	lsr	x2, x1, #16
    5830:	f949fc63 	ldr	x3, [x3, #5112]
    5834:	8b020842 	add	x2, x2, x2, lsl #2
    5838:	d37df042 	lsl	x2, x2, #3
    583c:	8b020060 	add	x0, x3, x2
    5840:	f9401014 	ldr	x20, [x0, #32]
    5844:	b4000254 	cbz	x20, 588c <fwp_rc_fresh+0x8c>
    5848:	38626862 	ldrb	w2, [x3, x2]
    584c:	7100085f 	cmp	w2, #0x2
    5850:	54000260 	b.eq	589c <fwp_rc_fresh+0x9c>  // b.none
    5854:	7100045f 	cmp	w2, #0x1
    5858:	540001a1 	b.ne	588c <fwp_rc_fresh+0x8c>  // b.any
    585c:	29430002 	ldp	w2, w0, [x0, #24]
    5860:	92403c21 	and	x1, x1, #0xffff
    5864:	9b027c21 	mul	x1, x1, x2
    5868:	d360fc21 	lsr	x1, x1, #32
    586c:	eb00003f 	cmp	x1, x0
    5870:	540000e2 	b.cs	588c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5874:	8b010294 	add	x20, x20, x1
    5878:	39400280 	ldrb	w0, [x20]
    587c:	7103fc1f 	cmp	w0, #0xff
    5880:	540001a0 	b.eq	58b4 <fwp_rc_fresh+0xb4>  // b.none
    5884:	52800020 	mov	w0, #0x1                   	// #1
    5888:	39000280 	strb	w0, [x20]
    588c:	aa1303e0 	mov	x0, x19
    5890:	a94153f3 	ldp	x19, x20, [sp, #16]
    5894:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5898:	d65f03c0 	ret
    589c:	72003c3f 	tst	w1, #0xffff
    58a0:	54fffec0 	b.eq	5878 <fwp_rc_fresh+0x78>  // b.none
    58a4:	aa1303e0 	mov	x0, x19
    58a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    58ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    58b0:	d65f03c0 	ret
    58b4:	aa1403e0 	mov	x0, x20
    58b8:	97fff972 	bl	3e80 <fwp_rc_forget_slot.part.0>
    58bc:	17fffff2 	b	5884 <fwp_rc_fresh+0x84>

00000000000058c0 <fwp_rc_free_arr>:
    58c0:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    58c4:	9114c063 	add	x3, x3, #0x530
    58c8:	f949d861 	ldr	x1, [x3, #5040]
    58cc:	f949ec62 	ldr	x2, [x3, #5080]
    58d0:	cb010001 	sub	x1, x0, x1
    58d4:	eb02403f 	cmp	x1, x2, lsl #16
    58d8:	54000342 	b.cs	5940 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    58dc:	d350fc22 	lsr	x2, x1, #16
    58e0:	f949fc65 	ldr	x5, [x3, #5112]
    58e4:	8b020842 	add	x2, x2, x2, lsl #2
    58e8:	d37df042 	lsl	x2, x2, #3
    58ec:	8b0200a4 	add	x4, x5, x2
    58f0:	f9401083 	ldr	x3, [x4, #32]
    58f4:	b4000263 	cbz	x3, 5940 <fwp_rc_free_arr+0x80>
    58f8:	386268a2 	ldrb	w2, [x5, x2]
    58fc:	7100085f 	cmp	w2, #0x2
    5900:	540001c0 	b.eq	5938 <fwp_rc_free_arr+0x78>  // b.none
    5904:	7100045f 	cmp	w2, #0x1
    5908:	540001c1 	b.ne	5940 <fwp_rc_free_arr+0x80>  // b.any
    590c:	29430885 	ldp	w5, w2, [x4, #24]
    5910:	92403c21 	and	x1, x1, #0xffff
    5914:	9b057c21 	mul	x1, x1, x5
    5918:	d360fc21 	lsr	x1, x1, #32
    591c:	eb02003f 	cmp	x1, x2
    5920:	54000102 	b.cs	5940 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5924:	8b010063 	add	x3, x3, x1
    5928:	39400061 	ldrb	w1, [x3]
    592c:	7100043f 	cmp	w1, #0x1
    5930:	54000081 	b.ne	5940 <fwp_rc_free_arr+0x80>  // b.any
    5934:	17fff9ef 	b	40f0 <fwp_mem_free>
    5938:	72003c3f 	tst	w1, #0xffff
    593c:	54ffff60 	b.eq	5928 <fwp_rc_free_arr+0x68>  // b.none
    5940:	d65f03c0 	ret

0000000000005944 <fwp_rc_dup>:
    5944:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5948:	9114c042 	add	x2, x2, #0x530
    594c:	f949d841 	ldr	x1, [x2, #5040]
    5950:	f949ec43 	ldr	x3, [x2, #5080]
    5954:	cb010001 	sub	x1, x0, x1
    5958:	eb03403f 	cmp	x1, x3, lsl #16
    595c:	54000342 	b.cs	59c4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5960:	d350fc20 	lsr	x0, x1, #16
    5964:	f949fc44 	ldr	x4, [x2, #5112]
    5968:	8b000800 	add	x0, x0, x0, lsl #2
    596c:	d37df002 	lsl	x2, x0, #3
    5970:	8b020083 	add	x3, x4, x2
    5974:	f9401060 	ldr	x0, [x3, #32]
    5978:	b4000260 	cbz	x0, 59c4 <fwp_rc_dup+0x80>
    597c:	38626882 	ldrb	w2, [x4, x2]
    5980:	7100085f 	cmp	w2, #0x2
    5984:	54000220 	b.eq	59c8 <fwp_rc_dup+0x84>  // b.none
    5988:	7100045f 	cmp	w2, #0x1
    598c:	540001c1 	b.ne	59c4 <fwp_rc_dup+0x80>  // b.any
    5990:	29430864 	ldp	w4, w2, [x3, #24]
    5994:	92403c21 	and	x1, x1, #0xffff
    5998:	9b047c21 	mul	x1, x1, x4
    599c:	d360fc21 	lsr	x1, x1, #32
    59a0:	eb02003f 	cmp	x1, x2
    59a4:	54000102 	b.cs	59c4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    59a8:	8b010000 	add	x0, x0, x1
    59ac:	39400001 	ldrb	w1, [x0]
    59b0:	340000a1 	cbz	w1, 59c4 <fwp_rc_dup+0x80>
    59b4:	7103f43f 	cmp	w1, #0xfd
    59b8:	540000e8 	b.hi	59d4 <fwp_rc_dup+0x90>  // b.pmore
    59bc:	11000421 	add	w1, w1, #0x1
    59c0:	39000001 	strb	w1, [x0]
    59c4:	d65f03c0 	ret
    59c8:	72003c3f 	tst	w1, #0xffff
    59cc:	54ffff00 	b.eq	59ac <fwp_rc_dup+0x68>  // b.none
    59d0:	d65f03c0 	ret
    59d4:	17fffa40 	b	42d4 <fwp_rc_wide_dup>
    59d8:	d503201f 	nop
    59dc:	d503201f 	nop

00000000000059e0 <fwp_owned_entry173>:
    59e0:	d10103ff 	sub	sp, sp, #0x40
    59e4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    59e8:	f947f442 	ldr	x2, [x2, #4072]
    59ec:	a9027bfd 	stp	x29, x30, [sp, #32]
    59f0:	910083fd 	add	x29, sp, #0x20
    59f4:	a90353f3 	stp	x19, x20, [sp, #48]
    59f8:	f9400043 	ldr	x3, [x2]
    59fc:	f9000fe3 	str	x3, [sp, #24]
    5a00:	d2800003 	mov	x3, #0x0                   	// #0
    5a04:	a9400c01 	ldp	x1, x3, [x0]
    5a08:	f9400802 	ldr	x2, [x0, #16]
    5a0c:	ab020022 	adds	x2, x1, x2
    5a10:	540006e6 	b.vs	5aec <fwp_owned_entry173+0x10c>
    5a14:	910023e1 	add	x1, sp, #0x8
    5a18:	52800000 	mov	w0, #0x0                   	// #0
    5a1c:	a9008be3 	stp	x3, x2, [sp, #8]
    5a20:	97fffcb5 	bl	4cf4 <fwp_data.part.0.constprop.0>
    5a24:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    5a28:	9114c063 	add	x3, x3, #0x530
    5a2c:	aa0003f3 	mov	x19, x0
    5a30:	f949d861 	ldr	x1, [x3, #5040]
    5a34:	f949ec60 	ldr	x0, [x3, #5080]
    5a38:	cb010261 	sub	x1, x19, x1
    5a3c:	eb00403f 	cmp	x1, x0, lsl #16
    5a40:	54000322 	b.cs	5aa4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5a44:	d350fc22 	lsr	x2, x1, #16
    5a48:	f949fc63 	ldr	x3, [x3, #5112]
    5a4c:	8b020842 	add	x2, x2, x2, lsl #2
    5a50:	d37df042 	lsl	x2, x2, #3
    5a54:	8b020060 	add	x0, x3, x2
    5a58:	f9401014 	ldr	x20, [x0, #32]
    5a5c:	b4000254 	cbz	x20, 5aa4 <fwp_owned_entry173+0xc4>
    5a60:	38626862 	ldrb	w2, [x3, x2]
    5a64:	7100085f 	cmp	w2, #0x2
    5a68:	54000360 	b.eq	5ad4 <fwp_owned_entry173+0xf4>  // b.none
    5a6c:	7100045f 	cmp	w2, #0x1
    5a70:	540001a1 	b.ne	5aa4 <fwp_owned_entry173+0xc4>  // b.any
    5a74:	29430002 	ldp	w2, w0, [x0, #24]
    5a78:	92403c21 	and	x1, x1, #0xffff
    5a7c:	9b027c21 	mul	x1, x1, x2
    5a80:	d360fc21 	lsr	x1, x1, #32
    5a84:	eb00003f 	cmp	x1, x0
    5a88:	540000e2 	b.cs	5aa4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5a8c:	8b010294 	add	x20, x20, x1
    5a90:	39400280 	ldrb	w0, [x20]
    5a94:	7103fc1f 	cmp	w0, #0xff
    5a98:	54000240 	b.eq	5ae0 <fwp_owned_entry173+0x100>  // b.none
    5a9c:	52800020 	mov	w0, #0x1                   	// #1
    5aa0:	39000280 	strb	w0, [x20]
    5aa4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    5aa8:	f947f400 	ldr	x0, [x0, #4072]
    5aac:	f9400fe2 	ldr	x2, [sp, #24]
    5ab0:	f9400001 	ldr	x1, [x0]
    5ab4:	eb010042 	subs	x2, x2, x1
    5ab8:	d2800001 	mov	x1, #0x0                   	// #0
    5abc:	540001a1 	b.ne	5af0 <fwp_owned_entry173+0x110>  // b.any
    5ac0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5ac4:	aa1303e0 	mov	x0, x19
    5ac8:	a94353f3 	ldp	x19, x20, [sp, #48]
    5acc:	910103ff 	add	sp, sp, #0x40
    5ad0:	d65f03c0 	ret
    5ad4:	72003c3f 	tst	w1, #0xffff
    5ad8:	54fffe61 	b.ne	5aa4 <fwp_owned_entry173+0xc4>  // b.any
    5adc:	17ffffed 	b	5a90 <fwp_owned_entry173+0xb0>
    5ae0:	aa1403e0 	mov	x0, x20
    5ae4:	97fff8e7 	bl	3e80 <fwp_rc_forget_slot.part.0>
    5ae8:	17ffffed 	b	5a9c <fwp_owned_entry173+0xbc>
    5aec:	97fff3c5 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5af0:	97fff344 	bl	2800 <__stack_chk_fail@plt>

0000000000005af4 <e173>:
    5af4:	d10103ff 	sub	sp, sp, #0x40
    5af8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    5afc:	f947f442 	ldr	x2, [x2, #4072]
    5b00:	a9027bfd 	stp	x29, x30, [sp, #32]
    5b04:	910083fd 	add	x29, sp, #0x20
    5b08:	a90353f3 	stp	x19, x20, [sp, #48]
    5b0c:	f9400043 	ldr	x3, [x2]
    5b10:	f9000fe3 	str	x3, [sp, #24]
    5b14:	d2800003 	mov	x3, #0x0                   	// #0
    5b18:	a9400c01 	ldp	x1, x3, [x0]
    5b1c:	f9400802 	ldr	x2, [x0, #16]
    5b20:	ab020022 	adds	x2, x1, x2
    5b24:	54000726 	b.vs	5c08 <e173+0x114>
    5b28:	910023e1 	add	x1, sp, #0x8
    5b2c:	52800000 	mov	w0, #0x0                   	// #0
    5b30:	a9008be3 	stp	x3, x2, [sp, #8]
    5b34:	97fffc70 	bl	4cf4 <fwp_data.part.0.constprop.0>
    5b38:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    5b3c:	9114c063 	add	x3, x3, #0x530
    5b40:	aa0003f3 	mov	x19, x0
    5b44:	f949d861 	ldr	x1, [x3, #5040]
    5b48:	f949ec60 	ldr	x0, [x3, #5080]
    5b4c:	cb010261 	sub	x1, x19, x1
    5b50:	eb00403f 	cmp	x1, x0, lsl #16
    5b54:	54000322 	b.cs	5bb8 <e173+0xc4>  // b.hs, b.nlast
    5b58:	d350fc22 	lsr	x2, x1, #16
    5b5c:	f949fc63 	ldr	x3, [x3, #5112]
    5b60:	8b020842 	add	x2, x2, x2, lsl #2
    5b64:	d37df042 	lsl	x2, x2, #3
    5b68:	8b020060 	add	x0, x3, x2
    5b6c:	f9401014 	ldr	x20, [x0, #32]
    5b70:	b4000254 	cbz	x20, 5bb8 <e173+0xc4>
    5b74:	38626862 	ldrb	w2, [x3, x2]
    5b78:	7100085f 	cmp	w2, #0x2
    5b7c:	540003a0 	b.eq	5bf0 <e173+0xfc>  // b.none
    5b80:	7100045f 	cmp	w2, #0x1
    5b84:	540001a1 	b.ne	5bb8 <e173+0xc4>  // b.any
    5b88:	29430002 	ldp	w2, w0, [x0, #24]
    5b8c:	92403c21 	and	x1, x1, #0xffff
    5b90:	9b027c21 	mul	x1, x1, x2
    5b94:	d360fc21 	lsr	x1, x1, #32
    5b98:	eb00003f 	cmp	x1, x0
    5b9c:	540000e2 	b.cs	5bb8 <e173+0xc4>  // b.hs, b.nlast
    5ba0:	8b010294 	add	x20, x20, x1
    5ba4:	39400280 	ldrb	w0, [x20]
    5ba8:	7103fc1f 	cmp	w0, #0xff
    5bac:	54000280 	b.eq	5bfc <e173+0x108>  // b.none
    5bb0:	52800020 	mov	w0, #0x1                   	// #1
    5bb4:	39000280 	strb	w0, [x20]
    5bb8:	aa1303e0 	mov	x0, x19
    5bbc:	97fffeed 	bl	5770 <fwp_rc_share>
    5bc0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    5bc4:	f947f400 	ldr	x0, [x0, #4072]
    5bc8:	f9400fe2 	ldr	x2, [sp, #24]
    5bcc:	f9400001 	ldr	x1, [x0]
    5bd0:	eb010042 	subs	x2, x2, x1
    5bd4:	d2800001 	mov	x1, #0x0                   	// #0
    5bd8:	540001a1 	b.ne	5c0c <e173+0x118>  // b.any
    5bdc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5be0:	aa1303e0 	mov	x0, x19
    5be4:	a94353f3 	ldp	x19, x20, [sp, #48]
    5be8:	910103ff 	add	sp, sp, #0x40
    5bec:	d65f03c0 	ret
    5bf0:	72003c3f 	tst	w1, #0xffff
    5bf4:	54fffe21 	b.ne	5bb8 <e173+0xc4>  // b.any
    5bf8:	17ffffeb 	b	5ba4 <e173+0xb0>
    5bfc:	aa1403e0 	mov	x0, x20
    5c00:	97fff8a0 	bl	3e80 <fwp_rc_forget_slot.part.0>
    5c04:	17ffffeb 	b	5bb0 <e173+0xbc>
    5c08:	97fff37e 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5c0c:	97fff2fd 	bl	2800 <__stack_chk_fail@plt>

0000000000005c10 <fwp_drop0>:
    5c10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c14:	910003fd 	mov	x29, sp
    5c18:	a90153f3 	stp	x19, x20, [sp, #16]
    5c1c:	f90013f5 	str	x21, [sp, #32]
    5c20:	90000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    5c24:	9114c2b4 	add	x20, x21, #0x530
    5c28:	f949da81 	ldr	x1, [x20, #5040]
    5c2c:	f949ee82 	ldr	x2, [x20, #5080]
    5c30:	cb010001 	sub	x1, x0, x1
    5c34:	eb02403f 	cmp	x1, x2, lsl #16
    5c38:	54000382 	b.cs	5ca8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c3c:	d350fc22 	lsr	x2, x1, #16
    5c40:	f949fe84 	ldr	x4, [x20, #5112]
    5c44:	8b020842 	add	x2, x2, x2, lsl #2
    5c48:	d37df042 	lsl	x2, x2, #3
    5c4c:	8b020083 	add	x3, x4, x2
    5c50:	f9401073 	ldr	x19, [x3, #32]
    5c54:	b40002b3 	cbz	x19, 5ca8 <fwp_drop0+0x98>
    5c58:	38626882 	ldrb	w2, [x4, x2]
    5c5c:	7100085f 	cmp	w2, #0x2
    5c60:	540002c0 	b.eq	5cb8 <fwp_drop0+0xa8>  // b.none
    5c64:	7100045f 	cmp	w2, #0x1
    5c68:	54000201 	b.ne	5ca8 <fwp_drop0+0x98>  // b.any
    5c6c:	29430864 	ldp	w4, w2, [x3, #24]
    5c70:	92403c21 	and	x1, x1, #0xffff
    5c74:	9b047c21 	mul	x1, x1, x4
    5c78:	d360fc21 	lsr	x1, x1, #32
    5c7c:	eb02003f 	cmp	x1, x2
    5c80:	54000142 	b.cs	5ca8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c84:	8b010273 	add	x19, x19, x1
    5c88:	39400261 	ldrb	w1, [x19]
    5c8c:	340000e1 	cbz	w1, 5ca8 <fwp_drop0+0x98>
    5c90:	7100043f 	cmp	w1, #0x1
    5c94:	540001e0 	b.eq	5cd0 <fwp_drop0+0xc0>  // b.none
    5c98:	7103fc3f 	cmp	w1, #0xff
    5c9c:	540002e0 	b.eq	5cf8 <fwp_drop0+0xe8>  // b.none
    5ca0:	51000421 	sub	w1, w1, #0x1
    5ca4:	39000261 	strb	w1, [x19]
    5ca8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5cac:	f94013f5 	ldr	x21, [sp, #32]
    5cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cb4:	d65f03c0 	ret
    5cb8:	72003c3f 	tst	w1, #0xffff
    5cbc:	54fffe60 	b.eq	5c88 <fwp_drop0+0x78>  // b.none
    5cc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5cc4:	f94013f5 	ldr	x21, [sp, #32]
    5cc8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ccc:	d65f03c0 	ret
    5cd0:	f9400813 	ldr	x19, [x0, #16]
    5cd4:	97fffefb 	bl	58c0 <fwp_rc_free_arr>
    5cd8:	9114c2a0 	add	x0, x21, #0x530
    5cdc:	f949d801 	ldr	x1, [x0, #5040]
    5ce0:	f949ec00 	ldr	x0, [x0, #5080]
    5ce4:	cb010261 	sub	x1, x19, x1
    5ce8:	eb00403f 	cmp	x1, x0, lsl #16
    5cec:	54fffde2 	b.cs	5ca8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5cf0:	aa1303e0 	mov	x0, x19
    5cf4:	17ffffd2 	b	5c3c <fwp_drop0+0x2c>
    5cf8:	ca534660 	eor	x0, x19, x19, lsr #17
    5cfc:	9114c2b5 	add	x21, x21, #0x530
    5d00:	ca402400 	eor	x0, x0, x0, lsr #9
    5d04:	92401c00 	and	x0, x0, #0xff
    5d08:	910a2402 	add	x2, x0, #0x289
    5d0c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5d10:	8b020ea2 	add	x2, x21, x2, lsl #3
    5d14:	f94a2400 	ldr	x0, [x0, #5192]
    5d18:	b50000a0 	cbnz	x0, 5d2c <fwp_drop0+0x11c>
    5d1c:	14000013 	b	5d68 <fwp_drop0+0x158>
    5d20:	91004002 	add	x2, x0, #0x10
    5d24:	f9400800 	ldr	x0, [x0, #16]
    5d28:	b4000200 	cbz	x0, 5d68 <fwp_drop0+0x158>
    5d2c:	f9400001 	ldr	x1, [x0]
    5d30:	eb13003f 	cmp	x1, x19
    5d34:	54ffff61 	b.ne	5d20 <fwp_drop0+0x110>  // b.any
    5d38:	f9400041 	ldr	x1, [x2]
    5d3c:	f9400420 	ldr	x0, [x1, #8]
    5d40:	d1000400 	sub	x0, x0, #0x1
    5d44:	f9000420 	str	x0, [x1, #8]
    5d48:	f103f81f 	cmp	x0, #0xfe
    5d4c:	54fffae1 	b.ne	5ca8 <fwp_drop0+0x98>  // b.any
    5d50:	39400260 	ldrb	w0, [x19]
    5d54:	7103fc1f 	cmp	w0, #0xff
    5d58:	540000e0 	b.eq	5d74 <fwp_drop0+0x164>  // b.none
    5d5c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d60:	39000260 	strb	w0, [x19]
    5d64:	17ffffd1 	b	5ca8 <fwp_drop0+0x98>
    5d68:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    5d6c:	91088000 	add	x0, x0, #0x220
    5d70:	97fff824 	bl	3e00 <fwp_trap>
    5d74:	aa1303e0 	mov	x0, x19
    5d78:	97fff842 	bl	3e80 <fwp_rc_forget_slot.part.0>
    5d7c:	17fffff8 	b	5d5c <fwp_drop0+0x14c>

0000000000005d80 <fwp_drop1>:
    5d80:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5d84:	910003fd 	mov	x29, sp
    5d88:	a90153f3 	stp	x19, x20, [sp, #16]
    5d8c:	f90013f5 	str	x21, [sp, #32]
    5d90:	90000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    5d94:	9114c2b4 	add	x20, x21, #0x530
    5d98:	f949da81 	ldr	x1, [x20, #5040]
    5d9c:	f949ee82 	ldr	x2, [x20, #5080]
    5da0:	cb010001 	sub	x1, x0, x1
    5da4:	eb02403f 	cmp	x1, x2, lsl #16
    5da8:	54000382 	b.cs	5e18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5dac:	d350fc22 	lsr	x2, x1, #16
    5db0:	f949fe84 	ldr	x4, [x20, #5112]
    5db4:	8b020842 	add	x2, x2, x2, lsl #2
    5db8:	d37df042 	lsl	x2, x2, #3
    5dbc:	8b020083 	add	x3, x4, x2
    5dc0:	f9401073 	ldr	x19, [x3, #32]
    5dc4:	b40002b3 	cbz	x19, 5e18 <fwp_drop1+0x98>
    5dc8:	38626882 	ldrb	w2, [x4, x2]
    5dcc:	7100085f 	cmp	w2, #0x2
    5dd0:	540002c0 	b.eq	5e28 <fwp_drop1+0xa8>  // b.none
    5dd4:	7100045f 	cmp	w2, #0x1
    5dd8:	54000201 	b.ne	5e18 <fwp_drop1+0x98>  // b.any
    5ddc:	29430864 	ldp	w4, w2, [x3, #24]
    5de0:	92403c21 	and	x1, x1, #0xffff
    5de4:	9b047c21 	mul	x1, x1, x4
    5de8:	d360fc21 	lsr	x1, x1, #32
    5dec:	eb02003f 	cmp	x1, x2
    5df0:	54000142 	b.cs	5e18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5df4:	8b010273 	add	x19, x19, x1
    5df8:	39400261 	ldrb	w1, [x19]
    5dfc:	340000e1 	cbz	w1, 5e18 <fwp_drop1+0x98>
    5e00:	7100043f 	cmp	w1, #0x1
    5e04:	540001e0 	b.eq	5e40 <fwp_drop1+0xc0>  // b.none
    5e08:	7103fc3f 	cmp	w1, #0xff
    5e0c:	540002e0 	b.eq	5e68 <fwp_drop1+0xe8>  // b.none
    5e10:	51000421 	sub	w1, w1, #0x1
    5e14:	39000261 	strb	w1, [x19]
    5e18:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e1c:	f94013f5 	ldr	x21, [sp, #32]
    5e20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e24:	d65f03c0 	ret
    5e28:	72003c3f 	tst	w1, #0xffff
    5e2c:	54fffe60 	b.eq	5df8 <fwp_drop1+0x78>  // b.none
    5e30:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e34:	f94013f5 	ldr	x21, [sp, #32]
    5e38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e3c:	d65f03c0 	ret
    5e40:	f9400813 	ldr	x19, [x0, #16]
    5e44:	97fffe9f 	bl	58c0 <fwp_rc_free_arr>
    5e48:	9114c2a0 	add	x0, x21, #0x530
    5e4c:	f949d801 	ldr	x1, [x0, #5040]
    5e50:	f949ec00 	ldr	x0, [x0, #5080]
    5e54:	cb010261 	sub	x1, x19, x1
    5e58:	eb00403f 	cmp	x1, x0, lsl #16
    5e5c:	54fffde2 	b.cs	5e18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5e60:	aa1303e0 	mov	x0, x19
    5e64:	17ffffd2 	b	5dac <fwp_drop1+0x2c>
    5e68:	ca534660 	eor	x0, x19, x19, lsr #17
    5e6c:	9114c2b5 	add	x21, x21, #0x530
    5e70:	ca402400 	eor	x0, x0, x0, lsr #9
    5e74:	92401c00 	and	x0, x0, #0xff
    5e78:	910a2402 	add	x2, x0, #0x289
    5e7c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5e80:	8b020ea2 	add	x2, x21, x2, lsl #3
    5e84:	f94a2400 	ldr	x0, [x0, #5192]
    5e88:	b50000a0 	cbnz	x0, 5e9c <fwp_drop1+0x11c>
    5e8c:	14000013 	b	5ed8 <fwp_drop1+0x158>
    5e90:	91004002 	add	x2, x0, #0x10
    5e94:	f9400800 	ldr	x0, [x0, #16]
    5e98:	b4000200 	cbz	x0, 5ed8 <fwp_drop1+0x158>
    5e9c:	f9400001 	ldr	x1, [x0]
    5ea0:	eb13003f 	cmp	x1, x19
    5ea4:	54ffff61 	b.ne	5e90 <fwp_drop1+0x110>  // b.any
    5ea8:	f9400041 	ldr	x1, [x2]
    5eac:	f9400420 	ldr	x0, [x1, #8]
    5eb0:	d1000400 	sub	x0, x0, #0x1
    5eb4:	f9000420 	str	x0, [x1, #8]
    5eb8:	f103f81f 	cmp	x0, #0xfe
    5ebc:	54fffae1 	b.ne	5e18 <fwp_drop1+0x98>  // b.any
    5ec0:	39400260 	ldrb	w0, [x19]
    5ec4:	7103fc1f 	cmp	w0, #0xff
    5ec8:	540000e0 	b.eq	5ee4 <fwp_drop1+0x164>  // b.none
    5ecc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ed0:	39000260 	strb	w0, [x19]
    5ed4:	17ffffd1 	b	5e18 <fwp_drop1+0x98>
    5ed8:	90000040 	adrp	x0, d000 <__modti3+0x2c0>
    5edc:	91088000 	add	x0, x0, #0x220
    5ee0:	97fff7c8 	bl	3e00 <fwp_trap>
    5ee4:	aa1303e0 	mov	x0, x19
    5ee8:	97fff7e6 	bl	3e80 <fwp_rc_forget_slot.part.0>
    5eec:	17fffff8 	b	5ecc <fwp_drop1+0x14c>

0000000000005ef0 <fwp_closure_drop>:
    5ef0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xcb0>
    5ef4:	9114c0a4 	add	x4, x5, #0x530
    5ef8:	aa0003e1 	mov	x1, x0
    5efc:	f949d882 	ldr	x2, [x4, #5040]
    5f00:	f949ec80 	ldr	x0, [x4, #5080]
    5f04:	cb020022 	sub	x2, x1, x2
    5f08:	eb00405f 	cmp	x2, x0, lsl #16
    5f0c:	54000662 	b.cs	5fd8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5f10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5f14:	d350fc43 	lsr	x3, x2, #16
    5f18:	910003fd 	mov	x29, sp
    5f1c:	8b030863 	add	x3, x3, x3, lsl #2
    5f20:	f949fc84 	ldr	x4, [x4, #5112]
    5f24:	d37df063 	lsl	x3, x3, #3
    5f28:	f9000bf3 	str	x19, [sp, #16]
    5f2c:	8b030080 	add	x0, x4, x3
    5f30:	f9401013 	ldr	x19, [x0, #32]
    5f34:	b40002b3 	cbz	x19, 5f88 <fwp_closure_drop+0x98>
    5f38:	38636883 	ldrb	w3, [x4, x3]
    5f3c:	7100087f 	cmp	w3, #0x2
    5f40:	54000420 	b.eq	5fc4 <fwp_closure_drop+0xd4>  // b.none
    5f44:	7100047f 	cmp	w3, #0x1
    5f48:	54000201 	b.ne	5f88 <fwp_closure_drop+0x98>  // b.any
    5f4c:	29430003 	ldp	w3, w0, [x0, #24]
    5f50:	92403c42 	and	x2, x2, #0xffff
    5f54:	9b037c42 	mul	x2, x2, x3
    5f58:	d360fc42 	lsr	x2, x2, #32
    5f5c:	eb00005f 	cmp	x2, x0
    5f60:	54000142 	b.cs	5f88 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5f64:	8b020273 	add	x19, x19, x2
    5f68:	39400260 	ldrb	w0, [x19]
    5f6c:	340000e0 	cbz	w0, 5f88 <fwp_closure_drop+0x98>
    5f70:	7100041f 	cmp	w0, #0x1
    5f74:	54000100 	b.eq	5f94 <fwp_closure_drop+0xa4>  // b.none
    5f78:	7103fc1f 	cmp	w0, #0xff
    5f7c:	54000300 	b.eq	5fdc <fwp_closure_drop+0xec>  // b.none
    5f80:	51000400 	sub	w0, w0, #0x1
    5f84:	39000260 	strb	w0, [x19]
    5f88:	f9400bf3 	ldr	x19, [sp, #16]
    5f8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f90:	d65f03c0 	ret
    5f94:	d53bd040 	mrs	x0, tpidr_el0
    5f98:	91400000 	add	x0, x0, #0x0, lsl #12
    5f9c:	91004000 	add	x0, x0, #0x10
    5fa0:	f9400000 	ldr	x0, [x0]
    5fa4:	b4000080 	cbz	x0, 5fb4 <fwp_closure_drop+0xc4>
    5fa8:	f9400bf3 	ldr	x19, [sp, #16]
    5fac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5fb0:	17fff910 	b	43f0 <fwp_closure_drop_push>
    5fb4:	f9400bf3 	ldr	x19, [sp, #16]
    5fb8:	aa0103e0 	mov	x0, x1
    5fbc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5fc0:	17fff951 	b	4504 <fwp_closure_drop.part.0>
    5fc4:	72003c5f 	tst	w2, #0xffff
    5fc8:	54fffd00 	b.eq	5f68 <fwp_closure_drop+0x78>  // b.none
    5fcc:	f9400bf3 	ldr	x19, [sp, #16]
    5fd0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5fd4:	d65f03c0 	ret
    5fd8:	d65f03c0 	ret
    5fdc:	ca534660 	eor	x0, x19, x19, lsr #17
    5fe0:	9114c0a5 	add	x5, x5, #0x530
    5fe4:	ca402400 	eor	x0, x0, x0, lsr #9
    5fe8:	92401c00 	and	x0, x0, #0xff
    5fec:	910a2402 	add	x2, x0, #0x289
    5ff0:	8b000ca0 	add	x0, x5, x0, lsl #3
    5ff4:	8b020ca2 	add	x2, x5, x2, lsl #3
    5ff8:	f94a2400 	ldr	x0, [x0, #5192]
    5ffc:	b50000a0 	cbnz	x0, 6010 <fwp_closure_drop+0x120>
    6000:	14000013 	b	604c <fwp_closure_drop+0x15c>
    6004:	91004002 	add	x2, x0, #0x10
    6008:	f9400800 	ldr	x0, [x0, #16]
    600c:	b4000200 	cbz	x0, 604c <fwp_closure_drop+0x15c>
    6010:	f9400001 	ldr	x1, [x0]
    6014:	eb13003f 	cmp	x1, x19
    6018:	54ffff61 	b.ne	6004 <fwp_closure_drop+0x114>  // b.any
    601c:	f9400041 	ldr	x1, [x2]
    6020:	f9400420 	ldr	x0, [x1, #8]
    6024:	d1000400 	sub	x0, x0, #0x1
    6028:	f9000420 	str	x0, [x1, #8]
    602c:	f103f81f 	cmp	x0, #0xfe
    6030:	54fffac1 	b.ne	5f88 <fwp_closure_drop+0x98>  // b.any
    6034:	39400260 	ldrb	w0, [x19]
    6038:	7103fc1f 	cmp	w0, #0xff
    603c:	540000e0 	b.eq	6058 <fwp_closure_drop+0x168>  // b.none
    6040:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6044:	39000260 	strb	w0, [x19]
    6048:	17ffffd0 	b	5f88 <fwp_closure_drop+0x98>
    604c:	f0000020 	adrp	x0, d000 <__modti3+0x2c0>
    6050:	91088000 	add	x0, x0, #0x220
    6054:	97fff76b 	bl	3e00 <fwp_trap>
    6058:	aa1303e0 	mov	x0, x19
    605c:	97fff789 	bl	3e80 <fwp_rc_forget_slot.part.0>
    6060:	17fffff8 	b	6040 <fwp_closure_drop+0x150>

0000000000006064 <fwp_owned_tape_release>:
    6064:	b4000920 	cbz	x0, 6188 <fwp_owned_tape_release+0x124>
    6068:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    606c:	910003fd 	mov	x29, sp
    6070:	a90153f3 	stp	x19, x20, [sp, #16]
    6074:	aa0003f3 	mov	x19, x0
    6078:	f9400000 	ldr	x0, [x0]
    607c:	b4000060 	cbz	x0, 6088 <fwp_owned_tape_release+0x24>
    6080:	f9400661 	ldr	x1, [x19, #8]
    6084:	f9000401 	str	x1, [x0, #8]
    6088:	f9400661 	ldr	x1, [x19, #8]
    608c:	b4000041 	cbz	x1, 6094 <fwp_owned_tape_release+0x30>
    6090:	f9000020 	str	x0, [x1]
    6094:	f9400a60 	ldr	x0, [x19, #16]
    6098:	f9403401 	ldr	x1, [x0, #104]
    609c:	b40005a1 	cbz	x1, 6150 <fwp_owned_tape_release+0xec>
    60a0:	a9450a60 	ldp	x0, x2, [x19, #80]
    60a4:	eb00005f 	cmp	x2, x0
    60a8:	540002cd 	b.le	6100 <fwp_owned_tape_release+0x9c>
    60ac:	d2800014 	mov	x20, #0x0                   	// #0
    60b0:	f90013f5 	str	x21, [sp, #32]
    60b4:	d2800015 	mov	x21, #0x0                   	// #0
    60b8:	f9402260 	ldr	x0, [x19, #64]
    60bc:	910006b5 	add	x21, x21, #0x1
    60c0:	f8746800 	ldr	x0, [x0, x20]
    60c4:	d63f0020 	blr	x1
    60c8:	f9402260 	ldr	x0, [x19, #64]
    60cc:	f9400a61 	ldr	x1, [x19, #16]
    60d0:	8b140000 	add	x0, x0, x20
    60d4:	91004294 	add	x20, x20, #0x10
    60d8:	f9400400 	ldr	x0, [x0, #8]
    60dc:	f9403421 	ldr	x1, [x1, #104]
    60e0:	d63f0020 	blr	x1
    60e4:	a9450261 	ldp	x1, x0, [x19, #80]
    60e8:	cb010000 	sub	x0, x0, x1
    60ec:	eb15001f 	cmp	x0, x21
    60f0:	f9400a60 	ldr	x0, [x19, #16]
    60f4:	f9403401 	ldr	x1, [x0, #104]
    60f8:	54fffe0c 	b.gt	60b8 <fwp_owned_tape_release+0x54>
    60fc:	f94013f5 	ldr	x21, [sp, #32]
    6100:	f9403663 	ldr	x3, [x19, #104]
    6104:	f9401262 	ldr	x2, [x19, #32]
    6108:	f100007f 	cmp	x3, #0x0
    610c:	540001ed 	b.le	6148 <fwp_owned_tape_release+0xe4>
    6110:	d2800014 	mov	x20, #0x0                   	// #0
    6114:	d503201f 	nop
    6118:	f9402660 	ldr	x0, [x19, #72]
    611c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6120:	eb02001f 	cmp	x0, x2
    6124:	540000c0 	b.eq	613c <fwp_owned_tape_release+0xd8>  // b.none
    6128:	d63f0020 	blr	x1
    612c:	f9400a60 	ldr	x0, [x19, #16]
    6130:	f9401262 	ldr	x2, [x19, #32]
    6134:	f9403663 	ldr	x3, [x19, #104]
    6138:	f9403401 	ldr	x1, [x0, #104]
    613c:	91000694 	add	x20, x20, #0x1
    6140:	eb14007f 	cmp	x3, x20
    6144:	54fffeac 	b.gt	6118 <fwp_owned_tape_release+0xb4>
    6148:	aa0203e0 	mov	x0, x2
    614c:	d63f0020 	blr	x1
    6150:	f9401660 	ldr	x0, [x19, #40]
    6154:	97ffff67 	bl	5ef0 <fwp_closure_drop>
    6158:	f9401a60 	ldr	x0, [x19, #48]
    615c:	97ffff65 	bl	5ef0 <fwp_closure_drop>
    6160:	f9401e60 	ldr	x0, [x19, #56]
    6164:	97ffff63 	bl	5ef0 <fwp_closure_drop>
    6168:	f9402260 	ldr	x0, [x19, #64]
    616c:	97fff7e1 	bl	40f0 <fwp_mem_free>
    6170:	f9402660 	ldr	x0, [x19, #72]
    6174:	97fff7df 	bl	40f0 <fwp_mem_free>
    6178:	aa1303e0 	mov	x0, x19
    617c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6180:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6184:	17fff7db 	b	40f0 <fwp_mem_free>
    6188:	d65f03c0 	ret
    618c:	d503201f 	nop

0000000000006190 <fwp_tape_finish>:
    6190:	d101c3ff 	sub	sp, sp, #0x70
    6194:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    6198:	f947f421 	ldr	x1, [x1, #4072]
    619c:	a9037bfd 	stp	x29, x30, [sp, #48]
    61a0:	9100c3fd 	add	x29, sp, #0x30
    61a4:	a90453f3 	stp	x19, x20, [sp, #64]
    61a8:	a9055bf5 	stp	x21, x22, [sp, #80]
    61ac:	a90663f7 	stp	x23, x24, [sp, #96]
    61b0:	d00000d8 	adrp	x24, 20000 <__data_start>
    61b4:	9100c316 	add	x22, x24, #0x30
    61b8:	f9400022 	ldr	x2, [x1]
    61bc:	f90017e2 	str	x2, [sp, #40]
    61c0:	d2800002 	mov	x2, #0x0                   	// #0
    61c4:	9100e2c0 	add	x0, x22, #0x38
    61c8:	97fff42e 	bl	3280 <fwp_tape_buffers_dispose>
    61cc:	f90032df 	str	xzr, [x22, #96]
    61d0:	f9403ac0 	ldr	x0, [x22, #112]
    61d4:	f100001f 	cmp	x0, #0x0
    61d8:	540002cd 	b.le	6230 <fwp_tape_finish+0xa0>
    61dc:	910003f7 	mov	x23, sp
    61e0:	d2800015 	mov	x21, #0x0                   	// #0
    61e4:	d2800014 	mov	x20, #0x0                   	// #0
    61e8:	f94002d3 	ldr	x19, [x22]
    61ec:	91000694 	add	x20, x20, #0x1
    61f0:	8b150273 	add	x19, x19, x21
    61f4:	910162b5 	add	x21, x21, #0x58
    61f8:	aa1303e0 	mov	x0, x19
    61fc:	97fff345 	bl	2f10 <fwp_tape_unlink_scope>
    6200:	aa1703e0 	mov	x0, x23
    6204:	3dc00a60 	ldr	q0, [x19, #32]
    6208:	f9401a61 	ldr	x1, [x19, #48]
    620c:	f9000be1 	str	x1, [sp, #16]
    6210:	3d8003e0 	str	q0, [sp]
    6214:	97fff41b 	bl	3280 <fwp_tape_buffers_dispose>
    6218:	f9402a60 	ldr	x0, [x19, #80]
    621c:	97ffff92 	bl	6064 <fwp_owned_tape_release>
    6220:	f9002a7f 	str	xzr, [x19, #80]
    6224:	f9403ac0 	ldr	x0, [x22, #112]
    6228:	eb14001f 	cmp	x0, x20
    622c:	54fffdec 	b.gt	61e8 <fwp_tape_finish+0x58>
    6230:	f9401b00 	ldr	x0, [x24, #48]
    6234:	9100c313 	add	x19, x24, #0x30
    6238:	97fff1a2 	bl	28c0 <free@plt>
    623c:	f9001b1f 	str	xzr, [x24, #48]
    6240:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    6244:	f947f400 	ldr	x0, [x0, #4072]
    6248:	f9003a7f 	str	xzr, [x19, #112]
    624c:	a9087e7f 	stp	xzr, xzr, [x19, #128]
    6250:	f94017e2 	ldr	x2, [sp, #40]
    6254:	f9400001 	ldr	x1, [x0]
    6258:	eb010042 	subs	x2, x2, x1
    625c:	d2800001 	mov	x1, #0x0                   	// #0
    6260:	540000e1 	b.ne	627c <fwp_tape_finish+0xec>  // b.any
    6264:	a9437bfd 	ldp	x29, x30, [sp, #48]
    6268:	a94453f3 	ldp	x19, x20, [sp, #64]
    626c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    6270:	a94663f7 	ldp	x23, x24, [sp, #96]
    6274:	9101c3ff 	add	sp, sp, #0x70
    6278:	d65f03c0 	ret
    627c:	97fff161 	bl	2800 <__stack_chk_fail@plt>

0000000000006280 <fwp_tape_scope_release>:
    6280:	d10203ff 	sub	sp, sp, #0x80
    6284:	a9037bfd 	stp	x29, x30, [sp, #48]
    6288:	9100c3fd 	add	x29, sp, #0x30
    628c:	a90453f3 	stp	x19, x20, [sp, #64]
    6290:	aa0003f4 	mov	x20, x0
    6294:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    6298:	f947f400 	ldr	x0, [x0, #4072]
    629c:	b9400285 	ldr	w5, [x20]
    62a0:	f9400001 	ldr	x1, [x0]
    62a4:	f90017e1 	str	x1, [sp, #40]
    62a8:	d2800001 	mov	x1, #0x0                   	// #0
    62ac:	37f806e5 	tbnz	w5, #31, 6388 <fwp_tape_scope_release+0x108>
    62b0:	a90663f7 	stp	x23, x24, [sp, #96]
    62b4:	d2917478 	mov	x24, #0x8ba3                	// #35747
    62b8:	f2b745d8 	movk	x24, #0xba2e, lsl #16
    62bc:	f2d45d18 	movk	x24, #0xa2e8, lsl #32
    62c0:	d00000d3 	adrp	x19, 20000 <__data_start>
    62c4:	910003f7 	mov	x23, sp
    62c8:	9100c273 	add	x19, x19, #0x30
    62cc:	f2e5d178 	movk	x24, #0x2e8b, lsl #48
    62d0:	a9055bf5 	stp	x21, x22, [sp, #80]
    62d4:	52800b16 	mov	w22, #0x58                  	// #88
    62d8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    62dc:	f9003bf9 	str	x25, [sp, #112]
    62e0:	14000006 	b	62f8 <fwp_tape_scope_release+0x78>
    62e4:	97fff3e7 	bl	3280 <fwp_tape_buffers_dispose>
    62e8:	aa1903e0 	mov	x0, x25
    62ec:	97ffff5e 	bl	6064 <fwp_owned_tape_release>
    62f0:	b9400285 	ldr	w5, [x20]
    62f4:	37f80445 	tbnz	w5, #31, 637c <fwp_tape_scope_release+0xfc>
    62f8:	f9400266 	ldr	x6, [x19]
    62fc:	9b367ca5 	smull	x5, w5, w22
    6300:	8b0500c0 	add	x0, x6, x5
    6304:	97fff303 	bl	2f10 <fwp_tape_unlink_scope>
    6308:	3dc00800 	ldr	q0, [x0, #32]
    630c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6310:	f9400c03 	ldr	x3, [x0, #24]
    6314:	3d8003e0 	str	q0, [sp]
    6318:	b86568c1 	ldr	w1, [x6, x5]
    631c:	f9401802 	ldr	x2, [x0, #48]
    6320:	a9010fe2 	stp	x2, x3, [sp, #16]
    6324:	f9401c02 	ldr	x2, [x0, #56]
    6328:	b900041f 	str	wzr, [x0, #4]
    632c:	f9402819 	ldr	x25, [x0, #80]
    6330:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6334:	f9000c1f 	str	xzr, [x0, #24]
    6338:	f90013e2 	str	x2, [sp, #32]
    633c:	f900181f 	str	xzr, [x0, #48]
    6340:	f9001c1f 	str	xzr, [x0, #56]
    6344:	f900281f 	str	xzr, [x0, #80]
    6348:	6b15003f 	cmp	w1, w21
    634c:	540000e8 	b.hi	6368 <fwp_tape_scope_release+0xe8>  // b.pmore
    6350:	9343fca5 	asr	x5, x5, #3
    6354:	f9404660 	ldr	x0, [x19, #136]
    6358:	9b187ca5 	mul	x5, x5, x24
    635c:	eb0000bf 	cmp	x5, x0
    6360:	5400004a 	b.ge	6368 <fwp_tape_scope_release+0xe8>  // b.tcont
    6364:	f9004665 	str	x5, [x19, #136]
    6368:	aa1703e0 	mov	x0, x23
    636c:	b5fffbd9 	cbnz	x25, 62e4 <fwp_tape_scope_release+0x64>
    6370:	97fff660 	bl	3cf0 <fwp_tape_buffers_release>
    6374:	b9400285 	ldr	w5, [x20]
    6378:	36fffc05 	tbz	w5, #31, 62f8 <fwp_tape_scope_release+0x78>
    637c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    6380:	a94663f7 	ldp	x23, x24, [sp, #96]
    6384:	f9403bf9 	ldr	x25, [sp, #112]
    6388:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    638c:	f947f400 	ldr	x0, [x0, #4072]
    6390:	f94017e2 	ldr	x2, [sp, #40]
    6394:	f9400001 	ldr	x1, [x0]
    6398:	eb010042 	subs	x2, x2, x1
    639c:	d2800001 	mov	x1, #0x0                   	// #0
    63a0:	540000a1 	b.ne	63b4 <fwp_tape_scope_release+0x134>  // b.any
    63a4:	a9437bfd 	ldp	x29, x30, [sp, #48]
    63a8:	a94453f3 	ldp	x19, x20, [sp, #64]
    63ac:	910203ff 	add	sp, sp, #0x80
    63b0:	d65f03c0 	ret
    63b4:	a9055bf5 	stp	x21, x22, [sp, #80]
    63b8:	a90663f7 	stp	x23, x24, [sp, #96]
    63bc:	f9003bf9 	str	x25, [sp, #112]
    63c0:	97fff110 	bl	2800 <__stack_chk_fail@plt>

00000000000063c4 <fwp_drop4>:
    63c4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    63c8:	910003fd 	mov	x29, sp
    63cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    63d0:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    63d4:	9114c2d5 	add	x21, x22, #0x530
    63d8:	a90153f3 	stp	x19, x20, [sp, #16]
    63dc:	aa0003f3 	mov	x19, x0
    63e0:	f949daa1 	ldr	x1, [x21, #5040]
    63e4:	f949eea0 	ldr	x0, [x21, #5080]
    63e8:	cb010261 	sub	x1, x19, x1
    63ec:	eb00403f 	cmp	x1, x0, lsl #16
    63f0:	54000382 	b.cs	6460 <fwp_drop4+0x9c>  // b.hs, b.nlast
    63f4:	d350fc22 	lsr	x2, x1, #16
    63f8:	f949fea3 	ldr	x3, [x21, #5112]
    63fc:	8b020842 	add	x2, x2, x2, lsl #2
    6400:	d37df042 	lsl	x2, x2, #3
    6404:	8b020060 	add	x0, x3, x2
    6408:	f9401014 	ldr	x20, [x0, #32]
    640c:	b40002b4 	cbz	x20, 6460 <fwp_drop4+0x9c>
    6410:	38626862 	ldrb	w2, [x3, x2]
    6414:	7100085f 	cmp	w2, #0x2
    6418:	540002c0 	b.eq	6470 <fwp_drop4+0xac>  // b.none
    641c:	7100045f 	cmp	w2, #0x1
    6420:	54000201 	b.ne	6460 <fwp_drop4+0x9c>  // b.any
    6424:	29430002 	ldp	w2, w0, [x0, #24]
    6428:	92403c21 	and	x1, x1, #0xffff
    642c:	9b027c21 	mul	x1, x1, x2
    6430:	d360fc21 	lsr	x1, x1, #32
    6434:	eb00003f 	cmp	x1, x0
    6438:	54000142 	b.cs	6460 <fwp_drop4+0x9c>  // b.hs, b.nlast
    643c:	8b010294 	add	x20, x20, x1
    6440:	39400280 	ldrb	w0, [x20]
    6444:	340000e0 	cbz	w0, 6460 <fwp_drop4+0x9c>
    6448:	7100041f 	cmp	w0, #0x1
    644c:	540001e0 	b.eq	6488 <fwp_drop4+0xc4>  // b.none
    6450:	7103fc1f 	cmp	w0, #0xff
    6454:	540007e0 	b.eq	6550 <fwp_drop4+0x18c>  // b.none
    6458:	51000400 	sub	w0, w0, #0x1
    645c:	39000280 	strb	w0, [x20]
    6460:	a94153f3 	ldp	x19, x20, [sp, #16]
    6464:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6468:	a8c37bfd 	ldp	x29, x30, [sp], #48
    646c:	d65f03c0 	ret
    6470:	72003c3f 	tst	w1, #0xffff
    6474:	54fffe60 	b.eq	6440 <fwp_drop4+0x7c>  // b.none
    6478:	a94153f3 	ldp	x19, x20, [sp, #16]
    647c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6480:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6484:	d65f03c0 	ret
    6488:	9114c2c2 	add	x2, x22, #0x530
    648c:	f9400660 	ldr	x0, [x19, #8]
    6490:	f949d841 	ldr	x1, [x2, #5040]
    6494:	f949ec42 	ldr	x2, [x2, #5080]
    6498:	cb010001 	sub	x1, x0, x1
    649c:	eb02403f 	cmp	x1, x2, lsl #16
    64a0:	54000382 	b.cs	6510 <fwp_drop4+0x14c>  // b.hs, b.nlast
    64a4:	d350fc22 	lsr	x2, x1, #16
    64a8:	8b020842 	add	x2, x2, x2, lsl #2
    64ac:	d37df042 	lsl	x2, x2, #3
    64b0:	8b020064 	add	x4, x3, x2
    64b4:	f9401094 	ldr	x20, [x4, #32]
    64b8:	b40002d4 	cbz	x20, 6510 <fwp_drop4+0x14c>
    64bc:	38626862 	ldrb	w2, [x3, x2]
    64c0:	7100085f 	cmp	w2, #0x2
    64c4:	54000400 	b.eq	6544 <fwp_drop4+0x180>  // b.none
    64c8:	7100045f 	cmp	w2, #0x1
    64cc:	54000221 	b.ne	6510 <fwp_drop4+0x14c>  // b.any
    64d0:	29430883 	ldp	w3, w2, [x4, #24]
    64d4:	92403c21 	and	x1, x1, #0xffff
    64d8:	9b037c21 	mul	x1, x1, x3
    64dc:	d360fc21 	lsr	x1, x1, #32
    64e0:	eb02003f 	cmp	x1, x2
    64e4:	54000162 	b.cs	6510 <fwp_drop4+0x14c>  // b.hs, b.nlast
    64e8:	8b010294 	add	x20, x20, x1
    64ec:	39400281 	ldrb	w1, [x20]
    64f0:	34000101 	cbz	w1, 6510 <fwp_drop4+0x14c>
    64f4:	7100043f 	cmp	w1, #0x1
    64f8:	54000220 	b.eq	653c <fwp_drop4+0x178>  // b.none
    64fc:	7103fc3f 	cmp	w1, #0xff
    6500:	54000660 	b.eq	65cc <fwp_drop4+0x208>  // b.none
    6504:	51000421 	sub	w1, w1, #0x1
    6508:	39000281 	strb	w1, [x20]
    650c:	d503201f 	nop
    6510:	f9400a74 	ldr	x20, [x19, #16]
    6514:	aa1303e0 	mov	x0, x19
    6518:	97fffcea 	bl	58c0 <fwp_rc_free_arr>
    651c:	9114c2c0 	add	x0, x22, #0x530
    6520:	f949d801 	ldr	x1, [x0, #5040]
    6524:	f949ec00 	ldr	x0, [x0, #5080]
    6528:	cb010281 	sub	x1, x20, x1
    652c:	eb00403f 	cmp	x1, x0, lsl #16
    6530:	54fff982 	b.cs	6460 <fwp_drop4+0x9c>  // b.hs, b.nlast
    6534:	aa1403f3 	mov	x19, x20
    6538:	17ffffaf 	b	63f4 <fwp_drop4+0x30>
    653c:	97fffce1 	bl	58c0 <fwp_rc_free_arr>
    6540:	17fffff4 	b	6510 <fwp_drop4+0x14c>
    6544:	72003c3f 	tst	w1, #0xffff
    6548:	54fffe41 	b.ne	6510 <fwp_drop4+0x14c>  // b.any
    654c:	17ffffe8 	b	64ec <fwp_drop4+0x128>
    6550:	ca544681 	eor	x1, x20, x20, lsr #17
    6554:	9114c2c0 	add	x0, x22, #0x530
    6558:	ca412421 	eor	x1, x1, x1, lsr #9
    655c:	92401c21 	and	x1, x1, #0xff
    6560:	910a2422 	add	x2, x1, #0x289
    6564:	8b010c01 	add	x1, x0, x1, lsl #3
    6568:	8b020c02 	add	x2, x0, x2, lsl #3
    656c:	f94a2420 	ldr	x0, [x1, #5192]
    6570:	b50000a0 	cbnz	x0, 6584 <fwp_drop4+0x1c0>
    6574:	14000013 	b	65c0 <fwp_drop4+0x1fc>
    6578:	91004002 	add	x2, x0, #0x10
    657c:	f9400800 	ldr	x0, [x0, #16]
    6580:	b4000200 	cbz	x0, 65c0 <fwp_drop4+0x1fc>
    6584:	f9400001 	ldr	x1, [x0]
    6588:	eb14003f 	cmp	x1, x20
    658c:	54ffff61 	b.ne	6578 <fwp_drop4+0x1b4>  // b.any
    6590:	f9400041 	ldr	x1, [x2]
    6594:	f9400420 	ldr	x0, [x1, #8]
    6598:	d1000400 	sub	x0, x0, #0x1
    659c:	f9000420 	str	x0, [x1, #8]
    65a0:	f103f81f 	cmp	x0, #0xfe
    65a4:	54fff5e1 	b.ne	6460 <fwp_drop4+0x9c>  // b.any
    65a8:	39400280 	ldrb	w0, [x20]
    65ac:	7103fc1f 	cmp	w0, #0xff
    65b0:	54000460 	b.eq	663c <fwp_drop4+0x278>  // b.none
    65b4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    65b8:	39000280 	strb	w0, [x20]
    65bc:	17ffffa9 	b	6460 <fwp_drop4+0x9c>
    65c0:	f0000020 	adrp	x0, d000 <__modti3+0x2c0>
    65c4:	91088000 	add	x0, x0, #0x220
    65c8:	97fff60e 	bl	3e00 <fwp_trap>
    65cc:	ca544680 	eor	x0, x20, x20, lsr #17
    65d0:	9114c2c1 	add	x1, x22, #0x530
    65d4:	ca402400 	eor	x0, x0, x0, lsr #9
    65d8:	92401c00 	and	x0, x0, #0xff
    65dc:	910a2402 	add	x2, x0, #0x289
    65e0:	8b000c20 	add	x0, x1, x0, lsl #3
    65e4:	8b020c22 	add	x2, x1, x2, lsl #3
    65e8:	f94a2400 	ldr	x0, [x0, #5192]
    65ec:	b50000a0 	cbnz	x0, 6600 <fwp_drop4+0x23c>
    65f0:	17fffff4 	b	65c0 <fwp_drop4+0x1fc>
    65f4:	91004002 	add	x2, x0, #0x10
    65f8:	f9400800 	ldr	x0, [x0, #16]
    65fc:	b4fffe20 	cbz	x0, 65c0 <fwp_drop4+0x1fc>
    6600:	f9400001 	ldr	x1, [x0]
    6604:	eb14003f 	cmp	x1, x20
    6608:	54ffff61 	b.ne	65f4 <fwp_drop4+0x230>  // b.any
    660c:	f9400041 	ldr	x1, [x2]
    6610:	f9400420 	ldr	x0, [x1, #8]
    6614:	d1000400 	sub	x0, x0, #0x1
    6618:	f9000420 	str	x0, [x1, #8]
    661c:	f103f81f 	cmp	x0, #0xfe
    6620:	54fff781 	b.ne	6510 <fwp_drop4+0x14c>  // b.any
    6624:	39400280 	ldrb	w0, [x20]
    6628:	7103fc1f 	cmp	w0, #0xff
    662c:	540000e0 	b.eq	6648 <fwp_drop4+0x284>  // b.none
    6630:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6634:	39000280 	strb	w0, [x20]
    6638:	17ffffb6 	b	6510 <fwp_drop4+0x14c>
    663c:	aa1403e0 	mov	x0, x20
    6640:	97fff610 	bl	3e80 <fwp_rc_forget_slot.part.0>
    6644:	17ffffdc 	b	65b4 <fwp_drop4+0x1f0>
    6648:	aa1403e0 	mov	x0, x20
    664c:	97fff60d 	bl	3e80 <fwp_rc_forget_slot.part.0>
    6650:	17fffff8 	b	6630 <fwp_drop4+0x26c>

0000000000006654 <fwp_arg_drop37>:
    6654:	7100003f 	cmp	w1, #0x0
    6658:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    665c:	54000041 	b.ne	6664 <fwp_arg_drop37+0x10>  // b.any
    6660:	d65f03c0 	ret
    6664:	f9400000 	ldr	x0, [x0]
    6668:	17ffff57 	b	63c4 <fwp_drop4>
    666c:	d503201f 	nop

0000000000006670 <fwp_task_dispose>:
    6670:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6674:	910003fd 	mov	x29, sp
    6678:	f9000bf3 	str	x19, [sp, #16]
    667c:	aa0003f3 	mov	x19, x0
    6680:	39414000 	ldrb	w0, [x0, #80]
    6684:	36000720 	tbz	w0, #0, 6768 <fwp_task_dispose+0xf8>
    6688:	f9400a60 	ldr	x0, [x19, #16]
    668c:	b50006e0 	cbnz	x0, 6768 <fwp_task_dispose+0xf8>
    6690:	a9478660 	ldp	x0, x1, [x19, #120]
    6694:	39014e7f 	strb	wzr, [x19, #83]
    6698:	f9003e7f 	str	xzr, [x19, #120]
    669c:	f100003f 	cmp	x1, #0x0
    66a0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    66a4:	54000040 	b.eq	66ac <fwp_task_dispose+0x3c>  // b.none
    66a8:	d63f0020 	blr	x1
    66ac:	f9405660 	ldr	x0, [x19, #168]
    66b0:	97fff690 	bl	40f0 <fwp_mem_free>
    66b4:	f900567f 	str	xzr, [x19, #168]
    66b8:	b9405e60 	ldr	w0, [x19, #92]
    66bc:	7100041f 	cmp	w0, #0x1
    66c0:	54000420 	b.eq	6744 <fwp_task_dispose+0xd4>  // b.none
    66c4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    66c8:	9114c042 	add	x2, x2, #0x530
    66cc:	f949d840 	ldr	x0, [x2, #5040]
    66d0:	f949ec41 	ldr	x1, [x2, #5080]
    66d4:	cb000260 	sub	x0, x19, x0
    66d8:	eb01401f 	cmp	x0, x1, lsl #16
    66dc:	540002e2 	b.cs	6738 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    66e0:	d350fc01 	lsr	x1, x0, #16
    66e4:	f949fc44 	ldr	x4, [x2, #5112]
    66e8:	8b010821 	add	x1, x1, x1, lsl #2
    66ec:	d37df021 	lsl	x1, x1, #3
    66f0:	8b010083 	add	x3, x4, x1
    66f4:	f9401062 	ldr	x2, [x3, #32]
    66f8:	b4000202 	cbz	x2, 6738 <fwp_task_dispose+0xc8>
    66fc:	38616881 	ldrb	w1, [x4, x1]
    6700:	7100083f 	cmp	w1, #0x2
    6704:	54000280 	b.eq	6754 <fwp_task_dispose+0xe4>  // b.none
    6708:	7100043f 	cmp	w1, #0x1
    670c:	54000161 	b.ne	6738 <fwp_task_dispose+0xc8>  // b.any
    6710:	29430464 	ldp	w4, w1, [x3, #24]
    6714:	92403c00 	and	x0, x0, #0xffff
    6718:	9b047c00 	mul	x0, x0, x4
    671c:	d360fc00 	lsr	x0, x0, #32
    6720:	eb01001f 	cmp	x0, x1
    6724:	540000a2 	b.cs	6738 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6728:	8b000042 	add	x2, x2, x0
    672c:	39400040 	ldrb	w0, [x2]
    6730:	7100041f 	cmp	w0, #0x1
    6734:	54000080 	b.eq	6744 <fwp_task_dispose+0xd4>  // b.none
    6738:	f9400bf3 	ldr	x19, [sp, #16]
    673c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6740:	d65f03c0 	ret
    6744:	aa1303e0 	mov	x0, x19
    6748:	f9400bf3 	ldr	x19, [sp, #16]
    674c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6750:	17fff668 	b	40f0 <fwp_mem_free>
    6754:	72003c1f 	tst	w0, #0xffff
    6758:	54fffea0 	b.eq	672c <fwp_task_dispose+0xbc>  // b.none
    675c:	f9400bf3 	ldr	x19, [sp, #16]
    6760:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6764:	d65f03c0 	ret
    6768:	97fff03a 	bl	2850 <abort@plt>
    676c:	d503201f 	nop

0000000000006770 <fwp_free_zombie>:
    6770:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6774:	910003fd 	mov	x29, sp
    6778:	a90153f3 	stp	x19, x20, [sp, #16]
    677c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6780:	9100c281 	add	x1, x20, #0x30
    6784:	f9404833 	ldr	x19, [x1, #144]
    6788:	b4000333 	cbz	x19, 67ec <fwp_free_zombie+0x7c>
    678c:	f9400820 	ldr	x0, [x1, #16]
    6790:	eb00027f 	cmp	x19, x0
    6794:	540002c0 	b.eq	67ec <fwp_free_zombie+0x7c>  // b.none
    6798:	b9409822 	ldr	w2, [x1, #152]
    679c:	f9400a60 	ldr	x0, [x19, #16]
    67a0:	7100fc5f 	cmp	w2, #0x3f
    67a4:	5400078c 	b.gt	6894 <fwp_free_zombie+0x124>
    67a8:	91028023 	add	x3, x1, #0xa0
    67ac:	11000444 	add	w4, w2, #0x1
    67b0:	b9009824 	str	w4, [x1, #152]
    67b4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67b8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    67bc:	a9530261 	ldp	x1, x0, [x19, #304]
    67c0:	b4000741 	cbz	x1, 68a8 <fwp_free_zombie+0x138>
    67c4:	f9009c20 	str	x0, [x1, #312]
    67c8:	b4000040 	cbz	x0, 67d0 <fwp_free_zombie+0x60>
    67cc:	f9009801 	str	x1, [x0, #304]
    67d0:	9100c294 	add	x20, x20, #0x30
    67d4:	b9405e60 	ldr	w0, [x19, #92]
    67d8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    67dc:	f9004a9f 	str	xzr, [x20, #144]
    67e0:	34000140 	cbz	w0, 6808 <fwp_free_zombie+0x98>
    67e4:	7100041f 	cmp	w0, #0x1
    67e8:	54000080 	b.eq	67f8 <fwp_free_zombie+0x88>  // b.none
    67ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    67f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67f4:	d65f03c0 	ret
    67f8:	aa1303e0 	mov	x0, x19
    67fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6800:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6804:	17ffff9b 	b	6670 <fwp_task_dispose>
    6808:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xcb0>
    680c:	9114c082 	add	x2, x4, #0x530
    6810:	f949d841 	ldr	x1, [x2, #5040]
    6814:	f949ec40 	ldr	x0, [x2, #5080]
    6818:	cb010261 	sub	x1, x19, x1
    681c:	eb00403f 	cmp	x1, x0, lsl #16
    6820:	54fffe62 	b.cs	67ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6824:	d350fc20 	lsr	x0, x1, #16
    6828:	f949fc43 	ldr	x3, [x2, #5112]
    682c:	8b000800 	add	x0, x0, x0, lsl #2
    6830:	d37df000 	lsl	x0, x0, #3
    6834:	8b000062 	add	x2, x3, x0
    6838:	f9401054 	ldr	x20, [x2, #32]
    683c:	b4fffd94 	cbz	x20, 67ec <fwp_free_zombie+0x7c>
    6840:	38606860 	ldrb	w0, [x3, x0]
    6844:	7100081f 	cmp	w0, #0x2
    6848:	54000360 	b.eq	68b4 <fwp_free_zombie+0x144>  // b.none
    684c:	7100041f 	cmp	w0, #0x1
    6850:	54fffce1 	b.ne	67ec <fwp_free_zombie+0x7c>  // b.any
    6854:	29430043 	ldp	w3, w0, [x2, #24]
    6858:	92403c21 	and	x1, x1, #0xffff
    685c:	9b037c21 	mul	x1, x1, x3
    6860:	d360fc21 	lsr	x1, x1, #32
    6864:	eb00003f 	cmp	x1, x0
    6868:	54fffc22 	b.cs	67ec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    686c:	8b010294 	add	x20, x20, x1
    6870:	39400280 	ldrb	w0, [x20]
    6874:	34fffbc0 	cbz	w0, 67ec <fwp_free_zombie+0x7c>
    6878:	7100041f 	cmp	w0, #0x1
    687c:	54fffbe0 	b.eq	67f8 <fwp_free_zombie+0x88>  // b.none
    6880:	7103fc1f 	cmp	w0, #0xff
    6884:	540001e0 	b.eq	68c0 <fwp_free_zombie+0x150>  // b.none
    6888:	51000400 	sub	w0, w0, #0x1
    688c:	39000280 	strb	w0, [x20]
    6890:	17ffffd7 	b	67ec <fwp_free_zombie+0x7c>
    6894:	f9400e61 	ldr	x1, [x19, #24]
    6898:	97fff022 	bl	2920 <munmap@plt>
    689c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    68a0:	a9530261 	ldp	x1, x0, [x19, #304]
    68a4:	b5fff901 	cbnz	x1, 67c4 <fwp_free_zombie+0x54>
    68a8:	9100c282 	add	x2, x20, #0x30
    68ac:	f9015040 	str	x0, [x2, #672]
    68b0:	17ffffc6 	b	67c8 <fwp_free_zombie+0x58>
    68b4:	72003c3f 	tst	w1, #0xffff
    68b8:	54fff9a1 	b.ne	67ec <fwp_free_zombie+0x7c>  // b.any
    68bc:	17ffffed 	b	6870 <fwp_free_zombie+0x100>
    68c0:	ca544680 	eor	x0, x20, x20, lsr #17
    68c4:	9114c084 	add	x4, x4, #0x530
    68c8:	ca402400 	eor	x0, x0, x0, lsr #9
    68cc:	92401c00 	and	x0, x0, #0xff
    68d0:	910a2402 	add	x2, x0, #0x289
    68d4:	8b000c80 	add	x0, x4, x0, lsl #3
    68d8:	8b020c82 	add	x2, x4, x2, lsl #3
    68dc:	f94a2400 	ldr	x0, [x0, #5192]
    68e0:	b50000a0 	cbnz	x0, 68f4 <fwp_free_zombie+0x184>
    68e4:	14000013 	b	6930 <fwp_free_zombie+0x1c0>
    68e8:	91004002 	add	x2, x0, #0x10
    68ec:	f9400800 	ldr	x0, [x0, #16]
    68f0:	b4000200 	cbz	x0, 6930 <fwp_free_zombie+0x1c0>
    68f4:	f9400001 	ldr	x1, [x0]
    68f8:	eb14003f 	cmp	x1, x20
    68fc:	54ffff61 	b.ne	68e8 <fwp_free_zombie+0x178>  // b.any
    6900:	f9400041 	ldr	x1, [x2]
    6904:	f9400420 	ldr	x0, [x1, #8]
    6908:	d1000400 	sub	x0, x0, #0x1
    690c:	f9000420 	str	x0, [x1, #8]
    6910:	f103f81f 	cmp	x0, #0xfe
    6914:	54fff6c1 	b.ne	67ec <fwp_free_zombie+0x7c>  // b.any
    6918:	39400280 	ldrb	w0, [x20]
    691c:	7103fc1f 	cmp	w0, #0xff
    6920:	540000e0 	b.eq	693c <fwp_free_zombie+0x1cc>  // b.none
    6924:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6928:	39000280 	strb	w0, [x20]
    692c:	17ffffb0 	b	67ec <fwp_free_zombie+0x7c>
    6930:	f0000020 	adrp	x0, d000 <__modti3+0x2c0>
    6934:	91088000 	add	x0, x0, #0x220
    6938:	97fff532 	bl	3e00 <fwp_trap>
    693c:	aa1403e0 	mov	x0, x20
    6940:	97fff550 	bl	3e80 <fwp_rc_forget_slot.part.0>
    6944:	17fffff8 	b	6924 <fwp_free_zombie+0x1b4>
    6948:	d503201f 	nop
    694c:	d503201f 	nop

0000000000006950 <fwp_block>:
    6950:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6954:	910003fd 	mov	x29, sp
    6958:	a90153f3 	stp	x19, x20, [sp, #16]
    695c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6960:	9100c274 	add	x20, x19, #0x30
    6964:	f9401a82 	ldr	x2, [x20, #48]
    6968:	b4000642 	cbz	x2, 6a30 <fwp_block+0xe0>
    696c:	9100c261 	add	x1, x19, #0x30
    6970:	f9408040 	ldr	x0, [x2, #256]
    6974:	f9001820 	str	x0, [x1, #48]
    6978:	b40006a0 	cbz	x0, 6a4c <fwp_block+0xfc>
    697c:	d503201f 	nop
    6980:	9100c263 	add	x3, x19, #0x30
    6984:	3901505f 	strb	wzr, [x2, #84]
    6988:	f9400864 	ldr	x4, [x3, #16]
    698c:	eb02009f 	cmp	x4, x2
    6990:	54000440 	b.eq	6a18 <fwp_block+0xc8>  // b.none
    6994:	f9415465 	ldr	x5, [x3, #680]
    6998:	f9000862 	str	x2, [x3, #16]
    699c:	f9400441 	ldr	x1, [x2, #8]
    69a0:	f9004885 	str	x5, [x4, #144]
    69a4:	f9415865 	ldr	x5, [x3, #688]
    69a8:	f9004c85 	str	x5, [x4, #152]
    69ac:	f9415c65 	ldr	x5, [x3, #696]
    69b0:	f9005085 	str	x5, [x4, #160]
    69b4:	f9416065 	ldr	x5, [x3, #704]
    69b8:	f9005485 	str	x5, [x4, #168]
    69bc:	f9416465 	ldr	x5, [x3, #712]
    69c0:	f9005885 	str	x5, [x4, #176]
    69c4:	f9416865 	ldr	x5, [x3, #720]
    69c8:	f9005c85 	str	x5, [x4, #184]
    69cc:	f9416c65 	ldr	x5, [x3, #728]
    69d0:	f9006085 	str	x5, [x4, #192]
    69d4:	f9400480 	ldr	x0, [x4, #8]
    69d8:	f9404844 	ldr	x4, [x2, #144]
    69dc:	f9015464 	str	x4, [x3, #680]
    69e0:	f9404c44 	ldr	x4, [x2, #152]
    69e4:	f9015864 	str	x4, [x3, #688]
    69e8:	f9405044 	ldr	x4, [x2, #160]
    69ec:	f9015c64 	str	x4, [x3, #696]
    69f0:	f9405444 	ldr	x4, [x2, #168]
    69f4:	f9016064 	str	x4, [x3, #704]
    69f8:	f9405844 	ldr	x4, [x2, #176]
    69fc:	f9016464 	str	x4, [x3, #712]
    6a00:	a94b8844 	ldp	x4, x2, [x2, #184]
    6a04:	f9016864 	str	x4, [x3, #720]
    6a08:	f9016c62 	str	x2, [x3, #728]
    6a0c:	97ffef95 	bl	2860 <swapcontext@plt>
    6a10:	97ffff58 	bl	6770 <fwp_free_zombie>
    6a14:	d503201f 	nop
    6a18:	9100c260 	add	x0, x19, #0x30
    6a1c:	b942e000 	ldr	w0, [x0, #736]
    6a20:	340001a0 	cbz	w0, 6a54 <fwp_block+0x104>
    6a24:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a28:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a2c:	d65f03c0 	ret
    6a30:	97fff73c 	bl	4720 <fwp_poll_events>
    6a34:	f9401a82 	ldr	x2, [x20, #48]
    6a38:	b4ffffc2 	cbz	x2, 6a30 <fwp_block+0xe0>
    6a3c:	9100c261 	add	x1, x19, #0x30
    6a40:	f9408040 	ldr	x0, [x2, #256]
    6a44:	f9001820 	str	x0, [x1, #48]
    6a48:	b5fff9c0 	cbnz	x0, 6980 <fwp_block+0x30>
    6a4c:	f900143f 	str	xzr, [x1, #40]
    6a50:	17ffffcc 	b	6980 <fwp_block+0x30>
    6a54:	f0000020 	adrp	x0, d000 <__modti3+0x2c0>
    6a58:	9112e000 	add	x0, x0, #0x4b8
    6a5c:	97ffefcd 	bl	2990 <getenv@plt>
    6a60:	5284e202 	mov	w2, #0x2710                	// #10000
    6a64:	b4000060 	cbz	x0, 6a70 <fwp_block+0x120>
    6a68:	39400001 	ldrb	w1, [x0]
    6a6c:	350000c1 	cbnz	w1, 6a84 <fwp_block+0x134>
    6a70:	9100c273 	add	x19, x19, #0x30
    6a74:	b902e262 	str	w2, [x19, #736]
    6a78:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a7c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a80:	d65f03c0 	ret
    6a84:	52800142 	mov	w2, #0xa                   	// #10
    6a88:	d2800001 	mov	x1, #0x0                   	// #0
    6a8c:	97ffef11 	bl	26d0 <strtoll@plt>
    6a90:	d1000403 	sub	x3, x0, #0x1
    6a94:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6a98:	eb02007f 	cmp	x3, x2
    6a9c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6aa0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6aa4:	17fffff3 	b	6a70 <fwp_block+0x120>
    6aa8:	d503201f 	nop
    6aac:	d503201f 	nop

0000000000006ab0 <fwp_drop10>:
    6ab0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6ab4:	910003fd 	mov	x29, sp
    6ab8:	a90153f3 	stp	x19, x20, [sp, #16]
    6abc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    6ac0:	f90013f5 	str	x21, [sp, #32]
    6ac4:	9114c275 	add	x21, x19, #0x530
    6ac8:	f949daa1 	ldr	x1, [x21, #5040]
    6acc:	f949eea2 	ldr	x2, [x21, #5080]
    6ad0:	cb010001 	sub	x1, x0, x1
    6ad4:	eb02403f 	cmp	x1, x2, lsl #16
    6ad8:	54000382 	b.cs	6b48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6adc:	d350fc22 	lsr	x2, x1, #16
    6ae0:	f949fea3 	ldr	x3, [x21, #5112]
    6ae4:	8b020842 	add	x2, x2, x2, lsl #2
    6ae8:	d37df042 	lsl	x2, x2, #3
    6aec:	8b020064 	add	x4, x3, x2
    6af0:	f9401094 	ldr	x20, [x4, #32]
    6af4:	b40002b4 	cbz	x20, 6b48 <fwp_drop10+0x98>
    6af8:	38626862 	ldrb	w2, [x3, x2]
    6afc:	7100085f 	cmp	w2, #0x2
    6b00:	540007a0 	b.eq	6bf4 <fwp_drop10+0x144>  // b.none
    6b04:	7100045f 	cmp	w2, #0x1
    6b08:	54000201 	b.ne	6b48 <fwp_drop10+0x98>  // b.any
    6b0c:	29430885 	ldp	w5, w2, [x4, #24]
    6b10:	92403c21 	and	x1, x1, #0xffff
    6b14:	9b057c21 	mul	x1, x1, x5
    6b18:	d360fc21 	lsr	x1, x1, #32
    6b1c:	eb02003f 	cmp	x1, x2
    6b20:	54000142 	b.cs	6b48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b24:	8b010294 	add	x20, x20, x1
    6b28:	39400281 	ldrb	w1, [x20]
    6b2c:	340000e1 	cbz	w1, 6b48 <fwp_drop10+0x98>
    6b30:	7100043f 	cmp	w1, #0x1
    6b34:	54000120 	b.eq	6b58 <fwp_drop10+0xa8>  // b.none
    6b38:	7103fc3f 	cmp	w1, #0xff
    6b3c:	540007c0 	b.eq	6c34 <fwp_drop10+0x184>  // b.none
    6b40:	51000421 	sub	w1, w1, #0x1
    6b44:	39000281 	strb	w1, [x20]
    6b48:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b4c:	f94013f5 	ldr	x21, [sp, #32]
    6b50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b54:	d65f03c0 	ret
    6b58:	f9400001 	ldr	x1, [x0]
    6b5c:	b7f80581 	tbnz	x1, #63, 6c0c <fwp_drop10+0x15c>
    6b60:	9114c273 	add	x19, x19, #0x530
    6b64:	f949da61 	ldr	x1, [x19, #5040]
    6b68:	f949ee62 	ldr	x2, [x19, #5080]
    6b6c:	cb010001 	sub	x1, x0, x1
    6b70:	eb02403f 	cmp	x1, x2, lsl #16
    6b74:	54fffea2 	b.cs	6b48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b78:	d350fc22 	lsr	x2, x1, #16
    6b7c:	8b020842 	add	x2, x2, x2, lsl #2
    6b80:	d37df042 	lsl	x2, x2, #3
    6b84:	8b020065 	add	x5, x3, x2
    6b88:	f94010a4 	ldr	x4, [x5, #32]
    6b8c:	b4fffde4 	cbz	x4, 6b48 <fwp_drop10+0x98>
    6b90:	38626862 	ldrb	w2, [x3, x2]
    6b94:	7100085f 	cmp	w2, #0x2
    6b98:	54000220 	b.eq	6bdc <fwp_drop10+0x12c>  // b.none
    6b9c:	7100045f 	cmp	w2, #0x1
    6ba0:	54fffd41 	b.ne	6b48 <fwp_drop10+0x98>  // b.any
    6ba4:	294308a3 	ldp	w3, w2, [x5, #24]
    6ba8:	92403c21 	and	x1, x1, #0xffff
    6bac:	9b037c21 	mul	x1, x1, x3
    6bb0:	d360fc21 	lsr	x1, x1, #32
    6bb4:	eb02003f 	cmp	x1, x2
    6bb8:	54fffc82 	b.cs	6b48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6bbc:	8b010084 	add	x4, x4, x1
    6bc0:	39400081 	ldrb	w1, [x4]
    6bc4:	7100043f 	cmp	w1, #0x1
    6bc8:	54fffc01 	b.ne	6b48 <fwp_drop10+0x98>  // b.any
    6bcc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bd0:	f94013f5 	ldr	x21, [sp, #32]
    6bd4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bd8:	17fff546 	b	40f0 <fwp_mem_free>
    6bdc:	72003c3f 	tst	w1, #0xffff
    6be0:	54ffff00 	b.eq	6bc0 <fwp_drop10+0x110>  // b.none
    6be4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6be8:	f94013f5 	ldr	x21, [sp, #32]
    6bec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6bf0:	d65f03c0 	ret
    6bf4:	72003c3f 	tst	w1, #0xffff
    6bf8:	54fff980 	b.eq	6b28 <fwp_drop10+0x78>  // b.none
    6bfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c00:	f94013f5 	ldr	x21, [sp, #32]
    6c04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c08:	d65f03c0 	ret
    6c0c:	f9400414 	ldr	x20, [x0, #8]
    6c10:	97fffb2c 	bl	58c0 <fwp_rc_free_arr>
    6c14:	9114c260 	add	x0, x19, #0x530
    6c18:	f949d801 	ldr	x1, [x0, #5040]
    6c1c:	f949ec00 	ldr	x0, [x0, #5080]
    6c20:	cb010281 	sub	x1, x20, x1
    6c24:	eb00403f 	cmp	x1, x0, lsl #16
    6c28:	54fff902 	b.cs	6b48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c2c:	aa1403e0 	mov	x0, x20
    6c30:	17ffffab 	b	6adc <fwp_drop10+0x2c>
    6c34:	ca544680 	eor	x0, x20, x20, lsr #17
    6c38:	9114c273 	add	x19, x19, #0x530
    6c3c:	ca402400 	eor	x0, x0, x0, lsr #9
    6c40:	92401c00 	and	x0, x0, #0xff
    6c44:	910a2402 	add	x2, x0, #0x289
    6c48:	8b000e60 	add	x0, x19, x0, lsl #3
    6c4c:	8b020e62 	add	x2, x19, x2, lsl #3
    6c50:	f94a2400 	ldr	x0, [x0, #5192]
    6c54:	b50000a0 	cbnz	x0, 6c68 <fwp_drop10+0x1b8>
    6c58:	14000013 	b	6ca4 <fwp_drop10+0x1f4>
    6c5c:	91004002 	add	x2, x0, #0x10
    6c60:	f9400800 	ldr	x0, [x0, #16]
    6c64:	b4000200 	cbz	x0, 6ca4 <fwp_drop10+0x1f4>
    6c68:	f9400001 	ldr	x1, [x0]
    6c6c:	eb14003f 	cmp	x1, x20
    6c70:	54ffff61 	b.ne	6c5c <fwp_drop10+0x1ac>  // b.any
    6c74:	f9400041 	ldr	x1, [x2]
    6c78:	f9400420 	ldr	x0, [x1, #8]
    6c7c:	d1000400 	sub	x0, x0, #0x1
    6c80:	f9000420 	str	x0, [x1, #8]
    6c84:	f103f81f 	cmp	x0, #0xfe
    6c88:	54fff601 	b.ne	6b48 <fwp_drop10+0x98>  // b.any
    6c8c:	39400280 	ldrb	w0, [x20]
    6c90:	7103fc1f 	cmp	w0, #0xff
    6c94:	540000e0 	b.eq	6cb0 <fwp_drop10+0x200>  // b.none
    6c98:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c9c:	39000280 	strb	w0, [x20]
    6ca0:	17ffffaa 	b	6b48 <fwp_drop10+0x98>
    6ca4:	f0000020 	adrp	x0, d000 <__modti3+0x2c0>
    6ca8:	91088000 	add	x0, x0, #0x220
    6cac:	97fff455 	bl	3e00 <fwp_trap>
    6cb0:	aa1403e0 	mov	x0, x20
    6cb4:	97fff473 	bl	3e80 <fwp_rc_forget_slot.part.0>
    6cb8:	17fffff8 	b	6c98 <fwp_drop10+0x1e8>
    6cbc:	d503201f 	nop

0000000000006cc0 <fwp_caps173>:
    6cc0:	34000041 	cbz	w1, 6cc8 <fwp_caps173+0x8>
    6cc4:	d65f03c0 	ret
    6cc8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    6ccc:	9114c063 	add	x3, x3, #0x530
    6cd0:	f949d861 	ldr	x1, [x3, #5040]
    6cd4:	f949ec62 	ldr	x2, [x3, #5080]
    6cd8:	cb010001 	sub	x1, x0, x1
    6cdc:	eb02403f 	cmp	x1, x2, lsl #16
    6ce0:	54ffff22 	b.cs	6cc4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6ce4:	d350fc22 	lsr	x2, x1, #16
    6ce8:	f949fc65 	ldr	x5, [x3, #5112]
    6cec:	8b020842 	add	x2, x2, x2, lsl #2
    6cf0:	d37df042 	lsl	x2, x2, #3
    6cf4:	8b0200a4 	add	x4, x5, x2
    6cf8:	f9401083 	ldr	x3, [x4, #32]
    6cfc:	b4fffe43 	cbz	x3, 6cc4 <fwp_caps173+0x4>
    6d00:	386268a2 	ldrb	w2, [x5, x2]
    6d04:	7100085f 	cmp	w2, #0x2
    6d08:	540001c0 	b.eq	6d40 <fwp_caps173+0x80>  // b.none
    6d0c:	7100045f 	cmp	w2, #0x1
    6d10:	54fffda1 	b.ne	6cc4 <fwp_caps173+0x4>  // b.any
    6d14:	29430885 	ldp	w5, w2, [x4, #24]
    6d18:	92403c21 	and	x1, x1, #0xffff
    6d1c:	9b057c21 	mul	x1, x1, x5
    6d20:	d360fc21 	lsr	x1, x1, #32
    6d24:	eb02003f 	cmp	x1, x2
    6d28:	54fffce2 	b.cs	6cc4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6d2c:	8b010063 	add	x3, x3, x1
    6d30:	39400061 	ldrb	w1, [x3]
    6d34:	7100043f 	cmp	w1, #0x1
    6d38:	54fffc61 	b.ne	6cc4 <fwp_caps173+0x4>  // b.any
    6d3c:	17fff4ed 	b	40f0 <fwp_mem_free>
    6d40:	72003c3f 	tst	w1, #0xffff
    6d44:	54ffff60 	b.eq	6d30 <fwp_caps173+0x70>  // b.none
    6d48:	d65f03c0 	ret
    6d4c:	d503201f 	nop

0000000000006d50 <fwp_args37>:
    6d50:	7100003f 	cmp	w1, #0x0
    6d54:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6d58:	54000041 	b.ne	6d60 <fwp_args37+0x10>  // b.any
    6d5c:	d65f03c0 	ret
    6d60:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    6d64:	9114c042 	add	x2, x2, #0x530
    6d68:	f9400001 	ldr	x1, [x0]
    6d6c:	f949d843 	ldr	x3, [x2, #5040]
    6d70:	f949ec40 	ldr	x0, [x2, #5080]
    6d74:	cb030021 	sub	x1, x1, x3
    6d78:	eb00403f 	cmp	x1, x0, lsl #16
    6d7c:	54ffff02 	b.cs	6d5c <fwp_args37+0xc>  // b.hs, b.nlast
    6d80:	d350fc20 	lsr	x0, x1, #16
    6d84:	f949fc44 	ldr	x4, [x2, #5112]
    6d88:	8b000800 	add	x0, x0, x0, lsl #2
    6d8c:	d37df002 	lsl	x2, x0, #3
    6d90:	8b020083 	add	x3, x4, x2
    6d94:	f9401060 	ldr	x0, [x3, #32]
    6d98:	b4fffe20 	cbz	x0, 6d5c <fwp_args37+0xc>
    6d9c:	38626882 	ldrb	w2, [x4, x2]
    6da0:	7100085f 	cmp	w2, #0x2
    6da4:	54000220 	b.eq	6de8 <fwp_args37+0x98>  // b.none
    6da8:	7100045f 	cmp	w2, #0x1
    6dac:	54fffd81 	b.ne	6d5c <fwp_args37+0xc>  // b.any
    6db0:	29430864 	ldp	w4, w2, [x3, #24]
    6db4:	92403c21 	and	x1, x1, #0xffff
    6db8:	9b047c21 	mul	x1, x1, x4
    6dbc:	d360fc21 	lsr	x1, x1, #32
    6dc0:	eb02003f 	cmp	x1, x2
    6dc4:	54fffcc2 	b.cs	6d5c <fwp_args37+0xc>  // b.hs, b.nlast
    6dc8:	8b010000 	add	x0, x0, x1
    6dcc:	39400001 	ldrb	w1, [x0]
    6dd0:	34fffc61 	cbz	w1, 6d5c <fwp_args37+0xc>
    6dd4:	7103f43f 	cmp	w1, #0xfd
    6dd8:	540000e8 	b.hi	6df4 <fwp_args37+0xa4>  // b.pmore
    6ddc:	11000421 	add	w1, w1, #0x1
    6de0:	39000001 	strb	w1, [x0]
    6de4:	d65f03c0 	ret
    6de8:	72003c3f 	tst	w1, #0xffff
    6dec:	54ffff00 	b.eq	6dcc <fwp_args37+0x7c>  // b.none
    6df0:	d65f03c0 	ret
    6df4:	17fff538 	b	42d4 <fwp_rc_wide_dup>
    6df8:	d503201f 	nop
    6dfc:	d503201f 	nop

0000000000006e00 <fwp_caps37>:
    6e00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6e04:	910003fd 	mov	x29, sp
    6e08:	f9000bf3 	str	x19, [sp, #16]
    6e0c:	aa0003f3 	mov	x19, x0
    6e10:	b9400400 	ldr	w0, [x0, #4]
    6e14:	340004a0 	cbz	w0, 6ea8 <fwp_caps37+0xa8>
    6e18:	f9400660 	ldr	x0, [x19, #8]
    6e1c:	350004e1 	cbnz	w1, 6eb8 <fwp_caps37+0xb8>
    6e20:	97fffd69 	bl	63c4 <fwp_drop4>
    6e24:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    6e28:	9114c042 	add	x2, x2, #0x530
    6e2c:	f949d840 	ldr	x0, [x2, #5040]
    6e30:	f949ec41 	ldr	x1, [x2, #5080]
    6e34:	cb000260 	sub	x0, x19, x0
    6e38:	eb01401f 	cmp	x0, x1, lsl #16
    6e3c:	54000382 	b.cs	6eac <fwp_caps37+0xac>  // b.hs, b.nlast
    6e40:	d350fc01 	lsr	x1, x0, #16
    6e44:	f949fc44 	ldr	x4, [x2, #5112]
    6e48:	8b010821 	add	x1, x1, x1, lsl #2
    6e4c:	d37df021 	lsl	x1, x1, #3
    6e50:	8b010083 	add	x3, x4, x1
    6e54:	f9401062 	ldr	x2, [x3, #32]
    6e58:	b40002a2 	cbz	x2, 6eac <fwp_caps37+0xac>
    6e5c:	38616881 	ldrb	w1, [x4, x1]
    6e60:	7100083f 	cmp	w1, #0x2
    6e64:	540006c0 	b.eq	6f3c <fwp_caps37+0x13c>  // b.none
    6e68:	7100043f 	cmp	w1, #0x1
    6e6c:	54000201 	b.ne	6eac <fwp_caps37+0xac>  // b.any
    6e70:	29430464 	ldp	w4, w1, [x3, #24]
    6e74:	92403c00 	and	x0, x0, #0xffff
    6e78:	9b047c00 	mul	x0, x0, x4
    6e7c:	d360fc00 	lsr	x0, x0, #32
    6e80:	eb01001f 	cmp	x0, x1
    6e84:	54000142 	b.cs	6eac <fwp_caps37+0xac>  // b.hs, b.nlast
    6e88:	8b000042 	add	x2, x2, x0
    6e8c:	39400040 	ldrb	w0, [x2]
    6e90:	7100041f 	cmp	w0, #0x1
    6e94:	540000c1 	b.ne	6eac <fwp_caps37+0xac>  // b.any
    6e98:	aa1303e0 	mov	x0, x19
    6e9c:	f9400bf3 	ldr	x19, [sp, #16]
    6ea0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ea4:	17fff493 	b	40f0 <fwp_mem_free>
    6ea8:	34fffbe1 	cbz	w1, 6e24 <fwp_caps37+0x24>
    6eac:	f9400bf3 	ldr	x19, [sp, #16]
    6eb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6eb4:	d65f03c0 	ret
    6eb8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    6ebc:	9114c042 	add	x2, x2, #0x530
    6ec0:	f949d843 	ldr	x3, [x2, #5040]
    6ec4:	f949ec41 	ldr	x1, [x2, #5080]
    6ec8:	cb030000 	sub	x0, x0, x3
    6ecc:	eb01401f 	cmp	x0, x1, lsl #16
    6ed0:	54fffee2 	b.cs	6eac <fwp_caps37+0xac>  // b.hs, b.nlast
    6ed4:	d350fc01 	lsr	x1, x0, #16
    6ed8:	f949fc44 	ldr	x4, [x2, #5112]
    6edc:	8b010821 	add	x1, x1, x1, lsl #2
    6ee0:	d37df021 	lsl	x1, x1, #3
    6ee4:	8b010083 	add	x3, x4, x1
    6ee8:	f9401062 	ldr	x2, [x3, #32]
    6eec:	b4fffe02 	cbz	x2, 6eac <fwp_caps37+0xac>
    6ef0:	38616881 	ldrb	w1, [x4, x1]
    6ef4:	7100083f 	cmp	w1, #0x2
    6ef8:	54000280 	b.eq	6f48 <fwp_caps37+0x148>  // b.none
    6efc:	7100043f 	cmp	w1, #0x1
    6f00:	54fffd61 	b.ne	6eac <fwp_caps37+0xac>  // b.any
    6f04:	92403c01 	and	x1, x0, #0xffff
    6f08:	29430064 	ldp	w4, w0, [x3, #24]
    6f0c:	9b047c21 	mul	x1, x1, x4
    6f10:	d360fc21 	lsr	x1, x1, #32
    6f14:	eb00003f 	cmp	x1, x0
    6f18:	54fffca2 	b.cs	6eac <fwp_caps37+0xac>  // b.hs, b.nlast
    6f1c:	8b010042 	add	x2, x2, x1
    6f20:	39400040 	ldrb	w0, [x2]
    6f24:	34fffc40 	cbz	w0, 6eac <fwp_caps37+0xac>
    6f28:	7103f41f 	cmp	w0, #0xfd
    6f2c:	54000148 	b.hi	6f54 <fwp_caps37+0x154>  // b.pmore
    6f30:	11000400 	add	w0, w0, #0x1
    6f34:	39000040 	strb	w0, [x2]
    6f38:	17ffffdd 	b	6eac <fwp_caps37+0xac>
    6f3c:	72003c1f 	tst	w0, #0xffff
    6f40:	54fffb61 	b.ne	6eac <fwp_caps37+0xac>  // b.any
    6f44:	17ffffd2 	b	6e8c <fwp_caps37+0x8c>
    6f48:	72003c1f 	tst	w0, #0xffff
    6f4c:	54fffb01 	b.ne	6eac <fwp_caps37+0xac>  // b.any
    6f50:	17fffff4 	b	6f20 <fwp_caps37+0x120>
    6f54:	f9400bf3 	ldr	x19, [sp, #16]
    6f58:	aa0203e0 	mov	x0, x2
    6f5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f60:	17fff4dd 	b	42d4 <fwp_rc_wide_dup>

0000000000006f64 <f37>:
    6f64:	d10243ff 	sub	sp, sp, #0x90
    6f68:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    6f6c:	f947f421 	ldr	x1, [x1, #4072]
    6f70:	a9037bfd 	stp	x29, x30, [sp, #48]
    6f74:	9100c3fd 	add	x29, sp, #0x30
    6f78:	a9055bf5 	stp	x21, x22, [sp, #80]
    6f7c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    6f80:	9114c2c3 	add	x3, x22, #0x530
    6f84:	a90453f3 	stp	x19, x20, [sp, #64]
    6f88:	aa0003f5 	mov	x21, x0
    6f8c:	a90663f7 	stp	x23, x24, [sp, #96]
    6f90:	a90873fb 	stp	x27, x28, [sp, #128]
    6f94:	f949ec62 	ldr	x2, [x3, #5080]
    6f98:	f9400024 	ldr	x4, [x1]
    6f9c:	f90017e4 	str	x4, [sp, #40]
    6fa0:	d2800004 	mov	x4, #0x0                   	// #0
    6fa4:	f949d861 	ldr	x1, [x3, #5040]
    6fa8:	d370bc42 	lsl	x2, x2, #16
    6fac:	b4001700 	cbz	x0, 728c <f37+0x328>
    6fb0:	f9400817 	ldr	x23, [x0, #16]
    6fb4:	cb0102e1 	sub	x1, x23, x1
    6fb8:	eb02003f 	cmp	x1, x2
    6fbc:	54000362 	b.cs	7028 <f37+0xc4>  // b.hs, b.nlast
    6fc0:	f949fc60 	ldr	x0, [x3, #5112]
    6fc4:	d350fc22 	lsr	x2, x1, #16
    6fc8:	8b020842 	add	x2, x2, x2, lsl #2
    6fcc:	8b020c02 	add	x2, x0, x2, lsl #3
    6fd0:	f9401040 	ldr	x0, [x2, #32]
    6fd4:	b40002a0 	cbz	x0, 7028 <f37+0xc4>
    6fd8:	39400043 	ldrb	w3, [x2]
    6fdc:	7100087f 	cmp	w3, #0x2
    6fe0:	54001440 	b.eq	7268 <f37+0x304>  // b.none
    6fe4:	7100047f 	cmp	w3, #0x1
    6fe8:	540001c1 	b.ne	7020 <f37+0xbc>  // b.any
    6fec:	29430843 	ldp	w3, w2, [x2, #24]
    6ff0:	92403c21 	and	x1, x1, #0xffff
    6ff4:	9b037c21 	mul	x1, x1, x3
    6ff8:	d360fc21 	lsr	x1, x1, #32
    6ffc:	eb02003f 	cmp	x1, x2
    7000:	54000102 	b.cs	7020 <f37+0xbc>  // b.hs, b.nlast
    7004:	8b010000 	add	x0, x0, x1
    7008:	39400001 	ldrb	w1, [x0]
    700c:	340000a1 	cbz	w1, 7020 <f37+0xbc>
    7010:	7103f43f 	cmp	w1, #0xfd
    7014:	54001708 	b.hi	72f4 <f37+0x390>  // b.pmore
    7018:	11000421 	add	w1, w1, #0x1
    701c:	39000001 	strb	w1, [x0]
    7020:	d2800002 	mov	x2, #0x0                   	// #0
    7024:	b40000d5 	cbz	x21, 703c <f37+0xd8>
    7028:	aa1503e1 	mov	x1, x21
    702c:	d2800002 	mov	x2, #0x0                   	// #0
    7030:	f9400821 	ldr	x1, [x1, #16]
    7034:	91000442 	add	x2, x2, #0x1
    7038:	b5ffffc1 	cbnz	x1, 7030 <f37+0xcc>
    703c:	b40012f7 	cbz	x23, 7298 <f37+0x334>
    7040:	aa1703e1 	mov	x1, x23
    7044:	d2800003 	mov	x3, #0x0                   	// #0
    7048:	f9400821 	ldr	x1, [x1, #16]
    704c:	91000463 	add	x3, x3, #0x1
    7050:	b5ffffc1 	cbnz	x1, 7048 <f37+0xe4>
    7054:	eb02007f 	cmp	x3, x2
    7058:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    705c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7060:	eb00027f 	cmp	x19, x0
    7064:	54000fa8 	b.hi	7258 <f37+0x2f4>  // b.pmore
    7068:	d37ffa74 	lsl	x20, x19, #1
    706c:	52800041 	mov	w1, #0x2                   	// #2
    7070:	91000680 	add	x0, x20, #0x1
    7074:	d37df000 	lsl	x0, x0, #3
    7078:	97fff6da 	bl	4be0 <fwp_heap_alloc>
    707c:	9114c2c1 	add	x1, x22, #0x530
    7080:	aa0003fb 	mov	x27, x0
    7084:	f9000014 	str	x20, [x0]
    7088:	aa0103e0 	mov	x0, x1
    708c:	f949d821 	ldr	x1, [x1, #5040]
    7090:	f949ec00 	ldr	x0, [x0, #5080]
    7094:	cb010361 	sub	x1, x27, x1
    7098:	eb00403f 	cmp	x1, x0, lsl #16
    709c:	54000342 	b.cs	7104 <f37+0x1a0>  // b.hs, b.nlast
    70a0:	9114c2c2 	add	x2, x22, #0x530
    70a4:	d350fc20 	lsr	x0, x1, #16
    70a8:	8b000800 	add	x0, x0, x0, lsl #2
    70ac:	f949fc43 	ldr	x3, [x2, #5112]
    70b0:	d37df002 	lsl	x2, x0, #3
    70b4:	8b020060 	add	x0, x3, x2
    70b8:	f9401014 	ldr	x20, [x0, #32]
    70bc:	b4000254 	cbz	x20, 7104 <f37+0x1a0>
    70c0:	38626862 	ldrb	w2, [x3, x2]
    70c4:	7100085f 	cmp	w2, #0x2
    70c8:	54000dc0 	b.eq	7280 <f37+0x31c>  // b.none
    70cc:	7100045f 	cmp	w2, #0x1
    70d0:	540001a1 	b.ne	7104 <f37+0x1a0>  // b.any
    70d4:	29430002 	ldp	w2, w0, [x0, #24]
    70d8:	92403c21 	and	x1, x1, #0xffff
    70dc:	9b027c21 	mul	x1, x1, x2
    70e0:	d360fc21 	lsr	x1, x1, #32
    70e4:	eb00003f 	cmp	x1, x0
    70e8:	540000e2 	b.cs	7104 <f37+0x1a0>  // b.hs, b.nlast
    70ec:	8b010294 	add	x20, x20, x1
    70f0:	39400280 	ldrb	w0, [x20]
    70f4:	7103fc1f 	cmp	w0, #0xff
    70f8:	54001020 	b.eq	72fc <f37+0x398>  // b.none
    70fc:	52800020 	mov	w0, #0x1                   	// #1
    7100:	39000280 	strb	w0, [x20]
    7104:	b4000333 	cbz	x19, 7168 <f37+0x204>
    7108:	8b131373 	add	x19, x27, x19, lsl #4
    710c:	aa1b03f4 	mov	x20, x27
    7110:	aa1703f8 	mov	x24, x23
    7114:	910023fc 	add	x28, sp, #0x8
    7118:	a9076bf9 	stp	x25, x26, [sp, #112]
    711c:	aa1503f9 	mov	x25, x21
    7120:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    7124:	d503201f 	nop
    7128:	f9400704 	ldr	x4, [x24, #8]
    712c:	aa1c03e2 	mov	x2, x28
    7130:	f9400723 	ldr	x3, [x25, #8]
    7134:	a900fffa 	stp	x26, xzr, [sp, #8]
    7138:	fd400481 	ldr	d1, [x4, #8]
    713c:	f9400881 	ldr	x1, [x4, #16]
    7140:	f9400860 	ldr	x0, [x3, #16]
    7144:	fd400460 	ldr	d0, [x3, #8]
    7148:	97fff806 	bl	5160 <w120>
    714c:	f9000680 	str	x0, [x20, #8]
    7150:	f8010e81 	str	x1, [x20, #16]!
    7154:	f9400b18 	ldr	x24, [x24, #16]
    7158:	f9400b39 	ldr	x25, [x25, #16]
    715c:	eb14027f 	cmp	x19, x20
    7160:	54fffe41 	b.ne	7128 <f37+0x1c4>  // b.any
    7164:	a9476bf9 	ldp	x25, x26, [sp, #112]
    7168:	aa1703e0 	mov	x0, x23
    716c:	97fffc96 	bl	63c4 <fwp_drop4>
    7170:	9114c2d6 	add	x22, x22, #0x530
    7174:	aa1503e0 	mov	x0, x21
    7178:	97fffc93 	bl	63c4 <fwp_drop4>
    717c:	aa1b03e0 	mov	x0, x27
    7180:	97fff948 	bl	56a0 <w176.constprop.0>
    7184:	aa0103f3 	mov	x19, x1
    7188:	aa0003f4 	mov	x20, x0
    718c:	aa1b03e0 	mov	x0, x27
    7190:	97fffe48 	bl	6ab0 <fwp_drop10>
    7194:	910063e1 	add	x1, sp, #0x18
    7198:	52800000 	mov	w0, #0x0                   	// #0
    719c:	a901cff4 	stp	x20, x19, [sp, #24]
    71a0:	97fff6d5 	bl	4cf4 <fwp_data.part.0.constprop.0>
    71a4:	aa0003f3 	mov	x19, x0
    71a8:	f949dac1 	ldr	x1, [x22, #5040]
    71ac:	f949eec0 	ldr	x0, [x22, #5080]
    71b0:	cb010261 	sub	x1, x19, x1
    71b4:	eb00403f 	cmp	x1, x0, lsl #16
    71b8:	54000322 	b.cs	721c <f37+0x2b8>  // b.hs, b.nlast
    71bc:	d350fc22 	lsr	x2, x1, #16
    71c0:	f949fec3 	ldr	x3, [x22, #5112]
    71c4:	8b020842 	add	x2, x2, x2, lsl #2
    71c8:	d37df042 	lsl	x2, x2, #3
    71cc:	8b020060 	add	x0, x3, x2
    71d0:	f9401014 	ldr	x20, [x0, #32]
    71d4:	b4000254 	cbz	x20, 721c <f37+0x2b8>
    71d8:	38626862 	ldrb	w2, [x3, x2]
    71dc:	7100085f 	cmp	w2, #0x2
    71e0:	540004a0 	b.eq	7274 <f37+0x310>  // b.none
    71e4:	7100045f 	cmp	w2, #0x1
    71e8:	540001a1 	b.ne	721c <f37+0x2b8>  // b.any
    71ec:	29430002 	ldp	w2, w0, [x0, #24]
    71f0:	92403c21 	and	x1, x1, #0xffff
    71f4:	9b027c21 	mul	x1, x1, x2
    71f8:	d360fc21 	lsr	x1, x1, #32
    71fc:	eb00003f 	cmp	x1, x0
    7200:	540000e2 	b.cs	721c <f37+0x2b8>  // b.hs, b.nlast
    7204:	8b010294 	add	x20, x20, x1
    7208:	39400280 	ldrb	w0, [x20]
    720c:	7103fc1f 	cmp	w0, #0xff
    7210:	540007c0 	b.eq	7308 <f37+0x3a4>  // b.none
    7214:	52800020 	mov	w0, #0x1                   	// #1
    7218:	39000280 	strb	w0, [x20]
    721c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7220:	f947f400 	ldr	x0, [x0, #4072]
    7224:	f94017e2 	ldr	x2, [sp, #40]
    7228:	f9400001 	ldr	x1, [x0]
    722c:	eb010042 	subs	x2, x2, x1
    7230:	d2800001 	mov	x1, #0x0                   	// #0
    7234:	54000701 	b.ne	7314 <f37+0x3b0>  // b.any
    7238:	a9437bfd 	ldp	x29, x30, [sp, #48]
    723c:	aa1303e0 	mov	x0, x19
    7240:	a94453f3 	ldp	x19, x20, [sp, #64]
    7244:	a9455bf5 	ldp	x21, x22, [sp, #80]
    7248:	a94663f7 	ldp	x23, x24, [sp, #96]
    724c:	a94873fb 	ldp	x27, x28, [sp, #128]
    7250:	910243ff 	add	sp, sp, #0x90
    7254:	d65f03c0 	ret
    7258:	d0000020 	adrp	x0, d000 <__modti3+0x2c0>
    725c:	91132000 	add	x0, x0, #0x4c8
    7260:	a9076bf9 	stp	x25, x26, [sp, #112]
    7264:	97fff2e7 	bl	3e00 <fwp_trap>
    7268:	72003c3f 	tst	w1, #0xffff
    726c:	54ffeda1 	b.ne	7020 <f37+0xbc>  // b.any
    7270:	17ffff66 	b	7008 <f37+0xa4>
    7274:	72003c3f 	tst	w1, #0xffff
    7278:	54fffd21 	b.ne	721c <f37+0x2b8>  // b.any
    727c:	17ffffe3 	b	7208 <f37+0x2a4>
    7280:	72003c3f 	tst	w1, #0xffff
    7284:	54fff401 	b.ne	7104 <f37+0x1a0>  // b.any
    7288:	17ffff9a 	b	70f0 <f37+0x18c>
    728c:	cb0103e1 	neg	x1, x1
    7290:	eb02003f 	cmp	x1, x2
    7294:	54000203 	b.cc	72d4 <f37+0x370>  // b.lo, b.ul, b.last
    7298:	52800041 	mov	w1, #0x2                   	// #2
    729c:	d2800100 	mov	x0, #0x8                   	// #8
    72a0:	97fff650 	bl	4be0 <fwp_heap_alloc>
    72a4:	aa0003e1 	mov	x1, x0
    72a8:	9114c2c0 	add	x0, x22, #0x530
    72ac:	aa0103fb 	mov	x27, x1
    72b0:	d2800017 	mov	x23, #0x0                   	// #0
    72b4:	f900003f 	str	xzr, [x1]
    72b8:	f949d801 	ldr	x1, [x0, #5040]
    72bc:	f949ec00 	ldr	x0, [x0, #5080]
    72c0:	cb010361 	sub	x1, x27, x1
    72c4:	eb00403f 	cmp	x1, x0, lsl #16
    72c8:	54fff502 	b.cs	7168 <f37+0x204>  // b.hs, b.nlast
    72cc:	d2800013 	mov	x19, #0x0                   	// #0
    72d0:	17ffff74 	b	70a0 <f37+0x13c>
    72d4:	f949fc62 	ldr	x2, [x3, #5112]
    72d8:	d350fc20 	lsr	x0, x1, #16
    72dc:	8b000800 	add	x0, x0, x0, lsl #2
    72e0:	8b000c42 	add	x2, x2, x0, lsl #3
    72e4:	f9401040 	ldr	x0, [x2, #32]
    72e8:	b4fffd80 	cbz	x0, 7298 <f37+0x334>
    72ec:	d2800017 	mov	x23, #0x0                   	// #0
    72f0:	17ffff3a 	b	6fd8 <f37+0x74>
    72f4:	97fff3f8 	bl	42d4 <fwp_rc_wide_dup>
    72f8:	17ffff4a 	b	7020 <f37+0xbc>
    72fc:	aa1403e0 	mov	x0, x20
    7300:	97fff2e0 	bl	3e80 <fwp_rc_forget_slot.part.0>
    7304:	17ffff7e 	b	70fc <f37+0x198>
    7308:	aa1403e0 	mov	x0, x20
    730c:	97fff2dd 	bl	3e80 <fwp_rc_forget_slot.part.0>
    7310:	17ffffc1 	b	7214 <f37+0x2b0>
    7314:	a9076bf9 	stp	x25, x26, [sp, #112]
    7318:	97ffed3a 	bl	2800 <__stack_chk_fail@plt>
    731c:	d503201f 	nop

0000000000007320 <fwp_owned_entry37>:
    7320:	f9400000 	ldr	x0, [x0]
    7324:	17ffff10 	b	6f64 <f37>
    7328:	d503201f 	nop
    732c:	d503201f 	nop

0000000000007330 <e37>:
    7330:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7334:	910003fd 	mov	x29, sp
    7338:	f9000bf3 	str	x19, [sp, #16]
    733c:	f9400013 	ldr	x19, [x0]
    7340:	aa1303e0 	mov	x0, x19
    7344:	97fff90b 	bl	5770 <fwp_rc_share>
    7348:	aa1303e0 	mov	x0, x19
    734c:	97ffff06 	bl	6f64 <f37>
    7350:	aa0003f3 	mov	x19, x0
    7354:	97fff907 	bl	5770 <fwp_rc_share>
    7358:	aa1303e0 	mov	x0, x19
    735c:	f9400bf3 	ldr	x19, [sp, #16]
    7360:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7364:	d65f03c0 	ret
    7368:	d503201f 	nop
    736c:	d503201f 	nop

0000000000007370 <fwp_write>:
    7370:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7374:	910003fd 	mov	x29, sp
    7378:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc88>
    737c:	f947f484 	ldr	x4, [x4, #4072]
    7380:	a90153f3 	stp	x19, x20, [sp, #16]
    7384:	d10943ff 	sub	sp, sp, #0x250
    7388:	b9400045 	ldr	w5, [x2]
    738c:	aa0003f4 	mov	x20, x0
    7390:	f9400080 	ldr	x0, [x4]
    7394:	f90127e0 	str	x0, [sp, #584]
    7398:	d2800000 	mov	x0, #0x0                   	// #0
    739c:	710064bf 	cmp	w5, #0x19
    73a0:	54000408 	b.hi	7420 <fwp_write+0xb0>  // b.pmore
    73a4:	d0000020 	adrp	x0, d000 <__modti3+0x2c0>
    73a8:	aa0103f3 	mov	x19, x1
    73ac:	9134c000 	add	x0, x0, #0xd30
    73b0:	f9013bf5 	str	x21, [sp, #624]
    73b4:	f9013ff6 	str	x22, [sp, #632]
    73b8:	f90153fb 	str	x27, [sp, #672]
    73bc:	f90157fc 	str	x28, [sp, #680]
    73c0:	aa0203fc 	mov	x28, x2
    73c4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    73c8:	10000061 	adr	x1, 73d4 <fwp_write+0x64>
    73cc:	8b20a820 	add	x0, x1, w0, sxth #2
    73d0:	d61f0000 	br	x0
    73d4:	910123e0 	add	x0, sp, #0x48
    73d8:	aa1303e5 	mov	x5, x19
    73dc:	d0000024 	adrp	x4, d000 <__modti3+0x2c0>
    73e0:	aa0003f3 	mov	x19, x0
    73e4:	91144084 	add	x4, x4, #0x510
    73e8:	d2804003 	mov	x3, #0x200                 	// #512
    73ec:	aa0303e1 	mov	x1, x3
    73f0:	52800042 	mov	w2, #0x2                   	// #2
    73f4:	97ffecdf 	bl	2770 <__snprintf_chk@plt>
    73f8:	aa1303e0 	mov	x0, x19
    73fc:	97ffeca5 	bl	2690 <strlen@plt>
    7400:	aa1303e1 	mov	x1, x19
    7404:	aa0003e2 	mov	x2, x0
    7408:	aa1403e0 	mov	x0, x20
    740c:	97ffefe1 	bl	3390 <buf_put>
    7410:	f9413bf5 	ldr	x21, [sp, #624]
    7414:	f9413ff6 	ldr	x22, [sp, #632]
    7418:	f94153fb 	ldr	x27, [sp, #672]
    741c:	f94157fc 	ldr	x28, [sp, #680]
    7420:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7424:	f947f400 	ldr	x0, [x0, #4072]
    7428:	f94127e2 	ldr	x2, [sp, #584]
    742c:	f9400001 	ldr	x1, [x0]
    7430:	eb010042 	subs	x2, x2, x1
    7434:	d2800001 	mov	x1, #0x0                   	// #0
    7438:	540077c1 	b.ne	8330 <fwp_write+0xfc0>  // b.any
    743c:	910943ff 	add	sp, sp, #0x250
    7440:	a94153f3 	ldp	x19, x20, [sp, #16]
    7444:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7448:	d65f03c0 	ret
    744c:	910123e0 	add	x0, sp, #0x48
    7450:	aa1303e5 	mov	x5, x19
    7454:	d0000024 	adrp	x4, d000 <__modti3+0x2c0>
    7458:	aa0003f3 	mov	x19, x0
    745c:	91142084 	add	x4, x4, #0x508
    7460:	d2804003 	mov	x3, #0x200                 	// #512
    7464:	17ffffe2 	b	73ec <fwp_write+0x7c>
    7468:	71004cbf 	cmp	w5, #0x13
    746c:	d0000020 	adrp	x0, d000 <__modti3+0x2c0>
    7470:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7474:	9113e000 	add	x0, x0, #0x4f8
    7478:	91140021 	add	x1, x1, #0x500
    747c:	d2800082 	mov	x2, #0x4                   	// #4
    7480:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7484:	aa1403e0 	mov	x0, x20
    7488:	f90143f7 	str	x23, [sp, #640]
    748c:	d2800016 	mov	x22, #0x0                   	// #0
    7490:	f90147f8 	str	x24, [sp, #648]
    7494:	97ffefbf 	bl	3390 <buf_put>
    7498:	f9400260 	ldr	x0, [x19]
    749c:	d0000037 	adrp	x23, d000 <__modti3+0x2c0>
    74a0:	d2800015 	mov	x21, #0x0                   	// #0
    74a4:	911602f7 	add	x23, x23, #0x580
    74a8:	b40047a0 	cbz	x0, 7d9c <fwp_write+0xa2c>
    74ac:	b9400380 	ldr	w0, [x28]
    74b0:	52800003 	mov	w3, #0x0                   	// #0
    74b4:	f9401f82 	ldr	x2, [x28, #56]
    74b8:	71004c1f 	cmp	w0, #0x13
    74bc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    74c0:	aa1403e0 	mov	x0, x20
    74c4:	8b010e61 	add	x1, x19, x1, lsl #3
    74c8:	f9400421 	ldr	x1, [x1, #8]
    74cc:	97ffffa9 	bl	7370 <fwp_write>
    74d0:	b9400380 	ldr	w0, [x28]
    74d4:	7100481f 	cmp	w0, #0x12
    74d8:	54004b40 	b.eq	7e40 <fwp_write+0xad0>  // b.none
    74dc:	f9400260 	ldr	x0, [x19]
    74e0:	910006b5 	add	x21, x21, #0x1
    74e4:	91000ad6 	add	x22, x22, #0x2
    74e8:	eb15001f 	cmp	x0, x21
    74ec:	54004589 	b.ls	7d9c <fwp_write+0xa2c>  // b.plast
    74f0:	aa1703e1 	mov	x1, x23
    74f4:	aa1403e0 	mov	x0, x20
    74f8:	d2800042 	mov	x2, #0x2                   	// #2
    74fc:	97ffefa5 	bl	3390 <buf_put>
    7500:	17ffffeb 	b	74ac <fwp_write+0x13c>
    7504:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7508:	9114e021 	add	x1, x1, #0x538
    750c:	d28000c2 	mov	x2, #0x6                   	// #6
    7510:	aa1403e0 	mov	x0, x20
    7514:	91004273 	add	x19, x19, #0x10
    7518:	97ffef9e 	bl	3390 <buf_put>
    751c:	aa1303e0 	mov	x0, x19
    7520:	97ffec5c 	bl	2690 <strlen@plt>
    7524:	aa1303e1 	mov	x1, x19
    7528:	aa0003e2 	mov	x2, x0
    752c:	aa1403e0 	mov	x0, x20
    7530:	97ffef98 	bl	3390 <buf_put>
    7534:	528007c3 	mov	w3, #0x3e                  	// #62
    7538:	aa1403e0 	mov	x0, x20
    753c:	91001fe1 	add	x1, sp, #0x7
    7540:	d2800022 	mov	x2, #0x1                   	// #1
    7544:	39001fe3 	strb	w3, [sp, #7]
    7548:	17ffffb1 	b	740c <fwp_write+0x9c>
    754c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7550:	f947f400 	ldr	x0, [x0, #4072]
    7554:	f94127e2 	ldr	x2, [sp, #584]
    7558:	f9400001 	ldr	x1, [x0]
    755c:	eb010042 	subs	x2, x2, x1
    7560:	d2800001 	mov	x1, #0x0                   	// #0
    7564:	540034e1 	b.ne	7c00 <fwp_write+0x890>  // b.any
    7568:	f9413bf5 	ldr	x21, [sp, #624]
    756c:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7570:	f9413ff6 	ldr	x22, [sp, #632]
    7574:	aa1403e0 	mov	x0, x20
    7578:	91146021 	add	x1, x1, #0x518
    757c:	d2800142 	mov	x2, #0xa                   	// #10
    7580:	f94153fb 	ldr	x27, [sp, #672]
    7584:	f94157fc 	ldr	x28, [sp, #680]
    7588:	910943ff 	add	sp, sp, #0x250
    758c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7590:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7594:	17ffef7f 	b	3390 <buf_put>
    7598:	f9400456 	ldr	x22, [x2, #8]
    759c:	f90143f7 	str	x23, [sp, #640]
    75a0:	f90147f8 	str	x24, [sp, #648]
    75a4:	b4005b16 	cbz	x22, 8104 <fwp_write+0xd94>
    75a8:	aa1603e0 	mov	x0, x22
    75ac:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    75b0:	91166021 	add	x1, x1, #0x598
    75b4:	97ffecb3 	bl	2880 <strcmp@plt>
    75b8:	2a0003f5 	mov	w21, w0
    75bc:	34005fe0 	cbz	w0, 81b8 <fwp_write+0xe48>
    75c0:	aa1603e0 	mov	x0, x22
    75c4:	97ffec33 	bl	2690 <strlen@plt>
    75c8:	aa1603e1 	mov	x1, x22
    75cc:	aa0003e2 	mov	x2, x0
    75d0:	aa1403e0 	mov	x0, x20
    75d4:	97ffef6f 	bl	3390 <buf_put>
    75d8:	52800403 	mov	w3, #0x20                  	// #32
    75dc:	91001ff5 	add	x21, sp, #0x7
    75e0:	aa1503e1 	mov	x1, x21
    75e4:	aa1403e0 	mov	x0, x20
    75e8:	d2800022 	mov	x2, #0x1                   	// #1
    75ec:	39001fe3 	strb	w3, [sp, #7]
    75f0:	97ffef68 	bl	3390 <buf_put>
    75f4:	52800f63 	mov	w3, #0x7b                  	// #123
    75f8:	aa1403e0 	mov	x0, x20
    75fc:	aa1503e1 	mov	x1, x21
    7600:	d2800022 	mov	x2, #0x1                   	// #1
    7604:	39001fe3 	strb	w3, [sp, #7]
    7608:	97ffef62 	bl	3390 <buf_put>
    760c:	b9401380 	ldr	w0, [x28, #16]
    7610:	52800018 	mov	w24, #0x0                   	// #0
    7614:	7100001f 	cmp	w0, #0x0
    7618:	54003aad 	b.le	7d6c <fwp_write+0x9fc>
    761c:	f9014bf9 	str	x25, [sp, #656]
    7620:	d0000039 	adrp	x25, d000 <__modti3+0x2c0>
    7624:	91170339 	add	x25, x25, #0x5c0
    7628:	f9014ffa 	str	x26, [sp, #664]
    762c:	d000003a 	adrp	x26, d000 <__modti3+0x2c0>
    7630:	9116035a 	add	x26, x26, #0x580
    7634:	91002276 	add	x22, x19, #0x8
    7638:	d2800013 	mov	x19, #0x0                   	// #0
    763c:	b5003e93 	cbnz	x19, 7e0c <fwp_write+0xa9c>
    7640:	d37df277 	lsl	x23, x19, #3
    7644:	34003cb8 	cbz	w24, 7dd8 <fwp_write+0xa68>
    7648:	f9401382 	ldr	x2, [x28, #32]
    764c:	aa1403e0 	mov	x0, x20
    7650:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7654:	52800003 	mov	w3, #0x0                   	// #0
    7658:	f8776842 	ldr	x2, [x2, x23]
    765c:	91000673 	add	x19, x19, #0x1
    7660:	97ffff44 	bl	7370 <fwp_write>
    7664:	b9401380 	ldr	w0, [x28, #16]
    7668:	6b13001f 	cmp	w0, w19
    766c:	54fffe8c 	b.gt	763c <fwp_write+0x2cc>
    7670:	f9414bf9 	ldr	x25, [sp, #656]
    7674:	f9414ffa 	ldr	x26, [sp, #664]
    7678:	340037b8 	cbz	w24, 7d6c <fwp_write+0x9fc>
    767c:	52800523 	mov	w3, #0x29                  	// #41
    7680:	aa1503e1 	mov	x1, x21
    7684:	aa1403e0 	mov	x0, x20
    7688:	d2800022 	mov	x2, #0x1                   	// #1
    768c:	39001fe3 	strb	w3, [sp, #7]
    7690:	97ffef40 	bl	3390 <buf_put>
    7694:	f9413bf5 	ldr	x21, [sp, #624]
    7698:	f9413ff6 	ldr	x22, [sp, #632]
    769c:	f94143f7 	ldr	x23, [sp, #640]
    76a0:	f94147f8 	ldr	x24, [sp, #648]
    76a4:	f94153fb 	ldr	x27, [sp, #672]
    76a8:	f94157fc 	ldr	x28, [sp, #680]
    76ac:	17ffff5d 	b	7420 <fwp_write+0xb0>
    76b0:	b9404855 	ldr	w21, [x2, #72]
    76b4:	aa1403e0 	mov	x0, x20
    76b8:	93407eb6 	sxtw	x22, w21
    76bc:	91000ac1 	add	x1, x22, #0x2
    76c0:	97ffef00 	bl	32c0 <buf_grow>
    76c4:	a9400281 	ldp	x1, x0, [x20]
    76c8:	528e8603 	mov	w3, #0x7430                	// #29744
    76cc:	78206823 	strh	w3, [x1, x0]
    76d0:	8b000022 	add	x2, x1, x0
    76d4:	710002bf 	cmp	w21, #0x0
    76d8:	540036cd 	b.le	7db0 <fwp_write+0xa40>
    76dc:	110006a3 	add	w3, w21, #0x1
    76e0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    76e4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    76e8:	91000449 	add	x9, x2, #0x1
    76ec:	8b23c043 	add	x3, x2, w3, sxtw
    76f0:	f28aaac6 	movk	x6, #0x5556
    76f4:	f2955568 	movk	x8, #0xaaab
    76f8:	1400000d 	b	772c <fwp_write+0x3bc>
    76fc:	d2800021 	mov	x1, #0x1                   	// #1
    7700:	528005a5 	mov	w5, #0x2d                  	// #45
    7704:	f100001f 	cmp	x0, #0x0
    7708:	9b467e60 	smulh	x0, x19, x6
    770c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7710:	381ff465 	strb	w5, [x3], #-1
    7714:	cb040000 	sub	x0, x0, x4
    7718:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    771c:	cb020000 	sub	x0, x0, x2
    7720:	8b010013 	add	x19, x0, x1
    7724:	eb03013f 	cmp	x9, x3
    7728:	54003440 	b.eq	7db0 <fwp_write+0xa40>  // b.none
    772c:	9b467e60 	smulh	x0, x19, x6
    7730:	937ffe64 	asr	x4, x19, #63
    7734:	52800605 	mov	w5, #0x30                  	// #48
    7738:	cb040000 	sub	x0, x0, x4
    773c:	8b000400 	add	x0, x0, x0, lsl #1
    7740:	cb000260 	sub	x0, x19, x0
    7744:	91000c01 	add	x1, x0, #0x3
    7748:	9bc87c22 	umulh	x2, x1, x8
    774c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7750:	8b4204e2 	add	x2, x7, x2, lsr #1
    7754:	eb020021 	subs	x1, x1, x2
    7758:	54fffd60 	b.eq	7704 <fwp_write+0x394>  // b.none
    775c:	f100043f 	cmp	x1, #0x1
    7760:	54fffce1 	b.ne	76fc <fwp_write+0x38c>  // b.any
    7764:	d2800001 	mov	x1, #0x0                   	// #0
    7768:	52800565 	mov	w5, #0x2b                  	// #43
    776c:	17ffffe6 	b	7704 <fwp_write+0x394>
    7770:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7774:	f947f400 	ldr	x0, [x0, #4072]
    7778:	f94127e2 	ldr	x2, [sp, #584]
    777c:	f9400001 	ldr	x1, [x0]
    7780:	eb010042 	subs	x2, x2, x1
    7784:	d2800001 	mov	x1, #0x0                   	// #0
    7788:	540023c1 	b.ne	7c00 <fwp_write+0x890>  // b.any
    778c:	f9413bf5 	ldr	x21, [sp, #624]
    7790:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7794:	f9413ff6 	ldr	x22, [sp, #632]
    7798:	aa1403e0 	mov	x0, x20
    779c:	9114a021 	add	x1, x1, #0x528
    77a0:	d2800102 	mov	x2, #0x8                   	// #8
    77a4:	17ffff77 	b	7580 <fwp_write+0x210>
    77a8:	aa1403e0 	mov	x0, x20
    77ac:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    77b0:	d28000c2 	mov	x2, #0x6                   	// #6
    77b4:	91162021 	add	x1, x1, #0x588
    77b8:	97ffeef6 	bl	3390 <buf_put>
    77bc:	d2800015 	mov	x21, #0x0                   	// #0
    77c0:	f9400263 	ldr	x3, [x19]
    77c4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    77c8:	54002c60 	b.eq	7d54 <fwp_write+0x9e4>  // b.none
    77cc:	f9401f82 	ldr	x2, [x28, #56]
    77d0:	f90143f7 	str	x23, [sp, #640]
    77d4:	f90147f8 	str	x24, [sp, #648]
    77d8:	d2800857 	mov	x23, #0x42                  	// #66
    77dc:	f9014bf9 	str	x25, [sp, #656]
    77e0:	d0000036 	adrp	x22, d000 <__modti3+0x2c0>
    77e4:	f9014ffa 	str	x26, [sp, #664]
    77e8:	911602d6 	add	x22, x22, #0x580
    77ec:	d2800038 	mov	x24, #0x1                   	// #1
    77f0:	f2a18017 	movk	x23, #0xc00, lsl #16
    77f4:	d2809099 	mov	x25, #0x484                 	// #1156
    77f8:	b40004a2 	cbz	x2, 788c <fwp_write+0x51c>
    77fc:	b9400040 	ldr	w0, [x2]
    7800:	7100701f 	cmp	w0, #0x1c
    7804:	540042c0 	b.eq	805c <fwp_write+0xcec>  // b.none
    7808:	71006c1f 	cmp	w0, #0x1b
    780c:	54000408 	b.hi	788c <fwp_write+0x51c>  // b.pmore
    7810:	9ac02301 	lsl	x1, x24, x0
    7814:	ea17003f 	tst	x1, x23
    7818:	540036a1 	b.ne	7eec <fwp_write+0xb7c>  // b.any
    781c:	ea19003f 	tst	x1, x25
    7820:	54003521 	b.ne	7ec4 <fwp_write+0xb54>  // b.any
    7824:	d2800424 	mov	x4, #0x21                  	// #33
    7828:	ea04003f 	tst	x1, x4
    782c:	54000300 	b.eq	788c <fwp_write+0x51c>  // b.none
    7830:	b7f849c3 	tbnz	x3, #63, 8168 <fwp_write+0xdf8>
    7834:	91002261 	add	x1, x19, #0x8
    7838:	8b150021 	add	x1, x1, x21
    783c:	39400021 	ldrb	w1, [x1]
    7840:	7100001f 	cmp	w0, #0x0
    7844:	93401c23 	sxtb	x3, w1
    7848:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    784c:	d503201f 	nop
    7850:	aa1403e0 	mov	x0, x20
    7854:	52800003 	mov	w3, #0x0                   	// #0
    7858:	97fffec6 	bl	7370 <fwp_write>
    785c:	910006b5 	add	x21, x21, #0x1
    7860:	f9400260 	ldr	x0, [x19]
    7864:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7868:	eb0002bf 	cmp	x21, x0
    786c:	540026c2 	b.cs	7d44 <fwp_write+0x9d4>  // b.hs, b.nlast
    7870:	d2800042 	mov	x2, #0x2                   	// #2
    7874:	aa1603e1 	mov	x1, x22
    7878:	aa1403e0 	mov	x0, x20
    787c:	97ffeec5 	bl	3390 <buf_put>
    7880:	f9401f82 	ldr	x2, [x28, #56]
    7884:	f9400263 	ldr	x3, [x19]
    7888:	b5fffba2 	cbnz	x2, 77fc <fwp_write+0x48c>
    788c:	d37df2a0 	lsl	x0, x21, #3
    7890:	b7f83f03 	tbnz	x3, #63, 8070 <fwp_write+0xd00>
    7894:	91002261 	add	x1, x19, #0x8
    7898:	8b000020 	add	x0, x1, x0
    789c:	f9400001 	ldr	x1, [x0]
    78a0:	17ffffec 	b	7850 <fwp_write+0x4e0>
    78a4:	a9400e62 	ldp	x2, x3, [x19]
    78a8:	b7f83ca3 	tbnz	x3, #63, 803c <fwp_write+0xccc>
    78ac:	910123f5 	add	x21, sp, #0x48
    78b0:	aa1503e0 	mov	x0, x21
    78b4:	97ffed3b 	bl	2da0 <fwp_fmt_u128>
    78b8:	aa1503e0 	mov	x0, x21
    78bc:	97ffeb75 	bl	2690 <strlen@plt>
    78c0:	aa1503e1 	mov	x1, x21
    78c4:	aa0003e2 	mov	x2, x0
    78c8:	17fffed0 	b	7408 <fwp_write+0x98>
    78cc:	fd015be8 	str	d8, [sp, #688]
    78d0:	1e270268 	fmov	s8, w19
    78d4:	fd015fe9 	str	d9, [sp, #696]
    78d8:	1e282100 	fcmp	s8, s8
    78dc:	54004d26 	b.vs	8280 <fwp_write+0xf10>
    78e0:	1e20c101 	fabs	s1, s8
    78e4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    78e8:	1e270000 	fmov	s0, w0
    78ec:	1e202020 	fcmp	s1, s0
    78f0:	54002c0d 	b.le	7e70 <fwp_write+0xb00>
    78f4:	1e202118 	fcmpe	s8, #0.0
    78f8:	d0000022 	adrp	x2, d000 <__modti3+0x2c0>
    78fc:	91040042 	add	x2, x2, #0x100
    7900:	910123f5 	add	x21, sp, #0x48
    7904:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7908:	91136021 	add	x1, x1, #0x4d8
    790c:	aa1503e0 	mov	x0, x21
    7910:	9a81c041 	csel	x1, x2, x1, gt
    7914:	97ffec0b 	bl	2940 <strcpy@plt>
    7918:	aa1503e0 	mov	x0, x21
    791c:	97ffeb5d 	bl	2690 <strlen@plt>
    7920:	aa1503e1 	mov	x1, x21
    7924:	aa0003e2 	mov	x2, x0
    7928:	aa1403e0 	mov	x0, x20
    792c:	97ffee99 	bl	3390 <buf_put>
    7930:	f9413bf5 	ldr	x21, [sp, #624]
    7934:	f9413ff6 	ldr	x22, [sp, #632]
    7938:	f94153fb 	ldr	x27, [sp, #672]
    793c:	f94157fc 	ldr	x28, [sp, #680]
    7940:	fd415be8 	ldr	d8, [sp, #688]
    7944:	fd415fe9 	ldr	d9, [sp, #696]
    7948:	17fffeb6 	b	7420 <fwp_write+0xb0>
    794c:	f9400276 	ldr	x22, [x19]
    7950:	34002e03 	cbz	w3, 7f10 <fwp_write+0xba0>
    7954:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7958:	f947f400 	ldr	x0, [x0, #4072]
    795c:	f94127e2 	ldr	x2, [sp, #584]
    7960:	f9400001 	ldr	x1, [x0]
    7964:	eb010042 	subs	x2, x2, x1
    7968:	d2800001 	mov	x1, #0x0                   	// #0
    796c:	540014a1 	b.ne	7c00 <fwp_write+0x890>  // b.any
    7970:	aa1603e2 	mov	x2, x22
    7974:	91002261 	add	x1, x19, #0x8
    7978:	f9413bf5 	ldr	x21, [sp, #624]
    797c:	aa1403e0 	mov	x0, x20
    7980:	f9413ff6 	ldr	x22, [sp, #632]
    7984:	17fffeff 	b	7580 <fwp_write+0x210>
    7988:	fd015be8 	str	d8, [sp, #688]
    798c:	9e670268 	fmov	d8, x19
    7990:	fd015fe9 	str	d9, [sp, #696]
    7994:	1e682100 	fcmp	d8, d8
    7998:	54004746 	b.vs	8280 <fwp_write+0xf10>
    799c:	1e60c101 	fabs	d1, d8
    79a0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    79a4:	9e670000 	fmov	d0, x0
    79a8:	910123f5 	add	x21, sp, #0x48
    79ac:	52800033 	mov	w19, #0x1                   	// #1
    79b0:	1e602020 	fcmp	d1, d0
    79b4:	540001ad 	b.le	79e8 <fwp_write+0x678>
    79b8:	1e602118 	fcmpe	d8, #0.0
    79bc:	d0000022 	adrp	x2, d000 <__modti3+0x2c0>
    79c0:	91040042 	add	x2, x2, #0x100
    79c4:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    79c8:	91136021 	add	x1, x1, #0x4d8
    79cc:	aa1503e0 	mov	x0, x21
    79d0:	9a81c041 	csel	x1, x2, x1, gt
    79d4:	97ffebdb 	bl	2940 <strcpy@plt>
    79d8:	17ffffd0 	b	7918 <fwp_write+0x5a8>
    79dc:	11000673 	add	w19, w19, #0x1
    79e0:	71004a7f 	cmp	w19, #0x12
    79e4:	54003860 	b.eq	80f0 <fwp_write+0xd80>  // b.none
    79e8:	1e604100 	fmov	d0, d8
    79ec:	2a1303e1 	mov	w1, w19
    79f0:	aa1503e0 	mov	x0, x21
    79f4:	97ffeec3 	bl	3500 <fwp_format_g.constprop.0>
    79f8:	aa1503e0 	mov	x0, x21
    79fc:	d2800001 	mov	x1, #0x0                   	// #0
    7a00:	97ffeb38 	bl	26e0 <strtod@plt>
    7a04:	1e602100 	fcmp	d8, d0
    7a08:	54fffea1 	b.ne	79dc <fwp_write+0x66c>  // b.any
    7a0c:	aa1503e0 	mov	x0, x21
    7a10:	97ffee99 	bl	3474 <fwp_finish_float>
    7a14:	17ffffc1 	b	7918 <fwp_write+0x5a8>
    7a18:	a9400e62 	ldp	x2, x3, [x19]
    7a1c:	910123f3 	add	x19, sp, #0x48
    7a20:	aa1303e0 	mov	x0, x19
    7a24:	97ffecdf 	bl	2da0 <fwp_fmt_u128>
    7a28:	17fffe74 	b	73f8 <fwp_write+0x88>
    7a2c:	f90143f7 	str	x23, [sp, #640]
    7a30:	f90147f8 	str	x24, [sp, #648]
    7a34:	2a1303f8 	mov	w24, w19
    7a38:	f9014bf9 	str	x25, [sp, #656]
    7a3c:	f9014ffa 	str	x26, [sp, #664]
    7a40:	f13ffe7f 	cmp	x19, #0xfff
    7a44:	54000049 	b.ls	7a4c <fwp_write+0x6dc>  // b.plast
    7a48:	b9400278 	ldr	w24, [x19]
    7a4c:	f9400f80 	ldr	x0, [x28, #24]
    7a50:	2a1803f5 	mov	w21, w24
    7a54:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7a58:	d37ef6b9 	lsl	x25, x21, #2
    7a5c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7a60:	aa1603e0 	mov	x0, x22
    7a64:	97ffeb0b 	bl	2690 <strlen@plt>
    7a68:	aa1603e1 	mov	x1, x22
    7a6c:	aa0003e2 	mov	x2, x0
    7a70:	aa1403e0 	mov	x0, x20
    7a74:	97ffee47 	bl	3390 <buf_put>
    7a78:	f9401780 	ldr	x0, [x28, #40]
    7a7c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7a80:	7100001f 	cmp	w0, #0x0
    7a84:	5400068d 	b.le	7b54 <fwp_write+0x7e4>
    7a88:	91002276 	add	x22, x19, #0x8
    7a8c:	91001ff5 	add	x21, sp, #0x7
    7a90:	d280001b 	mov	x27, #0x0                   	// #0
    7a94:	5280041a 	mov	w26, #0x20                  	// #32
    7a98:	f9401b80 	ldr	x0, [x28, #48]
    7a9c:	aa1503e1 	mov	x1, x21
    7aa0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7aa4:	d2800022 	mov	x2, #0x1                   	// #1
    7aa8:	f8786803 	ldr	x3, [x0, x24]
    7aac:	aa1403e0 	mov	x0, x20
    7ab0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7ab4:	39001ffa 	strb	w26, [sp, #7]
    7ab8:	97ffee36 	bl	3390 <buf_put>
    7abc:	f13ffeff 	cmp	x23, #0xfff
    7ac0:	b9400261 	ldr	w1, [x19]
    7ac4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7ac8:	7100383f 	cmp	w1, #0xe
    7acc:	54000160 	b.eq	7af8 <fwp_write+0x788>  // b.none
    7ad0:	7100403f 	cmp	w1, #0x10
    7ad4:	54001a60 	b.eq	7e20 <fwp_write+0xab0>  // b.none
    7ad8:	7100283f 	cmp	w1, #0xa
    7adc:	54002aa0 	b.eq	8030 <fwp_write+0xcc0>  // b.none
    7ae0:	540014ac 	b.gt	7d74 <fwp_write+0xa04>
    7ae4:	71000c3f 	cmp	w1, #0x3
    7ae8:	540029ac 	b.gt	801c <fwp_write+0xcac>
    7aec:	d37ffee0 	lsr	x0, x23, #63
    7af0:	37f814a1 	tbnz	w1, #31, 7d84 <fwp_write+0xa14>
    7af4:	d503201f 	nop
    7af8:	34001460 	cbz	w0, 7d84 <fwp_write+0xa14>
    7afc:	52800503 	mov	w3, #0x28                  	// #40
    7b00:	aa1503e1 	mov	x1, x21
    7b04:	aa1403e0 	mov	x0, x20
    7b08:	d2800022 	mov	x2, #0x1                   	// #1
    7b0c:	39001fe3 	strb	w3, [sp, #7]
    7b10:	97ffee20 	bl	3390 <buf_put>
    7b14:	aa1303e2 	mov	x2, x19
    7b18:	aa1703e1 	mov	x1, x23
    7b1c:	aa1403e0 	mov	x0, x20
    7b20:	52800003 	mov	w3, #0x0                   	// #0
    7b24:	97fffe13 	bl	7370 <fwp_write>
    7b28:	52800523 	mov	w3, #0x29                  	// #41
    7b2c:	aa1503e1 	mov	x1, x21
    7b30:	aa1403e0 	mov	x0, x20
    7b34:	d2800022 	mov	x2, #0x1                   	// #1
    7b38:	39001fe3 	strb	w3, [sp, #7]
    7b3c:	97ffee15 	bl	3390 <buf_put>
    7b40:	f9401780 	ldr	x0, [x28, #40]
    7b44:	9100077b 	add	x27, x27, #0x1
    7b48:	b8796800 	ldr	w0, [x0, x25]
    7b4c:	6b1b001f 	cmp	w0, w27
    7b50:	54fffa4c 	b.gt	7a98 <fwp_write+0x728>
    7b54:	f9413bf5 	ldr	x21, [sp, #624]
    7b58:	f9413ff6 	ldr	x22, [sp, #632]
    7b5c:	f94143f7 	ldr	x23, [sp, #640]
    7b60:	f94147f8 	ldr	x24, [sp, #648]
    7b64:	f9414bf9 	ldr	x25, [sp, #656]
    7b68:	f9414ffa 	ldr	x26, [sp, #664]
    7b6c:	f94153fb 	ldr	x27, [sp, #672]
    7b70:	f94157fc 	ldr	x28, [sp, #680]
    7b74:	17fffe2b 	b	7420 <fwp_write+0xb0>
    7b78:	52800783 	mov	w3, #0x3c                  	// #60
    7b7c:	91001ff3 	add	x19, sp, #0x7
    7b80:	aa1303e1 	mov	x1, x19
    7b84:	d2800022 	mov	x2, #0x1                   	// #1
    7b88:	aa1403e0 	mov	x0, x20
    7b8c:	39001fe3 	strb	w3, [sp, #7]
    7b90:	97ffee00 	bl	3390 <buf_put>
    7b94:	f9400795 	ldr	x21, [x28, #8]
    7b98:	aa1503e0 	mov	x0, x21
    7b9c:	97ffeabd 	bl	2690 <strlen@plt>
    7ba0:	aa1503e1 	mov	x1, x21
    7ba4:	aa0003e2 	mov	x2, x0
    7ba8:	aa1403e0 	mov	x0, x20
    7bac:	97ffedf9 	bl	3390 <buf_put>
    7bb0:	528007c3 	mov	w3, #0x3e                  	// #62
    7bb4:	aa1303e1 	mov	x1, x19
    7bb8:	aa1403e0 	mov	x0, x20
    7bbc:	d2800022 	mov	x2, #0x1                   	// #1
    7bc0:	39001fe3 	strb	w3, [sp, #7]
    7bc4:	17fffe12 	b	740c <fwp_write+0x9c>
    7bc8:	f100067f 	cmp	x19, #0x1
    7bcc:	540025a0 	b.eq	8080 <fwp_write+0xd10>  // b.none
    7bd0:	b100067f 	cmn	x19, #0x1
    7bd4:	54002bc0 	b.eq	814c <fwp_write+0xddc>  // b.none
    7bd8:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7bdc:	91138021 	add	x1, x1, #0x4e0
    7be0:	d2800022 	mov	x2, #0x1                   	// #1
    7be4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7be8:	f947f400 	ldr	x0, [x0, #4072]
    7bec:	f94127e4 	ldr	x4, [sp, #584]
    7bf0:	f9400003 	ldr	x3, [x0]
    7bf4:	eb030084 	subs	x4, x4, x3
    7bf8:	d2800003 	mov	x3, #0x0                   	// #0
    7bfc:	54ffebe0 	b.eq	7978 <fwp_write+0x608>  // b.none
    7c00:	f90143f7 	str	x23, [sp, #640]
    7c04:	f90147f8 	str	x24, [sp, #648]
    7c08:	f9014bf9 	str	x25, [sp, #656]
    7c0c:	f9014ffa 	str	x26, [sp, #664]
    7c10:	fd015be8 	str	d8, [sp, #688]
    7c14:	fd015fe9 	str	d9, [sp, #696]
    7c18:	97ffeafa 	bl	2800 <__stack_chk_fail@plt>
    7c1c:	52800b63 	mov	w3, #0x5b                  	// #91
    7c20:	91001ff5 	add	x21, sp, #0x7
    7c24:	aa1503e1 	mov	x1, x21
    7c28:	aa1403e0 	mov	x0, x20
    7c2c:	d2800022 	mov	x2, #0x1                   	// #1
    7c30:	d0000036 	adrp	x22, d000 <__modti3+0x2c0>
    7c34:	911602d6 	add	x22, x22, #0x580
    7c38:	39001fe3 	strb	w3, [sp, #7]
    7c3c:	97ffedd5 	bl	3390 <buf_put>
    7c40:	b4000273 	cbz	x19, 7c8c <fwp_write+0x91c>
    7c44:	f9400661 	ldr	x1, [x19, #8]
    7c48:	aa1403e0 	mov	x0, x20
    7c4c:	f9401f82 	ldr	x2, [x28, #56]
    7c50:	52800003 	mov	w3, #0x0                   	// #0
    7c54:	97fffdc7 	bl	7370 <fwp_write>
    7c58:	f9400a73 	ldr	x19, [x19, #16]
    7c5c:	b4000193 	cbz	x19, 7c8c <fwp_write+0x91c>
    7c60:	aa1603e1 	mov	x1, x22
    7c64:	aa1403e0 	mov	x0, x20
    7c68:	d2800042 	mov	x2, #0x2                   	// #2
    7c6c:	97ffedc9 	bl	3390 <buf_put>
    7c70:	f9400661 	ldr	x1, [x19, #8]
    7c74:	aa1403e0 	mov	x0, x20
    7c78:	f9401f82 	ldr	x2, [x28, #56]
    7c7c:	52800003 	mov	w3, #0x0                   	// #0
    7c80:	97fffdbc 	bl	7370 <fwp_write>
    7c84:	f9400a73 	ldr	x19, [x19, #16]
    7c88:	b5fffed3 	cbnz	x19, 7c60 <fwp_write+0x8f0>
    7c8c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7c90:	aa1503e1 	mov	x1, x21
    7c94:	aa1403e0 	mov	x0, x20
    7c98:	d2800022 	mov	x2, #0x1                   	// #1
    7c9c:	39001fe3 	strb	w3, [sp, #7]
    7ca0:	17fffddb 	b	740c <fwp_write+0x9c>
    7ca4:	aa1403e0 	mov	x0, x20
    7ca8:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7cac:	d28000c2 	mov	x2, #0x6                   	// #6
    7cb0:	9115c021 	add	x1, x1, #0x570
    7cb4:	97ffedb7 	bl	3390 <buf_put>
    7cb8:	f9400260 	ldr	x0, [x19]
    7cbc:	b40004c0 	cbz	x0, 7d54 <fwp_write+0x9e4>
    7cc0:	910123f5 	add	x21, sp, #0x48
    7cc4:	91002276 	add	x22, x19, #0x8
    7cc8:	f90143f7 	str	x23, [sp, #640]
    7ccc:	d2800017 	mov	x23, #0x0                   	// #0
    7cd0:	f90147f8 	str	x24, [sp, #648]
    7cd4:	d0000038 	adrp	x24, d000 <__modti3+0x2c0>
    7cd8:	9115e318 	add	x24, x24, #0x578
    7cdc:	f9014bf9 	str	x25, [sp, #656]
    7ce0:	d0000039 	adrp	x25, d000 <__modti3+0x2c0>
    7ce4:	91160339 	add	x25, x25, #0x580
    7ce8:	f9014ffa 	str	x26, [sp, #664]
    7cec:	14000005 	b	7d00 <fwp_write+0x990>
    7cf0:	aa1903e1 	mov	x1, x25
    7cf4:	aa1403e0 	mov	x0, x20
    7cf8:	d2800042 	mov	x2, #0x2                   	// #2
    7cfc:	97ffeda5 	bl	3390 <buf_put>
    7d00:	38776ac5 	ldrb	w5, [x22, x23]
    7d04:	d2804003 	mov	x3, #0x200                 	// #512
    7d08:	aa1803e4 	mov	x4, x24
    7d0c:	aa0303e1 	mov	x1, x3
    7d10:	52800042 	mov	w2, #0x2                   	// #2
    7d14:	aa1503e0 	mov	x0, x21
    7d18:	910006f7 	add	x23, x23, #0x1
    7d1c:	97ffea95 	bl	2770 <__snprintf_chk@plt>
    7d20:	aa1503e0 	mov	x0, x21
    7d24:	97ffea5b 	bl	2690 <strlen@plt>
    7d28:	aa1503e1 	mov	x1, x21
    7d2c:	aa0003e2 	mov	x2, x0
    7d30:	aa1403e0 	mov	x0, x20
    7d34:	97ffed97 	bl	3390 <buf_put>
    7d38:	f9400260 	ldr	x0, [x19]
    7d3c:	eb17001f 	cmp	x0, x23
    7d40:	54fffd88 	b.hi	7cf0 <fwp_write+0x980>  // b.pmore
    7d44:	f94143f7 	ldr	x23, [sp, #640]
    7d48:	f94147f8 	ldr	x24, [sp, #648]
    7d4c:	f9414bf9 	ldr	x25, [sp, #656]
    7d50:	f9414ffa 	ldr	x26, [sp, #664]
    7d54:	52800ba3 	mov	w3, #0x5d                  	// #93
    7d58:	aa1403e0 	mov	x0, x20
    7d5c:	91001fe1 	add	x1, sp, #0x7
    7d60:	d2800022 	mov	x2, #0x1                   	// #1
    7d64:	39001fe3 	strb	w3, [sp, #7]
    7d68:	17fffda9 	b	740c <fwp_write+0x9c>
    7d6c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7d70:	17fffe44 	b	7680 <fwp_write+0x310>
    7d74:	f10002ff 	cmp	x23, #0x0
    7d78:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7d7c:	71002c3f 	cmp	w1, #0xb
    7d80:	54ffebc0 	b.eq	7af8 <fwp_write+0x788>  // b.none
    7d84:	aa1303e2 	mov	x2, x19
    7d88:	aa1703e1 	mov	x1, x23
    7d8c:	aa1403e0 	mov	x0, x20
    7d90:	52800003 	mov	w3, #0x0                   	// #0
    7d94:	97fffd77 	bl	7370 <fwp_write>
    7d98:	17ffff6a 	b	7b40 <fwp_write+0x7d0>
    7d9c:	aa1403e0 	mov	x0, x20
    7da0:	91001fe1 	add	x1, sp, #0x7
    7da4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7da8:	d2800022 	mov	x2, #0x1                   	// #1
    7dac:	17fffe38 	b	768c <fwp_write+0x31c>
    7db0:	a9400281 	ldp	x1, x0, [x20]
    7db4:	91000800 	add	x0, x0, #0x2
    7db8:	8b160000 	add	x0, x0, x22
    7dbc:	f9000680 	str	x0, [x20, #8]
    7dc0:	3820683f 	strb	wzr, [x1, x0]
    7dc4:	f9413bf5 	ldr	x21, [sp, #624]
    7dc8:	f9413ff6 	ldr	x22, [sp, #632]
    7dcc:	f94153fb 	ldr	x27, [sp, #672]
    7dd0:	f94157fc 	ldr	x28, [sp, #680]
    7dd4:	17fffd93 	b	7420 <fwp_write+0xb0>
    7dd8:	f9400f80 	ldr	x0, [x28, #24]
    7ddc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7de0:	aa1b03e0 	mov	x0, x27
    7de4:	97ffea2b 	bl	2690 <strlen@plt>
    7de8:	aa1b03e1 	mov	x1, x27
    7dec:	aa0003e2 	mov	x2, x0
    7df0:	aa1403e0 	mov	x0, x20
    7df4:	97ffed67 	bl	3390 <buf_put>
    7df8:	aa1903e1 	mov	x1, x25
    7dfc:	aa1403e0 	mov	x0, x20
    7e00:	d2800062 	mov	x2, #0x3                   	// #3
    7e04:	97ffed63 	bl	3390 <buf_put>
    7e08:	17fffe10 	b	7648 <fwp_write+0x2d8>
    7e0c:	aa1a03e1 	mov	x1, x26
    7e10:	aa1403e0 	mov	x0, x20
    7e14:	d2800042 	mov	x2, #0x2                   	// #2
    7e18:	97ffed5e 	bl	3390 <buf_put>
    7e1c:	17fffe09 	b	7640 <fwp_write+0x2d0>
    7e20:	f9400660 	ldr	x0, [x19, #8]
    7e24:	b4fffb00 	cbz	x0, 7d84 <fwp_write+0xa14>
    7e28:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7e2c:	91166021 	add	x1, x1, #0x598
    7e30:	97ffea94 	bl	2880 <strcmp@plt>
    7e34:	7100001f 	cmp	w0, #0x0
    7e38:	1a9f07e0 	cset	w0, ne	// ne = any
    7e3c:	17ffff2f 	b	7af8 <fwp_write+0x788>
    7e40:	aa1403e0 	mov	x0, x20
    7e44:	d2800042 	mov	x2, #0x2                   	// #2
    7e48:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7e4c:	91164021 	add	x1, x1, #0x590
    7e50:	97ffed50 	bl	3390 <buf_put>
    7e54:	91004261 	add	x1, x19, #0x10
    7e58:	aa1403e0 	mov	x0, x20
    7e5c:	f9402382 	ldr	x2, [x28, #64]
    7e60:	52800003 	mov	w3, #0x0                   	// #0
    7e64:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7e68:	97fffd42 	bl	7370 <fwp_write>
    7e6c:	17fffd9c 	b	74dc <fwp_write+0x16c>
    7e70:	1e22c109 	fcvt	d9, s8
    7e74:	910123f5 	add	x21, sp, #0x48
    7e78:	52800033 	mov	w19, #0x1                   	// #1
    7e7c:	d503201f 	nop
    7e80:	1e604120 	fmov	d0, d9
    7e84:	2a1303e1 	mov	w1, w19
    7e88:	aa1503e0 	mov	x0, x21
    7e8c:	97ffed9d 	bl	3500 <fwp_format_g.constprop.0>
    7e90:	aa1503e0 	mov	x0, x21
    7e94:	d2800001 	mov	x1, #0x0                   	// #0
    7e98:	97ffea86 	bl	28b0 <strtof@plt>
    7e9c:	1e202100 	fcmp	s8, s0
    7ea0:	54ffdb60 	b.eq	7a0c <fwp_write+0x69c>  // b.none
    7ea4:	11000673 	add	w19, w19, #0x1
    7ea8:	71002a7f 	cmp	w19, #0xa
    7eac:	54fffea1 	b.ne	7e80 <fwp_write+0xb10>  // b.any
    7eb0:	1e604120 	fmov	d0, d9
    7eb4:	aa1503e0 	mov	x0, x21
    7eb8:	52800121 	mov	w1, #0x9                   	// #9
    7ebc:	97ffed91 	bl	3500 <fwp_format_g.constprop.0>
    7ec0:	17fffed3 	b	7a0c <fwp_write+0x69c>
    7ec4:	d37ef6a1 	lsl	x1, x21, #2
    7ec8:	b7f81563 	tbnz	x3, #63, 8174 <fwp_write+0xe04>
    7ecc:	91002263 	add	x3, x19, #0x8
    7ed0:	8b010061 	add	x1, x3, x1
    7ed4:	b9400023 	ldr	w3, [x1]
    7ed8:	7100081f 	cmp	w0, #0x2
    7edc:	2a0303e1 	mov	w1, w3
    7ee0:	93407c63 	sxtw	x3, w3
    7ee4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7ee8:	17fffe5a 	b	7850 <fwp_write+0x4e0>
    7eec:	d37ffaa1 	lsl	x1, x21, #1
    7ef0:	b7f81363 	tbnz	x3, #63, 815c <fwp_write+0xdec>
    7ef4:	91002263 	add	x3, x19, #0x8
    7ef8:	8b010061 	add	x1, x3, x1
    7efc:	79400021 	ldrh	w1, [x1]
    7f00:	7100041f 	cmp	w0, #0x1
    7f04:	93403c23 	sxth	x3, w1
    7f08:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7f0c:	17fffe51 	b	7850 <fwp_write+0x4e0>
    7f10:	52800443 	mov	w3, #0x22                  	// #34
    7f14:	91001ff5 	add	x21, sp, #0x7
    7f18:	91002273 	add	x19, x19, #0x8
    7f1c:	aa1503e1 	mov	x1, x21
    7f20:	aa1403e0 	mov	x0, x20
    7f24:	d2800022 	mov	x2, #0x1                   	// #1
    7f28:	39001fe3 	strb	w3, [sp, #7]
    7f2c:	f90143f7 	str	x23, [sp, #640]
    7f30:	8b160277 	add	x23, x19, x22
    7f34:	f90147f8 	str	x24, [sp, #648]
    7f38:	97ffed16 	bl	3390 <buf_put>
    7f3c:	b4000696 	cbz	x22, 800c <fwp_write+0xc9c>
    7f40:	d0000038 	adrp	x24, d000 <__modti3+0x2c0>
    7f44:	91150318 	add	x24, x24, #0x540
    7f48:	f9014bf9 	str	x25, [sp, #656]
    7f4c:	d0000039 	adrp	x25, d000 <__modti3+0x2c0>
    7f50:	91158339 	add	x25, x25, #0x560
    7f54:	f9014ffa 	str	x26, [sp, #664]
    7f58:	1400000d 	b	7f8c <fwp_write+0xc1c>
    7f5c:	710024bf 	cmp	w5, #0x9
    7f60:	54000460 	b.eq	7fec <fwp_write+0xc7c>  // b.none
    7f64:	710028bf 	cmp	w5, #0xa
    7f68:	54000a61 	b.ne	80b4 <fwp_write+0xd44>  // b.any
    7f6c:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7f70:	aa1403e0 	mov	x0, x20
    7f74:	91154021 	add	x1, x1, #0x550
    7f78:	d2800042 	mov	x2, #0x2                   	// #2
    7f7c:	97ffed05 	bl	3390 <buf_put>
    7f80:	91000673 	add	x19, x19, #0x1
    7f84:	eb17027f 	cmp	x19, x23
    7f88:	540003e0 	b.eq	8004 <fwp_write+0xc94>  // b.none
    7f8c:	39400265 	ldrb	w5, [x19]
    7f90:	710034bf 	cmp	w5, #0xd
    7f94:	54000180 	b.eq	7fc4 <fwp_write+0xc54>  // b.none
    7f98:	54fffe29 	b.ls	7f5c <fwp_write+0xbec>  // b.plast
    7f9c:	710088bf 	cmp	w5, #0x22
    7fa0:	540001c0 	b.eq	7fd8 <fwp_write+0xc68>  // b.none
    7fa4:	710170bf 	cmp	w5, #0x5c
    7fa8:	54000741 	b.ne	8090 <fwp_write+0xd20>  // b.any
    7fac:	aa1403e0 	mov	x0, x20
    7fb0:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7fb4:	d2800042 	mov	x2, #0x2                   	// #2
    7fb8:	91152021 	add	x1, x1, #0x548
    7fbc:	97ffecf5 	bl	3390 <buf_put>
    7fc0:	17fffff0 	b	7f80 <fwp_write+0xc10>
    7fc4:	aa1903e1 	mov	x1, x25
    7fc8:	aa1403e0 	mov	x0, x20
    7fcc:	d2800042 	mov	x2, #0x2                   	// #2
    7fd0:	97ffecf0 	bl	3390 <buf_put>
    7fd4:	17ffffeb 	b	7f80 <fwp_write+0xc10>
    7fd8:	aa1803e1 	mov	x1, x24
    7fdc:	aa1403e0 	mov	x0, x20
    7fe0:	d2800042 	mov	x2, #0x2                   	// #2
    7fe4:	97ffeceb 	bl	3390 <buf_put>
    7fe8:	17ffffe6 	b	7f80 <fwp_write+0xc10>
    7fec:	aa1403e0 	mov	x0, x20
    7ff0:	d0000021 	adrp	x1, d000 <__modti3+0x2c0>
    7ff4:	d2800042 	mov	x2, #0x2                   	// #2
    7ff8:	91156021 	add	x1, x1, #0x558
    7ffc:	97ffece5 	bl	3390 <buf_put>
    8000:	17ffffe0 	b	7f80 <fwp_write+0xc10>
    8004:	f9414bf9 	ldr	x25, [sp, #656]
    8008:	f9414ffa 	ldr	x26, [sp, #664]
    800c:	aa1503e1 	mov	x1, x21
    8010:	aa1403e0 	mov	x0, x20
    8014:	52800443 	mov	w3, #0x22                  	// #34
    8018:	17fffd9c 	b	7688 <fwp_write+0x318>
    801c:	7100103f 	cmp	w1, #0x4
    8020:	54ffeb21 	b.ne	7d84 <fwp_write+0xa14>  // b.any
    8024:	f94006e0 	ldr	x0, [x23, #8]
    8028:	d37ffc00 	lsr	x0, x0, #63
    802c:	17fffeb3 	b	7af8 <fwp_write+0x788>
    8030:	710002ff 	cmp	w23, #0x0
    8034:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8038:	17fffeb0 	b	7af8 <fwp_write+0x788>
    803c:	528005a1 	mov	w1, #0x2d                  	// #45
    8040:	eb0203e2 	negs	x2, x2
    8044:	da0303e3 	ngc	x3, x3
    8048:	910127e0 	add	x0, sp, #0x49
    804c:	910123f5 	add	x21, sp, #0x48
    8050:	390123e1 	strb	w1, [sp, #72]
    8054:	97ffeb53 	bl	2da0 <fwp_fmt_u128>
    8058:	17fffe18 	b	78b8 <fwp_write+0x548>
    805c:	d37ceea1 	lsl	x1, x21, #4
    8060:	b7f810a3 	tbnz	x3, #63, 8274 <fwp_write+0xf04>
    8064:	91002260 	add	x0, x19, #0x8
    8068:	8b010001 	add	x1, x0, x1
    806c:	17fffdf9 	b	7850 <fwp_write+0x4e0>
    8070:	f9400a61 	ldr	x1, [x19, #16]
    8074:	8b010000 	add	x0, x0, x1
    8078:	f9400001 	ldr	x1, [x0]
    807c:	17fffdf5 	b	7850 <fwp_write+0x4e0>
    8080:	b0000021 	adrp	x1, d000 <__modti3+0x2c0>
    8084:	d2800042 	mov	x2, #0x2                   	// #2
    8088:	9113a021 	add	x1, x1, #0x4e8
    808c:	17fffed6 	b	7be4 <fwp_write+0x874>
    8090:	7101fcbf 	cmp	w5, #0x7f
    8094:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8098:	540000e9 	b.ls	80b4 <fwp_write+0xd44>  // b.plast
    809c:	aa1503e1 	mov	x1, x21
    80a0:	aa1403e0 	mov	x0, x20
    80a4:	d2800022 	mov	x2, #0x1                   	// #1
    80a8:	39001fe5 	strb	w5, [sp, #7]
    80ac:	97ffecb9 	bl	3390 <buf_put>
    80b0:	17ffffb4 	b	7f80 <fwp_write+0xc10>
    80b4:	d2800203 	mov	x3, #0x10                  	// #16
    80b8:	b0000024 	adrp	x4, d000 <__modti3+0x2c0>
    80bc:	aa0303e1 	mov	x1, x3
    80c0:	9115a084 	add	x4, x4, #0x568
    80c4:	910123f6 	add	x22, sp, #0x48
    80c8:	52800042 	mov	w2, #0x2                   	// #2
    80cc:	aa1603e0 	mov	x0, x22
    80d0:	97ffe9a8 	bl	2770 <__snprintf_chk@plt>
    80d4:	aa1603e0 	mov	x0, x22
    80d8:	97ffe96e 	bl	2690 <strlen@plt>
    80dc:	aa1603e1 	mov	x1, x22
    80e0:	aa0003e2 	mov	x2, x0
    80e4:	aa1403e0 	mov	x0, x20
    80e8:	97ffecaa 	bl	3390 <buf_put>
    80ec:	17ffffa5 	b	7f80 <fwp_write+0xc10>
    80f0:	1e604100 	fmov	d0, d8
    80f4:	aa1503e0 	mov	x0, x21
    80f8:	52800221 	mov	w1, #0x11                  	// #17
    80fc:	97ffed01 	bl	3500 <fwp_format_g.constprop.0>
    8100:	17fffe43 	b	7a0c <fwp_write+0x69c>
    8104:	b9401040 	ldr	w0, [x2, #16]
    8108:	350003c0 	cbnz	w0, 8180 <fwp_write+0xe10>
    810c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8110:	f947f400 	ldr	x0, [x0, #4072]
    8114:	f94127e2 	ldr	x2, [sp, #584]
    8118:	f9400001 	ldr	x1, [x0]
    811c:	eb010042 	subs	x2, x2, x1
    8120:	d2800001 	mov	x1, #0x0                   	// #0
    8124:	54ffd721 	b.ne	7c08 <fwp_write+0x898>  // b.any
    8128:	f9413bf5 	ldr	x21, [sp, #624]
    812c:	b0000021 	adrp	x1, d000 <__modti3+0x2c0>
    8130:	f9413ff6 	ldr	x22, [sp, #632]
    8134:	aa1403e0 	mov	x0, x20
    8138:	f94143f7 	ldr	x23, [sp, #640]
    813c:	9116e021 	add	x1, x1, #0x5b8
    8140:	f94147f8 	ldr	x24, [sp, #648]
    8144:	d2800042 	mov	x2, #0x2                   	// #2
    8148:	17fffd0e 	b	7580 <fwp_write+0x210>
    814c:	b0000021 	adrp	x1, d000 <__modti3+0x2c0>
    8150:	d2800042 	mov	x2, #0x2                   	// #2
    8154:	9113c021 	add	x1, x1, #0x4f0
    8158:	17fffea3 	b	7be4 <fwp_write+0x874>
    815c:	f9400a63 	ldr	x3, [x19, #16]
    8160:	8b030021 	add	x1, x1, x3
    8164:	17ffff66 	b	7efc <fwp_write+0xb8c>
    8168:	f9400a61 	ldr	x1, [x19, #16]
    816c:	8b0102a1 	add	x1, x21, x1
    8170:	17fffdb3 	b	783c <fwp_write+0x4cc>
    8174:	f9400a63 	ldr	x3, [x19, #16]
    8178:	8b030021 	add	x1, x1, x3
    817c:	17ffff56 	b	7ed4 <fwp_write+0xb64>
    8180:	b9404840 	ldr	w0, [x2, #72]
    8184:	91001ff5 	add	x21, sp, #0x7
    8188:	34ffa360 	cbz	w0, 75f4 <fwp_write+0x284>
    818c:	52800503 	mov	w3, #0x28                  	// #40
    8190:	aa1403e0 	mov	x0, x20
    8194:	aa1503e1 	mov	x1, x21
    8198:	d2800022 	mov	x2, #0x1                   	// #1
    819c:	39001fe3 	strb	w3, [sp, #7]
    81a0:	97ffec7c 	bl	3390 <buf_put>
    81a4:	b9401380 	ldr	w0, [x28, #16]
    81a8:	52800038 	mov	w24, #0x1                   	// #1
    81ac:	7100001f 	cmp	w0, #0x0
    81b0:	54ffa36c 	b.gt	761c <fwp_write+0x2ac>
    81b4:	17fffd32 	b	767c <fwp_write+0x30c>
    81b8:	f9014bf9 	str	x25, [sp, #656]
    81bc:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xee98>
    81c0:	f9014ffa 	str	x26, [sp, #664]
    81c4:	f9400676 	ldr	x22, [x19, #8]
    81c8:	910ae333 	add	x19, x25, #0x2b8
    81cc:	91002273 	add	x19, x19, #0x8
    81d0:	937ffed8 	asr	x24, x22, #63
    81d4:	aa1802c0 	orr	x0, x22, x24
    81d8:	b5000320 	cbnz	x0, 823c <fwp_write+0xecc>
    81dc:	110006b5 	add	w21, w21, #0x1
    81e0:	710016bf 	cmp	w21, #0x5
    81e4:	54ffffc1 	b.ne	81dc <fwp_write+0xe6c>  // b.any
    81e8:	b7f80578 	tbnz	x24, #63, 8294 <fwp_write+0xf24>
    81ec:	910023f3 	add	x19, sp, #0x8
    81f0:	aa1603e2 	mov	x2, x22
    81f4:	aa1303e0 	mov	x0, x19
    81f8:	d2800003 	mov	x3, #0x0                   	// #0
    81fc:	97ffeae9 	bl	2da0 <fwp_fmt_u128>
    8200:	910123f5 	add	x21, sp, #0x48
    8204:	b0000023 	adrp	x3, d000 <__modti3+0x2c0>
    8208:	aa1303e4 	mov	x4, x19
    820c:	aa1503e0 	mov	x0, x21
    8210:	9116c063 	add	x3, x3, #0x5b0
    8214:	d2804002 	mov	x2, #0x200                 	// #512
    8218:	52800041 	mov	w1, #0x2                   	// #2
    821c:	97ffe921 	bl	26a0 <__sprintf_chk@plt>
    8220:	aa1503e0 	mov	x0, x21
    8224:	97ffe91b 	bl	2690 <strlen@plt>
    8228:	aa1503e1 	mov	x1, x21
    822c:	aa0003e2 	mov	x2, x0
    8230:	aa1403e0 	mov	x0, x20
    8234:	97ffec57 	bl	3390 <buf_put>
    8238:	17fffe47 	b	7b54 <fwp_write+0x7e4>
    823c:	f9400277 	ldr	x23, [x19]
    8240:	aa1603e0 	mov	x0, x22
    8244:	aa1803e1 	mov	x1, x24
    8248:	aa1703e2 	mov	x2, x23
    824c:	937ffefa 	asr	x26, x23, #63
    8250:	aa1a03e3 	mov	x3, x26
    8254:	940012bb 	bl	cd40 <__modti3>
    8258:	aa010000 	orr	x0, x0, x1
    825c:	b40002c0 	cbz	x0, 82b4 <fwp_write+0xf44>
    8260:	110006b5 	add	w21, w21, #0x1
    8264:	91004273 	add	x19, x19, #0x10
    8268:	710016bf 	cmp	w21, #0x5
    826c:	54fffe81 	b.ne	823c <fwp_write+0xecc>  // b.any
    8270:	17ffffde 	b	81e8 <fwp_write+0xe78>
    8274:	f9400a60 	ldr	x0, [x19, #16]
    8278:	8b000021 	add	x1, x1, x0
    827c:	17fffd75 	b	7850 <fwp_write+0x4e0>
    8280:	528c29c0 	mov	w0, #0x614e                	// #24910
    8284:	910123f5 	add	x21, sp, #0x48
    8288:	72a009c0 	movk	w0, #0x4e, lsl #16
    828c:	b9004be0 	str	w0, [sp, #72]
    8290:	17fffda2 	b	7918 <fwp_write+0x5a8>
    8294:	528005a1 	mov	w1, #0x2d                  	// #45
    8298:	eb1603e2 	negs	x2, x22
    829c:	da1803e3 	ngc	x3, x24
    82a0:	910027e0 	add	x0, sp, #0x9
    82a4:	910023f3 	add	x19, sp, #0x8
    82a8:	390023e1 	strb	w1, [sp, #8]
    82ac:	97ffeabd 	bl	2da0 <fwp_fmt_u128>
    82b0:	17ffffd4 	b	8200 <fwp_write+0xe90>
    82b4:	aa1703e2 	mov	x2, x23
    82b8:	aa1a03e3 	mov	x3, x26
    82bc:	aa1603e0 	mov	x0, x22
    82c0:	aa1803e1 	mov	x1, x24
    82c4:	940011bf 	bl	c9c0 <__divti3>
    82c8:	aa0003e2 	mov	x2, x0
    82cc:	aa0103e3 	mov	x3, x1
    82d0:	b7f80201 	tbnz	x1, #63, 8310 <fwp_write+0xfa0>
    82d4:	910023f3 	add	x19, sp, #0x8
    82d8:	aa1303e0 	mov	x0, x19
    82dc:	97ffeab1 	bl	2da0 <fwp_fmt_u128>
    82e0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    82e4:	910ae339 	add	x25, x25, #0x2b8
    82e8:	910123f5 	add	x21, sp, #0x48
    82ec:	aa1303e4 	mov	x4, x19
    82f0:	aa1503e0 	mov	x0, x21
    82f4:	b0000023 	adrp	x3, d000 <__modti3+0x2c0>
    82f8:	f8616b25 	ldr	x5, [x25, x1]
    82fc:	9116a063 	add	x3, x3, #0x5a8
    8300:	d2804002 	mov	x2, #0x200                 	// #512
    8304:	52800041 	mov	w1, #0x2                   	// #2
    8308:	97ffe8e6 	bl	26a0 <__sprintf_chk@plt>
    830c:	17ffffc5 	b	8220 <fwp_write+0xeb0>
    8310:	528005a4 	mov	w4, #0x2d                  	// #45
    8314:	eb0003e2 	negs	x2, x0
    8318:	da0103e3 	ngc	x3, x1
    831c:	910027e0 	add	x0, sp, #0x9
    8320:	910023f3 	add	x19, sp, #0x8
    8324:	390023e4 	strb	w4, [sp, #8]
    8328:	97ffea9e 	bl	2da0 <fwp_fmt_u128>
    832c:	17ffffed 	b	82e0 <fwp_write+0xf70>
    8330:	f9013bf5 	str	x21, [sp, #624]
    8334:	f9013ff6 	str	x22, [sp, #632]
    8338:	f90143f7 	str	x23, [sp, #640]
    833c:	f90147f8 	str	x24, [sp, #648]
    8340:	f9014bf9 	str	x25, [sp, #656]
    8344:	f9014ffa 	str	x26, [sp, #664]
    8348:	f90153fb 	str	x27, [sp, #672]
    834c:	f90157fc 	str	x28, [sp, #680]
    8350:	fd015be8 	str	d8, [sp, #688]
    8354:	fd015fe9 	str	d9, [sp, #696]
    8358:	97ffe92a 	bl	2800 <__stack_chk_fail@plt>
    835c:	d503201f 	nop

0000000000008360 <fwp_hof0.constprop.0>:
    8360:	d105c3ff 	sub	sp, sp, #0x170
    8364:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    8368:	f947f442 	ldr	x2, [x2, #4072]
    836c:	a9117bfd 	stp	x29, x30, [sp, #272]
    8370:	910443fd 	add	x29, sp, #0x110
    8374:	a91673fb 	stp	x27, x28, [sp, #352]
    8378:	aa0003fc 	mov	x28, x0
    837c:	f9400040 	ldr	x0, [x2]
    8380:	f90087e0 	str	x0, [sp, #264]
    8384:	d2800000 	mov	x0, #0x0                   	// #0
    8388:	b4003641 	cbz	x1, 8a50 <fwp_hof0.constprop.0+0x6f0>
    838c:	910263e0 	add	x0, sp, #0x98
    8390:	aa1c03fb 	mov	x27, x28
    8394:	a91253f3 	stp	x19, x20, [sp, #288]
    8398:	900000d3 	adrp	x19, 20000 <__data_start>
    839c:	91004273 	add	x19, x19, #0x10
    83a0:	a9135bf5 	stp	x21, x22, [sp, #304]
    83a4:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    83a8:	900000d5 	adrp	x21, 20000 <__data_start>
    83ac:	a91463f7 	stp	x23, x24, [sp, #320]
    83b0:	9100c2b7 	add	x23, x21, #0x30
    83b4:	d0fffff8 	adrp	x24, 6000 <fwp_closure_drop+0x110>
    83b8:	a9156bf9 	stp	x25, x26, [sp, #336]
    83bc:	9114c2d9 	add	x25, x22, #0x530
    83c0:	f90007e0 	str	x0, [sp, #8]
    83c4:	910283e0 	add	x0, sp, #0xa0
    83c8:	f9000be0 	str	x0, [sp, #16]
    83cc:	f90013e1 	str	x1, [sp, #32]
    83d0:	f949ef24 	ldr	x4, [x25, #5080]
    83d4:	f949db21 	ldr	x1, [x25, #5040]
    83d8:	d370bc84 	lsl	x4, x4, #16
    83dc:	cb010363 	sub	x3, x27, x1
    83e0:	eb04007f 	cmp	x3, x4
    83e4:	540003e2 	b.cs	8460 <fwp_hof0.constprop.0+0x100>  // b.hs, b.nlast
    83e8:	d350fc60 	lsr	x0, x3, #16
    83ec:	f949ff26 	ldr	x6, [x25, #5112]
    83f0:	8b000800 	add	x0, x0, x0, lsl #2
    83f4:	d37df002 	lsl	x2, x0, #3
    83f8:	8b0200c5 	add	x5, x6, x2
    83fc:	f94010a0 	ldr	x0, [x5, #32]
    8400:	b4000300 	cbz	x0, 8460 <fwp_hof0.constprop.0+0x100>
    8404:	386268c2 	ldrb	w2, [x6, x2]
    8408:	7100085f 	cmp	w2, #0x2
    840c:	54000de0 	b.eq	85c8 <fwp_hof0.constprop.0+0x268>  // b.none
    8410:	7100045f 	cmp	w2, #0x1
    8414:	54000261 	b.ne	8460 <fwp_hof0.constprop.0+0x100>  // b.any
    8418:	92403c62 	and	x2, x3, #0xffff
    841c:	29430ca6 	ldp	w6, w3, [x5, #24]
    8420:	9b067c42 	mul	x2, x2, x6
    8424:	d360fc42 	lsr	x2, x2, #32
    8428:	eb03005f 	cmp	x2, x3
    842c:	540001a2 	b.cs	8460 <fwp_hof0.constprop.0+0x100>  // b.hs, b.nlast
    8430:	8b020000 	add	x0, x0, x2
    8434:	39400002 	ldrb	w2, [x0]
    8438:	34000142 	cbz	w2, 8460 <fwp_hof0.constprop.0+0x100>
    843c:	7103f45f 	cmp	w2, #0xfd
    8440:	54004f28 	b.hi	8e24 <fwp_hof0.constprop.0+0xac4>  // b.pmore
    8444:	9114c2c1 	add	x1, x22, #0x530
    8448:	11000442 	add	w2, w2, #0x1
    844c:	39000002 	strb	w2, [x0]
    8450:	aa0103e0 	mov	x0, x1
    8454:	f949d821 	ldr	x1, [x1, #5040]
    8458:	f949ec04 	ldr	x4, [x0, #5080]
    845c:	d370bc84 	lsl	x4, x4, #16
    8460:	910a031a 	add	x26, x24, #0x280
    8464:	a902e7fb 	stp	x27, x25, [sp, #40]
    8468:	aa1a03f4 	mov	x20, x26
    846c:	aa1b03f9 	mov	x25, x27
    8470:	aa1703fb 	mov	x27, x23
    8474:	d28018c0 	mov	x0, #0xc6                  	// #198
    8478:	b2407bfc 	mov	x28, #0x7fffffff            	// #2147483647
    847c:	f9000fe0 	str	x0, [sp, #24]
    8480:	f9415b60 	ldr	x0, [x27, #688]
    8484:	a90a53e0 	stp	x0, x20, [sp, #160]
    8488:	12800002 	mov	w2, #0xffffffff            	// #-1
    848c:	f94007e0 	ldr	x0, [sp, #8]
    8490:	f9005be0 	str	x0, [sp, #176]
    8494:	f9400be0 	ldr	x0, [sp, #16]
    8498:	cb010261 	sub	x1, x19, x1
    849c:	b9009be2 	str	w2, [sp, #152]
    84a0:	f9015b60 	str	x0, [x27, #688]
    84a4:	eb04003f 	cmp	x1, x4
    84a8:	54000782 	b.cs	8598 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    84ac:	9114c2c2 	add	x2, x22, #0x530
    84b0:	d350fc20 	lsr	x0, x1, #16
    84b4:	8b000800 	add	x0, x0, x0, lsl #2
    84b8:	f949fc44 	ldr	x4, [x2, #5112]
    84bc:	d37df000 	lsl	x0, x0, #3
    84c0:	8b000082 	add	x2, x4, x0
    84c4:	f9401057 	ldr	x23, [x2, #32]
    84c8:	b4000697 	cbz	x23, 8598 <fwp_hof0.constprop.0+0x238>
    84cc:	38606880 	ldrb	w0, [x4, x0]
    84d0:	7100081f 	cmp	w0, #0x2
    84d4:	54000800 	b.eq	85d4 <fwp_hof0.constprop.0+0x274>  // b.none
    84d8:	7100041f 	cmp	w0, #0x1
    84dc:	540005e1 	b.ne	8598 <fwp_hof0.constprop.0+0x238>  // b.any
    84e0:	29431046 	ldp	w6, w4, [x2, #24]
    84e4:	92403c20 	and	x0, x1, #0xffff
    84e8:	9b067c00 	mul	x0, x0, x6
    84ec:	d360fc00 	lsr	x0, x0, #32
    84f0:	eb04001f 	cmp	x0, x4
    84f4:	54000282 	b.cs	8544 <fwp_hof0.constprop.0+0x1e4>  // b.hs, b.nlast
    84f8:	8b0002e0 	add	x0, x23, x0
    84fc:	39400004 	ldrb	w4, [x0]
    8500:	34000224 	cbz	w4, 8544 <fwp_hof0.constprop.0+0x1e4>
    8504:	7103f49f 	cmp	w4, #0xfd
    8508:	540049a8 	b.hi	8e3c <fwp_hof0.constprop.0+0xadc>  // b.pmore
    850c:	11000484 	add	w4, w4, #0x1
    8510:	39000004 	strb	w4, [x0]
    8514:	9114c2c0 	add	x0, x22, #0x530
    8518:	f949d801 	ldr	x1, [x0, #5040]
    851c:	f949ec02 	ldr	x2, [x0, #5080]
    8520:	cb010261 	sub	x1, x19, x1
    8524:	eb02403f 	cmp	x1, x2, lsl #16
    8528:	54000382 	b.cs	8598 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    852c:	f949fc00 	ldr	x0, [x0, #5112]
    8530:	d350fc22 	lsr	x2, x1, #16
    8534:	8b020842 	add	x2, x2, x2, lsl #2
    8538:	8b020c02 	add	x2, x0, x2, lsl #3
    853c:	f9401057 	ldr	x23, [x2, #32]
    8540:	b40002d7 	cbz	x23, 8598 <fwp_hof0.constprop.0+0x238>
    8544:	39400040 	ldrb	w0, [x2]
    8548:	7100081f 	cmp	w0, #0x2
    854c:	54000620 	b.eq	8610 <fwp_hof0.constprop.0+0x2b0>  // b.none
    8550:	7100041f 	cmp	w0, #0x1
    8554:	54000221 	b.ne	8598 <fwp_hof0.constprop.0+0x238>  // b.any
    8558:	29430044 	ldp	w4, w0, [x2, #24]
    855c:	92403c21 	and	x1, x1, #0xffff
    8560:	9b047c21 	mul	x1, x1, x4
    8564:	d360fc21 	lsr	x1, x1, #32
    8568:	eb00003f 	cmp	x1, x0
    856c:	54000162 	b.cs	8598 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    8570:	8b0102f7 	add	x23, x23, x1
    8574:	394002e1 	ldrb	w1, [x23]
    8578:	34000101 	cbz	w1, 8598 <fwp_hof0.constprop.0+0x238>
    857c:	7100043f 	cmp	w1, #0x1
    8580:	54000320 	b.eq	85e4 <fwp_hof0.constprop.0+0x284>  // b.none
    8584:	7103fc3f 	cmp	w1, #0xff
    8588:	540045e0 	b.eq	8e44 <fwp_hof0.constprop.0+0xae4>  // b.none
    858c:	51000421 	sub	w1, w1, #0x1
    8590:	390002e1 	strb	w1, [x23]
    8594:	d503201f 	nop
    8598:	b4003a79 	cbz	x25, 8ce4 <fwp_hof0.constprop.0+0x984>
    859c:	aa1903e0 	mov	x0, x25
    85a0:	d2800001 	mov	x1, #0x0                   	// #0
    85a4:	d503201f 	nop
    85a8:	f9400800 	ldr	x0, [x0, #16]
    85ac:	91000421 	add	x1, x1, #0x1
    85b0:	b5ffffc0 	cbnz	x0, 85a8 <fwp_hof0.constprop.0+0x248>
    85b4:	eb1c003f 	cmp	x1, x28
    85b8:	54000329 	b.ls	861c <fwp_hof0.constprop.0+0x2bc>  // b.plast
    85bc:	b0000020 	adrp	x0, d000 <__modti3+0x2c0>
    85c0:	91172000 	add	x0, x0, #0x5c8
    85c4:	97ffee0f 	bl	3e00 <fwp_trap>
    85c8:	72003c7f 	tst	w3, #0xffff
    85cc:	54fff4a1 	b.ne	8460 <fwp_hof0.constprop.0+0x100>  // b.any
    85d0:	17ffff99 	b	8434 <fwp_hof0.constprop.0+0xd4>
    85d4:	72003c3f 	tst	w1, #0xffff
    85d8:	54fffb61 	b.ne	8544 <fwp_hof0.constprop.0+0x1e4>  // b.any
    85dc:	aa1703e0 	mov	x0, x23
    85e0:	17ffffc7 	b	84fc <fwp_hof0.constprop.0+0x19c>
    85e4:	d53bd040 	mrs	x0, tpidr_el0
    85e8:	91400000 	add	x0, x0, #0x0, lsl #12
    85ec:	91004000 	add	x0, x0, #0x10
    85f0:	f9400000 	ldr	x0, [x0]
    85f4:	b4000080 	cbz	x0, 8604 <fwp_hof0.constprop.0+0x2a4>
    85f8:	aa1303e1 	mov	x1, x19
    85fc:	97ffef7d 	bl	43f0 <fwp_closure_drop_push>
    8600:	17ffffe6 	b	8598 <fwp_hof0.constprop.0+0x238>
    8604:	aa1303e0 	mov	x0, x19
    8608:	97ffefbf 	bl	4504 <fwp_closure_drop.part.0>
    860c:	17ffffe3 	b	8598 <fwp_hof0.constprop.0+0x238>
    8610:	72003c3f 	tst	w1, #0xffff
    8614:	54fffc21 	b.ne	8598 <fwp_hof0.constprop.0+0x238>  // b.any
    8618:	17ffffd7 	b	8574 <fwp_hof0.constprop.0+0x214>
    861c:	aa0103fa 	mov	x26, x1
    8620:	9100c2b7 	add	x23, x21, #0x30
    8624:	b942e6e0 	ldr	w0, [x23, #740]
    8628:	340022c0 	cbz	w0, 8a80 <fwp_hof0.constprop.0+0x720>
    862c:	9100c2a0 	add	x0, x21, #0x30
    8630:	f9403802 	ldr	x2, [x0, #112]
    8634:	f9404417 	ldr	x23, [x0, #136]
    8638:	eb0202ff 	cmp	x23, x2
    863c:	5400072a 	b.ge	8720 <fwp_hof0.constprop.0+0x3c0>  // b.tcont
    8640:	8b1706e0 	add	x0, x23, x23, lsl #1
    8644:	528fffc4 	mov	w4, #0x7ffe                	// #32766
    8648:	f9401aa1 	ldr	x1, [x21, #48]
    864c:	d37ef400 	lsl	x0, x0, #2
    8650:	cb170000 	sub	x0, x0, x23
    8654:	8b000c20 	add	x0, x1, x0, lsl #3
    8658:	b9400401 	ldr	w1, [x0, #4]
    865c:	35000081 	cbnz	w1, 866c <fwp_hof0.constprop.0+0x30c>
    8660:	b9400001 	ldr	w1, [x0]
    8664:	6b04003f 	cmp	w1, w4
    8668:	540005c9 	b.ls	8720 <fwp_hof0.constprop.0+0x3c0>  // b.plast
    866c:	910006f7 	add	x23, x23, #0x1
    8670:	91016000 	add	x0, x0, #0x58
    8674:	eb0202ff 	cmp	x23, x2
    8678:	54ffff01 	b.ne	8658 <fwp_hof0.constprop.0+0x2f8>  // b.any
    867c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8680:	eb00005f 	cmp	x2, x0
    8684:	54003cac 	b.gt	8e18 <fwp_hof0.constprop.0+0xab8>
    8688:	9100c2a0 	add	x0, x21, #0x30
    868c:	f9401aa8 	ldr	x8, [x21, #48]
    8690:	f9404000 	ldr	x0, [x0, #128]
    8694:	eb02001f 	cmp	x0, x2
    8698:	540002a1 	b.ne	86ec <fwp_hof0.constprop.0+0x38c>  // b.any
    869c:	b4004682 	cbz	x2, 8f6c <fwp_hof0.constprop.0+0xc0c>
    86a0:	d37ff844 	lsl	x4, x2, #1
    86a4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    86a8:	eb00009f 	cmp	x4, x0
    86ac:	9a80d084 	csel	x4, x4, x0, le
    86b0:	8b040481 	add	x1, x4, x4, lsl #1
    86b4:	d37ef421 	lsl	x1, x1, #2
    86b8:	cb040021 	sub	x1, x1, x4
    86bc:	d37df021 	lsl	x1, x1, #3
    86c0:	aa0803e0 	mov	x0, x8
    86c4:	f9001fe4 	str	x4, [sp, #56]
    86c8:	f9002be2 	str	x2, [sp, #80]
    86cc:	97ffe849 	bl	27f0 <realloc@plt>
    86d0:	f9401fe4 	ldr	x4, [sp, #56]
    86d4:	aa0003e8 	mov	x8, x0
    86d8:	f9402be2 	ldr	x2, [sp, #80]
    86dc:	b4006fe0 	cbz	x0, 94d8 <fwp_hof0.constprop.0+0x1178>
    86e0:	9100c2a0 	add	x0, x21, #0x30
    86e4:	f9001aa8 	str	x8, [x21, #48]
    86e8:	f9004004 	str	x4, [x0, #128]
    86ec:	8b020440 	add	x0, x2, x2, lsl #1
    86f0:	9100c2a1 	add	x1, x21, #0x30
    86f4:	4f000400 	movi	v0.4s, #0x0
    86f8:	91000444 	add	x4, x2, #0x1
    86fc:	d37ef400 	lsl	x0, x0, #2
    8700:	cb020000 	sub	x0, x0, x2
    8704:	f9003824 	str	x4, [x1, #112]
    8708:	8b000d00 	add	x0, x8, x0, lsl #3
    870c:	ad000000 	stp	q0, q0, [x0]
    8710:	ad010000 	stp	q0, q0, [x0, #32]
    8714:	3d801000 	str	q0, [x0, #64]
    8718:	f900281f 	str	xzr, [x0, #80]
    871c:	14000004 	b	872c <fwp_hof0.constprop.0+0x3cc>
    8720:	eb0202ff 	cmp	x23, x2
    8724:	54fffac0 	b.eq	867c <fwp_hof0.constprop.0+0x31c>  // b.none
    8728:	f9401aa8 	ldr	x8, [x21, #48]
    872c:	8b1706e1 	add	x1, x23, x23, lsl #1
    8730:	b0000020 	adrp	x0, d000 <__modti3+0x2c0>
    8734:	9107e000 	add	x0, x0, #0x1f8
    8738:	d37ef422 	lsl	x2, x1, #2
    873c:	f9002be8 	str	x8, [sp, #80]
    8740:	cb170042 	sub	x2, x2, x23
    8744:	8b020d02 	add	x2, x8, x2, lsl #3
    8748:	f9001fe2 	str	x2, [sp, #56]
    874c:	f900285f 	str	xzr, [x2, #80]
    8750:	97ffe890 	bl	2990 <getenv@plt>
    8754:	f9401fe2 	ldr	x2, [sp, #56]
    8758:	f9402be8 	ldr	x8, [sp, #80]
    875c:	b4000080 	cbz	x0, 876c <fwp_hof0.constprop.0+0x40c>
    8760:	39400001 	ldrb	w1, [x0]
    8764:	7100c03f 	cmp	w1, #0x30
    8768:	54000740 	b.eq	8850 <fwp_hof0.constprop.0+0x4f0>  // b.none
    876c:	9100c2a0 	add	x0, x21, #0x30
    8770:	f9403001 	ldr	x1, [x0, #96]
    8774:	b5003381 	cbnz	x1, 8de4 <fwp_hof0.constprop.0+0xa84>
    8778:	9100c2a0 	add	x0, x21, #0x30
    877c:	2f000400 	mvni	v0.2s, #0x0
    8780:	b9400047 	ldr	w7, [x2]
    8784:	910006e9 	add	x9, x23, #0x1
    8788:	52800024 	mov	w4, #0x1                   	// #1
    878c:	a900e85a 	stp	x26, x26, [x2, #8]
    8790:	110004e7 	add	w7, w7, #0x1
    8794:	f9415801 	ldr	x1, [x0, #688]
    8798:	29001047 	stp	w7, w4, [x2]
    879c:	f900205f 	str	xzr, [x2, #64]
    87a0:	f9004409 	str	x9, [x0, #136]
    87a4:	fd002440 	str	d0, [x2, #72]
    87a8:	b4003181 	cbz	x1, 8dd8 <fwp_hof0.constprop.0+0xa78>
    87ac:	910a0306 	add	x6, x24, #0x280
    87b0:	14000003 	b	87bc <fwp_hof0.constprop.0+0x45c>
    87b4:	f9400021 	ldr	x1, [x1]
    87b8:	b4003101 	cbz	x1, 8dd8 <fwp_hof0.constprop.0+0xa78>
    87bc:	f9400420 	ldr	x0, [x1, #8]
    87c0:	eb06001f 	cmp	x0, x6
    87c4:	54ffff81 	b.ne	87b4 <fwp_hof0.constprop.0+0x454>  // b.any
    87c8:	f9400820 	ldr	x0, [x1, #16]
    87cc:	2a1703e4 	mov	w4, w23
    87d0:	b9400001 	ldr	w1, [x0]
    87d4:	f9002040 	str	x0, [x2, #64]
    87d8:	b9004c41 	str	w1, [x2, #76]
    87dc:	37f80081 	tbnz	w1, #31, 87ec <fwp_hof0.constprop.0+0x48c>
    87e0:	52800b02 	mov	w2, #0x58                  	// #88
    87e4:	9b222021 	smaddl	x1, w1, w2, x8
    87e8:	b9004837 	str	w23, [x1, #72]
    87ec:	b9000004 	str	w4, [x0]
    87f0:	d2800002 	mov	x2, #0x0                   	// #0
    87f4:	aa1903e0 	mov	x0, x25
    87f8:	b4001539 	cbz	x25, 8a9c <fwp_hof0.constprop.0+0x73c>
    87fc:	d503201f 	nop
    8800:	f9400800 	ldr	x0, [x0, #16]
    8804:	91000442 	add	x2, x2, #0x1
    8808:	b5ffffc0 	cbnz	x0, 8800 <fwp_hof0.constprop.0+0x4a0>
    880c:	aa1903e1 	mov	x1, x25
    8810:	f9400821 	ldr	x1, [x1, #16]
    8814:	91000400 	add	x0, x0, #0x1
    8818:	b5ffffc1 	cbnz	x1, 8810 <fwp_hof0.constprop.0+0x4b0>
    881c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8820:	eb01001f 	cmp	x0, x1
    8824:	54000108 	b.hi	8844 <fwp_hof0.constprop.0+0x4e4>  // b.pmore
    8828:	f100005f 	cmp	x2, #0x0
    882c:	5400138d 	b.le	8a9c <fwp_hof0.constprop.0+0x73c>
    8830:	eb00005f 	cmp	x2, x0
    8834:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8838:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    883c:	eb0102ff 	cmp	x23, x1
    8840:	54002569 	b.ls	8cec <fwp_hof0.constprop.0+0x98c>  // b.plast
    8844:	b0000020 	adrp	x0, d000 <__modti3+0x2c0>
    8848:	91132000 	add	x0, x0, #0x4c8
    884c:	97ffed6d 	bl	3e00 <fwp_trap>
    8850:	39400400 	ldrb	w0, [x0, #1]
    8854:	34fff920 	cbz	w0, 8778 <fwp_hof0.constprop.0+0x418>
    8858:	17ffffc5 	b	876c <fwp_hof0.constprop.0+0x40c>
    885c:	f9401fe6 	ldr	x6, [sp, #56]
    8860:	d00000a1 	adrp	x1, 1e000 <__FRAME_END__+0xee98>
    8864:	910ae021 	add	x1, x1, #0x2b8
    8868:	52800023 	mov	w3, #0x1                   	// #1
    886c:	91014022 	add	x2, x1, #0x50
    8870:	aa0603e0 	mov	x0, x6
    8874:	aa1903e1 	mov	x1, x25
    8878:	aa1903f4 	mov	x20, x25
    887c:	aa1b03f7 	mov	x23, x27
    8880:	a90d7fff 	stp	xzr, xzr, [sp, #208]
    8884:	a942e7fb 	ldp	x27, x25, [sp, #40]
    8888:	f90073ff 	str	xzr, [sp, #224]
    888c:	97fffab9 	bl	7370 <fwp_write>
    8890:	a94d0be3 	ldp	x3, x2, [sp, #208]
    8894:	b0000020 	adrp	x0, d000 <__modti3+0x2c0>
    8898:	912c4000 	add	x0, x0, #0xb10
    889c:	f100007f 	cmp	x3, #0x0
    88a0:	9a830003 	csel	x3, x0, x3, eq	// eq = none
    88a4:	b100285f 	cmn	x2, #0xa
    88a8:	54008dc8 	b.hi	9a60 <fwp_hof0.constprop.0+0x1700>  // b.pmore
    88ac:	91002440 	add	x0, x2, #0x9
    88b0:	52800021 	mov	w1, #0x1                   	// #1
    88b4:	f9000fe2 	str	x2, [sp, #24]
    88b8:	f90017e3 	str	x3, [sp, #40]
    88bc:	97fff0c9 	bl	4be0 <fwp_heap_alloc>
    88c0:	f94017e3 	ldr	x3, [sp, #40]
    88c4:	aa0003fa 	mov	x26, x0
    88c8:	f9400fe2 	ldr	x2, [sp, #24]
    88cc:	aa0303e1 	mov	x1, x3
    88d0:	aa0003e3 	mov	x3, x0
    88d4:	f90017e2 	str	x2, [sp, #40]
    88d8:	f8008462 	str	x2, [x3], #8
    88dc:	aa0303e0 	mov	x0, x3
    88e0:	f9000fe3 	str	x3, [sp, #24]
    88e4:	97ffe75f 	bl	2660 <memcpy@plt>
    88e8:	f94017e2 	ldr	x2, [sp, #40]
    88ec:	8b020342 	add	x2, x26, x2
    88f0:	3900205f 	strb	wzr, [x2, #8]
    88f4:	f9406be0 	ldr	x0, [sp, #208]
    88f8:	97ffe7f2 	bl	28c0 <free@plt>
    88fc:	9114c2c2 	add	x2, x22, #0x530
    8900:	f9400fe3 	ldr	x3, [sp, #24]
    8904:	f949d841 	ldr	x1, [x2, #5040]
    8908:	f949ec40 	ldr	x0, [x2, #5080]
    890c:	cb010341 	sub	x1, x26, x1
    8910:	eb00403f 	cmp	x1, x0, lsl #16
    8914:	54000322 	b.cs	8978 <fwp_hof0.constprop.0+0x618>  // b.hs, b.nlast
    8918:	d350fc20 	lsr	x0, x1, #16
    891c:	f949fc45 	ldr	x5, [x2, #5112]
    8920:	8b000800 	add	x0, x0, x0, lsl #2
    8924:	d37df002 	lsl	x2, x0, #3
    8928:	8b0200a4 	add	x4, x5, x2
    892c:	f9401080 	ldr	x0, [x4, #32]
    8930:	b4000240 	cbz	x0, 8978 <fwp_hof0.constprop.0+0x618>
    8934:	386268a2 	ldrb	w2, [x5, x2]
    8938:	7100085f 	cmp	w2, #0x2
    893c:	54008a40 	b.eq	9a84 <fwp_hof0.constprop.0+0x1724>  // b.none
    8940:	7100045f 	cmp	w2, #0x1
    8944:	540001a1 	b.ne	8978 <fwp_hof0.constprop.0+0x618>  // b.any
    8948:	29430885 	ldp	w5, w2, [x4, #24]
    894c:	92403c21 	and	x1, x1, #0xffff
    8950:	9b057c21 	mul	x1, x1, x5
    8954:	d360fc21 	lsr	x1, x1, #32
    8958:	eb02003f 	cmp	x1, x2
    895c:	540000e2 	b.cs	8978 <fwp_hof0.constprop.0+0x618>  // b.hs, b.nlast
    8960:	8b010000 	add	x0, x0, x1
    8964:	39400001 	ldrb	w1, [x0]
    8968:	7103fc3f 	cmp	w1, #0xff
    896c:	54008920 	b.eq	9a90 <fwp_hof0.constprop.0+0x1730>  // b.none
    8970:	52800021 	mov	w1, #0x1                   	// #1
    8974:	39000001 	strb	w1, [x0]
    8978:	aa1403e0 	mov	x0, x20
    897c:	f9000fe3 	str	x3, [sp, #24]
    8980:	97fff4a4 	bl	5c10 <fwp_drop0>
    8984:	9100c2b4 	add	x20, x21, #0x30
    8988:	f9400fe3 	ldr	x3, [sp, #24]
    898c:	d2800021 	mov	x1, #0x1                   	// #1
    8990:	f9400342 	ldr	x2, [x26]
    8994:	aa0303e0 	mov	x0, x3
    8998:	f9400683 	ldr	x3, [x20, #8]
    899c:	97ffe7d9 	bl	2900 <fwrite@plt>
    89a0:	f9400681 	ldr	x1, [x20, #8]
    89a4:	52800140 	mov	w0, #0xa                   	// #10
    89a8:	97ffe75e 	bl	2720 <fputc@plt>
    89ac:	9114c2c2 	add	x2, x22, #0x530
    89b0:	f949d841 	ldr	x1, [x2, #5040]
    89b4:	f949ec40 	ldr	x0, [x2, #5080]
    89b8:	cb010341 	sub	x1, x26, x1
    89bc:	eb00403f 	cmp	x1, x0, lsl #16
    89c0:	54000382 	b.cs	8a30 <fwp_hof0.constprop.0+0x6d0>  // b.hs, b.nlast
    89c4:	d350fc20 	lsr	x0, x1, #16
    89c8:	f949fc44 	ldr	x4, [x2, #5112]
    89cc:	8b000800 	add	x0, x0, x0, lsl #2
    89d0:	d37df002 	lsl	x2, x0, #3
    89d4:	8b020083 	add	x3, x4, x2
    89d8:	f9401074 	ldr	x20, [x3, #32]
    89dc:	b40002b4 	cbz	x20, 8a30 <fwp_hof0.constprop.0+0x6d0>
    89e0:	38626882 	ldrb	w2, [x4, x2]
    89e4:	7100085f 	cmp	w2, #0x2
    89e8:	54008480 	b.eq	9a78 <fwp_hof0.constprop.0+0x1718>  // b.none
    89ec:	7100045f 	cmp	w2, #0x1
    89f0:	54000201 	b.ne	8a30 <fwp_hof0.constprop.0+0x6d0>  // b.any
    89f4:	29430062 	ldp	w2, w0, [x3, #24]
    89f8:	92403c21 	and	x1, x1, #0xffff
    89fc:	9b027c21 	mul	x1, x1, x2
    8a00:	d360fc21 	lsr	x1, x1, #32
    8a04:	eb00003f 	cmp	x1, x0
    8a08:	54000142 	b.cs	8a30 <fwp_hof0.constprop.0+0x6d0>  // b.hs, b.nlast
    8a0c:	8b010294 	add	x20, x20, x1
    8a10:	39400281 	ldrb	w1, [x20]
    8a14:	340000e1 	cbz	w1, 8a30 <fwp_hof0.constprop.0+0x6d0>
    8a18:	7100043f 	cmp	w1, #0x1
    8a1c:	54008280 	b.eq	9a6c <fwp_hof0.constprop.0+0x170c>  // b.none
    8a20:	7103fc3f 	cmp	w1, #0xff
    8a24:	54008420 	b.eq	9aa8 <fwp_hof0.constprop.0+0x1748>  // b.none
    8a28:	51000421 	sub	w1, w1, #0x1
    8a2c:	39000281 	strb	w1, [x20]
    8a30:	f94013e0 	ldr	x0, [sp, #32]
    8a34:	f9400800 	ldr	x0, [x0, #16]
    8a38:	f90013e0 	str	x0, [sp, #32]
    8a3c:	b5ffcca0 	cbnz	x0, 83d0 <fwp_hof0.constprop.0+0x70>
    8a40:	a95253f3 	ldp	x19, x20, [sp, #288]
    8a44:	a9535bf5 	ldp	x21, x22, [sp, #304]
    8a48:	a95463f7 	ldp	x23, x24, [sp, #320]
    8a4c:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8a50:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8a54:	f947f400 	ldr	x0, [x0, #4072]
    8a58:	f94087e2 	ldr	x2, [sp, #264]
    8a5c:	f9400001 	ldr	x1, [x0]
    8a60:	eb010042 	subs	x2, x2, x1
    8a64:	d2800001 	mov	x1, #0x0                   	// #0
    8a68:	540096c1 	b.ne	9d40 <fwp_hof0.constprop.0+0x19e0>  // b.any
    8a6c:	a9517bfd 	ldp	x29, x30, [sp, #272]
    8a70:	d2800000 	mov	x0, #0x0                   	// #0
    8a74:	a95673fb 	ldp	x27, x28, [sp, #352]
    8a78:	9105c3ff 	add	sp, sp, #0x170
    8a7c:	d65f03c0 	ret
    8a80:	d0ffffe0 	adrp	x0, 6000 <fwp_closure_drop+0x110>
    8a84:	91064000 	add	x0, x0, #0x190
    8a88:	9400118a 	bl	d0b0 <atexit>
    8a8c:	35005260 	cbnz	w0, 94d8 <fwp_hof0.constprop.0+0x1178>
    8a90:	52800020 	mov	w0, #0x1                   	// #1
    8a94:	b902e6e0 	str	w0, [x23, #740]
    8a98:	17fffee5 	b	862c <fwp_hof0.constprop.0+0x2cc>
    8a9c:	d3707ce7 	ubfiz	x7, x7, #16, #32
    8aa0:	52800041 	mov	w1, #0x2                   	// #2
    8aa4:	aa0900e0 	orr	x0, x7, x9
    8aa8:	f9001fe0 	str	x0, [sp, #56]
    8aac:	d2800100 	mov	x0, #0x8                   	// #8
    8ab0:	97fff04c 	bl	4be0 <fwp_heap_alloc>
    8ab4:	aa0003e9 	mov	x9, x0
    8ab8:	9114c2c0 	add	x0, x22, #0x530
    8abc:	aa0903ea 	mov	x10, x9
    8ac0:	f900013f 	str	xzr, [x9]
    8ac4:	f949d801 	ldr	x1, [x0, #5040]
    8ac8:	f949ec00 	ldr	x0, [x0, #5080]
    8acc:	cb010121 	sub	x1, x9, x1
    8ad0:	eb00403f 	cmp	x1, x0, lsl #16
    8ad4:	54001342 	b.cs	8d3c <fwp_hof0.constprop.0+0x9dc>  // b.hs, b.nlast
    8ad8:	d2800017 	mov	x23, #0x0                   	// #0
    8adc:	9114c2c2 	add	x2, x22, #0x530
    8ae0:	d350fc20 	lsr	x0, x1, #16
    8ae4:	8b000800 	add	x0, x0, x0, lsl #2
    8ae8:	f949fc46 	ldr	x6, [x2, #5112]
    8aec:	d37df002 	lsl	x2, x0, #3
    8af0:	8b0200c4 	add	x4, x6, x2
    8af4:	f940109a 	ldr	x26, [x4, #32]
    8af8:	b400025a 	cbz	x26, 8b40 <fwp_hof0.constprop.0+0x7e0>
    8afc:	386268c2 	ldrb	w2, [x6, x2]
    8b00:	7100085f 	cmp	w2, #0x2
    8b04:	54001200 	b.eq	8d44 <fwp_hof0.constprop.0+0x9e4>  // b.none
    8b08:	7100045f 	cmp	w2, #0x1
    8b0c:	540001a1 	b.ne	8b40 <fwp_hof0.constprop.0+0x7e0>  // b.any
    8b10:	29430886 	ldp	w6, w2, [x4, #24]
    8b14:	92403c21 	and	x1, x1, #0xffff
    8b18:	9b067c21 	mul	x1, x1, x6
    8b1c:	d360fc21 	lsr	x1, x1, #32
    8b20:	eb02003f 	cmp	x1, x2
    8b24:	540000e2 	b.cs	8b40 <fwp_hof0.constprop.0+0x7e0>  // b.hs, b.nlast
    8b28:	8b01035a 	add	x26, x26, x1
    8b2c:	39400341 	ldrb	w1, [x26]
    8b30:	7103fc3f 	cmp	w1, #0xff
    8b34:	54004680 	b.eq	9404 <fwp_hof0.constprop.0+0x10a4>  // b.none
    8b38:	52800021 	mov	w1, #0x1                   	// #1
    8b3c:	39000341 	strb	w1, [x26]
    8b40:	b4000257 	cbz	x23, 8b88 <fwp_hof0.constprop.0+0x828>
    8b44:	f9401fe0 	ldr	x0, [sp, #56]
    8b48:	aa1903e4 	mov	x4, x25
    8b4c:	f9400728 	ldr	x8, [x25, #8]
    8b50:	91002122 	add	x2, x9, #0x8
    8b54:	d3607c07 	lsl	x7, x0, #32
    8b58:	d2800001 	mov	x1, #0x0                   	// #0
    8b5c:	aa0703e6 	mov	x6, x7
    8b60:	14000005 	b	8b74 <fwp_hof0.constprop.0+0x814>
    8b64:	f9400488 	ldr	x8, [x4, #8]
    8b68:	ab0100e6 	adds	x6, x7, x1
    8b6c:	91004042 	add	x2, x2, #0x10
    8b70:	54009566 	b.vs	9e1c <fwp_hof0.constprop.0+0x1abc>
    8b74:	a9001848 	stp	x8, x6, [x2]
    8b78:	91000421 	add	x1, x1, #0x1
    8b7c:	f9400884 	ldr	x4, [x4, #16]
    8b80:	eb17003f 	cmp	x1, x23
    8b84:	54ffff03 	b.cc	8b64 <fwp_hof0.constprop.0+0x804>  // b.lo, b.ul, b.last
    8b88:	f9400120 	ldr	x0, [x9]
    8b8c:	f100041f 	cmp	x0, #0x1
    8b90:	54000d69 	b.ls	8d3c <fwp_hof0.constprop.0+0x9dc>  // b.plast
    8b94:	d341fc00 	lsr	x0, x0, #1
    8b98:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8b9c:	d1000401 	sub	x1, x0, #0x1
    8ba0:	eb02003f 	cmp	x1, x2
    8ba4:	54ffe508 	b.hi	8844 <fwp_hof0.constprop.0+0x4e4>  // b.pmore
    8ba8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    8bac:	a90d7fe2 	stp	x2, xzr, [sp, #208]
    8bb0:	d37ff822 	lsl	x2, x1, #1
    8bb4:	b4000321 	cbz	x1, 8c18 <fwp_hof0.constprop.0+0x8b8>
    8bb8:	d1002121 	sub	x1, x9, #0x8
    8bbc:	9100213a 	add	x26, x9, #0x8
    8bc0:	8b001037 	add	x23, x1, x0, lsl #4
    8bc4:	910343e0 	add	x0, sp, #0xd0
    8bc8:	f90023f3 	str	x19, [sp, #64]
    8bcc:	aa1a03f3 	mov	x19, x26
    8bd0:	aa0203fa 	mov	x26, x2
    8bd4:	a90527f9 	stp	x25, x9, [sp, #80]
    8bd8:	aa0003f9 	mov	x25, x0
    8bdc:	f90033ea 	str	x10, [sp, #96]
    8be0:	f9400660 	ldr	x0, [x19, #8]
    8be4:	aa1903e2 	mov	x2, x25
    8be8:	f9400e61 	ldr	x1, [x19, #24]
    8bec:	fd400260 	ldr	d0, [x19]
    8bf0:	fd400a61 	ldr	d1, [x19, #16]
    8bf4:	97fff15b 	bl	5160 <w120>
    8bf8:	a9000660 	stp	x0, x1, [x19]
    8bfc:	91004273 	add	x19, x19, #0x10
    8c00:	eb1302ff 	cmp	x23, x19
    8c04:	54fffee1 	b.ne	8be0 <fwp_hof0.constprop.0+0x880>  // b.any
    8c08:	a94527f9 	ldp	x25, x9, [sp, #80]
    8c0c:	aa1a03e2 	mov	x2, x26
    8c10:	f94023f3 	ldr	x19, [sp, #64]
    8c14:	f94033ea 	ldr	x10, [sp, #96]
    8c18:	9114c2d7 	add	x23, x22, #0x530
    8c1c:	f9000122 	str	x2, [x9]
    8c20:	aa0903e0 	mov	x0, x9
    8c24:	f90023e9 	str	x9, [sp, #64]
    8c28:	f9002fea 	str	x10, [sp, #88]
    8c2c:	97fff29d 	bl	56a0 <w176.constprop.0>
    8c30:	f94023e9 	ldr	x9, [sp, #64]
    8c34:	f9002be1 	str	x1, [sp, #80]
    8c38:	f949dae1 	ldr	x1, [x23, #5040]
    8c3c:	f949eee0 	ldr	x0, [x23, #5080]
    8c40:	cb010121 	sub	x1, x9, x1
    8c44:	f9402fea 	ldr	x10, [sp, #88]
    8c48:	aa0a03fa 	mov	x26, x10
    8c4c:	eb00403f 	cmp	x1, x0, lsl #16
    8c50:	54000382 	b.cs	8cc0 <fwp_hof0.constprop.0+0x960>  // b.hs, b.nlast
    8c54:	d350fc20 	lsr	x0, x1, #16
    8c58:	f949fee6 	ldr	x6, [x23, #5112]
    8c5c:	8b000800 	add	x0, x0, x0, lsl #2
    8c60:	d37df002 	lsl	x2, x0, #3
    8c64:	8b0200c3 	add	x3, x6, x2
    8c68:	f9401060 	ldr	x0, [x3, #32]
    8c6c:	b40002a0 	cbz	x0, 8cc0 <fwp_hof0.constprop.0+0x960>
    8c70:	386268c2 	ldrb	w2, [x6, x2]
    8c74:	7100085f 	cmp	w2, #0x2
    8c78:	54001800 	b.eq	8f78 <fwp_hof0.constprop.0+0xc18>  // b.none
    8c7c:	7100045f 	cmp	w2, #0x1
    8c80:	54000201 	b.ne	8cc0 <fwp_hof0.constprop.0+0x960>  // b.any
    8c84:	29430864 	ldp	w4, w2, [x3, #24]
    8c88:	92403c21 	and	x1, x1, #0xffff
    8c8c:	9b047c21 	mul	x1, x1, x4
    8c90:	d360fc21 	lsr	x1, x1, #32
    8c94:	eb02003f 	cmp	x1, x2
    8c98:	54000142 	b.cs	8cc0 <fwp_hof0.constprop.0+0x960>  // b.hs, b.nlast
    8c9c:	8b010000 	add	x0, x0, x1
    8ca0:	39400001 	ldrb	w1, [x0]
    8ca4:	340000e1 	cbz	w1, 8cc0 <fwp_hof0.constprop.0+0x960>
    8ca8:	7100043f 	cmp	w1, #0x1
    8cac:	54000520 	b.eq	8d50 <fwp_hof0.constprop.0+0x9f0>  // b.none
    8cb0:	7103fc3f 	cmp	w1, #0xff
    8cb4:	54003c80 	b.eq	9444 <fwp_hof0.constprop.0+0x10e4>  // b.none
    8cb8:	51000421 	sub	w1, w1, #0x1
    8cbc:	39000001 	strb	w1, [x0]
    8cc0:	b9803bfa 	ldrsw	x26, [sp, #56]
    8cc4:	aa1a03e0 	mov	x0, x26
    8cc8:	97ffee52 	bl	4610 <fwp_tape_of>
    8ccc:	f9402808 	ldr	x8, [x0, #80]
    8cd0:	aa0003e6 	mov	x6, x0
    8cd4:	b4000f08 	cbz	x8, 8eb4 <fwp_hof0.constprop.0+0xb54>
    8cd8:	b0000020 	adrp	x0, d000 <__modti3+0x2c0>
    8cdc:	9110e000 	add	x0, x0, #0x438
    8ce0:	97ffec48 	bl	3e00 <fwp_trap>
    8ce4:	d280001a 	mov	x26, #0x0                   	// #0
    8ce8:	17fffe4e 	b	8620 <fwp_hof0.constprop.0+0x2c0>
    8cec:	d37ffae2 	lsl	x2, x23, #1
    8cf0:	d3707ce7 	ubfiz	x7, x7, #16, #32
    8cf4:	91000440 	add	x0, x2, #0x1
    8cf8:	aa0900e1 	orr	x1, x7, x9
    8cfc:	aa0203fa 	mov	x26, x2
    8d00:	f9001fe1 	str	x1, [sp, #56]
    8d04:	d37df000 	lsl	x0, x0, #3
    8d08:	52800041 	mov	w1, #0x2                   	// #2
    8d0c:	97ffefb5 	bl	4be0 <fwp_heap_alloc>
    8d10:	aa0003e9 	mov	x9, x0
    8d14:	9114c2c1 	add	x1, x22, #0x530
    8d18:	aa0003ea 	mov	x10, x0
    8d1c:	aa0103e0 	mov	x0, x1
    8d20:	f900013a 	str	x26, [x9]
    8d24:	f949d821 	ldr	x1, [x1, #5040]
    8d28:	f949ec00 	ldr	x0, [x0, #5080]
    8d2c:	cb010121 	sub	x1, x9, x1
    8d30:	eb00403f 	cmp	x1, x0, lsl #16
    8d34:	54ffed43 	b.cc	8adc <fwp_hof0.constprop.0+0x77c>  // b.lo, b.ul, b.last
    8d38:	b5fff077 	cbnz	x23, 8b44 <fwp_hof0.constprop.0+0x7e4>
    8d3c:	d2800002 	mov	x2, #0x0                   	// #0
    8d40:	17ffffb6 	b	8c18 <fwp_hof0.constprop.0+0x8b8>
    8d44:	72003c3f 	tst	w1, #0xffff
    8d48:	54ffefc1 	b.ne	8b40 <fwp_hof0.constprop.0+0x7e0>  // b.any
    8d4c:	17ffff78 	b	8b2c <fwp_hof0.constprop.0+0x7cc>
    8d50:	f9400343 	ldr	x3, [x26]
    8d54:	aa1a03e0 	mov	x0, x26
    8d58:	f949eee2 	ldr	x2, [x23, #5080]
    8d5c:	f949dae1 	ldr	x1, [x23, #5040]
    8d60:	d370bc44 	lsl	x4, x2, #16
    8d64:	cb010342 	sub	x2, x26, x1
    8d68:	b7f810e3 	tbnz	x3, #63, 8f84 <fwp_hof0.constprop.0+0xc24>
    8d6c:	aa1a03ea 	mov	x10, x26
    8d70:	eb04005f 	cmp	x2, x4
    8d74:	54fffa62 	b.cs	8cc0 <fwp_hof0.constprop.0+0x960>  // b.hs, b.nlast
    8d78:	d350fc40 	lsr	x0, x2, #16
    8d7c:	8b000800 	add	x0, x0, x0, lsl #2
    8d80:	d37df000 	lsl	x0, x0, #3
    8d84:	8b0000c4 	add	x4, x6, x0
    8d88:	f9401081 	ldr	x1, [x4, #32]
    8d8c:	b4fff9a1 	cbz	x1, 8cc0 <fwp_hof0.constprop.0+0x960>
    8d90:	386068c0 	ldrb	w0, [x6, x0]
    8d94:	7100081f 	cmp	w0, #0x2
    8d98:	54003260 	b.eq	93e4 <fwp_hof0.constprop.0+0x1084>  // b.none
    8d9c:	7100041f 	cmp	w0, #0x1
    8da0:	54fff901 	b.ne	8cc0 <fwp_hof0.constprop.0+0x960>  // b.any
    8da4:	92403c40 	and	x0, x2, #0xffff
    8da8:	29430886 	ldp	w6, w2, [x4, #24]
    8dac:	9b067c00 	mul	x0, x0, x6
    8db0:	d360fc00 	lsr	x0, x0, #32
    8db4:	eb02001f 	cmp	x0, x2
    8db8:	54fff842 	b.cs	8cc0 <fwp_hof0.constprop.0+0x960>  // b.hs, b.nlast
    8dbc:	8b000021 	add	x1, x1, x0
    8dc0:	39400020 	ldrb	w0, [x1]
    8dc4:	7100041f 	cmp	w0, #0x1
    8dc8:	54fff7c1 	b.ne	8cc0 <fwp_hof0.constprop.0+0x960>  // b.any
    8dcc:	aa0a03e0 	mov	x0, x10
    8dd0:	97ffecc8 	bl	40f0 <fwp_mem_free>
    8dd4:	17ffffbb 	b	8cc0 <fwp_hof0.constprop.0+0x960>
    8dd8:	b0000020 	adrp	x0, d000 <__modti3+0x2c0>
    8ddc:	9119a000 	add	x0, x0, #0x668
    8de0:	97ffec08 	bl	3e00 <fwp_trap>
    8de4:	3cc38000 	ldur	q0, [x0, #56]
    8de8:	f900301f 	str	xzr, [x0, #96]
    8dec:	3d800840 	str	q0, [x2, #32]
    8df0:	f9402c04 	ldr	x4, [x0, #88]
    8df4:	f9001c44 	str	x4, [x2, #56]
    8df8:	f9402404 	ldr	x4, [x0, #72]
    8dfc:	f9001844 	str	x4, [x2, #48]
    8e00:	f9402804 	ldr	x4, [x0, #80]
    8e04:	f9000c44 	str	x4, [x2, #24]
    8e08:	a903fc1f 	stp	xzr, xzr, [x0, #56]
    8e0c:	a904fc1f 	stp	xzr, xzr, [x0, #72]
    8e10:	f9002c1f 	str	xzr, [x0, #88]
    8e14:	17fffe59 	b	8778 <fwp_hof0.constprop.0+0x418>
    8e18:	b0000020 	adrp	x0, d000 <__modti3+0x2c0>
    8e1c:	9117a000 	add	x0, x0, #0x5e8
    8e20:	97ffebf8 	bl	3e00 <fwp_trap>
    8e24:	97ffed2c 	bl	42d4 <fwp_rc_wide_dup>
    8e28:	9114c2c0 	add	x0, x22, #0x530
    8e2c:	f949ec04 	ldr	x4, [x0, #5080]
    8e30:	f949d801 	ldr	x1, [x0, #5040]
    8e34:	d370bc84 	lsl	x4, x4, #16
    8e38:	17fffd8a 	b	8460 <fwp_hof0.constprop.0+0x100>
    8e3c:	97ffed26 	bl	42d4 <fwp_rc_wide_dup>
    8e40:	17fffdb5 	b	8514 <fwp_hof0.constprop.0+0x1b4>
    8e44:	ca5746e0 	eor	x0, x23, x23, lsr #17
    8e48:	9114c2c1 	add	x1, x22, #0x530
    8e4c:	ca402400 	eor	x0, x0, x0, lsr #9
    8e50:	92401c00 	and	x0, x0, #0xff
    8e54:	910a2402 	add	x2, x0, #0x289
    8e58:	8b000c20 	add	x0, x1, x0, lsl #3
    8e5c:	8b020c22 	add	x2, x1, x2, lsl #3
    8e60:	f94a2400 	ldr	x0, [x0, #5192]
    8e64:	b50000a0 	cbnz	x0, 8e78 <fwp_hof0.constprop.0+0xb18>
    8e68:	14000162 	b	93f0 <fwp_hof0.constprop.0+0x1090>
    8e6c:	91004002 	add	x2, x0, #0x10
    8e70:	f9400800 	ldr	x0, [x0, #16]
    8e74:	b4002be0 	cbz	x0, 93f0 <fwp_hof0.constprop.0+0x1090>
    8e78:	f9400001 	ldr	x1, [x0]
    8e7c:	eb0102ff 	cmp	x23, x1
    8e80:	54ffff61 	b.ne	8e6c <fwp_hof0.constprop.0+0xb0c>  // b.any
    8e84:	f9400041 	ldr	x1, [x2]
    8e88:	f9400420 	ldr	x0, [x1, #8]
    8e8c:	d1000400 	sub	x0, x0, #0x1
    8e90:	f9000420 	str	x0, [x1, #8]
    8e94:	f103f81f 	cmp	x0, #0xfe
    8e98:	54ffb801 	b.ne	8598 <fwp_hof0.constprop.0+0x238>  // b.any
    8e9c:	394002e0 	ldrb	w0, [x23]
    8ea0:	7103fc1f 	cmp	w0, #0xff
    8ea4:	54002ca0 	b.eq	9438 <fwp_hof0.constprop.0+0x10d8>  // b.none
    8ea8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8eac:	390002e0 	strb	w0, [x23]
    8eb0:	17fffdba 	b	8598 <fwp_hof0.constprop.0+0x238>
    8eb4:	97ffe817 	bl	2f10 <fwp_tape_unlink_scope>
    8eb8:	b90004df 	str	wzr, [x6, #4]
    8ebc:	3dc008c0 	ldr	q0, [x6, #32]
    8ec0:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    8ec4:	b94000c1 	ldr	w1, [x6]
    8ec8:	a940a4c7 	ldp	x7, x9, [x6, #8]
    8ecc:	3d8013e0 	str	q0, [sp, #64]
    8ed0:	f9400cc8 	ldr	x8, [x6, #24]
    8ed4:	a94308c4 	ldp	x4, x2, [x6, #48]
    8ed8:	6b00003f 	cmp	w1, w0
    8edc:	54000108 	b.hi	8efc <fwp_hof0.constprop.0+0xb9c>  // b.pmore
    8ee0:	9100c2a1 	add	x1, x21, #0x30
    8ee4:	92403f40 	and	x0, x26, #0xffff
    8ee8:	d1000400 	sub	x0, x0, #0x1
    8eec:	f940442a 	ldr	x10, [x1, #136]
    8ef0:	eb0a001f 	cmp	x0, x10
    8ef4:	5400004a 	b.ge	8efc <fwp_hof0.constprop.0+0xb9c>  // b.tcont
    8ef8:	f9004420 	str	x0, [x1, #136]
    8efc:	9100c2a1 	add	x1, x21, #0x30
    8f00:	f9000cdf 	str	xzr, [x6, #24]
    8f04:	4f000400 	movi	v0.4s, #0x0
    8f08:	a9037cdf 	stp	xzr, xzr, [x6, #48]
    8f0c:	9102e3e3 	add	x3, sp, #0xb8
    8f10:	f9415820 	ldr	x0, [x1, #688]
    8f14:	f9005fe0 	str	x0, [sp, #184]
    8f18:	f0ffffc0 	adrp	x0, 3000 <fwp_segv+0x10>
    8f1c:	9133c000 	add	x0, x0, #0xcf0
    8f20:	3c8080c0 	stur	q0, [x6, #8]
    8f24:	3d8008c0 	str	q0, [x6, #32]
    8f28:	3dc013e0 	ldr	q0, [sp, #64]
    8f2c:	f90063e0 	str	x0, [sp, #192]
    8f30:	910343e0 	add	x0, sp, #0xd0
    8f34:	f9001fe0 	str	x0, [sp, #56]
    8f38:	f90067e0 	str	x0, [sp, #200]
    8f3c:	f9402be0 	ldr	x0, [sp, #80]
    8f40:	f9002fe3 	str	x3, [sp, #88]
    8f44:	a90e23e4 	stp	x4, x8, [sp, #224]
    8f48:	f9007be2 	str	x2, [sp, #240]
    8f4c:	f9015823 	str	x3, [x1, #688]
    8f50:	3d8037e0 	str	q0, [sp, #208]
    8f54:	b7f82540 	tbnz	x0, #63, 93fc <fwp_hof0.constprop.0+0x109c>
    8f58:	eb80835f 	cmp	x26, x0, asr #32
    8f5c:	54000560 	b.eq	9008 <fwp_hof0.constprop.0+0xca8>  // b.none
    8f60:	b0000020 	adrp	x0, d000 <__modti3+0x2c0>
    8f64:	910fc000 	add	x0, x0, #0x3f0
    8f68:	97ffeba6 	bl	3e00 <fwp_trap>
    8f6c:	d2800b01 	mov	x1, #0x58                  	// #88
    8f70:	d2800024 	mov	x4, #0x1                   	// #1
    8f74:	17fffdd3 	b	86c0 <fwp_hof0.constprop.0+0x360>
    8f78:	72003c3f 	tst	w1, #0xffff
    8f7c:	54ffea21 	b.ne	8cc0 <fwp_hof0.constprop.0+0x960>  // b.any
    8f80:	17ffff48 	b	8ca0 <fwp_hof0.constprop.0+0x940>
    8f84:	f940075a 	ldr	x26, [x26, #8]
    8f88:	eb04005f 	cmp	x2, x4
    8f8c:	54000362 	b.cs	8ff8 <fwp_hof0.constprop.0+0xc98>  // b.hs, b.nlast
    8f90:	d350fc43 	lsr	x3, x2, #16
    8f94:	8b030863 	add	x3, x3, x3, lsl #2
    8f98:	d37df063 	lsl	x3, x3, #3
    8f9c:	8b0300c7 	add	x7, x6, x3
    8fa0:	f94010e5 	ldr	x5, [x7, #32]
    8fa4:	b40002a5 	cbz	x5, 8ff8 <fwp_hof0.constprop.0+0xc98>
    8fa8:	386368c3 	ldrb	w3, [x6, x3]
    8fac:	7100087f 	cmp	w3, #0x2
    8fb0:	540023e0 	b.eq	942c <fwp_hof0.constprop.0+0x10cc>  // b.none
    8fb4:	7100047f 	cmp	w3, #0x1
    8fb8:	54000201 	b.ne	8ff8 <fwp_hof0.constprop.0+0xc98>  // b.any
    8fbc:	29430ce6 	ldp	w6, w3, [x7, #24]
    8fc0:	92403c42 	and	x2, x2, #0xffff
    8fc4:	9b067c42 	mul	x2, x2, x6
    8fc8:	d360fc42 	lsr	x2, x2, #32
    8fcc:	eb03005f 	cmp	x2, x3
    8fd0:	54000142 	b.cs	8ff8 <fwp_hof0.constprop.0+0xc98>  // b.hs, b.nlast
    8fd4:	8b0200a5 	add	x5, x5, x2
    8fd8:	394000a2 	ldrb	w2, [x5]
    8fdc:	7100045f 	cmp	w2, #0x1
    8fe0:	540000c1 	b.ne	8ff8 <fwp_hof0.constprop.0+0xc98>  // b.any
    8fe4:	97ffec43 	bl	40f0 <fwp_mem_free>
    8fe8:	9114c2c0 	add	x0, x22, #0x530
    8fec:	f949ec02 	ldr	x2, [x0, #5080]
    8ff0:	f949d801 	ldr	x1, [x0, #5040]
    8ff4:	d370bc44 	lsl	x4, x2, #16
    8ff8:	cb010341 	sub	x1, x26, x1
    8ffc:	eb01009f 	cmp	x4, x1
    9000:	54ffe2a8 	b.hi	8c54 <fwp_hof0.constprop.0+0x8f4>  // b.pmore
    9004:	17ffff2f 	b	8cc0 <fwp_hof0.constprop.0+0x960>
    9008:	f9402be0 	ldr	x0, [sp, #80]
    900c:	92407c17 	and	x23, x0, #0xffffffff
    9010:	eb20413f 	cmp	x9, w0, uxtw
    9014:	5400206d 	b.le	9420 <fwp_hof0.constprop.0+0x10c0>
    9018:	eb1700ff 	cmp	x7, x23
    901c:	9a97c4f7 	csinc	x23, x7, x23, gt
    9020:	eb17005f 	cmp	x2, x23
    9024:	5400248a 	b.ge	94b4 <fwp_hof0.constprop.0+0x1154>  // b.tcont
    9028:	f100005f 	cmp	x2, #0x0
    902c:	b24077e6 	mov	x6, #0x3fffffff            	// #1073741823
    9030:	9a971042 	csel	x2, x2, x23, ne	// ne = any
    9034:	14000004 	b	9044 <fwp_hof0.constprop.0+0xce4>
    9038:	eb06005f 	cmp	x2, x6
    903c:	d37ff842 	lsl	x2, x2, #1
    9040:	9a97d042 	csel	x2, x2, x23, le
    9044:	eb17005f 	cmp	x2, x23
    9048:	54ffff8b 	b.lt	9038 <fwp_hof0.constprop.0+0xcd8>  // b.tstop
    904c:	f90037e7 	str	x7, [sp, #104]
    9050:	b40059a4 	cbz	x4, 9b84 <fwp_hof0.constprop.0+0x1824>
    9054:	aa0403e0 	mov	x0, x4
    9058:	d37df041 	lsl	x1, x2, #3
    905c:	f90033e2 	str	x2, [sp, #96]
    9060:	97ffe5e4 	bl	27f0 <realloc@plt>
    9064:	a9461fe2 	ldp	x2, x7, [sp, #96]
    9068:	aa0003e4 	mov	x4, x0
    906c:	b4002244 	cbz	x4, 94b4 <fwp_hof0.constprop.0+0x1154>
    9070:	f90073e4 	str	x4, [sp, #224]
    9074:	f9007be2 	str	x2, [sp, #240]
    9078:	b50024f7 	cbnz	x23, 9514 <fwp_hof0.constprop.0+0x11b4>
    907c:	f9402be0 	ldr	x0, [sp, #80]
    9080:	b7f800c0 	tbnz	x0, #63, 9098 <fwp_hof0.constprop.0+0xd38>
    9084:	92407c00 	and	x0, x0, #0xffffffff
    9088:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    908c:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    9090:	1e612800 	fadd	d0, d0, d1
    9094:	fc207880 	str	d0, [x4, x0, lsl #3]
    9098:	d10006e1 	sub	x1, x23, #0x1
    909c:	eb0100ff 	cmp	x7, x1
    90a0:	540003cc 	b.gt	9118 <fwp_hof0.constprop.0+0xdb8>
    90a4:	f94023e0 	ldr	x0, [sp, #64]
    90a8:	cb0702f7 	sub	x23, x23, x7
    90ac:	d10004e6 	sub	x6, x7, #0x1
    90b0:	8b1706f7 	add	x23, x23, x23, lsl #1
    90b4:	d1006000 	sub	x0, x0, #0x18
    90b8:	8b170c00 	add	x0, x0, x23, lsl #3
    90bc:	fc617880 	ldr	d0, [x4, x1, lsl #3]
    90c0:	1e602008 	fcmp	d0, #0.0
    90c4:	54000220 	b.eq	9108 <fwp_hof0.constprop.0+0xda8>  // b.none
    90c8:	b9400002 	ldr	w2, [x0]
    90cc:	37f800e2 	tbnz	w2, #31, 90e8 <fwp_hof0.constprop.0+0xd88>
    90d0:	fd400402 	ldr	d2, [x0, #8]
    90d4:	93407c42 	sxtw	x2, w2
    90d8:	1e620802 	fmul	d2, d0, d2
    90dc:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    90e0:	1e622821 	fadd	d1, d1, d2
    90e4:	fc227881 	str	d1, [x4, x2, lsl #3]
    90e8:	b9400402 	ldr	w2, [x0, #4]
    90ec:	37f800e2 	tbnz	w2, #31, 9108 <fwp_hof0.constprop.0+0xda8>
    90f0:	fd400801 	ldr	d1, [x0, #16]
    90f4:	93407c42 	sxtw	x2, w2
    90f8:	1e610800 	fmul	d0, d0, d1
    90fc:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    9100:	1e602820 	fadd	d0, d1, d0
    9104:	fc227880 	str	d0, [x4, x2, lsl #3]
    9108:	d1000421 	sub	x1, x1, #0x1
    910c:	d1006000 	sub	x0, x0, #0x18
    9110:	eb06003f 	cmp	x1, x6
    9114:	54fffd41 	b.ne	90bc <fwp_hof0.constprop.0+0xd5c>  // b.any
    9118:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    911c:	eb0000ff 	cmp	x7, x0
    9120:	54001f48 	b.hi	9508 <fwp_hof0.constprop.0+0x11a8>  // b.pmore
    9124:	910004e0 	add	x0, x7, #0x1
    9128:	52800041 	mov	w1, #0x2                   	// #2
    912c:	f90023e4 	str	x4, [sp, #64]
    9130:	d37df000 	lsl	x0, x0, #3
    9134:	f9002be7 	str	x7, [sp, #80]
    9138:	97ffeeaa 	bl	4be0 <fwp_heap_alloc>
    913c:	aa0003fa 	mov	x26, x0
    9140:	f9402be7 	ldr	x7, [sp, #80]
    9144:	f8008407 	str	x7, [x0], #8
    9148:	f94023e4 	ldr	x4, [sp, #64]
    914c:	d2800001 	mov	x1, #0x0                   	// #0
    9150:	b40000c7 	cbz	x7, 9168 <fwp_hof0.constprop.0+0xe08>
    9154:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    9158:	f8217802 	str	x2, [x0, x1, lsl #3]
    915c:	91000421 	add	x1, x1, #0x1
    9160:	eb0100ff 	cmp	x7, x1
    9164:	54ffff81 	b.ne	9154 <fwp_hof0.constprop.0+0xdf4>  // b.any
    9168:	9100c2a1 	add	x1, x21, #0x30
    916c:	f9402fe2 	ldr	x2, [sp, #88]
    9170:	f9415820 	ldr	x0, [x1, #688]
    9174:	eb02001f 	cmp	x0, x2
    9178:	54006541 	b.ne	9e20 <fwp_hof0.constprop.0+0x1ac0>  // b.any
    917c:	f9401fe0 	ldr	x0, [sp, #56]
    9180:	f9405fe6 	ldr	x6, [sp, #184]
    9184:	f9002be6 	str	x6, [sp, #80]
    9188:	f9015826 	str	x6, [x1, #688]
    918c:	97ffead9 	bl	3cf0 <fwp_tape_buffers_release>
    9190:	9114c2c2 	add	x2, x22, #0x530
    9194:	f9402be6 	ldr	x6, [sp, #80]
    9198:	f949d841 	ldr	x1, [x2, #5040]
    919c:	f949ec40 	ldr	x0, [x2, #5080]
    91a0:	cb010341 	sub	x1, x26, x1
    91a4:	eb00403f 	cmp	x1, x0, lsl #16
    91a8:	54000322 	b.cs	920c <fwp_hof0.constprop.0+0xeac>  // b.hs, b.nlast
    91ac:	d350fc20 	lsr	x0, x1, #16
    91b0:	f949fc47 	ldr	x7, [x2, #5112]
    91b4:	8b000800 	add	x0, x0, x0, lsl #2
    91b8:	d37df002 	lsl	x2, x0, #3
    91bc:	8b0200e4 	add	x4, x7, x2
    91c0:	f9401097 	ldr	x23, [x4, #32]
    91c4:	b4000257 	cbz	x23, 920c <fwp_hof0.constprop.0+0xeac>
    91c8:	386268e0 	ldrb	w0, [x7, x2]
    91cc:	7100081f 	cmp	w0, #0x2
    91d0:	54004e80 	b.eq	9ba0 <fwp_hof0.constprop.0+0x1840>  // b.none
    91d4:	7100041f 	cmp	w0, #0x1
    91d8:	540001a1 	b.ne	920c <fwp_hof0.constprop.0+0xeac>  // b.any
    91dc:	29430082 	ldp	w2, w0, [x4, #24]
    91e0:	92403c21 	and	x1, x1, #0xffff
    91e4:	9b027c21 	mul	x1, x1, x2
    91e8:	d360fc21 	lsr	x1, x1, #32
    91ec:	eb00003f 	cmp	x1, x0
    91f0:	540000e2 	b.cs	920c <fwp_hof0.constprop.0+0xeac>  // b.hs, b.nlast
    91f4:	8b0102f7 	add	x23, x23, x1
    91f8:	394002e0 	ldrb	w0, [x23]
    91fc:	7103fc1f 	cmp	w0, #0xff
    9200:	54004d60 	b.eq	9bac <fwp_hof0.constprop.0+0x184c>  // b.none
    9204:	52800020 	mov	w0, #0x1                   	// #1
    9208:	390002e0 	strb	w0, [x23]
    920c:	f9400be0 	ldr	x0, [sp, #16]
    9210:	eb0000df 	cmp	x6, x0
    9214:	54006061 	b.ne	9e20 <fwp_hof0.constprop.0+0x1ac0>  // b.any
    9218:	f94007e0 	ldr	x0, [sp, #8]
    921c:	9100c2a1 	add	x1, x21, #0x30
    9220:	f94053e2 	ldr	x2, [sp, #160]
    9224:	f9015822 	str	x2, [x1, #688]
    9228:	97fff416 	bl	6280 <fwp_tape_scope_release>
    922c:	f9400340 	ldr	x0, [x26]
    9230:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    9234:	b7f818e0 	tbnz	x0, #63, 9550 <fwp_hof0.constprop.0+0x11f0>
    9238:	9114c2c4 	add	x4, x22, #0x530
    923c:	f949d880 	ldr	x0, [x4, #5040]
    9240:	f949ec81 	ldr	x1, [x4, #5080]
    9244:	cb000340 	sub	x0, x26, x0
    9248:	eb01401f 	cmp	x0, x1, lsl #16
    924c:	54001822 	b.cs	9550 <fwp_hof0.constprop.0+0x11f0>  // b.hs, b.nlast
    9250:	d350fc01 	lsr	x1, x0, #16
    9254:	f949fc87 	ldr	x7, [x4, #5112]
    9258:	8b010821 	add	x1, x1, x1, lsl #2
    925c:	d37df021 	lsl	x1, x1, #3
    9260:	8b0100e6 	add	x6, x7, x1
    9264:	f94010c4 	ldr	x4, [x6, #32]
    9268:	b4001744 	cbz	x4, 9550 <fwp_hof0.constprop.0+0x11f0>
    926c:	386168e1 	ldrb	w1, [x7, x1]
    9270:	7100083f 	cmp	w1, #0x2
    9274:	540016a0 	b.eq	9548 <fwp_hof0.constprop.0+0x11e8>  // b.none
    9278:	7100043f 	cmp	w1, #0x1
    927c:	540016a1 	b.ne	9550 <fwp_hof0.constprop.0+0x11f0>  // b.any
    9280:	294304c7 	ldp	w7, w1, [x6, #24]
    9284:	92403c00 	and	x0, x0, #0xffff
    9288:	9b077c00 	mul	x0, x0, x7
    928c:	d360fc00 	lsr	x0, x0, #32
    9290:	eb01001f 	cmp	x0, x1
    9294:	540015e2 	b.cs	9550 <fwp_hof0.constprop.0+0x11f0>  // b.hs, b.nlast
    9298:	8b000084 	add	x4, x4, x0
    929c:	39400080 	ldrb	w0, [x4]
    92a0:	7100041f 	cmp	w0, #0x1
    92a4:	54001561 	b.ne	9550 <fwp_hof0.constprop.0+0x11f0>  // b.any
    92a8:	aa1a03f7 	mov	x23, x26
    92ac:	d2800000 	mov	x0, #0x0                   	// #0
    92b0:	910022e4 	add	x4, x23, #0x8
    92b4:	d2800001 	mov	x1, #0x0                   	// #0
    92b8:	b40001e2 	cbz	x2, 92f4 <fwp_hof0.constprop.0+0xf94>
    92bc:	90000023 	adrp	x3, d000 <__modti3+0x2c0>
    92c0:	91002347 	add	x7, x26, #0x8
    92c4:	fd470061 	ldr	d1, [x3, #3584]
    92c8:	f9400345 	ldr	x5, [x26]
    92cc:	aa0703e3 	mov	x3, x7
    92d0:	b7f81385 	tbnz	x5, #63, 9540 <fwp_hof0.constprop.0+0x11e0>
    92d4:	f94002e5 	ldr	x5, [x23]
    92d8:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    92dc:	b7f812c5 	tbnz	x5, #63, 9534 <fwp_hof0.constprop.0+0x11d4>
    92e0:	1e600820 	fmul	d0, d1, d0
    92e4:	91000421 	add	x1, x1, #0x1
    92e8:	fc008480 	str	d0, [x4], #8
    92ec:	eb01005f 	cmp	x2, x1
    92f0:	54fffec1 	b.ne	92c8 <fwp_hof0.constprop.0+0xf68>  // b.any
    92f4:	97fff5ef 	bl	6ab0 <fwp_drop10>
    92f8:	b40054d9 	cbz	x25, 9d90 <fwp_hof0.constprop.0+0x1a30>
    92fc:	aa1903e0 	mov	x0, x25
    9300:	d280001a 	mov	x26, #0x0                   	// #0
    9304:	f9400800 	ldr	x0, [x0, #16]
    9308:	9100075a 	add	x26, x26, #0x1
    930c:	b5ffffc0 	cbnz	x0, 9304 <fwp_hof0.constprop.0+0xfa4>
    9310:	f94002e0 	ldr	x0, [x23]
    9314:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    9318:	b7f81780 	tbnz	x0, #63, 9608 <fwp_hof0.constprop.0+0x12a8>
    931c:	9114c2c1 	add	x1, x22, #0x530
    9320:	f949d820 	ldr	x0, [x1, #5040]
    9324:	f949ec24 	ldr	x4, [x1, #5080]
    9328:	cb0002e0 	sub	x0, x23, x0
    932c:	eb04401f 	cmp	x0, x4, lsl #16
    9330:	540016a2 	b.cs	9604 <fwp_hof0.constprop.0+0x12a4>  // b.hs, b.nlast
    9334:	d350fc04 	lsr	x4, x0, #16
    9338:	d2800506 	mov	x6, #0x28                  	// #40
    933c:	f949fc27 	ldr	x7, [x1, #5112]
    9340:	9b067c84 	mul	x4, x4, x6
    9344:	8b0400e6 	add	x6, x7, x4
    9348:	f94010c1 	ldr	x1, [x6, #32]
    934c:	b40015c1 	cbz	x1, 9604 <fwp_hof0.constprop.0+0x12a4>
    9350:	386468e4 	ldrb	w4, [x7, x4]
    9354:	7100089f 	cmp	w4, #0x2
    9358:	54001520 	b.eq	95fc <fwp_hof0.constprop.0+0x129c>  // b.none
    935c:	7100049f 	cmp	w4, #0x1
    9360:	54001521 	b.ne	9604 <fwp_hof0.constprop.0+0x12a4>  // b.any
    9364:	294310c7 	ldp	w7, w4, [x6, #24]
    9368:	92403c00 	and	x0, x0, #0xffff
    936c:	9b077c00 	mul	x0, x0, x7
    9370:	d360fc00 	lsr	x0, x0, #32
    9374:	eb04001f 	cmp	x0, x4
    9378:	54001462 	b.cs	9604 <fwp_hof0.constprop.0+0x12a4>  // b.hs, b.nlast
    937c:	8b000021 	add	x1, x1, x0
    9380:	39400029 	ldrb	w9, [x1]
    9384:	7100053f 	cmp	w9, #0x1
    9388:	540013e1 	b.ne	9604 <fwp_hof0.constprop.0+0x12a4>  // b.any
    938c:	910022e1 	add	x1, x23, #0x8
    9390:	eb1a005f 	cmp	x2, x26
    9394:	9a9a9042 	csel	x2, x2, x26, ls	// ls = plast
    9398:	b4004ae2 	cbz	x2, 9cf4 <fwp_hof0.constprop.0+0x1994>
    939c:	d37df048 	lsl	x8, x2, #3
    93a0:	aa1903e4 	mov	x4, x25
    93a4:	910022e7 	add	x7, x23, #0x8
    93a8:	d2800000 	mov	x0, #0x0                   	// #0
    93ac:	14000009 	b	93d0 <fwp_hof0.constprop.0+0x1070>
    93b0:	fc606861 	ldr	d1, [x3, x0]
    93b4:	fd400480 	ldr	d0, [x4, #8]
    93b8:	1e613800 	fsub	d0, d0, d1
    93bc:	fc206820 	str	d0, [x1, x0]
    93c0:	91002000 	add	x0, x0, #0x8
    93c4:	f9400884 	ldr	x4, [x4, #16]
    93c8:	eb00011f 	cmp	x8, x0
    93cc:	540014c0 	b.eq	9664 <fwp_hof0.constprop.0+0x1304>  // b.none
    93d0:	f94002e5 	ldr	x5, [x23]
    93d4:	aa0703e3 	mov	x3, x7
    93d8:	b6fffec5 	tbz	x5, #63, 93b0 <fwp_hof0.constprop.0+0x1050>
    93dc:	f9400ae3 	ldr	x3, [x23, #16]
    93e0:	17fffff4 	b	93b0 <fwp_hof0.constprop.0+0x1050>
    93e4:	72003c5f 	tst	w2, #0xffff
    93e8:	54ffc6c1 	b.ne	8cc0 <fwp_hof0.constprop.0+0x960>  // b.any
    93ec:	17fffe75 	b	8dc0 <fwp_hof0.constprop.0+0xa60>
    93f0:	90000020 	adrp	x0, d000 <__modti3+0x2c0>
    93f4:	91088000 	add	x0, x0, #0x220
    93f8:	97ffea82 	bl	3e00 <fwp_trap>
    93fc:	aa0703f7 	mov	x23, x7
    9400:	17ffff08 	b	9020 <fwp_hof0.constprop.0+0xcc0>
    9404:	aa1a03e0 	mov	x0, x26
    9408:	f90023ea 	str	x10, [sp, #64]
    940c:	f9002be9 	str	x9, [sp, #80]
    9410:	97ffea9c 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9414:	f94023ea 	ldr	x10, [sp, #64]
    9418:	f9402be9 	ldr	x9, [sp, #80]
    941c:	17fffdc7 	b	8b38 <fwp_hof0.constprop.0+0x7d8>
    9420:	90000020 	adrp	x0, d000 <__modti3+0x2c0>
    9424:	9111a000 	add	x0, x0, #0x468
    9428:	97ffea76 	bl	3e00 <fwp_trap>
    942c:	72003c5f 	tst	w2, #0xffff
    9430:	54ffde41 	b.ne	8ff8 <fwp_hof0.constprop.0+0xc98>  // b.any
    9434:	17fffee9 	b	8fd8 <fwp_hof0.constprop.0+0xc78>
    9438:	aa1703e0 	mov	x0, x23
    943c:	97ffea91 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9440:	17fffe9a 	b	8ea8 <fwp_hof0.constprop.0+0xb48>
    9444:	ca404401 	eor	x1, x0, x0, lsr #17
    9448:	9114c2c4 	add	x4, x22, #0x530
    944c:	ca412421 	eor	x1, x1, x1, lsr #9
    9450:	92401c21 	and	x1, x1, #0xff
    9454:	910a2422 	add	x2, x1, #0x289
    9458:	8b010c81 	add	x1, x4, x1, lsl #3
    945c:	8b020c82 	add	x2, x4, x2, lsl #3
    9460:	f94a2421 	ldr	x1, [x1, #5192]
    9464:	b50000a1 	cbnz	x1, 9478 <fwp_hof0.constprop.0+0x1118>
    9468:	17ffffe2 	b	93f0 <fwp_hof0.constprop.0+0x1090>
    946c:	91004022 	add	x2, x1, #0x10
    9470:	f9400821 	ldr	x1, [x1, #16]
    9474:	b4fffbe1 	cbz	x1, 93f0 <fwp_hof0.constprop.0+0x1090>
    9478:	f9400023 	ldr	x3, [x1]
    947c:	eb00007f 	cmp	x3, x0
    9480:	54ffff61 	b.ne	946c <fwp_hof0.constprop.0+0x110c>  // b.any
    9484:	f9400042 	ldr	x2, [x2]
    9488:	f9400441 	ldr	x1, [x2, #8]
    948c:	d1000421 	sub	x1, x1, #0x1
    9490:	f9000441 	str	x1, [x2, #8]
    9494:	f103f83f 	cmp	x1, #0xfe
    9498:	54ffc141 	b.ne	8cc0 <fwp_hof0.constprop.0+0x960>  // b.any
    949c:	39400001 	ldrb	w1, [x0]
    94a0:	7103fc3f 	cmp	w1, #0xff
    94a4:	54004460 	b.eq	9d30 <fwp_hof0.constprop.0+0x19d0>  // b.none
    94a8:	12800021 	mov	w1, #0xfffffffe            	// #-2
    94ac:	39000001 	strb	w1, [x0]
    94b0:	17fffe04 	b	8cc0 <fwp_hof0.constprop.0+0x960>
    94b4:	f10002ff 	cmp	x23, #0x0
    94b8:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    94bc:	54ffdde1 	b.ne	9078 <fwp_hof0.constprop.0+0xd18>  // b.any
    94c0:	f9401fe6 	ldr	x6, [sp, #56]
    94c4:	9100c2b5 	add	x21, x21, #0x30
    94c8:	f9405fe1 	ldr	x1, [sp, #184]
    94cc:	aa0603e0 	mov	x0, x6
    94d0:	f9015aa1 	str	x1, [x21, #688]
    94d4:	97ffea07 	bl	3cf0 <fwp_tape_buffers_release>
    94d8:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    94dc:	f947e863 	ldr	x3, [x3, #4048]
    94e0:	d2800262 	mov	x2, #0x13                  	// #19
    94e4:	d2800021 	mov	x1, #0x1                   	// #1
    94e8:	90000020 	adrp	x0, d000 <__modti3+0x2c0>
    94ec:	9103a000 	add	x0, x0, #0xe8
    94f0:	f9400063 	ldr	x3, [x3]
    94f4:	97ffe503 	bl	2900 <fwrite@plt>
    94f8:	d2800000 	mov	x0, #0x0                   	// #0
    94fc:	97ffe50d 	bl	2930 <fflush@plt>
    9500:	52800cc0 	mov	w0, #0x66                  	// #102
    9504:	97ffe51b 	bl	2970 <_Exit@plt>
    9508:	90000020 	adrp	x0, d000 <__modti3+0x2c0>
    950c:	91186000 	add	x0, x0, #0x618
    9510:	97ffea3c 	bl	3e00 <fwp_trap>
    9514:	aa0403e0 	mov	x0, x4
    9518:	d37df2e2 	lsl	x2, x23, #3
    951c:	52800001 	mov	w1, #0x0                   	// #0
    9520:	f90033e7 	str	x7, [sp, #96]
    9524:	97ffe4ab 	bl	27d0 <memset@plt>
    9528:	aa0003e4 	mov	x4, x0
    952c:	f94033e7 	ldr	x7, [sp, #96]
    9530:	17fffed3 	b	907c <fwp_hof0.constprop.0+0xd1c>
    9534:	90000020 	adrp	x0, d000 <__modti3+0x2c0>
    9538:	9118a000 	add	x0, x0, #0x628
    953c:	97ffea31 	bl	3e00 <fwp_trap>
    9540:	f9400b43 	ldr	x3, [x26, #16]
    9544:	17ffff64 	b	92d4 <fwp_hof0.constprop.0+0xf74>
    9548:	72003c1f 	tst	w0, #0xffff
    954c:	54ffea80 	b.eq	929c <fwp_hof0.constprop.0+0xf3c>  // b.none
    9550:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9554:	eb00005f 	cmp	x2, x0
    9558:	54fffd88 	b.hi	9508 <fwp_hof0.constprop.0+0x11a8>  // b.pmore
    955c:	91000440 	add	x0, x2, #0x1
    9560:	52800021 	mov	w1, #0x1                   	// #1
    9564:	f9002be2 	str	x2, [sp, #80]
    9568:	d37df000 	lsl	x0, x0, #3
    956c:	97ffed9d 	bl	4be0 <fwp_heap_alloc>
    9570:	f9402be2 	ldr	x2, [sp, #80]
    9574:	9114c2c6 	add	x6, x22, #0x530
    9578:	f9000002 	str	x2, [x0]
    957c:	aa0003f7 	mov	x23, x0
    9580:	f949d8c1 	ldr	x1, [x6, #5040]
    9584:	f949ecc0 	ldr	x0, [x6, #5080]
    9588:	cb0102e1 	sub	x1, x23, x1
    958c:	eb00403f 	cmp	x1, x0, lsl #16
    9590:	54000322 	b.cs	95f4 <fwp_hof0.constprop.0+0x1294>  // b.hs, b.nlast
    9594:	d350fc24 	lsr	x4, x1, #16
    9598:	d2800500 	mov	x0, #0x28                  	// #40
    959c:	f949fcc7 	ldr	x7, [x6, #5112]
    95a0:	9b007c84 	mul	x4, x4, x0
    95a4:	8b0400e6 	add	x6, x7, x4
    95a8:	f94010c0 	ldr	x0, [x6, #32]
    95ac:	b4000240 	cbz	x0, 95f4 <fwp_hof0.constprop.0+0x1294>
    95b0:	386468e4 	ldrb	w4, [x7, x4]
    95b4:	7100089f 	cmp	w4, #0x2
    95b8:	54003b40 	b.eq	9d20 <fwp_hof0.constprop.0+0x19c0>  // b.none
    95bc:	7100049f 	cmp	w4, #0x1
    95c0:	540001a1 	b.ne	95f4 <fwp_hof0.constprop.0+0x1294>  // b.any
    95c4:	294310c7 	ldp	w7, w4, [x6, #24]
    95c8:	92403c21 	and	x1, x1, #0xffff
    95cc:	9b077c21 	mul	x1, x1, x7
    95d0:	d360fc21 	lsr	x1, x1, #32
    95d4:	eb04003f 	cmp	x1, x4
    95d8:	540000e2 	b.cs	95f4 <fwp_hof0.constprop.0+0x1294>  // b.hs, b.nlast
    95dc:	8b010000 	add	x0, x0, x1
    95e0:	39400001 	ldrb	w1, [x0]
    95e4:	7103fc3f 	cmp	w1, #0xff
    95e8:	54003900 	b.eq	9d08 <fwp_hof0.constprop.0+0x19a8>  // b.none
    95ec:	52800021 	mov	w1, #0x1                   	// #1
    95f0:	39000001 	strb	w1, [x0]
    95f4:	aa1a03e0 	mov	x0, x26
    95f8:	17ffff2e 	b	92b0 <fwp_hof0.constprop.0+0xf50>
    95fc:	72003c1f 	tst	w0, #0xffff
    9600:	54ffec00 	b.eq	9380 <fwp_hof0.constprop.0+0x1020>  // b.none
    9604:	b40036f9 	cbz	x25, 9ce0 <fwp_hof0.constprop.0+0x1980>
    9608:	aa1903e1 	mov	x1, x25
    960c:	d280001a 	mov	x26, #0x0                   	// #0
    9610:	f9400821 	ldr	x1, [x1, #16]
    9614:	aa1a03e0 	mov	x0, x26
    9618:	9100075a 	add	x26, x26, #0x1
    961c:	b5ffffa1 	cbnz	x1, 9610 <fwp_hof0.constprop.0+0x12b0>
    9620:	f9002be2 	str	x2, [sp, #80]
    9624:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9628:	eb01035f 	cmp	x26, x1
    962c:	54ff90c8 	b.hi	8844 <fwp_hof0.constprop.0+0x4e4>  // b.pmore
    9630:	91000800 	add	x0, x0, #0x2
    9634:	52800041 	mov	w1, #0x2                   	// #2
    9638:	d37df000 	lsl	x0, x0, #3
    963c:	97ffed69 	bl	4be0 <fwp_heap_alloc>
    9640:	f9402be2 	ldr	x2, [sp, #80]
    9644:	aa1903e4 	mov	x4, x25
    9648:	aa0003e1 	mov	x1, x0
    964c:	f9400483 	ldr	x3, [x4, #8]
    9650:	f8008403 	str	x3, [x0], #8
    9654:	f9400884 	ldr	x4, [x4, #16]
    9658:	b5ffffa4 	cbnz	x4, 964c <fwp_hof0.constprop.0+0x12ec>
    965c:	52800009 	mov	w9, #0x0                   	// #0
    9660:	17ffff4c 	b	9390 <fwp_hof0.constprop.0+0x1030>
    9664:	b40034f9 	cbz	x25, 9d00 <fwp_hof0.constprop.0+0x19a0>
    9668:	9114c2c0 	add	x0, x22, #0x530
    966c:	aa1903e8 	mov	x8, x25
    9670:	d2800007 	mov	x7, #0x0                   	// #0
    9674:	f949ec0a 	ldr	x10, [x0, #5080]
    9678:	f949d80c 	ldr	x12, [x0, #5040]
    967c:	f949fc0d 	ldr	x13, [x0, #5112]
    9680:	d370bd4a 	lsl	x10, x10, #16
    9684:	14000006 	b	969c <fwp_hof0.constprop.0+0x133c>
    9688:	f9400908 	ldr	x8, [x8, #16]
    968c:	910004e7 	add	x7, x7, #0x1
    9690:	f100011f 	cmp	x8, #0x0
    9694:	fa471040 	ccmp	x2, x7, #0x0, ne	// ne = any
    9698:	54000329 	b.ls	96fc <fwp_hof0.constprop.0+0x139c>  // b.plast
    969c:	cb0c0100 	sub	x0, x8, x12
    96a0:	eb0a001f 	cmp	x0, x10
    96a4:	540002c2 	b.cs	96fc <fwp_hof0.constprop.0+0x139c>  // b.hs, b.nlast
    96a8:	d350fc03 	lsr	x3, x0, #16
    96ac:	8b030863 	add	x3, x3, x3, lsl #2
    96b0:	d37df063 	lsl	x3, x3, #3
    96b4:	8b0301a5 	add	x5, x13, x3
    96b8:	f94010a4 	ldr	x4, [x5, #32]
    96bc:	b4000204 	cbz	x4, 96fc <fwp_hof0.constprop.0+0x139c>
    96c0:	386369a3 	ldrb	w3, [x13, x3]
    96c4:	7100087f 	cmp	w3, #0x2
    96c8:	54002580 	b.eq	9b78 <fwp_hof0.constprop.0+0x1818>  // b.none
    96cc:	7100047f 	cmp	w3, #0x1
    96d0:	54000161 	b.ne	96fc <fwp_hof0.constprop.0+0x139c>  // b.any
    96d4:	29430ca6 	ldp	w6, w3, [x5, #24]
    96d8:	92403c00 	and	x0, x0, #0xffff
    96dc:	9b067c00 	mul	x0, x0, x6
    96e0:	d360fc00 	lsr	x0, x0, #32
    96e4:	eb03001f 	cmp	x0, x3
    96e8:	540000a2 	b.cs	96fc <fwp_hof0.constprop.0+0x139c>  // b.hs, b.nlast
    96ec:	8b000084 	add	x4, x4, x0
    96f0:	39400080 	ldrb	w0, [x4]
    96f4:	7100041f 	cmp	w0, #0x1
    96f8:	54fffc80 	b.eq	9688 <fwp_hof0.constprop.0+0x1328>  // b.none
    96fc:	d2800004 	mov	x4, #0x0                   	// #0
    9700:	eb07005f 	cmp	x2, x7
    9704:	54002cc9 	b.ls	9c9c <fwp_hof0.constprop.0+0x193c>  // b.plast
    9708:	d1002020 	sub	x0, x1, #0x8
    970c:	9114c2da 	add	x26, x22, #0x530
    9710:	f90023e0 	str	x0, [sp, #64]
    9714:	9103e3e0 	add	x0, sp, #0xf8
    9718:	f9002be0 	str	x0, [sp, #80]
    971c:	aa1a03e0 	mov	x0, x26
    9720:	d2800004 	mov	x4, #0x0                   	// #0
    9724:	aa1403fa 	mov	x26, x20
    9728:	aa0003f4 	mov	x20, x0
    972c:	a90587f9 	stp	x25, x1, [sp, #88]
    9730:	aa0703f9 	mov	x25, x7
    9734:	b9006be9 	str	w9, [sp, #104]
    9738:	a9074fe2 	stp	x2, x19, [sp, #112]
    973c:	aa0203f3 	mov	x19, x2
    9740:	14000012 	b	9788 <fwp_hof0.constprop.0+0x1428>
    9744:	7100045f 	cmp	w2, #0x1
    9748:	540001a1 	b.ne	977c <fwp_hof0.constprop.0+0x141c>  // b.any
    974c:	29430866 	ldp	w6, w2, [x3, #24]
    9750:	92403c21 	and	x1, x1, #0xffff
    9754:	9b067c21 	mul	x1, x1, x6
    9758:	d360fc21 	lsr	x1, x1, #32
    975c:	eb02003f 	cmp	x1, x2
    9760:	540000e2 	b.cs	977c <fwp_hof0.constprop.0+0x141c>  // b.hs, b.nlast
    9764:	8b010000 	add	x0, x0, x1
    9768:	39400001 	ldrb	w1, [x0]
    976c:	7103fc3f 	cmp	w1, #0xff
    9770:	54002b00 	b.eq	9cd0 <fwp_hof0.constprop.0+0x1970>  // b.none
    9774:	52800021 	mov	w1, #0x1                   	// #1
    9778:	39000001 	strb	w1, [x0]
    977c:	d1000673 	sub	x19, x19, #0x1
    9780:	eb19027f 	cmp	x19, x25
    9784:	54000349 	b.ls	97ec <fwp_hof0.constprop.0+0x148c>  // b.plast
    9788:	f94023e0 	ldr	x0, [sp, #64]
    978c:	f9402be1 	ldr	x1, [sp, #80]
    9790:	f8737800 	ldr	x0, [x0, x19, lsl #3]
    9794:	a90f93e0 	stp	x0, x4, [sp, #248]
    9798:	52800020 	mov	w0, #0x1                   	// #1
    979c:	97ffed56 	bl	4cf4 <fwp_data.part.0.constprop.0>
    97a0:	aa0003e4 	mov	x4, x0
    97a4:	f949da81 	ldr	x1, [x20, #5040]
    97a8:	f949ee80 	ldr	x0, [x20, #5080]
    97ac:	cb010081 	sub	x1, x4, x1
    97b0:	eb00403f 	cmp	x1, x0, lsl #16
    97b4:	54fffe42 	b.cs	977c <fwp_hof0.constprop.0+0x141c>  // b.hs, b.nlast
    97b8:	d350fc20 	lsr	x0, x1, #16
    97bc:	f949fe86 	ldr	x6, [x20, #5112]
    97c0:	8b000800 	add	x0, x0, x0, lsl #2
    97c4:	d37df002 	lsl	x2, x0, #3
    97c8:	8b0200c3 	add	x3, x6, x2
    97cc:	f9401060 	ldr	x0, [x3, #32]
    97d0:	b4fffd60 	cbz	x0, 977c <fwp_hof0.constprop.0+0x141c>
    97d4:	386268c2 	ldrb	w2, [x6, x2]
    97d8:	7100085f 	cmp	w2, #0x2
    97dc:	54fffb41 	b.ne	9744 <fwp_hof0.constprop.0+0x13e4>  // b.any
    97e0:	72003c3f 	tst	w1, #0xffff
    97e4:	54fffcc1 	b.ne	977c <fwp_hof0.constprop.0+0x141c>  // b.any
    97e8:	17ffffe0 	b	9768 <fwp_hof0.constprop.0+0x1408>
    97ec:	a9474fe2 	ldp	x2, x19, [sp, #112]
    97f0:	aa1903e7 	mov	x7, x25
    97f4:	a94587f9 	ldp	x25, x1, [sp, #88]
    97f8:	aa1a03f4 	mov	x20, x26
    97fc:	b9406be9 	ldr	w9, [sp, #104]
    9800:	d1000446 	sub	x6, x2, #0x1
    9804:	cb0200e0 	sub	x0, x7, x2
    9808:	eb0700df 	cmp	x6, x7
    980c:	9a8037e0 	csinc	x0, xzr, x0, cc	// cc = lo, ul, last
    9810:	8b060000 	add	x0, x0, x6
    9814:	b5002447 	cbnz	x7, 9c9c <fwp_hof0.constprop.0+0x193c>
    9818:	7100013f 	cmp	w9, #0x0
    981c:	9a8113e8 	csel	x8, xzr, x1, ne	// ne = any
    9820:	b40022e0 	cbz	x0, 9c7c <fwp_hof0.constprop.0+0x191c>
    9824:	d1000406 	sub	x6, x0, #0x1
    9828:	9114c2da 	add	x26, x22, #0x530
    982c:	f90023f7 	str	x23, [sp, #64]
    9830:	aa1a03f7 	mov	x23, x26
    9834:	a905d3f3 	stp	x19, x20, [sp, #88]
    9838:	aa0803f3 	mov	x19, x8
    983c:	aa0603f4 	mov	x20, x6
    9840:	14000012 	b	9888 <fwp_hof0.constprop.0+0x1528>
    9844:	7100045f 	cmp	w2, #0x1
    9848:	540001a1 	b.ne	987c <fwp_hof0.constprop.0+0x151c>  // b.any
    984c:	29430002 	ldp	w2, w0, [x0, #24]
    9850:	92403c21 	and	x1, x1, #0xffff
    9854:	9b027c21 	mul	x1, x1, x2
    9858:	d360fc21 	lsr	x1, x1, #32
    985c:	eb00003f 	cmp	x1, x0
    9860:	540000e2 	b.cs	987c <fwp_hof0.constprop.0+0x151c>  // b.hs, b.nlast
    9864:	8b01035a 	add	x26, x26, x1
    9868:	39400340 	ldrb	w0, [x26]
    986c:	7103fc1f 	cmp	w0, #0xff
    9870:	540020c0 	b.eq	9c88 <fwp_hof0.constprop.0+0x1928>  // b.none
    9874:	52800020 	mov	w0, #0x1                   	// #1
    9878:	39000340 	strb	w0, [x26]
    987c:	d1000694 	sub	x20, x20, #0x1
    9880:	b100069f 	cmn	x20, #0x1
    9884:	54000320 	b.eq	98e8 <fwp_hof0.constprop.0+0x1588>  // b.none
    9888:	f9402be1 	ldr	x1, [sp, #80]
    988c:	f8747a60 	ldr	x0, [x19, x20, lsl #3]
    9890:	a90f93e0 	stp	x0, x4, [sp, #248]
    9894:	52800020 	mov	w0, #0x1                   	// #1
    9898:	97ffed17 	bl	4cf4 <fwp_data.part.0.constprop.0>
    989c:	aa0003e4 	mov	x4, x0
    98a0:	f949dae1 	ldr	x1, [x23, #5040]
    98a4:	f949eee0 	ldr	x0, [x23, #5080]
    98a8:	cb010081 	sub	x1, x4, x1
    98ac:	eb00403f 	cmp	x1, x0, lsl #16
    98b0:	54fffe62 	b.cs	987c <fwp_hof0.constprop.0+0x151c>  // b.hs, b.nlast
    98b4:	d350fc20 	lsr	x0, x1, #16
    98b8:	f949fee5 	ldr	x5, [x23, #5112]
    98bc:	8b000800 	add	x0, x0, x0, lsl #2
    98c0:	d37df002 	lsl	x2, x0, #3
    98c4:	8b0200a0 	add	x0, x5, x2
    98c8:	f940101a 	ldr	x26, [x0, #32]
    98cc:	b4fffd9a 	cbz	x26, 987c <fwp_hof0.constprop.0+0x151c>
    98d0:	386268a2 	ldrb	w2, [x5, x2]
    98d4:	7100085f 	cmp	w2, #0x2
    98d8:	54fffb61 	b.ne	9844 <fwp_hof0.constprop.0+0x14e4>  // b.any
    98dc:	72003c3f 	tst	w1, #0xffff
    98e0:	54fffce1 	b.ne	987c <fwp_hof0.constprop.0+0x151c>  // b.any
    98e4:	17ffffe1 	b	9868 <fwp_hof0.constprop.0+0x1508>
    98e8:	aa1303e8 	mov	x8, x19
    98ec:	aa1903fa 	mov	x26, x25
    98f0:	a945d3f3 	ldp	x19, x20, [sp, #88]
    98f4:	aa0403f9 	mov	x25, x4
    98f8:	f94023f7 	ldr	x23, [sp, #64]
    98fc:	aa0803e0 	mov	x0, x8
    9900:	97ffe9fc 	bl	40f0 <fwp_mem_free>
    9904:	f9002bf4 	str	x20, [sp, #80]
    9908:	9114c2c6 	add	x6, x22, #0x530
    990c:	aa1303f4 	mov	x20, x19
    9910:	aa0603f3 	mov	x19, x6
    9914:	d2800507 	mov	x7, #0x28                  	// #40
    9918:	f949da61 	ldr	x1, [x19, #5040]
    991c:	f949ee60 	ldr	x0, [x19, #5080]
    9920:	cb0102e1 	sub	x1, x23, x1
    9924:	eb00403f 	cmp	x1, x0, lsl #16
    9928:	54001222 	b.cs	9b6c <fwp_hof0.constprop.0+0x180c>  // b.hs, b.nlast
    992c:	d350fc22 	lsr	x2, x1, #16
    9930:	f949fe63 	ldr	x3, [x19, #5112]
    9934:	9b077c42 	mul	x2, x2, x7
    9938:	8b020068 	add	x8, x3, x2
    993c:	f9401100 	ldr	x0, [x8, #32]
    9940:	b4001160 	cbz	x0, 9b6c <fwp_hof0.constprop.0+0x180c>
    9944:	38626864 	ldrb	w4, [x3, x2]
    9948:	7100089f 	cmp	w4, #0x2
    994c:	540010c0 	b.eq	9b64 <fwp_hof0.constprop.0+0x1804>  // b.none
    9950:	7100049f 	cmp	w4, #0x1
    9954:	540010c1 	b.ne	9b6c <fwp_hof0.constprop.0+0x180c>  // b.any
    9958:	29430d02 	ldp	w2, w3, [x8, #24]
    995c:	92403c21 	and	x1, x1, #0xffff
    9960:	9b027c22 	mul	x2, x1, x2
    9964:	d360fc42 	lsr	x2, x2, #32
    9968:	eb03005f 	cmp	x2, x3
    996c:	54001002 	b.cs	9b6c <fwp_hof0.constprop.0+0x180c>  // b.hs, b.nlast
    9970:	8b020000 	add	x0, x0, x2
    9974:	39400002 	ldrb	w2, [x0]
    9978:	34000fa2 	cbz	w2, 9b6c <fwp_hof0.constprop.0+0x180c>
    997c:	7100045f 	cmp	w2, #0x1
    9980:	54000d60 	b.eq	9b2c <fwp_hof0.constprop.0+0x17cc>  // b.none
    9984:	aa1403f3 	mov	x19, x20
    9988:	f9402bf4 	ldr	x20, [sp, #80]
    998c:	7103fc5f 	cmp	w2, #0xff
    9990:	54001e20 	b.eq	9d54 <fwp_hof0.constprop.0+0x19f4>  // b.none
    9994:	51000442 	sub	w2, w2, #0x1
    9998:	39000002 	strb	w2, [x0]
    999c:	9114c2c6 	add	x6, x22, #0x530
    99a0:	f9002bf4 	str	x20, [sp, #80]
    99a4:	aa1303f4 	mov	x20, x19
    99a8:	aa0603f3 	mov	x19, x6
    99ac:	d2800507 	mov	x7, #0x28                  	// #40
    99b0:	f949da60 	ldr	x0, [x19, #5040]
    99b4:	f949ee61 	ldr	x1, [x19, #5080]
    99b8:	cb000340 	sub	x0, x26, x0
    99bc:	eb01401f 	cmp	x0, x1, lsl #16
    99c0:	54000b02 	b.cs	9b20 <fwp_hof0.constprop.0+0x17c0>  // b.hs, b.nlast
    99c4:	d350fc01 	lsr	x1, x0, #16
    99c8:	f949fe62 	ldr	x2, [x19, #5112]
    99cc:	9b077c21 	mul	x1, x1, x7
    99d0:	8b010043 	add	x3, x2, x1
    99d4:	f9401077 	ldr	x23, [x3, #32]
    99d8:	b4000a57 	cbz	x23, 9b20 <fwp_hof0.constprop.0+0x17c0>
    99dc:	38616844 	ldrb	w4, [x2, x1]
    99e0:	7100089f 	cmp	w4, #0x2
    99e4:	540009a0 	b.eq	9b18 <fwp_hof0.constprop.0+0x17b8>  // b.none
    99e8:	7100049f 	cmp	w4, #0x1
    99ec:	540009a1 	b.ne	9b20 <fwp_hof0.constprop.0+0x17c0>  // b.any
    99f0:	29430861 	ldp	w1, w2, [x3, #24]
    99f4:	92403c00 	and	x0, x0, #0xffff
    99f8:	9b017c01 	mul	x1, x0, x1
    99fc:	d360fc21 	lsr	x1, x1, #32
    9a00:	eb02003f 	cmp	x1, x2
    9a04:	540008e2 	b.cs	9b20 <fwp_hof0.constprop.0+0x17c0>  // b.hs, b.nlast
    9a08:	8b0102f7 	add	x23, x23, x1
    9a0c:	394002e2 	ldrb	w2, [x23]
    9a10:	34000882 	cbz	w2, 9b20 <fwp_hof0.constprop.0+0x17c0>
    9a14:	7100045f 	cmp	w2, #0x1
    9a18:	54000f20 	b.eq	9bfc <fwp_hof0.constprop.0+0x189c>  // b.none
    9a1c:	aa1403f3 	mov	x19, x20
    9a20:	f9402bf4 	ldr	x20, [sp, #80]
    9a24:	7103fc5f 	cmp	w2, #0xff
    9a28:	54000cc0 	b.eq	9bc0 <fwp_hof0.constprop.0+0x1860>  // b.none
    9a2c:	51000442 	sub	w2, w2, #0x1
    9a30:	390002e2 	strb	w2, [x23]
    9a34:	f9400fe0 	ldr	x0, [sp, #24]
    9a38:	b4ff7120 	cbz	x0, 885c <fwp_hof0.constprop.0+0x4fc>
    9a3c:	f9400fe0 	ldr	x0, [sp, #24]
    9a40:	f1000400 	subs	x0, x0, #0x1
    9a44:	f9000fe0 	str	x0, [sp, #24]
    9a48:	54001ea6 	b.vs	9e1c <fwp_hof0.constprop.0+0x1abc>
    9a4c:	9114c2c0 	add	x0, x22, #0x530
    9a50:	f949ec04 	ldr	x4, [x0, #5080]
    9a54:	f949d801 	ldr	x1, [x0, #5040]
    9a58:	d370bc84 	lsl	x4, x4, #16
    9a5c:	17fffa89 	b	8480 <fwp_hof0.constprop.0+0x120>
    9a60:	90000020 	adrp	x0, d000 <__modti3+0x2c0>
    9a64:	91194000 	add	x0, x0, #0x650
    9a68:	97ffe8e6 	bl	3e00 <fwp_trap>
    9a6c:	aa1a03e0 	mov	x0, x26
    9a70:	97ffef94 	bl	58c0 <fwp_rc_free_arr>
    9a74:	17fffbef 	b	8a30 <fwp_hof0.constprop.0+0x6d0>
    9a78:	72003c3f 	tst	w1, #0xffff
    9a7c:	54ff7da1 	b.ne	8a30 <fwp_hof0.constprop.0+0x6d0>  // b.any
    9a80:	17fffbe4 	b	8a10 <fwp_hof0.constprop.0+0x6b0>
    9a84:	72003c3f 	tst	w1, #0xffff
    9a88:	54ff7781 	b.ne	8978 <fwp_hof0.constprop.0+0x618>  // b.any
    9a8c:	17fffbb6 	b	8964 <fwp_hof0.constprop.0+0x604>
    9a90:	f9000fe0 	str	x0, [sp, #24]
    9a94:	f90017e3 	str	x3, [sp, #40]
    9a98:	97ffe8fa 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9a9c:	f9400fe0 	ldr	x0, [sp, #24]
    9aa0:	f94017e3 	ldr	x3, [sp, #40]
    9aa4:	17fffbb3 	b	8970 <fwp_hof0.constprop.0+0x610>
    9aa8:	ca544681 	eor	x1, x20, x20, lsr #17
    9aac:	9114c2c2 	add	x2, x22, #0x530
    9ab0:	ca412421 	eor	x1, x1, x1, lsr #9
    9ab4:	92401c21 	and	x1, x1, #0xff
    9ab8:	910a2420 	add	x0, x1, #0x289
    9abc:	8b010c41 	add	x1, x2, x1, lsl #3
    9ac0:	8b000c40 	add	x0, x2, x0, lsl #3
    9ac4:	f94a2421 	ldr	x1, [x1, #5192]
    9ac8:	b50000a1 	cbnz	x1, 9adc <fwp_hof0.constprop.0+0x177c>
    9acc:	17fffe49 	b	93f0 <fwp_hof0.constprop.0+0x1090>
    9ad0:	91004020 	add	x0, x1, #0x10
    9ad4:	f9400821 	ldr	x1, [x1, #16]
    9ad8:	b4ffc8c1 	cbz	x1, 93f0 <fwp_hof0.constprop.0+0x1090>
    9adc:	f9400022 	ldr	x2, [x1]
    9ae0:	eb02029f 	cmp	x20, x2
    9ae4:	54ffff61 	b.ne	9ad0 <fwp_hof0.constprop.0+0x1770>  // b.any
    9ae8:	f9400001 	ldr	x1, [x0]
    9aec:	f9400420 	ldr	x0, [x1, #8]
    9af0:	d1000400 	sub	x0, x0, #0x1
    9af4:	f9000420 	str	x0, [x1, #8]
    9af8:	f103f81f 	cmp	x0, #0xfe
    9afc:	54ff79a1 	b.ne	8a30 <fwp_hof0.constprop.0+0x6d0>  // b.any
    9b00:	39400280 	ldrb	w0, [x20]
    9b04:	7103fc1f 	cmp	w0, #0xff
    9b08:	54000ae0 	b.eq	9c64 <fwp_hof0.constprop.0+0x1904>  // b.none
    9b0c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9b10:	39000280 	strb	w0, [x20]
    9b14:	17fffbc7 	b	8a30 <fwp_hof0.constprop.0+0x6d0>
    9b18:	f2403c00 	ands	x0, x0, #0xffff
    9b1c:	54fff780 	b.eq	9a0c <fwp_hof0.constprop.0+0x16ac>  // b.none
    9b20:	aa1403f3 	mov	x19, x20
    9b24:	f9402bf4 	ldr	x20, [sp, #80]
    9b28:	17ffffc3 	b	9a34 <fwp_hof0.constprop.0+0x16d4>
    9b2c:	f94002e2 	ldr	x2, [x23]
    9b30:	aa1703e0 	mov	x0, x23
    9b34:	b7f813c2 	tbnz	x2, #63, 9dac <fwp_hof0.constprop.0+0x1a4c>
    9b38:	aa1403f3 	mov	x19, x20
    9b3c:	f9402bf4 	ldr	x20, [sp, #80]
    9b40:	7100089f 	cmp	w4, #0x2
    9b44:	54001300 	b.eq	9da4 <fwp_hof0.constprop.0+0x1a44>  // b.none
    9b48:	29430102 	ldp	w2, w0, [x8, #24]
    9b4c:	9b027c21 	mul	x1, x1, x2
    9b50:	eb41801f 	cmp	x0, x1, lsr #32
    9b54:	54fff249 	b.ls	999c <fwp_hof0.constprop.0+0x163c>  // b.plast
    9b58:	aa1703e0 	mov	x0, x23
    9b5c:	97ffe965 	bl	40f0 <fwp_mem_free>
    9b60:	17ffff8f 	b	999c <fwp_hof0.constprop.0+0x163c>
    9b64:	f2403c21 	ands	x1, x1, #0xffff
    9b68:	54fff060 	b.eq	9974 <fwp_hof0.constprop.0+0x1614>  // b.none
    9b6c:	aa1403f3 	mov	x19, x20
    9b70:	f9402bf4 	ldr	x20, [sp, #80]
    9b74:	17ffff8a 	b	999c <fwp_hof0.constprop.0+0x163c>
    9b78:	72003c1f 	tst	w0, #0xffff
    9b7c:	54ffdc01 	b.ne	96fc <fwp_hof0.constprop.0+0x139c>  // b.any
    9b80:	17fffedc 	b	96f0 <fwp_hof0.constprop.0+0x1390>
    9b84:	aa0203e0 	mov	x0, x2
    9b88:	d2800101 	mov	x1, #0x8                   	// #8
    9b8c:	f90033e2 	str	x2, [sp, #96]
    9b90:	97ffe314 	bl	27e0 <calloc@plt>
    9b94:	a9461fe2 	ldp	x2, x7, [sp, #96]
    9b98:	aa0003e4 	mov	x4, x0
    9b9c:	17fffd34 	b	906c <fwp_hof0.constprop.0+0xd0c>
    9ba0:	72003c3f 	tst	w1, #0xffff
    9ba4:	54ffb341 	b.ne	920c <fwp_hof0.constprop.0+0xeac>  // b.any
    9ba8:	17fffd94 	b	91f8 <fwp_hof0.constprop.0+0xe98>
    9bac:	aa1703e0 	mov	x0, x23
    9bb0:	97ffe8b4 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9bb4:	9100c2a0 	add	x0, x21, #0x30
    9bb8:	f9415806 	ldr	x6, [x0, #688]
    9bbc:	17fffd92 	b	9204 <fwp_hof0.constprop.0+0xea4>
    9bc0:	ca5746e1 	eor	x1, x23, x23, lsr #17
    9bc4:	9114c2c0 	add	x0, x22, #0x530
    9bc8:	ca412421 	eor	x1, x1, x1, lsr #9
    9bcc:	92401c21 	and	x1, x1, #0xff
    9bd0:	910a2422 	add	x2, x1, #0x289
    9bd4:	8b010c01 	add	x1, x0, x1, lsl #3
    9bd8:	8b020c02 	add	x2, x0, x2, lsl #3
    9bdc:	f94a2420 	ldr	x0, [x1, #5192]
    9be0:	b4ffc080 	cbz	x0, 93f0 <fwp_hof0.constprop.0+0x1090>
    9be4:	f9400001 	ldr	x1, [x0]
    9be8:	eb0102ff 	cmp	x23, x1
    9bec:	54000240 	b.eq	9c34 <fwp_hof0.constprop.0+0x18d4>  // b.none
    9bf0:	91004002 	add	x2, x0, #0x10
    9bf4:	f9400800 	ldr	x0, [x0, #16]
    9bf8:	17fffffa 	b	9be0 <fwp_hof0.constprop.0+0x1880>
    9bfc:	aa1a03e1 	mov	x1, x26
    9c00:	f9400b5a 	ldr	x26, [x26, #16]
    9c04:	7100089f 	cmp	w4, #0x2
    9c08:	54000120 	b.eq	9c2c <fwp_hof0.constprop.0+0x18cc>  // b.none
    9c0c:	29430864 	ldp	w4, w2, [x3, #24]
    9c10:	9b047c00 	mul	x0, x0, x4
    9c14:	eb40805f 	cmp	x2, x0, lsr #32
    9c18:	54ffecc9 	b.ls	99b0 <fwp_hof0.constprop.0+0x1650>  // b.plast
    9c1c:	aa0103e0 	mov	x0, x1
    9c20:	97ffe934 	bl	40f0 <fwp_mem_free>
    9c24:	d2800507 	mov	x7, #0x28                  	// #40
    9c28:	17ffff62 	b	99b0 <fwp_hof0.constprop.0+0x1650>
    9c2c:	b5ffec20 	cbnz	x0, 99b0 <fwp_hof0.constprop.0+0x1650>
    9c30:	17fffffb 	b	9c1c <fwp_hof0.constprop.0+0x18bc>
    9c34:	f9400041 	ldr	x1, [x2]
    9c38:	f9400420 	ldr	x0, [x1, #8]
    9c3c:	d1000400 	sub	x0, x0, #0x1
    9c40:	f9000420 	str	x0, [x1, #8]
    9c44:	f103f81f 	cmp	x0, #0xfe
    9c48:	54ffef61 	b.ne	9a34 <fwp_hof0.constprop.0+0x16d4>  // b.any
    9c4c:	394002e0 	ldrb	w0, [x23]
    9c50:	7103fc1f 	cmp	w0, #0xff
    9c54:	540000e0 	b.eq	9c70 <fwp_hof0.constprop.0+0x1910>  // b.none
    9c58:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9c5c:	390002e0 	strb	w0, [x23]
    9c60:	17ffff75 	b	9a34 <fwp_hof0.constprop.0+0x16d4>
    9c64:	aa1403e0 	mov	x0, x20
    9c68:	97ffe886 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9c6c:	17ffffa8 	b	9b0c <fwp_hof0.constprop.0+0x17ac>
    9c70:	aa1703e0 	mov	x0, x23
    9c74:	97ffe883 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9c78:	17fffff8 	b	9c58 <fwp_hof0.constprop.0+0x18f8>
    9c7c:	aa1903fa 	mov	x26, x25
    9c80:	aa0403f9 	mov	x25, x4
    9c84:	17ffff1e 	b	98fc <fwp_hof0.constprop.0+0x159c>
    9c88:	aa1a03e0 	mov	x0, x26
    9c8c:	f90037e4 	str	x4, [sp, #104]
    9c90:	97ffe87c 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9c94:	f94037e4 	ldr	x4, [sp, #104]
    9c98:	17fffef7 	b	9874 <fwp_hof0.constprop.0+0x1514>
    9c9c:	aa1903fa 	mov	x26, x25
    9ca0:	d2800000 	mov	x0, #0x0                   	// #0
    9ca4:	f8607822 	ldr	x2, [x1, x0, lsl #3]
    9ca8:	91000400 	add	x0, x0, #0x1
    9cac:	f9000742 	str	x2, [x26, #8]
    9cb0:	aa1a03e2 	mov	x2, x26
    9cb4:	f9400b5a 	ldr	x26, [x26, #16]
    9cb8:	eb0000ff 	cmp	x7, x0
    9cbc:	54ffff48 	b.hi	9ca4 <fwp_hof0.constprop.0+0x1944>  // b.pmore
    9cc0:	f9000844 	str	x4, [x2, #16]
    9cc4:	7100013f 	cmp	w9, #0x0
    9cc8:	9a8113e8 	csel	x8, xzr, x1, ne	// ne = any
    9ccc:	17ffff0c 	b	98fc <fwp_hof0.constprop.0+0x159c>
    9cd0:	a90813e0 	stp	x0, x4, [sp, #128]
    9cd4:	97ffe86b 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9cd8:	a94813e0 	ldp	x0, x4, [sp, #128]
    9cdc:	17fffea6 	b	9774 <fwp_hof0.constprop.0+0x1414>
    9ce0:	52800041 	mov	w1, #0x2                   	// #2
    9ce4:	d2800100 	mov	x0, #0x8                   	// #8
    9ce8:	97ffebbe 	bl	4be0 <fwp_heap_alloc>
    9cec:	aa0003e1 	mov	x1, x0
    9cf0:	52800009 	mov	w9, #0x0                   	// #0
    9cf4:	aa1903fa 	mov	x26, x25
    9cf8:	d2800019 	mov	x25, #0x0                   	// #0
    9cfc:	17fffff2 	b	9cc4 <fwp_hof0.constprop.0+0x1964>
    9d00:	d2800007 	mov	x7, #0x0                   	// #0
    9d04:	17fffe81 	b	9708 <fwp_hof0.constprop.0+0x13a8>
    9d08:	f90023e2 	str	x2, [sp, #64]
    9d0c:	f9002be0 	str	x0, [sp, #80]
    9d10:	97ffe85c 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9d14:	f94023e2 	ldr	x2, [sp, #64]
    9d18:	f9402be0 	ldr	x0, [sp, #80]
    9d1c:	17fffe34 	b	95ec <fwp_hof0.constprop.0+0x128c>
    9d20:	72003c3f 	tst	w1, #0xffff
    9d24:	54ffc5e0 	b.eq	95e0 <fwp_hof0.constprop.0+0x1280>  // b.none
    9d28:	aa1a03e0 	mov	x0, x26
    9d2c:	17fffd61 	b	92b0 <fwp_hof0.constprop.0+0xf50>
    9d30:	f90023e0 	str	x0, [sp, #64]
    9d34:	97ffe853 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9d38:	f94023e0 	ldr	x0, [sp, #64]
    9d3c:	17fffddb 	b	94a8 <fwp_hof0.constprop.0+0x1148>
    9d40:	a91253f3 	stp	x19, x20, [sp, #288]
    9d44:	a9135bf5 	stp	x21, x22, [sp, #304]
    9d48:	a91463f7 	stp	x23, x24, [sp, #320]
    9d4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    9d50:	97ffe2ac 	bl	2800 <__stack_chk_fail@plt>
    9d54:	ca404401 	eor	x1, x0, x0, lsr #17
    9d58:	9114c2c4 	add	x4, x22, #0x530
    9d5c:	ca412421 	eor	x1, x1, x1, lsr #9
    9d60:	92401c21 	and	x1, x1, #0xff
    9d64:	910a2422 	add	x2, x1, #0x289
    9d68:	8b010c81 	add	x1, x4, x1, lsl #3
    9d6c:	8b020c82 	add	x2, x4, x2, lsl #3
    9d70:	f94a2421 	ldr	x1, [x1, #5192]
    9d74:	b4ffb3e1 	cbz	x1, 93f0 <fwp_hof0.constprop.0+0x1090>
    9d78:	f9400023 	ldr	x3, [x1]
    9d7c:	eb00007f 	cmp	x3, x0
    9d80:	540002a0 	b.eq	9dd4 <fwp_hof0.constprop.0+0x1a74>  // b.none
    9d84:	91004022 	add	x2, x1, #0x10
    9d88:	f9400821 	ldr	x1, [x1, #16]
    9d8c:	17fffffa 	b	9d74 <fwp_hof0.constprop.0+0x1a14>
    9d90:	f94002e2 	ldr	x2, [x23]
    9d94:	b7fffa62 	tbnz	x2, #63, 9ce0 <fwp_hof0.constprop.0+0x1980>
    9d98:	9240f842 	and	x2, x2, #0x7fffffffffffffff
    9d9c:	d280001a 	mov	x26, #0x0                   	// #0
    9da0:	17fffd5f 	b	931c <fwp_hof0.constprop.0+0xfbc>
    9da4:	b5ffdfc1 	cbnz	x1, 999c <fwp_hof0.constprop.0+0x163c>
    9da8:	17ffff6c 	b	9b58 <fwp_hof0.constprop.0+0x17f8>
    9dac:	f94006f7 	ldr	x23, [x23, #8]
    9db0:	7100089f 	cmp	w4, #0x2
    9db4:	54000280 	b.eq	9e04 <fwp_hof0.constprop.0+0x1aa4>  // b.none
    9db8:	29430903 	ldp	w3, w2, [x8, #24]
    9dbc:	9b037c21 	mul	x1, x1, x3
    9dc0:	eb41805f 	cmp	x2, x1, lsr #32
    9dc4:	54ffdaa9 	b.ls	9918 <fwp_hof0.constprop.0+0x15b8>  // b.plast
    9dc8:	97ffe8ca 	bl	40f0 <fwp_mem_free>
    9dcc:	d2800507 	mov	x7, #0x28                  	// #40
    9dd0:	17fffed2 	b	9918 <fwp_hof0.constprop.0+0x15b8>
    9dd4:	f9400042 	ldr	x2, [x2]
    9dd8:	f9400441 	ldr	x1, [x2, #8]
    9ddc:	d1000421 	sub	x1, x1, #0x1
    9de0:	f9000441 	str	x1, [x2, #8]
    9de4:	f103f83f 	cmp	x1, #0xfe
    9de8:	54ffdda1 	b.ne	999c <fwp_hof0.constprop.0+0x163c>  // b.any
    9dec:	39400001 	ldrb	w1, [x0]
    9df0:	7103fc3f 	cmp	w1, #0xff
    9df4:	540000c0 	b.eq	9e0c <fwp_hof0.constprop.0+0x1aac>  // b.none
    9df8:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9dfc:	39000001 	strb	w1, [x0]
    9e00:	17fffee7 	b	999c <fwp_hof0.constprop.0+0x163c>
    9e04:	b5ffd8a1 	cbnz	x1, 9918 <fwp_hof0.constprop.0+0x15b8>
    9e08:	17fffff0 	b	9dc8 <fwp_hof0.constprop.0+0x1a68>
    9e0c:	f9002be0 	str	x0, [sp, #80]
    9e10:	97ffe81c 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9e14:	f9402be0 	ldr	x0, [sp, #80]
    9e18:	17fffff8 	b	9df8 <fwp_hof0.constprop.0+0x1a98>
    9e1c:	97ffe2f9 	bl	2a00 <fwp_trap_overflow.constprop.0>
    9e20:	97ffe28c 	bl	2850 <abort@plt>

0000000000009e24 <f0>:
    9e24:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9e28:	910003fd 	mov	x29, sp
    9e2c:	a90153f3 	stp	x19, x20, [sp, #16]
    9e30:	a9025bf5 	stp	x21, x22, [sp, #32]
    9e34:	a90363f7 	stp	x23, x24, [sp, #48]
    9e38:	a9046bf9 	stp	x25, x26, [sp, #64]
    9e3c:	a90573fb 	stp	x27, x28, [sp, #80]
    9e40:	d121c3ff 	sub	sp, sp, #0x870
    9e44:	f90203ff 	str	xzr, [sp, #1024]
    9e48:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e4c:	9100c003 	add	x3, x0, #0x30
    9e50:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    9e54:	f947f400 	ldr	x0, [x0, #4072]
    9e58:	90000154 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    9e5c:	f9415865 	ldr	x5, [x3, #688]
    9e60:	f9400001 	ldr	x1, [x0]
    9e64:	f90437e1 	str	x1, [sp, #2152]
    9e68:	d2800001 	mov	x1, #0x0                   	// #0
    9e6c:	9114c299 	add	x25, x20, #0x530
    9e70:	912163f6 	add	x22, sp, #0x858
    9e74:	910063e4 	add	x4, sp, #0x18
    9e78:	9100c3e1 	add	x1, sp, #0x30
    9e7c:	90ffffe0 	adrp	x0, 5000 <w123+0x40>
    9e80:	b0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    9e84:	91360000 	add	x0, x0, #0xd80
    9e88:	913b4042 	add	x2, x2, #0xed0
    9e8c:	d2800013 	mov	x19, #0x0                   	// #0
    9e90:	d280011a 	mov	x26, #0x8                   	// #8
    9e94:	d2800015 	mov	x21, #0x0                   	// #0
    9e98:	52800037 	mov	w23, #0x1                   	// #1
    9e9c:	f90007e4 	str	x4, [sp, #8]
    9ea0:	a9018be5 	stp	x5, x2, [sp, #24]
    9ea4:	a902ffe1 	stp	x1, xzr, [sp, #40]
    9ea8:	a90403ff 	stp	xzr, x0, [sp, #64]
    9eac:	f9015864 	str	x4, [x3, #688]
    9eb0:	f100075b 	subs	x27, x26, #0x1
    9eb4:	aa1603e1 	mov	x1, x22
    9eb8:	da1f02b8 	sbc	x24, x21, xzr
    9ebc:	52800020 	mov	w0, #0x1                   	// #1
    9ec0:	f9001ffb 	str	x27, [sp, #56]
    9ec4:	aa1b03fa 	mov	x26, x27
    9ec8:	f9042ffb 	str	x27, [sp, #2136]
    9ecc:	aa1803f5 	mov	x21, x24
    9ed0:	f90433f3 	str	x19, [sp, #2144]
    9ed4:	97ffeb88 	bl	4cf4 <fwp_data.part.0.constprop.0>
    9ed8:	f949db22 	ldr	x2, [x25, #5040]
    9edc:	aa0003f3 	mov	x19, x0
    9ee0:	f949ef20 	ldr	x0, [x25, #5080]
    9ee4:	cb020262 	sub	x2, x19, x2
    9ee8:	eb00405f 	cmp	x2, x0, lsl #16
    9eec:	54000302 	b.cs	9f4c <f0+0x128>  // b.hs, b.nlast
    9ef0:	d350fc40 	lsr	x0, x2, #16
    9ef4:	f949ff25 	ldr	x5, [x25, #5112]
    9ef8:	8b000800 	add	x0, x0, x0, lsl #2
    9efc:	d37df001 	lsl	x1, x0, #3
    9f00:	8b0100a0 	add	x0, x5, x1
    9f04:	f940101c 	ldr	x28, [x0, #32]
    9f08:	b400023c 	cbz	x28, 9f4c <f0+0x128>
    9f0c:	386168a1 	ldrb	w1, [x5, x1]
    9f10:	7100083f 	cmp	w1, #0x2
    9f14:	54010ea0 	b.eq	c0e8 <f0+0x22c4>  // b.none
    9f18:	7100043f 	cmp	w1, #0x1
    9f1c:	54000181 	b.ne	9f4c <f0+0x128>  // b.any
    9f20:	29430001 	ldp	w1, w0, [x0, #24]
    9f24:	92403c42 	and	x2, x2, #0xffff
    9f28:	9b017c42 	mul	x2, x2, x1
    9f2c:	d360fc42 	lsr	x2, x2, #32
    9f30:	eb00005f 	cmp	x2, x0
    9f34:	540000c2 	b.cs	9f4c <f0+0x128>  // b.hs, b.nlast
    9f38:	8b02039c 	add	x28, x28, x2
    9f3c:	39400380 	ldrb	w0, [x28]
    9f40:	7103fc1f 	cmp	w0, #0xff
    9f44:	54010cc0 	b.eq	c0dc <f0+0x22b8>  // b.none
    9f48:	39000397 	strb	w23, [x28]
    9f4c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    9f50:	aa18037b 	orr	x27, x27, x24
    9f54:	b5fffafb 	cbnz	x27, 9eb0 <f0+0x8c>
    9f58:	f00000a0 	adrp	x0, 20000 <__data_start>
    9f5c:	9100c018 	add	x24, x0, #0x30
    9f60:	f94007e1 	ldr	x1, [sp, #8]
    9f64:	f9001bff 	str	xzr, [sp, #48]
    9f68:	f9415b00 	ldr	x0, [x24, #688]
    9f6c:	eb01001f 	cmp	x0, x1
    9f70:	54012981 	b.ne	c4a0 <f0+0x267c>  // b.any
    9f74:	90000020 	adrp	x0, d000 <__modti3+0x2c0>
    9f78:	910143e1 	add	x1, sp, #0x50
    9f7c:	f9400fe2 	ldr	x2, [sp, #24]
    9f80:	f9015b02 	str	x2, [x24, #688]
    9f84:	3dc37c00 	ldr	q0, [x0, #3568]
    9f88:	52800020 	mov	w0, #0x1                   	// #1
    9f8c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9f90:	3d8017e0 	str	q0, [sp, #80]
    9f94:	97ffeb58 	bl	4cf4 <fwp_data.part.0.constprop.0>
    9f98:	97ffee1a 	bl	5800 <fwp_rc_fresh>
    9f9c:	9101a3e1 	add	x1, sp, #0x68
    9fa0:	aa0003e2 	mov	x2, x0
    9fa4:	52800020 	mov	w0, #0x1                   	// #1
    9fa8:	a9068bf5 	stp	x21, x2, [sp, #104]
    9fac:	97ffeb52 	bl	4cf4 <fwp_data.part.0.constprop.0>
    9fb0:	97ffee14 	bl	5800 <fwp_rc_fresh>
    9fb4:	aa0003e2 	mov	x2, x0
    9fb8:	90000023 	adrp	x3, d000 <__modti3+0x2c0>
    9fbc:	9101e3e1 	add	x1, sp, #0x78
    9fc0:	52800020 	mov	w0, #0x1                   	// #1
    9fc4:	f90043e2 	str	x2, [sp, #128]
    9fc8:	3dc37c60 	ldr	q0, [x3, #3568]
    9fcc:	fd003fe0 	str	d0, [sp, #120]
    9fd0:	97ffeb49 	bl	4cf4 <fwp_data.part.0.constprop.0>
    9fd4:	97ffee0b 	bl	5800 <fwp_rc_fresh>
    9fd8:	aa0003e2 	mov	x2, x0
    9fdc:	910223e1 	add	x1, sp, #0x88
    9fe0:	52800020 	mov	w0, #0x1                   	// #1
    9fe4:	a9088bf5 	stp	x21, x2, [sp, #136]
    9fe8:	97ffeb43 	bl	4cf4 <fwp_data.part.0.constprop.0>
    9fec:	97ffee05 	bl	5800 <fwp_rc_fresh>
    9ff0:	aa0003e2 	mov	x2, x0
    9ff4:	90000023 	adrp	x3, d000 <__modti3+0x2c0>
    9ff8:	910263e1 	add	x1, sp, #0x98
    9ffc:	52800020 	mov	w0, #0x1                   	// #1
    a000:	f90053e2 	str	x2, [sp, #160]
    a004:	3dc37c60 	ldr	q0, [x3, #3568]
    a008:	fd004fe0 	str	d0, [sp, #152]
    a00c:	97ffeb3a 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a010:	9114c283 	add	x3, x20, #0x530
    a014:	aa0003f5 	mov	x21, x0
    a018:	f949d861 	ldr	x1, [x3, #5040]
    a01c:	f949ec60 	ldr	x0, [x3, #5080]
    a020:	cb0102a1 	sub	x1, x21, x1
    a024:	eb00403f 	cmp	x1, x0, lsl #16
    a028:	54000322 	b.cs	a08c <f0+0x268>  // b.hs, b.nlast
    a02c:	d350fc22 	lsr	x2, x1, #16
    a030:	f949fc63 	ldr	x3, [x3, #5112]
    a034:	8b020842 	add	x2, x2, x2, lsl #2
    a038:	d37df042 	lsl	x2, x2, #3
    a03c:	8b020060 	add	x0, x3, x2
    a040:	f9401017 	ldr	x23, [x0, #32]
    a044:	b4000257 	cbz	x23, a08c <f0+0x268>
    a048:	38626862 	ldrb	w2, [x3, x2]
    a04c:	7100085f 	cmp	w2, #0x2
    a050:	54010520 	b.eq	c0f4 <f0+0x22d0>  // b.none
    a054:	7100045f 	cmp	w2, #0x1
    a058:	540001a1 	b.ne	a08c <f0+0x268>  // b.any
    a05c:	29430002 	ldp	w2, w0, [x0, #24]
    a060:	92403c21 	and	x1, x1, #0xffff
    a064:	9b027c21 	mul	x1, x1, x2
    a068:	d360fc21 	lsr	x1, x1, #32
    a06c:	eb00003f 	cmp	x1, x0
    a070:	540000e2 	b.cs	a08c <f0+0x268>  // b.hs, b.nlast
    a074:	8b0102f7 	add	x23, x23, x1
    a078:	394002e0 	ldrb	w0, [x23]
    a07c:	7103fc1f 	cmp	w0, #0xff
    a080:	540112a0 	b.eq	c2d4 <f0+0x24b0>  // b.none
    a084:	52800020 	mov	w0, #0x1                   	// #1
    a088:	390002e0 	strb	w0, [x23]
    a08c:	9102a3e1 	add	x1, sp, #0xa8
    a090:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a094:	52800020 	mov	w0, #0x1                   	// #1
    a098:	a90ad7f7 	stp	x23, x21, [sp, #168]
    a09c:	97ffeb16 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a0a0:	97ffedd8 	bl	5800 <fwp_rc_fresh>
    a0a4:	aa0003e2 	mov	x2, x0
    a0a8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a0ac:	9102e3e1 	add	x1, sp, #0xb8
    a0b0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a0b4:	52800020 	mov	w0, #0x1                   	// #1
    a0b8:	a90b8be3 	stp	x3, x2, [sp, #184]
    a0bc:	97ffeb0e 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a0c0:	97ffedd0 	bl	5800 <fwp_rc_fresh>
    a0c4:	aa0003e2 	mov	x2, x0
    a0c8:	910323e1 	add	x1, sp, #0xc8
    a0cc:	52800020 	mov	w0, #0x1                   	// #1
    a0d0:	a90c8bf7 	stp	x23, x2, [sp, #200]
    a0d4:	97ffeb08 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a0d8:	9114c283 	add	x3, x20, #0x530
    a0dc:	aa0003f5 	mov	x21, x0
    a0e0:	f949d861 	ldr	x1, [x3, #5040]
    a0e4:	f949ec60 	ldr	x0, [x3, #5080]
    a0e8:	cb0102a1 	sub	x1, x21, x1
    a0ec:	eb00403f 	cmp	x1, x0, lsl #16
    a0f0:	54000322 	b.cs	a154 <f0+0x330>  // b.hs, b.nlast
    a0f4:	d350fc22 	lsr	x2, x1, #16
    a0f8:	f949fc63 	ldr	x3, [x3, #5112]
    a0fc:	8b020842 	add	x2, x2, x2, lsl #2
    a100:	d37df042 	lsl	x2, x2, #3
    a104:	8b020060 	add	x0, x3, x2
    a108:	f9401017 	ldr	x23, [x0, #32]
    a10c:	b4000257 	cbz	x23, a154 <f0+0x330>
    a110:	38626862 	ldrb	w2, [x3, x2]
    a114:	7100085f 	cmp	w2, #0x2
    a118:	5400ffa0 	b.eq	c10c <f0+0x22e8>  // b.none
    a11c:	7100045f 	cmp	w2, #0x1
    a120:	540001a1 	b.ne	a154 <f0+0x330>  // b.any
    a124:	29430002 	ldp	w2, w0, [x0, #24]
    a128:	92403c21 	and	x1, x1, #0xffff
    a12c:	9b027c21 	mul	x1, x1, x2
    a130:	d360fc21 	lsr	x1, x1, #32
    a134:	eb00003f 	cmp	x1, x0
    a138:	540000e2 	b.cs	a154 <f0+0x330>  // b.hs, b.nlast
    a13c:	8b0102f7 	add	x23, x23, x1
    a140:	394002e0 	ldrb	w0, [x23]
    a144:	7103fc1f 	cmp	w0, #0xff
    a148:	54010cc0 	b.eq	c2e0 <f0+0x24bc>  // b.none
    a14c:	52800020 	mov	w0, #0x1                   	// #1
    a150:	390002e0 	strb	w0, [x23]
    a154:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a158:	910363e1 	add	x1, sp, #0xd8
    a15c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a160:	52800020 	mov	w0, #0x1                   	// #1
    a164:	a90dd7e2 	stp	x2, x21, [sp, #216]
    a168:	97ffeae3 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a16c:	9114c283 	add	x3, x20, #0x530
    a170:	aa0003f5 	mov	x21, x0
    a174:	f949d861 	ldr	x1, [x3, #5040]
    a178:	f949ec60 	ldr	x0, [x3, #5080]
    a17c:	cb0102a1 	sub	x1, x21, x1
    a180:	eb00403f 	cmp	x1, x0, lsl #16
    a184:	54000322 	b.cs	a1e8 <f0+0x3c4>  // b.hs, b.nlast
    a188:	d350fc22 	lsr	x2, x1, #16
    a18c:	f949fc63 	ldr	x3, [x3, #5112]
    a190:	8b020842 	add	x2, x2, x2, lsl #2
    a194:	d37df042 	lsl	x2, x2, #3
    a198:	8b020060 	add	x0, x3, x2
    a19c:	f9401017 	ldr	x23, [x0, #32]
    a1a0:	b4000257 	cbz	x23, a1e8 <f0+0x3c4>
    a1a4:	38626862 	ldrb	w2, [x3, x2]
    a1a8:	7100085f 	cmp	w2, #0x2
    a1ac:	5400faa0 	b.eq	c100 <f0+0x22dc>  // b.none
    a1b0:	7100045f 	cmp	w2, #0x1
    a1b4:	540001a1 	b.ne	a1e8 <f0+0x3c4>  // b.any
    a1b8:	29430002 	ldp	w2, w0, [x0, #24]
    a1bc:	92403c21 	and	x1, x1, #0xffff
    a1c0:	9b027c21 	mul	x1, x1, x2
    a1c4:	d360fc21 	lsr	x1, x1, #32
    a1c8:	eb00003f 	cmp	x1, x0
    a1cc:	540000e2 	b.cs	a1e8 <f0+0x3c4>  // b.hs, b.nlast
    a1d0:	8b0102f7 	add	x23, x23, x1
    a1d4:	394002e0 	ldrb	w0, [x23]
    a1d8:	7103fc1f 	cmp	w0, #0xff
    a1dc:	54010880 	b.eq	c2ec <f0+0x24c8>  // b.none
    a1e0:	52800020 	mov	w0, #0x1                   	// #1
    a1e4:	390002e0 	strb	w0, [x23]
    a1e8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a1ec:	9103a3e1 	add	x1, sp, #0xe8
    a1f0:	52800020 	mov	w0, #0x1                   	// #1
    a1f4:	a90ed7e2 	stp	x2, x21, [sp, #232]
    a1f8:	97ffeabf 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a1fc:	9114c283 	add	x3, x20, #0x530
    a200:	aa0003f7 	mov	x23, x0
    a204:	f949d861 	ldr	x1, [x3, #5040]
    a208:	f949ec60 	ldr	x0, [x3, #5080]
    a20c:	cb0102e1 	sub	x1, x23, x1
    a210:	eb00403f 	cmp	x1, x0, lsl #16
    a214:	54000322 	b.cs	a278 <f0+0x454>  // b.hs, b.nlast
    a218:	d350fc22 	lsr	x2, x1, #16
    a21c:	f949fc63 	ldr	x3, [x3, #5112]
    a220:	8b020842 	add	x2, x2, x2, lsl #2
    a224:	d37df042 	lsl	x2, x2, #3
    a228:	8b020060 	add	x0, x3, x2
    a22c:	f9401015 	ldr	x21, [x0, #32]
    a230:	b4000255 	cbz	x21, a278 <f0+0x454>
    a234:	38626862 	ldrb	w2, [x3, x2]
    a238:	7100085f 	cmp	w2, #0x2
    a23c:	5400f740 	b.eq	c124 <f0+0x2300>  // b.none
    a240:	7100045f 	cmp	w2, #0x1
    a244:	540001a1 	b.ne	a278 <f0+0x454>  // b.any
    a248:	29430002 	ldp	w2, w0, [x0, #24]
    a24c:	92403c21 	and	x1, x1, #0xffff
    a250:	9b027c21 	mul	x1, x1, x2
    a254:	d360fc21 	lsr	x1, x1, #32
    a258:	eb00003f 	cmp	x1, x0
    a25c:	540000e2 	b.cs	a278 <f0+0x454>  // b.hs, b.nlast
    a260:	8b0102b5 	add	x21, x21, x1
    a264:	394002a0 	ldrb	w0, [x21]
    a268:	7103fc1f 	cmp	w0, #0xff
    a26c:	54010460 	b.eq	c2f8 <f0+0x24d4>  // b.none
    a270:	52800020 	mov	w0, #0x1                   	// #1
    a274:	390002a0 	strb	w0, [x21]
    a278:	9103e3e1 	add	x1, sp, #0xf8
    a27c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a280:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a284:	52800020 	mov	w0, #0x1                   	// #1
    a288:	a90fdff5 	stp	x21, x23, [sp, #248]
    a28c:	97ffea9a 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a290:	97ffed5c 	bl	5800 <fwp_rc_fresh>
    a294:	aa0003e2 	mov	x2, x0
    a298:	910423e1 	add	x1, sp, #0x108
    a29c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a2a0:	52800020 	mov	w0, #0x1                   	// #1
    a2a4:	a9108bf7 	stp	x23, x2, [sp, #264]
    a2a8:	97ffea93 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a2ac:	97ffed55 	bl	5800 <fwp_rc_fresh>
    a2b0:	aa0003e2 	mov	x2, x0
    a2b4:	910463e1 	add	x1, sp, #0x118
    a2b8:	52800020 	mov	w0, #0x1                   	// #1
    a2bc:	a9118bf5 	stp	x21, x2, [sp, #280]
    a2c0:	97ffea8d 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a2c4:	97ffed4f 	bl	5800 <fwp_rc_fresh>
    a2c8:	aa0003e2 	mov	x2, x0
    a2cc:	9104a3e1 	add	x1, sp, #0x128
    a2d0:	52800020 	mov	w0, #0x1                   	// #1
    a2d4:	a9128bf7 	stp	x23, x2, [sp, #296]
    a2d8:	97ffea87 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a2dc:	97ffed49 	bl	5800 <fwp_rc_fresh>
    a2e0:	aa0003e2 	mov	x2, x0
    a2e4:	9104e3e1 	add	x1, sp, #0x138
    a2e8:	52800020 	mov	w0, #0x1                   	// #1
    a2ec:	a9138bf5 	stp	x21, x2, [sp, #312]
    a2f0:	97ffea81 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a2f4:	97ffed43 	bl	5800 <fwp_rc_fresh>
    a2f8:	aa0003e2 	mov	x2, x0
    a2fc:	910523e1 	add	x1, sp, #0x148
    a300:	52800020 	mov	w0, #0x1                   	// #1
    a304:	a9148bf7 	stp	x23, x2, [sp, #328]
    a308:	97ffea7b 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a30c:	97ffed3d 	bl	5800 <fwp_rc_fresh>
    a310:	aa0003e2 	mov	x2, x0
    a314:	910563e1 	add	x1, sp, #0x158
    a318:	52800020 	mov	w0, #0x1                   	// #1
    a31c:	a9158bf5 	stp	x21, x2, [sp, #344]
    a320:	97ffea75 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a324:	97ffed37 	bl	5800 <fwp_rc_fresh>
    a328:	aa0003e2 	mov	x2, x0
    a32c:	9105a3e1 	add	x1, sp, #0x168
    a330:	52800020 	mov	w0, #0x1                   	// #1
    a334:	a9168bf7 	stp	x23, x2, [sp, #360]
    a338:	97ffea6f 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a33c:	97ffed31 	bl	5800 <fwp_rc_fresh>
    a340:	aa0003e2 	mov	x2, x0
    a344:	9105e3e1 	add	x1, sp, #0x178
    a348:	52800020 	mov	w0, #0x1                   	// #1
    a34c:	a9178bf5 	stp	x21, x2, [sp, #376]
    a350:	97ffea69 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a354:	97ffed2b 	bl	5800 <fwp_rc_fresh>
    a358:	aa0003e2 	mov	x2, x0
    a35c:	910623e1 	add	x1, sp, #0x188
    a360:	52800020 	mov	w0, #0x1                   	// #1
    a364:	a9188bf7 	stp	x23, x2, [sp, #392]
    a368:	97ffea63 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a36c:	97ffed25 	bl	5800 <fwp_rc_fresh>
    a370:	aa0003e2 	mov	x2, x0
    a374:	910663e1 	add	x1, sp, #0x198
    a378:	52800020 	mov	w0, #0x1                   	// #1
    a37c:	a9198bf5 	stp	x21, x2, [sp, #408]
    a380:	97ffea5d 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a384:	97ffed1f 	bl	5800 <fwp_rc_fresh>
    a388:	aa0003e2 	mov	x2, x0
    a38c:	9106a3e1 	add	x1, sp, #0x1a8
    a390:	52800020 	mov	w0, #0x1                   	// #1
    a394:	a91a8bf7 	stp	x23, x2, [sp, #424]
    a398:	97ffea57 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a39c:	97ffed19 	bl	5800 <fwp_rc_fresh>
    a3a0:	aa0003e2 	mov	x2, x0
    a3a4:	9106e3e1 	add	x1, sp, #0x1b8
    a3a8:	52800020 	mov	w0, #0x1                   	// #1
    a3ac:	a91b8bf5 	stp	x21, x2, [sp, #440]
    a3b0:	97ffea51 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a3b4:	97ffed13 	bl	5800 <fwp_rc_fresh>
    a3b8:	aa0003e2 	mov	x2, x0
    a3bc:	910723e1 	add	x1, sp, #0x1c8
    a3c0:	52800020 	mov	w0, #0x1                   	// #1
    a3c4:	a91c8bf7 	stp	x23, x2, [sp, #456]
    a3c8:	97ffea4b 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a3cc:	97ffed0d 	bl	5800 <fwp_rc_fresh>
    a3d0:	aa0003e2 	mov	x2, x0
    a3d4:	910763e1 	add	x1, sp, #0x1d8
    a3d8:	52800020 	mov	w0, #0x1                   	// #1
    a3dc:	a91d8bf5 	stp	x21, x2, [sp, #472]
    a3e0:	97ffea45 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a3e4:	97ffed07 	bl	5800 <fwp_rc_fresh>
    a3e8:	aa0003e2 	mov	x2, x0
    a3ec:	9107a3e1 	add	x1, sp, #0x1e8
    a3f0:	52800020 	mov	w0, #0x1                   	// #1
    a3f4:	a91e8bf7 	stp	x23, x2, [sp, #488]
    a3f8:	97ffea3f 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a3fc:	97ffed01 	bl	5800 <fwp_rc_fresh>
    a400:	aa0003e2 	mov	x2, x0
    a404:	9107e3e1 	add	x1, sp, #0x1f8
    a408:	52800020 	mov	w0, #0x1                   	// #1
    a40c:	a91f8bf5 	stp	x21, x2, [sp, #504]
    a410:	97ffea39 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a414:	9114c283 	add	x3, x20, #0x530
    a418:	aa0003f5 	mov	x21, x0
    a41c:	f949d861 	ldr	x1, [x3, #5040]
    a420:	f949ec60 	ldr	x0, [x3, #5080]
    a424:	cb0102a1 	sub	x1, x21, x1
    a428:	eb00403f 	cmp	x1, x0, lsl #16
    a42c:	54000322 	b.cs	a490 <f0+0x66c>  // b.hs, b.nlast
    a430:	d350fc22 	lsr	x2, x1, #16
    a434:	f949fc63 	ldr	x3, [x3, #5112]
    a438:	8b020842 	add	x2, x2, x2, lsl #2
    a43c:	d37df042 	lsl	x2, x2, #3
    a440:	8b020060 	add	x0, x3, x2
    a444:	f9401017 	ldr	x23, [x0, #32]
    a448:	b4000257 	cbz	x23, a490 <f0+0x66c>
    a44c:	38626862 	ldrb	w2, [x3, x2]
    a450:	7100085f 	cmp	w2, #0x2
    a454:	5400e620 	b.eq	c118 <f0+0x22f4>  // b.none
    a458:	7100045f 	cmp	w2, #0x1
    a45c:	540001a1 	b.ne	a490 <f0+0x66c>  // b.any
    a460:	29430002 	ldp	w2, w0, [x0, #24]
    a464:	92403c21 	and	x1, x1, #0xffff
    a468:	9b027c21 	mul	x1, x1, x2
    a46c:	d360fc21 	lsr	x1, x1, #32
    a470:	eb00003f 	cmp	x1, x0
    a474:	540000e2 	b.cs	a490 <f0+0x66c>  // b.hs, b.nlast
    a478:	8b0102f7 	add	x23, x23, x1
    a47c:	394002e0 	ldrb	w0, [x23]
    a480:	7103fc1f 	cmp	w0, #0xff
    a484:	5400f400 	b.eq	c304 <f0+0x24e0>  // b.none
    a488:	52800020 	mov	w0, #0x1                   	// #1
    a48c:	390002e0 	strb	w0, [x23]
    a490:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a494:	910823e1 	add	x1, sp, #0x208
    a498:	52800020 	mov	w0, #0x1                   	// #1
    a49c:	f90107e2 	str	x2, [sp, #520]
    a4a0:	f9010bf5 	str	x21, [sp, #528]
    a4a4:	97ffea14 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a4a8:	9114c283 	add	x3, x20, #0x530
    a4ac:	aa0003f5 	mov	x21, x0
    a4b0:	f949d861 	ldr	x1, [x3, #5040]
    a4b4:	f949ec60 	ldr	x0, [x3, #5080]
    a4b8:	cb0102a1 	sub	x1, x21, x1
    a4bc:	eb00403f 	cmp	x1, x0, lsl #16
    a4c0:	54000322 	b.cs	a524 <f0+0x700>  // b.hs, b.nlast
    a4c4:	d350fc22 	lsr	x2, x1, #16
    a4c8:	f949fc63 	ldr	x3, [x3, #5112]
    a4cc:	8b020842 	add	x2, x2, x2, lsl #2
    a4d0:	d37df042 	lsl	x2, x2, #3
    a4d4:	8b020060 	add	x0, x3, x2
    a4d8:	f9401017 	ldr	x23, [x0, #32]
    a4dc:	b4000257 	cbz	x23, a524 <f0+0x700>
    a4e0:	38626862 	ldrb	w2, [x3, x2]
    a4e4:	7100085f 	cmp	w2, #0x2
    a4e8:	5400e2a0 	b.eq	c13c <f0+0x2318>  // b.none
    a4ec:	7100045f 	cmp	w2, #0x1
    a4f0:	540001a1 	b.ne	a524 <f0+0x700>  // b.any
    a4f4:	29430002 	ldp	w2, w0, [x0, #24]
    a4f8:	92403c21 	and	x1, x1, #0xffff
    a4fc:	9b027c21 	mul	x1, x1, x2
    a500:	d360fc21 	lsr	x1, x1, #32
    a504:	eb00003f 	cmp	x1, x0
    a508:	540000e2 	b.cs	a524 <f0+0x700>  // b.hs, b.nlast
    a50c:	8b0102f7 	add	x23, x23, x1
    a510:	394002e0 	ldrb	w0, [x23]
    a514:	7103fc1f 	cmp	w0, #0xff
    a518:	5400efc0 	b.eq	c310 <f0+0x24ec>  // b.none
    a51c:	52800020 	mov	w0, #0x1                   	// #1
    a520:	390002e0 	strb	w0, [x23]
    a524:	910863e1 	add	x1, sp, #0x218
    a528:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a52c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a530:	52800020 	mov	w0, #0x1                   	// #1
    a534:	f9010ff7 	str	x23, [sp, #536]
    a538:	f90113f5 	str	x21, [sp, #544]
    a53c:	97ffe9ee 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a540:	97ffecb0 	bl	5800 <fwp_rc_fresh>
    a544:	aa0003e2 	mov	x2, x0
    a548:	9108a3e1 	add	x1, sp, #0x228
    a54c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a550:	52800020 	mov	w0, #0x1                   	// #1
    a554:	f90117f5 	str	x21, [sp, #552]
    a558:	f9011be2 	str	x2, [sp, #560]
    a55c:	97ffe9e6 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a560:	97ffeca8 	bl	5800 <fwp_rc_fresh>
    a564:	aa0003e2 	mov	x2, x0
    a568:	9108e3e1 	add	x1, sp, #0x238
    a56c:	52800020 	mov	w0, #0x1                   	// #1
    a570:	f9011ff7 	str	x23, [sp, #568]
    a574:	f90123e2 	str	x2, [sp, #576]
    a578:	97ffe9df 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a57c:	97ffeca1 	bl	5800 <fwp_rc_fresh>
    a580:	aa0003e2 	mov	x2, x0
    a584:	910923e1 	add	x1, sp, #0x248
    a588:	52800020 	mov	w0, #0x1                   	// #1
    a58c:	f90127f5 	str	x21, [sp, #584]
    a590:	f9012be2 	str	x2, [sp, #592]
    a594:	97ffe9d8 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a598:	9114c283 	add	x3, x20, #0x530
    a59c:	aa0003f5 	mov	x21, x0
    a5a0:	f949d861 	ldr	x1, [x3, #5040]
    a5a4:	f949ec60 	ldr	x0, [x3, #5080]
    a5a8:	cb0102a1 	sub	x1, x21, x1
    a5ac:	eb00403f 	cmp	x1, x0, lsl #16
    a5b0:	54000322 	b.cs	a614 <f0+0x7f0>  // b.hs, b.nlast
    a5b4:	d350fc22 	lsr	x2, x1, #16
    a5b8:	f949fc63 	ldr	x3, [x3, #5112]
    a5bc:	8b020842 	add	x2, x2, x2, lsl #2
    a5c0:	d37df042 	lsl	x2, x2, #3
    a5c4:	8b020060 	add	x0, x3, x2
    a5c8:	f9401017 	ldr	x23, [x0, #32]
    a5cc:	b4000257 	cbz	x23, a614 <f0+0x7f0>
    a5d0:	38626862 	ldrb	w2, [x3, x2]
    a5d4:	7100085f 	cmp	w2, #0x2
    a5d8:	5400dac0 	b.eq	c130 <f0+0x230c>  // b.none
    a5dc:	7100045f 	cmp	w2, #0x1
    a5e0:	540001a1 	b.ne	a614 <f0+0x7f0>  // b.any
    a5e4:	29430002 	ldp	w2, w0, [x0, #24]
    a5e8:	92403c21 	and	x1, x1, #0xffff
    a5ec:	9b027c21 	mul	x1, x1, x2
    a5f0:	d360fc21 	lsr	x1, x1, #32
    a5f4:	eb00003f 	cmp	x1, x0
    a5f8:	540000e2 	b.cs	a614 <f0+0x7f0>  // b.hs, b.nlast
    a5fc:	8b0102f7 	add	x23, x23, x1
    a600:	394002e0 	ldrb	w0, [x23]
    a604:	7103fc1f 	cmp	w0, #0xff
    a608:	5400e8a0 	b.eq	c31c <f0+0x24f8>  // b.none
    a60c:	52800020 	mov	w0, #0x1                   	// #1
    a610:	390002e0 	strb	w0, [x23]
    a614:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a618:	910963e1 	add	x1, sp, #0x258
    a61c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a620:	52800020 	mov	w0, #0x1                   	// #1
    a624:	f9012fe2 	str	x2, [sp, #600]
    a628:	f90133f5 	str	x21, [sp, #608]
    a62c:	97ffe9b2 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a630:	97ffec74 	bl	5800 <fwp_rc_fresh>
    a634:	aa0003e2 	mov	x2, x0
    a638:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a63c:	9109a3e1 	add	x1, sp, #0x268
    a640:	52800020 	mov	w0, #0x1                   	// #1
    a644:	f90137e3 	str	x3, [sp, #616]
    a648:	f9013be2 	str	x2, [sp, #624]
    a64c:	97ffe9aa 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a650:	9114c283 	add	x3, x20, #0x530
    a654:	aa0003f7 	mov	x23, x0
    a658:	f949d861 	ldr	x1, [x3, #5040]
    a65c:	f949ec60 	ldr	x0, [x3, #5080]
    a660:	cb0102e1 	sub	x1, x23, x1
    a664:	eb00403f 	cmp	x1, x0, lsl #16
    a668:	54000322 	b.cs	a6cc <f0+0x8a8>  // b.hs, b.nlast
    a66c:	d350fc22 	lsr	x2, x1, #16
    a670:	f949fc63 	ldr	x3, [x3, #5112]
    a674:	8b020842 	add	x2, x2, x2, lsl #2
    a678:	d37df042 	lsl	x2, x2, #3
    a67c:	8b020060 	add	x0, x3, x2
    a680:	f9401015 	ldr	x21, [x0, #32]
    a684:	b4000255 	cbz	x21, a6cc <f0+0x8a8>
    a688:	38626862 	ldrb	w2, [x3, x2]
    a68c:	7100085f 	cmp	w2, #0x2
    a690:	5400dc20 	b.eq	c214 <f0+0x23f0>  // b.none
    a694:	7100045f 	cmp	w2, #0x1
    a698:	540001a1 	b.ne	a6cc <f0+0x8a8>  // b.any
    a69c:	29430002 	ldp	w2, w0, [x0, #24]
    a6a0:	92403c21 	and	x1, x1, #0xffff
    a6a4:	9b027c21 	mul	x1, x1, x2
    a6a8:	d360fc21 	lsr	x1, x1, #32
    a6ac:	eb00003f 	cmp	x1, x0
    a6b0:	540000e2 	b.cs	a6cc <f0+0x8a8>  // b.hs, b.nlast
    a6b4:	8b0102b5 	add	x21, x21, x1
    a6b8:	394002a0 	ldrb	w0, [x21]
    a6bc:	7103fc1f 	cmp	w0, #0xff
    a6c0:	5400e340 	b.eq	c328 <f0+0x2504>  // b.none
    a6c4:	52800020 	mov	w0, #0x1                   	// #1
    a6c8:	390002a0 	strb	w0, [x21]
    a6cc:	9109e3e1 	add	x1, sp, #0x278
    a6d0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a6d4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a6d8:	52800020 	mov	w0, #0x1                   	// #1
    a6dc:	f9013ff5 	str	x21, [sp, #632]
    a6e0:	f90143f7 	str	x23, [sp, #640]
    a6e4:	97ffe984 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a6e8:	97ffec46 	bl	5800 <fwp_rc_fresh>
    a6ec:	aa0003e2 	mov	x2, x0
    a6f0:	910a23e1 	add	x1, sp, #0x288
    a6f4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a6f8:	52800020 	mov	w0, #0x1                   	// #1
    a6fc:	f90147f7 	str	x23, [sp, #648]
    a700:	f9014be2 	str	x2, [sp, #656]
    a704:	97ffe97c 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a708:	97ffec3e 	bl	5800 <fwp_rc_fresh>
    a70c:	aa0003e2 	mov	x2, x0
    a710:	910a63e1 	add	x1, sp, #0x298
    a714:	52800020 	mov	w0, #0x1                   	// #1
    a718:	f9014ff5 	str	x21, [sp, #664]
    a71c:	f90153e2 	str	x2, [sp, #672]
    a720:	97ffe975 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a724:	97ffec37 	bl	5800 <fwp_rc_fresh>
    a728:	aa0003e2 	mov	x2, x0
    a72c:	910aa3e1 	add	x1, sp, #0x2a8
    a730:	52800020 	mov	w0, #0x1                   	// #1
    a734:	f90157f7 	str	x23, [sp, #680]
    a738:	f9015be2 	str	x2, [sp, #688]
    a73c:	97ffe96e 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a740:	97ffec30 	bl	5800 <fwp_rc_fresh>
    a744:	aa0003e2 	mov	x2, x0
    a748:	910ae3e1 	add	x1, sp, #0x2b8
    a74c:	52800020 	mov	w0, #0x1                   	// #1
    a750:	f9015ff5 	str	x21, [sp, #696]
    a754:	f90163e2 	str	x2, [sp, #704]
    a758:	97ffe967 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a75c:	97ffec29 	bl	5800 <fwp_rc_fresh>
    a760:	aa0003e2 	mov	x2, x0
    a764:	910b23e1 	add	x1, sp, #0x2c8
    a768:	52800020 	mov	w0, #0x1                   	// #1
    a76c:	f90167f7 	str	x23, [sp, #712]
    a770:	f9016be2 	str	x2, [sp, #720]
    a774:	97ffe960 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a778:	97ffec22 	bl	5800 <fwp_rc_fresh>
    a77c:	aa0003e2 	mov	x2, x0
    a780:	910b63e1 	add	x1, sp, #0x2d8
    a784:	52800020 	mov	w0, #0x1                   	// #1
    a788:	f9016ff5 	str	x21, [sp, #728]
    a78c:	f90173e2 	str	x2, [sp, #736]
    a790:	97ffe959 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a794:	97ffec1b 	bl	5800 <fwp_rc_fresh>
    a798:	aa0003e2 	mov	x2, x0
    a79c:	910ba3e1 	add	x1, sp, #0x2e8
    a7a0:	52800020 	mov	w0, #0x1                   	// #1
    a7a4:	f90177f7 	str	x23, [sp, #744]
    a7a8:	f9017be2 	str	x2, [sp, #752]
    a7ac:	97ffe952 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a7b0:	97ffec14 	bl	5800 <fwp_rc_fresh>
    a7b4:	aa0003e2 	mov	x2, x0
    a7b8:	910be3e1 	add	x1, sp, #0x2f8
    a7bc:	52800020 	mov	w0, #0x1                   	// #1
    a7c0:	f9017ff5 	str	x21, [sp, #760]
    a7c4:	f90183e2 	str	x2, [sp, #768]
    a7c8:	97ffe94b 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a7cc:	9114c283 	add	x3, x20, #0x530
    a7d0:	aa0003f5 	mov	x21, x0
    a7d4:	f949d861 	ldr	x1, [x3, #5040]
    a7d8:	f949ec60 	ldr	x0, [x3, #5080]
    a7dc:	cb0102a1 	sub	x1, x21, x1
    a7e0:	eb00403f 	cmp	x1, x0, lsl #16
    a7e4:	54000322 	b.cs	a848 <f0+0xa24>  // b.hs, b.nlast
    a7e8:	d350fc22 	lsr	x2, x1, #16
    a7ec:	f949fc63 	ldr	x3, [x3, #5112]
    a7f0:	8b020842 	add	x2, x2, x2, lsl #2
    a7f4:	d37df042 	lsl	x2, x2, #3
    a7f8:	8b020060 	add	x0, x3, x2
    a7fc:	f9401017 	ldr	x23, [x0, #32]
    a800:	b4000257 	cbz	x23, a848 <f0+0xa24>
    a804:	38626862 	ldrb	w2, [x3, x2]
    a808:	7100085f 	cmp	w2, #0x2
    a80c:	5400cfe0 	b.eq	c208 <f0+0x23e4>  // b.none
    a810:	7100045f 	cmp	w2, #0x1
    a814:	540001a1 	b.ne	a848 <f0+0xa24>  // b.any
    a818:	29430002 	ldp	w2, w0, [x0, #24]
    a81c:	92403c21 	and	x1, x1, #0xffff
    a820:	9b027c21 	mul	x1, x1, x2
    a824:	d360fc21 	lsr	x1, x1, #32
    a828:	eb00003f 	cmp	x1, x0
    a82c:	540000e2 	b.cs	a848 <f0+0xa24>  // b.hs, b.nlast
    a830:	8b0102f7 	add	x23, x23, x1
    a834:	394002e0 	ldrb	w0, [x23]
    a838:	7103fc1f 	cmp	w0, #0xff
    a83c:	5400d7c0 	b.eq	c334 <f0+0x2510>  // b.none
    a840:	52800020 	mov	w0, #0x1                   	// #1
    a844:	390002e0 	strb	w0, [x23]
    a848:	910c23e1 	add	x1, sp, #0x308
    a84c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a850:	52800020 	mov	w0, #0x1                   	// #1
    a854:	f90187f7 	str	x23, [sp, #776]
    a858:	f9018bf5 	str	x21, [sp, #784]
    a85c:	97ffe926 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a860:	97ffebe8 	bl	5800 <fwp_rc_fresh>
    a864:	aa0003e2 	mov	x2, x0
    a868:	910c63e1 	add	x1, sp, #0x318
    a86c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a870:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a874:	52800020 	mov	w0, #0x1                   	// #1
    a878:	f9018ff5 	str	x21, [sp, #792]
    a87c:	f90193e2 	str	x2, [sp, #800]
    a880:	97ffe91d 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a884:	97ffebdf 	bl	5800 <fwp_rc_fresh>
    a888:	aa0003e2 	mov	x2, x0
    a88c:	910ca3e1 	add	x1, sp, #0x328
    a890:	52800020 	mov	w0, #0x1                   	// #1
    a894:	f90197f7 	str	x23, [sp, #808]
    a898:	f9019be2 	str	x2, [sp, #816]
    a89c:	97ffe916 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a8a0:	97ffebd8 	bl	5800 <fwp_rc_fresh>
    a8a4:	aa0003e2 	mov	x2, x0
    a8a8:	910ce3e1 	add	x1, sp, #0x338
    a8ac:	52800020 	mov	w0, #0x1                   	// #1
    a8b0:	f9019ff5 	str	x21, [sp, #824]
    a8b4:	f901a3e2 	str	x2, [sp, #832]
    a8b8:	97ffe90f 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a8bc:	97ffebd1 	bl	5800 <fwp_rc_fresh>
    a8c0:	aa0003e2 	mov	x2, x0
    a8c4:	910d23e1 	add	x1, sp, #0x348
    a8c8:	52800020 	mov	w0, #0x1                   	// #1
    a8cc:	f901a7f7 	str	x23, [sp, #840]
    a8d0:	f901abe2 	str	x2, [sp, #848]
    a8d4:	97ffe908 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a8d8:	97ffebca 	bl	5800 <fwp_rc_fresh>
    a8dc:	aa0003e2 	mov	x2, x0
    a8e0:	910d63e1 	add	x1, sp, #0x358
    a8e4:	52800020 	mov	w0, #0x1                   	// #1
    a8e8:	f901aff5 	str	x21, [sp, #856]
    a8ec:	f901b3e2 	str	x2, [sp, #864]
    a8f0:	97ffe901 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a8f4:	97ffebc3 	bl	5800 <fwp_rc_fresh>
    a8f8:	aa0003e2 	mov	x2, x0
    a8fc:	910da3e1 	add	x1, sp, #0x368
    a900:	52800020 	mov	w0, #0x1                   	// #1
    a904:	f901b7f7 	str	x23, [sp, #872]
    a908:	f901bbe2 	str	x2, [sp, #880]
    a90c:	97ffe8fa 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a910:	97ffebbc 	bl	5800 <fwp_rc_fresh>
    a914:	aa0003e2 	mov	x2, x0
    a918:	910de3e1 	add	x1, sp, #0x378
    a91c:	52800020 	mov	w0, #0x1                   	// #1
    a920:	f901bff5 	str	x21, [sp, #888]
    a924:	f901c3e2 	str	x2, [sp, #896]
    a928:	97ffe8f3 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a92c:	97ffebb5 	bl	5800 <fwp_rc_fresh>
    a930:	aa0003e2 	mov	x2, x0
    a934:	910e23e1 	add	x1, sp, #0x388
    a938:	52800020 	mov	w0, #0x1                   	// #1
    a93c:	f901c7f7 	str	x23, [sp, #904]
    a940:	f901cbe2 	str	x2, [sp, #912]
    a944:	97ffe8ec 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a948:	97ffebae 	bl	5800 <fwp_rc_fresh>
    a94c:	aa0003e2 	mov	x2, x0
    a950:	910e63e1 	add	x1, sp, #0x398
    a954:	52800020 	mov	w0, #0x1                   	// #1
    a958:	f901cff5 	str	x21, [sp, #920]
    a95c:	f901d3e2 	str	x2, [sp, #928]
    a960:	97ffe8e5 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a964:	9114c283 	add	x3, x20, #0x530
    a968:	aa0003f5 	mov	x21, x0
    a96c:	f949d861 	ldr	x1, [x3, #5040]
    a970:	f949ec60 	ldr	x0, [x3, #5080]
    a974:	cb0102a1 	sub	x1, x21, x1
    a978:	eb00403f 	cmp	x1, x0, lsl #16
    a97c:	54000322 	b.cs	a9e0 <f0+0xbbc>  // b.hs, b.nlast
    a980:	d350fc22 	lsr	x2, x1, #16
    a984:	f949fc63 	ldr	x3, [x3, #5112]
    a988:	8b020842 	add	x2, x2, x2, lsl #2
    a98c:	d37df042 	lsl	x2, x2, #3
    a990:	8b020060 	add	x0, x3, x2
    a994:	f9401017 	ldr	x23, [x0, #32]
    a998:	b4000257 	cbz	x23, a9e0 <f0+0xbbc>
    a99c:	38626862 	ldrb	w2, [x3, x2]
    a9a0:	7100085f 	cmp	w2, #0x2
    a9a4:	5400c440 	b.eq	c22c <f0+0x2408>  // b.none
    a9a8:	7100045f 	cmp	w2, #0x1
    a9ac:	540001a1 	b.ne	a9e0 <f0+0xbbc>  // b.any
    a9b0:	29430002 	ldp	w2, w0, [x0, #24]
    a9b4:	92403c21 	and	x1, x1, #0xffff
    a9b8:	9b027c21 	mul	x1, x1, x2
    a9bc:	d360fc21 	lsr	x1, x1, #32
    a9c0:	eb00003f 	cmp	x1, x0
    a9c4:	540000e2 	b.cs	a9e0 <f0+0xbbc>  // b.hs, b.nlast
    a9c8:	8b0102f7 	add	x23, x23, x1
    a9cc:	394002e0 	ldrb	w0, [x23]
    a9d0:	7103fc1f 	cmp	w0, #0xff
    a9d4:	5400cb60 	b.eq	c340 <f0+0x251c>  // b.none
    a9d8:	52800020 	mov	w0, #0x1                   	// #1
    a9dc:	390002e0 	strb	w0, [x23]
    a9e0:	910ea3e1 	add	x1, sp, #0x3a8
    a9e4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a9e8:	52800020 	mov	w0, #0x1                   	// #1
    a9ec:	f901d7e2 	str	x2, [sp, #936]
    a9f0:	f901dbf5 	str	x21, [sp, #944]
    a9f4:	97ffe8c0 	bl	4cf4 <fwp_data.part.0.constprop.0>
    a9f8:	97ffeb82 	bl	5800 <fwp_rc_fresh>
    a9fc:	aa0003e2 	mov	x2, x0
    aa00:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aa04:	910ee3e1 	add	x1, sp, #0x3b8
    aa08:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aa0c:	52800020 	mov	w0, #0x1                   	// #1
    aa10:	f901dfe3 	str	x3, [sp, #952]
    aa14:	f901e3e2 	str	x2, [sp, #960]
    aa18:	97ffe8b7 	bl	4cf4 <fwp_data.part.0.constprop.0>
    aa1c:	9114c283 	add	x3, x20, #0x530
    aa20:	aa0003f5 	mov	x21, x0
    aa24:	f949d861 	ldr	x1, [x3, #5040]
    aa28:	f949ec60 	ldr	x0, [x3, #5080]
    aa2c:	cb0102a1 	sub	x1, x21, x1
    aa30:	eb00403f 	cmp	x1, x0, lsl #16
    aa34:	54000322 	b.cs	aa98 <f0+0xc74>  // b.hs, b.nlast
    aa38:	d350fc22 	lsr	x2, x1, #16
    aa3c:	f949fc63 	ldr	x3, [x3, #5112]
    aa40:	8b020842 	add	x2, x2, x2, lsl #2
    aa44:	d37df042 	lsl	x2, x2, #3
    aa48:	8b020060 	add	x0, x3, x2
    aa4c:	f9401017 	ldr	x23, [x0, #32]
    aa50:	b4000257 	cbz	x23, aa98 <f0+0xc74>
    aa54:	38626862 	ldrb	w2, [x3, x2]
    aa58:	7100085f 	cmp	w2, #0x2
    aa5c:	5400be20 	b.eq	c220 <f0+0x23fc>  // b.none
    aa60:	7100045f 	cmp	w2, #0x1
    aa64:	540001a1 	b.ne	aa98 <f0+0xc74>  // b.any
    aa68:	29430002 	ldp	w2, w0, [x0, #24]
    aa6c:	92403c21 	and	x1, x1, #0xffff
    aa70:	9b027c21 	mul	x1, x1, x2
    aa74:	d360fc21 	lsr	x1, x1, #32
    aa78:	eb00003f 	cmp	x1, x0
    aa7c:	540000e2 	b.cs	aa98 <f0+0xc74>  // b.hs, b.nlast
    aa80:	8b0102f7 	add	x23, x23, x1
    aa84:	394002e0 	ldrb	w0, [x23]
    aa88:	7103fc1f 	cmp	w0, #0xff
    aa8c:	5400c600 	b.eq	c34c <f0+0x2528>  // b.none
    aa90:	52800020 	mov	w0, #0x1                   	// #1
    aa94:	390002e0 	strb	w0, [x23]
    aa98:	910f23e1 	add	x1, sp, #0x3c8
    aa9c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aaa0:	52800020 	mov	w0, #0x1                   	// #1
    aaa4:	f901e7e2 	str	x2, [sp, #968]
    aaa8:	f901ebf5 	str	x21, [sp, #976]
    aaac:	97ffe892 	bl	4cf4 <fwp_data.part.0.constprop.0>
    aab0:	97ffeb54 	bl	5800 <fwp_rc_fresh>
    aab4:	aa0003e2 	mov	x2, x0
    aab8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aabc:	910f63e1 	add	x1, sp, #0x3d8
    aac0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aac4:	52800020 	mov	w0, #0x1                   	// #1
    aac8:	f901efe3 	str	x3, [sp, #984]
    aacc:	f901f3e2 	str	x2, [sp, #992]
    aad0:	97ffe889 	bl	4cf4 <fwp_data.part.0.constprop.0>
    aad4:	9114c283 	add	x3, x20, #0x530
    aad8:	aa0003f5 	mov	x21, x0
    aadc:	f949d861 	ldr	x1, [x3, #5040]
    aae0:	f949ec60 	ldr	x0, [x3, #5080]
    aae4:	cb0102a1 	sub	x1, x21, x1
    aae8:	eb00403f 	cmp	x1, x0, lsl #16
    aaec:	54000322 	b.cs	ab50 <f0+0xd2c>  // b.hs, b.nlast
    aaf0:	d350fc22 	lsr	x2, x1, #16
    aaf4:	f949fc63 	ldr	x3, [x3, #5112]
    aaf8:	8b020842 	add	x2, x2, x2, lsl #2
    aafc:	d37df042 	lsl	x2, x2, #3
    ab00:	8b020060 	add	x0, x3, x2
    ab04:	f9401017 	ldr	x23, [x0, #32]
    ab08:	b4000257 	cbz	x23, ab50 <f0+0xd2c>
    ab0c:	38626862 	ldrb	w2, [x3, x2]
    ab10:	7100085f 	cmp	w2, #0x2
    ab14:	5400b980 	b.eq	c244 <f0+0x2420>  // b.none
    ab18:	7100045f 	cmp	w2, #0x1
    ab1c:	540001a1 	b.ne	ab50 <f0+0xd2c>  // b.any
    ab20:	29430002 	ldp	w2, w0, [x0, #24]
    ab24:	92403c21 	and	x1, x1, #0xffff
    ab28:	9b027c21 	mul	x1, x1, x2
    ab2c:	d360fc21 	lsr	x1, x1, #32
    ab30:	eb00003f 	cmp	x1, x0
    ab34:	540000e2 	b.cs	ab50 <f0+0xd2c>  // b.hs, b.nlast
    ab38:	8b0102f7 	add	x23, x23, x1
    ab3c:	394002e0 	ldrb	w0, [x23]
    ab40:	7103fc1f 	cmp	w0, #0xff
    ab44:	5400c0a0 	b.eq	c358 <f0+0x2534>  // b.none
    ab48:	52800020 	mov	w0, #0x1                   	// #1
    ab4c:	390002e0 	strb	w0, [x23]
    ab50:	910fa3e1 	add	x1, sp, #0x3e8
    ab54:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab58:	52800020 	mov	w0, #0x1                   	// #1
    ab5c:	f901f7e2 	str	x2, [sp, #1000]
    ab60:	f901fbf5 	str	x21, [sp, #1008]
    ab64:	97ffe864 	bl	4cf4 <fwp_data.part.0.constprop.0>
    ab68:	97ffeb26 	bl	5800 <fwp_rc_fresh>
    ab6c:	aa0003e2 	mov	x2, x0
    ab70:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ab74:	910fe3e1 	add	x1, sp, #0x3f8
    ab78:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ab7c:	52800020 	mov	w0, #0x1                   	// #1
    ab80:	f901ffe3 	str	x3, [sp, #1016]
    ab84:	f90203e2 	str	x2, [sp, #1024]
    ab88:	97ffe85b 	bl	4cf4 <fwp_data.part.0.constprop.0>
    ab8c:	9114c283 	add	x3, x20, #0x530
    ab90:	aa0003f5 	mov	x21, x0
    ab94:	f949d861 	ldr	x1, [x3, #5040]
    ab98:	f949ec60 	ldr	x0, [x3, #5080]
    ab9c:	cb0102a1 	sub	x1, x21, x1
    aba0:	eb00403f 	cmp	x1, x0, lsl #16
    aba4:	54000322 	b.cs	ac08 <f0+0xde4>  // b.hs, b.nlast
    aba8:	d350fc22 	lsr	x2, x1, #16
    abac:	f949fc63 	ldr	x3, [x3, #5112]
    abb0:	8b020842 	add	x2, x2, x2, lsl #2
    abb4:	d37df042 	lsl	x2, x2, #3
    abb8:	8b020060 	add	x0, x3, x2
    abbc:	f9401017 	ldr	x23, [x0, #32]
    abc0:	b4000257 	cbz	x23, ac08 <f0+0xde4>
    abc4:	38626862 	ldrb	w2, [x3, x2]
    abc8:	7100085f 	cmp	w2, #0x2
    abcc:	5400b360 	b.eq	c238 <f0+0x2414>  // b.none
    abd0:	7100045f 	cmp	w2, #0x1
    abd4:	540001a1 	b.ne	ac08 <f0+0xde4>  // b.any
    abd8:	29430002 	ldp	w2, w0, [x0, #24]
    abdc:	92403c21 	and	x1, x1, #0xffff
    abe0:	9b027c21 	mul	x1, x1, x2
    abe4:	d360fc21 	lsr	x1, x1, #32
    abe8:	eb00003f 	cmp	x1, x0
    abec:	540000e2 	b.cs	ac08 <f0+0xde4>  // b.hs, b.nlast
    abf0:	8b0102f7 	add	x23, x23, x1
    abf4:	394002e0 	ldrb	w0, [x23]
    abf8:	7103fc1f 	cmp	w0, #0xff
    abfc:	5400bb40 	b.eq	c364 <f0+0x2540>  // b.none
    ac00:	52800020 	mov	w0, #0x1                   	// #1
    ac04:	390002e0 	strb	w0, [x23]
    ac08:	911023e1 	add	x1, sp, #0x408
    ac0c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ac10:	52800020 	mov	w0, #0x1                   	// #1
    ac14:	f90207f7 	str	x23, [sp, #1032]
    ac18:	f9020bf5 	str	x21, [sp, #1040]
    ac1c:	97ffe836 	bl	4cf4 <fwp_data.part.0.constprop.0>
    ac20:	97ffeaf8 	bl	5800 <fwp_rc_fresh>
    ac24:	aa0003e2 	mov	x2, x0
    ac28:	911063e1 	add	x1, sp, #0x418
    ac2c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ac30:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ac34:	52800020 	mov	w0, #0x1                   	// #1
    ac38:	f9020ff5 	str	x21, [sp, #1048]
    ac3c:	f90213e2 	str	x2, [sp, #1056]
    ac40:	97ffe82d 	bl	4cf4 <fwp_data.part.0.constprop.0>
    ac44:	97ffeaef 	bl	5800 <fwp_rc_fresh>
    ac48:	aa0003e2 	mov	x2, x0
    ac4c:	9110a3e1 	add	x1, sp, #0x428
    ac50:	52800020 	mov	w0, #0x1                   	// #1
    ac54:	f90217f7 	str	x23, [sp, #1064]
    ac58:	f9021be2 	str	x2, [sp, #1072]
    ac5c:	97ffe826 	bl	4cf4 <fwp_data.part.0.constprop.0>
    ac60:	97ffeae8 	bl	5800 <fwp_rc_fresh>
    ac64:	aa0003e2 	mov	x2, x0
    ac68:	9110e3e1 	add	x1, sp, #0x438
    ac6c:	52800020 	mov	w0, #0x1                   	// #1
    ac70:	f9021ff5 	str	x21, [sp, #1080]
    ac74:	f90223e2 	str	x2, [sp, #1088]
    ac78:	97ffe81f 	bl	4cf4 <fwp_data.part.0.constprop.0>
    ac7c:	97ffeae1 	bl	5800 <fwp_rc_fresh>
    ac80:	aa0003e2 	mov	x2, x0
    ac84:	911123e1 	add	x1, sp, #0x448
    ac88:	52800020 	mov	w0, #0x1                   	// #1
    ac8c:	f90227f7 	str	x23, [sp, #1096]
    ac90:	f9022be2 	str	x2, [sp, #1104]
    ac94:	97ffe818 	bl	4cf4 <fwp_data.part.0.constprop.0>
    ac98:	9114c283 	add	x3, x20, #0x530
    ac9c:	aa0003f5 	mov	x21, x0
    aca0:	f949d861 	ldr	x1, [x3, #5040]
    aca4:	f949ec60 	ldr	x0, [x3, #5080]
    aca8:	cb0102a1 	sub	x1, x21, x1
    acac:	eb00403f 	cmp	x1, x0, lsl #16
    acb0:	54000322 	b.cs	ad14 <f0+0xef0>  // b.hs, b.nlast
    acb4:	d350fc22 	lsr	x2, x1, #16
    acb8:	f949fc63 	ldr	x3, [x3, #5112]
    acbc:	8b020842 	add	x2, x2, x2, lsl #2
    acc0:	d37df042 	lsl	x2, x2, #3
    acc4:	8b020060 	add	x0, x3, x2
    acc8:	f9401017 	ldr	x23, [x0, #32]
    accc:	b4000257 	cbz	x23, ad14 <f0+0xef0>
    acd0:	38626862 	ldrb	w2, [x3, x2]
    acd4:	7100085f 	cmp	w2, #0x2
    acd8:	5400ac20 	b.eq	c25c <f0+0x2438>  // b.none
    acdc:	7100045f 	cmp	w2, #0x1
    ace0:	540001a1 	b.ne	ad14 <f0+0xef0>  // b.any
    ace4:	29430002 	ldp	w2, w0, [x0, #24]
    ace8:	92403c21 	and	x1, x1, #0xffff
    acec:	9b027c21 	mul	x1, x1, x2
    acf0:	d360fc21 	lsr	x1, x1, #32
    acf4:	eb00003f 	cmp	x1, x0
    acf8:	540000e2 	b.cs	ad14 <f0+0xef0>  // b.hs, b.nlast
    acfc:	8b0102f7 	add	x23, x23, x1
    ad00:	394002e0 	ldrb	w0, [x23]
    ad04:	7103fc1f 	cmp	w0, #0xff
    ad08:	5400b340 	b.eq	c370 <f0+0x254c>  // b.none
    ad0c:	52800020 	mov	w0, #0x1                   	// #1
    ad10:	390002e0 	strb	w0, [x23]
    ad14:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ad18:	911163e1 	add	x1, sp, #0x458
    ad1c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ad20:	52800020 	mov	w0, #0x1                   	// #1
    ad24:	f9022fe2 	str	x2, [sp, #1112]
    ad28:	f90233f5 	str	x21, [sp, #1120]
    ad2c:	97ffe7f2 	bl	4cf4 <fwp_data.part.0.constprop.0>
    ad30:	9114c283 	add	x3, x20, #0x530
    ad34:	aa0003f5 	mov	x21, x0
    ad38:	f949d861 	ldr	x1, [x3, #5040]
    ad3c:	f949ec60 	ldr	x0, [x3, #5080]
    ad40:	cb0102a1 	sub	x1, x21, x1
    ad44:	eb00403f 	cmp	x1, x0, lsl #16
    ad48:	54000322 	b.cs	adac <f0+0xf88>  // b.hs, b.nlast
    ad4c:	d350fc22 	lsr	x2, x1, #16
    ad50:	f949fc63 	ldr	x3, [x3, #5112]
    ad54:	8b020842 	add	x2, x2, x2, lsl #2
    ad58:	d37df042 	lsl	x2, x2, #3
    ad5c:	8b020060 	add	x0, x3, x2
    ad60:	f9401017 	ldr	x23, [x0, #32]
    ad64:	b4000257 	cbz	x23, adac <f0+0xf88>
    ad68:	38626862 	ldrb	w2, [x3, x2]
    ad6c:	7100085f 	cmp	w2, #0x2
    ad70:	5400a700 	b.eq	c250 <f0+0x242c>  // b.none
    ad74:	7100045f 	cmp	w2, #0x1
    ad78:	540001a1 	b.ne	adac <f0+0xf88>  // b.any
    ad7c:	29430002 	ldp	w2, w0, [x0, #24]
    ad80:	92403c21 	and	x1, x1, #0xffff
    ad84:	9b027c21 	mul	x1, x1, x2
    ad88:	d360fc21 	lsr	x1, x1, #32
    ad8c:	eb00003f 	cmp	x1, x0
    ad90:	540000e2 	b.cs	adac <f0+0xf88>  // b.hs, b.nlast
    ad94:	8b0102f7 	add	x23, x23, x1
    ad98:	394002e0 	ldrb	w0, [x23]
    ad9c:	7103fc1f 	cmp	w0, #0xff
    ada0:	5400aee0 	b.eq	c37c <f0+0x2558>  // b.none
    ada4:	52800020 	mov	w0, #0x1                   	// #1
    ada8:	390002e0 	strb	w0, [x23]
    adac:	9111a3e1 	add	x1, sp, #0x468
    adb0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    adb4:	52800020 	mov	w0, #0x1                   	// #1
    adb8:	f90237e2 	str	x2, [sp, #1128]
    adbc:	f9023bf5 	str	x21, [sp, #1136]
    adc0:	97ffe7cd 	bl	4cf4 <fwp_data.part.0.constprop.0>
    adc4:	97ffea8f 	bl	5800 <fwp_rc_fresh>
    adc8:	aa0003e2 	mov	x2, x0
    adcc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    add0:	9111e3e1 	add	x1, sp, #0x478
    add4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    add8:	52800020 	mov	w0, #0x1                   	// #1
    addc:	f9023fe3 	str	x3, [sp, #1144]
    ade0:	f90243e2 	str	x2, [sp, #1152]
    ade4:	97ffe7c4 	bl	4cf4 <fwp_data.part.0.constprop.0>
    ade8:	9114c283 	add	x3, x20, #0x530
    adec:	aa0003f5 	mov	x21, x0
    adf0:	f949d861 	ldr	x1, [x3, #5040]
    adf4:	f949ec60 	ldr	x0, [x3, #5080]
    adf8:	cb0102a1 	sub	x1, x21, x1
    adfc:	eb00403f 	cmp	x1, x0, lsl #16
    ae00:	54000322 	b.cs	ae64 <f0+0x1040>  // b.hs, b.nlast
    ae04:	d350fc22 	lsr	x2, x1, #16
    ae08:	f949fc63 	ldr	x3, [x3, #5112]
    ae0c:	8b020842 	add	x2, x2, x2, lsl #2
    ae10:	d37df042 	lsl	x2, x2, #3
    ae14:	8b020060 	add	x0, x3, x2
    ae18:	f9401017 	ldr	x23, [x0, #32]
    ae1c:	b4000257 	cbz	x23, ae64 <f0+0x1040>
    ae20:	38626862 	ldrb	w2, [x3, x2]
    ae24:	7100085f 	cmp	w2, #0x2
    ae28:	5400a260 	b.eq	c274 <f0+0x2450>  // b.none
    ae2c:	7100045f 	cmp	w2, #0x1
    ae30:	540001a1 	b.ne	ae64 <f0+0x1040>  // b.any
    ae34:	29430002 	ldp	w2, w0, [x0, #24]
    ae38:	92403c21 	and	x1, x1, #0xffff
    ae3c:	9b027c21 	mul	x1, x1, x2
    ae40:	d360fc21 	lsr	x1, x1, #32
    ae44:	eb00003f 	cmp	x1, x0
    ae48:	540000e2 	b.cs	ae64 <f0+0x1040>  // b.hs, b.nlast
    ae4c:	8b0102f7 	add	x23, x23, x1
    ae50:	394002e0 	ldrb	w0, [x23]
    ae54:	7103fc1f 	cmp	w0, #0xff
    ae58:	5400a980 	b.eq	c388 <f0+0x2564>  // b.none
    ae5c:	52800020 	mov	w0, #0x1                   	// #1
    ae60:	390002e0 	strb	w0, [x23]
    ae64:	911223e1 	add	x1, sp, #0x488
    ae68:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ae6c:	52800020 	mov	w0, #0x1                   	// #1
    ae70:	f90247e2 	str	x2, [sp, #1160]
    ae74:	f9024bf5 	str	x21, [sp, #1168]
    ae78:	97ffe79f 	bl	4cf4 <fwp_data.part.0.constprop.0>
    ae7c:	97ffea61 	bl	5800 <fwp_rc_fresh>
    ae80:	aa0003e2 	mov	x2, x0
    ae84:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ae88:	911263e1 	add	x1, sp, #0x498
    ae8c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ae90:	52800020 	mov	w0, #0x1                   	// #1
    ae94:	f9024fe3 	str	x3, [sp, #1176]
    ae98:	f90253e2 	str	x2, [sp, #1184]
    ae9c:	97ffe796 	bl	4cf4 <fwp_data.part.0.constprop.0>
    aea0:	9114c283 	add	x3, x20, #0x530
    aea4:	aa0003f5 	mov	x21, x0
    aea8:	f949d861 	ldr	x1, [x3, #5040]
    aeac:	f949ec60 	ldr	x0, [x3, #5080]
    aeb0:	cb0102a1 	sub	x1, x21, x1
    aeb4:	eb00403f 	cmp	x1, x0, lsl #16
    aeb8:	54000322 	b.cs	af1c <f0+0x10f8>  // b.hs, b.nlast
    aebc:	d350fc22 	lsr	x2, x1, #16
    aec0:	f949fc63 	ldr	x3, [x3, #5112]
    aec4:	8b020842 	add	x2, x2, x2, lsl #2
    aec8:	d37df042 	lsl	x2, x2, #3
    aecc:	8b020060 	add	x0, x3, x2
    aed0:	f9401017 	ldr	x23, [x0, #32]
    aed4:	b4000257 	cbz	x23, af1c <f0+0x10f8>
    aed8:	38626862 	ldrb	w2, [x3, x2]
    aedc:	7100085f 	cmp	w2, #0x2
    aee0:	54009c40 	b.eq	c268 <f0+0x2444>  // b.none
    aee4:	7100045f 	cmp	w2, #0x1
    aee8:	540001a1 	b.ne	af1c <f0+0x10f8>  // b.any
    aeec:	29430002 	ldp	w2, w0, [x0, #24]
    aef0:	92403c21 	and	x1, x1, #0xffff
    aef4:	9b027c21 	mul	x1, x1, x2
    aef8:	d360fc21 	lsr	x1, x1, #32
    aefc:	eb00003f 	cmp	x1, x0
    af00:	540000e2 	b.cs	af1c <f0+0x10f8>  // b.hs, b.nlast
    af04:	8b0102f7 	add	x23, x23, x1
    af08:	394002e0 	ldrb	w0, [x23]
    af0c:	7103fc1f 	cmp	w0, #0xff
    af10:	5400a420 	b.eq	c394 <f0+0x2570>  // b.none
    af14:	52800020 	mov	w0, #0x1                   	// #1
    af18:	390002e0 	strb	w0, [x23]
    af1c:	9112a3e1 	add	x1, sp, #0x4a8
    af20:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    af24:	52800020 	mov	w0, #0x1                   	// #1
    af28:	f90257f7 	str	x23, [sp, #1192]
    af2c:	f9025bf5 	str	x21, [sp, #1200]
    af30:	97ffe771 	bl	4cf4 <fwp_data.part.0.constprop.0>
    af34:	97ffea33 	bl	5800 <fwp_rc_fresh>
    af38:	aa0003e2 	mov	x2, x0
    af3c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    af40:	9112e3e1 	add	x1, sp, #0x4b8
    af44:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    af48:	52800020 	mov	w0, #0x1                   	// #1
    af4c:	f9025fe3 	str	x3, [sp, #1208]
    af50:	f90263e2 	str	x2, [sp, #1216]
    af54:	97ffe768 	bl	4cf4 <fwp_data.part.0.constprop.0>
    af58:	97ffea2a 	bl	5800 <fwp_rc_fresh>
    af5c:	aa0003e2 	mov	x2, x0
    af60:	911323e1 	add	x1, sp, #0x4c8
    af64:	52800020 	mov	w0, #0x1                   	// #1
    af68:	f90267f7 	str	x23, [sp, #1224]
    af6c:	f9026be2 	str	x2, [sp, #1232]
    af70:	97ffe761 	bl	4cf4 <fwp_data.part.0.constprop.0>
    af74:	9114c283 	add	x3, x20, #0x530
    af78:	aa0003f5 	mov	x21, x0
    af7c:	f949d861 	ldr	x1, [x3, #5040]
    af80:	f949ec60 	ldr	x0, [x3, #5080]
    af84:	cb0102a1 	sub	x1, x21, x1
    af88:	eb00403f 	cmp	x1, x0, lsl #16
    af8c:	54000322 	b.cs	aff0 <f0+0x11cc>  // b.hs, b.nlast
    af90:	d350fc22 	lsr	x2, x1, #16
    af94:	f949fc63 	ldr	x3, [x3, #5112]
    af98:	8b020842 	add	x2, x2, x2, lsl #2
    af9c:	d37df042 	lsl	x2, x2, #3
    afa0:	8b020060 	add	x0, x3, x2
    afa4:	f9401017 	ldr	x23, [x0, #32]
    afa8:	b4000257 	cbz	x23, aff0 <f0+0x11cc>
    afac:	38626862 	ldrb	w2, [x3, x2]
    afb0:	7100085f 	cmp	w2, #0x2
    afb4:	540096c0 	b.eq	c28c <f0+0x2468>  // b.none
    afb8:	7100045f 	cmp	w2, #0x1
    afbc:	540001a1 	b.ne	aff0 <f0+0x11cc>  // b.any
    afc0:	29430002 	ldp	w2, w0, [x0, #24]
    afc4:	92403c21 	and	x1, x1, #0xffff
    afc8:	9b027c21 	mul	x1, x1, x2
    afcc:	d360fc21 	lsr	x1, x1, #32
    afd0:	eb00003f 	cmp	x1, x0
    afd4:	540000e2 	b.cs	aff0 <f0+0x11cc>  // b.hs, b.nlast
    afd8:	8b0102f7 	add	x23, x23, x1
    afdc:	394002e0 	ldrb	w0, [x23]
    afe0:	7103fc1f 	cmp	w0, #0xff
    afe4:	54009de0 	b.eq	c3a0 <f0+0x257c>  // b.none
    afe8:	52800020 	mov	w0, #0x1                   	// #1
    afec:	390002e0 	strb	w0, [x23]
    aff0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aff4:	911363e1 	add	x1, sp, #0x4d8
    aff8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    affc:	52800020 	mov	w0, #0x1                   	// #1
    b000:	f9026fe2 	str	x2, [sp, #1240]
    b004:	f90273f5 	str	x21, [sp, #1248]
    b008:	97ffe73b 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b00c:	9114c283 	add	x3, x20, #0x530
    b010:	aa0003f5 	mov	x21, x0
    b014:	f949d861 	ldr	x1, [x3, #5040]
    b018:	f949ec60 	ldr	x0, [x3, #5080]
    b01c:	cb0102a1 	sub	x1, x21, x1
    b020:	eb00403f 	cmp	x1, x0, lsl #16
    b024:	54000322 	b.cs	b088 <f0+0x1264>  // b.hs, b.nlast
    b028:	d350fc22 	lsr	x2, x1, #16
    b02c:	f949fc63 	ldr	x3, [x3, #5112]
    b030:	8b020842 	add	x2, x2, x2, lsl #2
    b034:	d37df042 	lsl	x2, x2, #3
    b038:	8b020060 	add	x0, x3, x2
    b03c:	f9401017 	ldr	x23, [x0, #32]
    b040:	b4000257 	cbz	x23, b088 <f0+0x1264>
    b044:	38626862 	ldrb	w2, [x3, x2]
    b048:	7100085f 	cmp	w2, #0x2
    b04c:	540091a0 	b.eq	c280 <f0+0x245c>  // b.none
    b050:	7100045f 	cmp	w2, #0x1
    b054:	540001a1 	b.ne	b088 <f0+0x1264>  // b.any
    b058:	29430002 	ldp	w2, w0, [x0, #24]
    b05c:	92403c21 	and	x1, x1, #0xffff
    b060:	9b027c21 	mul	x1, x1, x2
    b064:	d360fc21 	lsr	x1, x1, #32
    b068:	eb00003f 	cmp	x1, x0
    b06c:	540000e2 	b.cs	b088 <f0+0x1264>  // b.hs, b.nlast
    b070:	8b0102f7 	add	x23, x23, x1
    b074:	394002e0 	ldrb	w0, [x23]
    b078:	7103fc1f 	cmp	w0, #0xff
    b07c:	54009980 	b.eq	c3ac <f0+0x2588>  // b.none
    b080:	52800020 	mov	w0, #0x1                   	// #1
    b084:	390002e0 	strb	w0, [x23]
    b088:	9113a3e1 	add	x1, sp, #0x4e8
    b08c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b090:	52800020 	mov	w0, #0x1                   	// #1
    b094:	f90277e2 	str	x2, [sp, #1256]
    b098:	f9027bf5 	str	x21, [sp, #1264]
    b09c:	97ffe716 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b0a0:	97ffe9d8 	bl	5800 <fwp_rc_fresh>
    b0a4:	aa0003e2 	mov	x2, x0
    b0a8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b0ac:	9113e3e1 	add	x1, sp, #0x4f8
    b0b0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b0b4:	52800020 	mov	w0, #0x1                   	// #1
    b0b8:	f9027fe3 	str	x3, [sp, #1272]
    b0bc:	f90283e2 	str	x2, [sp, #1280]
    b0c0:	97ffe70d 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b0c4:	9114c283 	add	x3, x20, #0x530
    b0c8:	aa0003f5 	mov	x21, x0
    b0cc:	f949d861 	ldr	x1, [x3, #5040]
    b0d0:	f949ec60 	ldr	x0, [x3, #5080]
    b0d4:	cb0102a1 	sub	x1, x21, x1
    b0d8:	eb00403f 	cmp	x1, x0, lsl #16
    b0dc:	54000322 	b.cs	b140 <f0+0x131c>  // b.hs, b.nlast
    b0e0:	d350fc22 	lsr	x2, x1, #16
    b0e4:	f949fc63 	ldr	x3, [x3, #5112]
    b0e8:	8b020842 	add	x2, x2, x2, lsl #2
    b0ec:	d37df042 	lsl	x2, x2, #3
    b0f0:	8b020060 	add	x0, x3, x2
    b0f4:	f9401017 	ldr	x23, [x0, #32]
    b0f8:	b4000257 	cbz	x23, b140 <f0+0x131c>
    b0fc:	38626862 	ldrb	w2, [x3, x2]
    b100:	7100085f 	cmp	w2, #0x2
    b104:	54008d00 	b.eq	c2a4 <f0+0x2480>  // b.none
    b108:	7100045f 	cmp	w2, #0x1
    b10c:	540001a1 	b.ne	b140 <f0+0x131c>  // b.any
    b110:	29430002 	ldp	w2, w0, [x0, #24]
    b114:	92403c21 	and	x1, x1, #0xffff
    b118:	9b027c21 	mul	x1, x1, x2
    b11c:	d360fc21 	lsr	x1, x1, #32
    b120:	eb00003f 	cmp	x1, x0
    b124:	540000e2 	b.cs	b140 <f0+0x131c>  // b.hs, b.nlast
    b128:	8b0102f7 	add	x23, x23, x1
    b12c:	394002e0 	ldrb	w0, [x23]
    b130:	7103fc1f 	cmp	w0, #0xff
    b134:	54009420 	b.eq	c3b8 <f0+0x2594>  // b.none
    b138:	52800020 	mov	w0, #0x1                   	// #1
    b13c:	390002e0 	strb	w0, [x23]
    b140:	911423e1 	add	x1, sp, #0x508
    b144:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b148:	52800020 	mov	w0, #0x1                   	// #1
    b14c:	f90287e2 	str	x2, [sp, #1288]
    b150:	f9028bf5 	str	x21, [sp, #1296]
    b154:	97ffe6e8 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b158:	97ffe9aa 	bl	5800 <fwp_rc_fresh>
    b15c:	aa0003e2 	mov	x2, x0
    b160:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b164:	911463e1 	add	x1, sp, #0x518
    b168:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b16c:	52800020 	mov	w0, #0x1                   	// #1
    b170:	f9028fe3 	str	x3, [sp, #1304]
    b174:	f90293e2 	str	x2, [sp, #1312]
    b178:	97ffe6df 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b17c:	9114c283 	add	x3, x20, #0x530
    b180:	aa0003f5 	mov	x21, x0
    b184:	f949d861 	ldr	x1, [x3, #5040]
    b188:	f949ec60 	ldr	x0, [x3, #5080]
    b18c:	cb0102a1 	sub	x1, x21, x1
    b190:	eb00403f 	cmp	x1, x0, lsl #16
    b194:	54000322 	b.cs	b1f8 <f0+0x13d4>  // b.hs, b.nlast
    b198:	d350fc22 	lsr	x2, x1, #16
    b19c:	f949fc63 	ldr	x3, [x3, #5112]
    b1a0:	8b020842 	add	x2, x2, x2, lsl #2
    b1a4:	d37df042 	lsl	x2, x2, #3
    b1a8:	8b020060 	add	x0, x3, x2
    b1ac:	f9401017 	ldr	x23, [x0, #32]
    b1b0:	b4000257 	cbz	x23, b1f8 <f0+0x13d4>
    b1b4:	38626862 	ldrb	w2, [x3, x2]
    b1b8:	7100085f 	cmp	w2, #0x2
    b1bc:	540086e0 	b.eq	c298 <f0+0x2474>  // b.none
    b1c0:	7100045f 	cmp	w2, #0x1
    b1c4:	540001a1 	b.ne	b1f8 <f0+0x13d4>  // b.any
    b1c8:	29430002 	ldp	w2, w0, [x0, #24]
    b1cc:	92403c21 	and	x1, x1, #0xffff
    b1d0:	9b027c21 	mul	x1, x1, x2
    b1d4:	d360fc21 	lsr	x1, x1, #32
    b1d8:	eb00003f 	cmp	x1, x0
    b1dc:	540000e2 	b.cs	b1f8 <f0+0x13d4>  // b.hs, b.nlast
    b1e0:	8b0102f7 	add	x23, x23, x1
    b1e4:	394002e0 	ldrb	w0, [x23]
    b1e8:	7103fc1f 	cmp	w0, #0xff
    b1ec:	54008ec0 	b.eq	c3c4 <f0+0x25a0>  // b.none
    b1f0:	52800020 	mov	w0, #0x1                   	// #1
    b1f4:	390002e0 	strb	w0, [x23]
    b1f8:	9114a3e1 	add	x1, sp, #0x528
    b1fc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b200:	52800020 	mov	w0, #0x1                   	// #1
    b204:	f90297f7 	str	x23, [sp, #1320]
    b208:	f9029bf5 	str	x21, [sp, #1328]
    b20c:	97ffe6ba 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b210:	97ffe97c 	bl	5800 <fwp_rc_fresh>
    b214:	aa0003e2 	mov	x2, x0
    b218:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b21c:	9114e3e1 	add	x1, sp, #0x538
    b220:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b224:	52800020 	mov	w0, #0x1                   	// #1
    b228:	f9029fe3 	str	x3, [sp, #1336]
    b22c:	f902a3e2 	str	x2, [sp, #1344]
    b230:	97ffe6b1 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b234:	97ffe973 	bl	5800 <fwp_rc_fresh>
    b238:	aa0003e2 	mov	x2, x0
    b23c:	911523e1 	add	x1, sp, #0x548
    b240:	52800020 	mov	w0, #0x1                   	// #1
    b244:	f902a7f7 	str	x23, [sp, #1352]
    b248:	f902abe2 	str	x2, [sp, #1360]
    b24c:	97ffe6aa 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b250:	9114c283 	add	x3, x20, #0x530
    b254:	aa0003f5 	mov	x21, x0
    b258:	f949d861 	ldr	x1, [x3, #5040]
    b25c:	f949ec60 	ldr	x0, [x3, #5080]
    b260:	cb0102a1 	sub	x1, x21, x1
    b264:	eb00403f 	cmp	x1, x0, lsl #16
    b268:	54000322 	b.cs	b2cc <f0+0x14a8>  // b.hs, b.nlast
    b26c:	d350fc22 	lsr	x2, x1, #16
    b270:	f949fc63 	ldr	x3, [x3, #5112]
    b274:	8b020842 	add	x2, x2, x2, lsl #2
    b278:	d37df042 	lsl	x2, x2, #3
    b27c:	8b020060 	add	x0, x3, x2
    b280:	f9401017 	ldr	x23, [x0, #32]
    b284:	b4000257 	cbz	x23, b2cc <f0+0x14a8>
    b288:	38626862 	ldrb	w2, [x3, x2]
    b28c:	7100085f 	cmp	w2, #0x2
    b290:	54008160 	b.eq	c2bc <f0+0x2498>  // b.none
    b294:	7100045f 	cmp	w2, #0x1
    b298:	540001a1 	b.ne	b2cc <f0+0x14a8>  // b.any
    b29c:	29430002 	ldp	w2, w0, [x0, #24]
    b2a0:	92403c21 	and	x1, x1, #0xffff
    b2a4:	9b027c21 	mul	x1, x1, x2
    b2a8:	d360fc21 	lsr	x1, x1, #32
    b2ac:	eb00003f 	cmp	x1, x0
    b2b0:	540000e2 	b.cs	b2cc <f0+0x14a8>  // b.hs, b.nlast
    b2b4:	8b0102f7 	add	x23, x23, x1
    b2b8:	394002e0 	ldrb	w0, [x23]
    b2bc:	7103fc1f 	cmp	w0, #0xff
    b2c0:	54008880 	b.eq	c3d0 <f0+0x25ac>  // b.none
    b2c4:	52800020 	mov	w0, #0x1                   	// #1
    b2c8:	390002e0 	strb	w0, [x23]
    b2cc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b2d0:	911563e1 	add	x1, sp, #0x558
    b2d4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b2d8:	52800020 	mov	w0, #0x1                   	// #1
    b2dc:	f902afe2 	str	x2, [sp, #1368]
    b2e0:	f902b3f5 	str	x21, [sp, #1376]
    b2e4:	97ffe684 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b2e8:	9114c283 	add	x3, x20, #0x530
    b2ec:	aa0003f5 	mov	x21, x0
    b2f0:	f949d861 	ldr	x1, [x3, #5040]
    b2f4:	f949ec60 	ldr	x0, [x3, #5080]
    b2f8:	cb0102a1 	sub	x1, x21, x1
    b2fc:	eb00403f 	cmp	x1, x0, lsl #16
    b300:	54000322 	b.cs	b364 <f0+0x1540>  // b.hs, b.nlast
    b304:	d350fc22 	lsr	x2, x1, #16
    b308:	f949fc63 	ldr	x3, [x3, #5112]
    b30c:	8b020842 	add	x2, x2, x2, lsl #2
    b310:	d37df042 	lsl	x2, x2, #3
    b314:	8b020060 	add	x0, x3, x2
    b318:	f9401017 	ldr	x23, [x0, #32]
    b31c:	b4000257 	cbz	x23, b364 <f0+0x1540>
    b320:	38626862 	ldrb	w2, [x3, x2]
    b324:	7100085f 	cmp	w2, #0x2
    b328:	54007c40 	b.eq	c2b0 <f0+0x248c>  // b.none
    b32c:	7100045f 	cmp	w2, #0x1
    b330:	540001a1 	b.ne	b364 <f0+0x1540>  // b.any
    b334:	29430002 	ldp	w2, w0, [x0, #24]
    b338:	92403c21 	and	x1, x1, #0xffff
    b33c:	9b027c21 	mul	x1, x1, x2
    b340:	d360fc21 	lsr	x1, x1, #32
    b344:	eb00003f 	cmp	x1, x0
    b348:	540000e2 	b.cs	b364 <f0+0x1540>  // b.hs, b.nlast
    b34c:	8b0102f7 	add	x23, x23, x1
    b350:	394002e0 	ldrb	w0, [x23]
    b354:	7103fc1f 	cmp	w0, #0xff
    b358:	54008420 	b.eq	c3dc <f0+0x25b8>  // b.none
    b35c:	52800020 	mov	w0, #0x1                   	// #1
    b360:	390002e0 	strb	w0, [x23]
    b364:	9115a3e1 	add	x1, sp, #0x568
    b368:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b36c:	52800020 	mov	w0, #0x1                   	// #1
    b370:	f902b7f7 	str	x23, [sp, #1384]
    b374:	f902bbf5 	str	x21, [sp, #1392]
    b378:	97ffe65f 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b37c:	97ffe921 	bl	5800 <fwp_rc_fresh>
    b380:	aa0003e2 	mov	x2, x0
    b384:	9115e3e1 	add	x1, sp, #0x578
    b388:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b38c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b390:	52800020 	mov	w0, #0x1                   	// #1
    b394:	f902bff5 	str	x21, [sp, #1400]
    b398:	f902c3e2 	str	x2, [sp, #1408]
    b39c:	97ffe656 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b3a0:	97ffe918 	bl	5800 <fwp_rc_fresh>
    b3a4:	aa0003e2 	mov	x2, x0
    b3a8:	911623e1 	add	x1, sp, #0x588
    b3ac:	52800020 	mov	w0, #0x1                   	// #1
    b3b0:	f902c7f7 	str	x23, [sp, #1416]
    b3b4:	f902cbe2 	str	x2, [sp, #1424]
    b3b8:	97ffe64f 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b3bc:	97ffe911 	bl	5800 <fwp_rc_fresh>
    b3c0:	aa0003e2 	mov	x2, x0
    b3c4:	911663e1 	add	x1, sp, #0x598
    b3c8:	52800020 	mov	w0, #0x1                   	// #1
    b3cc:	f902cff5 	str	x21, [sp, #1432]
    b3d0:	f902d3e2 	str	x2, [sp, #1440]
    b3d4:	97ffe648 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b3d8:	9114c283 	add	x3, x20, #0x530
    b3dc:	aa0003f5 	mov	x21, x0
    b3e0:	f949d861 	ldr	x1, [x3, #5040]
    b3e4:	f949ec60 	ldr	x0, [x3, #5080]
    b3e8:	cb0102a1 	sub	x1, x21, x1
    b3ec:	eb00403f 	cmp	x1, x0, lsl #16
    b3f0:	54000322 	b.cs	b454 <f0+0x1630>  // b.hs, b.nlast
    b3f4:	d350fc22 	lsr	x2, x1, #16
    b3f8:	f949fc63 	ldr	x3, [x3, #5112]
    b3fc:	8b020842 	add	x2, x2, x2, lsl #2
    b400:	d37df042 	lsl	x2, x2, #3
    b404:	8b020060 	add	x0, x3, x2
    b408:	f9401017 	ldr	x23, [x0, #32]
    b40c:	b4000257 	cbz	x23, b454 <f0+0x1630>
    b410:	38626862 	ldrb	w2, [x3, x2]
    b414:	7100085f 	cmp	w2, #0x2
    b418:	540069e0 	b.eq	c154 <f0+0x2330>  // b.none
    b41c:	7100045f 	cmp	w2, #0x1
    b420:	540001a1 	b.ne	b454 <f0+0x1630>  // b.any
    b424:	29430002 	ldp	w2, w0, [x0, #24]
    b428:	92403c21 	and	x1, x1, #0xffff
    b42c:	9b027c21 	mul	x1, x1, x2
    b430:	d360fc21 	lsr	x1, x1, #32
    b434:	eb00003f 	cmp	x1, x0
    b438:	540000e2 	b.cs	b454 <f0+0x1630>  // b.hs, b.nlast
    b43c:	8b0102f7 	add	x23, x23, x1
    b440:	394002e0 	ldrb	w0, [x23]
    b444:	7103fc1f 	cmp	w0, #0xff
    b448:	54007d00 	b.eq	c3e8 <f0+0x25c4>  // b.none
    b44c:	52800020 	mov	w0, #0x1                   	// #1
    b450:	390002e0 	strb	w0, [x23]
    b454:	9116a3e1 	add	x1, sp, #0x5a8
    b458:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b45c:	52800020 	mov	w0, #0x1                   	// #1
    b460:	f902d7f7 	str	x23, [sp, #1448]
    b464:	f902dbf5 	str	x21, [sp, #1456]
    b468:	97ffe623 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b46c:	97ffe8e5 	bl	5800 <fwp_rc_fresh>
    b470:	aa0003e2 	mov	x2, x0
    b474:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b478:	9116e3e1 	add	x1, sp, #0x5b8
    b47c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b480:	52800020 	mov	w0, #0x1                   	// #1
    b484:	f902dfe3 	str	x3, [sp, #1464]
    b488:	f902e3e2 	str	x2, [sp, #1472]
    b48c:	97ffe61a 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b490:	97ffe8dc 	bl	5800 <fwp_rc_fresh>
    b494:	aa0003e2 	mov	x2, x0
    b498:	911723e1 	add	x1, sp, #0x5c8
    b49c:	52800020 	mov	w0, #0x1                   	// #1
    b4a0:	f902e7f7 	str	x23, [sp, #1480]
    b4a4:	f902ebe2 	str	x2, [sp, #1488]
    b4a8:	97ffe613 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b4ac:	9114c283 	add	x3, x20, #0x530
    b4b0:	aa0003f5 	mov	x21, x0
    b4b4:	f949d861 	ldr	x1, [x3, #5040]
    b4b8:	f949ec60 	ldr	x0, [x3, #5080]
    b4bc:	cb0102a1 	sub	x1, x21, x1
    b4c0:	eb00403f 	cmp	x1, x0, lsl #16
    b4c4:	54000322 	b.cs	b528 <f0+0x1704>  // b.hs, b.nlast
    b4c8:	d350fc22 	lsr	x2, x1, #16
    b4cc:	f949fc63 	ldr	x3, [x3, #5112]
    b4d0:	8b020842 	add	x2, x2, x2, lsl #2
    b4d4:	d37df042 	lsl	x2, x2, #3
    b4d8:	8b020060 	add	x0, x3, x2
    b4dc:	f9401017 	ldr	x23, [x0, #32]
    b4e0:	b4000257 	cbz	x23, b528 <f0+0x1704>
    b4e4:	38626862 	ldrb	w2, [x3, x2]
    b4e8:	7100085f 	cmp	w2, #0x2
    b4ec:	540062e0 	b.eq	c148 <f0+0x2324>  // b.none
    b4f0:	7100045f 	cmp	w2, #0x1
    b4f4:	540001a1 	b.ne	b528 <f0+0x1704>  // b.any
    b4f8:	29430002 	ldp	w2, w0, [x0, #24]
    b4fc:	92403c21 	and	x1, x1, #0xffff
    b500:	9b027c21 	mul	x1, x1, x2
    b504:	d360fc21 	lsr	x1, x1, #32
    b508:	eb00003f 	cmp	x1, x0
    b50c:	540000e2 	b.cs	b528 <f0+0x1704>  // b.hs, b.nlast
    b510:	8b0102f7 	add	x23, x23, x1
    b514:	394002e0 	ldrb	w0, [x23]
    b518:	7103fc1f 	cmp	w0, #0xff
    b51c:	540076c0 	b.eq	c3f4 <f0+0x25d0>  // b.none
    b520:	52800020 	mov	w0, #0x1                   	// #1
    b524:	390002e0 	strb	w0, [x23]
    b528:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b52c:	911763e1 	add	x1, sp, #0x5d8
    b530:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b534:	52800020 	mov	w0, #0x1                   	// #1
    b538:	f902efe2 	str	x2, [sp, #1496]
    b53c:	f902f3f5 	str	x21, [sp, #1504]
    b540:	97ffe5ed 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b544:	9114c283 	add	x3, x20, #0x530
    b548:	aa0003f5 	mov	x21, x0
    b54c:	f949d861 	ldr	x1, [x3, #5040]
    b550:	f949ec60 	ldr	x0, [x3, #5080]
    b554:	cb0102a1 	sub	x1, x21, x1
    b558:	eb00403f 	cmp	x1, x0, lsl #16
    b55c:	54000322 	b.cs	b5c0 <f0+0x179c>  // b.hs, b.nlast
    b560:	d350fc22 	lsr	x2, x1, #16
    b564:	f949fc63 	ldr	x3, [x3, #5112]
    b568:	8b020842 	add	x2, x2, x2, lsl #2
    b56c:	d37df042 	lsl	x2, x2, #3
    b570:	8b020060 	add	x0, x3, x2
    b574:	f9401017 	ldr	x23, [x0, #32]
    b578:	b4000257 	cbz	x23, b5c0 <f0+0x179c>
    b57c:	38626862 	ldrb	w2, [x3, x2]
    b580:	7100085f 	cmp	w2, #0x2
    b584:	54005f40 	b.eq	c16c <f0+0x2348>  // b.none
    b588:	7100045f 	cmp	w2, #0x1
    b58c:	540001a1 	b.ne	b5c0 <f0+0x179c>  // b.any
    b590:	29430002 	ldp	w2, w0, [x0, #24]
    b594:	92403c21 	and	x1, x1, #0xffff
    b598:	9b027c21 	mul	x1, x1, x2
    b59c:	d360fc21 	lsr	x1, x1, #32
    b5a0:	eb00003f 	cmp	x1, x0
    b5a4:	540000e2 	b.cs	b5c0 <f0+0x179c>  // b.hs, b.nlast
    b5a8:	8b0102f7 	add	x23, x23, x1
    b5ac:	394002e0 	ldrb	w0, [x23]
    b5b0:	7103fc1f 	cmp	w0, #0xff
    b5b4:	54007260 	b.eq	c400 <f0+0x25dc>  // b.none
    b5b8:	52800020 	mov	w0, #0x1                   	// #1
    b5bc:	390002e0 	strb	w0, [x23]
    b5c0:	9117a3e1 	add	x1, sp, #0x5e8
    b5c4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b5c8:	52800020 	mov	w0, #0x1                   	// #1
    b5cc:	f902f7e2 	str	x2, [sp, #1512]
    b5d0:	f902fbf5 	str	x21, [sp, #1520]
    b5d4:	97ffe5c8 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b5d8:	97ffe88a 	bl	5800 <fwp_rc_fresh>
    b5dc:	aa0003e2 	mov	x2, x0
    b5e0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b5e4:	9117e3e1 	add	x1, sp, #0x5f8
    b5e8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b5ec:	52800020 	mov	w0, #0x1                   	// #1
    b5f0:	f902ffe3 	str	x3, [sp, #1528]
    b5f4:	f90303e2 	str	x2, [sp, #1536]
    b5f8:	97ffe5bf 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b5fc:	9114c283 	add	x3, x20, #0x530
    b600:	aa0003f5 	mov	x21, x0
    b604:	f949d861 	ldr	x1, [x3, #5040]
    b608:	f949ec60 	ldr	x0, [x3, #5080]
    b60c:	cb0102a1 	sub	x1, x21, x1
    b610:	eb00403f 	cmp	x1, x0, lsl #16
    b614:	54000322 	b.cs	b678 <f0+0x1854>  // b.hs, b.nlast
    b618:	d350fc22 	lsr	x2, x1, #16
    b61c:	f949fc63 	ldr	x3, [x3, #5112]
    b620:	8b020842 	add	x2, x2, x2, lsl #2
    b624:	d37df042 	lsl	x2, x2, #3
    b628:	8b020060 	add	x0, x3, x2
    b62c:	f9401017 	ldr	x23, [x0, #32]
    b630:	b4000257 	cbz	x23, b678 <f0+0x1854>
    b634:	38626862 	ldrb	w2, [x3, x2]
    b638:	7100085f 	cmp	w2, #0x2
    b63c:	54005920 	b.eq	c160 <f0+0x233c>  // b.none
    b640:	7100045f 	cmp	w2, #0x1
    b644:	540001a1 	b.ne	b678 <f0+0x1854>  // b.any
    b648:	29430002 	ldp	w2, w0, [x0, #24]
    b64c:	92403c21 	and	x1, x1, #0xffff
    b650:	9b027c21 	mul	x1, x1, x2
    b654:	d360fc21 	lsr	x1, x1, #32
    b658:	eb00003f 	cmp	x1, x0
    b65c:	540000e2 	b.cs	b678 <f0+0x1854>  // b.hs, b.nlast
    b660:	8b0102f7 	add	x23, x23, x1
    b664:	394002e0 	ldrb	w0, [x23]
    b668:	7103fc1f 	cmp	w0, #0xff
    b66c:	54006d00 	b.eq	c40c <f0+0x25e8>  // b.none
    b670:	52800020 	mov	w0, #0x1                   	// #1
    b674:	390002e0 	strb	w0, [x23]
    b678:	911823e1 	add	x1, sp, #0x608
    b67c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b680:	52800020 	mov	w0, #0x1                   	// #1
    b684:	f90307f7 	str	x23, [sp, #1544]
    b688:	f9030bf5 	str	x21, [sp, #1552]
    b68c:	97ffe59a 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b690:	97ffe85c 	bl	5800 <fwp_rc_fresh>
    b694:	aa0003e2 	mov	x2, x0
    b698:	911863e1 	add	x1, sp, #0x618
    b69c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b6a0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b6a4:	52800020 	mov	w0, #0x1                   	// #1
    b6a8:	f9030ff5 	str	x21, [sp, #1560]
    b6ac:	f90313e2 	str	x2, [sp, #1568]
    b6b0:	97ffe591 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b6b4:	97ffe853 	bl	5800 <fwp_rc_fresh>
    b6b8:	aa0003e2 	mov	x2, x0
    b6bc:	9118a3e1 	add	x1, sp, #0x628
    b6c0:	52800020 	mov	w0, #0x1                   	// #1
    b6c4:	f90317f7 	str	x23, [sp, #1576]
    b6c8:	f9031be2 	str	x2, [sp, #1584]
    b6cc:	97ffe58a 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b6d0:	97ffe84c 	bl	5800 <fwp_rc_fresh>
    b6d4:	aa0003e2 	mov	x2, x0
    b6d8:	9118e3e1 	add	x1, sp, #0x638
    b6dc:	52800020 	mov	w0, #0x1                   	// #1
    b6e0:	f9031ff5 	str	x21, [sp, #1592]
    b6e4:	f90323e2 	str	x2, [sp, #1600]
    b6e8:	97ffe583 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b6ec:	97ffe845 	bl	5800 <fwp_rc_fresh>
    b6f0:	aa0003e2 	mov	x2, x0
    b6f4:	911923e1 	add	x1, sp, #0x648
    b6f8:	52800020 	mov	w0, #0x1                   	// #1
    b6fc:	f90327f7 	str	x23, [sp, #1608]
    b700:	f9032be2 	str	x2, [sp, #1616]
    b704:	97ffe57c 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b708:	9114c283 	add	x3, x20, #0x530
    b70c:	aa0003f5 	mov	x21, x0
    b710:	f949d861 	ldr	x1, [x3, #5040]
    b714:	f949ec60 	ldr	x0, [x3, #5080]
    b718:	cb0102a1 	sub	x1, x21, x1
    b71c:	eb00403f 	cmp	x1, x0, lsl #16
    b720:	54000322 	b.cs	b784 <f0+0x1960>  // b.hs, b.nlast
    b724:	d350fc22 	lsr	x2, x1, #16
    b728:	f949fc63 	ldr	x3, [x3, #5112]
    b72c:	8b020842 	add	x2, x2, x2, lsl #2
    b730:	d37df042 	lsl	x2, x2, #3
    b734:	8b020060 	add	x0, x3, x2
    b738:	f9401017 	ldr	x23, [x0, #32]
    b73c:	b4000257 	cbz	x23, b784 <f0+0x1960>
    b740:	38626862 	ldrb	w2, [x3, x2]
    b744:	7100085f 	cmp	w2, #0x2
    b748:	540051e0 	b.eq	c184 <f0+0x2360>  // b.none
    b74c:	7100045f 	cmp	w2, #0x1
    b750:	540001a1 	b.ne	b784 <f0+0x1960>  // b.any
    b754:	29430002 	ldp	w2, w0, [x0, #24]
    b758:	92403c21 	and	x1, x1, #0xffff
    b75c:	9b027c21 	mul	x1, x1, x2
    b760:	d360fc21 	lsr	x1, x1, #32
    b764:	eb00003f 	cmp	x1, x0
    b768:	540000e2 	b.cs	b784 <f0+0x1960>  // b.hs, b.nlast
    b76c:	8b0102f7 	add	x23, x23, x1
    b770:	394002e0 	ldrb	w0, [x23]
    b774:	7103fc1f 	cmp	w0, #0xff
    b778:	54006500 	b.eq	c418 <f0+0x25f4>  // b.none
    b77c:	52800020 	mov	w0, #0x1                   	// #1
    b780:	390002e0 	strb	w0, [x23]
    b784:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b788:	911963e1 	add	x1, sp, #0x658
    b78c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b790:	52800020 	mov	w0, #0x1                   	// #1
    b794:	f9032fe2 	str	x2, [sp, #1624]
    b798:	f90333f5 	str	x21, [sp, #1632]
    b79c:	97ffe556 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b7a0:	9114c283 	add	x3, x20, #0x530
    b7a4:	aa0003f5 	mov	x21, x0
    b7a8:	f949d861 	ldr	x1, [x3, #5040]
    b7ac:	f949ec60 	ldr	x0, [x3, #5080]
    b7b0:	cb0102a1 	sub	x1, x21, x1
    b7b4:	eb00403f 	cmp	x1, x0, lsl #16
    b7b8:	54000322 	b.cs	b81c <f0+0x19f8>  // b.hs, b.nlast
    b7bc:	d350fc22 	lsr	x2, x1, #16
    b7c0:	f949fc63 	ldr	x3, [x3, #5112]
    b7c4:	8b020842 	add	x2, x2, x2, lsl #2
    b7c8:	d37df042 	lsl	x2, x2, #3
    b7cc:	8b020060 	add	x0, x3, x2
    b7d0:	f9401017 	ldr	x23, [x0, #32]
    b7d4:	b4000257 	cbz	x23, b81c <f0+0x19f8>
    b7d8:	38626862 	ldrb	w2, [x3, x2]
    b7dc:	7100085f 	cmp	w2, #0x2
    b7e0:	54004cc0 	b.eq	c178 <f0+0x2354>  // b.none
    b7e4:	7100045f 	cmp	w2, #0x1
    b7e8:	540001a1 	b.ne	b81c <f0+0x19f8>  // b.any
    b7ec:	29430002 	ldp	w2, w0, [x0, #24]
    b7f0:	92403c21 	and	x1, x1, #0xffff
    b7f4:	9b027c21 	mul	x1, x1, x2
    b7f8:	d360fc21 	lsr	x1, x1, #32
    b7fc:	eb00003f 	cmp	x1, x0
    b800:	540000e2 	b.cs	b81c <f0+0x19f8>  // b.hs, b.nlast
    b804:	8b0102f7 	add	x23, x23, x1
    b808:	394002e0 	ldrb	w0, [x23]
    b80c:	7103fc1f 	cmp	w0, #0xff
    b810:	540060a0 	b.eq	c424 <f0+0x2600>  // b.none
    b814:	52800020 	mov	w0, #0x1                   	// #1
    b818:	390002e0 	strb	w0, [x23]
    b81c:	9119a3e1 	add	x1, sp, #0x668
    b820:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b824:	52800020 	mov	w0, #0x1                   	// #1
    b828:	f90337f7 	str	x23, [sp, #1640]
    b82c:	f9033bf5 	str	x21, [sp, #1648]
    b830:	97ffe531 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b834:	97ffe7f3 	bl	5800 <fwp_rc_fresh>
    b838:	aa0003e2 	mov	x2, x0
    b83c:	9119e3e1 	add	x1, sp, #0x678
    b840:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b844:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b848:	52800020 	mov	w0, #0x1                   	// #1
    b84c:	f9033ff5 	str	x21, [sp, #1656]
    b850:	f90343e2 	str	x2, [sp, #1664]
    b854:	97ffe528 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b858:	97ffe7ea 	bl	5800 <fwp_rc_fresh>
    b85c:	aa0003e2 	mov	x2, x0
    b860:	911a23e1 	add	x1, sp, #0x688
    b864:	52800020 	mov	w0, #0x1                   	// #1
    b868:	f90347f7 	str	x23, [sp, #1672]
    b86c:	f9034be2 	str	x2, [sp, #1680]
    b870:	97ffe521 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b874:	97ffe7e3 	bl	5800 <fwp_rc_fresh>
    b878:	aa0003e2 	mov	x2, x0
    b87c:	911a63e1 	add	x1, sp, #0x698
    b880:	52800020 	mov	w0, #0x1                   	// #1
    b884:	f9034ff5 	str	x21, [sp, #1688]
    b888:	f90353e2 	str	x2, [sp, #1696]
    b88c:	97ffe51a 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b890:	9114c283 	add	x3, x20, #0x530
    b894:	aa0003f5 	mov	x21, x0
    b898:	f949d861 	ldr	x1, [x3, #5040]
    b89c:	f949ec60 	ldr	x0, [x3, #5080]
    b8a0:	cb0102a1 	sub	x1, x21, x1
    b8a4:	eb00403f 	cmp	x1, x0, lsl #16
    b8a8:	54000322 	b.cs	b90c <f0+0x1ae8>  // b.hs, b.nlast
    b8ac:	d350fc22 	lsr	x2, x1, #16
    b8b0:	f949fc63 	ldr	x3, [x3, #5112]
    b8b4:	8b020842 	add	x2, x2, x2, lsl #2
    b8b8:	d37df042 	lsl	x2, x2, #3
    b8bc:	8b020060 	add	x0, x3, x2
    b8c0:	f9401017 	ldr	x23, [x0, #32]
    b8c4:	b4000257 	cbz	x23, b90c <f0+0x1ae8>
    b8c8:	38626862 	ldrb	w2, [x3, x2]
    b8cc:	7100085f 	cmp	w2, #0x2
    b8d0:	54004660 	b.eq	c19c <f0+0x2378>  // b.none
    b8d4:	7100045f 	cmp	w2, #0x1
    b8d8:	540001a1 	b.ne	b90c <f0+0x1ae8>  // b.any
    b8dc:	29430002 	ldp	w2, w0, [x0, #24]
    b8e0:	92403c21 	and	x1, x1, #0xffff
    b8e4:	9b027c21 	mul	x1, x1, x2
    b8e8:	d360fc21 	lsr	x1, x1, #32
    b8ec:	eb00003f 	cmp	x1, x0
    b8f0:	540000e2 	b.cs	b90c <f0+0x1ae8>  // b.hs, b.nlast
    b8f4:	8b0102f7 	add	x23, x23, x1
    b8f8:	394002e0 	ldrb	w0, [x23]
    b8fc:	7103fc1f 	cmp	w0, #0xff
    b900:	54005980 	b.eq	c430 <f0+0x260c>  // b.none
    b904:	52800020 	mov	w0, #0x1                   	// #1
    b908:	390002e0 	strb	w0, [x23]
    b90c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b910:	911aa3e1 	add	x1, sp, #0x6a8
    b914:	52800020 	mov	w0, #0x1                   	// #1
    b918:	f90357e2 	str	x2, [sp, #1704]
    b91c:	f9035bf5 	str	x21, [sp, #1712]
    b920:	97ffe4f5 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b924:	9114c283 	add	x3, x20, #0x530
    b928:	aa0003f5 	mov	x21, x0
    b92c:	f949d861 	ldr	x1, [x3, #5040]
    b930:	f949ec60 	ldr	x0, [x3, #5080]
    b934:	cb0102a1 	sub	x1, x21, x1
    b938:	eb00403f 	cmp	x1, x0, lsl #16
    b93c:	54000322 	b.cs	b9a0 <f0+0x1b7c>  // b.hs, b.nlast
    b940:	d350fc22 	lsr	x2, x1, #16
    b944:	f949fc63 	ldr	x3, [x3, #5112]
    b948:	8b020842 	add	x2, x2, x2, lsl #2
    b94c:	d37df042 	lsl	x2, x2, #3
    b950:	8b020060 	add	x0, x3, x2
    b954:	f9401017 	ldr	x23, [x0, #32]
    b958:	b4000257 	cbz	x23, b9a0 <f0+0x1b7c>
    b95c:	38626862 	ldrb	w2, [x3, x2]
    b960:	7100085f 	cmp	w2, #0x2
    b964:	54004160 	b.eq	c190 <f0+0x236c>  // b.none
    b968:	7100045f 	cmp	w2, #0x1
    b96c:	540001a1 	b.ne	b9a0 <f0+0x1b7c>  // b.any
    b970:	29430002 	ldp	w2, w0, [x0, #24]
    b974:	92403c21 	and	x1, x1, #0xffff
    b978:	9b027c21 	mul	x1, x1, x2
    b97c:	d360fc21 	lsr	x1, x1, #32
    b980:	eb00003f 	cmp	x1, x0
    b984:	540000e2 	b.cs	b9a0 <f0+0x1b7c>  // b.hs, b.nlast
    b988:	8b0102f7 	add	x23, x23, x1
    b98c:	394002e0 	ldrb	w0, [x23]
    b990:	7103fc1f 	cmp	w0, #0xff
    b994:	54005540 	b.eq	c43c <f0+0x2618>  // b.none
    b998:	52800020 	mov	w0, #0x1                   	// #1
    b99c:	390002e0 	strb	w0, [x23]
    b9a0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b9a4:	911ae3e1 	add	x1, sp, #0x6b8
    b9a8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b9ac:	52800020 	mov	w0, #0x1                   	// #1
    b9b0:	f9035fe2 	str	x2, [sp, #1720]
    b9b4:	f90363f5 	str	x21, [sp, #1728]
    b9b8:	97ffe4cf 	bl	4cf4 <fwp_data.part.0.constprop.0>
    b9bc:	9114c283 	add	x3, x20, #0x530
    b9c0:	aa0003f5 	mov	x21, x0
    b9c4:	f949d861 	ldr	x1, [x3, #5040]
    b9c8:	f949ec60 	ldr	x0, [x3, #5080]
    b9cc:	cb0102a1 	sub	x1, x21, x1
    b9d0:	eb00403f 	cmp	x1, x0, lsl #16
    b9d4:	54000322 	b.cs	ba38 <f0+0x1c14>  // b.hs, b.nlast
    b9d8:	d350fc22 	lsr	x2, x1, #16
    b9dc:	f949fc63 	ldr	x3, [x3, #5112]
    b9e0:	8b020842 	add	x2, x2, x2, lsl #2
    b9e4:	d37df042 	lsl	x2, x2, #3
    b9e8:	8b020060 	add	x0, x3, x2
    b9ec:	f9401017 	ldr	x23, [x0, #32]
    b9f0:	b4000257 	cbz	x23, ba38 <f0+0x1c14>
    b9f4:	38626862 	ldrb	w2, [x3, x2]
    b9f8:	7100085f 	cmp	w2, #0x2
    b9fc:	54003dc0 	b.eq	c1b4 <f0+0x2390>  // b.none
    ba00:	7100045f 	cmp	w2, #0x1
    ba04:	540001a1 	b.ne	ba38 <f0+0x1c14>  // b.any
    ba08:	29430002 	ldp	w2, w0, [x0, #24]
    ba0c:	92403c21 	and	x1, x1, #0xffff
    ba10:	9b027c21 	mul	x1, x1, x2
    ba14:	d360fc21 	lsr	x1, x1, #32
    ba18:	eb00003f 	cmp	x1, x0
    ba1c:	540000e2 	b.cs	ba38 <f0+0x1c14>  // b.hs, b.nlast
    ba20:	8b0102f7 	add	x23, x23, x1
    ba24:	394002e0 	ldrb	w0, [x23]
    ba28:	7103fc1f 	cmp	w0, #0xff
    ba2c:	540050e0 	b.eq	c448 <f0+0x2624>  // b.none
    ba30:	52800020 	mov	w0, #0x1                   	// #1
    ba34:	390002e0 	strb	w0, [x23]
    ba38:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba3c:	911b23e1 	add	x1, sp, #0x6c8
    ba40:	52800020 	mov	w0, #0x1                   	// #1
    ba44:	f90367e2 	str	x2, [sp, #1736]
    ba48:	f9036bf5 	str	x21, [sp, #1744]
    ba4c:	97ffe4aa 	bl	4cf4 <fwp_data.part.0.constprop.0>
    ba50:	9114c283 	add	x3, x20, #0x530
    ba54:	aa0003f7 	mov	x23, x0
    ba58:	f949d861 	ldr	x1, [x3, #5040]
    ba5c:	f949ec60 	ldr	x0, [x3, #5080]
    ba60:	cb0102e1 	sub	x1, x23, x1
    ba64:	eb00403f 	cmp	x1, x0, lsl #16
    ba68:	54000322 	b.cs	bacc <f0+0x1ca8>  // b.hs, b.nlast
    ba6c:	d350fc22 	lsr	x2, x1, #16
    ba70:	f949fc63 	ldr	x3, [x3, #5112]
    ba74:	8b020842 	add	x2, x2, x2, lsl #2
    ba78:	d37df042 	lsl	x2, x2, #3
    ba7c:	8b020060 	add	x0, x3, x2
    ba80:	f9401015 	ldr	x21, [x0, #32]
    ba84:	b4000255 	cbz	x21, bacc <f0+0x1ca8>
    ba88:	38626862 	ldrb	w2, [x3, x2]
    ba8c:	7100085f 	cmp	w2, #0x2
    ba90:	540038c0 	b.eq	c1a8 <f0+0x2384>  // b.none
    ba94:	7100045f 	cmp	w2, #0x1
    ba98:	540001a1 	b.ne	bacc <f0+0x1ca8>  // b.any
    ba9c:	29430002 	ldp	w2, w0, [x0, #24]
    baa0:	92403c21 	and	x1, x1, #0xffff
    baa4:	9b027c21 	mul	x1, x1, x2
    baa8:	d360fc21 	lsr	x1, x1, #32
    baac:	eb00003f 	cmp	x1, x0
    bab0:	540000e2 	b.cs	bacc <f0+0x1ca8>  // b.hs, b.nlast
    bab4:	8b0102b5 	add	x21, x21, x1
    bab8:	394002a0 	ldrb	w0, [x21]
    babc:	7103fc1f 	cmp	w0, #0xff
    bac0:	54004ca0 	b.eq	c454 <f0+0x2630>  // b.none
    bac4:	52800020 	mov	w0, #0x1                   	// #1
    bac8:	390002a0 	strb	w0, [x21]
    bacc:	911b63e1 	add	x1, sp, #0x6d8
    bad0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bad4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bad8:	52800020 	mov	w0, #0x1                   	// #1
    badc:	f9036ff5 	str	x21, [sp, #1752]
    bae0:	f90373f7 	str	x23, [sp, #1760]
    bae4:	97ffe484 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bae8:	97ffe746 	bl	5800 <fwp_rc_fresh>
    baec:	aa0003e2 	mov	x2, x0
    baf0:	911ba3e1 	add	x1, sp, #0x6e8
    baf4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    baf8:	52800020 	mov	w0, #0x1                   	// #1
    bafc:	f90377f7 	str	x23, [sp, #1768]
    bb00:	f9037be2 	str	x2, [sp, #1776]
    bb04:	97ffe47c 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bb08:	97ffe73e 	bl	5800 <fwp_rc_fresh>
    bb0c:	aa0003e2 	mov	x2, x0
    bb10:	911be3e1 	add	x1, sp, #0x6f8
    bb14:	52800020 	mov	w0, #0x1                   	// #1
    bb18:	f9037ff5 	str	x21, [sp, #1784]
    bb1c:	f90383e2 	str	x2, [sp, #1792]
    bb20:	97ffe475 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bb24:	97ffe737 	bl	5800 <fwp_rc_fresh>
    bb28:	aa0003e2 	mov	x2, x0
    bb2c:	911c23e1 	add	x1, sp, #0x708
    bb30:	52800020 	mov	w0, #0x1                   	// #1
    bb34:	f90387f7 	str	x23, [sp, #1800]
    bb38:	f9038be2 	str	x2, [sp, #1808]
    bb3c:	97ffe46e 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bb40:	97ffe730 	bl	5800 <fwp_rc_fresh>
    bb44:	aa0003e2 	mov	x2, x0
    bb48:	911c63e1 	add	x1, sp, #0x718
    bb4c:	52800020 	mov	w0, #0x1                   	// #1
    bb50:	f9038ff5 	str	x21, [sp, #1816]
    bb54:	f90393e2 	str	x2, [sp, #1824]
    bb58:	97ffe467 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bb5c:	97ffe729 	bl	5800 <fwp_rc_fresh>
    bb60:	aa0003e2 	mov	x2, x0
    bb64:	911ca3e1 	add	x1, sp, #0x728
    bb68:	52800020 	mov	w0, #0x1                   	// #1
    bb6c:	f90397f7 	str	x23, [sp, #1832]
    bb70:	f9039be2 	str	x2, [sp, #1840]
    bb74:	97ffe460 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bb78:	97ffe722 	bl	5800 <fwp_rc_fresh>
    bb7c:	aa0003e2 	mov	x2, x0
    bb80:	911ce3e1 	add	x1, sp, #0x738
    bb84:	52800020 	mov	w0, #0x1                   	// #1
    bb88:	f9039ff5 	str	x21, [sp, #1848]
    bb8c:	f903a3e2 	str	x2, [sp, #1856]
    bb90:	97ffe459 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bb94:	97ffe71b 	bl	5800 <fwp_rc_fresh>
    bb98:	aa0003e2 	mov	x2, x0
    bb9c:	911d23e1 	add	x1, sp, #0x748
    bba0:	52800020 	mov	w0, #0x1                   	// #1
    bba4:	f903a7f7 	str	x23, [sp, #1864]
    bba8:	f903abe2 	str	x2, [sp, #1872]
    bbac:	97ffe452 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bbb0:	97ffe714 	bl	5800 <fwp_rc_fresh>
    bbb4:	aa0003e2 	mov	x2, x0
    bbb8:	911d63e1 	add	x1, sp, #0x758
    bbbc:	52800020 	mov	w0, #0x1                   	// #1
    bbc0:	f903aff5 	str	x21, [sp, #1880]
    bbc4:	f903b3e2 	str	x2, [sp, #1888]
    bbc8:	97ffe44b 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bbcc:	9114c283 	add	x3, x20, #0x530
    bbd0:	aa0003f5 	mov	x21, x0
    bbd4:	f949d861 	ldr	x1, [x3, #5040]
    bbd8:	f949ec60 	ldr	x0, [x3, #5080]
    bbdc:	cb0102a1 	sub	x1, x21, x1
    bbe0:	eb00403f 	cmp	x1, x0, lsl #16
    bbe4:	54000322 	b.cs	bc48 <f0+0x1e24>  // b.hs, b.nlast
    bbe8:	d350fc22 	lsr	x2, x1, #16
    bbec:	f949fc63 	ldr	x3, [x3, #5112]
    bbf0:	8b020842 	add	x2, x2, x2, lsl #2
    bbf4:	d37df042 	lsl	x2, x2, #3
    bbf8:	8b020060 	add	x0, x3, x2
    bbfc:	f9401017 	ldr	x23, [x0, #32]
    bc00:	b4000257 	cbz	x23, bc48 <f0+0x1e24>
    bc04:	38626862 	ldrb	w2, [x3, x2]
    bc08:	7100085f 	cmp	w2, #0x2
    bc0c:	54002e00 	b.eq	c1cc <f0+0x23a8>  // b.none
    bc10:	7100045f 	cmp	w2, #0x1
    bc14:	540001a1 	b.ne	bc48 <f0+0x1e24>  // b.any
    bc18:	29430002 	ldp	w2, w0, [x0, #24]
    bc1c:	92403c21 	and	x1, x1, #0xffff
    bc20:	9b027c21 	mul	x1, x1, x2
    bc24:	d360fc21 	lsr	x1, x1, #32
    bc28:	eb00003f 	cmp	x1, x0
    bc2c:	540000e2 	b.cs	bc48 <f0+0x1e24>  // b.hs, b.nlast
    bc30:	8b0102f7 	add	x23, x23, x1
    bc34:	394002e0 	ldrb	w0, [x23]
    bc38:	7103fc1f 	cmp	w0, #0xff
    bc3c:	54004120 	b.eq	c460 <f0+0x263c>  // b.none
    bc40:	52800020 	mov	w0, #0x1                   	// #1
    bc44:	390002e0 	strb	w0, [x23]
    bc48:	911da3e1 	add	x1, sp, #0x768
    bc4c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bc50:	52800020 	mov	w0, #0x1                   	// #1
    bc54:	f903b7f7 	str	x23, [sp, #1896]
    bc58:	f903bbf5 	str	x21, [sp, #1904]
    bc5c:	97ffe426 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bc60:	97ffe6e8 	bl	5800 <fwp_rc_fresh>
    bc64:	aa0003e2 	mov	x2, x0
    bc68:	911de3e1 	add	x1, sp, #0x778
    bc6c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bc70:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bc74:	52800020 	mov	w0, #0x1                   	// #1
    bc78:	f903bff5 	str	x21, [sp, #1912]
    bc7c:	f903c3e2 	str	x2, [sp, #1920]
    bc80:	97ffe41d 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bc84:	97ffe6df 	bl	5800 <fwp_rc_fresh>
    bc88:	aa0003e2 	mov	x2, x0
    bc8c:	911e23e1 	add	x1, sp, #0x788
    bc90:	52800020 	mov	w0, #0x1                   	// #1
    bc94:	f903c7f7 	str	x23, [sp, #1928]
    bc98:	f903cbe2 	str	x2, [sp, #1936]
    bc9c:	97ffe416 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bca0:	97ffe6d8 	bl	5800 <fwp_rc_fresh>
    bca4:	aa0003e2 	mov	x2, x0
    bca8:	911e63e1 	add	x1, sp, #0x798
    bcac:	52800020 	mov	w0, #0x1                   	// #1
    bcb0:	f903cff5 	str	x21, [sp, #1944]
    bcb4:	f903d3e2 	str	x2, [sp, #1952]
    bcb8:	97ffe40f 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bcbc:	9114c283 	add	x3, x20, #0x530
    bcc0:	aa0003f5 	mov	x21, x0
    bcc4:	f949d861 	ldr	x1, [x3, #5040]
    bcc8:	f949ec60 	ldr	x0, [x3, #5080]
    bccc:	cb0102a1 	sub	x1, x21, x1
    bcd0:	eb00403f 	cmp	x1, x0, lsl #16
    bcd4:	54000322 	b.cs	bd38 <f0+0x1f14>  // b.hs, b.nlast
    bcd8:	d350fc22 	lsr	x2, x1, #16
    bcdc:	f949fc63 	ldr	x3, [x3, #5112]
    bce0:	8b020842 	add	x2, x2, x2, lsl #2
    bce4:	d37df042 	lsl	x2, x2, #3
    bce8:	8b020060 	add	x0, x3, x2
    bcec:	f9401017 	ldr	x23, [x0, #32]
    bcf0:	b4000257 	cbz	x23, bd38 <f0+0x1f14>
    bcf4:	38626862 	ldrb	w2, [x3, x2]
    bcf8:	7100085f 	cmp	w2, #0x2
    bcfc:	54002620 	b.eq	c1c0 <f0+0x239c>  // b.none
    bd00:	7100045f 	cmp	w2, #0x1
    bd04:	540001a1 	b.ne	bd38 <f0+0x1f14>  // b.any
    bd08:	29430002 	ldp	w2, w0, [x0, #24]
    bd0c:	92403c21 	and	x1, x1, #0xffff
    bd10:	9b027c21 	mul	x1, x1, x2
    bd14:	d360fc21 	lsr	x1, x1, #32
    bd18:	eb00003f 	cmp	x1, x0
    bd1c:	540000e2 	b.cs	bd38 <f0+0x1f14>  // b.hs, b.nlast
    bd20:	8b0102f7 	add	x23, x23, x1
    bd24:	394002e0 	ldrb	w0, [x23]
    bd28:	7103fc1f 	cmp	w0, #0xff
    bd2c:	54003a00 	b.eq	c46c <f0+0x2648>  // b.none
    bd30:	52800020 	mov	w0, #0x1                   	// #1
    bd34:	390002e0 	strb	w0, [x23]
    bd38:	911ea3e1 	add	x1, sp, #0x7a8
    bd3c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bd40:	52800020 	mov	w0, #0x1                   	// #1
    bd44:	f903d7f7 	str	x23, [sp, #1960]
    bd48:	f903dbf5 	str	x21, [sp, #1968]
    bd4c:	97ffe3ea 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bd50:	97ffe6ac 	bl	5800 <fwp_rc_fresh>
    bd54:	aa0003e2 	mov	x2, x0
    bd58:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bd5c:	911ee3e1 	add	x1, sp, #0x7b8
    bd60:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bd64:	52800020 	mov	w0, #0x1                   	// #1
    bd68:	f903dfe3 	str	x3, [sp, #1976]
    bd6c:	f903e3e2 	str	x2, [sp, #1984]
    bd70:	97ffe3e1 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bd74:	97ffe6a3 	bl	5800 <fwp_rc_fresh>
    bd78:	aa0003e2 	mov	x2, x0
    bd7c:	911f23e1 	add	x1, sp, #0x7c8
    bd80:	52800020 	mov	w0, #0x1                   	// #1
    bd84:	f903e7f7 	str	x23, [sp, #1992]
    bd88:	f903ebe2 	str	x2, [sp, #2000]
    bd8c:	97ffe3da 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bd90:	9114c283 	add	x3, x20, #0x530
    bd94:	aa0003f7 	mov	x23, x0
    bd98:	f949d861 	ldr	x1, [x3, #5040]
    bd9c:	f949ec60 	ldr	x0, [x3, #5080]
    bda0:	cb0102e1 	sub	x1, x23, x1
    bda4:	eb00403f 	cmp	x1, x0, lsl #16
    bda8:	54000322 	b.cs	be0c <f0+0x1fe8>  // b.hs, b.nlast
    bdac:	d350fc22 	lsr	x2, x1, #16
    bdb0:	f949fc63 	ldr	x3, [x3, #5112]
    bdb4:	8b020842 	add	x2, x2, x2, lsl #2
    bdb8:	d37df042 	lsl	x2, x2, #3
    bdbc:	8b020060 	add	x0, x3, x2
    bdc0:	f9401015 	ldr	x21, [x0, #32]
    bdc4:	b4000255 	cbz	x21, be0c <f0+0x1fe8>
    bdc8:	38626862 	ldrb	w2, [x3, x2]
    bdcc:	7100085f 	cmp	w2, #0x2
    bdd0:	540020a0 	b.eq	c1e4 <f0+0x23c0>  // b.none
    bdd4:	7100045f 	cmp	w2, #0x1
    bdd8:	540001a1 	b.ne	be0c <f0+0x1fe8>  // b.any
    bddc:	29430002 	ldp	w2, w0, [x0, #24]
    bde0:	92403c21 	and	x1, x1, #0xffff
    bde4:	9b027c21 	mul	x1, x1, x2
    bde8:	d360fc21 	lsr	x1, x1, #32
    bdec:	eb00003f 	cmp	x1, x0
    bdf0:	540000e2 	b.cs	be0c <f0+0x1fe8>  // b.hs, b.nlast
    bdf4:	8b0102b5 	add	x21, x21, x1
    bdf8:	394002a0 	ldrb	w0, [x21]
    bdfc:	7103fc1f 	cmp	w0, #0xff
    be00:	540033c0 	b.eq	c478 <f0+0x2654>  // b.none
    be04:	52800020 	mov	w0, #0x1                   	// #1
    be08:	390002a0 	strb	w0, [x21]
    be0c:	911f63e1 	add	x1, sp, #0x7d8
    be10:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    be14:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    be18:	52800020 	mov	w0, #0x1                   	// #1
    be1c:	f903eff5 	str	x21, [sp, #2008]
    be20:	f903f3f7 	str	x23, [sp, #2016]
    be24:	97ffe3b4 	bl	4cf4 <fwp_data.part.0.constprop.0>
    be28:	97ffe676 	bl	5800 <fwp_rc_fresh>
    be2c:	aa0003e2 	mov	x2, x0
    be30:	911fa3e1 	add	x1, sp, #0x7e8
    be34:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    be38:	52800020 	mov	w0, #0x1                   	// #1
    be3c:	f903f7f7 	str	x23, [sp, #2024]
    be40:	f903fbe2 	str	x2, [sp, #2032]
    be44:	97ffe3ac 	bl	4cf4 <fwp_data.part.0.constprop.0>
    be48:	97ffe66e 	bl	5800 <fwp_rc_fresh>
    be4c:	aa0003e2 	mov	x2, x0
    be50:	911fe3e1 	add	x1, sp, #0x7f8
    be54:	52800020 	mov	w0, #0x1                   	// #1
    be58:	f903fff5 	str	x21, [sp, #2040]
    be5c:	f90403e2 	str	x2, [sp, #2048]
    be60:	97ffe3a5 	bl	4cf4 <fwp_data.part.0.constprop.0>
    be64:	97ffe667 	bl	5800 <fwp_rc_fresh>
    be68:	aa0003e2 	mov	x2, x0
    be6c:	912023e1 	add	x1, sp, #0x808
    be70:	52800020 	mov	w0, #0x1                   	// #1
    be74:	f90407f7 	str	x23, [sp, #2056]
    be78:	f9040be2 	str	x2, [sp, #2064]
    be7c:	97ffe39e 	bl	4cf4 <fwp_data.part.0.constprop.0>
    be80:	97ffe660 	bl	5800 <fwp_rc_fresh>
    be84:	aa0003e2 	mov	x2, x0
    be88:	912063e1 	add	x1, sp, #0x818
    be8c:	52800020 	mov	w0, #0x1                   	// #1
    be90:	f9040ff5 	str	x21, [sp, #2072]
    be94:	f90413e2 	str	x2, [sp, #2080]
    be98:	97ffe397 	bl	4cf4 <fwp_data.part.0.constprop.0>
    be9c:	97ffe659 	bl	5800 <fwp_rc_fresh>
    bea0:	aa0003e2 	mov	x2, x0
    bea4:	9120a3e1 	add	x1, sp, #0x828
    bea8:	52800020 	mov	w0, #0x1                   	// #1
    beac:	f90417f7 	str	x23, [sp, #2088]
    beb0:	f9041be2 	str	x2, [sp, #2096]
    beb4:	97ffe390 	bl	4cf4 <fwp_data.part.0.constprop.0>
    beb8:	97ffe652 	bl	5800 <fwp_rc_fresh>
    bebc:	aa0003e2 	mov	x2, x0
    bec0:	9120e3e1 	add	x1, sp, #0x838
    bec4:	52800020 	mov	w0, #0x1                   	// #1
    bec8:	f9041ff5 	str	x21, [sp, #2104]
    becc:	f90423e2 	str	x2, [sp, #2112]
    bed0:	97ffe389 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bed4:	9114c283 	add	x3, x20, #0x530
    bed8:	aa0003f5 	mov	x21, x0
    bedc:	f949d861 	ldr	x1, [x3, #5040]
    bee0:	f949ec60 	ldr	x0, [x3, #5080]
    bee4:	cb0102a1 	sub	x1, x21, x1
    bee8:	eb00403f 	cmp	x1, x0, lsl #16
    beec:	54000322 	b.cs	bf50 <f0+0x212c>  // b.hs, b.nlast
    bef0:	d350fc22 	lsr	x2, x1, #16
    bef4:	f949fc63 	ldr	x3, [x3, #5112]
    bef8:	8b020842 	add	x2, x2, x2, lsl #2
    befc:	d37df042 	lsl	x2, x2, #3
    bf00:	8b020060 	add	x0, x3, x2
    bf04:	f9401017 	ldr	x23, [x0, #32]
    bf08:	b4000257 	cbz	x23, bf50 <f0+0x212c>
    bf0c:	38626862 	ldrb	w2, [x3, x2]
    bf10:	7100085f 	cmp	w2, #0x2
    bf14:	54001620 	b.eq	c1d8 <f0+0x23b4>  // b.none
    bf18:	7100045f 	cmp	w2, #0x1
    bf1c:	540001a1 	b.ne	bf50 <f0+0x212c>  // b.any
    bf20:	29430002 	ldp	w2, w0, [x0, #24]
    bf24:	92403c21 	and	x1, x1, #0xffff
    bf28:	9b027c21 	mul	x1, x1, x2
    bf2c:	d360fc21 	lsr	x1, x1, #32
    bf30:	eb00003f 	cmp	x1, x0
    bf34:	540000e2 	b.cs	bf50 <f0+0x212c>  // b.hs, b.nlast
    bf38:	8b0102f7 	add	x23, x23, x1
    bf3c:	394002e0 	ldrb	w0, [x23]
    bf40:	7103fc1f 	cmp	w0, #0xff
    bf44:	54002a00 	b.eq	c484 <f0+0x2660>  // b.none
    bf48:	52800020 	mov	w0, #0x1                   	// #1
    bf4c:	390002e0 	strb	w0, [x23]
    bf50:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bf54:	912123e1 	add	x1, sp, #0x848
    bf58:	52800020 	mov	w0, #0x1                   	// #1
    bf5c:	f90427e2 	str	x2, [sp, #2120]
    bf60:	f9042bf5 	str	x21, [sp, #2128]
    bf64:	97ffe364 	bl	4cf4 <fwp_data.part.0.constprop.0>
    bf68:	9114c283 	add	x3, x20, #0x530
    bf6c:	aa0003f5 	mov	x21, x0
    bf70:	f949d861 	ldr	x1, [x3, #5040]
    bf74:	f949ec60 	ldr	x0, [x3, #5080]
    bf78:	cb0102a1 	sub	x1, x21, x1
    bf7c:	eb00403f 	cmp	x1, x0, lsl #16
    bf80:	54000322 	b.cs	bfe4 <f0+0x21c0>  // b.hs, b.nlast
    bf84:	d350fc22 	lsr	x2, x1, #16
    bf88:	f949fc63 	ldr	x3, [x3, #5112]
    bf8c:	8b020842 	add	x2, x2, x2, lsl #2
    bf90:	d37df042 	lsl	x2, x2, #3
    bf94:	8b020060 	add	x0, x3, x2
    bf98:	f9401017 	ldr	x23, [x0, #32]
    bf9c:	b4000257 	cbz	x23, bfe4 <f0+0x21c0>
    bfa0:	38626862 	ldrb	w2, [x3, x2]
    bfa4:	7100085f 	cmp	w2, #0x2
    bfa8:	540012a0 	b.eq	c1fc <f0+0x23d8>  // b.none
    bfac:	7100045f 	cmp	w2, #0x1
    bfb0:	540001a1 	b.ne	bfe4 <f0+0x21c0>  // b.any
    bfb4:	29430002 	ldp	w2, w0, [x0, #24]
    bfb8:	92403c21 	and	x1, x1, #0xffff
    bfbc:	9b027c21 	mul	x1, x1, x2
    bfc0:	d360fc21 	lsr	x1, x1, #32
    bfc4:	eb00003f 	cmp	x1, x0
    bfc8:	540000e2 	b.cs	bfe4 <f0+0x21c0>  // b.hs, b.nlast
    bfcc:	8b0102f7 	add	x23, x23, x1
    bfd0:	394002e0 	ldrb	w0, [x23]
    bfd4:	7103fc1f 	cmp	w0, #0xff
    bfd8:	540025c0 	b.eq	c490 <f0+0x266c>  // b.none
    bfdc:	52800020 	mov	w0, #0x1                   	// #1
    bfe0:	390002e0 	strb	w0, [x23]
    bfe4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bfe8:	9114c294 	add	x20, x20, #0x530
    bfec:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bff0:	aa1603e1 	mov	x1, x22
    bff4:	52800020 	mov	w0, #0x1                   	// #1
    bff8:	f9042fe2 	str	x2, [sp, #2136]
    bffc:	f90433f5 	str	x21, [sp, #2144]
    c000:	97ffe33d 	bl	4cf4 <fwp_data.part.0.constprop.0>
    c004:	f949da81 	ldr	x1, [x20, #5040]
    c008:	aa0003f5 	mov	x21, x0
    c00c:	f949ee80 	ldr	x0, [x20, #5080]
    c010:	cb0102a1 	sub	x1, x21, x1
    c014:	eb00403f 	cmp	x1, x0, lsl #16
    c018:	54000322 	b.cs	c07c <f0+0x2258>  // b.hs, b.nlast
    c01c:	d350fc22 	lsr	x2, x1, #16
    c020:	f949fe83 	ldr	x3, [x20, #5112]
    c024:	8b020842 	add	x2, x2, x2, lsl #2
    c028:	d37df042 	lsl	x2, x2, #3
    c02c:	8b020060 	add	x0, x3, x2
    c030:	f9401014 	ldr	x20, [x0, #32]
    c034:	b4000254 	cbz	x20, c07c <f0+0x2258>
    c038:	38626862 	ldrb	w2, [x3, x2]
    c03c:	7100085f 	cmp	w2, #0x2
    c040:	54000d80 	b.eq	c1f0 <f0+0x23cc>  // b.none
    c044:	7100045f 	cmp	w2, #0x1
    c048:	540001a1 	b.ne	c07c <f0+0x2258>  // b.any
    c04c:	29430002 	ldp	w2, w0, [x0, #24]
    c050:	92403c21 	and	x1, x1, #0xffff
    c054:	9b027c21 	mul	x1, x1, x2
    c058:	d360fc21 	lsr	x1, x1, #32
    c05c:	eb00003f 	cmp	x1, x0
    c060:	540000e2 	b.cs	c07c <f0+0x2258>  // b.hs, b.nlast
    c064:	8b010294 	add	x20, x20, x1
    c068:	39400280 	ldrb	w0, [x20]
    c06c:	7103fc1f 	cmp	w0, #0xff
    c070:	540012c0 	b.eq	c2c8 <f0+0x24a4>  // b.none
    c074:	52800020 	mov	w0, #0x1                   	// #1
    c078:	39000280 	strb	w0, [x20]
    c07c:	aa1303e1 	mov	x1, x19
    c080:	aa1503e0 	mov	x0, x21
    c084:	97fff0b7 	bl	8360 <fwp_hof0.constprop.0>
    c088:	aa0003f4 	mov	x20, x0
    c08c:	aa1503e0 	mov	x0, x21
    c090:	97ffe6e0 	bl	5c10 <fwp_drop0>
    c094:	aa1303e0 	mov	x0, x19
    c098:	97ffe6de 	bl	5c10 <fwp_drop0>
    c09c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    c0a0:	f947f400 	ldr	x0, [x0, #4072]
    c0a4:	f94437e2 	ldr	x2, [sp, #2152]
    c0a8:	f9400001 	ldr	x1, [x0]
    c0ac:	eb010042 	subs	x2, x2, x1
    c0b0:	d2800001 	mov	x1, #0x0                   	// #0
    c0b4:	54001f41 	b.ne	c49c <f0+0x2678>  // b.any
    c0b8:	9121c3ff 	add	sp, sp, #0x870
    c0bc:	aa1403e0 	mov	x0, x20
    c0c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    c0c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c0c8:	a94363f7 	ldp	x23, x24, [sp, #48]
    c0cc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c0d0:	a94573fb 	ldp	x27, x28, [sp, #80]
    c0d4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c0d8:	d65f03c0 	ret
    c0dc:	aa1c03e0 	mov	x0, x28
    c0e0:	97ffdf68 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c0e4:	17fff799 	b	9f48 <f0+0x124>
    c0e8:	72003c5f 	tst	w2, #0xffff
    c0ec:	54fef301 	b.ne	9f4c <f0+0x128>  // b.any
    c0f0:	17fff793 	b	9f3c <f0+0x118>
    c0f4:	72003c3f 	tst	w1, #0xffff
    c0f8:	54fefca1 	b.ne	a08c <f0+0x268>  // b.any
    c0fc:	17fff7df 	b	a078 <f0+0x254>
    c100:	72003c3f 	tst	w1, #0xffff
    c104:	54ff0721 	b.ne	a1e8 <f0+0x3c4>  // b.any
    c108:	17fff833 	b	a1d4 <f0+0x3b0>
    c10c:	72003c3f 	tst	w1, #0xffff
    c110:	54ff0221 	b.ne	a154 <f0+0x330>  // b.any
    c114:	17fff80b 	b	a140 <f0+0x31c>
    c118:	72003c3f 	tst	w1, #0xffff
    c11c:	54ff1ba1 	b.ne	a490 <f0+0x66c>  // b.any
    c120:	17fff8d7 	b	a47c <f0+0x658>
    c124:	72003c3f 	tst	w1, #0xffff
    c128:	54ff0a81 	b.ne	a278 <f0+0x454>  // b.any
    c12c:	17fff84e 	b	a264 <f0+0x440>
    c130:	72003c3f 	tst	w1, #0xffff
    c134:	54ff2701 	b.ne	a614 <f0+0x7f0>  // b.any
    c138:	17fff932 	b	a600 <f0+0x7dc>
    c13c:	72003c3f 	tst	w1, #0xffff
    c140:	54ff1f21 	b.ne	a524 <f0+0x700>  // b.any
    c144:	17fff8f3 	b	a510 <f0+0x6ec>
    c148:	72003c3f 	tst	w1, #0xffff
    c14c:	54ff9ee1 	b.ne	b528 <f0+0x1704>  // b.any
    c150:	17fffcf1 	b	b514 <f0+0x16f0>
    c154:	72003c3f 	tst	w1, #0xffff
    c158:	54ff97e1 	b.ne	b454 <f0+0x1630>  // b.any
    c15c:	17fffcb9 	b	b440 <f0+0x161c>
    c160:	72003c3f 	tst	w1, #0xffff
    c164:	54ffa8a1 	b.ne	b678 <f0+0x1854>  // b.any
    c168:	17fffd3f 	b	b664 <f0+0x1840>
    c16c:	72003c3f 	tst	w1, #0xffff
    c170:	54ffa281 	b.ne	b5c0 <f0+0x179c>  // b.any
    c174:	17fffd0e 	b	b5ac <f0+0x1788>
    c178:	72003c3f 	tst	w1, #0xffff
    c17c:	54ffb501 	b.ne	b81c <f0+0x19f8>  // b.any
    c180:	17fffda2 	b	b808 <f0+0x19e4>
    c184:	72003c3f 	tst	w1, #0xffff
    c188:	54ffafe1 	b.ne	b784 <f0+0x1960>  // b.any
    c18c:	17fffd79 	b	b770 <f0+0x194c>
    c190:	72003c3f 	tst	w1, #0xffff
    c194:	54ffc061 	b.ne	b9a0 <f0+0x1b7c>  // b.any
    c198:	17fffdfd 	b	b98c <f0+0x1b68>
    c19c:	72003c3f 	tst	w1, #0xffff
    c1a0:	54ffbb61 	b.ne	b90c <f0+0x1ae8>  // b.any
    c1a4:	17fffdd5 	b	b8f8 <f0+0x1ad4>
    c1a8:	72003c3f 	tst	w1, #0xffff
    c1ac:	54ffc901 	b.ne	bacc <f0+0x1ca8>  // b.any
    c1b0:	17fffe42 	b	bab8 <f0+0x1c94>
    c1b4:	72003c3f 	tst	w1, #0xffff
    c1b8:	54ffc401 	b.ne	ba38 <f0+0x1c14>  // b.any
    c1bc:	17fffe1a 	b	ba24 <f0+0x1c00>
    c1c0:	72003c3f 	tst	w1, #0xffff
    c1c4:	54ffdba1 	b.ne	bd38 <f0+0x1f14>  // b.any
    c1c8:	17fffed7 	b	bd24 <f0+0x1f00>
    c1cc:	72003c3f 	tst	w1, #0xffff
    c1d0:	54ffd3c1 	b.ne	bc48 <f0+0x1e24>  // b.any
    c1d4:	17fffe98 	b	bc34 <f0+0x1e10>
    c1d8:	72003c3f 	tst	w1, #0xffff
    c1dc:	54ffeba1 	b.ne	bf50 <f0+0x212c>  // b.any
    c1e0:	17ffff57 	b	bf3c <f0+0x2118>
    c1e4:	72003c3f 	tst	w1, #0xffff
    c1e8:	54ffe121 	b.ne	be0c <f0+0x1fe8>  // b.any
    c1ec:	17ffff03 	b	bdf8 <f0+0x1fd4>
    c1f0:	72003c3f 	tst	w1, #0xffff
    c1f4:	54fff441 	b.ne	c07c <f0+0x2258>  // b.any
    c1f8:	17ffff9c 	b	c068 <f0+0x2244>
    c1fc:	72003c3f 	tst	w1, #0xffff
    c200:	54ffef21 	b.ne	bfe4 <f0+0x21c0>  // b.any
    c204:	17ffff73 	b	bfd0 <f0+0x21ac>
    c208:	72003c3f 	tst	w1, #0xffff
    c20c:	54ff31e1 	b.ne	a848 <f0+0xa24>  // b.any
    c210:	17fff989 	b	a834 <f0+0xa10>
    c214:	72003c3f 	tst	w1, #0xffff
    c218:	54ff25a1 	b.ne	a6cc <f0+0x8a8>  // b.any
    c21c:	17fff927 	b	a6b8 <f0+0x894>
    c220:	72003c3f 	tst	w1, #0xffff
    c224:	54ff43a1 	b.ne	aa98 <f0+0xc74>  // b.any
    c228:	17fffa17 	b	aa84 <f0+0xc60>
    c22c:	72003c3f 	tst	w1, #0xffff
    c230:	54ff3d81 	b.ne	a9e0 <f0+0xbbc>  // b.any
    c234:	17fff9e6 	b	a9cc <f0+0xba8>
    c238:	72003c3f 	tst	w1, #0xffff
    c23c:	54ff4e61 	b.ne	ac08 <f0+0xde4>  // b.any
    c240:	17fffa6d 	b	abf4 <f0+0xdd0>
    c244:	72003c3f 	tst	w1, #0xffff
    c248:	54ff4841 	b.ne	ab50 <f0+0xd2c>  // b.any
    c24c:	17fffa3c 	b	ab3c <f0+0xd18>
    c250:	72003c3f 	tst	w1, #0xffff
    c254:	54ff5ac1 	b.ne	adac <f0+0xf88>  // b.any
    c258:	17fffad0 	b	ad98 <f0+0xf74>
    c25c:	72003c3f 	tst	w1, #0xffff
    c260:	54ff55a1 	b.ne	ad14 <f0+0xef0>  // b.any
    c264:	17fffaa7 	b	ad00 <f0+0xedc>
    c268:	72003c3f 	tst	w1, #0xffff
    c26c:	54ff6581 	b.ne	af1c <f0+0x10f8>  // b.any
    c270:	17fffb26 	b	af08 <f0+0x10e4>
    c274:	72003c3f 	tst	w1, #0xffff
    c278:	54ff5f61 	b.ne	ae64 <f0+0x1040>  // b.any
    c27c:	17fffaf5 	b	ae50 <f0+0x102c>
    c280:	72003c3f 	tst	w1, #0xffff
    c284:	54ff7021 	b.ne	b088 <f0+0x1264>  // b.any
    c288:	17fffb7b 	b	b074 <f0+0x1250>
    c28c:	72003c3f 	tst	w1, #0xffff
    c290:	54ff6b01 	b.ne	aff0 <f0+0x11cc>  // b.any
    c294:	17fffb52 	b	afdc <f0+0x11b8>
    c298:	72003c3f 	tst	w1, #0xffff
    c29c:	54ff7ae1 	b.ne	b1f8 <f0+0x13d4>  // b.any
    c2a0:	17fffbd1 	b	b1e4 <f0+0x13c0>
    c2a4:	72003c3f 	tst	w1, #0xffff
    c2a8:	54ff74c1 	b.ne	b140 <f0+0x131c>  // b.any
    c2ac:	17fffba0 	b	b12c <f0+0x1308>
    c2b0:	72003c3f 	tst	w1, #0xffff
    c2b4:	54ff8581 	b.ne	b364 <f0+0x1540>  // b.any
    c2b8:	17fffc26 	b	b350 <f0+0x152c>
    c2bc:	72003c3f 	tst	w1, #0xffff
    c2c0:	54ff8061 	b.ne	b2cc <f0+0x14a8>  // b.any
    c2c4:	17fffbfd 	b	b2b8 <f0+0x1494>
    c2c8:	aa1403e0 	mov	x0, x20
    c2cc:	97ffdeed 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c2d0:	17ffff69 	b	c074 <f0+0x2250>
    c2d4:	aa1703e0 	mov	x0, x23
    c2d8:	97ffdeea 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c2dc:	17fff76a 	b	a084 <f0+0x260>
    c2e0:	aa1703e0 	mov	x0, x23
    c2e4:	97ffdee7 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c2e8:	17fff799 	b	a14c <f0+0x328>
    c2ec:	aa1703e0 	mov	x0, x23
    c2f0:	97ffdee4 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c2f4:	17fff7bb 	b	a1e0 <f0+0x3bc>
    c2f8:	aa1503e0 	mov	x0, x21
    c2fc:	97ffdee1 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c300:	17fff7dc 	b	a270 <f0+0x44c>
    c304:	aa1703e0 	mov	x0, x23
    c308:	97ffdede 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c30c:	17fff85f 	b	a488 <f0+0x664>
    c310:	aa1703e0 	mov	x0, x23
    c314:	97ffdedb 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c318:	17fff881 	b	a51c <f0+0x6f8>
    c31c:	aa1703e0 	mov	x0, x23
    c320:	97ffded8 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c324:	17fff8ba 	b	a60c <f0+0x7e8>
    c328:	aa1503e0 	mov	x0, x21
    c32c:	97ffded5 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c330:	17fff8e5 	b	a6c4 <f0+0x8a0>
    c334:	aa1703e0 	mov	x0, x23
    c338:	97ffded2 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c33c:	17fff941 	b	a840 <f0+0xa1c>
    c340:	aa1703e0 	mov	x0, x23
    c344:	97ffdecf 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c348:	17fff9a4 	b	a9d8 <f0+0xbb4>
    c34c:	aa1703e0 	mov	x0, x23
    c350:	97ffdecc 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c354:	17fff9cf 	b	aa90 <f0+0xc6c>
    c358:	aa1703e0 	mov	x0, x23
    c35c:	97ffdec9 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c360:	17fff9fa 	b	ab48 <f0+0xd24>
    c364:	aa1703e0 	mov	x0, x23
    c368:	97ffdec6 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c36c:	17fffa25 	b	ac00 <f0+0xddc>
    c370:	aa1703e0 	mov	x0, x23
    c374:	97ffdec3 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c378:	17fffa65 	b	ad0c <f0+0xee8>
    c37c:	aa1703e0 	mov	x0, x23
    c380:	97ffdec0 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c384:	17fffa88 	b	ada4 <f0+0xf80>
    c388:	aa1703e0 	mov	x0, x23
    c38c:	97ffdebd 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c390:	17fffab3 	b	ae5c <f0+0x1038>
    c394:	aa1703e0 	mov	x0, x23
    c398:	97ffdeba 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c39c:	17fffade 	b	af14 <f0+0x10f0>
    c3a0:	aa1703e0 	mov	x0, x23
    c3a4:	97ffdeb7 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c3a8:	17fffb10 	b	afe8 <f0+0x11c4>
    c3ac:	aa1703e0 	mov	x0, x23
    c3b0:	97ffdeb4 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c3b4:	17fffb33 	b	b080 <f0+0x125c>
    c3b8:	aa1703e0 	mov	x0, x23
    c3bc:	97ffdeb1 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c3c0:	17fffb5e 	b	b138 <f0+0x1314>
    c3c4:	aa1703e0 	mov	x0, x23
    c3c8:	97ffdeae 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c3cc:	17fffb89 	b	b1f0 <f0+0x13cc>
    c3d0:	aa1703e0 	mov	x0, x23
    c3d4:	97ffdeab 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c3d8:	17fffbbb 	b	b2c4 <f0+0x14a0>
    c3dc:	aa1703e0 	mov	x0, x23
    c3e0:	97ffdea8 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c3e4:	17fffbde 	b	b35c <f0+0x1538>
    c3e8:	aa1703e0 	mov	x0, x23
    c3ec:	97ffdea5 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c3f0:	17fffc17 	b	b44c <f0+0x1628>
    c3f4:	aa1703e0 	mov	x0, x23
    c3f8:	97ffdea2 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c3fc:	17fffc49 	b	b520 <f0+0x16fc>
    c400:	aa1703e0 	mov	x0, x23
    c404:	97ffde9f 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c408:	17fffc6c 	b	b5b8 <f0+0x1794>
    c40c:	aa1703e0 	mov	x0, x23
    c410:	97ffde9c 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c414:	17fffc97 	b	b670 <f0+0x184c>
    c418:	aa1703e0 	mov	x0, x23
    c41c:	97ffde99 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c420:	17fffcd7 	b	b77c <f0+0x1958>
    c424:	aa1703e0 	mov	x0, x23
    c428:	97ffde96 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c42c:	17fffcfa 	b	b814 <f0+0x19f0>
    c430:	aa1703e0 	mov	x0, x23
    c434:	97ffde93 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c438:	17fffd33 	b	b904 <f0+0x1ae0>
    c43c:	aa1703e0 	mov	x0, x23
    c440:	97ffde90 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c444:	17fffd55 	b	b998 <f0+0x1b74>
    c448:	aa1703e0 	mov	x0, x23
    c44c:	97ffde8d 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c450:	17fffd78 	b	ba30 <f0+0x1c0c>
    c454:	aa1503e0 	mov	x0, x21
    c458:	97ffde8a 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c45c:	17fffd9a 	b	bac4 <f0+0x1ca0>
    c460:	aa1703e0 	mov	x0, x23
    c464:	97ffde87 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c468:	17fffdf6 	b	bc40 <f0+0x1e1c>
    c46c:	aa1703e0 	mov	x0, x23
    c470:	97ffde84 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c474:	17fffe2f 	b	bd30 <f0+0x1f0c>
    c478:	aa1503e0 	mov	x0, x21
    c47c:	97ffde81 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c480:	17fffe61 	b	be04 <f0+0x1fe0>
    c484:	aa1703e0 	mov	x0, x23
    c488:	97ffde7e 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c48c:	17fffeaf 	b	bf48 <f0+0x2124>
    c490:	aa1703e0 	mov	x0, x23
    c494:	97ffde7b 	bl	3e80 <fwp_rc_forget_slot.part.0>
    c498:	17fffed1 	b	bfdc <f0+0x21b8>
    c49c:	97ffd8d9 	bl	2800 <__stack_chk_fail@plt>
    c4a0:	97ffd8ec 	bl	2850 <abort@plt>

000000000000c4a4 <fwp_main_thread>:
    c4a4:	d10443ff 	sub	sp, sp, #0x110
    c4a8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    c4ac:	f947f400 	ldr	x0, [x0, #4072]
    c4b0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c4b4:	910303fd 	add	x29, sp, #0xc0
    c4b8:	a90d53f3 	stp	x19, x20, [sp, #208]
    c4bc:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    c4c0:	9114c261 	add	x1, x19, #0x530
    c4c4:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c4c8:	b953a421 	ldr	w1, [x1, #5028]
    c4cc:	f9400002 	ldr	x2, [x0]
    c4d0:	f9005fe2 	str	x2, [sp, #184]
    c4d4:	d2800002 	mov	x2, #0x0                   	// #0
    c4d8:	34000e41 	cbz	w1, c6a0 <fwp_main_thread+0x1fc>
    c4dc:	9114c273 	add	x19, x19, #0x530
    c4e0:	b953aa60 	ldr	w0, [x19, #5032]
    c4e4:	35000d60 	cbnz	w0, c690 <fwp_main_thread+0x1ec>
    c4e8:	91001fe2 	add	x2, sp, #0x7
    c4ec:	900000b4 	adrp	x20, 20000 <__data_start>
    c4f0:	900000a3 	adrp	x3, 20000 <__data_start>
    c4f4:	9100c293 	add	x19, x20, #0x30
    c4f8:	910d4063 	add	x3, x3, #0x350
    c4fc:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c500:	d2a00025 	mov	x5, #0x10000               	// #65536
    c504:	910023e0 	add	x0, sp, #0x8
    c508:	d2800001 	mov	x1, #0x0                   	// #0
    c50c:	f90007e3 	str	x3, [sp, #8]
    c510:	b90013ff 	str	wzr, [sp, #16]
    c514:	a9019262 	stp	x2, x4, [x19, #24]
    c518:	f9000fe5 	str	x5, [sp, #24]
    c51c:	97ffd855 	bl	2670 <sigaltstack@plt>
    c520:	35000220 	cbnz	w0, c564 <fwp_main_thread+0xc0>
    c524:	4f000400 	movi	v0.4s, #0x0
    c528:	9100a3e0 	add	x0, sp, #0x28
    c52c:	d0ffffa1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    c530:	52800082 	mov	w2, #0x4                   	// #4
    c534:	913fc021 	add	x1, x1, #0xff0
    c538:	72a10002 	movk	w2, #0x800, lsl #16
    c53c:	910083f5 	add	x21, sp, #0x20
    c540:	f90013e1 	str	x1, [sp, #32]
    c544:	3d802000 	str	q0, [x0, #128]
    c548:	b900abe2 	str	w2, [sp, #168]
    c54c:	ad000000 	stp	q0, q0, [x0]
    c550:	ad010000 	stp	q0, q0, [x0, #32]
    c554:	ad020000 	stp	q0, q0, [x0, #64]
    c558:	ad030000 	stp	q0, q0, [x0, #96]
    c55c:	97ffd899 	bl	27c0 <sigemptyset@plt>
    c560:	340000c0 	cbz	w0, c578 <fwp_main_thread+0xd4>
    c564:	b0000000 	adrp	x0, d000 <__modti3+0x2c0>
    c568:	911a6000 	add	x0, x0, #0x698
    c56c:	a90f63f7 	stp	x23, x24, [sp, #240]
    c570:	f90083f9 	str	x25, [sp, #256]
    c574:	97ffde23 	bl	3e00 <fwp_trap>
    c578:	aa1503e1 	mov	x1, x21
    c57c:	d2800002 	mov	x2, #0x0                   	// #0
    c580:	52800160 	mov	w0, #0xb                   	// #11
    c584:	97ffd8a7 	bl	2820 <sigaction@plt>
    c588:	35fffee0 	cbnz	w0, c564 <fwp_main_thread+0xc0>
    c58c:	aa1503e1 	mov	x1, x21
    c590:	d2800002 	mov	x2, #0x0                   	// #0
    c594:	528000e0 	mov	w0, #0x7                   	// #7
    c598:	97ffd8a2 	bl	2820 <sigaction@plt>
    c59c:	35fffe40 	cbnz	w0, c564 <fwp_main_thread+0xc0>
    c5a0:	b942ea60 	ldr	w0, [x19, #744]
    c5a4:	a90f63f7 	stp	x23, x24, [sp, #240]
    c5a8:	340019c0 	cbz	w0, c8e0 <fwp_main_thread+0x43c>
    c5ac:	9100c296 	add	x22, x20, #0x30
    c5b0:	f9400ad5 	ldr	x21, [x22, #16]
    c5b4:	b40007f5 	cbz	x21, c6b0 <fwp_main_thread+0x20c>
    c5b8:	910102b7 	add	x23, x21, #0x40
    c5bc:	f90083f9 	str	x25, [sp, #256]
    c5c0:	52800038 	mov	w24, #0x1                   	// #1
    c5c4:	39414ab9 	ldrb	w25, [x21, #82]
    c5c8:	39014ab8 	strb	w24, [x21, #82]
    c5cc:	d503201f 	nop
    c5d0:	f94016a0 	ldr	x0, [x21, #40]
    c5d4:	b40006a0 	cbz	x0, c6a8 <fwp_main_thread+0x204>
    c5d8:	f94032a1 	ldr	x1, [x21, #96]
    c5dc:	394146a0 	ldrb	w0, [x21, #81]
    c5e0:	b40019c1 	cbz	x1, c918 <fwp_main_thread+0x474>
    c5e4:	36001880 	tbz	w0, #0, c8f4 <fwp_main_thread+0x450>
    c5e8:	f9400ad3 	ldr	x19, [x22, #16]
    c5ec:	f94022a0 	ldr	x0, [x21, #64]
    c5f0:	39414a61 	ldrb	w1, [x19, #82]
    c5f4:	37001be1 	tbnz	w1, #0, c970 <fwp_main_thread+0x4cc>
    c5f8:	f9403261 	ldr	x1, [x19, #96]
    c5fc:	a911fe77 	stp	x23, xzr, [x19, #280]
    c600:	f9009660 	str	x0, [x19, #296]
    c604:	b4000040 	cbz	x0, c60c <fwp_main_thread+0x168>
    c608:	f9009013 	str	x19, [x0, #288]
    c60c:	f90022b3 	str	x19, [x21, #64]
    c610:	b4000101 	cbz	x1, c630 <fwp_main_thread+0x18c>
    c614:	f9403ec0 	ldr	x0, [x22, #120]
    c618:	39015678 	strb	w24, [x19, #85]
    c61c:	f9003661 	str	x1, [x19, #104]
    c620:	a910827f 	stp	xzr, x0, [x19, #264]
    c624:	b4000040 	cbz	x0, c62c <fwp_main_thread+0x188>
    c628:	f9008413 	str	x19, [x0, #264]
    c62c:	f9003ed3 	str	x19, [x22, #120]
    c630:	39015a7f 	strb	wzr, [x19, #86]
    c634:	97ffe8c7 	bl	6950 <fwp_block>
    c638:	f9408e62 	ldr	x2, [x19, #280]
    c63c:	b4000142 	cbz	x2, c664 <fwp_main_thread+0x1c0>
    c640:	a9520261 	ldp	x1, x0, [x19, #288]
    c644:	b4001a21 	cbz	x1, c988 <fwp_main_thread+0x4e4>
    c648:	f9009420 	str	x0, [x1, #296]
    c64c:	f9409660 	ldr	x0, [x19, #296]
    c650:	b4000040 	cbz	x0, c658 <fwp_main_thread+0x1b4>
    c654:	f9009001 	str	x1, [x0, #288]
    c658:	91080260 	add	x0, x19, #0x200
    c65c:	f900967f 	str	xzr, [x19, #296]
    c660:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c664:	39415660 	ldrb	w0, [x19, #85]
    c668:	3607fb40 	tbz	w0, #0, c5d0 <fwp_main_thread+0x12c>
    c66c:	a9508261 	ldp	x1, x0, [x19, #264]
    c670:	b4001901 	cbz	x1, c990 <fwp_main_thread+0x4ec>
    c674:	f9008820 	str	x0, [x1, #272]
    c678:	b4000040 	cbz	x0, c680 <fwp_main_thread+0x1dc>
    c67c:	f9008401 	str	x1, [x0, #264]
    c680:	91080260 	add	x0, x19, #0x200
    c684:	3901567f 	strb	wzr, [x19, #85]
    c688:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c68c:	17ffffd1 	b	c5d0 <fwp_main_thread+0x12c>
    c690:	f0ffffa0 	adrp	x0, 3000 <fwp_segv+0x10>
    c694:	91241000 	add	x0, x0, #0x904
    c698:	94000286 	bl	d0b0 <atexit>
    c69c:	17ffff93 	b	c4e8 <fwp_main_thread+0x44>
    c6a0:	97ffdcf4 	bl	3a70 <fwp_heap_init>
    c6a4:	17ffff8e 	b	c4dc <fwp_main_thread+0x38>
    c6a8:	39014ab9 	strb	w25, [x21, #82]
    c6ac:	f94083f9 	ldr	x25, [sp, #256]
    c6b0:	9100c293 	add	x19, x20, #0x30
    c6b4:	f9416660 	ldr	x0, [x19, #712]
    c6b8:	b5000180 	cbnz	x0, c6e8 <fwp_main_thread+0x244>
    c6bc:	f9416e60 	ldr	x0, [x19, #728]
    c6c0:	b5000140 	cbnz	x0, c6e8 <fwp_main_thread+0x244>
    c6c4:	f9416260 	ldr	x0, [x19, #704]
    c6c8:	97ffde8a 	bl	40f0 <fwp_mem_free>
    c6cc:	f901627f 	str	xzr, [x19, #704]
    c6d0:	f9400a60 	ldr	x0, [x19, #16]
    c6d4:	f9016a7f 	str	xzr, [x19, #720]
    c6d8:	b40000c0 	cbz	x0, c6f0 <fwp_main_thread+0x24c>
    c6dc:	f900541f 	str	xzr, [x0, #168]
    c6e0:	f9005c1f 	str	xzr, [x0, #184]
    c6e4:	14000003 	b	c6f0 <fwp_main_thread+0x24c>
    c6e8:	9100c280 	add	x0, x20, #0x30
    c6ec:	f9400800 	ldr	x0, [x0, #16]
    c6f0:	9100c281 	add	x1, x20, #0x30
    c6f4:	f9418026 	ldr	x6, [x1, #768]
    c6f8:	b902f83f 	str	wzr, [x1, #760]
    c6fc:	eb0000df 	cmp	x6, x0
    c700:	54001561 	b.ne	c9ac <fwp_main_thread+0x508>  // b.any
    c704:	b4000380 	cbz	x0, c774 <fwp_main_thread+0x2d0>
    c708:	f9415025 	ldr	x5, [x1, #672]
    c70c:	52800021 	mov	w1, #0x1                   	// #1
    c710:	39014801 	strb	w1, [x0, #82]
    c714:	b4000305 	cbz	x5, c774 <fwp_main_thread+0x2d0>
    c718:	394140a0 	ldrb	w0, [x5, #80]
    c71c:	37000060 	tbnz	w0, #0, c728 <fwp_main_thread+0x284>
    c720:	aa0503e0 	mov	x0, x5
    c724:	97ffdb33 	bl	33f0 <fwp_cancel_tree.part.0>
    c728:	f9409ca5 	ldr	x5, [x5, #312]
    c72c:	b5ffff65 	cbnz	x5, c718 <fwp_main_thread+0x274>
    c730:	9100c293 	add	x19, x20, #0x30
    c734:	52800035 	mov	w21, #0x1                   	// #1
    c738:	f94028c0 	ldr	x0, [x6, #80]
    c73c:	f2001c1f 	tst	x0, #0xff000000ff
    c740:	540000e1 	b.ne	c75c <fwp_main_thread+0x2b8>  // b.any
    c744:	f9401660 	ldr	x0, [x19, #40]
    c748:	390150d5 	strb	w21, [x6, #84]
    c74c:	f90080df 	str	xzr, [x6, #256]
    c750:	b40010c0 	cbz	x0, c968 <fwp_main_thread+0x4c4>
    c754:	f9008006 	str	x6, [x0, #256]
    c758:	f9001666 	str	x6, [x19, #40]
    c75c:	97ffe87d 	bl	6950 <fwp_block>
    c760:	97ffe804 	bl	6770 <fwp_free_zombie>
    c764:	f9415260 	ldr	x0, [x19, #672]
    c768:	b4000060 	cbz	x0, c774 <fwp_main_thread+0x2d0>
    c76c:	f9418266 	ldr	x6, [x19, #768]
    c770:	17fffff2 	b	c738 <fwp_main_thread+0x294>
    c774:	9100c295 	add	x21, x20, #0x30
    c778:	97ffe7fe 	bl	6770 <fwp_free_zombie>
    c77c:	f9401aa0 	ldr	x0, [x21, #48]
    c780:	b5001160 	cbnz	x0, c9ac <fwp_main_thread+0x508>
    c784:	f9403ea0 	ldr	x0, [x21, #120]
    c788:	b5001120 	cbnz	x0, c9ac <fwp_main_thread+0x508>
    c78c:	b9409ab3 	ldr	w19, [x21, #152]
    c790:	340001f3 	cbz	w19, c7cc <fwp_main_thread+0x328>
    c794:	93407e76 	sxtw	x22, w19
    c798:	51000673 	sub	w19, w19, #0x1
    c79c:	d1000ad6 	sub	x22, x22, #0x2
    c7a0:	910282b7 	add	x23, x21, #0xa0
    c7a4:	cb3342d6 	sub	x22, x22, w19, uxtw
    c7a8:	93407e73 	sxtw	x19, w19
    c7ac:	d503201f 	nop
    c7b0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c7b4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c7b8:	b9009ab3 	str	w19, [x21, #152]
    c7bc:	d1000673 	sub	x19, x19, #0x1
    c7c0:	97ffd858 	bl	2920 <munmap@plt>
    c7c4:	eb1302df 	cmp	x22, x19
    c7c8:	54ffff41 	b.ne	c7b0 <fwp_main_thread+0x30c>  // b.any
    c7cc:	900000b3 	adrp	x19, 20000 <__data_start>
    c7d0:	91004260 	add	x0, x19, #0x10
    c7d4:	b9400800 	ldr	w0, [x0, #8]
    c7d8:	36f80800 	tbz	w0, #31, c8d8 <fwp_main_thread+0x434>
    c7dc:	9100c295 	add	x21, x20, #0x30
    c7e0:	91004273 	add	x19, x19, #0x10
    c7e4:	12800001 	mov	w1, #0xffffffff            	// #-1
    c7e8:	f9418aa0 	ldr	x0, [x21, #784]
    c7ec:	b9000a61 	str	w1, [x19, #8]
    c7f0:	f94186a1 	ldr	x1, [x21, #776]
    c7f4:	b40001e0 	cbz	x0, c830 <fwp_main_thread+0x38c>
    c7f8:	d2800013 	mov	x19, #0x0                   	// #0
    c7fc:	d503201f 	nop
    c800:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    c804:	b40000e0 	cbz	x0, c820 <fwp_main_thread+0x37c>
    c808:	f9400001 	ldr	x1, [x0]
    c80c:	b5000d01 	cbnz	x1, c9ac <fwp_main_thread+0x508>
    c810:	f9400401 	ldr	x1, [x0, #8]
    c814:	b5000cc1 	cbnz	x1, c9ac <fwp_main_thread+0x508>
    c818:	97ffde36 	bl	40f0 <fwp_mem_free>
    c81c:	f94186a1 	ldr	x1, [x21, #776]
    c820:	91000673 	add	x19, x19, #0x1
    c824:	f9418aa0 	ldr	x0, [x21, #784]
    c828:	eb00027f 	cmp	x19, x0
    c82c:	54fffea3 	b.cc	c800 <fwp_main_thread+0x35c>  // b.lo, b.ul, b.last
    c830:	aa0103e0 	mov	x0, x1
    c834:	97ffde2f 	bl	40f0 <fwp_mem_free>
    c838:	9100c280 	add	x0, x20, #0x30
    c83c:	f9418013 	ldr	x19, [x0, #768]
    c840:	f901841f 	str	xzr, [x0, #776]
    c844:	f901881f 	str	xzr, [x0, #784]
    c848:	b40001f3 	cbz	x19, c884 <fwp_main_thread+0x3e0>
    c84c:	f9401661 	ldr	x1, [x19, #40]
    c850:	b5000ae1 	cbnz	x1, c9ac <fwp_main_thread+0x508>
    c854:	f9405661 	ldr	x1, [x19, #168]
    c858:	b5000aa1 	cbnz	x1, c9ac <fwp_main_thread+0x508>
    c85c:	f9416401 	ldr	x1, [x0, #712]
    c860:	b5000a61 	cbnz	x1, c9ac <fwp_main_thread+0x508>
    c864:	f9416c00 	ldr	x0, [x0, #728]
    c868:	b5000a20 	cbnz	x0, c9ac <fwp_main_thread+0x508>
    c86c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c870:	90000120 	adrp	x0, 30000 <alt.5+0xfcb0>
    c874:	910d4000 	add	x0, x0, #0x350
    c878:	97ffd7d6 	bl	27d0 <memset@plt>
    c87c:	aa1303e0 	mov	x0, x19
    c880:	97ffde1c 	bl	40f0 <fwp_mem_free>
    c884:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    c888:	f947ec00 	ldr	x0, [x0, #4056]
    c88c:	9100c294 	add	x20, x20, #0x30
    c890:	f9400000 	ldr	x0, [x0]
    c894:	f9000a9f 	str	xzr, [x20, #16]
    c898:	f901829f 	str	xzr, [x20, #768]
    c89c:	97ffd825 	bl	2930 <fflush@plt>
    c8a0:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    c8a4:	f947f400 	ldr	x0, [x0, #4072]
    c8a8:	f9405fe2 	ldr	x2, [sp, #184]
    c8ac:	f9400001 	ldr	x1, [x0]
    c8b0:	eb010042 	subs	x2, x2, x1
    c8b4:	d2800001 	mov	x1, #0x0                   	// #0
    c8b8:	54000761 	b.ne	c9a4 <fwp_main_thread+0x500>  // b.any
    c8bc:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c8c0:	d2800000 	mov	x0, #0x0                   	// #0
    c8c4:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c8c8:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c8cc:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c8d0:	910443ff 	add	sp, sp, #0x110
    c8d4:	d65f03c0 	ret
    c8d8:	97ffd7ce 	bl	2810 <close@plt>
    c8dc:	17ffffc0 	b	c7dc <fwp_main_thread+0x338>
    c8e0:	97fff551 	bl	9e24 <f0>
    c8e4:	f9017a60 	str	x0, [x19, #752]
    c8e8:	52800021 	mov	w1, #0x1                   	// #1
    c8ec:	b902ea61 	str	w1, [x19, #744]
    c8f0:	17ffff2f 	b	c5ac <fwp_main_thread+0x108>
    c8f4:	97ffdf63 	bl	4680 <fwp_now_ns>
    c8f8:	f94032a1 	ldr	x1, [x21, #96]
    c8fc:	eb01001f 	cmp	x0, x1
    c900:	540000ab 	b.lt	c914 <fwp_main_thread+0x470>  // b.tstop
    c904:	394142a0 	ldrb	w0, [x21, #80]
    c908:	37000060 	tbnz	w0, #0, c914 <fwp_main_thread+0x470>
    c90c:	aa1503e0 	mov	x0, x21
    c910:	97ffdab8 	bl	33f0 <fwp_cancel_tree.part.0>
    c914:	394146a0 	ldrb	w0, [x21, #81]
    c918:	f9400ad3 	ldr	x19, [x22, #16]
    c91c:	39414a62 	ldrb	w2, [x19, #82]
    c920:	3707e640 	tbnz	w0, #0, c5e8 <fwp_main_thread+0x144>
    c924:	f94032a1 	ldr	x1, [x21, #96]
    c928:	370001c2 	tbnz	w2, #0, c960 <fwp_main_thread+0x4bc>
    c92c:	f9403260 	ldr	x0, [x19, #96]
    c930:	b4000180 	cbz	x0, c960 <fwp_main_thread+0x4bc>
    c934:	b4000061 	cbz	x1, c940 <fwp_main_thread+0x49c>
    c938:	eb01001f 	cmp	x0, x1
    c93c:	9a81d000 	csel	x0, x0, x1, le
    c940:	f94022a1 	ldr	x1, [x21, #64]
    c944:	a911fe77 	stp	x23, xzr, [x19, #280]
    c948:	f9009661 	str	x1, [x19, #296]
    c94c:	b4000261 	cbz	x1, c998 <fwp_main_thread+0x4f4>
    c950:	f9009033 	str	x19, [x1, #288]
    c954:	aa0003e1 	mov	x1, x0
    c958:	f90022b3 	str	x19, [x21, #64]
    c95c:	17ffff2e 	b	c614 <fwp_main_thread+0x170>
    c960:	f94022a0 	ldr	x0, [x21, #64]
    c964:	17ffff26 	b	c5fc <fwp_main_thread+0x158>
    c968:	f9001a66 	str	x6, [x19, #48]
    c96c:	17ffff7b 	b	c758 <fwp_main_thread+0x2b4>
    c970:	a911fe77 	stp	x23, xzr, [x19, #280]
    c974:	f9009660 	str	x0, [x19, #296]
    c978:	b4000040 	cbz	x0, c980 <fwp_main_thread+0x4dc>
    c97c:	f9009013 	str	x19, [x0, #288]
    c980:	f90022b3 	str	x19, [x21, #64]
    c984:	17ffff2b 	b	c630 <fwp_main_thread+0x18c>
    c988:	f9000040 	str	x0, [x2]
    c98c:	17ffff31 	b	c650 <fwp_main_thread+0x1ac>
    c990:	f9003ec0 	str	x0, [x22, #120]
    c994:	17ffff39 	b	c678 <fwp_main_thread+0x1d4>
    c998:	aa0003e1 	mov	x1, x0
    c99c:	f90022b3 	str	x19, [x21, #64]
    c9a0:	17ffff1d 	b	c614 <fwp_main_thread+0x170>
    c9a4:	f90083f9 	str	x25, [sp, #256]
    c9a8:	97ffd796 	bl	2800 <__stack_chk_fail@plt>
    c9ac:	f90083f9 	str	x25, [sp, #256]
    c9b0:	97ffd7a8 	bl	2850 <abort@plt>
    c9b4:	d503201f 	nop
    c9b8:	d503201f 	nop
    c9bc:	d503201f 	nop

000000000000c9c0 <__divti3>:
    c9c0:	d503245f 	bti	c
    c9c4:	d2800004 	mov	x4, #0x0                   	// #0
    c9c8:	b7f80721 	tbnz	x1, #63, caac <__divti3+0xec>
    c9cc:	b6f80083 	tbz	x3, #63, c9dc <__divti3+0x1c>
    c9d0:	eb0203e2 	negs	x2, x2
    c9d4:	aa2403e4 	mvn	x4, x4
    c9d8:	da0303e3 	ngc	x3, x3
    c9dc:	aa0203e6 	mov	x6, x2
    c9e0:	aa0003e7 	mov	x7, x0
    c9e4:	aa0103e5 	mov	x5, x1
    c9e8:	b5000583 	cbnz	x3, ca98 <__divti3+0xd8>
    c9ec:	eb01005f 	cmp	x2, x1
    c9f0:	54000e69 	b.ls	cbbc <__divti3+0x1fc>  // b.plast
    c9f4:	dac01040 	clz	x0, x2
    c9f8:	b40000e0 	cbz	x0, ca14 <__divti3+0x54>
    c9fc:	4b0003e1 	neg	w1, w0
    ca00:	9ac020a5 	lsl	x5, x5, x0
    ca04:	9ac02046 	lsl	x6, x2, x0
    ca08:	9ac124e1 	lsr	x1, x7, x1
    ca0c:	aa050025 	orr	x5, x1, x5
    ca10:	9ac020e7 	lsl	x7, x7, x0
    ca14:	d360fcc8 	lsr	x8, x6, #32
    ca18:	92407cc2 	and	x2, x6, #0xffffffff
    ca1c:	9ac808a3 	udiv	x3, x5, x8
    ca20:	9b089465 	msub	x5, x3, x8, x5
    ca24:	aa0303e0 	mov	x0, x3
    ca28:	9b037c41 	mul	x1, x2, x3
    ca2c:	93c780a5 	extr	x5, x5, x7, #32
    ca30:	eb05003f 	cmp	x1, x5
    ca34:	540000a9 	b.ls	ca48 <__divti3+0x88>  // b.plast
    ca38:	ab0500c5 	adds	x5, x6, x5
    ca3c:	d1000460 	sub	x0, x3, #0x1
    ca40:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    ca44:	540015a8 	b.hi	ccf8 <__divti3+0x338>  // b.pmore
    ca48:	cb0100a5 	sub	x5, x5, x1
    ca4c:	9ac808a3 	udiv	x3, x5, x8
    ca50:	9b089465 	msub	x5, x3, x8, x5
    ca54:	aa0303e1 	mov	x1, x3
    ca58:	9b037c42 	mul	x2, x2, x3
    ca5c:	aa0703e3 	mov	x3, x7
    ca60:	b3607ca3 	bfi	x3, x5, #32, #32
    ca64:	eb03005f 	cmp	x2, x3
    ca68:	540000c9 	b.ls	ca80 <__divti3+0xc0>  // b.plast
    ca6c:	ab0300c3 	adds	x3, x6, x3
    ca70:	d1000425 	sub	x5, x1, #0x1
    ca74:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ca78:	d1000821 	sub	x1, x1, #0x2
    ca7c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ca80:	aa008020 	orr	x0, x1, x0, lsl #32
    ca84:	d2800001 	mov	x1, #0x0                   	// #0
    ca88:	b4000064 	cbz	x4, ca94 <__divti3+0xd4>
    ca8c:	eb0003e0 	negs	x0, x0
    ca90:	da0103e1 	ngc	x1, x1
    ca94:	d65f03c0 	ret
    ca98:	eb01007f 	cmp	x3, x1
    ca9c:	54000109 	b.ls	cabc <__divti3+0xfc>  // b.plast
    caa0:	d2800001 	mov	x1, #0x0                   	// #0
    caa4:	d2800000 	mov	x0, #0x0                   	// #0
    caa8:	17fffff8 	b	ca88 <__divti3+0xc8>
    caac:	eb0003e0 	negs	x0, x0
    cab0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cab4:	da0103e1 	ngc	x1, x1
    cab8:	17ffffc5 	b	c9cc <__divti3+0xc>
    cabc:	dac01067 	clz	x7, x3
    cac0:	b40010e7 	cbz	x7, ccdc <__divti3+0x31c>
    cac4:	d2800805 	mov	x5, #0x40                  	// #64
    cac8:	cb0700a5 	sub	x5, x5, x7
    cacc:	9ac72063 	lsl	x3, x3, x7
    cad0:	9ac52448 	lsr	x8, x2, x5
    cad4:	aa030108 	orr	x8, x8, x3
    cad8:	9ac52426 	lsr	x6, x1, x5
    cadc:	92407d0a 	and	x10, x8, #0xffffffff
    cae0:	d360fd09 	lsr	x9, x8, #32
    cae4:	9ac52403 	lsr	x3, x0, x5
    cae8:	9ac72021 	lsl	x1, x1, x7
    caec:	aa010063 	orr	x3, x3, x1
    caf0:	9ac72042 	lsl	x2, x2, x7
    caf4:	9ac908cb 	udiv	x11, x6, x9
    caf8:	9b099965 	msub	x5, x11, x9, x6
    cafc:	aa0b03e1 	mov	x1, x11
    cb00:	9b0b7d46 	mul	x6, x10, x11
    cb04:	93c380a5 	extr	x5, x5, x3, #32
    cb08:	eb0500df 	cmp	x6, x5
    cb0c:	540000a9 	b.ls	cb20 <__divti3+0x160>  // b.plast
    cb10:	ab050105 	adds	x5, x8, x5
    cb14:	d1000561 	sub	x1, x11, #0x1
    cb18:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cb1c:	54000f48 	b.hi	cd04 <__divti3+0x344>  // b.pmore
    cb20:	cb0600a6 	sub	x6, x5, x6
    cb24:	9ac908cb 	udiv	x11, x6, x9
    cb28:	9b099969 	msub	x9, x11, x9, x6
    cb2c:	aa0b03e5 	mov	x5, x11
    cb30:	9b0b7d4a 	mul	x10, x10, x11
    cb34:	b3607d23 	bfi	x3, x9, #32, #32
    cb38:	eb03015f 	cmp	x10, x3
    cb3c:	540000a9 	b.ls	cb50 <__divti3+0x190>  // b.plast
    cb40:	ab030103 	adds	x3, x8, x3
    cb44:	d1000565 	sub	x5, x11, #0x1
    cb48:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cb4c:	54000e28 	b.hi	cd10 <__divti3+0x350>  // b.pmore
    cb50:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cb54:	92407c48 	and	x8, x2, #0xffffffff
    cb58:	2a0503e5 	mov	w5, w5
    cb5c:	d360fc42 	lsr	x2, x2, #32
    cb60:	d360fc26 	lsr	x6, x1, #32
    cb64:	cb0a0063 	sub	x3, x3, x10
    cb68:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cb6c:	9b087caa 	mul	x10, x5, x8
    cb70:	9b087cc8 	mul	x8, x6, x8
    cb74:	9b0220a5 	madd	x5, x5, x2, x8
    cb78:	9b027cc6 	mul	x6, x6, x2
    cb7c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cb80:	8b0900c5 	add	x5, x6, x9
    cb84:	eb02011f 	cmp	x8, x2
    cb88:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cb8c:	8b4280c6 	add	x6, x6, x2, lsr #32
    cb90:	eb06007f 	cmp	x3, x6
    cb94:	540000e3 	b.cc	cbb0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cb98:	92407d4a 	and	x10, x10, #0xffffffff
    cb9c:	9ac72000 	lsl	x0, x0, x7
    cba0:	8b028142 	add	x2, x10, x2, lsl #32
    cba4:	eb02001f 	cmp	x0, x2
    cba8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cbac:	54000a01 	b.ne	ccec <__divti3+0x32c>  // b.any
    cbb0:	d1000420 	sub	x0, x1, #0x1
    cbb4:	d2800001 	mov	x1, #0x0                   	// #0
    cbb8:	17ffffb4 	b	ca88 <__divti3+0xc8>
    cbbc:	b5000062 	cbnz	x2, cbc8 <__divti3+0x208>
    cbc0:	d2800022 	mov	x2, #0x1                   	// #1
    cbc4:	9ac30846 	udiv	x6, x2, x3
    cbc8:	dac010c8 	clz	x8, x6
    cbcc:	b5000408 	cbnz	x8, cc4c <__divti3+0x28c>
    cbd0:	d360fcc9 	lsr	x9, x6, #32
    cbd4:	92407cc5 	and	x5, x6, #0xffffffff
    cbd8:	cb060023 	sub	x3, x1, x6
    cbdc:	d2800021 	mov	x1, #0x1                   	// #1
    cbe0:	9ac90868 	udiv	x8, x3, x9
    cbe4:	9b098d03 	msub	x3, x8, x9, x3
    cbe8:	aa0803e0 	mov	x0, x8
    cbec:	9b057d02 	mul	x2, x8, x5
    cbf0:	93c78063 	extr	x3, x3, x7, #32
    cbf4:	eb03005f 	cmp	x2, x3
    cbf8:	540000a9 	b.ls	cc0c <__divti3+0x24c>  // b.plast
    cbfc:	ab0300c3 	adds	x3, x6, x3
    cc00:	d1000500 	sub	x0, x8, #0x1
    cc04:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cc08:	54000968 	b.hi	cd34 <__divti3+0x374>  // b.pmore
    cc0c:	cb020063 	sub	x3, x3, x2
    cc10:	9ac90862 	udiv	x2, x3, x9
    cc14:	aa0203e8 	mov	x8, x2
    cc18:	9b098c42 	msub	x2, x2, x9, x3
    cc1c:	aa0703e3 	mov	x3, x7
    cc20:	9b057d05 	mul	x5, x8, x5
    cc24:	b3607c43 	bfi	x3, x2, #32, #32
    cc28:	eb0300bf 	cmp	x5, x3
    cc2c:	540000c9 	b.ls	cc44 <__divti3+0x284>  // b.plast
    cc30:	ab0300c2 	adds	x2, x6, x3
    cc34:	d1000503 	sub	x3, x8, #0x1
    cc38:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cc3c:	d1000908 	sub	x8, x8, #0x2
    cc40:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cc44:	aa008100 	orr	x0, x8, x0, lsl #32
    cc48:	17ffff90 	b	ca88 <__divti3+0xc8>
    cc4c:	9ac820c6 	lsl	x6, x6, x8
    cc50:	d2800803 	mov	x3, #0x40                  	// #64
    cc54:	cb080063 	sub	x3, x3, x8
    cc58:	d360fcc9 	lsr	x9, x6, #32
    cc5c:	9ac82027 	lsl	x7, x1, x8
    cc60:	92407cc5 	and	x5, x6, #0xffffffff
    cc64:	9ac32422 	lsr	x2, x1, x3
    cc68:	9ac32403 	lsr	x3, x0, x3
    cc6c:	aa070063 	orr	x3, x3, x7
    cc70:	9ac9084a 	udiv	x10, x2, x9
    cc74:	9ac82007 	lsl	x7, x0, x8
    cc78:	9b098940 	msub	x0, x10, x9, x2
    cc7c:	aa0a03e1 	mov	x1, x10
    cc80:	9b0a7ca2 	mul	x2, x5, x10
    cc84:	93c38000 	extr	x0, x0, x3, #32
    cc88:	eb00005f 	cmp	x2, x0
    cc8c:	540000a9 	b.ls	cca0 <__divti3+0x2e0>  // b.plast
    cc90:	ab0000c0 	adds	x0, x6, x0
    cc94:	d1000541 	sub	x1, x10, #0x1
    cc98:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cc9c:	54000468 	b.hi	cd28 <__divti3+0x368>  // b.pmore
    cca0:	cb020000 	sub	x0, x0, x2
    cca4:	9ac9080a 	udiv	x10, x0, x9
    cca8:	9b098140 	msub	x0, x10, x9, x0
    ccac:	aa0a03e2 	mov	x2, x10
    ccb0:	9b0a7ca8 	mul	x8, x5, x10
    ccb4:	b3607c03 	bfi	x3, x0, #32, #32
    ccb8:	eb03011f 	cmp	x8, x3
    ccbc:	540000a9 	b.ls	ccd0 <__divti3+0x310>  // b.plast
    ccc0:	ab0300c3 	adds	x3, x6, x3
    ccc4:	d1000542 	sub	x2, x10, #0x1
    ccc8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cccc:	54000288 	b.hi	cd1c <__divti3+0x35c>  // b.pmore
    ccd0:	cb080063 	sub	x3, x3, x8
    ccd4:	aa018041 	orr	x1, x2, x1, lsl #32
    ccd8:	17ffffc2 	b	cbe0 <__divti3+0x220>
    ccdc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cce0:	d2800001 	mov	x1, #0x0                   	// #0
    cce4:	9a9f87e0 	cset	x0, ls	// ls = plast
    cce8:	17ffff68 	b	ca88 <__divti3+0xc8>
    ccec:	aa0103e0 	mov	x0, x1
    ccf0:	d2800001 	mov	x1, #0x0                   	// #0
    ccf4:	17ffff65 	b	ca88 <__divti3+0xc8>
    ccf8:	d1000860 	sub	x0, x3, #0x2
    ccfc:	8b0600a5 	add	x5, x5, x6
    cd00:	17ffff52 	b	ca48 <__divti3+0x88>
    cd04:	d1000961 	sub	x1, x11, #0x2
    cd08:	8b0800a5 	add	x5, x5, x8
    cd0c:	17ffff85 	b	cb20 <__divti3+0x160>
    cd10:	d1000965 	sub	x5, x11, #0x2
    cd14:	8b080063 	add	x3, x3, x8
    cd18:	17ffff8e 	b	cb50 <__divti3+0x190>
    cd1c:	d1000942 	sub	x2, x10, #0x2
    cd20:	8b060063 	add	x3, x3, x6
    cd24:	17ffffeb 	b	ccd0 <__divti3+0x310>
    cd28:	d1000941 	sub	x1, x10, #0x2
    cd2c:	8b060000 	add	x0, x0, x6
    cd30:	17ffffdc 	b	cca0 <__divti3+0x2e0>
    cd34:	d1000900 	sub	x0, x8, #0x2
    cd38:	8b060063 	add	x3, x3, x6
    cd3c:	17ffffb4 	b	cc0c <__divti3+0x24c>

000000000000cd40 <__modti3>:
    cd40:	d503245f 	bti	c
    cd44:	d2800004 	mov	x4, #0x0                   	// #0
    cd48:	b6f80081 	tbz	x1, #63, cd58 <__modti3+0x18>
    cd4c:	eb0003e0 	negs	x0, x0
    cd50:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cd54:	da0103e1 	ngc	x1, x1
    cd58:	f100007f 	cmp	x3, #0x0
    cd5c:	5400128b 	b.lt	cfac <__modti3+0x26c>  // b.tstop
    cd60:	aa0003e7 	mov	x7, x0
    cd64:	aa0103e6 	mov	x6, x1
    cd68:	540004e1 	b.ne	ce04 <__modti3+0xc4>  // b.any
    cd6c:	eb02003f 	cmp	x1, x2
    cd70:	54000dc2 	b.cs	cf28 <__modti3+0x1e8>  // b.hs, b.nlast
    cd74:	dac01043 	clz	x3, x2
    cd78:	aa0303e5 	mov	x5, x3
    cd7c:	b40000e3 	cbz	x3, cd98 <__modti3+0x58>
    cd80:	4b0303e6 	neg	w6, w3
    cd84:	9ac32021 	lsl	x1, x1, x3
    cd88:	9ac32042 	lsl	x2, x2, x3
    cd8c:	9ac62406 	lsr	x6, x0, x6
    cd90:	aa0100c6 	orr	x6, x6, x1
    cd94:	9ac32007 	lsl	x7, x0, x3
    cd98:	d360fc40 	lsr	x0, x2, #32
    cd9c:	92407c43 	and	x3, x2, #0xffffffff
    cda0:	9ac008c1 	udiv	x1, x6, x0
    cda4:	9b009826 	msub	x6, x1, x0, x6
    cda8:	9b017c61 	mul	x1, x3, x1
    cdac:	93c780c6 	extr	x6, x6, x7, #32
    cdb0:	eb06003f 	cmp	x1, x6
    cdb4:	540000a9 	b.ls	cdc8 <__modti3+0x88>  // b.plast
    cdb8:	ab060046 	adds	x6, x2, x6
    cdbc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    cdc0:	8b0200c8 	add	x8, x6, x2
    cdc4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    cdc8:	cb0100c6 	sub	x6, x6, x1
    cdcc:	9ac008c8 	udiv	x8, x6, x0
    cdd0:	9b009901 	msub	x1, x8, x0, x6
    cdd4:	aa0703e0 	mov	x0, x7
    cdd8:	9b087c63 	mul	x3, x3, x8
    cddc:	b3607c20 	bfi	x0, x1, #32, #32
    cde0:	eb00007f 	cmp	x3, x0
    cde4:	54001088 	b.hi	cff4 <__modti3+0x2b4>  // b.pmore
    cde8:	cb030000 	sub	x0, x0, x3
    cdec:	9ac52400 	lsr	x0, x0, x5
    cdf0:	d2800001 	mov	x1, #0x0                   	// #0
    cdf4:	b4000064 	cbz	x4, ce00 <__modti3+0xc0>
    cdf8:	eb0003e0 	negs	x0, x0
    cdfc:	da0103e1 	ngc	x1, x1
    ce00:	d65f03c0 	ret
    ce04:	dac01066 	clz	x6, x3
    ce08:	eb03003f 	cmp	x1, x3
    ce0c:	54ffff43 	b.cc	cdf4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    ce10:	93407cc5 	sxtw	x5, w6
    ce14:	d2800808 	mov	x8, #0x40                  	// #64
    ce18:	cb050108 	sub	x8, x8, x5
    ce1c:	9ac62063 	lsl	x3, x3, x6
    ce20:	9ac62025 	lsl	x5, x1, x6
    ce24:	9ac82447 	lsr	x7, x2, x8
    ce28:	aa0300e7 	orr	x7, x7, x3
    ce2c:	9ac82423 	lsr	x3, x1, x8
    ce30:	92407cec 	and	x12, x7, #0xffffffff
    ce34:	d360fcea 	lsr	x10, x7, #32
    ce38:	9ac82401 	lsr	x1, x0, x8
    ce3c:	aa050021 	orr	x1, x1, x5
    ce40:	9ac62042 	lsl	x2, x2, x6
    ce44:	9ac62000 	lsl	x0, x0, x6
    ce48:	9aca086b 	udiv	x11, x3, x10
    ce4c:	9b0a8d63 	msub	x3, x11, x10, x3
    ce50:	aa0b03e5 	mov	x5, x11
    ce54:	9b0b7d89 	mul	x9, x12, x11
    ce58:	93c18063 	extr	x3, x3, x1, #32
    ce5c:	eb03013f 	cmp	x9, x3
    ce60:	540000a9 	b.ls	ce74 <__modti3+0x134>  // b.plast
    ce64:	ab0300e3 	adds	x3, x7, x3
    ce68:	d1000565 	sub	x5, x11, #0x1
    ce6c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ce70:	54001168 	b.hi	d09c <__modti3+0x35c>  // b.pmore
    ce74:	cb090063 	sub	x3, x3, x9
    ce78:	9aca086b 	udiv	x11, x3, x10
    ce7c:	9b0a8d6a 	msub	x10, x11, x10, x3
    ce80:	aa0b03e9 	mov	x9, x11
    ce84:	9b0b7d8c 	mul	x12, x12, x11
    ce88:	b3607d41 	bfi	x1, x10, #32, #32
    ce8c:	eb01019f 	cmp	x12, x1
    ce90:	540000a9 	b.ls	cea4 <__modti3+0x164>  // b.plast
    ce94:	ab0100e1 	adds	x1, x7, x1
    ce98:	d1000569 	sub	x9, x11, #0x1
    ce9c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    cea0:	54000f88 	b.hi	d090 <__modti3+0x350>  // b.pmore
    cea4:	aa058123 	orr	x3, x9, x5, lsl #32
    cea8:	92407c4b 	and	x11, x2, #0xffffffff
    ceac:	2a0903e9 	mov	w9, w9
    ceb0:	d360fc4a 	lsr	x10, x2, #32
    ceb4:	d360fc63 	lsr	x3, x3, #32
    ceb8:	cb0c0021 	sub	x1, x1, x12
    cebc:	aa0a03ec 	mov	x12, x10
    cec0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    cec4:	9b0b7d25 	mul	x5, x9, x11
    cec8:	9b0b7c6b 	mul	x11, x3, x11
    cecc:	9b0a2d29 	madd	x9, x9, x10, x11
    ced0:	92407caa 	and	x10, x5, #0xffffffff
    ced4:	9b0c7c63 	mul	x3, x3, x12
    ced8:	8b458125 	add	x5, x9, x5, lsr #32
    cedc:	8b0d0069 	add	x9, x3, x13
    cee0:	eb05017f 	cmp	x11, x5
    cee4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    cee8:	8b058149 	add	x9, x10, x5, lsl #32
    ceec:	8b458063 	add	x3, x3, x5, lsr #32
    cef0:	eb03003f 	cmp	x1, x3
    cef4:	54000063 	b.cc	cf00 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    cef8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    cefc:	54000082 	b.cs	cf0c <__modti3+0x1cc>  // b.hs, b.nlast
    cf00:	eb020129 	subs	x9, x9, x2
    cf04:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    cf08:	cb070063 	sub	x3, x3, x7
    cf0c:	eb090000 	subs	x0, x0, x9
    cf10:	da030021 	sbc	x1, x1, x3
    cf14:	9ac62400 	lsr	x0, x0, x6
    cf18:	9ac82028 	lsl	x8, x1, x8
    cf1c:	aa000100 	orr	x0, x8, x0
    cf20:	9ac62421 	lsr	x1, x1, x6
    cf24:	17ffffb4 	b	cdf4 <__modti3+0xb4>
    cf28:	b5000062 	cbnz	x2, cf34 <__modti3+0x1f4>
    cf2c:	d2800023 	mov	x3, #0x1                   	// #1
    cf30:	9ac20862 	udiv	x2, x3, x2
    cf34:	dac01048 	clz	x8, x2
    cf38:	aa0803e5 	mov	x5, x8
    cf3c:	b5000668 	cbnz	x8, d008 <__modti3+0x2c8>
    cf40:	cb020020 	sub	x0, x1, x2
    cf44:	d360fc49 	lsr	x9, x2, #32
    cf48:	92407c4a 	and	x10, x2, #0xffffffff
    cf4c:	9ac90801 	udiv	x1, x0, x9
    cf50:	9b098020 	msub	x0, x1, x9, x0
    cf54:	9b0a7c21 	mul	x1, x1, x10
    cf58:	93c78000 	extr	x0, x0, x7, #32
    cf5c:	eb00003f 	cmp	x1, x0
    cf60:	540000a9 	b.ls	cf74 <__modti3+0x234>  // b.plast
    cf64:	ab000040 	adds	x0, x2, x0
    cf68:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cf6c:	8b020003 	add	x3, x0, x2
    cf70:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cf74:	cb010001 	sub	x1, x0, x1
    cf78:	9ac90820 	udiv	x0, x1, x9
    cf7c:	9b098403 	msub	x3, x0, x9, x1
    cf80:	aa0703e1 	mov	x1, x7
    cf84:	9b0a7c00 	mul	x0, x0, x10
    cf88:	b3607c61 	bfi	x1, x3, #32, #32
    cf8c:	eb01001f 	cmp	x0, x1
    cf90:	540000a9 	b.ls	cfa4 <__modti3+0x264>  // b.plast
    cf94:	ab010041 	adds	x1, x2, x1
    cf98:	8b020022 	add	x2, x1, x2
    cf9c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    cfa0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    cfa4:	cb000020 	sub	x0, x1, x0
    cfa8:	17ffff91 	b	cdec <__modti3+0xac>
    cfac:	eb0203e5 	negs	x5, x2
    cfb0:	aa0003e7 	mov	x7, x0
    cfb4:	da0303e8 	ngc	x8, x3
    cfb8:	aa0503e2 	mov	x2, x5
    cfbc:	aa0803e3 	mov	x3, x8
    cfc0:	aa0103e6 	mov	x6, x1
    cfc4:	b4ffed48 	cbz	x8, cd6c <__modti3+0x2c>
    cfc8:	eb01011f 	cmp	x8, x1
    cfcc:	54fff148 	b.hi	cdf4 <__modti3+0xb4>  // b.pmore
    cfd0:	dac01109 	clz	x9, x8
    cfd4:	2a0903e6 	mov	w6, w9
    cfd8:	b5fff1c9 	cbnz	x9, ce10 <__modti3+0xd0>
    cfdc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    cfe0:	54000068 	b.hi	cfec <__modti3+0x2ac>  // b.pmore
    cfe4:	eb050007 	subs	x7, x0, x5
    cfe8:	da080021 	sbc	x1, x1, x8
    cfec:	aa0703e0 	mov	x0, x7
    cff0:	17ffff81 	b	cdf4 <__modti3+0xb4>
    cff4:	ab000040 	adds	x0, x2, x0
    cff8:	8b020002 	add	x2, x0, x2
    cffc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d000:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d004:	17ffff79 	b	cde8 <__modti3+0xa8>
    d008:	9ac82042 	lsl	x2, x2, x8
    d00c:	d2800803 	mov	x3, #0x40                  	// #64
    d010:	cb080063 	sub	x3, x3, x8
    d014:	d360fc49 	lsr	x9, x2, #32
    d018:	9ac82027 	lsl	x7, x1, x8
    d01c:	92407c4a 	and	x10, x2, #0xffffffff
    d020:	9ac32426 	lsr	x6, x1, x3
    d024:	9ac32403 	lsr	x3, x0, x3
    d028:	aa070063 	orr	x3, x3, x7
    d02c:	9ac908c1 	udiv	x1, x6, x9
    d030:	9ac82007 	lsl	x7, x0, x8
    d034:	9b099820 	msub	x0, x1, x9, x6
    d038:	9b017d41 	mul	x1, x10, x1
    d03c:	93c38000 	extr	x0, x0, x3, #32
    d040:	eb00003f 	cmp	x1, x0
    d044:	540000a9 	b.ls	d058 <__modti3+0x318>  // b.plast
    d048:	ab000040 	adds	x0, x2, x0
    d04c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d050:	8b020006 	add	x6, x0, x2
    d054:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d058:	cb010000 	sub	x0, x0, x1
    d05c:	9ac90801 	udiv	x1, x0, x9
    d060:	9b098026 	msub	x6, x1, x9, x0
    d064:	aa0303e0 	mov	x0, x3
    d068:	9b017d41 	mul	x1, x10, x1
    d06c:	b3607cc0 	bfi	x0, x6, #32, #32
    d070:	eb00003f 	cmp	x1, x0
    d074:	540000a9 	b.ls	d088 <__modti3+0x348>  // b.plast
    d078:	ab000040 	adds	x0, x2, x0
    d07c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d080:	8b020003 	add	x3, x0, x2
    d084:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d088:	cb010000 	sub	x0, x0, x1
    d08c:	17ffffb0 	b	cf4c <__modti3+0x20c>
    d090:	d1000969 	sub	x9, x11, #0x2
    d094:	8b070021 	add	x1, x1, x7
    d098:	17ffff83 	b	cea4 <__modti3+0x164>
    d09c:	d1000965 	sub	x5, x11, #0x2
    d0a0:	8b070063 	add	x3, x3, x7
    d0a4:	17ffff74 	b	ce74 <__modti3+0x134>
    d0a8:	d503201f 	nop
    d0ac:	d503201f 	nop

000000000000d0b0 <atexit>:
    d0b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d0b4:	f0000082 	adrp	x2, 20000 <__data_start>
    d0b8:	d2800001 	mov	x1, #0x0                   	// #0
    d0bc:	910003fd 	mov	x29, sp
    d0c0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d0c4:	f9400442 	ldr	x2, [x2, #8]
    d0c8:	17ffd58e 	b	2700 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d0cc <_fini>:
    d0cc:	d503201f 	nop
    d0d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d0d4:	910003fd 	mov	x29, sp
    d0d8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d0dc:	d65f03c0 	ret
