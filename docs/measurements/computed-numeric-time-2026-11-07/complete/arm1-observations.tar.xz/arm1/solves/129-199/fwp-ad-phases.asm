
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-ad-phases:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b0 <_init>:
    26b0:	d503201f 	nop
    26b4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26b8:	910003fd 	mov	x29, sp
    26bc:	9400019e 	bl	2d34 <call_weak_fn>
    26c0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26c4:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26d8:	f946fe11 	ldr	x17, [x16, #3576]
    26dc:	9137e210 	add	x16, x16, #0xdf8
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <_exit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <strlen@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <__sprintf_chk@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <exit@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <__libc_start_main@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtoll@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <strtod@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_finalize@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_atexit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_init@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <fputc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <clock_gettime@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <setvbuf@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <__memcpy_chk@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <signal@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <__snprintf_chk@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fclose@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <fopen@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <malloc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <pthread_attr_destroy@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <sigemptyset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <memset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <calloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <realloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <__stack_chk_fail@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <close@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <sigaction@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <__gmon_start__@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <write@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <abort@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <swapcontext@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <__fprintf_chk@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <strcmp@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <mmap@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtol@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <strtof@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <free@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <nanosleep@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strchr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <strtoull@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <fwrite@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <pthread_create@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <munmap@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <fflush@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <strcpy@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <sysconf@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <strstr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <_Exit@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <pthread_join@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <getenv@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <__divti3+0x2a0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	912000a5 	add	x5, x5, #0x800
    2aa0:	f0000044 	adrp	x4, d000 <__divti3+0x2a0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	91202084 	add	x4, x4, #0x808
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4e 	bl	2800 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400058c 	bl	4100 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc88>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	9101c2a1 	add	x1, x21, #0x70
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe928>
    2b20:	910de000 	add	x0, x0, #0x378
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9005c20 	str	x0, [x1, #184]
    2b2c:	94000795 	bl	4980 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <__divti3+0x2a0>
    2b34:	912c6000 	add	x0, x0, #0xb18
    2b38:	97ffffba 	bl	2a20 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1b 	bl	27c0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff0d 	bl	27d0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff12 	bl	27f0 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97fffefc 	bl	27a0 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x1e60>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91208042 	add	x2, x2, #0x820
    2bdc:	97ffff71 	bl	29a0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff15 	bl	2840 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff84 	bl	2a10 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c2b5 	add	x21, x21, #0x70
    2c10:	97ffff6c 	bl	29c0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9434aa0 	ldr	w0, [x21, #840]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	f0000040 	adrp	x0, d000 <__divti3+0x2a0>
    2c4c:	912d2000 	add	x0, x0, #0xb48
    2c50:	9400052c 	bl	4100 <fwp_trap>
    2c54:	f0000040 	adrp	x0, d000 <__divti3+0x2a0>
    2c58:	912ca000 	add	x0, x0, #0xb28
    2c5c:	94000529 	bl	4100 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff46 	bl	2980 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffeeb 	bl	2840 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	f0000040 	adrp	x0, d000 <__divti3+0x2a0>
    2ca0:	912e8000 	add	x0, x0, #0xba0
    2ca4:	94000517 	bl	4100 <fwp_trap>
    2ca8:	f0000040 	adrp	x0, d000 <__divti3+0x2a0>
    2cac:	912dc000 	add	x0, x0, #0xb70
    2cb0:	94000514 	bl	4100 <fwp_trap>
    2cb4:	f0000040 	adrp	x0, d000 <__divti3+0x2a0>
    2cb8:	912f2000 	add	x0, x0, #0xbc8
    2cbc:	94000511 	bl	4100 <fwp_trap>
    2cc0:	97fffef4 	bl	2890 <__stack_chk_fail@plt>
    2cc4:	97ffff07 	bl	28e0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe89 	bl	2750 <__libc_start_main@plt>
    2d30:	97fffeec 	bl	28e0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee0 	b	28c0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91016000 	add	x0, x0, #0x58
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91016021 	add	x1, x1, #0x58
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91016000 	add	x0, x0, #0x58
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91016021 	add	x1, x1, #0x58
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe64 	bl	2780 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0xb80>
    2eb4:	91094021 	add	x1, x1, #0x250
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe51 	bl	2890 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402003 	ldr	x3, [x0, #64]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	29490402 	ldp	w2, w1, [x0, #72]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800b03 	mov	w3, #0x58                  	// #88
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9004c61 	str	w1, [x3, #76]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800b04 	mov	w4, #0x58                  	// #88
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9004822 	str	w2, [x1, #72]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900201f 	str	xzr, [x0, #64]
    2fd4:	fd002400 	str	d0, [x0, #72]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6f 	bl	29c0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe6a 	b	29c0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe66 	b	29c0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000040 	adrp	x0, d000 <__divti3+0x2a0>
    3050:	91122000 	add	x0, x0, #0x488
    3054:	97fffe4f 	bl	2990 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe59 	bl	29c0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe67 	bl	2a00 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4f 	bl	29e0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc4 	b	27f0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xb80>
    3118:	9108c021 	add	x1, x1, #0x230
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffdeb 	bl	28d0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd79 	bl	2710 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	d0000040 	adrp	x0, d000 <__divti3+0x2a0>
    3150:	91128000 	add	x0, x0, #0x4a0
    3154:	97fffe0f 	bl	2990 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe29 	bl	2a00 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc88>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	d0000042 	adrp	x2, d000 <__divti3+0x2a0>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	d0000056 	adrp	x22, d000 <__divti3+0x2a0>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	d0000058 	adrp	x24, d000 <__divti3+0x2a0>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	9113a042 	add	x2, x2, #0x4e8
    31e0:	911502d6 	add	x22, x22, #0x540
    31e4:	913f4318 	add	x24, x24, #0xfd0
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	d0000059 	adrp	x25, d000 <__divti3+0x2a0>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdc1 	bl	2900 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	9114e323 	add	x3, x25, #0x538
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb4 	bl	2900 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	d0000040 	adrp	x0, d000 <__divti3+0x2a0>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	91154000 	add	x0, x0, #0x550
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdc3 	b	2990 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd98 	bl	2900 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd79 	bl	2890 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    32c4:	911702a1 	add	x1, x21, #0x5c0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa40>
    32d8:	9126c0a5 	add	x5, x5, #0x9b0
    32dc:	911702a1 	add	x1, x21, #0x5c0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911702b7 	add	x23, x21, #0x5c0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd91 	bl	29e0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911702b5 	add	x21, x21, #0x5c0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911702b5 	add	x21, x21, #0x5c0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa40>
    3468:	9126a0a5 	add	x5, x5, #0x9a8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2f 	bl	2950 <free@plt>
    3498:	f9400660 	ldr	x0, [x19, #8]
    349c:	97fffd2d 	bl	2950 <free@plt>
    34a0:	f9400a60 	ldr	x0, [x19, #16]
    34a4:	97fffd2b 	bl	2950 <free@plt>
    34a8:	a9007e7f 	stp	xzr, xzr, [x19]
    34ac:	a9017e7f 	stp	xzr, xzr, [x19, #16]
    34b0:	f900127f 	str	xzr, [x19, #32]
    34b4:	f9400bf3 	ldr	x19, [sp, #16]
    34b8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34bc:	d65f03c0 	ret

00000000000034c0 <buf_grow>:
    34c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c4:	910003fd 	mov	x29, sp
    34c8:	a90153f3 	stp	x19, x20, [sp, #16]
    34cc:	aa0003f4 	mov	x20, x0
    34d0:	f9400400 	ldr	x0, [x0, #8]
    34d4:	b100041f 	cmn	x0, #0x1
    34d8:	54000400 	b.eq	3558 <buf_grow+0x98>  // b.none
    34dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e0:	cb000042 	sub	x2, x2, x0
    34e4:	eb01005f 	cmp	x2, x1
    34e8:	54000383 	b.cc	3558 <buf_grow+0x98>  // b.lo, b.ul, b.last
    34ec:	f9400a82 	ldr	x2, [x20, #16]
    34f0:	91000421 	add	x1, x1, #0x1
    34f4:	8b000033 	add	x19, x1, x0
    34f8:	eb13005f 	cmp	x2, x19
    34fc:	54000242 	b.cs	3544 <buf_grow+0x84>  // b.hs, b.nlast
    3500:	f100005f 	cmp	x2, #0x0
    3504:	b5000262 	cbnz	x2, 3550 <buf_grow+0x90>
    3508:	d2800802 	mov	x2, #0x40                  	// #64
    350c:	eb02027f 	cmp	x19, x2
    3510:	54000068 	b.hi	351c <buf_grow+0x5c>  // b.pmore
    3514:	14000005 	b	3528 <buf_grow+0x68>
    3518:	b7f800a2 	tbnz	x2, #63, 352c <buf_grow+0x6c>
    351c:	d37ff842 	lsl	x2, x2, #1
    3520:	eb02027f 	cmp	x19, x2
    3524:	54ffffa8 	b.hi	3518 <buf_grow+0x58>  // b.pmore
    3528:	aa0203f3 	mov	x19, x2
    352c:	f9400280 	ldr	x0, [x20]
    3530:	aa1303e1 	mov	x1, x19
    3534:	97fffcd3 	bl	2880 <realloc@plt>
    3538:	b4000100 	cbz	x0, 3558 <buf_grow+0x98>
    353c:	f9000280 	str	x0, [x20]
    3540:	f9000a93 	str	x19, [x20, #16]
    3544:	a94153f3 	ldp	x19, x20, [sp, #16]
    3548:	a8c27bfd 	ldp	x29, x30, [sp], #32
    354c:	d65f03c0 	ret
    3550:	54fffe6a 	b.ge	351c <buf_grow+0x5c>  // b.tcont
    3554:	17fffff6 	b	352c <buf_grow+0x6c>
    3558:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    355c:	f947e863 	ldr	x3, [x3, #4048]
    3560:	d2800262 	mov	x2, #0x13                  	// #19
    3564:	d2800021 	mov	x1, #0x1                   	// #1
    3568:	d0000040 	adrp	x0, d000 <__divti3+0x2a0>
    356c:	91122000 	add	x0, x0, #0x488
    3570:	f9400063 	ldr	x3, [x3]
    3574:	97fffd07 	bl	2990 <fwrite@plt>
    3578:	d2800000 	mov	x0, #0x0                   	// #0
    357c:	97fffd11 	bl	29c0 <fflush@plt>
    3580:	52800cc0 	mov	w0, #0x66                  	// #102
    3584:	97fffd1f 	bl	2a00 <_Exit@plt>
    3588:	d503201f 	nop
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc4 	bl	34c0 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc4b 	bl	26f0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc62 	bl	27c0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc6b 	bl	2890 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7a 	bl	2970 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc73 	bl	2970 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <__divti3+0x2a0>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	91156021 	add	x1, x1, #0x558
    37b8:	97fffc8e 	bl	29f0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <__divti3+0x2a0>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91158021 	add	x1, x1, #0x560
    37cc:	97fffc89 	bl	29f0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd2 	bl	2720 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <__divti3+0x2a0>
    37e0:	9115a021 	add	x1, x1, #0x568
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_format_g.constprop.0>:
    3800:	d10483ff 	sub	sp, sp, #0x120
    3804:	d0000044 	adrp	x4, d000 <__divti3+0x2a0>
    3808:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    380c:	f947f442 	ldr	x2, [x2, #4072]
    3810:	9115c084 	add	x4, x4, #0x570
    3814:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3818:	9102c3fd 	add	x29, sp, #0xb0
    381c:	d2800803 	mov	x3, #0x40                  	// #64
    3820:	a90e63f7 	stp	x23, x24, [sp, #224]
    3824:	93407c38 	sxtw	x24, w1
    3828:	aa0303e1 	mov	x1, x3
    382c:	fd008be8 	str	d8, [sp, #272]
    3830:	1e604008 	fmov	d8, d0
    3834:	a90c53f3 	stp	x19, x20, [sp, #192]
    3838:	910083f4 	add	x20, sp, #0x20
    383c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3840:	aa0003f5 	mov	x21, x0
    3844:	a91073fb 	stp	x27, x28, [sp, #256]
    3848:	5100071c 	sub	w28, w24, #0x1
    384c:	2a1c03e5 	mov	w5, w28
    3850:	f9400040 	ldr	x0, [x2]
    3854:	f90057e0 	str	x0, [sp, #168]
    3858:	d2800000 	mov	x0, #0x0                   	// #0
    385c:	52800042 	mov	w2, #0x2                   	// #2
    3860:	aa1403e0 	mov	x0, x20
    3864:	97fffbe7 	bl	2800 <__snprintf_chk@plt>
    3868:	52800ca1 	mov	w1, #0x65                  	// #101
    386c:	aa1403e0 	mov	x0, x20
    3870:	97fffc40 	bl	2970 <strchr@plt>
    3874:	aa0003f3 	mov	x19, x0
    3878:	52800142 	mov	w2, #0xa                   	// #10
    387c:	91000400 	add	x0, x0, #0x1
    3880:	d2800001 	mov	x1, #0x0                   	// #0
    3884:	97fffc2b 	bl	2930 <strtol@plt>
    3888:	aa0003f7 	mov	x23, x0
    388c:	11001400 	add	w0, w0, #0x5
    3890:	7100541f 	cmp	w0, #0x15
    3894:	54000d68 	b.hi	3a40 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3898:	4b170385 	sub	w5, w28, w23
    389c:	710000bf 	cmp	w5, #0x0
    38a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    38a4:	54000b80 	b.eq	3a14 <fwp_format_g.constprop.0+0x214>  // b.none
    38a8:	394083e0 	ldrb	w0, [sp, #32]
    38ac:	cb180273 	sub	x19, x19, x24
    38b0:	91000673 	add	x19, x19, #0x1
    38b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    38b8:	7100b41f 	cmp	w0, #0x2d
    38bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    38c0:	1a9f17e4 	cset	w4, eq	// eq = none
    38c4:	cb010266 	sub	x6, x19, x1
    38c8:	d10004da 	sub	x26, x6, #0x1
    38cc:	540018a0 	b.eq	3be0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    38d0:	910183f9 	add	x25, sp, #0x60
    38d4:	d280091b 	mov	x27, #0x48                  	// #72
    38d8:	aa1903e7 	mov	x7, x25
    38dc:	91000423 	add	x3, x1, #0x1
    38e0:	91011cc6 	add	x6, x6, #0x47
    38e4:	910004f6 	add	x22, x7, #0x1
    38e8:	37f80ff7 	tbnz	w23, #31, 3ae4 <fwp_format_g.constprop.0+0x2e4>
    38ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38f0:	93407ef7 	sxtw	x23, w23
    38f4:	390000e4 	strb	w4, [x7]
    38f8:	aa1303e1 	mov	x1, x19
    38fc:	aa1703e2 	mov	x2, x23
    3900:	aa1603e0 	mov	x0, x22
    3904:	b9000be5 	str	w5, [sp, #8]
    3908:	cb170374 	sub	x20, x27, x23
    390c:	a9011be3 	stp	x3, x6, [sp, #16]
    3910:	97fffb78 	bl	26f0 <memcpy@plt>
    3914:	d1000694 	sub	x20, x20, #0x1
    3918:	f9400be3 	ldr	x3, [sp, #16]
    391c:	8b1702d6 	add	x22, x22, x23
    3920:	aa1603e0 	mov	x0, x22
    3924:	aa1a03e2 	mov	x2, x26
    3928:	aa0303e1 	mov	x1, x3
    392c:	aa1403e3 	mov	x3, x20
    3930:	97fffbac 	bl	27e0 <__memcpy_chk@plt>
    3934:	8b1a02d6 	add	x22, x22, x26
    3938:	f9400fe6 	ldr	x6, [sp, #24]
    393c:	d2800900 	mov	x0, #0x48                  	// #72
    3940:	b9400be5 	ldr	w5, [sp, #8]
    3944:	8b170261 	add	x1, x19, x23
    3948:	cb1400c3 	sub	x3, x6, x20
    394c:	cb060294 	sub	x20, x20, x6
    3950:	f101207f 	cmp	x3, #0x48
    3954:	93407cb8 	sxtw	x24, w5
    3958:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    395c:	aa1803e2 	mov	x2, x24
    3960:	8b1802d3 	add	x19, x22, x24
    3964:	8b140063 	add	x3, x3, x20
    3968:	aa1603e0 	mov	x0, x22
    396c:	97fffb9d 	bl	27e0 <__memcpy_chk@plt>
    3970:	cb190273 	sub	x19, x19, x25
    3974:	d28031e0 	mov	x0, #0x18f                 	// #399
    3978:	eb00027f 	cmp	x19, x0
    397c:	aa1903e1 	mov	x1, x25
    3980:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3984:	aa1503e0 	mov	x0, x21
    3988:	aa1303e2 	mov	x2, x19
    398c:	97fffb59 	bl	26f0 <memcpy@plt>
    3990:	38336abf 	strb	wzr, [x21, x19]
    3994:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3998:	aa1503e0 	mov	x0, x21
    399c:	97fffb61 	bl	2720 <strlen@plt>
    39a0:	aa0003f3 	mov	x19, x0
    39a4:	528005c1 	mov	w1, #0x2e                  	// #46
    39a8:	aa1503e0 	mov	x0, x21
    39ac:	97fffbf1 	bl	2970 <strchr@plt>
    39b0:	b4000140 	cbz	x0, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b4:	b4000133 	cbz	x19, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b8:	aa1303e1 	mov	x1, x19
    39bc:	d1000673 	sub	x19, x19, #0x1
    39c0:	38736aa0 	ldrb	w0, [x21, x19]
    39c4:	7100c01f 	cmp	w0, #0x30
    39c8:	54001001 	b.ne	3bc8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    39cc:	38336abf 	strb	wzr, [x21, x19]
    39d0:	b5ffff53 	cbnz	x19, 39b8 <fwp_format_g.constprop.0+0x1b8>
    39d4:	d503201f 	nop
    39d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    39dc:	f947f400 	ldr	x0, [x0, #4072]
    39e0:	f94057e2 	ldr	x2, [sp, #168]
    39e4:	f9400001 	ldr	x1, [x0]
    39e8:	eb010042 	subs	x2, x2, x1
    39ec:	d2800001 	mov	x1, #0x0                   	// #0
    39f0:	54001061 	b.ne	3bfc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a00:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a04:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a08:	fd408be8 	ldr	d8, [sp, #272]
    3a0c:	910483ff 	add	sp, sp, #0x120
    3a10:	d65f03c0 	ret
    3a14:	1e604100 	fmov	d0, d8
    3a18:	710000bf 	cmp	w5, #0x0
    3a1c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3a20:	aa1503e0 	mov	x0, x21
    3a24:	d0000044 	adrp	x4, d000 <__divti3+0x2a0>
    3a28:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a2c:	91162084 	add	x4, x4, #0x588
    3a30:	52800042 	mov	w2, #0x2                   	// #2
    3a34:	d2803201 	mov	x1, #0x190                 	// #400
    3a38:	97fffb72 	bl	2800 <__snprintf_chk@plt>
    3a3c:	17ffffd7 	b	3998 <fwp_format_g.constprop.0+0x198>
    3a40:	cb140273 	sub	x19, x19, x20
    3a44:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a48:	910183f9 	add	x25, sp, #0x60
    3a4c:	aa1303e2 	mov	x2, x19
    3a50:	aa1403e1 	mov	x1, x20
    3a54:	aa1903e0 	mov	x0, x25
    3a58:	d2800803 	mov	x3, #0x40                  	// #64
    3a5c:	97fffb61 	bl	27e0 <__memcpy_chk@plt>
    3a60:	38336b3f 	strb	wzr, [x25, x19]
    3a64:	aa1903e0 	mov	x0, x25
    3a68:	528005c1 	mov	w1, #0x2e                  	// #46
    3a6c:	97fffbc1 	bl	2970 <strchr@plt>
    3a70:	b40001c0 	cbz	x0, 3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a74:	b50000b3 	cbnz	x19, 3a88 <fwp_format_g.constprop.0+0x288>
    3a78:	1400000c 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a7c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a80:	f1000673 	subs	x19, x19, #0x1
    3a84:	54000120 	b.eq	3aa8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a88:	8b130320 	add	x0, x25, x19
    3a8c:	385ff001 	ldurb	w1, [x0, #-1]
    3a90:	7100c03f 	cmp	w1, #0x30
    3a94:	54ffff40 	b.eq	3a7c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a98:	d1000673 	sub	x19, x19, #0x1
    3a9c:	38736b20 	ldrb	w0, [x25, x19]
    3aa0:	7100b81f 	cmp	w0, #0x2e
    3aa4:	54000a80 	b.eq	3bf4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3aa8:	710002ff 	cmp	w23, #0x0
    3aac:	528005a1 	mov	w1, #0x2d                  	// #45
    3ab0:	aa1903e5 	mov	x5, x25
    3ab4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	52800566 	mov	w6, #0x2b                  	// #43
    3ac0:	d0000044 	adrp	x4, d000 <__divti3+0x2a0>
    3ac4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ac8:	9115e084 	add	x4, x4, #0x578
    3acc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ad0:	52800042 	mov	w2, #0x2                   	// #2
    3ad4:	d2803201 	mov	x1, #0x190                 	// #400
    3ad8:	97fffb4a 	bl	2800 <__snprintf_chk@plt>
    3adc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ae0:	17ffffbe 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3ae4:	52800605 	mov	w5, #0x30                  	// #48
    3ae8:	390000e5 	strb	w5, [x7]
    3aec:	d100077b 	sub	x27, x27, #0x1
    3af0:	aa0303e1 	mov	x1, x3
    3af4:	aa1603e0 	mov	x0, x22
    3af8:	aa1b03e3 	mov	x3, x27
    3afc:	aa1a03e2 	mov	x2, x26
    3b00:	f90007e6 	str	x6, [sp, #8]
    3b04:	b90013e4 	str	w4, [sp, #16]
    3b08:	8b1a02d6 	add	x22, x22, x26
    3b0c:	b9001be5 	str	w5, [sp, #24]
    3b10:	97fffb34 	bl	27e0 <__memcpy_chk@plt>
    3b14:	f94007e6 	ldr	x6, [sp, #8]
    3b18:	2a3703e7 	mvn	w7, w23
    3b1c:	b94013e4 	ldr	w4, [sp, #16]
    3b20:	cb1b00c1 	sub	x1, x6, x27
    3b24:	cb06037b 	sub	x27, x27, x6
    3b28:	f101203f 	cmp	x1, #0x48
    3b2c:	d2800906 	mov	x6, #0x48                  	// #72
    3b30:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3b34:	8b1b0023 	add	x3, x1, x27
    3b38:	310006ff 	cmn	w23, #0x1
    3b3c:	54000220 	b.eq	3b80 <fwp_format_g.constprop.0+0x380>  // b.none
    3b40:	b9401be5 	ldr	w5, [sp, #24]
    3b44:	d2800001 	mov	x1, #0x0                   	// #0
    3b48:	f101207f 	cmp	x3, #0x48
    3b4c:	d1000462 	sub	x2, x3, #0x1
    3b50:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b54:	38216ac5 	strb	w5, [x22, x1]
    3b58:	cb030003 	sub	x3, x0, x3
    3b5c:	91000421 	add	x1, x1, #0x1
    3b60:	91000463 	add	x3, x3, #0x1
    3b64:	eb00007f 	cmp	x3, x0
    3b68:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b6c:	cb000063 	sub	x3, x3, x0
    3b70:	8b020063 	add	x3, x3, x2
    3b74:	6b0100ff 	cmp	w7, w1
    3b78:	54fffe8c 	b.gt	3b48 <fwp_format_g.constprop.0+0x348>
    3b7c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b80:	f101207f 	cmp	x3, #0x48
    3b84:	d2800905 	mov	x5, #0x48                  	// #72
    3b88:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	cb0300a1 	sub	x1, x5, x3
    3b94:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b98:	91000421 	add	x1, x1, #0x1
    3b9c:	d1000463 	sub	x3, x3, #0x1
    3ba0:	eb05003f 	cmp	x1, x5
    3ba4:	38001402 	strb	w2, [x0], #1
    3ba8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3bac:	93407f82 	sxtw	x2, w28
    3bb0:	cb050025 	sub	x5, x1, x5
    3bb4:	aa1303e1 	mov	x1, x19
    3bb8:	8b0300a3 	add	x3, x5, x3
    3bbc:	8b1802d3 	add	x19, x22, x24
    3bc0:	97fffb08 	bl	27e0 <__memcpy_chk@plt>
    3bc4:	17ffff6b 	b	3970 <fwp_format_g.constprop.0+0x170>
    3bc8:	d1000421 	sub	x1, x1, #0x1
    3bcc:	38616aa0 	ldrb	w0, [x21, x1]
    3bd0:	7100b81f 	cmp	w0, #0x2e
    3bd4:	54fff021 	b.ne	39d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3bd8:	38216abf 	strb	wzr, [x21, x1]
    3bdc:	17ffff7f 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3be0:	910187e7 	add	x7, sp, #0x61
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bec:	390183e0 	strb	w0, [sp, #96]
    3bf0:	17ffff3b 	b	38dc <fwp_format_g.constprop.0+0xdc>
    3bf4:	38336b3f 	strb	wzr, [x25, x19]
    3bf8:	17ffffac 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3bfc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c00:	97fffb24 	bl	2890 <__stack_chk_fail@plt>

0000000000003c04 <fwp_heap_report>:
    3c04:	d105c3ff 	sub	sp, sp, #0x170
    3c08:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    3c0c:	91170042 	add	x2, x2, #0x5c0
    3c10:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    3c14:	f947e821 	ldr	x1, [x1, #4048]
    3c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c1c:	910443fd 	add	x29, sp, #0x110
    3c20:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3c24:	f947f400 	ldr	x0, [x0, #4072]
    3c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    3c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    3c30:	a9156bf9 	stp	x25, x26, [sp, #336]
    3c34:	6d1627e8 	stp	d8, d9, [sp, #352]
    3c38:	fd4a1c48 	ldr	d8, [x2, #5176]
    3c3c:	fd4a2049 	ldr	d9, [x2, #5184]
    3c40:	f9400036 	ldr	x22, [x1]
    3c44:	f9400001 	ldr	x1, [x0]
    3c48:	f90087e1 	str	x1, [sp, #264]
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	f949e459 	ldr	x25, [x2, #5064]
    3c54:	d0000041 	adrp	x1, d000 <__divti3+0x2a0>
    3c58:	f94a1057 	ldr	x23, [x2, #5152]
    3c5c:	d0000040 	adrp	x0, d000 <__divti3+0x2a0>
    3c60:	f94a1458 	ldr	x24, [x2, #5160]
    3c64:	91164021 	add	x1, x1, #0x590
    3c68:	91166000 	add	x0, x0, #0x598
    3c6c:	97fffaed 	bl	2820 <fopen@plt>
    3c70:	b4000760 	cbz	x0, 3d5c <fwp_heap_report+0x158>
    3c74:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c78:	a91253f3 	stp	x19, x20, [sp, #288]
    3c7c:	aa0003f4 	mov	x20, x0
    3c80:	910023f3 	add	x19, sp, #0x8
    3c84:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c88:	72aae915 	movk	w21, #0x5748, lsl #16
    3c8c:	d503201f 	nop
    3c90:	aa1403e2 	mov	x2, x20
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	52802001 	mov	w1, #0x100                 	// #256
    3c9c:	97fffb69 	bl	2a40 <fgets@plt>
    3ca0:	b4000280 	cbz	x0, 3cf0 <fwp_heap_report+0xec>
    3ca4:	b9400261 	ldr	w1, [x19]
    3ca8:	6b15003f 	cmp	w1, w21
    3cac:	54ffff21 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cb0:	39401260 	ldrb	w0, [x19, #4]
    3cb4:	7101341f 	cmp	w0, #0x4d
    3cb8:	54fffec1 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cbc:	394037e0 	ldrb	w0, [sp, #13]
    3cc0:	7100e81f 	cmp	w0, #0x3a
    3cc4:	54fffe61 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cc8:	52800142 	mov	w2, #0xa                   	// #10
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	91003be0 	add	x0, sp, #0xe
    3cd4:	97fffb17 	bl	2930 <strtol@plt>
    3cd8:	aa1403e2 	mov	x2, x20
    3cdc:	aa0003fa 	mov	x26, x0
    3ce0:	52802001 	mov	w1, #0x100                 	// #256
    3ce4:	aa1303e0 	mov	x0, x19
    3ce8:	97fffb56 	bl	2a40 <fgets@plt>
    3cec:	b5fffdc0 	cbnz	x0, 3ca4 <fwp_heap_report+0xa0>
    3cf0:	aa1403e0 	mov	x0, x20
    3cf4:	97fffac7 	bl	2810 <fclose@plt>
    3cf8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cfc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3d00:	f947f400 	ldr	x0, [x0, #4072]
    3d04:	f94087e2 	ldr	x2, [sp, #264]
    3d08:	f9400001 	ldr	x1, [x0]
    3d0c:	eb010042 	subs	x2, x2, x1
    3d10:	d2800001 	mov	x1, #0x0                   	// #0
    3d14:	54000281 	b.ne	3d64 <fwp_heap_report+0x160>  // b.any
    3d18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d1c:	aa1a03e6 	mov	x6, x26
    3d20:	aa1903e5 	mov	x5, x25
    3d24:	aa1803e4 	mov	x4, x24
    3d28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3d2c:	aa1703e3 	mov	x3, x23
    3d30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3d3c:	1e604121 	fmov	d1, d9
    3d40:	1e604100 	fmov	d0, d8
    3d44:	d0000042 	adrp	x2, d000 <__divti3+0x2a0>
    3d48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d4c:	9116e042 	add	x2, x2, #0x5b8
    3d50:	9105c3ff 	add	sp, sp, #0x170
    3d54:	52800041 	mov	w1, #0x2                   	// #2
    3d58:	17fffaea 	b	2900 <__fprintf_chk@plt>
    3d5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d60:	17ffffe7 	b	3cfc <fwp_heap_report+0xf8>
    3d64:	a91253f3 	stp	x19, x20, [sp, #288]
    3d68:	97fffaca 	bl	2890 <__stack_chk_fail@plt>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_heap_init>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa40>
    3d78:	91130061 	add	x1, x3, #0x4c0
    3d7c:	910003fd 	mov	x29, sp
    3d80:	a90153f3 	stp	x19, x20, [sp, #16]
    3d84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    3d88:	91170262 	add	x2, x19, #0x5c0
    3d8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d90:	52800024 	mov	w4, #0x1                   	// #1
    3d94:	52800200 	mov	w0, #0x10                  	// #16
    3d98:	b913a444 	str	w4, [x2, #5028]
    3d9c:	d503201f 	nop
    3da0:	b8004420 	str	w0, [x1], #4
    3da4:	11004000 	add	w0, w0, #0x10
    3da8:	7104401f 	cmp	w0, #0x110
    3dac:	54ffffa1 	b.ne	3da0 <fwp_heap_init+0x30>  // b.any
    3db0:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0xb80>
    3db4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3db8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa40>
    3dbc:	91140021 	add	x1, x1, #0x500
    3dc0:	3dc09843 	ldr	q3, [x2, #608]
    3dc4:	d2800000 	mov	x0, #0x0                   	// #0
    3dc8:	4e040401 	dup	v1.4s, v0.s[0]
    3dcc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3dd0:	0f215400 	shl	v0.2s, v0.2s, #1
    3dd4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3dd8:	3ca06821 	str	q1, [x1, x0]
    3ddc:	91004000 	add	x0, x0, #0x10
    3de0:	f101801f 	cmp	x0, #0x60
    3de4:	54ffff21 	b.ne	3dc8 <fwp_heap_init+0x58>  // b.any
    3de8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa40>
    3dec:	91130063 	add	x3, x3, #0x4c0
    3df0:	91158084 	add	x4, x4, #0x560
    3df4:	91170266 	add	x6, x19, #0x5c0
    3df8:	d2800002 	mov	x2, #0x0                   	// #0
    3dfc:	d2800000 	mov	x0, #0x0                   	// #0
    3e00:	d2880205 	mov	x5, #0x4010                	// #16400
    3e04:	d503201f 	nop
    3e08:	910f0001 	add	x1, x0, #0x3c0
    3e0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e10:	eb02003f 	cmp	x1, x2
    3e14:	540000a2 	b.cs	3e28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e18:	91000400 	add	x0, x0, #0x1
    3e1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3e20:	eb02003f 	cmp	x1, x2
    3e24:	54ffffa3 	b.cc	3e18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3e28:	91004042 	add	x2, x2, #0x10
    3e2c:	38001480 	strb	w0, [x4], #1
    3e30:	eb05005f 	cmp	x2, x5
    3e34:	54fffea1 	b.ne	3e08 <fwp_heap_init+0x98>  // b.any
    3e38:	528000b5 	mov	w21, #0x5                   	// #5
    3e3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e40:	14000004 	b	3e50 <fwp_heap_init+0xe0>
    3e44:	d342fe94 	lsr	x20, x20, #2
    3e48:	710006b5 	subs	w21, w21, #0x1
    3e4c:	54000720 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3e50:	91404296 	add	x22, x20, #0x10, lsl #12
    3e54:	d2800005 	mov	x5, #0x0                   	// #0
    3e58:	aa1603e1 	mov	x1, x22
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	52880443 	mov	w3, #0x4022                	// #16418
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	d2800000 	mov	x0, #0x0                   	// #0
    3e6c:	97fffaad 	bl	2920 <mmap@plt>
    3e70:	aa0003e6 	mov	x6, x0
    3e74:	b100041f 	cmn	x0, #0x1
    3e78:	54fffe60 	b.eq	3e44 <fwp_heap_init+0xd4>  // b.none
    3e7c:	b40005a0 	cbz	x0, 3f30 <fwp_heap_init+0x1c0>
    3e80:	d350fe94 	lsr	x20, x20, #16
    3e84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e88:	8b0000c7 	add	x7, x6, x0
    3e8c:	91170275 	add	x21, x19, #0x5c0
    3e90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e94:	8b140a81 	add	x1, x20, x20, lsl #2
    3e98:	d2800005 	mov	x5, #0x0                   	// #0
    3e9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ea0:	d37df021 	lsl	x1, x1, #3
    3ea4:	52880443 	mov	w3, #0x4022                	// #16418
    3ea8:	52800002 	mov	w2, #0x0                   	// #0
    3eac:	d2800000 	mov	x0, #0x0                   	// #0
    3eb0:	f909daa7 	str	x7, [x21, #5040]
    3eb4:	f909dea6 	str	x6, [x21, #5048]
    3eb8:	f909e2b6 	str	x22, [x21, #5056]
    3ebc:	f909eab4 	str	x20, [x21, #5072]
    3ec0:	f90a02a1 	str	x1, [x21, #5120]
    3ec4:	97fffa97 	bl	2920 <mmap@plt>
    3ec8:	aa0003e1 	mov	x1, x0
    3ecc:	b100041f 	cmn	x0, #0x1
    3ed0:	54000300 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3ed4:	d0000040 	adrp	x0, d000 <__divti3+0x2a0>
    3ed8:	91190000 	add	x0, x0, #0x640
    3edc:	f909fea1 	str	x1, [x21, #5112]
    3ee0:	97fffad0 	bl	2a20 <getenv@plt>
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	aa0003e1 	mov	x1, x0
    3eec:	b40000e0 	cbz	x0, 3f08 <fwp_heap_init+0x198>
    3ef0:	39400000 	ldrb	w0, [x0]
    3ef4:	340000a0 	cbz	w0, 3f08 <fwp_heap_init+0x198>
    3ef8:	7100c000 	subs	w0, w0, #0x30
    3efc:	54000120 	b.eq	3f20 <fwp_heap_init+0x1b0>  // b.none
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	1a9f07e2 	cset	w2, ne	// ne = any
    3f08:	91170273 	add	x19, x19, #0x5c0
    3f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f10:	b913aa62 	str	w2, [x19, #5032]
    3f14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f1c:	d65f03c0 	ret
    3f20:	39400420 	ldrb	w0, [x1, #1]
    3f24:	7100001f 	cmp	w0, #0x0
    3f28:	1a9f07e2 	cset	w2, ne	// ne = any
    3f2c:	17fffff7 	b	3f08 <fwp_heap_init+0x198>
    3f30:	97fffc40 	bl	3030 <fwp_heap_oom>

0000000000003f34 <fwp_wake_io>:
    3f34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3f38:	9101c122 	add	x2, x9, #0x70
    3f3c:	f9400001 	ldr	x1, [x0]
    3f40:	5280000a 	mov	w10, #0x0                   	// #0
    3f44:	f9403c46 	ldr	x6, [x2, #120]
    3f48:	52800008 	mov	w8, #0x0                   	// #0
    3f4c:	4f000400 	movi	v0.4s, #0x0
    3f50:	52800027 	mov	w7, #0x1                   	// #1
    3f54:	aa0103e2 	mov	x2, x1
    3f58:	b4000321 	cbz	x1, 3fbc <fwp_wake_io+0x88>
    3f5c:	f9408c25 	ldr	x5, [x1, #280]
    3f60:	39015c27 	strb	w7, [x1, #87]
    3f64:	b4000165 	cbz	x5, 3f90 <fwp_wake_io+0x5c>
    3f68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f6c:	b4000364 	cbz	x4, 3fd8 <fwp_wake_io+0xa4>
    3f70:	f9009483 	str	x3, [x4, #296]
    3f74:	f9409423 	ldr	x3, [x1, #296]
    3f78:	b4000043 	cbz	x3, 3f80 <fwp_wake_io+0x4c>
    3f7c:	f9009064 	str	x4, [x3, #288]
    3f80:	91080023 	add	x3, x1, #0x200
    3f84:	f900943f 	str	xzr, [x1, #296]
    3f88:	3c918060 	stur	q0, [x3, #-232]
    3f8c:	f9400001 	ldr	x1, [x0]
    3f90:	f9402843 	ldr	x3, [x2, #80]
    3f94:	f2001c7f 	tst	x3, #0xff000000ff
    3f98:	54fffde1 	b.ne	3f54 <fwp_wake_io+0x20>  // b.any
    3f9c:	39015047 	strb	w7, [x2, #84]
    3fa0:	f900805f 	str	xzr, [x2, #256]
    3fa4:	b40001e6 	cbz	x6, 3fe0 <fwp_wake_io+0xac>
    3fa8:	f90080c2 	str	x2, [x6, #256]
    3fac:	aa0203e6 	mov	x6, x2
    3fb0:	52800028 	mov	w8, #0x1                   	// #1
    3fb4:	aa0103e2 	mov	x2, x1
    3fb8:	b5fffd21 	cbnz	x1, 3f5c <fwp_wake_io+0x28>
    3fbc:	3400006a 	cbz	w10, 3fc8 <fwp_wake_io+0x94>
    3fc0:	9101c120 	add	x0, x9, #0x70
    3fc4:	f900400b 	str	x11, [x0, #128]
    3fc8:	34000068 	cbz	w8, 3fd4 <fwp_wake_io+0xa0>
    3fcc:	9101c129 	add	x9, x9, #0x70
    3fd0:	f9003d26 	str	x6, [x9, #120]
    3fd4:	d65f03c0 	ret
    3fd8:	f90000a3 	str	x3, [x5]
    3fdc:	17ffffe7 	b	3f78 <fwp_wake_io+0x44>
    3fe0:	aa0203eb 	mov	x11, x2
    3fe4:	5280002a 	mov	w10, #0x1                   	// #1
    3fe8:	17fffff1 	b	3fac <fwp_wake_io+0x78>
    3fec:	d503201f 	nop

0000000000003ff0 <fwp_tape_buffers_release>:
    3ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3ff4:	910003fd 	mov	x29, sp
    3ff8:	a90153f3 	stp	x19, x20, [sp, #16]
    3ffc:	aa0003f3 	mov	x19, x0
    4000:	f9400c00 	ldr	x0, [x0, #24]
    4004:	b7f80700 	tbnz	x0, #63, 40e4 <fwp_tape_buffers_release+0xf4>
    4008:	f9401261 	ldr	x1, [x19, #32]
    400c:	b7f80301 	tbnz	x1, #63, 406c <fwp_tape_buffers_release+0x7c>
    4010:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4014:	eb02001f 	cmp	x0, x2
    4018:	540002a8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    401c:	8b000400 	add	x0, x0, x0, lsl #1
    4020:	d2a00102 	mov	x2, #0x80000               	// #524288
    4024:	d37df000 	lsl	x0, x0, #3
    4028:	cb000042 	sub	x2, x2, x0
    402c:	eb420c3f 	cmp	x1, x2, lsr #3
    4030:	540001e8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4034:	8b010c14 	add	x20, x0, x1, lsl #3
    4038:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    403c:	91194000 	add	x0, x0, #0x650
    4040:	97fffa78 	bl	2a20 <getenv@plt>
    4044:	b4000240 	cbz	x0, 408c <fwp_tape_buffers_release+0x9c>
    4048:	39400001 	ldrb	w1, [x0]
    404c:	7100c03f 	cmp	w1, #0x30
    4050:	540001e1 	b.ne	408c <fwp_tape_buffers_release+0x9c>  // b.any
    4054:	39400400 	ldrb	w0, [x0, #1]
    4058:	350001a0 	cbnz	w0, 408c <fwp_tape_buffers_release+0x9c>
    405c:	aa1303e0 	mov	x0, x19
    4060:	a94153f3 	ldp	x19, x20, [sp, #16]
    4064:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4068:	17fffd06 	b	3480 <fwp_tape_buffers_dispose>
    406c:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    4070:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4074:	91194000 	add	x0, x0, #0x650
    4078:	97fffa6a 	bl	2a20 <getenv@plt>
    407c:	b4ffff00 	cbz	x0, 405c <fwp_tape_buffers_release+0x6c>
    4080:	39400001 	ldrb	w1, [x0]
    4084:	7100c03f 	cmp	w1, #0x30
    4088:	54fffe60 	b.eq	4054 <fwp_tape_buffers_release+0x64>  // b.none
    408c:	d1000681 	sub	x1, x20, #0x1
    4090:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4094:	eb00003f 	cmp	x1, x0
    4098:	54fffe28 	b.hi	405c <fwp_tape_buffers_release+0x6c>  // b.pmore
    409c:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a0:	900000f6 	adrp	x22, 20000 <__data_start>
    40a4:	9101c2d6 	add	x22, x22, #0x70
    40a8:	910222d5 	add	x21, x22, #0x88
    40ac:	aa1503e0 	mov	x0, x21
    40b0:	97fffcf4 	bl	3480 <fwp_tape_buffers_dispose>
    40b4:	ad400660 	ldp	q0, q1, [x19]
    40b8:	f9005ad4 	str	x20, [x22, #176]
    40bc:	ad0006a0 	stp	q0, q1, [x21]
    40c0:	f9401260 	ldr	x0, [x19, #32]
    40c4:	f90012a0 	str	x0, [x21, #32]
    40c8:	a9007e7f 	stp	xzr, xzr, [x19]
    40cc:	a9017e7f 	stp	xzr, xzr, [x19, #16]
    40d0:	f900127f 	str	xzr, [x19, #32]
    40d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    40d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40e0:	d65f03c0 	ret
    40e4:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    40e8:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    40ec:	91194000 	add	x0, x0, #0x650
    40f0:	97fffa4c 	bl	2a20 <getenv@plt>
    40f4:	b5fffaa0 	cbnz	x0, 4048 <fwp_tape_buffers_release+0x58>
    40f8:	17ffffd9 	b	405c <fwp_tape_buffers_release+0x6c>
    40fc:	d503201f 	nop

0000000000004100 <fwp_trap>:
    4100:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4104:	900000e2 	adrp	x2, 20000 <__data_start>
    4108:	d53bd041 	mrs	x1, tpidr_el0
    410c:	910003fd 	mov	x29, sp
    4110:	f9403c42 	ldr	x2, [x2, #120]
    4114:	91400021 	add	x1, x1, #0x0, lsl #12
    4118:	91004021 	add	x1, x1, #0x10
    411c:	a90153f3 	stp	x19, x20, [sp, #16]
    4120:	aa0003f3 	mov	x19, x0
    4124:	f9400034 	ldr	x20, [x1]
    4128:	b4000062 	cbz	x2, 4134 <fwp_trap+0x34>
    412c:	aa0203e0 	mov	x0, x2
    4130:	97fffa24 	bl	29c0 <fflush@plt>
    4134:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4138:	f947ec00 	ldr	x0, [x0, #4056]
    413c:	f9400000 	ldr	x0, [x0]
    4140:	97fffa20 	bl	29c0 <fflush@plt>
    4144:	aa1303e3 	mov	x3, x19
    4148:	b0000042 	adrp	x2, d000 <__divti3+0x2a0>
    414c:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc88>
    4150:	f947ea73 	ldr	x19, [x19, #4048]
    4154:	9119a042 	add	x2, x2, #0x668
    4158:	52800041 	mov	w1, #0x2                   	// #2
    415c:	f9400260 	ldr	x0, [x19]
    4160:	97fff9e8 	bl	2900 <__fprintf_chk@plt>
    4164:	b40000b4 	cbz	x20, 4178 <fwp_trap+0x78>
    4168:	f9400260 	ldr	x0, [x19]
    416c:	97fffa15 	bl	29c0 <fflush@plt>
    4170:	52800ca0 	mov	w0, #0x65                  	// #101
    4174:	97fffa23 	bl	2a00 <_Exit@plt>
    4178:	52800ca0 	mov	w0, #0x65                  	// #101
    417c:	97fff971 	bl	2740 <exit@plt>

0000000000004180 <fwp_rc_forget_slot.part.0>:
    4180:	ca404401 	eor	x1, x0, x0, lsr #17
    4184:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4188:	ca412421 	eor	x1, x1, x1, lsr #9
    418c:	910003fd 	mov	x29, sp
    4190:	92401c21 	and	x1, x1, #0xff
    4194:	f9000bf3 	str	x19, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    419c:	91170262 	add	x2, x19, #0x5c0
    41a0:	910a2423 	add	x3, x1, #0x289
    41a4:	8b010c41 	add	x1, x2, x1, lsl #3
    41a8:	8b030c43 	add	x3, x2, x3, lsl #3
    41ac:	f94a2421 	ldr	x1, [x1, #5192]
    41b0:	b50000a1 	cbnz	x1, 41c4 <fwp_rc_forget_slot.part.0+0x44>
    41b4:	14000012 	b	41fc <fwp_rc_forget_slot.part.0+0x7c>
    41b8:	91004023 	add	x3, x1, #0x10
    41bc:	f9400821 	ldr	x1, [x1, #16]
    41c0:	b40001e1 	cbz	x1, 41fc <fwp_rc_forget_slot.part.0+0x7c>
    41c4:	f9400022 	ldr	x2, [x1]
    41c8:	eb02001f 	cmp	x0, x2
    41cc:	54ffff61 	b.ne	41b8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    41d0:	f9400060 	ldr	x0, [x3]
    41d4:	91170273 	add	x19, x19, #0x5c0
    41d8:	f9400801 	ldr	x1, [x0, #16]
    41dc:	f9000061 	str	x1, [x3]
    41e0:	97fff9dc 	bl	2950 <free@plt>
    41e4:	f94e2660 	ldr	x0, [x19, #7240]
    41e8:	d1000400 	sub	x0, x0, #0x1
    41ec:	f90e2660 	str	x0, [x19, #7240]
    41f0:	f9400bf3 	ldr	x19, [sp, #16]
    41f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    41f8:	d65f03c0 	ret
    41fc:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    4200:	9119e000 	add	x0, x0, #0x678
    4204:	97ffffbf 	bl	4100 <fwp_trap>
    4208:	d503201f 	nop
    420c:	d503201f 	nop

0000000000004210 <fwp_rc_prepare_chunk>:
    4210:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4214:	910003fd 	mov	x29, sp
    4218:	a9025bf5 	stp	x21, x22, [sp, #32]
    421c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc20>
    4220:	911702c2 	add	x2, x22, #0x5c0
    4224:	b9401c03 	ldr	w3, [x0, #28]
    4228:	aa0103f5 	mov	x21, x1
    422c:	a90153f3 	stp	x19, x20, [sp, #16]
    4230:	aa0003f4 	mov	x20, x0
    4234:	f94e2440 	ldr	x0, [x2, #7240]
    4238:	b4000440 	cbz	x0, 42c0 <fwp_rc_prepare_chunk+0xb0>
    423c:	d2800013 	mov	x19, #0x0                   	// #0
    4240:	35000203 	cbnz	w3, 4280 <fwp_rc_prepare_chunk+0x70>
    4244:	b4000361 	cbz	x1, 42b0 <fwp_rc_prepare_chunk+0xa0>
    4248:	f9401280 	ldr	x0, [x20, #32]
    424c:	97fff9c1 	bl	2950 <free@plt>
    4250:	aa1503e0 	mov	x0, x21
    4254:	d2800021 	mov	x1, #0x1                   	// #1
    4258:	97fff986 	bl	2870 <calloc@plt>
    425c:	f9001280 	str	x0, [x20, #32]
    4260:	b5000460 	cbnz	x0, 42ec <fwp_rc_prepare_chunk+0xdc>
    4264:	97fffb73 	bl	3030 <fwp_heap_oom>
    4268:	97ffffc6 	bl	4180 <fwp_rc_forget_slot.part.0>
    426c:	91000673 	add	x19, x19, #0x1
    4270:	b9401e83 	ldr	w3, [x20, #28]
    4274:	eb13007f 	cmp	x3, x19
    4278:	54000169 	b.ls	42a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    427c:	d503201f 	nop
    4280:	f9401283 	ldr	x3, [x20, #32]
    4284:	8b130060 	add	x0, x3, x19
    4288:	38736863 	ldrb	w3, [x3, x19]
    428c:	7103fc7f 	cmp	w3, #0xff
    4290:	54fffec0 	b.eq	4268 <fwp_rc_prepare_chunk+0x58>  // b.none
    4294:	b9401e83 	ldr	w3, [x20, #28]
    4298:	91000673 	add	x19, x19, #0x1
    429c:	eb13007f 	cmp	x3, x19
    42a0:	54ffff08 	b.hi	4280 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    42a4:	eb0302bf 	cmp	x21, x3
    42a8:	54000121 	b.ne	42cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    42ac:	b5000335 	cbnz	x21, 4310 <fwp_rc_prepare_chunk+0x100>
    42b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    42b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42bc:	d65f03c0 	ret
    42c0:	2a0303e3 	mov	w3, w3
    42c4:	eb0302bf 	cmp	x21, x3
    42c8:	54ffff20 	b.eq	42ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    42cc:	911702c2 	add	x2, x22, #0x5c0
    42d0:	f9401280 	ldr	x0, [x20, #32]
    42d4:	f94e2841 	ldr	x1, [x2, #7248]
    42d8:	cb030021 	sub	x1, x1, x3
    42dc:	f90e2841 	str	x1, [x2, #7248]
    42e0:	97fff99c 	bl	2950 <free@plt>
    42e4:	b5fffb75 	cbnz	x21, 4250 <fwp_rc_prepare_chunk+0x40>
    42e8:	f900129f 	str	xzr, [x20, #32]
    42ec:	911702d6 	add	x22, x22, #0x5c0
    42f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    42f4:	b9001e95 	str	w21, [x20, #28]
    42f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    42fc:	8b150000 	add	x0, x0, x21
    4300:	f90e2ac0 	str	x0, [x22, #7248]
    4304:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4308:	a8c37bfd 	ldp	x29, x30, [sp], #48
    430c:	d65f03c0 	ret
    4310:	f9401280 	ldr	x0, [x20, #32]
    4314:	aa1503e2 	mov	x2, x21
    4318:	a94153f3 	ldp	x19, x20, [sp, #16]
    431c:	52800001 	mov	w1, #0x0                   	// #0
    4320:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4324:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4328:	17fff94e 	b	2860 <memset@plt>
    432c:	d503201f 	nop

0000000000004330 <fwp_heap_refill>:
    4330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4334:	910003fd 	mov	x29, sp
    4338:	a9025bf5 	stp	x21, x22, [sp, #32]
    433c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    4340:	911702b5 	add	x21, x21, #0x5c0
    4344:	aa0003f6 	mov	x22, x0
    4348:	d2800020 	mov	x0, #0x1                   	// #1
    434c:	a90153f3 	stp	x19, x20, [sp, #16]
    4350:	a90363f7 	stp	x23, x24, [sp, #48]
    4354:	2a0103f7 	mov	w23, w1
    4358:	2a0203f8 	mov	w24, w2
    435c:	97fffbd5 	bl	32b0 <fwp_heap_chunks>
    4360:	aa0003f3 	mov	x19, x0
    4364:	f949fea2 	ldr	x2, [x21, #5112]
    4368:	8b000800 	add	x0, x0, x0, lsl #2
    436c:	2a1703e1 	mov	w1, w23
    4370:	52800025 	mov	w5, #0x1                   	// #1
    4374:	d37df000 	lsl	x0, x0, #3
    4378:	910f0021 	add	x1, x1, #0x3c0
    437c:	8b000054 	add	x20, x2, x0
    4380:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4384:	52a00024 	mov	w4, #0x10000               	// #65536
    4388:	38206845 	strb	w5, [x2, x0]
    438c:	aa1403e0 	mov	x0, x20
    4390:	39000698 	strb	w24, [x20, #1]
    4394:	39000a97 	strb	w23, [x20, #2]
    4398:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    439c:	b9000681 	str	w1, [x20, #4]
    43a0:	2a0103e5 	mov	w5, w1
    43a4:	8b0300a2 	add	x2, x5, x3
    43a8:	1ac10881 	udiv	w1, w4, w1
    43ac:	9ac50842 	udiv	x2, x2, x5
    43b0:	b9000a81 	str	w1, [x20, #8]
    43b4:	92404021 	and	x1, x1, #0x1ffff
    43b8:	b9001a82 	str	w2, [x20, #24]
    43bc:	97ffff95 	bl	4210 <fwp_rc_prepare_chunk>
    43c0:	f949daa0 	ldr	x0, [x21, #5040]
    43c4:	29408a81 	ldp	w1, w2, [x20, #4]
    43c8:	8b134000 	add	x0, x0, x19, lsl #16
    43cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    43d0:	8b214003 	add	x3, x0, w1, uxtw
    43d4:	9ba20021 	umaddl	x1, w1, w2, x0
    43d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    43dc:	a90086c3 	stp	x3, x1, [x22, #8]
    43e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    43e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    43e8:	d65f03c0 	ret
    43ec:	d503201f 	nop

00000000000043f0 <fwp_mem_free>:
    43f0:	b40003c0 	cbz	x0, 4468 <fwp_mem_free+0x78>
    43f4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    43f8:	910003fd 	mov	x29, sp
    43fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4400:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    4404:	911702a1 	add	x1, x21, #0x5c0
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	f949d823 	ldr	x3, [x1, #5040]
    4414:	f949ec22 	ldr	x2, [x1, #5080]
    4418:	cb030000 	sub	x0, x0, x3
    441c:	eb02401f 	cmp	x0, x2, lsl #16
    4420:	540001c2 	b.cs	4458 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4424:	d350fc16 	lsr	x22, x0, #16
    4428:	a90363f7 	stp	x23, x24, [sp, #48]
    442c:	f949fc22 	ldr	x2, [x1, #5112]
    4430:	8b160ad4 	add	x20, x22, x22, lsl #2
    4434:	d37df294 	lsl	x20, x20, #3
    4438:	ab140057 	adds	x23, x2, x20
    443c:	540000c0 	b.eq	4454 <fwp_mem_free+0x64>  // b.none
    4440:	38746842 	ldrb	w2, [x2, x20]
    4444:	7100045f 	cmp	w2, #0x1
    4448:	54000120 	b.eq	446c <fwp_mem_free+0x7c>  // b.none
    444c:	7100085f 	cmp	w2, #0x2
    4450:	540005e0 	b.eq	450c <fwp_mem_free+0x11c>  // b.none
    4454:	a94363f7 	ldp	x23, x24, [sp, #48]
    4458:	a94153f3 	ldp	x19, x20, [sp, #16]
    445c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4460:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4464:	d65f03c0 	ret
    4468:	d65f03c0 	ret
    446c:	f94012f8 	ldr	x24, [x23, #32]
    4470:	b94006e1 	ldr	w1, [x23, #4]
    4474:	f90023f9 	str	x25, [sp, #64]
    4478:	2a0103e2 	mov	w2, w1
    447c:	394006f9 	ldrb	w25, [x23, #1]
    4480:	39400af4 	ldrb	w20, [x23, #2]
    4484:	b4000158 	cbz	x24, 44ac <fwp_mem_free+0xbc>
    4488:	92403e76 	and	x22, x19, #0xffff
    448c:	9ac20ad6 	udiv	x22, x22, x2
    4490:	38766b01 	ldrb	w1, [x24, x22]
    4494:	8b160300 	add	x0, x24, x22
    4498:	7103fc3f 	cmp	w1, #0xff
    449c:	54000980 	b.eq	45cc <fwp_mem_free+0x1dc>  // b.none
    44a0:	38366b1f 	strb	wzr, [x24, x22]
    44a4:	b94006e1 	ldr	w1, [x23, #4]
    44a8:	2a0103e2 	mov	w2, w1
    44ac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    44b0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    44b4:	cb390000 	sub	x0, x0, w25, uxtb
    44b8:	8b340074 	add	x20, x3, w20, uxtb
    44bc:	911702b5 	add	x21, x21, #0x5c0
    44c0:	1e630021 	ucvtf	d1, w1
    44c4:	d37ae400 	lsl	x0, x0, #6
    44c8:	8b140c14 	add	x20, x0, x20, lsl #3
    44cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44d0:	f8746aa0 	ldr	x0, [x21, x20]
    44d4:	f94023f9 	ldr	x25, [sp, #64]
    44d8:	aa2003e0 	mvn	x0, x0
    44dc:	fd4a22a0 	ldr	d0, [x21, #5184]
    44e0:	f9000260 	str	x0, [x19]
    44e4:	f8346ab3 	str	x19, [x21, x20]
    44e8:	f94a12a0 	ldr	x0, [x21, #5152]
    44ec:	1e612800 	fadd	d0, d0, d1
    44f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44f4:	cb020000 	sub	x0, x0, x2
    44f8:	f90a12a0 	str	x0, [x21, #5152]
    44fc:	fd0a22a0 	str	d0, [x21, #5184]
    4500:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4504:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4508:	d65f03c0 	ret
    450c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4510:	8b000063 	add	x3, x3, x0
    4514:	eb03027f 	cmp	x19, x3
    4518:	54fff9e1 	b.ne	4454 <fwp_mem_free+0x64>  // b.any
    451c:	fd400ae1 	ldr	d1, [x23, #16]
    4520:	fd4a2020 	ldr	d0, [x1, #5184]
    4524:	f9400ae0 	ldr	x0, [x23, #16]
    4528:	7e61d821 	ucvtf	d1, d1
    452c:	f94a1022 	ldr	x2, [x1, #5152]
    4530:	f94012f3 	ldr	x19, [x23, #32]
    4534:	1e612800 	fadd	d0, d0, d1
    4538:	cb000042 	sub	x2, x2, x0
    453c:	f90a1022 	str	x2, [x1, #5152]
    4540:	fd0a2020 	str	d0, [x1, #5184]
    4544:	b40000b3 	cbz	x19, 4558 <fwp_mem_free+0x168>
    4548:	39400260 	ldrb	w0, [x19]
    454c:	7103fc1f 	cmp	w0, #0xff
    4550:	54000380 	b.eq	45c0 <fwp_mem_free+0x1d0>  // b.none
    4554:	3900027f 	strb	wzr, [x19]
    4558:	b9400ee2 	ldr	w2, [x23, #12]
    455c:	b4000142 	cbz	x2, 4584 <fwp_mem_free+0x194>
    4560:	911702a1 	add	x1, x21, #0x5c0
    4564:	8b160040 	add	x0, x2, x22
    4568:	8b000800 	add	x0, x0, x0, lsl #2
    456c:	f949fc21 	ldr	x1, [x1, #5112]
    4570:	8b140034 	add	x20, x1, x20
    4574:	8b000c20 	add	x0, x1, x0, lsl #3
    4578:	3802869f 	strb	wzr, [x20], #40
    457c:	eb00029f 	cmp	x20, x0
    4580:	54ffffc1 	b.ne	4578 <fwp_mem_free+0x188>  // b.any
    4584:	911702a0 	add	x0, x21, #0x5c0
    4588:	f94a1801 	ldr	x1, [x0, #5168]
    458c:	f949f803 	ldr	x3, [x0, #5104]
    4590:	8b020021 	add	x1, x1, x2
    4594:	f90a1801 	str	x1, [x0, #5168]
    4598:	eb16007f 	cmp	x3, x22
    459c:	54000049 	b.ls	45a4 <fwp_mem_free+0x1b4>  // b.plast
    45a0:	f909f816 	str	x22, [x0, #5104]
    45a4:	911702b5 	add	x21, x21, #0x5c0
    45a8:	f949f6a0 	ldr	x0, [x21, #5096]
    45ac:	eb16001f 	cmp	x0, x22
    45b0:	54fff529 	b.ls	4454 <fwp_mem_free+0x64>  // b.plast
    45b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    45b8:	f909f6b6 	str	x22, [x21, #5096]
    45bc:	17ffffa7 	b	4458 <fwp_mem_free+0x68>
    45c0:	aa1303e0 	mov	x0, x19
    45c4:	97fffeef 	bl	4180 <fwp_rc_forget_slot.part.0>
    45c8:	17ffffe3 	b	4554 <fwp_mem_free+0x164>
    45cc:	97fffeed 	bl	4180 <fwp_rc_forget_slot.part.0>
    45d0:	17ffffb4 	b	44a0 <fwp_mem_free+0xb0>

00000000000045d4 <fwp_rc_wide_dup>:
    45d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    45d8:	910003fd 	mov	x29, sp
    45dc:	a90153f3 	stp	x19, x20, [sp, #16]
    45e0:	aa0003f3 	mov	x19, x0
    45e4:	ca404400 	eor	x0, x0, x0, lsr #17
    45e8:	f90013f5 	str	x21, [sp, #32]
    45ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    45f0:	ca402400 	eor	x0, x0, x0, lsr #9
    45f4:	911702a2 	add	x2, x21, #0x5c0
    45f8:	92401c00 	and	x0, x0, #0xff
    45fc:	910a2403 	add	x3, x0, #0x289
    4600:	8b000c40 	add	x0, x2, x0, lsl #3
    4604:	8b030c54 	add	x20, x2, x3, lsl #3
    4608:	f94a2401 	ldr	x1, [x0, #5192]
    460c:	b50000a1 	cbnz	x1, 4620 <fwp_rc_wide_dup+0x4c>
    4610:	14000033 	b	46dc <fwp_rc_wide_dup+0x108>
    4614:	91004034 	add	x20, x1, #0x10
    4618:	f9400821 	ldr	x1, [x1, #16]
    461c:	b4000241 	cbz	x1, 4664 <fwp_rc_wide_dup+0x90>
    4620:	f9400022 	ldr	x2, [x1]
    4624:	eb02027f 	cmp	x19, x2
    4628:	54ffff61 	b.ne	4614 <fwp_rc_wide_dup+0x40>  // b.any
    462c:	f9400281 	ldr	x1, [x20]
    4630:	39400260 	ldrb	w0, [x19]
    4634:	7103f81f 	cmp	w0, #0xfe
    4638:	54000220 	b.eq	467c <fwp_rc_wide_dup+0xa8>  // b.none
    463c:	b40001a1 	cbz	x1, 4670 <fwp_rc_wide_dup+0x9c>
    4640:	f9400420 	ldr	x0, [x1, #8]
    4644:	b100041f 	cmn	x0, #0x1
    4648:	54000440 	b.eq	46d0 <fwp_rc_wide_dup+0xfc>  // b.none
    464c:	91000400 	add	x0, x0, #0x1
    4650:	f9000420 	str	x0, [x1, #8]
    4654:	a94153f3 	ldp	x19, x20, [sp, #16]
    4658:	f94013f5 	ldr	x21, [sp, #32]
    465c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4660:	d65f03c0 	ret
    4664:	39400260 	ldrb	w0, [x19]
    4668:	7103f81f 	cmp	w0, #0xfe
    466c:	54000100 	b.eq	468c <fwp_rc_wide_dup+0xb8>  // b.none
    4670:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    4674:	9119e000 	add	x0, x0, #0x678
    4678:	97fffea2 	bl	4100 <fwp_trap>
    467c:	b4000081 	cbz	x1, 468c <fwp_rc_wide_dup+0xb8>
    4680:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    4684:	911a8000 	add	x0, x0, #0x6a0
    4688:	97fffe9e 	bl	4100 <fwp_trap>
    468c:	d2800300 	mov	x0, #0x18                  	// #24
    4690:	97fff868 	bl	2830 <malloc@plt>
    4694:	b4000280 	cbz	x0, 46e4 <fwp_rc_wide_dup+0x110>
    4698:	d2801fe1 	mov	x1, #0xff                  	// #255
    469c:	a9000413 	stp	x19, x1, [x0]
    46a0:	911702b5 	add	x21, x21, #0x5c0
    46a4:	f900081f 	str	xzr, [x0, #16]
    46a8:	12800001 	mov	w1, #0xffffffff            	// #-1
    46ac:	f9000280 	str	x0, [x20]
    46b0:	39000261 	strb	w1, [x19]
    46b4:	f94e26a0 	ldr	x0, [x21, #7240]
    46b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46bc:	91000400 	add	x0, x0, #0x1
    46c0:	f90e26a0 	str	x0, [x21, #7240]
    46c4:	f94013f5 	ldr	x21, [sp, #32]
    46c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46cc:	d65f03c0 	ret
    46d0:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    46d4:	911b2000 	add	x0, x0, #0x6c8
    46d8:	97fffe8a 	bl	4100 <fwp_trap>
    46dc:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    46e0:	17ffffd4 	b	4630 <fwp_rc_wide_dup+0x5c>
    46e4:	97fffa53 	bl	3030 <fwp_heap_oom>
    46e8:	d503201f 	nop
    46ec:	d503201f 	nop

00000000000046f0 <fwp_closure_drop_push>:
    46f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    46f4:	910003fd 	mov	x29, sp
    46f8:	a90153f3 	stp	x19, x20, [sp, #16]
    46fc:	aa0003f3 	mov	x19, x0
    4700:	a9408014 	ldp	x20, x0, [x0, #8]
    4704:	a9025bf5 	stp	x21, x22, [sp, #32]
    4708:	aa0103f5 	mov	x21, x1
    470c:	a90363f7 	stp	x23, x24, [sp, #48]
    4710:	eb00029f 	cmp	x20, x0
    4714:	54000160 	b.eq	4740 <fwp_closure_drop_push+0x50>  // b.none
    4718:	f9400276 	ldr	x22, [x19]
    471c:	d37df297 	lsl	x23, x20, #3
    4720:	91000694 	add	x20, x20, #0x1
    4724:	f9000674 	str	x20, [x19, #8]
    4728:	a94153f3 	ldp	x19, x20, [sp, #16]
    472c:	f8376ad5 	str	x21, [x22, x23]
    4730:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4734:	a94363f7 	ldp	x23, x24, [sp, #48]
    4738:	a8c57bfd 	ldp	x29, x30, [sp], #80
    473c:	d65f03c0 	ret
    4740:	a9046bf9 	stp	x25, x26, [sp, #64]
    4744:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4748:	eb00029f 	cmp	x20, x0
    474c:	540003e8 	b.hi	47c8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4750:	d37cee99 	lsl	x25, x20, #4
    4754:	d37ffa9a 	lsl	x26, x20, #1
    4758:	aa1903e0 	mov	x0, x25
    475c:	97fff835 	bl	2830 <malloc@plt>
    4760:	aa0003f6 	mov	x22, x0
    4764:	b4000380 	cbz	x0, 47d4 <fwp_closure_drop_push+0xe4>
    4768:	aa1303f8 	mov	x24, x19
    476c:	aa1903e3 	mov	x3, x25
    4770:	d37df297 	lsl	x23, x20, #3
    4774:	aa1703e2 	mov	x2, x23
    4778:	f8418719 	ldr	x25, [x24], #24
    477c:	aa1903e1 	mov	x1, x25
    4780:	97fff818 	bl	27e0 <__memcpy_chk@plt>
    4784:	eb18033f 	cmp	x25, x24
    4788:	540000a0 	b.eq	479c <fwp_closure_drop_push+0xac>  // b.none
    478c:	aa1903e0 	mov	x0, x25
    4790:	97fff870 	bl	2950 <free@plt>
    4794:	f9400674 	ldr	x20, [x19, #8]
    4798:	d37df297 	lsl	x23, x20, #3
    479c:	91000694 	add	x20, x20, #0x1
    47a0:	f9000276 	str	x22, [x19]
    47a4:	f9000a7a 	str	x26, [x19, #16]
    47a8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    47ac:	f9000674 	str	x20, [x19, #8]
    47b0:	f8376ad5 	str	x21, [x22, x23]
    47b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    47c0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47c4:	d65f03c0 	ret
    47c8:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    47cc:	911ba000 	add	x0, x0, #0x6e8
    47d0:	97fffe4c 	bl	4100 <fwp_trap>
    47d4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    47d8:	f947e863 	ldr	x3, [x3, #4048]
    47dc:	d2800262 	mov	x2, #0x13                  	// #19
    47e0:	d2800021 	mov	x1, #0x1                   	// #1
    47e4:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    47e8:	91122000 	add	x0, x0, #0x488
    47ec:	f9400063 	ldr	x3, [x3]
    47f0:	97fff868 	bl	2990 <fwrite@plt>
    47f4:	d2800000 	mov	x0, #0x0                   	// #0
    47f8:	97fff872 	bl	29c0 <fflush@plt>
    47fc:	52800cc0 	mov	w0, #0x66                  	// #102
    4800:	97fff880 	bl	2a00 <_Exit@plt>

0000000000004804 <fwp_closure_drop.part.0>:
    4804:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4808:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0xb80>
    480c:	910003fd 	mov	x29, sp
    4810:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    4814:	f947f463 	ldr	x3, [x3, #4072]
    4818:	a90153f3 	stp	x19, x20, [sp, #16]
    481c:	d10883ff 	sub	sp, sp, #0x220
    4820:	910003e2 	mov	x2, sp
    4824:	d53bd053 	mrs	x19, tpidr_el0
    4828:	910063f4 	add	x20, sp, #0x18
    482c:	3dc09c20 	ldr	q0, [x1, #624]
    4830:	91400264 	add	x4, x19, #0x0, lsl #12
    4834:	91004084 	add	x4, x4, #0x10
    4838:	aa0003e1 	mov	x1, x0
    483c:	aa0203e0 	mov	x0, x2
    4840:	f9400062 	ldr	x2, [x3]
    4844:	f9010fe2 	str	x2, [sp, #536]
    4848:	d2800002 	mov	x2, #0x0                   	// #0
    484c:	f90003f4 	str	x20, [sp]
    4850:	f9000080 	str	x0, [x4]
    4854:	3c8083e0 	stur	q0, [sp, #8]
    4858:	97ffffa6 	bl	46f0 <fwp_closure_drop_push>
    485c:	f94007e0 	ldr	x0, [sp, #8]
    4860:	b40002e0 	cbz	x0, 48bc <fwp_closure_drop.part.0+0xb8>
    4864:	f90123f5 	str	x21, [sp, #576]
    4868:	900000f5 	adrp	x21, 20000 <__data_start>
    486c:	9101c2b5 	add	x21, x21, #0x70
    4870:	14000006 	b	4888 <fwp_closure_drop.part.0+0x84>
    4874:	f9400422 	ldr	x2, [x1, #8]
    4878:	52800001 	mov	w1, #0x0                   	// #0
    487c:	d63f0040 	blr	x2
    4880:	f94007e0 	ldr	x0, [sp, #8]
    4884:	b40001a0 	cbz	x0, 48b8 <fwp_closure_drop.part.0+0xb4>
    4888:	f94003e1 	ldr	x1, [sp]
    488c:	d1000400 	sub	x0, x0, #0x1
    4890:	f90007e0 	str	x0, [sp, #8]
    4894:	f9405ea2 	ldr	x2, [x21, #184]
    4898:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    489c:	b9400001 	ldr	w1, [x0]
    48a0:	8b011441 	add	x1, x2, x1, lsl #5
    48a4:	f9400c21 	ldr	x1, [x1, #24]
    48a8:	b5fffe61 	cbnz	x1, 4874 <fwp_closure_drop.part.0+0x70>
    48ac:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    48b0:	911c2000 	add	x0, x0, #0x708
    48b4:	97fffe13 	bl	4100 <fwp_trap>
    48b8:	f94123f5 	ldr	x21, [sp, #576]
    48bc:	91400273 	add	x19, x19, #0x0, lsl #12
    48c0:	91004273 	add	x19, x19, #0x10
    48c4:	f94003e0 	ldr	x0, [sp]
    48c8:	f900027f 	str	xzr, [x19]
    48cc:	eb14001f 	cmp	x0, x20
    48d0:	54000040 	b.eq	48d8 <fwp_closure_drop.part.0+0xd4>  // b.none
    48d4:	97fff81f 	bl	2950 <free@plt>
    48d8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    48dc:	f947f400 	ldr	x0, [x0, #4072]
    48e0:	f9410fe2 	ldr	x2, [sp, #536]
    48e4:	f9400001 	ldr	x1, [x0]
    48e8:	eb010042 	subs	x2, x2, x1
    48ec:	d2800001 	mov	x1, #0x0                   	// #0
    48f0:	540000a1 	b.ne	4904 <fwp_closure_drop.part.0+0x100>  // b.any
    48f4:	910883ff 	add	sp, sp, #0x220
    48f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4900:	d65f03c0 	ret
    4904:	f90123f5 	str	x21, [sp, #576]
    4908:	97fff7e2 	bl	2890 <__stack_chk_fail@plt>
    490c:	d503201f 	nop

0000000000004910 <fwp_tape_of>:
    4910:	aa0003e1 	mov	x1, x0
    4914:	92403c00 	and	x0, x0, #0xffff
    4918:	b40000e0 	cbz	x0, 4934 <fwp_tape_of+0x24>
    491c:	d1000403 	sub	x3, x0, #0x1
    4920:	900000e0 	adrp	x0, 20000 <__data_start>
    4924:	9101c002 	add	x2, x0, #0x70
    4928:	f9406042 	ldr	x2, [x2, #192]
    492c:	eb03005f 	cmp	x2, x3
    4930:	540000cc 	b.gt	4948 <fwp_tape_of+0x38>
    4934:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4938:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    493c:	911ce000 	add	x0, x0, #0x738
    4940:	910003fd 	mov	x29, sp
    4944:	97fffdef 	bl	4100 <fwp_trap>
    4948:	8b030462 	add	x2, x3, x3, lsl #1
    494c:	f9403804 	ldr	x4, [x0, #112]
    4950:	d37ef442 	lsl	x2, x2, #2
    4954:	cb030042 	sub	x2, x2, x3
    4958:	d37df042 	lsl	x2, x2, #3
    495c:	8b020080 	add	x0, x4, x2
    4960:	b9400403 	ldr	w3, [x0, #4]
    4964:	34fffe83 	cbz	w3, 4934 <fwp_tape_of+0x24>
    4968:	b8626882 	ldr	w2, [x4, x2]
    496c:	9350fc21 	asr	x1, x1, #16
    4970:	6b01005f 	cmp	w2, w1
    4974:	54fffe01 	b.ne	4934 <fwp_tape_of+0x24>  // b.any
    4978:	d65f03c0 	ret
    497c:	d503201f 	nop

0000000000004980 <fwp_now_ns>:
    4980:	d100c3ff 	sub	sp, sp, #0x30
    4984:	52800020 	mov	w0, #0x1                   	// #1
    4988:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    498c:	f947f442 	ldr	x2, [x2, #4072]
    4990:	910023e1 	add	x1, sp, #0x8
    4994:	a9027bfd 	stp	x29, x30, [sp, #32]
    4998:	910083fd 	add	x29, sp, #0x20
    499c:	f9400043 	ldr	x3, [x2]
    49a0:	f9000fe3 	str	x3, [sp, #24]
    49a4:	d2800003 	mov	x3, #0x0                   	// #0
    49a8:	97fff786 	bl	27c0 <clock_gettime@plt>
    49ac:	350002c0 	cbnz	w0, 4a04 <fwp_now_ns+0x84>
    49b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    49b4:	d2994003 	mov	x3, #0xca00                	// #51712
    49b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    49bc:	9b037c20 	mul	x0, x1, x3
    49c0:	9b437c21 	smulh	x1, x1, x3
    49c4:	ab020000 	adds	x0, x0, x2
    49c8:	937ffc42 	asr	x2, x2, #63
    49cc:	9a020021 	adc	x1, x1, x2
    49d0:	f100001f 	cmp	x0, #0x0
    49d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    49d8:	b50001c1 	cbnz	x1, 4a10 <fwp_now_ns+0x90>
    49dc:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    49e0:	f947f421 	ldr	x1, [x1, #4072]
    49e4:	f9400fe3 	ldr	x3, [sp, #24]
    49e8:	f9400022 	ldr	x2, [x1]
    49ec:	eb020063 	subs	x3, x3, x2
    49f0:	d2800002 	mov	x2, #0x0                   	// #0
    49f4:	54000141 	b.ne	4a1c <fwp_now_ns+0x9c>  // b.any
    49f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    49fc:	9100c3ff 	add	sp, sp, #0x30
    4a00:	d65f03c0 	ret
    4a04:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    4a08:	911e2000 	add	x0, x0, #0x788
    4a0c:	97fffdbd 	bl	4100 <fwp_trap>
    4a10:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    4a14:	911ea000 	add	x0, x0, #0x7a8
    4a18:	97fffdba 	bl	4100 <fwp_trap>
    4a1c:	97fff79d 	bl	2890 <__stack_chk_fail@plt>

0000000000004a20 <fwp_poll_events>:
    4a20:	d10103ff 	sub	sp, sp, #0x40
    4a24:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4a28:	f947f400 	ldr	x0, [x0, #4072]
    4a2c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4a30:	910083fd 	add	x29, sp, #0x20
    4a34:	f9001bf3 	str	x19, [sp, #48]
    4a38:	900000f3 	adrp	x19, 20000 <__data_start>
    4a3c:	f9400001 	ldr	x1, [x0]
    4a40:	f9000fe1 	str	x1, [sp, #24]
    4a44:	d2800001 	mov	x1, #0x0                   	// #0
    4a48:	97ffffce 	bl	4980 <fwp_now_ns>
    4a4c:	9101c261 	add	x1, x19, #0x70
    4a50:	f9406421 	ldr	x1, [x1, #200]
    4a54:	b4000e01 	cbz	x1, 4c14 <fwp_poll_events+0x1f4>
    4a58:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4a5c:	14000005 	b	4a70 <fwp_poll_events+0x50>
    4a60:	f9408821 	ldr	x1, [x1, #272]
    4a64:	eb03005f 	cmp	x2, x3
    4a68:	9a83d042 	csel	x2, x2, x3, le
    4a6c:	b40000c1 	cbz	x1, 4a84 <fwp_poll_events+0x64>
    4a70:	f9403423 	ldr	x3, [x1, #104]
    4a74:	b6ffff62 	tbz	x2, #63, 4a60 <fwp_poll_events+0x40>
    4a78:	f9408821 	ldr	x1, [x1, #272]
    4a7c:	aa0303e2 	mov	x2, x3
    4a80:	b5ffff81 	cbnz	x1, 4a70 <fwp_poll_events+0x50>
    4a84:	b7f80c82 	tbnz	x2, #63, 4c14 <fwp_poll_events+0x1f4>
    4a88:	cb000042 	sub	x2, x2, x0
    4a8c:	f100005f 	cmp	x2, #0x0
    4a90:	540003ad 	b.le	4b04 <fwp_poll_events+0xe4>
    4a94:	d2869b60 	mov	x0, #0x34db                	// #13531
    4a98:	d2884804 	mov	x4, #0x4240                	// #16960
    4a9c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4aa0:	f2a001e4 	movk	x4, #0xf, lsl #16
    4aa4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4aa8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4aac:	f2e86360 	movk	x0, #0x431b, lsl #48
    4ab0:	9b407c40 	smulh	x0, x2, x0
    4ab4:	9352fc00 	asr	x0, x0, #18
    4ab8:	cb82fc00 	sub	x0, x0, x2, asr #63
    4abc:	9b048802 	msub	x2, x0, x4, x2
    4ac0:	f100005f 	cmp	x2, #0x0
    4ac4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4ac8:	eb01001f 	cmp	x0, x1
    4acc:	5400098c 	b.gt	4bfc <fwp_poll_events+0x1dc>
    4ad0:	340001a0 	cbz	w0, 4b04 <fwp_poll_events+0xe4>
    4ad4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4ad8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4adc:	72a20c41 	movk	w1, #0x1062, lsl #16
    4ae0:	9ba17c01 	umull	x1, w0, w1
    4ae4:	d366fc23 	lsr	x3, x1, #38
    4ae8:	aa0303e2 	mov	x2, x3
    4aec:	1b058063 	msub	w3, w3, w5, w0
    4af0:	9b247c63 	smull	x3, w3, w4
    4af4:	910023e0 	add	x0, sp, #0x8
    4af8:	d2800001 	mov	x1, #0x0                   	// #0
    4afc:	a9008fe2 	stp	x2, x3, [sp, #8]
    4b00:	97fff798 	bl	2960 <nanosleep@plt>
    4b04:	97ffff9f 	bl	4980 <fwp_now_ns>
    4b08:	9101c268 	add	x8, x19, #0x70
    4b0c:	aa0003e7 	mov	x7, x0
    4b10:	4f000400 	movi	v0.4s, #0x0
    4b14:	52800029 	mov	w9, #0x1                   	// #1
    4b18:	f9406506 	ldr	x6, [x8, #200]
    4b1c:	d503201f 	nop
    4b20:	b40003e6 	cbz	x6, 4b9c <fwp_poll_events+0x17c>
    4b24:	f94034c1 	ldr	x1, [x6, #104]
    4b28:	aa0603e5 	mov	x5, x6
    4b2c:	f94088c6 	ldr	x6, [x6, #272]
    4b30:	eb07003f 	cmp	x1, x7
    4b34:	54ffff6c 	b.gt	4b20 <fwp_poll_events+0x100>
    4b38:	394154a0 	ldrb	w0, [x5, #85]
    4b3c:	36000120 	tbz	w0, #0, 4b60 <fwp_poll_events+0x140>
    4b40:	f94084a0 	ldr	x0, [x5, #264]
    4b44:	b4000560 	cbz	x0, 4bf0 <fwp_poll_events+0x1d0>
    4b48:	f9008806 	str	x6, [x0, #272]
    4b4c:	b4000046 	cbz	x6, 4b54 <fwp_poll_events+0x134>
    4b50:	f90084c0 	str	x0, [x6, #264]
    4b54:	910800a0 	add	x0, x5, #0x200
    4b58:	390154bf 	strb	wzr, [x5, #85]
    4b5c:	3c908000 	stur	q0, [x0, #-248]
    4b60:	f94030a0 	ldr	x0, [x5, #96]
    4b64:	390158a9 	strb	w9, [x5, #86]
    4b68:	f100001f 	cmp	x0, #0x0
    4b6c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4b70:	540002cd 	b.le	4bc8 <fwp_poll_events+0x1a8>
    4b74:	f94028a0 	ldr	x0, [x5, #80]
    4b78:	f2001c1f 	tst	x0, #0xff000000ff
    4b7c:	54fffd21 	b.ne	4b20 <fwp_poll_events+0x100>  // b.any
    4b80:	f9403d00 	ldr	x0, [x8, #120]
    4b84:	390150a9 	strb	w9, [x5, #84]
    4b88:	f90080bf 	str	xzr, [x5, #256]
    4b8c:	b40002c0 	cbz	x0, 4be4 <fwp_poll_events+0x1c4>
    4b90:	f9003d05 	str	x5, [x8, #120]
    4b94:	f9008005 	str	x5, [x0, #256]
    4b98:	b5fffc66 	cbnz	x6, 4b24 <fwp_poll_events+0x104>
    4b9c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4ba0:	f947f400 	ldr	x0, [x0, #4072]
    4ba4:	f9400fe2 	ldr	x2, [sp, #24]
    4ba8:	f9400001 	ldr	x1, [x0]
    4bac:	eb010042 	subs	x2, x2, x1
    4bb0:	d2800001 	mov	x1, #0x0                   	// #0
    4bb4:	540002e1 	b.ne	4c10 <fwp_poll_events+0x1f0>  // b.any
    4bb8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bbc:	f9401bf3 	ldr	x19, [sp, #48]
    4bc0:	910103ff 	add	sp, sp, #0x40
    4bc4:	d65f03c0 	ret
    4bc8:	394144a0 	ldrb	w0, [x5, #81]
    4bcc:	3707fd40 	tbnz	w0, #0, 4b74 <fwp_poll_events+0x154>
    4bd0:	394140a0 	ldrb	w0, [x5, #80]
    4bd4:	3707fd00 	tbnz	w0, #0, 4b74 <fwp_poll_events+0x154>
    4bd8:	aa0503e0 	mov	x0, x5
    4bdc:	97fffac5 	bl	36f0 <fwp_cancel_tree.part.0>
    4be0:	17ffffe5 	b	4b74 <fwp_poll_events+0x154>
    4be4:	f9003d05 	str	x5, [x8, #120]
    4be8:	f9004105 	str	x5, [x8, #128]
    4bec:	17ffffeb 	b	4b98 <fwp_poll_events+0x178>
    4bf0:	9101c261 	add	x1, x19, #0x70
    4bf4:	f9006426 	str	x6, [x1, #200]
    4bf8:	17ffffd5 	b	4b4c <fwp_poll_events+0x12c>
    4bfc:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4c00:	d2989362 	mov	x2, #0xc49b                	// #50331
    4c04:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4c08:	f2a00402 	movk	x2, #0x20, lsl #16
    4c0c:	17ffffba 	b	4af4 <fwp_poll_events+0xd4>
    4c10:	97fff720 	bl	2890 <__stack_chk_fail@plt>
    4c14:	97fff8f7 	bl	2ff0 <fwp_flush>
    4c18:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    4c1c:	f947e863 	ldr	x3, [x3, #4048]
    4c20:	d2800562 	mov	x2, #0x2b                  	// #43
    4c24:	d2800021 	mov	x1, #0x1                   	// #1
    4c28:	b0000040 	adrp	x0, d000 <__divti3+0x2a0>
    4c2c:	911f4000 	add	x0, x0, #0x7d0
    4c30:	f9400063 	ldr	x3, [x3]
    4c34:	97fff757 	bl	2990 <fwrite@plt>
    4c38:	52800ca0 	mov	w0, #0x65                  	// #101
    4c3c:	97fff6c1 	bl	2740 <exit@plt>

0000000000004c40 <fwp_heap_alloc_big>:
    4c40:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c44:	910003fd 	mov	x29, sp
    4c48:	a90153f3 	stp	x19, x20, [sp, #16]
    4c4c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c50:	a90363f7 	stp	x23, x24, [sp, #48]
    4c54:	aa0003f7 	mov	x23, x0
    4c58:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c5c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c60:	eb0002ff 	cmp	x23, x0
    4c64:	540008a8 	b.hi	4d78 <fwp_heap_alloc_big+0x138>  // b.pmore
    4c68:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c6c:	8b0002f4 	add	x20, x23, x0
    4c70:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc20>
    4c74:	91170359 	add	x25, x26, #0x5c0
    4c78:	d350fe94 	lsr	x20, x20, #16
    4c7c:	2a0103f5 	mov	w21, w1
    4c80:	aa1403e0 	mov	x0, x20
    4c84:	97fff98b 	bl	32b0 <fwp_heap_chunks>
    4c88:	f949ff22 	ldr	x2, [x25, #5112]
    4c8c:	8b000813 	add	x19, x0, x0, lsl #2
    4c90:	aa0003f8 	mov	x24, x0
    4c94:	52800043 	mov	w3, #0x2                   	// #2
    4c98:	d37df273 	lsl	x19, x19, #3
    4c9c:	d2800021 	mov	x1, #0x1                   	// #1
    4ca0:	8b130040 	add	x0, x2, x19
    4ca4:	38336843 	strb	w3, [x2, x19]
    4ca8:	39000415 	strb	w21, [x0, #1]
    4cac:	b9000c14 	str	w20, [x0, #12]
    4cb0:	f9000817 	str	x23, [x0, #16]
    4cb4:	97fffd57 	bl	4210 <fwp_rc_prepare_chunk>
    4cb8:	f100069f 	cmp	x20, #0x1
    4cbc:	54000289 	b.ls	4d0c <fwp_heap_alloc_big+0xcc>  // b.plast
    4cc0:	8b180294 	add	x20, x20, x24
    4cc4:	9100a273 	add	x19, x19, #0x28
    4cc8:	a90573fb 	stp	x27, x28, [sp, #80]
    4ccc:	5280007b 	mov	w27, #0x3                   	// #3
    4cd0:	8b140a94 	add	x20, x20, x20, lsl #2
    4cd4:	2a1803fc 	mov	w28, w24
    4cd8:	9adb2296 	lsl	x22, x20, x27
    4cdc:	d503201f 	nop
    4ce0:	f949ff35 	ldr	x21, [x25, #5112]
    4ce4:	d2800001 	mov	x1, #0x0                   	// #0
    4ce8:	8b1302b4 	add	x20, x21, x19
    4cec:	aa1403e0 	mov	x0, x20
    4cf0:	97fffd48 	bl	4210 <fwp_rc_prepare_chunk>
    4cf4:	38336abb 	strb	w27, [x21, x19]
    4cf8:	9100a273 	add	x19, x19, #0x28
    4cfc:	b9000e9c 	str	w28, [x20, #12]
    4d00:	eb1302df 	cmp	x22, x19
    4d04:	54fffee1 	b.ne	4ce0 <fwp_heap_alloc_big+0xa0>  // b.any
    4d08:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d0c:	91170353 	add	x19, x26, #0x5c0
    4d10:	aa1703e2 	mov	x2, x23
    4d14:	52800001 	mov	w1, #0x0                   	// #0
    4d18:	f949da60 	ldr	x0, [x19, #5040]
    4d1c:	8b184018 	add	x24, x0, x24, lsl #16
    4d20:	aa1803e0 	mov	x0, x24
    4d24:	97fff6cf 	bl	2860 <memset@plt>
    4d28:	f94a1260 	ldr	x0, [x19, #5152]
    4d2c:	ab170000 	adds	x0, x0, x23
    4d30:	54000242 	b.cs	4d78 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4d34:	f94a1661 	ldr	x1, [x19, #5160]
    4d38:	f90a1260 	str	x0, [x19, #5152]
    4d3c:	eb01001f 	cmp	x0, x1
    4d40:	54000049 	b.ls	4d48 <fwp_heap_alloc_big+0x108>  // b.plast
    4d44:	f90a1660 	str	x0, [x19, #5160]
    4d48:	9117035a 	add	x26, x26, #0x5c0
    4d4c:	9e6202e0 	scvtf	d0, x23
    4d50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d54:	aa1803e0 	mov	x0, x24
    4d58:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d60:	1e602820 	fadd	d0, d1, d0
    4d64:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d68:	fd0a1f40 	str	d0, [x26, #5176]
    4d6c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d70:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d74:	d65f03c0 	ret
    4d78:	a90573fb 	stp	x27, x28, [sp, #80]
    4d7c:	97fff8ad 	bl	3030 <fwp_heap_oom>

0000000000004d80 <fwp_heap_alloc_slow>:
    4d80:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d84:	910003fd 	mov	x29, sp
    4d88:	a90153f3 	stp	x19, x20, [sp, #16]
    4d8c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    4d90:	91170262 	add	x2, x19, #0x5c0
    4d94:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d98:	aa0003f5 	mov	x21, x0
    4d9c:	2a0103f4 	mov	w20, w1
    4da0:	b953a440 	ldr	w0, [x2, #5028]
    4da4:	34000600 	cbz	w0, 4e64 <fwp_heap_alloc_slow+0xe4>
    4da8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dac:	54000628 	b.hi	4e70 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4db0:	91003ea0 	add	x0, x21, #0xf
    4db4:	91170262 	add	x2, x19, #0x5c0
    4db8:	f9001bf7 	str	x23, [sp, #48]
    4dbc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dc0:	8b401040 	add	x0, x2, x0, lsr #4
    4dc4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dc8:	d37ae484 	lsl	x4, x4, #6
    4dcc:	397e8003 	ldrb	w3, [x0, #4000]
    4dd0:	910f0060 	add	x0, x3, #0x3c0
    4dd4:	aa0303e1 	mov	x1, x3
    4dd8:	8b030463 	add	x3, x3, x3, lsl #1
    4ddc:	8b030c83 	add	x3, x4, x3, lsl #3
    4de0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4de4:	2a1703f6 	mov	w22, w23
    4de8:	f8636844 	ldr	x4, [x2, x3]
    4dec:	b40004e4 	cbz	x4, 4e88 <fwp_heap_alloc_slow+0x108>
    4df0:	f9400080 	ldr	x0, [x4]
    4df4:	aa2003e0 	mvn	x0, x0
    4df8:	f8236840 	str	x0, [x2, x3]
    4dfc:	7100069f 	cmp	w20, #0x1
    4e00:	aa0403e0 	mov	x0, x4
    4e04:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e08:	52800001 	mov	w1, #0x0                   	// #0
    4e0c:	97fff695 	bl	2860 <memset@plt>
    4e10:	aa0003e4 	mov	x4, x0
    4e14:	91170260 	add	x0, x19, #0x5c0
    4e18:	f94a1001 	ldr	x1, [x0, #5152]
    4e1c:	ab160021 	adds	x1, x1, x22
    4e20:	540005c2 	b.cs	4ed8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e24:	f94a1402 	ldr	x2, [x0, #5160]
    4e28:	f90a1001 	str	x1, [x0, #5152]
    4e2c:	eb02003f 	cmp	x1, x2
    4e30:	54000049 	b.ls	4e38 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e34:	f90a1401 	str	x1, [x0, #5160]
    4e38:	91170273 	add	x19, x19, #0x5c0
    4e3c:	1e6302e1 	ucvtf	d1, w23
    4e40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e44:	aa0403e0 	mov	x0, x4
    4e48:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e4c:	f9401bf7 	ldr	x23, [sp, #48]
    4e50:	1e612800 	fadd	d0, d0, d1
    4e54:	fd0a1e60 	str	d0, [x19, #5176]
    4e58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	97fffbc3 	bl	3d70 <fwp_heap_init>
    4e68:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e6c:	54fffa29 	b.ls	4db0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e70:	2a1403e1 	mov	w1, w20
    4e74:	aa1503e0 	mov	x0, x21
    4e78:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e80:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e84:	17ffff6f 	b	4c40 <fwp_heap_alloc_big>
    4e88:	8b030042 	add	x2, x2, x3
    4e8c:	f9400444 	ldr	x4, [x2, #8]
    4e90:	b4000104 	cbz	x4, 4eb0 <fwp_heap_alloc_slow+0x130>
    4e94:	f9400840 	ldr	x0, [x2, #16]
    4e98:	cb040000 	sub	x0, x0, x4
    4e9c:	eb16001f 	cmp	x0, x22
    4ea0:	54000083 	b.cc	4eb0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4ea4:	8b160080 	add	x0, x4, x22
    4ea8:	f9000440 	str	x0, [x2, #8]
    4eac:	17ffffd4 	b	4dfc <fwp_heap_alloc_slow+0x7c>
    4eb0:	52800302 	mov	w2, #0x18                  	// #24
    4eb4:	52807804 	mov	w4, #0x3c0                 	// #960
    4eb8:	91170260 	add	x0, x19, #0x5c0
    4ebc:	9ba27c23 	umull	x3, w1, w2
    4ec0:	2a1403e2 	mov	w2, w20
    4ec4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ec8:	8b040000 	add	x0, x0, x4
    4ecc:	97fffd19 	bl	4330 <fwp_heap_refill>
    4ed0:	aa0003e4 	mov	x4, x0
    4ed4:	17ffffca 	b	4dfc <fwp_heap_alloc_slow+0x7c>
    4ed8:	97fff856 	bl	3030 <fwp_heap_oom>
    4edc:	d503201f 	nop

0000000000004ee0 <fwp_heap_alloc>:
    4ee0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ee4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ee8:	910003fd 	mov	x29, sp
    4eec:	a90153f3 	stp	x19, x20, [sp, #16]
    4ef0:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc20>
    4ef4:	91170293 	add	x19, x20, #0x5c0
    4ef8:	b953a662 	ldr	w2, [x19, #5028]
    4efc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f00:	54000640 	b.eq	4fc8 <fwp_heap_alloc+0xe8>  // b.none
    4f04:	91003c03 	add	x3, x0, #0xf
    4f08:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f0c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f10:	8b431263 	add	x3, x19, x3, lsr #4
    4f14:	cb21c042 	sub	x2, x2, w1, sxtw
    4f18:	d37ae442 	lsl	x2, x2, #6
    4f1c:	397e8063 	ldrb	w3, [x3, #4000]
    4f20:	910f0064 	add	x4, x3, #0x3c0
    4f24:	8b030463 	add	x3, x3, x3, lsl #1
    4f28:	8b030c43 	add	x3, x2, x3, lsl #3
    4f2c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f30:	2a1603f5 	mov	w21, w22
    4f34:	f8636a64 	ldr	x4, [x19, x3]
    4f38:	b4000384 	cbz	x4, 4fa8 <fwp_heap_alloc+0xc8>
    4f3c:	f9400085 	ldr	x5, [x4]
    4f40:	7100043f 	cmp	w1, #0x1
    4f44:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f48:	aa0403e0 	mov	x0, x4
    4f4c:	aa2503e5 	mvn	x5, x5
    4f50:	52800001 	mov	w1, #0x0                   	// #0
    4f54:	f8236a65 	str	x5, [x19, x3]
    4f58:	97fff642 	bl	2860 <memset@plt>
    4f5c:	aa0003e4 	mov	x4, x0
    4f60:	f94a1260 	ldr	x0, [x19, #5152]
    4f64:	ab150000 	adds	x0, x0, x21
    4f68:	54000442 	b.cs	4ff0 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f6c:	f94a1661 	ldr	x1, [x19, #5160]
    4f70:	f90a1260 	str	x0, [x19, #5152]
    4f74:	eb01001f 	cmp	x0, x1
    4f78:	54000049 	b.ls	4f80 <fwp_heap_alloc+0xa0>  // b.plast
    4f7c:	f90a1660 	str	x0, [x19, #5160]
    4f80:	91170294 	add	x20, x20, #0x5c0
    4f84:	1e6302c1 	ucvtf	d1, w22
    4f88:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f8c:	aa0403e0 	mov	x0, x4
    4f90:	fd4a1e80 	ldr	d0, [x20, #5176]
    4f94:	1e612800 	fadd	d0, d0, d1
    4f98:	fd0a1e80 	str	d0, [x20, #5176]
    4f9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fa0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fa4:	d65f03c0 	ret
    4fa8:	8b030263 	add	x3, x19, x3
    4fac:	f9400464 	ldr	x4, [x3, #8]
    4fb0:	b40000a4 	cbz	x4, 4fc4 <fwp_heap_alloc+0xe4>
    4fb4:	f9400862 	ldr	x2, [x3, #16]
    4fb8:	cb040042 	sub	x2, x2, x4
    4fbc:	eb15005f 	cmp	x2, x21
    4fc0:	540000a2 	b.cs	4fd4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fc4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fcc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fd0:	17ffff6c 	b	4d80 <fwp_heap_alloc_slow>
    4fd4:	7100043f 	cmp	w1, #0x1
    4fd8:	8b150085 	add	x5, x4, x21
    4fdc:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	aa0403e0 	mov	x0, x4
    4fe8:	f9000465 	str	x5, [x3, #8]
    4fec:	17ffffdb 	b	4f58 <fwp_heap_alloc+0x78>
    4ff0:	97fff810 	bl	3030 <fwp_heap_oom>

0000000000004ff4 <fwp_data.part.0.constprop.0>:
    4ff4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4ff8:	910003fd 	mov	x29, sp
    4ffc:	a90153f3 	stp	x19, x20, [sp, #16]
    5000:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc20>
    5004:	91170283 	add	x3, x20, #0x5c0
    5008:	a9025bf5 	stp	x21, x22, [sp, #32]
    500c:	aa0103f5 	mov	x21, x1
    5010:	b953a461 	ldr	w1, [x3, #5028]
    5014:	a90363f7 	stp	x23, x24, [sp, #48]
    5018:	2a0003f8 	mov	w24, w0
    501c:	34000701 	cbz	w1, 50fc <fwp_data.part.0.constprop.0+0x108>
    5020:	397e8862 	ldrb	w2, [x3, #4002]
    5024:	910f0040 	add	x0, x2, #0x3c0
    5028:	8b020442 	add	x2, x2, x2, lsl #1
    502c:	d37df042 	lsl	x2, x2, #3
    5030:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5034:	2a1703f6 	mov	w22, w23
    5038:	f8626873 	ldr	x19, [x3, x2]
    503c:	b40004d3 	cbz	x19, 50d4 <fwp_data.part.0.constprop.0+0xe0>
    5040:	f9400260 	ldr	x0, [x19]
    5044:	aa2003e0 	mvn	x0, x0
    5048:	f8226860 	str	x0, [x3, x2]
    504c:	f10062df 	cmp	x22, #0x18
    5050:	540000e9 	b.ls	506c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5054:	d10066c2 	sub	x2, x22, #0x19
    5058:	91006260 	add	x0, x19, #0x18
    505c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5060:	52800001 	mov	w1, #0x0                   	// #0
    5064:	91002042 	add	x2, x2, #0x8
    5068:	97fff5fe 	bl	2860 <memset@plt>
    506c:	91170282 	add	x2, x20, #0x5c0
    5070:	f94a1041 	ldr	x1, [x2, #5152]
    5074:	ab160021 	adds	x1, x1, x22
    5078:	540004c2 	b.cs	5110 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    507c:	f94a1440 	ldr	x0, [x2, #5160]
    5080:	f90a1041 	str	x1, [x2, #5152]
    5084:	eb00003f 	cmp	x1, x0
    5088:	54000049 	b.ls	5090 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    508c:	f90a1441 	str	x1, [x2, #5160]
    5090:	91170294 	add	x20, x20, #0x5c0
    5094:	1e6302e1 	ucvtf	d1, w23
    5098:	fd4a1e80 	ldr	d0, [x20, #5176]
    509c:	1e612800 	fadd	d0, d0, d1
    50a0:	fd0a1e80 	str	d0, [x20, #5176]
    50a4:	52800041 	mov	w1, #0x2                   	// #2
    50a8:	29000678 	stp	w24, w1, [x19]
    50ac:	aa1303e0 	mov	x0, x19
    50b0:	f94002a1 	ldr	x1, [x21]
    50b4:	f9000661 	str	x1, [x19, #8]
    50b8:	f94006a1 	ldr	x1, [x21, #8]
    50bc:	f9000a61 	str	x1, [x19, #16]
    50c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    50c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50c8:	a94363f7 	ldp	x23, x24, [sp, #48]
    50cc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50d0:	d65f03c0 	ret
    50d4:	8b020063 	add	x3, x3, x2
    50d8:	f9400473 	ldr	x19, [x3, #8]
    50dc:	b4000113 	cbz	x19, 50fc <fwp_data.part.0.constprop.0+0x108>
    50e0:	f9400860 	ldr	x0, [x3, #16]
    50e4:	cb130000 	sub	x0, x0, x19
    50e8:	eb0002df 	cmp	x22, x0
    50ec:	54000088 	b.hi	50fc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    50f0:	8b160260 	add	x0, x19, x22
    50f4:	f9000460 	str	x0, [x3, #8]
    50f8:	17ffffd5 	b	504c <fwp_data.part.0.constprop.0+0x58>
    50fc:	52800001 	mov	w1, #0x0                   	// #0
    5100:	d2800300 	mov	x0, #0x18                  	// #24
    5104:	97ffff77 	bl	4ee0 <fwp_heap_alloc>
    5108:	aa0003f3 	mov	x19, x0
    510c:	17ffffe6 	b	50a4 <fwp_data.part.0.constprop.0+0xb0>
    5110:	97fff7c8 	bl	3030 <fwp_heap_oom>

0000000000005114 <fwp_tape_grow.constprop.0>:
    5114:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5118:	d2800802 	mov	x2, #0x40                  	// #64
    511c:	910003fd 	mov	x29, sp
    5120:	a90153f3 	stp	x19, x20, [sp, #16]
    5124:	aa0003f4 	mov	x20, x0
    5128:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    512c:	f9400e93 	ldr	x19, [x20, #24]
    5130:	f100027f 	cmp	x19, #0x0
    5134:	9a821273 	csel	x19, x19, x2, ne	// ne = any
    5138:	eb13003f 	cmp	x1, x19
    513c:	540000ed 	b.le	5158 <fwp_tape_grow.constprop.0+0x44>
    5140:	eb00027f 	cmp	x19, x0
    5144:	5400064d 	b.le	520c <fwp_tape_grow.constprop.0+0xf8>
    5148:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    514c:	eb13003f 	cmp	x1, x19
    5150:	5400004d 	b.le	5158 <fwp_tape_grow.constprop.0+0x44>
    5154:	14000000 	b	5154 <fwp_tape_grow.constprop.0+0x40>
    5158:	a9025bf5 	stp	x21, x22, [sp, #32]
    515c:	f9402a95 	ldr	x21, [x20, #80]
    5160:	b40005b5 	cbz	x21, 5214 <fwp_tape_grow.constprop.0+0x100>
    5164:	f9401680 	ldr	x0, [x20, #40]
    5168:	d37df261 	lsl	x1, x19, #3
    516c:	97fff5c5 	bl	2880 <realloc@plt>
    5170:	b40006e0 	cbz	x0, 524c <fwp_tape_grow.constprop.0+0x138>
    5174:	f94032b6 	ldr	x22, [x21, #96]
    5178:	f9001680 	str	x0, [x20, #40]
    517c:	eb1302df 	cmp	x22, x19
    5180:	540003ca 	b.ge	51f8 <fwp_tape_grow.constprop.0+0xe4>  // b.tcont
    5184:	a90363f7 	stp	x23, x24, [sp, #48]
    5188:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    518c:	f90023f9 	str	x25, [sp, #64]
    5190:	eb00027f 	cmp	x19, x0
    5194:	54000568 	b.hi	5240 <fwp_tape_grow.constprop.0+0x12c>  // b.pmore
    5198:	f94022b8 	ldr	x24, [x21, #64]
    519c:	d37cee79 	lsl	x25, x19, #4
    51a0:	aa1903e0 	mov	x0, x25
    51a4:	52800041 	mov	w1, #0x2                   	// #2
    51a8:	97ffff4e 	bl	4ee0 <fwp_heap_alloc>
    51ac:	aa0003f7 	mov	x23, x0
    51b0:	b4000118 	cbz	x24, 51d0 <fwp_tape_grow.constprop.0+0xbc>
    51b4:	d37ceed6 	lsl	x22, x22, #4
    51b8:	aa1803e1 	mov	x1, x24
    51bc:	eb1902df 	cmp	x22, x25
    51c0:	9a9992c2 	csel	x2, x22, x25, ls	// ls = plast
    51c4:	97fff54b 	bl	26f0 <memcpy@plt>
    51c8:	aa1803e0 	mov	x0, x24
    51cc:	97fffc89 	bl	43f0 <fwp_mem_free>
    51d0:	f94032a0 	ldr	x0, [x21, #96]
    51d4:	52800001 	mov	w1, #0x0                   	// #0
    51d8:	cb000262 	sub	x2, x19, x0
    51dc:	8b0012e0 	add	x0, x23, x0, lsl #4
    51e0:	d37cec42 	lsl	x2, x2, #4
    51e4:	97fff59f 	bl	2860 <memset@plt>
    51e8:	f94023f9 	ldr	x25, [sp, #64]
    51ec:	f90022b7 	str	x23, [x21, #64]
    51f0:	a94363f7 	ldp	x23, x24, [sp, #48]
    51f4:	f90032b3 	str	x19, [x21, #96]
    51f8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51fc:	f9000e93 	str	x19, [x20, #24]
    5200:	a94153f3 	ldp	x19, x20, [sp, #16]
    5204:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5208:	d65f03c0 	ret
    520c:	d37ffa73 	lsl	x19, x19, #1
    5210:	17ffffca 	b	5138 <fwp_tape_grow.constprop.0+0x24>
    5214:	f9401280 	ldr	x0, [x20, #32]
    5218:	8b130661 	add	x1, x19, x19, lsl #1
    521c:	d37df021 	lsl	x1, x1, #3
    5220:	97fff598 	bl	2880 <realloc@plt>
    5224:	b4000140 	cbz	x0, 524c <fwp_tape_grow.constprop.0+0x138>
    5228:	a9425bf5 	ldp	x21, x22, [sp, #32]
    522c:	f9000e93 	str	x19, [x20, #24]
    5230:	f9001280 	str	x0, [x20, #32]
    5234:	a94153f3 	ldp	x19, x20, [sp, #16]
    5238:	a8c57bfd 	ldp	x29, x30, [sp], #80
    523c:	d65f03c0 	ret
    5240:	90000040 	adrp	x0, d000 <__divti3+0x2a0>
    5244:	9120a000 	add	x0, x0, #0x828
    5248:	97fffbae 	bl	4100 <fwp_trap>
    524c:	aa1403e0 	mov	x0, x20
    5250:	a90363f7 	stp	x23, x24, [sp, #48]
    5254:	f90023f9 	str	x25, [sp, #64]
    5258:	97fff74e 	bl	2f90 <fwp_tape_unlink_scope>
    525c:	f9401280 	ldr	x0, [x20, #32]
    5260:	97fff5bc 	bl	2950 <free@plt>
    5264:	f9401680 	ldr	x0, [x20, #40]
    5268:	97fff5ba 	bl	2950 <free@plt>
    526c:	f9401a80 	ldr	x0, [x20, #48]
    5270:	97fff5b8 	bl	2950 <free@plt>
    5274:	f9000e9f 	str	xzr, [x20, #24]
    5278:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    527c:	f947e821 	ldr	x1, [x1, #4048]
    5280:	a9037e9f 	stp	xzr, xzr, [x20, #48]
    5284:	d2800262 	mov	x2, #0x13                  	// #19
    5288:	4f000400 	movi	v0.4s, #0x0
    528c:	90000040 	adrp	x0, d000 <__divti3+0x2a0>
    5290:	f9400023 	ldr	x3, [x1]
    5294:	b900069f 	str	wzr, [x20, #4]
    5298:	d2800021 	mov	x1, #0x1                   	// #1
    529c:	91122000 	add	x0, x0, #0x488
    52a0:	3c808280 	stur	q0, [x20, #8]
    52a4:	3d800a80 	str	q0, [x20, #32]
    52a8:	97fff5ba 	bl	2990 <fwrite@plt>
    52ac:	d2800000 	mov	x0, #0x0                   	// #0
    52b0:	97fff5c4 	bl	29c0 <fflush@plt>
    52b4:	52800cc0 	mov	w0, #0x66                  	// #102
    52b8:	97fff5d2 	bl	2a00 <_Exit@plt>
    52bc:	d503201f 	nop

00000000000052c0 <w123>:
    52c0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    52c4:	910003fd 	mov	x29, sp
    52c8:	6d0427e8 	stp	d8, d9, [sp, #64]
    52cc:	1e612808 	fadd	d8, d0, d1
    52d0:	ea01001f 	tst	x0, x1
    52d4:	54000b44 	b.mi	543c <w123+0x17c>  // b.first
    52d8:	a90153f3 	stp	x19, x20, [sp, #16]
    52dc:	aa0003f4 	mov	x20, x0
    52e0:	aa0103f3 	mov	x19, x1
    52e4:	a9025bf5 	stp	x21, x22, [sp, #32]
    52e8:	aa010000 	orr	x0, x0, x1
    52ec:	aa0203f5 	mov	x21, x2
    52f0:	f9001bf7 	str	x23, [sp, #48]
    52f4:	b7f80200 	tbnz	x0, #63, 5334 <w123+0x74>
    52f8:	9360fc37 	asr	x23, x1, #32
    52fc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5300:	eb9482ff 	cmp	x23, x20, asr #32
    5304:	54000a61 	b.ne	5450 <w123+0x190>  // b.any
    5308:	f94002a0 	ldr	x0, [x21]
    530c:	eb17001f 	cmp	x0, x23
    5310:	54000220 	b.eq	5354 <w123+0x94>  // b.none
    5314:	aa1703e0 	mov	x0, x23
    5318:	97fffd7e 	bl	4910 <fwp_tape_of>
    531c:	aa0003f6 	mov	x22, x0
    5320:	f9402800 	ldr	x0, [x0, #80]
    5324:	b40002e0 	cbz	x0, 5380 <w123+0xc0>
    5328:	90000040 	adrp	x0, d000 <__divti3+0x2a0>
    532c:	91224000 	add	x0, x0, #0x890
    5330:	97fffb74 	bl	4100 <fwp_trap>
    5334:	b6f80214 	tbz	x20, #63, 5374 <w123+0xb4>
    5338:	f94002a0 	ldr	x0, [x21]
    533c:	9360fc37 	asr	x23, x1, #32
    5340:	2f00e409 	movi	d9, #0x0
    5344:	aa0103f4 	mov	x20, x1
    5348:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    534c:	eb17001f 	cmp	x0, x23
    5350:	54fffe21 	b.ne	5314 <w123+0x54>  // b.any
    5354:	f94006b6 	ldr	x22, [x21, #8]
    5358:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    535c:	f9400ad7 	ldr	x23, [x22, #16]
    5360:	eb0002ff 	cmp	x23, x0
    5364:	5400018d 	b.le	5394 <w123+0xd4>
    5368:	90000040 	adrp	x0, d000 <__divti3+0x2a0>
    536c:	9120a000 	add	x0, x0, #0x828
    5370:	97fffb64 	bl	4100 <fwp_trap>
    5374:	9360fe97 	asr	x23, x20, #32
    5378:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    537c:	17ffffe3 	b	5308 <w123+0x48>
    5380:	a9005ab7 	stp	x23, x22, [x21]
    5384:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5388:	f9400ad7 	ldr	x23, [x22, #16]
    538c:	eb0002ff 	cmp	x23, x0
    5390:	54fffecc 	b.gt	5368 <w123+0xa8>
    5394:	eb3442ff 	cmp	x23, w20, uxtw
    5398:	540004cd 	b.le	5430 <w123+0x170>
    539c:	b7f80073 	tbnz	x19, #63, 53a8 <w123+0xe8>
    53a0:	eb3342ff 	cmp	x23, w19, uxtw
    53a4:	5400046d 	b.le	5430 <w123+0x170>
    53a8:	f94006d5 	ldr	x21, [x22, #8]
    53ac:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    53b0:	cb1502f5 	sub	x21, x23, x21
    53b4:	910006a1 	add	x1, x21, #0x1
    53b8:	eb00003f 	cmp	x1, x0
    53bc:	54fffd68 	b.hi	5368 <w123+0xa8>  // b.pmore
    53c0:	f9400ec0 	ldr	x0, [x22, #24]
    53c4:	eb00003f 	cmp	x1, x0
    53c8:	5400006d 	b.le	53d4 <w123+0x114>
    53cc:	aa1603e0 	mov	x0, x22
    53d0:	97ffff51 	bl	5114 <fwp_tape_grow.constprop.0>
    53d4:	f100027f 	cmp	x19, #0x0
    53d8:	9e670282 	fmov	d2, x20
    53dc:	da9fa273 	csinv	x19, x19, xzr, ge	// ge = tcont
    53e0:	8b1506b5 	add	x21, x21, x21, lsl #1
    53e4:	f94012c2 	ldr	x2, [x22, #32]
    53e8:	4e181e62 	mov	v2.d[1], x19
    53ec:	d37df2b5 	lsl	x21, x21, #3
    53f0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    53f4:	8b150040 	add	x0, x2, x21
    53f8:	92607e81 	and	x1, x20, #0xffffffff00000000
    53fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5400:	aa170021 	orr	x1, x1, x23
    5404:	0ea12842 	xtn	v2.2s, v2.2d
    5408:	910006f7 	add	x23, x23, #0x1
    540c:	fc356842 	str	d2, [x2, x21]
    5410:	6d00a400 	stp	d0, d9, [x0, #8]
    5414:	9e660100 	fmov	x0, d8
    5418:	f9000ad7 	str	x23, [x22, #16]
    541c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5420:	f9401bf7 	ldr	x23, [sp, #48]
    5424:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5428:	a8c57bfd 	ldp	x29, x30, [sp], #80
    542c:	d65f03c0 	ret
    5430:	90000040 	adrp	x0, d000 <__divti3+0x2a0>
    5434:	91230000 	add	x0, x0, #0x8c0
    5438:	97fffb32 	bl	4100 <fwp_trap>
    543c:	9e660100 	fmov	x0, d8
    5440:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    5444:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5448:	a8c57bfd 	ldp	x29, x30, [sp], #80
    544c:	d65f03c0 	ret
    5450:	90000040 	adrp	x0, d000 <__divti3+0x2a0>
    5454:	91212000 	add	x0, x0, #0x848
    5458:	97fffb2a 	bl	4100 <fwp_trap>
    545c:	d503201f 	nop

0000000000005460 <w120>:
    5460:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5464:	910003fd 	mov	x29, sp
    5468:	a90153f3 	stp	x19, x20, [sp, #16]
    546c:	aa0203f3 	mov	x19, x2
    5470:	a9025bf5 	stp	x21, x22, [sp, #32]
    5474:	aa0003f6 	mov	x22, x0
    5478:	aa0103f5 	mov	x21, x1
    547c:	a90363f7 	stp	x23, x24, [sp, #48]
    5480:	f90023f9 	str	x25, [sp, #64]
    5484:	fd0027ea 	str	d10, [sp, #72]
    5488:	1e60080a 	fmul	d10, d0, d0
    548c:	6d0527e8 	stp	d8, d9, [sp, #80]
    5490:	1e604008 	fmov	d8, d0
    5494:	1e604029 	fmov	d9, d1
    5498:	b7f82500 	tbnz	x0, #63, 5938 <w120+0x4d8>
    549c:	9360fc14 	asr	x20, x0, #32
    54a0:	f9400040 	ldr	x0, [x2]
    54a4:	eb14001f 	cmp	x0, x20
    54a8:	54002340 	b.eq	5910 <w120+0x4b0>  // b.none
    54ac:	aa1403e0 	mov	x0, x20
    54b0:	97fffd18 	bl	4910 <fwp_tape_of>
    54b4:	aa0003f7 	mov	x23, x0
    54b8:	f9402800 	ldr	x0, [x0, #80]
    54bc:	b4000080 	cbz	x0, 54cc <w120+0x6c>
    54c0:	90000040 	adrp	x0, d000 <__divti3+0x2a0>
    54c4:	91224000 	add	x0, x0, #0x890
    54c8:	97fffb0e 	bl	4100 <fwp_trap>
    54cc:	a9005e74 	stp	x20, x23, [x19]
    54d0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54d4:	f9400af8 	ldr	x24, [x23, #16]
    54d8:	eb00031f 	cmp	x24, x0
    54dc:	5400210c 	b.gt	58fc <w120+0x49c>
    54e0:	eb36431f 	cmp	x24, w22, uxtw
    54e4:	5400206d 	b.le	58f0 <w120+0x490>
    54e8:	f94006f4 	ldr	x20, [x23, #8]
    54ec:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54f0:	cb140314 	sub	x20, x24, x20
    54f4:	91000681 	add	x1, x20, #0x1
    54f8:	eb00003f 	cmp	x1, x0
    54fc:	54002008 	b.hi	58fc <w120+0x49c>  // b.pmore
    5500:	f9400ee0 	ldr	x0, [x23, #24]
    5504:	eb00003f 	cmp	x1, x0
    5508:	5400006d 	b.le	5514 <w120+0xb4>
    550c:	aa1703e0 	mov	x0, x23
    5510:	97ffff01 	bl	5114 <fwp_tape_grow.constprop.0>
    5514:	8b140681 	add	x1, x20, x20, lsl #1
    5518:	92607ed4 	and	x20, x22, #0xffffffff00000000
    551c:	f94012e2 	ldr	x2, [x23, #32]
    5520:	d37df021 	lsl	x1, x1, #3
    5524:	aa180294 	orr	x20, x20, x24
    5528:	91000718 	add	x24, x24, #0x1
    552c:	8b010040 	add	x0, x2, x1
    5530:	b8216856 	str	w22, [x2, x1]
    5534:	9360fe99 	asr	x25, x20, #32
    5538:	b9000416 	str	w22, [x0, #4]
    553c:	6d00a008 	stp	d8, d8, [x0, #8]
    5540:	f9000af8 	str	x24, [x23, #16]
    5544:	b7f80075 	tbnz	x21, #63, 5550 <w120+0xf0>
    5548:	eb95833f 	cmp	x25, x21, asr #32
    554c:	540021c1 	b.ne	5984 <w120+0x524>  // b.any
    5550:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0xb80>
    5554:	1e6a3929 	fsub	d9, d9, d10
    5558:	3dc0a400 	ldr	q0, [x0, #656]
    555c:	3d801be0 	str	q0, [sp, #96]
    5560:	f9400260 	ldr	x0, [x19]
    5564:	eb19001f 	cmp	x0, x25
    5568:	54001d00 	b.eq	5908 <w120+0x4a8>  // b.none
    556c:	aa1903e0 	mov	x0, x25
    5570:	97fffce8 	bl	4910 <fwp_tape_of>
    5574:	aa0003f8 	mov	x24, x0
    5578:	f9402800 	ldr	x0, [x0, #80]
    557c:	b5fffa20 	cbnz	x0, 54c0 <w120+0x60>
    5580:	a9006279 	stp	x25, x24, [x19]
    5584:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5588:	f9400b19 	ldr	x25, [x24, #16]
    558c:	eb00033f 	cmp	x25, x0
    5590:	54001b6c 	b.gt	58fc <w120+0x49c>
    5594:	eb34433f 	cmp	x25, w20, uxtw
    5598:	54001acd 	b.le	58f0 <w120+0x490>
    559c:	b7f80075 	tbnz	x21, #63, 55a8 <w120+0x148>
    55a0:	eb35433f 	cmp	x25, w21, uxtw
    55a4:	54001a6d 	b.le	58f0 <w120+0x490>
    55a8:	f9400717 	ldr	x23, [x24, #8]
    55ac:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    55b0:	cb170337 	sub	x23, x25, x23
    55b4:	910006e1 	add	x1, x23, #0x1
    55b8:	eb00003f 	cmp	x1, x0
    55bc:	54001a08 	b.hi	58fc <w120+0x49c>  // b.pmore
    55c0:	f9400f00 	ldr	x0, [x24, #24]
    55c4:	eb00003f 	cmp	x1, x0
    55c8:	5400006d 	b.le	55d4 <w120+0x174>
    55cc:	aa1803e0 	mov	x0, x24
    55d0:	97fffed1 	bl	5114 <fwp_tape_grow.constprop.0>
    55d4:	f10002bf 	cmp	x21, #0x0
    55d8:	9e670282 	fmov	d2, x20
    55dc:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    55e0:	9a81a2b5 	csel	x21, x21, x1, ge	// ge = tcont
    55e4:	f9401300 	ldr	x0, [x24, #32]
    55e8:	4e181ea2 	mov	v2.d[1], x21
    55ec:	8b1706f7 	add	x23, x23, x23, lsl #1
    55f0:	91000722 	add	x2, x25, #0x1
    55f4:	3dc01be0 	ldr	q0, [sp, #96]
    55f8:	d37df2f7 	lsl	x23, x23, #3
    55fc:	0ea12842 	xtn	v2.2s, v2.2d
    5600:	8b170003 	add	x3, x0, x23
    5604:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5608:	92607e94 	and	x20, x20, #0xffffffff00000000
    560c:	aa190294 	orr	x20, x20, x25
    5610:	1e68394a 	fsub	d10, d10, d8
    5614:	fc376802 	str	d2, [x0, x23]
    5618:	3c808060 	stur	q0, [x3, #8]
    561c:	f9000b02 	str	x2, [x24, #16]
    5620:	b7f81b96 	tbnz	x22, #63, 5990 <w120+0x530>
    5624:	f9400260 	ldr	x0, [x19]
    5628:	9360fed5 	asr	x21, x22, #32
    562c:	eb15001f 	cmp	x0, x21
    5630:	54001800 	b.eq	5930 <w120+0x4d0>  // b.none
    5634:	aa1503e0 	mov	x0, x21
    5638:	97fffcb6 	bl	4910 <fwp_tape_of>
    563c:	aa0003f7 	mov	x23, x0
    5640:	f9402800 	ldr	x0, [x0, #80]
    5644:	b5fff3e0 	cbnz	x0, 54c0 <w120+0x60>
    5648:	a9005e75 	stp	x21, x23, [x19]
    564c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5650:	f9400af8 	ldr	x24, [x23, #16]
    5654:	eb00031f 	cmp	x24, x0
    5658:	5400152c 	b.gt	58fc <w120+0x49c>
    565c:	eb36431f 	cmp	x24, w22, uxtw
    5660:	5400148d 	b.le	58f0 <w120+0x490>
    5664:	f94006f5 	ldr	x21, [x23, #8]
    5668:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    566c:	cb150315 	sub	x21, x24, x21
    5670:	910006a1 	add	x1, x21, #0x1
    5674:	eb00003f 	cmp	x1, x0
    5678:	54001428 	b.hi	58fc <w120+0x49c>  // b.pmore
    567c:	f9400ee0 	ldr	x0, [x23, #24]
    5680:	eb00003f 	cmp	x1, x0
    5684:	5400006d 	b.le	5690 <w120+0x230>
    5688:	aa1703e0 	mov	x0, x23
    568c:	97fffea2 	bl	5114 <fwp_tape_grow.constprop.0>
    5690:	8b1506b5 	add	x21, x21, x21, lsl #1
    5694:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0xb80>
    5698:	f94012e2 	ldr	x2, [x23, #32]
    569c:	d37df2a1 	lsl	x1, x21, #3
    56a0:	3dc0a400 	ldr	q0, [x0, #656]
    56a4:	8b010040 	add	x0, x2, x1
    56a8:	b8216856 	str	w22, [x2, x1]
    56ac:	92607ec3 	and	x3, x22, #0xffffffff00000000
    56b0:	12800001 	mov	w1, #0xffffffff            	// #-1
    56b4:	aa180075 	orr	x21, x3, x24
    56b8:	b9000401 	str	w1, [x0, #4]
    56bc:	91000718 	add	x24, x24, #0x1
    56c0:	3c808000 	stur	q0, [x0, #8]
    56c4:	f9000af8 	str	x24, [x23, #16]
    56c8:	f9400260 	ldr	x0, [x19]
    56cc:	9360fe96 	asr	x22, x20, #32
    56d0:	1e690928 	fmul	d8, d9, d9
    56d4:	eb16001f 	cmp	x0, x22
    56d8:	54001280 	b.eq	5928 <w120+0x4c8>  // b.none
    56dc:	aa1603e0 	mov	x0, x22
    56e0:	97fffc8c 	bl	4910 <fwp_tape_of>
    56e4:	aa0003f7 	mov	x23, x0
    56e8:	f9402800 	ldr	x0, [x0, #80]
    56ec:	b5ffeea0 	cbnz	x0, 54c0 <w120+0x60>
    56f0:	a9005e76 	stp	x22, x23, [x19]
    56f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    56f8:	f9400af9 	ldr	x25, [x23, #16]
    56fc:	eb00033f 	cmp	x25, x0
    5700:	54000fec 	b.gt	58fc <w120+0x49c>
    5704:	eb34433f 	cmp	x25, w20, uxtw
    5708:	54000f4d 	b.le	58f0 <w120+0x490>
    570c:	f94006f6 	ldr	x22, [x23, #8]
    5710:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5714:	cb160336 	sub	x22, x25, x22
    5718:	910006c1 	add	x1, x22, #0x1
    571c:	eb00003f 	cmp	x1, x0
    5720:	54000ee8 	b.hi	58fc <w120+0x49c>  // b.pmore
    5724:	f9400ee0 	ldr	x0, [x23, #24]
    5728:	eb00003f 	cmp	x1, x0
    572c:	5400006d 	b.le	5738 <w120+0x2d8>
    5730:	aa1703e0 	mov	x0, x23
    5734:	97fffe78 	bl	5114 <fwp_tape_grow.constprop.0>
    5738:	8b1606d6 	add	x22, x22, x22, lsl #1
    573c:	92607e98 	and	x24, x20, #0xffffffff00000000
    5740:	f94012e0 	ldr	x0, [x23, #32]
    5744:	d37df2d6 	lsl	x22, x22, #3
    5748:	f9400262 	ldr	x2, [x19]
    574c:	8b160001 	add	x1, x0, x22
    5750:	b8366814 	str	w20, [x0, x22]
    5754:	aa190318 	orr	x24, x24, x25
    5758:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    575c:	9e670000 	fmov	d0, x0
    5760:	b9000434 	str	w20, [x1, #4]
    5764:	91000739 	add	x25, x25, #0x1
    5768:	6d00a429 	stp	d9, d9, [x1, #8]
    576c:	9360ff14 	asr	x20, x24, #32
    5770:	1e600908 	fmul	d8, d8, d0
    5774:	f9000af9 	str	x25, [x23, #16]
    5778:	eb14005f 	cmp	x2, x20
    577c:	54000d20 	b.eq	5920 <w120+0x4c0>  // b.none
    5780:	aa1403e0 	mov	x0, x20
    5784:	97fffc63 	bl	4910 <fwp_tape_of>
    5788:	aa0003f6 	mov	x22, x0
    578c:	f9402800 	ldr	x0, [x0, #80]
    5790:	b5ffe980 	cbnz	x0, 54c0 <w120+0x60>
    5794:	a9005a74 	stp	x20, x22, [x19]
    5798:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    579c:	f9400ad7 	ldr	x23, [x22, #16]
    57a0:	eb0002ff 	cmp	x23, x0
    57a4:	54000acc 	b.gt	58fc <w120+0x49c>
    57a8:	eb3842ff 	cmp	x23, w24, uxtw
    57ac:	54000a2d 	b.le	58f0 <w120+0x490>
    57b0:	f94006d4 	ldr	x20, [x22, #8]
    57b4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    57b8:	cb1402f4 	sub	x20, x23, x20
    57bc:	91000681 	add	x1, x20, #0x1
    57c0:	eb00003f 	cmp	x1, x0
    57c4:	540009c8 	b.hi	58fc <w120+0x49c>  // b.pmore
    57c8:	f9400ec0 	ldr	x0, [x22, #24]
    57cc:	eb00003f 	cmp	x1, x0
    57d0:	5400006d 	b.le	57dc <w120+0x37c>
    57d4:	aa1603e0 	mov	x0, x22
    57d8:	97fffe4f 	bl	5114 <fwp_tape_grow.constprop.0>
    57dc:	8b140694 	add	x20, x20, x20, lsl #1
    57e0:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0xb80>
    57e4:	f94012c1 	ldr	x1, [x22, #32]
    57e8:	d37df294 	lsl	x20, x20, #3
    57ec:	3dc0a800 	ldr	q0, [x0, #672]
    57f0:	8b140020 	add	x0, x1, x20
    57f4:	b8346838 	str	w24, [x1, x20]
    57f8:	12800002 	mov	w2, #0xffffffff            	// #-1
    57fc:	92607f18 	and	x24, x24, #0xffffffff00000000
    5800:	910006e1 	add	x1, x23, #0x1
    5804:	b9000402 	str	w2, [x0, #4]
    5808:	1e6a0949 	fmul	d9, d10, d10
    580c:	3c808000 	stur	q0, [x0, #8]
    5810:	aa170318 	orr	x24, x24, x23
    5814:	aa1503e0 	mov	x0, x21
    5818:	f9000ac1 	str	x1, [x22, #16]
    581c:	b10006bf 	cmn	x21, #0x1
    5820:	540004e0 	b.eq	58bc <w120+0x45c>  // b.none
    5824:	f9400260 	ldr	x0, [x19]
    5828:	9360feb4 	asr	x20, x21, #32
    582c:	eb14001f 	cmp	x0, x20
    5830:	54000740 	b.eq	5918 <w120+0x4b8>  // b.none
    5834:	aa1403e0 	mov	x0, x20
    5838:	97fffc36 	bl	4910 <fwp_tape_of>
    583c:	aa0003f6 	mov	x22, x0
    5840:	f9402800 	ldr	x0, [x0, #80]
    5844:	b5ffe3e0 	cbnz	x0, 54c0 <w120+0x60>
    5848:	a9005a74 	stp	x20, x22, [x19]
    584c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5850:	f9400ad7 	ldr	x23, [x22, #16]
    5854:	eb0002ff 	cmp	x23, x0
    5858:	5400052c 	b.gt	58fc <w120+0x49c>
    585c:	eb3542ff 	cmp	x23, w21, uxtw
    5860:	5400048d 	b.le	58f0 <w120+0x490>
    5864:	f94006d4 	ldr	x20, [x22, #8]
    5868:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    586c:	cb1402f4 	sub	x20, x23, x20
    5870:	91000681 	add	x1, x20, #0x1
    5874:	eb00003f 	cmp	x1, x0
    5878:	54000428 	b.hi	58fc <w120+0x49c>  // b.pmore
    587c:	f9400ec0 	ldr	x0, [x22, #24]
    5880:	eb00003f 	cmp	x1, x0
    5884:	5400006d 	b.le	5890 <w120+0x430>
    5888:	aa1603e0 	mov	x0, x22
    588c:	97fffe22 	bl	5114 <fwp_tape_grow.constprop.0>
    5890:	8b140694 	add	x20, x20, x20, lsl #1
    5894:	92607ea0 	and	x0, x21, #0xffffffff00000000
    5898:	f94012c2 	ldr	x2, [x22, #32]
    589c:	d37df294 	lsl	x20, x20, #3
    58a0:	aa170000 	orr	x0, x0, x23
    58a4:	910006f7 	add	x23, x23, #0x1
    58a8:	8b140041 	add	x1, x2, x20
    58ac:	b8346855 	str	w21, [x2, x20]
    58b0:	b9000435 	str	w21, [x1, #4]
    58b4:	6d00a82a 	stp	d10, d10, [x1, #8]
    58b8:	f9000ad7 	str	x23, [x22, #16]
    58bc:	1e604101 	fmov	d1, d8
    58c0:	1e604120 	fmov	d0, d9
    58c4:	aa1303e2 	mov	x2, x19
    58c8:	aa1803e1 	mov	x1, x24
    58cc:	97fffe7d 	bl	52c0 <w123>
    58d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    58d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    58d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    58dc:	f94023f9 	ldr	x25, [sp, #64]
    58e0:	fd4027ea 	ldr	d10, [sp, #72]
    58e4:	6d4527e8 	ldp	d8, d9, [sp, #80]
    58e8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    58ec:	d65f03c0 	ret
    58f0:	90000040 	adrp	x0, d000 <__divti3+0x2a0>
    58f4:	91230000 	add	x0, x0, #0x8c0
    58f8:	97fffa02 	bl	4100 <fwp_trap>
    58fc:	90000040 	adrp	x0, d000 <__divti3+0x2a0>
    5900:	9120a000 	add	x0, x0, #0x828
    5904:	97fff9ff 	bl	4100 <fwp_trap>
    5908:	f9400678 	ldr	x24, [x19, #8]
    590c:	17ffff1e 	b	5584 <w120+0x124>
    5910:	f9400457 	ldr	x23, [x2, #8]
    5914:	17fffeef 	b	54d0 <w120+0x70>
    5918:	f9400676 	ldr	x22, [x19, #8]
    591c:	17ffffcc 	b	584c <w120+0x3ec>
    5920:	f9400676 	ldr	x22, [x19, #8]
    5924:	17ffff9d 	b	5798 <w120+0x338>
    5928:	f9400677 	ldr	x23, [x19, #8]
    592c:	17ffff72 	b	56f4 <w120+0x294>
    5930:	f9400677 	ldr	x23, [x19, #8]
    5934:	17ffff46 	b	564c <w120+0x1ec>
    5938:	1e6a3829 	fsub	d9, d1, d10
    593c:	b6f80161 	tbz	x1, #63, 5968 <w120+0x508>
    5940:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5944:	1e690921 	fmul	d1, d9, d9
    5948:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    594c:	9e670002 	fmov	d2, x0
    5950:	1e683809 	fsub	d9, d0, d8
    5954:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5958:	aa1803e0 	mov	x0, x24
    595c:	1e620828 	fmul	d8, d1, d2
    5960:	1e690929 	fmul	d9, d9, d9
    5964:	17ffffd6 	b	58bc <w120+0x45c>
    5968:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0xb80>
    596c:	9360fc39 	asr	x25, x1, #32
    5970:	aa0103f4 	mov	x20, x1
    5974:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5978:	3dc0a000 	ldr	q0, [x0, #640]
    597c:	3d801be0 	str	q0, [sp, #96]
    5980:	17fffef8 	b	5560 <w120+0x100>
    5984:	90000040 	adrp	x0, d000 <__divti3+0x2a0>
    5988:	91212000 	add	x0, x0, #0x848
    598c:	97fff9dd 	bl	4100 <fwp_trap>
    5990:	aa0103f5 	mov	x21, x1
    5994:	17ffff4d 	b	56c8 <w120+0x268>
    5998:	d503201f 	nop
    599c:	d503201f 	nop

00000000000059a0 <w176.constprop.0>:
    59a0:	d10183ff 	sub	sp, sp, #0x60
    59a4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    59a8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    59ac:	f947f421 	ldr	x1, [x1, #4072]
    59b0:	a9027bfd 	stp	x29, x30, [sp, #32]
    59b4:	910083fd 	add	x29, sp, #0x20
    59b8:	a9045bf5 	stp	x21, x22, [sp, #64]
    59bc:	f9400015 	ldr	x21, [x0]
    59c0:	f9400023 	ldr	x3, [x1]
    59c4:	f9000fe3 	str	x3, [sp, #24]
    59c8:	d2800003 	mov	x3, #0x0                   	// #0
    59cc:	a900ffe2 	stp	x2, xzr, [sp, #8]
    59d0:	b4000435 	cbz	x21, 5a54 <w176.constprop.0+0xb4>
    59d4:	2f00e400 	movi	d0, #0x0
    59d8:	91004016 	add	x22, x0, #0x10
    59dc:	a90353f3 	stp	x19, x20, [sp, #48]
    59e0:	91002014 	add	x20, x0, #0x8
    59e4:	d2800013 	mov	x19, #0x0                   	// #0
    59e8:	f9002bf7 	str	x23, [sp, #80]
    59ec:	910023f7 	add	x23, sp, #0x8
    59f0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    59f4:	aa0203e0 	mov	x0, x2
    59f8:	fc737a81 	ldr	d1, [x20, x19, lsl #3]
    59fc:	aa1703e2 	mov	x2, x23
    5a00:	91000a73 	add	x19, x19, #0x2
    5a04:	97fffe2f 	bl	52c0 <w123>
    5a08:	aa0103e2 	mov	x2, x1
    5a0c:	9e670000 	fmov	d0, x0
    5a10:	eb1302bf 	cmp	x21, x19
    5a14:	54fffee8 	b.hi	59f0 <w176.constprop.0+0x50>  // b.pmore
    5a18:	a94353f3 	ldp	x19, x20, [sp, #48]
    5a1c:	f9402bf7 	ldr	x23, [sp, #80]
    5a20:	9e660000 	fmov	x0, d0
    5a24:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    5a28:	f947f421 	ldr	x1, [x1, #4072]
    5a2c:	f9400fe4 	ldr	x4, [sp, #24]
    5a30:	f9400023 	ldr	x3, [x1]
    5a34:	eb030084 	subs	x4, x4, x3
    5a38:	d2800003 	mov	x3, #0x0                   	// #0
    5a3c:	54000101 	b.ne	5a5c <w176.constprop.0+0xbc>  // b.any
    5a40:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a44:	aa0203e1 	mov	x1, x2
    5a48:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5a4c:	910183ff 	add	sp, sp, #0x60
    5a50:	d65f03c0 	ret
    5a54:	2f00e400 	movi	d0, #0x0
    5a58:	17fffff2 	b	5a20 <w176.constprop.0+0x80>
    5a5c:	a90353f3 	stp	x19, x20, [sp, #48]
    5a60:	f9002bf7 	str	x23, [sp, #80]
    5a64:	97fff38b 	bl	2890 <__stack_chk_fail@plt>
    5a68:	d503201f 	nop
    5a6c:	d503201f 	nop

0000000000005a70 <fwp_rc_share>:
    5a70:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    5a74:	91170042 	add	x2, x2, #0x5c0
    5a78:	f949d843 	ldr	x3, [x2, #5040]
    5a7c:	f949ec41 	ldr	x1, [x2, #5080]
    5a80:	cb030000 	sub	x0, x0, x3
    5a84:	eb01401f 	cmp	x0, x1, lsl #16
    5a88:	540003a2 	b.cs	5afc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5a8c:	d350fc01 	lsr	x1, x0, #16
    5a90:	f949fc44 	ldr	x4, [x2, #5112]
    5a94:	8b010821 	add	x1, x1, x1, lsl #2
    5a98:	d37df021 	lsl	x1, x1, #3
    5a9c:	8b010083 	add	x3, x4, x1
    5aa0:	f9401062 	ldr	x2, [x3, #32]
    5aa4:	b40002c2 	cbz	x2, 5afc <fwp_rc_share+0x8c>
    5aa8:	38616881 	ldrb	w1, [x4, x1]
    5aac:	7100083f 	cmp	w1, #0x2
    5ab0:	54000220 	b.eq	5af4 <fwp_rc_share+0x84>  // b.none
    5ab4:	7100043f 	cmp	w1, #0x1
    5ab8:	54000221 	b.ne	5afc <fwp_rc_share+0x8c>  // b.any
    5abc:	29430464 	ldp	w4, w1, [x3, #24]
    5ac0:	92403c00 	and	x0, x0, #0xffff
    5ac4:	9b047c00 	mul	x0, x0, x4
    5ac8:	d360fc00 	lsr	x0, x0, #32
    5acc:	eb01001f 	cmp	x0, x1
    5ad0:	54000162 	b.cs	5afc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5ad4:	8b000042 	add	x2, x2, x0
    5ad8:	39400040 	ldrb	w0, [x2]
    5adc:	34000100 	cbz	w0, 5afc <fwp_rc_share+0x8c>
    5ae0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5ae4:	90000040 	adrp	x0, d000 <__divti3+0x2a0>
    5ae8:	91238000 	add	x0, x0, #0x8e0
    5aec:	910003fd 	mov	x29, sp
    5af0:	97fff984 	bl	4100 <fwp_trap>
    5af4:	72003c1f 	tst	w0, #0xffff
    5af8:	54ffff00 	b.eq	5ad8 <fwp_rc_share+0x68>  // b.none
    5afc:	d65f03c0 	ret

0000000000005b00 <fwp_rc_fresh>:
    5b00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5b04:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5b08:	91170063 	add	x3, x3, #0x5c0
    5b0c:	910003fd 	mov	x29, sp
    5b10:	a90153f3 	stp	x19, x20, [sp, #16]
    5b14:	aa0003f3 	mov	x19, x0
    5b18:	f949d861 	ldr	x1, [x3, #5040]
    5b1c:	f949ec60 	ldr	x0, [x3, #5080]
    5b20:	cb010261 	sub	x1, x19, x1
    5b24:	eb00403f 	cmp	x1, x0, lsl #16
    5b28:	54000322 	b.cs	5b8c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5b2c:	d350fc22 	lsr	x2, x1, #16
    5b30:	f949fc63 	ldr	x3, [x3, #5112]
    5b34:	8b020842 	add	x2, x2, x2, lsl #2
    5b38:	d37df042 	lsl	x2, x2, #3
    5b3c:	8b020060 	add	x0, x3, x2
    5b40:	f9401014 	ldr	x20, [x0, #32]
    5b44:	b4000254 	cbz	x20, 5b8c <fwp_rc_fresh+0x8c>
    5b48:	38626862 	ldrb	w2, [x3, x2]
    5b4c:	7100085f 	cmp	w2, #0x2
    5b50:	54000260 	b.eq	5b9c <fwp_rc_fresh+0x9c>  // b.none
    5b54:	7100045f 	cmp	w2, #0x1
    5b58:	540001a1 	b.ne	5b8c <fwp_rc_fresh+0x8c>  // b.any
    5b5c:	29430002 	ldp	w2, w0, [x0, #24]
    5b60:	92403c21 	and	x1, x1, #0xffff
    5b64:	9b027c21 	mul	x1, x1, x2
    5b68:	d360fc21 	lsr	x1, x1, #32
    5b6c:	eb00003f 	cmp	x1, x0
    5b70:	540000e2 	b.cs	5b8c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5b74:	8b010294 	add	x20, x20, x1
    5b78:	39400280 	ldrb	w0, [x20]
    5b7c:	7103fc1f 	cmp	w0, #0xff
    5b80:	540001a0 	b.eq	5bb4 <fwp_rc_fresh+0xb4>  // b.none
    5b84:	52800020 	mov	w0, #0x1                   	// #1
    5b88:	39000280 	strb	w0, [x20]
    5b8c:	aa1303e0 	mov	x0, x19
    5b90:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b94:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b98:	d65f03c0 	ret
    5b9c:	72003c3f 	tst	w1, #0xffff
    5ba0:	54fffec0 	b.eq	5b78 <fwp_rc_fresh+0x78>  // b.none
    5ba4:	aa1303e0 	mov	x0, x19
    5ba8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5bb0:	d65f03c0 	ret
    5bb4:	aa1403e0 	mov	x0, x20
    5bb8:	97fff972 	bl	4180 <fwp_rc_forget_slot.part.0>
    5bbc:	17fffff2 	b	5b84 <fwp_rc_fresh+0x84>

0000000000005bc0 <fwp_rc_free_arr>:
    5bc0:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5bc4:	91170063 	add	x3, x3, #0x5c0
    5bc8:	f949d861 	ldr	x1, [x3, #5040]
    5bcc:	f949ec62 	ldr	x2, [x3, #5080]
    5bd0:	cb010001 	sub	x1, x0, x1
    5bd4:	eb02403f 	cmp	x1, x2, lsl #16
    5bd8:	54000342 	b.cs	5c40 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5bdc:	d350fc22 	lsr	x2, x1, #16
    5be0:	f949fc65 	ldr	x5, [x3, #5112]
    5be4:	8b020842 	add	x2, x2, x2, lsl #2
    5be8:	d37df042 	lsl	x2, x2, #3
    5bec:	8b0200a4 	add	x4, x5, x2
    5bf0:	f9401083 	ldr	x3, [x4, #32]
    5bf4:	b4000263 	cbz	x3, 5c40 <fwp_rc_free_arr+0x80>
    5bf8:	386268a2 	ldrb	w2, [x5, x2]
    5bfc:	7100085f 	cmp	w2, #0x2
    5c00:	540001c0 	b.eq	5c38 <fwp_rc_free_arr+0x78>  // b.none
    5c04:	7100045f 	cmp	w2, #0x1
    5c08:	540001c1 	b.ne	5c40 <fwp_rc_free_arr+0x80>  // b.any
    5c0c:	29430885 	ldp	w5, w2, [x4, #24]
    5c10:	92403c21 	and	x1, x1, #0xffff
    5c14:	9b057c21 	mul	x1, x1, x5
    5c18:	d360fc21 	lsr	x1, x1, #32
    5c1c:	eb02003f 	cmp	x1, x2
    5c20:	54000102 	b.cs	5c40 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5c24:	8b010063 	add	x3, x3, x1
    5c28:	39400061 	ldrb	w1, [x3]
    5c2c:	7100043f 	cmp	w1, #0x1
    5c30:	54000081 	b.ne	5c40 <fwp_rc_free_arr+0x80>  // b.any
    5c34:	17fff9ef 	b	43f0 <fwp_mem_free>
    5c38:	72003c3f 	tst	w1, #0xffff
    5c3c:	54ffff60 	b.eq	5c28 <fwp_rc_free_arr+0x68>  // b.none
    5c40:	d65f03c0 	ret

0000000000005c44 <fwp_rc_dup>:
    5c44:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    5c48:	91170042 	add	x2, x2, #0x5c0
    5c4c:	f949d841 	ldr	x1, [x2, #5040]
    5c50:	f949ec43 	ldr	x3, [x2, #5080]
    5c54:	cb010001 	sub	x1, x0, x1
    5c58:	eb03403f 	cmp	x1, x3, lsl #16
    5c5c:	54000342 	b.cs	5cc4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5c60:	d350fc20 	lsr	x0, x1, #16
    5c64:	f949fc44 	ldr	x4, [x2, #5112]
    5c68:	8b000800 	add	x0, x0, x0, lsl #2
    5c6c:	d37df002 	lsl	x2, x0, #3
    5c70:	8b020083 	add	x3, x4, x2
    5c74:	f9401060 	ldr	x0, [x3, #32]
    5c78:	b4000260 	cbz	x0, 5cc4 <fwp_rc_dup+0x80>
    5c7c:	38626882 	ldrb	w2, [x4, x2]
    5c80:	7100085f 	cmp	w2, #0x2
    5c84:	54000220 	b.eq	5cc8 <fwp_rc_dup+0x84>  // b.none
    5c88:	7100045f 	cmp	w2, #0x1
    5c8c:	540001c1 	b.ne	5cc4 <fwp_rc_dup+0x80>  // b.any
    5c90:	29430864 	ldp	w4, w2, [x3, #24]
    5c94:	92403c21 	and	x1, x1, #0xffff
    5c98:	9b047c21 	mul	x1, x1, x4
    5c9c:	d360fc21 	lsr	x1, x1, #32
    5ca0:	eb02003f 	cmp	x1, x2
    5ca4:	54000102 	b.cs	5cc4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5ca8:	8b010000 	add	x0, x0, x1
    5cac:	39400001 	ldrb	w1, [x0]
    5cb0:	340000a1 	cbz	w1, 5cc4 <fwp_rc_dup+0x80>
    5cb4:	7103f43f 	cmp	w1, #0xfd
    5cb8:	540000e8 	b.hi	5cd4 <fwp_rc_dup+0x90>  // b.pmore
    5cbc:	11000421 	add	w1, w1, #0x1
    5cc0:	39000001 	strb	w1, [x0]
    5cc4:	d65f03c0 	ret
    5cc8:	72003c3f 	tst	w1, #0xffff
    5ccc:	54ffff00 	b.eq	5cac <fwp_rc_dup+0x68>  // b.none
    5cd0:	d65f03c0 	ret
    5cd4:	17fffa40 	b	45d4 <fwp_rc_wide_dup>
    5cd8:	d503201f 	nop
    5cdc:	d503201f 	nop

0000000000005ce0 <fwp_owned_entry173>:
    5ce0:	d10103ff 	sub	sp, sp, #0x40
    5ce4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    5ce8:	f947f442 	ldr	x2, [x2, #4072]
    5cec:	a9027bfd 	stp	x29, x30, [sp, #32]
    5cf0:	910083fd 	add	x29, sp, #0x20
    5cf4:	a90353f3 	stp	x19, x20, [sp, #48]
    5cf8:	f9400043 	ldr	x3, [x2]
    5cfc:	f9000fe3 	str	x3, [sp, #24]
    5d00:	d2800003 	mov	x3, #0x0                   	// #0
    5d04:	a9400c01 	ldp	x1, x3, [x0]
    5d08:	f9400802 	ldr	x2, [x0, #16]
    5d0c:	ab020022 	adds	x2, x1, x2
    5d10:	540006e6 	b.vs	5dec <fwp_owned_entry173+0x10c>
    5d14:	910023e1 	add	x1, sp, #0x8
    5d18:	52800000 	mov	w0, #0x0                   	// #0
    5d1c:	a9008be3 	stp	x3, x2, [sp, #8]
    5d20:	97fffcb5 	bl	4ff4 <fwp_data.part.0.constprop.0>
    5d24:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5d28:	91170063 	add	x3, x3, #0x5c0
    5d2c:	aa0003f3 	mov	x19, x0
    5d30:	f949d861 	ldr	x1, [x3, #5040]
    5d34:	f949ec60 	ldr	x0, [x3, #5080]
    5d38:	cb010261 	sub	x1, x19, x1
    5d3c:	eb00403f 	cmp	x1, x0, lsl #16
    5d40:	54000322 	b.cs	5da4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5d44:	d350fc22 	lsr	x2, x1, #16
    5d48:	f949fc63 	ldr	x3, [x3, #5112]
    5d4c:	8b020842 	add	x2, x2, x2, lsl #2
    5d50:	d37df042 	lsl	x2, x2, #3
    5d54:	8b020060 	add	x0, x3, x2
    5d58:	f9401014 	ldr	x20, [x0, #32]
    5d5c:	b4000254 	cbz	x20, 5da4 <fwp_owned_entry173+0xc4>
    5d60:	38626862 	ldrb	w2, [x3, x2]
    5d64:	7100085f 	cmp	w2, #0x2
    5d68:	54000360 	b.eq	5dd4 <fwp_owned_entry173+0xf4>  // b.none
    5d6c:	7100045f 	cmp	w2, #0x1
    5d70:	540001a1 	b.ne	5da4 <fwp_owned_entry173+0xc4>  // b.any
    5d74:	29430002 	ldp	w2, w0, [x0, #24]
    5d78:	92403c21 	and	x1, x1, #0xffff
    5d7c:	9b027c21 	mul	x1, x1, x2
    5d80:	d360fc21 	lsr	x1, x1, #32
    5d84:	eb00003f 	cmp	x1, x0
    5d88:	540000e2 	b.cs	5da4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5d8c:	8b010294 	add	x20, x20, x1
    5d90:	39400280 	ldrb	w0, [x20]
    5d94:	7103fc1f 	cmp	w0, #0xff
    5d98:	54000240 	b.eq	5de0 <fwp_owned_entry173+0x100>  // b.none
    5d9c:	52800020 	mov	w0, #0x1                   	// #1
    5da0:	39000280 	strb	w0, [x20]
    5da4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    5da8:	f947f400 	ldr	x0, [x0, #4072]
    5dac:	f9400fe2 	ldr	x2, [sp, #24]
    5db0:	f9400001 	ldr	x1, [x0]
    5db4:	eb010042 	subs	x2, x2, x1
    5db8:	d2800001 	mov	x1, #0x0                   	// #0
    5dbc:	540001a1 	b.ne	5df0 <fwp_owned_entry173+0x110>  // b.any
    5dc0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5dc4:	aa1303e0 	mov	x0, x19
    5dc8:	a94353f3 	ldp	x19, x20, [sp, #48]
    5dcc:	910103ff 	add	sp, sp, #0x40
    5dd0:	d65f03c0 	ret
    5dd4:	72003c3f 	tst	w1, #0xffff
    5dd8:	54fffe61 	b.ne	5da4 <fwp_owned_entry173+0xc4>  // b.any
    5ddc:	17ffffed 	b	5d90 <fwp_owned_entry173+0xb0>
    5de0:	aa1403e0 	mov	x0, x20
    5de4:	97fff8e7 	bl	4180 <fwp_rc_forget_slot.part.0>
    5de8:	17ffffed 	b	5d9c <fwp_owned_entry173+0xbc>
    5dec:	97fff325 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5df0:	97fff2a8 	bl	2890 <__stack_chk_fail@plt>

0000000000005df4 <e173>:
    5df4:	d10103ff 	sub	sp, sp, #0x40
    5df8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    5dfc:	f947f442 	ldr	x2, [x2, #4072]
    5e00:	a9027bfd 	stp	x29, x30, [sp, #32]
    5e04:	910083fd 	add	x29, sp, #0x20
    5e08:	a90353f3 	stp	x19, x20, [sp, #48]
    5e0c:	f9400043 	ldr	x3, [x2]
    5e10:	f9000fe3 	str	x3, [sp, #24]
    5e14:	d2800003 	mov	x3, #0x0                   	// #0
    5e18:	a9400c01 	ldp	x1, x3, [x0]
    5e1c:	f9400802 	ldr	x2, [x0, #16]
    5e20:	ab020022 	adds	x2, x1, x2
    5e24:	54000726 	b.vs	5f08 <e173+0x114>
    5e28:	910023e1 	add	x1, sp, #0x8
    5e2c:	52800000 	mov	w0, #0x0                   	// #0
    5e30:	a9008be3 	stp	x3, x2, [sp, #8]
    5e34:	97fffc70 	bl	4ff4 <fwp_data.part.0.constprop.0>
    5e38:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5e3c:	91170063 	add	x3, x3, #0x5c0
    5e40:	aa0003f3 	mov	x19, x0
    5e44:	f949d861 	ldr	x1, [x3, #5040]
    5e48:	f949ec60 	ldr	x0, [x3, #5080]
    5e4c:	cb010261 	sub	x1, x19, x1
    5e50:	eb00403f 	cmp	x1, x0, lsl #16
    5e54:	54000322 	b.cs	5eb8 <e173+0xc4>  // b.hs, b.nlast
    5e58:	d350fc22 	lsr	x2, x1, #16
    5e5c:	f949fc63 	ldr	x3, [x3, #5112]
    5e60:	8b020842 	add	x2, x2, x2, lsl #2
    5e64:	d37df042 	lsl	x2, x2, #3
    5e68:	8b020060 	add	x0, x3, x2
    5e6c:	f9401014 	ldr	x20, [x0, #32]
    5e70:	b4000254 	cbz	x20, 5eb8 <e173+0xc4>
    5e74:	38626862 	ldrb	w2, [x3, x2]
    5e78:	7100085f 	cmp	w2, #0x2
    5e7c:	540003a0 	b.eq	5ef0 <e173+0xfc>  // b.none
    5e80:	7100045f 	cmp	w2, #0x1
    5e84:	540001a1 	b.ne	5eb8 <e173+0xc4>  // b.any
    5e88:	29430002 	ldp	w2, w0, [x0, #24]
    5e8c:	92403c21 	and	x1, x1, #0xffff
    5e90:	9b027c21 	mul	x1, x1, x2
    5e94:	d360fc21 	lsr	x1, x1, #32
    5e98:	eb00003f 	cmp	x1, x0
    5e9c:	540000e2 	b.cs	5eb8 <e173+0xc4>  // b.hs, b.nlast
    5ea0:	8b010294 	add	x20, x20, x1
    5ea4:	39400280 	ldrb	w0, [x20]
    5ea8:	7103fc1f 	cmp	w0, #0xff
    5eac:	54000280 	b.eq	5efc <e173+0x108>  // b.none
    5eb0:	52800020 	mov	w0, #0x1                   	// #1
    5eb4:	39000280 	strb	w0, [x20]
    5eb8:	aa1303e0 	mov	x0, x19
    5ebc:	97fffeed 	bl	5a70 <fwp_rc_share>
    5ec0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    5ec4:	f947f400 	ldr	x0, [x0, #4072]
    5ec8:	f9400fe2 	ldr	x2, [sp, #24]
    5ecc:	f9400001 	ldr	x1, [x0]
    5ed0:	eb010042 	subs	x2, x2, x1
    5ed4:	d2800001 	mov	x1, #0x0                   	// #0
    5ed8:	540001a1 	b.ne	5f0c <e173+0x118>  // b.any
    5edc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5ee0:	aa1303e0 	mov	x0, x19
    5ee4:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ee8:	910103ff 	add	sp, sp, #0x40
    5eec:	d65f03c0 	ret
    5ef0:	72003c3f 	tst	w1, #0xffff
    5ef4:	54fffe21 	b.ne	5eb8 <e173+0xc4>  // b.any
    5ef8:	17ffffeb 	b	5ea4 <e173+0xb0>
    5efc:	aa1403e0 	mov	x0, x20
    5f00:	97fff8a0 	bl	4180 <fwp_rc_forget_slot.part.0>
    5f04:	17ffffeb 	b	5eb0 <e173+0xbc>
    5f08:	97fff2de 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5f0c:	97fff261 	bl	2890 <__stack_chk_fail@plt>

0000000000005f10 <fwp_drop1>:
    5f10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f14:	910003fd 	mov	x29, sp
    5f18:	a90153f3 	stp	x19, x20, [sp, #16]
    5f1c:	f90013f5 	str	x21, [sp, #32]
    5f20:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    5f24:	911702b4 	add	x20, x21, #0x5c0
    5f28:	f949da81 	ldr	x1, [x20, #5040]
    5f2c:	f949ee82 	ldr	x2, [x20, #5080]
    5f30:	cb010001 	sub	x1, x0, x1
    5f34:	eb02403f 	cmp	x1, x2, lsl #16
    5f38:	54000382 	b.cs	5fa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f3c:	d350fc22 	lsr	x2, x1, #16
    5f40:	f949fe84 	ldr	x4, [x20, #5112]
    5f44:	8b020842 	add	x2, x2, x2, lsl #2
    5f48:	d37df042 	lsl	x2, x2, #3
    5f4c:	8b020083 	add	x3, x4, x2
    5f50:	f9401073 	ldr	x19, [x3, #32]
    5f54:	b40002b3 	cbz	x19, 5fa8 <fwp_drop1+0x98>
    5f58:	38626882 	ldrb	w2, [x4, x2]
    5f5c:	7100085f 	cmp	w2, #0x2
    5f60:	540002c0 	b.eq	5fb8 <fwp_drop1+0xa8>  // b.none
    5f64:	7100045f 	cmp	w2, #0x1
    5f68:	54000201 	b.ne	5fa8 <fwp_drop1+0x98>  // b.any
    5f6c:	29430864 	ldp	w4, w2, [x3, #24]
    5f70:	92403c21 	and	x1, x1, #0xffff
    5f74:	9b047c21 	mul	x1, x1, x4
    5f78:	d360fc21 	lsr	x1, x1, #32
    5f7c:	eb02003f 	cmp	x1, x2
    5f80:	54000142 	b.cs	5fa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f84:	8b010273 	add	x19, x19, x1
    5f88:	39400261 	ldrb	w1, [x19]
    5f8c:	340000e1 	cbz	w1, 5fa8 <fwp_drop1+0x98>
    5f90:	7100043f 	cmp	w1, #0x1
    5f94:	540001e0 	b.eq	5fd0 <fwp_drop1+0xc0>  // b.none
    5f98:	7103fc3f 	cmp	w1, #0xff
    5f9c:	540002e0 	b.eq	5ff8 <fwp_drop1+0xe8>  // b.none
    5fa0:	51000421 	sub	w1, w1, #0x1
    5fa4:	39000261 	strb	w1, [x19]
    5fa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fac:	f94013f5 	ldr	x21, [sp, #32]
    5fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fb4:	d65f03c0 	ret
    5fb8:	72003c3f 	tst	w1, #0xffff
    5fbc:	54fffe60 	b.eq	5f88 <fwp_drop1+0x78>  // b.none
    5fc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fc4:	f94013f5 	ldr	x21, [sp, #32]
    5fc8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fcc:	d65f03c0 	ret
    5fd0:	f9400813 	ldr	x19, [x0, #16]
    5fd4:	97fffefb 	bl	5bc0 <fwp_rc_free_arr>
    5fd8:	911702a0 	add	x0, x21, #0x5c0
    5fdc:	f949d801 	ldr	x1, [x0, #5040]
    5fe0:	f949ec00 	ldr	x0, [x0, #5080]
    5fe4:	cb010261 	sub	x1, x19, x1
    5fe8:	eb00403f 	cmp	x1, x0, lsl #16
    5fec:	54fffde2 	b.cs	5fa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ff0:	aa1303e0 	mov	x0, x19
    5ff4:	17ffffd2 	b	5f3c <fwp_drop1+0x2c>
    5ff8:	ca534660 	eor	x0, x19, x19, lsr #17
    5ffc:	911702b5 	add	x21, x21, #0x5c0
    6000:	ca402400 	eor	x0, x0, x0, lsr #9
    6004:	92401c00 	and	x0, x0, #0xff
    6008:	910a2402 	add	x2, x0, #0x289
    600c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6010:	8b020ea2 	add	x2, x21, x2, lsl #3
    6014:	f94a2400 	ldr	x0, [x0, #5192]
    6018:	b50000a0 	cbnz	x0, 602c <fwp_drop1+0x11c>
    601c:	14000013 	b	6068 <fwp_drop1+0x158>
    6020:	91004002 	add	x2, x0, #0x10
    6024:	f9400800 	ldr	x0, [x0, #16]
    6028:	b4000200 	cbz	x0, 6068 <fwp_drop1+0x158>
    602c:	f9400001 	ldr	x1, [x0]
    6030:	eb13003f 	cmp	x1, x19
    6034:	54ffff61 	b.ne	6020 <fwp_drop1+0x110>  // b.any
    6038:	f9400041 	ldr	x1, [x2]
    603c:	f9400420 	ldr	x0, [x1, #8]
    6040:	d1000400 	sub	x0, x0, #0x1
    6044:	f9000420 	str	x0, [x1, #8]
    6048:	f103f81f 	cmp	x0, #0xfe
    604c:	54fffae1 	b.ne	5fa8 <fwp_drop1+0x98>  // b.any
    6050:	39400260 	ldrb	w0, [x19]
    6054:	7103fc1f 	cmp	w0, #0xff
    6058:	540000e0 	b.eq	6074 <fwp_drop1+0x164>  // b.none
    605c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6060:	39000260 	strb	w0, [x19]
    6064:	17ffffd1 	b	5fa8 <fwp_drop1+0x98>
    6068:	f0000020 	adrp	x0, d000 <__divti3+0x2a0>
    606c:	9119e000 	add	x0, x0, #0x678
    6070:	97fff824 	bl	4100 <fwp_trap>
    6074:	aa1303e0 	mov	x0, x19
    6078:	97fff842 	bl	4180 <fwp_rc_forget_slot.part.0>
    607c:	17fffff8 	b	605c <fwp_drop1+0x14c>

0000000000006080 <fwp_drop0>:
    6080:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6084:	910003fd 	mov	x29, sp
    6088:	a90153f3 	stp	x19, x20, [sp, #16]
    608c:	f90013f5 	str	x21, [sp, #32]
    6090:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xc20>
    6094:	911702b4 	add	x20, x21, #0x5c0
    6098:	f949da81 	ldr	x1, [x20, #5040]
    609c:	f949ee82 	ldr	x2, [x20, #5080]
    60a0:	cb010001 	sub	x1, x0, x1
    60a4:	eb02403f 	cmp	x1, x2, lsl #16
    60a8:	54000382 	b.cs	6118 <fwp_drop0+0x98>  // b.hs, b.nlast
    60ac:	d350fc22 	lsr	x2, x1, #16
    60b0:	f949fe84 	ldr	x4, [x20, #5112]
    60b4:	8b020842 	add	x2, x2, x2, lsl #2
    60b8:	d37df042 	lsl	x2, x2, #3
    60bc:	8b020083 	add	x3, x4, x2
    60c0:	f9401073 	ldr	x19, [x3, #32]
    60c4:	b40002b3 	cbz	x19, 6118 <fwp_drop0+0x98>
    60c8:	38626882 	ldrb	w2, [x4, x2]
    60cc:	7100085f 	cmp	w2, #0x2
    60d0:	540002c0 	b.eq	6128 <fwp_drop0+0xa8>  // b.none
    60d4:	7100045f 	cmp	w2, #0x1
    60d8:	54000201 	b.ne	6118 <fwp_drop0+0x98>  // b.any
    60dc:	29430864 	ldp	w4, w2, [x3, #24]
    60e0:	92403c21 	and	x1, x1, #0xffff
    60e4:	9b047c21 	mul	x1, x1, x4
    60e8:	d360fc21 	lsr	x1, x1, #32
    60ec:	eb02003f 	cmp	x1, x2
    60f0:	54000142 	b.cs	6118 <fwp_drop0+0x98>  // b.hs, b.nlast
    60f4:	8b010273 	add	x19, x19, x1
    60f8:	39400261 	ldrb	w1, [x19]
    60fc:	340000e1 	cbz	w1, 6118 <fwp_drop0+0x98>
    6100:	7100043f 	cmp	w1, #0x1
    6104:	540001e0 	b.eq	6140 <fwp_drop0+0xc0>  // b.none
    6108:	7103fc3f 	cmp	w1, #0xff
    610c:	540002e0 	b.eq	6168 <fwp_drop0+0xe8>  // b.none
    6110:	51000421 	sub	w1, w1, #0x1
    6114:	39000261 	strb	w1, [x19]
    6118:	a94153f3 	ldp	x19, x20, [sp, #16]
    611c:	f94013f5 	ldr	x21, [sp, #32]
    6120:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6124:	d65f03c0 	ret
    6128:	72003c3f 	tst	w1, #0xffff
    612c:	54fffe60 	b.eq	60f8 <fwp_drop0+0x78>  // b.none
    6130:	a94153f3 	ldp	x19, x20, [sp, #16]
    6134:	f94013f5 	ldr	x21, [sp, #32]
    6138:	a8c37bfd 	ldp	x29, x30, [sp], #48
    613c:	d65f03c0 	ret
    6140:	f9400813 	ldr	x19, [x0, #16]
    6144:	97fffe9f 	bl	5bc0 <fwp_rc_free_arr>
    6148:	911702a0 	add	x0, x21, #0x5c0
    614c:	f949d801 	ldr	x1, [x0, #5040]
    6150:	f949ec00 	ldr	x0, [x0, #5080]
    6154:	cb010261 	sub	x1, x19, x1
    6158:	eb00403f 	cmp	x1, x0, lsl #16
    615c:	54fffde2 	b.cs	6118 <fwp_drop0+0x98>  // b.hs, b.nlast
    6160:	aa1303e0 	mov	x0, x19
    6164:	17ffffd2 	b	60ac <fwp_drop0+0x2c>
    6168:	ca534660 	eor	x0, x19, x19, lsr #17
    616c:	911702b5 	add	x21, x21, #0x5c0
    6170:	ca402400 	eor	x0, x0, x0, lsr #9
    6174:	92401c00 	and	x0, x0, #0xff
    6178:	910a2402 	add	x2, x0, #0x289
    617c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6180:	8b020ea2 	add	x2, x21, x2, lsl #3
    6184:	f94a2400 	ldr	x0, [x0, #5192]
    6188:	b50000a0 	cbnz	x0, 619c <fwp_drop0+0x11c>
    618c:	14000013 	b	61d8 <fwp_drop0+0x158>
    6190:	91004002 	add	x2, x0, #0x10
    6194:	f9400800 	ldr	x0, [x0, #16]
    6198:	b4000200 	cbz	x0, 61d8 <fwp_drop0+0x158>
    619c:	f9400001 	ldr	x1, [x0]
    61a0:	eb13003f 	cmp	x1, x19
    61a4:	54ffff61 	b.ne	6190 <fwp_drop0+0x110>  // b.any
    61a8:	f9400041 	ldr	x1, [x2]
    61ac:	f9400420 	ldr	x0, [x1, #8]
    61b0:	d1000400 	sub	x0, x0, #0x1
    61b4:	f9000420 	str	x0, [x1, #8]
    61b8:	f103f81f 	cmp	x0, #0xfe
    61bc:	54fffae1 	b.ne	6118 <fwp_drop0+0x98>  // b.any
    61c0:	39400260 	ldrb	w0, [x19]
    61c4:	7103fc1f 	cmp	w0, #0xff
    61c8:	540000e0 	b.eq	61e4 <fwp_drop0+0x164>  // b.none
    61cc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    61d0:	39000260 	strb	w0, [x19]
    61d4:	17ffffd1 	b	6118 <fwp_drop0+0x98>
    61d8:	f0000020 	adrp	x0, d000 <__divti3+0x2a0>
    61dc:	9119e000 	add	x0, x0, #0x678
    61e0:	97fff7c8 	bl	4100 <fwp_trap>
    61e4:	aa1303e0 	mov	x0, x19
    61e8:	97fff7e6 	bl	4180 <fwp_rc_forget_slot.part.0>
    61ec:	17fffff8 	b	61cc <fwp_drop0+0x14c>

00000000000061f0 <fwp_closure_drop>:
    61f0:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc20>
    61f4:	911700a4 	add	x4, x5, #0x5c0
    61f8:	aa0003e1 	mov	x1, x0
    61fc:	f949d882 	ldr	x2, [x4, #5040]
    6200:	f949ec80 	ldr	x0, [x4, #5080]
    6204:	cb020022 	sub	x2, x1, x2
    6208:	eb00405f 	cmp	x2, x0, lsl #16
    620c:	54000662 	b.cs	62d8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6210:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6214:	d350fc43 	lsr	x3, x2, #16
    6218:	910003fd 	mov	x29, sp
    621c:	8b030863 	add	x3, x3, x3, lsl #2
    6220:	f949fc84 	ldr	x4, [x4, #5112]
    6224:	d37df063 	lsl	x3, x3, #3
    6228:	f9000bf3 	str	x19, [sp, #16]
    622c:	8b030080 	add	x0, x4, x3
    6230:	f9401013 	ldr	x19, [x0, #32]
    6234:	b40002b3 	cbz	x19, 6288 <fwp_closure_drop+0x98>
    6238:	38636883 	ldrb	w3, [x4, x3]
    623c:	7100087f 	cmp	w3, #0x2
    6240:	54000420 	b.eq	62c4 <fwp_closure_drop+0xd4>  // b.none
    6244:	7100047f 	cmp	w3, #0x1
    6248:	54000201 	b.ne	6288 <fwp_closure_drop+0x98>  // b.any
    624c:	29430003 	ldp	w3, w0, [x0, #24]
    6250:	92403c42 	and	x2, x2, #0xffff
    6254:	9b037c42 	mul	x2, x2, x3
    6258:	d360fc42 	lsr	x2, x2, #32
    625c:	eb00005f 	cmp	x2, x0
    6260:	54000142 	b.cs	6288 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6264:	8b020273 	add	x19, x19, x2
    6268:	39400260 	ldrb	w0, [x19]
    626c:	340000e0 	cbz	w0, 6288 <fwp_closure_drop+0x98>
    6270:	7100041f 	cmp	w0, #0x1
    6274:	54000100 	b.eq	6294 <fwp_closure_drop+0xa4>  // b.none
    6278:	7103fc1f 	cmp	w0, #0xff
    627c:	54000300 	b.eq	62dc <fwp_closure_drop+0xec>  // b.none
    6280:	51000400 	sub	w0, w0, #0x1
    6284:	39000260 	strb	w0, [x19]
    6288:	f9400bf3 	ldr	x19, [sp, #16]
    628c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6290:	d65f03c0 	ret
    6294:	d53bd040 	mrs	x0, tpidr_el0
    6298:	91400000 	add	x0, x0, #0x0, lsl #12
    629c:	91004000 	add	x0, x0, #0x10
    62a0:	f9400000 	ldr	x0, [x0]
    62a4:	b4000080 	cbz	x0, 62b4 <fwp_closure_drop+0xc4>
    62a8:	f9400bf3 	ldr	x19, [sp, #16]
    62ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62b0:	17fff910 	b	46f0 <fwp_closure_drop_push>
    62b4:	f9400bf3 	ldr	x19, [sp, #16]
    62b8:	aa0103e0 	mov	x0, x1
    62bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62c0:	17fff951 	b	4804 <fwp_closure_drop.part.0>
    62c4:	72003c5f 	tst	w2, #0xffff
    62c8:	54fffd00 	b.eq	6268 <fwp_closure_drop+0x78>  // b.none
    62cc:	f9400bf3 	ldr	x19, [sp, #16]
    62d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62d4:	d65f03c0 	ret
    62d8:	d65f03c0 	ret
    62dc:	ca534660 	eor	x0, x19, x19, lsr #17
    62e0:	911700a5 	add	x5, x5, #0x5c0
    62e4:	ca402400 	eor	x0, x0, x0, lsr #9
    62e8:	92401c00 	and	x0, x0, #0xff
    62ec:	910a2402 	add	x2, x0, #0x289
    62f0:	8b000ca0 	add	x0, x5, x0, lsl #3
    62f4:	8b020ca2 	add	x2, x5, x2, lsl #3
    62f8:	f94a2400 	ldr	x0, [x0, #5192]
    62fc:	b50000a0 	cbnz	x0, 6310 <fwp_closure_drop+0x120>
    6300:	14000013 	b	634c <fwp_closure_drop+0x15c>
    6304:	91004002 	add	x2, x0, #0x10
    6308:	f9400800 	ldr	x0, [x0, #16]
    630c:	b4000200 	cbz	x0, 634c <fwp_closure_drop+0x15c>
    6310:	f9400001 	ldr	x1, [x0]
    6314:	eb13003f 	cmp	x1, x19
    6318:	54ffff61 	b.ne	6304 <fwp_closure_drop+0x114>  // b.any
    631c:	f9400041 	ldr	x1, [x2]
    6320:	f9400420 	ldr	x0, [x1, #8]
    6324:	d1000400 	sub	x0, x0, #0x1
    6328:	f9000420 	str	x0, [x1, #8]
    632c:	f103f81f 	cmp	x0, #0xfe
    6330:	54fffac1 	b.ne	6288 <fwp_closure_drop+0x98>  // b.any
    6334:	39400260 	ldrb	w0, [x19]
    6338:	7103fc1f 	cmp	w0, #0xff
    633c:	540000e0 	b.eq	6358 <fwp_closure_drop+0x168>  // b.none
    6340:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6344:	39000260 	strb	w0, [x19]
    6348:	17ffffd0 	b	6288 <fwp_closure_drop+0x98>
    634c:	f0000020 	adrp	x0, d000 <__divti3+0x2a0>
    6350:	9119e000 	add	x0, x0, #0x678
    6354:	97fff76b 	bl	4100 <fwp_trap>
    6358:	aa1303e0 	mov	x0, x19
    635c:	97fff789 	bl	4180 <fwp_rc_forget_slot.part.0>
    6360:	17fffff8 	b	6340 <fwp_closure_drop+0x150>

0000000000006364 <fwp_owned_tape_release>:
    6364:	b4000920 	cbz	x0, 6488 <fwp_owned_tape_release+0x124>
    6368:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    636c:	910003fd 	mov	x29, sp
    6370:	a90153f3 	stp	x19, x20, [sp, #16]
    6374:	aa0003f3 	mov	x19, x0
    6378:	f9400000 	ldr	x0, [x0]
    637c:	b4000060 	cbz	x0, 6388 <fwp_owned_tape_release+0x24>
    6380:	f9400661 	ldr	x1, [x19, #8]
    6384:	f9000401 	str	x1, [x0, #8]
    6388:	f9400661 	ldr	x1, [x19, #8]
    638c:	b4000041 	cbz	x1, 6394 <fwp_owned_tape_release+0x30>
    6390:	f9000020 	str	x0, [x1]
    6394:	f9400a60 	ldr	x0, [x19, #16]
    6398:	f9403401 	ldr	x1, [x0, #104]
    639c:	b40005a1 	cbz	x1, 6450 <fwp_owned_tape_release+0xec>
    63a0:	a9450a60 	ldp	x0, x2, [x19, #80]
    63a4:	eb00005f 	cmp	x2, x0
    63a8:	540002cd 	b.le	6400 <fwp_owned_tape_release+0x9c>
    63ac:	d2800014 	mov	x20, #0x0                   	// #0
    63b0:	f90013f5 	str	x21, [sp, #32]
    63b4:	d2800015 	mov	x21, #0x0                   	// #0
    63b8:	f9402260 	ldr	x0, [x19, #64]
    63bc:	910006b5 	add	x21, x21, #0x1
    63c0:	f8746800 	ldr	x0, [x0, x20]
    63c4:	d63f0020 	blr	x1
    63c8:	f9402260 	ldr	x0, [x19, #64]
    63cc:	f9400a61 	ldr	x1, [x19, #16]
    63d0:	8b140000 	add	x0, x0, x20
    63d4:	91004294 	add	x20, x20, #0x10
    63d8:	f9400400 	ldr	x0, [x0, #8]
    63dc:	f9403421 	ldr	x1, [x1, #104]
    63e0:	d63f0020 	blr	x1
    63e4:	a9450261 	ldp	x1, x0, [x19, #80]
    63e8:	cb010000 	sub	x0, x0, x1
    63ec:	eb15001f 	cmp	x0, x21
    63f0:	f9400a60 	ldr	x0, [x19, #16]
    63f4:	f9403401 	ldr	x1, [x0, #104]
    63f8:	54fffe0c 	b.gt	63b8 <fwp_owned_tape_release+0x54>
    63fc:	f94013f5 	ldr	x21, [sp, #32]
    6400:	f9403663 	ldr	x3, [x19, #104]
    6404:	f9401262 	ldr	x2, [x19, #32]
    6408:	f100007f 	cmp	x3, #0x0
    640c:	540001ed 	b.le	6448 <fwp_owned_tape_release+0xe4>
    6410:	d2800014 	mov	x20, #0x0                   	// #0
    6414:	d503201f 	nop
    6418:	f9402660 	ldr	x0, [x19, #72]
    641c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6420:	eb02001f 	cmp	x0, x2
    6424:	540000c0 	b.eq	643c <fwp_owned_tape_release+0xd8>  // b.none
    6428:	d63f0020 	blr	x1
    642c:	f9400a60 	ldr	x0, [x19, #16]
    6430:	f9401262 	ldr	x2, [x19, #32]
    6434:	f9403663 	ldr	x3, [x19, #104]
    6438:	f9403401 	ldr	x1, [x0, #104]
    643c:	91000694 	add	x20, x20, #0x1
    6440:	eb14007f 	cmp	x3, x20
    6444:	54fffeac 	b.gt	6418 <fwp_owned_tape_release+0xb4>
    6448:	aa0203e0 	mov	x0, x2
    644c:	d63f0020 	blr	x1
    6450:	f9401660 	ldr	x0, [x19, #40]
    6454:	97ffff67 	bl	61f0 <fwp_closure_drop>
    6458:	f9401a60 	ldr	x0, [x19, #48]
    645c:	97ffff65 	bl	61f0 <fwp_closure_drop>
    6460:	f9401e60 	ldr	x0, [x19, #56]
    6464:	97ffff63 	bl	61f0 <fwp_closure_drop>
    6468:	f9402260 	ldr	x0, [x19, #64]
    646c:	97fff7e1 	bl	43f0 <fwp_mem_free>
    6470:	f9402660 	ldr	x0, [x19, #72]
    6474:	97fff7df 	bl	43f0 <fwp_mem_free>
    6478:	aa1303e0 	mov	x0, x19
    647c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6480:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6484:	17fff7db 	b	43f0 <fwp_mem_free>
    6488:	d65f03c0 	ret
    648c:	d503201f 	nop

0000000000006490 <fwp_tape_finish>:
    6490:	d101c3ff 	sub	sp, sp, #0x70
    6494:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    6498:	f947f421 	ldr	x1, [x1, #4072]
    649c:	a9037bfd 	stp	x29, x30, [sp, #48]
    64a0:	9100c3fd 	add	x29, sp, #0x30
    64a4:	a90453f3 	stp	x19, x20, [sp, #64]
    64a8:	a9055bf5 	stp	x21, x22, [sp, #80]
    64ac:	a90663f7 	stp	x23, x24, [sp, #96]
    64b0:	d00000d8 	adrp	x24, 20000 <__data_start>
    64b4:	9101c316 	add	x22, x24, #0x70
    64b8:	f9400022 	ldr	x2, [x1]
    64bc:	f90017e2 	str	x2, [sp, #40]
    64c0:	d2800002 	mov	x2, #0x0                   	// #0
    64c4:	910222c0 	add	x0, x22, #0x88
    64c8:	97fff3ee 	bl	3480 <fwp_tape_buffers_dispose>
    64cc:	f9005adf 	str	xzr, [x22, #176]
    64d0:	f94062c0 	ldr	x0, [x22, #192]
    64d4:	f100001f 	cmp	x0, #0x0
    64d8:	540002cd 	b.le	6530 <fwp_tape_finish+0xa0>
    64dc:	910003f7 	mov	x23, sp
    64e0:	d2800015 	mov	x21, #0x0                   	// #0
    64e4:	d2800014 	mov	x20, #0x0                   	// #0
    64e8:	f94002d3 	ldr	x19, [x22]
    64ec:	91000694 	add	x20, x20, #0x1
    64f0:	8b150273 	add	x19, x19, x21
    64f4:	910162b5 	add	x21, x21, #0x58
    64f8:	aa1303e0 	mov	x0, x19
    64fc:	97fff2a5 	bl	2f90 <fwp_tape_unlink_scope>
    6500:	aa1703e0 	mov	x0, x23
    6504:	3dc00a60 	ldr	q0, [x19, #32]
    6508:	f9401a61 	ldr	x1, [x19, #48]
    650c:	f9000be1 	str	x1, [sp, #16]
    6510:	3d8003e0 	str	q0, [sp]
    6514:	97fff3db 	bl	3480 <fwp_tape_buffers_dispose>
    6518:	f9402a60 	ldr	x0, [x19, #80]
    651c:	97ffff92 	bl	6364 <fwp_owned_tape_release>
    6520:	f9002a7f 	str	xzr, [x19, #80]
    6524:	f94062c0 	ldr	x0, [x22, #192]
    6528:	eb14001f 	cmp	x0, x20
    652c:	54fffdec 	b.gt	64e8 <fwp_tape_finish+0x58>
    6530:	f9403b00 	ldr	x0, [x24, #112]
    6534:	9101c313 	add	x19, x24, #0x70
    6538:	97fff106 	bl	2950 <free@plt>
    653c:	f9003b1f 	str	xzr, [x24, #112]
    6540:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    6544:	f947f400 	ldr	x0, [x0, #4072]
    6548:	f900627f 	str	xzr, [x19, #192]
    654c:	a90d7e7f 	stp	xzr, xzr, [x19, #208]
    6550:	f94017e2 	ldr	x2, [sp, #40]
    6554:	f9400001 	ldr	x1, [x0]
    6558:	eb010042 	subs	x2, x2, x1
    655c:	d2800001 	mov	x1, #0x0                   	// #0
    6560:	540000e1 	b.ne	657c <fwp_tape_finish+0xec>  // b.any
    6564:	a9437bfd 	ldp	x29, x30, [sp, #48]
    6568:	a94453f3 	ldp	x19, x20, [sp, #64]
    656c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    6570:	a94663f7 	ldp	x23, x24, [sp, #96]
    6574:	9101c3ff 	add	sp, sp, #0x70
    6578:	d65f03c0 	ret
    657c:	97fff0c5 	bl	2890 <__stack_chk_fail@plt>

0000000000006580 <fwp_tape_scope_release>:
    6580:	d10203ff 	sub	sp, sp, #0x80
    6584:	a9037bfd 	stp	x29, x30, [sp, #48]
    6588:	9100c3fd 	add	x29, sp, #0x30
    658c:	a90453f3 	stp	x19, x20, [sp, #64]
    6590:	aa0003f4 	mov	x20, x0
    6594:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    6598:	f947f400 	ldr	x0, [x0, #4072]
    659c:	b9400285 	ldr	w5, [x20]
    65a0:	f9400001 	ldr	x1, [x0]
    65a4:	f90017e1 	str	x1, [sp, #40]
    65a8:	d2800001 	mov	x1, #0x0                   	// #0
    65ac:	37f806e5 	tbnz	w5, #31, 6688 <fwp_tape_scope_release+0x108>
    65b0:	a90663f7 	stp	x23, x24, [sp, #96]
    65b4:	d2917478 	mov	x24, #0x8ba3                	// #35747
    65b8:	f2b745d8 	movk	x24, #0xba2e, lsl #16
    65bc:	f2d45d18 	movk	x24, #0xa2e8, lsl #32
    65c0:	d00000d3 	adrp	x19, 20000 <__data_start>
    65c4:	910003f7 	mov	x23, sp
    65c8:	9101c273 	add	x19, x19, #0x70
    65cc:	f2e5d178 	movk	x24, #0x2e8b, lsl #48
    65d0:	a9055bf5 	stp	x21, x22, [sp, #80]
    65d4:	52800b16 	mov	w22, #0x58                  	// #88
    65d8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    65dc:	f9003bf9 	str	x25, [sp, #112]
    65e0:	14000006 	b	65f8 <fwp_tape_scope_release+0x78>
    65e4:	97fff3a7 	bl	3480 <fwp_tape_buffers_dispose>
    65e8:	aa1903e0 	mov	x0, x25
    65ec:	97ffff5e 	bl	6364 <fwp_owned_tape_release>
    65f0:	b9400285 	ldr	w5, [x20]
    65f4:	37f80445 	tbnz	w5, #31, 667c <fwp_tape_scope_release+0xfc>
    65f8:	f9400266 	ldr	x6, [x19]
    65fc:	9b367ca5 	smull	x5, w5, w22
    6600:	8b0500c0 	add	x0, x6, x5
    6604:	97fff263 	bl	2f90 <fwp_tape_unlink_scope>
    6608:	3dc00800 	ldr	q0, [x0, #32]
    660c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6610:	f9400c03 	ldr	x3, [x0, #24]
    6614:	3d8003e0 	str	q0, [sp]
    6618:	b86568c1 	ldr	w1, [x6, x5]
    661c:	f9401802 	ldr	x2, [x0, #48]
    6620:	a9010fe2 	stp	x2, x3, [sp, #16]
    6624:	f9401c02 	ldr	x2, [x0, #56]
    6628:	b900041f 	str	wzr, [x0, #4]
    662c:	f9402819 	ldr	x25, [x0, #80]
    6630:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6634:	f9000c1f 	str	xzr, [x0, #24]
    6638:	f90013e2 	str	x2, [sp, #32]
    663c:	f900181f 	str	xzr, [x0, #48]
    6640:	f9001c1f 	str	xzr, [x0, #56]
    6644:	f900281f 	str	xzr, [x0, #80]
    6648:	6b15003f 	cmp	w1, w21
    664c:	540000e8 	b.hi	6668 <fwp_tape_scope_release+0xe8>  // b.pmore
    6650:	9343fca5 	asr	x5, x5, #3
    6654:	f9406e60 	ldr	x0, [x19, #216]
    6658:	9b187ca5 	mul	x5, x5, x24
    665c:	eb0000bf 	cmp	x5, x0
    6660:	5400004a 	b.ge	6668 <fwp_tape_scope_release+0xe8>  // b.tcont
    6664:	f9006e65 	str	x5, [x19, #216]
    6668:	aa1703e0 	mov	x0, x23
    666c:	b5fffbd9 	cbnz	x25, 65e4 <fwp_tape_scope_release+0x64>
    6670:	97fff660 	bl	3ff0 <fwp_tape_buffers_release>
    6674:	b9400285 	ldr	w5, [x20]
    6678:	36fffc05 	tbz	w5, #31, 65f8 <fwp_tape_scope_release+0x78>
    667c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    6680:	a94663f7 	ldp	x23, x24, [sp, #96]
    6684:	f9403bf9 	ldr	x25, [sp, #112]
    6688:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    668c:	f947f400 	ldr	x0, [x0, #4072]
    6690:	f94017e2 	ldr	x2, [sp, #40]
    6694:	f9400001 	ldr	x1, [x0]
    6698:	eb010042 	subs	x2, x2, x1
    669c:	d2800001 	mov	x1, #0x0                   	// #0
    66a0:	540000a1 	b.ne	66b4 <fwp_tape_scope_release+0x134>  // b.any
    66a4:	a9437bfd 	ldp	x29, x30, [sp, #48]
    66a8:	a94453f3 	ldp	x19, x20, [sp, #64]
    66ac:	910203ff 	add	sp, sp, #0x80
    66b0:	d65f03c0 	ret
    66b4:	a9055bf5 	stp	x21, x22, [sp, #80]
    66b8:	a90663f7 	stp	x23, x24, [sp, #96]
    66bc:	f9003bf9 	str	x25, [sp, #112]
    66c0:	97fff074 	bl	2890 <__stack_chk_fail@plt>

00000000000066c4 <fwp_drop4>:
    66c4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    66c8:	910003fd 	mov	x29, sp
    66cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    66d0:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc20>
    66d4:	911702d5 	add	x21, x22, #0x5c0
    66d8:	a90153f3 	stp	x19, x20, [sp, #16]
    66dc:	aa0003f3 	mov	x19, x0
    66e0:	f949daa1 	ldr	x1, [x21, #5040]
    66e4:	f949eea0 	ldr	x0, [x21, #5080]
    66e8:	cb010261 	sub	x1, x19, x1
    66ec:	eb00403f 	cmp	x1, x0, lsl #16
    66f0:	54000382 	b.cs	6760 <fwp_drop4+0x9c>  // b.hs, b.nlast
    66f4:	d350fc22 	lsr	x2, x1, #16
    66f8:	f949fea3 	ldr	x3, [x21, #5112]
    66fc:	8b020842 	add	x2, x2, x2, lsl #2
    6700:	d37df042 	lsl	x2, x2, #3
    6704:	8b020060 	add	x0, x3, x2
    6708:	f9401014 	ldr	x20, [x0, #32]
    670c:	b40002b4 	cbz	x20, 6760 <fwp_drop4+0x9c>
    6710:	38626862 	ldrb	w2, [x3, x2]
    6714:	7100085f 	cmp	w2, #0x2
    6718:	540002c0 	b.eq	6770 <fwp_drop4+0xac>  // b.none
    671c:	7100045f 	cmp	w2, #0x1
    6720:	54000201 	b.ne	6760 <fwp_drop4+0x9c>  // b.any
    6724:	29430002 	ldp	w2, w0, [x0, #24]
    6728:	92403c21 	and	x1, x1, #0xffff
    672c:	9b027c21 	mul	x1, x1, x2
    6730:	d360fc21 	lsr	x1, x1, #32
    6734:	eb00003f 	cmp	x1, x0
    6738:	54000142 	b.cs	6760 <fwp_drop4+0x9c>  // b.hs, b.nlast
    673c:	8b010294 	add	x20, x20, x1
    6740:	39400280 	ldrb	w0, [x20]
    6744:	340000e0 	cbz	w0, 6760 <fwp_drop4+0x9c>
    6748:	7100041f 	cmp	w0, #0x1
    674c:	540001e0 	b.eq	6788 <fwp_drop4+0xc4>  // b.none
    6750:	7103fc1f 	cmp	w0, #0xff
    6754:	540007e0 	b.eq	6850 <fwp_drop4+0x18c>  // b.none
    6758:	51000400 	sub	w0, w0, #0x1
    675c:	39000280 	strb	w0, [x20]
    6760:	a94153f3 	ldp	x19, x20, [sp, #16]
    6764:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6768:	a8c37bfd 	ldp	x29, x30, [sp], #48
    676c:	d65f03c0 	ret
    6770:	72003c3f 	tst	w1, #0xffff
    6774:	54fffe60 	b.eq	6740 <fwp_drop4+0x7c>  // b.none
    6778:	a94153f3 	ldp	x19, x20, [sp, #16]
    677c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6780:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6784:	d65f03c0 	ret
    6788:	911702c2 	add	x2, x22, #0x5c0
    678c:	f9400660 	ldr	x0, [x19, #8]
    6790:	f949d841 	ldr	x1, [x2, #5040]
    6794:	f949ec42 	ldr	x2, [x2, #5080]
    6798:	cb010001 	sub	x1, x0, x1
    679c:	eb02403f 	cmp	x1, x2, lsl #16
    67a0:	54000382 	b.cs	6810 <fwp_drop4+0x14c>  // b.hs, b.nlast
    67a4:	d350fc22 	lsr	x2, x1, #16
    67a8:	8b020842 	add	x2, x2, x2, lsl #2
    67ac:	d37df042 	lsl	x2, x2, #3
    67b0:	8b020064 	add	x4, x3, x2
    67b4:	f9401094 	ldr	x20, [x4, #32]
    67b8:	b40002d4 	cbz	x20, 6810 <fwp_drop4+0x14c>
    67bc:	38626862 	ldrb	w2, [x3, x2]
    67c0:	7100085f 	cmp	w2, #0x2
    67c4:	54000400 	b.eq	6844 <fwp_drop4+0x180>  // b.none
    67c8:	7100045f 	cmp	w2, #0x1
    67cc:	54000221 	b.ne	6810 <fwp_drop4+0x14c>  // b.any
    67d0:	29430883 	ldp	w3, w2, [x4, #24]
    67d4:	92403c21 	and	x1, x1, #0xffff
    67d8:	9b037c21 	mul	x1, x1, x3
    67dc:	d360fc21 	lsr	x1, x1, #32
    67e0:	eb02003f 	cmp	x1, x2
    67e4:	54000162 	b.cs	6810 <fwp_drop4+0x14c>  // b.hs, b.nlast
    67e8:	8b010294 	add	x20, x20, x1
    67ec:	39400281 	ldrb	w1, [x20]
    67f0:	34000101 	cbz	w1, 6810 <fwp_drop4+0x14c>
    67f4:	7100043f 	cmp	w1, #0x1
    67f8:	54000220 	b.eq	683c <fwp_drop4+0x178>  // b.none
    67fc:	7103fc3f 	cmp	w1, #0xff
    6800:	54000660 	b.eq	68cc <fwp_drop4+0x208>  // b.none
    6804:	51000421 	sub	w1, w1, #0x1
    6808:	39000281 	strb	w1, [x20]
    680c:	d503201f 	nop
    6810:	f9400a74 	ldr	x20, [x19, #16]
    6814:	aa1303e0 	mov	x0, x19
    6818:	97fffcea 	bl	5bc0 <fwp_rc_free_arr>
    681c:	911702c0 	add	x0, x22, #0x5c0
    6820:	f949d801 	ldr	x1, [x0, #5040]
    6824:	f949ec00 	ldr	x0, [x0, #5080]
    6828:	cb010281 	sub	x1, x20, x1
    682c:	eb00403f 	cmp	x1, x0, lsl #16
    6830:	54fff982 	b.cs	6760 <fwp_drop4+0x9c>  // b.hs, b.nlast
    6834:	aa1403f3 	mov	x19, x20
    6838:	17ffffaf 	b	66f4 <fwp_drop4+0x30>
    683c:	97fffce1 	bl	5bc0 <fwp_rc_free_arr>
    6840:	17fffff4 	b	6810 <fwp_drop4+0x14c>
    6844:	72003c3f 	tst	w1, #0xffff
    6848:	54fffe41 	b.ne	6810 <fwp_drop4+0x14c>  // b.any
    684c:	17ffffe8 	b	67ec <fwp_drop4+0x128>
    6850:	ca544681 	eor	x1, x20, x20, lsr #17
    6854:	911702c0 	add	x0, x22, #0x5c0
    6858:	ca412421 	eor	x1, x1, x1, lsr #9
    685c:	92401c21 	and	x1, x1, #0xff
    6860:	910a2422 	add	x2, x1, #0x289
    6864:	8b010c01 	add	x1, x0, x1, lsl #3
    6868:	8b020c02 	add	x2, x0, x2, lsl #3
    686c:	f94a2420 	ldr	x0, [x1, #5192]
    6870:	b50000a0 	cbnz	x0, 6884 <fwp_drop4+0x1c0>
    6874:	14000013 	b	68c0 <fwp_drop4+0x1fc>
    6878:	91004002 	add	x2, x0, #0x10
    687c:	f9400800 	ldr	x0, [x0, #16]
    6880:	b4000200 	cbz	x0, 68c0 <fwp_drop4+0x1fc>
    6884:	f9400001 	ldr	x1, [x0]
    6888:	eb14003f 	cmp	x1, x20
    688c:	54ffff61 	b.ne	6878 <fwp_drop4+0x1b4>  // b.any
    6890:	f9400041 	ldr	x1, [x2]
    6894:	f9400420 	ldr	x0, [x1, #8]
    6898:	d1000400 	sub	x0, x0, #0x1
    689c:	f9000420 	str	x0, [x1, #8]
    68a0:	f103f81f 	cmp	x0, #0xfe
    68a4:	54fff5e1 	b.ne	6760 <fwp_drop4+0x9c>  // b.any
    68a8:	39400280 	ldrb	w0, [x20]
    68ac:	7103fc1f 	cmp	w0, #0xff
    68b0:	54000460 	b.eq	693c <fwp_drop4+0x278>  // b.none
    68b4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    68b8:	39000280 	strb	w0, [x20]
    68bc:	17ffffa9 	b	6760 <fwp_drop4+0x9c>
    68c0:	f0000020 	adrp	x0, d000 <__divti3+0x2a0>
    68c4:	9119e000 	add	x0, x0, #0x678
    68c8:	97fff60e 	bl	4100 <fwp_trap>
    68cc:	ca544680 	eor	x0, x20, x20, lsr #17
    68d0:	911702c1 	add	x1, x22, #0x5c0
    68d4:	ca402400 	eor	x0, x0, x0, lsr #9
    68d8:	92401c00 	and	x0, x0, #0xff
    68dc:	910a2402 	add	x2, x0, #0x289
    68e0:	8b000c20 	add	x0, x1, x0, lsl #3
    68e4:	8b020c22 	add	x2, x1, x2, lsl #3
    68e8:	f94a2400 	ldr	x0, [x0, #5192]
    68ec:	b50000a0 	cbnz	x0, 6900 <fwp_drop4+0x23c>
    68f0:	17fffff4 	b	68c0 <fwp_drop4+0x1fc>
    68f4:	91004002 	add	x2, x0, #0x10
    68f8:	f9400800 	ldr	x0, [x0, #16]
    68fc:	b4fffe20 	cbz	x0, 68c0 <fwp_drop4+0x1fc>
    6900:	f9400001 	ldr	x1, [x0]
    6904:	eb14003f 	cmp	x1, x20
    6908:	54ffff61 	b.ne	68f4 <fwp_drop4+0x230>  // b.any
    690c:	f9400041 	ldr	x1, [x2]
    6910:	f9400420 	ldr	x0, [x1, #8]
    6914:	d1000400 	sub	x0, x0, #0x1
    6918:	f9000420 	str	x0, [x1, #8]
    691c:	f103f81f 	cmp	x0, #0xfe
    6920:	54fff781 	b.ne	6810 <fwp_drop4+0x14c>  // b.any
    6924:	39400280 	ldrb	w0, [x20]
    6928:	7103fc1f 	cmp	w0, #0xff
    692c:	540000e0 	b.eq	6948 <fwp_drop4+0x284>  // b.none
    6930:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6934:	39000280 	strb	w0, [x20]
    6938:	17ffffb6 	b	6810 <fwp_drop4+0x14c>
    693c:	aa1403e0 	mov	x0, x20
    6940:	97fff610 	bl	4180 <fwp_rc_forget_slot.part.0>
    6944:	17ffffdc 	b	68b4 <fwp_drop4+0x1f0>
    6948:	aa1403e0 	mov	x0, x20
    694c:	97fff60d 	bl	4180 <fwp_rc_forget_slot.part.0>
    6950:	17fffff8 	b	6930 <fwp_drop4+0x26c>

0000000000006954 <fwp_arg_drop37>:
    6954:	7100003f 	cmp	w1, #0x0
    6958:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    695c:	54000041 	b.ne	6964 <fwp_arg_drop37+0x10>  // b.any
    6960:	d65f03c0 	ret
    6964:	f9400000 	ldr	x0, [x0]
    6968:	17ffff57 	b	66c4 <fwp_drop4>
    696c:	d503201f 	nop

0000000000006970 <fwp_task_dispose>:
    6970:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6974:	910003fd 	mov	x29, sp
    6978:	f9000bf3 	str	x19, [sp, #16]
    697c:	aa0003f3 	mov	x19, x0
    6980:	39414000 	ldrb	w0, [x0, #80]
    6984:	36000720 	tbz	w0, #0, 6a68 <fwp_task_dispose+0xf8>
    6988:	f9400a60 	ldr	x0, [x19, #16]
    698c:	b50006e0 	cbnz	x0, 6a68 <fwp_task_dispose+0xf8>
    6990:	a9478660 	ldp	x0, x1, [x19, #120]
    6994:	39014e7f 	strb	wzr, [x19, #83]
    6998:	f9003e7f 	str	xzr, [x19, #120]
    699c:	f100003f 	cmp	x1, #0x0
    69a0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    69a4:	54000040 	b.eq	69ac <fwp_task_dispose+0x3c>  // b.none
    69a8:	d63f0020 	blr	x1
    69ac:	f9405660 	ldr	x0, [x19, #168]
    69b0:	97fff690 	bl	43f0 <fwp_mem_free>
    69b4:	f900567f 	str	xzr, [x19, #168]
    69b8:	b9405e60 	ldr	w0, [x19, #92]
    69bc:	7100041f 	cmp	w0, #0x1
    69c0:	54000420 	b.eq	6a44 <fwp_task_dispose+0xd4>  // b.none
    69c4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    69c8:	91170042 	add	x2, x2, #0x5c0
    69cc:	f949d840 	ldr	x0, [x2, #5040]
    69d0:	f949ec41 	ldr	x1, [x2, #5080]
    69d4:	cb000260 	sub	x0, x19, x0
    69d8:	eb01401f 	cmp	x0, x1, lsl #16
    69dc:	540002e2 	b.cs	6a38 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    69e0:	d350fc01 	lsr	x1, x0, #16
    69e4:	f949fc44 	ldr	x4, [x2, #5112]
    69e8:	8b010821 	add	x1, x1, x1, lsl #2
    69ec:	d37df021 	lsl	x1, x1, #3
    69f0:	8b010083 	add	x3, x4, x1
    69f4:	f9401062 	ldr	x2, [x3, #32]
    69f8:	b4000202 	cbz	x2, 6a38 <fwp_task_dispose+0xc8>
    69fc:	38616881 	ldrb	w1, [x4, x1]
    6a00:	7100083f 	cmp	w1, #0x2
    6a04:	54000280 	b.eq	6a54 <fwp_task_dispose+0xe4>  // b.none
    6a08:	7100043f 	cmp	w1, #0x1
    6a0c:	54000161 	b.ne	6a38 <fwp_task_dispose+0xc8>  // b.any
    6a10:	29430464 	ldp	w4, w1, [x3, #24]
    6a14:	92403c00 	and	x0, x0, #0xffff
    6a18:	9b047c00 	mul	x0, x0, x4
    6a1c:	d360fc00 	lsr	x0, x0, #32
    6a20:	eb01001f 	cmp	x0, x1
    6a24:	540000a2 	b.cs	6a38 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6a28:	8b000042 	add	x2, x2, x0
    6a2c:	39400040 	ldrb	w0, [x2]
    6a30:	7100041f 	cmp	w0, #0x1
    6a34:	54000080 	b.eq	6a44 <fwp_task_dispose+0xd4>  // b.none
    6a38:	f9400bf3 	ldr	x19, [sp, #16]
    6a3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a40:	d65f03c0 	ret
    6a44:	aa1303e0 	mov	x0, x19
    6a48:	f9400bf3 	ldr	x19, [sp, #16]
    6a4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a50:	17fff668 	b	43f0 <fwp_mem_free>
    6a54:	72003c1f 	tst	w0, #0xffff
    6a58:	54fffea0 	b.eq	6a2c <fwp_task_dispose+0xbc>  // b.none
    6a5c:	f9400bf3 	ldr	x19, [sp, #16]
    6a60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a64:	d65f03c0 	ret
    6a68:	97ffef9e 	bl	28e0 <abort@plt>
    6a6c:	d503201f 	nop

0000000000006a70 <fwp_free_zombie>:
    6a70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a74:	910003fd 	mov	x29, sp
    6a78:	a90153f3 	stp	x19, x20, [sp, #16]
    6a7c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6a80:	9101c281 	add	x1, x20, #0x70
    6a84:	f9407033 	ldr	x19, [x1, #224]
    6a88:	b4000333 	cbz	x19, 6aec <fwp_free_zombie+0x7c>
    6a8c:	f9400820 	ldr	x0, [x1, #16]
    6a90:	eb00027f 	cmp	x19, x0
    6a94:	540002c0 	b.eq	6aec <fwp_free_zombie+0x7c>  // b.none
    6a98:	b940e822 	ldr	w2, [x1, #232]
    6a9c:	f9400a60 	ldr	x0, [x19, #16]
    6aa0:	7100fc5f 	cmp	w2, #0x3f
    6aa4:	5400078c 	b.gt	6b94 <fwp_free_zombie+0x124>
    6aa8:	9103c023 	add	x3, x1, #0xf0
    6aac:	11000444 	add	w4, w2, #0x1
    6ab0:	b900e824 	str	w4, [x1, #232]
    6ab4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6ab8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6abc:	a9530261 	ldp	x1, x0, [x19, #304]
    6ac0:	b4000741 	cbz	x1, 6ba8 <fwp_free_zombie+0x138>
    6ac4:	f9009c20 	str	x0, [x1, #312]
    6ac8:	b4000040 	cbz	x0, 6ad0 <fwp_free_zombie+0x60>
    6acc:	f9009801 	str	x1, [x0, #304]
    6ad0:	9101c294 	add	x20, x20, #0x70
    6ad4:	b9405e60 	ldr	w0, [x19, #92]
    6ad8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6adc:	f900729f 	str	xzr, [x20, #224]
    6ae0:	34000140 	cbz	w0, 6b08 <fwp_free_zombie+0x98>
    6ae4:	7100041f 	cmp	w0, #0x1
    6ae8:	54000080 	b.eq	6af8 <fwp_free_zombie+0x88>  // b.none
    6aec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6af0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6af4:	d65f03c0 	ret
    6af8:	aa1303e0 	mov	x0, x19
    6afc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b04:	17ffff9b 	b	6970 <fwp_task_dispose>
    6b08:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc20>
    6b0c:	91170082 	add	x2, x4, #0x5c0
    6b10:	f949d841 	ldr	x1, [x2, #5040]
    6b14:	f949ec40 	ldr	x0, [x2, #5080]
    6b18:	cb010261 	sub	x1, x19, x1
    6b1c:	eb00403f 	cmp	x1, x0, lsl #16
    6b20:	54fffe62 	b.cs	6aec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6b24:	d350fc20 	lsr	x0, x1, #16
    6b28:	f949fc43 	ldr	x3, [x2, #5112]
    6b2c:	8b000800 	add	x0, x0, x0, lsl #2
    6b30:	d37df000 	lsl	x0, x0, #3
    6b34:	8b000062 	add	x2, x3, x0
    6b38:	f9401054 	ldr	x20, [x2, #32]
    6b3c:	b4fffd94 	cbz	x20, 6aec <fwp_free_zombie+0x7c>
    6b40:	38606860 	ldrb	w0, [x3, x0]
    6b44:	7100081f 	cmp	w0, #0x2
    6b48:	54000360 	b.eq	6bb4 <fwp_free_zombie+0x144>  // b.none
    6b4c:	7100041f 	cmp	w0, #0x1
    6b50:	54fffce1 	b.ne	6aec <fwp_free_zombie+0x7c>  // b.any
    6b54:	29430043 	ldp	w3, w0, [x2, #24]
    6b58:	92403c21 	and	x1, x1, #0xffff
    6b5c:	9b037c21 	mul	x1, x1, x3
    6b60:	d360fc21 	lsr	x1, x1, #32
    6b64:	eb00003f 	cmp	x1, x0
    6b68:	54fffc22 	b.cs	6aec <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6b6c:	8b010294 	add	x20, x20, x1
    6b70:	39400280 	ldrb	w0, [x20]
    6b74:	34fffbc0 	cbz	w0, 6aec <fwp_free_zombie+0x7c>
    6b78:	7100041f 	cmp	w0, #0x1
    6b7c:	54fffbe0 	b.eq	6af8 <fwp_free_zombie+0x88>  // b.none
    6b80:	7103fc1f 	cmp	w0, #0xff
    6b84:	540001e0 	b.eq	6bc0 <fwp_free_zombie+0x150>  // b.none
    6b88:	51000400 	sub	w0, w0, #0x1
    6b8c:	39000280 	strb	w0, [x20]
    6b90:	17ffffd7 	b	6aec <fwp_free_zombie+0x7c>
    6b94:	f9400e61 	ldr	x1, [x19, #24]
    6b98:	97ffef86 	bl	29b0 <munmap@plt>
    6b9c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6ba0:	a9530261 	ldp	x1, x0, [x19, #304]
    6ba4:	b5fff901 	cbnz	x1, 6ac4 <fwp_free_zombie+0x54>
    6ba8:	9101c282 	add	x2, x20, #0x70
    6bac:	f9017840 	str	x0, [x2, #752]
    6bb0:	17ffffc6 	b	6ac8 <fwp_free_zombie+0x58>
    6bb4:	72003c3f 	tst	w1, #0xffff
    6bb8:	54fff9a1 	b.ne	6aec <fwp_free_zombie+0x7c>  // b.any
    6bbc:	17ffffed 	b	6b70 <fwp_free_zombie+0x100>
    6bc0:	ca544680 	eor	x0, x20, x20, lsr #17
    6bc4:	91170084 	add	x4, x4, #0x5c0
    6bc8:	ca402400 	eor	x0, x0, x0, lsr #9
    6bcc:	92401c00 	and	x0, x0, #0xff
    6bd0:	910a2402 	add	x2, x0, #0x289
    6bd4:	8b000c80 	add	x0, x4, x0, lsl #3
    6bd8:	8b020c82 	add	x2, x4, x2, lsl #3
    6bdc:	f94a2400 	ldr	x0, [x0, #5192]
    6be0:	b50000a0 	cbnz	x0, 6bf4 <fwp_free_zombie+0x184>
    6be4:	14000013 	b	6c30 <fwp_free_zombie+0x1c0>
    6be8:	91004002 	add	x2, x0, #0x10
    6bec:	f9400800 	ldr	x0, [x0, #16]
    6bf0:	b4000200 	cbz	x0, 6c30 <fwp_free_zombie+0x1c0>
    6bf4:	f9400001 	ldr	x1, [x0]
    6bf8:	eb14003f 	cmp	x1, x20
    6bfc:	54ffff61 	b.ne	6be8 <fwp_free_zombie+0x178>  // b.any
    6c00:	f9400041 	ldr	x1, [x2]
    6c04:	f9400420 	ldr	x0, [x1, #8]
    6c08:	d1000400 	sub	x0, x0, #0x1
    6c0c:	f9000420 	str	x0, [x1, #8]
    6c10:	f103f81f 	cmp	x0, #0xfe
    6c14:	54fff6c1 	b.ne	6aec <fwp_free_zombie+0x7c>  // b.any
    6c18:	39400280 	ldrb	w0, [x20]
    6c1c:	7103fc1f 	cmp	w0, #0xff
    6c20:	540000e0 	b.eq	6c3c <fwp_free_zombie+0x1cc>  // b.none
    6c24:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c28:	39000280 	strb	w0, [x20]
    6c2c:	17ffffb0 	b	6aec <fwp_free_zombie+0x7c>
    6c30:	f0000020 	adrp	x0, d000 <__divti3+0x2a0>
    6c34:	9119e000 	add	x0, x0, #0x678
    6c38:	97fff532 	bl	4100 <fwp_trap>
    6c3c:	aa1403e0 	mov	x0, x20
    6c40:	97fff550 	bl	4180 <fwp_rc_forget_slot.part.0>
    6c44:	17fffff8 	b	6c24 <fwp_free_zombie+0x1b4>
    6c48:	d503201f 	nop
    6c4c:	d503201f 	nop

0000000000006c50 <fwp_block>:
    6c50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c54:	910003fd 	mov	x29, sp
    6c58:	a90153f3 	stp	x19, x20, [sp, #16]
    6c5c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6c60:	9101c274 	add	x20, x19, #0x70
    6c64:	f9404282 	ldr	x2, [x20, #128]
    6c68:	b4000642 	cbz	x2, 6d30 <fwp_block+0xe0>
    6c6c:	9101c261 	add	x1, x19, #0x70
    6c70:	f9408040 	ldr	x0, [x2, #256]
    6c74:	f9004020 	str	x0, [x1, #128]
    6c78:	b40006a0 	cbz	x0, 6d4c <fwp_block+0xfc>
    6c7c:	d503201f 	nop
    6c80:	9101c263 	add	x3, x19, #0x70
    6c84:	3901505f 	strb	wzr, [x2, #84]
    6c88:	f9400864 	ldr	x4, [x3, #16]
    6c8c:	eb02009f 	cmp	x4, x2
    6c90:	54000440 	b.eq	6d18 <fwp_block+0xc8>  // b.none
    6c94:	f9417c65 	ldr	x5, [x3, #760]
    6c98:	f9000862 	str	x2, [x3, #16]
    6c9c:	f9400441 	ldr	x1, [x2, #8]
    6ca0:	f9004885 	str	x5, [x4, #144]
    6ca4:	f9418065 	ldr	x5, [x3, #768]
    6ca8:	f9004c85 	str	x5, [x4, #152]
    6cac:	f9418465 	ldr	x5, [x3, #776]
    6cb0:	f9005085 	str	x5, [x4, #160]
    6cb4:	f9418865 	ldr	x5, [x3, #784]
    6cb8:	f9005485 	str	x5, [x4, #168]
    6cbc:	f9418c65 	ldr	x5, [x3, #792]
    6cc0:	f9005885 	str	x5, [x4, #176]
    6cc4:	f9419065 	ldr	x5, [x3, #800]
    6cc8:	f9005c85 	str	x5, [x4, #184]
    6ccc:	f9419465 	ldr	x5, [x3, #808]
    6cd0:	f9006085 	str	x5, [x4, #192]
    6cd4:	f9400480 	ldr	x0, [x4, #8]
    6cd8:	f9404844 	ldr	x4, [x2, #144]
    6cdc:	f9017c64 	str	x4, [x3, #760]
    6ce0:	f9404c44 	ldr	x4, [x2, #152]
    6ce4:	f9018064 	str	x4, [x3, #768]
    6ce8:	f9405044 	ldr	x4, [x2, #160]
    6cec:	f9018464 	str	x4, [x3, #776]
    6cf0:	f9405444 	ldr	x4, [x2, #168]
    6cf4:	f9018864 	str	x4, [x3, #784]
    6cf8:	f9405844 	ldr	x4, [x2, #176]
    6cfc:	f9018c64 	str	x4, [x3, #792]
    6d00:	a94b8844 	ldp	x4, x2, [x2, #184]
    6d04:	f9019064 	str	x4, [x3, #800]
    6d08:	f9019462 	str	x2, [x3, #808]
    6d0c:	97ffeef9 	bl	28f0 <swapcontext@plt>
    6d10:	97ffff58 	bl	6a70 <fwp_free_zombie>
    6d14:	d503201f 	nop
    6d18:	9101c260 	add	x0, x19, #0x70
    6d1c:	b9433000 	ldr	w0, [x0, #816]
    6d20:	340001a0 	cbz	w0, 6d54 <fwp_block+0x104>
    6d24:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d28:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d2c:	d65f03c0 	ret
    6d30:	97fff73c 	bl	4a20 <fwp_poll_events>
    6d34:	f9404282 	ldr	x2, [x20, #128]
    6d38:	b4ffffc2 	cbz	x2, 6d30 <fwp_block+0xe0>
    6d3c:	9101c261 	add	x1, x19, #0x70
    6d40:	f9408040 	ldr	x0, [x2, #256]
    6d44:	f9004020 	str	x0, [x1, #128]
    6d48:	b5fff9c0 	cbnz	x0, 6c80 <fwp_block+0x30>
    6d4c:	f9003c3f 	str	xzr, [x1, #120]
    6d50:	17ffffcc 	b	6c80 <fwp_block+0x30>
    6d54:	f0000020 	adrp	x0, d000 <__divti3+0x2a0>
    6d58:	91244000 	add	x0, x0, #0x910
    6d5c:	97ffef31 	bl	2a20 <getenv@plt>
    6d60:	5284e202 	mov	w2, #0x2710                	// #10000
    6d64:	b4000060 	cbz	x0, 6d70 <fwp_block+0x120>
    6d68:	39400001 	ldrb	w1, [x0]
    6d6c:	350000c1 	cbnz	w1, 6d84 <fwp_block+0x134>
    6d70:	9101c273 	add	x19, x19, #0x70
    6d74:	b9033262 	str	w2, [x19, #816]
    6d78:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d7c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d80:	d65f03c0 	ret
    6d84:	52800142 	mov	w2, #0xa                   	// #10
    6d88:	d2800001 	mov	x1, #0x0                   	// #0
    6d8c:	97ffee75 	bl	2760 <strtoll@plt>
    6d90:	d1000403 	sub	x3, x0, #0x1
    6d94:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6d98:	eb02007f 	cmp	x3, x2
    6d9c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6da0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6da4:	17fffff3 	b	6d70 <fwp_block+0x120>
    6da8:	d503201f 	nop
    6dac:	d503201f 	nop

0000000000006db0 <fwp_drop10>:
    6db0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6db4:	910003fd 	mov	x29, sp
    6db8:	a90153f3 	stp	x19, x20, [sp, #16]
    6dbc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc20>
    6dc0:	f90013f5 	str	x21, [sp, #32]
    6dc4:	91170275 	add	x21, x19, #0x5c0
    6dc8:	f949daa1 	ldr	x1, [x21, #5040]
    6dcc:	f949eea2 	ldr	x2, [x21, #5080]
    6dd0:	cb010001 	sub	x1, x0, x1
    6dd4:	eb02403f 	cmp	x1, x2, lsl #16
    6dd8:	54000382 	b.cs	6e48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6ddc:	d350fc22 	lsr	x2, x1, #16
    6de0:	f949fea3 	ldr	x3, [x21, #5112]
    6de4:	8b020842 	add	x2, x2, x2, lsl #2
    6de8:	d37df042 	lsl	x2, x2, #3
    6dec:	8b020064 	add	x4, x3, x2
    6df0:	f9401094 	ldr	x20, [x4, #32]
    6df4:	b40002b4 	cbz	x20, 6e48 <fwp_drop10+0x98>
    6df8:	38626862 	ldrb	w2, [x3, x2]
    6dfc:	7100085f 	cmp	w2, #0x2
    6e00:	540007a0 	b.eq	6ef4 <fwp_drop10+0x144>  // b.none
    6e04:	7100045f 	cmp	w2, #0x1
    6e08:	54000201 	b.ne	6e48 <fwp_drop10+0x98>  // b.any
    6e0c:	29430885 	ldp	w5, w2, [x4, #24]
    6e10:	92403c21 	and	x1, x1, #0xffff
    6e14:	9b057c21 	mul	x1, x1, x5
    6e18:	d360fc21 	lsr	x1, x1, #32
    6e1c:	eb02003f 	cmp	x1, x2
    6e20:	54000142 	b.cs	6e48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6e24:	8b010294 	add	x20, x20, x1
    6e28:	39400281 	ldrb	w1, [x20]
    6e2c:	340000e1 	cbz	w1, 6e48 <fwp_drop10+0x98>
    6e30:	7100043f 	cmp	w1, #0x1
    6e34:	54000120 	b.eq	6e58 <fwp_drop10+0xa8>  // b.none
    6e38:	7103fc3f 	cmp	w1, #0xff
    6e3c:	540007c0 	b.eq	6f34 <fwp_drop10+0x184>  // b.none
    6e40:	51000421 	sub	w1, w1, #0x1
    6e44:	39000281 	strb	w1, [x20]
    6e48:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e4c:	f94013f5 	ldr	x21, [sp, #32]
    6e50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e54:	d65f03c0 	ret
    6e58:	f9400001 	ldr	x1, [x0]
    6e5c:	b7f80581 	tbnz	x1, #63, 6f0c <fwp_drop10+0x15c>
    6e60:	91170273 	add	x19, x19, #0x5c0
    6e64:	f949da61 	ldr	x1, [x19, #5040]
    6e68:	f949ee62 	ldr	x2, [x19, #5080]
    6e6c:	cb010001 	sub	x1, x0, x1
    6e70:	eb02403f 	cmp	x1, x2, lsl #16
    6e74:	54fffea2 	b.cs	6e48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6e78:	d350fc22 	lsr	x2, x1, #16
    6e7c:	8b020842 	add	x2, x2, x2, lsl #2
    6e80:	d37df042 	lsl	x2, x2, #3
    6e84:	8b020065 	add	x5, x3, x2
    6e88:	f94010a4 	ldr	x4, [x5, #32]
    6e8c:	b4fffde4 	cbz	x4, 6e48 <fwp_drop10+0x98>
    6e90:	38626862 	ldrb	w2, [x3, x2]
    6e94:	7100085f 	cmp	w2, #0x2
    6e98:	54000220 	b.eq	6edc <fwp_drop10+0x12c>  // b.none
    6e9c:	7100045f 	cmp	w2, #0x1
    6ea0:	54fffd41 	b.ne	6e48 <fwp_drop10+0x98>  // b.any
    6ea4:	294308a3 	ldp	w3, w2, [x5, #24]
    6ea8:	92403c21 	and	x1, x1, #0xffff
    6eac:	9b037c21 	mul	x1, x1, x3
    6eb0:	d360fc21 	lsr	x1, x1, #32
    6eb4:	eb02003f 	cmp	x1, x2
    6eb8:	54fffc82 	b.cs	6e48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6ebc:	8b010084 	add	x4, x4, x1
    6ec0:	39400081 	ldrb	w1, [x4]
    6ec4:	7100043f 	cmp	w1, #0x1
    6ec8:	54fffc01 	b.ne	6e48 <fwp_drop10+0x98>  // b.any
    6ecc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ed0:	f94013f5 	ldr	x21, [sp, #32]
    6ed4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ed8:	17fff546 	b	43f0 <fwp_mem_free>
    6edc:	72003c3f 	tst	w1, #0xffff
    6ee0:	54ffff00 	b.eq	6ec0 <fwp_drop10+0x110>  // b.none
    6ee4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ee8:	f94013f5 	ldr	x21, [sp, #32]
    6eec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ef0:	d65f03c0 	ret
    6ef4:	72003c3f 	tst	w1, #0xffff
    6ef8:	54fff980 	b.eq	6e28 <fwp_drop10+0x78>  // b.none
    6efc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f00:	f94013f5 	ldr	x21, [sp, #32]
    6f04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6f08:	d65f03c0 	ret
    6f0c:	f9400414 	ldr	x20, [x0, #8]
    6f10:	97fffb2c 	bl	5bc0 <fwp_rc_free_arr>
    6f14:	91170260 	add	x0, x19, #0x5c0
    6f18:	f949d801 	ldr	x1, [x0, #5040]
    6f1c:	f949ec00 	ldr	x0, [x0, #5080]
    6f20:	cb010281 	sub	x1, x20, x1
    6f24:	eb00403f 	cmp	x1, x0, lsl #16
    6f28:	54fff902 	b.cs	6e48 <fwp_drop10+0x98>  // b.hs, b.nlast
    6f2c:	aa1403e0 	mov	x0, x20
    6f30:	17ffffab 	b	6ddc <fwp_drop10+0x2c>
    6f34:	ca544680 	eor	x0, x20, x20, lsr #17
    6f38:	91170273 	add	x19, x19, #0x5c0
    6f3c:	ca402400 	eor	x0, x0, x0, lsr #9
    6f40:	92401c00 	and	x0, x0, #0xff
    6f44:	910a2402 	add	x2, x0, #0x289
    6f48:	8b000e60 	add	x0, x19, x0, lsl #3
    6f4c:	8b020e62 	add	x2, x19, x2, lsl #3
    6f50:	f94a2400 	ldr	x0, [x0, #5192]
    6f54:	b50000a0 	cbnz	x0, 6f68 <fwp_drop10+0x1b8>
    6f58:	14000013 	b	6fa4 <fwp_drop10+0x1f4>
    6f5c:	91004002 	add	x2, x0, #0x10
    6f60:	f9400800 	ldr	x0, [x0, #16]
    6f64:	b4000200 	cbz	x0, 6fa4 <fwp_drop10+0x1f4>
    6f68:	f9400001 	ldr	x1, [x0]
    6f6c:	eb14003f 	cmp	x1, x20
    6f70:	54ffff61 	b.ne	6f5c <fwp_drop10+0x1ac>  // b.any
    6f74:	f9400041 	ldr	x1, [x2]
    6f78:	f9400420 	ldr	x0, [x1, #8]
    6f7c:	d1000400 	sub	x0, x0, #0x1
    6f80:	f9000420 	str	x0, [x1, #8]
    6f84:	f103f81f 	cmp	x0, #0xfe
    6f88:	54fff601 	b.ne	6e48 <fwp_drop10+0x98>  // b.any
    6f8c:	39400280 	ldrb	w0, [x20]
    6f90:	7103fc1f 	cmp	w0, #0xff
    6f94:	540000e0 	b.eq	6fb0 <fwp_drop10+0x200>  // b.none
    6f98:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6f9c:	39000280 	strb	w0, [x20]
    6fa0:	17ffffaa 	b	6e48 <fwp_drop10+0x98>
    6fa4:	f0000020 	adrp	x0, d000 <__divti3+0x2a0>
    6fa8:	9119e000 	add	x0, x0, #0x678
    6fac:	97fff455 	bl	4100 <fwp_trap>
    6fb0:	aa1403e0 	mov	x0, x20
    6fb4:	97fff473 	bl	4180 <fwp_rc_forget_slot.part.0>
    6fb8:	17fffff8 	b	6f98 <fwp_drop10+0x1e8>
    6fbc:	d503201f 	nop

0000000000006fc0 <fwp_caps173>:
    6fc0:	34000041 	cbz	w1, 6fc8 <fwp_caps173+0x8>
    6fc4:	d65f03c0 	ret
    6fc8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc20>
    6fcc:	91170063 	add	x3, x3, #0x5c0
    6fd0:	f949d861 	ldr	x1, [x3, #5040]
    6fd4:	f949ec62 	ldr	x2, [x3, #5080]
    6fd8:	cb010001 	sub	x1, x0, x1
    6fdc:	eb02403f 	cmp	x1, x2, lsl #16
    6fe0:	54ffff22 	b.cs	6fc4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6fe4:	d350fc22 	lsr	x2, x1, #16
    6fe8:	f949fc65 	ldr	x5, [x3, #5112]
    6fec:	8b020842 	add	x2, x2, x2, lsl #2
    6ff0:	d37df042 	lsl	x2, x2, #3
    6ff4:	8b0200a4 	add	x4, x5, x2
    6ff8:	f9401083 	ldr	x3, [x4, #32]
    6ffc:	b4fffe43 	cbz	x3, 6fc4 <fwp_caps173+0x4>
    7000:	386268a2 	ldrb	w2, [x5, x2]
    7004:	7100085f 	cmp	w2, #0x2
    7008:	540001c0 	b.eq	7040 <fwp_caps173+0x80>  // b.none
    700c:	7100045f 	cmp	w2, #0x1
    7010:	54fffda1 	b.ne	6fc4 <fwp_caps173+0x4>  // b.any
    7014:	29430885 	ldp	w5, w2, [x4, #24]
    7018:	92403c21 	and	x1, x1, #0xffff
    701c:	9b057c21 	mul	x1, x1, x5
    7020:	d360fc21 	lsr	x1, x1, #32
    7024:	eb02003f 	cmp	x1, x2
    7028:	54fffce2 	b.cs	6fc4 <fwp_caps173+0x4>  // b.hs, b.nlast
    702c:	8b010063 	add	x3, x3, x1
    7030:	39400061 	ldrb	w1, [x3]
    7034:	7100043f 	cmp	w1, #0x1
    7038:	54fffc61 	b.ne	6fc4 <fwp_caps173+0x4>  // b.any
    703c:	17fff4ed 	b	43f0 <fwp_mem_free>
    7040:	72003c3f 	tst	w1, #0xffff
    7044:	54ffff60 	b.eq	7030 <fwp_caps173+0x70>  // b.none
    7048:	d65f03c0 	ret
    704c:	d503201f 	nop

0000000000007050 <fwp_args37>:
    7050:	7100003f 	cmp	w1, #0x0
    7054:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7058:	54000041 	b.ne	7060 <fwp_args37+0x10>  // b.any
    705c:	d65f03c0 	ret
    7060:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    7064:	91170042 	add	x2, x2, #0x5c0
    7068:	f9400001 	ldr	x1, [x0]
    706c:	f949d843 	ldr	x3, [x2, #5040]
    7070:	f949ec40 	ldr	x0, [x2, #5080]
    7074:	cb030021 	sub	x1, x1, x3
    7078:	eb00403f 	cmp	x1, x0, lsl #16
    707c:	54ffff02 	b.cs	705c <fwp_args37+0xc>  // b.hs, b.nlast
    7080:	d350fc20 	lsr	x0, x1, #16
    7084:	f949fc44 	ldr	x4, [x2, #5112]
    7088:	8b000800 	add	x0, x0, x0, lsl #2
    708c:	d37df002 	lsl	x2, x0, #3
    7090:	8b020083 	add	x3, x4, x2
    7094:	f9401060 	ldr	x0, [x3, #32]
    7098:	b4fffe20 	cbz	x0, 705c <fwp_args37+0xc>
    709c:	38626882 	ldrb	w2, [x4, x2]
    70a0:	7100085f 	cmp	w2, #0x2
    70a4:	54000220 	b.eq	70e8 <fwp_args37+0x98>  // b.none
    70a8:	7100045f 	cmp	w2, #0x1
    70ac:	54fffd81 	b.ne	705c <fwp_args37+0xc>  // b.any
    70b0:	29430864 	ldp	w4, w2, [x3, #24]
    70b4:	92403c21 	and	x1, x1, #0xffff
    70b8:	9b047c21 	mul	x1, x1, x4
    70bc:	d360fc21 	lsr	x1, x1, #32
    70c0:	eb02003f 	cmp	x1, x2
    70c4:	54fffcc2 	b.cs	705c <fwp_args37+0xc>  // b.hs, b.nlast
    70c8:	8b010000 	add	x0, x0, x1
    70cc:	39400001 	ldrb	w1, [x0]
    70d0:	34fffc61 	cbz	w1, 705c <fwp_args37+0xc>
    70d4:	7103f43f 	cmp	w1, #0xfd
    70d8:	540000e8 	b.hi	70f4 <fwp_args37+0xa4>  // b.pmore
    70dc:	11000421 	add	w1, w1, #0x1
    70e0:	39000001 	strb	w1, [x0]
    70e4:	d65f03c0 	ret
    70e8:	72003c3f 	tst	w1, #0xffff
    70ec:	54ffff00 	b.eq	70cc <fwp_args37+0x7c>  // b.none
    70f0:	d65f03c0 	ret
    70f4:	17fff538 	b	45d4 <fwp_rc_wide_dup>
    70f8:	d503201f 	nop
    70fc:	d503201f 	nop

0000000000007100 <fwp_caps37>:
    7100:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7104:	910003fd 	mov	x29, sp
    7108:	f9000bf3 	str	x19, [sp, #16]
    710c:	aa0003f3 	mov	x19, x0
    7110:	b9400400 	ldr	w0, [x0, #4]
    7114:	340004a0 	cbz	w0, 71a8 <fwp_caps37+0xa8>
    7118:	f9400660 	ldr	x0, [x19, #8]
    711c:	350004e1 	cbnz	w1, 71b8 <fwp_caps37+0xb8>
    7120:	97fffd69 	bl	66c4 <fwp_drop4>
    7124:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    7128:	91170042 	add	x2, x2, #0x5c0
    712c:	f949d840 	ldr	x0, [x2, #5040]
    7130:	f949ec41 	ldr	x1, [x2, #5080]
    7134:	cb000260 	sub	x0, x19, x0
    7138:	eb01401f 	cmp	x0, x1, lsl #16
    713c:	54000382 	b.cs	71ac <fwp_caps37+0xac>  // b.hs, b.nlast
    7140:	d350fc01 	lsr	x1, x0, #16
    7144:	f949fc44 	ldr	x4, [x2, #5112]
    7148:	8b010821 	add	x1, x1, x1, lsl #2
    714c:	d37df021 	lsl	x1, x1, #3
    7150:	8b010083 	add	x3, x4, x1
    7154:	f9401062 	ldr	x2, [x3, #32]
    7158:	b40002a2 	cbz	x2, 71ac <fwp_caps37+0xac>
    715c:	38616881 	ldrb	w1, [x4, x1]
    7160:	7100083f 	cmp	w1, #0x2
    7164:	540006c0 	b.eq	723c <fwp_caps37+0x13c>  // b.none
    7168:	7100043f 	cmp	w1, #0x1
    716c:	54000201 	b.ne	71ac <fwp_caps37+0xac>  // b.any
    7170:	29430464 	ldp	w4, w1, [x3, #24]
    7174:	92403c00 	and	x0, x0, #0xffff
    7178:	9b047c00 	mul	x0, x0, x4
    717c:	d360fc00 	lsr	x0, x0, #32
    7180:	eb01001f 	cmp	x0, x1
    7184:	54000142 	b.cs	71ac <fwp_caps37+0xac>  // b.hs, b.nlast
    7188:	8b000042 	add	x2, x2, x0
    718c:	39400040 	ldrb	w0, [x2]
    7190:	7100041f 	cmp	w0, #0x1
    7194:	540000c1 	b.ne	71ac <fwp_caps37+0xac>  // b.any
    7198:	aa1303e0 	mov	x0, x19
    719c:	f9400bf3 	ldr	x19, [sp, #16]
    71a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71a4:	17fff493 	b	43f0 <fwp_mem_free>
    71a8:	34fffbe1 	cbz	w1, 7124 <fwp_caps37+0x24>
    71ac:	f9400bf3 	ldr	x19, [sp, #16]
    71b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71b4:	d65f03c0 	ret
    71b8:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    71bc:	91170042 	add	x2, x2, #0x5c0
    71c0:	f949d843 	ldr	x3, [x2, #5040]
    71c4:	f949ec41 	ldr	x1, [x2, #5080]
    71c8:	cb030000 	sub	x0, x0, x3
    71cc:	eb01401f 	cmp	x0, x1, lsl #16
    71d0:	54fffee2 	b.cs	71ac <fwp_caps37+0xac>  // b.hs, b.nlast
    71d4:	d350fc01 	lsr	x1, x0, #16
    71d8:	f949fc44 	ldr	x4, [x2, #5112]
    71dc:	8b010821 	add	x1, x1, x1, lsl #2
    71e0:	d37df021 	lsl	x1, x1, #3
    71e4:	8b010083 	add	x3, x4, x1
    71e8:	f9401062 	ldr	x2, [x3, #32]
    71ec:	b4fffe02 	cbz	x2, 71ac <fwp_caps37+0xac>
    71f0:	38616881 	ldrb	w1, [x4, x1]
    71f4:	7100083f 	cmp	w1, #0x2
    71f8:	54000280 	b.eq	7248 <fwp_caps37+0x148>  // b.none
    71fc:	7100043f 	cmp	w1, #0x1
    7200:	54fffd61 	b.ne	71ac <fwp_caps37+0xac>  // b.any
    7204:	92403c01 	and	x1, x0, #0xffff
    7208:	29430064 	ldp	w4, w0, [x3, #24]
    720c:	9b047c21 	mul	x1, x1, x4
    7210:	d360fc21 	lsr	x1, x1, #32
    7214:	eb00003f 	cmp	x1, x0
    7218:	54fffca2 	b.cs	71ac <fwp_caps37+0xac>  // b.hs, b.nlast
    721c:	8b010042 	add	x2, x2, x1
    7220:	39400040 	ldrb	w0, [x2]
    7224:	34fffc40 	cbz	w0, 71ac <fwp_caps37+0xac>
    7228:	7103f41f 	cmp	w0, #0xfd
    722c:	54000148 	b.hi	7254 <fwp_caps37+0x154>  // b.pmore
    7230:	11000400 	add	w0, w0, #0x1
    7234:	39000040 	strb	w0, [x2]
    7238:	17ffffdd 	b	71ac <fwp_caps37+0xac>
    723c:	72003c1f 	tst	w0, #0xffff
    7240:	54fffb61 	b.ne	71ac <fwp_caps37+0xac>  // b.any
    7244:	17ffffd2 	b	718c <fwp_caps37+0x8c>
    7248:	72003c1f 	tst	w0, #0xffff
    724c:	54fffb01 	b.ne	71ac <fwp_caps37+0xac>  // b.any
    7250:	17fffff4 	b	7220 <fwp_caps37+0x120>
    7254:	f9400bf3 	ldr	x19, [sp, #16]
    7258:	aa0203e0 	mov	x0, x2
    725c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7260:	17fff4dd 	b	45d4 <fwp_rc_wide_dup>

0000000000007264 <f37>:
    7264:	d10243ff 	sub	sp, sp, #0x90
    7268:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    726c:	f947f421 	ldr	x1, [x1, #4072]
    7270:	a9037bfd 	stp	x29, x30, [sp, #48]
    7274:	9100c3fd 	add	x29, sp, #0x30
    7278:	a9055bf5 	stp	x21, x22, [sp, #80]
    727c:	d0000156 	adrp	x22, 31000 <fwp_root_context+0xc20>
    7280:	911702c3 	add	x3, x22, #0x5c0
    7284:	a90453f3 	stp	x19, x20, [sp, #64]
    7288:	aa0003f5 	mov	x21, x0
    728c:	a90663f7 	stp	x23, x24, [sp, #96]
    7290:	a90873fb 	stp	x27, x28, [sp, #128]
    7294:	f949ec62 	ldr	x2, [x3, #5080]
    7298:	f9400024 	ldr	x4, [x1]
    729c:	f90017e4 	str	x4, [sp, #40]
    72a0:	d2800004 	mov	x4, #0x0                   	// #0
    72a4:	f949d861 	ldr	x1, [x3, #5040]
    72a8:	d370bc42 	lsl	x2, x2, #16
    72ac:	b4001700 	cbz	x0, 758c <f37+0x328>
    72b0:	f9400817 	ldr	x23, [x0, #16]
    72b4:	cb0102e1 	sub	x1, x23, x1
    72b8:	eb02003f 	cmp	x1, x2
    72bc:	54000362 	b.cs	7328 <f37+0xc4>  // b.hs, b.nlast
    72c0:	f949fc60 	ldr	x0, [x3, #5112]
    72c4:	d350fc22 	lsr	x2, x1, #16
    72c8:	8b020842 	add	x2, x2, x2, lsl #2
    72cc:	8b020c02 	add	x2, x0, x2, lsl #3
    72d0:	f9401040 	ldr	x0, [x2, #32]
    72d4:	b40002a0 	cbz	x0, 7328 <f37+0xc4>
    72d8:	39400043 	ldrb	w3, [x2]
    72dc:	7100087f 	cmp	w3, #0x2
    72e0:	54001440 	b.eq	7568 <f37+0x304>  // b.none
    72e4:	7100047f 	cmp	w3, #0x1
    72e8:	540001c1 	b.ne	7320 <f37+0xbc>  // b.any
    72ec:	29430843 	ldp	w3, w2, [x2, #24]
    72f0:	92403c21 	and	x1, x1, #0xffff
    72f4:	9b037c21 	mul	x1, x1, x3
    72f8:	d360fc21 	lsr	x1, x1, #32
    72fc:	eb02003f 	cmp	x1, x2
    7300:	54000102 	b.cs	7320 <f37+0xbc>  // b.hs, b.nlast
    7304:	8b010000 	add	x0, x0, x1
    7308:	39400001 	ldrb	w1, [x0]
    730c:	340000a1 	cbz	w1, 7320 <f37+0xbc>
    7310:	7103f43f 	cmp	w1, #0xfd
    7314:	54001708 	b.hi	75f4 <f37+0x390>  // b.pmore
    7318:	11000421 	add	w1, w1, #0x1
    731c:	39000001 	strb	w1, [x0]
    7320:	d2800002 	mov	x2, #0x0                   	// #0
    7324:	b40000d5 	cbz	x21, 733c <f37+0xd8>
    7328:	aa1503e1 	mov	x1, x21
    732c:	d2800002 	mov	x2, #0x0                   	// #0
    7330:	f9400821 	ldr	x1, [x1, #16]
    7334:	91000442 	add	x2, x2, #0x1
    7338:	b5ffffc1 	cbnz	x1, 7330 <f37+0xcc>
    733c:	b40012f7 	cbz	x23, 7598 <f37+0x334>
    7340:	aa1703e1 	mov	x1, x23
    7344:	d2800003 	mov	x3, #0x0                   	// #0
    7348:	f9400821 	ldr	x1, [x1, #16]
    734c:	91000463 	add	x3, x3, #0x1
    7350:	b5ffffc1 	cbnz	x1, 7348 <f37+0xe4>
    7354:	eb02007f 	cmp	x3, x2
    7358:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    735c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7360:	eb00027f 	cmp	x19, x0
    7364:	54000fa8 	b.hi	7558 <f37+0x2f4>  // b.pmore
    7368:	d37ffa74 	lsl	x20, x19, #1
    736c:	52800041 	mov	w1, #0x2                   	// #2
    7370:	91000680 	add	x0, x20, #0x1
    7374:	d37df000 	lsl	x0, x0, #3
    7378:	97fff6da 	bl	4ee0 <fwp_heap_alloc>
    737c:	911702c1 	add	x1, x22, #0x5c0
    7380:	aa0003fb 	mov	x27, x0
    7384:	f9000014 	str	x20, [x0]
    7388:	aa0103e0 	mov	x0, x1
    738c:	f949d821 	ldr	x1, [x1, #5040]
    7390:	f949ec00 	ldr	x0, [x0, #5080]
    7394:	cb010361 	sub	x1, x27, x1
    7398:	eb00403f 	cmp	x1, x0, lsl #16
    739c:	54000342 	b.cs	7404 <f37+0x1a0>  // b.hs, b.nlast
    73a0:	911702c2 	add	x2, x22, #0x5c0
    73a4:	d350fc20 	lsr	x0, x1, #16
    73a8:	8b000800 	add	x0, x0, x0, lsl #2
    73ac:	f949fc43 	ldr	x3, [x2, #5112]
    73b0:	d37df002 	lsl	x2, x0, #3
    73b4:	8b020060 	add	x0, x3, x2
    73b8:	f9401014 	ldr	x20, [x0, #32]
    73bc:	b4000254 	cbz	x20, 7404 <f37+0x1a0>
    73c0:	38626862 	ldrb	w2, [x3, x2]
    73c4:	7100085f 	cmp	w2, #0x2
    73c8:	54000dc0 	b.eq	7580 <f37+0x31c>  // b.none
    73cc:	7100045f 	cmp	w2, #0x1
    73d0:	540001a1 	b.ne	7404 <f37+0x1a0>  // b.any
    73d4:	29430002 	ldp	w2, w0, [x0, #24]
    73d8:	92403c21 	and	x1, x1, #0xffff
    73dc:	9b027c21 	mul	x1, x1, x2
    73e0:	d360fc21 	lsr	x1, x1, #32
    73e4:	eb00003f 	cmp	x1, x0
    73e8:	540000e2 	b.cs	7404 <f37+0x1a0>  // b.hs, b.nlast
    73ec:	8b010294 	add	x20, x20, x1
    73f0:	39400280 	ldrb	w0, [x20]
    73f4:	7103fc1f 	cmp	w0, #0xff
    73f8:	54001020 	b.eq	75fc <f37+0x398>  // b.none
    73fc:	52800020 	mov	w0, #0x1                   	// #1
    7400:	39000280 	strb	w0, [x20]
    7404:	b4000333 	cbz	x19, 7468 <f37+0x204>
    7408:	8b131373 	add	x19, x27, x19, lsl #4
    740c:	aa1b03f4 	mov	x20, x27
    7410:	aa1703f8 	mov	x24, x23
    7414:	910023fc 	add	x28, sp, #0x8
    7418:	a9076bf9 	stp	x25, x26, [sp, #112]
    741c:	aa1503f9 	mov	x25, x21
    7420:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    7424:	d503201f 	nop
    7428:	f9400704 	ldr	x4, [x24, #8]
    742c:	aa1c03e2 	mov	x2, x28
    7430:	f9400723 	ldr	x3, [x25, #8]
    7434:	a900fffa 	stp	x26, xzr, [sp, #8]
    7438:	fd400481 	ldr	d1, [x4, #8]
    743c:	f9400881 	ldr	x1, [x4, #16]
    7440:	f9400860 	ldr	x0, [x3, #16]
    7444:	fd400460 	ldr	d0, [x3, #8]
    7448:	97fff806 	bl	5460 <w120>
    744c:	f9000680 	str	x0, [x20, #8]
    7450:	f8010e81 	str	x1, [x20, #16]!
    7454:	f9400b18 	ldr	x24, [x24, #16]
    7458:	f9400b39 	ldr	x25, [x25, #16]
    745c:	eb14027f 	cmp	x19, x20
    7460:	54fffe41 	b.ne	7428 <f37+0x1c4>  // b.any
    7464:	a9476bf9 	ldp	x25, x26, [sp, #112]
    7468:	aa1703e0 	mov	x0, x23
    746c:	97fffc96 	bl	66c4 <fwp_drop4>
    7470:	911702d6 	add	x22, x22, #0x5c0
    7474:	aa1503e0 	mov	x0, x21
    7478:	97fffc93 	bl	66c4 <fwp_drop4>
    747c:	aa1b03e0 	mov	x0, x27
    7480:	97fff948 	bl	59a0 <w176.constprop.0>
    7484:	aa0103f3 	mov	x19, x1
    7488:	aa0003f4 	mov	x20, x0
    748c:	aa1b03e0 	mov	x0, x27
    7490:	97fffe48 	bl	6db0 <fwp_drop10>
    7494:	910063e1 	add	x1, sp, #0x18
    7498:	52800000 	mov	w0, #0x0                   	// #0
    749c:	a901cff4 	stp	x20, x19, [sp, #24]
    74a0:	97fff6d5 	bl	4ff4 <fwp_data.part.0.constprop.0>
    74a4:	aa0003f3 	mov	x19, x0
    74a8:	f949dac1 	ldr	x1, [x22, #5040]
    74ac:	f949eec0 	ldr	x0, [x22, #5080]
    74b0:	cb010261 	sub	x1, x19, x1
    74b4:	eb00403f 	cmp	x1, x0, lsl #16
    74b8:	54000322 	b.cs	751c <f37+0x2b8>  // b.hs, b.nlast
    74bc:	d350fc22 	lsr	x2, x1, #16
    74c0:	f949fec3 	ldr	x3, [x22, #5112]
    74c4:	8b020842 	add	x2, x2, x2, lsl #2
    74c8:	d37df042 	lsl	x2, x2, #3
    74cc:	8b020060 	add	x0, x3, x2
    74d0:	f9401014 	ldr	x20, [x0, #32]
    74d4:	b4000254 	cbz	x20, 751c <f37+0x2b8>
    74d8:	38626862 	ldrb	w2, [x3, x2]
    74dc:	7100085f 	cmp	w2, #0x2
    74e0:	540004a0 	b.eq	7574 <f37+0x310>  // b.none
    74e4:	7100045f 	cmp	w2, #0x1
    74e8:	540001a1 	b.ne	751c <f37+0x2b8>  // b.any
    74ec:	29430002 	ldp	w2, w0, [x0, #24]
    74f0:	92403c21 	and	x1, x1, #0xffff
    74f4:	9b027c21 	mul	x1, x1, x2
    74f8:	d360fc21 	lsr	x1, x1, #32
    74fc:	eb00003f 	cmp	x1, x0
    7500:	540000e2 	b.cs	751c <f37+0x2b8>  // b.hs, b.nlast
    7504:	8b010294 	add	x20, x20, x1
    7508:	39400280 	ldrb	w0, [x20]
    750c:	7103fc1f 	cmp	w0, #0xff
    7510:	540007c0 	b.eq	7608 <f37+0x3a4>  // b.none
    7514:	52800020 	mov	w0, #0x1                   	// #1
    7518:	39000280 	strb	w0, [x20]
    751c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7520:	f947f400 	ldr	x0, [x0, #4072]
    7524:	f94017e2 	ldr	x2, [sp, #40]
    7528:	f9400001 	ldr	x1, [x0]
    752c:	eb010042 	subs	x2, x2, x1
    7530:	d2800001 	mov	x1, #0x0                   	// #0
    7534:	54000701 	b.ne	7614 <f37+0x3b0>  // b.any
    7538:	a9437bfd 	ldp	x29, x30, [sp, #48]
    753c:	aa1303e0 	mov	x0, x19
    7540:	a94453f3 	ldp	x19, x20, [sp, #64]
    7544:	a9455bf5 	ldp	x21, x22, [sp, #80]
    7548:	a94663f7 	ldp	x23, x24, [sp, #96]
    754c:	a94873fb 	ldp	x27, x28, [sp, #128]
    7550:	910243ff 	add	sp, sp, #0x90
    7554:	d65f03c0 	ret
    7558:	d0000020 	adrp	x0, d000 <__divti3+0x2a0>
    755c:	91248000 	add	x0, x0, #0x920
    7560:	a9076bf9 	stp	x25, x26, [sp, #112]
    7564:	97fff2e7 	bl	4100 <fwp_trap>
    7568:	72003c3f 	tst	w1, #0xffff
    756c:	54ffeda1 	b.ne	7320 <f37+0xbc>  // b.any
    7570:	17ffff66 	b	7308 <f37+0xa4>
    7574:	72003c3f 	tst	w1, #0xffff
    7578:	54fffd21 	b.ne	751c <f37+0x2b8>  // b.any
    757c:	17ffffe3 	b	7508 <f37+0x2a4>
    7580:	72003c3f 	tst	w1, #0xffff
    7584:	54fff401 	b.ne	7404 <f37+0x1a0>  // b.any
    7588:	17ffff9a 	b	73f0 <f37+0x18c>
    758c:	cb0103e1 	neg	x1, x1
    7590:	eb02003f 	cmp	x1, x2
    7594:	54000203 	b.cc	75d4 <f37+0x370>  // b.lo, b.ul, b.last
    7598:	52800041 	mov	w1, #0x2                   	// #2
    759c:	d2800100 	mov	x0, #0x8                   	// #8
    75a0:	97fff650 	bl	4ee0 <fwp_heap_alloc>
    75a4:	aa0003e1 	mov	x1, x0
    75a8:	911702c0 	add	x0, x22, #0x5c0
    75ac:	aa0103fb 	mov	x27, x1
    75b0:	d2800017 	mov	x23, #0x0                   	// #0
    75b4:	f900003f 	str	xzr, [x1]
    75b8:	f949d801 	ldr	x1, [x0, #5040]
    75bc:	f949ec00 	ldr	x0, [x0, #5080]
    75c0:	cb010361 	sub	x1, x27, x1
    75c4:	eb00403f 	cmp	x1, x0, lsl #16
    75c8:	54fff502 	b.cs	7468 <f37+0x204>  // b.hs, b.nlast
    75cc:	d2800013 	mov	x19, #0x0                   	// #0
    75d0:	17ffff74 	b	73a0 <f37+0x13c>
    75d4:	f949fc62 	ldr	x2, [x3, #5112]
    75d8:	d350fc20 	lsr	x0, x1, #16
    75dc:	8b000800 	add	x0, x0, x0, lsl #2
    75e0:	8b000c42 	add	x2, x2, x0, lsl #3
    75e4:	f9401040 	ldr	x0, [x2, #32]
    75e8:	b4fffd80 	cbz	x0, 7598 <f37+0x334>
    75ec:	d2800017 	mov	x23, #0x0                   	// #0
    75f0:	17ffff3a 	b	72d8 <f37+0x74>
    75f4:	97fff3f8 	bl	45d4 <fwp_rc_wide_dup>
    75f8:	17ffff4a 	b	7320 <f37+0xbc>
    75fc:	aa1403e0 	mov	x0, x20
    7600:	97fff2e0 	bl	4180 <fwp_rc_forget_slot.part.0>
    7604:	17ffff7e 	b	73fc <f37+0x198>
    7608:	aa1403e0 	mov	x0, x20
    760c:	97fff2dd 	bl	4180 <fwp_rc_forget_slot.part.0>
    7610:	17ffffc1 	b	7514 <f37+0x2b0>
    7614:	a9076bf9 	stp	x25, x26, [sp, #112]
    7618:	97ffec9e 	bl	2890 <__stack_chk_fail@plt>
    761c:	d503201f 	nop

0000000000007620 <fwp_owned_entry37>:
    7620:	f9400000 	ldr	x0, [x0]
    7624:	17ffff10 	b	7264 <f37>
    7628:	d503201f 	nop
    762c:	d503201f 	nop

0000000000007630 <e37>:
    7630:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7634:	910003fd 	mov	x29, sp
    7638:	f9000bf3 	str	x19, [sp, #16]
    763c:	f9400013 	ldr	x19, [x0]
    7640:	aa1303e0 	mov	x0, x19
    7644:	97fff90b 	bl	5a70 <fwp_rc_share>
    7648:	aa1303e0 	mov	x0, x19
    764c:	97ffff06 	bl	7264 <f37>
    7650:	aa0003f3 	mov	x19, x0
    7654:	97fff907 	bl	5a70 <fwp_rc_share>
    7658:	aa1303e0 	mov	x0, x19
    765c:	f9400bf3 	ldr	x19, [sp, #16]
    7660:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7664:	d65f03c0 	ret
    7668:	d503201f 	nop
    766c:	d503201f 	nop

0000000000007670 <fwp_write>:
    7670:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7674:	910003fd 	mov	x29, sp
    7678:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc88>
    767c:	f947f484 	ldr	x4, [x4, #4072]
    7680:	a90153f3 	stp	x19, x20, [sp, #16]
    7684:	d10943ff 	sub	sp, sp, #0x250
    7688:	b9400045 	ldr	w5, [x2]
    768c:	aa0003f4 	mov	x20, x0
    7690:	f9400080 	ldr	x0, [x4]
    7694:	f90127e0 	str	x0, [sp, #584]
    7698:	d2800000 	mov	x0, #0x0                   	// #0
    769c:	710064bf 	cmp	w5, #0x19
    76a0:	54000408 	b.hi	7720 <fwp_write+0xb0>  // b.pmore
    76a4:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0xb80>
    76a8:	aa0103f3 	mov	x19, x1
    76ac:	9107c000 	add	x0, x0, #0x1f0
    76b0:	f9013bf5 	str	x21, [sp, #624]
    76b4:	f9013ff6 	str	x22, [sp, #632]
    76b8:	f90153fb 	str	x27, [sp, #672]
    76bc:	f90157fc 	str	x28, [sp, #680]
    76c0:	aa0203fc 	mov	x28, x2
    76c4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    76c8:	10000061 	adr	x1, 76d4 <fwp_write+0x64>
    76cc:	8b20a820 	add	x0, x1, w0, sxth #2
    76d0:	d61f0000 	br	x0
    76d4:	910123e0 	add	x0, sp, #0x48
    76d8:	aa1303e5 	mov	x5, x19
    76dc:	d0000024 	adrp	x4, d000 <__divti3+0x2a0>
    76e0:	aa0003f3 	mov	x19, x0
    76e4:	9125a084 	add	x4, x4, #0x968
    76e8:	d2804003 	mov	x3, #0x200                 	// #512
    76ec:	aa0303e1 	mov	x1, x3
    76f0:	52800042 	mov	w2, #0x2                   	// #2
    76f4:	97ffec43 	bl	2800 <__snprintf_chk@plt>
    76f8:	aa1303e0 	mov	x0, x19
    76fc:	97ffec09 	bl	2720 <strlen@plt>
    7700:	aa1303e1 	mov	x1, x19
    7704:	aa0003e2 	mov	x2, x0
    7708:	aa1403e0 	mov	x0, x20
    770c:	97ffefa1 	bl	3590 <buf_put>
    7710:	f9413bf5 	ldr	x21, [sp, #624]
    7714:	f9413ff6 	ldr	x22, [sp, #632]
    7718:	f94153fb 	ldr	x27, [sp, #672]
    771c:	f94157fc 	ldr	x28, [sp, #680]
    7720:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7724:	f947f400 	ldr	x0, [x0, #4072]
    7728:	f94127e2 	ldr	x2, [sp, #584]
    772c:	f9400001 	ldr	x1, [x0]
    7730:	eb010042 	subs	x2, x2, x1
    7734:	d2800001 	mov	x1, #0x0                   	// #0
    7738:	540077c1 	b.ne	8630 <fwp_write+0xfc0>  // b.any
    773c:	910943ff 	add	sp, sp, #0x250
    7740:	a94153f3 	ldp	x19, x20, [sp, #16]
    7744:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7748:	d65f03c0 	ret
    774c:	910123e0 	add	x0, sp, #0x48
    7750:	aa1303e5 	mov	x5, x19
    7754:	d0000024 	adrp	x4, d000 <__divti3+0x2a0>
    7758:	aa0003f3 	mov	x19, x0
    775c:	91258084 	add	x4, x4, #0x960
    7760:	d2804003 	mov	x3, #0x200                 	// #512
    7764:	17ffffe2 	b	76ec <fwp_write+0x7c>
    7768:	71004cbf 	cmp	w5, #0x13
    776c:	d0000020 	adrp	x0, d000 <__divti3+0x2a0>
    7770:	d0000021 	adrp	x1, d000 <__divti3+0x2a0>
    7774:	91254000 	add	x0, x0, #0x950
    7778:	91256021 	add	x1, x1, #0x958
    777c:	d2800082 	mov	x2, #0x4                   	// #4
    7780:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7784:	aa1403e0 	mov	x0, x20
    7788:	f90143f7 	str	x23, [sp, #640]
    778c:	d2800016 	mov	x22, #0x0                   	// #0
    7790:	f90147f8 	str	x24, [sp, #648]
    7794:	97ffef7f 	bl	3590 <buf_put>
    7798:	f9400260 	ldr	x0, [x19]
    779c:	d0000037 	adrp	x23, d000 <__divti3+0x2a0>
    77a0:	d2800015 	mov	x21, #0x0                   	// #0
    77a4:	912762f7 	add	x23, x23, #0x9d8
    77a8:	b40047a0 	cbz	x0, 809c <fwp_write+0xa2c>
    77ac:	b9400380 	ldr	w0, [x28]
    77b0:	52800003 	mov	w3, #0x0                   	// #0
    77b4:	f9401f82 	ldr	x2, [x28, #56]
    77b8:	71004c1f 	cmp	w0, #0x13
    77bc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    77c0:	aa1403e0 	mov	x0, x20
    77c4:	8b010e61 	add	x1, x19, x1, lsl #3
    77c8:	f9400421 	ldr	x1, [x1, #8]
    77cc:	97ffffa9 	bl	7670 <fwp_write>
    77d0:	b9400380 	ldr	w0, [x28]
    77d4:	7100481f 	cmp	w0, #0x12
    77d8:	54004b40 	b.eq	8140 <fwp_write+0xad0>  // b.none
    77dc:	f9400260 	ldr	x0, [x19]
    77e0:	910006b5 	add	x21, x21, #0x1
    77e4:	91000ad6 	add	x22, x22, #0x2
    77e8:	eb15001f 	cmp	x0, x21
    77ec:	54004589 	b.ls	809c <fwp_write+0xa2c>  // b.plast
    77f0:	aa1703e1 	mov	x1, x23
    77f4:	aa1403e0 	mov	x0, x20
    77f8:	d2800042 	mov	x2, #0x2                   	// #2
    77fc:	97ffef65 	bl	3590 <buf_put>
    7800:	17ffffeb 	b	77ac <fwp_write+0x13c>
    7804:	d0000021 	adrp	x1, d000 <__divti3+0x2a0>
    7808:	91264021 	add	x1, x1, #0x990
    780c:	d28000c2 	mov	x2, #0x6                   	// #6
    7810:	aa1403e0 	mov	x0, x20
    7814:	91004273 	add	x19, x19, #0x10
    7818:	97ffef5e 	bl	3590 <buf_put>
    781c:	aa1303e0 	mov	x0, x19
    7820:	97ffebc0 	bl	2720 <strlen@plt>
    7824:	aa1303e1 	mov	x1, x19
    7828:	aa0003e2 	mov	x2, x0
    782c:	aa1403e0 	mov	x0, x20
    7830:	97ffef58 	bl	3590 <buf_put>
    7834:	528007c3 	mov	w3, #0x3e                  	// #62
    7838:	aa1403e0 	mov	x0, x20
    783c:	91001fe1 	add	x1, sp, #0x7
    7840:	d2800022 	mov	x2, #0x1                   	// #1
    7844:	39001fe3 	strb	w3, [sp, #7]
    7848:	17ffffb1 	b	770c <fwp_write+0x9c>
    784c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7850:	f947f400 	ldr	x0, [x0, #4072]
    7854:	f94127e2 	ldr	x2, [sp, #584]
    7858:	f9400001 	ldr	x1, [x0]
    785c:	eb010042 	subs	x2, x2, x1
    7860:	d2800001 	mov	x1, #0x0                   	// #0
    7864:	540034e1 	b.ne	7f00 <fwp_write+0x890>  // b.any
    7868:	f9413bf5 	ldr	x21, [sp, #624]
    786c:	d0000021 	adrp	x1, d000 <__divti3+0x2a0>
    7870:	f9413ff6 	ldr	x22, [sp, #632]
    7874:	aa1403e0 	mov	x0, x20
    7878:	9125c021 	add	x1, x1, #0x970
    787c:	d2800142 	mov	x2, #0xa                   	// #10
    7880:	f94153fb 	ldr	x27, [sp, #672]
    7884:	f94157fc 	ldr	x28, [sp, #680]
    7888:	910943ff 	add	sp, sp, #0x250
    788c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7890:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7894:	17ffef3f 	b	3590 <buf_put>
    7898:	f9400456 	ldr	x22, [x2, #8]
    789c:	f90143f7 	str	x23, [sp, #640]
    78a0:	f90147f8 	str	x24, [sp, #648]
    78a4:	b4005b16 	cbz	x22, 8404 <fwp_write+0xd94>
    78a8:	aa1603e0 	mov	x0, x22
    78ac:	d0000021 	adrp	x1, d000 <__divti3+0x2a0>
    78b0:	9127c021 	add	x1, x1, #0x9f0
    78b4:	97ffec17 	bl	2910 <strcmp@plt>
    78b8:	2a0003f5 	mov	w21, w0
    78bc:	34005fe0 	cbz	w0, 84b8 <fwp_write+0xe48>
    78c0:	aa1603e0 	mov	x0, x22
    78c4:	97ffeb97 	bl	2720 <strlen@plt>
    78c8:	aa1603e1 	mov	x1, x22
    78cc:	aa0003e2 	mov	x2, x0
    78d0:	aa1403e0 	mov	x0, x20
    78d4:	97ffef2f 	bl	3590 <buf_put>
    78d8:	52800403 	mov	w3, #0x20                  	// #32
    78dc:	91001ff5 	add	x21, sp, #0x7
    78e0:	aa1503e1 	mov	x1, x21
    78e4:	aa1403e0 	mov	x0, x20
    78e8:	d2800022 	mov	x2, #0x1                   	// #1
    78ec:	39001fe3 	strb	w3, [sp, #7]
    78f0:	97ffef28 	bl	3590 <buf_put>
    78f4:	52800f63 	mov	w3, #0x7b                  	// #123
    78f8:	aa1403e0 	mov	x0, x20
    78fc:	aa1503e1 	mov	x1, x21
    7900:	d2800022 	mov	x2, #0x1                   	// #1
    7904:	39001fe3 	strb	w3, [sp, #7]
    7908:	97ffef22 	bl	3590 <buf_put>
    790c:	b9401380 	ldr	w0, [x28, #16]
    7910:	52800018 	mov	w24, #0x0                   	// #0
    7914:	7100001f 	cmp	w0, #0x0
    7918:	54003aad 	b.le	806c <fwp_write+0x9fc>
    791c:	f9014bf9 	str	x25, [sp, #656]
    7920:	d0000039 	adrp	x25, d000 <__divti3+0x2a0>
    7924:	91286339 	add	x25, x25, #0xa18
    7928:	f9014ffa 	str	x26, [sp, #664]
    792c:	d000003a 	adrp	x26, d000 <__divti3+0x2a0>
    7930:	9127635a 	add	x26, x26, #0x9d8
    7934:	91002276 	add	x22, x19, #0x8
    7938:	d2800013 	mov	x19, #0x0                   	// #0
    793c:	b5003e93 	cbnz	x19, 810c <fwp_write+0xa9c>
    7940:	d37df277 	lsl	x23, x19, #3
    7944:	34003cb8 	cbz	w24, 80d8 <fwp_write+0xa68>
    7948:	f9401382 	ldr	x2, [x28, #32]
    794c:	aa1403e0 	mov	x0, x20
    7950:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7954:	52800003 	mov	w3, #0x0                   	// #0
    7958:	f8776842 	ldr	x2, [x2, x23]
    795c:	91000673 	add	x19, x19, #0x1
    7960:	97ffff44 	bl	7670 <fwp_write>
    7964:	b9401380 	ldr	w0, [x28, #16]
    7968:	6b13001f 	cmp	w0, w19
    796c:	54fffe8c 	b.gt	793c <fwp_write+0x2cc>
    7970:	f9414bf9 	ldr	x25, [sp, #656]
    7974:	f9414ffa 	ldr	x26, [sp, #664]
    7978:	340037b8 	cbz	w24, 806c <fwp_write+0x9fc>
    797c:	52800523 	mov	w3, #0x29                  	// #41
    7980:	aa1503e1 	mov	x1, x21
    7984:	aa1403e0 	mov	x0, x20
    7988:	d2800022 	mov	x2, #0x1                   	// #1
    798c:	39001fe3 	strb	w3, [sp, #7]
    7990:	97ffef00 	bl	3590 <buf_put>
    7994:	f9413bf5 	ldr	x21, [sp, #624]
    7998:	f9413ff6 	ldr	x22, [sp, #632]
    799c:	f94143f7 	ldr	x23, [sp, #640]
    79a0:	f94147f8 	ldr	x24, [sp, #648]
    79a4:	f94153fb 	ldr	x27, [sp, #672]
    79a8:	f94157fc 	ldr	x28, [sp, #680]
    79ac:	17ffff5d 	b	7720 <fwp_write+0xb0>
    79b0:	b9404855 	ldr	w21, [x2, #72]
    79b4:	aa1403e0 	mov	x0, x20
    79b8:	93407eb6 	sxtw	x22, w21
    79bc:	91000ac1 	add	x1, x22, #0x2
    79c0:	97ffeec0 	bl	34c0 <buf_grow>
    79c4:	a9400281 	ldp	x1, x0, [x20]
    79c8:	528e8603 	mov	w3, #0x7430                	// #29744
    79cc:	78206823 	strh	w3, [x1, x0]
    79d0:	8b000022 	add	x2, x1, x0
    79d4:	710002bf 	cmp	w21, #0x0
    79d8:	540036cd 	b.le	80b0 <fwp_write+0xa40>
    79dc:	110006a3 	add	w3, w21, #0x1
    79e0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    79e4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    79e8:	91000449 	add	x9, x2, #0x1
    79ec:	8b23c043 	add	x3, x2, w3, sxtw
    79f0:	f28aaac6 	movk	x6, #0x5556
    79f4:	f2955568 	movk	x8, #0xaaab
    79f8:	1400000d 	b	7a2c <fwp_write+0x3bc>
    79fc:	d2800021 	mov	x1, #0x1                   	// #1
    7a00:	528005a5 	mov	w5, #0x2d                  	// #45
    7a04:	f100001f 	cmp	x0, #0x0
    7a08:	9b467e60 	smulh	x0, x19, x6
    7a0c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7a10:	381ff465 	strb	w5, [x3], #-1
    7a14:	cb040000 	sub	x0, x0, x4
    7a18:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7a1c:	cb020000 	sub	x0, x0, x2
    7a20:	8b010013 	add	x19, x0, x1
    7a24:	eb03013f 	cmp	x9, x3
    7a28:	54003440 	b.eq	80b0 <fwp_write+0xa40>  // b.none
    7a2c:	9b467e60 	smulh	x0, x19, x6
    7a30:	937ffe64 	asr	x4, x19, #63
    7a34:	52800605 	mov	w5, #0x30                  	// #48
    7a38:	cb040000 	sub	x0, x0, x4
    7a3c:	8b000400 	add	x0, x0, x0, lsl #1
    7a40:	cb000260 	sub	x0, x19, x0
    7a44:	91000c01 	add	x1, x0, #0x3
    7a48:	9bc87c22 	umulh	x2, x1, x8
    7a4c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7a50:	8b4204e2 	add	x2, x7, x2, lsr #1
    7a54:	eb020021 	subs	x1, x1, x2
    7a58:	54fffd60 	b.eq	7a04 <fwp_write+0x394>  // b.none
    7a5c:	f100043f 	cmp	x1, #0x1
    7a60:	54fffce1 	b.ne	79fc <fwp_write+0x38c>  // b.any
    7a64:	d2800001 	mov	x1, #0x0                   	// #0
    7a68:	52800565 	mov	w5, #0x2b                  	// #43
    7a6c:	17ffffe6 	b	7a04 <fwp_write+0x394>
    7a70:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7a74:	f947f400 	ldr	x0, [x0, #4072]
    7a78:	f94127e2 	ldr	x2, [sp, #584]
    7a7c:	f9400001 	ldr	x1, [x0]
    7a80:	eb010042 	subs	x2, x2, x1
    7a84:	d2800001 	mov	x1, #0x0                   	// #0
    7a88:	540023c1 	b.ne	7f00 <fwp_write+0x890>  // b.any
    7a8c:	f9413bf5 	ldr	x21, [sp, #624]
    7a90:	d0000021 	adrp	x1, d000 <__divti3+0x2a0>
    7a94:	f9413ff6 	ldr	x22, [sp, #632]
    7a98:	aa1403e0 	mov	x0, x20
    7a9c:	91260021 	add	x1, x1, #0x980
    7aa0:	d2800102 	mov	x2, #0x8                   	// #8
    7aa4:	17ffff77 	b	7880 <fwp_write+0x210>
    7aa8:	aa1403e0 	mov	x0, x20
    7aac:	d0000021 	adrp	x1, d000 <__divti3+0x2a0>
    7ab0:	d28000c2 	mov	x2, #0x6                   	// #6
    7ab4:	91278021 	add	x1, x1, #0x9e0
    7ab8:	97ffeeb6 	bl	3590 <buf_put>
    7abc:	d2800015 	mov	x21, #0x0                   	// #0
    7ac0:	f9400263 	ldr	x3, [x19]
    7ac4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7ac8:	54002c60 	b.eq	8054 <fwp_write+0x9e4>  // b.none
    7acc:	f9401f82 	ldr	x2, [x28, #56]
    7ad0:	f90143f7 	str	x23, [sp, #640]
    7ad4:	f90147f8 	str	x24, [sp, #648]
    7ad8:	d2800857 	mov	x23, #0x42                  	// #66
    7adc:	f9014bf9 	str	x25, [sp, #656]
    7ae0:	d0000036 	adrp	x22, d000 <__divti3+0x2a0>
    7ae4:	f9014ffa 	str	x26, [sp, #664]
    7ae8:	912762d6 	add	x22, x22, #0x9d8
    7aec:	d2800038 	mov	x24, #0x1                   	// #1
    7af0:	f2a18017 	movk	x23, #0xc00, lsl #16
    7af4:	d2809099 	mov	x25, #0x484                 	// #1156
    7af8:	b40004a2 	cbz	x2, 7b8c <fwp_write+0x51c>
    7afc:	b9400040 	ldr	w0, [x2]
    7b00:	7100701f 	cmp	w0, #0x1c
    7b04:	540042c0 	b.eq	835c <fwp_write+0xcec>  // b.none
    7b08:	71006c1f 	cmp	w0, #0x1b
    7b0c:	54000408 	b.hi	7b8c <fwp_write+0x51c>  // b.pmore
    7b10:	9ac02301 	lsl	x1, x24, x0
    7b14:	ea17003f 	tst	x1, x23
    7b18:	540036a1 	b.ne	81ec <fwp_write+0xb7c>  // b.any
    7b1c:	ea19003f 	tst	x1, x25
    7b20:	54003521 	b.ne	81c4 <fwp_write+0xb54>  // b.any
    7b24:	d2800424 	mov	x4, #0x21                  	// #33
    7b28:	ea04003f 	tst	x1, x4
    7b2c:	54000300 	b.eq	7b8c <fwp_write+0x51c>  // b.none
    7b30:	b7f849c3 	tbnz	x3, #63, 8468 <fwp_write+0xdf8>
    7b34:	91002261 	add	x1, x19, #0x8
    7b38:	8b150021 	add	x1, x1, x21
    7b3c:	39400021 	ldrb	w1, [x1]
    7b40:	7100001f 	cmp	w0, #0x0
    7b44:	93401c23 	sxtb	x3, w1
    7b48:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7b4c:	d503201f 	nop
    7b50:	aa1403e0 	mov	x0, x20
    7b54:	52800003 	mov	w3, #0x0                   	// #0
    7b58:	97fffec6 	bl	7670 <fwp_write>
    7b5c:	910006b5 	add	x21, x21, #0x1
    7b60:	f9400260 	ldr	x0, [x19]
    7b64:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7b68:	eb0002bf 	cmp	x21, x0
    7b6c:	540026c2 	b.cs	8044 <fwp_write+0x9d4>  // b.hs, b.nlast
    7b70:	d2800042 	mov	x2, #0x2                   	// #2
    7b74:	aa1603e1 	mov	x1, x22
    7b78:	aa1403e0 	mov	x0, x20
    7b7c:	97ffee85 	bl	3590 <buf_put>
    7b80:	f9401f82 	ldr	x2, [x28, #56]
    7b84:	f9400263 	ldr	x3, [x19]
    7b88:	b5fffba2 	cbnz	x2, 7afc <fwp_write+0x48c>
    7b8c:	d37df2a0 	lsl	x0, x21, #3
    7b90:	b7f83f03 	tbnz	x3, #63, 8370 <fwp_write+0xd00>
    7b94:	91002261 	add	x1, x19, #0x8
    7b98:	8b000020 	add	x0, x1, x0
    7b9c:	f9400001 	ldr	x1, [x0]
    7ba0:	17ffffec 	b	7b50 <fwp_write+0x4e0>
    7ba4:	a9400e62 	ldp	x2, x3, [x19]
    7ba8:	b7f83ca3 	tbnz	x3, #63, 833c <fwp_write+0xccc>
    7bac:	910123f5 	add	x21, sp, #0x48
    7bb0:	aa1503e0 	mov	x0, x21
    7bb4:	97ffec9b 	bl	2e20 <fwp_fmt_u128>
    7bb8:	aa1503e0 	mov	x0, x21
    7bbc:	97ffead9 	bl	2720 <strlen@plt>
    7bc0:	aa1503e1 	mov	x1, x21
    7bc4:	aa0003e2 	mov	x2, x0
    7bc8:	17fffed0 	b	7708 <fwp_write+0x98>
    7bcc:	fd015be8 	str	d8, [sp, #688]
    7bd0:	1e270268 	fmov	s8, w19
    7bd4:	fd015fe9 	str	d9, [sp, #696]
    7bd8:	1e282100 	fcmp	s8, s8
    7bdc:	54004d26 	b.vs	8580 <fwp_write+0xf10>
    7be0:	1e20c101 	fabs	s1, s8
    7be4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7be8:	1e270000 	fmov	s0, w0
    7bec:	1e202020 	fcmp	s1, s0
    7bf0:	54002c0d 	b.le	8170 <fwp_write+0xb00>
    7bf4:	1e202118 	fcmpe	s8, #0.0
    7bf8:	d0000022 	adrp	x2, d000 <__divti3+0x2a0>
    7bfc:	91156042 	add	x2, x2, #0x558
    7c00:	910123f5 	add	x21, sp, #0x48
    7c04:	d0000021 	adrp	x1, d000 <__divti3+0x2a0>
    7c08:	9124c021 	add	x1, x1, #0x930
    7c0c:	aa1503e0 	mov	x0, x21
    7c10:	9a81c041 	csel	x1, x2, x1, gt
    7c14:	97ffeb6f 	bl	29d0 <strcpy@plt>
    7c18:	aa1503e0 	mov	x0, x21
    7c1c:	97ffeac1 	bl	2720 <strlen@plt>
    7c20:	aa1503e1 	mov	x1, x21
    7c24:	aa0003e2 	mov	x2, x0
    7c28:	aa1403e0 	mov	x0, x20
    7c2c:	97ffee59 	bl	3590 <buf_put>
    7c30:	f9413bf5 	ldr	x21, [sp, #624]
    7c34:	f9413ff6 	ldr	x22, [sp, #632]
    7c38:	f94153fb 	ldr	x27, [sp, #672]
    7c3c:	f94157fc 	ldr	x28, [sp, #680]
    7c40:	fd415be8 	ldr	d8, [sp, #688]
    7c44:	fd415fe9 	ldr	d9, [sp, #696]
    7c48:	17fffeb6 	b	7720 <fwp_write+0xb0>
    7c4c:	f9400276 	ldr	x22, [x19]
    7c50:	34002e03 	cbz	w3, 8210 <fwp_write+0xba0>
    7c54:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7c58:	f947f400 	ldr	x0, [x0, #4072]
    7c5c:	f94127e2 	ldr	x2, [sp, #584]
    7c60:	f9400001 	ldr	x1, [x0]
    7c64:	eb010042 	subs	x2, x2, x1
    7c68:	d2800001 	mov	x1, #0x0                   	// #0
    7c6c:	540014a1 	b.ne	7f00 <fwp_write+0x890>  // b.any
    7c70:	aa1603e2 	mov	x2, x22
    7c74:	91002261 	add	x1, x19, #0x8
    7c78:	f9413bf5 	ldr	x21, [sp, #624]
    7c7c:	aa1403e0 	mov	x0, x20
    7c80:	f9413ff6 	ldr	x22, [sp, #632]
    7c84:	17fffeff 	b	7880 <fwp_write+0x210>
    7c88:	fd015be8 	str	d8, [sp, #688]
    7c8c:	9e670268 	fmov	d8, x19
    7c90:	fd015fe9 	str	d9, [sp, #696]
    7c94:	1e682100 	fcmp	d8, d8
    7c98:	54004746 	b.vs	8580 <fwp_write+0xf10>
    7c9c:	1e60c101 	fabs	d1, d8
    7ca0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7ca4:	9e670000 	fmov	d0, x0
    7ca8:	910123f5 	add	x21, sp, #0x48
    7cac:	52800033 	mov	w19, #0x1                   	// #1
    7cb0:	1e602020 	fcmp	d1, d0
    7cb4:	540001ad 	b.le	7ce8 <fwp_write+0x678>
    7cb8:	1e602118 	fcmpe	d8, #0.0
    7cbc:	d0000022 	adrp	x2, d000 <__divti3+0x2a0>
    7cc0:	91156042 	add	x2, x2, #0x558
    7cc4:	d0000021 	adrp	x1, d000 <__divti3+0x2a0>
    7cc8:	9124c021 	add	x1, x1, #0x930
    7ccc:	aa1503e0 	mov	x0, x21
    7cd0:	9a81c041 	csel	x1, x2, x1, gt
    7cd4:	97ffeb3f 	bl	29d0 <strcpy@plt>
    7cd8:	17ffffd0 	b	7c18 <fwp_write+0x5a8>
    7cdc:	11000673 	add	w19, w19, #0x1
    7ce0:	71004a7f 	cmp	w19, #0x12
    7ce4:	54003860 	b.eq	83f0 <fwp_write+0xd80>  // b.none
    7ce8:	1e604100 	fmov	d0, d8
    7cec:	2a1303e1 	mov	w1, w19
    7cf0:	aa1503e0 	mov	x0, x21
    7cf4:	97ffeec3 	bl	3800 <fwp_format_g.constprop.0>
    7cf8:	aa1503e0 	mov	x0, x21
    7cfc:	d2800001 	mov	x1, #0x0                   	// #0
    7d00:	97ffea9c 	bl	2770 <strtod@plt>
    7d04:	1e602100 	fcmp	d8, d0
    7d08:	54fffea1 	b.ne	7cdc <fwp_write+0x66c>  // b.any
    7d0c:	aa1503e0 	mov	x0, x21
    7d10:	97ffee99 	bl	3774 <fwp_finish_float>
    7d14:	17ffffc1 	b	7c18 <fwp_write+0x5a8>
    7d18:	a9400e62 	ldp	x2, x3, [x19]
    7d1c:	910123f3 	add	x19, sp, #0x48
    7d20:	aa1303e0 	mov	x0, x19
    7d24:	97ffec3f 	bl	2e20 <fwp_fmt_u128>
    7d28:	17fffe74 	b	76f8 <fwp_write+0x88>
    7d2c:	f90143f7 	str	x23, [sp, #640]
    7d30:	f90147f8 	str	x24, [sp, #648]
    7d34:	2a1303f8 	mov	w24, w19
    7d38:	f9014bf9 	str	x25, [sp, #656]
    7d3c:	f9014ffa 	str	x26, [sp, #664]
    7d40:	f13ffe7f 	cmp	x19, #0xfff
    7d44:	54000049 	b.ls	7d4c <fwp_write+0x6dc>  // b.plast
    7d48:	b9400278 	ldr	w24, [x19]
    7d4c:	f9400f80 	ldr	x0, [x28, #24]
    7d50:	2a1803f5 	mov	w21, w24
    7d54:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7d58:	d37ef6b9 	lsl	x25, x21, #2
    7d5c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7d60:	aa1603e0 	mov	x0, x22
    7d64:	97ffea6f 	bl	2720 <strlen@plt>
    7d68:	aa1603e1 	mov	x1, x22
    7d6c:	aa0003e2 	mov	x2, x0
    7d70:	aa1403e0 	mov	x0, x20
    7d74:	97ffee07 	bl	3590 <buf_put>
    7d78:	f9401780 	ldr	x0, [x28, #40]
    7d7c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7d80:	7100001f 	cmp	w0, #0x0
    7d84:	5400068d 	b.le	7e54 <fwp_write+0x7e4>
    7d88:	91002276 	add	x22, x19, #0x8
    7d8c:	91001ff5 	add	x21, sp, #0x7
    7d90:	d280001b 	mov	x27, #0x0                   	// #0
    7d94:	5280041a 	mov	w26, #0x20                  	// #32
    7d98:	f9401b80 	ldr	x0, [x28, #48]
    7d9c:	aa1503e1 	mov	x1, x21
    7da0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7da4:	d2800022 	mov	x2, #0x1                   	// #1
    7da8:	f8786803 	ldr	x3, [x0, x24]
    7dac:	aa1403e0 	mov	x0, x20
    7db0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7db4:	39001ffa 	strb	w26, [sp, #7]
    7db8:	97ffedf6 	bl	3590 <buf_put>
    7dbc:	f13ffeff 	cmp	x23, #0xfff
    7dc0:	b9400261 	ldr	w1, [x19]
    7dc4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7dc8:	7100383f 	cmp	w1, #0xe
    7dcc:	54000160 	b.eq	7df8 <fwp_write+0x788>  // b.none
    7dd0:	7100403f 	cmp	w1, #0x10
    7dd4:	54001a60 	b.eq	8120 <fwp_write+0xab0>  // b.none
    7dd8:	7100283f 	cmp	w1, #0xa
    7ddc:	54002aa0 	b.eq	8330 <fwp_write+0xcc0>  // b.none
    7de0:	540014ac 	b.gt	8074 <fwp_write+0xa04>
    7de4:	71000c3f 	cmp	w1, #0x3
    7de8:	540029ac 	b.gt	831c <fwp_write+0xcac>
    7dec:	d37ffee0 	lsr	x0, x23, #63
    7df0:	37f814a1 	tbnz	w1, #31, 8084 <fwp_write+0xa14>
    7df4:	d503201f 	nop
    7df8:	34001460 	cbz	w0, 8084 <fwp_write+0xa14>
    7dfc:	52800503 	mov	w3, #0x28                  	// #40
    7e00:	aa1503e1 	mov	x1, x21
    7e04:	aa1403e0 	mov	x0, x20
    7e08:	d2800022 	mov	x2, #0x1                   	// #1
    7e0c:	39001fe3 	strb	w3, [sp, #7]
    7e10:	97ffede0 	bl	3590 <buf_put>
    7e14:	aa1303e2 	mov	x2, x19
    7e18:	aa1703e1 	mov	x1, x23
    7e1c:	aa1403e0 	mov	x0, x20
    7e20:	52800003 	mov	w3, #0x0                   	// #0
    7e24:	97fffe13 	bl	7670 <fwp_write>
    7e28:	52800523 	mov	w3, #0x29                  	// #41
    7e2c:	aa1503e1 	mov	x1, x21
    7e30:	aa1403e0 	mov	x0, x20
    7e34:	d2800022 	mov	x2, #0x1                   	// #1
    7e38:	39001fe3 	strb	w3, [sp, #7]
    7e3c:	97ffedd5 	bl	3590 <buf_put>
    7e40:	f9401780 	ldr	x0, [x28, #40]
    7e44:	9100077b 	add	x27, x27, #0x1
    7e48:	b8796800 	ldr	w0, [x0, x25]
    7e4c:	6b1b001f 	cmp	w0, w27
    7e50:	54fffa4c 	b.gt	7d98 <fwp_write+0x728>
    7e54:	f9413bf5 	ldr	x21, [sp, #624]
    7e58:	f9413ff6 	ldr	x22, [sp, #632]
    7e5c:	f94143f7 	ldr	x23, [sp, #640]
    7e60:	f94147f8 	ldr	x24, [sp, #648]
    7e64:	f9414bf9 	ldr	x25, [sp, #656]
    7e68:	f9414ffa 	ldr	x26, [sp, #664]
    7e6c:	f94153fb 	ldr	x27, [sp, #672]
    7e70:	f94157fc 	ldr	x28, [sp, #680]
    7e74:	17fffe2b 	b	7720 <fwp_write+0xb0>
    7e78:	52800783 	mov	w3, #0x3c                  	// #60
    7e7c:	91001ff3 	add	x19, sp, #0x7
    7e80:	aa1303e1 	mov	x1, x19
    7e84:	d2800022 	mov	x2, #0x1                   	// #1
    7e88:	aa1403e0 	mov	x0, x20
    7e8c:	39001fe3 	strb	w3, [sp, #7]
    7e90:	97ffedc0 	bl	3590 <buf_put>
    7e94:	f9400795 	ldr	x21, [x28, #8]
    7e98:	aa1503e0 	mov	x0, x21
    7e9c:	97ffea21 	bl	2720 <strlen@plt>
    7ea0:	aa1503e1 	mov	x1, x21
    7ea4:	aa0003e2 	mov	x2, x0
    7ea8:	aa1403e0 	mov	x0, x20
    7eac:	97ffedb9 	bl	3590 <buf_put>
    7eb0:	528007c3 	mov	w3, #0x3e                  	// #62
    7eb4:	aa1303e1 	mov	x1, x19
    7eb8:	aa1403e0 	mov	x0, x20
    7ebc:	d2800022 	mov	x2, #0x1                   	// #1
    7ec0:	39001fe3 	strb	w3, [sp, #7]
    7ec4:	17fffe12 	b	770c <fwp_write+0x9c>
    7ec8:	f100067f 	cmp	x19, #0x1
    7ecc:	540025a0 	b.eq	8380 <fwp_write+0xd10>  // b.none
    7ed0:	b100067f 	cmn	x19, #0x1
    7ed4:	54002bc0 	b.eq	844c <fwp_write+0xddc>  // b.none
    7ed8:	d0000021 	adrp	x1, d000 <__divti3+0x2a0>
    7edc:	9124e021 	add	x1, x1, #0x938
    7ee0:	d2800022 	mov	x2, #0x1                   	// #1
    7ee4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7ee8:	f947f400 	ldr	x0, [x0, #4072]
    7eec:	f94127e4 	ldr	x4, [sp, #584]
    7ef0:	f9400003 	ldr	x3, [x0]
    7ef4:	eb030084 	subs	x4, x4, x3
    7ef8:	d2800003 	mov	x3, #0x0                   	// #0
    7efc:	54ffebe0 	b.eq	7c78 <fwp_write+0x608>  // b.none
    7f00:	f90143f7 	str	x23, [sp, #640]
    7f04:	f90147f8 	str	x24, [sp, #648]
    7f08:	f9014bf9 	str	x25, [sp, #656]
    7f0c:	f9014ffa 	str	x26, [sp, #664]
    7f10:	fd015be8 	str	d8, [sp, #688]
    7f14:	fd015fe9 	str	d9, [sp, #696]
    7f18:	97ffea5e 	bl	2890 <__stack_chk_fail@plt>
    7f1c:	52800b63 	mov	w3, #0x5b                  	// #91
    7f20:	91001ff5 	add	x21, sp, #0x7
    7f24:	aa1503e1 	mov	x1, x21
    7f28:	aa1403e0 	mov	x0, x20
    7f2c:	d2800022 	mov	x2, #0x1                   	// #1
    7f30:	d0000036 	adrp	x22, d000 <__divti3+0x2a0>
    7f34:	912762d6 	add	x22, x22, #0x9d8
    7f38:	39001fe3 	strb	w3, [sp, #7]
    7f3c:	97ffed95 	bl	3590 <buf_put>
    7f40:	b4000273 	cbz	x19, 7f8c <fwp_write+0x91c>
    7f44:	f9400661 	ldr	x1, [x19, #8]
    7f48:	aa1403e0 	mov	x0, x20
    7f4c:	f9401f82 	ldr	x2, [x28, #56]
    7f50:	52800003 	mov	w3, #0x0                   	// #0
    7f54:	97fffdc7 	bl	7670 <fwp_write>
    7f58:	f9400a73 	ldr	x19, [x19, #16]
    7f5c:	b4000193 	cbz	x19, 7f8c <fwp_write+0x91c>
    7f60:	aa1603e1 	mov	x1, x22
    7f64:	aa1403e0 	mov	x0, x20
    7f68:	d2800042 	mov	x2, #0x2                   	// #2
    7f6c:	97ffed89 	bl	3590 <buf_put>
    7f70:	f9400661 	ldr	x1, [x19, #8]
    7f74:	aa1403e0 	mov	x0, x20
    7f78:	f9401f82 	ldr	x2, [x28, #56]
    7f7c:	52800003 	mov	w3, #0x0                   	// #0
    7f80:	97fffdbc 	bl	7670 <fwp_write>
    7f84:	f9400a73 	ldr	x19, [x19, #16]
    7f88:	b5fffed3 	cbnz	x19, 7f60 <fwp_write+0x8f0>
    7f8c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7f90:	aa1503e1 	mov	x1, x21
    7f94:	aa1403e0 	mov	x0, x20
    7f98:	d2800022 	mov	x2, #0x1                   	// #1
    7f9c:	39001fe3 	strb	w3, [sp, #7]
    7fa0:	17fffddb 	b	770c <fwp_write+0x9c>
    7fa4:	aa1403e0 	mov	x0, x20
    7fa8:	d0000021 	adrp	x1, d000 <__divti3+0x2a0>
    7fac:	d28000c2 	mov	x2, #0x6                   	// #6
    7fb0:	91272021 	add	x1, x1, #0x9c8
    7fb4:	97ffed77 	bl	3590 <buf_put>
    7fb8:	f9400260 	ldr	x0, [x19]
    7fbc:	b40004c0 	cbz	x0, 8054 <fwp_write+0x9e4>
    7fc0:	910123f5 	add	x21, sp, #0x48
    7fc4:	91002276 	add	x22, x19, #0x8
    7fc8:	f90143f7 	str	x23, [sp, #640]
    7fcc:	d2800017 	mov	x23, #0x0                   	// #0
    7fd0:	f90147f8 	str	x24, [sp, #648]
    7fd4:	d0000038 	adrp	x24, d000 <__divti3+0x2a0>
    7fd8:	91274318 	add	x24, x24, #0x9d0
    7fdc:	f9014bf9 	str	x25, [sp, #656]
    7fe0:	d0000039 	adrp	x25, d000 <__divti3+0x2a0>
    7fe4:	91276339 	add	x25, x25, #0x9d8
    7fe8:	f9014ffa 	str	x26, [sp, #664]
    7fec:	14000005 	b	8000 <fwp_write+0x990>
    7ff0:	aa1903e1 	mov	x1, x25
    7ff4:	aa1403e0 	mov	x0, x20
    7ff8:	d2800042 	mov	x2, #0x2                   	// #2
    7ffc:	97ffed65 	bl	3590 <buf_put>
    8000:	38776ac5 	ldrb	w5, [x22, x23]
    8004:	d2804003 	mov	x3, #0x200                 	// #512
    8008:	aa1803e4 	mov	x4, x24
    800c:	aa0303e1 	mov	x1, x3
    8010:	52800042 	mov	w2, #0x2                   	// #2
    8014:	aa1503e0 	mov	x0, x21
    8018:	910006f7 	add	x23, x23, #0x1
    801c:	97ffe9f9 	bl	2800 <__snprintf_chk@plt>
    8020:	aa1503e0 	mov	x0, x21
    8024:	97ffe9bf 	bl	2720 <strlen@plt>
    8028:	aa1503e1 	mov	x1, x21
    802c:	aa0003e2 	mov	x2, x0
    8030:	aa1403e0 	mov	x0, x20
    8034:	97ffed57 	bl	3590 <buf_put>
    8038:	f9400260 	ldr	x0, [x19]
    803c:	eb17001f 	cmp	x0, x23
    8040:	54fffd88 	b.hi	7ff0 <fwp_write+0x980>  // b.pmore
    8044:	f94143f7 	ldr	x23, [sp, #640]
    8048:	f94147f8 	ldr	x24, [sp, #648]
    804c:	f9414bf9 	ldr	x25, [sp, #656]
    8050:	f9414ffa 	ldr	x26, [sp, #664]
    8054:	52800ba3 	mov	w3, #0x5d                  	// #93
    8058:	aa1403e0 	mov	x0, x20
    805c:	91001fe1 	add	x1, sp, #0x7
    8060:	d2800022 	mov	x2, #0x1                   	// #1
    8064:	39001fe3 	strb	w3, [sp, #7]
    8068:	17fffda9 	b	770c <fwp_write+0x9c>
    806c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8070:	17fffe44 	b	7980 <fwp_write+0x310>
    8074:	f10002ff 	cmp	x23, #0x0
    8078:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    807c:	71002c3f 	cmp	w1, #0xb
    8080:	54ffebc0 	b.eq	7df8 <fwp_write+0x788>  // b.none
    8084:	aa1303e2 	mov	x2, x19
    8088:	aa1703e1 	mov	x1, x23
    808c:	aa1403e0 	mov	x0, x20
    8090:	52800003 	mov	w3, #0x0                   	// #0
    8094:	97fffd77 	bl	7670 <fwp_write>
    8098:	17ffff6a 	b	7e40 <fwp_write+0x7d0>
    809c:	aa1403e0 	mov	x0, x20
    80a0:	91001fe1 	add	x1, sp, #0x7
    80a4:	52800fa3 	mov	w3, #0x7d                  	// #125
    80a8:	d2800022 	mov	x2, #0x1                   	// #1
    80ac:	17fffe38 	b	798c <fwp_write+0x31c>
    80b0:	a9400281 	ldp	x1, x0, [x20]
    80b4:	91000800 	add	x0, x0, #0x2
    80b8:	8b160000 	add	x0, x0, x22
    80bc:	f9000680 	str	x0, [x20, #8]
    80c0:	3820683f 	strb	wzr, [x1, x0]
    80c4:	f9413bf5 	ldr	x21, [sp, #624]
    80c8:	f9413ff6 	ldr	x22, [sp, #632]
    80cc:	f94153fb 	ldr	x27, [sp, #672]
    80d0:	f94157fc 	ldr	x28, [sp, #680]
    80d4:	17fffd93 	b	7720 <fwp_write+0xb0>
    80d8:	f9400f80 	ldr	x0, [x28, #24]
    80dc:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    80e0:	aa1b03e0 	mov	x0, x27
    80e4:	97ffe98f 	bl	2720 <strlen@plt>
    80e8:	aa1b03e1 	mov	x1, x27
    80ec:	aa0003e2 	mov	x2, x0
    80f0:	aa1403e0 	mov	x0, x20
    80f4:	97ffed27 	bl	3590 <buf_put>
    80f8:	aa1903e1 	mov	x1, x25
    80fc:	aa1403e0 	mov	x0, x20
    8100:	d2800062 	mov	x2, #0x3                   	// #3
    8104:	97ffed23 	bl	3590 <buf_put>
    8108:	17fffe10 	b	7948 <fwp_write+0x2d8>
    810c:	aa1a03e1 	mov	x1, x26
    8110:	aa1403e0 	mov	x0, x20
    8114:	d2800042 	mov	x2, #0x2                   	// #2
    8118:	97ffed1e 	bl	3590 <buf_put>
    811c:	17fffe09 	b	7940 <fwp_write+0x2d0>
    8120:	f9400660 	ldr	x0, [x19, #8]
    8124:	b4fffb00 	cbz	x0, 8084 <fwp_write+0xa14>
    8128:	b0000021 	adrp	x1, d000 <__divti3+0x2a0>
    812c:	9127c021 	add	x1, x1, #0x9f0
    8130:	97ffe9f8 	bl	2910 <strcmp@plt>
    8134:	7100001f 	cmp	w0, #0x0
    8138:	1a9f07e0 	cset	w0, ne	// ne = any
    813c:	17ffff2f 	b	7df8 <fwp_write+0x788>
    8140:	aa1403e0 	mov	x0, x20
    8144:	d2800042 	mov	x2, #0x2                   	// #2
    8148:	b0000021 	adrp	x1, d000 <__divti3+0x2a0>
    814c:	9127a021 	add	x1, x1, #0x9e8
    8150:	97ffed10 	bl	3590 <buf_put>
    8154:	91004261 	add	x1, x19, #0x10
    8158:	aa1403e0 	mov	x0, x20
    815c:	f9402382 	ldr	x2, [x28, #64]
    8160:	52800003 	mov	w3, #0x0                   	// #0
    8164:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8168:	97fffd42 	bl	7670 <fwp_write>
    816c:	17fffd9c 	b	77dc <fwp_write+0x16c>
    8170:	1e22c109 	fcvt	d9, s8
    8174:	910123f5 	add	x21, sp, #0x48
    8178:	52800033 	mov	w19, #0x1                   	// #1
    817c:	d503201f 	nop
    8180:	1e604120 	fmov	d0, d9
    8184:	2a1303e1 	mov	w1, w19
    8188:	aa1503e0 	mov	x0, x21
    818c:	97ffed9d 	bl	3800 <fwp_format_g.constprop.0>
    8190:	aa1503e0 	mov	x0, x21
    8194:	d2800001 	mov	x1, #0x0                   	// #0
    8198:	97ffe9ea 	bl	2940 <strtof@plt>
    819c:	1e202100 	fcmp	s8, s0
    81a0:	54ffdb60 	b.eq	7d0c <fwp_write+0x69c>  // b.none
    81a4:	11000673 	add	w19, w19, #0x1
    81a8:	71002a7f 	cmp	w19, #0xa
    81ac:	54fffea1 	b.ne	8180 <fwp_write+0xb10>  // b.any
    81b0:	1e604120 	fmov	d0, d9
    81b4:	aa1503e0 	mov	x0, x21
    81b8:	52800121 	mov	w1, #0x9                   	// #9
    81bc:	97ffed91 	bl	3800 <fwp_format_g.constprop.0>
    81c0:	17fffed3 	b	7d0c <fwp_write+0x69c>
    81c4:	d37ef6a1 	lsl	x1, x21, #2
    81c8:	b7f81563 	tbnz	x3, #63, 8474 <fwp_write+0xe04>
    81cc:	91002263 	add	x3, x19, #0x8
    81d0:	8b010061 	add	x1, x3, x1
    81d4:	b9400023 	ldr	w3, [x1]
    81d8:	7100081f 	cmp	w0, #0x2
    81dc:	2a0303e1 	mov	w1, w3
    81e0:	93407c63 	sxtw	x3, w3
    81e4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    81e8:	17fffe5a 	b	7b50 <fwp_write+0x4e0>
    81ec:	d37ffaa1 	lsl	x1, x21, #1
    81f0:	b7f81363 	tbnz	x3, #63, 845c <fwp_write+0xdec>
    81f4:	91002263 	add	x3, x19, #0x8
    81f8:	8b010061 	add	x1, x3, x1
    81fc:	79400021 	ldrh	w1, [x1]
    8200:	7100041f 	cmp	w0, #0x1
    8204:	93403c23 	sxth	x3, w1
    8208:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    820c:	17fffe51 	b	7b50 <fwp_write+0x4e0>
    8210:	52800443 	mov	w3, #0x22                  	// #34
    8214:	91001ff5 	add	x21, sp, #0x7
    8218:	91002273 	add	x19, x19, #0x8
    821c:	aa1503e1 	mov	x1, x21
    8220:	aa1403e0 	mov	x0, x20
    8224:	d2800022 	mov	x2, #0x1                   	// #1
    8228:	39001fe3 	strb	w3, [sp, #7]
    822c:	f90143f7 	str	x23, [sp, #640]
    8230:	8b160277 	add	x23, x19, x22
    8234:	f90147f8 	str	x24, [sp, #648]
    8238:	97ffecd6 	bl	3590 <buf_put>
    823c:	b4000696 	cbz	x22, 830c <fwp_write+0xc9c>
    8240:	b0000038 	adrp	x24, d000 <__divti3+0x2a0>
    8244:	91266318 	add	x24, x24, #0x998
    8248:	f9014bf9 	str	x25, [sp, #656]
    824c:	b0000039 	adrp	x25, d000 <__divti3+0x2a0>
    8250:	9126e339 	add	x25, x25, #0x9b8
    8254:	f9014ffa 	str	x26, [sp, #664]
    8258:	1400000d 	b	828c <fwp_write+0xc1c>
    825c:	710024bf 	cmp	w5, #0x9
    8260:	54000460 	b.eq	82ec <fwp_write+0xc7c>  // b.none
    8264:	710028bf 	cmp	w5, #0xa
    8268:	54000a61 	b.ne	83b4 <fwp_write+0xd44>  // b.any
    826c:	b0000021 	adrp	x1, d000 <__divti3+0x2a0>
    8270:	aa1403e0 	mov	x0, x20
    8274:	9126a021 	add	x1, x1, #0x9a8
    8278:	d2800042 	mov	x2, #0x2                   	// #2
    827c:	97ffecc5 	bl	3590 <buf_put>
    8280:	91000673 	add	x19, x19, #0x1
    8284:	eb17027f 	cmp	x19, x23
    8288:	540003e0 	b.eq	8304 <fwp_write+0xc94>  // b.none
    828c:	39400265 	ldrb	w5, [x19]
    8290:	710034bf 	cmp	w5, #0xd
    8294:	54000180 	b.eq	82c4 <fwp_write+0xc54>  // b.none
    8298:	54fffe29 	b.ls	825c <fwp_write+0xbec>  // b.plast
    829c:	710088bf 	cmp	w5, #0x22
    82a0:	540001c0 	b.eq	82d8 <fwp_write+0xc68>  // b.none
    82a4:	710170bf 	cmp	w5, #0x5c
    82a8:	54000741 	b.ne	8390 <fwp_write+0xd20>  // b.any
    82ac:	aa1403e0 	mov	x0, x20
    82b0:	b0000021 	adrp	x1, d000 <__divti3+0x2a0>
    82b4:	d2800042 	mov	x2, #0x2                   	// #2
    82b8:	91268021 	add	x1, x1, #0x9a0
    82bc:	97ffecb5 	bl	3590 <buf_put>
    82c0:	17fffff0 	b	8280 <fwp_write+0xc10>
    82c4:	aa1903e1 	mov	x1, x25
    82c8:	aa1403e0 	mov	x0, x20
    82cc:	d2800042 	mov	x2, #0x2                   	// #2
    82d0:	97ffecb0 	bl	3590 <buf_put>
    82d4:	17ffffeb 	b	8280 <fwp_write+0xc10>
    82d8:	aa1803e1 	mov	x1, x24
    82dc:	aa1403e0 	mov	x0, x20
    82e0:	d2800042 	mov	x2, #0x2                   	// #2
    82e4:	97ffecab 	bl	3590 <buf_put>
    82e8:	17ffffe6 	b	8280 <fwp_write+0xc10>
    82ec:	aa1403e0 	mov	x0, x20
    82f0:	b0000021 	adrp	x1, d000 <__divti3+0x2a0>
    82f4:	d2800042 	mov	x2, #0x2                   	// #2
    82f8:	9126c021 	add	x1, x1, #0x9b0
    82fc:	97ffeca5 	bl	3590 <buf_put>
    8300:	17ffffe0 	b	8280 <fwp_write+0xc10>
    8304:	f9414bf9 	ldr	x25, [sp, #656]
    8308:	f9414ffa 	ldr	x26, [sp, #664]
    830c:	aa1503e1 	mov	x1, x21
    8310:	aa1403e0 	mov	x0, x20
    8314:	52800443 	mov	w3, #0x22                  	// #34
    8318:	17fffd9c 	b	7988 <fwp_write+0x318>
    831c:	7100103f 	cmp	w1, #0x4
    8320:	54ffeb21 	b.ne	8084 <fwp_write+0xa14>  // b.any
    8324:	f94006e0 	ldr	x0, [x23, #8]
    8328:	d37ffc00 	lsr	x0, x0, #63
    832c:	17fffeb3 	b	7df8 <fwp_write+0x788>
    8330:	710002ff 	cmp	w23, #0x0
    8334:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8338:	17fffeb0 	b	7df8 <fwp_write+0x788>
    833c:	528005a1 	mov	w1, #0x2d                  	// #45
    8340:	eb0203e2 	negs	x2, x2
    8344:	da0303e3 	ngc	x3, x3
    8348:	910127e0 	add	x0, sp, #0x49
    834c:	910123f5 	add	x21, sp, #0x48
    8350:	390123e1 	strb	w1, [sp, #72]
    8354:	97ffeab3 	bl	2e20 <fwp_fmt_u128>
    8358:	17fffe18 	b	7bb8 <fwp_write+0x548>
    835c:	d37ceea1 	lsl	x1, x21, #4
    8360:	b7f810a3 	tbnz	x3, #63, 8574 <fwp_write+0xf04>
    8364:	91002260 	add	x0, x19, #0x8
    8368:	8b010001 	add	x1, x0, x1
    836c:	17fffdf9 	b	7b50 <fwp_write+0x4e0>
    8370:	f9400a61 	ldr	x1, [x19, #16]
    8374:	8b010000 	add	x0, x0, x1
    8378:	f9400001 	ldr	x1, [x0]
    837c:	17fffdf5 	b	7b50 <fwp_write+0x4e0>
    8380:	b0000021 	adrp	x1, d000 <__divti3+0x2a0>
    8384:	d2800042 	mov	x2, #0x2                   	// #2
    8388:	91250021 	add	x1, x1, #0x940
    838c:	17fffed6 	b	7ee4 <fwp_write+0x874>
    8390:	7101fcbf 	cmp	w5, #0x7f
    8394:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8398:	540000e9 	b.ls	83b4 <fwp_write+0xd44>  // b.plast
    839c:	aa1503e1 	mov	x1, x21
    83a0:	aa1403e0 	mov	x0, x20
    83a4:	d2800022 	mov	x2, #0x1                   	// #1
    83a8:	39001fe5 	strb	w5, [sp, #7]
    83ac:	97ffec79 	bl	3590 <buf_put>
    83b0:	17ffffb4 	b	8280 <fwp_write+0xc10>
    83b4:	d2800203 	mov	x3, #0x10                  	// #16
    83b8:	b0000024 	adrp	x4, d000 <__divti3+0x2a0>
    83bc:	aa0303e1 	mov	x1, x3
    83c0:	91270084 	add	x4, x4, #0x9c0
    83c4:	910123f6 	add	x22, sp, #0x48
    83c8:	52800042 	mov	w2, #0x2                   	// #2
    83cc:	aa1603e0 	mov	x0, x22
    83d0:	97ffe90c 	bl	2800 <__snprintf_chk@plt>
    83d4:	aa1603e0 	mov	x0, x22
    83d8:	97ffe8d2 	bl	2720 <strlen@plt>
    83dc:	aa1603e1 	mov	x1, x22
    83e0:	aa0003e2 	mov	x2, x0
    83e4:	aa1403e0 	mov	x0, x20
    83e8:	97ffec6a 	bl	3590 <buf_put>
    83ec:	17ffffa5 	b	8280 <fwp_write+0xc10>
    83f0:	1e604100 	fmov	d0, d8
    83f4:	aa1503e0 	mov	x0, x21
    83f8:	52800221 	mov	w1, #0x11                  	// #17
    83fc:	97ffed01 	bl	3800 <fwp_format_g.constprop.0>
    8400:	17fffe43 	b	7d0c <fwp_write+0x69c>
    8404:	b9401040 	ldr	w0, [x2, #16]
    8408:	350003c0 	cbnz	w0, 8480 <fwp_write+0xe10>
    840c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8410:	f947f400 	ldr	x0, [x0, #4072]
    8414:	f94127e2 	ldr	x2, [sp, #584]
    8418:	f9400001 	ldr	x1, [x0]
    841c:	eb010042 	subs	x2, x2, x1
    8420:	d2800001 	mov	x1, #0x0                   	// #0
    8424:	54ffd721 	b.ne	7f08 <fwp_write+0x898>  // b.any
    8428:	f9413bf5 	ldr	x21, [sp, #624]
    842c:	b0000021 	adrp	x1, d000 <__divti3+0x2a0>
    8430:	f9413ff6 	ldr	x22, [sp, #632]
    8434:	aa1403e0 	mov	x0, x20
    8438:	f94143f7 	ldr	x23, [sp, #640]
    843c:	91284021 	add	x1, x1, #0xa10
    8440:	f94147f8 	ldr	x24, [sp, #648]
    8444:	d2800042 	mov	x2, #0x2                   	// #2
    8448:	17fffd0e 	b	7880 <fwp_write+0x210>
    844c:	b0000021 	adrp	x1, d000 <__divti3+0x2a0>
    8450:	d2800042 	mov	x2, #0x2                   	// #2
    8454:	91252021 	add	x1, x1, #0x948
    8458:	17fffea3 	b	7ee4 <fwp_write+0x874>
    845c:	f9400a63 	ldr	x3, [x19, #16]
    8460:	8b030021 	add	x1, x1, x3
    8464:	17ffff66 	b	81fc <fwp_write+0xb8c>
    8468:	f9400a61 	ldr	x1, [x19, #16]
    846c:	8b0102a1 	add	x1, x21, x1
    8470:	17fffdb3 	b	7b3c <fwp_write+0x4cc>
    8474:	f9400a63 	ldr	x3, [x19, #16]
    8478:	8b030021 	add	x1, x1, x3
    847c:	17ffff56 	b	81d4 <fwp_write+0xb64>
    8480:	b9404840 	ldr	w0, [x2, #72]
    8484:	91001ff5 	add	x21, sp, #0x7
    8488:	34ffa360 	cbz	w0, 78f4 <fwp_write+0x284>
    848c:	52800503 	mov	w3, #0x28                  	// #40
    8490:	aa1403e0 	mov	x0, x20
    8494:	aa1503e1 	mov	x1, x21
    8498:	d2800022 	mov	x2, #0x1                   	// #1
    849c:	39001fe3 	strb	w3, [sp, #7]
    84a0:	97ffec3c 	bl	3590 <buf_put>
    84a4:	b9401380 	ldr	w0, [x28, #16]
    84a8:	52800038 	mov	w24, #0x1                   	// #1
    84ac:	7100001f 	cmp	w0, #0x0
    84b0:	54ffa36c 	b.gt	791c <fwp_write+0x2ac>
    84b4:	17fffd32 	b	797c <fwp_write+0x30c>
    84b8:	f9014bf9 	str	x25, [sp, #656]
    84bc:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe928>
    84c0:	f9014ffa 	str	x26, [sp, #664]
    84c4:	f9400676 	ldr	x22, [x19, #8]
    84c8:	910ae333 	add	x19, x25, #0x2b8
    84cc:	91002273 	add	x19, x19, #0x8
    84d0:	937ffed8 	asr	x24, x22, #63
    84d4:	aa1802c0 	orr	x0, x22, x24
    84d8:	b5000320 	cbnz	x0, 853c <fwp_write+0xecc>
    84dc:	110006b5 	add	w21, w21, #0x1
    84e0:	710016bf 	cmp	w21, #0x5
    84e4:	54ffffc1 	b.ne	84dc <fwp_write+0xe6c>  // b.any
    84e8:	b7f80578 	tbnz	x24, #63, 8594 <fwp_write+0xf24>
    84ec:	910023f3 	add	x19, sp, #0x8
    84f0:	aa1603e2 	mov	x2, x22
    84f4:	aa1303e0 	mov	x0, x19
    84f8:	d2800003 	mov	x3, #0x0                   	// #0
    84fc:	97ffea49 	bl	2e20 <fwp_fmt_u128>
    8500:	910123f5 	add	x21, sp, #0x48
    8504:	b0000023 	adrp	x3, d000 <__divti3+0x2a0>
    8508:	aa1303e4 	mov	x4, x19
    850c:	aa1503e0 	mov	x0, x21
    8510:	91282063 	add	x3, x3, #0xa08
    8514:	d2804002 	mov	x2, #0x200                 	// #512
    8518:	52800041 	mov	w1, #0x2                   	// #2
    851c:	97ffe885 	bl	2730 <__sprintf_chk@plt>
    8520:	aa1503e0 	mov	x0, x21
    8524:	97ffe87f 	bl	2720 <strlen@plt>
    8528:	aa1503e1 	mov	x1, x21
    852c:	aa0003e2 	mov	x2, x0
    8530:	aa1403e0 	mov	x0, x20
    8534:	97ffec17 	bl	3590 <buf_put>
    8538:	17fffe47 	b	7e54 <fwp_write+0x7e4>
    853c:	f9400277 	ldr	x23, [x19]
    8540:	aa1603e0 	mov	x0, x22
    8544:	aa1803e1 	mov	x1, x24
    8548:	aa1703e2 	mov	x2, x23
    854c:	937ffefa 	asr	x26, x23, #63
    8550:	aa1a03e3 	mov	x3, x26
    8554:	940012e3 	bl	d0e0 <__modti3>
    8558:	aa010000 	orr	x0, x0, x1
    855c:	b40002c0 	cbz	x0, 85b4 <fwp_write+0xf44>
    8560:	110006b5 	add	w21, w21, #0x1
    8564:	91004273 	add	x19, x19, #0x10
    8568:	710016bf 	cmp	w21, #0x5
    856c:	54fffe81 	b.ne	853c <fwp_write+0xecc>  // b.any
    8570:	17ffffde 	b	84e8 <fwp_write+0xe78>
    8574:	f9400a60 	ldr	x0, [x19, #16]
    8578:	8b000021 	add	x1, x1, x0
    857c:	17fffd75 	b	7b50 <fwp_write+0x4e0>
    8580:	528c29c0 	mov	w0, #0x614e                	// #24910
    8584:	910123f5 	add	x21, sp, #0x48
    8588:	72a009c0 	movk	w0, #0x4e, lsl #16
    858c:	b9004be0 	str	w0, [sp, #72]
    8590:	17fffda2 	b	7c18 <fwp_write+0x5a8>
    8594:	528005a1 	mov	w1, #0x2d                  	// #45
    8598:	eb1603e2 	negs	x2, x22
    859c:	da1803e3 	ngc	x3, x24
    85a0:	910027e0 	add	x0, sp, #0x9
    85a4:	910023f3 	add	x19, sp, #0x8
    85a8:	390023e1 	strb	w1, [sp, #8]
    85ac:	97ffea1d 	bl	2e20 <fwp_fmt_u128>
    85b0:	17ffffd4 	b	8500 <fwp_write+0xe90>
    85b4:	aa1703e2 	mov	x2, x23
    85b8:	aa1a03e3 	mov	x3, x26
    85bc:	aa1603e0 	mov	x0, x22
    85c0:	aa1803e1 	mov	x1, x24
    85c4:	940011e7 	bl	cd60 <__divti3>
    85c8:	aa0003e2 	mov	x2, x0
    85cc:	aa0103e3 	mov	x3, x1
    85d0:	b7f80201 	tbnz	x1, #63, 8610 <fwp_write+0xfa0>
    85d4:	910023f3 	add	x19, sp, #0x8
    85d8:	aa1303e0 	mov	x0, x19
    85dc:	97ffea11 	bl	2e20 <fwp_fmt_u128>
    85e0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    85e4:	910ae339 	add	x25, x25, #0x2b8
    85e8:	910123f5 	add	x21, sp, #0x48
    85ec:	aa1303e4 	mov	x4, x19
    85f0:	aa1503e0 	mov	x0, x21
    85f4:	b0000023 	adrp	x3, d000 <__divti3+0x2a0>
    85f8:	f8616b25 	ldr	x5, [x25, x1]
    85fc:	91280063 	add	x3, x3, #0xa00
    8600:	d2804002 	mov	x2, #0x200                 	// #512
    8604:	52800041 	mov	w1, #0x2                   	// #2
    8608:	97ffe84a 	bl	2730 <__sprintf_chk@plt>
    860c:	17ffffc5 	b	8520 <fwp_write+0xeb0>
    8610:	528005a4 	mov	w4, #0x2d                  	// #45
    8614:	eb0003e2 	negs	x2, x0
    8618:	da0103e3 	ngc	x3, x1
    861c:	910027e0 	add	x0, sp, #0x9
    8620:	910023f3 	add	x19, sp, #0x8
    8624:	390023e4 	strb	w4, [sp, #8]
    8628:	97ffe9fe 	bl	2e20 <fwp_fmt_u128>
    862c:	17ffffed 	b	85e0 <fwp_write+0xf70>
    8630:	f9013bf5 	str	x21, [sp, #624]
    8634:	f9013ff6 	str	x22, [sp, #632]
    8638:	f90143f7 	str	x23, [sp, #640]
    863c:	f90147f8 	str	x24, [sp, #648]
    8640:	f9014bf9 	str	x25, [sp, #656]
    8644:	f9014ffa 	str	x26, [sp, #664]
    8648:	f90153fb 	str	x27, [sp, #672]
    864c:	f90157fc 	str	x28, [sp, #680]
    8650:	fd015be8 	str	d8, [sp, #688]
    8654:	fd015fe9 	str	d9, [sp, #696]
    8658:	97ffe88e 	bl	2890 <__stack_chk_fail@plt>
    865c:	d503201f 	nop

0000000000008660 <fwp_hof0.constprop.0>:
    8660:	d105c3ff 	sub	sp, sp, #0x170
    8664:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    8668:	f947f442 	ldr	x2, [x2, #4072]
    866c:	a9117bfd 	stp	x29, x30, [sp, #272]
    8670:	910443fd 	add	x29, sp, #0x110
    8674:	a91673fb 	stp	x27, x28, [sp, #352]
    8678:	aa0003fc 	mov	x28, x0
    867c:	f9400040 	ldr	x0, [x2]
    8680:	f90087e0 	str	x0, [sp, #264]
    8684:	d2800000 	mov	x0, #0x0                   	// #0
    8688:	b40036c1 	cbz	x1, 8d60 <fwp_hof0.constprop.0+0x700>
    868c:	a91253f3 	stp	x19, x20, [sp, #288]
    8690:	900000d4 	adrp	x20, 20000 <__data_start>
    8694:	91004294 	add	x20, x20, #0x10
    8698:	a91463f7 	stp	x23, x24, [sp, #320]
    869c:	b0000157 	adrp	x23, 31000 <fwp_root_context+0xc20>
    86a0:	911702e4 	add	x4, x23, #0x5c0
    86a4:	910263e0 	add	x0, sp, #0x98
    86a8:	9100e294 	add	x20, x20, #0x38
    86ac:	aa1c03fb 	mov	x27, x28
    86b0:	a9135bf5 	stp	x21, x22, [sp, #304]
    86b4:	900000d5 	adrp	x21, 20000 <__data_start>
    86b8:	9101c2b8 	add	x24, x21, #0x70
    86bc:	a9156bf9 	stp	x25, x26, [sp, #336]
    86c0:	aa0403fa 	mov	x26, x4
    86c4:	d0fffff9 	adrp	x25, 6000 <fwp_drop1+0xf0>
    86c8:	f90007e0 	str	x0, [sp, #8]
    86cc:	910283e0 	add	x0, sp, #0xa0
    86d0:	f9000be0 	str	x0, [sp, #16]
    86d4:	f90013e1 	str	x1, [sp, #32]
    86d8:	f949ef45 	ldr	x5, [x26, #5080]
    86dc:	f949db41 	ldr	x1, [x26, #5040]
    86e0:	d370bca5 	lsl	x5, x5, #16
    86e4:	cb010363 	sub	x3, x27, x1
    86e8:	eb05007f 	cmp	x3, x5
    86ec:	540003e2 	b.cs	8768 <fwp_hof0.constprop.0+0x108>  // b.hs, b.nlast
    86f0:	d350fc60 	lsr	x0, x3, #16
    86f4:	f949ff47 	ldr	x7, [x26, #5112]
    86f8:	8b000800 	add	x0, x0, x0, lsl #2
    86fc:	d37df002 	lsl	x2, x0, #3
    8700:	8b0200e6 	add	x6, x7, x2
    8704:	f94010c0 	ldr	x0, [x6, #32]
    8708:	b4000300 	cbz	x0, 8768 <fwp_hof0.constprop.0+0x108>
    870c:	386268e2 	ldrb	w2, [x7, x2]
    8710:	7100085f 	cmp	w2, #0x2
    8714:	54000de0 	b.eq	88d0 <fwp_hof0.constprop.0+0x270>  // b.none
    8718:	7100045f 	cmp	w2, #0x1
    871c:	54000261 	b.ne	8768 <fwp_hof0.constprop.0+0x108>  // b.any
    8720:	92403c62 	and	x2, x3, #0xffff
    8724:	29430cc7 	ldp	w7, w3, [x6, #24]
    8728:	9b077c42 	mul	x2, x2, x7
    872c:	d360fc42 	lsr	x2, x2, #32
    8730:	eb03005f 	cmp	x2, x3
    8734:	540001a2 	b.cs	8768 <fwp_hof0.constprop.0+0x108>  // b.hs, b.nlast
    8738:	8b020000 	add	x0, x0, x2
    873c:	39400002 	ldrb	w2, [x0]
    8740:	34000142 	cbz	w2, 8768 <fwp_hof0.constprop.0+0x108>
    8744:	7103f45f 	cmp	w2, #0xfd
    8748:	54004e88 	b.hi	9118 <fwp_hof0.constprop.0+0xab8>  // b.pmore
    874c:	911702e1 	add	x1, x23, #0x5c0
    8750:	11000442 	add	w2, w2, #0x1
    8754:	39000002 	strb	w2, [x0]
    8758:	aa0103e0 	mov	x0, x1
    875c:	f949d821 	ldr	x1, [x1, #5040]
    8760:	f949ec05 	ldr	x5, [x0, #5080]
    8764:	d370bca5 	lsl	x5, x5, #16
    8768:	aa1b03f3 	mov	x19, x27
    876c:	91160336 	add	x22, x25, #0x580
    8770:	d28018c0 	mov	x0, #0xc6                  	// #198
    8774:	b2407bfc 	mov	x28, #0x7fffffff            	// #2147483647
    8778:	f9000fe0 	str	x0, [sp, #24]
    877c:	f90017fb 	str	x27, [sp, #40]
    8780:	f9418300 	ldr	x0, [x24, #768]
    8784:	a90a5be0 	stp	x0, x22, [sp, #160]
    8788:	12800002 	mov	w2, #0xffffffff            	// #-1
    878c:	f94007e0 	ldr	x0, [sp, #8]
    8790:	f9005be0 	str	x0, [sp, #176]
    8794:	f9400be0 	ldr	x0, [sp, #16]
    8798:	cb010281 	sub	x1, x20, x1
    879c:	b9009be2 	str	w2, [sp, #152]
    87a0:	f9018300 	str	x0, [x24, #768]
    87a4:	eb05003f 	cmp	x1, x5
    87a8:	54000782 	b.cs	8898 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    87ac:	911702e2 	add	x2, x23, #0x5c0
    87b0:	d350fc20 	lsr	x0, x1, #16
    87b4:	8b000800 	add	x0, x0, x0, lsl #2
    87b8:	f949fc43 	ldr	x3, [x2, #5112]
    87bc:	d37df000 	lsl	x0, x0, #3
    87c0:	8b000062 	add	x2, x3, x0
    87c4:	f940105b 	ldr	x27, [x2, #32]
    87c8:	b400069b 	cbz	x27, 8898 <fwp_hof0.constprop.0+0x238>
    87cc:	38606860 	ldrb	w0, [x3, x0]
    87d0:	7100081f 	cmp	w0, #0x2
    87d4:	54000840 	b.eq	88dc <fwp_hof0.constprop.0+0x27c>  // b.none
    87d8:	7100041f 	cmp	w0, #0x1
    87dc:	540005e1 	b.ne	8898 <fwp_hof0.constprop.0+0x238>  // b.any
    87e0:	29430c44 	ldp	w4, w3, [x2, #24]
    87e4:	92403c20 	and	x0, x1, #0xffff
    87e8:	9b047c00 	mul	x0, x0, x4
    87ec:	d360fc00 	lsr	x0, x0, #32
    87f0:	eb03001f 	cmp	x0, x3
    87f4:	54000282 	b.cs	8844 <fwp_hof0.constprop.0+0x1e4>  // b.hs, b.nlast
    87f8:	8b000360 	add	x0, x27, x0
    87fc:	39400003 	ldrb	w3, [x0]
    8800:	34000223 	cbz	w3, 8844 <fwp_hof0.constprop.0+0x1e4>
    8804:	7103f47f 	cmp	w3, #0xfd
    8808:	54004cc8 	b.hi	91a0 <fwp_hof0.constprop.0+0xb40>  // b.pmore
    880c:	11000463 	add	w3, w3, #0x1
    8810:	39000003 	strb	w3, [x0]
    8814:	911702e0 	add	x0, x23, #0x5c0
    8818:	f949d801 	ldr	x1, [x0, #5040]
    881c:	f949ec02 	ldr	x2, [x0, #5080]
    8820:	cb010281 	sub	x1, x20, x1
    8824:	eb02403f 	cmp	x1, x2, lsl #16
    8828:	54000382 	b.cs	8898 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    882c:	f949fc00 	ldr	x0, [x0, #5112]
    8830:	d350fc22 	lsr	x2, x1, #16
    8834:	8b020842 	add	x2, x2, x2, lsl #2
    8838:	8b020c02 	add	x2, x0, x2, lsl #3
    883c:	f940105b 	ldr	x27, [x2, #32]
    8840:	b40002db 	cbz	x27, 8898 <fwp_hof0.constprop.0+0x238>
    8844:	39400040 	ldrb	w0, [x2]
    8848:	7100081f 	cmp	w0, #0x2
    884c:	54000e00 	b.eq	8a0c <fwp_hof0.constprop.0+0x3ac>  // b.none
    8850:	7100041f 	cmp	w0, #0x1
    8854:	54000221 	b.ne	8898 <fwp_hof0.constprop.0+0x238>  // b.any
    8858:	29430043 	ldp	w3, w0, [x2, #24]
    885c:	92403c21 	and	x1, x1, #0xffff
    8860:	9b037c21 	mul	x1, x1, x3
    8864:	d360fc21 	lsr	x1, x1, #32
    8868:	eb00003f 	cmp	x1, x0
    886c:	54000162 	b.cs	8898 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    8870:	8b01037b 	add	x27, x27, x1
    8874:	39400360 	ldrb	w0, [x27]
    8878:	34000100 	cbz	w0, 8898 <fwp_hof0.constprop.0+0x238>
    887c:	7100041f 	cmp	w0, #0x1
    8880:	54000360 	b.eq	88ec <fwp_hof0.constprop.0+0x28c>  // b.none
    8884:	7103fc1f 	cmp	w0, #0xff
    8888:	54004540 	b.eq	9130 <fwp_hof0.constprop.0+0xad0>  // b.none
    888c:	51000400 	sub	w0, w0, #0x1
    8890:	39000360 	strb	w0, [x27]
    8894:	d503201f 	nop
    8898:	b40003b3 	cbz	x19, 890c <fwp_hof0.constprop.0+0x2ac>
    889c:	aa1303e0 	mov	x0, x19
    88a0:	d280001b 	mov	x27, #0x0                   	// #0
    88a4:	d503201f 	nop
    88a8:	f9400800 	ldr	x0, [x0, #16]
    88ac:	9100077b 	add	x27, x27, #0x1
    88b0:	b5ffffc0 	cbnz	x0, 88a8 <fwp_hof0.constprop.0+0x248>
    88b4:	52800000 	mov	w0, #0x0                   	// #0
    88b8:	97ffeb4e 	bl	35f0 <descent_phase_step>
    88bc:	eb1c037f 	cmp	x27, x28
    88c0:	540002c9 	b.ls	8918 <fwp_hof0.constprop.0+0x2b8>  // b.plast
    88c4:	b0000020 	adrp	x0, d000 <__divti3+0x2a0>
    88c8:	91288000 	add	x0, x0, #0xa20
    88cc:	97ffee0d 	bl	4100 <fwp_trap>
    88d0:	72003c7f 	tst	w3, #0xffff
    88d4:	54fff4a1 	b.ne	8768 <fwp_hof0.constprop.0+0x108>  // b.any
    88d8:	17ffff99 	b	873c <fwp_hof0.constprop.0+0xdc>
    88dc:	72003c3f 	tst	w1, #0xffff
    88e0:	54fffb21 	b.ne	8844 <fwp_hof0.constprop.0+0x1e4>  // b.any
    88e4:	aa1b03e0 	mov	x0, x27
    88e8:	17ffffc5 	b	87fc <fwp_hof0.constprop.0+0x19c>
    88ec:	d53bd040 	mrs	x0, tpidr_el0
    88f0:	91400000 	add	x0, x0, #0x0, lsl #12
    88f4:	91004000 	add	x0, x0, #0x10
    88f8:	f9400000 	ldr	x0, [x0]
    88fc:	b4000820 	cbz	x0, 8a00 <fwp_hof0.constprop.0+0x3a0>
    8900:	aa1403e1 	mov	x1, x20
    8904:	97ffef7b 	bl	46f0 <fwp_closure_drop_push>
    8908:	17ffffe4 	b	8898 <fwp_hof0.constprop.0+0x238>
    890c:	d280001b 	mov	x27, #0x0                   	// #0
    8910:	52800000 	mov	w0, #0x0                   	// #0
    8914:	97ffeb37 	bl	35f0 <descent_phase_step>
    8918:	9101c2a1 	add	x1, x21, #0x70
    891c:	b9433420 	ldr	w0, [x1, #820]
    8920:	34002380 	cbz	w0, 8d90 <fwp_hof0.constprop.0+0x730>
    8924:	9101c2a0 	add	x0, x21, #0x70
    8928:	f9406003 	ldr	x3, [x0, #192]
    892c:	f9406c02 	ldr	x2, [x0, #216]
    8930:	eb03005f 	cmp	x2, x3
    8934:	5400072a 	b.ge	8a18 <fwp_hof0.constprop.0+0x3b8>  // b.tcont
    8938:	8b020440 	add	x0, x2, x2, lsl #1
    893c:	528fffc4 	mov	w4, #0x7ffe                	// #32766
    8940:	f9403aa1 	ldr	x1, [x21, #112]
    8944:	d37ef400 	lsl	x0, x0, #2
    8948:	cb020000 	sub	x0, x0, x2
    894c:	8b000c20 	add	x0, x1, x0, lsl #3
    8950:	b9400401 	ldr	w1, [x0, #4]
    8954:	35000081 	cbnz	w1, 8964 <fwp_hof0.constprop.0+0x304>
    8958:	b9400001 	ldr	w1, [x0]
    895c:	6b04003f 	cmp	w1, w4
    8960:	540005c9 	b.ls	8a18 <fwp_hof0.constprop.0+0x3b8>  // b.plast
    8964:	91000442 	add	x2, x2, #0x1
    8968:	91016000 	add	x0, x0, #0x58
    896c:	eb03005f 	cmp	x2, x3
    8970:	54ffff01 	b.ne	8950 <fwp_hof0.constprop.0+0x2f0>  // b.any
    8974:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8978:	eb00007f 	cmp	x3, x0
    897c:	540033cc 	b.gt	8ff4 <fwp_hof0.constprop.0+0x994>
    8980:	9101c2a0 	add	x0, x21, #0x70
    8984:	f9403aa6 	ldr	x6, [x21, #112]
    8988:	f9406800 	ldr	x0, [x0, #208]
    898c:	eb03001f 	cmp	x0, x3
    8990:	540001e1 	b.ne	89cc <fwp_hof0.constprop.0+0x36c>  // b.any
    8994:	b5003363 	cbnz	x3, 9000 <fwp_hof0.constprop.0+0x9a0>
    8998:	d2800b01 	mov	x1, #0x58                  	// #88
    899c:	d2800024 	mov	x4, #0x1                   	// #1
    89a0:	aa0603e0 	mov	x0, x6
    89a4:	a90313e2 	stp	x2, x4, [sp, #48]
    89a8:	f90023e3 	str	x3, [sp, #64]
    89ac:	97ffe7b5 	bl	2880 <realloc@plt>
    89b0:	a94313e2 	ldp	x2, x4, [sp, #48]
    89b4:	aa0003e6 	mov	x6, x0
    89b8:	f94023e3 	ldr	x3, [sp, #64]
    89bc:	b4007000 	cbz	x0, 97bc <fwp_hof0.constprop.0+0x115c>
    89c0:	9101c2a0 	add	x0, x21, #0x70
    89c4:	f9003aa6 	str	x6, [x21, #112]
    89c8:	f9006804 	str	x4, [x0, #208]
    89cc:	8b030461 	add	x1, x3, x3, lsl #1
    89d0:	9101c2a0 	add	x0, x21, #0x70
    89d4:	4f000400 	movi	v0.4s, #0x0
    89d8:	91000464 	add	x4, x3, #0x1
    89dc:	d37ef421 	lsl	x1, x1, #2
    89e0:	cb030021 	sub	x1, x1, x3
    89e4:	f9006004 	str	x4, [x0, #192]
    89e8:	8b010cc1 	add	x1, x6, x1, lsl #3
    89ec:	ad000020 	stp	q0, q0, [x1]
    89f0:	ad010020 	stp	q0, q0, [x1, #32]
    89f4:	3d801020 	str	q0, [x1, #64]
    89f8:	f900283f 	str	xzr, [x1, #80]
    89fc:	1400000a 	b	8a24 <fwp_hof0.constprop.0+0x3c4>
    8a00:	aa1403e0 	mov	x0, x20
    8a04:	97ffef80 	bl	4804 <fwp_closure_drop.part.0>
    8a08:	17ffffa4 	b	8898 <fwp_hof0.constprop.0+0x238>
    8a0c:	72003c3f 	tst	w1, #0xffff
    8a10:	54fff441 	b.ne	8898 <fwp_hof0.constprop.0+0x238>  // b.any
    8a14:	17ffff98 	b	8874 <fwp_hof0.constprop.0+0x214>
    8a18:	eb03005f 	cmp	x2, x3
    8a1c:	54fffac0 	b.eq	8974 <fwp_hof0.constprop.0+0x314>  // b.none
    8a20:	f9403aa6 	ldr	x6, [x21, #112]
    8a24:	8b020441 	add	x1, x2, x2, lsl #1
    8a28:	b0000020 	adrp	x0, d000 <__divti3+0x2a0>
    8a2c:	91194000 	add	x0, x0, #0x650
    8a30:	d37ef423 	lsl	x3, x1, #2
    8a34:	f90023e2 	str	x2, [sp, #64]
    8a38:	cb020063 	sub	x3, x3, x2
    8a3c:	8b030cc3 	add	x3, x6, x3, lsl #3
    8a40:	a9031be3 	stp	x3, x6, [sp, #48]
    8a44:	f900287f 	str	xzr, [x3, #80]
    8a48:	97ffe7f6 	bl	2a20 <getenv@plt>
    8a4c:	a9431be3 	ldp	x3, x6, [sp, #48]
    8a50:	f94023e2 	ldr	x2, [sp, #64]
    8a54:	b4000820 	cbz	x0, 8b58 <fwp_hof0.constprop.0+0x4f8>
    8a58:	39400001 	ldrb	w1, [x0]
    8a5c:	7100c03f 	cmp	w1, #0x30
    8a60:	540007c1 	b.ne	8b58 <fwp_hof0.constprop.0+0x4f8>  // b.any
    8a64:	39400400 	ldrb	w0, [x0, #1]
    8a68:	35000780 	cbnz	w0, 8b58 <fwp_hof0.constprop.0+0x4f8>
    8a6c:	9101c2a0 	add	x0, x21, #0x70
    8a70:	2f000400 	mvni	v0.2s, #0x0
    8a74:	b9400067 	ldr	w7, [x3]
    8a78:	91000448 	add	x8, x2, #0x1
    8a7c:	52800024 	mov	w4, #0x1                   	// #1
    8a80:	a900ec7b 	stp	x27, x27, [x3, #8]
    8a84:	110004e7 	add	w7, w7, #0x1
    8a88:	f9418001 	ldr	x1, [x0, #768]
    8a8c:	29001067 	stp	w7, w4, [x3]
    8a90:	f900207f 	str	xzr, [x3, #64]
    8a94:	f9006c08 	str	x8, [x0, #216]
    8a98:	fd002460 	str	d0, [x3, #72]
    8a9c:	b4003381 	cbz	x1, 910c <fwp_hof0.constprop.0+0xaac>
    8aa0:	91160325 	add	x5, x25, #0x580
    8aa4:	14000003 	b	8ab0 <fwp_hof0.constprop.0+0x450>
    8aa8:	f9400021 	ldr	x1, [x1]
    8aac:	b4003301 	cbz	x1, 910c <fwp_hof0.constprop.0+0xaac>
    8ab0:	f9400420 	ldr	x0, [x1, #8]
    8ab4:	eb05001f 	cmp	x0, x5
    8ab8:	54ffff81 	b.ne	8aa8 <fwp_hof0.constprop.0+0x448>  // b.any
    8abc:	f9400820 	ldr	x0, [x1, #16]
    8ac0:	2a0203e4 	mov	w4, w2
    8ac4:	b9400001 	ldr	w1, [x0]
    8ac8:	f9002060 	str	x0, [x3, #64]
    8acc:	b9004c61 	str	w1, [x3, #76]
    8ad0:	37f80081 	tbnz	w1, #31, 8ae0 <fwp_hof0.constprop.0+0x480>
    8ad4:	52800b03 	mov	w3, #0x58                  	// #88
    8ad8:	9b231821 	smaddl	x1, w1, w3, x6
    8adc:	b9004822 	str	w2, [x1, #72]
    8ae0:	b9000004 	str	w4, [x0]
    8ae4:	52800020 	mov	w0, #0x1                   	// #1
    8ae8:	b90033e7 	str	w7, [sp, #48]
    8aec:	f9001fe8 	str	x8, [sp, #56]
    8af0:	97ffeac0 	bl	35f0 <descent_phase_step>
    8af4:	f9401fe8 	ldr	x8, [sp, #56]
    8af8:	aa1303e0 	mov	x0, x19
    8afc:	b94033e7 	ldr	w7, [sp, #48]
    8b00:	d2800002 	mov	x2, #0x0                   	// #0
    8b04:	b4001593 	cbz	x19, 8db4 <fwp_hof0.constprop.0+0x754>
    8b08:	f9400800 	ldr	x0, [x0, #16]
    8b0c:	91000442 	add	x2, x2, #0x1
    8b10:	b5ffffc0 	cbnz	x0, 8b08 <fwp_hof0.constprop.0+0x4a8>
    8b14:	aa1303e1 	mov	x1, x19
    8b18:	f9400821 	ldr	x1, [x1, #16]
    8b1c:	91000400 	add	x0, x0, #0x1
    8b20:	b5ffffc1 	cbnz	x1, 8b18 <fwp_hof0.constprop.0+0x4b8>
    8b24:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8b28:	eb01001f 	cmp	x0, x1
    8b2c:	54000108 	b.hi	8b4c <fwp_hof0.constprop.0+0x4ec>  // b.pmore
    8b30:	f100005f 	cmp	x2, #0x0
    8b34:	5400140d 	b.le	8db4 <fwp_hof0.constprop.0+0x754>
    8b38:	eb00005f 	cmp	x2, x0
    8b3c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8b40:	9a80905b 	csel	x27, x2, x0, ls	// ls = plast
    8b44:	eb01037f 	cmp	x27, x1
    8b48:	540026e9 	b.ls	9024 <fwp_hof0.constprop.0+0x9c4>  // b.plast
    8b4c:	b0000020 	adrp	x0, d000 <__divti3+0x2a0>
    8b50:	91248000 	add	x0, x0, #0x920
    8b54:	97ffed6b 	bl	4100 <fwp_trap>
    8b58:	9101c2a0 	add	x0, x21, #0x70
    8b5c:	f9405801 	ldr	x1, [x0, #176]
    8b60:	b4fff861 	cbz	x1, 8a6c <fwp_hof0.constprop.0+0x40c>
    8b64:	3cc88000 	ldur	q0, [x0, #136]
    8b68:	f900581f 	str	xzr, [x0, #176]
    8b6c:	3d800860 	str	q0, [x3, #32]
    8b70:	f9405404 	ldr	x4, [x0, #168]
    8b74:	f9001c64 	str	x4, [x3, #56]
    8b78:	f9404c04 	ldr	x4, [x0, #152]
    8b7c:	f9001864 	str	x4, [x3, #48]
    8b80:	f9405004 	ldr	x4, [x0, #160]
    8b84:	f9000c64 	str	x4, [x3, #24]
    8b88:	a908fc1f 	stp	xzr, xzr, [x0, #136]
    8b8c:	a909fc1f 	stp	xzr, xzr, [x0, #152]
    8b90:	f900541f 	str	xzr, [x0, #168]
    8b94:	17ffffb6 	b	8a6c <fwp_hof0.constprop.0+0x40c>
    8b98:	a94283fb 	ldp	x27, x0, [sp, #40]
    8b9c:	d00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe928>
    8ba0:	910ae042 	add	x2, x2, #0x2b8
    8ba4:	aa1303e1 	mov	x1, x19
    8ba8:	91014042 	add	x2, x2, #0x50
    8bac:	52800023 	mov	w3, #0x1                   	// #1
    8bb0:	a90d7fff 	stp	xzr, xzr, [sp, #208]
    8bb4:	f90073ff 	str	xzr, [sp, #224]
    8bb8:	97fffaae 	bl	7670 <fwp_write>
    8bbc:	a94d0bfc 	ldp	x28, x2, [sp, #208]
    8bc0:	b0000020 	adrp	x0, d000 <__divti3+0x2a0>
    8bc4:	913f4000 	add	x0, x0, #0xfd0
    8bc8:	f100039f 	cmp	x28, #0x0
    8bcc:	9a9c001c 	csel	x28, x0, x28, eq	// eq = none
    8bd0:	b100285f 	cmn	x2, #0xa
    8bd4:	54008b68 	b.hi	9d40 <fwp_hof0.constprop.0+0x16e0>  // b.pmore
    8bd8:	91002440 	add	x0, x2, #0x9
    8bdc:	52800021 	mov	w1, #0x1                   	// #1
    8be0:	f9000fe2 	str	x2, [sp, #24]
    8be4:	97fff0bf 	bl	4ee0 <fwp_heap_alloc>
    8be8:	aa1c03e1 	mov	x1, x28
    8bec:	aa0003fc 	mov	x28, x0
    8bf0:	f9400fe2 	ldr	x2, [sp, #24]
    8bf4:	aa0003f6 	mov	x22, x0
    8bf8:	f8008782 	str	x2, [x28], #8
    8bfc:	aa1c03e0 	mov	x0, x28
    8c00:	97ffe6bc 	bl	26f0 <memcpy@plt>
    8c04:	f9400fe2 	ldr	x2, [sp, #24]
    8c08:	8b0202c2 	add	x2, x22, x2
    8c0c:	3900205f 	strb	wzr, [x2, #8]
    8c10:	f9406be0 	ldr	x0, [sp, #208]
    8c14:	97ffe74f 	bl	2950 <free@plt>
    8c18:	911702e2 	add	x2, x23, #0x5c0
    8c1c:	f949d841 	ldr	x1, [x2, #5040]
    8c20:	f949ec40 	ldr	x0, [x2, #5080]
    8c24:	cb0102c1 	sub	x1, x22, x1
    8c28:	eb00403f 	cmp	x1, x0, lsl #16
    8c2c:	54000322 	b.cs	8c90 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    8c30:	d350fc20 	lsr	x0, x1, #16
    8c34:	f949fc45 	ldr	x5, [x2, #5112]
    8c38:	8b000800 	add	x0, x0, x0, lsl #2
    8c3c:	d37df002 	lsl	x2, x0, #3
    8c40:	8b0200a3 	add	x3, x5, x2
    8c44:	f9401060 	ldr	x0, [x3, #32]
    8c48:	b4000240 	cbz	x0, 8c90 <fwp_hof0.constprop.0+0x630>
    8c4c:	386268a2 	ldrb	w2, [x5, x2]
    8c50:	7100085f 	cmp	w2, #0x2
    8c54:	54008880 	b.eq	9d64 <fwp_hof0.constprop.0+0x1704>  // b.none
    8c58:	7100045f 	cmp	w2, #0x1
    8c5c:	540001a1 	b.ne	8c90 <fwp_hof0.constprop.0+0x630>  // b.any
    8c60:	29430865 	ldp	w5, w2, [x3, #24]
    8c64:	92403c21 	and	x1, x1, #0xffff
    8c68:	9b057c21 	mul	x1, x1, x5
    8c6c:	d360fc21 	lsr	x1, x1, #32
    8c70:	eb02003f 	cmp	x1, x2
    8c74:	540000e2 	b.cs	8c90 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    8c78:	8b010000 	add	x0, x0, x1
    8c7c:	39400001 	ldrb	w1, [x0]
    8c80:	7103fc3f 	cmp	w1, #0xff
    8c84:	54008760 	b.eq	9d70 <fwp_hof0.constprop.0+0x1710>  // b.none
    8c88:	52800021 	mov	w1, #0x1                   	// #1
    8c8c:	39000001 	strb	w1, [x0]
    8c90:	aa1303e0 	mov	x0, x19
    8c94:	9101c2b3 	add	x19, x21, #0x70
    8c98:	97fff4fa 	bl	6080 <fwp_drop0>
    8c9c:	f94002c2 	ldr	x2, [x22]
    8ca0:	d2800021 	mov	x1, #0x1                   	// #1
    8ca4:	f9400663 	ldr	x3, [x19, #8]
    8ca8:	aa1c03e0 	mov	x0, x28
    8cac:	97ffe739 	bl	2990 <fwrite@plt>
    8cb0:	f9400661 	ldr	x1, [x19, #8]
    8cb4:	52800140 	mov	w0, #0xa                   	// #10
    8cb8:	97ffe6be 	bl	27b0 <fputc@plt>
    8cbc:	911702e2 	add	x2, x23, #0x5c0
    8cc0:	f949d841 	ldr	x1, [x2, #5040]
    8cc4:	f949ec40 	ldr	x0, [x2, #5080]
    8cc8:	cb0102c1 	sub	x1, x22, x1
    8ccc:	eb00403f 	cmp	x1, x0, lsl #16
    8cd0:	54000382 	b.cs	8d40 <fwp_hof0.constprop.0+0x6e0>  // b.hs, b.nlast
    8cd4:	d350fc20 	lsr	x0, x1, #16
    8cd8:	f949fc45 	ldr	x5, [x2, #5112]
    8cdc:	8b000800 	add	x0, x0, x0, lsl #2
    8ce0:	d37df002 	lsl	x2, x0, #3
    8ce4:	8b0200a3 	add	x3, x5, x2
    8ce8:	f9401073 	ldr	x19, [x3, #32]
    8cec:	b40002b3 	cbz	x19, 8d40 <fwp_hof0.constprop.0+0x6e0>
    8cf0:	386268a2 	ldrb	w2, [x5, x2]
    8cf4:	7100085f 	cmp	w2, #0x2
    8cf8:	54008300 	b.eq	9d58 <fwp_hof0.constprop.0+0x16f8>  // b.none
    8cfc:	7100045f 	cmp	w2, #0x1
    8d00:	54000201 	b.ne	8d40 <fwp_hof0.constprop.0+0x6e0>  // b.any
    8d04:	29430062 	ldp	w2, w0, [x3, #24]
    8d08:	92403c21 	and	x1, x1, #0xffff
    8d0c:	9b027c21 	mul	x1, x1, x2
    8d10:	d360fc21 	lsr	x1, x1, #32
    8d14:	eb00003f 	cmp	x1, x0
    8d18:	54000142 	b.cs	8d40 <fwp_hof0.constprop.0+0x6e0>  // b.hs, b.nlast
    8d1c:	8b010273 	add	x19, x19, x1
    8d20:	39400261 	ldrb	w1, [x19]
    8d24:	340000e1 	cbz	w1, 8d40 <fwp_hof0.constprop.0+0x6e0>
    8d28:	7100043f 	cmp	w1, #0x1
    8d2c:	54008100 	b.eq	9d4c <fwp_hof0.constprop.0+0x16ec>  // b.none
    8d30:	7103fc3f 	cmp	w1, #0xff
    8d34:	54008260 	b.eq	9d80 <fwp_hof0.constprop.0+0x1720>  // b.none
    8d38:	51000421 	sub	w1, w1, #0x1
    8d3c:	39000261 	strb	w1, [x19]
    8d40:	f94013e0 	ldr	x0, [sp, #32]
    8d44:	f9400800 	ldr	x0, [x0, #16]
    8d48:	f90013e0 	str	x0, [sp, #32]
    8d4c:	b5ffcc60 	cbnz	x0, 86d8 <fwp_hof0.constprop.0+0x78>
    8d50:	a95253f3 	ldp	x19, x20, [sp, #288]
    8d54:	a9535bf5 	ldp	x21, x22, [sp, #304]
    8d58:	a95463f7 	ldp	x23, x24, [sp, #320]
    8d5c:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8d60:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8d64:	f947f400 	ldr	x0, [x0, #4072]
    8d68:	f94087e2 	ldr	x2, [sp, #264]
    8d6c:	f9400001 	ldr	x1, [x0]
    8d70:	eb010042 	subs	x2, x2, x1
    8d74:	d2800001 	mov	x1, #0x0                   	// #0
    8d78:	54009401 	b.ne	9ff8 <fwp_hof0.constprop.0+0x1998>  // b.any
    8d7c:	a9517bfd 	ldp	x29, x30, [sp, #272]
    8d80:	d2800000 	mov	x0, #0x0                   	// #0
    8d84:	a95673fb 	ldp	x27, x28, [sp, #352]
    8d88:	9105c3ff 	add	sp, sp, #0x170
    8d8c:	d65f03c0 	ret
    8d90:	d0ffffe0 	adrp	x0, 6000 <fwp_drop1+0xf0>
    8d94:	91124000 	add	x0, x0, #0x490
    8d98:	f9001be1 	str	x1, [sp, #48]
    8d9c:	940011ad 	bl	d450 <atexit>
    8da0:	f9401be1 	ldr	x1, [sp, #48]
    8da4:	350050c0 	cbnz	w0, 97bc <fwp_hof0.constprop.0+0x115c>
    8da8:	52800020 	mov	w0, #0x1                   	// #1
    8dac:	b9033420 	str	w0, [x1, #820]
    8db0:	17fffedd 	b	8924 <fwp_hof0.constprop.0+0x2c4>
    8db4:	d3707ce7 	ubfiz	x7, x7, #16, #32
    8db8:	52800041 	mov	w1, #0x2                   	// #2
    8dbc:	aa0800e0 	orr	x0, x7, x8
    8dc0:	f9001be0 	str	x0, [sp, #48]
    8dc4:	d2800100 	mov	x0, #0x8                   	// #8
    8dc8:	97fff046 	bl	4ee0 <fwp_heap_alloc>
    8dcc:	aa0003e7 	mov	x7, x0
    8dd0:	911702e0 	add	x0, x23, #0x5c0
    8dd4:	aa0703e8 	mov	x8, x7
    8dd8:	f90000ff 	str	xzr, [x7]
    8ddc:	f949d801 	ldr	x1, [x0, #5040]
    8de0:	f949ec00 	ldr	x0, [x0, #5080]
    8de4:	cb0100e1 	sub	x1, x7, x1
    8de8:	eb00403f 	cmp	x1, x0, lsl #16
    8dec:	54001442 	b.cs	9074 <fwp_hof0.constprop.0+0xa14>  // b.hs, b.nlast
    8df0:	d280001b 	mov	x27, #0x0                   	// #0
    8df4:	911702e2 	add	x2, x23, #0x5c0
    8df8:	d350fc20 	lsr	x0, x1, #16
    8dfc:	8b000800 	add	x0, x0, x0, lsl #2
    8e00:	f949fc44 	ldr	x4, [x2, #5112]
    8e04:	d37df002 	lsl	x2, x0, #3
    8e08:	8b020083 	add	x3, x4, x2
    8e0c:	f9401060 	ldr	x0, [x3, #32]
    8e10:	b4000240 	cbz	x0, 8e58 <fwp_hof0.constprop.0+0x7f8>
    8e14:	38626882 	ldrb	w2, [x4, x2]
    8e18:	7100085f 	cmp	w2, #0x2
    8e1c:	54001300 	b.eq	907c <fwp_hof0.constprop.0+0xa1c>  // b.none
    8e20:	7100045f 	cmp	w2, #0x1
    8e24:	540001a1 	b.ne	8e58 <fwp_hof0.constprop.0+0x7f8>  // b.any
    8e28:	29430864 	ldp	w4, w2, [x3, #24]
    8e2c:	92403c21 	and	x1, x1, #0xffff
    8e30:	9b047c21 	mul	x1, x1, x4
    8e34:	d360fc21 	lsr	x1, x1, #32
    8e38:	eb02003f 	cmp	x1, x2
    8e3c:	540000e2 	b.cs	8e58 <fwp_hof0.constprop.0+0x7f8>  // b.hs, b.nlast
    8e40:	8b010000 	add	x0, x0, x1
    8e44:	39400001 	ldrb	w1, [x0]
    8e48:	7103fc3f 	cmp	w1, #0xff
    8e4c:	540048a0 	b.eq	9760 <fwp_hof0.constprop.0+0x1100>  // b.none
    8e50:	52800021 	mov	w1, #0x1                   	// #1
    8e54:	39000001 	strb	w1, [x0]
    8e58:	b400025b 	cbz	x27, 8ea0 <fwp_hof0.constprop.0+0x840>
    8e5c:	f9401be0 	ldr	x0, [sp, #48]
    8e60:	aa1303e3 	mov	x3, x19
    8e64:	f9400666 	ldr	x6, [x19, #8]
    8e68:	910020e2 	add	x2, x7, #0x8
    8e6c:	d3607c05 	lsl	x5, x0, #32
    8e70:	d2800001 	mov	x1, #0x0                   	// #0
    8e74:	aa0503e4 	mov	x4, x5
    8e78:	14000005 	b	8e8c <fwp_hof0.constprop.0+0x82c>
    8e7c:	f9400466 	ldr	x6, [x3, #8]
    8e80:	ab0100a4 	adds	x4, x5, x1
    8e84:	91004042 	add	x2, x2, #0x10
    8e88:	54009866 	b.vs	a194 <fwp_hof0.constprop.0+0x1b34>
    8e8c:	a9001046 	stp	x6, x4, [x2]
    8e90:	91000421 	add	x1, x1, #0x1
    8e94:	f9400863 	ldr	x3, [x3, #16]
    8e98:	eb1b003f 	cmp	x1, x27
    8e9c:	54ffff03 	b.cc	8e7c <fwp_hof0.constprop.0+0x81c>  // b.lo, b.ul, b.last
    8ea0:	f94000e0 	ldr	x0, [x7]
    8ea4:	f100041f 	cmp	x0, #0x1
    8ea8:	54000e69 	b.ls	9074 <fwp_hof0.constprop.0+0xa14>  // b.plast
    8eac:	d341fc00 	lsr	x0, x0, #1
    8eb0:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8eb4:	d1000401 	sub	x1, x0, #0x1
    8eb8:	eb02003f 	cmp	x1, x2
    8ebc:	54ffe488 	b.hi	8b4c <fwp_hof0.constprop.0+0x4ec>  // b.pmore
    8ec0:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    8ec4:	a90d7fe2 	stp	x2, xzr, [sp, #208]
    8ec8:	d37ff822 	lsl	x2, x1, #1
    8ecc:	b4000301 	cbz	x1, 8f2c <fwp_hof0.constprop.0+0x8cc>
    8ed0:	d10020e1 	sub	x1, x7, #0x8
    8ed4:	910020fb 	add	x27, x7, #0x8
    8ed8:	8b001020 	add	x0, x1, x0, lsl #4
    8edc:	910343e1 	add	x1, sp, #0xd0
    8ee0:	a9038bf3 	stp	x19, x2, [sp, #56]
    8ee4:	aa0003f3 	mov	x19, x0
    8ee8:	f90033f4 	str	x20, [sp, #96]
    8eec:	aa1b03f4 	mov	x20, x27
    8ef0:	aa0103fb 	mov	x27, x1
    8ef4:	a904a3e7 	stp	x7, x8, [sp, #72]
    8ef8:	fd400280 	ldr	d0, [x20]
    8efc:	f9400680 	ldr	x0, [x20, #8]
    8f00:	aa1b03e2 	mov	x2, x27
    8f04:	f9400e81 	ldr	x1, [x20, #24]
    8f08:	fd400a81 	ldr	d1, [x20, #16]
    8f0c:	97fff155 	bl	5460 <w120>
    8f10:	a9000680 	stp	x0, x1, [x20]
    8f14:	91004294 	add	x20, x20, #0x10
    8f18:	eb13029f 	cmp	x20, x19
    8f1c:	54fffee1 	b.ne	8ef8 <fwp_hof0.constprop.0+0x898>  // b.any
    8f20:	a9438bf3 	ldp	x19, x2, [sp, #56]
    8f24:	a944a3e7 	ldp	x7, x8, [sp, #72]
    8f28:	f94033f4 	ldr	x20, [sp, #96]
    8f2c:	f90000e2 	str	x2, [x7]
    8f30:	aa0703e0 	mov	x0, x7
    8f34:	a903a3e7 	stp	x7, x8, [sp, #56]
    8f38:	97fff29a 	bl	59a0 <w176.constprop.0>
    8f3c:	a943a3e7 	ldp	x7, x8, [sp, #56]
    8f40:	911702e3 	add	x3, x23, #0x5c0
    8f44:	aa0103fb 	mov	x27, x1
    8f48:	f949d861 	ldr	x1, [x3, #5040]
    8f4c:	f949ec60 	ldr	x0, [x3, #5080]
    8f50:	cb0100e1 	sub	x1, x7, x1
    8f54:	eb00403f 	cmp	x1, x0, lsl #16
    8f58:	54000382 	b.cs	8fc8 <fwp_hof0.constprop.0+0x968>  // b.hs, b.nlast
    8f5c:	d350fc20 	lsr	x0, x1, #16
    8f60:	f949fc65 	ldr	x5, [x3, #5112]
    8f64:	8b000800 	add	x0, x0, x0, lsl #2
    8f68:	d37df002 	lsl	x2, x0, #3
    8f6c:	8b0200a4 	add	x4, x5, x2
    8f70:	f9401080 	ldr	x0, [x4, #32]
    8f74:	b40002a0 	cbz	x0, 8fc8 <fwp_hof0.constprop.0+0x968>
    8f78:	386268a2 	ldrb	w2, [x5, x2]
    8f7c:	7100085f 	cmp	w2, #0x2
    8f80:	54001720 	b.eq	9264 <fwp_hof0.constprop.0+0xc04>  // b.none
    8f84:	7100045f 	cmp	w2, #0x1
    8f88:	54000201 	b.ne	8fc8 <fwp_hof0.constprop.0+0x968>  // b.any
    8f8c:	29430886 	ldp	w6, w2, [x4, #24]
    8f90:	92403c21 	and	x1, x1, #0xffff
    8f94:	9b067c21 	mul	x1, x1, x6
    8f98:	d360fc21 	lsr	x1, x1, #32
    8f9c:	eb02003f 	cmp	x1, x2
    8fa0:	54000142 	b.cs	8fc8 <fwp_hof0.constprop.0+0x968>  // b.hs, b.nlast
    8fa4:	8b010000 	add	x0, x0, x1
    8fa8:	39400001 	ldrb	w1, [x0]
    8fac:	340000e1 	cbz	w1, 8fc8 <fwp_hof0.constprop.0+0x968>
    8fb0:	7100043f 	cmp	w1, #0x1
    8fb4:	540006a0 	b.eq	9088 <fwp_hof0.constprop.0+0xa28>  // b.none
    8fb8:	7103fc3f 	cmp	w1, #0xff
    8fbc:	54004180 	b.eq	97ec <fwp_hof0.constprop.0+0x118c>  // b.none
    8fc0:	51000421 	sub	w1, w1, #0x1
    8fc4:	39000001 	strb	w1, [x0]
    8fc8:	52800040 	mov	w0, #0x2                   	// #2
    8fcc:	97ffe989 	bl	35f0 <descent_phase_step>
    8fd0:	b98033e0 	ldrsw	x0, [sp, #48]
    8fd4:	f9001fe0 	str	x0, [sp, #56]
    8fd8:	97ffee4e 	bl	4910 <fwp_tape_of>
    8fdc:	aa0003e5 	mov	x5, x0
    8fe0:	f9402809 	ldr	x9, [x0, #80]
    8fe4:	b4000e29 	cbz	x9, 91a8 <fwp_hof0.constprop.0+0xb48>
    8fe8:	b0000020 	adrp	x0, d000 <__divti3+0x2a0>
    8fec:	91224000 	add	x0, x0, #0x890
    8ff0:	97ffec44 	bl	4100 <fwp_trap>
    8ff4:	b0000020 	adrp	x0, d000 <__divti3+0x2a0>
    8ff8:	91290000 	add	x0, x0, #0xa40
    8ffc:	97ffec41 	bl	4100 <fwp_trap>
    9000:	d37ff864 	lsl	x4, x3, #1
    9004:	d29fffe0 	mov	x0, #0xffff                	// #65535
    9008:	eb00009f 	cmp	x4, x0
    900c:	9a80d084 	csel	x4, x4, x0, le
    9010:	8b040481 	add	x1, x4, x4, lsl #1
    9014:	d37ef421 	lsl	x1, x1, #2
    9018:	cb040021 	sub	x1, x1, x4
    901c:	d37df021 	lsl	x1, x1, #3
    9020:	17fffe60 	b	89a0 <fwp_hof0.constprop.0+0x340>
    9024:	d37ffb62 	lsl	x2, x27, #1
    9028:	d3707ce7 	ubfiz	x7, x7, #16, #32
    902c:	91000440 	add	x0, x2, #0x1
    9030:	aa0800e1 	orr	x1, x7, x8
    9034:	a9030be1 	stp	x1, x2, [sp, #48]
    9038:	52800041 	mov	w1, #0x2                   	// #2
    903c:	d37df000 	lsl	x0, x0, #3
    9040:	97ffefa8 	bl	4ee0 <fwp_heap_alloc>
    9044:	aa0003e7 	mov	x7, x0
    9048:	911702e1 	add	x1, x23, #0x5c0
    904c:	aa0003e8 	mov	x8, x0
    9050:	f9401fe2 	ldr	x2, [sp, #56]
    9054:	aa0103e0 	mov	x0, x1
    9058:	f90000e2 	str	x2, [x7]
    905c:	f949d821 	ldr	x1, [x1, #5040]
    9060:	f949ec00 	ldr	x0, [x0, #5080]
    9064:	cb0100e1 	sub	x1, x7, x1
    9068:	eb00403f 	cmp	x1, x0, lsl #16
    906c:	54ffec43 	b.cc	8df4 <fwp_hof0.constprop.0+0x794>  // b.lo, b.ul, b.last
    9070:	b5ffef7b 	cbnz	x27, 8e5c <fwp_hof0.constprop.0+0x7fc>
    9074:	d2800002 	mov	x2, #0x0                   	// #0
    9078:	17ffffad 	b	8f2c <fwp_hof0.constprop.0+0x8cc>
    907c:	72003c3f 	tst	w1, #0xffff
    9080:	54ffeec1 	b.ne	8e58 <fwp_hof0.constprop.0+0x7f8>  // b.any
    9084:	17ffff70 	b	8e44 <fwp_hof0.constprop.0+0x7e4>
    9088:	f9400106 	ldr	x6, [x8]
    908c:	aa0803e0 	mov	x0, x8
    9090:	f949ec62 	ldr	x2, [x3, #5080]
    9094:	f949d861 	ldr	x1, [x3, #5040]
    9098:	d370bc44 	lsl	x4, x2, #16
    909c:	cb010102 	sub	x2, x8, x1
    90a0:	b7f80e86 	tbnz	x6, #63, 9270 <fwp_hof0.constprop.0+0xc10>
    90a4:	eb04005f 	cmp	x2, x4
    90a8:	54fff902 	b.cs	8fc8 <fwp_hof0.constprop.0+0x968>  // b.hs, b.nlast
    90ac:	d350fc40 	lsr	x0, x2, #16
    90b0:	8b000800 	add	x0, x0, x0, lsl #2
    90b4:	d37df000 	lsl	x0, x0, #3
    90b8:	8b0000a3 	add	x3, x5, x0
    90bc:	f9401061 	ldr	x1, [x3, #32]
    90c0:	b4fff841 	cbz	x1, 8fc8 <fwp_hof0.constprop.0+0x968>
    90c4:	386068a0 	ldrb	w0, [x5, x0]
    90c8:	7100081f 	cmp	w0, #0x2
    90cc:	540033a0 	b.eq	9740 <fwp_hof0.constprop.0+0x10e0>  // b.none
    90d0:	7100041f 	cmp	w0, #0x1
    90d4:	54fff7a1 	b.ne	8fc8 <fwp_hof0.constprop.0+0x968>  // b.any
    90d8:	92403c40 	and	x0, x2, #0xffff
    90dc:	29430864 	ldp	w4, w2, [x3, #24]
    90e0:	9b047c00 	mul	x0, x0, x4
    90e4:	d360fc00 	lsr	x0, x0, #32
    90e8:	eb02001f 	cmp	x0, x2
    90ec:	54fff6e2 	b.cs	8fc8 <fwp_hof0.constprop.0+0x968>  // b.hs, b.nlast
    90f0:	8b000021 	add	x1, x1, x0
    90f4:	39400020 	ldrb	w0, [x1]
    90f8:	7100041f 	cmp	w0, #0x1
    90fc:	54fff661 	b.ne	8fc8 <fwp_hof0.constprop.0+0x968>  // b.any
    9100:	aa0803e0 	mov	x0, x8
    9104:	97ffecbb 	bl	43f0 <fwp_mem_free>
    9108:	17ffffb0 	b	8fc8 <fwp_hof0.constprop.0+0x968>
    910c:	90000020 	adrp	x0, d000 <__divti3+0x2a0>
    9110:	912b0000 	add	x0, x0, #0xac0
    9114:	97ffebfb 	bl	4100 <fwp_trap>
    9118:	97ffed2f 	bl	45d4 <fwp_rc_wide_dup>
    911c:	911702e0 	add	x0, x23, #0x5c0
    9120:	f949ec05 	ldr	x5, [x0, #5080]
    9124:	f949d801 	ldr	x1, [x0, #5040]
    9128:	d370bca5 	lsl	x5, x5, #16
    912c:	17fffd8f 	b	8768 <fwp_hof0.constprop.0+0x108>
    9130:	ca5b4760 	eor	x0, x27, x27, lsr #17
    9134:	911702e1 	add	x1, x23, #0x5c0
    9138:	ca402400 	eor	x0, x0, x0, lsr #9
    913c:	92401c00 	and	x0, x0, #0xff
    9140:	910a2402 	add	x2, x0, #0x289
    9144:	8b000c20 	add	x0, x1, x0, lsl #3
    9148:	8b020c22 	add	x2, x1, x2, lsl #3
    914c:	f94a2400 	ldr	x0, [x0, #5192]
    9150:	b50000a0 	cbnz	x0, 9164 <fwp_hof0.constprop.0+0xb04>
    9154:	1400017e 	b	974c <fwp_hof0.constprop.0+0x10ec>
    9158:	91004002 	add	x2, x0, #0x10
    915c:	f9400800 	ldr	x0, [x0, #16]
    9160:	b4002f60 	cbz	x0, 974c <fwp_hof0.constprop.0+0x10ec>
    9164:	f9400001 	ldr	x1, [x0]
    9168:	eb01037f 	cmp	x27, x1
    916c:	54ffff61 	b.ne	9158 <fwp_hof0.constprop.0+0xaf8>  // b.any
    9170:	f9400041 	ldr	x1, [x2]
    9174:	f9400420 	ldr	x0, [x1, #8]
    9178:	d1000400 	sub	x0, x0, #0x1
    917c:	f9000420 	str	x0, [x1, #8]
    9180:	f103f81f 	cmp	x0, #0xfe
    9184:	54ffb8a1 	b.ne	8898 <fwp_hof0.constprop.0+0x238>  // b.any
    9188:	39400360 	ldrb	w0, [x27]
    918c:	7103fc1f 	cmp	w0, #0xff
    9190:	54003000 	b.eq	9790 <fwp_hof0.constprop.0+0x1130>  // b.none
    9194:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9198:	39000360 	strb	w0, [x27]
    919c:	17fffdbf 	b	8898 <fwp_hof0.constprop.0+0x238>
    91a0:	97ffed0d 	bl	45d4 <fwp_rc_wide_dup>
    91a4:	17fffd9c 	b	8814 <fwp_hof0.constprop.0+0x1b4>
    91a8:	97ffe77a 	bl	2f90 <fwp_tape_unlink_scope>
    91ac:	b90004bf 	str	wzr, [x5, #4]
    91b0:	3dc008a0 	ldr	q0, [x5, #32]
    91b4:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    91b8:	b94000a1 	ldr	w1, [x5]
    91bc:	a9409ca6 	ldp	x6, x7, [x5, #8]
    91c0:	3d8017e0 	str	q0, [sp, #80]
    91c4:	f9400ca3 	ldr	x3, [x5, #24]
    91c8:	a94308a4 	ldp	x4, x2, [x5, #48]
    91cc:	6b00003f 	cmp	w1, w0
    91d0:	54000128 	b.hi	91f4 <fwp_hof0.constprop.0+0xb94>  // b.pmore
    91d4:	9101c2a1 	add	x1, x21, #0x70
    91d8:	f9401fe0 	ldr	x0, [sp, #56]
    91dc:	f9406c28 	ldr	x8, [x1, #216]
    91e0:	92403c00 	and	x0, x0, #0xffff
    91e4:	d1000400 	sub	x0, x0, #0x1
    91e8:	eb08001f 	cmp	x0, x8
    91ec:	5400004a 	b.ge	91f4 <fwp_hof0.constprop.0+0xb94>  // b.tcont
    91f0:	f9006c20 	str	x0, [x1, #216]
    91f4:	4f000400 	movi	v0.4s, #0x0
    91f8:	9101c2a1 	add	x1, x21, #0x70
    91fc:	f9000cbf 	str	xzr, [x5, #24]
    9200:	a9037cbf 	stp	xzr, xzr, [x5, #48]
    9204:	f9418020 	ldr	x0, [x1, #768]
    9208:	3c8080a0 	stur	q0, [x5, #8]
    920c:	3d8008a0 	str	q0, [x5, #32]
    9210:	9102e3e5 	add	x5, sp, #0xb8
    9214:	3dc017e0 	ldr	q0, [sp, #80]
    9218:	f9005fe0 	str	x0, [sp, #184]
    921c:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    9220:	913fc000 	add	x0, x0, #0xff0
    9224:	f90033e5 	str	x5, [sp, #96]
    9228:	f90063e0 	str	x0, [sp, #192]
    922c:	910343e0 	add	x0, sp, #0xd0
    9230:	f9001be0 	str	x0, [sp, #48]
    9234:	f90067e0 	str	x0, [sp, #200]
    9238:	a90e0fe4 	stp	x4, x3, [sp, #224]
    923c:	f9007be2 	str	x2, [sp, #240]
    9240:	f9018025 	str	x5, [x1, #768]
    9244:	3d8037e0 	str	q0, [sp, #208]
    9248:	b7f8289b 	tbnz	x27, #63, 9758 <fwp_hof0.constprop.0+0x10f8>
    924c:	f9401fe0 	ldr	x0, [sp, #56]
    9250:	eb9b801f 	cmp	x0, x27, asr #32
    9254:	54000540 	b.eq	92fc <fwp_hof0.constprop.0+0xc9c>  // b.none
    9258:	90000020 	adrp	x0, d000 <__divti3+0x2a0>
    925c:	91212000 	add	x0, x0, #0x848
    9260:	97ffeba8 	bl	4100 <fwp_trap>
    9264:	72003c3f 	tst	w1, #0xffff
    9268:	54ffeb01 	b.ne	8fc8 <fwp_hof0.constprop.0+0x968>  // b.any
    926c:	17ffff4f 	b	8fa8 <fwp_hof0.constprop.0+0x948>
    9270:	f9400508 	ldr	x8, [x8, #8]
    9274:	eb04005f 	cmp	x2, x4
    9278:	540003a2 	b.cs	92ec <fwp_hof0.constprop.0+0xc8c>  // b.hs, b.nlast
    927c:	d350fc46 	lsr	x6, x2, #16
    9280:	8b0608c6 	add	x6, x6, x6, lsl #2
    9284:	d37df0c6 	lsl	x6, x6, #3
    9288:	8b0600a9 	add	x9, x5, x6
    928c:	f9401127 	ldr	x7, [x9, #32]
    9290:	b40002e7 	cbz	x7, 92ec <fwp_hof0.constprop.0+0xc8c>
    9294:	386668a5 	ldrb	w5, [x5, x6]
    9298:	710008bf 	cmp	w5, #0x2
    929c:	540026e0 	b.eq	9778 <fwp_hof0.constprop.0+0x1118>  // b.none
    92a0:	710004bf 	cmp	w5, #0x1
    92a4:	54000241 	b.ne	92ec <fwp_hof0.constprop.0+0xc8c>  // b.any
    92a8:	29431526 	ldp	w6, w5, [x9, #24]
    92ac:	92403c42 	and	x2, x2, #0xffff
    92b0:	9b067c42 	mul	x2, x2, x6
    92b4:	d360fc42 	lsr	x2, x2, #32
    92b8:	eb05005f 	cmp	x2, x5
    92bc:	54000182 	b.cs	92ec <fwp_hof0.constprop.0+0xc8c>  // b.hs, b.nlast
    92c0:	8b0200e7 	add	x7, x7, x2
    92c4:	394000e2 	ldrb	w2, [x7]
    92c8:	7100045f 	cmp	w2, #0x1
    92cc:	54000101 	b.ne	92ec <fwp_hof0.constprop.0+0xc8c>  // b.any
    92d0:	a9038fe8 	stp	x8, x3, [sp, #56]
    92d4:	97ffec47 	bl	43f0 <fwp_mem_free>
    92d8:	911702e0 	add	x0, x23, #0x5c0
    92dc:	a9438fe8 	ldp	x8, x3, [sp, #56]
    92e0:	f949ec02 	ldr	x2, [x0, #5080]
    92e4:	f949d801 	ldr	x1, [x0, #5040]
    92e8:	d370bc44 	lsl	x4, x2, #16
    92ec:	cb010101 	sub	x1, x8, x1
    92f0:	eb01009f 	cmp	x4, x1
    92f4:	54ffe348 	b.hi	8f5c <fwp_hof0.constprop.0+0x8fc>  // b.pmore
    92f8:	17ffff34 	b	8fc8 <fwp_hof0.constprop.0+0x968>
    92fc:	92407f63 	and	x3, x27, #0xffffffff
    9300:	eb3b40ff 	cmp	x7, w27, uxtw
    9304:	5400240d 	b.le	9784 <fwp_hof0.constprop.0+0x1124>
    9308:	eb0300df 	cmp	x6, x3
    930c:	9a83c4c3 	csinc	x3, x6, x3, gt
    9310:	eb03005f 	cmp	x2, x3
    9314:	5400244a 	b.ge	979c <fwp_hof0.constprop.0+0x113c>  // b.tcont
    9318:	f100005f 	cmp	x2, #0x0
    931c:	b24077e5 	mov	x5, #0x3fffffff            	// #1073741823
    9320:	9a831042 	csel	x2, x2, x3, ne	// ne = any
    9324:	14000004 	b	9334 <fwp_hof0.constprop.0+0xcd4>
    9328:	eb05005f 	cmp	x2, x5
    932c:	d37ff842 	lsl	x2, x2, #1
    9330:	9a83d042 	csel	x2, x2, x3, le
    9334:	eb03005f 	cmp	x2, x3
    9338:	54ffff8b 	b.lt	9328 <fwp_hof0.constprop.0+0xcc8>  // b.tstop
    933c:	a9040fe6 	stp	x6, x3, [sp, #64]
    9340:	b4003f04 	cbz	x4, 9b20 <fwp_hof0.constprop.0+0x14c0>
    9344:	aa0403e0 	mov	x0, x4
    9348:	d37df041 	lsl	x1, x2, #3
    934c:	f9001fe2 	str	x2, [sp, #56]
    9350:	97ffe54c 	bl	2880 <realloc@plt>
    9354:	a9439be2 	ldp	x2, x6, [sp, #56]
    9358:	aa0003e4 	mov	x4, x0
    935c:	f94027e3 	ldr	x3, [sp, #72]
    9360:	b40021e4 	cbz	x4, 979c <fwp_hof0.constprop.0+0x113c>
    9364:	f90073e4 	str	x4, [sp, #224]
    9368:	f9007be2 	str	x2, [sp, #240]
    936c:	b5001da3 	cbnz	x3, 9720 <fwp_hof0.constprop.0+0x10c0>
    9370:	b7f800db 	tbnz	x27, #63, 9388 <fwp_hof0.constprop.0+0xd28>
    9374:	92407f7b 	and	x27, x27, #0xffffffff
    9378:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    937c:	fc7b7880 	ldr	d0, [x4, x27, lsl #3]
    9380:	1e612800 	fadd	d0, d0, d1
    9384:	fc3b7880 	str	d0, [x4, x27, lsl #3]
    9388:	9101c2a1 	add	x1, x21, #0x70
    938c:	cb06007b 	sub	x27, x3, x6
    9390:	52800060 	mov	w0, #0x3                   	// #3
    9394:	a9038fe6 	stp	x6, x3, [sp, #56]
    9398:	a9429422 	ldp	x2, x5, [x1, #40]
    939c:	f90027e4 	str	x4, [sp, #72]
    93a0:	8b0600a5 	add	x5, x5, x6
    93a4:	8b1b0042 	add	x2, x2, x27
    93a8:	a9029422 	stp	x2, x5, [x1, #40]
    93ac:	97ffe891 	bl	35f0 <descent_phase_step>
    93b0:	a9438fe6 	ldp	x6, x3, [sp, #56]
    93b4:	f94027e4 	ldr	x4, [sp, #72]
    93b8:	d1000463 	sub	x3, x3, #0x1
    93bc:	eb0300df 	cmp	x6, x3
    93c0:	540003ac 	b.gt	9434 <fwp_hof0.constprop.0+0xdd4>
    93c4:	f9402be0 	ldr	x0, [sp, #80]
    93c8:	8b1b077b 	add	x27, x27, x27, lsl #1
    93cc:	d10004c2 	sub	x2, x6, #0x1
    93d0:	d1006000 	sub	x0, x0, #0x18
    93d4:	8b1b0c00 	add	x0, x0, x27, lsl #3
    93d8:	fc637880 	ldr	d0, [x4, x3, lsl #3]
    93dc:	1e602008 	fcmp	d0, #0.0
    93e0:	54000220 	b.eq	9424 <fwp_hof0.constprop.0+0xdc4>  // b.none
    93e4:	b9400001 	ldr	w1, [x0]
    93e8:	37f800e1 	tbnz	w1, #31, 9404 <fwp_hof0.constprop.0+0xda4>
    93ec:	fd400402 	ldr	d2, [x0, #8]
    93f0:	93407c21 	sxtw	x1, w1
    93f4:	1e620802 	fmul	d2, d0, d2
    93f8:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    93fc:	1e622821 	fadd	d1, d1, d2
    9400:	fc217881 	str	d1, [x4, x1, lsl #3]
    9404:	b9400401 	ldr	w1, [x0, #4]
    9408:	37f800e1 	tbnz	w1, #31, 9424 <fwp_hof0.constprop.0+0xdc4>
    940c:	fd400801 	ldr	d1, [x0, #16]
    9410:	93407c21 	sxtw	x1, w1
    9414:	1e610800 	fmul	d0, d0, d1
    9418:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    941c:	1e602820 	fadd	d0, d1, d0
    9420:	fc217880 	str	d0, [x4, x1, lsl #3]
    9424:	d1000463 	sub	x3, x3, #0x1
    9428:	d1006000 	sub	x0, x0, #0x18
    942c:	eb02007f 	cmp	x3, x2
    9430:	54fffd41 	b.ne	93d8 <fwp_hof0.constprop.0+0xd78>  // b.any
    9434:	52800080 	mov	w0, #0x4                   	// #4
    9438:	a90393e6 	stp	x6, x4, [sp, #56]
    943c:	97ffe86d 	bl	35f0 <descent_phase_step>
    9440:	a94393e6 	ldp	x6, x4, [sp, #56]
    9444:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9448:	eb0000df 	cmp	x6, x0
    944c:	54002628 	b.hi	9910 <fwp_hof0.constprop.0+0x12b0>  // b.pmore
    9450:	910004c0 	add	x0, x6, #0x1
    9454:	52800041 	mov	w1, #0x2                   	// #2
    9458:	a90393e6 	stp	x6, x4, [sp, #56]
    945c:	d37df000 	lsl	x0, x0, #3
    9460:	97ffeea0 	bl	4ee0 <fwp_heap_alloc>
    9464:	aa0003fb 	mov	x27, x0
    9468:	a94393e6 	ldp	x6, x4, [sp, #56]
    946c:	f8008406 	str	x6, [x0], #8
    9470:	d2800001 	mov	x1, #0x0                   	// #0
    9474:	b40000c6 	cbz	x6, 948c <fwp_hof0.constprop.0+0xe2c>
    9478:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    947c:	f8217802 	str	x2, [x0, x1, lsl #3]
    9480:	91000421 	add	x1, x1, #0x1
    9484:	eb0100df 	cmp	x6, x1
    9488:	54ffff81 	b.ne	9478 <fwp_hof0.constprop.0+0xe18>  // b.any
    948c:	528000a0 	mov	w0, #0x5                   	// #5
    9490:	97ffe858 	bl	35f0 <descent_phase_step>
    9494:	9101c2a1 	add	x1, x21, #0x70
    9498:	f94033e2 	ldr	x2, [sp, #96]
    949c:	f9418020 	ldr	x0, [x1, #768]
    94a0:	eb02001f 	cmp	x0, x2
    94a4:	54006761 	b.ne	a190 <fwp_hof0.constprop.0+0x1b30>  // b.any
    94a8:	f9401be0 	ldr	x0, [sp, #48]
    94ac:	f9405fe3 	ldr	x3, [sp, #184]
    94b0:	f9001fe3 	str	x3, [sp, #56]
    94b4:	f9018023 	str	x3, [x1, #768]
    94b8:	97ffeace 	bl	3ff0 <fwp_tape_buffers_release>
    94bc:	528000c0 	mov	w0, #0x6                   	// #6
    94c0:	97ffe84c 	bl	35f0 <descent_phase_step>
    94c4:	911702e2 	add	x2, x23, #0x5c0
    94c8:	f9401fe3 	ldr	x3, [sp, #56]
    94cc:	f949d841 	ldr	x1, [x2, #5040]
    94d0:	f949ec40 	ldr	x0, [x2, #5080]
    94d4:	cb010361 	sub	x1, x27, x1
    94d8:	eb00403f 	cmp	x1, x0, lsl #16
    94dc:	54000322 	b.cs	9540 <fwp_hof0.constprop.0+0xee0>  // b.hs, b.nlast
    94e0:	d350fc20 	lsr	x0, x1, #16
    94e4:	f949fc45 	ldr	x5, [x2, #5112]
    94e8:	8b000800 	add	x0, x0, x0, lsl #2
    94ec:	d37df002 	lsl	x2, x0, #3
    94f0:	8b0200a4 	add	x4, x5, x2
    94f4:	f9401080 	ldr	x0, [x4, #32]
    94f8:	b4000240 	cbz	x0, 9540 <fwp_hof0.constprop.0+0xee0>
    94fc:	386268a2 	ldrb	w2, [x5, x2]
    9500:	7100085f 	cmp	w2, #0x2
    9504:	54003080 	b.eq	9b14 <fwp_hof0.constprop.0+0x14b4>  // b.none
    9508:	7100045f 	cmp	w2, #0x1
    950c:	540001a1 	b.ne	9540 <fwp_hof0.constprop.0+0xee0>  // b.any
    9510:	29430885 	ldp	w5, w2, [x4, #24]
    9514:	92403c21 	and	x1, x1, #0xffff
    9518:	9b057c21 	mul	x1, x1, x5
    951c:	d360fc21 	lsr	x1, x1, #32
    9520:	eb02003f 	cmp	x1, x2
    9524:	540000e2 	b.cs	9540 <fwp_hof0.constprop.0+0xee0>  // b.hs, b.nlast
    9528:	8b010000 	add	x0, x0, x1
    952c:	39400001 	ldrb	w1, [x0]
    9530:	7103fc3f 	cmp	w1, #0xff
    9534:	540030c0 	b.eq	9b4c <fwp_hof0.constprop.0+0x14ec>  // b.none
    9538:	52800021 	mov	w1, #0x1                   	// #1
    953c:	39000001 	strb	w1, [x0]
    9540:	f9400be0 	ldr	x0, [sp, #16]
    9544:	eb00007f 	cmp	x3, x0
    9548:	54006241 	b.ne	a190 <fwp_hof0.constprop.0+0x1b30>  // b.any
    954c:	f94007e0 	ldr	x0, [sp, #8]
    9550:	9101c2a1 	add	x1, x21, #0x70
    9554:	f94053e2 	ldr	x2, [sp, #160]
    9558:	f9018022 	str	x2, [x1, #768]
    955c:	97fff409 	bl	6580 <fwp_tape_scope_release>
    9560:	f9400360 	ldr	x0, [x27]
    9564:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    9568:	b7f817e0 	tbnz	x0, #63, 9864 <fwp_hof0.constprop.0+0x1204>
    956c:	911702e3 	add	x3, x23, #0x5c0
    9570:	f949d860 	ldr	x0, [x3, #5040]
    9574:	f949ec61 	ldr	x1, [x3, #5080]
    9578:	cb000360 	sub	x0, x27, x0
    957c:	eb01401f 	cmp	x0, x1, lsl #16
    9580:	54001722 	b.cs	9864 <fwp_hof0.constprop.0+0x1204>  // b.hs, b.nlast
    9584:	d350fc01 	lsr	x1, x0, #16
    9588:	f949fc65 	ldr	x5, [x3, #5112]
    958c:	8b010821 	add	x1, x1, x1, lsl #2
    9590:	d37df021 	lsl	x1, x1, #3
    9594:	8b0100a4 	add	x4, x5, x1
    9598:	f9401083 	ldr	x3, [x4, #32]
    959c:	b4001643 	cbz	x3, 9864 <fwp_hof0.constprop.0+0x1204>
    95a0:	386168a1 	ldrb	w1, [x5, x1]
    95a4:	7100083f 	cmp	w1, #0x2
    95a8:	540015a0 	b.eq	985c <fwp_hof0.constprop.0+0x11fc>  // b.none
    95ac:	7100043f 	cmp	w1, #0x1
    95b0:	540015a1 	b.ne	9864 <fwp_hof0.constprop.0+0x1204>  // b.any
    95b4:	29430485 	ldp	w5, w1, [x4, #24]
    95b8:	92403c00 	and	x0, x0, #0xffff
    95bc:	9b057c00 	mul	x0, x0, x5
    95c0:	d360fc00 	lsr	x0, x0, #32
    95c4:	eb01001f 	cmp	x0, x1
    95c8:	540014e2 	b.cs	9864 <fwp_hof0.constprop.0+0x1204>  // b.hs, b.nlast
    95cc:	8b000063 	add	x3, x3, x0
    95d0:	39400060 	ldrb	w0, [x3]
    95d4:	7100041f 	cmp	w0, #0x1
    95d8:	54001461 	b.ne	9864 <fwp_hof0.constprop.0+0x1204>  // b.any
    95dc:	aa1b03e3 	mov	x3, x27
    95e0:	d2800000 	mov	x0, #0x0                   	// #0
    95e4:	91002064 	add	x4, x3, #0x8
    95e8:	d2800001 	mov	x1, #0x0                   	// #0
    95ec:	b40001e2 	cbz	x2, 9628 <fwp_hof0.constprop.0+0xfc8>
    95f0:	b0000025 	adrp	x5, e000 <_IO_stdin_used+0xb80>
    95f4:	91002366 	add	x6, x27, #0x8
    95f8:	fd4160a1 	ldr	d1, [x5, #704]
    95fc:	f9400367 	ldr	x7, [x27]
    9600:	aa0603e5 	mov	x5, x6
    9604:	b7f818c7 	tbnz	x7, #63, 991c <fwp_hof0.constprop.0+0x12bc>
    9608:	f9400067 	ldr	x7, [x3]
    960c:	fc6178a0 	ldr	d0, [x5, x1, lsl #3]
    9610:	b7f82987 	tbnz	x7, #63, 9b40 <fwp_hof0.constprop.0+0x14e0>
    9614:	1e600820 	fmul	d0, d1, d0
    9618:	91000421 	add	x1, x1, #0x1
    961c:	fc008480 	str	d0, [x4], #8
    9620:	eb01005f 	cmp	x2, x1
    9624:	54fffec1 	b.ne	95fc <fwp_hof0.constprop.0+0xf9c>  // b.any
    9628:	f9001fe3 	str	x3, [sp, #56]
    962c:	97fff5e1 	bl	6db0 <fwp_drop10>
    9630:	f9401fe3 	ldr	x3, [sp, #56]
    9634:	b4002a13 	cbz	x19, 9b74 <fwp_hof0.constprop.0+0x1514>
    9638:	aa1303e0 	mov	x0, x19
    963c:	d280001b 	mov	x27, #0x0                   	// #0
    9640:	f9400800 	ldr	x0, [x0, #16]
    9644:	9100077b 	add	x27, x27, #0x1
    9648:	b5ffffc0 	cbnz	x0, 9640 <fwp_hof0.constprop.0+0xfe0>
    964c:	f9400060 	ldr	x0, [x3]
    9650:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    9654:	b7f81680 	tbnz	x0, #63, 9924 <fwp_hof0.constprop.0+0x12c4>
    9658:	911702e1 	add	x1, x23, #0x5c0
    965c:	f949d820 	ldr	x0, [x1, #5040]
    9660:	f949ec24 	ldr	x4, [x1, #5080]
    9664:	cb000060 	sub	x0, x3, x0
    9668:	eb04401f 	cmp	x0, x4, lsl #16
    966c:	54002922 	b.cs	9b90 <fwp_hof0.constprop.0+0x1530>  // b.hs, b.nlast
    9670:	d350fc04 	lsr	x4, x0, #16
    9674:	d2800505 	mov	x5, #0x28                  	// #40
    9678:	f949fc26 	ldr	x6, [x1, #5112]
    967c:	9b057c84 	mul	x4, x4, x5
    9680:	8b0400c5 	add	x5, x6, x4
    9684:	f94010a1 	ldr	x1, [x5, #32]
    9688:	b4002841 	cbz	x1, 9b90 <fwp_hof0.constprop.0+0x1530>
    968c:	386468c4 	ldrb	w4, [x6, x4]
    9690:	7100089f 	cmp	w4, #0x2
    9694:	540027a0 	b.eq	9b88 <fwp_hof0.constprop.0+0x1528>  // b.none
    9698:	7100049f 	cmp	w4, #0x1
    969c:	540027a1 	b.ne	9b90 <fwp_hof0.constprop.0+0x1530>  // b.any
    96a0:	294310a6 	ldp	w6, w4, [x5, #24]
    96a4:	92403c00 	and	x0, x0, #0xffff
    96a8:	9b067c00 	mul	x0, x0, x6
    96ac:	d360fc00 	lsr	x0, x0, #32
    96b0:	eb04001f 	cmp	x0, x4
    96b4:	540026e2 	b.cs	9b90 <fwp_hof0.constprop.0+0x1530>  // b.hs, b.nlast
    96b8:	8b000021 	add	x1, x1, x0
    96bc:	39400028 	ldrb	w8, [x1]
    96c0:	7100051f 	cmp	w8, #0x1
    96c4:	54002661 	b.ne	9b90 <fwp_hof0.constprop.0+0x1530>  // b.any
    96c8:	91002065 	add	x5, x3, #0x8
    96cc:	eb1b005f 	cmp	x2, x27
    96d0:	9a9b9042 	csel	x2, x2, x27, ls	// ls = plast
    96d4:	b40026e2 	cbz	x2, 9bb0 <fwp_hof0.constprop.0+0x1550>
    96d8:	d37df047 	lsl	x7, x2, #3
    96dc:	aa1303e1 	mov	x1, x19
    96e0:	91002066 	add	x6, x3, #0x8
    96e4:	d2800000 	mov	x0, #0x0                   	// #0
    96e8:	14000009 	b	970c <fwp_hof0.constprop.0+0x10ac>
    96ec:	fc606881 	ldr	d1, [x4, x0]
    96f0:	fd400420 	ldr	d0, [x1, #8]
    96f4:	1e613800 	fsub	d0, d0, d1
    96f8:	fc2068a0 	str	d0, [x5, x0]
    96fc:	91002000 	add	x0, x0, #0x8
    9700:	f9400821 	ldr	x1, [x1, #16]
    9704:	eb0000ff 	cmp	x7, x0
    9708:	540013c0 	b.eq	9980 <fwp_hof0.constprop.0+0x1320>  // b.none
    970c:	f9400069 	ldr	x9, [x3]
    9710:	aa0603e4 	mov	x4, x6
    9714:	b6fffec9 	tbz	x9, #63, 96ec <fwp_hof0.constprop.0+0x108c>
    9718:	f9400864 	ldr	x4, [x3, #16]
    971c:	17fffff4 	b	96ec <fwp_hof0.constprop.0+0x108c>
    9720:	d37df062 	lsl	x2, x3, #3
    9724:	aa0403e0 	mov	x0, x4
    9728:	52800001 	mov	w1, #0x0                   	// #0
    972c:	a9039be3 	stp	x3, x6, [sp, #56]
    9730:	97ffe44c 	bl	2860 <memset@plt>
    9734:	a9439be3 	ldp	x3, x6, [sp, #56]
    9738:	aa0003e4 	mov	x4, x0
    973c:	17ffff0d 	b	9370 <fwp_hof0.constprop.0+0xd10>
    9740:	72003c5f 	tst	w2, #0xffff
    9744:	54ffc421 	b.ne	8fc8 <fwp_hof0.constprop.0+0x968>  // b.any
    9748:	17fffe6b 	b	90f4 <fwp_hof0.constprop.0+0xa94>
    974c:	90000020 	adrp	x0, d000 <__divti3+0x2a0>
    9750:	9119e000 	add	x0, x0, #0x678
    9754:	97ffea6b 	bl	4100 <fwp_trap>
    9758:	aa0603e3 	mov	x3, x6
    975c:	17fffeed 	b	9310 <fwp_hof0.constprop.0+0xcb0>
    9760:	a9039fe0 	stp	x0, x7, [sp, #56]
    9764:	f90027e8 	str	x8, [sp, #72]
    9768:	97ffea86 	bl	4180 <fwp_rc_forget_slot.part.0>
    976c:	a9439fe0 	ldp	x0, x7, [sp, #56]
    9770:	f94027e8 	ldr	x8, [sp, #72]
    9774:	17fffdb7 	b	8e50 <fwp_hof0.constprop.0+0x7f0>
    9778:	72003c5f 	tst	w2, #0xffff
    977c:	54ffdb81 	b.ne	92ec <fwp_hof0.constprop.0+0xc8c>  // b.any
    9780:	17fffed1 	b	92c4 <fwp_hof0.constprop.0+0xc64>
    9784:	90000020 	adrp	x0, d000 <__divti3+0x2a0>
    9788:	91230000 	add	x0, x0, #0x8c0
    978c:	97ffea5d 	bl	4100 <fwp_trap>
    9790:	aa1b03e0 	mov	x0, x27
    9794:	97ffea7b 	bl	4180 <fwp_rc_forget_slot.part.0>
    9798:	17fffe7f 	b	9194 <fwp_hof0.constprop.0+0xb34>
    979c:	f100007f 	cmp	x3, #0x0
    97a0:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    97a4:	54ffde41 	b.ne	936c <fwp_hof0.constprop.0+0xd0c>  // b.any
    97a8:	f9401be0 	ldr	x0, [sp, #48]
    97ac:	9101c2b5 	add	x21, x21, #0x70
    97b0:	f9405fe1 	ldr	x1, [sp, #184]
    97b4:	f90182a1 	str	x1, [x21, #768]
    97b8:	97ffea0e 	bl	3ff0 <fwp_tape_buffers_release>
    97bc:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    97c0:	f947e863 	ldr	x3, [x3, #4048]
    97c4:	d2800262 	mov	x2, #0x13                  	// #19
    97c8:	d2800021 	mov	x1, #0x1                   	// #1
    97cc:	90000020 	adrp	x0, d000 <__divti3+0x2a0>
    97d0:	91122000 	add	x0, x0, #0x488
    97d4:	f9400063 	ldr	x3, [x3]
    97d8:	97ffe46e 	bl	2990 <fwrite@plt>
    97dc:	d2800000 	mov	x0, #0x0                   	// #0
    97e0:	97ffe478 	bl	29c0 <fflush@plt>
    97e4:	52800cc0 	mov	w0, #0x66                  	// #102
    97e8:	97ffe486 	bl	2a00 <_Exit@plt>
    97ec:	ca404401 	eor	x1, x0, x0, lsr #17
    97f0:	911702e3 	add	x3, x23, #0x5c0
    97f4:	ca412421 	eor	x1, x1, x1, lsr #9
    97f8:	92401c21 	and	x1, x1, #0xff
    97fc:	910a2422 	add	x2, x1, #0x289
    9800:	8b010c61 	add	x1, x3, x1, lsl #3
    9804:	8b020c62 	add	x2, x3, x2, lsl #3
    9808:	f94a2421 	ldr	x1, [x1, #5192]
    980c:	b50000a1 	cbnz	x1, 9820 <fwp_hof0.constprop.0+0x11c0>
    9810:	17ffffcf 	b	974c <fwp_hof0.constprop.0+0x10ec>
    9814:	91004022 	add	x2, x1, #0x10
    9818:	f9400821 	ldr	x1, [x1, #16]
    981c:	b4fff981 	cbz	x1, 974c <fwp_hof0.constprop.0+0x10ec>
    9820:	f9400023 	ldr	x3, [x1]
    9824:	eb00007f 	cmp	x3, x0
    9828:	54ffff61 	b.ne	9814 <fwp_hof0.constprop.0+0x11b4>  // b.any
    982c:	f9400042 	ldr	x2, [x2]
    9830:	f9400441 	ldr	x1, [x2, #8]
    9834:	d1000421 	sub	x1, x1, #0x1
    9838:	f9000441 	str	x1, [x2, #8]
    983c:	f103f83f 	cmp	x1, #0xfe
    9840:	54ffbc41 	b.ne	8fc8 <fwp_hof0.constprop.0+0x968>  // b.any
    9844:	39400001 	ldrb	w1, [x0]
    9848:	7103fc3f 	cmp	w1, #0xff
    984c:	540018c0 	b.eq	9b64 <fwp_hof0.constprop.0+0x1504>  // b.none
    9850:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9854:	39000001 	strb	w1, [x0]
    9858:	17fffddc 	b	8fc8 <fwp_hof0.constprop.0+0x968>
    985c:	72003c1f 	tst	w0, #0xffff
    9860:	54ffeb80 	b.eq	95d0 <fwp_hof0.constprop.0+0xf70>  // b.none
    9864:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9868:	eb00005f 	cmp	x2, x0
    986c:	54000528 	b.hi	9910 <fwp_hof0.constprop.0+0x12b0>  // b.pmore
    9870:	91000440 	add	x0, x2, #0x1
    9874:	52800021 	mov	w1, #0x1                   	// #1
    9878:	f9001fe2 	str	x2, [sp, #56]
    987c:	d37df000 	lsl	x0, x0, #3
    9880:	97ffed98 	bl	4ee0 <fwp_heap_alloc>
    9884:	f9401fe2 	ldr	x2, [sp, #56]
    9888:	911702e5 	add	x5, x23, #0x5c0
    988c:	f9000002 	str	x2, [x0]
    9890:	aa0003e3 	mov	x3, x0
    9894:	f949d8a1 	ldr	x1, [x5, #5040]
    9898:	f949eca0 	ldr	x0, [x5, #5080]
    989c:	cb010061 	sub	x1, x3, x1
    98a0:	eb00403f 	cmp	x1, x0, lsl #16
    98a4:	54000322 	b.cs	9908 <fwp_hof0.constprop.0+0x12a8>  // b.hs, b.nlast
    98a8:	d350fc24 	lsr	x4, x1, #16
    98ac:	d2800500 	mov	x0, #0x28                  	// #40
    98b0:	f949fca6 	ldr	x6, [x5, #5112]
    98b4:	9b007c84 	mul	x4, x4, x0
    98b8:	8b0400c5 	add	x5, x6, x4
    98bc:	f94010a0 	ldr	x0, [x5, #32]
    98c0:	b4000240 	cbz	x0, 9908 <fwp_hof0.constprop.0+0x12a8>
    98c4:	386468c4 	ldrb	w4, [x6, x4]
    98c8:	7100089f 	cmp	w4, #0x2
    98cc:	540038e0 	b.eq	9fe8 <fwp_hof0.constprop.0+0x1988>  // b.none
    98d0:	7100049f 	cmp	w4, #0x1
    98d4:	540001a1 	b.ne	9908 <fwp_hof0.constprop.0+0x12a8>  // b.any
    98d8:	294310a6 	ldp	w6, w4, [x5, #24]
    98dc:	92403c21 	and	x1, x1, #0xffff
    98e0:	9b067c21 	mul	x1, x1, x6
    98e4:	d360fc21 	lsr	x1, x1, #32
    98e8:	eb04003f 	cmp	x1, x4
    98ec:	540000e2 	b.cs	9908 <fwp_hof0.constprop.0+0x12a8>  // b.hs, b.nlast
    98f0:	8b010000 	add	x0, x0, x1
    98f4:	39400001 	ldrb	w1, [x0]
    98f8:	7103fc3f 	cmp	w1, #0xff
    98fc:	540036a0 	b.eq	9fd0 <fwp_hof0.constprop.0+0x1970>  // b.none
    9900:	52800021 	mov	w1, #0x1                   	// #1
    9904:	39000001 	strb	w1, [x0]
    9908:	aa1b03e0 	mov	x0, x27
    990c:	17ffff36 	b	95e4 <fwp_hof0.constprop.0+0xf84>
    9910:	90000020 	adrp	x0, d000 <__divti3+0x2a0>
    9914:	9129c000 	add	x0, x0, #0xa70
    9918:	97ffe9fa 	bl	4100 <fwp_trap>
    991c:	f9400b65 	ldr	x5, [x27, #16]
    9920:	17ffff3a 	b	9608 <fwp_hof0.constprop.0+0xfa8>
    9924:	aa1303e1 	mov	x1, x19
    9928:	d280001b 	mov	x27, #0x0                   	// #0
    992c:	f9400821 	ldr	x1, [x1, #16]
    9930:	aa1b03e0 	mov	x0, x27
    9934:	9100077b 	add	x27, x27, #0x1
    9938:	b5ffffa1 	cbnz	x1, 992c <fwp_hof0.constprop.0+0x12cc>
    993c:	a9038fe2 	stp	x2, x3, [sp, #56]
    9940:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9944:	eb01037f 	cmp	x27, x1
    9948:	54ff9028 	b.hi	8b4c <fwp_hof0.constprop.0+0x4ec>  // b.pmore
    994c:	91000800 	add	x0, x0, #0x2
    9950:	52800041 	mov	w1, #0x2                   	// #2
    9954:	d37df000 	lsl	x0, x0, #3
    9958:	97ffed62 	bl	4ee0 <fwp_heap_alloc>
    995c:	a9438fe2 	ldp	x2, x3, [sp, #56]
    9960:	aa1303e1 	mov	x1, x19
    9964:	aa0003e5 	mov	x5, x0
    9968:	f9400424 	ldr	x4, [x1, #8]
    996c:	f8008404 	str	x4, [x0], #8
    9970:	f9400821 	ldr	x1, [x1, #16]
    9974:	b5ffffa1 	cbnz	x1, 9968 <fwp_hof0.constprop.0+0x1308>
    9978:	52800008 	mov	w8, #0x0                   	// #0
    997c:	17ffff54 	b	96cc <fwp_hof0.constprop.0+0x106c>
    9980:	b4003ef3 	cbz	x19, a15c <fwp_hof0.constprop.0+0x1afc>
    9984:	911702e0 	add	x0, x23, #0x5c0
    9988:	aa1303ea 	mov	x10, x19
    998c:	d2800006 	mov	x6, #0x0                   	// #0
    9990:	f949ec07 	ldr	x7, [x0, #5080]
    9994:	f949d80b 	ldr	x11, [x0, #5040]
    9998:	f949fc0c 	ldr	x12, [x0, #5112]
    999c:	d370bce7 	lsl	x7, x7, #16
    99a0:	14000006 	b	99b8 <fwp_hof0.constprop.0+0x1358>
    99a4:	f940094a 	ldr	x10, [x10, #16]
    99a8:	910004c6 	add	x6, x6, #0x1
    99ac:	f100015f 	cmp	x10, #0x0
    99b0:	fa461040 	ccmp	x2, x6, #0x0, ne	// ne = any
    99b4:	54000329 	b.ls	9a18 <fwp_hof0.constprop.0+0x13b8>  // b.plast
    99b8:	cb0b0140 	sub	x0, x10, x11
    99bc:	eb07001f 	cmp	x0, x7
    99c0:	540002c2 	b.cs	9a18 <fwp_hof0.constprop.0+0x13b8>  // b.hs, b.nlast
    99c4:	d350fc01 	lsr	x1, x0, #16
    99c8:	8b010821 	add	x1, x1, x1, lsl #2
    99cc:	d37df021 	lsl	x1, x1, #3
    99d0:	8b010189 	add	x9, x12, x1
    99d4:	f9401124 	ldr	x4, [x9, #32]
    99d8:	b4000204 	cbz	x4, 9a18 <fwp_hof0.constprop.0+0x13b8>
    99dc:	38616981 	ldrb	w1, [x12, x1]
    99e0:	7100083f 	cmp	w1, #0x2
    99e4:	54000920 	b.eq	9b08 <fwp_hof0.constprop.0+0x14a8>  // b.none
    99e8:	7100043f 	cmp	w1, #0x1
    99ec:	54000161 	b.ne	9a18 <fwp_hof0.constprop.0+0x13b8>  // b.any
    99f0:	2943052d 	ldp	w13, w1, [x9, #24]
    99f4:	92403c00 	and	x0, x0, #0xffff
    99f8:	9b0d7c00 	mul	x0, x0, x13
    99fc:	d360fc00 	lsr	x0, x0, #32
    9a00:	eb01001f 	cmp	x0, x1
    9a04:	540000a2 	b.cs	9a18 <fwp_hof0.constprop.0+0x13b8>  // b.hs, b.nlast
    9a08:	8b000084 	add	x4, x4, x0
    9a0c:	39400080 	ldrb	w0, [x4]
    9a10:	7100041f 	cmp	w0, #0x1
    9a14:	54fffc80 	b.eq	99a4 <fwp_hof0.constprop.0+0x1344>  // b.none
    9a18:	d2800004 	mov	x4, #0x0                   	// #0
    9a1c:	eb06005f 	cmp	x2, x6
    9a20:	540037a9 	b.ls	a114 <fwp_hof0.constprop.0+0x1ab4>  // b.plast
    9a24:	d10020a0 	sub	x0, x5, #0x8
    9a28:	911702fb 	add	x27, x23, #0x5c0
    9a2c:	a9044fe0 	stp	x0, x19, [sp, #64]
    9a30:	9103e3e0 	add	x0, sp, #0xf8
    9a34:	aa0603f3 	mov	x19, x6
    9a38:	f9001fe0 	str	x0, [sp, #56]
    9a3c:	aa1b03e0 	mov	x0, x27
    9a40:	d2800004 	mov	x4, #0x0                   	// #0
    9a44:	aa1603fb 	mov	x27, x22
    9a48:	aa0003f6 	mov	x22, x0
    9a4c:	f9002be5 	str	x5, [sp, #80]
    9a50:	b90063e8 	str	w8, [sp, #96]
    9a54:	a9068fe2 	stp	x2, x3, [sp, #104]
    9a58:	f9003ff4 	str	x20, [sp, #120]
    9a5c:	aa0203f4 	mov	x20, x2
    9a60:	14000012 	b	9aa8 <fwp_hof0.constprop.0+0x1448>
    9a64:	7100045f 	cmp	w2, #0x1
    9a68:	540001a1 	b.ne	9a9c <fwp_hof0.constprop.0+0x143c>  // b.any
    9a6c:	29430866 	ldp	w6, w2, [x3, #24]
    9a70:	92403c21 	and	x1, x1, #0xffff
    9a74:	9b067c21 	mul	x1, x1, x6
    9a78:	d360fc21 	lsr	x1, x1, #32
    9a7c:	eb02003f 	cmp	x1, x2
    9a80:	540000e2 	b.cs	9a9c <fwp_hof0.constprop.0+0x143c>  // b.hs, b.nlast
    9a84:	8b010000 	add	x0, x0, x1
    9a88:	39400001 	ldrb	w1, [x0]
    9a8c:	7103fc3f 	cmp	w1, #0xff
    9a90:	54003580 	b.eq	a140 <fwp_hof0.constprop.0+0x1ae0>  // b.none
    9a94:	52800021 	mov	w1, #0x1                   	// #1
    9a98:	39000001 	strb	w1, [x0]
    9a9c:	d1000694 	sub	x20, x20, #0x1
    9aa0:	eb13029f 	cmp	x20, x19
    9aa4:	54002b49 	b.ls	a00c <fwp_hof0.constprop.0+0x19ac>  // b.plast
    9aa8:	a94383e1 	ldp	x1, x0, [sp, #56]
    9aac:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    9ab0:	a90f93e0 	stp	x0, x4, [sp, #248]
    9ab4:	52800020 	mov	w0, #0x1                   	// #1
    9ab8:	97ffed4f 	bl	4ff4 <fwp_data.part.0.constprop.0>
    9abc:	aa0003e4 	mov	x4, x0
    9ac0:	f949dac1 	ldr	x1, [x22, #5040]
    9ac4:	f949eec0 	ldr	x0, [x22, #5080]
    9ac8:	cb010081 	sub	x1, x4, x1
    9acc:	eb00403f 	cmp	x1, x0, lsl #16
    9ad0:	54fffe62 	b.cs	9a9c <fwp_hof0.constprop.0+0x143c>  // b.hs, b.nlast
    9ad4:	d350fc20 	lsr	x0, x1, #16
    9ad8:	f949fec6 	ldr	x6, [x22, #5112]
    9adc:	8b000800 	add	x0, x0, x0, lsl #2
    9ae0:	d37df002 	lsl	x2, x0, #3
    9ae4:	8b0200c3 	add	x3, x6, x2
    9ae8:	f9401060 	ldr	x0, [x3, #32]
    9aec:	b4fffd80 	cbz	x0, 9a9c <fwp_hof0.constprop.0+0x143c>
    9af0:	386268c2 	ldrb	w2, [x6, x2]
    9af4:	7100085f 	cmp	w2, #0x2
    9af8:	54fffb61 	b.ne	9a64 <fwp_hof0.constprop.0+0x1404>  // b.any
    9afc:	72003c3f 	tst	w1, #0xffff
    9b00:	54fffce1 	b.ne	9a9c <fwp_hof0.constprop.0+0x143c>  // b.any
    9b04:	17ffffe1 	b	9a88 <fwp_hof0.constprop.0+0x1428>
    9b08:	72003c1f 	tst	w0, #0xffff
    9b0c:	54fff861 	b.ne	9a18 <fwp_hof0.constprop.0+0x13b8>  // b.any
    9b10:	17ffffbf 	b	9a0c <fwp_hof0.constprop.0+0x13ac>
    9b14:	72003c3f 	tst	w1, #0xffff
    9b18:	54ffd141 	b.ne	9540 <fwp_hof0.constprop.0+0xee0>  // b.any
    9b1c:	17fffe84 	b	952c <fwp_hof0.constprop.0+0xecc>
    9b20:	aa0203e0 	mov	x0, x2
    9b24:	d2800101 	mov	x1, #0x8                   	// #8
    9b28:	f9001fe2 	str	x2, [sp, #56]
    9b2c:	97ffe351 	bl	2870 <calloc@plt>
    9b30:	a9439be2 	ldp	x2, x6, [sp, #56]
    9b34:	aa0003e4 	mov	x4, x0
    9b38:	f94027e3 	ldr	x3, [sp, #72]
    9b3c:	17fffe09 	b	9360 <fwp_hof0.constprop.0+0xd00>
    9b40:	90000020 	adrp	x0, d000 <__divti3+0x2a0>
    9b44:	912a0000 	add	x0, x0, #0xa80
    9b48:	97ffe96e 	bl	4100 <fwp_trap>
    9b4c:	f9001fe0 	str	x0, [sp, #56]
    9b50:	97ffe98c 	bl	4180 <fwp_rc_forget_slot.part.0>
    9b54:	9101c2a1 	add	x1, x21, #0x70
    9b58:	f9401fe0 	ldr	x0, [sp, #56]
    9b5c:	f9418023 	ldr	x3, [x1, #768]
    9b60:	17fffe76 	b	9538 <fwp_hof0.constprop.0+0xed8>
    9b64:	f9001fe0 	str	x0, [sp, #56]
    9b68:	97ffe986 	bl	4180 <fwp_rc_forget_slot.part.0>
    9b6c:	f9401fe0 	ldr	x0, [sp, #56]
    9b70:	17ffff38 	b	9850 <fwp_hof0.constprop.0+0x11f0>
    9b74:	f9400062 	ldr	x2, [x3]
    9b78:	b7f800e2 	tbnz	x2, #63, 9b94 <fwp_hof0.constprop.0+0x1534>
    9b7c:	9240f842 	and	x2, x2, #0x7fffffffffffffff
    9b80:	d280001b 	mov	x27, #0x0                   	// #0
    9b84:	17fffeb5 	b	9658 <fwp_hof0.constprop.0+0xff8>
    9b88:	72003c1f 	tst	w0, #0xffff
    9b8c:	54ffd980 	b.eq	96bc <fwp_hof0.constprop.0+0x105c>  // b.none
    9b90:	b5ffecb3 	cbnz	x19, 9924 <fwp_hof0.constprop.0+0x12c4>
    9b94:	52800041 	mov	w1, #0x2                   	// #2
    9b98:	d2800100 	mov	x0, #0x8                   	// #8
    9b9c:	f9001fe3 	str	x3, [sp, #56]
    9ba0:	97ffecd0 	bl	4ee0 <fwp_heap_alloc>
    9ba4:	f9401fe3 	ldr	x3, [sp, #56]
    9ba8:	aa0003e5 	mov	x5, x0
    9bac:	52800008 	mov	w8, #0x0                   	// #0
    9bb0:	aa1303fb 	mov	x27, x19
    9bb4:	d2800013 	mov	x19, #0x0                   	// #0
    9bb8:	7100011f 	cmp	w8, #0x0
    9bbc:	9a8513e9 	csel	x9, xzr, x5, ne	// ne = any
    9bc0:	aa0903e0 	mov	x0, x9
    9bc4:	f90027e3 	str	x3, [sp, #72]
    9bc8:	97ffea0a 	bl	43f0 <fwp_mem_free>
    9bcc:	a903dbf8 	stp	x24, x22, [sp, #56]
    9bd0:	911702e6 	add	x6, x23, #0x5c0
    9bd4:	f94027e3 	ldr	x3, [sp, #72]
    9bd8:	aa1403f8 	mov	x24, x20
    9bdc:	aa1303f6 	mov	x22, x19
    9be0:	aa0603f4 	mov	x20, x6
    9be4:	aa0303f3 	mov	x19, x3
    9be8:	d2800507 	mov	x7, #0x28                  	// #40
    9bec:	f949da81 	ldr	x1, [x20, #5040]
    9bf0:	f949ee80 	ldr	x0, [x20, #5080]
    9bf4:	cb010261 	sub	x1, x19, x1
    9bf8:	eb00403f 	cmp	x1, x0, lsl #16
    9bfc:	540012a2 	b.cs	9e50 <fwp_hof0.constprop.0+0x17f0>  // b.hs, b.nlast
    9c00:	d350fc22 	lsr	x2, x1, #16
    9c04:	f949fe85 	ldr	x5, [x20, #5112]
    9c08:	9b077c42 	mul	x2, x2, x7
    9c0c:	8b0200a4 	add	x4, x5, x2
    9c10:	f9401080 	ldr	x0, [x4, #32]
    9c14:	b40011e0 	cbz	x0, 9e50 <fwp_hof0.constprop.0+0x17f0>
    9c18:	386268a5 	ldrb	w5, [x5, x2]
    9c1c:	710008bf 	cmp	w5, #0x2
    9c20:	54001140 	b.eq	9e48 <fwp_hof0.constprop.0+0x17e8>  // b.none
    9c24:	710004bf 	cmp	w5, #0x1
    9c28:	54001141 	b.ne	9e50 <fwp_hof0.constprop.0+0x17f0>  // b.any
    9c2c:	29432082 	ldp	w2, w8, [x4, #24]
    9c30:	92403c21 	and	x1, x1, #0xffff
    9c34:	9b027c22 	mul	x2, x1, x2
    9c38:	d360fc42 	lsr	x2, x2, #32
    9c3c:	eb08005f 	cmp	x2, x8
    9c40:	54001082 	b.cs	9e50 <fwp_hof0.constprop.0+0x17f0>  // b.hs, b.nlast
    9c44:	8b020000 	add	x0, x0, x2
    9c48:	39400002 	ldrb	w2, [x0]
    9c4c:	34001022 	cbz	w2, 9e50 <fwp_hof0.constprop.0+0x17f0>
    9c50:	7100045f 	cmp	w2, #0x1
    9c54:	54000da0 	b.eq	9e08 <fwp_hof0.constprop.0+0x17a8>  // b.none
    9c58:	aa1603f3 	mov	x19, x22
    9c5c:	aa1803f4 	mov	x20, x24
    9c60:	a943dbf8 	ldp	x24, x22, [sp, #56]
    9c64:	7103fc5f 	cmp	w2, #0xff
    9c68:	54000fc0 	b.eq	9e60 <fwp_hof0.constprop.0+0x1800>  // b.none
    9c6c:	51000442 	sub	w2, w2, #0x1
    9c70:	39000002 	strb	w2, [x0]
    9c74:	911702e5 	add	x5, x23, #0x5c0
    9c78:	f9001ff6 	str	x22, [sp, #56]
    9c7c:	aa1403f6 	mov	x22, x20
    9c80:	aa1303f4 	mov	x20, x19
    9c84:	aa0503f3 	mov	x19, x5
    9c88:	d2800506 	mov	x6, #0x28                  	// #40
    9c8c:	f949da61 	ldr	x1, [x19, #5040]
    9c90:	f949ee60 	ldr	x0, [x19, #5080]
    9c94:	cb010361 	sub	x1, x27, x1
    9c98:	eb00403f 	cmp	x1, x0, lsl #16
    9c9c:	54000ae2 	b.cs	9df8 <fwp_hof0.constprop.0+0x1798>  // b.hs, b.nlast
    9ca0:	d350fc22 	lsr	x2, x1, #16
    9ca4:	f949fe64 	ldr	x4, [x19, #5112]
    9ca8:	9b067c42 	mul	x2, x2, x6
    9cac:	8b020083 	add	x3, x4, x2
    9cb0:	f9401060 	ldr	x0, [x3, #32]
    9cb4:	b4000a20 	cbz	x0, 9df8 <fwp_hof0.constprop.0+0x1798>
    9cb8:	38626884 	ldrb	w4, [x4, x2]
    9cbc:	7100089f 	cmp	w4, #0x2
    9cc0:	54000980 	b.eq	9df0 <fwp_hof0.constprop.0+0x1790>  // b.none
    9cc4:	7100049f 	cmp	w4, #0x1
    9cc8:	54000981 	b.ne	9df8 <fwp_hof0.constprop.0+0x1798>  // b.any
    9ccc:	29431c62 	ldp	w2, w7, [x3, #24]
    9cd0:	92403c21 	and	x1, x1, #0xffff
    9cd4:	9b027c22 	mul	x2, x1, x2
    9cd8:	d360fc42 	lsr	x2, x2, #32
    9cdc:	eb07005f 	cmp	x2, x7
    9ce0:	540008c2 	b.cs	9df8 <fwp_hof0.constprop.0+0x1798>  // b.hs, b.nlast
    9ce4:	8b020000 	add	x0, x0, x2
    9ce8:	39400002 	ldrb	w2, [x0]
    9cec:	34000862 	cbz	w2, 9df8 <fwp_hof0.constprop.0+0x1798>
    9cf0:	7100045f 	cmp	w2, #0x1
    9cf4:	540012e0 	b.eq	9f50 <fwp_hof0.constprop.0+0x18f0>  // b.none
    9cf8:	aa1403f3 	mov	x19, x20
    9cfc:	aa1603f4 	mov	x20, x22
    9d00:	f9401ff6 	ldr	x22, [sp, #56]
    9d04:	7103fc5f 	cmp	w2, #0xff
    9d08:	54001060 	b.eq	9f14 <fwp_hof0.constprop.0+0x18b4>  // b.none
    9d0c:	51000442 	sub	w2, w2, #0x1
    9d10:	39000002 	strb	w2, [x0]
    9d14:	f9400fe0 	ldr	x0, [sp, #24]
    9d18:	b4ff7400 	cbz	x0, 8b98 <fwp_hof0.constprop.0+0x538>
    9d1c:	f9400fe0 	ldr	x0, [sp, #24]
    9d20:	f1000400 	subs	x0, x0, #0x1
    9d24:	f9000fe0 	str	x0, [sp, #24]
    9d28:	54002366 	b.vs	a194 <fwp_hof0.constprop.0+0x1b34>
    9d2c:	911702e0 	add	x0, x23, #0x5c0
    9d30:	f949ec05 	ldr	x5, [x0, #5080]
    9d34:	f949d801 	ldr	x1, [x0, #5040]
    9d38:	d370bca5 	lsl	x5, x5, #16
    9d3c:	17fffa91 	b	8780 <fwp_hof0.constprop.0+0x120>
    9d40:	90000020 	adrp	x0, d000 <__divti3+0x2a0>
    9d44:	912aa000 	add	x0, x0, #0xaa8
    9d48:	97ffe8ee 	bl	4100 <fwp_trap>
    9d4c:	aa1603e0 	mov	x0, x22
    9d50:	97ffef9c 	bl	5bc0 <fwp_rc_free_arr>
    9d54:	17fffbfb 	b	8d40 <fwp_hof0.constprop.0+0x6e0>
    9d58:	72003c3f 	tst	w1, #0xffff
    9d5c:	54ff7f21 	b.ne	8d40 <fwp_hof0.constprop.0+0x6e0>  // b.any
    9d60:	17fffbf0 	b	8d20 <fwp_hof0.constprop.0+0x6c0>
    9d64:	72003c3f 	tst	w1, #0xffff
    9d68:	54ff7941 	b.ne	8c90 <fwp_hof0.constprop.0+0x630>  // b.any
    9d6c:	17fffbc4 	b	8c7c <fwp_hof0.constprop.0+0x61c>
    9d70:	f9000fe0 	str	x0, [sp, #24]
    9d74:	97ffe903 	bl	4180 <fwp_rc_forget_slot.part.0>
    9d78:	f9400fe0 	ldr	x0, [sp, #24]
    9d7c:	17fffbc3 	b	8c88 <fwp_hof0.constprop.0+0x628>
    9d80:	ca534661 	eor	x1, x19, x19, lsr #17
    9d84:	911702e2 	add	x2, x23, #0x5c0
    9d88:	ca412421 	eor	x1, x1, x1, lsr #9
    9d8c:	92401c21 	and	x1, x1, #0xff
    9d90:	910a2420 	add	x0, x1, #0x289
    9d94:	8b010c41 	add	x1, x2, x1, lsl #3
    9d98:	8b000c40 	add	x0, x2, x0, lsl #3
    9d9c:	f94a2421 	ldr	x1, [x1, #5192]
    9da0:	b50000a1 	cbnz	x1, 9db4 <fwp_hof0.constprop.0+0x1754>
    9da4:	17fffe6a 	b	974c <fwp_hof0.constprop.0+0x10ec>
    9da8:	91004020 	add	x0, x1, #0x10
    9dac:	f9400821 	ldr	x1, [x1, #16]
    9db0:	b4ffcce1 	cbz	x1, 974c <fwp_hof0.constprop.0+0x10ec>
    9db4:	f9400022 	ldr	x2, [x1]
    9db8:	eb02027f 	cmp	x19, x2
    9dbc:	54ffff61 	b.ne	9da8 <fwp_hof0.constprop.0+0x1748>  // b.any
    9dc0:	f9400001 	ldr	x1, [x0]
    9dc4:	f9400420 	ldr	x0, [x1, #8]
    9dc8:	d1000400 	sub	x0, x0, #0x1
    9dcc:	f9000420 	str	x0, [x1, #8]
    9dd0:	f103f81f 	cmp	x0, #0xfe
    9dd4:	54ff7b61 	b.ne	8d40 <fwp_hof0.constprop.0+0x6e0>  // b.any
    9dd8:	39400260 	ldrb	w0, [x19]
    9ddc:	7103fc1f 	cmp	w0, #0xff
    9de0:	54000ea0 	b.eq	9fb4 <fwp_hof0.constprop.0+0x1954>  // b.none
    9de4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9de8:	39000260 	strb	w0, [x19]
    9dec:	17fffbd5 	b	8d40 <fwp_hof0.constprop.0+0x6e0>
    9df0:	f2403c21 	ands	x1, x1, #0xffff
    9df4:	54fff7a0 	b.eq	9ce8 <fwp_hof0.constprop.0+0x1688>  // b.none
    9df8:	aa1403f3 	mov	x19, x20
    9dfc:	aa1603f4 	mov	x20, x22
    9e00:	f9401ff6 	ldr	x22, [sp, #56]
    9e04:	17ffffc4 	b	9d14 <fwp_hof0.constprop.0+0x16b4>
    9e08:	f9400262 	ldr	x2, [x19]
    9e0c:	aa1303e0 	mov	x0, x19
    9e10:	b7f804a2 	tbnz	x2, #63, 9ea4 <fwp_hof0.constprop.0+0x1844>
    9e14:	aa1303e3 	mov	x3, x19
    9e18:	aa1803f4 	mov	x20, x24
    9e1c:	aa1603f3 	mov	x19, x22
    9e20:	a943dbf8 	ldp	x24, x22, [sp, #56]
    9e24:	710008bf 	cmp	w5, #0x2
    9e28:	540003a0 	b.eq	9e9c <fwp_hof0.constprop.0+0x183c>  // b.none
    9e2c:	29430082 	ldp	w2, w0, [x4, #24]
    9e30:	9b027c21 	mul	x1, x1, x2
    9e34:	eb41801f 	cmp	x0, x1, lsr #32
    9e38:	54fff1e9 	b.ls	9c74 <fwp_hof0.constprop.0+0x1614>  // b.plast
    9e3c:	aa0303e0 	mov	x0, x3
    9e40:	97ffe96c 	bl	43f0 <fwp_mem_free>
    9e44:	17ffff8c 	b	9c74 <fwp_hof0.constprop.0+0x1614>
    9e48:	f2403c21 	ands	x1, x1, #0xffff
    9e4c:	54ffefe0 	b.eq	9c48 <fwp_hof0.constprop.0+0x15e8>  // b.none
    9e50:	aa1603f3 	mov	x19, x22
    9e54:	aa1803f4 	mov	x20, x24
    9e58:	a943dbf8 	ldp	x24, x22, [sp, #56]
    9e5c:	17ffff86 	b	9c74 <fwp_hof0.constprop.0+0x1614>
    9e60:	ca404401 	eor	x1, x0, x0, lsr #17
    9e64:	911702e3 	add	x3, x23, #0x5c0
    9e68:	ca412421 	eor	x1, x1, x1, lsr #9
    9e6c:	92401c21 	and	x1, x1, #0xff
    9e70:	910a2422 	add	x2, x1, #0x289
    9e74:	8b010c61 	add	x1, x3, x1, lsl #3
    9e78:	8b020c62 	add	x2, x3, x2, lsl #3
    9e7c:	f94a2421 	ldr	x1, [x1, #5192]
    9e80:	b4ffc661 	cbz	x1, 974c <fwp_hof0.constprop.0+0x10ec>
    9e84:	f9400023 	ldr	x3, [x1]
    9e88:	eb00007f 	cmp	x3, x0
    9e8c:	54000200 	b.eq	9ecc <fwp_hof0.constprop.0+0x186c>  // b.none
    9e90:	91004022 	add	x2, x1, #0x10
    9e94:	f9400821 	ldr	x1, [x1, #16]
    9e98:	17fffffa 	b	9e80 <fwp_hof0.constprop.0+0x1820>
    9e9c:	b5ffeec1 	cbnz	x1, 9c74 <fwp_hof0.constprop.0+0x1614>
    9ea0:	17ffffe7 	b	9e3c <fwp_hof0.constprop.0+0x17dc>
    9ea4:	f9400673 	ldr	x19, [x19, #8]
    9ea8:	710008bf 	cmp	w5, #0x2
    9eac:	54000280 	b.eq	9efc <fwp_hof0.constprop.0+0x189c>  // b.none
    9eb0:	29430885 	ldp	w5, w2, [x4, #24]
    9eb4:	9b057c21 	mul	x1, x1, x5
    9eb8:	eb41805f 	cmp	x2, x1, lsr #32
    9ebc:	54ffe989 	b.ls	9bec <fwp_hof0.constprop.0+0x158c>  // b.plast
    9ec0:	97ffe94c 	bl	43f0 <fwp_mem_free>
    9ec4:	d2800507 	mov	x7, #0x28                  	// #40
    9ec8:	17ffff49 	b	9bec <fwp_hof0.constprop.0+0x158c>
    9ecc:	f9400042 	ldr	x2, [x2]
    9ed0:	f9400441 	ldr	x1, [x2, #8]
    9ed4:	d1000421 	sub	x1, x1, #0x1
    9ed8:	f9000441 	str	x1, [x2, #8]
    9edc:	f103f83f 	cmp	x1, #0xfe
    9ee0:	54ffeca1 	b.ne	9c74 <fwp_hof0.constprop.0+0x1614>  // b.any
    9ee4:	39400001 	ldrb	w1, [x0]
    9ee8:	7103fc3f 	cmp	w1, #0xff
    9eec:	540000c0 	b.eq	9f04 <fwp_hof0.constprop.0+0x18a4>  // b.none
    9ef0:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9ef4:	39000001 	strb	w1, [x0]
    9ef8:	17ffff5f 	b	9c74 <fwp_hof0.constprop.0+0x1614>
    9efc:	b5ffe781 	cbnz	x1, 9bec <fwp_hof0.constprop.0+0x158c>
    9f00:	17fffff0 	b	9ec0 <fwp_hof0.constprop.0+0x1860>
    9f04:	f9001fe0 	str	x0, [sp, #56]
    9f08:	97ffe89e 	bl	4180 <fwp_rc_forget_slot.part.0>
    9f0c:	f9401fe0 	ldr	x0, [sp, #56]
    9f10:	17fffff8 	b	9ef0 <fwp_hof0.constprop.0+0x1890>
    9f14:	ca404401 	eor	x1, x0, x0, lsr #17
    9f18:	911702e3 	add	x3, x23, #0x5c0
    9f1c:	ca412421 	eor	x1, x1, x1, lsr #9
    9f20:	92401c21 	and	x1, x1, #0xff
    9f24:	910a2422 	add	x2, x1, #0x289
    9f28:	8b010c61 	add	x1, x3, x1, lsl #3
    9f2c:	8b020c62 	add	x2, x3, x2, lsl #3
    9f30:	f94a2421 	ldr	x1, [x1, #5192]
    9f34:	b4ffc0c1 	cbz	x1, 974c <fwp_hof0.constprop.0+0x10ec>
    9f38:	f9400023 	ldr	x3, [x1]
    9f3c:	eb03001f 	cmp	x0, x3
    9f40:	54000220 	b.eq	9f84 <fwp_hof0.constprop.0+0x1924>  // b.none
    9f44:	91004022 	add	x2, x1, #0x10
    9f48:	f9400821 	ldr	x1, [x1, #16]
    9f4c:	17fffffa 	b	9f34 <fwp_hof0.constprop.0+0x18d4>
    9f50:	aa1b03e0 	mov	x0, x27
    9f54:	f9400b7b 	ldr	x27, [x27, #16]
    9f58:	7100089f 	cmp	w4, #0x2
    9f5c:	54000100 	b.eq	9f7c <fwp_hof0.constprop.0+0x191c>  // b.none
    9f60:	29430864 	ldp	w4, w2, [x3, #24]
    9f64:	9b047c21 	mul	x1, x1, x4
    9f68:	eb41805f 	cmp	x2, x1, lsr #32
    9f6c:	54ffe909 	b.ls	9c8c <fwp_hof0.constprop.0+0x162c>  // b.plast
    9f70:	97ffe920 	bl	43f0 <fwp_mem_free>
    9f74:	d2800506 	mov	x6, #0x28                  	// #40
    9f78:	17ffff45 	b	9c8c <fwp_hof0.constprop.0+0x162c>
    9f7c:	b5ffe881 	cbnz	x1, 9c8c <fwp_hof0.constprop.0+0x162c>
    9f80:	17fffffc 	b	9f70 <fwp_hof0.constprop.0+0x1910>
    9f84:	f9400042 	ldr	x2, [x2]
    9f88:	f9400441 	ldr	x1, [x2, #8]
    9f8c:	d1000421 	sub	x1, x1, #0x1
    9f90:	f9000441 	str	x1, [x2, #8]
    9f94:	f103f83f 	cmp	x1, #0xfe
    9f98:	54ffebe1 	b.ne	9d14 <fwp_hof0.constprop.0+0x16b4>  // b.any
    9f9c:	39400001 	ldrb	w1, [x0]
    9fa0:	7103fc3f 	cmp	w1, #0xff
    9fa4:	540000e0 	b.eq	9fc0 <fwp_hof0.constprop.0+0x1960>  // b.none
    9fa8:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9fac:	39000001 	strb	w1, [x0]
    9fb0:	17ffff59 	b	9d14 <fwp_hof0.constprop.0+0x16b4>
    9fb4:	aa1303e0 	mov	x0, x19
    9fb8:	97ffe872 	bl	4180 <fwp_rc_forget_slot.part.0>
    9fbc:	17ffff8a 	b	9de4 <fwp_hof0.constprop.0+0x1784>
    9fc0:	f9001fe0 	str	x0, [sp, #56]
    9fc4:	97ffe86f 	bl	4180 <fwp_rc_forget_slot.part.0>
    9fc8:	f9401fe0 	ldr	x0, [sp, #56]
    9fcc:	17fffff7 	b	9fa8 <fwp_hof0.constprop.0+0x1948>
    9fd0:	a9038be0 	stp	x0, x2, [sp, #56]
    9fd4:	f90027e3 	str	x3, [sp, #72]
    9fd8:	97ffe86a 	bl	4180 <fwp_rc_forget_slot.part.0>
    9fdc:	a9438be0 	ldp	x0, x2, [sp, #56]
    9fe0:	f94027e3 	ldr	x3, [sp, #72]
    9fe4:	17fffe47 	b	9900 <fwp_hof0.constprop.0+0x12a0>
    9fe8:	72003c3f 	tst	w1, #0xffff
    9fec:	54ffc840 	b.eq	98f4 <fwp_hof0.constprop.0+0x1294>  // b.none
    9ff0:	aa1b03e0 	mov	x0, x27
    9ff4:	17fffd7c 	b	95e4 <fwp_hof0.constprop.0+0xf84>
    9ff8:	a91253f3 	stp	x19, x20, [sp, #288]
    9ffc:	a9135bf5 	stp	x21, x22, [sp, #304]
    a000:	a91463f7 	stp	x23, x24, [sp, #320]
    a004:	a9156bf9 	stp	x25, x26, [sp, #336]
    a008:	97ffe222 	bl	2890 <__stack_chk_fail@plt>
    a00c:	a9468fe2 	ldp	x2, x3, [sp, #104]
    a010:	aa1303e6 	mov	x6, x19
    a014:	a94497f3 	ldp	x19, x5, [sp, #72]
    a018:	aa1b03f6 	mov	x22, x27
    a01c:	f9403ff4 	ldr	x20, [sp, #120]
    a020:	d1000441 	sub	x1, x2, #0x1
    a024:	cb0200c0 	sub	x0, x6, x2
    a028:	eb06003f 	cmp	x1, x6
    a02c:	b94063e8 	ldr	w8, [sp, #96]
    a030:	9a8037e0 	csinc	x0, xzr, x0, cc	// cc = lo, ul, last
    a034:	8b010000 	add	x0, x0, x1
    a038:	b50006e6 	cbnz	x6, a114 <fwp_hof0.constprop.0+0x1ab4>
    a03c:	7100011f 	cmp	w8, #0x0
    a040:	9a8513e9 	csel	x9, xzr, x5, ne	// ne = any
    a044:	b4000860 	cbz	x0, a150 <fwp_hof0.constprop.0+0x1af0>
    a048:	911702fb 	add	x27, x23, #0x5c0
    a04c:	d1000407 	sub	x7, x0, #0x1
    a050:	aa1b03e0 	mov	x0, x27
    a054:	aa1603fb 	mov	x27, x22
    a058:	aa0003f6 	mov	x22, x0
    a05c:	a9040ff3 	stp	x19, x3, [sp, #64]
    a060:	aa0903f3 	mov	x19, x9
    a064:	f9002bf4 	str	x20, [sp, #80]
    a068:	aa0703f4 	mov	x20, x7
    a06c:	14000012 	b	a0b4 <fwp_hof0.constprop.0+0x1a54>
    a070:	7100045f 	cmp	w2, #0x1
    a074:	540001a1 	b.ne	a0a8 <fwp_hof0.constprop.0+0x1a48>  // b.any
    a078:	29430866 	ldp	w6, w2, [x3, #24]
    a07c:	92403c21 	and	x1, x1, #0xffff
    a080:	9b067c21 	mul	x1, x1, x6
    a084:	d360fc21 	lsr	x1, x1, #32
    a088:	eb02003f 	cmp	x1, x2
    a08c:	540000e2 	b.cs	a0a8 <fwp_hof0.constprop.0+0x1a48>  // b.hs, b.nlast
    a090:	8b010000 	add	x0, x0, x1
    a094:	39400001 	ldrb	w1, [x0]
    a098:	7103fc3f 	cmp	w1, #0xff
    a09c:	54000640 	b.eq	a164 <fwp_hof0.constprop.0+0x1b04>  // b.none
    a0a0:	52800021 	mov	w1, #0x1                   	// #1
    a0a4:	39000001 	strb	w1, [x0]
    a0a8:	d1000694 	sub	x20, x20, #0x1
    a0ac:	b100069f 	cmn	x20, #0x1
    a0b0:	54000620 	b.eq	a174 <fwp_hof0.constprop.0+0x1b14>  // b.none
    a0b4:	f9401fe1 	ldr	x1, [sp, #56]
    a0b8:	f8747a60 	ldr	x0, [x19, x20, lsl #3]
    a0bc:	a90f93e0 	stp	x0, x4, [sp, #248]
    a0c0:	52800020 	mov	w0, #0x1                   	// #1
    a0c4:	97ffebcc 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a0c8:	aa0003e4 	mov	x4, x0
    a0cc:	f949dac1 	ldr	x1, [x22, #5040]
    a0d0:	f949eec0 	ldr	x0, [x22, #5080]
    a0d4:	cb010081 	sub	x1, x4, x1
    a0d8:	eb00403f 	cmp	x1, x0, lsl #16
    a0dc:	54fffe62 	b.cs	a0a8 <fwp_hof0.constprop.0+0x1a48>  // b.hs, b.nlast
    a0e0:	d350fc20 	lsr	x0, x1, #16
    a0e4:	f949fec6 	ldr	x6, [x22, #5112]
    a0e8:	8b000800 	add	x0, x0, x0, lsl #2
    a0ec:	d37df002 	lsl	x2, x0, #3
    a0f0:	8b0200c3 	add	x3, x6, x2
    a0f4:	f9401060 	ldr	x0, [x3, #32]
    a0f8:	b4fffd80 	cbz	x0, a0a8 <fwp_hof0.constprop.0+0x1a48>
    a0fc:	386268c2 	ldrb	w2, [x6, x2]
    a100:	7100085f 	cmp	w2, #0x2
    a104:	54fffb61 	b.ne	a070 <fwp_hof0.constprop.0+0x1a10>  // b.any
    a108:	72003c3f 	tst	w1, #0xffff
    a10c:	54fffce1 	b.ne	a0a8 <fwp_hof0.constprop.0+0x1a48>  // b.any
    a110:	17ffffe1 	b	a094 <fwp_hof0.constprop.0+0x1a34>
    a114:	aa1303fb 	mov	x27, x19
    a118:	d2800000 	mov	x0, #0x0                   	// #0
    a11c:	f86078a1 	ldr	x1, [x5, x0, lsl #3]
    a120:	91000400 	add	x0, x0, #0x1
    a124:	f9000761 	str	x1, [x27, #8]
    a128:	aa1b03e1 	mov	x1, x27
    a12c:	f9400b7b 	ldr	x27, [x27, #16]
    a130:	eb06001f 	cmp	x0, x6
    a134:	54ffff43 	b.cc	a11c <fwp_hof0.constprop.0+0x1abc>  // b.lo, b.ul, b.last
    a138:	f9000824 	str	x4, [x1, #16]
    a13c:	17fffe9f 	b	9bb8 <fwp_hof0.constprop.0+0x1558>
    a140:	a90813e0 	stp	x0, x4, [sp, #128]
    a144:	97ffe80f 	bl	4180 <fwp_rc_forget_slot.part.0>
    a148:	a94813e0 	ldp	x0, x4, [sp, #128]
    a14c:	17fffe52 	b	9a94 <fwp_hof0.constprop.0+0x1434>
    a150:	aa1303fb 	mov	x27, x19
    a154:	aa0403f3 	mov	x19, x4
    a158:	17fffe9a 	b	9bc0 <fwp_hof0.constprop.0+0x1560>
    a15c:	d2800006 	mov	x6, #0x0                   	// #0
    a160:	17fffe31 	b	9a24 <fwp_hof0.constprop.0+0x13c4>
    a164:	a90613e0 	stp	x0, x4, [sp, #96]
    a168:	97ffe806 	bl	4180 <fwp_rc_forget_slot.part.0>
    a16c:	a94613e0 	ldp	x0, x4, [sp, #96]
    a170:	17ffffcc 	b	a0a0 <fwp_hof0.constprop.0+0x1a40>
    a174:	aa1303e9 	mov	x9, x19
    a178:	aa1b03f6 	mov	x22, x27
    a17c:	a9440ff3 	ldp	x19, x3, [sp, #64]
    a180:	f9402bf4 	ldr	x20, [sp, #80]
    a184:	aa1303fb 	mov	x27, x19
    a188:	aa0403f3 	mov	x19, x4
    a18c:	17fffe8d 	b	9bc0 <fwp_hof0.constprop.0+0x1560>
    a190:	97ffe1d4 	bl	28e0 <abort@plt>
    a194:	97ffe23b 	bl	2a80 <fwp_trap_overflow.constprop.0>
    a198:	d503201f 	nop
    a19c:	d503201f 	nop

000000000000a1a0 <f0>:
    a1a0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a1a4:	910003fd 	mov	x29, sp
    a1a8:	a90153f3 	stp	x19, x20, [sp, #16]
    a1ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    a1b0:	a90363f7 	stp	x23, x24, [sp, #48]
    a1b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    a1b8:	a90573fb 	stp	x27, x28, [sp, #80]
    a1bc:	d121c3ff 	sub	sp, sp, #0x870
    a1c0:	f90203ff 	str	xzr, [sp, #1024]
    a1c4:	d00000a0 	adrp	x0, 20000 <__data_start>
    a1c8:	9101c003 	add	x3, x0, #0x70
    a1cc:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    a1d0:	f947f400 	ldr	x0, [x0, #4072]
    a1d4:	f0000134 	adrp	x20, 31000 <fwp_root_context+0xc20>
    a1d8:	f9418065 	ldr	x5, [x3, #768]
    a1dc:	f9400001 	ldr	x1, [x0]
    a1e0:	f90437e1 	str	x1, [sp, #2152]
    a1e4:	d2800001 	mov	x1, #0x0                   	// #0
    a1e8:	91170299 	add	x25, x20, #0x5c0
    a1ec:	912163f6 	add	x22, sp, #0x858
    a1f0:	910063e4 	add	x4, sp, #0x18
    a1f4:	9100c3e1 	add	x1, sp, #0x30
    a1f8:	f0ffffc0 	adrp	x0, 5000 <fwp_data.part.0.constprop.0+0xc>
    a1fc:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    a200:	913c4000 	add	x0, x0, #0xf10
    a204:	913d4042 	add	x2, x2, #0xf50
    a208:	d2800013 	mov	x19, #0x0                   	// #0
    a20c:	d280011a 	mov	x26, #0x8                   	// #8
    a210:	d2800015 	mov	x21, #0x0                   	// #0
    a214:	52800037 	mov	w23, #0x1                   	// #1
    a218:	f90007e4 	str	x4, [sp, #8]
    a21c:	a9018be5 	stp	x5, x2, [sp, #24]
    a220:	a902ffe1 	stp	x1, xzr, [sp, #40]
    a224:	a90403ff 	stp	xzr, x0, [sp, #64]
    a228:	f9018064 	str	x4, [x3, #768]
    a22c:	d503201f 	nop
    a230:	f100075b 	subs	x27, x26, #0x1
    a234:	aa1603e1 	mov	x1, x22
    a238:	da1f02b8 	sbc	x24, x21, xzr
    a23c:	52800020 	mov	w0, #0x1                   	// #1
    a240:	f9001ffb 	str	x27, [sp, #56]
    a244:	aa1b03fa 	mov	x26, x27
    a248:	f9042ffb 	str	x27, [sp, #2136]
    a24c:	aa1803f5 	mov	x21, x24
    a250:	f90433f3 	str	x19, [sp, #2144]
    a254:	97ffeb68 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a258:	f949db22 	ldr	x2, [x25, #5040]
    a25c:	aa0003f3 	mov	x19, x0
    a260:	f949ef20 	ldr	x0, [x25, #5080]
    a264:	cb020262 	sub	x2, x19, x2
    a268:	eb00405f 	cmp	x2, x0, lsl #16
    a26c:	54000302 	b.cs	a2cc <f0+0x12c>  // b.hs, b.nlast
    a270:	d350fc40 	lsr	x0, x2, #16
    a274:	f949ff25 	ldr	x5, [x25, #5112]
    a278:	8b000800 	add	x0, x0, x0, lsl #2
    a27c:	d37df001 	lsl	x1, x0, #3
    a280:	8b0100a0 	add	x0, x5, x1
    a284:	f940101c 	ldr	x28, [x0, #32]
    a288:	b400023c 	cbz	x28, a2cc <f0+0x12c>
    a28c:	386168a1 	ldrb	w1, [x5, x1]
    a290:	7100083f 	cmp	w1, #0x2
    a294:	54010e40 	b.eq	c45c <f0+0x22bc>  // b.none
    a298:	7100043f 	cmp	w1, #0x1
    a29c:	54000181 	b.ne	a2cc <f0+0x12c>  // b.any
    a2a0:	29430001 	ldp	w1, w0, [x0, #24]
    a2a4:	92403c42 	and	x2, x2, #0xffff
    a2a8:	9b017c42 	mul	x2, x2, x1
    a2ac:	d360fc42 	lsr	x2, x2, #32
    a2b0:	eb00005f 	cmp	x2, x0
    a2b4:	540000c2 	b.cs	a2cc <f0+0x12c>  // b.hs, b.nlast
    a2b8:	8b02039c 	add	x28, x28, x2
    a2bc:	39400380 	ldrb	w0, [x28]
    a2c0:	7103fc1f 	cmp	w0, #0xff
    a2c4:	54010c60 	b.eq	c450 <f0+0x22b0>  // b.none
    a2c8:	39000397 	strb	w23, [x28]
    a2cc:	a9037ff3 	stp	x19, xzr, [sp, #48]
    a2d0:	aa18037b 	orr	x27, x27, x24
    a2d4:	b5fffafb 	cbnz	x27, a230 <f0+0x90>
    a2d8:	d00000a0 	adrp	x0, 20000 <__data_start>
    a2dc:	9101c018 	add	x24, x0, #0x70
    a2e0:	f94007e1 	ldr	x1, [sp, #8]
    a2e4:	f9001bff 	str	xzr, [sp, #48]
    a2e8:	f9418300 	ldr	x0, [x24, #768]
    a2ec:	eb01001f 	cmp	x0, x1
    a2f0:	54012921 	b.ne	c814 <f0+0x2674>  // b.any
    a2f4:	90000020 	adrp	x0, e000 <_IO_stdin_used+0xb80>
    a2f8:	910143e1 	add	x1, sp, #0x50
    a2fc:	f9400fe2 	ldr	x2, [sp, #24]
    a300:	f9018302 	str	x2, [x24, #768]
    a304:	3dc0ac00 	ldr	q0, [x0, #688]
    a308:	52800020 	mov	w0, #0x1                   	// #1
    a30c:	3d8017e0 	str	q0, [sp, #80]
    a310:	97ffeb39 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a314:	91170283 	add	x3, x20, #0x5c0
    a318:	aa0003f7 	mov	x23, x0
    a31c:	f949d861 	ldr	x1, [x3, #5040]
    a320:	f949ec60 	ldr	x0, [x3, #5080]
    a324:	cb0102e1 	sub	x1, x23, x1
    a328:	eb00403f 	cmp	x1, x0, lsl #16
    a32c:	54000322 	b.cs	a390 <f0+0x1f0>  // b.hs, b.nlast
    a330:	d350fc22 	lsr	x2, x1, #16
    a334:	f949fc63 	ldr	x3, [x3, #5112]
    a338:	8b020842 	add	x2, x2, x2, lsl #2
    a33c:	d37df042 	lsl	x2, x2, #3
    a340:	8b020060 	add	x0, x3, x2
    a344:	f9401015 	ldr	x21, [x0, #32]
    a348:	b4000255 	cbz	x21, a390 <f0+0x1f0>
    a34c:	38626862 	ldrb	w2, [x3, x2]
    a350:	7100085f 	cmp	w2, #0x2
    a354:	540108a0 	b.eq	c468 <f0+0x22c8>  // b.none
    a358:	7100045f 	cmp	w2, #0x1
    a35c:	540001a1 	b.ne	a390 <f0+0x1f0>  // b.any
    a360:	29430002 	ldp	w2, w0, [x0, #24]
    a364:	92403c21 	and	x1, x1, #0xffff
    a368:	9b027c21 	mul	x1, x1, x2
    a36c:	d360fc21 	lsr	x1, x1, #32
    a370:	eb00003f 	cmp	x1, x0
    a374:	540000e2 	b.cs	a390 <f0+0x1f0>  // b.hs, b.nlast
    a378:	8b0102b5 	add	x21, x21, x1
    a37c:	394002a0 	ldrb	w0, [x21]
    a380:	7103fc1f 	cmp	w0, #0xff
    a384:	54011620 	b.eq	c648 <f0+0x24a8>  // b.none
    a388:	52800020 	mov	w0, #0x1                   	// #1
    a38c:	390002a0 	strb	w0, [x21]
    a390:	9101a3e1 	add	x1, sp, #0x68
    a394:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a398:	52800020 	mov	w0, #0x1                   	// #1
    a39c:	a906dff5 	stp	x21, x23, [sp, #104]
    a3a0:	97ffeb15 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a3a4:	97ffedd7 	bl	5b00 <fwp_rc_fresh>
    a3a8:	aa0003e2 	mov	x2, x0
    a3ac:	9101e3e1 	add	x1, sp, #0x78
    a3b0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a3b4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a3b8:	52800020 	mov	w0, #0x1                   	// #1
    a3bc:	a9078bf7 	stp	x23, x2, [sp, #120]
    a3c0:	97ffeb0d 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a3c4:	97ffedcf 	bl	5b00 <fwp_rc_fresh>
    a3c8:	aa0003e2 	mov	x2, x0
    a3cc:	910223e1 	add	x1, sp, #0x88
    a3d0:	52800020 	mov	w0, #0x1                   	// #1
    a3d4:	a9088bf5 	stp	x21, x2, [sp, #136]
    a3d8:	97ffeb07 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a3dc:	97ffedc9 	bl	5b00 <fwp_rc_fresh>
    a3e0:	aa0003e2 	mov	x2, x0
    a3e4:	910263e1 	add	x1, sp, #0x98
    a3e8:	52800020 	mov	w0, #0x1                   	// #1
    a3ec:	a9098bf7 	stp	x23, x2, [sp, #152]
    a3f0:	97ffeb01 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a3f4:	97ffedc3 	bl	5b00 <fwp_rc_fresh>
    a3f8:	aa0003e2 	mov	x2, x0
    a3fc:	9102a3e1 	add	x1, sp, #0xa8
    a400:	52800020 	mov	w0, #0x1                   	// #1
    a404:	a90a8bf5 	stp	x21, x2, [sp, #168]
    a408:	97ffeafb 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a40c:	97ffedbd 	bl	5b00 <fwp_rc_fresh>
    a410:	aa0003e2 	mov	x2, x0
    a414:	9102e3e1 	add	x1, sp, #0xb8
    a418:	52800020 	mov	w0, #0x1                   	// #1
    a41c:	a90b8bf7 	stp	x23, x2, [sp, #184]
    a420:	97ffeaf5 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a424:	97ffedb7 	bl	5b00 <fwp_rc_fresh>
    a428:	aa0003e2 	mov	x2, x0
    a42c:	910323e1 	add	x1, sp, #0xc8
    a430:	52800020 	mov	w0, #0x1                   	// #1
    a434:	a90c8bf5 	stp	x21, x2, [sp, #200]
    a438:	97ffeaef 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a43c:	91170283 	add	x3, x20, #0x5c0
    a440:	aa0003f5 	mov	x21, x0
    a444:	f949d861 	ldr	x1, [x3, #5040]
    a448:	f949ec60 	ldr	x0, [x3, #5080]
    a44c:	cb0102a1 	sub	x1, x21, x1
    a450:	eb00403f 	cmp	x1, x0, lsl #16
    a454:	54000322 	b.cs	a4b8 <f0+0x318>  // b.hs, b.nlast
    a458:	d350fc22 	lsr	x2, x1, #16
    a45c:	f949fc63 	ldr	x3, [x3, #5112]
    a460:	8b020842 	add	x2, x2, x2, lsl #2
    a464:	d37df042 	lsl	x2, x2, #3
    a468:	8b020060 	add	x0, x3, x2
    a46c:	f9401017 	ldr	x23, [x0, #32]
    a470:	b4000257 	cbz	x23, a4b8 <f0+0x318>
    a474:	38626862 	ldrb	w2, [x3, x2]
    a478:	7100085f 	cmp	w2, #0x2
    a47c:	54010020 	b.eq	c480 <f0+0x22e0>  // b.none
    a480:	7100045f 	cmp	w2, #0x1
    a484:	540001a1 	b.ne	a4b8 <f0+0x318>  // b.any
    a488:	29430002 	ldp	w2, w0, [x0, #24]
    a48c:	92403c21 	and	x1, x1, #0xffff
    a490:	9b027c21 	mul	x1, x1, x2
    a494:	d360fc21 	lsr	x1, x1, #32
    a498:	eb00003f 	cmp	x1, x0
    a49c:	540000e2 	b.cs	a4b8 <f0+0x318>  // b.hs, b.nlast
    a4a0:	8b0102f7 	add	x23, x23, x1
    a4a4:	394002e0 	ldrb	w0, [x23]
    a4a8:	7103fc1f 	cmp	w0, #0xff
    a4ac:	54010d40 	b.eq	c654 <f0+0x24b4>  // b.none
    a4b0:	52800020 	mov	w0, #0x1                   	// #1
    a4b4:	390002e0 	strb	w0, [x23]
    a4b8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a4bc:	910363e1 	add	x1, sp, #0xd8
    a4c0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a4c4:	52800020 	mov	w0, #0x1                   	// #1
    a4c8:	a90dd7e2 	stp	x2, x21, [sp, #216]
    a4cc:	97ffeaca 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a4d0:	91170283 	add	x3, x20, #0x5c0
    a4d4:	aa0003f5 	mov	x21, x0
    a4d8:	f949d861 	ldr	x1, [x3, #5040]
    a4dc:	f949ec60 	ldr	x0, [x3, #5080]
    a4e0:	cb0102a1 	sub	x1, x21, x1
    a4e4:	eb00403f 	cmp	x1, x0, lsl #16
    a4e8:	54000322 	b.cs	a54c <f0+0x3ac>  // b.hs, b.nlast
    a4ec:	d350fc22 	lsr	x2, x1, #16
    a4f0:	f949fc63 	ldr	x3, [x3, #5112]
    a4f4:	8b020842 	add	x2, x2, x2, lsl #2
    a4f8:	d37df042 	lsl	x2, x2, #3
    a4fc:	8b020060 	add	x0, x3, x2
    a500:	f9401017 	ldr	x23, [x0, #32]
    a504:	b4000257 	cbz	x23, a54c <f0+0x3ac>
    a508:	38626862 	ldrb	w2, [x3, x2]
    a50c:	7100085f 	cmp	w2, #0x2
    a510:	5400fb20 	b.eq	c474 <f0+0x22d4>  // b.none
    a514:	7100045f 	cmp	w2, #0x1
    a518:	540001a1 	b.ne	a54c <f0+0x3ac>  // b.any
    a51c:	29430002 	ldp	w2, w0, [x0, #24]
    a520:	92403c21 	and	x1, x1, #0xffff
    a524:	9b027c21 	mul	x1, x1, x2
    a528:	d360fc21 	lsr	x1, x1, #32
    a52c:	eb00003f 	cmp	x1, x0
    a530:	540000e2 	b.cs	a54c <f0+0x3ac>  // b.hs, b.nlast
    a534:	8b0102f7 	add	x23, x23, x1
    a538:	394002e0 	ldrb	w0, [x23]
    a53c:	7103fc1f 	cmp	w0, #0xff
    a540:	54010900 	b.eq	c660 <f0+0x24c0>  // b.none
    a544:	52800020 	mov	w0, #0x1                   	// #1
    a548:	390002e0 	strb	w0, [x23]
    a54c:	9103a3e1 	add	x1, sp, #0xe8
    a550:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a554:	52800020 	mov	w0, #0x1                   	// #1
    a558:	a90ed7f7 	stp	x23, x21, [sp, #232]
    a55c:	97ffeaa6 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a560:	97ffed68 	bl	5b00 <fwp_rc_fresh>
    a564:	aa0003e2 	mov	x2, x0
    a568:	9103e3e1 	add	x1, sp, #0xf8
    a56c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a570:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a574:	52800020 	mov	w0, #0x1                   	// #1
    a578:	a90f8bf5 	stp	x21, x2, [sp, #248]
    a57c:	97ffea9e 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a580:	97ffed60 	bl	5b00 <fwp_rc_fresh>
    a584:	aa0003e2 	mov	x2, x0
    a588:	910423e1 	add	x1, sp, #0x108
    a58c:	52800020 	mov	w0, #0x1                   	// #1
    a590:	a9108bf7 	stp	x23, x2, [sp, #264]
    a594:	97ffea98 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a598:	97ffed5a 	bl	5b00 <fwp_rc_fresh>
    a59c:	aa0003e2 	mov	x2, x0
    a5a0:	910463e1 	add	x1, sp, #0x118
    a5a4:	52800020 	mov	w0, #0x1                   	// #1
    a5a8:	a9118bf5 	stp	x21, x2, [sp, #280]
    a5ac:	97ffea92 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a5b0:	91170283 	add	x3, x20, #0x5c0
    a5b4:	aa0003f5 	mov	x21, x0
    a5b8:	f949d861 	ldr	x1, [x3, #5040]
    a5bc:	f949ec60 	ldr	x0, [x3, #5080]
    a5c0:	cb0102a1 	sub	x1, x21, x1
    a5c4:	eb00403f 	cmp	x1, x0, lsl #16
    a5c8:	54000322 	b.cs	a62c <f0+0x48c>  // b.hs, b.nlast
    a5cc:	d350fc22 	lsr	x2, x1, #16
    a5d0:	f949fc63 	ldr	x3, [x3, #5112]
    a5d4:	8b020842 	add	x2, x2, x2, lsl #2
    a5d8:	d37df042 	lsl	x2, x2, #3
    a5dc:	8b020060 	add	x0, x3, x2
    a5e0:	f9401017 	ldr	x23, [x0, #32]
    a5e4:	b4000257 	cbz	x23, a62c <f0+0x48c>
    a5e8:	38626862 	ldrb	w2, [x3, x2]
    a5ec:	7100085f 	cmp	w2, #0x2
    a5f0:	5400f540 	b.eq	c498 <f0+0x22f8>  // b.none
    a5f4:	7100045f 	cmp	w2, #0x1
    a5f8:	540001a1 	b.ne	a62c <f0+0x48c>  // b.any
    a5fc:	29430002 	ldp	w2, w0, [x0, #24]
    a600:	92403c21 	and	x1, x1, #0xffff
    a604:	9b027c21 	mul	x1, x1, x2
    a608:	d360fc21 	lsr	x1, x1, #32
    a60c:	eb00003f 	cmp	x1, x0
    a610:	540000e2 	b.cs	a62c <f0+0x48c>  // b.hs, b.nlast
    a614:	8b0102f7 	add	x23, x23, x1
    a618:	394002e0 	ldrb	w0, [x23]
    a61c:	7103fc1f 	cmp	w0, #0xff
    a620:	54010260 	b.eq	c66c <f0+0x24cc>  // b.none
    a624:	52800020 	mov	w0, #0x1                   	// #1
    a628:	390002e0 	strb	w0, [x23]
    a62c:	9104a3e1 	add	x1, sp, #0x128
    a630:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a634:	52800020 	mov	w0, #0x1                   	// #1
    a638:	a912d7e2 	stp	x2, x21, [sp, #296]
    a63c:	97ffea6e 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a640:	97ffed30 	bl	5b00 <fwp_rc_fresh>
    a644:	aa0003e2 	mov	x2, x0
    a648:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a64c:	9104e3e1 	add	x1, sp, #0x138
    a650:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a654:	52800020 	mov	w0, #0x1                   	// #1
    a658:	a9138be3 	stp	x3, x2, [sp, #312]
    a65c:	97ffea66 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a660:	91170283 	add	x3, x20, #0x5c0
    a664:	aa0003f5 	mov	x21, x0
    a668:	f949d861 	ldr	x1, [x3, #5040]
    a66c:	f949ec60 	ldr	x0, [x3, #5080]
    a670:	cb0102a1 	sub	x1, x21, x1
    a674:	eb00403f 	cmp	x1, x0, lsl #16
    a678:	54000322 	b.cs	a6dc <f0+0x53c>  // b.hs, b.nlast
    a67c:	d350fc22 	lsr	x2, x1, #16
    a680:	f949fc63 	ldr	x3, [x3, #5112]
    a684:	8b020842 	add	x2, x2, x2, lsl #2
    a688:	d37df042 	lsl	x2, x2, #3
    a68c:	8b020060 	add	x0, x3, x2
    a690:	f9401017 	ldr	x23, [x0, #32]
    a694:	b4000257 	cbz	x23, a6dc <f0+0x53c>
    a698:	38626862 	ldrb	w2, [x3, x2]
    a69c:	7100085f 	cmp	w2, #0x2
    a6a0:	5400ef60 	b.eq	c48c <f0+0x22ec>  // b.none
    a6a4:	7100045f 	cmp	w2, #0x1
    a6a8:	540001a1 	b.ne	a6dc <f0+0x53c>  // b.any
    a6ac:	29430002 	ldp	w2, w0, [x0, #24]
    a6b0:	92403c21 	and	x1, x1, #0xffff
    a6b4:	9b027c21 	mul	x1, x1, x2
    a6b8:	d360fc21 	lsr	x1, x1, #32
    a6bc:	eb00003f 	cmp	x1, x0
    a6c0:	540000e2 	b.cs	a6dc <f0+0x53c>  // b.hs, b.nlast
    a6c4:	8b0102f7 	add	x23, x23, x1
    a6c8:	394002e0 	ldrb	w0, [x23]
    a6cc:	7103fc1f 	cmp	w0, #0xff
    a6d0:	5400fd40 	b.eq	c678 <f0+0x24d8>  // b.none
    a6d4:	52800020 	mov	w0, #0x1                   	// #1
    a6d8:	390002e0 	strb	w0, [x23]
    a6dc:	910523e1 	add	x1, sp, #0x148
    a6e0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a6e4:	52800020 	mov	w0, #0x1                   	// #1
    a6e8:	a914d7f7 	stp	x23, x21, [sp, #328]
    a6ec:	97ffea42 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a6f0:	97ffed04 	bl	5b00 <fwp_rc_fresh>
    a6f4:	aa0003e2 	mov	x2, x0
    a6f8:	910563e1 	add	x1, sp, #0x158
    a6fc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a700:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a704:	52800020 	mov	w0, #0x1                   	// #1
    a708:	a9158bf5 	stp	x21, x2, [sp, #344]
    a70c:	97ffea3a 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a710:	97ffecfc 	bl	5b00 <fwp_rc_fresh>
    a714:	aa0003e2 	mov	x2, x0
    a718:	9105a3e1 	add	x1, sp, #0x168
    a71c:	52800020 	mov	w0, #0x1                   	// #1
    a720:	a9168bf7 	stp	x23, x2, [sp, #360]
    a724:	97ffea34 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a728:	97ffecf6 	bl	5b00 <fwp_rc_fresh>
    a72c:	aa0003e2 	mov	x2, x0
    a730:	9105e3e1 	add	x1, sp, #0x178
    a734:	52800020 	mov	w0, #0x1                   	// #1
    a738:	a9178bf5 	stp	x21, x2, [sp, #376]
    a73c:	97ffea2e 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a740:	97ffecf0 	bl	5b00 <fwp_rc_fresh>
    a744:	aa0003e2 	mov	x2, x0
    a748:	910623e1 	add	x1, sp, #0x188
    a74c:	52800020 	mov	w0, #0x1                   	// #1
    a750:	a9188bf7 	stp	x23, x2, [sp, #392]
    a754:	97ffea28 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a758:	97ffecea 	bl	5b00 <fwp_rc_fresh>
    a75c:	aa0003e2 	mov	x2, x0
    a760:	910663e1 	add	x1, sp, #0x198
    a764:	52800020 	mov	w0, #0x1                   	// #1
    a768:	a9198bf5 	stp	x21, x2, [sp, #408]
    a76c:	97ffea22 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a770:	91170283 	add	x3, x20, #0x5c0
    a774:	aa0003f5 	mov	x21, x0
    a778:	f949d861 	ldr	x1, [x3, #5040]
    a77c:	f949ec60 	ldr	x0, [x3, #5080]
    a780:	cb0102a1 	sub	x1, x21, x1
    a784:	eb00403f 	cmp	x1, x0, lsl #16
    a788:	54000322 	b.cs	a7ec <f0+0x64c>  // b.hs, b.nlast
    a78c:	d350fc22 	lsr	x2, x1, #16
    a790:	f949fc63 	ldr	x3, [x3, #5112]
    a794:	8b020842 	add	x2, x2, x2, lsl #2
    a798:	d37df042 	lsl	x2, x2, #3
    a79c:	8b020060 	add	x0, x3, x2
    a7a0:	f9401017 	ldr	x23, [x0, #32]
    a7a4:	b4000257 	cbz	x23, a7ec <f0+0x64c>
    a7a8:	38626862 	ldrb	w2, [x3, x2]
    a7ac:	7100085f 	cmp	w2, #0x2
    a7b0:	5400e800 	b.eq	c4b0 <f0+0x2310>  // b.none
    a7b4:	7100045f 	cmp	w2, #0x1
    a7b8:	540001a1 	b.ne	a7ec <f0+0x64c>  // b.any
    a7bc:	29430002 	ldp	w2, w0, [x0, #24]
    a7c0:	92403c21 	and	x1, x1, #0xffff
    a7c4:	9b027c21 	mul	x1, x1, x2
    a7c8:	d360fc21 	lsr	x1, x1, #32
    a7cc:	eb00003f 	cmp	x1, x0
    a7d0:	540000e2 	b.cs	a7ec <f0+0x64c>  // b.hs, b.nlast
    a7d4:	8b0102f7 	add	x23, x23, x1
    a7d8:	394002e0 	ldrb	w0, [x23]
    a7dc:	7103fc1f 	cmp	w0, #0xff
    a7e0:	5400f520 	b.eq	c684 <f0+0x24e4>  // b.none
    a7e4:	52800020 	mov	w0, #0x1                   	// #1
    a7e8:	390002e0 	strb	w0, [x23]
    a7ec:	9106a3e1 	add	x1, sp, #0x1a8
    a7f0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a7f4:	52800020 	mov	w0, #0x1                   	// #1
    a7f8:	a91ad7e2 	stp	x2, x21, [sp, #424]
    a7fc:	97ffe9fe 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a800:	97ffecc0 	bl	5b00 <fwp_rc_fresh>
    a804:	aa0003e2 	mov	x2, x0
    a808:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a80c:	9106e3e1 	add	x1, sp, #0x1b8
    a810:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a814:	52800020 	mov	w0, #0x1                   	// #1
    a818:	a91b8be3 	stp	x3, x2, [sp, #440]
    a81c:	97ffe9f6 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a820:	91170283 	add	x3, x20, #0x5c0
    a824:	aa0003f5 	mov	x21, x0
    a828:	f949d861 	ldr	x1, [x3, #5040]
    a82c:	f949ec60 	ldr	x0, [x3, #5080]
    a830:	cb0102a1 	sub	x1, x21, x1
    a834:	eb00403f 	cmp	x1, x0, lsl #16
    a838:	54000322 	b.cs	a89c <f0+0x6fc>  // b.hs, b.nlast
    a83c:	d350fc22 	lsr	x2, x1, #16
    a840:	f949fc63 	ldr	x3, [x3, #5112]
    a844:	8b020842 	add	x2, x2, x2, lsl #2
    a848:	d37df042 	lsl	x2, x2, #3
    a84c:	8b020060 	add	x0, x3, x2
    a850:	f9401017 	ldr	x23, [x0, #32]
    a854:	b4000257 	cbz	x23, a89c <f0+0x6fc>
    a858:	38626862 	ldrb	w2, [x3, x2]
    a85c:	7100085f 	cmp	w2, #0x2
    a860:	5400e220 	b.eq	c4a4 <f0+0x2304>  // b.none
    a864:	7100045f 	cmp	w2, #0x1
    a868:	540001a1 	b.ne	a89c <f0+0x6fc>  // b.any
    a86c:	29430002 	ldp	w2, w0, [x0, #24]
    a870:	92403c21 	and	x1, x1, #0xffff
    a874:	9b027c21 	mul	x1, x1, x2
    a878:	d360fc21 	lsr	x1, x1, #32
    a87c:	eb00003f 	cmp	x1, x0
    a880:	540000e2 	b.cs	a89c <f0+0x6fc>  // b.hs, b.nlast
    a884:	8b0102f7 	add	x23, x23, x1
    a888:	394002e0 	ldrb	w0, [x23]
    a88c:	7103fc1f 	cmp	w0, #0xff
    a890:	5400f000 	b.eq	c690 <f0+0x24f0>  // b.none
    a894:	52800020 	mov	w0, #0x1                   	// #1
    a898:	390002e0 	strb	w0, [x23]
    a89c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a8a0:	910723e1 	add	x1, sp, #0x1c8
    a8a4:	52800020 	mov	w0, #0x1                   	// #1
    a8a8:	a91cd7e2 	stp	x2, x21, [sp, #456]
    a8ac:	97ffe9d2 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a8b0:	91170283 	add	x3, x20, #0x5c0
    a8b4:	aa0003f5 	mov	x21, x0
    a8b8:	f949d861 	ldr	x1, [x3, #5040]
    a8bc:	f949ec60 	ldr	x0, [x3, #5080]
    a8c0:	cb0102a1 	sub	x1, x21, x1
    a8c4:	eb00403f 	cmp	x1, x0, lsl #16
    a8c8:	54000322 	b.cs	a92c <f0+0x78c>  // b.hs, b.nlast
    a8cc:	d350fc22 	lsr	x2, x1, #16
    a8d0:	f949fc63 	ldr	x3, [x3, #5112]
    a8d4:	8b020842 	add	x2, x2, x2, lsl #2
    a8d8:	d37df042 	lsl	x2, x2, #3
    a8dc:	8b020060 	add	x0, x3, x2
    a8e0:	f9401017 	ldr	x23, [x0, #32]
    a8e4:	b4000257 	cbz	x23, a92c <f0+0x78c>
    a8e8:	38626862 	ldrb	w2, [x3, x2]
    a8ec:	7100085f 	cmp	w2, #0x2
    a8f0:	5400e4c0 	b.eq	c588 <f0+0x23e8>  // b.none
    a8f4:	7100045f 	cmp	w2, #0x1
    a8f8:	540001a1 	b.ne	a92c <f0+0x78c>  // b.any
    a8fc:	29430002 	ldp	w2, w0, [x0, #24]
    a900:	92403c21 	and	x1, x1, #0xffff
    a904:	9b027c21 	mul	x1, x1, x2
    a908:	d360fc21 	lsr	x1, x1, #32
    a90c:	eb00003f 	cmp	x1, x0
    a910:	540000e2 	b.cs	a92c <f0+0x78c>  // b.hs, b.nlast
    a914:	8b0102f7 	add	x23, x23, x1
    a918:	394002e0 	ldrb	w0, [x23]
    a91c:	7103fc1f 	cmp	w0, #0xff
    a920:	5400ebe0 	b.eq	c69c <f0+0x24fc>  // b.none
    a924:	52800020 	mov	w0, #0x1                   	// #1
    a928:	390002e0 	strb	w0, [x23]
    a92c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a930:	910763e1 	add	x1, sp, #0x1d8
    a934:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a938:	52800020 	mov	w0, #0x1                   	// #1
    a93c:	a91dd7e2 	stp	x2, x21, [sp, #472]
    a940:	97ffe9ad 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a944:	91170283 	add	x3, x20, #0x5c0
    a948:	aa0003f5 	mov	x21, x0
    a94c:	f949d861 	ldr	x1, [x3, #5040]
    a950:	f949ec60 	ldr	x0, [x3, #5080]
    a954:	cb0102a1 	sub	x1, x21, x1
    a958:	eb00403f 	cmp	x1, x0, lsl #16
    a95c:	54000322 	b.cs	a9c0 <f0+0x820>  // b.hs, b.nlast
    a960:	d350fc22 	lsr	x2, x1, #16
    a964:	f949fc63 	ldr	x3, [x3, #5112]
    a968:	8b020842 	add	x2, x2, x2, lsl #2
    a96c:	d37df042 	lsl	x2, x2, #3
    a970:	8b020060 	add	x0, x3, x2
    a974:	f9401017 	ldr	x23, [x0, #32]
    a978:	b4000257 	cbz	x23, a9c0 <f0+0x820>
    a97c:	38626862 	ldrb	w2, [x3, x2]
    a980:	7100085f 	cmp	w2, #0x2
    a984:	5400dfc0 	b.eq	c57c <f0+0x23dc>  // b.none
    a988:	7100045f 	cmp	w2, #0x1
    a98c:	540001a1 	b.ne	a9c0 <f0+0x820>  // b.any
    a990:	29430002 	ldp	w2, w0, [x0, #24]
    a994:	92403c21 	and	x1, x1, #0xffff
    a998:	9b027c21 	mul	x1, x1, x2
    a99c:	d360fc21 	lsr	x1, x1, #32
    a9a0:	eb00003f 	cmp	x1, x0
    a9a4:	540000e2 	b.cs	a9c0 <f0+0x820>  // b.hs, b.nlast
    a9a8:	8b0102f7 	add	x23, x23, x1
    a9ac:	394002e0 	ldrb	w0, [x23]
    a9b0:	7103fc1f 	cmp	w0, #0xff
    a9b4:	5400e7a0 	b.eq	c6a8 <f0+0x2508>  // b.none
    a9b8:	52800020 	mov	w0, #0x1                   	// #1
    a9bc:	390002e0 	strb	w0, [x23]
    a9c0:	9107a3e1 	add	x1, sp, #0x1e8
    a9c4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a9c8:	52800020 	mov	w0, #0x1                   	// #1
    a9cc:	a91ed7e2 	stp	x2, x21, [sp, #488]
    a9d0:	97ffe989 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a9d4:	97ffec4b 	bl	5b00 <fwp_rc_fresh>
    a9d8:	aa0003e2 	mov	x2, x0
    a9dc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a9e0:	9107e3e1 	add	x1, sp, #0x1f8
    a9e4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a9e8:	52800020 	mov	w0, #0x1                   	// #1
    a9ec:	a91f8be3 	stp	x3, x2, [sp, #504]
    a9f0:	97ffe981 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a9f4:	91170283 	add	x3, x20, #0x5c0
    a9f8:	aa0003f5 	mov	x21, x0
    a9fc:	f949d861 	ldr	x1, [x3, #5040]
    aa00:	f949ec60 	ldr	x0, [x3, #5080]
    aa04:	cb0102a1 	sub	x1, x21, x1
    aa08:	eb00403f 	cmp	x1, x0, lsl #16
    aa0c:	54000322 	b.cs	aa70 <f0+0x8d0>  // b.hs, b.nlast
    aa10:	d350fc22 	lsr	x2, x1, #16
    aa14:	f949fc63 	ldr	x3, [x3, #5112]
    aa18:	8b020842 	add	x2, x2, x2, lsl #2
    aa1c:	d37df042 	lsl	x2, x2, #3
    aa20:	8b020060 	add	x0, x3, x2
    aa24:	f9401017 	ldr	x23, [x0, #32]
    aa28:	b4000257 	cbz	x23, aa70 <f0+0x8d0>
    aa2c:	38626862 	ldrb	w2, [x3, x2]
    aa30:	7100085f 	cmp	w2, #0x2
    aa34:	5400db60 	b.eq	c5a0 <f0+0x2400>  // b.none
    aa38:	7100045f 	cmp	w2, #0x1
    aa3c:	540001a1 	b.ne	aa70 <f0+0x8d0>  // b.any
    aa40:	29430002 	ldp	w2, w0, [x0, #24]
    aa44:	92403c21 	and	x1, x1, #0xffff
    aa48:	9b027c21 	mul	x1, x1, x2
    aa4c:	d360fc21 	lsr	x1, x1, #32
    aa50:	eb00003f 	cmp	x1, x0
    aa54:	540000e2 	b.cs	aa70 <f0+0x8d0>  // b.hs, b.nlast
    aa58:	8b0102f7 	add	x23, x23, x1
    aa5c:	394002e0 	ldrb	w0, [x23]
    aa60:	7103fc1f 	cmp	w0, #0xff
    aa64:	5400e280 	b.eq	c6b4 <f0+0x2514>  // b.none
    aa68:	52800020 	mov	w0, #0x1                   	// #1
    aa6c:	390002e0 	strb	w0, [x23]
    aa70:	910823e1 	add	x1, sp, #0x208
    aa74:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aa78:	52800020 	mov	w0, #0x1                   	// #1
    aa7c:	f90107e2 	str	x2, [sp, #520]
    aa80:	f9010bf5 	str	x21, [sp, #528]
    aa84:	97ffe95c 	bl	4ff4 <fwp_data.part.0.constprop.0>
    aa88:	97ffec1e 	bl	5b00 <fwp_rc_fresh>
    aa8c:	aa0003e2 	mov	x2, x0
    aa90:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aa94:	910863e1 	add	x1, sp, #0x218
    aa98:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aa9c:	52800020 	mov	w0, #0x1                   	// #1
    aaa0:	f9010fe3 	str	x3, [sp, #536]
    aaa4:	f90113e2 	str	x2, [sp, #544]
    aaa8:	97ffe953 	bl	4ff4 <fwp_data.part.0.constprop.0>
    aaac:	91170283 	add	x3, x20, #0x5c0
    aab0:	aa0003f5 	mov	x21, x0
    aab4:	f949d861 	ldr	x1, [x3, #5040]
    aab8:	f949ec60 	ldr	x0, [x3, #5080]
    aabc:	cb0102a1 	sub	x1, x21, x1
    aac0:	eb00403f 	cmp	x1, x0, lsl #16
    aac4:	54000322 	b.cs	ab28 <f0+0x988>  // b.hs, b.nlast
    aac8:	d350fc22 	lsr	x2, x1, #16
    aacc:	f949fc63 	ldr	x3, [x3, #5112]
    aad0:	8b020842 	add	x2, x2, x2, lsl #2
    aad4:	d37df042 	lsl	x2, x2, #3
    aad8:	8b020060 	add	x0, x3, x2
    aadc:	f9401017 	ldr	x23, [x0, #32]
    aae0:	b4000257 	cbz	x23, ab28 <f0+0x988>
    aae4:	38626862 	ldrb	w2, [x3, x2]
    aae8:	7100085f 	cmp	w2, #0x2
    aaec:	5400d540 	b.eq	c594 <f0+0x23f4>  // b.none
    aaf0:	7100045f 	cmp	w2, #0x1
    aaf4:	540001a1 	b.ne	ab28 <f0+0x988>  // b.any
    aaf8:	29430002 	ldp	w2, w0, [x0, #24]
    aafc:	92403c21 	and	x1, x1, #0xffff
    ab00:	9b027c21 	mul	x1, x1, x2
    ab04:	d360fc21 	lsr	x1, x1, #32
    ab08:	eb00003f 	cmp	x1, x0
    ab0c:	540000e2 	b.cs	ab28 <f0+0x988>  // b.hs, b.nlast
    ab10:	8b0102f7 	add	x23, x23, x1
    ab14:	394002e0 	ldrb	w0, [x23]
    ab18:	7103fc1f 	cmp	w0, #0xff
    ab1c:	5400dd20 	b.eq	c6c0 <f0+0x2520>  // b.none
    ab20:	52800020 	mov	w0, #0x1                   	// #1
    ab24:	390002e0 	strb	w0, [x23]
    ab28:	9108a3e1 	add	x1, sp, #0x228
    ab2c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ab30:	52800020 	mov	w0, #0x1                   	// #1
    ab34:	f90117f7 	str	x23, [sp, #552]
    ab38:	f9011bf5 	str	x21, [sp, #560]
    ab3c:	97ffe92e 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ab40:	97ffebf0 	bl	5b00 <fwp_rc_fresh>
    ab44:	aa0003e2 	mov	x2, x0
    ab48:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ab4c:	9108e3e1 	add	x1, sp, #0x238
    ab50:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ab54:	52800020 	mov	w0, #0x1                   	// #1
    ab58:	f9011fe3 	str	x3, [sp, #568]
    ab5c:	f90123e2 	str	x2, [sp, #576]
    ab60:	97ffe925 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ab64:	97ffebe7 	bl	5b00 <fwp_rc_fresh>
    ab68:	aa0003e2 	mov	x2, x0
    ab6c:	910923e1 	add	x1, sp, #0x248
    ab70:	52800020 	mov	w0, #0x1                   	// #1
    ab74:	f90127f7 	str	x23, [sp, #584]
    ab78:	f9012be2 	str	x2, [sp, #592]
    ab7c:	97ffe91e 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ab80:	91170283 	add	x3, x20, #0x5c0
    ab84:	aa0003f5 	mov	x21, x0
    ab88:	f949d861 	ldr	x1, [x3, #5040]
    ab8c:	f949ec60 	ldr	x0, [x3, #5080]
    ab90:	cb0102a1 	sub	x1, x21, x1
    ab94:	eb00403f 	cmp	x1, x0, lsl #16
    ab98:	54000322 	b.cs	abfc <f0+0xa5c>  // b.hs, b.nlast
    ab9c:	d350fc22 	lsr	x2, x1, #16
    aba0:	f949fc63 	ldr	x3, [x3, #5112]
    aba4:	8b020842 	add	x2, x2, x2, lsl #2
    aba8:	d37df042 	lsl	x2, x2, #3
    abac:	8b020060 	add	x0, x3, x2
    abb0:	f9401017 	ldr	x23, [x0, #32]
    abb4:	b4000257 	cbz	x23, abfc <f0+0xa5c>
    abb8:	38626862 	ldrb	w2, [x3, x2]
    abbc:	7100085f 	cmp	w2, #0x2
    abc0:	5400cfc0 	b.eq	c5b8 <f0+0x2418>  // b.none
    abc4:	7100045f 	cmp	w2, #0x1
    abc8:	540001a1 	b.ne	abfc <f0+0xa5c>  // b.any
    abcc:	29430002 	ldp	w2, w0, [x0, #24]
    abd0:	92403c21 	and	x1, x1, #0xffff
    abd4:	9b027c21 	mul	x1, x1, x2
    abd8:	d360fc21 	lsr	x1, x1, #32
    abdc:	eb00003f 	cmp	x1, x0
    abe0:	540000e2 	b.cs	abfc <f0+0xa5c>  // b.hs, b.nlast
    abe4:	8b0102f7 	add	x23, x23, x1
    abe8:	394002e0 	ldrb	w0, [x23]
    abec:	7103fc1f 	cmp	w0, #0xff
    abf0:	5400d6e0 	b.eq	c6cc <f0+0x252c>  // b.none
    abf4:	52800020 	mov	w0, #0x1                   	// #1
    abf8:	390002e0 	strb	w0, [x23]
    abfc:	910963e1 	add	x1, sp, #0x258
    ac00:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ac04:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ac08:	52800020 	mov	w0, #0x1                   	// #1
    ac0c:	f9012ff7 	str	x23, [sp, #600]
    ac10:	f90133f5 	str	x21, [sp, #608]
    ac14:	97ffe8f8 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ac18:	97ffebba 	bl	5b00 <fwp_rc_fresh>
    ac1c:	aa0003e2 	mov	x2, x0
    ac20:	9109a3e1 	add	x1, sp, #0x268
    ac24:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ac28:	52800020 	mov	w0, #0x1                   	// #1
    ac2c:	f90137f5 	str	x21, [sp, #616]
    ac30:	f9013be2 	str	x2, [sp, #624]
    ac34:	97ffe8f0 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ac38:	97ffebb2 	bl	5b00 <fwp_rc_fresh>
    ac3c:	aa0003e2 	mov	x2, x0
    ac40:	9109e3e1 	add	x1, sp, #0x278
    ac44:	52800020 	mov	w0, #0x1                   	// #1
    ac48:	f9013ff7 	str	x23, [sp, #632]
    ac4c:	f90143e2 	str	x2, [sp, #640]
    ac50:	97ffe8e9 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ac54:	97ffebab 	bl	5b00 <fwp_rc_fresh>
    ac58:	aa0003e2 	mov	x2, x0
    ac5c:	910a23e1 	add	x1, sp, #0x288
    ac60:	52800020 	mov	w0, #0x1                   	// #1
    ac64:	f90147f5 	str	x21, [sp, #648]
    ac68:	f9014be2 	str	x2, [sp, #656]
    ac6c:	97ffe8e2 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ac70:	91170283 	add	x3, x20, #0x5c0
    ac74:	aa0003f5 	mov	x21, x0
    ac78:	f949d861 	ldr	x1, [x3, #5040]
    ac7c:	f949ec60 	ldr	x0, [x3, #5080]
    ac80:	cb0102a1 	sub	x1, x21, x1
    ac84:	eb00403f 	cmp	x1, x0, lsl #16
    ac88:	54000322 	b.cs	acec <f0+0xb4c>  // b.hs, b.nlast
    ac8c:	d350fc22 	lsr	x2, x1, #16
    ac90:	f949fc63 	ldr	x3, [x3, #5112]
    ac94:	8b020842 	add	x2, x2, x2, lsl #2
    ac98:	d37df042 	lsl	x2, x2, #3
    ac9c:	8b020060 	add	x0, x3, x2
    aca0:	f9401017 	ldr	x23, [x0, #32]
    aca4:	b4000257 	cbz	x23, acec <f0+0xb4c>
    aca8:	38626862 	ldrb	w2, [x3, x2]
    acac:	7100085f 	cmp	w2, #0x2
    acb0:	5400c7e0 	b.eq	c5ac <f0+0x240c>  // b.none
    acb4:	7100045f 	cmp	w2, #0x1
    acb8:	540001a1 	b.ne	acec <f0+0xb4c>  // b.any
    acbc:	29430002 	ldp	w2, w0, [x0, #24]
    acc0:	92403c21 	and	x1, x1, #0xffff
    acc4:	9b027c21 	mul	x1, x1, x2
    acc8:	d360fc21 	lsr	x1, x1, #32
    accc:	eb00003f 	cmp	x1, x0
    acd0:	540000e2 	b.cs	acec <f0+0xb4c>  // b.hs, b.nlast
    acd4:	8b0102f7 	add	x23, x23, x1
    acd8:	394002e0 	ldrb	w0, [x23]
    acdc:	7103fc1f 	cmp	w0, #0xff
    ace0:	5400cfc0 	b.eq	c6d8 <f0+0x2538>  // b.none
    ace4:	52800020 	mov	w0, #0x1                   	// #1
    ace8:	390002e0 	strb	w0, [x23]
    acec:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    acf0:	910a63e1 	add	x1, sp, #0x298
    acf4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    acf8:	52800020 	mov	w0, #0x1                   	// #1
    acfc:	f9014fe2 	str	x2, [sp, #664]
    ad00:	f90153f5 	str	x21, [sp, #672]
    ad04:	97ffe8bc 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ad08:	91170283 	add	x3, x20, #0x5c0
    ad0c:	aa0003f5 	mov	x21, x0
    ad10:	f949d861 	ldr	x1, [x3, #5040]
    ad14:	f949ec60 	ldr	x0, [x3, #5080]
    ad18:	cb0102a1 	sub	x1, x21, x1
    ad1c:	eb00403f 	cmp	x1, x0, lsl #16
    ad20:	54000322 	b.cs	ad84 <f0+0xbe4>  // b.hs, b.nlast
    ad24:	d350fc22 	lsr	x2, x1, #16
    ad28:	f949fc63 	ldr	x3, [x3, #5112]
    ad2c:	8b020842 	add	x2, x2, x2, lsl #2
    ad30:	d37df042 	lsl	x2, x2, #3
    ad34:	8b020060 	add	x0, x3, x2
    ad38:	f9401017 	ldr	x23, [x0, #32]
    ad3c:	b4000257 	cbz	x23, ad84 <f0+0xbe4>
    ad40:	38626862 	ldrb	w2, [x3, x2]
    ad44:	7100085f 	cmp	w2, #0x2
    ad48:	5400c440 	b.eq	c5d0 <f0+0x2430>  // b.none
    ad4c:	7100045f 	cmp	w2, #0x1
    ad50:	540001a1 	b.ne	ad84 <f0+0xbe4>  // b.any
    ad54:	29430002 	ldp	w2, w0, [x0, #24]
    ad58:	92403c21 	and	x1, x1, #0xffff
    ad5c:	9b027c21 	mul	x1, x1, x2
    ad60:	d360fc21 	lsr	x1, x1, #32
    ad64:	eb00003f 	cmp	x1, x0
    ad68:	540000e2 	b.cs	ad84 <f0+0xbe4>  // b.hs, b.nlast
    ad6c:	8b0102f7 	add	x23, x23, x1
    ad70:	394002e0 	ldrb	w0, [x23]
    ad74:	7103fc1f 	cmp	w0, #0xff
    ad78:	5400cb60 	b.eq	c6e4 <f0+0x2544>  // b.none
    ad7c:	52800020 	mov	w0, #0x1                   	// #1
    ad80:	390002e0 	strb	w0, [x23]
    ad84:	910aa3e1 	add	x1, sp, #0x2a8
    ad88:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ad8c:	52800020 	mov	w0, #0x1                   	// #1
    ad90:	f90157e2 	str	x2, [sp, #680]
    ad94:	f9015bf5 	str	x21, [sp, #688]
    ad98:	97ffe897 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ad9c:	97ffeb59 	bl	5b00 <fwp_rc_fresh>
    ada0:	aa0003e2 	mov	x2, x0
    ada4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ada8:	910ae3e1 	add	x1, sp, #0x2b8
    adac:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    adb0:	52800020 	mov	w0, #0x1                   	// #1
    adb4:	f9015fe3 	str	x3, [sp, #696]
    adb8:	f90163e2 	str	x2, [sp, #704]
    adbc:	97ffe88e 	bl	4ff4 <fwp_data.part.0.constprop.0>
    adc0:	91170283 	add	x3, x20, #0x5c0
    adc4:	aa0003f5 	mov	x21, x0
    adc8:	f949d861 	ldr	x1, [x3, #5040]
    adcc:	f949ec60 	ldr	x0, [x3, #5080]
    add0:	cb0102a1 	sub	x1, x21, x1
    add4:	eb00403f 	cmp	x1, x0, lsl #16
    add8:	54000322 	b.cs	ae3c <f0+0xc9c>  // b.hs, b.nlast
    addc:	d350fc22 	lsr	x2, x1, #16
    ade0:	f949fc63 	ldr	x3, [x3, #5112]
    ade4:	8b020842 	add	x2, x2, x2, lsl #2
    ade8:	d37df042 	lsl	x2, x2, #3
    adec:	8b020060 	add	x0, x3, x2
    adf0:	f9401017 	ldr	x23, [x0, #32]
    adf4:	b4000257 	cbz	x23, ae3c <f0+0xc9c>
    adf8:	38626862 	ldrb	w2, [x3, x2]
    adfc:	7100085f 	cmp	w2, #0x2
    ae00:	5400be20 	b.eq	c5c4 <f0+0x2424>  // b.none
    ae04:	7100045f 	cmp	w2, #0x1
    ae08:	540001a1 	b.ne	ae3c <f0+0xc9c>  // b.any
    ae0c:	29430002 	ldp	w2, w0, [x0, #24]
    ae10:	92403c21 	and	x1, x1, #0xffff
    ae14:	9b027c21 	mul	x1, x1, x2
    ae18:	d360fc21 	lsr	x1, x1, #32
    ae1c:	eb00003f 	cmp	x1, x0
    ae20:	540000e2 	b.cs	ae3c <f0+0xc9c>  // b.hs, b.nlast
    ae24:	8b0102f7 	add	x23, x23, x1
    ae28:	394002e0 	ldrb	w0, [x23]
    ae2c:	7103fc1f 	cmp	w0, #0xff
    ae30:	5400c600 	b.eq	c6f0 <f0+0x2550>  // b.none
    ae34:	52800020 	mov	w0, #0x1                   	// #1
    ae38:	390002e0 	strb	w0, [x23]
    ae3c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ae40:	910b23e1 	add	x1, sp, #0x2c8
    ae44:	52800020 	mov	w0, #0x1                   	// #1
    ae48:	f90167e2 	str	x2, [sp, #712]
    ae4c:	f9016bf5 	str	x21, [sp, #720]
    ae50:	97ffe869 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ae54:	91170283 	add	x3, x20, #0x5c0
    ae58:	aa0003f5 	mov	x21, x0
    ae5c:	f949d861 	ldr	x1, [x3, #5040]
    ae60:	f949ec60 	ldr	x0, [x3, #5080]
    ae64:	cb0102a1 	sub	x1, x21, x1
    ae68:	eb00403f 	cmp	x1, x0, lsl #16
    ae6c:	54000322 	b.cs	aed0 <f0+0xd30>  // b.hs, b.nlast
    ae70:	d350fc22 	lsr	x2, x1, #16
    ae74:	f949fc63 	ldr	x3, [x3, #5112]
    ae78:	8b020842 	add	x2, x2, x2, lsl #2
    ae7c:	d37df042 	lsl	x2, x2, #3
    ae80:	8b020060 	add	x0, x3, x2
    ae84:	f9401017 	ldr	x23, [x0, #32]
    ae88:	b4000257 	cbz	x23, aed0 <f0+0xd30>
    ae8c:	38626862 	ldrb	w2, [x3, x2]
    ae90:	7100085f 	cmp	w2, #0x2
    ae94:	5400baa0 	b.eq	c5e8 <f0+0x2448>  // b.none
    ae98:	7100045f 	cmp	w2, #0x1
    ae9c:	540001a1 	b.ne	aed0 <f0+0xd30>  // b.any
    aea0:	29430002 	ldp	w2, w0, [x0, #24]
    aea4:	92403c21 	and	x1, x1, #0xffff
    aea8:	9b027c21 	mul	x1, x1, x2
    aeac:	d360fc21 	lsr	x1, x1, #32
    aeb0:	eb00003f 	cmp	x1, x0
    aeb4:	540000e2 	b.cs	aed0 <f0+0xd30>  // b.hs, b.nlast
    aeb8:	8b0102f7 	add	x23, x23, x1
    aebc:	394002e0 	ldrb	w0, [x23]
    aec0:	7103fc1f 	cmp	w0, #0xff
    aec4:	5400c1c0 	b.eq	c6fc <f0+0x255c>  // b.none
    aec8:	52800020 	mov	w0, #0x1                   	// #1
    aecc:	390002e0 	strb	w0, [x23]
    aed0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aed4:	910b63e1 	add	x1, sp, #0x2d8
    aed8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aedc:	52800020 	mov	w0, #0x1                   	// #1
    aee0:	f9016fe2 	str	x2, [sp, #728]
    aee4:	f90173f5 	str	x21, [sp, #736]
    aee8:	97ffe843 	bl	4ff4 <fwp_data.part.0.constprop.0>
    aeec:	91170283 	add	x3, x20, #0x5c0
    aef0:	aa0003f5 	mov	x21, x0
    aef4:	f949d861 	ldr	x1, [x3, #5040]
    aef8:	f949ec60 	ldr	x0, [x3, #5080]
    aefc:	cb0102a1 	sub	x1, x21, x1
    af00:	eb00403f 	cmp	x1, x0, lsl #16
    af04:	54000322 	b.cs	af68 <f0+0xdc8>  // b.hs, b.nlast
    af08:	d350fc22 	lsr	x2, x1, #16
    af0c:	f949fc63 	ldr	x3, [x3, #5112]
    af10:	8b020842 	add	x2, x2, x2, lsl #2
    af14:	d37df042 	lsl	x2, x2, #3
    af18:	8b020060 	add	x0, x3, x2
    af1c:	f9401017 	ldr	x23, [x0, #32]
    af20:	b4000257 	cbz	x23, af68 <f0+0xdc8>
    af24:	38626862 	ldrb	w2, [x3, x2]
    af28:	7100085f 	cmp	w2, #0x2
    af2c:	5400b580 	b.eq	c5dc <f0+0x243c>  // b.none
    af30:	7100045f 	cmp	w2, #0x1
    af34:	540001a1 	b.ne	af68 <f0+0xdc8>  // b.any
    af38:	29430002 	ldp	w2, w0, [x0, #24]
    af3c:	92403c21 	and	x1, x1, #0xffff
    af40:	9b027c21 	mul	x1, x1, x2
    af44:	d360fc21 	lsr	x1, x1, #32
    af48:	eb00003f 	cmp	x1, x0
    af4c:	540000e2 	b.cs	af68 <f0+0xdc8>  // b.hs, b.nlast
    af50:	8b0102f7 	add	x23, x23, x1
    af54:	394002e0 	ldrb	w0, [x23]
    af58:	7103fc1f 	cmp	w0, #0xff
    af5c:	5400bd60 	b.eq	c708 <f0+0x2568>  // b.none
    af60:	52800020 	mov	w0, #0x1                   	// #1
    af64:	390002e0 	strb	w0, [x23]
    af68:	910ba3e1 	add	x1, sp, #0x2e8
    af6c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    af70:	52800020 	mov	w0, #0x1                   	// #1
    af74:	f90177f7 	str	x23, [sp, #744]
    af78:	f9017bf5 	str	x21, [sp, #752]
    af7c:	97ffe81e 	bl	4ff4 <fwp_data.part.0.constprop.0>
    af80:	97ffeae0 	bl	5b00 <fwp_rc_fresh>
    af84:	aa0003e2 	mov	x2, x0
    af88:	910be3e1 	add	x1, sp, #0x2f8
    af8c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    af90:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    af94:	52800020 	mov	w0, #0x1                   	// #1
    af98:	f9017ff5 	str	x21, [sp, #760]
    af9c:	f90183e2 	str	x2, [sp, #768]
    afa0:	97ffe815 	bl	4ff4 <fwp_data.part.0.constprop.0>
    afa4:	97ffead7 	bl	5b00 <fwp_rc_fresh>
    afa8:	aa0003e2 	mov	x2, x0
    afac:	910c23e1 	add	x1, sp, #0x308
    afb0:	52800020 	mov	w0, #0x1                   	// #1
    afb4:	f90187f7 	str	x23, [sp, #776]
    afb8:	f9018be2 	str	x2, [sp, #784]
    afbc:	97ffe80e 	bl	4ff4 <fwp_data.part.0.constprop.0>
    afc0:	97ffead0 	bl	5b00 <fwp_rc_fresh>
    afc4:	aa0003e2 	mov	x2, x0
    afc8:	910c63e1 	add	x1, sp, #0x318
    afcc:	52800020 	mov	w0, #0x1                   	// #1
    afd0:	f9018ff5 	str	x21, [sp, #792]
    afd4:	f90193e2 	str	x2, [sp, #800]
    afd8:	97ffe807 	bl	4ff4 <fwp_data.part.0.constprop.0>
    afdc:	91170283 	add	x3, x20, #0x5c0
    afe0:	aa0003f5 	mov	x21, x0
    afe4:	f949d861 	ldr	x1, [x3, #5040]
    afe8:	f949ec60 	ldr	x0, [x3, #5080]
    afec:	cb0102a1 	sub	x1, x21, x1
    aff0:	eb00403f 	cmp	x1, x0, lsl #16
    aff4:	54000322 	b.cs	b058 <f0+0xeb8>  // b.hs, b.nlast
    aff8:	d350fc22 	lsr	x2, x1, #16
    affc:	f949fc63 	ldr	x3, [x3, #5112]
    b000:	8b020842 	add	x2, x2, x2, lsl #2
    b004:	d37df042 	lsl	x2, x2, #3
    b008:	8b020060 	add	x0, x3, x2
    b00c:	f9401017 	ldr	x23, [x0, #32]
    b010:	b4000257 	cbz	x23, b058 <f0+0xeb8>
    b014:	38626862 	ldrb	w2, [x3, x2]
    b018:	7100085f 	cmp	w2, #0x2
    b01c:	5400af20 	b.eq	c600 <f0+0x2460>  // b.none
    b020:	7100045f 	cmp	w2, #0x1
    b024:	540001a1 	b.ne	b058 <f0+0xeb8>  // b.any
    b028:	29430002 	ldp	w2, w0, [x0, #24]
    b02c:	92403c21 	and	x1, x1, #0xffff
    b030:	9b027c21 	mul	x1, x1, x2
    b034:	d360fc21 	lsr	x1, x1, #32
    b038:	eb00003f 	cmp	x1, x0
    b03c:	540000e2 	b.cs	b058 <f0+0xeb8>  // b.hs, b.nlast
    b040:	8b0102f7 	add	x23, x23, x1
    b044:	394002e0 	ldrb	w0, [x23]
    b048:	7103fc1f 	cmp	w0, #0xff
    b04c:	5400b640 	b.eq	c714 <f0+0x2574>  // b.none
    b050:	52800020 	mov	w0, #0x1                   	// #1
    b054:	390002e0 	strb	w0, [x23]
    b058:	910ca3e1 	add	x1, sp, #0x328
    b05c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b060:	52800020 	mov	w0, #0x1                   	// #1
    b064:	f90197f7 	str	x23, [sp, #808]
    b068:	f9019bf5 	str	x21, [sp, #816]
    b06c:	97ffe7e2 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b070:	97ffeaa4 	bl	5b00 <fwp_rc_fresh>
    b074:	aa0003e2 	mov	x2, x0
    b078:	910ce3e1 	add	x1, sp, #0x338
    b07c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b080:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b084:	52800020 	mov	w0, #0x1                   	// #1
    b088:	f9019ff5 	str	x21, [sp, #824]
    b08c:	f901a3e2 	str	x2, [sp, #832]
    b090:	97ffe7d9 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b094:	97ffea9b 	bl	5b00 <fwp_rc_fresh>
    b098:	aa0003e2 	mov	x2, x0
    b09c:	910d23e1 	add	x1, sp, #0x348
    b0a0:	52800020 	mov	w0, #0x1                   	// #1
    b0a4:	f901a7f7 	str	x23, [sp, #840]
    b0a8:	f901abe2 	str	x2, [sp, #848]
    b0ac:	97ffe7d2 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b0b0:	97ffea94 	bl	5b00 <fwp_rc_fresh>
    b0b4:	aa0003e2 	mov	x2, x0
    b0b8:	910d63e1 	add	x1, sp, #0x358
    b0bc:	52800020 	mov	w0, #0x1                   	// #1
    b0c0:	f901aff5 	str	x21, [sp, #856]
    b0c4:	f901b3e2 	str	x2, [sp, #864]
    b0c8:	97ffe7cb 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b0cc:	91170283 	add	x3, x20, #0x5c0
    b0d0:	aa0003f7 	mov	x23, x0
    b0d4:	f949d861 	ldr	x1, [x3, #5040]
    b0d8:	f949ec60 	ldr	x0, [x3, #5080]
    b0dc:	cb0102e1 	sub	x1, x23, x1
    b0e0:	eb00403f 	cmp	x1, x0, lsl #16
    b0e4:	54000322 	b.cs	b148 <f0+0xfa8>  // b.hs, b.nlast
    b0e8:	d350fc22 	lsr	x2, x1, #16
    b0ec:	f949fc63 	ldr	x3, [x3, #5112]
    b0f0:	8b020842 	add	x2, x2, x2, lsl #2
    b0f4:	d37df042 	lsl	x2, x2, #3
    b0f8:	8b020060 	add	x0, x3, x2
    b0fc:	f9401015 	ldr	x21, [x0, #32]
    b100:	b4000255 	cbz	x21, b148 <f0+0xfa8>
    b104:	38626862 	ldrb	w2, [x3, x2]
    b108:	7100085f 	cmp	w2, #0x2
    b10c:	5400a740 	b.eq	c5f4 <f0+0x2454>  // b.none
    b110:	7100045f 	cmp	w2, #0x1
    b114:	540001a1 	b.ne	b148 <f0+0xfa8>  // b.any
    b118:	29430002 	ldp	w2, w0, [x0, #24]
    b11c:	92403c21 	and	x1, x1, #0xffff
    b120:	9b027c21 	mul	x1, x1, x2
    b124:	d360fc21 	lsr	x1, x1, #32
    b128:	eb00003f 	cmp	x1, x0
    b12c:	540000e2 	b.cs	b148 <f0+0xfa8>  // b.hs, b.nlast
    b130:	8b0102b5 	add	x21, x21, x1
    b134:	394002a0 	ldrb	w0, [x21]
    b138:	7103fc1f 	cmp	w0, #0xff
    b13c:	5400af20 	b.eq	c720 <f0+0x2580>  // b.none
    b140:	52800020 	mov	w0, #0x1                   	// #1
    b144:	390002a0 	strb	w0, [x21]
    b148:	910da3e1 	add	x1, sp, #0x368
    b14c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b150:	52800020 	mov	w0, #0x1                   	// #1
    b154:	f901b7f5 	str	x21, [sp, #872]
    b158:	f901bbf7 	str	x23, [sp, #880]
    b15c:	97ffe7a6 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b160:	97ffea68 	bl	5b00 <fwp_rc_fresh>
    b164:	aa0003e2 	mov	x2, x0
    b168:	910de3e1 	add	x1, sp, #0x378
    b16c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b170:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b174:	52800020 	mov	w0, #0x1                   	// #1
    b178:	f901bff7 	str	x23, [sp, #888]
    b17c:	f901c3e2 	str	x2, [sp, #896]
    b180:	97ffe79d 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b184:	97ffea5f 	bl	5b00 <fwp_rc_fresh>
    b188:	aa0003e2 	mov	x2, x0
    b18c:	910e23e1 	add	x1, sp, #0x388
    b190:	52800020 	mov	w0, #0x1                   	// #1
    b194:	f901c7f5 	str	x21, [sp, #904]
    b198:	f901cbe2 	str	x2, [sp, #912]
    b19c:	97ffe796 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b1a0:	97ffea58 	bl	5b00 <fwp_rc_fresh>
    b1a4:	aa0003e2 	mov	x2, x0
    b1a8:	910e63e1 	add	x1, sp, #0x398
    b1ac:	52800020 	mov	w0, #0x1                   	// #1
    b1b0:	f901cff7 	str	x23, [sp, #920]
    b1b4:	f901d3e2 	str	x2, [sp, #928]
    b1b8:	97ffe78f 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b1bc:	97ffea51 	bl	5b00 <fwp_rc_fresh>
    b1c0:	aa0003e2 	mov	x2, x0
    b1c4:	910ea3e1 	add	x1, sp, #0x3a8
    b1c8:	52800020 	mov	w0, #0x1                   	// #1
    b1cc:	f901d7f5 	str	x21, [sp, #936]
    b1d0:	f901dbe2 	str	x2, [sp, #944]
    b1d4:	97ffe788 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b1d8:	97ffea4a 	bl	5b00 <fwp_rc_fresh>
    b1dc:	aa0003e2 	mov	x2, x0
    b1e0:	910ee3e1 	add	x1, sp, #0x3b8
    b1e4:	52800020 	mov	w0, #0x1                   	// #1
    b1e8:	f901dff7 	str	x23, [sp, #952]
    b1ec:	f901e3e2 	str	x2, [sp, #960]
    b1f0:	97ffe781 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b1f4:	97ffea43 	bl	5b00 <fwp_rc_fresh>
    b1f8:	aa0003e2 	mov	x2, x0
    b1fc:	910f23e1 	add	x1, sp, #0x3c8
    b200:	52800020 	mov	w0, #0x1                   	// #1
    b204:	f901e7f5 	str	x21, [sp, #968]
    b208:	f901ebe2 	str	x2, [sp, #976]
    b20c:	97ffe77a 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b210:	91170283 	add	x3, x20, #0x5c0
    b214:	aa0003f5 	mov	x21, x0
    b218:	f949d861 	ldr	x1, [x3, #5040]
    b21c:	f949ec60 	ldr	x0, [x3, #5080]
    b220:	cb0102a1 	sub	x1, x21, x1
    b224:	eb00403f 	cmp	x1, x0, lsl #16
    b228:	54000322 	b.cs	b28c <f0+0x10ec>  // b.hs, b.nlast
    b22c:	d350fc22 	lsr	x2, x1, #16
    b230:	f949fc63 	ldr	x3, [x3, #5112]
    b234:	8b020842 	add	x2, x2, x2, lsl #2
    b238:	d37df042 	lsl	x2, x2, #3
    b23c:	8b020060 	add	x0, x3, x2
    b240:	f9401017 	ldr	x23, [x0, #32]
    b244:	b4000257 	cbz	x23, b28c <f0+0x10ec>
    b248:	38626862 	ldrb	w2, [x3, x2]
    b24c:	7100085f 	cmp	w2, #0x2
    b250:	54009e40 	b.eq	c618 <f0+0x2478>  // b.none
    b254:	7100045f 	cmp	w2, #0x1
    b258:	540001a1 	b.ne	b28c <f0+0x10ec>  // b.any
    b25c:	29430002 	ldp	w2, w0, [x0, #24]
    b260:	92403c21 	and	x1, x1, #0xffff
    b264:	9b027c21 	mul	x1, x1, x2
    b268:	d360fc21 	lsr	x1, x1, #32
    b26c:	eb00003f 	cmp	x1, x0
    b270:	540000e2 	b.cs	b28c <f0+0x10ec>  // b.hs, b.nlast
    b274:	8b0102f7 	add	x23, x23, x1
    b278:	394002e0 	ldrb	w0, [x23]
    b27c:	7103fc1f 	cmp	w0, #0xff
    b280:	5400a560 	b.eq	c72c <f0+0x258c>  // b.none
    b284:	52800020 	mov	w0, #0x1                   	// #1
    b288:	390002e0 	strb	w0, [x23]
    b28c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b290:	910f63e1 	add	x1, sp, #0x3d8
    b294:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b298:	52800020 	mov	w0, #0x1                   	// #1
    b29c:	f901efe2 	str	x2, [sp, #984]
    b2a0:	f901f3f5 	str	x21, [sp, #992]
    b2a4:	97ffe754 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b2a8:	91170283 	add	x3, x20, #0x5c0
    b2ac:	aa0003f5 	mov	x21, x0
    b2b0:	f949d861 	ldr	x1, [x3, #5040]
    b2b4:	f949ec60 	ldr	x0, [x3, #5080]
    b2b8:	cb0102a1 	sub	x1, x21, x1
    b2bc:	eb00403f 	cmp	x1, x0, lsl #16
    b2c0:	54000322 	b.cs	b324 <f0+0x1184>  // b.hs, b.nlast
    b2c4:	d350fc22 	lsr	x2, x1, #16
    b2c8:	f949fc63 	ldr	x3, [x3, #5112]
    b2cc:	8b020842 	add	x2, x2, x2, lsl #2
    b2d0:	d37df042 	lsl	x2, x2, #3
    b2d4:	8b020060 	add	x0, x3, x2
    b2d8:	f9401017 	ldr	x23, [x0, #32]
    b2dc:	b4000257 	cbz	x23, b324 <f0+0x1184>
    b2e0:	38626862 	ldrb	w2, [x3, x2]
    b2e4:	7100085f 	cmp	w2, #0x2
    b2e8:	54009920 	b.eq	c60c <f0+0x246c>  // b.none
    b2ec:	7100045f 	cmp	w2, #0x1
    b2f0:	540001a1 	b.ne	b324 <f0+0x1184>  // b.any
    b2f4:	29430002 	ldp	w2, w0, [x0, #24]
    b2f8:	92403c21 	and	x1, x1, #0xffff
    b2fc:	9b027c21 	mul	x1, x1, x2
    b300:	d360fc21 	lsr	x1, x1, #32
    b304:	eb00003f 	cmp	x1, x0
    b308:	540000e2 	b.cs	b324 <f0+0x1184>  // b.hs, b.nlast
    b30c:	8b0102f7 	add	x23, x23, x1
    b310:	394002e0 	ldrb	w0, [x23]
    b314:	7103fc1f 	cmp	w0, #0xff
    b318:	5400a100 	b.eq	c738 <f0+0x2598>  // b.none
    b31c:	52800020 	mov	w0, #0x1                   	// #1
    b320:	390002e0 	strb	w0, [x23]
    b324:	910fa3e1 	add	x1, sp, #0x3e8
    b328:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b32c:	52800020 	mov	w0, #0x1                   	// #1
    b330:	f901f7f7 	str	x23, [sp, #1000]
    b334:	f901fbf5 	str	x21, [sp, #1008]
    b338:	97ffe72f 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b33c:	97ffe9f1 	bl	5b00 <fwp_rc_fresh>
    b340:	aa0003e2 	mov	x2, x0
    b344:	910fe3e1 	add	x1, sp, #0x3f8
    b348:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b34c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b350:	52800020 	mov	w0, #0x1                   	// #1
    b354:	f901fff5 	str	x21, [sp, #1016]
    b358:	f90203e2 	str	x2, [sp, #1024]
    b35c:	97ffe726 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b360:	97ffe9e8 	bl	5b00 <fwp_rc_fresh>
    b364:	aa0003e2 	mov	x2, x0
    b368:	911023e1 	add	x1, sp, #0x408
    b36c:	52800020 	mov	w0, #0x1                   	// #1
    b370:	f90207f7 	str	x23, [sp, #1032]
    b374:	f9020be2 	str	x2, [sp, #1040]
    b378:	97ffe71f 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b37c:	97ffe9e1 	bl	5b00 <fwp_rc_fresh>
    b380:	aa0003e2 	mov	x2, x0
    b384:	911063e1 	add	x1, sp, #0x418
    b388:	52800020 	mov	w0, #0x1                   	// #1
    b38c:	f9020ff5 	str	x21, [sp, #1048]
    b390:	f90213e2 	str	x2, [sp, #1056]
    b394:	97ffe718 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b398:	91170283 	add	x3, x20, #0x5c0
    b39c:	aa0003f5 	mov	x21, x0
    b3a0:	f949d861 	ldr	x1, [x3, #5040]
    b3a4:	f949ec60 	ldr	x0, [x3, #5080]
    b3a8:	cb0102a1 	sub	x1, x21, x1
    b3ac:	eb00403f 	cmp	x1, x0, lsl #16
    b3b0:	54000322 	b.cs	b414 <f0+0x1274>  // b.hs, b.nlast
    b3b4:	d350fc22 	lsr	x2, x1, #16
    b3b8:	f949fc63 	ldr	x3, [x3, #5112]
    b3bc:	8b020842 	add	x2, x2, x2, lsl #2
    b3c0:	d37df042 	lsl	x2, x2, #3
    b3c4:	8b020060 	add	x0, x3, x2
    b3c8:	f9401017 	ldr	x23, [x0, #32]
    b3cc:	b4000257 	cbz	x23, b414 <f0+0x1274>
    b3d0:	38626862 	ldrb	w2, [x3, x2]
    b3d4:	7100085f 	cmp	w2, #0x2
    b3d8:	540092c0 	b.eq	c630 <f0+0x2490>  // b.none
    b3dc:	7100045f 	cmp	w2, #0x1
    b3e0:	540001a1 	b.ne	b414 <f0+0x1274>  // b.any
    b3e4:	29430002 	ldp	w2, w0, [x0, #24]
    b3e8:	92403c21 	and	x1, x1, #0xffff
    b3ec:	9b027c21 	mul	x1, x1, x2
    b3f0:	d360fc21 	lsr	x1, x1, #32
    b3f4:	eb00003f 	cmp	x1, x0
    b3f8:	540000e2 	b.cs	b414 <f0+0x1274>  // b.hs, b.nlast
    b3fc:	8b0102f7 	add	x23, x23, x1
    b400:	394002e0 	ldrb	w0, [x23]
    b404:	7103fc1f 	cmp	w0, #0xff
    b408:	540099e0 	b.eq	c744 <f0+0x25a4>  // b.none
    b40c:	52800020 	mov	w0, #0x1                   	// #1
    b410:	390002e0 	strb	w0, [x23]
    b414:	9110a3e1 	add	x1, sp, #0x428
    b418:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b41c:	52800020 	mov	w0, #0x1                   	// #1
    b420:	f90217f7 	str	x23, [sp, #1064]
    b424:	f9021bf5 	str	x21, [sp, #1072]
    b428:	97ffe6f3 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b42c:	97ffe9b5 	bl	5b00 <fwp_rc_fresh>
    b430:	aa0003e2 	mov	x2, x0
    b434:	9110e3e1 	add	x1, sp, #0x438
    b438:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b43c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b440:	52800020 	mov	w0, #0x1                   	// #1
    b444:	f9021ff5 	str	x21, [sp, #1080]
    b448:	f90223e2 	str	x2, [sp, #1088]
    b44c:	97ffe6ea 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b450:	97ffe9ac 	bl	5b00 <fwp_rc_fresh>
    b454:	aa0003e2 	mov	x2, x0
    b458:	911123e1 	add	x1, sp, #0x448
    b45c:	52800020 	mov	w0, #0x1                   	// #1
    b460:	f90227f7 	str	x23, [sp, #1096]
    b464:	f9022be2 	str	x2, [sp, #1104]
    b468:	97ffe6e3 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b46c:	97ffe9a5 	bl	5b00 <fwp_rc_fresh>
    b470:	aa0003e2 	mov	x2, x0
    b474:	911163e1 	add	x1, sp, #0x458
    b478:	52800020 	mov	w0, #0x1                   	// #1
    b47c:	f9022ff5 	str	x21, [sp, #1112]
    b480:	f90233e2 	str	x2, [sp, #1120]
    b484:	97ffe6dc 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b488:	97ffe99e 	bl	5b00 <fwp_rc_fresh>
    b48c:	aa0003e2 	mov	x2, x0
    b490:	9111a3e1 	add	x1, sp, #0x468
    b494:	52800020 	mov	w0, #0x1                   	// #1
    b498:	f90237f7 	str	x23, [sp, #1128]
    b49c:	f9023be2 	str	x2, [sp, #1136]
    b4a0:	97ffe6d5 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b4a4:	97ffe997 	bl	5b00 <fwp_rc_fresh>
    b4a8:	aa0003e2 	mov	x2, x0
    b4ac:	9111e3e1 	add	x1, sp, #0x478
    b4b0:	52800020 	mov	w0, #0x1                   	// #1
    b4b4:	f9023ff5 	str	x21, [sp, #1144]
    b4b8:	f90243e2 	str	x2, [sp, #1152]
    b4bc:	97ffe6ce 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b4c0:	91170283 	add	x3, x20, #0x5c0
    b4c4:	aa0003f5 	mov	x21, x0
    b4c8:	f949d861 	ldr	x1, [x3, #5040]
    b4cc:	f949ec60 	ldr	x0, [x3, #5080]
    b4d0:	cb0102a1 	sub	x1, x21, x1
    b4d4:	eb00403f 	cmp	x1, x0, lsl #16
    b4d8:	54000322 	b.cs	b53c <f0+0x139c>  // b.hs, b.nlast
    b4dc:	d350fc22 	lsr	x2, x1, #16
    b4e0:	f949fc63 	ldr	x3, [x3, #5112]
    b4e4:	8b020842 	add	x2, x2, x2, lsl #2
    b4e8:	d37df042 	lsl	x2, x2, #3
    b4ec:	8b020060 	add	x0, x3, x2
    b4f0:	f9401017 	ldr	x23, [x0, #32]
    b4f4:	b4000257 	cbz	x23, b53c <f0+0x139c>
    b4f8:	38626862 	ldrb	w2, [x3, x2]
    b4fc:	7100085f 	cmp	w2, #0x2
    b500:	54008920 	b.eq	c624 <f0+0x2484>  // b.none
    b504:	7100045f 	cmp	w2, #0x1
    b508:	540001a1 	b.ne	b53c <f0+0x139c>  // b.any
    b50c:	29430002 	ldp	w2, w0, [x0, #24]
    b510:	92403c21 	and	x1, x1, #0xffff
    b514:	9b027c21 	mul	x1, x1, x2
    b518:	d360fc21 	lsr	x1, x1, #32
    b51c:	eb00003f 	cmp	x1, x0
    b520:	540000e2 	b.cs	b53c <f0+0x139c>  // b.hs, b.nlast
    b524:	8b0102f7 	add	x23, x23, x1
    b528:	394002e0 	ldrb	w0, [x23]
    b52c:	7103fc1f 	cmp	w0, #0xff
    b530:	54009100 	b.eq	c750 <f0+0x25b0>  // b.none
    b534:	52800020 	mov	w0, #0x1                   	// #1
    b538:	390002e0 	strb	w0, [x23]
    b53c:	911223e1 	add	x1, sp, #0x488
    b540:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b544:	52800020 	mov	w0, #0x1                   	// #1
    b548:	f90247f7 	str	x23, [sp, #1160]
    b54c:	f9024bf5 	str	x21, [sp, #1168]
    b550:	97ffe6a9 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b554:	97ffe96b 	bl	5b00 <fwp_rc_fresh>
    b558:	aa0003e2 	mov	x2, x0
    b55c:	911263e1 	add	x1, sp, #0x498
    b560:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b564:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b568:	52800020 	mov	w0, #0x1                   	// #1
    b56c:	f9024ff5 	str	x21, [sp, #1176]
    b570:	f90253e2 	str	x2, [sp, #1184]
    b574:	97ffe6a0 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b578:	97ffe962 	bl	5b00 <fwp_rc_fresh>
    b57c:	aa0003e2 	mov	x2, x0
    b580:	9112a3e1 	add	x1, sp, #0x4a8
    b584:	52800020 	mov	w0, #0x1                   	// #1
    b588:	f90257f7 	str	x23, [sp, #1192]
    b58c:	f9025be2 	str	x2, [sp, #1200]
    b590:	97ffe699 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b594:	97ffe95b 	bl	5b00 <fwp_rc_fresh>
    b598:	aa0003e2 	mov	x2, x0
    b59c:	9112e3e1 	add	x1, sp, #0x4b8
    b5a0:	52800020 	mov	w0, #0x1                   	// #1
    b5a4:	f9025ff5 	str	x21, [sp, #1208]
    b5a8:	f90263e2 	str	x2, [sp, #1216]
    b5ac:	97ffe692 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b5b0:	97ffe954 	bl	5b00 <fwp_rc_fresh>
    b5b4:	aa0003e2 	mov	x2, x0
    b5b8:	911323e1 	add	x1, sp, #0x4c8
    b5bc:	52800020 	mov	w0, #0x1                   	// #1
    b5c0:	f90267f7 	str	x23, [sp, #1224]
    b5c4:	f9026be2 	str	x2, [sp, #1232]
    b5c8:	97ffe68b 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b5cc:	91170283 	add	x3, x20, #0x5c0
    b5d0:	aa0003f5 	mov	x21, x0
    b5d4:	f949d861 	ldr	x1, [x3, #5040]
    b5d8:	f949ec60 	ldr	x0, [x3, #5080]
    b5dc:	cb0102a1 	sub	x1, x21, x1
    b5e0:	eb00403f 	cmp	x1, x0, lsl #16
    b5e4:	54000322 	b.cs	b648 <f0+0x14a8>  // b.hs, b.nlast
    b5e8:	d350fc22 	lsr	x2, x1, #16
    b5ec:	f949fc63 	ldr	x3, [x3, #5112]
    b5f0:	8b020842 	add	x2, x2, x2, lsl #2
    b5f4:	d37df042 	lsl	x2, x2, #3
    b5f8:	8b020060 	add	x0, x3, x2
    b5fc:	f9401017 	ldr	x23, [x0, #32]
    b600:	b4000257 	cbz	x23, b648 <f0+0x14a8>
    b604:	38626862 	ldrb	w2, [x3, x2]
    b608:	7100085f 	cmp	w2, #0x2
    b60c:	540075e0 	b.eq	c4c8 <f0+0x2328>  // b.none
    b610:	7100045f 	cmp	w2, #0x1
    b614:	540001a1 	b.ne	b648 <f0+0x14a8>  // b.any
    b618:	29430002 	ldp	w2, w0, [x0, #24]
    b61c:	92403c21 	and	x1, x1, #0xffff
    b620:	9b027c21 	mul	x1, x1, x2
    b624:	d360fc21 	lsr	x1, x1, #32
    b628:	eb00003f 	cmp	x1, x0
    b62c:	540000e2 	b.cs	b648 <f0+0x14a8>  // b.hs, b.nlast
    b630:	8b0102f7 	add	x23, x23, x1
    b634:	394002e0 	ldrb	w0, [x23]
    b638:	7103fc1f 	cmp	w0, #0xff
    b63c:	54008900 	b.eq	c75c <f0+0x25bc>  // b.none
    b640:	52800020 	mov	w0, #0x1                   	// #1
    b644:	390002e0 	strb	w0, [x23]
    b648:	911363e1 	add	x1, sp, #0x4d8
    b64c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b650:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b654:	52800020 	mov	w0, #0x1                   	// #1
    b658:	f9026ff7 	str	x23, [sp, #1240]
    b65c:	f90273f5 	str	x21, [sp, #1248]
    b660:	97ffe665 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b664:	97ffe927 	bl	5b00 <fwp_rc_fresh>
    b668:	aa0003e2 	mov	x2, x0
    b66c:	9113a3e1 	add	x1, sp, #0x4e8
    b670:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b674:	52800020 	mov	w0, #0x1                   	// #1
    b678:	f90277f5 	str	x21, [sp, #1256]
    b67c:	f9027be2 	str	x2, [sp, #1264]
    b680:	97ffe65d 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b684:	97ffe91f 	bl	5b00 <fwp_rc_fresh>
    b688:	aa0003e2 	mov	x2, x0
    b68c:	9113e3e1 	add	x1, sp, #0x4f8
    b690:	52800020 	mov	w0, #0x1                   	// #1
    b694:	f9027ff7 	str	x23, [sp, #1272]
    b698:	f90283e2 	str	x2, [sp, #1280]
    b69c:	97ffe656 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b6a0:	97ffe918 	bl	5b00 <fwp_rc_fresh>
    b6a4:	aa0003e2 	mov	x2, x0
    b6a8:	911423e1 	add	x1, sp, #0x508
    b6ac:	52800020 	mov	w0, #0x1                   	// #1
    b6b0:	f90287f5 	str	x21, [sp, #1288]
    b6b4:	f9028be2 	str	x2, [sp, #1296]
    b6b8:	97ffe64f 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b6bc:	97ffe911 	bl	5b00 <fwp_rc_fresh>
    b6c0:	aa0003e2 	mov	x2, x0
    b6c4:	911463e1 	add	x1, sp, #0x518
    b6c8:	52800020 	mov	w0, #0x1                   	// #1
    b6cc:	f9028ff7 	str	x23, [sp, #1304]
    b6d0:	f90293e2 	str	x2, [sp, #1312]
    b6d4:	97ffe648 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b6d8:	97ffe90a 	bl	5b00 <fwp_rc_fresh>
    b6dc:	aa0003e2 	mov	x2, x0
    b6e0:	9114a3e1 	add	x1, sp, #0x528
    b6e4:	52800020 	mov	w0, #0x1                   	// #1
    b6e8:	f90297f5 	str	x21, [sp, #1320]
    b6ec:	f9029be2 	str	x2, [sp, #1328]
    b6f0:	97ffe641 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b6f4:	97ffe903 	bl	5b00 <fwp_rc_fresh>
    b6f8:	aa0003e2 	mov	x2, x0
    b6fc:	9114e3e1 	add	x1, sp, #0x538
    b700:	52800020 	mov	w0, #0x1                   	// #1
    b704:	f9029ff7 	str	x23, [sp, #1336]
    b708:	f902a3e2 	str	x2, [sp, #1344]
    b70c:	97ffe63a 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b710:	97ffe8fc 	bl	5b00 <fwp_rc_fresh>
    b714:	aa0003e2 	mov	x2, x0
    b718:	911523e1 	add	x1, sp, #0x548
    b71c:	52800020 	mov	w0, #0x1                   	// #1
    b720:	f902a7f5 	str	x21, [sp, #1352]
    b724:	f902abe2 	str	x2, [sp, #1360]
    b728:	97ffe633 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b72c:	97ffe8f5 	bl	5b00 <fwp_rc_fresh>
    b730:	aa0003e2 	mov	x2, x0
    b734:	911563e1 	add	x1, sp, #0x558
    b738:	52800020 	mov	w0, #0x1                   	// #1
    b73c:	f902aff7 	str	x23, [sp, #1368]
    b740:	f902b3e2 	str	x2, [sp, #1376]
    b744:	97ffe62c 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b748:	97ffe8ee 	bl	5b00 <fwp_rc_fresh>
    b74c:	aa0003e2 	mov	x2, x0
    b750:	9115a3e1 	add	x1, sp, #0x568
    b754:	52800020 	mov	w0, #0x1                   	// #1
    b758:	f902b7f5 	str	x21, [sp, #1384]
    b75c:	f902bbe2 	str	x2, [sp, #1392]
    b760:	97ffe625 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b764:	97ffe8e7 	bl	5b00 <fwp_rc_fresh>
    b768:	aa0003e2 	mov	x2, x0
    b76c:	9115e3e1 	add	x1, sp, #0x578
    b770:	52800020 	mov	w0, #0x1                   	// #1
    b774:	f902bff7 	str	x23, [sp, #1400]
    b778:	f902c3e2 	str	x2, [sp, #1408]
    b77c:	97ffe61e 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b780:	97ffe8e0 	bl	5b00 <fwp_rc_fresh>
    b784:	aa0003e2 	mov	x2, x0
    b788:	911623e1 	add	x1, sp, #0x588
    b78c:	52800020 	mov	w0, #0x1                   	// #1
    b790:	f902c7f5 	str	x21, [sp, #1416]
    b794:	f902cbe2 	str	x2, [sp, #1424]
    b798:	97ffe617 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b79c:	97ffe8d9 	bl	5b00 <fwp_rc_fresh>
    b7a0:	aa0003e2 	mov	x2, x0
    b7a4:	911663e1 	add	x1, sp, #0x598
    b7a8:	52800020 	mov	w0, #0x1                   	// #1
    b7ac:	f902cff7 	str	x23, [sp, #1432]
    b7b0:	f902d3e2 	str	x2, [sp, #1440]
    b7b4:	97ffe610 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b7b8:	97ffe8d2 	bl	5b00 <fwp_rc_fresh>
    b7bc:	aa0003e2 	mov	x2, x0
    b7c0:	9116a3e1 	add	x1, sp, #0x5a8
    b7c4:	52800020 	mov	w0, #0x1                   	// #1
    b7c8:	f902d7f5 	str	x21, [sp, #1448]
    b7cc:	f902dbe2 	str	x2, [sp, #1456]
    b7d0:	97ffe609 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b7d4:	97ffe8cb 	bl	5b00 <fwp_rc_fresh>
    b7d8:	aa0003e2 	mov	x2, x0
    b7dc:	9116e3e1 	add	x1, sp, #0x5b8
    b7e0:	52800020 	mov	w0, #0x1                   	// #1
    b7e4:	f902dff7 	str	x23, [sp, #1464]
    b7e8:	f902e3e2 	str	x2, [sp, #1472]
    b7ec:	97ffe602 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b7f0:	97ffe8c4 	bl	5b00 <fwp_rc_fresh>
    b7f4:	aa0003e2 	mov	x2, x0
    b7f8:	911723e1 	add	x1, sp, #0x5c8
    b7fc:	52800020 	mov	w0, #0x1                   	// #1
    b800:	f902e7f5 	str	x21, [sp, #1480]
    b804:	f902ebe2 	str	x2, [sp, #1488]
    b808:	97ffe5fb 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b80c:	91170283 	add	x3, x20, #0x5c0
    b810:	aa0003f5 	mov	x21, x0
    b814:	f949d861 	ldr	x1, [x3, #5040]
    b818:	f949ec60 	ldr	x0, [x3, #5080]
    b81c:	cb0102a1 	sub	x1, x21, x1
    b820:	eb00403f 	cmp	x1, x0, lsl #16
    b824:	54000322 	b.cs	b888 <f0+0x16e8>  // b.hs, b.nlast
    b828:	d350fc22 	lsr	x2, x1, #16
    b82c:	f949fc63 	ldr	x3, [x3, #5112]
    b830:	8b020842 	add	x2, x2, x2, lsl #2
    b834:	d37df042 	lsl	x2, x2, #3
    b838:	8b020060 	add	x0, x3, x2
    b83c:	f9401017 	ldr	x23, [x0, #32]
    b840:	b4000257 	cbz	x23, b888 <f0+0x16e8>
    b844:	38626862 	ldrb	w2, [x3, x2]
    b848:	7100085f 	cmp	w2, #0x2
    b84c:	54006380 	b.eq	c4bc <f0+0x231c>  // b.none
    b850:	7100045f 	cmp	w2, #0x1
    b854:	540001a1 	b.ne	b888 <f0+0x16e8>  // b.any
    b858:	29430002 	ldp	w2, w0, [x0, #24]
    b85c:	92403c21 	and	x1, x1, #0xffff
    b860:	9b027c21 	mul	x1, x1, x2
    b864:	d360fc21 	lsr	x1, x1, #32
    b868:	eb00003f 	cmp	x1, x0
    b86c:	540000e2 	b.cs	b888 <f0+0x16e8>  // b.hs, b.nlast
    b870:	8b0102f7 	add	x23, x23, x1
    b874:	394002e0 	ldrb	w0, [x23]
    b878:	7103fc1f 	cmp	w0, #0xff
    b87c:	54007760 	b.eq	c768 <f0+0x25c8>  // b.none
    b880:	52800020 	mov	w0, #0x1                   	// #1
    b884:	390002e0 	strb	w0, [x23]
    b888:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b88c:	911763e1 	add	x1, sp, #0x5d8
    b890:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b894:	52800020 	mov	w0, #0x1                   	// #1
    b898:	f902efe2 	str	x2, [sp, #1496]
    b89c:	f902f3f5 	str	x21, [sp, #1504]
    b8a0:	97ffe5d5 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b8a4:	91170283 	add	x3, x20, #0x5c0
    b8a8:	aa0003f5 	mov	x21, x0
    b8ac:	f949d861 	ldr	x1, [x3, #5040]
    b8b0:	f949ec60 	ldr	x0, [x3, #5080]
    b8b4:	cb0102a1 	sub	x1, x21, x1
    b8b8:	eb00403f 	cmp	x1, x0, lsl #16
    b8bc:	54000322 	b.cs	b920 <f0+0x1780>  // b.hs, b.nlast
    b8c0:	d350fc22 	lsr	x2, x1, #16
    b8c4:	f949fc63 	ldr	x3, [x3, #5112]
    b8c8:	8b020842 	add	x2, x2, x2, lsl #2
    b8cc:	d37df042 	lsl	x2, x2, #3
    b8d0:	8b020060 	add	x0, x3, x2
    b8d4:	f9401017 	ldr	x23, [x0, #32]
    b8d8:	b4000257 	cbz	x23, b920 <f0+0x1780>
    b8dc:	38626862 	ldrb	w2, [x3, x2]
    b8e0:	7100085f 	cmp	w2, #0x2
    b8e4:	54005fe0 	b.eq	c4e0 <f0+0x2340>  // b.none
    b8e8:	7100045f 	cmp	w2, #0x1
    b8ec:	540001a1 	b.ne	b920 <f0+0x1780>  // b.any
    b8f0:	29430002 	ldp	w2, w0, [x0, #24]
    b8f4:	92403c21 	and	x1, x1, #0xffff
    b8f8:	9b027c21 	mul	x1, x1, x2
    b8fc:	d360fc21 	lsr	x1, x1, #32
    b900:	eb00003f 	cmp	x1, x0
    b904:	540000e2 	b.cs	b920 <f0+0x1780>  // b.hs, b.nlast
    b908:	8b0102f7 	add	x23, x23, x1
    b90c:	394002e0 	ldrb	w0, [x23]
    b910:	7103fc1f 	cmp	w0, #0xff
    b914:	54007300 	b.eq	c774 <f0+0x25d4>  // b.none
    b918:	52800020 	mov	w0, #0x1                   	// #1
    b91c:	390002e0 	strb	w0, [x23]
    b920:	9117a3e1 	add	x1, sp, #0x5e8
    b924:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b928:	52800020 	mov	w0, #0x1                   	// #1
    b92c:	f902f7f7 	str	x23, [sp, #1512]
    b930:	f902fbf5 	str	x21, [sp, #1520]
    b934:	97ffe5b0 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b938:	97ffe872 	bl	5b00 <fwp_rc_fresh>
    b93c:	aa0003e2 	mov	x2, x0
    b940:	9117e3e1 	add	x1, sp, #0x5f8
    b944:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b948:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b94c:	52800020 	mov	w0, #0x1                   	// #1
    b950:	f902fff5 	str	x21, [sp, #1528]
    b954:	f90303e2 	str	x2, [sp, #1536]
    b958:	97ffe5a7 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b95c:	97ffe869 	bl	5b00 <fwp_rc_fresh>
    b960:	aa0003e2 	mov	x2, x0
    b964:	911823e1 	add	x1, sp, #0x608
    b968:	52800020 	mov	w0, #0x1                   	// #1
    b96c:	f90307f7 	str	x23, [sp, #1544]
    b970:	f9030be2 	str	x2, [sp, #1552]
    b974:	97ffe5a0 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b978:	97ffe862 	bl	5b00 <fwp_rc_fresh>
    b97c:	aa0003e2 	mov	x2, x0
    b980:	911863e1 	add	x1, sp, #0x618
    b984:	52800020 	mov	w0, #0x1                   	// #1
    b988:	f9030ff5 	str	x21, [sp, #1560]
    b98c:	f90313e2 	str	x2, [sp, #1568]
    b990:	97ffe599 	bl	4ff4 <fwp_data.part.0.constprop.0>
    b994:	91170283 	add	x3, x20, #0x5c0
    b998:	aa0003f5 	mov	x21, x0
    b99c:	f949d861 	ldr	x1, [x3, #5040]
    b9a0:	f949ec60 	ldr	x0, [x3, #5080]
    b9a4:	cb0102a1 	sub	x1, x21, x1
    b9a8:	eb00403f 	cmp	x1, x0, lsl #16
    b9ac:	54000322 	b.cs	ba10 <f0+0x1870>  // b.hs, b.nlast
    b9b0:	d350fc22 	lsr	x2, x1, #16
    b9b4:	f949fc63 	ldr	x3, [x3, #5112]
    b9b8:	8b020842 	add	x2, x2, x2, lsl #2
    b9bc:	d37df042 	lsl	x2, x2, #3
    b9c0:	8b020060 	add	x0, x3, x2
    b9c4:	f9401017 	ldr	x23, [x0, #32]
    b9c8:	b4000257 	cbz	x23, ba10 <f0+0x1870>
    b9cc:	38626862 	ldrb	w2, [x3, x2]
    b9d0:	7100085f 	cmp	w2, #0x2
    b9d4:	54005800 	b.eq	c4d4 <f0+0x2334>  // b.none
    b9d8:	7100045f 	cmp	w2, #0x1
    b9dc:	540001a1 	b.ne	ba10 <f0+0x1870>  // b.any
    b9e0:	29430002 	ldp	w2, w0, [x0, #24]
    b9e4:	92403c21 	and	x1, x1, #0xffff
    b9e8:	9b027c21 	mul	x1, x1, x2
    b9ec:	d360fc21 	lsr	x1, x1, #32
    b9f0:	eb00003f 	cmp	x1, x0
    b9f4:	540000e2 	b.cs	ba10 <f0+0x1870>  // b.hs, b.nlast
    b9f8:	8b0102f7 	add	x23, x23, x1
    b9fc:	394002e0 	ldrb	w0, [x23]
    ba00:	7103fc1f 	cmp	w0, #0xff
    ba04:	54006be0 	b.eq	c780 <f0+0x25e0>  // b.none
    ba08:	52800020 	mov	w0, #0x1                   	// #1
    ba0c:	390002e0 	strb	w0, [x23]
    ba10:	9118a3e1 	add	x1, sp, #0x628
    ba14:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ba18:	52800020 	mov	w0, #0x1                   	// #1
    ba1c:	f90317f7 	str	x23, [sp, #1576]
    ba20:	f9031bf5 	str	x21, [sp, #1584]
    ba24:	97ffe574 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ba28:	97ffe836 	bl	5b00 <fwp_rc_fresh>
    ba2c:	aa0003e2 	mov	x2, x0
    ba30:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ba34:	9118e3e1 	add	x1, sp, #0x638
    ba38:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ba3c:	52800020 	mov	w0, #0x1                   	// #1
    ba40:	f9031fe3 	str	x3, [sp, #1592]
    ba44:	f90323e2 	str	x2, [sp, #1600]
    ba48:	97ffe56b 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ba4c:	97ffe82d 	bl	5b00 <fwp_rc_fresh>
    ba50:	aa0003e2 	mov	x2, x0
    ba54:	911923e1 	add	x1, sp, #0x648
    ba58:	52800020 	mov	w0, #0x1                   	// #1
    ba5c:	f90327f7 	str	x23, [sp, #1608]
    ba60:	f9032be2 	str	x2, [sp, #1616]
    ba64:	97ffe564 	bl	4ff4 <fwp_data.part.0.constprop.0>
    ba68:	91170283 	add	x3, x20, #0x5c0
    ba6c:	aa0003f5 	mov	x21, x0
    ba70:	f949d861 	ldr	x1, [x3, #5040]
    ba74:	f949ec60 	ldr	x0, [x3, #5080]
    ba78:	cb0102a1 	sub	x1, x21, x1
    ba7c:	eb00403f 	cmp	x1, x0, lsl #16
    ba80:	54000322 	b.cs	bae4 <f0+0x1944>  // b.hs, b.nlast
    ba84:	d350fc22 	lsr	x2, x1, #16
    ba88:	f949fc63 	ldr	x3, [x3, #5112]
    ba8c:	8b020842 	add	x2, x2, x2, lsl #2
    ba90:	d37df042 	lsl	x2, x2, #3
    ba94:	8b020060 	add	x0, x3, x2
    ba98:	f9401017 	ldr	x23, [x0, #32]
    ba9c:	b4000257 	cbz	x23, bae4 <f0+0x1944>
    baa0:	38626862 	ldrb	w2, [x3, x2]
    baa4:	7100085f 	cmp	w2, #0x2
    baa8:	54005280 	b.eq	c4f8 <f0+0x2358>  // b.none
    baac:	7100045f 	cmp	w2, #0x1
    bab0:	540001a1 	b.ne	bae4 <f0+0x1944>  // b.any
    bab4:	29430002 	ldp	w2, w0, [x0, #24]
    bab8:	92403c21 	and	x1, x1, #0xffff
    babc:	9b027c21 	mul	x1, x1, x2
    bac0:	d360fc21 	lsr	x1, x1, #32
    bac4:	eb00003f 	cmp	x1, x0
    bac8:	540000e2 	b.cs	bae4 <f0+0x1944>  // b.hs, b.nlast
    bacc:	8b0102f7 	add	x23, x23, x1
    bad0:	394002e0 	ldrb	w0, [x23]
    bad4:	7103fc1f 	cmp	w0, #0xff
    bad8:	540065a0 	b.eq	c78c <f0+0x25ec>  // b.none
    badc:	52800020 	mov	w0, #0x1                   	// #1
    bae0:	390002e0 	strb	w0, [x23]
    bae4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bae8:	911963e1 	add	x1, sp, #0x658
    baec:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    baf0:	52800020 	mov	w0, #0x1                   	// #1
    baf4:	f9032fe2 	str	x2, [sp, #1624]
    baf8:	f90333f5 	str	x21, [sp, #1632]
    bafc:	97ffe53e 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bb00:	91170283 	add	x3, x20, #0x5c0
    bb04:	aa0003f5 	mov	x21, x0
    bb08:	f949d861 	ldr	x1, [x3, #5040]
    bb0c:	f949ec60 	ldr	x0, [x3, #5080]
    bb10:	cb0102a1 	sub	x1, x21, x1
    bb14:	eb00403f 	cmp	x1, x0, lsl #16
    bb18:	54000322 	b.cs	bb7c <f0+0x19dc>  // b.hs, b.nlast
    bb1c:	d350fc22 	lsr	x2, x1, #16
    bb20:	f949fc63 	ldr	x3, [x3, #5112]
    bb24:	8b020842 	add	x2, x2, x2, lsl #2
    bb28:	d37df042 	lsl	x2, x2, #3
    bb2c:	8b020060 	add	x0, x3, x2
    bb30:	f9401017 	ldr	x23, [x0, #32]
    bb34:	b4000257 	cbz	x23, bb7c <f0+0x19dc>
    bb38:	38626862 	ldrb	w2, [x3, x2]
    bb3c:	7100085f 	cmp	w2, #0x2
    bb40:	54004d60 	b.eq	c4ec <f0+0x234c>  // b.none
    bb44:	7100045f 	cmp	w2, #0x1
    bb48:	540001a1 	b.ne	bb7c <f0+0x19dc>  // b.any
    bb4c:	29430002 	ldp	w2, w0, [x0, #24]
    bb50:	92403c21 	and	x1, x1, #0xffff
    bb54:	9b027c21 	mul	x1, x1, x2
    bb58:	d360fc21 	lsr	x1, x1, #32
    bb5c:	eb00003f 	cmp	x1, x0
    bb60:	540000e2 	b.cs	bb7c <f0+0x19dc>  // b.hs, b.nlast
    bb64:	8b0102f7 	add	x23, x23, x1
    bb68:	394002e0 	ldrb	w0, [x23]
    bb6c:	7103fc1f 	cmp	w0, #0xff
    bb70:	54006140 	b.eq	c798 <f0+0x25f8>  // b.none
    bb74:	52800020 	mov	w0, #0x1                   	// #1
    bb78:	390002e0 	strb	w0, [x23]
    bb7c:	9119a3e1 	add	x1, sp, #0x668
    bb80:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bb84:	52800020 	mov	w0, #0x1                   	// #1
    bb88:	f90337f7 	str	x23, [sp, #1640]
    bb8c:	f9033bf5 	str	x21, [sp, #1648]
    bb90:	97ffe519 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bb94:	97ffe7db 	bl	5b00 <fwp_rc_fresh>
    bb98:	aa0003e2 	mov	x2, x0
    bb9c:	9119e3e1 	add	x1, sp, #0x678
    bba0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bba4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bba8:	52800020 	mov	w0, #0x1                   	// #1
    bbac:	f9033ff5 	str	x21, [sp, #1656]
    bbb0:	f90343e2 	str	x2, [sp, #1664]
    bbb4:	97ffe510 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bbb8:	97ffe7d2 	bl	5b00 <fwp_rc_fresh>
    bbbc:	aa0003e2 	mov	x2, x0
    bbc0:	911a23e1 	add	x1, sp, #0x688
    bbc4:	52800020 	mov	w0, #0x1                   	// #1
    bbc8:	f90347f7 	str	x23, [sp, #1672]
    bbcc:	f9034be2 	str	x2, [sp, #1680]
    bbd0:	97ffe509 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bbd4:	97ffe7cb 	bl	5b00 <fwp_rc_fresh>
    bbd8:	aa0003e2 	mov	x2, x0
    bbdc:	911a63e1 	add	x1, sp, #0x698
    bbe0:	52800020 	mov	w0, #0x1                   	// #1
    bbe4:	f9034ff5 	str	x21, [sp, #1688]
    bbe8:	f90353e2 	str	x2, [sp, #1696]
    bbec:	97ffe502 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bbf0:	91170283 	add	x3, x20, #0x5c0
    bbf4:	aa0003f5 	mov	x21, x0
    bbf8:	f949d861 	ldr	x1, [x3, #5040]
    bbfc:	f949ec60 	ldr	x0, [x3, #5080]
    bc00:	cb0102a1 	sub	x1, x21, x1
    bc04:	eb00403f 	cmp	x1, x0, lsl #16
    bc08:	54000322 	b.cs	bc6c <f0+0x1acc>  // b.hs, b.nlast
    bc0c:	d350fc22 	lsr	x2, x1, #16
    bc10:	f949fc63 	ldr	x3, [x3, #5112]
    bc14:	8b020842 	add	x2, x2, x2, lsl #2
    bc18:	d37df042 	lsl	x2, x2, #3
    bc1c:	8b020060 	add	x0, x3, x2
    bc20:	f9401017 	ldr	x23, [x0, #32]
    bc24:	b4000257 	cbz	x23, bc6c <f0+0x1acc>
    bc28:	38626862 	ldrb	w2, [x3, x2]
    bc2c:	7100085f 	cmp	w2, #0x2
    bc30:	54004700 	b.eq	c510 <f0+0x2370>  // b.none
    bc34:	7100045f 	cmp	w2, #0x1
    bc38:	540001a1 	b.ne	bc6c <f0+0x1acc>  // b.any
    bc3c:	29430002 	ldp	w2, w0, [x0, #24]
    bc40:	92403c21 	and	x1, x1, #0xffff
    bc44:	9b027c21 	mul	x1, x1, x2
    bc48:	d360fc21 	lsr	x1, x1, #32
    bc4c:	eb00003f 	cmp	x1, x0
    bc50:	540000e2 	b.cs	bc6c <f0+0x1acc>  // b.hs, b.nlast
    bc54:	8b0102f7 	add	x23, x23, x1
    bc58:	394002e0 	ldrb	w0, [x23]
    bc5c:	7103fc1f 	cmp	w0, #0xff
    bc60:	54005a20 	b.eq	c7a4 <f0+0x2604>  // b.none
    bc64:	52800020 	mov	w0, #0x1                   	// #1
    bc68:	390002e0 	strb	w0, [x23]
    bc6c:	911aa3e1 	add	x1, sp, #0x6a8
    bc70:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bc74:	52800020 	mov	w0, #0x1                   	// #1
    bc78:	f90357e2 	str	x2, [sp, #1704]
    bc7c:	f9035bf5 	str	x21, [sp, #1712]
    bc80:	97ffe4dd 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bc84:	97ffe79f 	bl	5b00 <fwp_rc_fresh>
    bc88:	aa0003e2 	mov	x2, x0
    bc8c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bc90:	911ae3e1 	add	x1, sp, #0x6b8
    bc94:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bc98:	52800020 	mov	w0, #0x1                   	// #1
    bc9c:	f9035fe3 	str	x3, [sp, #1720]
    bca0:	f90363e2 	str	x2, [sp, #1728]
    bca4:	97ffe4d4 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bca8:	91170283 	add	x3, x20, #0x5c0
    bcac:	aa0003f5 	mov	x21, x0
    bcb0:	f949d861 	ldr	x1, [x3, #5040]
    bcb4:	f949ec60 	ldr	x0, [x3, #5080]
    bcb8:	cb0102a1 	sub	x1, x21, x1
    bcbc:	eb00403f 	cmp	x1, x0, lsl #16
    bcc0:	54000322 	b.cs	bd24 <f0+0x1b84>  // b.hs, b.nlast
    bcc4:	d350fc22 	lsr	x2, x1, #16
    bcc8:	f949fc63 	ldr	x3, [x3, #5112]
    bccc:	8b020842 	add	x2, x2, x2, lsl #2
    bcd0:	d37df042 	lsl	x2, x2, #3
    bcd4:	8b020060 	add	x0, x3, x2
    bcd8:	f9401017 	ldr	x23, [x0, #32]
    bcdc:	b4000257 	cbz	x23, bd24 <f0+0x1b84>
    bce0:	38626862 	ldrb	w2, [x3, x2]
    bce4:	7100085f 	cmp	w2, #0x2
    bce8:	540040e0 	b.eq	c504 <f0+0x2364>  // b.none
    bcec:	7100045f 	cmp	w2, #0x1
    bcf0:	540001a1 	b.ne	bd24 <f0+0x1b84>  // b.any
    bcf4:	29430002 	ldp	w2, w0, [x0, #24]
    bcf8:	92403c21 	and	x1, x1, #0xffff
    bcfc:	9b027c21 	mul	x1, x1, x2
    bd00:	d360fc21 	lsr	x1, x1, #32
    bd04:	eb00003f 	cmp	x1, x0
    bd08:	540000e2 	b.cs	bd24 <f0+0x1b84>  // b.hs, b.nlast
    bd0c:	8b0102f7 	add	x23, x23, x1
    bd10:	394002e0 	ldrb	w0, [x23]
    bd14:	7103fc1f 	cmp	w0, #0xff
    bd18:	540054c0 	b.eq	c7b0 <f0+0x2610>  // b.none
    bd1c:	52800020 	mov	w0, #0x1                   	// #1
    bd20:	390002e0 	strb	w0, [x23]
    bd24:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bd28:	911b23e1 	add	x1, sp, #0x6c8
    bd2c:	52800020 	mov	w0, #0x1                   	// #1
    bd30:	f90367e2 	str	x2, [sp, #1736]
    bd34:	f9036bf5 	str	x21, [sp, #1744]
    bd38:	97ffe4af 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bd3c:	91170283 	add	x3, x20, #0x5c0
    bd40:	aa0003f5 	mov	x21, x0
    bd44:	f949d861 	ldr	x1, [x3, #5040]
    bd48:	f949ec60 	ldr	x0, [x3, #5080]
    bd4c:	cb0102a1 	sub	x1, x21, x1
    bd50:	eb00403f 	cmp	x1, x0, lsl #16
    bd54:	54000322 	b.cs	bdb8 <f0+0x1c18>  // b.hs, b.nlast
    bd58:	d350fc22 	lsr	x2, x1, #16
    bd5c:	f949fc63 	ldr	x3, [x3, #5112]
    bd60:	8b020842 	add	x2, x2, x2, lsl #2
    bd64:	d37df042 	lsl	x2, x2, #3
    bd68:	8b020060 	add	x0, x3, x2
    bd6c:	f9401017 	ldr	x23, [x0, #32]
    bd70:	b4000257 	cbz	x23, bdb8 <f0+0x1c18>
    bd74:	38626862 	ldrb	w2, [x3, x2]
    bd78:	7100085f 	cmp	w2, #0x2
    bd7c:	54003d60 	b.eq	c528 <f0+0x2388>  // b.none
    bd80:	7100045f 	cmp	w2, #0x1
    bd84:	540001a1 	b.ne	bdb8 <f0+0x1c18>  // b.any
    bd88:	29430002 	ldp	w2, w0, [x0, #24]
    bd8c:	92403c21 	and	x1, x1, #0xffff
    bd90:	9b027c21 	mul	x1, x1, x2
    bd94:	d360fc21 	lsr	x1, x1, #32
    bd98:	eb00003f 	cmp	x1, x0
    bd9c:	540000e2 	b.cs	bdb8 <f0+0x1c18>  // b.hs, b.nlast
    bda0:	8b0102f7 	add	x23, x23, x1
    bda4:	394002e0 	ldrb	w0, [x23]
    bda8:	7103fc1f 	cmp	w0, #0xff
    bdac:	54005080 	b.eq	c7bc <f0+0x261c>  // b.none
    bdb0:	52800020 	mov	w0, #0x1                   	// #1
    bdb4:	390002e0 	strb	w0, [x23]
    bdb8:	911b63e1 	add	x1, sp, #0x6d8
    bdbc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bdc0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bdc4:	52800020 	mov	w0, #0x1                   	// #1
    bdc8:	f9036ff7 	str	x23, [sp, #1752]
    bdcc:	f90373f5 	str	x21, [sp, #1760]
    bdd0:	97ffe489 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bdd4:	97ffe74b 	bl	5b00 <fwp_rc_fresh>
    bdd8:	aa0003e2 	mov	x2, x0
    bddc:	911ba3e1 	add	x1, sp, #0x6e8
    bde0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bde4:	52800020 	mov	w0, #0x1                   	// #1
    bde8:	f90377f5 	str	x21, [sp, #1768]
    bdec:	f9037be2 	str	x2, [sp, #1776]
    bdf0:	97ffe481 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bdf4:	97ffe743 	bl	5b00 <fwp_rc_fresh>
    bdf8:	aa0003e2 	mov	x2, x0
    bdfc:	911be3e1 	add	x1, sp, #0x6f8
    be00:	52800020 	mov	w0, #0x1                   	// #1
    be04:	f9037ff7 	str	x23, [sp, #1784]
    be08:	f90383e2 	str	x2, [sp, #1792]
    be0c:	97ffe47a 	bl	4ff4 <fwp_data.part.0.constprop.0>
    be10:	97ffe73c 	bl	5b00 <fwp_rc_fresh>
    be14:	aa0003e2 	mov	x2, x0
    be18:	911c23e1 	add	x1, sp, #0x708
    be1c:	52800020 	mov	w0, #0x1                   	// #1
    be20:	f90387f5 	str	x21, [sp, #1800]
    be24:	f9038be2 	str	x2, [sp, #1808]
    be28:	97ffe473 	bl	4ff4 <fwp_data.part.0.constprop.0>
    be2c:	97ffe735 	bl	5b00 <fwp_rc_fresh>
    be30:	aa0003e2 	mov	x2, x0
    be34:	911c63e1 	add	x1, sp, #0x718
    be38:	52800020 	mov	w0, #0x1                   	// #1
    be3c:	f9038ff7 	str	x23, [sp, #1816]
    be40:	f90393e2 	str	x2, [sp, #1824]
    be44:	97ffe46c 	bl	4ff4 <fwp_data.part.0.constprop.0>
    be48:	91170283 	add	x3, x20, #0x5c0
    be4c:	aa0003f5 	mov	x21, x0
    be50:	f949d861 	ldr	x1, [x3, #5040]
    be54:	f949ec60 	ldr	x0, [x3, #5080]
    be58:	cb0102a1 	sub	x1, x21, x1
    be5c:	eb00403f 	cmp	x1, x0, lsl #16
    be60:	54000322 	b.cs	bec4 <f0+0x1d24>  // b.hs, b.nlast
    be64:	d350fc22 	lsr	x2, x1, #16
    be68:	f949fc63 	ldr	x3, [x3, #5112]
    be6c:	8b020842 	add	x2, x2, x2, lsl #2
    be70:	d37df042 	lsl	x2, x2, #3
    be74:	8b020060 	add	x0, x3, x2
    be78:	f9401017 	ldr	x23, [x0, #32]
    be7c:	b4000257 	cbz	x23, bec4 <f0+0x1d24>
    be80:	38626862 	ldrb	w2, [x3, x2]
    be84:	7100085f 	cmp	w2, #0x2
    be88:	540034a0 	b.eq	c51c <f0+0x237c>  // b.none
    be8c:	7100045f 	cmp	w2, #0x1
    be90:	540001a1 	b.ne	bec4 <f0+0x1d24>  // b.any
    be94:	29430002 	ldp	w2, w0, [x0, #24]
    be98:	92403c21 	and	x1, x1, #0xffff
    be9c:	9b027c21 	mul	x1, x1, x2
    bea0:	d360fc21 	lsr	x1, x1, #32
    bea4:	eb00003f 	cmp	x1, x0
    bea8:	540000e2 	b.cs	bec4 <f0+0x1d24>  // b.hs, b.nlast
    beac:	8b0102f7 	add	x23, x23, x1
    beb0:	394002e0 	ldrb	w0, [x23]
    beb4:	7103fc1f 	cmp	w0, #0xff
    beb8:	54004880 	b.eq	c7c8 <f0+0x2628>  // b.none
    bebc:	52800020 	mov	w0, #0x1                   	// #1
    bec0:	390002e0 	strb	w0, [x23]
    bec4:	911ca3e1 	add	x1, sp, #0x728
    bec8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    becc:	52800020 	mov	w0, #0x1                   	// #1
    bed0:	f90397f7 	str	x23, [sp, #1832]
    bed4:	f9039bf5 	str	x21, [sp, #1840]
    bed8:	97ffe447 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bedc:	97ffe709 	bl	5b00 <fwp_rc_fresh>
    bee0:	aa0003e2 	mov	x2, x0
    bee4:	911ce3e1 	add	x1, sp, #0x738
    bee8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    beec:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bef0:	52800020 	mov	w0, #0x1                   	// #1
    bef4:	f9039ff5 	str	x21, [sp, #1848]
    bef8:	f903a3e2 	str	x2, [sp, #1856]
    befc:	97ffe43e 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bf00:	97ffe700 	bl	5b00 <fwp_rc_fresh>
    bf04:	aa0003e2 	mov	x2, x0
    bf08:	911d23e1 	add	x1, sp, #0x748
    bf0c:	52800020 	mov	w0, #0x1                   	// #1
    bf10:	f903a7f7 	str	x23, [sp, #1864]
    bf14:	f903abe2 	str	x2, [sp, #1872]
    bf18:	97ffe437 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bf1c:	97ffe6f9 	bl	5b00 <fwp_rc_fresh>
    bf20:	aa0003e2 	mov	x2, x0
    bf24:	911d63e1 	add	x1, sp, #0x758
    bf28:	52800020 	mov	w0, #0x1                   	// #1
    bf2c:	f903aff5 	str	x21, [sp, #1880]
    bf30:	f903b3e2 	str	x2, [sp, #1888]
    bf34:	97ffe430 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bf38:	97ffe6f2 	bl	5b00 <fwp_rc_fresh>
    bf3c:	aa0003e2 	mov	x2, x0
    bf40:	911da3e1 	add	x1, sp, #0x768
    bf44:	52800020 	mov	w0, #0x1                   	// #1
    bf48:	f903b7f7 	str	x23, [sp, #1896]
    bf4c:	f903bbe2 	str	x2, [sp, #1904]
    bf50:	97ffe429 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bf54:	97ffe6eb 	bl	5b00 <fwp_rc_fresh>
    bf58:	aa0003e2 	mov	x2, x0
    bf5c:	911de3e1 	add	x1, sp, #0x778
    bf60:	52800020 	mov	w0, #0x1                   	// #1
    bf64:	f903bff5 	str	x21, [sp, #1912]
    bf68:	f903c3e2 	str	x2, [sp, #1920]
    bf6c:	97ffe422 	bl	4ff4 <fwp_data.part.0.constprop.0>
    bf70:	91170283 	add	x3, x20, #0x5c0
    bf74:	aa0003f5 	mov	x21, x0
    bf78:	f949d861 	ldr	x1, [x3, #5040]
    bf7c:	f949ec60 	ldr	x0, [x3, #5080]
    bf80:	cb0102a1 	sub	x1, x21, x1
    bf84:	eb00403f 	cmp	x1, x0, lsl #16
    bf88:	54000322 	b.cs	bfec <f0+0x1e4c>  // b.hs, b.nlast
    bf8c:	d350fc22 	lsr	x2, x1, #16
    bf90:	f949fc63 	ldr	x3, [x3, #5112]
    bf94:	8b020842 	add	x2, x2, x2, lsl #2
    bf98:	d37df042 	lsl	x2, x2, #3
    bf9c:	8b020060 	add	x0, x3, x2
    bfa0:	f9401017 	ldr	x23, [x0, #32]
    bfa4:	b4000257 	cbz	x23, bfec <f0+0x1e4c>
    bfa8:	38626862 	ldrb	w2, [x3, x2]
    bfac:	7100085f 	cmp	w2, #0x2
    bfb0:	54002c80 	b.eq	c540 <f0+0x23a0>  // b.none
    bfb4:	7100045f 	cmp	w2, #0x1
    bfb8:	540001a1 	b.ne	bfec <f0+0x1e4c>  // b.any
    bfbc:	29430002 	ldp	w2, w0, [x0, #24]
    bfc0:	92403c21 	and	x1, x1, #0xffff
    bfc4:	9b027c21 	mul	x1, x1, x2
    bfc8:	d360fc21 	lsr	x1, x1, #32
    bfcc:	eb00003f 	cmp	x1, x0
    bfd0:	540000e2 	b.cs	bfec <f0+0x1e4c>  // b.hs, b.nlast
    bfd4:	8b0102f7 	add	x23, x23, x1
    bfd8:	394002e0 	ldrb	w0, [x23]
    bfdc:	7103fc1f 	cmp	w0, #0xff
    bfe0:	54003fa0 	b.eq	c7d4 <f0+0x2634>  // b.none
    bfe4:	52800020 	mov	w0, #0x1                   	// #1
    bfe8:	390002e0 	strb	w0, [x23]
    bfec:	911e23e1 	add	x1, sp, #0x788
    bff0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bff4:	52800020 	mov	w0, #0x1                   	// #1
    bff8:	f903c7f7 	str	x23, [sp, #1928]
    bffc:	f903cbf5 	str	x21, [sp, #1936]
    c000:	97ffe3fd 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c004:	97ffe6bf 	bl	5b00 <fwp_rc_fresh>
    c008:	aa0003e2 	mov	x2, x0
    c00c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c010:	911e63e1 	add	x1, sp, #0x798
    c014:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c018:	52800020 	mov	w0, #0x1                   	// #1
    c01c:	f903cfe3 	str	x3, [sp, #1944]
    c020:	f903d3e2 	str	x2, [sp, #1952]
    c024:	97ffe3f4 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c028:	97ffe6b6 	bl	5b00 <fwp_rc_fresh>
    c02c:	aa0003e2 	mov	x2, x0
    c030:	911ea3e1 	add	x1, sp, #0x7a8
    c034:	52800020 	mov	w0, #0x1                   	// #1
    c038:	f903d7f7 	str	x23, [sp, #1960]
    c03c:	f903dbe2 	str	x2, [sp, #1968]
    c040:	97ffe3ed 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c044:	91170283 	add	x3, x20, #0x5c0
    c048:	aa0003f5 	mov	x21, x0
    c04c:	f949d861 	ldr	x1, [x3, #5040]
    c050:	f949ec60 	ldr	x0, [x3, #5080]
    c054:	cb0102a1 	sub	x1, x21, x1
    c058:	eb00403f 	cmp	x1, x0, lsl #16
    c05c:	54000322 	b.cs	c0c0 <f0+0x1f20>  // b.hs, b.nlast
    c060:	d350fc22 	lsr	x2, x1, #16
    c064:	f949fc63 	ldr	x3, [x3, #5112]
    c068:	8b020842 	add	x2, x2, x2, lsl #2
    c06c:	d37df042 	lsl	x2, x2, #3
    c070:	8b020060 	add	x0, x3, x2
    c074:	f9401017 	ldr	x23, [x0, #32]
    c078:	b4000257 	cbz	x23, c0c0 <f0+0x1f20>
    c07c:	38626862 	ldrb	w2, [x3, x2]
    c080:	7100085f 	cmp	w2, #0x2
    c084:	54002580 	b.eq	c534 <f0+0x2394>  // b.none
    c088:	7100045f 	cmp	w2, #0x1
    c08c:	540001a1 	b.ne	c0c0 <f0+0x1f20>  // b.any
    c090:	29430002 	ldp	w2, w0, [x0, #24]
    c094:	92403c21 	and	x1, x1, #0xffff
    c098:	9b027c21 	mul	x1, x1, x2
    c09c:	d360fc21 	lsr	x1, x1, #32
    c0a0:	eb00003f 	cmp	x1, x0
    c0a4:	540000e2 	b.cs	c0c0 <f0+0x1f20>  // b.hs, b.nlast
    c0a8:	8b0102f7 	add	x23, x23, x1
    c0ac:	394002e0 	ldrb	w0, [x23]
    c0b0:	7103fc1f 	cmp	w0, #0xff
    c0b4:	54003960 	b.eq	c7e0 <f0+0x2640>  // b.none
    c0b8:	52800020 	mov	w0, #0x1                   	// #1
    c0bc:	390002e0 	strb	w0, [x23]
    c0c0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c0c4:	911ee3e1 	add	x1, sp, #0x7b8
    c0c8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c0cc:	52800020 	mov	w0, #0x1                   	// #1
    c0d0:	f903dfe2 	str	x2, [sp, #1976]
    c0d4:	f903e3f5 	str	x21, [sp, #1984]
    c0d8:	97ffe3c7 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c0dc:	91170283 	add	x3, x20, #0x5c0
    c0e0:	aa0003f5 	mov	x21, x0
    c0e4:	f949d861 	ldr	x1, [x3, #5040]
    c0e8:	f949ec60 	ldr	x0, [x3, #5080]
    c0ec:	cb0102a1 	sub	x1, x21, x1
    c0f0:	eb00403f 	cmp	x1, x0, lsl #16
    c0f4:	54000322 	b.cs	c158 <f0+0x1fb8>  // b.hs, b.nlast
    c0f8:	d350fc22 	lsr	x2, x1, #16
    c0fc:	f949fc63 	ldr	x3, [x3, #5112]
    c100:	8b020842 	add	x2, x2, x2, lsl #2
    c104:	d37df042 	lsl	x2, x2, #3
    c108:	8b020060 	add	x0, x3, x2
    c10c:	f9401017 	ldr	x23, [x0, #32]
    c110:	b4000257 	cbz	x23, c158 <f0+0x1fb8>
    c114:	38626862 	ldrb	w2, [x3, x2]
    c118:	7100085f 	cmp	w2, #0x2
    c11c:	540021e0 	b.eq	c558 <f0+0x23b8>  // b.none
    c120:	7100045f 	cmp	w2, #0x1
    c124:	540001a1 	b.ne	c158 <f0+0x1fb8>  // b.any
    c128:	29430002 	ldp	w2, w0, [x0, #24]
    c12c:	92403c21 	and	x1, x1, #0xffff
    c130:	9b027c21 	mul	x1, x1, x2
    c134:	d360fc21 	lsr	x1, x1, #32
    c138:	eb00003f 	cmp	x1, x0
    c13c:	540000e2 	b.cs	c158 <f0+0x1fb8>  // b.hs, b.nlast
    c140:	8b0102f7 	add	x23, x23, x1
    c144:	394002e0 	ldrb	w0, [x23]
    c148:	7103fc1f 	cmp	w0, #0xff
    c14c:	54003500 	b.eq	c7ec <f0+0x264c>  // b.none
    c150:	52800020 	mov	w0, #0x1                   	// #1
    c154:	390002e0 	strb	w0, [x23]
    c158:	911f23e1 	add	x1, sp, #0x7c8
    c15c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c160:	52800020 	mov	w0, #0x1                   	// #1
    c164:	f903e7e2 	str	x2, [sp, #1992]
    c168:	f903ebf5 	str	x21, [sp, #2000]
    c16c:	97ffe3a2 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c170:	97ffe664 	bl	5b00 <fwp_rc_fresh>
    c174:	aa0003e2 	mov	x2, x0
    c178:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c17c:	911f63e1 	add	x1, sp, #0x7d8
    c180:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c184:	52800020 	mov	w0, #0x1                   	// #1
    c188:	f903efe3 	str	x3, [sp, #2008]
    c18c:	f903f3e2 	str	x2, [sp, #2016]
    c190:	97ffe399 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c194:	91170283 	add	x3, x20, #0x5c0
    c198:	aa0003f5 	mov	x21, x0
    c19c:	f949d861 	ldr	x1, [x3, #5040]
    c1a0:	f949ec60 	ldr	x0, [x3, #5080]
    c1a4:	cb0102a1 	sub	x1, x21, x1
    c1a8:	eb00403f 	cmp	x1, x0, lsl #16
    c1ac:	54000322 	b.cs	c210 <f0+0x2070>  // b.hs, b.nlast
    c1b0:	d350fc22 	lsr	x2, x1, #16
    c1b4:	f949fc63 	ldr	x3, [x3, #5112]
    c1b8:	8b020842 	add	x2, x2, x2, lsl #2
    c1bc:	d37df042 	lsl	x2, x2, #3
    c1c0:	8b020060 	add	x0, x3, x2
    c1c4:	f9401017 	ldr	x23, [x0, #32]
    c1c8:	b4000257 	cbz	x23, c210 <f0+0x2070>
    c1cc:	38626862 	ldrb	w2, [x3, x2]
    c1d0:	7100085f 	cmp	w2, #0x2
    c1d4:	54001bc0 	b.eq	c54c <f0+0x23ac>  // b.none
    c1d8:	7100045f 	cmp	w2, #0x1
    c1dc:	540001a1 	b.ne	c210 <f0+0x2070>  // b.any
    c1e0:	29430002 	ldp	w2, w0, [x0, #24]
    c1e4:	92403c21 	and	x1, x1, #0xffff
    c1e8:	9b027c21 	mul	x1, x1, x2
    c1ec:	d360fc21 	lsr	x1, x1, #32
    c1f0:	eb00003f 	cmp	x1, x0
    c1f4:	540000e2 	b.cs	c210 <f0+0x2070>  // b.hs, b.nlast
    c1f8:	8b0102f7 	add	x23, x23, x1
    c1fc:	394002e0 	ldrb	w0, [x23]
    c200:	7103fc1f 	cmp	w0, #0xff
    c204:	54002fa0 	b.eq	c7f8 <f0+0x2658>  // b.none
    c208:	52800020 	mov	w0, #0x1                   	// #1
    c20c:	390002e0 	strb	w0, [x23]
    c210:	911fa3e1 	add	x1, sp, #0x7e8
    c214:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c218:	52800020 	mov	w0, #0x1                   	// #1
    c21c:	f903f7f7 	str	x23, [sp, #2024]
    c220:	f903fbf5 	str	x21, [sp, #2032]
    c224:	97ffe374 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c228:	97ffe636 	bl	5b00 <fwp_rc_fresh>
    c22c:	aa0003e2 	mov	x2, x0
    c230:	911fe3e1 	add	x1, sp, #0x7f8
    c234:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c238:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c23c:	52800020 	mov	w0, #0x1                   	// #1
    c240:	f903fff5 	str	x21, [sp, #2040]
    c244:	f90403e2 	str	x2, [sp, #2048]
    c248:	97ffe36b 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c24c:	97ffe62d 	bl	5b00 <fwp_rc_fresh>
    c250:	aa0003e2 	mov	x2, x0
    c254:	912023e1 	add	x1, sp, #0x808
    c258:	52800020 	mov	w0, #0x1                   	// #1
    c25c:	f90407f7 	str	x23, [sp, #2056]
    c260:	f9040be2 	str	x2, [sp, #2064]
    c264:	97ffe364 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c268:	97ffe626 	bl	5b00 <fwp_rc_fresh>
    c26c:	aa0003e2 	mov	x2, x0
    c270:	912063e1 	add	x1, sp, #0x818
    c274:	52800020 	mov	w0, #0x1                   	// #1
    c278:	f9040ff5 	str	x21, [sp, #2072]
    c27c:	f90413e2 	str	x2, [sp, #2080]
    c280:	97ffe35d 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c284:	91170283 	add	x3, x20, #0x5c0
    c288:	aa0003f5 	mov	x21, x0
    c28c:	f949d861 	ldr	x1, [x3, #5040]
    c290:	f949ec60 	ldr	x0, [x3, #5080]
    c294:	cb0102a1 	sub	x1, x21, x1
    c298:	eb00403f 	cmp	x1, x0, lsl #16
    c29c:	54000322 	b.cs	c300 <f0+0x2160>  // b.hs, b.nlast
    c2a0:	d350fc22 	lsr	x2, x1, #16
    c2a4:	f949fc63 	ldr	x3, [x3, #5112]
    c2a8:	8b020842 	add	x2, x2, x2, lsl #2
    c2ac:	d37df042 	lsl	x2, x2, #3
    c2b0:	8b020060 	add	x0, x3, x2
    c2b4:	f9401017 	ldr	x23, [x0, #32]
    c2b8:	b4000257 	cbz	x23, c300 <f0+0x2160>
    c2bc:	38626862 	ldrb	w2, [x3, x2]
    c2c0:	7100085f 	cmp	w2, #0x2
    c2c4:	54001560 	b.eq	c570 <f0+0x23d0>  // b.none
    c2c8:	7100045f 	cmp	w2, #0x1
    c2cc:	540001a1 	b.ne	c300 <f0+0x2160>  // b.any
    c2d0:	29430002 	ldp	w2, w0, [x0, #24]
    c2d4:	92403c21 	and	x1, x1, #0xffff
    c2d8:	9b027c21 	mul	x1, x1, x2
    c2dc:	d360fc21 	lsr	x1, x1, #32
    c2e0:	eb00003f 	cmp	x1, x0
    c2e4:	540000e2 	b.cs	c300 <f0+0x2160>  // b.hs, b.nlast
    c2e8:	8b0102f7 	add	x23, x23, x1
    c2ec:	394002e0 	ldrb	w0, [x23]
    c2f0:	7103fc1f 	cmp	w0, #0xff
    c2f4:	54002880 	b.eq	c804 <f0+0x2664>  // b.none
    c2f8:	52800020 	mov	w0, #0x1                   	// #1
    c2fc:	390002e0 	strb	w0, [x23]
    c300:	91170294 	add	x20, x20, #0x5c0
    c304:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c308:	9120a3e1 	add	x1, sp, #0x828
    c30c:	52800020 	mov	w0, #0x1                   	// #1
    c310:	f90417e2 	str	x2, [sp, #2088]
    c314:	f9041bf5 	str	x21, [sp, #2096]
    c318:	97ffe337 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c31c:	f949da81 	ldr	x1, [x20, #5040]
    c320:	aa0003f5 	mov	x21, x0
    c324:	f949ee80 	ldr	x0, [x20, #5080]
    c328:	cb0102a1 	sub	x1, x21, x1
    c32c:	eb00403f 	cmp	x1, x0, lsl #16
    c330:	54000322 	b.cs	c394 <f0+0x21f4>  // b.hs, b.nlast
    c334:	d350fc22 	lsr	x2, x1, #16
    c338:	f949fe83 	ldr	x3, [x20, #5112]
    c33c:	8b020842 	add	x2, x2, x2, lsl #2
    c340:	d37df042 	lsl	x2, x2, #3
    c344:	8b020060 	add	x0, x3, x2
    c348:	f9401014 	ldr	x20, [x0, #32]
    c34c:	b4000254 	cbz	x20, c394 <f0+0x21f4>
    c350:	38626862 	ldrb	w2, [x3, x2]
    c354:	7100085f 	cmp	w2, #0x2
    c358:	54001060 	b.eq	c564 <f0+0x23c4>  // b.none
    c35c:	7100045f 	cmp	w2, #0x1
    c360:	540001a1 	b.ne	c394 <f0+0x21f4>  // b.any
    c364:	29430002 	ldp	w2, w0, [x0, #24]
    c368:	92403c21 	and	x1, x1, #0xffff
    c36c:	9b027c21 	mul	x1, x1, x2
    c370:	d360fc21 	lsr	x1, x1, #32
    c374:	eb00003f 	cmp	x1, x0
    c378:	540000e2 	b.cs	c394 <f0+0x21f4>  // b.hs, b.nlast
    c37c:	8b010294 	add	x20, x20, x1
    c380:	39400280 	ldrb	w0, [x20]
    c384:	7103fc1f 	cmp	w0, #0xff
    c388:	540015a0 	b.eq	c63c <f0+0x249c>  // b.none
    c38c:	52800020 	mov	w0, #0x1                   	// #1
    c390:	39000280 	strb	w0, [x20]
    c394:	9120e3e1 	add	x1, sp, #0x838
    c398:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c39c:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c3a0:	52800020 	mov	w0, #0x1                   	// #1
    c3a4:	f9041ff4 	str	x20, [sp, #2104]
    c3a8:	f90423f5 	str	x21, [sp, #2112]
    c3ac:	97ffe312 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c3b0:	97ffe5d4 	bl	5b00 <fwp_rc_fresh>
    c3b4:	aa0003e2 	mov	x2, x0
    c3b8:	912123e1 	add	x1, sp, #0x848
    c3bc:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c3c0:	52800020 	mov	w0, #0x1                   	// #1
    c3c4:	f90427e3 	str	x3, [sp, #2120]
    c3c8:	f9042be2 	str	x2, [sp, #2128]
    c3cc:	97ffe30a 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c3d0:	97ffe5cc 	bl	5b00 <fwp_rc_fresh>
    c3d4:	aa0003e2 	mov	x2, x0
    c3d8:	aa1603e1 	mov	x1, x22
    c3dc:	52800020 	mov	w0, #0x1                   	// #1
    c3e0:	f9042ff4 	str	x20, [sp, #2136]
    c3e4:	f90433e2 	str	x2, [sp, #2144]
    c3e8:	97ffe303 	bl	4ff4 <fwp_data.part.0.constprop.0>
    c3ec:	97ffe5c5 	bl	5b00 <fwp_rc_fresh>
    c3f0:	aa0003f5 	mov	x21, x0
    c3f4:	aa1303e1 	mov	x1, x19
    c3f8:	97fff09a 	bl	8660 <fwp_hof0.constprop.0>
    c3fc:	aa0003f4 	mov	x20, x0
    c400:	aa1503e0 	mov	x0, x21
    c404:	97ffe71f 	bl	6080 <fwp_drop0>
    c408:	aa1303e0 	mov	x0, x19
    c40c:	97ffe71d 	bl	6080 <fwp_drop0>
    c410:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    c414:	f947f400 	ldr	x0, [x0, #4072]
    c418:	f94437e2 	ldr	x2, [sp, #2152]
    c41c:	f9400001 	ldr	x1, [x0]
    c420:	eb010042 	subs	x2, x2, x1
    c424:	d2800001 	mov	x1, #0x0                   	// #0
    c428:	54001f41 	b.ne	c810 <f0+0x2670>  // b.any
    c42c:	9121c3ff 	add	sp, sp, #0x870
    c430:	aa1403e0 	mov	x0, x20
    c434:	a94153f3 	ldp	x19, x20, [sp, #16]
    c438:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c43c:	a94363f7 	ldp	x23, x24, [sp, #48]
    c440:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c444:	a94573fb 	ldp	x27, x28, [sp, #80]
    c448:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c44c:	d65f03c0 	ret
    c450:	aa1c03e0 	mov	x0, x28
    c454:	97ffdf4b 	bl	4180 <fwp_rc_forget_slot.part.0>
    c458:	17fff79c 	b	a2c8 <f0+0x128>
    c45c:	72003c5f 	tst	w2, #0xffff
    c460:	54fef361 	b.ne	a2cc <f0+0x12c>  // b.any
    c464:	17fff796 	b	a2bc <f0+0x11c>
    c468:	72003c3f 	tst	w1, #0xffff
    c46c:	54fef921 	b.ne	a390 <f0+0x1f0>  // b.any
    c470:	17fff7c3 	b	a37c <f0+0x1dc>
    c474:	72003c3f 	tst	w1, #0xffff
    c478:	54ff06a1 	b.ne	a54c <f0+0x3ac>  // b.any
    c47c:	17fff82f 	b	a538 <f0+0x398>
    c480:	72003c3f 	tst	w1, #0xffff
    c484:	54ff01a1 	b.ne	a4b8 <f0+0x318>  // b.any
    c488:	17fff807 	b	a4a4 <f0+0x304>
    c48c:	72003c3f 	tst	w1, #0xffff
    c490:	54ff1261 	b.ne	a6dc <f0+0x53c>  // b.any
    c494:	17fff88d 	b	a6c8 <f0+0x528>
    c498:	72003c3f 	tst	w1, #0xffff
    c49c:	54ff0c81 	b.ne	a62c <f0+0x48c>  // b.any
    c4a0:	17fff85e 	b	a618 <f0+0x478>
    c4a4:	72003c3f 	tst	w1, #0xffff
    c4a8:	54ff1fa1 	b.ne	a89c <f0+0x6fc>  // b.any
    c4ac:	17fff8f7 	b	a888 <f0+0x6e8>
    c4b0:	72003c3f 	tst	w1, #0xffff
    c4b4:	54ff19c1 	b.ne	a7ec <f0+0x64c>  // b.any
    c4b8:	17fff8c8 	b	a7d8 <f0+0x638>
    c4bc:	72003c3f 	tst	w1, #0xffff
    c4c0:	54ff9e41 	b.ne	b888 <f0+0x16e8>  // b.any
    c4c4:	17fffcec 	b	b874 <f0+0x16d4>
    c4c8:	72003c3f 	tst	w1, #0xffff
    c4cc:	54ff8be1 	b.ne	b648 <f0+0x14a8>  // b.any
    c4d0:	17fffc59 	b	b634 <f0+0x1494>
    c4d4:	72003c3f 	tst	w1, #0xffff
    c4d8:	54ffa9c1 	b.ne	ba10 <f0+0x1870>  // b.any
    c4dc:	17fffd48 	b	b9fc <f0+0x185c>
    c4e0:	72003c3f 	tst	w1, #0xffff
    c4e4:	54ffa1e1 	b.ne	b920 <f0+0x1780>  // b.any
    c4e8:	17fffd09 	b	b90c <f0+0x176c>
    c4ec:	72003c3f 	tst	w1, #0xffff
    c4f0:	54ffb461 	b.ne	bb7c <f0+0x19dc>  // b.any
    c4f4:	17fffd9d 	b	bb68 <f0+0x19c8>
    c4f8:	72003c3f 	tst	w1, #0xffff
    c4fc:	54ffaf41 	b.ne	bae4 <f0+0x1944>  // b.any
    c500:	17fffd74 	b	bad0 <f0+0x1930>
    c504:	72003c3f 	tst	w1, #0xffff
    c508:	54ffc0e1 	b.ne	bd24 <f0+0x1b84>  // b.any
    c50c:	17fffe01 	b	bd10 <f0+0x1b70>
    c510:	72003c3f 	tst	w1, #0xffff
    c514:	54ffbac1 	b.ne	bc6c <f0+0x1acc>  // b.any
    c518:	17fffdd0 	b	bc58 <f0+0x1ab8>
    c51c:	72003c3f 	tst	w1, #0xffff
    c520:	54ffcd21 	b.ne	bec4 <f0+0x1d24>  // b.any
    c524:	17fffe63 	b	beb0 <f0+0x1d10>
    c528:	72003c3f 	tst	w1, #0xffff
    c52c:	54ffc461 	b.ne	bdb8 <f0+0x1c18>  // b.any
    c530:	17fffe1d 	b	bda4 <f0+0x1c04>
    c534:	72003c3f 	tst	w1, #0xffff
    c538:	54ffdc41 	b.ne	c0c0 <f0+0x1f20>  // b.any
    c53c:	17fffedc 	b	c0ac <f0+0x1f0c>
    c540:	72003c3f 	tst	w1, #0xffff
    c544:	54ffd541 	b.ne	bfec <f0+0x1e4c>  // b.any
    c548:	17fffea4 	b	bfd8 <f0+0x1e38>
    c54c:	72003c3f 	tst	w1, #0xffff
    c550:	54ffe601 	b.ne	c210 <f0+0x2070>  // b.any
    c554:	17ffff2a 	b	c1fc <f0+0x205c>
    c558:	72003c3f 	tst	w1, #0xffff
    c55c:	54ffdfe1 	b.ne	c158 <f0+0x1fb8>  // b.any
    c560:	17fffef9 	b	c144 <f0+0x1fa4>
    c564:	72003c3f 	tst	w1, #0xffff
    c568:	54fff161 	b.ne	c394 <f0+0x21f4>  // b.any
    c56c:	17ffff85 	b	c380 <f0+0x21e0>
    c570:	72003c3f 	tst	w1, #0xffff
    c574:	54ffec61 	b.ne	c300 <f0+0x2160>  // b.any
    c578:	17ffff5d 	b	c2ec <f0+0x214c>
    c57c:	72003c3f 	tst	w1, #0xffff
    c580:	54ff2201 	b.ne	a9c0 <f0+0x820>  // b.any
    c584:	17fff90a 	b	a9ac <f0+0x80c>
    c588:	72003c3f 	tst	w1, #0xffff
    c58c:	54ff1d01 	b.ne	a92c <f0+0x78c>  // b.any
    c590:	17fff8e2 	b	a918 <f0+0x778>
    c594:	72003c3f 	tst	w1, #0xffff
    c598:	54ff2c81 	b.ne	ab28 <f0+0x988>  // b.any
    c59c:	17fff95e 	b	ab14 <f0+0x974>
    c5a0:	72003c3f 	tst	w1, #0xffff
    c5a4:	54ff2661 	b.ne	aa70 <f0+0x8d0>  // b.any
    c5a8:	17fff92d 	b	aa5c <f0+0x8bc>
    c5ac:	72003c3f 	tst	w1, #0xffff
    c5b0:	54ff39e1 	b.ne	acec <f0+0xb4c>  // b.any
    c5b4:	17fff9c9 	b	acd8 <f0+0xb38>
    c5b8:	72003c3f 	tst	w1, #0xffff
    c5bc:	54ff3201 	b.ne	abfc <f0+0xa5c>  // b.any
    c5c0:	17fff98a 	b	abe8 <f0+0xa48>
    c5c4:	72003c3f 	tst	w1, #0xffff
    c5c8:	54ff43a1 	b.ne	ae3c <f0+0xc9c>  // b.any
    c5cc:	17fffa17 	b	ae28 <f0+0xc88>
    c5d0:	72003c3f 	tst	w1, #0xffff
    c5d4:	54ff3d81 	b.ne	ad84 <f0+0xbe4>  // b.any
    c5d8:	17fff9e6 	b	ad70 <f0+0xbd0>
    c5dc:	72003c3f 	tst	w1, #0xffff
    c5e0:	54ff4c41 	b.ne	af68 <f0+0xdc8>  // b.any
    c5e4:	17fffa5c 	b	af54 <f0+0xdb4>
    c5e8:	72003c3f 	tst	w1, #0xffff
    c5ec:	54ff4721 	b.ne	aed0 <f0+0xd30>  // b.any
    c5f0:	17fffa33 	b	aebc <f0+0xd1c>
    c5f4:	72003c3f 	tst	w1, #0xffff
    c5f8:	54ff5a81 	b.ne	b148 <f0+0xfa8>  // b.any
    c5fc:	17ffface 	b	b134 <f0+0xf94>
    c600:	72003c3f 	tst	w1, #0xffff
    c604:	54ff52a1 	b.ne	b058 <f0+0xeb8>  // b.any
    c608:	17fffa8f 	b	b044 <f0+0xea4>
    c60c:	72003c3f 	tst	w1, #0xffff
    c610:	54ff68a1 	b.ne	b324 <f0+0x1184>  // b.any
    c614:	17fffb3f 	b	b310 <f0+0x1170>
    c618:	72003c3f 	tst	w1, #0xffff
    c61c:	54ff6381 	b.ne	b28c <f0+0x10ec>  // b.any
    c620:	17fffb16 	b	b278 <f0+0x10d8>
    c624:	72003c3f 	tst	w1, #0xffff
    c628:	54ff78a1 	b.ne	b53c <f0+0x139c>  // b.any
    c62c:	17fffbbf 	b	b528 <f0+0x1388>
    c630:	72003c3f 	tst	w1, #0xffff
    c634:	54ff6f01 	b.ne	b414 <f0+0x1274>  // b.any
    c638:	17fffb72 	b	b400 <f0+0x1260>
    c63c:	aa1403e0 	mov	x0, x20
    c640:	97ffded0 	bl	4180 <fwp_rc_forget_slot.part.0>
    c644:	17ffff52 	b	c38c <f0+0x21ec>
    c648:	aa1503e0 	mov	x0, x21
    c64c:	97ffdecd 	bl	4180 <fwp_rc_forget_slot.part.0>
    c650:	17fff74e 	b	a388 <f0+0x1e8>
    c654:	aa1703e0 	mov	x0, x23
    c658:	97ffdeca 	bl	4180 <fwp_rc_forget_slot.part.0>
    c65c:	17fff795 	b	a4b0 <f0+0x310>
    c660:	aa1703e0 	mov	x0, x23
    c664:	97ffdec7 	bl	4180 <fwp_rc_forget_slot.part.0>
    c668:	17fff7b7 	b	a544 <f0+0x3a4>
    c66c:	aa1703e0 	mov	x0, x23
    c670:	97ffdec4 	bl	4180 <fwp_rc_forget_slot.part.0>
    c674:	17fff7ec 	b	a624 <f0+0x484>
    c678:	aa1703e0 	mov	x0, x23
    c67c:	97ffdec1 	bl	4180 <fwp_rc_forget_slot.part.0>
    c680:	17fff815 	b	a6d4 <f0+0x534>
    c684:	aa1703e0 	mov	x0, x23
    c688:	97ffdebe 	bl	4180 <fwp_rc_forget_slot.part.0>
    c68c:	17fff856 	b	a7e4 <f0+0x644>
    c690:	aa1703e0 	mov	x0, x23
    c694:	97ffdebb 	bl	4180 <fwp_rc_forget_slot.part.0>
    c698:	17fff87f 	b	a894 <f0+0x6f4>
    c69c:	aa1703e0 	mov	x0, x23
    c6a0:	97ffdeb8 	bl	4180 <fwp_rc_forget_slot.part.0>
    c6a4:	17fff8a0 	b	a924 <f0+0x784>
    c6a8:	aa1703e0 	mov	x0, x23
    c6ac:	97ffdeb5 	bl	4180 <fwp_rc_forget_slot.part.0>
    c6b0:	17fff8c2 	b	a9b8 <f0+0x818>
    c6b4:	aa1703e0 	mov	x0, x23
    c6b8:	97ffdeb2 	bl	4180 <fwp_rc_forget_slot.part.0>
    c6bc:	17fff8eb 	b	aa68 <f0+0x8c8>
    c6c0:	aa1703e0 	mov	x0, x23
    c6c4:	97ffdeaf 	bl	4180 <fwp_rc_forget_slot.part.0>
    c6c8:	17fff916 	b	ab20 <f0+0x980>
    c6cc:	aa1703e0 	mov	x0, x23
    c6d0:	97ffdeac 	bl	4180 <fwp_rc_forget_slot.part.0>
    c6d4:	17fff948 	b	abf4 <f0+0xa54>
    c6d8:	aa1703e0 	mov	x0, x23
    c6dc:	97ffdea9 	bl	4180 <fwp_rc_forget_slot.part.0>
    c6e0:	17fff981 	b	ace4 <f0+0xb44>
    c6e4:	aa1703e0 	mov	x0, x23
    c6e8:	97ffdea6 	bl	4180 <fwp_rc_forget_slot.part.0>
    c6ec:	17fff9a4 	b	ad7c <f0+0xbdc>
    c6f0:	aa1703e0 	mov	x0, x23
    c6f4:	97ffdea3 	bl	4180 <fwp_rc_forget_slot.part.0>
    c6f8:	17fff9cf 	b	ae34 <f0+0xc94>
    c6fc:	aa1703e0 	mov	x0, x23
    c700:	97ffdea0 	bl	4180 <fwp_rc_forget_slot.part.0>
    c704:	17fff9f1 	b	aec8 <f0+0xd28>
    c708:	aa1703e0 	mov	x0, x23
    c70c:	97ffde9d 	bl	4180 <fwp_rc_forget_slot.part.0>
    c710:	17fffa14 	b	af60 <f0+0xdc0>
    c714:	aa1703e0 	mov	x0, x23
    c718:	97ffde9a 	bl	4180 <fwp_rc_forget_slot.part.0>
    c71c:	17fffa4d 	b	b050 <f0+0xeb0>
    c720:	aa1503e0 	mov	x0, x21
    c724:	97ffde97 	bl	4180 <fwp_rc_forget_slot.part.0>
    c728:	17fffa86 	b	b140 <f0+0xfa0>
    c72c:	aa1703e0 	mov	x0, x23
    c730:	97ffde94 	bl	4180 <fwp_rc_forget_slot.part.0>
    c734:	17fffad4 	b	b284 <f0+0x10e4>
    c738:	aa1703e0 	mov	x0, x23
    c73c:	97ffde91 	bl	4180 <fwp_rc_forget_slot.part.0>
    c740:	17fffaf7 	b	b31c <f0+0x117c>
    c744:	aa1703e0 	mov	x0, x23
    c748:	97ffde8e 	bl	4180 <fwp_rc_forget_slot.part.0>
    c74c:	17fffb30 	b	b40c <f0+0x126c>
    c750:	aa1703e0 	mov	x0, x23
    c754:	97ffde8b 	bl	4180 <fwp_rc_forget_slot.part.0>
    c758:	17fffb77 	b	b534 <f0+0x1394>
    c75c:	aa1703e0 	mov	x0, x23
    c760:	97ffde88 	bl	4180 <fwp_rc_forget_slot.part.0>
    c764:	17fffbb7 	b	b640 <f0+0x14a0>
    c768:	aa1703e0 	mov	x0, x23
    c76c:	97ffde85 	bl	4180 <fwp_rc_forget_slot.part.0>
    c770:	17fffc44 	b	b880 <f0+0x16e0>
    c774:	aa1703e0 	mov	x0, x23
    c778:	97ffde82 	bl	4180 <fwp_rc_forget_slot.part.0>
    c77c:	17fffc67 	b	b918 <f0+0x1778>
    c780:	aa1703e0 	mov	x0, x23
    c784:	97ffde7f 	bl	4180 <fwp_rc_forget_slot.part.0>
    c788:	17fffca0 	b	ba08 <f0+0x1868>
    c78c:	aa1703e0 	mov	x0, x23
    c790:	97ffde7c 	bl	4180 <fwp_rc_forget_slot.part.0>
    c794:	17fffcd2 	b	badc <f0+0x193c>
    c798:	aa1703e0 	mov	x0, x23
    c79c:	97ffde79 	bl	4180 <fwp_rc_forget_slot.part.0>
    c7a0:	17fffcf5 	b	bb74 <f0+0x19d4>
    c7a4:	aa1703e0 	mov	x0, x23
    c7a8:	97ffde76 	bl	4180 <fwp_rc_forget_slot.part.0>
    c7ac:	17fffd2e 	b	bc64 <f0+0x1ac4>
    c7b0:	aa1703e0 	mov	x0, x23
    c7b4:	97ffde73 	bl	4180 <fwp_rc_forget_slot.part.0>
    c7b8:	17fffd59 	b	bd1c <f0+0x1b7c>
    c7bc:	aa1703e0 	mov	x0, x23
    c7c0:	97ffde70 	bl	4180 <fwp_rc_forget_slot.part.0>
    c7c4:	17fffd7b 	b	bdb0 <f0+0x1c10>
    c7c8:	aa1703e0 	mov	x0, x23
    c7cc:	97ffde6d 	bl	4180 <fwp_rc_forget_slot.part.0>
    c7d0:	17fffdbb 	b	bebc <f0+0x1d1c>
    c7d4:	aa1703e0 	mov	x0, x23
    c7d8:	97ffde6a 	bl	4180 <fwp_rc_forget_slot.part.0>
    c7dc:	17fffe02 	b	bfe4 <f0+0x1e44>
    c7e0:	aa1703e0 	mov	x0, x23
    c7e4:	97ffde67 	bl	4180 <fwp_rc_forget_slot.part.0>
    c7e8:	17fffe34 	b	c0b8 <f0+0x1f18>
    c7ec:	aa1703e0 	mov	x0, x23
    c7f0:	97ffde64 	bl	4180 <fwp_rc_forget_slot.part.0>
    c7f4:	17fffe57 	b	c150 <f0+0x1fb0>
    c7f8:	aa1703e0 	mov	x0, x23
    c7fc:	97ffde61 	bl	4180 <fwp_rc_forget_slot.part.0>
    c800:	17fffe82 	b	c208 <f0+0x2068>
    c804:	aa1703e0 	mov	x0, x23
    c808:	97ffde5e 	bl	4180 <fwp_rc_forget_slot.part.0>
    c80c:	17fffebb 	b	c2f8 <f0+0x2158>
    c810:	97ffd820 	bl	2890 <__stack_chk_fail@plt>
    c814:	97ffd833 	bl	28e0 <abort@plt>
    c818:	d503201f 	nop
    c81c:	d503201f 	nop

000000000000c820 <fwp_main_thread>:
    c820:	d10443ff 	sub	sp, sp, #0x110
    c824:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    c828:	f947f400 	ldr	x0, [x0, #4072]
    c82c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c830:	910303fd 	add	x29, sp, #0xc0
    c834:	a90d53f3 	stp	x19, x20, [sp, #208]
    c838:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc20>
    c83c:	91170261 	add	x1, x19, #0x5c0
    c840:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c844:	b953a421 	ldr	w1, [x1, #5028]
    c848:	f9400002 	ldr	x2, [x0]
    c84c:	f9005fe2 	str	x2, [sp, #184]
    c850:	d2800002 	mov	x2, #0x0                   	// #0
    c854:	34000ea1 	cbz	w1, ca28 <fwp_main_thread+0x208>
    c858:	91170273 	add	x19, x19, #0x5c0
    c85c:	b953aa60 	ldr	w0, [x19, #5032]
    c860:	35000dc0 	cbnz	w0, ca18 <fwp_main_thread+0x1f8>
    c864:	91001fe2 	add	x2, sp, #0x7
    c868:	900000b4 	adrp	x20, 20000 <__data_start>
    c86c:	900000a3 	adrp	x3, 20000 <__data_start>
    c870:	9101c293 	add	x19, x20, #0x70
    c874:	910f8063 	add	x3, x3, #0x3e0
    c878:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c87c:	d2a00025 	mov	x5, #0x10000               	// #65536
    c880:	910023e0 	add	x0, sp, #0x8
    c884:	d2800001 	mov	x1, #0x0                   	// #0
    c888:	f90007e3 	str	x3, [sp, #8]
    c88c:	b90013ff 	str	wzr, [sp, #16]
    c890:	a9019262 	stp	x2, x4, [x19, #24]
    c894:	f9000fe5 	str	x5, [sp, #24]
    c898:	97ffd79a 	bl	2700 <sigaltstack@plt>
    c89c:	35000220 	cbnz	w0, c8e0 <fwp_main_thread+0xc0>
    c8a0:	4f000400 	movi	v0.4s, #0x0
    c8a4:	9100a3e0 	add	x0, sp, #0x28
    c8a8:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0x10>
    c8ac:	52800082 	mov	w2, #0x4                   	// #4
    c8b0:	9101c021 	add	x1, x1, #0x70
    c8b4:	72a10002 	movk	w2, #0x800, lsl #16
    c8b8:	910083f5 	add	x21, sp, #0x20
    c8bc:	f90013e1 	str	x1, [sp, #32]
    c8c0:	3d802000 	str	q0, [x0, #128]
    c8c4:	b900abe2 	str	w2, [sp, #168]
    c8c8:	ad000000 	stp	q0, q0, [x0]
    c8cc:	ad010000 	stp	q0, q0, [x0, #32]
    c8d0:	ad020000 	stp	q0, q0, [x0, #64]
    c8d4:	ad030000 	stp	q0, q0, [x0, #96]
    c8d8:	97ffd7de 	bl	2850 <sigemptyset@plt>
    c8dc:	340000c0 	cbz	w0, c8f4 <fwp_main_thread+0xd4>
    c8e0:	b0000000 	adrp	x0, d000 <__divti3+0x2a0>
    c8e4:	912bc000 	add	x0, x0, #0xaf0
    c8e8:	a90f63f7 	stp	x23, x24, [sp, #240]
    c8ec:	f90083f9 	str	x25, [sp, #256]
    c8f0:	97ffde04 	bl	4100 <fwp_trap>
    c8f4:	aa1503e1 	mov	x1, x21
    c8f8:	d2800002 	mov	x2, #0x0                   	// #0
    c8fc:	52800160 	mov	w0, #0xb                   	// #11
    c900:	97ffd7ec 	bl	28b0 <sigaction@plt>
    c904:	35fffee0 	cbnz	w0, c8e0 <fwp_main_thread+0xc0>
    c908:	aa1503e1 	mov	x1, x21
    c90c:	d2800002 	mov	x2, #0x0                   	// #0
    c910:	528000e0 	mov	w0, #0x7                   	// #7
    c914:	97ffd7e7 	bl	28b0 <sigaction@plt>
    c918:	35fffe40 	cbnz	w0, c8e0 <fwp_main_thread+0xc0>
    c91c:	b9433a60 	ldr	w0, [x19, #824]
    c920:	34000880 	cbz	w0, ca30 <fwp_main_thread+0x210>
    c924:	a90f63f7 	stp	x23, x24, [sp, #240]
    c928:	9101c293 	add	x19, x20, #0x70
    c92c:	b9433e60 	ldr	w0, [x19, #828]
    c930:	34001e80 	cbz	w0, cd00 <fwp_main_thread+0x4e0>
    c934:	9101c296 	add	x22, x20, #0x70
    c938:	f9400ad5 	ldr	x21, [x22, #16]
    c93c:	b4000d95 	cbz	x21, caec <fwp_main_thread+0x2cc>
    c940:	910102b7 	add	x23, x21, #0x40
    c944:	f90083f9 	str	x25, [sp, #256]
    c948:	52800038 	mov	w24, #0x1                   	// #1
    c94c:	39414ab9 	ldrb	w25, [x21, #82]
    c950:	39014ab8 	strb	w24, [x21, #82]
    c954:	d503201f 	nop
    c958:	f94016a0 	ldr	x0, [x21, #40]
    c95c:	b4000c40 	cbz	x0, cae4 <fwp_main_thread+0x2c4>
    c960:	f94032a1 	ldr	x1, [x21, #96]
    c964:	394146a0 	ldrb	w0, [x21, #81]
    c968:	b4000861 	cbz	x1, ca74 <fwp_main_thread+0x254>
    c96c:	36000720 	tbz	w0, #0, ca50 <fwp_main_thread+0x230>
    c970:	f9400ad3 	ldr	x19, [x22, #16]
    c974:	f94022a0 	ldr	x0, [x21, #64]
    c978:	39414a61 	ldrb	w1, [x19, #82]
    c97c:	37000a41 	tbnz	w1, #0, cac4 <fwp_main_thread+0x2a4>
    c980:	f9403261 	ldr	x1, [x19, #96]
    c984:	a911fe77 	stp	x23, xzr, [x19, #280]
    c988:	f9009660 	str	x0, [x19, #296]
    c98c:	b4000040 	cbz	x0, c994 <fwp_main_thread+0x174>
    c990:	f9009013 	str	x19, [x0, #288]
    c994:	f90022b3 	str	x19, [x21, #64]
    c998:	b4000101 	cbz	x1, c9b8 <fwp_main_thread+0x198>
    c99c:	f94066c0 	ldr	x0, [x22, #200]
    c9a0:	39015678 	strb	w24, [x19, #85]
    c9a4:	f9003661 	str	x1, [x19, #104]
    c9a8:	a910827f 	stp	xzr, x0, [x19, #264]
    c9ac:	b4000040 	cbz	x0, c9b4 <fwp_main_thread+0x194>
    c9b0:	f9008413 	str	x19, [x0, #264]
    c9b4:	f90066d3 	str	x19, [x22, #200]
    c9b8:	39015a7f 	strb	wzr, [x19, #86]
    c9bc:	97ffe8a5 	bl	6c50 <fwp_block>
    c9c0:	f9408e62 	ldr	x2, [x19, #280]
    c9c4:	b4000142 	cbz	x2, c9ec <fwp_main_thread+0x1cc>
    c9c8:	a9520261 	ldp	x1, x0, [x19, #288]
    c9cc:	b4000881 	cbz	x1, cadc <fwp_main_thread+0x2bc>
    c9d0:	f9009420 	str	x0, [x1, #296]
    c9d4:	f9409660 	ldr	x0, [x19, #296]
    c9d8:	b4000040 	cbz	x0, c9e0 <fwp_main_thread+0x1c0>
    c9dc:	f9009001 	str	x1, [x0, #288]
    c9e0:	91080260 	add	x0, x19, #0x200
    c9e4:	f900967f 	str	xzr, [x19, #296]
    c9e8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c9ec:	39415660 	ldrb	w0, [x19, #85]
    c9f0:	3607fb40 	tbz	w0, #0, c958 <fwp_main_thread+0x138>
    c9f4:	a9508261 	ldp	x1, x0, [x19, #264]
    c9f8:	b4001801 	cbz	x1, ccf8 <fwp_main_thread+0x4d8>
    c9fc:	f9008820 	str	x0, [x1, #272]
    ca00:	b4000040 	cbz	x0, ca08 <fwp_main_thread+0x1e8>
    ca04:	f9008401 	str	x1, [x0, #264]
    ca08:	91080260 	add	x0, x19, #0x200
    ca0c:	3901567f 	strb	wzr, [x19, #85]
    ca10:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    ca14:	17ffffd1 	b	c958 <fwp_main_thread+0x138>
    ca18:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    ca1c:	91301000 	add	x0, x0, #0xc04
    ca20:	9400028c 	bl	d450 <atexit>
    ca24:	17ffff90 	b	c864 <fwp_main_thread+0x44>
    ca28:	97ffdcd2 	bl	3d70 <fwp_heap_init>
    ca2c:	17ffff8b 	b	c858 <fwp_main_thread+0x38>
    ca30:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    ca34:	91058000 	add	x0, x0, #0x160
    ca38:	94000286 	bl	d450 <atexit>
    ca3c:	a90f63f7 	stp	x23, x24, [sp, #240]
    ca40:	35001860 	cbnz	w0, cd4c <fwp_main_thread+0x52c>
    ca44:	52800020 	mov	w0, #0x1                   	// #1
    ca48:	b9033a60 	str	w0, [x19, #824]
    ca4c:	17ffffb7 	b	c928 <fwp_main_thread+0x108>
    ca50:	97ffdfcc 	bl	4980 <fwp_now_ns>
    ca54:	f94032a1 	ldr	x1, [x21, #96]
    ca58:	eb01001f 	cmp	x0, x1
    ca5c:	540000ab 	b.lt	ca70 <fwp_main_thread+0x250>  // b.tstop
    ca60:	394142a0 	ldrb	w0, [x21, #80]
    ca64:	37000060 	tbnz	w0, #0, ca70 <fwp_main_thread+0x250>
    ca68:	aa1503e0 	mov	x0, x21
    ca6c:	97ffdb21 	bl	36f0 <fwp_cancel_tree.part.0>
    ca70:	394146a0 	ldrb	w0, [x21, #81]
    ca74:	f9400ad3 	ldr	x19, [x22, #16]
    ca78:	39414a62 	ldrb	w2, [x19, #82]
    ca7c:	3707f7a0 	tbnz	w0, #0, c970 <fwp_main_thread+0x150>
    ca80:	f94032a1 	ldr	x1, [x21, #96]
    ca84:	370001c2 	tbnz	w2, #0, cabc <fwp_main_thread+0x29c>
    ca88:	f9403260 	ldr	x0, [x19, #96]
    ca8c:	b4000180 	cbz	x0, cabc <fwp_main_thread+0x29c>
    ca90:	b4000061 	cbz	x1, ca9c <fwp_main_thread+0x27c>
    ca94:	eb01001f 	cmp	x0, x1
    ca98:	9a81d000 	csel	x0, x0, x1, le
    ca9c:	f94022a1 	ldr	x1, [x21, #64]
    caa0:	a911fe77 	stp	x23, xzr, [x19, #280]
    caa4:	f9009661 	str	x1, [x19, #296]
    caa8:	b4001361 	cbz	x1, cd14 <fwp_main_thread+0x4f4>
    caac:	f9009033 	str	x19, [x1, #288]
    cab0:	aa0003e1 	mov	x1, x0
    cab4:	f90022b3 	str	x19, [x21, #64]
    cab8:	17ffffb9 	b	c99c <fwp_main_thread+0x17c>
    cabc:	f94022a0 	ldr	x0, [x21, #64]
    cac0:	17ffffb1 	b	c984 <fwp_main_thread+0x164>
    cac4:	a911fe77 	stp	x23, xzr, [x19, #280]
    cac8:	f9009660 	str	x0, [x19, #296]
    cacc:	b4000040 	cbz	x0, cad4 <fwp_main_thread+0x2b4>
    cad0:	f9009013 	str	x19, [x0, #288]
    cad4:	f90022b3 	str	x19, [x21, #64]
    cad8:	17ffffb8 	b	c9b8 <fwp_main_thread+0x198>
    cadc:	f9000040 	str	x0, [x2]
    cae0:	17ffffbe 	b	c9d8 <fwp_main_thread+0x1b8>
    cae4:	39014ab9 	strb	w25, [x21, #82]
    cae8:	f94083f9 	ldr	x25, [sp, #256]
    caec:	9101c293 	add	x19, x20, #0x70
    caf0:	f9418e60 	ldr	x0, [x19, #792]
    caf4:	b5000060 	cbnz	x0, cb00 <fwp_main_thread+0x2e0>
    caf8:	f9419660 	ldr	x0, [x19, #808]
    cafc:	b4001120 	cbz	x0, cd20 <fwp_main_thread+0x500>
    cb00:	9101c280 	add	x0, x20, #0x70
    cb04:	f9400800 	ldr	x0, [x0, #16]
    cb08:	9101c281 	add	x1, x20, #0x70
    cb0c:	f941a826 	ldr	x6, [x1, #848]
    cb10:	b903483f 	str	wzr, [x1, #840]
    cb14:	eb0000df 	cmp	x6, x0
    cb18:	540011e1 	b.ne	cd54 <fwp_main_thread+0x534>  // b.any
    cb1c:	b40003c0 	cbz	x0, cb94 <fwp_main_thread+0x374>
    cb20:	f9417825 	ldr	x5, [x1, #752]
    cb24:	52800021 	mov	w1, #0x1                   	// #1
    cb28:	39014801 	strb	w1, [x0, #82]
    cb2c:	b4000345 	cbz	x5, cb94 <fwp_main_thread+0x374>
    cb30:	394140a0 	ldrb	w0, [x5, #80]
    cb34:	37000060 	tbnz	w0, #0, cb40 <fwp_main_thread+0x320>
    cb38:	aa0503e0 	mov	x0, x5
    cb3c:	97ffdaed 	bl	36f0 <fwp_cancel_tree.part.0>
    cb40:	f9409ca5 	ldr	x5, [x5, #312]
    cb44:	b5ffff65 	cbnz	x5, cb30 <fwp_main_thread+0x310>
    cb48:	9101c293 	add	x19, x20, #0x70
    cb4c:	52800035 	mov	w21, #0x1                   	// #1
    cb50:	f94028c0 	ldr	x0, [x6, #80]
    cb54:	f2001c1f 	tst	x0, #0xff000000ff
    cb58:	540000e1 	b.ne	cb74 <fwp_main_thread+0x354>  // b.any
    cb5c:	f9403e60 	ldr	x0, [x19, #120]
    cb60:	390150d5 	strb	w21, [x6, #84]
    cb64:	f90080df 	str	xzr, [x6, #256]
    cb68:	b4000120 	cbz	x0, cb8c <fwp_main_thread+0x36c>
    cb6c:	f9008006 	str	x6, [x0, #256]
    cb70:	f9003e66 	str	x6, [x19, #120]
    cb74:	97ffe837 	bl	6c50 <fwp_block>
    cb78:	97ffe7be 	bl	6a70 <fwp_free_zombie>
    cb7c:	f9417a60 	ldr	x0, [x19, #752]
    cb80:	b40000a0 	cbz	x0, cb94 <fwp_main_thread+0x374>
    cb84:	f941aa66 	ldr	x6, [x19, #848]
    cb88:	17fffff2 	b	cb50 <fwp_main_thread+0x330>
    cb8c:	f9004266 	str	x6, [x19, #128]
    cb90:	17fffff8 	b	cb70 <fwp_main_thread+0x350>
    cb94:	9101c295 	add	x21, x20, #0x70
    cb98:	97ffe7b6 	bl	6a70 <fwp_free_zombie>
    cb9c:	f94042a0 	ldr	x0, [x21, #128]
    cba0:	b5000da0 	cbnz	x0, cd54 <fwp_main_thread+0x534>
    cba4:	f94066a0 	ldr	x0, [x21, #200]
    cba8:	b5000d60 	cbnz	x0, cd54 <fwp_main_thread+0x534>
    cbac:	b940eab3 	ldr	w19, [x21, #232]
    cbb0:	340001f3 	cbz	w19, cbec <fwp_main_thread+0x3cc>
    cbb4:	93407e76 	sxtw	x22, w19
    cbb8:	51000673 	sub	w19, w19, #0x1
    cbbc:	d1000ad6 	sub	x22, x22, #0x2
    cbc0:	9103c2b7 	add	x23, x21, #0xf0
    cbc4:	cb3342d6 	sub	x22, x22, w19, uxtw
    cbc8:	93407e73 	sxtw	x19, w19
    cbcc:	d503201f 	nop
    cbd0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    cbd4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cbd8:	b900eab3 	str	w19, [x21, #232]
    cbdc:	d1000673 	sub	x19, x19, #0x1
    cbe0:	97ffd774 	bl	29b0 <munmap@plt>
    cbe4:	eb1302df 	cmp	x22, x19
    cbe8:	54ffff41 	b.ne	cbd0 <fwp_main_thread+0x3b0>  // b.any
    cbec:	900000b3 	adrp	x19, 20000 <__data_start>
    cbf0:	91004260 	add	x0, x19, #0x10
    cbf4:	b9404000 	ldr	w0, [x0, #64]
    cbf8:	37f80040 	tbnz	w0, #31, cc00 <fwp_main_thread+0x3e0>
    cbfc:	97ffd729 	bl	28a0 <close@plt>
    cc00:	9101c295 	add	x21, x20, #0x70
    cc04:	91004273 	add	x19, x19, #0x10
    cc08:	12800001 	mov	w1, #0xffffffff            	// #-1
    cc0c:	f941b2a0 	ldr	x0, [x21, #864]
    cc10:	b9004261 	str	w1, [x19, #64]
    cc14:	f941aea1 	ldr	x1, [x21, #856]
    cc18:	b40001c0 	cbz	x0, cc50 <fwp_main_thread+0x430>
    cc1c:	d2800013 	mov	x19, #0x0                   	// #0
    cc20:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    cc24:	b40000e0 	cbz	x0, cc40 <fwp_main_thread+0x420>
    cc28:	f9400001 	ldr	x1, [x0]
    cc2c:	b5000941 	cbnz	x1, cd54 <fwp_main_thread+0x534>
    cc30:	f9400401 	ldr	x1, [x0, #8]
    cc34:	b5000901 	cbnz	x1, cd54 <fwp_main_thread+0x534>
    cc38:	97ffddee 	bl	43f0 <fwp_mem_free>
    cc3c:	f941aea1 	ldr	x1, [x21, #856]
    cc40:	91000673 	add	x19, x19, #0x1
    cc44:	f941b2a0 	ldr	x0, [x21, #864]
    cc48:	eb00027f 	cmp	x19, x0
    cc4c:	54fffea3 	b.cc	cc20 <fwp_main_thread+0x400>  // b.lo, b.ul, b.last
    cc50:	aa0103e0 	mov	x0, x1
    cc54:	97ffdde7 	bl	43f0 <fwp_mem_free>
    cc58:	9101c280 	add	x0, x20, #0x70
    cc5c:	f941a813 	ldr	x19, [x0, #848]
    cc60:	f901ac1f 	str	xzr, [x0, #856]
    cc64:	f901b01f 	str	xzr, [x0, #864]
    cc68:	b40001f3 	cbz	x19, cca4 <fwp_main_thread+0x484>
    cc6c:	f9401661 	ldr	x1, [x19, #40]
    cc70:	b5000721 	cbnz	x1, cd54 <fwp_main_thread+0x534>
    cc74:	f9405661 	ldr	x1, [x19, #168]
    cc78:	b50006e1 	cbnz	x1, cd54 <fwp_main_thread+0x534>
    cc7c:	f9418c01 	ldr	x1, [x0, #792]
    cc80:	b50006a1 	cbnz	x1, cd54 <fwp_main_thread+0x534>
    cc84:	f9419400 	ldr	x0, [x0, #808]
    cc88:	b5000660 	cbnz	x0, cd54 <fwp_main_thread+0x534>
    cc8c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    cc90:	90000120 	adrp	x0, 30000 <alt.5+0xfc20>
    cc94:	910f8000 	add	x0, x0, #0x3e0
    cc98:	97ffd6f2 	bl	2860 <memset@plt>
    cc9c:	aa1303e0 	mov	x0, x19
    cca0:	97ffddd4 	bl	43f0 <fwp_mem_free>
    cca4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    cca8:	f947ec00 	ldr	x0, [x0, #4056]
    ccac:	9101c294 	add	x20, x20, #0x70
    ccb0:	f9400000 	ldr	x0, [x0]
    ccb4:	f9000a9f 	str	xzr, [x20, #16]
    ccb8:	f901aa9f 	str	xzr, [x20, #848]
    ccbc:	97ffd741 	bl	29c0 <fflush@plt>
    ccc0:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    ccc4:	f947f400 	ldr	x0, [x0, #4072]
    ccc8:	f9405fe2 	ldr	x2, [sp, #184]
    cccc:	f9400001 	ldr	x1, [x0]
    ccd0:	eb010042 	subs	x2, x2, x1
    ccd4:	d2800001 	mov	x1, #0x0                   	// #0
    ccd8:	54000361 	b.ne	cd44 <fwp_main_thread+0x524>  // b.any
    ccdc:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cce0:	d2800000 	mov	x0, #0x0                   	// #0
    cce4:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cce8:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    ccec:	a94f63f7 	ldp	x23, x24, [sp, #240]
    ccf0:	910443ff 	add	sp, sp, #0x110
    ccf4:	d65f03c0 	ret
    ccf8:	f90066c0 	str	x0, [x22, #200]
    ccfc:	17ffff41 	b	ca00 <fwp_main_thread+0x1e0>
    cd00:	97fff528 	bl	a1a0 <f0>
    cd04:	f901a260 	str	x0, [x19, #832]
    cd08:	52800021 	mov	w1, #0x1                   	// #1
    cd0c:	b9033e61 	str	w1, [x19, #828]
    cd10:	17ffff09 	b	c934 <fwp_main_thread+0x114>
    cd14:	aa0003e1 	mov	x1, x0
    cd18:	f90022b3 	str	x19, [x21, #64]
    cd1c:	17ffff20 	b	c99c <fwp_main_thread+0x17c>
    cd20:	f9418a60 	ldr	x0, [x19, #784]
    cd24:	97ffddb3 	bl	43f0 <fwp_mem_free>
    cd28:	f9018a7f 	str	xzr, [x19, #784]
    cd2c:	f9400a60 	ldr	x0, [x19, #16]
    cd30:	f901927f 	str	xzr, [x19, #800]
    cd34:	b4ffeea0 	cbz	x0, cb08 <fwp_main_thread+0x2e8>
    cd38:	f900541f 	str	xzr, [x0, #168]
    cd3c:	f9005c1f 	str	xzr, [x0, #184]
    cd40:	17ffff72 	b	cb08 <fwp_main_thread+0x2e8>
    cd44:	f90083f9 	str	x25, [sp, #256]
    cd48:	97ffd6d2 	bl	2890 <__stack_chk_fail@plt>
    cd4c:	f90083f9 	str	x25, [sp, #256]
    cd50:	97ffd8f8 	bl	3130 <descent_phase_fail>
    cd54:	f90083f9 	str	x25, [sp, #256]
    cd58:	97ffd6e2 	bl	28e0 <abort@plt>
    cd5c:	d503201f 	nop

000000000000cd60 <__divti3>:
    cd60:	d503245f 	bti	c
    cd64:	d2800004 	mov	x4, #0x0                   	// #0
    cd68:	b7f80721 	tbnz	x1, #63, ce4c <__divti3+0xec>
    cd6c:	b6f80083 	tbz	x3, #63, cd7c <__divti3+0x1c>
    cd70:	eb0203e2 	negs	x2, x2
    cd74:	aa2403e4 	mvn	x4, x4
    cd78:	da0303e3 	ngc	x3, x3
    cd7c:	aa0203e6 	mov	x6, x2
    cd80:	aa0003e7 	mov	x7, x0
    cd84:	aa0103e5 	mov	x5, x1
    cd88:	b5000583 	cbnz	x3, ce38 <__divti3+0xd8>
    cd8c:	eb01005f 	cmp	x2, x1
    cd90:	54000e69 	b.ls	cf5c <__divti3+0x1fc>  // b.plast
    cd94:	dac01040 	clz	x0, x2
    cd98:	b40000e0 	cbz	x0, cdb4 <__divti3+0x54>
    cd9c:	4b0003e1 	neg	w1, w0
    cda0:	9ac020a5 	lsl	x5, x5, x0
    cda4:	9ac02046 	lsl	x6, x2, x0
    cda8:	9ac124e1 	lsr	x1, x7, x1
    cdac:	aa050025 	orr	x5, x1, x5
    cdb0:	9ac020e7 	lsl	x7, x7, x0
    cdb4:	d360fcc8 	lsr	x8, x6, #32
    cdb8:	92407cc2 	and	x2, x6, #0xffffffff
    cdbc:	9ac808a3 	udiv	x3, x5, x8
    cdc0:	9b089465 	msub	x5, x3, x8, x5
    cdc4:	aa0303e0 	mov	x0, x3
    cdc8:	9b037c41 	mul	x1, x2, x3
    cdcc:	93c780a5 	extr	x5, x5, x7, #32
    cdd0:	eb05003f 	cmp	x1, x5
    cdd4:	540000a9 	b.ls	cde8 <__divti3+0x88>  // b.plast
    cdd8:	ab0500c5 	adds	x5, x6, x5
    cddc:	d1000460 	sub	x0, x3, #0x1
    cde0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    cde4:	540015a8 	b.hi	d098 <__divti3+0x338>  // b.pmore
    cde8:	cb0100a5 	sub	x5, x5, x1
    cdec:	9ac808a3 	udiv	x3, x5, x8
    cdf0:	9b089465 	msub	x5, x3, x8, x5
    cdf4:	aa0303e1 	mov	x1, x3
    cdf8:	9b037c42 	mul	x2, x2, x3
    cdfc:	aa0703e3 	mov	x3, x7
    ce00:	b3607ca3 	bfi	x3, x5, #32, #32
    ce04:	eb03005f 	cmp	x2, x3
    ce08:	540000c9 	b.ls	ce20 <__divti3+0xc0>  // b.plast
    ce0c:	ab0300c3 	adds	x3, x6, x3
    ce10:	d1000425 	sub	x5, x1, #0x1
    ce14:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ce18:	d1000821 	sub	x1, x1, #0x2
    ce1c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ce20:	aa008020 	orr	x0, x1, x0, lsl #32
    ce24:	d2800001 	mov	x1, #0x0                   	// #0
    ce28:	b4000064 	cbz	x4, ce34 <__divti3+0xd4>
    ce2c:	eb0003e0 	negs	x0, x0
    ce30:	da0103e1 	ngc	x1, x1
    ce34:	d65f03c0 	ret
    ce38:	eb01007f 	cmp	x3, x1
    ce3c:	54000109 	b.ls	ce5c <__divti3+0xfc>  // b.plast
    ce40:	d2800001 	mov	x1, #0x0                   	// #0
    ce44:	d2800000 	mov	x0, #0x0                   	// #0
    ce48:	17fffff8 	b	ce28 <__divti3+0xc8>
    ce4c:	eb0003e0 	negs	x0, x0
    ce50:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ce54:	da0103e1 	ngc	x1, x1
    ce58:	17ffffc5 	b	cd6c <__divti3+0xc>
    ce5c:	dac01067 	clz	x7, x3
    ce60:	b40010e7 	cbz	x7, d07c <__divti3+0x31c>
    ce64:	d2800805 	mov	x5, #0x40                  	// #64
    ce68:	cb0700a5 	sub	x5, x5, x7
    ce6c:	9ac72063 	lsl	x3, x3, x7
    ce70:	9ac52448 	lsr	x8, x2, x5
    ce74:	aa030108 	orr	x8, x8, x3
    ce78:	9ac52426 	lsr	x6, x1, x5
    ce7c:	92407d0a 	and	x10, x8, #0xffffffff
    ce80:	d360fd09 	lsr	x9, x8, #32
    ce84:	9ac52403 	lsr	x3, x0, x5
    ce88:	9ac72021 	lsl	x1, x1, x7
    ce8c:	aa010063 	orr	x3, x3, x1
    ce90:	9ac72042 	lsl	x2, x2, x7
    ce94:	9ac908cb 	udiv	x11, x6, x9
    ce98:	9b099965 	msub	x5, x11, x9, x6
    ce9c:	aa0b03e1 	mov	x1, x11
    cea0:	9b0b7d46 	mul	x6, x10, x11
    cea4:	93c380a5 	extr	x5, x5, x3, #32
    cea8:	eb0500df 	cmp	x6, x5
    ceac:	540000a9 	b.ls	cec0 <__divti3+0x160>  // b.plast
    ceb0:	ab050105 	adds	x5, x8, x5
    ceb4:	d1000561 	sub	x1, x11, #0x1
    ceb8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    cebc:	54000f48 	b.hi	d0a4 <__divti3+0x344>  // b.pmore
    cec0:	cb0600a6 	sub	x6, x5, x6
    cec4:	9ac908cb 	udiv	x11, x6, x9
    cec8:	9b099969 	msub	x9, x11, x9, x6
    cecc:	aa0b03e5 	mov	x5, x11
    ced0:	9b0b7d4a 	mul	x10, x10, x11
    ced4:	b3607d23 	bfi	x3, x9, #32, #32
    ced8:	eb03015f 	cmp	x10, x3
    cedc:	540000a9 	b.ls	cef0 <__divti3+0x190>  // b.plast
    cee0:	ab030103 	adds	x3, x8, x3
    cee4:	d1000565 	sub	x5, x11, #0x1
    cee8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    ceec:	54000e28 	b.hi	d0b0 <__divti3+0x350>  // b.pmore
    cef0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cef4:	92407c48 	and	x8, x2, #0xffffffff
    cef8:	2a0503e5 	mov	w5, w5
    cefc:	d360fc42 	lsr	x2, x2, #32
    cf00:	d360fc26 	lsr	x6, x1, #32
    cf04:	cb0a0063 	sub	x3, x3, x10
    cf08:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cf0c:	9b087caa 	mul	x10, x5, x8
    cf10:	9b087cc8 	mul	x8, x6, x8
    cf14:	9b0220a5 	madd	x5, x5, x2, x8
    cf18:	9b027cc6 	mul	x6, x6, x2
    cf1c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cf20:	8b0900c5 	add	x5, x6, x9
    cf24:	eb02011f 	cmp	x8, x2
    cf28:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cf2c:	8b4280c6 	add	x6, x6, x2, lsr #32
    cf30:	eb06007f 	cmp	x3, x6
    cf34:	540000e3 	b.cc	cf50 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cf38:	92407d4a 	and	x10, x10, #0xffffffff
    cf3c:	9ac72000 	lsl	x0, x0, x7
    cf40:	8b028142 	add	x2, x10, x2, lsl #32
    cf44:	eb02001f 	cmp	x0, x2
    cf48:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cf4c:	54000a01 	b.ne	d08c <__divti3+0x32c>  // b.any
    cf50:	d1000420 	sub	x0, x1, #0x1
    cf54:	d2800001 	mov	x1, #0x0                   	// #0
    cf58:	17ffffb4 	b	ce28 <__divti3+0xc8>
    cf5c:	b5000062 	cbnz	x2, cf68 <__divti3+0x208>
    cf60:	d2800022 	mov	x2, #0x1                   	// #1
    cf64:	9ac30846 	udiv	x6, x2, x3
    cf68:	dac010c8 	clz	x8, x6
    cf6c:	b5000408 	cbnz	x8, cfec <__divti3+0x28c>
    cf70:	d360fcc9 	lsr	x9, x6, #32
    cf74:	92407cc5 	and	x5, x6, #0xffffffff
    cf78:	cb060023 	sub	x3, x1, x6
    cf7c:	d2800021 	mov	x1, #0x1                   	// #1
    cf80:	9ac90868 	udiv	x8, x3, x9
    cf84:	9b098d03 	msub	x3, x8, x9, x3
    cf88:	aa0803e0 	mov	x0, x8
    cf8c:	9b057d02 	mul	x2, x8, x5
    cf90:	93c78063 	extr	x3, x3, x7, #32
    cf94:	eb03005f 	cmp	x2, x3
    cf98:	540000a9 	b.ls	cfac <__divti3+0x24c>  // b.plast
    cf9c:	ab0300c3 	adds	x3, x6, x3
    cfa0:	d1000500 	sub	x0, x8, #0x1
    cfa4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cfa8:	54000968 	b.hi	d0d4 <__divti3+0x374>  // b.pmore
    cfac:	cb020063 	sub	x3, x3, x2
    cfb0:	9ac90862 	udiv	x2, x3, x9
    cfb4:	aa0203e8 	mov	x8, x2
    cfb8:	9b098c42 	msub	x2, x2, x9, x3
    cfbc:	aa0703e3 	mov	x3, x7
    cfc0:	9b057d05 	mul	x5, x8, x5
    cfc4:	b3607c43 	bfi	x3, x2, #32, #32
    cfc8:	eb0300bf 	cmp	x5, x3
    cfcc:	540000c9 	b.ls	cfe4 <__divti3+0x284>  // b.plast
    cfd0:	ab0300c2 	adds	x2, x6, x3
    cfd4:	d1000503 	sub	x3, x8, #0x1
    cfd8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cfdc:	d1000908 	sub	x8, x8, #0x2
    cfe0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cfe4:	aa008100 	orr	x0, x8, x0, lsl #32
    cfe8:	17ffff90 	b	ce28 <__divti3+0xc8>
    cfec:	9ac820c6 	lsl	x6, x6, x8
    cff0:	d2800803 	mov	x3, #0x40                  	// #64
    cff4:	cb080063 	sub	x3, x3, x8
    cff8:	d360fcc9 	lsr	x9, x6, #32
    cffc:	9ac82027 	lsl	x7, x1, x8
    d000:	92407cc5 	and	x5, x6, #0xffffffff
    d004:	9ac32422 	lsr	x2, x1, x3
    d008:	9ac32403 	lsr	x3, x0, x3
    d00c:	aa070063 	orr	x3, x3, x7
    d010:	9ac9084a 	udiv	x10, x2, x9
    d014:	9ac82007 	lsl	x7, x0, x8
    d018:	9b098940 	msub	x0, x10, x9, x2
    d01c:	aa0a03e1 	mov	x1, x10
    d020:	9b0a7ca2 	mul	x2, x5, x10
    d024:	93c38000 	extr	x0, x0, x3, #32
    d028:	eb00005f 	cmp	x2, x0
    d02c:	540000a9 	b.ls	d040 <__divti3+0x2e0>  // b.plast
    d030:	ab0000c0 	adds	x0, x6, x0
    d034:	d1000541 	sub	x1, x10, #0x1
    d038:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d03c:	54000468 	b.hi	d0c8 <__divti3+0x368>  // b.pmore
    d040:	cb020000 	sub	x0, x0, x2
    d044:	9ac9080a 	udiv	x10, x0, x9
    d048:	9b098140 	msub	x0, x10, x9, x0
    d04c:	aa0a03e2 	mov	x2, x10
    d050:	9b0a7ca8 	mul	x8, x5, x10
    d054:	b3607c03 	bfi	x3, x0, #32, #32
    d058:	eb03011f 	cmp	x8, x3
    d05c:	540000a9 	b.ls	d070 <__divti3+0x310>  // b.plast
    d060:	ab0300c3 	adds	x3, x6, x3
    d064:	d1000542 	sub	x2, x10, #0x1
    d068:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d06c:	54000288 	b.hi	d0bc <__divti3+0x35c>  // b.pmore
    d070:	cb080063 	sub	x3, x3, x8
    d074:	aa018041 	orr	x1, x2, x1, lsl #32
    d078:	17ffffc2 	b	cf80 <__divti3+0x220>
    d07c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d080:	d2800001 	mov	x1, #0x0                   	// #0
    d084:	9a9f87e0 	cset	x0, ls	// ls = plast
    d088:	17ffff68 	b	ce28 <__divti3+0xc8>
    d08c:	aa0103e0 	mov	x0, x1
    d090:	d2800001 	mov	x1, #0x0                   	// #0
    d094:	17ffff65 	b	ce28 <__divti3+0xc8>
    d098:	d1000860 	sub	x0, x3, #0x2
    d09c:	8b0600a5 	add	x5, x5, x6
    d0a0:	17ffff52 	b	cde8 <__divti3+0x88>
    d0a4:	d1000961 	sub	x1, x11, #0x2
    d0a8:	8b0800a5 	add	x5, x5, x8
    d0ac:	17ffff85 	b	cec0 <__divti3+0x160>
    d0b0:	d1000965 	sub	x5, x11, #0x2
    d0b4:	8b080063 	add	x3, x3, x8
    d0b8:	17ffff8e 	b	cef0 <__divti3+0x190>
    d0bc:	d1000942 	sub	x2, x10, #0x2
    d0c0:	8b060063 	add	x3, x3, x6
    d0c4:	17ffffeb 	b	d070 <__divti3+0x310>
    d0c8:	d1000941 	sub	x1, x10, #0x2
    d0cc:	8b060000 	add	x0, x0, x6
    d0d0:	17ffffdc 	b	d040 <__divti3+0x2e0>
    d0d4:	d1000900 	sub	x0, x8, #0x2
    d0d8:	8b060063 	add	x3, x3, x6
    d0dc:	17ffffb4 	b	cfac <__divti3+0x24c>

000000000000d0e0 <__modti3>:
    d0e0:	d503245f 	bti	c
    d0e4:	d2800004 	mov	x4, #0x0                   	// #0
    d0e8:	b6f80081 	tbz	x1, #63, d0f8 <__modti3+0x18>
    d0ec:	eb0003e0 	negs	x0, x0
    d0f0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d0f4:	da0103e1 	ngc	x1, x1
    d0f8:	f100007f 	cmp	x3, #0x0
    d0fc:	5400128b 	b.lt	d34c <__modti3+0x26c>  // b.tstop
    d100:	aa0003e7 	mov	x7, x0
    d104:	aa0103e6 	mov	x6, x1
    d108:	540004e1 	b.ne	d1a4 <__modti3+0xc4>  // b.any
    d10c:	eb02003f 	cmp	x1, x2
    d110:	54000dc2 	b.cs	d2c8 <__modti3+0x1e8>  // b.hs, b.nlast
    d114:	dac01043 	clz	x3, x2
    d118:	aa0303e5 	mov	x5, x3
    d11c:	b40000e3 	cbz	x3, d138 <__modti3+0x58>
    d120:	4b0303e6 	neg	w6, w3
    d124:	9ac32021 	lsl	x1, x1, x3
    d128:	9ac32042 	lsl	x2, x2, x3
    d12c:	9ac62406 	lsr	x6, x0, x6
    d130:	aa0100c6 	orr	x6, x6, x1
    d134:	9ac32007 	lsl	x7, x0, x3
    d138:	d360fc40 	lsr	x0, x2, #32
    d13c:	92407c43 	and	x3, x2, #0xffffffff
    d140:	9ac008c1 	udiv	x1, x6, x0
    d144:	9b009826 	msub	x6, x1, x0, x6
    d148:	9b017c61 	mul	x1, x3, x1
    d14c:	93c780c6 	extr	x6, x6, x7, #32
    d150:	eb06003f 	cmp	x1, x6
    d154:	540000a9 	b.ls	d168 <__modti3+0x88>  // b.plast
    d158:	ab060046 	adds	x6, x2, x6
    d15c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d160:	8b0200c8 	add	x8, x6, x2
    d164:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d168:	cb0100c6 	sub	x6, x6, x1
    d16c:	9ac008c8 	udiv	x8, x6, x0
    d170:	9b009901 	msub	x1, x8, x0, x6
    d174:	aa0703e0 	mov	x0, x7
    d178:	9b087c63 	mul	x3, x3, x8
    d17c:	b3607c20 	bfi	x0, x1, #32, #32
    d180:	eb00007f 	cmp	x3, x0
    d184:	54001088 	b.hi	d394 <__modti3+0x2b4>  // b.pmore
    d188:	cb030000 	sub	x0, x0, x3
    d18c:	9ac52400 	lsr	x0, x0, x5
    d190:	d2800001 	mov	x1, #0x0                   	// #0
    d194:	b4000064 	cbz	x4, d1a0 <__modti3+0xc0>
    d198:	eb0003e0 	negs	x0, x0
    d19c:	da0103e1 	ngc	x1, x1
    d1a0:	d65f03c0 	ret
    d1a4:	dac01066 	clz	x6, x3
    d1a8:	eb03003f 	cmp	x1, x3
    d1ac:	54ffff43 	b.cc	d194 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d1b0:	93407cc5 	sxtw	x5, w6
    d1b4:	d2800808 	mov	x8, #0x40                  	// #64
    d1b8:	cb050108 	sub	x8, x8, x5
    d1bc:	9ac62063 	lsl	x3, x3, x6
    d1c0:	9ac62025 	lsl	x5, x1, x6
    d1c4:	9ac82447 	lsr	x7, x2, x8
    d1c8:	aa0300e7 	orr	x7, x7, x3
    d1cc:	9ac82423 	lsr	x3, x1, x8
    d1d0:	92407cec 	and	x12, x7, #0xffffffff
    d1d4:	d360fcea 	lsr	x10, x7, #32
    d1d8:	9ac82401 	lsr	x1, x0, x8
    d1dc:	aa050021 	orr	x1, x1, x5
    d1e0:	9ac62042 	lsl	x2, x2, x6
    d1e4:	9ac62000 	lsl	x0, x0, x6
    d1e8:	9aca086b 	udiv	x11, x3, x10
    d1ec:	9b0a8d63 	msub	x3, x11, x10, x3
    d1f0:	aa0b03e5 	mov	x5, x11
    d1f4:	9b0b7d89 	mul	x9, x12, x11
    d1f8:	93c18063 	extr	x3, x3, x1, #32
    d1fc:	eb03013f 	cmp	x9, x3
    d200:	540000a9 	b.ls	d214 <__modti3+0x134>  // b.plast
    d204:	ab0300e3 	adds	x3, x7, x3
    d208:	d1000565 	sub	x5, x11, #0x1
    d20c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d210:	54001168 	b.hi	d43c <__modti3+0x35c>  // b.pmore
    d214:	cb090063 	sub	x3, x3, x9
    d218:	9aca086b 	udiv	x11, x3, x10
    d21c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d220:	aa0b03e9 	mov	x9, x11
    d224:	9b0b7d8c 	mul	x12, x12, x11
    d228:	b3607d41 	bfi	x1, x10, #32, #32
    d22c:	eb01019f 	cmp	x12, x1
    d230:	540000a9 	b.ls	d244 <__modti3+0x164>  // b.plast
    d234:	ab0100e1 	adds	x1, x7, x1
    d238:	d1000569 	sub	x9, x11, #0x1
    d23c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d240:	54000f88 	b.hi	d430 <__modti3+0x350>  // b.pmore
    d244:	aa058123 	orr	x3, x9, x5, lsl #32
    d248:	92407c4b 	and	x11, x2, #0xffffffff
    d24c:	2a0903e9 	mov	w9, w9
    d250:	d360fc4a 	lsr	x10, x2, #32
    d254:	d360fc63 	lsr	x3, x3, #32
    d258:	cb0c0021 	sub	x1, x1, x12
    d25c:	aa0a03ec 	mov	x12, x10
    d260:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d264:	9b0b7d25 	mul	x5, x9, x11
    d268:	9b0b7c6b 	mul	x11, x3, x11
    d26c:	9b0a2d29 	madd	x9, x9, x10, x11
    d270:	92407caa 	and	x10, x5, #0xffffffff
    d274:	9b0c7c63 	mul	x3, x3, x12
    d278:	8b458125 	add	x5, x9, x5, lsr #32
    d27c:	8b0d0069 	add	x9, x3, x13
    d280:	eb05017f 	cmp	x11, x5
    d284:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d288:	8b058149 	add	x9, x10, x5, lsl #32
    d28c:	8b458063 	add	x3, x3, x5, lsr #32
    d290:	eb03003f 	cmp	x1, x3
    d294:	54000063 	b.cc	d2a0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d298:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d29c:	54000082 	b.cs	d2ac <__modti3+0x1cc>  // b.hs, b.nlast
    d2a0:	eb020129 	subs	x9, x9, x2
    d2a4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d2a8:	cb070063 	sub	x3, x3, x7
    d2ac:	eb090000 	subs	x0, x0, x9
    d2b0:	da030021 	sbc	x1, x1, x3
    d2b4:	9ac62400 	lsr	x0, x0, x6
    d2b8:	9ac82028 	lsl	x8, x1, x8
    d2bc:	aa000100 	orr	x0, x8, x0
    d2c0:	9ac62421 	lsr	x1, x1, x6
    d2c4:	17ffffb4 	b	d194 <__modti3+0xb4>
    d2c8:	b5000062 	cbnz	x2, d2d4 <__modti3+0x1f4>
    d2cc:	d2800023 	mov	x3, #0x1                   	// #1
    d2d0:	9ac20862 	udiv	x2, x3, x2
    d2d4:	dac01048 	clz	x8, x2
    d2d8:	aa0803e5 	mov	x5, x8
    d2dc:	b5000668 	cbnz	x8, d3a8 <__modti3+0x2c8>
    d2e0:	cb020020 	sub	x0, x1, x2
    d2e4:	d360fc49 	lsr	x9, x2, #32
    d2e8:	92407c4a 	and	x10, x2, #0xffffffff
    d2ec:	9ac90801 	udiv	x1, x0, x9
    d2f0:	9b098020 	msub	x0, x1, x9, x0
    d2f4:	9b0a7c21 	mul	x1, x1, x10
    d2f8:	93c78000 	extr	x0, x0, x7, #32
    d2fc:	eb00003f 	cmp	x1, x0
    d300:	540000a9 	b.ls	d314 <__modti3+0x234>  // b.plast
    d304:	ab000040 	adds	x0, x2, x0
    d308:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d30c:	8b020003 	add	x3, x0, x2
    d310:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d314:	cb010001 	sub	x1, x0, x1
    d318:	9ac90820 	udiv	x0, x1, x9
    d31c:	9b098403 	msub	x3, x0, x9, x1
    d320:	aa0703e1 	mov	x1, x7
    d324:	9b0a7c00 	mul	x0, x0, x10
    d328:	b3607c61 	bfi	x1, x3, #32, #32
    d32c:	eb01001f 	cmp	x0, x1
    d330:	540000a9 	b.ls	d344 <__modti3+0x264>  // b.plast
    d334:	ab010041 	adds	x1, x2, x1
    d338:	8b020022 	add	x2, x1, x2
    d33c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d340:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d344:	cb000020 	sub	x0, x1, x0
    d348:	17ffff91 	b	d18c <__modti3+0xac>
    d34c:	eb0203e5 	negs	x5, x2
    d350:	aa0003e7 	mov	x7, x0
    d354:	da0303e8 	ngc	x8, x3
    d358:	aa0503e2 	mov	x2, x5
    d35c:	aa0803e3 	mov	x3, x8
    d360:	aa0103e6 	mov	x6, x1
    d364:	b4ffed48 	cbz	x8, d10c <__modti3+0x2c>
    d368:	eb01011f 	cmp	x8, x1
    d36c:	54fff148 	b.hi	d194 <__modti3+0xb4>  // b.pmore
    d370:	dac01109 	clz	x9, x8
    d374:	2a0903e6 	mov	w6, w9
    d378:	b5fff1c9 	cbnz	x9, d1b0 <__modti3+0xd0>
    d37c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d380:	54000068 	b.hi	d38c <__modti3+0x2ac>  // b.pmore
    d384:	eb050007 	subs	x7, x0, x5
    d388:	da080021 	sbc	x1, x1, x8
    d38c:	aa0703e0 	mov	x0, x7
    d390:	17ffff81 	b	d194 <__modti3+0xb4>
    d394:	ab000040 	adds	x0, x2, x0
    d398:	8b020002 	add	x2, x0, x2
    d39c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d3a0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d3a4:	17ffff79 	b	d188 <__modti3+0xa8>
    d3a8:	9ac82042 	lsl	x2, x2, x8
    d3ac:	d2800803 	mov	x3, #0x40                  	// #64
    d3b0:	cb080063 	sub	x3, x3, x8
    d3b4:	d360fc49 	lsr	x9, x2, #32
    d3b8:	9ac82027 	lsl	x7, x1, x8
    d3bc:	92407c4a 	and	x10, x2, #0xffffffff
    d3c0:	9ac32426 	lsr	x6, x1, x3
    d3c4:	9ac32403 	lsr	x3, x0, x3
    d3c8:	aa070063 	orr	x3, x3, x7
    d3cc:	9ac908c1 	udiv	x1, x6, x9
    d3d0:	9ac82007 	lsl	x7, x0, x8
    d3d4:	9b099820 	msub	x0, x1, x9, x6
    d3d8:	9b017d41 	mul	x1, x10, x1
    d3dc:	93c38000 	extr	x0, x0, x3, #32
    d3e0:	eb00003f 	cmp	x1, x0
    d3e4:	540000a9 	b.ls	d3f8 <__modti3+0x318>  // b.plast
    d3e8:	ab000040 	adds	x0, x2, x0
    d3ec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d3f0:	8b020006 	add	x6, x0, x2
    d3f4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d3f8:	cb010000 	sub	x0, x0, x1
    d3fc:	9ac90801 	udiv	x1, x0, x9
    d400:	9b098026 	msub	x6, x1, x9, x0
    d404:	aa0303e0 	mov	x0, x3
    d408:	9b017d41 	mul	x1, x10, x1
    d40c:	b3607cc0 	bfi	x0, x6, #32, #32
    d410:	eb00003f 	cmp	x1, x0
    d414:	540000a9 	b.ls	d428 <__modti3+0x348>  // b.plast
    d418:	ab000040 	adds	x0, x2, x0
    d41c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d420:	8b020003 	add	x3, x0, x2
    d424:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d428:	cb010000 	sub	x0, x0, x1
    d42c:	17ffffb0 	b	d2ec <__modti3+0x20c>
    d430:	d1000969 	sub	x9, x11, #0x2
    d434:	8b070021 	add	x1, x1, x7
    d438:	17ffff83 	b	d244 <__modti3+0x164>
    d43c:	d1000965 	sub	x5, x11, #0x2
    d440:	8b070063 	add	x3, x3, x7
    d444:	17ffff74 	b	d214 <__modti3+0x134>
    d448:	d503201f 	nop
    d44c:	d503201f 	nop

000000000000d450 <atexit>:
    d450:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d454:	f0000082 	adrp	x2, 20000 <__data_start>
    d458:	d2800001 	mov	x1, #0x0                   	// #0
    d45c:	910003fd 	mov	x29, sp
    d460:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d464:	f9400442 	ldr	x2, [x2, #8]
    d468:	17ffd4ca 	b	2790 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d46c <_fini>:
    d46c:	d503201f 	nop
    d470:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d474:	910003fd 	mov	x29, sp
    d478:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d47c:	d65f03c0 	ret
