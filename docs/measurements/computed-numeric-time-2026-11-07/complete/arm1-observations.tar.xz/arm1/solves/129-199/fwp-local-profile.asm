
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-local-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001328 <_init>:
    1328:	d503201f 	nop
    132c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1330:	910003fd 	mov	x29, sp
    1334:	94000190 	bl	1974 <call_weak_fn>
    1338:	a8c17bfd 	ldp	x29, x30, [sp], #16
    133c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001340 <.plt>:
    1340:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1344:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1348:	f946fe11 	ldr	x17, [x16, #3576]
    134c:	9137e210 	add	x16, x16, #0xdf8
    1350:	d61f0220 	br	x17
    1354:	d503201f 	nop
    1358:	d503201f 	nop
    135c:	d503201f 	nop

0000000000001360 <memcpy@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1364:	f9470211 	ldr	x17, [x16, #3584]
    1368:	91380210 	add	x16, x16, #0xe00
    136c:	d61f0220 	br	x17

0000000000001370 <sigaltstack@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1374:	f9470611 	ldr	x17, [x16, #3592]
    1378:	91382210 	add	x16, x16, #0xe08
    137c:	d61f0220 	br	x17

0000000000001380 <_exit@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1384:	f9470a11 	ldr	x17, [x16, #3600]
    1388:	91384210 	add	x16, x16, #0xe10
    138c:	d61f0220 	br	x17

0000000000001390 <strlen@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1394:	f9470e11 	ldr	x17, [x16, #3608]
    1398:	91386210 	add	x16, x16, #0xe18
    139c:	d61f0220 	br	x17

00000000000013a0 <__sprintf_chk@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13a4:	f9471211 	ldr	x17, [x16, #3616]
    13a8:	91388210 	add	x16, x16, #0xe20
    13ac:	d61f0220 	br	x17

00000000000013b0 <exit@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13b4:	f9471611 	ldr	x17, [x16, #3624]
    13b8:	9138a210 	add	x16, x16, #0xe28
    13bc:	d61f0220 	br	x17

00000000000013c0 <__libc_start_main@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13c4:	f9471a11 	ldr	x17, [x16, #3632]
    13c8:	9138c210 	add	x16, x16, #0xe30
    13cc:	d61f0220 	br	x17

00000000000013d0 <strtoll@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13d4:	f9471e11 	ldr	x17, [x16, #3640]
    13d8:	9138e210 	add	x16, x16, #0xe38
    13dc:	d61f0220 	br	x17

00000000000013e0 <strtod@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13e4:	f9472211 	ldr	x17, [x16, #3648]
    13e8:	91390210 	add	x16, x16, #0xe40
    13ec:	d61f0220 	br	x17

00000000000013f0 <__cxa_finalize@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13f4:	f9472611 	ldr	x17, [x16, #3656]
    13f8:	91392210 	add	x16, x16, #0xe48
    13fc:	d61f0220 	br	x17

0000000000001400 <__cxa_atexit@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1404:	f9472a11 	ldr	x17, [x16, #3664]
    1408:	91394210 	add	x16, x16, #0xe50
    140c:	d61f0220 	br	x17

0000000000001410 <pthread_attr_init@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1414:	f9472e11 	ldr	x17, [x16, #3672]
    1418:	91396210 	add	x16, x16, #0xe58
    141c:	d61f0220 	br	x17

0000000000001420 <fputc@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1424:	f9473211 	ldr	x17, [x16, #3680]
    1428:	91398210 	add	x16, x16, #0xe60
    142c:	d61f0220 	br	x17

0000000000001430 <clock_gettime@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1434:	f9473611 	ldr	x17, [x16, #3688]
    1438:	9139a210 	add	x16, x16, #0xe68
    143c:	d61f0220 	br	x17

0000000000001440 <setvbuf@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1444:	f9473a11 	ldr	x17, [x16, #3696]
    1448:	9139c210 	add	x16, x16, #0xe70
    144c:	d61f0220 	br	x17

0000000000001450 <__memcpy_chk@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1454:	f9473e11 	ldr	x17, [x16, #3704]
    1458:	9139e210 	add	x16, x16, #0xe78
    145c:	d61f0220 	br	x17

0000000000001460 <signal@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1464:	f9474211 	ldr	x17, [x16, #3712]
    1468:	913a0210 	add	x16, x16, #0xe80
    146c:	d61f0220 	br	x17

0000000000001470 <__snprintf_chk@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1474:	f9474611 	ldr	x17, [x16, #3720]
    1478:	913a2210 	add	x16, x16, #0xe88
    147c:	d61f0220 	br	x17

0000000000001480 <fclose@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1484:	f9474a11 	ldr	x17, [x16, #3728]
    1488:	913a4210 	add	x16, x16, #0xe90
    148c:	d61f0220 	br	x17

0000000000001490 <fopen@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1494:	f9474e11 	ldr	x17, [x16, #3736]
    1498:	913a6210 	add	x16, x16, #0xe98
    149c:	d61f0220 	br	x17

00000000000014a0 <malloc@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14a4:	f9475211 	ldr	x17, [x16, #3744]
    14a8:	913a8210 	add	x16, x16, #0xea0
    14ac:	d61f0220 	br	x17

00000000000014b0 <pthread_attr_destroy@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14b4:	f9475611 	ldr	x17, [x16, #3752]
    14b8:	913aa210 	add	x16, x16, #0xea8
    14bc:	d61f0220 	br	x17

00000000000014c0 <sigemptyset@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14c4:	f9475a11 	ldr	x17, [x16, #3760]
    14c8:	913ac210 	add	x16, x16, #0xeb0
    14cc:	d61f0220 	br	x17

00000000000014d0 <memset@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14d4:	f9475e11 	ldr	x17, [x16, #3768]
    14d8:	913ae210 	add	x16, x16, #0xeb8
    14dc:	d61f0220 	br	x17

00000000000014e0 <calloc@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14e4:	f9476211 	ldr	x17, [x16, #3776]
    14e8:	913b0210 	add	x16, x16, #0xec0
    14ec:	d61f0220 	br	x17

00000000000014f0 <realloc@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14f4:	f9476611 	ldr	x17, [x16, #3784]
    14f8:	913b2210 	add	x16, x16, #0xec8
    14fc:	d61f0220 	br	x17

0000000000001500 <__stack_chk_fail@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1504:	f9476a11 	ldr	x17, [x16, #3792]
    1508:	913b4210 	add	x16, x16, #0xed0
    150c:	d61f0220 	br	x17

0000000000001510 <close@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1514:	f9476e11 	ldr	x17, [x16, #3800]
    1518:	913b6210 	add	x16, x16, #0xed8
    151c:	d61f0220 	br	x17

0000000000001520 <sigaction@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1524:	f9477211 	ldr	x17, [x16, #3808]
    1528:	913b8210 	add	x16, x16, #0xee0
    152c:	d61f0220 	br	x17

0000000000001530 <__gmon_start__@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1534:	f9477611 	ldr	x17, [x16, #3816]
    1538:	913ba210 	add	x16, x16, #0xee8
    153c:	d61f0220 	br	x17

0000000000001540 <write@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1544:	f9477a11 	ldr	x17, [x16, #3824]
    1548:	913bc210 	add	x16, x16, #0xef0
    154c:	d61f0220 	br	x17

0000000000001550 <abort@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1554:	f9477e11 	ldr	x17, [x16, #3832]
    1558:	913be210 	add	x16, x16, #0xef8
    155c:	d61f0220 	br	x17

0000000000001560 <swapcontext@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1564:	f9478211 	ldr	x17, [x16, #3840]
    1568:	913c0210 	add	x16, x16, #0xf00
    156c:	d61f0220 	br	x17

0000000000001570 <__fprintf_chk@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1574:	f9478611 	ldr	x17, [x16, #3848]
    1578:	913c2210 	add	x16, x16, #0xf08
    157c:	d61f0220 	br	x17

0000000000001580 <strcmp@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1584:	f9478a11 	ldr	x17, [x16, #3856]
    1588:	913c4210 	add	x16, x16, #0xf10
    158c:	d61f0220 	br	x17

0000000000001590 <mmap@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1594:	f9478e11 	ldr	x17, [x16, #3864]
    1598:	913c6210 	add	x16, x16, #0xf18
    159c:	d61f0220 	br	x17

00000000000015a0 <strtol@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15a4:	f9479211 	ldr	x17, [x16, #3872]
    15a8:	913c8210 	add	x16, x16, #0xf20
    15ac:	d61f0220 	br	x17

00000000000015b0 <strtof@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15b4:	f9479611 	ldr	x17, [x16, #3880]
    15b8:	913ca210 	add	x16, x16, #0xf28
    15bc:	d61f0220 	br	x17

00000000000015c0 <free@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15c4:	f9479a11 	ldr	x17, [x16, #3888]
    15c8:	913cc210 	add	x16, x16, #0xf30
    15cc:	d61f0220 	br	x17

00000000000015d0 <nanosleep@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15d4:	f9479e11 	ldr	x17, [x16, #3896]
    15d8:	913ce210 	add	x16, x16, #0xf38
    15dc:	d61f0220 	br	x17

00000000000015e0 <strchr@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15e4:	f947a211 	ldr	x17, [x16, #3904]
    15e8:	913d0210 	add	x16, x16, #0xf40
    15ec:	d61f0220 	br	x17

00000000000015f0 <strtoull@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15f4:	f947a611 	ldr	x17, [x16, #3912]
    15f8:	913d2210 	add	x16, x16, #0xf48
    15fc:	d61f0220 	br	x17

0000000000001600 <fwrite@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1604:	f947aa11 	ldr	x17, [x16, #3920]
    1608:	913d4210 	add	x16, x16, #0xf50
    160c:	d61f0220 	br	x17

0000000000001610 <pthread_create@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1614:	f947ae11 	ldr	x17, [x16, #3928]
    1618:	913d6210 	add	x16, x16, #0xf58
    161c:	d61f0220 	br	x17

0000000000001620 <munmap@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1624:	f947b211 	ldr	x17, [x16, #3936]
    1628:	913d8210 	add	x16, x16, #0xf60
    162c:	d61f0220 	br	x17

0000000000001630 <fflush@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1634:	f947b611 	ldr	x17, [x16, #3944]
    1638:	913da210 	add	x16, x16, #0xf68
    163c:	d61f0220 	br	x17

0000000000001640 <strcpy@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1644:	f947ba11 	ldr	x17, [x16, #3952]
    1648:	913dc210 	add	x16, x16, #0xf70
    164c:	d61f0220 	br	x17

0000000000001650 <sysconf@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1654:	f947be11 	ldr	x17, [x16, #3960]
    1658:	913de210 	add	x16, x16, #0xf78
    165c:	d61f0220 	br	x17

0000000000001660 <strstr@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1664:	f947c211 	ldr	x17, [x16, #3968]
    1668:	913e0210 	add	x16, x16, #0xf80
    166c:	d61f0220 	br	x17

0000000000001670 <_Exit@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1674:	f947c611 	ldr	x17, [x16, #3976]
    1678:	913e2210 	add	x16, x16, #0xf88
    167c:	d61f0220 	br	x17

0000000000001680 <pthread_join@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1684:	f947ca11 	ldr	x17, [x16, #3984]
    1688:	913e4210 	add	x16, x16, #0xf90
    168c:	d61f0220 	br	x17

0000000000001690 <getenv@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1694:	f947ce11 	ldr	x17, [x16, #3992]
    1698:	913e6210 	add	x16, x16, #0xf98
    169c:	d61f0220 	br	x17

00000000000016a0 <mprotect@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    16a4:	f947d211 	ldr	x17, [x16, #4000]
    16a8:	913e8210 	add	x16, x16, #0xfa0
    16ac:	d61f0220 	br	x17

00000000000016b0 <fgets@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    16b4:	f947d611 	ldr	x17, [x16, #4008]
    16b8:	913ea210 	add	x16, x16, #0xfa8
    16bc:	d61f0220 	br	x17

00000000000016c0 <pthread_attr_setstacksize@plt>:
    16c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    16c4:	f947da11 	ldr	x17, [x16, #4016]
    16c8:	913ec210 	add	x16, x16, #0xfb0
    16cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001700 <fwp_trap_overflow.constprop.0>:
    1700:	d10243ff 	sub	sp, sp, #0x90
    1704:	d2800c03 	mov	x3, #0x60                  	// #96
    1708:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    170c:	f947f421 	ldr	x1, [x1, #4072]
    1710:	90000045 	adrp	x5, 9000 <_IO_stdin_used+0x1e0>
    1714:	a9077bfd 	stp	x29, x30, [sp, #112]
    1718:	9101c3fd 	add	x29, sp, #0x70
    171c:	9101c0a5 	add	x5, x5, #0x70
    1720:	90000044 	adrp	x4, 9000 <_IO_stdin_used+0x1e0>
    1724:	f90043f3 	str	x19, [sp, #128]
    1728:	9101e084 	add	x4, x4, #0x78
    172c:	910023f3 	add	x19, sp, #0x8
    1730:	f9400022 	ldr	x2, [x1]
    1734:	f90037e2 	str	x2, [sp, #104]
    1738:	d2800002 	mov	x2, #0x0                   	// #0
    173c:	aa0303e1 	mov	x1, x3
    1740:	52800042 	mov	w2, #0x2                   	// #2
    1744:	aa1303e0 	mov	x0, x19
    1748:	97ffff4a 	bl	1470 <__snprintf_chk@plt>
    174c:	aa1303e0 	mov	x0, x19
    1750:	940002cc 	bl	2280 <fwp_trap>
    1754:	d503201f 	nop
    1758:	d503201f 	nop
    175c:	d503201f 	nop

0000000000001760 <main>:
    1760:	d10243ff 	sub	sp, sp, #0x90
    1764:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1768:	f947f400 	ldr	x0, [x0, #4072]
    176c:	a9067bfd 	stp	x29, x30, [sp, #96]
    1770:	910183fd 	add	x29, sp, #0x60
    1774:	a90753f3 	stp	x19, x20, [sp, #112]
    1778:	f00000f3 	adrp	x19, 20000 <__data_start>
    177c:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x14da0>
    1780:	f947ee94 	ldr	x20, [x20, #4056]
    1784:	f9400281 	ldr	x1, [x20]
    1788:	f90043f5 	str	x21, [sp, #128]
    178c:	f9400002 	ldr	x2, [x0]
    1790:	f9002fe2 	str	x2, [sp, #88]
    1794:	d2800002 	mov	x2, #0x0                   	// #0
    1798:	f9004a61 	str	x1, [x19, #144]
    179c:	940002c9 	bl	22c0 <fwp_now_ns>
    17a0:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    17a4:	910d4000 	add	x0, x0, #0x350
    17a8:	97ffffba 	bl	1690 <getenv@plt>
    17ac:	b4000080 	cbz	x0, 17bc <main+0x5c>
    17b0:	39400001 	ldrb	w1, [x0]
    17b4:	aa0003f5 	mov	x21, x0
    17b8:	35000801 	cbnz	w1, 18b8 <main+0x158>
    17bc:	910023e1 	add	x1, sp, #0x8
    17c0:	52800000 	mov	w0, #0x0                   	// #0
    17c4:	97ffff1b 	bl	1430 <clock_gettime@plt>
    17c8:	35000900 	cbnz	w0, 18e8 <main+0x188>
    17cc:	a9408be0 	ldp	x0, x2, [sp, #8]
    17d0:	d2994003 	mov	x3, #0xca00                	// #51712
    17d4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    17d8:	9b037c01 	mul	x1, x0, x3
    17dc:	9b437c00 	smulh	x0, x0, x3
    17e0:	ab020021 	adds	x1, x1, x2
    17e4:	937ffc42 	asr	x2, x2, #63
    17e8:	9a020000 	adc	x0, x0, x2
    17ec:	f100003f 	cmp	x1, #0x0
    17f0:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    17f4:	b50009a0 	cbnz	x0, 1928 <main+0x1c8>
    17f8:	f9400280 	ldr	x0, [x20]
    17fc:	d2a00023 	mov	x3, #0x10000               	// #65536
    1800:	52800002 	mov	w2, #0x0                   	// #0
    1804:	d2800001 	mov	x1, #0x0                   	// #0
    1808:	910063f5 	add	x21, sp, #0x18
    180c:	97ffff0d 	bl	1440 <setvbuf@plt>
    1810:	d2800021 	mov	x1, #0x1                   	// #1
    1814:	528001a0 	mov	w0, #0xd                   	// #13
    1818:	97ffff12 	bl	1460 <signal@plt>
    181c:	aa1503e0 	mov	x0, x21
    1820:	97fffefc 	bl	1410 <pthread_attr_init@plt>
    1824:	350007c0 	cbnz	w0, 191c <main+0x1bc>
    1828:	aa1503e0 	mov	x0, x21
    182c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    1830:	97ffffa4 	bl	16c0 <pthread_attr_setstacksize@plt>
    1834:	35000680 	cbnz	w0, 1904 <main+0x1a4>
    1838:	aa1503e1 	mov	x1, x21
    183c:	910023e0 	add	x0, sp, #0x8
    1840:	f0000022 	adrp	x2, 8000 <f0+0x2320>
    1844:	d2800003 	mov	x3, #0x0                   	// #0
    1848:	91054042 	add	x2, x2, #0x150
    184c:	97ffff71 	bl	1610 <pthread_create@plt>
    1850:	2a0003e1 	mov	w1, w0
    1854:	aa1503e0 	mov	x0, x21
    1858:	2a0103f5 	mov	w21, w1
    185c:	97ffff15 	bl	14b0 <pthread_attr_destroy@plt>
    1860:	350006a0 	cbnz	w0, 1934 <main+0x1d4>
    1864:	350004b5 	cbnz	w21, 18f8 <main+0x198>
    1868:	f94007e0 	ldr	x0, [sp, #8]
    186c:	d2800001 	mov	x1, #0x0                   	// #0
    1870:	97ffff84 	bl	1680 <pthread_join@plt>
    1874:	35000600 	cbnz	w0, 1934 <main+0x1d4>
    1878:	f9400280 	ldr	x0, [x20]
    187c:	91024273 	add	x19, x19, #0x90
    1880:	97ffff6c 	bl	1630 <fflush@plt>
    1884:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    1888:	f947f421 	ldr	x1, [x1, #4072]
    188c:	b942e260 	ldr	w0, [x19, #736]
    1890:	f9402fe3 	ldr	x3, [sp, #88]
    1894:	f9400022 	ldr	x2, [x1]
    1898:	eb020063 	subs	x3, x3, x2
    189c:	d2800002 	mov	x2, #0x0                   	// #0
    18a0:	540002a1 	b.ne	18f4 <main+0x194>  // b.any
    18a4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    18a8:	a94753f3 	ldp	x19, x20, [sp, #112]
    18ac:	f94043f5 	ldr	x21, [sp, #128]
    18b0:	910243ff 	add	sp, sp, #0x90
    18b4:	d65f03c0 	ret
    18b8:	910003e1 	mov	x1, sp
    18bc:	52800142 	mov	w2, #0xa                   	// #10
    18c0:	97ffff4c 	bl	15f0 <strtoull@plt>
    18c4:	f94003e0 	ldr	x0, [sp]
    18c8:	39400000 	ldrb	w0, [x0]
    18cc:	35fff780 	cbnz	w0, 17bc <main+0x5c>
    18d0:	394002a0 	ldrb	w0, [x21]
    18d4:	52801fa1 	mov	w1, #0xfd                  	// #253
    18d8:	5100ac00 	sub	w0, w0, #0x2b
    18dc:	6a01001f 	tst	w0, w1
    18e0:	54fff6e0 	b.eq	17bc <main+0x5c>  // b.none
    18e4:	17ffffc5 	b	17f8 <main+0x98>
    18e8:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    18ec:	910d8000 	add	x0, x0, #0x360
    18f0:	94000264 	bl	2280 <fwp_trap>
    18f4:	97ffff03 	bl	1500 <__stack_chk_fail@plt>
    18f8:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    18fc:	91100000 	add	x0, x0, #0x400
    1900:	94000260 	bl	2280 <fwp_trap>
    1904:	aa1503e0 	mov	x0, x21
    1908:	97fffeea 	bl	14b0 <pthread_attr_destroy@plt>
    190c:	35000140 	cbnz	w0, 1934 <main+0x1d4>
    1910:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    1914:	910f6000 	add	x0, x0, #0x3d8
    1918:	9400025a 	bl	2280 <fwp_trap>
    191c:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    1920:	910ea000 	add	x0, x0, #0x3a8
    1924:	94000257 	bl	2280 <fwp_trap>
    1928:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    192c:	910e0000 	add	x0, x0, #0x380
    1930:	94000254 	bl	2280 <fwp_trap>
    1934:	97ffff07 	bl	1550 <abort@plt>
    1938:	d503201f 	nop
    193c:	d503201f 	nop

0000000000001940 <_start>:
    1940:	d503201f 	nop
    1944:	d280001d 	mov	x29, #0x0                   	// #0
    1948:	d280001e 	mov	x30, #0x0                   	// #0
    194c:	aa0003e5 	mov	x5, x0
    1950:	f94003e1 	ldr	x1, [sp]
    1954:	910023e2 	add	x2, sp, #0x8
    1958:	910003e6 	mov	x6, sp
    195c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1960:	f947f800 	ldr	x0, [x0, #4080]
    1964:	d2800003 	mov	x3, #0x0                   	// #0
    1968:	d2800004 	mov	x4, #0x0                   	// #0
    196c:	97fffe95 	bl	13c0 <__libc_start_main@plt>
    1970:	97fffef8 	bl	1550 <abort@plt>

0000000000001974 <call_weak_fn>:
    1974:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1978:	f947f000 	ldr	x0, [x0, #4064]
    197c:	b4000040 	cbz	x0, 1984 <call_weak_fn+0x10>
    1980:	17fffeec 	b	1530 <__gmon_start__@plt>
    1984:	d65f03c0 	ret
    1988:	d503201f 	nop
    198c:	d503201f 	nop

0000000000001990 <deregister_tm_clones>:
    1990:	f00000e0 	adrp	x0, 20000 <__data_start>
    1994:	9101e000 	add	x0, x0, #0x78
    1998:	f00000e1 	adrp	x1, 20000 <__data_start>
    199c:	9101e021 	add	x1, x1, #0x78
    19a0:	eb00003f 	cmp	x1, x0
    19a4:	540000c0 	b.eq	19bc <deregister_tm_clones+0x2c>  // b.none
    19a8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    19ac:	f947e021 	ldr	x1, [x1, #4032]
    19b0:	b4000061 	cbz	x1, 19bc <deregister_tm_clones+0x2c>
    19b4:	aa0103f0 	mov	x16, x1
    19b8:	d61f0200 	br	x16
    19bc:	d65f03c0 	ret

00000000000019c0 <register_tm_clones>:
    19c0:	f00000e0 	adrp	x0, 20000 <__data_start>
    19c4:	9101e000 	add	x0, x0, #0x78
    19c8:	f00000e1 	adrp	x1, 20000 <__data_start>
    19cc:	9101e021 	add	x1, x1, #0x78
    19d0:	cb000021 	sub	x1, x1, x0
    19d4:	d37ffc22 	lsr	x2, x1, #63
    19d8:	8b810c41 	add	x1, x2, x1, asr #3
    19dc:	9341fc21 	asr	x1, x1, #1
    19e0:	b40000c1 	cbz	x1, 19f8 <register_tm_clones+0x38>
    19e4:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14da0>
    19e8:	f947fc42 	ldr	x2, [x2, #4088]
    19ec:	b4000062 	cbz	x2, 19f8 <register_tm_clones+0x38>
    19f0:	aa0203f0 	mov	x16, x2
    19f4:	d61f0200 	br	x16
    19f8:	d65f03c0 	ret
    19fc:	d503201f 	nop

0000000000001a00 <__do_global_dtors_aux>:
    1a00:	d503233f 	paciasp
    1a04:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1a08:	910003fd 	mov	x29, sp
    1a0c:	f9000bf3 	str	x19, [sp, #16]
    1a10:	f00000f3 	adrp	x19, 20000 <__data_start>
    1a14:	39420260 	ldrb	w0, [x19, #128]
    1a18:	37000140 	tbnz	w0, #0, 1a40 <__do_global_dtors_aux+0x40>
    1a1c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1a20:	f947e400 	ldr	x0, [x0, #4040]
    1a24:	b4000080 	cbz	x0, 1a34 <__do_global_dtors_aux+0x34>
    1a28:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a2c:	f9400400 	ldr	x0, [x0, #8]
    1a30:	97fffe70 	bl	13f0 <__cxa_finalize@plt>
    1a34:	97ffffd7 	bl	1990 <deregister_tm_clones>
    1a38:	52800020 	mov	w0, #0x1                   	// #1
    1a3c:	39020260 	strb	w0, [x19, #128]
    1a40:	f9400bf3 	ldr	x19, [sp, #16]
    1a44:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a48:	d50323bf 	autiasp
    1a4c:	d65f03c0 	ret

0000000000001a50 <frame_dummy>:
    1a50:	d503245f 	bti	c
    1a54:	17ffffdb 	b	19c0 <register_tm_clones>
    1a58:	d503201f 	nop
    1a5c:	d503201f 	nop

0000000000001a60 <fwp_fmt_u128>:
    1a60:	d10183ff 	sub	sp, sp, #0x60
    1a64:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    1a68:	f947f421 	ldr	x1, [x1, #4072]
    1a6c:	a9057bfd 	stp	x29, x30, [sp, #80]
    1a70:	910143fd 	add	x29, sp, #0x50
    1a74:	f9400024 	ldr	x4, [x1]
    1a78:	f90027e4 	str	x4, [sp, #72]
    1a7c:	d2800004 	mov	x4, #0x0                   	// #0
    1a80:	aa030041 	orr	x1, x2, x3
    1a84:	b5000361 	cbnz	x1, 1af0 <fwp_fmt_u128+0x90>
    1a88:	910023e9 	add	x9, sp, #0x8
    1a8c:	52800601 	mov	w1, #0x30                  	// #48
    1a90:	5280002d 	mov	w13, #0x1                   	// #1
    1a94:	390023e1 	strb	w1, [sp, #8]
    1a98:	93407dad 	sxtw	x13, w13
    1a9c:	aa0d03e1 	mov	x1, x13
    1aa0:	8b0d0004 	add	x4, x0, x13
    1aa4:	d503201f 	nop
    1aa8:	8b010123 	add	x3, x9, x1
    1aac:	cb0103e2 	neg	x2, x1
    1ab0:	d1000421 	sub	x1, x1, #0x1
    1ab4:	385ff063 	ldurb	w3, [x3, #-1]
    1ab8:	38226883 	strb	w3, [x4, x2]
    1abc:	35ffff61 	cbnz	w1, 1aa8 <fwp_fmt_u128+0x48>
    1ac0:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    1ac4:	f947f421 	ldr	x1, [x1, #4072]
    1ac8:	382d681f 	strb	wzr, [x0, x13]
    1acc:	aa0103e0 	mov	x0, x1
    1ad0:	f94027e2 	ldr	x2, [sp, #72]
    1ad4:	f9400001 	ldr	x1, [x0]
    1ad8:	eb010042 	subs	x2, x2, x1
    1adc:	d2800001 	mov	x1, #0x0                   	// #0
    1ae0:	54000561 	b.ne	1b8c <fwp_fmt_u128+0x12c>  // b.any
    1ae4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1ae8:	910183ff 	add	sp, sp, #0x60
    1aec:	d65f03c0 	ret
    1af0:	90000041 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    1af4:	9113c021 	add	x1, x1, #0x4f0
    1af8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1afc:	910023e9 	add	x9, sp, #0x8
    1b00:	d2800027 	mov	x7, #0x1                   	// #1
    1b04:	f29999af 	movk	x15, #0xcccd
    1b08:	a9402826 	ldp	x6, x10, [x1]
    1b0c:	d503201f 	nop
    1b10:	ab030041 	adds	x1, x2, x3
    1b14:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1b18:	aa0303eb 	mov	x11, x3
    1b1c:	8b070128 	add	x8, x9, x7
    1b20:	aa0203ee 	mov	x14, x2
    1b24:	aa0703ed 	mov	x13, x7
    1b28:	910004e7 	add	x7, x7, #0x1
    1b2c:	9bcf7c24 	umulh	x4, x1, x15
    1b30:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1b34:	8b4408a4 	add	x4, x5, x4, lsr #2
    1b38:	cb040021 	sub	x1, x1, x4
    1b3c:	eb010041 	subs	x1, x2, x1
    1b40:	da1f0063 	sbc	x3, x3, xzr
    1b44:	9bc67c24 	umulh	x4, x1, x6
    1b48:	9b061064 	madd	x4, x3, x6, x4
    1b4c:	9b067c2c 	mul	x12, x1, x6
    1b50:	9b0a1024 	madd	x4, x1, x10, x4
    1b54:	9bc67c25 	umulh	x5, x1, x6
    1b58:	9b061465 	madd	x5, x3, x6, x5
    1b5c:	9b0a1425 	madd	x5, x1, x10, x5
    1b60:	93cc0484 	extr	x4, x4, x12, #1
    1b64:	8b040884 	add	x4, x4, x4, lsl #2
    1b68:	d341fca3 	lsr	x3, x5, #1
    1b6c:	cb040444 	sub	x4, x2, x4, lsl #1
    1b70:	93cc04a2 	extr	x2, x5, x12, #1
    1b74:	1100c084 	add	w4, w4, #0x30
    1b78:	381ff104 	sturb	w4, [x8, #-1]
    1b7c:	b5fffcab 	cbnz	x11, 1b10 <fwp_fmt_u128+0xb0>
    1b80:	f10025df 	cmp	x14, #0x9
    1b84:	54fffc68 	b.hi	1b10 <fwp_fmt_u128+0xb0>  // b.pmore
    1b88:	17ffffc4 	b	1a98 <fwp_fmt_u128+0x38>
    1b8c:	97fffe5d 	bl	1500 <__stack_chk_fail@plt>

0000000000001b90 <fwp_range_release>:
    1b90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b94:	910003fd 	mov	x29, sp
    1b98:	f9400801 	ldr	x1, [x0, #16]
    1b9c:	f9000bf3 	str	x19, [sp, #16]
    1ba0:	aa0003f3 	mov	x19, x0
    1ba4:	b4000061 	cbz	x1, 1bb0 <fwp_range_release+0x20>
    1ba8:	f9400400 	ldr	x0, [x0, #8]
    1bac:	d63f0020 	blr	x1
    1bb0:	f9400260 	ldr	x0, [x19]
    1bb4:	f9400e61 	ldr	x1, [x19, #24]
    1bb8:	f9400bf3 	ldr	x19, [sp, #16]
    1bbc:	aa0103f0 	mov	x16, x1
    1bc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1bc4:	d61f0200 	br	x16
    1bc8:	d503201f 	nop
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_flush>:
    1bd0:	f00000e0 	adrp	x0, 20000 <__data_start>
    1bd4:	f9404800 	ldr	x0, [x0, #144]
    1bd8:	b4000120 	cbz	x0, 1bfc <fwp_flush+0x2c>
    1bdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1be0:	910003fd 	mov	x29, sp
    1be4:	97fffe93 	bl	1630 <fflush@plt>
    1be8:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1bec:	f947ec00 	ldr	x0, [x0, #4056]
    1bf0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1bf4:	f9400000 	ldr	x0, [x0]
    1bf8:	17fffe8e 	b	1630 <fflush@plt>
    1bfc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1c00:	f947ec00 	ldr	x0, [x0, #4056]
    1c04:	f9400000 	ldr	x0, [x0]
    1c08:	17fffe8a 	b	1630 <fflush@plt>
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_segv>:
    1c10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c14:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c18:	91024043 	add	x3, x2, #0x90
    1c1c:	910003fd 	mov	x29, sp
    1c20:	a90153f3 	stp	x19, x20, [sp, #16]
    1c24:	2a0003f3 	mov	w19, w0
    1c28:	f9400460 	ldr	x0, [x3, #8]
    1c2c:	f90013f5 	str	x21, [sp, #32]
    1c30:	f9400835 	ldr	x21, [x1, #16]
    1c34:	b4000280 	cbz	x0, 1c84 <fwp_segv+0x74>
    1c38:	f9400814 	ldr	x20, [x0, #16]
    1c3c:	b4000254 	cbz	x20, 1c84 <fwp_segv+0x74>
    1c40:	528003c0 	mov	w0, #0x1e                  	// #30
    1c44:	97fffe83 	bl	1650 <sysconf@plt>
    1c48:	f144029f 	cmp	x20, #0x100, lsl #12
    1c4c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c50:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c54:	8b000294 	add	x20, x20, x0
    1c58:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c5c:	eb0102bf 	cmp	x21, x1
    1c60:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1c64:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c68:	35000240 	cbnz	w0, 1cb0 <fwp_segv+0xa0>
    1c6c:	f94013f5 	ldr	x21, [sp, #32]
    1c70:	2a1303e0 	mov	w0, w19
    1c74:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c78:	d2800001 	mov	x1, #0x0                   	// #0
    1c7c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c80:	17fffdf8 	b	1460 <signal@plt>
    1c84:	91024042 	add	x2, x2, #0x90
    1c88:	f9400840 	ldr	x0, [x2, #16]
    1c8c:	b4ffff00 	cbz	x0, 1c6c <fwp_segv+0x5c>
    1c90:	f9400c41 	ldr	x1, [x2, #24]
    1c94:	cb010000 	sub	x0, x0, x1
    1c98:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1c9c:	91440000 	add	x0, x0, #0x100, lsl #12
    1ca0:	eb15003f 	cmp	x1, x21
    1ca4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1ca8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1cac:	34fffe00 	cbz	w0, 1c6c <fwp_segv+0x5c>
    1cb0:	97ffffc8 	bl	1bd0 <fwp_flush>
    1cb4:	90000041 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    1cb8:	91134021 	add	x1, x1, #0x4d0
    1cbc:	d2800342 	mov	x2, #0x1a                  	// #26
    1cc0:	52800040 	mov	w0, #0x2                   	// #2
    1cc4:	97fffe1f 	bl	1540 <write@plt>
    1cc8:	52800ca0 	mov	w0, #0x65                  	// #101
    1ccc:	97fffdad 	bl	1380 <_exit@plt>

0000000000001cd0 <fwp_heap_oom>:
    1cd0:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14da0>
    1cd4:	f947e863 	ldr	x3, [x3, #4048]
    1cd8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1cdc:	d2800262 	mov	x2, #0x13                  	// #19
    1ce0:	910003fd 	mov	x29, sp
    1ce4:	f9400063 	ldr	x3, [x3]
    1ce8:	d2800021 	mov	x1, #0x1                   	// #1
    1cec:	f0000020 	adrp	x0, 8000 <f0+0x2320>
    1cf0:	9138a000 	add	x0, x0, #0xe28
    1cf4:	97fffe43 	bl	1600 <fwrite@plt>
    1cf8:	d2800000 	mov	x0, #0x0                   	// #0
    1cfc:	97fffe4d 	bl	1630 <fflush@plt>
    1d00:	52800cc0 	mov	w0, #0x66                  	// #102
    1d04:	97fffe5b 	bl	1670 <_Exit@plt>
    1d08:	d503201f 	nop
    1d0c:	d503201f 	nop

0000000000001d10 <fwp_heap_chunks>:
    1d10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d14:	910003fd 	mov	x29, sp
    1d18:	a90153f3 	stp	x19, x20, [sp, #16]
    1d1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1d20:	90000195 	adrp	x21, 31000 <fwp_root_context+0xc70>
    1d24:	9115c2a1 	add	x1, x21, #0x570
    1d28:	f100041f 	cmp	x0, #0x1
    1d2c:	54000ca0 	b.eq	1ec0 <fwp_heap_chunks+0x1b0>  // b.none
    1d30:	f949f822 	ldr	x2, [x1, #5104]
    1d34:	b0000185 	adrp	x5, 32000 <fwp_heap+0xa90>
    1d38:	912580a5 	add	x5, x5, #0x960
    1d3c:	9115c2a1 	add	x1, x21, #0x570
    1d40:	f949ec34 	ldr	x20, [x1, #5080]
    1d44:	eb14005f 	cmp	x2, x20
    1d48:	54000c42 	b.cs	1ed0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1d4c:	f949fc23 	ldr	x3, [x1, #5112]
    1d50:	8b020841 	add	x1, x2, x2, lsl #2
    1d54:	d2800004 	mov	x4, #0x0                   	// #0
    1d58:	8b010c61 	add	x1, x3, x1, lsl #3
    1d5c:	14000009 	b	1d80 <fwp_heap_chunks+0x70>
    1d60:	91000483 	add	x3, x4, #0x1
    1d64:	eb03001f 	cmp	x0, x3
    1d68:	54000940 	b.eq	1e90 <fwp_heap_chunks+0x180>  // b.none
    1d6c:	91000442 	add	x2, x2, #0x1
    1d70:	aa0303e4 	mov	x4, x3
    1d74:	9100a021 	add	x1, x1, #0x28
    1d78:	eb02029f 	cmp	x20, x2
    1d7c:	54000100 	b.eq	1d9c <fwp_heap_chunks+0x8c>  // b.none
    1d80:	39400023 	ldrb	w3, [x1]
    1d84:	34fffee3 	cbz	w3, 1d60 <fwp_heap_chunks+0x50>
    1d88:	91000442 	add	x2, x2, #0x1
    1d8c:	9100a021 	add	x1, x1, #0x28
    1d90:	d2800004 	mov	x4, #0x0                   	// #0
    1d94:	eb02029f 	cmp	x20, x2
    1d98:	54ffff41 	b.ne	1d80 <fwp_heap_chunks+0x70>  // b.any
    1d9c:	cb040294 	sub	x20, x20, x4
    1da0:	f9001bf7 	str	x23, [sp, #48]
    1da4:	9115c2b7 	add	x23, x21, #0x570
    1da8:	8b140013 	add	x19, x0, x20
    1dac:	f94a1ae1 	ldr	x1, [x23, #5168]
    1db0:	f949f2e0 	ldr	x0, [x23, #5088]
    1db4:	cb040021 	sub	x1, x1, x4
    1db8:	f90a1ae1 	str	x1, [x23, #5168]
    1dbc:	eb00027f 	cmp	x19, x0
    1dc0:	54000429 	b.ls	1e44 <fwp_heap_chunks+0x134>  // b.plast
    1dc4:	f949eae1 	ldr	x1, [x23, #5072]
    1dc8:	eb01027f 	cmp	x19, x1
    1dcc:	54000888 	b.hi	1edc <fwp_heap_chunks+0x1cc>  // b.pmore
    1dd0:	91010276 	add	x22, x19, #0x40
    1dd4:	52800062 	mov	w2, #0x3                   	// #3
    1dd8:	f949dae3 	ldr	x3, [x23, #5040]
    1ddc:	eb0102df 	cmp	x22, x1
    1de0:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1de4:	cb0002c1 	sub	x1, x22, x0
    1de8:	8b004060 	add	x0, x3, x0, lsl #16
    1dec:	d370bc21 	lsl	x1, x1, #16
    1df0:	97fffe2c 	bl	16a0 <mprotect@plt>
    1df4:	35000740 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1df8:	528003c0 	mov	w0, #0x1e                  	// #30
    1dfc:	97fffe15 	bl	1650 <sysconf@plt>
    1e00:	f949f2e2 	ldr	x2, [x23, #5088]
    1e04:	cb0003e5 	neg	x5, x0
    1e08:	aa0003e4 	mov	x4, x0
    1e0c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e10:	f949fee0 	ldr	x0, [x23, #5112]
    1e14:	8b020843 	add	x3, x2, x2, lsl #2
    1e18:	52800062 	mov	w2, #0x3                   	// #3
    1e1c:	8b010c01 	add	x1, x0, x1, lsl #3
    1e20:	8b030c03 	add	x3, x0, x3, lsl #3
    1e24:	d1000421 	sub	x1, x1, #0x1
    1e28:	8a050060 	and	x0, x3, x5
    1e2c:	8b040021 	add	x1, x1, x4
    1e30:	8a050021 	and	x1, x1, x5
    1e34:	cb000021 	sub	x1, x1, x0
    1e38:	97fffe1a 	bl	16a0 <mprotect@plt>
    1e3c:	35000500 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1e40:	f909f2f6 	str	x22, [x23, #5088]
    1e44:	9115c2b5 	add	x21, x21, #0x570
    1e48:	d370be60 	lsl	x0, x19, #16
    1e4c:	f949e6a1 	ldr	x1, [x21, #5064]
    1e50:	f909eeb3 	str	x19, [x21, #5080]
    1e54:	eb01001f 	cmp	x0, x1
    1e58:	540000e8 	b.hi	1e74 <fwp_heap_chunks+0x164>  // b.pmore
    1e5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e60:	aa1403e0 	mov	x0, x20
    1e64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e68:	f9401bf7 	ldr	x23, [sp, #48]
    1e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e70:	d65f03c0 	ret
    1e74:	f9401bf7 	ldr	x23, [sp, #48]
    1e78:	f909e6a0 	str	x0, [x21, #5064]
    1e7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e80:	aa1403e0 	mov	x0, x20
    1e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e88:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e8c:	d65f03c0 	ret
    1e90:	9115c2b5 	add	x21, x21, #0x570
    1e94:	91000441 	add	x1, x2, #0x1
    1e98:	f90000a1 	str	x1, [x5]
    1e9c:	cb040054 	sub	x20, x2, x4
    1ea0:	f94a1aa1 	ldr	x1, [x21, #5168]
    1ea4:	cb000020 	sub	x0, x1, x0
    1ea8:	f90a1aa0 	str	x0, [x21, #5168]
    1eac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1eb0:	aa1403e0 	mov	x0, x20
    1eb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1eb8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ebc:	d65f03c0 	ret
    1ec0:	f949f422 	ldr	x2, [x1, #5096]
    1ec4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xa90>
    1ec8:	912560a5 	add	x5, x5, #0x958
    1ecc:	17ffff9c 	b	1d3c <fwp_heap_chunks+0x2c>
    1ed0:	d2800004 	mov	x4, #0x0                   	// #0
    1ed4:	f9001bf7 	str	x23, [sp, #48]
    1ed8:	17ffffb3 	b	1da4 <fwp_heap_chunks+0x94>
    1edc:	97ffff7d 	bl	1cd0 <fwp_heap_oom>

0000000000001ee0 <ad_raw_fail>:
    1ee0:	d00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x14da0>
    1ee4:	f947e884 	ldr	x4, [x4, #4048]
    1ee8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1eec:	aa0003e3 	mov	x3, x0
    1ef0:	910003fd 	mov	x29, sp
    1ef4:	f9400080 	ldr	x0, [x4]
    1ef8:	f0000022 	adrp	x2, 8000 <f0+0x2320>
    1efc:	91390042 	add	x2, x2, #0xe40
    1f00:	52800041 	mov	w1, #0x2                   	// #2
    1f04:	97fffd9b 	bl	1570 <__fprintf_chk@plt>
    1f08:	52801d00 	mov	w0, #0xe8                  	// #232
    1f0c:	97fffd29 	bl	13b0 <exit@plt>

0000000000001f10 <ad_raw_report>:
    1f10:	d101c3ff 	sub	sp, sp, #0x70
    1f14:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f18:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14da0>
    1f1c:	f947f463 	ldr	x3, [x3, #4072]
    1f20:	f0000022 	adrp	x2, 8000 <f0+0x2320>
    1f24:	a9037bfd 	stp	x29, x30, [sp, #48]
    1f28:	9100c3fd 	add	x29, sp, #0x30
    1f2c:	9139c042 	add	x2, x2, #0xe70
    1f30:	d2800005 	mov	x5, #0x0                   	// #0
    1f34:	a9055bf5 	stp	x21, x22, [sp, #80]
    1f38:	f0000036 	adrp	x22, 8000 <f0+0x2320>
    1f3c:	913b42d6 	add	x22, x22, #0xed0
    1f40:	d00000f5 	adrp	x21, 1f000 <__FRAME_END__+0x14da0>
    1f44:	f947eab5 	ldr	x21, [x21, #4048]
    1f48:	a90453f3 	stp	x19, x20, [sp, #64]
    1f4c:	52800013 	mov	w19, #0x0                   	// #0
    1f50:	f94002a0 	ldr	x0, [x21]
    1f54:	f90033f7 	str	x23, [sp, #96]
    1f58:	f0000037 	adrp	x23, 8000 <f0+0x2320>
    1f5c:	9139a2f7 	add	x23, x23, #0xe68
    1f60:	f9400064 	ldr	x4, [x3]
    1f64:	f90017e4 	str	x4, [sp, #40]
    1f68:	d2800004 	mov	x4, #0x0                   	// #0
    1f6c:	d2800003 	mov	x3, #0x0                   	// #0
    1f70:	f9405824 	ldr	x4, [x1, #176]
    1f74:	52800041 	mov	w1, #0x2                   	// #2
    1f78:	97fffd7e 	bl	1570 <__fprintf_chk@plt>
    1f7c:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f80:	91004021 	add	x1, x1, #0x10
    1f84:	f94002a0 	ldr	x0, [x21]
    1f88:	910023e2 	add	x2, sp, #0x8
    1f8c:	4c40a020 	ld1	{v0.16b-v1.16b}, [x1]
    1f90:	f0000023 	adrp	x3, 8000 <f0+0x2320>
    1f94:	aa0203f4 	mov	x20, x2
    1f98:	91398063 	add	x3, x3, #0xe60
    1f9c:	4c00a040 	st1	{v0.16b-v1.16b}, [x2]
    1fa0:	aa1603e2 	mov	x2, x22
    1fa4:	f8408684 	ldr	x4, [x20], #8
    1fa8:	d2800007 	mov	x7, #0x0                   	// #0
    1fac:	d2800006 	mov	x6, #0x0                   	// #0
    1fb0:	d2800005 	mov	x5, #0x0                   	// #0
    1fb4:	52800041 	mov	w1, #0x2                   	// #2
    1fb8:	11000673 	add	w19, w19, #0x1
    1fbc:	97fffd6d 	bl	1570 <__fprintf_chk@plt>
    1fc0:	7100127f 	cmp	w19, #0x4
    1fc4:	54000080 	b.eq	1fd4 <ad_raw_report+0xc4>  // b.none
    1fc8:	f94002a0 	ldr	x0, [x21]
    1fcc:	aa1703e3 	mov	x3, x23
    1fd0:	17fffff4 	b	1fa0 <ad_raw_report+0x90>
    1fd4:	f94002a3 	ldr	x3, [x21]
    1fd8:	d2800262 	mov	x2, #0x13                  	// #19
    1fdc:	d2800021 	mov	x1, #0x1                   	// #1
    1fe0:	f0000020 	adrp	x0, 8000 <f0+0x2320>
    1fe4:	913c4000 	add	x0, x0, #0xf10
    1fe8:	97fffd86 	bl	1600 <fwrite@plt>
    1fec:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1ff0:	f947f400 	ldr	x0, [x0, #4072]
    1ff4:	f94017e2 	ldr	x2, [sp, #40]
    1ff8:	f9400001 	ldr	x1, [x0]
    1ffc:	eb010042 	subs	x2, x2, x1
    2000:	d2800001 	mov	x1, #0x0                   	// #0
    2004:	54000181 	b.ne	2034 <ad_raw_report+0x124>  // b.any
    2008:	f94002a3 	ldr	x3, [x21]
    200c:	d0000020 	adrp	x0, 8000 <f0+0x2320>
    2010:	a9437bfd 	ldp	x29, x30, [sp, #48]
    2014:	913ca000 	add	x0, x0, #0xf28
    2018:	a94453f3 	ldp	x19, x20, [sp, #64]
    201c:	d2800082 	mov	x2, #0x4                   	// #4
    2020:	a9455bf5 	ldp	x21, x22, [sp, #80]
    2024:	d2800021 	mov	x1, #0x1                   	// #1
    2028:	f94033f7 	ldr	x23, [sp, #96]
    202c:	9101c3ff 	add	sp, sp, #0x70
    2030:	17fffd74 	b	1600 <fwrite@plt>
    2034:	97fffd33 	bl	1500 <__stack_chk_fail@plt>
    2038:	d503201f 	nop
    203c:	d503201f 	nop

0000000000002040 <buf_grow>:
    2040:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2044:	910003fd 	mov	x29, sp
    2048:	a90153f3 	stp	x19, x20, [sp, #16]
    204c:	aa0003f4 	mov	x20, x0
    2050:	f9400400 	ldr	x0, [x0, #8]
    2054:	b100041f 	cmn	x0, #0x1
    2058:	54000400 	b.eq	20d8 <buf_grow+0x98>  // b.none
    205c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    2060:	cb000042 	sub	x2, x2, x0
    2064:	eb01005f 	cmp	x2, x1
    2068:	54000383 	b.cc	20d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    206c:	f9400a82 	ldr	x2, [x20, #16]
    2070:	91000421 	add	x1, x1, #0x1
    2074:	8b000033 	add	x19, x1, x0
    2078:	eb13005f 	cmp	x2, x19
    207c:	54000242 	b.cs	20c4 <buf_grow+0x84>  // b.hs, b.nlast
    2080:	f100005f 	cmp	x2, #0x0
    2084:	b5000262 	cbnz	x2, 20d0 <buf_grow+0x90>
    2088:	d2800802 	mov	x2, #0x40                  	// #64
    208c:	eb02027f 	cmp	x19, x2
    2090:	54000068 	b.hi	209c <buf_grow+0x5c>  // b.pmore
    2094:	14000005 	b	20a8 <buf_grow+0x68>
    2098:	b7f800a2 	tbnz	x2, #63, 20ac <buf_grow+0x6c>
    209c:	d37ff842 	lsl	x2, x2, #1
    20a0:	eb02027f 	cmp	x19, x2
    20a4:	54ffffa8 	b.hi	2098 <buf_grow+0x58>  // b.pmore
    20a8:	aa0203f3 	mov	x19, x2
    20ac:	f9400280 	ldr	x0, [x20]
    20b0:	aa1303e1 	mov	x1, x19
    20b4:	97fffd0f 	bl	14f0 <realloc@plt>
    20b8:	b4000100 	cbz	x0, 20d8 <buf_grow+0x98>
    20bc:	f9000280 	str	x0, [x20]
    20c0:	f9000a93 	str	x19, [x20, #16]
    20c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    20c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    20cc:	d65f03c0 	ret
    20d0:	54fffe6a 	b.ge	209c <buf_grow+0x5c>  // b.tcont
    20d4:	17fffff6 	b	20ac <buf_grow+0x6c>
    20d8:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14da0>
    20dc:	f947e863 	ldr	x3, [x3, #4048]
    20e0:	d2800262 	mov	x2, #0x13                  	// #19
    20e4:	d2800021 	mov	x1, #0x1                   	// #1
    20e8:	d0000020 	adrp	x0, 8000 <f0+0x2320>
    20ec:	9138a000 	add	x0, x0, #0xe28
    20f0:	f9400063 	ldr	x3, [x3]
    20f4:	97fffd43 	bl	1600 <fwrite@plt>
    20f8:	d2800000 	mov	x0, #0x0                   	// #0
    20fc:	97fffd4d 	bl	1630 <fflush@plt>
    2100:	52800cc0 	mov	w0, #0x66                  	// #102
    2104:	97fffd5b 	bl	1670 <_Exit@plt>
    2108:	d503201f 	nop
    210c:	d503201f 	nop

0000000000002110 <buf_put>:
    2110:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2114:	910003fd 	mov	x29, sp
    2118:	a90153f3 	stp	x19, x20, [sp, #16]
    211c:	aa0003f4 	mov	x20, x0
    2120:	aa0203f3 	mov	x19, x2
    2124:	f90013f5 	str	x21, [sp, #32]
    2128:	aa0103f5 	mov	x21, x1
    212c:	aa0203e1 	mov	x1, x2
    2130:	97ffffc4 	bl	2040 <buf_grow>
    2134:	a9400283 	ldp	x3, x0, [x20]
    2138:	aa1503e1 	mov	x1, x21
    213c:	aa1303e2 	mov	x2, x19
    2140:	8b000060 	add	x0, x3, x0
    2144:	97fffc87 	bl	1360 <memcpy@plt>
    2148:	a9400680 	ldp	x0, x1, [x20]
    214c:	8b010273 	add	x19, x19, x1
    2150:	f9000693 	str	x19, [x20, #8]
    2154:	3833681f 	strb	wzr, [x0, x19]
    2158:	a94153f3 	ldp	x19, x20, [sp, #16]
    215c:	f94013f5 	ldr	x21, [sp, #32]
    2160:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2164:	d65f03c0 	ret
    2168:	d503201f 	nop
    216c:	d503201f 	nop

0000000000002170 <fwp_cancel_tree.part.0>:
    2170:	d00000e1 	adrp	x1, 20000 <__data_start>
    2174:	91024022 	add	x2, x1, #0x90
    2178:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    217c:	52800023 	mov	w3, #0x1                   	// #1
    2180:	910003fd 	mov	x29, sp
    2184:	f9400444 	ldr	x4, [x2, #8]
    2188:	f9000bf3 	str	x19, [sp, #16]
    218c:	39014403 	strb	w3, [x0, #81]
    2190:	eb04001f 	cmp	x0, x4
    2194:	54000160 	b.eq	21c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    2198:	f9402804 	ldr	x4, [x0, #80]
    219c:	f2001c9f 	tst	x4, #0xff000000ff
    21a0:	54000101 	b.ne	21c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    21a4:	f9401444 	ldr	x4, [x2, #40]
    21a8:	39015003 	strb	w3, [x0, #84]
    21ac:	f900801f 	str	xzr, [x0, #256]
    21b0:	b40001e4 	cbz	x4, 21ec <fwp_cancel_tree.part.0+0x7c>
    21b4:	f9008080 	str	x0, [x4, #256]
    21b8:	91024021 	add	x1, x1, #0x90
    21bc:	f9001420 	str	x0, [x1, #40]
    21c0:	f9401413 	ldr	x19, [x0, #40]
    21c4:	b40000f3 	cbz	x19, 21e0 <fwp_cancel_tree.part.0+0x70>
    21c8:	39414261 	ldrb	w1, [x19, #80]
    21cc:	aa1303e0 	mov	x0, x19
    21d0:	37000041 	tbnz	w1, #0, 21d8 <fwp_cancel_tree.part.0+0x68>
    21d4:	97ffffe7 	bl	2170 <fwp_cancel_tree.part.0>
    21d8:	f9401a73 	ldr	x19, [x19, #48]
    21dc:	b5ffff73 	cbnz	x19, 21c8 <fwp_cancel_tree.part.0+0x58>
    21e0:	f9400bf3 	ldr	x19, [sp, #16]
    21e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    21e8:	d65f03c0 	ret
    21ec:	f9001840 	str	x0, [x2, #48]
    21f0:	17fffff2 	b	21b8 <fwp_cancel_tree.part.0+0x48>

00000000000021f4 <fwp_finish_float>:
    21f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    21f8:	528005c1 	mov	w1, #0x2e                  	// #46
    21fc:	910003fd 	mov	x29, sp
    2200:	f9000bf3 	str	x19, [sp, #16]
    2204:	aa0003f3 	mov	x19, x0
    2208:	97fffcf6 	bl	15e0 <strchr@plt>
    220c:	b4000080 	cbz	x0, 221c <fwp_finish_float+0x28>
    2210:	f9400bf3 	ldr	x19, [sp, #16]
    2214:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2218:	d65f03c0 	ret
    221c:	aa1303e0 	mov	x0, x19
    2220:	52800ca1 	mov	w1, #0x65                  	// #101
    2224:	97fffcef 	bl	15e0 <strchr@plt>
    2228:	b5ffff40 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    222c:	d0000021 	adrp	x1, 8000 <f0+0x2320>
    2230:	aa1303e0 	mov	x0, x19
    2234:	913cc021 	add	x1, x1, #0xf30
    2238:	97fffd0a 	bl	1660 <strstr@plt>
    223c:	b5fffea0 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2240:	d0000021 	adrp	x1, 8000 <f0+0x2320>
    2244:	aa1303e0 	mov	x0, x19
    2248:	913ce021 	add	x1, x1, #0xf38
    224c:	97fffd05 	bl	1660 <strstr@plt>
    2250:	b5fffe00 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2254:	aa1303e0 	mov	x0, x19
    2258:	97fffc4e 	bl	1390 <strlen@plt>
    225c:	d0000021 	adrp	x1, 8000 <f0+0x2320>
    2260:	913d0021 	add	x1, x1, #0xf40
    2264:	8b000262 	add	x2, x19, x0
    2268:	79400023 	ldrh	w3, [x1]
    226c:	39400821 	ldrb	w1, [x1, #2]
    2270:	78206a63 	strh	w3, [x19, x0]
    2274:	39000841 	strb	w1, [x2, #2]
    2278:	17ffffe6 	b	2210 <fwp_finish_float+0x1c>
    227c:	d503201f 	nop

0000000000002280 <fwp_trap>:
    2280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2284:	910003fd 	mov	x29, sp
    2288:	f9000bf3 	str	x19, [sp, #16]
    228c:	aa0003f3 	mov	x19, x0
    2290:	97fffe50 	bl	1bd0 <fwp_flush>
    2294:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x14da0>
    2298:	f947e884 	ldr	x4, [x4, #4048]
    229c:	aa1303e3 	mov	x3, x19
    22a0:	d0000022 	adrp	x2, 8000 <f0+0x2320>
    22a4:	913d2042 	add	x2, x2, #0xf48
    22a8:	52800041 	mov	w1, #0x2                   	// #2
    22ac:	f9400080 	ldr	x0, [x4]
    22b0:	97fffcb0 	bl	1570 <__fprintf_chk@plt>
    22b4:	52800ca0 	mov	w0, #0x65                  	// #101
    22b8:	97fffc3e 	bl	13b0 <exit@plt>
    22bc:	d503201f 	nop

00000000000022c0 <fwp_now_ns>:
    22c0:	d100c3ff 	sub	sp, sp, #0x30
    22c4:	52800020 	mov	w0, #0x1                   	// #1
    22c8:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14da0>
    22cc:	f947f442 	ldr	x2, [x2, #4072]
    22d0:	910023e1 	add	x1, sp, #0x8
    22d4:	a9027bfd 	stp	x29, x30, [sp, #32]
    22d8:	910083fd 	add	x29, sp, #0x20
    22dc:	f9400043 	ldr	x3, [x2]
    22e0:	f9000fe3 	str	x3, [sp, #24]
    22e4:	d2800003 	mov	x3, #0x0                   	// #0
    22e8:	97fffc52 	bl	1430 <clock_gettime@plt>
    22ec:	350002c0 	cbnz	w0, 2344 <fwp_now_ns+0x84>
    22f0:	a9408be1 	ldp	x1, x2, [sp, #8]
    22f4:	d2994003 	mov	x3, #0xca00                	// #51712
    22f8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    22fc:	9b037c20 	mul	x0, x1, x3
    2300:	9b437c21 	smulh	x1, x1, x3
    2304:	ab020000 	adds	x0, x0, x2
    2308:	937ffc42 	asr	x2, x2, #63
    230c:	9a020021 	adc	x1, x1, x2
    2310:	f100001f 	cmp	x0, #0x0
    2314:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2318:	b50001e1 	cbnz	x1, 2354 <fwp_now_ns+0x94>
    231c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    2320:	f947f421 	ldr	x1, [x1, #4072]
    2324:	f9400fe3 	ldr	x3, [sp, #24]
    2328:	f9400022 	ldr	x2, [x1]
    232c:	eb020063 	subs	x3, x3, x2
    2330:	d2800002 	mov	x2, #0x0                   	// #0
    2334:	540000e1 	b.ne	2350 <fwp_now_ns+0x90>  // b.any
    2338:	a9427bfd 	ldp	x29, x30, [sp, #32]
    233c:	9100c3ff 	add	sp, sp, #0x30
    2340:	d65f03c0 	ret
    2344:	d0000020 	adrp	x0, 8000 <f0+0x2320>
    2348:	913d6000 	add	x0, x0, #0xf58
    234c:	97ffffcd 	bl	2280 <fwp_trap>
    2350:	97fffc6c 	bl	1500 <__stack_chk_fail@plt>
    2354:	d0000020 	adrp	x0, 8000 <f0+0x2320>
    2358:	913de000 	add	x0, x0, #0xf78
    235c:	97ffffc9 	bl	2280 <fwp_trap>

0000000000002360 <fwp_format_g.constprop.0>:
    2360:	d10483ff 	sub	sp, sp, #0x120
    2364:	d0000024 	adrp	x4, 8000 <f0+0x2320>
    2368:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14da0>
    236c:	f947f442 	ldr	x2, [x2, #4072]
    2370:	913e8084 	add	x4, x4, #0xfa0
    2374:	a90b7bfd 	stp	x29, x30, [sp, #176]
    2378:	9102c3fd 	add	x29, sp, #0xb0
    237c:	d2800803 	mov	x3, #0x40                  	// #64
    2380:	a90e63f7 	stp	x23, x24, [sp, #224]
    2384:	93407c38 	sxtw	x24, w1
    2388:	aa0303e1 	mov	x1, x3
    238c:	fd008be8 	str	d8, [sp, #272]
    2390:	1e604008 	fmov	d8, d0
    2394:	a90c53f3 	stp	x19, x20, [sp, #192]
    2398:	910083f4 	add	x20, sp, #0x20
    239c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    23a0:	aa0003f5 	mov	x21, x0
    23a4:	a91073fb 	stp	x27, x28, [sp, #256]
    23a8:	5100071c 	sub	w28, w24, #0x1
    23ac:	2a1c03e5 	mov	w5, w28
    23b0:	f9400040 	ldr	x0, [x2]
    23b4:	f90057e0 	str	x0, [sp, #168]
    23b8:	d2800000 	mov	x0, #0x0                   	// #0
    23bc:	52800042 	mov	w2, #0x2                   	// #2
    23c0:	aa1403e0 	mov	x0, x20
    23c4:	97fffc2b 	bl	1470 <__snprintf_chk@plt>
    23c8:	52800ca1 	mov	w1, #0x65                  	// #101
    23cc:	aa1403e0 	mov	x0, x20
    23d0:	97fffc84 	bl	15e0 <strchr@plt>
    23d4:	aa0003f3 	mov	x19, x0
    23d8:	52800142 	mov	w2, #0xa                   	// #10
    23dc:	91000400 	add	x0, x0, #0x1
    23e0:	d2800001 	mov	x1, #0x0                   	// #0
    23e4:	97fffc6f 	bl	15a0 <strtol@plt>
    23e8:	aa0003f7 	mov	x23, x0
    23ec:	11001400 	add	w0, w0, #0x5
    23f0:	7100541f 	cmp	w0, #0x15
    23f4:	54000d68 	b.hi	25a0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    23f8:	4b170385 	sub	w5, w28, w23
    23fc:	710000bf 	cmp	w5, #0x0
    2400:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2404:	54000b80 	b.eq	2574 <fwp_format_g.constprop.0+0x214>  // b.none
    2408:	394083e0 	ldrb	w0, [sp, #32]
    240c:	cb180273 	sub	x19, x19, x24
    2410:	91000673 	add	x19, x19, #0x1
    2414:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2418:	7100b41f 	cmp	w0, #0x2d
    241c:	9a941681 	cinc	x1, x20, eq	// eq = none
    2420:	1a9f17e4 	cset	w4, eq	// eq = none
    2424:	cb010266 	sub	x6, x19, x1
    2428:	d10004da 	sub	x26, x6, #0x1
    242c:	540018a0 	b.eq	2740 <fwp_format_g.constprop.0+0x3e0>  // b.none
    2430:	910183f9 	add	x25, sp, #0x60
    2434:	d280091b 	mov	x27, #0x48                  	// #72
    2438:	aa1903e7 	mov	x7, x25
    243c:	91000423 	add	x3, x1, #0x1
    2440:	91011cc6 	add	x6, x6, #0x47
    2444:	910004f6 	add	x22, x7, #0x1
    2448:	37f80ff7 	tbnz	w23, #31, 2644 <fwp_format_g.constprop.0+0x2e4>
    244c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    2450:	93407ef7 	sxtw	x23, w23
    2454:	390000e4 	strb	w4, [x7]
    2458:	aa1303e1 	mov	x1, x19
    245c:	aa1703e2 	mov	x2, x23
    2460:	aa1603e0 	mov	x0, x22
    2464:	b9000be5 	str	w5, [sp, #8]
    2468:	cb170374 	sub	x20, x27, x23
    246c:	a9011be3 	stp	x3, x6, [sp, #16]
    2470:	97fffbbc 	bl	1360 <memcpy@plt>
    2474:	d1000694 	sub	x20, x20, #0x1
    2478:	f9400be3 	ldr	x3, [sp, #16]
    247c:	8b1702d6 	add	x22, x22, x23
    2480:	aa1603e0 	mov	x0, x22
    2484:	aa1a03e2 	mov	x2, x26
    2488:	aa0303e1 	mov	x1, x3
    248c:	aa1403e3 	mov	x3, x20
    2490:	97fffbf0 	bl	1450 <__memcpy_chk@plt>
    2494:	8b1a02d6 	add	x22, x22, x26
    2498:	f9400fe6 	ldr	x6, [sp, #24]
    249c:	d2800900 	mov	x0, #0x48                  	// #72
    24a0:	b9400be5 	ldr	w5, [sp, #8]
    24a4:	8b170261 	add	x1, x19, x23
    24a8:	cb1400c3 	sub	x3, x6, x20
    24ac:	cb060294 	sub	x20, x20, x6
    24b0:	f101207f 	cmp	x3, #0x48
    24b4:	93407cb8 	sxtw	x24, w5
    24b8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    24bc:	aa1803e2 	mov	x2, x24
    24c0:	8b1802d3 	add	x19, x22, x24
    24c4:	8b140063 	add	x3, x3, x20
    24c8:	aa1603e0 	mov	x0, x22
    24cc:	97fffbe1 	bl	1450 <__memcpy_chk@plt>
    24d0:	cb190273 	sub	x19, x19, x25
    24d4:	d28031e0 	mov	x0, #0x18f                 	// #399
    24d8:	eb00027f 	cmp	x19, x0
    24dc:	aa1903e1 	mov	x1, x25
    24e0:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    24e4:	aa1503e0 	mov	x0, x21
    24e8:	aa1303e2 	mov	x2, x19
    24ec:	97fffb9d 	bl	1360 <memcpy@plt>
    24f0:	38336abf 	strb	wzr, [x21, x19]
    24f4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    24f8:	aa1503e0 	mov	x0, x21
    24fc:	97fffba5 	bl	1390 <strlen@plt>
    2500:	aa0003f3 	mov	x19, x0
    2504:	528005c1 	mov	w1, #0x2e                  	// #46
    2508:	aa1503e0 	mov	x0, x21
    250c:	97fffc35 	bl	15e0 <strchr@plt>
    2510:	b4000140 	cbz	x0, 2538 <fwp_format_g.constprop.0+0x1d8>
    2514:	b4000133 	cbz	x19, 2538 <fwp_format_g.constprop.0+0x1d8>
    2518:	aa1303e1 	mov	x1, x19
    251c:	d1000673 	sub	x19, x19, #0x1
    2520:	38736aa0 	ldrb	w0, [x21, x19]
    2524:	7100c01f 	cmp	w0, #0x30
    2528:	54001001 	b.ne	2728 <fwp_format_g.constprop.0+0x3c8>  // b.any
    252c:	38336abf 	strb	wzr, [x21, x19]
    2530:	b5ffff53 	cbnz	x19, 2518 <fwp_format_g.constprop.0+0x1b8>
    2534:	d503201f 	nop
    2538:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    253c:	f947f400 	ldr	x0, [x0, #4072]
    2540:	f94057e2 	ldr	x2, [sp, #168]
    2544:	f9400001 	ldr	x1, [x0]
    2548:	eb010042 	subs	x2, x2, x1
    254c:	d2800001 	mov	x1, #0x0                   	// #0
    2550:	54001061 	b.ne	275c <fwp_format_g.constprop.0+0x3fc>  // b.any
    2554:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2558:	a94c53f3 	ldp	x19, x20, [sp, #192]
    255c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2560:	a94e63f7 	ldp	x23, x24, [sp, #224]
    2564:	a95073fb 	ldp	x27, x28, [sp, #256]
    2568:	fd408be8 	ldr	d8, [sp, #272]
    256c:	910483ff 	add	sp, sp, #0x120
    2570:	d65f03c0 	ret
    2574:	1e604100 	fmov	d0, d8
    2578:	710000bf 	cmp	w5, #0x0
    257c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2580:	aa1503e0 	mov	x0, x21
    2584:	d0000024 	adrp	x4, 8000 <f0+0x2320>
    2588:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    258c:	913ee084 	add	x4, x4, #0xfb8
    2590:	52800042 	mov	w2, #0x2                   	// #2
    2594:	d2803201 	mov	x1, #0x190                 	// #400
    2598:	97fffbb6 	bl	1470 <__snprintf_chk@plt>
    259c:	17ffffd7 	b	24f8 <fwp_format_g.constprop.0+0x198>
    25a0:	cb140273 	sub	x19, x19, x20
    25a4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    25a8:	910183f9 	add	x25, sp, #0x60
    25ac:	aa1303e2 	mov	x2, x19
    25b0:	aa1403e1 	mov	x1, x20
    25b4:	aa1903e0 	mov	x0, x25
    25b8:	d2800803 	mov	x3, #0x40                  	// #64
    25bc:	97fffba5 	bl	1450 <__memcpy_chk@plt>
    25c0:	38336b3f 	strb	wzr, [x25, x19]
    25c4:	aa1903e0 	mov	x0, x25
    25c8:	528005c1 	mov	w1, #0x2e                  	// #46
    25cc:	97fffc05 	bl	15e0 <strchr@plt>
    25d0:	b40001c0 	cbz	x0, 2608 <fwp_format_g.constprop.0+0x2a8>
    25d4:	b50000b3 	cbnz	x19, 25e8 <fwp_format_g.constprop.0+0x288>
    25d8:	1400000c 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    25dc:	381ff01f 	sturb	wzr, [x0, #-1]
    25e0:	f1000673 	subs	x19, x19, #0x1
    25e4:	54000120 	b.eq	2608 <fwp_format_g.constprop.0+0x2a8>  // b.none
    25e8:	8b130320 	add	x0, x25, x19
    25ec:	385ff001 	ldurb	w1, [x0, #-1]
    25f0:	7100c03f 	cmp	w1, #0x30
    25f4:	54ffff40 	b.eq	25dc <fwp_format_g.constprop.0+0x27c>  // b.none
    25f8:	d1000673 	sub	x19, x19, #0x1
    25fc:	38736b20 	ldrb	w0, [x25, x19]
    2600:	7100b81f 	cmp	w0, #0x2e
    2604:	54000a80 	b.eq	2754 <fwp_format_g.constprop.0+0x3f4>  // b.none
    2608:	710002ff 	cmp	w23, #0x0
    260c:	528005a1 	mov	w1, #0x2d                  	// #45
    2610:	aa1903e5 	mov	x5, x25
    2614:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    2618:	aa1503e0 	mov	x0, x21
    261c:	52800566 	mov	w6, #0x2b                  	// #43
    2620:	d0000024 	adrp	x4, 8000 <f0+0x2320>
    2624:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    2628:	913ea084 	add	x4, x4, #0xfa8
    262c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2630:	52800042 	mov	w2, #0x2                   	// #2
    2634:	d2803201 	mov	x1, #0x190                 	// #400
    2638:	97fffb8e 	bl	1470 <__snprintf_chk@plt>
    263c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2640:	17ffffbe 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2644:	52800605 	mov	w5, #0x30                  	// #48
    2648:	390000e5 	strb	w5, [x7]
    264c:	d100077b 	sub	x27, x27, #0x1
    2650:	aa0303e1 	mov	x1, x3
    2654:	aa1603e0 	mov	x0, x22
    2658:	aa1b03e3 	mov	x3, x27
    265c:	aa1a03e2 	mov	x2, x26
    2660:	f90007e6 	str	x6, [sp, #8]
    2664:	b90013e4 	str	w4, [sp, #16]
    2668:	8b1a02d6 	add	x22, x22, x26
    266c:	b9001be5 	str	w5, [sp, #24]
    2670:	97fffb78 	bl	1450 <__memcpy_chk@plt>
    2674:	f94007e6 	ldr	x6, [sp, #8]
    2678:	2a3703e7 	mvn	w7, w23
    267c:	b94013e4 	ldr	w4, [sp, #16]
    2680:	cb1b00c1 	sub	x1, x6, x27
    2684:	cb06037b 	sub	x27, x27, x6
    2688:	f101203f 	cmp	x1, #0x48
    268c:	d2800906 	mov	x6, #0x48                  	// #72
    2690:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    2694:	8b1b0023 	add	x3, x1, x27
    2698:	310006ff 	cmn	w23, #0x1
    269c:	54000220 	b.eq	26e0 <fwp_format_g.constprop.0+0x380>  // b.none
    26a0:	b9401be5 	ldr	w5, [sp, #24]
    26a4:	d2800001 	mov	x1, #0x0                   	// #0
    26a8:	f101207f 	cmp	x3, #0x48
    26ac:	d1000462 	sub	x2, x3, #0x1
    26b0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    26b4:	38216ac5 	strb	w5, [x22, x1]
    26b8:	cb030003 	sub	x3, x0, x3
    26bc:	91000421 	add	x1, x1, #0x1
    26c0:	91000463 	add	x3, x3, #0x1
    26c4:	eb00007f 	cmp	x3, x0
    26c8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    26cc:	cb000063 	sub	x3, x3, x0
    26d0:	8b020063 	add	x3, x3, x2
    26d4:	6b0100ff 	cmp	w7, w1
    26d8:	54fffe8c 	b.gt	26a8 <fwp_format_g.constprop.0+0x348>
    26dc:	8b2742d6 	add	x22, x22, w7, uxtw
    26e0:	f101207f 	cmp	x3, #0x48
    26e4:	d2800905 	mov	x5, #0x48                  	// #72
    26e8:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    26ec:	aa1603e0 	mov	x0, x22
    26f0:	cb0300a1 	sub	x1, x5, x3
    26f4:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    26f8:	91000421 	add	x1, x1, #0x1
    26fc:	d1000463 	sub	x3, x3, #0x1
    2700:	eb05003f 	cmp	x1, x5
    2704:	38001402 	strb	w2, [x0], #1
    2708:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    270c:	93407f82 	sxtw	x2, w28
    2710:	cb050025 	sub	x5, x1, x5
    2714:	aa1303e1 	mov	x1, x19
    2718:	8b0300a3 	add	x3, x5, x3
    271c:	8b1802d3 	add	x19, x22, x24
    2720:	97fffb4c 	bl	1450 <__memcpy_chk@plt>
    2724:	17ffff6b 	b	24d0 <fwp_format_g.constprop.0+0x170>
    2728:	d1000421 	sub	x1, x1, #0x1
    272c:	38616aa0 	ldrb	w0, [x21, x1]
    2730:	7100b81f 	cmp	w0, #0x2e
    2734:	54fff021 	b.ne	2538 <fwp_format_g.constprop.0+0x1d8>  // b.any
    2738:	38216abf 	strb	wzr, [x21, x1]
    273c:	17ffff7f 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2740:	910187e7 	add	x7, sp, #0x61
    2744:	910183f9 	add	x25, sp, #0x60
    2748:	d28008fb 	mov	x27, #0x47                  	// #71
    274c:	390183e0 	strb	w0, [sp, #96]
    2750:	17ffff3b 	b	243c <fwp_format_g.constprop.0+0xdc>
    2754:	38336b3f 	strb	wzr, [x25, x19]
    2758:	17ffffac 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    275c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2760:	97fffb68 	bl	1500 <__stack_chk_fail@plt>

0000000000002764 <fwp_heap_report>:
    2764:	d105c3ff 	sub	sp, sp, #0x170
    2768:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    276c:	9115c042 	add	x2, x2, #0x570
    2770:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    2774:	f947e821 	ldr	x1, [x1, #4048]
    2778:	a9117bfd 	stp	x29, x30, [sp, #272]
    277c:	910443fd 	add	x29, sp, #0x110
    2780:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    2784:	f947f400 	ldr	x0, [x0, #4072]
    2788:	a9135bf5 	stp	x21, x22, [sp, #304]
    278c:	a91463f7 	stp	x23, x24, [sp, #320]
    2790:	a9156bf9 	stp	x25, x26, [sp, #336]
    2794:	6d1627e8 	stp	d8, d9, [sp, #352]
    2798:	fd4a1c48 	ldr	d8, [x2, #5176]
    279c:	fd4a2049 	ldr	d9, [x2, #5184]
    27a0:	f9400036 	ldr	x22, [x1]
    27a4:	f9400001 	ldr	x1, [x0]
    27a8:	f90087e1 	str	x1, [sp, #264]
    27ac:	d2800001 	mov	x1, #0x0                   	// #0
    27b0:	f949e459 	ldr	x25, [x2, #5064]
    27b4:	d0000021 	adrp	x1, 8000 <f0+0x2320>
    27b8:	f94a1057 	ldr	x23, [x2, #5152]
    27bc:	d0000020 	adrp	x0, 8000 <f0+0x2320>
    27c0:	f94a1458 	ldr	x24, [x2, #5160]
    27c4:	913f0021 	add	x1, x1, #0xfc0
    27c8:	913f2000 	add	x0, x0, #0xfc8
    27cc:	97fffb31 	bl	1490 <fopen@plt>
    27d0:	b4000760 	cbz	x0, 28bc <fwp_heap_report+0x158>
    27d4:	528daad5 	mov	w21, #0x6d56                	// #27990
    27d8:	a91253f3 	stp	x19, x20, [sp, #288]
    27dc:	aa0003f4 	mov	x20, x0
    27e0:	910023f3 	add	x19, sp, #0x8
    27e4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    27e8:	72aae915 	movk	w21, #0x5748, lsl #16
    27ec:	d503201f 	nop
    27f0:	aa1403e2 	mov	x2, x20
    27f4:	aa1303e0 	mov	x0, x19
    27f8:	52802001 	mov	w1, #0x100                 	// #256
    27fc:	97fffbad 	bl	16b0 <fgets@plt>
    2800:	b4000280 	cbz	x0, 2850 <fwp_heap_report+0xec>
    2804:	b9400261 	ldr	w1, [x19]
    2808:	6b15003f 	cmp	w1, w21
    280c:	54ffff21 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2810:	39401260 	ldrb	w0, [x19, #4]
    2814:	7101341f 	cmp	w0, #0x4d
    2818:	54fffec1 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    281c:	394037e0 	ldrb	w0, [sp, #13]
    2820:	7100e81f 	cmp	w0, #0x3a
    2824:	54fffe61 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2828:	52800142 	mov	w2, #0xa                   	// #10
    282c:	d2800001 	mov	x1, #0x0                   	// #0
    2830:	91003be0 	add	x0, sp, #0xe
    2834:	97fffb5b 	bl	15a0 <strtol@plt>
    2838:	aa1403e2 	mov	x2, x20
    283c:	aa0003fa 	mov	x26, x0
    2840:	52802001 	mov	w1, #0x100                 	// #256
    2844:	aa1303e0 	mov	x0, x19
    2848:	97fffb9a 	bl	16b0 <fgets@plt>
    284c:	b5fffdc0 	cbnz	x0, 2804 <fwp_heap_report+0xa0>
    2850:	aa1403e0 	mov	x0, x20
    2854:	97fffb0b 	bl	1480 <fclose@plt>
    2858:	a95253f3 	ldp	x19, x20, [sp, #288]
    285c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    2860:	f947f400 	ldr	x0, [x0, #4072]
    2864:	f94087e2 	ldr	x2, [sp, #264]
    2868:	f9400001 	ldr	x1, [x0]
    286c:	eb010042 	subs	x2, x2, x1
    2870:	d2800001 	mov	x1, #0x0                   	// #0
    2874:	54000281 	b.ne	28c4 <fwp_heap_report+0x160>  // b.any
    2878:	a9517bfd 	ldp	x29, x30, [sp, #272]
    287c:	aa1a03e6 	mov	x6, x26
    2880:	aa1903e5 	mov	x5, x25
    2884:	aa1803e4 	mov	x4, x24
    2888:	a9556bf9 	ldp	x25, x26, [sp, #336]
    288c:	aa1703e3 	mov	x3, x23
    2890:	a95463f7 	ldp	x23, x24, [sp, #320]
    2894:	aa1603e0 	mov	x0, x22
    2898:	a9535bf5 	ldp	x21, x22, [sp, #304]
    289c:	1e604121 	fmov	d1, d9
    28a0:	1e604100 	fmov	d0, d8
    28a4:	d0000022 	adrp	x2, 8000 <f0+0x2320>
    28a8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    28ac:	913fa042 	add	x2, x2, #0xfe8
    28b0:	9105c3ff 	add	sp, sp, #0x170
    28b4:	52800041 	mov	w1, #0x2                   	// #2
    28b8:	17fffb2e 	b	1570 <__fprintf_chk@plt>
    28bc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    28c0:	17ffffe7 	b	285c <fwp_heap_report+0xf8>
    28c4:	a91253f3 	stp	x19, x20, [sp, #288]
    28c8:	97fffb0e 	bl	1500 <__stack_chk_fail@plt>
    28cc:	d503201f 	nop

00000000000028d0 <fwp_heap_init>:
    28d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    28d4:	90000183 	adrp	x3, 32000 <fwp_heap+0xa90>
    28d8:	9111c061 	add	x1, x3, #0x470
    28dc:	910003fd 	mov	x29, sp
    28e0:	a90153f3 	stp	x19, x20, [sp, #16]
    28e4:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    28e8:	9115c262 	add	x2, x19, #0x570
    28ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    28f0:	52800024 	mov	w4, #0x1                   	// #1
    28f4:	52800200 	mov	w0, #0x10                  	// #16
    28f8:	b913a444 	str	w4, [x2, #5028]
    28fc:	d503201f 	nop
    2900:	b8004420 	str	w0, [x1], #4
    2904:	11004000 	add	w0, w0, #0x10
    2908:	7104401f 	cmp	w0, #0x110
    290c:	54ffffa1 	b.ne	2900 <fwp_heap_init+0x30>  // b.any
    2910:	f0000022 	adrp	x2, 9000 <_IO_stdin_used+0x1e0>
    2914:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2918:	90000181 	adrp	x1, 32000 <fwp_heap+0xa90>
    291c:	9112c021 	add	x1, x1, #0x4b0
    2920:	3dc14043 	ldr	q3, [x2, #1280]
    2924:	d2800000 	mov	x0, #0x0                   	// #0
    2928:	4e040401 	dup	v1.4s, v0.s[0]
    292c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    2930:	0f215400 	shl	v0.2s, v0.2s, #1
    2934:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    2938:	3ca06821 	str	q1, [x1, x0]
    293c:	91004000 	add	x0, x0, #0x10
    2940:	f101801f 	cmp	x0, #0x60
    2944:	54ffff21 	b.ne	2928 <fwp_heap_init+0x58>  // b.any
    2948:	90000184 	adrp	x4, 32000 <fwp_heap+0xa90>
    294c:	9111c063 	add	x3, x3, #0x470
    2950:	91144084 	add	x4, x4, #0x510
    2954:	9115c266 	add	x6, x19, #0x570
    2958:	d2800002 	mov	x2, #0x0                   	// #0
    295c:	d2800000 	mov	x0, #0x0                   	// #0
    2960:	d2880205 	mov	x5, #0x4010                	// #16400
    2964:	d503201f 	nop
    2968:	910f0001 	add	x1, x0, #0x3c0
    296c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2970:	eb02003f 	cmp	x1, x2
    2974:	540000a2 	b.cs	2988 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    2978:	91000400 	add	x0, x0, #0x1
    297c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2980:	eb02003f 	cmp	x1, x2
    2984:	54ffffa3 	b.cc	2978 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    2988:	91004042 	add	x2, x2, #0x10
    298c:	38001480 	strb	w0, [x4], #1
    2990:	eb05005f 	cmp	x2, x5
    2994:	54fffea1 	b.ne	2968 <fwp_heap_init+0x98>  // b.any
    2998:	528000b5 	mov	w21, #0x5                   	// #5
    299c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    29a0:	14000004 	b	29b0 <fwp_heap_init+0xe0>
    29a4:	d342fe94 	lsr	x20, x20, #2
    29a8:	710006b5 	subs	w21, w21, #0x1
    29ac:	54000720 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    29b0:	91404296 	add	x22, x20, #0x10, lsl #12
    29b4:	d2800005 	mov	x5, #0x0                   	// #0
    29b8:	aa1603e1 	mov	x1, x22
    29bc:	12800004 	mov	w4, #0xffffffff            	// #-1
    29c0:	52880443 	mov	w3, #0x4022                	// #16418
    29c4:	52800002 	mov	w2, #0x0                   	// #0
    29c8:	d2800000 	mov	x0, #0x0                   	// #0
    29cc:	97fffaf1 	bl	1590 <mmap@plt>
    29d0:	aa0003e6 	mov	x6, x0
    29d4:	b100041f 	cmn	x0, #0x1
    29d8:	54fffe60 	b.eq	29a4 <fwp_heap_init+0xd4>  // b.none
    29dc:	b40005a0 	cbz	x0, 2a90 <fwp_heap_init+0x1c0>
    29e0:	d350fe94 	lsr	x20, x20, #16
    29e4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    29e8:	8b0000c7 	add	x7, x6, x0
    29ec:	9115c275 	add	x21, x19, #0x570
    29f0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    29f4:	8b140a81 	add	x1, x20, x20, lsl #2
    29f8:	d2800005 	mov	x5, #0x0                   	// #0
    29fc:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a00:	d37df021 	lsl	x1, x1, #3
    2a04:	52880443 	mov	w3, #0x4022                	// #16418
    2a08:	52800002 	mov	w2, #0x0                   	// #0
    2a0c:	d2800000 	mov	x0, #0x0                   	// #0
    2a10:	f909daa7 	str	x7, [x21, #5040]
    2a14:	f909dea6 	str	x6, [x21, #5048]
    2a18:	f909e2b6 	str	x22, [x21, #5056]
    2a1c:	f909eab4 	str	x20, [x21, #5072]
    2a20:	f90a02a1 	str	x1, [x21, #5120]
    2a24:	97fffadb 	bl	1590 <mmap@plt>
    2a28:	aa0003e1 	mov	x1, x0
    2a2c:	b100041f 	cmn	x0, #0x1
    2a30:	54000300 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    2a34:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    2a38:	91026000 	add	x0, x0, #0x98
    2a3c:	f909fea1 	str	x1, [x21, #5112]
    2a40:	97fffb14 	bl	1690 <getenv@plt>
    2a44:	52800002 	mov	w2, #0x0                   	// #0
    2a48:	aa0003e1 	mov	x1, x0
    2a4c:	b40000e0 	cbz	x0, 2a68 <fwp_heap_init+0x198>
    2a50:	39400000 	ldrb	w0, [x0]
    2a54:	340000a0 	cbz	w0, 2a68 <fwp_heap_init+0x198>
    2a58:	7100c000 	subs	w0, w0, #0x30
    2a5c:	54000120 	b.eq	2a80 <fwp_heap_init+0x1b0>  // b.none
    2a60:	7100001f 	cmp	w0, #0x0
    2a64:	1a9f07e2 	cset	w2, ne	// ne = any
    2a68:	9115c273 	add	x19, x19, #0x570
    2a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2a70:	b913aa62 	str	w2, [x19, #5032]
    2a74:	a94153f3 	ldp	x19, x20, [sp, #16]
    2a78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2a7c:	d65f03c0 	ret
    2a80:	39400420 	ldrb	w0, [x1, #1]
    2a84:	7100001f 	cmp	w0, #0x0
    2a88:	1a9f07e2 	cset	w2, ne	// ne = any
    2a8c:	17fffff7 	b	2a68 <fwp_heap_init+0x198>
    2a90:	97fffc90 	bl	1cd0 <fwp_heap_oom>

0000000000002a94 <fwp_wake_io>:
    2a94:	d00000e9 	adrp	x9, 20000 <__data_start>
    2a98:	91024122 	add	x2, x9, #0x90
    2a9c:	f9400001 	ldr	x1, [x0]
    2aa0:	5280000a 	mov	w10, #0x0                   	// #0
    2aa4:	f9401446 	ldr	x6, [x2, #40]
    2aa8:	52800008 	mov	w8, #0x0                   	// #0
    2aac:	4f000400 	movi	v0.4s, #0x0
    2ab0:	52800027 	mov	w7, #0x1                   	// #1
    2ab4:	aa0103e2 	mov	x2, x1
    2ab8:	b4000321 	cbz	x1, 2b1c <fwp_wake_io+0x88>
    2abc:	f9408c25 	ldr	x5, [x1, #280]
    2ac0:	39015c27 	strb	w7, [x1, #87]
    2ac4:	b4000165 	cbz	x5, 2af0 <fwp_wake_io+0x5c>
    2ac8:	a9520c24 	ldp	x4, x3, [x1, #288]
    2acc:	b4000364 	cbz	x4, 2b38 <fwp_wake_io+0xa4>
    2ad0:	f9009483 	str	x3, [x4, #296]
    2ad4:	f9409423 	ldr	x3, [x1, #296]
    2ad8:	b4000043 	cbz	x3, 2ae0 <fwp_wake_io+0x4c>
    2adc:	f9009064 	str	x4, [x3, #288]
    2ae0:	91080023 	add	x3, x1, #0x200
    2ae4:	f900943f 	str	xzr, [x1, #296]
    2ae8:	3c918060 	stur	q0, [x3, #-232]
    2aec:	f9400001 	ldr	x1, [x0]
    2af0:	f9402843 	ldr	x3, [x2, #80]
    2af4:	f2001c7f 	tst	x3, #0xff000000ff
    2af8:	54fffde1 	b.ne	2ab4 <fwp_wake_io+0x20>  // b.any
    2afc:	39015047 	strb	w7, [x2, #84]
    2b00:	f900805f 	str	xzr, [x2, #256]
    2b04:	b40001e6 	cbz	x6, 2b40 <fwp_wake_io+0xac>
    2b08:	f90080c2 	str	x2, [x6, #256]
    2b0c:	aa0203e6 	mov	x6, x2
    2b10:	52800028 	mov	w8, #0x1                   	// #1
    2b14:	aa0103e2 	mov	x2, x1
    2b18:	b5fffd21 	cbnz	x1, 2abc <fwp_wake_io+0x28>
    2b1c:	3400006a 	cbz	w10, 2b28 <fwp_wake_io+0x94>
    2b20:	91024120 	add	x0, x9, #0x90
    2b24:	f900180b 	str	x11, [x0, #48]
    2b28:	34000068 	cbz	w8, 2b34 <fwp_wake_io+0xa0>
    2b2c:	91024129 	add	x9, x9, #0x90
    2b30:	f9001526 	str	x6, [x9, #40]
    2b34:	d65f03c0 	ret
    2b38:	f90000a3 	str	x3, [x5]
    2b3c:	17ffffe7 	b	2ad8 <fwp_wake_io+0x44>
    2b40:	aa0203eb 	mov	x11, x2
    2b44:	5280002a 	mov	w10, #0x1                   	// #1
    2b48:	17fffff1 	b	2b0c <fwp_wake_io+0x78>
    2b4c:	d503201f 	nop

0000000000002b50 <fwp_poll_events>:
    2b50:	d10103ff 	sub	sp, sp, #0x40
    2b54:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    2b58:	f947f400 	ldr	x0, [x0, #4072]
    2b5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2b60:	910083fd 	add	x29, sp, #0x20
    2b64:	a90353f3 	stp	x19, x20, [sp, #48]
    2b68:	d00000f4 	adrp	x20, 20000 <__data_start>
    2b6c:	f9400001 	ldr	x1, [x0]
    2b70:	f9000fe1 	str	x1, [sp, #24]
    2b74:	d2800001 	mov	x1, #0x0                   	// #0
    2b78:	97fffdd2 	bl	22c0 <fwp_now_ns>
    2b7c:	91024281 	add	x1, x20, #0x90
    2b80:	f9401c33 	ldr	x19, [x1, #56]
    2b84:	b4000e93 	cbz	x19, 2d54 <fwp_poll_events+0x204>
    2b88:	aa1303e1 	mov	x1, x19
    2b8c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2b90:	14000005 	b	2ba4 <fwp_poll_events+0x54>
    2b94:	f9408821 	ldr	x1, [x1, #272]
    2b98:	eb03005f 	cmp	x2, x3
    2b9c:	9a83d042 	csel	x2, x2, x3, le
    2ba0:	b40000c1 	cbz	x1, 2bb8 <fwp_poll_events+0x68>
    2ba4:	f9403423 	ldr	x3, [x1, #104]
    2ba8:	b6ffff62 	tbz	x2, #63, 2b94 <fwp_poll_events+0x44>
    2bac:	f9408821 	ldr	x1, [x1, #272]
    2bb0:	aa0303e2 	mov	x2, x3
    2bb4:	b5ffff81 	cbnz	x1, 2ba4 <fwp_poll_events+0x54>
    2bb8:	b7f80ce2 	tbnz	x2, #63, 2d54 <fwp_poll_events+0x204>
    2bbc:	cb000042 	sub	x2, x2, x0
    2bc0:	f100005f 	cmp	x2, #0x0
    2bc4:	540005cd 	b.le	2c7c <fwp_poll_events+0x12c>
    2bc8:	d2869b60 	mov	x0, #0x34db                	// #13531
    2bcc:	d2884801 	mov	x1, #0x4240                	// #16960
    2bd0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2bd4:	f2a001e1 	movk	x1, #0xf, lsl #16
    2bd8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2bdc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2be0:	f2e86360 	movk	x0, #0x431b, lsl #48
    2be4:	9b407c40 	smulh	x0, x2, x0
    2be8:	9352fc00 	asr	x0, x0, #18
    2bec:	cb82fc00 	sub	x0, x0, x2, asr #63
    2bf0:	9b018802 	msub	x2, x0, x1, x2
    2bf4:	f100005f 	cmp	x2, #0x0
    2bf8:	9a800400 	cinc	x0, x0, ne	// ne = any
    2bfc:	eb03001f 	cmp	x0, x3
    2c00:	54000a0c 	b.gt	2d40 <fwp_poll_events+0x1f0>
    2c04:	340003c0 	cbz	w0, 2c7c <fwp_poll_events+0x12c>
    2c08:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2c0c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2c10:	72a20c42 	movk	w2, #0x1062, lsl #16
    2c14:	9ba27c02 	umull	x2, w0, w2
    2c18:	d366fc43 	lsr	x3, x2, #38
    2c1c:	aa0303e2 	mov	x2, x3
    2c20:	1b048063 	msub	w3, w3, w4, w0
    2c24:	9b217c63 	smull	x3, w3, w1
    2c28:	d2800001 	mov	x1, #0x0                   	// #0
    2c2c:	910023e0 	add	x0, sp, #0x8
    2c30:	a9008fe2 	stp	x2, x3, [sp, #8]
    2c34:	97fffa67 	bl	15d0 <nanosleep@plt>
    2c38:	91024280 	add	x0, x20, #0x90
    2c3c:	f9401c13 	ldr	x19, [x0, #56]
    2c40:	97fffda0 	bl	22c0 <fwp_now_ns>
    2c44:	aa0003e6 	mov	x6, x0
    2c48:	b50001f3 	cbnz	x19, 2c84 <fwp_poll_events+0x134>
    2c4c:	d503201f 	nop
    2c50:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    2c54:	f947f400 	ldr	x0, [x0, #4072]
    2c58:	f9400fe2 	ldr	x2, [sp, #24]
    2c5c:	f9400001 	ldr	x1, [x0]
    2c60:	eb010042 	subs	x2, x2, x1
    2c64:	d2800001 	mov	x1, #0x0                   	// #0
    2c68:	540008c1 	b.ne	2d80 <fwp_poll_events+0x230>  // b.any
    2c6c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2c70:	a94353f3 	ldp	x19, x20, [sp, #48]
    2c74:	910103ff 	add	sp, sp, #0x40
    2c78:	d65f03c0 	ret
    2c7c:	97fffd91 	bl	22c0 <fwp_now_ns>
    2c80:	aa0003e6 	mov	x6, x0
    2c84:	4f000400 	movi	v0.4s, #0x0
    2c88:	91024288 	add	x8, x20, #0x90
    2c8c:	52800027 	mov	w7, #0x1                   	// #1
    2c90:	f9403661 	ldr	x1, [x19, #104]
    2c94:	aa1303e5 	mov	x5, x19
    2c98:	f9408a73 	ldr	x19, [x19, #272]
    2c9c:	eb06003f 	cmp	x1, x6
    2ca0:	5400032c 	b.gt	2d04 <fwp_poll_events+0x1b4>
    2ca4:	394154a0 	ldrb	w0, [x5, #85]
    2ca8:	36000120 	tbz	w0, #0, 2ccc <fwp_poll_events+0x17c>
    2cac:	f94084a0 	ldr	x0, [x5, #264]
    2cb0:	b40003c0 	cbz	x0, 2d28 <fwp_poll_events+0x1d8>
    2cb4:	f9008813 	str	x19, [x0, #272]
    2cb8:	b4000053 	cbz	x19, 2cc0 <fwp_poll_events+0x170>
    2cbc:	f9008660 	str	x0, [x19, #264]
    2cc0:	910800a0 	add	x0, x5, #0x200
    2cc4:	390154bf 	strb	wzr, [x5, #85]
    2cc8:	3c908000 	stur	q0, [x0, #-248]
    2ccc:	f94030a0 	ldr	x0, [x5, #96]
    2cd0:	390158a7 	strb	w7, [x5, #86]
    2cd4:	f100001f 	cmp	x0, #0x0
    2cd8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2cdc:	5400018d 	b.le	2d0c <fwp_poll_events+0x1bc>
    2ce0:	f94028a0 	ldr	x0, [x5, #80]
    2ce4:	f2001c1f 	tst	x0, #0xff000000ff
    2ce8:	540000e1 	b.ne	2d04 <fwp_poll_events+0x1b4>  // b.any
    2cec:	f9401500 	ldr	x0, [x8, #40]
    2cf0:	390150a7 	strb	w7, [x5, #84]
    2cf4:	f90080bf 	str	xzr, [x5, #256]
    2cf8:	b40001e0 	cbz	x0, 2d34 <fwp_poll_events+0x1e4>
    2cfc:	f9001505 	str	x5, [x8, #40]
    2d00:	f9008005 	str	x5, [x0, #256]
    2d04:	b5fffc73 	cbnz	x19, 2c90 <fwp_poll_events+0x140>
    2d08:	17ffffd2 	b	2c50 <fwp_poll_events+0x100>
    2d0c:	394144a0 	ldrb	w0, [x5, #81]
    2d10:	3707fe80 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d14:	394140a0 	ldrb	w0, [x5, #80]
    2d18:	3707fe40 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d1c:	aa0503e0 	mov	x0, x5
    2d20:	97fffd14 	bl	2170 <fwp_cancel_tree.part.0>
    2d24:	17ffffef 	b	2ce0 <fwp_poll_events+0x190>
    2d28:	91024281 	add	x1, x20, #0x90
    2d2c:	f9001c33 	str	x19, [x1, #56]
    2d30:	17ffffe2 	b	2cb8 <fwp_poll_events+0x168>
    2d34:	f9001505 	str	x5, [x8, #40]
    2d38:	f9001905 	str	x5, [x8, #48]
    2d3c:	17fffff2 	b	2d04 <fwp_poll_events+0x1b4>
    2d40:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2d44:	d2989362 	mov	x2, #0xc49b                	// #50331
    2d48:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2d4c:	f2a00402 	movk	x2, #0x20, lsl #16
    2d50:	17ffffb6 	b	2c28 <fwp_poll_events+0xd8>
    2d54:	97fffb9f 	bl	1bd0 <fwp_flush>
    2d58:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14da0>
    2d5c:	f947e863 	ldr	x3, [x3, #4048]
    2d60:	d2800562 	mov	x2, #0x2b                  	// #43
    2d64:	d2800021 	mov	x1, #0x1                   	// #1
    2d68:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    2d6c:	9102a000 	add	x0, x0, #0xa8
    2d70:	f9400063 	ldr	x3, [x3]
    2d74:	97fffa23 	bl	1600 <fwrite@plt>
    2d78:	52800ca0 	mov	w0, #0x65                  	// #101
    2d7c:	97fff98d 	bl	13b0 <exit@plt>
    2d80:	97fff9e0 	bl	1500 <__stack_chk_fail@plt>

0000000000002d84 <fwp_rc_forget_slot>:
    2d84:	aa0003e1 	mov	x1, x0
    2d88:	39400000 	ldrb	w0, [x0]
    2d8c:	7103fc1f 	cmp	w0, #0xff
    2d90:	54000040 	b.eq	2d98 <fwp_rc_forget_slot+0x14>  // b.none
    2d94:	d65f03c0 	ret
    2d98:	ca414420 	eor	x0, x1, x1, lsr #17
    2d9c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2da0:	ca402400 	eor	x0, x0, x0, lsr #9
    2da4:	910003fd 	mov	x29, sp
    2da8:	92401c00 	and	x0, x0, #0xff
    2dac:	f9000bf3 	str	x19, [sp, #16]
    2db0:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    2db4:	9115c262 	add	x2, x19, #0x570
    2db8:	910a2403 	add	x3, x0, #0x289
    2dbc:	8b000c40 	add	x0, x2, x0, lsl #3
    2dc0:	8b030c43 	add	x3, x2, x3, lsl #3
    2dc4:	f94a2400 	ldr	x0, [x0, #5192]
    2dc8:	b50000a0 	cbnz	x0, 2ddc <fwp_rc_forget_slot+0x58>
    2dcc:	14000011 	b	2e10 <fwp_rc_forget_slot+0x8c>
    2dd0:	91004003 	add	x3, x0, #0x10
    2dd4:	f9400800 	ldr	x0, [x0, #16]
    2dd8:	b40001c0 	cbz	x0, 2e10 <fwp_rc_forget_slot+0x8c>
    2ddc:	f9400002 	ldr	x2, [x0]
    2de0:	eb02003f 	cmp	x1, x2
    2de4:	54ffff61 	b.ne	2dd0 <fwp_rc_forget_slot+0x4c>  // b.any
    2de8:	f9400801 	ldr	x1, [x0, #16]
    2dec:	9115c273 	add	x19, x19, #0x570
    2df0:	f9000061 	str	x1, [x3]
    2df4:	97fff9f3 	bl	15c0 <free@plt>
    2df8:	f94e2660 	ldr	x0, [x19, #7240]
    2dfc:	d1000400 	sub	x0, x0, #0x1
    2e00:	f90e2660 	str	x0, [x19, #7240]
    2e04:	f9400bf3 	ldr	x19, [sp, #16]
    2e08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e0c:	d65f03c0 	ret
    2e10:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    2e14:	91036000 	add	x0, x0, #0xd8
    2e18:	97fffd1a 	bl	2280 <fwp_trap>
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_rc_prepare_chunk>:
    2e20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2e24:	910003fd 	mov	x29, sp
    2e28:	a9025bf5 	stp	x21, x22, [sp, #32]
    2e2c:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xc70>
    2e30:	9115c2c2 	add	x2, x22, #0x570
    2e34:	b9401c03 	ldr	w3, [x0, #28]
    2e38:	aa0103f5 	mov	x21, x1
    2e3c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e40:	aa0003f4 	mov	x20, x0
    2e44:	f94e2440 	ldr	x0, [x2, #7240]
    2e48:	b4000440 	cbz	x0, 2ed0 <fwp_rc_prepare_chunk+0xb0>
    2e4c:	d2800013 	mov	x19, #0x0                   	// #0
    2e50:	35000203 	cbnz	w3, 2e90 <fwp_rc_prepare_chunk+0x70>
    2e54:	b4000361 	cbz	x1, 2ec0 <fwp_rc_prepare_chunk+0xa0>
    2e58:	f9401280 	ldr	x0, [x20, #32]
    2e5c:	97fff9d9 	bl	15c0 <free@plt>
    2e60:	aa1503e0 	mov	x0, x21
    2e64:	d2800021 	mov	x1, #0x1                   	// #1
    2e68:	97fff99e 	bl	14e0 <calloc@plt>
    2e6c:	f9001280 	str	x0, [x20, #32]
    2e70:	b5000460 	cbnz	x0, 2efc <fwp_rc_prepare_chunk+0xdc>
    2e74:	97fffb97 	bl	1cd0 <fwp_heap_oom>
    2e78:	97ffffc3 	bl	2d84 <fwp_rc_forget_slot>
    2e7c:	91000673 	add	x19, x19, #0x1
    2e80:	b9401e83 	ldr	w3, [x20, #28]
    2e84:	eb13007f 	cmp	x3, x19
    2e88:	54000169 	b.ls	2eb4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2e8c:	d503201f 	nop
    2e90:	f9401283 	ldr	x3, [x20, #32]
    2e94:	8b130060 	add	x0, x3, x19
    2e98:	38736863 	ldrb	w3, [x3, x19]
    2e9c:	7103fc7f 	cmp	w3, #0xff
    2ea0:	54fffec0 	b.eq	2e78 <fwp_rc_prepare_chunk+0x58>  // b.none
    2ea4:	b9401e83 	ldr	w3, [x20, #28]
    2ea8:	91000673 	add	x19, x19, #0x1
    2eac:	eb13007f 	cmp	x3, x19
    2eb0:	54ffff08 	b.hi	2e90 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2eb4:	eb0302bf 	cmp	x21, x3
    2eb8:	54000121 	b.ne	2edc <fwp_rc_prepare_chunk+0xbc>  // b.any
    2ebc:	b5000335 	cbnz	x21, 2f20 <fwp_rc_prepare_chunk+0x100>
    2ec0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ec4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ec8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2ecc:	d65f03c0 	ret
    2ed0:	2a0303e3 	mov	w3, w3
    2ed4:	eb0302bf 	cmp	x21, x3
    2ed8:	54ffff20 	b.eq	2ebc <fwp_rc_prepare_chunk+0x9c>  // b.none
    2edc:	9115c2c2 	add	x2, x22, #0x570
    2ee0:	f9401280 	ldr	x0, [x20, #32]
    2ee4:	f94e2841 	ldr	x1, [x2, #7248]
    2ee8:	cb030021 	sub	x1, x1, x3
    2eec:	f90e2841 	str	x1, [x2, #7248]
    2ef0:	97fff9b4 	bl	15c0 <free@plt>
    2ef4:	b5fffb75 	cbnz	x21, 2e60 <fwp_rc_prepare_chunk+0x40>
    2ef8:	f900129f 	str	xzr, [x20, #32]
    2efc:	9115c2d6 	add	x22, x22, #0x570
    2f00:	f94e2ac0 	ldr	x0, [x22, #7248]
    2f04:	b9001e95 	str	w21, [x20, #28]
    2f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f0c:	8b150000 	add	x0, x0, x21
    2f10:	f90e2ac0 	str	x0, [x22, #7248]
    2f14:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f1c:	d65f03c0 	ret
    2f20:	f9401280 	ldr	x0, [x20, #32]
    2f24:	aa1503e2 	mov	x2, x21
    2f28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f2c:	52800001 	mov	w1, #0x0                   	// #0
    2f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f38:	17fff966 	b	14d0 <memset@plt>
    2f3c:	d503201f 	nop

0000000000002f40 <fwp_heap_refill>:
    2f40:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2f44:	910003fd 	mov	x29, sp
    2f48:	a9025bf5 	stp	x21, x22, [sp, #32]
    2f4c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    2f50:	9115c2b5 	add	x21, x21, #0x570
    2f54:	aa0003f6 	mov	x22, x0
    2f58:	d2800020 	mov	x0, #0x1                   	// #1
    2f5c:	a90153f3 	stp	x19, x20, [sp, #16]
    2f60:	a90363f7 	stp	x23, x24, [sp, #48]
    2f64:	2a0103f7 	mov	w23, w1
    2f68:	2a0203f8 	mov	w24, w2
    2f6c:	97fffb69 	bl	1d10 <fwp_heap_chunks>
    2f70:	aa0003f3 	mov	x19, x0
    2f74:	f949fea2 	ldr	x2, [x21, #5112]
    2f78:	8b000800 	add	x0, x0, x0, lsl #2
    2f7c:	2a1703e1 	mov	w1, w23
    2f80:	52800025 	mov	w5, #0x1                   	// #1
    2f84:	d37df000 	lsl	x0, x0, #3
    2f88:	910f0021 	add	x1, x1, #0x3c0
    2f8c:	8b000054 	add	x20, x2, x0
    2f90:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2f94:	52a00024 	mov	w4, #0x10000               	// #65536
    2f98:	38206845 	strb	w5, [x2, x0]
    2f9c:	aa1403e0 	mov	x0, x20
    2fa0:	39000698 	strb	w24, [x20, #1]
    2fa4:	39000a97 	strb	w23, [x20, #2]
    2fa8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2fac:	b9000681 	str	w1, [x20, #4]
    2fb0:	2a0103e5 	mov	w5, w1
    2fb4:	8b0300a2 	add	x2, x5, x3
    2fb8:	1ac10881 	udiv	w1, w4, w1
    2fbc:	9ac50842 	udiv	x2, x2, x5
    2fc0:	b9000a81 	str	w1, [x20, #8]
    2fc4:	92404021 	and	x1, x1, #0x1ffff
    2fc8:	b9001a82 	str	w2, [x20, #24]
    2fcc:	97ffff95 	bl	2e20 <fwp_rc_prepare_chunk>
    2fd0:	f949daa0 	ldr	x0, [x21, #5040]
    2fd4:	29408a81 	ldp	w1, w2, [x20, #4]
    2fd8:	8b134000 	add	x0, x0, x19, lsl #16
    2fdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2fe0:	8b214003 	add	x3, x0, w1, uxtw
    2fe4:	9ba20021 	umaddl	x1, w1, w2, x0
    2fe8:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fec:	a90086c3 	stp	x3, x1, [x22, #8]
    2ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ff4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2ff8:	d65f03c0 	ret
    2ffc:	d503201f 	nop

0000000000003000 <fwp_mem_free>:
    3000:	b40003c0 	cbz	x0, 3078 <fwp_mem_free+0x78>
    3004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3008:	910003fd 	mov	x29, sp
    300c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3010:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    3014:	9115c2a1 	add	x1, x21, #0x570
    3018:	a90153f3 	stp	x19, x20, [sp, #16]
    301c:	aa0003f3 	mov	x19, x0
    3020:	f949d823 	ldr	x3, [x1, #5040]
    3024:	f949ec22 	ldr	x2, [x1, #5080]
    3028:	cb030000 	sub	x0, x0, x3
    302c:	eb02401f 	cmp	x0, x2, lsl #16
    3030:	540001c2 	b.cs	3068 <fwp_mem_free+0x68>  // b.hs, b.nlast
    3034:	d350fc16 	lsr	x22, x0, #16
    3038:	a90363f7 	stp	x23, x24, [sp, #48]
    303c:	f949fc22 	ldr	x2, [x1, #5112]
    3040:	8b160ad4 	add	x20, x22, x22, lsl #2
    3044:	d37df294 	lsl	x20, x20, #3
    3048:	ab140057 	adds	x23, x2, x20
    304c:	540000c0 	b.eq	3064 <fwp_mem_free+0x64>  // b.none
    3050:	38746842 	ldrb	w2, [x2, x20]
    3054:	7100045f 	cmp	w2, #0x1
    3058:	54000120 	b.eq	307c <fwp_mem_free+0x7c>  // b.none
    305c:	7100085f 	cmp	w2, #0x2
    3060:	540005e0 	b.eq	311c <fwp_mem_free+0x11c>  // b.none
    3064:	a94363f7 	ldp	x23, x24, [sp, #48]
    3068:	a94153f3 	ldp	x19, x20, [sp, #16]
    306c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3070:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3074:	d65f03c0 	ret
    3078:	d65f03c0 	ret
    307c:	f94012f8 	ldr	x24, [x23, #32]
    3080:	b94006e1 	ldr	w1, [x23, #4]
    3084:	f90023f9 	str	x25, [sp, #64]
    3088:	2a0103e2 	mov	w2, w1
    308c:	394006f9 	ldrb	w25, [x23, #1]
    3090:	39400af4 	ldrb	w20, [x23, #2]
    3094:	b4000158 	cbz	x24, 30bc <fwp_mem_free+0xbc>
    3098:	92403e76 	and	x22, x19, #0xffff
    309c:	9ac20ad6 	udiv	x22, x22, x2
    30a0:	38766b01 	ldrb	w1, [x24, x22]
    30a4:	8b160300 	add	x0, x24, x22
    30a8:	7103fc3f 	cmp	w1, #0xff
    30ac:	54000980 	b.eq	31dc <fwp_mem_free+0x1dc>  // b.none
    30b0:	38366b1f 	strb	wzr, [x24, x22]
    30b4:	b94006e1 	ldr	w1, [x23, #4]
    30b8:	2a0103e2 	mov	w2, w1
    30bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    30c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    30c4:	cb390000 	sub	x0, x0, w25, uxtb
    30c8:	8b340074 	add	x20, x3, w20, uxtb
    30cc:	9115c2b5 	add	x21, x21, #0x570
    30d0:	1e630021 	ucvtf	d1, w1
    30d4:	d37ae400 	lsl	x0, x0, #6
    30d8:	8b140c14 	add	x20, x0, x20, lsl #3
    30dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    30e0:	f8746aa0 	ldr	x0, [x21, x20]
    30e4:	f94023f9 	ldr	x25, [sp, #64]
    30e8:	aa2003e0 	mvn	x0, x0
    30ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    30f0:	f9000260 	str	x0, [x19]
    30f4:	f8346ab3 	str	x19, [x21, x20]
    30f8:	f94a12a0 	ldr	x0, [x21, #5152]
    30fc:	1e612800 	fadd	d0, d0, d1
    3100:	a94153f3 	ldp	x19, x20, [sp, #16]
    3104:	cb020000 	sub	x0, x0, x2
    3108:	f90a12a0 	str	x0, [x21, #5152]
    310c:	fd0a22a0 	str	d0, [x21, #5184]
    3110:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3114:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3118:	d65f03c0 	ret
    311c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    3120:	8b000063 	add	x3, x3, x0
    3124:	eb03027f 	cmp	x19, x3
    3128:	54fff9e1 	b.ne	3064 <fwp_mem_free+0x64>  // b.any
    312c:	fd400ae1 	ldr	d1, [x23, #16]
    3130:	fd4a2020 	ldr	d0, [x1, #5184]
    3134:	f9400ae0 	ldr	x0, [x23, #16]
    3138:	7e61d821 	ucvtf	d1, d1
    313c:	f94a1022 	ldr	x2, [x1, #5152]
    3140:	f94012f3 	ldr	x19, [x23, #32]
    3144:	1e612800 	fadd	d0, d0, d1
    3148:	cb000042 	sub	x2, x2, x0
    314c:	f90a1022 	str	x2, [x1, #5152]
    3150:	fd0a2020 	str	d0, [x1, #5184]
    3154:	b40000b3 	cbz	x19, 3168 <fwp_mem_free+0x168>
    3158:	39400260 	ldrb	w0, [x19]
    315c:	7103fc1f 	cmp	w0, #0xff
    3160:	54000380 	b.eq	31d0 <fwp_mem_free+0x1d0>  // b.none
    3164:	3900027f 	strb	wzr, [x19]
    3168:	b9400ee2 	ldr	w2, [x23, #12]
    316c:	b4000142 	cbz	x2, 3194 <fwp_mem_free+0x194>
    3170:	9115c2a1 	add	x1, x21, #0x570
    3174:	8b160040 	add	x0, x2, x22
    3178:	8b000800 	add	x0, x0, x0, lsl #2
    317c:	f949fc21 	ldr	x1, [x1, #5112]
    3180:	8b140034 	add	x20, x1, x20
    3184:	8b000c20 	add	x0, x1, x0, lsl #3
    3188:	3802869f 	strb	wzr, [x20], #40
    318c:	eb00029f 	cmp	x20, x0
    3190:	54ffffc1 	b.ne	3188 <fwp_mem_free+0x188>  // b.any
    3194:	9115c2a0 	add	x0, x21, #0x570
    3198:	f94a1801 	ldr	x1, [x0, #5168]
    319c:	f949f803 	ldr	x3, [x0, #5104]
    31a0:	8b020021 	add	x1, x1, x2
    31a4:	f90a1801 	str	x1, [x0, #5168]
    31a8:	eb16007f 	cmp	x3, x22
    31ac:	54000049 	b.ls	31b4 <fwp_mem_free+0x1b4>  // b.plast
    31b0:	f909f816 	str	x22, [x0, #5104]
    31b4:	9115c2b5 	add	x21, x21, #0x570
    31b8:	f949f6a0 	ldr	x0, [x21, #5096]
    31bc:	eb16001f 	cmp	x0, x22
    31c0:	54fff529 	b.ls	3064 <fwp_mem_free+0x64>  // b.plast
    31c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    31c8:	f909f6b6 	str	x22, [x21, #5096]
    31cc:	17ffffa7 	b	3068 <fwp_mem_free+0x68>
    31d0:	aa1303e0 	mov	x0, x19
    31d4:	97fffeec 	bl	2d84 <fwp_rc_forget_slot>
    31d8:	17ffffe3 	b	3164 <fwp_mem_free+0x164>
    31dc:	97fffeea 	bl	2d84 <fwp_rc_forget_slot>
    31e0:	17ffffb4 	b	30b0 <fwp_mem_free+0xb0>

00000000000031e4 <fwp_heap_alloc_big>:
    31e4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    31e8:	910003fd 	mov	x29, sp
    31ec:	a90153f3 	stp	x19, x20, [sp, #16]
    31f0:	a9025bf5 	stp	x21, x22, [sp, #32]
    31f4:	a90363f7 	stp	x23, x24, [sp, #48]
    31f8:	aa0003f7 	mov	x23, x0
    31fc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    3200:	a9046bf9 	stp	x25, x26, [sp, #64]
    3204:	eb0002ff 	cmp	x23, x0
    3208:	54000888 	b.hi	3318 <fwp_heap_alloc_big+0x134>  // b.pmore
    320c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3210:	8b0002f4 	add	x20, x23, x0
    3214:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xc70>
    3218:	9115c359 	add	x25, x26, #0x570
    321c:	d350fe94 	lsr	x20, x20, #16
    3220:	2a0103f5 	mov	w21, w1
    3224:	aa1403e0 	mov	x0, x20
    3228:	97fffaba 	bl	1d10 <fwp_heap_chunks>
    322c:	f949ff22 	ldr	x2, [x25, #5112]
    3230:	8b000813 	add	x19, x0, x0, lsl #2
    3234:	aa0003f8 	mov	x24, x0
    3238:	52800043 	mov	w3, #0x2                   	// #2
    323c:	d37df273 	lsl	x19, x19, #3
    3240:	d2800021 	mov	x1, #0x1                   	// #1
    3244:	8b130040 	add	x0, x2, x19
    3248:	38336843 	strb	w3, [x2, x19]
    324c:	39000415 	strb	w21, [x0, #1]
    3250:	b9000c14 	str	w20, [x0, #12]
    3254:	f9000817 	str	x23, [x0, #16]
    3258:	97fffef2 	bl	2e20 <fwp_rc_prepare_chunk>
    325c:	f100069f 	cmp	x20, #0x1
    3260:	54000269 	b.ls	32ac <fwp_heap_alloc_big+0xc8>  // b.plast
    3264:	8b180294 	add	x20, x20, x24
    3268:	9100a273 	add	x19, x19, #0x28
    326c:	a90573fb 	stp	x27, x28, [sp, #80]
    3270:	5280007b 	mov	w27, #0x3                   	// #3
    3274:	8b140a94 	add	x20, x20, x20, lsl #2
    3278:	2a1803fc 	mov	w28, w24
    327c:	9adb2296 	lsl	x22, x20, x27
    3280:	f949ff35 	ldr	x21, [x25, #5112]
    3284:	d2800001 	mov	x1, #0x0                   	// #0
    3288:	8b1302b4 	add	x20, x21, x19
    328c:	aa1403e0 	mov	x0, x20
    3290:	97fffee4 	bl	2e20 <fwp_rc_prepare_chunk>
    3294:	38336abb 	strb	w27, [x21, x19]
    3298:	9100a273 	add	x19, x19, #0x28
    329c:	b9000e9c 	str	w28, [x20, #12]
    32a0:	eb1302df 	cmp	x22, x19
    32a4:	54fffee1 	b.ne	3280 <fwp_heap_alloc_big+0x9c>  // b.any
    32a8:	a94573fb 	ldp	x27, x28, [sp, #80]
    32ac:	9115c353 	add	x19, x26, #0x570
    32b0:	aa1703e2 	mov	x2, x23
    32b4:	52800001 	mov	w1, #0x0                   	// #0
    32b8:	f949da60 	ldr	x0, [x19, #5040]
    32bc:	8b184018 	add	x24, x0, x24, lsl #16
    32c0:	aa1803e0 	mov	x0, x24
    32c4:	97fff883 	bl	14d0 <memset@plt>
    32c8:	f94a1260 	ldr	x0, [x19, #5152]
    32cc:	ab170000 	adds	x0, x0, x23
    32d0:	54000242 	b.cs	3318 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    32d4:	f94a1661 	ldr	x1, [x19, #5160]
    32d8:	f90a1260 	str	x0, [x19, #5152]
    32dc:	eb01001f 	cmp	x0, x1
    32e0:	54000049 	b.ls	32e8 <fwp_heap_alloc_big+0x104>  // b.plast
    32e4:	f90a1660 	str	x0, [x19, #5160]
    32e8:	9115c35a 	add	x26, x26, #0x570
    32ec:	9e6202e0 	scvtf	d0, x23
    32f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32f4:	aa1803e0 	mov	x0, x24
    32f8:	fd4a1f41 	ldr	d1, [x26, #5176]
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	1e602820 	fadd	d0, d1, d0
    3304:	a94363f7 	ldp	x23, x24, [sp, #48]
    3308:	fd0a1f40 	str	d0, [x26, #5176]
    330c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3310:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3314:	d65f03c0 	ret
    3318:	a90573fb 	stp	x27, x28, [sp, #80]
    331c:	97fffa6d 	bl	1cd0 <fwp_heap_oom>

0000000000003320 <fwp_heap_alloc_slow>:
    3320:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3324:	910003fd 	mov	x29, sp
    3328:	a90153f3 	stp	x19, x20, [sp, #16]
    332c:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc70>
    3330:	9115c262 	add	x2, x19, #0x570
    3334:	a9025bf5 	stp	x21, x22, [sp, #32]
    3338:	aa0003f5 	mov	x21, x0
    333c:	2a0103f4 	mov	w20, w1
    3340:	b953a440 	ldr	w0, [x2, #5028]
    3344:	34000600 	cbz	w0, 3404 <fwp_heap_alloc_slow+0xe4>
    3348:	f14012bf 	cmp	x21, #0x4, lsl #12
    334c:	54000628 	b.hi	3410 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3350:	91003ea0 	add	x0, x21, #0xf
    3354:	9115c262 	add	x2, x19, #0x570
    3358:	f9001bf7 	str	x23, [sp, #48]
    335c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3360:	8b401040 	add	x0, x2, x0, lsr #4
    3364:	cb34c084 	sub	x4, x4, w20, sxtw
    3368:	d37ae484 	lsl	x4, x4, #6
    336c:	397e8003 	ldrb	w3, [x0, #4000]
    3370:	910f0060 	add	x0, x3, #0x3c0
    3374:	aa0303e1 	mov	x1, x3
    3378:	8b030463 	add	x3, x3, x3, lsl #1
    337c:	8b030c83 	add	x3, x4, x3, lsl #3
    3380:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3384:	2a1703f6 	mov	w22, w23
    3388:	f8636844 	ldr	x4, [x2, x3]
    338c:	b40004e4 	cbz	x4, 3428 <fwp_heap_alloc_slow+0x108>
    3390:	f9400080 	ldr	x0, [x4]
    3394:	aa2003e0 	mvn	x0, x0
    3398:	f8236840 	str	x0, [x2, x3]
    339c:	7100069f 	cmp	w20, #0x1
    33a0:	aa0403e0 	mov	x0, x4
    33a4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    33a8:	52800001 	mov	w1, #0x0                   	// #0
    33ac:	97fff849 	bl	14d0 <memset@plt>
    33b0:	aa0003e4 	mov	x4, x0
    33b4:	9115c260 	add	x0, x19, #0x570
    33b8:	f94a1001 	ldr	x1, [x0, #5152]
    33bc:	ab160021 	adds	x1, x1, x22
    33c0:	540005c2 	b.cs	3478 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    33c4:	f94a1402 	ldr	x2, [x0, #5160]
    33c8:	f90a1001 	str	x1, [x0, #5152]
    33cc:	eb02003f 	cmp	x1, x2
    33d0:	54000049 	b.ls	33d8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    33d4:	f90a1401 	str	x1, [x0, #5160]
    33d8:	9115c273 	add	x19, x19, #0x570
    33dc:	1e6302e1 	ucvtf	d1, w23
    33e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33e4:	aa0403e0 	mov	x0, x4
    33e8:	fd4a1e60 	ldr	d0, [x19, #5176]
    33ec:	f9401bf7 	ldr	x23, [sp, #48]
    33f0:	1e612800 	fadd	d0, d0, d1
    33f4:	fd0a1e60 	str	d0, [x19, #5176]
    33f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3400:	d65f03c0 	ret
    3404:	97fffd33 	bl	28d0 <fwp_heap_init>
    3408:	f14012bf 	cmp	x21, #0x4, lsl #12
    340c:	54fffa29 	b.ls	3350 <fwp_heap_alloc_slow+0x30>  // b.plast
    3410:	2a1403e1 	mov	w1, w20
    3414:	aa1503e0 	mov	x0, x21
    3418:	a94153f3 	ldp	x19, x20, [sp, #16]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3424:	17ffff70 	b	31e4 <fwp_heap_alloc_big>
    3428:	8b030042 	add	x2, x2, x3
    342c:	f9400444 	ldr	x4, [x2, #8]
    3430:	b4000104 	cbz	x4, 3450 <fwp_heap_alloc_slow+0x130>
    3434:	f9400840 	ldr	x0, [x2, #16]
    3438:	cb040000 	sub	x0, x0, x4
    343c:	eb16001f 	cmp	x0, x22
    3440:	54000083 	b.cc	3450 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3444:	8b160080 	add	x0, x4, x22
    3448:	f9000440 	str	x0, [x2, #8]
    344c:	17ffffd4 	b	339c <fwp_heap_alloc_slow+0x7c>
    3450:	52800302 	mov	w2, #0x18                  	// #24
    3454:	52807804 	mov	w4, #0x3c0                 	// #960
    3458:	9115c260 	add	x0, x19, #0x570
    345c:	9ba27c23 	umull	x3, w1, w2
    3460:	2a1403e2 	mov	w2, w20
    3464:	9b240e84 	smaddl	x4, w20, w4, x3
    3468:	8b040000 	add	x0, x0, x4
    346c:	97fffeb5 	bl	2f40 <fwp_heap_refill>
    3470:	aa0003e4 	mov	x4, x0
    3474:	17ffffca 	b	339c <fwp_heap_alloc_slow+0x7c>
    3478:	97fffa16 	bl	1cd0 <fwp_heap_oom>
    347c:	d503201f 	nop

0000000000003480 <fwp_rc_fresh>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xc70>
    3488:	9115c063 	add	x3, x3, #0x570
    348c:	910003fd 	mov	x29, sp
    3490:	a90153f3 	stp	x19, x20, [sp, #16]
    3494:	aa0003f3 	mov	x19, x0
    3498:	f949d861 	ldr	x1, [x3, #5040]
    349c:	f949ec60 	ldr	x0, [x3, #5080]
    34a0:	cb010261 	sub	x1, x19, x1
    34a4:	eb00403f 	cmp	x1, x0, lsl #16
    34a8:	54000322 	b.cs	350c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    34ac:	d350fc22 	lsr	x2, x1, #16
    34b0:	f949fc63 	ldr	x3, [x3, #5112]
    34b4:	8b020842 	add	x2, x2, x2, lsl #2
    34b8:	d37df042 	lsl	x2, x2, #3
    34bc:	8b020060 	add	x0, x3, x2
    34c0:	f9401014 	ldr	x20, [x0, #32]
    34c4:	b4000254 	cbz	x20, 350c <fwp_rc_fresh+0x8c>
    34c8:	38626862 	ldrb	w2, [x3, x2]
    34cc:	7100085f 	cmp	w2, #0x2
    34d0:	54000260 	b.eq	351c <fwp_rc_fresh+0x9c>  // b.none
    34d4:	7100045f 	cmp	w2, #0x1
    34d8:	540001a1 	b.ne	350c <fwp_rc_fresh+0x8c>  // b.any
    34dc:	29430002 	ldp	w2, w0, [x0, #24]
    34e0:	92403c21 	and	x1, x1, #0xffff
    34e4:	9b027c21 	mul	x1, x1, x2
    34e8:	d360fc21 	lsr	x1, x1, #32
    34ec:	eb00003f 	cmp	x1, x0
    34f0:	540000e2 	b.cs	350c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    34f4:	8b010294 	add	x20, x20, x1
    34f8:	39400280 	ldrb	w0, [x20]
    34fc:	7103fc1f 	cmp	w0, #0xff
    3500:	540001a0 	b.eq	3534 <fwp_rc_fresh+0xb4>  // b.none
    3504:	52800020 	mov	w0, #0x1                   	// #1
    3508:	39000280 	strb	w0, [x20]
    350c:	aa1303e0 	mov	x0, x19
    3510:	a94153f3 	ldp	x19, x20, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	72003c3f 	tst	w1, #0xffff
    3520:	54fffec0 	b.eq	34f8 <fwp_rc_fresh+0x78>  // b.none
    3524:	aa1303e0 	mov	x0, x19
    3528:	a94153f3 	ldp	x19, x20, [sp, #16]
    352c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3530:	d65f03c0 	ret
    3534:	aa1403e0 	mov	x0, x20
    3538:	97fffe13 	bl	2d84 <fwp_rc_forget_slot>
    353c:	17fffff2 	b	3504 <fwp_rc_fresh+0x84>

0000000000003540 <fwp_rc_free_arr>:
    3540:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xc70>
    3544:	9115c063 	add	x3, x3, #0x570
    3548:	f949d861 	ldr	x1, [x3, #5040]
    354c:	f949ec62 	ldr	x2, [x3, #5080]
    3550:	cb010001 	sub	x1, x0, x1
    3554:	eb02403f 	cmp	x1, x2, lsl #16
    3558:	54000342 	b.cs	35c0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    355c:	d350fc22 	lsr	x2, x1, #16
    3560:	f949fc65 	ldr	x5, [x3, #5112]
    3564:	8b020842 	add	x2, x2, x2, lsl #2
    3568:	d37df042 	lsl	x2, x2, #3
    356c:	8b0200a4 	add	x4, x5, x2
    3570:	f9401083 	ldr	x3, [x4, #32]
    3574:	b4000263 	cbz	x3, 35c0 <fwp_rc_free_arr+0x80>
    3578:	386268a2 	ldrb	w2, [x5, x2]
    357c:	7100085f 	cmp	w2, #0x2
    3580:	540001c0 	b.eq	35b8 <fwp_rc_free_arr+0x78>  // b.none
    3584:	7100045f 	cmp	w2, #0x1
    3588:	540001c1 	b.ne	35c0 <fwp_rc_free_arr+0x80>  // b.any
    358c:	29430885 	ldp	w5, w2, [x4, #24]
    3590:	92403c21 	and	x1, x1, #0xffff
    3594:	9b057c21 	mul	x1, x1, x5
    3598:	d360fc21 	lsr	x1, x1, #32
    359c:	eb02003f 	cmp	x1, x2
    35a0:	54000102 	b.cs	35c0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    35a4:	8b010063 	add	x3, x3, x1
    35a8:	39400061 	ldrb	w1, [x3]
    35ac:	7100043f 	cmp	w1, #0x1
    35b0:	54000081 	b.ne	35c0 <fwp_rc_free_arr+0x80>  // b.any
    35b4:	17fffe93 	b	3000 <fwp_mem_free>
    35b8:	72003c3f 	tst	w1, #0xffff
    35bc:	54ffff60 	b.eq	35a8 <fwp_rc_free_arr+0x68>  // b.none
    35c0:	d65f03c0 	ret

00000000000035c4 <fwp_heap_alloc>:
    35c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    35c8:	910003fd 	mov	x29, sp
    35cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    35d0:	b00000f6 	adrp	x22, 20000 <__data_start>
    35d4:	910242c2 	add	x2, x22, #0x90
    35d8:	a90363f7 	stp	x23, x24, [sp, #48]
    35dc:	b9404058 	ldr	w24, [x2, #64]
    35e0:	a90153f3 	stp	x19, x20, [sp, #16]
    35e4:	7100031f 	cmp	w24, #0x0
    35e8:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    35ec:	54000861 	b.ne	36f8 <fwp_heap_alloc+0x134>  // b.any
    35f0:	d0000177 	adrp	x23, 31000 <fwp_root_context+0xc70>
    35f4:	9115c2f3 	add	x19, x23, #0x570
    35f8:	f140101f 	cmp	x0, #0x4, lsl #12
    35fc:	b953a662 	ldr	w2, [x19, #5028]
    3600:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3604:	54000740 	b.eq	36ec <fwp_heap_alloc+0x128>  // b.none
    3608:	91003c03 	add	x3, x0, #0xf
    360c:	937c7c22 	sbfiz	x2, x1, #4, #32
    3610:	cb21c042 	sub	x2, x2, w1, sxtw
    3614:	8b431263 	add	x3, x19, x3, lsr #4
    3618:	d37ae442 	lsl	x2, x2, #6
    361c:	397e8063 	ldrb	w3, [x3, #4000]
    3620:	910f0064 	add	x4, x3, #0x3c0
    3624:	8b030463 	add	x3, x3, x3, lsl #1
    3628:	8b030c43 	add	x3, x2, x3, lsl #3
    362c:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    3630:	2a1503f4 	mov	w20, w21
    3634:	f8636a64 	ldr	x4, [x19, x3]
    3638:	b40004c4 	cbz	x4, 36d0 <fwp_heap_alloc+0x10c>
    363c:	f9400085 	ldr	x5, [x4]
    3640:	7100043f 	cmp	w1, #0x1
    3644:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3648:	aa0403e0 	mov	x0, x4
    364c:	aa2503e5 	mvn	x5, x5
    3650:	52800001 	mov	w1, #0x0                   	// #0
    3654:	f8236a65 	str	x5, [x19, x3]
    3658:	97fff79e 	bl	14d0 <memset@plt>
    365c:	aa0003e4 	mov	x4, x0
    3660:	f94a1260 	ldr	x0, [x19, #5152]
    3664:	ab140000 	adds	x0, x0, x20
    3668:	540006e2 	b.cs	3744 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    366c:	f94a1661 	ldr	x1, [x19, #5160]
    3670:	f90a1260 	str	x0, [x19, #5152]
    3674:	eb01001f 	cmp	x0, x1
    3678:	54000049 	b.ls	3680 <fwp_heap_alloc+0xbc>  // b.plast
    367c:	f90a1660 	str	x0, [x19, #5160]
    3680:	9115c2e0 	add	x0, x23, #0x570
    3684:	1e6302a1 	ucvtf	d1, w21
    3688:	fd4a1c00 	ldr	d0, [x0, #5176]
    368c:	1e612800 	fadd	d0, d0, d1
    3690:	fd0a1c00 	str	d0, [x0, #5176]
    3694:	34000138 	cbz	w24, 36b8 <fwp_heap_alloc+0xf4>
    3698:	9115c2e1 	add	x1, x23, #0x570
    369c:	910242c0 	add	x0, x22, #0x90
    36a0:	fd4a1020 	ldr	d0, [x1, #5152]
    36a4:	6d458402 	ldp	d2, d1, [x0, #88]
    36a8:	7e61d800 	ucvtf	d0, d0
    36ac:	1e623800 	fsub	d0, d0, d2
    36b0:	1e612010 	fcmpe	d0, d1
    36b4:	540002cc 	b.gt	370c <fwp_heap_alloc+0x148>
    36b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36bc:	aa0403e0 	mov	x0, x4
    36c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    36c8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    36cc:	d65f03c0 	ret
    36d0:	8b030263 	add	x3, x19, x3
    36d4:	f9400464 	ldr	x4, [x3, #8]
    36d8:	b40000a4 	cbz	x4, 36ec <fwp_heap_alloc+0x128>
    36dc:	f9400862 	ldr	x2, [x3, #16]
    36e0:	cb040042 	sub	x2, x2, x4
    36e4:	eb02029f 	cmp	x20, x2
    36e8:	54000209 	b.ls	3728 <fwp_heap_alloc+0x164>  // b.plast
    36ec:	97ffff0d 	bl	3320 <fwp_heap_alloc_slow>
    36f0:	aa0003e4 	mov	x4, x0
    36f4:	17ffffe8 	b	3694 <fwp_heap_alloc+0xd0>
    36f8:	a9448c44 	ldp	x4, x3, [x2, #72]
    36fc:	91000484 	add	x4, x4, #0x1
    3700:	8b000063 	add	x3, x3, x0
    3704:	a9048c44 	stp	x4, x3, [x2, #72]
    3708:	17ffffba 	b	35f0 <fwp_heap_alloc+0x2c>
    370c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3710:	fd003000 	str	d0, [x0, #96]
    3714:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3718:	aa0403e0 	mov	x0, x4
    371c:	a94363f7 	ldp	x23, x24, [sp, #48]
    3720:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3724:	d65f03c0 	ret
    3728:	7100043f 	cmp	w1, #0x1
    372c:	8b140085 	add	x5, x4, x20
    3730:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3734:	52800001 	mov	w1, #0x0                   	// #0
    3738:	aa0403e0 	mov	x0, x4
    373c:	f9000465 	str	x5, [x3, #8]
    3740:	17ffffc6 	b	3658 <fwp_heap_alloc+0x94>
    3744:	97fff963 	bl	1cd0 <fwp_heap_oom>
    3748:	d503201f 	nop
    374c:	d503201f 	nop

0000000000003750 <fwp_data.part.0.constprop.0>:
    3750:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3754:	910003fd 	mov	x29, sp
    3758:	a9025bf5 	stp	x21, x22, [sp, #32]
    375c:	b00000f6 	adrp	x22, 20000 <__data_start>
    3760:	910242c1 	add	x1, x22, #0x90
    3764:	a90363f7 	stp	x23, x24, [sp, #48]
    3768:	b9404038 	ldr	w24, [x1, #64]
    376c:	a90153f3 	stp	x19, x20, [sp, #16]
    3770:	aa0003f4 	mov	x20, x0
    3774:	340000b8 	cbz	w24, 3788 <fwp_data.part.0.constprop.0+0x38>
    3778:	a9448022 	ldp	x2, x0, [x1, #72]
    377c:	91000442 	add	x2, x2, #0x1
    3780:	91006000 	add	x0, x0, #0x18
    3784:	a9048022 	stp	x2, x0, [x1, #72]
    3788:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    378c:	9115c2a2 	add	x2, x21, #0x570
    3790:	b953a440 	ldr	w0, [x2, #5028]
    3794:	34000840 	cbz	w0, 389c <fwp_data.part.0.constprop.0+0x14c>
    3798:	f90023f9 	str	x25, [sp, #64]
    379c:	397e8841 	ldrb	w1, [x2, #4002]
    37a0:	910f0020 	add	x0, x1, #0x3c0
    37a4:	8b010421 	add	x1, x1, x1, lsl #1
    37a8:	d37df021 	lsl	x1, x1, #3
    37ac:	b8607859 	ldr	w25, [x2, x0, lsl #2]
    37b0:	2a1903f7 	mov	w23, w25
    37b4:	f8616853 	ldr	x19, [x2, x1]
    37b8:	b4000633 	cbz	x19, 387c <fwp_data.part.0.constprop.0+0x12c>
    37bc:	f9400260 	ldr	x0, [x19]
    37c0:	aa2003e0 	mvn	x0, x0
    37c4:	f8216840 	str	x0, [x2, x1]
    37c8:	f10062ff 	cmp	x23, #0x18
    37cc:	540000e9 	b.ls	37e8 <fwp_data.part.0.constprop.0+0x98>  // b.plast
    37d0:	d10066e2 	sub	x2, x23, #0x19
    37d4:	91006260 	add	x0, x19, #0x18
    37d8:	927df042 	and	x2, x2, #0xfffffffffffffff8
    37dc:	52800001 	mov	w1, #0x0                   	// #0
    37e0:	91002042 	add	x2, x2, #0x8
    37e4:	97fff73b 	bl	14d0 <memset@plt>
    37e8:	9115c2a1 	add	x1, x21, #0x570
    37ec:	f94a1020 	ldr	x0, [x1, #5152]
    37f0:	ab170000 	adds	x0, x0, x23
    37f4:	54000682 	b.cs	38c4 <fwp_data.part.0.constprop.0+0x174>  // b.hs, b.nlast
    37f8:	f94a1422 	ldr	x2, [x1, #5160]
    37fc:	f90a1020 	str	x0, [x1, #5152]
    3800:	eb02001f 	cmp	x0, x2
    3804:	54000049 	b.ls	380c <fwp_data.part.0.constprop.0+0xbc>  // b.plast
    3808:	f90a1420 	str	x0, [x1, #5160]
    380c:	9115c2a0 	add	x0, x21, #0x570
    3810:	1e630321 	ucvtf	d1, w25
    3814:	f94023f9 	ldr	x25, [sp, #64]
    3818:	fd4a1c00 	ldr	d0, [x0, #5176]
    381c:	1e612800 	fadd	d0, d0, d1
    3820:	fd0a1c00 	str	d0, [x0, #5176]
    3824:	34000138 	cbz	w24, 3848 <fwp_data.part.0.constprop.0+0xf8>
    3828:	9115c2b5 	add	x21, x21, #0x570
    382c:	910242d6 	add	x22, x22, #0x90
    3830:	fd4a12a0 	ldr	d0, [x21, #5152]
    3834:	6d4586c2 	ldp	d2, d1, [x22, #88]
    3838:	7e61d800 	ucvtf	d0, d0
    383c:	1e623800 	fsub	d0, d0, d2
    3840:	1e612010 	fcmpe	d0, d1
    3844:	5400036c 	b.gt	38b0 <fwp_data.part.0.constprop.0+0x160>
    3848:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    384c:	fd428000 	ldr	d0, [x0, #1280]
    3850:	aa1303e0 	mov	x0, x19
    3854:	fd000260 	str	d0, [x19]
    3858:	f9400281 	ldr	x1, [x20]
    385c:	f9000661 	str	x1, [x19, #8]
    3860:	f9400681 	ldr	x1, [x20, #8]
    3864:	f9000a61 	str	x1, [x19, #16]
    3868:	a94153f3 	ldp	x19, x20, [sp, #16]
    386c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3870:	a94363f7 	ldp	x23, x24, [sp, #48]
    3874:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3878:	d65f03c0 	ret
    387c:	8b010042 	add	x2, x2, x1
    3880:	f9400453 	ldr	x19, [x2, #8]
    3884:	b40000b3 	cbz	x19, 3898 <fwp_data.part.0.constprop.0+0x148>
    3888:	f9400840 	ldr	x0, [x2, #16]
    388c:	cb130000 	sub	x0, x0, x19
    3890:	eb0002ff 	cmp	x23, x0
    3894:	54000129 	b.ls	38b8 <fwp_data.part.0.constprop.0+0x168>  // b.plast
    3898:	f94023f9 	ldr	x25, [sp, #64]
    389c:	52800001 	mov	w1, #0x0                   	// #0
    38a0:	d2800300 	mov	x0, #0x18                  	// #24
    38a4:	97ffff48 	bl	35c4 <fwp_heap_alloc>
    38a8:	aa0003f3 	mov	x19, x0
    38ac:	17ffffde 	b	3824 <fwp_data.part.0.constprop.0+0xd4>
    38b0:	fd0032c0 	str	d0, [x22, #96]
    38b4:	17ffffe5 	b	3848 <fwp_data.part.0.constprop.0+0xf8>
    38b8:	8b170260 	add	x0, x19, x23
    38bc:	f9000440 	str	x0, [x2, #8]
    38c0:	17ffffc2 	b	37c8 <fwp_data.part.0.constprop.0+0x78>
    38c4:	97fff903 	bl	1cd0 <fwp_heap_oom>
    38c8:	d503201f 	nop
    38cc:	d503201f 	nop

00000000000038d0 <fwp_array_new_packed.constprop.0>:
    38d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    38d4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    38d8:	910003fd 	mov	x29, sp
    38dc:	f9000bf3 	str	x19, [sp, #16]
    38e0:	eb01001f 	cmp	x0, x1
    38e4:	54000148 	b.hi	390c <fwp_array_new_packed.constprop.0+0x3c>  // b.pmore
    38e8:	aa0003f3 	mov	x19, x0
    38ec:	91000400 	add	x0, x0, #0x1
    38f0:	52800021 	mov	w1, #0x1                   	// #1
    38f4:	d37df000 	lsl	x0, x0, #3
    38f8:	97ffff33 	bl	35c4 <fwp_heap_alloc>
    38fc:	f9000013 	str	x19, [x0]
    3900:	f9400bf3 	ldr	x19, [sp, #16]
    3904:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3908:	d65f03c0 	ret
    390c:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    3910:	91040000 	add	x0, x0, #0x100
    3914:	97fffa5b 	bl	2280 <fwp_trap>
    3918:	d503201f 	nop
    391c:	d503201f 	nop

0000000000003920 <fwp_drop0>:
    3920:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3924:	910003fd 	mov	x29, sp
    3928:	a90153f3 	stp	x19, x20, [sp, #16]
    392c:	f90013f5 	str	x21, [sp, #32]
    3930:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    3934:	9115c2b4 	add	x20, x21, #0x570
    3938:	f949da81 	ldr	x1, [x20, #5040]
    393c:	f949ee82 	ldr	x2, [x20, #5080]
    3940:	cb010001 	sub	x1, x0, x1
    3944:	eb02403f 	cmp	x1, x2, lsl #16
    3948:	54000382 	b.cs	39b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    394c:	d350fc22 	lsr	x2, x1, #16
    3950:	f949fe84 	ldr	x4, [x20, #5112]
    3954:	8b020842 	add	x2, x2, x2, lsl #2
    3958:	d37df042 	lsl	x2, x2, #3
    395c:	8b020083 	add	x3, x4, x2
    3960:	f9401073 	ldr	x19, [x3, #32]
    3964:	b40002b3 	cbz	x19, 39b8 <fwp_drop0+0x98>
    3968:	38626882 	ldrb	w2, [x4, x2]
    396c:	7100085f 	cmp	w2, #0x2
    3970:	540002c0 	b.eq	39c8 <fwp_drop0+0xa8>  // b.none
    3974:	7100045f 	cmp	w2, #0x1
    3978:	54000201 	b.ne	39b8 <fwp_drop0+0x98>  // b.any
    397c:	29430864 	ldp	w4, w2, [x3, #24]
    3980:	92403c21 	and	x1, x1, #0xffff
    3984:	9b047c21 	mul	x1, x1, x4
    3988:	d360fc21 	lsr	x1, x1, #32
    398c:	eb02003f 	cmp	x1, x2
    3990:	54000142 	b.cs	39b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    3994:	8b010273 	add	x19, x19, x1
    3998:	39400261 	ldrb	w1, [x19]
    399c:	340000e1 	cbz	w1, 39b8 <fwp_drop0+0x98>
    39a0:	7100043f 	cmp	w1, #0x1
    39a4:	540001e0 	b.eq	39e0 <fwp_drop0+0xc0>  // b.none
    39a8:	7103fc3f 	cmp	w1, #0xff
    39ac:	540002e0 	b.eq	3a08 <fwp_drop0+0xe8>  // b.none
    39b0:	51000421 	sub	w1, w1, #0x1
    39b4:	39000261 	strb	w1, [x19]
    39b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39bc:	f94013f5 	ldr	x21, [sp, #32]
    39c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    39c4:	d65f03c0 	ret
    39c8:	72003c3f 	tst	w1, #0xffff
    39cc:	54fffe60 	b.eq	3998 <fwp_drop0+0x78>  // b.none
    39d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    39d4:	f94013f5 	ldr	x21, [sp, #32]
    39d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    39dc:	d65f03c0 	ret
    39e0:	f9400813 	ldr	x19, [x0, #16]
    39e4:	97fffed7 	bl	3540 <fwp_rc_free_arr>
    39e8:	9115c2a0 	add	x0, x21, #0x570
    39ec:	f949d801 	ldr	x1, [x0, #5040]
    39f0:	f949ec00 	ldr	x0, [x0, #5080]
    39f4:	cb010261 	sub	x1, x19, x1
    39f8:	eb00403f 	cmp	x1, x0, lsl #16
    39fc:	54fffde2 	b.cs	39b8 <fwp_drop0+0x98>  // b.hs, b.nlast
    3a00:	aa1303e0 	mov	x0, x19
    3a04:	17ffffd2 	b	394c <fwp_drop0+0x2c>
    3a08:	ca534660 	eor	x0, x19, x19, lsr #17
    3a0c:	9115c2b5 	add	x21, x21, #0x570
    3a10:	ca402400 	eor	x0, x0, x0, lsr #9
    3a14:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3a18:	f94a2400 	ldr	x0, [x0, #5192]
    3a1c:	b5000080 	cbnz	x0, 3a2c <fwp_drop0+0x10c>
    3a20:	14000010 	b	3a60 <fwp_drop0+0x140>
    3a24:	f9400800 	ldr	x0, [x0, #16]
    3a28:	b40001c0 	cbz	x0, 3a60 <fwp_drop0+0x140>
    3a2c:	f9400001 	ldr	x1, [x0]
    3a30:	eb13003f 	cmp	x1, x19
    3a34:	54ffff81 	b.ne	3a24 <fwp_drop0+0x104>  // b.any
    3a38:	f9400401 	ldr	x1, [x0, #8]
    3a3c:	d1000421 	sub	x1, x1, #0x1
    3a40:	f9000401 	str	x1, [x0, #8]
    3a44:	f103f83f 	cmp	x1, #0xfe
    3a48:	54fffb81 	b.ne	39b8 <fwp_drop0+0x98>  // b.any
    3a4c:	aa1303e0 	mov	x0, x19
    3a50:	97fffccd 	bl	2d84 <fwp_rc_forget_slot>
    3a54:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3a58:	39000260 	strb	w0, [x19]
    3a5c:	17ffffd7 	b	39b8 <fwp_drop0+0x98>
    3a60:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    3a64:	91036000 	add	x0, x0, #0xd8
    3a68:	97fffa06 	bl	2280 <fwp_trap>
    3a6c:	d503201f 	nop

0000000000003a70 <fwp_drop1>:
    3a70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a74:	910003fd 	mov	x29, sp
    3a78:	a90153f3 	stp	x19, x20, [sp, #16]
    3a7c:	f90013f5 	str	x21, [sp, #32]
    3a80:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc70>
    3a84:	9115c2b4 	add	x20, x21, #0x570
    3a88:	f949da81 	ldr	x1, [x20, #5040]
    3a8c:	f949ee82 	ldr	x2, [x20, #5080]
    3a90:	cb010001 	sub	x1, x0, x1
    3a94:	eb02403f 	cmp	x1, x2, lsl #16
    3a98:	54000382 	b.cs	3b08 <fwp_drop1+0x98>  // b.hs, b.nlast
    3a9c:	d350fc22 	lsr	x2, x1, #16
    3aa0:	f949fe84 	ldr	x4, [x20, #5112]
    3aa4:	8b020842 	add	x2, x2, x2, lsl #2
    3aa8:	d37df042 	lsl	x2, x2, #3
    3aac:	8b020083 	add	x3, x4, x2
    3ab0:	f9401073 	ldr	x19, [x3, #32]
    3ab4:	b40002b3 	cbz	x19, 3b08 <fwp_drop1+0x98>
    3ab8:	38626882 	ldrb	w2, [x4, x2]
    3abc:	7100085f 	cmp	w2, #0x2
    3ac0:	540002c0 	b.eq	3b18 <fwp_drop1+0xa8>  // b.none
    3ac4:	7100045f 	cmp	w2, #0x1
    3ac8:	54000201 	b.ne	3b08 <fwp_drop1+0x98>  // b.any
    3acc:	29430864 	ldp	w4, w2, [x3, #24]
    3ad0:	92403c21 	and	x1, x1, #0xffff
    3ad4:	9b047c21 	mul	x1, x1, x4
    3ad8:	d360fc21 	lsr	x1, x1, #32
    3adc:	eb02003f 	cmp	x1, x2
    3ae0:	54000142 	b.cs	3b08 <fwp_drop1+0x98>  // b.hs, b.nlast
    3ae4:	8b010273 	add	x19, x19, x1
    3ae8:	39400261 	ldrb	w1, [x19]
    3aec:	340000e1 	cbz	w1, 3b08 <fwp_drop1+0x98>
    3af0:	7100043f 	cmp	w1, #0x1
    3af4:	540001e0 	b.eq	3b30 <fwp_drop1+0xc0>  // b.none
    3af8:	7103fc3f 	cmp	w1, #0xff
    3afc:	540002e0 	b.eq	3b58 <fwp_drop1+0xe8>  // b.none
    3b00:	51000421 	sub	w1, w1, #0x1
    3b04:	39000261 	strb	w1, [x19]
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	f94013f5 	ldr	x21, [sp, #32]
    3b10:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b14:	d65f03c0 	ret
    3b18:	72003c3f 	tst	w1, #0xffff
    3b1c:	54fffe60 	b.eq	3ae8 <fwp_drop1+0x78>  // b.none
    3b20:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b24:	f94013f5 	ldr	x21, [sp, #32]
    3b28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b2c:	d65f03c0 	ret
    3b30:	f9400813 	ldr	x19, [x0, #16]
    3b34:	97fffe83 	bl	3540 <fwp_rc_free_arr>
    3b38:	9115c2a0 	add	x0, x21, #0x570
    3b3c:	f949d801 	ldr	x1, [x0, #5040]
    3b40:	f949ec00 	ldr	x0, [x0, #5080]
    3b44:	cb010261 	sub	x1, x19, x1
    3b48:	eb00403f 	cmp	x1, x0, lsl #16
    3b4c:	54fffde2 	b.cs	3b08 <fwp_drop1+0x98>  // b.hs, b.nlast
    3b50:	aa1303e0 	mov	x0, x19
    3b54:	17ffffd2 	b	3a9c <fwp_drop1+0x2c>
    3b58:	ca534660 	eor	x0, x19, x19, lsr #17
    3b5c:	9115c2b5 	add	x21, x21, #0x570
    3b60:	ca402400 	eor	x0, x0, x0, lsr #9
    3b64:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3b68:	f94a2400 	ldr	x0, [x0, #5192]
    3b6c:	b5000080 	cbnz	x0, 3b7c <fwp_drop1+0x10c>
    3b70:	14000010 	b	3bb0 <fwp_drop1+0x140>
    3b74:	f9400800 	ldr	x0, [x0, #16]
    3b78:	b40001c0 	cbz	x0, 3bb0 <fwp_drop1+0x140>
    3b7c:	f9400001 	ldr	x1, [x0]
    3b80:	eb13003f 	cmp	x1, x19
    3b84:	54ffff81 	b.ne	3b74 <fwp_drop1+0x104>  // b.any
    3b88:	f9400401 	ldr	x1, [x0, #8]
    3b8c:	d1000421 	sub	x1, x1, #0x1
    3b90:	f9000401 	str	x1, [x0, #8]
    3b94:	f103f83f 	cmp	x1, #0xfe
    3b98:	54fffb81 	b.ne	3b08 <fwp_drop1+0x98>  // b.any
    3b9c:	aa1303e0 	mov	x0, x19
    3ba0:	97fffc79 	bl	2d84 <fwp_rc_forget_slot>
    3ba4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3ba8:	39000260 	strb	w0, [x19]
    3bac:	17ffffd7 	b	3b08 <fwp_drop1+0x98>
    3bb0:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    3bb4:	91036000 	add	x0, x0, #0xd8
    3bb8:	97fff9b2 	bl	2280 <fwp_trap>
    3bbc:	d503201f 	nop

0000000000003bc0 <fwp_task_dispose>:
    3bc0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3bc4:	910003fd 	mov	x29, sp
    3bc8:	f9000bf3 	str	x19, [sp, #16]
    3bcc:	aa0003f3 	mov	x19, x0
    3bd0:	39414000 	ldrb	w0, [x0, #80]
    3bd4:	36000720 	tbz	w0, #0, 3cb8 <fwp_task_dispose+0xf8>
    3bd8:	f9400a60 	ldr	x0, [x19, #16]
    3bdc:	b50006e0 	cbnz	x0, 3cb8 <fwp_task_dispose+0xf8>
    3be0:	a9478660 	ldp	x0, x1, [x19, #120]
    3be4:	39014e7f 	strb	wzr, [x19, #83]
    3be8:	f9003e7f 	str	xzr, [x19, #120]
    3bec:	f100003f 	cmp	x1, #0x0
    3bf0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3bf4:	54000040 	b.eq	3bfc <fwp_task_dispose+0x3c>  // b.none
    3bf8:	d63f0020 	blr	x1
    3bfc:	f9405660 	ldr	x0, [x19, #168]
    3c00:	97fffd00 	bl	3000 <fwp_mem_free>
    3c04:	f900567f 	str	xzr, [x19, #168]
    3c08:	b9405e60 	ldr	w0, [x19, #92]
    3c0c:	7100041f 	cmp	w0, #0x1
    3c10:	54000420 	b.eq	3c94 <fwp_task_dispose+0xd4>  // b.none
    3c14:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc70>
    3c18:	9115c042 	add	x2, x2, #0x570
    3c1c:	f949d840 	ldr	x0, [x2, #5040]
    3c20:	f949ec41 	ldr	x1, [x2, #5080]
    3c24:	cb000260 	sub	x0, x19, x0
    3c28:	eb01401f 	cmp	x0, x1, lsl #16
    3c2c:	540002e2 	b.cs	3c88 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3c30:	d350fc01 	lsr	x1, x0, #16
    3c34:	f949fc44 	ldr	x4, [x2, #5112]
    3c38:	8b010821 	add	x1, x1, x1, lsl #2
    3c3c:	d37df021 	lsl	x1, x1, #3
    3c40:	8b010083 	add	x3, x4, x1
    3c44:	f9401062 	ldr	x2, [x3, #32]
    3c48:	b4000202 	cbz	x2, 3c88 <fwp_task_dispose+0xc8>
    3c4c:	38616881 	ldrb	w1, [x4, x1]
    3c50:	7100083f 	cmp	w1, #0x2
    3c54:	54000280 	b.eq	3ca4 <fwp_task_dispose+0xe4>  // b.none
    3c58:	7100043f 	cmp	w1, #0x1
    3c5c:	54000161 	b.ne	3c88 <fwp_task_dispose+0xc8>  // b.any
    3c60:	29430464 	ldp	w4, w1, [x3, #24]
    3c64:	92403c00 	and	x0, x0, #0xffff
    3c68:	9b047c00 	mul	x0, x0, x4
    3c6c:	d360fc00 	lsr	x0, x0, #32
    3c70:	eb01001f 	cmp	x0, x1
    3c74:	540000a2 	b.cs	3c88 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3c78:	8b000042 	add	x2, x2, x0
    3c7c:	39400040 	ldrb	w0, [x2]
    3c80:	7100041f 	cmp	w0, #0x1
    3c84:	54000080 	b.eq	3c94 <fwp_task_dispose+0xd4>  // b.none
    3c88:	f9400bf3 	ldr	x19, [sp, #16]
    3c8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c90:	d65f03c0 	ret
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	f9400bf3 	ldr	x19, [sp, #16]
    3c9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3ca0:	17fffcd8 	b	3000 <fwp_mem_free>
    3ca4:	72003c1f 	tst	w0, #0xffff
    3ca8:	54fffea0 	b.eq	3c7c <fwp_task_dispose+0xbc>  // b.none
    3cac:	f9400bf3 	ldr	x19, [sp, #16]
    3cb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3cb4:	d65f03c0 	ret
    3cb8:	97fff626 	bl	1550 <abort@plt>
    3cbc:	d503201f 	nop

0000000000003cc0 <fwp_free_zombie>:
    3cc0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3cc4:	910003fd 	mov	x29, sp
    3cc8:	a90153f3 	stp	x19, x20, [sp, #16]
    3ccc:	b00000f4 	adrp	x20, 20000 <__data_start>
    3cd0:	91024281 	add	x1, x20, #0x90
    3cd4:	f9403433 	ldr	x19, [x1, #104]
    3cd8:	b4000333 	cbz	x19, 3d3c <fwp_free_zombie+0x7c>
    3cdc:	f9400420 	ldr	x0, [x1, #8]
    3ce0:	eb00027f 	cmp	x19, x0
    3ce4:	540002c0 	b.eq	3d3c <fwp_free_zombie+0x7c>  // b.none
    3ce8:	b9407022 	ldr	w2, [x1, #112]
    3cec:	f9400a60 	ldr	x0, [x19, #16]
    3cf0:	7100fc5f 	cmp	w2, #0x3f
    3cf4:	5400078c 	b.gt	3de4 <fwp_free_zombie+0x124>
    3cf8:	91020023 	add	x3, x1, #0x80
    3cfc:	11000444 	add	w4, w2, #0x1
    3d00:	b9007024 	str	w4, [x1, #112]
    3d04:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3d08:	f822d860 	str	x0, [x3, w2, sxtw #3]
    3d0c:	a9530261 	ldp	x1, x0, [x19, #304]
    3d10:	b4000741 	cbz	x1, 3df8 <fwp_free_zombie+0x138>
    3d14:	f9009c20 	str	x0, [x1, #312]
    3d18:	b4000040 	cbz	x0, 3d20 <fwp_free_zombie+0x60>
    3d1c:	f9009801 	str	x1, [x0, #304]
    3d20:	91024294 	add	x20, x20, #0x90
    3d24:	b9405e60 	ldr	w0, [x19, #92]
    3d28:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    3d2c:	f900369f 	str	xzr, [x20, #104]
    3d30:	34000140 	cbz	w0, 3d58 <fwp_free_zombie+0x98>
    3d34:	7100041f 	cmp	w0, #0x1
    3d38:	54000080 	b.eq	3d48 <fwp_free_zombie+0x88>  // b.none
    3d3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3d44:	d65f03c0 	ret
    3d48:	aa1303e0 	mov	x0, x19
    3d4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3d54:	17ffff9b 	b	3bc0 <fwp_task_dispose>
    3d58:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xc70>
    3d5c:	9115c082 	add	x2, x4, #0x570
    3d60:	f949d841 	ldr	x1, [x2, #5040]
    3d64:	f949ec40 	ldr	x0, [x2, #5080]
    3d68:	cb010261 	sub	x1, x19, x1
    3d6c:	eb00403f 	cmp	x1, x0, lsl #16
    3d70:	54fffe62 	b.cs	3d3c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3d74:	d350fc20 	lsr	x0, x1, #16
    3d78:	f949fc43 	ldr	x3, [x2, #5112]
    3d7c:	8b000800 	add	x0, x0, x0, lsl #2
    3d80:	d37df000 	lsl	x0, x0, #3
    3d84:	8b000062 	add	x2, x3, x0
    3d88:	f9401054 	ldr	x20, [x2, #32]
    3d8c:	b4fffd94 	cbz	x20, 3d3c <fwp_free_zombie+0x7c>
    3d90:	38606860 	ldrb	w0, [x3, x0]
    3d94:	7100081f 	cmp	w0, #0x2
    3d98:	54000360 	b.eq	3e04 <fwp_free_zombie+0x144>  // b.none
    3d9c:	7100041f 	cmp	w0, #0x1
    3da0:	54fffce1 	b.ne	3d3c <fwp_free_zombie+0x7c>  // b.any
    3da4:	29430043 	ldp	w3, w0, [x2, #24]
    3da8:	92403c21 	and	x1, x1, #0xffff
    3dac:	9b037c21 	mul	x1, x1, x3
    3db0:	d360fc21 	lsr	x1, x1, #32
    3db4:	eb00003f 	cmp	x1, x0
    3db8:	54fffc22 	b.cs	3d3c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3dbc:	8b010294 	add	x20, x20, x1
    3dc0:	39400280 	ldrb	w0, [x20]
    3dc4:	34fffbc0 	cbz	w0, 3d3c <fwp_free_zombie+0x7c>
    3dc8:	7100041f 	cmp	w0, #0x1
    3dcc:	54fffbe0 	b.eq	3d48 <fwp_free_zombie+0x88>  // b.none
    3dd0:	7103fc1f 	cmp	w0, #0xff
    3dd4:	540001e0 	b.eq	3e10 <fwp_free_zombie+0x150>  // b.none
    3dd8:	51000400 	sub	w0, w0, #0x1
    3ddc:	39000280 	strb	w0, [x20]
    3de0:	17ffffd7 	b	3d3c <fwp_free_zombie+0x7c>
    3de4:	f9400e61 	ldr	x1, [x19, #24]
    3de8:	97fff60e 	bl	1620 <munmap@plt>
    3dec:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3df0:	a9530261 	ldp	x1, x0, [x19, #304]
    3df4:	b5fff901 	cbnz	x1, 3d14 <fwp_free_zombie+0x54>
    3df8:	91024282 	add	x2, x20, #0x90
    3dfc:	f9014040 	str	x0, [x2, #640]
    3e00:	17ffffc6 	b	3d18 <fwp_free_zombie+0x58>
    3e04:	72003c3f 	tst	w1, #0xffff
    3e08:	54fff9a1 	b.ne	3d3c <fwp_free_zombie+0x7c>  // b.any
    3e0c:	17ffffed 	b	3dc0 <fwp_free_zombie+0x100>
    3e10:	ca544680 	eor	x0, x20, x20, lsr #17
    3e14:	9115c084 	add	x4, x4, #0x570
    3e18:	ca402400 	eor	x0, x0, x0, lsr #9
    3e1c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3e20:	f94a2400 	ldr	x0, [x0, #5192]
    3e24:	b5000080 	cbnz	x0, 3e34 <fwp_free_zombie+0x174>
    3e28:	14000010 	b	3e68 <fwp_free_zombie+0x1a8>
    3e2c:	f9400800 	ldr	x0, [x0, #16]
    3e30:	b40001c0 	cbz	x0, 3e68 <fwp_free_zombie+0x1a8>
    3e34:	f9400001 	ldr	x1, [x0]
    3e38:	eb14003f 	cmp	x1, x20
    3e3c:	54ffff81 	b.ne	3e2c <fwp_free_zombie+0x16c>  // b.any
    3e40:	f9400401 	ldr	x1, [x0, #8]
    3e44:	d1000421 	sub	x1, x1, #0x1
    3e48:	f9000401 	str	x1, [x0, #8]
    3e4c:	f103f83f 	cmp	x1, #0xfe
    3e50:	54fff761 	b.ne	3d3c <fwp_free_zombie+0x7c>  // b.any
    3e54:	aa1403e0 	mov	x0, x20
    3e58:	97fffbcb 	bl	2d84 <fwp_rc_forget_slot>
    3e5c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3e60:	39000280 	strb	w0, [x20]
    3e64:	17ffffb6 	b	3d3c <fwp_free_zombie+0x7c>
    3e68:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    3e6c:	91036000 	add	x0, x0, #0xd8
    3e70:	97fff904 	bl	2280 <fwp_trap>

0000000000003e74 <fwp_block>:
    3e74:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e78:	910003fd 	mov	x29, sp
    3e7c:	a90153f3 	stp	x19, x20, [sp, #16]
    3e80:	b00000f3 	adrp	x19, 20000 <__data_start>
    3e84:	91024274 	add	x20, x19, #0x90
    3e88:	f9401a82 	ldr	x2, [x20, #48]
    3e8c:	b4000622 	cbz	x2, 3f50 <fwp_block+0xdc>
    3e90:	91024261 	add	x1, x19, #0x90
    3e94:	f9408040 	ldr	x0, [x2, #256]
    3e98:	f9001820 	str	x0, [x1, #48]
    3e9c:	b4000680 	cbz	x0, 3f6c <fwp_block+0xf8>
    3ea0:	91024263 	add	x3, x19, #0x90
    3ea4:	3901505f 	strb	wzr, [x2, #84]
    3ea8:	f9400464 	ldr	x4, [x3, #8]
    3eac:	eb02009f 	cmp	x4, x2
    3eb0:	54000440 	b.eq	3f38 <fwp_block+0xc4>  // b.none
    3eb4:	f9414465 	ldr	x5, [x3, #648]
    3eb8:	f9000462 	str	x2, [x3, #8]
    3ebc:	f9400441 	ldr	x1, [x2, #8]
    3ec0:	f9004885 	str	x5, [x4, #144]
    3ec4:	f9414865 	ldr	x5, [x3, #656]
    3ec8:	f9004c85 	str	x5, [x4, #152]
    3ecc:	f9414c65 	ldr	x5, [x3, #664]
    3ed0:	f9005085 	str	x5, [x4, #160]
    3ed4:	f9415065 	ldr	x5, [x3, #672]
    3ed8:	f9005485 	str	x5, [x4, #168]
    3edc:	f9415465 	ldr	x5, [x3, #680]
    3ee0:	f9005885 	str	x5, [x4, #176]
    3ee4:	f9415865 	ldr	x5, [x3, #688]
    3ee8:	f9005c85 	str	x5, [x4, #184]
    3eec:	f9415c65 	ldr	x5, [x3, #696]
    3ef0:	f9006085 	str	x5, [x4, #192]
    3ef4:	f9400480 	ldr	x0, [x4, #8]
    3ef8:	f9404844 	ldr	x4, [x2, #144]
    3efc:	f9014464 	str	x4, [x3, #648]
    3f00:	f9404c44 	ldr	x4, [x2, #152]
    3f04:	f9014864 	str	x4, [x3, #656]
    3f08:	f9405044 	ldr	x4, [x2, #160]
    3f0c:	f9014c64 	str	x4, [x3, #664]
    3f10:	f9405444 	ldr	x4, [x2, #168]
    3f14:	f9015064 	str	x4, [x3, #672]
    3f18:	f9405844 	ldr	x4, [x2, #176]
    3f1c:	f9015464 	str	x4, [x3, #680]
    3f20:	a94b8844 	ldp	x4, x2, [x2, #184]
    3f24:	f9015864 	str	x4, [x3, #688]
    3f28:	f9015c62 	str	x2, [x3, #696]
    3f2c:	97fff58d 	bl	1560 <swapcontext@plt>
    3f30:	97ffff64 	bl	3cc0 <fwp_free_zombie>
    3f34:	d503201f 	nop
    3f38:	91024260 	add	x0, x19, #0x90
    3f3c:	b942c000 	ldr	w0, [x0, #704]
    3f40:	340001a0 	cbz	w0, 3f74 <fwp_block+0x100>
    3f44:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f48:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f4c:	d65f03c0 	ret
    3f50:	97fffb00 	bl	2b50 <fwp_poll_events>
    3f54:	f9401a82 	ldr	x2, [x20, #48]
    3f58:	b4ffffc2 	cbz	x2, 3f50 <fwp_block+0xdc>
    3f5c:	91024261 	add	x1, x19, #0x90
    3f60:	f9408040 	ldr	x0, [x2, #256]
    3f64:	f9001820 	str	x0, [x1, #48]
    3f68:	b5fff9c0 	cbnz	x0, 3ea0 <fwp_block+0x2c>
    3f6c:	f900143f 	str	xzr, [x1, #40]
    3f70:	17ffffcc 	b	3ea0 <fwp_block+0x2c>
    3f74:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    3f78:	91044000 	add	x0, x0, #0x110
    3f7c:	97fff5c5 	bl	1690 <getenv@plt>
    3f80:	5284e202 	mov	w2, #0x2710                	// #10000
    3f84:	b4000060 	cbz	x0, 3f90 <fwp_block+0x11c>
    3f88:	39400001 	ldrb	w1, [x0]
    3f8c:	350000c1 	cbnz	w1, 3fa4 <fwp_block+0x130>
    3f90:	91024273 	add	x19, x19, #0x90
    3f94:	b902c262 	str	w2, [x19, #704]
    3f98:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3fa0:	d65f03c0 	ret
    3fa4:	52800142 	mov	w2, #0xa                   	// #10
    3fa8:	d2800001 	mov	x1, #0x0                   	// #0
    3fac:	97fff509 	bl	13d0 <strtoll@plt>
    3fb0:	d1000403 	sub	x3, x0, #0x1
    3fb4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3fb8:	eb02007f 	cmp	x3, x2
    3fbc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3fc0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3fc4:	17fffff3 	b	3f90 <fwp_block+0x11c>
    3fc8:	d503201f 	nop
    3fcc:	d503201f 	nop

0000000000003fd0 <fwp_write.constprop.0>:
    3fd0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3fd4:	910003fd 	mov	x29, sp
    3fd8:	900000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14da0>
    3fdc:	f947f463 	ldr	x3, [x3, #4072]
    3fe0:	a90153f3 	stp	x19, x20, [sp, #16]
    3fe4:	d10943ff 	sub	sp, sp, #0x250
    3fe8:	aa0003f4 	mov	x20, x0
    3fec:	b9400040 	ldr	w0, [x2]
    3ff0:	aa0103f3 	mov	x19, x1
    3ff4:	f9400061 	ldr	x1, [x3]
    3ff8:	f90127e1 	str	x1, [sp, #584]
    3ffc:	d2800001 	mov	x1, #0x0                   	// #0
    4000:	7100641f 	cmp	w0, #0x19
    4004:	540003e8 	b.hi	4080 <fwp_write.constprop.0+0xb0>  // b.pmore
    4008:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    400c:	91124021 	add	x1, x1, #0x490
    4010:	f9013bf5 	str	x21, [sp, #624]
    4014:	f9013ff6 	str	x22, [sp, #632]
    4018:	f90153fb 	str	x27, [sp, #672]
    401c:	f90157fc 	str	x28, [sp, #680]
    4020:	aa0203fc 	mov	x28, x2
    4024:	78605821 	ldrh	w1, [x1, w0, uxtw #1]
    4028:	10000062 	adr	x2, 4034 <fwp_write.constprop.0+0x64>
    402c:	8b21a841 	add	x1, x2, w1, sxth #2
    4030:	d61f0020 	br	x1
    4034:	910123e0 	add	x0, sp, #0x48
    4038:	aa1303e5 	mov	x5, x19
    403c:	b0000024 	adrp	x4, 9000 <_IO_stdin_used+0x1e0>
    4040:	aa0003f3 	mov	x19, x0
    4044:	91056084 	add	x4, x4, #0x158
    4048:	d2804003 	mov	x3, #0x200                 	// #512
    404c:	aa0303e1 	mov	x1, x3
    4050:	52800042 	mov	w2, #0x2                   	// #2
    4054:	97fff507 	bl	1470 <__snprintf_chk@plt>
    4058:	aa1303e0 	mov	x0, x19
    405c:	97fff4cd 	bl	1390 <strlen@plt>
    4060:	aa1303e1 	mov	x1, x19
    4064:	aa0003e2 	mov	x2, x0
    4068:	aa1403e0 	mov	x0, x20
    406c:	97fff829 	bl	2110 <buf_put>
    4070:	f9413bf5 	ldr	x21, [sp, #624]
    4074:	f9413ff6 	ldr	x22, [sp, #632]
    4078:	f94153fb 	ldr	x27, [sp, #672]
    407c:	f94157fc 	ldr	x28, [sp, #680]
    4080:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    4084:	f947f400 	ldr	x0, [x0, #4072]
    4088:	f94127e2 	ldr	x2, [sp, #584]
    408c:	f9400001 	ldr	x1, [x0]
    4090:	eb010042 	subs	x2, x2, x1
    4094:	d2800001 	mov	x1, #0x0                   	// #0
    4098:	540074a1 	b.ne	4f2c <fwp_write.constprop.0+0xf5c>  // b.any
    409c:	910943ff 	add	sp, sp, #0x250
    40a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40a4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    40a8:	d65f03c0 	ret
    40ac:	910123e0 	add	x0, sp, #0x48
    40b0:	aa1303e5 	mov	x5, x19
    40b4:	b0000024 	adrp	x4, 9000 <_IO_stdin_used+0x1e0>
    40b8:	aa0003f3 	mov	x19, x0
    40bc:	91054084 	add	x4, x4, #0x150
    40c0:	d2804003 	mov	x3, #0x200                 	// #512
    40c4:	17ffffe2 	b	404c <fwp_write.constprop.0+0x7c>
    40c8:	71004c1f 	cmp	w0, #0x13
    40cc:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    40d0:	b0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    40d4:	91052021 	add	x1, x1, #0x148
    40d8:	91050000 	add	x0, x0, #0x140
    40dc:	d2800082 	mov	x2, #0x4                   	// #4
    40e0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    40e4:	aa1403e0 	mov	x0, x20
    40e8:	f90143f7 	str	x23, [sp, #640]
    40ec:	d2800016 	mov	x22, #0x0                   	// #0
    40f0:	f90147f8 	str	x24, [sp, #648]
    40f4:	97fff807 	bl	2110 <buf_put>
    40f8:	f9400260 	ldr	x0, [x19]
    40fc:	b0000037 	adrp	x23, 9000 <_IO_stdin_used+0x1e0>
    4100:	d2800015 	mov	x21, #0x0                   	// #0
    4104:	910722f7 	add	x23, x23, #0x1c8
    4108:	b4004e40 	cbz	x0, 4ad0 <fwp_write.constprop.0+0xb00>
    410c:	b9400381 	ldr	w1, [x28]
    4110:	aa1403e0 	mov	x0, x20
    4114:	f9401f82 	ldr	x2, [x28, #56]
    4118:	71004c3f 	cmp	w1, #0x13
    411c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    4120:	8b010e61 	add	x1, x19, x1, lsl #3
    4124:	f9400421 	ldr	x1, [x1, #8]
    4128:	97ffffaa 	bl	3fd0 <fwp_write.constprop.0>
    412c:	b9400380 	ldr	w0, [x28]
    4130:	7100481f 	cmp	w0, #0x12
    4134:	540050c0 	b.eq	4b4c <fwp_write.constprop.0+0xb7c>  // b.none
    4138:	f9400260 	ldr	x0, [x19]
    413c:	910006b5 	add	x21, x21, #0x1
    4140:	91000ad6 	add	x22, x22, #0x2
    4144:	eb0002bf 	cmp	x21, x0
    4148:	54004c42 	b.cs	4ad0 <fwp_write.constprop.0+0xb00>  // b.hs, b.nlast
    414c:	aa1703e1 	mov	x1, x23
    4150:	aa1403e0 	mov	x0, x20
    4154:	d2800042 	mov	x2, #0x2                   	// #2
    4158:	97fff7ee 	bl	2110 <buf_put>
    415c:	17ffffec 	b	410c <fwp_write.constprop.0+0x13c>
    4160:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    4164:	91060021 	add	x1, x1, #0x180
    4168:	d28000c2 	mov	x2, #0x6                   	// #6
    416c:	aa1403e0 	mov	x0, x20
    4170:	91004273 	add	x19, x19, #0x10
    4174:	97fff7e7 	bl	2110 <buf_put>
    4178:	aa1303e0 	mov	x0, x19
    417c:	97fff485 	bl	1390 <strlen@plt>
    4180:	aa1303e1 	mov	x1, x19
    4184:	aa0003e2 	mov	x2, x0
    4188:	aa1403e0 	mov	x0, x20
    418c:	97fff7e1 	bl	2110 <buf_put>
    4190:	528007c3 	mov	w3, #0x3e                  	// #62
    4194:	aa1403e0 	mov	x0, x20
    4198:	91001fe1 	add	x1, sp, #0x7
    419c:	d2800022 	mov	x2, #0x1                   	// #1
    41a0:	39001fe3 	strb	w3, [sp, #7]
    41a4:	17ffffb2 	b	406c <fwp_write.constprop.0+0x9c>
    41a8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    41ac:	f947f400 	ldr	x0, [x0, #4072]
    41b0:	f94127e2 	ldr	x2, [sp, #584]
    41b4:	f9400001 	ldr	x1, [x0]
    41b8:	eb010042 	subs	x2, x2, x1
    41bc:	d2800001 	mov	x1, #0x0                   	// #0
    41c0:	54006cc1 	b.ne	4f58 <fwp_write.constprop.0+0xf88>  // b.any
    41c4:	f9413bf5 	ldr	x21, [sp, #624]
    41c8:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    41cc:	f9413ff6 	ldr	x22, [sp, #632]
    41d0:	aa1403e0 	mov	x0, x20
    41d4:	91058021 	add	x1, x1, #0x160
    41d8:	d2800142 	mov	x2, #0xa                   	// #10
    41dc:	f94153fb 	ldr	x27, [sp, #672]
    41e0:	f94157fc 	ldr	x28, [sp, #680]
    41e4:	910943ff 	add	sp, sp, #0x250
    41e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    41ec:	a8c77bfd 	ldp	x29, x30, [sp], #112
    41f0:	17fff7c8 	b	2110 <buf_put>
    41f4:	f9400796 	ldr	x22, [x28, #8]
    41f8:	f90143f7 	str	x23, [sp, #640]
    41fc:	f90147f8 	str	x24, [sp, #648]
    4200:	b4005816 	cbz	x22, 4d00 <fwp_write.constprop.0+0xd30>
    4204:	aa1603e0 	mov	x0, x22
    4208:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    420c:	91078021 	add	x1, x1, #0x1e0
    4210:	97fff4dc 	bl	1580 <strcmp@plt>
    4214:	2a0003f5 	mov	w21, w0
    4218:	34005ce0 	cbz	w0, 4db4 <fwp_write.constprop.0+0xde4>
    421c:	aa1603e0 	mov	x0, x22
    4220:	97fff45c 	bl	1390 <strlen@plt>
    4224:	aa1603e1 	mov	x1, x22
    4228:	aa0003e2 	mov	x2, x0
    422c:	aa1403e0 	mov	x0, x20
    4230:	97fff7b8 	bl	2110 <buf_put>
    4234:	52800403 	mov	w3, #0x20                  	// #32
    4238:	91001ff5 	add	x21, sp, #0x7
    423c:	aa1503e1 	mov	x1, x21
    4240:	aa1403e0 	mov	x0, x20
    4244:	d2800022 	mov	x2, #0x1                   	// #1
    4248:	39001fe3 	strb	w3, [sp, #7]
    424c:	97fff7b1 	bl	2110 <buf_put>
    4250:	52800f63 	mov	w3, #0x7b                  	// #123
    4254:	aa1403e0 	mov	x0, x20
    4258:	aa1503e1 	mov	x1, x21
    425c:	d2800022 	mov	x2, #0x1                   	// #1
    4260:	39001fe3 	strb	w3, [sp, #7]
    4264:	97fff7ab 	bl	2110 <buf_put>
    4268:	b9401380 	ldr	w0, [x28, #16]
    426c:	52800018 	mov	w24, #0x0                   	// #0
    4270:	7100001f 	cmp	w0, #0x0
    4274:	54003d8d 	b.le	4a24 <fwp_write.constprop.0+0xa54>
    4278:	f9014bf9 	str	x25, [sp, #656]
    427c:	b0000039 	adrp	x25, 9000 <_IO_stdin_used+0x1e0>
    4280:	91082339 	add	x25, x25, #0x208
    4284:	f9014ffa 	str	x26, [sp, #664]
    4288:	b000003a 	adrp	x26, 9000 <_IO_stdin_used+0x1e0>
    428c:	9107235a 	add	x26, x26, #0x1c8
    4290:	91002276 	add	x22, x19, #0x8
    4294:	d2800013 	mov	x19, #0x0                   	// #0
    4298:	b5004413 	cbnz	x19, 4b18 <fwp_write.constprop.0+0xb48>
    429c:	d37df277 	lsl	x23, x19, #3
    42a0:	34004238 	cbz	w24, 4ae4 <fwp_write.constprop.0+0xb14>
    42a4:	f9401382 	ldr	x2, [x28, #32]
    42a8:	aa1403e0 	mov	x0, x20
    42ac:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    42b0:	91000673 	add	x19, x19, #0x1
    42b4:	f8776842 	ldr	x2, [x2, x23]
    42b8:	97ffff46 	bl	3fd0 <fwp_write.constprop.0>
    42bc:	b9401380 	ldr	w0, [x28, #16]
    42c0:	6b13001f 	cmp	w0, w19
    42c4:	54fffeac 	b.gt	4298 <fwp_write.constprop.0+0x2c8>
    42c8:	f9414bf9 	ldr	x25, [sp, #656]
    42cc:	f9414ffa 	ldr	x26, [sp, #664]
    42d0:	34003ab8 	cbz	w24, 4a24 <fwp_write.constprop.0+0xa54>
    42d4:	52800523 	mov	w3, #0x29                  	// #41
    42d8:	aa1503e1 	mov	x1, x21
    42dc:	aa1403e0 	mov	x0, x20
    42e0:	d2800022 	mov	x2, #0x1                   	// #1
    42e4:	39001fe3 	strb	w3, [sp, #7]
    42e8:	97fff78a 	bl	2110 <buf_put>
    42ec:	f9413bf5 	ldr	x21, [sp, #624]
    42f0:	f9413ff6 	ldr	x22, [sp, #632]
    42f4:	f94143f7 	ldr	x23, [sp, #640]
    42f8:	f94147f8 	ldr	x24, [sp, #648]
    42fc:	f94153fb 	ldr	x27, [sp, #672]
    4300:	f94157fc 	ldr	x28, [sp, #680]
    4304:	17ffff5f 	b	4080 <fwp_write.constprop.0+0xb0>
    4308:	b9404b95 	ldr	w21, [x28, #72]
    430c:	aa1403e0 	mov	x0, x20
    4310:	93407eb6 	sxtw	x22, w21
    4314:	91000ac1 	add	x1, x22, #0x2
    4318:	97fff74a 	bl	2040 <buf_grow>
    431c:	a9400281 	ldp	x1, x0, [x20]
    4320:	528e8603 	mov	w3, #0x7430                	// #29744
    4324:	78206823 	strh	w3, [x1, x0]
    4328:	8b000022 	add	x2, x1, x0
    432c:	710002bf 	cmp	w21, #0x0
    4330:	54003bcd 	b.le	4aa8 <fwp_write.constprop.0+0xad8>
    4334:	110006a3 	add	w3, w21, #0x1
    4338:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    433c:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    4340:	91000449 	add	x9, x2, #0x1
    4344:	8b23c043 	add	x3, x2, w3, sxtw
    4348:	f28aaac6 	movk	x6, #0x5556
    434c:	f2955568 	movk	x8, #0xaaab
    4350:	1400000d 	b	4384 <fwp_write.constprop.0+0x3b4>
    4354:	d2800021 	mov	x1, #0x1                   	// #1
    4358:	528005a5 	mov	w5, #0x2d                  	// #45
    435c:	f100001f 	cmp	x0, #0x0
    4360:	9b467e60 	smulh	x0, x19, x6
    4364:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    4368:	381ff465 	strb	w5, [x3], #-1
    436c:	cb040000 	sub	x0, x0, x4
    4370:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    4374:	cb020000 	sub	x0, x0, x2
    4378:	8b010013 	add	x19, x0, x1
    437c:	eb03013f 	cmp	x9, x3
    4380:	54003940 	b.eq	4aa8 <fwp_write.constprop.0+0xad8>  // b.none
    4384:	9b467e60 	smulh	x0, x19, x6
    4388:	937ffe64 	asr	x4, x19, #63
    438c:	52800605 	mov	w5, #0x30                  	// #48
    4390:	cb040000 	sub	x0, x0, x4
    4394:	8b000400 	add	x0, x0, x0, lsl #1
    4398:	cb000260 	sub	x0, x19, x0
    439c:	91000c01 	add	x1, x0, #0x3
    43a0:	9bc87c22 	umulh	x2, x1, x8
    43a4:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    43a8:	8b4204e2 	add	x2, x7, x2, lsr #1
    43ac:	eb020021 	subs	x1, x1, x2
    43b0:	54fffd60 	b.eq	435c <fwp_write.constprop.0+0x38c>  // b.none
    43b4:	f100043f 	cmp	x1, #0x1
    43b8:	54fffce1 	b.ne	4354 <fwp_write.constprop.0+0x384>  // b.any
    43bc:	d2800001 	mov	x1, #0x0                   	// #0
    43c0:	52800565 	mov	w5, #0x2b                  	// #43
    43c4:	17ffffe6 	b	435c <fwp_write.constprop.0+0x38c>
    43c8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    43cc:	f947f400 	ldr	x0, [x0, #4072]
    43d0:	f94127e2 	ldr	x2, [sp, #584]
    43d4:	f9400001 	ldr	x1, [x0]
    43d8:	eb010042 	subs	x2, x2, x1
    43dc:	d2800001 	mov	x1, #0x0                   	// #0
    43e0:	54005bc1 	b.ne	4f58 <fwp_write.constprop.0+0xf88>  // b.any
    43e4:	f9413bf5 	ldr	x21, [sp, #624]
    43e8:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    43ec:	f9413ff6 	ldr	x22, [sp, #632]
    43f0:	aa1403e0 	mov	x0, x20
    43f4:	9105c021 	add	x1, x1, #0x170
    43f8:	d2800102 	mov	x2, #0x8                   	// #8
    43fc:	17ffff78 	b	41dc <fwp_write.constprop.0+0x20c>
    4400:	aa1403e0 	mov	x0, x20
    4404:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    4408:	d28000c2 	mov	x2, #0x6                   	// #6
    440c:	91074021 	add	x1, x1, #0x1d0
    4410:	97fff740 	bl	2110 <buf_put>
    4414:	d2800015 	mov	x21, #0x0                   	// #0
    4418:	f9400263 	ldr	x3, [x19]
    441c:	f240f87f 	tst	x3, #0x7fffffffffffffff
    4420:	540026a0 	b.eq	48f4 <fwp_write.constprop.0+0x924>  // b.none
    4424:	f9401f82 	ldr	x2, [x28, #56]
    4428:	f90143f7 	str	x23, [sp, #640]
    442c:	f90147f8 	str	x24, [sp, #648]
    4430:	d2800857 	mov	x23, #0x42                  	// #66
    4434:	f9014bf9 	str	x25, [sp, #656]
    4438:	b0000036 	adrp	x22, 9000 <_IO_stdin_used+0x1e0>
    443c:	f9014ffa 	str	x26, [sp, #664]
    4440:	910722d6 	add	x22, x22, #0x1c8
    4444:	d2800038 	mov	x24, #0x1                   	// #1
    4448:	f2a18017 	movk	x23, #0xc00, lsl #16
    444c:	d2809099 	mov	x25, #0x484                 	// #1156
    4450:	b4000482 	cbz	x2, 44e0 <fwp_write.constprop.0+0x510>
    4454:	b9400040 	ldr	w0, [x2]
    4458:	7100701f 	cmp	w0, #0x1c
    445c:	540042e0 	b.eq	4cb8 <fwp_write.constprop.0+0xce8>  // b.none
    4460:	71006c1f 	cmp	w0, #0x1b
    4464:	540003e8 	b.hi	44e0 <fwp_write.constprop.0+0x510>  // b.pmore
    4468:	9ac02301 	lsl	x1, x24, x0
    446c:	ea17003f 	tst	x1, x23
    4470:	54003f21 	b.ne	4c54 <fwp_write.constprop.0+0xc84>  // b.any
    4474:	ea19003f 	tst	x1, x25
    4478:	54003da1 	b.ne	4c2c <fwp_write.constprop.0+0xc5c>  // b.any
    447c:	d2800425 	mov	x5, #0x21                  	// #33
    4480:	ea05003f 	tst	x1, x5
    4484:	540002e0 	b.eq	44e0 <fwp_write.constprop.0+0x510>  // b.none
    4488:	b7f84743 	tbnz	x3, #63, 4d70 <fwp_write.constprop.0+0xda0>
    448c:	91002261 	add	x1, x19, #0x8
    4490:	8b150021 	add	x1, x1, x21
    4494:	39400021 	ldrb	w1, [x1]
    4498:	7100001f 	cmp	w0, #0x0
    449c:	93401c23 	sxtb	x3, w1
    44a0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    44a4:	d503201f 	nop
    44a8:	aa1403e0 	mov	x0, x20
    44ac:	97fffec9 	bl	3fd0 <fwp_write.constprop.0>
    44b0:	f9400260 	ldr	x0, [x19]
    44b4:	910006b5 	add	x21, x21, #0x1
    44b8:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    44bc:	eb0002bf 	cmp	x21, x0
    44c0:	54002122 	b.cs	48e4 <fwp_write.constprop.0+0x914>  // b.hs, b.nlast
    44c4:	d2800042 	mov	x2, #0x2                   	// #2
    44c8:	aa1603e1 	mov	x1, x22
    44cc:	aa1403e0 	mov	x0, x20
    44d0:	97fff710 	bl	2110 <buf_put>
    44d4:	f9401f82 	ldr	x2, [x28, #56]
    44d8:	f9400263 	ldr	x3, [x19]
    44dc:	b5fffbc2 	cbnz	x2, 4454 <fwp_write.constprop.0+0x484>
    44e0:	d37df2a0 	lsl	x0, x21, #3
    44e4:	b7f83f43 	tbnz	x3, #63, 4ccc <fwp_write.constprop.0+0xcfc>
    44e8:	91002261 	add	x1, x19, #0x8
    44ec:	8b000020 	add	x0, x1, x0
    44f0:	f9400001 	ldr	x1, [x0]
    44f4:	17ffffed 	b	44a8 <fwp_write.constprop.0+0x4d8>
    44f8:	a9400e62 	ldp	x2, x3, [x19]
    44fc:	b7f83ce3 	tbnz	x3, #63, 4c98 <fwp_write.constprop.0+0xcc8>
    4500:	910123f5 	add	x21, sp, #0x48
    4504:	aa1503e0 	mov	x0, x21
    4508:	97fff556 	bl	1a60 <fwp_fmt_u128>
    450c:	aa1503e0 	mov	x0, x21
    4510:	97fff3a0 	bl	1390 <strlen@plt>
    4514:	aa1503e1 	mov	x1, x21
    4518:	aa0003e2 	mov	x2, x0
    451c:	17fffed3 	b	4068 <fwp_write.constprop.0+0x98>
    4520:	fd015be8 	str	d8, [sp, #688]
    4524:	1e270268 	fmov	s8, w19
    4528:	fd015fe9 	str	d9, [sp, #696]
    452c:	1e282100 	fcmp	s8, s8
    4530:	54004a66 	b.vs	4e7c <fwp_write.constprop.0+0xeac>
    4534:	1e20c101 	fabs	s1, s8
    4538:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    453c:	1e270000 	fmov	s0, w0
    4540:	1e202020 	fcmp	s1, s0
    4544:	540034ad 	b.le	4bd8 <fwp_write.constprop.0+0xc08>
    4548:	1e202118 	fcmpe	s8, #0.0
    454c:	90000022 	adrp	x2, 8000 <f0+0x2320>
    4550:	913cc042 	add	x2, x2, #0xf30
    4554:	910123f5 	add	x21, sp, #0x48
    4558:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    455c:	91048021 	add	x1, x1, #0x120
    4560:	aa1503e0 	mov	x0, x21
    4564:	9a81c041 	csel	x1, x2, x1, gt
    4568:	97fff436 	bl	1640 <strcpy@plt>
    456c:	d503201f 	nop
    4570:	aa1503e0 	mov	x0, x21
    4574:	97fff387 	bl	1390 <strlen@plt>
    4578:	aa1503e1 	mov	x1, x21
    457c:	aa0003e2 	mov	x2, x0
    4580:	aa1403e0 	mov	x0, x20
    4584:	97fff6e3 	bl	2110 <buf_put>
    4588:	f9413bf5 	ldr	x21, [sp, #624]
    458c:	f9413ff6 	ldr	x22, [sp, #632]
    4590:	f94153fb 	ldr	x27, [sp, #672]
    4594:	f94157fc 	ldr	x28, [sp, #680]
    4598:	fd415be8 	ldr	d8, [sp, #688]
    459c:	fd415fe9 	ldr	d9, [sp, #696]
    45a0:	17fffeb8 	b	4080 <fwp_write.constprop.0+0xb0>
    45a4:	f90143f7 	str	x23, [sp, #640]
    45a8:	52800443 	mov	w3, #0x22                  	// #34
    45ac:	f90147f8 	str	x24, [sp, #648]
    45b0:	91001ff5 	add	x21, sp, #0x7
    45b4:	aa1503e1 	mov	x1, x21
    45b8:	aa1403e0 	mov	x0, x20
    45bc:	f8408677 	ldr	x23, [x19], #8
    45c0:	d2800022 	mov	x2, #0x1                   	// #1
    45c4:	39001fe3 	strb	w3, [sp, #7]
    45c8:	97fff6d2 	bl	2110 <buf_put>
    45cc:	8b1302f6 	add	x22, x23, x19
    45d0:	b4002657 	cbz	x23, 4a98 <fwp_write.constprop.0+0xac8>
    45d4:	b0000038 	adrp	x24, 9000 <_IO_stdin_used+0x1e0>
    45d8:	91062318 	add	x24, x24, #0x188
    45dc:	f9014bf9 	str	x25, [sp, #656]
    45e0:	b0000039 	adrp	x25, 9000 <_IO_stdin_used+0x1e0>
    45e4:	9106a339 	add	x25, x25, #0x1a8
    45e8:	f9014ffa 	str	x26, [sp, #664]
    45ec:	1400000e 	b	4624 <fwp_write.constprop.0+0x654>
    45f0:	710024bf 	cmp	w5, #0x9
    45f4:	54002380 	b.eq	4a64 <fwp_write.constprop.0+0xa94>  // b.none
    45f8:	710028bf 	cmp	w5, #0xa
    45fc:	54002be1 	b.ne	4b78 <fwp_write.constprop.0+0xba8>  // b.any
    4600:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    4604:	aa1403e0 	mov	x0, x20
    4608:	91066021 	add	x1, x1, #0x198
    460c:	d2800042 	mov	x2, #0x2                   	// #2
    4610:	97fff6c0 	bl	2110 <buf_put>
    4614:	d503201f 	nop
    4618:	91000673 	add	x19, x19, #0x1
    461c:	eb16027f 	cmp	x19, x22
    4620:	54002380 	b.eq	4a90 <fwp_write.constprop.0+0xac0>  // b.none
    4624:	39400265 	ldrb	w5, [x19]
    4628:	710034bf 	cmp	w5, #0xd
    462c:	54002120 	b.eq	4a50 <fwp_write.constprop.0+0xa80>  // b.none
    4630:	54fffe09 	b.ls	45f0 <fwp_write.constprop.0+0x620>  // b.plast
    4634:	710088bf 	cmp	w5, #0x22
    4638:	54002220 	b.eq	4a7c <fwp_write.constprop.0+0xaac>  // b.none
    463c:	710170bf 	cmp	w5, #0x5c
    4640:	54002ba1 	b.ne	4bb4 <fwp_write.constprop.0+0xbe4>  // b.any
    4644:	aa1403e0 	mov	x0, x20
    4648:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    464c:	d2800042 	mov	x2, #0x2                   	// #2
    4650:	91064021 	add	x1, x1, #0x190
    4654:	97fff6af 	bl	2110 <buf_put>
    4658:	17fffff0 	b	4618 <fwp_write.constprop.0+0x648>
    465c:	fd015be8 	str	d8, [sp, #688]
    4660:	9e670268 	fmov	d8, x19
    4664:	fd015fe9 	str	d9, [sp, #696]
    4668:	1e682100 	fcmp	d8, d8
    466c:	54004086 	b.vs	4e7c <fwp_write.constprop.0+0xeac>
    4670:	1e60c101 	fabs	d1, d8
    4674:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    4678:	9e670000 	fmov	d0, x0
    467c:	910123f5 	add	x21, sp, #0x48
    4680:	52800033 	mov	w19, #0x1                   	// #1
    4684:	1e602020 	fcmp	d1, d0
    4688:	540001ad 	b.le	46bc <fwp_write.constprop.0+0x6ec>
    468c:	1e602118 	fcmpe	d8, #0.0
    4690:	90000022 	adrp	x2, 8000 <f0+0x2320>
    4694:	913cc042 	add	x2, x2, #0xf30
    4698:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    469c:	91048021 	add	x1, x1, #0x120
    46a0:	aa1503e0 	mov	x0, x21
    46a4:	9a81c041 	csel	x1, x2, x1, gt
    46a8:	97fff3e6 	bl	1640 <strcpy@plt>
    46ac:	17ffffb1 	b	4570 <fwp_write.constprop.0+0x5a0>
    46b0:	11000673 	add	w19, w19, #0x1
    46b4:	71004a7f 	cmp	w19, #0x12
    46b8:	540031a0 	b.eq	4cec <fwp_write.constprop.0+0xd1c>  // b.none
    46bc:	1e604100 	fmov	d0, d8
    46c0:	2a1303e1 	mov	w1, w19
    46c4:	aa1503e0 	mov	x0, x21
    46c8:	97fff726 	bl	2360 <fwp_format_g.constprop.0>
    46cc:	aa1503e0 	mov	x0, x21
    46d0:	d2800001 	mov	x1, #0x0                   	// #0
    46d4:	97fff343 	bl	13e0 <strtod@plt>
    46d8:	1e602100 	fcmp	d8, d0
    46dc:	54fffea1 	b.ne	46b0 <fwp_write.constprop.0+0x6e0>  // b.any
    46e0:	aa1503e0 	mov	x0, x21
    46e4:	97fff6c4 	bl	21f4 <fwp_finish_float>
    46e8:	17ffffa2 	b	4570 <fwp_write.constprop.0+0x5a0>
    46ec:	a9400e62 	ldp	x2, x3, [x19]
    46f0:	910123f3 	add	x19, sp, #0x48
    46f4:	aa1303e0 	mov	x0, x19
    46f8:	97fff4da 	bl	1a60 <fwp_fmt_u128>
    46fc:	17fffe57 	b	4058 <fwp_write.constprop.0+0x88>
    4700:	f90143f7 	str	x23, [sp, #640]
    4704:	f90147f8 	str	x24, [sp, #648]
    4708:	2a1303f8 	mov	w24, w19
    470c:	f9014bf9 	str	x25, [sp, #656]
    4710:	f9014ffa 	str	x26, [sp, #664]
    4714:	f13ffe7f 	cmp	x19, #0xfff
    4718:	54000049 	b.ls	4720 <fwp_write.constprop.0+0x750>  // b.plast
    471c:	b9400278 	ldr	w24, [x19]
    4720:	f9400f80 	ldr	x0, [x28, #24]
    4724:	2a1803f5 	mov	w21, w24
    4728:	d37d7f18 	ubfiz	x24, x24, #3, #32
    472c:	d37ef6b9 	lsl	x25, x21, #2
    4730:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    4734:	aa1603e0 	mov	x0, x22
    4738:	97fff316 	bl	1390 <strlen@plt>
    473c:	aa1603e1 	mov	x1, x22
    4740:	aa0003e2 	mov	x2, x0
    4744:	aa1403e0 	mov	x0, x20
    4748:	97fff672 	bl	2110 <buf_put>
    474c:	f9401780 	ldr	x0, [x28, #40]
    4750:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    4754:	7100001f 	cmp	w0, #0x0
    4758:	5400064d 	b.le	4820 <fwp_write.constprop.0+0x850>
    475c:	91002276 	add	x22, x19, #0x8
    4760:	91001ff5 	add	x21, sp, #0x7
    4764:	d280001b 	mov	x27, #0x0                   	// #0
    4768:	5280041a 	mov	w26, #0x20                  	// #32
    476c:	f9401b80 	ldr	x0, [x28, #48]
    4770:	aa1503e1 	mov	x1, x21
    4774:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    4778:	d2800022 	mov	x2, #0x1                   	// #1
    477c:	f8786805 	ldr	x5, [x0, x24]
    4780:	aa1403e0 	mov	x0, x20
    4784:	f87b78b3 	ldr	x19, [x5, x27, lsl #3]
    4788:	39001ffa 	strb	w26, [sp, #7]
    478c:	97fff661 	bl	2110 <buf_put>
    4790:	f13ffeff 	cmp	x23, #0xfff
    4794:	b9400261 	ldr	w1, [x19]
    4798:	1a9f97e0 	cset	w0, hi	// hi = pmore
    479c:	7100383f 	cmp	w1, #0xe
    47a0:	54000140 	b.eq	47c8 <fwp_write.constprop.0+0x7f8>  // b.none
    47a4:	7100403f 	cmp	w1, #0x10
    47a8:	54001c20 	b.eq	4b2c <fwp_write.constprop.0+0xb5c>  // b.none
    47ac:	7100283f 	cmp	w1, #0xa
    47b0:	540026e0 	b.eq	4c8c <fwp_write.constprop.0+0xcbc>  // b.none
    47b4:	540013cc 	b.gt	4a2c <fwp_write.constprop.0+0xa5c>
    47b8:	71000c3f 	cmp	w1, #0x3
    47bc:	540025ec 	b.gt	4c78 <fwp_write.constprop.0+0xca8>
    47c0:	d37ffee0 	lsr	x0, x23, #63
    47c4:	37f813c1 	tbnz	w1, #31, 4a3c <fwp_write.constprop.0+0xa6c>
    47c8:	340013a0 	cbz	w0, 4a3c <fwp_write.constprop.0+0xa6c>
    47cc:	52800503 	mov	w3, #0x28                  	// #40
    47d0:	aa1503e1 	mov	x1, x21
    47d4:	aa1403e0 	mov	x0, x20
    47d8:	d2800022 	mov	x2, #0x1                   	// #1
    47dc:	39001fe3 	strb	w3, [sp, #7]
    47e0:	97fff64c 	bl	2110 <buf_put>
    47e4:	aa1303e2 	mov	x2, x19
    47e8:	aa1703e1 	mov	x1, x23
    47ec:	aa1403e0 	mov	x0, x20
    47f0:	97fffdf8 	bl	3fd0 <fwp_write.constprop.0>
    47f4:	52800523 	mov	w3, #0x29                  	// #41
    47f8:	aa1503e1 	mov	x1, x21
    47fc:	aa1403e0 	mov	x0, x20
    4800:	d2800022 	mov	x2, #0x1                   	// #1
    4804:	39001fe3 	strb	w3, [sp, #7]
    4808:	97fff642 	bl	2110 <buf_put>
    480c:	f9401780 	ldr	x0, [x28, #40]
    4810:	9100077b 	add	x27, x27, #0x1
    4814:	b8796800 	ldr	w0, [x0, x25]
    4818:	6b1b001f 	cmp	w0, w27
    481c:	54fffa8c 	b.gt	476c <fwp_write.constprop.0+0x79c>
    4820:	f9413bf5 	ldr	x21, [sp, #624]
    4824:	f9413ff6 	ldr	x22, [sp, #632]
    4828:	f94143f7 	ldr	x23, [sp, #640]
    482c:	f94147f8 	ldr	x24, [sp, #648]
    4830:	f9414bf9 	ldr	x25, [sp, #656]
    4834:	f9414ffa 	ldr	x26, [sp, #664]
    4838:	f94153fb 	ldr	x27, [sp, #672]
    483c:	f94157fc 	ldr	x28, [sp, #680]
    4840:	17fffe10 	b	4080 <fwp_write.constprop.0+0xb0>
    4844:	aa1403e0 	mov	x0, x20
    4848:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    484c:	d28000c2 	mov	x2, #0x6                   	// #6
    4850:	9106e021 	add	x1, x1, #0x1b8
    4854:	97fff62f 	bl	2110 <buf_put>
    4858:	f9400260 	ldr	x0, [x19]
    485c:	b40004c0 	cbz	x0, 48f4 <fwp_write.constprop.0+0x924>
    4860:	910123f5 	add	x21, sp, #0x48
    4864:	91002276 	add	x22, x19, #0x8
    4868:	f90143f7 	str	x23, [sp, #640]
    486c:	d2800017 	mov	x23, #0x0                   	// #0
    4870:	f90147f8 	str	x24, [sp, #648]
    4874:	b0000038 	adrp	x24, 9000 <_IO_stdin_used+0x1e0>
    4878:	91070318 	add	x24, x24, #0x1c0
    487c:	f9014bf9 	str	x25, [sp, #656]
    4880:	b0000039 	adrp	x25, 9000 <_IO_stdin_used+0x1e0>
    4884:	91072339 	add	x25, x25, #0x1c8
    4888:	f9014ffa 	str	x26, [sp, #664]
    488c:	14000005 	b	48a0 <fwp_write.constprop.0+0x8d0>
    4890:	aa1903e1 	mov	x1, x25
    4894:	aa1403e0 	mov	x0, x20
    4898:	d2800042 	mov	x2, #0x2                   	// #2
    489c:	97fff61d 	bl	2110 <buf_put>
    48a0:	38776ac5 	ldrb	w5, [x22, x23]
    48a4:	d2804003 	mov	x3, #0x200                 	// #512
    48a8:	aa1803e4 	mov	x4, x24
    48ac:	aa0303e1 	mov	x1, x3
    48b0:	52800042 	mov	w2, #0x2                   	// #2
    48b4:	aa1503e0 	mov	x0, x21
    48b8:	910006f7 	add	x23, x23, #0x1
    48bc:	97fff2ed 	bl	1470 <__snprintf_chk@plt>
    48c0:	aa1503e0 	mov	x0, x21
    48c4:	97fff2b3 	bl	1390 <strlen@plt>
    48c8:	aa1503e1 	mov	x1, x21
    48cc:	aa0003e2 	mov	x2, x0
    48d0:	aa1403e0 	mov	x0, x20
    48d4:	97fff60f 	bl	2110 <buf_put>
    48d8:	f9400260 	ldr	x0, [x19]
    48dc:	eb0002ff 	cmp	x23, x0
    48e0:	54fffd83 	b.cc	4890 <fwp_write.constprop.0+0x8c0>  // b.lo, b.ul, b.last
    48e4:	f94143f7 	ldr	x23, [sp, #640]
    48e8:	f94147f8 	ldr	x24, [sp, #648]
    48ec:	f9414bf9 	ldr	x25, [sp, #656]
    48f0:	f9414ffa 	ldr	x26, [sp, #664]
    48f4:	52800ba3 	mov	w3, #0x5d                  	// #93
    48f8:	aa1403e0 	mov	x0, x20
    48fc:	91001fe1 	add	x1, sp, #0x7
    4900:	d2800022 	mov	x2, #0x1                   	// #1
    4904:	39001fe3 	strb	w3, [sp, #7]
    4908:	17fffdd9 	b	406c <fwp_write.constprop.0+0x9c>
    490c:	52800b63 	mov	w3, #0x5b                  	// #91
    4910:	91001ff5 	add	x21, sp, #0x7
    4914:	aa1503e1 	mov	x1, x21
    4918:	aa1403e0 	mov	x0, x20
    491c:	d2800022 	mov	x2, #0x1                   	// #1
    4920:	b0000036 	adrp	x22, 9000 <_IO_stdin_used+0x1e0>
    4924:	910722d6 	add	x22, x22, #0x1c8
    4928:	39001fe3 	strb	w3, [sp, #7]
    492c:	97fff5f9 	bl	2110 <buf_put>
    4930:	b4000233 	cbz	x19, 4974 <fwp_write.constprop.0+0x9a4>
    4934:	f9400661 	ldr	x1, [x19, #8]
    4938:	aa1403e0 	mov	x0, x20
    493c:	f9401f82 	ldr	x2, [x28, #56]
    4940:	97fffda4 	bl	3fd0 <fwp_write.constprop.0>
    4944:	f9400a73 	ldr	x19, [x19, #16]
    4948:	b4000173 	cbz	x19, 4974 <fwp_write.constprop.0+0x9a4>
    494c:	aa1603e1 	mov	x1, x22
    4950:	aa1403e0 	mov	x0, x20
    4954:	d2800042 	mov	x2, #0x2                   	// #2
    4958:	97fff5ee 	bl	2110 <buf_put>
    495c:	f9400661 	ldr	x1, [x19, #8]
    4960:	aa1403e0 	mov	x0, x20
    4964:	f9401f82 	ldr	x2, [x28, #56]
    4968:	97fffd9a 	bl	3fd0 <fwp_write.constprop.0>
    496c:	f9400a73 	ldr	x19, [x19, #16]
    4970:	b5fffef3 	cbnz	x19, 494c <fwp_write.constprop.0+0x97c>
    4974:	52800ba3 	mov	w3, #0x5d                  	// #93
    4978:	aa1503e1 	mov	x1, x21
    497c:	aa1403e0 	mov	x0, x20
    4980:	d2800022 	mov	x2, #0x1                   	// #1
    4984:	39001fe3 	strb	w3, [sp, #7]
    4988:	17fffdb9 	b	406c <fwp_write.constprop.0+0x9c>
    498c:	52800783 	mov	w3, #0x3c                  	// #60
    4990:	91001ff3 	add	x19, sp, #0x7
    4994:	aa1303e1 	mov	x1, x19
    4998:	d2800022 	mov	x2, #0x1                   	// #1
    499c:	aa1403e0 	mov	x0, x20
    49a0:	39001fe3 	strb	w3, [sp, #7]
    49a4:	97fff5db 	bl	2110 <buf_put>
    49a8:	f9400795 	ldr	x21, [x28, #8]
    49ac:	aa1503e0 	mov	x0, x21
    49b0:	97fff278 	bl	1390 <strlen@plt>
    49b4:	aa1503e1 	mov	x1, x21
    49b8:	aa0003e2 	mov	x2, x0
    49bc:	aa1403e0 	mov	x0, x20
    49c0:	97fff5d4 	bl	2110 <buf_put>
    49c4:	528007c3 	mov	w3, #0x3e                  	// #62
    49c8:	aa1303e1 	mov	x1, x19
    49cc:	aa1403e0 	mov	x0, x20
    49d0:	d2800022 	mov	x2, #0x1                   	// #1
    49d4:	39001fe3 	strb	w3, [sp, #7]
    49d8:	17fffda5 	b	406c <fwp_write.constprop.0+0x9c>
    49dc:	f100067f 	cmp	x19, #0x1
    49e0:	540017e0 	b.eq	4cdc <fwp_write.constprop.0+0xd0c>  // b.none
    49e4:	b100067f 	cmn	x19, #0x1
    49e8:	54001b00 	b.eq	4d48 <fwp_write.constprop.0+0xd78>  // b.none
    49ec:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    49f0:	9104e021 	add	x1, x1, #0x138
    49f4:	d2800022 	mov	x2, #0x1                   	// #1
    49f8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    49fc:	f947f400 	ldr	x0, [x0, #4072]
    4a00:	f94127e4 	ldr	x4, [sp, #584]
    4a04:	f9400003 	ldr	x3, [x0]
    4a08:	eb030084 	subs	x4, x4, x3
    4a0c:	d2800003 	mov	x3, #0x0                   	// #0
    4a10:	54002a41 	b.ne	4f58 <fwp_write.constprop.0+0xf88>  // b.any
    4a14:	f9413bf5 	ldr	x21, [sp, #624]
    4a18:	aa1403e0 	mov	x0, x20
    4a1c:	f9413ff6 	ldr	x22, [sp, #632]
    4a20:	17fffdef 	b	41dc <fwp_write.constprop.0+0x20c>
    4a24:	52800fa3 	mov	w3, #0x7d                  	// #125
    4a28:	17fffe2c 	b	42d8 <fwp_write.constprop.0+0x308>
    4a2c:	f10002ff 	cmp	x23, #0x0
    4a30:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4a34:	71002c3f 	cmp	w1, #0xb
    4a38:	54ffec80 	b.eq	47c8 <fwp_write.constprop.0+0x7f8>  // b.none
    4a3c:	aa1303e2 	mov	x2, x19
    4a40:	aa1703e1 	mov	x1, x23
    4a44:	aa1403e0 	mov	x0, x20
    4a48:	97fffd62 	bl	3fd0 <fwp_write.constprop.0>
    4a4c:	17ffff70 	b	480c <fwp_write.constprop.0+0x83c>
    4a50:	aa1903e1 	mov	x1, x25
    4a54:	aa1403e0 	mov	x0, x20
    4a58:	d2800042 	mov	x2, #0x2                   	// #2
    4a5c:	97fff5ad 	bl	2110 <buf_put>
    4a60:	17fffeee 	b	4618 <fwp_write.constprop.0+0x648>
    4a64:	aa1403e0 	mov	x0, x20
    4a68:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    4a6c:	d2800042 	mov	x2, #0x2                   	// #2
    4a70:	91068021 	add	x1, x1, #0x1a0
    4a74:	97fff5a7 	bl	2110 <buf_put>
    4a78:	17fffee8 	b	4618 <fwp_write.constprop.0+0x648>
    4a7c:	aa1803e1 	mov	x1, x24
    4a80:	aa1403e0 	mov	x0, x20
    4a84:	d2800042 	mov	x2, #0x2                   	// #2
    4a88:	97fff5a2 	bl	2110 <buf_put>
    4a8c:	17fffee3 	b	4618 <fwp_write.constprop.0+0x648>
    4a90:	f9414bf9 	ldr	x25, [sp, #656]
    4a94:	f9414ffa 	ldr	x26, [sp, #664]
    4a98:	aa1503e1 	mov	x1, x21
    4a9c:	aa1403e0 	mov	x0, x20
    4aa0:	52800443 	mov	w3, #0x22                  	// #34
    4aa4:	17fffe0f 	b	42e0 <fwp_write.constprop.0+0x310>
    4aa8:	a9400281 	ldp	x1, x0, [x20]
    4aac:	91000800 	add	x0, x0, #0x2
    4ab0:	8b160000 	add	x0, x0, x22
    4ab4:	f9000680 	str	x0, [x20, #8]
    4ab8:	3820683f 	strb	wzr, [x1, x0]
    4abc:	f9413bf5 	ldr	x21, [sp, #624]
    4ac0:	f9413ff6 	ldr	x22, [sp, #632]
    4ac4:	f94153fb 	ldr	x27, [sp, #672]
    4ac8:	f94157fc 	ldr	x28, [sp, #680]
    4acc:	17fffd6d 	b	4080 <fwp_write.constprop.0+0xb0>
    4ad0:	aa1403e0 	mov	x0, x20
    4ad4:	91001fe1 	add	x1, sp, #0x7
    4ad8:	52800fa3 	mov	w3, #0x7d                  	// #125
    4adc:	d2800022 	mov	x2, #0x1                   	// #1
    4ae0:	17fffe01 	b	42e4 <fwp_write.constprop.0+0x314>
    4ae4:	f9400f80 	ldr	x0, [x28, #24]
    4ae8:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    4aec:	aa1b03e0 	mov	x0, x27
    4af0:	97fff228 	bl	1390 <strlen@plt>
    4af4:	aa1b03e1 	mov	x1, x27
    4af8:	aa0003e2 	mov	x2, x0
    4afc:	aa1403e0 	mov	x0, x20
    4b00:	97fff584 	bl	2110 <buf_put>
    4b04:	aa1903e1 	mov	x1, x25
    4b08:	aa1403e0 	mov	x0, x20
    4b0c:	d2800062 	mov	x2, #0x3                   	// #3
    4b10:	97fff580 	bl	2110 <buf_put>
    4b14:	17fffde4 	b	42a4 <fwp_write.constprop.0+0x2d4>
    4b18:	aa1a03e1 	mov	x1, x26
    4b1c:	aa1403e0 	mov	x0, x20
    4b20:	d2800042 	mov	x2, #0x2                   	// #2
    4b24:	97fff57b 	bl	2110 <buf_put>
    4b28:	17fffddd 	b	429c <fwp_write.constprop.0+0x2cc>
    4b2c:	f9400660 	ldr	x0, [x19, #8]
    4b30:	b4fff860 	cbz	x0, 4a3c <fwp_write.constprop.0+0xa6c>
    4b34:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    4b38:	91078021 	add	x1, x1, #0x1e0
    4b3c:	97fff291 	bl	1580 <strcmp@plt>
    4b40:	7100001f 	cmp	w0, #0x0
    4b44:	1a9f07e0 	cset	w0, ne	// ne = any
    4b48:	17ffff20 	b	47c8 <fwp_write.constprop.0+0x7f8>
    4b4c:	aa1403e0 	mov	x0, x20
    4b50:	d2800042 	mov	x2, #0x2                   	// #2
    4b54:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    4b58:	91076021 	add	x1, x1, #0x1d8
    4b5c:	97fff56d 	bl	2110 <buf_put>
    4b60:	91004261 	add	x1, x19, #0x10
    4b64:	aa1403e0 	mov	x0, x20
    4b68:	f9402382 	ldr	x2, [x28, #64]
    4b6c:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    4b70:	97fffd18 	bl	3fd0 <fwp_write.constprop.0>
    4b74:	17fffd71 	b	4138 <fwp_write.constprop.0+0x168>
    4b78:	d2800203 	mov	x3, #0x10                  	// #16
    4b7c:	b0000024 	adrp	x4, 9000 <_IO_stdin_used+0x1e0>
    4b80:	aa0303e1 	mov	x1, x3
    4b84:	9106c084 	add	x4, x4, #0x1b0
    4b88:	910123f7 	add	x23, sp, #0x48
    4b8c:	52800042 	mov	w2, #0x2                   	// #2
    4b90:	aa1703e0 	mov	x0, x23
    4b94:	97fff237 	bl	1470 <__snprintf_chk@plt>
    4b98:	aa1703e0 	mov	x0, x23
    4b9c:	97fff1fd 	bl	1390 <strlen@plt>
    4ba0:	aa1703e1 	mov	x1, x23
    4ba4:	aa0003e2 	mov	x2, x0
    4ba8:	aa1403e0 	mov	x0, x20
    4bac:	97fff559 	bl	2110 <buf_put>
    4bb0:	17fffe9a 	b	4618 <fwp_write.constprop.0+0x648>
    4bb4:	7101fcbf 	cmp	w5, #0x7f
    4bb8:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    4bbc:	54fffde9 	b.ls	4b78 <fwp_write.constprop.0+0xba8>  // b.plast
    4bc0:	aa1503e1 	mov	x1, x21
    4bc4:	aa1403e0 	mov	x0, x20
    4bc8:	d2800022 	mov	x2, #0x1                   	// #1
    4bcc:	39001fe5 	strb	w5, [sp, #7]
    4bd0:	97fff550 	bl	2110 <buf_put>
    4bd4:	17fffe91 	b	4618 <fwp_write.constprop.0+0x648>
    4bd8:	1e22c109 	fcvt	d9, s8
    4bdc:	910123f5 	add	x21, sp, #0x48
    4be0:	52800033 	mov	w19, #0x1                   	// #1
    4be4:	d503201f 	nop
    4be8:	1e604120 	fmov	d0, d9
    4bec:	2a1303e1 	mov	w1, w19
    4bf0:	aa1503e0 	mov	x0, x21
    4bf4:	97fff5db 	bl	2360 <fwp_format_g.constprop.0>
    4bf8:	aa1503e0 	mov	x0, x21
    4bfc:	d2800001 	mov	x1, #0x0                   	// #0
    4c00:	97fff26c 	bl	15b0 <strtof@plt>
    4c04:	1e202100 	fcmp	s8, s0
    4c08:	54ffd6c0 	b.eq	46e0 <fwp_write.constprop.0+0x710>  // b.none
    4c0c:	11000673 	add	w19, w19, #0x1
    4c10:	71002a7f 	cmp	w19, #0xa
    4c14:	54fffea1 	b.ne	4be8 <fwp_write.constprop.0+0xc18>  // b.any
    4c18:	1e604120 	fmov	d0, d9
    4c1c:	aa1503e0 	mov	x0, x21
    4c20:	52800121 	mov	w1, #0x9                   	// #9
    4c24:	97fff5cf 	bl	2360 <fwp_format_g.constprop.0>
    4c28:	17fffeae 	b	46e0 <fwp_write.constprop.0+0x710>
    4c2c:	d37ef6a1 	lsl	x1, x21, #2
    4c30:	b7f809a3 	tbnz	x3, #63, 4d64 <fwp_write.constprop.0+0xd94>
    4c34:	91002263 	add	x3, x19, #0x8
    4c38:	8b010061 	add	x1, x3, x1
    4c3c:	b9400023 	ldr	w3, [x1]
    4c40:	7100081f 	cmp	w0, #0x2
    4c44:	2a0303e1 	mov	w1, w3
    4c48:	93407c63 	sxtw	x3, w3
    4c4c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4c50:	17fffe16 	b	44a8 <fwp_write.constprop.0+0x4d8>
    4c54:	d37ffaa1 	lsl	x1, x21, #1
    4c58:	b7f80803 	tbnz	x3, #63, 4d58 <fwp_write.constprop.0+0xd88>
    4c5c:	91002263 	add	x3, x19, #0x8
    4c60:	8b010061 	add	x1, x3, x1
    4c64:	79400021 	ldrh	w1, [x1]
    4c68:	7100041f 	cmp	w0, #0x1
    4c6c:	93403c23 	sxth	x3, w1
    4c70:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4c74:	17fffe0d 	b	44a8 <fwp_write.constprop.0+0x4d8>
    4c78:	7100103f 	cmp	w1, #0x4
    4c7c:	54ffee01 	b.ne	4a3c <fwp_write.constprop.0+0xa6c>  // b.any
    4c80:	f94006e0 	ldr	x0, [x23, #8]
    4c84:	d37ffc00 	lsr	x0, x0, #63
    4c88:	17fffed0 	b	47c8 <fwp_write.constprop.0+0x7f8>
    4c8c:	710002ff 	cmp	w23, #0x0
    4c90:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4c94:	17fffecd 	b	47c8 <fwp_write.constprop.0+0x7f8>
    4c98:	528005a1 	mov	w1, #0x2d                  	// #45
    4c9c:	eb0203e2 	negs	x2, x2
    4ca0:	da0303e3 	ngc	x3, x3
    4ca4:	910127e0 	add	x0, sp, #0x49
    4ca8:	910123f5 	add	x21, sp, #0x48
    4cac:	390123e1 	strb	w1, [sp, #72]
    4cb0:	97fff36c 	bl	1a60 <fwp_fmt_u128>
    4cb4:	17fffe16 	b	450c <fwp_write.constprop.0+0x53c>
    4cb8:	d37ceea1 	lsl	x1, x21, #4
    4cbc:	b7f80da3 	tbnz	x3, #63, 4e70 <fwp_write.constprop.0+0xea0>
    4cc0:	91002260 	add	x0, x19, #0x8
    4cc4:	8b010001 	add	x1, x0, x1
    4cc8:	17fffdf8 	b	44a8 <fwp_write.constprop.0+0x4d8>
    4ccc:	f9400a61 	ldr	x1, [x19, #16]
    4cd0:	8b010000 	add	x0, x0, x1
    4cd4:	f9400001 	ldr	x1, [x0]
    4cd8:	17fffdf4 	b	44a8 <fwp_write.constprop.0+0x4d8>
    4cdc:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    4ce0:	d2800042 	mov	x2, #0x2                   	// #2
    4ce4:	9104a021 	add	x1, x1, #0x128
    4ce8:	17ffff44 	b	49f8 <fwp_write.constprop.0+0xa28>
    4cec:	1e604100 	fmov	d0, d8
    4cf0:	aa1503e0 	mov	x0, x21
    4cf4:	52800221 	mov	w1, #0x11                  	// #17
    4cf8:	97fff59a 	bl	2360 <fwp_format_g.constprop.0>
    4cfc:	17fffe79 	b	46e0 <fwp_write.constprop.0+0x710>
    4d00:	b9401380 	ldr	w0, [x28, #16]
    4d04:	350003c0 	cbnz	w0, 4d7c <fwp_write.constprop.0+0xdac>
    4d08:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    4d0c:	f947f400 	ldr	x0, [x0, #4072]
    4d10:	f94127e2 	ldr	x2, [sp, #584]
    4d14:	f9400001 	ldr	x1, [x0]
    4d18:	eb010042 	subs	x2, x2, x1
    4d1c:	d2800001 	mov	x1, #0x0                   	// #0
    4d20:	54001201 	b.ne	4f60 <fwp_write.constprop.0+0xf90>  // b.any
    4d24:	f9413bf5 	ldr	x21, [sp, #624]
    4d28:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    4d2c:	f9413ff6 	ldr	x22, [sp, #632]
    4d30:	aa1403e0 	mov	x0, x20
    4d34:	f94143f7 	ldr	x23, [sp, #640]
    4d38:	91080021 	add	x1, x1, #0x200
    4d3c:	f94147f8 	ldr	x24, [sp, #648]
    4d40:	d2800042 	mov	x2, #0x2                   	// #2
    4d44:	17fffd26 	b	41dc <fwp_write.constprop.0+0x20c>
    4d48:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    4d4c:	d2800042 	mov	x2, #0x2                   	// #2
    4d50:	9104c021 	add	x1, x1, #0x130
    4d54:	17ffff29 	b	49f8 <fwp_write.constprop.0+0xa28>
    4d58:	f9400a63 	ldr	x3, [x19, #16]
    4d5c:	8b030021 	add	x1, x1, x3
    4d60:	17ffffc1 	b	4c64 <fwp_write.constprop.0+0xc94>
    4d64:	f9400a63 	ldr	x3, [x19, #16]
    4d68:	8b030021 	add	x1, x1, x3
    4d6c:	17ffffb4 	b	4c3c <fwp_write.constprop.0+0xc6c>
    4d70:	f9400a61 	ldr	x1, [x19, #16]
    4d74:	8b0102a1 	add	x1, x21, x1
    4d78:	17fffdc7 	b	4494 <fwp_write.constprop.0+0x4c4>
    4d7c:	b9404b80 	ldr	w0, [x28, #72]
    4d80:	91001ff5 	add	x21, sp, #0x7
    4d84:	34ffa660 	cbz	w0, 4250 <fwp_write.constprop.0+0x280>
    4d88:	52800503 	mov	w3, #0x28                  	// #40
    4d8c:	aa1403e0 	mov	x0, x20
    4d90:	aa1503e1 	mov	x1, x21
    4d94:	d2800022 	mov	x2, #0x1                   	// #1
    4d98:	39001fe3 	strb	w3, [sp, #7]
    4d9c:	97fff4dd 	bl	2110 <buf_put>
    4da0:	b9401380 	ldr	w0, [x28, #16]
    4da4:	52800038 	mov	w24, #0x1                   	// #1
    4da8:	7100001f 	cmp	w0, #0x0
    4dac:	54ffa66c 	b.gt	4278 <fwp_write.constprop.0+0x2a8>
    4db0:	17fffd49 	b	42d4 <fwp_write.constprop.0+0x304>
    4db4:	f9014bf9 	str	x25, [sp, #656]
    4db8:	f00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x14da0>
    4dbc:	f9014ffa 	str	x26, [sp, #664]
    4dc0:	f9400676 	ldr	x22, [x19, #8]
    4dc4:	912ca333 	add	x19, x25, #0xb28
    4dc8:	91002273 	add	x19, x19, #0x8
    4dcc:	937ffed8 	asr	x24, x22, #63
    4dd0:	aa1802c0 	orr	x0, x22, x24
    4dd4:	b5000320 	cbnz	x0, 4e38 <fwp_write.constprop.0+0xe68>
    4dd8:	110006b5 	add	w21, w21, #0x1
    4ddc:	710016bf 	cmp	w21, #0x5
    4de0:	54ffffc1 	b.ne	4dd8 <fwp_write.constprop.0+0xe08>  // b.any
    4de4:	b7f80578 	tbnz	x24, #63, 4e90 <fwp_write.constprop.0+0xec0>
    4de8:	910023f3 	add	x19, sp, #0x8
    4dec:	aa1603e2 	mov	x2, x22
    4df0:	aa1303e0 	mov	x0, x19
    4df4:	d2800003 	mov	x3, #0x0                   	// #0
    4df8:	97fff31a 	bl	1a60 <fwp_fmt_u128>
    4dfc:	910123f5 	add	x21, sp, #0x48
    4e00:	b0000023 	adrp	x3, 9000 <_IO_stdin_used+0x1e0>
    4e04:	aa1303e4 	mov	x4, x19
    4e08:	aa1503e0 	mov	x0, x21
    4e0c:	9107e063 	add	x3, x3, #0x1f8
    4e10:	d2804002 	mov	x2, #0x200                 	// #512
    4e14:	52800041 	mov	w1, #0x2                   	// #2
    4e18:	97fff162 	bl	13a0 <__sprintf_chk@plt>
    4e1c:	aa1503e0 	mov	x0, x21
    4e20:	97fff15c 	bl	1390 <strlen@plt>
    4e24:	aa1503e1 	mov	x1, x21
    4e28:	aa0003e2 	mov	x2, x0
    4e2c:	aa1403e0 	mov	x0, x20
    4e30:	97fff4b8 	bl	2110 <buf_put>
    4e34:	17fffe7b 	b	4820 <fwp_write.constprop.0+0x850>
    4e38:	f9400277 	ldr	x23, [x19]
    4e3c:	aa1603e0 	mov	x0, x22
    4e40:	aa1803e1 	mov	x1, x24
    4e44:	aa1703e2 	mov	x2, x23
    4e48:	937ffefa 	asr	x26, x23, #63
    4e4c:	aa1a03e3 	mov	x3, x26
    4e50:	94000f0c 	bl	8a80 <__modti3>
    4e54:	aa010000 	orr	x0, x0, x1
    4e58:	b40002c0 	cbz	x0, 4eb0 <fwp_write.constprop.0+0xee0>
    4e5c:	110006b5 	add	w21, w21, #0x1
    4e60:	91004273 	add	x19, x19, #0x10
    4e64:	710016bf 	cmp	w21, #0x5
    4e68:	54fffe81 	b.ne	4e38 <fwp_write.constprop.0+0xe68>  // b.any
    4e6c:	17ffffde 	b	4de4 <fwp_write.constprop.0+0xe14>
    4e70:	f9400a60 	ldr	x0, [x19, #16]
    4e74:	8b000021 	add	x1, x1, x0
    4e78:	17fffd8c 	b	44a8 <fwp_write.constprop.0+0x4d8>
    4e7c:	528c29c0 	mov	w0, #0x614e                	// #24910
    4e80:	910123f5 	add	x21, sp, #0x48
    4e84:	72a009c0 	movk	w0, #0x4e, lsl #16
    4e88:	b9004be0 	str	w0, [sp, #72]
    4e8c:	17fffdb9 	b	4570 <fwp_write.constprop.0+0x5a0>
    4e90:	528005a1 	mov	w1, #0x2d                  	// #45
    4e94:	eb1603e2 	negs	x2, x22
    4e98:	da1803e3 	ngc	x3, x24
    4e9c:	910027e0 	add	x0, sp, #0x9
    4ea0:	910023f3 	add	x19, sp, #0x8
    4ea4:	390023e1 	strb	w1, [sp, #8]
    4ea8:	97fff2ee 	bl	1a60 <fwp_fmt_u128>
    4eac:	17ffffd4 	b	4dfc <fwp_write.constprop.0+0xe2c>
    4eb0:	aa1703e2 	mov	x2, x23
    4eb4:	aa1a03e3 	mov	x3, x26
    4eb8:	aa1603e0 	mov	x0, x22
    4ebc:	aa1803e1 	mov	x1, x24
    4ec0:	94000e10 	bl	8700 <__divti3>
    4ec4:	aa0003e2 	mov	x2, x0
    4ec8:	aa0103e3 	mov	x3, x1
    4ecc:	b7f80201 	tbnz	x1, #63, 4f0c <fwp_write.constprop.0+0xf3c>
    4ed0:	910023f3 	add	x19, sp, #0x8
    4ed4:	aa1303e0 	mov	x0, x19
    4ed8:	97fff2e2 	bl	1a60 <fwp_fmt_u128>
    4edc:	937c7ea1 	sbfiz	x1, x21, #4, #32
    4ee0:	912ca339 	add	x25, x25, #0xb28
    4ee4:	910123f5 	add	x21, sp, #0x48
    4ee8:	aa1303e4 	mov	x4, x19
    4eec:	aa1503e0 	mov	x0, x21
    4ef0:	b0000023 	adrp	x3, 9000 <_IO_stdin_used+0x1e0>
    4ef4:	f8616b25 	ldr	x5, [x25, x1]
    4ef8:	9107c063 	add	x3, x3, #0x1f0
    4efc:	d2804002 	mov	x2, #0x200                 	// #512
    4f00:	52800041 	mov	w1, #0x2                   	// #2
    4f04:	97fff127 	bl	13a0 <__sprintf_chk@plt>
    4f08:	17ffffc5 	b	4e1c <fwp_write.constprop.0+0xe4c>
    4f0c:	528005a4 	mov	w4, #0x2d                  	// #45
    4f10:	eb0003e2 	negs	x2, x0
    4f14:	da0103e3 	ngc	x3, x1
    4f18:	910027e0 	add	x0, sp, #0x9
    4f1c:	910023f3 	add	x19, sp, #0x8
    4f20:	390023e4 	strb	w4, [sp, #8]
    4f24:	97fff2cf 	bl	1a60 <fwp_fmt_u128>
    4f28:	17ffffed 	b	4edc <fwp_write.constprop.0+0xf0c>
    4f2c:	f9013bf5 	str	x21, [sp, #624]
    4f30:	f9013ff6 	str	x22, [sp, #632]
    4f34:	f90143f7 	str	x23, [sp, #640]
    4f38:	f90147f8 	str	x24, [sp, #648]
    4f3c:	f9014bf9 	str	x25, [sp, #656]
    4f40:	f9014ffa 	str	x26, [sp, #664]
    4f44:	f90153fb 	str	x27, [sp, #672]
    4f48:	f90157fc 	str	x28, [sp, #680]
    4f4c:	fd015be8 	str	d8, [sp, #688]
    4f50:	fd015fe9 	str	d9, [sp, #696]
    4f54:	97fff16b 	bl	1500 <__stack_chk_fail@plt>
    4f58:	f90143f7 	str	x23, [sp, #640]
    4f5c:	f90147f8 	str	x24, [sp, #648]
    4f60:	f9014bf9 	str	x25, [sp, #656]
    4f64:	f9014ffa 	str	x26, [sp, #664]
    4f68:	fd015be8 	str	d8, [sp, #688]
    4f6c:	fd015fe9 	str	d9, [sp, #696]
    4f70:	97fff164 	bl	1500 <__stack_chk_fail@plt>

0000000000004f74 <fwp_hof0.constprop.0>:
    4f74:	d102c3ff 	sub	sp, sp, #0xb0
    4f78:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x14da0>
    4f7c:	f947f442 	ldr	x2, [x2, #4072]
    4f80:	a9047bfd 	stp	x29, x30, [sp, #64]
    4f84:	910103fd 	add	x29, sp, #0x40
    4f88:	a9065bf5 	stp	x21, x22, [sp, #96]
    4f8c:	aa0003f5 	mov	x21, x0
    4f90:	f9400040 	ldr	x0, [x2]
    4f94:	f9001fe0 	str	x0, [sp, #56]
    4f98:	d2800000 	mov	x0, #0x0                   	// #0
    4f9c:	f90007e1 	str	x1, [sp, #8]
    4fa0:	b40044e1 	cbz	x1, 583c <fwp_hof0.constprop.0+0x8c8>
    4fa4:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1e0>
    4fa8:	6d0a27e8 	stp	d8, d9, [sp, #160]
    4fac:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    4fb0:	fd429029 	ldr	d9, [x1, #1312]
    4fb4:	9e670008 	fmov	d8, x0
    4fb8:	a90553f3 	stp	x19, x20, [sp, #80]
    4fbc:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc70>
    4fc0:	a90763f7 	stp	x23, x24, [sp, #112]
    4fc4:	a9086bf9 	stp	x25, x26, [sp, #128]
    4fc8:	a90973fb 	stp	x27, x28, [sp, #144]
    4fcc:	d503201f 	nop
    4fd0:	9115c282 	add	x2, x20, #0x570
    4fd4:	f949d840 	ldr	x0, [x2, #5040]
    4fd8:	f949ec41 	ldr	x1, [x2, #5080]
    4fdc:	cb0002a0 	sub	x0, x21, x0
    4fe0:	eb01401f 	cmp	x0, x1, lsl #16
    4fe4:	54000422 	b.cs	5068 <fwp_hof0.constprop.0+0xf4>  // b.hs, b.nlast
    4fe8:	d350fc01 	lsr	x1, x0, #16
    4fec:	f949fc43 	ldr	x3, [x2, #5112]
    4ff0:	8b010821 	add	x1, x1, x1, lsl #2
    4ff4:	d37df021 	lsl	x1, x1, #3
    4ff8:	8b010062 	add	x2, x3, x1
    4ffc:	f9401053 	ldr	x19, [x2, #32]
    5000:	b4000353 	cbz	x19, 5068 <fwp_hof0.constprop.0+0xf4>
    5004:	38616861 	ldrb	w1, [x3, x1]
    5008:	7100083f 	cmp	w1, #0x2
    500c:	54004fc0 	b.eq	5a04 <fwp_hof0.constprop.0+0xa90>  // b.none
    5010:	7100043f 	cmp	w1, #0x1
    5014:	540002a1 	b.ne	5068 <fwp_hof0.constprop.0+0xf4>  // b.any
    5018:	29430443 	ldp	w3, w1, [x2, #24]
    501c:	92403c00 	and	x0, x0, #0xffff
    5020:	9b037c00 	mul	x0, x0, x3
    5024:	d360fc00 	lsr	x0, x0, #32
    5028:	eb01001f 	cmp	x0, x1
    502c:	540001e2 	b.cs	5068 <fwp_hof0.constprop.0+0xf4>  // b.hs, b.nlast
    5030:	8b000273 	add	x19, x19, x0
    5034:	39400260 	ldrb	w0, [x19]
    5038:	34000180 	cbz	w0, 5068 <fwp_hof0.constprop.0+0xf4>
    503c:	f00000c1 	adrp	x1, 20000 <__data_start>
    5040:	91024021 	add	x1, x1, #0x90
    5044:	b9404022 	ldr	w2, [x1, #64]
    5048:	34000082 	cbz	w2, 5058 <fwp_hof0.constprop.0+0xe4>
    504c:	f9416422 	ldr	x2, [x1, #712]
    5050:	91000442 	add	x2, x2, #0x1
    5054:	f9016422 	str	x2, [x1, #712]
    5058:	7103f41f 	cmp	w0, #0xfd
    505c:	54005868 	b.hi	5b68 <fwp_hof0.constprop.0+0xbf4>  // b.pmore
    5060:	11000400 	add	w0, w0, #0x1
    5064:	39000260 	strb	w0, [x19]
    5068:	b4004d55 	cbz	x21, 5a10 <fwp_hof0.constprop.0+0xa9c>
    506c:	aa1503e1 	mov	x1, x21
    5070:	d2800000 	mov	x0, #0x0                   	// #0
    5074:	d503201f 	nop
    5078:	f9400821 	ldr	x1, [x1, #16]
    507c:	91000400 	add	x0, x0, #0x1
    5080:	b5ffffc1 	cbnz	x1, 5078 <fwp_hof0.constprop.0+0x104>
    5084:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    5088:	eb01001f 	cmp	x0, x1
    508c:	54006028 	b.hi	5c90 <fwp_hof0.constprop.0+0xd1c>  // b.pmore
    5090:	97fffa10 	bl	38d0 <fwp_array_new_packed.constprop.0>
    5094:	aa0003f8 	mov	x24, x0
    5098:	9115c281 	add	x1, x20, #0x570
    509c:	aa0103e0 	mov	x0, x1
    50a0:	f949d821 	ldr	x1, [x1, #5040]
    50a4:	f949ec00 	ldr	x0, [x0, #5080]
    50a8:	cb010301 	sub	x1, x24, x1
    50ac:	eb00403f 	cmp	x1, x0, lsl #16
    50b0:	54000362 	b.cs	511c <fwp_hof0.constprop.0+0x1a8>  // b.hs, b.nlast
    50b4:	9115c282 	add	x2, x20, #0x570
    50b8:	d350fc20 	lsr	x0, x1, #16
    50bc:	8b000800 	add	x0, x0, x0, lsl #2
    50c0:	f949fc43 	ldr	x3, [x2, #5112]
    50c4:	d37df002 	lsl	x2, x0, #3
    50c8:	8b020060 	add	x0, x3, x2
    50cc:	f9401013 	ldr	x19, [x0, #32]
    50d0:	b4000253 	cbz	x19, 5118 <fwp_hof0.constprop.0+0x1a4>
    50d4:	38626862 	ldrb	w2, [x3, x2]
    50d8:	7100085f 	cmp	w2, #0x2
    50dc:	54004b20 	b.eq	5a40 <fwp_hof0.constprop.0+0xacc>  // b.none
    50e0:	7100045f 	cmp	w2, #0x1
    50e4:	540001a1 	b.ne	5118 <fwp_hof0.constprop.0+0x1a4>  // b.any
    50e8:	29430002 	ldp	w2, w0, [x0, #24]
    50ec:	92403c21 	and	x1, x1, #0xffff
    50f0:	9b027c21 	mul	x1, x1, x2
    50f4:	d360fc21 	lsr	x1, x1, #32
    50f8:	eb00003f 	cmp	x1, x0
    50fc:	540000e2 	b.cs	5118 <fwp_hof0.constprop.0+0x1a4>  // b.hs, b.nlast
    5100:	8b010273 	add	x19, x19, x1
    5104:	39400260 	ldrb	w0, [x19]
    5108:	7103fc1f 	cmp	w0, #0xff
    510c:	54004a40 	b.eq	5a54 <fwp_hof0.constprop.0+0xae0>  // b.none
    5110:	52800020 	mov	w0, #0x1                   	// #1
    5114:	39000260 	strb	w0, [x19]
    5118:	b4004915 	cbz	x21, 5a38 <fwp_hof0.constprop.0+0xac4>
    511c:	91002316 	add	x22, x24, #0x8
    5120:	aa1503e0 	mov	x0, x21
    5124:	aa1503f3 	mov	x19, x21
    5128:	9115c299 	add	x25, x20, #0x570
    512c:	5280003a 	mov	w26, #0x1                   	// #1
    5130:	14000014 	b	5180 <fwp_hof0.constprop.0+0x20c>
    5134:	7100045f 	cmp	w2, #0x1
    5138:	54000181 	b.ne	5168 <fwp_hof0.constprop.0+0x1f4>  // b.any
    513c:	294308e8 	ldp	w8, w2, [x7, #24]
    5140:	92403c21 	and	x1, x1, #0xffff
    5144:	9b087c21 	mul	x1, x1, x8
    5148:	d360fc21 	lsr	x1, x1, #32
    514c:	eb02003f 	cmp	x1, x2
    5150:	540000c2 	b.cs	5168 <fwp_hof0.constprop.0+0x1f4>  // b.hs, b.nlast
    5154:	8b0100a5 	add	x5, x5, x1
    5158:	394000a1 	ldrb	w1, [x5]
    515c:	7100043f 	cmp	w1, #0x1
    5160:	54000400 	b.eq	51e0 <fwp_hof0.constprop.0+0x26c>  // b.none
    5164:	d503201f 	nop
    5168:	f9400301 	ldr	x1, [x24]
    516c:	b7f855e1 	tbnz	x1, #63, 5c28 <fwp_hof0.constprop.0+0xcb4>
    5170:	f90002c4 	str	x4, [x22]
    5174:	5280001a 	mov	w26, #0x0                   	// #0
    5178:	910022d6 	add	x22, x22, #0x8
    517c:	b4000773 	cbz	x19, 5268 <fwp_hof0.constprop.0+0x2f4>
    5180:	aa1303e6 	mov	x6, x19
    5184:	aa1303e3 	mov	x3, x19
    5188:	a940ce64 	ldp	x4, x19, [x19, #8]
    518c:	34fffefa 	cbz	w26, 5168 <fwp_hof0.constprop.0+0x1f4>
    5190:	f949db21 	ldr	x1, [x25, #5040]
    5194:	f949ef22 	ldr	x2, [x25, #5080]
    5198:	cb0100c1 	sub	x1, x6, x1
    519c:	eb02403f 	cmp	x1, x2, lsl #16
    51a0:	54fffe42 	b.cs	5168 <fwp_hof0.constprop.0+0x1f4>  // b.hs, b.nlast
    51a4:	d350fc22 	lsr	x2, x1, #16
    51a8:	f949ff28 	ldr	x8, [x25, #5112]
    51ac:	8b020842 	add	x2, x2, x2, lsl #2
    51b0:	d37df042 	lsl	x2, x2, #3
    51b4:	8b020107 	add	x7, x8, x2
    51b8:	f94010e5 	ldr	x5, [x7, #32]
    51bc:	b4fffd65 	cbz	x5, 5168 <fwp_hof0.constprop.0+0x1f4>
    51c0:	38626902 	ldrb	w2, [x8, x2]
    51c4:	7100085f 	cmp	w2, #0x2
    51c8:	54fffb61 	b.ne	5134 <fwp_hof0.constprop.0+0x1c0>  // b.any
    51cc:	72003c3f 	tst	w1, #0xffff
    51d0:	54fffcc1 	b.ne	5168 <fwp_hof0.constprop.0+0x1f4>  // b.any
    51d4:	394000a1 	ldrb	w1, [x5]
    51d8:	7100043f 	cmp	w1, #0x1
    51dc:	54fffc61 	b.ne	5168 <fwp_hof0.constprop.0+0x1f4>  // b.any
    51e0:	f9400300 	ldr	x0, [x24]
    51e4:	b7f85220 	tbnz	x0, #63, 5c28 <fwp_hof0.constprop.0+0xcb4>
    51e8:	f90002c4 	str	x4, [x22]
    51ec:	f949db21 	ldr	x1, [x25, #5040]
    51f0:	f949ef20 	ldr	x0, [x25, #5080]
    51f4:	cb010063 	sub	x3, x3, x1
    51f8:	eb00407f 	cmp	x3, x0, lsl #16
    51fc:	540002e2 	b.cs	5258 <fwp_hof0.constprop.0+0x2e4>  // b.hs, b.nlast
    5200:	d350fc60 	lsr	x0, x3, #16
    5204:	f949ff21 	ldr	x1, [x25, #5112]
    5208:	8b000800 	add	x0, x0, x0, lsl #2
    520c:	d37df000 	lsl	x0, x0, #3
    5210:	8b000024 	add	x4, x1, x0
    5214:	f9401082 	ldr	x2, [x4, #32]
    5218:	b4000202 	cbz	x2, 5258 <fwp_hof0.constprop.0+0x2e4>
    521c:	38606820 	ldrb	w0, [x1, x0]
    5220:	7100081f 	cmp	w0, #0x2
    5224:	54003cc0 	b.eq	59bc <fwp_hof0.constprop.0+0xa48>  // b.none
    5228:	7100041f 	cmp	w0, #0x1
    522c:	54000161 	b.ne	5258 <fwp_hof0.constprop.0+0x2e4>  // b.any
    5230:	29430085 	ldp	w5, w0, [x4, #24]
    5234:	92403c61 	and	x1, x3, #0xffff
    5238:	9b057c21 	mul	x1, x1, x5
    523c:	d360fc21 	lsr	x1, x1, #32
    5240:	eb00003f 	cmp	x1, x0
    5244:	540000a2 	b.cs	5258 <fwp_hof0.constprop.0+0x2e4>  // b.hs, b.nlast
    5248:	8b010042 	add	x2, x2, x1
    524c:	39400040 	ldrb	w0, [x2]
    5250:	7100041f 	cmp	w0, #0x1
    5254:	54000ac0 	b.eq	53ac <fwp_hof0.constprop.0+0x438>  // b.none
    5258:	aa1303e0 	mov	x0, x19
    525c:	910022d6 	add	x22, x22, #0x8
    5260:	b5fff913 	cbnz	x19, 5180 <fwp_hof0.constprop.0+0x20c>
    5264:	d503201f 	nop
    5268:	d28018da 	mov	x26, #0xc6                  	// #198
    526c:	b27feff6 	mov	x22, #0x1ffffffffffffffe    	// #2305843009213693950
    5270:	97fff9ac 	bl	3920 <fwp_drop0>
    5274:	d503201f 	nop
    5278:	f9400319 	ldr	x25, [x24]
    527c:	9240fb39 	and	x25, x25, #0x7fffffffffffffff
    5280:	eb16033f 	cmp	x25, x22
    5284:	54005068 	b.hi	5c90 <fwp_hof0.constprop.0+0xd1c>  // b.pmore
    5288:	aa1903e0 	mov	x0, x25
    528c:	97fff991 	bl	38d0 <fwp_array_new_packed.constprop.0>
    5290:	9115c282 	add	x2, x20, #0x570
    5294:	aa0003f3 	mov	x19, x0
    5298:	f949d841 	ldr	x1, [x2, #5040]
    529c:	f949ec40 	ldr	x0, [x2, #5080]
    52a0:	cb010261 	sub	x1, x19, x1
    52a4:	eb00403f 	cmp	x1, x0, lsl #16
    52a8:	54000322 	b.cs	530c <fwp_hof0.constprop.0+0x398>  // b.hs, b.nlast
    52ac:	d350fc20 	lsr	x0, x1, #16
    52b0:	f949fc43 	ldr	x3, [x2, #5112]
    52b4:	8b000800 	add	x0, x0, x0, lsl #2
    52b8:	d37df002 	lsl	x2, x0, #3
    52bc:	8b020060 	add	x0, x3, x2
    52c0:	f940101b 	ldr	x27, [x0, #32]
    52c4:	b400025b 	cbz	x27, 530c <fwp_hof0.constprop.0+0x398>
    52c8:	38626862 	ldrb	w2, [x3, x2]
    52cc:	7100085f 	cmp	w2, #0x2
    52d0:	540031a0 	b.eq	5904 <fwp_hof0.constprop.0+0x990>  // b.none
    52d4:	7100045f 	cmp	w2, #0x1
    52d8:	540001a1 	b.ne	530c <fwp_hof0.constprop.0+0x398>  // b.any
    52dc:	29430002 	ldp	w2, w0, [x0, #24]
    52e0:	92403c21 	and	x1, x1, #0xffff
    52e4:	9b027c21 	mul	x1, x1, x2
    52e8:	d360fc21 	lsr	x1, x1, #32
    52ec:	eb00003f 	cmp	x1, x0
    52f0:	540000e2 	b.cs	530c <fwp_hof0.constprop.0+0x398>  // b.hs, b.nlast
    52f4:	8b01037b 	add	x27, x27, x1
    52f8:	39400360 	ldrb	w0, [x27]
    52fc:	7103fc1f 	cmp	w0, #0xff
    5300:	540030c0 	b.eq	5918 <fwp_hof0.constprop.0+0x9a4>  // b.none
    5304:	52800020 	mov	w0, #0x1                   	// #1
    5308:	39000360 	strb	w0, [x27]
    530c:	d2800103 	mov	x3, #0x8                   	// #8
    5310:	2f00e405 	movi	d5, #0x0
    5314:	8b030301 	add	x1, x24, x3
    5318:	d2800024 	mov	x4, #0x1                   	// #1
    531c:	d2800002 	mov	x2, #0x0                   	// #0
    5320:	1e6e1006 	fmov	d6, #1.000000000000000000e+00
    5324:	b4000819 	cbz	x25, 5424 <fwp_hof0.constprop.0+0x4b0>
    5328:	f9400300 	ldr	x0, [x24]
    532c:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    5330:	eb0200bf 	cmp	x5, x2
    5334:	54000349 	b.ls	539c <fwp_hof0.constprop.0+0x428>  // b.plast
    5338:	aa0103e6 	mov	x6, x1
    533c:	b7f82980 	tbnz	x0, #63, 586c <fwp_hof0.constprop.0+0x8f8>
    5340:	fc6278c3 	ldr	d3, [x6, x2, lsl #3]
    5344:	9e6703e1 	fmov	d1, xzr
    5348:	b4000242 	cbz	x2, 5390 <fwp_hof0.constprop.0+0x41c>
    534c:	8b0300c0 	add	x0, x6, x3
    5350:	fc5f0000 	ldur	d0, [x0, #-16]
    5354:	1e650801 	fmul	d1, d0, d5
    5358:	1e600802 	fmul	d2, d0, d0
    535c:	1e6038c0 	fsub	d0, d6, d0
    5360:	1e612821 	fadd	d1, d1, d1
    5364:	1e623862 	fsub	d2, d3, d2
    5368:	1e650800 	fmul	d0, d0, d5
    536c:	1e6138c1 	fsub	d1, d6, d1
    5370:	1e620844 	fmul	d4, d2, d2
    5374:	1e602800 	fadd	d0, d0, d0
    5378:	1e620821 	fmul	d1, d1, d2
    537c:	1e650882 	fmul	d2, d4, d5
    5380:	1e612821 	fadd	d1, d1, d1
    5384:	1e680821 	fmul	d1, d1, d8
    5388:	1e622821 	fadd	d1, d1, d2
    538c:	1e602821 	fadd	d1, d1, d0
    5390:	eb0400bf 	cmp	x5, x4
    5394:	54000940 	b.eq	54bc <fwp_hof0.constprop.0+0x548>  // b.none
    5398:	54000128 	b.hi	53bc <fwp_hof0.constprop.0+0x448>  // b.pmore
    539c:	f00000c0 	adrp	x0, 20000 <__data_start>
    53a0:	91004000 	add	x0, x0, #0x10
    53a4:	9100a000 	add	x0, x0, #0x28
    53a8:	97fff3b6 	bl	2280 <fwp_trap>
    53ac:	aa0603e0 	mov	x0, x6
    53b0:	97fff714 	bl	3000 <fwp_mem_free>
    53b4:	aa1303e0 	mov	x0, x19
    53b8:	17ffffa9 	b	525c <fwp_hof0.constprop.0+0x2e8>
    53bc:	fc6368c4 	ldr	d4, [x6, x3]
    53c0:	1e630867 	fmul	d7, d3, d3
    53c4:	1e632860 	fadd	d0, d3, d3
    53c8:	1e6338c2 	fsub	d2, d6, d3
    53cc:	1e673884 	fsub	d4, d4, d7
    53d0:	1e6038a0 	fsub	d0, d5, d0
    53d4:	1e614042 	fneg	d2, d2
    53d8:	1e640887 	fmul	d7, d4, d4
    53dc:	1e640800 	fmul	d0, d0, d4
    53e0:	1e622842 	fadd	d2, d2, d2
    53e4:	1e6508e4 	fmul	d4, d7, d5
    53e8:	1e602800 	fadd	d0, d0, d0
    53ec:	1e680800 	fmul	d0, d0, d8
    53f0:	1e642800 	fadd	d0, d0, d4
    53f4:	1e622800 	fadd	d0, d0, d2
    53f8:	1e612800 	fadd	d0, d0, d1
    53fc:	f9400260 	ldr	x0, [x19]
    5400:	1e690800 	fmul	d0, d0, d9
    5404:	1e603863 	fsub	d3, d3, d0
    5408:	b7f84100 	tbnz	x0, #63, 5c28 <fwp_hof0.constprop.0+0xcb4>
    540c:	91000442 	add	x2, x2, #0x1
    5410:	fc336863 	str	d3, [x3, x19]
    5414:	91000484 	add	x4, x4, #0x1
    5418:	91002063 	add	x3, x3, #0x8
    541c:	eb02033f 	cmp	x25, x2
    5420:	54fff841 	b.ne	5328 <fwp_hof0.constprop.0+0x3b4>  // b.any
    5424:	9115c299 	add	x25, x20, #0x570
    5428:	f949db21 	ldr	x1, [x25, #5040]
    542c:	f949ef20 	ldr	x0, [x25, #5080]
    5430:	cb010301 	sub	x1, x24, x1
    5434:	eb00403f 	cmp	x1, x0, lsl #16
    5438:	54000382 	b.cs	54a8 <fwp_hof0.constprop.0+0x534>  // b.hs, b.nlast
    543c:	d350fc20 	lsr	x0, x1, #16
    5440:	f949ff24 	ldr	x4, [x25, #5112]
    5444:	8b000800 	add	x0, x0, x0, lsl #2
    5448:	d37df000 	lsl	x0, x0, #3
    544c:	8b000082 	add	x2, x4, x0
    5450:	f940105b 	ldr	x27, [x2, #32]
    5454:	b40002bb 	cbz	x27, 54a8 <fwp_hof0.constprop.0+0x534>
    5458:	38606880 	ldrb	w0, [x4, x0]
    545c:	7100081f 	cmp	w0, #0x2
    5460:	540020a0 	b.eq	5874 <fwp_hof0.constprop.0+0x900>  // b.none
    5464:	7100041f 	cmp	w0, #0x1
    5468:	54000201 	b.ne	54a8 <fwp_hof0.constprop.0+0x534>  // b.any
    546c:	29430043 	ldp	w3, w0, [x2, #24]
    5470:	92403c21 	and	x1, x1, #0xffff
    5474:	9b037c21 	mul	x1, x1, x3
    5478:	d360fc21 	lsr	x1, x1, #32
    547c:	eb00003f 	cmp	x1, x0
    5480:	54000142 	b.cs	54a8 <fwp_hof0.constprop.0+0x534>  // b.hs, b.nlast
    5484:	8b01037b 	add	x27, x27, x1
    5488:	39400360 	ldrb	w0, [x27]
    548c:	340000e0 	cbz	w0, 54a8 <fwp_hof0.constprop.0+0x534>
    5490:	7100041f 	cmp	w0, #0x1
    5494:	54000180 	b.eq	54c4 <fwp_hof0.constprop.0+0x550>  // b.none
    5498:	7103fc1f 	cmp	w0, #0xff
    549c:	54002e20 	b.eq	5a60 <fwp_hof0.constprop.0+0xaec>  // b.none
    54a0:	51000400 	sub	w0, w0, #0x1
    54a4:	39000360 	strb	w0, [x27]
    54a8:	b400051a 	cbz	x26, 5548 <fwp_hof0.constprop.0+0x5d4>
    54ac:	f100075a 	subs	x26, x26, #0x1
    54b0:	54004146 	b.vs	5cd8 <fwp_hof0.constprop.0+0xd64>
    54b4:	aa1303f8 	mov	x24, x19
    54b8:	17ffff70 	b	5278 <fwp_hof0.constprop.0+0x304>
    54bc:	2f00e400 	movi	d0, #0x0
    54c0:	17ffffce 	b	53f8 <fwp_hof0.constprop.0+0x484>
    54c4:	f9400305 	ldr	x5, [x24]
    54c8:	aa1803e0 	mov	x0, x24
    54cc:	f949ef23 	ldr	x3, [x25, #5080]
    54d0:	f949db21 	ldr	x1, [x25, #5040]
    54d4:	d370bc63 	lsl	x3, x3, #16
    54d8:	cb010302 	sub	x2, x24, x1
    54dc:	b7f81d25 	tbnz	x5, #63, 5880 <fwp_hof0.constprop.0+0x90c>
    54e0:	eb02007f 	cmp	x3, x2
    54e4:	54fffe29 	b.ls	54a8 <fwp_hof0.constprop.0+0x534>  // b.plast
    54e8:	d350fc40 	lsr	x0, x2, #16
    54ec:	8b000800 	add	x0, x0, x0, lsl #2
    54f0:	d37df000 	lsl	x0, x0, #3
    54f4:	8b000083 	add	x3, x4, x0
    54f8:	f9401061 	ldr	x1, [x3, #32]
    54fc:	b4fffd61 	cbz	x1, 54a8 <fwp_hof0.constprop.0+0x534>
    5500:	38606880 	ldrb	w0, [x4, x0]
    5504:	7100081f 	cmp	w0, #0x2
    5508:	540020e0 	b.eq	5924 <fwp_hof0.constprop.0+0x9b0>  // b.none
    550c:	7100041f 	cmp	w0, #0x1
    5510:	54fffcc1 	b.ne	54a8 <fwp_hof0.constprop.0+0x534>  // b.any
    5514:	92403c40 	and	x0, x2, #0xffff
    5518:	29430864 	ldp	w4, w2, [x3, #24]
    551c:	9b047c00 	mul	x0, x0, x4
    5520:	d360fc00 	lsr	x0, x0, #32
    5524:	eb02001f 	cmp	x0, x2
    5528:	54fffc02 	b.cs	54a8 <fwp_hof0.constprop.0+0x534>  // b.hs, b.nlast
    552c:	8b000021 	add	x1, x1, x0
    5530:	39400020 	ldrb	w0, [x1]
    5534:	7100041f 	cmp	w0, #0x1
    5538:	54fffb81 	b.ne	54a8 <fwp_hof0.constprop.0+0x534>  // b.any
    553c:	aa1803e0 	mov	x0, x24
    5540:	97fff6b0 	bl	3000 <fwp_mem_free>
    5544:	b5fffb5a 	cbnz	x26, 54ac <fwp_hof0.constprop.0+0x538>
    5548:	52800b63 	mov	w3, #0x5b                  	// #91
    554c:	91007ffc 	add	x28, sp, #0x1f
    5550:	910083f6 	add	x22, sp, #0x20
    5554:	aa1c03e1 	mov	x1, x28
    5558:	aa1603e0 	mov	x0, x22
    555c:	d2800022 	mov	x2, #0x1                   	// #1
    5560:	39007fe3 	strb	w3, [sp, #31]
    5564:	d2800017 	mov	x23, #0x0                   	// #0
    5568:	a9027fff 	stp	xzr, xzr, [sp, #32]
    556c:	d00000d8 	adrp	x24, 1f000 <__FRAME_END__+0x14da0>
    5570:	f9001bff 	str	xzr, [sp, #48]
    5574:	97fff2e7 	bl	2110 <buf_put>
    5578:	f9400260 	ldr	x0, [x19]
    557c:	f240f81a 	ands	x26, x0, #0x7fffffffffffffff
    5580:	540003c0 	b.eq	55f8 <fwp_hof0.constprop.0+0x684>  // b.none
    5584:	912ca318 	add	x24, x24, #0xb28
    5588:	90000039 	adrp	x25, 9000 <_IO_stdin_used+0x1e0>
    558c:	91014318 	add	x24, x24, #0x50
    5590:	91072339 	add	x25, x25, #0x1c8
    5594:	9100227b 	add	x27, x19, #0x8
    5598:	1400000d 	b	55cc <fwp_hof0.constprop.0+0x658>
    559c:	f8777821 	ldr	x1, [x1, x23, lsl #3]
    55a0:	aa1803e2 	mov	x2, x24
    55a4:	aa1603e0 	mov	x0, x22
    55a8:	910006f7 	add	x23, x23, #0x1
    55ac:	97fffa89 	bl	3fd0 <fwp_write.constprop.0>
    55b0:	eb17035f 	cmp	x26, x23
    55b4:	54000220 	b.eq	55f8 <fwp_hof0.constprop.0+0x684>  // b.none
    55b8:	aa1603e0 	mov	x0, x22
    55bc:	aa1903e1 	mov	x1, x25
    55c0:	d2800042 	mov	x2, #0x2                   	// #2
    55c4:	97fff2d3 	bl	2110 <buf_put>
    55c8:	f9400260 	ldr	x0, [x19]
    55cc:	aa1b03e1 	mov	x1, x27
    55d0:	b6fffe60 	tbz	x0, #63, 559c <fwp_hof0.constprop.0+0x628>
    55d4:	f9400a61 	ldr	x1, [x19, #16]
    55d8:	aa1803e2 	mov	x2, x24
    55dc:	aa1603e0 	mov	x0, x22
    55e0:	f8777821 	ldr	x1, [x1, x23, lsl #3]
    55e4:	910006f7 	add	x23, x23, #0x1
    55e8:	97fffa7a 	bl	3fd0 <fwp_write.constprop.0>
    55ec:	eb17035f 	cmp	x26, x23
    55f0:	54fffe41 	b.ne	55b8 <fwp_hof0.constprop.0+0x644>  // b.any
    55f4:	d503201f 	nop
    55f8:	52800ba3 	mov	w3, #0x5d                  	// #93
    55fc:	aa1603e0 	mov	x0, x22
    5600:	aa1c03e1 	mov	x1, x28
    5604:	d2800022 	mov	x2, #0x1                   	// #1
    5608:	39007fe3 	strb	w3, [sp, #31]
    560c:	97fff2c1 	bl	2110 <buf_put>
    5610:	a94263f9 	ldp	x25, x24, [sp, #32]
    5614:	f0000000 	adrp	x0, 8000 <f0+0x2320>
    5618:	91398000 	add	x0, x0, #0xe60
    561c:	f100033f 	cmp	x25, #0x0
    5620:	9a990019 	csel	x25, x0, x25, eq	// eq = none
    5624:	b1002b1f 	cmn	x24, #0xa
    5628:	54003528 	b.hi	5ccc <fwp_hof0.constprop.0+0xd58>  // b.pmore
    562c:	91002700 	add	x0, x24, #0x9
    5630:	52800021 	mov	w1, #0x1                   	// #1
    5634:	97fff7e4 	bl	35c4 <fwp_heap_alloc>
    5638:	aa0003f6 	mov	x22, x0
    563c:	aa1903e1 	mov	x1, x25
    5640:	aa0003f9 	mov	x25, x0
    5644:	aa1803e2 	mov	x2, x24
    5648:	f8008738 	str	x24, [x25], #8
    564c:	8b1802d8 	add	x24, x22, x24
    5650:	aa1903e0 	mov	x0, x25
    5654:	97ffef43 	bl	1360 <memcpy@plt>
    5658:	f94013e0 	ldr	x0, [sp, #32]
    565c:	3900231f 	strb	wzr, [x24, #8]
    5660:	97ffefd8 	bl	15c0 <free@plt>
    5664:	9115c282 	add	x2, x20, #0x570
    5668:	f949ec43 	ldr	x3, [x2, #5080]
    566c:	f949d841 	ldr	x1, [x2, #5040]
    5670:	d370bc63 	lsl	x3, x3, #16
    5674:	cb0102c4 	sub	x4, x22, x1
    5678:	eb03009f 	cmp	x4, x3
    567c:	540003a2 	b.cs	56f0 <fwp_hof0.constprop.0+0x77c>  // b.hs, b.nlast
    5680:	d350fc80 	lsr	x0, x4, #16
    5684:	f949fc45 	ldr	x5, [x2, #5112]
    5688:	8b000800 	add	x0, x0, x0, lsl #2
    568c:	d37df002 	lsl	x2, x0, #3
    5690:	8b0200a0 	add	x0, x5, x2
    5694:	f9401018 	ldr	x24, [x0, #32]
    5698:	b40002d8 	cbz	x24, 56f0 <fwp_hof0.constprop.0+0x77c>
    569c:	386268a2 	ldrb	w2, [x5, x2]
    56a0:	7100085f 	cmp	w2, #0x2
    56a4:	540020a0 	b.eq	5ab8 <fwp_hof0.constprop.0+0xb44>  // b.none
    56a8:	7100045f 	cmp	w2, #0x1
    56ac:	54000221 	b.ne	56f0 <fwp_hof0.constprop.0+0x77c>  // b.any
    56b0:	29430005 	ldp	w5, w0, [x0, #24]
    56b4:	92403c82 	and	x2, x4, #0xffff
    56b8:	9b057c42 	mul	x2, x2, x5
    56bc:	d360fc42 	lsr	x2, x2, #32
    56c0:	eb00005f 	cmp	x2, x0
    56c4:	54000162 	b.cs	56f0 <fwp_hof0.constprop.0+0x77c>  // b.hs, b.nlast
    56c8:	8b020318 	add	x24, x24, x2
    56cc:	39400300 	ldrb	w0, [x24]
    56d0:	7103fc1f 	cmp	w0, #0xff
    56d4:	54001fc0 	b.eq	5acc <fwp_hof0.constprop.0+0xb58>  // b.none
    56d8:	9115c280 	add	x0, x20, #0x570
    56dc:	52800021 	mov	w1, #0x1                   	// #1
    56e0:	39000301 	strb	w1, [x24]
    56e4:	f949ec03 	ldr	x3, [x0, #5080]
    56e8:	f949d801 	ldr	x1, [x0, #5040]
    56ec:	d370bc63 	lsl	x3, x3, #16
    56f0:	cb010261 	sub	x1, x19, x1
    56f4:	9115c29a 	add	x26, x20, #0x570
    56f8:	eb01007f 	cmp	x3, x1
    56fc:	540003a9 	b.ls	5770 <fwp_hof0.constprop.0+0x7fc>  // b.plast
    5700:	d350fc20 	lsr	x0, x1, #16
    5704:	f949ff43 	ldr	x3, [x26, #5112]
    5708:	8b000800 	add	x0, x0, x0, lsl #2
    570c:	d37df002 	lsl	x2, x0, #3
    5710:	8b020060 	add	x0, x3, x2
    5714:	f9401018 	ldr	x24, [x0, #32]
    5718:	b40002d8 	cbz	x24, 5770 <fwp_hof0.constprop.0+0x7fc>
    571c:	38626862 	ldrb	w2, [x3, x2]
    5720:	7100085f 	cmp	w2, #0x2
    5724:	54001540 	b.eq	59cc <fwp_hof0.constprop.0+0xa58>  // b.none
    5728:	7100045f 	cmp	w2, #0x1
    572c:	54000221 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    5730:	29430002 	ldp	w2, w0, [x0, #24]
    5734:	92403c21 	and	x1, x1, #0xffff
    5738:	9b027c21 	mul	x1, x1, x2
    573c:	d360fc21 	lsr	x1, x1, #32
    5740:	eb00003f 	cmp	x1, x0
    5744:	54000162 	b.cs	5770 <fwp_hof0.constprop.0+0x7fc>  // b.hs, b.nlast
    5748:	8b010318 	add	x24, x24, x1
    574c:	39400300 	ldrb	w0, [x24]
    5750:	34000100 	cbz	w0, 5770 <fwp_hof0.constprop.0+0x7fc>
    5754:	7100041f 	cmp	w0, #0x1
    5758:	54000ec0 	b.eq	5930 <fwp_hof0.constprop.0+0x9bc>  // b.none
    575c:	7103fc1f 	cmp	w0, #0xff
    5760:	54001d40 	b.eq	5b08 <fwp_hof0.constprop.0+0xb94>  // b.none
    5764:	51000400 	sub	w0, w0, #0x1
    5768:	39000300 	strb	w0, [x24]
    576c:	d503201f 	nop
    5770:	f00000d3 	adrp	x19, 20000 <__data_start>
    5774:	d2800021 	mov	x1, #0x1                   	// #1
    5778:	f94002c2 	ldr	x2, [x22]
    577c:	aa1903e0 	mov	x0, x25
    5780:	f9404a63 	ldr	x3, [x19, #144]
    5784:	97ffef9f 	bl	1600 <fwrite@plt>
    5788:	f9404a61 	ldr	x1, [x19, #144]
    578c:	52800140 	mov	w0, #0xa                   	// #10
    5790:	97ffef24 	bl	1420 <fputc@plt>
    5794:	9115c282 	add	x2, x20, #0x570
    5798:	f949d841 	ldr	x1, [x2, #5040]
    579c:	f949ec40 	ldr	x0, [x2, #5080]
    57a0:	cb0102c1 	sub	x1, x22, x1
    57a4:	eb00403f 	cmp	x1, x0, lsl #16
    57a8:	54000382 	b.cs	5818 <fwp_hof0.constprop.0+0x8a4>  // b.hs, b.nlast
    57ac:	d350fc20 	lsr	x0, x1, #16
    57b0:	f949fc43 	ldr	x3, [x2, #5112]
    57b4:	8b000800 	add	x0, x0, x0, lsl #2
    57b8:	d37df002 	lsl	x2, x0, #3
    57bc:	8b020060 	add	x0, x3, x2
    57c0:	f9401013 	ldr	x19, [x0, #32]
    57c4:	b40002b3 	cbz	x19, 5818 <fwp_hof0.constprop.0+0x8a4>
    57c8:	38626862 	ldrb	w2, [x3, x2]
    57cc:	7100085f 	cmp	w2, #0x2
    57d0:	54001840 	b.eq	5ad8 <fwp_hof0.constprop.0+0xb64>  // b.none
    57d4:	7100045f 	cmp	w2, #0x1
    57d8:	54000201 	b.ne	5818 <fwp_hof0.constprop.0+0x8a4>  // b.any
    57dc:	29430002 	ldp	w2, w0, [x0, #24]
    57e0:	92403c21 	and	x1, x1, #0xffff
    57e4:	9b027c21 	mul	x1, x1, x2
    57e8:	d360fc21 	lsr	x1, x1, #32
    57ec:	eb00003f 	cmp	x1, x0
    57f0:	54000142 	b.cs	5818 <fwp_hof0.constprop.0+0x8a4>  // b.hs, b.nlast
    57f4:	8b010273 	add	x19, x19, x1
    57f8:	39400260 	ldrb	w0, [x19]
    57fc:	340000e0 	cbz	w0, 5818 <fwp_hof0.constprop.0+0x8a4>
    5800:	7100041f 	cmp	w0, #0x1
    5804:	54001760 	b.eq	5af0 <fwp_hof0.constprop.0+0xb7c>  // b.none
    5808:	7103fc1f 	cmp	w0, #0xff
    580c:	54001e20 	b.eq	5bd0 <fwp_hof0.constprop.0+0xc5c>  // b.none
    5810:	51000400 	sub	w0, w0, #0x1
    5814:	39000260 	strb	w0, [x19]
    5818:	f94007e0 	ldr	x0, [sp, #8]
    581c:	f9400800 	ldr	x0, [x0, #16]
    5820:	f90007e0 	str	x0, [sp, #8]
    5824:	b5ffbd60 	cbnz	x0, 4fd0 <fwp_hof0.constprop.0+0x5c>
    5828:	a94553f3 	ldp	x19, x20, [sp, #80]
    582c:	a94763f7 	ldp	x23, x24, [sp, #112]
    5830:	a9486bf9 	ldp	x25, x26, [sp, #128]
    5834:	a94973fb 	ldp	x27, x28, [sp, #144]
    5838:	6d4a27e8 	ldp	d8, d9, [sp, #160]
    583c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    5840:	f947f400 	ldr	x0, [x0, #4072]
    5844:	f9401fe2 	ldr	x2, [sp, #56]
    5848:	f9400001 	ldr	x1, [x0]
    584c:	eb010042 	subs	x2, x2, x1
    5850:	d2800001 	mov	x1, #0x0                   	// #0
    5854:	54002301 	b.ne	5cb4 <fwp_hof0.constprop.0+0xd40>  // b.any
    5858:	a9447bfd 	ldp	x29, x30, [sp, #64]
    585c:	d2800000 	mov	x0, #0x0                   	// #0
    5860:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5864:	9102c3ff 	add	sp, sp, #0xb0
    5868:	d65f03c0 	ret
    586c:	f9400b06 	ldr	x6, [x24, #16]
    5870:	17fffeb4 	b	5340 <fwp_hof0.constprop.0+0x3cc>
    5874:	72003c3f 	tst	w1, #0xffff
    5878:	54ffe181 	b.ne	54a8 <fwp_hof0.constprop.0+0x534>  // b.any
    587c:	17ffff03 	b	5488 <fwp_hof0.constprop.0+0x514>
    5880:	f9400718 	ldr	x24, [x24, #8]
    5884:	eb02007f 	cmp	x3, x2
    5888:	54000369 	b.ls	58f4 <fwp_hof0.constprop.0+0x980>  // b.plast
    588c:	d350fc45 	lsr	x5, x2, #16
    5890:	8b0508a5 	add	x5, x5, x5, lsl #2
    5894:	d37df0a5 	lsl	x5, x5, #3
    5898:	8b050087 	add	x7, x4, x5
    589c:	f94010e6 	ldr	x6, [x7, #32]
    58a0:	b40002a6 	cbz	x6, 58f4 <fwp_hof0.constprop.0+0x980>
    58a4:	38656884 	ldrb	w4, [x4, x5]
    58a8:	7100089f 	cmp	w4, #0x2
    58ac:	54000820 	b.eq	59b0 <fwp_hof0.constprop.0+0xa3c>  // b.none
    58b0:	7100049f 	cmp	w4, #0x1
    58b4:	54000201 	b.ne	58f4 <fwp_hof0.constprop.0+0x980>  // b.any
    58b8:	294310e5 	ldp	w5, w4, [x7, #24]
    58bc:	92403c42 	and	x2, x2, #0xffff
    58c0:	9b057c42 	mul	x2, x2, x5
    58c4:	d360fc42 	lsr	x2, x2, #32
    58c8:	eb04005f 	cmp	x2, x4
    58cc:	54000142 	b.cs	58f4 <fwp_hof0.constprop.0+0x980>  // b.hs, b.nlast
    58d0:	8b0200c6 	add	x6, x6, x2
    58d4:	394000c2 	ldrb	w2, [x6]
    58d8:	7100045f 	cmp	w2, #0x1
    58dc:	540000c1 	b.ne	58f4 <fwp_hof0.constprop.0+0x980>  // b.any
    58e0:	97fff5c8 	bl	3000 <fwp_mem_free>
    58e4:	9115c280 	add	x0, x20, #0x570
    58e8:	f949ec03 	ldr	x3, [x0, #5080]
    58ec:	f949d801 	ldr	x1, [x0, #5040]
    58f0:	d370bc63 	lsl	x3, x3, #16
    58f4:	cb010301 	sub	x1, x24, x1
    58f8:	eb03003f 	cmp	x1, x3
    58fc:	54ffda03 	b.cc	543c <fwp_hof0.constprop.0+0x4c8>  // b.lo, b.ul, b.last
    5900:	17fffeea 	b	54a8 <fwp_hof0.constprop.0+0x534>
    5904:	72003c3f 	tst	w1, #0xffff
    5908:	54ffd021 	b.ne	530c <fwp_hof0.constprop.0+0x398>  // b.any
    590c:	39400360 	ldrb	w0, [x27]
    5910:	7103fc1f 	cmp	w0, #0xff
    5914:	54ffcf81 	b.ne	5304 <fwp_hof0.constprop.0+0x390>  // b.any
    5918:	aa1b03e0 	mov	x0, x27
    591c:	97fff51a 	bl	2d84 <fwp_rc_forget_slot>
    5920:	17fffe79 	b	5304 <fwp_hof0.constprop.0+0x390>
    5924:	72003c5f 	tst	w2, #0xffff
    5928:	54ffdc01 	b.ne	54a8 <fwp_hof0.constprop.0+0x534>  // b.any
    592c:	17ffff01 	b	5530 <fwp_hof0.constprop.0+0x5bc>
    5930:	f9400260 	ldr	x0, [x19]
    5934:	b7f80520 	tbnz	x0, #63, 59d8 <fwp_hof0.constprop.0+0xa64>
    5938:	9115c281 	add	x1, x20, #0x570
    593c:	f949d820 	ldr	x0, [x1, #5040]
    5940:	f949ec21 	ldr	x1, [x1, #5080]
    5944:	cb000260 	sub	x0, x19, x0
    5948:	eb01401f 	cmp	x0, x1, lsl #16
    594c:	54fff122 	b.cs	5770 <fwp_hof0.constprop.0+0x7fc>  // b.hs, b.nlast
    5950:	d350fc01 	lsr	x1, x0, #16
    5954:	8b010821 	add	x1, x1, x1, lsl #2
    5958:	d37df021 	lsl	x1, x1, #3
    595c:	8b010064 	add	x4, x3, x1
    5960:	f9401082 	ldr	x2, [x4, #32]
    5964:	b4fff062 	cbz	x2, 5770 <fwp_hof0.constprop.0+0x7fc>
    5968:	38616861 	ldrb	w1, [x3, x1]
    596c:	7100083f 	cmp	w1, #0x2
    5970:	54000c60 	b.eq	5afc <fwp_hof0.constprop.0+0xb88>  // b.none
    5974:	7100043f 	cmp	w1, #0x1
    5978:	54ffefc1 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    597c:	29430483 	ldp	w3, w1, [x4, #24]
    5980:	92403c00 	and	x0, x0, #0xffff
    5984:	9b037c00 	mul	x0, x0, x3
    5988:	d360fc00 	lsr	x0, x0, #32
    598c:	eb01001f 	cmp	x0, x1
    5990:	54ffef02 	b.cs	5770 <fwp_hof0.constprop.0+0x7fc>  // b.hs, b.nlast
    5994:	8b000042 	add	x2, x2, x0
    5998:	39400040 	ldrb	w0, [x2]
    599c:	7100041f 	cmp	w0, #0x1
    59a0:	54ffee81 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    59a4:	aa1303e0 	mov	x0, x19
    59a8:	97fff596 	bl	3000 <fwp_mem_free>
    59ac:	17ffff71 	b	5770 <fwp_hof0.constprop.0+0x7fc>
    59b0:	72003c5f 	tst	w2, #0xffff
    59b4:	54fffa01 	b.ne	58f4 <fwp_hof0.constprop.0+0x980>  // b.any
    59b8:	17ffffc7 	b	58d4 <fwp_hof0.constprop.0+0x960>
    59bc:	72003c7f 	tst	w3, #0xffff
    59c0:	54ffc460 	b.eq	524c <fwp_hof0.constprop.0+0x2d8>  // b.none
    59c4:	aa1303e0 	mov	x0, x19
    59c8:	17fffe25 	b	525c <fwp_hof0.constprop.0+0x2e8>
    59cc:	72003c3f 	tst	w1, #0xffff
    59d0:	54ffed01 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    59d4:	17ffff5e 	b	574c <fwp_hof0.constprop.0+0x7d8>
    59d8:	f9400678 	ldr	x24, [x19, #8]
    59dc:	aa1303e0 	mov	x0, x19
    59e0:	97fff6d8 	bl	3540 <fwp_rc_free_arr>
    59e4:	9115c280 	add	x0, x20, #0x570
    59e8:	f949d801 	ldr	x1, [x0, #5040]
    59ec:	f949ec00 	ldr	x0, [x0, #5080]
    59f0:	cb010301 	sub	x1, x24, x1
    59f4:	eb00403f 	cmp	x1, x0, lsl #16
    59f8:	54ffebc2 	b.cs	5770 <fwp_hof0.constprop.0+0x7fc>  // b.hs, b.nlast
    59fc:	aa1803f3 	mov	x19, x24
    5a00:	17ffff40 	b	5700 <fwp_hof0.constprop.0+0x78c>
    5a04:	72003c1f 	tst	w0, #0xffff
    5a08:	54ffb160 	b.eq	5034 <fwp_hof0.constprop.0+0xc0>  // b.none
    5a0c:	b5ffb315 	cbnz	x21, 506c <fwp_hof0.constprop.0+0xf8>
    5a10:	d2800000 	mov	x0, #0x0                   	// #0
    5a14:	97fff7af 	bl	38d0 <fwp_array_new_packed.constprop.0>
    5a18:	9115c281 	add	x1, x20, #0x570
    5a1c:	aa0003f8 	mov	x24, x0
    5a20:	aa0103e0 	mov	x0, x1
    5a24:	f949d821 	ldr	x1, [x1, #5040]
    5a28:	f949ec00 	ldr	x0, [x0, #5080]
    5a2c:	cb010301 	sub	x1, x24, x1
    5a30:	eb00403f 	cmp	x1, x0, lsl #16
    5a34:	54ffb403 	b.cc	50b4 <fwp_hof0.constprop.0+0x140>  // b.lo, b.ul, b.last
    5a38:	d2800000 	mov	x0, #0x0                   	// #0
    5a3c:	17fffe0b 	b	5268 <fwp_hof0.constprop.0+0x2f4>
    5a40:	72003c3f 	tst	w1, #0xffff
    5a44:	54ffb6a1 	b.ne	5118 <fwp_hof0.constprop.0+0x1a4>  // b.any
    5a48:	39400260 	ldrb	w0, [x19]
    5a4c:	7103fc1f 	cmp	w0, #0xff
    5a50:	54ffb601 	b.ne	5110 <fwp_hof0.constprop.0+0x19c>  // b.any
    5a54:	aa1303e0 	mov	x0, x19
    5a58:	97fff4cb 	bl	2d84 <fwp_rc_forget_slot>
    5a5c:	17fffdad 	b	5110 <fwp_hof0.constprop.0+0x19c>
    5a60:	ca5b4760 	eor	x0, x27, x27, lsr #17
    5a64:	9115c281 	add	x1, x20, #0x570
    5a68:	ca402400 	eor	x0, x0, x0, lsr #9
    5a6c:	8b200c20 	add	x0, x1, w0, uxtb #3
    5a70:	f94a2400 	ldr	x0, [x0, #5192]
    5a74:	b5000080 	cbnz	x0, 5a84 <fwp_hof0.constprop.0+0xb10>
    5a78:	14000071 	b	5c3c <fwp_hof0.constprop.0+0xcc8>
    5a7c:	f9400800 	ldr	x0, [x0, #16]
    5a80:	b4000de0 	cbz	x0, 5c3c <fwp_hof0.constprop.0+0xcc8>
    5a84:	f9400001 	ldr	x1, [x0]
    5a88:	eb01037f 	cmp	x27, x1
    5a8c:	54ffff81 	b.ne	5a7c <fwp_hof0.constprop.0+0xb08>  // b.any
    5a90:	f9400401 	ldr	x1, [x0, #8]
    5a94:	d1000421 	sub	x1, x1, #0x1
    5a98:	f9000401 	str	x1, [x0, #8]
    5a9c:	f103f83f 	cmp	x1, #0xfe
    5aa0:	54ffd041 	b.ne	54a8 <fwp_hof0.constprop.0+0x534>  // b.any
    5aa4:	aa1b03e0 	mov	x0, x27
    5aa8:	97fff4b7 	bl	2d84 <fwp_rc_forget_slot>
    5aac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ab0:	39000360 	strb	w0, [x27]
    5ab4:	17fffe7d 	b	54a8 <fwp_hof0.constprop.0+0x534>
    5ab8:	72003c9f 	tst	w4, #0xffff
    5abc:	54ffe1a1 	b.ne	56f0 <fwp_hof0.constprop.0+0x77c>  // b.any
    5ac0:	39400300 	ldrb	w0, [x24]
    5ac4:	7103fc1f 	cmp	w0, #0xff
    5ac8:	54ffe081 	b.ne	56d8 <fwp_hof0.constprop.0+0x764>  // b.any
    5acc:	aa1803e0 	mov	x0, x24
    5ad0:	97fff4ad 	bl	2d84 <fwp_rc_forget_slot>
    5ad4:	17ffff01 	b	56d8 <fwp_hof0.constprop.0+0x764>
    5ad8:	72003c3f 	tst	w1, #0xffff
    5adc:	54ffe9e1 	b.ne	5818 <fwp_hof0.constprop.0+0x8a4>  // b.any
    5ae0:	39400260 	ldrb	w0, [x19]
    5ae4:	34ffe9a0 	cbz	w0, 5818 <fwp_hof0.constprop.0+0x8a4>
    5ae8:	7100041f 	cmp	w0, #0x1
    5aec:	54ffe8e1 	b.ne	5808 <fwp_hof0.constprop.0+0x894>  // b.any
    5af0:	aa1603e0 	mov	x0, x22
    5af4:	97fff543 	bl	3000 <fwp_mem_free>
    5af8:	17ffff48 	b	5818 <fwp_hof0.constprop.0+0x8a4>
    5afc:	72003c1f 	tst	w0, #0xffff
    5b00:	54ffe381 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    5b04:	17ffffa5 	b	5998 <fwp_hof0.constprop.0+0xa24>
    5b08:	ca584700 	eor	x0, x24, x24, lsr #17
    5b0c:	9115c281 	add	x1, x20, #0x570
    5b10:	ca402400 	eor	x0, x0, x0, lsr #9
    5b14:	8b200c20 	add	x0, x1, w0, uxtb #3
    5b18:	f94a2400 	ldr	x0, [x0, #5192]
    5b1c:	b4000900 	cbz	x0, 5c3c <fwp_hof0.constprop.0+0xcc8>
    5b20:	f9400001 	ldr	x1, [x0]
    5b24:	eb01031f 	cmp	x24, x1
    5b28:	540000c0 	b.eq	5b40 <fwp_hof0.constprop.0+0xbcc>  // b.none
    5b2c:	f9400800 	ldr	x0, [x0, #16]
    5b30:	b4000860 	cbz	x0, 5c3c <fwp_hof0.constprop.0+0xcc8>
    5b34:	f9400001 	ldr	x1, [x0]
    5b38:	eb01031f 	cmp	x24, x1
    5b3c:	54ffff81 	b.ne	5b2c <fwp_hof0.constprop.0+0xbb8>  // b.any
    5b40:	f9400401 	ldr	x1, [x0, #8]
    5b44:	d1000421 	sub	x1, x1, #0x1
    5b48:	f9000401 	str	x1, [x0, #8]
    5b4c:	f103f83f 	cmp	x1, #0xfe
    5b50:	54ffe101 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    5b54:	aa1803e0 	mov	x0, x24
    5b58:	97fff48b 	bl	2d84 <fwp_rc_forget_slot>
    5b5c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b60:	39000300 	strb	w0, [x24]
    5b64:	17ffff03 	b	5770 <fwp_hof0.constprop.0+0x7fc>
    5b68:	ca534661 	eor	x1, x19, x19, lsr #17
    5b6c:	9115c282 	add	x2, x20, #0x570
    5b70:	ca412421 	eor	x1, x1, x1, lsr #9
    5b74:	92401c21 	and	x1, x1, #0xff
    5b78:	910a2423 	add	x3, x1, #0x289
    5b7c:	8b010c41 	add	x1, x2, x1, lsl #3
    5b80:	8b030c56 	add	x22, x2, x3, lsl #3
    5b84:	f94a2421 	ldr	x1, [x1, #5192]
    5b88:	b50000a1 	cbnz	x1, 5b9c <fwp_hof0.constprop.0+0xc28>
    5b8c:	14000047 	b	5ca8 <fwp_hof0.constprop.0+0xd34>
    5b90:	91004036 	add	x22, x1, #0x10
    5b94:	f9400821 	ldr	x1, [x1, #16]
    5b98:	b40004e1 	cbz	x1, 5c34 <fwp_hof0.constprop.0+0xcc0>
    5b9c:	f9400022 	ldr	x2, [x1]
    5ba0:	eb13005f 	cmp	x2, x19
    5ba4:	54ffff61 	b.ne	5b90 <fwp_hof0.constprop.0+0xc1c>  // b.any
    5ba8:	f94002c1 	ldr	x1, [x22]
    5bac:	7103f81f 	cmp	w0, #0xfe
    5bb0:	54000680 	b.eq	5c80 <fwp_hof0.constprop.0+0xd0c>  // b.none
    5bb4:	b4000441 	cbz	x1, 5c3c <fwp_hof0.constprop.0+0xcc8>
    5bb8:	f9400420 	ldr	x0, [x1, #8]
    5bbc:	b100041f 	cmn	x0, #0x1
    5bc0:	540006e0 	b.eq	5c9c <fwp_hof0.constprop.0+0xd28>  // b.none
    5bc4:	91000400 	add	x0, x0, #0x1
    5bc8:	f9000420 	str	x0, [x1, #8]
    5bcc:	17fffd27 	b	5068 <fwp_hof0.constprop.0+0xf4>
    5bd0:	ca534660 	eor	x0, x19, x19, lsr #17
    5bd4:	9115c281 	add	x1, x20, #0x570
    5bd8:	ca402400 	eor	x0, x0, x0, lsr #9
    5bdc:	8b200c20 	add	x0, x1, w0, uxtb #3
    5be0:	f94a2400 	ldr	x0, [x0, #5192]
    5be4:	b5000080 	cbnz	x0, 5bf4 <fwp_hof0.constprop.0+0xc80>
    5be8:	14000015 	b	5c3c <fwp_hof0.constprop.0+0xcc8>
    5bec:	f9400800 	ldr	x0, [x0, #16]
    5bf0:	b4000260 	cbz	x0, 5c3c <fwp_hof0.constprop.0+0xcc8>
    5bf4:	f9400001 	ldr	x1, [x0]
    5bf8:	eb13003f 	cmp	x1, x19
    5bfc:	54ffff81 	b.ne	5bec <fwp_hof0.constprop.0+0xc78>  // b.any
    5c00:	f9400401 	ldr	x1, [x0, #8]
    5c04:	d1000421 	sub	x1, x1, #0x1
    5c08:	f9000401 	str	x1, [x0, #8]
    5c0c:	f103f83f 	cmp	x1, #0xfe
    5c10:	54ffe041 	b.ne	5818 <fwp_hof0.constprop.0+0x8a4>  // b.any
    5c14:	aa1303e0 	mov	x0, x19
    5c18:	97fff45b 	bl	2d84 <fwp_rc_forget_slot>
    5c1c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c20:	39000260 	strb	w0, [x19]
    5c24:	17fffefd 	b	5818 <fwp_hof0.constprop.0+0x8a4>
    5c28:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    5c2c:	91096000 	add	x0, x0, #0x258
    5c30:	97fff194 	bl	2280 <fwp_trap>
    5c34:	7103f81f 	cmp	w0, #0xfe
    5c38:	54000080 	b.eq	5c48 <fwp_hof0.constprop.0+0xcd4>  // b.none
    5c3c:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    5c40:	91036000 	add	x0, x0, #0xd8
    5c44:	97fff18f 	bl	2280 <fwp_trap>
    5c48:	d2800300 	mov	x0, #0x18                  	// #24
    5c4c:	97ffee15 	bl	14a0 <malloc@plt>
    5c50:	b4000300 	cbz	x0, 5cb0 <fwp_hof0.constprop.0+0xd3c>
    5c54:	d2801fe1 	mov	x1, #0xff                  	// #255
    5c58:	a9000413 	stp	x19, x1, [x0]
    5c5c:	9115c281 	add	x1, x20, #0x570
    5c60:	f900081f 	str	xzr, [x0, #16]
    5c64:	12800002 	mov	w2, #0xffffffff            	// #-1
    5c68:	f90002c0 	str	x0, [x22]
    5c6c:	39000262 	strb	w2, [x19]
    5c70:	f94e2420 	ldr	x0, [x1, #7240]
    5c74:	91000400 	add	x0, x0, #0x1
    5c78:	f90e2420 	str	x0, [x1, #7240]
    5c7c:	17fffcfb 	b	5068 <fwp_hof0.constprop.0+0xf4>
    5c80:	b4fffe41 	cbz	x1, 5c48 <fwp_hof0.constprop.0+0xcd4>
    5c84:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    5c88:	91084000 	add	x0, x0, #0x210
    5c8c:	97fff17d 	bl	2280 <fwp_trap>
    5c90:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    5c94:	91040000 	add	x0, x0, #0x100
    5c98:	97fff17a 	bl	2280 <fwp_trap>
    5c9c:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    5ca0:	9108e000 	add	x0, x0, #0x238
    5ca4:	97fff177 	bl	2280 <fwp_trap>
    5ca8:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    5cac:	17ffffc0 	b	5bac <fwp_hof0.constprop.0+0xc38>
    5cb0:	97fff008 	bl	1cd0 <fwp_heap_oom>
    5cb4:	a90553f3 	stp	x19, x20, [sp, #80]
    5cb8:	a90763f7 	stp	x23, x24, [sp, #112]
    5cbc:	a9086bf9 	stp	x25, x26, [sp, #128]
    5cc0:	a90973fb 	stp	x27, x28, [sp, #144]
    5cc4:	6d0a27e8 	stp	d8, d9, [sp, #160]
    5cc8:	97ffee0e 	bl	1500 <__stack_chk_fail@plt>
    5ccc:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    5cd0:	910a0000 	add	x0, x0, #0x280
    5cd4:	97fff16b 	bl	2280 <fwp_trap>
    5cd8:	97ffee8a 	bl	1700 <fwp_trap_overflow.constprop.0>
    5cdc:	d503201f 	nop

0000000000005ce0 <f0>:
    5ce0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    5ce4:	910003fd 	mov	x29, sp
    5ce8:	a90153f3 	stp	x19, x20, [sp, #16]
    5cec:	a9025bf5 	stp	x21, x22, [sp, #32]
    5cf0:	a90363f7 	stp	x23, x24, [sp, #48]
    5cf4:	a9046bf9 	stp	x25, x26, [sp, #64]
    5cf8:	a90573fb 	stp	x27, x28, [sp, #80]
    5cfc:	d12183ff 	sub	sp, sp, #0x860
    5d00:	f90203ff 	str	xzr, [sp, #1024]
    5d04:	f00000c0 	adrp	x0, 20000 <__data_start>
    5d08:	91024005 	add	x5, x0, #0x90
    5d0c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    5d10:	f947f400 	ldr	x0, [x0, #4072]
    5d14:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc70>
    5d18:	f94148a6 	ldr	x6, [x5, #656]
    5d1c:	f9400001 	ldr	x1, [x0]
    5d20:	f9042fe1 	str	x1, [sp, #2136]
    5d24:	d2800001 	mov	x1, #0x0                   	// #0
    5d28:	9115c298 	add	x24, x20, #0x570
    5d2c:	912123f6 	add	x22, sp, #0x848
    5d30:	910023e0 	add	x0, sp, #0x8
    5d34:	910083e2 	add	x2, sp, #0x20
    5d38:	d0ffffe1 	adrp	x1, 3000 <fwp_mem_free>
    5d3c:	90ffffe4 	adrp	x4, 1000 <__abi_tag+0xd88>
    5d40:	9129c021 	add	x1, x1, #0xa70
    5d44:	912e4084 	add	x4, x4, #0xb90
    5d48:	d2800013 	mov	x19, #0x0                   	// #0
    5d4c:	d2800119 	mov	x25, #0x8                   	// #8
    5d50:	d2800015 	mov	x21, #0x0                   	// #0
    5d54:	52800037 	mov	w23, #0x1                   	// #1
    5d58:	a90093e6 	stp	x6, x4, [sp, #8]
    5d5c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    5d60:	a90307ff 	stp	xzr, x1, [sp, #48]
    5d64:	f90148a0 	str	x0, [x5, #656]
    5d68:	f100073a 	subs	x26, x25, #0x1
    5d6c:	aa1603e0 	mov	x0, x22
    5d70:	da1f02bc 	sbc	x28, x21, xzr
    5d74:	f90017fa 	str	x26, [sp, #40]
    5d78:	f90427fa 	str	x26, [sp, #2120]
    5d7c:	aa1a03f9 	mov	x25, x26
    5d80:	f9042bf3 	str	x19, [sp, #2128]
    5d84:	97fff673 	bl	3750 <fwp_data.part.0.constprop.0>
    5d88:	f949db02 	ldr	x2, [x24, #5040]
    5d8c:	aa0003f3 	mov	x19, x0
    5d90:	f949ef00 	ldr	x0, [x24, #5080]
    5d94:	cb020262 	sub	x2, x19, x2
    5d98:	aa1c03f5 	mov	x21, x28
    5d9c:	eb00405f 	cmp	x2, x0, lsl #16
    5da0:	54000302 	b.cs	5e00 <f0+0x120>  // b.hs, b.nlast
    5da4:	d350fc40 	lsr	x0, x2, #16
    5da8:	f949ff04 	ldr	x4, [x24, #5112]
    5dac:	8b000800 	add	x0, x0, x0, lsl #2
    5db0:	d37df001 	lsl	x1, x0, #3
    5db4:	8b010080 	add	x0, x4, x1
    5db8:	f940101b 	ldr	x27, [x0, #32]
    5dbc:	b400023b 	cbz	x27, 5e00 <f0+0x120>
    5dc0:	38616881 	ldrb	w1, [x4, x1]
    5dc4:	7100083f 	cmp	w1, #0x2
    5dc8:	5400fe40 	b.eq	7d90 <f0+0x20b0>  // b.none
    5dcc:	7100043f 	cmp	w1, #0x1
    5dd0:	54000181 	b.ne	5e00 <f0+0x120>  // b.any
    5dd4:	29430001 	ldp	w1, w0, [x0, #24]
    5dd8:	92403c42 	and	x2, x2, #0xffff
    5ddc:	9b017c42 	mul	x2, x2, x1
    5de0:	d360fc42 	lsr	x2, x2, #32
    5de4:	eb00005f 	cmp	x2, x0
    5de8:	540000c2 	b.cs	5e00 <f0+0x120>  // b.hs, b.nlast
    5dec:	8b02037b 	add	x27, x27, x2
    5df0:	39400360 	ldrb	w0, [x27]
    5df4:	7103fc1f 	cmp	w0, #0xff
    5df8:	5400fc60 	b.eq	7d84 <f0+0x20a4>  // b.none
    5dfc:	39000377 	strb	w23, [x27]
    5e00:	f90013f3 	str	x19, [sp, #32]
    5e04:	aa1c035a 	orr	x26, x26, x28
    5e08:	b5fffb1a 	cbnz	x26, 5d68 <f0+0x88>
    5e0c:	90000022 	adrp	x2, 9000 <_IO_stdin_used+0x1e0>
    5e10:	f00000c0 	adrp	x0, 20000 <__data_start>
    5e14:	f94007e1 	ldr	x1, [sp, #8]
    5e18:	91024018 	add	x24, x0, #0x90
    5e1c:	3dc14440 	ldr	q0, [x2, #1296]
    5e20:	910103e0 	add	x0, sp, #0x40
    5e24:	f9014b01 	str	x1, [x24, #656]
    5e28:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    5e2c:	3d8013e0 	str	q0, [sp, #64]
    5e30:	97fff648 	bl	3750 <fwp_data.part.0.constprop.0>
    5e34:	97fff593 	bl	3480 <fwp_rc_fresh>
    5e38:	aa0003e1 	mov	x1, x0
    5e3c:	910163e0 	add	x0, sp, #0x58
    5e40:	a90587f5 	stp	x21, x1, [sp, #88]
    5e44:	97fff643 	bl	3750 <fwp_data.part.0.constprop.0>
    5e48:	97fff58e 	bl	3480 <fwp_rc_fresh>
    5e4c:	aa0003e1 	mov	x1, x0
    5e50:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5e54:	9101a3e0 	add	x0, sp, #0x68
    5e58:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5e5c:	a90687e2 	stp	x2, x1, [sp, #104]
    5e60:	97fff63c 	bl	3750 <fwp_data.part.0.constprop.0>
    5e64:	97fff587 	bl	3480 <fwp_rc_fresh>
    5e68:	aa0003e1 	mov	x1, x0
    5e6c:	9101e3e0 	add	x0, sp, #0x78
    5e70:	a90787f5 	stp	x21, x1, [sp, #120]
    5e74:	97fff637 	bl	3750 <fwp_data.part.0.constprop.0>
    5e78:	97fff582 	bl	3480 <fwp_rc_fresh>
    5e7c:	aa0003e1 	mov	x1, x0
    5e80:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5e84:	910223e0 	add	x0, sp, #0x88
    5e88:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5e8c:	a90887e2 	stp	x2, x1, [sp, #136]
    5e90:	97fff630 	bl	3750 <fwp_data.part.0.constprop.0>
    5e94:	97fff57b 	bl	3480 <fwp_rc_fresh>
    5e98:	aa0003e1 	mov	x1, x0
    5e9c:	910263e0 	add	x0, sp, #0x98
    5ea0:	a90987f5 	stp	x21, x1, [sp, #152]
    5ea4:	97fff62b 	bl	3750 <fwp_data.part.0.constprop.0>
    5ea8:	97fff576 	bl	3480 <fwp_rc_fresh>
    5eac:	aa0003e1 	mov	x1, x0
    5eb0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5eb4:	9102a3e0 	add	x0, sp, #0xa8
    5eb8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5ebc:	a90a87e2 	stp	x2, x1, [sp, #168]
    5ec0:	97fff624 	bl	3750 <fwp_data.part.0.constprop.0>
    5ec4:	97fff56f 	bl	3480 <fwp_rc_fresh>
    5ec8:	aa0003e1 	mov	x1, x0
    5ecc:	9102e3e0 	add	x0, sp, #0xb8
    5ed0:	a90b87f5 	stp	x21, x1, [sp, #184]
    5ed4:	97fff61f 	bl	3750 <fwp_data.part.0.constprop.0>
    5ed8:	97fff56a 	bl	3480 <fwp_rc_fresh>
    5edc:	aa0003e1 	mov	x1, x0
    5ee0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5ee4:	910323e0 	add	x0, sp, #0xc8
    5ee8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5eec:	a90c87e2 	stp	x2, x1, [sp, #200]
    5ef0:	97fff618 	bl	3750 <fwp_data.part.0.constprop.0>
    5ef4:	97fff563 	bl	3480 <fwp_rc_fresh>
    5ef8:	aa0003e1 	mov	x1, x0
    5efc:	910363e0 	add	x0, sp, #0xd8
    5f00:	a90d87f5 	stp	x21, x1, [sp, #216]
    5f04:	97fff613 	bl	3750 <fwp_data.part.0.constprop.0>
    5f08:	aa0003f5 	mov	x21, x0
    5f0c:	9115c283 	add	x3, x20, #0x570
    5f10:	f949d861 	ldr	x1, [x3, #5040]
    5f14:	f949ec60 	ldr	x0, [x3, #5080]
    5f18:	cb0102a1 	sub	x1, x21, x1
    5f1c:	eb00403f 	cmp	x1, x0, lsl #16
    5f20:	54000322 	b.cs	5f84 <f0+0x2a4>  // b.hs, b.nlast
    5f24:	d350fc22 	lsr	x2, x1, #16
    5f28:	f949fc63 	ldr	x3, [x3, #5112]
    5f2c:	8b020842 	add	x2, x2, x2, lsl #2
    5f30:	d37df042 	lsl	x2, x2, #3
    5f34:	8b020060 	add	x0, x3, x2
    5f38:	f9401017 	ldr	x23, [x0, #32]
    5f3c:	b4000257 	cbz	x23, 5f84 <f0+0x2a4>
    5f40:	38626862 	ldrb	w2, [x3, x2]
    5f44:	7100085f 	cmp	w2, #0x2
    5f48:	5400f660 	b.eq	7e14 <f0+0x2134>  // b.none
    5f4c:	7100045f 	cmp	w2, #0x1
    5f50:	540001a1 	b.ne	5f84 <f0+0x2a4>  // b.any
    5f54:	29430002 	ldp	w2, w0, [x0, #24]
    5f58:	92403c21 	and	x1, x1, #0xffff
    5f5c:	9b027c21 	mul	x1, x1, x2
    5f60:	d360fc21 	lsr	x1, x1, #32
    5f64:	eb00003f 	cmp	x1, x0
    5f68:	540000e2 	b.cs	5f84 <f0+0x2a4>  // b.hs, b.nlast
    5f6c:	8b0102f7 	add	x23, x23, x1
    5f70:	394002e0 	ldrb	w0, [x23]
    5f74:	7103fc1f 	cmp	w0, #0xff
    5f78:	54010020 	b.eq	7f7c <f0+0x229c>  // b.none
    5f7c:	52800020 	mov	w0, #0x1                   	// #1
    5f80:	390002e0 	strb	w0, [x23]
    5f84:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    5f88:	9103a3e0 	add	x0, sp, #0xe8
    5f8c:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    5f90:	a90ed7e1 	stp	x1, x21, [sp, #232]
    5f94:	97fff5ef 	bl	3750 <fwp_data.part.0.constprop.0>
    5f98:	aa0003f5 	mov	x21, x0
    5f9c:	9115c283 	add	x3, x20, #0x570
    5fa0:	f949d861 	ldr	x1, [x3, #5040]
    5fa4:	f949ec60 	ldr	x0, [x3, #5080]
    5fa8:	cb0102a1 	sub	x1, x21, x1
    5fac:	eb00403f 	cmp	x1, x0, lsl #16
    5fb0:	54000322 	b.cs	6014 <f0+0x334>  // b.hs, b.nlast
    5fb4:	d350fc22 	lsr	x2, x1, #16
    5fb8:	f949fc63 	ldr	x3, [x3, #5112]
    5fbc:	8b020842 	add	x2, x2, x2, lsl #2
    5fc0:	d37df042 	lsl	x2, x2, #3
    5fc4:	8b020060 	add	x0, x3, x2
    5fc8:	f9401017 	ldr	x23, [x0, #32]
    5fcc:	b4000257 	cbz	x23, 6014 <f0+0x334>
    5fd0:	38626862 	ldrb	w2, [x3, x2]
    5fd4:	7100085f 	cmp	w2, #0x2
    5fd8:	5400f180 	b.eq	7e08 <f0+0x2128>  // b.none
    5fdc:	7100045f 	cmp	w2, #0x1
    5fe0:	540001a1 	b.ne	6014 <f0+0x334>  // b.any
    5fe4:	29430002 	ldp	w2, w0, [x0, #24]
    5fe8:	92403c21 	and	x1, x1, #0xffff
    5fec:	9b027c21 	mul	x1, x1, x2
    5ff0:	d360fc21 	lsr	x1, x1, #32
    5ff4:	eb00003f 	cmp	x1, x0
    5ff8:	540000e2 	b.cs	6014 <f0+0x334>  // b.hs, b.nlast
    5ffc:	8b0102f7 	add	x23, x23, x1
    6000:	394002e0 	ldrb	w0, [x23]
    6004:	7103fc1f 	cmp	w0, #0xff
    6008:	5400fc00 	b.eq	7f88 <f0+0x22a8>  // b.none
    600c:	52800020 	mov	w0, #0x1                   	// #1
    6010:	390002e0 	strb	w0, [x23]
    6014:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6018:	9103e3e0 	add	x0, sp, #0xf8
    601c:	a90fd7f7 	stp	x23, x21, [sp, #248]
    6020:	97fff5cc 	bl	3750 <fwp_data.part.0.constprop.0>
    6024:	97fff517 	bl	3480 <fwp_rc_fresh>
    6028:	aa0003e1 	mov	x1, x0
    602c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6030:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    6034:	910423e0 	add	x0, sp, #0x108
    6038:	a91087f5 	stp	x21, x1, [sp, #264]
    603c:	97fff5c5 	bl	3750 <fwp_data.part.0.constprop.0>
    6040:	97fff510 	bl	3480 <fwp_rc_fresh>
    6044:	aa0003e1 	mov	x1, x0
    6048:	910463e0 	add	x0, sp, #0x118
    604c:	a91187f7 	stp	x23, x1, [sp, #280]
    6050:	97fff5c0 	bl	3750 <fwp_data.part.0.constprop.0>
    6054:	97fff50b 	bl	3480 <fwp_rc_fresh>
    6058:	aa0003e1 	mov	x1, x0
    605c:	9104a3e0 	add	x0, sp, #0x128
    6060:	a91287f5 	stp	x21, x1, [sp, #296]
    6064:	97fff5bb 	bl	3750 <fwp_data.part.0.constprop.0>
    6068:	97fff506 	bl	3480 <fwp_rc_fresh>
    606c:	aa0003e1 	mov	x1, x0
    6070:	9104e3e0 	add	x0, sp, #0x138
    6074:	a91387f7 	stp	x23, x1, [sp, #312]
    6078:	97fff5b6 	bl	3750 <fwp_data.part.0.constprop.0>
    607c:	97fff501 	bl	3480 <fwp_rc_fresh>
    6080:	aa0003e1 	mov	x1, x0
    6084:	910523e0 	add	x0, sp, #0x148
    6088:	a91487f5 	stp	x21, x1, [sp, #328]
    608c:	97fff5b1 	bl	3750 <fwp_data.part.0.constprop.0>
    6090:	aa0003f5 	mov	x21, x0
    6094:	9115c283 	add	x3, x20, #0x570
    6098:	f949d861 	ldr	x1, [x3, #5040]
    609c:	f949ec60 	ldr	x0, [x3, #5080]
    60a0:	cb0102a1 	sub	x1, x21, x1
    60a4:	eb00403f 	cmp	x1, x0, lsl #16
    60a8:	54000322 	b.cs	610c <f0+0x42c>  // b.hs, b.nlast
    60ac:	d350fc22 	lsr	x2, x1, #16
    60b0:	f949fc63 	ldr	x3, [x3, #5112]
    60b4:	8b020842 	add	x2, x2, x2, lsl #2
    60b8:	d37df042 	lsl	x2, x2, #3
    60bc:	8b020060 	add	x0, x3, x2
    60c0:	f9401017 	ldr	x23, [x0, #32]
    60c4:	b4000257 	cbz	x23, 610c <f0+0x42c>
    60c8:	38626862 	ldrb	w2, [x3, x2]
    60cc:	7100085f 	cmp	w2, #0x2
    60d0:	5400e960 	b.eq	7dfc <f0+0x211c>  // b.none
    60d4:	7100045f 	cmp	w2, #0x1
    60d8:	540001a1 	b.ne	610c <f0+0x42c>  // b.any
    60dc:	29430002 	ldp	w2, w0, [x0, #24]
    60e0:	92403c21 	and	x1, x1, #0xffff
    60e4:	9b027c21 	mul	x1, x1, x2
    60e8:	d360fc21 	lsr	x1, x1, #32
    60ec:	eb00003f 	cmp	x1, x0
    60f0:	540000e2 	b.cs	610c <f0+0x42c>  // b.hs, b.nlast
    60f4:	8b0102f7 	add	x23, x23, x1
    60f8:	394002e0 	ldrb	w0, [x23]
    60fc:	7103fc1f 	cmp	w0, #0xff
    6100:	5400f4a0 	b.eq	7f94 <f0+0x22b4>  // b.none
    6104:	52800020 	mov	w0, #0x1                   	// #1
    6108:	390002e0 	strb	w0, [x23]
    610c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6110:	910563e0 	add	x0, sp, #0x158
    6114:	a915d7f7 	stp	x23, x21, [sp, #344]
    6118:	97fff58e 	bl	3750 <fwp_data.part.0.constprop.0>
    611c:	97fff4d9 	bl	3480 <fwp_rc_fresh>
    6120:	aa0003e1 	mov	x1, x0
    6124:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6128:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    612c:	9105a3e0 	add	x0, sp, #0x168
    6130:	a91687f5 	stp	x21, x1, [sp, #360]
    6134:	97fff587 	bl	3750 <fwp_data.part.0.constprop.0>
    6138:	97fff4d2 	bl	3480 <fwp_rc_fresh>
    613c:	aa0003e1 	mov	x1, x0
    6140:	9105e3e0 	add	x0, sp, #0x178
    6144:	a91787f7 	stp	x23, x1, [sp, #376]
    6148:	97fff582 	bl	3750 <fwp_data.part.0.constprop.0>
    614c:	97fff4cd 	bl	3480 <fwp_rc_fresh>
    6150:	aa0003e1 	mov	x1, x0
    6154:	910623e0 	add	x0, sp, #0x188
    6158:	a91887f5 	stp	x21, x1, [sp, #392]
    615c:	97fff57d 	bl	3750 <fwp_data.part.0.constprop.0>
    6160:	aa0003f5 	mov	x21, x0
    6164:	9115c283 	add	x3, x20, #0x570
    6168:	f949d861 	ldr	x1, [x3, #5040]
    616c:	f949ec60 	ldr	x0, [x3, #5080]
    6170:	cb0102a1 	sub	x1, x21, x1
    6174:	eb00403f 	cmp	x1, x0, lsl #16
    6178:	54000322 	b.cs	61dc <f0+0x4fc>  // b.hs, b.nlast
    617c:	d350fc22 	lsr	x2, x1, #16
    6180:	f949fc63 	ldr	x3, [x3, #5112]
    6184:	8b020842 	add	x2, x2, x2, lsl #2
    6188:	d37df042 	lsl	x2, x2, #3
    618c:	8b020060 	add	x0, x3, x2
    6190:	f9401017 	ldr	x23, [x0, #32]
    6194:	b4000257 	cbz	x23, 61dc <f0+0x4fc>
    6198:	38626862 	ldrb	w2, [x3, x2]
    619c:	7100085f 	cmp	w2, #0x2
    61a0:	5400e520 	b.eq	7e44 <f0+0x2164>  // b.none
    61a4:	7100045f 	cmp	w2, #0x1
    61a8:	540001a1 	b.ne	61dc <f0+0x4fc>  // b.any
    61ac:	29430002 	ldp	w2, w0, [x0, #24]
    61b0:	92403c21 	and	x1, x1, #0xffff
    61b4:	9b027c21 	mul	x1, x1, x2
    61b8:	d360fc21 	lsr	x1, x1, #32
    61bc:	eb00003f 	cmp	x1, x0
    61c0:	540000e2 	b.cs	61dc <f0+0x4fc>  // b.hs, b.nlast
    61c4:	8b0102f7 	add	x23, x23, x1
    61c8:	394002e0 	ldrb	w0, [x23]
    61cc:	7103fc1f 	cmp	w0, #0xff
    61d0:	5400ee80 	b.eq	7fa0 <f0+0x22c0>  // b.none
    61d4:	52800020 	mov	w0, #0x1                   	// #1
    61d8:	390002e0 	strb	w0, [x23]
    61dc:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    61e0:	910663e0 	add	x0, sp, #0x198
    61e4:	a919d7e1 	stp	x1, x21, [sp, #408]
    61e8:	97fff55a 	bl	3750 <fwp_data.part.0.constprop.0>
    61ec:	97fff4a5 	bl	3480 <fwp_rc_fresh>
    61f0:	aa0003e1 	mov	x1, x0
    61f4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    61f8:	9106a3e0 	add	x0, sp, #0x1a8
    61fc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6200:	a91a87e2 	stp	x2, x1, [sp, #424]
    6204:	97fff553 	bl	3750 <fwp_data.part.0.constprop.0>
    6208:	aa0003f5 	mov	x21, x0
    620c:	9115c283 	add	x3, x20, #0x570
    6210:	f949d861 	ldr	x1, [x3, #5040]
    6214:	f949ec60 	ldr	x0, [x3, #5080]
    6218:	cb0102a1 	sub	x1, x21, x1
    621c:	eb00403f 	cmp	x1, x0, lsl #16
    6220:	54000322 	b.cs	6284 <f0+0x5a4>  // b.hs, b.nlast
    6224:	d350fc22 	lsr	x2, x1, #16
    6228:	f949fc63 	ldr	x3, [x3, #5112]
    622c:	8b020842 	add	x2, x2, x2, lsl #2
    6230:	d37df042 	lsl	x2, x2, #3
    6234:	8b020060 	add	x0, x3, x2
    6238:	f9401017 	ldr	x23, [x0, #32]
    623c:	b4000257 	cbz	x23, 6284 <f0+0x5a4>
    6240:	38626862 	ldrb	w2, [x3, x2]
    6244:	7100085f 	cmp	w2, #0x2
    6248:	5400df80 	b.eq	7e38 <f0+0x2158>  // b.none
    624c:	7100045f 	cmp	w2, #0x1
    6250:	540001a1 	b.ne	6284 <f0+0x5a4>  // b.any
    6254:	29430002 	ldp	w2, w0, [x0, #24]
    6258:	92403c21 	and	x1, x1, #0xffff
    625c:	9b027c21 	mul	x1, x1, x2
    6260:	d360fc21 	lsr	x1, x1, #32
    6264:	eb00003f 	cmp	x1, x0
    6268:	540000e2 	b.cs	6284 <f0+0x5a4>  // b.hs, b.nlast
    626c:	8b0102f7 	add	x23, x23, x1
    6270:	394002e0 	ldrb	w0, [x23]
    6274:	7103fc1f 	cmp	w0, #0xff
    6278:	5400e9a0 	b.eq	7fac <f0+0x22cc>  // b.none
    627c:	52800020 	mov	w0, #0x1                   	// #1
    6280:	390002e0 	strb	w0, [x23]
    6284:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6288:	9106e3e0 	add	x0, sp, #0x1b8
    628c:	a91bd7e1 	stp	x1, x21, [sp, #440]
    6290:	97fff530 	bl	3750 <fwp_data.part.0.constprop.0>
    6294:	97fff47b 	bl	3480 <fwp_rc_fresh>
    6298:	aa0003e1 	mov	x1, x0
    629c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    62a0:	910723e0 	add	x0, sp, #0x1c8
    62a4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    62a8:	a91c87e2 	stp	x2, x1, [sp, #456]
    62ac:	97fff529 	bl	3750 <fwp_data.part.0.constprop.0>
    62b0:	aa0003f5 	mov	x21, x0
    62b4:	9115c283 	add	x3, x20, #0x570
    62b8:	f949d861 	ldr	x1, [x3, #5040]
    62bc:	f949ec60 	ldr	x0, [x3, #5080]
    62c0:	cb0102a1 	sub	x1, x21, x1
    62c4:	eb00403f 	cmp	x1, x0, lsl #16
    62c8:	54000322 	b.cs	632c <f0+0x64c>  // b.hs, b.nlast
    62cc:	d350fc22 	lsr	x2, x1, #16
    62d0:	f949fc63 	ldr	x3, [x3, #5112]
    62d4:	8b020842 	add	x2, x2, x2, lsl #2
    62d8:	d37df042 	lsl	x2, x2, #3
    62dc:	8b020060 	add	x0, x3, x2
    62e0:	f9401017 	ldr	x23, [x0, #32]
    62e4:	b4000257 	cbz	x23, 632c <f0+0x64c>
    62e8:	38626862 	ldrb	w2, [x3, x2]
    62ec:	7100085f 	cmp	w2, #0x2
    62f0:	5400d9e0 	b.eq	7e2c <f0+0x214c>  // b.none
    62f4:	7100045f 	cmp	w2, #0x1
    62f8:	540001a1 	b.ne	632c <f0+0x64c>  // b.any
    62fc:	29430002 	ldp	w2, w0, [x0, #24]
    6300:	92403c21 	and	x1, x1, #0xffff
    6304:	9b027c21 	mul	x1, x1, x2
    6308:	d360fc21 	lsr	x1, x1, #32
    630c:	eb00003f 	cmp	x1, x0
    6310:	540000e2 	b.cs	632c <f0+0x64c>  // b.hs, b.nlast
    6314:	8b0102f7 	add	x23, x23, x1
    6318:	394002e0 	ldrb	w0, [x23]
    631c:	7103fc1f 	cmp	w0, #0xff
    6320:	5400e4c0 	b.eq	7fb8 <f0+0x22d8>  // b.none
    6324:	52800020 	mov	w0, #0x1                   	// #1
    6328:	390002e0 	strb	w0, [x23]
    632c:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6330:	910763e0 	add	x0, sp, #0x1d8
    6334:	a91dd7e1 	stp	x1, x21, [sp, #472]
    6338:	97fff506 	bl	3750 <fwp_data.part.0.constprop.0>
    633c:	9115c283 	add	x3, x20, #0x570
    6340:	aa0003f5 	mov	x21, x0
    6344:	f949d861 	ldr	x1, [x3, #5040]
    6348:	f949ec60 	ldr	x0, [x3, #5080]
    634c:	cb0102a1 	sub	x1, x21, x1
    6350:	eb00403f 	cmp	x1, x0, lsl #16
    6354:	54000322 	b.cs	63b8 <f0+0x6d8>  // b.hs, b.nlast
    6358:	d350fc22 	lsr	x2, x1, #16
    635c:	f949fc63 	ldr	x3, [x3, #5112]
    6360:	8b020842 	add	x2, x2, x2, lsl #2
    6364:	d37df042 	lsl	x2, x2, #3
    6368:	8b020060 	add	x0, x3, x2
    636c:	f9401017 	ldr	x23, [x0, #32]
    6370:	b4000257 	cbz	x23, 63b8 <f0+0x6d8>
    6374:	38626862 	ldrb	w2, [x3, x2]
    6378:	7100085f 	cmp	w2, #0x2
    637c:	5400d520 	b.eq	7e20 <f0+0x2140>  // b.none
    6380:	7100045f 	cmp	w2, #0x1
    6384:	540001a1 	b.ne	63b8 <f0+0x6d8>  // b.any
    6388:	29430002 	ldp	w2, w0, [x0, #24]
    638c:	92403c21 	and	x1, x1, #0xffff
    6390:	9b027c21 	mul	x1, x1, x2
    6394:	d360fc21 	lsr	x1, x1, #32
    6398:	eb00003f 	cmp	x1, x0
    639c:	540000e2 	b.cs	63b8 <f0+0x6d8>  // b.hs, b.nlast
    63a0:	8b0102f7 	add	x23, x23, x1
    63a4:	394002e0 	ldrb	w0, [x23]
    63a8:	7103fc1f 	cmp	w0, #0xff
    63ac:	5400e0c0 	b.eq	7fc4 <f0+0x22e4>  // b.none
    63b0:	52800020 	mov	w0, #0x1                   	// #1
    63b4:	390002e0 	strb	w0, [x23]
    63b8:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    63bc:	9107a3e0 	add	x0, sp, #0x1e8
    63c0:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    63c4:	a91ed7e1 	stp	x1, x21, [sp, #488]
    63c8:	97fff4e2 	bl	3750 <fwp_data.part.0.constprop.0>
    63cc:	aa0003f5 	mov	x21, x0
    63d0:	9115c283 	add	x3, x20, #0x570
    63d4:	f949d861 	ldr	x1, [x3, #5040]
    63d8:	f949ec60 	ldr	x0, [x3, #5080]
    63dc:	cb0102a1 	sub	x1, x21, x1
    63e0:	eb00403f 	cmp	x1, x0, lsl #16
    63e4:	54000322 	b.cs	6448 <f0+0x768>  // b.hs, b.nlast
    63e8:	d350fc22 	lsr	x2, x1, #16
    63ec:	f949fc63 	ldr	x3, [x3, #5112]
    63f0:	8b020842 	add	x2, x2, x2, lsl #2
    63f4:	d37df042 	lsl	x2, x2, #3
    63f8:	8b020060 	add	x0, x3, x2
    63fc:	f9401017 	ldr	x23, [x0, #32]
    6400:	b4000257 	cbz	x23, 6448 <f0+0x768>
    6404:	38626862 	ldrb	w2, [x3, x2]
    6408:	7100085f 	cmp	w2, #0x2
    640c:	5400d4c0 	b.eq	7ea4 <f0+0x21c4>  // b.none
    6410:	7100045f 	cmp	w2, #0x1
    6414:	540001a1 	b.ne	6448 <f0+0x768>  // b.any
    6418:	29430002 	ldp	w2, w0, [x0, #24]
    641c:	92403c21 	and	x1, x1, #0xffff
    6420:	9b027c21 	mul	x1, x1, x2
    6424:	d360fc21 	lsr	x1, x1, #32
    6428:	eb00003f 	cmp	x1, x0
    642c:	540000e2 	b.cs	6448 <f0+0x768>  // b.hs, b.nlast
    6430:	8b0102f7 	add	x23, x23, x1
    6434:	394002e0 	ldrb	w0, [x23]
    6438:	7103fc1f 	cmp	w0, #0xff
    643c:	5400dca0 	b.eq	7fd0 <f0+0x22f0>  // b.none
    6440:	52800020 	mov	w0, #0x1                   	// #1
    6444:	390002e0 	strb	w0, [x23]
    6448:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    644c:	9107e3e0 	add	x0, sp, #0x1f8
    6450:	a91fd7e1 	stp	x1, x21, [sp, #504]
    6454:	97fff4bf 	bl	3750 <fwp_data.part.0.constprop.0>
    6458:	97fff40a 	bl	3480 <fwp_rc_fresh>
    645c:	aa0003e1 	mov	x1, x0
    6460:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6464:	910823e0 	add	x0, sp, #0x208
    6468:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    646c:	f90107e2 	str	x2, [sp, #520]
    6470:	f9010be1 	str	x1, [sp, #528]
    6474:	97fff4b7 	bl	3750 <fwp_data.part.0.constprop.0>
    6478:	aa0003f5 	mov	x21, x0
    647c:	9115c283 	add	x3, x20, #0x570
    6480:	f949d861 	ldr	x1, [x3, #5040]
    6484:	f949ec60 	ldr	x0, [x3, #5080]
    6488:	cb0102a1 	sub	x1, x21, x1
    648c:	eb00403f 	cmp	x1, x0, lsl #16
    6490:	54000322 	b.cs	64f4 <f0+0x814>  // b.hs, b.nlast
    6494:	d350fc22 	lsr	x2, x1, #16
    6498:	f949fc63 	ldr	x3, [x3, #5112]
    649c:	8b020842 	add	x2, x2, x2, lsl #2
    64a0:	d37df042 	lsl	x2, x2, #3
    64a4:	8b020060 	add	x0, x3, x2
    64a8:	f9401017 	ldr	x23, [x0, #32]
    64ac:	b4000257 	cbz	x23, 64f4 <f0+0x814>
    64b0:	38626862 	ldrb	w2, [x3, x2]
    64b4:	7100085f 	cmp	w2, #0x2
    64b8:	5400cf00 	b.eq	7e98 <f0+0x21b8>  // b.none
    64bc:	7100045f 	cmp	w2, #0x1
    64c0:	540001a1 	b.ne	64f4 <f0+0x814>  // b.any
    64c4:	29430002 	ldp	w2, w0, [x0, #24]
    64c8:	92403c21 	and	x1, x1, #0xffff
    64cc:	9b027c21 	mul	x1, x1, x2
    64d0:	d360fc21 	lsr	x1, x1, #32
    64d4:	eb00003f 	cmp	x1, x0
    64d8:	540000e2 	b.cs	64f4 <f0+0x814>  // b.hs, b.nlast
    64dc:	8b0102f7 	add	x23, x23, x1
    64e0:	394002e0 	ldrb	w0, [x23]
    64e4:	7103fc1f 	cmp	w0, #0xff
    64e8:	5400d7a0 	b.eq	7fdc <f0+0x22fc>  // b.none
    64ec:	52800020 	mov	w0, #0x1                   	// #1
    64f0:	390002e0 	strb	w0, [x23]
    64f4:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    64f8:	910863e0 	add	x0, sp, #0x218
    64fc:	f9010fe1 	str	x1, [sp, #536]
    6500:	f90113f5 	str	x21, [sp, #544]
    6504:	97fff493 	bl	3750 <fwp_data.part.0.constprop.0>
    6508:	97fff3de 	bl	3480 <fwp_rc_fresh>
    650c:	aa0003e1 	mov	x1, x0
    6510:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6514:	9108a3e0 	add	x0, sp, #0x228
    6518:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    651c:	f90117e2 	str	x2, [sp, #552]
    6520:	f9011be1 	str	x1, [sp, #560]
    6524:	97fff48b 	bl	3750 <fwp_data.part.0.constprop.0>
    6528:	aa0003f5 	mov	x21, x0
    652c:	9115c283 	add	x3, x20, #0x570
    6530:	f949d861 	ldr	x1, [x3, #5040]
    6534:	f949ec60 	ldr	x0, [x3, #5080]
    6538:	cb0102a1 	sub	x1, x21, x1
    653c:	eb00403f 	cmp	x1, x0, lsl #16
    6540:	54000322 	b.cs	65a4 <f0+0x8c4>  // b.hs, b.nlast
    6544:	d350fc22 	lsr	x2, x1, #16
    6548:	f949fc63 	ldr	x3, [x3, #5112]
    654c:	8b020842 	add	x2, x2, x2, lsl #2
    6550:	d37df042 	lsl	x2, x2, #3
    6554:	8b020060 	add	x0, x3, x2
    6558:	f9401017 	ldr	x23, [x0, #32]
    655c:	b4000257 	cbz	x23, 65a4 <f0+0x8c4>
    6560:	38626862 	ldrb	w2, [x3, x2]
    6564:	7100085f 	cmp	w2, #0x2
    6568:	5400c920 	b.eq	7e8c <f0+0x21ac>  // b.none
    656c:	7100045f 	cmp	w2, #0x1
    6570:	540001a1 	b.ne	65a4 <f0+0x8c4>  // b.any
    6574:	29430002 	ldp	w2, w0, [x0, #24]
    6578:	92403c21 	and	x1, x1, #0xffff
    657c:	9b027c21 	mul	x1, x1, x2
    6580:	d360fc21 	lsr	x1, x1, #32
    6584:	eb00003f 	cmp	x1, x0
    6588:	540000e2 	b.cs	65a4 <f0+0x8c4>  // b.hs, b.nlast
    658c:	8b0102f7 	add	x23, x23, x1
    6590:	394002e0 	ldrb	w0, [x23]
    6594:	7103fc1f 	cmp	w0, #0xff
    6598:	5400d280 	b.eq	7fe8 <f0+0x2308>  // b.none
    659c:	52800020 	mov	w0, #0x1                   	// #1
    65a0:	390002e0 	strb	w0, [x23]
    65a4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    65a8:	9108e3e0 	add	x0, sp, #0x238
    65ac:	f9011ff7 	str	x23, [sp, #568]
    65b0:	f90123f5 	str	x21, [sp, #576]
    65b4:	97fff467 	bl	3750 <fwp_data.part.0.constprop.0>
    65b8:	97fff3b2 	bl	3480 <fwp_rc_fresh>
    65bc:	aa0003e1 	mov	x1, x0
    65c0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    65c4:	910923e0 	add	x0, sp, #0x248
    65c8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    65cc:	f90127e2 	str	x2, [sp, #584]
    65d0:	f9012be1 	str	x1, [sp, #592]
    65d4:	97fff45f 	bl	3750 <fwp_data.part.0.constprop.0>
    65d8:	97fff3aa 	bl	3480 <fwp_rc_fresh>
    65dc:	aa0003e1 	mov	x1, x0
    65e0:	910963e0 	add	x0, sp, #0x258
    65e4:	f9012ff7 	str	x23, [sp, #600]
    65e8:	f90133e1 	str	x1, [sp, #608]
    65ec:	97fff459 	bl	3750 <fwp_data.part.0.constprop.0>
    65f0:	aa0003f5 	mov	x21, x0
    65f4:	9115c283 	add	x3, x20, #0x570
    65f8:	f949d861 	ldr	x1, [x3, #5040]
    65fc:	f949ec60 	ldr	x0, [x3, #5080]
    6600:	cb0102a1 	sub	x1, x21, x1
    6604:	eb00403f 	cmp	x1, x0, lsl #16
    6608:	54000322 	b.cs	666c <f0+0x98c>  // b.hs, b.nlast
    660c:	d350fc22 	lsr	x2, x1, #16
    6610:	f949fc63 	ldr	x3, [x3, #5112]
    6614:	8b020842 	add	x2, x2, x2, lsl #2
    6618:	d37df042 	lsl	x2, x2, #3
    661c:	8b020060 	add	x0, x3, x2
    6620:	f9401017 	ldr	x23, [x0, #32]
    6624:	b4000257 	cbz	x23, 666c <f0+0x98c>
    6628:	38626862 	ldrb	w2, [x3, x2]
    662c:	7100085f 	cmp	w2, #0x2
    6630:	5400c280 	b.eq	7e80 <f0+0x21a0>  // b.none
    6634:	7100045f 	cmp	w2, #0x1
    6638:	540001a1 	b.ne	666c <f0+0x98c>  // b.any
    663c:	29430002 	ldp	w2, w0, [x0, #24]
    6640:	92403c21 	and	x1, x1, #0xffff
    6644:	9b027c21 	mul	x1, x1, x2
    6648:	d360fc21 	lsr	x1, x1, #32
    664c:	eb00003f 	cmp	x1, x0
    6650:	540000e2 	b.cs	666c <f0+0x98c>  // b.hs, b.nlast
    6654:	8b0102f7 	add	x23, x23, x1
    6658:	394002e0 	ldrb	w0, [x23]
    665c:	7103fc1f 	cmp	w0, #0xff
    6660:	5400cca0 	b.eq	7ff4 <f0+0x2314>  // b.none
    6664:	52800020 	mov	w0, #0x1                   	// #1
    6668:	390002e0 	strb	w0, [x23]
    666c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6670:	9109a3e0 	add	x0, sp, #0x268
    6674:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6678:	f90137f7 	str	x23, [sp, #616]
    667c:	f9013bf5 	str	x21, [sp, #624]
    6680:	97fff434 	bl	3750 <fwp_data.part.0.constprop.0>
    6684:	97fff37f 	bl	3480 <fwp_rc_fresh>
    6688:	aa0003e1 	mov	x1, x0
    668c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6690:	9109e3e0 	add	x0, sp, #0x278
    6694:	f9013ff5 	str	x21, [sp, #632]
    6698:	f90143e1 	str	x1, [sp, #640]
    669c:	97fff42d 	bl	3750 <fwp_data.part.0.constprop.0>
    66a0:	97fff378 	bl	3480 <fwp_rc_fresh>
    66a4:	aa0003e1 	mov	x1, x0
    66a8:	910a23e0 	add	x0, sp, #0x288
    66ac:	f90147f7 	str	x23, [sp, #648]
    66b0:	f9014be1 	str	x1, [sp, #656]
    66b4:	97fff427 	bl	3750 <fwp_data.part.0.constprop.0>
    66b8:	97fff372 	bl	3480 <fwp_rc_fresh>
    66bc:	aa0003e1 	mov	x1, x0
    66c0:	910a63e0 	add	x0, sp, #0x298
    66c4:	f9014ff5 	str	x21, [sp, #664]
    66c8:	f90153e1 	str	x1, [sp, #672]
    66cc:	97fff421 	bl	3750 <fwp_data.part.0.constprop.0>
    66d0:	aa0003f5 	mov	x21, x0
    66d4:	9115c283 	add	x3, x20, #0x570
    66d8:	f949d861 	ldr	x1, [x3, #5040]
    66dc:	f949ec60 	ldr	x0, [x3, #5080]
    66e0:	cb0102a1 	sub	x1, x21, x1
    66e4:	eb00403f 	cmp	x1, x0, lsl #16
    66e8:	54000322 	b.cs	674c <f0+0xa6c>  // b.hs, b.nlast
    66ec:	d350fc22 	lsr	x2, x1, #16
    66f0:	f949fc63 	ldr	x3, [x3, #5112]
    66f4:	8b020842 	add	x2, x2, x2, lsl #2
    66f8:	d37df042 	lsl	x2, x2, #3
    66fc:	8b020060 	add	x0, x3, x2
    6700:	f9401017 	ldr	x23, [x0, #32]
    6704:	b4000257 	cbz	x23, 674c <f0+0xa6c>
    6708:	38626862 	ldrb	w2, [x3, x2]
    670c:	7100085f 	cmp	w2, #0x2
    6710:	5400bb20 	b.eq	7e74 <f0+0x2194>  // b.none
    6714:	7100045f 	cmp	w2, #0x1
    6718:	540001a1 	b.ne	674c <f0+0xa6c>  // b.any
    671c:	29430002 	ldp	w2, w0, [x0, #24]
    6720:	92403c21 	and	x1, x1, #0xffff
    6724:	9b027c21 	mul	x1, x1, x2
    6728:	d360fc21 	lsr	x1, x1, #32
    672c:	eb00003f 	cmp	x1, x0
    6730:	540000e2 	b.cs	674c <f0+0xa6c>  // b.hs, b.nlast
    6734:	8b0102f7 	add	x23, x23, x1
    6738:	394002e0 	ldrb	w0, [x23]
    673c:	7103fc1f 	cmp	w0, #0xff
    6740:	5400c600 	b.eq	8000 <f0+0x2320>  // b.none
    6744:	52800020 	mov	w0, #0x1                   	// #1
    6748:	390002e0 	strb	w0, [x23]
    674c:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    6750:	910aa3e0 	add	x0, sp, #0x2a8
    6754:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    6758:	f90157e1 	str	x1, [sp, #680]
    675c:	f9015bf5 	str	x21, [sp, #688]
    6760:	97fff3fc 	bl	3750 <fwp_data.part.0.constprop.0>
    6764:	aa0003f5 	mov	x21, x0
    6768:	9115c283 	add	x3, x20, #0x570
    676c:	f949d861 	ldr	x1, [x3, #5040]
    6770:	f949ec60 	ldr	x0, [x3, #5080]
    6774:	cb0102a1 	sub	x1, x21, x1
    6778:	eb00403f 	cmp	x1, x0, lsl #16
    677c:	54000322 	b.cs	67e0 <f0+0xb00>  // b.hs, b.nlast
    6780:	d350fc22 	lsr	x2, x1, #16
    6784:	f949fc63 	ldr	x3, [x3, #5112]
    6788:	8b020842 	add	x2, x2, x2, lsl #2
    678c:	d37df042 	lsl	x2, x2, #3
    6790:	8b020060 	add	x0, x3, x2
    6794:	f9401017 	ldr	x23, [x0, #32]
    6798:	b4000257 	cbz	x23, 67e0 <f0+0xb00>
    679c:	38626862 	ldrb	w2, [x3, x2]
    67a0:	7100085f 	cmp	w2, #0x2
    67a4:	5400b620 	b.eq	7e68 <f0+0x2188>  // b.none
    67a8:	7100045f 	cmp	w2, #0x1
    67ac:	540001a1 	b.ne	67e0 <f0+0xb00>  // b.any
    67b0:	29430002 	ldp	w2, w0, [x0, #24]
    67b4:	92403c21 	and	x1, x1, #0xffff
    67b8:	9b027c21 	mul	x1, x1, x2
    67bc:	d360fc21 	lsr	x1, x1, #32
    67c0:	eb00003f 	cmp	x1, x0
    67c4:	540000e2 	b.cs	67e0 <f0+0xb00>  // b.hs, b.nlast
    67c8:	8b0102f7 	add	x23, x23, x1
    67cc:	394002e0 	ldrb	w0, [x23]
    67d0:	7103fc1f 	cmp	w0, #0xff
    67d4:	5400c1c0 	b.eq	800c <f0+0x232c>  // b.none
    67d8:	52800020 	mov	w0, #0x1                   	// #1
    67dc:	390002e0 	strb	w0, [x23]
    67e0:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    67e4:	910ae3e0 	add	x0, sp, #0x2b8
    67e8:	f9015fe1 	str	x1, [sp, #696]
    67ec:	f90163f5 	str	x21, [sp, #704]
    67f0:	97fff3d8 	bl	3750 <fwp_data.part.0.constprop.0>
    67f4:	9115c283 	add	x3, x20, #0x570
    67f8:	aa0003f5 	mov	x21, x0
    67fc:	f949d861 	ldr	x1, [x3, #5040]
    6800:	f949ec60 	ldr	x0, [x3, #5080]
    6804:	cb0102a1 	sub	x1, x21, x1
    6808:	eb00403f 	cmp	x1, x0, lsl #16
    680c:	54000322 	b.cs	6870 <f0+0xb90>  // b.hs, b.nlast
    6810:	d350fc22 	lsr	x2, x1, #16
    6814:	f949fc63 	ldr	x3, [x3, #5112]
    6818:	8b020842 	add	x2, x2, x2, lsl #2
    681c:	d37df042 	lsl	x2, x2, #3
    6820:	8b020060 	add	x0, x3, x2
    6824:	f9401017 	ldr	x23, [x0, #32]
    6828:	b4000257 	cbz	x23, 6870 <f0+0xb90>
    682c:	38626862 	ldrb	w2, [x3, x2]
    6830:	7100085f 	cmp	w2, #0x2
    6834:	5400b140 	b.eq	7e5c <f0+0x217c>  // b.none
    6838:	7100045f 	cmp	w2, #0x1
    683c:	540001a1 	b.ne	6870 <f0+0xb90>  // b.any
    6840:	29430002 	ldp	w2, w0, [x0, #24]
    6844:	92403c21 	and	x1, x1, #0xffff
    6848:	9b027c21 	mul	x1, x1, x2
    684c:	d360fc21 	lsr	x1, x1, #32
    6850:	eb00003f 	cmp	x1, x0
    6854:	540000e2 	b.cs	6870 <f0+0xb90>  // b.hs, b.nlast
    6858:	8b0102f7 	add	x23, x23, x1
    685c:	394002e0 	ldrb	w0, [x23]
    6860:	7103fc1f 	cmp	w0, #0xff
    6864:	5400bda0 	b.eq	8018 <f0+0x2338>  // b.none
    6868:	52800020 	mov	w0, #0x1                   	// #1
    686c:	390002e0 	strb	w0, [x23]
    6870:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6874:	910b23e0 	add	x0, sp, #0x2c8
    6878:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    687c:	f90167f7 	str	x23, [sp, #712]
    6880:	f9016bf5 	str	x21, [sp, #720]
    6884:	97fff3b3 	bl	3750 <fwp_data.part.0.constprop.0>
    6888:	97fff2fe 	bl	3480 <fwp_rc_fresh>
    688c:	aa0003e1 	mov	x1, x0
    6890:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    6894:	910b63e0 	add	x0, sp, #0x2d8
    6898:	f9016fe2 	str	x2, [sp, #728]
    689c:	f90173e1 	str	x1, [sp, #736]
    68a0:	97fff3ac 	bl	3750 <fwp_data.part.0.constprop.0>
    68a4:	97fff2f7 	bl	3480 <fwp_rc_fresh>
    68a8:	aa0003e1 	mov	x1, x0
    68ac:	910ba3e0 	add	x0, sp, #0x2e8
    68b0:	f90177f7 	str	x23, [sp, #744]
    68b4:	f9017be1 	str	x1, [sp, #752]
    68b8:	97fff3a6 	bl	3750 <fwp_data.part.0.constprop.0>
    68bc:	aa0003f5 	mov	x21, x0
    68c0:	9115c283 	add	x3, x20, #0x570
    68c4:	f949d861 	ldr	x1, [x3, #5040]
    68c8:	f949ec60 	ldr	x0, [x3, #5080]
    68cc:	cb0102a1 	sub	x1, x21, x1
    68d0:	eb00403f 	cmp	x1, x0, lsl #16
    68d4:	54000322 	b.cs	6938 <f0+0xc58>  // b.hs, b.nlast
    68d8:	d350fc22 	lsr	x2, x1, #16
    68dc:	f949fc63 	ldr	x3, [x3, #5112]
    68e0:	8b020842 	add	x2, x2, x2, lsl #2
    68e4:	d37df042 	lsl	x2, x2, #3
    68e8:	8b020060 	add	x0, x3, x2
    68ec:	f9401017 	ldr	x23, [x0, #32]
    68f0:	b4000257 	cbz	x23, 6938 <f0+0xc58>
    68f4:	38626862 	ldrb	w2, [x3, x2]
    68f8:	7100085f 	cmp	w2, #0x2
    68fc:	5400aaa0 	b.eq	7e50 <f0+0x2170>  // b.none
    6900:	7100045f 	cmp	w2, #0x1
    6904:	540001a1 	b.ne	6938 <f0+0xc58>  // b.any
    6908:	29430002 	ldp	w2, w0, [x0, #24]
    690c:	92403c21 	and	x1, x1, #0xffff
    6910:	9b027c21 	mul	x1, x1, x2
    6914:	d360fc21 	lsr	x1, x1, #32
    6918:	eb00003f 	cmp	x1, x0
    691c:	540000e2 	b.cs	6938 <f0+0xc58>  // b.hs, b.nlast
    6920:	8b0102f7 	add	x23, x23, x1
    6924:	394002e0 	ldrb	w0, [x23]
    6928:	7103fc1f 	cmp	w0, #0xff
    692c:	5400b7c0 	b.eq	8024 <f0+0x2344>  // b.none
    6930:	52800020 	mov	w0, #0x1                   	// #1
    6934:	390002e0 	strb	w0, [x23]
    6938:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    693c:	910be3e0 	add	x0, sp, #0x2f8
    6940:	f9017ff7 	str	x23, [sp, #760]
    6944:	f90183f5 	str	x21, [sp, #768]
    6948:	97fff382 	bl	3750 <fwp_data.part.0.constprop.0>
    694c:	97fff2cd 	bl	3480 <fwp_rc_fresh>
    6950:	aa0003e1 	mov	x1, x0
    6954:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6958:	910c23e0 	add	x0, sp, #0x308
    695c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    6960:	f90187f5 	str	x21, [sp, #776]
    6964:	f9018be1 	str	x1, [sp, #784]
    6968:	97fff37a 	bl	3750 <fwp_data.part.0.constprop.0>
    696c:	97fff2c5 	bl	3480 <fwp_rc_fresh>
    6970:	aa0003e1 	mov	x1, x0
    6974:	910c63e0 	add	x0, sp, #0x318
    6978:	f9018ff7 	str	x23, [sp, #792]
    697c:	f90193e1 	str	x1, [sp, #800]
    6980:	97fff374 	bl	3750 <fwp_data.part.0.constprop.0>
    6984:	97fff2bf 	bl	3480 <fwp_rc_fresh>
    6988:	aa0003e1 	mov	x1, x0
    698c:	910ca3e0 	add	x0, sp, #0x328
    6990:	f90197f5 	str	x21, [sp, #808]
    6994:	f9019be1 	str	x1, [sp, #816]
    6998:	97fff36e 	bl	3750 <fwp_data.part.0.constprop.0>
    699c:	aa0003f5 	mov	x21, x0
    69a0:	9115c283 	add	x3, x20, #0x570
    69a4:	f949d861 	ldr	x1, [x3, #5040]
    69a8:	f949ec60 	ldr	x0, [x3, #5080]
    69ac:	cb0102a1 	sub	x1, x21, x1
    69b0:	eb00403f 	cmp	x1, x0, lsl #16
    69b4:	54000322 	b.cs	6a18 <f0+0xd38>  // b.hs, b.nlast
    69b8:	d350fc22 	lsr	x2, x1, #16
    69bc:	f949fc63 	ldr	x3, [x3, #5112]
    69c0:	8b020842 	add	x2, x2, x2, lsl #2
    69c4:	d37df042 	lsl	x2, x2, #3
    69c8:	8b020060 	add	x0, x3, x2
    69cc:	f9401017 	ldr	x23, [x0, #32]
    69d0:	b4000257 	cbz	x23, 6a18 <f0+0xd38>
    69d4:	38626862 	ldrb	w2, [x3, x2]
    69d8:	7100085f 	cmp	w2, #0x2
    69dc:	5400a0a0 	b.eq	7df0 <f0+0x2110>  // b.none
    69e0:	7100045f 	cmp	w2, #0x1
    69e4:	540001a1 	b.ne	6a18 <f0+0xd38>  // b.any
    69e8:	29430002 	ldp	w2, w0, [x0, #24]
    69ec:	92403c21 	and	x1, x1, #0xffff
    69f0:	9b027c21 	mul	x1, x1, x2
    69f4:	d360fc21 	lsr	x1, x1, #32
    69f8:	eb00003f 	cmp	x1, x0
    69fc:	540000e2 	b.cs	6a18 <f0+0xd38>  // b.hs, b.nlast
    6a00:	8b0102f7 	add	x23, x23, x1
    6a04:	394002e0 	ldrb	w0, [x23]
    6a08:	7103fc1f 	cmp	w0, #0xff
    6a0c:	5400b120 	b.eq	8030 <f0+0x2350>  // b.none
    6a10:	52800020 	mov	w0, #0x1                   	// #1
    6a14:	390002e0 	strb	w0, [x23]
    6a18:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6a1c:	910ce3e0 	add	x0, sp, #0x338
    6a20:	f9019fe1 	str	x1, [sp, #824]
    6a24:	f901a3f5 	str	x21, [sp, #832]
    6a28:	97fff34a 	bl	3750 <fwp_data.part.0.constprop.0>
    6a2c:	97fff295 	bl	3480 <fwp_rc_fresh>
    6a30:	aa0003e1 	mov	x1, x0
    6a34:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6a38:	910d23e0 	add	x0, sp, #0x348
    6a3c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6a40:	f901a7e2 	str	x2, [sp, #840]
    6a44:	f901abe1 	str	x1, [sp, #848]
    6a48:	97fff342 	bl	3750 <fwp_data.part.0.constprop.0>
    6a4c:	aa0003f5 	mov	x21, x0
    6a50:	9115c283 	add	x3, x20, #0x570
    6a54:	f949d861 	ldr	x1, [x3, #5040]
    6a58:	f949ec60 	ldr	x0, [x3, #5080]
    6a5c:	cb0102a1 	sub	x1, x21, x1
    6a60:	eb00403f 	cmp	x1, x0, lsl #16
    6a64:	54000322 	b.cs	6ac8 <f0+0xde8>  // b.hs, b.nlast
    6a68:	d350fc22 	lsr	x2, x1, #16
    6a6c:	f949fc63 	ldr	x3, [x3, #5112]
    6a70:	8b020842 	add	x2, x2, x2, lsl #2
    6a74:	d37df042 	lsl	x2, x2, #3
    6a78:	8b020060 	add	x0, x3, x2
    6a7c:	f9401017 	ldr	x23, [x0, #32]
    6a80:	b4000257 	cbz	x23, 6ac8 <f0+0xde8>
    6a84:	38626862 	ldrb	w2, [x3, x2]
    6a88:	7100085f 	cmp	w2, #0x2
    6a8c:	54009ac0 	b.eq	7de4 <f0+0x2104>  // b.none
    6a90:	7100045f 	cmp	w2, #0x1
    6a94:	540001a1 	b.ne	6ac8 <f0+0xde8>  // b.any
    6a98:	29430002 	ldp	w2, w0, [x0, #24]
    6a9c:	92403c21 	and	x1, x1, #0xffff
    6aa0:	9b027c21 	mul	x1, x1, x2
    6aa4:	d360fc21 	lsr	x1, x1, #32
    6aa8:	eb00003f 	cmp	x1, x0
    6aac:	540000e2 	b.cs	6ac8 <f0+0xde8>  // b.hs, b.nlast
    6ab0:	8b0102f7 	add	x23, x23, x1
    6ab4:	394002e0 	ldrb	w0, [x23]
    6ab8:	7103fc1f 	cmp	w0, #0xff
    6abc:	5400ac00 	b.eq	803c <f0+0x235c>  // b.none
    6ac0:	52800020 	mov	w0, #0x1                   	// #1
    6ac4:	390002e0 	strb	w0, [x23]
    6ac8:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6acc:	910d63e0 	add	x0, sp, #0x358
    6ad0:	f901afe1 	str	x1, [sp, #856]
    6ad4:	f901b3f5 	str	x21, [sp, #864]
    6ad8:	97fff31e 	bl	3750 <fwp_data.part.0.constprop.0>
    6adc:	97fff269 	bl	3480 <fwp_rc_fresh>
    6ae0:	aa0003e1 	mov	x1, x0
    6ae4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6ae8:	910da3e0 	add	x0, sp, #0x368
    6aec:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6af0:	f901b7e2 	str	x2, [sp, #872]
    6af4:	f901bbe1 	str	x1, [sp, #880]
    6af8:	97fff316 	bl	3750 <fwp_data.part.0.constprop.0>
    6afc:	aa0003f7 	mov	x23, x0
    6b00:	9115c283 	add	x3, x20, #0x570
    6b04:	f949d861 	ldr	x1, [x3, #5040]
    6b08:	f949ec60 	ldr	x0, [x3, #5080]
    6b0c:	cb0102e1 	sub	x1, x23, x1
    6b10:	eb00403f 	cmp	x1, x0, lsl #16
    6b14:	54000322 	b.cs	6b78 <f0+0xe98>  // b.hs, b.nlast
    6b18:	d350fc22 	lsr	x2, x1, #16
    6b1c:	f949fc63 	ldr	x3, [x3, #5112]
    6b20:	8b020842 	add	x2, x2, x2, lsl #2
    6b24:	d37df042 	lsl	x2, x2, #3
    6b28:	8b020060 	add	x0, x3, x2
    6b2c:	f9401015 	ldr	x21, [x0, #32]
    6b30:	b4000255 	cbz	x21, 6b78 <f0+0xe98>
    6b34:	38626862 	ldrb	w2, [x3, x2]
    6b38:	7100085f 	cmp	w2, #0x2
    6b3c:	540094e0 	b.eq	7dd8 <f0+0x20f8>  // b.none
    6b40:	7100045f 	cmp	w2, #0x1
    6b44:	540001a1 	b.ne	6b78 <f0+0xe98>  // b.any
    6b48:	29430002 	ldp	w2, w0, [x0, #24]
    6b4c:	92403c21 	and	x1, x1, #0xffff
    6b50:	9b027c21 	mul	x1, x1, x2
    6b54:	d360fc21 	lsr	x1, x1, #32
    6b58:	eb00003f 	cmp	x1, x0
    6b5c:	540000e2 	b.cs	6b78 <f0+0xe98>  // b.hs, b.nlast
    6b60:	8b0102b5 	add	x21, x21, x1
    6b64:	394002a0 	ldrb	w0, [x21]
    6b68:	7103fc1f 	cmp	w0, #0xff
    6b6c:	5400a6e0 	b.eq	8048 <f0+0x2368>  // b.none
    6b70:	52800020 	mov	w0, #0x1                   	// #1
    6b74:	390002a0 	strb	w0, [x21]
    6b78:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6b7c:	910de3e0 	add	x0, sp, #0x378
    6b80:	f901bff5 	str	x21, [sp, #888]
    6b84:	f901c3f7 	str	x23, [sp, #896]
    6b88:	97fff2f2 	bl	3750 <fwp_data.part.0.constprop.0>
    6b8c:	97fff23d 	bl	3480 <fwp_rc_fresh>
    6b90:	aa0003e1 	mov	x1, x0
    6b94:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6b98:	910e23e0 	add	x0, sp, #0x388
    6b9c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6ba0:	f901c7f7 	str	x23, [sp, #904]
    6ba4:	f901cbe1 	str	x1, [sp, #912]
    6ba8:	97fff2ea 	bl	3750 <fwp_data.part.0.constprop.0>
    6bac:	97fff235 	bl	3480 <fwp_rc_fresh>
    6bb0:	aa0003e1 	mov	x1, x0
    6bb4:	910e63e0 	add	x0, sp, #0x398
    6bb8:	f901cff5 	str	x21, [sp, #920]
    6bbc:	f901d3e1 	str	x1, [sp, #928]
    6bc0:	97fff2e4 	bl	3750 <fwp_data.part.0.constprop.0>
    6bc4:	97fff22f 	bl	3480 <fwp_rc_fresh>
    6bc8:	aa0003e1 	mov	x1, x0
    6bcc:	910ea3e0 	add	x0, sp, #0x3a8
    6bd0:	f901d7f7 	str	x23, [sp, #936]
    6bd4:	f901dbe1 	str	x1, [sp, #944]
    6bd8:	97fff2de 	bl	3750 <fwp_data.part.0.constprop.0>
    6bdc:	97fff229 	bl	3480 <fwp_rc_fresh>
    6be0:	aa0003e1 	mov	x1, x0
    6be4:	910ee3e0 	add	x0, sp, #0x3b8
    6be8:	f901dff5 	str	x21, [sp, #952]
    6bec:	f901e3e1 	str	x1, [sp, #960]
    6bf0:	97fff2d8 	bl	3750 <fwp_data.part.0.constprop.0>
    6bf4:	97fff223 	bl	3480 <fwp_rc_fresh>
    6bf8:	aa0003e1 	mov	x1, x0
    6bfc:	910f23e0 	add	x0, sp, #0x3c8
    6c00:	f901e7f7 	str	x23, [sp, #968]
    6c04:	f901ebe1 	str	x1, [sp, #976]
    6c08:	97fff2d2 	bl	3750 <fwp_data.part.0.constprop.0>
    6c0c:	97fff21d 	bl	3480 <fwp_rc_fresh>
    6c10:	aa0003e1 	mov	x1, x0
    6c14:	910f63e0 	add	x0, sp, #0x3d8
    6c18:	f901eff5 	str	x21, [sp, #984]
    6c1c:	f901f3e1 	str	x1, [sp, #992]
    6c20:	97fff2cc 	bl	3750 <fwp_data.part.0.constprop.0>
    6c24:	aa0003f5 	mov	x21, x0
    6c28:	9115c283 	add	x3, x20, #0x570
    6c2c:	f949d861 	ldr	x1, [x3, #5040]
    6c30:	f949ec60 	ldr	x0, [x3, #5080]
    6c34:	cb0102a1 	sub	x1, x21, x1
    6c38:	eb00403f 	cmp	x1, x0, lsl #16
    6c3c:	54000322 	b.cs	6ca0 <f0+0xfc0>  // b.hs, b.nlast
    6c40:	d350fc22 	lsr	x2, x1, #16
    6c44:	f949fc63 	ldr	x3, [x3, #5112]
    6c48:	8b020842 	add	x2, x2, x2, lsl #2
    6c4c:	d37df042 	lsl	x2, x2, #3
    6c50:	8b020060 	add	x0, x3, x2
    6c54:	f9401017 	ldr	x23, [x0, #32]
    6c58:	b4000257 	cbz	x23, 6ca0 <f0+0xfc0>
    6c5c:	38626862 	ldrb	w2, [x3, x2]
    6c60:	7100085f 	cmp	w2, #0x2
    6c64:	54008b40 	b.eq	7dcc <f0+0x20ec>  // b.none
    6c68:	7100045f 	cmp	w2, #0x1
    6c6c:	540001a1 	b.ne	6ca0 <f0+0xfc0>  // b.any
    6c70:	29430002 	ldp	w2, w0, [x0, #24]
    6c74:	92403c21 	and	x1, x1, #0xffff
    6c78:	9b027c21 	mul	x1, x1, x2
    6c7c:	d360fc21 	lsr	x1, x1, #32
    6c80:	eb00003f 	cmp	x1, x0
    6c84:	540000e2 	b.cs	6ca0 <f0+0xfc0>  // b.hs, b.nlast
    6c88:	8b0102f7 	add	x23, x23, x1
    6c8c:	394002e0 	ldrb	w0, [x23]
    6c90:	7103fc1f 	cmp	w0, #0xff
    6c94:	54009e00 	b.eq	8054 <f0+0x2374>  // b.none
    6c98:	52800020 	mov	w0, #0x1                   	// #1
    6c9c:	390002e0 	strb	w0, [x23]
    6ca0:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    6ca4:	910fa3e0 	add	x0, sp, #0x3e8
    6ca8:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    6cac:	f901f7e1 	str	x1, [sp, #1000]
    6cb0:	f901fbf5 	str	x21, [sp, #1008]
    6cb4:	97fff2a7 	bl	3750 <fwp_data.part.0.constprop.0>
    6cb8:	aa0003f7 	mov	x23, x0
    6cbc:	9115c283 	add	x3, x20, #0x570
    6cc0:	f949d861 	ldr	x1, [x3, #5040]
    6cc4:	f949ec60 	ldr	x0, [x3, #5080]
    6cc8:	cb0102e1 	sub	x1, x23, x1
    6ccc:	eb00403f 	cmp	x1, x0, lsl #16
    6cd0:	54000322 	b.cs	6d34 <f0+0x1054>  // b.hs, b.nlast
    6cd4:	d350fc22 	lsr	x2, x1, #16
    6cd8:	f949fc63 	ldr	x3, [x3, #5112]
    6cdc:	8b020842 	add	x2, x2, x2, lsl #2
    6ce0:	d37df042 	lsl	x2, x2, #3
    6ce4:	8b020060 	add	x0, x3, x2
    6ce8:	f9401015 	ldr	x21, [x0, #32]
    6cec:	b4000255 	cbz	x21, 6d34 <f0+0x1054>
    6cf0:	38626862 	ldrb	w2, [x3, x2]
    6cf4:	7100085f 	cmp	w2, #0x2
    6cf8:	54008640 	b.eq	7dc0 <f0+0x20e0>  // b.none
    6cfc:	7100045f 	cmp	w2, #0x1
    6d00:	540001a1 	b.ne	6d34 <f0+0x1054>  // b.any
    6d04:	29430002 	ldp	w2, w0, [x0, #24]
    6d08:	92403c21 	and	x1, x1, #0xffff
    6d0c:	9b027c21 	mul	x1, x1, x2
    6d10:	d360fc21 	lsr	x1, x1, #32
    6d14:	eb00003f 	cmp	x1, x0
    6d18:	540000e2 	b.cs	6d34 <f0+0x1054>  // b.hs, b.nlast
    6d1c:	8b0102b5 	add	x21, x21, x1
    6d20:	394002a0 	ldrb	w0, [x21]
    6d24:	7103fc1f 	cmp	w0, #0xff
    6d28:	540099c0 	b.eq	8060 <f0+0x2380>  // b.none
    6d2c:	52800020 	mov	w0, #0x1                   	// #1
    6d30:	390002a0 	strb	w0, [x21]
    6d34:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6d38:	910fe3e0 	add	x0, sp, #0x3f8
    6d3c:	f901fff5 	str	x21, [sp, #1016]
    6d40:	f90203f7 	str	x23, [sp, #1024]
    6d44:	97fff283 	bl	3750 <fwp_data.part.0.constprop.0>
    6d48:	97fff1ce 	bl	3480 <fwp_rc_fresh>
    6d4c:	aa0003e1 	mov	x1, x0
    6d50:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6d54:	911023e0 	add	x0, sp, #0x408
    6d58:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6d5c:	f90207f7 	str	x23, [sp, #1032]
    6d60:	f9020be1 	str	x1, [sp, #1040]
    6d64:	97fff27b 	bl	3750 <fwp_data.part.0.constprop.0>
    6d68:	97fff1c6 	bl	3480 <fwp_rc_fresh>
    6d6c:	aa0003e1 	mov	x1, x0
    6d70:	911063e0 	add	x0, sp, #0x418
    6d74:	f9020ff5 	str	x21, [sp, #1048]
    6d78:	f90213e1 	str	x1, [sp, #1056]
    6d7c:	97fff275 	bl	3750 <fwp_data.part.0.constprop.0>
    6d80:	97fff1c0 	bl	3480 <fwp_rc_fresh>
    6d84:	aa0003e1 	mov	x1, x0
    6d88:	9110a3e0 	add	x0, sp, #0x428
    6d8c:	f90217f7 	str	x23, [sp, #1064]
    6d90:	f9021be1 	str	x1, [sp, #1072]
    6d94:	97fff26f 	bl	3750 <fwp_data.part.0.constprop.0>
    6d98:	97fff1ba 	bl	3480 <fwp_rc_fresh>
    6d9c:	aa0003e1 	mov	x1, x0
    6da0:	9110e3e0 	add	x0, sp, #0x438
    6da4:	f9021ff5 	str	x21, [sp, #1080]
    6da8:	f90223e1 	str	x1, [sp, #1088]
    6dac:	97fff269 	bl	3750 <fwp_data.part.0.constprop.0>
    6db0:	97fff1b4 	bl	3480 <fwp_rc_fresh>
    6db4:	aa0003e1 	mov	x1, x0
    6db8:	911123e0 	add	x0, sp, #0x448
    6dbc:	f90227f7 	str	x23, [sp, #1096]
    6dc0:	f9022be1 	str	x1, [sp, #1104]
    6dc4:	97fff263 	bl	3750 <fwp_data.part.0.constprop.0>
    6dc8:	97fff1ae 	bl	3480 <fwp_rc_fresh>
    6dcc:	aa0003e1 	mov	x1, x0
    6dd0:	911163e0 	add	x0, sp, #0x458
    6dd4:	f9022ff5 	str	x21, [sp, #1112]
    6dd8:	f90233e1 	str	x1, [sp, #1120]
    6ddc:	97fff25d 	bl	3750 <fwp_data.part.0.constprop.0>
    6de0:	97fff1a8 	bl	3480 <fwp_rc_fresh>
    6de4:	aa0003e1 	mov	x1, x0
    6de8:	9111a3e0 	add	x0, sp, #0x468
    6dec:	f90237f7 	str	x23, [sp, #1128]
    6df0:	f9023be1 	str	x1, [sp, #1136]
    6df4:	97fff257 	bl	3750 <fwp_data.part.0.constprop.0>
    6df8:	97fff1a2 	bl	3480 <fwp_rc_fresh>
    6dfc:	aa0003e1 	mov	x1, x0
    6e00:	9111e3e0 	add	x0, sp, #0x478
    6e04:	f9023ff5 	str	x21, [sp, #1144]
    6e08:	f90243e1 	str	x1, [sp, #1152]
    6e0c:	97fff251 	bl	3750 <fwp_data.part.0.constprop.0>
    6e10:	97fff19c 	bl	3480 <fwp_rc_fresh>
    6e14:	aa0003e1 	mov	x1, x0
    6e18:	911223e0 	add	x0, sp, #0x488
    6e1c:	f90247f7 	str	x23, [sp, #1160]
    6e20:	f9024be1 	str	x1, [sp, #1168]
    6e24:	97fff24b 	bl	3750 <fwp_data.part.0.constprop.0>
    6e28:	97fff196 	bl	3480 <fwp_rc_fresh>
    6e2c:	aa0003e1 	mov	x1, x0
    6e30:	911263e0 	add	x0, sp, #0x498
    6e34:	f9024ff5 	str	x21, [sp, #1176]
    6e38:	f90253e1 	str	x1, [sp, #1184]
    6e3c:	97fff245 	bl	3750 <fwp_data.part.0.constprop.0>
    6e40:	aa0003f5 	mov	x21, x0
    6e44:	9115c283 	add	x3, x20, #0x570
    6e48:	f949d861 	ldr	x1, [x3, #5040]
    6e4c:	f949ec60 	ldr	x0, [x3, #5080]
    6e50:	cb0102a1 	sub	x1, x21, x1
    6e54:	eb00403f 	cmp	x1, x0, lsl #16
    6e58:	54000322 	b.cs	6ebc <f0+0x11dc>  // b.hs, b.nlast
    6e5c:	d350fc22 	lsr	x2, x1, #16
    6e60:	f949fc63 	ldr	x3, [x3, #5112]
    6e64:	8b020842 	add	x2, x2, x2, lsl #2
    6e68:	d37df042 	lsl	x2, x2, #3
    6e6c:	8b020060 	add	x0, x3, x2
    6e70:	f9401017 	ldr	x23, [x0, #32]
    6e74:	b4000257 	cbz	x23, 6ebc <f0+0x11dc>
    6e78:	38626862 	ldrb	w2, [x3, x2]
    6e7c:	7100085f 	cmp	w2, #0x2
    6e80:	540079a0 	b.eq	7db4 <f0+0x20d4>  // b.none
    6e84:	7100045f 	cmp	w2, #0x1
    6e88:	540001a1 	b.ne	6ebc <f0+0x11dc>  // b.any
    6e8c:	29430002 	ldp	w2, w0, [x0, #24]
    6e90:	92403c21 	and	x1, x1, #0xffff
    6e94:	9b027c21 	mul	x1, x1, x2
    6e98:	d360fc21 	lsr	x1, x1, #32
    6e9c:	eb00003f 	cmp	x1, x0
    6ea0:	540000e2 	b.cs	6ebc <f0+0x11dc>  // b.hs, b.nlast
    6ea4:	8b0102f7 	add	x23, x23, x1
    6ea8:	394002e0 	ldrb	w0, [x23]
    6eac:	7103fc1f 	cmp	w0, #0xff
    6eb0:	54008de0 	b.eq	806c <f0+0x238c>  // b.none
    6eb4:	52800020 	mov	w0, #0x1                   	// #1
    6eb8:	390002e0 	strb	w0, [x23]
    6ebc:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    6ec0:	9112a3e0 	add	x0, sp, #0x4a8
    6ec4:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    6ec8:	f90257e1 	str	x1, [sp, #1192]
    6ecc:	f9025bf5 	str	x21, [sp, #1200]
    6ed0:	97fff220 	bl	3750 <fwp_data.part.0.constprop.0>
    6ed4:	aa0003f5 	mov	x21, x0
    6ed8:	9115c283 	add	x3, x20, #0x570
    6edc:	f949d861 	ldr	x1, [x3, #5040]
    6ee0:	f949ec60 	ldr	x0, [x3, #5080]
    6ee4:	cb0102a1 	sub	x1, x21, x1
    6ee8:	eb00403f 	cmp	x1, x0, lsl #16
    6eec:	54000322 	b.cs	6f50 <f0+0x1270>  // b.hs, b.nlast
    6ef0:	d350fc22 	lsr	x2, x1, #16
    6ef4:	f949fc63 	ldr	x3, [x3, #5112]
    6ef8:	8b020842 	add	x2, x2, x2, lsl #2
    6efc:	d37df042 	lsl	x2, x2, #3
    6f00:	8b020060 	add	x0, x3, x2
    6f04:	f9401017 	ldr	x23, [x0, #32]
    6f08:	b4000257 	cbz	x23, 6f50 <f0+0x1270>
    6f0c:	38626862 	ldrb	w2, [x3, x2]
    6f10:	7100085f 	cmp	w2, #0x2
    6f14:	540074a0 	b.eq	7da8 <f0+0x20c8>  // b.none
    6f18:	7100045f 	cmp	w2, #0x1
    6f1c:	540001a1 	b.ne	6f50 <f0+0x1270>  // b.any
    6f20:	29430002 	ldp	w2, w0, [x0, #24]
    6f24:	92403c21 	and	x1, x1, #0xffff
    6f28:	9b027c21 	mul	x1, x1, x2
    6f2c:	d360fc21 	lsr	x1, x1, #32
    6f30:	eb00003f 	cmp	x1, x0
    6f34:	540000e2 	b.cs	6f50 <f0+0x1270>  // b.hs, b.nlast
    6f38:	8b0102f7 	add	x23, x23, x1
    6f3c:	394002e0 	ldrb	w0, [x23]
    6f40:	7103fc1f 	cmp	w0, #0xff
    6f44:	540089a0 	b.eq	8078 <f0+0x2398>  // b.none
    6f48:	52800020 	mov	w0, #0x1                   	// #1
    6f4c:	390002e0 	strb	w0, [x23]
    6f50:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6f54:	9112e3e0 	add	x0, sp, #0x4b8
    6f58:	f9025ff7 	str	x23, [sp, #1208]
    6f5c:	f90263f5 	str	x21, [sp, #1216]
    6f60:	97fff1fc 	bl	3750 <fwp_data.part.0.constprop.0>
    6f64:	97fff147 	bl	3480 <fwp_rc_fresh>
    6f68:	aa0003e1 	mov	x1, x0
    6f6c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6f70:	911323e0 	add	x0, sp, #0x4c8
    6f74:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6f78:	f90267e2 	str	x2, [sp, #1224]
    6f7c:	f9026be1 	str	x1, [sp, #1232]
    6f80:	97fff1f4 	bl	3750 <fwp_data.part.0.constprop.0>
    6f84:	97fff13f 	bl	3480 <fwp_rc_fresh>
    6f88:	aa0003e1 	mov	x1, x0
    6f8c:	911363e0 	add	x0, sp, #0x4d8
    6f90:	f9026ff7 	str	x23, [sp, #1240]
    6f94:	f90273e1 	str	x1, [sp, #1248]
    6f98:	97fff1ee 	bl	3750 <fwp_data.part.0.constprop.0>
    6f9c:	aa0003f5 	mov	x21, x0
    6fa0:	9115c283 	add	x3, x20, #0x570
    6fa4:	f949d861 	ldr	x1, [x3, #5040]
    6fa8:	f949ec60 	ldr	x0, [x3, #5080]
    6fac:	cb0102a1 	sub	x1, x21, x1
    6fb0:	eb00403f 	cmp	x1, x0, lsl #16
    6fb4:	54000322 	b.cs	7018 <f0+0x1338>  // b.hs, b.nlast
    6fb8:	d350fc22 	lsr	x2, x1, #16
    6fbc:	f949fc63 	ldr	x3, [x3, #5112]
    6fc0:	8b020842 	add	x2, x2, x2, lsl #2
    6fc4:	d37df042 	lsl	x2, x2, #3
    6fc8:	8b020060 	add	x0, x3, x2
    6fcc:	f9401017 	ldr	x23, [x0, #32]
    6fd0:	b4000257 	cbz	x23, 7018 <f0+0x1338>
    6fd4:	38626862 	ldrb	w2, [x3, x2]
    6fd8:	7100085f 	cmp	w2, #0x2
    6fdc:	54006e00 	b.eq	7d9c <f0+0x20bc>  // b.none
    6fe0:	7100045f 	cmp	w2, #0x1
    6fe4:	540001a1 	b.ne	7018 <f0+0x1338>  // b.any
    6fe8:	29430002 	ldp	w2, w0, [x0, #24]
    6fec:	92403c21 	and	x1, x1, #0xffff
    6ff0:	9b027c21 	mul	x1, x1, x2
    6ff4:	d360fc21 	lsr	x1, x1, #32
    6ff8:	eb00003f 	cmp	x1, x0
    6ffc:	540000e2 	b.cs	7018 <f0+0x1338>  // b.hs, b.nlast
    7000:	8b0102f7 	add	x23, x23, x1
    7004:	394002e0 	ldrb	w0, [x23]
    7008:	7103fc1f 	cmp	w0, #0xff
    700c:	540083c0 	b.eq	8084 <f0+0x23a4>  // b.none
    7010:	52800020 	mov	w0, #0x1                   	// #1
    7014:	390002e0 	strb	w0, [x23]
    7018:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    701c:	9113a3e0 	add	x0, sp, #0x4e8
    7020:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7024:	f90277f7 	str	x23, [sp, #1256]
    7028:	f9027bf5 	str	x21, [sp, #1264]
    702c:	97fff1c9 	bl	3750 <fwp_data.part.0.constprop.0>
    7030:	97fff114 	bl	3480 <fwp_rc_fresh>
    7034:	aa0003e1 	mov	x1, x0
    7038:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    703c:	9113e3e0 	add	x0, sp, #0x4f8
    7040:	f9027ff5 	str	x21, [sp, #1272]
    7044:	f90283e1 	str	x1, [sp, #1280]
    7048:	97fff1c2 	bl	3750 <fwp_data.part.0.constprop.0>
    704c:	97fff10d 	bl	3480 <fwp_rc_fresh>
    7050:	aa0003e1 	mov	x1, x0
    7054:	911423e0 	add	x0, sp, #0x508
    7058:	f90287f7 	str	x23, [sp, #1288]
    705c:	f9028be1 	str	x1, [sp, #1296]
    7060:	97fff1bc 	bl	3750 <fwp_data.part.0.constprop.0>
    7064:	97fff107 	bl	3480 <fwp_rc_fresh>
    7068:	aa0003e1 	mov	x1, x0
    706c:	911463e0 	add	x0, sp, #0x518
    7070:	f9028ff5 	str	x21, [sp, #1304]
    7074:	f90293e1 	str	x1, [sp, #1312]
    7078:	97fff1b6 	bl	3750 <fwp_data.part.0.constprop.0>
    707c:	97fff101 	bl	3480 <fwp_rc_fresh>
    7080:	aa0003e1 	mov	x1, x0
    7084:	9114a3e0 	add	x0, sp, #0x528
    7088:	f90297f7 	str	x23, [sp, #1320]
    708c:	f9029be1 	str	x1, [sp, #1328]
    7090:	97fff1b0 	bl	3750 <fwp_data.part.0.constprop.0>
    7094:	97fff0fb 	bl	3480 <fwp_rc_fresh>
    7098:	aa0003e1 	mov	x1, x0
    709c:	9114e3e0 	add	x0, sp, #0x538
    70a0:	f9029ff5 	str	x21, [sp, #1336]
    70a4:	f902a3e1 	str	x1, [sp, #1344]
    70a8:	97fff1aa 	bl	3750 <fwp_data.part.0.constprop.0>
    70ac:	97fff0f5 	bl	3480 <fwp_rc_fresh>
    70b0:	aa0003e1 	mov	x1, x0
    70b4:	911523e0 	add	x0, sp, #0x548
    70b8:	f902a7f7 	str	x23, [sp, #1352]
    70bc:	f902abe1 	str	x1, [sp, #1360]
    70c0:	97fff1a4 	bl	3750 <fwp_data.part.0.constprop.0>
    70c4:	97fff0ef 	bl	3480 <fwp_rc_fresh>
    70c8:	aa0003e1 	mov	x1, x0
    70cc:	911563e0 	add	x0, sp, #0x558
    70d0:	f902aff5 	str	x21, [sp, #1368]
    70d4:	f902b3e1 	str	x1, [sp, #1376]
    70d8:	97fff19e 	bl	3750 <fwp_data.part.0.constprop.0>
    70dc:	97fff0e9 	bl	3480 <fwp_rc_fresh>
    70e0:	aa0003e1 	mov	x1, x0
    70e4:	9115a3e0 	add	x0, sp, #0x568
    70e8:	f902b7f7 	str	x23, [sp, #1384]
    70ec:	f902bbe1 	str	x1, [sp, #1392]
    70f0:	97fff198 	bl	3750 <fwp_data.part.0.constprop.0>
    70f4:	97fff0e3 	bl	3480 <fwp_rc_fresh>
    70f8:	aa0003e1 	mov	x1, x0
    70fc:	9115e3e0 	add	x0, sp, #0x578
    7100:	f902bff5 	str	x21, [sp, #1400]
    7104:	f902c3e1 	str	x1, [sp, #1408]
    7108:	97fff192 	bl	3750 <fwp_data.part.0.constprop.0>
    710c:	97fff0dd 	bl	3480 <fwp_rc_fresh>
    7110:	aa0003e1 	mov	x1, x0
    7114:	911623e0 	add	x0, sp, #0x588
    7118:	f902c7f7 	str	x23, [sp, #1416]
    711c:	f902cbe1 	str	x1, [sp, #1424]
    7120:	97fff18c 	bl	3750 <fwp_data.part.0.constprop.0>
    7124:	97fff0d7 	bl	3480 <fwp_rc_fresh>
    7128:	aa0003e1 	mov	x1, x0
    712c:	911663e0 	add	x0, sp, #0x598
    7130:	f902cff5 	str	x21, [sp, #1432]
    7134:	f902d3e1 	str	x1, [sp, #1440]
    7138:	97fff186 	bl	3750 <fwp_data.part.0.constprop.0>
    713c:	97fff0d1 	bl	3480 <fwp_rc_fresh>
    7140:	aa0003e1 	mov	x1, x0
    7144:	9116a3e0 	add	x0, sp, #0x5a8
    7148:	f902d7f7 	str	x23, [sp, #1448]
    714c:	f902dbe1 	str	x1, [sp, #1456]
    7150:	97fff180 	bl	3750 <fwp_data.part.0.constprop.0>
    7154:	97fff0cb 	bl	3480 <fwp_rc_fresh>
    7158:	aa0003e1 	mov	x1, x0
    715c:	9116e3e0 	add	x0, sp, #0x5b8
    7160:	f902dff5 	str	x21, [sp, #1464]
    7164:	f902e3e1 	str	x1, [sp, #1472]
    7168:	97fff17a 	bl	3750 <fwp_data.part.0.constprop.0>
    716c:	97fff0c5 	bl	3480 <fwp_rc_fresh>
    7170:	aa0003e1 	mov	x1, x0
    7174:	911723e0 	add	x0, sp, #0x5c8
    7178:	f902e7f7 	str	x23, [sp, #1480]
    717c:	f902ebe1 	str	x1, [sp, #1488]
    7180:	97fff174 	bl	3750 <fwp_data.part.0.constprop.0>
    7184:	97fff0bf 	bl	3480 <fwp_rc_fresh>
    7188:	aa0003e1 	mov	x1, x0
    718c:	911763e0 	add	x0, sp, #0x5d8
    7190:	f902eff5 	str	x21, [sp, #1496]
    7194:	f902f3e1 	str	x1, [sp, #1504]
    7198:	97fff16e 	bl	3750 <fwp_data.part.0.constprop.0>
    719c:	aa0003f5 	mov	x21, x0
    71a0:	9115c283 	add	x3, x20, #0x570
    71a4:	f949d861 	ldr	x1, [x3, #5040]
    71a8:	f949ec60 	ldr	x0, [x3, #5080]
    71ac:	cb0102a1 	sub	x1, x21, x1
    71b0:	eb00403f 	cmp	x1, x0, lsl #16
    71b4:	54000322 	b.cs	7218 <f0+0x1538>  // b.hs, b.nlast
    71b8:	d350fc22 	lsr	x2, x1, #16
    71bc:	f949fc63 	ldr	x3, [x3, #5112]
    71c0:	8b020842 	add	x2, x2, x2, lsl #2
    71c4:	d37df042 	lsl	x2, x2, #3
    71c8:	8b020060 	add	x0, x3, x2
    71cc:	f9401017 	ldr	x23, [x0, #32]
    71d0:	b4000257 	cbz	x23, 7218 <f0+0x1538>
    71d4:	38626862 	ldrb	w2, [x3, x2]
    71d8:	7100085f 	cmp	w2, #0x2
    71dc:	54006c40 	b.eq	7f64 <f0+0x2284>  // b.none
    71e0:	7100045f 	cmp	w2, #0x1
    71e4:	540001a1 	b.ne	7218 <f0+0x1538>  // b.any
    71e8:	29430002 	ldp	w2, w0, [x0, #24]
    71ec:	92403c21 	and	x1, x1, #0xffff
    71f0:	9b027c21 	mul	x1, x1, x2
    71f4:	d360fc21 	lsr	x1, x1, #32
    71f8:	eb00003f 	cmp	x1, x0
    71fc:	540000e2 	b.cs	7218 <f0+0x1538>  // b.hs, b.nlast
    7200:	8b0102f7 	add	x23, x23, x1
    7204:	394002e0 	ldrb	w0, [x23]
    7208:	7103fc1f 	cmp	w0, #0xff
    720c:	54007420 	b.eq	8090 <f0+0x23b0>  // b.none
    7210:	52800020 	mov	w0, #0x1                   	// #1
    7214:	390002e0 	strb	w0, [x23]
    7218:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    721c:	9117a3e0 	add	x0, sp, #0x5e8
    7220:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7224:	f902f7e1 	str	x1, [sp, #1512]
    7228:	f902fbf5 	str	x21, [sp, #1520]
    722c:	97fff149 	bl	3750 <fwp_data.part.0.constprop.0>
    7230:	aa0003f5 	mov	x21, x0
    7234:	9115c283 	add	x3, x20, #0x570
    7238:	f949d861 	ldr	x1, [x3, #5040]
    723c:	f949ec60 	ldr	x0, [x3, #5080]
    7240:	cb0102a1 	sub	x1, x21, x1
    7244:	eb00403f 	cmp	x1, x0, lsl #16
    7248:	54000322 	b.cs	72ac <f0+0x15cc>  // b.hs, b.nlast
    724c:	d350fc22 	lsr	x2, x1, #16
    7250:	f949fc63 	ldr	x3, [x3, #5112]
    7254:	8b020842 	add	x2, x2, x2, lsl #2
    7258:	d37df042 	lsl	x2, x2, #3
    725c:	8b020060 	add	x0, x3, x2
    7260:	f9401017 	ldr	x23, [x0, #32]
    7264:	b4000257 	cbz	x23, 72ac <f0+0x15cc>
    7268:	38626862 	ldrb	w2, [x3, x2]
    726c:	7100085f 	cmp	w2, #0x2
    7270:	54006740 	b.eq	7f58 <f0+0x2278>  // b.none
    7274:	7100045f 	cmp	w2, #0x1
    7278:	540001a1 	b.ne	72ac <f0+0x15cc>  // b.any
    727c:	29430002 	ldp	w2, w0, [x0, #24]
    7280:	92403c21 	and	x1, x1, #0xffff
    7284:	9b027c21 	mul	x1, x1, x2
    7288:	d360fc21 	lsr	x1, x1, #32
    728c:	eb00003f 	cmp	x1, x0
    7290:	540000e2 	b.cs	72ac <f0+0x15cc>  // b.hs, b.nlast
    7294:	8b0102f7 	add	x23, x23, x1
    7298:	394002e0 	ldrb	w0, [x23]
    729c:	7103fc1f 	cmp	w0, #0xff
    72a0:	54006fe0 	b.eq	809c <f0+0x23bc>  // b.none
    72a4:	52800020 	mov	w0, #0x1                   	// #1
    72a8:	390002e0 	strb	w0, [x23]
    72ac:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    72b0:	9117e3e0 	add	x0, sp, #0x5f8
    72b4:	f902fff7 	str	x23, [sp, #1528]
    72b8:	f90303f5 	str	x21, [sp, #1536]
    72bc:	97fff125 	bl	3750 <fwp_data.part.0.constprop.0>
    72c0:	97fff070 	bl	3480 <fwp_rc_fresh>
    72c4:	aa0003e1 	mov	x1, x0
    72c8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    72cc:	911823e0 	add	x0, sp, #0x608
    72d0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    72d4:	f90307f5 	str	x21, [sp, #1544]
    72d8:	f9030be1 	str	x1, [sp, #1552]
    72dc:	97fff11d 	bl	3750 <fwp_data.part.0.constprop.0>
    72e0:	97fff068 	bl	3480 <fwp_rc_fresh>
    72e4:	aa0003e1 	mov	x1, x0
    72e8:	911863e0 	add	x0, sp, #0x618
    72ec:	f9030ff7 	str	x23, [sp, #1560]
    72f0:	f90313e1 	str	x1, [sp, #1568]
    72f4:	97fff117 	bl	3750 <fwp_data.part.0.constprop.0>
    72f8:	97fff062 	bl	3480 <fwp_rc_fresh>
    72fc:	aa0003e1 	mov	x1, x0
    7300:	9118a3e0 	add	x0, sp, #0x628
    7304:	f90317f5 	str	x21, [sp, #1576]
    7308:	f9031be1 	str	x1, [sp, #1584]
    730c:	97fff111 	bl	3750 <fwp_data.part.0.constprop.0>
    7310:	aa0003f5 	mov	x21, x0
    7314:	9115c283 	add	x3, x20, #0x570
    7318:	f949d861 	ldr	x1, [x3, #5040]
    731c:	f949ec60 	ldr	x0, [x3, #5080]
    7320:	cb0102a1 	sub	x1, x21, x1
    7324:	eb00403f 	cmp	x1, x0, lsl #16
    7328:	54000322 	b.cs	738c <f0+0x16ac>  // b.hs, b.nlast
    732c:	d350fc22 	lsr	x2, x1, #16
    7330:	f949fc63 	ldr	x3, [x3, #5112]
    7334:	8b020842 	add	x2, x2, x2, lsl #2
    7338:	d37df042 	lsl	x2, x2, #3
    733c:	8b020060 	add	x0, x3, x2
    7340:	f9401017 	ldr	x23, [x0, #32]
    7344:	b4000257 	cbz	x23, 738c <f0+0x16ac>
    7348:	38626862 	ldrb	w2, [x3, x2]
    734c:	7100085f 	cmp	w2, #0x2
    7350:	54005fe0 	b.eq	7f4c <f0+0x226c>  // b.none
    7354:	7100045f 	cmp	w2, #0x1
    7358:	540001a1 	b.ne	738c <f0+0x16ac>  // b.any
    735c:	29430002 	ldp	w2, w0, [x0, #24]
    7360:	92403c21 	and	x1, x1, #0xffff
    7364:	9b027c21 	mul	x1, x1, x2
    7368:	d360fc21 	lsr	x1, x1, #32
    736c:	eb00003f 	cmp	x1, x0
    7370:	540000e2 	b.cs	738c <f0+0x16ac>  // b.hs, b.nlast
    7374:	8b0102f7 	add	x23, x23, x1
    7378:	394002e0 	ldrb	w0, [x23]
    737c:	7103fc1f 	cmp	w0, #0xff
    7380:	54006940 	b.eq	80a8 <f0+0x23c8>  // b.none
    7384:	52800020 	mov	w0, #0x1                   	// #1
    7388:	390002e0 	strb	w0, [x23]
    738c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7390:	9118e3e0 	add	x0, sp, #0x638
    7394:	f9031ff7 	str	x23, [sp, #1592]
    7398:	f90323f5 	str	x21, [sp, #1600]
    739c:	97fff0ed 	bl	3750 <fwp_data.part.0.constprop.0>
    73a0:	97fff038 	bl	3480 <fwp_rc_fresh>
    73a4:	aa0003e1 	mov	x1, x0
    73a8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    73ac:	911923e0 	add	x0, sp, #0x648
    73b0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    73b4:	f90327e2 	str	x2, [sp, #1608]
    73b8:	f9032be1 	str	x1, [sp, #1616]
    73bc:	97fff0e5 	bl	3750 <fwp_data.part.0.constprop.0>
    73c0:	97fff030 	bl	3480 <fwp_rc_fresh>
    73c4:	aa0003e1 	mov	x1, x0
    73c8:	911963e0 	add	x0, sp, #0x658
    73cc:	f9032ff7 	str	x23, [sp, #1624]
    73d0:	f90333e1 	str	x1, [sp, #1632]
    73d4:	97fff0df 	bl	3750 <fwp_data.part.0.constprop.0>
    73d8:	aa0003f5 	mov	x21, x0
    73dc:	9115c283 	add	x3, x20, #0x570
    73e0:	f949d861 	ldr	x1, [x3, #5040]
    73e4:	f949ec60 	ldr	x0, [x3, #5080]
    73e8:	cb0102a1 	sub	x1, x21, x1
    73ec:	eb00403f 	cmp	x1, x0, lsl #16
    73f0:	54000322 	b.cs	7454 <f0+0x1774>  // b.hs, b.nlast
    73f4:	d350fc22 	lsr	x2, x1, #16
    73f8:	f949fc63 	ldr	x3, [x3, #5112]
    73fc:	8b020842 	add	x2, x2, x2, lsl #2
    7400:	d37df042 	lsl	x2, x2, #3
    7404:	8b020060 	add	x0, x3, x2
    7408:	f9401017 	ldr	x23, [x0, #32]
    740c:	b4000257 	cbz	x23, 7454 <f0+0x1774>
    7410:	38626862 	ldrb	w2, [x3, x2]
    7414:	7100085f 	cmp	w2, #0x2
    7418:	54005940 	b.eq	7f40 <f0+0x2260>  // b.none
    741c:	7100045f 	cmp	w2, #0x1
    7420:	540001a1 	b.ne	7454 <f0+0x1774>  // b.any
    7424:	29430002 	ldp	w2, w0, [x0, #24]
    7428:	92403c21 	and	x1, x1, #0xffff
    742c:	9b027c21 	mul	x1, x1, x2
    7430:	d360fc21 	lsr	x1, x1, #32
    7434:	eb00003f 	cmp	x1, x0
    7438:	540000e2 	b.cs	7454 <f0+0x1774>  // b.hs, b.nlast
    743c:	8b0102f7 	add	x23, x23, x1
    7440:	394002e0 	ldrb	w0, [x23]
    7444:	7103fc1f 	cmp	w0, #0xff
    7448:	54006360 	b.eq	80b4 <f0+0x23d4>  // b.none
    744c:	52800020 	mov	w0, #0x1                   	// #1
    7450:	390002e0 	strb	w0, [x23]
    7454:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    7458:	9119a3e0 	add	x0, sp, #0x668
    745c:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7460:	f90337e1 	str	x1, [sp, #1640]
    7464:	f9033bf5 	str	x21, [sp, #1648]
    7468:	97fff0ba 	bl	3750 <fwp_data.part.0.constprop.0>
    746c:	aa0003f5 	mov	x21, x0
    7470:	9115c283 	add	x3, x20, #0x570
    7474:	f949d861 	ldr	x1, [x3, #5040]
    7478:	f949ec60 	ldr	x0, [x3, #5080]
    747c:	cb0102a1 	sub	x1, x21, x1
    7480:	eb00403f 	cmp	x1, x0, lsl #16
    7484:	54000322 	b.cs	74e8 <f0+0x1808>  // b.hs, b.nlast
    7488:	d350fc22 	lsr	x2, x1, #16
    748c:	f949fc63 	ldr	x3, [x3, #5112]
    7490:	8b020842 	add	x2, x2, x2, lsl #2
    7494:	d37df042 	lsl	x2, x2, #3
    7498:	8b020060 	add	x0, x3, x2
    749c:	f9401017 	ldr	x23, [x0, #32]
    74a0:	b4000257 	cbz	x23, 74e8 <f0+0x1808>
    74a4:	38626862 	ldrb	w2, [x3, x2]
    74a8:	7100085f 	cmp	w2, #0x2
    74ac:	54005440 	b.eq	7f34 <f0+0x2254>  // b.none
    74b0:	7100045f 	cmp	w2, #0x1
    74b4:	540001a1 	b.ne	74e8 <f0+0x1808>  // b.any
    74b8:	29430002 	ldp	w2, w0, [x0, #24]
    74bc:	92403c21 	and	x1, x1, #0xffff
    74c0:	9b027c21 	mul	x1, x1, x2
    74c4:	d360fc21 	lsr	x1, x1, #32
    74c8:	eb00003f 	cmp	x1, x0
    74cc:	540000e2 	b.cs	74e8 <f0+0x1808>  // b.hs, b.nlast
    74d0:	8b0102f7 	add	x23, x23, x1
    74d4:	394002e0 	ldrb	w0, [x23]
    74d8:	7103fc1f 	cmp	w0, #0xff
    74dc:	54005f20 	b.eq	80c0 <f0+0x23e0>  // b.none
    74e0:	52800020 	mov	w0, #0x1                   	// #1
    74e4:	390002e0 	strb	w0, [x23]
    74e8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    74ec:	9119e3e0 	add	x0, sp, #0x678
    74f0:	f9033ff7 	str	x23, [sp, #1656]
    74f4:	f90343f5 	str	x21, [sp, #1664]
    74f8:	97fff096 	bl	3750 <fwp_data.part.0.constprop.0>
    74fc:	97ffefe1 	bl	3480 <fwp_rc_fresh>
    7500:	aa0003e1 	mov	x1, x0
    7504:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    7508:	911a23e0 	add	x0, sp, #0x688
    750c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    7510:	f90347f5 	str	x21, [sp, #1672]
    7514:	f9034be1 	str	x1, [sp, #1680]
    7518:	97fff08e 	bl	3750 <fwp_data.part.0.constprop.0>
    751c:	97ffefd9 	bl	3480 <fwp_rc_fresh>
    7520:	aa0003e1 	mov	x1, x0
    7524:	911a63e0 	add	x0, sp, #0x698
    7528:	f9034ff7 	str	x23, [sp, #1688]
    752c:	f90353e1 	str	x1, [sp, #1696]
    7530:	97fff088 	bl	3750 <fwp_data.part.0.constprop.0>
    7534:	97ffefd3 	bl	3480 <fwp_rc_fresh>
    7538:	aa0003e1 	mov	x1, x0
    753c:	911aa3e0 	add	x0, sp, #0x6a8
    7540:	f90357f5 	str	x21, [sp, #1704]
    7544:	f9035be1 	str	x1, [sp, #1712]
    7548:	97fff082 	bl	3750 <fwp_data.part.0.constprop.0>
    754c:	aa0003f5 	mov	x21, x0
    7550:	9115c283 	add	x3, x20, #0x570
    7554:	f949d861 	ldr	x1, [x3, #5040]
    7558:	f949ec60 	ldr	x0, [x3, #5080]
    755c:	cb0102a1 	sub	x1, x21, x1
    7560:	eb00403f 	cmp	x1, x0, lsl #16
    7564:	54000322 	b.cs	75c8 <f0+0x18e8>  // b.hs, b.nlast
    7568:	d350fc22 	lsr	x2, x1, #16
    756c:	f949fc63 	ldr	x3, [x3, #5112]
    7570:	8b020842 	add	x2, x2, x2, lsl #2
    7574:	d37df042 	lsl	x2, x2, #3
    7578:	8b020060 	add	x0, x3, x2
    757c:	f9401017 	ldr	x23, [x0, #32]
    7580:	b4000257 	cbz	x23, 75c8 <f0+0x18e8>
    7584:	38626862 	ldrb	w2, [x3, x2]
    7588:	7100085f 	cmp	w2, #0x2
    758c:	54004ce0 	b.eq	7f28 <f0+0x2248>  // b.none
    7590:	7100045f 	cmp	w2, #0x1
    7594:	540001a1 	b.ne	75c8 <f0+0x18e8>  // b.any
    7598:	29430002 	ldp	w2, w0, [x0, #24]
    759c:	92403c21 	and	x1, x1, #0xffff
    75a0:	9b027c21 	mul	x1, x1, x2
    75a4:	d360fc21 	lsr	x1, x1, #32
    75a8:	eb00003f 	cmp	x1, x0
    75ac:	540000e2 	b.cs	75c8 <f0+0x18e8>  // b.hs, b.nlast
    75b0:	8b0102f7 	add	x23, x23, x1
    75b4:	394002e0 	ldrb	w0, [x23]
    75b8:	7103fc1f 	cmp	w0, #0xff
    75bc:	54005880 	b.eq	80cc <f0+0x23ec>  // b.none
    75c0:	52800020 	mov	w0, #0x1                   	// #1
    75c4:	390002e0 	strb	w0, [x23]
    75c8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    75cc:	911ae3e0 	add	x0, sp, #0x6b8
    75d0:	f9035ff7 	str	x23, [sp, #1720]
    75d4:	f90363f5 	str	x21, [sp, #1728]
    75d8:	97fff05e 	bl	3750 <fwp_data.part.0.constprop.0>
    75dc:	97ffefa9 	bl	3480 <fwp_rc_fresh>
    75e0:	aa0003e1 	mov	x1, x0
    75e4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    75e8:	911b23e0 	add	x0, sp, #0x6c8
    75ec:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    75f0:	f90367e2 	str	x2, [sp, #1736]
    75f4:	f9036be1 	str	x1, [sp, #1744]
    75f8:	97fff056 	bl	3750 <fwp_data.part.0.constprop.0>
    75fc:	97ffefa1 	bl	3480 <fwp_rc_fresh>
    7600:	aa0003e1 	mov	x1, x0
    7604:	911b63e0 	add	x0, sp, #0x6d8
    7608:	f9036ff7 	str	x23, [sp, #1752]
    760c:	f90373e1 	str	x1, [sp, #1760]
    7610:	97fff050 	bl	3750 <fwp_data.part.0.constprop.0>
    7614:	aa0003f5 	mov	x21, x0
    7618:	9115c283 	add	x3, x20, #0x570
    761c:	f949d861 	ldr	x1, [x3, #5040]
    7620:	f949ec60 	ldr	x0, [x3, #5080]
    7624:	cb0102a1 	sub	x1, x21, x1
    7628:	eb00403f 	cmp	x1, x0, lsl #16
    762c:	54000322 	b.cs	7690 <f0+0x19b0>  // b.hs, b.nlast
    7630:	d350fc22 	lsr	x2, x1, #16
    7634:	f949fc63 	ldr	x3, [x3, #5112]
    7638:	8b020842 	add	x2, x2, x2, lsl #2
    763c:	d37df042 	lsl	x2, x2, #3
    7640:	8b020060 	add	x0, x3, x2
    7644:	f9401017 	ldr	x23, [x0, #32]
    7648:	b4000257 	cbz	x23, 7690 <f0+0x19b0>
    764c:	38626862 	ldrb	w2, [x3, x2]
    7650:	7100085f 	cmp	w2, #0x2
    7654:	54004640 	b.eq	7f1c <f0+0x223c>  // b.none
    7658:	7100045f 	cmp	w2, #0x1
    765c:	540001a1 	b.ne	7690 <f0+0x19b0>  // b.any
    7660:	29430002 	ldp	w2, w0, [x0, #24]
    7664:	92403c21 	and	x1, x1, #0xffff
    7668:	9b027c21 	mul	x1, x1, x2
    766c:	d360fc21 	lsr	x1, x1, #32
    7670:	eb00003f 	cmp	x1, x0
    7674:	540000e2 	b.cs	7690 <f0+0x19b0>  // b.hs, b.nlast
    7678:	8b0102f7 	add	x23, x23, x1
    767c:	394002e0 	ldrb	w0, [x23]
    7680:	7103fc1f 	cmp	w0, #0xff
    7684:	540052a0 	b.eq	80d8 <f0+0x23f8>  // b.none
    7688:	52800020 	mov	w0, #0x1                   	// #1
    768c:	390002e0 	strb	w0, [x23]
    7690:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7694:	911ba3e0 	add	x0, sp, #0x6e8
    7698:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    769c:	f90377f7 	str	x23, [sp, #1768]
    76a0:	f9037bf5 	str	x21, [sp, #1776]
    76a4:	97fff02b 	bl	3750 <fwp_data.part.0.constprop.0>
    76a8:	97ffef76 	bl	3480 <fwp_rc_fresh>
    76ac:	aa0003e1 	mov	x1, x0
    76b0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    76b4:	911be3e0 	add	x0, sp, #0x6f8
    76b8:	f9037ff5 	str	x21, [sp, #1784]
    76bc:	f90383e1 	str	x1, [sp, #1792]
    76c0:	97fff024 	bl	3750 <fwp_data.part.0.constprop.0>
    76c4:	97ffef6f 	bl	3480 <fwp_rc_fresh>
    76c8:	aa0003e1 	mov	x1, x0
    76cc:	911c23e0 	add	x0, sp, #0x708
    76d0:	f90387f7 	str	x23, [sp, #1800]
    76d4:	f9038be1 	str	x1, [sp, #1808]
    76d8:	97fff01e 	bl	3750 <fwp_data.part.0.constprop.0>
    76dc:	97ffef69 	bl	3480 <fwp_rc_fresh>
    76e0:	aa0003e1 	mov	x1, x0
    76e4:	911c63e0 	add	x0, sp, #0x718
    76e8:	f9038ff5 	str	x21, [sp, #1816]
    76ec:	f90393e1 	str	x1, [sp, #1824]
    76f0:	97fff018 	bl	3750 <fwp_data.part.0.constprop.0>
    76f4:	97ffef63 	bl	3480 <fwp_rc_fresh>
    76f8:	aa0003e1 	mov	x1, x0
    76fc:	911ca3e0 	add	x0, sp, #0x728
    7700:	f90397f7 	str	x23, [sp, #1832]
    7704:	f9039be1 	str	x1, [sp, #1840]
    7708:	97fff012 	bl	3750 <fwp_data.part.0.constprop.0>
    770c:	aa0003f5 	mov	x21, x0
    7710:	9115c283 	add	x3, x20, #0x570
    7714:	f949d861 	ldr	x1, [x3, #5040]
    7718:	f949ec60 	ldr	x0, [x3, #5080]
    771c:	cb0102a1 	sub	x1, x21, x1
    7720:	eb00403f 	cmp	x1, x0, lsl #16
    7724:	54000322 	b.cs	7788 <f0+0x1aa8>  // b.hs, b.nlast
    7728:	d350fc22 	lsr	x2, x1, #16
    772c:	f949fc63 	ldr	x3, [x3, #5112]
    7730:	8b020842 	add	x2, x2, x2, lsl #2
    7734:	d37df042 	lsl	x2, x2, #3
    7738:	8b020060 	add	x0, x3, x2
    773c:	f9401017 	ldr	x23, [x0, #32]
    7740:	b4000257 	cbz	x23, 7788 <f0+0x1aa8>
    7744:	38626862 	ldrb	w2, [x3, x2]
    7748:	7100085f 	cmp	w2, #0x2
    774c:	54003e20 	b.eq	7f10 <f0+0x2230>  // b.none
    7750:	7100045f 	cmp	w2, #0x1
    7754:	540001a1 	b.ne	7788 <f0+0x1aa8>  // b.any
    7758:	29430002 	ldp	w2, w0, [x0, #24]
    775c:	92403c21 	and	x1, x1, #0xffff
    7760:	9b027c21 	mul	x1, x1, x2
    7764:	d360fc21 	lsr	x1, x1, #32
    7768:	eb00003f 	cmp	x1, x0
    776c:	540000e2 	b.cs	7788 <f0+0x1aa8>  // b.hs, b.nlast
    7770:	8b0102f7 	add	x23, x23, x1
    7774:	394002e0 	ldrb	w0, [x23]
    7778:	7103fc1f 	cmp	w0, #0xff
    777c:	54004b40 	b.eq	80e4 <f0+0x2404>  // b.none
    7780:	52800020 	mov	w0, #0x1                   	// #1
    7784:	390002e0 	strb	w0, [x23]
    7788:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    778c:	911ce3e0 	add	x0, sp, #0x738
    7790:	f9039ff7 	str	x23, [sp, #1848]
    7794:	f903a3f5 	str	x21, [sp, #1856]
    7798:	97ffefee 	bl	3750 <fwp_data.part.0.constprop.0>
    779c:	97ffef39 	bl	3480 <fwp_rc_fresh>
    77a0:	aa0003e1 	mov	x1, x0
    77a4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    77a8:	911d23e0 	add	x0, sp, #0x748
    77ac:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    77b0:	f903a7e2 	str	x2, [sp, #1864]
    77b4:	f903abe1 	str	x1, [sp, #1872]
    77b8:	97ffefe6 	bl	3750 <fwp_data.part.0.constprop.0>
    77bc:	97ffef31 	bl	3480 <fwp_rc_fresh>
    77c0:	aa0003e1 	mov	x1, x0
    77c4:	911d63e0 	add	x0, sp, #0x758
    77c8:	f903aff7 	str	x23, [sp, #1880]
    77cc:	f903b3e1 	str	x1, [sp, #1888]
    77d0:	97ffefe0 	bl	3750 <fwp_data.part.0.constprop.0>
    77d4:	aa0003f5 	mov	x21, x0
    77d8:	9115c283 	add	x3, x20, #0x570
    77dc:	f949d861 	ldr	x1, [x3, #5040]
    77e0:	f949ec60 	ldr	x0, [x3, #5080]
    77e4:	cb0102a1 	sub	x1, x21, x1
    77e8:	eb00403f 	cmp	x1, x0, lsl #16
    77ec:	54000322 	b.cs	7850 <f0+0x1b70>  // b.hs, b.nlast
    77f0:	d350fc22 	lsr	x2, x1, #16
    77f4:	f949fc63 	ldr	x3, [x3, #5112]
    77f8:	8b020842 	add	x2, x2, x2, lsl #2
    77fc:	d37df042 	lsl	x2, x2, #3
    7800:	8b020060 	add	x0, x3, x2
    7804:	f9401017 	ldr	x23, [x0, #32]
    7808:	b4000257 	cbz	x23, 7850 <f0+0x1b70>
    780c:	38626862 	ldrb	w2, [x3, x2]
    7810:	7100085f 	cmp	w2, #0x2
    7814:	54003780 	b.eq	7f04 <f0+0x2224>  // b.none
    7818:	7100045f 	cmp	w2, #0x1
    781c:	540001a1 	b.ne	7850 <f0+0x1b70>  // b.any
    7820:	29430002 	ldp	w2, w0, [x0, #24]
    7824:	92403c21 	and	x1, x1, #0xffff
    7828:	9b027c21 	mul	x1, x1, x2
    782c:	d360fc21 	lsr	x1, x1, #32
    7830:	eb00003f 	cmp	x1, x0
    7834:	540000e2 	b.cs	7850 <f0+0x1b70>  // b.hs, b.nlast
    7838:	8b0102f7 	add	x23, x23, x1
    783c:	394002e0 	ldrb	w0, [x23]
    7840:	7103fc1f 	cmp	w0, #0xff
    7844:	54004560 	b.eq	80f0 <f0+0x2410>  // b.none
    7848:	52800020 	mov	w0, #0x1                   	// #1
    784c:	390002e0 	strb	w0, [x23]
    7850:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7854:	911da3e0 	add	x0, sp, #0x768
    7858:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    785c:	f903b7f7 	str	x23, [sp, #1896]
    7860:	f903bbf5 	str	x21, [sp, #1904]
    7864:	97ffefbb 	bl	3750 <fwp_data.part.0.constprop.0>
    7868:	97ffef06 	bl	3480 <fwp_rc_fresh>
    786c:	aa0003e1 	mov	x1, x0
    7870:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7874:	911de3e0 	add	x0, sp, #0x778
    7878:	f903bfe2 	str	x2, [sp, #1912]
    787c:	f903c3e1 	str	x1, [sp, #1920]
    7880:	97ffefb4 	bl	3750 <fwp_data.part.0.constprop.0>
    7884:	97ffeeff 	bl	3480 <fwp_rc_fresh>
    7888:	aa0003e1 	mov	x1, x0
    788c:	911e23e0 	add	x0, sp, #0x788
    7890:	f903c7f7 	str	x23, [sp, #1928]
    7894:	f903cbe1 	str	x1, [sp, #1936]
    7898:	97ffefae 	bl	3750 <fwp_data.part.0.constprop.0>
    789c:	aa0003f5 	mov	x21, x0
    78a0:	9115c283 	add	x3, x20, #0x570
    78a4:	f949d861 	ldr	x1, [x3, #5040]
    78a8:	f949ec60 	ldr	x0, [x3, #5080]
    78ac:	cb0102a1 	sub	x1, x21, x1
    78b0:	eb00403f 	cmp	x1, x0, lsl #16
    78b4:	54000322 	b.cs	7918 <f0+0x1c38>  // b.hs, b.nlast
    78b8:	d350fc22 	lsr	x2, x1, #16
    78bc:	f949fc63 	ldr	x3, [x3, #5112]
    78c0:	8b020842 	add	x2, x2, x2, lsl #2
    78c4:	d37df042 	lsl	x2, x2, #3
    78c8:	8b020060 	add	x0, x3, x2
    78cc:	f9401017 	ldr	x23, [x0, #32]
    78d0:	b4000257 	cbz	x23, 7918 <f0+0x1c38>
    78d4:	38626862 	ldrb	w2, [x3, x2]
    78d8:	7100085f 	cmp	w2, #0x2
    78dc:	540030e0 	b.eq	7ef8 <f0+0x2218>  // b.none
    78e0:	7100045f 	cmp	w2, #0x1
    78e4:	540001a1 	b.ne	7918 <f0+0x1c38>  // b.any
    78e8:	29430002 	ldp	w2, w0, [x0, #24]
    78ec:	92403c21 	and	x1, x1, #0xffff
    78f0:	9b027c21 	mul	x1, x1, x2
    78f4:	d360fc21 	lsr	x1, x1, #32
    78f8:	eb00003f 	cmp	x1, x0
    78fc:	540000e2 	b.cs	7918 <f0+0x1c38>  // b.hs, b.nlast
    7900:	8b0102f7 	add	x23, x23, x1
    7904:	394002e0 	ldrb	w0, [x23]
    7908:	7103fc1f 	cmp	w0, #0xff
    790c:	54003f80 	b.eq	80fc <f0+0x241c>  // b.none
    7910:	52800020 	mov	w0, #0x1                   	// #1
    7914:	390002e0 	strb	w0, [x23]
    7918:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    791c:	911e63e0 	add	x0, sp, #0x798
    7920:	f903cff7 	str	x23, [sp, #1944]
    7924:	f903d3f5 	str	x21, [sp, #1952]
    7928:	97ffef8a 	bl	3750 <fwp_data.part.0.constprop.0>
    792c:	97ffeed5 	bl	3480 <fwp_rc_fresh>
    7930:	aa0003e1 	mov	x1, x0
    7934:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7938:	911ea3e0 	add	x0, sp, #0x7a8
    793c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7940:	f903d7e2 	str	x2, [sp, #1960]
    7944:	f903dbe1 	str	x1, [sp, #1968]
    7948:	97ffef82 	bl	3750 <fwp_data.part.0.constprop.0>
    794c:	97ffeecd 	bl	3480 <fwp_rc_fresh>
    7950:	aa0003e1 	mov	x1, x0
    7954:	911ee3e0 	add	x0, sp, #0x7b8
    7958:	f903dff7 	str	x23, [sp, #1976]
    795c:	f903e3e1 	str	x1, [sp, #1984]
    7960:	97ffef7c 	bl	3750 <fwp_data.part.0.constprop.0>
    7964:	aa0003f5 	mov	x21, x0
    7968:	9115c283 	add	x3, x20, #0x570
    796c:	f949d861 	ldr	x1, [x3, #5040]
    7970:	f949ec60 	ldr	x0, [x3, #5080]
    7974:	cb0102a1 	sub	x1, x21, x1
    7978:	eb00403f 	cmp	x1, x0, lsl #16
    797c:	54000322 	b.cs	79e0 <f0+0x1d00>  // b.hs, b.nlast
    7980:	d350fc22 	lsr	x2, x1, #16
    7984:	f949fc63 	ldr	x3, [x3, #5112]
    7988:	8b020842 	add	x2, x2, x2, lsl #2
    798c:	d37df042 	lsl	x2, x2, #3
    7990:	8b020060 	add	x0, x3, x2
    7994:	f9401017 	ldr	x23, [x0, #32]
    7998:	b4000257 	cbz	x23, 79e0 <f0+0x1d00>
    799c:	38626862 	ldrb	w2, [x3, x2]
    79a0:	7100085f 	cmp	w2, #0x2
    79a4:	54002a40 	b.eq	7eec <f0+0x220c>  // b.none
    79a8:	7100045f 	cmp	w2, #0x1
    79ac:	540001a1 	b.ne	79e0 <f0+0x1d00>  // b.any
    79b0:	29430002 	ldp	w2, w0, [x0, #24]
    79b4:	92403c21 	and	x1, x1, #0xffff
    79b8:	9b027c21 	mul	x1, x1, x2
    79bc:	d360fc21 	lsr	x1, x1, #32
    79c0:	eb00003f 	cmp	x1, x0
    79c4:	540000e2 	b.cs	79e0 <f0+0x1d00>  // b.hs, b.nlast
    79c8:	8b0102f7 	add	x23, x23, x1
    79cc:	394002e0 	ldrb	w0, [x23]
    79d0:	7103fc1f 	cmp	w0, #0xff
    79d4:	540039a0 	b.eq	8108 <f0+0x2428>  // b.none
    79d8:	52800020 	mov	w0, #0x1                   	// #1
    79dc:	390002e0 	strb	w0, [x23]
    79e0:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    79e4:	911f23e0 	add	x0, sp, #0x7c8
    79e8:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    79ec:	f903e7e1 	str	x1, [sp, #1992]
    79f0:	f903ebf5 	str	x21, [sp, #2000]
    79f4:	97ffef57 	bl	3750 <fwp_data.part.0.constprop.0>
    79f8:	aa0003f5 	mov	x21, x0
    79fc:	9115c283 	add	x3, x20, #0x570
    7a00:	f949d861 	ldr	x1, [x3, #5040]
    7a04:	f949ec60 	ldr	x0, [x3, #5080]
    7a08:	cb0102a1 	sub	x1, x21, x1
    7a0c:	eb00403f 	cmp	x1, x0, lsl #16
    7a10:	54000322 	b.cs	7a74 <f0+0x1d94>  // b.hs, b.nlast
    7a14:	d350fc22 	lsr	x2, x1, #16
    7a18:	f949fc63 	ldr	x3, [x3, #5112]
    7a1c:	8b020842 	add	x2, x2, x2, lsl #2
    7a20:	d37df042 	lsl	x2, x2, #3
    7a24:	8b020060 	add	x0, x3, x2
    7a28:	f9401017 	ldr	x23, [x0, #32]
    7a2c:	b4000257 	cbz	x23, 7a74 <f0+0x1d94>
    7a30:	38626862 	ldrb	w2, [x3, x2]
    7a34:	7100085f 	cmp	w2, #0x2
    7a38:	54002540 	b.eq	7ee0 <f0+0x2200>  // b.none
    7a3c:	7100045f 	cmp	w2, #0x1
    7a40:	540001a1 	b.ne	7a74 <f0+0x1d94>  // b.any
    7a44:	29430002 	ldp	w2, w0, [x0, #24]
    7a48:	92403c21 	and	x1, x1, #0xffff
    7a4c:	9b027c21 	mul	x1, x1, x2
    7a50:	d360fc21 	lsr	x1, x1, #32
    7a54:	eb00003f 	cmp	x1, x0
    7a58:	540000e2 	b.cs	7a74 <f0+0x1d94>  // b.hs, b.nlast
    7a5c:	8b0102f7 	add	x23, x23, x1
    7a60:	394002e0 	ldrb	w0, [x23]
    7a64:	7103fc1f 	cmp	w0, #0xff
    7a68:	54003560 	b.eq	8114 <f0+0x2434>  // b.none
    7a6c:	52800020 	mov	w0, #0x1                   	// #1
    7a70:	390002e0 	strb	w0, [x23]
    7a74:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    7a78:	911f63e0 	add	x0, sp, #0x7d8
    7a7c:	f903efe1 	str	x1, [sp, #2008]
    7a80:	f903f3f5 	str	x21, [sp, #2016]
    7a84:	97ffef33 	bl	3750 <fwp_data.part.0.constprop.0>
    7a88:	9115c283 	add	x3, x20, #0x570
    7a8c:	aa0003f5 	mov	x21, x0
    7a90:	f949d861 	ldr	x1, [x3, #5040]
    7a94:	f949ec60 	ldr	x0, [x3, #5080]
    7a98:	cb0102a1 	sub	x1, x21, x1
    7a9c:	eb00403f 	cmp	x1, x0, lsl #16
    7aa0:	54000322 	b.cs	7b04 <f0+0x1e24>  // b.hs, b.nlast
    7aa4:	d350fc22 	lsr	x2, x1, #16
    7aa8:	f949fc63 	ldr	x3, [x3, #5112]
    7aac:	8b020842 	add	x2, x2, x2, lsl #2
    7ab0:	d37df042 	lsl	x2, x2, #3
    7ab4:	8b020060 	add	x0, x3, x2
    7ab8:	f9401017 	ldr	x23, [x0, #32]
    7abc:	b4000257 	cbz	x23, 7b04 <f0+0x1e24>
    7ac0:	38626862 	ldrb	w2, [x3, x2]
    7ac4:	7100085f 	cmp	w2, #0x2
    7ac8:	54002060 	b.eq	7ed4 <f0+0x21f4>  // b.none
    7acc:	7100045f 	cmp	w2, #0x1
    7ad0:	540001a1 	b.ne	7b04 <f0+0x1e24>  // b.any
    7ad4:	29430002 	ldp	w2, w0, [x0, #24]
    7ad8:	92403c21 	and	x1, x1, #0xffff
    7adc:	9b027c21 	mul	x1, x1, x2
    7ae0:	d360fc21 	lsr	x1, x1, #32
    7ae4:	eb00003f 	cmp	x1, x0
    7ae8:	540000e2 	b.cs	7b04 <f0+0x1e24>  // b.hs, b.nlast
    7aec:	8b0102f7 	add	x23, x23, x1
    7af0:	394002e0 	ldrb	w0, [x23]
    7af4:	7103fc1f 	cmp	w0, #0xff
    7af8:	54003140 	b.eq	8120 <f0+0x2440>  // b.none
    7afc:	52800020 	mov	w0, #0x1                   	// #1
    7b00:	390002e0 	strb	w0, [x23]
    7b04:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    7b08:	911fa3e0 	add	x0, sp, #0x7e8
    7b0c:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7b10:	f903f7e1 	str	x1, [sp, #2024]
    7b14:	f903fbf5 	str	x21, [sp, #2032]
    7b18:	97ffef0e 	bl	3750 <fwp_data.part.0.constprop.0>
    7b1c:	aa0003f5 	mov	x21, x0
    7b20:	9115c283 	add	x3, x20, #0x570
    7b24:	f949d861 	ldr	x1, [x3, #5040]
    7b28:	f949ec60 	ldr	x0, [x3, #5080]
    7b2c:	cb0102a1 	sub	x1, x21, x1
    7b30:	eb00403f 	cmp	x1, x0, lsl #16
    7b34:	54000322 	b.cs	7b98 <f0+0x1eb8>  // b.hs, b.nlast
    7b38:	d350fc22 	lsr	x2, x1, #16
    7b3c:	f949fc63 	ldr	x3, [x3, #5112]
    7b40:	8b020842 	add	x2, x2, x2, lsl #2
    7b44:	d37df042 	lsl	x2, x2, #3
    7b48:	8b020060 	add	x0, x3, x2
    7b4c:	f9401017 	ldr	x23, [x0, #32]
    7b50:	b4000257 	cbz	x23, 7b98 <f0+0x1eb8>
    7b54:	38626862 	ldrb	w2, [x3, x2]
    7b58:	7100085f 	cmp	w2, #0x2
    7b5c:	54001b60 	b.eq	7ec8 <f0+0x21e8>  // b.none
    7b60:	7100045f 	cmp	w2, #0x1
    7b64:	540001a1 	b.ne	7b98 <f0+0x1eb8>  // b.any
    7b68:	29430002 	ldp	w2, w0, [x0, #24]
    7b6c:	92403c21 	and	x1, x1, #0xffff
    7b70:	9b027c21 	mul	x1, x1, x2
    7b74:	d360fc21 	lsr	x1, x1, #32
    7b78:	eb00003f 	cmp	x1, x0
    7b7c:	540000e2 	b.cs	7b98 <f0+0x1eb8>  // b.hs, b.nlast
    7b80:	8b0102f7 	add	x23, x23, x1
    7b84:	394002e0 	ldrb	w0, [x23]
    7b88:	7103fc1f 	cmp	w0, #0xff
    7b8c:	54002d00 	b.eq	812c <f0+0x244c>  // b.none
    7b90:	52800020 	mov	w0, #0x1                   	// #1
    7b94:	390002e0 	strb	w0, [x23]
    7b98:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    7b9c:	911fe3e0 	add	x0, sp, #0x7f8
    7ba0:	f903ffe1 	str	x1, [sp, #2040]
    7ba4:	f90403f5 	str	x21, [sp, #2048]
    7ba8:	97ffeeea 	bl	3750 <fwp_data.part.0.constprop.0>
    7bac:	9115c283 	add	x3, x20, #0x570
    7bb0:	aa0003f5 	mov	x21, x0
    7bb4:	f949d861 	ldr	x1, [x3, #5040]
    7bb8:	f949ec60 	ldr	x0, [x3, #5080]
    7bbc:	cb0102a1 	sub	x1, x21, x1
    7bc0:	eb00403f 	cmp	x1, x0, lsl #16
    7bc4:	54000322 	b.cs	7c28 <f0+0x1f48>  // b.hs, b.nlast
    7bc8:	d350fc22 	lsr	x2, x1, #16
    7bcc:	f949fc63 	ldr	x3, [x3, #5112]
    7bd0:	8b020842 	add	x2, x2, x2, lsl #2
    7bd4:	d37df042 	lsl	x2, x2, #3
    7bd8:	8b020060 	add	x0, x3, x2
    7bdc:	f9401017 	ldr	x23, [x0, #32]
    7be0:	b4000257 	cbz	x23, 7c28 <f0+0x1f48>
    7be4:	38626862 	ldrb	w2, [x3, x2]
    7be8:	7100085f 	cmp	w2, #0x2
    7bec:	54001680 	b.eq	7ebc <f0+0x21dc>  // b.none
    7bf0:	7100045f 	cmp	w2, #0x1
    7bf4:	540001a1 	b.ne	7c28 <f0+0x1f48>  // b.any
    7bf8:	29430002 	ldp	w2, w0, [x0, #24]
    7bfc:	92403c21 	and	x1, x1, #0xffff
    7c00:	9b027c21 	mul	x1, x1, x2
    7c04:	d360fc21 	lsr	x1, x1, #32
    7c08:	eb00003f 	cmp	x1, x0
    7c0c:	540000e2 	b.cs	7c28 <f0+0x1f48>  // b.hs, b.nlast
    7c10:	8b0102f7 	add	x23, x23, x1
    7c14:	394002e0 	ldrb	w0, [x23]
    7c18:	7103fc1f 	cmp	w0, #0xff
    7c1c:	540028e0 	b.eq	8138 <f0+0x2458>  // b.none
    7c20:	52800020 	mov	w0, #0x1                   	// #1
    7c24:	390002e0 	strb	w0, [x23]
    7c28:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    7c2c:	9115c294 	add	x20, x20, #0x570
    7c30:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7c34:	912023e0 	add	x0, sp, #0x808
    7c38:	f90407e1 	str	x1, [sp, #2056]
    7c3c:	f9040bf5 	str	x21, [sp, #2064]
    7c40:	97ffeec4 	bl	3750 <fwp_data.part.0.constprop.0>
    7c44:	f949da81 	ldr	x1, [x20, #5040]
    7c48:	aa0003f5 	mov	x21, x0
    7c4c:	f949ee80 	ldr	x0, [x20, #5080]
    7c50:	cb0102a1 	sub	x1, x21, x1
    7c54:	eb00403f 	cmp	x1, x0, lsl #16
    7c58:	54000322 	b.cs	7cbc <f0+0x1fdc>  // b.hs, b.nlast
    7c5c:	d350fc22 	lsr	x2, x1, #16
    7c60:	f949fe83 	ldr	x3, [x20, #5112]
    7c64:	8b020842 	add	x2, x2, x2, lsl #2
    7c68:	d37df042 	lsl	x2, x2, #3
    7c6c:	8b020060 	add	x0, x3, x2
    7c70:	f9401014 	ldr	x20, [x0, #32]
    7c74:	b4000254 	cbz	x20, 7cbc <f0+0x1fdc>
    7c78:	38626862 	ldrb	w2, [x3, x2]
    7c7c:	7100085f 	cmp	w2, #0x2
    7c80:	54001180 	b.eq	7eb0 <f0+0x21d0>  // b.none
    7c84:	7100045f 	cmp	w2, #0x1
    7c88:	540001a1 	b.ne	7cbc <f0+0x1fdc>  // b.any
    7c8c:	29430002 	ldp	w2, w0, [x0, #24]
    7c90:	92403c21 	and	x1, x1, #0xffff
    7c94:	9b027c21 	mul	x1, x1, x2
    7c98:	d360fc21 	lsr	x1, x1, #32
    7c9c:	eb00003f 	cmp	x1, x0
    7ca0:	540000e2 	b.cs	7cbc <f0+0x1fdc>  // b.hs, b.nlast
    7ca4:	8b010294 	add	x20, x20, x1
    7ca8:	39400280 	ldrb	w0, [x20]
    7cac:	7103fc1f 	cmp	w0, #0xff
    7cb0:	54001600 	b.eq	7f70 <f0+0x2290>  // b.none
    7cb4:	52800020 	mov	w0, #0x1                   	// #1
    7cb8:	39000280 	strb	w0, [x20]
    7cbc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7cc0:	912063e0 	add	x0, sp, #0x818
    7cc4:	f9040ff7 	str	x23, [sp, #2072]
    7cc8:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    7ccc:	f90413f5 	str	x21, [sp, #2080]
    7cd0:	97ffeea0 	bl	3750 <fwp_data.part.0.constprop.0>
    7cd4:	97ffedeb 	bl	3480 <fwp_rc_fresh>
    7cd8:	aa0003e1 	mov	x1, x0
    7cdc:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    7ce0:	9120a3e0 	add	x0, sp, #0x828
    7ce4:	f90417f4 	str	x20, [sp, #2088]
    7ce8:	f9041be1 	str	x1, [sp, #2096]
    7cec:	97ffee99 	bl	3750 <fwp_data.part.0.constprop.0>
    7cf0:	97ffede4 	bl	3480 <fwp_rc_fresh>
    7cf4:	aa0003e1 	mov	x1, x0
    7cf8:	9120e3e0 	add	x0, sp, #0x838
    7cfc:	f9041ff7 	str	x23, [sp, #2104]
    7d00:	f90423e1 	str	x1, [sp, #2112]
    7d04:	97ffee93 	bl	3750 <fwp_data.part.0.constprop.0>
    7d08:	97ffedde 	bl	3480 <fwp_rc_fresh>
    7d0c:	aa0003e1 	mov	x1, x0
    7d10:	aa1603e0 	mov	x0, x22
    7d14:	f90427f4 	str	x20, [sp, #2120]
    7d18:	f9042be1 	str	x1, [sp, #2128]
    7d1c:	97ffee8d 	bl	3750 <fwp_data.part.0.constprop.0>
    7d20:	97ffedd8 	bl	3480 <fwp_rc_fresh>
    7d24:	aa0003f5 	mov	x21, x0
    7d28:	aa1303e1 	mov	x1, x19
    7d2c:	97fff492 	bl	4f74 <fwp_hof0.constprop.0>
    7d30:	aa0003f4 	mov	x20, x0
    7d34:	aa1503e0 	mov	x0, x21
    7d38:	97ffeefa 	bl	3920 <fwp_drop0>
    7d3c:	aa1303e0 	mov	x0, x19
    7d40:	97ffeef8 	bl	3920 <fwp_drop0>
    7d44:	900000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    7d48:	f947f400 	ldr	x0, [x0, #4072]
    7d4c:	f9442fe2 	ldr	x2, [sp, #2136]
    7d50:	f9400001 	ldr	x1, [x0]
    7d54:	eb010042 	subs	x2, x2, x1
    7d58:	d2800001 	mov	x1, #0x0                   	// #0
    7d5c:	54001f41 	b.ne	8144 <f0+0x2464>  // b.any
    7d60:	912183ff 	add	sp, sp, #0x860
    7d64:	aa1403e0 	mov	x0, x20
    7d68:	a94153f3 	ldp	x19, x20, [sp, #16]
    7d6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7d70:	a94363f7 	ldp	x23, x24, [sp, #48]
    7d74:	a9446bf9 	ldp	x25, x26, [sp, #64]
    7d78:	a94573fb 	ldp	x27, x28, [sp, #80]
    7d7c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    7d80:	d65f03c0 	ret
    7d84:	aa1b03e0 	mov	x0, x27
    7d88:	97ffebff 	bl	2d84 <fwp_rc_forget_slot>
    7d8c:	17fff81c 	b	5dfc <f0+0x11c>
    7d90:	72003c5f 	tst	w2, #0xffff
    7d94:	54ff0361 	b.ne	5e00 <f0+0x120>  // b.any
    7d98:	17fff816 	b	5df0 <f0+0x110>
    7d9c:	72003c3f 	tst	w1, #0xffff
    7da0:	54ff93c1 	b.ne	7018 <f0+0x1338>  // b.any
    7da4:	17fffc98 	b	7004 <f0+0x1324>
    7da8:	72003c3f 	tst	w1, #0xffff
    7dac:	54ff8d21 	b.ne	6f50 <f0+0x1270>  // b.any
    7db0:	17fffc63 	b	6f3c <f0+0x125c>
    7db4:	72003c3f 	tst	w1, #0xffff
    7db8:	54ff8821 	b.ne	6ebc <f0+0x11dc>  // b.any
    7dbc:	17fffc3b 	b	6ea8 <f0+0x11c8>
    7dc0:	72003c3f 	tst	w1, #0xffff
    7dc4:	54ff7b81 	b.ne	6d34 <f0+0x1054>  // b.any
    7dc8:	17fffbd6 	b	6d20 <f0+0x1040>
    7dcc:	72003c3f 	tst	w1, #0xffff
    7dd0:	54ff7681 	b.ne	6ca0 <f0+0xfc0>  // b.any
    7dd4:	17fffbae 	b	6c8c <f0+0xfac>
    7dd8:	72003c3f 	tst	w1, #0xffff
    7ddc:	54ff6ce1 	b.ne	6b78 <f0+0xe98>  // b.any
    7de0:	17fffb61 	b	6b64 <f0+0xe84>
    7de4:	72003c3f 	tst	w1, #0xffff
    7de8:	54ff6701 	b.ne	6ac8 <f0+0xde8>  // b.any
    7dec:	17fffb32 	b	6ab4 <f0+0xdd4>
    7df0:	72003c3f 	tst	w1, #0xffff
    7df4:	54ff6121 	b.ne	6a18 <f0+0xd38>  // b.any
    7df8:	17fffb03 	b	6a04 <f0+0xd24>
    7dfc:	72003c3f 	tst	w1, #0xffff
    7e00:	54ff1861 	b.ne	610c <f0+0x42c>  // b.any
    7e04:	17fff8bd 	b	60f8 <f0+0x418>
    7e08:	72003c3f 	tst	w1, #0xffff
    7e0c:	54ff1041 	b.ne	6014 <f0+0x334>  // b.any
    7e10:	17fff87c 	b	6000 <f0+0x320>
    7e14:	72003c3f 	tst	w1, #0xffff
    7e18:	54ff0b61 	b.ne	5f84 <f0+0x2a4>  // b.any
    7e1c:	17fff855 	b	5f70 <f0+0x290>
    7e20:	72003c3f 	tst	w1, #0xffff
    7e24:	54ff2ca1 	b.ne	63b8 <f0+0x6d8>  // b.any
    7e28:	17fff95f 	b	63a4 <f0+0x6c4>
    7e2c:	72003c3f 	tst	w1, #0xffff
    7e30:	54ff27e1 	b.ne	632c <f0+0x64c>  // b.any
    7e34:	17fff939 	b	6318 <f0+0x638>
    7e38:	72003c3f 	tst	w1, #0xffff
    7e3c:	54ff2241 	b.ne	6284 <f0+0x5a4>  // b.any
    7e40:	17fff90c 	b	6270 <f0+0x590>
    7e44:	72003c3f 	tst	w1, #0xffff
    7e48:	54ff1ca1 	b.ne	61dc <f0+0x4fc>  // b.any
    7e4c:	17fff8df 	b	61c8 <f0+0x4e8>
    7e50:	72003c3f 	tst	w1, #0xffff
    7e54:	54ff5721 	b.ne	6938 <f0+0xc58>  // b.any
    7e58:	17fffab3 	b	6924 <f0+0xc44>
    7e5c:	72003c3f 	tst	w1, #0xffff
    7e60:	54ff5081 	b.ne	6870 <f0+0xb90>  // b.any
    7e64:	17fffa7e 	b	685c <f0+0xb7c>
    7e68:	72003c3f 	tst	w1, #0xffff
    7e6c:	54ff4ba1 	b.ne	67e0 <f0+0xb00>  // b.any
    7e70:	17fffa57 	b	67cc <f0+0xaec>
    7e74:	72003c3f 	tst	w1, #0xffff
    7e78:	54ff46a1 	b.ne	674c <f0+0xa6c>  // b.any
    7e7c:	17fffa2f 	b	6738 <f0+0xa58>
    7e80:	72003c3f 	tst	w1, #0xffff
    7e84:	54ff3f41 	b.ne	666c <f0+0x98c>  // b.any
    7e88:	17fff9f4 	b	6658 <f0+0x978>
    7e8c:	72003c3f 	tst	w1, #0xffff
    7e90:	54ff38a1 	b.ne	65a4 <f0+0x8c4>  // b.any
    7e94:	17fff9bf 	b	6590 <f0+0x8b0>
    7e98:	72003c3f 	tst	w1, #0xffff
    7e9c:	54ff32c1 	b.ne	64f4 <f0+0x814>  // b.any
    7ea0:	17fff990 	b	64e0 <f0+0x800>
    7ea4:	72003c3f 	tst	w1, #0xffff
    7ea8:	54ff2d01 	b.ne	6448 <f0+0x768>  // b.any
    7eac:	17fff962 	b	6434 <f0+0x754>
    7eb0:	72003c3f 	tst	w1, #0xffff
    7eb4:	54fff041 	b.ne	7cbc <f0+0x1fdc>  // b.any
    7eb8:	17ffff7c 	b	7ca8 <f0+0x1fc8>
    7ebc:	72003c3f 	tst	w1, #0xffff
    7ec0:	54ffeb41 	b.ne	7c28 <f0+0x1f48>  // b.any
    7ec4:	17ffff54 	b	7c14 <f0+0x1f34>
    7ec8:	72003c3f 	tst	w1, #0xffff
    7ecc:	54ffe661 	b.ne	7b98 <f0+0x1eb8>  // b.any
    7ed0:	17ffff2d 	b	7b84 <f0+0x1ea4>
    7ed4:	72003c3f 	tst	w1, #0xffff
    7ed8:	54ffe161 	b.ne	7b04 <f0+0x1e24>  // b.any
    7edc:	17ffff05 	b	7af0 <f0+0x1e10>
    7ee0:	72003c3f 	tst	w1, #0xffff
    7ee4:	54ffdc81 	b.ne	7a74 <f0+0x1d94>  // b.any
    7ee8:	17fffede 	b	7a60 <f0+0x1d80>
    7eec:	72003c3f 	tst	w1, #0xffff
    7ef0:	54ffd781 	b.ne	79e0 <f0+0x1d00>  // b.any
    7ef4:	17fffeb6 	b	79cc <f0+0x1cec>
    7ef8:	72003c3f 	tst	w1, #0xffff
    7efc:	54ffd0e1 	b.ne	7918 <f0+0x1c38>  // b.any
    7f00:	17fffe81 	b	7904 <f0+0x1c24>
    7f04:	72003c3f 	tst	w1, #0xffff
    7f08:	54ffca41 	b.ne	7850 <f0+0x1b70>  // b.any
    7f0c:	17fffe4c 	b	783c <f0+0x1b5c>
    7f10:	72003c3f 	tst	w1, #0xffff
    7f14:	54ffc3a1 	b.ne	7788 <f0+0x1aa8>  // b.any
    7f18:	17fffe17 	b	7774 <f0+0x1a94>
    7f1c:	72003c3f 	tst	w1, #0xffff
    7f20:	54ffbb81 	b.ne	7690 <f0+0x19b0>  // b.any
    7f24:	17fffdd6 	b	767c <f0+0x199c>
    7f28:	72003c3f 	tst	w1, #0xffff
    7f2c:	54ffb4e1 	b.ne	75c8 <f0+0x18e8>  // b.any
    7f30:	17fffda1 	b	75b4 <f0+0x18d4>
    7f34:	72003c3f 	tst	w1, #0xffff
    7f38:	54ffad81 	b.ne	74e8 <f0+0x1808>  // b.any
    7f3c:	17fffd66 	b	74d4 <f0+0x17f4>
    7f40:	72003c3f 	tst	w1, #0xffff
    7f44:	54ffa881 	b.ne	7454 <f0+0x1774>  // b.any
    7f48:	17fffd3e 	b	7440 <f0+0x1760>
    7f4c:	72003c3f 	tst	w1, #0xffff
    7f50:	54ffa1e1 	b.ne	738c <f0+0x16ac>  // b.any
    7f54:	17fffd09 	b	7378 <f0+0x1698>
    7f58:	72003c3f 	tst	w1, #0xffff
    7f5c:	54ff9a81 	b.ne	72ac <f0+0x15cc>  // b.any
    7f60:	17fffcce 	b	7298 <f0+0x15b8>
    7f64:	72003c3f 	tst	w1, #0xffff
    7f68:	54ff9581 	b.ne	7218 <f0+0x1538>  // b.any
    7f6c:	17fffca6 	b	7204 <f0+0x1524>
    7f70:	aa1403e0 	mov	x0, x20
    7f74:	97ffeb84 	bl	2d84 <fwp_rc_forget_slot>
    7f78:	17ffff4f 	b	7cb4 <f0+0x1fd4>
    7f7c:	aa1703e0 	mov	x0, x23
    7f80:	97ffeb81 	bl	2d84 <fwp_rc_forget_slot>
    7f84:	17fff7fe 	b	5f7c <f0+0x29c>
    7f88:	aa1703e0 	mov	x0, x23
    7f8c:	97ffeb7e 	bl	2d84 <fwp_rc_forget_slot>
    7f90:	17fff81f 	b	600c <f0+0x32c>
    7f94:	aa1703e0 	mov	x0, x23
    7f98:	97ffeb7b 	bl	2d84 <fwp_rc_forget_slot>
    7f9c:	17fff85a 	b	6104 <f0+0x424>
    7fa0:	aa1703e0 	mov	x0, x23
    7fa4:	97ffeb78 	bl	2d84 <fwp_rc_forget_slot>
    7fa8:	17fff88b 	b	61d4 <f0+0x4f4>
    7fac:	aa1703e0 	mov	x0, x23
    7fb0:	97ffeb75 	bl	2d84 <fwp_rc_forget_slot>
    7fb4:	17fff8b2 	b	627c <f0+0x59c>
    7fb8:	aa1703e0 	mov	x0, x23
    7fbc:	97ffeb72 	bl	2d84 <fwp_rc_forget_slot>
    7fc0:	17fff8d9 	b	6324 <f0+0x644>
    7fc4:	aa1703e0 	mov	x0, x23
    7fc8:	97ffeb6f 	bl	2d84 <fwp_rc_forget_slot>
    7fcc:	17fff8f9 	b	63b0 <f0+0x6d0>
    7fd0:	aa1703e0 	mov	x0, x23
    7fd4:	97ffeb6c 	bl	2d84 <fwp_rc_forget_slot>
    7fd8:	17fff91a 	b	6440 <f0+0x760>
    7fdc:	aa1703e0 	mov	x0, x23
    7fe0:	97ffeb69 	bl	2d84 <fwp_rc_forget_slot>
    7fe4:	17fff942 	b	64ec <f0+0x80c>
    7fe8:	aa1703e0 	mov	x0, x23
    7fec:	97ffeb66 	bl	2d84 <fwp_rc_forget_slot>
    7ff0:	17fff96b 	b	659c <f0+0x8bc>
    7ff4:	aa1703e0 	mov	x0, x23
    7ff8:	97ffeb63 	bl	2d84 <fwp_rc_forget_slot>
    7ffc:	17fff99a 	b	6664 <f0+0x984>
    8000:	aa1703e0 	mov	x0, x23
    8004:	97ffeb60 	bl	2d84 <fwp_rc_forget_slot>
    8008:	17fff9cf 	b	6744 <f0+0xa64>
    800c:	aa1703e0 	mov	x0, x23
    8010:	97ffeb5d 	bl	2d84 <fwp_rc_forget_slot>
    8014:	17fff9f1 	b	67d8 <f0+0xaf8>
    8018:	aa1703e0 	mov	x0, x23
    801c:	97ffeb5a 	bl	2d84 <fwp_rc_forget_slot>
    8020:	17fffa12 	b	6868 <f0+0xb88>
    8024:	aa1703e0 	mov	x0, x23
    8028:	97ffeb57 	bl	2d84 <fwp_rc_forget_slot>
    802c:	17fffa41 	b	6930 <f0+0xc50>
    8030:	aa1703e0 	mov	x0, x23
    8034:	97ffeb54 	bl	2d84 <fwp_rc_forget_slot>
    8038:	17fffa76 	b	6a10 <f0+0xd30>
    803c:	aa1703e0 	mov	x0, x23
    8040:	97ffeb51 	bl	2d84 <fwp_rc_forget_slot>
    8044:	17fffa9f 	b	6ac0 <f0+0xde0>
    8048:	aa1503e0 	mov	x0, x21
    804c:	97ffeb4e 	bl	2d84 <fwp_rc_forget_slot>
    8050:	17fffac8 	b	6b70 <f0+0xe90>
    8054:	aa1703e0 	mov	x0, x23
    8058:	97ffeb4b 	bl	2d84 <fwp_rc_forget_slot>
    805c:	17fffb0f 	b	6c98 <f0+0xfb8>
    8060:	aa1503e0 	mov	x0, x21
    8064:	97ffeb48 	bl	2d84 <fwp_rc_forget_slot>
    8068:	17fffb31 	b	6d2c <f0+0x104c>
    806c:	aa1703e0 	mov	x0, x23
    8070:	97ffeb45 	bl	2d84 <fwp_rc_forget_slot>
    8074:	17fffb90 	b	6eb4 <f0+0x11d4>
    8078:	aa1703e0 	mov	x0, x23
    807c:	97ffeb42 	bl	2d84 <fwp_rc_forget_slot>
    8080:	17fffbb2 	b	6f48 <f0+0x1268>
    8084:	aa1703e0 	mov	x0, x23
    8088:	97ffeb3f 	bl	2d84 <fwp_rc_forget_slot>
    808c:	17fffbe1 	b	7010 <f0+0x1330>
    8090:	aa1703e0 	mov	x0, x23
    8094:	97ffeb3c 	bl	2d84 <fwp_rc_forget_slot>
    8098:	17fffc5e 	b	7210 <f0+0x1530>
    809c:	aa1703e0 	mov	x0, x23
    80a0:	97ffeb39 	bl	2d84 <fwp_rc_forget_slot>
    80a4:	17fffc80 	b	72a4 <f0+0x15c4>
    80a8:	aa1703e0 	mov	x0, x23
    80ac:	97ffeb36 	bl	2d84 <fwp_rc_forget_slot>
    80b0:	17fffcb5 	b	7384 <f0+0x16a4>
    80b4:	aa1703e0 	mov	x0, x23
    80b8:	97ffeb33 	bl	2d84 <fwp_rc_forget_slot>
    80bc:	17fffce4 	b	744c <f0+0x176c>
    80c0:	aa1703e0 	mov	x0, x23
    80c4:	97ffeb30 	bl	2d84 <fwp_rc_forget_slot>
    80c8:	17fffd06 	b	74e0 <f0+0x1800>
    80cc:	aa1703e0 	mov	x0, x23
    80d0:	97ffeb2d 	bl	2d84 <fwp_rc_forget_slot>
    80d4:	17fffd3b 	b	75c0 <f0+0x18e0>
    80d8:	aa1703e0 	mov	x0, x23
    80dc:	97ffeb2a 	bl	2d84 <fwp_rc_forget_slot>
    80e0:	17fffd6a 	b	7688 <f0+0x19a8>
    80e4:	aa1703e0 	mov	x0, x23
    80e8:	97ffeb27 	bl	2d84 <fwp_rc_forget_slot>
    80ec:	17fffda5 	b	7780 <f0+0x1aa0>
    80f0:	aa1703e0 	mov	x0, x23
    80f4:	97ffeb24 	bl	2d84 <fwp_rc_forget_slot>
    80f8:	17fffdd4 	b	7848 <f0+0x1b68>
    80fc:	aa1703e0 	mov	x0, x23
    8100:	97ffeb21 	bl	2d84 <fwp_rc_forget_slot>
    8104:	17fffe03 	b	7910 <f0+0x1c30>
    8108:	aa1703e0 	mov	x0, x23
    810c:	97ffeb1e 	bl	2d84 <fwp_rc_forget_slot>
    8110:	17fffe32 	b	79d8 <f0+0x1cf8>
    8114:	aa1703e0 	mov	x0, x23
    8118:	97ffeb1b 	bl	2d84 <fwp_rc_forget_slot>
    811c:	17fffe54 	b	7a6c <f0+0x1d8c>
    8120:	aa1703e0 	mov	x0, x23
    8124:	97ffeb18 	bl	2d84 <fwp_rc_forget_slot>
    8128:	17fffe75 	b	7afc <f0+0x1e1c>
    812c:	aa1703e0 	mov	x0, x23
    8130:	97ffeb15 	bl	2d84 <fwp_rc_forget_slot>
    8134:	17fffe97 	b	7b90 <f0+0x1eb0>
    8138:	aa1703e0 	mov	x0, x23
    813c:	97ffeb12 	bl	2d84 <fwp_rc_forget_slot>
    8140:	17fffeb8 	b	7c20 <f0+0x1f40>
    8144:	97ffe4ef 	bl	1500 <__stack_chk_fail@plt>
    8148:	d503201f 	nop
    814c:	d503201f 	nop

0000000000008150 <fwp_main_thread>:
    8150:	d10443ff 	sub	sp, sp, #0x110
    8154:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    8158:	f947f400 	ldr	x0, [x0, #4072]
    815c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    8160:	910303fd 	add	x29, sp, #0xc0
    8164:	a90e5bf5 	stp	x21, x22, [sp, #224]
    8168:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xc70>
    816c:	9115c2c1 	add	x1, x22, #0x570
    8170:	a90d53f3 	stp	x19, x20, [sp, #208]
    8174:	a90f63f7 	stp	x23, x24, [sp, #240]
    8178:	b953a421 	ldr	w1, [x1, #5028]
    817c:	a9106bf9 	stp	x25, x26, [sp, #256]
    8180:	f9400002 	ldr	x2, [x0]
    8184:	f9005fe2 	str	x2, [sp, #184]
    8188:	d2800002 	mov	x2, #0x0                   	// #0
    818c:	340028e1 	cbz	w1, 86a8 <fwp_main_thread+0x558>
    8190:	9115c2c0 	add	x0, x22, #0x570
    8194:	b953a800 	ldr	w0, [x0, #5032]
    8198:	35002800 	cbnz	w0, 8698 <fwp_main_thread+0x548>
    819c:	91001fe2 	add	x2, sp, #0x7
    81a0:	900000d5 	adrp	x21, 20000 <__data_start>
    81a4:	900000c3 	adrp	x3, 20000 <__data_start>
    81a8:	910242b3 	add	x19, x21, #0x90
    81ac:	910e4063 	add	x3, x3, #0x390
    81b0:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    81b4:	d2a00025 	mov	x5, #0x10000               	// #65536
    81b8:	910023e0 	add	x0, sp, #0x8
    81bc:	d2800001 	mov	x1, #0x0                   	// #0
    81c0:	f90007e3 	str	x3, [sp, #8]
    81c4:	a9011262 	stp	x2, x4, [x19, #16]
    81c8:	b90013ff 	str	wzr, [sp, #16]
    81cc:	f9000fe5 	str	x5, [sp, #24]
    81d0:	97ffe468 	bl	1370 <sigaltstack@plt>
    81d4:	35002820 	cbnz	w0, 86d8 <fwp_main_thread+0x588>
    81d8:	4f000400 	movi	v0.4s, #0x0
    81dc:	9100a3e0 	add	x0, sp, #0x28
    81e0:	b0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    81e4:	52800082 	mov	w2, #0x4                   	// #4
    81e8:	91304021 	add	x1, x1, #0xc10
    81ec:	72a10002 	movk	w2, #0x800, lsl #16
    81f0:	910083f4 	add	x20, sp, #0x20
    81f4:	f90013e1 	str	x1, [sp, #32]
    81f8:	3d802000 	str	q0, [x0, #128]
    81fc:	b900abe2 	str	w2, [sp, #168]
    8200:	ad000000 	stp	q0, q0, [x0]
    8204:	ad010000 	stp	q0, q0, [x0, #32]
    8208:	ad020000 	stp	q0, q0, [x0, #64]
    820c:	ad030000 	stp	q0, q0, [x0, #96]
    8210:	97ffe4ac 	bl	14c0 <sigemptyset@plt>
    8214:	35002620 	cbnz	w0, 86d8 <fwp_main_thread+0x588>
    8218:	aa1403e1 	mov	x1, x20
    821c:	d2800002 	mov	x2, #0x0                   	// #0
    8220:	52800160 	mov	w0, #0xb                   	// #11
    8224:	97ffe4bf 	bl	1520 <sigaction@plt>
    8228:	35002580 	cbnz	w0, 86d8 <fwp_main_thread+0x588>
    822c:	aa1403e1 	mov	x1, x20
    8230:	d2800002 	mov	x2, #0x0                   	// #0
    8234:	528000e0 	mov	w0, #0x7                   	// #7
    8238:	97ffe4ba 	bl	1520 <sigaction@plt>
    823c:	350024e0 	cbnz	w0, 86d8 <fwp_main_thread+0x588>
    8240:	9115c2c1 	add	x1, x22, #0x570
    8244:	52800034 	mov	w20, #0x1                   	// #1
    8248:	b0ffffc0 	adrp	x0, 1000 <__abi_tag+0xd88>
    824c:	913c4000 	add	x0, x0, #0xf10
    8250:	b9004274 	str	w20, [x19, #64]
    8254:	fd4a1020 	ldr	d0, [x1, #5152]
    8258:	7e61d800 	ucvtf	d0, d0
    825c:	fd002e60 	str	d0, [x19, #88]
    8260:	940002e4 	bl	8df0 <atexit>
    8264:	35002400 	cbnz	w0, 86e4 <fwp_main_thread+0x594>
    8268:	b942d260 	ldr	w0, [x19, #720]
    826c:	34002220 	cbz	w0, 86b0 <fwp_main_thread+0x560>
    8270:	910242ba 	add	x26, x21, #0x90
    8274:	f9400754 	ldr	x20, [x26, #8]
    8278:	b40010b4 	cbz	x20, 848c <fwp_main_thread+0x33c>
    827c:	aa1403f3 	mov	x19, x20
    8280:	91010297 	add	x23, x20, #0x40
    8284:	39414a99 	ldrb	w25, [x20, #82]
    8288:	52800038 	mov	w24, #0x1                   	// #1
    828c:	39014a98 	strb	w24, [x20, #82]
    8290:	f9401680 	ldr	x0, [x20, #40]
    8294:	b4000620 	cbz	x0, 8358 <fwp_main_thread+0x208>
    8298:	f9403281 	ldr	x1, [x20, #96]
    829c:	39414680 	ldrb	w0, [x20, #81]
    82a0:	b4000b41 	cbz	x1, 8408 <fwp_main_thread+0x2b8>
    82a4:	36000a80 	tbz	w0, #0, 83f4 <fwp_main_thread+0x2a4>
    82a8:	39414a62 	ldrb	w2, [x19, #82]
    82ac:	f9402280 	ldr	x0, [x20, #64]
    82b0:	37000d62 	tbnz	w2, #0, 845c <fwp_main_thread+0x30c>
    82b4:	f9403261 	ldr	x1, [x19, #96]
    82b8:	a911fe77 	stp	x23, xzr, [x19, #280]
    82bc:	f9009660 	str	x0, [x19, #296]
    82c0:	b4000040 	cbz	x0, 82c8 <fwp_main_thread+0x178>
    82c4:	f9009013 	str	x19, [x0, #288]
    82c8:	f9002293 	str	x19, [x20, #64]
    82cc:	b4000101 	cbz	x1, 82ec <fwp_main_thread+0x19c>
    82d0:	f9401f40 	ldr	x0, [x26, #56]
    82d4:	39015678 	strb	w24, [x19, #85]
    82d8:	f9003661 	str	x1, [x19, #104]
    82dc:	a910827f 	stp	xzr, x0, [x19, #264]
    82e0:	b4000040 	cbz	x0, 82e8 <fwp_main_thread+0x198>
    82e4:	f9008413 	str	x19, [x0, #264]
    82e8:	f9001f53 	str	x19, [x26, #56]
    82ec:	39015a7f 	strb	wzr, [x19, #86]
    82f0:	97ffeee1 	bl	3e74 <fwp_block>
    82f4:	f9408e62 	ldr	x2, [x19, #280]
    82f8:	b4000142 	cbz	x2, 8320 <fwp_main_thread+0x1d0>
    82fc:	a9520261 	ldp	x1, x0, [x19, #288]
    8300:	b4000ba1 	cbz	x1, 8474 <fwp_main_thread+0x324>
    8304:	f9009420 	str	x0, [x1, #296]
    8308:	f9409660 	ldr	x0, [x19, #296]
    830c:	b4000040 	cbz	x0, 8314 <fwp_main_thread+0x1c4>
    8310:	f9009001 	str	x1, [x0, #288]
    8314:	91080260 	add	x0, x19, #0x200
    8318:	f900967f 	str	xzr, [x19, #296]
    831c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8320:	39415660 	ldrb	w0, [x19, #85]
    8324:	f9400742 	ldr	x2, [x26, #8]
    8328:	36000960 	tbz	w0, #0, 8454 <fwp_main_thread+0x304>
    832c:	a9508261 	ldp	x1, x0, [x19, #264]
    8330:	b4000a61 	cbz	x1, 847c <fwp_main_thread+0x32c>
    8334:	f9008820 	str	x0, [x1, #272]
    8338:	b4000040 	cbz	x0, 8340 <fwp_main_thread+0x1f0>
    833c:	f9008401 	str	x1, [x0, #264]
    8340:	91080260 	add	x0, x19, #0x200
    8344:	3901567f 	strb	wzr, [x19, #85]
    8348:	aa0203f3 	mov	x19, x2
    834c:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8350:	f9401680 	ldr	x0, [x20, #40]
    8354:	b5fffa20 	cbnz	x0, 8298 <fwp_main_thread+0x148>
    8358:	910242a0 	add	x0, x21, #0x90
    835c:	39014a99 	strb	w25, [x20, #82]
    8360:	f9415400 	ldr	x0, [x0, #680]
    8364:	b40017c0 	cbz	x0, 865c <fwp_main_thread+0x50c>
    8368:	910242a0 	add	x0, x21, #0x90
    836c:	f9417401 	ldr	x1, [x0, #744]
    8370:	b902e01f 	str	wzr, [x0, #736]
    8374:	eb13003f 	cmp	x1, x19
    8378:	540018e1 	b.ne	8694 <fwp_main_thread+0x544>  // b.any
    837c:	b4000933 	cbz	x19, 84a0 <fwp_main_thread+0x350>
    8380:	910242a0 	add	x0, x21, #0x90
    8384:	52800021 	mov	w1, #0x1                   	// #1
    8388:	39014a61 	strb	w1, [x19, #82]
    838c:	f9414005 	ldr	x5, [x0, #640]
    8390:	b4000885 	cbz	x5, 84a0 <fwp_main_thread+0x350>
    8394:	d503201f 	nop
    8398:	394140a0 	ldrb	w0, [x5, #80]
    839c:	37000060 	tbnz	w0, #0, 83a8 <fwp_main_thread+0x258>
    83a0:	aa0503e0 	mov	x0, x5
    83a4:	97ffe773 	bl	2170 <fwp_cancel_tree.part.0>
    83a8:	f9409ca5 	ldr	x5, [x5, #312]
    83ac:	b5ffff65 	cbnz	x5, 8398 <fwp_main_thread+0x248>
    83b0:	910242b4 	add	x20, x21, #0x90
    83b4:	52800037 	mov	w23, #0x1                   	// #1
    83b8:	f9402a60 	ldr	x0, [x19, #80]
    83bc:	f2001c1f 	tst	x0, #0xff000000ff
    83c0:	540000e1 	b.ne	83dc <fwp_main_thread+0x28c>  // b.any
    83c4:	f9401680 	ldr	x0, [x20, #40]
    83c8:	39015277 	strb	w23, [x19, #84]
    83cc:	f900827f 	str	xzr, [x19, #256]
    83d0:	b40005a0 	cbz	x0, 8484 <fwp_main_thread+0x334>
    83d4:	f9008013 	str	x19, [x0, #256]
    83d8:	f9001693 	str	x19, [x20, #40]
    83dc:	97ffeea6 	bl	3e74 <fwp_block>
    83e0:	97ffee38 	bl	3cc0 <fwp_free_zombie>
    83e4:	f9414280 	ldr	x0, [x20, #640]
    83e8:	b40005c0 	cbz	x0, 84a0 <fwp_main_thread+0x350>
    83ec:	f9417693 	ldr	x19, [x20, #744]
    83f0:	17fffff2 	b	83b8 <fwp_main_thread+0x268>
    83f4:	97ffe7b3 	bl	22c0 <fwp_now_ns>
    83f8:	f9403281 	ldr	x1, [x20, #96]
    83fc:	eb01001f 	cmp	x0, x1
    8400:	5400120a 	b.ge	8640 <fwp_main_thread+0x4f0>  // b.tcont
    8404:	39414680 	ldrb	w0, [x20, #81]
    8408:	39414a62 	ldrb	w2, [x19, #82]
    840c:	3707f500 	tbnz	w0, #0, 82ac <fwp_main_thread+0x15c>
    8410:	f9403281 	ldr	x1, [x20, #96]
    8414:	370001c2 	tbnz	w2, #0, 844c <fwp_main_thread+0x2fc>
    8418:	f9403260 	ldr	x0, [x19, #96]
    841c:	b4000180 	cbz	x0, 844c <fwp_main_thread+0x2fc>
    8420:	b4000061 	cbz	x1, 842c <fwp_main_thread+0x2dc>
    8424:	eb01001f 	cmp	x0, x1
    8428:	9a81d000 	csel	x0, x0, x1, le
    842c:	f9402281 	ldr	x1, [x20, #64]
    8430:	a911fe77 	stp	x23, xzr, [x19, #280]
    8434:	f9009661 	str	x1, [x19, #296]
    8438:	b4001441 	cbz	x1, 86c0 <fwp_main_thread+0x570>
    843c:	f9009033 	str	x19, [x1, #288]
    8440:	aa0003e1 	mov	x1, x0
    8444:	f9002293 	str	x19, [x20, #64]
    8448:	17ffffa2 	b	82d0 <fwp_main_thread+0x180>
    844c:	f9402280 	ldr	x0, [x20, #64]
    8450:	17ffff9a 	b	82b8 <fwp_main_thread+0x168>
    8454:	aa0203f3 	mov	x19, x2
    8458:	17ffff8e 	b	8290 <fwp_main_thread+0x140>
    845c:	a911fe77 	stp	x23, xzr, [x19, #280]
    8460:	f9009660 	str	x0, [x19, #296]
    8464:	b4000040 	cbz	x0, 846c <fwp_main_thread+0x31c>
    8468:	f9009013 	str	x19, [x0, #288]
    846c:	f9002293 	str	x19, [x20, #64]
    8470:	17ffff9f 	b	82ec <fwp_main_thread+0x19c>
    8474:	f9000040 	str	x0, [x2]
    8478:	17ffffa5 	b	830c <fwp_main_thread+0x1bc>
    847c:	f9001f40 	str	x0, [x26, #56]
    8480:	17ffffae 	b	8338 <fwp_main_thread+0x1e8>
    8484:	f9001a93 	str	x19, [x20, #48]
    8488:	17ffffd4 	b	83d8 <fwp_main_thread+0x288>
    848c:	f9415740 	ldr	x0, [x26, #680]
    8490:	b4000e40 	cbz	x0, 8658 <fwp_main_thread+0x508>
    8494:	f9417740 	ldr	x0, [x26, #744]
    8498:	b902e35f 	str	wzr, [x26, #736]
    849c:	b5000fc0 	cbnz	x0, 8694 <fwp_main_thread+0x544>
    84a0:	910242b4 	add	x20, x21, #0x90
    84a4:	97ffee07 	bl	3cc0 <fwp_free_zombie>
    84a8:	f9401a80 	ldr	x0, [x20, #48]
    84ac:	b5000f40 	cbnz	x0, 8694 <fwp_main_thread+0x544>
    84b0:	f9401e80 	ldr	x0, [x20, #56]
    84b4:	b5000f00 	cbnz	x0, 8694 <fwp_main_thread+0x544>
    84b8:	b9407293 	ldr	w19, [x20, #112]
    84bc:	340001d3 	cbz	w19, 84f4 <fwp_main_thread+0x3a4>
    84c0:	93407e77 	sxtw	x23, w19
    84c4:	51000673 	sub	w19, w19, #0x1
    84c8:	d1000af7 	sub	x23, x23, #0x2
    84cc:	91020298 	add	x24, x20, #0x80
    84d0:	cb3342f7 	sub	x23, x23, w19, uxtw
    84d4:	93407e73 	sxtw	x19, w19
    84d8:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    84dc:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    84e0:	b9007293 	str	w19, [x20, #112]
    84e4:	d1000673 	sub	x19, x19, #0x1
    84e8:	97ffe44e 	bl	1620 <munmap@plt>
    84ec:	eb1302ff 	cmp	x23, x19
    84f0:	54ffff41 	b.ne	84d8 <fwp_main_thread+0x388>  // b.any
    84f4:	900000d3 	adrp	x19, 20000 <__data_start>
    84f8:	91004260 	add	x0, x19, #0x10
    84fc:	b9406000 	ldr	w0, [x0, #96]
    8500:	37f80040 	tbnz	w0, #31, 8508 <fwp_main_thread+0x3b8>
    8504:	97ffe403 	bl	1510 <close@plt>
    8508:	910242a0 	add	x0, x21, #0x90
    850c:	91004261 	add	x1, x19, #0x10
    8510:	12800002 	mov	w2, #0xffffffff            	// #-1
    8514:	d2800013 	mov	x19, #0x0                   	// #0
    8518:	f9417817 	ldr	x23, [x0, #752]
    851c:	b9006022 	str	w2, [x1, #96]
    8520:	f9417c14 	ldr	x20, [x0, #760]
    8524:	b4000177 	cbz	x23, 8550 <fwp_main_thread+0x400>
    8528:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    852c:	b40000c0 	cbz	x0, 8544 <fwp_main_thread+0x3f4>
    8530:	f9400001 	ldr	x1, [x0]
    8534:	b5000b01 	cbnz	x1, 8694 <fwp_main_thread+0x544>
    8538:	f9400401 	ldr	x1, [x0, #8]
    853c:	b5000ac1 	cbnz	x1, 8694 <fwp_main_thread+0x544>
    8540:	97ffeab0 	bl	3000 <fwp_mem_free>
    8544:	91000673 	add	x19, x19, #0x1
    8548:	eb1302ff 	cmp	x23, x19
    854c:	54fffee1 	b.ne	8528 <fwp_main_thread+0x3d8>  // b.any
    8550:	aa1403e0 	mov	x0, x20
    8554:	97ffeaab 	bl	3000 <fwp_mem_free>
    8558:	910242a0 	add	x0, x21, #0x90
    855c:	f9417413 	ldr	x19, [x0, #744]
    8560:	f901781f 	str	xzr, [x0, #752]
    8564:	f9017c1f 	str	xzr, [x0, #760]
    8568:	b40001f3 	cbz	x19, 85a4 <fwp_main_thread+0x454>
    856c:	f9401661 	ldr	x1, [x19, #40]
    8570:	b5000921 	cbnz	x1, 8694 <fwp_main_thread+0x544>
    8574:	f9405661 	ldr	x1, [x19, #168]
    8578:	b50008e1 	cbnz	x1, 8694 <fwp_main_thread+0x544>
    857c:	f9415401 	ldr	x1, [x0, #680]
    8580:	b50008a1 	cbnz	x1, 8694 <fwp_main_thread+0x544>
    8584:	f9415c00 	ldr	x0, [x0, #696]
    8588:	b5000860 	cbnz	x0, 8694 <fwp_main_thread+0x544>
    858c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8590:	90000140 	adrp	x0, 30000 <alt.4+0xfc70>
    8594:	910e4000 	add	x0, x0, #0x390
    8598:	97ffe3ce 	bl	14d0 <memset@plt>
    859c:	aa1303e0 	mov	x0, x19
    85a0:	97ffea98 	bl	3000 <fwp_mem_free>
    85a4:	9115c2d6 	add	x22, x22, #0x570
    85a8:	910242b5 	add	x21, x21, #0x90
    85ac:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    85b0:	f947e800 	ldr	x0, [x0, #4048]
    85b4:	52800041 	mov	w1, #0x2                   	// #2
    85b8:	fd4a12c0 	ldr	d0, [x22, #5152]
    85bc:	b0000002 	adrp	x2, 9000 <_IO_stdin_used+0x1e0>
    85c0:	fd402ea1 	ldr	d1, [x21, #88]
    85c4:	910b8042 	add	x2, x2, #0x2e0
    85c8:	a94492a3 	ldp	x3, x4, [x21, #72]
    85cc:	7e61d800 	ucvtf	d0, d0
    85d0:	f9400000 	ldr	x0, [x0]
    85d4:	f90006bf 	str	xzr, [x21, #8]
    85d8:	f94166a5 	ldr	x5, [x21, #712]
    85dc:	1e613801 	fsub	d1, d0, d1
    85e0:	fd4032a0 	ldr	d0, [x21, #96]
    85e4:	f90012bf 	str	xzr, [x21, #32]
    85e8:	b90042bf 	str	wzr, [x21, #64]
    85ec:	f90176bf 	str	xzr, [x21, #744]
    85f0:	97ffe3e0 	bl	1570 <__fprintf_chk@plt>
    85f4:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    85f8:	f947ec00 	ldr	x0, [x0, #4056]
    85fc:	f9400000 	ldr	x0, [x0]
    8600:	97ffe40c 	bl	1630 <fflush@plt>
    8604:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    8608:	f947f400 	ldr	x0, [x0, #4072]
    860c:	f9405fe2 	ldr	x2, [sp, #184]
    8610:	f9400001 	ldr	x1, [x0]
    8614:	eb010042 	subs	x2, x2, x1
    8618:	d2800001 	mov	x1, #0x0                   	// #0
    861c:	540006a1 	b.ne	86f0 <fwp_main_thread+0x5a0>  // b.any
    8620:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    8624:	d2800000 	mov	x0, #0x0                   	// #0
    8628:	a94d53f3 	ldp	x19, x20, [sp, #208]
    862c:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    8630:	a94f63f7 	ldp	x23, x24, [sp, #240]
    8634:	a9506bf9 	ldp	x25, x26, [sp, #256]
    8638:	910443ff 	add	sp, sp, #0x110
    863c:	d65f03c0 	ret
    8640:	39414280 	ldrb	w0, [x20, #80]
    8644:	3707ee00 	tbnz	w0, #0, 8404 <fwp_main_thread+0x2b4>
    8648:	aa1403e0 	mov	x0, x20
    864c:	97ffe6c9 	bl	2170 <fwp_cancel_tree.part.0>
    8650:	39414680 	ldrb	w0, [x20, #81]
    8654:	17ffff6d 	b	8408 <fwp_main_thread+0x2b8>
    8658:	d2800013 	mov	x19, #0x0                   	// #0
    865c:	910242b4 	add	x20, x21, #0x90
    8660:	f9415e80 	ldr	x0, [x20, #696]
    8664:	b5ffe820 	cbnz	x0, 8368 <fwp_main_thread+0x218>
    8668:	f9415280 	ldr	x0, [x20, #672]
    866c:	97ffea65 	bl	3000 <fwp_mem_free>
    8670:	f901529f 	str	xzr, [x20, #672]
    8674:	f9015a9f 	str	xzr, [x20, #688]
    8678:	f9417680 	ldr	x0, [x20, #744]
    867c:	b4000293 	cbz	x19, 86cc <fwp_main_thread+0x57c>
    8680:	f900567f 	str	xzr, [x19, #168]
    8684:	f9005e7f 	str	xzr, [x19, #184]
    8688:	b902e29f 	str	wzr, [x20, #736]
    868c:	eb13001f 	cmp	x0, x19
    8690:	54ffe780 	b.eq	8380 <fwp_main_thread+0x230>  // b.none
    8694:	97ffe3af 	bl	1550 <abort@plt>
    8698:	d0ffffc0 	adrp	x0, 2000 <ad_raw_report+0xf0>
    869c:	911d9000 	add	x0, x0, #0x764
    86a0:	940001d4 	bl	8df0 <atexit>
    86a4:	17fffebe 	b	819c <fwp_main_thread+0x4c>
    86a8:	97ffe88a 	bl	28d0 <fwp_heap_init>
    86ac:	17fffeb9 	b	8190 <fwp_main_thread+0x40>
    86b0:	97fff58c 	bl	5ce0 <f0>
    86b4:	b902d274 	str	w20, [x19, #720]
    86b8:	f9016e60 	str	x0, [x19, #728]
    86bc:	17fffeed 	b	8270 <fwp_main_thread+0x120>
    86c0:	aa0003e1 	mov	x1, x0
    86c4:	f9002293 	str	x19, [x20, #64]
    86c8:	17ffff02 	b	82d0 <fwp_main_thread+0x180>
    86cc:	b902e29f 	str	wzr, [x20, #736]
    86d0:	b4ffee80 	cbz	x0, 84a0 <fwp_main_thread+0x350>
    86d4:	97ffe39f 	bl	1550 <abort@plt>
    86d8:	b0000000 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    86dc:	910a6000 	add	x0, x0, #0x298
    86e0:	97ffe6e8 	bl	2280 <fwp_trap>
    86e4:	b0000000 	adrp	x0, 9000 <_IO_stdin_used+0x1e0>
    86e8:	910b0000 	add	x0, x0, #0x2c0
    86ec:	97ffe5fd 	bl	1ee0 <ad_raw_fail>
    86f0:	97ffe384 	bl	1500 <__stack_chk_fail@plt>
    86f4:	d503201f 	nop
    86f8:	d503201f 	nop
    86fc:	d503201f 	nop

0000000000008700 <__divti3>:
    8700:	d503245f 	bti	c
    8704:	d2800004 	mov	x4, #0x0                   	// #0
    8708:	b7f80721 	tbnz	x1, #63, 87ec <__divti3+0xec>
    870c:	b6f80083 	tbz	x3, #63, 871c <__divti3+0x1c>
    8710:	eb0203e2 	negs	x2, x2
    8714:	aa2403e4 	mvn	x4, x4
    8718:	da0303e3 	ngc	x3, x3
    871c:	aa0203e6 	mov	x6, x2
    8720:	aa0003e7 	mov	x7, x0
    8724:	aa0103e5 	mov	x5, x1
    8728:	b5000583 	cbnz	x3, 87d8 <__divti3+0xd8>
    872c:	eb01005f 	cmp	x2, x1
    8730:	54000e69 	b.ls	88fc <__divti3+0x1fc>  // b.plast
    8734:	dac01040 	clz	x0, x2
    8738:	b40000e0 	cbz	x0, 8754 <__divti3+0x54>
    873c:	4b0003e1 	neg	w1, w0
    8740:	9ac020a5 	lsl	x5, x5, x0
    8744:	9ac02046 	lsl	x6, x2, x0
    8748:	9ac124e1 	lsr	x1, x7, x1
    874c:	aa050025 	orr	x5, x1, x5
    8750:	9ac020e7 	lsl	x7, x7, x0
    8754:	d360fcc8 	lsr	x8, x6, #32
    8758:	92407cc2 	and	x2, x6, #0xffffffff
    875c:	9ac808a3 	udiv	x3, x5, x8
    8760:	9b089465 	msub	x5, x3, x8, x5
    8764:	aa0303e0 	mov	x0, x3
    8768:	9b037c41 	mul	x1, x2, x3
    876c:	93c780a5 	extr	x5, x5, x7, #32
    8770:	eb05003f 	cmp	x1, x5
    8774:	540000a9 	b.ls	8788 <__divti3+0x88>  // b.plast
    8778:	ab0500c5 	adds	x5, x6, x5
    877c:	d1000460 	sub	x0, x3, #0x1
    8780:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8784:	540015a8 	b.hi	8a38 <__divti3+0x338>  // b.pmore
    8788:	cb0100a5 	sub	x5, x5, x1
    878c:	9ac808a3 	udiv	x3, x5, x8
    8790:	9b089465 	msub	x5, x3, x8, x5
    8794:	aa0303e1 	mov	x1, x3
    8798:	9b037c42 	mul	x2, x2, x3
    879c:	aa0703e3 	mov	x3, x7
    87a0:	b3607ca3 	bfi	x3, x5, #32, #32
    87a4:	eb03005f 	cmp	x2, x3
    87a8:	540000c9 	b.ls	87c0 <__divti3+0xc0>  // b.plast
    87ac:	ab0300c3 	adds	x3, x6, x3
    87b0:	d1000425 	sub	x5, x1, #0x1
    87b4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    87b8:	d1000821 	sub	x1, x1, #0x2
    87bc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    87c0:	aa008020 	orr	x0, x1, x0, lsl #32
    87c4:	d2800001 	mov	x1, #0x0                   	// #0
    87c8:	b4000064 	cbz	x4, 87d4 <__divti3+0xd4>
    87cc:	eb0003e0 	negs	x0, x0
    87d0:	da0103e1 	ngc	x1, x1
    87d4:	d65f03c0 	ret
    87d8:	eb01007f 	cmp	x3, x1
    87dc:	54000109 	b.ls	87fc <__divti3+0xfc>  // b.plast
    87e0:	d2800001 	mov	x1, #0x0                   	// #0
    87e4:	d2800000 	mov	x0, #0x0                   	// #0
    87e8:	17fffff8 	b	87c8 <__divti3+0xc8>
    87ec:	eb0003e0 	negs	x0, x0
    87f0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    87f4:	da0103e1 	ngc	x1, x1
    87f8:	17ffffc5 	b	870c <__divti3+0xc>
    87fc:	dac01067 	clz	x7, x3
    8800:	b40010e7 	cbz	x7, 8a1c <__divti3+0x31c>
    8804:	d2800805 	mov	x5, #0x40                  	// #64
    8808:	cb0700a5 	sub	x5, x5, x7
    880c:	9ac72063 	lsl	x3, x3, x7
    8810:	9ac52448 	lsr	x8, x2, x5
    8814:	aa030108 	orr	x8, x8, x3
    8818:	9ac52426 	lsr	x6, x1, x5
    881c:	92407d0a 	and	x10, x8, #0xffffffff
    8820:	d360fd09 	lsr	x9, x8, #32
    8824:	9ac52403 	lsr	x3, x0, x5
    8828:	9ac72021 	lsl	x1, x1, x7
    882c:	aa010063 	orr	x3, x3, x1
    8830:	9ac72042 	lsl	x2, x2, x7
    8834:	9ac908cb 	udiv	x11, x6, x9
    8838:	9b099965 	msub	x5, x11, x9, x6
    883c:	aa0b03e1 	mov	x1, x11
    8840:	9b0b7d46 	mul	x6, x10, x11
    8844:	93c380a5 	extr	x5, x5, x3, #32
    8848:	eb0500df 	cmp	x6, x5
    884c:	540000a9 	b.ls	8860 <__divti3+0x160>  // b.plast
    8850:	ab050105 	adds	x5, x8, x5
    8854:	d1000561 	sub	x1, x11, #0x1
    8858:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    885c:	54000f48 	b.hi	8a44 <__divti3+0x344>  // b.pmore
    8860:	cb0600a6 	sub	x6, x5, x6
    8864:	9ac908cb 	udiv	x11, x6, x9
    8868:	9b099969 	msub	x9, x11, x9, x6
    886c:	aa0b03e5 	mov	x5, x11
    8870:	9b0b7d4a 	mul	x10, x10, x11
    8874:	b3607d23 	bfi	x3, x9, #32, #32
    8878:	eb03015f 	cmp	x10, x3
    887c:	540000a9 	b.ls	8890 <__divti3+0x190>  // b.plast
    8880:	ab030103 	adds	x3, x8, x3
    8884:	d1000565 	sub	x5, x11, #0x1
    8888:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    888c:	54000e28 	b.hi	8a50 <__divti3+0x350>  // b.pmore
    8890:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8894:	92407c48 	and	x8, x2, #0xffffffff
    8898:	2a0503e5 	mov	w5, w5
    889c:	d360fc42 	lsr	x2, x2, #32
    88a0:	d360fc26 	lsr	x6, x1, #32
    88a4:	cb0a0063 	sub	x3, x3, x10
    88a8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    88ac:	9b087caa 	mul	x10, x5, x8
    88b0:	9b087cc8 	mul	x8, x6, x8
    88b4:	9b0220a5 	madd	x5, x5, x2, x8
    88b8:	9b027cc6 	mul	x6, x6, x2
    88bc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    88c0:	8b0900c5 	add	x5, x6, x9
    88c4:	eb02011f 	cmp	x8, x2
    88c8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    88cc:	8b4280c6 	add	x6, x6, x2, lsr #32
    88d0:	eb06007f 	cmp	x3, x6
    88d4:	540000e3 	b.cc	88f0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    88d8:	92407d4a 	and	x10, x10, #0xffffffff
    88dc:	9ac72000 	lsl	x0, x0, x7
    88e0:	8b028142 	add	x2, x10, x2, lsl #32
    88e4:	eb02001f 	cmp	x0, x2
    88e8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    88ec:	54000a01 	b.ne	8a2c <__divti3+0x32c>  // b.any
    88f0:	d1000420 	sub	x0, x1, #0x1
    88f4:	d2800001 	mov	x1, #0x0                   	// #0
    88f8:	17ffffb4 	b	87c8 <__divti3+0xc8>
    88fc:	b5000062 	cbnz	x2, 8908 <__divti3+0x208>
    8900:	d2800022 	mov	x2, #0x1                   	// #1
    8904:	9ac30846 	udiv	x6, x2, x3
    8908:	dac010c8 	clz	x8, x6
    890c:	b5000408 	cbnz	x8, 898c <__divti3+0x28c>
    8910:	d360fcc9 	lsr	x9, x6, #32
    8914:	92407cc5 	and	x5, x6, #0xffffffff
    8918:	cb060023 	sub	x3, x1, x6
    891c:	d2800021 	mov	x1, #0x1                   	// #1
    8920:	9ac90868 	udiv	x8, x3, x9
    8924:	9b098d03 	msub	x3, x8, x9, x3
    8928:	aa0803e0 	mov	x0, x8
    892c:	9b057d02 	mul	x2, x8, x5
    8930:	93c78063 	extr	x3, x3, x7, #32
    8934:	eb03005f 	cmp	x2, x3
    8938:	540000a9 	b.ls	894c <__divti3+0x24c>  // b.plast
    893c:	ab0300c3 	adds	x3, x6, x3
    8940:	d1000500 	sub	x0, x8, #0x1
    8944:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8948:	54000968 	b.hi	8a74 <__divti3+0x374>  // b.pmore
    894c:	cb020063 	sub	x3, x3, x2
    8950:	9ac90862 	udiv	x2, x3, x9
    8954:	aa0203e8 	mov	x8, x2
    8958:	9b098c42 	msub	x2, x2, x9, x3
    895c:	aa0703e3 	mov	x3, x7
    8960:	9b057d05 	mul	x5, x8, x5
    8964:	b3607c43 	bfi	x3, x2, #32, #32
    8968:	eb0300bf 	cmp	x5, x3
    896c:	540000c9 	b.ls	8984 <__divti3+0x284>  // b.plast
    8970:	ab0300c2 	adds	x2, x6, x3
    8974:	d1000503 	sub	x3, x8, #0x1
    8978:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    897c:	d1000908 	sub	x8, x8, #0x2
    8980:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    8984:	aa008100 	orr	x0, x8, x0, lsl #32
    8988:	17ffff90 	b	87c8 <__divti3+0xc8>
    898c:	9ac820c6 	lsl	x6, x6, x8
    8990:	d2800803 	mov	x3, #0x40                  	// #64
    8994:	cb080063 	sub	x3, x3, x8
    8998:	d360fcc9 	lsr	x9, x6, #32
    899c:	9ac82027 	lsl	x7, x1, x8
    89a0:	92407cc5 	and	x5, x6, #0xffffffff
    89a4:	9ac32422 	lsr	x2, x1, x3
    89a8:	9ac32403 	lsr	x3, x0, x3
    89ac:	aa070063 	orr	x3, x3, x7
    89b0:	9ac9084a 	udiv	x10, x2, x9
    89b4:	9ac82007 	lsl	x7, x0, x8
    89b8:	9b098940 	msub	x0, x10, x9, x2
    89bc:	aa0a03e1 	mov	x1, x10
    89c0:	9b0a7ca2 	mul	x2, x5, x10
    89c4:	93c38000 	extr	x0, x0, x3, #32
    89c8:	eb00005f 	cmp	x2, x0
    89cc:	540000a9 	b.ls	89e0 <__divti3+0x2e0>  // b.plast
    89d0:	ab0000c0 	adds	x0, x6, x0
    89d4:	d1000541 	sub	x1, x10, #0x1
    89d8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    89dc:	54000468 	b.hi	8a68 <__divti3+0x368>  // b.pmore
    89e0:	cb020000 	sub	x0, x0, x2
    89e4:	9ac9080a 	udiv	x10, x0, x9
    89e8:	9b098140 	msub	x0, x10, x9, x0
    89ec:	aa0a03e2 	mov	x2, x10
    89f0:	9b0a7ca8 	mul	x8, x5, x10
    89f4:	b3607c03 	bfi	x3, x0, #32, #32
    89f8:	eb03011f 	cmp	x8, x3
    89fc:	540000a9 	b.ls	8a10 <__divti3+0x310>  // b.plast
    8a00:	ab0300c3 	adds	x3, x6, x3
    8a04:	d1000542 	sub	x2, x10, #0x1
    8a08:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    8a0c:	54000288 	b.hi	8a5c <__divti3+0x35c>  // b.pmore
    8a10:	cb080063 	sub	x3, x3, x8
    8a14:	aa018041 	orr	x1, x2, x1, lsl #32
    8a18:	17ffffc2 	b	8920 <__divti3+0x220>
    8a1c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    8a20:	d2800001 	mov	x1, #0x0                   	// #0
    8a24:	9a9f87e0 	cset	x0, ls	// ls = plast
    8a28:	17ffff68 	b	87c8 <__divti3+0xc8>
    8a2c:	aa0103e0 	mov	x0, x1
    8a30:	d2800001 	mov	x1, #0x0                   	// #0
    8a34:	17ffff65 	b	87c8 <__divti3+0xc8>
    8a38:	d1000860 	sub	x0, x3, #0x2
    8a3c:	8b0600a5 	add	x5, x5, x6
    8a40:	17ffff52 	b	8788 <__divti3+0x88>
    8a44:	d1000961 	sub	x1, x11, #0x2
    8a48:	8b0800a5 	add	x5, x5, x8
    8a4c:	17ffff85 	b	8860 <__divti3+0x160>
    8a50:	d1000965 	sub	x5, x11, #0x2
    8a54:	8b080063 	add	x3, x3, x8
    8a58:	17ffff8e 	b	8890 <__divti3+0x190>
    8a5c:	d1000942 	sub	x2, x10, #0x2
    8a60:	8b060063 	add	x3, x3, x6
    8a64:	17ffffeb 	b	8a10 <__divti3+0x310>
    8a68:	d1000941 	sub	x1, x10, #0x2
    8a6c:	8b060000 	add	x0, x0, x6
    8a70:	17ffffdc 	b	89e0 <__divti3+0x2e0>
    8a74:	d1000900 	sub	x0, x8, #0x2
    8a78:	8b060063 	add	x3, x3, x6
    8a7c:	17ffffb4 	b	894c <__divti3+0x24c>

0000000000008a80 <__modti3>:
    8a80:	d503245f 	bti	c
    8a84:	d2800004 	mov	x4, #0x0                   	// #0
    8a88:	b6f80081 	tbz	x1, #63, 8a98 <__modti3+0x18>
    8a8c:	eb0003e0 	negs	x0, x0
    8a90:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8a94:	da0103e1 	ngc	x1, x1
    8a98:	f100007f 	cmp	x3, #0x0
    8a9c:	5400128b 	b.lt	8cec <__modti3+0x26c>  // b.tstop
    8aa0:	aa0003e7 	mov	x7, x0
    8aa4:	aa0103e6 	mov	x6, x1
    8aa8:	540004e1 	b.ne	8b44 <__modti3+0xc4>  // b.any
    8aac:	eb02003f 	cmp	x1, x2
    8ab0:	54000dc2 	b.cs	8c68 <__modti3+0x1e8>  // b.hs, b.nlast
    8ab4:	dac01043 	clz	x3, x2
    8ab8:	aa0303e5 	mov	x5, x3
    8abc:	b40000e3 	cbz	x3, 8ad8 <__modti3+0x58>
    8ac0:	4b0303e6 	neg	w6, w3
    8ac4:	9ac32021 	lsl	x1, x1, x3
    8ac8:	9ac32042 	lsl	x2, x2, x3
    8acc:	9ac62406 	lsr	x6, x0, x6
    8ad0:	aa0100c6 	orr	x6, x6, x1
    8ad4:	9ac32007 	lsl	x7, x0, x3
    8ad8:	d360fc40 	lsr	x0, x2, #32
    8adc:	92407c43 	and	x3, x2, #0xffffffff
    8ae0:	9ac008c1 	udiv	x1, x6, x0
    8ae4:	9b009826 	msub	x6, x1, x0, x6
    8ae8:	9b017c61 	mul	x1, x3, x1
    8aec:	93c780c6 	extr	x6, x6, x7, #32
    8af0:	eb06003f 	cmp	x1, x6
    8af4:	540000a9 	b.ls	8b08 <__modti3+0x88>  // b.plast
    8af8:	ab060046 	adds	x6, x2, x6
    8afc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    8b00:	8b0200c8 	add	x8, x6, x2
    8b04:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    8b08:	cb0100c6 	sub	x6, x6, x1
    8b0c:	9ac008c8 	udiv	x8, x6, x0
    8b10:	9b009901 	msub	x1, x8, x0, x6
    8b14:	aa0703e0 	mov	x0, x7
    8b18:	9b087c63 	mul	x3, x3, x8
    8b1c:	b3607c20 	bfi	x0, x1, #32, #32
    8b20:	eb00007f 	cmp	x3, x0
    8b24:	54001088 	b.hi	8d34 <__modti3+0x2b4>  // b.pmore
    8b28:	cb030000 	sub	x0, x0, x3
    8b2c:	9ac52400 	lsr	x0, x0, x5
    8b30:	d2800001 	mov	x1, #0x0                   	// #0
    8b34:	b4000064 	cbz	x4, 8b40 <__modti3+0xc0>
    8b38:	eb0003e0 	negs	x0, x0
    8b3c:	da0103e1 	ngc	x1, x1
    8b40:	d65f03c0 	ret
    8b44:	dac01066 	clz	x6, x3
    8b48:	eb03003f 	cmp	x1, x3
    8b4c:	54ffff43 	b.cc	8b34 <__modti3+0xb4>  // b.lo, b.ul, b.last
    8b50:	93407cc5 	sxtw	x5, w6
    8b54:	d2800808 	mov	x8, #0x40                  	// #64
    8b58:	cb050108 	sub	x8, x8, x5
    8b5c:	9ac62063 	lsl	x3, x3, x6
    8b60:	9ac62025 	lsl	x5, x1, x6
    8b64:	9ac82447 	lsr	x7, x2, x8
    8b68:	aa0300e7 	orr	x7, x7, x3
    8b6c:	9ac82423 	lsr	x3, x1, x8
    8b70:	92407cec 	and	x12, x7, #0xffffffff
    8b74:	d360fcea 	lsr	x10, x7, #32
    8b78:	9ac82401 	lsr	x1, x0, x8
    8b7c:	aa050021 	orr	x1, x1, x5
    8b80:	9ac62042 	lsl	x2, x2, x6
    8b84:	9ac62000 	lsl	x0, x0, x6
    8b88:	9aca086b 	udiv	x11, x3, x10
    8b8c:	9b0a8d63 	msub	x3, x11, x10, x3
    8b90:	aa0b03e5 	mov	x5, x11
    8b94:	9b0b7d89 	mul	x9, x12, x11
    8b98:	93c18063 	extr	x3, x3, x1, #32
    8b9c:	eb03013f 	cmp	x9, x3
    8ba0:	540000a9 	b.ls	8bb4 <__modti3+0x134>  // b.plast
    8ba4:	ab0300e3 	adds	x3, x7, x3
    8ba8:	d1000565 	sub	x5, x11, #0x1
    8bac:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    8bb0:	54001168 	b.hi	8ddc <__modti3+0x35c>  // b.pmore
    8bb4:	cb090063 	sub	x3, x3, x9
    8bb8:	9aca086b 	udiv	x11, x3, x10
    8bbc:	9b0a8d6a 	msub	x10, x11, x10, x3
    8bc0:	aa0b03e9 	mov	x9, x11
    8bc4:	9b0b7d8c 	mul	x12, x12, x11
    8bc8:	b3607d41 	bfi	x1, x10, #32, #32
    8bcc:	eb01019f 	cmp	x12, x1
    8bd0:	540000a9 	b.ls	8be4 <__modti3+0x164>  // b.plast
    8bd4:	ab0100e1 	adds	x1, x7, x1
    8bd8:	d1000569 	sub	x9, x11, #0x1
    8bdc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    8be0:	54000f88 	b.hi	8dd0 <__modti3+0x350>  // b.pmore
    8be4:	aa058123 	orr	x3, x9, x5, lsl #32
    8be8:	92407c4b 	and	x11, x2, #0xffffffff
    8bec:	2a0903e9 	mov	w9, w9
    8bf0:	d360fc4a 	lsr	x10, x2, #32
    8bf4:	d360fc63 	lsr	x3, x3, #32
    8bf8:	cb0c0021 	sub	x1, x1, x12
    8bfc:	aa0a03ec 	mov	x12, x10
    8c00:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    8c04:	9b0b7d25 	mul	x5, x9, x11
    8c08:	9b0b7c6b 	mul	x11, x3, x11
    8c0c:	9b0a2d29 	madd	x9, x9, x10, x11
    8c10:	92407caa 	and	x10, x5, #0xffffffff
    8c14:	9b0c7c63 	mul	x3, x3, x12
    8c18:	8b458125 	add	x5, x9, x5, lsr #32
    8c1c:	8b0d0069 	add	x9, x3, x13
    8c20:	eb05017f 	cmp	x11, x5
    8c24:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    8c28:	8b058149 	add	x9, x10, x5, lsl #32
    8c2c:	8b458063 	add	x3, x3, x5, lsr #32
    8c30:	eb03003f 	cmp	x1, x3
    8c34:	54000063 	b.cc	8c40 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    8c38:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    8c3c:	54000082 	b.cs	8c4c <__modti3+0x1cc>  // b.hs, b.nlast
    8c40:	eb020129 	subs	x9, x9, x2
    8c44:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    8c48:	cb070063 	sub	x3, x3, x7
    8c4c:	eb090000 	subs	x0, x0, x9
    8c50:	da030021 	sbc	x1, x1, x3
    8c54:	9ac62400 	lsr	x0, x0, x6
    8c58:	9ac82028 	lsl	x8, x1, x8
    8c5c:	aa000100 	orr	x0, x8, x0
    8c60:	9ac62421 	lsr	x1, x1, x6
    8c64:	17ffffb4 	b	8b34 <__modti3+0xb4>
    8c68:	b5000062 	cbnz	x2, 8c74 <__modti3+0x1f4>
    8c6c:	d2800023 	mov	x3, #0x1                   	// #1
    8c70:	9ac20862 	udiv	x2, x3, x2
    8c74:	dac01048 	clz	x8, x2
    8c78:	aa0803e5 	mov	x5, x8
    8c7c:	b5000668 	cbnz	x8, 8d48 <__modti3+0x2c8>
    8c80:	cb020020 	sub	x0, x1, x2
    8c84:	d360fc49 	lsr	x9, x2, #32
    8c88:	92407c4a 	and	x10, x2, #0xffffffff
    8c8c:	9ac90801 	udiv	x1, x0, x9
    8c90:	9b098020 	msub	x0, x1, x9, x0
    8c94:	9b0a7c21 	mul	x1, x1, x10
    8c98:	93c78000 	extr	x0, x0, x7, #32
    8c9c:	eb00003f 	cmp	x1, x0
    8ca0:	540000a9 	b.ls	8cb4 <__modti3+0x234>  // b.plast
    8ca4:	ab000040 	adds	x0, x2, x0
    8ca8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8cac:	8b020003 	add	x3, x0, x2
    8cb0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8cb4:	cb010001 	sub	x1, x0, x1
    8cb8:	9ac90820 	udiv	x0, x1, x9
    8cbc:	9b098403 	msub	x3, x0, x9, x1
    8cc0:	aa0703e1 	mov	x1, x7
    8cc4:	9b0a7c00 	mul	x0, x0, x10
    8cc8:	b3607c61 	bfi	x1, x3, #32, #32
    8ccc:	eb01001f 	cmp	x0, x1
    8cd0:	540000a9 	b.ls	8ce4 <__modti3+0x264>  // b.plast
    8cd4:	ab010041 	adds	x1, x2, x1
    8cd8:	8b020022 	add	x2, x1, x2
    8cdc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    8ce0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    8ce4:	cb000020 	sub	x0, x1, x0
    8ce8:	17ffff91 	b	8b2c <__modti3+0xac>
    8cec:	eb0203e5 	negs	x5, x2
    8cf0:	aa0003e7 	mov	x7, x0
    8cf4:	da0303e8 	ngc	x8, x3
    8cf8:	aa0503e2 	mov	x2, x5
    8cfc:	aa0803e3 	mov	x3, x8
    8d00:	aa0103e6 	mov	x6, x1
    8d04:	b4ffed48 	cbz	x8, 8aac <__modti3+0x2c>
    8d08:	eb01011f 	cmp	x8, x1
    8d0c:	54fff148 	b.hi	8b34 <__modti3+0xb4>  // b.pmore
    8d10:	dac01109 	clz	x9, x8
    8d14:	2a0903e6 	mov	w6, w9
    8d18:	b5fff1c9 	cbnz	x9, 8b50 <__modti3+0xd0>
    8d1c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    8d20:	54000068 	b.hi	8d2c <__modti3+0x2ac>  // b.pmore
    8d24:	eb050007 	subs	x7, x0, x5
    8d28:	da080021 	sbc	x1, x1, x8
    8d2c:	aa0703e0 	mov	x0, x7
    8d30:	17ffff81 	b	8b34 <__modti3+0xb4>
    8d34:	ab000040 	adds	x0, x2, x0
    8d38:	8b020002 	add	x2, x0, x2
    8d3c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    8d40:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    8d44:	17ffff79 	b	8b28 <__modti3+0xa8>
    8d48:	9ac82042 	lsl	x2, x2, x8
    8d4c:	d2800803 	mov	x3, #0x40                  	// #64
    8d50:	cb080063 	sub	x3, x3, x8
    8d54:	d360fc49 	lsr	x9, x2, #32
    8d58:	9ac82027 	lsl	x7, x1, x8
    8d5c:	92407c4a 	and	x10, x2, #0xffffffff
    8d60:	9ac32426 	lsr	x6, x1, x3
    8d64:	9ac32403 	lsr	x3, x0, x3
    8d68:	aa070063 	orr	x3, x3, x7
    8d6c:	9ac908c1 	udiv	x1, x6, x9
    8d70:	9ac82007 	lsl	x7, x0, x8
    8d74:	9b099820 	msub	x0, x1, x9, x6
    8d78:	9b017d41 	mul	x1, x10, x1
    8d7c:	93c38000 	extr	x0, x0, x3, #32
    8d80:	eb00003f 	cmp	x1, x0
    8d84:	540000a9 	b.ls	8d98 <__modti3+0x318>  // b.plast
    8d88:	ab000040 	adds	x0, x2, x0
    8d8c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8d90:	8b020006 	add	x6, x0, x2
    8d94:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    8d98:	cb010000 	sub	x0, x0, x1
    8d9c:	9ac90801 	udiv	x1, x0, x9
    8da0:	9b098026 	msub	x6, x1, x9, x0
    8da4:	aa0303e0 	mov	x0, x3
    8da8:	9b017d41 	mul	x1, x10, x1
    8dac:	b3607cc0 	bfi	x0, x6, #32, #32
    8db0:	eb00003f 	cmp	x1, x0
    8db4:	540000a9 	b.ls	8dc8 <__modti3+0x348>  // b.plast
    8db8:	ab000040 	adds	x0, x2, x0
    8dbc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8dc0:	8b020003 	add	x3, x0, x2
    8dc4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8dc8:	cb010000 	sub	x0, x0, x1
    8dcc:	17ffffb0 	b	8c8c <__modti3+0x20c>
    8dd0:	d1000969 	sub	x9, x11, #0x2
    8dd4:	8b070021 	add	x1, x1, x7
    8dd8:	17ffff83 	b	8be4 <__modti3+0x164>
    8ddc:	d1000965 	sub	x5, x11, #0x2
    8de0:	8b070063 	add	x3, x3, x7
    8de4:	17ffff74 	b	8bb4 <__modti3+0x134>
    8de8:	d503201f 	nop
    8dec:	d503201f 	nop

0000000000008df0 <atexit>:
    8df0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    8df4:	900000c2 	adrp	x2, 20000 <__data_start>
    8df8:	d2800001 	mov	x1, #0x0                   	// #0
    8dfc:	910003fd 	mov	x29, sp
    8e00:	a8c17bfd 	ldp	x29, x30, [sp], #16
    8e04:	f9400442 	ldr	x2, [x2, #8]
    8e08:	17ffe17e 	b	1400 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000008e0c <_fini>:
    8e0c:	d503201f 	nop
    8e10:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    8e14:	910003fd 	mov	x29, sp
    8e18:	a8c17bfd 	ldp	x29, x30, [sp], #16
    8e1c:	d65f03c0 	ret
