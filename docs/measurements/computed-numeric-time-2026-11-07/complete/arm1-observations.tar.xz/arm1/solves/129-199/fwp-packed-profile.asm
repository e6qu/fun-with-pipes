
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-packed-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001328 <_init>:
    1328:	d503201f 	nop
    132c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1330:	910003fd 	mov	x29, sp
    1334:	94000190 	bl	1974 <call_weak_fn>
    1338:	a8c17bfd 	ldp	x29, x30, [sp], #16
    133c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001340 <.plt>:
    1340:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1344:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1348:	f946fe11 	ldr	x17, [x16, #3576]
    134c:	9137e210 	add	x16, x16, #0xdf8
    1350:	d61f0220 	br	x17
    1354:	d503201f 	nop
    1358:	d503201f 	nop
    135c:	d503201f 	nop

0000000000001360 <memcpy@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1364:	f9470211 	ldr	x17, [x16, #3584]
    1368:	91380210 	add	x16, x16, #0xe00
    136c:	d61f0220 	br	x17

0000000000001370 <sigaltstack@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1374:	f9470611 	ldr	x17, [x16, #3592]
    1378:	91382210 	add	x16, x16, #0xe08
    137c:	d61f0220 	br	x17

0000000000001380 <_exit@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1384:	f9470a11 	ldr	x17, [x16, #3600]
    1388:	91384210 	add	x16, x16, #0xe10
    138c:	d61f0220 	br	x17

0000000000001390 <strlen@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1394:	f9470e11 	ldr	x17, [x16, #3608]
    1398:	91386210 	add	x16, x16, #0xe18
    139c:	d61f0220 	br	x17

00000000000013a0 <__sprintf_chk@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13a4:	f9471211 	ldr	x17, [x16, #3616]
    13a8:	91388210 	add	x16, x16, #0xe20
    13ac:	d61f0220 	br	x17

00000000000013b0 <exit@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13b4:	f9471611 	ldr	x17, [x16, #3624]
    13b8:	9138a210 	add	x16, x16, #0xe28
    13bc:	d61f0220 	br	x17

00000000000013c0 <__libc_start_main@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13c4:	f9471a11 	ldr	x17, [x16, #3632]
    13c8:	9138c210 	add	x16, x16, #0xe30
    13cc:	d61f0220 	br	x17

00000000000013d0 <strtoll@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13d4:	f9471e11 	ldr	x17, [x16, #3640]
    13d8:	9138e210 	add	x16, x16, #0xe38
    13dc:	d61f0220 	br	x17

00000000000013e0 <strtod@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13e4:	f9472211 	ldr	x17, [x16, #3648]
    13e8:	91390210 	add	x16, x16, #0xe40
    13ec:	d61f0220 	br	x17

00000000000013f0 <__cxa_finalize@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    13f4:	f9472611 	ldr	x17, [x16, #3656]
    13f8:	91392210 	add	x16, x16, #0xe48
    13fc:	d61f0220 	br	x17

0000000000001400 <__cxa_atexit@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1404:	f9472a11 	ldr	x17, [x16, #3664]
    1408:	91394210 	add	x16, x16, #0xe50
    140c:	d61f0220 	br	x17

0000000000001410 <pthread_attr_init@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1414:	f9472e11 	ldr	x17, [x16, #3672]
    1418:	91396210 	add	x16, x16, #0xe58
    141c:	d61f0220 	br	x17

0000000000001420 <fputc@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1424:	f9473211 	ldr	x17, [x16, #3680]
    1428:	91398210 	add	x16, x16, #0xe60
    142c:	d61f0220 	br	x17

0000000000001430 <clock_gettime@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1434:	f9473611 	ldr	x17, [x16, #3688]
    1438:	9139a210 	add	x16, x16, #0xe68
    143c:	d61f0220 	br	x17

0000000000001440 <setvbuf@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1444:	f9473a11 	ldr	x17, [x16, #3696]
    1448:	9139c210 	add	x16, x16, #0xe70
    144c:	d61f0220 	br	x17

0000000000001450 <__memcpy_chk@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1454:	f9473e11 	ldr	x17, [x16, #3704]
    1458:	9139e210 	add	x16, x16, #0xe78
    145c:	d61f0220 	br	x17

0000000000001460 <signal@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1464:	f9474211 	ldr	x17, [x16, #3712]
    1468:	913a0210 	add	x16, x16, #0xe80
    146c:	d61f0220 	br	x17

0000000000001470 <__snprintf_chk@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1474:	f9474611 	ldr	x17, [x16, #3720]
    1478:	913a2210 	add	x16, x16, #0xe88
    147c:	d61f0220 	br	x17

0000000000001480 <fclose@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1484:	f9474a11 	ldr	x17, [x16, #3728]
    1488:	913a4210 	add	x16, x16, #0xe90
    148c:	d61f0220 	br	x17

0000000000001490 <fopen@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1494:	f9474e11 	ldr	x17, [x16, #3736]
    1498:	913a6210 	add	x16, x16, #0xe98
    149c:	d61f0220 	br	x17

00000000000014a0 <malloc@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14a4:	f9475211 	ldr	x17, [x16, #3744]
    14a8:	913a8210 	add	x16, x16, #0xea0
    14ac:	d61f0220 	br	x17

00000000000014b0 <pthread_attr_destroy@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14b4:	f9475611 	ldr	x17, [x16, #3752]
    14b8:	913aa210 	add	x16, x16, #0xea8
    14bc:	d61f0220 	br	x17

00000000000014c0 <sigemptyset@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14c4:	f9475a11 	ldr	x17, [x16, #3760]
    14c8:	913ac210 	add	x16, x16, #0xeb0
    14cc:	d61f0220 	br	x17

00000000000014d0 <memset@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14d4:	f9475e11 	ldr	x17, [x16, #3768]
    14d8:	913ae210 	add	x16, x16, #0xeb8
    14dc:	d61f0220 	br	x17

00000000000014e0 <calloc@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14e4:	f9476211 	ldr	x17, [x16, #3776]
    14e8:	913b0210 	add	x16, x16, #0xec0
    14ec:	d61f0220 	br	x17

00000000000014f0 <realloc@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    14f4:	f9476611 	ldr	x17, [x16, #3784]
    14f8:	913b2210 	add	x16, x16, #0xec8
    14fc:	d61f0220 	br	x17

0000000000001500 <__stack_chk_fail@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1504:	f9476a11 	ldr	x17, [x16, #3792]
    1508:	913b4210 	add	x16, x16, #0xed0
    150c:	d61f0220 	br	x17

0000000000001510 <close@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1514:	f9476e11 	ldr	x17, [x16, #3800]
    1518:	913b6210 	add	x16, x16, #0xed8
    151c:	d61f0220 	br	x17

0000000000001520 <sigaction@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1524:	f9477211 	ldr	x17, [x16, #3808]
    1528:	913b8210 	add	x16, x16, #0xee0
    152c:	d61f0220 	br	x17

0000000000001530 <__gmon_start__@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1534:	f9477611 	ldr	x17, [x16, #3816]
    1538:	913ba210 	add	x16, x16, #0xee8
    153c:	d61f0220 	br	x17

0000000000001540 <write@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1544:	f9477a11 	ldr	x17, [x16, #3824]
    1548:	913bc210 	add	x16, x16, #0xef0
    154c:	d61f0220 	br	x17

0000000000001550 <abort@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1554:	f9477e11 	ldr	x17, [x16, #3832]
    1558:	913be210 	add	x16, x16, #0xef8
    155c:	d61f0220 	br	x17

0000000000001560 <swapcontext@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1564:	f9478211 	ldr	x17, [x16, #3840]
    1568:	913c0210 	add	x16, x16, #0xf00
    156c:	d61f0220 	br	x17

0000000000001570 <__fprintf_chk@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1574:	f9478611 	ldr	x17, [x16, #3848]
    1578:	913c2210 	add	x16, x16, #0xf08
    157c:	d61f0220 	br	x17

0000000000001580 <strcmp@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1584:	f9478a11 	ldr	x17, [x16, #3856]
    1588:	913c4210 	add	x16, x16, #0xf10
    158c:	d61f0220 	br	x17

0000000000001590 <mmap@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1594:	f9478e11 	ldr	x17, [x16, #3864]
    1598:	913c6210 	add	x16, x16, #0xf18
    159c:	d61f0220 	br	x17

00000000000015a0 <strtol@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15a4:	f9479211 	ldr	x17, [x16, #3872]
    15a8:	913c8210 	add	x16, x16, #0xf20
    15ac:	d61f0220 	br	x17

00000000000015b0 <strtof@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15b4:	f9479611 	ldr	x17, [x16, #3880]
    15b8:	913ca210 	add	x16, x16, #0xf28
    15bc:	d61f0220 	br	x17

00000000000015c0 <free@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15c4:	f9479a11 	ldr	x17, [x16, #3888]
    15c8:	913cc210 	add	x16, x16, #0xf30
    15cc:	d61f0220 	br	x17

00000000000015d0 <nanosleep@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15d4:	f9479e11 	ldr	x17, [x16, #3896]
    15d8:	913ce210 	add	x16, x16, #0xf38
    15dc:	d61f0220 	br	x17

00000000000015e0 <strchr@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15e4:	f947a211 	ldr	x17, [x16, #3904]
    15e8:	913d0210 	add	x16, x16, #0xf40
    15ec:	d61f0220 	br	x17

00000000000015f0 <strtoull@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    15f4:	f947a611 	ldr	x17, [x16, #3912]
    15f8:	913d2210 	add	x16, x16, #0xf48
    15fc:	d61f0220 	br	x17

0000000000001600 <fwrite@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1604:	f947aa11 	ldr	x17, [x16, #3920]
    1608:	913d4210 	add	x16, x16, #0xf50
    160c:	d61f0220 	br	x17

0000000000001610 <pthread_create@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1614:	f947ae11 	ldr	x17, [x16, #3928]
    1618:	913d6210 	add	x16, x16, #0xf58
    161c:	d61f0220 	br	x17

0000000000001620 <munmap@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1624:	f947b211 	ldr	x17, [x16, #3936]
    1628:	913d8210 	add	x16, x16, #0xf60
    162c:	d61f0220 	br	x17

0000000000001630 <fflush@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1634:	f947b611 	ldr	x17, [x16, #3944]
    1638:	913da210 	add	x16, x16, #0xf68
    163c:	d61f0220 	br	x17

0000000000001640 <strcpy@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1644:	f947ba11 	ldr	x17, [x16, #3952]
    1648:	913dc210 	add	x16, x16, #0xf70
    164c:	d61f0220 	br	x17

0000000000001650 <sysconf@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1654:	f947be11 	ldr	x17, [x16, #3960]
    1658:	913de210 	add	x16, x16, #0xf78
    165c:	d61f0220 	br	x17

0000000000001660 <strstr@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1664:	f947c211 	ldr	x17, [x16, #3968]
    1668:	913e0210 	add	x16, x16, #0xf80
    166c:	d61f0220 	br	x17

0000000000001670 <_Exit@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1674:	f947c611 	ldr	x17, [x16, #3976]
    1678:	913e2210 	add	x16, x16, #0xf88
    167c:	d61f0220 	br	x17

0000000000001680 <pthread_join@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1684:	f947ca11 	ldr	x17, [x16, #3984]
    1688:	913e4210 	add	x16, x16, #0xf90
    168c:	d61f0220 	br	x17

0000000000001690 <getenv@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    1694:	f947ce11 	ldr	x17, [x16, #3992]
    1698:	913e6210 	add	x16, x16, #0xf98
    169c:	d61f0220 	br	x17

00000000000016a0 <mprotect@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    16a4:	f947d211 	ldr	x17, [x16, #4000]
    16a8:	913e8210 	add	x16, x16, #0xfa0
    16ac:	d61f0220 	br	x17

00000000000016b0 <fgets@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    16b4:	f947d611 	ldr	x17, [x16, #4008]
    16b8:	913ea210 	add	x16, x16, #0xfa8
    16bc:	d61f0220 	br	x17

00000000000016c0 <pthread_attr_setstacksize@plt>:
    16c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x14da0>
    16c4:	f947da11 	ldr	x17, [x16, #4016]
    16c8:	913ec210 	add	x16, x16, #0xfb0
    16cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001700 <fwp_trap_overflow.constprop.0>:
    1700:	d10243ff 	sub	sp, sp, #0x90
    1704:	d2800c03 	mov	x3, #0x60                  	// #96
    1708:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    170c:	f947f421 	ldr	x1, [x1, #4072]
    1710:	90000045 	adrp	x5, 9000 <_IO_stdin_used+0x1f0>
    1714:	a9077bfd 	stp	x29, x30, [sp, #112]
    1718:	9101c3fd 	add	x29, sp, #0x70
    171c:	910180a5 	add	x5, x5, #0x60
    1720:	90000044 	adrp	x4, 9000 <_IO_stdin_used+0x1f0>
    1724:	f90043f3 	str	x19, [sp, #128]
    1728:	9101a084 	add	x4, x4, #0x68
    172c:	910023f3 	add	x19, sp, #0x8
    1730:	f9400022 	ldr	x2, [x1]
    1734:	f90037e2 	str	x2, [sp, #104]
    1738:	d2800002 	mov	x2, #0x0                   	// #0
    173c:	aa0303e1 	mov	x1, x3
    1740:	52800042 	mov	w2, #0x2                   	// #2
    1744:	aa1303e0 	mov	x0, x19
    1748:	97ffff4a 	bl	1470 <__snprintf_chk@plt>
    174c:	aa1303e0 	mov	x0, x19
    1750:	940002cc 	bl	2280 <fwp_trap>
    1754:	d503201f 	nop
    1758:	d503201f 	nop
    175c:	d503201f 	nop

0000000000001760 <main>:
    1760:	d10243ff 	sub	sp, sp, #0x90
    1764:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1768:	f947f400 	ldr	x0, [x0, #4072]
    176c:	a9067bfd 	stp	x29, x30, [sp, #96]
    1770:	910183fd 	add	x29, sp, #0x60
    1774:	a90753f3 	stp	x19, x20, [sp, #112]
    1778:	f00000f3 	adrp	x19, 20000 <__data_start>
    177c:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x14da0>
    1780:	f947ee94 	ldr	x20, [x20, #4056]
    1784:	f9400281 	ldr	x1, [x20]
    1788:	f90043f5 	str	x21, [sp, #128]
    178c:	f9400002 	ldr	x2, [x0]
    1790:	f9002fe2 	str	x2, [sp, #88]
    1794:	d2800002 	mov	x2, #0x0                   	// #0
    1798:	f9004261 	str	x1, [x19, #128]
    179c:	940002c9 	bl	22c0 <fwp_now_ns>
    17a0:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    17a4:	910d0000 	add	x0, x0, #0x340
    17a8:	97ffffba 	bl	1690 <getenv@plt>
    17ac:	b4000080 	cbz	x0, 17bc <main+0x5c>
    17b0:	39400001 	ldrb	w1, [x0]
    17b4:	aa0003f5 	mov	x21, x0
    17b8:	35000801 	cbnz	w1, 18b8 <main+0x158>
    17bc:	910023e1 	add	x1, sp, #0x8
    17c0:	52800000 	mov	w0, #0x0                   	// #0
    17c4:	97ffff1b 	bl	1430 <clock_gettime@plt>
    17c8:	35000900 	cbnz	w0, 18e8 <main+0x188>
    17cc:	a9408be0 	ldp	x0, x2, [sp, #8]
    17d0:	d2994003 	mov	x3, #0xca00                	// #51712
    17d4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    17d8:	9b037c01 	mul	x1, x0, x3
    17dc:	9b437c00 	smulh	x0, x0, x3
    17e0:	ab020021 	adds	x1, x1, x2
    17e4:	937ffc42 	asr	x2, x2, #63
    17e8:	9a020000 	adc	x0, x0, x2
    17ec:	f100003f 	cmp	x1, #0x0
    17f0:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    17f4:	b50009a0 	cbnz	x0, 1928 <main+0x1c8>
    17f8:	f9400280 	ldr	x0, [x20]
    17fc:	d2a00023 	mov	x3, #0x10000               	// #65536
    1800:	52800002 	mov	w2, #0x0                   	// #0
    1804:	d2800001 	mov	x1, #0x0                   	// #0
    1808:	910063f5 	add	x21, sp, #0x18
    180c:	97ffff0d 	bl	1440 <setvbuf@plt>
    1810:	d2800021 	mov	x1, #0x1                   	// #1
    1814:	528001a0 	mov	w0, #0xd                   	// #13
    1818:	97ffff12 	bl	1460 <signal@plt>
    181c:	aa1503e0 	mov	x0, x21
    1820:	97fffefc 	bl	1410 <pthread_attr_init@plt>
    1824:	350007c0 	cbnz	w0, 191c <main+0x1bc>
    1828:	aa1503e0 	mov	x0, x21
    182c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    1830:	97ffffa4 	bl	16c0 <pthread_attr_setstacksize@plt>
    1834:	35000680 	cbnz	w0, 1904 <main+0x1a4>
    1838:	aa1503e1 	mov	x1, x21
    183c:	910023e0 	add	x0, sp, #0x8
    1840:	f0000022 	adrp	x2, 8000 <f0+0x2340>
    1844:	d2800003 	mov	x3, #0x0                   	// #0
    1848:	91051042 	add	x2, x2, #0x144
    184c:	97ffff71 	bl	1610 <pthread_create@plt>
    1850:	2a0003e1 	mov	w1, w0
    1854:	aa1503e0 	mov	x0, x21
    1858:	2a0103f5 	mov	w21, w1
    185c:	97ffff15 	bl	14b0 <pthread_attr_destroy@plt>
    1860:	350006a0 	cbnz	w0, 1934 <main+0x1d4>
    1864:	350004b5 	cbnz	w21, 18f8 <main+0x198>
    1868:	f94007e0 	ldr	x0, [sp, #8]
    186c:	d2800001 	mov	x1, #0x0                   	// #0
    1870:	97ffff84 	bl	1680 <pthread_join@plt>
    1874:	35000600 	cbnz	w0, 1934 <main+0x1d4>
    1878:	f9400280 	ldr	x0, [x20]
    187c:	91020273 	add	x19, x19, #0x80
    1880:	97ffff6c 	bl	1630 <fflush@plt>
    1884:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    1888:	f947f421 	ldr	x1, [x1, #4072]
    188c:	b942e260 	ldr	w0, [x19, #736]
    1890:	f9402fe3 	ldr	x3, [sp, #88]
    1894:	f9400022 	ldr	x2, [x1]
    1898:	eb020063 	subs	x3, x3, x2
    189c:	d2800002 	mov	x2, #0x0                   	// #0
    18a0:	540002a1 	b.ne	18f4 <main+0x194>  // b.any
    18a4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    18a8:	a94753f3 	ldp	x19, x20, [sp, #112]
    18ac:	f94043f5 	ldr	x21, [sp, #128]
    18b0:	910243ff 	add	sp, sp, #0x90
    18b4:	d65f03c0 	ret
    18b8:	910003e1 	mov	x1, sp
    18bc:	52800142 	mov	w2, #0xa                   	// #10
    18c0:	97ffff4c 	bl	15f0 <strtoull@plt>
    18c4:	f94003e0 	ldr	x0, [sp]
    18c8:	39400000 	ldrb	w0, [x0]
    18cc:	35fff780 	cbnz	w0, 17bc <main+0x5c>
    18d0:	394002a0 	ldrb	w0, [x21]
    18d4:	52801fa1 	mov	w1, #0xfd                  	// #253
    18d8:	5100ac00 	sub	w0, w0, #0x2b
    18dc:	6a01001f 	tst	w0, w1
    18e0:	54fff6e0 	b.eq	17bc <main+0x5c>  // b.none
    18e4:	17ffffc5 	b	17f8 <main+0x98>
    18e8:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    18ec:	910d4000 	add	x0, x0, #0x350
    18f0:	94000264 	bl	2280 <fwp_trap>
    18f4:	97ffff03 	bl	1500 <__stack_chk_fail@plt>
    18f8:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    18fc:	910fc000 	add	x0, x0, #0x3f0
    1900:	94000260 	bl	2280 <fwp_trap>
    1904:	aa1503e0 	mov	x0, x21
    1908:	97fffeea 	bl	14b0 <pthread_attr_destroy@plt>
    190c:	35000140 	cbnz	w0, 1934 <main+0x1d4>
    1910:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    1914:	910f2000 	add	x0, x0, #0x3c8
    1918:	9400025a 	bl	2280 <fwp_trap>
    191c:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    1920:	910e6000 	add	x0, x0, #0x398
    1924:	94000257 	bl	2280 <fwp_trap>
    1928:	90000040 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    192c:	910dc000 	add	x0, x0, #0x370
    1930:	94000254 	bl	2280 <fwp_trap>
    1934:	97ffff07 	bl	1550 <abort@plt>
    1938:	d503201f 	nop
    193c:	d503201f 	nop

0000000000001940 <_start>:
    1940:	d503201f 	nop
    1944:	d280001d 	mov	x29, #0x0                   	// #0
    1948:	d280001e 	mov	x30, #0x0                   	// #0
    194c:	aa0003e5 	mov	x5, x0
    1950:	f94003e1 	ldr	x1, [sp]
    1954:	910023e2 	add	x2, sp, #0x8
    1958:	910003e6 	mov	x6, sp
    195c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1960:	f947f800 	ldr	x0, [x0, #4080]
    1964:	d2800003 	mov	x3, #0x0                   	// #0
    1968:	d2800004 	mov	x4, #0x0                   	// #0
    196c:	97fffe95 	bl	13c0 <__libc_start_main@plt>
    1970:	97fffef8 	bl	1550 <abort@plt>

0000000000001974 <call_weak_fn>:
    1974:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1978:	f947f000 	ldr	x0, [x0, #4064]
    197c:	b4000040 	cbz	x0, 1984 <call_weak_fn+0x10>
    1980:	17fffeec 	b	1530 <__gmon_start__@plt>
    1984:	d65f03c0 	ret
    1988:	d503201f 	nop
    198c:	d503201f 	nop

0000000000001990 <deregister_tm_clones>:
    1990:	f00000e0 	adrp	x0, 20000 <__data_start>
    1994:	9101a000 	add	x0, x0, #0x68
    1998:	f00000e1 	adrp	x1, 20000 <__data_start>
    199c:	9101a021 	add	x1, x1, #0x68
    19a0:	eb00003f 	cmp	x1, x0
    19a4:	540000c0 	b.eq	19bc <deregister_tm_clones+0x2c>  // b.none
    19a8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    19ac:	f947e021 	ldr	x1, [x1, #4032]
    19b0:	b4000061 	cbz	x1, 19bc <deregister_tm_clones+0x2c>
    19b4:	aa0103f0 	mov	x16, x1
    19b8:	d61f0200 	br	x16
    19bc:	d65f03c0 	ret

00000000000019c0 <register_tm_clones>:
    19c0:	f00000e0 	adrp	x0, 20000 <__data_start>
    19c4:	9101a000 	add	x0, x0, #0x68
    19c8:	f00000e1 	adrp	x1, 20000 <__data_start>
    19cc:	9101a021 	add	x1, x1, #0x68
    19d0:	cb000021 	sub	x1, x1, x0
    19d4:	d37ffc22 	lsr	x2, x1, #63
    19d8:	8b810c41 	add	x1, x2, x1, asr #3
    19dc:	9341fc21 	asr	x1, x1, #1
    19e0:	b40000c1 	cbz	x1, 19f8 <register_tm_clones+0x38>
    19e4:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14da0>
    19e8:	f947fc42 	ldr	x2, [x2, #4088]
    19ec:	b4000062 	cbz	x2, 19f8 <register_tm_clones+0x38>
    19f0:	aa0203f0 	mov	x16, x2
    19f4:	d61f0200 	br	x16
    19f8:	d65f03c0 	ret
    19fc:	d503201f 	nop

0000000000001a00 <__do_global_dtors_aux>:
    1a00:	d503233f 	paciasp
    1a04:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1a08:	910003fd 	mov	x29, sp
    1a0c:	f9000bf3 	str	x19, [sp, #16]
    1a10:	f00000f3 	adrp	x19, 20000 <__data_start>
    1a14:	3941c260 	ldrb	w0, [x19, #112]
    1a18:	37000140 	tbnz	w0, #0, 1a40 <__do_global_dtors_aux+0x40>
    1a1c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1a20:	f947e400 	ldr	x0, [x0, #4040]
    1a24:	b4000080 	cbz	x0, 1a34 <__do_global_dtors_aux+0x34>
    1a28:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a2c:	f9400400 	ldr	x0, [x0, #8]
    1a30:	97fffe70 	bl	13f0 <__cxa_finalize@plt>
    1a34:	97ffffd7 	bl	1990 <deregister_tm_clones>
    1a38:	52800020 	mov	w0, #0x1                   	// #1
    1a3c:	3901c260 	strb	w0, [x19, #112]
    1a40:	f9400bf3 	ldr	x19, [sp, #16]
    1a44:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a48:	d50323bf 	autiasp
    1a4c:	d65f03c0 	ret

0000000000001a50 <frame_dummy>:
    1a50:	d503245f 	bti	c
    1a54:	17ffffdb 	b	19c0 <register_tm_clones>
    1a58:	d503201f 	nop
    1a5c:	d503201f 	nop

0000000000001a60 <fwp_fmt_u128>:
    1a60:	d10183ff 	sub	sp, sp, #0x60
    1a64:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    1a68:	f947f421 	ldr	x1, [x1, #4072]
    1a6c:	a9057bfd 	stp	x29, x30, [sp, #80]
    1a70:	910143fd 	add	x29, sp, #0x50
    1a74:	f9400024 	ldr	x4, [x1]
    1a78:	f90027e4 	str	x4, [sp, #72]
    1a7c:	d2800004 	mov	x4, #0x0                   	// #0
    1a80:	aa030041 	orr	x1, x2, x3
    1a84:	b5000361 	cbnz	x1, 1af0 <fwp_fmt_u128+0x90>
    1a88:	910023e9 	add	x9, sp, #0x8
    1a8c:	52800601 	mov	w1, #0x30                  	// #48
    1a90:	5280002d 	mov	w13, #0x1                   	// #1
    1a94:	390023e1 	strb	w1, [sp, #8]
    1a98:	93407dad 	sxtw	x13, w13
    1a9c:	aa0d03e1 	mov	x1, x13
    1aa0:	8b0d0004 	add	x4, x0, x13
    1aa4:	d503201f 	nop
    1aa8:	8b010123 	add	x3, x9, x1
    1aac:	cb0103e2 	neg	x2, x1
    1ab0:	d1000421 	sub	x1, x1, #0x1
    1ab4:	385ff063 	ldurb	w3, [x3, #-1]
    1ab8:	38226883 	strb	w3, [x4, x2]
    1abc:	35ffff61 	cbnz	w1, 1aa8 <fwp_fmt_u128+0x48>
    1ac0:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    1ac4:	f947f421 	ldr	x1, [x1, #4072]
    1ac8:	382d681f 	strb	wzr, [x0, x13]
    1acc:	aa0103e0 	mov	x0, x1
    1ad0:	f94027e2 	ldr	x2, [sp, #72]
    1ad4:	f9400001 	ldr	x1, [x0]
    1ad8:	eb010042 	subs	x2, x2, x1
    1adc:	d2800001 	mov	x1, #0x0                   	// #0
    1ae0:	54000561 	b.ne	1b8c <fwp_fmt_u128+0x12c>  // b.any
    1ae4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1ae8:	910183ff 	add	sp, sp, #0x60
    1aec:	d65f03c0 	ret
    1af0:	90000041 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    1af4:	91138021 	add	x1, x1, #0x4e0
    1af8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1afc:	910023e9 	add	x9, sp, #0x8
    1b00:	d2800027 	mov	x7, #0x1                   	// #1
    1b04:	f29999af 	movk	x15, #0xcccd
    1b08:	a9402826 	ldp	x6, x10, [x1]
    1b0c:	d503201f 	nop
    1b10:	ab030041 	adds	x1, x2, x3
    1b14:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1b18:	aa0303eb 	mov	x11, x3
    1b1c:	8b070128 	add	x8, x9, x7
    1b20:	aa0203ee 	mov	x14, x2
    1b24:	aa0703ed 	mov	x13, x7
    1b28:	910004e7 	add	x7, x7, #0x1
    1b2c:	9bcf7c24 	umulh	x4, x1, x15
    1b30:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1b34:	8b4408a4 	add	x4, x5, x4, lsr #2
    1b38:	cb040021 	sub	x1, x1, x4
    1b3c:	eb010041 	subs	x1, x2, x1
    1b40:	da1f0063 	sbc	x3, x3, xzr
    1b44:	9bc67c24 	umulh	x4, x1, x6
    1b48:	9b061064 	madd	x4, x3, x6, x4
    1b4c:	9b067c2c 	mul	x12, x1, x6
    1b50:	9b0a1024 	madd	x4, x1, x10, x4
    1b54:	9bc67c25 	umulh	x5, x1, x6
    1b58:	9b061465 	madd	x5, x3, x6, x5
    1b5c:	9b0a1425 	madd	x5, x1, x10, x5
    1b60:	93cc0484 	extr	x4, x4, x12, #1
    1b64:	8b040884 	add	x4, x4, x4, lsl #2
    1b68:	d341fca3 	lsr	x3, x5, #1
    1b6c:	cb040444 	sub	x4, x2, x4, lsl #1
    1b70:	93cc04a2 	extr	x2, x5, x12, #1
    1b74:	1100c084 	add	w4, w4, #0x30
    1b78:	381ff104 	sturb	w4, [x8, #-1]
    1b7c:	b5fffcab 	cbnz	x11, 1b10 <fwp_fmt_u128+0xb0>
    1b80:	f10025df 	cmp	x14, #0x9
    1b84:	54fffc68 	b.hi	1b10 <fwp_fmt_u128+0xb0>  // b.pmore
    1b88:	17ffffc4 	b	1a98 <fwp_fmt_u128+0x38>
    1b8c:	97fffe5d 	bl	1500 <__stack_chk_fail@plt>

0000000000001b90 <fwp_range_release>:
    1b90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b94:	910003fd 	mov	x29, sp
    1b98:	f9400801 	ldr	x1, [x0, #16]
    1b9c:	f9000bf3 	str	x19, [sp, #16]
    1ba0:	aa0003f3 	mov	x19, x0
    1ba4:	b4000061 	cbz	x1, 1bb0 <fwp_range_release+0x20>
    1ba8:	f9400400 	ldr	x0, [x0, #8]
    1bac:	d63f0020 	blr	x1
    1bb0:	f9400260 	ldr	x0, [x19]
    1bb4:	f9400e61 	ldr	x1, [x19, #24]
    1bb8:	f9400bf3 	ldr	x19, [sp, #16]
    1bbc:	aa0103f0 	mov	x16, x1
    1bc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1bc4:	d61f0200 	br	x16
    1bc8:	d503201f 	nop
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_flush>:
    1bd0:	f00000e0 	adrp	x0, 20000 <__data_start>
    1bd4:	f9404000 	ldr	x0, [x0, #128]
    1bd8:	b4000120 	cbz	x0, 1bfc <fwp_flush+0x2c>
    1bdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1be0:	910003fd 	mov	x29, sp
    1be4:	97fffe93 	bl	1630 <fflush@plt>
    1be8:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1bec:	f947ec00 	ldr	x0, [x0, #4056]
    1bf0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1bf4:	f9400000 	ldr	x0, [x0]
    1bf8:	17fffe8e 	b	1630 <fflush@plt>
    1bfc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1c00:	f947ec00 	ldr	x0, [x0, #4056]
    1c04:	f9400000 	ldr	x0, [x0]
    1c08:	17fffe8a 	b	1630 <fflush@plt>
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_segv>:
    1c10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c14:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c18:	91020043 	add	x3, x2, #0x80
    1c1c:	910003fd 	mov	x29, sp
    1c20:	a90153f3 	stp	x19, x20, [sp, #16]
    1c24:	2a0003f3 	mov	w19, w0
    1c28:	f9400460 	ldr	x0, [x3, #8]
    1c2c:	f90013f5 	str	x21, [sp, #32]
    1c30:	f9400835 	ldr	x21, [x1, #16]
    1c34:	b4000280 	cbz	x0, 1c84 <fwp_segv+0x74>
    1c38:	f9400814 	ldr	x20, [x0, #16]
    1c3c:	b4000254 	cbz	x20, 1c84 <fwp_segv+0x74>
    1c40:	528003c0 	mov	w0, #0x1e                  	// #30
    1c44:	97fffe83 	bl	1650 <sysconf@plt>
    1c48:	f144029f 	cmp	x20, #0x100, lsl #12
    1c4c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c50:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c54:	8b000294 	add	x20, x20, x0
    1c58:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c5c:	eb0102bf 	cmp	x21, x1
    1c60:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1c64:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c68:	35000240 	cbnz	w0, 1cb0 <fwp_segv+0xa0>
    1c6c:	f94013f5 	ldr	x21, [sp, #32]
    1c70:	2a1303e0 	mov	w0, w19
    1c74:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c78:	d2800001 	mov	x1, #0x0                   	// #0
    1c7c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c80:	17fffdf8 	b	1460 <signal@plt>
    1c84:	91020042 	add	x2, x2, #0x80
    1c88:	f9400840 	ldr	x0, [x2, #16]
    1c8c:	b4ffff00 	cbz	x0, 1c6c <fwp_segv+0x5c>
    1c90:	f9400c41 	ldr	x1, [x2, #24]
    1c94:	cb010000 	sub	x0, x0, x1
    1c98:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1c9c:	91440000 	add	x0, x0, #0x100, lsl #12
    1ca0:	eb15003f 	cmp	x1, x21
    1ca4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1ca8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1cac:	34fffe00 	cbz	w0, 1c6c <fwp_segv+0x5c>
    1cb0:	97ffffc8 	bl	1bd0 <fwp_flush>
    1cb4:	90000041 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    1cb8:	91130021 	add	x1, x1, #0x4c0
    1cbc:	d2800342 	mov	x2, #0x1a                  	// #26
    1cc0:	52800040 	mov	w0, #0x2                   	// #2
    1cc4:	97fffe1f 	bl	1540 <write@plt>
    1cc8:	52800ca0 	mov	w0, #0x65                  	// #101
    1ccc:	97fffdad 	bl	1380 <_exit@plt>

0000000000001cd0 <fwp_heap_oom>:
    1cd0:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14da0>
    1cd4:	f947e863 	ldr	x3, [x3, #4048]
    1cd8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1cdc:	d2800262 	mov	x2, #0x13                  	// #19
    1ce0:	910003fd 	mov	x29, sp
    1ce4:	f9400063 	ldr	x3, [x3]
    1ce8:	d2800021 	mov	x1, #0x1                   	// #1
    1cec:	f0000020 	adrp	x0, 8000 <f0+0x2340>
    1cf0:	91386000 	add	x0, x0, #0xe18
    1cf4:	97fffe43 	bl	1600 <fwrite@plt>
    1cf8:	d2800000 	mov	x0, #0x0                   	// #0
    1cfc:	97fffe4d 	bl	1630 <fflush@plt>
    1d00:	52800cc0 	mov	w0, #0x66                  	// #102
    1d04:	97fffe5b 	bl	1670 <_Exit@plt>
    1d08:	d503201f 	nop
    1d0c:	d503201f 	nop

0000000000001d10 <fwp_heap_chunks>:
    1d10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d14:	910003fd 	mov	x29, sp
    1d18:	a90153f3 	stp	x19, x20, [sp, #16]
    1d1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1d20:	90000195 	adrp	x21, 31000 <fwp_root_context+0xc80>
    1d24:	911582a1 	add	x1, x21, #0x560
    1d28:	f100041f 	cmp	x0, #0x1
    1d2c:	54000ca0 	b.eq	1ec0 <fwp_heap_chunks+0x1b0>  // b.none
    1d30:	f949f822 	ldr	x2, [x1, #5104]
    1d34:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaa0>
    1d38:	912540a5 	add	x5, x5, #0x950
    1d3c:	911582a1 	add	x1, x21, #0x560
    1d40:	f949ec34 	ldr	x20, [x1, #5080]
    1d44:	eb14005f 	cmp	x2, x20
    1d48:	54000c42 	b.cs	1ed0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1d4c:	f949fc23 	ldr	x3, [x1, #5112]
    1d50:	8b020841 	add	x1, x2, x2, lsl #2
    1d54:	d2800004 	mov	x4, #0x0                   	// #0
    1d58:	8b010c61 	add	x1, x3, x1, lsl #3
    1d5c:	14000009 	b	1d80 <fwp_heap_chunks+0x70>
    1d60:	91000483 	add	x3, x4, #0x1
    1d64:	eb03001f 	cmp	x0, x3
    1d68:	54000940 	b.eq	1e90 <fwp_heap_chunks+0x180>  // b.none
    1d6c:	91000442 	add	x2, x2, #0x1
    1d70:	aa0303e4 	mov	x4, x3
    1d74:	9100a021 	add	x1, x1, #0x28
    1d78:	eb02029f 	cmp	x20, x2
    1d7c:	54000100 	b.eq	1d9c <fwp_heap_chunks+0x8c>  // b.none
    1d80:	39400023 	ldrb	w3, [x1]
    1d84:	34fffee3 	cbz	w3, 1d60 <fwp_heap_chunks+0x50>
    1d88:	91000442 	add	x2, x2, #0x1
    1d8c:	9100a021 	add	x1, x1, #0x28
    1d90:	d2800004 	mov	x4, #0x0                   	// #0
    1d94:	eb02029f 	cmp	x20, x2
    1d98:	54ffff41 	b.ne	1d80 <fwp_heap_chunks+0x70>  // b.any
    1d9c:	cb040294 	sub	x20, x20, x4
    1da0:	f9001bf7 	str	x23, [sp, #48]
    1da4:	911582b7 	add	x23, x21, #0x560
    1da8:	8b140013 	add	x19, x0, x20
    1dac:	f94a1ae1 	ldr	x1, [x23, #5168]
    1db0:	f949f2e0 	ldr	x0, [x23, #5088]
    1db4:	cb040021 	sub	x1, x1, x4
    1db8:	f90a1ae1 	str	x1, [x23, #5168]
    1dbc:	eb00027f 	cmp	x19, x0
    1dc0:	54000429 	b.ls	1e44 <fwp_heap_chunks+0x134>  // b.plast
    1dc4:	f949eae1 	ldr	x1, [x23, #5072]
    1dc8:	eb01027f 	cmp	x19, x1
    1dcc:	54000888 	b.hi	1edc <fwp_heap_chunks+0x1cc>  // b.pmore
    1dd0:	91010276 	add	x22, x19, #0x40
    1dd4:	52800062 	mov	w2, #0x3                   	// #3
    1dd8:	f949dae3 	ldr	x3, [x23, #5040]
    1ddc:	eb0102df 	cmp	x22, x1
    1de0:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1de4:	cb0002c1 	sub	x1, x22, x0
    1de8:	8b004060 	add	x0, x3, x0, lsl #16
    1dec:	d370bc21 	lsl	x1, x1, #16
    1df0:	97fffe2c 	bl	16a0 <mprotect@plt>
    1df4:	35000740 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1df8:	528003c0 	mov	w0, #0x1e                  	// #30
    1dfc:	97fffe15 	bl	1650 <sysconf@plt>
    1e00:	f949f2e2 	ldr	x2, [x23, #5088]
    1e04:	cb0003e5 	neg	x5, x0
    1e08:	aa0003e4 	mov	x4, x0
    1e0c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e10:	f949fee0 	ldr	x0, [x23, #5112]
    1e14:	8b020843 	add	x3, x2, x2, lsl #2
    1e18:	52800062 	mov	w2, #0x3                   	// #3
    1e1c:	8b010c01 	add	x1, x0, x1, lsl #3
    1e20:	8b030c03 	add	x3, x0, x3, lsl #3
    1e24:	d1000421 	sub	x1, x1, #0x1
    1e28:	8a050060 	and	x0, x3, x5
    1e2c:	8b040021 	add	x1, x1, x4
    1e30:	8a050021 	and	x1, x1, x5
    1e34:	cb000021 	sub	x1, x1, x0
    1e38:	97fffe1a 	bl	16a0 <mprotect@plt>
    1e3c:	35000500 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1e40:	f909f2f6 	str	x22, [x23, #5088]
    1e44:	911582b5 	add	x21, x21, #0x560
    1e48:	d370be60 	lsl	x0, x19, #16
    1e4c:	f949e6a1 	ldr	x1, [x21, #5064]
    1e50:	f909eeb3 	str	x19, [x21, #5080]
    1e54:	eb01001f 	cmp	x0, x1
    1e58:	540000e8 	b.hi	1e74 <fwp_heap_chunks+0x164>  // b.pmore
    1e5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e60:	aa1403e0 	mov	x0, x20
    1e64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e68:	f9401bf7 	ldr	x23, [sp, #48]
    1e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e70:	d65f03c0 	ret
    1e74:	f9401bf7 	ldr	x23, [sp, #48]
    1e78:	f909e6a0 	str	x0, [x21, #5064]
    1e7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e80:	aa1403e0 	mov	x0, x20
    1e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e88:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e8c:	d65f03c0 	ret
    1e90:	911582b5 	add	x21, x21, #0x560
    1e94:	91000441 	add	x1, x2, #0x1
    1e98:	f90000a1 	str	x1, [x5]
    1e9c:	cb040054 	sub	x20, x2, x4
    1ea0:	f94a1aa1 	ldr	x1, [x21, #5168]
    1ea4:	cb000020 	sub	x0, x1, x0
    1ea8:	f90a1aa0 	str	x0, [x21, #5168]
    1eac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1eb0:	aa1403e0 	mov	x0, x20
    1eb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1eb8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ebc:	d65f03c0 	ret
    1ec0:	f949f422 	ldr	x2, [x1, #5096]
    1ec4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaa0>
    1ec8:	912520a5 	add	x5, x5, #0x948
    1ecc:	17ffff9c 	b	1d3c <fwp_heap_chunks+0x2c>
    1ed0:	d2800004 	mov	x4, #0x0                   	// #0
    1ed4:	f9001bf7 	str	x23, [sp, #48]
    1ed8:	17ffffb3 	b	1da4 <fwp_heap_chunks+0x94>
    1edc:	97ffff7d 	bl	1cd0 <fwp_heap_oom>

0000000000001ee0 <ad_raw_fail>:
    1ee0:	d00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x14da0>
    1ee4:	f947e884 	ldr	x4, [x4, #4048]
    1ee8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1eec:	aa0003e3 	mov	x3, x0
    1ef0:	910003fd 	mov	x29, sp
    1ef4:	f9400080 	ldr	x0, [x4]
    1ef8:	f0000022 	adrp	x2, 8000 <f0+0x2340>
    1efc:	9138c042 	add	x2, x2, #0xe30
    1f00:	52800041 	mov	w1, #0x2                   	// #2
    1f04:	97fffd9b 	bl	1570 <__fprintf_chk@plt>
    1f08:	52801d00 	mov	w0, #0xe8                  	// #232
    1f0c:	97fffd29 	bl	13b0 <exit@plt>

0000000000001f10 <ad_raw_report>:
    1f10:	d101c3ff 	sub	sp, sp, #0x70
    1f14:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f18:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14da0>
    1f1c:	f947f463 	ldr	x3, [x3, #4072]
    1f20:	f0000022 	adrp	x2, 8000 <f0+0x2340>
    1f24:	a9037bfd 	stp	x29, x30, [sp, #48]
    1f28:	9100c3fd 	add	x29, sp, #0x30
    1f2c:	91398042 	add	x2, x2, #0xe60
    1f30:	d2800005 	mov	x5, #0x0                   	// #0
    1f34:	a9055bf5 	stp	x21, x22, [sp, #80]
    1f38:	f0000036 	adrp	x22, 8000 <f0+0x2340>
    1f3c:	913b02d6 	add	x22, x22, #0xec0
    1f40:	d00000f5 	adrp	x21, 1f000 <__FRAME_END__+0x14da0>
    1f44:	f947eab5 	ldr	x21, [x21, #4048]
    1f48:	a90453f3 	stp	x19, x20, [sp, #64]
    1f4c:	52800013 	mov	w19, #0x0                   	// #0
    1f50:	f94002a0 	ldr	x0, [x21]
    1f54:	f90033f7 	str	x23, [sp, #96]
    1f58:	f0000037 	adrp	x23, 8000 <f0+0x2340>
    1f5c:	913962f7 	add	x23, x23, #0xe58
    1f60:	f9400064 	ldr	x4, [x3]
    1f64:	f90017e4 	str	x4, [sp, #40]
    1f68:	d2800004 	mov	x4, #0x0                   	// #0
    1f6c:	d2800003 	mov	x3, #0x0                   	// #0
    1f70:	f9405024 	ldr	x4, [x1, #160]
    1f74:	52800041 	mov	w1, #0x2                   	// #2
    1f78:	97fffd7e 	bl	1570 <__fprintf_chk@plt>
    1f7c:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f80:	91004021 	add	x1, x1, #0x10
    1f84:	f94002a0 	ldr	x0, [x21]
    1f88:	910023e2 	add	x2, sp, #0x8
    1f8c:	4c40a020 	ld1	{v0.16b-v1.16b}, [x1]
    1f90:	f0000023 	adrp	x3, 8000 <f0+0x2340>
    1f94:	aa0203f4 	mov	x20, x2
    1f98:	91394063 	add	x3, x3, #0xe50
    1f9c:	4c00a040 	st1	{v0.16b-v1.16b}, [x2]
    1fa0:	aa1603e2 	mov	x2, x22
    1fa4:	f8408684 	ldr	x4, [x20], #8
    1fa8:	d2800007 	mov	x7, #0x0                   	// #0
    1fac:	d2800006 	mov	x6, #0x0                   	// #0
    1fb0:	d2800005 	mov	x5, #0x0                   	// #0
    1fb4:	52800041 	mov	w1, #0x2                   	// #2
    1fb8:	11000673 	add	w19, w19, #0x1
    1fbc:	97fffd6d 	bl	1570 <__fprintf_chk@plt>
    1fc0:	7100127f 	cmp	w19, #0x4
    1fc4:	54000080 	b.eq	1fd4 <ad_raw_report+0xc4>  // b.none
    1fc8:	f94002a0 	ldr	x0, [x21]
    1fcc:	aa1703e3 	mov	x3, x23
    1fd0:	17fffff4 	b	1fa0 <ad_raw_report+0x90>
    1fd4:	f94002a3 	ldr	x3, [x21]
    1fd8:	d2800262 	mov	x2, #0x13                  	// #19
    1fdc:	d2800021 	mov	x1, #0x1                   	// #1
    1fe0:	f0000020 	adrp	x0, 8000 <f0+0x2340>
    1fe4:	913c0000 	add	x0, x0, #0xf00
    1fe8:	97fffd86 	bl	1600 <fwrite@plt>
    1fec:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    1ff0:	f947f400 	ldr	x0, [x0, #4072]
    1ff4:	f94017e2 	ldr	x2, [sp, #40]
    1ff8:	f9400001 	ldr	x1, [x0]
    1ffc:	eb010042 	subs	x2, x2, x1
    2000:	d2800001 	mov	x1, #0x0                   	// #0
    2004:	54000181 	b.ne	2034 <ad_raw_report+0x124>  // b.any
    2008:	f94002a3 	ldr	x3, [x21]
    200c:	d0000020 	adrp	x0, 8000 <f0+0x2340>
    2010:	a9437bfd 	ldp	x29, x30, [sp, #48]
    2014:	913c6000 	add	x0, x0, #0xf18
    2018:	a94453f3 	ldp	x19, x20, [sp, #64]
    201c:	d2800082 	mov	x2, #0x4                   	// #4
    2020:	a9455bf5 	ldp	x21, x22, [sp, #80]
    2024:	d2800021 	mov	x1, #0x1                   	// #1
    2028:	f94033f7 	ldr	x23, [sp, #96]
    202c:	9101c3ff 	add	sp, sp, #0x70
    2030:	17fffd74 	b	1600 <fwrite@plt>
    2034:	97fffd33 	bl	1500 <__stack_chk_fail@plt>
    2038:	d503201f 	nop
    203c:	d503201f 	nop

0000000000002040 <buf_grow>:
    2040:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2044:	910003fd 	mov	x29, sp
    2048:	a90153f3 	stp	x19, x20, [sp, #16]
    204c:	aa0003f4 	mov	x20, x0
    2050:	f9400400 	ldr	x0, [x0, #8]
    2054:	b100041f 	cmn	x0, #0x1
    2058:	54000400 	b.eq	20d8 <buf_grow+0x98>  // b.none
    205c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    2060:	cb000042 	sub	x2, x2, x0
    2064:	eb01005f 	cmp	x2, x1
    2068:	54000383 	b.cc	20d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    206c:	f9400a82 	ldr	x2, [x20, #16]
    2070:	91000421 	add	x1, x1, #0x1
    2074:	8b000033 	add	x19, x1, x0
    2078:	eb13005f 	cmp	x2, x19
    207c:	54000242 	b.cs	20c4 <buf_grow+0x84>  // b.hs, b.nlast
    2080:	f100005f 	cmp	x2, #0x0
    2084:	b5000262 	cbnz	x2, 20d0 <buf_grow+0x90>
    2088:	d2800802 	mov	x2, #0x40                  	// #64
    208c:	eb02027f 	cmp	x19, x2
    2090:	54000068 	b.hi	209c <buf_grow+0x5c>  // b.pmore
    2094:	14000005 	b	20a8 <buf_grow+0x68>
    2098:	b7f800a2 	tbnz	x2, #63, 20ac <buf_grow+0x6c>
    209c:	d37ff842 	lsl	x2, x2, #1
    20a0:	eb02027f 	cmp	x19, x2
    20a4:	54ffffa8 	b.hi	2098 <buf_grow+0x58>  // b.pmore
    20a8:	aa0203f3 	mov	x19, x2
    20ac:	f9400280 	ldr	x0, [x20]
    20b0:	aa1303e1 	mov	x1, x19
    20b4:	97fffd0f 	bl	14f0 <realloc@plt>
    20b8:	b4000100 	cbz	x0, 20d8 <buf_grow+0x98>
    20bc:	f9000280 	str	x0, [x20]
    20c0:	f9000a93 	str	x19, [x20, #16]
    20c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    20c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    20cc:	d65f03c0 	ret
    20d0:	54fffe6a 	b.ge	209c <buf_grow+0x5c>  // b.tcont
    20d4:	17fffff6 	b	20ac <buf_grow+0x6c>
    20d8:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14da0>
    20dc:	f947e863 	ldr	x3, [x3, #4048]
    20e0:	d2800262 	mov	x2, #0x13                  	// #19
    20e4:	d2800021 	mov	x1, #0x1                   	// #1
    20e8:	d0000020 	adrp	x0, 8000 <f0+0x2340>
    20ec:	91386000 	add	x0, x0, #0xe18
    20f0:	f9400063 	ldr	x3, [x3]
    20f4:	97fffd43 	bl	1600 <fwrite@plt>
    20f8:	d2800000 	mov	x0, #0x0                   	// #0
    20fc:	97fffd4d 	bl	1630 <fflush@plt>
    2100:	52800cc0 	mov	w0, #0x66                  	// #102
    2104:	97fffd5b 	bl	1670 <_Exit@plt>
    2108:	d503201f 	nop
    210c:	d503201f 	nop

0000000000002110 <buf_put>:
    2110:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2114:	910003fd 	mov	x29, sp
    2118:	a90153f3 	stp	x19, x20, [sp, #16]
    211c:	aa0003f4 	mov	x20, x0
    2120:	aa0203f3 	mov	x19, x2
    2124:	f90013f5 	str	x21, [sp, #32]
    2128:	aa0103f5 	mov	x21, x1
    212c:	aa0203e1 	mov	x1, x2
    2130:	97ffffc4 	bl	2040 <buf_grow>
    2134:	a9400283 	ldp	x3, x0, [x20]
    2138:	aa1503e1 	mov	x1, x21
    213c:	aa1303e2 	mov	x2, x19
    2140:	8b000060 	add	x0, x3, x0
    2144:	97fffc87 	bl	1360 <memcpy@plt>
    2148:	a9400680 	ldp	x0, x1, [x20]
    214c:	8b010273 	add	x19, x19, x1
    2150:	f9000693 	str	x19, [x20, #8]
    2154:	3833681f 	strb	wzr, [x0, x19]
    2158:	a94153f3 	ldp	x19, x20, [sp, #16]
    215c:	f94013f5 	ldr	x21, [sp, #32]
    2160:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2164:	d65f03c0 	ret
    2168:	d503201f 	nop
    216c:	d503201f 	nop

0000000000002170 <fwp_cancel_tree.part.0>:
    2170:	d00000e1 	adrp	x1, 20000 <__data_start>
    2174:	91020022 	add	x2, x1, #0x80
    2178:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    217c:	52800023 	mov	w3, #0x1                   	// #1
    2180:	910003fd 	mov	x29, sp
    2184:	f9400444 	ldr	x4, [x2, #8]
    2188:	f9000bf3 	str	x19, [sp, #16]
    218c:	39014403 	strb	w3, [x0, #81]
    2190:	eb04001f 	cmp	x0, x4
    2194:	54000160 	b.eq	21c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    2198:	f9402804 	ldr	x4, [x0, #80]
    219c:	f2001c9f 	tst	x4, #0xff000000ff
    21a0:	54000101 	b.ne	21c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    21a4:	f9401444 	ldr	x4, [x2, #40]
    21a8:	39015003 	strb	w3, [x0, #84]
    21ac:	f900801f 	str	xzr, [x0, #256]
    21b0:	b40001e4 	cbz	x4, 21ec <fwp_cancel_tree.part.0+0x7c>
    21b4:	f9008080 	str	x0, [x4, #256]
    21b8:	91020021 	add	x1, x1, #0x80
    21bc:	f9001420 	str	x0, [x1, #40]
    21c0:	f9401413 	ldr	x19, [x0, #40]
    21c4:	b40000f3 	cbz	x19, 21e0 <fwp_cancel_tree.part.0+0x70>
    21c8:	39414261 	ldrb	w1, [x19, #80]
    21cc:	aa1303e0 	mov	x0, x19
    21d0:	37000041 	tbnz	w1, #0, 21d8 <fwp_cancel_tree.part.0+0x68>
    21d4:	97ffffe7 	bl	2170 <fwp_cancel_tree.part.0>
    21d8:	f9401a73 	ldr	x19, [x19, #48]
    21dc:	b5ffff73 	cbnz	x19, 21c8 <fwp_cancel_tree.part.0+0x58>
    21e0:	f9400bf3 	ldr	x19, [sp, #16]
    21e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    21e8:	d65f03c0 	ret
    21ec:	f9001840 	str	x0, [x2, #48]
    21f0:	17fffff2 	b	21b8 <fwp_cancel_tree.part.0+0x48>

00000000000021f4 <fwp_finish_float>:
    21f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    21f8:	528005c1 	mov	w1, #0x2e                  	// #46
    21fc:	910003fd 	mov	x29, sp
    2200:	f9000bf3 	str	x19, [sp, #16]
    2204:	aa0003f3 	mov	x19, x0
    2208:	97fffcf6 	bl	15e0 <strchr@plt>
    220c:	b4000080 	cbz	x0, 221c <fwp_finish_float+0x28>
    2210:	f9400bf3 	ldr	x19, [sp, #16]
    2214:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2218:	d65f03c0 	ret
    221c:	aa1303e0 	mov	x0, x19
    2220:	52800ca1 	mov	w1, #0x65                  	// #101
    2224:	97fffcef 	bl	15e0 <strchr@plt>
    2228:	b5ffff40 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    222c:	d0000021 	adrp	x1, 8000 <f0+0x2340>
    2230:	aa1303e0 	mov	x0, x19
    2234:	913c8021 	add	x1, x1, #0xf20
    2238:	97fffd0a 	bl	1660 <strstr@plt>
    223c:	b5fffea0 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2240:	d0000021 	adrp	x1, 8000 <f0+0x2340>
    2244:	aa1303e0 	mov	x0, x19
    2248:	913ca021 	add	x1, x1, #0xf28
    224c:	97fffd05 	bl	1660 <strstr@plt>
    2250:	b5fffe00 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2254:	aa1303e0 	mov	x0, x19
    2258:	97fffc4e 	bl	1390 <strlen@plt>
    225c:	d0000021 	adrp	x1, 8000 <f0+0x2340>
    2260:	913cc021 	add	x1, x1, #0xf30
    2264:	8b000262 	add	x2, x19, x0
    2268:	79400023 	ldrh	w3, [x1]
    226c:	39400821 	ldrb	w1, [x1, #2]
    2270:	78206a63 	strh	w3, [x19, x0]
    2274:	39000841 	strb	w1, [x2, #2]
    2278:	17ffffe6 	b	2210 <fwp_finish_float+0x1c>
    227c:	d503201f 	nop

0000000000002280 <fwp_trap>:
    2280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2284:	910003fd 	mov	x29, sp
    2288:	f9000bf3 	str	x19, [sp, #16]
    228c:	aa0003f3 	mov	x19, x0
    2290:	97fffe50 	bl	1bd0 <fwp_flush>
    2294:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x14da0>
    2298:	f947e884 	ldr	x4, [x4, #4048]
    229c:	aa1303e3 	mov	x3, x19
    22a0:	d0000022 	adrp	x2, 8000 <f0+0x2340>
    22a4:	913ce042 	add	x2, x2, #0xf38
    22a8:	52800041 	mov	w1, #0x2                   	// #2
    22ac:	f9400080 	ldr	x0, [x4]
    22b0:	97fffcb0 	bl	1570 <__fprintf_chk@plt>
    22b4:	52800ca0 	mov	w0, #0x65                  	// #101
    22b8:	97fffc3e 	bl	13b0 <exit@plt>
    22bc:	d503201f 	nop

00000000000022c0 <fwp_now_ns>:
    22c0:	d100c3ff 	sub	sp, sp, #0x30
    22c4:	52800020 	mov	w0, #0x1                   	// #1
    22c8:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14da0>
    22cc:	f947f442 	ldr	x2, [x2, #4072]
    22d0:	910023e1 	add	x1, sp, #0x8
    22d4:	a9027bfd 	stp	x29, x30, [sp, #32]
    22d8:	910083fd 	add	x29, sp, #0x20
    22dc:	f9400043 	ldr	x3, [x2]
    22e0:	f9000fe3 	str	x3, [sp, #24]
    22e4:	d2800003 	mov	x3, #0x0                   	// #0
    22e8:	97fffc52 	bl	1430 <clock_gettime@plt>
    22ec:	350002c0 	cbnz	w0, 2344 <fwp_now_ns+0x84>
    22f0:	a9408be1 	ldp	x1, x2, [sp, #8]
    22f4:	d2994003 	mov	x3, #0xca00                	// #51712
    22f8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    22fc:	9b037c20 	mul	x0, x1, x3
    2300:	9b437c21 	smulh	x1, x1, x3
    2304:	ab020000 	adds	x0, x0, x2
    2308:	937ffc42 	asr	x2, x2, #63
    230c:	9a020021 	adc	x1, x1, x2
    2310:	f100001f 	cmp	x0, #0x0
    2314:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2318:	b50001e1 	cbnz	x1, 2354 <fwp_now_ns+0x94>
    231c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    2320:	f947f421 	ldr	x1, [x1, #4072]
    2324:	f9400fe3 	ldr	x3, [sp, #24]
    2328:	f9400022 	ldr	x2, [x1]
    232c:	eb020063 	subs	x3, x3, x2
    2330:	d2800002 	mov	x2, #0x0                   	// #0
    2334:	540000e1 	b.ne	2350 <fwp_now_ns+0x90>  // b.any
    2338:	a9427bfd 	ldp	x29, x30, [sp, #32]
    233c:	9100c3ff 	add	sp, sp, #0x30
    2340:	d65f03c0 	ret
    2344:	d0000020 	adrp	x0, 8000 <f0+0x2340>
    2348:	913d2000 	add	x0, x0, #0xf48
    234c:	97ffffcd 	bl	2280 <fwp_trap>
    2350:	97fffc6c 	bl	1500 <__stack_chk_fail@plt>
    2354:	d0000020 	adrp	x0, 8000 <f0+0x2340>
    2358:	913da000 	add	x0, x0, #0xf68
    235c:	97ffffc9 	bl	2280 <fwp_trap>

0000000000002360 <fwp_format_g.constprop.0>:
    2360:	d10483ff 	sub	sp, sp, #0x120
    2364:	d0000024 	adrp	x4, 8000 <f0+0x2340>
    2368:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x14da0>
    236c:	f947f442 	ldr	x2, [x2, #4072]
    2370:	913e4084 	add	x4, x4, #0xf90
    2374:	a90b7bfd 	stp	x29, x30, [sp, #176]
    2378:	9102c3fd 	add	x29, sp, #0xb0
    237c:	d2800803 	mov	x3, #0x40                  	// #64
    2380:	a90e63f7 	stp	x23, x24, [sp, #224]
    2384:	93407c38 	sxtw	x24, w1
    2388:	aa0303e1 	mov	x1, x3
    238c:	fd008be8 	str	d8, [sp, #272]
    2390:	1e604008 	fmov	d8, d0
    2394:	a90c53f3 	stp	x19, x20, [sp, #192]
    2398:	910083f4 	add	x20, sp, #0x20
    239c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    23a0:	aa0003f5 	mov	x21, x0
    23a4:	a91073fb 	stp	x27, x28, [sp, #256]
    23a8:	5100071c 	sub	w28, w24, #0x1
    23ac:	2a1c03e5 	mov	w5, w28
    23b0:	f9400040 	ldr	x0, [x2]
    23b4:	f90057e0 	str	x0, [sp, #168]
    23b8:	d2800000 	mov	x0, #0x0                   	// #0
    23bc:	52800042 	mov	w2, #0x2                   	// #2
    23c0:	aa1403e0 	mov	x0, x20
    23c4:	97fffc2b 	bl	1470 <__snprintf_chk@plt>
    23c8:	52800ca1 	mov	w1, #0x65                  	// #101
    23cc:	aa1403e0 	mov	x0, x20
    23d0:	97fffc84 	bl	15e0 <strchr@plt>
    23d4:	aa0003f3 	mov	x19, x0
    23d8:	52800142 	mov	w2, #0xa                   	// #10
    23dc:	91000400 	add	x0, x0, #0x1
    23e0:	d2800001 	mov	x1, #0x0                   	// #0
    23e4:	97fffc6f 	bl	15a0 <strtol@plt>
    23e8:	aa0003f7 	mov	x23, x0
    23ec:	11001400 	add	w0, w0, #0x5
    23f0:	7100541f 	cmp	w0, #0x15
    23f4:	54000d68 	b.hi	25a0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    23f8:	4b170385 	sub	w5, w28, w23
    23fc:	710000bf 	cmp	w5, #0x0
    2400:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2404:	54000b80 	b.eq	2574 <fwp_format_g.constprop.0+0x214>  // b.none
    2408:	394083e0 	ldrb	w0, [sp, #32]
    240c:	cb180273 	sub	x19, x19, x24
    2410:	91000673 	add	x19, x19, #0x1
    2414:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2418:	7100b41f 	cmp	w0, #0x2d
    241c:	9a941681 	cinc	x1, x20, eq	// eq = none
    2420:	1a9f17e4 	cset	w4, eq	// eq = none
    2424:	cb010266 	sub	x6, x19, x1
    2428:	d10004da 	sub	x26, x6, #0x1
    242c:	540018a0 	b.eq	2740 <fwp_format_g.constprop.0+0x3e0>  // b.none
    2430:	910183f9 	add	x25, sp, #0x60
    2434:	d280091b 	mov	x27, #0x48                  	// #72
    2438:	aa1903e7 	mov	x7, x25
    243c:	91000423 	add	x3, x1, #0x1
    2440:	91011cc6 	add	x6, x6, #0x47
    2444:	910004f6 	add	x22, x7, #0x1
    2448:	37f80ff7 	tbnz	w23, #31, 2644 <fwp_format_g.constprop.0+0x2e4>
    244c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    2450:	93407ef7 	sxtw	x23, w23
    2454:	390000e4 	strb	w4, [x7]
    2458:	aa1303e1 	mov	x1, x19
    245c:	aa1703e2 	mov	x2, x23
    2460:	aa1603e0 	mov	x0, x22
    2464:	b9000be5 	str	w5, [sp, #8]
    2468:	cb170374 	sub	x20, x27, x23
    246c:	a9011be3 	stp	x3, x6, [sp, #16]
    2470:	97fffbbc 	bl	1360 <memcpy@plt>
    2474:	d1000694 	sub	x20, x20, #0x1
    2478:	f9400be3 	ldr	x3, [sp, #16]
    247c:	8b1702d6 	add	x22, x22, x23
    2480:	aa1603e0 	mov	x0, x22
    2484:	aa1a03e2 	mov	x2, x26
    2488:	aa0303e1 	mov	x1, x3
    248c:	aa1403e3 	mov	x3, x20
    2490:	97fffbf0 	bl	1450 <__memcpy_chk@plt>
    2494:	8b1a02d6 	add	x22, x22, x26
    2498:	f9400fe6 	ldr	x6, [sp, #24]
    249c:	d2800900 	mov	x0, #0x48                  	// #72
    24a0:	b9400be5 	ldr	w5, [sp, #8]
    24a4:	8b170261 	add	x1, x19, x23
    24a8:	cb1400c3 	sub	x3, x6, x20
    24ac:	cb060294 	sub	x20, x20, x6
    24b0:	f101207f 	cmp	x3, #0x48
    24b4:	93407cb8 	sxtw	x24, w5
    24b8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    24bc:	aa1803e2 	mov	x2, x24
    24c0:	8b1802d3 	add	x19, x22, x24
    24c4:	8b140063 	add	x3, x3, x20
    24c8:	aa1603e0 	mov	x0, x22
    24cc:	97fffbe1 	bl	1450 <__memcpy_chk@plt>
    24d0:	cb190273 	sub	x19, x19, x25
    24d4:	d28031e0 	mov	x0, #0x18f                 	// #399
    24d8:	eb00027f 	cmp	x19, x0
    24dc:	aa1903e1 	mov	x1, x25
    24e0:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    24e4:	aa1503e0 	mov	x0, x21
    24e8:	aa1303e2 	mov	x2, x19
    24ec:	97fffb9d 	bl	1360 <memcpy@plt>
    24f0:	38336abf 	strb	wzr, [x21, x19]
    24f4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    24f8:	aa1503e0 	mov	x0, x21
    24fc:	97fffba5 	bl	1390 <strlen@plt>
    2500:	aa0003f3 	mov	x19, x0
    2504:	528005c1 	mov	w1, #0x2e                  	// #46
    2508:	aa1503e0 	mov	x0, x21
    250c:	97fffc35 	bl	15e0 <strchr@plt>
    2510:	b4000140 	cbz	x0, 2538 <fwp_format_g.constprop.0+0x1d8>
    2514:	b4000133 	cbz	x19, 2538 <fwp_format_g.constprop.0+0x1d8>
    2518:	aa1303e1 	mov	x1, x19
    251c:	d1000673 	sub	x19, x19, #0x1
    2520:	38736aa0 	ldrb	w0, [x21, x19]
    2524:	7100c01f 	cmp	w0, #0x30
    2528:	54001001 	b.ne	2728 <fwp_format_g.constprop.0+0x3c8>  // b.any
    252c:	38336abf 	strb	wzr, [x21, x19]
    2530:	b5ffff53 	cbnz	x19, 2518 <fwp_format_g.constprop.0+0x1b8>
    2534:	d503201f 	nop
    2538:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    253c:	f947f400 	ldr	x0, [x0, #4072]
    2540:	f94057e2 	ldr	x2, [sp, #168]
    2544:	f9400001 	ldr	x1, [x0]
    2548:	eb010042 	subs	x2, x2, x1
    254c:	d2800001 	mov	x1, #0x0                   	// #0
    2550:	54001061 	b.ne	275c <fwp_format_g.constprop.0+0x3fc>  // b.any
    2554:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2558:	a94c53f3 	ldp	x19, x20, [sp, #192]
    255c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2560:	a94e63f7 	ldp	x23, x24, [sp, #224]
    2564:	a95073fb 	ldp	x27, x28, [sp, #256]
    2568:	fd408be8 	ldr	d8, [sp, #272]
    256c:	910483ff 	add	sp, sp, #0x120
    2570:	d65f03c0 	ret
    2574:	1e604100 	fmov	d0, d8
    2578:	710000bf 	cmp	w5, #0x0
    257c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2580:	aa1503e0 	mov	x0, x21
    2584:	d0000024 	adrp	x4, 8000 <f0+0x2340>
    2588:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    258c:	913ea084 	add	x4, x4, #0xfa8
    2590:	52800042 	mov	w2, #0x2                   	// #2
    2594:	d2803201 	mov	x1, #0x190                 	// #400
    2598:	97fffbb6 	bl	1470 <__snprintf_chk@plt>
    259c:	17ffffd7 	b	24f8 <fwp_format_g.constprop.0+0x198>
    25a0:	cb140273 	sub	x19, x19, x20
    25a4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    25a8:	910183f9 	add	x25, sp, #0x60
    25ac:	aa1303e2 	mov	x2, x19
    25b0:	aa1403e1 	mov	x1, x20
    25b4:	aa1903e0 	mov	x0, x25
    25b8:	d2800803 	mov	x3, #0x40                  	// #64
    25bc:	97fffba5 	bl	1450 <__memcpy_chk@plt>
    25c0:	38336b3f 	strb	wzr, [x25, x19]
    25c4:	aa1903e0 	mov	x0, x25
    25c8:	528005c1 	mov	w1, #0x2e                  	// #46
    25cc:	97fffc05 	bl	15e0 <strchr@plt>
    25d0:	b40001c0 	cbz	x0, 2608 <fwp_format_g.constprop.0+0x2a8>
    25d4:	b50000b3 	cbnz	x19, 25e8 <fwp_format_g.constprop.0+0x288>
    25d8:	1400000c 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    25dc:	381ff01f 	sturb	wzr, [x0, #-1]
    25e0:	f1000673 	subs	x19, x19, #0x1
    25e4:	54000120 	b.eq	2608 <fwp_format_g.constprop.0+0x2a8>  // b.none
    25e8:	8b130320 	add	x0, x25, x19
    25ec:	385ff001 	ldurb	w1, [x0, #-1]
    25f0:	7100c03f 	cmp	w1, #0x30
    25f4:	54ffff40 	b.eq	25dc <fwp_format_g.constprop.0+0x27c>  // b.none
    25f8:	d1000673 	sub	x19, x19, #0x1
    25fc:	38736b20 	ldrb	w0, [x25, x19]
    2600:	7100b81f 	cmp	w0, #0x2e
    2604:	54000a80 	b.eq	2754 <fwp_format_g.constprop.0+0x3f4>  // b.none
    2608:	710002ff 	cmp	w23, #0x0
    260c:	528005a1 	mov	w1, #0x2d                  	// #45
    2610:	aa1903e5 	mov	x5, x25
    2614:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    2618:	aa1503e0 	mov	x0, x21
    261c:	52800566 	mov	w6, #0x2b                  	// #43
    2620:	d0000024 	adrp	x4, 8000 <f0+0x2340>
    2624:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    2628:	913e6084 	add	x4, x4, #0xf98
    262c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2630:	52800042 	mov	w2, #0x2                   	// #2
    2634:	d2803201 	mov	x1, #0x190                 	// #400
    2638:	97fffb8e 	bl	1470 <__snprintf_chk@plt>
    263c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2640:	17ffffbe 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2644:	52800605 	mov	w5, #0x30                  	// #48
    2648:	390000e5 	strb	w5, [x7]
    264c:	d100077b 	sub	x27, x27, #0x1
    2650:	aa0303e1 	mov	x1, x3
    2654:	aa1603e0 	mov	x0, x22
    2658:	aa1b03e3 	mov	x3, x27
    265c:	aa1a03e2 	mov	x2, x26
    2660:	f90007e6 	str	x6, [sp, #8]
    2664:	b90013e4 	str	w4, [sp, #16]
    2668:	8b1a02d6 	add	x22, x22, x26
    266c:	b9001be5 	str	w5, [sp, #24]
    2670:	97fffb78 	bl	1450 <__memcpy_chk@plt>
    2674:	f94007e6 	ldr	x6, [sp, #8]
    2678:	2a3703e7 	mvn	w7, w23
    267c:	b94013e4 	ldr	w4, [sp, #16]
    2680:	cb1b00c1 	sub	x1, x6, x27
    2684:	cb06037b 	sub	x27, x27, x6
    2688:	f101203f 	cmp	x1, #0x48
    268c:	d2800906 	mov	x6, #0x48                  	// #72
    2690:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    2694:	8b1b0023 	add	x3, x1, x27
    2698:	310006ff 	cmn	w23, #0x1
    269c:	54000220 	b.eq	26e0 <fwp_format_g.constprop.0+0x380>  // b.none
    26a0:	b9401be5 	ldr	w5, [sp, #24]
    26a4:	d2800001 	mov	x1, #0x0                   	// #0
    26a8:	f101207f 	cmp	x3, #0x48
    26ac:	d1000462 	sub	x2, x3, #0x1
    26b0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    26b4:	38216ac5 	strb	w5, [x22, x1]
    26b8:	cb030003 	sub	x3, x0, x3
    26bc:	91000421 	add	x1, x1, #0x1
    26c0:	91000463 	add	x3, x3, #0x1
    26c4:	eb00007f 	cmp	x3, x0
    26c8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    26cc:	cb000063 	sub	x3, x3, x0
    26d0:	8b020063 	add	x3, x3, x2
    26d4:	6b0100ff 	cmp	w7, w1
    26d8:	54fffe8c 	b.gt	26a8 <fwp_format_g.constprop.0+0x348>
    26dc:	8b2742d6 	add	x22, x22, w7, uxtw
    26e0:	f101207f 	cmp	x3, #0x48
    26e4:	d2800905 	mov	x5, #0x48                  	// #72
    26e8:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    26ec:	aa1603e0 	mov	x0, x22
    26f0:	cb0300a1 	sub	x1, x5, x3
    26f4:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    26f8:	91000421 	add	x1, x1, #0x1
    26fc:	d1000463 	sub	x3, x3, #0x1
    2700:	eb05003f 	cmp	x1, x5
    2704:	38001402 	strb	w2, [x0], #1
    2708:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    270c:	93407f82 	sxtw	x2, w28
    2710:	cb050025 	sub	x5, x1, x5
    2714:	aa1303e1 	mov	x1, x19
    2718:	8b0300a3 	add	x3, x5, x3
    271c:	8b1802d3 	add	x19, x22, x24
    2720:	97fffb4c 	bl	1450 <__memcpy_chk@plt>
    2724:	17ffff6b 	b	24d0 <fwp_format_g.constprop.0+0x170>
    2728:	d1000421 	sub	x1, x1, #0x1
    272c:	38616aa0 	ldrb	w0, [x21, x1]
    2730:	7100b81f 	cmp	w0, #0x2e
    2734:	54fff021 	b.ne	2538 <fwp_format_g.constprop.0+0x1d8>  // b.any
    2738:	38216abf 	strb	wzr, [x21, x1]
    273c:	17ffff7f 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2740:	910187e7 	add	x7, sp, #0x61
    2744:	910183f9 	add	x25, sp, #0x60
    2748:	d28008fb 	mov	x27, #0x47                  	// #71
    274c:	390183e0 	strb	w0, [sp, #96]
    2750:	17ffff3b 	b	243c <fwp_format_g.constprop.0+0xdc>
    2754:	38336b3f 	strb	wzr, [x25, x19]
    2758:	17ffffac 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    275c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2760:	97fffb68 	bl	1500 <__stack_chk_fail@plt>

0000000000002764 <fwp_heap_report>:
    2764:	d105c3ff 	sub	sp, sp, #0x170
    2768:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xc80>
    276c:	91158042 	add	x2, x2, #0x560
    2770:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x14da0>
    2774:	f947e821 	ldr	x1, [x1, #4048]
    2778:	a9117bfd 	stp	x29, x30, [sp, #272]
    277c:	910443fd 	add	x29, sp, #0x110
    2780:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    2784:	f947f400 	ldr	x0, [x0, #4072]
    2788:	a9135bf5 	stp	x21, x22, [sp, #304]
    278c:	a91463f7 	stp	x23, x24, [sp, #320]
    2790:	a9156bf9 	stp	x25, x26, [sp, #336]
    2794:	6d1627e8 	stp	d8, d9, [sp, #352]
    2798:	fd4a1c48 	ldr	d8, [x2, #5176]
    279c:	fd4a2049 	ldr	d9, [x2, #5184]
    27a0:	f9400036 	ldr	x22, [x1]
    27a4:	f9400001 	ldr	x1, [x0]
    27a8:	f90087e1 	str	x1, [sp, #264]
    27ac:	d2800001 	mov	x1, #0x0                   	// #0
    27b0:	f949e459 	ldr	x25, [x2, #5064]
    27b4:	d0000021 	adrp	x1, 8000 <f0+0x2340>
    27b8:	f94a1057 	ldr	x23, [x2, #5152]
    27bc:	d0000020 	adrp	x0, 8000 <f0+0x2340>
    27c0:	f94a1458 	ldr	x24, [x2, #5160]
    27c4:	913ec021 	add	x1, x1, #0xfb0
    27c8:	913ee000 	add	x0, x0, #0xfb8
    27cc:	97fffb31 	bl	1490 <fopen@plt>
    27d0:	b4000760 	cbz	x0, 28bc <fwp_heap_report+0x158>
    27d4:	528daad5 	mov	w21, #0x6d56                	// #27990
    27d8:	a91253f3 	stp	x19, x20, [sp, #288]
    27dc:	aa0003f4 	mov	x20, x0
    27e0:	910023f3 	add	x19, sp, #0x8
    27e4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    27e8:	72aae915 	movk	w21, #0x5748, lsl #16
    27ec:	d503201f 	nop
    27f0:	aa1403e2 	mov	x2, x20
    27f4:	aa1303e0 	mov	x0, x19
    27f8:	52802001 	mov	w1, #0x100                 	// #256
    27fc:	97fffbad 	bl	16b0 <fgets@plt>
    2800:	b4000280 	cbz	x0, 2850 <fwp_heap_report+0xec>
    2804:	b9400261 	ldr	w1, [x19]
    2808:	6b15003f 	cmp	w1, w21
    280c:	54ffff21 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2810:	39401260 	ldrb	w0, [x19, #4]
    2814:	7101341f 	cmp	w0, #0x4d
    2818:	54fffec1 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    281c:	394037e0 	ldrb	w0, [sp, #13]
    2820:	7100e81f 	cmp	w0, #0x3a
    2824:	54fffe61 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2828:	52800142 	mov	w2, #0xa                   	// #10
    282c:	d2800001 	mov	x1, #0x0                   	// #0
    2830:	91003be0 	add	x0, sp, #0xe
    2834:	97fffb5b 	bl	15a0 <strtol@plt>
    2838:	aa1403e2 	mov	x2, x20
    283c:	aa0003fa 	mov	x26, x0
    2840:	52802001 	mov	w1, #0x100                 	// #256
    2844:	aa1303e0 	mov	x0, x19
    2848:	97fffb9a 	bl	16b0 <fgets@plt>
    284c:	b5fffdc0 	cbnz	x0, 2804 <fwp_heap_report+0xa0>
    2850:	aa1403e0 	mov	x0, x20
    2854:	97fffb0b 	bl	1480 <fclose@plt>
    2858:	a95253f3 	ldp	x19, x20, [sp, #288]
    285c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    2860:	f947f400 	ldr	x0, [x0, #4072]
    2864:	f94087e2 	ldr	x2, [sp, #264]
    2868:	f9400001 	ldr	x1, [x0]
    286c:	eb010042 	subs	x2, x2, x1
    2870:	d2800001 	mov	x1, #0x0                   	// #0
    2874:	54000281 	b.ne	28c4 <fwp_heap_report+0x160>  // b.any
    2878:	a9517bfd 	ldp	x29, x30, [sp, #272]
    287c:	aa1a03e6 	mov	x6, x26
    2880:	aa1903e5 	mov	x5, x25
    2884:	aa1803e4 	mov	x4, x24
    2888:	a9556bf9 	ldp	x25, x26, [sp, #336]
    288c:	aa1703e3 	mov	x3, x23
    2890:	a95463f7 	ldp	x23, x24, [sp, #320]
    2894:	aa1603e0 	mov	x0, x22
    2898:	a9535bf5 	ldp	x21, x22, [sp, #304]
    289c:	1e604121 	fmov	d1, d9
    28a0:	1e604100 	fmov	d0, d8
    28a4:	d0000022 	adrp	x2, 8000 <f0+0x2340>
    28a8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    28ac:	913f6042 	add	x2, x2, #0xfd8
    28b0:	9105c3ff 	add	sp, sp, #0x170
    28b4:	52800041 	mov	w1, #0x2                   	// #2
    28b8:	17fffb2e 	b	1570 <__fprintf_chk@plt>
    28bc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    28c0:	17ffffe7 	b	285c <fwp_heap_report+0xf8>
    28c4:	a91253f3 	stp	x19, x20, [sp, #288]
    28c8:	97fffb0e 	bl	1500 <__stack_chk_fail@plt>
    28cc:	d503201f 	nop

00000000000028d0 <fwp_heap_init>:
    28d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    28d4:	90000183 	adrp	x3, 32000 <fwp_heap+0xaa0>
    28d8:	91118061 	add	x1, x3, #0x460
    28dc:	910003fd 	mov	x29, sp
    28e0:	a90153f3 	stp	x19, x20, [sp, #16]
    28e4:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xc80>
    28e8:	91158262 	add	x2, x19, #0x560
    28ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    28f0:	52800024 	mov	w4, #0x1                   	// #1
    28f4:	52800200 	mov	w0, #0x10                  	// #16
    28f8:	b913a444 	str	w4, [x2, #5028]
    28fc:	d503201f 	nop
    2900:	b8004420 	str	w0, [x1], #4
    2904:	11004000 	add	w0, w0, #0x10
    2908:	7104401f 	cmp	w0, #0x110
    290c:	54ffffa1 	b.ne	2900 <fwp_heap_init+0x30>  // b.any
    2910:	f0000022 	adrp	x2, 9000 <_IO_stdin_used+0x1f0>
    2914:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2918:	90000181 	adrp	x1, 32000 <fwp_heap+0xaa0>
    291c:	91128021 	add	x1, x1, #0x4a0
    2920:	3dc13c43 	ldr	q3, [x2, #1264]
    2924:	d2800000 	mov	x0, #0x0                   	// #0
    2928:	4e040401 	dup	v1.4s, v0.s[0]
    292c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    2930:	0f215400 	shl	v0.2s, v0.2s, #1
    2934:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    2938:	3ca06821 	str	q1, [x1, x0]
    293c:	91004000 	add	x0, x0, #0x10
    2940:	f101801f 	cmp	x0, #0x60
    2944:	54ffff21 	b.ne	2928 <fwp_heap_init+0x58>  // b.any
    2948:	90000184 	adrp	x4, 32000 <fwp_heap+0xaa0>
    294c:	91118063 	add	x3, x3, #0x460
    2950:	91140084 	add	x4, x4, #0x500
    2954:	91158266 	add	x6, x19, #0x560
    2958:	d2800002 	mov	x2, #0x0                   	// #0
    295c:	d2800000 	mov	x0, #0x0                   	// #0
    2960:	d2880205 	mov	x5, #0x4010                	// #16400
    2964:	d503201f 	nop
    2968:	910f0001 	add	x1, x0, #0x3c0
    296c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2970:	eb02003f 	cmp	x1, x2
    2974:	540000a2 	b.cs	2988 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    2978:	91000400 	add	x0, x0, #0x1
    297c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2980:	eb02003f 	cmp	x1, x2
    2984:	54ffffa3 	b.cc	2978 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    2988:	91004042 	add	x2, x2, #0x10
    298c:	38001480 	strb	w0, [x4], #1
    2990:	eb05005f 	cmp	x2, x5
    2994:	54fffea1 	b.ne	2968 <fwp_heap_init+0x98>  // b.any
    2998:	528000b5 	mov	w21, #0x5                   	// #5
    299c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    29a0:	14000004 	b	29b0 <fwp_heap_init+0xe0>
    29a4:	d342fe94 	lsr	x20, x20, #2
    29a8:	710006b5 	subs	w21, w21, #0x1
    29ac:	54000720 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    29b0:	91404296 	add	x22, x20, #0x10, lsl #12
    29b4:	d2800005 	mov	x5, #0x0                   	// #0
    29b8:	aa1603e1 	mov	x1, x22
    29bc:	12800004 	mov	w4, #0xffffffff            	// #-1
    29c0:	52880443 	mov	w3, #0x4022                	// #16418
    29c4:	52800002 	mov	w2, #0x0                   	// #0
    29c8:	d2800000 	mov	x0, #0x0                   	// #0
    29cc:	97fffaf1 	bl	1590 <mmap@plt>
    29d0:	aa0003e6 	mov	x6, x0
    29d4:	b100041f 	cmn	x0, #0x1
    29d8:	54fffe60 	b.eq	29a4 <fwp_heap_init+0xd4>  // b.none
    29dc:	b40005a0 	cbz	x0, 2a90 <fwp_heap_init+0x1c0>
    29e0:	d350fe94 	lsr	x20, x20, #16
    29e4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    29e8:	8b0000c7 	add	x7, x6, x0
    29ec:	91158275 	add	x21, x19, #0x560
    29f0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    29f4:	8b140a81 	add	x1, x20, x20, lsl #2
    29f8:	d2800005 	mov	x5, #0x0                   	// #0
    29fc:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a00:	d37df021 	lsl	x1, x1, #3
    2a04:	52880443 	mov	w3, #0x4022                	// #16418
    2a08:	52800002 	mov	w2, #0x0                   	// #0
    2a0c:	d2800000 	mov	x0, #0x0                   	// #0
    2a10:	f909daa7 	str	x7, [x21, #5040]
    2a14:	f909dea6 	str	x6, [x21, #5048]
    2a18:	f909e2b6 	str	x22, [x21, #5056]
    2a1c:	f909eab4 	str	x20, [x21, #5072]
    2a20:	f90a02a1 	str	x1, [x21, #5120]
    2a24:	97fffadb 	bl	1590 <mmap@plt>
    2a28:	aa0003e1 	mov	x1, x0
    2a2c:	b100041f 	cmn	x0, #0x1
    2a30:	54000300 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    2a34:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    2a38:	91022000 	add	x0, x0, #0x88
    2a3c:	f909fea1 	str	x1, [x21, #5112]
    2a40:	97fffb14 	bl	1690 <getenv@plt>
    2a44:	52800002 	mov	w2, #0x0                   	// #0
    2a48:	aa0003e1 	mov	x1, x0
    2a4c:	b40000e0 	cbz	x0, 2a68 <fwp_heap_init+0x198>
    2a50:	39400000 	ldrb	w0, [x0]
    2a54:	340000a0 	cbz	w0, 2a68 <fwp_heap_init+0x198>
    2a58:	7100c000 	subs	w0, w0, #0x30
    2a5c:	54000120 	b.eq	2a80 <fwp_heap_init+0x1b0>  // b.none
    2a60:	7100001f 	cmp	w0, #0x0
    2a64:	1a9f07e2 	cset	w2, ne	// ne = any
    2a68:	91158273 	add	x19, x19, #0x560
    2a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2a70:	b913aa62 	str	w2, [x19, #5032]
    2a74:	a94153f3 	ldp	x19, x20, [sp, #16]
    2a78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2a7c:	d65f03c0 	ret
    2a80:	39400420 	ldrb	w0, [x1, #1]
    2a84:	7100001f 	cmp	w0, #0x0
    2a88:	1a9f07e2 	cset	w2, ne	// ne = any
    2a8c:	17fffff7 	b	2a68 <fwp_heap_init+0x198>
    2a90:	97fffc90 	bl	1cd0 <fwp_heap_oom>

0000000000002a94 <fwp_wake_io>:
    2a94:	d00000e9 	adrp	x9, 20000 <__data_start>
    2a98:	91020122 	add	x2, x9, #0x80
    2a9c:	f9400001 	ldr	x1, [x0]
    2aa0:	5280000a 	mov	w10, #0x0                   	// #0
    2aa4:	f9401446 	ldr	x6, [x2, #40]
    2aa8:	52800008 	mov	w8, #0x0                   	// #0
    2aac:	4f000400 	movi	v0.4s, #0x0
    2ab0:	52800027 	mov	w7, #0x1                   	// #1
    2ab4:	aa0103e2 	mov	x2, x1
    2ab8:	b4000321 	cbz	x1, 2b1c <fwp_wake_io+0x88>
    2abc:	f9408c25 	ldr	x5, [x1, #280]
    2ac0:	39015c27 	strb	w7, [x1, #87]
    2ac4:	b4000165 	cbz	x5, 2af0 <fwp_wake_io+0x5c>
    2ac8:	a9520c24 	ldp	x4, x3, [x1, #288]
    2acc:	b4000364 	cbz	x4, 2b38 <fwp_wake_io+0xa4>
    2ad0:	f9009483 	str	x3, [x4, #296]
    2ad4:	f9409423 	ldr	x3, [x1, #296]
    2ad8:	b4000043 	cbz	x3, 2ae0 <fwp_wake_io+0x4c>
    2adc:	f9009064 	str	x4, [x3, #288]
    2ae0:	91080023 	add	x3, x1, #0x200
    2ae4:	f900943f 	str	xzr, [x1, #296]
    2ae8:	3c918060 	stur	q0, [x3, #-232]
    2aec:	f9400001 	ldr	x1, [x0]
    2af0:	f9402843 	ldr	x3, [x2, #80]
    2af4:	f2001c7f 	tst	x3, #0xff000000ff
    2af8:	54fffde1 	b.ne	2ab4 <fwp_wake_io+0x20>  // b.any
    2afc:	39015047 	strb	w7, [x2, #84]
    2b00:	f900805f 	str	xzr, [x2, #256]
    2b04:	b40001e6 	cbz	x6, 2b40 <fwp_wake_io+0xac>
    2b08:	f90080c2 	str	x2, [x6, #256]
    2b0c:	aa0203e6 	mov	x6, x2
    2b10:	52800028 	mov	w8, #0x1                   	// #1
    2b14:	aa0103e2 	mov	x2, x1
    2b18:	b5fffd21 	cbnz	x1, 2abc <fwp_wake_io+0x28>
    2b1c:	3400006a 	cbz	w10, 2b28 <fwp_wake_io+0x94>
    2b20:	91020120 	add	x0, x9, #0x80
    2b24:	f900180b 	str	x11, [x0, #48]
    2b28:	34000068 	cbz	w8, 2b34 <fwp_wake_io+0xa0>
    2b2c:	91020129 	add	x9, x9, #0x80
    2b30:	f9001526 	str	x6, [x9, #40]
    2b34:	d65f03c0 	ret
    2b38:	f90000a3 	str	x3, [x5]
    2b3c:	17ffffe7 	b	2ad8 <fwp_wake_io+0x44>
    2b40:	aa0203eb 	mov	x11, x2
    2b44:	5280002a 	mov	w10, #0x1                   	// #1
    2b48:	17fffff1 	b	2b0c <fwp_wake_io+0x78>
    2b4c:	d503201f 	nop

0000000000002b50 <fwp_poll_events>:
    2b50:	d10103ff 	sub	sp, sp, #0x40
    2b54:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    2b58:	f947f400 	ldr	x0, [x0, #4072]
    2b5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2b60:	910083fd 	add	x29, sp, #0x20
    2b64:	a90353f3 	stp	x19, x20, [sp, #48]
    2b68:	d00000f4 	adrp	x20, 20000 <__data_start>
    2b6c:	f9400001 	ldr	x1, [x0]
    2b70:	f9000fe1 	str	x1, [sp, #24]
    2b74:	d2800001 	mov	x1, #0x0                   	// #0
    2b78:	97fffdd2 	bl	22c0 <fwp_now_ns>
    2b7c:	91020281 	add	x1, x20, #0x80
    2b80:	f9401c33 	ldr	x19, [x1, #56]
    2b84:	b4000e93 	cbz	x19, 2d54 <fwp_poll_events+0x204>
    2b88:	aa1303e1 	mov	x1, x19
    2b8c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2b90:	14000005 	b	2ba4 <fwp_poll_events+0x54>
    2b94:	f9408821 	ldr	x1, [x1, #272]
    2b98:	eb03005f 	cmp	x2, x3
    2b9c:	9a83d042 	csel	x2, x2, x3, le
    2ba0:	b40000c1 	cbz	x1, 2bb8 <fwp_poll_events+0x68>
    2ba4:	f9403423 	ldr	x3, [x1, #104]
    2ba8:	b6ffff62 	tbz	x2, #63, 2b94 <fwp_poll_events+0x44>
    2bac:	f9408821 	ldr	x1, [x1, #272]
    2bb0:	aa0303e2 	mov	x2, x3
    2bb4:	b5ffff81 	cbnz	x1, 2ba4 <fwp_poll_events+0x54>
    2bb8:	b7f80ce2 	tbnz	x2, #63, 2d54 <fwp_poll_events+0x204>
    2bbc:	cb000042 	sub	x2, x2, x0
    2bc0:	f100005f 	cmp	x2, #0x0
    2bc4:	540005cd 	b.le	2c7c <fwp_poll_events+0x12c>
    2bc8:	d2869b60 	mov	x0, #0x34db                	// #13531
    2bcc:	d2884801 	mov	x1, #0x4240                	// #16960
    2bd0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2bd4:	f2a001e1 	movk	x1, #0xf, lsl #16
    2bd8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2bdc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2be0:	f2e86360 	movk	x0, #0x431b, lsl #48
    2be4:	9b407c40 	smulh	x0, x2, x0
    2be8:	9352fc00 	asr	x0, x0, #18
    2bec:	cb82fc00 	sub	x0, x0, x2, asr #63
    2bf0:	9b018802 	msub	x2, x0, x1, x2
    2bf4:	f100005f 	cmp	x2, #0x0
    2bf8:	9a800400 	cinc	x0, x0, ne	// ne = any
    2bfc:	eb03001f 	cmp	x0, x3
    2c00:	54000a0c 	b.gt	2d40 <fwp_poll_events+0x1f0>
    2c04:	340003c0 	cbz	w0, 2c7c <fwp_poll_events+0x12c>
    2c08:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2c0c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2c10:	72a20c42 	movk	w2, #0x1062, lsl #16
    2c14:	9ba27c02 	umull	x2, w0, w2
    2c18:	d366fc43 	lsr	x3, x2, #38
    2c1c:	aa0303e2 	mov	x2, x3
    2c20:	1b048063 	msub	w3, w3, w4, w0
    2c24:	9b217c63 	smull	x3, w3, w1
    2c28:	d2800001 	mov	x1, #0x0                   	// #0
    2c2c:	910023e0 	add	x0, sp, #0x8
    2c30:	a9008fe2 	stp	x2, x3, [sp, #8]
    2c34:	97fffa67 	bl	15d0 <nanosleep@plt>
    2c38:	91020280 	add	x0, x20, #0x80
    2c3c:	f9401c13 	ldr	x19, [x0, #56]
    2c40:	97fffda0 	bl	22c0 <fwp_now_ns>
    2c44:	aa0003e6 	mov	x6, x0
    2c48:	b50001f3 	cbnz	x19, 2c84 <fwp_poll_events+0x134>
    2c4c:	d503201f 	nop
    2c50:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    2c54:	f947f400 	ldr	x0, [x0, #4072]
    2c58:	f9400fe2 	ldr	x2, [sp, #24]
    2c5c:	f9400001 	ldr	x1, [x0]
    2c60:	eb010042 	subs	x2, x2, x1
    2c64:	d2800001 	mov	x1, #0x0                   	// #0
    2c68:	540008c1 	b.ne	2d80 <fwp_poll_events+0x230>  // b.any
    2c6c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2c70:	a94353f3 	ldp	x19, x20, [sp, #48]
    2c74:	910103ff 	add	sp, sp, #0x40
    2c78:	d65f03c0 	ret
    2c7c:	97fffd91 	bl	22c0 <fwp_now_ns>
    2c80:	aa0003e6 	mov	x6, x0
    2c84:	4f000400 	movi	v0.4s, #0x0
    2c88:	91020288 	add	x8, x20, #0x80
    2c8c:	52800027 	mov	w7, #0x1                   	// #1
    2c90:	f9403661 	ldr	x1, [x19, #104]
    2c94:	aa1303e5 	mov	x5, x19
    2c98:	f9408a73 	ldr	x19, [x19, #272]
    2c9c:	eb06003f 	cmp	x1, x6
    2ca0:	5400032c 	b.gt	2d04 <fwp_poll_events+0x1b4>
    2ca4:	394154a0 	ldrb	w0, [x5, #85]
    2ca8:	36000120 	tbz	w0, #0, 2ccc <fwp_poll_events+0x17c>
    2cac:	f94084a0 	ldr	x0, [x5, #264]
    2cb0:	b40003c0 	cbz	x0, 2d28 <fwp_poll_events+0x1d8>
    2cb4:	f9008813 	str	x19, [x0, #272]
    2cb8:	b4000053 	cbz	x19, 2cc0 <fwp_poll_events+0x170>
    2cbc:	f9008660 	str	x0, [x19, #264]
    2cc0:	910800a0 	add	x0, x5, #0x200
    2cc4:	390154bf 	strb	wzr, [x5, #85]
    2cc8:	3c908000 	stur	q0, [x0, #-248]
    2ccc:	f94030a0 	ldr	x0, [x5, #96]
    2cd0:	390158a7 	strb	w7, [x5, #86]
    2cd4:	f100001f 	cmp	x0, #0x0
    2cd8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2cdc:	5400018d 	b.le	2d0c <fwp_poll_events+0x1bc>
    2ce0:	f94028a0 	ldr	x0, [x5, #80]
    2ce4:	f2001c1f 	tst	x0, #0xff000000ff
    2ce8:	540000e1 	b.ne	2d04 <fwp_poll_events+0x1b4>  // b.any
    2cec:	f9401500 	ldr	x0, [x8, #40]
    2cf0:	390150a7 	strb	w7, [x5, #84]
    2cf4:	f90080bf 	str	xzr, [x5, #256]
    2cf8:	b40001e0 	cbz	x0, 2d34 <fwp_poll_events+0x1e4>
    2cfc:	f9001505 	str	x5, [x8, #40]
    2d00:	f9008005 	str	x5, [x0, #256]
    2d04:	b5fffc73 	cbnz	x19, 2c90 <fwp_poll_events+0x140>
    2d08:	17ffffd2 	b	2c50 <fwp_poll_events+0x100>
    2d0c:	394144a0 	ldrb	w0, [x5, #81]
    2d10:	3707fe80 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d14:	394140a0 	ldrb	w0, [x5, #80]
    2d18:	3707fe40 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d1c:	aa0503e0 	mov	x0, x5
    2d20:	97fffd14 	bl	2170 <fwp_cancel_tree.part.0>
    2d24:	17ffffef 	b	2ce0 <fwp_poll_events+0x190>
    2d28:	91020281 	add	x1, x20, #0x80
    2d2c:	f9001c33 	str	x19, [x1, #56]
    2d30:	17ffffe2 	b	2cb8 <fwp_poll_events+0x168>
    2d34:	f9001505 	str	x5, [x8, #40]
    2d38:	f9001905 	str	x5, [x8, #48]
    2d3c:	17fffff2 	b	2d04 <fwp_poll_events+0x1b4>
    2d40:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2d44:	d2989362 	mov	x2, #0xc49b                	// #50331
    2d48:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2d4c:	f2a00402 	movk	x2, #0x20, lsl #16
    2d50:	17ffffb6 	b	2c28 <fwp_poll_events+0xd8>
    2d54:	97fffb9f 	bl	1bd0 <fwp_flush>
    2d58:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14da0>
    2d5c:	f947e863 	ldr	x3, [x3, #4048]
    2d60:	d2800562 	mov	x2, #0x2b                  	// #43
    2d64:	d2800021 	mov	x1, #0x1                   	// #1
    2d68:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    2d6c:	91026000 	add	x0, x0, #0x98
    2d70:	f9400063 	ldr	x3, [x3]
    2d74:	97fffa23 	bl	1600 <fwrite@plt>
    2d78:	52800ca0 	mov	w0, #0x65                  	// #101
    2d7c:	97fff98d 	bl	13b0 <exit@plt>
    2d80:	97fff9e0 	bl	1500 <__stack_chk_fail@plt>

0000000000002d84 <fwp_rc_forget_slot>:
    2d84:	aa0003e1 	mov	x1, x0
    2d88:	39400000 	ldrb	w0, [x0]
    2d8c:	7103fc1f 	cmp	w0, #0xff
    2d90:	54000040 	b.eq	2d98 <fwp_rc_forget_slot+0x14>  // b.none
    2d94:	d65f03c0 	ret
    2d98:	ca414420 	eor	x0, x1, x1, lsr #17
    2d9c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2da0:	ca402400 	eor	x0, x0, x0, lsr #9
    2da4:	910003fd 	mov	x29, sp
    2da8:	92401c00 	and	x0, x0, #0xff
    2dac:	f9000bf3 	str	x19, [sp, #16]
    2db0:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xc80>
    2db4:	91158262 	add	x2, x19, #0x560
    2db8:	910a2403 	add	x3, x0, #0x289
    2dbc:	8b000c40 	add	x0, x2, x0, lsl #3
    2dc0:	8b030c43 	add	x3, x2, x3, lsl #3
    2dc4:	f94a2400 	ldr	x0, [x0, #5192]
    2dc8:	b50000a0 	cbnz	x0, 2ddc <fwp_rc_forget_slot+0x58>
    2dcc:	14000011 	b	2e10 <fwp_rc_forget_slot+0x8c>
    2dd0:	91004003 	add	x3, x0, #0x10
    2dd4:	f9400800 	ldr	x0, [x0, #16]
    2dd8:	b40001c0 	cbz	x0, 2e10 <fwp_rc_forget_slot+0x8c>
    2ddc:	f9400002 	ldr	x2, [x0]
    2de0:	eb02003f 	cmp	x1, x2
    2de4:	54ffff61 	b.ne	2dd0 <fwp_rc_forget_slot+0x4c>  // b.any
    2de8:	f9400801 	ldr	x1, [x0, #16]
    2dec:	91158273 	add	x19, x19, #0x560
    2df0:	f9000061 	str	x1, [x3]
    2df4:	97fff9f3 	bl	15c0 <free@plt>
    2df8:	f94e2660 	ldr	x0, [x19, #7240]
    2dfc:	d1000400 	sub	x0, x0, #0x1
    2e00:	f90e2660 	str	x0, [x19, #7240]
    2e04:	f9400bf3 	ldr	x19, [sp, #16]
    2e08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e0c:	d65f03c0 	ret
    2e10:	f0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    2e14:	91032000 	add	x0, x0, #0xc8
    2e18:	97fffd1a 	bl	2280 <fwp_trap>
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_rc_prepare_chunk>:
    2e20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2e24:	910003fd 	mov	x29, sp
    2e28:	a9025bf5 	stp	x21, x22, [sp, #32]
    2e2c:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xc80>
    2e30:	911582c2 	add	x2, x22, #0x560
    2e34:	b9401c03 	ldr	w3, [x0, #28]
    2e38:	aa0103f5 	mov	x21, x1
    2e3c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e40:	aa0003f4 	mov	x20, x0
    2e44:	f94e2440 	ldr	x0, [x2, #7240]
    2e48:	b4000440 	cbz	x0, 2ed0 <fwp_rc_prepare_chunk+0xb0>
    2e4c:	d2800013 	mov	x19, #0x0                   	// #0
    2e50:	35000203 	cbnz	w3, 2e90 <fwp_rc_prepare_chunk+0x70>
    2e54:	b4000361 	cbz	x1, 2ec0 <fwp_rc_prepare_chunk+0xa0>
    2e58:	f9401280 	ldr	x0, [x20, #32]
    2e5c:	97fff9d9 	bl	15c0 <free@plt>
    2e60:	aa1503e0 	mov	x0, x21
    2e64:	d2800021 	mov	x1, #0x1                   	// #1
    2e68:	97fff99e 	bl	14e0 <calloc@plt>
    2e6c:	f9001280 	str	x0, [x20, #32]
    2e70:	b5000460 	cbnz	x0, 2efc <fwp_rc_prepare_chunk+0xdc>
    2e74:	97fffb97 	bl	1cd0 <fwp_heap_oom>
    2e78:	97ffffc3 	bl	2d84 <fwp_rc_forget_slot>
    2e7c:	91000673 	add	x19, x19, #0x1
    2e80:	b9401e83 	ldr	w3, [x20, #28]
    2e84:	eb13007f 	cmp	x3, x19
    2e88:	54000169 	b.ls	2eb4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2e8c:	d503201f 	nop
    2e90:	f9401283 	ldr	x3, [x20, #32]
    2e94:	8b130060 	add	x0, x3, x19
    2e98:	38736863 	ldrb	w3, [x3, x19]
    2e9c:	7103fc7f 	cmp	w3, #0xff
    2ea0:	54fffec0 	b.eq	2e78 <fwp_rc_prepare_chunk+0x58>  // b.none
    2ea4:	b9401e83 	ldr	w3, [x20, #28]
    2ea8:	91000673 	add	x19, x19, #0x1
    2eac:	eb13007f 	cmp	x3, x19
    2eb0:	54ffff08 	b.hi	2e90 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2eb4:	eb0302bf 	cmp	x21, x3
    2eb8:	54000121 	b.ne	2edc <fwp_rc_prepare_chunk+0xbc>  // b.any
    2ebc:	b5000335 	cbnz	x21, 2f20 <fwp_rc_prepare_chunk+0x100>
    2ec0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ec4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ec8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2ecc:	d65f03c0 	ret
    2ed0:	2a0303e3 	mov	w3, w3
    2ed4:	eb0302bf 	cmp	x21, x3
    2ed8:	54ffff20 	b.eq	2ebc <fwp_rc_prepare_chunk+0x9c>  // b.none
    2edc:	911582c2 	add	x2, x22, #0x560
    2ee0:	f9401280 	ldr	x0, [x20, #32]
    2ee4:	f94e2841 	ldr	x1, [x2, #7248]
    2ee8:	cb030021 	sub	x1, x1, x3
    2eec:	f90e2841 	str	x1, [x2, #7248]
    2ef0:	97fff9b4 	bl	15c0 <free@plt>
    2ef4:	b5fffb75 	cbnz	x21, 2e60 <fwp_rc_prepare_chunk+0x40>
    2ef8:	f900129f 	str	xzr, [x20, #32]
    2efc:	911582d6 	add	x22, x22, #0x560
    2f00:	f94e2ac0 	ldr	x0, [x22, #7248]
    2f04:	b9001e95 	str	w21, [x20, #28]
    2f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f0c:	8b150000 	add	x0, x0, x21
    2f10:	f90e2ac0 	str	x0, [x22, #7248]
    2f14:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f1c:	d65f03c0 	ret
    2f20:	f9401280 	ldr	x0, [x20, #32]
    2f24:	aa1503e2 	mov	x2, x21
    2f28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f2c:	52800001 	mov	w1, #0x0                   	// #0
    2f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f38:	17fff966 	b	14d0 <memset@plt>
    2f3c:	d503201f 	nop

0000000000002f40 <fwp_heap_refill>:
    2f40:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2f44:	910003fd 	mov	x29, sp
    2f48:	a9025bf5 	stp	x21, x22, [sp, #32]
    2f4c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    2f50:	911582b5 	add	x21, x21, #0x560
    2f54:	aa0003f6 	mov	x22, x0
    2f58:	d2800020 	mov	x0, #0x1                   	// #1
    2f5c:	a90153f3 	stp	x19, x20, [sp, #16]
    2f60:	a90363f7 	stp	x23, x24, [sp, #48]
    2f64:	2a0103f7 	mov	w23, w1
    2f68:	2a0203f8 	mov	w24, w2
    2f6c:	97fffb69 	bl	1d10 <fwp_heap_chunks>
    2f70:	aa0003f3 	mov	x19, x0
    2f74:	f949fea2 	ldr	x2, [x21, #5112]
    2f78:	8b000800 	add	x0, x0, x0, lsl #2
    2f7c:	2a1703e1 	mov	w1, w23
    2f80:	52800025 	mov	w5, #0x1                   	// #1
    2f84:	d37df000 	lsl	x0, x0, #3
    2f88:	910f0021 	add	x1, x1, #0x3c0
    2f8c:	8b000054 	add	x20, x2, x0
    2f90:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2f94:	52a00024 	mov	w4, #0x10000               	// #65536
    2f98:	38206845 	strb	w5, [x2, x0]
    2f9c:	aa1403e0 	mov	x0, x20
    2fa0:	39000698 	strb	w24, [x20, #1]
    2fa4:	39000a97 	strb	w23, [x20, #2]
    2fa8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2fac:	b9000681 	str	w1, [x20, #4]
    2fb0:	2a0103e5 	mov	w5, w1
    2fb4:	8b0300a2 	add	x2, x5, x3
    2fb8:	1ac10881 	udiv	w1, w4, w1
    2fbc:	9ac50842 	udiv	x2, x2, x5
    2fc0:	b9000a81 	str	w1, [x20, #8]
    2fc4:	92404021 	and	x1, x1, #0x1ffff
    2fc8:	b9001a82 	str	w2, [x20, #24]
    2fcc:	97ffff95 	bl	2e20 <fwp_rc_prepare_chunk>
    2fd0:	f949daa0 	ldr	x0, [x21, #5040]
    2fd4:	29408a81 	ldp	w1, w2, [x20, #4]
    2fd8:	8b134000 	add	x0, x0, x19, lsl #16
    2fdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2fe0:	8b214003 	add	x3, x0, w1, uxtw
    2fe4:	9ba20021 	umaddl	x1, w1, w2, x0
    2fe8:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fec:	a90086c3 	stp	x3, x1, [x22, #8]
    2ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ff4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2ff8:	d65f03c0 	ret
    2ffc:	d503201f 	nop

0000000000003000 <fwp_mem_free>:
    3000:	b40003c0 	cbz	x0, 3078 <fwp_mem_free+0x78>
    3004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3008:	910003fd 	mov	x29, sp
    300c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3010:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    3014:	911582a1 	add	x1, x21, #0x560
    3018:	a90153f3 	stp	x19, x20, [sp, #16]
    301c:	aa0003f3 	mov	x19, x0
    3020:	f949d823 	ldr	x3, [x1, #5040]
    3024:	f949ec22 	ldr	x2, [x1, #5080]
    3028:	cb030000 	sub	x0, x0, x3
    302c:	eb02401f 	cmp	x0, x2, lsl #16
    3030:	540001c2 	b.cs	3068 <fwp_mem_free+0x68>  // b.hs, b.nlast
    3034:	d350fc16 	lsr	x22, x0, #16
    3038:	a90363f7 	stp	x23, x24, [sp, #48]
    303c:	f949fc22 	ldr	x2, [x1, #5112]
    3040:	8b160ad4 	add	x20, x22, x22, lsl #2
    3044:	d37df294 	lsl	x20, x20, #3
    3048:	ab140057 	adds	x23, x2, x20
    304c:	540000c0 	b.eq	3064 <fwp_mem_free+0x64>  // b.none
    3050:	38746842 	ldrb	w2, [x2, x20]
    3054:	7100045f 	cmp	w2, #0x1
    3058:	54000120 	b.eq	307c <fwp_mem_free+0x7c>  // b.none
    305c:	7100085f 	cmp	w2, #0x2
    3060:	540005e0 	b.eq	311c <fwp_mem_free+0x11c>  // b.none
    3064:	a94363f7 	ldp	x23, x24, [sp, #48]
    3068:	a94153f3 	ldp	x19, x20, [sp, #16]
    306c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3070:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3074:	d65f03c0 	ret
    3078:	d65f03c0 	ret
    307c:	f94012f8 	ldr	x24, [x23, #32]
    3080:	b94006e1 	ldr	w1, [x23, #4]
    3084:	f90023f9 	str	x25, [sp, #64]
    3088:	2a0103e2 	mov	w2, w1
    308c:	394006f9 	ldrb	w25, [x23, #1]
    3090:	39400af4 	ldrb	w20, [x23, #2]
    3094:	b4000158 	cbz	x24, 30bc <fwp_mem_free+0xbc>
    3098:	92403e76 	and	x22, x19, #0xffff
    309c:	9ac20ad6 	udiv	x22, x22, x2
    30a0:	38766b01 	ldrb	w1, [x24, x22]
    30a4:	8b160300 	add	x0, x24, x22
    30a8:	7103fc3f 	cmp	w1, #0xff
    30ac:	54000980 	b.eq	31dc <fwp_mem_free+0x1dc>  // b.none
    30b0:	38366b1f 	strb	wzr, [x24, x22]
    30b4:	b94006e1 	ldr	w1, [x23, #4]
    30b8:	2a0103e2 	mov	w2, w1
    30bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    30c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    30c4:	cb390000 	sub	x0, x0, w25, uxtb
    30c8:	8b340074 	add	x20, x3, w20, uxtb
    30cc:	911582b5 	add	x21, x21, #0x560
    30d0:	1e630021 	ucvtf	d1, w1
    30d4:	d37ae400 	lsl	x0, x0, #6
    30d8:	8b140c14 	add	x20, x0, x20, lsl #3
    30dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    30e0:	f8746aa0 	ldr	x0, [x21, x20]
    30e4:	f94023f9 	ldr	x25, [sp, #64]
    30e8:	aa2003e0 	mvn	x0, x0
    30ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    30f0:	f9000260 	str	x0, [x19]
    30f4:	f8346ab3 	str	x19, [x21, x20]
    30f8:	f94a12a0 	ldr	x0, [x21, #5152]
    30fc:	1e612800 	fadd	d0, d0, d1
    3100:	a94153f3 	ldp	x19, x20, [sp, #16]
    3104:	cb020000 	sub	x0, x0, x2
    3108:	f90a12a0 	str	x0, [x21, #5152]
    310c:	fd0a22a0 	str	d0, [x21, #5184]
    3110:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3114:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3118:	d65f03c0 	ret
    311c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    3120:	8b000063 	add	x3, x3, x0
    3124:	eb03027f 	cmp	x19, x3
    3128:	54fff9e1 	b.ne	3064 <fwp_mem_free+0x64>  // b.any
    312c:	fd400ae1 	ldr	d1, [x23, #16]
    3130:	fd4a2020 	ldr	d0, [x1, #5184]
    3134:	f9400ae0 	ldr	x0, [x23, #16]
    3138:	7e61d821 	ucvtf	d1, d1
    313c:	f94a1022 	ldr	x2, [x1, #5152]
    3140:	f94012f3 	ldr	x19, [x23, #32]
    3144:	1e612800 	fadd	d0, d0, d1
    3148:	cb000042 	sub	x2, x2, x0
    314c:	f90a1022 	str	x2, [x1, #5152]
    3150:	fd0a2020 	str	d0, [x1, #5184]
    3154:	b40000b3 	cbz	x19, 3168 <fwp_mem_free+0x168>
    3158:	39400260 	ldrb	w0, [x19]
    315c:	7103fc1f 	cmp	w0, #0xff
    3160:	54000380 	b.eq	31d0 <fwp_mem_free+0x1d0>  // b.none
    3164:	3900027f 	strb	wzr, [x19]
    3168:	b9400ee2 	ldr	w2, [x23, #12]
    316c:	b4000142 	cbz	x2, 3194 <fwp_mem_free+0x194>
    3170:	911582a1 	add	x1, x21, #0x560
    3174:	8b160040 	add	x0, x2, x22
    3178:	8b000800 	add	x0, x0, x0, lsl #2
    317c:	f949fc21 	ldr	x1, [x1, #5112]
    3180:	8b140034 	add	x20, x1, x20
    3184:	8b000c20 	add	x0, x1, x0, lsl #3
    3188:	3802869f 	strb	wzr, [x20], #40
    318c:	eb00029f 	cmp	x20, x0
    3190:	54ffffc1 	b.ne	3188 <fwp_mem_free+0x188>  // b.any
    3194:	911582a0 	add	x0, x21, #0x560
    3198:	f94a1801 	ldr	x1, [x0, #5168]
    319c:	f949f803 	ldr	x3, [x0, #5104]
    31a0:	8b020021 	add	x1, x1, x2
    31a4:	f90a1801 	str	x1, [x0, #5168]
    31a8:	eb16007f 	cmp	x3, x22
    31ac:	54000049 	b.ls	31b4 <fwp_mem_free+0x1b4>  // b.plast
    31b0:	f909f816 	str	x22, [x0, #5104]
    31b4:	911582b5 	add	x21, x21, #0x560
    31b8:	f949f6a0 	ldr	x0, [x21, #5096]
    31bc:	eb16001f 	cmp	x0, x22
    31c0:	54fff529 	b.ls	3064 <fwp_mem_free+0x64>  // b.plast
    31c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    31c8:	f909f6b6 	str	x22, [x21, #5096]
    31cc:	17ffffa7 	b	3068 <fwp_mem_free+0x68>
    31d0:	aa1303e0 	mov	x0, x19
    31d4:	97fffeec 	bl	2d84 <fwp_rc_forget_slot>
    31d8:	17ffffe3 	b	3164 <fwp_mem_free+0x164>
    31dc:	97fffeea 	bl	2d84 <fwp_rc_forget_slot>
    31e0:	17ffffb4 	b	30b0 <fwp_mem_free+0xb0>

00000000000031e4 <fwp_heap_alloc_big>:
    31e4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    31e8:	910003fd 	mov	x29, sp
    31ec:	a90153f3 	stp	x19, x20, [sp, #16]
    31f0:	a9025bf5 	stp	x21, x22, [sp, #32]
    31f4:	a90363f7 	stp	x23, x24, [sp, #48]
    31f8:	aa0003f7 	mov	x23, x0
    31fc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    3200:	a9046bf9 	stp	x25, x26, [sp, #64]
    3204:	eb0002ff 	cmp	x23, x0
    3208:	54000888 	b.hi	3318 <fwp_heap_alloc_big+0x134>  // b.pmore
    320c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3210:	8b0002f4 	add	x20, x23, x0
    3214:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xc80>
    3218:	91158359 	add	x25, x26, #0x560
    321c:	d350fe94 	lsr	x20, x20, #16
    3220:	2a0103f5 	mov	w21, w1
    3224:	aa1403e0 	mov	x0, x20
    3228:	97fffaba 	bl	1d10 <fwp_heap_chunks>
    322c:	f949ff22 	ldr	x2, [x25, #5112]
    3230:	8b000813 	add	x19, x0, x0, lsl #2
    3234:	aa0003f8 	mov	x24, x0
    3238:	52800043 	mov	w3, #0x2                   	// #2
    323c:	d37df273 	lsl	x19, x19, #3
    3240:	d2800021 	mov	x1, #0x1                   	// #1
    3244:	8b130040 	add	x0, x2, x19
    3248:	38336843 	strb	w3, [x2, x19]
    324c:	39000415 	strb	w21, [x0, #1]
    3250:	b9000c14 	str	w20, [x0, #12]
    3254:	f9000817 	str	x23, [x0, #16]
    3258:	97fffef2 	bl	2e20 <fwp_rc_prepare_chunk>
    325c:	f100069f 	cmp	x20, #0x1
    3260:	54000269 	b.ls	32ac <fwp_heap_alloc_big+0xc8>  // b.plast
    3264:	8b180294 	add	x20, x20, x24
    3268:	9100a273 	add	x19, x19, #0x28
    326c:	a90573fb 	stp	x27, x28, [sp, #80]
    3270:	5280007b 	mov	w27, #0x3                   	// #3
    3274:	8b140a94 	add	x20, x20, x20, lsl #2
    3278:	2a1803fc 	mov	w28, w24
    327c:	9adb2296 	lsl	x22, x20, x27
    3280:	f949ff35 	ldr	x21, [x25, #5112]
    3284:	d2800001 	mov	x1, #0x0                   	// #0
    3288:	8b1302b4 	add	x20, x21, x19
    328c:	aa1403e0 	mov	x0, x20
    3290:	97fffee4 	bl	2e20 <fwp_rc_prepare_chunk>
    3294:	38336abb 	strb	w27, [x21, x19]
    3298:	9100a273 	add	x19, x19, #0x28
    329c:	b9000e9c 	str	w28, [x20, #12]
    32a0:	eb1302df 	cmp	x22, x19
    32a4:	54fffee1 	b.ne	3280 <fwp_heap_alloc_big+0x9c>  // b.any
    32a8:	a94573fb 	ldp	x27, x28, [sp, #80]
    32ac:	91158353 	add	x19, x26, #0x560
    32b0:	aa1703e2 	mov	x2, x23
    32b4:	52800001 	mov	w1, #0x0                   	// #0
    32b8:	f949da60 	ldr	x0, [x19, #5040]
    32bc:	8b184018 	add	x24, x0, x24, lsl #16
    32c0:	aa1803e0 	mov	x0, x24
    32c4:	97fff883 	bl	14d0 <memset@plt>
    32c8:	f94a1260 	ldr	x0, [x19, #5152]
    32cc:	ab170000 	adds	x0, x0, x23
    32d0:	54000242 	b.cs	3318 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    32d4:	f94a1661 	ldr	x1, [x19, #5160]
    32d8:	f90a1260 	str	x0, [x19, #5152]
    32dc:	eb01001f 	cmp	x0, x1
    32e0:	54000049 	b.ls	32e8 <fwp_heap_alloc_big+0x104>  // b.plast
    32e4:	f90a1660 	str	x0, [x19, #5160]
    32e8:	9115835a 	add	x26, x26, #0x560
    32ec:	9e6202e0 	scvtf	d0, x23
    32f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32f4:	aa1803e0 	mov	x0, x24
    32f8:	fd4a1f41 	ldr	d1, [x26, #5176]
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	1e602820 	fadd	d0, d1, d0
    3304:	a94363f7 	ldp	x23, x24, [sp, #48]
    3308:	fd0a1f40 	str	d0, [x26, #5176]
    330c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3310:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3314:	d65f03c0 	ret
    3318:	a90573fb 	stp	x27, x28, [sp, #80]
    331c:	97fffa6d 	bl	1cd0 <fwp_heap_oom>

0000000000003320 <fwp_heap_alloc_slow>:
    3320:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3324:	910003fd 	mov	x29, sp
    3328:	a90153f3 	stp	x19, x20, [sp, #16]
    332c:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc80>
    3330:	91158262 	add	x2, x19, #0x560
    3334:	a9025bf5 	stp	x21, x22, [sp, #32]
    3338:	aa0003f5 	mov	x21, x0
    333c:	2a0103f4 	mov	w20, w1
    3340:	b953a440 	ldr	w0, [x2, #5028]
    3344:	34000600 	cbz	w0, 3404 <fwp_heap_alloc_slow+0xe4>
    3348:	f14012bf 	cmp	x21, #0x4, lsl #12
    334c:	54000628 	b.hi	3410 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3350:	91003ea0 	add	x0, x21, #0xf
    3354:	91158262 	add	x2, x19, #0x560
    3358:	f9001bf7 	str	x23, [sp, #48]
    335c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3360:	8b401040 	add	x0, x2, x0, lsr #4
    3364:	cb34c084 	sub	x4, x4, w20, sxtw
    3368:	d37ae484 	lsl	x4, x4, #6
    336c:	397e8003 	ldrb	w3, [x0, #4000]
    3370:	910f0060 	add	x0, x3, #0x3c0
    3374:	aa0303e1 	mov	x1, x3
    3378:	8b030463 	add	x3, x3, x3, lsl #1
    337c:	8b030c83 	add	x3, x4, x3, lsl #3
    3380:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3384:	2a1703f6 	mov	w22, w23
    3388:	f8636844 	ldr	x4, [x2, x3]
    338c:	b40004e4 	cbz	x4, 3428 <fwp_heap_alloc_slow+0x108>
    3390:	f9400080 	ldr	x0, [x4]
    3394:	aa2003e0 	mvn	x0, x0
    3398:	f8236840 	str	x0, [x2, x3]
    339c:	7100069f 	cmp	w20, #0x1
    33a0:	aa0403e0 	mov	x0, x4
    33a4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    33a8:	52800001 	mov	w1, #0x0                   	// #0
    33ac:	97fff849 	bl	14d0 <memset@plt>
    33b0:	aa0003e4 	mov	x4, x0
    33b4:	91158260 	add	x0, x19, #0x560
    33b8:	f94a1001 	ldr	x1, [x0, #5152]
    33bc:	ab160021 	adds	x1, x1, x22
    33c0:	540005c2 	b.cs	3478 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    33c4:	f94a1402 	ldr	x2, [x0, #5160]
    33c8:	f90a1001 	str	x1, [x0, #5152]
    33cc:	eb02003f 	cmp	x1, x2
    33d0:	54000049 	b.ls	33d8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    33d4:	f90a1401 	str	x1, [x0, #5160]
    33d8:	91158273 	add	x19, x19, #0x560
    33dc:	1e6302e1 	ucvtf	d1, w23
    33e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33e4:	aa0403e0 	mov	x0, x4
    33e8:	fd4a1e60 	ldr	d0, [x19, #5176]
    33ec:	f9401bf7 	ldr	x23, [sp, #48]
    33f0:	1e612800 	fadd	d0, d0, d1
    33f4:	fd0a1e60 	str	d0, [x19, #5176]
    33f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3400:	d65f03c0 	ret
    3404:	97fffd33 	bl	28d0 <fwp_heap_init>
    3408:	f14012bf 	cmp	x21, #0x4, lsl #12
    340c:	54fffa29 	b.ls	3350 <fwp_heap_alloc_slow+0x30>  // b.plast
    3410:	2a1403e1 	mov	w1, w20
    3414:	aa1503e0 	mov	x0, x21
    3418:	a94153f3 	ldp	x19, x20, [sp, #16]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3424:	17ffff70 	b	31e4 <fwp_heap_alloc_big>
    3428:	8b030042 	add	x2, x2, x3
    342c:	f9400444 	ldr	x4, [x2, #8]
    3430:	b4000104 	cbz	x4, 3450 <fwp_heap_alloc_slow+0x130>
    3434:	f9400840 	ldr	x0, [x2, #16]
    3438:	cb040000 	sub	x0, x0, x4
    343c:	eb16001f 	cmp	x0, x22
    3440:	54000083 	b.cc	3450 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3444:	8b160080 	add	x0, x4, x22
    3448:	f9000440 	str	x0, [x2, #8]
    344c:	17ffffd4 	b	339c <fwp_heap_alloc_slow+0x7c>
    3450:	52800302 	mov	w2, #0x18                  	// #24
    3454:	52807804 	mov	w4, #0x3c0                 	// #960
    3458:	91158260 	add	x0, x19, #0x560
    345c:	9ba27c23 	umull	x3, w1, w2
    3460:	2a1403e2 	mov	w2, w20
    3464:	9b240e84 	smaddl	x4, w20, w4, x3
    3468:	8b040000 	add	x0, x0, x4
    346c:	97fffeb5 	bl	2f40 <fwp_heap_refill>
    3470:	aa0003e4 	mov	x4, x0
    3474:	17ffffca 	b	339c <fwp_heap_alloc_slow+0x7c>
    3478:	97fffa16 	bl	1cd0 <fwp_heap_oom>
    347c:	d503201f 	nop

0000000000003480 <fwp_rc_fresh>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xc80>
    3488:	91158063 	add	x3, x3, #0x560
    348c:	910003fd 	mov	x29, sp
    3490:	a90153f3 	stp	x19, x20, [sp, #16]
    3494:	aa0003f3 	mov	x19, x0
    3498:	f949d861 	ldr	x1, [x3, #5040]
    349c:	f949ec60 	ldr	x0, [x3, #5080]
    34a0:	cb010261 	sub	x1, x19, x1
    34a4:	eb00403f 	cmp	x1, x0, lsl #16
    34a8:	54000322 	b.cs	350c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    34ac:	d350fc22 	lsr	x2, x1, #16
    34b0:	f949fc63 	ldr	x3, [x3, #5112]
    34b4:	8b020842 	add	x2, x2, x2, lsl #2
    34b8:	d37df042 	lsl	x2, x2, #3
    34bc:	8b020060 	add	x0, x3, x2
    34c0:	f9401014 	ldr	x20, [x0, #32]
    34c4:	b4000254 	cbz	x20, 350c <fwp_rc_fresh+0x8c>
    34c8:	38626862 	ldrb	w2, [x3, x2]
    34cc:	7100085f 	cmp	w2, #0x2
    34d0:	54000260 	b.eq	351c <fwp_rc_fresh+0x9c>  // b.none
    34d4:	7100045f 	cmp	w2, #0x1
    34d8:	540001a1 	b.ne	350c <fwp_rc_fresh+0x8c>  // b.any
    34dc:	29430002 	ldp	w2, w0, [x0, #24]
    34e0:	92403c21 	and	x1, x1, #0xffff
    34e4:	9b027c21 	mul	x1, x1, x2
    34e8:	d360fc21 	lsr	x1, x1, #32
    34ec:	eb00003f 	cmp	x1, x0
    34f0:	540000e2 	b.cs	350c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    34f4:	8b010294 	add	x20, x20, x1
    34f8:	39400280 	ldrb	w0, [x20]
    34fc:	7103fc1f 	cmp	w0, #0xff
    3500:	540001a0 	b.eq	3534 <fwp_rc_fresh+0xb4>  // b.none
    3504:	52800020 	mov	w0, #0x1                   	// #1
    3508:	39000280 	strb	w0, [x20]
    350c:	aa1303e0 	mov	x0, x19
    3510:	a94153f3 	ldp	x19, x20, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	72003c3f 	tst	w1, #0xffff
    3520:	54fffec0 	b.eq	34f8 <fwp_rc_fresh+0x78>  // b.none
    3524:	aa1303e0 	mov	x0, x19
    3528:	a94153f3 	ldp	x19, x20, [sp, #16]
    352c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3530:	d65f03c0 	ret
    3534:	aa1403e0 	mov	x0, x20
    3538:	97fffe13 	bl	2d84 <fwp_rc_forget_slot>
    353c:	17fffff2 	b	3504 <fwp_rc_fresh+0x84>

0000000000003540 <fwp_rc_free_arr>:
    3540:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xc80>
    3544:	91158063 	add	x3, x3, #0x560
    3548:	f949d861 	ldr	x1, [x3, #5040]
    354c:	f949ec62 	ldr	x2, [x3, #5080]
    3550:	cb010001 	sub	x1, x0, x1
    3554:	eb02403f 	cmp	x1, x2, lsl #16
    3558:	54000342 	b.cs	35c0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    355c:	d350fc22 	lsr	x2, x1, #16
    3560:	f949fc65 	ldr	x5, [x3, #5112]
    3564:	8b020842 	add	x2, x2, x2, lsl #2
    3568:	d37df042 	lsl	x2, x2, #3
    356c:	8b0200a4 	add	x4, x5, x2
    3570:	f9401083 	ldr	x3, [x4, #32]
    3574:	b4000263 	cbz	x3, 35c0 <fwp_rc_free_arr+0x80>
    3578:	386268a2 	ldrb	w2, [x5, x2]
    357c:	7100085f 	cmp	w2, #0x2
    3580:	540001c0 	b.eq	35b8 <fwp_rc_free_arr+0x78>  // b.none
    3584:	7100045f 	cmp	w2, #0x1
    3588:	540001c1 	b.ne	35c0 <fwp_rc_free_arr+0x80>  // b.any
    358c:	29430885 	ldp	w5, w2, [x4, #24]
    3590:	92403c21 	and	x1, x1, #0xffff
    3594:	9b057c21 	mul	x1, x1, x5
    3598:	d360fc21 	lsr	x1, x1, #32
    359c:	eb02003f 	cmp	x1, x2
    35a0:	54000102 	b.cs	35c0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    35a4:	8b010063 	add	x3, x3, x1
    35a8:	39400061 	ldrb	w1, [x3]
    35ac:	7100043f 	cmp	w1, #0x1
    35b0:	54000081 	b.ne	35c0 <fwp_rc_free_arr+0x80>  // b.any
    35b4:	17fffe93 	b	3000 <fwp_mem_free>
    35b8:	72003c3f 	tst	w1, #0xffff
    35bc:	54ffff60 	b.eq	35a8 <fwp_rc_free_arr+0x68>  // b.none
    35c0:	d65f03c0 	ret

00000000000035c4 <fwp_heap_alloc>:
    35c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    35c8:	910003fd 	mov	x29, sp
    35cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    35d0:	b00000f6 	adrp	x22, 20000 <__data_start>
    35d4:	910202c2 	add	x2, x22, #0x80
    35d8:	a90363f7 	stp	x23, x24, [sp, #48]
    35dc:	b9404058 	ldr	w24, [x2, #64]
    35e0:	a90153f3 	stp	x19, x20, [sp, #16]
    35e4:	7100031f 	cmp	w24, #0x0
    35e8:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    35ec:	54000861 	b.ne	36f8 <fwp_heap_alloc+0x134>  // b.any
    35f0:	d0000177 	adrp	x23, 31000 <fwp_root_context+0xc80>
    35f4:	911582f3 	add	x19, x23, #0x560
    35f8:	f140101f 	cmp	x0, #0x4, lsl #12
    35fc:	b953a662 	ldr	w2, [x19, #5028]
    3600:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3604:	54000740 	b.eq	36ec <fwp_heap_alloc+0x128>  // b.none
    3608:	91003c03 	add	x3, x0, #0xf
    360c:	937c7c22 	sbfiz	x2, x1, #4, #32
    3610:	cb21c042 	sub	x2, x2, w1, sxtw
    3614:	8b431263 	add	x3, x19, x3, lsr #4
    3618:	d37ae442 	lsl	x2, x2, #6
    361c:	397e8063 	ldrb	w3, [x3, #4000]
    3620:	910f0064 	add	x4, x3, #0x3c0
    3624:	8b030463 	add	x3, x3, x3, lsl #1
    3628:	8b030c43 	add	x3, x2, x3, lsl #3
    362c:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    3630:	2a1503f4 	mov	w20, w21
    3634:	f8636a64 	ldr	x4, [x19, x3]
    3638:	b40004c4 	cbz	x4, 36d0 <fwp_heap_alloc+0x10c>
    363c:	f9400085 	ldr	x5, [x4]
    3640:	7100043f 	cmp	w1, #0x1
    3644:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3648:	aa0403e0 	mov	x0, x4
    364c:	aa2503e5 	mvn	x5, x5
    3650:	52800001 	mov	w1, #0x0                   	// #0
    3654:	f8236a65 	str	x5, [x19, x3]
    3658:	97fff79e 	bl	14d0 <memset@plt>
    365c:	aa0003e4 	mov	x4, x0
    3660:	f94a1260 	ldr	x0, [x19, #5152]
    3664:	ab140000 	adds	x0, x0, x20
    3668:	540006e2 	b.cs	3744 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    366c:	f94a1661 	ldr	x1, [x19, #5160]
    3670:	f90a1260 	str	x0, [x19, #5152]
    3674:	eb01001f 	cmp	x0, x1
    3678:	54000049 	b.ls	3680 <fwp_heap_alloc+0xbc>  // b.plast
    367c:	f90a1660 	str	x0, [x19, #5160]
    3680:	911582e0 	add	x0, x23, #0x560
    3684:	1e6302a1 	ucvtf	d1, w21
    3688:	fd4a1c00 	ldr	d0, [x0, #5176]
    368c:	1e612800 	fadd	d0, d0, d1
    3690:	fd0a1c00 	str	d0, [x0, #5176]
    3694:	34000138 	cbz	w24, 36b8 <fwp_heap_alloc+0xf4>
    3698:	911582e1 	add	x1, x23, #0x560
    369c:	910202c0 	add	x0, x22, #0x80
    36a0:	fd4a1020 	ldr	d0, [x1, #5152]
    36a4:	6d458402 	ldp	d2, d1, [x0, #88]
    36a8:	7e61d800 	ucvtf	d0, d0
    36ac:	1e623800 	fsub	d0, d0, d2
    36b0:	1e612010 	fcmpe	d0, d1
    36b4:	540002cc 	b.gt	370c <fwp_heap_alloc+0x148>
    36b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36bc:	aa0403e0 	mov	x0, x4
    36c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    36c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    36c8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    36cc:	d65f03c0 	ret
    36d0:	8b030263 	add	x3, x19, x3
    36d4:	f9400464 	ldr	x4, [x3, #8]
    36d8:	b40000a4 	cbz	x4, 36ec <fwp_heap_alloc+0x128>
    36dc:	f9400862 	ldr	x2, [x3, #16]
    36e0:	cb040042 	sub	x2, x2, x4
    36e4:	eb02029f 	cmp	x20, x2
    36e8:	54000209 	b.ls	3728 <fwp_heap_alloc+0x164>  // b.plast
    36ec:	97ffff0d 	bl	3320 <fwp_heap_alloc_slow>
    36f0:	aa0003e4 	mov	x4, x0
    36f4:	17ffffe8 	b	3694 <fwp_heap_alloc+0xd0>
    36f8:	a9448c44 	ldp	x4, x3, [x2, #72]
    36fc:	91000484 	add	x4, x4, #0x1
    3700:	8b000063 	add	x3, x3, x0
    3704:	a9048c44 	stp	x4, x3, [x2, #72]
    3708:	17ffffba 	b	35f0 <fwp_heap_alloc+0x2c>
    370c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3710:	fd003000 	str	d0, [x0, #96]
    3714:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3718:	aa0403e0 	mov	x0, x4
    371c:	a94363f7 	ldp	x23, x24, [sp, #48]
    3720:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3724:	d65f03c0 	ret
    3728:	7100043f 	cmp	w1, #0x1
    372c:	8b140085 	add	x5, x4, x20
    3730:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3734:	52800001 	mov	w1, #0x0                   	// #0
    3738:	aa0403e0 	mov	x0, x4
    373c:	f9000465 	str	x5, [x3, #8]
    3740:	17ffffc6 	b	3658 <fwp_heap_alloc+0x94>
    3744:	97fff963 	bl	1cd0 <fwp_heap_oom>
    3748:	d503201f 	nop
    374c:	d503201f 	nop

0000000000003750 <fwp_data.part.0.constprop.0>:
    3750:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3754:	910003fd 	mov	x29, sp
    3758:	a9025bf5 	stp	x21, x22, [sp, #32]
    375c:	b00000f6 	adrp	x22, 20000 <__data_start>
    3760:	910202c1 	add	x1, x22, #0x80
    3764:	a90363f7 	stp	x23, x24, [sp, #48]
    3768:	b9404038 	ldr	w24, [x1, #64]
    376c:	a90153f3 	stp	x19, x20, [sp, #16]
    3770:	aa0003f4 	mov	x20, x0
    3774:	340000b8 	cbz	w24, 3788 <fwp_data.part.0.constprop.0+0x38>
    3778:	a9448022 	ldp	x2, x0, [x1, #72]
    377c:	91000442 	add	x2, x2, #0x1
    3780:	91006000 	add	x0, x0, #0x18
    3784:	a9048022 	stp	x2, x0, [x1, #72]
    3788:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    378c:	911582a2 	add	x2, x21, #0x560
    3790:	b953a440 	ldr	w0, [x2, #5028]
    3794:	34000840 	cbz	w0, 389c <fwp_data.part.0.constprop.0+0x14c>
    3798:	f90023f9 	str	x25, [sp, #64]
    379c:	397e8841 	ldrb	w1, [x2, #4002]
    37a0:	910f0020 	add	x0, x1, #0x3c0
    37a4:	8b010421 	add	x1, x1, x1, lsl #1
    37a8:	d37df021 	lsl	x1, x1, #3
    37ac:	b8607859 	ldr	w25, [x2, x0, lsl #2]
    37b0:	2a1903f7 	mov	w23, w25
    37b4:	f8616853 	ldr	x19, [x2, x1]
    37b8:	b4000633 	cbz	x19, 387c <fwp_data.part.0.constprop.0+0x12c>
    37bc:	f9400260 	ldr	x0, [x19]
    37c0:	aa2003e0 	mvn	x0, x0
    37c4:	f8216840 	str	x0, [x2, x1]
    37c8:	f10062ff 	cmp	x23, #0x18
    37cc:	540000e9 	b.ls	37e8 <fwp_data.part.0.constprop.0+0x98>  // b.plast
    37d0:	d10066e2 	sub	x2, x23, #0x19
    37d4:	91006260 	add	x0, x19, #0x18
    37d8:	927df042 	and	x2, x2, #0xfffffffffffffff8
    37dc:	52800001 	mov	w1, #0x0                   	// #0
    37e0:	91002042 	add	x2, x2, #0x8
    37e4:	97fff73b 	bl	14d0 <memset@plt>
    37e8:	911582a1 	add	x1, x21, #0x560
    37ec:	f94a1020 	ldr	x0, [x1, #5152]
    37f0:	ab170000 	adds	x0, x0, x23
    37f4:	54000682 	b.cs	38c4 <fwp_data.part.0.constprop.0+0x174>  // b.hs, b.nlast
    37f8:	f94a1422 	ldr	x2, [x1, #5160]
    37fc:	f90a1020 	str	x0, [x1, #5152]
    3800:	eb02001f 	cmp	x0, x2
    3804:	54000049 	b.ls	380c <fwp_data.part.0.constprop.0+0xbc>  // b.plast
    3808:	f90a1420 	str	x0, [x1, #5160]
    380c:	911582a0 	add	x0, x21, #0x560
    3810:	1e630321 	ucvtf	d1, w25
    3814:	f94023f9 	ldr	x25, [sp, #64]
    3818:	fd4a1c00 	ldr	d0, [x0, #5176]
    381c:	1e612800 	fadd	d0, d0, d1
    3820:	fd0a1c00 	str	d0, [x0, #5176]
    3824:	34000138 	cbz	w24, 3848 <fwp_data.part.0.constprop.0+0xf8>
    3828:	911582b5 	add	x21, x21, #0x560
    382c:	910202d6 	add	x22, x22, #0x80
    3830:	fd4a12a0 	ldr	d0, [x21, #5152]
    3834:	6d4586c2 	ldp	d2, d1, [x22, #88]
    3838:	7e61d800 	ucvtf	d0, d0
    383c:	1e623800 	fsub	d0, d0, d2
    3840:	1e612010 	fcmpe	d0, d1
    3844:	5400036c 	b.gt	38b0 <fwp_data.part.0.constprop.0+0x160>
    3848:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    384c:	fd427800 	ldr	d0, [x0, #1264]
    3850:	aa1303e0 	mov	x0, x19
    3854:	fd000260 	str	d0, [x19]
    3858:	f9400281 	ldr	x1, [x20]
    385c:	f9000661 	str	x1, [x19, #8]
    3860:	f9400681 	ldr	x1, [x20, #8]
    3864:	f9000a61 	str	x1, [x19, #16]
    3868:	a94153f3 	ldp	x19, x20, [sp, #16]
    386c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3870:	a94363f7 	ldp	x23, x24, [sp, #48]
    3874:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3878:	d65f03c0 	ret
    387c:	8b010042 	add	x2, x2, x1
    3880:	f9400453 	ldr	x19, [x2, #8]
    3884:	b40000b3 	cbz	x19, 3898 <fwp_data.part.0.constprop.0+0x148>
    3888:	f9400840 	ldr	x0, [x2, #16]
    388c:	cb130000 	sub	x0, x0, x19
    3890:	eb0002ff 	cmp	x23, x0
    3894:	54000129 	b.ls	38b8 <fwp_data.part.0.constprop.0+0x168>  // b.plast
    3898:	f94023f9 	ldr	x25, [sp, #64]
    389c:	52800001 	mov	w1, #0x0                   	// #0
    38a0:	d2800300 	mov	x0, #0x18                  	// #24
    38a4:	97ffff48 	bl	35c4 <fwp_heap_alloc>
    38a8:	aa0003f3 	mov	x19, x0
    38ac:	17ffffde 	b	3824 <fwp_data.part.0.constprop.0+0xd4>
    38b0:	fd0032c0 	str	d0, [x22, #96]
    38b4:	17ffffe5 	b	3848 <fwp_data.part.0.constprop.0+0xf8>
    38b8:	8b170260 	add	x0, x19, x23
    38bc:	f9000440 	str	x0, [x2, #8]
    38c0:	17ffffc2 	b	37c8 <fwp_data.part.0.constprop.0+0x78>
    38c4:	97fff903 	bl	1cd0 <fwp_heap_oom>
    38c8:	d503201f 	nop
    38cc:	d503201f 	nop

00000000000038d0 <fwp_array_new_packed.constprop.0>:
    38d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    38d4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    38d8:	910003fd 	mov	x29, sp
    38dc:	f9000bf3 	str	x19, [sp, #16]
    38e0:	eb01001f 	cmp	x0, x1
    38e4:	54000148 	b.hi	390c <fwp_array_new_packed.constprop.0+0x3c>  // b.pmore
    38e8:	aa0003f3 	mov	x19, x0
    38ec:	91000400 	add	x0, x0, #0x1
    38f0:	52800021 	mov	w1, #0x1                   	// #1
    38f4:	d37df000 	lsl	x0, x0, #3
    38f8:	97ffff33 	bl	35c4 <fwp_heap_alloc>
    38fc:	f9000013 	str	x19, [x0]
    3900:	f9400bf3 	ldr	x19, [sp, #16]
    3904:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3908:	d65f03c0 	ret
    390c:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    3910:	9103c000 	add	x0, x0, #0xf0
    3914:	97fffa5b 	bl	2280 <fwp_trap>
    3918:	d503201f 	nop
    391c:	d503201f 	nop

0000000000003920 <fwp_drop1>:
    3920:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3924:	910003fd 	mov	x29, sp
    3928:	a90153f3 	stp	x19, x20, [sp, #16]
    392c:	f90013f5 	str	x21, [sp, #32]
    3930:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    3934:	911582b4 	add	x20, x21, #0x560
    3938:	f949da81 	ldr	x1, [x20, #5040]
    393c:	f949ee82 	ldr	x2, [x20, #5080]
    3940:	cb010001 	sub	x1, x0, x1
    3944:	eb02403f 	cmp	x1, x2, lsl #16
    3948:	54000382 	b.cs	39b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    394c:	d350fc22 	lsr	x2, x1, #16
    3950:	f949fe84 	ldr	x4, [x20, #5112]
    3954:	8b020842 	add	x2, x2, x2, lsl #2
    3958:	d37df042 	lsl	x2, x2, #3
    395c:	8b020083 	add	x3, x4, x2
    3960:	f9401073 	ldr	x19, [x3, #32]
    3964:	b40002b3 	cbz	x19, 39b8 <fwp_drop1+0x98>
    3968:	38626882 	ldrb	w2, [x4, x2]
    396c:	7100085f 	cmp	w2, #0x2
    3970:	540002c0 	b.eq	39c8 <fwp_drop1+0xa8>  // b.none
    3974:	7100045f 	cmp	w2, #0x1
    3978:	54000201 	b.ne	39b8 <fwp_drop1+0x98>  // b.any
    397c:	29430864 	ldp	w4, w2, [x3, #24]
    3980:	92403c21 	and	x1, x1, #0xffff
    3984:	9b047c21 	mul	x1, x1, x4
    3988:	d360fc21 	lsr	x1, x1, #32
    398c:	eb02003f 	cmp	x1, x2
    3990:	54000142 	b.cs	39b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    3994:	8b010273 	add	x19, x19, x1
    3998:	39400261 	ldrb	w1, [x19]
    399c:	340000e1 	cbz	w1, 39b8 <fwp_drop1+0x98>
    39a0:	7100043f 	cmp	w1, #0x1
    39a4:	540001e0 	b.eq	39e0 <fwp_drop1+0xc0>  // b.none
    39a8:	7103fc3f 	cmp	w1, #0xff
    39ac:	540002e0 	b.eq	3a08 <fwp_drop1+0xe8>  // b.none
    39b0:	51000421 	sub	w1, w1, #0x1
    39b4:	39000261 	strb	w1, [x19]
    39b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39bc:	f94013f5 	ldr	x21, [sp, #32]
    39c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    39c4:	d65f03c0 	ret
    39c8:	72003c3f 	tst	w1, #0xffff
    39cc:	54fffe60 	b.eq	3998 <fwp_drop1+0x78>  // b.none
    39d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    39d4:	f94013f5 	ldr	x21, [sp, #32]
    39d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    39dc:	d65f03c0 	ret
    39e0:	f9400813 	ldr	x19, [x0, #16]
    39e4:	97fffed7 	bl	3540 <fwp_rc_free_arr>
    39e8:	911582a0 	add	x0, x21, #0x560
    39ec:	f949d801 	ldr	x1, [x0, #5040]
    39f0:	f949ec00 	ldr	x0, [x0, #5080]
    39f4:	cb010261 	sub	x1, x19, x1
    39f8:	eb00403f 	cmp	x1, x0, lsl #16
    39fc:	54fffde2 	b.cs	39b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    3a00:	aa1303e0 	mov	x0, x19
    3a04:	17ffffd2 	b	394c <fwp_drop1+0x2c>
    3a08:	ca534660 	eor	x0, x19, x19, lsr #17
    3a0c:	911582b5 	add	x21, x21, #0x560
    3a10:	ca402400 	eor	x0, x0, x0, lsr #9
    3a14:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3a18:	f94a2400 	ldr	x0, [x0, #5192]
    3a1c:	b5000080 	cbnz	x0, 3a2c <fwp_drop1+0x10c>
    3a20:	14000010 	b	3a60 <fwp_drop1+0x140>
    3a24:	f9400800 	ldr	x0, [x0, #16]
    3a28:	b40001c0 	cbz	x0, 3a60 <fwp_drop1+0x140>
    3a2c:	f9400001 	ldr	x1, [x0]
    3a30:	eb13003f 	cmp	x1, x19
    3a34:	54ffff81 	b.ne	3a24 <fwp_drop1+0x104>  // b.any
    3a38:	f9400401 	ldr	x1, [x0, #8]
    3a3c:	d1000421 	sub	x1, x1, #0x1
    3a40:	f9000401 	str	x1, [x0, #8]
    3a44:	f103f83f 	cmp	x1, #0xfe
    3a48:	54fffb81 	b.ne	39b8 <fwp_drop1+0x98>  // b.any
    3a4c:	aa1303e0 	mov	x0, x19
    3a50:	97fffccd 	bl	2d84 <fwp_rc_forget_slot>
    3a54:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3a58:	39000260 	strb	w0, [x19]
    3a5c:	17ffffd7 	b	39b8 <fwp_drop1+0x98>
    3a60:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    3a64:	91032000 	add	x0, x0, #0xc8
    3a68:	97fffa06 	bl	2280 <fwp_trap>
    3a6c:	d503201f 	nop

0000000000003a70 <fwp_drop0>:
    3a70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a74:	910003fd 	mov	x29, sp
    3a78:	a90153f3 	stp	x19, x20, [sp, #16]
    3a7c:	f90013f5 	str	x21, [sp, #32]
    3a80:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    3a84:	911582b4 	add	x20, x21, #0x560
    3a88:	f949da81 	ldr	x1, [x20, #5040]
    3a8c:	f949ee82 	ldr	x2, [x20, #5080]
    3a90:	cb010001 	sub	x1, x0, x1
    3a94:	eb02403f 	cmp	x1, x2, lsl #16
    3a98:	54000382 	b.cs	3b08 <fwp_drop0+0x98>  // b.hs, b.nlast
    3a9c:	d350fc22 	lsr	x2, x1, #16
    3aa0:	f949fe84 	ldr	x4, [x20, #5112]
    3aa4:	8b020842 	add	x2, x2, x2, lsl #2
    3aa8:	d37df042 	lsl	x2, x2, #3
    3aac:	8b020083 	add	x3, x4, x2
    3ab0:	f9401073 	ldr	x19, [x3, #32]
    3ab4:	b40002b3 	cbz	x19, 3b08 <fwp_drop0+0x98>
    3ab8:	38626882 	ldrb	w2, [x4, x2]
    3abc:	7100085f 	cmp	w2, #0x2
    3ac0:	540002c0 	b.eq	3b18 <fwp_drop0+0xa8>  // b.none
    3ac4:	7100045f 	cmp	w2, #0x1
    3ac8:	54000201 	b.ne	3b08 <fwp_drop0+0x98>  // b.any
    3acc:	29430864 	ldp	w4, w2, [x3, #24]
    3ad0:	92403c21 	and	x1, x1, #0xffff
    3ad4:	9b047c21 	mul	x1, x1, x4
    3ad8:	d360fc21 	lsr	x1, x1, #32
    3adc:	eb02003f 	cmp	x1, x2
    3ae0:	54000142 	b.cs	3b08 <fwp_drop0+0x98>  // b.hs, b.nlast
    3ae4:	8b010273 	add	x19, x19, x1
    3ae8:	39400261 	ldrb	w1, [x19]
    3aec:	340000e1 	cbz	w1, 3b08 <fwp_drop0+0x98>
    3af0:	7100043f 	cmp	w1, #0x1
    3af4:	540001e0 	b.eq	3b30 <fwp_drop0+0xc0>  // b.none
    3af8:	7103fc3f 	cmp	w1, #0xff
    3afc:	540002e0 	b.eq	3b58 <fwp_drop0+0xe8>  // b.none
    3b00:	51000421 	sub	w1, w1, #0x1
    3b04:	39000261 	strb	w1, [x19]
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	f94013f5 	ldr	x21, [sp, #32]
    3b10:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b14:	d65f03c0 	ret
    3b18:	72003c3f 	tst	w1, #0xffff
    3b1c:	54fffe60 	b.eq	3ae8 <fwp_drop0+0x78>  // b.none
    3b20:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b24:	f94013f5 	ldr	x21, [sp, #32]
    3b28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b2c:	d65f03c0 	ret
    3b30:	f9400813 	ldr	x19, [x0, #16]
    3b34:	97fffe83 	bl	3540 <fwp_rc_free_arr>
    3b38:	911582a0 	add	x0, x21, #0x560
    3b3c:	f949d801 	ldr	x1, [x0, #5040]
    3b40:	f949ec00 	ldr	x0, [x0, #5080]
    3b44:	cb010261 	sub	x1, x19, x1
    3b48:	eb00403f 	cmp	x1, x0, lsl #16
    3b4c:	54fffde2 	b.cs	3b08 <fwp_drop0+0x98>  // b.hs, b.nlast
    3b50:	aa1303e0 	mov	x0, x19
    3b54:	17ffffd2 	b	3a9c <fwp_drop0+0x2c>
    3b58:	ca534660 	eor	x0, x19, x19, lsr #17
    3b5c:	911582b5 	add	x21, x21, #0x560
    3b60:	ca402400 	eor	x0, x0, x0, lsr #9
    3b64:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3b68:	f94a2400 	ldr	x0, [x0, #5192]
    3b6c:	b5000080 	cbnz	x0, 3b7c <fwp_drop0+0x10c>
    3b70:	14000010 	b	3bb0 <fwp_drop0+0x140>
    3b74:	f9400800 	ldr	x0, [x0, #16]
    3b78:	b40001c0 	cbz	x0, 3bb0 <fwp_drop0+0x140>
    3b7c:	f9400001 	ldr	x1, [x0]
    3b80:	eb13003f 	cmp	x1, x19
    3b84:	54ffff81 	b.ne	3b74 <fwp_drop0+0x104>  // b.any
    3b88:	f9400401 	ldr	x1, [x0, #8]
    3b8c:	d1000421 	sub	x1, x1, #0x1
    3b90:	f9000401 	str	x1, [x0, #8]
    3b94:	f103f83f 	cmp	x1, #0xfe
    3b98:	54fffb81 	b.ne	3b08 <fwp_drop0+0x98>  // b.any
    3b9c:	aa1303e0 	mov	x0, x19
    3ba0:	97fffc79 	bl	2d84 <fwp_rc_forget_slot>
    3ba4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3ba8:	39000260 	strb	w0, [x19]
    3bac:	17ffffd7 	b	3b08 <fwp_drop0+0x98>
    3bb0:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    3bb4:	91032000 	add	x0, x0, #0xc8
    3bb8:	97fff9b2 	bl	2280 <fwp_trap>
    3bbc:	d503201f 	nop

0000000000003bc0 <fwp_task_dispose>:
    3bc0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3bc4:	910003fd 	mov	x29, sp
    3bc8:	f9000bf3 	str	x19, [sp, #16]
    3bcc:	aa0003f3 	mov	x19, x0
    3bd0:	39414000 	ldrb	w0, [x0, #80]
    3bd4:	36000720 	tbz	w0, #0, 3cb8 <fwp_task_dispose+0xf8>
    3bd8:	f9400a60 	ldr	x0, [x19, #16]
    3bdc:	b50006e0 	cbnz	x0, 3cb8 <fwp_task_dispose+0xf8>
    3be0:	a9478660 	ldp	x0, x1, [x19, #120]
    3be4:	39014e7f 	strb	wzr, [x19, #83]
    3be8:	f9003e7f 	str	xzr, [x19, #120]
    3bec:	f100003f 	cmp	x1, #0x0
    3bf0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3bf4:	54000040 	b.eq	3bfc <fwp_task_dispose+0x3c>  // b.none
    3bf8:	d63f0020 	blr	x1
    3bfc:	f9405660 	ldr	x0, [x19, #168]
    3c00:	97fffd00 	bl	3000 <fwp_mem_free>
    3c04:	f900567f 	str	xzr, [x19, #168]
    3c08:	b9405e60 	ldr	w0, [x19, #92]
    3c0c:	7100041f 	cmp	w0, #0x1
    3c10:	54000420 	b.eq	3c94 <fwp_task_dispose+0xd4>  // b.none
    3c14:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc80>
    3c18:	91158042 	add	x2, x2, #0x560
    3c1c:	f949d840 	ldr	x0, [x2, #5040]
    3c20:	f949ec41 	ldr	x1, [x2, #5080]
    3c24:	cb000260 	sub	x0, x19, x0
    3c28:	eb01401f 	cmp	x0, x1, lsl #16
    3c2c:	540002e2 	b.cs	3c88 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3c30:	d350fc01 	lsr	x1, x0, #16
    3c34:	f949fc44 	ldr	x4, [x2, #5112]
    3c38:	8b010821 	add	x1, x1, x1, lsl #2
    3c3c:	d37df021 	lsl	x1, x1, #3
    3c40:	8b010083 	add	x3, x4, x1
    3c44:	f9401062 	ldr	x2, [x3, #32]
    3c48:	b4000202 	cbz	x2, 3c88 <fwp_task_dispose+0xc8>
    3c4c:	38616881 	ldrb	w1, [x4, x1]
    3c50:	7100083f 	cmp	w1, #0x2
    3c54:	54000280 	b.eq	3ca4 <fwp_task_dispose+0xe4>  // b.none
    3c58:	7100043f 	cmp	w1, #0x1
    3c5c:	54000161 	b.ne	3c88 <fwp_task_dispose+0xc8>  // b.any
    3c60:	29430464 	ldp	w4, w1, [x3, #24]
    3c64:	92403c00 	and	x0, x0, #0xffff
    3c68:	9b047c00 	mul	x0, x0, x4
    3c6c:	d360fc00 	lsr	x0, x0, #32
    3c70:	eb01001f 	cmp	x0, x1
    3c74:	540000a2 	b.cs	3c88 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3c78:	8b000042 	add	x2, x2, x0
    3c7c:	39400040 	ldrb	w0, [x2]
    3c80:	7100041f 	cmp	w0, #0x1
    3c84:	54000080 	b.eq	3c94 <fwp_task_dispose+0xd4>  // b.none
    3c88:	f9400bf3 	ldr	x19, [sp, #16]
    3c8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c90:	d65f03c0 	ret
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	f9400bf3 	ldr	x19, [sp, #16]
    3c9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3ca0:	17fffcd8 	b	3000 <fwp_mem_free>
    3ca4:	72003c1f 	tst	w0, #0xffff
    3ca8:	54fffea0 	b.eq	3c7c <fwp_task_dispose+0xbc>  // b.none
    3cac:	f9400bf3 	ldr	x19, [sp, #16]
    3cb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3cb4:	d65f03c0 	ret
    3cb8:	97fff626 	bl	1550 <abort@plt>
    3cbc:	d503201f 	nop

0000000000003cc0 <fwp_free_zombie>:
    3cc0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3cc4:	910003fd 	mov	x29, sp
    3cc8:	a90153f3 	stp	x19, x20, [sp, #16]
    3ccc:	b00000f4 	adrp	x20, 20000 <__data_start>
    3cd0:	91020281 	add	x1, x20, #0x80
    3cd4:	f9403433 	ldr	x19, [x1, #104]
    3cd8:	b4000333 	cbz	x19, 3d3c <fwp_free_zombie+0x7c>
    3cdc:	f9400420 	ldr	x0, [x1, #8]
    3ce0:	eb00027f 	cmp	x19, x0
    3ce4:	540002c0 	b.eq	3d3c <fwp_free_zombie+0x7c>  // b.none
    3ce8:	b9407022 	ldr	w2, [x1, #112]
    3cec:	f9400a60 	ldr	x0, [x19, #16]
    3cf0:	7100fc5f 	cmp	w2, #0x3f
    3cf4:	5400078c 	b.gt	3de4 <fwp_free_zombie+0x124>
    3cf8:	91020023 	add	x3, x1, #0x80
    3cfc:	11000444 	add	w4, w2, #0x1
    3d00:	b9007024 	str	w4, [x1, #112]
    3d04:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3d08:	f822d860 	str	x0, [x3, w2, sxtw #3]
    3d0c:	a9530261 	ldp	x1, x0, [x19, #304]
    3d10:	b4000741 	cbz	x1, 3df8 <fwp_free_zombie+0x138>
    3d14:	f9009c20 	str	x0, [x1, #312]
    3d18:	b4000040 	cbz	x0, 3d20 <fwp_free_zombie+0x60>
    3d1c:	f9009801 	str	x1, [x0, #304]
    3d20:	91020294 	add	x20, x20, #0x80
    3d24:	b9405e60 	ldr	w0, [x19, #92]
    3d28:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    3d2c:	f900369f 	str	xzr, [x20, #104]
    3d30:	34000140 	cbz	w0, 3d58 <fwp_free_zombie+0x98>
    3d34:	7100041f 	cmp	w0, #0x1
    3d38:	54000080 	b.eq	3d48 <fwp_free_zombie+0x88>  // b.none
    3d3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3d44:	d65f03c0 	ret
    3d48:	aa1303e0 	mov	x0, x19
    3d4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3d54:	17ffff9b 	b	3bc0 <fwp_task_dispose>
    3d58:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xc80>
    3d5c:	91158082 	add	x2, x4, #0x560
    3d60:	f949d841 	ldr	x1, [x2, #5040]
    3d64:	f949ec40 	ldr	x0, [x2, #5080]
    3d68:	cb010261 	sub	x1, x19, x1
    3d6c:	eb00403f 	cmp	x1, x0, lsl #16
    3d70:	54fffe62 	b.cs	3d3c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3d74:	d350fc20 	lsr	x0, x1, #16
    3d78:	f949fc43 	ldr	x3, [x2, #5112]
    3d7c:	8b000800 	add	x0, x0, x0, lsl #2
    3d80:	d37df000 	lsl	x0, x0, #3
    3d84:	8b000062 	add	x2, x3, x0
    3d88:	f9401054 	ldr	x20, [x2, #32]
    3d8c:	b4fffd94 	cbz	x20, 3d3c <fwp_free_zombie+0x7c>
    3d90:	38606860 	ldrb	w0, [x3, x0]
    3d94:	7100081f 	cmp	w0, #0x2
    3d98:	54000360 	b.eq	3e04 <fwp_free_zombie+0x144>  // b.none
    3d9c:	7100041f 	cmp	w0, #0x1
    3da0:	54fffce1 	b.ne	3d3c <fwp_free_zombie+0x7c>  // b.any
    3da4:	29430043 	ldp	w3, w0, [x2, #24]
    3da8:	92403c21 	and	x1, x1, #0xffff
    3dac:	9b037c21 	mul	x1, x1, x3
    3db0:	d360fc21 	lsr	x1, x1, #32
    3db4:	eb00003f 	cmp	x1, x0
    3db8:	54fffc22 	b.cs	3d3c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3dbc:	8b010294 	add	x20, x20, x1
    3dc0:	39400280 	ldrb	w0, [x20]
    3dc4:	34fffbc0 	cbz	w0, 3d3c <fwp_free_zombie+0x7c>
    3dc8:	7100041f 	cmp	w0, #0x1
    3dcc:	54fffbe0 	b.eq	3d48 <fwp_free_zombie+0x88>  // b.none
    3dd0:	7103fc1f 	cmp	w0, #0xff
    3dd4:	540001e0 	b.eq	3e10 <fwp_free_zombie+0x150>  // b.none
    3dd8:	51000400 	sub	w0, w0, #0x1
    3ddc:	39000280 	strb	w0, [x20]
    3de0:	17ffffd7 	b	3d3c <fwp_free_zombie+0x7c>
    3de4:	f9400e61 	ldr	x1, [x19, #24]
    3de8:	97fff60e 	bl	1620 <munmap@plt>
    3dec:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3df0:	a9530261 	ldp	x1, x0, [x19, #304]
    3df4:	b5fff901 	cbnz	x1, 3d14 <fwp_free_zombie+0x54>
    3df8:	91020282 	add	x2, x20, #0x80
    3dfc:	f9014040 	str	x0, [x2, #640]
    3e00:	17ffffc6 	b	3d18 <fwp_free_zombie+0x58>
    3e04:	72003c3f 	tst	w1, #0xffff
    3e08:	54fff9a1 	b.ne	3d3c <fwp_free_zombie+0x7c>  // b.any
    3e0c:	17ffffed 	b	3dc0 <fwp_free_zombie+0x100>
    3e10:	ca544680 	eor	x0, x20, x20, lsr #17
    3e14:	91158084 	add	x4, x4, #0x560
    3e18:	ca402400 	eor	x0, x0, x0, lsr #9
    3e1c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3e20:	f94a2400 	ldr	x0, [x0, #5192]
    3e24:	b5000080 	cbnz	x0, 3e34 <fwp_free_zombie+0x174>
    3e28:	14000010 	b	3e68 <fwp_free_zombie+0x1a8>
    3e2c:	f9400800 	ldr	x0, [x0, #16]
    3e30:	b40001c0 	cbz	x0, 3e68 <fwp_free_zombie+0x1a8>
    3e34:	f9400001 	ldr	x1, [x0]
    3e38:	eb14003f 	cmp	x1, x20
    3e3c:	54ffff81 	b.ne	3e2c <fwp_free_zombie+0x16c>  // b.any
    3e40:	f9400401 	ldr	x1, [x0, #8]
    3e44:	d1000421 	sub	x1, x1, #0x1
    3e48:	f9000401 	str	x1, [x0, #8]
    3e4c:	f103f83f 	cmp	x1, #0xfe
    3e50:	54fff761 	b.ne	3d3c <fwp_free_zombie+0x7c>  // b.any
    3e54:	aa1403e0 	mov	x0, x20
    3e58:	97fffbcb 	bl	2d84 <fwp_rc_forget_slot>
    3e5c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3e60:	39000280 	strb	w0, [x20]
    3e64:	17ffffb6 	b	3d3c <fwp_free_zombie+0x7c>
    3e68:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    3e6c:	91032000 	add	x0, x0, #0xc8
    3e70:	97fff904 	bl	2280 <fwp_trap>

0000000000003e74 <fwp_block>:
    3e74:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e78:	910003fd 	mov	x29, sp
    3e7c:	a90153f3 	stp	x19, x20, [sp, #16]
    3e80:	b00000f3 	adrp	x19, 20000 <__data_start>
    3e84:	91020274 	add	x20, x19, #0x80
    3e88:	f9401a82 	ldr	x2, [x20, #48]
    3e8c:	b4000622 	cbz	x2, 3f50 <fwp_block+0xdc>
    3e90:	91020261 	add	x1, x19, #0x80
    3e94:	f9408040 	ldr	x0, [x2, #256]
    3e98:	f9001820 	str	x0, [x1, #48]
    3e9c:	b4000680 	cbz	x0, 3f6c <fwp_block+0xf8>
    3ea0:	91020263 	add	x3, x19, #0x80
    3ea4:	3901505f 	strb	wzr, [x2, #84]
    3ea8:	f9400464 	ldr	x4, [x3, #8]
    3eac:	eb02009f 	cmp	x4, x2
    3eb0:	54000440 	b.eq	3f38 <fwp_block+0xc4>  // b.none
    3eb4:	f9414465 	ldr	x5, [x3, #648]
    3eb8:	f9000462 	str	x2, [x3, #8]
    3ebc:	f9400441 	ldr	x1, [x2, #8]
    3ec0:	f9004885 	str	x5, [x4, #144]
    3ec4:	f9414865 	ldr	x5, [x3, #656]
    3ec8:	f9004c85 	str	x5, [x4, #152]
    3ecc:	f9414c65 	ldr	x5, [x3, #664]
    3ed0:	f9005085 	str	x5, [x4, #160]
    3ed4:	f9415065 	ldr	x5, [x3, #672]
    3ed8:	f9005485 	str	x5, [x4, #168]
    3edc:	f9415465 	ldr	x5, [x3, #680]
    3ee0:	f9005885 	str	x5, [x4, #176]
    3ee4:	f9415865 	ldr	x5, [x3, #688]
    3ee8:	f9005c85 	str	x5, [x4, #184]
    3eec:	f9415c65 	ldr	x5, [x3, #696]
    3ef0:	f9006085 	str	x5, [x4, #192]
    3ef4:	f9400480 	ldr	x0, [x4, #8]
    3ef8:	f9404844 	ldr	x4, [x2, #144]
    3efc:	f9014464 	str	x4, [x3, #648]
    3f00:	f9404c44 	ldr	x4, [x2, #152]
    3f04:	f9014864 	str	x4, [x3, #656]
    3f08:	f9405044 	ldr	x4, [x2, #160]
    3f0c:	f9014c64 	str	x4, [x3, #664]
    3f10:	f9405444 	ldr	x4, [x2, #168]
    3f14:	f9015064 	str	x4, [x3, #672]
    3f18:	f9405844 	ldr	x4, [x2, #176]
    3f1c:	f9015464 	str	x4, [x3, #680]
    3f20:	a94b8844 	ldp	x4, x2, [x2, #184]
    3f24:	f9015864 	str	x4, [x3, #688]
    3f28:	f9015c62 	str	x2, [x3, #696]
    3f2c:	97fff58d 	bl	1560 <swapcontext@plt>
    3f30:	97ffff64 	bl	3cc0 <fwp_free_zombie>
    3f34:	d503201f 	nop
    3f38:	91020260 	add	x0, x19, #0x80
    3f3c:	b942c000 	ldr	w0, [x0, #704]
    3f40:	340001a0 	cbz	w0, 3f74 <fwp_block+0x100>
    3f44:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f48:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f4c:	d65f03c0 	ret
    3f50:	97fffb00 	bl	2b50 <fwp_poll_events>
    3f54:	f9401a82 	ldr	x2, [x20, #48]
    3f58:	b4ffffc2 	cbz	x2, 3f50 <fwp_block+0xdc>
    3f5c:	91020261 	add	x1, x19, #0x80
    3f60:	f9408040 	ldr	x0, [x2, #256]
    3f64:	f9001820 	str	x0, [x1, #48]
    3f68:	b5fff9c0 	cbnz	x0, 3ea0 <fwp_block+0x2c>
    3f6c:	f900143f 	str	xzr, [x1, #40]
    3f70:	17ffffcc 	b	3ea0 <fwp_block+0x2c>
    3f74:	d0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    3f78:	91040000 	add	x0, x0, #0x100
    3f7c:	97fff5c5 	bl	1690 <getenv@plt>
    3f80:	5284e202 	mov	w2, #0x2710                	// #10000
    3f84:	b4000060 	cbz	x0, 3f90 <fwp_block+0x11c>
    3f88:	39400001 	ldrb	w1, [x0]
    3f8c:	350000c1 	cbnz	w1, 3fa4 <fwp_block+0x130>
    3f90:	91020273 	add	x19, x19, #0x80
    3f94:	b902c262 	str	w2, [x19, #704]
    3f98:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3fa0:	d65f03c0 	ret
    3fa4:	52800142 	mov	w2, #0xa                   	// #10
    3fa8:	d2800001 	mov	x1, #0x0                   	// #0
    3fac:	97fff509 	bl	13d0 <strtoll@plt>
    3fb0:	d1000403 	sub	x3, x0, #0x1
    3fb4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3fb8:	eb02007f 	cmp	x3, x2
    3fbc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3fc0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3fc4:	17fffff3 	b	3f90 <fwp_block+0x11c>
    3fc8:	d503201f 	nop
    3fcc:	d503201f 	nop

0000000000003fd0 <fwp_write.constprop.0>:
    3fd0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3fd4:	910003fd 	mov	x29, sp
    3fd8:	900000e3 	adrp	x3, 1f000 <__FRAME_END__+0x14da0>
    3fdc:	f947f463 	ldr	x3, [x3, #4072]
    3fe0:	a90153f3 	stp	x19, x20, [sp, #16]
    3fe4:	d10943ff 	sub	sp, sp, #0x250
    3fe8:	aa0003f4 	mov	x20, x0
    3fec:	b9400040 	ldr	w0, [x2]
    3ff0:	aa0103f3 	mov	x19, x1
    3ff4:	f9400061 	ldr	x1, [x3]
    3ff8:	f90127e1 	str	x1, [sp, #584]
    3ffc:	d2800001 	mov	x1, #0x0                   	// #0
    4000:	7100641f 	cmp	w0, #0x19
    4004:	540003e8 	b.hi	4080 <fwp_write.constprop.0+0xb0>  // b.pmore
    4008:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    400c:	91120021 	add	x1, x1, #0x480
    4010:	f9013bf5 	str	x21, [sp, #624]
    4014:	f9013ff6 	str	x22, [sp, #632]
    4018:	f90153fb 	str	x27, [sp, #672]
    401c:	f90157fc 	str	x28, [sp, #680]
    4020:	aa0203fc 	mov	x28, x2
    4024:	78605821 	ldrh	w1, [x1, w0, uxtw #1]
    4028:	10000062 	adr	x2, 4034 <fwp_write.constprop.0+0x64>
    402c:	8b21a841 	add	x1, x2, w1, sxth #2
    4030:	d61f0020 	br	x1
    4034:	910123e0 	add	x0, sp, #0x48
    4038:	aa1303e5 	mov	x5, x19
    403c:	b0000024 	adrp	x4, 9000 <_IO_stdin_used+0x1f0>
    4040:	aa0003f3 	mov	x19, x0
    4044:	91052084 	add	x4, x4, #0x148
    4048:	d2804003 	mov	x3, #0x200                 	// #512
    404c:	aa0303e1 	mov	x1, x3
    4050:	52800042 	mov	w2, #0x2                   	// #2
    4054:	97fff507 	bl	1470 <__snprintf_chk@plt>
    4058:	aa1303e0 	mov	x0, x19
    405c:	97fff4cd 	bl	1390 <strlen@plt>
    4060:	aa1303e1 	mov	x1, x19
    4064:	aa0003e2 	mov	x2, x0
    4068:	aa1403e0 	mov	x0, x20
    406c:	97fff829 	bl	2110 <buf_put>
    4070:	f9413bf5 	ldr	x21, [sp, #624]
    4074:	f9413ff6 	ldr	x22, [sp, #632]
    4078:	f94153fb 	ldr	x27, [sp, #672]
    407c:	f94157fc 	ldr	x28, [sp, #680]
    4080:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    4084:	f947f400 	ldr	x0, [x0, #4072]
    4088:	f94127e2 	ldr	x2, [sp, #584]
    408c:	f9400001 	ldr	x1, [x0]
    4090:	eb010042 	subs	x2, x2, x1
    4094:	d2800001 	mov	x1, #0x0                   	// #0
    4098:	540074a1 	b.ne	4f2c <fwp_write.constprop.0+0xf5c>  // b.any
    409c:	910943ff 	add	sp, sp, #0x250
    40a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40a4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    40a8:	d65f03c0 	ret
    40ac:	910123e0 	add	x0, sp, #0x48
    40b0:	aa1303e5 	mov	x5, x19
    40b4:	b0000024 	adrp	x4, 9000 <_IO_stdin_used+0x1f0>
    40b8:	aa0003f3 	mov	x19, x0
    40bc:	91050084 	add	x4, x4, #0x140
    40c0:	d2804003 	mov	x3, #0x200                 	// #512
    40c4:	17ffffe2 	b	404c <fwp_write.constprop.0+0x7c>
    40c8:	71004c1f 	cmp	w0, #0x13
    40cc:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    40d0:	b0000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    40d4:	9104e021 	add	x1, x1, #0x138
    40d8:	9104c000 	add	x0, x0, #0x130
    40dc:	d2800082 	mov	x2, #0x4                   	// #4
    40e0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    40e4:	aa1403e0 	mov	x0, x20
    40e8:	f90143f7 	str	x23, [sp, #640]
    40ec:	d2800016 	mov	x22, #0x0                   	// #0
    40f0:	f90147f8 	str	x24, [sp, #648]
    40f4:	97fff807 	bl	2110 <buf_put>
    40f8:	f9400260 	ldr	x0, [x19]
    40fc:	b0000037 	adrp	x23, 9000 <_IO_stdin_used+0x1f0>
    4100:	d2800015 	mov	x21, #0x0                   	// #0
    4104:	9106e2f7 	add	x23, x23, #0x1b8
    4108:	b4004e40 	cbz	x0, 4ad0 <fwp_write.constprop.0+0xb00>
    410c:	b9400381 	ldr	w1, [x28]
    4110:	aa1403e0 	mov	x0, x20
    4114:	f9401f82 	ldr	x2, [x28, #56]
    4118:	71004c3f 	cmp	w1, #0x13
    411c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    4120:	8b010e61 	add	x1, x19, x1, lsl #3
    4124:	f9400421 	ldr	x1, [x1, #8]
    4128:	97ffffaa 	bl	3fd0 <fwp_write.constprop.0>
    412c:	b9400380 	ldr	w0, [x28]
    4130:	7100481f 	cmp	w0, #0x12
    4134:	540050c0 	b.eq	4b4c <fwp_write.constprop.0+0xb7c>  // b.none
    4138:	f9400260 	ldr	x0, [x19]
    413c:	910006b5 	add	x21, x21, #0x1
    4140:	91000ad6 	add	x22, x22, #0x2
    4144:	eb0002bf 	cmp	x21, x0
    4148:	54004c42 	b.cs	4ad0 <fwp_write.constprop.0+0xb00>  // b.hs, b.nlast
    414c:	aa1703e1 	mov	x1, x23
    4150:	aa1403e0 	mov	x0, x20
    4154:	d2800042 	mov	x2, #0x2                   	// #2
    4158:	97fff7ee 	bl	2110 <buf_put>
    415c:	17ffffec 	b	410c <fwp_write.constprop.0+0x13c>
    4160:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    4164:	9105c021 	add	x1, x1, #0x170
    4168:	d28000c2 	mov	x2, #0x6                   	// #6
    416c:	aa1403e0 	mov	x0, x20
    4170:	91004273 	add	x19, x19, #0x10
    4174:	97fff7e7 	bl	2110 <buf_put>
    4178:	aa1303e0 	mov	x0, x19
    417c:	97fff485 	bl	1390 <strlen@plt>
    4180:	aa1303e1 	mov	x1, x19
    4184:	aa0003e2 	mov	x2, x0
    4188:	aa1403e0 	mov	x0, x20
    418c:	97fff7e1 	bl	2110 <buf_put>
    4190:	528007c3 	mov	w3, #0x3e                  	// #62
    4194:	aa1403e0 	mov	x0, x20
    4198:	91001fe1 	add	x1, sp, #0x7
    419c:	d2800022 	mov	x2, #0x1                   	// #1
    41a0:	39001fe3 	strb	w3, [sp, #7]
    41a4:	17ffffb2 	b	406c <fwp_write.constprop.0+0x9c>
    41a8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    41ac:	f947f400 	ldr	x0, [x0, #4072]
    41b0:	f94127e2 	ldr	x2, [sp, #584]
    41b4:	f9400001 	ldr	x1, [x0]
    41b8:	eb010042 	subs	x2, x2, x1
    41bc:	d2800001 	mov	x1, #0x0                   	// #0
    41c0:	54006cc1 	b.ne	4f58 <fwp_write.constprop.0+0xf88>  // b.any
    41c4:	f9413bf5 	ldr	x21, [sp, #624]
    41c8:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    41cc:	f9413ff6 	ldr	x22, [sp, #632]
    41d0:	aa1403e0 	mov	x0, x20
    41d4:	91054021 	add	x1, x1, #0x150
    41d8:	d2800142 	mov	x2, #0xa                   	// #10
    41dc:	f94153fb 	ldr	x27, [sp, #672]
    41e0:	f94157fc 	ldr	x28, [sp, #680]
    41e4:	910943ff 	add	sp, sp, #0x250
    41e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    41ec:	a8c77bfd 	ldp	x29, x30, [sp], #112
    41f0:	17fff7c8 	b	2110 <buf_put>
    41f4:	f9400796 	ldr	x22, [x28, #8]
    41f8:	f90143f7 	str	x23, [sp, #640]
    41fc:	f90147f8 	str	x24, [sp, #648]
    4200:	b4005816 	cbz	x22, 4d00 <fwp_write.constprop.0+0xd30>
    4204:	aa1603e0 	mov	x0, x22
    4208:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    420c:	91074021 	add	x1, x1, #0x1d0
    4210:	97fff4dc 	bl	1580 <strcmp@plt>
    4214:	2a0003f5 	mov	w21, w0
    4218:	34005ce0 	cbz	w0, 4db4 <fwp_write.constprop.0+0xde4>
    421c:	aa1603e0 	mov	x0, x22
    4220:	97fff45c 	bl	1390 <strlen@plt>
    4224:	aa1603e1 	mov	x1, x22
    4228:	aa0003e2 	mov	x2, x0
    422c:	aa1403e0 	mov	x0, x20
    4230:	97fff7b8 	bl	2110 <buf_put>
    4234:	52800403 	mov	w3, #0x20                  	// #32
    4238:	91001ff5 	add	x21, sp, #0x7
    423c:	aa1503e1 	mov	x1, x21
    4240:	aa1403e0 	mov	x0, x20
    4244:	d2800022 	mov	x2, #0x1                   	// #1
    4248:	39001fe3 	strb	w3, [sp, #7]
    424c:	97fff7b1 	bl	2110 <buf_put>
    4250:	52800f63 	mov	w3, #0x7b                  	// #123
    4254:	aa1403e0 	mov	x0, x20
    4258:	aa1503e1 	mov	x1, x21
    425c:	d2800022 	mov	x2, #0x1                   	// #1
    4260:	39001fe3 	strb	w3, [sp, #7]
    4264:	97fff7ab 	bl	2110 <buf_put>
    4268:	b9401380 	ldr	w0, [x28, #16]
    426c:	52800018 	mov	w24, #0x0                   	// #0
    4270:	7100001f 	cmp	w0, #0x0
    4274:	54003d8d 	b.le	4a24 <fwp_write.constprop.0+0xa54>
    4278:	f9014bf9 	str	x25, [sp, #656]
    427c:	b0000039 	adrp	x25, 9000 <_IO_stdin_used+0x1f0>
    4280:	9107e339 	add	x25, x25, #0x1f8
    4284:	f9014ffa 	str	x26, [sp, #664]
    4288:	b000003a 	adrp	x26, 9000 <_IO_stdin_used+0x1f0>
    428c:	9106e35a 	add	x26, x26, #0x1b8
    4290:	91002276 	add	x22, x19, #0x8
    4294:	d2800013 	mov	x19, #0x0                   	// #0
    4298:	b5004413 	cbnz	x19, 4b18 <fwp_write.constprop.0+0xb48>
    429c:	d37df277 	lsl	x23, x19, #3
    42a0:	34004238 	cbz	w24, 4ae4 <fwp_write.constprop.0+0xb14>
    42a4:	f9401382 	ldr	x2, [x28, #32]
    42a8:	aa1403e0 	mov	x0, x20
    42ac:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    42b0:	91000673 	add	x19, x19, #0x1
    42b4:	f8776842 	ldr	x2, [x2, x23]
    42b8:	97ffff46 	bl	3fd0 <fwp_write.constprop.0>
    42bc:	b9401380 	ldr	w0, [x28, #16]
    42c0:	6b13001f 	cmp	w0, w19
    42c4:	54fffeac 	b.gt	4298 <fwp_write.constprop.0+0x2c8>
    42c8:	f9414bf9 	ldr	x25, [sp, #656]
    42cc:	f9414ffa 	ldr	x26, [sp, #664]
    42d0:	34003ab8 	cbz	w24, 4a24 <fwp_write.constprop.0+0xa54>
    42d4:	52800523 	mov	w3, #0x29                  	// #41
    42d8:	aa1503e1 	mov	x1, x21
    42dc:	aa1403e0 	mov	x0, x20
    42e0:	d2800022 	mov	x2, #0x1                   	// #1
    42e4:	39001fe3 	strb	w3, [sp, #7]
    42e8:	97fff78a 	bl	2110 <buf_put>
    42ec:	f9413bf5 	ldr	x21, [sp, #624]
    42f0:	f9413ff6 	ldr	x22, [sp, #632]
    42f4:	f94143f7 	ldr	x23, [sp, #640]
    42f8:	f94147f8 	ldr	x24, [sp, #648]
    42fc:	f94153fb 	ldr	x27, [sp, #672]
    4300:	f94157fc 	ldr	x28, [sp, #680]
    4304:	17ffff5f 	b	4080 <fwp_write.constprop.0+0xb0>
    4308:	b9404b95 	ldr	w21, [x28, #72]
    430c:	aa1403e0 	mov	x0, x20
    4310:	93407eb6 	sxtw	x22, w21
    4314:	91000ac1 	add	x1, x22, #0x2
    4318:	97fff74a 	bl	2040 <buf_grow>
    431c:	a9400281 	ldp	x1, x0, [x20]
    4320:	528e8603 	mov	w3, #0x7430                	// #29744
    4324:	78206823 	strh	w3, [x1, x0]
    4328:	8b000022 	add	x2, x1, x0
    432c:	710002bf 	cmp	w21, #0x0
    4330:	54003bcd 	b.le	4aa8 <fwp_write.constprop.0+0xad8>
    4334:	110006a3 	add	w3, w21, #0x1
    4338:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    433c:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    4340:	91000449 	add	x9, x2, #0x1
    4344:	8b23c043 	add	x3, x2, w3, sxtw
    4348:	f28aaac6 	movk	x6, #0x5556
    434c:	f2955568 	movk	x8, #0xaaab
    4350:	1400000d 	b	4384 <fwp_write.constprop.0+0x3b4>
    4354:	d2800021 	mov	x1, #0x1                   	// #1
    4358:	528005a5 	mov	w5, #0x2d                  	// #45
    435c:	f100001f 	cmp	x0, #0x0
    4360:	9b467e60 	smulh	x0, x19, x6
    4364:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    4368:	381ff465 	strb	w5, [x3], #-1
    436c:	cb040000 	sub	x0, x0, x4
    4370:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    4374:	cb020000 	sub	x0, x0, x2
    4378:	8b010013 	add	x19, x0, x1
    437c:	eb03013f 	cmp	x9, x3
    4380:	54003940 	b.eq	4aa8 <fwp_write.constprop.0+0xad8>  // b.none
    4384:	9b467e60 	smulh	x0, x19, x6
    4388:	937ffe64 	asr	x4, x19, #63
    438c:	52800605 	mov	w5, #0x30                  	// #48
    4390:	cb040000 	sub	x0, x0, x4
    4394:	8b000400 	add	x0, x0, x0, lsl #1
    4398:	cb000260 	sub	x0, x19, x0
    439c:	91000c01 	add	x1, x0, #0x3
    43a0:	9bc87c22 	umulh	x2, x1, x8
    43a4:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    43a8:	8b4204e2 	add	x2, x7, x2, lsr #1
    43ac:	eb020021 	subs	x1, x1, x2
    43b0:	54fffd60 	b.eq	435c <fwp_write.constprop.0+0x38c>  // b.none
    43b4:	f100043f 	cmp	x1, #0x1
    43b8:	54fffce1 	b.ne	4354 <fwp_write.constprop.0+0x384>  // b.any
    43bc:	d2800001 	mov	x1, #0x0                   	// #0
    43c0:	52800565 	mov	w5, #0x2b                  	// #43
    43c4:	17ffffe6 	b	435c <fwp_write.constprop.0+0x38c>
    43c8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    43cc:	f947f400 	ldr	x0, [x0, #4072]
    43d0:	f94127e2 	ldr	x2, [sp, #584]
    43d4:	f9400001 	ldr	x1, [x0]
    43d8:	eb010042 	subs	x2, x2, x1
    43dc:	d2800001 	mov	x1, #0x0                   	// #0
    43e0:	54005bc1 	b.ne	4f58 <fwp_write.constprop.0+0xf88>  // b.any
    43e4:	f9413bf5 	ldr	x21, [sp, #624]
    43e8:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    43ec:	f9413ff6 	ldr	x22, [sp, #632]
    43f0:	aa1403e0 	mov	x0, x20
    43f4:	91058021 	add	x1, x1, #0x160
    43f8:	d2800102 	mov	x2, #0x8                   	// #8
    43fc:	17ffff78 	b	41dc <fwp_write.constprop.0+0x20c>
    4400:	aa1403e0 	mov	x0, x20
    4404:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    4408:	d28000c2 	mov	x2, #0x6                   	// #6
    440c:	91070021 	add	x1, x1, #0x1c0
    4410:	97fff740 	bl	2110 <buf_put>
    4414:	d2800015 	mov	x21, #0x0                   	// #0
    4418:	f9400263 	ldr	x3, [x19]
    441c:	f240f87f 	tst	x3, #0x7fffffffffffffff
    4420:	540026a0 	b.eq	48f4 <fwp_write.constprop.0+0x924>  // b.none
    4424:	f9401f82 	ldr	x2, [x28, #56]
    4428:	f90143f7 	str	x23, [sp, #640]
    442c:	f90147f8 	str	x24, [sp, #648]
    4430:	d2800857 	mov	x23, #0x42                  	// #66
    4434:	f9014bf9 	str	x25, [sp, #656]
    4438:	b0000036 	adrp	x22, 9000 <_IO_stdin_used+0x1f0>
    443c:	f9014ffa 	str	x26, [sp, #664]
    4440:	9106e2d6 	add	x22, x22, #0x1b8
    4444:	d2800038 	mov	x24, #0x1                   	// #1
    4448:	f2a18017 	movk	x23, #0xc00, lsl #16
    444c:	d2809099 	mov	x25, #0x484                 	// #1156
    4450:	b4000482 	cbz	x2, 44e0 <fwp_write.constprop.0+0x510>
    4454:	b9400040 	ldr	w0, [x2]
    4458:	7100701f 	cmp	w0, #0x1c
    445c:	540042e0 	b.eq	4cb8 <fwp_write.constprop.0+0xce8>  // b.none
    4460:	71006c1f 	cmp	w0, #0x1b
    4464:	540003e8 	b.hi	44e0 <fwp_write.constprop.0+0x510>  // b.pmore
    4468:	9ac02301 	lsl	x1, x24, x0
    446c:	ea17003f 	tst	x1, x23
    4470:	54003f21 	b.ne	4c54 <fwp_write.constprop.0+0xc84>  // b.any
    4474:	ea19003f 	tst	x1, x25
    4478:	54003da1 	b.ne	4c2c <fwp_write.constprop.0+0xc5c>  // b.any
    447c:	d2800425 	mov	x5, #0x21                  	// #33
    4480:	ea05003f 	tst	x1, x5
    4484:	540002e0 	b.eq	44e0 <fwp_write.constprop.0+0x510>  // b.none
    4488:	b7f84743 	tbnz	x3, #63, 4d70 <fwp_write.constprop.0+0xda0>
    448c:	91002261 	add	x1, x19, #0x8
    4490:	8b150021 	add	x1, x1, x21
    4494:	39400021 	ldrb	w1, [x1]
    4498:	7100001f 	cmp	w0, #0x0
    449c:	93401c23 	sxtb	x3, w1
    44a0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    44a4:	d503201f 	nop
    44a8:	aa1403e0 	mov	x0, x20
    44ac:	97fffec9 	bl	3fd0 <fwp_write.constprop.0>
    44b0:	f9400260 	ldr	x0, [x19]
    44b4:	910006b5 	add	x21, x21, #0x1
    44b8:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    44bc:	eb0002bf 	cmp	x21, x0
    44c0:	54002122 	b.cs	48e4 <fwp_write.constprop.0+0x914>  // b.hs, b.nlast
    44c4:	d2800042 	mov	x2, #0x2                   	// #2
    44c8:	aa1603e1 	mov	x1, x22
    44cc:	aa1403e0 	mov	x0, x20
    44d0:	97fff710 	bl	2110 <buf_put>
    44d4:	f9401f82 	ldr	x2, [x28, #56]
    44d8:	f9400263 	ldr	x3, [x19]
    44dc:	b5fffbc2 	cbnz	x2, 4454 <fwp_write.constprop.0+0x484>
    44e0:	d37df2a0 	lsl	x0, x21, #3
    44e4:	b7f83f43 	tbnz	x3, #63, 4ccc <fwp_write.constprop.0+0xcfc>
    44e8:	91002261 	add	x1, x19, #0x8
    44ec:	8b000020 	add	x0, x1, x0
    44f0:	f9400001 	ldr	x1, [x0]
    44f4:	17ffffed 	b	44a8 <fwp_write.constprop.0+0x4d8>
    44f8:	a9400e62 	ldp	x2, x3, [x19]
    44fc:	b7f83ce3 	tbnz	x3, #63, 4c98 <fwp_write.constprop.0+0xcc8>
    4500:	910123f5 	add	x21, sp, #0x48
    4504:	aa1503e0 	mov	x0, x21
    4508:	97fff556 	bl	1a60 <fwp_fmt_u128>
    450c:	aa1503e0 	mov	x0, x21
    4510:	97fff3a0 	bl	1390 <strlen@plt>
    4514:	aa1503e1 	mov	x1, x21
    4518:	aa0003e2 	mov	x2, x0
    451c:	17fffed3 	b	4068 <fwp_write.constprop.0+0x98>
    4520:	fd015be8 	str	d8, [sp, #688]
    4524:	1e270268 	fmov	s8, w19
    4528:	fd015fe9 	str	d9, [sp, #696]
    452c:	1e282100 	fcmp	s8, s8
    4530:	54004a66 	b.vs	4e7c <fwp_write.constprop.0+0xeac>
    4534:	1e20c101 	fabs	s1, s8
    4538:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    453c:	1e270000 	fmov	s0, w0
    4540:	1e202020 	fcmp	s1, s0
    4544:	540034ad 	b.le	4bd8 <fwp_write.constprop.0+0xc08>
    4548:	1e202118 	fcmpe	s8, #0.0
    454c:	90000022 	adrp	x2, 8000 <f0+0x2340>
    4550:	913c8042 	add	x2, x2, #0xf20
    4554:	910123f5 	add	x21, sp, #0x48
    4558:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    455c:	91044021 	add	x1, x1, #0x110
    4560:	aa1503e0 	mov	x0, x21
    4564:	9a81c041 	csel	x1, x2, x1, gt
    4568:	97fff436 	bl	1640 <strcpy@plt>
    456c:	d503201f 	nop
    4570:	aa1503e0 	mov	x0, x21
    4574:	97fff387 	bl	1390 <strlen@plt>
    4578:	aa1503e1 	mov	x1, x21
    457c:	aa0003e2 	mov	x2, x0
    4580:	aa1403e0 	mov	x0, x20
    4584:	97fff6e3 	bl	2110 <buf_put>
    4588:	f9413bf5 	ldr	x21, [sp, #624]
    458c:	f9413ff6 	ldr	x22, [sp, #632]
    4590:	f94153fb 	ldr	x27, [sp, #672]
    4594:	f94157fc 	ldr	x28, [sp, #680]
    4598:	fd415be8 	ldr	d8, [sp, #688]
    459c:	fd415fe9 	ldr	d9, [sp, #696]
    45a0:	17fffeb8 	b	4080 <fwp_write.constprop.0+0xb0>
    45a4:	f90143f7 	str	x23, [sp, #640]
    45a8:	52800443 	mov	w3, #0x22                  	// #34
    45ac:	f90147f8 	str	x24, [sp, #648]
    45b0:	91001ff5 	add	x21, sp, #0x7
    45b4:	aa1503e1 	mov	x1, x21
    45b8:	aa1403e0 	mov	x0, x20
    45bc:	f8408677 	ldr	x23, [x19], #8
    45c0:	d2800022 	mov	x2, #0x1                   	// #1
    45c4:	39001fe3 	strb	w3, [sp, #7]
    45c8:	97fff6d2 	bl	2110 <buf_put>
    45cc:	8b1302f6 	add	x22, x23, x19
    45d0:	b4002657 	cbz	x23, 4a98 <fwp_write.constprop.0+0xac8>
    45d4:	b0000038 	adrp	x24, 9000 <_IO_stdin_used+0x1f0>
    45d8:	9105e318 	add	x24, x24, #0x178
    45dc:	f9014bf9 	str	x25, [sp, #656]
    45e0:	b0000039 	adrp	x25, 9000 <_IO_stdin_used+0x1f0>
    45e4:	91066339 	add	x25, x25, #0x198
    45e8:	f9014ffa 	str	x26, [sp, #664]
    45ec:	1400000e 	b	4624 <fwp_write.constprop.0+0x654>
    45f0:	710024bf 	cmp	w5, #0x9
    45f4:	54002380 	b.eq	4a64 <fwp_write.constprop.0+0xa94>  // b.none
    45f8:	710028bf 	cmp	w5, #0xa
    45fc:	54002be1 	b.ne	4b78 <fwp_write.constprop.0+0xba8>  // b.any
    4600:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    4604:	aa1403e0 	mov	x0, x20
    4608:	91062021 	add	x1, x1, #0x188
    460c:	d2800042 	mov	x2, #0x2                   	// #2
    4610:	97fff6c0 	bl	2110 <buf_put>
    4614:	d503201f 	nop
    4618:	91000673 	add	x19, x19, #0x1
    461c:	eb16027f 	cmp	x19, x22
    4620:	54002380 	b.eq	4a90 <fwp_write.constprop.0+0xac0>  // b.none
    4624:	39400265 	ldrb	w5, [x19]
    4628:	710034bf 	cmp	w5, #0xd
    462c:	54002120 	b.eq	4a50 <fwp_write.constprop.0+0xa80>  // b.none
    4630:	54fffe09 	b.ls	45f0 <fwp_write.constprop.0+0x620>  // b.plast
    4634:	710088bf 	cmp	w5, #0x22
    4638:	54002220 	b.eq	4a7c <fwp_write.constprop.0+0xaac>  // b.none
    463c:	710170bf 	cmp	w5, #0x5c
    4640:	54002ba1 	b.ne	4bb4 <fwp_write.constprop.0+0xbe4>  // b.any
    4644:	aa1403e0 	mov	x0, x20
    4648:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    464c:	d2800042 	mov	x2, #0x2                   	// #2
    4650:	91060021 	add	x1, x1, #0x180
    4654:	97fff6af 	bl	2110 <buf_put>
    4658:	17fffff0 	b	4618 <fwp_write.constprop.0+0x648>
    465c:	fd015be8 	str	d8, [sp, #688]
    4660:	9e670268 	fmov	d8, x19
    4664:	fd015fe9 	str	d9, [sp, #696]
    4668:	1e682100 	fcmp	d8, d8
    466c:	54004086 	b.vs	4e7c <fwp_write.constprop.0+0xeac>
    4670:	1e60c101 	fabs	d1, d8
    4674:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    4678:	9e670000 	fmov	d0, x0
    467c:	910123f5 	add	x21, sp, #0x48
    4680:	52800033 	mov	w19, #0x1                   	// #1
    4684:	1e602020 	fcmp	d1, d0
    4688:	540001ad 	b.le	46bc <fwp_write.constprop.0+0x6ec>
    468c:	1e602118 	fcmpe	d8, #0.0
    4690:	90000022 	adrp	x2, 8000 <f0+0x2340>
    4694:	913c8042 	add	x2, x2, #0xf20
    4698:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    469c:	91044021 	add	x1, x1, #0x110
    46a0:	aa1503e0 	mov	x0, x21
    46a4:	9a81c041 	csel	x1, x2, x1, gt
    46a8:	97fff3e6 	bl	1640 <strcpy@plt>
    46ac:	17ffffb1 	b	4570 <fwp_write.constprop.0+0x5a0>
    46b0:	11000673 	add	w19, w19, #0x1
    46b4:	71004a7f 	cmp	w19, #0x12
    46b8:	540031a0 	b.eq	4cec <fwp_write.constprop.0+0xd1c>  // b.none
    46bc:	1e604100 	fmov	d0, d8
    46c0:	2a1303e1 	mov	w1, w19
    46c4:	aa1503e0 	mov	x0, x21
    46c8:	97fff726 	bl	2360 <fwp_format_g.constprop.0>
    46cc:	aa1503e0 	mov	x0, x21
    46d0:	d2800001 	mov	x1, #0x0                   	// #0
    46d4:	97fff343 	bl	13e0 <strtod@plt>
    46d8:	1e602100 	fcmp	d8, d0
    46dc:	54fffea1 	b.ne	46b0 <fwp_write.constprop.0+0x6e0>  // b.any
    46e0:	aa1503e0 	mov	x0, x21
    46e4:	97fff6c4 	bl	21f4 <fwp_finish_float>
    46e8:	17ffffa2 	b	4570 <fwp_write.constprop.0+0x5a0>
    46ec:	a9400e62 	ldp	x2, x3, [x19]
    46f0:	910123f3 	add	x19, sp, #0x48
    46f4:	aa1303e0 	mov	x0, x19
    46f8:	97fff4da 	bl	1a60 <fwp_fmt_u128>
    46fc:	17fffe57 	b	4058 <fwp_write.constprop.0+0x88>
    4700:	f90143f7 	str	x23, [sp, #640]
    4704:	f90147f8 	str	x24, [sp, #648]
    4708:	2a1303f8 	mov	w24, w19
    470c:	f9014bf9 	str	x25, [sp, #656]
    4710:	f9014ffa 	str	x26, [sp, #664]
    4714:	f13ffe7f 	cmp	x19, #0xfff
    4718:	54000049 	b.ls	4720 <fwp_write.constprop.0+0x750>  // b.plast
    471c:	b9400278 	ldr	w24, [x19]
    4720:	f9400f80 	ldr	x0, [x28, #24]
    4724:	2a1803f5 	mov	w21, w24
    4728:	d37d7f18 	ubfiz	x24, x24, #3, #32
    472c:	d37ef6b9 	lsl	x25, x21, #2
    4730:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    4734:	aa1603e0 	mov	x0, x22
    4738:	97fff316 	bl	1390 <strlen@plt>
    473c:	aa1603e1 	mov	x1, x22
    4740:	aa0003e2 	mov	x2, x0
    4744:	aa1403e0 	mov	x0, x20
    4748:	97fff672 	bl	2110 <buf_put>
    474c:	f9401780 	ldr	x0, [x28, #40]
    4750:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    4754:	7100001f 	cmp	w0, #0x0
    4758:	5400064d 	b.le	4820 <fwp_write.constprop.0+0x850>
    475c:	91002276 	add	x22, x19, #0x8
    4760:	91001ff5 	add	x21, sp, #0x7
    4764:	d280001b 	mov	x27, #0x0                   	// #0
    4768:	5280041a 	mov	w26, #0x20                  	// #32
    476c:	f9401b80 	ldr	x0, [x28, #48]
    4770:	aa1503e1 	mov	x1, x21
    4774:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    4778:	d2800022 	mov	x2, #0x1                   	// #1
    477c:	f8786805 	ldr	x5, [x0, x24]
    4780:	aa1403e0 	mov	x0, x20
    4784:	f87b78b3 	ldr	x19, [x5, x27, lsl #3]
    4788:	39001ffa 	strb	w26, [sp, #7]
    478c:	97fff661 	bl	2110 <buf_put>
    4790:	f13ffeff 	cmp	x23, #0xfff
    4794:	b9400261 	ldr	w1, [x19]
    4798:	1a9f97e0 	cset	w0, hi	// hi = pmore
    479c:	7100383f 	cmp	w1, #0xe
    47a0:	54000140 	b.eq	47c8 <fwp_write.constprop.0+0x7f8>  // b.none
    47a4:	7100403f 	cmp	w1, #0x10
    47a8:	54001c20 	b.eq	4b2c <fwp_write.constprop.0+0xb5c>  // b.none
    47ac:	7100283f 	cmp	w1, #0xa
    47b0:	540026e0 	b.eq	4c8c <fwp_write.constprop.0+0xcbc>  // b.none
    47b4:	540013cc 	b.gt	4a2c <fwp_write.constprop.0+0xa5c>
    47b8:	71000c3f 	cmp	w1, #0x3
    47bc:	540025ec 	b.gt	4c78 <fwp_write.constprop.0+0xca8>
    47c0:	d37ffee0 	lsr	x0, x23, #63
    47c4:	37f813c1 	tbnz	w1, #31, 4a3c <fwp_write.constprop.0+0xa6c>
    47c8:	340013a0 	cbz	w0, 4a3c <fwp_write.constprop.0+0xa6c>
    47cc:	52800503 	mov	w3, #0x28                  	// #40
    47d0:	aa1503e1 	mov	x1, x21
    47d4:	aa1403e0 	mov	x0, x20
    47d8:	d2800022 	mov	x2, #0x1                   	// #1
    47dc:	39001fe3 	strb	w3, [sp, #7]
    47e0:	97fff64c 	bl	2110 <buf_put>
    47e4:	aa1303e2 	mov	x2, x19
    47e8:	aa1703e1 	mov	x1, x23
    47ec:	aa1403e0 	mov	x0, x20
    47f0:	97fffdf8 	bl	3fd0 <fwp_write.constprop.0>
    47f4:	52800523 	mov	w3, #0x29                  	// #41
    47f8:	aa1503e1 	mov	x1, x21
    47fc:	aa1403e0 	mov	x0, x20
    4800:	d2800022 	mov	x2, #0x1                   	// #1
    4804:	39001fe3 	strb	w3, [sp, #7]
    4808:	97fff642 	bl	2110 <buf_put>
    480c:	f9401780 	ldr	x0, [x28, #40]
    4810:	9100077b 	add	x27, x27, #0x1
    4814:	b8796800 	ldr	w0, [x0, x25]
    4818:	6b1b001f 	cmp	w0, w27
    481c:	54fffa8c 	b.gt	476c <fwp_write.constprop.0+0x79c>
    4820:	f9413bf5 	ldr	x21, [sp, #624]
    4824:	f9413ff6 	ldr	x22, [sp, #632]
    4828:	f94143f7 	ldr	x23, [sp, #640]
    482c:	f94147f8 	ldr	x24, [sp, #648]
    4830:	f9414bf9 	ldr	x25, [sp, #656]
    4834:	f9414ffa 	ldr	x26, [sp, #664]
    4838:	f94153fb 	ldr	x27, [sp, #672]
    483c:	f94157fc 	ldr	x28, [sp, #680]
    4840:	17fffe10 	b	4080 <fwp_write.constprop.0+0xb0>
    4844:	aa1403e0 	mov	x0, x20
    4848:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    484c:	d28000c2 	mov	x2, #0x6                   	// #6
    4850:	9106a021 	add	x1, x1, #0x1a8
    4854:	97fff62f 	bl	2110 <buf_put>
    4858:	f9400260 	ldr	x0, [x19]
    485c:	b40004c0 	cbz	x0, 48f4 <fwp_write.constprop.0+0x924>
    4860:	910123f5 	add	x21, sp, #0x48
    4864:	91002276 	add	x22, x19, #0x8
    4868:	f90143f7 	str	x23, [sp, #640]
    486c:	d2800017 	mov	x23, #0x0                   	// #0
    4870:	f90147f8 	str	x24, [sp, #648]
    4874:	b0000038 	adrp	x24, 9000 <_IO_stdin_used+0x1f0>
    4878:	9106c318 	add	x24, x24, #0x1b0
    487c:	f9014bf9 	str	x25, [sp, #656]
    4880:	b0000039 	adrp	x25, 9000 <_IO_stdin_used+0x1f0>
    4884:	9106e339 	add	x25, x25, #0x1b8
    4888:	f9014ffa 	str	x26, [sp, #664]
    488c:	14000005 	b	48a0 <fwp_write.constprop.0+0x8d0>
    4890:	aa1903e1 	mov	x1, x25
    4894:	aa1403e0 	mov	x0, x20
    4898:	d2800042 	mov	x2, #0x2                   	// #2
    489c:	97fff61d 	bl	2110 <buf_put>
    48a0:	38776ac5 	ldrb	w5, [x22, x23]
    48a4:	d2804003 	mov	x3, #0x200                 	// #512
    48a8:	aa1803e4 	mov	x4, x24
    48ac:	aa0303e1 	mov	x1, x3
    48b0:	52800042 	mov	w2, #0x2                   	// #2
    48b4:	aa1503e0 	mov	x0, x21
    48b8:	910006f7 	add	x23, x23, #0x1
    48bc:	97fff2ed 	bl	1470 <__snprintf_chk@plt>
    48c0:	aa1503e0 	mov	x0, x21
    48c4:	97fff2b3 	bl	1390 <strlen@plt>
    48c8:	aa1503e1 	mov	x1, x21
    48cc:	aa0003e2 	mov	x2, x0
    48d0:	aa1403e0 	mov	x0, x20
    48d4:	97fff60f 	bl	2110 <buf_put>
    48d8:	f9400260 	ldr	x0, [x19]
    48dc:	eb0002ff 	cmp	x23, x0
    48e0:	54fffd83 	b.cc	4890 <fwp_write.constprop.0+0x8c0>  // b.lo, b.ul, b.last
    48e4:	f94143f7 	ldr	x23, [sp, #640]
    48e8:	f94147f8 	ldr	x24, [sp, #648]
    48ec:	f9414bf9 	ldr	x25, [sp, #656]
    48f0:	f9414ffa 	ldr	x26, [sp, #664]
    48f4:	52800ba3 	mov	w3, #0x5d                  	// #93
    48f8:	aa1403e0 	mov	x0, x20
    48fc:	91001fe1 	add	x1, sp, #0x7
    4900:	d2800022 	mov	x2, #0x1                   	// #1
    4904:	39001fe3 	strb	w3, [sp, #7]
    4908:	17fffdd9 	b	406c <fwp_write.constprop.0+0x9c>
    490c:	52800b63 	mov	w3, #0x5b                  	// #91
    4910:	91001ff5 	add	x21, sp, #0x7
    4914:	aa1503e1 	mov	x1, x21
    4918:	aa1403e0 	mov	x0, x20
    491c:	d2800022 	mov	x2, #0x1                   	// #1
    4920:	b0000036 	adrp	x22, 9000 <_IO_stdin_used+0x1f0>
    4924:	9106e2d6 	add	x22, x22, #0x1b8
    4928:	39001fe3 	strb	w3, [sp, #7]
    492c:	97fff5f9 	bl	2110 <buf_put>
    4930:	b4000233 	cbz	x19, 4974 <fwp_write.constprop.0+0x9a4>
    4934:	f9400661 	ldr	x1, [x19, #8]
    4938:	aa1403e0 	mov	x0, x20
    493c:	f9401f82 	ldr	x2, [x28, #56]
    4940:	97fffda4 	bl	3fd0 <fwp_write.constprop.0>
    4944:	f9400a73 	ldr	x19, [x19, #16]
    4948:	b4000173 	cbz	x19, 4974 <fwp_write.constprop.0+0x9a4>
    494c:	aa1603e1 	mov	x1, x22
    4950:	aa1403e0 	mov	x0, x20
    4954:	d2800042 	mov	x2, #0x2                   	// #2
    4958:	97fff5ee 	bl	2110 <buf_put>
    495c:	f9400661 	ldr	x1, [x19, #8]
    4960:	aa1403e0 	mov	x0, x20
    4964:	f9401f82 	ldr	x2, [x28, #56]
    4968:	97fffd9a 	bl	3fd0 <fwp_write.constprop.0>
    496c:	f9400a73 	ldr	x19, [x19, #16]
    4970:	b5fffef3 	cbnz	x19, 494c <fwp_write.constprop.0+0x97c>
    4974:	52800ba3 	mov	w3, #0x5d                  	// #93
    4978:	aa1503e1 	mov	x1, x21
    497c:	aa1403e0 	mov	x0, x20
    4980:	d2800022 	mov	x2, #0x1                   	// #1
    4984:	39001fe3 	strb	w3, [sp, #7]
    4988:	17fffdb9 	b	406c <fwp_write.constprop.0+0x9c>
    498c:	52800783 	mov	w3, #0x3c                  	// #60
    4990:	91001ff3 	add	x19, sp, #0x7
    4994:	aa1303e1 	mov	x1, x19
    4998:	d2800022 	mov	x2, #0x1                   	// #1
    499c:	aa1403e0 	mov	x0, x20
    49a0:	39001fe3 	strb	w3, [sp, #7]
    49a4:	97fff5db 	bl	2110 <buf_put>
    49a8:	f9400795 	ldr	x21, [x28, #8]
    49ac:	aa1503e0 	mov	x0, x21
    49b0:	97fff278 	bl	1390 <strlen@plt>
    49b4:	aa1503e1 	mov	x1, x21
    49b8:	aa0003e2 	mov	x2, x0
    49bc:	aa1403e0 	mov	x0, x20
    49c0:	97fff5d4 	bl	2110 <buf_put>
    49c4:	528007c3 	mov	w3, #0x3e                  	// #62
    49c8:	aa1303e1 	mov	x1, x19
    49cc:	aa1403e0 	mov	x0, x20
    49d0:	d2800022 	mov	x2, #0x1                   	// #1
    49d4:	39001fe3 	strb	w3, [sp, #7]
    49d8:	17fffda5 	b	406c <fwp_write.constprop.0+0x9c>
    49dc:	f100067f 	cmp	x19, #0x1
    49e0:	540017e0 	b.eq	4cdc <fwp_write.constprop.0+0xd0c>  // b.none
    49e4:	b100067f 	cmn	x19, #0x1
    49e8:	54001b00 	b.eq	4d48 <fwp_write.constprop.0+0xd78>  // b.none
    49ec:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    49f0:	9104a021 	add	x1, x1, #0x128
    49f4:	d2800022 	mov	x2, #0x1                   	// #1
    49f8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    49fc:	f947f400 	ldr	x0, [x0, #4072]
    4a00:	f94127e4 	ldr	x4, [sp, #584]
    4a04:	f9400003 	ldr	x3, [x0]
    4a08:	eb030084 	subs	x4, x4, x3
    4a0c:	d2800003 	mov	x3, #0x0                   	// #0
    4a10:	54002a41 	b.ne	4f58 <fwp_write.constprop.0+0xf88>  // b.any
    4a14:	f9413bf5 	ldr	x21, [sp, #624]
    4a18:	aa1403e0 	mov	x0, x20
    4a1c:	f9413ff6 	ldr	x22, [sp, #632]
    4a20:	17fffdef 	b	41dc <fwp_write.constprop.0+0x20c>
    4a24:	52800fa3 	mov	w3, #0x7d                  	// #125
    4a28:	17fffe2c 	b	42d8 <fwp_write.constprop.0+0x308>
    4a2c:	f10002ff 	cmp	x23, #0x0
    4a30:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4a34:	71002c3f 	cmp	w1, #0xb
    4a38:	54ffec80 	b.eq	47c8 <fwp_write.constprop.0+0x7f8>  // b.none
    4a3c:	aa1303e2 	mov	x2, x19
    4a40:	aa1703e1 	mov	x1, x23
    4a44:	aa1403e0 	mov	x0, x20
    4a48:	97fffd62 	bl	3fd0 <fwp_write.constprop.0>
    4a4c:	17ffff70 	b	480c <fwp_write.constprop.0+0x83c>
    4a50:	aa1903e1 	mov	x1, x25
    4a54:	aa1403e0 	mov	x0, x20
    4a58:	d2800042 	mov	x2, #0x2                   	// #2
    4a5c:	97fff5ad 	bl	2110 <buf_put>
    4a60:	17fffeee 	b	4618 <fwp_write.constprop.0+0x648>
    4a64:	aa1403e0 	mov	x0, x20
    4a68:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    4a6c:	d2800042 	mov	x2, #0x2                   	// #2
    4a70:	91064021 	add	x1, x1, #0x190
    4a74:	97fff5a7 	bl	2110 <buf_put>
    4a78:	17fffee8 	b	4618 <fwp_write.constprop.0+0x648>
    4a7c:	aa1803e1 	mov	x1, x24
    4a80:	aa1403e0 	mov	x0, x20
    4a84:	d2800042 	mov	x2, #0x2                   	// #2
    4a88:	97fff5a2 	bl	2110 <buf_put>
    4a8c:	17fffee3 	b	4618 <fwp_write.constprop.0+0x648>
    4a90:	f9414bf9 	ldr	x25, [sp, #656]
    4a94:	f9414ffa 	ldr	x26, [sp, #664]
    4a98:	aa1503e1 	mov	x1, x21
    4a9c:	aa1403e0 	mov	x0, x20
    4aa0:	52800443 	mov	w3, #0x22                  	// #34
    4aa4:	17fffe0f 	b	42e0 <fwp_write.constprop.0+0x310>
    4aa8:	a9400281 	ldp	x1, x0, [x20]
    4aac:	91000800 	add	x0, x0, #0x2
    4ab0:	8b160000 	add	x0, x0, x22
    4ab4:	f9000680 	str	x0, [x20, #8]
    4ab8:	3820683f 	strb	wzr, [x1, x0]
    4abc:	f9413bf5 	ldr	x21, [sp, #624]
    4ac0:	f9413ff6 	ldr	x22, [sp, #632]
    4ac4:	f94153fb 	ldr	x27, [sp, #672]
    4ac8:	f94157fc 	ldr	x28, [sp, #680]
    4acc:	17fffd6d 	b	4080 <fwp_write.constprop.0+0xb0>
    4ad0:	aa1403e0 	mov	x0, x20
    4ad4:	91001fe1 	add	x1, sp, #0x7
    4ad8:	52800fa3 	mov	w3, #0x7d                  	// #125
    4adc:	d2800022 	mov	x2, #0x1                   	// #1
    4ae0:	17fffe01 	b	42e4 <fwp_write.constprop.0+0x314>
    4ae4:	f9400f80 	ldr	x0, [x28, #24]
    4ae8:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    4aec:	aa1b03e0 	mov	x0, x27
    4af0:	97fff228 	bl	1390 <strlen@plt>
    4af4:	aa1b03e1 	mov	x1, x27
    4af8:	aa0003e2 	mov	x2, x0
    4afc:	aa1403e0 	mov	x0, x20
    4b00:	97fff584 	bl	2110 <buf_put>
    4b04:	aa1903e1 	mov	x1, x25
    4b08:	aa1403e0 	mov	x0, x20
    4b0c:	d2800062 	mov	x2, #0x3                   	// #3
    4b10:	97fff580 	bl	2110 <buf_put>
    4b14:	17fffde4 	b	42a4 <fwp_write.constprop.0+0x2d4>
    4b18:	aa1a03e1 	mov	x1, x26
    4b1c:	aa1403e0 	mov	x0, x20
    4b20:	d2800042 	mov	x2, #0x2                   	// #2
    4b24:	97fff57b 	bl	2110 <buf_put>
    4b28:	17fffddd 	b	429c <fwp_write.constprop.0+0x2cc>
    4b2c:	f9400660 	ldr	x0, [x19, #8]
    4b30:	b4fff860 	cbz	x0, 4a3c <fwp_write.constprop.0+0xa6c>
    4b34:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    4b38:	91074021 	add	x1, x1, #0x1d0
    4b3c:	97fff291 	bl	1580 <strcmp@plt>
    4b40:	7100001f 	cmp	w0, #0x0
    4b44:	1a9f07e0 	cset	w0, ne	// ne = any
    4b48:	17ffff20 	b	47c8 <fwp_write.constprop.0+0x7f8>
    4b4c:	aa1403e0 	mov	x0, x20
    4b50:	d2800042 	mov	x2, #0x2                   	// #2
    4b54:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    4b58:	91072021 	add	x1, x1, #0x1c8
    4b5c:	97fff56d 	bl	2110 <buf_put>
    4b60:	91004261 	add	x1, x19, #0x10
    4b64:	aa1403e0 	mov	x0, x20
    4b68:	f9402382 	ldr	x2, [x28, #64]
    4b6c:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    4b70:	97fffd18 	bl	3fd0 <fwp_write.constprop.0>
    4b74:	17fffd71 	b	4138 <fwp_write.constprop.0+0x168>
    4b78:	d2800203 	mov	x3, #0x10                  	// #16
    4b7c:	b0000024 	adrp	x4, 9000 <_IO_stdin_used+0x1f0>
    4b80:	aa0303e1 	mov	x1, x3
    4b84:	91068084 	add	x4, x4, #0x1a0
    4b88:	910123f7 	add	x23, sp, #0x48
    4b8c:	52800042 	mov	w2, #0x2                   	// #2
    4b90:	aa1703e0 	mov	x0, x23
    4b94:	97fff237 	bl	1470 <__snprintf_chk@plt>
    4b98:	aa1703e0 	mov	x0, x23
    4b9c:	97fff1fd 	bl	1390 <strlen@plt>
    4ba0:	aa1703e1 	mov	x1, x23
    4ba4:	aa0003e2 	mov	x2, x0
    4ba8:	aa1403e0 	mov	x0, x20
    4bac:	97fff559 	bl	2110 <buf_put>
    4bb0:	17fffe9a 	b	4618 <fwp_write.constprop.0+0x648>
    4bb4:	7101fcbf 	cmp	w5, #0x7f
    4bb8:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    4bbc:	54fffde9 	b.ls	4b78 <fwp_write.constprop.0+0xba8>  // b.plast
    4bc0:	aa1503e1 	mov	x1, x21
    4bc4:	aa1403e0 	mov	x0, x20
    4bc8:	d2800022 	mov	x2, #0x1                   	// #1
    4bcc:	39001fe5 	strb	w5, [sp, #7]
    4bd0:	97fff550 	bl	2110 <buf_put>
    4bd4:	17fffe91 	b	4618 <fwp_write.constprop.0+0x648>
    4bd8:	1e22c109 	fcvt	d9, s8
    4bdc:	910123f5 	add	x21, sp, #0x48
    4be0:	52800033 	mov	w19, #0x1                   	// #1
    4be4:	d503201f 	nop
    4be8:	1e604120 	fmov	d0, d9
    4bec:	2a1303e1 	mov	w1, w19
    4bf0:	aa1503e0 	mov	x0, x21
    4bf4:	97fff5db 	bl	2360 <fwp_format_g.constprop.0>
    4bf8:	aa1503e0 	mov	x0, x21
    4bfc:	d2800001 	mov	x1, #0x0                   	// #0
    4c00:	97fff26c 	bl	15b0 <strtof@plt>
    4c04:	1e202100 	fcmp	s8, s0
    4c08:	54ffd6c0 	b.eq	46e0 <fwp_write.constprop.0+0x710>  // b.none
    4c0c:	11000673 	add	w19, w19, #0x1
    4c10:	71002a7f 	cmp	w19, #0xa
    4c14:	54fffea1 	b.ne	4be8 <fwp_write.constprop.0+0xc18>  // b.any
    4c18:	1e604120 	fmov	d0, d9
    4c1c:	aa1503e0 	mov	x0, x21
    4c20:	52800121 	mov	w1, #0x9                   	// #9
    4c24:	97fff5cf 	bl	2360 <fwp_format_g.constprop.0>
    4c28:	17fffeae 	b	46e0 <fwp_write.constprop.0+0x710>
    4c2c:	d37ef6a1 	lsl	x1, x21, #2
    4c30:	b7f809a3 	tbnz	x3, #63, 4d64 <fwp_write.constprop.0+0xd94>
    4c34:	91002263 	add	x3, x19, #0x8
    4c38:	8b010061 	add	x1, x3, x1
    4c3c:	b9400023 	ldr	w3, [x1]
    4c40:	7100081f 	cmp	w0, #0x2
    4c44:	2a0303e1 	mov	w1, w3
    4c48:	93407c63 	sxtw	x3, w3
    4c4c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4c50:	17fffe16 	b	44a8 <fwp_write.constprop.0+0x4d8>
    4c54:	d37ffaa1 	lsl	x1, x21, #1
    4c58:	b7f80803 	tbnz	x3, #63, 4d58 <fwp_write.constprop.0+0xd88>
    4c5c:	91002263 	add	x3, x19, #0x8
    4c60:	8b010061 	add	x1, x3, x1
    4c64:	79400021 	ldrh	w1, [x1]
    4c68:	7100041f 	cmp	w0, #0x1
    4c6c:	93403c23 	sxth	x3, w1
    4c70:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4c74:	17fffe0d 	b	44a8 <fwp_write.constprop.0+0x4d8>
    4c78:	7100103f 	cmp	w1, #0x4
    4c7c:	54ffee01 	b.ne	4a3c <fwp_write.constprop.0+0xa6c>  // b.any
    4c80:	f94006e0 	ldr	x0, [x23, #8]
    4c84:	d37ffc00 	lsr	x0, x0, #63
    4c88:	17fffed0 	b	47c8 <fwp_write.constprop.0+0x7f8>
    4c8c:	710002ff 	cmp	w23, #0x0
    4c90:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4c94:	17fffecd 	b	47c8 <fwp_write.constprop.0+0x7f8>
    4c98:	528005a1 	mov	w1, #0x2d                  	// #45
    4c9c:	eb0203e2 	negs	x2, x2
    4ca0:	da0303e3 	ngc	x3, x3
    4ca4:	910127e0 	add	x0, sp, #0x49
    4ca8:	910123f5 	add	x21, sp, #0x48
    4cac:	390123e1 	strb	w1, [sp, #72]
    4cb0:	97fff36c 	bl	1a60 <fwp_fmt_u128>
    4cb4:	17fffe16 	b	450c <fwp_write.constprop.0+0x53c>
    4cb8:	d37ceea1 	lsl	x1, x21, #4
    4cbc:	b7f80da3 	tbnz	x3, #63, 4e70 <fwp_write.constprop.0+0xea0>
    4cc0:	91002260 	add	x0, x19, #0x8
    4cc4:	8b010001 	add	x1, x0, x1
    4cc8:	17fffdf8 	b	44a8 <fwp_write.constprop.0+0x4d8>
    4ccc:	f9400a61 	ldr	x1, [x19, #16]
    4cd0:	8b010000 	add	x0, x0, x1
    4cd4:	f9400001 	ldr	x1, [x0]
    4cd8:	17fffdf4 	b	44a8 <fwp_write.constprop.0+0x4d8>
    4cdc:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    4ce0:	d2800042 	mov	x2, #0x2                   	// #2
    4ce4:	91046021 	add	x1, x1, #0x118
    4ce8:	17ffff44 	b	49f8 <fwp_write.constprop.0+0xa28>
    4cec:	1e604100 	fmov	d0, d8
    4cf0:	aa1503e0 	mov	x0, x21
    4cf4:	52800221 	mov	w1, #0x11                  	// #17
    4cf8:	97fff59a 	bl	2360 <fwp_format_g.constprop.0>
    4cfc:	17fffe79 	b	46e0 <fwp_write.constprop.0+0x710>
    4d00:	b9401380 	ldr	w0, [x28, #16]
    4d04:	350003c0 	cbnz	w0, 4d7c <fwp_write.constprop.0+0xdac>
    4d08:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    4d0c:	f947f400 	ldr	x0, [x0, #4072]
    4d10:	f94127e2 	ldr	x2, [sp, #584]
    4d14:	f9400001 	ldr	x1, [x0]
    4d18:	eb010042 	subs	x2, x2, x1
    4d1c:	d2800001 	mov	x1, #0x0                   	// #0
    4d20:	54001201 	b.ne	4f60 <fwp_write.constprop.0+0xf90>  // b.any
    4d24:	f9413bf5 	ldr	x21, [sp, #624]
    4d28:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    4d2c:	f9413ff6 	ldr	x22, [sp, #632]
    4d30:	aa1403e0 	mov	x0, x20
    4d34:	f94143f7 	ldr	x23, [sp, #640]
    4d38:	9107c021 	add	x1, x1, #0x1f0
    4d3c:	f94147f8 	ldr	x24, [sp, #648]
    4d40:	d2800042 	mov	x2, #0x2                   	// #2
    4d44:	17fffd26 	b	41dc <fwp_write.constprop.0+0x20c>
    4d48:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    4d4c:	d2800042 	mov	x2, #0x2                   	// #2
    4d50:	91048021 	add	x1, x1, #0x120
    4d54:	17ffff29 	b	49f8 <fwp_write.constprop.0+0xa28>
    4d58:	f9400a63 	ldr	x3, [x19, #16]
    4d5c:	8b030021 	add	x1, x1, x3
    4d60:	17ffffc1 	b	4c64 <fwp_write.constprop.0+0xc94>
    4d64:	f9400a63 	ldr	x3, [x19, #16]
    4d68:	8b030021 	add	x1, x1, x3
    4d6c:	17ffffb4 	b	4c3c <fwp_write.constprop.0+0xc6c>
    4d70:	f9400a61 	ldr	x1, [x19, #16]
    4d74:	8b0102a1 	add	x1, x21, x1
    4d78:	17fffdc7 	b	4494 <fwp_write.constprop.0+0x4c4>
    4d7c:	b9404b80 	ldr	w0, [x28, #72]
    4d80:	91001ff5 	add	x21, sp, #0x7
    4d84:	34ffa660 	cbz	w0, 4250 <fwp_write.constprop.0+0x280>
    4d88:	52800503 	mov	w3, #0x28                  	// #40
    4d8c:	aa1403e0 	mov	x0, x20
    4d90:	aa1503e1 	mov	x1, x21
    4d94:	d2800022 	mov	x2, #0x1                   	// #1
    4d98:	39001fe3 	strb	w3, [sp, #7]
    4d9c:	97fff4dd 	bl	2110 <buf_put>
    4da0:	b9401380 	ldr	w0, [x28, #16]
    4da4:	52800038 	mov	w24, #0x1                   	// #1
    4da8:	7100001f 	cmp	w0, #0x0
    4dac:	54ffa66c 	b.gt	4278 <fwp_write.constprop.0+0x2a8>
    4db0:	17fffd49 	b	42d4 <fwp_write.constprop.0+0x304>
    4db4:	f9014bf9 	str	x25, [sp, #656]
    4db8:	f00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x14da0>
    4dbc:	f9014ffa 	str	x26, [sp, #664]
    4dc0:	f9400676 	ldr	x22, [x19, #8]
    4dc4:	912ca333 	add	x19, x25, #0xb28
    4dc8:	91002273 	add	x19, x19, #0x8
    4dcc:	937ffed8 	asr	x24, x22, #63
    4dd0:	aa1802c0 	orr	x0, x22, x24
    4dd4:	b5000320 	cbnz	x0, 4e38 <fwp_write.constprop.0+0xe68>
    4dd8:	110006b5 	add	w21, w21, #0x1
    4ddc:	710016bf 	cmp	w21, #0x5
    4de0:	54ffffc1 	b.ne	4dd8 <fwp_write.constprop.0+0xe08>  // b.any
    4de4:	b7f80578 	tbnz	x24, #63, 4e90 <fwp_write.constprop.0+0xec0>
    4de8:	910023f3 	add	x19, sp, #0x8
    4dec:	aa1603e2 	mov	x2, x22
    4df0:	aa1303e0 	mov	x0, x19
    4df4:	d2800003 	mov	x3, #0x0                   	// #0
    4df8:	97fff31a 	bl	1a60 <fwp_fmt_u128>
    4dfc:	910123f5 	add	x21, sp, #0x48
    4e00:	b0000023 	adrp	x3, 9000 <_IO_stdin_used+0x1f0>
    4e04:	aa1303e4 	mov	x4, x19
    4e08:	aa1503e0 	mov	x0, x21
    4e0c:	9107a063 	add	x3, x3, #0x1e8
    4e10:	d2804002 	mov	x2, #0x200                 	// #512
    4e14:	52800041 	mov	w1, #0x2                   	// #2
    4e18:	97fff162 	bl	13a0 <__sprintf_chk@plt>
    4e1c:	aa1503e0 	mov	x0, x21
    4e20:	97fff15c 	bl	1390 <strlen@plt>
    4e24:	aa1503e1 	mov	x1, x21
    4e28:	aa0003e2 	mov	x2, x0
    4e2c:	aa1403e0 	mov	x0, x20
    4e30:	97fff4b8 	bl	2110 <buf_put>
    4e34:	17fffe7b 	b	4820 <fwp_write.constprop.0+0x850>
    4e38:	f9400277 	ldr	x23, [x19]
    4e3c:	aa1603e0 	mov	x0, x22
    4e40:	aa1803e1 	mov	x1, x24
    4e44:	aa1703e2 	mov	x2, x23
    4e48:	937ffefa 	asr	x26, x23, #63
    4e4c:	aa1a03e3 	mov	x3, x26
    4e50:	94000f08 	bl	8a70 <__modti3>
    4e54:	aa010000 	orr	x0, x0, x1
    4e58:	b40002c0 	cbz	x0, 4eb0 <fwp_write.constprop.0+0xee0>
    4e5c:	110006b5 	add	w21, w21, #0x1
    4e60:	91004273 	add	x19, x19, #0x10
    4e64:	710016bf 	cmp	w21, #0x5
    4e68:	54fffe81 	b.ne	4e38 <fwp_write.constprop.0+0xe68>  // b.any
    4e6c:	17ffffde 	b	4de4 <fwp_write.constprop.0+0xe14>
    4e70:	f9400a60 	ldr	x0, [x19, #16]
    4e74:	8b000021 	add	x1, x1, x0
    4e78:	17fffd8c 	b	44a8 <fwp_write.constprop.0+0x4d8>
    4e7c:	528c29c0 	mov	w0, #0x614e                	// #24910
    4e80:	910123f5 	add	x21, sp, #0x48
    4e84:	72a009c0 	movk	w0, #0x4e, lsl #16
    4e88:	b9004be0 	str	w0, [sp, #72]
    4e8c:	17fffdb9 	b	4570 <fwp_write.constprop.0+0x5a0>
    4e90:	528005a1 	mov	w1, #0x2d                  	// #45
    4e94:	eb1603e2 	negs	x2, x22
    4e98:	da1803e3 	ngc	x3, x24
    4e9c:	910027e0 	add	x0, sp, #0x9
    4ea0:	910023f3 	add	x19, sp, #0x8
    4ea4:	390023e1 	strb	w1, [sp, #8]
    4ea8:	97fff2ee 	bl	1a60 <fwp_fmt_u128>
    4eac:	17ffffd4 	b	4dfc <fwp_write.constprop.0+0xe2c>
    4eb0:	aa1703e2 	mov	x2, x23
    4eb4:	aa1a03e3 	mov	x3, x26
    4eb8:	aa1603e0 	mov	x0, x22
    4ebc:	aa1803e1 	mov	x1, x24
    4ec0:	94000e0c 	bl	86f0 <__divti3>
    4ec4:	aa0003e2 	mov	x2, x0
    4ec8:	aa0103e3 	mov	x3, x1
    4ecc:	b7f80201 	tbnz	x1, #63, 4f0c <fwp_write.constprop.0+0xf3c>
    4ed0:	910023f3 	add	x19, sp, #0x8
    4ed4:	aa1303e0 	mov	x0, x19
    4ed8:	97fff2e2 	bl	1a60 <fwp_fmt_u128>
    4edc:	937c7ea1 	sbfiz	x1, x21, #4, #32
    4ee0:	912ca339 	add	x25, x25, #0xb28
    4ee4:	910123f5 	add	x21, sp, #0x48
    4ee8:	aa1303e4 	mov	x4, x19
    4eec:	aa1503e0 	mov	x0, x21
    4ef0:	b0000023 	adrp	x3, 9000 <_IO_stdin_used+0x1f0>
    4ef4:	f8616b25 	ldr	x5, [x25, x1]
    4ef8:	91078063 	add	x3, x3, #0x1e0
    4efc:	d2804002 	mov	x2, #0x200                 	// #512
    4f00:	52800041 	mov	w1, #0x2                   	// #2
    4f04:	97fff127 	bl	13a0 <__sprintf_chk@plt>
    4f08:	17ffffc5 	b	4e1c <fwp_write.constprop.0+0xe4c>
    4f0c:	528005a4 	mov	w4, #0x2d                  	// #45
    4f10:	eb0003e2 	negs	x2, x0
    4f14:	da0103e3 	ngc	x3, x1
    4f18:	910027e0 	add	x0, sp, #0x9
    4f1c:	910023f3 	add	x19, sp, #0x8
    4f20:	390023e4 	strb	w4, [sp, #8]
    4f24:	97fff2cf 	bl	1a60 <fwp_fmt_u128>
    4f28:	17ffffed 	b	4edc <fwp_write.constprop.0+0xf0c>
    4f2c:	f9013bf5 	str	x21, [sp, #624]
    4f30:	f9013ff6 	str	x22, [sp, #632]
    4f34:	f90143f7 	str	x23, [sp, #640]
    4f38:	f90147f8 	str	x24, [sp, #648]
    4f3c:	f9014bf9 	str	x25, [sp, #656]
    4f40:	f9014ffa 	str	x26, [sp, #664]
    4f44:	f90153fb 	str	x27, [sp, #672]
    4f48:	f90157fc 	str	x28, [sp, #680]
    4f4c:	fd015be8 	str	d8, [sp, #688]
    4f50:	fd015fe9 	str	d9, [sp, #696]
    4f54:	97fff16b 	bl	1500 <__stack_chk_fail@plt>
    4f58:	f90143f7 	str	x23, [sp, #640]
    4f5c:	f90147f8 	str	x24, [sp, #648]
    4f60:	f9014bf9 	str	x25, [sp, #656]
    4f64:	f9014ffa 	str	x26, [sp, #664]
    4f68:	fd015be8 	str	d8, [sp, #688]
    4f6c:	fd015fe9 	str	d9, [sp, #696]
    4f70:	97fff164 	bl	1500 <__stack_chk_fail@plt>

0000000000004f74 <fwp_hof0.constprop.0>:
    4f74:	d10303ff 	sub	sp, sp, #0xc0
    4f78:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x14da0>
    4f7c:	f947f442 	ldr	x2, [x2, #4072]
    4f80:	a9047bfd 	stp	x29, x30, [sp, #64]
    4f84:	910103fd 	add	x29, sp, #0x40
    4f88:	a9065bf5 	stp	x21, x22, [sp, #96]
    4f8c:	aa0003f5 	mov	x21, x0
    4f90:	f9400040 	ldr	x0, [x2]
    4f94:	f9001fe0 	str	x0, [sp, #56]
    4f98:	d2800000 	mov	x0, #0x0                   	// #0
    4f9c:	f90007e1 	str	x1, [sp, #8]
    4fa0:	b4004501 	cbz	x1, 5840 <fwp_hof0.constprop.0+0x8cc>
    4fa4:	b0000021 	adrp	x1, 9000 <_IO_stdin_used+0x1f0>
    4fa8:	6d0a27e8 	stp	d8, d9, [sp, #160]
    4fac:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    4fb0:	fd428829 	ldr	d9, [x1, #1296]
    4fb4:	9e670008 	fmov	d8, x0
    4fb8:	a90553f3 	stp	x19, x20, [sp, #80]
    4fbc:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc80>
    4fc0:	a90763f7 	stp	x23, x24, [sp, #112]
    4fc4:	a9086bf9 	stp	x25, x26, [sp, #128]
    4fc8:	a90973fb 	stp	x27, x28, [sp, #144]
    4fcc:	fd005bea 	str	d10, [sp, #176]
    4fd0:	91158282 	add	x2, x20, #0x560
    4fd4:	f949d840 	ldr	x0, [x2, #5040]
    4fd8:	f949ec41 	ldr	x1, [x2, #5080]
    4fdc:	cb0002a0 	sub	x0, x21, x0
    4fe0:	eb01401f 	cmp	x0, x1, lsl #16
    4fe4:	54000422 	b.cs	5068 <fwp_hof0.constprop.0+0xf4>  // b.hs, b.nlast
    4fe8:	d350fc01 	lsr	x1, x0, #16
    4fec:	f949fc43 	ldr	x3, [x2, #5112]
    4ff0:	8b010821 	add	x1, x1, x1, lsl #2
    4ff4:	d37df021 	lsl	x1, x1, #3
    4ff8:	8b010062 	add	x2, x3, x1
    4ffc:	f9401053 	ldr	x19, [x2, #32]
    5000:	b4000353 	cbz	x19, 5068 <fwp_hof0.constprop.0+0xf4>
    5004:	38616861 	ldrb	w1, [x3, x1]
    5008:	7100083f 	cmp	w1, #0x2
    500c:	54004e20 	b.eq	59d0 <fwp_hof0.constprop.0+0xa5c>  // b.none
    5010:	7100043f 	cmp	w1, #0x1
    5014:	540002a1 	b.ne	5068 <fwp_hof0.constprop.0+0xf4>  // b.any
    5018:	29430443 	ldp	w3, w1, [x2, #24]
    501c:	92403c00 	and	x0, x0, #0xffff
    5020:	9b037c00 	mul	x0, x0, x3
    5024:	d360fc00 	lsr	x0, x0, #32
    5028:	eb01001f 	cmp	x0, x1
    502c:	540001e2 	b.cs	5068 <fwp_hof0.constprop.0+0xf4>  // b.hs, b.nlast
    5030:	8b000273 	add	x19, x19, x0
    5034:	39400260 	ldrb	w0, [x19]
    5038:	34000180 	cbz	w0, 5068 <fwp_hof0.constprop.0+0xf4>
    503c:	f00000c1 	adrp	x1, 20000 <__data_start>
    5040:	91020021 	add	x1, x1, #0x80
    5044:	b9404022 	ldr	w2, [x1, #64]
    5048:	34000082 	cbz	w2, 5058 <fwp_hof0.constprop.0+0xe4>
    504c:	f9416422 	ldr	x2, [x1, #712]
    5050:	91000442 	add	x2, x2, #0x1
    5054:	f9016422 	str	x2, [x1, #712]
    5058:	7103f41f 	cmp	w0, #0xfd
    505c:	54005688 	b.hi	5b2c <fwp_hof0.constprop.0+0xbb8>  // b.pmore
    5060:	11000400 	add	w0, w0, #0x1
    5064:	39000260 	strb	w0, [x19]
    5068:	b4004bb5 	cbz	x21, 59dc <fwp_hof0.constprop.0+0xa68>
    506c:	aa1503e1 	mov	x1, x21
    5070:	d2800000 	mov	x0, #0x0                   	// #0
    5074:	d503201f 	nop
    5078:	f9400821 	ldr	x1, [x1, #16]
    507c:	91000400 	add	x0, x0, #0x1
    5080:	b5ffffc1 	cbnz	x1, 5078 <fwp_hof0.constprop.0+0x104>
    5084:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    5088:	eb01001f 	cmp	x0, x1
    508c:	54005e48 	b.hi	5c54 <fwp_hof0.constprop.0+0xce0>  // b.pmore
    5090:	97fffa10 	bl	38d0 <fwp_array_new_packed.constprop.0>
    5094:	aa0003f7 	mov	x23, x0
    5098:	91158281 	add	x1, x20, #0x560
    509c:	aa0103e0 	mov	x0, x1
    50a0:	f949d821 	ldr	x1, [x1, #5040]
    50a4:	f949ec00 	ldr	x0, [x0, #5080]
    50a8:	cb0102e1 	sub	x1, x23, x1
    50ac:	eb00403f 	cmp	x1, x0, lsl #16
    50b0:	54000362 	b.cs	511c <fwp_hof0.constprop.0+0x1a8>  // b.hs, b.nlast
    50b4:	91158282 	add	x2, x20, #0x560
    50b8:	d350fc20 	lsr	x0, x1, #16
    50bc:	8b000800 	add	x0, x0, x0, lsl #2
    50c0:	f949fc43 	ldr	x3, [x2, #5112]
    50c4:	d37df002 	lsl	x2, x0, #3
    50c8:	8b020060 	add	x0, x3, x2
    50cc:	f9401013 	ldr	x19, [x0, #32]
    50d0:	b4000253 	cbz	x19, 5118 <fwp_hof0.constprop.0+0x1a4>
    50d4:	38626862 	ldrb	w2, [x3, x2]
    50d8:	7100085f 	cmp	w2, #0x2
    50dc:	54004980 	b.eq	5a0c <fwp_hof0.constprop.0+0xa98>  // b.none
    50e0:	7100045f 	cmp	w2, #0x1
    50e4:	540001a1 	b.ne	5118 <fwp_hof0.constprop.0+0x1a4>  // b.any
    50e8:	29430002 	ldp	w2, w0, [x0, #24]
    50ec:	92403c21 	and	x1, x1, #0xffff
    50f0:	9b027c21 	mul	x1, x1, x2
    50f4:	d360fc21 	lsr	x1, x1, #32
    50f8:	eb00003f 	cmp	x1, x0
    50fc:	540000e2 	b.cs	5118 <fwp_hof0.constprop.0+0x1a4>  // b.hs, b.nlast
    5100:	8b010273 	add	x19, x19, x1
    5104:	39400260 	ldrb	w0, [x19]
    5108:	7103fc1f 	cmp	w0, #0xff
    510c:	540048a0 	b.eq	5a20 <fwp_hof0.constprop.0+0xaac>  // b.none
    5110:	52800020 	mov	w0, #0x1                   	// #1
    5114:	39000260 	strb	w0, [x19]
    5118:	b4004775 	cbz	x21, 5a04 <fwp_hof0.constprop.0+0xa90>
    511c:	910022f8 	add	x24, x23, #0x8
    5120:	aa1503e0 	mov	x0, x21
    5124:	aa1503f3 	mov	x19, x21
    5128:	91158299 	add	x25, x20, #0x560
    512c:	5280003a 	mov	w26, #0x1                   	// #1
    5130:	14000014 	b	5180 <fwp_hof0.constprop.0+0x20c>
    5134:	7100045f 	cmp	w2, #0x1
    5138:	54000181 	b.ne	5168 <fwp_hof0.constprop.0+0x1f4>  // b.any
    513c:	294308e8 	ldp	w8, w2, [x7, #24]
    5140:	92403c21 	and	x1, x1, #0xffff
    5144:	9b087c21 	mul	x1, x1, x8
    5148:	d360fc21 	lsr	x1, x1, #32
    514c:	eb02003f 	cmp	x1, x2
    5150:	540000c2 	b.cs	5168 <fwp_hof0.constprop.0+0x1f4>  // b.hs, b.nlast
    5154:	8b0100c6 	add	x6, x6, x1
    5158:	394000c1 	ldrb	w1, [x6]
    515c:	7100043f 	cmp	w1, #0x1
    5160:	54000400 	b.eq	51e0 <fwp_hof0.constprop.0+0x26c>  // b.none
    5164:	d503201f 	nop
    5168:	f94002e1 	ldr	x1, [x23]
    516c:	b7f85401 	tbnz	x1, #63, 5bec <fwp_hof0.constprop.0+0xc78>
    5170:	f9000304 	str	x4, [x24]
    5174:	5280001a 	mov	w26, #0x0                   	// #0
    5178:	91002318 	add	x24, x24, #0x8
    517c:	b4000773 	cbz	x19, 5268 <fwp_hof0.constprop.0+0x2f4>
    5180:	aa1303e5 	mov	x5, x19
    5184:	aa1303e3 	mov	x3, x19
    5188:	a940ce64 	ldp	x4, x19, [x19, #8]
    518c:	34fffefa 	cbz	w26, 5168 <fwp_hof0.constprop.0+0x1f4>
    5190:	f949db21 	ldr	x1, [x25, #5040]
    5194:	f949ef22 	ldr	x2, [x25, #5080]
    5198:	cb0100a1 	sub	x1, x5, x1
    519c:	eb02403f 	cmp	x1, x2, lsl #16
    51a0:	54fffe42 	b.cs	5168 <fwp_hof0.constprop.0+0x1f4>  // b.hs, b.nlast
    51a4:	d350fc22 	lsr	x2, x1, #16
    51a8:	f949ff28 	ldr	x8, [x25, #5112]
    51ac:	8b020842 	add	x2, x2, x2, lsl #2
    51b0:	d37df042 	lsl	x2, x2, #3
    51b4:	8b020107 	add	x7, x8, x2
    51b8:	f94010e6 	ldr	x6, [x7, #32]
    51bc:	b4fffd66 	cbz	x6, 5168 <fwp_hof0.constprop.0+0x1f4>
    51c0:	38626902 	ldrb	w2, [x8, x2]
    51c4:	7100085f 	cmp	w2, #0x2
    51c8:	54fffb61 	b.ne	5134 <fwp_hof0.constprop.0+0x1c0>  // b.any
    51cc:	72003c3f 	tst	w1, #0xffff
    51d0:	54fffcc1 	b.ne	5168 <fwp_hof0.constprop.0+0x1f4>  // b.any
    51d4:	394000c1 	ldrb	w1, [x6]
    51d8:	7100043f 	cmp	w1, #0x1
    51dc:	54fffc61 	b.ne	5168 <fwp_hof0.constprop.0+0x1f4>  // b.any
    51e0:	f94002e0 	ldr	x0, [x23]
    51e4:	b7f85040 	tbnz	x0, #63, 5bec <fwp_hof0.constprop.0+0xc78>
    51e8:	f9000304 	str	x4, [x24]
    51ec:	f949db21 	ldr	x1, [x25, #5040]
    51f0:	f949ef20 	ldr	x0, [x25, #5080]
    51f4:	cb010063 	sub	x3, x3, x1
    51f8:	eb00407f 	cmp	x3, x0, lsl #16
    51fc:	540002e2 	b.cs	5258 <fwp_hof0.constprop.0+0x2e4>  // b.hs, b.nlast
    5200:	d350fc60 	lsr	x0, x3, #16
    5204:	f949ff21 	ldr	x1, [x25, #5112]
    5208:	8b000800 	add	x0, x0, x0, lsl #2
    520c:	d37df000 	lsl	x0, x0, #3
    5210:	8b000024 	add	x4, x1, x0
    5214:	f9401082 	ldr	x2, [x4, #32]
    5218:	b4000202 	cbz	x2, 5258 <fwp_hof0.constprop.0+0x2e4>
    521c:	38606820 	ldrb	w0, [x1, x0]
    5220:	7100081f 	cmp	w0, #0x2
    5224:	54003b20 	b.eq	5988 <fwp_hof0.constprop.0+0xa14>  // b.none
    5228:	7100041f 	cmp	w0, #0x1
    522c:	54000161 	b.ne	5258 <fwp_hof0.constprop.0+0x2e4>  // b.any
    5230:	29430086 	ldp	w6, w0, [x4, #24]
    5234:	92403c61 	and	x1, x3, #0xffff
    5238:	9b067c21 	mul	x1, x1, x6
    523c:	d360fc21 	lsr	x1, x1, #32
    5240:	eb00003f 	cmp	x1, x0
    5244:	540000a2 	b.cs	5258 <fwp_hof0.constprop.0+0x2e4>  // b.hs, b.nlast
    5248:	8b010042 	add	x2, x2, x1
    524c:	39400040 	ldrb	w0, [x2]
    5250:	7100041f 	cmp	w0, #0x1
    5254:	54000e40 	b.eq	541c <fwp_hof0.constprop.0+0x4a8>  // b.none
    5258:	aa1303e0 	mov	x0, x19
    525c:	91002318 	add	x24, x24, #0x8
    5260:	b5fff913 	cbnz	x19, 5180 <fwp_hof0.constprop.0+0x20c>
    5264:	d503201f 	nop
    5268:	97fffa02 	bl	3a70 <fwp_drop0>
    526c:	d28018d9 	mov	x25, #0xc6                  	// #198
    5270:	d2f80f20 	mov	x0, #0xc079000000000000    	// #-4577627546245398528
    5274:	9e67000a 	fmov	d10, x0
    5278:	f94002f8 	ldr	x24, [x23]
    527c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    5280:	9240fb18 	and	x24, x24, #0x7fffffffffffffff
    5284:	eb00031f 	cmp	x24, x0
    5288:	54004e68 	b.hi	5c54 <fwp_hof0.constprop.0+0xce0>  // b.pmore
    528c:	aa1803e0 	mov	x0, x24
    5290:	97fff990 	bl	38d0 <fwp_array_new_packed.constprop.0>
    5294:	91158282 	add	x2, x20, #0x560
    5298:	aa0003f3 	mov	x19, x0
    529c:	f949d841 	ldr	x1, [x2, #5040]
    52a0:	f949ec40 	ldr	x0, [x2, #5080]
    52a4:	cb010261 	sub	x1, x19, x1
    52a8:	eb00403f 	cmp	x1, x0, lsl #16
    52ac:	54000322 	b.cs	5310 <fwp_hof0.constprop.0+0x39c>  // b.hs, b.nlast
    52b0:	d350fc20 	lsr	x0, x1, #16
    52b4:	f949fc43 	ldr	x3, [x2, #5112]
    52b8:	8b000800 	add	x0, x0, x0, lsl #2
    52bc:	d37df002 	lsl	x2, x0, #3
    52c0:	8b020060 	add	x0, x3, x2
    52c4:	f940101a 	ldr	x26, [x0, #32]
    52c8:	b400025a 	cbz	x26, 5310 <fwp_hof0.constprop.0+0x39c>
    52cc:	38626862 	ldrb	w2, [x3, x2]
    52d0:	7100085f 	cmp	w2, #0x2
    52d4:	54003040 	b.eq	58dc <fwp_hof0.constprop.0+0x968>  // b.none
    52d8:	7100045f 	cmp	w2, #0x1
    52dc:	540001a1 	b.ne	5310 <fwp_hof0.constprop.0+0x39c>  // b.any
    52e0:	29430002 	ldp	w2, w0, [x0, #24]
    52e4:	92403c21 	and	x1, x1, #0xffff
    52e8:	9b027c21 	mul	x1, x1, x2
    52ec:	d360fc21 	lsr	x1, x1, #32
    52f0:	eb00003f 	cmp	x1, x0
    52f4:	540000e2 	b.cs	5310 <fwp_hof0.constprop.0+0x39c>  // b.hs, b.nlast
    52f8:	8b01035a 	add	x26, x26, x1
    52fc:	39400340 	ldrb	w0, [x26]
    5300:	7103fc1f 	cmp	w0, #0xff
    5304:	54002f60 	b.eq	58f0 <fwp_hof0.constprop.0+0x97c>  // b.none
    5308:	52800020 	mov	w0, #0x1                   	// #1
    530c:	39000340 	strb	w0, [x26]
    5310:	b40008f8 	cbz	x24, 542c <fwp_hof0.constprop.0+0x4b8>
    5314:	aa1703e8 	mov	x8, x23
    5318:	d2800004 	mov	x4, #0x0                   	// #0
    531c:	d2800025 	mov	x5, #0x1                   	// #1
    5320:	d2800003 	mov	x3, #0x0                   	// #0
    5324:	9e6703e1 	fmov	d1, xzr
    5328:	1e6e1005 	fmov	d5, #1.000000000000000000e+00
    532c:	f8408506 	ldr	x6, [x8], #8
    5330:	9240f8c2 	and	x2, x6, #0x7fffffffffffffff
    5334:	aa0803e7 	mov	x7, x8
    5338:	eb0200bf 	cmp	x5, x2
    533c:	54000640 	b.eq	5404 <fwp_hof0.constprop.0+0x490>  // b.none
    5340:	eb02009f 	cmp	x4, x2
    5344:	54000642 	b.cs	540c <fwp_hof0.constprop.0+0x498>  // b.hs, b.nlast
    5348:	b7f82a46 	tbnz	x6, #63, 5890 <fwp_hof0.constprop.0+0x91c>
    534c:	fd4000e2 	ldr	d2, [x7]
    5350:	aa0803e0 	mov	x0, x8
    5354:	1e6238a3 	fsub	d3, d5, d2
    5358:	1e6a0844 	fmul	d4, d2, d10
    535c:	1e632863 	fadd	d3, d3, d3
    5360:	1e620842 	fmul	d2, d2, d2
    5364:	eb0200bf 	cmp	x5, x2
    5368:	54000522 	b.cs	540c <fwp_hof0.constprop.0+0x498>  // b.hs, b.nlast
    536c:	8b030000 	add	x0, x0, x3
    5370:	fd400400 	ldr	d0, [x0, #8]
    5374:	1e623800 	fsub	d0, d0, d2
    5378:	1e640800 	fmul	d0, d0, d4
    537c:	1e633800 	fsub	d0, d0, d3
    5380:	1e612800 	fadd	d0, d0, d1
    5384:	1e690800 	fmul	d0, d0, d9
    5388:	aa0803e0 	mov	x0, x8
    538c:	b7f82726 	tbnz	x6, #63, 5870 <fwp_hof0.constprop.0+0x8fc>
    5390:	fc636801 	ldr	d1, [x0, x3]
    5394:	f9400260 	ldr	x0, [x19]
    5398:	1e603821 	fsub	d1, d1, d0
    539c:	b7f84280 	tbnz	x0, #63, 5bec <fwp_hof0.constprop.0+0xc78>
    53a0:	8b130062 	add	x2, x3, x19
    53a4:	91000481 	add	x1, x4, #0x1
    53a8:	fd000441 	str	d1, [x2, #8]
    53ac:	eb01031f 	cmp	x24, x1
    53b0:	540003e0 	b.eq	542c <fwp_hof0.constprop.0+0x4b8>  // b.none
    53b4:	f94002e6 	ldr	x6, [x23]
    53b8:	9240f8c2 	and	x2, x6, #0x7fffffffffffffff
    53bc:	eb04005f 	cmp	x2, x4
    53c0:	54000269 	b.ls	540c <fwp_hof0.constprop.0+0x498>  // b.plast
    53c4:	91002060 	add	x0, x3, #0x8
    53c8:	b7f82586 	tbnz	x6, #63, 5878 <fwp_hof0.constprop.0+0x904>
    53cc:	fc776800 	ldr	d0, [x0, x23]
    53d0:	aa0803e4 	mov	x4, x8
    53d4:	1e600800 	fmul	d0, d0, d0
    53d8:	eb02003f 	cmp	x1, x2
    53dc:	54000182 	b.cs	540c <fwp_hof0.constprop.0+0x498>  // b.hs, b.nlast
    53e0:	fc606881 	ldr	d1, [x4, x0]
    53e4:	910004a5 	add	x5, x5, #0x1
    53e8:	910020e7 	add	x7, x7, #0x8
    53ec:	aa0103e4 	mov	x4, x1
    53f0:	aa0003e3 	mov	x3, x0
    53f4:	1e603821 	fsub	d1, d1, d0
    53f8:	1e680821 	fmul	d1, d1, d8
    53fc:	eb0200bf 	cmp	x5, x2
    5400:	54fffa01 	b.ne	5340 <fwp_hof0.constprop.0+0x3cc>  // b.any
    5404:	eb05009f 	cmp	x4, x5
    5408:	540043e3 	b.cc	5c84 <fwp_hof0.constprop.0+0xd10>  // b.lo, b.ul, b.last
    540c:	f00000c0 	adrp	x0, 20000 <__data_start>
    5410:	91004000 	add	x0, x0, #0x10
    5414:	9100a000 	add	x0, x0, #0x28
    5418:	97fff39a 	bl	2280 <fwp_trap>
    541c:	aa0503e0 	mov	x0, x5
    5420:	97fff6f8 	bl	3000 <fwp_mem_free>
    5424:	aa1303e0 	mov	x0, x19
    5428:	17ffff8d 	b	525c <fwp_hof0.constprop.0+0x2e8>
    542c:	9115829a 	add	x26, x20, #0x560
    5430:	f949db41 	ldr	x1, [x26, #5040]
    5434:	f949ef40 	ldr	x0, [x26, #5080]
    5438:	cb0102e1 	sub	x1, x23, x1
    543c:	eb00403f 	cmp	x1, x0, lsl #16
    5440:	54000382 	b.cs	54b0 <fwp_hof0.constprop.0+0x53c>  // b.hs, b.nlast
    5444:	d350fc20 	lsr	x0, x1, #16
    5448:	f949ff42 	ldr	x2, [x26, #5112]
    544c:	8b000800 	add	x0, x0, x0, lsl #2
    5450:	d37df000 	lsl	x0, x0, #3
    5454:	8b000043 	add	x3, x2, x0
    5458:	f9401078 	ldr	x24, [x3, #32]
    545c:	b40002b8 	cbz	x24, 54b0 <fwp_hof0.constprop.0+0x53c>
    5460:	38606840 	ldrb	w0, [x2, x0]
    5464:	7100081f 	cmp	w0, #0x2
    5468:	540021e0 	b.eq	58a4 <fwp_hof0.constprop.0+0x930>  // b.none
    546c:	7100041f 	cmp	w0, #0x1
    5470:	54000201 	b.ne	54b0 <fwp_hof0.constprop.0+0x53c>  // b.any
    5474:	29430064 	ldp	w4, w0, [x3, #24]
    5478:	92403c21 	and	x1, x1, #0xffff
    547c:	9b047c21 	mul	x1, x1, x4
    5480:	d360fc21 	lsr	x1, x1, #32
    5484:	eb00003f 	cmp	x1, x0
    5488:	54000142 	b.cs	54b0 <fwp_hof0.constprop.0+0x53c>  // b.hs, b.nlast
    548c:	8b010318 	add	x24, x24, x1
    5490:	39400300 	ldrb	w0, [x24]
    5494:	340000e0 	cbz	w0, 54b0 <fwp_hof0.constprop.0+0x53c>
    5498:	7100041f 	cmp	w0, #0x1
    549c:	54000140 	b.eq	54c4 <fwp_hof0.constprop.0+0x550>  // b.none
    54a0:	7103fc1f 	cmp	w0, #0xff
    54a4:	54002c40 	b.eq	5a2c <fwp_hof0.constprop.0+0xab8>  // b.none
    54a8:	51000400 	sub	w0, w0, #0x1
    54ac:	39000300 	strb	w0, [x24]
    54b0:	b40004d9 	cbz	x25, 5548 <fwp_hof0.constprop.0+0x5d4>
    54b4:	f1000739 	subs	x25, x25, #0x1
    54b8:	54004006 	b.vs	5cb8 <fwp_hof0.constprop.0+0xd44>
    54bc:	aa1303f7 	mov	x23, x19
    54c0:	17ffff6e 	b	5278 <fwp_hof0.constprop.0+0x304>
    54c4:	f94002e0 	ldr	x0, [x23]
    54c8:	b7f81f40 	tbnz	x0, #63, 58b0 <fwp_hof0.constprop.0+0x93c>
    54cc:	91158281 	add	x1, x20, #0x560
    54d0:	f949d820 	ldr	x0, [x1, #5040]
    54d4:	f949ec21 	ldr	x1, [x1, #5080]
    54d8:	cb0002e0 	sub	x0, x23, x0
    54dc:	eb01401f 	cmp	x0, x1, lsl #16
    54e0:	54fffe82 	b.cs	54b0 <fwp_hof0.constprop.0+0x53c>  // b.hs, b.nlast
    54e4:	d350fc01 	lsr	x1, x0, #16
    54e8:	8b010821 	add	x1, x1, x1, lsl #2
    54ec:	d37df021 	lsl	x1, x1, #3
    54f0:	8b010044 	add	x4, x2, x1
    54f4:	f9401083 	ldr	x3, [x4, #32]
    54f8:	b4fffdc3 	cbz	x3, 54b0 <fwp_hof0.constprop.0+0x53c>
    54fc:	38616841 	ldrb	w1, [x2, x1]
    5500:	7100083f 	cmp	w1, #0x2
    5504:	54001fc0 	b.eq	58fc <fwp_hof0.constprop.0+0x988>  // b.none
    5508:	7100043f 	cmp	w1, #0x1
    550c:	54fffd21 	b.ne	54b0 <fwp_hof0.constprop.0+0x53c>  // b.any
    5510:	29430482 	ldp	w2, w1, [x4, #24]
    5514:	92403c00 	and	x0, x0, #0xffff
    5518:	9b027c00 	mul	x0, x0, x2
    551c:	d360fc00 	lsr	x0, x0, #32
    5520:	eb01001f 	cmp	x0, x1
    5524:	54fffc62 	b.cs	54b0 <fwp_hof0.constprop.0+0x53c>  // b.hs, b.nlast
    5528:	8b000063 	add	x3, x3, x0
    552c:	39400060 	ldrb	w0, [x3]
    5530:	7100041f 	cmp	w0, #0x1
    5534:	54fffbe1 	b.ne	54b0 <fwp_hof0.constprop.0+0x53c>  // b.any
    5538:	aa1703e0 	mov	x0, x23
    553c:	97fff6b1 	bl	3000 <fwp_mem_free>
    5540:	b5fffbb9 	cbnz	x25, 54b4 <fwp_hof0.constprop.0+0x540>
    5544:	d503201f 	nop
    5548:	52800b63 	mov	w3, #0x5b                  	// #91
    554c:	91007ffc 	add	x28, sp, #0x1f
    5550:	910083f7 	add	x23, sp, #0x20
    5554:	aa1c03e1 	mov	x1, x28
    5558:	aa1703e0 	mov	x0, x23
    555c:	d2800022 	mov	x2, #0x1                   	// #1
    5560:	39007fe3 	strb	w3, [sp, #31]
    5564:	d2800016 	mov	x22, #0x0                   	// #0
    5568:	a9027fff 	stp	xzr, xzr, [sp, #32]
    556c:	d00000d8 	adrp	x24, 1f000 <__FRAME_END__+0x14da0>
    5570:	f9001bff 	str	xzr, [sp, #48]
    5574:	97fff2e7 	bl	2110 <buf_put>
    5578:	f9400260 	ldr	x0, [x19]
    557c:	f240f81a 	ands	x26, x0, #0x7fffffffffffffff
    5580:	540003c0 	b.eq	55f8 <fwp_hof0.constprop.0+0x684>  // b.none
    5584:	912ca318 	add	x24, x24, #0xb28
    5588:	90000039 	adrp	x25, 9000 <_IO_stdin_used+0x1f0>
    558c:	91014318 	add	x24, x24, #0x50
    5590:	9106e339 	add	x25, x25, #0x1b8
    5594:	9100227b 	add	x27, x19, #0x8
    5598:	1400000d 	b	55cc <fwp_hof0.constprop.0+0x658>
    559c:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    55a0:	aa1803e2 	mov	x2, x24
    55a4:	aa1703e0 	mov	x0, x23
    55a8:	910006d6 	add	x22, x22, #0x1
    55ac:	97fffa89 	bl	3fd0 <fwp_write.constprop.0>
    55b0:	eb16035f 	cmp	x26, x22
    55b4:	54000220 	b.eq	55f8 <fwp_hof0.constprop.0+0x684>  // b.none
    55b8:	aa1703e0 	mov	x0, x23
    55bc:	aa1903e1 	mov	x1, x25
    55c0:	d2800042 	mov	x2, #0x2                   	// #2
    55c4:	97fff2d3 	bl	2110 <buf_put>
    55c8:	f9400260 	ldr	x0, [x19]
    55cc:	aa1b03e1 	mov	x1, x27
    55d0:	b6fffe60 	tbz	x0, #63, 559c <fwp_hof0.constprop.0+0x628>
    55d4:	f9400a61 	ldr	x1, [x19, #16]
    55d8:	aa1803e2 	mov	x2, x24
    55dc:	aa1703e0 	mov	x0, x23
    55e0:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    55e4:	910006d6 	add	x22, x22, #0x1
    55e8:	97fffa7a 	bl	3fd0 <fwp_write.constprop.0>
    55ec:	eb16035f 	cmp	x26, x22
    55f0:	54fffe41 	b.ne	55b8 <fwp_hof0.constprop.0+0x644>  // b.any
    55f4:	d503201f 	nop
    55f8:	52800ba3 	mov	w3, #0x5d                  	// #93
    55fc:	aa1703e0 	mov	x0, x23
    5600:	aa1c03e1 	mov	x1, x28
    5604:	d2800022 	mov	x2, #0x1                   	// #1
    5608:	39007fe3 	strb	w3, [sp, #31]
    560c:	97fff2c1 	bl	2110 <buf_put>
    5610:	a94263f9 	ldp	x25, x24, [sp, #32]
    5614:	f0000000 	adrp	x0, 8000 <f0+0x2340>
    5618:	91394000 	add	x0, x0, #0xe50
    561c:	f100033f 	cmp	x25, #0x0
    5620:	9a990019 	csel	x25, x0, x25, eq	// eq = none
    5624:	b1002b1f 	cmn	x24, #0xa
    5628:	540031c8 	b.hi	5c60 <fwp_hof0.constprop.0+0xcec>  // b.pmore
    562c:	91002700 	add	x0, x24, #0x9
    5630:	52800021 	mov	w1, #0x1                   	// #1
    5634:	97fff7e4 	bl	35c4 <fwp_heap_alloc>
    5638:	aa0003f7 	mov	x23, x0
    563c:	aa1903e1 	mov	x1, x25
    5640:	aa0003f9 	mov	x25, x0
    5644:	aa1803e2 	mov	x2, x24
    5648:	f8008738 	str	x24, [x25], #8
    564c:	8b1802f8 	add	x24, x23, x24
    5650:	aa1903e0 	mov	x0, x25
    5654:	97ffef43 	bl	1360 <memcpy@plt>
    5658:	f94013e0 	ldr	x0, [sp, #32]
    565c:	3900231f 	strb	wzr, [x24, #8]
    5660:	97ffefd8 	bl	15c0 <free@plt>
    5664:	91158282 	add	x2, x20, #0x560
    5668:	f949ec43 	ldr	x3, [x2, #5080]
    566c:	f949d841 	ldr	x1, [x2, #5040]
    5670:	d370bc63 	lsl	x3, x3, #16
    5674:	cb0102e4 	sub	x4, x23, x1
    5678:	eb03009f 	cmp	x4, x3
    567c:	540003a2 	b.cs	56f0 <fwp_hof0.constprop.0+0x77c>  // b.hs, b.nlast
    5680:	d350fc80 	lsr	x0, x4, #16
    5684:	f949fc45 	ldr	x5, [x2, #5112]
    5688:	8b000800 	add	x0, x0, x0, lsl #2
    568c:	d37df002 	lsl	x2, x0, #3
    5690:	8b0200a0 	add	x0, x5, x2
    5694:	f9401018 	ldr	x24, [x0, #32]
    5698:	b40002d8 	cbz	x24, 56f0 <fwp_hof0.constprop.0+0x77c>
    569c:	386268a2 	ldrb	w2, [x5, x2]
    56a0:	7100085f 	cmp	w2, #0x2
    56a4:	54001f00 	b.eq	5a84 <fwp_hof0.constprop.0+0xb10>  // b.none
    56a8:	7100045f 	cmp	w2, #0x1
    56ac:	54000221 	b.ne	56f0 <fwp_hof0.constprop.0+0x77c>  // b.any
    56b0:	29430005 	ldp	w5, w0, [x0, #24]
    56b4:	92403c82 	and	x2, x4, #0xffff
    56b8:	9b057c42 	mul	x2, x2, x5
    56bc:	d360fc42 	lsr	x2, x2, #32
    56c0:	eb00005f 	cmp	x2, x0
    56c4:	54000162 	b.cs	56f0 <fwp_hof0.constprop.0+0x77c>  // b.hs, b.nlast
    56c8:	8b020318 	add	x24, x24, x2
    56cc:	39400300 	ldrb	w0, [x24]
    56d0:	7103fc1f 	cmp	w0, #0xff
    56d4:	54001e20 	b.eq	5a98 <fwp_hof0.constprop.0+0xb24>  // b.none
    56d8:	91158280 	add	x0, x20, #0x560
    56dc:	52800021 	mov	w1, #0x1                   	// #1
    56e0:	39000301 	strb	w1, [x24]
    56e4:	f949ec03 	ldr	x3, [x0, #5080]
    56e8:	f949d801 	ldr	x1, [x0, #5040]
    56ec:	d370bc63 	lsl	x3, x3, #16
    56f0:	cb010261 	sub	x1, x19, x1
    56f4:	9115829a 	add	x26, x20, #0x560
    56f8:	eb03003f 	cmp	x1, x3
    56fc:	540003a2 	b.cs	5770 <fwp_hof0.constprop.0+0x7fc>  // b.hs, b.nlast
    5700:	d350fc20 	lsr	x0, x1, #16
    5704:	f949ff43 	ldr	x3, [x26, #5112]
    5708:	8b000800 	add	x0, x0, x0, lsl #2
    570c:	d37df002 	lsl	x2, x0, #3
    5710:	8b020060 	add	x0, x3, x2
    5714:	f9401018 	ldr	x24, [x0, #32]
    5718:	b40002d8 	cbz	x24, 5770 <fwp_hof0.constprop.0+0x7fc>
    571c:	38626862 	ldrb	w2, [x3, x2]
    5720:	7100085f 	cmp	w2, #0x2
    5724:	540013a0 	b.eq	5998 <fwp_hof0.constprop.0+0xa24>  // b.none
    5728:	7100045f 	cmp	w2, #0x1
    572c:	54000221 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    5730:	29430002 	ldp	w2, w0, [x0, #24]
    5734:	92403c21 	and	x1, x1, #0xffff
    5738:	9b027c21 	mul	x1, x1, x2
    573c:	d360fc21 	lsr	x1, x1, #32
    5740:	eb00003f 	cmp	x1, x0
    5744:	54000162 	b.cs	5770 <fwp_hof0.constprop.0+0x7fc>  // b.hs, b.nlast
    5748:	8b010318 	add	x24, x24, x1
    574c:	39400300 	ldrb	w0, [x24]
    5750:	34000100 	cbz	w0, 5770 <fwp_hof0.constprop.0+0x7fc>
    5754:	7100041f 	cmp	w0, #0x1
    5758:	54000d80 	b.eq	5908 <fwp_hof0.constprop.0+0x994>  // b.none
    575c:	7103fc1f 	cmp	w0, #0xff
    5760:	54001ba0 	b.eq	5ad4 <fwp_hof0.constprop.0+0xb60>  // b.none
    5764:	51000400 	sub	w0, w0, #0x1
    5768:	39000300 	strb	w0, [x24]
    576c:	d503201f 	nop
    5770:	f00000d3 	adrp	x19, 20000 <__data_start>
    5774:	d2800021 	mov	x1, #0x1                   	// #1
    5778:	f94002e2 	ldr	x2, [x23]
    577c:	aa1903e0 	mov	x0, x25
    5780:	f9404263 	ldr	x3, [x19, #128]
    5784:	97ffef9f 	bl	1600 <fwrite@plt>
    5788:	f9404261 	ldr	x1, [x19, #128]
    578c:	52800140 	mov	w0, #0xa                   	// #10
    5790:	97ffef24 	bl	1420 <fputc@plt>
    5794:	91158282 	add	x2, x20, #0x560
    5798:	f949d841 	ldr	x1, [x2, #5040]
    579c:	f949ec40 	ldr	x0, [x2, #5080]
    57a0:	cb0102e1 	sub	x1, x23, x1
    57a4:	eb00403f 	cmp	x1, x0, lsl #16
    57a8:	54000382 	b.cs	5818 <fwp_hof0.constprop.0+0x8a4>  // b.hs, b.nlast
    57ac:	d350fc20 	lsr	x0, x1, #16
    57b0:	f949fc43 	ldr	x3, [x2, #5112]
    57b4:	8b000800 	add	x0, x0, x0, lsl #2
    57b8:	d37df002 	lsl	x2, x0, #3
    57bc:	8b020060 	add	x0, x3, x2
    57c0:	f9401013 	ldr	x19, [x0, #32]
    57c4:	b40002b3 	cbz	x19, 5818 <fwp_hof0.constprop.0+0x8a4>
    57c8:	38626862 	ldrb	w2, [x3, x2]
    57cc:	7100085f 	cmp	w2, #0x2
    57d0:	540016a0 	b.eq	5aa4 <fwp_hof0.constprop.0+0xb30>  // b.none
    57d4:	7100045f 	cmp	w2, #0x1
    57d8:	54000201 	b.ne	5818 <fwp_hof0.constprop.0+0x8a4>  // b.any
    57dc:	29430002 	ldp	w2, w0, [x0, #24]
    57e0:	92403c21 	and	x1, x1, #0xffff
    57e4:	9b027c21 	mul	x1, x1, x2
    57e8:	d360fc21 	lsr	x1, x1, #32
    57ec:	eb00003f 	cmp	x1, x0
    57f0:	54000142 	b.cs	5818 <fwp_hof0.constprop.0+0x8a4>  // b.hs, b.nlast
    57f4:	8b010273 	add	x19, x19, x1
    57f8:	39400260 	ldrb	w0, [x19]
    57fc:	340000e0 	cbz	w0, 5818 <fwp_hof0.constprop.0+0x8a4>
    5800:	7100041f 	cmp	w0, #0x1
    5804:	540015c0 	b.eq	5abc <fwp_hof0.constprop.0+0xb48>  // b.none
    5808:	7103fc1f 	cmp	w0, #0xff
    580c:	54001c40 	b.eq	5b94 <fwp_hof0.constprop.0+0xc20>  // b.none
    5810:	51000400 	sub	w0, w0, #0x1
    5814:	39000260 	strb	w0, [x19]
    5818:	f94007e0 	ldr	x0, [sp, #8]
    581c:	f9400800 	ldr	x0, [x0, #16]
    5820:	f90007e0 	str	x0, [sp, #8]
    5824:	b5ffbd60 	cbnz	x0, 4fd0 <fwp_hof0.constprop.0+0x5c>
    5828:	a94553f3 	ldp	x19, x20, [sp, #80]
    582c:	a94763f7 	ldp	x23, x24, [sp, #112]
    5830:	a9486bf9 	ldp	x25, x26, [sp, #128]
    5834:	a94973fb 	ldp	x27, x28, [sp, #144]
    5838:	6d4a27e8 	ldp	d8, d9, [sp, #160]
    583c:	fd405bea 	ldr	d10, [sp, #176]
    5840:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    5844:	f947f400 	ldr	x0, [x0, #4072]
    5848:	f9401fe2 	ldr	x2, [sp, #56]
    584c:	f9400001 	ldr	x1, [x0]
    5850:	eb010042 	subs	x2, x2, x1
    5854:	d2800001 	mov	x1, #0x0                   	// #0
    5858:	54002221 	b.ne	5c9c <fwp_hof0.constprop.0+0xd28>  // b.any
    585c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5860:	d2800000 	mov	x0, #0x0                   	// #0
    5864:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5868:	910303ff 	add	sp, sp, #0xc0
    586c:	d65f03c0 	ret
    5870:	f9400ae0 	ldr	x0, [x23, #16]
    5874:	17fffec7 	b	5390 <fwp_hof0.constprop.0+0x41c>
    5878:	f9400ae4 	ldr	x4, [x23, #16]
    587c:	fc636880 	ldr	d0, [x4, x3]
    5880:	1e600800 	fmul	d0, d0, d0
    5884:	eb02003f 	cmp	x1, x2
    5888:	54ffdac3 	b.cc	53e0 <fwp_hof0.constprop.0+0x46c>  // b.lo, b.ul, b.last
    588c:	17fffee0 	b	540c <fwp_hof0.constprop.0+0x498>
    5890:	f9400ae0 	ldr	x0, [x23, #16]
    5894:	1e6e1003 	fmov	d3, #1.000000000000000000e+00
    5898:	fc636802 	ldr	d2, [x0, x3]
    589c:	1e623863 	fsub	d3, d3, d2
    58a0:	17fffeae 	b	5358 <fwp_hof0.constprop.0+0x3e4>
    58a4:	72003c3f 	tst	w1, #0xffff
    58a8:	54ffe041 	b.ne	54b0 <fwp_hof0.constprop.0+0x53c>  // b.any
    58ac:	17fffef9 	b	5490 <fwp_hof0.constprop.0+0x51c>
    58b0:	f94006f8 	ldr	x24, [x23, #8]
    58b4:	aa1703e0 	mov	x0, x23
    58b8:	97fff722 	bl	3540 <fwp_rc_free_arr>
    58bc:	91158280 	add	x0, x20, #0x560
    58c0:	f949d801 	ldr	x1, [x0, #5040]
    58c4:	f949ec00 	ldr	x0, [x0, #5080]
    58c8:	cb010301 	sub	x1, x24, x1
    58cc:	eb00403f 	cmp	x1, x0, lsl #16
    58d0:	54ffdf02 	b.cs	54b0 <fwp_hof0.constprop.0+0x53c>  // b.hs, b.nlast
    58d4:	aa1803f7 	mov	x23, x24
    58d8:	17fffedb 	b	5444 <fwp_hof0.constprop.0+0x4d0>
    58dc:	72003c3f 	tst	w1, #0xffff
    58e0:	54ffd181 	b.ne	5310 <fwp_hof0.constprop.0+0x39c>  // b.any
    58e4:	39400340 	ldrb	w0, [x26]
    58e8:	7103fc1f 	cmp	w0, #0xff
    58ec:	54ffd0e1 	b.ne	5308 <fwp_hof0.constprop.0+0x394>  // b.any
    58f0:	aa1a03e0 	mov	x0, x26
    58f4:	97fff524 	bl	2d84 <fwp_rc_forget_slot>
    58f8:	17fffe84 	b	5308 <fwp_hof0.constprop.0+0x394>
    58fc:	72003c1f 	tst	w0, #0xffff
    5900:	54ffdd81 	b.ne	54b0 <fwp_hof0.constprop.0+0x53c>  // b.any
    5904:	17ffff0a 	b	552c <fwp_hof0.constprop.0+0x5b8>
    5908:	f9400260 	ldr	x0, [x19]
    590c:	b7f804c0 	tbnz	x0, #63, 59a4 <fwp_hof0.constprop.0+0xa30>
    5910:	91158281 	add	x1, x20, #0x560
    5914:	f949d820 	ldr	x0, [x1, #5040]
    5918:	f949ec21 	ldr	x1, [x1, #5080]
    591c:	cb000260 	sub	x0, x19, x0
    5920:	eb01401f 	cmp	x0, x1, lsl #16
    5924:	54fff262 	b.cs	5770 <fwp_hof0.constprop.0+0x7fc>  // b.hs, b.nlast
    5928:	d350fc01 	lsr	x1, x0, #16
    592c:	8b010821 	add	x1, x1, x1, lsl #2
    5930:	d37df021 	lsl	x1, x1, #3
    5934:	8b010064 	add	x4, x3, x1
    5938:	f9401082 	ldr	x2, [x4, #32]
    593c:	b4fff1a2 	cbz	x2, 5770 <fwp_hof0.constprop.0+0x7fc>
    5940:	38616861 	ldrb	w1, [x3, x1]
    5944:	7100083f 	cmp	w1, #0x2
    5948:	54000c00 	b.eq	5ac8 <fwp_hof0.constprop.0+0xb54>  // b.none
    594c:	7100043f 	cmp	w1, #0x1
    5950:	54fff101 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    5954:	29430483 	ldp	w3, w1, [x4, #24]
    5958:	92403c00 	and	x0, x0, #0xffff
    595c:	9b037c00 	mul	x0, x0, x3
    5960:	d360fc00 	lsr	x0, x0, #32
    5964:	eb01001f 	cmp	x0, x1
    5968:	54fff042 	b.cs	5770 <fwp_hof0.constprop.0+0x7fc>  // b.hs, b.nlast
    596c:	8b000042 	add	x2, x2, x0
    5970:	39400040 	ldrb	w0, [x2]
    5974:	7100041f 	cmp	w0, #0x1
    5978:	54ffefc1 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    597c:	aa1303e0 	mov	x0, x19
    5980:	97fff5a0 	bl	3000 <fwp_mem_free>
    5984:	17ffff7b 	b	5770 <fwp_hof0.constprop.0+0x7fc>
    5988:	72003c7f 	tst	w3, #0xffff
    598c:	54ffc600 	b.eq	524c <fwp_hof0.constprop.0+0x2d8>  // b.none
    5990:	aa1303e0 	mov	x0, x19
    5994:	17fffe32 	b	525c <fwp_hof0.constprop.0+0x2e8>
    5998:	72003c3f 	tst	w1, #0xffff
    599c:	54ffeea1 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    59a0:	17ffff6b 	b	574c <fwp_hof0.constprop.0+0x7d8>
    59a4:	f9400678 	ldr	x24, [x19, #8]
    59a8:	aa1303e0 	mov	x0, x19
    59ac:	97fff6e5 	bl	3540 <fwp_rc_free_arr>
    59b0:	91158280 	add	x0, x20, #0x560
    59b4:	f949d801 	ldr	x1, [x0, #5040]
    59b8:	f949ec00 	ldr	x0, [x0, #5080]
    59bc:	cb010301 	sub	x1, x24, x1
    59c0:	eb00403f 	cmp	x1, x0, lsl #16
    59c4:	54ffed62 	b.cs	5770 <fwp_hof0.constprop.0+0x7fc>  // b.hs, b.nlast
    59c8:	aa1803f3 	mov	x19, x24
    59cc:	17ffff4d 	b	5700 <fwp_hof0.constprop.0+0x78c>
    59d0:	72003c1f 	tst	w0, #0xffff
    59d4:	54ffb300 	b.eq	5034 <fwp_hof0.constprop.0+0xc0>  // b.none
    59d8:	b5ffb4b5 	cbnz	x21, 506c <fwp_hof0.constprop.0+0xf8>
    59dc:	d2800000 	mov	x0, #0x0                   	// #0
    59e0:	97fff7bc 	bl	38d0 <fwp_array_new_packed.constprop.0>
    59e4:	91158281 	add	x1, x20, #0x560
    59e8:	aa0003f7 	mov	x23, x0
    59ec:	aa0103e0 	mov	x0, x1
    59f0:	f949d821 	ldr	x1, [x1, #5040]
    59f4:	f949ec00 	ldr	x0, [x0, #5080]
    59f8:	cb0102e1 	sub	x1, x23, x1
    59fc:	eb00403f 	cmp	x1, x0, lsl #16
    5a00:	54ffb5a3 	b.cc	50b4 <fwp_hof0.constprop.0+0x140>  // b.lo, b.ul, b.last
    5a04:	d2800000 	mov	x0, #0x0                   	// #0
    5a08:	17fffe18 	b	5268 <fwp_hof0.constprop.0+0x2f4>
    5a0c:	72003c3f 	tst	w1, #0xffff
    5a10:	54ffb841 	b.ne	5118 <fwp_hof0.constprop.0+0x1a4>  // b.any
    5a14:	39400260 	ldrb	w0, [x19]
    5a18:	7103fc1f 	cmp	w0, #0xff
    5a1c:	54ffb7a1 	b.ne	5110 <fwp_hof0.constprop.0+0x19c>  // b.any
    5a20:	aa1303e0 	mov	x0, x19
    5a24:	97fff4d8 	bl	2d84 <fwp_rc_forget_slot>
    5a28:	17fffdba 	b	5110 <fwp_hof0.constprop.0+0x19c>
    5a2c:	ca584700 	eor	x0, x24, x24, lsr #17
    5a30:	91158281 	add	x1, x20, #0x560
    5a34:	ca402400 	eor	x0, x0, x0, lsr #9
    5a38:	8b200c20 	add	x0, x1, w0, uxtb #3
    5a3c:	f94a2400 	ldr	x0, [x0, #5192]
    5a40:	b5000080 	cbnz	x0, 5a50 <fwp_hof0.constprop.0+0xadc>
    5a44:	1400006f 	b	5c00 <fwp_hof0.constprop.0+0xc8c>
    5a48:	f9400800 	ldr	x0, [x0, #16]
    5a4c:	b4000da0 	cbz	x0, 5c00 <fwp_hof0.constprop.0+0xc8c>
    5a50:	f9400001 	ldr	x1, [x0]
    5a54:	eb01031f 	cmp	x24, x1
    5a58:	54ffff81 	b.ne	5a48 <fwp_hof0.constprop.0+0xad4>  // b.any
    5a5c:	f9400401 	ldr	x1, [x0, #8]
    5a60:	d1000421 	sub	x1, x1, #0x1
    5a64:	f9000401 	str	x1, [x0, #8]
    5a68:	f103f83f 	cmp	x1, #0xfe
    5a6c:	54ffd221 	b.ne	54b0 <fwp_hof0.constprop.0+0x53c>  // b.any
    5a70:	aa1803e0 	mov	x0, x24
    5a74:	97fff4c4 	bl	2d84 <fwp_rc_forget_slot>
    5a78:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5a7c:	39000300 	strb	w0, [x24]
    5a80:	17fffe8c 	b	54b0 <fwp_hof0.constprop.0+0x53c>
    5a84:	72003c9f 	tst	w4, #0xffff
    5a88:	54ffe341 	b.ne	56f0 <fwp_hof0.constprop.0+0x77c>  // b.any
    5a8c:	39400300 	ldrb	w0, [x24]
    5a90:	7103fc1f 	cmp	w0, #0xff
    5a94:	54ffe221 	b.ne	56d8 <fwp_hof0.constprop.0+0x764>  // b.any
    5a98:	aa1803e0 	mov	x0, x24
    5a9c:	97fff4ba 	bl	2d84 <fwp_rc_forget_slot>
    5aa0:	17ffff0e 	b	56d8 <fwp_hof0.constprop.0+0x764>
    5aa4:	72003c3f 	tst	w1, #0xffff
    5aa8:	54ffeb81 	b.ne	5818 <fwp_hof0.constprop.0+0x8a4>  // b.any
    5aac:	39400260 	ldrb	w0, [x19]
    5ab0:	34ffeb40 	cbz	w0, 5818 <fwp_hof0.constprop.0+0x8a4>
    5ab4:	7100041f 	cmp	w0, #0x1
    5ab8:	54ffea81 	b.ne	5808 <fwp_hof0.constprop.0+0x894>  // b.any
    5abc:	aa1703e0 	mov	x0, x23
    5ac0:	97fff550 	bl	3000 <fwp_mem_free>
    5ac4:	17ffff55 	b	5818 <fwp_hof0.constprop.0+0x8a4>
    5ac8:	72003c1f 	tst	w0, #0xffff
    5acc:	54ffe521 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    5ad0:	17ffffa8 	b	5970 <fwp_hof0.constprop.0+0x9fc>
    5ad4:	ca584700 	eor	x0, x24, x24, lsr #17
    5ad8:	91158281 	add	x1, x20, #0x560
    5adc:	ca402400 	eor	x0, x0, x0, lsr #9
    5ae0:	8b200c20 	add	x0, x1, w0, uxtb #3
    5ae4:	f94a2400 	ldr	x0, [x0, #5192]
    5ae8:	b5000080 	cbnz	x0, 5af8 <fwp_hof0.constprop.0+0xb84>
    5aec:	14000045 	b	5c00 <fwp_hof0.constprop.0+0xc8c>
    5af0:	f9400800 	ldr	x0, [x0, #16]
    5af4:	b4000860 	cbz	x0, 5c00 <fwp_hof0.constprop.0+0xc8c>
    5af8:	f9400001 	ldr	x1, [x0]
    5afc:	eb01031f 	cmp	x24, x1
    5b00:	54ffff81 	b.ne	5af0 <fwp_hof0.constprop.0+0xb7c>  // b.any
    5b04:	f9400401 	ldr	x1, [x0, #8]
    5b08:	d1000421 	sub	x1, x1, #0x1
    5b0c:	f9000401 	str	x1, [x0, #8]
    5b10:	f103f83f 	cmp	x1, #0xfe
    5b14:	54ffe2e1 	b.ne	5770 <fwp_hof0.constprop.0+0x7fc>  // b.any
    5b18:	aa1803e0 	mov	x0, x24
    5b1c:	97fff49a 	bl	2d84 <fwp_rc_forget_slot>
    5b20:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b24:	39000300 	strb	w0, [x24]
    5b28:	17ffff12 	b	5770 <fwp_hof0.constprop.0+0x7fc>
    5b2c:	ca534661 	eor	x1, x19, x19, lsr #17
    5b30:	91158282 	add	x2, x20, #0x560
    5b34:	ca412421 	eor	x1, x1, x1, lsr #9
    5b38:	92401c21 	and	x1, x1, #0xff
    5b3c:	910a2423 	add	x3, x1, #0x289
    5b40:	8b010c41 	add	x1, x2, x1, lsl #3
    5b44:	8b030c57 	add	x23, x2, x3, lsl #3
    5b48:	f94a2421 	ldr	x1, [x1, #5192]
    5b4c:	b50000a1 	cbnz	x1, 5b60 <fwp_hof0.constprop.0+0xbec>
    5b50:	1400004b 	b	5c7c <fwp_hof0.constprop.0+0xd08>
    5b54:	91004037 	add	x23, x1, #0x10
    5b58:	f9400821 	ldr	x1, [x1, #16]
    5b5c:	b40004e1 	cbz	x1, 5bf8 <fwp_hof0.constprop.0+0xc84>
    5b60:	f9400022 	ldr	x2, [x1]
    5b64:	eb13005f 	cmp	x2, x19
    5b68:	54ffff61 	b.ne	5b54 <fwp_hof0.constprop.0+0xbe0>  // b.any
    5b6c:	f94002e1 	ldr	x1, [x23]
    5b70:	7103f81f 	cmp	w0, #0xfe
    5b74:	54000680 	b.eq	5c44 <fwp_hof0.constprop.0+0xcd0>  // b.none
    5b78:	b4000441 	cbz	x1, 5c00 <fwp_hof0.constprop.0+0xc8c>
    5b7c:	f9400420 	ldr	x0, [x1, #8]
    5b80:	b100041f 	cmn	x0, #0x1
    5b84:	54000760 	b.eq	5c70 <fwp_hof0.constprop.0+0xcfc>  // b.none
    5b88:	91000400 	add	x0, x0, #0x1
    5b8c:	f9000420 	str	x0, [x1, #8]
    5b90:	17fffd36 	b	5068 <fwp_hof0.constprop.0+0xf4>
    5b94:	ca534660 	eor	x0, x19, x19, lsr #17
    5b98:	91158281 	add	x1, x20, #0x560
    5b9c:	ca402400 	eor	x0, x0, x0, lsr #9
    5ba0:	8b200c20 	add	x0, x1, w0, uxtb #3
    5ba4:	f94a2400 	ldr	x0, [x0, #5192]
    5ba8:	b5000080 	cbnz	x0, 5bb8 <fwp_hof0.constprop.0+0xc44>
    5bac:	14000015 	b	5c00 <fwp_hof0.constprop.0+0xc8c>
    5bb0:	f9400800 	ldr	x0, [x0, #16]
    5bb4:	b4000260 	cbz	x0, 5c00 <fwp_hof0.constprop.0+0xc8c>
    5bb8:	f9400001 	ldr	x1, [x0]
    5bbc:	eb01027f 	cmp	x19, x1
    5bc0:	54ffff81 	b.ne	5bb0 <fwp_hof0.constprop.0+0xc3c>  // b.any
    5bc4:	f9400401 	ldr	x1, [x0, #8]
    5bc8:	d1000421 	sub	x1, x1, #0x1
    5bcc:	f9000401 	str	x1, [x0, #8]
    5bd0:	f103f83f 	cmp	x1, #0xfe
    5bd4:	54ffe221 	b.ne	5818 <fwp_hof0.constprop.0+0x8a4>  // b.any
    5bd8:	aa1303e0 	mov	x0, x19
    5bdc:	97fff46a 	bl	2d84 <fwp_rc_forget_slot>
    5be0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5be4:	39000260 	strb	w0, [x19]
    5be8:	17ffff0c 	b	5818 <fwp_hof0.constprop.0+0x8a4>
    5bec:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    5bf0:	91092000 	add	x0, x0, #0x248
    5bf4:	97fff1a3 	bl	2280 <fwp_trap>
    5bf8:	7103f81f 	cmp	w0, #0xfe
    5bfc:	54000080 	b.eq	5c0c <fwp_hof0.constprop.0+0xc98>  // b.none
    5c00:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    5c04:	91032000 	add	x0, x0, #0xc8
    5c08:	97fff19e 	bl	2280 <fwp_trap>
    5c0c:	d2800300 	mov	x0, #0x18                  	// #24
    5c10:	97ffee24 	bl	14a0 <malloc@plt>
    5c14:	b40002c0 	cbz	x0, 5c6c <fwp_hof0.constprop.0+0xcf8>
    5c18:	d2801fe1 	mov	x1, #0xff                  	// #255
    5c1c:	a9000413 	stp	x19, x1, [x0]
    5c20:	91158281 	add	x1, x20, #0x560
    5c24:	f900081f 	str	xzr, [x0, #16]
    5c28:	12800002 	mov	w2, #0xffffffff            	// #-1
    5c2c:	f90002e0 	str	x0, [x23]
    5c30:	39000262 	strb	w2, [x19]
    5c34:	f94e2420 	ldr	x0, [x1, #7240]
    5c38:	91000400 	add	x0, x0, #0x1
    5c3c:	f90e2420 	str	x0, [x1, #7240]
    5c40:	17fffd0a 	b	5068 <fwp_hof0.constprop.0+0xf4>
    5c44:	b4fffe41 	cbz	x1, 5c0c <fwp_hof0.constprop.0+0xc98>
    5c48:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    5c4c:	91080000 	add	x0, x0, #0x200
    5c50:	97fff18c 	bl	2280 <fwp_trap>
    5c54:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    5c58:	9103c000 	add	x0, x0, #0xf0
    5c5c:	97fff189 	bl	2280 <fwp_trap>
    5c60:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    5c64:	9109c000 	add	x0, x0, #0x270
    5c68:	97fff186 	bl	2280 <fwp_trap>
    5c6c:	97fff019 	bl	1cd0 <fwp_heap_oom>
    5c70:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    5c74:	9108a000 	add	x0, x0, #0x228
    5c78:	97fff182 	bl	2280 <fwp_trap>
    5c7c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    5c80:	17ffffbc 	b	5b70 <fwp_hof0.constprop.0+0xbfc>
    5c84:	2f00e402 	movi	d2, #0x0
    5c88:	90000020 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    5c8c:	fd428800 	ldr	d0, [x0, #1296]
    5c90:	1e622821 	fadd	d1, d1, d2
    5c94:	1e600820 	fmul	d0, d1, d0
    5c98:	17fffdbc 	b	5388 <fwp_hof0.constprop.0+0x414>
    5c9c:	a90553f3 	stp	x19, x20, [sp, #80]
    5ca0:	a90763f7 	stp	x23, x24, [sp, #112]
    5ca4:	a9086bf9 	stp	x25, x26, [sp, #128]
    5ca8:	a90973fb 	stp	x27, x28, [sp, #144]
    5cac:	6d0a27e8 	stp	d8, d9, [sp, #160]
    5cb0:	fd005bea 	str	d10, [sp, #176]
    5cb4:	97ffee13 	bl	1500 <__stack_chk_fail@plt>
    5cb8:	97ffee92 	bl	1700 <fwp_trap_overflow.constprop.0>
    5cbc:	d503201f 	nop

0000000000005cc0 <f0>:
    5cc0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    5cc4:	910003fd 	mov	x29, sp
    5cc8:	a90153f3 	stp	x19, x20, [sp, #16]
    5ccc:	a9025bf5 	stp	x21, x22, [sp, #32]
    5cd0:	a90363f7 	stp	x23, x24, [sp, #48]
    5cd4:	a9046bf9 	stp	x25, x26, [sp, #64]
    5cd8:	a90573fb 	stp	x27, x28, [sp, #80]
    5cdc:	d12183ff 	sub	sp, sp, #0x860
    5ce0:	f90203ff 	str	xzr, [sp, #1024]
    5ce4:	f00000c0 	adrp	x0, 20000 <__data_start>
    5ce8:	91020005 	add	x5, x0, #0x80
    5cec:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    5cf0:	f947f400 	ldr	x0, [x0, #4072]
    5cf4:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc80>
    5cf8:	f94148a6 	ldr	x6, [x5, #656]
    5cfc:	f9400001 	ldr	x1, [x0]
    5d00:	f9042fe1 	str	x1, [sp, #2136]
    5d04:	d2800001 	mov	x1, #0x0                   	// #0
    5d08:	91158298 	add	x24, x20, #0x560
    5d0c:	912123f6 	add	x22, sp, #0x848
    5d10:	910023e0 	add	x0, sp, #0x8
    5d14:	910083e2 	add	x2, sp, #0x20
    5d18:	d0ffffe1 	adrp	x1, 3000 <fwp_mem_free>
    5d1c:	90ffffe4 	adrp	x4, 1000 <__abi_tag+0xd88>
    5d20:	91248021 	add	x1, x1, #0x920
    5d24:	912e4084 	add	x4, x4, #0xb90
    5d28:	d2800013 	mov	x19, #0x0                   	// #0
    5d2c:	d2800119 	mov	x25, #0x8                   	// #8
    5d30:	d2800015 	mov	x21, #0x0                   	// #0
    5d34:	52800037 	mov	w23, #0x1                   	// #1
    5d38:	a90093e6 	stp	x6, x4, [sp, #8]
    5d3c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    5d40:	a90307ff 	stp	xzr, x1, [sp, #48]
    5d44:	f90148a0 	str	x0, [x5, #656]
    5d48:	f100073a 	subs	x26, x25, #0x1
    5d4c:	aa1603e0 	mov	x0, x22
    5d50:	da1f02bc 	sbc	x28, x21, xzr
    5d54:	f90017fa 	str	x26, [sp, #40]
    5d58:	f90427fa 	str	x26, [sp, #2120]
    5d5c:	aa1a03f9 	mov	x25, x26
    5d60:	f9042bf3 	str	x19, [sp, #2128]
    5d64:	97fff67b 	bl	3750 <fwp_data.part.0.constprop.0>
    5d68:	f949db02 	ldr	x2, [x24, #5040]
    5d6c:	aa0003f3 	mov	x19, x0
    5d70:	f949ef00 	ldr	x0, [x24, #5080]
    5d74:	cb020262 	sub	x2, x19, x2
    5d78:	aa1c03f5 	mov	x21, x28
    5d7c:	eb00405f 	cmp	x2, x0, lsl #16
    5d80:	54000302 	b.cs	5de0 <f0+0x120>  // b.hs, b.nlast
    5d84:	d350fc40 	lsr	x0, x2, #16
    5d88:	f949ff04 	ldr	x4, [x24, #5112]
    5d8c:	8b000800 	add	x0, x0, x0, lsl #2
    5d90:	d37df001 	lsl	x1, x0, #3
    5d94:	8b010080 	add	x0, x4, x1
    5d98:	f940101b 	ldr	x27, [x0, #32]
    5d9c:	b400023b 	cbz	x27, 5de0 <f0+0x120>
    5da0:	38616881 	ldrb	w1, [x4, x1]
    5da4:	7100083f 	cmp	w1, #0x2
    5da8:	5400ff20 	b.eq	7d8c <f0+0x20cc>  // b.none
    5dac:	7100043f 	cmp	w1, #0x1
    5db0:	54000181 	b.ne	5de0 <f0+0x120>  // b.any
    5db4:	29430001 	ldp	w1, w0, [x0, #24]
    5db8:	92403c42 	and	x2, x2, #0xffff
    5dbc:	9b017c42 	mul	x2, x2, x1
    5dc0:	d360fc42 	lsr	x2, x2, #32
    5dc4:	eb00005f 	cmp	x2, x0
    5dc8:	540000c2 	b.cs	5de0 <f0+0x120>  // b.hs, b.nlast
    5dcc:	8b02037b 	add	x27, x27, x2
    5dd0:	39400360 	ldrb	w0, [x27]
    5dd4:	7103fc1f 	cmp	w0, #0xff
    5dd8:	5400fd40 	b.eq	7d80 <f0+0x20c0>  // b.none
    5ddc:	39000377 	strb	w23, [x27]
    5de0:	f90013f3 	str	x19, [sp, #32]
    5de4:	aa1c035a 	orr	x26, x26, x28
    5de8:	b5fffb1a 	cbnz	x26, 5d48 <f0+0x88>
    5dec:	90000022 	adrp	x2, 9000 <_IO_stdin_used+0x1f0>
    5df0:	f00000c0 	adrp	x0, 20000 <__data_start>
    5df4:	f94007e1 	ldr	x1, [sp, #8]
    5df8:	91020018 	add	x24, x0, #0x80
    5dfc:	3dc14040 	ldr	q0, [x2, #1280]
    5e00:	910103e0 	add	x0, sp, #0x40
    5e04:	f9014b01 	str	x1, [x24, #656]
    5e08:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    5e0c:	3d8013e0 	str	q0, [sp, #64]
    5e10:	97fff650 	bl	3750 <fwp_data.part.0.constprop.0>
    5e14:	97fff59b 	bl	3480 <fwp_rc_fresh>
    5e18:	aa0003e1 	mov	x1, x0
    5e1c:	910163e0 	add	x0, sp, #0x58
    5e20:	a90587f5 	stp	x21, x1, [sp, #88]
    5e24:	97fff64b 	bl	3750 <fwp_data.part.0.constprop.0>
    5e28:	97fff596 	bl	3480 <fwp_rc_fresh>
    5e2c:	aa0003e1 	mov	x1, x0
    5e30:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5e34:	9101a3e0 	add	x0, sp, #0x68
    5e38:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5e3c:	a90687e2 	stp	x2, x1, [sp, #104]
    5e40:	97fff644 	bl	3750 <fwp_data.part.0.constprop.0>
    5e44:	97fff58f 	bl	3480 <fwp_rc_fresh>
    5e48:	aa0003e1 	mov	x1, x0
    5e4c:	9101e3e0 	add	x0, sp, #0x78
    5e50:	a90787f5 	stp	x21, x1, [sp, #120]
    5e54:	97fff63f 	bl	3750 <fwp_data.part.0.constprop.0>
    5e58:	97fff58a 	bl	3480 <fwp_rc_fresh>
    5e5c:	aa0003e1 	mov	x1, x0
    5e60:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5e64:	910223e0 	add	x0, sp, #0x88
    5e68:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5e6c:	a90887e2 	stp	x2, x1, [sp, #136]
    5e70:	97fff638 	bl	3750 <fwp_data.part.0.constprop.0>
    5e74:	97fff583 	bl	3480 <fwp_rc_fresh>
    5e78:	aa0003e1 	mov	x1, x0
    5e7c:	910263e0 	add	x0, sp, #0x98
    5e80:	a90987f5 	stp	x21, x1, [sp, #152]
    5e84:	97fff633 	bl	3750 <fwp_data.part.0.constprop.0>
    5e88:	97fff57e 	bl	3480 <fwp_rc_fresh>
    5e8c:	aa0003e1 	mov	x1, x0
    5e90:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5e94:	9102a3e0 	add	x0, sp, #0xa8
    5e98:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5e9c:	a90a87e2 	stp	x2, x1, [sp, #168]
    5ea0:	97fff62c 	bl	3750 <fwp_data.part.0.constprop.0>
    5ea4:	97fff577 	bl	3480 <fwp_rc_fresh>
    5ea8:	aa0003e1 	mov	x1, x0
    5eac:	9102e3e0 	add	x0, sp, #0xb8
    5eb0:	a90b87f5 	stp	x21, x1, [sp, #184]
    5eb4:	97fff627 	bl	3750 <fwp_data.part.0.constprop.0>
    5eb8:	97fff572 	bl	3480 <fwp_rc_fresh>
    5ebc:	aa0003e1 	mov	x1, x0
    5ec0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5ec4:	910323e0 	add	x0, sp, #0xc8
    5ec8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5ecc:	a90c87e2 	stp	x2, x1, [sp, #200]
    5ed0:	97fff620 	bl	3750 <fwp_data.part.0.constprop.0>
    5ed4:	97fff56b 	bl	3480 <fwp_rc_fresh>
    5ed8:	aa0003e1 	mov	x1, x0
    5edc:	910363e0 	add	x0, sp, #0xd8
    5ee0:	a90d87f5 	stp	x21, x1, [sp, #216]
    5ee4:	97fff61b 	bl	3750 <fwp_data.part.0.constprop.0>
    5ee8:	97fff566 	bl	3480 <fwp_rc_fresh>
    5eec:	aa0003e1 	mov	x1, x0
    5ef0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5ef4:	9103a3e0 	add	x0, sp, #0xe8
    5ef8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5efc:	a90e87e2 	stp	x2, x1, [sp, #232]
    5f00:	97fff614 	bl	3750 <fwp_data.part.0.constprop.0>
    5f04:	97fff55f 	bl	3480 <fwp_rc_fresh>
    5f08:	aa0003e1 	mov	x1, x0
    5f0c:	9103e3e0 	add	x0, sp, #0xf8
    5f10:	a90f87f5 	stp	x21, x1, [sp, #248]
    5f14:	97fff60f 	bl	3750 <fwp_data.part.0.constprop.0>
    5f18:	97fff55a 	bl	3480 <fwp_rc_fresh>
    5f1c:	aa0003e1 	mov	x1, x0
    5f20:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5f24:	910423e0 	add	x0, sp, #0x108
    5f28:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5f2c:	a91087e2 	stp	x2, x1, [sp, #264]
    5f30:	97fff608 	bl	3750 <fwp_data.part.0.constprop.0>
    5f34:	aa0003f5 	mov	x21, x0
    5f38:	91158283 	add	x3, x20, #0x560
    5f3c:	f949d861 	ldr	x1, [x3, #5040]
    5f40:	f949ec60 	ldr	x0, [x3, #5080]
    5f44:	cb0102a1 	sub	x1, x21, x1
    5f48:	eb00403f 	cmp	x1, x0, lsl #16
    5f4c:	54000322 	b.cs	5fb0 <f0+0x2f0>  // b.hs, b.nlast
    5f50:	d350fc22 	lsr	x2, x1, #16
    5f54:	f949fc63 	ldr	x3, [x3, #5112]
    5f58:	8b020842 	add	x2, x2, x2, lsl #2
    5f5c:	d37df042 	lsl	x2, x2, #3
    5f60:	8b020060 	add	x0, x3, x2
    5f64:	f9401017 	ldr	x23, [x0, #32]
    5f68:	b4000257 	cbz	x23, 5fb0 <f0+0x2f0>
    5f6c:	38626862 	ldrb	w2, [x3, x2]
    5f70:	7100085f 	cmp	w2, #0x2
    5f74:	5400f4e0 	b.eq	7e10 <f0+0x2150>  // b.none
    5f78:	7100045f 	cmp	w2, #0x1
    5f7c:	540001a1 	b.ne	5fb0 <f0+0x2f0>  // b.any
    5f80:	29430002 	ldp	w2, w0, [x0, #24]
    5f84:	92403c21 	and	x1, x1, #0xffff
    5f88:	9b027c21 	mul	x1, x1, x2
    5f8c:	d360fc21 	lsr	x1, x1, #32
    5f90:	eb00003f 	cmp	x1, x0
    5f94:	540000e2 	b.cs	5fb0 <f0+0x2f0>  // b.hs, b.nlast
    5f98:	8b0102f7 	add	x23, x23, x1
    5f9c:	394002e0 	ldrb	w0, [x23]
    5fa0:	7103fc1f 	cmp	w0, #0xff
    5fa4:	5400fea0 	b.eq	7f78 <f0+0x22b8>  // b.none
    5fa8:	52800020 	mov	w0, #0x1                   	// #1
    5fac:	390002e0 	strb	w0, [x23]
    5fb0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    5fb4:	910463e0 	add	x0, sp, #0x118
    5fb8:	a911d7f7 	stp	x23, x21, [sp, #280]
    5fbc:	97fff5e5 	bl	3750 <fwp_data.part.0.constprop.0>
    5fc0:	97fff530 	bl	3480 <fwp_rc_fresh>
    5fc4:	aa0003e1 	mov	x1, x0
    5fc8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    5fcc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    5fd0:	9104a3e0 	add	x0, sp, #0x128
    5fd4:	a91287f5 	stp	x21, x1, [sp, #296]
    5fd8:	97fff5de 	bl	3750 <fwp_data.part.0.constprop.0>
    5fdc:	97fff529 	bl	3480 <fwp_rc_fresh>
    5fe0:	aa0003e1 	mov	x1, x0
    5fe4:	9104e3e0 	add	x0, sp, #0x138
    5fe8:	a91387f7 	stp	x23, x1, [sp, #312]
    5fec:	97fff5d9 	bl	3750 <fwp_data.part.0.constprop.0>
    5ff0:	97fff524 	bl	3480 <fwp_rc_fresh>
    5ff4:	aa0003e1 	mov	x1, x0
    5ff8:	910523e0 	add	x0, sp, #0x148
    5ffc:	a91487f5 	stp	x21, x1, [sp, #328]
    6000:	97fff5d4 	bl	3750 <fwp_data.part.0.constprop.0>
    6004:	aa0003f7 	mov	x23, x0
    6008:	91158283 	add	x3, x20, #0x560
    600c:	f949d861 	ldr	x1, [x3, #5040]
    6010:	f949ec60 	ldr	x0, [x3, #5080]
    6014:	cb0102e1 	sub	x1, x23, x1
    6018:	eb00403f 	cmp	x1, x0, lsl #16
    601c:	54000322 	b.cs	6080 <f0+0x3c0>  // b.hs, b.nlast
    6020:	d350fc22 	lsr	x2, x1, #16
    6024:	f949fc63 	ldr	x3, [x3, #5112]
    6028:	8b020842 	add	x2, x2, x2, lsl #2
    602c:	d37df042 	lsl	x2, x2, #3
    6030:	8b020060 	add	x0, x3, x2
    6034:	f9401015 	ldr	x21, [x0, #32]
    6038:	b4000255 	cbz	x21, 6080 <f0+0x3c0>
    603c:	38626862 	ldrb	w2, [x3, x2]
    6040:	7100085f 	cmp	w2, #0x2
    6044:	5400ee00 	b.eq	7e04 <f0+0x2144>  // b.none
    6048:	7100045f 	cmp	w2, #0x1
    604c:	540001a1 	b.ne	6080 <f0+0x3c0>  // b.any
    6050:	29430002 	ldp	w2, w0, [x0, #24]
    6054:	92403c21 	and	x1, x1, #0xffff
    6058:	9b027c21 	mul	x1, x1, x2
    605c:	d360fc21 	lsr	x1, x1, #32
    6060:	eb00003f 	cmp	x1, x0
    6064:	540000e2 	b.cs	6080 <f0+0x3c0>  // b.hs, b.nlast
    6068:	8b0102b5 	add	x21, x21, x1
    606c:	394002a0 	ldrb	w0, [x21]
    6070:	7103fc1f 	cmp	w0, #0xff
    6074:	5400f880 	b.eq	7f84 <f0+0x22c4>  // b.none
    6078:	52800020 	mov	w0, #0x1                   	// #1
    607c:	390002a0 	strb	w0, [x21]
    6080:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6084:	910563e0 	add	x0, sp, #0x158
    6088:	a915dff5 	stp	x21, x23, [sp, #344]
    608c:	97fff5b1 	bl	3750 <fwp_data.part.0.constprop.0>
    6090:	97fff4fc 	bl	3480 <fwp_rc_fresh>
    6094:	aa0003e1 	mov	x1, x0
    6098:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    609c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    60a0:	9105a3e0 	add	x0, sp, #0x168
    60a4:	a91687f7 	stp	x23, x1, [sp, #360]
    60a8:	97fff5aa 	bl	3750 <fwp_data.part.0.constprop.0>
    60ac:	97fff4f5 	bl	3480 <fwp_rc_fresh>
    60b0:	aa0003e1 	mov	x1, x0
    60b4:	9105e3e0 	add	x0, sp, #0x178
    60b8:	a91787f5 	stp	x21, x1, [sp, #376]
    60bc:	97fff5a5 	bl	3750 <fwp_data.part.0.constprop.0>
    60c0:	97fff4f0 	bl	3480 <fwp_rc_fresh>
    60c4:	aa0003e1 	mov	x1, x0
    60c8:	910623e0 	add	x0, sp, #0x188
    60cc:	a91887f7 	stp	x23, x1, [sp, #392]
    60d0:	97fff5a0 	bl	3750 <fwp_data.part.0.constprop.0>
    60d4:	97fff4eb 	bl	3480 <fwp_rc_fresh>
    60d8:	aa0003e1 	mov	x1, x0
    60dc:	910663e0 	add	x0, sp, #0x198
    60e0:	a91987f5 	stp	x21, x1, [sp, #408]
    60e4:	97fff59b 	bl	3750 <fwp_data.part.0.constprop.0>
    60e8:	97fff4e6 	bl	3480 <fwp_rc_fresh>
    60ec:	aa0003e1 	mov	x1, x0
    60f0:	9106a3e0 	add	x0, sp, #0x1a8
    60f4:	a91a87f7 	stp	x23, x1, [sp, #424]
    60f8:	97fff596 	bl	3750 <fwp_data.part.0.constprop.0>
    60fc:	97fff4e1 	bl	3480 <fwp_rc_fresh>
    6100:	aa0003e1 	mov	x1, x0
    6104:	9106e3e0 	add	x0, sp, #0x1b8
    6108:	a91b87f5 	stp	x21, x1, [sp, #440]
    610c:	97fff591 	bl	3750 <fwp_data.part.0.constprop.0>
    6110:	97fff4dc 	bl	3480 <fwp_rc_fresh>
    6114:	aa0003e1 	mov	x1, x0
    6118:	910723e0 	add	x0, sp, #0x1c8
    611c:	a91c87f7 	stp	x23, x1, [sp, #456]
    6120:	97fff58c 	bl	3750 <fwp_data.part.0.constprop.0>
    6124:	97fff4d7 	bl	3480 <fwp_rc_fresh>
    6128:	aa0003e1 	mov	x1, x0
    612c:	910763e0 	add	x0, sp, #0x1d8
    6130:	a91d87f5 	stp	x21, x1, [sp, #472]
    6134:	97fff587 	bl	3750 <fwp_data.part.0.constprop.0>
    6138:	97fff4d2 	bl	3480 <fwp_rc_fresh>
    613c:	aa0003e1 	mov	x1, x0
    6140:	9107a3e0 	add	x0, sp, #0x1e8
    6144:	a91e87f7 	stp	x23, x1, [sp, #488]
    6148:	97fff582 	bl	3750 <fwp_data.part.0.constprop.0>
    614c:	97fff4cd 	bl	3480 <fwp_rc_fresh>
    6150:	aa0003e1 	mov	x1, x0
    6154:	9107e3e0 	add	x0, sp, #0x1f8
    6158:	a91f87f5 	stp	x21, x1, [sp, #504]
    615c:	97fff57d 	bl	3750 <fwp_data.part.0.constprop.0>
    6160:	97fff4c8 	bl	3480 <fwp_rc_fresh>
    6164:	aa0003e1 	mov	x1, x0
    6168:	910823e0 	add	x0, sp, #0x208
    616c:	f90107f7 	str	x23, [sp, #520]
    6170:	f9010be1 	str	x1, [sp, #528]
    6174:	97fff577 	bl	3750 <fwp_data.part.0.constprop.0>
    6178:	97fff4c2 	bl	3480 <fwp_rc_fresh>
    617c:	aa0003e1 	mov	x1, x0
    6180:	910863e0 	add	x0, sp, #0x218
    6184:	f9010ff5 	str	x21, [sp, #536]
    6188:	f90113e1 	str	x1, [sp, #544]
    618c:	97fff571 	bl	3750 <fwp_data.part.0.constprop.0>
    6190:	aa0003f5 	mov	x21, x0
    6194:	91158283 	add	x3, x20, #0x560
    6198:	f949d861 	ldr	x1, [x3, #5040]
    619c:	f949ec60 	ldr	x0, [x3, #5080]
    61a0:	cb0102a1 	sub	x1, x21, x1
    61a4:	eb00403f 	cmp	x1, x0, lsl #16
    61a8:	54000322 	b.cs	620c <f0+0x54c>  // b.hs, b.nlast
    61ac:	d350fc22 	lsr	x2, x1, #16
    61b0:	f949fc63 	ldr	x3, [x3, #5112]
    61b4:	8b020842 	add	x2, x2, x2, lsl #2
    61b8:	d37df042 	lsl	x2, x2, #3
    61bc:	8b020060 	add	x0, x3, x2
    61c0:	f9401017 	ldr	x23, [x0, #32]
    61c4:	b4000257 	cbz	x23, 620c <f0+0x54c>
    61c8:	38626862 	ldrb	w2, [x3, x2]
    61cc:	7100085f 	cmp	w2, #0x2
    61d0:	5400e140 	b.eq	7df8 <f0+0x2138>  // b.none
    61d4:	7100045f 	cmp	w2, #0x1
    61d8:	540001a1 	b.ne	620c <f0+0x54c>  // b.any
    61dc:	29430002 	ldp	w2, w0, [x0, #24]
    61e0:	92403c21 	and	x1, x1, #0xffff
    61e4:	9b027c21 	mul	x1, x1, x2
    61e8:	d360fc21 	lsr	x1, x1, #32
    61ec:	eb00003f 	cmp	x1, x0
    61f0:	540000e2 	b.cs	620c <f0+0x54c>  // b.hs, b.nlast
    61f4:	8b0102f7 	add	x23, x23, x1
    61f8:	394002e0 	ldrb	w0, [x23]
    61fc:	7103fc1f 	cmp	w0, #0xff
    6200:	5400ec80 	b.eq	7f90 <f0+0x22d0>  // b.none
    6204:	52800020 	mov	w0, #0x1                   	// #1
    6208:	390002e0 	strb	w0, [x23]
    620c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6210:	9108a3e0 	add	x0, sp, #0x228
    6214:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6218:	f90117f7 	str	x23, [sp, #552]
    621c:	f9011bf5 	str	x21, [sp, #560]
    6220:	97fff54c 	bl	3750 <fwp_data.part.0.constprop.0>
    6224:	97fff497 	bl	3480 <fwp_rc_fresh>
    6228:	aa0003e1 	mov	x1, x0
    622c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6230:	9108e3e0 	add	x0, sp, #0x238
    6234:	f9011ff5 	str	x21, [sp, #568]
    6238:	f90123e1 	str	x1, [sp, #576]
    623c:	97fff545 	bl	3750 <fwp_data.part.0.constprop.0>
    6240:	97fff490 	bl	3480 <fwp_rc_fresh>
    6244:	aa0003e1 	mov	x1, x0
    6248:	910923e0 	add	x0, sp, #0x248
    624c:	f90127f7 	str	x23, [sp, #584]
    6250:	f9012be1 	str	x1, [sp, #592]
    6254:	97fff53f 	bl	3750 <fwp_data.part.0.constprop.0>
    6258:	97fff48a 	bl	3480 <fwp_rc_fresh>
    625c:	aa0003e1 	mov	x1, x0
    6260:	910963e0 	add	x0, sp, #0x258
    6264:	f9012ff5 	str	x21, [sp, #600]
    6268:	f90133e1 	str	x1, [sp, #608]
    626c:	97fff539 	bl	3750 <fwp_data.part.0.constprop.0>
    6270:	aa0003f7 	mov	x23, x0
    6274:	91158283 	add	x3, x20, #0x560
    6278:	f949d861 	ldr	x1, [x3, #5040]
    627c:	f949ec60 	ldr	x0, [x3, #5080]
    6280:	cb0102e1 	sub	x1, x23, x1
    6284:	eb00403f 	cmp	x1, x0, lsl #16
    6288:	54000322 	b.cs	62ec <f0+0x62c>  // b.hs, b.nlast
    628c:	d350fc22 	lsr	x2, x1, #16
    6290:	f949fc63 	ldr	x3, [x3, #5112]
    6294:	8b020842 	add	x2, x2, x2, lsl #2
    6298:	d37df042 	lsl	x2, x2, #3
    629c:	8b020060 	add	x0, x3, x2
    62a0:	f9401015 	ldr	x21, [x0, #32]
    62a4:	b4000255 	cbz	x21, 62ec <f0+0x62c>
    62a8:	38626862 	ldrb	w2, [x3, x2]
    62ac:	7100085f 	cmp	w2, #0x2
    62b0:	5400dc80 	b.eq	7e40 <f0+0x2180>  // b.none
    62b4:	7100045f 	cmp	w2, #0x1
    62b8:	540001a1 	b.ne	62ec <f0+0x62c>  // b.any
    62bc:	29430002 	ldp	w2, w0, [x0, #24]
    62c0:	92403c21 	and	x1, x1, #0xffff
    62c4:	9b027c21 	mul	x1, x1, x2
    62c8:	d360fc21 	lsr	x1, x1, #32
    62cc:	eb00003f 	cmp	x1, x0
    62d0:	540000e2 	b.cs	62ec <f0+0x62c>  // b.hs, b.nlast
    62d4:	8b0102b5 	add	x21, x21, x1
    62d8:	394002a0 	ldrb	w0, [x21]
    62dc:	7103fc1f 	cmp	w0, #0xff
    62e0:	5400e5e0 	b.eq	7f9c <f0+0x22dc>  // b.none
    62e4:	52800020 	mov	w0, #0x1                   	// #1
    62e8:	390002a0 	strb	w0, [x21]
    62ec:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    62f0:	9109a3e0 	add	x0, sp, #0x268
    62f4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    62f8:	f90137f5 	str	x21, [sp, #616]
    62fc:	f9013bf7 	str	x23, [sp, #624]
    6300:	97fff514 	bl	3750 <fwp_data.part.0.constprop.0>
    6304:	97fff45f 	bl	3480 <fwp_rc_fresh>
    6308:	aa0003e1 	mov	x1, x0
    630c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6310:	9109e3e0 	add	x0, sp, #0x278
    6314:	f9013ff7 	str	x23, [sp, #632]
    6318:	f90143e1 	str	x1, [sp, #640]
    631c:	97fff50d 	bl	3750 <fwp_data.part.0.constprop.0>
    6320:	97fff458 	bl	3480 <fwp_rc_fresh>
    6324:	aa0003e1 	mov	x1, x0
    6328:	910a23e0 	add	x0, sp, #0x288
    632c:	f90147f5 	str	x21, [sp, #648]
    6330:	f9014be1 	str	x1, [sp, #656]
    6334:	97fff507 	bl	3750 <fwp_data.part.0.constprop.0>
    6338:	97fff452 	bl	3480 <fwp_rc_fresh>
    633c:	aa0003e1 	mov	x1, x0
    6340:	910a63e0 	add	x0, sp, #0x298
    6344:	f9014ff7 	str	x23, [sp, #664]
    6348:	f90153e1 	str	x1, [sp, #672]
    634c:	97fff501 	bl	3750 <fwp_data.part.0.constprop.0>
    6350:	97fff44c 	bl	3480 <fwp_rc_fresh>
    6354:	aa0003e1 	mov	x1, x0
    6358:	910aa3e0 	add	x0, sp, #0x2a8
    635c:	f90157f5 	str	x21, [sp, #680]
    6360:	f9015be1 	str	x1, [sp, #688]
    6364:	97fff4fb 	bl	3750 <fwp_data.part.0.constprop.0>
    6368:	97fff446 	bl	3480 <fwp_rc_fresh>
    636c:	aa0003e1 	mov	x1, x0
    6370:	910ae3e0 	add	x0, sp, #0x2b8
    6374:	f9015ff7 	str	x23, [sp, #696]
    6378:	f90163e1 	str	x1, [sp, #704]
    637c:	97fff4f5 	bl	3750 <fwp_data.part.0.constprop.0>
    6380:	97fff440 	bl	3480 <fwp_rc_fresh>
    6384:	aa0003e1 	mov	x1, x0
    6388:	910b23e0 	add	x0, sp, #0x2c8
    638c:	f90167f5 	str	x21, [sp, #712]
    6390:	f9016be1 	str	x1, [sp, #720]
    6394:	97fff4ef 	bl	3750 <fwp_data.part.0.constprop.0>
    6398:	97fff43a 	bl	3480 <fwp_rc_fresh>
    639c:	aa0003e1 	mov	x1, x0
    63a0:	910b63e0 	add	x0, sp, #0x2d8
    63a4:	f9016ff7 	str	x23, [sp, #728]
    63a8:	f90173e1 	str	x1, [sp, #736]
    63ac:	97fff4e9 	bl	3750 <fwp_data.part.0.constprop.0>
    63b0:	97fff434 	bl	3480 <fwp_rc_fresh>
    63b4:	aa0003e1 	mov	x1, x0
    63b8:	910ba3e0 	add	x0, sp, #0x2e8
    63bc:	f90177f5 	str	x21, [sp, #744]
    63c0:	f9017be1 	str	x1, [sp, #752]
    63c4:	97fff4e3 	bl	3750 <fwp_data.part.0.constprop.0>
    63c8:	97fff42e 	bl	3480 <fwp_rc_fresh>
    63cc:	aa0003e1 	mov	x1, x0
    63d0:	910be3e0 	add	x0, sp, #0x2f8
    63d4:	f9017ff7 	str	x23, [sp, #760]
    63d8:	f90183e1 	str	x1, [sp, #768]
    63dc:	97fff4dd 	bl	3750 <fwp_data.part.0.constprop.0>
    63e0:	97fff428 	bl	3480 <fwp_rc_fresh>
    63e4:	aa0003e1 	mov	x1, x0
    63e8:	910c23e0 	add	x0, sp, #0x308
    63ec:	f90187f5 	str	x21, [sp, #776]
    63f0:	f9018be1 	str	x1, [sp, #784]
    63f4:	97fff4d7 	bl	3750 <fwp_data.part.0.constprop.0>
    63f8:	97fff422 	bl	3480 <fwp_rc_fresh>
    63fc:	aa0003e1 	mov	x1, x0
    6400:	910c63e0 	add	x0, sp, #0x318
    6404:	f9018ff7 	str	x23, [sp, #792]
    6408:	f90193e1 	str	x1, [sp, #800]
    640c:	97fff4d1 	bl	3750 <fwp_data.part.0.constprop.0>
    6410:	97fff41c 	bl	3480 <fwp_rc_fresh>
    6414:	aa0003e1 	mov	x1, x0
    6418:	910ca3e0 	add	x0, sp, #0x328
    641c:	f90197f5 	str	x21, [sp, #808]
    6420:	f9019be1 	str	x1, [sp, #816]
    6424:	97fff4cb 	bl	3750 <fwp_data.part.0.constprop.0>
    6428:	97fff416 	bl	3480 <fwp_rc_fresh>
    642c:	aa0003e1 	mov	x1, x0
    6430:	910ce3e0 	add	x0, sp, #0x338
    6434:	f9019ff7 	str	x23, [sp, #824]
    6438:	f901a3e1 	str	x1, [sp, #832]
    643c:	97fff4c5 	bl	3750 <fwp_data.part.0.constprop.0>
    6440:	97fff410 	bl	3480 <fwp_rc_fresh>
    6444:	aa0003e1 	mov	x1, x0
    6448:	910d23e0 	add	x0, sp, #0x348
    644c:	f901a7f5 	str	x21, [sp, #840]
    6450:	f901abe1 	str	x1, [sp, #848]
    6454:	97fff4bf 	bl	3750 <fwp_data.part.0.constprop.0>
    6458:	aa0003f5 	mov	x21, x0
    645c:	91158283 	add	x3, x20, #0x560
    6460:	f949d861 	ldr	x1, [x3, #5040]
    6464:	f949ec60 	ldr	x0, [x3, #5080]
    6468:	cb0102a1 	sub	x1, x21, x1
    646c:	eb00403f 	cmp	x1, x0, lsl #16
    6470:	54000322 	b.cs	64d4 <f0+0x814>  // b.hs, b.nlast
    6474:	d350fc22 	lsr	x2, x1, #16
    6478:	f949fc63 	ldr	x3, [x3, #5112]
    647c:	8b020842 	add	x2, x2, x2, lsl #2
    6480:	d37df042 	lsl	x2, x2, #3
    6484:	8b020060 	add	x0, x3, x2
    6488:	f9401017 	ldr	x23, [x0, #32]
    648c:	b4000257 	cbz	x23, 64d4 <f0+0x814>
    6490:	38626862 	ldrb	w2, [x3, x2]
    6494:	7100085f 	cmp	w2, #0x2
    6498:	5400cce0 	b.eq	7e34 <f0+0x2174>  // b.none
    649c:	7100045f 	cmp	w2, #0x1
    64a0:	540001a1 	b.ne	64d4 <f0+0x814>  // b.any
    64a4:	29430002 	ldp	w2, w0, [x0, #24]
    64a8:	92403c21 	and	x1, x1, #0xffff
    64ac:	9b027c21 	mul	x1, x1, x2
    64b0:	d360fc21 	lsr	x1, x1, #32
    64b4:	eb00003f 	cmp	x1, x0
    64b8:	540000e2 	b.cs	64d4 <f0+0x814>  // b.hs, b.nlast
    64bc:	8b0102f7 	add	x23, x23, x1
    64c0:	394002e0 	ldrb	w0, [x23]
    64c4:	7103fc1f 	cmp	w0, #0xff
    64c8:	5400d700 	b.eq	7fa8 <f0+0x22e8>  // b.none
    64cc:	52800020 	mov	w0, #0x1                   	// #1
    64d0:	390002e0 	strb	w0, [x23]
    64d4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    64d8:	910d63e0 	add	x0, sp, #0x358
    64dc:	f901aff7 	str	x23, [sp, #856]
    64e0:	f901b3f5 	str	x21, [sp, #864]
    64e4:	97fff49b 	bl	3750 <fwp_data.part.0.constprop.0>
    64e8:	97fff3e6 	bl	3480 <fwp_rc_fresh>
    64ec:	aa0003e1 	mov	x1, x0
    64f0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    64f4:	910da3e0 	add	x0, sp, #0x368
    64f8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    64fc:	f901b7f5 	str	x21, [sp, #872]
    6500:	f901bbe1 	str	x1, [sp, #880]
    6504:	97fff493 	bl	3750 <fwp_data.part.0.constprop.0>
    6508:	97fff3de 	bl	3480 <fwp_rc_fresh>
    650c:	aa0003e1 	mov	x1, x0
    6510:	910de3e0 	add	x0, sp, #0x378
    6514:	f901bff7 	str	x23, [sp, #888]
    6518:	f901c3e1 	str	x1, [sp, #896]
    651c:	97fff48d 	bl	3750 <fwp_data.part.0.constprop.0>
    6520:	97fff3d8 	bl	3480 <fwp_rc_fresh>
    6524:	aa0003e1 	mov	x1, x0
    6528:	910e23e0 	add	x0, sp, #0x388
    652c:	f901c7f5 	str	x21, [sp, #904]
    6530:	f901cbe1 	str	x1, [sp, #912]
    6534:	97fff487 	bl	3750 <fwp_data.part.0.constprop.0>
    6538:	aa0003f5 	mov	x21, x0
    653c:	91158283 	add	x3, x20, #0x560
    6540:	f949d861 	ldr	x1, [x3, #5040]
    6544:	f949ec60 	ldr	x0, [x3, #5080]
    6548:	cb0102a1 	sub	x1, x21, x1
    654c:	eb00403f 	cmp	x1, x0, lsl #16
    6550:	54000322 	b.cs	65b4 <f0+0x8f4>  // b.hs, b.nlast
    6554:	d350fc22 	lsr	x2, x1, #16
    6558:	f949fc63 	ldr	x3, [x3, #5112]
    655c:	8b020842 	add	x2, x2, x2, lsl #2
    6560:	d37df042 	lsl	x2, x2, #3
    6564:	8b020060 	add	x0, x3, x2
    6568:	f9401017 	ldr	x23, [x0, #32]
    656c:	b4000257 	cbz	x23, 65b4 <f0+0x8f4>
    6570:	38626862 	ldrb	w2, [x3, x2]
    6574:	7100085f 	cmp	w2, #0x2
    6578:	5400c580 	b.eq	7e28 <f0+0x2168>  // b.none
    657c:	7100045f 	cmp	w2, #0x1
    6580:	540001a1 	b.ne	65b4 <f0+0x8f4>  // b.any
    6584:	29430002 	ldp	w2, w0, [x0, #24]
    6588:	92403c21 	and	x1, x1, #0xffff
    658c:	9b027c21 	mul	x1, x1, x2
    6590:	d360fc21 	lsr	x1, x1, #32
    6594:	eb00003f 	cmp	x1, x0
    6598:	540000e2 	b.cs	65b4 <f0+0x8f4>  // b.hs, b.nlast
    659c:	8b0102f7 	add	x23, x23, x1
    65a0:	394002e0 	ldrb	w0, [x23]
    65a4:	7103fc1f 	cmp	w0, #0xff
    65a8:	5400d060 	b.eq	7fb4 <f0+0x22f4>  // b.none
    65ac:	52800020 	mov	w0, #0x1                   	// #1
    65b0:	390002e0 	strb	w0, [x23]
    65b4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    65b8:	910e63e0 	add	x0, sp, #0x398
    65bc:	f901cff7 	str	x23, [sp, #920]
    65c0:	f901d3f5 	str	x21, [sp, #928]
    65c4:	97fff463 	bl	3750 <fwp_data.part.0.constprop.0>
    65c8:	97fff3ae 	bl	3480 <fwp_rc_fresh>
    65cc:	aa0003e1 	mov	x1, x0
    65d0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    65d4:	910ea3e0 	add	x0, sp, #0x3a8
    65d8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    65dc:	f901d7f5 	str	x21, [sp, #936]
    65e0:	f901dbe1 	str	x1, [sp, #944]
    65e4:	97fff45b 	bl	3750 <fwp_data.part.0.constprop.0>
    65e8:	97fff3a6 	bl	3480 <fwp_rc_fresh>
    65ec:	aa0003e1 	mov	x1, x0
    65f0:	910ee3e0 	add	x0, sp, #0x3b8
    65f4:	f901dff7 	str	x23, [sp, #952]
    65f8:	f901e3e1 	str	x1, [sp, #960]
    65fc:	97fff455 	bl	3750 <fwp_data.part.0.constprop.0>
    6600:	97fff3a0 	bl	3480 <fwp_rc_fresh>
    6604:	aa0003e1 	mov	x1, x0
    6608:	910f23e0 	add	x0, sp, #0x3c8
    660c:	f901e7f5 	str	x21, [sp, #968]
    6610:	f901ebe1 	str	x1, [sp, #976]
    6614:	97fff44f 	bl	3750 <fwp_data.part.0.constprop.0>
    6618:	aa0003f5 	mov	x21, x0
    661c:	91158283 	add	x3, x20, #0x560
    6620:	f949d861 	ldr	x1, [x3, #5040]
    6624:	f949ec60 	ldr	x0, [x3, #5080]
    6628:	cb0102a1 	sub	x1, x21, x1
    662c:	eb00403f 	cmp	x1, x0, lsl #16
    6630:	54000322 	b.cs	6694 <f0+0x9d4>  // b.hs, b.nlast
    6634:	d350fc22 	lsr	x2, x1, #16
    6638:	f949fc63 	ldr	x3, [x3, #5112]
    663c:	8b020842 	add	x2, x2, x2, lsl #2
    6640:	d37df042 	lsl	x2, x2, #3
    6644:	8b020060 	add	x0, x3, x2
    6648:	f9401017 	ldr	x23, [x0, #32]
    664c:	b4000257 	cbz	x23, 6694 <f0+0x9d4>
    6650:	38626862 	ldrb	w2, [x3, x2]
    6654:	7100085f 	cmp	w2, #0x2
    6658:	5400be20 	b.eq	7e1c <f0+0x215c>  // b.none
    665c:	7100045f 	cmp	w2, #0x1
    6660:	540001a1 	b.ne	6694 <f0+0x9d4>  // b.any
    6664:	29430002 	ldp	w2, w0, [x0, #24]
    6668:	92403c21 	and	x1, x1, #0xffff
    666c:	9b027c21 	mul	x1, x1, x2
    6670:	d360fc21 	lsr	x1, x1, #32
    6674:	eb00003f 	cmp	x1, x0
    6678:	540000e2 	b.cs	6694 <f0+0x9d4>  // b.hs, b.nlast
    667c:	8b0102f7 	add	x23, x23, x1
    6680:	394002e0 	ldrb	w0, [x23]
    6684:	7103fc1f 	cmp	w0, #0xff
    6688:	5400c9c0 	b.eq	7fc0 <f0+0x2300>  // b.none
    668c:	52800020 	mov	w0, #0x1                   	// #1
    6690:	390002e0 	strb	w0, [x23]
    6694:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6698:	910f63e0 	add	x0, sp, #0x3d8
    669c:	f901efe1 	str	x1, [sp, #984]
    66a0:	f901f3f5 	str	x21, [sp, #992]
    66a4:	97fff42b 	bl	3750 <fwp_data.part.0.constprop.0>
    66a8:	97fff376 	bl	3480 <fwp_rc_fresh>
    66ac:	aa0003e1 	mov	x1, x0
    66b0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    66b4:	910fa3e0 	add	x0, sp, #0x3e8
    66b8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    66bc:	f901f7e2 	str	x2, [sp, #1000]
    66c0:	f901fbe1 	str	x1, [sp, #1008]
    66c4:	97fff423 	bl	3750 <fwp_data.part.0.constprop.0>
    66c8:	aa0003f5 	mov	x21, x0
    66cc:	91158283 	add	x3, x20, #0x560
    66d0:	f949d861 	ldr	x1, [x3, #5040]
    66d4:	f949ec60 	ldr	x0, [x3, #5080]
    66d8:	cb0102a1 	sub	x1, x21, x1
    66dc:	eb00403f 	cmp	x1, x0, lsl #16
    66e0:	54000322 	b.cs	6744 <f0+0xa84>  // b.hs, b.nlast
    66e4:	d350fc22 	lsr	x2, x1, #16
    66e8:	f949fc63 	ldr	x3, [x3, #5112]
    66ec:	8b020842 	add	x2, x2, x2, lsl #2
    66f0:	d37df042 	lsl	x2, x2, #3
    66f4:	8b020060 	add	x0, x3, x2
    66f8:	f9401017 	ldr	x23, [x0, #32]
    66fc:	b4000257 	cbz	x23, 6744 <f0+0xa84>
    6700:	38626862 	ldrb	w2, [x3, x2]
    6704:	7100085f 	cmp	w2, #0x2
    6708:	5400bcc0 	b.eq	7ea0 <f0+0x21e0>  // b.none
    670c:	7100045f 	cmp	w2, #0x1
    6710:	540001a1 	b.ne	6744 <f0+0xa84>  // b.any
    6714:	29430002 	ldp	w2, w0, [x0, #24]
    6718:	92403c21 	and	x1, x1, #0xffff
    671c:	9b027c21 	mul	x1, x1, x2
    6720:	d360fc21 	lsr	x1, x1, #32
    6724:	eb00003f 	cmp	x1, x0
    6728:	540000e2 	b.cs	6744 <f0+0xa84>  // b.hs, b.nlast
    672c:	8b0102f7 	add	x23, x23, x1
    6730:	394002e0 	ldrb	w0, [x23]
    6734:	7103fc1f 	cmp	w0, #0xff
    6738:	5400c4a0 	b.eq	7fcc <f0+0x230c>  // b.none
    673c:	52800020 	mov	w0, #0x1                   	// #1
    6740:	390002e0 	strb	w0, [x23]
    6744:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6748:	910fe3e0 	add	x0, sp, #0x3f8
    674c:	f901ffe1 	str	x1, [sp, #1016]
    6750:	f90203f5 	str	x21, [sp, #1024]
    6754:	97fff3ff 	bl	3750 <fwp_data.part.0.constprop.0>
    6758:	97fff34a 	bl	3480 <fwp_rc_fresh>
    675c:	aa0003e1 	mov	x1, x0
    6760:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6764:	911023e0 	add	x0, sp, #0x408
    6768:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    676c:	f90207e2 	str	x2, [sp, #1032]
    6770:	f9020be1 	str	x1, [sp, #1040]
    6774:	97fff3f7 	bl	3750 <fwp_data.part.0.constprop.0>
    6778:	aa0003f5 	mov	x21, x0
    677c:	91158283 	add	x3, x20, #0x560
    6780:	f949d861 	ldr	x1, [x3, #5040]
    6784:	f949ec60 	ldr	x0, [x3, #5080]
    6788:	cb0102a1 	sub	x1, x21, x1
    678c:	eb00403f 	cmp	x1, x0, lsl #16
    6790:	54000322 	b.cs	67f4 <f0+0xb34>  // b.hs, b.nlast
    6794:	d350fc22 	lsr	x2, x1, #16
    6798:	f949fc63 	ldr	x3, [x3, #5112]
    679c:	8b020842 	add	x2, x2, x2, lsl #2
    67a0:	d37df042 	lsl	x2, x2, #3
    67a4:	8b020060 	add	x0, x3, x2
    67a8:	f9401017 	ldr	x23, [x0, #32]
    67ac:	b4000257 	cbz	x23, 67f4 <f0+0xb34>
    67b0:	38626862 	ldrb	w2, [x3, x2]
    67b4:	7100085f 	cmp	w2, #0x2
    67b8:	5400b6e0 	b.eq	7e94 <f0+0x21d4>  // b.none
    67bc:	7100045f 	cmp	w2, #0x1
    67c0:	540001a1 	b.ne	67f4 <f0+0xb34>  // b.any
    67c4:	29430002 	ldp	w2, w0, [x0, #24]
    67c8:	92403c21 	and	x1, x1, #0xffff
    67cc:	9b027c21 	mul	x1, x1, x2
    67d0:	d360fc21 	lsr	x1, x1, #32
    67d4:	eb00003f 	cmp	x1, x0
    67d8:	540000e2 	b.cs	67f4 <f0+0xb34>  // b.hs, b.nlast
    67dc:	8b0102f7 	add	x23, x23, x1
    67e0:	394002e0 	ldrb	w0, [x23]
    67e4:	7103fc1f 	cmp	w0, #0xff
    67e8:	5400bf80 	b.eq	7fd8 <f0+0x2318>  // b.none
    67ec:	52800020 	mov	w0, #0x1                   	// #1
    67f0:	390002e0 	strb	w0, [x23]
    67f4:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    67f8:	911063e0 	add	x0, sp, #0x418
    67fc:	f9020fe1 	str	x1, [sp, #1048]
    6800:	f90213f5 	str	x21, [sp, #1056]
    6804:	97fff3d3 	bl	3750 <fwp_data.part.0.constprop.0>
    6808:	97fff31e 	bl	3480 <fwp_rc_fresh>
    680c:	aa0003e1 	mov	x1, x0
    6810:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6814:	9110a3e0 	add	x0, sp, #0x428
    6818:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    681c:	f90217e2 	str	x2, [sp, #1064]
    6820:	f9021be1 	str	x1, [sp, #1072]
    6824:	97fff3cb 	bl	3750 <fwp_data.part.0.constprop.0>
    6828:	aa0003f5 	mov	x21, x0
    682c:	91158283 	add	x3, x20, #0x560
    6830:	f949d861 	ldr	x1, [x3, #5040]
    6834:	f949ec60 	ldr	x0, [x3, #5080]
    6838:	cb0102a1 	sub	x1, x21, x1
    683c:	eb00403f 	cmp	x1, x0, lsl #16
    6840:	54000322 	b.cs	68a4 <f0+0xbe4>  // b.hs, b.nlast
    6844:	d350fc22 	lsr	x2, x1, #16
    6848:	f949fc63 	ldr	x3, [x3, #5112]
    684c:	8b020842 	add	x2, x2, x2, lsl #2
    6850:	d37df042 	lsl	x2, x2, #3
    6854:	8b020060 	add	x0, x3, x2
    6858:	f9401017 	ldr	x23, [x0, #32]
    685c:	b4000257 	cbz	x23, 68a4 <f0+0xbe4>
    6860:	38626862 	ldrb	w2, [x3, x2]
    6864:	7100085f 	cmp	w2, #0x2
    6868:	5400b100 	b.eq	7e88 <f0+0x21c8>  // b.none
    686c:	7100045f 	cmp	w2, #0x1
    6870:	540001a1 	b.ne	68a4 <f0+0xbe4>  // b.any
    6874:	29430002 	ldp	w2, w0, [x0, #24]
    6878:	92403c21 	and	x1, x1, #0xffff
    687c:	9b027c21 	mul	x1, x1, x2
    6880:	d360fc21 	lsr	x1, x1, #32
    6884:	eb00003f 	cmp	x1, x0
    6888:	540000e2 	b.cs	68a4 <f0+0xbe4>  // b.hs, b.nlast
    688c:	8b0102f7 	add	x23, x23, x1
    6890:	394002e0 	ldrb	w0, [x23]
    6894:	7103fc1f 	cmp	w0, #0xff
    6898:	5400ba60 	b.eq	7fe4 <f0+0x2324>  // b.none
    689c:	52800020 	mov	w0, #0x1                   	// #1
    68a0:	390002e0 	strb	w0, [x23]
    68a4:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    68a8:	9110e3e0 	add	x0, sp, #0x438
    68ac:	f9021fe1 	str	x1, [sp, #1080]
    68b0:	f90223f5 	str	x21, [sp, #1088]
    68b4:	97fff3a7 	bl	3750 <fwp_data.part.0.constprop.0>
    68b8:	97fff2f2 	bl	3480 <fwp_rc_fresh>
    68bc:	aa0003e1 	mov	x1, x0
    68c0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    68c4:	911123e0 	add	x0, sp, #0x448
    68c8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    68cc:	f90227e2 	str	x2, [sp, #1096]
    68d0:	f9022be1 	str	x1, [sp, #1104]
    68d4:	97fff39f 	bl	3750 <fwp_data.part.0.constprop.0>
    68d8:	aa0003f5 	mov	x21, x0
    68dc:	91158283 	add	x3, x20, #0x560
    68e0:	f949d861 	ldr	x1, [x3, #5040]
    68e4:	f949ec60 	ldr	x0, [x3, #5080]
    68e8:	cb0102a1 	sub	x1, x21, x1
    68ec:	eb00403f 	cmp	x1, x0, lsl #16
    68f0:	54000322 	b.cs	6954 <f0+0xc94>  // b.hs, b.nlast
    68f4:	d350fc22 	lsr	x2, x1, #16
    68f8:	f949fc63 	ldr	x3, [x3, #5112]
    68fc:	8b020842 	add	x2, x2, x2, lsl #2
    6900:	d37df042 	lsl	x2, x2, #3
    6904:	8b020060 	add	x0, x3, x2
    6908:	f9401017 	ldr	x23, [x0, #32]
    690c:	b4000257 	cbz	x23, 6954 <f0+0xc94>
    6910:	38626862 	ldrb	w2, [x3, x2]
    6914:	7100085f 	cmp	w2, #0x2
    6918:	5400ab20 	b.eq	7e7c <f0+0x21bc>  // b.none
    691c:	7100045f 	cmp	w2, #0x1
    6920:	540001a1 	b.ne	6954 <f0+0xc94>  // b.any
    6924:	29430002 	ldp	w2, w0, [x0, #24]
    6928:	92403c21 	and	x1, x1, #0xffff
    692c:	9b027c21 	mul	x1, x1, x2
    6930:	d360fc21 	lsr	x1, x1, #32
    6934:	eb00003f 	cmp	x1, x0
    6938:	540000e2 	b.cs	6954 <f0+0xc94>  // b.hs, b.nlast
    693c:	8b0102f7 	add	x23, x23, x1
    6940:	394002e0 	ldrb	w0, [x23]
    6944:	7103fc1f 	cmp	w0, #0xff
    6948:	5400b540 	b.eq	7ff0 <f0+0x2330>  // b.none
    694c:	52800020 	mov	w0, #0x1                   	// #1
    6950:	390002e0 	strb	w0, [x23]
    6954:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6958:	911163e0 	add	x0, sp, #0x458
    695c:	f9022ff7 	str	x23, [sp, #1112]
    6960:	f90233f5 	str	x21, [sp, #1120]
    6964:	97fff37b 	bl	3750 <fwp_data.part.0.constprop.0>
    6968:	97fff2c6 	bl	3480 <fwp_rc_fresh>
    696c:	aa0003e1 	mov	x1, x0
    6970:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6974:	9111a3e0 	add	x0, sp, #0x468
    6978:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    697c:	f90237e2 	str	x2, [sp, #1128]
    6980:	f9023be1 	str	x1, [sp, #1136]
    6984:	97fff373 	bl	3750 <fwp_data.part.0.constprop.0>
    6988:	97fff2be 	bl	3480 <fwp_rc_fresh>
    698c:	aa0003e1 	mov	x1, x0
    6990:	9111e3e0 	add	x0, sp, #0x478
    6994:	f9023ff7 	str	x23, [sp, #1144]
    6998:	f90243e1 	str	x1, [sp, #1152]
    699c:	97fff36d 	bl	3750 <fwp_data.part.0.constprop.0>
    69a0:	aa0003f5 	mov	x21, x0
    69a4:	91158283 	add	x3, x20, #0x560
    69a8:	f949d861 	ldr	x1, [x3, #5040]
    69ac:	f949ec60 	ldr	x0, [x3, #5080]
    69b0:	cb0102a1 	sub	x1, x21, x1
    69b4:	eb00403f 	cmp	x1, x0, lsl #16
    69b8:	54000322 	b.cs	6a1c <f0+0xd5c>  // b.hs, b.nlast
    69bc:	d350fc22 	lsr	x2, x1, #16
    69c0:	f949fc63 	ldr	x3, [x3, #5112]
    69c4:	8b020842 	add	x2, x2, x2, lsl #2
    69c8:	d37df042 	lsl	x2, x2, #3
    69cc:	8b020060 	add	x0, x3, x2
    69d0:	f9401017 	ldr	x23, [x0, #32]
    69d4:	b4000257 	cbz	x23, 6a1c <f0+0xd5c>
    69d8:	38626862 	ldrb	w2, [x3, x2]
    69dc:	7100085f 	cmp	w2, #0x2
    69e0:	5400a480 	b.eq	7e70 <f0+0x21b0>  // b.none
    69e4:	7100045f 	cmp	w2, #0x1
    69e8:	540001a1 	b.ne	6a1c <f0+0xd5c>  // b.any
    69ec:	29430002 	ldp	w2, w0, [x0, #24]
    69f0:	92403c21 	and	x1, x1, #0xffff
    69f4:	9b027c21 	mul	x1, x1, x2
    69f8:	d360fc21 	lsr	x1, x1, #32
    69fc:	eb00003f 	cmp	x1, x0
    6a00:	540000e2 	b.cs	6a1c <f0+0xd5c>  // b.hs, b.nlast
    6a04:	8b0102f7 	add	x23, x23, x1
    6a08:	394002e0 	ldrb	w0, [x23]
    6a0c:	7103fc1f 	cmp	w0, #0xff
    6a10:	5400af60 	b.eq	7ffc <f0+0x233c>  // b.none
    6a14:	52800020 	mov	w0, #0x1                   	// #1
    6a18:	390002e0 	strb	w0, [x23]
    6a1c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6a20:	911223e0 	add	x0, sp, #0x488
    6a24:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6a28:	f90247f7 	str	x23, [sp, #1160]
    6a2c:	f9024bf5 	str	x21, [sp, #1168]
    6a30:	97fff348 	bl	3750 <fwp_data.part.0.constprop.0>
    6a34:	97fff293 	bl	3480 <fwp_rc_fresh>
    6a38:	aa0003e1 	mov	x1, x0
    6a3c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    6a40:	911263e0 	add	x0, sp, #0x498
    6a44:	f9024fe2 	str	x2, [sp, #1176]
    6a48:	f90253e1 	str	x1, [sp, #1184]
    6a4c:	97fff341 	bl	3750 <fwp_data.part.0.constprop.0>
    6a50:	97fff28c 	bl	3480 <fwp_rc_fresh>
    6a54:	aa0003e1 	mov	x1, x0
    6a58:	9112a3e0 	add	x0, sp, #0x4a8
    6a5c:	f90257f7 	str	x23, [sp, #1192]
    6a60:	f9025be1 	str	x1, [sp, #1200]
    6a64:	97fff33b 	bl	3750 <fwp_data.part.0.constprop.0>
    6a68:	aa0003f5 	mov	x21, x0
    6a6c:	91158283 	add	x3, x20, #0x560
    6a70:	f949d861 	ldr	x1, [x3, #5040]
    6a74:	f949ec60 	ldr	x0, [x3, #5080]
    6a78:	cb0102a1 	sub	x1, x21, x1
    6a7c:	eb00403f 	cmp	x1, x0, lsl #16
    6a80:	54000322 	b.cs	6ae4 <f0+0xe24>  // b.hs, b.nlast
    6a84:	d350fc22 	lsr	x2, x1, #16
    6a88:	f949fc63 	ldr	x3, [x3, #5112]
    6a8c:	8b020842 	add	x2, x2, x2, lsl #2
    6a90:	d37df042 	lsl	x2, x2, #3
    6a94:	8b020060 	add	x0, x3, x2
    6a98:	f9401017 	ldr	x23, [x0, #32]
    6a9c:	b4000257 	cbz	x23, 6ae4 <f0+0xe24>
    6aa0:	38626862 	ldrb	w2, [x3, x2]
    6aa4:	7100085f 	cmp	w2, #0x2
    6aa8:	54009de0 	b.eq	7e64 <f0+0x21a4>  // b.none
    6aac:	7100045f 	cmp	w2, #0x1
    6ab0:	540001a1 	b.ne	6ae4 <f0+0xe24>  // b.any
    6ab4:	29430002 	ldp	w2, w0, [x0, #24]
    6ab8:	92403c21 	and	x1, x1, #0xffff
    6abc:	9b027c21 	mul	x1, x1, x2
    6ac0:	d360fc21 	lsr	x1, x1, #32
    6ac4:	eb00003f 	cmp	x1, x0
    6ac8:	540000e2 	b.cs	6ae4 <f0+0xe24>  // b.hs, b.nlast
    6acc:	8b0102f7 	add	x23, x23, x1
    6ad0:	394002e0 	ldrb	w0, [x23]
    6ad4:	7103fc1f 	cmp	w0, #0xff
    6ad8:	5400a980 	b.eq	8008 <f0+0x2348>  // b.none
    6adc:	52800020 	mov	w0, #0x1                   	// #1
    6ae0:	390002e0 	strb	w0, [x23]
    6ae4:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6ae8:	9112e3e0 	add	x0, sp, #0x4b8
    6aec:	f9025fe1 	str	x1, [sp, #1208]
    6af0:	f90263f5 	str	x21, [sp, #1216]
    6af4:	97fff317 	bl	3750 <fwp_data.part.0.constprop.0>
    6af8:	97fff262 	bl	3480 <fwp_rc_fresh>
    6afc:	aa0003e1 	mov	x1, x0
    6b00:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6b04:	911323e0 	add	x0, sp, #0x4c8
    6b08:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6b0c:	f90267e2 	str	x2, [sp, #1224]
    6b10:	f9026be1 	str	x1, [sp, #1232]
    6b14:	97fff30f 	bl	3750 <fwp_data.part.0.constprop.0>
    6b18:	aa0003f5 	mov	x21, x0
    6b1c:	91158283 	add	x3, x20, #0x560
    6b20:	f949d861 	ldr	x1, [x3, #5040]
    6b24:	f949ec60 	ldr	x0, [x3, #5080]
    6b28:	cb0102a1 	sub	x1, x21, x1
    6b2c:	eb00403f 	cmp	x1, x0, lsl #16
    6b30:	54000322 	b.cs	6b94 <f0+0xed4>  // b.hs, b.nlast
    6b34:	d350fc22 	lsr	x2, x1, #16
    6b38:	f949fc63 	ldr	x3, [x3, #5112]
    6b3c:	8b020842 	add	x2, x2, x2, lsl #2
    6b40:	d37df042 	lsl	x2, x2, #3
    6b44:	8b020060 	add	x0, x3, x2
    6b48:	f9401017 	ldr	x23, [x0, #32]
    6b4c:	b4000257 	cbz	x23, 6b94 <f0+0xed4>
    6b50:	38626862 	ldrb	w2, [x3, x2]
    6b54:	7100085f 	cmp	w2, #0x2
    6b58:	54009800 	b.eq	7e58 <f0+0x2198>  // b.none
    6b5c:	7100045f 	cmp	w2, #0x1
    6b60:	540001a1 	b.ne	6b94 <f0+0xed4>  // b.any
    6b64:	29430002 	ldp	w2, w0, [x0, #24]
    6b68:	92403c21 	and	x1, x1, #0xffff
    6b6c:	9b027c21 	mul	x1, x1, x2
    6b70:	d360fc21 	lsr	x1, x1, #32
    6b74:	eb00003f 	cmp	x1, x0
    6b78:	540000e2 	b.cs	6b94 <f0+0xed4>  // b.hs, b.nlast
    6b7c:	8b0102f7 	add	x23, x23, x1
    6b80:	394002e0 	ldrb	w0, [x23]
    6b84:	7103fc1f 	cmp	w0, #0xff
    6b88:	5400a460 	b.eq	8014 <f0+0x2354>  // b.none
    6b8c:	52800020 	mov	w0, #0x1                   	// #1
    6b90:	390002e0 	strb	w0, [x23]
    6b94:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6b98:	911363e0 	add	x0, sp, #0x4d8
    6b9c:	f9026ff7 	str	x23, [sp, #1240]
    6ba0:	f90273f5 	str	x21, [sp, #1248]
    6ba4:	97fff2eb 	bl	3750 <fwp_data.part.0.constprop.0>
    6ba8:	97fff236 	bl	3480 <fwp_rc_fresh>
    6bac:	aa0003e1 	mov	x1, x0
    6bb0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6bb4:	9113a3e0 	add	x0, sp, #0x4e8
    6bb8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6bbc:	f90277e2 	str	x2, [sp, #1256]
    6bc0:	f9027be1 	str	x1, [sp, #1264]
    6bc4:	97fff2e3 	bl	3750 <fwp_data.part.0.constprop.0>
    6bc8:	97fff22e 	bl	3480 <fwp_rc_fresh>
    6bcc:	aa0003e1 	mov	x1, x0
    6bd0:	9113e3e0 	add	x0, sp, #0x4f8
    6bd4:	f9027ff7 	str	x23, [sp, #1272]
    6bd8:	f90283e1 	str	x1, [sp, #1280]
    6bdc:	97fff2dd 	bl	3750 <fwp_data.part.0.constprop.0>
    6be0:	aa0003f5 	mov	x21, x0
    6be4:	91158283 	add	x3, x20, #0x560
    6be8:	f949d861 	ldr	x1, [x3, #5040]
    6bec:	f949ec60 	ldr	x0, [x3, #5080]
    6bf0:	cb0102a1 	sub	x1, x21, x1
    6bf4:	eb00403f 	cmp	x1, x0, lsl #16
    6bf8:	54000322 	b.cs	6c5c <f0+0xf9c>  // b.hs, b.nlast
    6bfc:	d350fc22 	lsr	x2, x1, #16
    6c00:	f949fc63 	ldr	x3, [x3, #5112]
    6c04:	8b020842 	add	x2, x2, x2, lsl #2
    6c08:	d37df042 	lsl	x2, x2, #3
    6c0c:	8b020060 	add	x0, x3, x2
    6c10:	f9401017 	ldr	x23, [x0, #32]
    6c14:	b4000257 	cbz	x23, 6c5c <f0+0xf9c>
    6c18:	38626862 	ldrb	w2, [x3, x2]
    6c1c:	7100085f 	cmp	w2, #0x2
    6c20:	54009160 	b.eq	7e4c <f0+0x218c>  // b.none
    6c24:	7100045f 	cmp	w2, #0x1
    6c28:	540001a1 	b.ne	6c5c <f0+0xf9c>  // b.any
    6c2c:	29430002 	ldp	w2, w0, [x0, #24]
    6c30:	92403c21 	and	x1, x1, #0xffff
    6c34:	9b027c21 	mul	x1, x1, x2
    6c38:	d360fc21 	lsr	x1, x1, #32
    6c3c:	eb00003f 	cmp	x1, x0
    6c40:	540000e2 	b.cs	6c5c <f0+0xf9c>  // b.hs, b.nlast
    6c44:	8b0102f7 	add	x23, x23, x1
    6c48:	394002e0 	ldrb	w0, [x23]
    6c4c:	7103fc1f 	cmp	w0, #0xff
    6c50:	54009e80 	b.eq	8020 <f0+0x2360>  // b.none
    6c54:	52800020 	mov	w0, #0x1                   	// #1
    6c58:	390002e0 	strb	w0, [x23]
    6c5c:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    6c60:	911423e0 	add	x0, sp, #0x508
    6c64:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    6c68:	f90287e1 	str	x1, [sp, #1288]
    6c6c:	f9028bf5 	str	x21, [sp, #1296]
    6c70:	97fff2b8 	bl	3750 <fwp_data.part.0.constprop.0>
    6c74:	aa0003f5 	mov	x21, x0
    6c78:	91158283 	add	x3, x20, #0x560
    6c7c:	f949d861 	ldr	x1, [x3, #5040]
    6c80:	f949ec60 	ldr	x0, [x3, #5080]
    6c84:	cb0102a1 	sub	x1, x21, x1
    6c88:	eb00403f 	cmp	x1, x0, lsl #16
    6c8c:	54000322 	b.cs	6cf0 <f0+0x1030>  // b.hs, b.nlast
    6c90:	d350fc22 	lsr	x2, x1, #16
    6c94:	f949fc63 	ldr	x3, [x3, #5112]
    6c98:	8b020842 	add	x2, x2, x2, lsl #2
    6c9c:	d37df042 	lsl	x2, x2, #3
    6ca0:	8b020060 	add	x0, x3, x2
    6ca4:	f9401017 	ldr	x23, [x0, #32]
    6ca8:	b4000257 	cbz	x23, 6cf0 <f0+0x1030>
    6cac:	38626862 	ldrb	w2, [x3, x2]
    6cb0:	7100085f 	cmp	w2, #0x2
    6cb4:	540089c0 	b.eq	7dec <f0+0x212c>  // b.none
    6cb8:	7100045f 	cmp	w2, #0x1
    6cbc:	540001a1 	b.ne	6cf0 <f0+0x1030>  // b.any
    6cc0:	29430002 	ldp	w2, w0, [x0, #24]
    6cc4:	92403c21 	and	x1, x1, #0xffff
    6cc8:	9b027c21 	mul	x1, x1, x2
    6ccc:	d360fc21 	lsr	x1, x1, #32
    6cd0:	eb00003f 	cmp	x1, x0
    6cd4:	540000e2 	b.cs	6cf0 <f0+0x1030>  // b.hs, b.nlast
    6cd8:	8b0102f7 	add	x23, x23, x1
    6cdc:	394002e0 	ldrb	w0, [x23]
    6ce0:	7103fc1f 	cmp	w0, #0xff
    6ce4:	54009a40 	b.eq	802c <f0+0x236c>  // b.none
    6ce8:	52800020 	mov	w0, #0x1                   	// #1
    6cec:	390002e0 	strb	w0, [x23]
    6cf0:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6cf4:	911463e0 	add	x0, sp, #0x518
    6cf8:	f9028fe1 	str	x1, [sp, #1304]
    6cfc:	f90293f5 	str	x21, [sp, #1312]
    6d00:	97fff294 	bl	3750 <fwp_data.part.0.constprop.0>
    6d04:	97fff1df 	bl	3480 <fwp_rc_fresh>
    6d08:	aa0003e1 	mov	x1, x0
    6d0c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6d10:	9114a3e0 	add	x0, sp, #0x528
    6d14:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6d18:	f90297e2 	str	x2, [sp, #1320]
    6d1c:	f9029be1 	str	x1, [sp, #1328]
    6d20:	97fff28c 	bl	3750 <fwp_data.part.0.constprop.0>
    6d24:	aa0003f5 	mov	x21, x0
    6d28:	91158283 	add	x3, x20, #0x560
    6d2c:	f949d861 	ldr	x1, [x3, #5040]
    6d30:	f949ec60 	ldr	x0, [x3, #5080]
    6d34:	cb0102a1 	sub	x1, x21, x1
    6d38:	eb00403f 	cmp	x1, x0, lsl #16
    6d3c:	54000322 	b.cs	6da0 <f0+0x10e0>  // b.hs, b.nlast
    6d40:	d350fc22 	lsr	x2, x1, #16
    6d44:	f949fc63 	ldr	x3, [x3, #5112]
    6d48:	8b020842 	add	x2, x2, x2, lsl #2
    6d4c:	d37df042 	lsl	x2, x2, #3
    6d50:	8b020060 	add	x0, x3, x2
    6d54:	f9401017 	ldr	x23, [x0, #32]
    6d58:	b4000257 	cbz	x23, 6da0 <f0+0x10e0>
    6d5c:	38626862 	ldrb	w2, [x3, x2]
    6d60:	7100085f 	cmp	w2, #0x2
    6d64:	540083e0 	b.eq	7de0 <f0+0x2120>  // b.none
    6d68:	7100045f 	cmp	w2, #0x1
    6d6c:	540001a1 	b.ne	6da0 <f0+0x10e0>  // b.any
    6d70:	29430002 	ldp	w2, w0, [x0, #24]
    6d74:	92403c21 	and	x1, x1, #0xffff
    6d78:	9b027c21 	mul	x1, x1, x2
    6d7c:	d360fc21 	lsr	x1, x1, #32
    6d80:	eb00003f 	cmp	x1, x0
    6d84:	540000e2 	b.cs	6da0 <f0+0x10e0>  // b.hs, b.nlast
    6d88:	8b0102f7 	add	x23, x23, x1
    6d8c:	394002e0 	ldrb	w0, [x23]
    6d90:	7103fc1f 	cmp	w0, #0xff
    6d94:	54009520 	b.eq	8038 <f0+0x2378>  // b.none
    6d98:	52800020 	mov	w0, #0x1                   	// #1
    6d9c:	390002e0 	strb	w0, [x23]
    6da0:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6da4:	9114e3e0 	add	x0, sp, #0x538
    6da8:	f9029fe1 	str	x1, [sp, #1336]
    6dac:	f902a3f5 	str	x21, [sp, #1344]
    6db0:	97fff268 	bl	3750 <fwp_data.part.0.constprop.0>
    6db4:	97fff1b3 	bl	3480 <fwp_rc_fresh>
    6db8:	aa0003e1 	mov	x1, x0
    6dbc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6dc0:	911523e0 	add	x0, sp, #0x548
    6dc4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6dc8:	f902a7e2 	str	x2, [sp, #1352]
    6dcc:	f902abe1 	str	x1, [sp, #1360]
    6dd0:	97fff260 	bl	3750 <fwp_data.part.0.constprop.0>
    6dd4:	aa0003f5 	mov	x21, x0
    6dd8:	91158283 	add	x3, x20, #0x560
    6ddc:	f949d861 	ldr	x1, [x3, #5040]
    6de0:	f949ec60 	ldr	x0, [x3, #5080]
    6de4:	cb0102a1 	sub	x1, x21, x1
    6de8:	eb00403f 	cmp	x1, x0, lsl #16
    6dec:	54000322 	b.cs	6e50 <f0+0x1190>  // b.hs, b.nlast
    6df0:	d350fc22 	lsr	x2, x1, #16
    6df4:	f949fc63 	ldr	x3, [x3, #5112]
    6df8:	8b020842 	add	x2, x2, x2, lsl #2
    6dfc:	d37df042 	lsl	x2, x2, #3
    6e00:	8b020060 	add	x0, x3, x2
    6e04:	f9401017 	ldr	x23, [x0, #32]
    6e08:	b4000257 	cbz	x23, 6e50 <f0+0x1190>
    6e0c:	38626862 	ldrb	w2, [x3, x2]
    6e10:	7100085f 	cmp	w2, #0x2
    6e14:	54007e00 	b.eq	7dd4 <f0+0x2114>  // b.none
    6e18:	7100045f 	cmp	w2, #0x1
    6e1c:	540001a1 	b.ne	6e50 <f0+0x1190>  // b.any
    6e20:	29430002 	ldp	w2, w0, [x0, #24]
    6e24:	92403c21 	and	x1, x1, #0xffff
    6e28:	9b027c21 	mul	x1, x1, x2
    6e2c:	d360fc21 	lsr	x1, x1, #32
    6e30:	eb00003f 	cmp	x1, x0
    6e34:	540000e2 	b.cs	6e50 <f0+0x1190>  // b.hs, b.nlast
    6e38:	8b0102f7 	add	x23, x23, x1
    6e3c:	394002e0 	ldrb	w0, [x23]
    6e40:	7103fc1f 	cmp	w0, #0xff
    6e44:	54009000 	b.eq	8044 <f0+0x2384>  // b.none
    6e48:	52800020 	mov	w0, #0x1                   	// #1
    6e4c:	390002e0 	strb	w0, [x23]
    6e50:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6e54:	911563e0 	add	x0, sp, #0x558
    6e58:	f902aff7 	str	x23, [sp, #1368]
    6e5c:	f902b3f5 	str	x21, [sp, #1376]
    6e60:	97fff23c 	bl	3750 <fwp_data.part.0.constprop.0>
    6e64:	97fff187 	bl	3480 <fwp_rc_fresh>
    6e68:	aa0003e1 	mov	x1, x0
    6e6c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6e70:	9115a3e0 	add	x0, sp, #0x568
    6e74:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    6e78:	f902b7f5 	str	x21, [sp, #1384]
    6e7c:	f902bbe1 	str	x1, [sp, #1392]
    6e80:	97fff234 	bl	3750 <fwp_data.part.0.constprop.0>
    6e84:	97fff17f 	bl	3480 <fwp_rc_fresh>
    6e88:	aa0003e1 	mov	x1, x0
    6e8c:	9115e3e0 	add	x0, sp, #0x578
    6e90:	f902bff7 	str	x23, [sp, #1400]
    6e94:	f902c3e1 	str	x1, [sp, #1408]
    6e98:	97fff22e 	bl	3750 <fwp_data.part.0.constprop.0>
    6e9c:	97fff179 	bl	3480 <fwp_rc_fresh>
    6ea0:	aa0003e1 	mov	x1, x0
    6ea4:	911623e0 	add	x0, sp, #0x588
    6ea8:	f902c7f5 	str	x21, [sp, #1416]
    6eac:	f902cbe1 	str	x1, [sp, #1424]
    6eb0:	97fff228 	bl	3750 <fwp_data.part.0.constprop.0>
    6eb4:	aa0003f5 	mov	x21, x0
    6eb8:	91158283 	add	x3, x20, #0x560
    6ebc:	f949d861 	ldr	x1, [x3, #5040]
    6ec0:	f949ec60 	ldr	x0, [x3, #5080]
    6ec4:	cb0102a1 	sub	x1, x21, x1
    6ec8:	eb00403f 	cmp	x1, x0, lsl #16
    6ecc:	54000322 	b.cs	6f30 <f0+0x1270>  // b.hs, b.nlast
    6ed0:	d350fc22 	lsr	x2, x1, #16
    6ed4:	f949fc63 	ldr	x3, [x3, #5112]
    6ed8:	8b020842 	add	x2, x2, x2, lsl #2
    6edc:	d37df042 	lsl	x2, x2, #3
    6ee0:	8b020060 	add	x0, x3, x2
    6ee4:	f9401017 	ldr	x23, [x0, #32]
    6ee8:	b4000257 	cbz	x23, 6f30 <f0+0x1270>
    6eec:	38626862 	ldrb	w2, [x3, x2]
    6ef0:	7100085f 	cmp	w2, #0x2
    6ef4:	540076a0 	b.eq	7dc8 <f0+0x2108>  // b.none
    6ef8:	7100045f 	cmp	w2, #0x1
    6efc:	540001a1 	b.ne	6f30 <f0+0x1270>  // b.any
    6f00:	29430002 	ldp	w2, w0, [x0, #24]
    6f04:	92403c21 	and	x1, x1, #0xffff
    6f08:	9b027c21 	mul	x1, x1, x2
    6f0c:	d360fc21 	lsr	x1, x1, #32
    6f10:	eb00003f 	cmp	x1, x0
    6f14:	540000e2 	b.cs	6f30 <f0+0x1270>  // b.hs, b.nlast
    6f18:	8b0102f7 	add	x23, x23, x1
    6f1c:	394002e0 	ldrb	w0, [x23]
    6f20:	7103fc1f 	cmp	w0, #0xff
    6f24:	54008960 	b.eq	8050 <f0+0x2390>  // b.none
    6f28:	52800020 	mov	w0, #0x1                   	// #1
    6f2c:	390002e0 	strb	w0, [x23]
    6f30:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6f34:	911663e0 	add	x0, sp, #0x598
    6f38:	f902cfe1 	str	x1, [sp, #1432]
    6f3c:	f902d3f5 	str	x21, [sp, #1440]
    6f40:	97fff204 	bl	3750 <fwp_data.part.0.constprop.0>
    6f44:	97fff14f 	bl	3480 <fwp_rc_fresh>
    6f48:	aa0003e1 	mov	x1, x0
    6f4c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6f50:	9116a3e0 	add	x0, sp, #0x5a8
    6f54:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6f58:	f902d7e2 	str	x2, [sp, #1448]
    6f5c:	f902dbe1 	str	x1, [sp, #1456]
    6f60:	97fff1fc 	bl	3750 <fwp_data.part.0.constprop.0>
    6f64:	aa0003f5 	mov	x21, x0
    6f68:	91158283 	add	x3, x20, #0x560
    6f6c:	f949d861 	ldr	x1, [x3, #5040]
    6f70:	f949ec60 	ldr	x0, [x3, #5080]
    6f74:	cb0102a1 	sub	x1, x21, x1
    6f78:	eb00403f 	cmp	x1, x0, lsl #16
    6f7c:	54000322 	b.cs	6fe0 <f0+0x1320>  // b.hs, b.nlast
    6f80:	d350fc22 	lsr	x2, x1, #16
    6f84:	f949fc63 	ldr	x3, [x3, #5112]
    6f88:	8b020842 	add	x2, x2, x2, lsl #2
    6f8c:	d37df042 	lsl	x2, x2, #3
    6f90:	8b020060 	add	x0, x3, x2
    6f94:	f9401017 	ldr	x23, [x0, #32]
    6f98:	b4000257 	cbz	x23, 6fe0 <f0+0x1320>
    6f9c:	38626862 	ldrb	w2, [x3, x2]
    6fa0:	7100085f 	cmp	w2, #0x2
    6fa4:	540070c0 	b.eq	7dbc <f0+0x20fc>  // b.none
    6fa8:	7100045f 	cmp	w2, #0x1
    6fac:	540001a1 	b.ne	6fe0 <f0+0x1320>  // b.any
    6fb0:	29430002 	ldp	w2, w0, [x0, #24]
    6fb4:	92403c21 	and	x1, x1, #0xffff
    6fb8:	9b027c21 	mul	x1, x1, x2
    6fbc:	d360fc21 	lsr	x1, x1, #32
    6fc0:	eb00003f 	cmp	x1, x0
    6fc4:	540000e2 	b.cs	6fe0 <f0+0x1320>  // b.hs, b.nlast
    6fc8:	8b0102f7 	add	x23, x23, x1
    6fcc:	394002e0 	ldrb	w0, [x23]
    6fd0:	7103fc1f 	cmp	w0, #0xff
    6fd4:	54008440 	b.eq	805c <f0+0x239c>  // b.none
    6fd8:	52800020 	mov	w0, #0x1                   	// #1
    6fdc:	390002e0 	strb	w0, [x23]
    6fe0:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6fe4:	9116e3e0 	add	x0, sp, #0x5b8
    6fe8:	f902dfe1 	str	x1, [sp, #1464]
    6fec:	f902e3f5 	str	x21, [sp, #1472]
    6ff0:	97fff1d8 	bl	3750 <fwp_data.part.0.constprop.0>
    6ff4:	97fff123 	bl	3480 <fwp_rc_fresh>
    6ff8:	aa0003e1 	mov	x1, x0
    6ffc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7000:	911723e0 	add	x0, sp, #0x5c8
    7004:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7008:	f902e7e2 	str	x2, [sp, #1480]
    700c:	f902ebe1 	str	x1, [sp, #1488]
    7010:	97fff1d0 	bl	3750 <fwp_data.part.0.constprop.0>
    7014:	aa0003f5 	mov	x21, x0
    7018:	91158283 	add	x3, x20, #0x560
    701c:	f949d861 	ldr	x1, [x3, #5040]
    7020:	f949ec60 	ldr	x0, [x3, #5080]
    7024:	cb0102a1 	sub	x1, x21, x1
    7028:	eb00403f 	cmp	x1, x0, lsl #16
    702c:	54000322 	b.cs	7090 <f0+0x13d0>  // b.hs, b.nlast
    7030:	d350fc22 	lsr	x2, x1, #16
    7034:	f949fc63 	ldr	x3, [x3, #5112]
    7038:	8b020842 	add	x2, x2, x2, lsl #2
    703c:	d37df042 	lsl	x2, x2, #3
    7040:	8b020060 	add	x0, x3, x2
    7044:	f9401017 	ldr	x23, [x0, #32]
    7048:	b4000257 	cbz	x23, 7090 <f0+0x13d0>
    704c:	38626862 	ldrb	w2, [x3, x2]
    7050:	7100085f 	cmp	w2, #0x2
    7054:	54006ae0 	b.eq	7db0 <f0+0x20f0>  // b.none
    7058:	7100045f 	cmp	w2, #0x1
    705c:	540001a1 	b.ne	7090 <f0+0x13d0>  // b.any
    7060:	29430002 	ldp	w2, w0, [x0, #24]
    7064:	92403c21 	and	x1, x1, #0xffff
    7068:	9b027c21 	mul	x1, x1, x2
    706c:	d360fc21 	lsr	x1, x1, #32
    7070:	eb00003f 	cmp	x1, x0
    7074:	540000e2 	b.cs	7090 <f0+0x13d0>  // b.hs, b.nlast
    7078:	8b0102f7 	add	x23, x23, x1
    707c:	394002e0 	ldrb	w0, [x23]
    7080:	7103fc1f 	cmp	w0, #0xff
    7084:	54007f20 	b.eq	8068 <f0+0x23a8>  // b.none
    7088:	52800020 	mov	w0, #0x1                   	// #1
    708c:	390002e0 	strb	w0, [x23]
    7090:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7094:	911763e0 	add	x0, sp, #0x5d8
    7098:	f902eff7 	str	x23, [sp, #1496]
    709c:	f902f3f5 	str	x21, [sp, #1504]
    70a0:	97fff1ac 	bl	3750 <fwp_data.part.0.constprop.0>
    70a4:	97fff0f7 	bl	3480 <fwp_rc_fresh>
    70a8:	aa0003e1 	mov	x1, x0
    70ac:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    70b0:	9117a3e0 	add	x0, sp, #0x5e8
    70b4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    70b8:	f902f7e2 	str	x2, [sp, #1512]
    70bc:	f902fbe1 	str	x1, [sp, #1520]
    70c0:	97fff1a4 	bl	3750 <fwp_data.part.0.constprop.0>
    70c4:	97fff0ef 	bl	3480 <fwp_rc_fresh>
    70c8:	aa0003e1 	mov	x1, x0
    70cc:	9117e3e0 	add	x0, sp, #0x5f8
    70d0:	f902fff7 	str	x23, [sp, #1528]
    70d4:	f90303e1 	str	x1, [sp, #1536]
    70d8:	97fff19e 	bl	3750 <fwp_data.part.0.constprop.0>
    70dc:	aa0003f5 	mov	x21, x0
    70e0:	91158283 	add	x3, x20, #0x560
    70e4:	f949d861 	ldr	x1, [x3, #5040]
    70e8:	f949ec60 	ldr	x0, [x3, #5080]
    70ec:	cb0102a1 	sub	x1, x21, x1
    70f0:	eb00403f 	cmp	x1, x0, lsl #16
    70f4:	54000322 	b.cs	7158 <f0+0x1498>  // b.hs, b.nlast
    70f8:	d350fc22 	lsr	x2, x1, #16
    70fc:	f949fc63 	ldr	x3, [x3, #5112]
    7100:	8b020842 	add	x2, x2, x2, lsl #2
    7104:	d37df042 	lsl	x2, x2, #3
    7108:	8b020060 	add	x0, x3, x2
    710c:	f9401017 	ldr	x23, [x0, #32]
    7110:	b4000257 	cbz	x23, 7158 <f0+0x1498>
    7114:	38626862 	ldrb	w2, [x3, x2]
    7118:	7100085f 	cmp	w2, #0x2
    711c:	54006440 	b.eq	7da4 <f0+0x20e4>  // b.none
    7120:	7100045f 	cmp	w2, #0x1
    7124:	540001a1 	b.ne	7158 <f0+0x1498>  // b.any
    7128:	29430002 	ldp	w2, w0, [x0, #24]
    712c:	92403c21 	and	x1, x1, #0xffff
    7130:	9b027c21 	mul	x1, x1, x2
    7134:	d360fc21 	lsr	x1, x1, #32
    7138:	eb00003f 	cmp	x1, x0
    713c:	540000e2 	b.cs	7158 <f0+0x1498>  // b.hs, b.nlast
    7140:	8b0102f7 	add	x23, x23, x1
    7144:	394002e0 	ldrb	w0, [x23]
    7148:	7103fc1f 	cmp	w0, #0xff
    714c:	54007940 	b.eq	8074 <f0+0x23b4>  // b.none
    7150:	52800020 	mov	w0, #0x1                   	// #1
    7154:	390002e0 	strb	w0, [x23]
    7158:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    715c:	911823e0 	add	x0, sp, #0x608
    7160:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7164:	f90307e1 	str	x1, [sp, #1544]
    7168:	f9030bf5 	str	x21, [sp, #1552]
    716c:	97fff179 	bl	3750 <fwp_data.part.0.constprop.0>
    7170:	aa0003f5 	mov	x21, x0
    7174:	91158283 	add	x3, x20, #0x560
    7178:	f949d861 	ldr	x1, [x3, #5040]
    717c:	f949ec60 	ldr	x0, [x3, #5080]
    7180:	cb0102a1 	sub	x1, x21, x1
    7184:	eb00403f 	cmp	x1, x0, lsl #16
    7188:	54000322 	b.cs	71ec <f0+0x152c>  // b.hs, b.nlast
    718c:	d350fc22 	lsr	x2, x1, #16
    7190:	f949fc63 	ldr	x3, [x3, #5112]
    7194:	8b020842 	add	x2, x2, x2, lsl #2
    7198:	d37df042 	lsl	x2, x2, #3
    719c:	8b020060 	add	x0, x3, x2
    71a0:	f9401017 	ldr	x23, [x0, #32]
    71a4:	b4000257 	cbz	x23, 71ec <f0+0x152c>
    71a8:	38626862 	ldrb	w2, [x3, x2]
    71ac:	7100085f 	cmp	w2, #0x2
    71b0:	54005f40 	b.eq	7d98 <f0+0x20d8>  // b.none
    71b4:	7100045f 	cmp	w2, #0x1
    71b8:	540001a1 	b.ne	71ec <f0+0x152c>  // b.any
    71bc:	29430002 	ldp	w2, w0, [x0, #24]
    71c0:	92403c21 	and	x1, x1, #0xffff
    71c4:	9b027c21 	mul	x1, x1, x2
    71c8:	d360fc21 	lsr	x1, x1, #32
    71cc:	eb00003f 	cmp	x1, x0
    71d0:	540000e2 	b.cs	71ec <f0+0x152c>  // b.hs, b.nlast
    71d4:	8b0102f7 	add	x23, x23, x1
    71d8:	394002e0 	ldrb	w0, [x23]
    71dc:	7103fc1f 	cmp	w0, #0xff
    71e0:	54007500 	b.eq	8080 <f0+0x23c0>  // b.none
    71e4:	52800020 	mov	w0, #0x1                   	// #1
    71e8:	390002e0 	strb	w0, [x23]
    71ec:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    71f0:	911863e0 	add	x0, sp, #0x618
    71f4:	f9030fe1 	str	x1, [sp, #1560]
    71f8:	f90313f5 	str	x21, [sp, #1568]
    71fc:	97fff155 	bl	3750 <fwp_data.part.0.constprop.0>
    7200:	97fff0a0 	bl	3480 <fwp_rc_fresh>
    7204:	aa0003e1 	mov	x1, x0
    7208:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    720c:	9118a3e0 	add	x0, sp, #0x628
    7210:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7214:	f90317e2 	str	x2, [sp, #1576]
    7218:	f9031be1 	str	x1, [sp, #1584]
    721c:	97fff14d 	bl	3750 <fwp_data.part.0.constprop.0>
    7220:	aa0003f5 	mov	x21, x0
    7224:	91158283 	add	x3, x20, #0x560
    7228:	f949d861 	ldr	x1, [x3, #5040]
    722c:	f949ec60 	ldr	x0, [x3, #5080]
    7230:	cb0102a1 	sub	x1, x21, x1
    7234:	eb00403f 	cmp	x1, x0, lsl #16
    7238:	54000322 	b.cs	729c <f0+0x15dc>  // b.hs, b.nlast
    723c:	d350fc22 	lsr	x2, x1, #16
    7240:	f949fc63 	ldr	x3, [x3, #5112]
    7244:	8b020842 	add	x2, x2, x2, lsl #2
    7248:	d37df042 	lsl	x2, x2, #3
    724c:	8b020060 	add	x0, x3, x2
    7250:	f9401017 	ldr	x23, [x0, #32]
    7254:	b4000257 	cbz	x23, 729c <f0+0x15dc>
    7258:	38626862 	ldrb	w2, [x3, x2]
    725c:	7100085f 	cmp	w2, #0x2
    7260:	54006800 	b.eq	7f60 <f0+0x22a0>  // b.none
    7264:	7100045f 	cmp	w2, #0x1
    7268:	540001a1 	b.ne	729c <f0+0x15dc>  // b.any
    726c:	29430002 	ldp	w2, w0, [x0, #24]
    7270:	92403c21 	and	x1, x1, #0xffff
    7274:	9b027c21 	mul	x1, x1, x2
    7278:	d360fc21 	lsr	x1, x1, #32
    727c:	eb00003f 	cmp	x1, x0
    7280:	540000e2 	b.cs	729c <f0+0x15dc>  // b.hs, b.nlast
    7284:	8b0102f7 	add	x23, x23, x1
    7288:	394002e0 	ldrb	w0, [x23]
    728c:	7103fc1f 	cmp	w0, #0xff
    7290:	54006fe0 	b.eq	808c <f0+0x23cc>  // b.none
    7294:	52800020 	mov	w0, #0x1                   	// #1
    7298:	390002e0 	strb	w0, [x23]
    729c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    72a0:	9118e3e0 	add	x0, sp, #0x638
    72a4:	f9031ff7 	str	x23, [sp, #1592]
    72a8:	f90323f5 	str	x21, [sp, #1600]
    72ac:	97fff129 	bl	3750 <fwp_data.part.0.constprop.0>
    72b0:	97fff074 	bl	3480 <fwp_rc_fresh>
    72b4:	aa0003e1 	mov	x1, x0
    72b8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    72bc:	911923e0 	add	x0, sp, #0x648
    72c0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    72c4:	f90327f5 	str	x21, [sp, #1608]
    72c8:	f9032be1 	str	x1, [sp, #1616]
    72cc:	97fff121 	bl	3750 <fwp_data.part.0.constprop.0>
    72d0:	97fff06c 	bl	3480 <fwp_rc_fresh>
    72d4:	aa0003e1 	mov	x1, x0
    72d8:	911963e0 	add	x0, sp, #0x658
    72dc:	f9032ff7 	str	x23, [sp, #1624]
    72e0:	f90333e1 	str	x1, [sp, #1632]
    72e4:	97fff11b 	bl	3750 <fwp_data.part.0.constprop.0>
    72e8:	97fff066 	bl	3480 <fwp_rc_fresh>
    72ec:	aa0003e1 	mov	x1, x0
    72f0:	9119a3e0 	add	x0, sp, #0x668
    72f4:	f90337f5 	str	x21, [sp, #1640]
    72f8:	f9033be1 	str	x1, [sp, #1648]
    72fc:	97fff115 	bl	3750 <fwp_data.part.0.constprop.0>
    7300:	97fff060 	bl	3480 <fwp_rc_fresh>
    7304:	aa0003e1 	mov	x1, x0
    7308:	9119e3e0 	add	x0, sp, #0x678
    730c:	f9033ff7 	str	x23, [sp, #1656]
    7310:	f90343e1 	str	x1, [sp, #1664]
    7314:	97fff10f 	bl	3750 <fwp_data.part.0.constprop.0>
    7318:	aa0003f5 	mov	x21, x0
    731c:	91158283 	add	x3, x20, #0x560
    7320:	f949d861 	ldr	x1, [x3, #5040]
    7324:	f949ec60 	ldr	x0, [x3, #5080]
    7328:	cb0102a1 	sub	x1, x21, x1
    732c:	eb00403f 	cmp	x1, x0, lsl #16
    7330:	54000322 	b.cs	7394 <f0+0x16d4>  // b.hs, b.nlast
    7334:	d350fc22 	lsr	x2, x1, #16
    7338:	f949fc63 	ldr	x3, [x3, #5112]
    733c:	8b020842 	add	x2, x2, x2, lsl #2
    7340:	d37df042 	lsl	x2, x2, #3
    7344:	8b020060 	add	x0, x3, x2
    7348:	f9401017 	ldr	x23, [x0, #32]
    734c:	b4000257 	cbz	x23, 7394 <f0+0x16d4>
    7350:	38626862 	ldrb	w2, [x3, x2]
    7354:	7100085f 	cmp	w2, #0x2
    7358:	54005fe0 	b.eq	7f54 <f0+0x2294>  // b.none
    735c:	7100045f 	cmp	w2, #0x1
    7360:	540001a1 	b.ne	7394 <f0+0x16d4>  // b.any
    7364:	29430002 	ldp	w2, w0, [x0, #24]
    7368:	92403c21 	and	x1, x1, #0xffff
    736c:	9b027c21 	mul	x1, x1, x2
    7370:	d360fc21 	lsr	x1, x1, #32
    7374:	eb00003f 	cmp	x1, x0
    7378:	540000e2 	b.cs	7394 <f0+0x16d4>  // b.hs, b.nlast
    737c:	8b0102f7 	add	x23, x23, x1
    7380:	394002e0 	ldrb	w0, [x23]
    7384:	7103fc1f 	cmp	w0, #0xff
    7388:	54006880 	b.eq	8098 <f0+0x23d8>  // b.none
    738c:	52800020 	mov	w0, #0x1                   	// #1
    7390:	390002e0 	strb	w0, [x23]
    7394:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    7398:	911a23e0 	add	x0, sp, #0x688
    739c:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    73a0:	f90347e1 	str	x1, [sp, #1672]
    73a4:	f9034bf5 	str	x21, [sp, #1680]
    73a8:	97fff0ea 	bl	3750 <fwp_data.part.0.constprop.0>
    73ac:	aa0003f5 	mov	x21, x0
    73b0:	91158283 	add	x3, x20, #0x560
    73b4:	f949d861 	ldr	x1, [x3, #5040]
    73b8:	f949ec60 	ldr	x0, [x3, #5080]
    73bc:	cb0102a1 	sub	x1, x21, x1
    73c0:	eb00403f 	cmp	x1, x0, lsl #16
    73c4:	54000322 	b.cs	7428 <f0+0x1768>  // b.hs, b.nlast
    73c8:	d350fc22 	lsr	x2, x1, #16
    73cc:	f949fc63 	ldr	x3, [x3, #5112]
    73d0:	8b020842 	add	x2, x2, x2, lsl #2
    73d4:	d37df042 	lsl	x2, x2, #3
    73d8:	8b020060 	add	x0, x3, x2
    73dc:	f9401017 	ldr	x23, [x0, #32]
    73e0:	b4000257 	cbz	x23, 7428 <f0+0x1768>
    73e4:	38626862 	ldrb	w2, [x3, x2]
    73e8:	7100085f 	cmp	w2, #0x2
    73ec:	54005ae0 	b.eq	7f48 <f0+0x2288>  // b.none
    73f0:	7100045f 	cmp	w2, #0x1
    73f4:	540001a1 	b.ne	7428 <f0+0x1768>  // b.any
    73f8:	29430002 	ldp	w2, w0, [x0, #24]
    73fc:	92403c21 	and	x1, x1, #0xffff
    7400:	9b027c21 	mul	x1, x1, x2
    7404:	d360fc21 	lsr	x1, x1, #32
    7408:	eb00003f 	cmp	x1, x0
    740c:	540000e2 	b.cs	7428 <f0+0x1768>  // b.hs, b.nlast
    7410:	8b0102f7 	add	x23, x23, x1
    7414:	394002e0 	ldrb	w0, [x23]
    7418:	7103fc1f 	cmp	w0, #0xff
    741c:	54006440 	b.eq	80a4 <f0+0x23e4>  // b.none
    7420:	52800020 	mov	w0, #0x1                   	// #1
    7424:	390002e0 	strb	w0, [x23]
    7428:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    742c:	911a63e0 	add	x0, sp, #0x698
    7430:	f9034ff7 	str	x23, [sp, #1688]
    7434:	f90353f5 	str	x21, [sp, #1696]
    7438:	97fff0c6 	bl	3750 <fwp_data.part.0.constprop.0>
    743c:	97fff011 	bl	3480 <fwp_rc_fresh>
    7440:	aa0003e1 	mov	x1, x0
    7444:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    7448:	911aa3e0 	add	x0, sp, #0x6a8
    744c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    7450:	f90357f5 	str	x21, [sp, #1704]
    7454:	f9035be1 	str	x1, [sp, #1712]
    7458:	97fff0be 	bl	3750 <fwp_data.part.0.constprop.0>
    745c:	97fff009 	bl	3480 <fwp_rc_fresh>
    7460:	aa0003e1 	mov	x1, x0
    7464:	911ae3e0 	add	x0, sp, #0x6b8
    7468:	f9035ff7 	str	x23, [sp, #1720]
    746c:	f90363e1 	str	x1, [sp, #1728]
    7470:	97fff0b8 	bl	3750 <fwp_data.part.0.constprop.0>
    7474:	97fff003 	bl	3480 <fwp_rc_fresh>
    7478:	aa0003e1 	mov	x1, x0
    747c:	911b23e0 	add	x0, sp, #0x6c8
    7480:	f90367f5 	str	x21, [sp, #1736]
    7484:	f9036be1 	str	x1, [sp, #1744]
    7488:	97fff0b2 	bl	3750 <fwp_data.part.0.constprop.0>
    748c:	aa0003f5 	mov	x21, x0
    7490:	91158283 	add	x3, x20, #0x560
    7494:	f949d861 	ldr	x1, [x3, #5040]
    7498:	f949ec60 	ldr	x0, [x3, #5080]
    749c:	cb0102a1 	sub	x1, x21, x1
    74a0:	eb00403f 	cmp	x1, x0, lsl #16
    74a4:	54000322 	b.cs	7508 <f0+0x1848>  // b.hs, b.nlast
    74a8:	d350fc22 	lsr	x2, x1, #16
    74ac:	f949fc63 	ldr	x3, [x3, #5112]
    74b0:	8b020842 	add	x2, x2, x2, lsl #2
    74b4:	d37df042 	lsl	x2, x2, #3
    74b8:	8b020060 	add	x0, x3, x2
    74bc:	f9401017 	ldr	x23, [x0, #32]
    74c0:	b4000257 	cbz	x23, 7508 <f0+0x1848>
    74c4:	38626862 	ldrb	w2, [x3, x2]
    74c8:	7100085f 	cmp	w2, #0x2
    74cc:	54005380 	b.eq	7f3c <f0+0x227c>  // b.none
    74d0:	7100045f 	cmp	w2, #0x1
    74d4:	540001a1 	b.ne	7508 <f0+0x1848>  // b.any
    74d8:	29430002 	ldp	w2, w0, [x0, #24]
    74dc:	92403c21 	and	x1, x1, #0xffff
    74e0:	9b027c21 	mul	x1, x1, x2
    74e4:	d360fc21 	lsr	x1, x1, #32
    74e8:	eb00003f 	cmp	x1, x0
    74ec:	540000e2 	b.cs	7508 <f0+0x1848>  // b.hs, b.nlast
    74f0:	8b0102f7 	add	x23, x23, x1
    74f4:	394002e0 	ldrb	w0, [x23]
    74f8:	7103fc1f 	cmp	w0, #0xff
    74fc:	54005da0 	b.eq	80b0 <f0+0x23f0>  // b.none
    7500:	52800020 	mov	w0, #0x1                   	// #1
    7504:	390002e0 	strb	w0, [x23]
    7508:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    750c:	911b63e0 	add	x0, sp, #0x6d8
    7510:	f9036fe1 	str	x1, [sp, #1752]
    7514:	f90373f5 	str	x21, [sp, #1760]
    7518:	97fff08e 	bl	3750 <fwp_data.part.0.constprop.0>
    751c:	91158283 	add	x3, x20, #0x560
    7520:	aa0003f5 	mov	x21, x0
    7524:	f949d861 	ldr	x1, [x3, #5040]
    7528:	f949ec60 	ldr	x0, [x3, #5080]
    752c:	cb0102a1 	sub	x1, x21, x1
    7530:	eb00403f 	cmp	x1, x0, lsl #16
    7534:	54000322 	b.cs	7598 <f0+0x18d8>  // b.hs, b.nlast
    7538:	d350fc22 	lsr	x2, x1, #16
    753c:	f949fc63 	ldr	x3, [x3, #5112]
    7540:	8b020842 	add	x2, x2, x2, lsl #2
    7544:	d37df042 	lsl	x2, x2, #3
    7548:	8b020060 	add	x0, x3, x2
    754c:	f9401017 	ldr	x23, [x0, #32]
    7550:	b4000257 	cbz	x23, 7598 <f0+0x18d8>
    7554:	38626862 	ldrb	w2, [x3, x2]
    7558:	7100085f 	cmp	w2, #0x2
    755c:	54004ea0 	b.eq	7f30 <f0+0x2270>  // b.none
    7560:	7100045f 	cmp	w2, #0x1
    7564:	540001a1 	b.ne	7598 <f0+0x18d8>  // b.any
    7568:	29430002 	ldp	w2, w0, [x0, #24]
    756c:	92403c21 	and	x1, x1, #0xffff
    7570:	9b027c21 	mul	x1, x1, x2
    7574:	d360fc21 	lsr	x1, x1, #32
    7578:	eb00003f 	cmp	x1, x0
    757c:	540000e2 	b.cs	7598 <f0+0x18d8>  // b.hs, b.nlast
    7580:	8b0102f7 	add	x23, x23, x1
    7584:	394002e0 	ldrb	w0, [x23]
    7588:	7103fc1f 	cmp	w0, #0xff
    758c:	54005980 	b.eq	80bc <f0+0x23fc>  // b.none
    7590:	52800020 	mov	w0, #0x1                   	// #1
    7594:	390002e0 	strb	w0, [x23]
    7598:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    759c:	911ba3e0 	add	x0, sp, #0x6e8
    75a0:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    75a4:	f90377e1 	str	x1, [sp, #1768]
    75a8:	f9037bf5 	str	x21, [sp, #1776]
    75ac:	97fff069 	bl	3750 <fwp_data.part.0.constprop.0>
    75b0:	aa0003f5 	mov	x21, x0
    75b4:	91158283 	add	x3, x20, #0x560
    75b8:	f949d861 	ldr	x1, [x3, #5040]
    75bc:	f949ec60 	ldr	x0, [x3, #5080]
    75c0:	cb0102a1 	sub	x1, x21, x1
    75c4:	eb00403f 	cmp	x1, x0, lsl #16
    75c8:	54000322 	b.cs	762c <f0+0x196c>  // b.hs, b.nlast
    75cc:	d350fc22 	lsr	x2, x1, #16
    75d0:	f949fc63 	ldr	x3, [x3, #5112]
    75d4:	8b020842 	add	x2, x2, x2, lsl #2
    75d8:	d37df042 	lsl	x2, x2, #3
    75dc:	8b020060 	add	x0, x3, x2
    75e0:	f9401017 	ldr	x23, [x0, #32]
    75e4:	b4000257 	cbz	x23, 762c <f0+0x196c>
    75e8:	38626862 	ldrb	w2, [x3, x2]
    75ec:	7100085f 	cmp	w2, #0x2
    75f0:	540049a0 	b.eq	7f24 <f0+0x2264>  // b.none
    75f4:	7100045f 	cmp	w2, #0x1
    75f8:	540001a1 	b.ne	762c <f0+0x196c>  // b.any
    75fc:	29430002 	ldp	w2, w0, [x0, #24]
    7600:	92403c21 	and	x1, x1, #0xffff
    7604:	9b027c21 	mul	x1, x1, x2
    7608:	d360fc21 	lsr	x1, x1, #32
    760c:	eb00003f 	cmp	x1, x0
    7610:	540000e2 	b.cs	762c <f0+0x196c>  // b.hs, b.nlast
    7614:	8b0102f7 	add	x23, x23, x1
    7618:	394002e0 	ldrb	w0, [x23]
    761c:	7103fc1f 	cmp	w0, #0xff
    7620:	54005540 	b.eq	80c8 <f0+0x2408>  // b.none
    7624:	52800020 	mov	w0, #0x1                   	// #1
    7628:	390002e0 	strb	w0, [x23]
    762c:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    7630:	911be3e0 	add	x0, sp, #0x6f8
    7634:	f9037fe1 	str	x1, [sp, #1784]
    7638:	f90383f5 	str	x21, [sp, #1792]
    763c:	97fff045 	bl	3750 <fwp_data.part.0.constprop.0>
    7640:	91158283 	add	x3, x20, #0x560
    7644:	aa0003f5 	mov	x21, x0
    7648:	f949d861 	ldr	x1, [x3, #5040]
    764c:	f949ec60 	ldr	x0, [x3, #5080]
    7650:	cb0102a1 	sub	x1, x21, x1
    7654:	eb00403f 	cmp	x1, x0, lsl #16
    7658:	54000322 	b.cs	76bc <f0+0x19fc>  // b.hs, b.nlast
    765c:	d350fc22 	lsr	x2, x1, #16
    7660:	f949fc63 	ldr	x3, [x3, #5112]
    7664:	8b020842 	add	x2, x2, x2, lsl #2
    7668:	d37df042 	lsl	x2, x2, #3
    766c:	8b020060 	add	x0, x3, x2
    7670:	f9401017 	ldr	x23, [x0, #32]
    7674:	b4000257 	cbz	x23, 76bc <f0+0x19fc>
    7678:	38626862 	ldrb	w2, [x3, x2]
    767c:	7100085f 	cmp	w2, #0x2
    7680:	540044c0 	b.eq	7f18 <f0+0x2258>  // b.none
    7684:	7100045f 	cmp	w2, #0x1
    7688:	540001a1 	b.ne	76bc <f0+0x19fc>  // b.any
    768c:	29430002 	ldp	w2, w0, [x0, #24]
    7690:	92403c21 	and	x1, x1, #0xffff
    7694:	9b027c21 	mul	x1, x1, x2
    7698:	d360fc21 	lsr	x1, x1, #32
    769c:	eb00003f 	cmp	x1, x0
    76a0:	540000e2 	b.cs	76bc <f0+0x19fc>  // b.hs, b.nlast
    76a4:	8b0102f7 	add	x23, x23, x1
    76a8:	394002e0 	ldrb	w0, [x23]
    76ac:	7103fc1f 	cmp	w0, #0xff
    76b0:	54005120 	b.eq	80d4 <f0+0x2414>  // b.none
    76b4:	52800020 	mov	w0, #0x1                   	// #1
    76b8:	390002e0 	strb	w0, [x23]
    76bc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    76c0:	911c23e0 	add	x0, sp, #0x708
    76c4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    76c8:	f90387f7 	str	x23, [sp, #1800]
    76cc:	f9038bf5 	str	x21, [sp, #1808]
    76d0:	97fff020 	bl	3750 <fwp_data.part.0.constprop.0>
    76d4:	97ffef6b 	bl	3480 <fwp_rc_fresh>
    76d8:	aa0003e1 	mov	x1, x0
    76dc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    76e0:	911c63e0 	add	x0, sp, #0x718
    76e4:	f9038ff5 	str	x21, [sp, #1816]
    76e8:	f90393e1 	str	x1, [sp, #1824]
    76ec:	97fff019 	bl	3750 <fwp_data.part.0.constprop.0>
    76f0:	97ffef64 	bl	3480 <fwp_rc_fresh>
    76f4:	aa0003e1 	mov	x1, x0
    76f8:	911ca3e0 	add	x0, sp, #0x728
    76fc:	f90397f7 	str	x23, [sp, #1832]
    7700:	f9039be1 	str	x1, [sp, #1840]
    7704:	97fff013 	bl	3750 <fwp_data.part.0.constprop.0>
    7708:	97ffef5e 	bl	3480 <fwp_rc_fresh>
    770c:	aa0003e1 	mov	x1, x0
    7710:	911ce3e0 	add	x0, sp, #0x738
    7714:	f9039ff5 	str	x21, [sp, #1848]
    7718:	f903a3e1 	str	x1, [sp, #1856]
    771c:	97fff00d 	bl	3750 <fwp_data.part.0.constprop.0>
    7720:	97ffef58 	bl	3480 <fwp_rc_fresh>
    7724:	aa0003e1 	mov	x1, x0
    7728:	911d23e0 	add	x0, sp, #0x748
    772c:	f903a7f7 	str	x23, [sp, #1864]
    7730:	f903abe1 	str	x1, [sp, #1872]
    7734:	97fff007 	bl	3750 <fwp_data.part.0.constprop.0>
    7738:	aa0003f5 	mov	x21, x0
    773c:	91158283 	add	x3, x20, #0x560
    7740:	f949d861 	ldr	x1, [x3, #5040]
    7744:	f949ec60 	ldr	x0, [x3, #5080]
    7748:	cb0102a1 	sub	x1, x21, x1
    774c:	eb00403f 	cmp	x1, x0, lsl #16
    7750:	54000322 	b.cs	77b4 <f0+0x1af4>  // b.hs, b.nlast
    7754:	d350fc22 	lsr	x2, x1, #16
    7758:	f949fc63 	ldr	x3, [x3, #5112]
    775c:	8b020842 	add	x2, x2, x2, lsl #2
    7760:	d37df042 	lsl	x2, x2, #3
    7764:	8b020060 	add	x0, x3, x2
    7768:	f9401017 	ldr	x23, [x0, #32]
    776c:	b4000257 	cbz	x23, 77b4 <f0+0x1af4>
    7770:	38626862 	ldrb	w2, [x3, x2]
    7774:	7100085f 	cmp	w2, #0x2
    7778:	54003ca0 	b.eq	7f0c <f0+0x224c>  // b.none
    777c:	7100045f 	cmp	w2, #0x1
    7780:	540001a1 	b.ne	77b4 <f0+0x1af4>  // b.any
    7784:	29430002 	ldp	w2, w0, [x0, #24]
    7788:	92403c21 	and	x1, x1, #0xffff
    778c:	9b027c21 	mul	x1, x1, x2
    7790:	d360fc21 	lsr	x1, x1, #32
    7794:	eb00003f 	cmp	x1, x0
    7798:	540000e2 	b.cs	77b4 <f0+0x1af4>  // b.hs, b.nlast
    779c:	8b0102f7 	add	x23, x23, x1
    77a0:	394002e0 	ldrb	w0, [x23]
    77a4:	7103fc1f 	cmp	w0, #0xff
    77a8:	540049c0 	b.eq	80e0 <f0+0x2420>  // b.none
    77ac:	52800020 	mov	w0, #0x1                   	// #1
    77b0:	390002e0 	strb	w0, [x23]
    77b4:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    77b8:	911d63e0 	add	x0, sp, #0x758
    77bc:	f903afe1 	str	x1, [sp, #1880]
    77c0:	f903b3f5 	str	x21, [sp, #1888]
    77c4:	97ffefe3 	bl	3750 <fwp_data.part.0.constprop.0>
    77c8:	97ffef2e 	bl	3480 <fwp_rc_fresh>
    77cc:	aa0003e1 	mov	x1, x0
    77d0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    77d4:	911da3e0 	add	x0, sp, #0x768
    77d8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    77dc:	f903b7e2 	str	x2, [sp, #1896]
    77e0:	f903bbe1 	str	x1, [sp, #1904]
    77e4:	97ffefdb 	bl	3750 <fwp_data.part.0.constprop.0>
    77e8:	aa0003f5 	mov	x21, x0
    77ec:	91158283 	add	x3, x20, #0x560
    77f0:	f949d861 	ldr	x1, [x3, #5040]
    77f4:	f949ec60 	ldr	x0, [x3, #5080]
    77f8:	cb0102a1 	sub	x1, x21, x1
    77fc:	eb00403f 	cmp	x1, x0, lsl #16
    7800:	54000322 	b.cs	7864 <f0+0x1ba4>  // b.hs, b.nlast
    7804:	d350fc22 	lsr	x2, x1, #16
    7808:	f949fc63 	ldr	x3, [x3, #5112]
    780c:	8b020842 	add	x2, x2, x2, lsl #2
    7810:	d37df042 	lsl	x2, x2, #3
    7814:	8b020060 	add	x0, x3, x2
    7818:	f9401017 	ldr	x23, [x0, #32]
    781c:	b4000257 	cbz	x23, 7864 <f0+0x1ba4>
    7820:	38626862 	ldrb	w2, [x3, x2]
    7824:	7100085f 	cmp	w2, #0x2
    7828:	540036c0 	b.eq	7f00 <f0+0x2240>  // b.none
    782c:	7100045f 	cmp	w2, #0x1
    7830:	540001a1 	b.ne	7864 <f0+0x1ba4>  // b.any
    7834:	29430002 	ldp	w2, w0, [x0, #24]
    7838:	92403c21 	and	x1, x1, #0xffff
    783c:	9b027c21 	mul	x1, x1, x2
    7840:	d360fc21 	lsr	x1, x1, #32
    7844:	eb00003f 	cmp	x1, x0
    7848:	540000e2 	b.cs	7864 <f0+0x1ba4>  // b.hs, b.nlast
    784c:	8b0102f7 	add	x23, x23, x1
    7850:	394002e0 	ldrb	w0, [x23]
    7854:	7103fc1f 	cmp	w0, #0xff
    7858:	540044a0 	b.eq	80ec <f0+0x242c>  // b.none
    785c:	52800020 	mov	w0, #0x1                   	// #1
    7860:	390002e0 	strb	w0, [x23]
    7864:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    7868:	911de3e0 	add	x0, sp, #0x778
    786c:	f903bfe1 	str	x1, [sp, #1912]
    7870:	f903c3f5 	str	x21, [sp, #1920]
    7874:	97ffefb7 	bl	3750 <fwp_data.part.0.constprop.0>
    7878:	91158283 	add	x3, x20, #0x560
    787c:	aa0003f5 	mov	x21, x0
    7880:	f949d861 	ldr	x1, [x3, #5040]
    7884:	f949ec60 	ldr	x0, [x3, #5080]
    7888:	cb0102a1 	sub	x1, x21, x1
    788c:	eb00403f 	cmp	x1, x0, lsl #16
    7890:	54000322 	b.cs	78f4 <f0+0x1c34>  // b.hs, b.nlast
    7894:	d350fc22 	lsr	x2, x1, #16
    7898:	f949fc63 	ldr	x3, [x3, #5112]
    789c:	8b020842 	add	x2, x2, x2, lsl #2
    78a0:	d37df042 	lsl	x2, x2, #3
    78a4:	8b020060 	add	x0, x3, x2
    78a8:	f9401017 	ldr	x23, [x0, #32]
    78ac:	b4000257 	cbz	x23, 78f4 <f0+0x1c34>
    78b0:	38626862 	ldrb	w2, [x3, x2]
    78b4:	7100085f 	cmp	w2, #0x2
    78b8:	540031e0 	b.eq	7ef4 <f0+0x2234>  // b.none
    78bc:	7100045f 	cmp	w2, #0x1
    78c0:	540001a1 	b.ne	78f4 <f0+0x1c34>  // b.any
    78c4:	29430002 	ldp	w2, w0, [x0, #24]
    78c8:	92403c21 	and	x1, x1, #0xffff
    78cc:	9b027c21 	mul	x1, x1, x2
    78d0:	d360fc21 	lsr	x1, x1, #32
    78d4:	eb00003f 	cmp	x1, x0
    78d8:	540000e2 	b.cs	78f4 <f0+0x1c34>  // b.hs, b.nlast
    78dc:	8b0102f7 	add	x23, x23, x1
    78e0:	394002e0 	ldrb	w0, [x23]
    78e4:	7103fc1f 	cmp	w0, #0xff
    78e8:	54004080 	b.eq	80f8 <f0+0x2438>  // b.none
    78ec:	52800020 	mov	w0, #0x1                   	// #1
    78f0:	390002e0 	strb	w0, [x23]
    78f4:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    78f8:	911e23e0 	add	x0, sp, #0x788
    78fc:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7900:	f903c7e1 	str	x1, [sp, #1928]
    7904:	f903cbf5 	str	x21, [sp, #1936]
    7908:	97ffef92 	bl	3750 <fwp_data.part.0.constprop.0>
    790c:	aa0003f5 	mov	x21, x0
    7910:	91158283 	add	x3, x20, #0x560
    7914:	f949d861 	ldr	x1, [x3, #5040]
    7918:	f949ec60 	ldr	x0, [x3, #5080]
    791c:	cb0102a1 	sub	x1, x21, x1
    7920:	eb00403f 	cmp	x1, x0, lsl #16
    7924:	54000322 	b.cs	7988 <f0+0x1cc8>  // b.hs, b.nlast
    7928:	d350fc22 	lsr	x2, x1, #16
    792c:	f949fc63 	ldr	x3, [x3, #5112]
    7930:	8b020842 	add	x2, x2, x2, lsl #2
    7934:	d37df042 	lsl	x2, x2, #3
    7938:	8b020060 	add	x0, x3, x2
    793c:	f9401017 	ldr	x23, [x0, #32]
    7940:	b4000257 	cbz	x23, 7988 <f0+0x1cc8>
    7944:	38626862 	ldrb	w2, [x3, x2]
    7948:	7100085f 	cmp	w2, #0x2
    794c:	54002ce0 	b.eq	7ee8 <f0+0x2228>  // b.none
    7950:	7100045f 	cmp	w2, #0x1
    7954:	540001a1 	b.ne	7988 <f0+0x1cc8>  // b.any
    7958:	29430002 	ldp	w2, w0, [x0, #24]
    795c:	92403c21 	and	x1, x1, #0xffff
    7960:	9b027c21 	mul	x1, x1, x2
    7964:	d360fc21 	lsr	x1, x1, #32
    7968:	eb00003f 	cmp	x1, x0
    796c:	540000e2 	b.cs	7988 <f0+0x1cc8>  // b.hs, b.nlast
    7970:	8b0102f7 	add	x23, x23, x1
    7974:	394002e0 	ldrb	w0, [x23]
    7978:	7103fc1f 	cmp	w0, #0xff
    797c:	54003c40 	b.eq	8104 <f0+0x2444>  // b.none
    7980:	52800020 	mov	w0, #0x1                   	// #1
    7984:	390002e0 	strb	w0, [x23]
    7988:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    798c:	911e63e0 	add	x0, sp, #0x798
    7990:	f903cfe1 	str	x1, [sp, #1944]
    7994:	f903d3f5 	str	x21, [sp, #1952]
    7998:	97ffef6e 	bl	3750 <fwp_data.part.0.constprop.0>
    799c:	97ffeeb9 	bl	3480 <fwp_rc_fresh>
    79a0:	aa0003e1 	mov	x1, x0
    79a4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    79a8:	911ea3e0 	add	x0, sp, #0x7a8
    79ac:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    79b0:	f903d7e2 	str	x2, [sp, #1960]
    79b4:	f903dbe1 	str	x1, [sp, #1968]
    79b8:	97ffef66 	bl	3750 <fwp_data.part.0.constprop.0>
    79bc:	aa0003f5 	mov	x21, x0
    79c0:	91158283 	add	x3, x20, #0x560
    79c4:	f949d861 	ldr	x1, [x3, #5040]
    79c8:	f949ec60 	ldr	x0, [x3, #5080]
    79cc:	cb0102a1 	sub	x1, x21, x1
    79d0:	eb00403f 	cmp	x1, x0, lsl #16
    79d4:	54000322 	b.cs	7a38 <f0+0x1d78>  // b.hs, b.nlast
    79d8:	d350fc22 	lsr	x2, x1, #16
    79dc:	f949fc63 	ldr	x3, [x3, #5112]
    79e0:	8b020842 	add	x2, x2, x2, lsl #2
    79e4:	d37df042 	lsl	x2, x2, #3
    79e8:	8b020060 	add	x0, x3, x2
    79ec:	f9401017 	ldr	x23, [x0, #32]
    79f0:	b4000257 	cbz	x23, 7a38 <f0+0x1d78>
    79f4:	38626862 	ldrb	w2, [x3, x2]
    79f8:	7100085f 	cmp	w2, #0x2
    79fc:	54002700 	b.eq	7edc <f0+0x221c>  // b.none
    7a00:	7100045f 	cmp	w2, #0x1
    7a04:	540001a1 	b.ne	7a38 <f0+0x1d78>  // b.any
    7a08:	29430002 	ldp	w2, w0, [x0, #24]
    7a0c:	92403c21 	and	x1, x1, #0xffff
    7a10:	9b027c21 	mul	x1, x1, x2
    7a14:	d360fc21 	lsr	x1, x1, #32
    7a18:	eb00003f 	cmp	x1, x0
    7a1c:	540000e2 	b.cs	7a38 <f0+0x1d78>  // b.hs, b.nlast
    7a20:	8b0102f7 	add	x23, x23, x1
    7a24:	394002e0 	ldrb	w0, [x23]
    7a28:	7103fc1f 	cmp	w0, #0xff
    7a2c:	54003720 	b.eq	8110 <f0+0x2450>  // b.none
    7a30:	52800020 	mov	w0, #0x1                   	// #1
    7a34:	390002e0 	strb	w0, [x23]
    7a38:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7a3c:	911ee3e0 	add	x0, sp, #0x7b8
    7a40:	f903dff7 	str	x23, [sp, #1976]
    7a44:	f903e3f5 	str	x21, [sp, #1984]
    7a48:	97ffef42 	bl	3750 <fwp_data.part.0.constprop.0>
    7a4c:	97ffee8d 	bl	3480 <fwp_rc_fresh>
    7a50:	aa0003e1 	mov	x1, x0
    7a54:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7a58:	911f23e0 	add	x0, sp, #0x7c8
    7a5c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7a60:	f903e7e2 	str	x2, [sp, #1992]
    7a64:	f903ebe1 	str	x1, [sp, #2000]
    7a68:	97ffef3a 	bl	3750 <fwp_data.part.0.constprop.0>
    7a6c:	97ffee85 	bl	3480 <fwp_rc_fresh>
    7a70:	aa0003e1 	mov	x1, x0
    7a74:	911f63e0 	add	x0, sp, #0x7d8
    7a78:	f903eff7 	str	x23, [sp, #2008]
    7a7c:	f903f3e1 	str	x1, [sp, #2016]
    7a80:	97ffef34 	bl	3750 <fwp_data.part.0.constprop.0>
    7a84:	aa0003f5 	mov	x21, x0
    7a88:	91158283 	add	x3, x20, #0x560
    7a8c:	f949d861 	ldr	x1, [x3, #5040]
    7a90:	f949ec60 	ldr	x0, [x3, #5080]
    7a94:	cb0102a1 	sub	x1, x21, x1
    7a98:	eb00403f 	cmp	x1, x0, lsl #16
    7a9c:	54000322 	b.cs	7b00 <f0+0x1e40>  // b.hs, b.nlast
    7aa0:	d350fc22 	lsr	x2, x1, #16
    7aa4:	f949fc63 	ldr	x3, [x3, #5112]
    7aa8:	8b020842 	add	x2, x2, x2, lsl #2
    7aac:	d37df042 	lsl	x2, x2, #3
    7ab0:	8b020060 	add	x0, x3, x2
    7ab4:	f9401017 	ldr	x23, [x0, #32]
    7ab8:	b4000257 	cbz	x23, 7b00 <f0+0x1e40>
    7abc:	38626862 	ldrb	w2, [x3, x2]
    7ac0:	7100085f 	cmp	w2, #0x2
    7ac4:	54002060 	b.eq	7ed0 <f0+0x2210>  // b.none
    7ac8:	7100045f 	cmp	w2, #0x1
    7acc:	540001a1 	b.ne	7b00 <f0+0x1e40>  // b.any
    7ad0:	29430002 	ldp	w2, w0, [x0, #24]
    7ad4:	92403c21 	and	x1, x1, #0xffff
    7ad8:	9b027c21 	mul	x1, x1, x2
    7adc:	d360fc21 	lsr	x1, x1, #32
    7ae0:	eb00003f 	cmp	x1, x0
    7ae4:	540000e2 	b.cs	7b00 <f0+0x1e40>  // b.hs, b.nlast
    7ae8:	8b0102f7 	add	x23, x23, x1
    7aec:	394002e0 	ldrb	w0, [x23]
    7af0:	7103fc1f 	cmp	w0, #0xff
    7af4:	54003140 	b.eq	811c <f0+0x245c>  // b.none
    7af8:	52800020 	mov	w0, #0x1                   	// #1
    7afc:	390002e0 	strb	w0, [x23]
    7b00:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    7b04:	911fa3e0 	add	x0, sp, #0x7e8
    7b08:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7b0c:	f903f7e1 	str	x1, [sp, #2024]
    7b10:	f903fbf5 	str	x21, [sp, #2032]
    7b14:	97ffef0f 	bl	3750 <fwp_data.part.0.constprop.0>
    7b18:	aa0003f5 	mov	x21, x0
    7b1c:	91158283 	add	x3, x20, #0x560
    7b20:	f949d861 	ldr	x1, [x3, #5040]
    7b24:	f949ec60 	ldr	x0, [x3, #5080]
    7b28:	cb0102a1 	sub	x1, x21, x1
    7b2c:	eb00403f 	cmp	x1, x0, lsl #16
    7b30:	54000322 	b.cs	7b94 <f0+0x1ed4>  // b.hs, b.nlast
    7b34:	d350fc22 	lsr	x2, x1, #16
    7b38:	f949fc63 	ldr	x3, [x3, #5112]
    7b3c:	8b020842 	add	x2, x2, x2, lsl #2
    7b40:	d37df042 	lsl	x2, x2, #3
    7b44:	8b020060 	add	x0, x3, x2
    7b48:	f9401017 	ldr	x23, [x0, #32]
    7b4c:	b4000257 	cbz	x23, 7b94 <f0+0x1ed4>
    7b50:	38626862 	ldrb	w2, [x3, x2]
    7b54:	7100085f 	cmp	w2, #0x2
    7b58:	54001b60 	b.eq	7ec4 <f0+0x2204>  // b.none
    7b5c:	7100045f 	cmp	w2, #0x1
    7b60:	540001a1 	b.ne	7b94 <f0+0x1ed4>  // b.any
    7b64:	29430002 	ldp	w2, w0, [x0, #24]
    7b68:	92403c21 	and	x1, x1, #0xffff
    7b6c:	9b027c21 	mul	x1, x1, x2
    7b70:	d360fc21 	lsr	x1, x1, #32
    7b74:	eb00003f 	cmp	x1, x0
    7b78:	540000e2 	b.cs	7b94 <f0+0x1ed4>  // b.hs, b.nlast
    7b7c:	8b0102f7 	add	x23, x23, x1
    7b80:	394002e0 	ldrb	w0, [x23]
    7b84:	7103fc1f 	cmp	w0, #0xff
    7b88:	54002d00 	b.eq	8128 <f0+0x2468>  // b.none
    7b8c:	52800020 	mov	w0, #0x1                   	// #1
    7b90:	390002e0 	strb	w0, [x23]
    7b94:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    7b98:	911fe3e0 	add	x0, sp, #0x7f8
    7b9c:	f903ffe1 	str	x1, [sp, #2040]
    7ba0:	f90403f5 	str	x21, [sp, #2048]
    7ba4:	97ffeeeb 	bl	3750 <fwp_data.part.0.constprop.0>
    7ba8:	91158283 	add	x3, x20, #0x560
    7bac:	aa0003f5 	mov	x21, x0
    7bb0:	f949d861 	ldr	x1, [x3, #5040]
    7bb4:	f949ec60 	ldr	x0, [x3, #5080]
    7bb8:	cb0102a1 	sub	x1, x21, x1
    7bbc:	eb00403f 	cmp	x1, x0, lsl #16
    7bc0:	54000322 	b.cs	7c24 <f0+0x1f64>  // b.hs, b.nlast
    7bc4:	d350fc22 	lsr	x2, x1, #16
    7bc8:	f949fc63 	ldr	x3, [x3, #5112]
    7bcc:	8b020842 	add	x2, x2, x2, lsl #2
    7bd0:	d37df042 	lsl	x2, x2, #3
    7bd4:	8b020060 	add	x0, x3, x2
    7bd8:	f9401017 	ldr	x23, [x0, #32]
    7bdc:	b4000257 	cbz	x23, 7c24 <f0+0x1f64>
    7be0:	38626862 	ldrb	w2, [x3, x2]
    7be4:	7100085f 	cmp	w2, #0x2
    7be8:	54001680 	b.eq	7eb8 <f0+0x21f8>  // b.none
    7bec:	7100045f 	cmp	w2, #0x1
    7bf0:	540001a1 	b.ne	7c24 <f0+0x1f64>  // b.any
    7bf4:	29430002 	ldp	w2, w0, [x0, #24]
    7bf8:	92403c21 	and	x1, x1, #0xffff
    7bfc:	9b027c21 	mul	x1, x1, x2
    7c00:	d360fc21 	lsr	x1, x1, #32
    7c04:	eb00003f 	cmp	x1, x0
    7c08:	540000e2 	b.cs	7c24 <f0+0x1f64>  // b.hs, b.nlast
    7c0c:	8b0102f7 	add	x23, x23, x1
    7c10:	394002e0 	ldrb	w0, [x23]
    7c14:	7103fc1f 	cmp	w0, #0xff
    7c18:	540028e0 	b.eq	8134 <f0+0x2474>  // b.none
    7c1c:	52800020 	mov	w0, #0x1                   	// #1
    7c20:	390002e0 	strb	w0, [x23]
    7c24:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    7c28:	91158294 	add	x20, x20, #0x560
    7c2c:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    7c30:	912023e0 	add	x0, sp, #0x808
    7c34:	f90407e1 	str	x1, [sp, #2056]
    7c38:	f9040bf5 	str	x21, [sp, #2064]
    7c3c:	97ffeec5 	bl	3750 <fwp_data.part.0.constprop.0>
    7c40:	f949da81 	ldr	x1, [x20, #5040]
    7c44:	aa0003f5 	mov	x21, x0
    7c48:	f949ee80 	ldr	x0, [x20, #5080]
    7c4c:	cb0102a1 	sub	x1, x21, x1
    7c50:	eb00403f 	cmp	x1, x0, lsl #16
    7c54:	54000322 	b.cs	7cb8 <f0+0x1ff8>  // b.hs, b.nlast
    7c58:	d350fc22 	lsr	x2, x1, #16
    7c5c:	f949fe83 	ldr	x3, [x20, #5112]
    7c60:	8b020842 	add	x2, x2, x2, lsl #2
    7c64:	d37df042 	lsl	x2, x2, #3
    7c68:	8b020060 	add	x0, x3, x2
    7c6c:	f9401014 	ldr	x20, [x0, #32]
    7c70:	b4000254 	cbz	x20, 7cb8 <f0+0x1ff8>
    7c74:	38626862 	ldrb	w2, [x3, x2]
    7c78:	7100085f 	cmp	w2, #0x2
    7c7c:	54001180 	b.eq	7eac <f0+0x21ec>  // b.none
    7c80:	7100045f 	cmp	w2, #0x1
    7c84:	540001a1 	b.ne	7cb8 <f0+0x1ff8>  // b.any
    7c88:	29430002 	ldp	w2, w0, [x0, #24]
    7c8c:	92403c21 	and	x1, x1, #0xffff
    7c90:	9b027c21 	mul	x1, x1, x2
    7c94:	d360fc21 	lsr	x1, x1, #32
    7c98:	eb00003f 	cmp	x1, x0
    7c9c:	540000e2 	b.cs	7cb8 <f0+0x1ff8>  // b.hs, b.nlast
    7ca0:	8b010294 	add	x20, x20, x1
    7ca4:	39400280 	ldrb	w0, [x20]
    7ca8:	7103fc1f 	cmp	w0, #0xff
    7cac:	54001600 	b.eq	7f6c <f0+0x22ac>  // b.none
    7cb0:	52800020 	mov	w0, #0x1                   	// #1
    7cb4:	39000280 	strb	w0, [x20]
    7cb8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7cbc:	912063e0 	add	x0, sp, #0x818
    7cc0:	f9040ff7 	str	x23, [sp, #2072]
    7cc4:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    7cc8:	f90413f5 	str	x21, [sp, #2080]
    7ccc:	97ffeea1 	bl	3750 <fwp_data.part.0.constprop.0>
    7cd0:	97ffedec 	bl	3480 <fwp_rc_fresh>
    7cd4:	aa0003e1 	mov	x1, x0
    7cd8:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    7cdc:	9120a3e0 	add	x0, sp, #0x828
    7ce0:	f90417f4 	str	x20, [sp, #2088]
    7ce4:	f9041be1 	str	x1, [sp, #2096]
    7ce8:	97ffee9a 	bl	3750 <fwp_data.part.0.constprop.0>
    7cec:	97ffede5 	bl	3480 <fwp_rc_fresh>
    7cf0:	aa0003e1 	mov	x1, x0
    7cf4:	9120e3e0 	add	x0, sp, #0x838
    7cf8:	f9041ff7 	str	x23, [sp, #2104]
    7cfc:	f90423e1 	str	x1, [sp, #2112]
    7d00:	97ffee94 	bl	3750 <fwp_data.part.0.constprop.0>
    7d04:	97ffeddf 	bl	3480 <fwp_rc_fresh>
    7d08:	aa0003e1 	mov	x1, x0
    7d0c:	aa1603e0 	mov	x0, x22
    7d10:	f90427f4 	str	x20, [sp, #2120]
    7d14:	f9042be1 	str	x1, [sp, #2128]
    7d18:	97ffee8e 	bl	3750 <fwp_data.part.0.constprop.0>
    7d1c:	97ffedd9 	bl	3480 <fwp_rc_fresh>
    7d20:	aa0003f5 	mov	x21, x0
    7d24:	aa1303e1 	mov	x1, x19
    7d28:	97fff493 	bl	4f74 <fwp_hof0.constprop.0>
    7d2c:	aa0003f4 	mov	x20, x0
    7d30:	aa1503e0 	mov	x0, x21
    7d34:	97ffef4f 	bl	3a70 <fwp_drop0>
    7d38:	aa1303e0 	mov	x0, x19
    7d3c:	97ffef4d 	bl	3a70 <fwp_drop0>
    7d40:	900000c0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    7d44:	f947f400 	ldr	x0, [x0, #4072]
    7d48:	f9442fe2 	ldr	x2, [sp, #2136]
    7d4c:	f9400001 	ldr	x1, [x0]
    7d50:	eb010042 	subs	x2, x2, x1
    7d54:	d2800001 	mov	x1, #0x0                   	// #0
    7d58:	54001f41 	b.ne	8140 <f0+0x2480>  // b.any
    7d5c:	912183ff 	add	sp, sp, #0x860
    7d60:	aa1403e0 	mov	x0, x20
    7d64:	a94153f3 	ldp	x19, x20, [sp, #16]
    7d68:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7d6c:	a94363f7 	ldp	x23, x24, [sp, #48]
    7d70:	a9446bf9 	ldp	x25, x26, [sp, #64]
    7d74:	a94573fb 	ldp	x27, x28, [sp, #80]
    7d78:	a8c67bfd 	ldp	x29, x30, [sp], #96
    7d7c:	d65f03c0 	ret
    7d80:	aa1b03e0 	mov	x0, x27
    7d84:	97ffec00 	bl	2d84 <fwp_rc_forget_slot>
    7d88:	17fff815 	b	5ddc <f0+0x11c>
    7d8c:	72003c5f 	tst	w2, #0xffff
    7d90:	54ff0281 	b.ne	5de0 <f0+0x120>  // b.any
    7d94:	17fff80f 	b	5dd0 <f0+0x110>
    7d98:	72003c3f 	tst	w1, #0xffff
    7d9c:	54ffa281 	b.ne	71ec <f0+0x152c>  // b.any
    7da0:	17fffd0e 	b	71d8 <f0+0x1518>
    7da4:	72003c3f 	tst	w1, #0xffff
    7da8:	54ff9d81 	b.ne	7158 <f0+0x1498>  // b.any
    7dac:	17fffce6 	b	7144 <f0+0x1484>
    7db0:	72003c3f 	tst	w1, #0xffff
    7db4:	54ff96e1 	b.ne	7090 <f0+0x13d0>  // b.any
    7db8:	17fffcb1 	b	707c <f0+0x13bc>
    7dbc:	72003c3f 	tst	w1, #0xffff
    7dc0:	54ff9101 	b.ne	6fe0 <f0+0x1320>  // b.any
    7dc4:	17fffc82 	b	6fcc <f0+0x130c>
    7dc8:	72003c3f 	tst	w1, #0xffff
    7dcc:	54ff8b21 	b.ne	6f30 <f0+0x1270>  // b.any
    7dd0:	17fffc53 	b	6f1c <f0+0x125c>
    7dd4:	72003c3f 	tst	w1, #0xffff
    7dd8:	54ff83c1 	b.ne	6e50 <f0+0x1190>  // b.any
    7ddc:	17fffc18 	b	6e3c <f0+0x117c>
    7de0:	72003c3f 	tst	w1, #0xffff
    7de4:	54ff7de1 	b.ne	6da0 <f0+0x10e0>  // b.any
    7de8:	17fffbe9 	b	6d8c <f0+0x10cc>
    7dec:	72003c3f 	tst	w1, #0xffff
    7df0:	54ff7801 	b.ne	6cf0 <f0+0x1030>  // b.any
    7df4:	17fffbba 	b	6cdc <f0+0x101c>
    7df8:	72003c3f 	tst	w1, #0xffff
    7dfc:	54ff2081 	b.ne	620c <f0+0x54c>  // b.any
    7e00:	17fff8fe 	b	61f8 <f0+0x538>
    7e04:	72003c3f 	tst	w1, #0xffff
    7e08:	54ff13c1 	b.ne	6080 <f0+0x3c0>  // b.any
    7e0c:	17fff898 	b	606c <f0+0x3ac>
    7e10:	72003c3f 	tst	w1, #0xffff
    7e14:	54ff0ce1 	b.ne	5fb0 <f0+0x2f0>  // b.any
    7e18:	17fff861 	b	5f9c <f0+0x2dc>
    7e1c:	72003c3f 	tst	w1, #0xffff
    7e20:	54ff43a1 	b.ne	6694 <f0+0x9d4>  // b.any
    7e24:	17fffa17 	b	6680 <f0+0x9c0>
    7e28:	72003c3f 	tst	w1, #0xffff
    7e2c:	54ff3c41 	b.ne	65b4 <f0+0x8f4>  // b.any
    7e30:	17fff9dc 	b	65a0 <f0+0x8e0>
    7e34:	72003c3f 	tst	w1, #0xffff
    7e38:	54ff34e1 	b.ne	64d4 <f0+0x814>  // b.any
    7e3c:	17fff9a1 	b	64c0 <f0+0x800>
    7e40:	72003c3f 	tst	w1, #0xffff
    7e44:	54ff2541 	b.ne	62ec <f0+0x62c>  // b.any
    7e48:	17fff924 	b	62d8 <f0+0x618>
    7e4c:	72003c3f 	tst	w1, #0xffff
    7e50:	54ff7061 	b.ne	6c5c <f0+0xf9c>  // b.any
    7e54:	17fffb7d 	b	6c48 <f0+0xf88>
    7e58:	72003c3f 	tst	w1, #0xffff
    7e5c:	54ff69c1 	b.ne	6b94 <f0+0xed4>  // b.any
    7e60:	17fffb48 	b	6b80 <f0+0xec0>
    7e64:	72003c3f 	tst	w1, #0xffff
    7e68:	54ff63e1 	b.ne	6ae4 <f0+0xe24>  // b.any
    7e6c:	17fffb19 	b	6ad0 <f0+0xe10>
    7e70:	72003c3f 	tst	w1, #0xffff
    7e74:	54ff5d41 	b.ne	6a1c <f0+0xd5c>  // b.any
    7e78:	17fffae4 	b	6a08 <f0+0xd48>
    7e7c:	72003c3f 	tst	w1, #0xffff
    7e80:	54ff56a1 	b.ne	6954 <f0+0xc94>  // b.any
    7e84:	17fffaaf 	b	6940 <f0+0xc80>
    7e88:	72003c3f 	tst	w1, #0xffff
    7e8c:	54ff50c1 	b.ne	68a4 <f0+0xbe4>  // b.any
    7e90:	17fffa80 	b	6890 <f0+0xbd0>
    7e94:	72003c3f 	tst	w1, #0xffff
    7e98:	54ff4ae1 	b.ne	67f4 <f0+0xb34>  // b.any
    7e9c:	17fffa51 	b	67e0 <f0+0xb20>
    7ea0:	72003c3f 	tst	w1, #0xffff
    7ea4:	54ff4501 	b.ne	6744 <f0+0xa84>  // b.any
    7ea8:	17fffa22 	b	6730 <f0+0xa70>
    7eac:	72003c3f 	tst	w1, #0xffff
    7eb0:	54fff041 	b.ne	7cb8 <f0+0x1ff8>  // b.any
    7eb4:	17ffff7c 	b	7ca4 <f0+0x1fe4>
    7eb8:	72003c3f 	tst	w1, #0xffff
    7ebc:	54ffeb41 	b.ne	7c24 <f0+0x1f64>  // b.any
    7ec0:	17ffff54 	b	7c10 <f0+0x1f50>
    7ec4:	72003c3f 	tst	w1, #0xffff
    7ec8:	54ffe661 	b.ne	7b94 <f0+0x1ed4>  // b.any
    7ecc:	17ffff2d 	b	7b80 <f0+0x1ec0>
    7ed0:	72003c3f 	tst	w1, #0xffff
    7ed4:	54ffe161 	b.ne	7b00 <f0+0x1e40>  // b.any
    7ed8:	17ffff05 	b	7aec <f0+0x1e2c>
    7edc:	72003c3f 	tst	w1, #0xffff
    7ee0:	54ffdac1 	b.ne	7a38 <f0+0x1d78>  // b.any
    7ee4:	17fffed0 	b	7a24 <f0+0x1d64>
    7ee8:	72003c3f 	tst	w1, #0xffff
    7eec:	54ffd4e1 	b.ne	7988 <f0+0x1cc8>  // b.any
    7ef0:	17fffea1 	b	7974 <f0+0x1cb4>
    7ef4:	72003c3f 	tst	w1, #0xffff
    7ef8:	54ffcfe1 	b.ne	78f4 <f0+0x1c34>  // b.any
    7efc:	17fffe79 	b	78e0 <f0+0x1c20>
    7f00:	72003c3f 	tst	w1, #0xffff
    7f04:	54ffcb01 	b.ne	7864 <f0+0x1ba4>  // b.any
    7f08:	17fffe52 	b	7850 <f0+0x1b90>
    7f0c:	72003c3f 	tst	w1, #0xffff
    7f10:	54ffc521 	b.ne	77b4 <f0+0x1af4>  // b.any
    7f14:	17fffe23 	b	77a0 <f0+0x1ae0>
    7f18:	72003c3f 	tst	w1, #0xffff
    7f1c:	54ffbd01 	b.ne	76bc <f0+0x19fc>  // b.any
    7f20:	17fffde2 	b	76a8 <f0+0x19e8>
    7f24:	72003c3f 	tst	w1, #0xffff
    7f28:	54ffb821 	b.ne	762c <f0+0x196c>  // b.any
    7f2c:	17fffdbb 	b	7618 <f0+0x1958>
    7f30:	72003c3f 	tst	w1, #0xffff
    7f34:	54ffb321 	b.ne	7598 <f0+0x18d8>  // b.any
    7f38:	17fffd93 	b	7584 <f0+0x18c4>
    7f3c:	72003c3f 	tst	w1, #0xffff
    7f40:	54ffae41 	b.ne	7508 <f0+0x1848>  // b.any
    7f44:	17fffd6c 	b	74f4 <f0+0x1834>
    7f48:	72003c3f 	tst	w1, #0xffff
    7f4c:	54ffa6e1 	b.ne	7428 <f0+0x1768>  // b.any
    7f50:	17fffd31 	b	7414 <f0+0x1754>
    7f54:	72003c3f 	tst	w1, #0xffff
    7f58:	54ffa1e1 	b.ne	7394 <f0+0x16d4>  // b.any
    7f5c:	17fffd09 	b	7380 <f0+0x16c0>
    7f60:	72003c3f 	tst	w1, #0xffff
    7f64:	54ff99c1 	b.ne	729c <f0+0x15dc>  // b.any
    7f68:	17fffcc8 	b	7288 <f0+0x15c8>
    7f6c:	aa1403e0 	mov	x0, x20
    7f70:	97ffeb85 	bl	2d84 <fwp_rc_forget_slot>
    7f74:	17ffff4f 	b	7cb0 <f0+0x1ff0>
    7f78:	aa1703e0 	mov	x0, x23
    7f7c:	97ffeb82 	bl	2d84 <fwp_rc_forget_slot>
    7f80:	17fff80a 	b	5fa8 <f0+0x2e8>
    7f84:	aa1503e0 	mov	x0, x21
    7f88:	97ffeb7f 	bl	2d84 <fwp_rc_forget_slot>
    7f8c:	17fff83b 	b	6078 <f0+0x3b8>
    7f90:	aa1703e0 	mov	x0, x23
    7f94:	97ffeb7c 	bl	2d84 <fwp_rc_forget_slot>
    7f98:	17fff89b 	b	6204 <f0+0x544>
    7f9c:	aa1503e0 	mov	x0, x21
    7fa0:	97ffeb79 	bl	2d84 <fwp_rc_forget_slot>
    7fa4:	17fff8d0 	b	62e4 <f0+0x624>
    7fa8:	aa1703e0 	mov	x0, x23
    7fac:	97ffeb76 	bl	2d84 <fwp_rc_forget_slot>
    7fb0:	17fff947 	b	64cc <f0+0x80c>
    7fb4:	aa1703e0 	mov	x0, x23
    7fb8:	97ffeb73 	bl	2d84 <fwp_rc_forget_slot>
    7fbc:	17fff97c 	b	65ac <f0+0x8ec>
    7fc0:	aa1703e0 	mov	x0, x23
    7fc4:	97ffeb70 	bl	2d84 <fwp_rc_forget_slot>
    7fc8:	17fff9b1 	b	668c <f0+0x9cc>
    7fcc:	aa1703e0 	mov	x0, x23
    7fd0:	97ffeb6d 	bl	2d84 <fwp_rc_forget_slot>
    7fd4:	17fff9da 	b	673c <f0+0xa7c>
    7fd8:	aa1703e0 	mov	x0, x23
    7fdc:	97ffeb6a 	bl	2d84 <fwp_rc_forget_slot>
    7fe0:	17fffa03 	b	67ec <f0+0xb2c>
    7fe4:	aa1703e0 	mov	x0, x23
    7fe8:	97ffeb67 	bl	2d84 <fwp_rc_forget_slot>
    7fec:	17fffa2c 	b	689c <f0+0xbdc>
    7ff0:	aa1703e0 	mov	x0, x23
    7ff4:	97ffeb64 	bl	2d84 <fwp_rc_forget_slot>
    7ff8:	17fffa55 	b	694c <f0+0xc8c>
    7ffc:	aa1703e0 	mov	x0, x23
    8000:	97ffeb61 	bl	2d84 <fwp_rc_forget_slot>
    8004:	17fffa84 	b	6a14 <f0+0xd54>
    8008:	aa1703e0 	mov	x0, x23
    800c:	97ffeb5e 	bl	2d84 <fwp_rc_forget_slot>
    8010:	17fffab3 	b	6adc <f0+0xe1c>
    8014:	aa1703e0 	mov	x0, x23
    8018:	97ffeb5b 	bl	2d84 <fwp_rc_forget_slot>
    801c:	17fffadc 	b	6b8c <f0+0xecc>
    8020:	aa1703e0 	mov	x0, x23
    8024:	97ffeb58 	bl	2d84 <fwp_rc_forget_slot>
    8028:	17fffb0b 	b	6c54 <f0+0xf94>
    802c:	aa1703e0 	mov	x0, x23
    8030:	97ffeb55 	bl	2d84 <fwp_rc_forget_slot>
    8034:	17fffb2d 	b	6ce8 <f0+0x1028>
    8038:	aa1703e0 	mov	x0, x23
    803c:	97ffeb52 	bl	2d84 <fwp_rc_forget_slot>
    8040:	17fffb56 	b	6d98 <f0+0x10d8>
    8044:	aa1703e0 	mov	x0, x23
    8048:	97ffeb4f 	bl	2d84 <fwp_rc_forget_slot>
    804c:	17fffb7f 	b	6e48 <f0+0x1188>
    8050:	aa1703e0 	mov	x0, x23
    8054:	97ffeb4c 	bl	2d84 <fwp_rc_forget_slot>
    8058:	17fffbb4 	b	6f28 <f0+0x1268>
    805c:	aa1703e0 	mov	x0, x23
    8060:	97ffeb49 	bl	2d84 <fwp_rc_forget_slot>
    8064:	17fffbdd 	b	6fd8 <f0+0x1318>
    8068:	aa1703e0 	mov	x0, x23
    806c:	97ffeb46 	bl	2d84 <fwp_rc_forget_slot>
    8070:	17fffc06 	b	7088 <f0+0x13c8>
    8074:	aa1703e0 	mov	x0, x23
    8078:	97ffeb43 	bl	2d84 <fwp_rc_forget_slot>
    807c:	17fffc35 	b	7150 <f0+0x1490>
    8080:	aa1703e0 	mov	x0, x23
    8084:	97ffeb40 	bl	2d84 <fwp_rc_forget_slot>
    8088:	17fffc57 	b	71e4 <f0+0x1524>
    808c:	aa1703e0 	mov	x0, x23
    8090:	97ffeb3d 	bl	2d84 <fwp_rc_forget_slot>
    8094:	17fffc80 	b	7294 <f0+0x15d4>
    8098:	aa1703e0 	mov	x0, x23
    809c:	97ffeb3a 	bl	2d84 <fwp_rc_forget_slot>
    80a0:	17fffcbb 	b	738c <f0+0x16cc>
    80a4:	aa1703e0 	mov	x0, x23
    80a8:	97ffeb37 	bl	2d84 <fwp_rc_forget_slot>
    80ac:	17fffcdd 	b	7420 <f0+0x1760>
    80b0:	aa1703e0 	mov	x0, x23
    80b4:	97ffeb34 	bl	2d84 <fwp_rc_forget_slot>
    80b8:	17fffd12 	b	7500 <f0+0x1840>
    80bc:	aa1703e0 	mov	x0, x23
    80c0:	97ffeb31 	bl	2d84 <fwp_rc_forget_slot>
    80c4:	17fffd33 	b	7590 <f0+0x18d0>
    80c8:	aa1703e0 	mov	x0, x23
    80cc:	97ffeb2e 	bl	2d84 <fwp_rc_forget_slot>
    80d0:	17fffd55 	b	7624 <f0+0x1964>
    80d4:	aa1703e0 	mov	x0, x23
    80d8:	97ffeb2b 	bl	2d84 <fwp_rc_forget_slot>
    80dc:	17fffd76 	b	76b4 <f0+0x19f4>
    80e0:	aa1703e0 	mov	x0, x23
    80e4:	97ffeb28 	bl	2d84 <fwp_rc_forget_slot>
    80e8:	17fffdb1 	b	77ac <f0+0x1aec>
    80ec:	aa1703e0 	mov	x0, x23
    80f0:	97ffeb25 	bl	2d84 <fwp_rc_forget_slot>
    80f4:	17fffdda 	b	785c <f0+0x1b9c>
    80f8:	aa1703e0 	mov	x0, x23
    80fc:	97ffeb22 	bl	2d84 <fwp_rc_forget_slot>
    8100:	17fffdfb 	b	78ec <f0+0x1c2c>
    8104:	aa1703e0 	mov	x0, x23
    8108:	97ffeb1f 	bl	2d84 <fwp_rc_forget_slot>
    810c:	17fffe1d 	b	7980 <f0+0x1cc0>
    8110:	aa1703e0 	mov	x0, x23
    8114:	97ffeb1c 	bl	2d84 <fwp_rc_forget_slot>
    8118:	17fffe46 	b	7a30 <f0+0x1d70>
    811c:	aa1703e0 	mov	x0, x23
    8120:	97ffeb19 	bl	2d84 <fwp_rc_forget_slot>
    8124:	17fffe75 	b	7af8 <f0+0x1e38>
    8128:	aa1703e0 	mov	x0, x23
    812c:	97ffeb16 	bl	2d84 <fwp_rc_forget_slot>
    8130:	17fffe97 	b	7b8c <f0+0x1ecc>
    8134:	aa1703e0 	mov	x0, x23
    8138:	97ffeb13 	bl	2d84 <fwp_rc_forget_slot>
    813c:	17fffeb8 	b	7c1c <f0+0x1f5c>
    8140:	97ffe4f0 	bl	1500 <__stack_chk_fail@plt>

0000000000008144 <fwp_main_thread>:
    8144:	d10443ff 	sub	sp, sp, #0x110
    8148:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    814c:	f947f400 	ldr	x0, [x0, #4072]
    8150:	a90c7bfd 	stp	x29, x30, [sp, #192]
    8154:	910303fd 	add	x29, sp, #0xc0
    8158:	a90e5bf5 	stp	x21, x22, [sp, #224]
    815c:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xc80>
    8160:	911582c1 	add	x1, x22, #0x560
    8164:	a90d53f3 	stp	x19, x20, [sp, #208]
    8168:	a90f63f7 	stp	x23, x24, [sp, #240]
    816c:	b953a421 	ldr	w1, [x1, #5028]
    8170:	a9106bf9 	stp	x25, x26, [sp, #256]
    8174:	f9400002 	ldr	x2, [x0]
    8178:	f9005fe2 	str	x2, [sp, #184]
    817c:	d2800002 	mov	x2, #0x0                   	// #0
    8180:	340028c1 	cbz	w1, 8698 <fwp_main_thread+0x554>
    8184:	911582c0 	add	x0, x22, #0x560
    8188:	b953a800 	ldr	w0, [x0, #5032]
    818c:	350027e0 	cbnz	w0, 8688 <fwp_main_thread+0x544>
    8190:	91001fe2 	add	x2, sp, #0x7
    8194:	900000d5 	adrp	x21, 20000 <__data_start>
    8198:	900000c3 	adrp	x3, 20000 <__data_start>
    819c:	910202b3 	add	x19, x21, #0x80
    81a0:	910e0063 	add	x3, x3, #0x380
    81a4:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    81a8:	d2a00025 	mov	x5, #0x10000               	// #65536
    81ac:	910023e0 	add	x0, sp, #0x8
    81b0:	d2800001 	mov	x1, #0x0                   	// #0
    81b4:	f90007e3 	str	x3, [sp, #8]
    81b8:	a9011262 	stp	x2, x4, [x19, #16]
    81bc:	b90013ff 	str	wzr, [sp, #16]
    81c0:	f9000fe5 	str	x5, [sp, #24]
    81c4:	97ffe46b 	bl	1370 <sigaltstack@plt>
    81c8:	35002800 	cbnz	w0, 86c8 <fwp_main_thread+0x584>
    81cc:	4f000400 	movi	v0.4s, #0x0
    81d0:	9100a3e0 	add	x0, sp, #0x28
    81d4:	b0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    81d8:	52800082 	mov	w2, #0x4                   	// #4
    81dc:	91304021 	add	x1, x1, #0xc10
    81e0:	72a10002 	movk	w2, #0x800, lsl #16
    81e4:	910083f4 	add	x20, sp, #0x20
    81e8:	f90013e1 	str	x1, [sp, #32]
    81ec:	3d802000 	str	q0, [x0, #128]
    81f0:	b900abe2 	str	w2, [sp, #168]
    81f4:	ad000000 	stp	q0, q0, [x0]
    81f8:	ad010000 	stp	q0, q0, [x0, #32]
    81fc:	ad020000 	stp	q0, q0, [x0, #64]
    8200:	ad030000 	stp	q0, q0, [x0, #96]
    8204:	97ffe4af 	bl	14c0 <sigemptyset@plt>
    8208:	35002600 	cbnz	w0, 86c8 <fwp_main_thread+0x584>
    820c:	aa1403e1 	mov	x1, x20
    8210:	d2800002 	mov	x2, #0x0                   	// #0
    8214:	52800160 	mov	w0, #0xb                   	// #11
    8218:	97ffe4c2 	bl	1520 <sigaction@plt>
    821c:	35002560 	cbnz	w0, 86c8 <fwp_main_thread+0x584>
    8220:	aa1403e1 	mov	x1, x20
    8224:	d2800002 	mov	x2, #0x0                   	// #0
    8228:	528000e0 	mov	w0, #0x7                   	// #7
    822c:	97ffe4bd 	bl	1520 <sigaction@plt>
    8230:	350024c0 	cbnz	w0, 86c8 <fwp_main_thread+0x584>
    8234:	911582c1 	add	x1, x22, #0x560
    8238:	52800034 	mov	w20, #0x1                   	// #1
    823c:	b0ffffc0 	adrp	x0, 1000 <__abi_tag+0xd88>
    8240:	913c4000 	add	x0, x0, #0xf10
    8244:	b9004274 	str	w20, [x19, #64]
    8248:	fd4a1020 	ldr	d0, [x1, #5152]
    824c:	7e61d800 	ucvtf	d0, d0
    8250:	fd002e60 	str	d0, [x19, #88]
    8254:	940002e3 	bl	8de0 <atexit>
    8258:	350023e0 	cbnz	w0, 86d4 <fwp_main_thread+0x590>
    825c:	b942d260 	ldr	w0, [x19, #720]
    8260:	34002200 	cbz	w0, 86a0 <fwp_main_thread+0x55c>
    8264:	910202ba 	add	x26, x21, #0x80
    8268:	f9400754 	ldr	x20, [x26, #8]
    826c:	b4001094 	cbz	x20, 847c <fwp_main_thread+0x338>
    8270:	aa1403f3 	mov	x19, x20
    8274:	91010297 	add	x23, x20, #0x40
    8278:	39414a99 	ldrb	w25, [x20, #82]
    827c:	52800038 	mov	w24, #0x1                   	// #1
    8280:	39014a98 	strb	w24, [x20, #82]
    8284:	f9401680 	ldr	x0, [x20, #40]
    8288:	b4000620 	cbz	x0, 834c <fwp_main_thread+0x208>
    828c:	f9403281 	ldr	x1, [x20, #96]
    8290:	39414680 	ldrb	w0, [x20, #81]
    8294:	b4000b21 	cbz	x1, 83f8 <fwp_main_thread+0x2b4>
    8298:	36000a60 	tbz	w0, #0, 83e4 <fwp_main_thread+0x2a0>
    829c:	39414a62 	ldrb	w2, [x19, #82]
    82a0:	f9402280 	ldr	x0, [x20, #64]
    82a4:	37000d42 	tbnz	w2, #0, 844c <fwp_main_thread+0x308>
    82a8:	f9403261 	ldr	x1, [x19, #96]
    82ac:	a911fe77 	stp	x23, xzr, [x19, #280]
    82b0:	f9009660 	str	x0, [x19, #296]
    82b4:	b4000040 	cbz	x0, 82bc <fwp_main_thread+0x178>
    82b8:	f9009013 	str	x19, [x0, #288]
    82bc:	f9002293 	str	x19, [x20, #64]
    82c0:	b4000101 	cbz	x1, 82e0 <fwp_main_thread+0x19c>
    82c4:	f9401f40 	ldr	x0, [x26, #56]
    82c8:	39015678 	strb	w24, [x19, #85]
    82cc:	f9003661 	str	x1, [x19, #104]
    82d0:	a910827f 	stp	xzr, x0, [x19, #264]
    82d4:	b4000040 	cbz	x0, 82dc <fwp_main_thread+0x198>
    82d8:	f9008413 	str	x19, [x0, #264]
    82dc:	f9001f53 	str	x19, [x26, #56]
    82e0:	39015a7f 	strb	wzr, [x19, #86]
    82e4:	97ffeee4 	bl	3e74 <fwp_block>
    82e8:	f9408e62 	ldr	x2, [x19, #280]
    82ec:	b4000142 	cbz	x2, 8314 <fwp_main_thread+0x1d0>
    82f0:	a9520261 	ldp	x1, x0, [x19, #288]
    82f4:	b4000b81 	cbz	x1, 8464 <fwp_main_thread+0x320>
    82f8:	f9009420 	str	x0, [x1, #296]
    82fc:	f9409660 	ldr	x0, [x19, #296]
    8300:	b4000040 	cbz	x0, 8308 <fwp_main_thread+0x1c4>
    8304:	f9009001 	str	x1, [x0, #288]
    8308:	91080260 	add	x0, x19, #0x200
    830c:	f900967f 	str	xzr, [x19, #296]
    8310:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8314:	39415660 	ldrb	w0, [x19, #85]
    8318:	f9400742 	ldr	x2, [x26, #8]
    831c:	36000940 	tbz	w0, #0, 8444 <fwp_main_thread+0x300>
    8320:	a9508261 	ldp	x1, x0, [x19, #264]
    8324:	b4000a41 	cbz	x1, 846c <fwp_main_thread+0x328>
    8328:	f9008820 	str	x0, [x1, #272]
    832c:	b4000040 	cbz	x0, 8334 <fwp_main_thread+0x1f0>
    8330:	f9008401 	str	x1, [x0, #264]
    8334:	91080260 	add	x0, x19, #0x200
    8338:	3901567f 	strb	wzr, [x19, #85]
    833c:	aa0203f3 	mov	x19, x2
    8340:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8344:	f9401680 	ldr	x0, [x20, #40]
    8348:	b5fffa20 	cbnz	x0, 828c <fwp_main_thread+0x148>
    834c:	910202a0 	add	x0, x21, #0x80
    8350:	39014a99 	strb	w25, [x20, #82]
    8354:	f9415400 	ldr	x0, [x0, #680]
    8358:	b40017a0 	cbz	x0, 864c <fwp_main_thread+0x508>
    835c:	910202a0 	add	x0, x21, #0x80
    8360:	f9417401 	ldr	x1, [x0, #744]
    8364:	b902e01f 	str	wzr, [x0, #736]
    8368:	eb13003f 	cmp	x1, x19
    836c:	540018c1 	b.ne	8684 <fwp_main_thread+0x540>  // b.any
    8370:	b4000913 	cbz	x19, 8490 <fwp_main_thread+0x34c>
    8374:	910202a0 	add	x0, x21, #0x80
    8378:	52800021 	mov	w1, #0x1                   	// #1
    837c:	39014a61 	strb	w1, [x19, #82]
    8380:	f9414005 	ldr	x5, [x0, #640]
    8384:	b4000865 	cbz	x5, 8490 <fwp_main_thread+0x34c>
    8388:	394140a0 	ldrb	w0, [x5, #80]
    838c:	37000060 	tbnz	w0, #0, 8398 <fwp_main_thread+0x254>
    8390:	aa0503e0 	mov	x0, x5
    8394:	97ffe777 	bl	2170 <fwp_cancel_tree.part.0>
    8398:	f9409ca5 	ldr	x5, [x5, #312]
    839c:	b5ffff65 	cbnz	x5, 8388 <fwp_main_thread+0x244>
    83a0:	910202b4 	add	x20, x21, #0x80
    83a4:	52800037 	mov	w23, #0x1                   	// #1
    83a8:	f9402a60 	ldr	x0, [x19, #80]
    83ac:	f2001c1f 	tst	x0, #0xff000000ff
    83b0:	540000e1 	b.ne	83cc <fwp_main_thread+0x288>  // b.any
    83b4:	f9401680 	ldr	x0, [x20, #40]
    83b8:	39015277 	strb	w23, [x19, #84]
    83bc:	f900827f 	str	xzr, [x19, #256]
    83c0:	b40005a0 	cbz	x0, 8474 <fwp_main_thread+0x330>
    83c4:	f9008013 	str	x19, [x0, #256]
    83c8:	f9001693 	str	x19, [x20, #40]
    83cc:	97ffeeaa 	bl	3e74 <fwp_block>
    83d0:	97ffee3c 	bl	3cc0 <fwp_free_zombie>
    83d4:	f9414280 	ldr	x0, [x20, #640]
    83d8:	b40005c0 	cbz	x0, 8490 <fwp_main_thread+0x34c>
    83dc:	f9417693 	ldr	x19, [x20, #744]
    83e0:	17fffff2 	b	83a8 <fwp_main_thread+0x264>
    83e4:	97ffe7b7 	bl	22c0 <fwp_now_ns>
    83e8:	f9403281 	ldr	x1, [x20, #96]
    83ec:	eb01001f 	cmp	x0, x1
    83f0:	5400120a 	b.ge	8630 <fwp_main_thread+0x4ec>  // b.tcont
    83f4:	39414680 	ldrb	w0, [x20, #81]
    83f8:	39414a62 	ldrb	w2, [x19, #82]
    83fc:	3707f520 	tbnz	w0, #0, 82a0 <fwp_main_thread+0x15c>
    8400:	f9403281 	ldr	x1, [x20, #96]
    8404:	370001c2 	tbnz	w2, #0, 843c <fwp_main_thread+0x2f8>
    8408:	f9403260 	ldr	x0, [x19, #96]
    840c:	b4000180 	cbz	x0, 843c <fwp_main_thread+0x2f8>
    8410:	b4000061 	cbz	x1, 841c <fwp_main_thread+0x2d8>
    8414:	eb01001f 	cmp	x0, x1
    8418:	9a81d000 	csel	x0, x0, x1, le
    841c:	f9402281 	ldr	x1, [x20, #64]
    8420:	a911fe77 	stp	x23, xzr, [x19, #280]
    8424:	f9009661 	str	x1, [x19, #296]
    8428:	b4001441 	cbz	x1, 86b0 <fwp_main_thread+0x56c>
    842c:	f9009033 	str	x19, [x1, #288]
    8430:	aa0003e1 	mov	x1, x0
    8434:	f9002293 	str	x19, [x20, #64]
    8438:	17ffffa3 	b	82c4 <fwp_main_thread+0x180>
    843c:	f9402280 	ldr	x0, [x20, #64]
    8440:	17ffff9b 	b	82ac <fwp_main_thread+0x168>
    8444:	aa0203f3 	mov	x19, x2
    8448:	17ffff8f 	b	8284 <fwp_main_thread+0x140>
    844c:	a911fe77 	stp	x23, xzr, [x19, #280]
    8450:	f9009660 	str	x0, [x19, #296]
    8454:	b4000040 	cbz	x0, 845c <fwp_main_thread+0x318>
    8458:	f9009013 	str	x19, [x0, #288]
    845c:	f9002293 	str	x19, [x20, #64]
    8460:	17ffffa0 	b	82e0 <fwp_main_thread+0x19c>
    8464:	f9000040 	str	x0, [x2]
    8468:	17ffffa6 	b	8300 <fwp_main_thread+0x1bc>
    846c:	f9001f40 	str	x0, [x26, #56]
    8470:	17ffffaf 	b	832c <fwp_main_thread+0x1e8>
    8474:	f9001a93 	str	x19, [x20, #48]
    8478:	17ffffd4 	b	83c8 <fwp_main_thread+0x284>
    847c:	f9415740 	ldr	x0, [x26, #680]
    8480:	b4000e40 	cbz	x0, 8648 <fwp_main_thread+0x504>
    8484:	f9417740 	ldr	x0, [x26, #744]
    8488:	b902e35f 	str	wzr, [x26, #736]
    848c:	b5000fc0 	cbnz	x0, 8684 <fwp_main_thread+0x540>
    8490:	910202b4 	add	x20, x21, #0x80
    8494:	97ffee0b 	bl	3cc0 <fwp_free_zombie>
    8498:	f9401a80 	ldr	x0, [x20, #48]
    849c:	b5000f40 	cbnz	x0, 8684 <fwp_main_thread+0x540>
    84a0:	f9401e80 	ldr	x0, [x20, #56]
    84a4:	b5000f00 	cbnz	x0, 8684 <fwp_main_thread+0x540>
    84a8:	b9407293 	ldr	w19, [x20, #112]
    84ac:	340001d3 	cbz	w19, 84e4 <fwp_main_thread+0x3a0>
    84b0:	93407e77 	sxtw	x23, w19
    84b4:	51000673 	sub	w19, w19, #0x1
    84b8:	d1000af7 	sub	x23, x23, #0x2
    84bc:	91020298 	add	x24, x20, #0x80
    84c0:	cb3342f7 	sub	x23, x23, w19, uxtw
    84c4:	93407e73 	sxtw	x19, w19
    84c8:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    84cc:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    84d0:	b9007293 	str	w19, [x20, #112]
    84d4:	d1000673 	sub	x19, x19, #0x1
    84d8:	97ffe452 	bl	1620 <munmap@plt>
    84dc:	eb1302ff 	cmp	x23, x19
    84e0:	54ffff41 	b.ne	84c8 <fwp_main_thread+0x384>  // b.any
    84e4:	900000d3 	adrp	x19, 20000 <__data_start>
    84e8:	91004260 	add	x0, x19, #0x10
    84ec:	b9405000 	ldr	w0, [x0, #80]
    84f0:	37f80040 	tbnz	w0, #31, 84f8 <fwp_main_thread+0x3b4>
    84f4:	97ffe407 	bl	1510 <close@plt>
    84f8:	910202a0 	add	x0, x21, #0x80
    84fc:	91004261 	add	x1, x19, #0x10
    8500:	12800002 	mov	w2, #0xffffffff            	// #-1
    8504:	d2800013 	mov	x19, #0x0                   	// #0
    8508:	f9417817 	ldr	x23, [x0, #752]
    850c:	b9005022 	str	w2, [x1, #80]
    8510:	f9417c14 	ldr	x20, [x0, #760]
    8514:	b4000177 	cbz	x23, 8540 <fwp_main_thread+0x3fc>
    8518:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    851c:	b40000c0 	cbz	x0, 8534 <fwp_main_thread+0x3f0>
    8520:	f9400001 	ldr	x1, [x0]
    8524:	b5000b01 	cbnz	x1, 8684 <fwp_main_thread+0x540>
    8528:	f9400401 	ldr	x1, [x0, #8]
    852c:	b5000ac1 	cbnz	x1, 8684 <fwp_main_thread+0x540>
    8530:	97ffeab4 	bl	3000 <fwp_mem_free>
    8534:	91000673 	add	x19, x19, #0x1
    8538:	eb1302ff 	cmp	x23, x19
    853c:	54fffee1 	b.ne	8518 <fwp_main_thread+0x3d4>  // b.any
    8540:	aa1403e0 	mov	x0, x20
    8544:	97ffeaaf 	bl	3000 <fwp_mem_free>
    8548:	910202a0 	add	x0, x21, #0x80
    854c:	f9417413 	ldr	x19, [x0, #744]
    8550:	f901781f 	str	xzr, [x0, #752]
    8554:	f9017c1f 	str	xzr, [x0, #760]
    8558:	b40001f3 	cbz	x19, 8594 <fwp_main_thread+0x450>
    855c:	f9401661 	ldr	x1, [x19, #40]
    8560:	b5000921 	cbnz	x1, 8684 <fwp_main_thread+0x540>
    8564:	f9405661 	ldr	x1, [x19, #168]
    8568:	b50008e1 	cbnz	x1, 8684 <fwp_main_thread+0x540>
    856c:	f9415401 	ldr	x1, [x0, #680]
    8570:	b50008a1 	cbnz	x1, 8684 <fwp_main_thread+0x540>
    8574:	f9415c00 	ldr	x0, [x0, #696]
    8578:	b5000860 	cbnz	x0, 8684 <fwp_main_thread+0x540>
    857c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8580:	90000140 	adrp	x0, 30000 <alt.4+0xfc80>
    8584:	910e0000 	add	x0, x0, #0x380
    8588:	97ffe3d2 	bl	14d0 <memset@plt>
    858c:	aa1303e0 	mov	x0, x19
    8590:	97ffea9c 	bl	3000 <fwp_mem_free>
    8594:	911582d6 	add	x22, x22, #0x560
    8598:	910202b5 	add	x21, x21, #0x80
    859c:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    85a0:	f947e800 	ldr	x0, [x0, #4048]
    85a4:	52800041 	mov	w1, #0x2                   	// #2
    85a8:	fd4a12c0 	ldr	d0, [x22, #5152]
    85ac:	b0000002 	adrp	x2, 9000 <_IO_stdin_used+0x1f0>
    85b0:	fd402ea1 	ldr	d1, [x21, #88]
    85b4:	910b4042 	add	x2, x2, #0x2d0
    85b8:	a94492a3 	ldp	x3, x4, [x21, #72]
    85bc:	7e61d800 	ucvtf	d0, d0
    85c0:	f9400000 	ldr	x0, [x0]
    85c4:	f90006bf 	str	xzr, [x21, #8]
    85c8:	f94166a5 	ldr	x5, [x21, #712]
    85cc:	1e613801 	fsub	d1, d0, d1
    85d0:	fd4032a0 	ldr	d0, [x21, #96]
    85d4:	f90012bf 	str	xzr, [x21, #32]
    85d8:	b90042bf 	str	wzr, [x21, #64]
    85dc:	f90176bf 	str	xzr, [x21, #744]
    85e0:	97ffe3e4 	bl	1570 <__fprintf_chk@plt>
    85e4:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    85e8:	f947ec00 	ldr	x0, [x0, #4056]
    85ec:	f9400000 	ldr	x0, [x0]
    85f0:	97ffe410 	bl	1630 <fflush@plt>
    85f4:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x14da0>
    85f8:	f947f400 	ldr	x0, [x0, #4072]
    85fc:	f9405fe2 	ldr	x2, [sp, #184]
    8600:	f9400001 	ldr	x1, [x0]
    8604:	eb010042 	subs	x2, x2, x1
    8608:	d2800001 	mov	x1, #0x0                   	// #0
    860c:	540006a1 	b.ne	86e0 <fwp_main_thread+0x59c>  // b.any
    8610:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    8614:	d2800000 	mov	x0, #0x0                   	// #0
    8618:	a94d53f3 	ldp	x19, x20, [sp, #208]
    861c:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    8620:	a94f63f7 	ldp	x23, x24, [sp, #240]
    8624:	a9506bf9 	ldp	x25, x26, [sp, #256]
    8628:	910443ff 	add	sp, sp, #0x110
    862c:	d65f03c0 	ret
    8630:	39414280 	ldrb	w0, [x20, #80]
    8634:	3707ee00 	tbnz	w0, #0, 83f4 <fwp_main_thread+0x2b0>
    8638:	aa1403e0 	mov	x0, x20
    863c:	97ffe6cd 	bl	2170 <fwp_cancel_tree.part.0>
    8640:	39414680 	ldrb	w0, [x20, #81]
    8644:	17ffff6d 	b	83f8 <fwp_main_thread+0x2b4>
    8648:	d2800013 	mov	x19, #0x0                   	// #0
    864c:	910202b4 	add	x20, x21, #0x80
    8650:	f9415e80 	ldr	x0, [x20, #696]
    8654:	b5ffe840 	cbnz	x0, 835c <fwp_main_thread+0x218>
    8658:	f9415280 	ldr	x0, [x20, #672]
    865c:	97ffea69 	bl	3000 <fwp_mem_free>
    8660:	f901529f 	str	xzr, [x20, #672]
    8664:	f9015a9f 	str	xzr, [x20, #688]
    8668:	f9417680 	ldr	x0, [x20, #744]
    866c:	b4000293 	cbz	x19, 86bc <fwp_main_thread+0x578>
    8670:	f900567f 	str	xzr, [x19, #168]
    8674:	f9005e7f 	str	xzr, [x19, #184]
    8678:	b902e29f 	str	wzr, [x20, #736]
    867c:	eb13001f 	cmp	x0, x19
    8680:	54ffe7a0 	b.eq	8374 <fwp_main_thread+0x230>  // b.none
    8684:	97ffe3b3 	bl	1550 <abort@plt>
    8688:	d0ffffc0 	adrp	x0, 2000 <ad_raw_report+0xf0>
    868c:	911d9000 	add	x0, x0, #0x764
    8690:	940001d4 	bl	8de0 <atexit>
    8694:	17fffebf 	b	8190 <fwp_main_thread+0x4c>
    8698:	97ffe88e 	bl	28d0 <fwp_heap_init>
    869c:	17fffeba 	b	8184 <fwp_main_thread+0x40>
    86a0:	97fff588 	bl	5cc0 <f0>
    86a4:	b902d274 	str	w20, [x19, #720]
    86a8:	f9016e60 	str	x0, [x19, #728]
    86ac:	17fffeee 	b	8264 <fwp_main_thread+0x120>
    86b0:	aa0003e1 	mov	x1, x0
    86b4:	f9002293 	str	x19, [x20, #64]
    86b8:	17ffff03 	b	82c4 <fwp_main_thread+0x180>
    86bc:	b902e29f 	str	wzr, [x20, #736]
    86c0:	b4ffee80 	cbz	x0, 8490 <fwp_main_thread+0x34c>
    86c4:	97ffe3a3 	bl	1550 <abort@plt>
    86c8:	b0000000 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    86cc:	910a2000 	add	x0, x0, #0x288
    86d0:	97ffe6ec 	bl	2280 <fwp_trap>
    86d4:	b0000000 	adrp	x0, 9000 <_IO_stdin_used+0x1f0>
    86d8:	910ac000 	add	x0, x0, #0x2b0
    86dc:	97ffe601 	bl	1ee0 <ad_raw_fail>
    86e0:	97ffe388 	bl	1500 <__stack_chk_fail@plt>
    86e4:	d503201f 	nop
    86e8:	d503201f 	nop
    86ec:	d503201f 	nop

00000000000086f0 <__divti3>:
    86f0:	d503245f 	bti	c
    86f4:	d2800004 	mov	x4, #0x0                   	// #0
    86f8:	b7f80721 	tbnz	x1, #63, 87dc <__divti3+0xec>
    86fc:	b6f80083 	tbz	x3, #63, 870c <__divti3+0x1c>
    8700:	eb0203e2 	negs	x2, x2
    8704:	aa2403e4 	mvn	x4, x4
    8708:	da0303e3 	ngc	x3, x3
    870c:	aa0203e6 	mov	x6, x2
    8710:	aa0003e7 	mov	x7, x0
    8714:	aa0103e5 	mov	x5, x1
    8718:	b5000583 	cbnz	x3, 87c8 <__divti3+0xd8>
    871c:	eb01005f 	cmp	x2, x1
    8720:	54000e69 	b.ls	88ec <__divti3+0x1fc>  // b.plast
    8724:	dac01040 	clz	x0, x2
    8728:	b40000e0 	cbz	x0, 8744 <__divti3+0x54>
    872c:	4b0003e1 	neg	w1, w0
    8730:	9ac020a5 	lsl	x5, x5, x0
    8734:	9ac02046 	lsl	x6, x2, x0
    8738:	9ac124e1 	lsr	x1, x7, x1
    873c:	aa050025 	orr	x5, x1, x5
    8740:	9ac020e7 	lsl	x7, x7, x0
    8744:	d360fcc8 	lsr	x8, x6, #32
    8748:	92407cc2 	and	x2, x6, #0xffffffff
    874c:	9ac808a3 	udiv	x3, x5, x8
    8750:	9b089465 	msub	x5, x3, x8, x5
    8754:	aa0303e0 	mov	x0, x3
    8758:	9b037c41 	mul	x1, x2, x3
    875c:	93c780a5 	extr	x5, x5, x7, #32
    8760:	eb05003f 	cmp	x1, x5
    8764:	540000a9 	b.ls	8778 <__divti3+0x88>  // b.plast
    8768:	ab0500c5 	adds	x5, x6, x5
    876c:	d1000460 	sub	x0, x3, #0x1
    8770:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8774:	540015a8 	b.hi	8a28 <__divti3+0x338>  // b.pmore
    8778:	cb0100a5 	sub	x5, x5, x1
    877c:	9ac808a3 	udiv	x3, x5, x8
    8780:	9b089465 	msub	x5, x3, x8, x5
    8784:	aa0303e1 	mov	x1, x3
    8788:	9b037c42 	mul	x2, x2, x3
    878c:	aa0703e3 	mov	x3, x7
    8790:	b3607ca3 	bfi	x3, x5, #32, #32
    8794:	eb03005f 	cmp	x2, x3
    8798:	540000c9 	b.ls	87b0 <__divti3+0xc0>  // b.plast
    879c:	ab0300c3 	adds	x3, x6, x3
    87a0:	d1000425 	sub	x5, x1, #0x1
    87a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    87a8:	d1000821 	sub	x1, x1, #0x2
    87ac:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    87b0:	aa008020 	orr	x0, x1, x0, lsl #32
    87b4:	d2800001 	mov	x1, #0x0                   	// #0
    87b8:	b4000064 	cbz	x4, 87c4 <__divti3+0xd4>
    87bc:	eb0003e0 	negs	x0, x0
    87c0:	da0103e1 	ngc	x1, x1
    87c4:	d65f03c0 	ret
    87c8:	eb01007f 	cmp	x3, x1
    87cc:	54000109 	b.ls	87ec <__divti3+0xfc>  // b.plast
    87d0:	d2800001 	mov	x1, #0x0                   	// #0
    87d4:	d2800000 	mov	x0, #0x0                   	// #0
    87d8:	17fffff8 	b	87b8 <__divti3+0xc8>
    87dc:	eb0003e0 	negs	x0, x0
    87e0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    87e4:	da0103e1 	ngc	x1, x1
    87e8:	17ffffc5 	b	86fc <__divti3+0xc>
    87ec:	dac01067 	clz	x7, x3
    87f0:	b40010e7 	cbz	x7, 8a0c <__divti3+0x31c>
    87f4:	d2800805 	mov	x5, #0x40                  	// #64
    87f8:	cb0700a5 	sub	x5, x5, x7
    87fc:	9ac72063 	lsl	x3, x3, x7
    8800:	9ac52448 	lsr	x8, x2, x5
    8804:	aa030108 	orr	x8, x8, x3
    8808:	9ac52426 	lsr	x6, x1, x5
    880c:	92407d0a 	and	x10, x8, #0xffffffff
    8810:	d360fd09 	lsr	x9, x8, #32
    8814:	9ac52403 	lsr	x3, x0, x5
    8818:	9ac72021 	lsl	x1, x1, x7
    881c:	aa010063 	orr	x3, x3, x1
    8820:	9ac72042 	lsl	x2, x2, x7
    8824:	9ac908cb 	udiv	x11, x6, x9
    8828:	9b099965 	msub	x5, x11, x9, x6
    882c:	aa0b03e1 	mov	x1, x11
    8830:	9b0b7d46 	mul	x6, x10, x11
    8834:	93c380a5 	extr	x5, x5, x3, #32
    8838:	eb0500df 	cmp	x6, x5
    883c:	540000a9 	b.ls	8850 <__divti3+0x160>  // b.plast
    8840:	ab050105 	adds	x5, x8, x5
    8844:	d1000561 	sub	x1, x11, #0x1
    8848:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    884c:	54000f48 	b.hi	8a34 <__divti3+0x344>  // b.pmore
    8850:	cb0600a6 	sub	x6, x5, x6
    8854:	9ac908cb 	udiv	x11, x6, x9
    8858:	9b099969 	msub	x9, x11, x9, x6
    885c:	aa0b03e5 	mov	x5, x11
    8860:	9b0b7d4a 	mul	x10, x10, x11
    8864:	b3607d23 	bfi	x3, x9, #32, #32
    8868:	eb03015f 	cmp	x10, x3
    886c:	540000a9 	b.ls	8880 <__divti3+0x190>  // b.plast
    8870:	ab030103 	adds	x3, x8, x3
    8874:	d1000565 	sub	x5, x11, #0x1
    8878:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    887c:	54000e28 	b.hi	8a40 <__divti3+0x350>  // b.pmore
    8880:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8884:	92407c48 	and	x8, x2, #0xffffffff
    8888:	2a0503e5 	mov	w5, w5
    888c:	d360fc42 	lsr	x2, x2, #32
    8890:	d360fc26 	lsr	x6, x1, #32
    8894:	cb0a0063 	sub	x3, x3, x10
    8898:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    889c:	9b087caa 	mul	x10, x5, x8
    88a0:	9b087cc8 	mul	x8, x6, x8
    88a4:	9b0220a5 	madd	x5, x5, x2, x8
    88a8:	9b027cc6 	mul	x6, x6, x2
    88ac:	8b4a80a2 	add	x2, x5, x10, lsr #32
    88b0:	8b0900c5 	add	x5, x6, x9
    88b4:	eb02011f 	cmp	x8, x2
    88b8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    88bc:	8b4280c6 	add	x6, x6, x2, lsr #32
    88c0:	eb06007f 	cmp	x3, x6
    88c4:	540000e3 	b.cc	88e0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    88c8:	92407d4a 	and	x10, x10, #0xffffffff
    88cc:	9ac72000 	lsl	x0, x0, x7
    88d0:	8b028142 	add	x2, x10, x2, lsl #32
    88d4:	eb02001f 	cmp	x0, x2
    88d8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    88dc:	54000a01 	b.ne	8a1c <__divti3+0x32c>  // b.any
    88e0:	d1000420 	sub	x0, x1, #0x1
    88e4:	d2800001 	mov	x1, #0x0                   	// #0
    88e8:	17ffffb4 	b	87b8 <__divti3+0xc8>
    88ec:	b5000062 	cbnz	x2, 88f8 <__divti3+0x208>
    88f0:	d2800022 	mov	x2, #0x1                   	// #1
    88f4:	9ac30846 	udiv	x6, x2, x3
    88f8:	dac010c8 	clz	x8, x6
    88fc:	b5000408 	cbnz	x8, 897c <__divti3+0x28c>
    8900:	d360fcc9 	lsr	x9, x6, #32
    8904:	92407cc5 	and	x5, x6, #0xffffffff
    8908:	cb060023 	sub	x3, x1, x6
    890c:	d2800021 	mov	x1, #0x1                   	// #1
    8910:	9ac90868 	udiv	x8, x3, x9
    8914:	9b098d03 	msub	x3, x8, x9, x3
    8918:	aa0803e0 	mov	x0, x8
    891c:	9b057d02 	mul	x2, x8, x5
    8920:	93c78063 	extr	x3, x3, x7, #32
    8924:	eb03005f 	cmp	x2, x3
    8928:	540000a9 	b.ls	893c <__divti3+0x24c>  // b.plast
    892c:	ab0300c3 	adds	x3, x6, x3
    8930:	d1000500 	sub	x0, x8, #0x1
    8934:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8938:	54000968 	b.hi	8a64 <__divti3+0x374>  // b.pmore
    893c:	cb020063 	sub	x3, x3, x2
    8940:	9ac90862 	udiv	x2, x3, x9
    8944:	aa0203e8 	mov	x8, x2
    8948:	9b098c42 	msub	x2, x2, x9, x3
    894c:	aa0703e3 	mov	x3, x7
    8950:	9b057d05 	mul	x5, x8, x5
    8954:	b3607c43 	bfi	x3, x2, #32, #32
    8958:	eb0300bf 	cmp	x5, x3
    895c:	540000c9 	b.ls	8974 <__divti3+0x284>  // b.plast
    8960:	ab0300c2 	adds	x2, x6, x3
    8964:	d1000503 	sub	x3, x8, #0x1
    8968:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    896c:	d1000908 	sub	x8, x8, #0x2
    8970:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    8974:	aa008100 	orr	x0, x8, x0, lsl #32
    8978:	17ffff90 	b	87b8 <__divti3+0xc8>
    897c:	9ac820c6 	lsl	x6, x6, x8
    8980:	d2800803 	mov	x3, #0x40                  	// #64
    8984:	cb080063 	sub	x3, x3, x8
    8988:	d360fcc9 	lsr	x9, x6, #32
    898c:	9ac82027 	lsl	x7, x1, x8
    8990:	92407cc5 	and	x5, x6, #0xffffffff
    8994:	9ac32422 	lsr	x2, x1, x3
    8998:	9ac32403 	lsr	x3, x0, x3
    899c:	aa070063 	orr	x3, x3, x7
    89a0:	9ac9084a 	udiv	x10, x2, x9
    89a4:	9ac82007 	lsl	x7, x0, x8
    89a8:	9b098940 	msub	x0, x10, x9, x2
    89ac:	aa0a03e1 	mov	x1, x10
    89b0:	9b0a7ca2 	mul	x2, x5, x10
    89b4:	93c38000 	extr	x0, x0, x3, #32
    89b8:	eb00005f 	cmp	x2, x0
    89bc:	540000a9 	b.ls	89d0 <__divti3+0x2e0>  // b.plast
    89c0:	ab0000c0 	adds	x0, x6, x0
    89c4:	d1000541 	sub	x1, x10, #0x1
    89c8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    89cc:	54000468 	b.hi	8a58 <__divti3+0x368>  // b.pmore
    89d0:	cb020000 	sub	x0, x0, x2
    89d4:	9ac9080a 	udiv	x10, x0, x9
    89d8:	9b098140 	msub	x0, x10, x9, x0
    89dc:	aa0a03e2 	mov	x2, x10
    89e0:	9b0a7ca8 	mul	x8, x5, x10
    89e4:	b3607c03 	bfi	x3, x0, #32, #32
    89e8:	eb03011f 	cmp	x8, x3
    89ec:	540000a9 	b.ls	8a00 <__divti3+0x310>  // b.plast
    89f0:	ab0300c3 	adds	x3, x6, x3
    89f4:	d1000542 	sub	x2, x10, #0x1
    89f8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    89fc:	54000288 	b.hi	8a4c <__divti3+0x35c>  // b.pmore
    8a00:	cb080063 	sub	x3, x3, x8
    8a04:	aa018041 	orr	x1, x2, x1, lsl #32
    8a08:	17ffffc2 	b	8910 <__divti3+0x220>
    8a0c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    8a10:	d2800001 	mov	x1, #0x0                   	// #0
    8a14:	9a9f87e0 	cset	x0, ls	// ls = plast
    8a18:	17ffff68 	b	87b8 <__divti3+0xc8>
    8a1c:	aa0103e0 	mov	x0, x1
    8a20:	d2800001 	mov	x1, #0x0                   	// #0
    8a24:	17ffff65 	b	87b8 <__divti3+0xc8>
    8a28:	d1000860 	sub	x0, x3, #0x2
    8a2c:	8b0600a5 	add	x5, x5, x6
    8a30:	17ffff52 	b	8778 <__divti3+0x88>
    8a34:	d1000961 	sub	x1, x11, #0x2
    8a38:	8b0800a5 	add	x5, x5, x8
    8a3c:	17ffff85 	b	8850 <__divti3+0x160>
    8a40:	d1000965 	sub	x5, x11, #0x2
    8a44:	8b080063 	add	x3, x3, x8
    8a48:	17ffff8e 	b	8880 <__divti3+0x190>
    8a4c:	d1000942 	sub	x2, x10, #0x2
    8a50:	8b060063 	add	x3, x3, x6
    8a54:	17ffffeb 	b	8a00 <__divti3+0x310>
    8a58:	d1000941 	sub	x1, x10, #0x2
    8a5c:	8b060000 	add	x0, x0, x6
    8a60:	17ffffdc 	b	89d0 <__divti3+0x2e0>
    8a64:	d1000900 	sub	x0, x8, #0x2
    8a68:	8b060063 	add	x3, x3, x6
    8a6c:	17ffffb4 	b	893c <__divti3+0x24c>

0000000000008a70 <__modti3>:
    8a70:	d503245f 	bti	c
    8a74:	d2800004 	mov	x4, #0x0                   	// #0
    8a78:	b6f80081 	tbz	x1, #63, 8a88 <__modti3+0x18>
    8a7c:	eb0003e0 	negs	x0, x0
    8a80:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8a84:	da0103e1 	ngc	x1, x1
    8a88:	f100007f 	cmp	x3, #0x0
    8a8c:	5400128b 	b.lt	8cdc <__modti3+0x26c>  // b.tstop
    8a90:	aa0003e7 	mov	x7, x0
    8a94:	aa0103e6 	mov	x6, x1
    8a98:	540004e1 	b.ne	8b34 <__modti3+0xc4>  // b.any
    8a9c:	eb02003f 	cmp	x1, x2
    8aa0:	54000dc2 	b.cs	8c58 <__modti3+0x1e8>  // b.hs, b.nlast
    8aa4:	dac01043 	clz	x3, x2
    8aa8:	aa0303e5 	mov	x5, x3
    8aac:	b40000e3 	cbz	x3, 8ac8 <__modti3+0x58>
    8ab0:	4b0303e6 	neg	w6, w3
    8ab4:	9ac32021 	lsl	x1, x1, x3
    8ab8:	9ac32042 	lsl	x2, x2, x3
    8abc:	9ac62406 	lsr	x6, x0, x6
    8ac0:	aa0100c6 	orr	x6, x6, x1
    8ac4:	9ac32007 	lsl	x7, x0, x3
    8ac8:	d360fc40 	lsr	x0, x2, #32
    8acc:	92407c43 	and	x3, x2, #0xffffffff
    8ad0:	9ac008c1 	udiv	x1, x6, x0
    8ad4:	9b009826 	msub	x6, x1, x0, x6
    8ad8:	9b017c61 	mul	x1, x3, x1
    8adc:	93c780c6 	extr	x6, x6, x7, #32
    8ae0:	eb06003f 	cmp	x1, x6
    8ae4:	540000a9 	b.ls	8af8 <__modti3+0x88>  // b.plast
    8ae8:	ab060046 	adds	x6, x2, x6
    8aec:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    8af0:	8b0200c8 	add	x8, x6, x2
    8af4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    8af8:	cb0100c6 	sub	x6, x6, x1
    8afc:	9ac008c8 	udiv	x8, x6, x0
    8b00:	9b009901 	msub	x1, x8, x0, x6
    8b04:	aa0703e0 	mov	x0, x7
    8b08:	9b087c63 	mul	x3, x3, x8
    8b0c:	b3607c20 	bfi	x0, x1, #32, #32
    8b10:	eb00007f 	cmp	x3, x0
    8b14:	54001088 	b.hi	8d24 <__modti3+0x2b4>  // b.pmore
    8b18:	cb030000 	sub	x0, x0, x3
    8b1c:	9ac52400 	lsr	x0, x0, x5
    8b20:	d2800001 	mov	x1, #0x0                   	// #0
    8b24:	b4000064 	cbz	x4, 8b30 <__modti3+0xc0>
    8b28:	eb0003e0 	negs	x0, x0
    8b2c:	da0103e1 	ngc	x1, x1
    8b30:	d65f03c0 	ret
    8b34:	dac01066 	clz	x6, x3
    8b38:	eb03003f 	cmp	x1, x3
    8b3c:	54ffff43 	b.cc	8b24 <__modti3+0xb4>  // b.lo, b.ul, b.last
    8b40:	93407cc5 	sxtw	x5, w6
    8b44:	d2800808 	mov	x8, #0x40                  	// #64
    8b48:	cb050108 	sub	x8, x8, x5
    8b4c:	9ac62063 	lsl	x3, x3, x6
    8b50:	9ac62025 	lsl	x5, x1, x6
    8b54:	9ac82447 	lsr	x7, x2, x8
    8b58:	aa0300e7 	orr	x7, x7, x3
    8b5c:	9ac82423 	lsr	x3, x1, x8
    8b60:	92407cec 	and	x12, x7, #0xffffffff
    8b64:	d360fcea 	lsr	x10, x7, #32
    8b68:	9ac82401 	lsr	x1, x0, x8
    8b6c:	aa050021 	orr	x1, x1, x5
    8b70:	9ac62042 	lsl	x2, x2, x6
    8b74:	9ac62000 	lsl	x0, x0, x6
    8b78:	9aca086b 	udiv	x11, x3, x10
    8b7c:	9b0a8d63 	msub	x3, x11, x10, x3
    8b80:	aa0b03e5 	mov	x5, x11
    8b84:	9b0b7d89 	mul	x9, x12, x11
    8b88:	93c18063 	extr	x3, x3, x1, #32
    8b8c:	eb03013f 	cmp	x9, x3
    8b90:	540000a9 	b.ls	8ba4 <__modti3+0x134>  // b.plast
    8b94:	ab0300e3 	adds	x3, x7, x3
    8b98:	d1000565 	sub	x5, x11, #0x1
    8b9c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    8ba0:	54001168 	b.hi	8dcc <__modti3+0x35c>  // b.pmore
    8ba4:	cb090063 	sub	x3, x3, x9
    8ba8:	9aca086b 	udiv	x11, x3, x10
    8bac:	9b0a8d6a 	msub	x10, x11, x10, x3
    8bb0:	aa0b03e9 	mov	x9, x11
    8bb4:	9b0b7d8c 	mul	x12, x12, x11
    8bb8:	b3607d41 	bfi	x1, x10, #32, #32
    8bbc:	eb01019f 	cmp	x12, x1
    8bc0:	540000a9 	b.ls	8bd4 <__modti3+0x164>  // b.plast
    8bc4:	ab0100e1 	adds	x1, x7, x1
    8bc8:	d1000569 	sub	x9, x11, #0x1
    8bcc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    8bd0:	54000f88 	b.hi	8dc0 <__modti3+0x350>  // b.pmore
    8bd4:	aa058123 	orr	x3, x9, x5, lsl #32
    8bd8:	92407c4b 	and	x11, x2, #0xffffffff
    8bdc:	2a0903e9 	mov	w9, w9
    8be0:	d360fc4a 	lsr	x10, x2, #32
    8be4:	d360fc63 	lsr	x3, x3, #32
    8be8:	cb0c0021 	sub	x1, x1, x12
    8bec:	aa0a03ec 	mov	x12, x10
    8bf0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    8bf4:	9b0b7d25 	mul	x5, x9, x11
    8bf8:	9b0b7c6b 	mul	x11, x3, x11
    8bfc:	9b0a2d29 	madd	x9, x9, x10, x11
    8c00:	92407caa 	and	x10, x5, #0xffffffff
    8c04:	9b0c7c63 	mul	x3, x3, x12
    8c08:	8b458125 	add	x5, x9, x5, lsr #32
    8c0c:	8b0d0069 	add	x9, x3, x13
    8c10:	eb05017f 	cmp	x11, x5
    8c14:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    8c18:	8b058149 	add	x9, x10, x5, lsl #32
    8c1c:	8b458063 	add	x3, x3, x5, lsr #32
    8c20:	eb03003f 	cmp	x1, x3
    8c24:	54000063 	b.cc	8c30 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    8c28:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    8c2c:	54000082 	b.cs	8c3c <__modti3+0x1cc>  // b.hs, b.nlast
    8c30:	eb020129 	subs	x9, x9, x2
    8c34:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    8c38:	cb070063 	sub	x3, x3, x7
    8c3c:	eb090000 	subs	x0, x0, x9
    8c40:	da030021 	sbc	x1, x1, x3
    8c44:	9ac62400 	lsr	x0, x0, x6
    8c48:	9ac82028 	lsl	x8, x1, x8
    8c4c:	aa000100 	orr	x0, x8, x0
    8c50:	9ac62421 	lsr	x1, x1, x6
    8c54:	17ffffb4 	b	8b24 <__modti3+0xb4>
    8c58:	b5000062 	cbnz	x2, 8c64 <__modti3+0x1f4>
    8c5c:	d2800023 	mov	x3, #0x1                   	// #1
    8c60:	9ac20862 	udiv	x2, x3, x2
    8c64:	dac01048 	clz	x8, x2
    8c68:	aa0803e5 	mov	x5, x8
    8c6c:	b5000668 	cbnz	x8, 8d38 <__modti3+0x2c8>
    8c70:	cb020020 	sub	x0, x1, x2
    8c74:	d360fc49 	lsr	x9, x2, #32
    8c78:	92407c4a 	and	x10, x2, #0xffffffff
    8c7c:	9ac90801 	udiv	x1, x0, x9
    8c80:	9b098020 	msub	x0, x1, x9, x0
    8c84:	9b0a7c21 	mul	x1, x1, x10
    8c88:	93c78000 	extr	x0, x0, x7, #32
    8c8c:	eb00003f 	cmp	x1, x0
    8c90:	540000a9 	b.ls	8ca4 <__modti3+0x234>  // b.plast
    8c94:	ab000040 	adds	x0, x2, x0
    8c98:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8c9c:	8b020003 	add	x3, x0, x2
    8ca0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8ca4:	cb010001 	sub	x1, x0, x1
    8ca8:	9ac90820 	udiv	x0, x1, x9
    8cac:	9b098403 	msub	x3, x0, x9, x1
    8cb0:	aa0703e1 	mov	x1, x7
    8cb4:	9b0a7c00 	mul	x0, x0, x10
    8cb8:	b3607c61 	bfi	x1, x3, #32, #32
    8cbc:	eb01001f 	cmp	x0, x1
    8cc0:	540000a9 	b.ls	8cd4 <__modti3+0x264>  // b.plast
    8cc4:	ab010041 	adds	x1, x2, x1
    8cc8:	8b020022 	add	x2, x1, x2
    8ccc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    8cd0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    8cd4:	cb000020 	sub	x0, x1, x0
    8cd8:	17ffff91 	b	8b1c <__modti3+0xac>
    8cdc:	eb0203e5 	negs	x5, x2
    8ce0:	aa0003e7 	mov	x7, x0
    8ce4:	da0303e8 	ngc	x8, x3
    8ce8:	aa0503e2 	mov	x2, x5
    8cec:	aa0803e3 	mov	x3, x8
    8cf0:	aa0103e6 	mov	x6, x1
    8cf4:	b4ffed48 	cbz	x8, 8a9c <__modti3+0x2c>
    8cf8:	eb01011f 	cmp	x8, x1
    8cfc:	54fff148 	b.hi	8b24 <__modti3+0xb4>  // b.pmore
    8d00:	dac01109 	clz	x9, x8
    8d04:	2a0903e6 	mov	w6, w9
    8d08:	b5fff1c9 	cbnz	x9, 8b40 <__modti3+0xd0>
    8d0c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    8d10:	54000068 	b.hi	8d1c <__modti3+0x2ac>  // b.pmore
    8d14:	eb050007 	subs	x7, x0, x5
    8d18:	da080021 	sbc	x1, x1, x8
    8d1c:	aa0703e0 	mov	x0, x7
    8d20:	17ffff81 	b	8b24 <__modti3+0xb4>
    8d24:	ab000040 	adds	x0, x2, x0
    8d28:	8b020002 	add	x2, x0, x2
    8d2c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    8d30:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    8d34:	17ffff79 	b	8b18 <__modti3+0xa8>
    8d38:	9ac82042 	lsl	x2, x2, x8
    8d3c:	d2800803 	mov	x3, #0x40                  	// #64
    8d40:	cb080063 	sub	x3, x3, x8
    8d44:	d360fc49 	lsr	x9, x2, #32
    8d48:	9ac82027 	lsl	x7, x1, x8
    8d4c:	92407c4a 	and	x10, x2, #0xffffffff
    8d50:	9ac32426 	lsr	x6, x1, x3
    8d54:	9ac32403 	lsr	x3, x0, x3
    8d58:	aa070063 	orr	x3, x3, x7
    8d5c:	9ac908c1 	udiv	x1, x6, x9
    8d60:	9ac82007 	lsl	x7, x0, x8
    8d64:	9b099820 	msub	x0, x1, x9, x6
    8d68:	9b017d41 	mul	x1, x10, x1
    8d6c:	93c38000 	extr	x0, x0, x3, #32
    8d70:	eb00003f 	cmp	x1, x0
    8d74:	540000a9 	b.ls	8d88 <__modti3+0x318>  // b.plast
    8d78:	ab000040 	adds	x0, x2, x0
    8d7c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8d80:	8b020006 	add	x6, x0, x2
    8d84:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    8d88:	cb010000 	sub	x0, x0, x1
    8d8c:	9ac90801 	udiv	x1, x0, x9
    8d90:	9b098026 	msub	x6, x1, x9, x0
    8d94:	aa0303e0 	mov	x0, x3
    8d98:	9b017d41 	mul	x1, x10, x1
    8d9c:	b3607cc0 	bfi	x0, x6, #32, #32
    8da0:	eb00003f 	cmp	x1, x0
    8da4:	540000a9 	b.ls	8db8 <__modti3+0x348>  // b.plast
    8da8:	ab000040 	adds	x0, x2, x0
    8dac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8db0:	8b020003 	add	x3, x0, x2
    8db4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8db8:	cb010000 	sub	x0, x0, x1
    8dbc:	17ffffb0 	b	8c7c <__modti3+0x20c>
    8dc0:	d1000969 	sub	x9, x11, #0x2
    8dc4:	8b070021 	add	x1, x1, x7
    8dc8:	17ffff83 	b	8bd4 <__modti3+0x164>
    8dcc:	d1000965 	sub	x5, x11, #0x2
    8dd0:	8b070063 	add	x3, x3, x7
    8dd4:	17ffff74 	b	8ba4 <__modti3+0x134>
    8dd8:	d503201f 	nop
    8ddc:	d503201f 	nop

0000000000008de0 <atexit>:
    8de0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    8de4:	900000c2 	adrp	x2, 20000 <__data_start>
    8de8:	d2800001 	mov	x1, #0x0                   	// #0
    8dec:	910003fd 	mov	x29, sp
    8df0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    8df4:	f9400442 	ldr	x2, [x2, #8]
    8df8:	17ffe182 	b	1400 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000008dfc <_fini>:
    8dfc:	d503201f 	nop
    8e00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    8e04:	910003fd 	mov	x29, sp
    8e08:	a8c17bfd 	ldp	x29, x30, [sp], #16
    8e0c:	d65f03c0 	ret
