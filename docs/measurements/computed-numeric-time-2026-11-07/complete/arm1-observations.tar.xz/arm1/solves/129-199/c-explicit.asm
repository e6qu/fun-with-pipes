
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/c-explicit:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000000748 <_init>:
 748:	d503201f 	nop
 74c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
 750:	910003fd 	mov	x29, sp
 754:	940000d8 	bl	ab4 <call_weak_fn>
 758:	a8c17bfd 	ldp	x29, x30, [sp], #16
 75c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000000760 <.plt>:
 760:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
 764:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 768:	f947b611 	ldr	x17, [x16, #3944]
 76c:	913da210 	add	x16, x16, #0xf68
 770:	d61f0220 	br	x17
 774:	d503201f 	nop
 778:	d503201f 	nop
 77c:	d503201f 	nop

0000000000000780 <__libc_start_main@plt>:
 780:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 784:	f947ba11 	ldr	x17, [x16, #3952]
 788:	913dc210 	add	x16, x16, #0xf70
 78c:	d61f0220 	br	x17

0000000000000790 <__cxa_finalize@plt>:
 790:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 794:	f947be11 	ldr	x17, [x16, #3960]
 798:	913de210 	add	x16, x16, #0xf78
 79c:	d61f0220 	br	x17

00000000000007a0 <putc@plt>:
 7a0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 7a4:	f947c211 	ldr	x17, [x16, #3968]
 7a8:	913e0210 	add	x16, x16, #0xf80
 7ac:	d61f0220 	br	x17

00000000000007b0 <malloc@plt>:
 7b0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 7b4:	f947c611 	ldr	x17, [x16, #3976]
 7b8:	913e2210 	add	x16, x16, #0xf88
 7bc:	d61f0220 	br	x17

00000000000007c0 <__printf_chk@plt>:
 7c0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 7c4:	f947ca11 	ldr	x17, [x16, #3984]
 7c8:	913e4210 	add	x16, x16, #0xf90
 7cc:	d61f0220 	br	x17

00000000000007d0 <memset@plt>:
 7d0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 7d4:	f947ce11 	ldr	x17, [x16, #3992]
 7d8:	913e6210 	add	x16, x16, #0xf98
 7dc:	d61f0220 	br	x17

00000000000007e0 <__gmon_start__@plt>:
 7e0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 7e4:	f947d211 	ldr	x17, [x16, #4000]
 7e8:	913e8210 	add	x16, x16, #0xfa0
 7ec:	d61f0220 	br	x17

00000000000007f0 <abort@plt>:
 7f0:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 7f4:	f947d611 	ldr	x17, [x16, #4008]
 7f8:	913ea210 	add	x16, x16, #0xfa8
 7fc:	d61f0220 	br	x17

0000000000000800 <puts@plt>:
 800:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 804:	f947da11 	ldr	x17, [x16, #4016]
 808:	913ec210 	add	x16, x16, #0xfb0
 80c:	d61f0220 	br	x17

0000000000000810 <free@plt>:
 810:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 814:	f947de11 	ldr	x17, [x16, #4024]
 818:	913ee210 	add	x16, x16, #0xfb8
 81c:	d61f0220 	br	x17

0000000000000820 <ferror@plt>:
 820:	f00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x1e30c>
 824:	f947e211 	ldr	x17, [x16, #4032]
 828:	913f0210 	add	x16, x16, #0xfc0
 82c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000000840 <main>:
 840:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
 844:	d2f80f20 	mov	x0, #0xc079000000000000    	// #-4577627546245398528
 848:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
 84c:	910003fd 	mov	x29, sp
 850:	6d052fea 	stp	d10, d11, [sp, #80]
 854:	9e67000a 	fmov	d10, x0
 858:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
 85c:	6d0427e8 	stp	d8, d9, [sp, #64]
 860:	9e670009 	fmov	d9, x0
 864:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 868:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
 86c:	9e670028 	fmov	d8, x1
 870:	fd45e80b 	ldr	d11, [x0, #3024]
 874:	a90153f3 	stp	x19, x20, [sp, #16]
 878:	a9025bf5 	stp	x21, x22, [sp, #32]
 87c:	d2800116 	mov	x22, #0x8                   	// #8
 880:	a90363f7 	stp	x23, x24, [sp, #48]
 884:	d2808100 	mov	x0, #0x408                 	// #1032
 888:	97ffffca 	bl	7b0 <malloc@plt>
 88c:	aa0003f4 	mov	x20, x0
 890:	d2808100 	mov	x0, #0x408                 	// #1032
 894:	97ffffc7 	bl	7b0 <malloc@plt>
 898:	f100029f 	cmp	x20, #0x0
 89c:	aa0003f5 	mov	x21, x0
 8a0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
 8a4:	54000d20 	b.eq	a48 <main+0x208>  // b.none
 8a8:	d2800000 	mov	x0, #0x0                   	// #0
 8ac:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
 8b0:	f240001f 	tst	x0, #0x1
 8b4:	1e610d00 	fcsel	d0, d8, d1, eq	// eq = none
 8b8:	fc207a80 	str	d0, [x20, x0, lsl #3]
 8bc:	91000400 	add	x0, x0, #0x1
 8c0:	f102041f 	cmp	x0, #0x81
 8c4:	54ffff61 	b.ne	8b0 <main+0x70>  // b.any
 8c8:	d10022b7 	sub	x23, x21, #0x8
 8cc:	d28018f3 	mov	x19, #0xc7                  	// #199
 8d0:	aa1503e0 	mov	x0, x21
 8d4:	d2808102 	mov	x2, #0x408                 	// #1032
 8d8:	52800001 	mov	w1, #0x0                   	// #0
 8dc:	97ffffbd 	bl	7d0 <memset@plt>
 8e0:	2f00e400 	movi	d0, #0x0
 8e4:	fd400281 	ldr	d1, [x20]
 8e8:	d2800100 	mov	x0, #0x8                   	// #8
 8ec:	1e6e1002 	fmov	d2, #1.000000000000000000e+00
 8f0:	1e604023 	fmov	d3, d1
 8f4:	fc606a81 	ldr	d1, [x20, x0]
 8f8:	1e630865 	fmul	d5, d3, d3
 8fc:	1e6a0864 	fmul	d4, d3, d10
 900:	1e633843 	fsub	d3, d2, d3
 904:	1e653825 	fsub	d5, d1, d5
 908:	1e632863 	fadd	d3, d3, d3
 90c:	1e650884 	fmul	d4, d4, d5
 910:	1e6908a5 	fmul	d5, d5, d9
 914:	1e633883 	fsub	d3, d4, d3
 918:	1e602860 	fadd	d0, d3, d0
 91c:	fc206ae0 	str	d0, [x23, x0]
 920:	fc606aa0 	ldr	d0, [x21, x0]
 924:	1e6028a0 	fadd	d0, d5, d0
 928:	fc206aa0 	str	d0, [x21, x0]
 92c:	91002000 	add	x0, x0, #0x8
 930:	f110201f 	cmp	x0, #0x408
 934:	54fffde1 	b.ne	8f0 <main+0xb0>  // b.any
 938:	d2800000 	mov	x0, #0x0                   	// #0
 93c:	d503201f 	nop
 940:	fc607aa1 	ldr	d1, [x21, x0, lsl #3]
 944:	fc607a80 	ldr	d0, [x20, x0, lsl #3]
 948:	1e6b0821 	fmul	d1, d1, d11
 94c:	1e613800 	fsub	d0, d0, d1
 950:	fc207a80 	str	d0, [x20, x0, lsl #3]
 954:	91000400 	add	x0, x0, #0x1
 958:	f102041f 	cmp	x0, #0x81
 95c:	54ffff21 	b.ne	940 <main+0x100>  // b.any
 960:	f1000673 	subs	x19, x19, #0x1
 964:	54fffb61 	b.ne	8d0 <main+0x90>  // b.any
 968:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
 96c:	9e670000 	fmov	d0, x0
 970:	fc737a81 	ldr	d1, [x20, x19, lsl #3]
 974:	1e60c021 	fabs	d1, d1
 978:	1e602020 	fcmp	d1, d0
 97c:	540004a8 	b.hi	a10 <main+0x1d0>  // b.pmore
 980:	91000673 	add	x19, x19, #0x1
 984:	f102067f 	cmp	x19, #0x81
 988:	54ffff41 	b.ne	970 <main+0x130>  // b.any
 98c:	f00000f7 	adrp	x23, 1f000 <__FRAME_END__+0x1e30c>
 990:	f947f2f7 	ldr	x23, [x23, #4064]
 994:	52800b60 	mov	w0, #0x5b                  	// #91
 998:	d2800033 	mov	x19, #0x1                   	// #1
 99c:	f94002e1 	ldr	x1, [x23]
 9a0:	97ffff80 	bl	7a0 <putc@plt>
 9a4:	fd400280 	ldr	d0, [x20]
 9a8:	90000001 	adrp	x1, 0 <__abi_tag-0x278>
 9ac:	52800040 	mov	w0, #0x2                   	// #2
 9b0:	912ee021 	add	x1, x1, #0xbb8
 9b4:	97ffff83 	bl	7c0 <__printf_chk@plt>
 9b8:	90000001 	adrp	x1, 0 <__abi_tag-0x278>
 9bc:	912f0038 	add	x24, x1, #0xbc0
 9c0:	fc737a80 	ldr	d0, [x20, x19, lsl #3]
 9c4:	aa1803e1 	mov	x1, x24
 9c8:	52800040 	mov	w0, #0x2                   	// #2
 9cc:	91000673 	add	x19, x19, #0x1
 9d0:	97ffff7c 	bl	7c0 <__printf_chk@plt>
 9d4:	f102067f 	cmp	x19, #0x81
 9d8:	54ffff41 	b.ne	9c0 <main+0x180>  // b.any
 9dc:	90000000 	adrp	x0, 0 <__abi_tag-0x278>
 9e0:	912f2000 	add	x0, x0, #0xbc8
 9e4:	97ffff87 	bl	800 <puts@plt>
 9e8:	aa1403e0 	mov	x0, x20
 9ec:	97ffff89 	bl	810 <free@plt>
 9f0:	aa1503e0 	mov	x0, x21
 9f4:	97ffff87 	bl	810 <free@plt>
 9f8:	f94002e0 	ldr	x0, [x23]
 9fc:	97ffff89 	bl	820 <ferror@plt>
 a00:	35000200 	cbnz	w0, a40 <main+0x200>
 a04:	f10006d6 	subs	x22, x22, #0x1
 a08:	54fff3e1 	b.ne	884 <main+0x44>  // b.any
 a0c:	14000006 	b	a24 <main+0x1e4>
 a10:	aa1403e0 	mov	x0, x20
 a14:	97ffff7f 	bl	810 <free@plt>
 a18:	aa1503e0 	mov	x0, x21
 a1c:	97ffff7d 	bl	810 <free@plt>
 a20:	52800060 	mov	w0, #0x3                   	// #3
 a24:	a94153f3 	ldp	x19, x20, [sp, #16]
 a28:	a9425bf5 	ldp	x21, x22, [sp, #32]
 a2c:	a94363f7 	ldp	x23, x24, [sp, #48]
 a30:	6d4427e8 	ldp	d8, d9, [sp, #64]
 a34:	6d452fea 	ldp	d10, d11, [sp, #80]
 a38:	a8c67bfd 	ldp	x29, x30, [sp], #96
 a3c:	d65f03c0 	ret
 a40:	52800080 	mov	w0, #0x4                   	// #4
 a44:	17fffff8 	b	a24 <main+0x1e4>
 a48:	aa1403e0 	mov	x0, x20
 a4c:	97ffff71 	bl	810 <free@plt>
 a50:	aa1503e0 	mov	x0, x21
 a54:	97ffff6f 	bl	810 <free@plt>
 a58:	52800040 	mov	w0, #0x2                   	// #2
 a5c:	17fffff2 	b	a24 <main+0x1e4>
 a60:	d503201f 	nop
 a64:	d503201f 	nop
 a68:	d503201f 	nop
 a6c:	d503201f 	nop
 a70:	d503201f 	nop
 a74:	d503201f 	nop
 a78:	d503201f 	nop
 a7c:	d503201f 	nop

0000000000000a80 <_start>:
 a80:	d503201f 	nop
 a84:	d280001d 	mov	x29, #0x0                   	// #0
 a88:	d280001e 	mov	x30, #0x0                   	// #0
 a8c:	aa0003e5 	mov	x5, x0
 a90:	f94003e1 	ldr	x1, [sp]
 a94:	910023e2 	add	x2, sp, #0x8
 a98:	910003e6 	mov	x6, sp
 a9c:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e30c>
 aa0:	f947f800 	ldr	x0, [x0, #4080]
 aa4:	d2800003 	mov	x3, #0x0                   	// #0
 aa8:	d2800004 	mov	x4, #0x0                   	// #0
 aac:	97ffff35 	bl	780 <__libc_start_main@plt>
 ab0:	97ffff50 	bl	7f0 <abort@plt>

0000000000000ab4 <call_weak_fn>:
 ab4:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e30c>
 ab8:	f947f400 	ldr	x0, [x0, #4072]
 abc:	b4000040 	cbz	x0, ac4 <call_weak_fn+0x10>
 ac0:	17ffff48 	b	7e0 <__gmon_start__@plt>
 ac4:	d65f03c0 	ret
 ac8:	d503201f 	nop
 acc:	d503201f 	nop

0000000000000ad0 <deregister_tm_clones>:
 ad0:	90000100 	adrp	x0, 20000 <__data_start>
 ad4:	91004000 	add	x0, x0, #0x10
 ad8:	90000101 	adrp	x1, 20000 <__data_start>
 adc:	91004021 	add	x1, x1, #0x10
 ae0:	eb00003f 	cmp	x1, x0
 ae4:	540000c0 	b.eq	afc <deregister_tm_clones+0x2c>  // b.none
 ae8:	f00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x1e30c>
 aec:	f947e821 	ldr	x1, [x1, #4048]
 af0:	b4000061 	cbz	x1, afc <deregister_tm_clones+0x2c>
 af4:	aa0103f0 	mov	x16, x1
 af8:	d61f0200 	br	x16
 afc:	d65f03c0 	ret

0000000000000b00 <register_tm_clones>:
 b00:	90000100 	adrp	x0, 20000 <__data_start>
 b04:	91004000 	add	x0, x0, #0x10
 b08:	90000101 	adrp	x1, 20000 <__data_start>
 b0c:	91004021 	add	x1, x1, #0x10
 b10:	cb000021 	sub	x1, x1, x0
 b14:	d37ffc22 	lsr	x2, x1, #63
 b18:	8b810c41 	add	x1, x2, x1, asr #3
 b1c:	9341fc21 	asr	x1, x1, #1
 b20:	b40000c1 	cbz	x1, b38 <register_tm_clones+0x38>
 b24:	f00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x1e30c>
 b28:	f947fc42 	ldr	x2, [x2, #4088]
 b2c:	b4000062 	cbz	x2, b38 <register_tm_clones+0x38>
 b30:	aa0203f0 	mov	x16, x2
 b34:	d61f0200 	br	x16
 b38:	d65f03c0 	ret
 b3c:	d503201f 	nop

0000000000000b40 <__do_global_dtors_aux>:
 b40:	d503233f 	paciasp
 b44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
 b48:	910003fd 	mov	x29, sp
 b4c:	f9000bf3 	str	x19, [sp, #16]
 b50:	90000113 	adrp	x19, 20000 <__data_start>
 b54:	39404260 	ldrb	w0, [x19, #16]
 b58:	37000140 	tbnz	w0, #0, b80 <__do_global_dtors_aux+0x40>
 b5c:	f00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x1e30c>
 b60:	f947ec00 	ldr	x0, [x0, #4056]
 b64:	b4000080 	cbz	x0, b74 <__do_global_dtors_aux+0x34>
 b68:	90000100 	adrp	x0, 20000 <__data_start>
 b6c:	f9400400 	ldr	x0, [x0, #8]
 b70:	97ffff08 	bl	790 <__cxa_finalize@plt>
 b74:	97ffffd7 	bl	ad0 <deregister_tm_clones>
 b78:	52800020 	mov	w0, #0x1                   	// #1
 b7c:	39004260 	strb	w0, [x19, #16]
 b80:	f9400bf3 	ldr	x19, [sp, #16]
 b84:	a8c27bfd 	ldp	x29, x30, [sp], #32
 b88:	d50323bf 	autiasp
 b8c:	d65f03c0 	ret

0000000000000b90 <frame_dummy>:
 b90:	d503245f 	bti	c
 b94:	17ffffdb 	b	b00 <register_tm_clones>

Disassembly of section .fini:

0000000000000b98 <_fini>:
 b98:	d503201f 	nop
 b9c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
 ba0:	910003fd 	mov	x29, sp
 ba4:	a8c17bfd 	ldp	x29, x30, [sp], #16
 ba8:	d65f03c0 	ret
