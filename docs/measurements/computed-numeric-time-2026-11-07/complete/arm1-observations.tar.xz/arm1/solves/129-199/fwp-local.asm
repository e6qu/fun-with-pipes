
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-local:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000012c8 <_init>:
    12c8:	d503201f 	nop
    12cc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    12d0:	910003fd 	mov	x29, sp
    12d4:	94000188 	bl	18f4 <call_weak_fn>
    12d8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    12dc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000012e0 <.plt>:
    12e0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    12e4:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    12e8:	f946fe11 	ldr	x17, [x16, #3576]
    12ec:	9137e210 	add	x16, x16, #0xdf8
    12f0:	d61f0220 	br	x17
    12f4:	d503201f 	nop
    12f8:	d503201f 	nop
    12fc:	d503201f 	nop

0000000000001300 <memcpy@plt>:
    1300:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1304:	f9470211 	ldr	x17, [x16, #3584]
    1308:	91380210 	add	x16, x16, #0xe00
    130c:	d61f0220 	br	x17

0000000000001310 <sigaltstack@plt>:
    1310:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1314:	f9470611 	ldr	x17, [x16, #3592]
    1318:	91382210 	add	x16, x16, #0xe08
    131c:	d61f0220 	br	x17

0000000000001320 <_exit@plt>:
    1320:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1324:	f9470a11 	ldr	x17, [x16, #3600]
    1328:	91384210 	add	x16, x16, #0xe10
    132c:	d61f0220 	br	x17

0000000000001330 <strlen@plt>:
    1330:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1334:	f9470e11 	ldr	x17, [x16, #3608]
    1338:	91386210 	add	x16, x16, #0xe18
    133c:	d61f0220 	br	x17

0000000000001340 <__sprintf_chk@plt>:
    1340:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1344:	f9471211 	ldr	x17, [x16, #3616]
    1348:	91388210 	add	x16, x16, #0xe20
    134c:	d61f0220 	br	x17

0000000000001350 <exit@plt>:
    1350:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1354:	f9471611 	ldr	x17, [x16, #3624]
    1358:	9138a210 	add	x16, x16, #0xe28
    135c:	d61f0220 	br	x17

0000000000001360 <__libc_start_main@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1364:	f9471a11 	ldr	x17, [x16, #3632]
    1368:	9138c210 	add	x16, x16, #0xe30
    136c:	d61f0220 	br	x17

0000000000001370 <strtoll@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1374:	f9471e11 	ldr	x17, [x16, #3640]
    1378:	9138e210 	add	x16, x16, #0xe38
    137c:	d61f0220 	br	x17

0000000000001380 <strtod@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1384:	f9472211 	ldr	x17, [x16, #3648]
    1388:	91390210 	add	x16, x16, #0xe40
    138c:	d61f0220 	br	x17

0000000000001390 <__cxa_finalize@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1394:	f9472611 	ldr	x17, [x16, #3656]
    1398:	91392210 	add	x16, x16, #0xe48
    139c:	d61f0220 	br	x17

00000000000013a0 <__cxa_atexit@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    13a4:	f9472a11 	ldr	x17, [x16, #3664]
    13a8:	91394210 	add	x16, x16, #0xe50
    13ac:	d61f0220 	br	x17

00000000000013b0 <pthread_attr_init@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    13b4:	f9472e11 	ldr	x17, [x16, #3672]
    13b8:	91396210 	add	x16, x16, #0xe58
    13bc:	d61f0220 	br	x17

00000000000013c0 <fputc@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    13c4:	f9473211 	ldr	x17, [x16, #3680]
    13c8:	91398210 	add	x16, x16, #0xe60
    13cc:	d61f0220 	br	x17

00000000000013d0 <clock_gettime@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    13d4:	f9473611 	ldr	x17, [x16, #3688]
    13d8:	9139a210 	add	x16, x16, #0xe68
    13dc:	d61f0220 	br	x17

00000000000013e0 <setvbuf@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    13e4:	f9473a11 	ldr	x17, [x16, #3696]
    13e8:	9139c210 	add	x16, x16, #0xe70
    13ec:	d61f0220 	br	x17

00000000000013f0 <__memcpy_chk@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    13f4:	f9473e11 	ldr	x17, [x16, #3704]
    13f8:	9139e210 	add	x16, x16, #0xe78
    13fc:	d61f0220 	br	x17

0000000000001400 <signal@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1404:	f9474211 	ldr	x17, [x16, #3712]
    1408:	913a0210 	add	x16, x16, #0xe80
    140c:	d61f0220 	br	x17

0000000000001410 <__snprintf_chk@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1414:	f9474611 	ldr	x17, [x16, #3720]
    1418:	913a2210 	add	x16, x16, #0xe88
    141c:	d61f0220 	br	x17

0000000000001420 <fclose@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1424:	f9474a11 	ldr	x17, [x16, #3728]
    1428:	913a4210 	add	x16, x16, #0xe90
    142c:	d61f0220 	br	x17

0000000000001430 <fopen@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1434:	f9474e11 	ldr	x17, [x16, #3736]
    1438:	913a6210 	add	x16, x16, #0xe98
    143c:	d61f0220 	br	x17

0000000000001440 <malloc@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1444:	f9475211 	ldr	x17, [x16, #3744]
    1448:	913a8210 	add	x16, x16, #0xea0
    144c:	d61f0220 	br	x17

0000000000001450 <pthread_attr_destroy@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1454:	f9475611 	ldr	x17, [x16, #3752]
    1458:	913aa210 	add	x16, x16, #0xea8
    145c:	d61f0220 	br	x17

0000000000001460 <sigemptyset@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1464:	f9475a11 	ldr	x17, [x16, #3760]
    1468:	913ac210 	add	x16, x16, #0xeb0
    146c:	d61f0220 	br	x17

0000000000001470 <memset@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1474:	f9475e11 	ldr	x17, [x16, #3768]
    1478:	913ae210 	add	x16, x16, #0xeb8
    147c:	d61f0220 	br	x17

0000000000001480 <calloc@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1484:	f9476211 	ldr	x17, [x16, #3776]
    1488:	913b0210 	add	x16, x16, #0xec0
    148c:	d61f0220 	br	x17

0000000000001490 <realloc@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1494:	f9476611 	ldr	x17, [x16, #3784]
    1498:	913b2210 	add	x16, x16, #0xec8
    149c:	d61f0220 	br	x17

00000000000014a0 <__stack_chk_fail@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    14a4:	f9476a11 	ldr	x17, [x16, #3792]
    14a8:	913b4210 	add	x16, x16, #0xed0
    14ac:	d61f0220 	br	x17

00000000000014b0 <close@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    14b4:	f9476e11 	ldr	x17, [x16, #3800]
    14b8:	913b6210 	add	x16, x16, #0xed8
    14bc:	d61f0220 	br	x17

00000000000014c0 <sigaction@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    14c4:	f9477211 	ldr	x17, [x16, #3808]
    14c8:	913b8210 	add	x16, x16, #0xee0
    14cc:	d61f0220 	br	x17

00000000000014d0 <__gmon_start__@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    14d4:	f9477611 	ldr	x17, [x16, #3816]
    14d8:	913ba210 	add	x16, x16, #0xee8
    14dc:	d61f0220 	br	x17

00000000000014e0 <write@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    14e4:	f9477a11 	ldr	x17, [x16, #3824]
    14e8:	913bc210 	add	x16, x16, #0xef0
    14ec:	d61f0220 	br	x17

00000000000014f0 <abort@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    14f4:	f9477e11 	ldr	x17, [x16, #3832]
    14f8:	913be210 	add	x16, x16, #0xef8
    14fc:	d61f0220 	br	x17

0000000000001500 <swapcontext@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1504:	f9478211 	ldr	x17, [x16, #3840]
    1508:	913c0210 	add	x16, x16, #0xf00
    150c:	d61f0220 	br	x17

0000000000001510 <__fprintf_chk@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1514:	f9478611 	ldr	x17, [x16, #3848]
    1518:	913c2210 	add	x16, x16, #0xf08
    151c:	d61f0220 	br	x17

0000000000001520 <strcmp@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1524:	f9478a11 	ldr	x17, [x16, #3856]
    1528:	913c4210 	add	x16, x16, #0xf10
    152c:	d61f0220 	br	x17

0000000000001530 <mmap@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1534:	f9478e11 	ldr	x17, [x16, #3864]
    1538:	913c6210 	add	x16, x16, #0xf18
    153c:	d61f0220 	br	x17

0000000000001540 <strtol@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1544:	f9479211 	ldr	x17, [x16, #3872]
    1548:	913c8210 	add	x16, x16, #0xf20
    154c:	d61f0220 	br	x17

0000000000001550 <strtof@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1554:	f9479611 	ldr	x17, [x16, #3880]
    1558:	913ca210 	add	x16, x16, #0xf28
    155c:	d61f0220 	br	x17

0000000000001560 <free@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1564:	f9479a11 	ldr	x17, [x16, #3888]
    1568:	913cc210 	add	x16, x16, #0xf30
    156c:	d61f0220 	br	x17

0000000000001570 <nanosleep@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1574:	f9479e11 	ldr	x17, [x16, #3896]
    1578:	913ce210 	add	x16, x16, #0xf38
    157c:	d61f0220 	br	x17

0000000000001580 <strchr@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1584:	f947a211 	ldr	x17, [x16, #3904]
    1588:	913d0210 	add	x16, x16, #0xf40
    158c:	d61f0220 	br	x17

0000000000001590 <strtoull@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1594:	f947a611 	ldr	x17, [x16, #3912]
    1598:	913d2210 	add	x16, x16, #0xf48
    159c:	d61f0220 	br	x17

00000000000015a0 <fwrite@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    15a4:	f947aa11 	ldr	x17, [x16, #3920]
    15a8:	913d4210 	add	x16, x16, #0xf50
    15ac:	d61f0220 	br	x17

00000000000015b0 <pthread_create@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    15b4:	f947ae11 	ldr	x17, [x16, #3928]
    15b8:	913d6210 	add	x16, x16, #0xf58
    15bc:	d61f0220 	br	x17

00000000000015c0 <munmap@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    15c4:	f947b211 	ldr	x17, [x16, #3936]
    15c8:	913d8210 	add	x16, x16, #0xf60
    15cc:	d61f0220 	br	x17

00000000000015d0 <fflush@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    15d4:	f947b611 	ldr	x17, [x16, #3944]
    15d8:	913da210 	add	x16, x16, #0xf68
    15dc:	d61f0220 	br	x17

00000000000015e0 <strcpy@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    15e4:	f947ba11 	ldr	x17, [x16, #3952]
    15e8:	913dc210 	add	x16, x16, #0xf70
    15ec:	d61f0220 	br	x17

00000000000015f0 <sysconf@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    15f4:	f947be11 	ldr	x17, [x16, #3960]
    15f8:	913de210 	add	x16, x16, #0xf78
    15fc:	d61f0220 	br	x17

0000000000001600 <strstr@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1604:	f947c211 	ldr	x17, [x16, #3968]
    1608:	913e0210 	add	x16, x16, #0xf80
    160c:	d61f0220 	br	x17

0000000000001610 <_Exit@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1614:	f947c611 	ldr	x17, [x16, #3976]
    1618:	913e2210 	add	x16, x16, #0xf88
    161c:	d61f0220 	br	x17

0000000000001620 <pthread_join@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1624:	f947ca11 	ldr	x17, [x16, #3984]
    1628:	913e4210 	add	x16, x16, #0xf90
    162c:	d61f0220 	br	x17

0000000000001630 <getenv@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1634:	f947ce11 	ldr	x17, [x16, #3992]
    1638:	913e6210 	add	x16, x16, #0xf98
    163c:	d61f0220 	br	x17

0000000000001640 <mprotect@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1644:	f947d211 	ldr	x17, [x16, #4000]
    1648:	913e8210 	add	x16, x16, #0xfa0
    164c:	d61f0220 	br	x17

0000000000001650 <fgets@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1654:	f947d611 	ldr	x17, [x16, #4008]
    1658:	913ea210 	add	x16, x16, #0xfa8
    165c:	d61f0220 	br	x17

0000000000001660 <pthread_attr_setstacksize@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x152b8>
    1664:	f947da11 	ldr	x17, [x16, #4016]
    1668:	913ec210 	add	x16, x16, #0xfb0
    166c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001680 <fwp_trap_overflow.constprop.0>:
    1680:	d10243ff 	sub	sp, sp, #0x90
    1684:	d2800c03 	mov	x3, #0x60                  	// #96
    1688:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152b8>
    168c:	f947f421 	ldr	x1, [x1, #4072]
    1690:	f0000025 	adrp	x5, 8000 <fwp_main_thread+0x170>
    1694:	a9077bfd 	stp	x29, x30, [sp, #112]
    1698:	9101c3fd 	add	x29, sp, #0x70
    169c:	913140a5 	add	x5, x5, #0xc50
    16a0:	f0000024 	adrp	x4, 8000 <fwp_main_thread+0x170>
    16a4:	f90043f3 	str	x19, [sp, #128]
    16a8:	91316084 	add	x4, x4, #0xc58
    16ac:	910023f3 	add	x19, sp, #0x8
    16b0:	f9400022 	ldr	x2, [x1]
    16b4:	f90037e2 	str	x2, [sp, #104]
    16b8:	d2800002 	mov	x2, #0x0                   	// #0
    16bc:	aa0303e1 	mov	x1, x3
    16c0:	52800042 	mov	w2, #0x2                   	// #2
    16c4:	aa1303e0 	mov	x0, x19
    16c8:	97ffff52 	bl	1410 <__snprintf_chk@plt>
    16cc:	aa1303e0 	mov	x0, x19
    16d0:	94000274 	bl	20a0 <fwp_trap>
    16d4:	d503201f 	nop
    16d8:	d503201f 	nop
    16dc:	d503201f 	nop

00000000000016e0 <main>:
    16e0:	d10243ff 	sub	sp, sp, #0x90
    16e4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    16e8:	f947f400 	ldr	x0, [x0, #4072]
    16ec:	a9067bfd 	stp	x29, x30, [sp, #96]
    16f0:	910183fd 	add	x29, sp, #0x60
    16f4:	a90753f3 	stp	x19, x20, [sp, #112]
    16f8:	f00000f3 	adrp	x19, 20000 <__data_start>
    16fc:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x152b8>
    1700:	f947ee94 	ldr	x20, [x20, #4056]
    1704:	f9400281 	ldr	x1, [x20]
    1708:	f90043f5 	str	x21, [sp, #128]
    170c:	f9400002 	ldr	x2, [x0]
    1710:	f9002fe2 	str	x2, [sp, #88]
    1714:	d2800002 	mov	x2, #0x0                   	// #0
    1718:	f9003a61 	str	x1, [x19, #112]
    171c:	94000271 	bl	20e0 <fwp_now_ns>
    1720:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    1724:	913a8000 	add	x0, x0, #0xea0
    1728:	97ffffc2 	bl	1630 <getenv@plt>
    172c:	b4000080 	cbz	x0, 173c <main+0x5c>
    1730:	39400001 	ldrb	w1, [x0]
    1734:	aa0003f5 	mov	x21, x0
    1738:	35000801 	cbnz	w1, 1838 <main+0x158>
    173c:	910023e1 	add	x1, sp, #0x8
    1740:	52800000 	mov	w0, #0x0                   	// #0
    1744:	97ffff23 	bl	13d0 <clock_gettime@plt>
    1748:	35000900 	cbnz	w0, 1868 <main+0x188>
    174c:	a9408be0 	ldp	x0, x2, [sp, #8]
    1750:	d2994003 	mov	x3, #0xca00                	// #51712
    1754:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    1758:	9b037c01 	mul	x1, x0, x3
    175c:	9b437c00 	smulh	x0, x0, x3
    1760:	ab020021 	adds	x1, x1, x2
    1764:	937ffc42 	asr	x2, x2, #63
    1768:	9a020000 	adc	x0, x0, x2
    176c:	f100003f 	cmp	x1, #0x0
    1770:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    1774:	b50009a0 	cbnz	x0, 18a8 <main+0x1c8>
    1778:	f9400280 	ldr	x0, [x20]
    177c:	d2a00023 	mov	x3, #0x10000               	// #65536
    1780:	52800002 	mov	w2, #0x0                   	// #0
    1784:	d2800001 	mov	x1, #0x0                   	// #0
    1788:	910063f5 	add	x21, sp, #0x18
    178c:	97ffff15 	bl	13e0 <setvbuf@plt>
    1790:	d2800021 	mov	x1, #0x1                   	// #1
    1794:	528001a0 	mov	w0, #0xd                   	// #13
    1798:	97ffff1a 	bl	1400 <signal@plt>
    179c:	aa1503e0 	mov	x0, x21
    17a0:	97ffff04 	bl	13b0 <pthread_attr_init@plt>
    17a4:	350007c0 	cbnz	w0, 189c <main+0x1bc>
    17a8:	aa1503e0 	mov	x0, x21
    17ac:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    17b0:	97ffffac 	bl	1660 <pthread_attr_setstacksize@plt>
    17b4:	35000680 	cbnz	w0, 1884 <main+0x1a4>
    17b8:	aa1503e1 	mov	x1, x21
    17bc:	910023e0 	add	x0, sp, #0x8
    17c0:	d0000022 	adrp	x2, 7000 <f0+0x15f0>
    17c4:	d2800003 	mov	x3, #0x0                   	// #0
    17c8:	913a4042 	add	x2, x2, #0xe90
    17cc:	97ffff79 	bl	15b0 <pthread_create@plt>
    17d0:	2a0003e1 	mov	w1, w0
    17d4:	aa1503e0 	mov	x0, x21
    17d8:	2a0103f5 	mov	w21, w1
    17dc:	97ffff1d 	bl	1450 <pthread_attr_destroy@plt>
    17e0:	350006a0 	cbnz	w0, 18b4 <main+0x1d4>
    17e4:	350004b5 	cbnz	w21, 1878 <main+0x198>
    17e8:	f94007e0 	ldr	x0, [sp, #8]
    17ec:	d2800001 	mov	x1, #0x0                   	// #0
    17f0:	97ffff8c 	bl	1620 <pthread_join@plt>
    17f4:	35000600 	cbnz	w0, 18b4 <main+0x1d4>
    17f8:	f9400280 	ldr	x0, [x20]
    17fc:	9101c273 	add	x19, x19, #0x70
    1800:	97ffff74 	bl	15d0 <fflush@plt>
    1804:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152b8>
    1808:	f947f421 	ldr	x1, [x1, #4072]
    180c:	b942a260 	ldr	w0, [x19, #672]
    1810:	f9402fe3 	ldr	x3, [sp, #88]
    1814:	f9400022 	ldr	x2, [x1]
    1818:	eb020063 	subs	x3, x3, x2
    181c:	d2800002 	mov	x2, #0x0                   	// #0
    1820:	540002a1 	b.ne	1874 <main+0x194>  // b.any
    1824:	a9467bfd 	ldp	x29, x30, [sp, #96]
    1828:	a94753f3 	ldp	x19, x20, [sp, #112]
    182c:	f94043f5 	ldr	x21, [sp, #128]
    1830:	910243ff 	add	sp, sp, #0x90
    1834:	d65f03c0 	ret
    1838:	910003e1 	mov	x1, sp
    183c:	52800142 	mov	w2, #0xa                   	// #10
    1840:	97ffff54 	bl	1590 <strtoull@plt>
    1844:	f94003e0 	ldr	x0, [sp]
    1848:	39400000 	ldrb	w0, [x0]
    184c:	35fff780 	cbnz	w0, 173c <main+0x5c>
    1850:	394002a0 	ldrb	w0, [x21]
    1854:	52801fa1 	mov	w1, #0xfd                  	// #253
    1858:	5100ac00 	sub	w0, w0, #0x2b
    185c:	6a01001f 	tst	w0, w1
    1860:	54fff6e0 	b.eq	173c <main+0x5c>  // b.none
    1864:	17ffffc5 	b	1778 <main+0x98>
    1868:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    186c:	913ac000 	add	x0, x0, #0xeb0
    1870:	9400020c 	bl	20a0 <fwp_trap>
    1874:	97ffff0b 	bl	14a0 <__stack_chk_fail@plt>
    1878:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    187c:	913d4000 	add	x0, x0, #0xf50
    1880:	94000208 	bl	20a0 <fwp_trap>
    1884:	aa1503e0 	mov	x0, x21
    1888:	97fffef2 	bl	1450 <pthread_attr_destroy@plt>
    188c:	35000140 	cbnz	w0, 18b4 <main+0x1d4>
    1890:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    1894:	913ca000 	add	x0, x0, #0xf28
    1898:	94000202 	bl	20a0 <fwp_trap>
    189c:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    18a0:	913be000 	add	x0, x0, #0xef8
    18a4:	940001ff 	bl	20a0 <fwp_trap>
    18a8:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    18ac:	913b4000 	add	x0, x0, #0xed0
    18b0:	940001fc 	bl	20a0 <fwp_trap>
    18b4:	97ffff0f 	bl	14f0 <abort@plt>
    18b8:	d503201f 	nop
    18bc:	d503201f 	nop

00000000000018c0 <_start>:
    18c0:	d503201f 	nop
    18c4:	d280001d 	mov	x29, #0x0                   	// #0
    18c8:	d280001e 	mov	x30, #0x0                   	// #0
    18cc:	aa0003e5 	mov	x5, x0
    18d0:	f94003e1 	ldr	x1, [sp]
    18d4:	910023e2 	add	x2, sp, #0x8
    18d8:	910003e6 	mov	x6, sp
    18dc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    18e0:	f947f800 	ldr	x0, [x0, #4080]
    18e4:	d2800003 	mov	x3, #0x0                   	// #0
    18e8:	d2800004 	mov	x4, #0x0                   	// #0
    18ec:	97fffe9d 	bl	1360 <__libc_start_main@plt>
    18f0:	97ffff00 	bl	14f0 <abort@plt>

00000000000018f4 <call_weak_fn>:
    18f4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    18f8:	f947f000 	ldr	x0, [x0, #4064]
    18fc:	b4000040 	cbz	x0, 1904 <call_weak_fn+0x10>
    1900:	17fffef4 	b	14d0 <__gmon_start__@plt>
    1904:	d65f03c0 	ret
    1908:	d503201f 	nop
    190c:	d503201f 	nop

0000000000001910 <deregister_tm_clones>:
    1910:	f00000e0 	adrp	x0, 20000 <__data_start>
    1914:	91016000 	add	x0, x0, #0x58
    1918:	f00000e1 	adrp	x1, 20000 <__data_start>
    191c:	91016021 	add	x1, x1, #0x58
    1920:	eb00003f 	cmp	x1, x0
    1924:	540000c0 	b.eq	193c <deregister_tm_clones+0x2c>  // b.none
    1928:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152b8>
    192c:	f947e021 	ldr	x1, [x1, #4032]
    1930:	b4000061 	cbz	x1, 193c <deregister_tm_clones+0x2c>
    1934:	aa0103f0 	mov	x16, x1
    1938:	d61f0200 	br	x16
    193c:	d65f03c0 	ret

0000000000001940 <register_tm_clones>:
    1940:	f00000e0 	adrp	x0, 20000 <__data_start>
    1944:	91016000 	add	x0, x0, #0x58
    1948:	f00000e1 	adrp	x1, 20000 <__data_start>
    194c:	91016021 	add	x1, x1, #0x58
    1950:	cb000021 	sub	x1, x1, x0
    1954:	d37ffc22 	lsr	x2, x1, #63
    1958:	8b810c41 	add	x1, x2, x1, asr #3
    195c:	9341fc21 	asr	x1, x1, #1
    1960:	b40000c1 	cbz	x1, 1978 <register_tm_clones+0x38>
    1964:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x152b8>
    1968:	f947fc42 	ldr	x2, [x2, #4088]
    196c:	b4000062 	cbz	x2, 1978 <register_tm_clones+0x38>
    1970:	aa0203f0 	mov	x16, x2
    1974:	d61f0200 	br	x16
    1978:	d65f03c0 	ret
    197c:	d503201f 	nop

0000000000001980 <__do_global_dtors_aux>:
    1980:	d503233f 	paciasp
    1984:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1988:	910003fd 	mov	x29, sp
    198c:	f9000bf3 	str	x19, [sp, #16]
    1990:	f00000f3 	adrp	x19, 20000 <__data_start>
    1994:	39418260 	ldrb	w0, [x19, #96]
    1998:	37000140 	tbnz	w0, #0, 19c0 <__do_global_dtors_aux+0x40>
    199c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    19a0:	f947e400 	ldr	x0, [x0, #4040]
    19a4:	b4000080 	cbz	x0, 19b4 <__do_global_dtors_aux+0x34>
    19a8:	f00000e0 	adrp	x0, 20000 <__data_start>
    19ac:	f9400400 	ldr	x0, [x0, #8]
    19b0:	97fffe78 	bl	1390 <__cxa_finalize@plt>
    19b4:	97ffffd7 	bl	1910 <deregister_tm_clones>
    19b8:	52800020 	mov	w0, #0x1                   	// #1
    19bc:	39018260 	strb	w0, [x19, #96]
    19c0:	f9400bf3 	ldr	x19, [sp, #16]
    19c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    19c8:	d50323bf 	autiasp
    19cc:	d65f03c0 	ret

00000000000019d0 <frame_dummy>:
    19d0:	d503245f 	bti	c
    19d4:	17ffffdb 	b	1940 <register_tm_clones>
    19d8:	d503201f 	nop
    19dc:	d503201f 	nop

00000000000019e0 <fwp_fmt_u128>:
    19e0:	d10183ff 	sub	sp, sp, #0x60
    19e4:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152b8>
    19e8:	f947f421 	ldr	x1, [x1, #4072]
    19ec:	a9057bfd 	stp	x29, x30, [sp, #80]
    19f0:	910143fd 	add	x29, sp, #0x50
    19f4:	f9400024 	ldr	x4, [x1]
    19f8:	f90027e4 	str	x4, [sp, #72]
    19fc:	d2800004 	mov	x4, #0x0                   	// #0
    1a00:	aa030041 	orr	x1, x2, x3
    1a04:	b5000361 	cbnz	x1, 1a70 <fwp_fmt_u128+0x90>
    1a08:	910023e9 	add	x9, sp, #0x8
    1a0c:	52800601 	mov	w1, #0x30                  	// #48
    1a10:	5280002d 	mov	w13, #0x1                   	// #1
    1a14:	390023e1 	strb	w1, [sp, #8]
    1a18:	93407dad 	sxtw	x13, w13
    1a1c:	aa0d03e1 	mov	x1, x13
    1a20:	8b0d0004 	add	x4, x0, x13
    1a24:	d503201f 	nop
    1a28:	8b010123 	add	x3, x9, x1
    1a2c:	cb0103e2 	neg	x2, x1
    1a30:	d1000421 	sub	x1, x1, #0x1
    1a34:	385ff063 	ldurb	w3, [x3, #-1]
    1a38:	38226883 	strb	w3, [x4, x2]
    1a3c:	35ffff61 	cbnz	w1, 1a28 <fwp_fmt_u128+0x48>
    1a40:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152b8>
    1a44:	f947f421 	ldr	x1, [x1, #4072]
    1a48:	382d681f 	strb	wzr, [x0, x13]
    1a4c:	aa0103e0 	mov	x0, x1
    1a50:	f94027e2 	ldr	x2, [sp, #72]
    1a54:	f9400001 	ldr	x1, [x0]
    1a58:	eb010042 	subs	x2, x2, x1
    1a5c:	d2800001 	mov	x1, #0x0                   	// #0
    1a60:	54000561 	b.ne	1b0c <fwp_fmt_u128+0x12c>  // b.any
    1a64:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1a68:	910183ff 	add	sp, sp, #0x60
    1a6c:	d65f03c0 	ret
    1a70:	90000041 	adrp	x1, 9000 <msg.3+0x20>
    1a74:	91000021 	add	x1, x1, #0x0
    1a78:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1a7c:	910023e9 	add	x9, sp, #0x8
    1a80:	d2800027 	mov	x7, #0x1                   	// #1
    1a84:	f29999af 	movk	x15, #0xcccd
    1a88:	a9402826 	ldp	x6, x10, [x1]
    1a8c:	d503201f 	nop
    1a90:	ab030041 	adds	x1, x2, x3
    1a94:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1a98:	aa0303eb 	mov	x11, x3
    1a9c:	8b070128 	add	x8, x9, x7
    1aa0:	aa0203ee 	mov	x14, x2
    1aa4:	aa0703ed 	mov	x13, x7
    1aa8:	910004e7 	add	x7, x7, #0x1
    1aac:	9bcf7c24 	umulh	x4, x1, x15
    1ab0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1ab4:	8b4408a4 	add	x4, x5, x4, lsr #2
    1ab8:	cb040021 	sub	x1, x1, x4
    1abc:	eb010041 	subs	x1, x2, x1
    1ac0:	da1f0063 	sbc	x3, x3, xzr
    1ac4:	9bc67c24 	umulh	x4, x1, x6
    1ac8:	9b061064 	madd	x4, x3, x6, x4
    1acc:	9b067c2c 	mul	x12, x1, x6
    1ad0:	9b0a1024 	madd	x4, x1, x10, x4
    1ad4:	9bc67c25 	umulh	x5, x1, x6
    1ad8:	9b061465 	madd	x5, x3, x6, x5
    1adc:	9b0a1425 	madd	x5, x1, x10, x5
    1ae0:	93cc0484 	extr	x4, x4, x12, #1
    1ae4:	8b040884 	add	x4, x4, x4, lsl #2
    1ae8:	d341fca3 	lsr	x3, x5, #1
    1aec:	cb040444 	sub	x4, x2, x4, lsl #1
    1af0:	93cc04a2 	extr	x2, x5, x12, #1
    1af4:	1100c084 	add	w4, w4, #0x30
    1af8:	381ff104 	sturb	w4, [x8, #-1]
    1afc:	b5fffcab 	cbnz	x11, 1a90 <fwp_fmt_u128+0xb0>
    1b00:	f10025df 	cmp	x14, #0x9
    1b04:	54fffc68 	b.hi	1a90 <fwp_fmt_u128+0xb0>  // b.pmore
    1b08:	17ffffc4 	b	1a18 <fwp_fmt_u128+0x38>
    1b0c:	97fffe65 	bl	14a0 <__stack_chk_fail@plt>

0000000000001b10 <fwp_range_release>:
    1b10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b14:	910003fd 	mov	x29, sp
    1b18:	f9400801 	ldr	x1, [x0, #16]
    1b1c:	f9000bf3 	str	x19, [sp, #16]
    1b20:	aa0003f3 	mov	x19, x0
    1b24:	b4000061 	cbz	x1, 1b30 <fwp_range_release+0x20>
    1b28:	f9400400 	ldr	x0, [x0, #8]
    1b2c:	d63f0020 	blr	x1
    1b30:	f9400260 	ldr	x0, [x19]
    1b34:	f9400e61 	ldr	x1, [x19, #24]
    1b38:	f9400bf3 	ldr	x19, [sp, #16]
    1b3c:	aa0103f0 	mov	x16, x1
    1b40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1b44:	d61f0200 	br	x16
    1b48:	d503201f 	nop
    1b4c:	d503201f 	nop

0000000000001b50 <fwp_flush>:
    1b50:	f00000e0 	adrp	x0, 20000 <__data_start>
    1b54:	f9403800 	ldr	x0, [x0, #112]
    1b58:	b4000120 	cbz	x0, 1b7c <fwp_flush+0x2c>
    1b5c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1b60:	910003fd 	mov	x29, sp
    1b64:	97fffe9b 	bl	15d0 <fflush@plt>
    1b68:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    1b6c:	f947ec00 	ldr	x0, [x0, #4056]
    1b70:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1b74:	f9400000 	ldr	x0, [x0]
    1b78:	17fffe96 	b	15d0 <fflush@plt>
    1b7c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    1b80:	f947ec00 	ldr	x0, [x0, #4056]
    1b84:	f9400000 	ldr	x0, [x0]
    1b88:	17fffe92 	b	15d0 <fflush@plt>
    1b8c:	d503201f 	nop

0000000000001b90 <fwp_heap_oom>:
    1b90:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x152b8>
    1b94:	f947e863 	ldr	x3, [x3, #4048]
    1b98:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1b9c:	d2800262 	mov	x2, #0x13                  	// #19
    1ba0:	910003fd 	mov	x29, sp
    1ba4:	f9400063 	ldr	x3, [x3]
    1ba8:	d2800021 	mov	x1, #0x1                   	// #1
    1bac:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    1bb0:	912be000 	add	x0, x0, #0xaf8
    1bb4:	97fffe7b 	bl	15a0 <fwrite@plt>
    1bb8:	d2800000 	mov	x0, #0x0                   	// #0
    1bbc:	97fffe85 	bl	15d0 <fflush@plt>
    1bc0:	52800cc0 	mov	w0, #0x66                  	// #102
    1bc4:	97fffe93 	bl	1610 <_Exit@plt>
    1bc8:	d503201f 	nop
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_segv>:
    1bd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1bd4:	f00000e2 	adrp	x2, 20000 <__data_start>
    1bd8:	9101c043 	add	x3, x2, #0x70
    1bdc:	910003fd 	mov	x29, sp
    1be0:	a90153f3 	stp	x19, x20, [sp, #16]
    1be4:	2a0003f3 	mov	w19, w0
    1be8:	f9400460 	ldr	x0, [x3, #8]
    1bec:	f90013f5 	str	x21, [sp, #32]
    1bf0:	f9400835 	ldr	x21, [x1, #16]
    1bf4:	b4000280 	cbz	x0, 1c44 <fwp_segv+0x74>
    1bf8:	f9400814 	ldr	x20, [x0, #16]
    1bfc:	b4000254 	cbz	x20, 1c44 <fwp_segv+0x74>
    1c00:	528003c0 	mov	w0, #0x1e                  	// #30
    1c04:	97fffe7b 	bl	15f0 <sysconf@plt>
    1c08:	f144029f 	cmp	x20, #0x100, lsl #12
    1c0c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c10:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c14:	8b000294 	add	x20, x20, x0
    1c18:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c1c:	eb0102bf 	cmp	x21, x1
    1c20:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1c24:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c28:	35000240 	cbnz	w0, 1c70 <fwp_segv+0xa0>
    1c2c:	f94013f5 	ldr	x21, [sp, #32]
    1c30:	2a1303e0 	mov	w0, w19
    1c34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c38:	d2800001 	mov	x1, #0x0                   	// #0
    1c3c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c40:	17fffdf0 	b	1400 <signal@plt>
    1c44:	9101c042 	add	x2, x2, #0x70
    1c48:	f9400840 	ldr	x0, [x2, #16]
    1c4c:	b4ffff00 	cbz	x0, 1c2c <fwp_segv+0x5c>
    1c50:	f9400c41 	ldr	x1, [x2, #24]
    1c54:	cb010000 	sub	x0, x0, x1
    1c58:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1c5c:	91440000 	add	x0, x0, #0x100, lsl #12
    1c60:	eb15003f 	cmp	x1, x21
    1c64:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1c68:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c6c:	34fffe00 	cbz	w0, 1c2c <fwp_segv+0x5c>
    1c70:	97ffffb8 	bl	1b50 <fwp_flush>
    1c74:	f0000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    1c78:	913f8021 	add	x1, x1, #0xfe0
    1c7c:	d2800342 	mov	x2, #0x1a                  	// #26
    1c80:	52800040 	mov	w0, #0x2                   	// #2
    1c84:	97fffe17 	bl	14e0 <write@plt>
    1c88:	52800ca0 	mov	w0, #0x65                  	// #101
    1c8c:	97fffda5 	bl	1320 <_exit@plt>

0000000000001c90 <fwp_heap_chunks>:
    1c90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1c94:	910003fd 	mov	x29, sp
    1c98:	a90153f3 	stp	x19, x20, [sp, #16]
    1c9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1ca0:	90000195 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    1ca4:	911442a1 	add	x1, x21, #0x510
    1ca8:	f100041f 	cmp	x0, #0x1
    1cac:	54000ca0 	b.eq	1e40 <fwp_heap_chunks+0x1b0>  // b.none
    1cb0:	f949f822 	ldr	x2, [x1, #5104]
    1cb4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaf0>
    1cb8:	912400a5 	add	x5, x5, #0x900
    1cbc:	911442a1 	add	x1, x21, #0x510
    1cc0:	f949ec34 	ldr	x20, [x1, #5080]
    1cc4:	eb14005f 	cmp	x2, x20
    1cc8:	54000c42 	b.cs	1e50 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1ccc:	f949fc23 	ldr	x3, [x1, #5112]
    1cd0:	8b020841 	add	x1, x2, x2, lsl #2
    1cd4:	d2800004 	mov	x4, #0x0                   	// #0
    1cd8:	8b010c61 	add	x1, x3, x1, lsl #3
    1cdc:	14000009 	b	1d00 <fwp_heap_chunks+0x70>
    1ce0:	91000483 	add	x3, x4, #0x1
    1ce4:	eb03001f 	cmp	x0, x3
    1ce8:	54000940 	b.eq	1e10 <fwp_heap_chunks+0x180>  // b.none
    1cec:	91000442 	add	x2, x2, #0x1
    1cf0:	aa0303e4 	mov	x4, x3
    1cf4:	9100a021 	add	x1, x1, #0x28
    1cf8:	eb02029f 	cmp	x20, x2
    1cfc:	54000100 	b.eq	1d1c <fwp_heap_chunks+0x8c>  // b.none
    1d00:	39400023 	ldrb	w3, [x1]
    1d04:	34fffee3 	cbz	w3, 1ce0 <fwp_heap_chunks+0x50>
    1d08:	91000442 	add	x2, x2, #0x1
    1d0c:	9100a021 	add	x1, x1, #0x28
    1d10:	d2800004 	mov	x4, #0x0                   	// #0
    1d14:	eb02029f 	cmp	x20, x2
    1d18:	54ffff41 	b.ne	1d00 <fwp_heap_chunks+0x70>  // b.any
    1d1c:	cb040294 	sub	x20, x20, x4
    1d20:	f9001bf7 	str	x23, [sp, #48]
    1d24:	911442b7 	add	x23, x21, #0x510
    1d28:	8b140013 	add	x19, x0, x20
    1d2c:	f94a1ae1 	ldr	x1, [x23, #5168]
    1d30:	f949f2e0 	ldr	x0, [x23, #5088]
    1d34:	cb040021 	sub	x1, x1, x4
    1d38:	f90a1ae1 	str	x1, [x23, #5168]
    1d3c:	eb00027f 	cmp	x19, x0
    1d40:	54000429 	b.ls	1dc4 <fwp_heap_chunks+0x134>  // b.plast
    1d44:	f949eae1 	ldr	x1, [x23, #5072]
    1d48:	eb01027f 	cmp	x19, x1
    1d4c:	54000888 	b.hi	1e5c <fwp_heap_chunks+0x1cc>  // b.pmore
    1d50:	91010276 	add	x22, x19, #0x40
    1d54:	52800062 	mov	w2, #0x3                   	// #3
    1d58:	f949dae3 	ldr	x3, [x23, #5040]
    1d5c:	eb0102df 	cmp	x22, x1
    1d60:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1d64:	cb0002c1 	sub	x1, x22, x0
    1d68:	8b004060 	add	x0, x3, x0, lsl #16
    1d6c:	d370bc21 	lsl	x1, x1, #16
    1d70:	97fffe34 	bl	1640 <mprotect@plt>
    1d74:	35000740 	cbnz	w0, 1e5c <fwp_heap_chunks+0x1cc>
    1d78:	528003c0 	mov	w0, #0x1e                  	// #30
    1d7c:	97fffe1d 	bl	15f0 <sysconf@plt>
    1d80:	f949f2e2 	ldr	x2, [x23, #5088]
    1d84:	cb0003e5 	neg	x5, x0
    1d88:	aa0003e4 	mov	x4, x0
    1d8c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1d90:	f949fee0 	ldr	x0, [x23, #5112]
    1d94:	8b020843 	add	x3, x2, x2, lsl #2
    1d98:	52800062 	mov	w2, #0x3                   	// #3
    1d9c:	8b010c01 	add	x1, x0, x1, lsl #3
    1da0:	8b030c03 	add	x3, x0, x3, lsl #3
    1da4:	d1000421 	sub	x1, x1, #0x1
    1da8:	8a050060 	and	x0, x3, x5
    1dac:	8b040021 	add	x1, x1, x4
    1db0:	8a050021 	and	x1, x1, x5
    1db4:	cb000021 	sub	x1, x1, x0
    1db8:	97fffe22 	bl	1640 <mprotect@plt>
    1dbc:	35000500 	cbnz	w0, 1e5c <fwp_heap_chunks+0x1cc>
    1dc0:	f909f2f6 	str	x22, [x23, #5088]
    1dc4:	911442b5 	add	x21, x21, #0x510
    1dc8:	d370be60 	lsl	x0, x19, #16
    1dcc:	f949e6a1 	ldr	x1, [x21, #5064]
    1dd0:	f909eeb3 	str	x19, [x21, #5080]
    1dd4:	eb01001f 	cmp	x0, x1
    1dd8:	540000e8 	b.hi	1df4 <fwp_heap_chunks+0x164>  // b.pmore
    1ddc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1de0:	aa1403e0 	mov	x0, x20
    1de4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1de8:	f9401bf7 	ldr	x23, [sp, #48]
    1dec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1df0:	d65f03c0 	ret
    1df4:	f9401bf7 	ldr	x23, [sp, #48]
    1df8:	f909e6a0 	str	x0, [x21, #5064]
    1dfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e00:	aa1403e0 	mov	x0, x20
    1e04:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e08:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e0c:	d65f03c0 	ret
    1e10:	911442b5 	add	x21, x21, #0x510
    1e14:	91000441 	add	x1, x2, #0x1
    1e18:	f90000a1 	str	x1, [x5]
    1e1c:	cb040054 	sub	x20, x2, x4
    1e20:	f94a1aa1 	ldr	x1, [x21, #5168]
    1e24:	cb000020 	sub	x0, x1, x0
    1e28:	f90a1aa0 	str	x0, [x21, #5168]
    1e2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e30:	aa1403e0 	mov	x0, x20
    1e34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e38:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e3c:	d65f03c0 	ret
    1e40:	f949f422 	ldr	x2, [x1, #5096]
    1e44:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaf0>
    1e48:	9123e0a5 	add	x5, x5, #0x8f8
    1e4c:	17ffff9c 	b	1cbc <fwp_heap_chunks+0x2c>
    1e50:	d2800004 	mov	x4, #0x0                   	// #0
    1e54:	f9001bf7 	str	x23, [sp, #48]
    1e58:	17ffffb3 	b	1d24 <fwp_heap_chunks+0x94>
    1e5c:	97ffff4d 	bl	1b90 <fwp_heap_oom>

0000000000001e60 <buf_grow>:
    1e60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1e64:	910003fd 	mov	x29, sp
    1e68:	a90153f3 	stp	x19, x20, [sp, #16]
    1e6c:	aa0003f4 	mov	x20, x0
    1e70:	f9400400 	ldr	x0, [x0, #8]
    1e74:	b100041f 	cmn	x0, #0x1
    1e78:	54000400 	b.eq	1ef8 <buf_grow+0x98>  // b.none
    1e7c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    1e80:	cb000042 	sub	x2, x2, x0
    1e84:	eb01005f 	cmp	x2, x1
    1e88:	54000383 	b.cc	1ef8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    1e8c:	f9400a82 	ldr	x2, [x20, #16]
    1e90:	91000421 	add	x1, x1, #0x1
    1e94:	8b000033 	add	x19, x1, x0
    1e98:	eb13005f 	cmp	x2, x19
    1e9c:	54000242 	b.cs	1ee4 <buf_grow+0x84>  // b.hs, b.nlast
    1ea0:	f100005f 	cmp	x2, #0x0
    1ea4:	b5000262 	cbnz	x2, 1ef0 <buf_grow+0x90>
    1ea8:	d2800802 	mov	x2, #0x40                  	// #64
    1eac:	eb02027f 	cmp	x19, x2
    1eb0:	54000068 	b.hi	1ebc <buf_grow+0x5c>  // b.pmore
    1eb4:	14000005 	b	1ec8 <buf_grow+0x68>
    1eb8:	b7f800a2 	tbnz	x2, #63, 1ecc <buf_grow+0x6c>
    1ebc:	d37ff842 	lsl	x2, x2, #1
    1ec0:	eb02027f 	cmp	x19, x2
    1ec4:	54ffffa8 	b.hi	1eb8 <buf_grow+0x58>  // b.pmore
    1ec8:	aa0203f3 	mov	x19, x2
    1ecc:	f9400280 	ldr	x0, [x20]
    1ed0:	aa1303e1 	mov	x1, x19
    1ed4:	97fffd6f 	bl	1490 <realloc@plt>
    1ed8:	b4000100 	cbz	x0, 1ef8 <buf_grow+0x98>
    1edc:	f9000280 	str	x0, [x20]
    1ee0:	f9000a93 	str	x19, [x20, #16]
    1ee4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ee8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1eec:	d65f03c0 	ret
    1ef0:	54fffe6a 	b.ge	1ebc <buf_grow+0x5c>  // b.tcont
    1ef4:	17fffff6 	b	1ecc <buf_grow+0x6c>
    1ef8:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x152b8>
    1efc:	f947e863 	ldr	x3, [x3, #4048]
    1f00:	d2800262 	mov	x2, #0x13                  	// #19
    1f04:	d2800021 	mov	x1, #0x1                   	// #1
    1f08:	f0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    1f0c:	912be000 	add	x0, x0, #0xaf8
    1f10:	f9400063 	ldr	x3, [x3]
    1f14:	97fffda3 	bl	15a0 <fwrite@plt>
    1f18:	d2800000 	mov	x0, #0x0                   	// #0
    1f1c:	97fffdad 	bl	15d0 <fflush@plt>
    1f20:	52800cc0 	mov	w0, #0x66                  	// #102
    1f24:	97fffdbb 	bl	1610 <_Exit@plt>
    1f28:	d503201f 	nop
    1f2c:	d503201f 	nop

0000000000001f30 <buf_put>:
    1f30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1f34:	910003fd 	mov	x29, sp
    1f38:	a90153f3 	stp	x19, x20, [sp, #16]
    1f3c:	aa0003f4 	mov	x20, x0
    1f40:	aa0203f3 	mov	x19, x2
    1f44:	f90013f5 	str	x21, [sp, #32]
    1f48:	aa0103f5 	mov	x21, x1
    1f4c:	aa0203e1 	mov	x1, x2
    1f50:	97ffffc4 	bl	1e60 <buf_grow>
    1f54:	a9400283 	ldp	x3, x0, [x20]
    1f58:	aa1503e1 	mov	x1, x21
    1f5c:	aa1303e2 	mov	x2, x19
    1f60:	8b000060 	add	x0, x3, x0
    1f64:	97fffce7 	bl	1300 <memcpy@plt>
    1f68:	a9400680 	ldp	x0, x1, [x20]
    1f6c:	8b010273 	add	x19, x19, x1
    1f70:	f9000693 	str	x19, [x20, #8]
    1f74:	3833681f 	strb	wzr, [x0, x19]
    1f78:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f7c:	f94013f5 	ldr	x21, [sp, #32]
    1f80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1f84:	d65f03c0 	ret
    1f88:	d503201f 	nop
    1f8c:	d503201f 	nop

0000000000001f90 <fwp_cancel_tree.part.0>:
    1f90:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f94:	9101c022 	add	x2, x1, #0x70
    1f98:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1f9c:	52800023 	mov	w3, #0x1                   	// #1
    1fa0:	910003fd 	mov	x29, sp
    1fa4:	f9400444 	ldr	x4, [x2, #8]
    1fa8:	f9000bf3 	str	x19, [sp, #16]
    1fac:	39014403 	strb	w3, [x0, #81]
    1fb0:	eb04001f 	cmp	x0, x4
    1fb4:	54000160 	b.eq	1fe0 <fwp_cancel_tree.part.0+0x50>  // b.none
    1fb8:	f9402804 	ldr	x4, [x0, #80]
    1fbc:	f2001c9f 	tst	x4, #0xff000000ff
    1fc0:	54000101 	b.ne	1fe0 <fwp_cancel_tree.part.0+0x50>  // b.any
    1fc4:	f9401044 	ldr	x4, [x2, #32]
    1fc8:	39015003 	strb	w3, [x0, #84]
    1fcc:	f900801f 	str	xzr, [x0, #256]
    1fd0:	b40001e4 	cbz	x4, 200c <fwp_cancel_tree.part.0+0x7c>
    1fd4:	f9008080 	str	x0, [x4, #256]
    1fd8:	9101c021 	add	x1, x1, #0x70
    1fdc:	f9001020 	str	x0, [x1, #32]
    1fe0:	f9401413 	ldr	x19, [x0, #40]
    1fe4:	b40000f3 	cbz	x19, 2000 <fwp_cancel_tree.part.0+0x70>
    1fe8:	39414261 	ldrb	w1, [x19, #80]
    1fec:	aa1303e0 	mov	x0, x19
    1ff0:	37000041 	tbnz	w1, #0, 1ff8 <fwp_cancel_tree.part.0+0x68>
    1ff4:	97ffffe7 	bl	1f90 <fwp_cancel_tree.part.0>
    1ff8:	f9401a73 	ldr	x19, [x19, #48]
    1ffc:	b5ffff73 	cbnz	x19, 1fe8 <fwp_cancel_tree.part.0+0x58>
    2000:	f9400bf3 	ldr	x19, [sp, #16]
    2004:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2008:	d65f03c0 	ret
    200c:	f9001440 	str	x0, [x2, #40]
    2010:	17fffff2 	b	1fd8 <fwp_cancel_tree.part.0+0x48>

0000000000002014 <fwp_finish_float>:
    2014:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2018:	528005c1 	mov	w1, #0x2e                  	// #46
    201c:	910003fd 	mov	x29, sp
    2020:	f9000bf3 	str	x19, [sp, #16]
    2024:	aa0003f3 	mov	x19, x0
    2028:	97fffd56 	bl	1580 <strchr@plt>
    202c:	b4000080 	cbz	x0, 203c <fwp_finish_float+0x28>
    2030:	f9400bf3 	ldr	x19, [sp, #16]
    2034:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2038:	d65f03c0 	ret
    203c:	aa1303e0 	mov	x0, x19
    2040:	52800ca1 	mov	w1, #0x65                  	// #101
    2044:	97fffd4f 	bl	1580 <strchr@plt>
    2048:	b5ffff40 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    204c:	d0000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    2050:	aa1303e0 	mov	x0, x19
    2054:	912c4021 	add	x1, x1, #0xb10
    2058:	97fffd6a 	bl	1600 <strstr@plt>
    205c:	b5fffea0 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    2060:	d0000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    2064:	aa1303e0 	mov	x0, x19
    2068:	912c6021 	add	x1, x1, #0xb18
    206c:	97fffd65 	bl	1600 <strstr@plt>
    2070:	b5fffe00 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    2074:	aa1303e0 	mov	x0, x19
    2078:	97fffcae 	bl	1330 <strlen@plt>
    207c:	d0000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    2080:	912c8021 	add	x1, x1, #0xb20
    2084:	8b000262 	add	x2, x19, x0
    2088:	79400023 	ldrh	w3, [x1]
    208c:	39400821 	ldrb	w1, [x1, #2]
    2090:	78206a63 	strh	w3, [x19, x0]
    2094:	39000841 	strb	w1, [x2, #2]
    2098:	17ffffe6 	b	2030 <fwp_finish_float+0x1c>
    209c:	d503201f 	nop

00000000000020a0 <fwp_trap>:
    20a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    20a4:	910003fd 	mov	x29, sp
    20a8:	f9000bf3 	str	x19, [sp, #16]
    20ac:	aa0003f3 	mov	x19, x0
    20b0:	97fffea8 	bl	1b50 <fwp_flush>
    20b4:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x152b8>
    20b8:	f947e884 	ldr	x4, [x4, #4048]
    20bc:	aa1303e3 	mov	x3, x19
    20c0:	d0000022 	adrp	x2, 8000 <fwp_main_thread+0x170>
    20c4:	912ca042 	add	x2, x2, #0xb28
    20c8:	52800041 	mov	w1, #0x2                   	// #2
    20cc:	f9400080 	ldr	x0, [x4]
    20d0:	97fffd10 	bl	1510 <__fprintf_chk@plt>
    20d4:	52800ca0 	mov	w0, #0x65                  	// #101
    20d8:	97fffc9e 	bl	1350 <exit@plt>
    20dc:	d503201f 	nop

00000000000020e0 <fwp_now_ns>:
    20e0:	d100c3ff 	sub	sp, sp, #0x30
    20e4:	52800020 	mov	w0, #0x1                   	// #1
    20e8:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x152b8>
    20ec:	f947f442 	ldr	x2, [x2, #4072]
    20f0:	910023e1 	add	x1, sp, #0x8
    20f4:	a9027bfd 	stp	x29, x30, [sp, #32]
    20f8:	910083fd 	add	x29, sp, #0x20
    20fc:	f9400043 	ldr	x3, [x2]
    2100:	f9000fe3 	str	x3, [sp, #24]
    2104:	d2800003 	mov	x3, #0x0                   	// #0
    2108:	97fffcb2 	bl	13d0 <clock_gettime@plt>
    210c:	350002c0 	cbnz	w0, 2164 <fwp_now_ns+0x84>
    2110:	a9408be1 	ldp	x1, x2, [sp, #8]
    2114:	d2994003 	mov	x3, #0xca00                	// #51712
    2118:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    211c:	9b037c20 	mul	x0, x1, x3
    2120:	9b437c21 	smulh	x1, x1, x3
    2124:	ab020000 	adds	x0, x0, x2
    2128:	937ffc42 	asr	x2, x2, #63
    212c:	9a020021 	adc	x1, x1, x2
    2130:	f100001f 	cmp	x0, #0x0
    2134:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2138:	b50001e1 	cbnz	x1, 2174 <fwp_now_ns+0x94>
    213c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152b8>
    2140:	f947f421 	ldr	x1, [x1, #4072]
    2144:	f9400fe3 	ldr	x3, [sp, #24]
    2148:	f9400022 	ldr	x2, [x1]
    214c:	eb020063 	subs	x3, x3, x2
    2150:	d2800002 	mov	x2, #0x0                   	// #0
    2154:	540000e1 	b.ne	2170 <fwp_now_ns+0x90>  // b.any
    2158:	a9427bfd 	ldp	x29, x30, [sp, #32]
    215c:	9100c3ff 	add	sp, sp, #0x30
    2160:	d65f03c0 	ret
    2164:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    2168:	912ce000 	add	x0, x0, #0xb38
    216c:	97ffffcd 	bl	20a0 <fwp_trap>
    2170:	97fffccc 	bl	14a0 <__stack_chk_fail@plt>
    2174:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    2178:	912d6000 	add	x0, x0, #0xb58
    217c:	97ffffc9 	bl	20a0 <fwp_trap>

0000000000002180 <fwp_format_g.constprop.0>:
    2180:	d10483ff 	sub	sp, sp, #0x120
    2184:	d0000024 	adrp	x4, 8000 <fwp_main_thread+0x170>
    2188:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x152b8>
    218c:	f947f442 	ldr	x2, [x2, #4072]
    2190:	912e0084 	add	x4, x4, #0xb80
    2194:	a90b7bfd 	stp	x29, x30, [sp, #176]
    2198:	9102c3fd 	add	x29, sp, #0xb0
    219c:	d2800803 	mov	x3, #0x40                  	// #64
    21a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    21a4:	93407c38 	sxtw	x24, w1
    21a8:	aa0303e1 	mov	x1, x3
    21ac:	fd008be8 	str	d8, [sp, #272]
    21b0:	1e604008 	fmov	d8, d0
    21b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    21b8:	910083f4 	add	x20, sp, #0x20
    21bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    21c0:	aa0003f5 	mov	x21, x0
    21c4:	a91073fb 	stp	x27, x28, [sp, #256]
    21c8:	5100071c 	sub	w28, w24, #0x1
    21cc:	2a1c03e5 	mov	w5, w28
    21d0:	f9400040 	ldr	x0, [x2]
    21d4:	f90057e0 	str	x0, [sp, #168]
    21d8:	d2800000 	mov	x0, #0x0                   	// #0
    21dc:	52800042 	mov	w2, #0x2                   	// #2
    21e0:	aa1403e0 	mov	x0, x20
    21e4:	97fffc8b 	bl	1410 <__snprintf_chk@plt>
    21e8:	52800ca1 	mov	w1, #0x65                  	// #101
    21ec:	aa1403e0 	mov	x0, x20
    21f0:	97fffce4 	bl	1580 <strchr@plt>
    21f4:	aa0003f3 	mov	x19, x0
    21f8:	52800142 	mov	w2, #0xa                   	// #10
    21fc:	91000400 	add	x0, x0, #0x1
    2200:	d2800001 	mov	x1, #0x0                   	// #0
    2204:	97fffccf 	bl	1540 <strtol@plt>
    2208:	aa0003f7 	mov	x23, x0
    220c:	11001400 	add	w0, w0, #0x5
    2210:	7100541f 	cmp	w0, #0x15
    2214:	54000d68 	b.hi	23c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    2218:	4b170385 	sub	w5, w28, w23
    221c:	710000bf 	cmp	w5, #0x0
    2220:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2224:	54000b80 	b.eq	2394 <fwp_format_g.constprop.0+0x214>  // b.none
    2228:	394083e0 	ldrb	w0, [sp, #32]
    222c:	cb180273 	sub	x19, x19, x24
    2230:	91000673 	add	x19, x19, #0x1
    2234:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2238:	7100b41f 	cmp	w0, #0x2d
    223c:	9a941681 	cinc	x1, x20, eq	// eq = none
    2240:	1a9f17e4 	cset	w4, eq	// eq = none
    2244:	cb010266 	sub	x6, x19, x1
    2248:	d10004da 	sub	x26, x6, #0x1
    224c:	540018a0 	b.eq	2560 <fwp_format_g.constprop.0+0x3e0>  // b.none
    2250:	910183f9 	add	x25, sp, #0x60
    2254:	d280091b 	mov	x27, #0x48                  	// #72
    2258:	aa1903e7 	mov	x7, x25
    225c:	91000423 	add	x3, x1, #0x1
    2260:	91011cc6 	add	x6, x6, #0x47
    2264:	910004f6 	add	x22, x7, #0x1
    2268:	37f80ff7 	tbnz	w23, #31, 2464 <fwp_format_g.constprop.0+0x2e4>
    226c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    2270:	93407ef7 	sxtw	x23, w23
    2274:	390000e4 	strb	w4, [x7]
    2278:	aa1303e1 	mov	x1, x19
    227c:	aa1703e2 	mov	x2, x23
    2280:	aa1603e0 	mov	x0, x22
    2284:	b9000be5 	str	w5, [sp, #8]
    2288:	cb170374 	sub	x20, x27, x23
    228c:	a9011be3 	stp	x3, x6, [sp, #16]
    2290:	97fffc1c 	bl	1300 <memcpy@plt>
    2294:	d1000694 	sub	x20, x20, #0x1
    2298:	f9400be3 	ldr	x3, [sp, #16]
    229c:	8b1702d6 	add	x22, x22, x23
    22a0:	aa1603e0 	mov	x0, x22
    22a4:	aa1a03e2 	mov	x2, x26
    22a8:	aa0303e1 	mov	x1, x3
    22ac:	aa1403e3 	mov	x3, x20
    22b0:	97fffc50 	bl	13f0 <__memcpy_chk@plt>
    22b4:	8b1a02d6 	add	x22, x22, x26
    22b8:	f9400fe6 	ldr	x6, [sp, #24]
    22bc:	d2800900 	mov	x0, #0x48                  	// #72
    22c0:	b9400be5 	ldr	w5, [sp, #8]
    22c4:	8b170261 	add	x1, x19, x23
    22c8:	cb1400c3 	sub	x3, x6, x20
    22cc:	cb060294 	sub	x20, x20, x6
    22d0:	f101207f 	cmp	x3, #0x48
    22d4:	93407cb8 	sxtw	x24, w5
    22d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    22dc:	aa1803e2 	mov	x2, x24
    22e0:	8b1802d3 	add	x19, x22, x24
    22e4:	8b140063 	add	x3, x3, x20
    22e8:	aa1603e0 	mov	x0, x22
    22ec:	97fffc41 	bl	13f0 <__memcpy_chk@plt>
    22f0:	cb190273 	sub	x19, x19, x25
    22f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    22f8:	eb00027f 	cmp	x19, x0
    22fc:	aa1903e1 	mov	x1, x25
    2300:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    2304:	aa1503e0 	mov	x0, x21
    2308:	aa1303e2 	mov	x2, x19
    230c:	97fffbfd 	bl	1300 <memcpy@plt>
    2310:	38336abf 	strb	wzr, [x21, x19]
    2314:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2318:	aa1503e0 	mov	x0, x21
    231c:	97fffc05 	bl	1330 <strlen@plt>
    2320:	aa0003f3 	mov	x19, x0
    2324:	528005c1 	mov	w1, #0x2e                  	// #46
    2328:	aa1503e0 	mov	x0, x21
    232c:	97fffc95 	bl	1580 <strchr@plt>
    2330:	b4000140 	cbz	x0, 2358 <fwp_format_g.constprop.0+0x1d8>
    2334:	b4000133 	cbz	x19, 2358 <fwp_format_g.constprop.0+0x1d8>
    2338:	aa1303e1 	mov	x1, x19
    233c:	d1000673 	sub	x19, x19, #0x1
    2340:	38736aa0 	ldrb	w0, [x21, x19]
    2344:	7100c01f 	cmp	w0, #0x30
    2348:	54001001 	b.ne	2548 <fwp_format_g.constprop.0+0x3c8>  // b.any
    234c:	38336abf 	strb	wzr, [x21, x19]
    2350:	b5ffff53 	cbnz	x19, 2338 <fwp_format_g.constprop.0+0x1b8>
    2354:	d503201f 	nop
    2358:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    235c:	f947f400 	ldr	x0, [x0, #4072]
    2360:	f94057e2 	ldr	x2, [sp, #168]
    2364:	f9400001 	ldr	x1, [x0]
    2368:	eb010042 	subs	x2, x2, x1
    236c:	d2800001 	mov	x1, #0x0                   	// #0
    2370:	54001061 	b.ne	257c <fwp_format_g.constprop.0+0x3fc>  // b.any
    2374:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2378:	a94c53f3 	ldp	x19, x20, [sp, #192]
    237c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2380:	a94e63f7 	ldp	x23, x24, [sp, #224]
    2384:	a95073fb 	ldp	x27, x28, [sp, #256]
    2388:	fd408be8 	ldr	d8, [sp, #272]
    238c:	910483ff 	add	sp, sp, #0x120
    2390:	d65f03c0 	ret
    2394:	1e604100 	fmov	d0, d8
    2398:	710000bf 	cmp	w5, #0x0
    239c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    23a0:	aa1503e0 	mov	x0, x21
    23a4:	d0000024 	adrp	x4, 8000 <fwp_main_thread+0x170>
    23a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    23ac:	912e6084 	add	x4, x4, #0xb98
    23b0:	52800042 	mov	w2, #0x2                   	// #2
    23b4:	d2803201 	mov	x1, #0x190                 	// #400
    23b8:	97fffc16 	bl	1410 <__snprintf_chk@plt>
    23bc:	17ffffd7 	b	2318 <fwp_format_g.constprop.0+0x198>
    23c0:	cb140273 	sub	x19, x19, x20
    23c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    23c8:	910183f9 	add	x25, sp, #0x60
    23cc:	aa1303e2 	mov	x2, x19
    23d0:	aa1403e1 	mov	x1, x20
    23d4:	aa1903e0 	mov	x0, x25
    23d8:	d2800803 	mov	x3, #0x40                  	// #64
    23dc:	97fffc05 	bl	13f0 <__memcpy_chk@plt>
    23e0:	38336b3f 	strb	wzr, [x25, x19]
    23e4:	aa1903e0 	mov	x0, x25
    23e8:	528005c1 	mov	w1, #0x2e                  	// #46
    23ec:	97fffc65 	bl	1580 <strchr@plt>
    23f0:	b40001c0 	cbz	x0, 2428 <fwp_format_g.constprop.0+0x2a8>
    23f4:	b50000b3 	cbnz	x19, 2408 <fwp_format_g.constprop.0+0x288>
    23f8:	1400000c 	b	2428 <fwp_format_g.constprop.0+0x2a8>
    23fc:	381ff01f 	sturb	wzr, [x0, #-1]
    2400:	f1000673 	subs	x19, x19, #0x1
    2404:	54000120 	b.eq	2428 <fwp_format_g.constprop.0+0x2a8>  // b.none
    2408:	8b130320 	add	x0, x25, x19
    240c:	385ff001 	ldurb	w1, [x0, #-1]
    2410:	7100c03f 	cmp	w1, #0x30
    2414:	54ffff40 	b.eq	23fc <fwp_format_g.constprop.0+0x27c>  // b.none
    2418:	d1000673 	sub	x19, x19, #0x1
    241c:	38736b20 	ldrb	w0, [x25, x19]
    2420:	7100b81f 	cmp	w0, #0x2e
    2424:	54000a80 	b.eq	2574 <fwp_format_g.constprop.0+0x3f4>  // b.none
    2428:	710002ff 	cmp	w23, #0x0
    242c:	528005a1 	mov	w1, #0x2d                  	// #45
    2430:	aa1903e5 	mov	x5, x25
    2434:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    2438:	aa1503e0 	mov	x0, x21
    243c:	52800566 	mov	w6, #0x2b                  	// #43
    2440:	d0000024 	adrp	x4, 8000 <fwp_main_thread+0x170>
    2444:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    2448:	912e2084 	add	x4, x4, #0xb88
    244c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2450:	52800042 	mov	w2, #0x2                   	// #2
    2454:	d2803201 	mov	x1, #0x190                 	// #400
    2458:	97fffbee 	bl	1410 <__snprintf_chk@plt>
    245c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2460:	17ffffbe 	b	2358 <fwp_format_g.constprop.0+0x1d8>
    2464:	52800605 	mov	w5, #0x30                  	// #48
    2468:	390000e5 	strb	w5, [x7]
    246c:	d100077b 	sub	x27, x27, #0x1
    2470:	aa0303e1 	mov	x1, x3
    2474:	aa1603e0 	mov	x0, x22
    2478:	aa1b03e3 	mov	x3, x27
    247c:	aa1a03e2 	mov	x2, x26
    2480:	f90007e6 	str	x6, [sp, #8]
    2484:	b90013e4 	str	w4, [sp, #16]
    2488:	8b1a02d6 	add	x22, x22, x26
    248c:	b9001be5 	str	w5, [sp, #24]
    2490:	97fffbd8 	bl	13f0 <__memcpy_chk@plt>
    2494:	f94007e6 	ldr	x6, [sp, #8]
    2498:	2a3703e7 	mvn	w7, w23
    249c:	b94013e4 	ldr	w4, [sp, #16]
    24a0:	cb1b00c1 	sub	x1, x6, x27
    24a4:	cb06037b 	sub	x27, x27, x6
    24a8:	f101203f 	cmp	x1, #0x48
    24ac:	d2800906 	mov	x6, #0x48                  	// #72
    24b0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    24b4:	8b1b0023 	add	x3, x1, x27
    24b8:	310006ff 	cmn	w23, #0x1
    24bc:	54000220 	b.eq	2500 <fwp_format_g.constprop.0+0x380>  // b.none
    24c0:	b9401be5 	ldr	w5, [sp, #24]
    24c4:	d2800001 	mov	x1, #0x0                   	// #0
    24c8:	f101207f 	cmp	x3, #0x48
    24cc:	d1000462 	sub	x2, x3, #0x1
    24d0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    24d4:	38216ac5 	strb	w5, [x22, x1]
    24d8:	cb030003 	sub	x3, x0, x3
    24dc:	91000421 	add	x1, x1, #0x1
    24e0:	91000463 	add	x3, x3, #0x1
    24e4:	eb00007f 	cmp	x3, x0
    24e8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    24ec:	cb000063 	sub	x3, x3, x0
    24f0:	8b020063 	add	x3, x3, x2
    24f4:	6b0100ff 	cmp	w7, w1
    24f8:	54fffe8c 	b.gt	24c8 <fwp_format_g.constprop.0+0x348>
    24fc:	8b2742d6 	add	x22, x22, w7, uxtw
    2500:	f101207f 	cmp	x3, #0x48
    2504:	d2800905 	mov	x5, #0x48                  	// #72
    2508:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    250c:	aa1603e0 	mov	x0, x22
    2510:	cb0300a1 	sub	x1, x5, x3
    2514:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    2518:	91000421 	add	x1, x1, #0x1
    251c:	d1000463 	sub	x3, x3, #0x1
    2520:	eb05003f 	cmp	x1, x5
    2524:	38001402 	strb	w2, [x0], #1
    2528:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    252c:	93407f82 	sxtw	x2, w28
    2530:	cb050025 	sub	x5, x1, x5
    2534:	aa1303e1 	mov	x1, x19
    2538:	8b0300a3 	add	x3, x5, x3
    253c:	8b1802d3 	add	x19, x22, x24
    2540:	97fffbac 	bl	13f0 <__memcpy_chk@plt>
    2544:	17ffff6b 	b	22f0 <fwp_format_g.constprop.0+0x170>
    2548:	d1000421 	sub	x1, x1, #0x1
    254c:	38616aa0 	ldrb	w0, [x21, x1]
    2550:	7100b81f 	cmp	w0, #0x2e
    2554:	54fff021 	b.ne	2358 <fwp_format_g.constprop.0+0x1d8>  // b.any
    2558:	38216abf 	strb	wzr, [x21, x1]
    255c:	17ffff7f 	b	2358 <fwp_format_g.constprop.0+0x1d8>
    2560:	910187e7 	add	x7, sp, #0x61
    2564:	910183f9 	add	x25, sp, #0x60
    2568:	d28008fb 	mov	x27, #0x47                  	// #71
    256c:	390183e0 	strb	w0, [sp, #96]
    2570:	17ffff3b 	b	225c <fwp_format_g.constprop.0+0xdc>
    2574:	38336b3f 	strb	wzr, [x25, x19]
    2578:	17ffffac 	b	2428 <fwp_format_g.constprop.0+0x2a8>
    257c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2580:	97fffbc8 	bl	14a0 <__stack_chk_fail@plt>

0000000000002584 <fwp_heap_report>:
    2584:	d105c3ff 	sub	sp, sp, #0x170
    2588:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xcd0>
    258c:	91144042 	add	x2, x2, #0x510
    2590:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x152b8>
    2594:	f947e821 	ldr	x1, [x1, #4048]
    2598:	a9117bfd 	stp	x29, x30, [sp, #272]
    259c:	910443fd 	add	x29, sp, #0x110
    25a0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    25a4:	f947f400 	ldr	x0, [x0, #4072]
    25a8:	a9135bf5 	stp	x21, x22, [sp, #304]
    25ac:	a91463f7 	stp	x23, x24, [sp, #320]
    25b0:	a9156bf9 	stp	x25, x26, [sp, #336]
    25b4:	6d1627e8 	stp	d8, d9, [sp, #352]
    25b8:	fd4a1c48 	ldr	d8, [x2, #5176]
    25bc:	fd4a2049 	ldr	d9, [x2, #5184]
    25c0:	f9400036 	ldr	x22, [x1]
    25c4:	f9400001 	ldr	x1, [x0]
    25c8:	f90087e1 	str	x1, [sp, #264]
    25cc:	d2800001 	mov	x1, #0x0                   	// #0
    25d0:	f949e459 	ldr	x25, [x2, #5064]
    25d4:	d0000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    25d8:	f94a1057 	ldr	x23, [x2, #5152]
    25dc:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    25e0:	f94a1458 	ldr	x24, [x2, #5160]
    25e4:	912e8021 	add	x1, x1, #0xba0
    25e8:	912ea000 	add	x0, x0, #0xba8
    25ec:	97fffb91 	bl	1430 <fopen@plt>
    25f0:	b4000760 	cbz	x0, 26dc <fwp_heap_report+0x158>
    25f4:	528daad5 	mov	w21, #0x6d56                	// #27990
    25f8:	a91253f3 	stp	x19, x20, [sp, #288]
    25fc:	aa0003f4 	mov	x20, x0
    2600:	910023f3 	add	x19, sp, #0x8
    2604:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2608:	72aae915 	movk	w21, #0x5748, lsl #16
    260c:	d503201f 	nop
    2610:	aa1403e2 	mov	x2, x20
    2614:	aa1303e0 	mov	x0, x19
    2618:	52802001 	mov	w1, #0x100                 	// #256
    261c:	97fffc0d 	bl	1650 <fgets@plt>
    2620:	b4000280 	cbz	x0, 2670 <fwp_heap_report+0xec>
    2624:	b9400261 	ldr	w1, [x19]
    2628:	6b15003f 	cmp	w1, w21
    262c:	54ffff21 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    2630:	39401260 	ldrb	w0, [x19, #4]
    2634:	7101341f 	cmp	w0, #0x4d
    2638:	54fffec1 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    263c:	394037e0 	ldrb	w0, [sp, #13]
    2640:	7100e81f 	cmp	w0, #0x3a
    2644:	54fffe61 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    2648:	52800142 	mov	w2, #0xa                   	// #10
    264c:	d2800001 	mov	x1, #0x0                   	// #0
    2650:	91003be0 	add	x0, sp, #0xe
    2654:	97fffbbb 	bl	1540 <strtol@plt>
    2658:	aa1403e2 	mov	x2, x20
    265c:	aa0003fa 	mov	x26, x0
    2660:	52802001 	mov	w1, #0x100                 	// #256
    2664:	aa1303e0 	mov	x0, x19
    2668:	97fffbfa 	bl	1650 <fgets@plt>
    266c:	b5fffdc0 	cbnz	x0, 2624 <fwp_heap_report+0xa0>
    2670:	aa1403e0 	mov	x0, x20
    2674:	97fffb6b 	bl	1420 <fclose@plt>
    2678:	a95253f3 	ldp	x19, x20, [sp, #288]
    267c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    2680:	f947f400 	ldr	x0, [x0, #4072]
    2684:	f94087e2 	ldr	x2, [sp, #264]
    2688:	f9400001 	ldr	x1, [x0]
    268c:	eb010042 	subs	x2, x2, x1
    2690:	d2800001 	mov	x1, #0x0                   	// #0
    2694:	54000281 	b.ne	26e4 <fwp_heap_report+0x160>  // b.any
    2698:	a9517bfd 	ldp	x29, x30, [sp, #272]
    269c:	aa1a03e6 	mov	x6, x26
    26a0:	aa1903e5 	mov	x5, x25
    26a4:	aa1803e4 	mov	x4, x24
    26a8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    26ac:	aa1703e3 	mov	x3, x23
    26b0:	a95463f7 	ldp	x23, x24, [sp, #320]
    26b4:	aa1603e0 	mov	x0, x22
    26b8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    26bc:	1e604121 	fmov	d1, d9
    26c0:	1e604100 	fmov	d0, d8
    26c4:	d0000022 	adrp	x2, 8000 <fwp_main_thread+0x170>
    26c8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    26cc:	912f2042 	add	x2, x2, #0xbc8
    26d0:	9105c3ff 	add	sp, sp, #0x170
    26d4:	52800041 	mov	w1, #0x2                   	// #2
    26d8:	17fffb8e 	b	1510 <__fprintf_chk@plt>
    26dc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    26e0:	17ffffe7 	b	267c <fwp_heap_report+0xf8>
    26e4:	a91253f3 	stp	x19, x20, [sp, #288]
    26e8:	97fffb6e 	bl	14a0 <__stack_chk_fail@plt>
    26ec:	d503201f 	nop

00000000000026f0 <fwp_heap_init>:
    26f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    26f4:	90000183 	adrp	x3, 32000 <fwp_heap+0xaf0>
    26f8:	91104061 	add	x1, x3, #0x410
    26fc:	910003fd 	mov	x29, sp
    2700:	a90153f3 	stp	x19, x20, [sp, #16]
    2704:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    2708:	91144262 	add	x2, x19, #0x510
    270c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2710:	52800024 	mov	w4, #0x1                   	// #1
    2714:	52800200 	mov	w0, #0x10                  	// #16
    2718:	b913a444 	str	w4, [x2, #5028]
    271c:	d503201f 	nop
    2720:	b8004420 	str	w0, [x1], #4
    2724:	11004000 	add	w0, w0, #0x10
    2728:	7104401f 	cmp	w0, #0x110
    272c:	54ffffa1 	b.ne	2720 <fwp_heap_init+0x30>  // b.any
    2730:	f0000022 	adrp	x2, 9000 <msg.3+0x20>
    2734:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2738:	90000181 	adrp	x1, 32000 <fwp_heap+0xaf0>
    273c:	91114021 	add	x1, x1, #0x450
    2740:	3dc00443 	ldr	q3, [x2, #16]
    2744:	d2800000 	mov	x0, #0x0                   	// #0
    2748:	4e040401 	dup	v1.4s, v0.s[0]
    274c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    2750:	0f215400 	shl	v0.2s, v0.2s, #1
    2754:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    2758:	3ca06821 	str	q1, [x1, x0]
    275c:	91004000 	add	x0, x0, #0x10
    2760:	f101801f 	cmp	x0, #0x60
    2764:	54ffff21 	b.ne	2748 <fwp_heap_init+0x58>  // b.any
    2768:	90000184 	adrp	x4, 32000 <fwp_heap+0xaf0>
    276c:	91104063 	add	x3, x3, #0x410
    2770:	9112c084 	add	x4, x4, #0x4b0
    2774:	91144266 	add	x6, x19, #0x510
    2778:	d2800002 	mov	x2, #0x0                   	// #0
    277c:	d2800000 	mov	x0, #0x0                   	// #0
    2780:	d2880205 	mov	x5, #0x4010                	// #16400
    2784:	d503201f 	nop
    2788:	910f0001 	add	x1, x0, #0x3c0
    278c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2790:	eb02003f 	cmp	x1, x2
    2794:	540000a2 	b.cs	27a8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    2798:	91000400 	add	x0, x0, #0x1
    279c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    27a0:	eb02003f 	cmp	x1, x2
    27a4:	54ffffa3 	b.cc	2798 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    27a8:	91004042 	add	x2, x2, #0x10
    27ac:	38001480 	strb	w0, [x4], #1
    27b0:	eb05005f 	cmp	x2, x5
    27b4:	54fffea1 	b.ne	2788 <fwp_heap_init+0x98>  // b.any
    27b8:	528000b5 	mov	w21, #0x5                   	// #5
    27bc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    27c0:	14000004 	b	27d0 <fwp_heap_init+0xe0>
    27c4:	d342fe94 	lsr	x20, x20, #2
    27c8:	710006b5 	subs	w21, w21, #0x1
    27cc:	54000720 	b.eq	28b0 <fwp_heap_init+0x1c0>  // b.none
    27d0:	91404296 	add	x22, x20, #0x10, lsl #12
    27d4:	d2800005 	mov	x5, #0x0                   	// #0
    27d8:	aa1603e1 	mov	x1, x22
    27dc:	12800004 	mov	w4, #0xffffffff            	// #-1
    27e0:	52880443 	mov	w3, #0x4022                	// #16418
    27e4:	52800002 	mov	w2, #0x0                   	// #0
    27e8:	d2800000 	mov	x0, #0x0                   	// #0
    27ec:	97fffb51 	bl	1530 <mmap@plt>
    27f0:	aa0003e6 	mov	x6, x0
    27f4:	b100041f 	cmn	x0, #0x1
    27f8:	54fffe60 	b.eq	27c4 <fwp_heap_init+0xd4>  // b.none
    27fc:	b40005a0 	cbz	x0, 28b0 <fwp_heap_init+0x1c0>
    2800:	d350fe94 	lsr	x20, x20, #16
    2804:	d29fffe0 	mov	x0, #0xffff                	// #65535
    2808:	8b0000c7 	add	x7, x6, x0
    280c:	91144275 	add	x21, x19, #0x510
    2810:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    2814:	8b140a81 	add	x1, x20, x20, lsl #2
    2818:	d2800005 	mov	x5, #0x0                   	// #0
    281c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2820:	d37df021 	lsl	x1, x1, #3
    2824:	52880443 	mov	w3, #0x4022                	// #16418
    2828:	52800002 	mov	w2, #0x0                   	// #0
    282c:	d2800000 	mov	x0, #0x0                   	// #0
    2830:	f909daa7 	str	x7, [x21, #5040]
    2834:	f909dea6 	str	x6, [x21, #5048]
    2838:	f909e2b6 	str	x22, [x21, #5056]
    283c:	f909eab4 	str	x20, [x21, #5072]
    2840:	f90a02a1 	str	x1, [x21, #5120]
    2844:	97fffb3b 	bl	1530 <mmap@plt>
    2848:	aa0003e1 	mov	x1, x0
    284c:	b100041f 	cmn	x0, #0x1
    2850:	54000300 	b.eq	28b0 <fwp_heap_init+0x1c0>  // b.none
    2854:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    2858:	9131e000 	add	x0, x0, #0xc78
    285c:	f909fea1 	str	x1, [x21, #5112]
    2860:	97fffb74 	bl	1630 <getenv@plt>
    2864:	52800002 	mov	w2, #0x0                   	// #0
    2868:	aa0003e1 	mov	x1, x0
    286c:	b40000e0 	cbz	x0, 2888 <fwp_heap_init+0x198>
    2870:	39400000 	ldrb	w0, [x0]
    2874:	340000a0 	cbz	w0, 2888 <fwp_heap_init+0x198>
    2878:	7100c000 	subs	w0, w0, #0x30
    287c:	54000120 	b.eq	28a0 <fwp_heap_init+0x1b0>  // b.none
    2880:	7100001f 	cmp	w0, #0x0
    2884:	1a9f07e2 	cset	w2, ne	// ne = any
    2888:	91144273 	add	x19, x19, #0x510
    288c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2890:	b913aa62 	str	w2, [x19, #5032]
    2894:	a94153f3 	ldp	x19, x20, [sp, #16]
    2898:	a8c37bfd 	ldp	x29, x30, [sp], #48
    289c:	d65f03c0 	ret
    28a0:	39400420 	ldrb	w0, [x1, #1]
    28a4:	7100001f 	cmp	w0, #0x0
    28a8:	1a9f07e2 	cset	w2, ne	// ne = any
    28ac:	17fffff7 	b	2888 <fwp_heap_init+0x198>
    28b0:	97fffcb8 	bl	1b90 <fwp_heap_oom>

00000000000028b4 <fwp_wake_io>:
    28b4:	d00000e9 	adrp	x9, 20000 <__data_start>
    28b8:	9101c122 	add	x2, x9, #0x70
    28bc:	f9400001 	ldr	x1, [x0]
    28c0:	5280000a 	mov	w10, #0x0                   	// #0
    28c4:	f9401046 	ldr	x6, [x2, #32]
    28c8:	52800008 	mov	w8, #0x0                   	// #0
    28cc:	4f000400 	movi	v0.4s, #0x0
    28d0:	52800027 	mov	w7, #0x1                   	// #1
    28d4:	aa0103e2 	mov	x2, x1
    28d8:	b4000321 	cbz	x1, 293c <fwp_wake_io+0x88>
    28dc:	f9408c25 	ldr	x5, [x1, #280]
    28e0:	39015c27 	strb	w7, [x1, #87]
    28e4:	b4000165 	cbz	x5, 2910 <fwp_wake_io+0x5c>
    28e8:	a9520c24 	ldp	x4, x3, [x1, #288]
    28ec:	b4000364 	cbz	x4, 2958 <fwp_wake_io+0xa4>
    28f0:	f9009483 	str	x3, [x4, #296]
    28f4:	f9409423 	ldr	x3, [x1, #296]
    28f8:	b4000043 	cbz	x3, 2900 <fwp_wake_io+0x4c>
    28fc:	f9009064 	str	x4, [x3, #288]
    2900:	91080023 	add	x3, x1, #0x200
    2904:	f900943f 	str	xzr, [x1, #296]
    2908:	3c918060 	stur	q0, [x3, #-232]
    290c:	f9400001 	ldr	x1, [x0]
    2910:	f9402843 	ldr	x3, [x2, #80]
    2914:	f2001c7f 	tst	x3, #0xff000000ff
    2918:	54fffde1 	b.ne	28d4 <fwp_wake_io+0x20>  // b.any
    291c:	39015047 	strb	w7, [x2, #84]
    2920:	f900805f 	str	xzr, [x2, #256]
    2924:	b40001e6 	cbz	x6, 2960 <fwp_wake_io+0xac>
    2928:	f90080c2 	str	x2, [x6, #256]
    292c:	aa0203e6 	mov	x6, x2
    2930:	52800028 	mov	w8, #0x1                   	// #1
    2934:	aa0103e2 	mov	x2, x1
    2938:	b5fffd21 	cbnz	x1, 28dc <fwp_wake_io+0x28>
    293c:	3400006a 	cbz	w10, 2948 <fwp_wake_io+0x94>
    2940:	9101c120 	add	x0, x9, #0x70
    2944:	f900140b 	str	x11, [x0, #40]
    2948:	34000068 	cbz	w8, 2954 <fwp_wake_io+0xa0>
    294c:	9101c129 	add	x9, x9, #0x70
    2950:	f9001126 	str	x6, [x9, #32]
    2954:	d65f03c0 	ret
    2958:	f90000a3 	str	x3, [x5]
    295c:	17ffffe7 	b	28f8 <fwp_wake_io+0x44>
    2960:	aa0203eb 	mov	x11, x2
    2964:	5280002a 	mov	w10, #0x1                   	// #1
    2968:	17fffff1 	b	292c <fwp_wake_io+0x78>
    296c:	d503201f 	nop

0000000000002970 <fwp_poll_events>:
    2970:	d10103ff 	sub	sp, sp, #0x40
    2974:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    2978:	f947f400 	ldr	x0, [x0, #4072]
    297c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2980:	910083fd 	add	x29, sp, #0x20
    2984:	a90353f3 	stp	x19, x20, [sp, #48]
    2988:	d00000f4 	adrp	x20, 20000 <__data_start>
    298c:	f9400001 	ldr	x1, [x0]
    2990:	f9000fe1 	str	x1, [sp, #24]
    2994:	d2800001 	mov	x1, #0x0                   	// #0
    2998:	97fffdd2 	bl	20e0 <fwp_now_ns>
    299c:	9101c281 	add	x1, x20, #0x70
    29a0:	f9401833 	ldr	x19, [x1, #48]
    29a4:	b4000e93 	cbz	x19, 2b74 <fwp_poll_events+0x204>
    29a8:	aa1303e1 	mov	x1, x19
    29ac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    29b0:	14000005 	b	29c4 <fwp_poll_events+0x54>
    29b4:	f9408821 	ldr	x1, [x1, #272]
    29b8:	eb03005f 	cmp	x2, x3
    29bc:	9a83d042 	csel	x2, x2, x3, le
    29c0:	b40000c1 	cbz	x1, 29d8 <fwp_poll_events+0x68>
    29c4:	f9403423 	ldr	x3, [x1, #104]
    29c8:	b6ffff62 	tbz	x2, #63, 29b4 <fwp_poll_events+0x44>
    29cc:	f9408821 	ldr	x1, [x1, #272]
    29d0:	aa0303e2 	mov	x2, x3
    29d4:	b5ffff81 	cbnz	x1, 29c4 <fwp_poll_events+0x54>
    29d8:	b7f80ce2 	tbnz	x2, #63, 2b74 <fwp_poll_events+0x204>
    29dc:	cb000042 	sub	x2, x2, x0
    29e0:	f100005f 	cmp	x2, #0x0
    29e4:	540005cd 	b.le	2a9c <fwp_poll_events+0x12c>
    29e8:	d2869b60 	mov	x0, #0x34db                	// #13531
    29ec:	d2884801 	mov	x1, #0x4240                	// #16960
    29f0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    29f4:	f2a001e1 	movk	x1, #0xf, lsl #16
    29f8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    29fc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2a00:	f2e86360 	movk	x0, #0x431b, lsl #48
    2a04:	9b407c40 	smulh	x0, x2, x0
    2a08:	9352fc00 	asr	x0, x0, #18
    2a0c:	cb82fc00 	sub	x0, x0, x2, asr #63
    2a10:	9b018802 	msub	x2, x0, x1, x2
    2a14:	f100005f 	cmp	x2, #0x0
    2a18:	9a800400 	cinc	x0, x0, ne	// ne = any
    2a1c:	eb03001f 	cmp	x0, x3
    2a20:	54000a0c 	b.gt	2b60 <fwp_poll_events+0x1f0>
    2a24:	340003c0 	cbz	w0, 2a9c <fwp_poll_events+0x12c>
    2a28:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2a2c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2a30:	72a20c42 	movk	w2, #0x1062, lsl #16
    2a34:	9ba27c02 	umull	x2, w0, w2
    2a38:	d366fc43 	lsr	x3, x2, #38
    2a3c:	aa0303e2 	mov	x2, x3
    2a40:	1b048063 	msub	w3, w3, w4, w0
    2a44:	9b217c63 	smull	x3, w3, w1
    2a48:	d2800001 	mov	x1, #0x0                   	// #0
    2a4c:	910023e0 	add	x0, sp, #0x8
    2a50:	a9008fe2 	stp	x2, x3, [sp, #8]
    2a54:	97fffac7 	bl	1570 <nanosleep@plt>
    2a58:	9101c280 	add	x0, x20, #0x70
    2a5c:	f9401813 	ldr	x19, [x0, #48]
    2a60:	97fffda0 	bl	20e0 <fwp_now_ns>
    2a64:	aa0003e6 	mov	x6, x0
    2a68:	b50001f3 	cbnz	x19, 2aa4 <fwp_poll_events+0x134>
    2a6c:	d503201f 	nop
    2a70:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    2a74:	f947f400 	ldr	x0, [x0, #4072]
    2a78:	f9400fe2 	ldr	x2, [sp, #24]
    2a7c:	f9400001 	ldr	x1, [x0]
    2a80:	eb010042 	subs	x2, x2, x1
    2a84:	d2800001 	mov	x1, #0x0                   	// #0
    2a88:	540008c1 	b.ne	2ba0 <fwp_poll_events+0x230>  // b.any
    2a8c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2a90:	a94353f3 	ldp	x19, x20, [sp, #48]
    2a94:	910103ff 	add	sp, sp, #0x40
    2a98:	d65f03c0 	ret
    2a9c:	97fffd91 	bl	20e0 <fwp_now_ns>
    2aa0:	aa0003e6 	mov	x6, x0
    2aa4:	4f000400 	movi	v0.4s, #0x0
    2aa8:	9101c288 	add	x8, x20, #0x70
    2aac:	52800027 	mov	w7, #0x1                   	// #1
    2ab0:	f9403661 	ldr	x1, [x19, #104]
    2ab4:	aa1303e5 	mov	x5, x19
    2ab8:	f9408a73 	ldr	x19, [x19, #272]
    2abc:	eb06003f 	cmp	x1, x6
    2ac0:	5400032c 	b.gt	2b24 <fwp_poll_events+0x1b4>
    2ac4:	394154a0 	ldrb	w0, [x5, #85]
    2ac8:	36000120 	tbz	w0, #0, 2aec <fwp_poll_events+0x17c>
    2acc:	f94084a0 	ldr	x0, [x5, #264]
    2ad0:	b40003c0 	cbz	x0, 2b48 <fwp_poll_events+0x1d8>
    2ad4:	f9008813 	str	x19, [x0, #272]
    2ad8:	b4000053 	cbz	x19, 2ae0 <fwp_poll_events+0x170>
    2adc:	f9008660 	str	x0, [x19, #264]
    2ae0:	910800a0 	add	x0, x5, #0x200
    2ae4:	390154bf 	strb	wzr, [x5, #85]
    2ae8:	3c908000 	stur	q0, [x0, #-248]
    2aec:	f94030a0 	ldr	x0, [x5, #96]
    2af0:	390158a7 	strb	w7, [x5, #86]
    2af4:	f100001f 	cmp	x0, #0x0
    2af8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2afc:	5400018d 	b.le	2b2c <fwp_poll_events+0x1bc>
    2b00:	f94028a0 	ldr	x0, [x5, #80]
    2b04:	f2001c1f 	tst	x0, #0xff000000ff
    2b08:	540000e1 	b.ne	2b24 <fwp_poll_events+0x1b4>  // b.any
    2b0c:	f9401100 	ldr	x0, [x8, #32]
    2b10:	390150a7 	strb	w7, [x5, #84]
    2b14:	f90080bf 	str	xzr, [x5, #256]
    2b18:	b40001e0 	cbz	x0, 2b54 <fwp_poll_events+0x1e4>
    2b1c:	f9001105 	str	x5, [x8, #32]
    2b20:	f9008005 	str	x5, [x0, #256]
    2b24:	b5fffc73 	cbnz	x19, 2ab0 <fwp_poll_events+0x140>
    2b28:	17ffffd2 	b	2a70 <fwp_poll_events+0x100>
    2b2c:	394144a0 	ldrb	w0, [x5, #81]
    2b30:	3707fe80 	tbnz	w0, #0, 2b00 <fwp_poll_events+0x190>
    2b34:	394140a0 	ldrb	w0, [x5, #80]
    2b38:	3707fe40 	tbnz	w0, #0, 2b00 <fwp_poll_events+0x190>
    2b3c:	aa0503e0 	mov	x0, x5
    2b40:	97fffd14 	bl	1f90 <fwp_cancel_tree.part.0>
    2b44:	17ffffef 	b	2b00 <fwp_poll_events+0x190>
    2b48:	9101c281 	add	x1, x20, #0x70
    2b4c:	f9001833 	str	x19, [x1, #48]
    2b50:	17ffffe2 	b	2ad8 <fwp_poll_events+0x168>
    2b54:	f9001105 	str	x5, [x8, #32]
    2b58:	f9001505 	str	x5, [x8, #40]
    2b5c:	17fffff2 	b	2b24 <fwp_poll_events+0x1b4>
    2b60:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2b64:	d2989362 	mov	x2, #0xc49b                	// #50331
    2b68:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2b6c:	f2a00402 	movk	x2, #0x20, lsl #16
    2b70:	17ffffb6 	b	2a48 <fwp_poll_events+0xd8>
    2b74:	97fffbf7 	bl	1b50 <fwp_flush>
    2b78:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x152b8>
    2b7c:	f947e863 	ldr	x3, [x3, #4048]
    2b80:	d2800562 	mov	x2, #0x2b                  	// #43
    2b84:	d2800021 	mov	x1, #0x1                   	// #1
    2b88:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    2b8c:	91322000 	add	x0, x0, #0xc88
    2b90:	f9400063 	ldr	x3, [x3]
    2b94:	97fffa83 	bl	15a0 <fwrite@plt>
    2b98:	52800ca0 	mov	w0, #0x65                  	// #101
    2b9c:	97fff9ed 	bl	1350 <exit@plt>
    2ba0:	97fffa40 	bl	14a0 <__stack_chk_fail@plt>

0000000000002ba4 <fwp_rc_forget_slot>:
    2ba4:	aa0003e1 	mov	x1, x0
    2ba8:	39400000 	ldrb	w0, [x0]
    2bac:	7103fc1f 	cmp	w0, #0xff
    2bb0:	54000040 	b.eq	2bb8 <fwp_rc_forget_slot+0x14>  // b.none
    2bb4:	d65f03c0 	ret
    2bb8:	ca414420 	eor	x0, x1, x1, lsr #17
    2bbc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2bc0:	ca402400 	eor	x0, x0, x0, lsr #9
    2bc4:	910003fd 	mov	x29, sp
    2bc8:	92401c00 	and	x0, x0, #0xff
    2bcc:	f9000bf3 	str	x19, [sp, #16]
    2bd0:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    2bd4:	91144262 	add	x2, x19, #0x510
    2bd8:	910a2403 	add	x3, x0, #0x289
    2bdc:	8b000c40 	add	x0, x2, x0, lsl #3
    2be0:	8b030c43 	add	x3, x2, x3, lsl #3
    2be4:	f94a2400 	ldr	x0, [x0, #5192]
    2be8:	b50000a0 	cbnz	x0, 2bfc <fwp_rc_forget_slot+0x58>
    2bec:	14000011 	b	2c30 <fwp_rc_forget_slot+0x8c>
    2bf0:	91004003 	add	x3, x0, #0x10
    2bf4:	f9400800 	ldr	x0, [x0, #16]
    2bf8:	b40001c0 	cbz	x0, 2c30 <fwp_rc_forget_slot+0x8c>
    2bfc:	f9400002 	ldr	x2, [x0]
    2c00:	eb02003f 	cmp	x1, x2
    2c04:	54ffff61 	b.ne	2bf0 <fwp_rc_forget_slot+0x4c>  // b.any
    2c08:	f9400801 	ldr	x1, [x0, #16]
    2c0c:	91144273 	add	x19, x19, #0x510
    2c10:	f9000061 	str	x1, [x3]
    2c14:	97fffa53 	bl	1560 <free@plt>
    2c18:	f94e2660 	ldr	x0, [x19, #7240]
    2c1c:	d1000400 	sub	x0, x0, #0x1
    2c20:	f90e2660 	str	x0, [x19, #7240]
    2c24:	f9400bf3 	ldr	x19, [sp, #16]
    2c28:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2c2c:	d65f03c0 	ret
    2c30:	d0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    2c34:	9132e000 	add	x0, x0, #0xcb8
    2c38:	97fffd1a 	bl	20a0 <fwp_trap>
    2c3c:	d503201f 	nop

0000000000002c40 <fwp_rc_prepare_chunk>:
    2c40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2c44:	910003fd 	mov	x29, sp
    2c48:	a9025bf5 	stp	x21, x22, [sp, #32]
    2c4c:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xcd0>
    2c50:	911442c2 	add	x2, x22, #0x510
    2c54:	b9401c03 	ldr	w3, [x0, #28]
    2c58:	aa0103f5 	mov	x21, x1
    2c5c:	a90153f3 	stp	x19, x20, [sp, #16]
    2c60:	aa0003f4 	mov	x20, x0
    2c64:	f94e2440 	ldr	x0, [x2, #7240]
    2c68:	b4000440 	cbz	x0, 2cf0 <fwp_rc_prepare_chunk+0xb0>
    2c6c:	d2800013 	mov	x19, #0x0                   	// #0
    2c70:	35000203 	cbnz	w3, 2cb0 <fwp_rc_prepare_chunk+0x70>
    2c74:	b4000361 	cbz	x1, 2ce0 <fwp_rc_prepare_chunk+0xa0>
    2c78:	f9401280 	ldr	x0, [x20, #32]
    2c7c:	97fffa39 	bl	1560 <free@plt>
    2c80:	aa1503e0 	mov	x0, x21
    2c84:	d2800021 	mov	x1, #0x1                   	// #1
    2c88:	97fff9fe 	bl	1480 <calloc@plt>
    2c8c:	f9001280 	str	x0, [x20, #32]
    2c90:	b5000460 	cbnz	x0, 2d1c <fwp_rc_prepare_chunk+0xdc>
    2c94:	97fffbbf 	bl	1b90 <fwp_heap_oom>
    2c98:	97ffffc3 	bl	2ba4 <fwp_rc_forget_slot>
    2c9c:	91000673 	add	x19, x19, #0x1
    2ca0:	b9401e83 	ldr	w3, [x20, #28]
    2ca4:	eb13007f 	cmp	x3, x19
    2ca8:	54000169 	b.ls	2cd4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2cac:	d503201f 	nop
    2cb0:	f9401283 	ldr	x3, [x20, #32]
    2cb4:	8b130060 	add	x0, x3, x19
    2cb8:	38736863 	ldrb	w3, [x3, x19]
    2cbc:	7103fc7f 	cmp	w3, #0xff
    2cc0:	54fffec0 	b.eq	2c98 <fwp_rc_prepare_chunk+0x58>  // b.none
    2cc4:	b9401e83 	ldr	w3, [x20, #28]
    2cc8:	91000673 	add	x19, x19, #0x1
    2ccc:	eb13007f 	cmp	x3, x19
    2cd0:	54ffff08 	b.hi	2cb0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2cd4:	eb0302bf 	cmp	x21, x3
    2cd8:	54000121 	b.ne	2cfc <fwp_rc_prepare_chunk+0xbc>  // b.any
    2cdc:	b5000335 	cbnz	x21, 2d40 <fwp_rc_prepare_chunk+0x100>
    2ce0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ce4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ce8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2cec:	d65f03c0 	ret
    2cf0:	2a0303e3 	mov	w3, w3
    2cf4:	eb0302bf 	cmp	x21, x3
    2cf8:	54ffff20 	b.eq	2cdc <fwp_rc_prepare_chunk+0x9c>  // b.none
    2cfc:	911442c2 	add	x2, x22, #0x510
    2d00:	f9401280 	ldr	x0, [x20, #32]
    2d04:	f94e2841 	ldr	x1, [x2, #7248]
    2d08:	cb030021 	sub	x1, x1, x3
    2d0c:	f90e2841 	str	x1, [x2, #7248]
    2d10:	97fffa14 	bl	1560 <free@plt>
    2d14:	b5fffb75 	cbnz	x21, 2c80 <fwp_rc_prepare_chunk+0x40>
    2d18:	f900129f 	str	xzr, [x20, #32]
    2d1c:	911442d6 	add	x22, x22, #0x510
    2d20:	f94e2ac0 	ldr	x0, [x22, #7248]
    2d24:	b9001e95 	str	w21, [x20, #28]
    2d28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d2c:	8b150000 	add	x0, x0, x21
    2d30:	f90e2ac0 	str	x0, [x22, #7248]
    2d34:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2d38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d3c:	d65f03c0 	ret
    2d40:	f9401280 	ldr	x0, [x20, #32]
    2d44:	aa1503e2 	mov	x2, x21
    2d48:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d4c:	52800001 	mov	w1, #0x0                   	// #0
    2d50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2d54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d58:	17fff9c6 	b	1470 <memset@plt>
    2d5c:	d503201f 	nop

0000000000002d60 <fwp_heap_refill>:
    2d60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2d64:	910003fd 	mov	x29, sp
    2d68:	a9025bf5 	stp	x21, x22, [sp, #32]
    2d6c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    2d70:	911442b5 	add	x21, x21, #0x510
    2d74:	aa0003f6 	mov	x22, x0
    2d78:	d2800020 	mov	x0, #0x1                   	// #1
    2d7c:	a90153f3 	stp	x19, x20, [sp, #16]
    2d80:	a90363f7 	stp	x23, x24, [sp, #48]
    2d84:	2a0103f7 	mov	w23, w1
    2d88:	2a0203f8 	mov	w24, w2
    2d8c:	97fffbc1 	bl	1c90 <fwp_heap_chunks>
    2d90:	aa0003f3 	mov	x19, x0
    2d94:	f949fea2 	ldr	x2, [x21, #5112]
    2d98:	8b000800 	add	x0, x0, x0, lsl #2
    2d9c:	2a1703e1 	mov	w1, w23
    2da0:	52800025 	mov	w5, #0x1                   	// #1
    2da4:	d37df000 	lsl	x0, x0, #3
    2da8:	910f0021 	add	x1, x1, #0x3c0
    2dac:	8b000054 	add	x20, x2, x0
    2db0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2db4:	52a00024 	mov	w4, #0x10000               	// #65536
    2db8:	38206845 	strb	w5, [x2, x0]
    2dbc:	aa1403e0 	mov	x0, x20
    2dc0:	39000698 	strb	w24, [x20, #1]
    2dc4:	39000a97 	strb	w23, [x20, #2]
    2dc8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2dcc:	b9000681 	str	w1, [x20, #4]
    2dd0:	2a0103e5 	mov	w5, w1
    2dd4:	8b0300a2 	add	x2, x5, x3
    2dd8:	1ac10881 	udiv	w1, w4, w1
    2ddc:	9ac50842 	udiv	x2, x2, x5
    2de0:	b9000a81 	str	w1, [x20, #8]
    2de4:	92404021 	and	x1, x1, #0x1ffff
    2de8:	b9001a82 	str	w2, [x20, #24]
    2dec:	97ffff95 	bl	2c40 <fwp_rc_prepare_chunk>
    2df0:	f949daa0 	ldr	x0, [x21, #5040]
    2df4:	29408a81 	ldp	w1, w2, [x20, #4]
    2df8:	8b134000 	add	x0, x0, x19, lsl #16
    2dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e00:	8b214003 	add	x3, x0, w1, uxtw
    2e04:	9ba20021 	umaddl	x1, w1, w2, x0
    2e08:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e0c:	a90086c3 	stp	x3, x1, [x22, #8]
    2e10:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e14:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2e18:	d65f03c0 	ret
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_mem_free>:
    2e20:	b40003c0 	cbz	x0, 2e98 <fwp_mem_free+0x78>
    2e24:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2e28:	910003fd 	mov	x29, sp
    2e2c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2e30:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    2e34:	911442a1 	add	x1, x21, #0x510
    2e38:	a90153f3 	stp	x19, x20, [sp, #16]
    2e3c:	aa0003f3 	mov	x19, x0
    2e40:	f949d823 	ldr	x3, [x1, #5040]
    2e44:	f949ec22 	ldr	x2, [x1, #5080]
    2e48:	cb030000 	sub	x0, x0, x3
    2e4c:	eb02401f 	cmp	x0, x2, lsl #16
    2e50:	540001c2 	b.cs	2e88 <fwp_mem_free+0x68>  // b.hs, b.nlast
    2e54:	d350fc16 	lsr	x22, x0, #16
    2e58:	a90363f7 	stp	x23, x24, [sp, #48]
    2e5c:	f949fc22 	ldr	x2, [x1, #5112]
    2e60:	8b160ad4 	add	x20, x22, x22, lsl #2
    2e64:	d37df294 	lsl	x20, x20, #3
    2e68:	ab140057 	adds	x23, x2, x20
    2e6c:	540000c0 	b.eq	2e84 <fwp_mem_free+0x64>  // b.none
    2e70:	38746842 	ldrb	w2, [x2, x20]
    2e74:	7100045f 	cmp	w2, #0x1
    2e78:	54000120 	b.eq	2e9c <fwp_mem_free+0x7c>  // b.none
    2e7c:	7100085f 	cmp	w2, #0x2
    2e80:	540005e0 	b.eq	2f3c <fwp_mem_free+0x11c>  // b.none
    2e84:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e90:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2e94:	d65f03c0 	ret
    2e98:	d65f03c0 	ret
    2e9c:	f94012f8 	ldr	x24, [x23, #32]
    2ea0:	b94006e1 	ldr	w1, [x23, #4]
    2ea4:	f90023f9 	str	x25, [sp, #64]
    2ea8:	2a0103e2 	mov	w2, w1
    2eac:	394006f9 	ldrb	w25, [x23, #1]
    2eb0:	39400af4 	ldrb	w20, [x23, #2]
    2eb4:	b4000158 	cbz	x24, 2edc <fwp_mem_free+0xbc>
    2eb8:	92403e76 	and	x22, x19, #0xffff
    2ebc:	9ac20ad6 	udiv	x22, x22, x2
    2ec0:	38766b01 	ldrb	w1, [x24, x22]
    2ec4:	8b160300 	add	x0, x24, x22
    2ec8:	7103fc3f 	cmp	w1, #0xff
    2ecc:	54000980 	b.eq	2ffc <fwp_mem_free+0x1dc>  // b.none
    2ed0:	38366b1f 	strb	wzr, [x24, x22]
    2ed4:	b94006e1 	ldr	w1, [x23, #4]
    2ed8:	2a0103e2 	mov	w2, w1
    2edc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    2ee0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    2ee4:	cb390000 	sub	x0, x0, w25, uxtb
    2ee8:	8b340074 	add	x20, x3, w20, uxtb
    2eec:	911442b5 	add	x21, x21, #0x510
    2ef0:	1e630021 	ucvtf	d1, w1
    2ef4:	d37ae400 	lsl	x0, x0, #6
    2ef8:	8b140c14 	add	x20, x0, x20, lsl #3
    2efc:	a94363f7 	ldp	x23, x24, [sp, #48]
    2f00:	f8746aa0 	ldr	x0, [x21, x20]
    2f04:	f94023f9 	ldr	x25, [sp, #64]
    2f08:	aa2003e0 	mvn	x0, x0
    2f0c:	fd4a22a0 	ldr	d0, [x21, #5184]
    2f10:	f9000260 	str	x0, [x19]
    2f14:	f8346ab3 	str	x19, [x21, x20]
    2f18:	f94a12a0 	ldr	x0, [x21, #5152]
    2f1c:	1e612800 	fadd	d0, d0, d1
    2f20:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f24:	cb020000 	sub	x0, x0, x2
    2f28:	f90a12a0 	str	x0, [x21, #5152]
    2f2c:	fd0a22a0 	str	d0, [x21, #5184]
    2f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f34:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2f38:	d65f03c0 	ret
    2f3c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    2f40:	8b000063 	add	x3, x3, x0
    2f44:	eb03027f 	cmp	x19, x3
    2f48:	54fff9e1 	b.ne	2e84 <fwp_mem_free+0x64>  // b.any
    2f4c:	fd400ae1 	ldr	d1, [x23, #16]
    2f50:	fd4a2020 	ldr	d0, [x1, #5184]
    2f54:	f9400ae0 	ldr	x0, [x23, #16]
    2f58:	7e61d821 	ucvtf	d1, d1
    2f5c:	f94a1022 	ldr	x2, [x1, #5152]
    2f60:	f94012f3 	ldr	x19, [x23, #32]
    2f64:	1e612800 	fadd	d0, d0, d1
    2f68:	cb000042 	sub	x2, x2, x0
    2f6c:	f90a1022 	str	x2, [x1, #5152]
    2f70:	fd0a2020 	str	d0, [x1, #5184]
    2f74:	b40000b3 	cbz	x19, 2f88 <fwp_mem_free+0x168>
    2f78:	39400260 	ldrb	w0, [x19]
    2f7c:	7103fc1f 	cmp	w0, #0xff
    2f80:	54000380 	b.eq	2ff0 <fwp_mem_free+0x1d0>  // b.none
    2f84:	3900027f 	strb	wzr, [x19]
    2f88:	b9400ee2 	ldr	w2, [x23, #12]
    2f8c:	b4000142 	cbz	x2, 2fb4 <fwp_mem_free+0x194>
    2f90:	911442a1 	add	x1, x21, #0x510
    2f94:	8b160040 	add	x0, x2, x22
    2f98:	8b000800 	add	x0, x0, x0, lsl #2
    2f9c:	f949fc21 	ldr	x1, [x1, #5112]
    2fa0:	8b140034 	add	x20, x1, x20
    2fa4:	8b000c20 	add	x0, x1, x0, lsl #3
    2fa8:	3802869f 	strb	wzr, [x20], #40
    2fac:	eb00029f 	cmp	x20, x0
    2fb0:	54ffffc1 	b.ne	2fa8 <fwp_mem_free+0x188>  // b.any
    2fb4:	911442a0 	add	x0, x21, #0x510
    2fb8:	f94a1801 	ldr	x1, [x0, #5168]
    2fbc:	f949f803 	ldr	x3, [x0, #5104]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f90a1801 	str	x1, [x0, #5168]
    2fc8:	eb16007f 	cmp	x3, x22
    2fcc:	54000049 	b.ls	2fd4 <fwp_mem_free+0x1b4>  // b.plast
    2fd0:	f909f816 	str	x22, [x0, #5104]
    2fd4:	911442b5 	add	x21, x21, #0x510
    2fd8:	f949f6a0 	ldr	x0, [x21, #5096]
    2fdc:	eb16001f 	cmp	x0, x22
    2fe0:	54fff529 	b.ls	2e84 <fwp_mem_free+0x64>  // b.plast
    2fe4:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fe8:	f909f6b6 	str	x22, [x21, #5096]
    2fec:	17ffffa7 	b	2e88 <fwp_mem_free+0x68>
    2ff0:	aa1303e0 	mov	x0, x19
    2ff4:	97fffeec 	bl	2ba4 <fwp_rc_forget_slot>
    2ff8:	17ffffe3 	b	2f84 <fwp_mem_free+0x164>
    2ffc:	97fffeea 	bl	2ba4 <fwp_rc_forget_slot>
    3000:	17ffffb4 	b	2ed0 <fwp_mem_free+0xb0>

0000000000003004 <fwp_heap_alloc_big>:
    3004:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    3008:	910003fd 	mov	x29, sp
    300c:	a90153f3 	stp	x19, x20, [sp, #16]
    3010:	a9025bf5 	stp	x21, x22, [sp, #32]
    3014:	a90363f7 	stp	x23, x24, [sp, #48]
    3018:	aa0003f7 	mov	x23, x0
    301c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    3020:	a9046bf9 	stp	x25, x26, [sp, #64]
    3024:	eb0002ff 	cmp	x23, x0
    3028:	54000888 	b.hi	3138 <fwp_heap_alloc_big+0x134>  // b.pmore
    302c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3030:	8b0002f4 	add	x20, x23, x0
    3034:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xcd0>
    3038:	91144359 	add	x25, x26, #0x510
    303c:	d350fe94 	lsr	x20, x20, #16
    3040:	2a0103f5 	mov	w21, w1
    3044:	aa1403e0 	mov	x0, x20
    3048:	97fffb12 	bl	1c90 <fwp_heap_chunks>
    304c:	f949ff22 	ldr	x2, [x25, #5112]
    3050:	8b000813 	add	x19, x0, x0, lsl #2
    3054:	aa0003f8 	mov	x24, x0
    3058:	52800043 	mov	w3, #0x2                   	// #2
    305c:	d37df273 	lsl	x19, x19, #3
    3060:	d2800021 	mov	x1, #0x1                   	// #1
    3064:	8b130040 	add	x0, x2, x19
    3068:	38336843 	strb	w3, [x2, x19]
    306c:	39000415 	strb	w21, [x0, #1]
    3070:	b9000c14 	str	w20, [x0, #12]
    3074:	f9000817 	str	x23, [x0, #16]
    3078:	97fffef2 	bl	2c40 <fwp_rc_prepare_chunk>
    307c:	f100069f 	cmp	x20, #0x1
    3080:	54000269 	b.ls	30cc <fwp_heap_alloc_big+0xc8>  // b.plast
    3084:	8b180294 	add	x20, x20, x24
    3088:	9100a273 	add	x19, x19, #0x28
    308c:	a90573fb 	stp	x27, x28, [sp, #80]
    3090:	5280007b 	mov	w27, #0x3                   	// #3
    3094:	8b140a94 	add	x20, x20, x20, lsl #2
    3098:	2a1803fc 	mov	w28, w24
    309c:	9adb2296 	lsl	x22, x20, x27
    30a0:	f949ff35 	ldr	x21, [x25, #5112]
    30a4:	d2800001 	mov	x1, #0x0                   	// #0
    30a8:	8b1302b4 	add	x20, x21, x19
    30ac:	aa1403e0 	mov	x0, x20
    30b0:	97fffee4 	bl	2c40 <fwp_rc_prepare_chunk>
    30b4:	38336abb 	strb	w27, [x21, x19]
    30b8:	9100a273 	add	x19, x19, #0x28
    30bc:	b9000e9c 	str	w28, [x20, #12]
    30c0:	eb1302df 	cmp	x22, x19
    30c4:	54fffee1 	b.ne	30a0 <fwp_heap_alloc_big+0x9c>  // b.any
    30c8:	a94573fb 	ldp	x27, x28, [sp, #80]
    30cc:	91144353 	add	x19, x26, #0x510
    30d0:	aa1703e2 	mov	x2, x23
    30d4:	52800001 	mov	w1, #0x0                   	// #0
    30d8:	f949da60 	ldr	x0, [x19, #5040]
    30dc:	8b184018 	add	x24, x0, x24, lsl #16
    30e0:	aa1803e0 	mov	x0, x24
    30e4:	97fff8e3 	bl	1470 <memset@plt>
    30e8:	f94a1260 	ldr	x0, [x19, #5152]
    30ec:	ab170000 	adds	x0, x0, x23
    30f0:	54000242 	b.cs	3138 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    30f4:	f94a1661 	ldr	x1, [x19, #5160]
    30f8:	f90a1260 	str	x0, [x19, #5152]
    30fc:	eb01001f 	cmp	x0, x1
    3100:	54000049 	b.ls	3108 <fwp_heap_alloc_big+0x104>  // b.plast
    3104:	f90a1660 	str	x0, [x19, #5160]
    3108:	9114435a 	add	x26, x26, #0x510
    310c:	9e6202e0 	scvtf	d0, x23
    3110:	a94153f3 	ldp	x19, x20, [sp, #16]
    3114:	aa1803e0 	mov	x0, x24
    3118:	fd4a1f41 	ldr	d1, [x26, #5176]
    311c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3120:	1e602820 	fadd	d0, d1, d0
    3124:	a94363f7 	ldp	x23, x24, [sp, #48]
    3128:	fd0a1f40 	str	d0, [x26, #5176]
    312c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3130:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3134:	d65f03c0 	ret
    3138:	a90573fb 	stp	x27, x28, [sp, #80]
    313c:	97fffa95 	bl	1b90 <fwp_heap_oom>

0000000000003140 <fwp_heap_alloc_slow>:
    3140:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3144:	910003fd 	mov	x29, sp
    3148:	a90153f3 	stp	x19, x20, [sp, #16]
    314c:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    3150:	91144262 	add	x2, x19, #0x510
    3154:	a9025bf5 	stp	x21, x22, [sp, #32]
    3158:	aa0003f5 	mov	x21, x0
    315c:	2a0103f4 	mov	w20, w1
    3160:	b953a440 	ldr	w0, [x2, #5028]
    3164:	34000600 	cbz	w0, 3224 <fwp_heap_alloc_slow+0xe4>
    3168:	f14012bf 	cmp	x21, #0x4, lsl #12
    316c:	54000628 	b.hi	3230 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3170:	91003ea0 	add	x0, x21, #0xf
    3174:	91144262 	add	x2, x19, #0x510
    3178:	f9001bf7 	str	x23, [sp, #48]
    317c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3180:	8b401040 	add	x0, x2, x0, lsr #4
    3184:	cb34c084 	sub	x4, x4, w20, sxtw
    3188:	d37ae484 	lsl	x4, x4, #6
    318c:	397e8003 	ldrb	w3, [x0, #4000]
    3190:	910f0060 	add	x0, x3, #0x3c0
    3194:	aa0303e1 	mov	x1, x3
    3198:	8b030463 	add	x3, x3, x3, lsl #1
    319c:	8b030c83 	add	x3, x4, x3, lsl #3
    31a0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    31a4:	2a1703f6 	mov	w22, w23
    31a8:	f8636844 	ldr	x4, [x2, x3]
    31ac:	b40004e4 	cbz	x4, 3248 <fwp_heap_alloc_slow+0x108>
    31b0:	f9400080 	ldr	x0, [x4]
    31b4:	aa2003e0 	mvn	x0, x0
    31b8:	f8236840 	str	x0, [x2, x3]
    31bc:	7100069f 	cmp	w20, #0x1
    31c0:	aa0403e0 	mov	x0, x4
    31c4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    31c8:	52800001 	mov	w1, #0x0                   	// #0
    31cc:	97fff8a9 	bl	1470 <memset@plt>
    31d0:	aa0003e4 	mov	x4, x0
    31d4:	91144260 	add	x0, x19, #0x510
    31d8:	f94a1001 	ldr	x1, [x0, #5152]
    31dc:	ab160021 	adds	x1, x1, x22
    31e0:	540005c2 	b.cs	3298 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    31e4:	f94a1402 	ldr	x2, [x0, #5160]
    31e8:	f90a1001 	str	x1, [x0, #5152]
    31ec:	eb02003f 	cmp	x1, x2
    31f0:	54000049 	b.ls	31f8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    31f4:	f90a1401 	str	x1, [x0, #5160]
    31f8:	91144273 	add	x19, x19, #0x510
    31fc:	1e6302e1 	ucvtf	d1, w23
    3200:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3204:	aa0403e0 	mov	x0, x4
    3208:	fd4a1e60 	ldr	d0, [x19, #5176]
    320c:	f9401bf7 	ldr	x23, [sp, #48]
    3210:	1e612800 	fadd	d0, d0, d1
    3214:	fd0a1e60 	str	d0, [x19, #5176]
    3218:	a94153f3 	ldp	x19, x20, [sp, #16]
    321c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3220:	d65f03c0 	ret
    3224:	97fffd33 	bl	26f0 <fwp_heap_init>
    3228:	f14012bf 	cmp	x21, #0x4, lsl #12
    322c:	54fffa29 	b.ls	3170 <fwp_heap_alloc_slow+0x30>  // b.plast
    3230:	2a1403e1 	mov	w1, w20
    3234:	aa1503e0 	mov	x0, x21
    3238:	a94153f3 	ldp	x19, x20, [sp, #16]
    323c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3240:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3244:	17ffff70 	b	3004 <fwp_heap_alloc_big>
    3248:	8b030042 	add	x2, x2, x3
    324c:	f9400444 	ldr	x4, [x2, #8]
    3250:	b4000104 	cbz	x4, 3270 <fwp_heap_alloc_slow+0x130>
    3254:	f9400840 	ldr	x0, [x2, #16]
    3258:	cb040000 	sub	x0, x0, x4
    325c:	eb16001f 	cmp	x0, x22
    3260:	54000083 	b.cc	3270 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3264:	8b160080 	add	x0, x4, x22
    3268:	f9000440 	str	x0, [x2, #8]
    326c:	17ffffd4 	b	31bc <fwp_heap_alloc_slow+0x7c>
    3270:	52800302 	mov	w2, #0x18                  	// #24
    3274:	52807804 	mov	w4, #0x3c0                 	// #960
    3278:	91144260 	add	x0, x19, #0x510
    327c:	9ba27c23 	umull	x3, w1, w2
    3280:	2a1403e2 	mov	w2, w20
    3284:	9b240e84 	smaddl	x4, w20, w4, x3
    3288:	8b040000 	add	x0, x0, x4
    328c:	97fffeb5 	bl	2d60 <fwp_heap_refill>
    3290:	aa0003e4 	mov	x4, x0
    3294:	17ffffca 	b	31bc <fwp_heap_alloc_slow+0x7c>
    3298:	97fffa3e 	bl	1b90 <fwp_heap_oom>
    329c:	d503201f 	nop

00000000000032a0 <fwp_rc_fresh>:
    32a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32a4:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcd0>
    32a8:	91144063 	add	x3, x3, #0x510
    32ac:	910003fd 	mov	x29, sp
    32b0:	a90153f3 	stp	x19, x20, [sp, #16]
    32b4:	aa0003f3 	mov	x19, x0
    32b8:	f949d861 	ldr	x1, [x3, #5040]
    32bc:	f949ec60 	ldr	x0, [x3, #5080]
    32c0:	cb010261 	sub	x1, x19, x1
    32c4:	eb00403f 	cmp	x1, x0, lsl #16
    32c8:	54000322 	b.cs	332c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    32cc:	d350fc22 	lsr	x2, x1, #16
    32d0:	f949fc63 	ldr	x3, [x3, #5112]
    32d4:	8b020842 	add	x2, x2, x2, lsl #2
    32d8:	d37df042 	lsl	x2, x2, #3
    32dc:	8b020060 	add	x0, x3, x2
    32e0:	f9401014 	ldr	x20, [x0, #32]
    32e4:	b4000254 	cbz	x20, 332c <fwp_rc_fresh+0x8c>
    32e8:	38626862 	ldrb	w2, [x3, x2]
    32ec:	7100085f 	cmp	w2, #0x2
    32f0:	54000260 	b.eq	333c <fwp_rc_fresh+0x9c>  // b.none
    32f4:	7100045f 	cmp	w2, #0x1
    32f8:	540001a1 	b.ne	332c <fwp_rc_fresh+0x8c>  // b.any
    32fc:	29430002 	ldp	w2, w0, [x0, #24]
    3300:	92403c21 	and	x1, x1, #0xffff
    3304:	9b027c21 	mul	x1, x1, x2
    3308:	d360fc21 	lsr	x1, x1, #32
    330c:	eb00003f 	cmp	x1, x0
    3310:	540000e2 	b.cs	332c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    3314:	8b010294 	add	x20, x20, x1
    3318:	39400280 	ldrb	w0, [x20]
    331c:	7103fc1f 	cmp	w0, #0xff
    3320:	540001a0 	b.eq	3354 <fwp_rc_fresh+0xb4>  // b.none
    3324:	52800020 	mov	w0, #0x1                   	// #1
    3328:	39000280 	strb	w0, [x20]
    332c:	aa1303e0 	mov	x0, x19
    3330:	a94153f3 	ldp	x19, x20, [sp, #16]
    3334:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3338:	d65f03c0 	ret
    333c:	72003c3f 	tst	w1, #0xffff
    3340:	54fffec0 	b.eq	3318 <fwp_rc_fresh+0x78>  // b.none
    3344:	aa1303e0 	mov	x0, x19
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	aa1403e0 	mov	x0, x20
    3358:	97fffe13 	bl	2ba4 <fwp_rc_forget_slot>
    335c:	17fffff2 	b	3324 <fwp_rc_fresh+0x84>

0000000000003360 <fwp_rc_free_arr>:
    3360:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcd0>
    3364:	91144063 	add	x3, x3, #0x510
    3368:	f949d861 	ldr	x1, [x3, #5040]
    336c:	f949ec62 	ldr	x2, [x3, #5080]
    3370:	cb010001 	sub	x1, x0, x1
    3374:	eb02403f 	cmp	x1, x2, lsl #16
    3378:	54000342 	b.cs	33e0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    337c:	d350fc22 	lsr	x2, x1, #16
    3380:	f949fc65 	ldr	x5, [x3, #5112]
    3384:	8b020842 	add	x2, x2, x2, lsl #2
    3388:	d37df042 	lsl	x2, x2, #3
    338c:	8b0200a4 	add	x4, x5, x2
    3390:	f9401083 	ldr	x3, [x4, #32]
    3394:	b4000263 	cbz	x3, 33e0 <fwp_rc_free_arr+0x80>
    3398:	386268a2 	ldrb	w2, [x5, x2]
    339c:	7100085f 	cmp	w2, #0x2
    33a0:	540001c0 	b.eq	33d8 <fwp_rc_free_arr+0x78>  // b.none
    33a4:	7100045f 	cmp	w2, #0x1
    33a8:	540001c1 	b.ne	33e0 <fwp_rc_free_arr+0x80>  // b.any
    33ac:	29430885 	ldp	w5, w2, [x4, #24]
    33b0:	92403c21 	and	x1, x1, #0xffff
    33b4:	9b057c21 	mul	x1, x1, x5
    33b8:	d360fc21 	lsr	x1, x1, #32
    33bc:	eb02003f 	cmp	x1, x2
    33c0:	54000102 	b.cs	33e0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    33c4:	8b010063 	add	x3, x3, x1
    33c8:	39400061 	ldrb	w1, [x3]
    33cc:	7100043f 	cmp	w1, #0x1
    33d0:	54000081 	b.ne	33e0 <fwp_rc_free_arr+0x80>  // b.any
    33d4:	17fffe93 	b	2e20 <fwp_mem_free>
    33d8:	72003c3f 	tst	w1, #0xffff
    33dc:	54ffff60 	b.eq	33c8 <fwp_rc_free_arr+0x68>  // b.none
    33e0:	d65f03c0 	ret

00000000000033e4 <fwp_heap_alloc>:
    33e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    33e8:	f140101f 	cmp	x0, #0x4, lsl #12
    33ec:	910003fd 	mov	x29, sp
    33f0:	a90153f3 	stp	x19, x20, [sp, #16]
    33f4:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xcd0>
    33f8:	91144293 	add	x19, x20, #0x510
    33fc:	b953a662 	ldr	w2, [x19, #5028]
    3400:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3404:	54000640 	b.eq	34cc <fwp_heap_alloc+0xe8>  // b.none
    3408:	91003c03 	add	x3, x0, #0xf
    340c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3410:	937c7c22 	sbfiz	x2, x1, #4, #32
    3414:	8b431263 	add	x3, x19, x3, lsr #4
    3418:	cb21c042 	sub	x2, x2, w1, sxtw
    341c:	d37ae442 	lsl	x2, x2, #6
    3420:	397e8063 	ldrb	w3, [x3, #4000]
    3424:	910f0064 	add	x4, x3, #0x3c0
    3428:	8b030463 	add	x3, x3, x3, lsl #1
    342c:	8b030c43 	add	x3, x2, x3, lsl #3
    3430:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    3434:	2a1603f5 	mov	w21, w22
    3438:	f8636a64 	ldr	x4, [x19, x3]
    343c:	b4000384 	cbz	x4, 34ac <fwp_heap_alloc+0xc8>
    3440:	f9400085 	ldr	x5, [x4]
    3444:	7100043f 	cmp	w1, #0x1
    3448:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    344c:	aa0403e0 	mov	x0, x4
    3450:	aa2503e5 	mvn	x5, x5
    3454:	52800001 	mov	w1, #0x0                   	// #0
    3458:	f8236a65 	str	x5, [x19, x3]
    345c:	97fff805 	bl	1470 <memset@plt>
    3460:	aa0003e4 	mov	x4, x0
    3464:	f94a1260 	ldr	x0, [x19, #5152]
    3468:	ab150000 	adds	x0, x0, x21
    346c:	54000442 	b.cs	34f4 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    3470:	f94a1661 	ldr	x1, [x19, #5160]
    3474:	f90a1260 	str	x0, [x19, #5152]
    3478:	eb01001f 	cmp	x0, x1
    347c:	54000049 	b.ls	3484 <fwp_heap_alloc+0xa0>  // b.plast
    3480:	f90a1660 	str	x0, [x19, #5160]
    3484:	91144294 	add	x20, x20, #0x510
    3488:	1e6302c1 	ucvtf	d1, w22
    348c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3490:	aa0403e0 	mov	x0, x4
    3494:	fd4a1e80 	ldr	d0, [x20, #5176]
    3498:	1e612800 	fadd	d0, d0, d1
    349c:	fd0a1e80 	str	d0, [x20, #5176]
    34a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    34a8:	d65f03c0 	ret
    34ac:	8b030263 	add	x3, x19, x3
    34b0:	f9400464 	ldr	x4, [x3, #8]
    34b4:	b40000a4 	cbz	x4, 34c8 <fwp_heap_alloc+0xe4>
    34b8:	f9400862 	ldr	x2, [x3, #16]
    34bc:	cb040042 	sub	x2, x2, x4
    34c0:	eb15005f 	cmp	x2, x21
    34c4:	540000a2 	b.cs	34d8 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    34c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    34d4:	17ffff1b 	b	3140 <fwp_heap_alloc_slow>
    34d8:	7100043f 	cmp	w1, #0x1
    34dc:	8b150085 	add	x5, x4, x21
    34e0:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    34e4:	52800001 	mov	w1, #0x0                   	// #0
    34e8:	aa0403e0 	mov	x0, x4
    34ec:	f9000465 	str	x5, [x3, #8]
    34f0:	17ffffdb 	b	345c <fwp_heap_alloc+0x78>
    34f4:	97fff9a7 	bl	1b90 <fwp_heap_oom>
    34f8:	d503201f 	nop
    34fc:	d503201f 	nop

0000000000003500 <fwp_data.part.0.constprop.0>:
    3500:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3504:	910003fd 	mov	x29, sp
    3508:	a90153f3 	stp	x19, x20, [sp, #16]
    350c:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xcd0>
    3510:	91144282 	add	x2, x20, #0x510
    3514:	a9025bf5 	stp	x21, x22, [sp, #32]
    3518:	aa0003f5 	mov	x21, x0
    351c:	b953a440 	ldr	w0, [x2, #5028]
    3520:	34000700 	cbz	w0, 3600 <fwp_data.part.0.constprop.0+0x100>
    3524:	f9001bf7 	str	x23, [sp, #48]
    3528:	397e8841 	ldrb	w1, [x2, #4002]
    352c:	910f0020 	add	x0, x1, #0x3c0
    3530:	8b010421 	add	x1, x1, x1, lsl #1
    3534:	d37df021 	lsl	x1, x1, #3
    3538:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    353c:	2a1703f6 	mov	w22, w23
    3540:	f8616853 	ldr	x19, [x2, x1]
    3544:	b40004f3 	cbz	x19, 35e0 <fwp_data.part.0.constprop.0+0xe0>
    3548:	f9400260 	ldr	x0, [x19]
    354c:	aa2003e0 	mvn	x0, x0
    3550:	f8216840 	str	x0, [x2, x1]
    3554:	f10062df 	cmp	x22, #0x18
    3558:	540000e9 	b.ls	3574 <fwp_data.part.0.constprop.0+0x74>  // b.plast
    355c:	d10066c2 	sub	x2, x22, #0x19
    3560:	91006260 	add	x0, x19, #0x18
    3564:	927df042 	and	x2, x2, #0xfffffffffffffff8
    3568:	52800001 	mov	w1, #0x0                   	// #0
    356c:	91002042 	add	x2, x2, #0x8
    3570:	97fff7c0 	bl	1470 <memset@plt>
    3574:	91144281 	add	x1, x20, #0x510
    3578:	f94a1020 	ldr	x0, [x1, #5152]
    357c:	ab160000 	adds	x0, x0, x22
    3580:	54000502 	b.cs	3620 <fwp_data.part.0.constprop.0+0x120>  // b.hs, b.nlast
    3584:	f94a1422 	ldr	x2, [x1, #5160]
    3588:	f90a1020 	str	x0, [x1, #5152]
    358c:	eb02001f 	cmp	x0, x2
    3590:	54000049 	b.ls	3598 <fwp_data.part.0.constprop.0+0x98>  // b.plast
    3594:	f90a1420 	str	x0, [x1, #5160]
    3598:	91144294 	add	x20, x20, #0x510
    359c:	1e6302e1 	ucvtf	d1, w23
    35a0:	f9401bf7 	ldr	x23, [sp, #48]
    35a4:	fd4a1e80 	ldr	d0, [x20, #5176]
    35a8:	1e612800 	fadd	d0, d0, d1
    35ac:	fd0a1e80 	str	d0, [x20, #5176]
    35b0:	d0000020 	adrp	x0, 9000 <msg.3+0x20>
    35b4:	fd400800 	ldr	d0, [x0, #16]
    35b8:	aa1303e0 	mov	x0, x19
    35bc:	fd000260 	str	d0, [x19]
    35c0:	f94002a1 	ldr	x1, [x21]
    35c4:	f9000661 	str	x1, [x19, #8]
    35c8:	f94006a1 	ldr	x1, [x21, #8]
    35cc:	f9000a61 	str	x1, [x19, #16]
    35d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    35d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    35dc:	d65f03c0 	ret
    35e0:	8b010042 	add	x2, x2, x1
    35e4:	f9400453 	ldr	x19, [x2, #8]
    35e8:	b40000b3 	cbz	x19, 35fc <fwp_data.part.0.constprop.0+0xfc>
    35ec:	f9400840 	ldr	x0, [x2, #16]
    35f0:	cb130000 	sub	x0, x0, x19
    35f4:	eb0002df 	cmp	x22, x0
    35f8:	540000e9 	b.ls	3614 <fwp_data.part.0.constprop.0+0x114>  // b.plast
    35fc:	f9401bf7 	ldr	x23, [sp, #48]
    3600:	52800001 	mov	w1, #0x0                   	// #0
    3604:	d2800300 	mov	x0, #0x18                  	// #24
    3608:	97ffff77 	bl	33e4 <fwp_heap_alloc>
    360c:	aa0003f3 	mov	x19, x0
    3610:	17ffffe8 	b	35b0 <fwp_data.part.0.constprop.0+0xb0>
    3614:	8b160260 	add	x0, x19, x22
    3618:	f9000440 	str	x0, [x2, #8]
    361c:	17ffffce 	b	3554 <fwp_data.part.0.constprop.0+0x54>
    3620:	97fff95c 	bl	1b90 <fwp_heap_oom>

0000000000003624 <fwp_array_new_packed.constprop.0>:
    3624:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3628:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    362c:	910003fd 	mov	x29, sp
    3630:	f9000bf3 	str	x19, [sp, #16]
    3634:	eb01001f 	cmp	x0, x1
    3638:	54000148 	b.hi	3660 <fwp_array_new_packed.constprop.0+0x3c>  // b.pmore
    363c:	aa0003f3 	mov	x19, x0
    3640:	91000400 	add	x0, x0, #0x1
    3644:	52800021 	mov	w1, #0x1                   	// #1
    3648:	d37df000 	lsl	x0, x0, #3
    364c:	97ffff66 	bl	33e4 <fwp_heap_alloc>
    3650:	f9000013 	str	x19, [x0]
    3654:	f9400bf3 	ldr	x19, [sp, #16]
    3658:	a8c27bfd 	ldp	x29, x30, [sp], #32
    365c:	d65f03c0 	ret
    3660:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    3664:	91338000 	add	x0, x0, #0xce0
    3668:	97fffa8e 	bl	20a0 <fwp_trap>
    366c:	d503201f 	nop

0000000000003670 <fwp_drop0>:
    3670:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3674:	910003fd 	mov	x29, sp
    3678:	a90153f3 	stp	x19, x20, [sp, #16]
    367c:	f90013f5 	str	x21, [sp, #32]
    3680:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    3684:	911442b4 	add	x20, x21, #0x510
    3688:	f949da81 	ldr	x1, [x20, #5040]
    368c:	f949ee82 	ldr	x2, [x20, #5080]
    3690:	cb010001 	sub	x1, x0, x1
    3694:	eb02403f 	cmp	x1, x2, lsl #16
    3698:	54000382 	b.cs	3708 <fwp_drop0+0x98>  // b.hs, b.nlast
    369c:	d350fc22 	lsr	x2, x1, #16
    36a0:	f949fe84 	ldr	x4, [x20, #5112]
    36a4:	8b020842 	add	x2, x2, x2, lsl #2
    36a8:	d37df042 	lsl	x2, x2, #3
    36ac:	8b020083 	add	x3, x4, x2
    36b0:	f9401073 	ldr	x19, [x3, #32]
    36b4:	b40002b3 	cbz	x19, 3708 <fwp_drop0+0x98>
    36b8:	38626882 	ldrb	w2, [x4, x2]
    36bc:	7100085f 	cmp	w2, #0x2
    36c0:	540002c0 	b.eq	3718 <fwp_drop0+0xa8>  // b.none
    36c4:	7100045f 	cmp	w2, #0x1
    36c8:	54000201 	b.ne	3708 <fwp_drop0+0x98>  // b.any
    36cc:	29430864 	ldp	w4, w2, [x3, #24]
    36d0:	92403c21 	and	x1, x1, #0xffff
    36d4:	9b047c21 	mul	x1, x1, x4
    36d8:	d360fc21 	lsr	x1, x1, #32
    36dc:	eb02003f 	cmp	x1, x2
    36e0:	54000142 	b.cs	3708 <fwp_drop0+0x98>  // b.hs, b.nlast
    36e4:	8b010273 	add	x19, x19, x1
    36e8:	39400261 	ldrb	w1, [x19]
    36ec:	340000e1 	cbz	w1, 3708 <fwp_drop0+0x98>
    36f0:	7100043f 	cmp	w1, #0x1
    36f4:	540001e0 	b.eq	3730 <fwp_drop0+0xc0>  // b.none
    36f8:	7103fc3f 	cmp	w1, #0xff
    36fc:	540002e0 	b.eq	3758 <fwp_drop0+0xe8>  // b.none
    3700:	51000421 	sub	w1, w1, #0x1
    3704:	39000261 	strb	w1, [x19]
    3708:	a94153f3 	ldp	x19, x20, [sp, #16]
    370c:	f94013f5 	ldr	x21, [sp, #32]
    3710:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3714:	d65f03c0 	ret
    3718:	72003c3f 	tst	w1, #0xffff
    371c:	54fffe60 	b.eq	36e8 <fwp_drop0+0x78>  // b.none
    3720:	a94153f3 	ldp	x19, x20, [sp, #16]
    3724:	f94013f5 	ldr	x21, [sp, #32]
    3728:	a8c37bfd 	ldp	x29, x30, [sp], #48
    372c:	d65f03c0 	ret
    3730:	f9400813 	ldr	x19, [x0, #16]
    3734:	97ffff0b 	bl	3360 <fwp_rc_free_arr>
    3738:	911442a0 	add	x0, x21, #0x510
    373c:	f949d801 	ldr	x1, [x0, #5040]
    3740:	f949ec00 	ldr	x0, [x0, #5080]
    3744:	cb010261 	sub	x1, x19, x1
    3748:	eb00403f 	cmp	x1, x0, lsl #16
    374c:	54fffde2 	b.cs	3708 <fwp_drop0+0x98>  // b.hs, b.nlast
    3750:	aa1303e0 	mov	x0, x19
    3754:	17ffffd2 	b	369c <fwp_drop0+0x2c>
    3758:	ca534660 	eor	x0, x19, x19, lsr #17
    375c:	911442b5 	add	x21, x21, #0x510
    3760:	ca402400 	eor	x0, x0, x0, lsr #9
    3764:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3768:	f94a2400 	ldr	x0, [x0, #5192]
    376c:	b5000080 	cbnz	x0, 377c <fwp_drop0+0x10c>
    3770:	14000010 	b	37b0 <fwp_drop0+0x140>
    3774:	f9400800 	ldr	x0, [x0, #16]
    3778:	b40001c0 	cbz	x0, 37b0 <fwp_drop0+0x140>
    377c:	f9400001 	ldr	x1, [x0]
    3780:	eb13003f 	cmp	x1, x19
    3784:	54ffff81 	b.ne	3774 <fwp_drop0+0x104>  // b.any
    3788:	f9400401 	ldr	x1, [x0, #8]
    378c:	d1000421 	sub	x1, x1, #0x1
    3790:	f9000401 	str	x1, [x0, #8]
    3794:	f103f83f 	cmp	x1, #0xfe
    3798:	54fffb81 	b.ne	3708 <fwp_drop0+0x98>  // b.any
    379c:	aa1303e0 	mov	x0, x19
    37a0:	97fffd01 	bl	2ba4 <fwp_rc_forget_slot>
    37a4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    37a8:	39000260 	strb	w0, [x19]
    37ac:	17ffffd7 	b	3708 <fwp_drop0+0x98>
    37b0:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    37b4:	9132e000 	add	x0, x0, #0xcb8
    37b8:	97fffa3a 	bl	20a0 <fwp_trap>
    37bc:	d503201f 	nop

00000000000037c0 <fwp_drop1>:
    37c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    37c4:	910003fd 	mov	x29, sp
    37c8:	a90153f3 	stp	x19, x20, [sp, #16]
    37cc:	f90013f5 	str	x21, [sp, #32]
    37d0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    37d4:	911442b4 	add	x20, x21, #0x510
    37d8:	f949da81 	ldr	x1, [x20, #5040]
    37dc:	f949ee82 	ldr	x2, [x20, #5080]
    37e0:	cb010001 	sub	x1, x0, x1
    37e4:	eb02403f 	cmp	x1, x2, lsl #16
    37e8:	54000382 	b.cs	3858 <fwp_drop1+0x98>  // b.hs, b.nlast
    37ec:	d350fc22 	lsr	x2, x1, #16
    37f0:	f949fe84 	ldr	x4, [x20, #5112]
    37f4:	8b020842 	add	x2, x2, x2, lsl #2
    37f8:	d37df042 	lsl	x2, x2, #3
    37fc:	8b020083 	add	x3, x4, x2
    3800:	f9401073 	ldr	x19, [x3, #32]
    3804:	b40002b3 	cbz	x19, 3858 <fwp_drop1+0x98>
    3808:	38626882 	ldrb	w2, [x4, x2]
    380c:	7100085f 	cmp	w2, #0x2
    3810:	540002c0 	b.eq	3868 <fwp_drop1+0xa8>  // b.none
    3814:	7100045f 	cmp	w2, #0x1
    3818:	54000201 	b.ne	3858 <fwp_drop1+0x98>  // b.any
    381c:	29430864 	ldp	w4, w2, [x3, #24]
    3820:	92403c21 	and	x1, x1, #0xffff
    3824:	9b047c21 	mul	x1, x1, x4
    3828:	d360fc21 	lsr	x1, x1, #32
    382c:	eb02003f 	cmp	x1, x2
    3830:	54000142 	b.cs	3858 <fwp_drop1+0x98>  // b.hs, b.nlast
    3834:	8b010273 	add	x19, x19, x1
    3838:	39400261 	ldrb	w1, [x19]
    383c:	340000e1 	cbz	w1, 3858 <fwp_drop1+0x98>
    3840:	7100043f 	cmp	w1, #0x1
    3844:	540001e0 	b.eq	3880 <fwp_drop1+0xc0>  // b.none
    3848:	7103fc3f 	cmp	w1, #0xff
    384c:	540002e0 	b.eq	38a8 <fwp_drop1+0xe8>  // b.none
    3850:	51000421 	sub	w1, w1, #0x1
    3854:	39000261 	strb	w1, [x19]
    3858:	a94153f3 	ldp	x19, x20, [sp, #16]
    385c:	f94013f5 	ldr	x21, [sp, #32]
    3860:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3864:	d65f03c0 	ret
    3868:	72003c3f 	tst	w1, #0xffff
    386c:	54fffe60 	b.eq	3838 <fwp_drop1+0x78>  // b.none
    3870:	a94153f3 	ldp	x19, x20, [sp, #16]
    3874:	f94013f5 	ldr	x21, [sp, #32]
    3878:	a8c37bfd 	ldp	x29, x30, [sp], #48
    387c:	d65f03c0 	ret
    3880:	f9400813 	ldr	x19, [x0, #16]
    3884:	97fffeb7 	bl	3360 <fwp_rc_free_arr>
    3888:	911442a0 	add	x0, x21, #0x510
    388c:	f949d801 	ldr	x1, [x0, #5040]
    3890:	f949ec00 	ldr	x0, [x0, #5080]
    3894:	cb010261 	sub	x1, x19, x1
    3898:	eb00403f 	cmp	x1, x0, lsl #16
    389c:	54fffde2 	b.cs	3858 <fwp_drop1+0x98>  // b.hs, b.nlast
    38a0:	aa1303e0 	mov	x0, x19
    38a4:	17ffffd2 	b	37ec <fwp_drop1+0x2c>
    38a8:	ca534660 	eor	x0, x19, x19, lsr #17
    38ac:	911442b5 	add	x21, x21, #0x510
    38b0:	ca402400 	eor	x0, x0, x0, lsr #9
    38b4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    38b8:	f94a2400 	ldr	x0, [x0, #5192]
    38bc:	b5000080 	cbnz	x0, 38cc <fwp_drop1+0x10c>
    38c0:	14000010 	b	3900 <fwp_drop1+0x140>
    38c4:	f9400800 	ldr	x0, [x0, #16]
    38c8:	b40001c0 	cbz	x0, 3900 <fwp_drop1+0x140>
    38cc:	f9400001 	ldr	x1, [x0]
    38d0:	eb13003f 	cmp	x1, x19
    38d4:	54ffff81 	b.ne	38c4 <fwp_drop1+0x104>  // b.any
    38d8:	f9400401 	ldr	x1, [x0, #8]
    38dc:	d1000421 	sub	x1, x1, #0x1
    38e0:	f9000401 	str	x1, [x0, #8]
    38e4:	f103f83f 	cmp	x1, #0xfe
    38e8:	54fffb81 	b.ne	3858 <fwp_drop1+0x98>  // b.any
    38ec:	aa1303e0 	mov	x0, x19
    38f0:	97fffcad 	bl	2ba4 <fwp_rc_forget_slot>
    38f4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    38f8:	39000260 	strb	w0, [x19]
    38fc:	17ffffd7 	b	3858 <fwp_drop1+0x98>
    3900:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    3904:	9132e000 	add	x0, x0, #0xcb8
    3908:	97fff9e6 	bl	20a0 <fwp_trap>
    390c:	d503201f 	nop

0000000000003910 <fwp_task_dispose>:
    3910:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3914:	910003fd 	mov	x29, sp
    3918:	f9000bf3 	str	x19, [sp, #16]
    391c:	aa0003f3 	mov	x19, x0
    3920:	39414000 	ldrb	w0, [x0, #80]
    3924:	36000720 	tbz	w0, #0, 3a08 <fwp_task_dispose+0xf8>
    3928:	f9400a60 	ldr	x0, [x19, #16]
    392c:	b50006e0 	cbnz	x0, 3a08 <fwp_task_dispose+0xf8>
    3930:	a9478660 	ldp	x0, x1, [x19, #120]
    3934:	39014e7f 	strb	wzr, [x19, #83]
    3938:	f9003e7f 	str	xzr, [x19, #120]
    393c:	f100003f 	cmp	x1, #0x0
    3940:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3944:	54000040 	b.eq	394c <fwp_task_dispose+0x3c>  // b.none
    3948:	d63f0020 	blr	x1
    394c:	f9405660 	ldr	x0, [x19, #168]
    3950:	97fffd34 	bl	2e20 <fwp_mem_free>
    3954:	f900567f 	str	xzr, [x19, #168]
    3958:	b9405e60 	ldr	w0, [x19, #92]
    395c:	7100041f 	cmp	w0, #0x1
    3960:	54000420 	b.eq	39e4 <fwp_task_dispose+0xd4>  // b.none
    3964:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcd0>
    3968:	91144042 	add	x2, x2, #0x510
    396c:	f949d840 	ldr	x0, [x2, #5040]
    3970:	f949ec41 	ldr	x1, [x2, #5080]
    3974:	cb000260 	sub	x0, x19, x0
    3978:	eb01401f 	cmp	x0, x1, lsl #16
    397c:	540002e2 	b.cs	39d8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3980:	d350fc01 	lsr	x1, x0, #16
    3984:	f949fc44 	ldr	x4, [x2, #5112]
    3988:	8b010821 	add	x1, x1, x1, lsl #2
    398c:	d37df021 	lsl	x1, x1, #3
    3990:	8b010083 	add	x3, x4, x1
    3994:	f9401062 	ldr	x2, [x3, #32]
    3998:	b4000202 	cbz	x2, 39d8 <fwp_task_dispose+0xc8>
    399c:	38616881 	ldrb	w1, [x4, x1]
    39a0:	7100083f 	cmp	w1, #0x2
    39a4:	54000280 	b.eq	39f4 <fwp_task_dispose+0xe4>  // b.none
    39a8:	7100043f 	cmp	w1, #0x1
    39ac:	54000161 	b.ne	39d8 <fwp_task_dispose+0xc8>  // b.any
    39b0:	29430464 	ldp	w4, w1, [x3, #24]
    39b4:	92403c00 	and	x0, x0, #0xffff
    39b8:	9b047c00 	mul	x0, x0, x4
    39bc:	d360fc00 	lsr	x0, x0, #32
    39c0:	eb01001f 	cmp	x0, x1
    39c4:	540000a2 	b.cs	39d8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    39c8:	8b000042 	add	x2, x2, x0
    39cc:	39400040 	ldrb	w0, [x2]
    39d0:	7100041f 	cmp	w0, #0x1
    39d4:	54000080 	b.eq	39e4 <fwp_task_dispose+0xd4>  // b.none
    39d8:	f9400bf3 	ldr	x19, [sp, #16]
    39dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39e0:	d65f03c0 	ret
    39e4:	aa1303e0 	mov	x0, x19
    39e8:	f9400bf3 	ldr	x19, [sp, #16]
    39ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39f0:	17fffd0c 	b	2e20 <fwp_mem_free>
    39f4:	72003c1f 	tst	w0, #0xffff
    39f8:	54fffea0 	b.eq	39cc <fwp_task_dispose+0xbc>  // b.none
    39fc:	f9400bf3 	ldr	x19, [sp, #16]
    3a00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3a04:	d65f03c0 	ret
    3a08:	97fff6ba 	bl	14f0 <abort@plt>
    3a0c:	d503201f 	nop

0000000000003a10 <fwp_free_zombie>:
    3a10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3a14:	910003fd 	mov	x29, sp
    3a18:	a90153f3 	stp	x19, x20, [sp, #16]
    3a1c:	b00000f4 	adrp	x20, 20000 <__data_start>
    3a20:	9101c281 	add	x1, x20, #0x70
    3a24:	f9401c33 	ldr	x19, [x1, #56]
    3a28:	b4000333 	cbz	x19, 3a8c <fwp_free_zombie+0x7c>
    3a2c:	f9400420 	ldr	x0, [x1, #8]
    3a30:	eb00027f 	cmp	x19, x0
    3a34:	540002c0 	b.eq	3a8c <fwp_free_zombie+0x7c>  // b.none
    3a38:	b9404022 	ldr	w2, [x1, #64]
    3a3c:	f9400a60 	ldr	x0, [x19, #16]
    3a40:	7100fc5f 	cmp	w2, #0x3f
    3a44:	5400078c 	b.gt	3b34 <fwp_free_zombie+0x124>
    3a48:	91014023 	add	x3, x1, #0x50
    3a4c:	11000444 	add	w4, w2, #0x1
    3a50:	b9004024 	str	w4, [x1, #64]
    3a54:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3a58:	f822d860 	str	x0, [x3, w2, sxtw #3]
    3a5c:	a9530261 	ldp	x1, x0, [x19, #304]
    3a60:	b4000741 	cbz	x1, 3b48 <fwp_free_zombie+0x138>
    3a64:	f9009c20 	str	x0, [x1, #312]
    3a68:	b4000040 	cbz	x0, 3a70 <fwp_free_zombie+0x60>
    3a6c:	f9009801 	str	x1, [x0, #304]
    3a70:	9101c294 	add	x20, x20, #0x70
    3a74:	b9405e60 	ldr	w0, [x19, #92]
    3a78:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    3a7c:	f9001e9f 	str	xzr, [x20, #56]
    3a80:	34000140 	cbz	w0, 3aa8 <fwp_free_zombie+0x98>
    3a84:	7100041f 	cmp	w0, #0x1
    3a88:	54000080 	b.eq	3a98 <fwp_free_zombie+0x88>  // b.none
    3a8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3a94:	d65f03c0 	ret
    3a98:	aa1303e0 	mov	x0, x19
    3a9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3aa0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3aa4:	17ffff9b 	b	3910 <fwp_task_dispose>
    3aa8:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xcd0>
    3aac:	91144082 	add	x2, x4, #0x510
    3ab0:	f949d841 	ldr	x1, [x2, #5040]
    3ab4:	f949ec40 	ldr	x0, [x2, #5080]
    3ab8:	cb010261 	sub	x1, x19, x1
    3abc:	eb00403f 	cmp	x1, x0, lsl #16
    3ac0:	54fffe62 	b.cs	3a8c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3ac4:	d350fc20 	lsr	x0, x1, #16
    3ac8:	f949fc43 	ldr	x3, [x2, #5112]
    3acc:	8b000800 	add	x0, x0, x0, lsl #2
    3ad0:	d37df000 	lsl	x0, x0, #3
    3ad4:	8b000062 	add	x2, x3, x0
    3ad8:	f9401054 	ldr	x20, [x2, #32]
    3adc:	b4fffd94 	cbz	x20, 3a8c <fwp_free_zombie+0x7c>
    3ae0:	38606860 	ldrb	w0, [x3, x0]
    3ae4:	7100081f 	cmp	w0, #0x2
    3ae8:	54000360 	b.eq	3b54 <fwp_free_zombie+0x144>  // b.none
    3aec:	7100041f 	cmp	w0, #0x1
    3af0:	54fffce1 	b.ne	3a8c <fwp_free_zombie+0x7c>  // b.any
    3af4:	29430043 	ldp	w3, w0, [x2, #24]
    3af8:	92403c21 	and	x1, x1, #0xffff
    3afc:	9b037c21 	mul	x1, x1, x3
    3b00:	d360fc21 	lsr	x1, x1, #32
    3b04:	eb00003f 	cmp	x1, x0
    3b08:	54fffc22 	b.cs	3a8c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3b0c:	8b010294 	add	x20, x20, x1
    3b10:	39400280 	ldrb	w0, [x20]
    3b14:	34fffbc0 	cbz	w0, 3a8c <fwp_free_zombie+0x7c>
    3b18:	7100041f 	cmp	w0, #0x1
    3b1c:	54fffbe0 	b.eq	3a98 <fwp_free_zombie+0x88>  // b.none
    3b20:	7103fc1f 	cmp	w0, #0xff
    3b24:	540001e0 	b.eq	3b60 <fwp_free_zombie+0x150>  // b.none
    3b28:	51000400 	sub	w0, w0, #0x1
    3b2c:	39000280 	strb	w0, [x20]
    3b30:	17ffffd7 	b	3a8c <fwp_free_zombie+0x7c>
    3b34:	f9400e61 	ldr	x1, [x19, #24]
    3b38:	97fff6a2 	bl	15c0 <munmap@plt>
    3b3c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3b40:	a9530261 	ldp	x1, x0, [x19, #304]
    3b44:	b5fff901 	cbnz	x1, 3a64 <fwp_free_zombie+0x54>
    3b48:	9101c282 	add	x2, x20, #0x70
    3b4c:	f9012840 	str	x0, [x2, #592]
    3b50:	17ffffc6 	b	3a68 <fwp_free_zombie+0x58>
    3b54:	72003c3f 	tst	w1, #0xffff
    3b58:	54fff9a1 	b.ne	3a8c <fwp_free_zombie+0x7c>  // b.any
    3b5c:	17ffffed 	b	3b10 <fwp_free_zombie+0x100>
    3b60:	ca544680 	eor	x0, x20, x20, lsr #17
    3b64:	91144084 	add	x4, x4, #0x510
    3b68:	ca402400 	eor	x0, x0, x0, lsr #9
    3b6c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3b70:	f94a2400 	ldr	x0, [x0, #5192]
    3b74:	b5000080 	cbnz	x0, 3b84 <fwp_free_zombie+0x174>
    3b78:	14000010 	b	3bb8 <fwp_free_zombie+0x1a8>
    3b7c:	f9400800 	ldr	x0, [x0, #16]
    3b80:	b40001c0 	cbz	x0, 3bb8 <fwp_free_zombie+0x1a8>
    3b84:	f9400001 	ldr	x1, [x0]
    3b88:	eb14003f 	cmp	x1, x20
    3b8c:	54ffff81 	b.ne	3b7c <fwp_free_zombie+0x16c>  // b.any
    3b90:	f9400401 	ldr	x1, [x0, #8]
    3b94:	d1000421 	sub	x1, x1, #0x1
    3b98:	f9000401 	str	x1, [x0, #8]
    3b9c:	f103f83f 	cmp	x1, #0xfe
    3ba0:	54fff761 	b.ne	3a8c <fwp_free_zombie+0x7c>  // b.any
    3ba4:	aa1403e0 	mov	x0, x20
    3ba8:	97fffbff 	bl	2ba4 <fwp_rc_forget_slot>
    3bac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3bb0:	39000280 	strb	w0, [x20]
    3bb4:	17ffffb6 	b	3a8c <fwp_free_zombie+0x7c>
    3bb8:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    3bbc:	9132e000 	add	x0, x0, #0xcb8
    3bc0:	97fff938 	bl	20a0 <fwp_trap>

0000000000003bc4 <fwp_block>:
    3bc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3bc8:	910003fd 	mov	x29, sp
    3bcc:	a90153f3 	stp	x19, x20, [sp, #16]
    3bd0:	b00000f3 	adrp	x19, 20000 <__data_start>
    3bd4:	9101c274 	add	x20, x19, #0x70
    3bd8:	f9401682 	ldr	x2, [x20, #40]
    3bdc:	b4000622 	cbz	x2, 3ca0 <fwp_block+0xdc>
    3be0:	9101c261 	add	x1, x19, #0x70
    3be4:	f9408040 	ldr	x0, [x2, #256]
    3be8:	f9001420 	str	x0, [x1, #40]
    3bec:	b4000680 	cbz	x0, 3cbc <fwp_block+0xf8>
    3bf0:	9101c263 	add	x3, x19, #0x70
    3bf4:	3901505f 	strb	wzr, [x2, #84]
    3bf8:	f9400464 	ldr	x4, [x3, #8]
    3bfc:	eb02009f 	cmp	x4, x2
    3c00:	54000440 	b.eq	3c88 <fwp_block+0xc4>  // b.none
    3c04:	f9412c65 	ldr	x5, [x3, #600]
    3c08:	f9000462 	str	x2, [x3, #8]
    3c0c:	f9400441 	ldr	x1, [x2, #8]
    3c10:	f9004885 	str	x5, [x4, #144]
    3c14:	f9413065 	ldr	x5, [x3, #608]
    3c18:	f9004c85 	str	x5, [x4, #152]
    3c1c:	f9413465 	ldr	x5, [x3, #616]
    3c20:	f9005085 	str	x5, [x4, #160]
    3c24:	f9413865 	ldr	x5, [x3, #624]
    3c28:	f9005485 	str	x5, [x4, #168]
    3c2c:	f9413c65 	ldr	x5, [x3, #632]
    3c30:	f9005885 	str	x5, [x4, #176]
    3c34:	f9414065 	ldr	x5, [x3, #640]
    3c38:	f9005c85 	str	x5, [x4, #184]
    3c3c:	f9414465 	ldr	x5, [x3, #648]
    3c40:	f9006085 	str	x5, [x4, #192]
    3c44:	f9400480 	ldr	x0, [x4, #8]
    3c48:	f9404844 	ldr	x4, [x2, #144]
    3c4c:	f9012c64 	str	x4, [x3, #600]
    3c50:	f9404c44 	ldr	x4, [x2, #152]
    3c54:	f9013064 	str	x4, [x3, #608]
    3c58:	f9405044 	ldr	x4, [x2, #160]
    3c5c:	f9013464 	str	x4, [x3, #616]
    3c60:	f9405444 	ldr	x4, [x2, #168]
    3c64:	f9013864 	str	x4, [x3, #624]
    3c68:	f9405844 	ldr	x4, [x2, #176]
    3c6c:	f9013c64 	str	x4, [x3, #632]
    3c70:	a94b8844 	ldp	x4, x2, [x2, #184]
    3c74:	f9014064 	str	x4, [x3, #640]
    3c78:	f9014462 	str	x2, [x3, #648]
    3c7c:	97fff621 	bl	1500 <swapcontext@plt>
    3c80:	97ffff64 	bl	3a10 <fwp_free_zombie>
    3c84:	d503201f 	nop
    3c88:	9101c260 	add	x0, x19, #0x70
    3c8c:	b9429000 	ldr	w0, [x0, #656]
    3c90:	340001a0 	cbz	w0, 3cc4 <fwp_block+0x100>
    3c94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c98:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c9c:	d65f03c0 	ret
    3ca0:	97fffb34 	bl	2970 <fwp_poll_events>
    3ca4:	f9401682 	ldr	x2, [x20, #40]
    3ca8:	b4ffffc2 	cbz	x2, 3ca0 <fwp_block+0xdc>
    3cac:	9101c261 	add	x1, x19, #0x70
    3cb0:	f9408040 	ldr	x0, [x2, #256]
    3cb4:	f9001420 	str	x0, [x1, #40]
    3cb8:	b5fff9c0 	cbnz	x0, 3bf0 <fwp_block+0x2c>
    3cbc:	f900103f 	str	xzr, [x1, #32]
    3cc0:	17ffffcc 	b	3bf0 <fwp_block+0x2c>
    3cc4:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    3cc8:	9133c000 	add	x0, x0, #0xcf0
    3ccc:	97fff659 	bl	1630 <getenv@plt>
    3cd0:	5284e202 	mov	w2, #0x2710                	// #10000
    3cd4:	b4000060 	cbz	x0, 3ce0 <fwp_block+0x11c>
    3cd8:	39400001 	ldrb	w1, [x0]
    3cdc:	350000c1 	cbnz	w1, 3cf4 <fwp_block+0x130>
    3ce0:	9101c273 	add	x19, x19, #0x70
    3ce4:	b9029262 	str	w2, [x19, #656]
    3ce8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3cec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3cf0:	d65f03c0 	ret
    3cf4:	52800142 	mov	w2, #0xa                   	// #10
    3cf8:	d2800001 	mov	x1, #0x0                   	// #0
    3cfc:	97fff59d 	bl	1370 <strtoll@plt>
    3d00:	d1000403 	sub	x3, x0, #0x1
    3d04:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3d08:	eb02007f 	cmp	x3, x2
    3d0c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3d10:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3d14:	17fffff3 	b	3ce0 <fwp_block+0x11c>
    3d18:	d503201f 	nop
    3d1c:	d503201f 	nop

0000000000003d20 <fwp_write.constprop.0>:
    3d20:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3d24:	910003fd 	mov	x29, sp
    3d28:	900000e3 	adrp	x3, 1f000 <__FRAME_END__+0x152b8>
    3d2c:	f947f463 	ldr	x3, [x3, #4072]
    3d30:	a90153f3 	stp	x19, x20, [sp, #16]
    3d34:	d10943ff 	sub	sp, sp, #0x250
    3d38:	aa0003f4 	mov	x20, x0
    3d3c:	b9400040 	ldr	w0, [x2]
    3d40:	aa0103f3 	mov	x19, x1
    3d44:	f9400061 	ldr	x1, [x3]
    3d48:	f90127e1 	str	x1, [sp, #584]
    3d4c:	d2800001 	mov	x1, #0x0                   	// #0
    3d50:	7100641f 	cmp	w0, #0x19
    3d54:	540003e8 	b.hi	3dd0 <fwp_write.constprop.0+0xb0>  // b.pmore
    3d58:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    3d5c:	913e8021 	add	x1, x1, #0xfa0
    3d60:	f9013bf5 	str	x21, [sp, #624]
    3d64:	f9013ff6 	str	x22, [sp, #632]
    3d68:	f90153fb 	str	x27, [sp, #672]
    3d6c:	f90157fc 	str	x28, [sp, #680]
    3d70:	aa0203fc 	mov	x28, x2
    3d74:	78605821 	ldrh	w1, [x1, w0, uxtw #1]
    3d78:	10000062 	adr	x2, 3d84 <fwp_write.constprop.0+0x64>
    3d7c:	8b21a841 	add	x1, x2, w1, sxth #2
    3d80:	d61f0020 	br	x1
    3d84:	910123e0 	add	x0, sp, #0x48
    3d88:	aa1303e5 	mov	x5, x19
    3d8c:	b0000024 	adrp	x4, 8000 <fwp_main_thread+0x170>
    3d90:	aa0003f3 	mov	x19, x0
    3d94:	9134e084 	add	x4, x4, #0xd38
    3d98:	d2804003 	mov	x3, #0x200                 	// #512
    3d9c:	aa0303e1 	mov	x1, x3
    3da0:	52800042 	mov	w2, #0x2                   	// #2
    3da4:	97fff59b 	bl	1410 <__snprintf_chk@plt>
    3da8:	aa1303e0 	mov	x0, x19
    3dac:	97fff561 	bl	1330 <strlen@plt>
    3db0:	aa1303e1 	mov	x1, x19
    3db4:	aa0003e2 	mov	x2, x0
    3db8:	aa1403e0 	mov	x0, x20
    3dbc:	97fff85d 	bl	1f30 <buf_put>
    3dc0:	f9413bf5 	ldr	x21, [sp, #624]
    3dc4:	f9413ff6 	ldr	x22, [sp, #632]
    3dc8:	f94153fb 	ldr	x27, [sp, #672]
    3dcc:	f94157fc 	ldr	x28, [sp, #680]
    3dd0:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    3dd4:	f947f400 	ldr	x0, [x0, #4072]
    3dd8:	f94127e2 	ldr	x2, [sp, #584]
    3ddc:	f9400001 	ldr	x1, [x0]
    3de0:	eb010042 	subs	x2, x2, x1
    3de4:	d2800001 	mov	x1, #0x0                   	// #0
    3de8:	540074a1 	b.ne	4c7c <fwp_write.constprop.0+0xf5c>  // b.any
    3dec:	910943ff 	add	sp, sp, #0x250
    3df0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3df4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3df8:	d65f03c0 	ret
    3dfc:	910123e0 	add	x0, sp, #0x48
    3e00:	aa1303e5 	mov	x5, x19
    3e04:	b0000024 	adrp	x4, 8000 <fwp_main_thread+0x170>
    3e08:	aa0003f3 	mov	x19, x0
    3e0c:	9134c084 	add	x4, x4, #0xd30
    3e10:	d2804003 	mov	x3, #0x200                 	// #512
    3e14:	17ffffe2 	b	3d9c <fwp_write.constprop.0+0x7c>
    3e18:	71004c1f 	cmp	w0, #0x13
    3e1c:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    3e20:	b0000020 	adrp	x0, 8000 <fwp_main_thread+0x170>
    3e24:	9134a021 	add	x1, x1, #0xd28
    3e28:	91348000 	add	x0, x0, #0xd20
    3e2c:	d2800082 	mov	x2, #0x4                   	// #4
    3e30:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    3e34:	aa1403e0 	mov	x0, x20
    3e38:	f90143f7 	str	x23, [sp, #640]
    3e3c:	d2800016 	mov	x22, #0x0                   	// #0
    3e40:	f90147f8 	str	x24, [sp, #648]
    3e44:	97fff83b 	bl	1f30 <buf_put>
    3e48:	f9400260 	ldr	x0, [x19]
    3e4c:	b0000037 	adrp	x23, 8000 <fwp_main_thread+0x170>
    3e50:	d2800015 	mov	x21, #0x0                   	// #0
    3e54:	9136a2f7 	add	x23, x23, #0xda8
    3e58:	b4004e40 	cbz	x0, 4820 <fwp_write.constprop.0+0xb00>
    3e5c:	b9400381 	ldr	w1, [x28]
    3e60:	aa1403e0 	mov	x0, x20
    3e64:	f9401f82 	ldr	x2, [x28, #56]
    3e68:	71004c3f 	cmp	w1, #0x13
    3e6c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    3e70:	8b010e61 	add	x1, x19, x1, lsl #3
    3e74:	f9400421 	ldr	x1, [x1, #8]
    3e78:	97ffffaa 	bl	3d20 <fwp_write.constprop.0>
    3e7c:	b9400380 	ldr	w0, [x28]
    3e80:	7100481f 	cmp	w0, #0x12
    3e84:	540050c0 	b.eq	489c <fwp_write.constprop.0+0xb7c>  // b.none
    3e88:	f9400260 	ldr	x0, [x19]
    3e8c:	910006b5 	add	x21, x21, #0x1
    3e90:	91000ad6 	add	x22, x22, #0x2
    3e94:	eb0002bf 	cmp	x21, x0
    3e98:	54004c42 	b.cs	4820 <fwp_write.constprop.0+0xb00>  // b.hs, b.nlast
    3e9c:	aa1703e1 	mov	x1, x23
    3ea0:	aa1403e0 	mov	x0, x20
    3ea4:	d2800042 	mov	x2, #0x2                   	// #2
    3ea8:	97fff822 	bl	1f30 <buf_put>
    3eac:	17ffffec 	b	3e5c <fwp_write.constprop.0+0x13c>
    3eb0:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    3eb4:	91358021 	add	x1, x1, #0xd60
    3eb8:	d28000c2 	mov	x2, #0x6                   	// #6
    3ebc:	aa1403e0 	mov	x0, x20
    3ec0:	91004273 	add	x19, x19, #0x10
    3ec4:	97fff81b 	bl	1f30 <buf_put>
    3ec8:	aa1303e0 	mov	x0, x19
    3ecc:	97fff519 	bl	1330 <strlen@plt>
    3ed0:	aa1303e1 	mov	x1, x19
    3ed4:	aa0003e2 	mov	x2, x0
    3ed8:	aa1403e0 	mov	x0, x20
    3edc:	97fff815 	bl	1f30 <buf_put>
    3ee0:	528007c3 	mov	w3, #0x3e                  	// #62
    3ee4:	aa1403e0 	mov	x0, x20
    3ee8:	91001fe1 	add	x1, sp, #0x7
    3eec:	d2800022 	mov	x2, #0x1                   	// #1
    3ef0:	39001fe3 	strb	w3, [sp, #7]
    3ef4:	17ffffb2 	b	3dbc <fwp_write.constprop.0+0x9c>
    3ef8:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    3efc:	f947f400 	ldr	x0, [x0, #4072]
    3f00:	f94127e2 	ldr	x2, [sp, #584]
    3f04:	f9400001 	ldr	x1, [x0]
    3f08:	eb010042 	subs	x2, x2, x1
    3f0c:	d2800001 	mov	x1, #0x0                   	// #0
    3f10:	54006cc1 	b.ne	4ca8 <fwp_write.constprop.0+0xf88>  // b.any
    3f14:	f9413bf5 	ldr	x21, [sp, #624]
    3f18:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    3f1c:	f9413ff6 	ldr	x22, [sp, #632]
    3f20:	aa1403e0 	mov	x0, x20
    3f24:	91350021 	add	x1, x1, #0xd40
    3f28:	d2800142 	mov	x2, #0xa                   	// #10
    3f2c:	f94153fb 	ldr	x27, [sp, #672]
    3f30:	f94157fc 	ldr	x28, [sp, #680]
    3f34:	910943ff 	add	sp, sp, #0x250
    3f38:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f3c:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3f40:	17fff7fc 	b	1f30 <buf_put>
    3f44:	f9400796 	ldr	x22, [x28, #8]
    3f48:	f90143f7 	str	x23, [sp, #640]
    3f4c:	f90147f8 	str	x24, [sp, #648]
    3f50:	b4005816 	cbz	x22, 4a50 <fwp_write.constprop.0+0xd30>
    3f54:	aa1603e0 	mov	x0, x22
    3f58:	b0000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    3f5c:	91370021 	add	x1, x1, #0xdc0
    3f60:	97fff570 	bl	1520 <strcmp@plt>
    3f64:	2a0003f5 	mov	w21, w0
    3f68:	34005ce0 	cbz	w0, 4b04 <fwp_write.constprop.0+0xde4>
    3f6c:	aa1603e0 	mov	x0, x22
    3f70:	97fff4f0 	bl	1330 <strlen@plt>
    3f74:	aa1603e1 	mov	x1, x22
    3f78:	aa0003e2 	mov	x2, x0
    3f7c:	aa1403e0 	mov	x0, x20
    3f80:	97fff7ec 	bl	1f30 <buf_put>
    3f84:	52800403 	mov	w3, #0x20                  	// #32
    3f88:	91001ff5 	add	x21, sp, #0x7
    3f8c:	aa1503e1 	mov	x1, x21
    3f90:	aa1403e0 	mov	x0, x20
    3f94:	d2800022 	mov	x2, #0x1                   	// #1
    3f98:	39001fe3 	strb	w3, [sp, #7]
    3f9c:	97fff7e5 	bl	1f30 <buf_put>
    3fa0:	52800f63 	mov	w3, #0x7b                  	// #123
    3fa4:	aa1403e0 	mov	x0, x20
    3fa8:	aa1503e1 	mov	x1, x21
    3fac:	d2800022 	mov	x2, #0x1                   	// #1
    3fb0:	39001fe3 	strb	w3, [sp, #7]
    3fb4:	97fff7df 	bl	1f30 <buf_put>
    3fb8:	b9401380 	ldr	w0, [x28, #16]
    3fbc:	52800018 	mov	w24, #0x0                   	// #0
    3fc0:	7100001f 	cmp	w0, #0x0
    3fc4:	54003d8d 	b.le	4774 <fwp_write.constprop.0+0xa54>
    3fc8:	f9014bf9 	str	x25, [sp, #656]
    3fcc:	b0000039 	adrp	x25, 8000 <fwp_main_thread+0x170>
    3fd0:	9137a339 	add	x25, x25, #0xde8
    3fd4:	f9014ffa 	str	x26, [sp, #664]
    3fd8:	b000003a 	adrp	x26, 8000 <fwp_main_thread+0x170>
    3fdc:	9136a35a 	add	x26, x26, #0xda8
    3fe0:	91002276 	add	x22, x19, #0x8
    3fe4:	d2800013 	mov	x19, #0x0                   	// #0
    3fe8:	b5004413 	cbnz	x19, 4868 <fwp_write.constprop.0+0xb48>
    3fec:	d37df277 	lsl	x23, x19, #3
    3ff0:	34004238 	cbz	w24, 4834 <fwp_write.constprop.0+0xb14>
    3ff4:	f9401382 	ldr	x2, [x28, #32]
    3ff8:	aa1403e0 	mov	x0, x20
    3ffc:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    4000:	91000673 	add	x19, x19, #0x1
    4004:	f8776842 	ldr	x2, [x2, x23]
    4008:	97ffff46 	bl	3d20 <fwp_write.constprop.0>
    400c:	b9401380 	ldr	w0, [x28, #16]
    4010:	6b13001f 	cmp	w0, w19
    4014:	54fffeac 	b.gt	3fe8 <fwp_write.constprop.0+0x2c8>
    4018:	f9414bf9 	ldr	x25, [sp, #656]
    401c:	f9414ffa 	ldr	x26, [sp, #664]
    4020:	34003ab8 	cbz	w24, 4774 <fwp_write.constprop.0+0xa54>
    4024:	52800523 	mov	w3, #0x29                  	// #41
    4028:	aa1503e1 	mov	x1, x21
    402c:	aa1403e0 	mov	x0, x20
    4030:	d2800022 	mov	x2, #0x1                   	// #1
    4034:	39001fe3 	strb	w3, [sp, #7]
    4038:	97fff7be 	bl	1f30 <buf_put>
    403c:	f9413bf5 	ldr	x21, [sp, #624]
    4040:	f9413ff6 	ldr	x22, [sp, #632]
    4044:	f94143f7 	ldr	x23, [sp, #640]
    4048:	f94147f8 	ldr	x24, [sp, #648]
    404c:	f94153fb 	ldr	x27, [sp, #672]
    4050:	f94157fc 	ldr	x28, [sp, #680]
    4054:	17ffff5f 	b	3dd0 <fwp_write.constprop.0+0xb0>
    4058:	b9404b95 	ldr	w21, [x28, #72]
    405c:	aa1403e0 	mov	x0, x20
    4060:	93407eb6 	sxtw	x22, w21
    4064:	91000ac1 	add	x1, x22, #0x2
    4068:	97fff77e 	bl	1e60 <buf_grow>
    406c:	a9400281 	ldp	x1, x0, [x20]
    4070:	528e8603 	mov	w3, #0x7430                	// #29744
    4074:	78206823 	strh	w3, [x1, x0]
    4078:	8b000022 	add	x2, x1, x0
    407c:	710002bf 	cmp	w21, #0x0
    4080:	54003bcd 	b.le	47f8 <fwp_write.constprop.0+0xad8>
    4084:	110006a3 	add	w3, w21, #0x1
    4088:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    408c:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    4090:	91000449 	add	x9, x2, #0x1
    4094:	8b23c043 	add	x3, x2, w3, sxtw
    4098:	f28aaac6 	movk	x6, #0x5556
    409c:	f2955568 	movk	x8, #0xaaab
    40a0:	1400000d 	b	40d4 <fwp_write.constprop.0+0x3b4>
    40a4:	d2800021 	mov	x1, #0x1                   	// #1
    40a8:	528005a5 	mov	w5, #0x2d                  	// #45
    40ac:	f100001f 	cmp	x0, #0x0
    40b0:	9b467e60 	smulh	x0, x19, x6
    40b4:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    40b8:	381ff465 	strb	w5, [x3], #-1
    40bc:	cb040000 	sub	x0, x0, x4
    40c0:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    40c4:	cb020000 	sub	x0, x0, x2
    40c8:	8b010013 	add	x19, x0, x1
    40cc:	eb03013f 	cmp	x9, x3
    40d0:	54003940 	b.eq	47f8 <fwp_write.constprop.0+0xad8>  // b.none
    40d4:	9b467e60 	smulh	x0, x19, x6
    40d8:	937ffe64 	asr	x4, x19, #63
    40dc:	52800605 	mov	w5, #0x30                  	// #48
    40e0:	cb040000 	sub	x0, x0, x4
    40e4:	8b000400 	add	x0, x0, x0, lsl #1
    40e8:	cb000260 	sub	x0, x19, x0
    40ec:	91000c01 	add	x1, x0, #0x3
    40f0:	9bc87c22 	umulh	x2, x1, x8
    40f4:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    40f8:	8b4204e2 	add	x2, x7, x2, lsr #1
    40fc:	eb020021 	subs	x1, x1, x2
    4100:	54fffd60 	b.eq	40ac <fwp_write.constprop.0+0x38c>  // b.none
    4104:	f100043f 	cmp	x1, #0x1
    4108:	54fffce1 	b.ne	40a4 <fwp_write.constprop.0+0x384>  // b.any
    410c:	d2800001 	mov	x1, #0x0                   	// #0
    4110:	52800565 	mov	w5, #0x2b                  	// #43
    4114:	17ffffe6 	b	40ac <fwp_write.constprop.0+0x38c>
    4118:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    411c:	f947f400 	ldr	x0, [x0, #4072]
    4120:	f94127e2 	ldr	x2, [sp, #584]
    4124:	f9400001 	ldr	x1, [x0]
    4128:	eb010042 	subs	x2, x2, x1
    412c:	d2800001 	mov	x1, #0x0                   	// #0
    4130:	54005bc1 	b.ne	4ca8 <fwp_write.constprop.0+0xf88>  // b.any
    4134:	f9413bf5 	ldr	x21, [sp, #624]
    4138:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    413c:	f9413ff6 	ldr	x22, [sp, #632]
    4140:	aa1403e0 	mov	x0, x20
    4144:	91354021 	add	x1, x1, #0xd50
    4148:	d2800102 	mov	x2, #0x8                   	// #8
    414c:	17ffff78 	b	3f2c <fwp_write.constprop.0+0x20c>
    4150:	aa1403e0 	mov	x0, x20
    4154:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    4158:	d28000c2 	mov	x2, #0x6                   	// #6
    415c:	9136c021 	add	x1, x1, #0xdb0
    4160:	97fff774 	bl	1f30 <buf_put>
    4164:	d2800015 	mov	x21, #0x0                   	// #0
    4168:	f9400263 	ldr	x3, [x19]
    416c:	f240f87f 	tst	x3, #0x7fffffffffffffff
    4170:	540026a0 	b.eq	4644 <fwp_write.constprop.0+0x924>  // b.none
    4174:	f9401f82 	ldr	x2, [x28, #56]
    4178:	f90143f7 	str	x23, [sp, #640]
    417c:	f90147f8 	str	x24, [sp, #648]
    4180:	d2800857 	mov	x23, #0x42                  	// #66
    4184:	f9014bf9 	str	x25, [sp, #656]
    4188:	90000036 	adrp	x22, 8000 <fwp_main_thread+0x170>
    418c:	f9014ffa 	str	x26, [sp, #664]
    4190:	9136a2d6 	add	x22, x22, #0xda8
    4194:	d2800038 	mov	x24, #0x1                   	// #1
    4198:	f2a18017 	movk	x23, #0xc00, lsl #16
    419c:	d2809099 	mov	x25, #0x484                 	// #1156
    41a0:	b4000482 	cbz	x2, 4230 <fwp_write.constprop.0+0x510>
    41a4:	b9400040 	ldr	w0, [x2]
    41a8:	7100701f 	cmp	w0, #0x1c
    41ac:	540042e0 	b.eq	4a08 <fwp_write.constprop.0+0xce8>  // b.none
    41b0:	71006c1f 	cmp	w0, #0x1b
    41b4:	540003e8 	b.hi	4230 <fwp_write.constprop.0+0x510>  // b.pmore
    41b8:	9ac02301 	lsl	x1, x24, x0
    41bc:	ea17003f 	tst	x1, x23
    41c0:	54003f21 	b.ne	49a4 <fwp_write.constprop.0+0xc84>  // b.any
    41c4:	ea19003f 	tst	x1, x25
    41c8:	54003da1 	b.ne	497c <fwp_write.constprop.0+0xc5c>  // b.any
    41cc:	d2800425 	mov	x5, #0x21                  	// #33
    41d0:	ea05003f 	tst	x1, x5
    41d4:	540002e0 	b.eq	4230 <fwp_write.constprop.0+0x510>  // b.none
    41d8:	b7f84743 	tbnz	x3, #63, 4ac0 <fwp_write.constprop.0+0xda0>
    41dc:	91002261 	add	x1, x19, #0x8
    41e0:	8b150021 	add	x1, x1, x21
    41e4:	39400021 	ldrb	w1, [x1]
    41e8:	7100001f 	cmp	w0, #0x0
    41ec:	93401c23 	sxtb	x3, w1
    41f0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    41f4:	d503201f 	nop
    41f8:	aa1403e0 	mov	x0, x20
    41fc:	97fffec9 	bl	3d20 <fwp_write.constprop.0>
    4200:	f9400260 	ldr	x0, [x19]
    4204:	910006b5 	add	x21, x21, #0x1
    4208:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    420c:	eb0002bf 	cmp	x21, x0
    4210:	54002122 	b.cs	4634 <fwp_write.constprop.0+0x914>  // b.hs, b.nlast
    4214:	d2800042 	mov	x2, #0x2                   	// #2
    4218:	aa1603e1 	mov	x1, x22
    421c:	aa1403e0 	mov	x0, x20
    4220:	97fff744 	bl	1f30 <buf_put>
    4224:	f9401f82 	ldr	x2, [x28, #56]
    4228:	f9400263 	ldr	x3, [x19]
    422c:	b5fffbc2 	cbnz	x2, 41a4 <fwp_write.constprop.0+0x484>
    4230:	d37df2a0 	lsl	x0, x21, #3
    4234:	b7f83f43 	tbnz	x3, #63, 4a1c <fwp_write.constprop.0+0xcfc>
    4238:	91002261 	add	x1, x19, #0x8
    423c:	8b000020 	add	x0, x1, x0
    4240:	f9400001 	ldr	x1, [x0]
    4244:	17ffffed 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4248:	a9400e62 	ldp	x2, x3, [x19]
    424c:	b7f83ce3 	tbnz	x3, #63, 49e8 <fwp_write.constprop.0+0xcc8>
    4250:	910123f5 	add	x21, sp, #0x48
    4254:	aa1503e0 	mov	x0, x21
    4258:	97fff5e2 	bl	19e0 <fwp_fmt_u128>
    425c:	aa1503e0 	mov	x0, x21
    4260:	97fff434 	bl	1330 <strlen@plt>
    4264:	aa1503e1 	mov	x1, x21
    4268:	aa0003e2 	mov	x2, x0
    426c:	17fffed3 	b	3db8 <fwp_write.constprop.0+0x98>
    4270:	fd015be8 	str	d8, [sp, #688]
    4274:	1e270268 	fmov	s8, w19
    4278:	fd015fe9 	str	d9, [sp, #696]
    427c:	1e282100 	fcmp	s8, s8
    4280:	54004a66 	b.vs	4bcc <fwp_write.constprop.0+0xeac>
    4284:	1e20c101 	fabs	s1, s8
    4288:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    428c:	1e270000 	fmov	s0, w0
    4290:	1e202020 	fcmp	s1, s0
    4294:	540034ad 	b.le	4928 <fwp_write.constprop.0+0xc08>
    4298:	1e202118 	fcmpe	s8, #0.0
    429c:	90000022 	adrp	x2, 8000 <fwp_main_thread+0x170>
    42a0:	912c4042 	add	x2, x2, #0xb10
    42a4:	910123f5 	add	x21, sp, #0x48
    42a8:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    42ac:	91340021 	add	x1, x1, #0xd00
    42b0:	aa1503e0 	mov	x0, x21
    42b4:	9a81c041 	csel	x1, x2, x1, gt
    42b8:	97fff4ca 	bl	15e0 <strcpy@plt>
    42bc:	d503201f 	nop
    42c0:	aa1503e0 	mov	x0, x21
    42c4:	97fff41b 	bl	1330 <strlen@plt>
    42c8:	aa1503e1 	mov	x1, x21
    42cc:	aa0003e2 	mov	x2, x0
    42d0:	aa1403e0 	mov	x0, x20
    42d4:	97fff717 	bl	1f30 <buf_put>
    42d8:	f9413bf5 	ldr	x21, [sp, #624]
    42dc:	f9413ff6 	ldr	x22, [sp, #632]
    42e0:	f94153fb 	ldr	x27, [sp, #672]
    42e4:	f94157fc 	ldr	x28, [sp, #680]
    42e8:	fd415be8 	ldr	d8, [sp, #688]
    42ec:	fd415fe9 	ldr	d9, [sp, #696]
    42f0:	17fffeb8 	b	3dd0 <fwp_write.constprop.0+0xb0>
    42f4:	f90143f7 	str	x23, [sp, #640]
    42f8:	52800443 	mov	w3, #0x22                  	// #34
    42fc:	f90147f8 	str	x24, [sp, #648]
    4300:	91001ff5 	add	x21, sp, #0x7
    4304:	aa1503e1 	mov	x1, x21
    4308:	aa1403e0 	mov	x0, x20
    430c:	f8408677 	ldr	x23, [x19], #8
    4310:	d2800022 	mov	x2, #0x1                   	// #1
    4314:	39001fe3 	strb	w3, [sp, #7]
    4318:	97fff706 	bl	1f30 <buf_put>
    431c:	8b1302f6 	add	x22, x23, x19
    4320:	b4002657 	cbz	x23, 47e8 <fwp_write.constprop.0+0xac8>
    4324:	90000038 	adrp	x24, 8000 <fwp_main_thread+0x170>
    4328:	9135a318 	add	x24, x24, #0xd68
    432c:	f9014bf9 	str	x25, [sp, #656]
    4330:	90000039 	adrp	x25, 8000 <fwp_main_thread+0x170>
    4334:	91362339 	add	x25, x25, #0xd88
    4338:	f9014ffa 	str	x26, [sp, #664]
    433c:	1400000e 	b	4374 <fwp_write.constprop.0+0x654>
    4340:	710024bf 	cmp	w5, #0x9
    4344:	54002380 	b.eq	47b4 <fwp_write.constprop.0+0xa94>  // b.none
    4348:	710028bf 	cmp	w5, #0xa
    434c:	54002be1 	b.ne	48c8 <fwp_write.constprop.0+0xba8>  // b.any
    4350:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    4354:	aa1403e0 	mov	x0, x20
    4358:	9135e021 	add	x1, x1, #0xd78
    435c:	d2800042 	mov	x2, #0x2                   	// #2
    4360:	97fff6f4 	bl	1f30 <buf_put>
    4364:	d503201f 	nop
    4368:	91000673 	add	x19, x19, #0x1
    436c:	eb16027f 	cmp	x19, x22
    4370:	54002380 	b.eq	47e0 <fwp_write.constprop.0+0xac0>  // b.none
    4374:	39400265 	ldrb	w5, [x19]
    4378:	710034bf 	cmp	w5, #0xd
    437c:	54002120 	b.eq	47a0 <fwp_write.constprop.0+0xa80>  // b.none
    4380:	54fffe09 	b.ls	4340 <fwp_write.constprop.0+0x620>  // b.plast
    4384:	710088bf 	cmp	w5, #0x22
    4388:	54002220 	b.eq	47cc <fwp_write.constprop.0+0xaac>  // b.none
    438c:	710170bf 	cmp	w5, #0x5c
    4390:	54002ba1 	b.ne	4904 <fwp_write.constprop.0+0xbe4>  // b.any
    4394:	aa1403e0 	mov	x0, x20
    4398:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    439c:	d2800042 	mov	x2, #0x2                   	// #2
    43a0:	9135c021 	add	x1, x1, #0xd70
    43a4:	97fff6e3 	bl	1f30 <buf_put>
    43a8:	17fffff0 	b	4368 <fwp_write.constprop.0+0x648>
    43ac:	fd015be8 	str	d8, [sp, #688]
    43b0:	9e670268 	fmov	d8, x19
    43b4:	fd015fe9 	str	d9, [sp, #696]
    43b8:	1e682100 	fcmp	d8, d8
    43bc:	54004086 	b.vs	4bcc <fwp_write.constprop.0+0xeac>
    43c0:	1e60c101 	fabs	d1, d8
    43c4:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    43c8:	9e670000 	fmov	d0, x0
    43cc:	910123f5 	add	x21, sp, #0x48
    43d0:	52800033 	mov	w19, #0x1                   	// #1
    43d4:	1e602020 	fcmp	d1, d0
    43d8:	540001ad 	b.le	440c <fwp_write.constprop.0+0x6ec>
    43dc:	1e602118 	fcmpe	d8, #0.0
    43e0:	90000022 	adrp	x2, 8000 <fwp_main_thread+0x170>
    43e4:	912c4042 	add	x2, x2, #0xb10
    43e8:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    43ec:	91340021 	add	x1, x1, #0xd00
    43f0:	aa1503e0 	mov	x0, x21
    43f4:	9a81c041 	csel	x1, x2, x1, gt
    43f8:	97fff47a 	bl	15e0 <strcpy@plt>
    43fc:	17ffffb1 	b	42c0 <fwp_write.constprop.0+0x5a0>
    4400:	11000673 	add	w19, w19, #0x1
    4404:	71004a7f 	cmp	w19, #0x12
    4408:	540031a0 	b.eq	4a3c <fwp_write.constprop.0+0xd1c>  // b.none
    440c:	1e604100 	fmov	d0, d8
    4410:	2a1303e1 	mov	w1, w19
    4414:	aa1503e0 	mov	x0, x21
    4418:	97fff75a 	bl	2180 <fwp_format_g.constprop.0>
    441c:	aa1503e0 	mov	x0, x21
    4420:	d2800001 	mov	x1, #0x0                   	// #0
    4424:	97fff3d7 	bl	1380 <strtod@plt>
    4428:	1e602100 	fcmp	d8, d0
    442c:	54fffea1 	b.ne	4400 <fwp_write.constprop.0+0x6e0>  // b.any
    4430:	aa1503e0 	mov	x0, x21
    4434:	97fff6f8 	bl	2014 <fwp_finish_float>
    4438:	17ffffa2 	b	42c0 <fwp_write.constprop.0+0x5a0>
    443c:	a9400e62 	ldp	x2, x3, [x19]
    4440:	910123f3 	add	x19, sp, #0x48
    4444:	aa1303e0 	mov	x0, x19
    4448:	97fff566 	bl	19e0 <fwp_fmt_u128>
    444c:	17fffe57 	b	3da8 <fwp_write.constprop.0+0x88>
    4450:	f90143f7 	str	x23, [sp, #640]
    4454:	f90147f8 	str	x24, [sp, #648]
    4458:	2a1303f8 	mov	w24, w19
    445c:	f9014bf9 	str	x25, [sp, #656]
    4460:	f9014ffa 	str	x26, [sp, #664]
    4464:	f13ffe7f 	cmp	x19, #0xfff
    4468:	54000049 	b.ls	4470 <fwp_write.constprop.0+0x750>  // b.plast
    446c:	b9400278 	ldr	w24, [x19]
    4470:	f9400f80 	ldr	x0, [x28, #24]
    4474:	2a1803f5 	mov	w21, w24
    4478:	d37d7f18 	ubfiz	x24, x24, #3, #32
    447c:	d37ef6b9 	lsl	x25, x21, #2
    4480:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    4484:	aa1603e0 	mov	x0, x22
    4488:	97fff3aa 	bl	1330 <strlen@plt>
    448c:	aa1603e1 	mov	x1, x22
    4490:	aa0003e2 	mov	x2, x0
    4494:	aa1403e0 	mov	x0, x20
    4498:	97fff6a6 	bl	1f30 <buf_put>
    449c:	f9401780 	ldr	x0, [x28, #40]
    44a0:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    44a4:	7100001f 	cmp	w0, #0x0
    44a8:	5400064d 	b.le	4570 <fwp_write.constprop.0+0x850>
    44ac:	91002276 	add	x22, x19, #0x8
    44b0:	91001ff5 	add	x21, sp, #0x7
    44b4:	d280001b 	mov	x27, #0x0                   	// #0
    44b8:	5280041a 	mov	w26, #0x20                  	// #32
    44bc:	f9401b80 	ldr	x0, [x28, #48]
    44c0:	aa1503e1 	mov	x1, x21
    44c4:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    44c8:	d2800022 	mov	x2, #0x1                   	// #1
    44cc:	f8786805 	ldr	x5, [x0, x24]
    44d0:	aa1403e0 	mov	x0, x20
    44d4:	f87b78b3 	ldr	x19, [x5, x27, lsl #3]
    44d8:	39001ffa 	strb	w26, [sp, #7]
    44dc:	97fff695 	bl	1f30 <buf_put>
    44e0:	f13ffeff 	cmp	x23, #0xfff
    44e4:	b9400261 	ldr	w1, [x19]
    44e8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    44ec:	7100383f 	cmp	w1, #0xe
    44f0:	54000140 	b.eq	4518 <fwp_write.constprop.0+0x7f8>  // b.none
    44f4:	7100403f 	cmp	w1, #0x10
    44f8:	54001c20 	b.eq	487c <fwp_write.constprop.0+0xb5c>  // b.none
    44fc:	7100283f 	cmp	w1, #0xa
    4500:	540026e0 	b.eq	49dc <fwp_write.constprop.0+0xcbc>  // b.none
    4504:	540013cc 	b.gt	477c <fwp_write.constprop.0+0xa5c>
    4508:	71000c3f 	cmp	w1, #0x3
    450c:	540025ec 	b.gt	49c8 <fwp_write.constprop.0+0xca8>
    4510:	d37ffee0 	lsr	x0, x23, #63
    4514:	37f813c1 	tbnz	w1, #31, 478c <fwp_write.constprop.0+0xa6c>
    4518:	340013a0 	cbz	w0, 478c <fwp_write.constprop.0+0xa6c>
    451c:	52800503 	mov	w3, #0x28                  	// #40
    4520:	aa1503e1 	mov	x1, x21
    4524:	aa1403e0 	mov	x0, x20
    4528:	d2800022 	mov	x2, #0x1                   	// #1
    452c:	39001fe3 	strb	w3, [sp, #7]
    4530:	97fff680 	bl	1f30 <buf_put>
    4534:	aa1303e2 	mov	x2, x19
    4538:	aa1703e1 	mov	x1, x23
    453c:	aa1403e0 	mov	x0, x20
    4540:	97fffdf8 	bl	3d20 <fwp_write.constprop.0>
    4544:	52800523 	mov	w3, #0x29                  	// #41
    4548:	aa1503e1 	mov	x1, x21
    454c:	aa1403e0 	mov	x0, x20
    4550:	d2800022 	mov	x2, #0x1                   	// #1
    4554:	39001fe3 	strb	w3, [sp, #7]
    4558:	97fff676 	bl	1f30 <buf_put>
    455c:	f9401780 	ldr	x0, [x28, #40]
    4560:	9100077b 	add	x27, x27, #0x1
    4564:	b8796800 	ldr	w0, [x0, x25]
    4568:	6b1b001f 	cmp	w0, w27
    456c:	54fffa8c 	b.gt	44bc <fwp_write.constprop.0+0x79c>
    4570:	f9413bf5 	ldr	x21, [sp, #624]
    4574:	f9413ff6 	ldr	x22, [sp, #632]
    4578:	f94143f7 	ldr	x23, [sp, #640]
    457c:	f94147f8 	ldr	x24, [sp, #648]
    4580:	f9414bf9 	ldr	x25, [sp, #656]
    4584:	f9414ffa 	ldr	x26, [sp, #664]
    4588:	f94153fb 	ldr	x27, [sp, #672]
    458c:	f94157fc 	ldr	x28, [sp, #680]
    4590:	17fffe10 	b	3dd0 <fwp_write.constprop.0+0xb0>
    4594:	aa1403e0 	mov	x0, x20
    4598:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    459c:	d28000c2 	mov	x2, #0x6                   	// #6
    45a0:	91366021 	add	x1, x1, #0xd98
    45a4:	97fff663 	bl	1f30 <buf_put>
    45a8:	f9400260 	ldr	x0, [x19]
    45ac:	b40004c0 	cbz	x0, 4644 <fwp_write.constprop.0+0x924>
    45b0:	910123f5 	add	x21, sp, #0x48
    45b4:	91002276 	add	x22, x19, #0x8
    45b8:	f90143f7 	str	x23, [sp, #640]
    45bc:	d2800017 	mov	x23, #0x0                   	// #0
    45c0:	f90147f8 	str	x24, [sp, #648]
    45c4:	90000038 	adrp	x24, 8000 <fwp_main_thread+0x170>
    45c8:	91368318 	add	x24, x24, #0xda0
    45cc:	f9014bf9 	str	x25, [sp, #656]
    45d0:	90000039 	adrp	x25, 8000 <fwp_main_thread+0x170>
    45d4:	9136a339 	add	x25, x25, #0xda8
    45d8:	f9014ffa 	str	x26, [sp, #664]
    45dc:	14000005 	b	45f0 <fwp_write.constprop.0+0x8d0>
    45e0:	aa1903e1 	mov	x1, x25
    45e4:	aa1403e0 	mov	x0, x20
    45e8:	d2800042 	mov	x2, #0x2                   	// #2
    45ec:	97fff651 	bl	1f30 <buf_put>
    45f0:	38776ac5 	ldrb	w5, [x22, x23]
    45f4:	d2804003 	mov	x3, #0x200                 	// #512
    45f8:	aa1803e4 	mov	x4, x24
    45fc:	aa0303e1 	mov	x1, x3
    4600:	52800042 	mov	w2, #0x2                   	// #2
    4604:	aa1503e0 	mov	x0, x21
    4608:	910006f7 	add	x23, x23, #0x1
    460c:	97fff381 	bl	1410 <__snprintf_chk@plt>
    4610:	aa1503e0 	mov	x0, x21
    4614:	97fff347 	bl	1330 <strlen@plt>
    4618:	aa1503e1 	mov	x1, x21
    461c:	aa0003e2 	mov	x2, x0
    4620:	aa1403e0 	mov	x0, x20
    4624:	97fff643 	bl	1f30 <buf_put>
    4628:	f9400260 	ldr	x0, [x19]
    462c:	eb0002ff 	cmp	x23, x0
    4630:	54fffd83 	b.cc	45e0 <fwp_write.constprop.0+0x8c0>  // b.lo, b.ul, b.last
    4634:	f94143f7 	ldr	x23, [sp, #640]
    4638:	f94147f8 	ldr	x24, [sp, #648]
    463c:	f9414bf9 	ldr	x25, [sp, #656]
    4640:	f9414ffa 	ldr	x26, [sp, #664]
    4644:	52800ba3 	mov	w3, #0x5d                  	// #93
    4648:	aa1403e0 	mov	x0, x20
    464c:	91001fe1 	add	x1, sp, #0x7
    4650:	d2800022 	mov	x2, #0x1                   	// #1
    4654:	39001fe3 	strb	w3, [sp, #7]
    4658:	17fffdd9 	b	3dbc <fwp_write.constprop.0+0x9c>
    465c:	52800b63 	mov	w3, #0x5b                  	// #91
    4660:	91001ff5 	add	x21, sp, #0x7
    4664:	aa1503e1 	mov	x1, x21
    4668:	aa1403e0 	mov	x0, x20
    466c:	d2800022 	mov	x2, #0x1                   	// #1
    4670:	90000036 	adrp	x22, 8000 <fwp_main_thread+0x170>
    4674:	9136a2d6 	add	x22, x22, #0xda8
    4678:	39001fe3 	strb	w3, [sp, #7]
    467c:	97fff62d 	bl	1f30 <buf_put>
    4680:	b4000233 	cbz	x19, 46c4 <fwp_write.constprop.0+0x9a4>
    4684:	f9400661 	ldr	x1, [x19, #8]
    4688:	aa1403e0 	mov	x0, x20
    468c:	f9401f82 	ldr	x2, [x28, #56]
    4690:	97fffda4 	bl	3d20 <fwp_write.constprop.0>
    4694:	f9400a73 	ldr	x19, [x19, #16]
    4698:	b4000173 	cbz	x19, 46c4 <fwp_write.constprop.0+0x9a4>
    469c:	aa1603e1 	mov	x1, x22
    46a0:	aa1403e0 	mov	x0, x20
    46a4:	d2800042 	mov	x2, #0x2                   	// #2
    46a8:	97fff622 	bl	1f30 <buf_put>
    46ac:	f9400661 	ldr	x1, [x19, #8]
    46b0:	aa1403e0 	mov	x0, x20
    46b4:	f9401f82 	ldr	x2, [x28, #56]
    46b8:	97fffd9a 	bl	3d20 <fwp_write.constprop.0>
    46bc:	f9400a73 	ldr	x19, [x19, #16]
    46c0:	b5fffef3 	cbnz	x19, 469c <fwp_write.constprop.0+0x97c>
    46c4:	52800ba3 	mov	w3, #0x5d                  	// #93
    46c8:	aa1503e1 	mov	x1, x21
    46cc:	aa1403e0 	mov	x0, x20
    46d0:	d2800022 	mov	x2, #0x1                   	// #1
    46d4:	39001fe3 	strb	w3, [sp, #7]
    46d8:	17fffdb9 	b	3dbc <fwp_write.constprop.0+0x9c>
    46dc:	52800783 	mov	w3, #0x3c                  	// #60
    46e0:	91001ff3 	add	x19, sp, #0x7
    46e4:	aa1303e1 	mov	x1, x19
    46e8:	d2800022 	mov	x2, #0x1                   	// #1
    46ec:	aa1403e0 	mov	x0, x20
    46f0:	39001fe3 	strb	w3, [sp, #7]
    46f4:	97fff60f 	bl	1f30 <buf_put>
    46f8:	f9400795 	ldr	x21, [x28, #8]
    46fc:	aa1503e0 	mov	x0, x21
    4700:	97fff30c 	bl	1330 <strlen@plt>
    4704:	aa1503e1 	mov	x1, x21
    4708:	aa0003e2 	mov	x2, x0
    470c:	aa1403e0 	mov	x0, x20
    4710:	97fff608 	bl	1f30 <buf_put>
    4714:	528007c3 	mov	w3, #0x3e                  	// #62
    4718:	aa1303e1 	mov	x1, x19
    471c:	aa1403e0 	mov	x0, x20
    4720:	d2800022 	mov	x2, #0x1                   	// #1
    4724:	39001fe3 	strb	w3, [sp, #7]
    4728:	17fffda5 	b	3dbc <fwp_write.constprop.0+0x9c>
    472c:	f100067f 	cmp	x19, #0x1
    4730:	540017e0 	b.eq	4a2c <fwp_write.constprop.0+0xd0c>  // b.none
    4734:	b100067f 	cmn	x19, #0x1
    4738:	54001b00 	b.eq	4a98 <fwp_write.constprop.0+0xd78>  // b.none
    473c:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    4740:	91346021 	add	x1, x1, #0xd18
    4744:	d2800022 	mov	x2, #0x1                   	// #1
    4748:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    474c:	f947f400 	ldr	x0, [x0, #4072]
    4750:	f94127e4 	ldr	x4, [sp, #584]
    4754:	f9400003 	ldr	x3, [x0]
    4758:	eb030084 	subs	x4, x4, x3
    475c:	d2800003 	mov	x3, #0x0                   	// #0
    4760:	54002a41 	b.ne	4ca8 <fwp_write.constprop.0+0xf88>  // b.any
    4764:	f9413bf5 	ldr	x21, [sp, #624]
    4768:	aa1403e0 	mov	x0, x20
    476c:	f9413ff6 	ldr	x22, [sp, #632]
    4770:	17fffdef 	b	3f2c <fwp_write.constprop.0+0x20c>
    4774:	52800fa3 	mov	w3, #0x7d                  	// #125
    4778:	17fffe2c 	b	4028 <fwp_write.constprop.0+0x308>
    477c:	f10002ff 	cmp	x23, #0x0
    4780:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4784:	71002c3f 	cmp	w1, #0xb
    4788:	54ffec80 	b.eq	4518 <fwp_write.constprop.0+0x7f8>  // b.none
    478c:	aa1303e2 	mov	x2, x19
    4790:	aa1703e1 	mov	x1, x23
    4794:	aa1403e0 	mov	x0, x20
    4798:	97fffd62 	bl	3d20 <fwp_write.constprop.0>
    479c:	17ffff70 	b	455c <fwp_write.constprop.0+0x83c>
    47a0:	aa1903e1 	mov	x1, x25
    47a4:	aa1403e0 	mov	x0, x20
    47a8:	d2800042 	mov	x2, #0x2                   	// #2
    47ac:	97fff5e1 	bl	1f30 <buf_put>
    47b0:	17fffeee 	b	4368 <fwp_write.constprop.0+0x648>
    47b4:	aa1403e0 	mov	x0, x20
    47b8:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    47bc:	d2800042 	mov	x2, #0x2                   	// #2
    47c0:	91360021 	add	x1, x1, #0xd80
    47c4:	97fff5db 	bl	1f30 <buf_put>
    47c8:	17fffee8 	b	4368 <fwp_write.constprop.0+0x648>
    47cc:	aa1803e1 	mov	x1, x24
    47d0:	aa1403e0 	mov	x0, x20
    47d4:	d2800042 	mov	x2, #0x2                   	// #2
    47d8:	97fff5d6 	bl	1f30 <buf_put>
    47dc:	17fffee3 	b	4368 <fwp_write.constprop.0+0x648>
    47e0:	f9414bf9 	ldr	x25, [sp, #656]
    47e4:	f9414ffa 	ldr	x26, [sp, #664]
    47e8:	aa1503e1 	mov	x1, x21
    47ec:	aa1403e0 	mov	x0, x20
    47f0:	52800443 	mov	w3, #0x22                  	// #34
    47f4:	17fffe0f 	b	4030 <fwp_write.constprop.0+0x310>
    47f8:	a9400281 	ldp	x1, x0, [x20]
    47fc:	91000800 	add	x0, x0, #0x2
    4800:	8b160000 	add	x0, x0, x22
    4804:	f9000680 	str	x0, [x20, #8]
    4808:	3820683f 	strb	wzr, [x1, x0]
    480c:	f9413bf5 	ldr	x21, [sp, #624]
    4810:	f9413ff6 	ldr	x22, [sp, #632]
    4814:	f94153fb 	ldr	x27, [sp, #672]
    4818:	f94157fc 	ldr	x28, [sp, #680]
    481c:	17fffd6d 	b	3dd0 <fwp_write.constprop.0+0xb0>
    4820:	aa1403e0 	mov	x0, x20
    4824:	91001fe1 	add	x1, sp, #0x7
    4828:	52800fa3 	mov	w3, #0x7d                  	// #125
    482c:	d2800022 	mov	x2, #0x1                   	// #1
    4830:	17fffe01 	b	4034 <fwp_write.constprop.0+0x314>
    4834:	f9400f80 	ldr	x0, [x28, #24]
    4838:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    483c:	aa1b03e0 	mov	x0, x27
    4840:	97fff2bc 	bl	1330 <strlen@plt>
    4844:	aa1b03e1 	mov	x1, x27
    4848:	aa0003e2 	mov	x2, x0
    484c:	aa1403e0 	mov	x0, x20
    4850:	97fff5b8 	bl	1f30 <buf_put>
    4854:	aa1903e1 	mov	x1, x25
    4858:	aa1403e0 	mov	x0, x20
    485c:	d2800062 	mov	x2, #0x3                   	// #3
    4860:	97fff5b4 	bl	1f30 <buf_put>
    4864:	17fffde4 	b	3ff4 <fwp_write.constprop.0+0x2d4>
    4868:	aa1a03e1 	mov	x1, x26
    486c:	aa1403e0 	mov	x0, x20
    4870:	d2800042 	mov	x2, #0x2                   	// #2
    4874:	97fff5af 	bl	1f30 <buf_put>
    4878:	17fffddd 	b	3fec <fwp_write.constprop.0+0x2cc>
    487c:	f9400660 	ldr	x0, [x19, #8]
    4880:	b4fff860 	cbz	x0, 478c <fwp_write.constprop.0+0xa6c>
    4884:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    4888:	91370021 	add	x1, x1, #0xdc0
    488c:	97fff325 	bl	1520 <strcmp@plt>
    4890:	7100001f 	cmp	w0, #0x0
    4894:	1a9f07e0 	cset	w0, ne	// ne = any
    4898:	17ffff20 	b	4518 <fwp_write.constprop.0+0x7f8>
    489c:	aa1403e0 	mov	x0, x20
    48a0:	d2800042 	mov	x2, #0x2                   	// #2
    48a4:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    48a8:	9136e021 	add	x1, x1, #0xdb8
    48ac:	97fff5a1 	bl	1f30 <buf_put>
    48b0:	91004261 	add	x1, x19, #0x10
    48b4:	aa1403e0 	mov	x0, x20
    48b8:	f9402382 	ldr	x2, [x28, #64]
    48bc:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    48c0:	97fffd18 	bl	3d20 <fwp_write.constprop.0>
    48c4:	17fffd71 	b	3e88 <fwp_write.constprop.0+0x168>
    48c8:	d2800203 	mov	x3, #0x10                  	// #16
    48cc:	90000024 	adrp	x4, 8000 <fwp_main_thread+0x170>
    48d0:	aa0303e1 	mov	x1, x3
    48d4:	91364084 	add	x4, x4, #0xd90
    48d8:	910123f7 	add	x23, sp, #0x48
    48dc:	52800042 	mov	w2, #0x2                   	// #2
    48e0:	aa1703e0 	mov	x0, x23
    48e4:	97fff2cb 	bl	1410 <__snprintf_chk@plt>
    48e8:	aa1703e0 	mov	x0, x23
    48ec:	97fff291 	bl	1330 <strlen@plt>
    48f0:	aa1703e1 	mov	x1, x23
    48f4:	aa0003e2 	mov	x2, x0
    48f8:	aa1403e0 	mov	x0, x20
    48fc:	97fff58d 	bl	1f30 <buf_put>
    4900:	17fffe9a 	b	4368 <fwp_write.constprop.0+0x648>
    4904:	7101fcbf 	cmp	w5, #0x7f
    4908:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    490c:	54fffde9 	b.ls	48c8 <fwp_write.constprop.0+0xba8>  // b.plast
    4910:	aa1503e1 	mov	x1, x21
    4914:	aa1403e0 	mov	x0, x20
    4918:	d2800022 	mov	x2, #0x1                   	// #1
    491c:	39001fe5 	strb	w5, [sp, #7]
    4920:	97fff584 	bl	1f30 <buf_put>
    4924:	17fffe91 	b	4368 <fwp_write.constprop.0+0x648>
    4928:	1e22c109 	fcvt	d9, s8
    492c:	910123f5 	add	x21, sp, #0x48
    4930:	52800033 	mov	w19, #0x1                   	// #1
    4934:	d503201f 	nop
    4938:	1e604120 	fmov	d0, d9
    493c:	2a1303e1 	mov	w1, w19
    4940:	aa1503e0 	mov	x0, x21
    4944:	97fff60f 	bl	2180 <fwp_format_g.constprop.0>
    4948:	aa1503e0 	mov	x0, x21
    494c:	d2800001 	mov	x1, #0x0                   	// #0
    4950:	97fff300 	bl	1550 <strtof@plt>
    4954:	1e202100 	fcmp	s8, s0
    4958:	54ffd6c0 	b.eq	4430 <fwp_write.constprop.0+0x710>  // b.none
    495c:	11000673 	add	w19, w19, #0x1
    4960:	71002a7f 	cmp	w19, #0xa
    4964:	54fffea1 	b.ne	4938 <fwp_write.constprop.0+0xc18>  // b.any
    4968:	1e604120 	fmov	d0, d9
    496c:	aa1503e0 	mov	x0, x21
    4970:	52800121 	mov	w1, #0x9                   	// #9
    4974:	97fff603 	bl	2180 <fwp_format_g.constprop.0>
    4978:	17fffeae 	b	4430 <fwp_write.constprop.0+0x710>
    497c:	d37ef6a1 	lsl	x1, x21, #2
    4980:	b7f809a3 	tbnz	x3, #63, 4ab4 <fwp_write.constprop.0+0xd94>
    4984:	91002263 	add	x3, x19, #0x8
    4988:	8b010061 	add	x1, x3, x1
    498c:	b9400023 	ldr	w3, [x1]
    4990:	7100081f 	cmp	w0, #0x2
    4994:	2a0303e1 	mov	w1, w3
    4998:	93407c63 	sxtw	x3, w3
    499c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    49a0:	17fffe16 	b	41f8 <fwp_write.constprop.0+0x4d8>
    49a4:	d37ffaa1 	lsl	x1, x21, #1
    49a8:	b7f80803 	tbnz	x3, #63, 4aa8 <fwp_write.constprop.0+0xd88>
    49ac:	91002263 	add	x3, x19, #0x8
    49b0:	8b010061 	add	x1, x3, x1
    49b4:	79400021 	ldrh	w1, [x1]
    49b8:	7100041f 	cmp	w0, #0x1
    49bc:	93403c23 	sxth	x3, w1
    49c0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    49c4:	17fffe0d 	b	41f8 <fwp_write.constprop.0+0x4d8>
    49c8:	7100103f 	cmp	w1, #0x4
    49cc:	54ffee01 	b.ne	478c <fwp_write.constprop.0+0xa6c>  // b.any
    49d0:	f94006e0 	ldr	x0, [x23, #8]
    49d4:	d37ffc00 	lsr	x0, x0, #63
    49d8:	17fffed0 	b	4518 <fwp_write.constprop.0+0x7f8>
    49dc:	710002ff 	cmp	w23, #0x0
    49e0:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    49e4:	17fffecd 	b	4518 <fwp_write.constprop.0+0x7f8>
    49e8:	528005a1 	mov	w1, #0x2d                  	// #45
    49ec:	eb0203e2 	negs	x2, x2
    49f0:	da0303e3 	ngc	x3, x3
    49f4:	910127e0 	add	x0, sp, #0x49
    49f8:	910123f5 	add	x21, sp, #0x48
    49fc:	390123e1 	strb	w1, [sp, #72]
    4a00:	97fff3f8 	bl	19e0 <fwp_fmt_u128>
    4a04:	17fffe16 	b	425c <fwp_write.constprop.0+0x53c>
    4a08:	d37ceea1 	lsl	x1, x21, #4
    4a0c:	b7f80da3 	tbnz	x3, #63, 4bc0 <fwp_write.constprop.0+0xea0>
    4a10:	91002260 	add	x0, x19, #0x8
    4a14:	8b010001 	add	x1, x0, x1
    4a18:	17fffdf8 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4a1c:	f9400a61 	ldr	x1, [x19, #16]
    4a20:	8b010000 	add	x0, x0, x1
    4a24:	f9400001 	ldr	x1, [x0]
    4a28:	17fffdf4 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4a2c:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    4a30:	d2800042 	mov	x2, #0x2                   	// #2
    4a34:	91342021 	add	x1, x1, #0xd08
    4a38:	17ffff44 	b	4748 <fwp_write.constprop.0+0xa28>
    4a3c:	1e604100 	fmov	d0, d8
    4a40:	aa1503e0 	mov	x0, x21
    4a44:	52800221 	mov	w1, #0x11                  	// #17
    4a48:	97fff5ce 	bl	2180 <fwp_format_g.constprop.0>
    4a4c:	17fffe79 	b	4430 <fwp_write.constprop.0+0x710>
    4a50:	b9401380 	ldr	w0, [x28, #16]
    4a54:	350003c0 	cbnz	w0, 4acc <fwp_write.constprop.0+0xdac>
    4a58:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    4a5c:	f947f400 	ldr	x0, [x0, #4072]
    4a60:	f94127e2 	ldr	x2, [sp, #584]
    4a64:	f9400001 	ldr	x1, [x0]
    4a68:	eb010042 	subs	x2, x2, x1
    4a6c:	d2800001 	mov	x1, #0x0                   	// #0
    4a70:	54001201 	b.ne	4cb0 <fwp_write.constprop.0+0xf90>  // b.any
    4a74:	f9413bf5 	ldr	x21, [sp, #624]
    4a78:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    4a7c:	f9413ff6 	ldr	x22, [sp, #632]
    4a80:	aa1403e0 	mov	x0, x20
    4a84:	f94143f7 	ldr	x23, [sp, #640]
    4a88:	91378021 	add	x1, x1, #0xde0
    4a8c:	f94147f8 	ldr	x24, [sp, #648]
    4a90:	d2800042 	mov	x2, #0x2                   	// #2
    4a94:	17fffd26 	b	3f2c <fwp_write.constprop.0+0x20c>
    4a98:	90000021 	adrp	x1, 8000 <fwp_main_thread+0x170>
    4a9c:	d2800042 	mov	x2, #0x2                   	// #2
    4aa0:	91344021 	add	x1, x1, #0xd10
    4aa4:	17ffff29 	b	4748 <fwp_write.constprop.0+0xa28>
    4aa8:	f9400a63 	ldr	x3, [x19, #16]
    4aac:	8b030021 	add	x1, x1, x3
    4ab0:	17ffffc1 	b	49b4 <fwp_write.constprop.0+0xc94>
    4ab4:	f9400a63 	ldr	x3, [x19, #16]
    4ab8:	8b030021 	add	x1, x1, x3
    4abc:	17ffffb4 	b	498c <fwp_write.constprop.0+0xc6c>
    4ac0:	f9400a61 	ldr	x1, [x19, #16]
    4ac4:	8b0102a1 	add	x1, x21, x1
    4ac8:	17fffdc7 	b	41e4 <fwp_write.constprop.0+0x4c4>
    4acc:	b9404b80 	ldr	w0, [x28, #72]
    4ad0:	91001ff5 	add	x21, sp, #0x7
    4ad4:	34ffa660 	cbz	w0, 3fa0 <fwp_write.constprop.0+0x280>
    4ad8:	52800503 	mov	w3, #0x28                  	// #40
    4adc:	aa1403e0 	mov	x0, x20
    4ae0:	aa1503e1 	mov	x1, x21
    4ae4:	d2800022 	mov	x2, #0x1                   	// #1
    4ae8:	39001fe3 	strb	w3, [sp, #7]
    4aec:	97fff511 	bl	1f30 <buf_put>
    4af0:	b9401380 	ldr	w0, [x28, #16]
    4af4:	52800038 	mov	w24, #0x1                   	// #1
    4af8:	7100001f 	cmp	w0, #0x0
    4afc:	54ffa66c 	b.gt	3fc8 <fwp_write.constprop.0+0x2a8>
    4b00:	17fffd49 	b	4024 <fwp_write.constprop.0+0x304>
    4b04:	f9014bf9 	str	x25, [sp, #656]
    4b08:	f00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x152b8>
    4b0c:	f9014ffa 	str	x26, [sp, #664]
    4b10:	f9400676 	ldr	x22, [x19, #8]
    4b14:	912ca333 	add	x19, x25, #0xb28
    4b18:	91002273 	add	x19, x19, #0x8
    4b1c:	937ffed8 	asr	x24, x22, #63
    4b20:	aa1802c0 	orr	x0, x22, x24
    4b24:	b5000320 	cbnz	x0, 4b88 <fwp_write.constprop.0+0xe68>
    4b28:	110006b5 	add	w21, w21, #0x1
    4b2c:	710016bf 	cmp	w21, #0x5
    4b30:	54ffffc1 	b.ne	4b28 <fwp_write.constprop.0+0xe08>  // b.any
    4b34:	b7f80578 	tbnz	x24, #63, 4be0 <fwp_write.constprop.0+0xec0>
    4b38:	910023f3 	add	x19, sp, #0x8
    4b3c:	aa1603e2 	mov	x2, x22
    4b40:	aa1303e0 	mov	x0, x19
    4b44:	d2800003 	mov	x3, #0x0                   	// #0
    4b48:	97fff3a6 	bl	19e0 <fwp_fmt_u128>
    4b4c:	910123f5 	add	x21, sp, #0x48
    4b50:	90000023 	adrp	x3, 8000 <fwp_main_thread+0x170>
    4b54:	aa1303e4 	mov	x4, x19
    4b58:	aa1503e0 	mov	x0, x21
    4b5c:	91376063 	add	x3, x3, #0xdd8
    4b60:	d2804002 	mov	x2, #0x200                 	// #512
    4b64:	52800041 	mov	w1, #0x2                   	// #2
    4b68:	97fff1f6 	bl	1340 <__sprintf_chk@plt>
    4b6c:	aa1503e0 	mov	x0, x21
    4b70:	97fff1f0 	bl	1330 <strlen@plt>
    4b74:	aa1503e1 	mov	x1, x21
    4b78:	aa0003e2 	mov	x2, x0
    4b7c:	aa1403e0 	mov	x0, x20
    4b80:	97fff4ec 	bl	1f30 <buf_put>
    4b84:	17fffe7b 	b	4570 <fwp_write.constprop.0+0x850>
    4b88:	f9400277 	ldr	x23, [x19]
    4b8c:	aa1603e0 	mov	x0, x22
    4b90:	aa1803e1 	mov	x1, x24
    4b94:	aa1703e2 	mov	x2, x23
    4b98:	937ffefa 	asr	x26, x23, #63
    4b9c:	aa1a03e3 	mov	x3, x26
    4ba0:	94000eec 	bl	8750 <__modti3>
    4ba4:	aa010000 	orr	x0, x0, x1
    4ba8:	b40002c0 	cbz	x0, 4c00 <fwp_write.constprop.0+0xee0>
    4bac:	110006b5 	add	w21, w21, #0x1
    4bb0:	91004273 	add	x19, x19, #0x10
    4bb4:	710016bf 	cmp	w21, #0x5
    4bb8:	54fffe81 	b.ne	4b88 <fwp_write.constprop.0+0xe68>  // b.any
    4bbc:	17ffffde 	b	4b34 <fwp_write.constprop.0+0xe14>
    4bc0:	f9400a60 	ldr	x0, [x19, #16]
    4bc4:	8b000021 	add	x1, x1, x0
    4bc8:	17fffd8c 	b	41f8 <fwp_write.constprop.0+0x4d8>
    4bcc:	528c29c0 	mov	w0, #0x614e                	// #24910
    4bd0:	910123f5 	add	x21, sp, #0x48
    4bd4:	72a009c0 	movk	w0, #0x4e, lsl #16
    4bd8:	b9004be0 	str	w0, [sp, #72]
    4bdc:	17fffdb9 	b	42c0 <fwp_write.constprop.0+0x5a0>
    4be0:	528005a1 	mov	w1, #0x2d                  	// #45
    4be4:	eb1603e2 	negs	x2, x22
    4be8:	da1803e3 	ngc	x3, x24
    4bec:	910027e0 	add	x0, sp, #0x9
    4bf0:	910023f3 	add	x19, sp, #0x8
    4bf4:	390023e1 	strb	w1, [sp, #8]
    4bf8:	97fff37a 	bl	19e0 <fwp_fmt_u128>
    4bfc:	17ffffd4 	b	4b4c <fwp_write.constprop.0+0xe2c>
    4c00:	aa1703e2 	mov	x2, x23
    4c04:	aa1a03e3 	mov	x3, x26
    4c08:	aa1603e0 	mov	x0, x22
    4c0c:	aa1803e1 	mov	x1, x24
    4c10:	94000df0 	bl	83d0 <__divti3>
    4c14:	aa0003e2 	mov	x2, x0
    4c18:	aa0103e3 	mov	x3, x1
    4c1c:	b7f80201 	tbnz	x1, #63, 4c5c <fwp_write.constprop.0+0xf3c>
    4c20:	910023f3 	add	x19, sp, #0x8
    4c24:	aa1303e0 	mov	x0, x19
    4c28:	97fff36e 	bl	19e0 <fwp_fmt_u128>
    4c2c:	937c7ea1 	sbfiz	x1, x21, #4, #32
    4c30:	912ca339 	add	x25, x25, #0xb28
    4c34:	910123f5 	add	x21, sp, #0x48
    4c38:	aa1303e4 	mov	x4, x19
    4c3c:	aa1503e0 	mov	x0, x21
    4c40:	90000023 	adrp	x3, 8000 <fwp_main_thread+0x170>
    4c44:	f8616b25 	ldr	x5, [x25, x1]
    4c48:	91374063 	add	x3, x3, #0xdd0
    4c4c:	d2804002 	mov	x2, #0x200                 	// #512
    4c50:	52800041 	mov	w1, #0x2                   	// #2
    4c54:	97fff1bb 	bl	1340 <__sprintf_chk@plt>
    4c58:	17ffffc5 	b	4b6c <fwp_write.constprop.0+0xe4c>
    4c5c:	528005a4 	mov	w4, #0x2d                  	// #45
    4c60:	eb0003e2 	negs	x2, x0
    4c64:	da0103e3 	ngc	x3, x1
    4c68:	910027e0 	add	x0, sp, #0x9
    4c6c:	910023f3 	add	x19, sp, #0x8
    4c70:	390023e4 	strb	w4, [sp, #8]
    4c74:	97fff35b 	bl	19e0 <fwp_fmt_u128>
    4c78:	17ffffed 	b	4c2c <fwp_write.constprop.0+0xf0c>
    4c7c:	f9013bf5 	str	x21, [sp, #624]
    4c80:	f9013ff6 	str	x22, [sp, #632]
    4c84:	f90143f7 	str	x23, [sp, #640]
    4c88:	f90147f8 	str	x24, [sp, #648]
    4c8c:	f9014bf9 	str	x25, [sp, #656]
    4c90:	f9014ffa 	str	x26, [sp, #664]
    4c94:	f90153fb 	str	x27, [sp, #672]
    4c98:	f90157fc 	str	x28, [sp, #680]
    4c9c:	fd015be8 	str	d8, [sp, #688]
    4ca0:	fd015fe9 	str	d9, [sp, #696]
    4ca4:	97fff1ff 	bl	14a0 <__stack_chk_fail@plt>
    4ca8:	f90143f7 	str	x23, [sp, #640]
    4cac:	f90147f8 	str	x24, [sp, #648]
    4cb0:	f9014bf9 	str	x25, [sp, #656]
    4cb4:	f9014ffa 	str	x26, [sp, #664]
    4cb8:	fd015be8 	str	d8, [sp, #688]
    4cbc:	fd015fe9 	str	d9, [sp, #696]
    4cc0:	97fff1f8 	bl	14a0 <__stack_chk_fail@plt>

0000000000004cc4 <fwp_hof0.constprop.0>:
    4cc4:	d102c3ff 	sub	sp, sp, #0xb0
    4cc8:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x152b8>
    4ccc:	f947f442 	ldr	x2, [x2, #4072]
    4cd0:	a9047bfd 	stp	x29, x30, [sp, #64]
    4cd4:	910103fd 	add	x29, sp, #0x40
    4cd8:	a9065bf5 	stp	x21, x22, [sp, #96]
    4cdc:	aa0003f5 	mov	x21, x0
    4ce0:	f9400040 	ldr	x0, [x2]
    4ce4:	f9001fe0 	str	x0, [sp, #56]
    4ce8:	d2800000 	mov	x0, #0x0                   	// #0
    4cec:	f90007e1 	str	x1, [sp, #8]
    4cf0:	b40043e1 	cbz	x1, 556c <fwp_hof0.constprop.0+0x8a8>
    4cf4:	b0000021 	adrp	x1, 9000 <msg.3+0x20>
    4cf8:	6d0a27e8 	stp	d8, d9, [sp, #160]
    4cfc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    4d00:	fd401829 	ldr	d9, [x1, #48]
    4d04:	9e670008 	fmov	d8, x0
    4d08:	a90553f3 	stp	x19, x20, [sp, #80]
    4d0c:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xcd0>
    4d10:	a90763f7 	stp	x23, x24, [sp, #112]
    4d14:	a9086bf9 	stp	x25, x26, [sp, #128]
    4d18:	a90973fb 	stp	x27, x28, [sp, #144]
    4d1c:	d503201f 	nop
    4d20:	91144282 	add	x2, x20, #0x510
    4d24:	f949d840 	ldr	x0, [x2, #5040]
    4d28:	f949ec41 	ldr	x1, [x2, #5080]
    4d2c:	cb0002a0 	sub	x0, x21, x0
    4d30:	eb01401f 	cmp	x0, x1, lsl #16
    4d34:	54000342 	b.cs	4d9c <fwp_hof0.constprop.0+0xd8>  // b.hs, b.nlast
    4d38:	d350fc01 	lsr	x1, x0, #16
    4d3c:	f949fc43 	ldr	x3, [x2, #5112]
    4d40:	8b010821 	add	x1, x1, x1, lsl #2
    4d44:	d37df021 	lsl	x1, x1, #3
    4d48:	8b010062 	add	x2, x3, x1
    4d4c:	f9401053 	ldr	x19, [x2, #32]
    4d50:	b4000273 	cbz	x19, 4d9c <fwp_hof0.constprop.0+0xd8>
    4d54:	38616861 	ldrb	w1, [x3, x1]
    4d58:	7100083f 	cmp	w1, #0x2
    4d5c:	54004ec0 	b.eq	5734 <fwp_hof0.constprop.0+0xa70>  // b.none
    4d60:	7100043f 	cmp	w1, #0x1
    4d64:	540001c1 	b.ne	4d9c <fwp_hof0.constprop.0+0xd8>  // b.any
    4d68:	29430443 	ldp	w3, w1, [x2, #24]
    4d6c:	92403c00 	and	x0, x0, #0xffff
    4d70:	9b037c00 	mul	x0, x0, x3
    4d74:	d360fc00 	lsr	x0, x0, #32
    4d78:	eb01001f 	cmp	x0, x1
    4d7c:	54000102 	b.cs	4d9c <fwp_hof0.constprop.0+0xd8>  // b.hs, b.nlast
    4d80:	8b000273 	add	x19, x19, x0
    4d84:	39400260 	ldrb	w0, [x19]
    4d88:	340000a0 	cbz	w0, 4d9c <fwp_hof0.constprop.0+0xd8>
    4d8c:	7103f41f 	cmp	w0, #0xfd
    4d90:	54005848 	b.hi	5898 <fwp_hof0.constprop.0+0xbd4>  // b.pmore
    4d94:	11000400 	add	w0, w0, #0x1
    4d98:	39000260 	strb	w0, [x19]
    4d9c:	b4004d35 	cbz	x21, 5740 <fwp_hof0.constprop.0+0xa7c>
    4da0:	aa1503e1 	mov	x1, x21
    4da4:	d2800000 	mov	x0, #0x0                   	// #0
    4da8:	f9400821 	ldr	x1, [x1, #16]
    4dac:	91000400 	add	x0, x0, #0x1
    4db0:	b5ffffc1 	cbnz	x1, 4da8 <fwp_hof0.constprop.0+0xe4>
    4db4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    4db8:	eb01001f 	cmp	x0, x1
    4dbc:	54006028 	b.hi	59c0 <fwp_hof0.constprop.0+0xcfc>  // b.pmore
    4dc0:	97fffa19 	bl	3624 <fwp_array_new_packed.constprop.0>
    4dc4:	aa0003f8 	mov	x24, x0
    4dc8:	91144281 	add	x1, x20, #0x510
    4dcc:	aa0103e0 	mov	x0, x1
    4dd0:	f949d821 	ldr	x1, [x1, #5040]
    4dd4:	f949ec00 	ldr	x0, [x0, #5080]
    4dd8:	cb010301 	sub	x1, x24, x1
    4ddc:	eb00403f 	cmp	x1, x0, lsl #16
    4de0:	54000362 	b.cs	4e4c <fwp_hof0.constprop.0+0x188>  // b.hs, b.nlast
    4de4:	91144282 	add	x2, x20, #0x510
    4de8:	d350fc20 	lsr	x0, x1, #16
    4dec:	8b000800 	add	x0, x0, x0, lsl #2
    4df0:	f949fc43 	ldr	x3, [x2, #5112]
    4df4:	d37df002 	lsl	x2, x0, #3
    4df8:	8b020060 	add	x0, x3, x2
    4dfc:	f9401013 	ldr	x19, [x0, #32]
    4e00:	b4000253 	cbz	x19, 4e48 <fwp_hof0.constprop.0+0x184>
    4e04:	38626862 	ldrb	w2, [x3, x2]
    4e08:	7100085f 	cmp	w2, #0x2
    4e0c:	54004b20 	b.eq	5770 <fwp_hof0.constprop.0+0xaac>  // b.none
    4e10:	7100045f 	cmp	w2, #0x1
    4e14:	540001a1 	b.ne	4e48 <fwp_hof0.constprop.0+0x184>  // b.any
    4e18:	29430002 	ldp	w2, w0, [x0, #24]
    4e1c:	92403c21 	and	x1, x1, #0xffff
    4e20:	9b027c21 	mul	x1, x1, x2
    4e24:	d360fc21 	lsr	x1, x1, #32
    4e28:	eb00003f 	cmp	x1, x0
    4e2c:	540000e2 	b.cs	4e48 <fwp_hof0.constprop.0+0x184>  // b.hs, b.nlast
    4e30:	8b010273 	add	x19, x19, x1
    4e34:	39400260 	ldrb	w0, [x19]
    4e38:	7103fc1f 	cmp	w0, #0xff
    4e3c:	54004a40 	b.eq	5784 <fwp_hof0.constprop.0+0xac0>  // b.none
    4e40:	52800020 	mov	w0, #0x1                   	// #1
    4e44:	39000260 	strb	w0, [x19]
    4e48:	b4004915 	cbz	x21, 5768 <fwp_hof0.constprop.0+0xaa4>
    4e4c:	91002316 	add	x22, x24, #0x8
    4e50:	aa1503e0 	mov	x0, x21
    4e54:	aa1503f3 	mov	x19, x21
    4e58:	91144299 	add	x25, x20, #0x510
    4e5c:	5280003a 	mov	w26, #0x1                   	// #1
    4e60:	14000014 	b	4eb0 <fwp_hof0.constprop.0+0x1ec>
    4e64:	7100045f 	cmp	w2, #0x1
    4e68:	54000181 	b.ne	4e98 <fwp_hof0.constprop.0+0x1d4>  // b.any
    4e6c:	294308e8 	ldp	w8, w2, [x7, #24]
    4e70:	92403c21 	and	x1, x1, #0xffff
    4e74:	9b087c21 	mul	x1, x1, x8
    4e78:	d360fc21 	lsr	x1, x1, #32
    4e7c:	eb02003f 	cmp	x1, x2
    4e80:	540000c2 	b.cs	4e98 <fwp_hof0.constprop.0+0x1d4>  // b.hs, b.nlast
    4e84:	8b0100a5 	add	x5, x5, x1
    4e88:	394000a1 	ldrb	w1, [x5]
    4e8c:	7100043f 	cmp	w1, #0x1
    4e90:	54000400 	b.eq	4f10 <fwp_hof0.constprop.0+0x24c>  // b.none
    4e94:	d503201f 	nop
    4e98:	f9400301 	ldr	x1, [x24]
    4e9c:	b7f855e1 	tbnz	x1, #63, 5958 <fwp_hof0.constprop.0+0xc94>
    4ea0:	f90002c4 	str	x4, [x22]
    4ea4:	5280001a 	mov	w26, #0x0                   	// #0
    4ea8:	910022d6 	add	x22, x22, #0x8
    4eac:	b4000773 	cbz	x19, 4f98 <fwp_hof0.constprop.0+0x2d4>
    4eb0:	aa1303e6 	mov	x6, x19
    4eb4:	aa1303e3 	mov	x3, x19
    4eb8:	a940ce64 	ldp	x4, x19, [x19, #8]
    4ebc:	34fffefa 	cbz	w26, 4e98 <fwp_hof0.constprop.0+0x1d4>
    4ec0:	f949db21 	ldr	x1, [x25, #5040]
    4ec4:	f949ef22 	ldr	x2, [x25, #5080]
    4ec8:	cb0100c1 	sub	x1, x6, x1
    4ecc:	eb02403f 	cmp	x1, x2, lsl #16
    4ed0:	54fffe42 	b.cs	4e98 <fwp_hof0.constprop.0+0x1d4>  // b.hs, b.nlast
    4ed4:	d350fc22 	lsr	x2, x1, #16
    4ed8:	f949ff28 	ldr	x8, [x25, #5112]
    4edc:	8b020842 	add	x2, x2, x2, lsl #2
    4ee0:	d37df042 	lsl	x2, x2, #3
    4ee4:	8b020107 	add	x7, x8, x2
    4ee8:	f94010e5 	ldr	x5, [x7, #32]
    4eec:	b4fffd65 	cbz	x5, 4e98 <fwp_hof0.constprop.0+0x1d4>
    4ef0:	38626902 	ldrb	w2, [x8, x2]
    4ef4:	7100085f 	cmp	w2, #0x2
    4ef8:	54fffb61 	b.ne	4e64 <fwp_hof0.constprop.0+0x1a0>  // b.any
    4efc:	72003c3f 	tst	w1, #0xffff
    4f00:	54fffcc1 	b.ne	4e98 <fwp_hof0.constprop.0+0x1d4>  // b.any
    4f04:	394000a1 	ldrb	w1, [x5]
    4f08:	7100043f 	cmp	w1, #0x1
    4f0c:	54fffc61 	b.ne	4e98 <fwp_hof0.constprop.0+0x1d4>  // b.any
    4f10:	f9400300 	ldr	x0, [x24]
    4f14:	b7f85220 	tbnz	x0, #63, 5958 <fwp_hof0.constprop.0+0xc94>
    4f18:	f90002c4 	str	x4, [x22]
    4f1c:	f949db21 	ldr	x1, [x25, #5040]
    4f20:	f949ef20 	ldr	x0, [x25, #5080]
    4f24:	cb010063 	sub	x3, x3, x1
    4f28:	eb00407f 	cmp	x3, x0, lsl #16
    4f2c:	540002e2 	b.cs	4f88 <fwp_hof0.constprop.0+0x2c4>  // b.hs, b.nlast
    4f30:	d350fc60 	lsr	x0, x3, #16
    4f34:	f949ff21 	ldr	x1, [x25, #5112]
    4f38:	8b000800 	add	x0, x0, x0, lsl #2
    4f3c:	d37df000 	lsl	x0, x0, #3
    4f40:	8b000024 	add	x4, x1, x0
    4f44:	f9401082 	ldr	x2, [x4, #32]
    4f48:	b4000202 	cbz	x2, 4f88 <fwp_hof0.constprop.0+0x2c4>
    4f4c:	38606820 	ldrb	w0, [x1, x0]
    4f50:	7100081f 	cmp	w0, #0x2
    4f54:	54003cc0 	b.eq	56ec <fwp_hof0.constprop.0+0xa28>  // b.none
    4f58:	7100041f 	cmp	w0, #0x1
    4f5c:	54000161 	b.ne	4f88 <fwp_hof0.constprop.0+0x2c4>  // b.any
    4f60:	29430085 	ldp	w5, w0, [x4, #24]
    4f64:	92403c61 	and	x1, x3, #0xffff
    4f68:	9b057c21 	mul	x1, x1, x5
    4f6c:	d360fc21 	lsr	x1, x1, #32
    4f70:	eb00003f 	cmp	x1, x0
    4f74:	540000a2 	b.cs	4f88 <fwp_hof0.constprop.0+0x2c4>  // b.hs, b.nlast
    4f78:	8b010042 	add	x2, x2, x1
    4f7c:	39400040 	ldrb	w0, [x2]
    4f80:	7100041f 	cmp	w0, #0x1
    4f84:	54000ac0 	b.eq	50dc <fwp_hof0.constprop.0+0x418>  // b.none
    4f88:	aa1303e0 	mov	x0, x19
    4f8c:	910022d6 	add	x22, x22, #0x8
    4f90:	b5fff913 	cbnz	x19, 4eb0 <fwp_hof0.constprop.0+0x1ec>
    4f94:	d503201f 	nop
    4f98:	d28018da 	mov	x26, #0xc6                  	// #198
    4f9c:	b27feff6 	mov	x22, #0x1ffffffffffffffe    	// #2305843009213693950
    4fa0:	97fff9b4 	bl	3670 <fwp_drop0>
    4fa4:	d503201f 	nop
    4fa8:	f9400319 	ldr	x25, [x24]
    4fac:	9240fb39 	and	x25, x25, #0x7fffffffffffffff
    4fb0:	eb16033f 	cmp	x25, x22
    4fb4:	54005068 	b.hi	59c0 <fwp_hof0.constprop.0+0xcfc>  // b.pmore
    4fb8:	aa1903e0 	mov	x0, x25
    4fbc:	97fff99a 	bl	3624 <fwp_array_new_packed.constprop.0>
    4fc0:	91144282 	add	x2, x20, #0x510
    4fc4:	aa0003f3 	mov	x19, x0
    4fc8:	f949d841 	ldr	x1, [x2, #5040]
    4fcc:	f949ec40 	ldr	x0, [x2, #5080]
    4fd0:	cb010261 	sub	x1, x19, x1
    4fd4:	eb00403f 	cmp	x1, x0, lsl #16
    4fd8:	54000322 	b.cs	503c <fwp_hof0.constprop.0+0x378>  // b.hs, b.nlast
    4fdc:	d350fc20 	lsr	x0, x1, #16
    4fe0:	f949fc43 	ldr	x3, [x2, #5112]
    4fe4:	8b000800 	add	x0, x0, x0, lsl #2
    4fe8:	d37df002 	lsl	x2, x0, #3
    4fec:	8b020060 	add	x0, x3, x2
    4ff0:	f940101b 	ldr	x27, [x0, #32]
    4ff4:	b400025b 	cbz	x27, 503c <fwp_hof0.constprop.0+0x378>
    4ff8:	38626862 	ldrb	w2, [x3, x2]
    4ffc:	7100085f 	cmp	w2, #0x2
    5000:	540031a0 	b.eq	5634 <fwp_hof0.constprop.0+0x970>  // b.none
    5004:	7100045f 	cmp	w2, #0x1
    5008:	540001a1 	b.ne	503c <fwp_hof0.constprop.0+0x378>  // b.any
    500c:	29430002 	ldp	w2, w0, [x0, #24]
    5010:	92403c21 	and	x1, x1, #0xffff
    5014:	9b027c21 	mul	x1, x1, x2
    5018:	d360fc21 	lsr	x1, x1, #32
    501c:	eb00003f 	cmp	x1, x0
    5020:	540000e2 	b.cs	503c <fwp_hof0.constprop.0+0x378>  // b.hs, b.nlast
    5024:	8b01037b 	add	x27, x27, x1
    5028:	39400360 	ldrb	w0, [x27]
    502c:	7103fc1f 	cmp	w0, #0xff
    5030:	540030c0 	b.eq	5648 <fwp_hof0.constprop.0+0x984>  // b.none
    5034:	52800020 	mov	w0, #0x1                   	// #1
    5038:	39000360 	strb	w0, [x27]
    503c:	d2800103 	mov	x3, #0x8                   	// #8
    5040:	2f00e405 	movi	d5, #0x0
    5044:	8b030301 	add	x1, x24, x3
    5048:	d2800024 	mov	x4, #0x1                   	// #1
    504c:	d2800002 	mov	x2, #0x0                   	// #0
    5050:	1e6e1006 	fmov	d6, #1.000000000000000000e+00
    5054:	b4000819 	cbz	x25, 5154 <fwp_hof0.constprop.0+0x490>
    5058:	f9400300 	ldr	x0, [x24]
    505c:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    5060:	eb0200bf 	cmp	x5, x2
    5064:	54000349 	b.ls	50cc <fwp_hof0.constprop.0+0x408>  // b.plast
    5068:	aa0103e6 	mov	x6, x1
    506c:	b7f82980 	tbnz	x0, #63, 559c <fwp_hof0.constprop.0+0x8d8>
    5070:	fc6278c3 	ldr	d3, [x6, x2, lsl #3]
    5074:	9e6703e1 	fmov	d1, xzr
    5078:	b4000242 	cbz	x2, 50c0 <fwp_hof0.constprop.0+0x3fc>
    507c:	8b0300c0 	add	x0, x6, x3
    5080:	fc5f0000 	ldur	d0, [x0, #-16]
    5084:	1e650801 	fmul	d1, d0, d5
    5088:	1e600802 	fmul	d2, d0, d0
    508c:	1e6038c0 	fsub	d0, d6, d0
    5090:	1e612821 	fadd	d1, d1, d1
    5094:	1e623862 	fsub	d2, d3, d2
    5098:	1e650800 	fmul	d0, d0, d5
    509c:	1e6138c1 	fsub	d1, d6, d1
    50a0:	1e620844 	fmul	d4, d2, d2
    50a4:	1e602800 	fadd	d0, d0, d0
    50a8:	1e620821 	fmul	d1, d1, d2
    50ac:	1e650882 	fmul	d2, d4, d5
    50b0:	1e612821 	fadd	d1, d1, d1
    50b4:	1e680821 	fmul	d1, d1, d8
    50b8:	1e622821 	fadd	d1, d1, d2
    50bc:	1e602821 	fadd	d1, d1, d0
    50c0:	eb0400bf 	cmp	x5, x4
    50c4:	54000940 	b.eq	51ec <fwp_hof0.constprop.0+0x528>  // b.none
    50c8:	54000128 	b.hi	50ec <fwp_hof0.constprop.0+0x428>  // b.pmore
    50cc:	f00000c0 	adrp	x0, 20000 <__data_start>
    50d0:	91004000 	add	x0, x0, #0x10
    50d4:	91002000 	add	x0, x0, #0x8
    50d8:	97fff3f2 	bl	20a0 <fwp_trap>
    50dc:	aa0603e0 	mov	x0, x6
    50e0:	97fff750 	bl	2e20 <fwp_mem_free>
    50e4:	aa1303e0 	mov	x0, x19
    50e8:	17ffffa9 	b	4f8c <fwp_hof0.constprop.0+0x2c8>
    50ec:	fc6368c4 	ldr	d4, [x6, x3]
    50f0:	1e630867 	fmul	d7, d3, d3
    50f4:	1e632860 	fadd	d0, d3, d3
    50f8:	1e6338c2 	fsub	d2, d6, d3
    50fc:	1e673884 	fsub	d4, d4, d7
    5100:	1e6038a0 	fsub	d0, d5, d0
    5104:	1e614042 	fneg	d2, d2
    5108:	1e640887 	fmul	d7, d4, d4
    510c:	1e640800 	fmul	d0, d0, d4
    5110:	1e622842 	fadd	d2, d2, d2
    5114:	1e6508e4 	fmul	d4, d7, d5
    5118:	1e602800 	fadd	d0, d0, d0
    511c:	1e680800 	fmul	d0, d0, d8
    5120:	1e642800 	fadd	d0, d0, d4
    5124:	1e622800 	fadd	d0, d0, d2
    5128:	1e612800 	fadd	d0, d0, d1
    512c:	f9400260 	ldr	x0, [x19]
    5130:	1e690800 	fmul	d0, d0, d9
    5134:	1e603863 	fsub	d3, d3, d0
    5138:	b7f84100 	tbnz	x0, #63, 5958 <fwp_hof0.constprop.0+0xc94>
    513c:	91000442 	add	x2, x2, #0x1
    5140:	fc336863 	str	d3, [x3, x19]
    5144:	91000484 	add	x4, x4, #0x1
    5148:	91002063 	add	x3, x3, #0x8
    514c:	eb02033f 	cmp	x25, x2
    5150:	54fff841 	b.ne	5058 <fwp_hof0.constprop.0+0x394>  // b.any
    5154:	91144299 	add	x25, x20, #0x510
    5158:	f949db21 	ldr	x1, [x25, #5040]
    515c:	f949ef20 	ldr	x0, [x25, #5080]
    5160:	cb010301 	sub	x1, x24, x1
    5164:	eb00403f 	cmp	x1, x0, lsl #16
    5168:	54000382 	b.cs	51d8 <fwp_hof0.constprop.0+0x514>  // b.hs, b.nlast
    516c:	d350fc20 	lsr	x0, x1, #16
    5170:	f949ff24 	ldr	x4, [x25, #5112]
    5174:	8b000800 	add	x0, x0, x0, lsl #2
    5178:	d37df000 	lsl	x0, x0, #3
    517c:	8b000082 	add	x2, x4, x0
    5180:	f940105b 	ldr	x27, [x2, #32]
    5184:	b40002bb 	cbz	x27, 51d8 <fwp_hof0.constprop.0+0x514>
    5188:	38606880 	ldrb	w0, [x4, x0]
    518c:	7100081f 	cmp	w0, #0x2
    5190:	540020a0 	b.eq	55a4 <fwp_hof0.constprop.0+0x8e0>  // b.none
    5194:	7100041f 	cmp	w0, #0x1
    5198:	54000201 	b.ne	51d8 <fwp_hof0.constprop.0+0x514>  // b.any
    519c:	29430043 	ldp	w3, w0, [x2, #24]
    51a0:	92403c21 	and	x1, x1, #0xffff
    51a4:	9b037c21 	mul	x1, x1, x3
    51a8:	d360fc21 	lsr	x1, x1, #32
    51ac:	eb00003f 	cmp	x1, x0
    51b0:	54000142 	b.cs	51d8 <fwp_hof0.constprop.0+0x514>  // b.hs, b.nlast
    51b4:	8b01037b 	add	x27, x27, x1
    51b8:	39400360 	ldrb	w0, [x27]
    51bc:	340000e0 	cbz	w0, 51d8 <fwp_hof0.constprop.0+0x514>
    51c0:	7100041f 	cmp	w0, #0x1
    51c4:	54000180 	b.eq	51f4 <fwp_hof0.constprop.0+0x530>  // b.none
    51c8:	7103fc1f 	cmp	w0, #0xff
    51cc:	54002e20 	b.eq	5790 <fwp_hof0.constprop.0+0xacc>  // b.none
    51d0:	51000400 	sub	w0, w0, #0x1
    51d4:	39000360 	strb	w0, [x27]
    51d8:	b400051a 	cbz	x26, 5278 <fwp_hof0.constprop.0+0x5b4>
    51dc:	f100075a 	subs	x26, x26, #0x1
    51e0:	54004146 	b.vs	5a08 <fwp_hof0.constprop.0+0xd44>
    51e4:	aa1303f8 	mov	x24, x19
    51e8:	17ffff70 	b	4fa8 <fwp_hof0.constprop.0+0x2e4>
    51ec:	2f00e400 	movi	d0, #0x0
    51f0:	17ffffce 	b	5128 <fwp_hof0.constprop.0+0x464>
    51f4:	f9400305 	ldr	x5, [x24]
    51f8:	aa1803e0 	mov	x0, x24
    51fc:	f949ef23 	ldr	x3, [x25, #5080]
    5200:	f949db21 	ldr	x1, [x25, #5040]
    5204:	d370bc63 	lsl	x3, x3, #16
    5208:	cb010302 	sub	x2, x24, x1
    520c:	b7f81d25 	tbnz	x5, #63, 55b0 <fwp_hof0.constprop.0+0x8ec>
    5210:	eb02007f 	cmp	x3, x2
    5214:	54fffe29 	b.ls	51d8 <fwp_hof0.constprop.0+0x514>  // b.plast
    5218:	d350fc40 	lsr	x0, x2, #16
    521c:	8b000800 	add	x0, x0, x0, lsl #2
    5220:	d37df000 	lsl	x0, x0, #3
    5224:	8b000083 	add	x3, x4, x0
    5228:	f9401061 	ldr	x1, [x3, #32]
    522c:	b4fffd61 	cbz	x1, 51d8 <fwp_hof0.constprop.0+0x514>
    5230:	38606880 	ldrb	w0, [x4, x0]
    5234:	7100081f 	cmp	w0, #0x2
    5238:	540020e0 	b.eq	5654 <fwp_hof0.constprop.0+0x990>  // b.none
    523c:	7100041f 	cmp	w0, #0x1
    5240:	54fffcc1 	b.ne	51d8 <fwp_hof0.constprop.0+0x514>  // b.any
    5244:	92403c40 	and	x0, x2, #0xffff
    5248:	29430864 	ldp	w4, w2, [x3, #24]
    524c:	9b047c00 	mul	x0, x0, x4
    5250:	d360fc00 	lsr	x0, x0, #32
    5254:	eb02001f 	cmp	x0, x2
    5258:	54fffc02 	b.cs	51d8 <fwp_hof0.constprop.0+0x514>  // b.hs, b.nlast
    525c:	8b000021 	add	x1, x1, x0
    5260:	39400020 	ldrb	w0, [x1]
    5264:	7100041f 	cmp	w0, #0x1
    5268:	54fffb81 	b.ne	51d8 <fwp_hof0.constprop.0+0x514>  // b.any
    526c:	aa1803e0 	mov	x0, x24
    5270:	97fff6ec 	bl	2e20 <fwp_mem_free>
    5274:	b5fffb5a 	cbnz	x26, 51dc <fwp_hof0.constprop.0+0x518>
    5278:	52800b63 	mov	w3, #0x5b                  	// #91
    527c:	91007ffc 	add	x28, sp, #0x1f
    5280:	910083f6 	add	x22, sp, #0x20
    5284:	aa1c03e1 	mov	x1, x28
    5288:	aa1603e0 	mov	x0, x22
    528c:	d2800022 	mov	x2, #0x1                   	// #1
    5290:	39007fe3 	strb	w3, [sp, #31]
    5294:	d2800017 	mov	x23, #0x0                   	// #0
    5298:	a9027fff 	stp	xzr, xzr, [sp, #32]
    529c:	d00000d8 	adrp	x24, 1f000 <__FRAME_END__+0x152b8>
    52a0:	f9001bff 	str	xzr, [sp, #48]
    52a4:	97fff323 	bl	1f30 <buf_put>
    52a8:	f9400260 	ldr	x0, [x19]
    52ac:	f240f81a 	ands	x26, x0, #0x7fffffffffffffff
    52b0:	540003c0 	b.eq	5328 <fwp_hof0.constprop.0+0x664>  // b.none
    52b4:	912ca318 	add	x24, x24, #0xb28
    52b8:	f0000019 	adrp	x25, 8000 <fwp_main_thread+0x170>
    52bc:	91014318 	add	x24, x24, #0x50
    52c0:	9136a339 	add	x25, x25, #0xda8
    52c4:	9100227b 	add	x27, x19, #0x8
    52c8:	1400000d 	b	52fc <fwp_hof0.constprop.0+0x638>
    52cc:	f8777821 	ldr	x1, [x1, x23, lsl #3]
    52d0:	aa1803e2 	mov	x2, x24
    52d4:	aa1603e0 	mov	x0, x22
    52d8:	910006f7 	add	x23, x23, #0x1
    52dc:	97fffa91 	bl	3d20 <fwp_write.constprop.0>
    52e0:	eb17035f 	cmp	x26, x23
    52e4:	54000220 	b.eq	5328 <fwp_hof0.constprop.0+0x664>  // b.none
    52e8:	aa1603e0 	mov	x0, x22
    52ec:	aa1903e1 	mov	x1, x25
    52f0:	d2800042 	mov	x2, #0x2                   	// #2
    52f4:	97fff30f 	bl	1f30 <buf_put>
    52f8:	f9400260 	ldr	x0, [x19]
    52fc:	aa1b03e1 	mov	x1, x27
    5300:	b6fffe60 	tbz	x0, #63, 52cc <fwp_hof0.constprop.0+0x608>
    5304:	f9400a61 	ldr	x1, [x19, #16]
    5308:	aa1803e2 	mov	x2, x24
    530c:	aa1603e0 	mov	x0, x22
    5310:	f8777821 	ldr	x1, [x1, x23, lsl #3]
    5314:	910006f7 	add	x23, x23, #0x1
    5318:	97fffa82 	bl	3d20 <fwp_write.constprop.0>
    531c:	eb17035f 	cmp	x26, x23
    5320:	54fffe41 	b.ne	52e8 <fwp_hof0.constprop.0+0x624>  // b.any
    5324:	d503201f 	nop
    5328:	52800ba3 	mov	w3, #0x5d                  	// #93
    532c:	aa1603e0 	mov	x0, x22
    5330:	aa1c03e1 	mov	x1, x28
    5334:	d2800022 	mov	x2, #0x1                   	// #1
    5338:	39007fe3 	strb	w3, [sp, #31]
    533c:	97fff2fd 	bl	1f30 <buf_put>
    5340:	a94263f9 	ldp	x25, x24, [sp, #32]
    5344:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x170>
    5348:	91356000 	add	x0, x0, #0xd58
    534c:	f100033f 	cmp	x25, #0x0
    5350:	9a990019 	csel	x25, x0, x25, eq	// eq = none
    5354:	b1002b1f 	cmn	x24, #0xa
    5358:	54003528 	b.hi	59fc <fwp_hof0.constprop.0+0xd38>  // b.pmore
    535c:	91002700 	add	x0, x24, #0x9
    5360:	52800021 	mov	w1, #0x1                   	// #1
    5364:	97fff820 	bl	33e4 <fwp_heap_alloc>
    5368:	aa0003f6 	mov	x22, x0
    536c:	aa1903e1 	mov	x1, x25
    5370:	aa0003f9 	mov	x25, x0
    5374:	aa1803e2 	mov	x2, x24
    5378:	f8008738 	str	x24, [x25], #8
    537c:	8b1802d8 	add	x24, x22, x24
    5380:	aa1903e0 	mov	x0, x25
    5384:	97ffefdf 	bl	1300 <memcpy@plt>
    5388:	f94013e0 	ldr	x0, [sp, #32]
    538c:	3900231f 	strb	wzr, [x24, #8]
    5390:	97fff074 	bl	1560 <free@plt>
    5394:	91144282 	add	x2, x20, #0x510
    5398:	f949ec43 	ldr	x3, [x2, #5080]
    539c:	f949d841 	ldr	x1, [x2, #5040]
    53a0:	d370bc63 	lsl	x3, x3, #16
    53a4:	cb0102c4 	sub	x4, x22, x1
    53a8:	eb03009f 	cmp	x4, x3
    53ac:	540003a2 	b.cs	5420 <fwp_hof0.constprop.0+0x75c>  // b.hs, b.nlast
    53b0:	d350fc80 	lsr	x0, x4, #16
    53b4:	f949fc45 	ldr	x5, [x2, #5112]
    53b8:	8b000800 	add	x0, x0, x0, lsl #2
    53bc:	d37df002 	lsl	x2, x0, #3
    53c0:	8b0200a0 	add	x0, x5, x2
    53c4:	f9401018 	ldr	x24, [x0, #32]
    53c8:	b40002d8 	cbz	x24, 5420 <fwp_hof0.constprop.0+0x75c>
    53cc:	386268a2 	ldrb	w2, [x5, x2]
    53d0:	7100085f 	cmp	w2, #0x2
    53d4:	540020a0 	b.eq	57e8 <fwp_hof0.constprop.0+0xb24>  // b.none
    53d8:	7100045f 	cmp	w2, #0x1
    53dc:	54000221 	b.ne	5420 <fwp_hof0.constprop.0+0x75c>  // b.any
    53e0:	29430005 	ldp	w5, w0, [x0, #24]
    53e4:	92403c82 	and	x2, x4, #0xffff
    53e8:	9b057c42 	mul	x2, x2, x5
    53ec:	d360fc42 	lsr	x2, x2, #32
    53f0:	eb00005f 	cmp	x2, x0
    53f4:	54000162 	b.cs	5420 <fwp_hof0.constprop.0+0x75c>  // b.hs, b.nlast
    53f8:	8b020318 	add	x24, x24, x2
    53fc:	39400300 	ldrb	w0, [x24]
    5400:	7103fc1f 	cmp	w0, #0xff
    5404:	54001fc0 	b.eq	57fc <fwp_hof0.constprop.0+0xb38>  // b.none
    5408:	91144280 	add	x0, x20, #0x510
    540c:	52800021 	mov	w1, #0x1                   	// #1
    5410:	39000301 	strb	w1, [x24]
    5414:	f949ec03 	ldr	x3, [x0, #5080]
    5418:	f949d801 	ldr	x1, [x0, #5040]
    541c:	d370bc63 	lsl	x3, x3, #16
    5420:	cb010261 	sub	x1, x19, x1
    5424:	9114429a 	add	x26, x20, #0x510
    5428:	eb01007f 	cmp	x3, x1
    542c:	540003a9 	b.ls	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.plast
    5430:	d350fc20 	lsr	x0, x1, #16
    5434:	f949ff43 	ldr	x3, [x26, #5112]
    5438:	8b000800 	add	x0, x0, x0, lsl #2
    543c:	d37df002 	lsl	x2, x0, #3
    5440:	8b020060 	add	x0, x3, x2
    5444:	f9401018 	ldr	x24, [x0, #32]
    5448:	b40002d8 	cbz	x24, 54a0 <fwp_hof0.constprop.0+0x7dc>
    544c:	38626862 	ldrb	w2, [x3, x2]
    5450:	7100085f 	cmp	w2, #0x2
    5454:	54001540 	b.eq	56fc <fwp_hof0.constprop.0+0xa38>  // b.none
    5458:	7100045f 	cmp	w2, #0x1
    545c:	54000221 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    5460:	29430002 	ldp	w2, w0, [x0, #24]
    5464:	92403c21 	and	x1, x1, #0xffff
    5468:	9b027c21 	mul	x1, x1, x2
    546c:	d360fc21 	lsr	x1, x1, #32
    5470:	eb00003f 	cmp	x1, x0
    5474:	54000162 	b.cs	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.hs, b.nlast
    5478:	8b010318 	add	x24, x24, x1
    547c:	39400300 	ldrb	w0, [x24]
    5480:	34000100 	cbz	w0, 54a0 <fwp_hof0.constprop.0+0x7dc>
    5484:	7100041f 	cmp	w0, #0x1
    5488:	54000ec0 	b.eq	5660 <fwp_hof0.constprop.0+0x99c>  // b.none
    548c:	7103fc1f 	cmp	w0, #0xff
    5490:	54001d40 	b.eq	5838 <fwp_hof0.constprop.0+0xb74>  // b.none
    5494:	51000400 	sub	w0, w0, #0x1
    5498:	39000300 	strb	w0, [x24]
    549c:	d503201f 	nop
    54a0:	f00000d3 	adrp	x19, 20000 <__data_start>
    54a4:	d2800021 	mov	x1, #0x1                   	// #1
    54a8:	f94002c2 	ldr	x2, [x22]
    54ac:	aa1903e0 	mov	x0, x25
    54b0:	f9403a63 	ldr	x3, [x19, #112]
    54b4:	97fff03b 	bl	15a0 <fwrite@plt>
    54b8:	f9403a61 	ldr	x1, [x19, #112]
    54bc:	52800140 	mov	w0, #0xa                   	// #10
    54c0:	97ffefc0 	bl	13c0 <fputc@plt>
    54c4:	91144282 	add	x2, x20, #0x510
    54c8:	f949d841 	ldr	x1, [x2, #5040]
    54cc:	f949ec40 	ldr	x0, [x2, #5080]
    54d0:	cb0102c1 	sub	x1, x22, x1
    54d4:	eb00403f 	cmp	x1, x0, lsl #16
    54d8:	54000382 	b.cs	5548 <fwp_hof0.constprop.0+0x884>  // b.hs, b.nlast
    54dc:	d350fc20 	lsr	x0, x1, #16
    54e0:	f949fc43 	ldr	x3, [x2, #5112]
    54e4:	8b000800 	add	x0, x0, x0, lsl #2
    54e8:	d37df002 	lsl	x2, x0, #3
    54ec:	8b020060 	add	x0, x3, x2
    54f0:	f9401013 	ldr	x19, [x0, #32]
    54f4:	b40002b3 	cbz	x19, 5548 <fwp_hof0.constprop.0+0x884>
    54f8:	38626862 	ldrb	w2, [x3, x2]
    54fc:	7100085f 	cmp	w2, #0x2
    5500:	54001840 	b.eq	5808 <fwp_hof0.constprop.0+0xb44>  // b.none
    5504:	7100045f 	cmp	w2, #0x1
    5508:	54000201 	b.ne	5548 <fwp_hof0.constprop.0+0x884>  // b.any
    550c:	29430002 	ldp	w2, w0, [x0, #24]
    5510:	92403c21 	and	x1, x1, #0xffff
    5514:	9b027c21 	mul	x1, x1, x2
    5518:	d360fc21 	lsr	x1, x1, #32
    551c:	eb00003f 	cmp	x1, x0
    5520:	54000142 	b.cs	5548 <fwp_hof0.constprop.0+0x884>  // b.hs, b.nlast
    5524:	8b010273 	add	x19, x19, x1
    5528:	39400260 	ldrb	w0, [x19]
    552c:	340000e0 	cbz	w0, 5548 <fwp_hof0.constprop.0+0x884>
    5530:	7100041f 	cmp	w0, #0x1
    5534:	54001760 	b.eq	5820 <fwp_hof0.constprop.0+0xb5c>  // b.none
    5538:	7103fc1f 	cmp	w0, #0xff
    553c:	54001e20 	b.eq	5900 <fwp_hof0.constprop.0+0xc3c>  // b.none
    5540:	51000400 	sub	w0, w0, #0x1
    5544:	39000260 	strb	w0, [x19]
    5548:	f94007e0 	ldr	x0, [sp, #8]
    554c:	f9400800 	ldr	x0, [x0, #16]
    5550:	f90007e0 	str	x0, [sp, #8]
    5554:	b5ffbe60 	cbnz	x0, 4d20 <fwp_hof0.constprop.0+0x5c>
    5558:	a94553f3 	ldp	x19, x20, [sp, #80]
    555c:	a94763f7 	ldp	x23, x24, [sp, #112]
    5560:	a9486bf9 	ldp	x25, x26, [sp, #128]
    5564:	a94973fb 	ldp	x27, x28, [sp, #144]
    5568:	6d4a27e8 	ldp	d8, d9, [sp, #160]
    556c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    5570:	f947f400 	ldr	x0, [x0, #4072]
    5574:	f9401fe2 	ldr	x2, [sp, #56]
    5578:	f9400001 	ldr	x1, [x0]
    557c:	eb010042 	subs	x2, x2, x1
    5580:	d2800001 	mov	x1, #0x0                   	// #0
    5584:	54002301 	b.ne	59e4 <fwp_hof0.constprop.0+0xd20>  // b.any
    5588:	a9447bfd 	ldp	x29, x30, [sp, #64]
    558c:	d2800000 	mov	x0, #0x0                   	// #0
    5590:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5594:	9102c3ff 	add	sp, sp, #0xb0
    5598:	d65f03c0 	ret
    559c:	f9400b06 	ldr	x6, [x24, #16]
    55a0:	17fffeb4 	b	5070 <fwp_hof0.constprop.0+0x3ac>
    55a4:	72003c3f 	tst	w1, #0xffff
    55a8:	54ffe181 	b.ne	51d8 <fwp_hof0.constprop.0+0x514>  // b.any
    55ac:	17ffff03 	b	51b8 <fwp_hof0.constprop.0+0x4f4>
    55b0:	f9400718 	ldr	x24, [x24, #8]
    55b4:	eb02007f 	cmp	x3, x2
    55b8:	54000369 	b.ls	5624 <fwp_hof0.constprop.0+0x960>  // b.plast
    55bc:	d350fc45 	lsr	x5, x2, #16
    55c0:	8b0508a5 	add	x5, x5, x5, lsl #2
    55c4:	d37df0a5 	lsl	x5, x5, #3
    55c8:	8b050087 	add	x7, x4, x5
    55cc:	f94010e6 	ldr	x6, [x7, #32]
    55d0:	b40002a6 	cbz	x6, 5624 <fwp_hof0.constprop.0+0x960>
    55d4:	38656884 	ldrb	w4, [x4, x5]
    55d8:	7100089f 	cmp	w4, #0x2
    55dc:	54000820 	b.eq	56e0 <fwp_hof0.constprop.0+0xa1c>  // b.none
    55e0:	7100049f 	cmp	w4, #0x1
    55e4:	54000201 	b.ne	5624 <fwp_hof0.constprop.0+0x960>  // b.any
    55e8:	294310e5 	ldp	w5, w4, [x7, #24]
    55ec:	92403c42 	and	x2, x2, #0xffff
    55f0:	9b057c42 	mul	x2, x2, x5
    55f4:	d360fc42 	lsr	x2, x2, #32
    55f8:	eb04005f 	cmp	x2, x4
    55fc:	54000142 	b.cs	5624 <fwp_hof0.constprop.0+0x960>  // b.hs, b.nlast
    5600:	8b0200c6 	add	x6, x6, x2
    5604:	394000c2 	ldrb	w2, [x6]
    5608:	7100045f 	cmp	w2, #0x1
    560c:	540000c1 	b.ne	5624 <fwp_hof0.constprop.0+0x960>  // b.any
    5610:	97fff604 	bl	2e20 <fwp_mem_free>
    5614:	91144280 	add	x0, x20, #0x510
    5618:	f949ec03 	ldr	x3, [x0, #5080]
    561c:	f949d801 	ldr	x1, [x0, #5040]
    5620:	d370bc63 	lsl	x3, x3, #16
    5624:	cb010301 	sub	x1, x24, x1
    5628:	eb03003f 	cmp	x1, x3
    562c:	54ffda03 	b.cc	516c <fwp_hof0.constprop.0+0x4a8>  // b.lo, b.ul, b.last
    5630:	17fffeea 	b	51d8 <fwp_hof0.constprop.0+0x514>
    5634:	72003c3f 	tst	w1, #0xffff
    5638:	54ffd021 	b.ne	503c <fwp_hof0.constprop.0+0x378>  // b.any
    563c:	39400360 	ldrb	w0, [x27]
    5640:	7103fc1f 	cmp	w0, #0xff
    5644:	54ffcf81 	b.ne	5034 <fwp_hof0.constprop.0+0x370>  // b.any
    5648:	aa1b03e0 	mov	x0, x27
    564c:	97fff556 	bl	2ba4 <fwp_rc_forget_slot>
    5650:	17fffe79 	b	5034 <fwp_hof0.constprop.0+0x370>
    5654:	72003c5f 	tst	w2, #0xffff
    5658:	54ffdc01 	b.ne	51d8 <fwp_hof0.constprop.0+0x514>  // b.any
    565c:	17ffff01 	b	5260 <fwp_hof0.constprop.0+0x59c>
    5660:	f9400260 	ldr	x0, [x19]
    5664:	b7f80520 	tbnz	x0, #63, 5708 <fwp_hof0.constprop.0+0xa44>
    5668:	91144281 	add	x1, x20, #0x510
    566c:	f949d820 	ldr	x0, [x1, #5040]
    5670:	f949ec21 	ldr	x1, [x1, #5080]
    5674:	cb000260 	sub	x0, x19, x0
    5678:	eb01401f 	cmp	x0, x1, lsl #16
    567c:	54fff122 	b.cs	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.hs, b.nlast
    5680:	d350fc01 	lsr	x1, x0, #16
    5684:	8b010821 	add	x1, x1, x1, lsl #2
    5688:	d37df021 	lsl	x1, x1, #3
    568c:	8b010064 	add	x4, x3, x1
    5690:	f9401082 	ldr	x2, [x4, #32]
    5694:	b4fff062 	cbz	x2, 54a0 <fwp_hof0.constprop.0+0x7dc>
    5698:	38616861 	ldrb	w1, [x3, x1]
    569c:	7100083f 	cmp	w1, #0x2
    56a0:	54000c60 	b.eq	582c <fwp_hof0.constprop.0+0xb68>  // b.none
    56a4:	7100043f 	cmp	w1, #0x1
    56a8:	54ffefc1 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    56ac:	29430483 	ldp	w3, w1, [x4, #24]
    56b0:	92403c00 	and	x0, x0, #0xffff
    56b4:	9b037c00 	mul	x0, x0, x3
    56b8:	d360fc00 	lsr	x0, x0, #32
    56bc:	eb01001f 	cmp	x0, x1
    56c0:	54ffef02 	b.cs	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.hs, b.nlast
    56c4:	8b000042 	add	x2, x2, x0
    56c8:	39400040 	ldrb	w0, [x2]
    56cc:	7100041f 	cmp	w0, #0x1
    56d0:	54ffee81 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    56d4:	aa1303e0 	mov	x0, x19
    56d8:	97fff5d2 	bl	2e20 <fwp_mem_free>
    56dc:	17ffff71 	b	54a0 <fwp_hof0.constprop.0+0x7dc>
    56e0:	72003c5f 	tst	w2, #0xffff
    56e4:	54fffa01 	b.ne	5624 <fwp_hof0.constprop.0+0x960>  // b.any
    56e8:	17ffffc7 	b	5604 <fwp_hof0.constprop.0+0x940>
    56ec:	72003c7f 	tst	w3, #0xffff
    56f0:	54ffc460 	b.eq	4f7c <fwp_hof0.constprop.0+0x2b8>  // b.none
    56f4:	aa1303e0 	mov	x0, x19
    56f8:	17fffe25 	b	4f8c <fwp_hof0.constprop.0+0x2c8>
    56fc:	72003c3f 	tst	w1, #0xffff
    5700:	54ffed01 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    5704:	17ffff5e 	b	547c <fwp_hof0.constprop.0+0x7b8>
    5708:	f9400678 	ldr	x24, [x19, #8]
    570c:	aa1303e0 	mov	x0, x19
    5710:	97fff714 	bl	3360 <fwp_rc_free_arr>
    5714:	91144280 	add	x0, x20, #0x510
    5718:	f949d801 	ldr	x1, [x0, #5040]
    571c:	f949ec00 	ldr	x0, [x0, #5080]
    5720:	cb010301 	sub	x1, x24, x1
    5724:	eb00403f 	cmp	x1, x0, lsl #16
    5728:	54ffebc2 	b.cs	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.hs, b.nlast
    572c:	aa1803f3 	mov	x19, x24
    5730:	17ffff40 	b	5430 <fwp_hof0.constprop.0+0x76c>
    5734:	72003c1f 	tst	w0, #0xffff
    5738:	54ffb260 	b.eq	4d84 <fwp_hof0.constprop.0+0xc0>  // b.none
    573c:	b5ffb335 	cbnz	x21, 4da0 <fwp_hof0.constprop.0+0xdc>
    5740:	d2800000 	mov	x0, #0x0                   	// #0
    5744:	97fff7b8 	bl	3624 <fwp_array_new_packed.constprop.0>
    5748:	91144281 	add	x1, x20, #0x510
    574c:	aa0003f8 	mov	x24, x0
    5750:	aa0103e0 	mov	x0, x1
    5754:	f949d821 	ldr	x1, [x1, #5040]
    5758:	f949ec00 	ldr	x0, [x0, #5080]
    575c:	cb010301 	sub	x1, x24, x1
    5760:	eb00403f 	cmp	x1, x0, lsl #16
    5764:	54ffb403 	b.cc	4de4 <fwp_hof0.constprop.0+0x120>  // b.lo, b.ul, b.last
    5768:	d2800000 	mov	x0, #0x0                   	// #0
    576c:	17fffe0b 	b	4f98 <fwp_hof0.constprop.0+0x2d4>
    5770:	72003c3f 	tst	w1, #0xffff
    5774:	54ffb6a1 	b.ne	4e48 <fwp_hof0.constprop.0+0x184>  // b.any
    5778:	39400260 	ldrb	w0, [x19]
    577c:	7103fc1f 	cmp	w0, #0xff
    5780:	54ffb601 	b.ne	4e40 <fwp_hof0.constprop.0+0x17c>  // b.any
    5784:	aa1303e0 	mov	x0, x19
    5788:	97fff507 	bl	2ba4 <fwp_rc_forget_slot>
    578c:	17fffdad 	b	4e40 <fwp_hof0.constprop.0+0x17c>
    5790:	ca5b4760 	eor	x0, x27, x27, lsr #17
    5794:	91144281 	add	x1, x20, #0x510
    5798:	ca402400 	eor	x0, x0, x0, lsr #9
    579c:	8b200c20 	add	x0, x1, w0, uxtb #3
    57a0:	f94a2400 	ldr	x0, [x0, #5192]
    57a4:	b5000080 	cbnz	x0, 57b4 <fwp_hof0.constprop.0+0xaf0>
    57a8:	14000071 	b	596c <fwp_hof0.constprop.0+0xca8>
    57ac:	f9400800 	ldr	x0, [x0, #16]
    57b0:	b4000de0 	cbz	x0, 596c <fwp_hof0.constprop.0+0xca8>
    57b4:	f9400001 	ldr	x1, [x0]
    57b8:	eb01037f 	cmp	x27, x1
    57bc:	54ffff81 	b.ne	57ac <fwp_hof0.constprop.0+0xae8>  // b.any
    57c0:	f9400401 	ldr	x1, [x0, #8]
    57c4:	d1000421 	sub	x1, x1, #0x1
    57c8:	f9000401 	str	x1, [x0, #8]
    57cc:	f103f83f 	cmp	x1, #0xfe
    57d0:	54ffd041 	b.ne	51d8 <fwp_hof0.constprop.0+0x514>  // b.any
    57d4:	aa1b03e0 	mov	x0, x27
    57d8:	97fff4f3 	bl	2ba4 <fwp_rc_forget_slot>
    57dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    57e0:	39000360 	strb	w0, [x27]
    57e4:	17fffe7d 	b	51d8 <fwp_hof0.constprop.0+0x514>
    57e8:	72003c9f 	tst	w4, #0xffff
    57ec:	54ffe1a1 	b.ne	5420 <fwp_hof0.constprop.0+0x75c>  // b.any
    57f0:	39400300 	ldrb	w0, [x24]
    57f4:	7103fc1f 	cmp	w0, #0xff
    57f8:	54ffe081 	b.ne	5408 <fwp_hof0.constprop.0+0x744>  // b.any
    57fc:	aa1803e0 	mov	x0, x24
    5800:	97fff4e9 	bl	2ba4 <fwp_rc_forget_slot>
    5804:	17ffff01 	b	5408 <fwp_hof0.constprop.0+0x744>
    5808:	72003c3f 	tst	w1, #0xffff
    580c:	54ffe9e1 	b.ne	5548 <fwp_hof0.constprop.0+0x884>  // b.any
    5810:	39400260 	ldrb	w0, [x19]
    5814:	34ffe9a0 	cbz	w0, 5548 <fwp_hof0.constprop.0+0x884>
    5818:	7100041f 	cmp	w0, #0x1
    581c:	54ffe8e1 	b.ne	5538 <fwp_hof0.constprop.0+0x874>  // b.any
    5820:	aa1603e0 	mov	x0, x22
    5824:	97fff57f 	bl	2e20 <fwp_mem_free>
    5828:	17ffff48 	b	5548 <fwp_hof0.constprop.0+0x884>
    582c:	72003c1f 	tst	w0, #0xffff
    5830:	54ffe381 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    5834:	17ffffa5 	b	56c8 <fwp_hof0.constprop.0+0xa04>
    5838:	ca584700 	eor	x0, x24, x24, lsr #17
    583c:	91144281 	add	x1, x20, #0x510
    5840:	ca402400 	eor	x0, x0, x0, lsr #9
    5844:	8b200c20 	add	x0, x1, w0, uxtb #3
    5848:	f94a2400 	ldr	x0, [x0, #5192]
    584c:	b4000900 	cbz	x0, 596c <fwp_hof0.constprop.0+0xca8>
    5850:	f9400001 	ldr	x1, [x0]
    5854:	eb01031f 	cmp	x24, x1
    5858:	540000c0 	b.eq	5870 <fwp_hof0.constprop.0+0xbac>  // b.none
    585c:	f9400800 	ldr	x0, [x0, #16]
    5860:	b4000860 	cbz	x0, 596c <fwp_hof0.constprop.0+0xca8>
    5864:	f9400001 	ldr	x1, [x0]
    5868:	eb01031f 	cmp	x24, x1
    586c:	54ffff81 	b.ne	585c <fwp_hof0.constprop.0+0xb98>  // b.any
    5870:	f9400401 	ldr	x1, [x0, #8]
    5874:	d1000421 	sub	x1, x1, #0x1
    5878:	f9000401 	str	x1, [x0, #8]
    587c:	f103f83f 	cmp	x1, #0xfe
    5880:	54ffe101 	b.ne	54a0 <fwp_hof0.constprop.0+0x7dc>  // b.any
    5884:	aa1803e0 	mov	x0, x24
    5888:	97fff4c7 	bl	2ba4 <fwp_rc_forget_slot>
    588c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5890:	39000300 	strb	w0, [x24]
    5894:	17ffff03 	b	54a0 <fwp_hof0.constprop.0+0x7dc>
    5898:	ca534661 	eor	x1, x19, x19, lsr #17
    589c:	91144282 	add	x2, x20, #0x510
    58a0:	ca412421 	eor	x1, x1, x1, lsr #9
    58a4:	92401c21 	and	x1, x1, #0xff
    58a8:	910a2423 	add	x3, x1, #0x289
    58ac:	8b010c41 	add	x1, x2, x1, lsl #3
    58b0:	8b030c56 	add	x22, x2, x3, lsl #3
    58b4:	f94a2421 	ldr	x1, [x1, #5192]
    58b8:	b50000a1 	cbnz	x1, 58cc <fwp_hof0.constprop.0+0xc08>
    58bc:	14000047 	b	59d8 <fwp_hof0.constprop.0+0xd14>
    58c0:	91004036 	add	x22, x1, #0x10
    58c4:	f9400821 	ldr	x1, [x1, #16]
    58c8:	b40004e1 	cbz	x1, 5964 <fwp_hof0.constprop.0+0xca0>
    58cc:	f9400022 	ldr	x2, [x1]
    58d0:	eb13005f 	cmp	x2, x19
    58d4:	54ffff61 	b.ne	58c0 <fwp_hof0.constprop.0+0xbfc>  // b.any
    58d8:	f94002c1 	ldr	x1, [x22]
    58dc:	7103f81f 	cmp	w0, #0xfe
    58e0:	54000680 	b.eq	59b0 <fwp_hof0.constprop.0+0xcec>  // b.none
    58e4:	b4000441 	cbz	x1, 596c <fwp_hof0.constprop.0+0xca8>
    58e8:	f9400420 	ldr	x0, [x1, #8]
    58ec:	b100041f 	cmn	x0, #0x1
    58f0:	540006e0 	b.eq	59cc <fwp_hof0.constprop.0+0xd08>  // b.none
    58f4:	91000400 	add	x0, x0, #0x1
    58f8:	f9000420 	str	x0, [x1, #8]
    58fc:	17fffd28 	b	4d9c <fwp_hof0.constprop.0+0xd8>
    5900:	ca534660 	eor	x0, x19, x19, lsr #17
    5904:	91144281 	add	x1, x20, #0x510
    5908:	ca402400 	eor	x0, x0, x0, lsr #9
    590c:	8b200c20 	add	x0, x1, w0, uxtb #3
    5910:	f94a2400 	ldr	x0, [x0, #5192]
    5914:	b5000080 	cbnz	x0, 5924 <fwp_hof0.constprop.0+0xc60>
    5918:	14000015 	b	596c <fwp_hof0.constprop.0+0xca8>
    591c:	f9400800 	ldr	x0, [x0, #16]
    5920:	b4000260 	cbz	x0, 596c <fwp_hof0.constprop.0+0xca8>
    5924:	f9400001 	ldr	x1, [x0]
    5928:	eb13003f 	cmp	x1, x19
    592c:	54ffff81 	b.ne	591c <fwp_hof0.constprop.0+0xc58>  // b.any
    5930:	f9400401 	ldr	x1, [x0, #8]
    5934:	d1000421 	sub	x1, x1, #0x1
    5938:	f9000401 	str	x1, [x0, #8]
    593c:	f103f83f 	cmp	x1, #0xfe
    5940:	54ffe041 	b.ne	5548 <fwp_hof0.constprop.0+0x884>  // b.any
    5944:	aa1303e0 	mov	x0, x19
    5948:	97fff497 	bl	2ba4 <fwp_rc_forget_slot>
    594c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5950:	39000260 	strb	w0, [x19]
    5954:	17fffefd 	b	5548 <fwp_hof0.constprop.0+0x884>
    5958:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x170>
    595c:	9138e000 	add	x0, x0, #0xe38
    5960:	97fff1d0 	bl	20a0 <fwp_trap>
    5964:	7103f81f 	cmp	w0, #0xfe
    5968:	54000080 	b.eq	5978 <fwp_hof0.constprop.0+0xcb4>  // b.none
    596c:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x170>
    5970:	9132e000 	add	x0, x0, #0xcb8
    5974:	97fff1cb 	bl	20a0 <fwp_trap>
    5978:	d2800300 	mov	x0, #0x18                  	// #24
    597c:	97ffeeb1 	bl	1440 <malloc@plt>
    5980:	b4000300 	cbz	x0, 59e0 <fwp_hof0.constprop.0+0xd1c>
    5984:	d2801fe1 	mov	x1, #0xff                  	// #255
    5988:	a9000413 	stp	x19, x1, [x0]
    598c:	91144281 	add	x1, x20, #0x510
    5990:	f900081f 	str	xzr, [x0, #16]
    5994:	12800002 	mov	w2, #0xffffffff            	// #-1
    5998:	f90002c0 	str	x0, [x22]
    599c:	39000262 	strb	w2, [x19]
    59a0:	f94e2420 	ldr	x0, [x1, #7240]
    59a4:	91000400 	add	x0, x0, #0x1
    59a8:	f90e2420 	str	x0, [x1, #7240]
    59ac:	17fffcfc 	b	4d9c <fwp_hof0.constprop.0+0xd8>
    59b0:	b4fffe41 	cbz	x1, 5978 <fwp_hof0.constprop.0+0xcb4>
    59b4:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x170>
    59b8:	9137c000 	add	x0, x0, #0xdf0
    59bc:	97fff1b9 	bl	20a0 <fwp_trap>
    59c0:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x170>
    59c4:	91338000 	add	x0, x0, #0xce0
    59c8:	97fff1b6 	bl	20a0 <fwp_trap>
    59cc:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x170>
    59d0:	91386000 	add	x0, x0, #0xe18
    59d4:	97fff1b3 	bl	20a0 <fwp_trap>
    59d8:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    59dc:	17ffffc0 	b	58dc <fwp_hof0.constprop.0+0xc18>
    59e0:	97fff06c 	bl	1b90 <fwp_heap_oom>
    59e4:	a90553f3 	stp	x19, x20, [sp, #80]
    59e8:	a90763f7 	stp	x23, x24, [sp, #112]
    59ec:	a9086bf9 	stp	x25, x26, [sp, #128]
    59f0:	a90973fb 	stp	x27, x28, [sp, #144]
    59f4:	6d0a27e8 	stp	d8, d9, [sp, #160]
    59f8:	97ffeeaa 	bl	14a0 <__stack_chk_fail@plt>
    59fc:	f0000000 	adrp	x0, 8000 <fwp_main_thread+0x170>
    5a00:	91398000 	add	x0, x0, #0xe60
    5a04:	97fff1a7 	bl	20a0 <fwp_trap>
    5a08:	97ffef1e 	bl	1680 <fwp_trap_overflow.constprop.0>
    5a0c:	d503201f 	nop

0000000000005a10 <f0>:
    5a10:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    5a14:	910003fd 	mov	x29, sp
    5a18:	a90153f3 	stp	x19, x20, [sp, #16]
    5a1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5a20:	a90363f7 	stp	x23, x24, [sp, #48]
    5a24:	a9046bf9 	stp	x25, x26, [sp, #64]
    5a28:	a90573fb 	stp	x27, x28, [sp, #80]
    5a2c:	d12183ff 	sub	sp, sp, #0x860
    5a30:	f90203ff 	str	xzr, [sp, #1024]
    5a34:	f00000c0 	adrp	x0, 20000 <__data_start>
    5a38:	9101c005 	add	x5, x0, #0x70
    5a3c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    5a40:	f947f400 	ldr	x0, [x0, #4072]
    5a44:	90000174 	adrp	x20, 31000 <fwp_root_context+0xcd0>
    5a48:	f94130a6 	ldr	x6, [x5, #608]
    5a4c:	f9400001 	ldr	x1, [x0]
    5a50:	f9042fe1 	str	x1, [sp, #2136]
    5a54:	d2800001 	mov	x1, #0x0                   	// #0
    5a58:	91144298 	add	x24, x20, #0x510
    5a5c:	912123f6 	add	x22, sp, #0x848
    5a60:	910023e0 	add	x0, sp, #0x8
    5a64:	910083e2 	add	x2, sp, #0x20
    5a68:	d0ffffe1 	adrp	x1, 3000 <fwp_mem_free+0x1e0>
    5a6c:	90ffffe4 	adrp	x4, 1000 <__abi_tag+0xd88>
    5a70:	911f0021 	add	x1, x1, #0x7c0
    5a74:	912c4084 	add	x4, x4, #0xb10
    5a78:	d2800013 	mov	x19, #0x0                   	// #0
    5a7c:	d2800119 	mov	x25, #0x8                   	// #8
    5a80:	d2800015 	mov	x21, #0x0                   	// #0
    5a84:	52800037 	mov	w23, #0x1                   	// #1
    5a88:	a90093e6 	stp	x6, x4, [sp, #8]
    5a8c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    5a90:	a90307ff 	stp	xzr, x1, [sp, #48]
    5a94:	f90130a0 	str	x0, [x5, #608]
    5a98:	f100073a 	subs	x26, x25, #0x1
    5a9c:	aa1603e0 	mov	x0, x22
    5aa0:	da1f02bc 	sbc	x28, x21, xzr
    5aa4:	f90017fa 	str	x26, [sp, #40]
    5aa8:	f90427fa 	str	x26, [sp, #2120]
    5aac:	aa1a03f9 	mov	x25, x26
    5ab0:	f9042bf3 	str	x19, [sp, #2128]
    5ab4:	97fff693 	bl	3500 <fwp_data.part.0.constprop.0>
    5ab8:	f949db02 	ldr	x2, [x24, #5040]
    5abc:	aa0003f3 	mov	x19, x0
    5ac0:	f949ef00 	ldr	x0, [x24, #5080]
    5ac4:	cb020262 	sub	x2, x19, x2
    5ac8:	aa1c03f5 	mov	x21, x28
    5acc:	eb00405f 	cmp	x2, x0, lsl #16
    5ad0:	54000302 	b.cs	5b30 <f0+0x120>  // b.hs, b.nlast
    5ad4:	d350fc40 	lsr	x0, x2, #16
    5ad8:	f949ff04 	ldr	x4, [x24, #5112]
    5adc:	8b000800 	add	x0, x0, x0, lsl #2
    5ae0:	d37df001 	lsl	x1, x0, #3
    5ae4:	8b010080 	add	x0, x4, x1
    5ae8:	f940101b 	ldr	x27, [x0, #32]
    5aec:	b400023b 	cbz	x27, 5b30 <f0+0x120>
    5af0:	38616881 	ldrb	w1, [x4, x1]
    5af4:	7100083f 	cmp	w1, #0x2
    5af8:	5400fec0 	b.eq	7ad0 <f0+0x20c0>  // b.none
    5afc:	7100043f 	cmp	w1, #0x1
    5b00:	54000181 	b.ne	5b30 <f0+0x120>  // b.any
    5b04:	29430001 	ldp	w1, w0, [x0, #24]
    5b08:	92403c42 	and	x2, x2, #0xffff
    5b0c:	9b017c42 	mul	x2, x2, x1
    5b10:	d360fc42 	lsr	x2, x2, #32
    5b14:	eb00005f 	cmp	x2, x0
    5b18:	540000c2 	b.cs	5b30 <f0+0x120>  // b.hs, b.nlast
    5b1c:	8b02037b 	add	x27, x27, x2
    5b20:	39400360 	ldrb	w0, [x27]
    5b24:	7103fc1f 	cmp	w0, #0xff
    5b28:	5400fce0 	b.eq	7ac4 <f0+0x20b4>  // b.none
    5b2c:	39000377 	strb	w23, [x27]
    5b30:	f90013f3 	str	x19, [sp, #32]
    5b34:	aa1c035a 	orr	x26, x26, x28
    5b38:	b5fffb1a 	cbnz	x26, 5a98 <f0+0x88>
    5b3c:	90000022 	adrp	x2, 9000 <msg.3+0x20>
    5b40:	f00000c0 	adrp	x0, 20000 <__data_start>
    5b44:	f94007e1 	ldr	x1, [sp, #8]
    5b48:	9101c018 	add	x24, x0, #0x70
    5b4c:	3dc00840 	ldr	q0, [x2, #32]
    5b50:	910103e0 	add	x0, sp, #0x40
    5b54:	f9013301 	str	x1, [x24, #608]
    5b58:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    5b5c:	3d8013e0 	str	q0, [sp, #64]
    5b60:	97fff668 	bl	3500 <fwp_data.part.0.constprop.0>
    5b64:	97fff5cf 	bl	32a0 <fwp_rc_fresh>
    5b68:	aa0003e1 	mov	x1, x0
    5b6c:	910163e0 	add	x0, sp, #0x58
    5b70:	a90587f5 	stp	x21, x1, [sp, #88]
    5b74:	97fff663 	bl	3500 <fwp_data.part.0.constprop.0>
    5b78:	97fff5ca 	bl	32a0 <fwp_rc_fresh>
    5b7c:	aa0003e1 	mov	x1, x0
    5b80:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5b84:	9101a3e0 	add	x0, sp, #0x68
    5b88:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5b8c:	a90687e2 	stp	x2, x1, [sp, #104]
    5b90:	97fff65c 	bl	3500 <fwp_data.part.0.constprop.0>
    5b94:	97fff5c3 	bl	32a0 <fwp_rc_fresh>
    5b98:	aa0003e1 	mov	x1, x0
    5b9c:	9101e3e0 	add	x0, sp, #0x78
    5ba0:	a90787f5 	stp	x21, x1, [sp, #120]
    5ba4:	97fff657 	bl	3500 <fwp_data.part.0.constprop.0>
    5ba8:	97fff5be 	bl	32a0 <fwp_rc_fresh>
    5bac:	aa0003e1 	mov	x1, x0
    5bb0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5bb4:	910223e0 	add	x0, sp, #0x88
    5bb8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5bbc:	a90887e2 	stp	x2, x1, [sp, #136]
    5bc0:	97fff650 	bl	3500 <fwp_data.part.0.constprop.0>
    5bc4:	97fff5b7 	bl	32a0 <fwp_rc_fresh>
    5bc8:	aa0003e1 	mov	x1, x0
    5bcc:	910263e0 	add	x0, sp, #0x98
    5bd0:	a90987f5 	stp	x21, x1, [sp, #152]
    5bd4:	97fff64b 	bl	3500 <fwp_data.part.0.constprop.0>
    5bd8:	97fff5b2 	bl	32a0 <fwp_rc_fresh>
    5bdc:	aa0003e1 	mov	x1, x0
    5be0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5be4:	9102a3e0 	add	x0, sp, #0xa8
    5be8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5bec:	a90a87e2 	stp	x2, x1, [sp, #168]
    5bf0:	97fff644 	bl	3500 <fwp_data.part.0.constprop.0>
    5bf4:	97fff5ab 	bl	32a0 <fwp_rc_fresh>
    5bf8:	aa0003e1 	mov	x1, x0
    5bfc:	9102e3e0 	add	x0, sp, #0xb8
    5c00:	a90b87f5 	stp	x21, x1, [sp, #184]
    5c04:	97fff63f 	bl	3500 <fwp_data.part.0.constprop.0>
    5c08:	97fff5a6 	bl	32a0 <fwp_rc_fresh>
    5c0c:	aa0003e1 	mov	x1, x0
    5c10:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5c14:	910323e0 	add	x0, sp, #0xc8
    5c18:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5c1c:	a90c87e2 	stp	x2, x1, [sp, #200]
    5c20:	97fff638 	bl	3500 <fwp_data.part.0.constprop.0>
    5c24:	97fff59f 	bl	32a0 <fwp_rc_fresh>
    5c28:	aa0003e1 	mov	x1, x0
    5c2c:	910363e0 	add	x0, sp, #0xd8
    5c30:	a90d87f5 	stp	x21, x1, [sp, #216]
    5c34:	97fff633 	bl	3500 <fwp_data.part.0.constprop.0>
    5c38:	97fff59a 	bl	32a0 <fwp_rc_fresh>
    5c3c:	aa0003e1 	mov	x1, x0
    5c40:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5c44:	9103a3e0 	add	x0, sp, #0xe8
    5c48:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5c4c:	a90e87e2 	stp	x2, x1, [sp, #232]
    5c50:	97fff62c 	bl	3500 <fwp_data.part.0.constprop.0>
    5c54:	97fff593 	bl	32a0 <fwp_rc_fresh>
    5c58:	aa0003e1 	mov	x1, x0
    5c5c:	9103e3e0 	add	x0, sp, #0xf8
    5c60:	a90f87f5 	stp	x21, x1, [sp, #248]
    5c64:	97fff627 	bl	3500 <fwp_data.part.0.constprop.0>
    5c68:	97fff58e 	bl	32a0 <fwp_rc_fresh>
    5c6c:	aa0003e1 	mov	x1, x0
    5c70:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5c74:	910423e0 	add	x0, sp, #0x108
    5c78:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5c7c:	a91087e2 	stp	x2, x1, [sp, #264]
    5c80:	97fff620 	bl	3500 <fwp_data.part.0.constprop.0>
    5c84:	97fff587 	bl	32a0 <fwp_rc_fresh>
    5c88:	aa0003e1 	mov	x1, x0
    5c8c:	910463e0 	add	x0, sp, #0x118
    5c90:	a91187f5 	stp	x21, x1, [sp, #280]
    5c94:	97fff61b 	bl	3500 <fwp_data.part.0.constprop.0>
    5c98:	97fff582 	bl	32a0 <fwp_rc_fresh>
    5c9c:	aa0003e1 	mov	x1, x0
    5ca0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5ca4:	9104a3e0 	add	x0, sp, #0x128
    5ca8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5cac:	a91287e2 	stp	x2, x1, [sp, #296]
    5cb0:	97fff614 	bl	3500 <fwp_data.part.0.constprop.0>
    5cb4:	97fff57b 	bl	32a0 <fwp_rc_fresh>
    5cb8:	aa0003e1 	mov	x1, x0
    5cbc:	9104e3e0 	add	x0, sp, #0x138
    5cc0:	a91387f5 	stp	x21, x1, [sp, #312]
    5cc4:	97fff60f 	bl	3500 <fwp_data.part.0.constprop.0>
    5cc8:	97fff576 	bl	32a0 <fwp_rc_fresh>
    5ccc:	aa0003e1 	mov	x1, x0
    5cd0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5cd4:	910523e0 	add	x0, sp, #0x148
    5cd8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5cdc:	a91487e2 	stp	x2, x1, [sp, #328]
    5ce0:	97fff608 	bl	3500 <fwp_data.part.0.constprop.0>
    5ce4:	aa0003f5 	mov	x21, x0
    5ce8:	91144283 	add	x3, x20, #0x510
    5cec:	f949d861 	ldr	x1, [x3, #5040]
    5cf0:	f949ec60 	ldr	x0, [x3, #5080]
    5cf4:	cb0102a1 	sub	x1, x21, x1
    5cf8:	eb00403f 	cmp	x1, x0, lsl #16
    5cfc:	54000322 	b.cs	5d60 <f0+0x350>  // b.hs, b.nlast
    5d00:	d350fc22 	lsr	x2, x1, #16
    5d04:	f949fc63 	ldr	x3, [x3, #5112]
    5d08:	8b020842 	add	x2, x2, x2, lsl #2
    5d0c:	d37df042 	lsl	x2, x2, #3
    5d10:	8b020060 	add	x0, x3, x2
    5d14:	f9401017 	ldr	x23, [x0, #32]
    5d18:	b4000257 	cbz	x23, 5d60 <f0+0x350>
    5d1c:	38626862 	ldrb	w2, [x3, x2]
    5d20:	7100085f 	cmp	w2, #0x2
    5d24:	5400f180 	b.eq	7b54 <f0+0x2144>  // b.none
    5d28:	7100045f 	cmp	w2, #0x1
    5d2c:	540001a1 	b.ne	5d60 <f0+0x350>  // b.any
    5d30:	29430002 	ldp	w2, w0, [x0, #24]
    5d34:	92403c21 	and	x1, x1, #0xffff
    5d38:	9b027c21 	mul	x1, x1, x2
    5d3c:	d360fc21 	lsr	x1, x1, #32
    5d40:	eb00003f 	cmp	x1, x0
    5d44:	540000e2 	b.cs	5d60 <f0+0x350>  // b.hs, b.nlast
    5d48:	8b0102f7 	add	x23, x23, x1
    5d4c:	394002e0 	ldrb	w0, [x23]
    5d50:	7103fc1f 	cmp	w0, #0xff
    5d54:	5400fb40 	b.eq	7cbc <f0+0x22ac>  // b.none
    5d58:	52800020 	mov	w0, #0x1                   	// #1
    5d5c:	390002e0 	strb	w0, [x23]
    5d60:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    5d64:	910563e0 	add	x0, sp, #0x158
    5d68:	a915d7e1 	stp	x1, x21, [sp, #344]
    5d6c:	97fff5e5 	bl	3500 <fwp_data.part.0.constprop.0>
    5d70:	97fff54c 	bl	32a0 <fwp_rc_fresh>
    5d74:	aa0003e1 	mov	x1, x0
    5d78:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5d7c:	9105a3e0 	add	x0, sp, #0x168
    5d80:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5d84:	a91687e2 	stp	x2, x1, [sp, #360]
    5d88:	97fff5de 	bl	3500 <fwp_data.part.0.constprop.0>
    5d8c:	aa0003f5 	mov	x21, x0
    5d90:	91144283 	add	x3, x20, #0x510
    5d94:	f949d861 	ldr	x1, [x3, #5040]
    5d98:	f949ec60 	ldr	x0, [x3, #5080]
    5d9c:	cb0102a1 	sub	x1, x21, x1
    5da0:	eb00403f 	cmp	x1, x0, lsl #16
    5da4:	54000322 	b.cs	5e08 <f0+0x3f8>  // b.hs, b.nlast
    5da8:	d350fc22 	lsr	x2, x1, #16
    5dac:	f949fc63 	ldr	x3, [x3, #5112]
    5db0:	8b020842 	add	x2, x2, x2, lsl #2
    5db4:	d37df042 	lsl	x2, x2, #3
    5db8:	8b020060 	add	x0, x3, x2
    5dbc:	f9401017 	ldr	x23, [x0, #32]
    5dc0:	b4000257 	cbz	x23, 5e08 <f0+0x3f8>
    5dc4:	38626862 	ldrb	w2, [x3, x2]
    5dc8:	7100085f 	cmp	w2, #0x2
    5dcc:	5400ebe0 	b.eq	7b48 <f0+0x2138>  // b.none
    5dd0:	7100045f 	cmp	w2, #0x1
    5dd4:	540001a1 	b.ne	5e08 <f0+0x3f8>  // b.any
    5dd8:	29430002 	ldp	w2, w0, [x0, #24]
    5ddc:	92403c21 	and	x1, x1, #0xffff
    5de0:	9b027c21 	mul	x1, x1, x2
    5de4:	d360fc21 	lsr	x1, x1, #32
    5de8:	eb00003f 	cmp	x1, x0
    5dec:	540000e2 	b.cs	5e08 <f0+0x3f8>  // b.hs, b.nlast
    5df0:	8b0102f7 	add	x23, x23, x1
    5df4:	394002e0 	ldrb	w0, [x23]
    5df8:	7103fc1f 	cmp	w0, #0xff
    5dfc:	5400f660 	b.eq	7cc8 <f0+0x22b8>  // b.none
    5e00:	52800020 	mov	w0, #0x1                   	// #1
    5e04:	390002e0 	strb	w0, [x23]
    5e08:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    5e0c:	9105e3e0 	add	x0, sp, #0x178
    5e10:	a917d7e1 	stp	x1, x21, [sp, #376]
    5e14:	97fff5bb 	bl	3500 <fwp_data.part.0.constprop.0>
    5e18:	97fff522 	bl	32a0 <fwp_rc_fresh>
    5e1c:	aa0003e1 	mov	x1, x0
    5e20:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    5e24:	910623e0 	add	x0, sp, #0x188
    5e28:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    5e2c:	a91887e2 	stp	x2, x1, [sp, #392]
    5e30:	97fff5b4 	bl	3500 <fwp_data.part.0.constprop.0>
    5e34:	aa0003f5 	mov	x21, x0
    5e38:	91144283 	add	x3, x20, #0x510
    5e3c:	f949d861 	ldr	x1, [x3, #5040]
    5e40:	f949ec60 	ldr	x0, [x3, #5080]
    5e44:	cb0102a1 	sub	x1, x21, x1
    5e48:	eb00403f 	cmp	x1, x0, lsl #16
    5e4c:	54000322 	b.cs	5eb0 <f0+0x4a0>  // b.hs, b.nlast
    5e50:	d350fc22 	lsr	x2, x1, #16
    5e54:	f949fc63 	ldr	x3, [x3, #5112]
    5e58:	8b020842 	add	x2, x2, x2, lsl #2
    5e5c:	d37df042 	lsl	x2, x2, #3
    5e60:	8b020060 	add	x0, x3, x2
    5e64:	f9401017 	ldr	x23, [x0, #32]
    5e68:	b4000257 	cbz	x23, 5eb0 <f0+0x4a0>
    5e6c:	38626862 	ldrb	w2, [x3, x2]
    5e70:	7100085f 	cmp	w2, #0x2
    5e74:	5400e640 	b.eq	7b3c <f0+0x212c>  // b.none
    5e78:	7100045f 	cmp	w2, #0x1
    5e7c:	540001a1 	b.ne	5eb0 <f0+0x4a0>  // b.any
    5e80:	29430002 	ldp	w2, w0, [x0, #24]
    5e84:	92403c21 	and	x1, x1, #0xffff
    5e88:	9b027c21 	mul	x1, x1, x2
    5e8c:	d360fc21 	lsr	x1, x1, #32
    5e90:	eb00003f 	cmp	x1, x0
    5e94:	540000e2 	b.cs	5eb0 <f0+0x4a0>  // b.hs, b.nlast
    5e98:	8b0102f7 	add	x23, x23, x1
    5e9c:	394002e0 	ldrb	w0, [x23]
    5ea0:	7103fc1f 	cmp	w0, #0xff
    5ea4:	5400f180 	b.eq	7cd4 <f0+0x22c4>  // b.none
    5ea8:	52800020 	mov	w0, #0x1                   	// #1
    5eac:	390002e0 	strb	w0, [x23]
    5eb0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    5eb4:	910663e0 	add	x0, sp, #0x198
    5eb8:	a919d7f7 	stp	x23, x21, [sp, #408]
    5ebc:	97fff591 	bl	3500 <fwp_data.part.0.constprop.0>
    5ec0:	97fff4f8 	bl	32a0 <fwp_rc_fresh>
    5ec4:	aa0003e1 	mov	x1, x0
    5ec8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    5ecc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    5ed0:	9106a3e0 	add	x0, sp, #0x1a8
    5ed4:	a91a87f5 	stp	x21, x1, [sp, #424]
    5ed8:	97fff58a 	bl	3500 <fwp_data.part.0.constprop.0>
    5edc:	97fff4f1 	bl	32a0 <fwp_rc_fresh>
    5ee0:	aa0003e1 	mov	x1, x0
    5ee4:	9106e3e0 	add	x0, sp, #0x1b8
    5ee8:	a91b87f7 	stp	x23, x1, [sp, #440]
    5eec:	97fff585 	bl	3500 <fwp_data.part.0.constprop.0>
    5ef0:	97fff4ec 	bl	32a0 <fwp_rc_fresh>
    5ef4:	aa0003e1 	mov	x1, x0
    5ef8:	910723e0 	add	x0, sp, #0x1c8
    5efc:	a91c87f5 	stp	x21, x1, [sp, #456]
    5f00:	97fff580 	bl	3500 <fwp_data.part.0.constprop.0>
    5f04:	aa0003f5 	mov	x21, x0
    5f08:	91144283 	add	x3, x20, #0x510
    5f0c:	f949d861 	ldr	x1, [x3, #5040]
    5f10:	f949ec60 	ldr	x0, [x3, #5080]
    5f14:	cb0102a1 	sub	x1, x21, x1
    5f18:	eb00403f 	cmp	x1, x0, lsl #16
    5f1c:	54000322 	b.cs	5f80 <f0+0x570>  // b.hs, b.nlast
    5f20:	d350fc22 	lsr	x2, x1, #16
    5f24:	f949fc63 	ldr	x3, [x3, #5112]
    5f28:	8b020842 	add	x2, x2, x2, lsl #2
    5f2c:	d37df042 	lsl	x2, x2, #3
    5f30:	8b020060 	add	x0, x3, x2
    5f34:	f9401017 	ldr	x23, [x0, #32]
    5f38:	b4000257 	cbz	x23, 5f80 <f0+0x570>
    5f3c:	38626862 	ldrb	w2, [x3, x2]
    5f40:	7100085f 	cmp	w2, #0x2
    5f44:	5400e200 	b.eq	7b84 <f0+0x2174>  // b.none
    5f48:	7100045f 	cmp	w2, #0x1
    5f4c:	540001a1 	b.ne	5f80 <f0+0x570>  // b.any
    5f50:	29430002 	ldp	w2, w0, [x0, #24]
    5f54:	92403c21 	and	x1, x1, #0xffff
    5f58:	9b027c21 	mul	x1, x1, x2
    5f5c:	d360fc21 	lsr	x1, x1, #32
    5f60:	eb00003f 	cmp	x1, x0
    5f64:	540000e2 	b.cs	5f80 <f0+0x570>  // b.hs, b.nlast
    5f68:	8b0102f7 	add	x23, x23, x1
    5f6c:	394002e0 	ldrb	w0, [x23]
    5f70:	7103fc1f 	cmp	w0, #0xff
    5f74:	5400eb60 	b.eq	7ce0 <f0+0x22d0>  // b.none
    5f78:	52800020 	mov	w0, #0x1                   	// #1
    5f7c:	390002e0 	strb	w0, [x23]
    5f80:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    5f84:	910763e0 	add	x0, sp, #0x1d8
    5f88:	a91dd7e1 	stp	x1, x21, [sp, #472]
    5f8c:	97fff55d 	bl	3500 <fwp_data.part.0.constprop.0>
    5f90:	91144283 	add	x3, x20, #0x510
    5f94:	aa0003f5 	mov	x21, x0
    5f98:	f949d861 	ldr	x1, [x3, #5040]
    5f9c:	f949ec60 	ldr	x0, [x3, #5080]
    5fa0:	cb0102a1 	sub	x1, x21, x1
    5fa4:	eb00403f 	cmp	x1, x0, lsl #16
    5fa8:	54000322 	b.cs	600c <f0+0x5fc>  // b.hs, b.nlast
    5fac:	d350fc22 	lsr	x2, x1, #16
    5fb0:	f949fc63 	ldr	x3, [x3, #5112]
    5fb4:	8b020842 	add	x2, x2, x2, lsl #2
    5fb8:	d37df042 	lsl	x2, x2, #3
    5fbc:	8b020060 	add	x0, x3, x2
    5fc0:	f9401017 	ldr	x23, [x0, #32]
    5fc4:	b4000257 	cbz	x23, 600c <f0+0x5fc>
    5fc8:	38626862 	ldrb	w2, [x3, x2]
    5fcc:	7100085f 	cmp	w2, #0x2
    5fd0:	5400dd40 	b.eq	7b78 <f0+0x2168>  // b.none
    5fd4:	7100045f 	cmp	w2, #0x1
    5fd8:	540001a1 	b.ne	600c <f0+0x5fc>  // b.any
    5fdc:	29430002 	ldp	w2, w0, [x0, #24]
    5fe0:	92403c21 	and	x1, x1, #0xffff
    5fe4:	9b027c21 	mul	x1, x1, x2
    5fe8:	d360fc21 	lsr	x1, x1, #32
    5fec:	eb00003f 	cmp	x1, x0
    5ff0:	540000e2 	b.cs	600c <f0+0x5fc>  // b.hs, b.nlast
    5ff4:	8b0102f7 	add	x23, x23, x1
    5ff8:	394002e0 	ldrb	w0, [x23]
    5ffc:	7103fc1f 	cmp	w0, #0xff
    6000:	5400e760 	b.eq	7cec <f0+0x22dc>  // b.none
    6004:	52800020 	mov	w0, #0x1                   	// #1
    6008:	390002e0 	strb	w0, [x23]
    600c:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    6010:	9107a3e0 	add	x0, sp, #0x1e8
    6014:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    6018:	a91ed7e1 	stp	x1, x21, [sp, #488]
    601c:	97fff539 	bl	3500 <fwp_data.part.0.constprop.0>
    6020:	aa0003f5 	mov	x21, x0
    6024:	91144283 	add	x3, x20, #0x510
    6028:	f949d861 	ldr	x1, [x3, #5040]
    602c:	f949ec60 	ldr	x0, [x3, #5080]
    6030:	cb0102a1 	sub	x1, x21, x1
    6034:	eb00403f 	cmp	x1, x0, lsl #16
    6038:	54000322 	b.cs	609c <f0+0x68c>  // b.hs, b.nlast
    603c:	d350fc22 	lsr	x2, x1, #16
    6040:	f949fc63 	ldr	x3, [x3, #5112]
    6044:	8b020842 	add	x2, x2, x2, lsl #2
    6048:	d37df042 	lsl	x2, x2, #3
    604c:	8b020060 	add	x0, x3, x2
    6050:	f9401017 	ldr	x23, [x0, #32]
    6054:	b4000257 	cbz	x23, 609c <f0+0x68c>
    6058:	38626862 	ldrb	w2, [x3, x2]
    605c:	7100085f 	cmp	w2, #0x2
    6060:	5400d860 	b.eq	7b6c <f0+0x215c>  // b.none
    6064:	7100045f 	cmp	w2, #0x1
    6068:	540001a1 	b.ne	609c <f0+0x68c>  // b.any
    606c:	29430002 	ldp	w2, w0, [x0, #24]
    6070:	92403c21 	and	x1, x1, #0xffff
    6074:	9b027c21 	mul	x1, x1, x2
    6078:	d360fc21 	lsr	x1, x1, #32
    607c:	eb00003f 	cmp	x1, x0
    6080:	540000e2 	b.cs	609c <f0+0x68c>  // b.hs, b.nlast
    6084:	8b0102f7 	add	x23, x23, x1
    6088:	394002e0 	ldrb	w0, [x23]
    608c:	7103fc1f 	cmp	w0, #0xff
    6090:	5400e340 	b.eq	7cf8 <f0+0x22e8>  // b.none
    6094:	52800020 	mov	w0, #0x1                   	// #1
    6098:	390002e0 	strb	w0, [x23]
    609c:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    60a0:	9107e3e0 	add	x0, sp, #0x1f8
    60a4:	a91fd7e1 	stp	x1, x21, [sp, #504]
    60a8:	97fff516 	bl	3500 <fwp_data.part.0.constprop.0>
    60ac:	97fff47d 	bl	32a0 <fwp_rc_fresh>
    60b0:	aa0003e1 	mov	x1, x0
    60b4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    60b8:	910823e0 	add	x0, sp, #0x208
    60bc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    60c0:	f90107e2 	str	x2, [sp, #520]
    60c4:	f9010be1 	str	x1, [sp, #528]
    60c8:	97fff50e 	bl	3500 <fwp_data.part.0.constprop.0>
    60cc:	aa0003f5 	mov	x21, x0
    60d0:	91144283 	add	x3, x20, #0x510
    60d4:	f949d861 	ldr	x1, [x3, #5040]
    60d8:	f949ec60 	ldr	x0, [x3, #5080]
    60dc:	cb0102a1 	sub	x1, x21, x1
    60e0:	eb00403f 	cmp	x1, x0, lsl #16
    60e4:	54000322 	b.cs	6148 <f0+0x738>  // b.hs, b.nlast
    60e8:	d350fc22 	lsr	x2, x1, #16
    60ec:	f949fc63 	ldr	x3, [x3, #5112]
    60f0:	8b020842 	add	x2, x2, x2, lsl #2
    60f4:	d37df042 	lsl	x2, x2, #3
    60f8:	8b020060 	add	x0, x3, x2
    60fc:	f9401017 	ldr	x23, [x0, #32]
    6100:	b4000257 	cbz	x23, 6148 <f0+0x738>
    6104:	38626862 	ldrb	w2, [x3, x2]
    6108:	7100085f 	cmp	w2, #0x2
    610c:	5400d2a0 	b.eq	7b60 <f0+0x2150>  // b.none
    6110:	7100045f 	cmp	w2, #0x1
    6114:	540001a1 	b.ne	6148 <f0+0x738>  // b.any
    6118:	29430002 	ldp	w2, w0, [x0, #24]
    611c:	92403c21 	and	x1, x1, #0xffff
    6120:	9b027c21 	mul	x1, x1, x2
    6124:	d360fc21 	lsr	x1, x1, #32
    6128:	eb00003f 	cmp	x1, x0
    612c:	540000e2 	b.cs	6148 <f0+0x738>  // b.hs, b.nlast
    6130:	8b0102f7 	add	x23, x23, x1
    6134:	394002e0 	ldrb	w0, [x23]
    6138:	7103fc1f 	cmp	w0, #0xff
    613c:	5400de40 	b.eq	7d04 <f0+0x22f4>  // b.none
    6140:	52800020 	mov	w0, #0x1                   	// #1
    6144:	390002e0 	strb	w0, [x23]
    6148:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    614c:	910863e0 	add	x0, sp, #0x218
    6150:	f9010ff7 	str	x23, [sp, #536]
    6154:	f90113f5 	str	x21, [sp, #544]
    6158:	97fff4ea 	bl	3500 <fwp_data.part.0.constprop.0>
    615c:	97fff451 	bl	32a0 <fwp_rc_fresh>
    6160:	aa0003e1 	mov	x1, x0
    6164:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6168:	9108a3e0 	add	x0, sp, #0x228
    616c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    6170:	f90117f5 	str	x21, [sp, #552]
    6174:	f9011be1 	str	x1, [sp, #560]
    6178:	97fff4e2 	bl	3500 <fwp_data.part.0.constprop.0>
    617c:	97fff449 	bl	32a0 <fwp_rc_fresh>
    6180:	aa0003e1 	mov	x1, x0
    6184:	9108e3e0 	add	x0, sp, #0x238
    6188:	f9011ff7 	str	x23, [sp, #568]
    618c:	f90123e1 	str	x1, [sp, #576]
    6190:	97fff4dc 	bl	3500 <fwp_data.part.0.constprop.0>
    6194:	97fff443 	bl	32a0 <fwp_rc_fresh>
    6198:	aa0003e1 	mov	x1, x0
    619c:	910923e0 	add	x0, sp, #0x248
    61a0:	f90127f5 	str	x21, [sp, #584]
    61a4:	f9012be1 	str	x1, [sp, #592]
    61a8:	97fff4d6 	bl	3500 <fwp_data.part.0.constprop.0>
    61ac:	97fff43d 	bl	32a0 <fwp_rc_fresh>
    61b0:	aa0003e1 	mov	x1, x0
    61b4:	910963e0 	add	x0, sp, #0x258
    61b8:	f9012ff7 	str	x23, [sp, #600]
    61bc:	f90133e1 	str	x1, [sp, #608]
    61c0:	97fff4d0 	bl	3500 <fwp_data.part.0.constprop.0>
    61c4:	aa0003f5 	mov	x21, x0
    61c8:	91144283 	add	x3, x20, #0x510
    61cc:	f949d861 	ldr	x1, [x3, #5040]
    61d0:	f949ec60 	ldr	x0, [x3, #5080]
    61d4:	cb0102a1 	sub	x1, x21, x1
    61d8:	eb00403f 	cmp	x1, x0, lsl #16
    61dc:	54000322 	b.cs	6240 <f0+0x830>  // b.hs, b.nlast
    61e0:	d350fc22 	lsr	x2, x1, #16
    61e4:	f949fc63 	ldr	x3, [x3, #5112]
    61e8:	8b020842 	add	x2, x2, x2, lsl #2
    61ec:	d37df042 	lsl	x2, x2, #3
    61f0:	8b020060 	add	x0, x3, x2
    61f4:	f9401017 	ldr	x23, [x0, #32]
    61f8:	b4000257 	cbz	x23, 6240 <f0+0x830>
    61fc:	38626862 	ldrb	w2, [x3, x2]
    6200:	7100085f 	cmp	w2, #0x2
    6204:	5400cf00 	b.eq	7be4 <f0+0x21d4>  // b.none
    6208:	7100045f 	cmp	w2, #0x1
    620c:	540001a1 	b.ne	6240 <f0+0x830>  // b.any
    6210:	29430002 	ldp	w2, w0, [x0, #24]
    6214:	92403c21 	and	x1, x1, #0xffff
    6218:	9b027c21 	mul	x1, x1, x2
    621c:	d360fc21 	lsr	x1, x1, #32
    6220:	eb00003f 	cmp	x1, x0
    6224:	540000e2 	b.cs	6240 <f0+0x830>  // b.hs, b.nlast
    6228:	8b0102f7 	add	x23, x23, x1
    622c:	394002e0 	ldrb	w0, [x23]
    6230:	7103fc1f 	cmp	w0, #0xff
    6234:	5400d6e0 	b.eq	7d10 <f0+0x2300>  // b.none
    6238:	52800020 	mov	w0, #0x1                   	// #1
    623c:	390002e0 	strb	w0, [x23]
    6240:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6244:	9109a3e0 	add	x0, sp, #0x268
    6248:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    624c:	f90137f7 	str	x23, [sp, #616]
    6250:	f9013bf5 	str	x21, [sp, #624]
    6254:	97fff4ab 	bl	3500 <fwp_data.part.0.constprop.0>
    6258:	97fff412 	bl	32a0 <fwp_rc_fresh>
    625c:	aa0003e1 	mov	x1, x0
    6260:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    6264:	9109e3e0 	add	x0, sp, #0x278
    6268:	f9013fe2 	str	x2, [sp, #632]
    626c:	f90143e1 	str	x1, [sp, #640]
    6270:	97fff4a4 	bl	3500 <fwp_data.part.0.constprop.0>
    6274:	97fff40b 	bl	32a0 <fwp_rc_fresh>
    6278:	aa0003e1 	mov	x1, x0
    627c:	910a23e0 	add	x0, sp, #0x288
    6280:	f90147f7 	str	x23, [sp, #648]
    6284:	f9014be1 	str	x1, [sp, #656]
    6288:	97fff49e 	bl	3500 <fwp_data.part.0.constprop.0>
    628c:	aa0003f5 	mov	x21, x0
    6290:	91144283 	add	x3, x20, #0x510
    6294:	f949d861 	ldr	x1, [x3, #5040]
    6298:	f949ec60 	ldr	x0, [x3, #5080]
    629c:	cb0102a1 	sub	x1, x21, x1
    62a0:	eb00403f 	cmp	x1, x0, lsl #16
    62a4:	54000322 	b.cs	6308 <f0+0x8f8>  // b.hs, b.nlast
    62a8:	d350fc22 	lsr	x2, x1, #16
    62ac:	f949fc63 	ldr	x3, [x3, #5112]
    62b0:	8b020842 	add	x2, x2, x2, lsl #2
    62b4:	d37df042 	lsl	x2, x2, #3
    62b8:	8b020060 	add	x0, x3, x2
    62bc:	f9401017 	ldr	x23, [x0, #32]
    62c0:	b4000257 	cbz	x23, 6308 <f0+0x8f8>
    62c4:	38626862 	ldrb	w2, [x3, x2]
    62c8:	7100085f 	cmp	w2, #0x2
    62cc:	5400c860 	b.eq	7bd8 <f0+0x21c8>  // b.none
    62d0:	7100045f 	cmp	w2, #0x1
    62d4:	540001a1 	b.ne	6308 <f0+0x8f8>  // b.any
    62d8:	29430002 	ldp	w2, w0, [x0, #24]
    62dc:	92403c21 	and	x1, x1, #0xffff
    62e0:	9b027c21 	mul	x1, x1, x2
    62e4:	d360fc21 	lsr	x1, x1, #32
    62e8:	eb00003f 	cmp	x1, x0
    62ec:	540000e2 	b.cs	6308 <f0+0x8f8>  // b.hs, b.nlast
    62f0:	8b0102f7 	add	x23, x23, x1
    62f4:	394002e0 	ldrb	w0, [x23]
    62f8:	7103fc1f 	cmp	w0, #0xff
    62fc:	5400d100 	b.eq	7d1c <f0+0x230c>  // b.none
    6300:	52800020 	mov	w0, #0x1                   	// #1
    6304:	390002e0 	strb	w0, [x23]
    6308:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    630c:	910a63e0 	add	x0, sp, #0x298
    6310:	f9014fe1 	str	x1, [sp, #664]
    6314:	f90153f5 	str	x21, [sp, #672]
    6318:	97fff47a 	bl	3500 <fwp_data.part.0.constprop.0>
    631c:	91144283 	add	x3, x20, #0x510
    6320:	aa0003f5 	mov	x21, x0
    6324:	f949d861 	ldr	x1, [x3, #5040]
    6328:	f949ec60 	ldr	x0, [x3, #5080]
    632c:	cb0102a1 	sub	x1, x21, x1
    6330:	eb00403f 	cmp	x1, x0, lsl #16
    6334:	54000322 	b.cs	6398 <f0+0x988>  // b.hs, b.nlast
    6338:	d350fc22 	lsr	x2, x1, #16
    633c:	f949fc63 	ldr	x3, [x3, #5112]
    6340:	8b020842 	add	x2, x2, x2, lsl #2
    6344:	d37df042 	lsl	x2, x2, #3
    6348:	8b020060 	add	x0, x3, x2
    634c:	f9401017 	ldr	x23, [x0, #32]
    6350:	b4000257 	cbz	x23, 6398 <f0+0x988>
    6354:	38626862 	ldrb	w2, [x3, x2]
    6358:	7100085f 	cmp	w2, #0x2
    635c:	5400c380 	b.eq	7bcc <f0+0x21bc>  // b.none
    6360:	7100045f 	cmp	w2, #0x1
    6364:	540001a1 	b.ne	6398 <f0+0x988>  // b.any
    6368:	29430002 	ldp	w2, w0, [x0, #24]
    636c:	92403c21 	and	x1, x1, #0xffff
    6370:	9b027c21 	mul	x1, x1, x2
    6374:	d360fc21 	lsr	x1, x1, #32
    6378:	eb00003f 	cmp	x1, x0
    637c:	540000e2 	b.cs	6398 <f0+0x988>  // b.hs, b.nlast
    6380:	8b0102f7 	add	x23, x23, x1
    6384:	394002e0 	ldrb	w0, [x23]
    6388:	7103fc1f 	cmp	w0, #0xff
    638c:	5400cce0 	b.eq	7d28 <f0+0x2318>  // b.none
    6390:	52800020 	mov	w0, #0x1                   	// #1
    6394:	390002e0 	strb	w0, [x23]
    6398:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    639c:	910aa3e0 	add	x0, sp, #0x2a8
    63a0:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    63a4:	f90157e1 	str	x1, [sp, #680]
    63a8:	f9015bf5 	str	x21, [sp, #688]
    63ac:	97fff455 	bl	3500 <fwp_data.part.0.constprop.0>
    63b0:	aa0003f5 	mov	x21, x0
    63b4:	91144283 	add	x3, x20, #0x510
    63b8:	f949d861 	ldr	x1, [x3, #5040]
    63bc:	f949ec60 	ldr	x0, [x3, #5080]
    63c0:	cb0102a1 	sub	x1, x21, x1
    63c4:	eb00403f 	cmp	x1, x0, lsl #16
    63c8:	54000322 	b.cs	642c <f0+0xa1c>  // b.hs, b.nlast
    63cc:	d350fc22 	lsr	x2, x1, #16
    63d0:	f949fc63 	ldr	x3, [x3, #5112]
    63d4:	8b020842 	add	x2, x2, x2, lsl #2
    63d8:	d37df042 	lsl	x2, x2, #3
    63dc:	8b020060 	add	x0, x3, x2
    63e0:	f9401017 	ldr	x23, [x0, #32]
    63e4:	b4000257 	cbz	x23, 642c <f0+0xa1c>
    63e8:	38626862 	ldrb	w2, [x3, x2]
    63ec:	7100085f 	cmp	w2, #0x2
    63f0:	5400be80 	b.eq	7bc0 <f0+0x21b0>  // b.none
    63f4:	7100045f 	cmp	w2, #0x1
    63f8:	540001a1 	b.ne	642c <f0+0xa1c>  // b.any
    63fc:	29430002 	ldp	w2, w0, [x0, #24]
    6400:	92403c21 	and	x1, x1, #0xffff
    6404:	9b027c21 	mul	x1, x1, x2
    6408:	d360fc21 	lsr	x1, x1, #32
    640c:	eb00003f 	cmp	x1, x0
    6410:	540000e2 	b.cs	642c <f0+0xa1c>  // b.hs, b.nlast
    6414:	8b0102f7 	add	x23, x23, x1
    6418:	394002e0 	ldrb	w0, [x23]
    641c:	7103fc1f 	cmp	w0, #0xff
    6420:	5400c8a0 	b.eq	7d34 <f0+0x2324>  // b.none
    6424:	52800020 	mov	w0, #0x1                   	// #1
    6428:	390002e0 	strb	w0, [x23]
    642c:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6430:	910ae3e0 	add	x0, sp, #0x2b8
    6434:	f9015fe1 	str	x1, [sp, #696]
    6438:	f90163f5 	str	x21, [sp, #704]
    643c:	97fff431 	bl	3500 <fwp_data.part.0.constprop.0>
    6440:	91144283 	add	x3, x20, #0x510
    6444:	aa0003f5 	mov	x21, x0
    6448:	f949d861 	ldr	x1, [x3, #5040]
    644c:	f949ec60 	ldr	x0, [x3, #5080]
    6450:	cb0102a1 	sub	x1, x21, x1
    6454:	eb00403f 	cmp	x1, x0, lsl #16
    6458:	54000322 	b.cs	64bc <f0+0xaac>  // b.hs, b.nlast
    645c:	d350fc22 	lsr	x2, x1, #16
    6460:	f949fc63 	ldr	x3, [x3, #5112]
    6464:	8b020842 	add	x2, x2, x2, lsl #2
    6468:	d37df042 	lsl	x2, x2, #3
    646c:	8b020060 	add	x0, x3, x2
    6470:	f9401017 	ldr	x23, [x0, #32]
    6474:	b4000257 	cbz	x23, 64bc <f0+0xaac>
    6478:	38626862 	ldrb	w2, [x3, x2]
    647c:	7100085f 	cmp	w2, #0x2
    6480:	5400b9a0 	b.eq	7bb4 <f0+0x21a4>  // b.none
    6484:	7100045f 	cmp	w2, #0x1
    6488:	540001a1 	b.ne	64bc <f0+0xaac>  // b.any
    648c:	29430002 	ldp	w2, w0, [x0, #24]
    6490:	92403c21 	and	x1, x1, #0xffff
    6494:	9b027c21 	mul	x1, x1, x2
    6498:	d360fc21 	lsr	x1, x1, #32
    649c:	eb00003f 	cmp	x1, x0
    64a0:	540000e2 	b.cs	64bc <f0+0xaac>  // b.hs, b.nlast
    64a4:	8b0102f7 	add	x23, x23, x1
    64a8:	394002e0 	ldrb	w0, [x23]
    64ac:	7103fc1f 	cmp	w0, #0xff
    64b0:	5400c480 	b.eq	7d40 <f0+0x2330>  // b.none
    64b4:	52800020 	mov	w0, #0x1                   	// #1
    64b8:	390002e0 	strb	w0, [x23]
    64bc:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    64c0:	910b23e0 	add	x0, sp, #0x2c8
    64c4:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    64c8:	f90167e1 	str	x1, [sp, #712]
    64cc:	f9016bf5 	str	x21, [sp, #720]
    64d0:	97fff40c 	bl	3500 <fwp_data.part.0.constprop.0>
    64d4:	97fff373 	bl	32a0 <fwp_rc_fresh>
    64d8:	aa0003e1 	mov	x1, x0
    64dc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    64e0:	910b63e0 	add	x0, sp, #0x2d8
    64e4:	f9016fe2 	str	x2, [sp, #728]
    64e8:	f90173e1 	str	x1, [sp, #736]
    64ec:	97fff405 	bl	3500 <fwp_data.part.0.constprop.0>
    64f0:	91144283 	add	x3, x20, #0x510
    64f4:	aa0003f5 	mov	x21, x0
    64f8:	f949d861 	ldr	x1, [x3, #5040]
    64fc:	f949ec60 	ldr	x0, [x3, #5080]
    6500:	cb0102a1 	sub	x1, x21, x1
    6504:	eb00403f 	cmp	x1, x0, lsl #16
    6508:	54000322 	b.cs	656c <f0+0xb5c>  // b.hs, b.nlast
    650c:	d350fc22 	lsr	x2, x1, #16
    6510:	f949fc63 	ldr	x3, [x3, #5112]
    6514:	8b020842 	add	x2, x2, x2, lsl #2
    6518:	d37df042 	lsl	x2, x2, #3
    651c:	8b020060 	add	x0, x3, x2
    6520:	f9401017 	ldr	x23, [x0, #32]
    6524:	b4000257 	cbz	x23, 656c <f0+0xb5c>
    6528:	38626862 	ldrb	w2, [x3, x2]
    652c:	7100085f 	cmp	w2, #0x2
    6530:	5400b3c0 	b.eq	7ba8 <f0+0x2198>  // b.none
    6534:	7100045f 	cmp	w2, #0x1
    6538:	540001a1 	b.ne	656c <f0+0xb5c>  // b.any
    653c:	29430002 	ldp	w2, w0, [x0, #24]
    6540:	92403c21 	and	x1, x1, #0xffff
    6544:	9b027c21 	mul	x1, x1, x2
    6548:	d360fc21 	lsr	x1, x1, #32
    654c:	eb00003f 	cmp	x1, x0
    6550:	540000e2 	b.cs	656c <f0+0xb5c>  // b.hs, b.nlast
    6554:	8b0102f7 	add	x23, x23, x1
    6558:	394002e0 	ldrb	w0, [x23]
    655c:	7103fc1f 	cmp	w0, #0xff
    6560:	5400bf60 	b.eq	7d4c <f0+0x233c>  // b.none
    6564:	52800020 	mov	w0, #0x1                   	// #1
    6568:	390002e0 	strb	w0, [x23]
    656c:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    6570:	910ba3e0 	add	x0, sp, #0x2e8
    6574:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    6578:	f90177e1 	str	x1, [sp, #744]
    657c:	f9017bf5 	str	x21, [sp, #752]
    6580:	97fff3e0 	bl	3500 <fwp_data.part.0.constprop.0>
    6584:	aa0003f5 	mov	x21, x0
    6588:	91144283 	add	x3, x20, #0x510
    658c:	f949d861 	ldr	x1, [x3, #5040]
    6590:	f949ec60 	ldr	x0, [x3, #5080]
    6594:	cb0102a1 	sub	x1, x21, x1
    6598:	eb00403f 	cmp	x1, x0, lsl #16
    659c:	54000322 	b.cs	6600 <f0+0xbf0>  // b.hs, b.nlast
    65a0:	d350fc22 	lsr	x2, x1, #16
    65a4:	f949fc63 	ldr	x3, [x3, #5112]
    65a8:	8b020842 	add	x2, x2, x2, lsl #2
    65ac:	d37df042 	lsl	x2, x2, #3
    65b0:	8b020060 	add	x0, x3, x2
    65b4:	f9401017 	ldr	x23, [x0, #32]
    65b8:	b4000257 	cbz	x23, 6600 <f0+0xbf0>
    65bc:	38626862 	ldrb	w2, [x3, x2]
    65c0:	7100085f 	cmp	w2, #0x2
    65c4:	5400aec0 	b.eq	7b9c <f0+0x218c>  // b.none
    65c8:	7100045f 	cmp	w2, #0x1
    65cc:	540001a1 	b.ne	6600 <f0+0xbf0>  // b.any
    65d0:	29430002 	ldp	w2, w0, [x0, #24]
    65d4:	92403c21 	and	x1, x1, #0xffff
    65d8:	9b027c21 	mul	x1, x1, x2
    65dc:	d360fc21 	lsr	x1, x1, #32
    65e0:	eb00003f 	cmp	x1, x0
    65e4:	540000e2 	b.cs	6600 <f0+0xbf0>  // b.hs, b.nlast
    65e8:	8b0102f7 	add	x23, x23, x1
    65ec:	394002e0 	ldrb	w0, [x23]
    65f0:	7103fc1f 	cmp	w0, #0xff
    65f4:	5400bb20 	b.eq	7d58 <f0+0x2348>  // b.none
    65f8:	52800020 	mov	w0, #0x1                   	// #1
    65fc:	390002e0 	strb	w0, [x23]
    6600:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6604:	910be3e0 	add	x0, sp, #0x2f8
    6608:	f9017ff7 	str	x23, [sp, #760]
    660c:	f90183f5 	str	x21, [sp, #768]
    6610:	97fff3bc 	bl	3500 <fwp_data.part.0.constprop.0>
    6614:	97fff323 	bl	32a0 <fwp_rc_fresh>
    6618:	aa0003e1 	mov	x1, x0
    661c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6620:	910c23e0 	add	x0, sp, #0x308
    6624:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6628:	f90187e2 	str	x2, [sp, #776]
    662c:	f9018be1 	str	x1, [sp, #784]
    6630:	97fff3b4 	bl	3500 <fwp_data.part.0.constprop.0>
    6634:	97fff31b 	bl	32a0 <fwp_rc_fresh>
    6638:	aa0003e1 	mov	x1, x0
    663c:	910c63e0 	add	x0, sp, #0x318
    6640:	f9018ff7 	str	x23, [sp, #792]
    6644:	f90193e1 	str	x1, [sp, #800]
    6648:	97fff3ae 	bl	3500 <fwp_data.part.0.constprop.0>
    664c:	aa0003f5 	mov	x21, x0
    6650:	91144283 	add	x3, x20, #0x510
    6654:	f949d861 	ldr	x1, [x3, #5040]
    6658:	f949ec60 	ldr	x0, [x3, #5080]
    665c:	cb0102a1 	sub	x1, x21, x1
    6660:	eb00403f 	cmp	x1, x0, lsl #16
    6664:	54000322 	b.cs	66c8 <f0+0xcb8>  // b.hs, b.nlast
    6668:	d350fc22 	lsr	x2, x1, #16
    666c:	f949fc63 	ldr	x3, [x3, #5112]
    6670:	8b020842 	add	x2, x2, x2, lsl #2
    6674:	d37df042 	lsl	x2, x2, #3
    6678:	8b020060 	add	x0, x3, x2
    667c:	f9401017 	ldr	x23, [x0, #32]
    6680:	b4000257 	cbz	x23, 66c8 <f0+0xcb8>
    6684:	38626862 	ldrb	w2, [x3, x2]
    6688:	7100085f 	cmp	w2, #0x2
    668c:	5400a820 	b.eq	7b90 <f0+0x2180>  // b.none
    6690:	7100045f 	cmp	w2, #0x1
    6694:	540001a1 	b.ne	66c8 <f0+0xcb8>  // b.any
    6698:	29430002 	ldp	w2, w0, [x0, #24]
    669c:	92403c21 	and	x1, x1, #0xffff
    66a0:	9b027c21 	mul	x1, x1, x2
    66a4:	d360fc21 	lsr	x1, x1, #32
    66a8:	eb00003f 	cmp	x1, x0
    66ac:	540000e2 	b.cs	66c8 <f0+0xcb8>  // b.hs, b.nlast
    66b0:	8b0102f7 	add	x23, x23, x1
    66b4:	394002e0 	ldrb	w0, [x23]
    66b8:	7103fc1f 	cmp	w0, #0xff
    66bc:	5400b540 	b.eq	7d64 <f0+0x2354>  // b.none
    66c0:	52800020 	mov	w0, #0x1                   	// #1
    66c4:	390002e0 	strb	w0, [x23]
    66c8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    66cc:	910ca3e0 	add	x0, sp, #0x328
    66d0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    66d4:	f90197f7 	str	x23, [sp, #808]
    66d8:	f9019bf5 	str	x21, [sp, #816]
    66dc:	97fff389 	bl	3500 <fwp_data.part.0.constprop.0>
    66e0:	97fff2f0 	bl	32a0 <fwp_rc_fresh>
    66e4:	aa0003e1 	mov	x1, x0
    66e8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    66ec:	910ce3e0 	add	x0, sp, #0x338
    66f0:	f9019ff5 	str	x21, [sp, #824]
    66f4:	f901a3e1 	str	x1, [sp, #832]
    66f8:	97fff382 	bl	3500 <fwp_data.part.0.constprop.0>
    66fc:	97fff2e9 	bl	32a0 <fwp_rc_fresh>
    6700:	aa0003e1 	mov	x1, x0
    6704:	910d23e0 	add	x0, sp, #0x348
    6708:	f901a7f7 	str	x23, [sp, #840]
    670c:	f901abe1 	str	x1, [sp, #848]
    6710:	97fff37c 	bl	3500 <fwp_data.part.0.constprop.0>
    6714:	97fff2e3 	bl	32a0 <fwp_rc_fresh>
    6718:	aa0003e1 	mov	x1, x0
    671c:	910d63e0 	add	x0, sp, #0x358
    6720:	f901aff5 	str	x21, [sp, #856]
    6724:	f901b3e1 	str	x1, [sp, #864]
    6728:	97fff376 	bl	3500 <fwp_data.part.0.constprop.0>
    672c:	97fff2dd 	bl	32a0 <fwp_rc_fresh>
    6730:	aa0003e1 	mov	x1, x0
    6734:	910da3e0 	add	x0, sp, #0x368
    6738:	f901b7f7 	str	x23, [sp, #872]
    673c:	f901bbe1 	str	x1, [sp, #880]
    6740:	97fff370 	bl	3500 <fwp_data.part.0.constprop.0>
    6744:	aa0003f5 	mov	x21, x0
    6748:	91144283 	add	x3, x20, #0x510
    674c:	f949d861 	ldr	x1, [x3, #5040]
    6750:	f949ec60 	ldr	x0, [x3, #5080]
    6754:	cb0102a1 	sub	x1, x21, x1
    6758:	eb00403f 	cmp	x1, x0, lsl #16
    675c:	54000322 	b.cs	67c0 <f0+0xdb0>  // b.hs, b.nlast
    6760:	d350fc22 	lsr	x2, x1, #16
    6764:	f949fc63 	ldr	x3, [x3, #5112]
    6768:	8b020842 	add	x2, x2, x2, lsl #2
    676c:	d37df042 	lsl	x2, x2, #3
    6770:	8b020060 	add	x0, x3, x2
    6774:	f9401017 	ldr	x23, [x0, #32]
    6778:	b4000257 	cbz	x23, 67c0 <f0+0xdb0>
    677c:	38626862 	ldrb	w2, [x3, x2]
    6780:	7100085f 	cmp	w2, #0x2
    6784:	54009d60 	b.eq	7b30 <f0+0x2120>  // b.none
    6788:	7100045f 	cmp	w2, #0x1
    678c:	540001a1 	b.ne	67c0 <f0+0xdb0>  // b.any
    6790:	29430002 	ldp	w2, w0, [x0, #24]
    6794:	92403c21 	and	x1, x1, #0xffff
    6798:	9b027c21 	mul	x1, x1, x2
    679c:	d360fc21 	lsr	x1, x1, #32
    67a0:	eb00003f 	cmp	x1, x0
    67a4:	540000e2 	b.cs	67c0 <f0+0xdb0>  // b.hs, b.nlast
    67a8:	8b0102f7 	add	x23, x23, x1
    67ac:	394002e0 	ldrb	w0, [x23]
    67b0:	7103fc1f 	cmp	w0, #0xff
    67b4:	5400ade0 	b.eq	7d70 <f0+0x2360>  // b.none
    67b8:	52800020 	mov	w0, #0x1                   	// #1
    67bc:	390002e0 	strb	w0, [x23]
    67c0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    67c4:	910de3e0 	add	x0, sp, #0x378
    67c8:	f901bff7 	str	x23, [sp, #888]
    67cc:	f901c3f5 	str	x21, [sp, #896]
    67d0:	97fff34c 	bl	3500 <fwp_data.part.0.constprop.0>
    67d4:	97fff2b3 	bl	32a0 <fwp_rc_fresh>
    67d8:	aa0003e1 	mov	x1, x0
    67dc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    67e0:	910e23e0 	add	x0, sp, #0x388
    67e4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    67e8:	f901c7f5 	str	x21, [sp, #904]
    67ec:	f901cbe1 	str	x1, [sp, #912]
    67f0:	97fff344 	bl	3500 <fwp_data.part.0.constprop.0>
    67f4:	97fff2ab 	bl	32a0 <fwp_rc_fresh>
    67f8:	aa0003e1 	mov	x1, x0
    67fc:	910e63e0 	add	x0, sp, #0x398
    6800:	f901cff7 	str	x23, [sp, #920]
    6804:	f901d3e1 	str	x1, [sp, #928]
    6808:	97fff33e 	bl	3500 <fwp_data.part.0.constprop.0>
    680c:	97fff2a5 	bl	32a0 <fwp_rc_fresh>
    6810:	aa0003e1 	mov	x1, x0
    6814:	910ea3e0 	add	x0, sp, #0x3a8
    6818:	f901d7f5 	str	x21, [sp, #936]
    681c:	f901dbe1 	str	x1, [sp, #944]
    6820:	97fff338 	bl	3500 <fwp_data.part.0.constprop.0>
    6824:	aa0003f5 	mov	x21, x0
    6828:	91144283 	add	x3, x20, #0x510
    682c:	f949d861 	ldr	x1, [x3, #5040]
    6830:	f949ec60 	ldr	x0, [x3, #5080]
    6834:	cb0102a1 	sub	x1, x21, x1
    6838:	eb00403f 	cmp	x1, x0, lsl #16
    683c:	54000322 	b.cs	68a0 <f0+0xe90>  // b.hs, b.nlast
    6840:	d350fc22 	lsr	x2, x1, #16
    6844:	f949fc63 	ldr	x3, [x3, #5112]
    6848:	8b020842 	add	x2, x2, x2, lsl #2
    684c:	d37df042 	lsl	x2, x2, #3
    6850:	8b020060 	add	x0, x3, x2
    6854:	f9401017 	ldr	x23, [x0, #32]
    6858:	b4000257 	cbz	x23, 68a0 <f0+0xe90>
    685c:	38626862 	ldrb	w2, [x3, x2]
    6860:	7100085f 	cmp	w2, #0x2
    6864:	54009600 	b.eq	7b24 <f0+0x2114>  // b.none
    6868:	7100045f 	cmp	w2, #0x1
    686c:	540001a1 	b.ne	68a0 <f0+0xe90>  // b.any
    6870:	29430002 	ldp	w2, w0, [x0, #24]
    6874:	92403c21 	and	x1, x1, #0xffff
    6878:	9b027c21 	mul	x1, x1, x2
    687c:	d360fc21 	lsr	x1, x1, #32
    6880:	eb00003f 	cmp	x1, x0
    6884:	540000e2 	b.cs	68a0 <f0+0xe90>  // b.hs, b.nlast
    6888:	8b0102f7 	add	x23, x23, x1
    688c:	394002e0 	ldrb	w0, [x23]
    6890:	7103fc1f 	cmp	w0, #0xff
    6894:	5400a740 	b.eq	7d7c <f0+0x236c>  // b.none
    6898:	52800020 	mov	w0, #0x1                   	// #1
    689c:	390002e0 	strb	w0, [x23]
    68a0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    68a4:	910ee3e0 	add	x0, sp, #0x3b8
    68a8:	f901dff7 	str	x23, [sp, #952]
    68ac:	f901e3f5 	str	x21, [sp, #960]
    68b0:	97fff314 	bl	3500 <fwp_data.part.0.constprop.0>
    68b4:	97fff27b 	bl	32a0 <fwp_rc_fresh>
    68b8:	aa0003e1 	mov	x1, x0
    68bc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    68c0:	910f23e0 	add	x0, sp, #0x3c8
    68c4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    68c8:	f901e7f5 	str	x21, [sp, #968]
    68cc:	f901ebe1 	str	x1, [sp, #976]
    68d0:	97fff30c 	bl	3500 <fwp_data.part.0.constprop.0>
    68d4:	97fff273 	bl	32a0 <fwp_rc_fresh>
    68d8:	aa0003e1 	mov	x1, x0
    68dc:	910f63e0 	add	x0, sp, #0x3d8
    68e0:	f901eff7 	str	x23, [sp, #984]
    68e4:	f901f3e1 	str	x1, [sp, #992]
    68e8:	97fff306 	bl	3500 <fwp_data.part.0.constprop.0>
    68ec:	97fff26d 	bl	32a0 <fwp_rc_fresh>
    68f0:	aa0003e1 	mov	x1, x0
    68f4:	910fa3e0 	add	x0, sp, #0x3e8
    68f8:	f901f7f5 	str	x21, [sp, #1000]
    68fc:	f901fbe1 	str	x1, [sp, #1008]
    6900:	97fff300 	bl	3500 <fwp_data.part.0.constprop.0>
    6904:	aa0003f5 	mov	x21, x0
    6908:	91144283 	add	x3, x20, #0x510
    690c:	f949d861 	ldr	x1, [x3, #5040]
    6910:	f949ec60 	ldr	x0, [x3, #5080]
    6914:	cb0102a1 	sub	x1, x21, x1
    6918:	eb00403f 	cmp	x1, x0, lsl #16
    691c:	54000322 	b.cs	6980 <f0+0xf70>  // b.hs, b.nlast
    6920:	d350fc22 	lsr	x2, x1, #16
    6924:	f949fc63 	ldr	x3, [x3, #5112]
    6928:	8b020842 	add	x2, x2, x2, lsl #2
    692c:	d37df042 	lsl	x2, x2, #3
    6930:	8b020060 	add	x0, x3, x2
    6934:	f9401017 	ldr	x23, [x0, #32]
    6938:	b4000257 	cbz	x23, 6980 <f0+0xf70>
    693c:	38626862 	ldrb	w2, [x3, x2]
    6940:	7100085f 	cmp	w2, #0x2
    6944:	54008ea0 	b.eq	7b18 <f0+0x2108>  // b.none
    6948:	7100045f 	cmp	w2, #0x1
    694c:	540001a1 	b.ne	6980 <f0+0xf70>  // b.any
    6950:	29430002 	ldp	w2, w0, [x0, #24]
    6954:	92403c21 	and	x1, x1, #0xffff
    6958:	9b027c21 	mul	x1, x1, x2
    695c:	d360fc21 	lsr	x1, x1, #32
    6960:	eb00003f 	cmp	x1, x0
    6964:	540000e2 	b.cs	6980 <f0+0xf70>  // b.hs, b.nlast
    6968:	8b0102f7 	add	x23, x23, x1
    696c:	394002e0 	ldrb	w0, [x23]
    6970:	7103fc1f 	cmp	w0, #0xff
    6974:	5400a0a0 	b.eq	7d88 <f0+0x2378>  // b.none
    6978:	52800020 	mov	w0, #0x1                   	// #1
    697c:	390002e0 	strb	w0, [x23]
    6980:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6984:	910fe3e0 	add	x0, sp, #0x3f8
    6988:	f901fff7 	str	x23, [sp, #1016]
    698c:	f90203f5 	str	x21, [sp, #1024]
    6990:	97fff2dc 	bl	3500 <fwp_data.part.0.constprop.0>
    6994:	97fff243 	bl	32a0 <fwp_rc_fresh>
    6998:	aa0003e1 	mov	x1, x0
    699c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    69a0:	911023e0 	add	x0, sp, #0x408
    69a4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    69a8:	f90207f5 	str	x21, [sp, #1032]
    69ac:	f9020be1 	str	x1, [sp, #1040]
    69b0:	97fff2d4 	bl	3500 <fwp_data.part.0.constprop.0>
    69b4:	97fff23b 	bl	32a0 <fwp_rc_fresh>
    69b8:	aa0003e1 	mov	x1, x0
    69bc:	911063e0 	add	x0, sp, #0x418
    69c0:	f9020ff7 	str	x23, [sp, #1048]
    69c4:	f90213e1 	str	x1, [sp, #1056]
    69c8:	97fff2ce 	bl	3500 <fwp_data.part.0.constprop.0>
    69cc:	97fff235 	bl	32a0 <fwp_rc_fresh>
    69d0:	aa0003e1 	mov	x1, x0
    69d4:	9110a3e0 	add	x0, sp, #0x428
    69d8:	f90217f5 	str	x21, [sp, #1064]
    69dc:	f9021be1 	str	x1, [sp, #1072]
    69e0:	97fff2c8 	bl	3500 <fwp_data.part.0.constprop.0>
    69e4:	aa0003f5 	mov	x21, x0
    69e8:	91144283 	add	x3, x20, #0x510
    69ec:	f949d861 	ldr	x1, [x3, #5040]
    69f0:	f949ec60 	ldr	x0, [x3, #5080]
    69f4:	cb0102a1 	sub	x1, x21, x1
    69f8:	eb00403f 	cmp	x1, x0, lsl #16
    69fc:	54000322 	b.cs	6a60 <f0+0x1050>  // b.hs, b.nlast
    6a00:	d350fc22 	lsr	x2, x1, #16
    6a04:	f949fc63 	ldr	x3, [x3, #5112]
    6a08:	8b020842 	add	x2, x2, x2, lsl #2
    6a0c:	d37df042 	lsl	x2, x2, #3
    6a10:	8b020060 	add	x0, x3, x2
    6a14:	f9401017 	ldr	x23, [x0, #32]
    6a18:	b4000257 	cbz	x23, 6a60 <f0+0x1050>
    6a1c:	38626862 	ldrb	w2, [x3, x2]
    6a20:	7100085f 	cmp	w2, #0x2
    6a24:	54008740 	b.eq	7b0c <f0+0x20fc>  // b.none
    6a28:	7100045f 	cmp	w2, #0x1
    6a2c:	540001a1 	b.ne	6a60 <f0+0x1050>  // b.any
    6a30:	29430002 	ldp	w2, w0, [x0, #24]
    6a34:	92403c21 	and	x1, x1, #0xffff
    6a38:	9b027c21 	mul	x1, x1, x2
    6a3c:	d360fc21 	lsr	x1, x1, #32
    6a40:	eb00003f 	cmp	x1, x0
    6a44:	540000e2 	b.cs	6a60 <f0+0x1050>  // b.hs, b.nlast
    6a48:	8b0102f7 	add	x23, x23, x1
    6a4c:	394002e0 	ldrb	w0, [x23]
    6a50:	7103fc1f 	cmp	w0, #0xff
    6a54:	54009a00 	b.eq	7d94 <f0+0x2384>  // b.none
    6a58:	52800020 	mov	w0, #0x1                   	// #1
    6a5c:	390002e0 	strb	w0, [x23]
    6a60:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6a64:	9110e3e0 	add	x0, sp, #0x438
    6a68:	f9021ff7 	str	x23, [sp, #1080]
    6a6c:	f90223f5 	str	x21, [sp, #1088]
    6a70:	97fff2a4 	bl	3500 <fwp_data.part.0.constprop.0>
    6a74:	97fff20b 	bl	32a0 <fwp_rc_fresh>
    6a78:	aa0003e1 	mov	x1, x0
    6a7c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6a80:	911123e0 	add	x0, sp, #0x448
    6a84:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    6a88:	f90227f5 	str	x21, [sp, #1096]
    6a8c:	f9022be1 	str	x1, [sp, #1104]
    6a90:	97fff29c 	bl	3500 <fwp_data.part.0.constprop.0>
    6a94:	97fff203 	bl	32a0 <fwp_rc_fresh>
    6a98:	aa0003e1 	mov	x1, x0
    6a9c:	911163e0 	add	x0, sp, #0x458
    6aa0:	f9022ff7 	str	x23, [sp, #1112]
    6aa4:	f90233e1 	str	x1, [sp, #1120]
    6aa8:	97fff296 	bl	3500 <fwp_data.part.0.constprop.0>
    6aac:	97fff1fd 	bl	32a0 <fwp_rc_fresh>
    6ab0:	aa0003e1 	mov	x1, x0
    6ab4:	9111a3e0 	add	x0, sp, #0x468
    6ab8:	f90237f5 	str	x21, [sp, #1128]
    6abc:	f9023be1 	str	x1, [sp, #1136]
    6ac0:	97fff290 	bl	3500 <fwp_data.part.0.constprop.0>
    6ac4:	97fff1f7 	bl	32a0 <fwp_rc_fresh>
    6ac8:	aa0003e1 	mov	x1, x0
    6acc:	9111e3e0 	add	x0, sp, #0x478
    6ad0:	f9023ff7 	str	x23, [sp, #1144]
    6ad4:	f90243e1 	str	x1, [sp, #1152]
    6ad8:	97fff28a 	bl	3500 <fwp_data.part.0.constprop.0>
    6adc:	97fff1f1 	bl	32a0 <fwp_rc_fresh>
    6ae0:	aa0003e1 	mov	x1, x0
    6ae4:	911223e0 	add	x0, sp, #0x488
    6ae8:	f90247f5 	str	x21, [sp, #1160]
    6aec:	f9024be1 	str	x1, [sp, #1168]
    6af0:	97fff284 	bl	3500 <fwp_data.part.0.constprop.0>
    6af4:	97fff1eb 	bl	32a0 <fwp_rc_fresh>
    6af8:	aa0003e1 	mov	x1, x0
    6afc:	911263e0 	add	x0, sp, #0x498
    6b00:	f9024ff7 	str	x23, [sp, #1176]
    6b04:	f90253e1 	str	x1, [sp, #1184]
    6b08:	97fff27e 	bl	3500 <fwp_data.part.0.constprop.0>
    6b0c:	97fff1e5 	bl	32a0 <fwp_rc_fresh>
    6b10:	aa0003e1 	mov	x1, x0
    6b14:	9112a3e0 	add	x0, sp, #0x4a8
    6b18:	f90257f5 	str	x21, [sp, #1192]
    6b1c:	f9025be1 	str	x1, [sp, #1200]
    6b20:	97fff278 	bl	3500 <fwp_data.part.0.constprop.0>
    6b24:	aa0003f5 	mov	x21, x0
    6b28:	91144283 	add	x3, x20, #0x510
    6b2c:	f949d861 	ldr	x1, [x3, #5040]
    6b30:	f949ec60 	ldr	x0, [x3, #5080]
    6b34:	cb0102a1 	sub	x1, x21, x1
    6b38:	eb00403f 	cmp	x1, x0, lsl #16
    6b3c:	54000322 	b.cs	6ba0 <f0+0x1190>  // b.hs, b.nlast
    6b40:	d350fc22 	lsr	x2, x1, #16
    6b44:	f949fc63 	ldr	x3, [x3, #5112]
    6b48:	8b020842 	add	x2, x2, x2, lsl #2
    6b4c:	d37df042 	lsl	x2, x2, #3
    6b50:	8b020060 	add	x0, x3, x2
    6b54:	f9401017 	ldr	x23, [x0, #32]
    6b58:	b4000257 	cbz	x23, 6ba0 <f0+0x1190>
    6b5c:	38626862 	ldrb	w2, [x3, x2]
    6b60:	7100085f 	cmp	w2, #0x2
    6b64:	54007ce0 	b.eq	7b00 <f0+0x20f0>  // b.none
    6b68:	7100045f 	cmp	w2, #0x1
    6b6c:	540001a1 	b.ne	6ba0 <f0+0x1190>  // b.any
    6b70:	29430002 	ldp	w2, w0, [x0, #24]
    6b74:	92403c21 	and	x1, x1, #0xffff
    6b78:	9b027c21 	mul	x1, x1, x2
    6b7c:	d360fc21 	lsr	x1, x1, #32
    6b80:	eb00003f 	cmp	x1, x0
    6b84:	540000e2 	b.cs	6ba0 <f0+0x1190>  // b.hs, b.nlast
    6b88:	8b0102f7 	add	x23, x23, x1
    6b8c:	394002e0 	ldrb	w0, [x23]
    6b90:	7103fc1f 	cmp	w0, #0xff
    6b94:	54009060 	b.eq	7da0 <f0+0x2390>  // b.none
    6b98:	52800020 	mov	w0, #0x1                   	// #1
    6b9c:	390002e0 	strb	w0, [x23]
    6ba0:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6ba4:	9112e3e0 	add	x0, sp, #0x4b8
    6ba8:	f9025fe1 	str	x1, [sp, #1208]
    6bac:	f90263f5 	str	x21, [sp, #1216]
    6bb0:	97fff254 	bl	3500 <fwp_data.part.0.constprop.0>
    6bb4:	97fff1bb 	bl	32a0 <fwp_rc_fresh>
    6bb8:	aa0003e1 	mov	x1, x0
    6bbc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6bc0:	911323e0 	add	x0, sp, #0x4c8
    6bc4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6bc8:	f90267e2 	str	x2, [sp, #1224]
    6bcc:	f9026be1 	str	x1, [sp, #1232]
    6bd0:	97fff24c 	bl	3500 <fwp_data.part.0.constprop.0>
    6bd4:	aa0003f5 	mov	x21, x0
    6bd8:	91144283 	add	x3, x20, #0x510
    6bdc:	f949d861 	ldr	x1, [x3, #5040]
    6be0:	f949ec60 	ldr	x0, [x3, #5080]
    6be4:	cb0102a1 	sub	x1, x21, x1
    6be8:	eb00403f 	cmp	x1, x0, lsl #16
    6bec:	54000322 	b.cs	6c50 <f0+0x1240>  // b.hs, b.nlast
    6bf0:	d350fc22 	lsr	x2, x1, #16
    6bf4:	f949fc63 	ldr	x3, [x3, #5112]
    6bf8:	8b020842 	add	x2, x2, x2, lsl #2
    6bfc:	d37df042 	lsl	x2, x2, #3
    6c00:	8b020060 	add	x0, x3, x2
    6c04:	f9401017 	ldr	x23, [x0, #32]
    6c08:	b4000257 	cbz	x23, 6c50 <f0+0x1240>
    6c0c:	38626862 	ldrb	w2, [x3, x2]
    6c10:	7100085f 	cmp	w2, #0x2
    6c14:	54007700 	b.eq	7af4 <f0+0x20e4>  // b.none
    6c18:	7100045f 	cmp	w2, #0x1
    6c1c:	540001a1 	b.ne	6c50 <f0+0x1240>  // b.any
    6c20:	29430002 	ldp	w2, w0, [x0, #24]
    6c24:	92403c21 	and	x1, x1, #0xffff
    6c28:	9b027c21 	mul	x1, x1, x2
    6c2c:	d360fc21 	lsr	x1, x1, #32
    6c30:	eb00003f 	cmp	x1, x0
    6c34:	540000e2 	b.cs	6c50 <f0+0x1240>  // b.hs, b.nlast
    6c38:	8b0102f7 	add	x23, x23, x1
    6c3c:	394002e0 	ldrb	w0, [x23]
    6c40:	7103fc1f 	cmp	w0, #0xff
    6c44:	54008b40 	b.eq	7dac <f0+0x239c>  // b.none
    6c48:	52800020 	mov	w0, #0x1                   	// #1
    6c4c:	390002e0 	strb	w0, [x23]
    6c50:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    6c54:	911363e0 	add	x0, sp, #0x4d8
    6c58:	f9026fe1 	str	x1, [sp, #1240]
    6c5c:	f90273f5 	str	x21, [sp, #1248]
    6c60:	97fff228 	bl	3500 <fwp_data.part.0.constprop.0>
    6c64:	91144283 	add	x3, x20, #0x510
    6c68:	aa0003f5 	mov	x21, x0
    6c6c:	f949d861 	ldr	x1, [x3, #5040]
    6c70:	f949ec60 	ldr	x0, [x3, #5080]
    6c74:	cb0102a1 	sub	x1, x21, x1
    6c78:	eb00403f 	cmp	x1, x0, lsl #16
    6c7c:	54000322 	b.cs	6ce0 <f0+0x12d0>  // b.hs, b.nlast
    6c80:	d350fc22 	lsr	x2, x1, #16
    6c84:	f949fc63 	ldr	x3, [x3, #5112]
    6c88:	8b020842 	add	x2, x2, x2, lsl #2
    6c8c:	d37df042 	lsl	x2, x2, #3
    6c90:	8b020060 	add	x0, x3, x2
    6c94:	f9401017 	ldr	x23, [x0, #32]
    6c98:	b4000257 	cbz	x23, 6ce0 <f0+0x12d0>
    6c9c:	38626862 	ldrb	w2, [x3, x2]
    6ca0:	7100085f 	cmp	w2, #0x2
    6ca4:	54007220 	b.eq	7ae8 <f0+0x20d8>  // b.none
    6ca8:	7100045f 	cmp	w2, #0x1
    6cac:	540001a1 	b.ne	6ce0 <f0+0x12d0>  // b.any
    6cb0:	29430002 	ldp	w2, w0, [x0, #24]
    6cb4:	92403c21 	and	x1, x1, #0xffff
    6cb8:	9b027c21 	mul	x1, x1, x2
    6cbc:	d360fc21 	lsr	x1, x1, #32
    6cc0:	eb00003f 	cmp	x1, x0
    6cc4:	540000e2 	b.cs	6ce0 <f0+0x12d0>  // b.hs, b.nlast
    6cc8:	8b0102f7 	add	x23, x23, x1
    6ccc:	394002e0 	ldrb	w0, [x23]
    6cd0:	7103fc1f 	cmp	w0, #0xff
    6cd4:	54008720 	b.eq	7db8 <f0+0x23a8>  // b.none
    6cd8:	52800020 	mov	w0, #0x1                   	// #1
    6cdc:	390002e0 	strb	w0, [x23]
    6ce0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    6ce4:	9113a3e0 	add	x0, sp, #0x4e8
    6ce8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    6cec:	f90277f7 	str	x23, [sp, #1256]
    6cf0:	f9027bf5 	str	x21, [sp, #1264]
    6cf4:	97fff203 	bl	3500 <fwp_data.part.0.constprop.0>
    6cf8:	97fff16a 	bl	32a0 <fwp_rc_fresh>
    6cfc:	aa0003e1 	mov	x1, x0
    6d00:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    6d04:	9113e3e0 	add	x0, sp, #0x4f8
    6d08:	f9027ff5 	str	x21, [sp, #1272]
    6d0c:	f90283e1 	str	x1, [sp, #1280]
    6d10:	97fff1fc 	bl	3500 <fwp_data.part.0.constprop.0>
    6d14:	97fff163 	bl	32a0 <fwp_rc_fresh>
    6d18:	aa0003e1 	mov	x1, x0
    6d1c:	911423e0 	add	x0, sp, #0x508
    6d20:	f90287f7 	str	x23, [sp, #1288]
    6d24:	f9028be1 	str	x1, [sp, #1296]
    6d28:	97fff1f6 	bl	3500 <fwp_data.part.0.constprop.0>
    6d2c:	97fff15d 	bl	32a0 <fwp_rc_fresh>
    6d30:	aa0003e1 	mov	x1, x0
    6d34:	911463e0 	add	x0, sp, #0x518
    6d38:	f9028ff5 	str	x21, [sp, #1304]
    6d3c:	f90293e1 	str	x1, [sp, #1312]
    6d40:	97fff1f0 	bl	3500 <fwp_data.part.0.constprop.0>
    6d44:	97fff157 	bl	32a0 <fwp_rc_fresh>
    6d48:	aa0003e1 	mov	x1, x0
    6d4c:	9114a3e0 	add	x0, sp, #0x528
    6d50:	f90297f7 	str	x23, [sp, #1320]
    6d54:	f9029be1 	str	x1, [sp, #1328]
    6d58:	97fff1ea 	bl	3500 <fwp_data.part.0.constprop.0>
    6d5c:	aa0003f5 	mov	x21, x0
    6d60:	91144283 	add	x3, x20, #0x510
    6d64:	f949d861 	ldr	x1, [x3, #5040]
    6d68:	f949ec60 	ldr	x0, [x3, #5080]
    6d6c:	cb0102a1 	sub	x1, x21, x1
    6d70:	eb00403f 	cmp	x1, x0, lsl #16
    6d74:	54000322 	b.cs	6dd8 <f0+0x13c8>  // b.hs, b.nlast
    6d78:	d350fc22 	lsr	x2, x1, #16
    6d7c:	f949fc63 	ldr	x3, [x3, #5112]
    6d80:	8b020842 	add	x2, x2, x2, lsl #2
    6d84:	d37df042 	lsl	x2, x2, #3
    6d88:	8b020060 	add	x0, x3, x2
    6d8c:	f9401017 	ldr	x23, [x0, #32]
    6d90:	b4000257 	cbz	x23, 6dd8 <f0+0x13c8>
    6d94:	38626862 	ldrb	w2, [x3, x2]
    6d98:	7100085f 	cmp	w2, #0x2
    6d9c:	54006a00 	b.eq	7adc <f0+0x20cc>  // b.none
    6da0:	7100045f 	cmp	w2, #0x1
    6da4:	540001a1 	b.ne	6dd8 <f0+0x13c8>  // b.any
    6da8:	29430002 	ldp	w2, w0, [x0, #24]
    6dac:	92403c21 	and	x1, x1, #0xffff
    6db0:	9b027c21 	mul	x1, x1, x2
    6db4:	d360fc21 	lsr	x1, x1, #32
    6db8:	eb00003f 	cmp	x1, x0
    6dbc:	540000e2 	b.cs	6dd8 <f0+0x13c8>  // b.hs, b.nlast
    6dc0:	8b0102f7 	add	x23, x23, x1
    6dc4:	394002e0 	ldrb	w0, [x23]
    6dc8:	7103fc1f 	cmp	w0, #0xff
    6dcc:	54007fc0 	b.eq	7dc4 <f0+0x23b4>  // b.none
    6dd0:	52800020 	mov	w0, #0x1                   	// #1
    6dd4:	390002e0 	strb	w0, [x23]
    6dd8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6ddc:	9114e3e0 	add	x0, sp, #0x538
    6de0:	f9029ff7 	str	x23, [sp, #1336]
    6de4:	f902a3f5 	str	x21, [sp, #1344]
    6de8:	97fff1c6 	bl	3500 <fwp_data.part.0.constprop.0>
    6dec:	97fff12d 	bl	32a0 <fwp_rc_fresh>
    6df0:	aa0003e1 	mov	x1, x0
    6df4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    6df8:	911523e0 	add	x0, sp, #0x548
    6dfc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    6e00:	f902a7f5 	str	x21, [sp, #1352]
    6e04:	f902abe1 	str	x1, [sp, #1360]
    6e08:	97fff1be 	bl	3500 <fwp_data.part.0.constprop.0>
    6e0c:	97fff125 	bl	32a0 <fwp_rc_fresh>
    6e10:	aa0003e1 	mov	x1, x0
    6e14:	911563e0 	add	x0, sp, #0x558
    6e18:	f902aff7 	str	x23, [sp, #1368]
    6e1c:	f902b3e1 	str	x1, [sp, #1376]
    6e20:	97fff1b8 	bl	3500 <fwp_data.part.0.constprop.0>
    6e24:	97fff11f 	bl	32a0 <fwp_rc_fresh>
    6e28:	aa0003e1 	mov	x1, x0
    6e2c:	9115a3e0 	add	x0, sp, #0x568
    6e30:	f902b7f5 	str	x21, [sp, #1384]
    6e34:	f902bbe1 	str	x1, [sp, #1392]
    6e38:	97fff1b2 	bl	3500 <fwp_data.part.0.constprop.0>
    6e3c:	97fff119 	bl	32a0 <fwp_rc_fresh>
    6e40:	aa0003e1 	mov	x1, x0
    6e44:	9115e3e0 	add	x0, sp, #0x578
    6e48:	f902bff7 	str	x23, [sp, #1400]
    6e4c:	f902c3e1 	str	x1, [sp, #1408]
    6e50:	97fff1ac 	bl	3500 <fwp_data.part.0.constprop.0>
    6e54:	97fff113 	bl	32a0 <fwp_rc_fresh>
    6e58:	aa0003e1 	mov	x1, x0
    6e5c:	911623e0 	add	x0, sp, #0x588
    6e60:	f902c7f5 	str	x21, [sp, #1416]
    6e64:	f902cbe1 	str	x1, [sp, #1424]
    6e68:	97fff1a6 	bl	3500 <fwp_data.part.0.constprop.0>
    6e6c:	97fff10d 	bl	32a0 <fwp_rc_fresh>
    6e70:	aa0003e1 	mov	x1, x0
    6e74:	911663e0 	add	x0, sp, #0x598
    6e78:	f902cff7 	str	x23, [sp, #1432]
    6e7c:	f902d3e1 	str	x1, [sp, #1440]
    6e80:	97fff1a0 	bl	3500 <fwp_data.part.0.constprop.0>
    6e84:	97fff107 	bl	32a0 <fwp_rc_fresh>
    6e88:	aa0003e1 	mov	x1, x0
    6e8c:	9116a3e0 	add	x0, sp, #0x5a8
    6e90:	f902d7f5 	str	x21, [sp, #1448]
    6e94:	f902dbe1 	str	x1, [sp, #1456]
    6e98:	97fff19a 	bl	3500 <fwp_data.part.0.constprop.0>
    6e9c:	aa0003f5 	mov	x21, x0
    6ea0:	91144283 	add	x3, x20, #0x510
    6ea4:	f949d861 	ldr	x1, [x3, #5040]
    6ea8:	f949ec60 	ldr	x0, [x3, #5080]
    6eac:	cb0102a1 	sub	x1, x21, x1
    6eb0:	eb00403f 	cmp	x1, x0, lsl #16
    6eb4:	54000322 	b.cs	6f18 <f0+0x1508>  // b.hs, b.nlast
    6eb8:	d350fc22 	lsr	x2, x1, #16
    6ebc:	f949fc63 	ldr	x3, [x3, #5112]
    6ec0:	8b020842 	add	x2, x2, x2, lsl #2
    6ec4:	d37df042 	lsl	x2, x2, #3
    6ec8:	8b020060 	add	x0, x3, x2
    6ecc:	f9401017 	ldr	x23, [x0, #32]
    6ed0:	b4000257 	cbz	x23, 6f18 <f0+0x1508>
    6ed4:	38626862 	ldrb	w2, [x3, x2]
    6ed8:	7100085f 	cmp	w2, #0x2
    6edc:	54006e40 	b.eq	7ca4 <f0+0x2294>  // b.none
    6ee0:	7100045f 	cmp	w2, #0x1
    6ee4:	540001a1 	b.ne	6f18 <f0+0x1508>  // b.any
    6ee8:	29430002 	ldp	w2, w0, [x0, #24]
    6eec:	92403c21 	and	x1, x1, #0xffff
    6ef0:	9b027c21 	mul	x1, x1, x2
    6ef4:	d360fc21 	lsr	x1, x1, #32
    6ef8:	eb00003f 	cmp	x1, x0
    6efc:	540000e2 	b.cs	6f18 <f0+0x1508>  // b.hs, b.nlast
    6f00:	8b0102f7 	add	x23, x23, x1
    6f04:	394002e0 	ldrb	w0, [x23]
    6f08:	7103fc1f 	cmp	w0, #0xff
    6f0c:	54007620 	b.eq	7dd0 <f0+0x23c0>  // b.none
    6f10:	52800020 	mov	w0, #0x1                   	// #1
    6f14:	390002e0 	strb	w0, [x23]
    6f18:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    6f1c:	9116e3e0 	add	x0, sp, #0x5b8
    6f20:	f902dff7 	str	x23, [sp, #1464]
    6f24:	f902e3f5 	str	x21, [sp, #1472]
    6f28:	97fff176 	bl	3500 <fwp_data.part.0.constprop.0>
    6f2c:	97fff0dd 	bl	32a0 <fwp_rc_fresh>
    6f30:	aa0003e1 	mov	x1, x0
    6f34:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6f38:	911723e0 	add	x0, sp, #0x5c8
    6f3c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6f40:	f902e7e2 	str	x2, [sp, #1480]
    6f44:	f902ebe1 	str	x1, [sp, #1488]
    6f48:	97fff16e 	bl	3500 <fwp_data.part.0.constprop.0>
    6f4c:	97fff0d5 	bl	32a0 <fwp_rc_fresh>
    6f50:	aa0003e1 	mov	x1, x0
    6f54:	911763e0 	add	x0, sp, #0x5d8
    6f58:	f902eff7 	str	x23, [sp, #1496]
    6f5c:	f902f3e1 	str	x1, [sp, #1504]
    6f60:	97fff168 	bl	3500 <fwp_data.part.0.constprop.0>
    6f64:	aa0003f5 	mov	x21, x0
    6f68:	91144283 	add	x3, x20, #0x510
    6f6c:	f949d861 	ldr	x1, [x3, #5040]
    6f70:	f949ec60 	ldr	x0, [x3, #5080]
    6f74:	cb0102a1 	sub	x1, x21, x1
    6f78:	eb00403f 	cmp	x1, x0, lsl #16
    6f7c:	54000322 	b.cs	6fe0 <f0+0x15d0>  // b.hs, b.nlast
    6f80:	d350fc22 	lsr	x2, x1, #16
    6f84:	f949fc63 	ldr	x3, [x3, #5112]
    6f88:	8b020842 	add	x2, x2, x2, lsl #2
    6f8c:	d37df042 	lsl	x2, x2, #3
    6f90:	8b020060 	add	x0, x3, x2
    6f94:	f9401017 	ldr	x23, [x0, #32]
    6f98:	b4000257 	cbz	x23, 6fe0 <f0+0x15d0>
    6f9c:	38626862 	ldrb	w2, [x3, x2]
    6fa0:	7100085f 	cmp	w2, #0x2
    6fa4:	540067a0 	b.eq	7c98 <f0+0x2288>  // b.none
    6fa8:	7100045f 	cmp	w2, #0x1
    6fac:	540001a1 	b.ne	6fe0 <f0+0x15d0>  // b.any
    6fb0:	29430002 	ldp	w2, w0, [x0, #24]
    6fb4:	92403c21 	and	x1, x1, #0xffff
    6fb8:	9b027c21 	mul	x1, x1, x2
    6fbc:	d360fc21 	lsr	x1, x1, #32
    6fc0:	eb00003f 	cmp	x1, x0
    6fc4:	540000e2 	b.cs	6fe0 <f0+0x15d0>  // b.hs, b.nlast
    6fc8:	8b0102f7 	add	x23, x23, x1
    6fcc:	394002e0 	ldrb	w0, [x23]
    6fd0:	7103fc1f 	cmp	w0, #0xff
    6fd4:	54007040 	b.eq	7ddc <f0+0x23cc>  // b.none
    6fd8:	52800020 	mov	w0, #0x1                   	// #1
    6fdc:	390002e0 	strb	w0, [x23]
    6fe0:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    6fe4:	9117a3e0 	add	x0, sp, #0x5e8
    6fe8:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    6fec:	f902f7e1 	str	x1, [sp, #1512]
    6ff0:	f902fbf5 	str	x21, [sp, #1520]
    6ff4:	97fff143 	bl	3500 <fwp_data.part.0.constprop.0>
    6ff8:	aa0003f5 	mov	x21, x0
    6ffc:	91144283 	add	x3, x20, #0x510
    7000:	f949d861 	ldr	x1, [x3, #5040]
    7004:	f949ec60 	ldr	x0, [x3, #5080]
    7008:	cb0102a1 	sub	x1, x21, x1
    700c:	eb00403f 	cmp	x1, x0, lsl #16
    7010:	54000322 	b.cs	7074 <f0+0x1664>  // b.hs, b.nlast
    7014:	d350fc22 	lsr	x2, x1, #16
    7018:	f949fc63 	ldr	x3, [x3, #5112]
    701c:	8b020842 	add	x2, x2, x2, lsl #2
    7020:	d37df042 	lsl	x2, x2, #3
    7024:	8b020060 	add	x0, x3, x2
    7028:	f9401017 	ldr	x23, [x0, #32]
    702c:	b4000257 	cbz	x23, 7074 <f0+0x1664>
    7030:	38626862 	ldrb	w2, [x3, x2]
    7034:	7100085f 	cmp	w2, #0x2
    7038:	540062a0 	b.eq	7c8c <f0+0x227c>  // b.none
    703c:	7100045f 	cmp	w2, #0x1
    7040:	540001a1 	b.ne	7074 <f0+0x1664>  // b.any
    7044:	29430002 	ldp	w2, w0, [x0, #24]
    7048:	92403c21 	and	x1, x1, #0xffff
    704c:	9b027c21 	mul	x1, x1, x2
    7050:	d360fc21 	lsr	x1, x1, #32
    7054:	eb00003f 	cmp	x1, x0
    7058:	540000e2 	b.cs	7074 <f0+0x1664>  // b.hs, b.nlast
    705c:	8b0102f7 	add	x23, x23, x1
    7060:	394002e0 	ldrb	w0, [x23]
    7064:	7103fc1f 	cmp	w0, #0xff
    7068:	54006c00 	b.eq	7de8 <f0+0x23d8>  // b.none
    706c:	52800020 	mov	w0, #0x1                   	// #1
    7070:	390002e0 	strb	w0, [x23]
    7074:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7078:	9117e3e0 	add	x0, sp, #0x5f8
    707c:	f902fff7 	str	x23, [sp, #1528]
    7080:	f90303f5 	str	x21, [sp, #1536]
    7084:	97fff11f 	bl	3500 <fwp_data.part.0.constprop.0>
    7088:	97fff086 	bl	32a0 <fwp_rc_fresh>
    708c:	aa0003e1 	mov	x1, x0
    7090:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    7094:	911823e0 	add	x0, sp, #0x608
    7098:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    709c:	f90307f5 	str	x21, [sp, #1544]
    70a0:	f9030be1 	str	x1, [sp, #1552]
    70a4:	97fff117 	bl	3500 <fwp_data.part.0.constprop.0>
    70a8:	97fff07e 	bl	32a0 <fwp_rc_fresh>
    70ac:	aa0003e1 	mov	x1, x0
    70b0:	911863e0 	add	x0, sp, #0x618
    70b4:	f9030ff7 	str	x23, [sp, #1560]
    70b8:	f90313e1 	str	x1, [sp, #1568]
    70bc:	97fff111 	bl	3500 <fwp_data.part.0.constprop.0>
    70c0:	97fff078 	bl	32a0 <fwp_rc_fresh>
    70c4:	aa0003e1 	mov	x1, x0
    70c8:	9118a3e0 	add	x0, sp, #0x628
    70cc:	f90317f5 	str	x21, [sp, #1576]
    70d0:	f9031be1 	str	x1, [sp, #1584]
    70d4:	97fff10b 	bl	3500 <fwp_data.part.0.constprop.0>
    70d8:	97fff072 	bl	32a0 <fwp_rc_fresh>
    70dc:	aa0003e1 	mov	x1, x0
    70e0:	9118e3e0 	add	x0, sp, #0x638
    70e4:	f9031ff7 	str	x23, [sp, #1592]
    70e8:	f90323e1 	str	x1, [sp, #1600]
    70ec:	97fff105 	bl	3500 <fwp_data.part.0.constprop.0>
    70f0:	97fff06c 	bl	32a0 <fwp_rc_fresh>
    70f4:	aa0003e1 	mov	x1, x0
    70f8:	911923e0 	add	x0, sp, #0x648
    70fc:	f90327f5 	str	x21, [sp, #1608]
    7100:	f9032be1 	str	x1, [sp, #1616]
    7104:	97fff0ff 	bl	3500 <fwp_data.part.0.constprop.0>
    7108:	97fff066 	bl	32a0 <fwp_rc_fresh>
    710c:	aa0003e1 	mov	x1, x0
    7110:	911963e0 	add	x0, sp, #0x658
    7114:	f9032ff7 	str	x23, [sp, #1624]
    7118:	f90333e1 	str	x1, [sp, #1632]
    711c:	97fff0f9 	bl	3500 <fwp_data.part.0.constprop.0>
    7120:	97fff060 	bl	32a0 <fwp_rc_fresh>
    7124:	aa0003e1 	mov	x1, x0
    7128:	9119a3e0 	add	x0, sp, #0x668
    712c:	f90337f5 	str	x21, [sp, #1640]
    7130:	f9033be1 	str	x1, [sp, #1648]
    7134:	97fff0f3 	bl	3500 <fwp_data.part.0.constprop.0>
    7138:	aa0003f5 	mov	x21, x0
    713c:	91144283 	add	x3, x20, #0x510
    7140:	f949d861 	ldr	x1, [x3, #5040]
    7144:	f949ec60 	ldr	x0, [x3, #5080]
    7148:	cb0102a1 	sub	x1, x21, x1
    714c:	eb00403f 	cmp	x1, x0, lsl #16
    7150:	54000322 	b.cs	71b4 <f0+0x17a4>  // b.hs, b.nlast
    7154:	d350fc22 	lsr	x2, x1, #16
    7158:	f949fc63 	ldr	x3, [x3, #5112]
    715c:	8b020842 	add	x2, x2, x2, lsl #2
    7160:	d37df042 	lsl	x2, x2, #3
    7164:	8b020060 	add	x0, x3, x2
    7168:	f9401017 	ldr	x23, [x0, #32]
    716c:	b4000257 	cbz	x23, 71b4 <f0+0x17a4>
    7170:	38626862 	ldrb	w2, [x3, x2]
    7174:	7100085f 	cmp	w2, #0x2
    7178:	54005840 	b.eq	7c80 <f0+0x2270>  // b.none
    717c:	7100045f 	cmp	w2, #0x1
    7180:	540001a1 	b.ne	71b4 <f0+0x17a4>  // b.any
    7184:	29430002 	ldp	w2, w0, [x0, #24]
    7188:	92403c21 	and	x1, x1, #0xffff
    718c:	9b027c21 	mul	x1, x1, x2
    7190:	d360fc21 	lsr	x1, x1, #32
    7194:	eb00003f 	cmp	x1, x0
    7198:	540000e2 	b.cs	71b4 <f0+0x17a4>  // b.hs, b.nlast
    719c:	8b0102f7 	add	x23, x23, x1
    71a0:	394002e0 	ldrb	w0, [x23]
    71a4:	7103fc1f 	cmp	w0, #0xff
    71a8:	54006260 	b.eq	7df4 <f0+0x23e4>  // b.none
    71ac:	52800020 	mov	w0, #0x1                   	// #1
    71b0:	390002e0 	strb	w0, [x23]
    71b4:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    71b8:	9119e3e0 	add	x0, sp, #0x678
    71bc:	f9033fe1 	str	x1, [sp, #1656]
    71c0:	f90343f5 	str	x21, [sp, #1664]
    71c4:	97fff0cf 	bl	3500 <fwp_data.part.0.constprop.0>
    71c8:	97fff036 	bl	32a0 <fwp_rc_fresh>
    71cc:	aa0003e1 	mov	x1, x0
    71d0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    71d4:	911a23e0 	add	x0, sp, #0x688
    71d8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    71dc:	f90347e2 	str	x2, [sp, #1672]
    71e0:	f9034be1 	str	x1, [sp, #1680]
    71e4:	97fff0c7 	bl	3500 <fwp_data.part.0.constprop.0>
    71e8:	aa0003f5 	mov	x21, x0
    71ec:	91144283 	add	x3, x20, #0x510
    71f0:	f949d861 	ldr	x1, [x3, #5040]
    71f4:	f949ec60 	ldr	x0, [x3, #5080]
    71f8:	cb0102a1 	sub	x1, x21, x1
    71fc:	eb00403f 	cmp	x1, x0, lsl #16
    7200:	54000322 	b.cs	7264 <f0+0x1854>  // b.hs, b.nlast
    7204:	d350fc22 	lsr	x2, x1, #16
    7208:	f949fc63 	ldr	x3, [x3, #5112]
    720c:	8b020842 	add	x2, x2, x2, lsl #2
    7210:	d37df042 	lsl	x2, x2, #3
    7214:	8b020060 	add	x0, x3, x2
    7218:	f9401017 	ldr	x23, [x0, #32]
    721c:	b4000257 	cbz	x23, 7264 <f0+0x1854>
    7220:	38626862 	ldrb	w2, [x3, x2]
    7224:	7100085f 	cmp	w2, #0x2
    7228:	54005260 	b.eq	7c74 <f0+0x2264>  // b.none
    722c:	7100045f 	cmp	w2, #0x1
    7230:	540001a1 	b.ne	7264 <f0+0x1854>  // b.any
    7234:	29430002 	ldp	w2, w0, [x0, #24]
    7238:	92403c21 	and	x1, x1, #0xffff
    723c:	9b027c21 	mul	x1, x1, x2
    7240:	d360fc21 	lsr	x1, x1, #32
    7244:	eb00003f 	cmp	x1, x0
    7248:	540000e2 	b.cs	7264 <f0+0x1854>  // b.hs, b.nlast
    724c:	8b0102f7 	add	x23, x23, x1
    7250:	394002e0 	ldrb	w0, [x23]
    7254:	7103fc1f 	cmp	w0, #0xff
    7258:	54005d40 	b.eq	7e00 <f0+0x23f0>  // b.none
    725c:	52800020 	mov	w0, #0x1                   	// #1
    7260:	390002e0 	strb	w0, [x23]
    7264:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    7268:	911a63e0 	add	x0, sp, #0x698
    726c:	f9034fe1 	str	x1, [sp, #1688]
    7270:	f90353f5 	str	x21, [sp, #1696]
    7274:	97fff0a3 	bl	3500 <fwp_data.part.0.constprop.0>
    7278:	97fff00a 	bl	32a0 <fwp_rc_fresh>
    727c:	aa0003e1 	mov	x1, x0
    7280:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7284:	911aa3e0 	add	x0, sp, #0x6a8
    7288:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    728c:	f90357e2 	str	x2, [sp, #1704]
    7290:	f9035be1 	str	x1, [sp, #1712]
    7294:	97fff09b 	bl	3500 <fwp_data.part.0.constprop.0>
    7298:	aa0003f5 	mov	x21, x0
    729c:	91144283 	add	x3, x20, #0x510
    72a0:	f949d861 	ldr	x1, [x3, #5040]
    72a4:	f949ec60 	ldr	x0, [x3, #5080]
    72a8:	cb0102a1 	sub	x1, x21, x1
    72ac:	eb00403f 	cmp	x1, x0, lsl #16
    72b0:	54000322 	b.cs	7314 <f0+0x1904>  // b.hs, b.nlast
    72b4:	d350fc22 	lsr	x2, x1, #16
    72b8:	f949fc63 	ldr	x3, [x3, #5112]
    72bc:	8b020842 	add	x2, x2, x2, lsl #2
    72c0:	d37df042 	lsl	x2, x2, #3
    72c4:	8b020060 	add	x0, x3, x2
    72c8:	f9401017 	ldr	x23, [x0, #32]
    72cc:	b4000257 	cbz	x23, 7314 <f0+0x1904>
    72d0:	38626862 	ldrb	w2, [x3, x2]
    72d4:	7100085f 	cmp	w2, #0x2
    72d8:	54004c80 	b.eq	7c68 <f0+0x2258>  // b.none
    72dc:	7100045f 	cmp	w2, #0x1
    72e0:	540001a1 	b.ne	7314 <f0+0x1904>  // b.any
    72e4:	29430002 	ldp	w2, w0, [x0, #24]
    72e8:	92403c21 	and	x1, x1, #0xffff
    72ec:	9b027c21 	mul	x1, x1, x2
    72f0:	d360fc21 	lsr	x1, x1, #32
    72f4:	eb00003f 	cmp	x1, x0
    72f8:	540000e2 	b.cs	7314 <f0+0x1904>  // b.hs, b.nlast
    72fc:	8b0102f7 	add	x23, x23, x1
    7300:	394002e0 	ldrb	w0, [x23]
    7304:	7103fc1f 	cmp	w0, #0xff
    7308:	54005820 	b.eq	7e0c <f0+0x23fc>  // b.none
    730c:	52800020 	mov	w0, #0x1                   	// #1
    7310:	390002e0 	strb	w0, [x23]
    7314:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    7318:	911ae3e0 	add	x0, sp, #0x6b8
    731c:	f9035fe1 	str	x1, [sp, #1720]
    7320:	f90363f5 	str	x21, [sp, #1728]
    7324:	97fff077 	bl	3500 <fwp_data.part.0.constprop.0>
    7328:	97ffefde 	bl	32a0 <fwp_rc_fresh>
    732c:	aa0003e1 	mov	x1, x0
    7330:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7334:	911b23e0 	add	x0, sp, #0x6c8
    7338:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    733c:	f90367e2 	str	x2, [sp, #1736]
    7340:	f9036be1 	str	x1, [sp, #1744]
    7344:	97fff06f 	bl	3500 <fwp_data.part.0.constprop.0>
    7348:	aa0003f5 	mov	x21, x0
    734c:	91144283 	add	x3, x20, #0x510
    7350:	f949d861 	ldr	x1, [x3, #5040]
    7354:	f949ec60 	ldr	x0, [x3, #5080]
    7358:	cb0102a1 	sub	x1, x21, x1
    735c:	eb00403f 	cmp	x1, x0, lsl #16
    7360:	54000322 	b.cs	73c4 <f0+0x19b4>  // b.hs, b.nlast
    7364:	d350fc22 	lsr	x2, x1, #16
    7368:	f949fc63 	ldr	x3, [x3, #5112]
    736c:	8b020842 	add	x2, x2, x2, lsl #2
    7370:	d37df042 	lsl	x2, x2, #3
    7374:	8b020060 	add	x0, x3, x2
    7378:	f9401017 	ldr	x23, [x0, #32]
    737c:	b4000257 	cbz	x23, 73c4 <f0+0x19b4>
    7380:	38626862 	ldrb	w2, [x3, x2]
    7384:	7100085f 	cmp	w2, #0x2
    7388:	540046a0 	b.eq	7c5c <f0+0x224c>  // b.none
    738c:	7100045f 	cmp	w2, #0x1
    7390:	540001a1 	b.ne	73c4 <f0+0x19b4>  // b.any
    7394:	29430002 	ldp	w2, w0, [x0, #24]
    7398:	92403c21 	and	x1, x1, #0xffff
    739c:	9b027c21 	mul	x1, x1, x2
    73a0:	d360fc21 	lsr	x1, x1, #32
    73a4:	eb00003f 	cmp	x1, x0
    73a8:	540000e2 	b.cs	73c4 <f0+0x19b4>  // b.hs, b.nlast
    73ac:	8b0102f7 	add	x23, x23, x1
    73b0:	394002e0 	ldrb	w0, [x23]
    73b4:	7103fc1f 	cmp	w0, #0xff
    73b8:	54005300 	b.eq	7e18 <f0+0x2408>  // b.none
    73bc:	52800020 	mov	w0, #0x1                   	// #1
    73c0:	390002e0 	strb	w0, [x23]
    73c4:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    73c8:	911b63e0 	add	x0, sp, #0x6d8
    73cc:	f9036fe1 	str	x1, [sp, #1752]
    73d0:	f90373f5 	str	x21, [sp, #1760]
    73d4:	97fff04b 	bl	3500 <fwp_data.part.0.constprop.0>
    73d8:	91144283 	add	x3, x20, #0x510
    73dc:	aa0003f5 	mov	x21, x0
    73e0:	f949d861 	ldr	x1, [x3, #5040]
    73e4:	f949ec60 	ldr	x0, [x3, #5080]
    73e8:	cb0102a1 	sub	x1, x21, x1
    73ec:	eb00403f 	cmp	x1, x0, lsl #16
    73f0:	54000322 	b.cs	7454 <f0+0x1a44>  // b.hs, b.nlast
    73f4:	d350fc22 	lsr	x2, x1, #16
    73f8:	f949fc63 	ldr	x3, [x3, #5112]
    73fc:	8b020842 	add	x2, x2, x2, lsl #2
    7400:	d37df042 	lsl	x2, x2, #3
    7404:	8b020060 	add	x0, x3, x2
    7408:	f9401017 	ldr	x23, [x0, #32]
    740c:	b4000257 	cbz	x23, 7454 <f0+0x1a44>
    7410:	38626862 	ldrb	w2, [x3, x2]
    7414:	7100085f 	cmp	w2, #0x2
    7418:	540041c0 	b.eq	7c50 <f0+0x2240>  // b.none
    741c:	7100045f 	cmp	w2, #0x1
    7420:	540001a1 	b.ne	7454 <f0+0x1a44>  // b.any
    7424:	29430002 	ldp	w2, w0, [x0, #24]
    7428:	92403c21 	and	x1, x1, #0xffff
    742c:	9b027c21 	mul	x1, x1, x2
    7430:	d360fc21 	lsr	x1, x1, #32
    7434:	eb00003f 	cmp	x1, x0
    7438:	540000e2 	b.cs	7454 <f0+0x1a44>  // b.hs, b.nlast
    743c:	8b0102f7 	add	x23, x23, x1
    7440:	394002e0 	ldrb	w0, [x23]
    7444:	7103fc1f 	cmp	w0, #0xff
    7448:	54004ee0 	b.eq	7e24 <f0+0x2414>  // b.none
    744c:	52800020 	mov	w0, #0x1                   	// #1
    7450:	390002e0 	strb	w0, [x23]
    7454:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7458:	911ba3e0 	add	x0, sp, #0x6e8
    745c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7460:	f90377f7 	str	x23, [sp, #1768]
    7464:	f9037bf5 	str	x21, [sp, #1776]
    7468:	97fff026 	bl	3500 <fwp_data.part.0.constprop.0>
    746c:	97ffef8d 	bl	32a0 <fwp_rc_fresh>
    7470:	aa0003e1 	mov	x1, x0
    7474:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7478:	911be3e0 	add	x0, sp, #0x6f8
    747c:	f9037ff5 	str	x21, [sp, #1784]
    7480:	f90383e1 	str	x1, [sp, #1792]
    7484:	97fff01f 	bl	3500 <fwp_data.part.0.constprop.0>
    7488:	97ffef86 	bl	32a0 <fwp_rc_fresh>
    748c:	aa0003e1 	mov	x1, x0
    7490:	911c23e0 	add	x0, sp, #0x708
    7494:	f90387f7 	str	x23, [sp, #1800]
    7498:	f9038be1 	str	x1, [sp, #1808]
    749c:	97fff019 	bl	3500 <fwp_data.part.0.constprop.0>
    74a0:	97ffef80 	bl	32a0 <fwp_rc_fresh>
    74a4:	aa0003e1 	mov	x1, x0
    74a8:	911c63e0 	add	x0, sp, #0x718
    74ac:	f9038ff5 	str	x21, [sp, #1816]
    74b0:	f90393e1 	str	x1, [sp, #1824]
    74b4:	97fff013 	bl	3500 <fwp_data.part.0.constprop.0>
    74b8:	97ffef7a 	bl	32a0 <fwp_rc_fresh>
    74bc:	aa0003e1 	mov	x1, x0
    74c0:	911ca3e0 	add	x0, sp, #0x728
    74c4:	f90397f7 	str	x23, [sp, #1832]
    74c8:	f9039be1 	str	x1, [sp, #1840]
    74cc:	97fff00d 	bl	3500 <fwp_data.part.0.constprop.0>
    74d0:	aa0003f5 	mov	x21, x0
    74d4:	91144283 	add	x3, x20, #0x510
    74d8:	f949d861 	ldr	x1, [x3, #5040]
    74dc:	f949ec60 	ldr	x0, [x3, #5080]
    74e0:	cb0102a1 	sub	x1, x21, x1
    74e4:	eb00403f 	cmp	x1, x0, lsl #16
    74e8:	54000322 	b.cs	754c <f0+0x1b3c>  // b.hs, b.nlast
    74ec:	d350fc22 	lsr	x2, x1, #16
    74f0:	f949fc63 	ldr	x3, [x3, #5112]
    74f4:	8b020842 	add	x2, x2, x2, lsl #2
    74f8:	d37df042 	lsl	x2, x2, #3
    74fc:	8b020060 	add	x0, x3, x2
    7500:	f9401017 	ldr	x23, [x0, #32]
    7504:	b4000257 	cbz	x23, 754c <f0+0x1b3c>
    7508:	38626862 	ldrb	w2, [x3, x2]
    750c:	7100085f 	cmp	w2, #0x2
    7510:	540039a0 	b.eq	7c44 <f0+0x2234>  // b.none
    7514:	7100045f 	cmp	w2, #0x1
    7518:	540001a1 	b.ne	754c <f0+0x1b3c>  // b.any
    751c:	29430002 	ldp	w2, w0, [x0, #24]
    7520:	92403c21 	and	x1, x1, #0xffff
    7524:	9b027c21 	mul	x1, x1, x2
    7528:	d360fc21 	lsr	x1, x1, #32
    752c:	eb00003f 	cmp	x1, x0
    7530:	540000e2 	b.cs	754c <f0+0x1b3c>  // b.hs, b.nlast
    7534:	8b0102f7 	add	x23, x23, x1
    7538:	394002e0 	ldrb	w0, [x23]
    753c:	7103fc1f 	cmp	w0, #0xff
    7540:	54004780 	b.eq	7e30 <f0+0x2420>  // b.none
    7544:	52800020 	mov	w0, #0x1                   	// #1
    7548:	390002e0 	strb	w0, [x23]
    754c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7550:	911ce3e0 	add	x0, sp, #0x738
    7554:	f9039ff7 	str	x23, [sp, #1848]
    7558:	f903a3f5 	str	x21, [sp, #1856]
    755c:	97ffefe9 	bl	3500 <fwp_data.part.0.constprop.0>
    7560:	97ffef50 	bl	32a0 <fwp_rc_fresh>
    7564:	aa0003e1 	mov	x1, x0
    7568:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    756c:	911d23e0 	add	x0, sp, #0x748
    7570:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    7574:	f903a7f5 	str	x21, [sp, #1864]
    7578:	f903abe1 	str	x1, [sp, #1872]
    757c:	97ffefe1 	bl	3500 <fwp_data.part.0.constprop.0>
    7580:	97ffef48 	bl	32a0 <fwp_rc_fresh>
    7584:	aa0003e1 	mov	x1, x0
    7588:	911d63e0 	add	x0, sp, #0x758
    758c:	f903aff7 	str	x23, [sp, #1880]
    7590:	f903b3e1 	str	x1, [sp, #1888]
    7594:	97ffefdb 	bl	3500 <fwp_data.part.0.constprop.0>
    7598:	97ffef42 	bl	32a0 <fwp_rc_fresh>
    759c:	aa0003e1 	mov	x1, x0
    75a0:	911da3e0 	add	x0, sp, #0x768
    75a4:	f903b7f5 	str	x21, [sp, #1896]
    75a8:	f903bbe1 	str	x1, [sp, #1904]
    75ac:	97ffefd5 	bl	3500 <fwp_data.part.0.constprop.0>
    75b0:	97ffef3c 	bl	32a0 <fwp_rc_fresh>
    75b4:	aa0003e1 	mov	x1, x0
    75b8:	911de3e0 	add	x0, sp, #0x778
    75bc:	f903bff7 	str	x23, [sp, #1912]
    75c0:	f903c3e1 	str	x1, [sp, #1920]
    75c4:	97ffefcf 	bl	3500 <fwp_data.part.0.constprop.0>
    75c8:	97ffef36 	bl	32a0 <fwp_rc_fresh>
    75cc:	aa0003e1 	mov	x1, x0
    75d0:	911e23e0 	add	x0, sp, #0x788
    75d4:	f903c7f5 	str	x21, [sp, #1928]
    75d8:	f903cbe1 	str	x1, [sp, #1936]
    75dc:	97ffefc9 	bl	3500 <fwp_data.part.0.constprop.0>
    75e0:	97ffef30 	bl	32a0 <fwp_rc_fresh>
    75e4:	aa0003e1 	mov	x1, x0
    75e8:	911e63e0 	add	x0, sp, #0x798
    75ec:	f903cff7 	str	x23, [sp, #1944]
    75f0:	f903d3e1 	str	x1, [sp, #1952]
    75f4:	97ffefc3 	bl	3500 <fwp_data.part.0.constprop.0>
    75f8:	97ffef2a 	bl	32a0 <fwp_rc_fresh>
    75fc:	aa0003e1 	mov	x1, x0
    7600:	911ea3e0 	add	x0, sp, #0x7a8
    7604:	f903d7f5 	str	x21, [sp, #1960]
    7608:	f903dbe1 	str	x1, [sp, #1968]
    760c:	97ffefbd 	bl	3500 <fwp_data.part.0.constprop.0>
    7610:	aa0003f5 	mov	x21, x0
    7614:	91144283 	add	x3, x20, #0x510
    7618:	f949d861 	ldr	x1, [x3, #5040]
    761c:	f949ec60 	ldr	x0, [x3, #5080]
    7620:	cb0102a1 	sub	x1, x21, x1
    7624:	eb00403f 	cmp	x1, x0, lsl #16
    7628:	54000322 	b.cs	768c <f0+0x1c7c>  // b.hs, b.nlast
    762c:	d350fc22 	lsr	x2, x1, #16
    7630:	f949fc63 	ldr	x3, [x3, #5112]
    7634:	8b020842 	add	x2, x2, x2, lsl #2
    7638:	d37df042 	lsl	x2, x2, #3
    763c:	8b020060 	add	x0, x3, x2
    7640:	f9401017 	ldr	x23, [x0, #32]
    7644:	b4000257 	cbz	x23, 768c <f0+0x1c7c>
    7648:	38626862 	ldrb	w2, [x3, x2]
    764c:	7100085f 	cmp	w2, #0x2
    7650:	54002f40 	b.eq	7c38 <f0+0x2228>  // b.none
    7654:	7100045f 	cmp	w2, #0x1
    7658:	540001a1 	b.ne	768c <f0+0x1c7c>  // b.any
    765c:	29430002 	ldp	w2, w0, [x0, #24]
    7660:	92403c21 	and	x1, x1, #0xffff
    7664:	9b027c21 	mul	x1, x1, x2
    7668:	d360fc21 	lsr	x1, x1, #32
    766c:	eb00003f 	cmp	x1, x0
    7670:	540000e2 	b.cs	768c <f0+0x1c7c>  // b.hs, b.nlast
    7674:	8b0102f7 	add	x23, x23, x1
    7678:	394002e0 	ldrb	w0, [x23]
    767c:	7103fc1f 	cmp	w0, #0xff
    7680:	54003de0 	b.eq	7e3c <f0+0x242c>  // b.none
    7684:	52800020 	mov	w0, #0x1                   	// #1
    7688:	390002e0 	strb	w0, [x23]
    768c:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    7690:	911ee3e0 	add	x0, sp, #0x7b8
    7694:	f903dfe1 	str	x1, [sp, #1976]
    7698:	f903e3f5 	str	x21, [sp, #1984]
    769c:	97ffef99 	bl	3500 <fwp_data.part.0.constprop.0>
    76a0:	97ffef00 	bl	32a0 <fwp_rc_fresh>
    76a4:	aa0003e1 	mov	x1, x0
    76a8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    76ac:	911f23e0 	add	x0, sp, #0x7c8
    76b0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    76b4:	f903e7e2 	str	x2, [sp, #1992]
    76b8:	f903ebe1 	str	x1, [sp, #2000]
    76bc:	97ffef91 	bl	3500 <fwp_data.part.0.constprop.0>
    76c0:	aa0003f5 	mov	x21, x0
    76c4:	91144283 	add	x3, x20, #0x510
    76c8:	f949d861 	ldr	x1, [x3, #5040]
    76cc:	f949ec60 	ldr	x0, [x3, #5080]
    76d0:	cb0102a1 	sub	x1, x21, x1
    76d4:	eb00403f 	cmp	x1, x0, lsl #16
    76d8:	54000322 	b.cs	773c <f0+0x1d2c>  // b.hs, b.nlast
    76dc:	d350fc22 	lsr	x2, x1, #16
    76e0:	f949fc63 	ldr	x3, [x3, #5112]
    76e4:	8b020842 	add	x2, x2, x2, lsl #2
    76e8:	d37df042 	lsl	x2, x2, #3
    76ec:	8b020060 	add	x0, x3, x2
    76f0:	f9401017 	ldr	x23, [x0, #32]
    76f4:	b4000257 	cbz	x23, 773c <f0+0x1d2c>
    76f8:	38626862 	ldrb	w2, [x3, x2]
    76fc:	7100085f 	cmp	w2, #0x2
    7700:	54002960 	b.eq	7c2c <f0+0x221c>  // b.none
    7704:	7100045f 	cmp	w2, #0x1
    7708:	540001a1 	b.ne	773c <f0+0x1d2c>  // b.any
    770c:	29430002 	ldp	w2, w0, [x0, #24]
    7710:	92403c21 	and	x1, x1, #0xffff
    7714:	9b027c21 	mul	x1, x1, x2
    7718:	d360fc21 	lsr	x1, x1, #32
    771c:	eb00003f 	cmp	x1, x0
    7720:	540000e2 	b.cs	773c <f0+0x1d2c>  // b.hs, b.nlast
    7724:	8b0102f7 	add	x23, x23, x1
    7728:	394002e0 	ldrb	w0, [x23]
    772c:	7103fc1f 	cmp	w0, #0xff
    7730:	540038c0 	b.eq	7e48 <f0+0x2438>  // b.none
    7734:	52800020 	mov	w0, #0x1                   	// #1
    7738:	390002e0 	strb	w0, [x23]
    773c:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    7740:	911f63e0 	add	x0, sp, #0x7d8
    7744:	f903efe1 	str	x1, [sp, #2008]
    7748:	f903f3f5 	str	x21, [sp, #2016]
    774c:	97ffef6d 	bl	3500 <fwp_data.part.0.constprop.0>
    7750:	91144283 	add	x3, x20, #0x510
    7754:	aa0003f5 	mov	x21, x0
    7758:	f949d861 	ldr	x1, [x3, #5040]
    775c:	f949ec60 	ldr	x0, [x3, #5080]
    7760:	cb0102a1 	sub	x1, x21, x1
    7764:	eb00403f 	cmp	x1, x0, lsl #16
    7768:	54000322 	b.cs	77cc <f0+0x1dbc>  // b.hs, b.nlast
    776c:	d350fc22 	lsr	x2, x1, #16
    7770:	f949fc63 	ldr	x3, [x3, #5112]
    7774:	8b020842 	add	x2, x2, x2, lsl #2
    7778:	d37df042 	lsl	x2, x2, #3
    777c:	8b020060 	add	x0, x3, x2
    7780:	f9401017 	ldr	x23, [x0, #32]
    7784:	b4000257 	cbz	x23, 77cc <f0+0x1dbc>
    7788:	38626862 	ldrb	w2, [x3, x2]
    778c:	7100085f 	cmp	w2, #0x2
    7790:	54002480 	b.eq	7c20 <f0+0x2210>  // b.none
    7794:	7100045f 	cmp	w2, #0x1
    7798:	540001a1 	b.ne	77cc <f0+0x1dbc>  // b.any
    779c:	29430002 	ldp	w2, w0, [x0, #24]
    77a0:	92403c21 	and	x1, x1, #0xffff
    77a4:	9b027c21 	mul	x1, x1, x2
    77a8:	d360fc21 	lsr	x1, x1, #32
    77ac:	eb00003f 	cmp	x1, x0
    77b0:	540000e2 	b.cs	77cc <f0+0x1dbc>  // b.hs, b.nlast
    77b4:	8b0102f7 	add	x23, x23, x1
    77b8:	394002e0 	ldrb	w0, [x23]
    77bc:	7103fc1f 	cmp	w0, #0xff
    77c0:	540034a0 	b.eq	7e54 <f0+0x2444>  // b.none
    77c4:	52800020 	mov	w0, #0x1                   	// #1
    77c8:	390002e0 	strb	w0, [x23]
    77cc:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    77d0:	911fa3e0 	add	x0, sp, #0x7e8
    77d4:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    77d8:	f903f7e1 	str	x1, [sp, #2024]
    77dc:	f903fbf5 	str	x21, [sp, #2032]
    77e0:	97ffef48 	bl	3500 <fwp_data.part.0.constprop.0>
    77e4:	aa0003f5 	mov	x21, x0
    77e8:	91144283 	add	x3, x20, #0x510
    77ec:	f949d861 	ldr	x1, [x3, #5040]
    77f0:	f949ec60 	ldr	x0, [x3, #5080]
    77f4:	cb0102a1 	sub	x1, x21, x1
    77f8:	eb00403f 	cmp	x1, x0, lsl #16
    77fc:	54000322 	b.cs	7860 <f0+0x1e50>  // b.hs, b.nlast
    7800:	d350fc22 	lsr	x2, x1, #16
    7804:	f949fc63 	ldr	x3, [x3, #5112]
    7808:	8b020842 	add	x2, x2, x2, lsl #2
    780c:	d37df042 	lsl	x2, x2, #3
    7810:	8b020060 	add	x0, x3, x2
    7814:	f9401017 	ldr	x23, [x0, #32]
    7818:	b4000257 	cbz	x23, 7860 <f0+0x1e50>
    781c:	38626862 	ldrb	w2, [x3, x2]
    7820:	7100085f 	cmp	w2, #0x2
    7824:	54001f80 	b.eq	7c14 <f0+0x2204>  // b.none
    7828:	7100045f 	cmp	w2, #0x1
    782c:	540001a1 	b.ne	7860 <f0+0x1e50>  // b.any
    7830:	29430002 	ldp	w2, w0, [x0, #24]
    7834:	92403c21 	and	x1, x1, #0xffff
    7838:	9b027c21 	mul	x1, x1, x2
    783c:	d360fc21 	lsr	x1, x1, #32
    7840:	eb00003f 	cmp	x1, x0
    7844:	540000e2 	b.cs	7860 <f0+0x1e50>  // b.hs, b.nlast
    7848:	8b0102f7 	add	x23, x23, x1
    784c:	394002e0 	ldrb	w0, [x23]
    7850:	7103fc1f 	cmp	w0, #0xff
    7854:	54003060 	b.eq	7e60 <f0+0x2450>  // b.none
    7858:	52800020 	mov	w0, #0x1                   	// #1
    785c:	390002e0 	strb	w0, [x23]
    7860:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    7864:	911fe3e0 	add	x0, sp, #0x7f8
    7868:	f903ffe1 	str	x1, [sp, #2040]
    786c:	f90403f5 	str	x21, [sp, #2048]
    7870:	97ffef24 	bl	3500 <fwp_data.part.0.constprop.0>
    7874:	91144283 	add	x3, x20, #0x510
    7878:	aa0003f5 	mov	x21, x0
    787c:	f949d861 	ldr	x1, [x3, #5040]
    7880:	f949ec60 	ldr	x0, [x3, #5080]
    7884:	cb0102a1 	sub	x1, x21, x1
    7888:	eb00403f 	cmp	x1, x0, lsl #16
    788c:	54000322 	b.cs	78f0 <f0+0x1ee0>  // b.hs, b.nlast
    7890:	d350fc22 	lsr	x2, x1, #16
    7894:	f949fc63 	ldr	x3, [x3, #5112]
    7898:	8b020842 	add	x2, x2, x2, lsl #2
    789c:	d37df042 	lsl	x2, x2, #3
    78a0:	8b020060 	add	x0, x3, x2
    78a4:	f9401017 	ldr	x23, [x0, #32]
    78a8:	b4000257 	cbz	x23, 78f0 <f0+0x1ee0>
    78ac:	38626862 	ldrb	w2, [x3, x2]
    78b0:	7100085f 	cmp	w2, #0x2
    78b4:	54001aa0 	b.eq	7c08 <f0+0x21f8>  // b.none
    78b8:	7100045f 	cmp	w2, #0x1
    78bc:	540001a1 	b.ne	78f0 <f0+0x1ee0>  // b.any
    78c0:	29430002 	ldp	w2, w0, [x0, #24]
    78c4:	92403c21 	and	x1, x1, #0xffff
    78c8:	9b027c21 	mul	x1, x1, x2
    78cc:	d360fc21 	lsr	x1, x1, #32
    78d0:	eb00003f 	cmp	x1, x0
    78d4:	540000e2 	b.cs	78f0 <f0+0x1ee0>  // b.hs, b.nlast
    78d8:	8b0102f7 	add	x23, x23, x1
    78dc:	394002e0 	ldrb	w0, [x23]
    78e0:	7103fc1f 	cmp	w0, #0xff
    78e4:	54002c40 	b.eq	7e6c <f0+0x245c>  // b.none
    78e8:	52800020 	mov	w0, #0x1                   	// #1
    78ec:	390002e0 	strb	w0, [x23]
    78f0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    78f4:	912023e0 	add	x0, sp, #0x808
    78f8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    78fc:	f90407f7 	str	x23, [sp, #2056]
    7900:	f9040bf5 	str	x21, [sp, #2064]
    7904:	97ffeeff 	bl	3500 <fwp_data.part.0.constprop.0>
    7908:	97ffee66 	bl	32a0 <fwp_rc_fresh>
    790c:	aa0003e1 	mov	x1, x0
    7910:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7914:	912063e0 	add	x0, sp, #0x818
    7918:	f9040ff5 	str	x21, [sp, #2072]
    791c:	f90413e1 	str	x1, [sp, #2080]
    7920:	97ffeef8 	bl	3500 <fwp_data.part.0.constprop.0>
    7924:	97ffee5f 	bl	32a0 <fwp_rc_fresh>
    7928:	aa0003e1 	mov	x1, x0
    792c:	9120a3e0 	add	x0, sp, #0x828
    7930:	f90417f7 	str	x23, [sp, #2088]
    7934:	f9041be1 	str	x1, [sp, #2096]
    7938:	97ffeef2 	bl	3500 <fwp_data.part.0.constprop.0>
    793c:	97ffee59 	bl	32a0 <fwp_rc_fresh>
    7940:	aa0003e1 	mov	x1, x0
    7944:	9120e3e0 	add	x0, sp, #0x838
    7948:	f9041ff5 	str	x21, [sp, #2104]
    794c:	f90423e1 	str	x1, [sp, #2112]
    7950:	97ffeeec 	bl	3500 <fwp_data.part.0.constprop.0>
    7954:	aa0003f5 	mov	x21, x0
    7958:	91144283 	add	x3, x20, #0x510
    795c:	f949d861 	ldr	x1, [x3, #5040]
    7960:	f949ec60 	ldr	x0, [x3, #5080]
    7964:	cb0102a1 	sub	x1, x21, x1
    7968:	eb00403f 	cmp	x1, x0, lsl #16
    796c:	54000322 	b.cs	79d0 <f0+0x1fc0>  // b.hs, b.nlast
    7970:	d350fc22 	lsr	x2, x1, #16
    7974:	f949fc63 	ldr	x3, [x3, #5112]
    7978:	8b020842 	add	x2, x2, x2, lsl #2
    797c:	d37df042 	lsl	x2, x2, #3
    7980:	8b020060 	add	x0, x3, x2
    7984:	f9401017 	ldr	x23, [x0, #32]
    7988:	b4000257 	cbz	x23, 79d0 <f0+0x1fc0>
    798c:	38626862 	ldrb	w2, [x3, x2]
    7990:	7100085f 	cmp	w2, #0x2
    7994:	54001340 	b.eq	7bfc <f0+0x21ec>  // b.none
    7998:	7100045f 	cmp	w2, #0x1
    799c:	540001a1 	b.ne	79d0 <f0+0x1fc0>  // b.any
    79a0:	29430002 	ldp	w2, w0, [x0, #24]
    79a4:	92403c21 	and	x1, x1, #0xffff
    79a8:	9b027c21 	mul	x1, x1, x2
    79ac:	d360fc21 	lsr	x1, x1, #32
    79b0:	eb00003f 	cmp	x1, x0
    79b4:	540000e2 	b.cs	79d0 <f0+0x1fc0>  // b.hs, b.nlast
    79b8:	8b0102f7 	add	x23, x23, x1
    79bc:	394002e0 	ldrb	w0, [x23]
    79c0:	7103fc1f 	cmp	w0, #0xff
    79c4:	540025a0 	b.eq	7e78 <f0+0x2468>  // b.none
    79c8:	52800020 	mov	w0, #0x1                   	// #1
    79cc:	390002e0 	strb	w0, [x23]
    79d0:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    79d4:	91144294 	add	x20, x20, #0x510
    79d8:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    79dc:	aa1603e0 	mov	x0, x22
    79e0:	f90427e1 	str	x1, [sp, #2120]
    79e4:	f9042bf5 	str	x21, [sp, #2128]
    79e8:	97ffeec6 	bl	3500 <fwp_data.part.0.constprop.0>
    79ec:	f949da81 	ldr	x1, [x20, #5040]
    79f0:	aa0003f5 	mov	x21, x0
    79f4:	f949ee80 	ldr	x0, [x20, #5080]
    79f8:	cb0102a1 	sub	x1, x21, x1
    79fc:	eb00403f 	cmp	x1, x0, lsl #16
    7a00:	54000322 	b.cs	7a64 <f0+0x2054>  // b.hs, b.nlast
    7a04:	d350fc22 	lsr	x2, x1, #16
    7a08:	f949fe83 	ldr	x3, [x20, #5112]
    7a0c:	8b020842 	add	x2, x2, x2, lsl #2
    7a10:	d37df042 	lsl	x2, x2, #3
    7a14:	8b020060 	add	x0, x3, x2
    7a18:	f9401014 	ldr	x20, [x0, #32]
    7a1c:	b4000254 	cbz	x20, 7a64 <f0+0x2054>
    7a20:	38626862 	ldrb	w2, [x3, x2]
    7a24:	7100085f 	cmp	w2, #0x2
    7a28:	54000e40 	b.eq	7bf0 <f0+0x21e0>  // b.none
    7a2c:	7100045f 	cmp	w2, #0x1
    7a30:	540001a1 	b.ne	7a64 <f0+0x2054>  // b.any
    7a34:	29430002 	ldp	w2, w0, [x0, #24]
    7a38:	92403c21 	and	x1, x1, #0xffff
    7a3c:	9b027c21 	mul	x1, x1, x2
    7a40:	d360fc21 	lsr	x1, x1, #32
    7a44:	eb00003f 	cmp	x1, x0
    7a48:	540000e2 	b.cs	7a64 <f0+0x2054>  // b.hs, b.nlast
    7a4c:	8b010294 	add	x20, x20, x1
    7a50:	39400280 	ldrb	w0, [x20]
    7a54:	7103fc1f 	cmp	w0, #0xff
    7a58:	540012c0 	b.eq	7cb0 <f0+0x22a0>  // b.none
    7a5c:	52800020 	mov	w0, #0x1                   	// #1
    7a60:	39000280 	strb	w0, [x20]
    7a64:	aa1303e1 	mov	x1, x19
    7a68:	aa1503e0 	mov	x0, x21
    7a6c:	97fff496 	bl	4cc4 <fwp_hof0.constprop.0>
    7a70:	aa0003f4 	mov	x20, x0
    7a74:	aa1503e0 	mov	x0, x21
    7a78:	97ffeefe 	bl	3670 <fwp_drop0>
    7a7c:	aa1303e0 	mov	x0, x19
    7a80:	97ffeefc 	bl	3670 <fwp_drop0>
    7a84:	900000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    7a88:	f947f400 	ldr	x0, [x0, #4072]
    7a8c:	f9442fe2 	ldr	x2, [sp, #2136]
    7a90:	f9400001 	ldr	x1, [x0]
    7a94:	eb010042 	subs	x2, x2, x1
    7a98:	d2800001 	mov	x1, #0x0                   	// #0
    7a9c:	54001f41 	b.ne	7e84 <f0+0x2474>  // b.any
    7aa0:	912183ff 	add	sp, sp, #0x860
    7aa4:	aa1403e0 	mov	x0, x20
    7aa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    7aac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7ab0:	a94363f7 	ldp	x23, x24, [sp, #48]
    7ab4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    7ab8:	a94573fb 	ldp	x27, x28, [sp, #80]
    7abc:	a8c67bfd 	ldp	x29, x30, [sp], #96
    7ac0:	d65f03c0 	ret
    7ac4:	aa1b03e0 	mov	x0, x27
    7ac8:	97ffec37 	bl	2ba4 <fwp_rc_forget_slot>
    7acc:	17fff818 	b	5b2c <f0+0x11c>
    7ad0:	72003c5f 	tst	w2, #0xffff
    7ad4:	54ff02e1 	b.ne	5b30 <f0+0x120>  // b.any
    7ad8:	17fff812 	b	5b20 <f0+0x110>
    7adc:	72003c3f 	tst	w1, #0xffff
    7ae0:	54ff97c1 	b.ne	6dd8 <f0+0x13c8>  // b.any
    7ae4:	17fffcb8 	b	6dc4 <f0+0x13b4>
    7ae8:	72003c3f 	tst	w1, #0xffff
    7aec:	54ff8fa1 	b.ne	6ce0 <f0+0x12d0>  // b.any
    7af0:	17fffc77 	b	6ccc <f0+0x12bc>
    7af4:	72003c3f 	tst	w1, #0xffff
    7af8:	54ff8ac1 	b.ne	6c50 <f0+0x1240>  // b.any
    7afc:	17fffc50 	b	6c3c <f0+0x122c>
    7b00:	72003c3f 	tst	w1, #0xffff
    7b04:	54ff84e1 	b.ne	6ba0 <f0+0x1190>  // b.any
    7b08:	17fffc21 	b	6b8c <f0+0x117c>
    7b0c:	72003c3f 	tst	w1, #0xffff
    7b10:	54ff7a81 	b.ne	6a60 <f0+0x1050>  // b.any
    7b14:	17fffbce 	b	6a4c <f0+0x103c>
    7b18:	72003c3f 	tst	w1, #0xffff
    7b1c:	54ff7321 	b.ne	6980 <f0+0xf70>  // b.any
    7b20:	17fffb93 	b	696c <f0+0xf5c>
    7b24:	72003c3f 	tst	w1, #0xffff
    7b28:	54ff6bc1 	b.ne	68a0 <f0+0xe90>  // b.any
    7b2c:	17fffb58 	b	688c <f0+0xe7c>
    7b30:	72003c3f 	tst	w1, #0xffff
    7b34:	54ff6461 	b.ne	67c0 <f0+0xdb0>  // b.any
    7b38:	17fffb1d 	b	67ac <f0+0xd9c>
    7b3c:	72003c3f 	tst	w1, #0xffff
    7b40:	54ff1b81 	b.ne	5eb0 <f0+0x4a0>  // b.any
    7b44:	17fff8d6 	b	5e9c <f0+0x48c>
    7b48:	72003c3f 	tst	w1, #0xffff
    7b4c:	54ff15e1 	b.ne	5e08 <f0+0x3f8>  // b.any
    7b50:	17fff8a9 	b	5df4 <f0+0x3e4>
    7b54:	72003c3f 	tst	w1, #0xffff
    7b58:	54ff1041 	b.ne	5d60 <f0+0x350>  // b.any
    7b5c:	17fff87c 	b	5d4c <f0+0x33c>
    7b60:	72003c3f 	tst	w1, #0xffff
    7b64:	54ff2f21 	b.ne	6148 <f0+0x738>  // b.any
    7b68:	17fff973 	b	6134 <f0+0x724>
    7b6c:	72003c3f 	tst	w1, #0xffff
    7b70:	54ff2961 	b.ne	609c <f0+0x68c>  // b.any
    7b74:	17fff945 	b	6088 <f0+0x678>
    7b78:	72003c3f 	tst	w1, #0xffff
    7b7c:	54ff2481 	b.ne	600c <f0+0x5fc>  // b.any
    7b80:	17fff91e 	b	5ff8 <f0+0x5e8>
    7b84:	72003c3f 	tst	w1, #0xffff
    7b88:	54ff1fc1 	b.ne	5f80 <f0+0x570>  // b.any
    7b8c:	17fff8f8 	b	5f6c <f0+0x55c>
    7b90:	72003c3f 	tst	w1, #0xffff
    7b94:	54ff59a1 	b.ne	66c8 <f0+0xcb8>  // b.any
    7b98:	17fffac7 	b	66b4 <f0+0xca4>
    7b9c:	72003c3f 	tst	w1, #0xffff
    7ba0:	54ff5301 	b.ne	6600 <f0+0xbf0>  // b.any
    7ba4:	17fffa92 	b	65ec <f0+0xbdc>
    7ba8:	72003c3f 	tst	w1, #0xffff
    7bac:	54ff4e01 	b.ne	656c <f0+0xb5c>  // b.any
    7bb0:	17fffa6a 	b	6558 <f0+0xb48>
    7bb4:	72003c3f 	tst	w1, #0xffff
    7bb8:	54ff4821 	b.ne	64bc <f0+0xaac>  // b.any
    7bbc:	17fffa3b 	b	64a8 <f0+0xa98>
    7bc0:	72003c3f 	tst	w1, #0xffff
    7bc4:	54ff4341 	b.ne	642c <f0+0xa1c>  // b.any
    7bc8:	17fffa14 	b	6418 <f0+0xa08>
    7bcc:	72003c3f 	tst	w1, #0xffff
    7bd0:	54ff3e41 	b.ne	6398 <f0+0x988>  // b.any
    7bd4:	17fff9ec 	b	6384 <f0+0x974>
    7bd8:	72003c3f 	tst	w1, #0xffff
    7bdc:	54ff3961 	b.ne	6308 <f0+0x8f8>  // b.any
    7be0:	17fff9c5 	b	62f4 <f0+0x8e4>
    7be4:	72003c3f 	tst	w1, #0xffff
    7be8:	54ff32c1 	b.ne	6240 <f0+0x830>  // b.any
    7bec:	17fff990 	b	622c <f0+0x81c>
    7bf0:	72003c3f 	tst	w1, #0xffff
    7bf4:	54fff381 	b.ne	7a64 <f0+0x2054>  // b.any
    7bf8:	17ffff96 	b	7a50 <f0+0x2040>
    7bfc:	72003c3f 	tst	w1, #0xffff
    7c00:	54ffee81 	b.ne	79d0 <f0+0x1fc0>  // b.any
    7c04:	17ffff6e 	b	79bc <f0+0x1fac>
    7c08:	72003c3f 	tst	w1, #0xffff
    7c0c:	54ffe721 	b.ne	78f0 <f0+0x1ee0>  // b.any
    7c10:	17ffff33 	b	78dc <f0+0x1ecc>
    7c14:	72003c3f 	tst	w1, #0xffff
    7c18:	54ffe241 	b.ne	7860 <f0+0x1e50>  // b.any
    7c1c:	17ffff0c 	b	784c <f0+0x1e3c>
    7c20:	72003c3f 	tst	w1, #0xffff
    7c24:	54ffdd41 	b.ne	77cc <f0+0x1dbc>  // b.any
    7c28:	17fffee4 	b	77b8 <f0+0x1da8>
    7c2c:	72003c3f 	tst	w1, #0xffff
    7c30:	54ffd861 	b.ne	773c <f0+0x1d2c>  // b.any
    7c34:	17fffebd 	b	7728 <f0+0x1d18>
    7c38:	72003c3f 	tst	w1, #0xffff
    7c3c:	54ffd281 	b.ne	768c <f0+0x1c7c>  // b.any
    7c40:	17fffe8e 	b	7678 <f0+0x1c68>
    7c44:	72003c3f 	tst	w1, #0xffff
    7c48:	54ffc821 	b.ne	754c <f0+0x1b3c>  // b.any
    7c4c:	17fffe3b 	b	7538 <f0+0x1b28>
    7c50:	72003c3f 	tst	w1, #0xffff
    7c54:	54ffc001 	b.ne	7454 <f0+0x1a44>  // b.any
    7c58:	17fffdfa 	b	7440 <f0+0x1a30>
    7c5c:	72003c3f 	tst	w1, #0xffff
    7c60:	54ffbb21 	b.ne	73c4 <f0+0x19b4>  // b.any
    7c64:	17fffdd3 	b	73b0 <f0+0x19a0>
    7c68:	72003c3f 	tst	w1, #0xffff
    7c6c:	54ffb541 	b.ne	7314 <f0+0x1904>  // b.any
    7c70:	17fffda4 	b	7300 <f0+0x18f0>
    7c74:	72003c3f 	tst	w1, #0xffff
    7c78:	54ffaf61 	b.ne	7264 <f0+0x1854>  // b.any
    7c7c:	17fffd75 	b	7250 <f0+0x1840>
    7c80:	72003c3f 	tst	w1, #0xffff
    7c84:	54ffa981 	b.ne	71b4 <f0+0x17a4>  // b.any
    7c88:	17fffd46 	b	71a0 <f0+0x1790>
    7c8c:	72003c3f 	tst	w1, #0xffff
    7c90:	54ff9f21 	b.ne	7074 <f0+0x1664>  // b.any
    7c94:	17fffcf3 	b	7060 <f0+0x1650>
    7c98:	72003c3f 	tst	w1, #0xffff
    7c9c:	54ff9a21 	b.ne	6fe0 <f0+0x15d0>  // b.any
    7ca0:	17fffccb 	b	6fcc <f0+0x15bc>
    7ca4:	72003c3f 	tst	w1, #0xffff
    7ca8:	54ff9381 	b.ne	6f18 <f0+0x1508>  // b.any
    7cac:	17fffc96 	b	6f04 <f0+0x14f4>
    7cb0:	aa1403e0 	mov	x0, x20
    7cb4:	97ffebbc 	bl	2ba4 <fwp_rc_forget_slot>
    7cb8:	17ffff69 	b	7a5c <f0+0x204c>
    7cbc:	aa1703e0 	mov	x0, x23
    7cc0:	97ffebb9 	bl	2ba4 <fwp_rc_forget_slot>
    7cc4:	17fff825 	b	5d58 <f0+0x348>
    7cc8:	aa1703e0 	mov	x0, x23
    7ccc:	97ffebb6 	bl	2ba4 <fwp_rc_forget_slot>
    7cd0:	17fff84c 	b	5e00 <f0+0x3f0>
    7cd4:	aa1703e0 	mov	x0, x23
    7cd8:	97ffebb3 	bl	2ba4 <fwp_rc_forget_slot>
    7cdc:	17fff873 	b	5ea8 <f0+0x498>
    7ce0:	aa1703e0 	mov	x0, x23
    7ce4:	97ffebb0 	bl	2ba4 <fwp_rc_forget_slot>
    7ce8:	17fff8a4 	b	5f78 <f0+0x568>
    7cec:	aa1703e0 	mov	x0, x23
    7cf0:	97ffebad 	bl	2ba4 <fwp_rc_forget_slot>
    7cf4:	17fff8c4 	b	6004 <f0+0x5f4>
    7cf8:	aa1703e0 	mov	x0, x23
    7cfc:	97ffebaa 	bl	2ba4 <fwp_rc_forget_slot>
    7d00:	17fff8e5 	b	6094 <f0+0x684>
    7d04:	aa1703e0 	mov	x0, x23
    7d08:	97ffeba7 	bl	2ba4 <fwp_rc_forget_slot>
    7d0c:	17fff90d 	b	6140 <f0+0x730>
    7d10:	aa1703e0 	mov	x0, x23
    7d14:	97ffeba4 	bl	2ba4 <fwp_rc_forget_slot>
    7d18:	17fff948 	b	6238 <f0+0x828>
    7d1c:	aa1703e0 	mov	x0, x23
    7d20:	97ffeba1 	bl	2ba4 <fwp_rc_forget_slot>
    7d24:	17fff977 	b	6300 <f0+0x8f0>
    7d28:	aa1703e0 	mov	x0, x23
    7d2c:	97ffeb9e 	bl	2ba4 <fwp_rc_forget_slot>
    7d30:	17fff998 	b	6390 <f0+0x980>
    7d34:	aa1703e0 	mov	x0, x23
    7d38:	97ffeb9b 	bl	2ba4 <fwp_rc_forget_slot>
    7d3c:	17fff9ba 	b	6424 <f0+0xa14>
    7d40:	aa1703e0 	mov	x0, x23
    7d44:	97ffeb98 	bl	2ba4 <fwp_rc_forget_slot>
    7d48:	17fff9db 	b	64b4 <f0+0xaa4>
    7d4c:	aa1703e0 	mov	x0, x23
    7d50:	97ffeb95 	bl	2ba4 <fwp_rc_forget_slot>
    7d54:	17fffa04 	b	6564 <f0+0xb54>
    7d58:	aa1703e0 	mov	x0, x23
    7d5c:	97ffeb92 	bl	2ba4 <fwp_rc_forget_slot>
    7d60:	17fffa26 	b	65f8 <f0+0xbe8>
    7d64:	aa1703e0 	mov	x0, x23
    7d68:	97ffeb8f 	bl	2ba4 <fwp_rc_forget_slot>
    7d6c:	17fffa55 	b	66c0 <f0+0xcb0>
    7d70:	aa1703e0 	mov	x0, x23
    7d74:	97ffeb8c 	bl	2ba4 <fwp_rc_forget_slot>
    7d78:	17fffa90 	b	67b8 <f0+0xda8>
    7d7c:	aa1703e0 	mov	x0, x23
    7d80:	97ffeb89 	bl	2ba4 <fwp_rc_forget_slot>
    7d84:	17fffac5 	b	6898 <f0+0xe88>
    7d88:	aa1703e0 	mov	x0, x23
    7d8c:	97ffeb86 	bl	2ba4 <fwp_rc_forget_slot>
    7d90:	17fffafa 	b	6978 <f0+0xf68>
    7d94:	aa1703e0 	mov	x0, x23
    7d98:	97ffeb83 	bl	2ba4 <fwp_rc_forget_slot>
    7d9c:	17fffb2f 	b	6a58 <f0+0x1048>
    7da0:	aa1703e0 	mov	x0, x23
    7da4:	97ffeb80 	bl	2ba4 <fwp_rc_forget_slot>
    7da8:	17fffb7c 	b	6b98 <f0+0x1188>
    7dac:	aa1703e0 	mov	x0, x23
    7db0:	97ffeb7d 	bl	2ba4 <fwp_rc_forget_slot>
    7db4:	17fffba5 	b	6c48 <f0+0x1238>
    7db8:	aa1703e0 	mov	x0, x23
    7dbc:	97ffeb7a 	bl	2ba4 <fwp_rc_forget_slot>
    7dc0:	17fffbc6 	b	6cd8 <f0+0x12c8>
    7dc4:	aa1703e0 	mov	x0, x23
    7dc8:	97ffeb77 	bl	2ba4 <fwp_rc_forget_slot>
    7dcc:	17fffc01 	b	6dd0 <f0+0x13c0>
    7dd0:	aa1703e0 	mov	x0, x23
    7dd4:	97ffeb74 	bl	2ba4 <fwp_rc_forget_slot>
    7dd8:	17fffc4e 	b	6f10 <f0+0x1500>
    7ddc:	aa1703e0 	mov	x0, x23
    7de0:	97ffeb71 	bl	2ba4 <fwp_rc_forget_slot>
    7de4:	17fffc7d 	b	6fd8 <f0+0x15c8>
    7de8:	aa1703e0 	mov	x0, x23
    7dec:	97ffeb6e 	bl	2ba4 <fwp_rc_forget_slot>
    7df0:	17fffc9f 	b	706c <f0+0x165c>
    7df4:	aa1703e0 	mov	x0, x23
    7df8:	97ffeb6b 	bl	2ba4 <fwp_rc_forget_slot>
    7dfc:	17fffcec 	b	71ac <f0+0x179c>
    7e00:	aa1703e0 	mov	x0, x23
    7e04:	97ffeb68 	bl	2ba4 <fwp_rc_forget_slot>
    7e08:	17fffd15 	b	725c <f0+0x184c>
    7e0c:	aa1703e0 	mov	x0, x23
    7e10:	97ffeb65 	bl	2ba4 <fwp_rc_forget_slot>
    7e14:	17fffd3e 	b	730c <f0+0x18fc>
    7e18:	aa1703e0 	mov	x0, x23
    7e1c:	97ffeb62 	bl	2ba4 <fwp_rc_forget_slot>
    7e20:	17fffd67 	b	73bc <f0+0x19ac>
    7e24:	aa1703e0 	mov	x0, x23
    7e28:	97ffeb5f 	bl	2ba4 <fwp_rc_forget_slot>
    7e2c:	17fffd88 	b	744c <f0+0x1a3c>
    7e30:	aa1703e0 	mov	x0, x23
    7e34:	97ffeb5c 	bl	2ba4 <fwp_rc_forget_slot>
    7e38:	17fffdc3 	b	7544 <f0+0x1b34>
    7e3c:	aa1703e0 	mov	x0, x23
    7e40:	97ffeb59 	bl	2ba4 <fwp_rc_forget_slot>
    7e44:	17fffe10 	b	7684 <f0+0x1c74>
    7e48:	aa1703e0 	mov	x0, x23
    7e4c:	97ffeb56 	bl	2ba4 <fwp_rc_forget_slot>
    7e50:	17fffe39 	b	7734 <f0+0x1d24>
    7e54:	aa1703e0 	mov	x0, x23
    7e58:	97ffeb53 	bl	2ba4 <fwp_rc_forget_slot>
    7e5c:	17fffe5a 	b	77c4 <f0+0x1db4>
    7e60:	aa1703e0 	mov	x0, x23
    7e64:	97ffeb50 	bl	2ba4 <fwp_rc_forget_slot>
    7e68:	17fffe7c 	b	7858 <f0+0x1e48>
    7e6c:	aa1703e0 	mov	x0, x23
    7e70:	97ffeb4d 	bl	2ba4 <fwp_rc_forget_slot>
    7e74:	17fffe9d 	b	78e8 <f0+0x1ed8>
    7e78:	aa1703e0 	mov	x0, x23
    7e7c:	97ffeb4a 	bl	2ba4 <fwp_rc_forget_slot>
    7e80:	17fffed2 	b	79c8 <f0+0x1fb8>
    7e84:	97ffe587 	bl	14a0 <__stack_chk_fail@plt>
    7e88:	d503201f 	nop
    7e8c:	d503201f 	nop

0000000000007e90 <fwp_main_thread>:
    7e90:	d10443ff 	sub	sp, sp, #0x110
    7e94:	900000c0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    7e98:	f947f400 	ldr	x0, [x0, #4072]
    7e9c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    7ea0:	910303fd 	add	x29, sp, #0xc0
    7ea4:	a90d53f3 	stp	x19, x20, [sp, #208]
    7ea8:	d0000153 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    7eac:	91144261 	add	x1, x19, #0x510
    7eb0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    7eb4:	b953a421 	ldr	w1, [x1, #5028]
    7eb8:	f9400002 	ldr	x2, [x0]
    7ebc:	f9005fe2 	str	x2, [sp, #184]
    7ec0:	d2800002 	mov	x2, #0x0                   	// #0
    7ec4:	340025c1 	cbz	w1, 837c <fwp_main_thread+0x4ec>
    7ec8:	91144273 	add	x19, x19, #0x510
    7ecc:	b953aa60 	ldr	w0, [x19, #5032]
    7ed0:	350024e0 	cbnz	w0, 836c <fwp_main_thread+0x4dc>
    7ed4:	91001fe2 	add	x2, sp, #0x7
    7ed8:	b00000d5 	adrp	x21, 20000 <__data_start>
    7edc:	b00000c3 	adrp	x3, 20000 <__data_start>
    7ee0:	9101c2b3 	add	x19, x21, #0x70
    7ee4:	910cc063 	add	x3, x3, #0x330
    7ee8:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    7eec:	d2a00025 	mov	x5, #0x10000               	// #65536
    7ef0:	910023e0 	add	x0, sp, #0x8
    7ef4:	d2800001 	mov	x1, #0x0                   	// #0
    7ef8:	f90007e3 	str	x3, [sp, #8]
    7efc:	a9011262 	stp	x2, x4, [x19, #16]
    7f00:	b90013ff 	str	wzr, [sp, #16]
    7f04:	f9000fe5 	str	x5, [sp, #24]
    7f08:	97ffe502 	bl	1310 <sigaltstack@plt>
    7f0c:	35002520 	cbnz	w0, 83b0 <fwp_main_thread+0x520>
    7f10:	4f000400 	movi	v0.4s, #0x0
    7f14:	9100a3e0 	add	x0, sp, #0x28
    7f18:	d0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    7f1c:	52800082 	mov	w2, #0x4                   	// #4
    7f20:	912f4021 	add	x1, x1, #0xbd0
    7f24:	72a10002 	movk	w2, #0x800, lsl #16
    7f28:	910083f4 	add	x20, sp, #0x20
    7f2c:	f90013e1 	str	x1, [sp, #32]
    7f30:	3d802000 	str	q0, [x0, #128]
    7f34:	b900abe2 	str	w2, [sp, #168]
    7f38:	ad000000 	stp	q0, q0, [x0]
    7f3c:	ad010000 	stp	q0, q0, [x0, #32]
    7f40:	ad020000 	stp	q0, q0, [x0, #64]
    7f44:	ad030000 	stp	q0, q0, [x0, #96]
    7f48:	97ffe546 	bl	1460 <sigemptyset@plt>
    7f4c:	35002320 	cbnz	w0, 83b0 <fwp_main_thread+0x520>
    7f50:	aa1403e1 	mov	x1, x20
    7f54:	d2800002 	mov	x2, #0x0                   	// #0
    7f58:	52800160 	mov	w0, #0xb                   	// #11
    7f5c:	97ffe559 	bl	14c0 <sigaction@plt>
    7f60:	35002280 	cbnz	w0, 83b0 <fwp_main_thread+0x520>
    7f64:	aa1403e1 	mov	x1, x20
    7f68:	d2800002 	mov	x2, #0x0                   	// #0
    7f6c:	528000e0 	mov	w0, #0x7                   	// #7
    7f70:	97ffe554 	bl	14c0 <sigaction@plt>
    7f74:	350021e0 	cbnz	w0, 83b0 <fwp_main_thread+0x520>
    7f78:	b9429660 	ldr	w0, [x19, #660]
    7f7c:	a90f63f7 	stp	x23, x24, [sp, #240]
    7f80:	34002020 	cbz	w0, 8384 <fwp_main_thread+0x4f4>
    7f84:	9101c2b6 	add	x22, x21, #0x70
    7f88:	f94006d4 	ldr	x20, [x22, #8]
    7f8c:	b40010d4 	cbz	x20, 81a4 <fwp_main_thread+0x314>
    7f90:	aa1403f3 	mov	x19, x20
    7f94:	91010297 	add	x23, x20, #0x40
    7f98:	f90083f9 	str	x25, [sp, #256]
    7f9c:	52800038 	mov	w24, #0x1                   	// #1
    7fa0:	39414a99 	ldrb	w25, [x20, #82]
    7fa4:	39014a98 	strb	w24, [x20, #82]
    7fa8:	f9401680 	ldr	x0, [x20, #40]
    7fac:	b4000620 	cbz	x0, 8070 <fwp_main_thread+0x1e0>
    7fb0:	f9403281 	ldr	x1, [x20, #96]
    7fb4:	39414680 	ldrb	w0, [x20, #81]
    7fb8:	b4000b41 	cbz	x1, 8120 <fwp_main_thread+0x290>
    7fbc:	36000a80 	tbz	w0, #0, 810c <fwp_main_thread+0x27c>
    7fc0:	39414a62 	ldrb	w2, [x19, #82]
    7fc4:	f9402280 	ldr	x0, [x20, #64]
    7fc8:	37000d62 	tbnz	w2, #0, 8174 <fwp_main_thread+0x2e4>
    7fcc:	f9403261 	ldr	x1, [x19, #96]
    7fd0:	a911fe77 	stp	x23, xzr, [x19, #280]
    7fd4:	f9009660 	str	x0, [x19, #296]
    7fd8:	b4000040 	cbz	x0, 7fe0 <fwp_main_thread+0x150>
    7fdc:	f9009013 	str	x19, [x0, #288]
    7fe0:	f9002293 	str	x19, [x20, #64]
    7fe4:	b4000101 	cbz	x1, 8004 <fwp_main_thread+0x174>
    7fe8:	f9401ac0 	ldr	x0, [x22, #48]
    7fec:	39015678 	strb	w24, [x19, #85]
    7ff0:	f9003661 	str	x1, [x19, #104]
    7ff4:	a910827f 	stp	xzr, x0, [x19, #264]
    7ff8:	b4000040 	cbz	x0, 8000 <fwp_main_thread+0x170>
    7ffc:	f9008413 	str	x19, [x0, #264]
    8000:	f9001ad3 	str	x19, [x22, #48]
    8004:	39015a7f 	strb	wzr, [x19, #86]
    8008:	97ffeeef 	bl	3bc4 <fwp_block>
    800c:	f9408e62 	ldr	x2, [x19, #280]
    8010:	b4000142 	cbz	x2, 8038 <fwp_main_thread+0x1a8>
    8014:	a9520261 	ldp	x1, x0, [x19, #288]
    8018:	b4000ba1 	cbz	x1, 818c <fwp_main_thread+0x2fc>
    801c:	f9009420 	str	x0, [x1, #296]
    8020:	f9409660 	ldr	x0, [x19, #296]
    8024:	b4000040 	cbz	x0, 802c <fwp_main_thread+0x19c>
    8028:	f9009001 	str	x1, [x0, #288]
    802c:	91080260 	add	x0, x19, #0x200
    8030:	f900967f 	str	xzr, [x19, #296]
    8034:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8038:	39415660 	ldrb	w0, [x19, #85]
    803c:	f94006c2 	ldr	x2, [x22, #8]
    8040:	36000960 	tbz	w0, #0, 816c <fwp_main_thread+0x2dc>
    8044:	a9508261 	ldp	x1, x0, [x19, #264]
    8048:	b4000a61 	cbz	x1, 8194 <fwp_main_thread+0x304>
    804c:	f9008820 	str	x0, [x1, #272]
    8050:	b4000040 	cbz	x0, 8058 <fwp_main_thread+0x1c8>
    8054:	f9008401 	str	x1, [x0, #264]
    8058:	91080260 	add	x0, x19, #0x200
    805c:	3901567f 	strb	wzr, [x19, #85]
    8060:	aa0203f3 	mov	x19, x2
    8064:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8068:	f9401680 	ldr	x0, [x20, #40]
    806c:	b5fffa20 	cbnz	x0, 7fb0 <fwp_main_thread+0x120>
    8070:	9101c2a0 	add	x0, x21, #0x70
    8074:	39014a99 	strb	w25, [x20, #82]
    8078:	f94083f9 	ldr	x25, [sp, #256]
    807c:	f9413c00 	ldr	x0, [x0, #632]
    8080:	b4001560 	cbz	x0, 832c <fwp_main_thread+0x49c>
    8084:	9101c2a0 	add	x0, x21, #0x70
    8088:	f9415401 	ldr	x1, [x0, #680]
    808c:	b902a01f 	str	wzr, [x0, #672]
    8090:	eb13003f 	cmp	x1, x19
    8094:	54001681 	b.ne	8364 <fwp_main_thread+0x4d4>  // b.any
    8098:	b4000913 	cbz	x19, 81b8 <fwp_main_thread+0x328>
    809c:	9101c2a0 	add	x0, x21, #0x70
    80a0:	52800021 	mov	w1, #0x1                   	// #1
    80a4:	39014a61 	strb	w1, [x19, #82]
    80a8:	f9412805 	ldr	x5, [x0, #592]
    80ac:	b4000865 	cbz	x5, 81b8 <fwp_main_thread+0x328>
    80b0:	394140a0 	ldrb	w0, [x5, #80]
    80b4:	37000060 	tbnz	w0, #0, 80c0 <fwp_main_thread+0x230>
    80b8:	aa0503e0 	mov	x0, x5
    80bc:	97ffe7b5 	bl	1f90 <fwp_cancel_tree.part.0>
    80c0:	f9409ca5 	ldr	x5, [x5, #312]
    80c4:	b5ffff65 	cbnz	x5, 80b0 <fwp_main_thread+0x220>
    80c8:	9101c2b4 	add	x20, x21, #0x70
    80cc:	52800036 	mov	w22, #0x1                   	// #1
    80d0:	f9402a60 	ldr	x0, [x19, #80]
    80d4:	f2001c1f 	tst	x0, #0xff000000ff
    80d8:	540000e1 	b.ne	80f4 <fwp_main_thread+0x264>  // b.any
    80dc:	f9401280 	ldr	x0, [x20, #32]
    80e0:	39015276 	strb	w22, [x19, #84]
    80e4:	f900827f 	str	xzr, [x19, #256]
    80e8:	b40005a0 	cbz	x0, 819c <fwp_main_thread+0x30c>
    80ec:	f9008013 	str	x19, [x0, #256]
    80f0:	f9001293 	str	x19, [x20, #32]
    80f4:	97ffeeb4 	bl	3bc4 <fwp_block>
    80f8:	97ffee46 	bl	3a10 <fwp_free_zombie>
    80fc:	f9412a80 	ldr	x0, [x20, #592]
    8100:	b40005c0 	cbz	x0, 81b8 <fwp_main_thread+0x328>
    8104:	f9415693 	ldr	x19, [x20, #680]
    8108:	17fffff2 	b	80d0 <fwp_main_thread+0x240>
    810c:	97ffe7f5 	bl	20e0 <fwp_now_ns>
    8110:	f9403281 	ldr	x1, [x20, #96]
    8114:	eb01001f 	cmp	x0, x1
    8118:	54000fca 	b.ge	8310 <fwp_main_thread+0x480>  // b.tcont
    811c:	39414680 	ldrb	w0, [x20, #81]
    8120:	39414a62 	ldrb	w2, [x19, #82]
    8124:	3707f500 	tbnz	w0, #0, 7fc4 <fwp_main_thread+0x134>
    8128:	f9403281 	ldr	x1, [x20, #96]
    812c:	370001c2 	tbnz	w2, #0, 8164 <fwp_main_thread+0x2d4>
    8130:	f9403260 	ldr	x0, [x19, #96]
    8134:	b4000180 	cbz	x0, 8164 <fwp_main_thread+0x2d4>
    8138:	b4000061 	cbz	x1, 8144 <fwp_main_thread+0x2b4>
    813c:	eb01001f 	cmp	x0, x1
    8140:	9a81d000 	csel	x0, x0, x1, le
    8144:	f9402281 	ldr	x1, [x20, #64]
    8148:	a911fe77 	stp	x23, xzr, [x19, #280]
    814c:	f9009661 	str	x1, [x19, #296]
    8150:	b4001241 	cbz	x1, 8398 <fwp_main_thread+0x508>
    8154:	f9009033 	str	x19, [x1, #288]
    8158:	aa0003e1 	mov	x1, x0
    815c:	f9002293 	str	x19, [x20, #64]
    8160:	17ffffa2 	b	7fe8 <fwp_main_thread+0x158>
    8164:	f9402280 	ldr	x0, [x20, #64]
    8168:	17ffff9a 	b	7fd0 <fwp_main_thread+0x140>
    816c:	aa0203f3 	mov	x19, x2
    8170:	17ffff8e 	b	7fa8 <fwp_main_thread+0x118>
    8174:	a911fe77 	stp	x23, xzr, [x19, #280]
    8178:	f9009660 	str	x0, [x19, #296]
    817c:	b4000040 	cbz	x0, 8184 <fwp_main_thread+0x2f4>
    8180:	f9009013 	str	x19, [x0, #288]
    8184:	f9002293 	str	x19, [x20, #64]
    8188:	17ffff9f 	b	8004 <fwp_main_thread+0x174>
    818c:	f9000040 	str	x0, [x2]
    8190:	17ffffa5 	b	8024 <fwp_main_thread+0x194>
    8194:	f9001ac0 	str	x0, [x22, #48]
    8198:	17ffffae 	b	8050 <fwp_main_thread+0x1c0>
    819c:	f9001693 	str	x19, [x20, #40]
    81a0:	17ffffd4 	b	80f0 <fwp_main_thread+0x260>
    81a4:	f9413ec0 	ldr	x0, [x22, #632]
    81a8:	b4000c00 	cbz	x0, 8328 <fwp_main_thread+0x498>
    81ac:	f94156c0 	ldr	x0, [x22, #680]
    81b0:	b902a2df 	str	wzr, [x22, #672]
    81b4:	b5000d80 	cbnz	x0, 8364 <fwp_main_thread+0x4d4>
    81b8:	9101c2b4 	add	x20, x21, #0x70
    81bc:	97ffee15 	bl	3a10 <fwp_free_zombie>
    81c0:	f9401680 	ldr	x0, [x20, #40]
    81c4:	b5000d00 	cbnz	x0, 8364 <fwp_main_thread+0x4d4>
    81c8:	f9401a80 	ldr	x0, [x20, #48]
    81cc:	b5000cc0 	cbnz	x0, 8364 <fwp_main_thread+0x4d4>
    81d0:	b9404293 	ldr	w19, [x20, #64]
    81d4:	340001d3 	cbz	w19, 820c <fwp_main_thread+0x37c>
    81d8:	93407e76 	sxtw	x22, w19
    81dc:	51000673 	sub	w19, w19, #0x1
    81e0:	d1000ad6 	sub	x22, x22, #0x2
    81e4:	91014297 	add	x23, x20, #0x50
    81e8:	cb3342d6 	sub	x22, x22, w19, uxtw
    81ec:	93407e73 	sxtw	x19, w19
    81f0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    81f4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    81f8:	b9004293 	str	w19, [x20, #64]
    81fc:	d1000673 	sub	x19, x19, #0x1
    8200:	97ffe4f0 	bl	15c0 <munmap@plt>
    8204:	eb16027f 	cmp	x19, x22
    8208:	54ffff41 	b.ne	81f0 <fwp_main_thread+0x360>  // b.any
    820c:	900000d3 	adrp	x19, 20000 <__data_start>
    8210:	91004260 	add	x0, x19, #0x10
    8214:	b9404000 	ldr	w0, [x0, #64]
    8218:	37f80040 	tbnz	w0, #31, 8220 <fwp_main_thread+0x390>
    821c:	97ffe4a5 	bl	14b0 <close@plt>
    8220:	9101c2a0 	add	x0, x21, #0x70
    8224:	91004261 	add	x1, x19, #0x10
    8228:	12800002 	mov	w2, #0xffffffff            	// #-1
    822c:	d2800013 	mov	x19, #0x0                   	// #0
    8230:	f9415816 	ldr	x22, [x0, #688]
    8234:	b9004022 	str	w2, [x1, #64]
    8238:	f9415c14 	ldr	x20, [x0, #696]
    823c:	b4000176 	cbz	x22, 8268 <fwp_main_thread+0x3d8>
    8240:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    8244:	b40000c0 	cbz	x0, 825c <fwp_main_thread+0x3cc>
    8248:	f9400001 	ldr	x1, [x0]
    824c:	b50008c1 	cbnz	x1, 8364 <fwp_main_thread+0x4d4>
    8250:	f9400401 	ldr	x1, [x0, #8]
    8254:	b5000881 	cbnz	x1, 8364 <fwp_main_thread+0x4d4>
    8258:	97ffeaf2 	bl	2e20 <fwp_mem_free>
    825c:	91000673 	add	x19, x19, #0x1
    8260:	eb16027f 	cmp	x19, x22
    8264:	54fffee1 	b.ne	8240 <fwp_main_thread+0x3b0>  // b.any
    8268:	aa1403e0 	mov	x0, x20
    826c:	97ffeaed 	bl	2e20 <fwp_mem_free>
    8270:	9101c2a0 	add	x0, x21, #0x70
    8274:	f9415413 	ldr	x19, [x0, #680]
    8278:	f901581f 	str	xzr, [x0, #688]
    827c:	f9015c1f 	str	xzr, [x0, #696]
    8280:	b40001f3 	cbz	x19, 82bc <fwp_main_thread+0x42c>
    8284:	f9401661 	ldr	x1, [x19, #40]
    8288:	b50006e1 	cbnz	x1, 8364 <fwp_main_thread+0x4d4>
    828c:	f9405661 	ldr	x1, [x19, #168]
    8290:	b50006a1 	cbnz	x1, 8364 <fwp_main_thread+0x4d4>
    8294:	f9413c01 	ldr	x1, [x0, #632]
    8298:	b5000661 	cbnz	x1, 8364 <fwp_main_thread+0x4d4>
    829c:	f9414400 	ldr	x0, [x0, #648]
    82a0:	b5000620 	cbnz	x0, 8364 <fwp_main_thread+0x4d4>
    82a4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    82a8:	90000140 	adrp	x0, 30000 <alt.4+0xfcd0>
    82ac:	910cc000 	add	x0, x0, #0x330
    82b0:	97ffe470 	bl	1470 <memset@plt>
    82b4:	aa1303e0 	mov	x0, x19
    82b8:	97ffeada 	bl	2e20 <fwp_mem_free>
    82bc:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    82c0:	f947ec00 	ldr	x0, [x0, #4056]
    82c4:	9101c2b5 	add	x21, x21, #0x70
    82c8:	f9400000 	ldr	x0, [x0]
    82cc:	f90006bf 	str	xzr, [x21, #8]
    82d0:	f90156bf 	str	xzr, [x21, #680]
    82d4:	97ffe4bf 	bl	15d0 <fflush@plt>
    82d8:	f00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x152b8>
    82dc:	f947f400 	ldr	x0, [x0, #4072]
    82e0:	f9405fe2 	ldr	x2, [sp, #184]
    82e4:	f9400001 	ldr	x1, [x0]
    82e8:	eb010042 	subs	x2, x2, x1
    82ec:	d2800001 	mov	x1, #0x0                   	// #0
    82f0:	540006a1 	b.ne	83c4 <fwp_main_thread+0x534>  // b.any
    82f4:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    82f8:	d2800000 	mov	x0, #0x0                   	// #0
    82fc:	a94d53f3 	ldp	x19, x20, [sp, #208]
    8300:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    8304:	a94f63f7 	ldp	x23, x24, [sp, #240]
    8308:	910443ff 	add	sp, sp, #0x110
    830c:	d65f03c0 	ret
    8310:	39414280 	ldrb	w0, [x20, #80]
    8314:	3707f040 	tbnz	w0, #0, 811c <fwp_main_thread+0x28c>
    8318:	aa1403e0 	mov	x0, x20
    831c:	97ffe71d 	bl	1f90 <fwp_cancel_tree.part.0>
    8320:	39414680 	ldrb	w0, [x20, #81]
    8324:	17ffff7f 	b	8120 <fwp_main_thread+0x290>
    8328:	d2800013 	mov	x19, #0x0                   	// #0
    832c:	9101c2b4 	add	x20, x21, #0x70
    8330:	f9414680 	ldr	x0, [x20, #648]
    8334:	b5ffea80 	cbnz	x0, 8084 <fwp_main_thread+0x1f4>
    8338:	f9413a80 	ldr	x0, [x20, #624]
    833c:	97ffeab9 	bl	2e20 <fwp_mem_free>
    8340:	f9013a9f 	str	xzr, [x20, #624]
    8344:	f901429f 	str	xzr, [x20, #640]
    8348:	f9415680 	ldr	x0, [x20, #680]
    834c:	b40002d3 	cbz	x19, 83a4 <fwp_main_thread+0x514>
    8350:	f900567f 	str	xzr, [x19, #168]
    8354:	f9005e7f 	str	xzr, [x19, #184]
    8358:	b902a29f 	str	wzr, [x20, #672]
    835c:	eb00027f 	cmp	x19, x0
    8360:	54ffe9e0 	b.eq	809c <fwp_main_thread+0x20c>  // b.none
    8364:	f90083f9 	str	x25, [sp, #256]
    8368:	97ffe462 	bl	14f0 <abort@plt>
    836c:	d0ffffc0 	adrp	x0, 2000 <fwp_cancel_tree.part.0+0x70>
    8370:	91161000 	add	x0, x0, #0x584
    8374:	940001d3 	bl	8ac0 <atexit>
    8378:	17fffed7 	b	7ed4 <fwp_main_thread+0x44>
    837c:	97ffe8dd 	bl	26f0 <fwp_heap_init>
    8380:	17fffed2 	b	7ec8 <fwp_main_thread+0x38>
    8384:	97fff5a3 	bl	5a10 <f0>
    8388:	f9014e60 	str	x0, [x19, #664]
    838c:	52800021 	mov	w1, #0x1                   	// #1
    8390:	b9029661 	str	w1, [x19, #660]
    8394:	17fffefc 	b	7f84 <fwp_main_thread+0xf4>
    8398:	aa0003e1 	mov	x1, x0
    839c:	f9002293 	str	x19, [x20, #64]
    83a0:	17ffff12 	b	7fe8 <fwp_main_thread+0x158>
    83a4:	b902a29f 	str	wzr, [x20, #672]
    83a8:	b4fff080 	cbz	x0, 81b8 <fwp_main_thread+0x328>
    83ac:	17ffffee 	b	8364 <fwp_main_thread+0x4d4>
    83b0:	90000000 	adrp	x0, 8000 <fwp_main_thread+0x170>
    83b4:	9139e000 	add	x0, x0, #0xe78
    83b8:	a90f63f7 	stp	x23, x24, [sp, #240]
    83bc:	f90083f9 	str	x25, [sp, #256]
    83c0:	97ffe738 	bl	20a0 <fwp_trap>
    83c4:	f90083f9 	str	x25, [sp, #256]
    83c8:	97ffe436 	bl	14a0 <__stack_chk_fail@plt>
    83cc:	d503201f 	nop

00000000000083d0 <__divti3>:
    83d0:	d503245f 	bti	c
    83d4:	d2800004 	mov	x4, #0x0                   	// #0
    83d8:	b7f80721 	tbnz	x1, #63, 84bc <__divti3+0xec>
    83dc:	b6f80083 	tbz	x3, #63, 83ec <__divti3+0x1c>
    83e0:	eb0203e2 	negs	x2, x2
    83e4:	aa2403e4 	mvn	x4, x4
    83e8:	da0303e3 	ngc	x3, x3
    83ec:	aa0203e6 	mov	x6, x2
    83f0:	aa0003e7 	mov	x7, x0
    83f4:	aa0103e5 	mov	x5, x1
    83f8:	b5000583 	cbnz	x3, 84a8 <__divti3+0xd8>
    83fc:	eb01005f 	cmp	x2, x1
    8400:	54000e69 	b.ls	85cc <__divti3+0x1fc>  // b.plast
    8404:	dac01040 	clz	x0, x2
    8408:	b40000e0 	cbz	x0, 8424 <__divti3+0x54>
    840c:	4b0003e1 	neg	w1, w0
    8410:	9ac020a5 	lsl	x5, x5, x0
    8414:	9ac02046 	lsl	x6, x2, x0
    8418:	9ac124e1 	lsr	x1, x7, x1
    841c:	aa050025 	orr	x5, x1, x5
    8420:	9ac020e7 	lsl	x7, x7, x0
    8424:	d360fcc8 	lsr	x8, x6, #32
    8428:	92407cc2 	and	x2, x6, #0xffffffff
    842c:	9ac808a3 	udiv	x3, x5, x8
    8430:	9b089465 	msub	x5, x3, x8, x5
    8434:	aa0303e0 	mov	x0, x3
    8438:	9b037c41 	mul	x1, x2, x3
    843c:	93c780a5 	extr	x5, x5, x7, #32
    8440:	eb05003f 	cmp	x1, x5
    8444:	540000a9 	b.ls	8458 <__divti3+0x88>  // b.plast
    8448:	ab0500c5 	adds	x5, x6, x5
    844c:	d1000460 	sub	x0, x3, #0x1
    8450:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8454:	540015a8 	b.hi	8708 <__divti3+0x338>  // b.pmore
    8458:	cb0100a5 	sub	x5, x5, x1
    845c:	9ac808a3 	udiv	x3, x5, x8
    8460:	9b089465 	msub	x5, x3, x8, x5
    8464:	aa0303e1 	mov	x1, x3
    8468:	9b037c42 	mul	x2, x2, x3
    846c:	aa0703e3 	mov	x3, x7
    8470:	b3607ca3 	bfi	x3, x5, #32, #32
    8474:	eb03005f 	cmp	x2, x3
    8478:	540000c9 	b.ls	8490 <__divti3+0xc0>  // b.plast
    847c:	ab0300c3 	adds	x3, x6, x3
    8480:	d1000425 	sub	x5, x1, #0x1
    8484:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8488:	d1000821 	sub	x1, x1, #0x2
    848c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    8490:	aa008020 	orr	x0, x1, x0, lsl #32
    8494:	d2800001 	mov	x1, #0x0                   	// #0
    8498:	b4000064 	cbz	x4, 84a4 <__divti3+0xd4>
    849c:	eb0003e0 	negs	x0, x0
    84a0:	da0103e1 	ngc	x1, x1
    84a4:	d65f03c0 	ret
    84a8:	eb01007f 	cmp	x3, x1
    84ac:	54000109 	b.ls	84cc <__divti3+0xfc>  // b.plast
    84b0:	d2800001 	mov	x1, #0x0                   	// #0
    84b4:	d2800000 	mov	x0, #0x0                   	// #0
    84b8:	17fffff8 	b	8498 <__divti3+0xc8>
    84bc:	eb0003e0 	negs	x0, x0
    84c0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    84c4:	da0103e1 	ngc	x1, x1
    84c8:	17ffffc5 	b	83dc <__divti3+0xc>
    84cc:	dac01067 	clz	x7, x3
    84d0:	b40010e7 	cbz	x7, 86ec <__divti3+0x31c>
    84d4:	d2800805 	mov	x5, #0x40                  	// #64
    84d8:	cb0700a5 	sub	x5, x5, x7
    84dc:	9ac72063 	lsl	x3, x3, x7
    84e0:	9ac52448 	lsr	x8, x2, x5
    84e4:	aa030108 	orr	x8, x8, x3
    84e8:	9ac52426 	lsr	x6, x1, x5
    84ec:	92407d0a 	and	x10, x8, #0xffffffff
    84f0:	d360fd09 	lsr	x9, x8, #32
    84f4:	9ac52403 	lsr	x3, x0, x5
    84f8:	9ac72021 	lsl	x1, x1, x7
    84fc:	aa010063 	orr	x3, x3, x1
    8500:	9ac72042 	lsl	x2, x2, x7
    8504:	9ac908cb 	udiv	x11, x6, x9
    8508:	9b099965 	msub	x5, x11, x9, x6
    850c:	aa0b03e1 	mov	x1, x11
    8510:	9b0b7d46 	mul	x6, x10, x11
    8514:	93c380a5 	extr	x5, x5, x3, #32
    8518:	eb0500df 	cmp	x6, x5
    851c:	540000a9 	b.ls	8530 <__divti3+0x160>  // b.plast
    8520:	ab050105 	adds	x5, x8, x5
    8524:	d1000561 	sub	x1, x11, #0x1
    8528:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    852c:	54000f48 	b.hi	8714 <__divti3+0x344>  // b.pmore
    8530:	cb0600a6 	sub	x6, x5, x6
    8534:	9ac908cb 	udiv	x11, x6, x9
    8538:	9b099969 	msub	x9, x11, x9, x6
    853c:	aa0b03e5 	mov	x5, x11
    8540:	9b0b7d4a 	mul	x10, x10, x11
    8544:	b3607d23 	bfi	x3, x9, #32, #32
    8548:	eb03015f 	cmp	x10, x3
    854c:	540000a9 	b.ls	8560 <__divti3+0x190>  // b.plast
    8550:	ab030103 	adds	x3, x8, x3
    8554:	d1000565 	sub	x5, x11, #0x1
    8558:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    855c:	54000e28 	b.hi	8720 <__divti3+0x350>  // b.pmore
    8560:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8564:	92407c48 	and	x8, x2, #0xffffffff
    8568:	2a0503e5 	mov	w5, w5
    856c:	d360fc42 	lsr	x2, x2, #32
    8570:	d360fc26 	lsr	x6, x1, #32
    8574:	cb0a0063 	sub	x3, x3, x10
    8578:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    857c:	9b087caa 	mul	x10, x5, x8
    8580:	9b087cc8 	mul	x8, x6, x8
    8584:	9b0220a5 	madd	x5, x5, x2, x8
    8588:	9b027cc6 	mul	x6, x6, x2
    858c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    8590:	8b0900c5 	add	x5, x6, x9
    8594:	eb02011f 	cmp	x8, x2
    8598:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    859c:	8b4280c6 	add	x6, x6, x2, lsr #32
    85a0:	eb06007f 	cmp	x3, x6
    85a4:	540000e3 	b.cc	85c0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    85a8:	92407d4a 	and	x10, x10, #0xffffffff
    85ac:	9ac72000 	lsl	x0, x0, x7
    85b0:	8b028142 	add	x2, x10, x2, lsl #32
    85b4:	eb02001f 	cmp	x0, x2
    85b8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    85bc:	54000a01 	b.ne	86fc <__divti3+0x32c>  // b.any
    85c0:	d1000420 	sub	x0, x1, #0x1
    85c4:	d2800001 	mov	x1, #0x0                   	// #0
    85c8:	17ffffb4 	b	8498 <__divti3+0xc8>
    85cc:	b5000062 	cbnz	x2, 85d8 <__divti3+0x208>
    85d0:	d2800022 	mov	x2, #0x1                   	// #1
    85d4:	9ac30846 	udiv	x6, x2, x3
    85d8:	dac010c8 	clz	x8, x6
    85dc:	b5000408 	cbnz	x8, 865c <__divti3+0x28c>
    85e0:	d360fcc9 	lsr	x9, x6, #32
    85e4:	92407cc5 	and	x5, x6, #0xffffffff
    85e8:	cb060023 	sub	x3, x1, x6
    85ec:	d2800021 	mov	x1, #0x1                   	// #1
    85f0:	9ac90868 	udiv	x8, x3, x9
    85f4:	9b098d03 	msub	x3, x8, x9, x3
    85f8:	aa0803e0 	mov	x0, x8
    85fc:	9b057d02 	mul	x2, x8, x5
    8600:	93c78063 	extr	x3, x3, x7, #32
    8604:	eb03005f 	cmp	x2, x3
    8608:	540000a9 	b.ls	861c <__divti3+0x24c>  // b.plast
    860c:	ab0300c3 	adds	x3, x6, x3
    8610:	d1000500 	sub	x0, x8, #0x1
    8614:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8618:	54000968 	b.hi	8744 <__divti3+0x374>  // b.pmore
    861c:	cb020063 	sub	x3, x3, x2
    8620:	9ac90862 	udiv	x2, x3, x9
    8624:	aa0203e8 	mov	x8, x2
    8628:	9b098c42 	msub	x2, x2, x9, x3
    862c:	aa0703e3 	mov	x3, x7
    8630:	9b057d05 	mul	x5, x8, x5
    8634:	b3607c43 	bfi	x3, x2, #32, #32
    8638:	eb0300bf 	cmp	x5, x3
    863c:	540000c9 	b.ls	8654 <__divti3+0x284>  // b.plast
    8640:	ab0300c2 	adds	x2, x6, x3
    8644:	d1000503 	sub	x3, x8, #0x1
    8648:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    864c:	d1000908 	sub	x8, x8, #0x2
    8650:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    8654:	aa008100 	orr	x0, x8, x0, lsl #32
    8658:	17ffff90 	b	8498 <__divti3+0xc8>
    865c:	9ac820c6 	lsl	x6, x6, x8
    8660:	d2800803 	mov	x3, #0x40                  	// #64
    8664:	cb080063 	sub	x3, x3, x8
    8668:	d360fcc9 	lsr	x9, x6, #32
    866c:	9ac82027 	lsl	x7, x1, x8
    8670:	92407cc5 	and	x5, x6, #0xffffffff
    8674:	9ac32422 	lsr	x2, x1, x3
    8678:	9ac32403 	lsr	x3, x0, x3
    867c:	aa070063 	orr	x3, x3, x7
    8680:	9ac9084a 	udiv	x10, x2, x9
    8684:	9ac82007 	lsl	x7, x0, x8
    8688:	9b098940 	msub	x0, x10, x9, x2
    868c:	aa0a03e1 	mov	x1, x10
    8690:	9b0a7ca2 	mul	x2, x5, x10
    8694:	93c38000 	extr	x0, x0, x3, #32
    8698:	eb00005f 	cmp	x2, x0
    869c:	540000a9 	b.ls	86b0 <__divti3+0x2e0>  // b.plast
    86a0:	ab0000c0 	adds	x0, x6, x0
    86a4:	d1000541 	sub	x1, x10, #0x1
    86a8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    86ac:	54000468 	b.hi	8738 <__divti3+0x368>  // b.pmore
    86b0:	cb020000 	sub	x0, x0, x2
    86b4:	9ac9080a 	udiv	x10, x0, x9
    86b8:	9b098140 	msub	x0, x10, x9, x0
    86bc:	aa0a03e2 	mov	x2, x10
    86c0:	9b0a7ca8 	mul	x8, x5, x10
    86c4:	b3607c03 	bfi	x3, x0, #32, #32
    86c8:	eb03011f 	cmp	x8, x3
    86cc:	540000a9 	b.ls	86e0 <__divti3+0x310>  // b.plast
    86d0:	ab0300c3 	adds	x3, x6, x3
    86d4:	d1000542 	sub	x2, x10, #0x1
    86d8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    86dc:	54000288 	b.hi	872c <__divti3+0x35c>  // b.pmore
    86e0:	cb080063 	sub	x3, x3, x8
    86e4:	aa018041 	orr	x1, x2, x1, lsl #32
    86e8:	17ffffc2 	b	85f0 <__divti3+0x220>
    86ec:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    86f0:	d2800001 	mov	x1, #0x0                   	// #0
    86f4:	9a9f87e0 	cset	x0, ls	// ls = plast
    86f8:	17ffff68 	b	8498 <__divti3+0xc8>
    86fc:	aa0103e0 	mov	x0, x1
    8700:	d2800001 	mov	x1, #0x0                   	// #0
    8704:	17ffff65 	b	8498 <__divti3+0xc8>
    8708:	d1000860 	sub	x0, x3, #0x2
    870c:	8b0600a5 	add	x5, x5, x6
    8710:	17ffff52 	b	8458 <__divti3+0x88>
    8714:	d1000961 	sub	x1, x11, #0x2
    8718:	8b0800a5 	add	x5, x5, x8
    871c:	17ffff85 	b	8530 <__divti3+0x160>
    8720:	d1000965 	sub	x5, x11, #0x2
    8724:	8b080063 	add	x3, x3, x8
    8728:	17ffff8e 	b	8560 <__divti3+0x190>
    872c:	d1000942 	sub	x2, x10, #0x2
    8730:	8b060063 	add	x3, x3, x6
    8734:	17ffffeb 	b	86e0 <__divti3+0x310>
    8738:	d1000941 	sub	x1, x10, #0x2
    873c:	8b060000 	add	x0, x0, x6
    8740:	17ffffdc 	b	86b0 <__divti3+0x2e0>
    8744:	d1000900 	sub	x0, x8, #0x2
    8748:	8b060063 	add	x3, x3, x6
    874c:	17ffffb4 	b	861c <__divti3+0x24c>

0000000000008750 <__modti3>:
    8750:	d503245f 	bti	c
    8754:	d2800004 	mov	x4, #0x0                   	// #0
    8758:	b6f80081 	tbz	x1, #63, 8768 <__modti3+0x18>
    875c:	eb0003e0 	negs	x0, x0
    8760:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8764:	da0103e1 	ngc	x1, x1
    8768:	f100007f 	cmp	x3, #0x0
    876c:	5400128b 	b.lt	89bc <__modti3+0x26c>  // b.tstop
    8770:	aa0003e7 	mov	x7, x0
    8774:	aa0103e6 	mov	x6, x1
    8778:	540004e1 	b.ne	8814 <__modti3+0xc4>  // b.any
    877c:	eb02003f 	cmp	x1, x2
    8780:	54000dc2 	b.cs	8938 <__modti3+0x1e8>  // b.hs, b.nlast
    8784:	dac01043 	clz	x3, x2
    8788:	aa0303e5 	mov	x5, x3
    878c:	b40000e3 	cbz	x3, 87a8 <__modti3+0x58>
    8790:	4b0303e6 	neg	w6, w3
    8794:	9ac32021 	lsl	x1, x1, x3
    8798:	9ac32042 	lsl	x2, x2, x3
    879c:	9ac62406 	lsr	x6, x0, x6
    87a0:	aa0100c6 	orr	x6, x6, x1
    87a4:	9ac32007 	lsl	x7, x0, x3
    87a8:	d360fc40 	lsr	x0, x2, #32
    87ac:	92407c43 	and	x3, x2, #0xffffffff
    87b0:	9ac008c1 	udiv	x1, x6, x0
    87b4:	9b009826 	msub	x6, x1, x0, x6
    87b8:	9b017c61 	mul	x1, x3, x1
    87bc:	93c780c6 	extr	x6, x6, x7, #32
    87c0:	eb06003f 	cmp	x1, x6
    87c4:	540000a9 	b.ls	87d8 <__modti3+0x88>  // b.plast
    87c8:	ab060046 	adds	x6, x2, x6
    87cc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    87d0:	8b0200c8 	add	x8, x6, x2
    87d4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    87d8:	cb0100c6 	sub	x6, x6, x1
    87dc:	9ac008c8 	udiv	x8, x6, x0
    87e0:	9b009901 	msub	x1, x8, x0, x6
    87e4:	aa0703e0 	mov	x0, x7
    87e8:	9b087c63 	mul	x3, x3, x8
    87ec:	b3607c20 	bfi	x0, x1, #32, #32
    87f0:	eb00007f 	cmp	x3, x0
    87f4:	54001088 	b.hi	8a04 <__modti3+0x2b4>  // b.pmore
    87f8:	cb030000 	sub	x0, x0, x3
    87fc:	9ac52400 	lsr	x0, x0, x5
    8800:	d2800001 	mov	x1, #0x0                   	// #0
    8804:	b4000064 	cbz	x4, 8810 <__modti3+0xc0>
    8808:	eb0003e0 	negs	x0, x0
    880c:	da0103e1 	ngc	x1, x1
    8810:	d65f03c0 	ret
    8814:	dac01066 	clz	x6, x3
    8818:	eb03003f 	cmp	x1, x3
    881c:	54ffff43 	b.cc	8804 <__modti3+0xb4>  // b.lo, b.ul, b.last
    8820:	93407cc5 	sxtw	x5, w6
    8824:	d2800808 	mov	x8, #0x40                  	// #64
    8828:	cb050108 	sub	x8, x8, x5
    882c:	9ac62063 	lsl	x3, x3, x6
    8830:	9ac62025 	lsl	x5, x1, x6
    8834:	9ac82447 	lsr	x7, x2, x8
    8838:	aa0300e7 	orr	x7, x7, x3
    883c:	9ac82423 	lsr	x3, x1, x8
    8840:	92407cec 	and	x12, x7, #0xffffffff
    8844:	d360fcea 	lsr	x10, x7, #32
    8848:	9ac82401 	lsr	x1, x0, x8
    884c:	aa050021 	orr	x1, x1, x5
    8850:	9ac62042 	lsl	x2, x2, x6
    8854:	9ac62000 	lsl	x0, x0, x6
    8858:	9aca086b 	udiv	x11, x3, x10
    885c:	9b0a8d63 	msub	x3, x11, x10, x3
    8860:	aa0b03e5 	mov	x5, x11
    8864:	9b0b7d89 	mul	x9, x12, x11
    8868:	93c18063 	extr	x3, x3, x1, #32
    886c:	eb03013f 	cmp	x9, x3
    8870:	540000a9 	b.ls	8884 <__modti3+0x134>  // b.plast
    8874:	ab0300e3 	adds	x3, x7, x3
    8878:	d1000565 	sub	x5, x11, #0x1
    887c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    8880:	54001168 	b.hi	8aac <__modti3+0x35c>  // b.pmore
    8884:	cb090063 	sub	x3, x3, x9
    8888:	9aca086b 	udiv	x11, x3, x10
    888c:	9b0a8d6a 	msub	x10, x11, x10, x3
    8890:	aa0b03e9 	mov	x9, x11
    8894:	9b0b7d8c 	mul	x12, x12, x11
    8898:	b3607d41 	bfi	x1, x10, #32, #32
    889c:	eb01019f 	cmp	x12, x1
    88a0:	540000a9 	b.ls	88b4 <__modti3+0x164>  // b.plast
    88a4:	ab0100e1 	adds	x1, x7, x1
    88a8:	d1000569 	sub	x9, x11, #0x1
    88ac:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    88b0:	54000f88 	b.hi	8aa0 <__modti3+0x350>  // b.pmore
    88b4:	aa058123 	orr	x3, x9, x5, lsl #32
    88b8:	92407c4b 	and	x11, x2, #0xffffffff
    88bc:	2a0903e9 	mov	w9, w9
    88c0:	d360fc4a 	lsr	x10, x2, #32
    88c4:	d360fc63 	lsr	x3, x3, #32
    88c8:	cb0c0021 	sub	x1, x1, x12
    88cc:	aa0a03ec 	mov	x12, x10
    88d0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    88d4:	9b0b7d25 	mul	x5, x9, x11
    88d8:	9b0b7c6b 	mul	x11, x3, x11
    88dc:	9b0a2d29 	madd	x9, x9, x10, x11
    88e0:	92407caa 	and	x10, x5, #0xffffffff
    88e4:	9b0c7c63 	mul	x3, x3, x12
    88e8:	8b458125 	add	x5, x9, x5, lsr #32
    88ec:	8b0d0069 	add	x9, x3, x13
    88f0:	eb05017f 	cmp	x11, x5
    88f4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    88f8:	8b058149 	add	x9, x10, x5, lsl #32
    88fc:	8b458063 	add	x3, x3, x5, lsr #32
    8900:	eb03003f 	cmp	x1, x3
    8904:	54000063 	b.cc	8910 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    8908:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    890c:	54000082 	b.cs	891c <__modti3+0x1cc>  // b.hs, b.nlast
    8910:	eb020129 	subs	x9, x9, x2
    8914:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    8918:	cb070063 	sub	x3, x3, x7
    891c:	eb090000 	subs	x0, x0, x9
    8920:	da030021 	sbc	x1, x1, x3
    8924:	9ac62400 	lsr	x0, x0, x6
    8928:	9ac82028 	lsl	x8, x1, x8
    892c:	aa000100 	orr	x0, x8, x0
    8930:	9ac62421 	lsr	x1, x1, x6
    8934:	17ffffb4 	b	8804 <__modti3+0xb4>
    8938:	b5000062 	cbnz	x2, 8944 <__modti3+0x1f4>
    893c:	d2800023 	mov	x3, #0x1                   	// #1
    8940:	9ac20862 	udiv	x2, x3, x2
    8944:	dac01048 	clz	x8, x2
    8948:	aa0803e5 	mov	x5, x8
    894c:	b5000668 	cbnz	x8, 8a18 <__modti3+0x2c8>
    8950:	cb020020 	sub	x0, x1, x2
    8954:	d360fc49 	lsr	x9, x2, #32
    8958:	92407c4a 	and	x10, x2, #0xffffffff
    895c:	9ac90801 	udiv	x1, x0, x9
    8960:	9b098020 	msub	x0, x1, x9, x0
    8964:	9b0a7c21 	mul	x1, x1, x10
    8968:	93c78000 	extr	x0, x0, x7, #32
    896c:	eb00003f 	cmp	x1, x0
    8970:	540000a9 	b.ls	8984 <__modti3+0x234>  // b.plast
    8974:	ab000040 	adds	x0, x2, x0
    8978:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    897c:	8b020003 	add	x3, x0, x2
    8980:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8984:	cb010001 	sub	x1, x0, x1
    8988:	9ac90820 	udiv	x0, x1, x9
    898c:	9b098403 	msub	x3, x0, x9, x1
    8990:	aa0703e1 	mov	x1, x7
    8994:	9b0a7c00 	mul	x0, x0, x10
    8998:	b3607c61 	bfi	x1, x3, #32, #32
    899c:	eb01001f 	cmp	x0, x1
    89a0:	540000a9 	b.ls	89b4 <__modti3+0x264>  // b.plast
    89a4:	ab010041 	adds	x1, x2, x1
    89a8:	8b020022 	add	x2, x1, x2
    89ac:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    89b0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    89b4:	cb000020 	sub	x0, x1, x0
    89b8:	17ffff91 	b	87fc <__modti3+0xac>
    89bc:	eb0203e5 	negs	x5, x2
    89c0:	aa0003e7 	mov	x7, x0
    89c4:	da0303e8 	ngc	x8, x3
    89c8:	aa0503e2 	mov	x2, x5
    89cc:	aa0803e3 	mov	x3, x8
    89d0:	aa0103e6 	mov	x6, x1
    89d4:	b4ffed48 	cbz	x8, 877c <__modti3+0x2c>
    89d8:	eb01011f 	cmp	x8, x1
    89dc:	54fff148 	b.hi	8804 <__modti3+0xb4>  // b.pmore
    89e0:	dac01109 	clz	x9, x8
    89e4:	2a0903e6 	mov	w6, w9
    89e8:	b5fff1c9 	cbnz	x9, 8820 <__modti3+0xd0>
    89ec:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    89f0:	54000068 	b.hi	89fc <__modti3+0x2ac>  // b.pmore
    89f4:	eb050007 	subs	x7, x0, x5
    89f8:	da080021 	sbc	x1, x1, x8
    89fc:	aa0703e0 	mov	x0, x7
    8a00:	17ffff81 	b	8804 <__modti3+0xb4>
    8a04:	ab000040 	adds	x0, x2, x0
    8a08:	8b020002 	add	x2, x0, x2
    8a0c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    8a10:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    8a14:	17ffff79 	b	87f8 <__modti3+0xa8>
    8a18:	9ac82042 	lsl	x2, x2, x8
    8a1c:	d2800803 	mov	x3, #0x40                  	// #64
    8a20:	cb080063 	sub	x3, x3, x8
    8a24:	d360fc49 	lsr	x9, x2, #32
    8a28:	9ac82027 	lsl	x7, x1, x8
    8a2c:	92407c4a 	and	x10, x2, #0xffffffff
    8a30:	9ac32426 	lsr	x6, x1, x3
    8a34:	9ac32403 	lsr	x3, x0, x3
    8a38:	aa070063 	orr	x3, x3, x7
    8a3c:	9ac908c1 	udiv	x1, x6, x9
    8a40:	9ac82007 	lsl	x7, x0, x8
    8a44:	9b099820 	msub	x0, x1, x9, x6
    8a48:	9b017d41 	mul	x1, x10, x1
    8a4c:	93c38000 	extr	x0, x0, x3, #32
    8a50:	eb00003f 	cmp	x1, x0
    8a54:	540000a9 	b.ls	8a68 <__modti3+0x318>  // b.plast
    8a58:	ab000040 	adds	x0, x2, x0
    8a5c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8a60:	8b020006 	add	x6, x0, x2
    8a64:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    8a68:	cb010000 	sub	x0, x0, x1
    8a6c:	9ac90801 	udiv	x1, x0, x9
    8a70:	9b098026 	msub	x6, x1, x9, x0
    8a74:	aa0303e0 	mov	x0, x3
    8a78:	9b017d41 	mul	x1, x10, x1
    8a7c:	b3607cc0 	bfi	x0, x6, #32, #32
    8a80:	eb00003f 	cmp	x1, x0
    8a84:	540000a9 	b.ls	8a98 <__modti3+0x348>  // b.plast
    8a88:	ab000040 	adds	x0, x2, x0
    8a8c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    8a90:	8b020003 	add	x3, x0, x2
    8a94:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    8a98:	cb010000 	sub	x0, x0, x1
    8a9c:	17ffffb0 	b	895c <__modti3+0x20c>
    8aa0:	d1000969 	sub	x9, x11, #0x2
    8aa4:	8b070021 	add	x1, x1, x7
    8aa8:	17ffff83 	b	88b4 <__modti3+0x164>
    8aac:	d1000965 	sub	x5, x11, #0x2
    8ab0:	8b070063 	add	x3, x3, x7
    8ab4:	17ffff74 	b	8884 <__modti3+0x134>
    8ab8:	d503201f 	nop
    8abc:	d503201f 	nop

0000000000008ac0 <atexit>:
    8ac0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    8ac4:	900000c2 	adrp	x2, 20000 <__data_start>
    8ac8:	d2800001 	mov	x1, #0x0                   	// #0
    8acc:	910003fd 	mov	x29, sp
    8ad0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    8ad4:	f9400442 	ldr	x2, [x2, #8]
    8ad8:	17ffe232 	b	13a0 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000008adc <_fini>:
    8adc:	d503201f 	nop
    8ae0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    8ae4:	910003fd 	mov	x29, sp
    8ae8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    8aec:	d65f03c0 	ret
