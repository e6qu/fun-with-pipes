
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-ad-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002680 <_init>:
    2680:	d503201f 	nop
    2684:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2688:	910003fd 	mov	x29, sp
    268c:	9400019a 	bl	2cf4 <call_weak_fn>
    2690:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2694:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026a0 <.plt>:
    26a0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26a4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26a8:	f946fe11 	ldr	x17, [x16, #3576]
    26ac:	9137e210 	add	x16, x16, #0xdf8
    26b0:	d61f0220 	br	x17
    26b4:	d503201f 	nop
    26b8:	d503201f 	nop
    26bc:	d503201f 	nop

00000000000026c0 <memcpy@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26c4:	f9470211 	ldr	x17, [x16, #3584]
    26c8:	91380210 	add	x16, x16, #0xe00
    26cc:	d61f0220 	br	x17

00000000000026d0 <sigaltstack@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26d4:	f9470611 	ldr	x17, [x16, #3592]
    26d8:	91382210 	add	x16, x16, #0xe08
    26dc:	d61f0220 	br	x17

00000000000026e0 <_exit@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26e4:	f9470a11 	ldr	x17, [x16, #3600]
    26e8:	91384210 	add	x16, x16, #0xe10
    26ec:	d61f0220 	br	x17

00000000000026f0 <strlen@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26f4:	f9470e11 	ldr	x17, [x16, #3608]
    26f8:	91386210 	add	x16, x16, #0xe18
    26fc:	d61f0220 	br	x17

0000000000002700 <__sprintf_chk@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2704:	f9471211 	ldr	x17, [x16, #3616]
    2708:	91388210 	add	x16, x16, #0xe20
    270c:	d61f0220 	br	x17

0000000000002710 <exit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2714:	f9471611 	ldr	x17, [x16, #3624]
    2718:	9138a210 	add	x16, x16, #0xe28
    271c:	d61f0220 	br	x17

0000000000002720 <__libc_start_main@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2724:	f9471a11 	ldr	x17, [x16, #3632]
    2728:	9138c210 	add	x16, x16, #0xe30
    272c:	d61f0220 	br	x17

0000000000002730 <strtoll@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2734:	f9471e11 	ldr	x17, [x16, #3640]
    2738:	9138e210 	add	x16, x16, #0xe38
    273c:	d61f0220 	br	x17

0000000000002740 <strtod@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2744:	f9472211 	ldr	x17, [x16, #3648]
    2748:	91390210 	add	x16, x16, #0xe40
    274c:	d61f0220 	br	x17

0000000000002750 <__cxa_finalize@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2754:	f9472611 	ldr	x17, [x16, #3656]
    2758:	91392210 	add	x16, x16, #0xe48
    275c:	d61f0220 	br	x17

0000000000002760 <__cxa_atexit@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2764:	f9472a11 	ldr	x17, [x16, #3664]
    2768:	91394210 	add	x16, x16, #0xe50
    276c:	d61f0220 	br	x17

0000000000002770 <pthread_attr_init@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2774:	f9472e11 	ldr	x17, [x16, #3672]
    2778:	91396210 	add	x16, x16, #0xe58
    277c:	d61f0220 	br	x17

0000000000002780 <fputc@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2784:	f9473211 	ldr	x17, [x16, #3680]
    2788:	91398210 	add	x16, x16, #0xe60
    278c:	d61f0220 	br	x17

0000000000002790 <clock_gettime@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2794:	f9473611 	ldr	x17, [x16, #3688]
    2798:	9139a210 	add	x16, x16, #0xe68
    279c:	d61f0220 	br	x17

00000000000027a0 <setvbuf@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27a4:	f9473a11 	ldr	x17, [x16, #3696]
    27a8:	9139c210 	add	x16, x16, #0xe70
    27ac:	d61f0220 	br	x17

00000000000027b0 <__memcpy_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27b4:	f9473e11 	ldr	x17, [x16, #3704]
    27b8:	9139e210 	add	x16, x16, #0xe78
    27bc:	d61f0220 	br	x17

00000000000027c0 <signal@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27c4:	f9474211 	ldr	x17, [x16, #3712]
    27c8:	913a0210 	add	x16, x16, #0xe80
    27cc:	d61f0220 	br	x17

00000000000027d0 <__snprintf_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27d4:	f9474611 	ldr	x17, [x16, #3720]
    27d8:	913a2210 	add	x16, x16, #0xe88
    27dc:	d61f0220 	br	x17

00000000000027e0 <fclose@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27e4:	f9474a11 	ldr	x17, [x16, #3728]
    27e8:	913a4210 	add	x16, x16, #0xe90
    27ec:	d61f0220 	br	x17

00000000000027f0 <fopen@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27f4:	f9474e11 	ldr	x17, [x16, #3736]
    27f8:	913a6210 	add	x16, x16, #0xe98
    27fc:	d61f0220 	br	x17

0000000000002800 <malloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2804:	f9475211 	ldr	x17, [x16, #3744]
    2808:	913a8210 	add	x16, x16, #0xea0
    280c:	d61f0220 	br	x17

0000000000002810 <pthread_attr_destroy@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2814:	f9475611 	ldr	x17, [x16, #3752]
    2818:	913aa210 	add	x16, x16, #0xea8
    281c:	d61f0220 	br	x17

0000000000002820 <sigemptyset@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2824:	f9475a11 	ldr	x17, [x16, #3760]
    2828:	913ac210 	add	x16, x16, #0xeb0
    282c:	d61f0220 	br	x17

0000000000002830 <memset@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2834:	f9475e11 	ldr	x17, [x16, #3768]
    2838:	913ae210 	add	x16, x16, #0xeb8
    283c:	d61f0220 	br	x17

0000000000002840 <calloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2844:	f9476211 	ldr	x17, [x16, #3776]
    2848:	913b0210 	add	x16, x16, #0xec0
    284c:	d61f0220 	br	x17

0000000000002850 <realloc@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2854:	f9476611 	ldr	x17, [x16, #3784]
    2858:	913b2210 	add	x16, x16, #0xec8
    285c:	d61f0220 	br	x17

0000000000002860 <__stack_chk_fail@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2864:	f9476a11 	ldr	x17, [x16, #3792]
    2868:	913b4210 	add	x16, x16, #0xed0
    286c:	d61f0220 	br	x17

0000000000002870 <close@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2874:	f9476e11 	ldr	x17, [x16, #3800]
    2878:	913b6210 	add	x16, x16, #0xed8
    287c:	d61f0220 	br	x17

0000000000002880 <sigaction@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2884:	f9477211 	ldr	x17, [x16, #3808]
    2888:	913b8210 	add	x16, x16, #0xee0
    288c:	d61f0220 	br	x17

0000000000002890 <__gmon_start__@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2894:	f9477611 	ldr	x17, [x16, #3816]
    2898:	913ba210 	add	x16, x16, #0xee8
    289c:	d61f0220 	br	x17

00000000000028a0 <write@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28a4:	f9477a11 	ldr	x17, [x16, #3824]
    28a8:	913bc210 	add	x16, x16, #0xef0
    28ac:	d61f0220 	br	x17

00000000000028b0 <abort@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28b4:	f9477e11 	ldr	x17, [x16, #3832]
    28b8:	913be210 	add	x16, x16, #0xef8
    28bc:	d61f0220 	br	x17

00000000000028c0 <swapcontext@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28c4:	f9478211 	ldr	x17, [x16, #3840]
    28c8:	913c0210 	add	x16, x16, #0xf00
    28cc:	d61f0220 	br	x17

00000000000028d0 <__fprintf_chk@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28d4:	f9478611 	ldr	x17, [x16, #3848]
    28d8:	913c2210 	add	x16, x16, #0xf08
    28dc:	d61f0220 	br	x17

00000000000028e0 <strcmp@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28e4:	f9478a11 	ldr	x17, [x16, #3856]
    28e8:	913c4210 	add	x16, x16, #0xf10
    28ec:	d61f0220 	br	x17

00000000000028f0 <mmap@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28f4:	f9478e11 	ldr	x17, [x16, #3864]
    28f8:	913c6210 	add	x16, x16, #0xf18
    28fc:	d61f0220 	br	x17

0000000000002900 <strtol@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2904:	f9479211 	ldr	x17, [x16, #3872]
    2908:	913c8210 	add	x16, x16, #0xf20
    290c:	d61f0220 	br	x17

0000000000002910 <strtof@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2914:	f9479611 	ldr	x17, [x16, #3880]
    2918:	913ca210 	add	x16, x16, #0xf28
    291c:	d61f0220 	br	x17

0000000000002920 <free@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2924:	f9479a11 	ldr	x17, [x16, #3888]
    2928:	913cc210 	add	x16, x16, #0xf30
    292c:	d61f0220 	br	x17

0000000000002930 <nanosleep@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2934:	f9479e11 	ldr	x17, [x16, #3896]
    2938:	913ce210 	add	x16, x16, #0xf38
    293c:	d61f0220 	br	x17

0000000000002940 <strchr@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2944:	f947a211 	ldr	x17, [x16, #3904]
    2948:	913d0210 	add	x16, x16, #0xf40
    294c:	d61f0220 	br	x17

0000000000002950 <strtoull@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2954:	f947a611 	ldr	x17, [x16, #3912]
    2958:	913d2210 	add	x16, x16, #0xf48
    295c:	d61f0220 	br	x17

0000000000002960 <fwrite@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2964:	f947aa11 	ldr	x17, [x16, #3920]
    2968:	913d4210 	add	x16, x16, #0xf50
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_create@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2974:	f947ae11 	ldr	x17, [x16, #3928]
    2978:	913d6210 	add	x16, x16, #0xf58
    297c:	d61f0220 	br	x17

0000000000002980 <munmap@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2984:	f947b211 	ldr	x17, [x16, #3936]
    2988:	913d8210 	add	x16, x16, #0xf60
    298c:	d61f0220 	br	x17

0000000000002990 <fflush@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2994:	f947b611 	ldr	x17, [x16, #3944]
    2998:	913da210 	add	x16, x16, #0xf68
    299c:	d61f0220 	br	x17

00000000000029a0 <strcpy@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29a4:	f947ba11 	ldr	x17, [x16, #3952]
    29a8:	913dc210 	add	x16, x16, #0xf70
    29ac:	d61f0220 	br	x17

00000000000029b0 <sysconf@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29b4:	f947be11 	ldr	x17, [x16, #3960]
    29b8:	913de210 	add	x16, x16, #0xf78
    29bc:	d61f0220 	br	x17

00000000000029c0 <strstr@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29c4:	f947c211 	ldr	x17, [x16, #3968]
    29c8:	913e0210 	add	x16, x16, #0xf80
    29cc:	d61f0220 	br	x17

00000000000029d0 <_Exit@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29d4:	f947c611 	ldr	x17, [x16, #3976]
    29d8:	913e2210 	add	x16, x16, #0xf88
    29dc:	d61f0220 	br	x17

00000000000029e0 <pthread_join@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29e4:	f947ca11 	ldr	x17, [x16, #3984]
    29e8:	913e4210 	add	x16, x16, #0xf90
    29ec:	d61f0220 	br	x17

00000000000029f0 <getenv@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29f4:	f947ce11 	ldr	x17, [x16, #3992]
    29f8:	913e6210 	add	x16, x16, #0xf98
    29fc:	d61f0220 	br	x17

0000000000002a00 <mprotect@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a04:	f947d211 	ldr	x17, [x16, #4000]
    2a08:	913e8210 	add	x16, x16, #0xfa0
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fgets@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a14:	f947d611 	ldr	x17, [x16, #4008]
    2a18:	913ea210 	add	x16, x16, #0xfa8
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_attr_setstacksize@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a24:	f947da11 	ldr	x17, [x16, #4016]
    2a28:	913ec210 	add	x16, x16, #0xfb0
    2a2c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a40 <fwp_trap_overflow.constprop.0>:
    2a40:	d10243ff 	sub	sp, sp, #0x90
    2a44:	d2800c03 	mov	x3, #0x60                  	// #96
    2a48:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2a4c:	f947f421 	ldr	x1, [x1, #4072]
    2a50:	f0000045 	adrp	x5, d000 <fwp_main_thread+0x42c>
    2a54:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a58:	9101c3fd 	add	x29, sp, #0x70
    2a5c:	913580a5 	add	x5, x5, #0xd60
    2a60:	f0000044 	adrp	x4, d000 <fwp_main_thread+0x42c>
    2a64:	f90043f3 	str	x19, [sp, #128]
    2a68:	9135a084 	add	x4, x4, #0xd68
    2a6c:	910023f3 	add	x19, sp, #0x8
    2a70:	f9400022 	ldr	x2, [x1]
    2a74:	f90037e2 	str	x2, [sp, #104]
    2a78:	d2800002 	mov	x2, #0x0                   	// #0
    2a7c:	aa0303e1 	mov	x1, x3
    2a80:	52800042 	mov	w2, #0x2                   	// #2
    2a84:	aa1303e0 	mov	x0, x19
    2a88:	97ffff52 	bl	27d0 <__snprintf_chk@plt>
    2a8c:	aa1303e0 	mov	x0, x19
    2a90:	94000615 	bl	42e4 <fwp_trap>
    2a94:	d503201f 	nop
    2a98:	d503201f 	nop
    2a9c:	d503201f 	nop

0000000000002aa0 <main>:
    2aa0:	d10243ff 	sub	sp, sp, #0x90
    2aa4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2aa8:	f947f400 	ldr	x0, [x0, #4072]
    2aac:	a9067bfd 	stp	x29, x30, [sp, #96]
    2ab0:	910183fd 	add	x29, sp, #0x60
    2ab4:	a90753f3 	stp	x19, x20, [sp, #112]
    2ab8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc88>
    2abc:	f947ee94 	ldr	x20, [x20, #4056]
    2ac0:	f9400282 	ldr	x2, [x20]
    2ac4:	f90043f5 	str	x21, [sp, #128]
    2ac8:	d00000f5 	adrp	x21, 20000 <__data_start>
    2acc:	910142a1 	add	x1, x21, #0x50
    2ad0:	f9400003 	ldr	x3, [x0]
    2ad4:	f9002fe3 	str	x3, [sp, #88]
    2ad8:	d2800003 	mov	x3, #0x0                   	// #0
    2adc:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe340>
    2ae0:	910de000 	add	x0, x0, #0x378
    2ae4:	f9004822 	str	x2, [x1, #144]
    2ae8:	f9008420 	str	x0, [x1, #264]
    2aec:	9400081d 	bl	4b60 <fwp_now_ns>
    2af0:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x780>
    2af4:	9104a000 	add	x0, x0, #0x128
    2af8:	97ffffbe 	bl	29f0 <getenv@plt>
    2afc:	b4000080 	cbz	x0, 2b0c <main+0x6c>
    2b00:	39400001 	ldrb	w1, [x0]
    2b04:	aa0003f3 	mov	x19, x0
    2b08:	350008c1 	cbnz	w1, 2c20 <main+0x180>
    2b0c:	910023e1 	add	x1, sp, #0x8
    2b10:	52800000 	mov	w0, #0x0                   	// #0
    2b14:	97ffff1f 	bl	2790 <clock_gettime@plt>
    2b18:	350007e0 	cbnz	w0, 2c14 <main+0x174>
    2b1c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b20:	d2994003 	mov	x3, #0xca00                	// #51712
    2b24:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b28:	9b037c01 	mul	x1, x0, x3
    2b2c:	9b437c00 	smulh	x0, x0, x3
    2b30:	ab020021 	adds	x1, x1, x2
    2b34:	937ffc42 	asr	x2, x2, #63
    2b38:	9a020000 	adc	x0, x0, x2
    2b3c:	f100003f 	cmp	x1, #0x0
    2b40:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b44:	b5000620 	cbnz	x0, 2c08 <main+0x168>
    2b48:	f9400280 	ldr	x0, [x20]
    2b4c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b50:	52800002 	mov	w2, #0x0                   	// #0
    2b54:	d2800001 	mov	x1, #0x0                   	// #0
    2b58:	910063f3 	add	x19, sp, #0x18
    2b5c:	97ffff11 	bl	27a0 <setvbuf@plt>
    2b60:	d2800021 	mov	x1, #0x1                   	// #1
    2b64:	528001a0 	mov	w0, #0xd                   	// #13
    2b68:	97ffff16 	bl	27c0 <signal@plt>
    2b6c:	aa1303e0 	mov	x0, x19
    2b70:	97ffff00 	bl	2770 <pthread_attr_init@plt>
    2b74:	350007a0 	cbnz	w0, 2c68 <main+0x1c8>
    2b78:	aa1303e0 	mov	x0, x19
    2b7c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b80:	97ffffa8 	bl	2a20 <pthread_attr_setstacksize@plt>
    2b84:	35000660 	cbnz	w0, 2c50 <main+0x1b0>
    2b88:	aa1303e1 	mov	x1, x19
    2b8c:	910023e0 	add	x0, sp, #0x8
    2b90:	d0000042 	adrp	x2, c000 <f0+0x1aac>
    2b94:	d2800003 	mov	x3, #0x0                   	// #0
    2b98:	912f5042 	add	x2, x2, #0xbd4
    2b9c:	97ffff75 	bl	2970 <pthread_create@plt>
    2ba0:	2a0003e1 	mov	w1, w0
    2ba4:	aa1303e0 	mov	x0, x19
    2ba8:	2a0103f3 	mov	w19, w1
    2bac:	97ffff19 	bl	2810 <pthread_attr_destroy@plt>
    2bb0:	350006a0 	cbnz	w0, 2c84 <main+0x1e4>
    2bb4:	35000613 	cbnz	w19, 2c74 <main+0x1d4>
    2bb8:	f94007e0 	ldr	x0, [sp, #8]
    2bbc:	d2800001 	mov	x1, #0x0                   	// #0
    2bc0:	97ffff88 	bl	29e0 <pthread_join@plt>
    2bc4:	35000600 	cbnz	w0, 2c84 <main+0x1e4>
    2bc8:	f9400280 	ldr	x0, [x20]
    2bcc:	910142b5 	add	x21, x21, #0x50
    2bd0:	97ffff70 	bl	2990 <fflush@plt>
    2bd4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2bd8:	f947f421 	ldr	x1, [x1, #4072]
    2bdc:	b943caa0 	ldr	w0, [x21, #968]
    2be0:	f9402fe3 	ldr	x3, [sp, #88]
    2be4:	f9400022 	ldr	x2, [x1]
    2be8:	eb020063 	subs	x3, x3, x2
    2bec:	d2800002 	mov	x2, #0x0                   	// #0
    2bf0:	54000481 	b.ne	2c80 <main+0x1e0>  // b.any
    2bf4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bf8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bfc:	f94043f5 	ldr	x21, [sp, #128]
    2c00:	910243ff 	add	sp, sp, #0x90
    2c04:	d65f03c0 	ret
    2c08:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x780>
    2c0c:	91056000 	add	x0, x0, #0x158
    2c10:	940005b5 	bl	42e4 <fwp_trap>
    2c14:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x780>
    2c18:	9104e000 	add	x0, x0, #0x138
    2c1c:	940005b2 	bl	42e4 <fwp_trap>
    2c20:	910003e1 	mov	x1, sp
    2c24:	52800142 	mov	w2, #0xa                   	// #10
    2c28:	97ffff4a 	bl	2950 <strtoull@plt>
    2c2c:	f94003e0 	ldr	x0, [sp]
    2c30:	39400000 	ldrb	w0, [x0]
    2c34:	35fff6c0 	cbnz	w0, 2b0c <main+0x6c>
    2c38:	39400260 	ldrb	w0, [x19]
    2c3c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c40:	5100ac00 	sub	w0, w0, #0x2b
    2c44:	6a01001f 	tst	w0, w1
    2c48:	54fff620 	b.eq	2b0c <main+0x6c>  // b.none
    2c4c:	17ffffbf 	b	2b48 <main+0xa8>
    2c50:	aa1303e0 	mov	x0, x19
    2c54:	97fffeef 	bl	2810 <pthread_attr_destroy@plt>
    2c58:	35000160 	cbnz	w0, 2c84 <main+0x1e4>
    2c5c:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x780>
    2c60:	9106c000 	add	x0, x0, #0x1b0
    2c64:	940005a0 	bl	42e4 <fwp_trap>
    2c68:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x780>
    2c6c:	91060000 	add	x0, x0, #0x180
    2c70:	9400059d 	bl	42e4 <fwp_trap>
    2c74:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x780>
    2c78:	91076000 	add	x0, x0, #0x1d8
    2c7c:	9400059a 	bl	42e4 <fwp_trap>
    2c80:	97fffef8 	bl	2860 <__stack_chk_fail@plt>
    2c84:	97ffff0b 	bl	28b0 <abort@plt>
    2c88:	d503201f 	nop
    2c8c:	d503201f 	nop
    2c90:	d503201f 	nop
    2c94:	d503201f 	nop
    2c98:	d503201f 	nop
    2c9c:	d503201f 	nop
    2ca0:	d503201f 	nop
    2ca4:	d503201f 	nop
    2ca8:	d503201f 	nop
    2cac:	d503201f 	nop
    2cb0:	d503201f 	nop
    2cb4:	d503201f 	nop
    2cb8:	d503201f 	nop
    2cbc:	d503201f 	nop

0000000000002cc0 <_start>:
    2cc0:	d503201f 	nop
    2cc4:	d280001d 	mov	x29, #0x0                   	// #0
    2cc8:	d280001e 	mov	x30, #0x0                   	// #0
    2ccc:	aa0003e5 	mov	x5, x0
    2cd0:	f94003e1 	ldr	x1, [sp]
    2cd4:	910023e2 	add	x2, sp, #0x8
    2cd8:	910003e6 	mov	x6, sp
    2cdc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2ce0:	f947f800 	ldr	x0, [x0, #4080]
    2ce4:	d2800003 	mov	x3, #0x0                   	// #0
    2ce8:	d2800004 	mov	x4, #0x0                   	// #0
    2cec:	97fffe8d 	bl	2720 <__libc_start_main@plt>
    2cf0:	97fffef0 	bl	28b0 <abort@plt>

0000000000002cf4 <call_weak_fn>:
    2cf4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2cf8:	f947f000 	ldr	x0, [x0, #4064]
    2cfc:	b4000040 	cbz	x0, 2d04 <call_weak_fn+0x10>
    2d00:	17fffee4 	b	2890 <__gmon_start__@plt>
    2d04:	d65f03c0 	ret
    2d08:	d503201f 	nop
    2d0c:	d503201f 	nop

0000000000002d10 <deregister_tm_clones>:
    2d10:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d14:	91010000 	add	x0, x0, #0x40
    2d18:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d1c:	91010021 	add	x1, x1, #0x40
    2d20:	eb00003f 	cmp	x1, x0
    2d24:	540000c0 	b.eq	2d3c <deregister_tm_clones+0x2c>  // b.none
    2d28:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2d2c:	f947e021 	ldr	x1, [x1, #4032]
    2d30:	b4000061 	cbz	x1, 2d3c <deregister_tm_clones+0x2c>
    2d34:	aa0103f0 	mov	x16, x1
    2d38:	d61f0200 	br	x16
    2d3c:	d65f03c0 	ret

0000000000002d40 <register_tm_clones>:
    2d40:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d44:	91010000 	add	x0, x0, #0x40
    2d48:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d4c:	91010021 	add	x1, x1, #0x40
    2d50:	cb000021 	sub	x1, x1, x0
    2d54:	d37ffc22 	lsr	x2, x1, #63
    2d58:	8b810c41 	add	x1, x2, x1, asr #3
    2d5c:	9341fc21 	asr	x1, x1, #1
    2d60:	b40000c1 	cbz	x1, 2d78 <register_tm_clones+0x38>
    2d64:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    2d68:	f947fc42 	ldr	x2, [x2, #4088]
    2d6c:	b4000062 	cbz	x2, 2d78 <register_tm_clones+0x38>
    2d70:	aa0203f0 	mov	x16, x2
    2d74:	d61f0200 	br	x16
    2d78:	d65f03c0 	ret
    2d7c:	d503201f 	nop

0000000000002d80 <__do_global_dtors_aux>:
    2d80:	d503233f 	paciasp
    2d84:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d88:	910003fd 	mov	x29, sp
    2d8c:	f9000bf3 	str	x19, [sp, #16]
    2d90:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d94:	39410260 	ldrb	w0, [x19, #64]
    2d98:	37000140 	tbnz	w0, #0, 2dc0 <__do_global_dtors_aux+0x40>
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2da0:	f947e400 	ldr	x0, [x0, #4040]
    2da4:	b4000080 	cbz	x0, 2db4 <__do_global_dtors_aux+0x34>
    2da8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dac:	f9400400 	ldr	x0, [x0, #8]
    2db0:	97fffe68 	bl	2750 <__cxa_finalize@plt>
    2db4:	97ffffd7 	bl	2d10 <deregister_tm_clones>
    2db8:	52800020 	mov	w0, #0x1                   	// #1
    2dbc:	39010260 	strb	w0, [x19, #64]
    2dc0:	f9400bf3 	ldr	x19, [sp, #16]
    2dc4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2dc8:	d50323bf 	autiasp
    2dcc:	d65f03c0 	ret

0000000000002dd0 <frame_dummy>:
    2dd0:	d503245f 	bti	c
    2dd4:	17ffffdb 	b	2d40 <register_tm_clones>
    2dd8:	d503201f 	nop
    2ddc:	d503201f 	nop

0000000000002de0 <fwp_fmt_u128>:
    2de0:	d10183ff 	sub	sp, sp, #0x60
    2de4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2de8:	f947f421 	ldr	x1, [x1, #4072]
    2dec:	a9057bfd 	stp	x29, x30, [sp, #80]
    2df0:	910143fd 	add	x29, sp, #0x50
    2df4:	f9400024 	ldr	x4, [x1]
    2df8:	f90027e4 	str	x4, [sp, #72]
    2dfc:	d2800004 	mov	x4, #0x0                   	// #0
    2e00:	aa030041 	orr	x1, x2, x3
    2e04:	b5000361 	cbnz	x1, 2e70 <fwp_fmt_u128+0x90>
    2e08:	910023e9 	add	x9, sp, #0x8
    2e0c:	52800601 	mov	w1, #0x30                  	// #48
    2e10:	5280002d 	mov	w13, #0x1                   	// #1
    2e14:	390023e1 	strb	w1, [sp, #8]
    2e18:	93407dad 	sxtw	x13, w13
    2e1c:	aa0d03e1 	mov	x1, x13
    2e20:	8b0d0004 	add	x4, x0, x13
    2e24:	d503201f 	nop
    2e28:	8b010123 	add	x3, x9, x1
    2e2c:	cb0103e2 	neg	x2, x1
    2e30:	d1000421 	sub	x1, x1, #0x1
    2e34:	385ff063 	ldurb	w3, [x3, #-1]
    2e38:	38226883 	strb	w3, [x4, x2]
    2e3c:	35ffff61 	cbnz	w1, 2e28 <fwp_fmt_u128+0x48>
    2e40:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2e44:	f947f421 	ldr	x1, [x1, #4072]
    2e48:	382d681f 	strb	wzr, [x0, x13]
    2e4c:	aa0103e0 	mov	x0, x1
    2e50:	f94027e2 	ldr	x2, [sp, #72]
    2e54:	f9400001 	ldr	x1, [x0]
    2e58:	eb010042 	subs	x2, x2, x1
    2e5c:	d2800001 	mov	x1, #0x0                   	// #0
    2e60:	54000561 	b.ne	2f0c <fwp_fmt_u128+0x12c>  // b.any
    2e64:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e68:	910183ff 	add	sp, sp, #0x60
    2e6c:	d65f03c0 	ret
    2e70:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x780>
    2e74:	9120c021 	add	x1, x1, #0x830
    2e78:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e7c:	910023e9 	add	x9, sp, #0x8
    2e80:	d2800027 	mov	x7, #0x1                   	// #1
    2e84:	f29999af 	movk	x15, #0xcccd
    2e88:	a9402826 	ldp	x6, x10, [x1]
    2e8c:	d503201f 	nop
    2e90:	ab030041 	adds	x1, x2, x3
    2e94:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e98:	aa0303eb 	mov	x11, x3
    2e9c:	8b070128 	add	x8, x9, x7
    2ea0:	aa0203ee 	mov	x14, x2
    2ea4:	aa0703ed 	mov	x13, x7
    2ea8:	910004e7 	add	x7, x7, #0x1
    2eac:	9bcf7c24 	umulh	x4, x1, x15
    2eb0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2eb4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2eb8:	cb040021 	sub	x1, x1, x4
    2ebc:	eb010041 	subs	x1, x2, x1
    2ec0:	da1f0063 	sbc	x3, x3, xzr
    2ec4:	9bc67c24 	umulh	x4, x1, x6
    2ec8:	9b061064 	madd	x4, x3, x6, x4
    2ecc:	9b067c2c 	mul	x12, x1, x6
    2ed0:	9b0a1024 	madd	x4, x1, x10, x4
    2ed4:	9bc67c25 	umulh	x5, x1, x6
    2ed8:	9b061465 	madd	x5, x3, x6, x5
    2edc:	9b0a1425 	madd	x5, x1, x10, x5
    2ee0:	93cc0484 	extr	x4, x4, x12, #1
    2ee4:	8b040884 	add	x4, x4, x4, lsl #2
    2ee8:	d341fca3 	lsr	x3, x5, #1
    2eec:	cb040444 	sub	x4, x2, x4, lsl #1
    2ef0:	93cc04a2 	extr	x2, x5, x12, #1
    2ef4:	1100c084 	add	w4, w4, #0x30
    2ef8:	381ff104 	sturb	w4, [x8, #-1]
    2efc:	b5fffcab 	cbnz	x11, 2e90 <fwp_fmt_u128+0xb0>
    2f00:	f10025df 	cmp	x14, #0x9
    2f04:	54fffc68 	b.hi	2e90 <fwp_fmt_u128+0xb0>  // b.pmore
    2f08:	17ffffc4 	b	2e18 <fwp_fmt_u128+0x38>
    2f0c:	97fffe55 	bl	2860 <__stack_chk_fail@plt>

0000000000002f10 <fwp_range_release>:
    2f10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f14:	910003fd 	mov	x29, sp
    2f18:	f9400801 	ldr	x1, [x0, #16]
    2f1c:	f9000bf3 	str	x19, [sp, #16]
    2f20:	aa0003f3 	mov	x19, x0
    2f24:	b4000061 	cbz	x1, 2f30 <fwp_range_release+0x20>
    2f28:	f9400400 	ldr	x0, [x0, #8]
    2f2c:	d63f0020 	blr	x1
    2f30:	f9400260 	ldr	x0, [x19]
    2f34:	f9400e61 	ldr	x1, [x19, #24]
    2f38:	f9400bf3 	ldr	x19, [sp, #16]
    2f3c:	aa0103f0 	mov	x16, x1
    2f40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f44:	d61f0200 	br	x16
    2f48:	d503201f 	nop
    2f4c:	d503201f 	nop

0000000000002f50 <ad_raw_record>:
    2f50:	2a0303e4 	mov	w4, w3
    2f54:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f58:	910140e6 	add	x6, x7, #0x50
    2f5c:	b9001003 	str	w3, [x0, #16]
    2f60:	f940040c 	ldr	x12, [x0, #8]
    2f64:	910080ca 	add	x10, x6, #0x20
    2f68:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f6c:	910100c9 	add	x9, x6, #0x40
    2f70:	910180cb 	add	x11, x6, #0x60
    2f74:	a9000801 	stp	x1, x2, [x0]
    2f78:	cb0c00a1 	sub	x1, x5, x12
    2f7c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f80:	8b020021 	add	x1, x1, x2
    2f84:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f88:	91000508 	add	x8, x8, #0x1
    2f8c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f90:	8b0200a5 	add	x5, x5, x2
    2f94:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f98:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f9c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fa0:	eb0c003f 	cmp	x1, x12
    2fa4:	54000049 	b.ls	2fac <ad_raw_record+0x5c>  // b.plast
    2fa8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fac:	910140e1 	add	x1, x7, #0x50
    2fb0:	ad400021 	ldp	q1, q0, [x1]
    2fb4:	f9404022 	ldr	x2, [x1, #128]
    2fb8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2fbc:	5ef1b800 	addp	d0, v0.2d
    2fc0:	9e660000 	fmov	x0, d0
    2fc4:	eb00005f 	cmp	x2, x0
    2fc8:	54000042 	b.cs	2fd0 <ad_raw_record+0x80>  // b.hs, b.nlast
    2fcc:	fd004020 	str	d0, [x1, #128]
    2fd0:	d65f03c0 	ret

0000000000002fd4 <fwp_tape_unlink_scope>:
    2fd4:	f9402003 	ldr	x3, [x0, #64]
    2fd8:	b4000223 	cbz	x3, 301c <fwp_tape_unlink_scope+0x48>
    2fdc:	29490402 	ldp	w2, w1, [x0, #72]
    2fe0:	37f80202 	tbnz	w2, #31, 3020 <fwp_tape_unlink_scope+0x4c>
    2fe4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fe8:	52800b03 	mov	w3, #0x58                  	// #88
    2fec:	f9406c84 	ldr	x4, [x4, #216]
    2ff0:	9b231043 	smaddl	x3, w2, w3, x4
    2ff4:	b9004c61 	str	w1, [x3, #76]
    2ff8:	37f800c1 	tbnz	w1, #31, 3010 <fwp_tape_unlink_scope+0x3c>
    2ffc:	d00000e3 	adrp	x3, 20000 <__data_start>
    3000:	52800b04 	mov	w4, #0x58                  	// #88
    3004:	f9406c63 	ldr	x3, [x3, #216]
    3008:	9b240c21 	smaddl	x1, w1, w4, x3
    300c:	b9004822 	str	w2, [x1, #72]
    3010:	2f000400 	mvni	v0.2s, #0x0
    3014:	f900201f 	str	xzr, [x0, #64]
    3018:	fd002400 	str	d0, [x0, #72]
    301c:	d65f03c0 	ret
    3020:	b9000061 	str	w1, [x3]
    3024:	17fffff5 	b	2ff8 <fwp_tape_unlink_scope+0x24>
    3028:	d503201f 	nop
    302c:	d503201f 	nop

0000000000003030 <fwp_args173>:
    3030:	d65f03c0 	ret

0000000000003034 <fwp_flush>:
    3034:	b00000e0 	adrp	x0, 20000 <__data_start>
    3038:	f9407000 	ldr	x0, [x0, #224]
    303c:	b4000120 	cbz	x0, 3060 <fwp_flush+0x2c>
    3040:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3044:	910003fd 	mov	x29, sp
    3048:	97fffe52 	bl	2990 <fflush@plt>
    304c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3050:	f947ec00 	ldr	x0, [x0, #4056]
    3054:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3058:	f9400000 	ldr	x0, [x0]
    305c:	17fffe4d 	b	2990 <fflush@plt>
    3060:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3064:	f947ec00 	ldr	x0, [x0, #4056]
    3068:	f9400000 	ldr	x0, [x0]
    306c:	17fffe49 	b	2990 <fflush@plt>

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	91014043 	add	x3, x2, #0x50
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9404c60 	ldr	x0, [x3, #152]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe43 	bl	29b0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdb8 	b	27c0 <signal@plt>
    30e4:	91014042 	add	x2, x2, #0x50
    30e8:	f9405040 	ldr	x0, [x2, #160]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9405441 	ldr	x1, [x2, #168]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffc9 	bl	3034 <fwp_flush>
    3114:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x780>
    3118:	91204021 	add	x1, x1, #0x810
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffddf 	bl	28a0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd6d 	bl	26e0 <_exit@plt>

0000000000003130 <fwp_heap_oom>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800262 	mov	x2, #0x13                  	// #19
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    3150:	91222000 	add	x0, x0, #0x888
    3154:	97fffe03 	bl	2960 <fwrite@plt>
    3158:	d2800000 	mov	x0, #0x0                   	// #0
    315c:	97fffe0d 	bl	2990 <fflush@plt>
    3160:	52800cc0 	mov	w0, #0x66                  	// #102
    3164:	97fffe1b 	bl	29d0 <_Exit@plt>
    3168:	d503201f 	nop
    316c:	d503201f 	nop

0000000000003170 <fwp_heap_chunks>:
    3170:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3174:	910003fd 	mov	x29, sp
    3178:	a90153f3 	stp	x19, x20, [sp, #16]
    317c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3180:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    3184:	911882a1 	add	x1, x21, #0x620
    3188:	f100041f 	cmp	x0, #0x1
    318c:	54000ca0 	b.eq	3320 <fwp_heap_chunks+0x1b0>  // b.none
    3190:	f949f822 	ldr	x2, [x1, #5104]
    3194:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9e0>
    3198:	912840a5 	add	x5, x5, #0xa10
    319c:	911882a1 	add	x1, x21, #0x620
    31a0:	f949ec34 	ldr	x20, [x1, #5080]
    31a4:	eb14005f 	cmp	x2, x20
    31a8:	54000c42 	b.cs	3330 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ac:	f949fc23 	ldr	x3, [x1, #5112]
    31b0:	8b020841 	add	x1, x2, x2, lsl #2
    31b4:	d2800004 	mov	x4, #0x0                   	// #0
    31b8:	8b010c61 	add	x1, x3, x1, lsl #3
    31bc:	14000009 	b	31e0 <fwp_heap_chunks+0x70>
    31c0:	91000483 	add	x3, x4, #0x1
    31c4:	eb03001f 	cmp	x0, x3
    31c8:	54000940 	b.eq	32f0 <fwp_heap_chunks+0x180>  // b.none
    31cc:	91000442 	add	x2, x2, #0x1
    31d0:	aa0303e4 	mov	x4, x3
    31d4:	9100a021 	add	x1, x1, #0x28
    31d8:	eb02029f 	cmp	x20, x2
    31dc:	54000100 	b.eq	31fc <fwp_heap_chunks+0x8c>  // b.none
    31e0:	39400023 	ldrb	w3, [x1]
    31e4:	34fffee3 	cbz	w3, 31c0 <fwp_heap_chunks+0x50>
    31e8:	91000442 	add	x2, x2, #0x1
    31ec:	9100a021 	add	x1, x1, #0x28
    31f0:	d2800004 	mov	x4, #0x0                   	// #0
    31f4:	eb02029f 	cmp	x20, x2
    31f8:	54ffff41 	b.ne	31e0 <fwp_heap_chunks+0x70>  // b.any
    31fc:	cb040294 	sub	x20, x20, x4
    3200:	f9001bf7 	str	x23, [sp, #48]
    3204:	911882b7 	add	x23, x21, #0x620
    3208:	8b140013 	add	x19, x0, x20
    320c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3210:	f949f2e0 	ldr	x0, [x23, #5088]
    3214:	cb040021 	sub	x1, x1, x4
    3218:	f90a1ae1 	str	x1, [x23, #5168]
    321c:	eb00027f 	cmp	x19, x0
    3220:	54000429 	b.ls	32a4 <fwp_heap_chunks+0x134>  // b.plast
    3224:	f949eae1 	ldr	x1, [x23, #5072]
    3228:	eb01027f 	cmp	x19, x1
    322c:	54000888 	b.hi	333c <fwp_heap_chunks+0x1cc>  // b.pmore
    3230:	91010276 	add	x22, x19, #0x40
    3234:	52800062 	mov	w2, #0x3                   	// #3
    3238:	f949dae3 	ldr	x3, [x23, #5040]
    323c:	eb0102df 	cmp	x22, x1
    3240:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3244:	cb0002c1 	sub	x1, x22, x0
    3248:	8b004060 	add	x0, x3, x0, lsl #16
    324c:	d370bc21 	lsl	x1, x1, #16
    3250:	97fffdec 	bl	2a00 <mprotect@plt>
    3254:	35000740 	cbnz	w0, 333c <fwp_heap_chunks+0x1cc>
    3258:	528003c0 	mov	w0, #0x1e                  	// #30
    325c:	97fffdd5 	bl	29b0 <sysconf@plt>
    3260:	f949f2e2 	ldr	x2, [x23, #5088]
    3264:	cb0003e5 	neg	x5, x0
    3268:	aa0003e4 	mov	x4, x0
    326c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3270:	f949fee0 	ldr	x0, [x23, #5112]
    3274:	8b020843 	add	x3, x2, x2, lsl #2
    3278:	52800062 	mov	w2, #0x3                   	// #3
    327c:	8b010c01 	add	x1, x0, x1, lsl #3
    3280:	8b030c03 	add	x3, x0, x3, lsl #3
    3284:	d1000421 	sub	x1, x1, #0x1
    3288:	8a050060 	and	x0, x3, x5
    328c:	8b040021 	add	x1, x1, x4
    3290:	8a050021 	and	x1, x1, x5
    3294:	cb000021 	sub	x1, x1, x0
    3298:	97fffdda 	bl	2a00 <mprotect@plt>
    329c:	35000500 	cbnz	w0, 333c <fwp_heap_chunks+0x1cc>
    32a0:	f909f2f6 	str	x22, [x23, #5088]
    32a4:	911882b5 	add	x21, x21, #0x620
    32a8:	d370be60 	lsl	x0, x19, #16
    32ac:	f949e6a1 	ldr	x1, [x21, #5064]
    32b0:	f909eeb3 	str	x19, [x21, #5080]
    32b4:	eb01001f 	cmp	x0, x1
    32b8:	540000e8 	b.hi	32d4 <fwp_heap_chunks+0x164>  // b.pmore
    32bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32c0:	aa1403e0 	mov	x0, x20
    32c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32c8:	f9401bf7 	ldr	x23, [sp, #48]
    32cc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32d0:	d65f03c0 	ret
    32d4:	f9401bf7 	ldr	x23, [sp, #48]
    32d8:	f909e6a0 	str	x0, [x21, #5064]
    32dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32e0:	aa1403e0 	mov	x0, x20
    32e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32e8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ec:	d65f03c0 	ret
    32f0:	911882b5 	add	x21, x21, #0x620
    32f4:	91000441 	add	x1, x2, #0x1
    32f8:	f90000a1 	str	x1, [x5]
    32fc:	cb040054 	sub	x20, x2, x4
    3300:	f94a1aa1 	ldr	x1, [x21, #5168]
    3304:	cb000020 	sub	x0, x1, x0
    3308:	f90a1aa0 	str	x0, [x21, #5168]
    330c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3310:	aa1403e0 	mov	x0, x20
    3314:	a94153f3 	ldp	x19, x20, [sp, #16]
    3318:	a8c47bfd 	ldp	x29, x30, [sp], #64
    331c:	d65f03c0 	ret
    3320:	f949f422 	ldr	x2, [x1, #5096]
    3324:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9e0>
    3328:	912820a5 	add	x5, x5, #0xa08
    332c:	17ffff9c 	b	319c <fwp_heap_chunks+0x2c>
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	f9001bf7 	str	x23, [sp, #48]
    3338:	17ffffb3 	b	3204 <fwp_heap_chunks+0x94>
    333c:	97ffff7d 	bl	3130 <fwp_heap_oom>

0000000000003340 <ad_raw_fail>:
    3340:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc88>
    3344:	f947e884 	ldr	x4, [x4, #4048]
    3348:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    334c:	aa0003e3 	mov	x3, x0
    3350:	910003fd 	mov	x29, sp
    3354:	f9400080 	ldr	x0, [x4]
    3358:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x42c>
    335c:	91228042 	add	x2, x2, #0x8a0
    3360:	52800041 	mov	w1, #0x2                   	// #2
    3364:	97fffd5b 	bl	28d0 <__fprintf_chk@plt>
    3368:	52801d00 	mov	w0, #0xe8                  	// #232
    336c:	97fffce9 	bl	2710 <exit@plt>

0000000000003370 <ad_raw_report>:
    3370:	d10243ff 	sub	sp, sp, #0x90
    3374:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3378:	f947f400 	ldr	x0, [x0, #4072]
    337c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3380:	9100c3fd 	add	x29, sp, #0x30
    3384:	a9055bf5 	stp	x21, x22, [sp, #80]
    3388:	a90663f7 	stp	x23, x24, [sp, #96]
    338c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3390:	91014315 	add	x21, x24, #0x50
    3394:	a90453f3 	stp	x19, x20, [sp, #64]
    3398:	ad4002a1 	ldp	q1, q0, [x21]
    339c:	a9076bf9 	stp	x25, x26, [sp, #112]
    33a0:	a90873fb 	stp	x27, x28, [sp, #128]
    33a4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33a8:	f9400001 	ldr	x1, [x0]
    33ac:	f90017e1 	str	x1, [sp, #40]
    33b0:	d2800001 	mov	x1, #0x0                   	// #0
    33b4:	5ef1b800 	addp	d0, v0.2d
    33b8:	9e660014 	fmov	x20, d0
    33bc:	b5000d74 	cbnz	x20, 3568 <ad_raw_report+0x1f8>
    33c0:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc88>
    33c4:	f947ead6 	ldr	x22, [x22, #4048]
    33c8:	52800041 	mov	w1, #0x2                   	// #2
    33cc:	f94042a3 	ldr	x3, [x21, #128]
    33d0:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x42c>
    33d4:	f94002c0 	ldr	x0, [x22]
    33d8:	9123e042 	add	x2, x2, #0x8f8
    33dc:	f9405aa4 	ldr	x4, [x21, #176]
    33e0:	d2800005 	mov	x5, #0x0                   	// #0
    33e4:	d0000059 	adrp	x25, d000 <fwp_main_thread+0x42c>
    33e8:	d000005a 	adrp	x26, d000 <fwp_main_thread+0x42c>
    33ec:	91256339 	add	x25, x25, #0x958
    33f0:	9123035a 	add	x26, x26, #0x8c0
    33f4:	97fffd37 	bl	28d0 <__fprintf_chk@plt>
    33f8:	d2800013 	mov	x19, #0x0                   	// #0
    33fc:	b00000e0 	adrp	x0, 20000 <__data_start>
    3400:	91004000 	add	x0, x0, #0x10
    3404:	910023e1 	add	x1, sp, #0x8
    3408:	d000005b 	adrp	x27, d000 <fwp_main_thread+0x42c>
    340c:	aa0103fc 	mov	x28, x1
    3410:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3414:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3418:	f94002c0 	ldr	x0, [x22]
    341c:	b4000273 	cbz	x19, 3468 <ad_raw_report+0xf8>
    3420:	910182a3 	add	x3, x21, #0x60
    3424:	910102a2 	add	x2, x21, #0x40
    3428:	910082a1 	add	x1, x21, #0x20
    342c:	91232377 	add	x23, x27, #0x8c8
    3430:	f9400384 	ldr	x4, [x28]
    3434:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3438:	aa1703e3 	mov	x3, x23
    343c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3440:	aa1903e2 	mov	x2, x25
    3444:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3448:	91000673 	add	x19, x19, #0x1
    344c:	52800041 	mov	w1, #0x2                   	// #2
    3450:	97fffd20 	bl	28d0 <__fprintf_chk@plt>
    3454:	f100127f 	cmp	x19, #0x4
    3458:	540001c0 	b.eq	3490 <ad_raw_report+0x120>  // b.none
    345c:	f94002c0 	ldr	x0, [x22]
    3460:	9100239c 	add	x28, x28, #0x8
    3464:	b5fffdf3 	cbnz	x19, 3420 <ad_raw_report+0xb0>
    3468:	f8408784 	ldr	x4, [x28], #8
    346c:	aa1a03e3 	mov	x3, x26
    3470:	f94012a5 	ldr	x5, [x21, #32]
    3474:	aa1903e2 	mov	x2, x25
    3478:	f94022a6 	ldr	x6, [x21, #64]
    347c:	52800041 	mov	w1, #0x2                   	// #2
    3480:	f94032a7 	ldr	x7, [x21, #96]
    3484:	d2800033 	mov	x19, #0x1                   	// #1
    3488:	97fffd12 	bl	28d0 <__fprintf_chk@plt>
    348c:	17ffffe3 	b	3418 <ad_raw_report+0xa8>
    3490:	f94002c3 	ldr	x3, [x22]
    3494:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    3498:	d2800262 	mov	x2, #0x13                  	// #19
    349c:	91266000 	add	x0, x0, #0x998
    34a0:	d2800021 	mov	x1, #0x1                   	// #1
    34a4:	97fffd2f 	bl	2960 <fwrite@plt>
    34a8:	f9405ea0 	ldr	x0, [x21, #184]
    34ac:	b4000360 	cbz	x0, 3518 <ad_raw_report+0x1a8>
    34b0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbc0>
    34b4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbc0>
    34b8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbc0>
    34bc:	d0000043 	adrp	x3, d000 <fwp_main_thread+0x42c>
    34c0:	f94002c0 	ldr	x0, [x22]
    34c4:	d0000055 	adrp	x21, d000 <fwp_main_thread+0x42c>
    34c8:	f9422024 	ldr	x4, [x1, #1088]
    34cc:	91014318 	add	x24, x24, #0x50
    34d0:	f94224a5 	ldr	x5, [x5, #1096]
    34d4:	91110033 	add	x19, x1, #0x440
    34d8:	f9422846 	ldr	x6, [x2, #1104]
    34dc:	91230063 	add	x3, x3, #0x8c0
    34e0:	9126c2b5 	add	x21, x21, #0x9b0
    34e4:	14000005 	b	34f8 <ad_raw_report+0x188>
    34e8:	a9401664 	ldp	x4, x5, [x19]
    34ec:	aa1703e3 	mov	x3, x23
    34f0:	f94002c0 	ldr	x0, [x22]
    34f4:	f9400a66 	ldr	x6, [x19, #16]
    34f8:	aa1503e2 	mov	x2, x21
    34fc:	52800041 	mov	w1, #0x2                   	// #2
    3500:	97fffcf4 	bl	28d0 <__fprintf_chk@plt>
    3504:	f9405f00 	ldr	x0, [x24, #184]
    3508:	91000694 	add	x20, x20, #0x1
    350c:	91006273 	add	x19, x19, #0x18
    3510:	eb14001f 	cmp	x0, x20
    3514:	54fffea8 	b.hi	34e8 <ad_raw_report+0x178>  // b.pmore
    3518:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    351c:	f947f400 	ldr	x0, [x0, #4072]
    3520:	f94017e2 	ldr	x2, [sp, #40]
    3524:	f9400001 	ldr	x1, [x0]
    3528:	eb010042 	subs	x2, x2, x1
    352c:	d2800001 	mov	x1, #0x0                   	// #0
    3530:	54000221 	b.ne	3574 <ad_raw_report+0x204>  // b.any
    3534:	f94002c3 	ldr	x3, [x22]
    3538:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    353c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3540:	9127c000 	add	x0, x0, #0x9f0
    3544:	a94453f3 	ldp	x19, x20, [sp, #64]
    3548:	d2800082 	mov	x2, #0x4                   	// #4
    354c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3550:	d2800021 	mov	x1, #0x1                   	// #1
    3554:	a94663f7 	ldp	x23, x24, [sp, #96]
    3558:	a9476bf9 	ldp	x25, x26, [sp, #112]
    355c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3560:	910243ff 	add	sp, sp, #0x90
    3564:	17fffcff 	b	2960 <fwrite@plt>
    3568:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    356c:	91234000 	add	x0, x0, #0x8d0
    3570:	97ffff74 	bl	3340 <ad_raw_fail>
    3574:	97fffcbb 	bl	2860 <__stack_chk_fail@plt>
    3578:	d503201f 	nop
    357c:	d503201f 	nop

0000000000003580 <buf_grow>:
    3580:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3584:	910003fd 	mov	x29, sp
    3588:	a90153f3 	stp	x19, x20, [sp, #16]
    358c:	aa0003f4 	mov	x20, x0
    3590:	f9400400 	ldr	x0, [x0, #8]
    3594:	b100041f 	cmn	x0, #0x1
    3598:	54000400 	b.eq	3618 <buf_grow+0x98>  // b.none
    359c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35a0:	cb000042 	sub	x2, x2, x0
    35a4:	eb01005f 	cmp	x2, x1
    35a8:	54000383 	b.cc	3618 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ac:	f9400a82 	ldr	x2, [x20, #16]
    35b0:	91000421 	add	x1, x1, #0x1
    35b4:	8b000033 	add	x19, x1, x0
    35b8:	eb13005f 	cmp	x2, x19
    35bc:	54000242 	b.cs	3604 <buf_grow+0x84>  // b.hs, b.nlast
    35c0:	f100005f 	cmp	x2, #0x0
    35c4:	b5000262 	cbnz	x2, 3610 <buf_grow+0x90>
    35c8:	d2800802 	mov	x2, #0x40                  	// #64
    35cc:	eb02027f 	cmp	x19, x2
    35d0:	54000068 	b.hi	35dc <buf_grow+0x5c>  // b.pmore
    35d4:	14000005 	b	35e8 <buf_grow+0x68>
    35d8:	b7f800a2 	tbnz	x2, #63, 35ec <buf_grow+0x6c>
    35dc:	d37ff842 	lsl	x2, x2, #1
    35e0:	eb02027f 	cmp	x19, x2
    35e4:	54ffffa8 	b.hi	35d8 <buf_grow+0x58>  // b.pmore
    35e8:	aa0203f3 	mov	x19, x2
    35ec:	f9400280 	ldr	x0, [x20]
    35f0:	aa1303e1 	mov	x1, x19
    35f4:	97fffc97 	bl	2850 <realloc@plt>
    35f8:	b4000100 	cbz	x0, 3618 <buf_grow+0x98>
    35fc:	f9000280 	str	x0, [x20]
    3600:	f9000a93 	str	x19, [x20, #16]
    3604:	a94153f3 	ldp	x19, x20, [sp, #16]
    3608:	a8c27bfd 	ldp	x29, x30, [sp], #32
    360c:	d65f03c0 	ret
    3610:	54fffe6a 	b.ge	35dc <buf_grow+0x5c>  // b.tcont
    3614:	17fffff6 	b	35ec <buf_grow+0x6c>
    3618:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    361c:	f947e863 	ldr	x3, [x3, #4048]
    3620:	d2800262 	mov	x2, #0x13                  	// #19
    3624:	d2800021 	mov	x1, #0x1                   	// #1
    3628:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    362c:	91222000 	add	x0, x0, #0x888
    3630:	f9400063 	ldr	x3, [x3]
    3634:	97fffccb 	bl	2960 <fwrite@plt>
    3638:	d2800000 	mov	x0, #0x0                   	// #0
    363c:	97fffcd5 	bl	2990 <fflush@plt>
    3640:	52800cc0 	mov	w0, #0x66                  	// #102
    3644:	97fffce3 	bl	29d0 <_Exit@plt>
    3648:	d503201f 	nop
    364c:	d503201f 	nop

0000000000003650 <buf_put>:
    3650:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3654:	910003fd 	mov	x29, sp
    3658:	a90153f3 	stp	x19, x20, [sp, #16]
    365c:	aa0003f4 	mov	x20, x0
    3660:	aa0203f3 	mov	x19, x2
    3664:	f90013f5 	str	x21, [sp, #32]
    3668:	aa0103f5 	mov	x21, x1
    366c:	aa0203e1 	mov	x1, x2
    3670:	97ffffc4 	bl	3580 <buf_grow>
    3674:	a9400283 	ldp	x3, x0, [x20]
    3678:	aa1503e1 	mov	x1, x21
    367c:	aa1303e2 	mov	x2, x19
    3680:	8b000060 	add	x0, x3, x0
    3684:	97fffc0f 	bl	26c0 <memcpy@plt>
    3688:	a9400680 	ldp	x0, x1, [x20]
    368c:	8b010273 	add	x19, x19, x1
    3690:	f9000693 	str	x19, [x20, #8]
    3694:	3833681f 	strb	wzr, [x0, x19]
    3698:	a94153f3 	ldp	x19, x20, [sp, #16]
    369c:	f94013f5 	ldr	x21, [sp, #32]
    36a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36a4:	d65f03c0 	ret
    36a8:	d503201f 	nop
    36ac:	d503201f 	nop

00000000000036b0 <fwp_cancel_tree.part.0>:
    36b0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36b4:	91014022 	add	x2, x1, #0x50
    36b8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36bc:	52800023 	mov	w3, #0x1                   	// #1
    36c0:	910003fd 	mov	x29, sp
    36c4:	f9404c44 	ldr	x4, [x2, #152]
    36c8:	f9000bf3 	str	x19, [sp, #16]
    36cc:	39014403 	strb	w3, [x0, #81]
    36d0:	eb04001f 	cmp	x0, x4
    36d4:	54000160 	b.eq	3700 <fwp_cancel_tree.part.0+0x50>  // b.none
    36d8:	f9402804 	ldr	x4, [x0, #80]
    36dc:	f2001c9f 	tst	x4, #0xff000000ff
    36e0:	54000101 	b.ne	3700 <fwp_cancel_tree.part.0+0x50>  // b.any
    36e4:	f9406044 	ldr	x4, [x2, #192]
    36e8:	39015003 	strb	w3, [x0, #84]
    36ec:	f900801f 	str	xzr, [x0, #256]
    36f0:	b40001e4 	cbz	x4, 372c <fwp_cancel_tree.part.0+0x7c>
    36f4:	f9008080 	str	x0, [x4, #256]
    36f8:	91014021 	add	x1, x1, #0x50
    36fc:	f9006020 	str	x0, [x1, #192]
    3700:	f9401413 	ldr	x19, [x0, #40]
    3704:	b40000f3 	cbz	x19, 3720 <fwp_cancel_tree.part.0+0x70>
    3708:	39414261 	ldrb	w1, [x19, #80]
    370c:	aa1303e0 	mov	x0, x19
    3710:	37000041 	tbnz	w1, #0, 3718 <fwp_cancel_tree.part.0+0x68>
    3714:	97ffffe7 	bl	36b0 <fwp_cancel_tree.part.0>
    3718:	f9401a73 	ldr	x19, [x19, #48]
    371c:	b5ffff73 	cbnz	x19, 3708 <fwp_cancel_tree.part.0+0x58>
    3720:	f9400bf3 	ldr	x19, [sp, #16]
    3724:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3728:	d65f03c0 	ret
    372c:	f9006440 	str	x0, [x2, #200]
    3730:	17fffff2 	b	36f8 <fwp_cancel_tree.part.0+0x48>

0000000000003734 <fwp_finish_float>:
    3734:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3738:	528005c1 	mov	w1, #0x2e                  	// #46
    373c:	910003fd 	mov	x29, sp
    3740:	f9000bf3 	str	x19, [sp, #16]
    3744:	aa0003f3 	mov	x19, x0
    3748:	97fffc7e 	bl	2940 <strchr@plt>
    374c:	b4000080 	cbz	x0, 375c <fwp_finish_float+0x28>
    3750:	f9400bf3 	ldr	x19, [sp, #16]
    3754:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3758:	d65f03c0 	ret
    375c:	aa1303e0 	mov	x0, x19
    3760:	52800ca1 	mov	w1, #0x65                  	// #101
    3764:	97fffc77 	bl	2940 <strchr@plt>
    3768:	b5ffff40 	cbnz	x0, 3750 <fwp_finish_float+0x1c>
    376c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x42c>
    3770:	aa1303e0 	mov	x0, x19
    3774:	9127e021 	add	x1, x1, #0x9f8
    3778:	97fffc92 	bl	29c0 <strstr@plt>
    377c:	b5fffea0 	cbnz	x0, 3750 <fwp_finish_float+0x1c>
    3780:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x42c>
    3784:	aa1303e0 	mov	x0, x19
    3788:	91280021 	add	x1, x1, #0xa00
    378c:	97fffc8d 	bl	29c0 <strstr@plt>
    3790:	b5fffe00 	cbnz	x0, 3750 <fwp_finish_float+0x1c>
    3794:	aa1303e0 	mov	x0, x19
    3798:	97fffbd6 	bl	26f0 <strlen@plt>
    379c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x42c>
    37a0:	91282021 	add	x1, x1, #0xa08
    37a4:	8b000262 	add	x2, x19, x0
    37a8:	79400023 	ldrh	w3, [x1]
    37ac:	39400821 	ldrb	w1, [x1, #2]
    37b0:	78206a63 	strh	w3, [x19, x0]
    37b4:	39000841 	strb	w1, [x2, #2]
    37b8:	17ffffe6 	b	3750 <fwp_finish_float+0x1c>
    37bc:	d503201f 	nop

00000000000037c0 <fwp_format_g.constprop.0>:
    37c0:	d10483ff 	sub	sp, sp, #0x120
    37c4:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x42c>
    37c8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    37cc:	f947f442 	ldr	x2, [x2, #4072]
    37d0:	91284084 	add	x4, x4, #0xa10
    37d4:	a90b7bfd 	stp	x29, x30, [sp, #176]
    37d8:	9102c3fd 	add	x29, sp, #0xb0
    37dc:	d2800803 	mov	x3, #0x40                  	// #64
    37e0:	a90e63f7 	stp	x23, x24, [sp, #224]
    37e4:	93407c38 	sxtw	x24, w1
    37e8:	aa0303e1 	mov	x1, x3
    37ec:	fd008be8 	str	d8, [sp, #272]
    37f0:	1e604008 	fmov	d8, d0
    37f4:	a90c53f3 	stp	x19, x20, [sp, #192]
    37f8:	910083f4 	add	x20, sp, #0x20
    37fc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3800:	aa0003f5 	mov	x21, x0
    3804:	a91073fb 	stp	x27, x28, [sp, #256]
    3808:	5100071c 	sub	w28, w24, #0x1
    380c:	2a1c03e5 	mov	w5, w28
    3810:	f9400040 	ldr	x0, [x2]
    3814:	f90057e0 	str	x0, [sp, #168]
    3818:	d2800000 	mov	x0, #0x0                   	// #0
    381c:	52800042 	mov	w2, #0x2                   	// #2
    3820:	aa1403e0 	mov	x0, x20
    3824:	97fffbeb 	bl	27d0 <__snprintf_chk@plt>
    3828:	52800ca1 	mov	w1, #0x65                  	// #101
    382c:	aa1403e0 	mov	x0, x20
    3830:	97fffc44 	bl	2940 <strchr@plt>
    3834:	aa0003f3 	mov	x19, x0
    3838:	52800142 	mov	w2, #0xa                   	// #10
    383c:	91000400 	add	x0, x0, #0x1
    3840:	d2800001 	mov	x1, #0x0                   	// #0
    3844:	97fffc2f 	bl	2900 <strtol@plt>
    3848:	aa0003f7 	mov	x23, x0
    384c:	11001400 	add	w0, w0, #0x5
    3850:	7100541f 	cmp	w0, #0x15
    3854:	54000d68 	b.hi	3a00 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3858:	4b170385 	sub	w5, w28, w23
    385c:	710000bf 	cmp	w5, #0x0
    3860:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3864:	54000b80 	b.eq	39d4 <fwp_format_g.constprop.0+0x214>  // b.none
    3868:	394083e0 	ldrb	w0, [sp, #32]
    386c:	cb180273 	sub	x19, x19, x24
    3870:	91000673 	add	x19, x19, #0x1
    3874:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3878:	7100b41f 	cmp	w0, #0x2d
    387c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3880:	1a9f17e4 	cset	w4, eq	// eq = none
    3884:	cb010266 	sub	x6, x19, x1
    3888:	d10004da 	sub	x26, x6, #0x1
    388c:	540018a0 	b.eq	3ba0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3890:	910183f9 	add	x25, sp, #0x60
    3894:	d280091b 	mov	x27, #0x48                  	// #72
    3898:	aa1903e7 	mov	x7, x25
    389c:	91000423 	add	x3, x1, #0x1
    38a0:	91011cc6 	add	x6, x6, #0x47
    38a4:	910004f6 	add	x22, x7, #0x1
    38a8:	37f80ff7 	tbnz	w23, #31, 3aa4 <fwp_format_g.constprop.0+0x2e4>
    38ac:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38b0:	93407ef7 	sxtw	x23, w23
    38b4:	390000e4 	strb	w4, [x7]
    38b8:	aa1303e1 	mov	x1, x19
    38bc:	aa1703e2 	mov	x2, x23
    38c0:	aa1603e0 	mov	x0, x22
    38c4:	b9000be5 	str	w5, [sp, #8]
    38c8:	cb170374 	sub	x20, x27, x23
    38cc:	a9011be3 	stp	x3, x6, [sp, #16]
    38d0:	97fffb7c 	bl	26c0 <memcpy@plt>
    38d4:	d1000694 	sub	x20, x20, #0x1
    38d8:	f9400be3 	ldr	x3, [sp, #16]
    38dc:	8b1702d6 	add	x22, x22, x23
    38e0:	aa1603e0 	mov	x0, x22
    38e4:	aa1a03e2 	mov	x2, x26
    38e8:	aa0303e1 	mov	x1, x3
    38ec:	aa1403e3 	mov	x3, x20
    38f0:	97fffbb0 	bl	27b0 <__memcpy_chk@plt>
    38f4:	8b1a02d6 	add	x22, x22, x26
    38f8:	f9400fe6 	ldr	x6, [sp, #24]
    38fc:	d2800900 	mov	x0, #0x48                  	// #72
    3900:	b9400be5 	ldr	w5, [sp, #8]
    3904:	8b170261 	add	x1, x19, x23
    3908:	cb1400c3 	sub	x3, x6, x20
    390c:	cb060294 	sub	x20, x20, x6
    3910:	f101207f 	cmp	x3, #0x48
    3914:	93407cb8 	sxtw	x24, w5
    3918:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    391c:	aa1803e2 	mov	x2, x24
    3920:	8b1802d3 	add	x19, x22, x24
    3924:	8b140063 	add	x3, x3, x20
    3928:	aa1603e0 	mov	x0, x22
    392c:	97fffba1 	bl	27b0 <__memcpy_chk@plt>
    3930:	cb190273 	sub	x19, x19, x25
    3934:	d28031e0 	mov	x0, #0x18f                 	// #399
    3938:	eb00027f 	cmp	x19, x0
    393c:	aa1903e1 	mov	x1, x25
    3940:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3944:	aa1503e0 	mov	x0, x21
    3948:	aa1303e2 	mov	x2, x19
    394c:	97fffb5d 	bl	26c0 <memcpy@plt>
    3950:	38336abf 	strb	wzr, [x21, x19]
    3954:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3958:	aa1503e0 	mov	x0, x21
    395c:	97fffb65 	bl	26f0 <strlen@plt>
    3960:	aa0003f3 	mov	x19, x0
    3964:	528005c1 	mov	w1, #0x2e                  	// #46
    3968:	aa1503e0 	mov	x0, x21
    396c:	97fffbf5 	bl	2940 <strchr@plt>
    3970:	b4000140 	cbz	x0, 3998 <fwp_format_g.constprop.0+0x1d8>
    3974:	b4000133 	cbz	x19, 3998 <fwp_format_g.constprop.0+0x1d8>
    3978:	aa1303e1 	mov	x1, x19
    397c:	d1000673 	sub	x19, x19, #0x1
    3980:	38736aa0 	ldrb	w0, [x21, x19]
    3984:	7100c01f 	cmp	w0, #0x30
    3988:	54001001 	b.ne	3b88 <fwp_format_g.constprop.0+0x3c8>  // b.any
    398c:	38336abf 	strb	wzr, [x21, x19]
    3990:	b5ffff53 	cbnz	x19, 3978 <fwp_format_g.constprop.0+0x1b8>
    3994:	d503201f 	nop
    3998:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    399c:	f947f400 	ldr	x0, [x0, #4072]
    39a0:	f94057e2 	ldr	x2, [sp, #168]
    39a4:	f9400001 	ldr	x1, [x0]
    39a8:	eb010042 	subs	x2, x2, x1
    39ac:	d2800001 	mov	x1, #0x0                   	// #0
    39b0:	54001061 	b.ne	3bbc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39b4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39b8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39bc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    39c0:	a94e63f7 	ldp	x23, x24, [sp, #224]
    39c4:	a95073fb 	ldp	x27, x28, [sp, #256]
    39c8:	fd408be8 	ldr	d8, [sp, #272]
    39cc:	910483ff 	add	sp, sp, #0x120
    39d0:	d65f03c0 	ret
    39d4:	1e604100 	fmov	d0, d8
    39d8:	710000bf 	cmp	w5, #0x0
    39dc:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    39e0:	aa1503e0 	mov	x0, x21
    39e4:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x42c>
    39e8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    39ec:	9128a084 	add	x4, x4, #0xa28
    39f0:	52800042 	mov	w2, #0x2                   	// #2
    39f4:	d2803201 	mov	x1, #0x190                 	// #400
    39f8:	97fffb76 	bl	27d0 <__snprintf_chk@plt>
    39fc:	17ffffd7 	b	3958 <fwp_format_g.constprop.0+0x198>
    3a00:	cb140273 	sub	x19, x19, x20
    3a04:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a08:	910183f9 	add	x25, sp, #0x60
    3a0c:	aa1303e2 	mov	x2, x19
    3a10:	aa1403e1 	mov	x1, x20
    3a14:	aa1903e0 	mov	x0, x25
    3a18:	d2800803 	mov	x3, #0x40                  	// #64
    3a1c:	97fffb65 	bl	27b0 <__memcpy_chk@plt>
    3a20:	38336b3f 	strb	wzr, [x25, x19]
    3a24:	aa1903e0 	mov	x0, x25
    3a28:	528005c1 	mov	w1, #0x2e                  	// #46
    3a2c:	97fffbc5 	bl	2940 <strchr@plt>
    3a30:	b40001c0 	cbz	x0, 3a68 <fwp_format_g.constprop.0+0x2a8>
    3a34:	b50000b3 	cbnz	x19, 3a48 <fwp_format_g.constprop.0+0x288>
    3a38:	1400000c 	b	3a68 <fwp_format_g.constprop.0+0x2a8>
    3a3c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a40:	f1000673 	subs	x19, x19, #0x1
    3a44:	54000120 	b.eq	3a68 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a48:	8b130320 	add	x0, x25, x19
    3a4c:	385ff001 	ldurb	w1, [x0, #-1]
    3a50:	7100c03f 	cmp	w1, #0x30
    3a54:	54ffff40 	b.eq	3a3c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a58:	d1000673 	sub	x19, x19, #0x1
    3a5c:	38736b20 	ldrb	w0, [x25, x19]
    3a60:	7100b81f 	cmp	w0, #0x2e
    3a64:	54000a80 	b.eq	3bb4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3a68:	710002ff 	cmp	w23, #0x0
    3a6c:	528005a1 	mov	w1, #0x2d                  	// #45
    3a70:	aa1903e5 	mov	x5, x25
    3a74:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3a78:	aa1503e0 	mov	x0, x21
    3a7c:	52800566 	mov	w6, #0x2b                  	// #43
    3a80:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x42c>
    3a84:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3a88:	91286084 	add	x4, x4, #0xa18
    3a8c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a90:	52800042 	mov	w2, #0x2                   	// #2
    3a94:	d2803201 	mov	x1, #0x190                 	// #400
    3a98:	97fffb4e 	bl	27d0 <__snprintf_chk@plt>
    3a9c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3aa0:	17ffffbe 	b	3998 <fwp_format_g.constprop.0+0x1d8>
    3aa4:	52800605 	mov	w5, #0x30                  	// #48
    3aa8:	390000e5 	strb	w5, [x7]
    3aac:	d100077b 	sub	x27, x27, #0x1
    3ab0:	aa0303e1 	mov	x1, x3
    3ab4:	aa1603e0 	mov	x0, x22
    3ab8:	aa1b03e3 	mov	x3, x27
    3abc:	aa1a03e2 	mov	x2, x26
    3ac0:	f90007e6 	str	x6, [sp, #8]
    3ac4:	b90013e4 	str	w4, [sp, #16]
    3ac8:	8b1a02d6 	add	x22, x22, x26
    3acc:	b9001be5 	str	w5, [sp, #24]
    3ad0:	97fffb38 	bl	27b0 <__memcpy_chk@plt>
    3ad4:	f94007e6 	ldr	x6, [sp, #8]
    3ad8:	2a3703e7 	mvn	w7, w23
    3adc:	b94013e4 	ldr	w4, [sp, #16]
    3ae0:	cb1b00c1 	sub	x1, x6, x27
    3ae4:	cb06037b 	sub	x27, x27, x6
    3ae8:	f101203f 	cmp	x1, #0x48
    3aec:	d2800906 	mov	x6, #0x48                  	// #72
    3af0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3af4:	8b1b0023 	add	x3, x1, x27
    3af8:	310006ff 	cmn	w23, #0x1
    3afc:	54000220 	b.eq	3b40 <fwp_format_g.constprop.0+0x380>  // b.none
    3b00:	b9401be5 	ldr	w5, [sp, #24]
    3b04:	d2800001 	mov	x1, #0x0                   	// #0
    3b08:	f101207f 	cmp	x3, #0x48
    3b0c:	d1000462 	sub	x2, x3, #0x1
    3b10:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b14:	38216ac5 	strb	w5, [x22, x1]
    3b18:	cb030003 	sub	x3, x0, x3
    3b1c:	91000421 	add	x1, x1, #0x1
    3b20:	91000463 	add	x3, x3, #0x1
    3b24:	eb00007f 	cmp	x3, x0
    3b28:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b2c:	cb000063 	sub	x3, x3, x0
    3b30:	8b020063 	add	x3, x3, x2
    3b34:	6b0100ff 	cmp	w7, w1
    3b38:	54fffe8c 	b.gt	3b08 <fwp_format_g.constprop.0+0x348>
    3b3c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b40:	f101207f 	cmp	x3, #0x48
    3b44:	d2800905 	mov	x5, #0x48                  	// #72
    3b48:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b4c:	aa1603e0 	mov	x0, x22
    3b50:	cb0300a1 	sub	x1, x5, x3
    3b54:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b58:	91000421 	add	x1, x1, #0x1
    3b5c:	d1000463 	sub	x3, x3, #0x1
    3b60:	eb05003f 	cmp	x1, x5
    3b64:	38001402 	strb	w2, [x0], #1
    3b68:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3b6c:	93407f82 	sxtw	x2, w28
    3b70:	cb050025 	sub	x5, x1, x5
    3b74:	aa1303e1 	mov	x1, x19
    3b78:	8b0300a3 	add	x3, x5, x3
    3b7c:	8b1802d3 	add	x19, x22, x24
    3b80:	97fffb0c 	bl	27b0 <__memcpy_chk@plt>
    3b84:	17ffff6b 	b	3930 <fwp_format_g.constprop.0+0x170>
    3b88:	d1000421 	sub	x1, x1, #0x1
    3b8c:	38616aa0 	ldrb	w0, [x21, x1]
    3b90:	7100b81f 	cmp	w0, #0x2e
    3b94:	54fff021 	b.ne	3998 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3b98:	38216abf 	strb	wzr, [x21, x1]
    3b9c:	17ffff7f 	b	3998 <fwp_format_g.constprop.0+0x1d8>
    3ba0:	910187e7 	add	x7, sp, #0x61
    3ba4:	910183f9 	add	x25, sp, #0x60
    3ba8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bac:	390183e0 	strb	w0, [sp, #96]
    3bb0:	17ffff3b 	b	389c <fwp_format_g.constprop.0+0xdc>
    3bb4:	38336b3f 	strb	wzr, [x25, x19]
    3bb8:	17ffffac 	b	3a68 <fwp_format_g.constprop.0+0x2a8>
    3bbc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3bc0:	97fffb28 	bl	2860 <__stack_chk_fail@plt>

0000000000003bc4 <fwp_heap_report>:
    3bc4:	d105c3ff 	sub	sp, sp, #0x170
    3bc8:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    3bcc:	91188042 	add	x2, x2, #0x620
    3bd0:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    3bd4:	f947e821 	ldr	x1, [x1, #4048]
    3bd8:	a9117bfd 	stp	x29, x30, [sp, #272]
    3bdc:	910443fd 	add	x29, sp, #0x110
    3be0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3be4:	f947f400 	ldr	x0, [x0, #4072]
    3be8:	a9135bf5 	stp	x21, x22, [sp, #304]
    3bec:	a91463f7 	stp	x23, x24, [sp, #320]
    3bf0:	a9156bf9 	stp	x25, x26, [sp, #336]
    3bf4:	6d1627e8 	stp	d8, d9, [sp, #352]
    3bf8:	fd4a1c48 	ldr	d8, [x2, #5176]
    3bfc:	fd4a2049 	ldr	d9, [x2, #5184]
    3c00:	f9400036 	ldr	x22, [x1]
    3c04:	f9400001 	ldr	x1, [x0]
    3c08:	f90087e1 	str	x1, [sp, #264]
    3c0c:	d2800001 	mov	x1, #0x0                   	// #0
    3c10:	f949e459 	ldr	x25, [x2, #5064]
    3c14:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x42c>
    3c18:	f94a1057 	ldr	x23, [x2, #5152]
    3c1c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    3c20:	f94a1458 	ldr	x24, [x2, #5160]
    3c24:	9128c021 	add	x1, x1, #0xa30
    3c28:	9128e000 	add	x0, x0, #0xa38
    3c2c:	97fffaf1 	bl	27f0 <fopen@plt>
    3c30:	b4000760 	cbz	x0, 3d1c <fwp_heap_report+0x158>
    3c34:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c38:	a91253f3 	stp	x19, x20, [sp, #288]
    3c3c:	aa0003f4 	mov	x20, x0
    3c40:	910023f3 	add	x19, sp, #0x8
    3c44:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c48:	72aae915 	movk	w21, #0x5748, lsl #16
    3c4c:	d503201f 	nop
    3c50:	aa1403e2 	mov	x2, x20
    3c54:	aa1303e0 	mov	x0, x19
    3c58:	52802001 	mov	w1, #0x100                 	// #256
    3c5c:	97fffb6d 	bl	2a10 <fgets@plt>
    3c60:	b4000280 	cbz	x0, 3cb0 <fwp_heap_report+0xec>
    3c64:	b9400261 	ldr	w1, [x19]
    3c68:	6b15003f 	cmp	w1, w21
    3c6c:	54ffff21 	b.ne	3c50 <fwp_heap_report+0x8c>  // b.any
    3c70:	39401260 	ldrb	w0, [x19, #4]
    3c74:	7101341f 	cmp	w0, #0x4d
    3c78:	54fffec1 	b.ne	3c50 <fwp_heap_report+0x8c>  // b.any
    3c7c:	394037e0 	ldrb	w0, [sp, #13]
    3c80:	7100e81f 	cmp	w0, #0x3a
    3c84:	54fffe61 	b.ne	3c50 <fwp_heap_report+0x8c>  // b.any
    3c88:	52800142 	mov	w2, #0xa                   	// #10
    3c8c:	d2800001 	mov	x1, #0x0                   	// #0
    3c90:	91003be0 	add	x0, sp, #0xe
    3c94:	97fffb1b 	bl	2900 <strtol@plt>
    3c98:	aa1403e2 	mov	x2, x20
    3c9c:	aa0003fa 	mov	x26, x0
    3ca0:	52802001 	mov	w1, #0x100                 	// #256
    3ca4:	aa1303e0 	mov	x0, x19
    3ca8:	97fffb5a 	bl	2a10 <fgets@plt>
    3cac:	b5fffdc0 	cbnz	x0, 3c64 <fwp_heap_report+0xa0>
    3cb0:	aa1403e0 	mov	x0, x20
    3cb4:	97fffacb 	bl	27e0 <fclose@plt>
    3cb8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3cc0:	f947f400 	ldr	x0, [x0, #4072]
    3cc4:	f94087e2 	ldr	x2, [sp, #264]
    3cc8:	f9400001 	ldr	x1, [x0]
    3ccc:	eb010042 	subs	x2, x2, x1
    3cd0:	d2800001 	mov	x1, #0x0                   	// #0
    3cd4:	54000281 	b.ne	3d24 <fwp_heap_report+0x160>  // b.any
    3cd8:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3cdc:	aa1a03e6 	mov	x6, x26
    3ce0:	aa1903e5 	mov	x5, x25
    3ce4:	aa1803e4 	mov	x4, x24
    3ce8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3cec:	aa1703e3 	mov	x3, x23
    3cf0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3cf4:	aa1603e0 	mov	x0, x22
    3cf8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3cfc:	1e604121 	fmov	d1, d9
    3d00:	1e604100 	fmov	d0, d8
    3d04:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x42c>
    3d08:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d0c:	91296042 	add	x2, x2, #0xa58
    3d10:	9105c3ff 	add	sp, sp, #0x170
    3d14:	52800041 	mov	w1, #0x2                   	// #2
    3d18:	17fffaee 	b	28d0 <__fprintf_chk@plt>
    3d1c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d20:	17ffffe7 	b	3cbc <fwp_heap_report+0xf8>
    3d24:	a91253f3 	stp	x19, x20, [sp, #288]
    3d28:	97ffface 	bl	2860 <__stack_chk_fail@plt>
    3d2c:	d503201f 	nop

0000000000003d30 <fwp_heap_init>:
    3d30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d34:	f00003a3 	adrp	x3, 7a000 <fwp_heap+0x9e0>
    3d38:	91148061 	add	x1, x3, #0x520
    3d3c:	910003fd 	mov	x29, sp
    3d40:	a90153f3 	stp	x19, x20, [sp, #16]
    3d44:	d00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    3d48:	91188262 	add	x2, x19, #0x620
    3d4c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d50:	52800024 	mov	w4, #0x1                   	// #1
    3d54:	52800200 	mov	w0, #0x10                  	// #16
    3d58:	b913a444 	str	w4, [x2, #5028]
    3d5c:	d503201f 	nop
    3d60:	b8004420 	str	w0, [x1], #4
    3d64:	11004000 	add	w0, w0, #0x10
    3d68:	7104401f 	cmp	w0, #0x110
    3d6c:	54ffffa1 	b.ne	3d60 <fwp_heap_init+0x30>  // b.any
    3d70:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x780>
    3d74:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3d78:	f00003a1 	adrp	x1, 7a000 <fwp_heap+0x9e0>
    3d7c:	91158021 	add	x1, x1, #0x560
    3d80:	3dc21043 	ldr	q3, [x2, #2112]
    3d84:	d2800000 	mov	x0, #0x0                   	// #0
    3d88:	4e040401 	dup	v1.4s, v0.s[0]
    3d8c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3d90:	0f215400 	shl	v0.2s, v0.2s, #1
    3d94:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3d98:	3ca06821 	str	q1, [x1, x0]
    3d9c:	91004000 	add	x0, x0, #0x10
    3da0:	f101801f 	cmp	x0, #0x60
    3da4:	54ffff21 	b.ne	3d88 <fwp_heap_init+0x58>  // b.any
    3da8:	f00003a4 	adrp	x4, 7a000 <fwp_heap+0x9e0>
    3dac:	91148063 	add	x3, x3, #0x520
    3db0:	91170084 	add	x4, x4, #0x5c0
    3db4:	91188266 	add	x6, x19, #0x620
    3db8:	d2800002 	mov	x2, #0x0                   	// #0
    3dbc:	d2800000 	mov	x0, #0x0                   	// #0
    3dc0:	d2880205 	mov	x5, #0x4010                	// #16400
    3dc4:	d503201f 	nop
    3dc8:	910f0001 	add	x1, x0, #0x3c0
    3dcc:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3dd0:	eb02003f 	cmp	x1, x2
    3dd4:	540000a2 	b.cs	3de8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3dd8:	91000400 	add	x0, x0, #0x1
    3ddc:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3de0:	eb02003f 	cmp	x1, x2
    3de4:	54ffffa3 	b.cc	3dd8 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3de8:	91004042 	add	x2, x2, #0x10
    3dec:	38001480 	strb	w0, [x4], #1
    3df0:	eb05005f 	cmp	x2, x5
    3df4:	54fffea1 	b.ne	3dc8 <fwp_heap_init+0x98>  // b.any
    3df8:	528000b5 	mov	w21, #0x5                   	// #5
    3dfc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e00:	14000004 	b	3e10 <fwp_heap_init+0xe0>
    3e04:	d342fe94 	lsr	x20, x20, #2
    3e08:	710006b5 	subs	w21, w21, #0x1
    3e0c:	54000720 	b.eq	3ef0 <fwp_heap_init+0x1c0>  // b.none
    3e10:	91404296 	add	x22, x20, #0x10, lsl #12
    3e14:	d2800005 	mov	x5, #0x0                   	// #0
    3e18:	aa1603e1 	mov	x1, x22
    3e1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e20:	52880443 	mov	w3, #0x4022                	// #16418
    3e24:	52800002 	mov	w2, #0x0                   	// #0
    3e28:	d2800000 	mov	x0, #0x0                   	// #0
    3e2c:	97fffab1 	bl	28f0 <mmap@plt>
    3e30:	aa0003e6 	mov	x6, x0
    3e34:	b100041f 	cmn	x0, #0x1
    3e38:	54fffe60 	b.eq	3e04 <fwp_heap_init+0xd4>  // b.none
    3e3c:	b40005a0 	cbz	x0, 3ef0 <fwp_heap_init+0x1c0>
    3e40:	d350fe94 	lsr	x20, x20, #16
    3e44:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e48:	8b0000c7 	add	x7, x6, x0
    3e4c:	91188275 	add	x21, x19, #0x620
    3e50:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e54:	8b140a81 	add	x1, x20, x20, lsl #2
    3e58:	d2800005 	mov	x5, #0x0                   	// #0
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	d37df021 	lsl	x1, x1, #3
    3e64:	52880443 	mov	w3, #0x4022                	// #16418
    3e68:	52800002 	mov	w2, #0x0                   	// #0
    3e6c:	d2800000 	mov	x0, #0x0                   	// #0
    3e70:	f909daa7 	str	x7, [x21, #5040]
    3e74:	f909dea6 	str	x6, [x21, #5048]
    3e78:	f909e2b6 	str	x22, [x21, #5056]
    3e7c:	f909eab4 	str	x20, [x21, #5072]
    3e80:	f90a02a1 	str	x1, [x21, #5120]
    3e84:	97fffa9b 	bl	28f0 <mmap@plt>
    3e88:	aa0003e1 	mov	x1, x0
    3e8c:	b100041f 	cmn	x0, #0x1
    3e90:	54000300 	b.eq	3ef0 <fwp_heap_init+0x1c0>  // b.none
    3e94:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    3e98:	912b8000 	add	x0, x0, #0xae0
    3e9c:	f909fea1 	str	x1, [x21, #5112]
    3ea0:	97fffad4 	bl	29f0 <getenv@plt>
    3ea4:	52800002 	mov	w2, #0x0                   	// #0
    3ea8:	aa0003e1 	mov	x1, x0
    3eac:	b40000e0 	cbz	x0, 3ec8 <fwp_heap_init+0x198>
    3eb0:	39400000 	ldrb	w0, [x0]
    3eb4:	340000a0 	cbz	w0, 3ec8 <fwp_heap_init+0x198>
    3eb8:	7100c000 	subs	w0, w0, #0x30
    3ebc:	54000120 	b.eq	3ee0 <fwp_heap_init+0x1b0>  // b.none
    3ec0:	7100001f 	cmp	w0, #0x0
    3ec4:	1a9f07e2 	cset	w2, ne	// ne = any
    3ec8:	91188273 	add	x19, x19, #0x620
    3ecc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3ed0:	b913aa62 	str	w2, [x19, #5032]
    3ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3ed8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3edc:	d65f03c0 	ret
    3ee0:	39400420 	ldrb	w0, [x1, #1]
    3ee4:	7100001f 	cmp	w0, #0x0
    3ee8:	1a9f07e2 	cset	w2, ne	// ne = any
    3eec:	17fffff7 	b	3ec8 <fwp_heap_init+0x198>
    3ef0:	97fffc90 	bl	3130 <fwp_heap_oom>

0000000000003ef4 <fwp_wake_io>:
    3ef4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3ef8:	91014122 	add	x2, x9, #0x50
    3efc:	f9400001 	ldr	x1, [x0]
    3f00:	5280000a 	mov	w10, #0x0                   	// #0
    3f04:	f9406046 	ldr	x6, [x2, #192]
    3f08:	52800008 	mov	w8, #0x0                   	// #0
    3f0c:	4f000400 	movi	v0.4s, #0x0
    3f10:	52800027 	mov	w7, #0x1                   	// #1
    3f14:	aa0103e2 	mov	x2, x1
    3f18:	b4000321 	cbz	x1, 3f7c <fwp_wake_io+0x88>
    3f1c:	f9408c25 	ldr	x5, [x1, #280]
    3f20:	39015c27 	strb	w7, [x1, #87]
    3f24:	b4000165 	cbz	x5, 3f50 <fwp_wake_io+0x5c>
    3f28:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f2c:	b4000364 	cbz	x4, 3f98 <fwp_wake_io+0xa4>
    3f30:	f9009483 	str	x3, [x4, #296]
    3f34:	f9409423 	ldr	x3, [x1, #296]
    3f38:	b4000043 	cbz	x3, 3f40 <fwp_wake_io+0x4c>
    3f3c:	f9009064 	str	x4, [x3, #288]
    3f40:	91080023 	add	x3, x1, #0x200
    3f44:	f900943f 	str	xzr, [x1, #296]
    3f48:	3c918060 	stur	q0, [x3, #-232]
    3f4c:	f9400001 	ldr	x1, [x0]
    3f50:	f9402843 	ldr	x3, [x2, #80]
    3f54:	f2001c7f 	tst	x3, #0xff000000ff
    3f58:	54fffde1 	b.ne	3f14 <fwp_wake_io+0x20>  // b.any
    3f5c:	39015047 	strb	w7, [x2, #84]
    3f60:	f900805f 	str	xzr, [x2, #256]
    3f64:	b40001e6 	cbz	x6, 3fa0 <fwp_wake_io+0xac>
    3f68:	f90080c2 	str	x2, [x6, #256]
    3f6c:	aa0203e6 	mov	x6, x2
    3f70:	52800028 	mov	w8, #0x1                   	// #1
    3f74:	aa0103e2 	mov	x2, x1
    3f78:	b5fffd21 	cbnz	x1, 3f1c <fwp_wake_io+0x28>
    3f7c:	3400006a 	cbz	w10, 3f88 <fwp_wake_io+0x94>
    3f80:	91014120 	add	x0, x9, #0x50
    3f84:	f900640b 	str	x11, [x0, #200]
    3f88:	34000068 	cbz	w8, 3f94 <fwp_wake_io+0xa0>
    3f8c:	91014129 	add	x9, x9, #0x50
    3f90:	f9006126 	str	x6, [x9, #192]
    3f94:	d65f03c0 	ret
    3f98:	f90000a3 	str	x3, [x5]
    3f9c:	17ffffe7 	b	3f38 <fwp_wake_io+0x44>
    3fa0:	aa0203eb 	mov	x11, x2
    3fa4:	5280002a 	mov	w10, #0x1                   	// #1
    3fa8:	17fffff1 	b	3f6c <fwp_wake_io+0x78>
    3fac:	d503201f 	nop

0000000000003fb0 <ad_raw_free.part.0>:
    3fb0:	b00002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbc0>
    3fb4:	d2800001 	mov	x1, #0x0                   	// #0
    3fb8:	91110082 	add	x2, x4, #0x440
    3fbc:	14000005 	b	3fd0 <ad_raw_free.part.0+0x20>
    3fc0:	91000421 	add	x1, x1, #0x1
    3fc4:	91006042 	add	x2, x2, #0x18
    3fc8:	f140043f 	cmp	x1, #0x1, lsl #12
    3fcc:	54000220 	b.eq	4010 <ad_raw_free.part.0+0x60>  // b.none
    3fd0:	f9400043 	ldr	x3, [x2]
    3fd4:	eb03001f 	cmp	x0, x3
    3fd8:	54ffff41 	b.ne	3fc0 <ad_raw_free.part.0+0x10>  // b.any
    3fdc:	8b010421 	add	x1, x1, x1, lsl #1
    3fe0:	91110084 	add	x4, x4, #0x440
    3fe4:	b00000e2 	adrp	x2, 20000 <__data_start>
    3fe8:	91014042 	add	x2, x2, #0x50
    3fec:	8b010c81 	add	x1, x4, x1, lsl #3
    3ff0:	b9401024 	ldr	w4, [x1, #16]
    3ff4:	f9400425 	ldr	x5, [x1, #8]
    3ff8:	a9007c3f 	stp	xzr, xzr, [x1]
    3ffc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4000:	f900083f 	str	xzr, [x1, #16]
    4004:	cb050061 	sub	x1, x3, x5
    4008:	f8247841 	str	x1, [x2, x4, lsl #3]
    400c:	17fffa45 	b	2920 <free@plt>
    4010:	f100001f 	cmp	x0, #0x0
    4014:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x42c>
    4018:	912c2021 	add	x1, x1, #0xb08
    401c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4020:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    4024:	912bc000 	add	x0, x0, #0xaf0
    4028:	910003fd 	mov	x29, sp
    402c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4030:	97fffcc4 	bl	3340 <ad_raw_fail>

0000000000004034 <fwp_tape_buffers_dispose>:
    4034:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4038:	910003fd 	mov	x29, sp
    403c:	f9000bf3 	str	x19, [sp, #16]
    4040:	aa0003f3 	mov	x19, x0
    4044:	f9400000 	ldr	x0, [x0]
    4048:	b4000040 	cbz	x0, 4050 <fwp_tape_buffers_dispose+0x1c>
    404c:	97ffffd9 	bl	3fb0 <ad_raw_free.part.0>
    4050:	f9400660 	ldr	x0, [x19, #8]
    4054:	b4000040 	cbz	x0, 405c <fwp_tape_buffers_dispose+0x28>
    4058:	97ffffd6 	bl	3fb0 <ad_raw_free.part.0>
    405c:	f9400a60 	ldr	x0, [x19, #16]
    4060:	b4000040 	cbz	x0, 4068 <fwp_tape_buffers_dispose+0x34>
    4064:	97ffffd3 	bl	3fb0 <ad_raw_free.part.0>
    4068:	a9007e7f 	stp	xzr, xzr, [x19]
    406c:	a9017e7f 	stp	xzr, xzr, [x19, #16]
    4070:	f900127f 	str	xzr, [x19, #32]
    4074:	f9400bf3 	ldr	x19, [sp, #16]
    4078:	a8c27bfd 	ldp	x29, x30, [sp], #32
    407c:	d65f03c0 	ret

0000000000004080 <ad_raw_realloc>:
    4080:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4084:	910003fd 	mov	x29, sp
    4088:	a90153f3 	stp	x19, x20, [sp, #16]
    408c:	f90013f5 	str	x21, [sp, #32]
    4090:	b40005a1 	cbz	x1, 4144 <ad_raw_realloc+0xc4>
    4094:	aa0103f4 	mov	x20, x1
    4098:	2a0203f5 	mov	w21, w2
    409c:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbc0>
    40a0:	d2800004 	mov	x4, #0x0                   	// #0
    40a4:	91110025 	add	x5, x1, #0x440
    40a8:	14000005 	b	40bc <ad_raw_realloc+0x3c>
    40ac:	91000484 	add	x4, x4, #0x1
    40b0:	910060a5 	add	x5, x5, #0x18
    40b4:	f140049f 	cmp	x4, #0x1, lsl #12
    40b8:	54000320 	b.eq	411c <ad_raw_realloc+0x9c>  // b.none
    40bc:	f94000a6 	ldr	x6, [x5]
    40c0:	eb06001f 	cmp	x0, x6
    40c4:	54ffff41 	b.ne	40ac <ad_raw_realloc+0x2c>  // b.any
    40c8:	8b040484 	add	x4, x4, x4, lsl #1
    40cc:	91110021 	add	x1, x1, #0x440
    40d0:	8b040c33 	add	x19, x1, x4, lsl #3
    40d4:	b4000080 	cbz	x0, 40e4 <ad_raw_realloc+0x64>
    40d8:	b9401261 	ldr	w1, [x19, #16]
    40dc:	6b15003f 	cmp	w1, w21
    40e0:	540002c1 	b.ne	4138 <ad_raw_realloc+0xb8>  // b.any
    40e4:	aa1403e1 	mov	x1, x20
    40e8:	97fff9da 	bl	2850 <realloc@plt>
    40ec:	aa0003ed 	mov	x13, x0
    40f0:	b40000c0 	cbz	x0, 4108 <ad_raw_realloc+0x88>
    40f4:	2a1503e3 	mov	w3, w21
    40f8:	aa1403e2 	mov	x2, x20
    40fc:	aa1303e0 	mov	x0, x19
    4100:	aa0d03e1 	mov	x1, x13
    4104:	97fffb93 	bl	2f50 <ad_raw_record>
    4108:	a94153f3 	ldp	x19, x20, [sp, #16]
    410c:	aa0d03e0 	mov	x0, x13
    4110:	f94013f5 	ldr	x21, [sp, #32]
    4114:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4118:	d65f03c0 	ret
    411c:	f100001f 	cmp	x0, #0x0
    4120:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x42c>
    4124:	912c2021 	add	x1, x1, #0xb08
    4128:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    412c:	912bc000 	add	x0, x0, #0xaf0
    4130:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4134:	97fffc83 	bl	3340 <ad_raw_fail>
    4138:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    413c:	912d2000 	add	x0, x0, #0xb48
    4140:	97fffc80 	bl	3340 <ad_raw_fail>
    4144:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    4148:	912ca000 	add	x0, x0, #0xb28
    414c:	97fffc7d 	bl	3340 <ad_raw_fail>

0000000000004150 <fwp_tape_buffers_release>:
    4150:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4154:	910003fd 	mov	x29, sp
    4158:	a90153f3 	stp	x19, x20, [sp, #16]
    415c:	aa0003f4 	mov	x20, x0
    4160:	f9400c00 	ldr	x0, [x0, #24]
    4164:	a9025bf5 	stp	x21, x22, [sp, #32]
    4168:	b7f80500 	tbnz	x0, #63, 4208 <fwp_tape_buffers_release+0xb8>
    416c:	f9401293 	ldr	x19, [x20, #32]
    4170:	b7f804d3 	tbnz	x19, #63, 4208 <fwp_tape_buffers_release+0xb8>
    4174:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    4178:	eb01001f 	cmp	x0, x1
    417c:	54000468 	b.hi	4208 <fwp_tape_buffers_release+0xb8>  // b.pmore
    4180:	8b000400 	add	x0, x0, x0, lsl #1
    4184:	d2a00101 	mov	x1, #0x80000               	// #524288
    4188:	d37df000 	lsl	x0, x0, #3
    418c:	cb000021 	sub	x1, x1, x0
    4190:	eb410e7f 	cmp	x19, x1, lsr #3
    4194:	540003a8 	b.hi	4208 <fwp_tape_buffers_release+0xb8>  // b.pmore
    4198:	8b130c13 	add	x19, x0, x19, lsl #3
    419c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    41a0:	912d8000 	add	x0, x0, #0xb60
    41a4:	97fffa13 	bl	29f0 <getenv@plt>
    41a8:	b4000080 	cbz	x0, 41b8 <fwp_tape_buffers_release+0x68>
    41ac:	39400001 	ldrb	w1, [x0]
    41b0:	7100c03f 	cmp	w1, #0x30
    41b4:	54000820 	b.eq	42b8 <fwp_tape_buffers_release+0x168>  // b.none
    41b8:	d1000661 	sub	x1, x19, #0x1
    41bc:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    41c0:	eb00003f 	cmp	x1, x0
    41c4:	540002c8 	b.hi	421c <fwp_tape_buffers_release+0xcc>  // b.pmore
    41c8:	900000f5 	adrp	x21, 20000 <__data_start>
    41cc:	f9001bf7 	str	x23, [sp, #48]
    41d0:	910142b7 	add	x23, x21, #0x50
    41d4:	910342f6 	add	x22, x23, #0xd0
    41d8:	aa1603e0 	mov	x0, x22
    41dc:	97ffff96 	bl	4034 <fwp_tape_buffers_dispose>
    41e0:	ad400680 	ldp	q0, q1, [x20]
    41e4:	f9007ef3 	str	x19, [x23, #248]
    41e8:	ad0006c0 	stp	q0, q1, [x22]
    41ec:	f9401280 	ldr	x0, [x20, #32]
    41f0:	f90012c0 	str	x0, [x22, #32]
    41f4:	a9007e9f 	stp	xzr, xzr, [x20]
    41f8:	a9017e9f 	stp	xzr, xzr, [x20, #16]
    41fc:	f900129f 	str	xzr, [x20, #32]
    4200:	f9401bf7 	ldr	x23, [sp, #48]
    4204:	1400000b 	b	4230 <fwp_tape_buffers_release+0xe0>
    4208:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    420c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4210:	912d8000 	add	x0, x0, #0xb60
    4214:	97fff9f7 	bl	29f0 <getenv@plt>
    4218:	b5fffca0 	cbnz	x0, 41ac <fwp_tape_buffers_release+0x5c>
    421c:	aa1403e0 	mov	x0, x20
    4220:	97ffff85 	bl	4034 <fwp_tape_buffers_dispose>
    4224:	900000f5 	adrp	x21, 20000 <__data_start>
    4228:	910142a0 	add	x0, x21, #0x50
    422c:	f9407c13 	ldr	x19, [x0, #248]
    4230:	910142a2 	add	x2, x21, #0x50
    4234:	f9408044 	ldr	x4, [x2, #256]
    4238:	a9400c45 	ldp	x5, x3, [x2]
    423c:	a9411841 	ldp	x1, x6, [x2, #16]
    4240:	8b040480 	add	x0, x4, x4, lsl #1
    4244:	d37ef400 	lsl	x0, x0, #2
    4248:	cb040000 	sub	x0, x0, x4
    424c:	8b0300a3 	add	x3, x5, x3
    4250:	8b060021 	add	x1, x1, x6
    4254:	d37df000 	lsl	x0, x0, #3
    4258:	8b030021 	add	x1, x1, x3
    425c:	eb05001f 	cmp	x0, x5
    4260:	54000321 	b.ne	42c4 <fwp_tape_buffers_release+0x174>  // b.any
    4264:	8b130003 	add	x3, x0, x19
    4268:	eb01007f 	cmp	x3, x1
    426c:	540002c8 	b.hi	42c4 <fwp_tape_buffers_release+0x174>  // b.pmore
    4270:	f9405c43 	ldr	x3, [x2, #184]
    4274:	f140087f 	cmp	x3, #0x2, lsl #12
    4278:	540002e0 	b.eq	42d4 <fwp_tape_buffers_release+0x184>  // b.none
    427c:	8b030464 	add	x4, x3, x3, lsl #1
    4280:	90000165 	adrp	x5, 30000 <alt.5+0xfbc0>
    4284:	911100a5 	add	x5, x5, #0x440
    4288:	cb000021 	sub	x1, x1, x0
    428c:	d37df084 	lsl	x4, x4, #3
    4290:	cb130021 	sub	x1, x1, x19
    4294:	8b0400a6 	add	x6, x5, x4
    4298:	91000463 	add	x3, x3, #0x1
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	f82468a0 	str	x0, [x5, x4]
    42a4:	a90084d3 	stp	x19, x1, [x6, #8]
    42a8:	f9005c43 	str	x3, [x2, #184]
    42ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    42b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    42b4:	d65f03c0 	ret
    42b8:	39400400 	ldrb	w0, [x0, #1]
    42bc:	34fffb00 	cbz	w0, 421c <fwp_tape_buffers_release+0xcc>
    42c0:	17ffffbe 	b	41b8 <fwp_tape_buffers_release+0x68>
    42c4:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    42c8:	912de000 	add	x0, x0, #0xb78
    42cc:	f9001bf7 	str	x23, [sp, #48]
    42d0:	97fffc1c 	bl	3340 <ad_raw_fail>
    42d4:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    42d8:	912ea000 	add	x0, x0, #0xba8
    42dc:	f9001bf7 	str	x23, [sp, #48]
    42e0:	97fffc18 	bl	3340 <ad_raw_fail>

00000000000042e4 <fwp_trap>:
    42e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    42e8:	900000e2 	adrp	x2, 20000 <__data_start>
    42ec:	d53bd041 	mrs	x1, tpidr_el0
    42f0:	910003fd 	mov	x29, sp
    42f4:	f9407042 	ldr	x2, [x2, #224]
    42f8:	91400021 	add	x1, x1, #0x0, lsl #12
    42fc:	91004021 	add	x1, x1, #0x10
    4300:	a90153f3 	stp	x19, x20, [sp, #16]
    4304:	aa0003f3 	mov	x19, x0
    4308:	f9400034 	ldr	x20, [x1]
    430c:	b4000062 	cbz	x2, 4318 <fwp_trap+0x34>
    4310:	aa0203e0 	mov	x0, x2
    4314:	97fff99f 	bl	2990 <fflush@plt>
    4318:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    431c:	f947ec00 	ldr	x0, [x0, #4056]
    4320:	f9400000 	ldr	x0, [x0]
    4324:	97fff99b 	bl	2990 <fflush@plt>
    4328:	aa1303e3 	mov	x3, x19
    432c:	b0000042 	adrp	x2, d000 <fwp_main_thread+0x42c>
    4330:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc88>
    4334:	f947ea73 	ldr	x19, [x19, #4048]
    4338:	912f2042 	add	x2, x2, #0xbc8
    433c:	52800041 	mov	w1, #0x2                   	// #2
    4340:	f9400260 	ldr	x0, [x19]
    4344:	97fff963 	bl	28d0 <__fprintf_chk@plt>
    4348:	b40000b4 	cbz	x20, 435c <fwp_trap+0x78>
    434c:	f9400260 	ldr	x0, [x19]
    4350:	97fff990 	bl	2990 <fflush@plt>
    4354:	52800ca0 	mov	w0, #0x65                  	// #101
    4358:	97fff99e 	bl	29d0 <_Exit@plt>
    435c:	52800ca0 	mov	w0, #0x65                  	// #101
    4360:	97fff8ec 	bl	2710 <exit@plt>

0000000000004364 <fwp_rc_forget_slot.part.0>:
    4364:	ca404401 	eor	x1, x0, x0, lsr #17
    4368:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    436c:	ca412421 	eor	x1, x1, x1, lsr #9
    4370:	910003fd 	mov	x29, sp
    4374:	92401c21 	and	x1, x1, #0xff
    4378:	f9000bf3 	str	x19, [sp, #16]
    437c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    4380:	91188262 	add	x2, x19, #0x620
    4384:	910a2423 	add	x3, x1, #0x289
    4388:	8b010c41 	add	x1, x2, x1, lsl #3
    438c:	8b030c43 	add	x3, x2, x3, lsl #3
    4390:	f94a2421 	ldr	x1, [x1, #5192]
    4394:	b50000a1 	cbnz	x1, 43a8 <fwp_rc_forget_slot.part.0+0x44>
    4398:	14000012 	b	43e0 <fwp_rc_forget_slot.part.0+0x7c>
    439c:	91004023 	add	x3, x1, #0x10
    43a0:	f9400821 	ldr	x1, [x1, #16]
    43a4:	b40001e1 	cbz	x1, 43e0 <fwp_rc_forget_slot.part.0+0x7c>
    43a8:	f9400022 	ldr	x2, [x1]
    43ac:	eb02001f 	cmp	x0, x2
    43b0:	54ffff61 	b.ne	439c <fwp_rc_forget_slot.part.0+0x38>  // b.any
    43b4:	f9400060 	ldr	x0, [x3]
    43b8:	91188273 	add	x19, x19, #0x620
    43bc:	f9400801 	ldr	x1, [x0, #16]
    43c0:	f9000061 	str	x1, [x3]
    43c4:	97fff957 	bl	2920 <free@plt>
    43c8:	f94e2660 	ldr	x0, [x19, #7240]
    43cc:	d1000400 	sub	x0, x0, #0x1
    43d0:	f90e2660 	str	x0, [x19, #7240]
    43d4:	f9400bf3 	ldr	x19, [sp, #16]
    43d8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43dc:	d65f03c0 	ret
    43e0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    43e4:	912f6000 	add	x0, x0, #0xbd8
    43e8:	97ffffbf 	bl	42e4 <fwp_trap>
    43ec:	d503201f 	nop

00000000000043f0 <fwp_rc_prepare_chunk>:
    43f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43f4:	910003fd 	mov	x29, sp
    43f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    43fc:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    4400:	911882c2 	add	x2, x22, #0x620
    4404:	b9401c03 	ldr	w3, [x0, #28]
    4408:	aa0103f5 	mov	x21, x1
    440c:	a90153f3 	stp	x19, x20, [sp, #16]
    4410:	aa0003f4 	mov	x20, x0
    4414:	f94e2440 	ldr	x0, [x2, #7240]
    4418:	b4000440 	cbz	x0, 44a0 <fwp_rc_prepare_chunk+0xb0>
    441c:	d2800013 	mov	x19, #0x0                   	// #0
    4420:	35000203 	cbnz	w3, 4460 <fwp_rc_prepare_chunk+0x70>
    4424:	b4000361 	cbz	x1, 4490 <fwp_rc_prepare_chunk+0xa0>
    4428:	f9401280 	ldr	x0, [x20, #32]
    442c:	97fff93d 	bl	2920 <free@plt>
    4430:	aa1503e0 	mov	x0, x21
    4434:	d2800021 	mov	x1, #0x1                   	// #1
    4438:	97fff902 	bl	2840 <calloc@plt>
    443c:	f9001280 	str	x0, [x20, #32]
    4440:	b5000460 	cbnz	x0, 44cc <fwp_rc_prepare_chunk+0xdc>
    4444:	97fffb3b 	bl	3130 <fwp_heap_oom>
    4448:	97ffffc7 	bl	4364 <fwp_rc_forget_slot.part.0>
    444c:	91000673 	add	x19, x19, #0x1
    4450:	b9401e83 	ldr	w3, [x20, #28]
    4454:	eb13007f 	cmp	x3, x19
    4458:	54000169 	b.ls	4484 <fwp_rc_prepare_chunk+0x94>  // b.plast
    445c:	d503201f 	nop
    4460:	f9401283 	ldr	x3, [x20, #32]
    4464:	8b130060 	add	x0, x3, x19
    4468:	38736863 	ldrb	w3, [x3, x19]
    446c:	7103fc7f 	cmp	w3, #0xff
    4470:	54fffec0 	b.eq	4448 <fwp_rc_prepare_chunk+0x58>  // b.none
    4474:	b9401e83 	ldr	w3, [x20, #28]
    4478:	91000673 	add	x19, x19, #0x1
    447c:	eb13007f 	cmp	x3, x19
    4480:	54ffff08 	b.hi	4460 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4484:	eb0302bf 	cmp	x21, x3
    4488:	54000121 	b.ne	44ac <fwp_rc_prepare_chunk+0xbc>  // b.any
    448c:	b5000335 	cbnz	x21, 44f0 <fwp_rc_prepare_chunk+0x100>
    4490:	a94153f3 	ldp	x19, x20, [sp, #16]
    4494:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4498:	a8c37bfd 	ldp	x29, x30, [sp], #48
    449c:	d65f03c0 	ret
    44a0:	2a0303e3 	mov	w3, w3
    44a4:	eb0302bf 	cmp	x21, x3
    44a8:	54ffff20 	b.eq	448c <fwp_rc_prepare_chunk+0x9c>  // b.none
    44ac:	911882c2 	add	x2, x22, #0x620
    44b0:	f9401280 	ldr	x0, [x20, #32]
    44b4:	f94e2841 	ldr	x1, [x2, #7248]
    44b8:	cb030021 	sub	x1, x1, x3
    44bc:	f90e2841 	str	x1, [x2, #7248]
    44c0:	97fff918 	bl	2920 <free@plt>
    44c4:	b5fffb75 	cbnz	x21, 4430 <fwp_rc_prepare_chunk+0x40>
    44c8:	f900129f 	str	xzr, [x20, #32]
    44cc:	911882d6 	add	x22, x22, #0x620
    44d0:	f94e2ac0 	ldr	x0, [x22, #7248]
    44d4:	b9001e95 	str	w21, [x20, #28]
    44d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44dc:	8b150000 	add	x0, x0, x21
    44e0:	f90e2ac0 	str	x0, [x22, #7248]
    44e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	f9401280 	ldr	x0, [x20, #32]
    44f4:	aa1503e2 	mov	x2, x21
    44f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44fc:	52800001 	mov	w1, #0x0                   	// #0
    4500:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4504:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4508:	17fff8ca 	b	2830 <memset@plt>
    450c:	d503201f 	nop

0000000000004510 <fwp_heap_refill>:
    4510:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4514:	910003fd 	mov	x29, sp
    4518:	a9025bf5 	stp	x21, x22, [sp, #32]
    451c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    4520:	911882b5 	add	x21, x21, #0x620
    4524:	aa0003f6 	mov	x22, x0
    4528:	d2800020 	mov	x0, #0x1                   	// #1
    452c:	a90153f3 	stp	x19, x20, [sp, #16]
    4530:	a90363f7 	stp	x23, x24, [sp, #48]
    4534:	2a0103f7 	mov	w23, w1
    4538:	2a0203f8 	mov	w24, w2
    453c:	97fffb0d 	bl	3170 <fwp_heap_chunks>
    4540:	aa0003f3 	mov	x19, x0
    4544:	f949fea2 	ldr	x2, [x21, #5112]
    4548:	8b000800 	add	x0, x0, x0, lsl #2
    454c:	2a1703e1 	mov	w1, w23
    4550:	52800025 	mov	w5, #0x1                   	// #1
    4554:	d37df000 	lsl	x0, x0, #3
    4558:	910f0021 	add	x1, x1, #0x3c0
    455c:	8b000054 	add	x20, x2, x0
    4560:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4564:	52a00024 	mov	w4, #0x10000               	// #65536
    4568:	38206845 	strb	w5, [x2, x0]
    456c:	aa1403e0 	mov	x0, x20
    4570:	39000698 	strb	w24, [x20, #1]
    4574:	39000a97 	strb	w23, [x20, #2]
    4578:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    457c:	b9000681 	str	w1, [x20, #4]
    4580:	2a0103e5 	mov	w5, w1
    4584:	8b0300a2 	add	x2, x5, x3
    4588:	1ac10881 	udiv	w1, w4, w1
    458c:	9ac50842 	udiv	x2, x2, x5
    4590:	b9000a81 	str	w1, [x20, #8]
    4594:	92404021 	and	x1, x1, #0x1ffff
    4598:	b9001a82 	str	w2, [x20, #24]
    459c:	97ffff95 	bl	43f0 <fwp_rc_prepare_chunk>
    45a0:	f949daa0 	ldr	x0, [x21, #5040]
    45a4:	29408a81 	ldp	w1, w2, [x20, #4]
    45a8:	8b134000 	add	x0, x0, x19, lsl #16
    45ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    45b0:	8b214003 	add	x3, x0, w1, uxtw
    45b4:	9ba20021 	umaddl	x1, w1, w2, x0
    45b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    45bc:	a90086c3 	stp	x3, x1, [x22, #8]
    45c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    45c4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    45c8:	d65f03c0 	ret
    45cc:	d503201f 	nop

00000000000045d0 <fwp_mem_free>:
    45d0:	b40003c0 	cbz	x0, 4648 <fwp_mem_free+0x78>
    45d4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    45d8:	910003fd 	mov	x29, sp
    45dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    45e0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    45e4:	911882a1 	add	x1, x21, #0x620
    45e8:	a90153f3 	stp	x19, x20, [sp, #16]
    45ec:	aa0003f3 	mov	x19, x0
    45f0:	f949d823 	ldr	x3, [x1, #5040]
    45f4:	f949ec22 	ldr	x2, [x1, #5080]
    45f8:	cb030000 	sub	x0, x0, x3
    45fc:	eb02401f 	cmp	x0, x2, lsl #16
    4600:	540001c2 	b.cs	4638 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4604:	d350fc16 	lsr	x22, x0, #16
    4608:	a90363f7 	stp	x23, x24, [sp, #48]
    460c:	f949fc22 	ldr	x2, [x1, #5112]
    4610:	8b160ad4 	add	x20, x22, x22, lsl #2
    4614:	d37df294 	lsl	x20, x20, #3
    4618:	ab140057 	adds	x23, x2, x20
    461c:	540000c0 	b.eq	4634 <fwp_mem_free+0x64>  // b.none
    4620:	38746842 	ldrb	w2, [x2, x20]
    4624:	7100045f 	cmp	w2, #0x1
    4628:	54000120 	b.eq	464c <fwp_mem_free+0x7c>  // b.none
    462c:	7100085f 	cmp	w2, #0x2
    4630:	540005e0 	b.eq	46ec <fwp_mem_free+0x11c>  // b.none
    4634:	a94363f7 	ldp	x23, x24, [sp, #48]
    4638:	a94153f3 	ldp	x19, x20, [sp, #16]
    463c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4640:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4644:	d65f03c0 	ret
    4648:	d65f03c0 	ret
    464c:	f94012f8 	ldr	x24, [x23, #32]
    4650:	b94006e1 	ldr	w1, [x23, #4]
    4654:	f90023f9 	str	x25, [sp, #64]
    4658:	2a0103e2 	mov	w2, w1
    465c:	394006f9 	ldrb	w25, [x23, #1]
    4660:	39400af4 	ldrb	w20, [x23, #2]
    4664:	b4000158 	cbz	x24, 468c <fwp_mem_free+0xbc>
    4668:	92403e76 	and	x22, x19, #0xffff
    466c:	9ac20ad6 	udiv	x22, x22, x2
    4670:	38766b01 	ldrb	w1, [x24, x22]
    4674:	8b160300 	add	x0, x24, x22
    4678:	7103fc3f 	cmp	w1, #0xff
    467c:	54000980 	b.eq	47ac <fwp_mem_free+0x1dc>  // b.none
    4680:	38366b1f 	strb	wzr, [x24, x22]
    4684:	b94006e1 	ldr	w1, [x23, #4]
    4688:	2a0103e2 	mov	w2, w1
    468c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4690:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4694:	cb390000 	sub	x0, x0, w25, uxtb
    4698:	8b340074 	add	x20, x3, w20, uxtb
    469c:	911882b5 	add	x21, x21, #0x620
    46a0:	1e630021 	ucvtf	d1, w1
    46a4:	d37ae400 	lsl	x0, x0, #6
    46a8:	8b140c14 	add	x20, x0, x20, lsl #3
    46ac:	a94363f7 	ldp	x23, x24, [sp, #48]
    46b0:	f8746aa0 	ldr	x0, [x21, x20]
    46b4:	f94023f9 	ldr	x25, [sp, #64]
    46b8:	aa2003e0 	mvn	x0, x0
    46bc:	fd4a22a0 	ldr	d0, [x21, #5184]
    46c0:	f9000260 	str	x0, [x19]
    46c4:	f8346ab3 	str	x19, [x21, x20]
    46c8:	f94a12a0 	ldr	x0, [x21, #5152]
    46cc:	1e612800 	fadd	d0, d0, d1
    46d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46d4:	cb020000 	sub	x0, x0, x2
    46d8:	f90a12a0 	str	x0, [x21, #5152]
    46dc:	fd0a22a0 	str	d0, [x21, #5184]
    46e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    46e8:	d65f03c0 	ret
    46ec:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    46f0:	8b000063 	add	x3, x3, x0
    46f4:	eb03027f 	cmp	x19, x3
    46f8:	54fff9e1 	b.ne	4634 <fwp_mem_free+0x64>  // b.any
    46fc:	fd400ae1 	ldr	d1, [x23, #16]
    4700:	fd4a2020 	ldr	d0, [x1, #5184]
    4704:	f9400ae0 	ldr	x0, [x23, #16]
    4708:	7e61d821 	ucvtf	d1, d1
    470c:	f94a1022 	ldr	x2, [x1, #5152]
    4710:	f94012f3 	ldr	x19, [x23, #32]
    4714:	1e612800 	fadd	d0, d0, d1
    4718:	cb000042 	sub	x2, x2, x0
    471c:	f90a1022 	str	x2, [x1, #5152]
    4720:	fd0a2020 	str	d0, [x1, #5184]
    4724:	b40000b3 	cbz	x19, 4738 <fwp_mem_free+0x168>
    4728:	39400260 	ldrb	w0, [x19]
    472c:	7103fc1f 	cmp	w0, #0xff
    4730:	54000380 	b.eq	47a0 <fwp_mem_free+0x1d0>  // b.none
    4734:	3900027f 	strb	wzr, [x19]
    4738:	b9400ee2 	ldr	w2, [x23, #12]
    473c:	b4000142 	cbz	x2, 4764 <fwp_mem_free+0x194>
    4740:	911882a1 	add	x1, x21, #0x620
    4744:	8b160040 	add	x0, x2, x22
    4748:	8b000800 	add	x0, x0, x0, lsl #2
    474c:	f949fc21 	ldr	x1, [x1, #5112]
    4750:	8b140034 	add	x20, x1, x20
    4754:	8b000c20 	add	x0, x1, x0, lsl #3
    4758:	3802869f 	strb	wzr, [x20], #40
    475c:	eb00029f 	cmp	x20, x0
    4760:	54ffffc1 	b.ne	4758 <fwp_mem_free+0x188>  // b.any
    4764:	911882a0 	add	x0, x21, #0x620
    4768:	f94a1801 	ldr	x1, [x0, #5168]
    476c:	f949f803 	ldr	x3, [x0, #5104]
    4770:	8b020021 	add	x1, x1, x2
    4774:	f90a1801 	str	x1, [x0, #5168]
    4778:	eb16007f 	cmp	x3, x22
    477c:	54000049 	b.ls	4784 <fwp_mem_free+0x1b4>  // b.plast
    4780:	f909f816 	str	x22, [x0, #5104]
    4784:	911882b5 	add	x21, x21, #0x620
    4788:	f949f6a0 	ldr	x0, [x21, #5096]
    478c:	eb16001f 	cmp	x0, x22
    4790:	54fff529 	b.ls	4634 <fwp_mem_free+0x64>  // b.plast
    4794:	a94363f7 	ldp	x23, x24, [sp, #48]
    4798:	f909f6b6 	str	x22, [x21, #5096]
    479c:	17ffffa7 	b	4638 <fwp_mem_free+0x68>
    47a0:	aa1303e0 	mov	x0, x19
    47a4:	97fffef0 	bl	4364 <fwp_rc_forget_slot.part.0>
    47a8:	17ffffe3 	b	4734 <fwp_mem_free+0x164>
    47ac:	97fffeee 	bl	4364 <fwp_rc_forget_slot.part.0>
    47b0:	17ffffb4 	b	4680 <fwp_mem_free+0xb0>

00000000000047b4 <fwp_rc_wide_dup>:
    47b4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    47b8:	910003fd 	mov	x29, sp
    47bc:	a90153f3 	stp	x19, x20, [sp, #16]
    47c0:	aa0003f3 	mov	x19, x0
    47c4:	ca404400 	eor	x0, x0, x0, lsr #17
    47c8:	f90013f5 	str	x21, [sp, #32]
    47cc:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    47d0:	ca402400 	eor	x0, x0, x0, lsr #9
    47d4:	911882a2 	add	x2, x21, #0x620
    47d8:	92401c00 	and	x0, x0, #0xff
    47dc:	910a2403 	add	x3, x0, #0x289
    47e0:	8b000c40 	add	x0, x2, x0, lsl #3
    47e4:	8b030c54 	add	x20, x2, x3, lsl #3
    47e8:	f94a2401 	ldr	x1, [x0, #5192]
    47ec:	b50000a1 	cbnz	x1, 4800 <fwp_rc_wide_dup+0x4c>
    47f0:	14000033 	b	48bc <fwp_rc_wide_dup+0x108>
    47f4:	91004034 	add	x20, x1, #0x10
    47f8:	f9400821 	ldr	x1, [x1, #16]
    47fc:	b4000241 	cbz	x1, 4844 <fwp_rc_wide_dup+0x90>
    4800:	f9400022 	ldr	x2, [x1]
    4804:	eb02027f 	cmp	x19, x2
    4808:	54ffff61 	b.ne	47f4 <fwp_rc_wide_dup+0x40>  // b.any
    480c:	f9400281 	ldr	x1, [x20]
    4810:	39400260 	ldrb	w0, [x19]
    4814:	7103f81f 	cmp	w0, #0xfe
    4818:	54000220 	b.eq	485c <fwp_rc_wide_dup+0xa8>  // b.none
    481c:	b40001a1 	cbz	x1, 4850 <fwp_rc_wide_dup+0x9c>
    4820:	f9400420 	ldr	x0, [x1, #8]
    4824:	b100041f 	cmn	x0, #0x1
    4828:	54000440 	b.eq	48b0 <fwp_rc_wide_dup+0xfc>  // b.none
    482c:	91000400 	add	x0, x0, #0x1
    4830:	f9000420 	str	x0, [x1, #8]
    4834:	a94153f3 	ldp	x19, x20, [sp, #16]
    4838:	f94013f5 	ldr	x21, [sp, #32]
    483c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4840:	d65f03c0 	ret
    4844:	39400260 	ldrb	w0, [x19]
    4848:	7103f81f 	cmp	w0, #0xfe
    484c:	54000100 	b.eq	486c <fwp_rc_wide_dup+0xb8>  // b.none
    4850:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    4854:	912f6000 	add	x0, x0, #0xbd8
    4858:	97fffea3 	bl	42e4 <fwp_trap>
    485c:	b4000081 	cbz	x1, 486c <fwp_rc_wide_dup+0xb8>
    4860:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    4864:	91300000 	add	x0, x0, #0xc00
    4868:	97fffe9f 	bl	42e4 <fwp_trap>
    486c:	d2800300 	mov	x0, #0x18                  	// #24
    4870:	97fff7e4 	bl	2800 <malloc@plt>
    4874:	b4000280 	cbz	x0, 48c4 <fwp_rc_wide_dup+0x110>
    4878:	d2801fe1 	mov	x1, #0xff                  	// #255
    487c:	a9000413 	stp	x19, x1, [x0]
    4880:	911882b5 	add	x21, x21, #0x620
    4884:	f900081f 	str	xzr, [x0, #16]
    4888:	12800001 	mov	w1, #0xffffffff            	// #-1
    488c:	f9000280 	str	x0, [x20]
    4890:	39000261 	strb	w1, [x19]
    4894:	f94e26a0 	ldr	x0, [x21, #7240]
    4898:	a94153f3 	ldp	x19, x20, [sp, #16]
    489c:	91000400 	add	x0, x0, #0x1
    48a0:	f90e26a0 	str	x0, [x21, #7240]
    48a4:	f94013f5 	ldr	x21, [sp, #32]
    48a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    48ac:	d65f03c0 	ret
    48b0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    48b4:	9130a000 	add	x0, x0, #0xc28
    48b8:	97fffe8b 	bl	42e4 <fwp_trap>
    48bc:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    48c0:	17ffffd4 	b	4810 <fwp_rc_wide_dup+0x5c>
    48c4:	97fffa1b 	bl	3130 <fwp_heap_oom>
    48c8:	d503201f 	nop
    48cc:	d503201f 	nop

00000000000048d0 <fwp_closure_drop_push>:
    48d0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    48d4:	910003fd 	mov	x29, sp
    48d8:	a90153f3 	stp	x19, x20, [sp, #16]
    48dc:	aa0003f3 	mov	x19, x0
    48e0:	a9408014 	ldp	x20, x0, [x0, #8]
    48e4:	a9025bf5 	stp	x21, x22, [sp, #32]
    48e8:	aa0103f5 	mov	x21, x1
    48ec:	a90363f7 	stp	x23, x24, [sp, #48]
    48f0:	eb00029f 	cmp	x20, x0
    48f4:	54000160 	b.eq	4920 <fwp_closure_drop_push+0x50>  // b.none
    48f8:	f9400276 	ldr	x22, [x19]
    48fc:	d37df297 	lsl	x23, x20, #3
    4900:	91000694 	add	x20, x20, #0x1
    4904:	f9000674 	str	x20, [x19, #8]
    4908:	a94153f3 	ldp	x19, x20, [sp, #16]
    490c:	f8376ad5 	str	x21, [x22, x23]
    4910:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4914:	a94363f7 	ldp	x23, x24, [sp, #48]
    4918:	a8c57bfd 	ldp	x29, x30, [sp], #80
    491c:	d65f03c0 	ret
    4920:	a9046bf9 	stp	x25, x26, [sp, #64]
    4924:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4928:	eb00029f 	cmp	x20, x0
    492c:	540003e8 	b.hi	49a8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4930:	d37cee99 	lsl	x25, x20, #4
    4934:	d37ffa9a 	lsl	x26, x20, #1
    4938:	aa1903e0 	mov	x0, x25
    493c:	97fff7b1 	bl	2800 <malloc@plt>
    4940:	aa0003f6 	mov	x22, x0
    4944:	b4000380 	cbz	x0, 49b4 <fwp_closure_drop_push+0xe4>
    4948:	aa1303f8 	mov	x24, x19
    494c:	aa1903e3 	mov	x3, x25
    4950:	d37df297 	lsl	x23, x20, #3
    4954:	aa1703e2 	mov	x2, x23
    4958:	f8418719 	ldr	x25, [x24], #24
    495c:	aa1903e1 	mov	x1, x25
    4960:	97fff794 	bl	27b0 <__memcpy_chk@plt>
    4964:	eb18033f 	cmp	x25, x24
    4968:	540000a0 	b.eq	497c <fwp_closure_drop_push+0xac>  // b.none
    496c:	aa1903e0 	mov	x0, x25
    4970:	97fff7ec 	bl	2920 <free@plt>
    4974:	f9400674 	ldr	x20, [x19, #8]
    4978:	d37df297 	lsl	x23, x20, #3
    497c:	91000694 	add	x20, x20, #0x1
    4980:	f9000276 	str	x22, [x19]
    4984:	f9000a7a 	str	x26, [x19, #16]
    4988:	a9446bf9 	ldp	x25, x26, [sp, #64]
    498c:	f9000674 	str	x20, [x19, #8]
    4990:	f8376ad5 	str	x21, [x22, x23]
    4994:	a94153f3 	ldp	x19, x20, [sp, #16]
    4998:	a9425bf5 	ldp	x21, x22, [sp, #32]
    499c:	a94363f7 	ldp	x23, x24, [sp, #48]
    49a0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    49a4:	d65f03c0 	ret
    49a8:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    49ac:	91312000 	add	x0, x0, #0xc48
    49b0:	97fffe4d 	bl	42e4 <fwp_trap>
    49b4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    49b8:	f947e863 	ldr	x3, [x3, #4048]
    49bc:	d2800262 	mov	x2, #0x13                  	// #19
    49c0:	d2800021 	mov	x1, #0x1                   	// #1
    49c4:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    49c8:	91222000 	add	x0, x0, #0x888
    49cc:	f9400063 	ldr	x3, [x3]
    49d0:	97fff7e4 	bl	2960 <fwrite@plt>
    49d4:	d2800000 	mov	x0, #0x0                   	// #0
    49d8:	97fff7ee 	bl	2990 <fflush@plt>
    49dc:	52800cc0 	mov	w0, #0x66                  	// #102
    49e0:	97fff7fc 	bl	29d0 <_Exit@plt>

00000000000049e4 <fwp_closure_drop.part.0>:
    49e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    49e8:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0x780>
    49ec:	910003fd 	mov	x29, sp
    49f0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    49f4:	f947f463 	ldr	x3, [x3, #4072]
    49f8:	a90153f3 	stp	x19, x20, [sp, #16]
    49fc:	d10883ff 	sub	sp, sp, #0x220
    4a00:	910003e2 	mov	x2, sp
    4a04:	d53bd053 	mrs	x19, tpidr_el0
    4a08:	910063f4 	add	x20, sp, #0x18
    4a0c:	3dc21420 	ldr	q0, [x1, #2128]
    4a10:	91400264 	add	x4, x19, #0x0, lsl #12
    4a14:	91004084 	add	x4, x4, #0x10
    4a18:	aa0003e1 	mov	x1, x0
    4a1c:	aa0203e0 	mov	x0, x2
    4a20:	f9400062 	ldr	x2, [x3]
    4a24:	f9010fe2 	str	x2, [sp, #536]
    4a28:	d2800002 	mov	x2, #0x0                   	// #0
    4a2c:	f90003f4 	str	x20, [sp]
    4a30:	f9000080 	str	x0, [x4]
    4a34:	3c8083e0 	stur	q0, [sp, #8]
    4a38:	97ffffa6 	bl	48d0 <fwp_closure_drop_push>
    4a3c:	f94007e0 	ldr	x0, [sp, #8]
    4a40:	b40002e0 	cbz	x0, 4a9c <fwp_closure_drop.part.0+0xb8>
    4a44:	f90123f5 	str	x21, [sp, #576]
    4a48:	900000f5 	adrp	x21, 20000 <__data_start>
    4a4c:	910142b5 	add	x21, x21, #0x50
    4a50:	14000006 	b	4a68 <fwp_closure_drop.part.0+0x84>
    4a54:	f9400422 	ldr	x2, [x1, #8]
    4a58:	52800001 	mov	w1, #0x0                   	// #0
    4a5c:	d63f0040 	blr	x2
    4a60:	f94007e0 	ldr	x0, [sp, #8]
    4a64:	b40001a0 	cbz	x0, 4a98 <fwp_closure_drop.part.0+0xb4>
    4a68:	f94003e1 	ldr	x1, [sp]
    4a6c:	d1000400 	sub	x0, x0, #0x1
    4a70:	f90007e0 	str	x0, [sp, #8]
    4a74:	f94086a2 	ldr	x2, [x21, #264]
    4a78:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    4a7c:	b9400001 	ldr	w1, [x0]
    4a80:	8b011441 	add	x1, x2, x1, lsl #5
    4a84:	f9400c21 	ldr	x1, [x1, #24]
    4a88:	b5fffe61 	cbnz	x1, 4a54 <fwp_closure_drop.part.0+0x70>
    4a8c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    4a90:	9131a000 	add	x0, x0, #0xc68
    4a94:	97fffe14 	bl	42e4 <fwp_trap>
    4a98:	f94123f5 	ldr	x21, [sp, #576]
    4a9c:	91400273 	add	x19, x19, #0x0, lsl #12
    4aa0:	91004273 	add	x19, x19, #0x10
    4aa4:	f94003e0 	ldr	x0, [sp]
    4aa8:	f900027f 	str	xzr, [x19]
    4aac:	eb14001f 	cmp	x0, x20
    4ab0:	54000040 	b.eq	4ab8 <fwp_closure_drop.part.0+0xd4>  // b.none
    4ab4:	97fff79b 	bl	2920 <free@plt>
    4ab8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4abc:	f947f400 	ldr	x0, [x0, #4072]
    4ac0:	f9410fe2 	ldr	x2, [sp, #536]
    4ac4:	f9400001 	ldr	x1, [x0]
    4ac8:	eb010042 	subs	x2, x2, x1
    4acc:	d2800001 	mov	x1, #0x0                   	// #0
    4ad0:	540000a1 	b.ne	4ae4 <fwp_closure_drop.part.0+0x100>  // b.any
    4ad4:	910883ff 	add	sp, sp, #0x220
    4ad8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4adc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ae0:	d65f03c0 	ret
    4ae4:	f90123f5 	str	x21, [sp, #576]
    4ae8:	97fff75e 	bl	2860 <__stack_chk_fail@plt>
    4aec:	d503201f 	nop

0000000000004af0 <fwp_tape_of>:
    4af0:	aa0003e1 	mov	x1, x0
    4af4:	92403c00 	and	x0, x0, #0xffff
    4af8:	b40000e0 	cbz	x0, 4b14 <fwp_tape_of+0x24>
    4afc:	d1000403 	sub	x3, x0, #0x1
    4b00:	900000e0 	adrp	x0, 20000 <__data_start>
    4b04:	91014000 	add	x0, x0, #0x50
    4b08:	f9408802 	ldr	x2, [x0, #272]
    4b0c:	eb03005f 	cmp	x2, x3
    4b10:	540000cc 	b.gt	4b28 <fwp_tape_of+0x38>
    4b14:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4b18:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    4b1c:	91326000 	add	x0, x0, #0xc98
    4b20:	910003fd 	mov	x29, sp
    4b24:	97fffdf0 	bl	42e4 <fwp_trap>
    4b28:	8b030462 	add	x2, x3, x3, lsl #1
    4b2c:	f9404404 	ldr	x4, [x0, #136]
    4b30:	d37ef442 	lsl	x2, x2, #2
    4b34:	cb030042 	sub	x2, x2, x3
    4b38:	d37df042 	lsl	x2, x2, #3
    4b3c:	8b020080 	add	x0, x4, x2
    4b40:	b9400403 	ldr	w3, [x0, #4]
    4b44:	34fffe83 	cbz	w3, 4b14 <fwp_tape_of+0x24>
    4b48:	b8626882 	ldr	w2, [x4, x2]
    4b4c:	9350fc21 	asr	x1, x1, #16
    4b50:	6b01005f 	cmp	w2, w1
    4b54:	54fffe01 	b.ne	4b14 <fwp_tape_of+0x24>  // b.any
    4b58:	d65f03c0 	ret
    4b5c:	d503201f 	nop

0000000000004b60 <fwp_now_ns>:
    4b60:	d100c3ff 	sub	sp, sp, #0x30
    4b64:	52800020 	mov	w0, #0x1                   	// #1
    4b68:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    4b6c:	f947f442 	ldr	x2, [x2, #4072]
    4b70:	910023e1 	add	x1, sp, #0x8
    4b74:	a9027bfd 	stp	x29, x30, [sp, #32]
    4b78:	910083fd 	add	x29, sp, #0x20
    4b7c:	f9400043 	ldr	x3, [x2]
    4b80:	f9000fe3 	str	x3, [sp, #24]
    4b84:	d2800003 	mov	x3, #0x0                   	// #0
    4b88:	97fff702 	bl	2790 <clock_gettime@plt>
    4b8c:	350002c0 	cbnz	w0, 4be4 <fwp_now_ns+0x84>
    4b90:	a9408be1 	ldp	x1, x2, [sp, #8]
    4b94:	d2994003 	mov	x3, #0xca00                	// #51712
    4b98:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4b9c:	9b037c20 	mul	x0, x1, x3
    4ba0:	9b437c21 	smulh	x1, x1, x3
    4ba4:	ab020000 	adds	x0, x0, x2
    4ba8:	937ffc42 	asr	x2, x2, #63
    4bac:	9a020021 	adc	x1, x1, x2
    4bb0:	f100001f 	cmp	x0, #0x0
    4bb4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4bb8:	b50001c1 	cbnz	x1, 4bf0 <fwp_now_ns+0x90>
    4bbc:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    4bc0:	f947f421 	ldr	x1, [x1, #4072]
    4bc4:	f9400fe3 	ldr	x3, [sp, #24]
    4bc8:	f9400022 	ldr	x2, [x1]
    4bcc:	eb020063 	subs	x3, x3, x2
    4bd0:	d2800002 	mov	x2, #0x0                   	// #0
    4bd4:	54000141 	b.ne	4bfc <fwp_now_ns+0x9c>  // b.any
    4bd8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bdc:	9100c3ff 	add	sp, sp, #0x30
    4be0:	d65f03c0 	ret
    4be4:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    4be8:	9133a000 	add	x0, x0, #0xce8
    4bec:	97fffdbe 	bl	42e4 <fwp_trap>
    4bf0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    4bf4:	91342000 	add	x0, x0, #0xd08
    4bf8:	97fffdbb 	bl	42e4 <fwp_trap>
    4bfc:	97fff719 	bl	2860 <__stack_chk_fail@plt>

0000000000004c00 <fwp_poll_events>:
    4c00:	d10103ff 	sub	sp, sp, #0x40
    4c04:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4c08:	f947f400 	ldr	x0, [x0, #4072]
    4c0c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4c10:	910083fd 	add	x29, sp, #0x20
    4c14:	f9001bf3 	str	x19, [sp, #48]
    4c18:	900000f3 	adrp	x19, 20000 <__data_start>
    4c1c:	f9400001 	ldr	x1, [x0]
    4c20:	f9000fe1 	str	x1, [sp, #24]
    4c24:	d2800001 	mov	x1, #0x0                   	// #0
    4c28:	97ffffce 	bl	4b60 <fwp_now_ns>
    4c2c:	91014261 	add	x1, x19, #0x50
    4c30:	f9408c21 	ldr	x1, [x1, #280]
    4c34:	b4000e01 	cbz	x1, 4df4 <fwp_poll_events+0x1f4>
    4c38:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4c3c:	14000005 	b	4c50 <fwp_poll_events+0x50>
    4c40:	f9408821 	ldr	x1, [x1, #272]
    4c44:	eb03005f 	cmp	x2, x3
    4c48:	9a83d042 	csel	x2, x2, x3, le
    4c4c:	b40000c1 	cbz	x1, 4c64 <fwp_poll_events+0x64>
    4c50:	f9403423 	ldr	x3, [x1, #104]
    4c54:	b6ffff62 	tbz	x2, #63, 4c40 <fwp_poll_events+0x40>
    4c58:	f9408821 	ldr	x1, [x1, #272]
    4c5c:	aa0303e2 	mov	x2, x3
    4c60:	b5ffff81 	cbnz	x1, 4c50 <fwp_poll_events+0x50>
    4c64:	b7f80c82 	tbnz	x2, #63, 4df4 <fwp_poll_events+0x1f4>
    4c68:	cb000042 	sub	x2, x2, x0
    4c6c:	f100005f 	cmp	x2, #0x0
    4c70:	540003ad 	b.le	4ce4 <fwp_poll_events+0xe4>
    4c74:	d2869b60 	mov	x0, #0x34db                	// #13531
    4c78:	d2884804 	mov	x4, #0x4240                	// #16960
    4c7c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4c80:	f2a001e4 	movk	x4, #0xf, lsl #16
    4c84:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4c88:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4c8c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4c90:	9b407c40 	smulh	x0, x2, x0
    4c94:	9352fc00 	asr	x0, x0, #18
    4c98:	cb82fc00 	sub	x0, x0, x2, asr #63
    4c9c:	9b048802 	msub	x2, x0, x4, x2
    4ca0:	f100005f 	cmp	x2, #0x0
    4ca4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4ca8:	eb01001f 	cmp	x0, x1
    4cac:	5400098c 	b.gt	4ddc <fwp_poll_events+0x1dc>
    4cb0:	340001a0 	cbz	w0, 4ce4 <fwp_poll_events+0xe4>
    4cb4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4cb8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4cbc:	72a20c41 	movk	w1, #0x1062, lsl #16
    4cc0:	9ba17c01 	umull	x1, w0, w1
    4cc4:	d366fc23 	lsr	x3, x1, #38
    4cc8:	aa0303e2 	mov	x2, x3
    4ccc:	1b058063 	msub	w3, w3, w5, w0
    4cd0:	9b247c63 	smull	x3, w3, w4
    4cd4:	910023e0 	add	x0, sp, #0x8
    4cd8:	d2800001 	mov	x1, #0x0                   	// #0
    4cdc:	a9008fe2 	stp	x2, x3, [sp, #8]
    4ce0:	97fff714 	bl	2930 <nanosleep@plt>
    4ce4:	97ffff9f 	bl	4b60 <fwp_now_ns>
    4ce8:	91014268 	add	x8, x19, #0x50
    4cec:	aa0003e7 	mov	x7, x0
    4cf0:	4f000400 	movi	v0.4s, #0x0
    4cf4:	52800029 	mov	w9, #0x1                   	// #1
    4cf8:	f9408d06 	ldr	x6, [x8, #280]
    4cfc:	d503201f 	nop
    4d00:	b40003e6 	cbz	x6, 4d7c <fwp_poll_events+0x17c>
    4d04:	f94034c1 	ldr	x1, [x6, #104]
    4d08:	aa0603e5 	mov	x5, x6
    4d0c:	f94088c6 	ldr	x6, [x6, #272]
    4d10:	eb07003f 	cmp	x1, x7
    4d14:	54ffff6c 	b.gt	4d00 <fwp_poll_events+0x100>
    4d18:	394154a0 	ldrb	w0, [x5, #85]
    4d1c:	36000120 	tbz	w0, #0, 4d40 <fwp_poll_events+0x140>
    4d20:	f94084a0 	ldr	x0, [x5, #264]
    4d24:	b4000560 	cbz	x0, 4dd0 <fwp_poll_events+0x1d0>
    4d28:	f9008806 	str	x6, [x0, #272]
    4d2c:	b4000046 	cbz	x6, 4d34 <fwp_poll_events+0x134>
    4d30:	f90084c0 	str	x0, [x6, #264]
    4d34:	910800a0 	add	x0, x5, #0x200
    4d38:	390154bf 	strb	wzr, [x5, #85]
    4d3c:	3c908000 	stur	q0, [x0, #-248]
    4d40:	f94030a0 	ldr	x0, [x5, #96]
    4d44:	390158a9 	strb	w9, [x5, #86]
    4d48:	f100001f 	cmp	x0, #0x0
    4d4c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4d50:	540002cd 	b.le	4da8 <fwp_poll_events+0x1a8>
    4d54:	f94028a0 	ldr	x0, [x5, #80]
    4d58:	f2001c1f 	tst	x0, #0xff000000ff
    4d5c:	54fffd21 	b.ne	4d00 <fwp_poll_events+0x100>  // b.any
    4d60:	f9406100 	ldr	x0, [x8, #192]
    4d64:	390150a9 	strb	w9, [x5, #84]
    4d68:	f90080bf 	str	xzr, [x5, #256]
    4d6c:	b40002c0 	cbz	x0, 4dc4 <fwp_poll_events+0x1c4>
    4d70:	f9006105 	str	x5, [x8, #192]
    4d74:	f9008005 	str	x5, [x0, #256]
    4d78:	b5fffc66 	cbnz	x6, 4d04 <fwp_poll_events+0x104>
    4d7c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4d80:	f947f400 	ldr	x0, [x0, #4072]
    4d84:	f9400fe2 	ldr	x2, [sp, #24]
    4d88:	f9400001 	ldr	x1, [x0]
    4d8c:	eb010042 	subs	x2, x2, x1
    4d90:	d2800001 	mov	x1, #0x0                   	// #0
    4d94:	540002e1 	b.ne	4df0 <fwp_poll_events+0x1f0>  // b.any
    4d98:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4d9c:	f9401bf3 	ldr	x19, [sp, #48]
    4da0:	910103ff 	add	sp, sp, #0x40
    4da4:	d65f03c0 	ret
    4da8:	394144a0 	ldrb	w0, [x5, #81]
    4dac:	3707fd40 	tbnz	w0, #0, 4d54 <fwp_poll_events+0x154>
    4db0:	394140a0 	ldrb	w0, [x5, #80]
    4db4:	3707fd00 	tbnz	w0, #0, 4d54 <fwp_poll_events+0x154>
    4db8:	aa0503e0 	mov	x0, x5
    4dbc:	97fffa3d 	bl	36b0 <fwp_cancel_tree.part.0>
    4dc0:	17ffffe5 	b	4d54 <fwp_poll_events+0x154>
    4dc4:	f9006105 	str	x5, [x8, #192]
    4dc8:	f9006505 	str	x5, [x8, #200]
    4dcc:	17ffffeb 	b	4d78 <fwp_poll_events+0x178>
    4dd0:	91014261 	add	x1, x19, #0x50
    4dd4:	f9008c26 	str	x6, [x1, #280]
    4dd8:	17ffffd5 	b	4d2c <fwp_poll_events+0x12c>
    4ddc:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4de0:	d2989362 	mov	x2, #0xc49b                	// #50331
    4de4:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4de8:	f2a00402 	movk	x2, #0x20, lsl #16
    4dec:	17ffffba 	b	4cd4 <fwp_poll_events+0xd4>
    4df0:	97fff69c 	bl	2860 <__stack_chk_fail@plt>
    4df4:	97fff890 	bl	3034 <fwp_flush>
    4df8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    4dfc:	f947e863 	ldr	x3, [x3, #4048]
    4e00:	d2800562 	mov	x2, #0x2b                  	// #43
    4e04:	d2800021 	mov	x1, #0x1                   	// #1
    4e08:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    4e0c:	9134c000 	add	x0, x0, #0xd30
    4e10:	f9400063 	ldr	x3, [x3]
    4e14:	97fff6d3 	bl	2960 <fwrite@plt>
    4e18:	52800ca0 	mov	w0, #0x65                  	// #101
    4e1c:	97fff63d 	bl	2710 <exit@plt>

0000000000004e20 <fwp_heap_alloc_big>:
    4e20:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e24:	910003fd 	mov	x29, sp
    4e28:	a90153f3 	stp	x19, x20, [sp, #16]
    4e2c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e30:	a90363f7 	stp	x23, x24, [sp, #48]
    4e34:	aa0003f7 	mov	x23, x0
    4e38:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e3c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e40:	eb0002ff 	cmp	x23, x0
    4e44:	540008a8 	b.hi	4f58 <fwp_heap_alloc_big+0x138>  // b.pmore
    4e48:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e4c:	8b0002f4 	add	x20, x23, x0
    4e50:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbc0>
    4e54:	91188359 	add	x25, x26, #0x620
    4e58:	d350fe94 	lsr	x20, x20, #16
    4e5c:	2a0103f5 	mov	w21, w1
    4e60:	aa1403e0 	mov	x0, x20
    4e64:	97fff8c3 	bl	3170 <fwp_heap_chunks>
    4e68:	f949ff22 	ldr	x2, [x25, #5112]
    4e6c:	8b000813 	add	x19, x0, x0, lsl #2
    4e70:	aa0003f8 	mov	x24, x0
    4e74:	52800043 	mov	w3, #0x2                   	// #2
    4e78:	d37df273 	lsl	x19, x19, #3
    4e7c:	d2800021 	mov	x1, #0x1                   	// #1
    4e80:	8b130040 	add	x0, x2, x19
    4e84:	38336843 	strb	w3, [x2, x19]
    4e88:	39000415 	strb	w21, [x0, #1]
    4e8c:	b9000c14 	str	w20, [x0, #12]
    4e90:	f9000817 	str	x23, [x0, #16]
    4e94:	97fffd57 	bl	43f0 <fwp_rc_prepare_chunk>
    4e98:	f100069f 	cmp	x20, #0x1
    4e9c:	54000289 	b.ls	4eec <fwp_heap_alloc_big+0xcc>  // b.plast
    4ea0:	8b180294 	add	x20, x20, x24
    4ea4:	9100a273 	add	x19, x19, #0x28
    4ea8:	a90573fb 	stp	x27, x28, [sp, #80]
    4eac:	5280007b 	mov	w27, #0x3                   	// #3
    4eb0:	8b140a94 	add	x20, x20, x20, lsl #2
    4eb4:	2a1803fc 	mov	w28, w24
    4eb8:	9adb2296 	lsl	x22, x20, x27
    4ebc:	d503201f 	nop
    4ec0:	f949ff35 	ldr	x21, [x25, #5112]
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	8b1302b4 	add	x20, x21, x19
    4ecc:	aa1403e0 	mov	x0, x20
    4ed0:	97fffd48 	bl	43f0 <fwp_rc_prepare_chunk>
    4ed4:	38336abb 	strb	w27, [x21, x19]
    4ed8:	9100a273 	add	x19, x19, #0x28
    4edc:	b9000e9c 	str	w28, [x20, #12]
    4ee0:	eb1302df 	cmp	x22, x19
    4ee4:	54fffee1 	b.ne	4ec0 <fwp_heap_alloc_big+0xa0>  // b.any
    4ee8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4eec:	91188353 	add	x19, x26, #0x620
    4ef0:	aa1703e2 	mov	x2, x23
    4ef4:	52800001 	mov	w1, #0x0                   	// #0
    4ef8:	f949da60 	ldr	x0, [x19, #5040]
    4efc:	8b184018 	add	x24, x0, x24, lsl #16
    4f00:	aa1803e0 	mov	x0, x24
    4f04:	97fff64b 	bl	2830 <memset@plt>
    4f08:	f94a1260 	ldr	x0, [x19, #5152]
    4f0c:	ab170000 	adds	x0, x0, x23
    4f10:	54000242 	b.cs	4f58 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4f14:	f94a1661 	ldr	x1, [x19, #5160]
    4f18:	f90a1260 	str	x0, [x19, #5152]
    4f1c:	eb01001f 	cmp	x0, x1
    4f20:	54000049 	b.ls	4f28 <fwp_heap_alloc_big+0x108>  // b.plast
    4f24:	f90a1660 	str	x0, [x19, #5160]
    4f28:	9118835a 	add	x26, x26, #0x620
    4f2c:	9e6202e0 	scvtf	d0, x23
    4f30:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f34:	aa1803e0 	mov	x0, x24
    4f38:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f3c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f40:	1e602820 	fadd	d0, d1, d0
    4f44:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f48:	fd0a1f40 	str	d0, [x26, #5176]
    4f4c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f50:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f54:	d65f03c0 	ret
    4f58:	a90573fb 	stp	x27, x28, [sp, #80]
    4f5c:	97fff875 	bl	3130 <fwp_heap_oom>

0000000000004f60 <fwp_heap_alloc_slow>:
    4f60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f64:	910003fd 	mov	x29, sp
    4f68:	a90153f3 	stp	x19, x20, [sp, #16]
    4f6c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    4f70:	91188262 	add	x2, x19, #0x620
    4f74:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f78:	aa0003f5 	mov	x21, x0
    4f7c:	2a0103f4 	mov	w20, w1
    4f80:	b953a440 	ldr	w0, [x2, #5028]
    4f84:	34000600 	cbz	w0, 5044 <fwp_heap_alloc_slow+0xe4>
    4f88:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f8c:	54000628 	b.hi	5050 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f90:	91003ea0 	add	x0, x21, #0xf
    4f94:	91188262 	add	x2, x19, #0x620
    4f98:	f9001bf7 	str	x23, [sp, #48]
    4f9c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4fa0:	8b401040 	add	x0, x2, x0, lsr #4
    4fa4:	cb34c084 	sub	x4, x4, w20, sxtw
    4fa8:	d37ae484 	lsl	x4, x4, #6
    4fac:	397e8003 	ldrb	w3, [x0, #4000]
    4fb0:	910f0060 	add	x0, x3, #0x3c0
    4fb4:	aa0303e1 	mov	x1, x3
    4fb8:	8b030463 	add	x3, x3, x3, lsl #1
    4fbc:	8b030c83 	add	x3, x4, x3, lsl #3
    4fc0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4fc4:	2a1703f6 	mov	w22, w23
    4fc8:	f8636844 	ldr	x4, [x2, x3]
    4fcc:	b40004e4 	cbz	x4, 5068 <fwp_heap_alloc_slow+0x108>
    4fd0:	f9400080 	ldr	x0, [x4]
    4fd4:	aa2003e0 	mvn	x0, x0
    4fd8:	f8236840 	str	x0, [x2, x3]
    4fdc:	7100069f 	cmp	w20, #0x1
    4fe0:	aa0403e0 	mov	x0, x4
    4fe4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fe8:	52800001 	mov	w1, #0x0                   	// #0
    4fec:	97fff611 	bl	2830 <memset@plt>
    4ff0:	aa0003e4 	mov	x4, x0
    4ff4:	91188260 	add	x0, x19, #0x620
    4ff8:	f94a1001 	ldr	x1, [x0, #5152]
    4ffc:	ab160021 	adds	x1, x1, x22
    5000:	540005c2 	b.cs	50b8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5004:	f94a1402 	ldr	x2, [x0, #5160]
    5008:	f90a1001 	str	x1, [x0, #5152]
    500c:	eb02003f 	cmp	x1, x2
    5010:	54000049 	b.ls	5018 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5014:	f90a1401 	str	x1, [x0, #5160]
    5018:	91188273 	add	x19, x19, #0x620
    501c:	1e6302e1 	ucvtf	d1, w23
    5020:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5024:	aa0403e0 	mov	x0, x4
    5028:	fd4a1e60 	ldr	d0, [x19, #5176]
    502c:	f9401bf7 	ldr	x23, [sp, #48]
    5030:	1e612800 	fadd	d0, d0, d1
    5034:	fd0a1e60 	str	d0, [x19, #5176]
    5038:	a94153f3 	ldp	x19, x20, [sp, #16]
    503c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5040:	d65f03c0 	ret
    5044:	97fffb3b 	bl	3d30 <fwp_heap_init>
    5048:	f14012bf 	cmp	x21, #0x4, lsl #12
    504c:	54fffa29 	b.ls	4f90 <fwp_heap_alloc_slow+0x30>  // b.plast
    5050:	2a1403e1 	mov	w1, w20
    5054:	aa1503e0 	mov	x0, x21
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5060:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5064:	17ffff6f 	b	4e20 <fwp_heap_alloc_big>
    5068:	8b030042 	add	x2, x2, x3
    506c:	f9400444 	ldr	x4, [x2, #8]
    5070:	b4000104 	cbz	x4, 5090 <fwp_heap_alloc_slow+0x130>
    5074:	f9400840 	ldr	x0, [x2, #16]
    5078:	cb040000 	sub	x0, x0, x4
    507c:	eb16001f 	cmp	x0, x22
    5080:	54000083 	b.cc	5090 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5084:	8b160080 	add	x0, x4, x22
    5088:	f9000440 	str	x0, [x2, #8]
    508c:	17ffffd4 	b	4fdc <fwp_heap_alloc_slow+0x7c>
    5090:	52800302 	mov	w2, #0x18                  	// #24
    5094:	52807804 	mov	w4, #0x3c0                 	// #960
    5098:	91188260 	add	x0, x19, #0x620
    509c:	9ba27c23 	umull	x3, w1, w2
    50a0:	2a1403e2 	mov	w2, w20
    50a4:	9b240e84 	smaddl	x4, w20, w4, x3
    50a8:	8b040000 	add	x0, x0, x4
    50ac:	97fffd19 	bl	4510 <fwp_heap_refill>
    50b0:	aa0003e4 	mov	x4, x0
    50b4:	17ffffca 	b	4fdc <fwp_heap_alloc_slow+0x7c>
    50b8:	97fff81e 	bl	3130 <fwp_heap_oom>
    50bc:	d503201f 	nop

00000000000050c0 <fwp_heap_alloc>:
    50c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    50c4:	910003fd 	mov	x29, sp
    50c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    50cc:	f00000d6 	adrp	x22, 20000 <__data_start>
    50d0:	910142c2 	add	x2, x22, #0x50
    50d4:	a90363f7 	stp	x23, x24, [sp, #48]
    50d8:	b9412058 	ldr	w24, [x2, #288]
    50dc:	a90153f3 	stp	x19, x20, [sp, #16]
    50e0:	7100031f 	cmp	w24, #0x0
    50e4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50e8:	540008a1 	b.ne	51fc <fwp_heap_alloc+0x13c>  // b.any
    50ec:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbc0>
    50f0:	911882f3 	add	x19, x23, #0x620
    50f4:	f140101f 	cmp	x0, #0x4, lsl #12
    50f8:	b953a662 	ldr	w2, [x19, #5028]
    50fc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5100:	54000740 	b.eq	51e8 <fwp_heap_alloc+0x128>  // b.none
    5104:	91003c03 	add	x3, x0, #0xf
    5108:	937c7c22 	sbfiz	x2, x1, #4, #32
    510c:	cb21c042 	sub	x2, x2, w1, sxtw
    5110:	8b431263 	add	x3, x19, x3, lsr #4
    5114:	d37ae442 	lsl	x2, x2, #6
    5118:	397e8063 	ldrb	w3, [x3, #4000]
    511c:	910f0064 	add	x4, x3, #0x3c0
    5120:	8b030463 	add	x3, x3, x3, lsl #1
    5124:	8b030c43 	add	x3, x2, x3, lsl #3
    5128:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    512c:	2a1503f4 	mov	w20, w21
    5130:	f8636a64 	ldr	x4, [x19, x3]
    5134:	b40004c4 	cbz	x4, 51cc <fwp_heap_alloc+0x10c>
    5138:	f9400085 	ldr	x5, [x4]
    513c:	7100043f 	cmp	w1, #0x1
    5140:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5144:	aa0403e0 	mov	x0, x4
    5148:	aa2503e5 	mvn	x5, x5
    514c:	52800001 	mov	w1, #0x0                   	// #0
    5150:	f8236a65 	str	x5, [x19, x3]
    5154:	97fff5b7 	bl	2830 <memset@plt>
    5158:	aa0003e4 	mov	x4, x0
    515c:	f94a1260 	ldr	x0, [x19, #5152]
    5160:	ab140000 	adds	x0, x0, x20
    5164:	54000722 	b.cs	5248 <fwp_heap_alloc+0x188>  // b.hs, b.nlast
    5168:	f94a1661 	ldr	x1, [x19, #5160]
    516c:	f90a1260 	str	x0, [x19, #5152]
    5170:	eb01001f 	cmp	x0, x1
    5174:	54000049 	b.ls	517c <fwp_heap_alloc+0xbc>  // b.plast
    5178:	f90a1660 	str	x0, [x19, #5160]
    517c:	911882e0 	add	x0, x23, #0x620
    5180:	1e6302a1 	ucvtf	d1, w21
    5184:	fd4a1c00 	ldr	d0, [x0, #5176]
    5188:	1e612800 	fadd	d0, d0, d1
    518c:	fd0a1c00 	str	d0, [x0, #5176]
    5190:	34000138 	cbz	w24, 51b4 <fwp_heap_alloc+0xf4>
    5194:	911882e1 	add	x1, x23, #0x620
    5198:	910142c0 	add	x0, x22, #0x50
    519c:	fd4a1020 	ldr	d0, [x1, #5152]
    51a0:	6d538402 	ldp	d2, d1, [x0, #312]
    51a4:	7e61d800 	ucvtf	d0, d0
    51a8:	1e623800 	fsub	d0, d0, d2
    51ac:	1e612010 	fcmpe	d0, d1
    51b0:	5400030c 	b.gt	5210 <fwp_heap_alloc+0x150>
    51b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51b8:	aa0403e0 	mov	x0, x4
    51bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51c0:	a94363f7 	ldp	x23, x24, [sp, #48]
    51c4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51c8:	d65f03c0 	ret
    51cc:	8b030263 	add	x3, x19, x3
    51d0:	f9400464 	ldr	x4, [x3, #8]
    51d4:	b40000a4 	cbz	x4, 51e8 <fwp_heap_alloc+0x128>
    51d8:	f9400862 	ldr	x2, [x3, #16]
    51dc:	cb040042 	sub	x2, x2, x4
    51e0:	eb02029f 	cmp	x20, x2
    51e4:	54000249 	b.ls	522c <fwp_heap_alloc+0x16c>  // b.plast
    51e8:	97ffff5e 	bl	4f60 <fwp_heap_alloc_slow>
    51ec:	aa0003e4 	mov	x4, x0
    51f0:	910142c1 	add	x1, x22, #0x50
    51f4:	b9412038 	ldr	w24, [x1, #288]
    51f8:	17ffffe6 	b	5190 <fwp_heap_alloc+0xd0>
    51fc:	a9528c44 	ldp	x4, x3, [x2, #296]
    5200:	91000484 	add	x4, x4, #0x1
    5204:	8b000063 	add	x3, x3, x0
    5208:	a9128c44 	stp	x4, x3, [x2, #296]
    520c:	17ffffb8 	b	50ec <fwp_heap_alloc+0x2c>
    5210:	a94153f3 	ldp	x19, x20, [sp, #16]
    5214:	fd00a000 	str	d0, [x0, #320]
    5218:	a9425bf5 	ldp	x21, x22, [sp, #32]
    521c:	aa0403e0 	mov	x0, x4
    5220:	a94363f7 	ldp	x23, x24, [sp, #48]
    5224:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5228:	d65f03c0 	ret
    522c:	7100043f 	cmp	w1, #0x1
    5230:	8b140085 	add	x5, x4, x20
    5234:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5238:	52800001 	mov	w1, #0x0                   	// #0
    523c:	aa0403e0 	mov	x0, x4
    5240:	f9000465 	str	x5, [x3, #8]
    5244:	17ffffc4 	b	5154 <fwp_heap_alloc+0x94>
    5248:	97fff7ba 	bl	3130 <fwp_heap_oom>
    524c:	d503201f 	nop

0000000000005250 <fwp_data.part.0.constprop.0>:
    5250:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5254:	910003fd 	mov	x29, sp
    5258:	a9025bf5 	stp	x21, x22, [sp, #32]
    525c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5260:	910142c2 	add	x2, x22, #0x50
    5264:	a9046bf9 	stp	x25, x26, [sp, #64]
    5268:	b9412059 	ldr	w25, [x2, #288]
    526c:	a90153f3 	stp	x19, x20, [sp, #16]
    5270:	aa0103f4 	mov	x20, x1
    5274:	a90363f7 	stp	x23, x24, [sp, #48]
    5278:	2a0003f7 	mov	w23, w0
    527c:	340000b9 	cbz	w25, 5290 <fwp_data.part.0.constprop.0+0x40>
    5280:	a9528041 	ldp	x1, x0, [x2, #296]
    5284:	91000421 	add	x1, x1, #0x1
    5288:	91006000 	add	x0, x0, #0x18
    528c:	a9128041 	stp	x1, x0, [x2, #296]
    5290:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    5294:	911882a3 	add	x3, x21, #0x620
    5298:	b953a460 	ldr	w0, [x3, #5028]
    529c:	34000840 	cbz	w0, 53a4 <fwp_data.part.0.constprop.0+0x154>
    52a0:	397e8862 	ldrb	w2, [x3, #4002]
    52a4:	910f0040 	add	x0, x2, #0x3c0
    52a8:	8b020442 	add	x2, x2, x2, lsl #1
    52ac:	d37df042 	lsl	x2, x2, #3
    52b0:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    52b4:	2a1a03f8 	mov	w24, w26
    52b8:	f8626873 	ldr	x19, [x3, x2]
    52bc:	b4000613 	cbz	x19, 537c <fwp_data.part.0.constprop.0+0x12c>
    52c0:	f9400260 	ldr	x0, [x19]
    52c4:	aa2003e0 	mvn	x0, x0
    52c8:	f8226860 	str	x0, [x3, x2]
    52cc:	f100631f 	cmp	x24, #0x18
    52d0:	540000e9 	b.ls	52ec <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    52d4:	d1006702 	sub	x2, x24, #0x19
    52d8:	91006260 	add	x0, x19, #0x18
    52dc:	927df042 	and	x2, x2, #0xfffffffffffffff8
    52e0:	52800001 	mov	w1, #0x0                   	// #0
    52e4:	91002042 	add	x2, x2, #0x8
    52e8:	97fff552 	bl	2830 <memset@plt>
    52ec:	911882a0 	add	x0, x21, #0x620
    52f0:	f94a1001 	ldr	x1, [x0, #5152]
    52f4:	ab180021 	adds	x1, x1, x24
    52f8:	54000682 	b.cs	53c8 <fwp_data.part.0.constprop.0+0x178>  // b.hs, b.nlast
    52fc:	f94a1402 	ldr	x2, [x0, #5160]
    5300:	f90a1001 	str	x1, [x0, #5152]
    5304:	eb02003f 	cmp	x1, x2
    5308:	54000049 	b.ls	5310 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    530c:	f90a1401 	str	x1, [x0, #5160]
    5310:	911882a0 	add	x0, x21, #0x620
    5314:	1e630341 	ucvtf	d1, w26
    5318:	fd4a1c00 	ldr	d0, [x0, #5176]
    531c:	1e612800 	fadd	d0, d0, d1
    5320:	fd0a1c00 	str	d0, [x0, #5176]
    5324:	34000139 	cbz	w25, 5348 <fwp_data.part.0.constprop.0+0xf8>
    5328:	911882b5 	add	x21, x21, #0x620
    532c:	910142d6 	add	x22, x22, #0x50
    5330:	fd4a12a0 	ldr	d0, [x21, #5152]
    5334:	6d5386c2 	ldp	d2, d1, [x22, #312]
    5338:	7e61d800 	ucvtf	d0, d0
    533c:	1e623800 	fsub	d0, d0, d2
    5340:	1e612010 	fcmpe	d0, d1
    5344:	540003ec 	b.gt	53c0 <fwp_data.part.0.constprop.0+0x170>
    5348:	52800040 	mov	w0, #0x2                   	// #2
    534c:	29000277 	stp	w23, w0, [x19]
    5350:	aa1303e0 	mov	x0, x19
    5354:	f9400281 	ldr	x1, [x20]
    5358:	f9000661 	str	x1, [x19, #8]
    535c:	f9400681 	ldr	x1, [x20, #8]
    5360:	f9000a61 	str	x1, [x19, #16]
    5364:	a94153f3 	ldp	x19, x20, [sp, #16]
    5368:	a9425bf5 	ldp	x21, x22, [sp, #32]
    536c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5370:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5374:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5378:	d65f03c0 	ret
    537c:	8b020063 	add	x3, x3, x2
    5380:	f9400473 	ldr	x19, [x3, #8]
    5384:	b4000113 	cbz	x19, 53a4 <fwp_data.part.0.constprop.0+0x154>
    5388:	f9400860 	ldr	x0, [x3, #16]
    538c:	cb130000 	sub	x0, x0, x19
    5390:	eb00031f 	cmp	x24, x0
    5394:	54000088 	b.hi	53a4 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5398:	8b180260 	add	x0, x19, x24
    539c:	f9000460 	str	x0, [x3, #8]
    53a0:	17ffffcb 	b	52cc <fwp_data.part.0.constprop.0+0x7c>
    53a4:	52800001 	mov	w1, #0x0                   	// #0
    53a8:	d2800300 	mov	x0, #0x18                  	// #24
    53ac:	97ffff45 	bl	50c0 <fwp_heap_alloc>
    53b0:	aa0003f3 	mov	x19, x0
    53b4:	910142c1 	add	x1, x22, #0x50
    53b8:	b9412039 	ldr	w25, [x1, #288]
    53bc:	17ffffda 	b	5324 <fwp_data.part.0.constprop.0+0xd4>
    53c0:	fd00a2c0 	str	d0, [x22, #320]
    53c4:	17ffffe1 	b	5348 <fwp_data.part.0.constprop.0+0xf8>
    53c8:	97fff75a 	bl	3130 <fwp_heap_oom>
    53cc:	d503201f 	nop

00000000000053d0 <fwp_tape_grow.constprop.0>:
    53d0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    53d4:	d2800802 	mov	x2, #0x40                  	// #64
    53d8:	910003fd 	mov	x29, sp
    53dc:	a90153f3 	stp	x19, x20, [sp, #16]
    53e0:	aa0003f4 	mov	x20, x0
    53e4:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    53e8:	f9400e93 	ldr	x19, [x20, #24]
    53ec:	f100027f 	cmp	x19, #0x0
    53f0:	9a821273 	csel	x19, x19, x2, ne	// ne = any
    53f4:	eb13003f 	cmp	x1, x19
    53f8:	540000ed 	b.le	5414 <fwp_tape_grow.constprop.0+0x44>
    53fc:	eb00027f 	cmp	x19, x0
    5400:	5400066d 	b.le	54cc <fwp_tape_grow.constprop.0+0xfc>
    5404:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    5408:	eb13003f 	cmp	x1, x19
    540c:	5400004d 	b.le	5414 <fwp_tape_grow.constprop.0+0x44>
    5410:	14000000 	b	5410 <fwp_tape_grow.constprop.0+0x40>
    5414:	a9025bf5 	stp	x21, x22, [sp, #32]
    5418:	f9402a95 	ldr	x21, [x20, #80]
    541c:	b40005d5 	cbz	x21, 54d4 <fwp_tape_grow.constprop.0+0x104>
    5420:	f9401680 	ldr	x0, [x20, #40]
    5424:	d37df261 	lsl	x1, x19, #3
    5428:	52800022 	mov	w2, #0x1                   	// #1
    542c:	97fffb15 	bl	4080 <ad_raw_realloc>
    5430:	b4000700 	cbz	x0, 5510 <fwp_tape_grow.constprop.0+0x140>
    5434:	f94032b6 	ldr	x22, [x21, #96]
    5438:	f9001680 	str	x0, [x20, #40]
    543c:	eb1302df 	cmp	x22, x19
    5440:	540003ca 	b.ge	54b8 <fwp_tape_grow.constprop.0+0xe8>  // b.tcont
    5444:	a90363f7 	stp	x23, x24, [sp, #48]
    5448:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    544c:	f90023f9 	str	x25, [sp, #64]
    5450:	eb00027f 	cmp	x19, x0
    5454:	54000588 	b.hi	5504 <fwp_tape_grow.constprop.0+0x134>  // b.pmore
    5458:	f94022b8 	ldr	x24, [x21, #64]
    545c:	d37cee79 	lsl	x25, x19, #4
    5460:	aa1903e0 	mov	x0, x25
    5464:	52800041 	mov	w1, #0x2                   	// #2
    5468:	97ffff16 	bl	50c0 <fwp_heap_alloc>
    546c:	aa0003f7 	mov	x23, x0
    5470:	b4000118 	cbz	x24, 5490 <fwp_tape_grow.constprop.0+0xc0>
    5474:	d37ceed6 	lsl	x22, x22, #4
    5478:	aa1803e1 	mov	x1, x24
    547c:	eb1902df 	cmp	x22, x25
    5480:	9a9992c2 	csel	x2, x22, x25, ls	// ls = plast
    5484:	97fff48f 	bl	26c0 <memcpy@plt>
    5488:	aa1803e0 	mov	x0, x24
    548c:	97fffc51 	bl	45d0 <fwp_mem_free>
    5490:	f94032a0 	ldr	x0, [x21, #96]
    5494:	52800001 	mov	w1, #0x0                   	// #0
    5498:	cb000262 	sub	x2, x19, x0
    549c:	8b0012e0 	add	x0, x23, x0, lsl #4
    54a0:	d37cec42 	lsl	x2, x2, #4
    54a4:	97fff4e3 	bl	2830 <memset@plt>
    54a8:	f94023f9 	ldr	x25, [sp, #64]
    54ac:	f90022b7 	str	x23, [x21, #64]
    54b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    54b4:	f90032b3 	str	x19, [x21, #96]
    54b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    54bc:	f9000e93 	str	x19, [x20, #24]
    54c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    54c4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    54c8:	d65f03c0 	ret
    54cc:	d37ffa73 	lsl	x19, x19, #1
    54d0:	17ffffc9 	b	53f4 <fwp_tape_grow.constprop.0+0x24>
    54d4:	f9401280 	ldr	x0, [x20, #32]
    54d8:	8b130661 	add	x1, x19, x19, lsl #1
    54dc:	52800042 	mov	w2, #0x2                   	// #2
    54e0:	d37df021 	lsl	x1, x1, #3
    54e4:	97fffae7 	bl	4080 <ad_raw_realloc>
    54e8:	b4000140 	cbz	x0, 5510 <fwp_tape_grow.constprop.0+0x140>
    54ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    54f0:	f9000e93 	str	x19, [x20, #24]
    54f4:	f9001280 	str	x0, [x20, #32]
    54f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    54fc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5500:	d65f03c0 	ret
    5504:	90000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    5508:	91362000 	add	x0, x0, #0xd88
    550c:	97fffb76 	bl	42e4 <fwp_trap>
    5510:	aa1403e0 	mov	x0, x20
    5514:	a90363f7 	stp	x23, x24, [sp, #48]
    5518:	f90023f9 	str	x25, [sp, #64]
    551c:	97fff6ae 	bl	2fd4 <fwp_tape_unlink_scope>
    5520:	f9401280 	ldr	x0, [x20, #32]
    5524:	b4000040 	cbz	x0, 552c <fwp_tape_grow.constprop.0+0x15c>
    5528:	97fffaa2 	bl	3fb0 <ad_raw_free.part.0>
    552c:	f9401680 	ldr	x0, [x20, #40]
    5530:	b4000040 	cbz	x0, 5538 <fwp_tape_grow.constprop.0+0x168>
    5534:	97fffa9f 	bl	3fb0 <ad_raw_free.part.0>
    5538:	f9401a80 	ldr	x0, [x20, #48]
    553c:	b4000040 	cbz	x0, 5544 <fwp_tape_grow.constprop.0+0x174>
    5540:	97fffa9c 	bl	3fb0 <ad_raw_free.part.0>
    5544:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    5548:	f947e821 	ldr	x1, [x1, #4048]
    554c:	f9000e9f 	str	xzr, [x20, #24]
    5550:	4f000400 	movi	v0.4s, #0x0
    5554:	a9037e9f 	stp	xzr, xzr, [x20, #48]
    5558:	d2800262 	mov	x2, #0x13                  	// #19
    555c:	f9400023 	ldr	x3, [x1]
    5560:	b900069f 	str	wzr, [x20, #4]
    5564:	d2800021 	mov	x1, #0x1                   	// #1
    5568:	90000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    556c:	91222000 	add	x0, x0, #0x888
    5570:	3c808280 	stur	q0, [x20, #8]
    5574:	3d800a80 	str	q0, [x20, #32]
    5578:	97fff4fa 	bl	2960 <fwrite@plt>
    557c:	d2800000 	mov	x0, #0x0                   	// #0
    5580:	97fff504 	bl	2990 <fflush@plt>
    5584:	52800cc0 	mov	w0, #0x66                  	// #102
    5588:	97fff512 	bl	29d0 <_Exit@plt>
    558c:	d503201f 	nop

0000000000005590 <w123>:
    5590:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5594:	910003fd 	mov	x29, sp
    5598:	6d0427e8 	stp	d8, d9, [sp, #64]
    559c:	1e612808 	fadd	d8, d0, d1
    55a0:	ea01001f 	tst	x0, x1
    55a4:	54000b44 	b.mi	570c <w123+0x17c>  // b.first
    55a8:	a90153f3 	stp	x19, x20, [sp, #16]
    55ac:	aa0003f4 	mov	x20, x0
    55b0:	aa0103f3 	mov	x19, x1
    55b4:	a9025bf5 	stp	x21, x22, [sp, #32]
    55b8:	aa010000 	orr	x0, x0, x1
    55bc:	aa0203f5 	mov	x21, x2
    55c0:	f9001bf7 	str	x23, [sp, #48]
    55c4:	b7f80200 	tbnz	x0, #63, 5604 <w123+0x74>
    55c8:	9360fc37 	asr	x23, x1, #32
    55cc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    55d0:	eb9482ff 	cmp	x23, x20, asr #32
    55d4:	54000a61 	b.ne	5720 <w123+0x190>  // b.any
    55d8:	f94002a0 	ldr	x0, [x21]
    55dc:	eb17001f 	cmp	x0, x23
    55e0:	54000220 	b.eq	5624 <w123+0x94>  // b.none
    55e4:	aa1703e0 	mov	x0, x23
    55e8:	97fffd42 	bl	4af0 <fwp_tape_of>
    55ec:	aa0003f6 	mov	x22, x0
    55f0:	f9402800 	ldr	x0, [x0, #80]
    55f4:	b40002e0 	cbz	x0, 5650 <w123+0xc0>
    55f8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    55fc:	9137c000 	add	x0, x0, #0xdf0
    5600:	97fffb39 	bl	42e4 <fwp_trap>
    5604:	b6f80214 	tbz	x20, #63, 5644 <w123+0xb4>
    5608:	f94002a0 	ldr	x0, [x21]
    560c:	9360fc37 	asr	x23, x1, #32
    5610:	2f00e409 	movi	d9, #0x0
    5614:	aa0103f4 	mov	x20, x1
    5618:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    561c:	eb17001f 	cmp	x0, x23
    5620:	54fffe21 	b.ne	55e4 <w123+0x54>  // b.any
    5624:	f94006b6 	ldr	x22, [x21, #8]
    5628:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    562c:	f9400ad7 	ldr	x23, [x22, #16]
    5630:	eb0002ff 	cmp	x23, x0
    5634:	5400018d 	b.le	5664 <w123+0xd4>
    5638:	90000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    563c:	91362000 	add	x0, x0, #0xd88
    5640:	97fffb29 	bl	42e4 <fwp_trap>
    5644:	9360fe97 	asr	x23, x20, #32
    5648:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    564c:	17ffffe3 	b	55d8 <w123+0x48>
    5650:	a9005ab7 	stp	x23, x22, [x21]
    5654:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5658:	f9400ad7 	ldr	x23, [x22, #16]
    565c:	eb0002ff 	cmp	x23, x0
    5660:	54fffecc 	b.gt	5638 <w123+0xa8>
    5664:	eb3442ff 	cmp	x23, w20, uxtw
    5668:	540004cd 	b.le	5700 <w123+0x170>
    566c:	b7f80073 	tbnz	x19, #63, 5678 <w123+0xe8>
    5670:	eb3342ff 	cmp	x23, w19, uxtw
    5674:	5400046d 	b.le	5700 <w123+0x170>
    5678:	f94006d5 	ldr	x21, [x22, #8]
    567c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5680:	cb1502f5 	sub	x21, x23, x21
    5684:	910006a1 	add	x1, x21, #0x1
    5688:	eb00003f 	cmp	x1, x0
    568c:	54fffd68 	b.hi	5638 <w123+0xa8>  // b.pmore
    5690:	f9400ec0 	ldr	x0, [x22, #24]
    5694:	eb00003f 	cmp	x1, x0
    5698:	5400006d 	b.le	56a4 <w123+0x114>
    569c:	aa1603e0 	mov	x0, x22
    56a0:	97ffff4c 	bl	53d0 <fwp_tape_grow.constprop.0>
    56a4:	f100027f 	cmp	x19, #0x0
    56a8:	9e670282 	fmov	d2, x20
    56ac:	da9fa273 	csinv	x19, x19, xzr, ge	// ge = tcont
    56b0:	8b1506b5 	add	x21, x21, x21, lsl #1
    56b4:	f94012c2 	ldr	x2, [x22, #32]
    56b8:	4e181e62 	mov	v2.d[1], x19
    56bc:	d37df2b5 	lsl	x21, x21, #3
    56c0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    56c4:	8b150040 	add	x0, x2, x21
    56c8:	92607e81 	and	x1, x20, #0xffffffff00000000
    56cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    56d0:	aa170021 	orr	x1, x1, x23
    56d4:	0ea12842 	xtn	v2.2s, v2.2d
    56d8:	910006f7 	add	x23, x23, #0x1
    56dc:	fc356842 	str	d2, [x2, x21]
    56e0:	6d00a400 	stp	d0, d9, [x0, #8]
    56e4:	9e660100 	fmov	x0, d8
    56e8:	f9000ad7 	str	x23, [x22, #16]
    56ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    56f0:	f9401bf7 	ldr	x23, [sp, #48]
    56f4:	6d4427e8 	ldp	d8, d9, [sp, #64]
    56f8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    56fc:	d65f03c0 	ret
    5700:	90000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    5704:	91388000 	add	x0, x0, #0xe20
    5708:	97fffaf7 	bl	42e4 <fwp_trap>
    570c:	9e660100 	fmov	x0, d8
    5710:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    5714:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5718:	a8c57bfd 	ldp	x29, x30, [sp], #80
    571c:	d65f03c0 	ret
    5720:	90000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    5724:	9136a000 	add	x0, x0, #0xda8
    5728:	97fffaef 	bl	42e4 <fwp_trap>
    572c:	d503201f 	nop

0000000000005730 <w120>:
    5730:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5734:	910003fd 	mov	x29, sp
    5738:	a90153f3 	stp	x19, x20, [sp, #16]
    573c:	aa0203f3 	mov	x19, x2
    5740:	a9025bf5 	stp	x21, x22, [sp, #32]
    5744:	aa0003f6 	mov	x22, x0
    5748:	aa0103f5 	mov	x21, x1
    574c:	a90363f7 	stp	x23, x24, [sp, #48]
    5750:	f90023f9 	str	x25, [sp, #64]
    5754:	fd0027ea 	str	d10, [sp, #72]
    5758:	1e60080a 	fmul	d10, d0, d0
    575c:	6d0527e8 	stp	d8, d9, [sp, #80]
    5760:	1e604008 	fmov	d8, d0
    5764:	1e604029 	fmov	d9, d1
    5768:	b7f82500 	tbnz	x0, #63, 5c08 <w120+0x4d8>
    576c:	9360fc14 	asr	x20, x0, #32
    5770:	f9400040 	ldr	x0, [x2]
    5774:	eb14001f 	cmp	x0, x20
    5778:	54002340 	b.eq	5be0 <w120+0x4b0>  // b.none
    577c:	aa1403e0 	mov	x0, x20
    5780:	97fffcdc 	bl	4af0 <fwp_tape_of>
    5784:	aa0003f7 	mov	x23, x0
    5788:	f9402800 	ldr	x0, [x0, #80]
    578c:	b4000080 	cbz	x0, 579c <w120+0x6c>
    5790:	90000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    5794:	9137c000 	add	x0, x0, #0xdf0
    5798:	97fffad3 	bl	42e4 <fwp_trap>
    579c:	a9005e74 	stp	x20, x23, [x19]
    57a0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    57a4:	f9400af8 	ldr	x24, [x23, #16]
    57a8:	eb00031f 	cmp	x24, x0
    57ac:	5400210c 	b.gt	5bcc <w120+0x49c>
    57b0:	eb36431f 	cmp	x24, w22, uxtw
    57b4:	5400206d 	b.le	5bc0 <w120+0x490>
    57b8:	f94006f4 	ldr	x20, [x23, #8]
    57bc:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    57c0:	cb140314 	sub	x20, x24, x20
    57c4:	91000681 	add	x1, x20, #0x1
    57c8:	eb00003f 	cmp	x1, x0
    57cc:	54002008 	b.hi	5bcc <w120+0x49c>  // b.pmore
    57d0:	f9400ee0 	ldr	x0, [x23, #24]
    57d4:	eb00003f 	cmp	x1, x0
    57d8:	5400006d 	b.le	57e4 <w120+0xb4>
    57dc:	aa1703e0 	mov	x0, x23
    57e0:	97fffefc 	bl	53d0 <fwp_tape_grow.constprop.0>
    57e4:	8b140681 	add	x1, x20, x20, lsl #1
    57e8:	92607ed4 	and	x20, x22, #0xffffffff00000000
    57ec:	f94012e2 	ldr	x2, [x23, #32]
    57f0:	d37df021 	lsl	x1, x1, #3
    57f4:	aa180294 	orr	x20, x20, x24
    57f8:	91000718 	add	x24, x24, #0x1
    57fc:	8b010040 	add	x0, x2, x1
    5800:	b8216856 	str	w22, [x2, x1]
    5804:	9360fe99 	asr	x25, x20, #32
    5808:	b9000416 	str	w22, [x0, #4]
    580c:	6d00a008 	stp	d8, d8, [x0, #8]
    5810:	f9000af8 	str	x24, [x23, #16]
    5814:	b7f80075 	tbnz	x21, #63, 5820 <w120+0xf0>
    5818:	eb95833f 	cmp	x25, x21, asr #32
    581c:	540021c1 	b.ne	5c54 <w120+0x524>  // b.any
    5820:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x780>
    5824:	1e6a3929 	fsub	d9, d9, d10
    5828:	3dc21c00 	ldr	q0, [x0, #2160]
    582c:	3d801be0 	str	q0, [sp, #96]
    5830:	f9400260 	ldr	x0, [x19]
    5834:	eb19001f 	cmp	x0, x25
    5838:	54001d00 	b.eq	5bd8 <w120+0x4a8>  // b.none
    583c:	aa1903e0 	mov	x0, x25
    5840:	97fffcac 	bl	4af0 <fwp_tape_of>
    5844:	aa0003f8 	mov	x24, x0
    5848:	f9402800 	ldr	x0, [x0, #80]
    584c:	b5fffa20 	cbnz	x0, 5790 <w120+0x60>
    5850:	a9006279 	stp	x25, x24, [x19]
    5854:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5858:	f9400b19 	ldr	x25, [x24, #16]
    585c:	eb00033f 	cmp	x25, x0
    5860:	54001b6c 	b.gt	5bcc <w120+0x49c>
    5864:	eb34433f 	cmp	x25, w20, uxtw
    5868:	54001acd 	b.le	5bc0 <w120+0x490>
    586c:	b7f80075 	tbnz	x21, #63, 5878 <w120+0x148>
    5870:	eb35433f 	cmp	x25, w21, uxtw
    5874:	54001a6d 	b.le	5bc0 <w120+0x490>
    5878:	f9400717 	ldr	x23, [x24, #8]
    587c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5880:	cb170337 	sub	x23, x25, x23
    5884:	910006e1 	add	x1, x23, #0x1
    5888:	eb00003f 	cmp	x1, x0
    588c:	54001a08 	b.hi	5bcc <w120+0x49c>  // b.pmore
    5890:	f9400f00 	ldr	x0, [x24, #24]
    5894:	eb00003f 	cmp	x1, x0
    5898:	5400006d 	b.le	58a4 <w120+0x174>
    589c:	aa1803e0 	mov	x0, x24
    58a0:	97fffecc 	bl	53d0 <fwp_tape_grow.constprop.0>
    58a4:	f10002bf 	cmp	x21, #0x0
    58a8:	9e670282 	fmov	d2, x20
    58ac:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    58b0:	9a81a2b5 	csel	x21, x21, x1, ge	// ge = tcont
    58b4:	f9401300 	ldr	x0, [x24, #32]
    58b8:	4e181ea2 	mov	v2.d[1], x21
    58bc:	8b1706f7 	add	x23, x23, x23, lsl #1
    58c0:	91000722 	add	x2, x25, #0x1
    58c4:	3dc01be0 	ldr	q0, [sp, #96]
    58c8:	d37df2f7 	lsl	x23, x23, #3
    58cc:	0ea12842 	xtn	v2.2s, v2.2d
    58d0:	8b170003 	add	x3, x0, x23
    58d4:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    58d8:	92607e94 	and	x20, x20, #0xffffffff00000000
    58dc:	aa190294 	orr	x20, x20, x25
    58e0:	1e68394a 	fsub	d10, d10, d8
    58e4:	fc376802 	str	d2, [x0, x23]
    58e8:	3c808060 	stur	q0, [x3, #8]
    58ec:	f9000b02 	str	x2, [x24, #16]
    58f0:	b7f81b96 	tbnz	x22, #63, 5c60 <w120+0x530>
    58f4:	f9400260 	ldr	x0, [x19]
    58f8:	9360fed5 	asr	x21, x22, #32
    58fc:	eb15001f 	cmp	x0, x21
    5900:	54001800 	b.eq	5c00 <w120+0x4d0>  // b.none
    5904:	aa1503e0 	mov	x0, x21
    5908:	97fffc7a 	bl	4af0 <fwp_tape_of>
    590c:	aa0003f7 	mov	x23, x0
    5910:	f9402800 	ldr	x0, [x0, #80]
    5914:	b5fff3e0 	cbnz	x0, 5790 <w120+0x60>
    5918:	a9005e75 	stp	x21, x23, [x19]
    591c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5920:	f9400af8 	ldr	x24, [x23, #16]
    5924:	eb00031f 	cmp	x24, x0
    5928:	5400152c 	b.gt	5bcc <w120+0x49c>
    592c:	eb36431f 	cmp	x24, w22, uxtw
    5930:	5400148d 	b.le	5bc0 <w120+0x490>
    5934:	f94006f5 	ldr	x21, [x23, #8]
    5938:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    593c:	cb150315 	sub	x21, x24, x21
    5940:	910006a1 	add	x1, x21, #0x1
    5944:	eb00003f 	cmp	x1, x0
    5948:	54001428 	b.hi	5bcc <w120+0x49c>  // b.pmore
    594c:	f9400ee0 	ldr	x0, [x23, #24]
    5950:	eb00003f 	cmp	x1, x0
    5954:	5400006d 	b.le	5960 <w120+0x230>
    5958:	aa1703e0 	mov	x0, x23
    595c:	97fffe9d 	bl	53d0 <fwp_tape_grow.constprop.0>
    5960:	8b1506b5 	add	x21, x21, x21, lsl #1
    5964:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x780>
    5968:	f94012e2 	ldr	x2, [x23, #32]
    596c:	d37df2a1 	lsl	x1, x21, #3
    5970:	3dc21c00 	ldr	q0, [x0, #2160]
    5974:	8b010040 	add	x0, x2, x1
    5978:	b8216856 	str	w22, [x2, x1]
    597c:	92607ec3 	and	x3, x22, #0xffffffff00000000
    5980:	12800001 	mov	w1, #0xffffffff            	// #-1
    5984:	aa180075 	orr	x21, x3, x24
    5988:	b9000401 	str	w1, [x0, #4]
    598c:	91000718 	add	x24, x24, #0x1
    5990:	3c808000 	stur	q0, [x0, #8]
    5994:	f9000af8 	str	x24, [x23, #16]
    5998:	f9400260 	ldr	x0, [x19]
    599c:	9360fe96 	asr	x22, x20, #32
    59a0:	1e690928 	fmul	d8, d9, d9
    59a4:	eb16001f 	cmp	x0, x22
    59a8:	54001280 	b.eq	5bf8 <w120+0x4c8>  // b.none
    59ac:	aa1603e0 	mov	x0, x22
    59b0:	97fffc50 	bl	4af0 <fwp_tape_of>
    59b4:	aa0003f7 	mov	x23, x0
    59b8:	f9402800 	ldr	x0, [x0, #80]
    59bc:	b5ffeea0 	cbnz	x0, 5790 <w120+0x60>
    59c0:	a9005e76 	stp	x22, x23, [x19]
    59c4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    59c8:	f9400af9 	ldr	x25, [x23, #16]
    59cc:	eb00033f 	cmp	x25, x0
    59d0:	54000fec 	b.gt	5bcc <w120+0x49c>
    59d4:	eb34433f 	cmp	x25, w20, uxtw
    59d8:	54000f4d 	b.le	5bc0 <w120+0x490>
    59dc:	f94006f6 	ldr	x22, [x23, #8]
    59e0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    59e4:	cb160336 	sub	x22, x25, x22
    59e8:	910006c1 	add	x1, x22, #0x1
    59ec:	eb00003f 	cmp	x1, x0
    59f0:	54000ee8 	b.hi	5bcc <w120+0x49c>  // b.pmore
    59f4:	f9400ee0 	ldr	x0, [x23, #24]
    59f8:	eb00003f 	cmp	x1, x0
    59fc:	5400006d 	b.le	5a08 <w120+0x2d8>
    5a00:	aa1703e0 	mov	x0, x23
    5a04:	97fffe73 	bl	53d0 <fwp_tape_grow.constprop.0>
    5a08:	8b1606d6 	add	x22, x22, x22, lsl #1
    5a0c:	92607e98 	and	x24, x20, #0xffffffff00000000
    5a10:	f94012e0 	ldr	x0, [x23, #32]
    5a14:	d37df2d6 	lsl	x22, x22, #3
    5a18:	f9400262 	ldr	x2, [x19]
    5a1c:	8b160001 	add	x1, x0, x22
    5a20:	b8366814 	str	w20, [x0, x22]
    5a24:	aa190318 	orr	x24, x24, x25
    5a28:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a2c:	9e670000 	fmov	d0, x0
    5a30:	b9000434 	str	w20, [x1, #4]
    5a34:	91000739 	add	x25, x25, #0x1
    5a38:	6d00a429 	stp	d9, d9, [x1, #8]
    5a3c:	9360ff14 	asr	x20, x24, #32
    5a40:	1e600908 	fmul	d8, d8, d0
    5a44:	f9000af9 	str	x25, [x23, #16]
    5a48:	eb14005f 	cmp	x2, x20
    5a4c:	54000d20 	b.eq	5bf0 <w120+0x4c0>  // b.none
    5a50:	aa1403e0 	mov	x0, x20
    5a54:	97fffc27 	bl	4af0 <fwp_tape_of>
    5a58:	aa0003f6 	mov	x22, x0
    5a5c:	f9402800 	ldr	x0, [x0, #80]
    5a60:	b5ffe980 	cbnz	x0, 5790 <w120+0x60>
    5a64:	a9005a74 	stp	x20, x22, [x19]
    5a68:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5a6c:	f9400ad7 	ldr	x23, [x22, #16]
    5a70:	eb0002ff 	cmp	x23, x0
    5a74:	54000acc 	b.gt	5bcc <w120+0x49c>
    5a78:	eb3842ff 	cmp	x23, w24, uxtw
    5a7c:	54000a2d 	b.le	5bc0 <w120+0x490>
    5a80:	f94006d4 	ldr	x20, [x22, #8]
    5a84:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5a88:	cb1402f4 	sub	x20, x23, x20
    5a8c:	91000681 	add	x1, x20, #0x1
    5a90:	eb00003f 	cmp	x1, x0
    5a94:	540009c8 	b.hi	5bcc <w120+0x49c>  // b.pmore
    5a98:	f9400ec0 	ldr	x0, [x22, #24]
    5a9c:	eb00003f 	cmp	x1, x0
    5aa0:	5400006d 	b.le	5aac <w120+0x37c>
    5aa4:	aa1603e0 	mov	x0, x22
    5aa8:	97fffe4a 	bl	53d0 <fwp_tape_grow.constprop.0>
    5aac:	8b140694 	add	x20, x20, x20, lsl #1
    5ab0:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x780>
    5ab4:	f94012c1 	ldr	x1, [x22, #32]
    5ab8:	d37df294 	lsl	x20, x20, #3
    5abc:	3dc22000 	ldr	q0, [x0, #2176]
    5ac0:	8b140020 	add	x0, x1, x20
    5ac4:	b8346838 	str	w24, [x1, x20]
    5ac8:	12800002 	mov	w2, #0xffffffff            	// #-1
    5acc:	92607f18 	and	x24, x24, #0xffffffff00000000
    5ad0:	910006e1 	add	x1, x23, #0x1
    5ad4:	b9000402 	str	w2, [x0, #4]
    5ad8:	1e6a0949 	fmul	d9, d10, d10
    5adc:	3c808000 	stur	q0, [x0, #8]
    5ae0:	aa170318 	orr	x24, x24, x23
    5ae4:	aa1503e0 	mov	x0, x21
    5ae8:	f9000ac1 	str	x1, [x22, #16]
    5aec:	b10006bf 	cmn	x21, #0x1
    5af0:	540004e0 	b.eq	5b8c <w120+0x45c>  // b.none
    5af4:	f9400260 	ldr	x0, [x19]
    5af8:	9360feb4 	asr	x20, x21, #32
    5afc:	eb14001f 	cmp	x0, x20
    5b00:	54000740 	b.eq	5be8 <w120+0x4b8>  // b.none
    5b04:	aa1403e0 	mov	x0, x20
    5b08:	97fffbfa 	bl	4af0 <fwp_tape_of>
    5b0c:	aa0003f6 	mov	x22, x0
    5b10:	f9402800 	ldr	x0, [x0, #80]
    5b14:	b5ffe3e0 	cbnz	x0, 5790 <w120+0x60>
    5b18:	a9005a74 	stp	x20, x22, [x19]
    5b1c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5b20:	f9400ad7 	ldr	x23, [x22, #16]
    5b24:	eb0002ff 	cmp	x23, x0
    5b28:	5400052c 	b.gt	5bcc <w120+0x49c>
    5b2c:	eb3542ff 	cmp	x23, w21, uxtw
    5b30:	5400048d 	b.le	5bc0 <w120+0x490>
    5b34:	f94006d4 	ldr	x20, [x22, #8]
    5b38:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5b3c:	cb1402f4 	sub	x20, x23, x20
    5b40:	91000681 	add	x1, x20, #0x1
    5b44:	eb00003f 	cmp	x1, x0
    5b48:	54000428 	b.hi	5bcc <w120+0x49c>  // b.pmore
    5b4c:	f9400ec0 	ldr	x0, [x22, #24]
    5b50:	eb00003f 	cmp	x1, x0
    5b54:	5400006d 	b.le	5b60 <w120+0x430>
    5b58:	aa1603e0 	mov	x0, x22
    5b5c:	97fffe1d 	bl	53d0 <fwp_tape_grow.constprop.0>
    5b60:	8b140694 	add	x20, x20, x20, lsl #1
    5b64:	92607ea0 	and	x0, x21, #0xffffffff00000000
    5b68:	f94012c2 	ldr	x2, [x22, #32]
    5b6c:	d37df294 	lsl	x20, x20, #3
    5b70:	aa170000 	orr	x0, x0, x23
    5b74:	910006f7 	add	x23, x23, #0x1
    5b78:	8b140041 	add	x1, x2, x20
    5b7c:	b8346855 	str	w21, [x2, x20]
    5b80:	b9000435 	str	w21, [x1, #4]
    5b84:	6d00a82a 	stp	d10, d10, [x1, #8]
    5b88:	f9000ad7 	str	x23, [x22, #16]
    5b8c:	1e604101 	fmov	d1, d8
    5b90:	1e604120 	fmov	d0, d9
    5b94:	aa1303e2 	mov	x2, x19
    5b98:	aa1803e1 	mov	x1, x24
    5b9c:	97fffe7d 	bl	5590 <w123>
    5ba0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ba4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5ba8:	a94363f7 	ldp	x23, x24, [sp, #48]
    5bac:	f94023f9 	ldr	x25, [sp, #64]
    5bb0:	fd4027ea 	ldr	d10, [sp, #72]
    5bb4:	6d4527e8 	ldp	d8, d9, [sp, #80]
    5bb8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5bbc:	d65f03c0 	ret
    5bc0:	90000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    5bc4:	91388000 	add	x0, x0, #0xe20
    5bc8:	97fff9c7 	bl	42e4 <fwp_trap>
    5bcc:	90000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    5bd0:	91362000 	add	x0, x0, #0xd88
    5bd4:	97fff9c4 	bl	42e4 <fwp_trap>
    5bd8:	f9400678 	ldr	x24, [x19, #8]
    5bdc:	17ffff1e 	b	5854 <w120+0x124>
    5be0:	f9400457 	ldr	x23, [x2, #8]
    5be4:	17fffeef 	b	57a0 <w120+0x70>
    5be8:	f9400676 	ldr	x22, [x19, #8]
    5bec:	17ffffcc 	b	5b1c <w120+0x3ec>
    5bf0:	f9400676 	ldr	x22, [x19, #8]
    5bf4:	17ffff9d 	b	5a68 <w120+0x338>
    5bf8:	f9400677 	ldr	x23, [x19, #8]
    5bfc:	17ffff72 	b	59c4 <w120+0x294>
    5c00:	f9400677 	ldr	x23, [x19, #8]
    5c04:	17ffff46 	b	591c <w120+0x1ec>
    5c08:	1e6a3829 	fsub	d9, d1, d10
    5c0c:	b6f80161 	tbz	x1, #63, 5c38 <w120+0x508>
    5c10:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5c14:	1e690921 	fmul	d1, d9, d9
    5c18:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5c1c:	9e670002 	fmov	d2, x0
    5c20:	1e683809 	fsub	d9, d0, d8
    5c24:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5c28:	aa1803e0 	mov	x0, x24
    5c2c:	1e620828 	fmul	d8, d1, d2
    5c30:	1e690929 	fmul	d9, d9, d9
    5c34:	17ffffd6 	b	5b8c <w120+0x45c>
    5c38:	b0000040 	adrp	x0, e000 <_IO_stdin_used+0x780>
    5c3c:	9360fc39 	asr	x25, x1, #32
    5c40:	aa0103f4 	mov	x20, x1
    5c44:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5c48:	3dc21800 	ldr	q0, [x0, #2144]
    5c4c:	3d801be0 	str	q0, [sp, #96]
    5c50:	17fffef8 	b	5830 <w120+0x100>
    5c54:	90000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    5c58:	9136a000 	add	x0, x0, #0xda8
    5c5c:	97fff9a2 	bl	42e4 <fwp_trap>
    5c60:	aa0103f5 	mov	x21, x1
    5c64:	17ffff4d 	b	5998 <w120+0x268>
    5c68:	d503201f 	nop
    5c6c:	d503201f 	nop

0000000000005c70 <w176.constprop.0>:
    5c70:	d10183ff 	sub	sp, sp, #0x60
    5c74:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5c78:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    5c7c:	f947f421 	ldr	x1, [x1, #4072]
    5c80:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c84:	910083fd 	add	x29, sp, #0x20
    5c88:	a9045bf5 	stp	x21, x22, [sp, #64]
    5c8c:	f9400015 	ldr	x21, [x0]
    5c90:	f9400023 	ldr	x3, [x1]
    5c94:	f9000fe3 	str	x3, [sp, #24]
    5c98:	d2800003 	mov	x3, #0x0                   	// #0
    5c9c:	a900ffe2 	stp	x2, xzr, [sp, #8]
    5ca0:	b4000435 	cbz	x21, 5d24 <w176.constprop.0+0xb4>
    5ca4:	2f00e400 	movi	d0, #0x0
    5ca8:	91004016 	add	x22, x0, #0x10
    5cac:	a90353f3 	stp	x19, x20, [sp, #48]
    5cb0:	91002014 	add	x20, x0, #0x8
    5cb4:	d2800013 	mov	x19, #0x0                   	// #0
    5cb8:	f9002bf7 	str	x23, [sp, #80]
    5cbc:	910023f7 	add	x23, sp, #0x8
    5cc0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    5cc4:	aa0203e0 	mov	x0, x2
    5cc8:	fc737a81 	ldr	d1, [x20, x19, lsl #3]
    5ccc:	aa1703e2 	mov	x2, x23
    5cd0:	91000a73 	add	x19, x19, #0x2
    5cd4:	97fffe2f 	bl	5590 <w123>
    5cd8:	aa0103e2 	mov	x2, x1
    5cdc:	9e670000 	fmov	d0, x0
    5ce0:	eb1302bf 	cmp	x21, x19
    5ce4:	54fffee8 	b.hi	5cc0 <w176.constprop.0+0x50>  // b.pmore
    5ce8:	a94353f3 	ldp	x19, x20, [sp, #48]
    5cec:	f9402bf7 	ldr	x23, [sp, #80]
    5cf0:	9e660000 	fmov	x0, d0
    5cf4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    5cf8:	f947f421 	ldr	x1, [x1, #4072]
    5cfc:	f9400fe4 	ldr	x4, [sp, #24]
    5d00:	f9400023 	ldr	x3, [x1]
    5d04:	eb030084 	subs	x4, x4, x3
    5d08:	d2800003 	mov	x3, #0x0                   	// #0
    5d0c:	54000101 	b.ne	5d2c <w176.constprop.0+0xbc>  // b.any
    5d10:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d14:	aa0203e1 	mov	x1, x2
    5d18:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5d1c:	910183ff 	add	sp, sp, #0x60
    5d20:	d65f03c0 	ret
    5d24:	2f00e400 	movi	d0, #0x0
    5d28:	17fffff2 	b	5cf0 <w176.constprop.0+0x80>
    5d2c:	a90353f3 	stp	x19, x20, [sp, #48]
    5d30:	f9002bf7 	str	x23, [sp, #80]
    5d34:	97fff2cb 	bl	2860 <__stack_chk_fail@plt>
    5d38:	d503201f 	nop
    5d3c:	d503201f 	nop

0000000000005d40 <fwp_rc_share>:
    5d40:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    5d44:	91188042 	add	x2, x2, #0x620
    5d48:	f949d843 	ldr	x3, [x2, #5040]
    5d4c:	f949ec41 	ldr	x1, [x2, #5080]
    5d50:	cb030000 	sub	x0, x0, x3
    5d54:	eb01401f 	cmp	x0, x1, lsl #16
    5d58:	540003a2 	b.cs	5dcc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5d5c:	d350fc01 	lsr	x1, x0, #16
    5d60:	f949fc44 	ldr	x4, [x2, #5112]
    5d64:	8b010821 	add	x1, x1, x1, lsl #2
    5d68:	d37df021 	lsl	x1, x1, #3
    5d6c:	8b010083 	add	x3, x4, x1
    5d70:	f9401062 	ldr	x2, [x3, #32]
    5d74:	b40002c2 	cbz	x2, 5dcc <fwp_rc_share+0x8c>
    5d78:	38616881 	ldrb	w1, [x4, x1]
    5d7c:	7100083f 	cmp	w1, #0x2
    5d80:	54000220 	b.eq	5dc4 <fwp_rc_share+0x84>  // b.none
    5d84:	7100043f 	cmp	w1, #0x1
    5d88:	54000221 	b.ne	5dcc <fwp_rc_share+0x8c>  // b.any
    5d8c:	29430464 	ldp	w4, w1, [x3, #24]
    5d90:	92403c00 	and	x0, x0, #0xffff
    5d94:	9b047c00 	mul	x0, x0, x4
    5d98:	d360fc00 	lsr	x0, x0, #32
    5d9c:	eb01001f 	cmp	x0, x1
    5da0:	54000162 	b.cs	5dcc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5da4:	8b000042 	add	x2, x2, x0
    5da8:	39400040 	ldrb	w0, [x2]
    5dac:	34000100 	cbz	w0, 5dcc <fwp_rc_share+0x8c>
    5db0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5db4:	90000040 	adrp	x0, d000 <fwp_main_thread+0x42c>
    5db8:	91390000 	add	x0, x0, #0xe40
    5dbc:	910003fd 	mov	x29, sp
    5dc0:	97fff949 	bl	42e4 <fwp_trap>
    5dc4:	72003c1f 	tst	w0, #0xffff
    5dc8:	54ffff00 	b.eq	5da8 <fwp_rc_share+0x68>  // b.none
    5dcc:	d65f03c0 	ret

0000000000005dd0 <fwp_rc_fresh>:
    5dd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5dd4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5dd8:	91188063 	add	x3, x3, #0x620
    5ddc:	910003fd 	mov	x29, sp
    5de0:	a90153f3 	stp	x19, x20, [sp, #16]
    5de4:	aa0003f3 	mov	x19, x0
    5de8:	f949d861 	ldr	x1, [x3, #5040]
    5dec:	f949ec60 	ldr	x0, [x3, #5080]
    5df0:	cb010261 	sub	x1, x19, x1
    5df4:	eb00403f 	cmp	x1, x0, lsl #16
    5df8:	54000322 	b.cs	5e5c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5dfc:	d350fc22 	lsr	x2, x1, #16
    5e00:	f949fc63 	ldr	x3, [x3, #5112]
    5e04:	8b020842 	add	x2, x2, x2, lsl #2
    5e08:	d37df042 	lsl	x2, x2, #3
    5e0c:	8b020060 	add	x0, x3, x2
    5e10:	f9401014 	ldr	x20, [x0, #32]
    5e14:	b4000254 	cbz	x20, 5e5c <fwp_rc_fresh+0x8c>
    5e18:	38626862 	ldrb	w2, [x3, x2]
    5e1c:	7100085f 	cmp	w2, #0x2
    5e20:	54000260 	b.eq	5e6c <fwp_rc_fresh+0x9c>  // b.none
    5e24:	7100045f 	cmp	w2, #0x1
    5e28:	540001a1 	b.ne	5e5c <fwp_rc_fresh+0x8c>  // b.any
    5e2c:	29430002 	ldp	w2, w0, [x0, #24]
    5e30:	92403c21 	and	x1, x1, #0xffff
    5e34:	9b027c21 	mul	x1, x1, x2
    5e38:	d360fc21 	lsr	x1, x1, #32
    5e3c:	eb00003f 	cmp	x1, x0
    5e40:	540000e2 	b.cs	5e5c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5e44:	8b010294 	add	x20, x20, x1
    5e48:	39400280 	ldrb	w0, [x20]
    5e4c:	7103fc1f 	cmp	w0, #0xff
    5e50:	540001a0 	b.eq	5e84 <fwp_rc_fresh+0xb4>  // b.none
    5e54:	52800020 	mov	w0, #0x1                   	// #1
    5e58:	39000280 	strb	w0, [x20]
    5e5c:	aa1303e0 	mov	x0, x19
    5e60:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e64:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e68:	d65f03c0 	ret
    5e6c:	72003c3f 	tst	w1, #0xffff
    5e70:	54fffec0 	b.eq	5e48 <fwp_rc_fresh+0x78>  // b.none
    5e74:	aa1303e0 	mov	x0, x19
    5e78:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e7c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e80:	d65f03c0 	ret
    5e84:	aa1403e0 	mov	x0, x20
    5e88:	97fff937 	bl	4364 <fwp_rc_forget_slot.part.0>
    5e8c:	17fffff2 	b	5e54 <fwp_rc_fresh+0x84>

0000000000005e90 <fwp_rc_free_arr>:
    5e90:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    5e94:	91188063 	add	x3, x3, #0x620
    5e98:	f949d861 	ldr	x1, [x3, #5040]
    5e9c:	f949ec62 	ldr	x2, [x3, #5080]
    5ea0:	cb010001 	sub	x1, x0, x1
    5ea4:	eb02403f 	cmp	x1, x2, lsl #16
    5ea8:	54000342 	b.cs	5f10 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5eac:	d350fc22 	lsr	x2, x1, #16
    5eb0:	f949fc65 	ldr	x5, [x3, #5112]
    5eb4:	8b020842 	add	x2, x2, x2, lsl #2
    5eb8:	d37df042 	lsl	x2, x2, #3
    5ebc:	8b0200a4 	add	x4, x5, x2
    5ec0:	f9401083 	ldr	x3, [x4, #32]
    5ec4:	b4000263 	cbz	x3, 5f10 <fwp_rc_free_arr+0x80>
    5ec8:	386268a2 	ldrb	w2, [x5, x2]
    5ecc:	7100085f 	cmp	w2, #0x2
    5ed0:	540001c0 	b.eq	5f08 <fwp_rc_free_arr+0x78>  // b.none
    5ed4:	7100045f 	cmp	w2, #0x1
    5ed8:	540001c1 	b.ne	5f10 <fwp_rc_free_arr+0x80>  // b.any
    5edc:	29430885 	ldp	w5, w2, [x4, #24]
    5ee0:	92403c21 	and	x1, x1, #0xffff
    5ee4:	9b057c21 	mul	x1, x1, x5
    5ee8:	d360fc21 	lsr	x1, x1, #32
    5eec:	eb02003f 	cmp	x1, x2
    5ef0:	54000102 	b.cs	5f10 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5ef4:	8b010063 	add	x3, x3, x1
    5ef8:	39400061 	ldrb	w1, [x3]
    5efc:	7100043f 	cmp	w1, #0x1
    5f00:	54000081 	b.ne	5f10 <fwp_rc_free_arr+0x80>  // b.any
    5f04:	17fff9b3 	b	45d0 <fwp_mem_free>
    5f08:	72003c3f 	tst	w1, #0xffff
    5f0c:	54ffff60 	b.eq	5ef8 <fwp_rc_free_arr+0x68>  // b.none
    5f10:	d65f03c0 	ret

0000000000005f14 <fwp_rc_dup>:
    5f14:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    5f18:	91188042 	add	x2, x2, #0x620
    5f1c:	f949d841 	ldr	x1, [x2, #5040]
    5f20:	f949ec43 	ldr	x3, [x2, #5080]
    5f24:	cb010001 	sub	x1, x0, x1
    5f28:	eb03403f 	cmp	x1, x3, lsl #16
    5f2c:	540003c2 	b.cs	5fa4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5f30:	d350fc20 	lsr	x0, x1, #16
    5f34:	f949fc44 	ldr	x4, [x2, #5112]
    5f38:	8b000800 	add	x0, x0, x0, lsl #2
    5f3c:	d37df002 	lsl	x2, x0, #3
    5f40:	8b020083 	add	x3, x4, x2
    5f44:	f9401060 	ldr	x0, [x3, #32]
    5f48:	b40002e0 	cbz	x0, 5fa4 <fwp_rc_dup+0x90>
    5f4c:	38626882 	ldrb	w2, [x4, x2]
    5f50:	7100085f 	cmp	w2, #0x2
    5f54:	540002a0 	b.eq	5fa8 <fwp_rc_dup+0x94>  // b.none
    5f58:	7100045f 	cmp	w2, #0x1
    5f5c:	54000241 	b.ne	5fa4 <fwp_rc_dup+0x90>  // b.any
    5f60:	29430864 	ldp	w4, w2, [x3, #24]
    5f64:	92403c21 	and	x1, x1, #0xffff
    5f68:	9b047c21 	mul	x1, x1, x4
    5f6c:	d360fc21 	lsr	x1, x1, #32
    5f70:	eb02003f 	cmp	x1, x2
    5f74:	54000182 	b.cs	5fa4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5f78:	8b010000 	add	x0, x0, x1
    5f7c:	39400001 	ldrb	w1, [x0]
    5f80:	34000121 	cbz	w1, 5fa4 <fwp_rc_dup+0x90>
    5f84:	f00000c2 	adrp	x2, 20000 <__data_start>
    5f88:	91014042 	add	x2, x2, #0x50
    5f8c:	b9412043 	ldr	w3, [x2, #288]
    5f90:	35000123 	cbnz	w3, 5fb4 <fwp_rc_dup+0xa0>
    5f94:	7103f43f 	cmp	w1, #0xfd
    5f98:	54000168 	b.hi	5fc4 <fwp_rc_dup+0xb0>  // b.pmore
    5f9c:	11000421 	add	w1, w1, #0x1
    5fa0:	39000001 	strb	w1, [x0]
    5fa4:	d65f03c0 	ret
    5fa8:	72003c3f 	tst	w1, #0xffff
    5fac:	54fffe80 	b.eq	5f7c <fwp_rc_dup+0x68>  // b.none
    5fb0:	d65f03c0 	ret
    5fb4:	f940a443 	ldr	x3, [x2, #328]
    5fb8:	91000463 	add	x3, x3, #0x1
    5fbc:	f900a443 	str	x3, [x2, #328]
    5fc0:	17fffff5 	b	5f94 <fwp_rc_dup+0x80>
    5fc4:	17fff9fc 	b	47b4 <fwp_rc_wide_dup>
    5fc8:	d503201f 	nop
    5fcc:	d503201f 	nop

0000000000005fd0 <fwp_owned_entry173>:
    5fd0:	d10103ff 	sub	sp, sp, #0x40
    5fd4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    5fd8:	f947f442 	ldr	x2, [x2, #4072]
    5fdc:	a9027bfd 	stp	x29, x30, [sp, #32]
    5fe0:	910083fd 	add	x29, sp, #0x20
    5fe4:	a90353f3 	stp	x19, x20, [sp, #48]
    5fe8:	f9400043 	ldr	x3, [x2]
    5fec:	f9000fe3 	str	x3, [sp, #24]
    5ff0:	d2800003 	mov	x3, #0x0                   	// #0
    5ff4:	a9400c01 	ldp	x1, x3, [x0]
    5ff8:	f9400802 	ldr	x2, [x0, #16]
    5ffc:	ab020022 	adds	x2, x1, x2
    6000:	540006e6 	b.vs	60dc <fwp_owned_entry173+0x10c>
    6004:	910023e1 	add	x1, sp, #0x8
    6008:	52800000 	mov	w0, #0x0                   	// #0
    600c:	a9008be3 	stp	x3, x2, [sp, #8]
    6010:	97fffc90 	bl	5250 <fwp_data.part.0.constprop.0>
    6014:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    6018:	91188063 	add	x3, x3, #0x620
    601c:	aa0003f3 	mov	x19, x0
    6020:	f949d861 	ldr	x1, [x3, #5040]
    6024:	f949ec60 	ldr	x0, [x3, #5080]
    6028:	cb010261 	sub	x1, x19, x1
    602c:	eb00403f 	cmp	x1, x0, lsl #16
    6030:	54000322 	b.cs	6094 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    6034:	d350fc22 	lsr	x2, x1, #16
    6038:	f949fc63 	ldr	x3, [x3, #5112]
    603c:	8b020842 	add	x2, x2, x2, lsl #2
    6040:	d37df042 	lsl	x2, x2, #3
    6044:	8b020060 	add	x0, x3, x2
    6048:	f9401014 	ldr	x20, [x0, #32]
    604c:	b4000254 	cbz	x20, 6094 <fwp_owned_entry173+0xc4>
    6050:	38626862 	ldrb	w2, [x3, x2]
    6054:	7100085f 	cmp	w2, #0x2
    6058:	54000360 	b.eq	60c4 <fwp_owned_entry173+0xf4>  // b.none
    605c:	7100045f 	cmp	w2, #0x1
    6060:	540001a1 	b.ne	6094 <fwp_owned_entry173+0xc4>  // b.any
    6064:	29430002 	ldp	w2, w0, [x0, #24]
    6068:	92403c21 	and	x1, x1, #0xffff
    606c:	9b027c21 	mul	x1, x1, x2
    6070:	d360fc21 	lsr	x1, x1, #32
    6074:	eb00003f 	cmp	x1, x0
    6078:	540000e2 	b.cs	6094 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    607c:	8b010294 	add	x20, x20, x1
    6080:	39400280 	ldrb	w0, [x20]
    6084:	7103fc1f 	cmp	w0, #0xff
    6088:	54000240 	b.eq	60d0 <fwp_owned_entry173+0x100>  // b.none
    608c:	52800020 	mov	w0, #0x1                   	// #1
    6090:	39000280 	strb	w0, [x20]
    6094:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    6098:	f947f400 	ldr	x0, [x0, #4072]
    609c:	f9400fe2 	ldr	x2, [sp, #24]
    60a0:	f9400001 	ldr	x1, [x0]
    60a4:	eb010042 	subs	x2, x2, x1
    60a8:	d2800001 	mov	x1, #0x0                   	// #0
    60ac:	540001a1 	b.ne	60e0 <fwp_owned_entry173+0x110>  // b.any
    60b0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    60b4:	aa1303e0 	mov	x0, x19
    60b8:	a94353f3 	ldp	x19, x20, [sp, #48]
    60bc:	910103ff 	add	sp, sp, #0x40
    60c0:	d65f03c0 	ret
    60c4:	72003c3f 	tst	w1, #0xffff
    60c8:	54fffe61 	b.ne	6094 <fwp_owned_entry173+0xc4>  // b.any
    60cc:	17ffffed 	b	6080 <fwp_owned_entry173+0xb0>
    60d0:	aa1403e0 	mov	x0, x20
    60d4:	97fff8a4 	bl	4364 <fwp_rc_forget_slot.part.0>
    60d8:	17ffffed 	b	608c <fwp_owned_entry173+0xbc>
    60dc:	97fff259 	bl	2a40 <fwp_trap_overflow.constprop.0>
    60e0:	97fff1e0 	bl	2860 <__stack_chk_fail@plt>

00000000000060e4 <e173>:
    60e4:	d10103ff 	sub	sp, sp, #0x40
    60e8:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    60ec:	f947f442 	ldr	x2, [x2, #4072]
    60f0:	a9027bfd 	stp	x29, x30, [sp, #32]
    60f4:	910083fd 	add	x29, sp, #0x20
    60f8:	a90353f3 	stp	x19, x20, [sp, #48]
    60fc:	f9400043 	ldr	x3, [x2]
    6100:	f9000fe3 	str	x3, [sp, #24]
    6104:	d2800003 	mov	x3, #0x0                   	// #0
    6108:	a9400c01 	ldp	x1, x3, [x0]
    610c:	f9400802 	ldr	x2, [x0, #16]
    6110:	ab020022 	adds	x2, x1, x2
    6114:	54000726 	b.vs	61f8 <e173+0x114>
    6118:	910023e1 	add	x1, sp, #0x8
    611c:	52800000 	mov	w0, #0x0                   	// #0
    6120:	a9008be3 	stp	x3, x2, [sp, #8]
    6124:	97fffc4b 	bl	5250 <fwp_data.part.0.constprop.0>
    6128:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    612c:	91188063 	add	x3, x3, #0x620
    6130:	aa0003f3 	mov	x19, x0
    6134:	f949d861 	ldr	x1, [x3, #5040]
    6138:	f949ec60 	ldr	x0, [x3, #5080]
    613c:	cb010261 	sub	x1, x19, x1
    6140:	eb00403f 	cmp	x1, x0, lsl #16
    6144:	54000322 	b.cs	61a8 <e173+0xc4>  // b.hs, b.nlast
    6148:	d350fc22 	lsr	x2, x1, #16
    614c:	f949fc63 	ldr	x3, [x3, #5112]
    6150:	8b020842 	add	x2, x2, x2, lsl #2
    6154:	d37df042 	lsl	x2, x2, #3
    6158:	8b020060 	add	x0, x3, x2
    615c:	f9401014 	ldr	x20, [x0, #32]
    6160:	b4000254 	cbz	x20, 61a8 <e173+0xc4>
    6164:	38626862 	ldrb	w2, [x3, x2]
    6168:	7100085f 	cmp	w2, #0x2
    616c:	540003a0 	b.eq	61e0 <e173+0xfc>  // b.none
    6170:	7100045f 	cmp	w2, #0x1
    6174:	540001a1 	b.ne	61a8 <e173+0xc4>  // b.any
    6178:	29430002 	ldp	w2, w0, [x0, #24]
    617c:	92403c21 	and	x1, x1, #0xffff
    6180:	9b027c21 	mul	x1, x1, x2
    6184:	d360fc21 	lsr	x1, x1, #32
    6188:	eb00003f 	cmp	x1, x0
    618c:	540000e2 	b.cs	61a8 <e173+0xc4>  // b.hs, b.nlast
    6190:	8b010294 	add	x20, x20, x1
    6194:	39400280 	ldrb	w0, [x20]
    6198:	7103fc1f 	cmp	w0, #0xff
    619c:	54000280 	b.eq	61ec <e173+0x108>  // b.none
    61a0:	52800020 	mov	w0, #0x1                   	// #1
    61a4:	39000280 	strb	w0, [x20]
    61a8:	aa1303e0 	mov	x0, x19
    61ac:	97fffee5 	bl	5d40 <fwp_rc_share>
    61b0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    61b4:	f947f400 	ldr	x0, [x0, #4072]
    61b8:	f9400fe2 	ldr	x2, [sp, #24]
    61bc:	f9400001 	ldr	x1, [x0]
    61c0:	eb010042 	subs	x2, x2, x1
    61c4:	d2800001 	mov	x1, #0x0                   	// #0
    61c8:	540001a1 	b.ne	61fc <e173+0x118>  // b.any
    61cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    61d0:	aa1303e0 	mov	x0, x19
    61d4:	a94353f3 	ldp	x19, x20, [sp, #48]
    61d8:	910103ff 	add	sp, sp, #0x40
    61dc:	d65f03c0 	ret
    61e0:	72003c3f 	tst	w1, #0xffff
    61e4:	54fffe21 	b.ne	61a8 <e173+0xc4>  // b.any
    61e8:	17ffffeb 	b	6194 <e173+0xb0>
    61ec:	aa1403e0 	mov	x0, x20
    61f0:	97fff85d 	bl	4364 <fwp_rc_forget_slot.part.0>
    61f4:	17ffffeb 	b	61a0 <e173+0xbc>
    61f8:	97fff212 	bl	2a40 <fwp_trap_overflow.constprop.0>
    61fc:	97fff199 	bl	2860 <__stack_chk_fail@plt>

0000000000006200 <fwp_drop0>:
    6200:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6204:	910003fd 	mov	x29, sp
    6208:	a90153f3 	stp	x19, x20, [sp, #16]
    620c:	f90013f5 	str	x21, [sp, #32]
    6210:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    6214:	911882b4 	add	x20, x21, #0x620
    6218:	f949da81 	ldr	x1, [x20, #5040]
    621c:	f949ee82 	ldr	x2, [x20, #5080]
    6220:	cb010001 	sub	x1, x0, x1
    6224:	eb02403f 	cmp	x1, x2, lsl #16
    6228:	54000382 	b.cs	6298 <fwp_drop0+0x98>  // b.hs, b.nlast
    622c:	d350fc22 	lsr	x2, x1, #16
    6230:	f949fe84 	ldr	x4, [x20, #5112]
    6234:	8b020842 	add	x2, x2, x2, lsl #2
    6238:	d37df042 	lsl	x2, x2, #3
    623c:	8b020083 	add	x3, x4, x2
    6240:	f9401073 	ldr	x19, [x3, #32]
    6244:	b40002b3 	cbz	x19, 6298 <fwp_drop0+0x98>
    6248:	38626882 	ldrb	w2, [x4, x2]
    624c:	7100085f 	cmp	w2, #0x2
    6250:	540002c0 	b.eq	62a8 <fwp_drop0+0xa8>  // b.none
    6254:	7100045f 	cmp	w2, #0x1
    6258:	54000201 	b.ne	6298 <fwp_drop0+0x98>  // b.any
    625c:	29430864 	ldp	w4, w2, [x3, #24]
    6260:	92403c21 	and	x1, x1, #0xffff
    6264:	9b047c21 	mul	x1, x1, x4
    6268:	d360fc21 	lsr	x1, x1, #32
    626c:	eb02003f 	cmp	x1, x2
    6270:	54000142 	b.cs	6298 <fwp_drop0+0x98>  // b.hs, b.nlast
    6274:	8b010273 	add	x19, x19, x1
    6278:	39400261 	ldrb	w1, [x19]
    627c:	340000e1 	cbz	w1, 6298 <fwp_drop0+0x98>
    6280:	7100043f 	cmp	w1, #0x1
    6284:	540001e0 	b.eq	62c0 <fwp_drop0+0xc0>  // b.none
    6288:	7103fc3f 	cmp	w1, #0xff
    628c:	540002e0 	b.eq	62e8 <fwp_drop0+0xe8>  // b.none
    6290:	51000421 	sub	w1, w1, #0x1
    6294:	39000261 	strb	w1, [x19]
    6298:	a94153f3 	ldp	x19, x20, [sp, #16]
    629c:	f94013f5 	ldr	x21, [sp, #32]
    62a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62a4:	d65f03c0 	ret
    62a8:	72003c3f 	tst	w1, #0xffff
    62ac:	54fffe60 	b.eq	6278 <fwp_drop0+0x78>  // b.none
    62b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    62b4:	f94013f5 	ldr	x21, [sp, #32]
    62b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62bc:	d65f03c0 	ret
    62c0:	f9400813 	ldr	x19, [x0, #16]
    62c4:	97fffef3 	bl	5e90 <fwp_rc_free_arr>
    62c8:	911882a0 	add	x0, x21, #0x620
    62cc:	f949d801 	ldr	x1, [x0, #5040]
    62d0:	f949ec00 	ldr	x0, [x0, #5080]
    62d4:	cb010261 	sub	x1, x19, x1
    62d8:	eb00403f 	cmp	x1, x0, lsl #16
    62dc:	54fffde2 	b.cs	6298 <fwp_drop0+0x98>  // b.hs, b.nlast
    62e0:	aa1303e0 	mov	x0, x19
    62e4:	17ffffd2 	b	622c <fwp_drop0+0x2c>
    62e8:	ca534660 	eor	x0, x19, x19, lsr #17
    62ec:	911882b5 	add	x21, x21, #0x620
    62f0:	ca402400 	eor	x0, x0, x0, lsr #9
    62f4:	92401c00 	and	x0, x0, #0xff
    62f8:	910a2402 	add	x2, x0, #0x289
    62fc:	8b000ea0 	add	x0, x21, x0, lsl #3
    6300:	8b020ea2 	add	x2, x21, x2, lsl #3
    6304:	f94a2400 	ldr	x0, [x0, #5192]
    6308:	b50000a0 	cbnz	x0, 631c <fwp_drop0+0x11c>
    630c:	14000013 	b	6358 <fwp_drop0+0x158>
    6310:	91004002 	add	x2, x0, #0x10
    6314:	f9400800 	ldr	x0, [x0, #16]
    6318:	b4000200 	cbz	x0, 6358 <fwp_drop0+0x158>
    631c:	f9400001 	ldr	x1, [x0]
    6320:	eb13003f 	cmp	x1, x19
    6324:	54ffff61 	b.ne	6310 <fwp_drop0+0x110>  // b.any
    6328:	f9400041 	ldr	x1, [x2]
    632c:	f9400420 	ldr	x0, [x1, #8]
    6330:	d1000400 	sub	x0, x0, #0x1
    6334:	f9000420 	str	x0, [x1, #8]
    6338:	f103f81f 	cmp	x0, #0xfe
    633c:	54fffae1 	b.ne	6298 <fwp_drop0+0x98>  // b.any
    6340:	39400260 	ldrb	w0, [x19]
    6344:	7103fc1f 	cmp	w0, #0xff
    6348:	540000e0 	b.eq	6364 <fwp_drop0+0x164>  // b.none
    634c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6350:	39000260 	strb	w0, [x19]
    6354:	17ffffd1 	b	6298 <fwp_drop0+0x98>
    6358:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    635c:	912f6000 	add	x0, x0, #0xbd8
    6360:	97fff7e1 	bl	42e4 <fwp_trap>
    6364:	aa1303e0 	mov	x0, x19
    6368:	97fff7ff 	bl	4364 <fwp_rc_forget_slot.part.0>
    636c:	17fffff8 	b	634c <fwp_drop0+0x14c>

0000000000006370 <fwp_drop1>:
    6370:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6374:	910003fd 	mov	x29, sp
    6378:	a90153f3 	stp	x19, x20, [sp, #16]
    637c:	f90013f5 	str	x21, [sp, #32]
    6380:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbc0>
    6384:	911882b4 	add	x20, x21, #0x620
    6388:	f949da81 	ldr	x1, [x20, #5040]
    638c:	f949ee82 	ldr	x2, [x20, #5080]
    6390:	cb010001 	sub	x1, x0, x1
    6394:	eb02403f 	cmp	x1, x2, lsl #16
    6398:	54000382 	b.cs	6408 <fwp_drop1+0x98>  // b.hs, b.nlast
    639c:	d350fc22 	lsr	x2, x1, #16
    63a0:	f949fe84 	ldr	x4, [x20, #5112]
    63a4:	8b020842 	add	x2, x2, x2, lsl #2
    63a8:	d37df042 	lsl	x2, x2, #3
    63ac:	8b020083 	add	x3, x4, x2
    63b0:	f9401073 	ldr	x19, [x3, #32]
    63b4:	b40002b3 	cbz	x19, 6408 <fwp_drop1+0x98>
    63b8:	38626882 	ldrb	w2, [x4, x2]
    63bc:	7100085f 	cmp	w2, #0x2
    63c0:	540002c0 	b.eq	6418 <fwp_drop1+0xa8>  // b.none
    63c4:	7100045f 	cmp	w2, #0x1
    63c8:	54000201 	b.ne	6408 <fwp_drop1+0x98>  // b.any
    63cc:	29430864 	ldp	w4, w2, [x3, #24]
    63d0:	92403c21 	and	x1, x1, #0xffff
    63d4:	9b047c21 	mul	x1, x1, x4
    63d8:	d360fc21 	lsr	x1, x1, #32
    63dc:	eb02003f 	cmp	x1, x2
    63e0:	54000142 	b.cs	6408 <fwp_drop1+0x98>  // b.hs, b.nlast
    63e4:	8b010273 	add	x19, x19, x1
    63e8:	39400261 	ldrb	w1, [x19]
    63ec:	340000e1 	cbz	w1, 6408 <fwp_drop1+0x98>
    63f0:	7100043f 	cmp	w1, #0x1
    63f4:	540001e0 	b.eq	6430 <fwp_drop1+0xc0>  // b.none
    63f8:	7103fc3f 	cmp	w1, #0xff
    63fc:	540002e0 	b.eq	6458 <fwp_drop1+0xe8>  // b.none
    6400:	51000421 	sub	w1, w1, #0x1
    6404:	39000261 	strb	w1, [x19]
    6408:	a94153f3 	ldp	x19, x20, [sp, #16]
    640c:	f94013f5 	ldr	x21, [sp, #32]
    6410:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6414:	d65f03c0 	ret
    6418:	72003c3f 	tst	w1, #0xffff
    641c:	54fffe60 	b.eq	63e8 <fwp_drop1+0x78>  // b.none
    6420:	a94153f3 	ldp	x19, x20, [sp, #16]
    6424:	f94013f5 	ldr	x21, [sp, #32]
    6428:	a8c37bfd 	ldp	x29, x30, [sp], #48
    642c:	d65f03c0 	ret
    6430:	f9400813 	ldr	x19, [x0, #16]
    6434:	97fffe97 	bl	5e90 <fwp_rc_free_arr>
    6438:	911882a0 	add	x0, x21, #0x620
    643c:	f949d801 	ldr	x1, [x0, #5040]
    6440:	f949ec00 	ldr	x0, [x0, #5080]
    6444:	cb010261 	sub	x1, x19, x1
    6448:	eb00403f 	cmp	x1, x0, lsl #16
    644c:	54fffde2 	b.cs	6408 <fwp_drop1+0x98>  // b.hs, b.nlast
    6450:	aa1303e0 	mov	x0, x19
    6454:	17ffffd2 	b	639c <fwp_drop1+0x2c>
    6458:	ca534660 	eor	x0, x19, x19, lsr #17
    645c:	911882b5 	add	x21, x21, #0x620
    6460:	ca402400 	eor	x0, x0, x0, lsr #9
    6464:	92401c00 	and	x0, x0, #0xff
    6468:	910a2402 	add	x2, x0, #0x289
    646c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6470:	8b020ea2 	add	x2, x21, x2, lsl #3
    6474:	f94a2400 	ldr	x0, [x0, #5192]
    6478:	b50000a0 	cbnz	x0, 648c <fwp_drop1+0x11c>
    647c:	14000013 	b	64c8 <fwp_drop1+0x158>
    6480:	91004002 	add	x2, x0, #0x10
    6484:	f9400800 	ldr	x0, [x0, #16]
    6488:	b4000200 	cbz	x0, 64c8 <fwp_drop1+0x158>
    648c:	f9400001 	ldr	x1, [x0]
    6490:	eb13003f 	cmp	x1, x19
    6494:	54ffff61 	b.ne	6480 <fwp_drop1+0x110>  // b.any
    6498:	f9400041 	ldr	x1, [x2]
    649c:	f9400420 	ldr	x0, [x1, #8]
    64a0:	d1000400 	sub	x0, x0, #0x1
    64a4:	f9000420 	str	x0, [x1, #8]
    64a8:	f103f81f 	cmp	x0, #0xfe
    64ac:	54fffae1 	b.ne	6408 <fwp_drop1+0x98>  // b.any
    64b0:	39400260 	ldrb	w0, [x19]
    64b4:	7103fc1f 	cmp	w0, #0xff
    64b8:	540000e0 	b.eq	64d4 <fwp_drop1+0x164>  // b.none
    64bc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64c0:	39000260 	strb	w0, [x19]
    64c4:	17ffffd1 	b	6408 <fwp_drop1+0x98>
    64c8:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    64cc:	912f6000 	add	x0, x0, #0xbd8
    64d0:	97fff785 	bl	42e4 <fwp_trap>
    64d4:	aa1303e0 	mov	x0, x19
    64d8:	97fff7a3 	bl	4364 <fwp_rc_forget_slot.part.0>
    64dc:	17fffff8 	b	64bc <fwp_drop1+0x14c>

00000000000064e0 <fwp_closure_drop>:
    64e0:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xbc0>
    64e4:	911880a4 	add	x4, x5, #0x620
    64e8:	aa0003e1 	mov	x1, x0
    64ec:	f949d882 	ldr	x2, [x4, #5040]
    64f0:	f949ec80 	ldr	x0, [x4, #5080]
    64f4:	cb020022 	sub	x2, x1, x2
    64f8:	eb00405f 	cmp	x2, x0, lsl #16
    64fc:	54000662 	b.cs	65c8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6504:	d350fc43 	lsr	x3, x2, #16
    6508:	910003fd 	mov	x29, sp
    650c:	8b030863 	add	x3, x3, x3, lsl #2
    6510:	f949fc84 	ldr	x4, [x4, #5112]
    6514:	d37df063 	lsl	x3, x3, #3
    6518:	f9000bf3 	str	x19, [sp, #16]
    651c:	8b030080 	add	x0, x4, x3
    6520:	f9401013 	ldr	x19, [x0, #32]
    6524:	b40002b3 	cbz	x19, 6578 <fwp_closure_drop+0x98>
    6528:	38636883 	ldrb	w3, [x4, x3]
    652c:	7100087f 	cmp	w3, #0x2
    6530:	54000420 	b.eq	65b4 <fwp_closure_drop+0xd4>  // b.none
    6534:	7100047f 	cmp	w3, #0x1
    6538:	54000201 	b.ne	6578 <fwp_closure_drop+0x98>  // b.any
    653c:	29430003 	ldp	w3, w0, [x0, #24]
    6540:	92403c42 	and	x2, x2, #0xffff
    6544:	9b037c42 	mul	x2, x2, x3
    6548:	d360fc42 	lsr	x2, x2, #32
    654c:	eb00005f 	cmp	x2, x0
    6550:	54000142 	b.cs	6578 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6554:	8b020273 	add	x19, x19, x2
    6558:	39400260 	ldrb	w0, [x19]
    655c:	340000e0 	cbz	w0, 6578 <fwp_closure_drop+0x98>
    6560:	7100041f 	cmp	w0, #0x1
    6564:	54000100 	b.eq	6584 <fwp_closure_drop+0xa4>  // b.none
    6568:	7103fc1f 	cmp	w0, #0xff
    656c:	54000300 	b.eq	65cc <fwp_closure_drop+0xec>  // b.none
    6570:	51000400 	sub	w0, w0, #0x1
    6574:	39000260 	strb	w0, [x19]
    6578:	f9400bf3 	ldr	x19, [sp, #16]
    657c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6580:	d65f03c0 	ret
    6584:	d53bd040 	mrs	x0, tpidr_el0
    6588:	91400000 	add	x0, x0, #0x0, lsl #12
    658c:	91004000 	add	x0, x0, #0x10
    6590:	f9400000 	ldr	x0, [x0]
    6594:	b4000080 	cbz	x0, 65a4 <fwp_closure_drop+0xc4>
    6598:	f9400bf3 	ldr	x19, [sp, #16]
    659c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65a0:	17fff8cc 	b	48d0 <fwp_closure_drop_push>
    65a4:	f9400bf3 	ldr	x19, [sp, #16]
    65a8:	aa0103e0 	mov	x0, x1
    65ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65b0:	17fff90d 	b	49e4 <fwp_closure_drop.part.0>
    65b4:	72003c5f 	tst	w2, #0xffff
    65b8:	54fffd00 	b.eq	6558 <fwp_closure_drop+0x78>  // b.none
    65bc:	f9400bf3 	ldr	x19, [sp, #16]
    65c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65c4:	d65f03c0 	ret
    65c8:	d65f03c0 	ret
    65cc:	ca534660 	eor	x0, x19, x19, lsr #17
    65d0:	911880a5 	add	x5, x5, #0x620
    65d4:	ca402400 	eor	x0, x0, x0, lsr #9
    65d8:	92401c00 	and	x0, x0, #0xff
    65dc:	910a2402 	add	x2, x0, #0x289
    65e0:	8b000ca0 	add	x0, x5, x0, lsl #3
    65e4:	8b020ca2 	add	x2, x5, x2, lsl #3
    65e8:	f94a2400 	ldr	x0, [x0, #5192]
    65ec:	b50000a0 	cbnz	x0, 6600 <fwp_closure_drop+0x120>
    65f0:	14000013 	b	663c <fwp_closure_drop+0x15c>
    65f4:	91004002 	add	x2, x0, #0x10
    65f8:	f9400800 	ldr	x0, [x0, #16]
    65fc:	b4000200 	cbz	x0, 663c <fwp_closure_drop+0x15c>
    6600:	f9400001 	ldr	x1, [x0]
    6604:	eb13003f 	cmp	x1, x19
    6608:	54ffff61 	b.ne	65f4 <fwp_closure_drop+0x114>  // b.any
    660c:	f9400041 	ldr	x1, [x2]
    6610:	f9400420 	ldr	x0, [x1, #8]
    6614:	d1000400 	sub	x0, x0, #0x1
    6618:	f9000420 	str	x0, [x1, #8]
    661c:	f103f81f 	cmp	x0, #0xfe
    6620:	54fffac1 	b.ne	6578 <fwp_closure_drop+0x98>  // b.any
    6624:	39400260 	ldrb	w0, [x19]
    6628:	7103fc1f 	cmp	w0, #0xff
    662c:	540000e0 	b.eq	6648 <fwp_closure_drop+0x168>  // b.none
    6630:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6634:	39000260 	strb	w0, [x19]
    6638:	17ffffd0 	b	6578 <fwp_closure_drop+0x98>
    663c:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    6640:	912f6000 	add	x0, x0, #0xbd8
    6644:	97fff728 	bl	42e4 <fwp_trap>
    6648:	aa1303e0 	mov	x0, x19
    664c:	97fff746 	bl	4364 <fwp_rc_forget_slot.part.0>
    6650:	17fffff8 	b	6630 <fwp_closure_drop+0x150>

0000000000006654 <fwp_owned_tape_release>:
    6654:	b4000920 	cbz	x0, 6778 <fwp_owned_tape_release+0x124>
    6658:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    665c:	910003fd 	mov	x29, sp
    6660:	a90153f3 	stp	x19, x20, [sp, #16]
    6664:	aa0003f3 	mov	x19, x0
    6668:	f9400000 	ldr	x0, [x0]
    666c:	b4000060 	cbz	x0, 6678 <fwp_owned_tape_release+0x24>
    6670:	f9400661 	ldr	x1, [x19, #8]
    6674:	f9000401 	str	x1, [x0, #8]
    6678:	f9400661 	ldr	x1, [x19, #8]
    667c:	b4000041 	cbz	x1, 6684 <fwp_owned_tape_release+0x30>
    6680:	f9000020 	str	x0, [x1]
    6684:	f9400a60 	ldr	x0, [x19, #16]
    6688:	f9403401 	ldr	x1, [x0, #104]
    668c:	b40005a1 	cbz	x1, 6740 <fwp_owned_tape_release+0xec>
    6690:	a9450a60 	ldp	x0, x2, [x19, #80]
    6694:	eb00005f 	cmp	x2, x0
    6698:	540002cd 	b.le	66f0 <fwp_owned_tape_release+0x9c>
    669c:	d2800014 	mov	x20, #0x0                   	// #0
    66a0:	f90013f5 	str	x21, [sp, #32]
    66a4:	d2800015 	mov	x21, #0x0                   	// #0
    66a8:	f9402260 	ldr	x0, [x19, #64]
    66ac:	910006b5 	add	x21, x21, #0x1
    66b0:	f8746800 	ldr	x0, [x0, x20]
    66b4:	d63f0020 	blr	x1
    66b8:	f9402260 	ldr	x0, [x19, #64]
    66bc:	f9400a61 	ldr	x1, [x19, #16]
    66c0:	8b140000 	add	x0, x0, x20
    66c4:	91004294 	add	x20, x20, #0x10
    66c8:	f9400400 	ldr	x0, [x0, #8]
    66cc:	f9403421 	ldr	x1, [x1, #104]
    66d0:	d63f0020 	blr	x1
    66d4:	a9450261 	ldp	x1, x0, [x19, #80]
    66d8:	cb010000 	sub	x0, x0, x1
    66dc:	eb15001f 	cmp	x0, x21
    66e0:	f9400a60 	ldr	x0, [x19, #16]
    66e4:	f9403401 	ldr	x1, [x0, #104]
    66e8:	54fffe0c 	b.gt	66a8 <fwp_owned_tape_release+0x54>
    66ec:	f94013f5 	ldr	x21, [sp, #32]
    66f0:	f9403663 	ldr	x3, [x19, #104]
    66f4:	f9401262 	ldr	x2, [x19, #32]
    66f8:	f100007f 	cmp	x3, #0x0
    66fc:	540001ed 	b.le	6738 <fwp_owned_tape_release+0xe4>
    6700:	d2800014 	mov	x20, #0x0                   	// #0
    6704:	d503201f 	nop
    6708:	f9402660 	ldr	x0, [x19, #72]
    670c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6710:	eb02001f 	cmp	x0, x2
    6714:	540000c0 	b.eq	672c <fwp_owned_tape_release+0xd8>  // b.none
    6718:	d63f0020 	blr	x1
    671c:	f9400a60 	ldr	x0, [x19, #16]
    6720:	f9401262 	ldr	x2, [x19, #32]
    6724:	f9403663 	ldr	x3, [x19, #104]
    6728:	f9403401 	ldr	x1, [x0, #104]
    672c:	91000694 	add	x20, x20, #0x1
    6730:	eb14007f 	cmp	x3, x20
    6734:	54fffeac 	b.gt	6708 <fwp_owned_tape_release+0xb4>
    6738:	aa0203e0 	mov	x0, x2
    673c:	d63f0020 	blr	x1
    6740:	f9401660 	ldr	x0, [x19, #40]
    6744:	97ffff67 	bl	64e0 <fwp_closure_drop>
    6748:	f9401a60 	ldr	x0, [x19, #48]
    674c:	97ffff65 	bl	64e0 <fwp_closure_drop>
    6750:	f9401e60 	ldr	x0, [x19, #56]
    6754:	97ffff63 	bl	64e0 <fwp_closure_drop>
    6758:	f9402260 	ldr	x0, [x19, #64]
    675c:	97fff79d 	bl	45d0 <fwp_mem_free>
    6760:	f9402660 	ldr	x0, [x19, #72]
    6764:	97fff79b 	bl	45d0 <fwp_mem_free>
    6768:	aa1303e0 	mov	x0, x19
    676c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6770:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6774:	17fff797 	b	45d0 <fwp_mem_free>
    6778:	d65f03c0 	ret
    677c:	d503201f 	nop

0000000000006780 <fwp_tape_finish>:
    6780:	d101c3ff 	sub	sp, sp, #0x70
    6784:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    6788:	f947f421 	ldr	x1, [x1, #4072]
    678c:	a9037bfd 	stp	x29, x30, [sp, #48]
    6790:	9100c3fd 	add	x29, sp, #0x30
    6794:	a9055bf5 	stp	x21, x22, [sp, #80]
    6798:	a90663f7 	stp	x23, x24, [sp, #96]
    679c:	d00000d7 	adrp	x23, 20000 <__data_start>
    67a0:	910142f6 	add	x22, x23, #0x50
    67a4:	f9400022 	ldr	x2, [x1]
    67a8:	f90017e2 	str	x2, [sp, #40]
    67ac:	d2800002 	mov	x2, #0x0                   	// #0
    67b0:	910342c0 	add	x0, x22, #0xd0
    67b4:	97fff620 	bl	4034 <fwp_tape_buffers_dispose>
    67b8:	f9007edf 	str	xzr, [x22, #248]
    67bc:	f9408ac0 	ldr	x0, [x22, #272]
    67c0:	f100001f 	cmp	x0, #0x0
    67c4:	5400036d 	b.le	6830 <fwp_tape_finish+0xb0>
    67c8:	910003f8 	mov	x24, sp
    67cc:	d2800015 	mov	x21, #0x0                   	// #0
    67d0:	a90453f3 	stp	x19, x20, [sp, #64]
    67d4:	d2800014 	mov	x20, #0x0                   	// #0
    67d8:	91000694 	add	x20, x20, #0x1
    67dc:	f94046d3 	ldr	x19, [x22, #136]
    67e0:	8b150273 	add	x19, x19, x21
    67e4:	910162b5 	add	x21, x21, #0x58
    67e8:	aa1303e0 	mov	x0, x19
    67ec:	97fff1fa 	bl	2fd4 <fwp_tape_unlink_scope>
    67f0:	aa1803e0 	mov	x0, x24
    67f4:	f9400e61 	ldr	x1, [x19, #24]
    67f8:	f9401a62 	ldr	x2, [x19, #48]
    67fc:	a90107e2 	stp	x2, x1, [sp, #16]
    6800:	3dc00a60 	ldr	q0, [x19, #32]
    6804:	f9401e61 	ldr	x1, [x19, #56]
    6808:	f90013e1 	str	x1, [sp, #32]
    680c:	3d8003e0 	str	q0, [sp]
    6810:	97fff609 	bl	4034 <fwp_tape_buffers_dispose>
    6814:	f9402a60 	ldr	x0, [x19, #80]
    6818:	97ffff8f 	bl	6654 <fwp_owned_tape_release>
    681c:	f9002a7f 	str	xzr, [x19, #80]
    6820:	f9408ac0 	ldr	x0, [x22, #272]
    6824:	eb14001f 	cmp	x0, x20
    6828:	54fffd8c 	b.gt	67d8 <fwp_tape_finish+0x58>
    682c:	a94453f3 	ldp	x19, x20, [sp, #64]
    6830:	910142e0 	add	x0, x23, #0x50
    6834:	f9404400 	ldr	x0, [x0, #136]
    6838:	b4000040 	cbz	x0, 6840 <fwp_tape_finish+0xc0>
    683c:	97fff5dd 	bl	3fb0 <ad_raw_free.part.0>
    6840:	910142f7 	add	x23, x23, #0x50
    6844:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    6848:	f947f400 	ldr	x0, [x0, #4072]
    684c:	f90046ff 	str	xzr, [x23, #136]
    6850:	f90082ff 	str	xzr, [x23, #256]
    6854:	f9008aff 	str	xzr, [x23, #272]
    6858:	f900aaff 	str	xzr, [x23, #336]
    685c:	f94017e2 	ldr	x2, [sp, #40]
    6860:	f9400001 	ldr	x1, [x0]
    6864:	eb010042 	subs	x2, x2, x1
    6868:	d2800001 	mov	x1, #0x0                   	// #0
    686c:	540000c1 	b.ne	6884 <fwp_tape_finish+0x104>  // b.any
    6870:	a9437bfd 	ldp	x29, x30, [sp, #48]
    6874:	a9455bf5 	ldp	x21, x22, [sp, #80]
    6878:	a94663f7 	ldp	x23, x24, [sp, #96]
    687c:	9101c3ff 	add	sp, sp, #0x70
    6880:	d65f03c0 	ret
    6884:	a90453f3 	stp	x19, x20, [sp, #64]
    6888:	97ffeff6 	bl	2860 <__stack_chk_fail@plt>
    688c:	d503201f 	nop

0000000000006890 <fwp_tape_scope_release>:
    6890:	d10203ff 	sub	sp, sp, #0x80
    6894:	a9037bfd 	stp	x29, x30, [sp, #48]
    6898:	9100c3fd 	add	x29, sp, #0x30
    689c:	a90453f3 	stp	x19, x20, [sp, #64]
    68a0:	aa0003f4 	mov	x20, x0
    68a4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    68a8:	f947f400 	ldr	x0, [x0, #4072]
    68ac:	b9400285 	ldr	w5, [x20]
    68b0:	f9400001 	ldr	x1, [x0]
    68b4:	f90017e1 	str	x1, [sp, #40]
    68b8:	d2800001 	mov	x1, #0x0                   	// #0
    68bc:	37f806e5 	tbnz	w5, #31, 6998 <fwp_tape_scope_release+0x108>
    68c0:	a90663f7 	stp	x23, x24, [sp, #96]
    68c4:	d2917478 	mov	x24, #0x8ba3                	// #35747
    68c8:	f2b745d8 	movk	x24, #0xba2e, lsl #16
    68cc:	f2d45d18 	movk	x24, #0xa2e8, lsl #32
    68d0:	d00000d3 	adrp	x19, 20000 <__data_start>
    68d4:	910003f7 	mov	x23, sp
    68d8:	91014273 	add	x19, x19, #0x50
    68dc:	f2e5d178 	movk	x24, #0x2e8b, lsl #48
    68e0:	a9055bf5 	stp	x21, x22, [sp, #80]
    68e4:	52800b16 	mov	w22, #0x58                  	// #88
    68e8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    68ec:	f9003bf9 	str	x25, [sp, #112]
    68f0:	14000006 	b	6908 <fwp_tape_scope_release+0x78>
    68f4:	97fff5d0 	bl	4034 <fwp_tape_buffers_dispose>
    68f8:	aa1903e0 	mov	x0, x25
    68fc:	97ffff56 	bl	6654 <fwp_owned_tape_release>
    6900:	b9400285 	ldr	w5, [x20]
    6904:	37f80445 	tbnz	w5, #31, 698c <fwp_tape_scope_release+0xfc>
    6908:	f9404666 	ldr	x6, [x19, #136]
    690c:	9b367ca5 	smull	x5, w5, w22
    6910:	8b0500c0 	add	x0, x6, x5
    6914:	97fff1b0 	bl	2fd4 <fwp_tape_unlink_scope>
    6918:	3dc00800 	ldr	q0, [x0, #32]
    691c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6920:	f9400c03 	ldr	x3, [x0, #24]
    6924:	3d8003e0 	str	q0, [sp]
    6928:	b86568c1 	ldr	w1, [x6, x5]
    692c:	f9401802 	ldr	x2, [x0, #48]
    6930:	a9010fe2 	stp	x2, x3, [sp, #16]
    6934:	f9401c02 	ldr	x2, [x0, #56]
    6938:	b900041f 	str	wzr, [x0, #4]
    693c:	f9402819 	ldr	x25, [x0, #80]
    6940:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6944:	f9000c1f 	str	xzr, [x0, #24]
    6948:	f90013e2 	str	x2, [sp, #32]
    694c:	f900181f 	str	xzr, [x0, #48]
    6950:	f9001c1f 	str	xzr, [x0, #56]
    6954:	f900281f 	str	xzr, [x0, #80]
    6958:	6b15003f 	cmp	w1, w21
    695c:	540000e8 	b.hi	6978 <fwp_tape_scope_release+0xe8>  // b.pmore
    6960:	9343fca5 	asr	x5, x5, #3
    6964:	f940aa60 	ldr	x0, [x19, #336]
    6968:	9b187ca5 	mul	x5, x5, x24
    696c:	eb0000bf 	cmp	x5, x0
    6970:	5400004a 	b.ge	6978 <fwp_tape_scope_release+0xe8>  // b.tcont
    6974:	f900aa65 	str	x5, [x19, #336]
    6978:	aa1703e0 	mov	x0, x23
    697c:	b5fffbd9 	cbnz	x25, 68f4 <fwp_tape_scope_release+0x64>
    6980:	97fff5f4 	bl	4150 <fwp_tape_buffers_release>
    6984:	b9400285 	ldr	w5, [x20]
    6988:	36fffc05 	tbz	w5, #31, 6908 <fwp_tape_scope_release+0x78>
    698c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    6990:	a94663f7 	ldp	x23, x24, [sp, #96]
    6994:	f9403bf9 	ldr	x25, [sp, #112]
    6998:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    699c:	f947f400 	ldr	x0, [x0, #4072]
    69a0:	f94017e2 	ldr	x2, [sp, #40]
    69a4:	f9400001 	ldr	x1, [x0]
    69a8:	eb010042 	subs	x2, x2, x1
    69ac:	d2800001 	mov	x1, #0x0                   	// #0
    69b0:	540000a1 	b.ne	69c4 <fwp_tape_scope_release+0x134>  // b.any
    69b4:	a9437bfd 	ldp	x29, x30, [sp, #48]
    69b8:	a94453f3 	ldp	x19, x20, [sp, #64]
    69bc:	910203ff 	add	sp, sp, #0x80
    69c0:	d65f03c0 	ret
    69c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    69c8:	a90663f7 	stp	x23, x24, [sp, #96]
    69cc:	f9003bf9 	str	x25, [sp, #112]
    69d0:	97ffefa4 	bl	2860 <__stack_chk_fail@plt>

00000000000069d4 <fwp_drop4>:
    69d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69d8:	910003fd 	mov	x29, sp
    69dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    69e0:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    69e4:	911882d5 	add	x21, x22, #0x620
    69e8:	a90153f3 	stp	x19, x20, [sp, #16]
    69ec:	aa0003f3 	mov	x19, x0
    69f0:	f949daa1 	ldr	x1, [x21, #5040]
    69f4:	f949eea0 	ldr	x0, [x21, #5080]
    69f8:	cb010261 	sub	x1, x19, x1
    69fc:	eb00403f 	cmp	x1, x0, lsl #16
    6a00:	54000382 	b.cs	6a70 <fwp_drop4+0x9c>  // b.hs, b.nlast
    6a04:	d350fc22 	lsr	x2, x1, #16
    6a08:	f949fea3 	ldr	x3, [x21, #5112]
    6a0c:	8b020842 	add	x2, x2, x2, lsl #2
    6a10:	d37df042 	lsl	x2, x2, #3
    6a14:	8b020060 	add	x0, x3, x2
    6a18:	f9401014 	ldr	x20, [x0, #32]
    6a1c:	b40002b4 	cbz	x20, 6a70 <fwp_drop4+0x9c>
    6a20:	38626862 	ldrb	w2, [x3, x2]
    6a24:	7100085f 	cmp	w2, #0x2
    6a28:	540002c0 	b.eq	6a80 <fwp_drop4+0xac>  // b.none
    6a2c:	7100045f 	cmp	w2, #0x1
    6a30:	54000201 	b.ne	6a70 <fwp_drop4+0x9c>  // b.any
    6a34:	29430002 	ldp	w2, w0, [x0, #24]
    6a38:	92403c21 	and	x1, x1, #0xffff
    6a3c:	9b027c21 	mul	x1, x1, x2
    6a40:	d360fc21 	lsr	x1, x1, #32
    6a44:	eb00003f 	cmp	x1, x0
    6a48:	54000142 	b.cs	6a70 <fwp_drop4+0x9c>  // b.hs, b.nlast
    6a4c:	8b010294 	add	x20, x20, x1
    6a50:	39400280 	ldrb	w0, [x20]
    6a54:	340000e0 	cbz	w0, 6a70 <fwp_drop4+0x9c>
    6a58:	7100041f 	cmp	w0, #0x1
    6a5c:	540001e0 	b.eq	6a98 <fwp_drop4+0xc4>  // b.none
    6a60:	7103fc1f 	cmp	w0, #0xff
    6a64:	540007e0 	b.eq	6b60 <fwp_drop4+0x18c>  // b.none
    6a68:	51000400 	sub	w0, w0, #0x1
    6a6c:	39000280 	strb	w0, [x20]
    6a70:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a74:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6a78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a7c:	d65f03c0 	ret
    6a80:	72003c3f 	tst	w1, #0xffff
    6a84:	54fffe60 	b.eq	6a50 <fwp_drop4+0x7c>  // b.none
    6a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6a90:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a94:	d65f03c0 	ret
    6a98:	911882c2 	add	x2, x22, #0x620
    6a9c:	f9400660 	ldr	x0, [x19, #8]
    6aa0:	f949d841 	ldr	x1, [x2, #5040]
    6aa4:	f949ec42 	ldr	x2, [x2, #5080]
    6aa8:	cb010001 	sub	x1, x0, x1
    6aac:	eb02403f 	cmp	x1, x2, lsl #16
    6ab0:	54000382 	b.cs	6b20 <fwp_drop4+0x14c>  // b.hs, b.nlast
    6ab4:	d350fc22 	lsr	x2, x1, #16
    6ab8:	8b020842 	add	x2, x2, x2, lsl #2
    6abc:	d37df042 	lsl	x2, x2, #3
    6ac0:	8b020064 	add	x4, x3, x2
    6ac4:	f9401094 	ldr	x20, [x4, #32]
    6ac8:	b40002d4 	cbz	x20, 6b20 <fwp_drop4+0x14c>
    6acc:	38626862 	ldrb	w2, [x3, x2]
    6ad0:	7100085f 	cmp	w2, #0x2
    6ad4:	54000400 	b.eq	6b54 <fwp_drop4+0x180>  // b.none
    6ad8:	7100045f 	cmp	w2, #0x1
    6adc:	54000221 	b.ne	6b20 <fwp_drop4+0x14c>  // b.any
    6ae0:	29430883 	ldp	w3, w2, [x4, #24]
    6ae4:	92403c21 	and	x1, x1, #0xffff
    6ae8:	9b037c21 	mul	x1, x1, x3
    6aec:	d360fc21 	lsr	x1, x1, #32
    6af0:	eb02003f 	cmp	x1, x2
    6af4:	54000162 	b.cs	6b20 <fwp_drop4+0x14c>  // b.hs, b.nlast
    6af8:	8b010294 	add	x20, x20, x1
    6afc:	39400281 	ldrb	w1, [x20]
    6b00:	34000101 	cbz	w1, 6b20 <fwp_drop4+0x14c>
    6b04:	7100043f 	cmp	w1, #0x1
    6b08:	54000220 	b.eq	6b4c <fwp_drop4+0x178>  // b.none
    6b0c:	7103fc3f 	cmp	w1, #0xff
    6b10:	54000660 	b.eq	6bdc <fwp_drop4+0x208>  // b.none
    6b14:	51000421 	sub	w1, w1, #0x1
    6b18:	39000281 	strb	w1, [x20]
    6b1c:	d503201f 	nop
    6b20:	f9400a74 	ldr	x20, [x19, #16]
    6b24:	aa1303e0 	mov	x0, x19
    6b28:	97fffcda 	bl	5e90 <fwp_rc_free_arr>
    6b2c:	911882c0 	add	x0, x22, #0x620
    6b30:	f949d801 	ldr	x1, [x0, #5040]
    6b34:	f949ec00 	ldr	x0, [x0, #5080]
    6b38:	cb010281 	sub	x1, x20, x1
    6b3c:	eb00403f 	cmp	x1, x0, lsl #16
    6b40:	54fff982 	b.cs	6a70 <fwp_drop4+0x9c>  // b.hs, b.nlast
    6b44:	aa1403f3 	mov	x19, x20
    6b48:	17ffffaf 	b	6a04 <fwp_drop4+0x30>
    6b4c:	97fffcd1 	bl	5e90 <fwp_rc_free_arr>
    6b50:	17fffff4 	b	6b20 <fwp_drop4+0x14c>
    6b54:	72003c3f 	tst	w1, #0xffff
    6b58:	54fffe41 	b.ne	6b20 <fwp_drop4+0x14c>  // b.any
    6b5c:	17ffffe8 	b	6afc <fwp_drop4+0x128>
    6b60:	ca544681 	eor	x1, x20, x20, lsr #17
    6b64:	911882c0 	add	x0, x22, #0x620
    6b68:	ca412421 	eor	x1, x1, x1, lsr #9
    6b6c:	92401c21 	and	x1, x1, #0xff
    6b70:	910a2422 	add	x2, x1, #0x289
    6b74:	8b010c01 	add	x1, x0, x1, lsl #3
    6b78:	8b020c02 	add	x2, x0, x2, lsl #3
    6b7c:	f94a2420 	ldr	x0, [x1, #5192]
    6b80:	b50000a0 	cbnz	x0, 6b94 <fwp_drop4+0x1c0>
    6b84:	14000013 	b	6bd0 <fwp_drop4+0x1fc>
    6b88:	91004002 	add	x2, x0, #0x10
    6b8c:	f9400800 	ldr	x0, [x0, #16]
    6b90:	b4000200 	cbz	x0, 6bd0 <fwp_drop4+0x1fc>
    6b94:	f9400001 	ldr	x1, [x0]
    6b98:	eb14003f 	cmp	x1, x20
    6b9c:	54ffff61 	b.ne	6b88 <fwp_drop4+0x1b4>  // b.any
    6ba0:	f9400041 	ldr	x1, [x2]
    6ba4:	f9400420 	ldr	x0, [x1, #8]
    6ba8:	d1000400 	sub	x0, x0, #0x1
    6bac:	f9000420 	str	x0, [x1, #8]
    6bb0:	f103f81f 	cmp	x0, #0xfe
    6bb4:	54fff5e1 	b.ne	6a70 <fwp_drop4+0x9c>  // b.any
    6bb8:	39400280 	ldrb	w0, [x20]
    6bbc:	7103fc1f 	cmp	w0, #0xff
    6bc0:	54000460 	b.eq	6c4c <fwp_drop4+0x278>  // b.none
    6bc4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6bc8:	39000280 	strb	w0, [x20]
    6bcc:	17ffffa9 	b	6a70 <fwp_drop4+0x9c>
    6bd0:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    6bd4:	912f6000 	add	x0, x0, #0xbd8
    6bd8:	97fff5c3 	bl	42e4 <fwp_trap>
    6bdc:	ca544680 	eor	x0, x20, x20, lsr #17
    6be0:	911882c1 	add	x1, x22, #0x620
    6be4:	ca402400 	eor	x0, x0, x0, lsr #9
    6be8:	92401c00 	and	x0, x0, #0xff
    6bec:	910a2402 	add	x2, x0, #0x289
    6bf0:	8b000c20 	add	x0, x1, x0, lsl #3
    6bf4:	8b020c22 	add	x2, x1, x2, lsl #3
    6bf8:	f94a2400 	ldr	x0, [x0, #5192]
    6bfc:	b50000a0 	cbnz	x0, 6c10 <fwp_drop4+0x23c>
    6c00:	17fffff4 	b	6bd0 <fwp_drop4+0x1fc>
    6c04:	91004002 	add	x2, x0, #0x10
    6c08:	f9400800 	ldr	x0, [x0, #16]
    6c0c:	b4fffe20 	cbz	x0, 6bd0 <fwp_drop4+0x1fc>
    6c10:	f9400001 	ldr	x1, [x0]
    6c14:	eb14003f 	cmp	x1, x20
    6c18:	54ffff61 	b.ne	6c04 <fwp_drop4+0x230>  // b.any
    6c1c:	f9400041 	ldr	x1, [x2]
    6c20:	f9400420 	ldr	x0, [x1, #8]
    6c24:	d1000400 	sub	x0, x0, #0x1
    6c28:	f9000420 	str	x0, [x1, #8]
    6c2c:	f103f81f 	cmp	x0, #0xfe
    6c30:	54fff781 	b.ne	6b20 <fwp_drop4+0x14c>  // b.any
    6c34:	39400280 	ldrb	w0, [x20]
    6c38:	7103fc1f 	cmp	w0, #0xff
    6c3c:	540000e0 	b.eq	6c58 <fwp_drop4+0x284>  // b.none
    6c40:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c44:	39000280 	strb	w0, [x20]
    6c48:	17ffffb6 	b	6b20 <fwp_drop4+0x14c>
    6c4c:	aa1403e0 	mov	x0, x20
    6c50:	97fff5c5 	bl	4364 <fwp_rc_forget_slot.part.0>
    6c54:	17ffffdc 	b	6bc4 <fwp_drop4+0x1f0>
    6c58:	aa1403e0 	mov	x0, x20
    6c5c:	97fff5c2 	bl	4364 <fwp_rc_forget_slot.part.0>
    6c60:	17fffff8 	b	6c40 <fwp_drop4+0x26c>

0000000000006c64 <fwp_arg_drop37>:
    6c64:	7100003f 	cmp	w1, #0x0
    6c68:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6c6c:	54000041 	b.ne	6c74 <fwp_arg_drop37+0x10>  // b.any
    6c70:	d65f03c0 	ret
    6c74:	f9400000 	ldr	x0, [x0]
    6c78:	17ffff57 	b	69d4 <fwp_drop4>
    6c7c:	d503201f 	nop

0000000000006c80 <fwp_task_dispose>:
    6c80:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c84:	910003fd 	mov	x29, sp
    6c88:	f9000bf3 	str	x19, [sp, #16]
    6c8c:	aa0003f3 	mov	x19, x0
    6c90:	39414000 	ldrb	w0, [x0, #80]
    6c94:	36000720 	tbz	w0, #0, 6d78 <fwp_task_dispose+0xf8>
    6c98:	f9400a60 	ldr	x0, [x19, #16]
    6c9c:	b50006e0 	cbnz	x0, 6d78 <fwp_task_dispose+0xf8>
    6ca0:	a9478660 	ldp	x0, x1, [x19, #120]
    6ca4:	39014e7f 	strb	wzr, [x19, #83]
    6ca8:	f9003e7f 	str	xzr, [x19, #120]
    6cac:	f100003f 	cmp	x1, #0x0
    6cb0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6cb4:	54000040 	b.eq	6cbc <fwp_task_dispose+0x3c>  // b.none
    6cb8:	d63f0020 	blr	x1
    6cbc:	f9405660 	ldr	x0, [x19, #168]
    6cc0:	97fff644 	bl	45d0 <fwp_mem_free>
    6cc4:	f900567f 	str	xzr, [x19, #168]
    6cc8:	b9405e60 	ldr	w0, [x19, #92]
    6ccc:	7100041f 	cmp	w0, #0x1
    6cd0:	54000420 	b.eq	6d54 <fwp_task_dispose+0xd4>  // b.none
    6cd4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    6cd8:	91188042 	add	x2, x2, #0x620
    6cdc:	f949d840 	ldr	x0, [x2, #5040]
    6ce0:	f949ec41 	ldr	x1, [x2, #5080]
    6ce4:	cb000260 	sub	x0, x19, x0
    6ce8:	eb01401f 	cmp	x0, x1, lsl #16
    6cec:	540002e2 	b.cs	6d48 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6cf0:	d350fc01 	lsr	x1, x0, #16
    6cf4:	f949fc44 	ldr	x4, [x2, #5112]
    6cf8:	8b010821 	add	x1, x1, x1, lsl #2
    6cfc:	d37df021 	lsl	x1, x1, #3
    6d00:	8b010083 	add	x3, x4, x1
    6d04:	f9401062 	ldr	x2, [x3, #32]
    6d08:	b4000202 	cbz	x2, 6d48 <fwp_task_dispose+0xc8>
    6d0c:	38616881 	ldrb	w1, [x4, x1]
    6d10:	7100083f 	cmp	w1, #0x2
    6d14:	54000280 	b.eq	6d64 <fwp_task_dispose+0xe4>  // b.none
    6d18:	7100043f 	cmp	w1, #0x1
    6d1c:	54000161 	b.ne	6d48 <fwp_task_dispose+0xc8>  // b.any
    6d20:	29430464 	ldp	w4, w1, [x3, #24]
    6d24:	92403c00 	and	x0, x0, #0xffff
    6d28:	9b047c00 	mul	x0, x0, x4
    6d2c:	d360fc00 	lsr	x0, x0, #32
    6d30:	eb01001f 	cmp	x0, x1
    6d34:	540000a2 	b.cs	6d48 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6d38:	8b000042 	add	x2, x2, x0
    6d3c:	39400040 	ldrb	w0, [x2]
    6d40:	7100041f 	cmp	w0, #0x1
    6d44:	54000080 	b.eq	6d54 <fwp_task_dispose+0xd4>  // b.none
    6d48:	f9400bf3 	ldr	x19, [sp, #16]
    6d4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d50:	d65f03c0 	ret
    6d54:	aa1303e0 	mov	x0, x19
    6d58:	f9400bf3 	ldr	x19, [sp, #16]
    6d5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d60:	17fff61c 	b	45d0 <fwp_mem_free>
    6d64:	72003c1f 	tst	w0, #0xffff
    6d68:	54fffea0 	b.eq	6d3c <fwp_task_dispose+0xbc>  // b.none
    6d6c:	f9400bf3 	ldr	x19, [sp, #16]
    6d70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d74:	d65f03c0 	ret
    6d78:	97ffeece 	bl	28b0 <abort@plt>
    6d7c:	d503201f 	nop

0000000000006d80 <fwp_free_zombie>:
    6d80:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6d84:	910003fd 	mov	x29, sp
    6d88:	a90153f3 	stp	x19, x20, [sp, #16]
    6d8c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6d90:	91014281 	add	x1, x20, #0x50
    6d94:	f940ac33 	ldr	x19, [x1, #344]
    6d98:	b4000333 	cbz	x19, 6dfc <fwp_free_zombie+0x7c>
    6d9c:	f9404c20 	ldr	x0, [x1, #152]
    6da0:	eb00027f 	cmp	x19, x0
    6da4:	540002c0 	b.eq	6dfc <fwp_free_zombie+0x7c>  // b.none
    6da8:	b9416022 	ldr	w2, [x1, #352]
    6dac:	f9400a60 	ldr	x0, [x19, #16]
    6db0:	7100fc5f 	cmp	w2, #0x3f
    6db4:	5400078c 	b.gt	6ea4 <fwp_free_zombie+0x124>
    6db8:	9105c023 	add	x3, x1, #0x170
    6dbc:	11000444 	add	w4, w2, #0x1
    6dc0:	b9016024 	str	w4, [x1, #352]
    6dc4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6dc8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6dcc:	a9530261 	ldp	x1, x0, [x19, #304]
    6dd0:	b4000741 	cbz	x1, 6eb8 <fwp_free_zombie+0x138>
    6dd4:	f9009c20 	str	x0, [x1, #312]
    6dd8:	b4000040 	cbz	x0, 6de0 <fwp_free_zombie+0x60>
    6ddc:	f9009801 	str	x1, [x0, #304]
    6de0:	91014294 	add	x20, x20, #0x50
    6de4:	b9405e60 	ldr	w0, [x19, #92]
    6de8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6dec:	f900ae9f 	str	xzr, [x20, #344]
    6df0:	34000140 	cbz	w0, 6e18 <fwp_free_zombie+0x98>
    6df4:	7100041f 	cmp	w0, #0x1
    6df8:	54000080 	b.eq	6e08 <fwp_free_zombie+0x88>  // b.none
    6dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e04:	d65f03c0 	ret
    6e08:	aa1303e0 	mov	x0, x19
    6e0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e14:	17ffff9b 	b	6c80 <fwp_task_dispose>
    6e18:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbc0>
    6e1c:	91188082 	add	x2, x4, #0x620
    6e20:	f949d841 	ldr	x1, [x2, #5040]
    6e24:	f949ec40 	ldr	x0, [x2, #5080]
    6e28:	cb010261 	sub	x1, x19, x1
    6e2c:	eb00403f 	cmp	x1, x0, lsl #16
    6e30:	54fffe62 	b.cs	6dfc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6e34:	d350fc20 	lsr	x0, x1, #16
    6e38:	f949fc43 	ldr	x3, [x2, #5112]
    6e3c:	8b000800 	add	x0, x0, x0, lsl #2
    6e40:	d37df000 	lsl	x0, x0, #3
    6e44:	8b000062 	add	x2, x3, x0
    6e48:	f9401054 	ldr	x20, [x2, #32]
    6e4c:	b4fffd94 	cbz	x20, 6dfc <fwp_free_zombie+0x7c>
    6e50:	38606860 	ldrb	w0, [x3, x0]
    6e54:	7100081f 	cmp	w0, #0x2
    6e58:	54000360 	b.eq	6ec4 <fwp_free_zombie+0x144>  // b.none
    6e5c:	7100041f 	cmp	w0, #0x1
    6e60:	54fffce1 	b.ne	6dfc <fwp_free_zombie+0x7c>  // b.any
    6e64:	29430043 	ldp	w3, w0, [x2, #24]
    6e68:	92403c21 	and	x1, x1, #0xffff
    6e6c:	9b037c21 	mul	x1, x1, x3
    6e70:	d360fc21 	lsr	x1, x1, #32
    6e74:	eb00003f 	cmp	x1, x0
    6e78:	54fffc22 	b.cs	6dfc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6e7c:	8b010294 	add	x20, x20, x1
    6e80:	39400280 	ldrb	w0, [x20]
    6e84:	34fffbc0 	cbz	w0, 6dfc <fwp_free_zombie+0x7c>
    6e88:	7100041f 	cmp	w0, #0x1
    6e8c:	54fffbe0 	b.eq	6e08 <fwp_free_zombie+0x88>  // b.none
    6e90:	7103fc1f 	cmp	w0, #0xff
    6e94:	540001e0 	b.eq	6ed0 <fwp_free_zombie+0x150>  // b.none
    6e98:	51000400 	sub	w0, w0, #0x1
    6e9c:	39000280 	strb	w0, [x20]
    6ea0:	17ffffd7 	b	6dfc <fwp_free_zombie+0x7c>
    6ea4:	f9400e61 	ldr	x1, [x19, #24]
    6ea8:	97ffeeb6 	bl	2980 <munmap@plt>
    6eac:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6eb0:	a9530261 	ldp	x1, x0, [x19, #304]
    6eb4:	b5fff901 	cbnz	x1, 6dd4 <fwp_free_zombie+0x54>
    6eb8:	91014282 	add	x2, x20, #0x50
    6ebc:	f901b840 	str	x0, [x2, #880]
    6ec0:	17ffffc6 	b	6dd8 <fwp_free_zombie+0x58>
    6ec4:	72003c3f 	tst	w1, #0xffff
    6ec8:	54fff9a1 	b.ne	6dfc <fwp_free_zombie+0x7c>  // b.any
    6ecc:	17ffffed 	b	6e80 <fwp_free_zombie+0x100>
    6ed0:	ca544680 	eor	x0, x20, x20, lsr #17
    6ed4:	91188084 	add	x4, x4, #0x620
    6ed8:	ca402400 	eor	x0, x0, x0, lsr #9
    6edc:	92401c00 	and	x0, x0, #0xff
    6ee0:	910a2402 	add	x2, x0, #0x289
    6ee4:	8b000c80 	add	x0, x4, x0, lsl #3
    6ee8:	8b020c82 	add	x2, x4, x2, lsl #3
    6eec:	f94a2400 	ldr	x0, [x0, #5192]
    6ef0:	b50000a0 	cbnz	x0, 6f04 <fwp_free_zombie+0x184>
    6ef4:	14000013 	b	6f40 <fwp_free_zombie+0x1c0>
    6ef8:	91004002 	add	x2, x0, #0x10
    6efc:	f9400800 	ldr	x0, [x0, #16]
    6f00:	b4000200 	cbz	x0, 6f40 <fwp_free_zombie+0x1c0>
    6f04:	f9400001 	ldr	x1, [x0]
    6f08:	eb14003f 	cmp	x1, x20
    6f0c:	54ffff61 	b.ne	6ef8 <fwp_free_zombie+0x178>  // b.any
    6f10:	f9400041 	ldr	x1, [x2]
    6f14:	f9400420 	ldr	x0, [x1, #8]
    6f18:	d1000400 	sub	x0, x0, #0x1
    6f1c:	f9000420 	str	x0, [x1, #8]
    6f20:	f103f81f 	cmp	x0, #0xfe
    6f24:	54fff6c1 	b.ne	6dfc <fwp_free_zombie+0x7c>  // b.any
    6f28:	39400280 	ldrb	w0, [x20]
    6f2c:	7103fc1f 	cmp	w0, #0xff
    6f30:	540000e0 	b.eq	6f4c <fwp_free_zombie+0x1cc>  // b.none
    6f34:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6f38:	39000280 	strb	w0, [x20]
    6f3c:	17ffffb0 	b	6dfc <fwp_free_zombie+0x7c>
    6f40:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    6f44:	912f6000 	add	x0, x0, #0xbd8
    6f48:	97fff4e7 	bl	42e4 <fwp_trap>
    6f4c:	aa1403e0 	mov	x0, x20
    6f50:	97fff505 	bl	4364 <fwp_rc_forget_slot.part.0>
    6f54:	17fffff8 	b	6f34 <fwp_free_zombie+0x1b4>
    6f58:	d503201f 	nop
    6f5c:	d503201f 	nop

0000000000006f60 <fwp_block>:
    6f60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6f64:	910003fd 	mov	x29, sp
    6f68:	a90153f3 	stp	x19, x20, [sp, #16]
    6f6c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6f70:	91014274 	add	x20, x19, #0x50
    6f74:	f9406682 	ldr	x2, [x20, #200]
    6f78:	b4000642 	cbz	x2, 7040 <fwp_block+0xe0>
    6f7c:	91014261 	add	x1, x19, #0x50
    6f80:	f9408040 	ldr	x0, [x2, #256]
    6f84:	f9006420 	str	x0, [x1, #200]
    6f88:	b40006a0 	cbz	x0, 705c <fwp_block+0xfc>
    6f8c:	d503201f 	nop
    6f90:	91014263 	add	x3, x19, #0x50
    6f94:	3901505f 	strb	wzr, [x2, #84]
    6f98:	f9404c64 	ldr	x4, [x3, #152]
    6f9c:	eb02009f 	cmp	x4, x2
    6fa0:	54000440 	b.eq	7028 <fwp_block+0xc8>  // b.none
    6fa4:	f941bc65 	ldr	x5, [x3, #888]
    6fa8:	f9004c62 	str	x2, [x3, #152]
    6fac:	f9400441 	ldr	x1, [x2, #8]
    6fb0:	f9004885 	str	x5, [x4, #144]
    6fb4:	f941c065 	ldr	x5, [x3, #896]
    6fb8:	f9004c85 	str	x5, [x4, #152]
    6fbc:	f941c465 	ldr	x5, [x3, #904]
    6fc0:	f9005085 	str	x5, [x4, #160]
    6fc4:	f941c865 	ldr	x5, [x3, #912]
    6fc8:	f9005485 	str	x5, [x4, #168]
    6fcc:	f941cc65 	ldr	x5, [x3, #920]
    6fd0:	f9005885 	str	x5, [x4, #176]
    6fd4:	f941d065 	ldr	x5, [x3, #928]
    6fd8:	f9005c85 	str	x5, [x4, #184]
    6fdc:	f941d465 	ldr	x5, [x3, #936]
    6fe0:	f9006085 	str	x5, [x4, #192]
    6fe4:	f9400480 	ldr	x0, [x4, #8]
    6fe8:	f9404844 	ldr	x4, [x2, #144]
    6fec:	f901bc64 	str	x4, [x3, #888]
    6ff0:	f9404c44 	ldr	x4, [x2, #152]
    6ff4:	f901c064 	str	x4, [x3, #896]
    6ff8:	f9405044 	ldr	x4, [x2, #160]
    6ffc:	f901c464 	str	x4, [x3, #904]
    7000:	f9405444 	ldr	x4, [x2, #168]
    7004:	f901c864 	str	x4, [x3, #912]
    7008:	f9405844 	ldr	x4, [x2, #176]
    700c:	f901cc64 	str	x4, [x3, #920]
    7010:	a94b8844 	ldp	x4, x2, [x2, #184]
    7014:	f901d064 	str	x4, [x3, #928]
    7018:	f901d462 	str	x2, [x3, #936]
    701c:	97ffee29 	bl	28c0 <swapcontext@plt>
    7020:	97ffff58 	bl	6d80 <fwp_free_zombie>
    7024:	d503201f 	nop
    7028:	91014260 	add	x0, x19, #0x50
    702c:	b943b000 	ldr	w0, [x0, #944]
    7030:	340001a0 	cbz	w0, 7064 <fwp_block+0x104>
    7034:	a94153f3 	ldp	x19, x20, [sp, #16]
    7038:	a8c27bfd 	ldp	x29, x30, [sp], #32
    703c:	d65f03c0 	ret
    7040:	97fff6f0 	bl	4c00 <fwp_poll_events>
    7044:	f9406682 	ldr	x2, [x20, #200]
    7048:	b4ffffc2 	cbz	x2, 7040 <fwp_block+0xe0>
    704c:	91014261 	add	x1, x19, #0x50
    7050:	f9408040 	ldr	x0, [x2, #256]
    7054:	f9006420 	str	x0, [x1, #200]
    7058:	b5fff9c0 	cbnz	x0, 6f90 <fwp_block+0x30>
    705c:	f900603f 	str	xzr, [x1, #192]
    7060:	17ffffcc 	b	6f90 <fwp_block+0x30>
    7064:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    7068:	9139c000 	add	x0, x0, #0xe70
    706c:	97ffee61 	bl	29f0 <getenv@plt>
    7070:	5284e202 	mov	w2, #0x2710                	// #10000
    7074:	b4000060 	cbz	x0, 7080 <fwp_block+0x120>
    7078:	39400001 	ldrb	w1, [x0]
    707c:	350000c1 	cbnz	w1, 7094 <fwp_block+0x134>
    7080:	91014273 	add	x19, x19, #0x50
    7084:	b903b262 	str	w2, [x19, #944]
    7088:	a94153f3 	ldp	x19, x20, [sp, #16]
    708c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7090:	d65f03c0 	ret
    7094:	52800142 	mov	w2, #0xa                   	// #10
    7098:	d2800001 	mov	x1, #0x0                   	// #0
    709c:	97ffeda5 	bl	2730 <strtoll@plt>
    70a0:	d1000403 	sub	x3, x0, #0x1
    70a4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    70a8:	eb02007f 	cmp	x3, x2
    70ac:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    70b0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    70b4:	17fffff3 	b	7080 <fwp_block+0x120>
    70b8:	d503201f 	nop
    70bc:	d503201f 	nop

00000000000070c0 <fwp_drop10>:
    70c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    70c4:	910003fd 	mov	x29, sp
    70c8:	a90153f3 	stp	x19, x20, [sp, #16]
    70cc:	d0000393 	adrp	x19, 79000 <fwp_root_context+0xbc0>
    70d0:	f90013f5 	str	x21, [sp, #32]
    70d4:	91188275 	add	x21, x19, #0x620
    70d8:	f949daa1 	ldr	x1, [x21, #5040]
    70dc:	f949eea2 	ldr	x2, [x21, #5080]
    70e0:	cb010001 	sub	x1, x0, x1
    70e4:	eb02403f 	cmp	x1, x2, lsl #16
    70e8:	54000382 	b.cs	7158 <fwp_drop10+0x98>  // b.hs, b.nlast
    70ec:	d350fc22 	lsr	x2, x1, #16
    70f0:	f949fea3 	ldr	x3, [x21, #5112]
    70f4:	8b020842 	add	x2, x2, x2, lsl #2
    70f8:	d37df042 	lsl	x2, x2, #3
    70fc:	8b020064 	add	x4, x3, x2
    7100:	f9401094 	ldr	x20, [x4, #32]
    7104:	b40002b4 	cbz	x20, 7158 <fwp_drop10+0x98>
    7108:	38626862 	ldrb	w2, [x3, x2]
    710c:	7100085f 	cmp	w2, #0x2
    7110:	540007a0 	b.eq	7204 <fwp_drop10+0x144>  // b.none
    7114:	7100045f 	cmp	w2, #0x1
    7118:	54000201 	b.ne	7158 <fwp_drop10+0x98>  // b.any
    711c:	29430885 	ldp	w5, w2, [x4, #24]
    7120:	92403c21 	and	x1, x1, #0xffff
    7124:	9b057c21 	mul	x1, x1, x5
    7128:	d360fc21 	lsr	x1, x1, #32
    712c:	eb02003f 	cmp	x1, x2
    7130:	54000142 	b.cs	7158 <fwp_drop10+0x98>  // b.hs, b.nlast
    7134:	8b010294 	add	x20, x20, x1
    7138:	39400281 	ldrb	w1, [x20]
    713c:	340000e1 	cbz	w1, 7158 <fwp_drop10+0x98>
    7140:	7100043f 	cmp	w1, #0x1
    7144:	54000120 	b.eq	7168 <fwp_drop10+0xa8>  // b.none
    7148:	7103fc3f 	cmp	w1, #0xff
    714c:	540007c0 	b.eq	7244 <fwp_drop10+0x184>  // b.none
    7150:	51000421 	sub	w1, w1, #0x1
    7154:	39000281 	strb	w1, [x20]
    7158:	a94153f3 	ldp	x19, x20, [sp, #16]
    715c:	f94013f5 	ldr	x21, [sp, #32]
    7160:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7164:	d65f03c0 	ret
    7168:	f9400001 	ldr	x1, [x0]
    716c:	b7f80581 	tbnz	x1, #63, 721c <fwp_drop10+0x15c>
    7170:	91188273 	add	x19, x19, #0x620
    7174:	f949da61 	ldr	x1, [x19, #5040]
    7178:	f949ee62 	ldr	x2, [x19, #5080]
    717c:	cb010001 	sub	x1, x0, x1
    7180:	eb02403f 	cmp	x1, x2, lsl #16
    7184:	54fffea2 	b.cs	7158 <fwp_drop10+0x98>  // b.hs, b.nlast
    7188:	d350fc22 	lsr	x2, x1, #16
    718c:	8b020842 	add	x2, x2, x2, lsl #2
    7190:	d37df042 	lsl	x2, x2, #3
    7194:	8b020065 	add	x5, x3, x2
    7198:	f94010a4 	ldr	x4, [x5, #32]
    719c:	b4fffde4 	cbz	x4, 7158 <fwp_drop10+0x98>
    71a0:	38626862 	ldrb	w2, [x3, x2]
    71a4:	7100085f 	cmp	w2, #0x2
    71a8:	54000220 	b.eq	71ec <fwp_drop10+0x12c>  // b.none
    71ac:	7100045f 	cmp	w2, #0x1
    71b0:	54fffd41 	b.ne	7158 <fwp_drop10+0x98>  // b.any
    71b4:	294308a3 	ldp	w3, w2, [x5, #24]
    71b8:	92403c21 	and	x1, x1, #0xffff
    71bc:	9b037c21 	mul	x1, x1, x3
    71c0:	d360fc21 	lsr	x1, x1, #32
    71c4:	eb02003f 	cmp	x1, x2
    71c8:	54fffc82 	b.cs	7158 <fwp_drop10+0x98>  // b.hs, b.nlast
    71cc:	8b010084 	add	x4, x4, x1
    71d0:	39400081 	ldrb	w1, [x4]
    71d4:	7100043f 	cmp	w1, #0x1
    71d8:	54fffc01 	b.ne	7158 <fwp_drop10+0x98>  // b.any
    71dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    71e0:	f94013f5 	ldr	x21, [sp, #32]
    71e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    71e8:	17fff4fa 	b	45d0 <fwp_mem_free>
    71ec:	72003c3f 	tst	w1, #0xffff
    71f0:	54ffff00 	b.eq	71d0 <fwp_drop10+0x110>  // b.none
    71f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    71f8:	f94013f5 	ldr	x21, [sp, #32]
    71fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7200:	d65f03c0 	ret
    7204:	72003c3f 	tst	w1, #0xffff
    7208:	54fff980 	b.eq	7138 <fwp_drop10+0x78>  // b.none
    720c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7210:	f94013f5 	ldr	x21, [sp, #32]
    7214:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7218:	d65f03c0 	ret
    721c:	f9400414 	ldr	x20, [x0, #8]
    7220:	97fffb1c 	bl	5e90 <fwp_rc_free_arr>
    7224:	91188260 	add	x0, x19, #0x620
    7228:	f949d801 	ldr	x1, [x0, #5040]
    722c:	f949ec00 	ldr	x0, [x0, #5080]
    7230:	cb010281 	sub	x1, x20, x1
    7234:	eb00403f 	cmp	x1, x0, lsl #16
    7238:	54fff902 	b.cs	7158 <fwp_drop10+0x98>  // b.hs, b.nlast
    723c:	aa1403e0 	mov	x0, x20
    7240:	17ffffab 	b	70ec <fwp_drop10+0x2c>
    7244:	ca544680 	eor	x0, x20, x20, lsr #17
    7248:	91188273 	add	x19, x19, #0x620
    724c:	ca402400 	eor	x0, x0, x0, lsr #9
    7250:	92401c00 	and	x0, x0, #0xff
    7254:	910a2402 	add	x2, x0, #0x289
    7258:	8b000e60 	add	x0, x19, x0, lsl #3
    725c:	8b020e62 	add	x2, x19, x2, lsl #3
    7260:	f94a2400 	ldr	x0, [x0, #5192]
    7264:	b50000a0 	cbnz	x0, 7278 <fwp_drop10+0x1b8>
    7268:	14000013 	b	72b4 <fwp_drop10+0x1f4>
    726c:	91004002 	add	x2, x0, #0x10
    7270:	f9400800 	ldr	x0, [x0, #16]
    7274:	b4000200 	cbz	x0, 72b4 <fwp_drop10+0x1f4>
    7278:	f9400001 	ldr	x1, [x0]
    727c:	eb14003f 	cmp	x1, x20
    7280:	54ffff61 	b.ne	726c <fwp_drop10+0x1ac>  // b.any
    7284:	f9400041 	ldr	x1, [x2]
    7288:	f9400420 	ldr	x0, [x1, #8]
    728c:	d1000400 	sub	x0, x0, #0x1
    7290:	f9000420 	str	x0, [x1, #8]
    7294:	f103f81f 	cmp	x0, #0xfe
    7298:	54fff601 	b.ne	7158 <fwp_drop10+0x98>  // b.any
    729c:	39400280 	ldrb	w0, [x20]
    72a0:	7103fc1f 	cmp	w0, #0xff
    72a4:	540000e0 	b.eq	72c0 <fwp_drop10+0x200>  // b.none
    72a8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    72ac:	39000280 	strb	w0, [x20]
    72b0:	17ffffaa 	b	7158 <fwp_drop10+0x98>
    72b4:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    72b8:	912f6000 	add	x0, x0, #0xbd8
    72bc:	97fff40a 	bl	42e4 <fwp_trap>
    72c0:	aa1403e0 	mov	x0, x20
    72c4:	97fff428 	bl	4364 <fwp_rc_forget_slot.part.0>
    72c8:	17fffff8 	b	72a8 <fwp_drop10+0x1e8>
    72cc:	d503201f 	nop

00000000000072d0 <fwp_caps173>:
    72d0:	34000041 	cbz	w1, 72d8 <fwp_caps173+0x8>
    72d4:	d65f03c0 	ret
    72d8:	d0000383 	adrp	x3, 79000 <fwp_root_context+0xbc0>
    72dc:	91188063 	add	x3, x3, #0x620
    72e0:	f949d861 	ldr	x1, [x3, #5040]
    72e4:	f949ec62 	ldr	x2, [x3, #5080]
    72e8:	cb010001 	sub	x1, x0, x1
    72ec:	eb02403f 	cmp	x1, x2, lsl #16
    72f0:	54ffff22 	b.cs	72d4 <fwp_caps173+0x4>  // b.hs, b.nlast
    72f4:	d350fc22 	lsr	x2, x1, #16
    72f8:	f949fc65 	ldr	x5, [x3, #5112]
    72fc:	8b020842 	add	x2, x2, x2, lsl #2
    7300:	d37df042 	lsl	x2, x2, #3
    7304:	8b0200a4 	add	x4, x5, x2
    7308:	f9401083 	ldr	x3, [x4, #32]
    730c:	b4fffe43 	cbz	x3, 72d4 <fwp_caps173+0x4>
    7310:	386268a2 	ldrb	w2, [x5, x2]
    7314:	7100085f 	cmp	w2, #0x2
    7318:	540001c0 	b.eq	7350 <fwp_caps173+0x80>  // b.none
    731c:	7100045f 	cmp	w2, #0x1
    7320:	54fffda1 	b.ne	72d4 <fwp_caps173+0x4>  // b.any
    7324:	29430885 	ldp	w5, w2, [x4, #24]
    7328:	92403c21 	and	x1, x1, #0xffff
    732c:	9b057c21 	mul	x1, x1, x5
    7330:	d360fc21 	lsr	x1, x1, #32
    7334:	eb02003f 	cmp	x1, x2
    7338:	54fffce2 	b.cs	72d4 <fwp_caps173+0x4>  // b.hs, b.nlast
    733c:	8b010063 	add	x3, x3, x1
    7340:	39400061 	ldrb	w1, [x3]
    7344:	7100043f 	cmp	w1, #0x1
    7348:	54fffc61 	b.ne	72d4 <fwp_caps173+0x4>  // b.any
    734c:	17fff4a1 	b	45d0 <fwp_mem_free>
    7350:	72003c3f 	tst	w1, #0xffff
    7354:	54ffff60 	b.eq	7340 <fwp_caps173+0x70>  // b.none
    7358:	d65f03c0 	ret
    735c:	d503201f 	nop

0000000000007360 <fwp_args37>:
    7360:	7100003f 	cmp	w1, #0x0
    7364:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7368:	54000041 	b.ne	7370 <fwp_args37+0x10>  // b.any
    736c:	d65f03c0 	ret
    7370:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    7374:	91188042 	add	x2, x2, #0x620
    7378:	f9400001 	ldr	x1, [x0]
    737c:	f949d843 	ldr	x3, [x2, #5040]
    7380:	f949ec40 	ldr	x0, [x2, #5080]
    7384:	cb030021 	sub	x1, x1, x3
    7388:	eb00403f 	cmp	x1, x0, lsl #16
    738c:	54ffff02 	b.cs	736c <fwp_args37+0xc>  // b.hs, b.nlast
    7390:	d350fc20 	lsr	x0, x1, #16
    7394:	f949fc44 	ldr	x4, [x2, #5112]
    7398:	8b000800 	add	x0, x0, x0, lsl #2
    739c:	d37df002 	lsl	x2, x0, #3
    73a0:	8b020083 	add	x3, x4, x2
    73a4:	f9401060 	ldr	x0, [x3, #32]
    73a8:	b4fffe20 	cbz	x0, 736c <fwp_args37+0xc>
    73ac:	38626882 	ldrb	w2, [x4, x2]
    73b0:	7100085f 	cmp	w2, #0x2
    73b4:	54000320 	b.eq	7418 <fwp_args37+0xb8>  // b.none
    73b8:	7100045f 	cmp	w2, #0x1
    73bc:	54fffd81 	b.ne	736c <fwp_args37+0xc>  // b.any
    73c0:	29430864 	ldp	w4, w2, [x3, #24]
    73c4:	92403c21 	and	x1, x1, #0xffff
    73c8:	9b047c21 	mul	x1, x1, x4
    73cc:	d360fc21 	lsr	x1, x1, #32
    73d0:	eb02003f 	cmp	x1, x2
    73d4:	54fffcc2 	b.cs	736c <fwp_args37+0xc>  // b.hs, b.nlast
    73d8:	8b010000 	add	x0, x0, x1
    73dc:	39400001 	ldrb	w1, [x0]
    73e0:	34fffc61 	cbz	w1, 736c <fwp_args37+0xc>
    73e4:	b00000c2 	adrp	x2, 20000 <__data_start>
    73e8:	91014042 	add	x2, x2, #0x50
    73ec:	b9412043 	ldr	w3, [x2, #288]
    73f0:	350000c3 	cbnz	w3, 7408 <fwp_args37+0xa8>
    73f4:	7103f43f 	cmp	w1, #0xfd
    73f8:	54000168 	b.hi	7424 <fwp_args37+0xc4>  // b.pmore
    73fc:	11000421 	add	w1, w1, #0x1
    7400:	39000001 	strb	w1, [x0]
    7404:	d65f03c0 	ret
    7408:	f940a443 	ldr	x3, [x2, #328]
    740c:	91000463 	add	x3, x3, #0x1
    7410:	f900a443 	str	x3, [x2, #328]
    7414:	17fffff8 	b	73f4 <fwp_args37+0x94>
    7418:	72003c3f 	tst	w1, #0xffff
    741c:	54fffe00 	b.eq	73dc <fwp_args37+0x7c>  // b.none
    7420:	d65f03c0 	ret
    7424:	17fff4e4 	b	47b4 <fwp_rc_wide_dup>
    7428:	d503201f 	nop
    742c:	d503201f 	nop

0000000000007430 <fwp_caps37>:
    7430:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7434:	910003fd 	mov	x29, sp
    7438:	f9000bf3 	str	x19, [sp, #16]
    743c:	aa0003f3 	mov	x19, x0
    7440:	b9400400 	ldr	w0, [x0, #4]
    7444:	340004a0 	cbz	w0, 74d8 <fwp_caps37+0xa8>
    7448:	f9400660 	ldr	x0, [x19, #8]
    744c:	350004e1 	cbnz	w1, 74e8 <fwp_caps37+0xb8>
    7450:	97fffd61 	bl	69d4 <fwp_drop4>
    7454:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    7458:	91188042 	add	x2, x2, #0x620
    745c:	f949d840 	ldr	x0, [x2, #5040]
    7460:	f949ec41 	ldr	x1, [x2, #5080]
    7464:	cb000260 	sub	x0, x19, x0
    7468:	eb01401f 	cmp	x0, x1, lsl #16
    746c:	54000382 	b.cs	74dc <fwp_caps37+0xac>  // b.hs, b.nlast
    7470:	d350fc01 	lsr	x1, x0, #16
    7474:	f949fc44 	ldr	x4, [x2, #5112]
    7478:	8b010821 	add	x1, x1, x1, lsl #2
    747c:	d37df021 	lsl	x1, x1, #3
    7480:	8b010083 	add	x3, x4, x1
    7484:	f9401062 	ldr	x2, [x3, #32]
    7488:	b40002a2 	cbz	x2, 74dc <fwp_caps37+0xac>
    748c:	38616881 	ldrb	w1, [x4, x1]
    7490:	7100083f 	cmp	w1, #0x2
    7494:	54000740 	b.eq	757c <fwp_caps37+0x14c>  // b.none
    7498:	7100043f 	cmp	w1, #0x1
    749c:	54000201 	b.ne	74dc <fwp_caps37+0xac>  // b.any
    74a0:	29430464 	ldp	w4, w1, [x3, #24]
    74a4:	92403c00 	and	x0, x0, #0xffff
    74a8:	9b047c00 	mul	x0, x0, x4
    74ac:	d360fc00 	lsr	x0, x0, #32
    74b0:	eb01001f 	cmp	x0, x1
    74b4:	54000142 	b.cs	74dc <fwp_caps37+0xac>  // b.hs, b.nlast
    74b8:	8b000042 	add	x2, x2, x0
    74bc:	39400040 	ldrb	w0, [x2]
    74c0:	7100041f 	cmp	w0, #0x1
    74c4:	540000c1 	b.ne	74dc <fwp_caps37+0xac>  // b.any
    74c8:	aa1303e0 	mov	x0, x19
    74cc:	f9400bf3 	ldr	x19, [sp, #16]
    74d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    74d4:	17fff43f 	b	45d0 <fwp_mem_free>
    74d8:	34fffbe1 	cbz	w1, 7454 <fwp_caps37+0x24>
    74dc:	f9400bf3 	ldr	x19, [sp, #16]
    74e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    74e4:	d65f03c0 	ret
    74e8:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbc0>
    74ec:	91188042 	add	x2, x2, #0x620
    74f0:	f949d843 	ldr	x3, [x2, #5040]
    74f4:	f949ec41 	ldr	x1, [x2, #5080]
    74f8:	cb030000 	sub	x0, x0, x3
    74fc:	eb01401f 	cmp	x0, x1, lsl #16
    7500:	54fffee2 	b.cs	74dc <fwp_caps37+0xac>  // b.hs, b.nlast
    7504:	d350fc01 	lsr	x1, x0, #16
    7508:	f949fc44 	ldr	x4, [x2, #5112]
    750c:	8b010821 	add	x1, x1, x1, lsl #2
    7510:	d37df021 	lsl	x1, x1, #3
    7514:	8b010083 	add	x3, x4, x1
    7518:	f9401062 	ldr	x2, [x3, #32]
    751c:	b4fffe02 	cbz	x2, 74dc <fwp_caps37+0xac>
    7520:	38616881 	ldrb	w1, [x4, x1]
    7524:	7100083f 	cmp	w1, #0x2
    7528:	54000300 	b.eq	7588 <fwp_caps37+0x158>  // b.none
    752c:	7100043f 	cmp	w1, #0x1
    7530:	54fffd61 	b.ne	74dc <fwp_caps37+0xac>  // b.any
    7534:	92403c01 	and	x1, x0, #0xffff
    7538:	29430064 	ldp	w4, w0, [x3, #24]
    753c:	9b047c21 	mul	x1, x1, x4
    7540:	d360fc21 	lsr	x1, x1, #32
    7544:	eb00003f 	cmp	x1, x0
    7548:	54fffca2 	b.cs	74dc <fwp_caps37+0xac>  // b.hs, b.nlast
    754c:	8b010042 	add	x2, x2, x1
    7550:	39400040 	ldrb	w0, [x2]
    7554:	34fffc40 	cbz	w0, 74dc <fwp_caps37+0xac>
    7558:	b00000c1 	adrp	x1, 20000 <__data_start>
    755c:	91014021 	add	x1, x1, #0x50
    7560:	b9412023 	ldr	w3, [x1, #288]
    7564:	35000183 	cbnz	w3, 7594 <fwp_caps37+0x164>
    7568:	7103f41f 	cmp	w0, #0xfd
    756c:	540001c8 	b.hi	75a4 <fwp_caps37+0x174>  // b.pmore
    7570:	11000400 	add	w0, w0, #0x1
    7574:	39000040 	strb	w0, [x2]
    7578:	17ffffd9 	b	74dc <fwp_caps37+0xac>
    757c:	72003c1f 	tst	w0, #0xffff
    7580:	54fffae1 	b.ne	74dc <fwp_caps37+0xac>  // b.any
    7584:	17ffffce 	b	74bc <fwp_caps37+0x8c>
    7588:	72003c1f 	tst	w0, #0xffff
    758c:	54fffa81 	b.ne	74dc <fwp_caps37+0xac>  // b.any
    7590:	17fffff0 	b	7550 <fwp_caps37+0x120>
    7594:	f940a423 	ldr	x3, [x1, #328]
    7598:	91000463 	add	x3, x3, #0x1
    759c:	f900a423 	str	x3, [x1, #328]
    75a0:	17fffff2 	b	7568 <fwp_caps37+0x138>
    75a4:	f9400bf3 	ldr	x19, [sp, #16]
    75a8:	aa0203e0 	mov	x0, x2
    75ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    75b0:	17fff481 	b	47b4 <fwp_rc_wide_dup>

00000000000075b4 <f37>:
    75b4:	d10243ff 	sub	sp, sp, #0x90
    75b8:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    75bc:	f947f421 	ldr	x1, [x1, #4072]
    75c0:	a9037bfd 	stp	x29, x30, [sp, #48]
    75c4:	9100c3fd 	add	x29, sp, #0x30
    75c8:	a9055bf5 	stp	x21, x22, [sp, #80]
    75cc:	d0000396 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    75d0:	911882c3 	add	x3, x22, #0x620
    75d4:	a90453f3 	stp	x19, x20, [sp, #64]
    75d8:	aa0003f5 	mov	x21, x0
    75dc:	a90663f7 	stp	x23, x24, [sp, #96]
    75e0:	a90873fb 	stp	x27, x28, [sp, #128]
    75e4:	f949ec62 	ldr	x2, [x3, #5080]
    75e8:	f9400024 	ldr	x4, [x1]
    75ec:	f90017e4 	str	x4, [sp, #40]
    75f0:	d2800004 	mov	x4, #0x0                   	// #0
    75f4:	f949d861 	ldr	x1, [x3, #5040]
    75f8:	d370bc42 	lsl	x2, x2, #16
    75fc:	b4001800 	cbz	x0, 78fc <f37+0x348>
    7600:	f9400817 	ldr	x23, [x0, #16]
    7604:	cb0102e1 	sub	x1, x23, x1
    7608:	eb02003f 	cmp	x1, x2
    760c:	540003e2 	b.cs	7688 <f37+0xd4>  // b.hs, b.nlast
    7610:	f949fc60 	ldr	x0, [x3, #5112]
    7614:	d350fc22 	lsr	x2, x1, #16
    7618:	8b020842 	add	x2, x2, x2, lsl #2
    761c:	8b020c02 	add	x2, x0, x2, lsl #3
    7620:	f9401040 	ldr	x0, [x2, #32]
    7624:	b4000320 	cbz	x0, 7688 <f37+0xd4>
    7628:	39400043 	ldrb	w3, [x2]
    762c:	7100087f 	cmp	w3, #0x2
    7630:	540014c0 	b.eq	78c8 <f37+0x314>  // b.none
    7634:	7100047f 	cmp	w3, #0x1
    7638:	54000241 	b.ne	7680 <f37+0xcc>  // b.any
    763c:	29430843 	ldp	w3, w2, [x2, #24]
    7640:	92403c21 	and	x1, x1, #0xffff
    7644:	9b037c21 	mul	x1, x1, x3
    7648:	d360fc21 	lsr	x1, x1, #32
    764c:	eb02003f 	cmp	x1, x2
    7650:	54000182 	b.cs	7680 <f37+0xcc>  // b.hs, b.nlast
    7654:	8b010000 	add	x0, x0, x1
    7658:	39400001 	ldrb	w1, [x0]
    765c:	34000121 	cbz	w1, 7680 <f37+0xcc>
    7660:	b00000c2 	adrp	x2, 20000 <__data_start>
    7664:	91014042 	add	x2, x2, #0x50
    7668:	b9412043 	ldr	w3, [x2, #288]
    766c:	35001343 	cbnz	w3, 78d4 <f37+0x320>
    7670:	7103f43f 	cmp	w1, #0xfd
    7674:	54001788 	b.hi	7964 <f37+0x3b0>  // b.pmore
    7678:	11000421 	add	w1, w1, #0x1
    767c:	39000001 	strb	w1, [x0]
    7680:	d2800002 	mov	x2, #0x0                   	// #0
    7684:	b40000d5 	cbz	x21, 769c <f37+0xe8>
    7688:	aa1503e1 	mov	x1, x21
    768c:	d2800002 	mov	x2, #0x0                   	// #0
    7690:	f9400821 	ldr	x1, [x1, #16]
    7694:	91000442 	add	x2, x2, #0x1
    7698:	b5ffffc1 	cbnz	x1, 7690 <f37+0xdc>
    769c:	b4001377 	cbz	x23, 7908 <f37+0x354>
    76a0:	aa1703e1 	mov	x1, x23
    76a4:	d2800003 	mov	x3, #0x0                   	// #0
    76a8:	f9400821 	ldr	x1, [x1, #16]
    76ac:	91000463 	add	x3, x3, #0x1
    76b0:	b5ffffc1 	cbnz	x1, 76a8 <f37+0xf4>
    76b4:	eb02007f 	cmp	x3, x2
    76b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    76bc:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    76c0:	eb00027f 	cmp	x19, x0
    76c4:	54000fa8 	b.hi	78b8 <f37+0x304>  // b.pmore
    76c8:	d37ffa74 	lsl	x20, x19, #1
    76cc:	52800041 	mov	w1, #0x2                   	// #2
    76d0:	91000680 	add	x0, x20, #0x1
    76d4:	d37df000 	lsl	x0, x0, #3
    76d8:	97fff67a 	bl	50c0 <fwp_heap_alloc>
    76dc:	911882c1 	add	x1, x22, #0x620
    76e0:	aa0003fb 	mov	x27, x0
    76e4:	f9000014 	str	x20, [x0]
    76e8:	aa0103e0 	mov	x0, x1
    76ec:	f949d821 	ldr	x1, [x1, #5040]
    76f0:	f949ec00 	ldr	x0, [x0, #5080]
    76f4:	cb010361 	sub	x1, x27, x1
    76f8:	eb00403f 	cmp	x1, x0, lsl #16
    76fc:	54000342 	b.cs	7764 <f37+0x1b0>  // b.hs, b.nlast
    7700:	911882c2 	add	x2, x22, #0x620
    7704:	d350fc20 	lsr	x0, x1, #16
    7708:	8b000800 	add	x0, x0, x0, lsl #2
    770c:	f949fc43 	ldr	x3, [x2, #5112]
    7710:	d37df002 	lsl	x2, x0, #3
    7714:	8b020060 	add	x0, x3, x2
    7718:	f9401014 	ldr	x20, [x0, #32]
    771c:	b4000254 	cbz	x20, 7764 <f37+0x1b0>
    7720:	38626862 	ldrb	w2, [x3, x2]
    7724:	7100085f 	cmp	w2, #0x2
    7728:	54000de0 	b.eq	78e4 <f37+0x330>  // b.none
    772c:	7100045f 	cmp	w2, #0x1
    7730:	540001a1 	b.ne	7764 <f37+0x1b0>  // b.any
    7734:	29430002 	ldp	w2, w0, [x0, #24]
    7738:	92403c21 	and	x1, x1, #0xffff
    773c:	9b027c21 	mul	x1, x1, x2
    7740:	d360fc21 	lsr	x1, x1, #32
    7744:	eb00003f 	cmp	x1, x0
    7748:	540000e2 	b.cs	7764 <f37+0x1b0>  // b.hs, b.nlast
    774c:	8b010294 	add	x20, x20, x1
    7750:	39400280 	ldrb	w0, [x20]
    7754:	7103fc1f 	cmp	w0, #0xff
    7758:	540010a0 	b.eq	796c <f37+0x3b8>  // b.none
    775c:	52800020 	mov	w0, #0x1                   	// #1
    7760:	39000280 	strb	w0, [x20]
    7764:	b4000333 	cbz	x19, 77c8 <f37+0x214>
    7768:	8b131373 	add	x19, x27, x19, lsl #4
    776c:	aa1b03f4 	mov	x20, x27
    7770:	aa1703f8 	mov	x24, x23
    7774:	910023fc 	add	x28, sp, #0x8
    7778:	a9076bf9 	stp	x25, x26, [sp, #112]
    777c:	aa1503f9 	mov	x25, x21
    7780:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    7784:	d503201f 	nop
    7788:	f9400704 	ldr	x4, [x24, #8]
    778c:	aa1c03e2 	mov	x2, x28
    7790:	f9400723 	ldr	x3, [x25, #8]
    7794:	a900fffa 	stp	x26, xzr, [sp, #8]
    7798:	fd400481 	ldr	d1, [x4, #8]
    779c:	f9400881 	ldr	x1, [x4, #16]
    77a0:	f9400860 	ldr	x0, [x3, #16]
    77a4:	fd400460 	ldr	d0, [x3, #8]
    77a8:	97fff7e2 	bl	5730 <w120>
    77ac:	f9000680 	str	x0, [x20, #8]
    77b0:	f8010e81 	str	x1, [x20, #16]!
    77b4:	f9400b18 	ldr	x24, [x24, #16]
    77b8:	f9400b39 	ldr	x25, [x25, #16]
    77bc:	eb14027f 	cmp	x19, x20
    77c0:	54fffe41 	b.ne	7788 <f37+0x1d4>  // b.any
    77c4:	a9476bf9 	ldp	x25, x26, [sp, #112]
    77c8:	aa1703e0 	mov	x0, x23
    77cc:	97fffc82 	bl	69d4 <fwp_drop4>
    77d0:	911882d6 	add	x22, x22, #0x620
    77d4:	aa1503e0 	mov	x0, x21
    77d8:	97fffc7f 	bl	69d4 <fwp_drop4>
    77dc:	aa1b03e0 	mov	x0, x27
    77e0:	97fff924 	bl	5c70 <w176.constprop.0>
    77e4:	aa0103f3 	mov	x19, x1
    77e8:	aa0003f4 	mov	x20, x0
    77ec:	aa1b03e0 	mov	x0, x27
    77f0:	97fffe34 	bl	70c0 <fwp_drop10>
    77f4:	910063e1 	add	x1, sp, #0x18
    77f8:	52800000 	mov	w0, #0x0                   	// #0
    77fc:	a901cff4 	stp	x20, x19, [sp, #24]
    7800:	97fff694 	bl	5250 <fwp_data.part.0.constprop.0>
    7804:	aa0003f3 	mov	x19, x0
    7808:	f949dac1 	ldr	x1, [x22, #5040]
    780c:	f949eec0 	ldr	x0, [x22, #5080]
    7810:	cb010261 	sub	x1, x19, x1
    7814:	eb00403f 	cmp	x1, x0, lsl #16
    7818:	54000322 	b.cs	787c <f37+0x2c8>  // b.hs, b.nlast
    781c:	d350fc22 	lsr	x2, x1, #16
    7820:	f949fec3 	ldr	x3, [x22, #5112]
    7824:	8b020842 	add	x2, x2, x2, lsl #2
    7828:	d37df042 	lsl	x2, x2, #3
    782c:	8b020060 	add	x0, x3, x2
    7830:	f9401014 	ldr	x20, [x0, #32]
    7834:	b4000254 	cbz	x20, 787c <f37+0x2c8>
    7838:	38626862 	ldrb	w2, [x3, x2]
    783c:	7100085f 	cmp	w2, #0x2
    7840:	54000580 	b.eq	78f0 <f37+0x33c>  // b.none
    7844:	7100045f 	cmp	w2, #0x1
    7848:	540001a1 	b.ne	787c <f37+0x2c8>  // b.any
    784c:	29430002 	ldp	w2, w0, [x0, #24]
    7850:	92403c21 	and	x1, x1, #0xffff
    7854:	9b027c21 	mul	x1, x1, x2
    7858:	d360fc21 	lsr	x1, x1, #32
    785c:	eb00003f 	cmp	x1, x0
    7860:	540000e2 	b.cs	787c <f37+0x2c8>  // b.hs, b.nlast
    7864:	8b010294 	add	x20, x20, x1
    7868:	39400280 	ldrb	w0, [x20]
    786c:	7103fc1f 	cmp	w0, #0xff
    7870:	54000840 	b.eq	7978 <f37+0x3c4>  // b.none
    7874:	52800020 	mov	w0, #0x1                   	// #1
    7878:	39000280 	strb	w0, [x20]
    787c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7880:	f947f400 	ldr	x0, [x0, #4072]
    7884:	f94017e2 	ldr	x2, [sp, #40]
    7888:	f9400001 	ldr	x1, [x0]
    788c:	eb010042 	subs	x2, x2, x1
    7890:	d2800001 	mov	x1, #0x0                   	// #0
    7894:	54000781 	b.ne	7984 <f37+0x3d0>  // b.any
    7898:	a9437bfd 	ldp	x29, x30, [sp, #48]
    789c:	aa1303e0 	mov	x0, x19
    78a0:	a94453f3 	ldp	x19, x20, [sp, #64]
    78a4:	a9455bf5 	ldp	x21, x22, [sp, #80]
    78a8:	a94663f7 	ldp	x23, x24, [sp, #96]
    78ac:	a94873fb 	ldp	x27, x28, [sp, #128]
    78b0:	910243ff 	add	sp, sp, #0x90
    78b4:	d65f03c0 	ret
    78b8:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    78bc:	913a0000 	add	x0, x0, #0xe80
    78c0:	a9076bf9 	stp	x25, x26, [sp, #112]
    78c4:	97fff288 	bl	42e4 <fwp_trap>
    78c8:	72003c3f 	tst	w1, #0xffff
    78cc:	54ffeda1 	b.ne	7680 <f37+0xcc>  // b.any
    78d0:	17ffff62 	b	7658 <f37+0xa4>
    78d4:	f940a443 	ldr	x3, [x2, #328]
    78d8:	91000463 	add	x3, x3, #0x1
    78dc:	f900a443 	str	x3, [x2, #328]
    78e0:	17ffff64 	b	7670 <f37+0xbc>
    78e4:	72003c3f 	tst	w1, #0xffff
    78e8:	54fff3e1 	b.ne	7764 <f37+0x1b0>  // b.any
    78ec:	17ffff99 	b	7750 <f37+0x19c>
    78f0:	72003c3f 	tst	w1, #0xffff
    78f4:	54fffc41 	b.ne	787c <f37+0x2c8>  // b.any
    78f8:	17ffffdc 	b	7868 <f37+0x2b4>
    78fc:	cb0103e1 	neg	x1, x1
    7900:	eb02003f 	cmp	x1, x2
    7904:	54000203 	b.cc	7944 <f37+0x390>  // b.lo, b.ul, b.last
    7908:	52800041 	mov	w1, #0x2                   	// #2
    790c:	d2800100 	mov	x0, #0x8                   	// #8
    7910:	97fff5ec 	bl	50c0 <fwp_heap_alloc>
    7914:	aa0003e1 	mov	x1, x0
    7918:	911882c0 	add	x0, x22, #0x620
    791c:	aa0103fb 	mov	x27, x1
    7920:	d2800017 	mov	x23, #0x0                   	// #0
    7924:	f900003f 	str	xzr, [x1]
    7928:	f949d801 	ldr	x1, [x0, #5040]
    792c:	f949ec00 	ldr	x0, [x0, #5080]
    7930:	cb010361 	sub	x1, x27, x1
    7934:	eb00403f 	cmp	x1, x0, lsl #16
    7938:	54fff482 	b.cs	77c8 <f37+0x214>  // b.hs, b.nlast
    793c:	d2800013 	mov	x19, #0x0                   	// #0
    7940:	17ffff70 	b	7700 <f37+0x14c>
    7944:	f949fc62 	ldr	x2, [x3, #5112]
    7948:	d350fc20 	lsr	x0, x1, #16
    794c:	8b000800 	add	x0, x0, x0, lsl #2
    7950:	8b000c42 	add	x2, x2, x0, lsl #3
    7954:	f9401040 	ldr	x0, [x2, #32]
    7958:	b4fffd80 	cbz	x0, 7908 <f37+0x354>
    795c:	d2800017 	mov	x23, #0x0                   	// #0
    7960:	17ffff32 	b	7628 <f37+0x74>
    7964:	97fff394 	bl	47b4 <fwp_rc_wide_dup>
    7968:	17ffff46 	b	7680 <f37+0xcc>
    796c:	aa1403e0 	mov	x0, x20
    7970:	97fff27d 	bl	4364 <fwp_rc_forget_slot.part.0>
    7974:	17ffff7a 	b	775c <f37+0x1a8>
    7978:	aa1403e0 	mov	x0, x20
    797c:	97fff27a 	bl	4364 <fwp_rc_forget_slot.part.0>
    7980:	17ffffbd 	b	7874 <f37+0x2c0>
    7984:	a9076bf9 	stp	x25, x26, [sp, #112]
    7988:	97ffebb6 	bl	2860 <__stack_chk_fail@plt>
    798c:	d503201f 	nop

0000000000007990 <fwp_owned_entry37>:
    7990:	f9400000 	ldr	x0, [x0]
    7994:	17ffff08 	b	75b4 <f37>
    7998:	d503201f 	nop
    799c:	d503201f 	nop

00000000000079a0 <e37>:
    79a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    79a4:	910003fd 	mov	x29, sp
    79a8:	f9000bf3 	str	x19, [sp, #16]
    79ac:	f9400013 	ldr	x19, [x0]
    79b0:	aa1303e0 	mov	x0, x19
    79b4:	97fff8e3 	bl	5d40 <fwp_rc_share>
    79b8:	aa1303e0 	mov	x0, x19
    79bc:	97fffefe 	bl	75b4 <f37>
    79c0:	aa0003f3 	mov	x19, x0
    79c4:	97fff8df 	bl	5d40 <fwp_rc_share>
    79c8:	aa1303e0 	mov	x0, x19
    79cc:	f9400bf3 	ldr	x19, [sp, #16]
    79d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    79d4:	d65f03c0 	ret
    79d8:	d503201f 	nop
    79dc:	d503201f 	nop

00000000000079e0 <fwp_write>:
    79e0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    79e4:	910003fd 	mov	x29, sp
    79e8:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc88>
    79ec:	f947f484 	ldr	x4, [x4, #4072]
    79f0:	a90153f3 	stp	x19, x20, [sp, #16]
    79f4:	d10943ff 	sub	sp, sp, #0x250
    79f8:	b9400045 	ldr	w5, [x2]
    79fc:	aa0003f4 	mov	x20, x0
    7a00:	f9400080 	ldr	x0, [x4]
    7a04:	f90127e0 	str	x0, [sp, #584]
    7a08:	d2800000 	mov	x0, #0x0                   	// #0
    7a0c:	710064bf 	cmp	w5, #0x19
    7a10:	54000408 	b.hi	7a90 <fwp_write+0xb0>  // b.pmore
    7a14:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x780>
    7a18:	aa0103f3 	mov	x19, x1
    7a1c:	911f4000 	add	x0, x0, #0x7d0
    7a20:	f9013bf5 	str	x21, [sp, #624]
    7a24:	f9013ff6 	str	x22, [sp, #632]
    7a28:	f90153fb 	str	x27, [sp, #672]
    7a2c:	f90157fc 	str	x28, [sp, #680]
    7a30:	aa0203fc 	mov	x28, x2
    7a34:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    7a38:	10000061 	adr	x1, 7a44 <fwp_write+0x64>
    7a3c:	8b20a820 	add	x0, x1, w0, sxth #2
    7a40:	d61f0000 	br	x0
    7a44:	910123e0 	add	x0, sp, #0x48
    7a48:	aa1303e5 	mov	x5, x19
    7a4c:	d0000024 	adrp	x4, d000 <fwp_main_thread+0x42c>
    7a50:	aa0003f3 	mov	x19, x0
    7a54:	913b2084 	add	x4, x4, #0xec8
    7a58:	d2804003 	mov	x3, #0x200                 	// #512
    7a5c:	aa0303e1 	mov	x1, x3
    7a60:	52800042 	mov	w2, #0x2                   	// #2
    7a64:	97ffeb5b 	bl	27d0 <__snprintf_chk@plt>
    7a68:	aa1303e0 	mov	x0, x19
    7a6c:	97ffeb21 	bl	26f0 <strlen@plt>
    7a70:	aa1303e1 	mov	x1, x19
    7a74:	aa0003e2 	mov	x2, x0
    7a78:	aa1403e0 	mov	x0, x20
    7a7c:	97ffeef5 	bl	3650 <buf_put>
    7a80:	f9413bf5 	ldr	x21, [sp, #624]
    7a84:	f9413ff6 	ldr	x22, [sp, #632]
    7a88:	f94153fb 	ldr	x27, [sp, #672]
    7a8c:	f94157fc 	ldr	x28, [sp, #680]
    7a90:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7a94:	f947f400 	ldr	x0, [x0, #4072]
    7a98:	f94127e2 	ldr	x2, [sp, #584]
    7a9c:	f9400001 	ldr	x1, [x0]
    7aa0:	eb010042 	subs	x2, x2, x1
    7aa4:	d2800001 	mov	x1, #0x0                   	// #0
    7aa8:	540077c1 	b.ne	89a0 <fwp_write+0xfc0>  // b.any
    7aac:	910943ff 	add	sp, sp, #0x250
    7ab0:	a94153f3 	ldp	x19, x20, [sp, #16]
    7ab4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7ab8:	d65f03c0 	ret
    7abc:	910123e0 	add	x0, sp, #0x48
    7ac0:	aa1303e5 	mov	x5, x19
    7ac4:	d0000024 	adrp	x4, d000 <fwp_main_thread+0x42c>
    7ac8:	aa0003f3 	mov	x19, x0
    7acc:	913b0084 	add	x4, x4, #0xec0
    7ad0:	d2804003 	mov	x3, #0x200                 	// #512
    7ad4:	17ffffe2 	b	7a5c <fwp_write+0x7c>
    7ad8:	71004cbf 	cmp	w5, #0x13
    7adc:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    7ae0:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    7ae4:	913ac000 	add	x0, x0, #0xeb0
    7ae8:	913ae021 	add	x1, x1, #0xeb8
    7aec:	d2800082 	mov	x2, #0x4                   	// #4
    7af0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7af4:	aa1403e0 	mov	x0, x20
    7af8:	f90143f7 	str	x23, [sp, #640]
    7afc:	d2800016 	mov	x22, #0x0                   	// #0
    7b00:	f90147f8 	str	x24, [sp, #648]
    7b04:	97ffeed3 	bl	3650 <buf_put>
    7b08:	f9400260 	ldr	x0, [x19]
    7b0c:	d0000037 	adrp	x23, d000 <fwp_main_thread+0x42c>
    7b10:	d2800015 	mov	x21, #0x0                   	// #0
    7b14:	913ce2f7 	add	x23, x23, #0xf38
    7b18:	b40047a0 	cbz	x0, 840c <fwp_write+0xa2c>
    7b1c:	b9400380 	ldr	w0, [x28]
    7b20:	52800003 	mov	w3, #0x0                   	// #0
    7b24:	f9401f82 	ldr	x2, [x28, #56]
    7b28:	71004c1f 	cmp	w0, #0x13
    7b2c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7b30:	aa1403e0 	mov	x0, x20
    7b34:	8b010e61 	add	x1, x19, x1, lsl #3
    7b38:	f9400421 	ldr	x1, [x1, #8]
    7b3c:	97ffffa9 	bl	79e0 <fwp_write>
    7b40:	b9400380 	ldr	w0, [x28]
    7b44:	7100481f 	cmp	w0, #0x12
    7b48:	54004b40 	b.eq	84b0 <fwp_write+0xad0>  // b.none
    7b4c:	f9400260 	ldr	x0, [x19]
    7b50:	910006b5 	add	x21, x21, #0x1
    7b54:	91000ad6 	add	x22, x22, #0x2
    7b58:	eb15001f 	cmp	x0, x21
    7b5c:	54004589 	b.ls	840c <fwp_write+0xa2c>  // b.plast
    7b60:	aa1703e1 	mov	x1, x23
    7b64:	aa1403e0 	mov	x0, x20
    7b68:	d2800042 	mov	x2, #0x2                   	// #2
    7b6c:	97ffeeb9 	bl	3650 <buf_put>
    7b70:	17ffffeb 	b	7b1c <fwp_write+0x13c>
    7b74:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    7b78:	913bc021 	add	x1, x1, #0xef0
    7b7c:	d28000c2 	mov	x2, #0x6                   	// #6
    7b80:	aa1403e0 	mov	x0, x20
    7b84:	91004273 	add	x19, x19, #0x10
    7b88:	97ffeeb2 	bl	3650 <buf_put>
    7b8c:	aa1303e0 	mov	x0, x19
    7b90:	97ffead8 	bl	26f0 <strlen@plt>
    7b94:	aa1303e1 	mov	x1, x19
    7b98:	aa0003e2 	mov	x2, x0
    7b9c:	aa1403e0 	mov	x0, x20
    7ba0:	97ffeeac 	bl	3650 <buf_put>
    7ba4:	528007c3 	mov	w3, #0x3e                  	// #62
    7ba8:	aa1403e0 	mov	x0, x20
    7bac:	91001fe1 	add	x1, sp, #0x7
    7bb0:	d2800022 	mov	x2, #0x1                   	// #1
    7bb4:	39001fe3 	strb	w3, [sp, #7]
    7bb8:	17ffffb1 	b	7a7c <fwp_write+0x9c>
    7bbc:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7bc0:	f947f400 	ldr	x0, [x0, #4072]
    7bc4:	f94127e2 	ldr	x2, [sp, #584]
    7bc8:	f9400001 	ldr	x1, [x0]
    7bcc:	eb010042 	subs	x2, x2, x1
    7bd0:	d2800001 	mov	x1, #0x0                   	// #0
    7bd4:	540034e1 	b.ne	8270 <fwp_write+0x890>  // b.any
    7bd8:	f9413bf5 	ldr	x21, [sp, #624]
    7bdc:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    7be0:	f9413ff6 	ldr	x22, [sp, #632]
    7be4:	aa1403e0 	mov	x0, x20
    7be8:	913b4021 	add	x1, x1, #0xed0
    7bec:	d2800142 	mov	x2, #0xa                   	// #10
    7bf0:	f94153fb 	ldr	x27, [sp, #672]
    7bf4:	f94157fc 	ldr	x28, [sp, #680]
    7bf8:	910943ff 	add	sp, sp, #0x250
    7bfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    7c00:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7c04:	17ffee93 	b	3650 <buf_put>
    7c08:	f9400456 	ldr	x22, [x2, #8]
    7c0c:	f90143f7 	str	x23, [sp, #640]
    7c10:	f90147f8 	str	x24, [sp, #648]
    7c14:	b4005b16 	cbz	x22, 8774 <fwp_write+0xd94>
    7c18:	aa1603e0 	mov	x0, x22
    7c1c:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    7c20:	913d4021 	add	x1, x1, #0xf50
    7c24:	97ffeb2f 	bl	28e0 <strcmp@plt>
    7c28:	2a0003f5 	mov	w21, w0
    7c2c:	34005fe0 	cbz	w0, 8828 <fwp_write+0xe48>
    7c30:	aa1603e0 	mov	x0, x22
    7c34:	97ffeaaf 	bl	26f0 <strlen@plt>
    7c38:	aa1603e1 	mov	x1, x22
    7c3c:	aa0003e2 	mov	x2, x0
    7c40:	aa1403e0 	mov	x0, x20
    7c44:	97ffee83 	bl	3650 <buf_put>
    7c48:	52800403 	mov	w3, #0x20                  	// #32
    7c4c:	91001ff5 	add	x21, sp, #0x7
    7c50:	aa1503e1 	mov	x1, x21
    7c54:	aa1403e0 	mov	x0, x20
    7c58:	d2800022 	mov	x2, #0x1                   	// #1
    7c5c:	39001fe3 	strb	w3, [sp, #7]
    7c60:	97ffee7c 	bl	3650 <buf_put>
    7c64:	52800f63 	mov	w3, #0x7b                  	// #123
    7c68:	aa1403e0 	mov	x0, x20
    7c6c:	aa1503e1 	mov	x1, x21
    7c70:	d2800022 	mov	x2, #0x1                   	// #1
    7c74:	39001fe3 	strb	w3, [sp, #7]
    7c78:	97ffee76 	bl	3650 <buf_put>
    7c7c:	b9401380 	ldr	w0, [x28, #16]
    7c80:	52800018 	mov	w24, #0x0                   	// #0
    7c84:	7100001f 	cmp	w0, #0x0
    7c88:	54003aad 	b.le	83dc <fwp_write+0x9fc>
    7c8c:	f9014bf9 	str	x25, [sp, #656]
    7c90:	d0000039 	adrp	x25, d000 <fwp_main_thread+0x42c>
    7c94:	913de339 	add	x25, x25, #0xf78
    7c98:	f9014ffa 	str	x26, [sp, #664]
    7c9c:	d000003a 	adrp	x26, d000 <fwp_main_thread+0x42c>
    7ca0:	913ce35a 	add	x26, x26, #0xf38
    7ca4:	91002276 	add	x22, x19, #0x8
    7ca8:	d2800013 	mov	x19, #0x0                   	// #0
    7cac:	b5003e93 	cbnz	x19, 847c <fwp_write+0xa9c>
    7cb0:	d37df277 	lsl	x23, x19, #3
    7cb4:	34003cb8 	cbz	w24, 8448 <fwp_write+0xa68>
    7cb8:	f9401382 	ldr	x2, [x28, #32]
    7cbc:	aa1403e0 	mov	x0, x20
    7cc0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7cc4:	52800003 	mov	w3, #0x0                   	// #0
    7cc8:	f8776842 	ldr	x2, [x2, x23]
    7ccc:	91000673 	add	x19, x19, #0x1
    7cd0:	97ffff44 	bl	79e0 <fwp_write>
    7cd4:	b9401380 	ldr	w0, [x28, #16]
    7cd8:	6b13001f 	cmp	w0, w19
    7cdc:	54fffe8c 	b.gt	7cac <fwp_write+0x2cc>
    7ce0:	f9414bf9 	ldr	x25, [sp, #656]
    7ce4:	f9414ffa 	ldr	x26, [sp, #664]
    7ce8:	340037b8 	cbz	w24, 83dc <fwp_write+0x9fc>
    7cec:	52800523 	mov	w3, #0x29                  	// #41
    7cf0:	aa1503e1 	mov	x1, x21
    7cf4:	aa1403e0 	mov	x0, x20
    7cf8:	d2800022 	mov	x2, #0x1                   	// #1
    7cfc:	39001fe3 	strb	w3, [sp, #7]
    7d00:	97ffee54 	bl	3650 <buf_put>
    7d04:	f9413bf5 	ldr	x21, [sp, #624]
    7d08:	f9413ff6 	ldr	x22, [sp, #632]
    7d0c:	f94143f7 	ldr	x23, [sp, #640]
    7d10:	f94147f8 	ldr	x24, [sp, #648]
    7d14:	f94153fb 	ldr	x27, [sp, #672]
    7d18:	f94157fc 	ldr	x28, [sp, #680]
    7d1c:	17ffff5d 	b	7a90 <fwp_write+0xb0>
    7d20:	b9404855 	ldr	w21, [x2, #72]
    7d24:	aa1403e0 	mov	x0, x20
    7d28:	93407eb6 	sxtw	x22, w21
    7d2c:	91000ac1 	add	x1, x22, #0x2
    7d30:	97ffee14 	bl	3580 <buf_grow>
    7d34:	a9400281 	ldp	x1, x0, [x20]
    7d38:	528e8603 	mov	w3, #0x7430                	// #29744
    7d3c:	78206823 	strh	w3, [x1, x0]
    7d40:	8b000022 	add	x2, x1, x0
    7d44:	710002bf 	cmp	w21, #0x0
    7d48:	540036cd 	b.le	8420 <fwp_write+0xa40>
    7d4c:	110006a3 	add	w3, w21, #0x1
    7d50:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7d54:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7d58:	91000449 	add	x9, x2, #0x1
    7d5c:	8b23c043 	add	x3, x2, w3, sxtw
    7d60:	f28aaac6 	movk	x6, #0x5556
    7d64:	f2955568 	movk	x8, #0xaaab
    7d68:	1400000d 	b	7d9c <fwp_write+0x3bc>
    7d6c:	d2800021 	mov	x1, #0x1                   	// #1
    7d70:	528005a5 	mov	w5, #0x2d                  	// #45
    7d74:	f100001f 	cmp	x0, #0x0
    7d78:	9b467e60 	smulh	x0, x19, x6
    7d7c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7d80:	381ff465 	strb	w5, [x3], #-1
    7d84:	cb040000 	sub	x0, x0, x4
    7d88:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7d8c:	cb020000 	sub	x0, x0, x2
    7d90:	8b010013 	add	x19, x0, x1
    7d94:	eb03013f 	cmp	x9, x3
    7d98:	54003440 	b.eq	8420 <fwp_write+0xa40>  // b.none
    7d9c:	9b467e60 	smulh	x0, x19, x6
    7da0:	937ffe64 	asr	x4, x19, #63
    7da4:	52800605 	mov	w5, #0x30                  	// #48
    7da8:	cb040000 	sub	x0, x0, x4
    7dac:	8b000400 	add	x0, x0, x0, lsl #1
    7db0:	cb000260 	sub	x0, x19, x0
    7db4:	91000c01 	add	x1, x0, #0x3
    7db8:	9bc87c22 	umulh	x2, x1, x8
    7dbc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7dc0:	8b4204e2 	add	x2, x7, x2, lsr #1
    7dc4:	eb020021 	subs	x1, x1, x2
    7dc8:	54fffd60 	b.eq	7d74 <fwp_write+0x394>  // b.none
    7dcc:	f100043f 	cmp	x1, #0x1
    7dd0:	54fffce1 	b.ne	7d6c <fwp_write+0x38c>  // b.any
    7dd4:	d2800001 	mov	x1, #0x0                   	// #0
    7dd8:	52800565 	mov	w5, #0x2b                  	// #43
    7ddc:	17ffffe6 	b	7d74 <fwp_write+0x394>
    7de0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7de4:	f947f400 	ldr	x0, [x0, #4072]
    7de8:	f94127e2 	ldr	x2, [sp, #584]
    7dec:	f9400001 	ldr	x1, [x0]
    7df0:	eb010042 	subs	x2, x2, x1
    7df4:	d2800001 	mov	x1, #0x0                   	// #0
    7df8:	540023c1 	b.ne	8270 <fwp_write+0x890>  // b.any
    7dfc:	f9413bf5 	ldr	x21, [sp, #624]
    7e00:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    7e04:	f9413ff6 	ldr	x22, [sp, #632]
    7e08:	aa1403e0 	mov	x0, x20
    7e0c:	913b8021 	add	x1, x1, #0xee0
    7e10:	d2800102 	mov	x2, #0x8                   	// #8
    7e14:	17ffff77 	b	7bf0 <fwp_write+0x210>
    7e18:	aa1403e0 	mov	x0, x20
    7e1c:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    7e20:	d28000c2 	mov	x2, #0x6                   	// #6
    7e24:	913d0021 	add	x1, x1, #0xf40
    7e28:	97ffee0a 	bl	3650 <buf_put>
    7e2c:	d2800015 	mov	x21, #0x0                   	// #0
    7e30:	f9400263 	ldr	x3, [x19]
    7e34:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7e38:	54002c60 	b.eq	83c4 <fwp_write+0x9e4>  // b.none
    7e3c:	f9401f82 	ldr	x2, [x28, #56]
    7e40:	f90143f7 	str	x23, [sp, #640]
    7e44:	f90147f8 	str	x24, [sp, #648]
    7e48:	d2800857 	mov	x23, #0x42                  	// #66
    7e4c:	f9014bf9 	str	x25, [sp, #656]
    7e50:	d0000036 	adrp	x22, d000 <fwp_main_thread+0x42c>
    7e54:	f9014ffa 	str	x26, [sp, #664]
    7e58:	913ce2d6 	add	x22, x22, #0xf38
    7e5c:	d2800038 	mov	x24, #0x1                   	// #1
    7e60:	f2a18017 	movk	x23, #0xc00, lsl #16
    7e64:	d2809099 	mov	x25, #0x484                 	// #1156
    7e68:	b40004a2 	cbz	x2, 7efc <fwp_write+0x51c>
    7e6c:	b9400040 	ldr	w0, [x2]
    7e70:	7100701f 	cmp	w0, #0x1c
    7e74:	540042c0 	b.eq	86cc <fwp_write+0xcec>  // b.none
    7e78:	71006c1f 	cmp	w0, #0x1b
    7e7c:	54000408 	b.hi	7efc <fwp_write+0x51c>  // b.pmore
    7e80:	9ac02301 	lsl	x1, x24, x0
    7e84:	ea17003f 	tst	x1, x23
    7e88:	540036a1 	b.ne	855c <fwp_write+0xb7c>  // b.any
    7e8c:	ea19003f 	tst	x1, x25
    7e90:	54003521 	b.ne	8534 <fwp_write+0xb54>  // b.any
    7e94:	d2800424 	mov	x4, #0x21                  	// #33
    7e98:	ea04003f 	tst	x1, x4
    7e9c:	54000300 	b.eq	7efc <fwp_write+0x51c>  // b.none
    7ea0:	b7f849c3 	tbnz	x3, #63, 87d8 <fwp_write+0xdf8>
    7ea4:	91002261 	add	x1, x19, #0x8
    7ea8:	8b150021 	add	x1, x1, x21
    7eac:	39400021 	ldrb	w1, [x1]
    7eb0:	7100001f 	cmp	w0, #0x0
    7eb4:	93401c23 	sxtb	x3, w1
    7eb8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7ebc:	d503201f 	nop
    7ec0:	aa1403e0 	mov	x0, x20
    7ec4:	52800003 	mov	w3, #0x0                   	// #0
    7ec8:	97fffec6 	bl	79e0 <fwp_write>
    7ecc:	910006b5 	add	x21, x21, #0x1
    7ed0:	f9400260 	ldr	x0, [x19]
    7ed4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7ed8:	eb0002bf 	cmp	x21, x0
    7edc:	540026c2 	b.cs	83b4 <fwp_write+0x9d4>  // b.hs, b.nlast
    7ee0:	d2800042 	mov	x2, #0x2                   	// #2
    7ee4:	aa1603e1 	mov	x1, x22
    7ee8:	aa1403e0 	mov	x0, x20
    7eec:	97ffedd9 	bl	3650 <buf_put>
    7ef0:	f9401f82 	ldr	x2, [x28, #56]
    7ef4:	f9400263 	ldr	x3, [x19]
    7ef8:	b5fffba2 	cbnz	x2, 7e6c <fwp_write+0x48c>
    7efc:	d37df2a0 	lsl	x0, x21, #3
    7f00:	b7f83f03 	tbnz	x3, #63, 86e0 <fwp_write+0xd00>
    7f04:	91002261 	add	x1, x19, #0x8
    7f08:	8b000020 	add	x0, x1, x0
    7f0c:	f9400001 	ldr	x1, [x0]
    7f10:	17ffffec 	b	7ec0 <fwp_write+0x4e0>
    7f14:	a9400e62 	ldp	x2, x3, [x19]
    7f18:	b7f83ca3 	tbnz	x3, #63, 86ac <fwp_write+0xccc>
    7f1c:	910123f5 	add	x21, sp, #0x48
    7f20:	aa1503e0 	mov	x0, x21
    7f24:	97ffebaf 	bl	2de0 <fwp_fmt_u128>
    7f28:	aa1503e0 	mov	x0, x21
    7f2c:	97ffe9f1 	bl	26f0 <strlen@plt>
    7f30:	aa1503e1 	mov	x1, x21
    7f34:	aa0003e2 	mov	x2, x0
    7f38:	17fffed0 	b	7a78 <fwp_write+0x98>
    7f3c:	fd015be8 	str	d8, [sp, #688]
    7f40:	1e270268 	fmov	s8, w19
    7f44:	fd015fe9 	str	d9, [sp, #696]
    7f48:	1e282100 	fcmp	s8, s8
    7f4c:	54004d26 	b.vs	88f0 <fwp_write+0xf10>
    7f50:	1e20c101 	fabs	s1, s8
    7f54:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7f58:	1e270000 	fmov	s0, w0
    7f5c:	1e202020 	fcmp	s1, s0
    7f60:	54002c0d 	b.le	84e0 <fwp_write+0xb00>
    7f64:	1e202118 	fcmpe	s8, #0.0
    7f68:	d0000022 	adrp	x2, d000 <fwp_main_thread+0x42c>
    7f6c:	9127e042 	add	x2, x2, #0x9f8
    7f70:	910123f5 	add	x21, sp, #0x48
    7f74:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    7f78:	913a4021 	add	x1, x1, #0xe90
    7f7c:	aa1503e0 	mov	x0, x21
    7f80:	9a81c041 	csel	x1, x2, x1, gt
    7f84:	97ffea87 	bl	29a0 <strcpy@plt>
    7f88:	aa1503e0 	mov	x0, x21
    7f8c:	97ffe9d9 	bl	26f0 <strlen@plt>
    7f90:	aa1503e1 	mov	x1, x21
    7f94:	aa0003e2 	mov	x2, x0
    7f98:	aa1403e0 	mov	x0, x20
    7f9c:	97ffedad 	bl	3650 <buf_put>
    7fa0:	f9413bf5 	ldr	x21, [sp, #624]
    7fa4:	f9413ff6 	ldr	x22, [sp, #632]
    7fa8:	f94153fb 	ldr	x27, [sp, #672]
    7fac:	f94157fc 	ldr	x28, [sp, #680]
    7fb0:	fd415be8 	ldr	d8, [sp, #688]
    7fb4:	fd415fe9 	ldr	d9, [sp, #696]
    7fb8:	17fffeb6 	b	7a90 <fwp_write+0xb0>
    7fbc:	f9400276 	ldr	x22, [x19]
    7fc0:	34002e03 	cbz	w3, 8580 <fwp_write+0xba0>
    7fc4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7fc8:	f947f400 	ldr	x0, [x0, #4072]
    7fcc:	f94127e2 	ldr	x2, [sp, #584]
    7fd0:	f9400001 	ldr	x1, [x0]
    7fd4:	eb010042 	subs	x2, x2, x1
    7fd8:	d2800001 	mov	x1, #0x0                   	// #0
    7fdc:	540014a1 	b.ne	8270 <fwp_write+0x890>  // b.any
    7fe0:	aa1603e2 	mov	x2, x22
    7fe4:	91002261 	add	x1, x19, #0x8
    7fe8:	f9413bf5 	ldr	x21, [sp, #624]
    7fec:	aa1403e0 	mov	x0, x20
    7ff0:	f9413ff6 	ldr	x22, [sp, #632]
    7ff4:	17fffeff 	b	7bf0 <fwp_write+0x210>
    7ff8:	fd015be8 	str	d8, [sp, #688]
    7ffc:	9e670268 	fmov	d8, x19
    8000:	fd015fe9 	str	d9, [sp, #696]
    8004:	1e682100 	fcmp	d8, d8
    8008:	54004746 	b.vs	88f0 <fwp_write+0xf10>
    800c:	1e60c101 	fabs	d1, d8
    8010:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8014:	9e670000 	fmov	d0, x0
    8018:	910123f5 	add	x21, sp, #0x48
    801c:	52800033 	mov	w19, #0x1                   	// #1
    8020:	1e602020 	fcmp	d1, d0
    8024:	540001ad 	b.le	8058 <fwp_write+0x678>
    8028:	1e602118 	fcmpe	d8, #0.0
    802c:	b0000022 	adrp	x2, d000 <fwp_main_thread+0x42c>
    8030:	9127e042 	add	x2, x2, #0x9f8
    8034:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    8038:	913a4021 	add	x1, x1, #0xe90
    803c:	aa1503e0 	mov	x0, x21
    8040:	9a81c041 	csel	x1, x2, x1, gt
    8044:	97ffea57 	bl	29a0 <strcpy@plt>
    8048:	17ffffd0 	b	7f88 <fwp_write+0x5a8>
    804c:	11000673 	add	w19, w19, #0x1
    8050:	71004a7f 	cmp	w19, #0x12
    8054:	54003860 	b.eq	8760 <fwp_write+0xd80>  // b.none
    8058:	1e604100 	fmov	d0, d8
    805c:	2a1303e1 	mov	w1, w19
    8060:	aa1503e0 	mov	x0, x21
    8064:	97ffedd7 	bl	37c0 <fwp_format_g.constprop.0>
    8068:	aa1503e0 	mov	x0, x21
    806c:	d2800001 	mov	x1, #0x0                   	// #0
    8070:	97ffe9b4 	bl	2740 <strtod@plt>
    8074:	1e602100 	fcmp	d8, d0
    8078:	54fffea1 	b.ne	804c <fwp_write+0x66c>  // b.any
    807c:	aa1503e0 	mov	x0, x21
    8080:	97ffedad 	bl	3734 <fwp_finish_float>
    8084:	17ffffc1 	b	7f88 <fwp_write+0x5a8>
    8088:	a9400e62 	ldp	x2, x3, [x19]
    808c:	910123f3 	add	x19, sp, #0x48
    8090:	aa1303e0 	mov	x0, x19
    8094:	97ffeb53 	bl	2de0 <fwp_fmt_u128>
    8098:	17fffe74 	b	7a68 <fwp_write+0x88>
    809c:	f90143f7 	str	x23, [sp, #640]
    80a0:	f90147f8 	str	x24, [sp, #648]
    80a4:	2a1303f8 	mov	w24, w19
    80a8:	f9014bf9 	str	x25, [sp, #656]
    80ac:	f9014ffa 	str	x26, [sp, #664]
    80b0:	f13ffe7f 	cmp	x19, #0xfff
    80b4:	54000049 	b.ls	80bc <fwp_write+0x6dc>  // b.plast
    80b8:	b9400278 	ldr	w24, [x19]
    80bc:	f9400f80 	ldr	x0, [x28, #24]
    80c0:	2a1803f5 	mov	w21, w24
    80c4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    80c8:	d37ef6b9 	lsl	x25, x21, #2
    80cc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    80d0:	aa1603e0 	mov	x0, x22
    80d4:	97ffe987 	bl	26f0 <strlen@plt>
    80d8:	aa1603e1 	mov	x1, x22
    80dc:	aa0003e2 	mov	x2, x0
    80e0:	aa1403e0 	mov	x0, x20
    80e4:	97ffed5b 	bl	3650 <buf_put>
    80e8:	f9401780 	ldr	x0, [x28, #40]
    80ec:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    80f0:	7100001f 	cmp	w0, #0x0
    80f4:	5400068d 	b.le	81c4 <fwp_write+0x7e4>
    80f8:	91002276 	add	x22, x19, #0x8
    80fc:	91001ff5 	add	x21, sp, #0x7
    8100:	d280001b 	mov	x27, #0x0                   	// #0
    8104:	5280041a 	mov	w26, #0x20                  	// #32
    8108:	f9401b80 	ldr	x0, [x28, #48]
    810c:	aa1503e1 	mov	x1, x21
    8110:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8114:	d2800022 	mov	x2, #0x1                   	// #1
    8118:	f8786803 	ldr	x3, [x0, x24]
    811c:	aa1403e0 	mov	x0, x20
    8120:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8124:	39001ffa 	strb	w26, [sp, #7]
    8128:	97ffed4a 	bl	3650 <buf_put>
    812c:	f13ffeff 	cmp	x23, #0xfff
    8130:	b9400261 	ldr	w1, [x19]
    8134:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8138:	7100383f 	cmp	w1, #0xe
    813c:	54000160 	b.eq	8168 <fwp_write+0x788>  // b.none
    8140:	7100403f 	cmp	w1, #0x10
    8144:	54001a60 	b.eq	8490 <fwp_write+0xab0>  // b.none
    8148:	7100283f 	cmp	w1, #0xa
    814c:	54002aa0 	b.eq	86a0 <fwp_write+0xcc0>  // b.none
    8150:	540014ac 	b.gt	83e4 <fwp_write+0xa04>
    8154:	71000c3f 	cmp	w1, #0x3
    8158:	540029ac 	b.gt	868c <fwp_write+0xcac>
    815c:	d37ffee0 	lsr	x0, x23, #63
    8160:	37f814a1 	tbnz	w1, #31, 83f4 <fwp_write+0xa14>
    8164:	d503201f 	nop
    8168:	34001460 	cbz	w0, 83f4 <fwp_write+0xa14>
    816c:	52800503 	mov	w3, #0x28                  	// #40
    8170:	aa1503e1 	mov	x1, x21
    8174:	aa1403e0 	mov	x0, x20
    8178:	d2800022 	mov	x2, #0x1                   	// #1
    817c:	39001fe3 	strb	w3, [sp, #7]
    8180:	97ffed34 	bl	3650 <buf_put>
    8184:	aa1303e2 	mov	x2, x19
    8188:	aa1703e1 	mov	x1, x23
    818c:	aa1403e0 	mov	x0, x20
    8190:	52800003 	mov	w3, #0x0                   	// #0
    8194:	97fffe13 	bl	79e0 <fwp_write>
    8198:	52800523 	mov	w3, #0x29                  	// #41
    819c:	aa1503e1 	mov	x1, x21
    81a0:	aa1403e0 	mov	x0, x20
    81a4:	d2800022 	mov	x2, #0x1                   	// #1
    81a8:	39001fe3 	strb	w3, [sp, #7]
    81ac:	97ffed29 	bl	3650 <buf_put>
    81b0:	f9401780 	ldr	x0, [x28, #40]
    81b4:	9100077b 	add	x27, x27, #0x1
    81b8:	b8796800 	ldr	w0, [x0, x25]
    81bc:	6b1b001f 	cmp	w0, w27
    81c0:	54fffa4c 	b.gt	8108 <fwp_write+0x728>
    81c4:	f9413bf5 	ldr	x21, [sp, #624]
    81c8:	f9413ff6 	ldr	x22, [sp, #632]
    81cc:	f94143f7 	ldr	x23, [sp, #640]
    81d0:	f94147f8 	ldr	x24, [sp, #648]
    81d4:	f9414bf9 	ldr	x25, [sp, #656]
    81d8:	f9414ffa 	ldr	x26, [sp, #664]
    81dc:	f94153fb 	ldr	x27, [sp, #672]
    81e0:	f94157fc 	ldr	x28, [sp, #680]
    81e4:	17fffe2b 	b	7a90 <fwp_write+0xb0>
    81e8:	52800783 	mov	w3, #0x3c                  	// #60
    81ec:	91001ff3 	add	x19, sp, #0x7
    81f0:	aa1303e1 	mov	x1, x19
    81f4:	d2800022 	mov	x2, #0x1                   	// #1
    81f8:	aa1403e0 	mov	x0, x20
    81fc:	39001fe3 	strb	w3, [sp, #7]
    8200:	97ffed14 	bl	3650 <buf_put>
    8204:	f9400795 	ldr	x21, [x28, #8]
    8208:	aa1503e0 	mov	x0, x21
    820c:	97ffe939 	bl	26f0 <strlen@plt>
    8210:	aa1503e1 	mov	x1, x21
    8214:	aa0003e2 	mov	x2, x0
    8218:	aa1403e0 	mov	x0, x20
    821c:	97ffed0d 	bl	3650 <buf_put>
    8220:	528007c3 	mov	w3, #0x3e                  	// #62
    8224:	aa1303e1 	mov	x1, x19
    8228:	aa1403e0 	mov	x0, x20
    822c:	d2800022 	mov	x2, #0x1                   	// #1
    8230:	39001fe3 	strb	w3, [sp, #7]
    8234:	17fffe12 	b	7a7c <fwp_write+0x9c>
    8238:	f100067f 	cmp	x19, #0x1
    823c:	540025a0 	b.eq	86f0 <fwp_write+0xd10>  // b.none
    8240:	b100067f 	cmn	x19, #0x1
    8244:	54002bc0 	b.eq	87bc <fwp_write+0xddc>  // b.none
    8248:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    824c:	913a6021 	add	x1, x1, #0xe98
    8250:	d2800022 	mov	x2, #0x1                   	// #1
    8254:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8258:	f947f400 	ldr	x0, [x0, #4072]
    825c:	f94127e4 	ldr	x4, [sp, #584]
    8260:	f9400003 	ldr	x3, [x0]
    8264:	eb030084 	subs	x4, x4, x3
    8268:	d2800003 	mov	x3, #0x0                   	// #0
    826c:	54ffebe0 	b.eq	7fe8 <fwp_write+0x608>  // b.none
    8270:	f90143f7 	str	x23, [sp, #640]
    8274:	f90147f8 	str	x24, [sp, #648]
    8278:	f9014bf9 	str	x25, [sp, #656]
    827c:	f9014ffa 	str	x26, [sp, #664]
    8280:	fd015be8 	str	d8, [sp, #688]
    8284:	fd015fe9 	str	d9, [sp, #696]
    8288:	97ffe976 	bl	2860 <__stack_chk_fail@plt>
    828c:	52800b63 	mov	w3, #0x5b                  	// #91
    8290:	91001ff5 	add	x21, sp, #0x7
    8294:	aa1503e1 	mov	x1, x21
    8298:	aa1403e0 	mov	x0, x20
    829c:	d2800022 	mov	x2, #0x1                   	// #1
    82a0:	b0000036 	adrp	x22, d000 <fwp_main_thread+0x42c>
    82a4:	913ce2d6 	add	x22, x22, #0xf38
    82a8:	39001fe3 	strb	w3, [sp, #7]
    82ac:	97ffece9 	bl	3650 <buf_put>
    82b0:	b4000273 	cbz	x19, 82fc <fwp_write+0x91c>
    82b4:	f9400661 	ldr	x1, [x19, #8]
    82b8:	aa1403e0 	mov	x0, x20
    82bc:	f9401f82 	ldr	x2, [x28, #56]
    82c0:	52800003 	mov	w3, #0x0                   	// #0
    82c4:	97fffdc7 	bl	79e0 <fwp_write>
    82c8:	f9400a73 	ldr	x19, [x19, #16]
    82cc:	b4000193 	cbz	x19, 82fc <fwp_write+0x91c>
    82d0:	aa1603e1 	mov	x1, x22
    82d4:	aa1403e0 	mov	x0, x20
    82d8:	d2800042 	mov	x2, #0x2                   	// #2
    82dc:	97ffecdd 	bl	3650 <buf_put>
    82e0:	f9400661 	ldr	x1, [x19, #8]
    82e4:	aa1403e0 	mov	x0, x20
    82e8:	f9401f82 	ldr	x2, [x28, #56]
    82ec:	52800003 	mov	w3, #0x0                   	// #0
    82f0:	97fffdbc 	bl	79e0 <fwp_write>
    82f4:	f9400a73 	ldr	x19, [x19, #16]
    82f8:	b5fffed3 	cbnz	x19, 82d0 <fwp_write+0x8f0>
    82fc:	52800ba3 	mov	w3, #0x5d                  	// #93
    8300:	aa1503e1 	mov	x1, x21
    8304:	aa1403e0 	mov	x0, x20
    8308:	d2800022 	mov	x2, #0x1                   	// #1
    830c:	39001fe3 	strb	w3, [sp, #7]
    8310:	17fffddb 	b	7a7c <fwp_write+0x9c>
    8314:	aa1403e0 	mov	x0, x20
    8318:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    831c:	d28000c2 	mov	x2, #0x6                   	// #6
    8320:	913ca021 	add	x1, x1, #0xf28
    8324:	97ffeccb 	bl	3650 <buf_put>
    8328:	f9400260 	ldr	x0, [x19]
    832c:	b40004c0 	cbz	x0, 83c4 <fwp_write+0x9e4>
    8330:	910123f5 	add	x21, sp, #0x48
    8334:	91002276 	add	x22, x19, #0x8
    8338:	f90143f7 	str	x23, [sp, #640]
    833c:	d2800017 	mov	x23, #0x0                   	// #0
    8340:	f90147f8 	str	x24, [sp, #648]
    8344:	b0000038 	adrp	x24, d000 <fwp_main_thread+0x42c>
    8348:	913cc318 	add	x24, x24, #0xf30
    834c:	f9014bf9 	str	x25, [sp, #656]
    8350:	b0000039 	adrp	x25, d000 <fwp_main_thread+0x42c>
    8354:	913ce339 	add	x25, x25, #0xf38
    8358:	f9014ffa 	str	x26, [sp, #664]
    835c:	14000005 	b	8370 <fwp_write+0x990>
    8360:	aa1903e1 	mov	x1, x25
    8364:	aa1403e0 	mov	x0, x20
    8368:	d2800042 	mov	x2, #0x2                   	// #2
    836c:	97ffecb9 	bl	3650 <buf_put>
    8370:	38776ac5 	ldrb	w5, [x22, x23]
    8374:	d2804003 	mov	x3, #0x200                 	// #512
    8378:	aa1803e4 	mov	x4, x24
    837c:	aa0303e1 	mov	x1, x3
    8380:	52800042 	mov	w2, #0x2                   	// #2
    8384:	aa1503e0 	mov	x0, x21
    8388:	910006f7 	add	x23, x23, #0x1
    838c:	97ffe911 	bl	27d0 <__snprintf_chk@plt>
    8390:	aa1503e0 	mov	x0, x21
    8394:	97ffe8d7 	bl	26f0 <strlen@plt>
    8398:	aa1503e1 	mov	x1, x21
    839c:	aa0003e2 	mov	x2, x0
    83a0:	aa1403e0 	mov	x0, x20
    83a4:	97ffecab 	bl	3650 <buf_put>
    83a8:	f9400260 	ldr	x0, [x19]
    83ac:	eb17001f 	cmp	x0, x23
    83b0:	54fffd88 	b.hi	8360 <fwp_write+0x980>  // b.pmore
    83b4:	f94143f7 	ldr	x23, [sp, #640]
    83b8:	f94147f8 	ldr	x24, [sp, #648]
    83bc:	f9414bf9 	ldr	x25, [sp, #656]
    83c0:	f9414ffa 	ldr	x26, [sp, #664]
    83c4:	52800ba3 	mov	w3, #0x5d                  	// #93
    83c8:	aa1403e0 	mov	x0, x20
    83cc:	91001fe1 	add	x1, sp, #0x7
    83d0:	d2800022 	mov	x2, #0x1                   	// #1
    83d4:	39001fe3 	strb	w3, [sp, #7]
    83d8:	17fffda9 	b	7a7c <fwp_write+0x9c>
    83dc:	52800fa3 	mov	w3, #0x7d                  	// #125
    83e0:	17fffe44 	b	7cf0 <fwp_write+0x310>
    83e4:	f10002ff 	cmp	x23, #0x0
    83e8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    83ec:	71002c3f 	cmp	w1, #0xb
    83f0:	54ffebc0 	b.eq	8168 <fwp_write+0x788>  // b.none
    83f4:	aa1303e2 	mov	x2, x19
    83f8:	aa1703e1 	mov	x1, x23
    83fc:	aa1403e0 	mov	x0, x20
    8400:	52800003 	mov	w3, #0x0                   	// #0
    8404:	97fffd77 	bl	79e0 <fwp_write>
    8408:	17ffff6a 	b	81b0 <fwp_write+0x7d0>
    840c:	aa1403e0 	mov	x0, x20
    8410:	91001fe1 	add	x1, sp, #0x7
    8414:	52800fa3 	mov	w3, #0x7d                  	// #125
    8418:	d2800022 	mov	x2, #0x1                   	// #1
    841c:	17fffe38 	b	7cfc <fwp_write+0x31c>
    8420:	a9400281 	ldp	x1, x0, [x20]
    8424:	91000800 	add	x0, x0, #0x2
    8428:	8b160000 	add	x0, x0, x22
    842c:	f9000680 	str	x0, [x20, #8]
    8430:	3820683f 	strb	wzr, [x1, x0]
    8434:	f9413bf5 	ldr	x21, [sp, #624]
    8438:	f9413ff6 	ldr	x22, [sp, #632]
    843c:	f94153fb 	ldr	x27, [sp, #672]
    8440:	f94157fc 	ldr	x28, [sp, #680]
    8444:	17fffd93 	b	7a90 <fwp_write+0xb0>
    8448:	f9400f80 	ldr	x0, [x28, #24]
    844c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8450:	aa1b03e0 	mov	x0, x27
    8454:	97ffe8a7 	bl	26f0 <strlen@plt>
    8458:	aa1b03e1 	mov	x1, x27
    845c:	aa0003e2 	mov	x2, x0
    8460:	aa1403e0 	mov	x0, x20
    8464:	97ffec7b 	bl	3650 <buf_put>
    8468:	aa1903e1 	mov	x1, x25
    846c:	aa1403e0 	mov	x0, x20
    8470:	d2800062 	mov	x2, #0x3                   	// #3
    8474:	97ffec77 	bl	3650 <buf_put>
    8478:	17fffe10 	b	7cb8 <fwp_write+0x2d8>
    847c:	aa1a03e1 	mov	x1, x26
    8480:	aa1403e0 	mov	x0, x20
    8484:	d2800042 	mov	x2, #0x2                   	// #2
    8488:	97ffec72 	bl	3650 <buf_put>
    848c:	17fffe09 	b	7cb0 <fwp_write+0x2d0>
    8490:	f9400660 	ldr	x0, [x19, #8]
    8494:	b4fffb00 	cbz	x0, 83f4 <fwp_write+0xa14>
    8498:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    849c:	913d4021 	add	x1, x1, #0xf50
    84a0:	97ffe910 	bl	28e0 <strcmp@plt>
    84a4:	7100001f 	cmp	w0, #0x0
    84a8:	1a9f07e0 	cset	w0, ne	// ne = any
    84ac:	17ffff2f 	b	8168 <fwp_write+0x788>
    84b0:	aa1403e0 	mov	x0, x20
    84b4:	d2800042 	mov	x2, #0x2                   	// #2
    84b8:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    84bc:	913d2021 	add	x1, x1, #0xf48
    84c0:	97ffec64 	bl	3650 <buf_put>
    84c4:	91004261 	add	x1, x19, #0x10
    84c8:	aa1403e0 	mov	x0, x20
    84cc:	f9402382 	ldr	x2, [x28, #64]
    84d0:	52800003 	mov	w3, #0x0                   	// #0
    84d4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    84d8:	97fffd42 	bl	79e0 <fwp_write>
    84dc:	17fffd9c 	b	7b4c <fwp_write+0x16c>
    84e0:	1e22c109 	fcvt	d9, s8
    84e4:	910123f5 	add	x21, sp, #0x48
    84e8:	52800033 	mov	w19, #0x1                   	// #1
    84ec:	d503201f 	nop
    84f0:	1e604120 	fmov	d0, d9
    84f4:	2a1303e1 	mov	w1, w19
    84f8:	aa1503e0 	mov	x0, x21
    84fc:	97ffecb1 	bl	37c0 <fwp_format_g.constprop.0>
    8500:	aa1503e0 	mov	x0, x21
    8504:	d2800001 	mov	x1, #0x0                   	// #0
    8508:	97ffe902 	bl	2910 <strtof@plt>
    850c:	1e202100 	fcmp	s8, s0
    8510:	54ffdb60 	b.eq	807c <fwp_write+0x69c>  // b.none
    8514:	11000673 	add	w19, w19, #0x1
    8518:	71002a7f 	cmp	w19, #0xa
    851c:	54fffea1 	b.ne	84f0 <fwp_write+0xb10>  // b.any
    8520:	1e604120 	fmov	d0, d9
    8524:	aa1503e0 	mov	x0, x21
    8528:	52800121 	mov	w1, #0x9                   	// #9
    852c:	97ffeca5 	bl	37c0 <fwp_format_g.constprop.0>
    8530:	17fffed3 	b	807c <fwp_write+0x69c>
    8534:	d37ef6a1 	lsl	x1, x21, #2
    8538:	b7f81563 	tbnz	x3, #63, 87e4 <fwp_write+0xe04>
    853c:	91002263 	add	x3, x19, #0x8
    8540:	8b010061 	add	x1, x3, x1
    8544:	b9400023 	ldr	w3, [x1]
    8548:	7100081f 	cmp	w0, #0x2
    854c:	2a0303e1 	mov	w1, w3
    8550:	93407c63 	sxtw	x3, w3
    8554:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8558:	17fffe5a 	b	7ec0 <fwp_write+0x4e0>
    855c:	d37ffaa1 	lsl	x1, x21, #1
    8560:	b7f81363 	tbnz	x3, #63, 87cc <fwp_write+0xdec>
    8564:	91002263 	add	x3, x19, #0x8
    8568:	8b010061 	add	x1, x3, x1
    856c:	79400021 	ldrh	w1, [x1]
    8570:	7100041f 	cmp	w0, #0x1
    8574:	93403c23 	sxth	x3, w1
    8578:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    857c:	17fffe51 	b	7ec0 <fwp_write+0x4e0>
    8580:	52800443 	mov	w3, #0x22                  	// #34
    8584:	91001ff5 	add	x21, sp, #0x7
    8588:	91002273 	add	x19, x19, #0x8
    858c:	aa1503e1 	mov	x1, x21
    8590:	aa1403e0 	mov	x0, x20
    8594:	d2800022 	mov	x2, #0x1                   	// #1
    8598:	39001fe3 	strb	w3, [sp, #7]
    859c:	f90143f7 	str	x23, [sp, #640]
    85a0:	8b160277 	add	x23, x19, x22
    85a4:	f90147f8 	str	x24, [sp, #648]
    85a8:	97ffec2a 	bl	3650 <buf_put>
    85ac:	b4000696 	cbz	x22, 867c <fwp_write+0xc9c>
    85b0:	b0000038 	adrp	x24, d000 <fwp_main_thread+0x42c>
    85b4:	913be318 	add	x24, x24, #0xef8
    85b8:	f9014bf9 	str	x25, [sp, #656]
    85bc:	b0000039 	adrp	x25, d000 <fwp_main_thread+0x42c>
    85c0:	913c6339 	add	x25, x25, #0xf18
    85c4:	f9014ffa 	str	x26, [sp, #664]
    85c8:	1400000d 	b	85fc <fwp_write+0xc1c>
    85cc:	710024bf 	cmp	w5, #0x9
    85d0:	54000460 	b.eq	865c <fwp_write+0xc7c>  // b.none
    85d4:	710028bf 	cmp	w5, #0xa
    85d8:	54000a61 	b.ne	8724 <fwp_write+0xd44>  // b.any
    85dc:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    85e0:	aa1403e0 	mov	x0, x20
    85e4:	913c2021 	add	x1, x1, #0xf08
    85e8:	d2800042 	mov	x2, #0x2                   	// #2
    85ec:	97ffec19 	bl	3650 <buf_put>
    85f0:	91000673 	add	x19, x19, #0x1
    85f4:	eb17027f 	cmp	x19, x23
    85f8:	540003e0 	b.eq	8674 <fwp_write+0xc94>  // b.none
    85fc:	39400265 	ldrb	w5, [x19]
    8600:	710034bf 	cmp	w5, #0xd
    8604:	54000180 	b.eq	8634 <fwp_write+0xc54>  // b.none
    8608:	54fffe29 	b.ls	85cc <fwp_write+0xbec>  // b.plast
    860c:	710088bf 	cmp	w5, #0x22
    8610:	540001c0 	b.eq	8648 <fwp_write+0xc68>  // b.none
    8614:	710170bf 	cmp	w5, #0x5c
    8618:	54000741 	b.ne	8700 <fwp_write+0xd20>  // b.any
    861c:	aa1403e0 	mov	x0, x20
    8620:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    8624:	d2800042 	mov	x2, #0x2                   	// #2
    8628:	913c0021 	add	x1, x1, #0xf00
    862c:	97ffec09 	bl	3650 <buf_put>
    8630:	17fffff0 	b	85f0 <fwp_write+0xc10>
    8634:	aa1903e1 	mov	x1, x25
    8638:	aa1403e0 	mov	x0, x20
    863c:	d2800042 	mov	x2, #0x2                   	// #2
    8640:	97ffec04 	bl	3650 <buf_put>
    8644:	17ffffeb 	b	85f0 <fwp_write+0xc10>
    8648:	aa1803e1 	mov	x1, x24
    864c:	aa1403e0 	mov	x0, x20
    8650:	d2800042 	mov	x2, #0x2                   	// #2
    8654:	97ffebff 	bl	3650 <buf_put>
    8658:	17ffffe6 	b	85f0 <fwp_write+0xc10>
    865c:	aa1403e0 	mov	x0, x20
    8660:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    8664:	d2800042 	mov	x2, #0x2                   	// #2
    8668:	913c4021 	add	x1, x1, #0xf10
    866c:	97ffebf9 	bl	3650 <buf_put>
    8670:	17ffffe0 	b	85f0 <fwp_write+0xc10>
    8674:	f9414bf9 	ldr	x25, [sp, #656]
    8678:	f9414ffa 	ldr	x26, [sp, #664]
    867c:	aa1503e1 	mov	x1, x21
    8680:	aa1403e0 	mov	x0, x20
    8684:	52800443 	mov	w3, #0x22                  	// #34
    8688:	17fffd9c 	b	7cf8 <fwp_write+0x318>
    868c:	7100103f 	cmp	w1, #0x4
    8690:	54ffeb21 	b.ne	83f4 <fwp_write+0xa14>  // b.any
    8694:	f94006e0 	ldr	x0, [x23, #8]
    8698:	d37ffc00 	lsr	x0, x0, #63
    869c:	17fffeb3 	b	8168 <fwp_write+0x788>
    86a0:	710002ff 	cmp	w23, #0x0
    86a4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    86a8:	17fffeb0 	b	8168 <fwp_write+0x788>
    86ac:	528005a1 	mov	w1, #0x2d                  	// #45
    86b0:	eb0203e2 	negs	x2, x2
    86b4:	da0303e3 	ngc	x3, x3
    86b8:	910127e0 	add	x0, sp, #0x49
    86bc:	910123f5 	add	x21, sp, #0x48
    86c0:	390123e1 	strb	w1, [sp, #72]
    86c4:	97ffe9c7 	bl	2de0 <fwp_fmt_u128>
    86c8:	17fffe18 	b	7f28 <fwp_write+0x548>
    86cc:	d37ceea1 	lsl	x1, x21, #4
    86d0:	b7f810a3 	tbnz	x3, #63, 88e4 <fwp_write+0xf04>
    86d4:	91002260 	add	x0, x19, #0x8
    86d8:	8b010001 	add	x1, x0, x1
    86dc:	17fffdf9 	b	7ec0 <fwp_write+0x4e0>
    86e0:	f9400a61 	ldr	x1, [x19, #16]
    86e4:	8b010000 	add	x0, x0, x1
    86e8:	f9400001 	ldr	x1, [x0]
    86ec:	17fffdf5 	b	7ec0 <fwp_write+0x4e0>
    86f0:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    86f4:	d2800042 	mov	x2, #0x2                   	// #2
    86f8:	913a8021 	add	x1, x1, #0xea0
    86fc:	17fffed6 	b	8254 <fwp_write+0x874>
    8700:	7101fcbf 	cmp	w5, #0x7f
    8704:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8708:	540000e9 	b.ls	8724 <fwp_write+0xd44>  // b.plast
    870c:	aa1503e1 	mov	x1, x21
    8710:	aa1403e0 	mov	x0, x20
    8714:	d2800022 	mov	x2, #0x1                   	// #1
    8718:	39001fe5 	strb	w5, [sp, #7]
    871c:	97ffebcd 	bl	3650 <buf_put>
    8720:	17ffffb4 	b	85f0 <fwp_write+0xc10>
    8724:	d2800203 	mov	x3, #0x10                  	// #16
    8728:	b0000024 	adrp	x4, d000 <fwp_main_thread+0x42c>
    872c:	aa0303e1 	mov	x1, x3
    8730:	913c8084 	add	x4, x4, #0xf20
    8734:	910123f6 	add	x22, sp, #0x48
    8738:	52800042 	mov	w2, #0x2                   	// #2
    873c:	aa1603e0 	mov	x0, x22
    8740:	97ffe824 	bl	27d0 <__snprintf_chk@plt>
    8744:	aa1603e0 	mov	x0, x22
    8748:	97ffe7ea 	bl	26f0 <strlen@plt>
    874c:	aa1603e1 	mov	x1, x22
    8750:	aa0003e2 	mov	x2, x0
    8754:	aa1403e0 	mov	x0, x20
    8758:	97ffebbe 	bl	3650 <buf_put>
    875c:	17ffffa5 	b	85f0 <fwp_write+0xc10>
    8760:	1e604100 	fmov	d0, d8
    8764:	aa1503e0 	mov	x0, x21
    8768:	52800221 	mov	w1, #0x11                  	// #17
    876c:	97ffec15 	bl	37c0 <fwp_format_g.constprop.0>
    8770:	17fffe43 	b	807c <fwp_write+0x69c>
    8774:	b9401040 	ldr	w0, [x2, #16]
    8778:	350003c0 	cbnz	w0, 87f0 <fwp_write+0xe10>
    877c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8780:	f947f400 	ldr	x0, [x0, #4072]
    8784:	f94127e2 	ldr	x2, [sp, #584]
    8788:	f9400001 	ldr	x1, [x0]
    878c:	eb010042 	subs	x2, x2, x1
    8790:	d2800001 	mov	x1, #0x0                   	// #0
    8794:	54ffd721 	b.ne	8278 <fwp_write+0x898>  // b.any
    8798:	f9413bf5 	ldr	x21, [sp, #624]
    879c:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    87a0:	f9413ff6 	ldr	x22, [sp, #632]
    87a4:	aa1403e0 	mov	x0, x20
    87a8:	f94143f7 	ldr	x23, [sp, #640]
    87ac:	913dc021 	add	x1, x1, #0xf70
    87b0:	f94147f8 	ldr	x24, [sp, #648]
    87b4:	d2800042 	mov	x2, #0x2                   	// #2
    87b8:	17fffd0e 	b	7bf0 <fwp_write+0x210>
    87bc:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x42c>
    87c0:	d2800042 	mov	x2, #0x2                   	// #2
    87c4:	913aa021 	add	x1, x1, #0xea8
    87c8:	17fffea3 	b	8254 <fwp_write+0x874>
    87cc:	f9400a63 	ldr	x3, [x19, #16]
    87d0:	8b030021 	add	x1, x1, x3
    87d4:	17ffff66 	b	856c <fwp_write+0xb8c>
    87d8:	f9400a61 	ldr	x1, [x19, #16]
    87dc:	8b0102a1 	add	x1, x21, x1
    87e0:	17fffdb3 	b	7eac <fwp_write+0x4cc>
    87e4:	f9400a63 	ldr	x3, [x19, #16]
    87e8:	8b030021 	add	x1, x1, x3
    87ec:	17ffff56 	b	8544 <fwp_write+0xb64>
    87f0:	b9404840 	ldr	w0, [x2, #72]
    87f4:	91001ff5 	add	x21, sp, #0x7
    87f8:	34ffa360 	cbz	w0, 7c64 <fwp_write+0x284>
    87fc:	52800503 	mov	w3, #0x28                  	// #40
    8800:	aa1403e0 	mov	x0, x20
    8804:	aa1503e1 	mov	x1, x21
    8808:	d2800022 	mov	x2, #0x1                   	// #1
    880c:	39001fe3 	strb	w3, [sp, #7]
    8810:	97ffeb90 	bl	3650 <buf_put>
    8814:	b9401380 	ldr	w0, [x28, #16]
    8818:	52800038 	mov	w24, #0x1                   	// #1
    881c:	7100001f 	cmp	w0, #0x0
    8820:	54ffa36c 	b.gt	7c8c <fwp_write+0x2ac>
    8824:	17fffd32 	b	7cec <fwp_write+0x30c>
    8828:	f9014bf9 	str	x25, [sp, #656]
    882c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe340>
    8830:	f9014ffa 	str	x26, [sp, #664]
    8834:	f9400676 	ldr	x22, [x19, #8]
    8838:	910ae333 	add	x19, x25, #0x2b8
    883c:	91002273 	add	x19, x19, #0x8
    8840:	937ffed8 	asr	x24, x22, #63
    8844:	aa1802c0 	orr	x0, x22, x24
    8848:	b5000320 	cbnz	x0, 88ac <fwp_write+0xecc>
    884c:	110006b5 	add	w21, w21, #0x1
    8850:	710016bf 	cmp	w21, #0x5
    8854:	54ffffc1 	b.ne	884c <fwp_write+0xe6c>  // b.any
    8858:	b7f80578 	tbnz	x24, #63, 8904 <fwp_write+0xf24>
    885c:	910023f3 	add	x19, sp, #0x8
    8860:	aa1603e2 	mov	x2, x22
    8864:	aa1303e0 	mov	x0, x19
    8868:	d2800003 	mov	x3, #0x0                   	// #0
    886c:	97ffe95d 	bl	2de0 <fwp_fmt_u128>
    8870:	910123f5 	add	x21, sp, #0x48
    8874:	b0000023 	adrp	x3, d000 <fwp_main_thread+0x42c>
    8878:	aa1303e4 	mov	x4, x19
    887c:	aa1503e0 	mov	x0, x21
    8880:	913da063 	add	x3, x3, #0xf68
    8884:	d2804002 	mov	x2, #0x200                 	// #512
    8888:	52800041 	mov	w1, #0x2                   	// #2
    888c:	97ffe79d 	bl	2700 <__sprintf_chk@plt>
    8890:	aa1503e0 	mov	x0, x21
    8894:	97ffe797 	bl	26f0 <strlen@plt>
    8898:	aa1503e1 	mov	x1, x21
    889c:	aa0003e2 	mov	x2, x0
    88a0:	aa1403e0 	mov	x0, x20
    88a4:	97ffeb6b 	bl	3650 <buf_put>
    88a8:	17fffe47 	b	81c4 <fwp_write+0x7e4>
    88ac:	f9400277 	ldr	x23, [x19]
    88b0:	aa1603e0 	mov	x0, x22
    88b4:	aa1803e1 	mov	x1, x24
    88b8:	aa1703e2 	mov	x2, x23
    88bc:	937ffefa 	asr	x26, x23, #63
    88c0:	aa1a03e3 	mov	x3, x26
    88c4:	94001307 	bl	d4e0 <__modti3>
    88c8:	aa010000 	orr	x0, x0, x1
    88cc:	b40002c0 	cbz	x0, 8924 <fwp_write+0xf44>
    88d0:	110006b5 	add	w21, w21, #0x1
    88d4:	91004273 	add	x19, x19, #0x10
    88d8:	710016bf 	cmp	w21, #0x5
    88dc:	54fffe81 	b.ne	88ac <fwp_write+0xecc>  // b.any
    88e0:	17ffffde 	b	8858 <fwp_write+0xe78>
    88e4:	f9400a60 	ldr	x0, [x19, #16]
    88e8:	8b000021 	add	x1, x1, x0
    88ec:	17fffd75 	b	7ec0 <fwp_write+0x4e0>
    88f0:	528c29c0 	mov	w0, #0x614e                	// #24910
    88f4:	910123f5 	add	x21, sp, #0x48
    88f8:	72a009c0 	movk	w0, #0x4e, lsl #16
    88fc:	b9004be0 	str	w0, [sp, #72]
    8900:	17fffda2 	b	7f88 <fwp_write+0x5a8>
    8904:	528005a1 	mov	w1, #0x2d                  	// #45
    8908:	eb1603e2 	negs	x2, x22
    890c:	da1803e3 	ngc	x3, x24
    8910:	910027e0 	add	x0, sp, #0x9
    8914:	910023f3 	add	x19, sp, #0x8
    8918:	390023e1 	strb	w1, [sp, #8]
    891c:	97ffe931 	bl	2de0 <fwp_fmt_u128>
    8920:	17ffffd4 	b	8870 <fwp_write+0xe90>
    8924:	aa1703e2 	mov	x2, x23
    8928:	aa1a03e3 	mov	x3, x26
    892c:	aa1603e0 	mov	x0, x22
    8930:	aa1803e1 	mov	x1, x24
    8934:	9400120b 	bl	d160 <__divti3>
    8938:	aa0003e2 	mov	x2, x0
    893c:	aa0103e3 	mov	x3, x1
    8940:	b7f80201 	tbnz	x1, #63, 8980 <fwp_write+0xfa0>
    8944:	910023f3 	add	x19, sp, #0x8
    8948:	aa1303e0 	mov	x0, x19
    894c:	97ffe925 	bl	2de0 <fwp_fmt_u128>
    8950:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8954:	910ae339 	add	x25, x25, #0x2b8
    8958:	910123f5 	add	x21, sp, #0x48
    895c:	aa1303e4 	mov	x4, x19
    8960:	aa1503e0 	mov	x0, x21
    8964:	b0000023 	adrp	x3, d000 <fwp_main_thread+0x42c>
    8968:	f8616b25 	ldr	x5, [x25, x1]
    896c:	913d8063 	add	x3, x3, #0xf60
    8970:	d2804002 	mov	x2, #0x200                 	// #512
    8974:	52800041 	mov	w1, #0x2                   	// #2
    8978:	97ffe762 	bl	2700 <__sprintf_chk@plt>
    897c:	17ffffc5 	b	8890 <fwp_write+0xeb0>
    8980:	528005a4 	mov	w4, #0x2d                  	// #45
    8984:	eb0003e2 	negs	x2, x0
    8988:	da0103e3 	ngc	x3, x1
    898c:	910027e0 	add	x0, sp, #0x9
    8990:	910023f3 	add	x19, sp, #0x8
    8994:	390023e4 	strb	w4, [sp, #8]
    8998:	97ffe912 	bl	2de0 <fwp_fmt_u128>
    899c:	17ffffed 	b	8950 <fwp_write+0xf70>
    89a0:	f9013bf5 	str	x21, [sp, #624]
    89a4:	f9013ff6 	str	x22, [sp, #632]
    89a8:	f90143f7 	str	x23, [sp, #640]
    89ac:	f90147f8 	str	x24, [sp, #648]
    89b0:	f9014bf9 	str	x25, [sp, #656]
    89b4:	f9014ffa 	str	x26, [sp, #664]
    89b8:	f90153fb 	str	x27, [sp, #672]
    89bc:	f90157fc 	str	x28, [sp, #680]
    89c0:	fd015be8 	str	d8, [sp, #688]
    89c4:	fd015fe9 	str	d9, [sp, #696]
    89c8:	97ffe7a6 	bl	2860 <__stack_chk_fail@plt>
    89cc:	d503201f 	nop

00000000000089d0 <fwp_hof0.constprop.0>:
    89d0:	d105c3ff 	sub	sp, sp, #0x170
    89d4:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    89d8:	f947f442 	ldr	x2, [x2, #4072]
    89dc:	a9117bfd 	stp	x29, x30, [sp, #272]
    89e0:	910443fd 	add	x29, sp, #0x110
    89e4:	a91673fb 	stp	x27, x28, [sp, #352]
    89e8:	aa0003fc 	mov	x28, x0
    89ec:	f9400040 	ldr	x0, [x2]
    89f0:	f90087e0 	str	x0, [sp, #264]
    89f4:	d2800000 	mov	x0, #0x0                   	// #0
    89f8:	b4003801 	cbz	x1, 90f8 <fwp_hof0.constprop.0+0x728>
    89fc:	a91253f3 	stp	x19, x20, [sp, #288]
    8a00:	900000d3 	adrp	x19, 20000 <__data_start>
    8a04:	91004273 	add	x19, x19, #0x10
    8a08:	910263e0 	add	x0, sp, #0x98
    8a0c:	900000d4 	adrp	x20, 20000 <__data_start>
    8a10:	91008273 	add	x19, x19, #0x20
    8a14:	aa1c03fb 	mov	x27, x28
    8a18:	a9135bf5 	stp	x21, x22, [sp, #304]
    8a1c:	b0000396 	adrp	x22, 79000 <fwp_root_context+0xbc0>
    8a20:	a91463f7 	stp	x23, x24, [sp, #320]
    8a24:	91014297 	add	x23, x20, #0x50
    8a28:	d0fffff8 	adrp	x24, 6000 <fwp_owned_entry173+0x30>
    8a2c:	a9156bf9 	stp	x25, x26, [sp, #336]
    8a30:	911882d9 	add	x25, x22, #0x620
    8a34:	f90007e0 	str	x0, [sp, #8]
    8a38:	910283e0 	add	x0, sp, #0xa0
    8a3c:	f9000be0 	str	x0, [sp, #16]
    8a40:	f90013e1 	str	x1, [sp, #32]
    8a44:	f949ef24 	ldr	x4, [x25, #5080]
    8a48:	f949db21 	ldr	x1, [x25, #5040]
    8a4c:	d370bc84 	lsl	x4, x4, #16
    8a50:	cb010363 	sub	x3, x27, x1
    8a54:	eb04007f 	cmp	x3, x4
    8a58:	54000442 	b.cs	8ae0 <fwp_hof0.constprop.0+0x110>  // b.hs, b.nlast
    8a5c:	d350fc60 	lsr	x0, x3, #16
    8a60:	f949ff26 	ldr	x6, [x25, #5112]
    8a64:	8b000800 	add	x0, x0, x0, lsl #2
    8a68:	d37df002 	lsl	x2, x0, #3
    8a6c:	8b0200c5 	add	x5, x6, x2
    8a70:	f94010a0 	ldr	x0, [x5, #32]
    8a74:	b4000360 	cbz	x0, 8ae0 <fwp_hof0.constprop.0+0x110>
    8a78:	386268c2 	ldrb	w2, [x6, x2]
    8a7c:	7100085f 	cmp	w2, #0x2
    8a80:	54000e80 	b.eq	8c50 <fwp_hof0.constprop.0+0x280>  // b.none
    8a84:	7100045f 	cmp	w2, #0x1
    8a88:	540002c1 	b.ne	8ae0 <fwp_hof0.constprop.0+0x110>  // b.any
    8a8c:	92403c62 	and	x2, x3, #0xffff
    8a90:	29430ca6 	ldp	w6, w3, [x5, #24]
    8a94:	9b067c42 	mul	x2, x2, x6
    8a98:	d360fc42 	lsr	x2, x2, #32
    8a9c:	eb03005f 	cmp	x2, x3
    8aa0:	54000202 	b.cs	8ae0 <fwp_hof0.constprop.0+0x110>  // b.hs, b.nlast
    8aa4:	8b020000 	add	x0, x0, x2
    8aa8:	39400002 	ldrb	w2, [x0]
    8aac:	340001a2 	cbz	w2, 8ae0 <fwp_hof0.constprop.0+0x110>
    8ab0:	91014281 	add	x1, x20, #0x50
    8ab4:	b9412023 	ldr	w3, [x1, #288]
    8ab8:	35002103 	cbnz	w3, 8ed8 <fwp_hof0.constprop.0+0x508>
    8abc:	7103f45f 	cmp	w2, #0xfd
    8ac0:	54005068 	b.hi	94cc <fwp_hof0.constprop.0+0xafc>  // b.pmore
    8ac4:	911882c1 	add	x1, x22, #0x620
    8ac8:	11000442 	add	w2, w2, #0x1
    8acc:	39000002 	strb	w2, [x0]
    8ad0:	aa0103e0 	mov	x0, x1
    8ad4:	f949d821 	ldr	x1, [x1, #5040]
    8ad8:	f949ec04 	ldr	x4, [x0, #5080]
    8adc:	d370bc84 	lsl	x4, x4, #16
    8ae0:	9122431a 	add	x26, x24, #0x890
    8ae4:	a902e7fb 	stp	x27, x25, [sp, #40]
    8ae8:	aa1a03f5 	mov	x21, x26
    8aec:	aa1b03f9 	mov	x25, x27
    8af0:	aa1703fb 	mov	x27, x23
    8af4:	d28018c0 	mov	x0, #0xc6                  	// #198
    8af8:	b2407bfc 	mov	x28, #0x7fffffff            	// #2147483647
    8afc:	f9000fe0 	str	x0, [sp, #24]
    8b00:	f941c360 	ldr	x0, [x27, #896]
    8b04:	a90a57e0 	stp	x0, x21, [sp, #160]
    8b08:	12800002 	mov	w2, #0xffffffff            	// #-1
    8b0c:	f94007e0 	ldr	x0, [sp, #8]
    8b10:	f9005be0 	str	x0, [sp, #176]
    8b14:	f9400be0 	ldr	x0, [sp, #16]
    8b18:	cb010261 	sub	x1, x19, x1
    8b1c:	b9009be2 	str	w2, [sp, #152]
    8b20:	f901c360 	str	x0, [x27, #896]
    8b24:	eb04003f 	cmp	x1, x4
    8b28:	540007c2 	b.cs	8c20 <fwp_hof0.constprop.0+0x250>  // b.hs, b.nlast
    8b2c:	911882c2 	add	x2, x22, #0x620
    8b30:	d350fc20 	lsr	x0, x1, #16
    8b34:	8b000800 	add	x0, x0, x0, lsl #2
    8b38:	f949fc43 	ldr	x3, [x2, #5112]
    8b3c:	d37df000 	lsl	x0, x0, #3
    8b40:	8b000062 	add	x2, x3, x0
    8b44:	f9401057 	ldr	x23, [x2, #32]
    8b48:	b40006d7 	cbz	x23, 8c20 <fwp_hof0.constprop.0+0x250>
    8b4c:	38606860 	ldrb	w0, [x3, x0]
    8b50:	7100081f 	cmp	w0, #0x2
    8b54:	54000840 	b.eq	8c5c <fwp_hof0.constprop.0+0x28c>  // b.none
    8b58:	7100041f 	cmp	w0, #0x1
    8b5c:	54000621 	b.ne	8c20 <fwp_hof0.constprop.0+0x250>  // b.any
    8b60:	29430c44 	ldp	w4, w3, [x2, #24]
    8b64:	92403c20 	and	x0, x1, #0xffff
    8b68:	9b047c00 	mul	x0, x0, x4
    8b6c:	d360fc00 	lsr	x0, x0, #32
    8b70:	eb03001f 	cmp	x0, x3
    8b74:	540002e2 	b.cs	8bd0 <fwp_hof0.constprop.0+0x200>  // b.hs, b.nlast
    8b78:	8b0002e0 	add	x0, x23, x0
    8b7c:	39400003 	ldrb	w3, [x0]
    8b80:	34000283 	cbz	w3, 8bd0 <fwp_hof0.constprop.0+0x200>
    8b84:	91014281 	add	x1, x20, #0x50
    8b88:	b9412022 	ldr	w2, [x1, #288]
    8b8c:	35001ae2 	cbnz	w2, 8ee8 <fwp_hof0.constprop.0+0x518>
    8b90:	7103f47f 	cmp	w3, #0xfd
    8b94:	54004a88 	b.hi	94e4 <fwp_hof0.constprop.0+0xb14>  // b.pmore
    8b98:	11000463 	add	w3, w3, #0x1
    8b9c:	39000003 	strb	w3, [x0]
    8ba0:	911882c0 	add	x0, x22, #0x620
    8ba4:	f949d801 	ldr	x1, [x0, #5040]
    8ba8:	f949ec02 	ldr	x2, [x0, #5080]
    8bac:	cb010261 	sub	x1, x19, x1
    8bb0:	eb02403f 	cmp	x1, x2, lsl #16
    8bb4:	54000362 	b.cs	8c20 <fwp_hof0.constprop.0+0x250>  // b.hs, b.nlast
    8bb8:	f949fc00 	ldr	x0, [x0, #5112]
    8bbc:	d350fc22 	lsr	x2, x1, #16
    8bc0:	8b020842 	add	x2, x2, x2, lsl #2
    8bc4:	8b020c02 	add	x2, x0, x2, lsl #3
    8bc8:	f9401057 	ldr	x23, [x2, #32]
    8bcc:	b40002b7 	cbz	x23, 8c20 <fwp_hof0.constprop.0+0x250>
    8bd0:	39400040 	ldrb	w0, [x2]
    8bd4:	7100081f 	cmp	w0, #0x2
    8bd8:	54000600 	b.eq	8c98 <fwp_hof0.constprop.0+0x2c8>  // b.none
    8bdc:	7100041f 	cmp	w0, #0x1
    8be0:	54000201 	b.ne	8c20 <fwp_hof0.constprop.0+0x250>  // b.any
    8be4:	29430043 	ldp	w3, w0, [x2, #24]
    8be8:	92403c21 	and	x1, x1, #0xffff
    8bec:	9b037c21 	mul	x1, x1, x3
    8bf0:	d360fc21 	lsr	x1, x1, #32
    8bf4:	eb00003f 	cmp	x1, x0
    8bf8:	54000142 	b.cs	8c20 <fwp_hof0.constprop.0+0x250>  // b.hs, b.nlast
    8bfc:	8b0102f7 	add	x23, x23, x1
    8c00:	394002e1 	ldrb	w1, [x23]
    8c04:	340000e1 	cbz	w1, 8c20 <fwp_hof0.constprop.0+0x250>
    8c08:	7100043f 	cmp	w1, #0x1
    8c0c:	54000300 	b.eq	8c6c <fwp_hof0.constprop.0+0x29c>  // b.none
    8c10:	7103fc3f 	cmp	w1, #0xff
    8c14:	540046c0 	b.eq	94ec <fwp_hof0.constprop.0+0xb1c>  // b.none
    8c18:	51000421 	sub	w1, w1, #0x1
    8c1c:	390002e1 	strb	w1, [x23]
    8c20:	b4003b79 	cbz	x25, 938c <fwp_hof0.constprop.0+0x9bc>
    8c24:	aa1903e0 	mov	x0, x25
    8c28:	d2800001 	mov	x1, #0x0                   	// #0
    8c2c:	d503201f 	nop
    8c30:	f9400800 	ldr	x0, [x0, #16]
    8c34:	91000421 	add	x1, x1, #0x1
    8c38:	b5ffffc0 	cbnz	x0, 8c30 <fwp_hof0.constprop.0+0x260>
    8c3c:	eb1c003f 	cmp	x1, x28
    8c40:	54000329 	b.ls	8ca4 <fwp_hof0.constprop.0+0x2d4>  // b.plast
    8c44:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    8c48:	913e0000 	add	x0, x0, #0xf80
    8c4c:	97ffeda6 	bl	42e4 <fwp_trap>
    8c50:	72003c7f 	tst	w3, #0xffff
    8c54:	54fff461 	b.ne	8ae0 <fwp_hof0.constprop.0+0x110>  // b.any
    8c58:	17ffff94 	b	8aa8 <fwp_hof0.constprop.0+0xd8>
    8c5c:	72003c3f 	tst	w1, #0xffff
    8c60:	54fffb81 	b.ne	8bd0 <fwp_hof0.constprop.0+0x200>  // b.any
    8c64:	aa1703e0 	mov	x0, x23
    8c68:	17ffffc5 	b	8b7c <fwp_hof0.constprop.0+0x1ac>
    8c6c:	d53bd040 	mrs	x0, tpidr_el0
    8c70:	91400000 	add	x0, x0, #0x0, lsl #12
    8c74:	91004000 	add	x0, x0, #0x10
    8c78:	f9400000 	ldr	x0, [x0]
    8c7c:	b4000080 	cbz	x0, 8c8c <fwp_hof0.constprop.0+0x2bc>
    8c80:	aa1303e1 	mov	x1, x19
    8c84:	97ffef13 	bl	48d0 <fwp_closure_drop_push>
    8c88:	17ffffe6 	b	8c20 <fwp_hof0.constprop.0+0x250>
    8c8c:	aa1303e0 	mov	x0, x19
    8c90:	97ffef55 	bl	49e4 <fwp_closure_drop.part.0>
    8c94:	17ffffe3 	b	8c20 <fwp_hof0.constprop.0+0x250>
    8c98:	72003c3f 	tst	w1, #0xffff
    8c9c:	54fffc21 	b.ne	8c20 <fwp_hof0.constprop.0+0x250>  // b.any
    8ca0:	17ffffd8 	b	8c00 <fwp_hof0.constprop.0+0x230>
    8ca4:	aa0103fa 	mov	x26, x1
    8ca8:	91014297 	add	x23, x20, #0x50
    8cac:	b943b6e0 	ldr	w0, [x23, #948]
    8cb0:	340023c0 	cbz	w0, 9128 <fwp_hof0.constprop.0+0x758>
    8cb4:	91014281 	add	x1, x20, #0x50
    8cb8:	f9408823 	ldr	x3, [x1, #272]
    8cbc:	f940a837 	ldr	x23, [x1, #336]
    8cc0:	eb17007f 	cmp	x3, x23
    8cc4:	5400072d 	b.le	8da8 <fwp_hof0.constprop.0+0x3d8>
    8cc8:	8b1706e0 	add	x0, x23, x23, lsl #1
    8ccc:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8cd0:	f9404421 	ldr	x1, [x1, #136]
    8cd4:	d37ef400 	lsl	x0, x0, #2
    8cd8:	cb170000 	sub	x0, x0, x23
    8cdc:	8b000c20 	add	x0, x1, x0, lsl #3
    8ce0:	b9400401 	ldr	w1, [x0, #4]
    8ce4:	35000081 	cbnz	w1, 8cf4 <fwp_hof0.constprop.0+0x324>
    8ce8:	b9400001 	ldr	w1, [x0]
    8cec:	6b02003f 	cmp	w1, w2
    8cf0:	540005c9 	b.ls	8da8 <fwp_hof0.constprop.0+0x3d8>  // b.plast
    8cf4:	910006f7 	add	x23, x23, #0x1
    8cf8:	91016000 	add	x0, x0, #0x58
    8cfc:	eb17007f 	cmp	x3, x23
    8d00:	54ffff01 	b.ne	8ce0 <fwp_hof0.constprop.0+0x310>  // b.any
    8d04:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8d08:	eb00007f 	cmp	x3, x0
    8d0c:	54003dac 	b.gt	94c0 <fwp_hof0.constprop.0+0xaf0>
    8d10:	91014280 	add	x0, x20, #0x50
    8d14:	f9408001 	ldr	x1, [x0, #256]
    8d18:	f9404407 	ldr	x7, [x0, #136]
    8d1c:	eb03003f 	cmp	x1, x3
    8d20:	54000281 	b.ne	8d70 <fwp_hof0.constprop.0+0x3a0>  // b.any
    8d24:	b4004783 	cbz	x3, 9614 <fwp_hof0.constprop.0+0xc44>
    8d28:	d37ff877 	lsl	x23, x3, #1
    8d2c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8d30:	eb0002ff 	cmp	x23, x0
    8d34:	9a80d2f7 	csel	x23, x23, x0, le
    8d38:	8b1706e1 	add	x1, x23, x23, lsl #1
    8d3c:	d37ef421 	lsl	x1, x1, #2
    8d40:	cb170021 	sub	x1, x1, x23
    8d44:	d37df021 	lsl	x1, x1, #3
    8d48:	aa0703e0 	mov	x0, x7
    8d4c:	52800002 	mov	w2, #0x0                   	// #0
    8d50:	f9001fe3 	str	x3, [sp, #56]
    8d54:	97ffeccb 	bl	4080 <ad_raw_realloc>
    8d58:	f9401fe3 	ldr	x3, [sp, #56]
    8d5c:	aa0003e7 	mov	x7, x0
    8d60:	b4006d40 	cbz	x0, 9b08 <fwp_hof0.constprop.0+0x1138>
    8d64:	91014280 	add	x0, x20, #0x50
    8d68:	f9004407 	str	x7, [x0, #136]
    8d6c:	f9008017 	str	x23, [x0, #256]
    8d70:	8b030460 	add	x0, x3, x3, lsl #1
    8d74:	91014282 	add	x2, x20, #0x50
    8d78:	4f000400 	movi	v0.4s, #0x0
    8d7c:	91000461 	add	x1, x3, #0x1
    8d80:	d37ef400 	lsl	x0, x0, #2
    8d84:	aa0303f7 	mov	x23, x3
    8d88:	cb030000 	sub	x0, x0, x3
    8d8c:	f9008841 	str	x1, [x2, #272]
    8d90:	8b000ce0 	add	x0, x7, x0, lsl #3
    8d94:	ad000000 	stp	q0, q0, [x0]
    8d98:	ad010000 	stp	q0, q0, [x0, #32]
    8d9c:	3d801000 	str	q0, [x0, #64]
    8da0:	f900281f 	str	xzr, [x0, #80]
    8da4:	14000005 	b	8db8 <fwp_hof0.constprop.0+0x3e8>
    8da8:	eb17007f 	cmp	x3, x23
    8dac:	54fffac0 	b.eq	8d04 <fwp_hof0.constprop.0+0x334>  // b.none
    8db0:	91014280 	add	x0, x20, #0x50
    8db4:	f9404407 	ldr	x7, [x0, #136]
    8db8:	8b1706e1 	add	x1, x23, x23, lsl #1
    8dbc:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    8dc0:	912d8000 	add	x0, x0, #0xb60
    8dc4:	d37ef422 	lsl	x2, x1, #2
    8dc8:	f9002be7 	str	x7, [sp, #80]
    8dcc:	cb170042 	sub	x2, x2, x23
    8dd0:	8b020ce2 	add	x2, x7, x2, lsl #3
    8dd4:	f9001fe2 	str	x2, [sp, #56]
    8dd8:	f900285f 	str	xzr, [x2, #80]
    8ddc:	97ffe705 	bl	29f0 <getenv@plt>
    8de0:	f9401fe2 	ldr	x2, [sp, #56]
    8de4:	f9402be7 	ldr	x7, [sp, #80]
    8de8:	b4000080 	cbz	x0, 8df8 <fwp_hof0.constprop.0+0x428>
    8dec:	39400001 	ldrb	w1, [x0]
    8df0:	7100c03f 	cmp	w1, #0x30
    8df4:	54000820 	b.eq	8ef8 <fwp_hof0.constprop.0+0x528>  // b.none
    8df8:	91014280 	add	x0, x20, #0x50
    8dfc:	f9407c01 	ldr	x1, [x0, #248]
    8e00:	b5003461 	cbnz	x1, 948c <fwp_hof0.constprop.0+0xabc>
    8e04:	91014280 	add	x0, x20, #0x50
    8e08:	2f000400 	mvni	v0.2s, #0x0
    8e0c:	b9400048 	ldr	w8, [x2]
    8e10:	910006e9 	add	x9, x23, #0x1
    8e14:	52800023 	mov	w3, #0x1                   	// #1
    8e18:	a900e85a 	stp	x26, x26, [x2, #8]
    8e1c:	11000508 	add	w8, w8, #0x1
    8e20:	f941c001 	ldr	x1, [x0, #896]
    8e24:	29000c48 	stp	w8, w3, [x2]
    8e28:	f900205f 	str	xzr, [x2, #64]
    8e2c:	f900a809 	str	x9, [x0, #336]
    8e30:	fd002440 	str	d0, [x2, #72]
    8e34:	b4003261 	cbz	x1, 9480 <fwp_hof0.constprop.0+0xab0>
    8e38:	91224304 	add	x4, x24, #0x890
    8e3c:	14000003 	b	8e48 <fwp_hof0.constprop.0+0x478>
    8e40:	f9400021 	ldr	x1, [x1]
    8e44:	b40031e1 	cbz	x1, 9480 <fwp_hof0.constprop.0+0xab0>
    8e48:	f9400420 	ldr	x0, [x1, #8]
    8e4c:	eb04001f 	cmp	x0, x4
    8e50:	54ffff81 	b.ne	8e40 <fwp_hof0.constprop.0+0x470>  // b.any
    8e54:	f9400820 	ldr	x0, [x1, #16]
    8e58:	2a1703e3 	mov	w3, w23
    8e5c:	b9400001 	ldr	w1, [x0]
    8e60:	f9002040 	str	x0, [x2, #64]
    8e64:	b9004c41 	str	w1, [x2, #76]
    8e68:	37f80081 	tbnz	w1, #31, 8e78 <fwp_hof0.constprop.0+0x4a8>
    8e6c:	52800b02 	mov	w2, #0x58                  	// #88
    8e70:	9b221c21 	smaddl	x1, w1, w2, x7
    8e74:	b9004837 	str	w23, [x1, #72]
    8e78:	b9000003 	str	w3, [x0]
    8e7c:	d2800002 	mov	x2, #0x0                   	// #0
    8e80:	aa1903e0 	mov	x0, x25
    8e84:	b4001619 	cbz	x25, 9144 <fwp_hof0.constprop.0+0x774>
    8e88:	f9400800 	ldr	x0, [x0, #16]
    8e8c:	91000442 	add	x2, x2, #0x1
    8e90:	b5ffffc0 	cbnz	x0, 8e88 <fwp_hof0.constprop.0+0x4b8>
    8e94:	aa1903e1 	mov	x1, x25
    8e98:	f9400821 	ldr	x1, [x1, #16]
    8e9c:	91000400 	add	x0, x0, #0x1
    8ea0:	b5ffffc1 	cbnz	x1, 8e98 <fwp_hof0.constprop.0+0x4c8>
    8ea4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8ea8:	eb01001f 	cmp	x0, x1
    8eac:	54000108 	b.hi	8ecc <fwp_hof0.constprop.0+0x4fc>  // b.pmore
    8eb0:	f100005f 	cmp	x2, #0x0
    8eb4:	5400148d 	b.le	9144 <fwp_hof0.constprop.0+0x774>
    8eb8:	eb00005f 	cmp	x2, x0
    8ebc:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8ec0:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8ec4:	eb0102ff 	cmp	x23, x1
    8ec8:	54002669 	b.ls	9394 <fwp_hof0.constprop.0+0x9c4>  // b.plast
    8ecc:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    8ed0:	913a0000 	add	x0, x0, #0xe80
    8ed4:	97ffed04 	bl	42e4 <fwp_trap>
    8ed8:	f940a423 	ldr	x3, [x1, #328]
    8edc:	91000463 	add	x3, x3, #0x1
    8ee0:	f900a423 	str	x3, [x1, #328]
    8ee4:	17fffef6 	b	8abc <fwp_hof0.constprop.0+0xec>
    8ee8:	f940a422 	ldr	x2, [x1, #328]
    8eec:	91000442 	add	x2, x2, #0x1
    8ef0:	f900a422 	str	x2, [x1, #328]
    8ef4:	17ffff27 	b	8b90 <fwp_hof0.constprop.0+0x1c0>
    8ef8:	39400400 	ldrb	w0, [x0, #1]
    8efc:	34fff840 	cbz	w0, 8e04 <fwp_hof0.constprop.0+0x434>
    8f00:	17ffffbe 	b	8df8 <fwp_hof0.constprop.0+0x428>
    8f04:	f9401fe6 	ldr	x6, [sp, #56]
    8f08:	d00000a1 	adrp	x1, 1e000 <__FRAME_END__+0xe340>
    8f0c:	910ae021 	add	x1, x1, #0x2b8
    8f10:	52800023 	mov	w3, #0x1                   	// #1
    8f14:	91014022 	add	x2, x1, #0x50
    8f18:	aa0603e0 	mov	x0, x6
    8f1c:	aa1903e1 	mov	x1, x25
    8f20:	aa1903f5 	mov	x21, x25
    8f24:	aa1b03f7 	mov	x23, x27
    8f28:	a90d7fff 	stp	xzr, xzr, [sp, #208]
    8f2c:	a942e7fb 	ldp	x27, x25, [sp, #40]
    8f30:	f90073ff 	str	xzr, [sp, #224]
    8f34:	97fffaab 	bl	79e0 <fwp_write>
    8f38:	a94d0be3 	ldp	x3, x2, [sp, #208]
    8f3c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    8f40:	91230000 	add	x0, x0, #0x8c0
    8f44:	f100007f 	cmp	x3, #0x0
    8f48:	9a830003 	csel	x3, x0, x3, eq	// eq = none
    8f4c:	b100285f 	cmn	x2, #0xa
    8f50:	54008e48 	b.hi	a118 <fwp_hof0.constprop.0+0x1748>  // b.pmore
    8f54:	91002440 	add	x0, x2, #0x9
    8f58:	52800021 	mov	w1, #0x1                   	// #1
    8f5c:	f9000fe2 	str	x2, [sp, #24]
    8f60:	f90017e3 	str	x3, [sp, #40]
    8f64:	97fff057 	bl	50c0 <fwp_heap_alloc>
    8f68:	f94017e3 	ldr	x3, [sp, #40]
    8f6c:	aa0003fa 	mov	x26, x0
    8f70:	f9400fe2 	ldr	x2, [sp, #24]
    8f74:	aa0303e1 	mov	x1, x3
    8f78:	aa0003e3 	mov	x3, x0
    8f7c:	f90017e2 	str	x2, [sp, #40]
    8f80:	f8008462 	str	x2, [x3], #8
    8f84:	aa0303e0 	mov	x0, x3
    8f88:	f9000fe3 	str	x3, [sp, #24]
    8f8c:	97ffe5cd 	bl	26c0 <memcpy@plt>
    8f90:	f94017e2 	ldr	x2, [sp, #40]
    8f94:	8b020342 	add	x2, x26, x2
    8f98:	3900205f 	strb	wzr, [x2, #8]
    8f9c:	f9406be0 	ldr	x0, [sp, #208]
    8fa0:	97ffe660 	bl	2920 <free@plt>
    8fa4:	911882c2 	add	x2, x22, #0x620
    8fa8:	f9400fe3 	ldr	x3, [sp, #24]
    8fac:	f949d841 	ldr	x1, [x2, #5040]
    8fb0:	f949ec40 	ldr	x0, [x2, #5080]
    8fb4:	cb010341 	sub	x1, x26, x1
    8fb8:	eb00403f 	cmp	x1, x0, lsl #16
    8fbc:	54000322 	b.cs	9020 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    8fc0:	d350fc20 	lsr	x0, x1, #16
    8fc4:	f949fc45 	ldr	x5, [x2, #5112]
    8fc8:	8b000800 	add	x0, x0, x0, lsl #2
    8fcc:	d37df002 	lsl	x2, x0, #3
    8fd0:	8b0200a4 	add	x4, x5, x2
    8fd4:	f9401080 	ldr	x0, [x4, #32]
    8fd8:	b4000240 	cbz	x0, 9020 <fwp_hof0.constprop.0+0x650>
    8fdc:	386268a2 	ldrb	w2, [x5, x2]
    8fe0:	7100085f 	cmp	w2, #0x2
    8fe4:	54008ac0 	b.eq	a13c <fwp_hof0.constprop.0+0x176c>  // b.none
    8fe8:	7100045f 	cmp	w2, #0x1
    8fec:	540001a1 	b.ne	9020 <fwp_hof0.constprop.0+0x650>  // b.any
    8ff0:	29430885 	ldp	w5, w2, [x4, #24]
    8ff4:	92403c21 	and	x1, x1, #0xffff
    8ff8:	9b057c21 	mul	x1, x1, x5
    8ffc:	d360fc21 	lsr	x1, x1, #32
    9000:	eb02003f 	cmp	x1, x2
    9004:	540000e2 	b.cs	9020 <fwp_hof0.constprop.0+0x650>  // b.hs, b.nlast
    9008:	8b010000 	add	x0, x0, x1
    900c:	39400001 	ldrb	w1, [x0]
    9010:	7103fc3f 	cmp	w1, #0xff
    9014:	540089a0 	b.eq	a148 <fwp_hof0.constprop.0+0x1778>  // b.none
    9018:	52800021 	mov	w1, #0x1                   	// #1
    901c:	39000001 	strb	w1, [x0]
    9020:	aa1503e0 	mov	x0, x21
    9024:	f9000fe3 	str	x3, [sp, #24]
    9028:	97fff476 	bl	6200 <fwp_drop0>
    902c:	91014295 	add	x21, x20, #0x50
    9030:	f9400fe3 	ldr	x3, [sp, #24]
    9034:	d2800021 	mov	x1, #0x1                   	// #1
    9038:	f9400342 	ldr	x2, [x26]
    903c:	aa0303e0 	mov	x0, x3
    9040:	f9404aa3 	ldr	x3, [x21, #144]
    9044:	97ffe647 	bl	2960 <fwrite@plt>
    9048:	f9404aa1 	ldr	x1, [x21, #144]
    904c:	52800140 	mov	w0, #0xa                   	// #10
    9050:	97ffe5cc 	bl	2780 <fputc@plt>
    9054:	911882c2 	add	x2, x22, #0x620
    9058:	f949d841 	ldr	x1, [x2, #5040]
    905c:	f949ec40 	ldr	x0, [x2, #5080]
    9060:	cb010341 	sub	x1, x26, x1
    9064:	eb00403f 	cmp	x1, x0, lsl #16
    9068:	54000382 	b.cs	90d8 <fwp_hof0.constprop.0+0x708>  // b.hs, b.nlast
    906c:	d350fc20 	lsr	x0, x1, #16
    9070:	f949fc44 	ldr	x4, [x2, #5112]
    9074:	8b000800 	add	x0, x0, x0, lsl #2
    9078:	d37df002 	lsl	x2, x0, #3
    907c:	8b020083 	add	x3, x4, x2
    9080:	f9401075 	ldr	x21, [x3, #32]
    9084:	b40002b5 	cbz	x21, 90d8 <fwp_hof0.constprop.0+0x708>
    9088:	38626882 	ldrb	w2, [x4, x2]
    908c:	7100085f 	cmp	w2, #0x2
    9090:	54008500 	b.eq	a130 <fwp_hof0.constprop.0+0x1760>  // b.none
    9094:	7100045f 	cmp	w2, #0x1
    9098:	54000201 	b.ne	90d8 <fwp_hof0.constprop.0+0x708>  // b.any
    909c:	29430062 	ldp	w2, w0, [x3, #24]
    90a0:	92403c21 	and	x1, x1, #0xffff
    90a4:	9b027c21 	mul	x1, x1, x2
    90a8:	d360fc21 	lsr	x1, x1, #32
    90ac:	eb00003f 	cmp	x1, x0
    90b0:	54000142 	b.cs	90d8 <fwp_hof0.constprop.0+0x708>  // b.hs, b.nlast
    90b4:	8b0102b5 	add	x21, x21, x1
    90b8:	394002a1 	ldrb	w1, [x21]
    90bc:	340000e1 	cbz	w1, 90d8 <fwp_hof0.constprop.0+0x708>
    90c0:	7100043f 	cmp	w1, #0x1
    90c4:	54008300 	b.eq	a124 <fwp_hof0.constprop.0+0x1754>  // b.none
    90c8:	7103fc3f 	cmp	w1, #0xff
    90cc:	540084a0 	b.eq	a160 <fwp_hof0.constprop.0+0x1790>  // b.none
    90d0:	51000421 	sub	w1, w1, #0x1
    90d4:	390002a1 	strb	w1, [x21]
    90d8:	f94013e0 	ldr	x0, [sp, #32]
    90dc:	f9400800 	ldr	x0, [x0, #16]
    90e0:	f90013e0 	str	x0, [sp, #32]
    90e4:	b5ffcb00 	cbnz	x0, 8a44 <fwp_hof0.constprop.0+0x74>
    90e8:	a95253f3 	ldp	x19, x20, [sp, #288]
    90ec:	a9535bf5 	ldp	x21, x22, [sp, #304]
    90f0:	a95463f7 	ldp	x23, x24, [sp, #320]
    90f4:	a9556bf9 	ldp	x25, x26, [sp, #336]
    90f8:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    90fc:	f947f400 	ldr	x0, [x0, #4072]
    9100:	f94087e2 	ldr	x2, [sp, #264]
    9104:	f9400001 	ldr	x1, [x0]
    9108:	eb010042 	subs	x2, x2, x1
    910c:	d2800001 	mov	x1, #0x0                   	// #0
    9110:	54009a01 	b.ne	a450 <fwp_hof0.constprop.0+0x1a80>  // b.any
    9114:	a9517bfd 	ldp	x29, x30, [sp, #272]
    9118:	d2800000 	mov	x0, #0x0                   	// #0
    911c:	a95673fb 	ldp	x27, x28, [sp, #352]
    9120:	9105c3ff 	add	sp, sp, #0x170
    9124:	d65f03c0 	ret
    9128:	b0ffffe0 	adrp	x0, 6000 <fwp_owned_entry173+0x30>
    912c:	911e0000 	add	x0, x0, #0x780
    9130:	940011c8 	bl	d850 <atexit>
    9134:	35004ea0 	cbnz	w0, 9b08 <fwp_hof0.constprop.0+0x1138>
    9138:	52800020 	mov	w0, #0x1                   	// #1
    913c:	b903b6e0 	str	w0, [x23, #948]
    9140:	17fffedd 	b	8cb4 <fwp_hof0.constprop.0+0x2e4>
    9144:	d3707d08 	ubfiz	x8, x8, #16, #32
    9148:	52800041 	mov	w1, #0x2                   	// #2
    914c:	aa090100 	orr	x0, x8, x9
    9150:	f9001fe0 	str	x0, [sp, #56]
    9154:	d2800100 	mov	x0, #0x8                   	// #8
    9158:	97ffefda 	bl	50c0 <fwp_heap_alloc>
    915c:	aa0003e9 	mov	x9, x0
    9160:	911882c0 	add	x0, x22, #0x620
    9164:	aa0903ea 	mov	x10, x9
    9168:	f900013f 	str	xzr, [x9]
    916c:	f949d801 	ldr	x1, [x0, #5040]
    9170:	f949ec00 	ldr	x0, [x0, #5080]
    9174:	cb010121 	sub	x1, x9, x1
    9178:	eb00403f 	cmp	x1, x0, lsl #16
    917c:	54001342 	b.cs	93e4 <fwp_hof0.constprop.0+0xa14>  // b.hs, b.nlast
    9180:	d2800017 	mov	x23, #0x0                   	// #0
    9184:	911882c2 	add	x2, x22, #0x620
    9188:	d350fc20 	lsr	x0, x1, #16
    918c:	8b000800 	add	x0, x0, x0, lsl #2
    9190:	f949fc44 	ldr	x4, [x2, #5112]
    9194:	d37df002 	lsl	x2, x0, #3
    9198:	8b020083 	add	x3, x4, x2
    919c:	f940107a 	ldr	x26, [x3, #32]
    91a0:	b400025a 	cbz	x26, 91e8 <fwp_hof0.constprop.0+0x818>
    91a4:	38626882 	ldrb	w2, [x4, x2]
    91a8:	7100085f 	cmp	w2, #0x2
    91ac:	54001200 	b.eq	93ec <fwp_hof0.constprop.0+0xa1c>  // b.none
    91b0:	7100045f 	cmp	w2, #0x1
    91b4:	540001a1 	b.ne	91e8 <fwp_hof0.constprop.0+0x818>  // b.any
    91b8:	29430864 	ldp	w4, w2, [x3, #24]
    91bc:	92403c21 	and	x1, x1, #0xffff
    91c0:	9b047c21 	mul	x1, x1, x4
    91c4:	d360fc21 	lsr	x1, x1, #32
    91c8:	eb02003f 	cmp	x1, x2
    91cc:	540000e2 	b.cs	91e8 <fwp_hof0.constprop.0+0x818>  // b.hs, b.nlast
    91d0:	8b01035a 	add	x26, x26, x1
    91d4:	39400341 	ldrb	w1, [x26]
    91d8:	7103fc3f 	cmp	w1, #0xff
    91dc:	54004680 	b.eq	9aac <fwp_hof0.constprop.0+0x10dc>  // b.none
    91e0:	52800021 	mov	w1, #0x1                   	// #1
    91e4:	39000341 	strb	w1, [x26]
    91e8:	b4000257 	cbz	x23, 9230 <fwp_hof0.constprop.0+0x860>
    91ec:	f9401fe0 	ldr	x0, [sp, #56]
    91f0:	aa1903e3 	mov	x3, x25
    91f4:	f9400728 	ldr	x8, [x25, #8]
    91f8:	91002122 	add	x2, x9, #0x8
    91fc:	d3607c07 	lsl	x7, x0, #32
    9200:	d2800001 	mov	x1, #0x0                   	// #0
    9204:	aa0703e4 	mov	x4, x7
    9208:	14000005 	b	921c <fwp_hof0.constprop.0+0x84c>
    920c:	f9400468 	ldr	x8, [x3, #8]
    9210:	ab0100e4 	adds	x4, x7, x1
    9214:	91004042 	add	x2, x2, #0x10
    9218:	540099c6 	b.vs	a550 <fwp_hof0.constprop.0+0x1b80>
    921c:	a9001048 	stp	x8, x4, [x2]
    9220:	91000421 	add	x1, x1, #0x1
    9224:	f9400863 	ldr	x3, [x3, #16]
    9228:	eb17003f 	cmp	x1, x23
    922c:	54ffff03 	b.cc	920c <fwp_hof0.constprop.0+0x83c>  // b.lo, b.ul, b.last
    9230:	f9400120 	ldr	x0, [x9]
    9234:	f100041f 	cmp	x0, #0x1
    9238:	54000d69 	b.ls	93e4 <fwp_hof0.constprop.0+0xa14>  // b.plast
    923c:	d341fc00 	lsr	x0, x0, #1
    9240:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    9244:	d1000401 	sub	x1, x0, #0x1
    9248:	eb02003f 	cmp	x1, x2
    924c:	54ffe408 	b.hi	8ecc <fwp_hof0.constprop.0+0x4fc>  // b.pmore
    9250:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    9254:	a90d7fe2 	stp	x2, xzr, [sp, #208]
    9258:	d37ff822 	lsl	x2, x1, #1
    925c:	b4000321 	cbz	x1, 92c0 <fwp_hof0.constprop.0+0x8f0>
    9260:	d1002121 	sub	x1, x9, #0x8
    9264:	9100213a 	add	x26, x9, #0x8
    9268:	8b001037 	add	x23, x1, x0, lsl #4
    926c:	910343e0 	add	x0, sp, #0xd0
    9270:	a90527f9 	stp	x25, x9, [sp, #80]
    9274:	aa0003f9 	mov	x25, x0
    9278:	f90033f3 	str	x19, [sp, #96]
    927c:	aa1a03f3 	mov	x19, x26
    9280:	aa0203fa 	mov	x26, x2
    9284:	f90023ea 	str	x10, [sp, #64]
    9288:	f9400660 	ldr	x0, [x19, #8]
    928c:	aa1903e2 	mov	x2, x25
    9290:	f9400e61 	ldr	x1, [x19, #24]
    9294:	fd400260 	ldr	d0, [x19]
    9298:	fd400a61 	ldr	d1, [x19, #16]
    929c:	97fff125 	bl	5730 <w120>
    92a0:	a9000660 	stp	x0, x1, [x19]
    92a4:	91004273 	add	x19, x19, #0x10
    92a8:	eb1302ff 	cmp	x23, x19
    92ac:	54fffee1 	b.ne	9288 <fwp_hof0.constprop.0+0x8b8>  // b.any
    92b0:	a94527f9 	ldp	x25, x9, [sp, #80]
    92b4:	aa1a03e2 	mov	x2, x26
    92b8:	f94023ea 	ldr	x10, [sp, #64]
    92bc:	f94033f3 	ldr	x19, [sp, #96]
    92c0:	911882d7 	add	x23, x22, #0x620
    92c4:	f9000122 	str	x2, [x9]
    92c8:	aa0903e0 	mov	x0, x9
    92cc:	f90023e9 	str	x9, [sp, #64]
    92d0:	f9002fea 	str	x10, [sp, #88]
    92d4:	97fff267 	bl	5c70 <w176.constprop.0>
    92d8:	f94023e9 	ldr	x9, [sp, #64]
    92dc:	f9002be1 	str	x1, [sp, #80]
    92e0:	f949dae1 	ldr	x1, [x23, #5040]
    92e4:	f949eee0 	ldr	x0, [x23, #5080]
    92e8:	cb010121 	sub	x1, x9, x1
    92ec:	f9402fea 	ldr	x10, [sp, #88]
    92f0:	aa0a03fa 	mov	x26, x10
    92f4:	eb00403f 	cmp	x1, x0, lsl #16
    92f8:	54000382 	b.cs	9368 <fwp_hof0.constprop.0+0x998>  // b.hs, b.nlast
    92fc:	d350fc20 	lsr	x0, x1, #16
    9300:	f949fee4 	ldr	x4, [x23, #5112]
    9304:	8b000800 	add	x0, x0, x0, lsl #2
    9308:	d37df002 	lsl	x2, x0, #3
    930c:	8b020083 	add	x3, x4, x2
    9310:	f9401060 	ldr	x0, [x3, #32]
    9314:	b40002a0 	cbz	x0, 9368 <fwp_hof0.constprop.0+0x998>
    9318:	38626882 	ldrb	w2, [x4, x2]
    931c:	7100085f 	cmp	w2, #0x2
    9320:	54001800 	b.eq	9620 <fwp_hof0.constprop.0+0xc50>  // b.none
    9324:	7100045f 	cmp	w2, #0x1
    9328:	54000201 	b.ne	9368 <fwp_hof0.constprop.0+0x998>  // b.any
    932c:	29430865 	ldp	w5, w2, [x3, #24]
    9330:	92403c21 	and	x1, x1, #0xffff
    9334:	9b057c21 	mul	x1, x1, x5
    9338:	d360fc21 	lsr	x1, x1, #32
    933c:	eb02003f 	cmp	x1, x2
    9340:	54000142 	b.cs	9368 <fwp_hof0.constprop.0+0x998>  // b.hs, b.nlast
    9344:	8b010000 	add	x0, x0, x1
    9348:	39400001 	ldrb	w1, [x0]
    934c:	340000e1 	cbz	w1, 9368 <fwp_hof0.constprop.0+0x998>
    9350:	7100043f 	cmp	w1, #0x1
    9354:	54000520 	b.eq	93f8 <fwp_hof0.constprop.0+0xa28>  // b.none
    9358:	7103fc3f 	cmp	w1, #0xff
    935c:	54003f40 	b.eq	9b44 <fwp_hof0.constprop.0+0x1174>  // b.none
    9360:	51000421 	sub	w1, w1, #0x1
    9364:	39000001 	strb	w1, [x0]
    9368:	b9803bfa 	ldrsw	x26, [sp, #56]
    936c:	aa1a03e0 	mov	x0, x26
    9370:	97ffede0 	bl	4af0 <fwp_tape_of>
    9374:	f9402808 	ldr	x8, [x0, #80]
    9378:	aa0003e7 	mov	x7, x0
    937c:	b4000f08 	cbz	x8, 955c <fwp_hof0.constprop.0+0xb8c>
    9380:	90000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    9384:	9137c000 	add	x0, x0, #0xdf0
    9388:	97ffebd7 	bl	42e4 <fwp_trap>
    938c:	d280001a 	mov	x26, #0x0                   	// #0
    9390:	17fffe46 	b	8ca8 <fwp_hof0.constprop.0+0x2d8>
    9394:	d37ffae2 	lsl	x2, x23, #1
    9398:	d3707d08 	ubfiz	x8, x8, #16, #32
    939c:	91000440 	add	x0, x2, #0x1
    93a0:	aa090101 	orr	x1, x8, x9
    93a4:	aa0203fa 	mov	x26, x2
    93a8:	f9001fe1 	str	x1, [sp, #56]
    93ac:	d37df000 	lsl	x0, x0, #3
    93b0:	52800041 	mov	w1, #0x2                   	// #2
    93b4:	97ffef43 	bl	50c0 <fwp_heap_alloc>
    93b8:	aa0003e9 	mov	x9, x0
    93bc:	911882c1 	add	x1, x22, #0x620
    93c0:	aa0003ea 	mov	x10, x0
    93c4:	aa0103e0 	mov	x0, x1
    93c8:	f900013a 	str	x26, [x9]
    93cc:	f949d821 	ldr	x1, [x1, #5040]
    93d0:	f949ec00 	ldr	x0, [x0, #5080]
    93d4:	cb010121 	sub	x1, x9, x1
    93d8:	eb00403f 	cmp	x1, x0, lsl #16
    93dc:	54ffed43 	b.cc	9184 <fwp_hof0.constprop.0+0x7b4>  // b.lo, b.ul, b.last
    93e0:	b5fff077 	cbnz	x23, 91ec <fwp_hof0.constprop.0+0x81c>
    93e4:	d2800002 	mov	x2, #0x0                   	// #0
    93e8:	17ffffb6 	b	92c0 <fwp_hof0.constprop.0+0x8f0>
    93ec:	72003c3f 	tst	w1, #0xffff
    93f0:	54ffefc1 	b.ne	91e8 <fwp_hof0.constprop.0+0x818>  // b.any
    93f4:	17ffff78 	b	91d4 <fwp_hof0.constprop.0+0x804>
    93f8:	f9400345 	ldr	x5, [x26]
    93fc:	aa1a03e0 	mov	x0, x26
    9400:	f949eee2 	ldr	x2, [x23, #5080]
    9404:	f949dae1 	ldr	x1, [x23, #5040]
    9408:	d370bc43 	lsl	x3, x2, #16
    940c:	cb010342 	sub	x2, x26, x1
    9410:	b7f810e5 	tbnz	x5, #63, 962c <fwp_hof0.constprop.0+0xc5c>
    9414:	aa1a03ea 	mov	x10, x26
    9418:	eb02007f 	cmp	x3, x2
    941c:	54fffa69 	b.ls	9368 <fwp_hof0.constprop.0+0x998>  // b.plast
    9420:	d350fc40 	lsr	x0, x2, #16
    9424:	8b000800 	add	x0, x0, x0, lsl #2
    9428:	d37df000 	lsl	x0, x0, #3
    942c:	8b000083 	add	x3, x4, x0
    9430:	f9401061 	ldr	x1, [x3, #32]
    9434:	b4fff9a1 	cbz	x1, 9368 <fwp_hof0.constprop.0+0x998>
    9438:	38606880 	ldrb	w0, [x4, x0]
    943c:	7100081f 	cmp	w0, #0x2
    9440:	54003260 	b.eq	9a8c <fwp_hof0.constprop.0+0x10bc>  // b.none
    9444:	7100041f 	cmp	w0, #0x1
    9448:	54fff901 	b.ne	9368 <fwp_hof0.constprop.0+0x998>  // b.any
    944c:	92403c40 	and	x0, x2, #0xffff
    9450:	29430864 	ldp	w4, w2, [x3, #24]
    9454:	9b047c00 	mul	x0, x0, x4
    9458:	d360fc00 	lsr	x0, x0, #32
    945c:	eb02001f 	cmp	x0, x2
    9460:	54fff842 	b.cs	9368 <fwp_hof0.constprop.0+0x998>  // b.hs, b.nlast
    9464:	8b000021 	add	x1, x1, x0
    9468:	39400020 	ldrb	w0, [x1]
    946c:	7100041f 	cmp	w0, #0x1
    9470:	54fff7c1 	b.ne	9368 <fwp_hof0.constprop.0+0x998>  // b.any
    9474:	aa0a03e0 	mov	x0, x10
    9478:	97ffec56 	bl	45d0 <fwp_mem_free>
    947c:	17ffffbb 	b	9368 <fwp_hof0.constprop.0+0x998>
    9480:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x780>
    9484:	91010000 	add	x0, x0, #0x40
    9488:	97ffeb97 	bl	42e4 <fwp_trap>
    948c:	3dc03400 	ldr	q0, [x0, #208]
    9490:	f9007c1f 	str	xzr, [x0, #248]
    9494:	3d800840 	str	q0, [x2, #32]
    9498:	f9407803 	ldr	x3, [x0, #240]
    949c:	f9001c43 	str	x3, [x2, #56]
    94a0:	f9407003 	ldr	x3, [x0, #224]
    94a4:	f9001843 	str	x3, [x2, #48]
    94a8:	f9407403 	ldr	x3, [x0, #232]
    94ac:	f9000c43 	str	x3, [x2, #24]
    94b0:	a90d7c1f 	stp	xzr, xzr, [x0, #208]
    94b4:	a90e7c1f 	stp	xzr, xzr, [x0, #224]
    94b8:	f900781f 	str	xzr, [x0, #240]
    94bc:	17fffe52 	b	8e04 <fwp_hof0.constprop.0+0x434>
    94c0:	90000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    94c4:	913e8000 	add	x0, x0, #0xfa0
    94c8:	97ffeb87 	bl	42e4 <fwp_trap>
    94cc:	97ffecba 	bl	47b4 <fwp_rc_wide_dup>
    94d0:	911882c0 	add	x0, x22, #0x620
    94d4:	f949ec04 	ldr	x4, [x0, #5080]
    94d8:	f949d801 	ldr	x1, [x0, #5040]
    94dc:	d370bc84 	lsl	x4, x4, #16
    94e0:	17fffd80 	b	8ae0 <fwp_hof0.constprop.0+0x110>
    94e4:	97ffecb4 	bl	47b4 <fwp_rc_wide_dup>
    94e8:	17fffdae 	b	8ba0 <fwp_hof0.constprop.0+0x1d0>
    94ec:	ca5746e0 	eor	x0, x23, x23, lsr #17
    94f0:	911882c1 	add	x1, x22, #0x620
    94f4:	ca402400 	eor	x0, x0, x0, lsr #9
    94f8:	92401c00 	and	x0, x0, #0xff
    94fc:	910a2402 	add	x2, x0, #0x289
    9500:	8b000c20 	add	x0, x1, x0, lsl #3
    9504:	8b020c22 	add	x2, x1, x2, lsl #3
    9508:	f94a2400 	ldr	x0, [x0, #5192]
    950c:	b50000a0 	cbnz	x0, 9520 <fwp_hof0.constprop.0+0xb50>
    9510:	14000162 	b	9a98 <fwp_hof0.constprop.0+0x10c8>
    9514:	91004002 	add	x2, x0, #0x10
    9518:	f9400800 	ldr	x0, [x0, #16]
    951c:	b4002be0 	cbz	x0, 9a98 <fwp_hof0.constprop.0+0x10c8>
    9520:	f9400001 	ldr	x1, [x0]
    9524:	eb17003f 	cmp	x1, x23
    9528:	54ffff61 	b.ne	9514 <fwp_hof0.constprop.0+0xb44>  // b.any
    952c:	f9400041 	ldr	x1, [x2]
    9530:	f9400420 	ldr	x0, [x1, #8]
    9534:	d1000400 	sub	x0, x0, #0x1
    9538:	f9000420 	str	x0, [x1, #8]
    953c:	f103f81f 	cmp	x0, #0xfe
    9540:	54ffb701 	b.ne	8c20 <fwp_hof0.constprop.0+0x250>  // b.any
    9544:	394002e0 	ldrb	w0, [x23]
    9548:	7103fc1f 	cmp	w0, #0xff
    954c:	54002f60 	b.eq	9b38 <fwp_hof0.constprop.0+0x1168>  // b.none
    9550:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9554:	390002e0 	strb	w0, [x23]
    9558:	17fffdb2 	b	8c20 <fwp_hof0.constprop.0+0x250>
    955c:	97ffe69e 	bl	2fd4 <fwp_tape_unlink_scope>
    9560:	b90004ff 	str	wzr, [x7, #4]
    9564:	3dc008e0 	ldr	q0, [x7, #32]
    9568:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    956c:	b94000e1 	ldr	w1, [x7]
    9570:	a9408ce8 	ldp	x8, x3, [x7, #8]
    9574:	3d8013e0 	str	q0, [sp, #64]
    9578:	f9400ce2 	ldr	x2, [x7, #24]
    957c:	a94324e4 	ldp	x4, x9, [x7, #48]
    9580:	6b00003f 	cmp	w1, w0
    9584:	54000108 	b.hi	95a4 <fwp_hof0.constprop.0+0xbd4>  // b.pmore
    9588:	91014281 	add	x1, x20, #0x50
    958c:	92403f40 	and	x0, x26, #0xffff
    9590:	d1000400 	sub	x0, x0, #0x1
    9594:	f940a82a 	ldr	x10, [x1, #336]
    9598:	eb0a001f 	cmp	x0, x10
    959c:	5400004a 	b.ge	95a4 <fwp_hof0.constprop.0+0xbd4>  // b.tcont
    95a0:	f900a820 	str	x0, [x1, #336]
    95a4:	91014281 	add	x1, x20, #0x50
    95a8:	f9000cff 	str	xzr, [x7, #24]
    95ac:	4f000400 	movi	v0.4s, #0x0
    95b0:	a9037cff 	stp	xzr, xzr, [x7, #48]
    95b4:	9102e3e5 	add	x5, sp, #0xb8
    95b8:	f941c020 	ldr	x0, [x1, #896]
    95bc:	f9005fe0 	str	x0, [sp, #184]
    95c0:	f0ffffc0 	adrp	x0, 4000 <ad_raw_free.part.0+0x50>
    95c4:	91054000 	add	x0, x0, #0x150
    95c8:	3c8080e0 	stur	q0, [x7, #8]
    95cc:	3d8008e0 	str	q0, [x7, #32]
    95d0:	3dc013e0 	ldr	q0, [sp, #64]
    95d4:	f90063e0 	str	x0, [sp, #192]
    95d8:	910343e0 	add	x0, sp, #0xd0
    95dc:	f9001fe0 	str	x0, [sp, #56]
    95e0:	f90067e0 	str	x0, [sp, #200]
    95e4:	f9402be0 	ldr	x0, [sp, #80]
    95e8:	f9002fe5 	str	x5, [sp, #88]
    95ec:	a90e0be4 	stp	x4, x2, [sp, #224]
    95f0:	f9007be9 	str	x9, [sp, #240]
    95f4:	f901c025 	str	x5, [x1, #896]
    95f8:	3d8037e0 	str	q0, [sp, #208]
    95fc:	b7f82540 	tbnz	x0, #63, 9aa4 <fwp_hof0.constprop.0+0x10d4>
    9600:	eb80835f 	cmp	x26, x0, asr #32
    9604:	54000560 	b.eq	96b0 <fwp_hof0.constprop.0+0xce0>  // b.none
    9608:	90000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    960c:	9136a000 	add	x0, x0, #0xda8
    9610:	97ffeb35 	bl	42e4 <fwp_trap>
    9614:	d2800b01 	mov	x1, #0x58                  	// #88
    9618:	d2800037 	mov	x23, #0x1                   	// #1
    961c:	17fffdcb 	b	8d48 <fwp_hof0.constprop.0+0x378>
    9620:	72003c3f 	tst	w1, #0xffff
    9624:	54ffea21 	b.ne	9368 <fwp_hof0.constprop.0+0x998>  // b.any
    9628:	17ffff48 	b	9348 <fwp_hof0.constprop.0+0x978>
    962c:	f940075a 	ldr	x26, [x26, #8]
    9630:	eb02007f 	cmp	x3, x2
    9634:	54000369 	b.ls	96a0 <fwp_hof0.constprop.0+0xcd0>  // b.plast
    9638:	d350fc45 	lsr	x5, x2, #16
    963c:	8b0508a5 	add	x5, x5, x5, lsl #2
    9640:	d37df0a5 	lsl	x5, x5, #3
    9644:	8b050087 	add	x7, x4, x5
    9648:	f94010e6 	ldr	x6, [x7, #32]
    964c:	b40002a6 	cbz	x6, 96a0 <fwp_hof0.constprop.0+0xcd0>
    9650:	38656884 	ldrb	w4, [x4, x5]
    9654:	7100089f 	cmp	w4, #0x2
    9658:	540023e0 	b.eq	9ad4 <fwp_hof0.constprop.0+0x1104>  // b.none
    965c:	7100049f 	cmp	w4, #0x1
    9660:	54000201 	b.ne	96a0 <fwp_hof0.constprop.0+0xcd0>  // b.any
    9664:	294310e5 	ldp	w5, w4, [x7, #24]
    9668:	92403c42 	and	x2, x2, #0xffff
    966c:	9b057c42 	mul	x2, x2, x5
    9670:	d360fc42 	lsr	x2, x2, #32
    9674:	eb04005f 	cmp	x2, x4
    9678:	54000142 	b.cs	96a0 <fwp_hof0.constprop.0+0xcd0>  // b.hs, b.nlast
    967c:	8b0200c6 	add	x6, x6, x2
    9680:	394000c2 	ldrb	w2, [x6]
    9684:	7100045f 	cmp	w2, #0x1
    9688:	540000c1 	b.ne	96a0 <fwp_hof0.constprop.0+0xcd0>  // b.any
    968c:	97ffebd1 	bl	45d0 <fwp_mem_free>
    9690:	911882c0 	add	x0, x22, #0x620
    9694:	f949ec02 	ldr	x2, [x0, #5080]
    9698:	f949d801 	ldr	x1, [x0, #5040]
    969c:	d370bc43 	lsl	x3, x2, #16
    96a0:	cb010341 	sub	x1, x26, x1
    96a4:	eb03003f 	cmp	x1, x3
    96a8:	54ffe2a3 	b.cc	92fc <fwp_hof0.constprop.0+0x92c>  // b.lo, b.ul, b.last
    96ac:	17ffff2f 	b	9368 <fwp_hof0.constprop.0+0x998>
    96b0:	f9402be0 	ldr	x0, [sp, #80]
    96b4:	92407c17 	and	x23, x0, #0xffffffff
    96b8:	eb20407f 	cmp	x3, w0, uxtw
    96bc:	5400206d 	b.le	9ac8 <fwp_hof0.constprop.0+0x10f8>
    96c0:	eb17011f 	cmp	x8, x23
    96c4:	9a97c517 	csinc	x23, x8, x23, gt
    96c8:	eb17013f 	cmp	x9, x23
    96cc:	540020ca 	b.ge	9ae4 <fwp_hof0.constprop.0+0x1114>  // b.tcont
    96d0:	f100013f 	cmp	x9, #0x0
    96d4:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    96d8:	9a971129 	csel	x9, x9, x23, ne	// ne = any
    96dc:	14000004 	b	96ec <fwp_hof0.constprop.0+0xd1c>
    96e0:	eb02013f 	cmp	x9, x2
    96e4:	d37ff929 	lsl	x9, x9, #1
    96e8:	9a97d129 	csel	x9, x9, x23, le
    96ec:	eb17013f 	cmp	x9, x23
    96f0:	54ffff8b 	b.lt	96e0 <fwp_hof0.constprop.0+0xd10>  // b.tstop
    96f4:	b4005a44 	cbz	x4, a23c <fwp_hof0.constprop.0+0x186c>
    96f8:	aa0403e0 	mov	x0, x4
    96fc:	d37df121 	lsl	x1, x9, #3
    9700:	52800062 	mov	w2, #0x3                   	// #3
    9704:	a90623e9 	stp	x9, x8, [sp, #96]
    9708:	97ffea5e 	bl	4080 <ad_raw_realloc>
    970c:	a94623e9 	ldp	x9, x8, [sp, #96]
    9710:	aa0003e4 	mov	x4, x0
    9714:	b4001e60 	cbz	x0, 9ae0 <fwp_hof0.constprop.0+0x1110>
    9718:	f90073e4 	str	x4, [sp, #224]
    971c:	f9007be9 	str	x9, [sp, #240]
    9720:	b5002517 	cbnz	x23, 9bc0 <fwp_hof0.constprop.0+0x11f0>
    9724:	f9402be0 	ldr	x0, [sp, #80]
    9728:	b7f800c0 	tbnz	x0, #63, 9740 <fwp_hof0.constprop.0+0xd70>
    972c:	92407c00 	and	x0, x0, #0xffffffff
    9730:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    9734:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    9738:	1e612800 	fadd	d0, d0, d1
    973c:	fc207880 	str	d0, [x4, x0, lsl #3]
    9740:	d10006e1 	sub	x1, x23, #0x1
    9744:	eb01011f 	cmp	x8, x1
    9748:	540003cc 	b.gt	97c0 <fwp_hof0.constprop.0+0xdf0>
    974c:	f94023e0 	ldr	x0, [sp, #64]
    9750:	cb0802f7 	sub	x23, x23, x8
    9754:	d1000503 	sub	x3, x8, #0x1
    9758:	8b1706f7 	add	x23, x23, x23, lsl #1
    975c:	d1006000 	sub	x0, x0, #0x18
    9760:	8b170c00 	add	x0, x0, x23, lsl #3
    9764:	fc617880 	ldr	d0, [x4, x1, lsl #3]
    9768:	1e602008 	fcmp	d0, #0.0
    976c:	54000220 	b.eq	97b0 <fwp_hof0.constprop.0+0xde0>  // b.none
    9770:	b9400002 	ldr	w2, [x0]
    9774:	37f800e2 	tbnz	w2, #31, 9790 <fwp_hof0.constprop.0+0xdc0>
    9778:	fd400402 	ldr	d2, [x0, #8]
    977c:	93407c42 	sxtw	x2, w2
    9780:	1e620802 	fmul	d2, d0, d2
    9784:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    9788:	1e622821 	fadd	d1, d1, d2
    978c:	fc227881 	str	d1, [x4, x2, lsl #3]
    9790:	b9400402 	ldr	w2, [x0, #4]
    9794:	37f800e2 	tbnz	w2, #31, 97b0 <fwp_hof0.constprop.0+0xde0>
    9798:	fd400801 	ldr	d1, [x0, #16]
    979c:	93407c42 	sxtw	x2, w2
    97a0:	1e610800 	fmul	d0, d0, d1
    97a4:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    97a8:	1e602820 	fadd	d0, d1, d0
    97ac:	fc227880 	str	d0, [x4, x2, lsl #3]
    97b0:	d1000421 	sub	x1, x1, #0x1
    97b4:	d1006000 	sub	x0, x0, #0x18
    97b8:	eb03003f 	cmp	x1, x3
    97bc:	54fffd41 	b.ne	9764 <fwp_hof0.constprop.0+0xd94>  // b.any
    97c0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    97c4:	eb00011f 	cmp	x8, x0
    97c8:	54001f68 	b.hi	9bb4 <fwp_hof0.constprop.0+0x11e4>  // b.pmore
    97cc:	91000500 	add	x0, x8, #0x1
    97d0:	52800041 	mov	w1, #0x2                   	// #2
    97d4:	f90023e4 	str	x4, [sp, #64]
    97d8:	d37df000 	lsl	x0, x0, #3
    97dc:	f9002be8 	str	x8, [sp, #80]
    97e0:	97ffee38 	bl	50c0 <fwp_heap_alloc>
    97e4:	aa0003fa 	mov	x26, x0
    97e8:	f9402be8 	ldr	x8, [sp, #80]
    97ec:	f8008408 	str	x8, [x0], #8
    97f0:	f94023e4 	ldr	x4, [sp, #64]
    97f4:	d2800001 	mov	x1, #0x0                   	// #0
    97f8:	b40000c8 	cbz	x8, 9810 <fwp_hof0.constprop.0+0xe40>
    97fc:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    9800:	f8217802 	str	x2, [x0, x1, lsl #3]
    9804:	91000421 	add	x1, x1, #0x1
    9808:	eb01011f 	cmp	x8, x1
    980c:	54ffff81 	b.ne	97fc <fwp_hof0.constprop.0+0xe2c>  // b.any
    9810:	91014281 	add	x1, x20, #0x50
    9814:	f9402fe2 	ldr	x2, [sp, #88]
    9818:	f941c020 	ldr	x0, [x1, #896]
    981c:	eb02001f 	cmp	x0, x2
    9820:	54006961 	b.ne	a54c <fwp_hof0.constprop.0+0x1b7c>  // b.any
    9824:	f9401fe0 	ldr	x0, [sp, #56]
    9828:	f9405fe4 	ldr	x4, [sp, #184]
    982c:	f9002be4 	str	x4, [sp, #80]
    9830:	f901c024 	str	x4, [x1, #896]
    9834:	97ffea47 	bl	4150 <fwp_tape_buffers_release>
    9838:	911882c2 	add	x2, x22, #0x620
    983c:	f9402be4 	ldr	x4, [sp, #80]
    9840:	f949d841 	ldr	x1, [x2, #5040]
    9844:	f949ec40 	ldr	x0, [x2, #5080]
    9848:	cb010341 	sub	x1, x26, x1
    984c:	eb00403f 	cmp	x1, x0, lsl #16
    9850:	54000322 	b.cs	98b4 <fwp_hof0.constprop.0+0xee4>  // b.hs, b.nlast
    9854:	d350fc20 	lsr	x0, x1, #16
    9858:	f949fc47 	ldr	x7, [x2, #5112]
    985c:	8b000800 	add	x0, x0, x0, lsl #2
    9860:	d37df002 	lsl	x2, x0, #3
    9864:	8b0200e3 	add	x3, x7, x2
    9868:	f9401077 	ldr	x23, [x3, #32]
    986c:	b4000257 	cbz	x23, 98b4 <fwp_hof0.constprop.0+0xee4>
    9870:	386268e0 	ldrb	w0, [x7, x2]
    9874:	7100081f 	cmp	w0, #0x2
    9878:	540024c0 	b.eq	9d10 <fwp_hof0.constprop.0+0x1340>  // b.none
    987c:	7100041f 	cmp	w0, #0x1
    9880:	540001a1 	b.ne	98b4 <fwp_hof0.constprop.0+0xee4>  // b.any
    9884:	29430062 	ldp	w2, w0, [x3, #24]
    9888:	92403c21 	and	x1, x1, #0xffff
    988c:	9b027c21 	mul	x1, x1, x2
    9890:	d360fc21 	lsr	x1, x1, #32
    9894:	eb00003f 	cmp	x1, x0
    9898:	540000e2 	b.cs	98b4 <fwp_hof0.constprop.0+0xee4>  // b.hs, b.nlast
    989c:	8b0102f7 	add	x23, x23, x1
    98a0:	394002e0 	ldrb	w0, [x23]
    98a4:	7103fc1f 	cmp	w0, #0xff
    98a8:	54005c20 	b.eq	a42c <fwp_hof0.constprop.0+0x1a5c>  // b.none
    98ac:	52800020 	mov	w0, #0x1                   	// #1
    98b0:	390002e0 	strb	w0, [x23]
    98b4:	f9400be0 	ldr	x0, [sp, #16]
    98b8:	eb00009f 	cmp	x4, x0
    98bc:	54006481 	b.ne	a54c <fwp_hof0.constprop.0+0x1b7c>  // b.any
    98c0:	f94007e0 	ldr	x0, [sp, #8]
    98c4:	91014281 	add	x1, x20, #0x50
    98c8:	f94053e2 	ldr	x2, [sp, #160]
    98cc:	f901c022 	str	x2, [x1, #896]
    98d0:	97fff3f0 	bl	6890 <fwp_tape_scope_release>
    98d4:	f9400340 	ldr	x0, [x26]
    98d8:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    98dc:	b7f81900 	tbnz	x0, #63, 9bfc <fwp_hof0.constprop.0+0x122c>
    98e0:	911882c3 	add	x3, x22, #0x620
    98e4:	f949d860 	ldr	x0, [x3, #5040]
    98e8:	f949ec61 	ldr	x1, [x3, #5080]
    98ec:	cb000340 	sub	x0, x26, x0
    98f0:	eb01401f 	cmp	x0, x1, lsl #16
    98f4:	54001842 	b.cs	9bfc <fwp_hof0.constprop.0+0x122c>  // b.hs, b.nlast
    98f8:	d350fc01 	lsr	x1, x0, #16
    98fc:	f949fc67 	ldr	x7, [x3, #5112]
    9900:	8b010821 	add	x1, x1, x1, lsl #2
    9904:	d37df021 	lsl	x1, x1, #3
    9908:	8b0100e4 	add	x4, x7, x1
    990c:	f9401083 	ldr	x3, [x4, #32]
    9910:	b4001763 	cbz	x3, 9bfc <fwp_hof0.constprop.0+0x122c>
    9914:	386168e1 	ldrb	w1, [x7, x1]
    9918:	7100083f 	cmp	w1, #0x2
    991c:	540016c0 	b.eq	9bf4 <fwp_hof0.constprop.0+0x1224>  // b.none
    9920:	7100043f 	cmp	w1, #0x1
    9924:	540016c1 	b.ne	9bfc <fwp_hof0.constprop.0+0x122c>  // b.any
    9928:	29430487 	ldp	w7, w1, [x4, #24]
    992c:	92403c00 	and	x0, x0, #0xffff
    9930:	9b077c00 	mul	x0, x0, x7
    9934:	d360fc00 	lsr	x0, x0, #32
    9938:	eb01001f 	cmp	x0, x1
    993c:	54001602 	b.cs	9bfc <fwp_hof0.constprop.0+0x122c>  // b.hs, b.nlast
    9940:	8b000063 	add	x3, x3, x0
    9944:	39400060 	ldrb	w0, [x3]
    9948:	7100041f 	cmp	w0, #0x1
    994c:	54001581 	b.ne	9bfc <fwp_hof0.constprop.0+0x122c>  // b.any
    9950:	aa1a03f7 	mov	x23, x26
    9954:	d2800000 	mov	x0, #0x0                   	// #0
    9958:	910022e3 	add	x3, x23, #0x8
    995c:	d2800001 	mov	x1, #0x0                   	// #0
    9960:	b40001e2 	cbz	x2, 999c <fwp_hof0.constprop.0+0xfcc>
    9964:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0x780>
    9968:	91002347 	add	x7, x26, #0x8
    996c:	fd445081 	ldr	d1, [x4, #2208]
    9970:	f9400345 	ldr	x5, [x26]
    9974:	aa0703e4 	mov	x4, x7
    9978:	b7f813a5 	tbnz	x5, #63, 9bec <fwp_hof0.constprop.0+0x121c>
    997c:	f94002e5 	ldr	x5, [x23]
    9980:	fc617880 	ldr	d0, [x4, x1, lsl #3]
    9984:	b7f812e5 	tbnz	x5, #63, 9be0 <fwp_hof0.constprop.0+0x1210>
    9988:	1e600820 	fmul	d0, d1, d0
    998c:	91000421 	add	x1, x1, #0x1
    9990:	fc008460 	str	d0, [x3], #8
    9994:	eb01005f 	cmp	x2, x1
    9998:	54fffec1 	b.ne	9970 <fwp_hof0.constprop.0+0xfa0>  // b.any
    999c:	97fff5c9 	bl	70c0 <fwp_drop10>
    99a0:	b4005859 	cbz	x25, a4a8 <fwp_hof0.constprop.0+0x1ad8>
    99a4:	aa1903e0 	mov	x0, x25
    99a8:	d280001a 	mov	x26, #0x0                   	// #0
    99ac:	f9400800 	ldr	x0, [x0, #16]
    99b0:	9100075a 	add	x26, x26, #0x1
    99b4:	b5ffffc0 	cbnz	x0, 99ac <fwp_hof0.constprop.0+0xfdc>
    99b8:	f94002e0 	ldr	x0, [x23]
    99bc:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    99c0:	b7f817a0 	tbnz	x0, #63, 9cb4 <fwp_hof0.constprop.0+0x12e4>
    99c4:	911882c1 	add	x1, x22, #0x620
    99c8:	f949d820 	ldr	x0, [x1, #5040]
    99cc:	f949ec23 	ldr	x3, [x1, #5080]
    99d0:	cb0002e0 	sub	x0, x23, x0
    99d4:	eb03401f 	cmp	x0, x3, lsl #16
    99d8:	540016c2 	b.cs	9cb0 <fwp_hof0.constprop.0+0x12e0>  // b.hs, b.nlast
    99dc:	d350fc03 	lsr	x3, x0, #16
    99e0:	d2800504 	mov	x4, #0x28                  	// #40
    99e4:	f949fc27 	ldr	x7, [x1, #5112]
    99e8:	9b047c63 	mul	x3, x3, x4
    99ec:	8b0300e4 	add	x4, x7, x3
    99f0:	f9401081 	ldr	x1, [x4, #32]
    99f4:	b40015e1 	cbz	x1, 9cb0 <fwp_hof0.constprop.0+0x12e0>
    99f8:	386368e3 	ldrb	w3, [x7, x3]
    99fc:	7100087f 	cmp	w3, #0x2
    9a00:	54001540 	b.eq	9ca8 <fwp_hof0.constprop.0+0x12d8>  // b.none
    9a04:	7100047f 	cmp	w3, #0x1
    9a08:	54001541 	b.ne	9cb0 <fwp_hof0.constprop.0+0x12e0>  // b.any
    9a0c:	29430c87 	ldp	w7, w3, [x4, #24]
    9a10:	92403c00 	and	x0, x0, #0xffff
    9a14:	9b077c00 	mul	x0, x0, x7
    9a18:	d360fc00 	lsr	x0, x0, #32
    9a1c:	eb03001f 	cmp	x0, x3
    9a20:	54001482 	b.cs	9cb0 <fwp_hof0.constprop.0+0x12e0>  // b.hs, b.nlast
    9a24:	8b000021 	add	x1, x1, x0
    9a28:	39400029 	ldrb	w9, [x1]
    9a2c:	7100053f 	cmp	w9, #0x1
    9a30:	54001401 	b.ne	9cb0 <fwp_hof0.constprop.0+0x12e0>  // b.any
    9a34:	910022e1 	add	x1, x23, #0x8
    9a38:	eb1a005f 	cmp	x2, x26
    9a3c:	9a9a9042 	csel	x2, x2, x26, ls	// ls = plast
    9a40:	b4005482 	cbz	x2, a4d0 <fwp_hof0.constprop.0+0x1b00>
    9a44:	d37df048 	lsl	x8, x2, #3
    9a48:	aa1903e3 	mov	x3, x25
    9a4c:	910022e7 	add	x7, x23, #0x8
    9a50:	d2800000 	mov	x0, #0x0                   	// #0
    9a54:	14000009 	b	9a78 <fwp_hof0.constprop.0+0x10a8>
    9a58:	fc606881 	ldr	d1, [x4, x0]
    9a5c:	fd400460 	ldr	d0, [x3, #8]
    9a60:	1e613800 	fsub	d0, d0, d1
    9a64:	fc206820 	str	d0, [x1, x0]
    9a68:	91002000 	add	x0, x0, #0x8
    9a6c:	f9400863 	ldr	x3, [x3, #16]
    9a70:	eb00011f 	cmp	x8, x0
    9a74:	54001540 	b.eq	9d1c <fwp_hof0.constprop.0+0x134c>  // b.none
    9a78:	f94002e5 	ldr	x5, [x23]
    9a7c:	aa0703e4 	mov	x4, x7
    9a80:	b6fffec5 	tbz	x5, #63, 9a58 <fwp_hof0.constprop.0+0x1088>
    9a84:	f9400ae4 	ldr	x4, [x23, #16]
    9a88:	17fffff4 	b	9a58 <fwp_hof0.constprop.0+0x1088>
    9a8c:	72003c5f 	tst	w2, #0xffff
    9a90:	54ffc6c1 	b.ne	9368 <fwp_hof0.constprop.0+0x998>  // b.any
    9a94:	17fffe75 	b	9468 <fwp_hof0.constprop.0+0xa98>
    9a98:	90000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    9a9c:	912f6000 	add	x0, x0, #0xbd8
    9aa0:	97ffea11 	bl	42e4 <fwp_trap>
    9aa4:	aa0803f7 	mov	x23, x8
    9aa8:	17ffff08 	b	96c8 <fwp_hof0.constprop.0+0xcf8>
    9aac:	aa1a03e0 	mov	x0, x26
    9ab0:	f90023e9 	str	x9, [sp, #64]
    9ab4:	f9002bea 	str	x10, [sp, #80]
    9ab8:	97ffea2b 	bl	4364 <fwp_rc_forget_slot.part.0>
    9abc:	f94023e9 	ldr	x9, [sp, #64]
    9ac0:	f9402bea 	ldr	x10, [sp, #80]
    9ac4:	17fffdc7 	b	91e0 <fwp_hof0.constprop.0+0x810>
    9ac8:	90000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    9acc:	91388000 	add	x0, x0, #0xe20
    9ad0:	97ffea05 	bl	42e4 <fwp_trap>
    9ad4:	72003c5f 	tst	w2, #0xffff
    9ad8:	54ffde41 	b.ne	96a0 <fwp_hof0.constprop.0+0xcd0>  // b.any
    9adc:	17fffee9 	b	9680 <fwp_hof0.constprop.0+0xcb0>
    9ae0:	d2800004 	mov	x4, #0x0                   	// #0
    9ae4:	f10002ff 	cmp	x23, #0x0
    9ae8:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    9aec:	54ffe1a1 	b.ne	9720 <fwp_hof0.constprop.0+0xd50>  // b.any
    9af0:	f9401fe6 	ldr	x6, [sp, #56]
    9af4:	91014294 	add	x20, x20, #0x50
    9af8:	f9405fe1 	ldr	x1, [sp, #184]
    9afc:	aa0603e0 	mov	x0, x6
    9b00:	f901c281 	str	x1, [x20, #896]
    9b04:	97ffe993 	bl	4150 <fwp_tape_buffers_release>
    9b08:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    9b0c:	f947e863 	ldr	x3, [x3, #4048]
    9b10:	d2800262 	mov	x2, #0x13                  	// #19
    9b14:	d2800021 	mov	x1, #0x1                   	// #1
    9b18:	90000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    9b1c:	91222000 	add	x0, x0, #0x888
    9b20:	f9400063 	ldr	x3, [x3]
    9b24:	97ffe38f 	bl	2960 <fwrite@plt>
    9b28:	d2800000 	mov	x0, #0x0                   	// #0
    9b2c:	97ffe399 	bl	2990 <fflush@plt>
    9b30:	52800cc0 	mov	w0, #0x66                  	// #102
    9b34:	97ffe3a7 	bl	29d0 <_Exit@plt>
    9b38:	aa1703e0 	mov	x0, x23
    9b3c:	97ffea0a 	bl	4364 <fwp_rc_forget_slot.part.0>
    9b40:	17fffe84 	b	9550 <fwp_hof0.constprop.0+0xb80>
    9b44:	ca404401 	eor	x1, x0, x0, lsr #17
    9b48:	911882c3 	add	x3, x22, #0x620
    9b4c:	ca412421 	eor	x1, x1, x1, lsr #9
    9b50:	92401c21 	and	x1, x1, #0xff
    9b54:	910a2422 	add	x2, x1, #0x289
    9b58:	8b010c61 	add	x1, x3, x1, lsl #3
    9b5c:	8b020c62 	add	x2, x3, x2, lsl #3
    9b60:	f94a2421 	ldr	x1, [x1, #5192]
    9b64:	b50000a1 	cbnz	x1, 9b78 <fwp_hof0.constprop.0+0x11a8>
    9b68:	17ffffcc 	b	9a98 <fwp_hof0.constprop.0+0x10c8>
    9b6c:	91004022 	add	x2, x1, #0x10
    9b70:	f9400821 	ldr	x1, [x1, #16]
    9b74:	b4fff921 	cbz	x1, 9a98 <fwp_hof0.constprop.0+0x10c8>
    9b78:	f9400023 	ldr	x3, [x1]
    9b7c:	eb00007f 	cmp	x3, x0
    9b80:	54ffff61 	b.ne	9b6c <fwp_hof0.constprop.0+0x119c>  // b.any
    9b84:	f9400042 	ldr	x2, [x2]
    9b88:	f9400441 	ldr	x1, [x2, #8]
    9b8c:	d1000421 	sub	x1, x1, #0x1
    9b90:	f9000441 	str	x1, [x2, #8]
    9b94:	f103f83f 	cmp	x1, #0xfe
    9b98:	54ffbe81 	b.ne	9368 <fwp_hof0.constprop.0+0x998>  // b.any
    9b9c:	39400001 	ldrb	w1, [x0]
    9ba0:	7103fc3f 	cmp	w1, #0xff
    9ba4:	540044e0 	b.eq	a440 <fwp_hof0.constprop.0+0x1a70>  // b.none
    9ba8:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9bac:	39000001 	strb	w1, [x0]
    9bb0:	17fffdee 	b	9368 <fwp_hof0.constprop.0+0x998>
    9bb4:	90000020 	adrp	x0, d000 <fwp_main_thread+0x42c>
    9bb8:	913fc000 	add	x0, x0, #0xff0
    9bbc:	97ffe9ca 	bl	42e4 <fwp_trap>
    9bc0:	aa0403e0 	mov	x0, x4
    9bc4:	d37df2e2 	lsl	x2, x23, #3
    9bc8:	52800001 	mov	w1, #0x0                   	// #0
    9bcc:	f90033e8 	str	x8, [sp, #96]
    9bd0:	97ffe318 	bl	2830 <memset@plt>
    9bd4:	aa0003e4 	mov	x4, x0
    9bd8:	f94033e8 	ldr	x8, [sp, #96]
    9bdc:	17fffed2 	b	9724 <fwp_hof0.constprop.0+0xd54>
    9be0:	b0000020 	adrp	x0, e000 <_IO_stdin_used+0x780>
    9be4:	91000000 	add	x0, x0, #0x0
    9be8:	97ffe9bf 	bl	42e4 <fwp_trap>
    9bec:	f9400b44 	ldr	x4, [x26, #16]
    9bf0:	17ffff63 	b	997c <fwp_hof0.constprop.0+0xfac>
    9bf4:	72003c1f 	tst	w0, #0xffff
    9bf8:	54ffea60 	b.eq	9944 <fwp_hof0.constprop.0+0xf74>  // b.none
    9bfc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9c00:	eb00005f 	cmp	x2, x0
    9c04:	54fffd88 	b.hi	9bb4 <fwp_hof0.constprop.0+0x11e4>  // b.pmore
    9c08:	91000440 	add	x0, x2, #0x1
    9c0c:	52800021 	mov	w1, #0x1                   	// #1
    9c10:	f9002be2 	str	x2, [sp, #80]
    9c14:	d37df000 	lsl	x0, x0, #3
    9c18:	97ffed2a 	bl	50c0 <fwp_heap_alloc>
    9c1c:	f9402be2 	ldr	x2, [sp, #80]
    9c20:	911882c4 	add	x4, x22, #0x620
    9c24:	f9000002 	str	x2, [x0]
    9c28:	aa0003f7 	mov	x23, x0
    9c2c:	f949d881 	ldr	x1, [x4, #5040]
    9c30:	f949ec80 	ldr	x0, [x4, #5080]
    9c34:	cb0102e1 	sub	x1, x23, x1
    9c38:	eb00403f 	cmp	x1, x0, lsl #16
    9c3c:	54000322 	b.cs	9ca0 <fwp_hof0.constprop.0+0x12d0>  // b.hs, b.nlast
    9c40:	d350fc23 	lsr	x3, x1, #16
    9c44:	d2800500 	mov	x0, #0x28                  	// #40
    9c48:	f949fc87 	ldr	x7, [x4, #5112]
    9c4c:	9b007c63 	mul	x3, x3, x0
    9c50:	8b0300e4 	add	x4, x7, x3
    9c54:	f9401080 	ldr	x0, [x4, #32]
    9c58:	b4000240 	cbz	x0, 9ca0 <fwp_hof0.constprop.0+0x12d0>
    9c5c:	386368e3 	ldrb	w3, [x7, x3]
    9c60:	7100087f 	cmp	w3, #0x2
    9c64:	54003dc0 	b.eq	a41c <fwp_hof0.constprop.0+0x1a4c>  // b.none
    9c68:	7100047f 	cmp	w3, #0x1
    9c6c:	540001a1 	b.ne	9ca0 <fwp_hof0.constprop.0+0x12d0>  // b.any
    9c70:	29430c87 	ldp	w7, w3, [x4, #24]
    9c74:	92403c21 	and	x1, x1, #0xffff
    9c78:	9b077c21 	mul	x1, x1, x7
    9c7c:	d360fc21 	lsr	x1, x1, #32
    9c80:	eb03003f 	cmp	x1, x3
    9c84:	540000e2 	b.cs	9ca0 <fwp_hof0.constprop.0+0x12d0>  // b.hs, b.nlast
    9c88:	8b010000 	add	x0, x0, x1
    9c8c:	39400001 	ldrb	w1, [x0]
    9c90:	7103fc3f 	cmp	w1, #0xff
    9c94:	54003b80 	b.eq	a404 <fwp_hof0.constprop.0+0x1a34>  // b.none
    9c98:	52800021 	mov	w1, #0x1                   	// #1
    9c9c:	39000001 	strb	w1, [x0]
    9ca0:	aa1a03e0 	mov	x0, x26
    9ca4:	17ffff2d 	b	9958 <fwp_hof0.constprop.0+0xf88>
    9ca8:	72003c1f 	tst	w0, #0xffff
    9cac:	54ffebe0 	b.eq	9a28 <fwp_hof0.constprop.0+0x1058>  // b.none
    9cb0:	b4004079 	cbz	x25, a4bc <fwp_hof0.constprop.0+0x1aec>
    9cb4:	aa1903e1 	mov	x1, x25
    9cb8:	d280001a 	mov	x26, #0x0                   	// #0
    9cbc:	f9400821 	ldr	x1, [x1, #16]
    9cc0:	aa1a03e0 	mov	x0, x26
    9cc4:	9100075a 	add	x26, x26, #0x1
    9cc8:	b5ffffa1 	cbnz	x1, 9cbc <fwp_hof0.constprop.0+0x12ec>
    9ccc:	f9002be2 	str	x2, [sp, #80]
    9cd0:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9cd4:	eb01035f 	cmp	x26, x1
    9cd8:	54ff8fa8 	b.hi	8ecc <fwp_hof0.constprop.0+0x4fc>  // b.pmore
    9cdc:	91000800 	add	x0, x0, #0x2
    9ce0:	52800041 	mov	w1, #0x2                   	// #2
    9ce4:	d37df000 	lsl	x0, x0, #3
    9ce8:	97ffecf6 	bl	50c0 <fwp_heap_alloc>
    9cec:	f9402be2 	ldr	x2, [sp, #80]
    9cf0:	aa1903e3 	mov	x3, x25
    9cf4:	aa0003e1 	mov	x1, x0
    9cf8:	f9400464 	ldr	x4, [x3, #8]
    9cfc:	f8008404 	str	x4, [x0], #8
    9d00:	f9400863 	ldr	x3, [x3, #16]
    9d04:	b5ffffa3 	cbnz	x3, 9cf8 <fwp_hof0.constprop.0+0x1328>
    9d08:	52800009 	mov	w9, #0x0                   	// #0
    9d0c:	17ffff4b 	b	9a38 <fwp_hof0.constprop.0+0x1068>
    9d10:	72003c3f 	tst	w1, #0xffff
    9d14:	54ffdd01 	b.ne	98b4 <fwp_hof0.constprop.0+0xee4>  // b.any
    9d18:	17fffee2 	b	98a0 <fwp_hof0.constprop.0+0xed0>
    9d1c:	b4002db9 	cbz	x25, a2d0 <fwp_hof0.constprop.0+0x1900>
    9d20:	911882c0 	add	x0, x22, #0x620
    9d24:	aa1903e8 	mov	x8, x25
    9d28:	d2800007 	mov	x7, #0x0                   	// #0
    9d2c:	f949ec0a 	ldr	x10, [x0, #5080]
    9d30:	f949d80c 	ldr	x12, [x0, #5040]
    9d34:	f949fc0d 	ldr	x13, [x0, #5112]
    9d38:	d370bd4a 	lsl	x10, x10, #16
    9d3c:	14000006 	b	9d54 <fwp_hof0.constprop.0+0x1384>
    9d40:	f9400908 	ldr	x8, [x8, #16]
    9d44:	910004e7 	add	x7, x7, #0x1
    9d48:	f100011f 	cmp	x8, #0x0
    9d4c:	fa471040 	ccmp	x2, x7, #0x0, ne	// ne = any
    9d50:	54000329 	b.ls	9db4 <fwp_hof0.constprop.0+0x13e4>  // b.plast
    9d54:	cb0c0100 	sub	x0, x8, x12
    9d58:	eb0a001f 	cmp	x0, x10
    9d5c:	540002c2 	b.cs	9db4 <fwp_hof0.constprop.0+0x13e4>  // b.hs, b.nlast
    9d60:	d350fc03 	lsr	x3, x0, #16
    9d64:	8b030863 	add	x3, x3, x3, lsl #2
    9d68:	d37df063 	lsl	x3, x3, #3
    9d6c:	8b0301a5 	add	x5, x13, x3
    9d70:	f94010a4 	ldr	x4, [x5, #32]
    9d74:	b4000204 	cbz	x4, 9db4 <fwp_hof0.constprop.0+0x13e4>
    9d78:	386369a3 	ldrb	w3, [x13, x3]
    9d7c:	7100087f 	cmp	w3, #0x2
    9d80:	54002580 	b.eq	a230 <fwp_hof0.constprop.0+0x1860>  // b.none
    9d84:	7100047f 	cmp	w3, #0x1
    9d88:	54000161 	b.ne	9db4 <fwp_hof0.constprop.0+0x13e4>  // b.any
    9d8c:	29430ca6 	ldp	w6, w3, [x5, #24]
    9d90:	92403c00 	and	x0, x0, #0xffff
    9d94:	9b067c00 	mul	x0, x0, x6
    9d98:	d360fc00 	lsr	x0, x0, #32
    9d9c:	eb03001f 	cmp	x0, x3
    9da0:	540000a2 	b.cs	9db4 <fwp_hof0.constprop.0+0x13e4>  // b.hs, b.nlast
    9da4:	8b000084 	add	x4, x4, x0
    9da8:	39400080 	ldrb	w0, [x4]
    9dac:	7100041f 	cmp	w0, #0x1
    9db0:	54fffc80 	b.eq	9d40 <fwp_hof0.constprop.0+0x1370>  // b.none
    9db4:	d2800003 	mov	x3, #0x0                   	// #0
    9db8:	eb07005f 	cmp	x2, x7
    9dbc:	54003029 	b.ls	a3c0 <fwp_hof0.constprop.0+0x19f0>  // b.plast
    9dc0:	d1002020 	sub	x0, x1, #0x8
    9dc4:	911882da 	add	x26, x22, #0x620
    9dc8:	f90023e0 	str	x0, [sp, #64]
    9dcc:	9103e3e0 	add	x0, sp, #0xf8
    9dd0:	f9002be0 	str	x0, [sp, #80]
    9dd4:	aa1a03e0 	mov	x0, x26
    9dd8:	d2800003 	mov	x3, #0x0                   	// #0
    9ddc:	aa1503fa 	mov	x26, x21
    9de0:	aa0003f5 	mov	x21, x0
    9de4:	a90587f9 	stp	x25, x1, [sp, #88]
    9de8:	aa0703f9 	mov	x25, x7
    9dec:	b9006be9 	str	w9, [sp, #104]
    9df0:	a9074fe2 	stp	x2, x19, [sp, #112]
    9df4:	aa0203f3 	mov	x19, x2
    9df8:	14000012 	b	9e40 <fwp_hof0.constprop.0+0x1470>
    9dfc:	7100045f 	cmp	w2, #0x1
    9e00:	540001a1 	b.ne	9e34 <fwp_hof0.constprop.0+0x1464>  // b.any
    9e04:	29430886 	ldp	w6, w2, [x4, #24]
    9e08:	92403c21 	and	x1, x1, #0xffff
    9e0c:	9b067c21 	mul	x1, x1, x6
    9e10:	d360fc21 	lsr	x1, x1, #32
    9e14:	eb02003f 	cmp	x1, x2
    9e18:	540000e2 	b.cs	9e34 <fwp_hof0.constprop.0+0x1464>  // b.hs, b.nlast
    9e1c:	8b010000 	add	x0, x0, x1
    9e20:	39400001 	ldrb	w1, [x0]
    9e24:	7103fc3f 	cmp	w1, #0xff
    9e28:	54002e60 	b.eq	a3f4 <fwp_hof0.constprop.0+0x1a24>  // b.none
    9e2c:	52800021 	mov	w1, #0x1                   	// #1
    9e30:	39000001 	strb	w1, [x0]
    9e34:	d1000673 	sub	x19, x19, #0x1
    9e38:	eb19027f 	cmp	x19, x25
    9e3c:	54000349 	b.ls	9ea4 <fwp_hof0.constprop.0+0x14d4>  // b.plast
    9e40:	f94023e0 	ldr	x0, [sp, #64]
    9e44:	f9402be1 	ldr	x1, [sp, #80]
    9e48:	f8737800 	ldr	x0, [x0, x19, lsl #3]
    9e4c:	a90f8fe0 	stp	x0, x3, [sp, #248]
    9e50:	52800020 	mov	w0, #0x1                   	// #1
    9e54:	97ffecff 	bl	5250 <fwp_data.part.0.constprop.0>
    9e58:	aa0003e3 	mov	x3, x0
    9e5c:	f949daa1 	ldr	x1, [x21, #5040]
    9e60:	f949eea0 	ldr	x0, [x21, #5080]
    9e64:	cb010061 	sub	x1, x3, x1
    9e68:	eb00403f 	cmp	x1, x0, lsl #16
    9e6c:	54fffe42 	b.cs	9e34 <fwp_hof0.constprop.0+0x1464>  // b.hs, b.nlast
    9e70:	d350fc20 	lsr	x0, x1, #16
    9e74:	f949fea6 	ldr	x6, [x21, #5112]
    9e78:	8b000800 	add	x0, x0, x0, lsl #2
    9e7c:	d37df002 	lsl	x2, x0, #3
    9e80:	8b0200c4 	add	x4, x6, x2
    9e84:	f9401080 	ldr	x0, [x4, #32]
    9e88:	b4fffd60 	cbz	x0, 9e34 <fwp_hof0.constprop.0+0x1464>
    9e8c:	386268c2 	ldrb	w2, [x6, x2]
    9e90:	7100085f 	cmp	w2, #0x2
    9e94:	54fffb41 	b.ne	9dfc <fwp_hof0.constprop.0+0x142c>  // b.any
    9e98:	72003c3f 	tst	w1, #0xffff
    9e9c:	54fffcc1 	b.ne	9e34 <fwp_hof0.constprop.0+0x1464>  // b.any
    9ea0:	17ffffe0 	b	9e20 <fwp_hof0.constprop.0+0x1450>
    9ea4:	a9474fe2 	ldp	x2, x19, [sp, #112]
    9ea8:	aa1903e7 	mov	x7, x25
    9eac:	a94587f9 	ldp	x25, x1, [sp, #88]
    9eb0:	aa1a03f5 	mov	x21, x26
    9eb4:	b9406be9 	ldr	w9, [sp, #104]
    9eb8:	d1000444 	sub	x4, x2, #0x1
    9ebc:	cb0200e0 	sub	x0, x7, x2
    9ec0:	eb07009f 	cmp	x4, x7
    9ec4:	9a8037e0 	csinc	x0, xzr, x0, cc	// cc = lo, ul, last
    9ec8:	8b040000 	add	x0, x0, x4
    9ecc:	b50027a7 	cbnz	x7, a3c0 <fwp_hof0.constprop.0+0x19f0>
    9ed0:	7100013f 	cmp	w9, #0x0
    9ed4:	9a8113e8 	csel	x8, xzr, x1, ne	// ne = any
    9ed8:	b4002640 	cbz	x0, a3a0 <fwp_hof0.constprop.0+0x19d0>
    9edc:	d1000404 	sub	x4, x0, #0x1
    9ee0:	911882da 	add	x26, x22, #0x620
    9ee4:	f90023f7 	str	x23, [sp, #64]
    9ee8:	aa1a03f7 	mov	x23, x26
    9eec:	a905d7f3 	stp	x19, x21, [sp, #88]
    9ef0:	aa0803f3 	mov	x19, x8
    9ef4:	aa0403f5 	mov	x21, x4
    9ef8:	14000012 	b	9f40 <fwp_hof0.constprop.0+0x1570>
    9efc:	7100045f 	cmp	w2, #0x1
    9f00:	540001a1 	b.ne	9f34 <fwp_hof0.constprop.0+0x1564>  // b.any
    9f04:	29430002 	ldp	w2, w0, [x0, #24]
    9f08:	92403c21 	and	x1, x1, #0xffff
    9f0c:	9b027c21 	mul	x1, x1, x2
    9f10:	d360fc21 	lsr	x1, x1, #32
    9f14:	eb00003f 	cmp	x1, x0
    9f18:	540000e2 	b.cs	9f34 <fwp_hof0.constprop.0+0x1564>  // b.hs, b.nlast
    9f1c:	8b01035a 	add	x26, x26, x1
    9f20:	39400340 	ldrb	w0, [x26]
    9f24:	7103fc1f 	cmp	w0, #0xff
    9f28:	54002420 	b.eq	a3ac <fwp_hof0.constprop.0+0x19dc>  // b.none
    9f2c:	52800020 	mov	w0, #0x1                   	// #1
    9f30:	39000340 	strb	w0, [x26]
    9f34:	d10006b5 	sub	x21, x21, #0x1
    9f38:	b10006bf 	cmn	x21, #0x1
    9f3c:	54000320 	b.eq	9fa0 <fwp_hof0.constprop.0+0x15d0>  // b.none
    9f40:	f9402be1 	ldr	x1, [sp, #80]
    9f44:	f8757a60 	ldr	x0, [x19, x21, lsl #3]
    9f48:	a90f8fe0 	stp	x0, x3, [sp, #248]
    9f4c:	52800020 	mov	w0, #0x1                   	// #1
    9f50:	97ffecc0 	bl	5250 <fwp_data.part.0.constprop.0>
    9f54:	aa0003e3 	mov	x3, x0
    9f58:	f949dae1 	ldr	x1, [x23, #5040]
    9f5c:	f949eee0 	ldr	x0, [x23, #5080]
    9f60:	cb010061 	sub	x1, x3, x1
    9f64:	eb00403f 	cmp	x1, x0, lsl #16
    9f68:	54fffe62 	b.cs	9f34 <fwp_hof0.constprop.0+0x1564>  // b.hs, b.nlast
    9f6c:	d350fc20 	lsr	x0, x1, #16
    9f70:	f949fee6 	ldr	x6, [x23, #5112]
    9f74:	8b000800 	add	x0, x0, x0, lsl #2
    9f78:	d37df002 	lsl	x2, x0, #3
    9f7c:	8b0200c0 	add	x0, x6, x2
    9f80:	f940101a 	ldr	x26, [x0, #32]
    9f84:	b4fffd9a 	cbz	x26, 9f34 <fwp_hof0.constprop.0+0x1564>
    9f88:	386268c2 	ldrb	w2, [x6, x2]
    9f8c:	7100085f 	cmp	w2, #0x2
    9f90:	54fffb61 	b.ne	9efc <fwp_hof0.constprop.0+0x152c>  // b.any
    9f94:	72003c3f 	tst	w1, #0xffff
    9f98:	54fffce1 	b.ne	9f34 <fwp_hof0.constprop.0+0x1564>  // b.any
    9f9c:	17ffffe1 	b	9f20 <fwp_hof0.constprop.0+0x1550>
    9fa0:	aa1303e8 	mov	x8, x19
    9fa4:	aa1903fa 	mov	x26, x25
    9fa8:	a945d7f3 	ldp	x19, x21, [sp, #88]
    9fac:	aa0303f9 	mov	x25, x3
    9fb0:	f94023f7 	ldr	x23, [sp, #64]
    9fb4:	aa0803e0 	mov	x0, x8
    9fb8:	97ffe986 	bl	45d0 <fwp_mem_free>
    9fbc:	f9002bf5 	str	x21, [sp, #80]
    9fc0:	911882c4 	add	x4, x22, #0x620
    9fc4:	aa1303f5 	mov	x21, x19
    9fc8:	aa0403f3 	mov	x19, x4
    9fcc:	d2800507 	mov	x7, #0x28                  	// #40
    9fd0:	f949da61 	ldr	x1, [x19, #5040]
    9fd4:	f949ee60 	ldr	x0, [x19, #5080]
    9fd8:	cb0102e1 	sub	x1, x23, x1
    9fdc:	eb00403f 	cmp	x1, x0, lsl #16
    9fe0:	54001222 	b.cs	a224 <fwp_hof0.constprop.0+0x1854>  // b.hs, b.nlast
    9fe4:	d350fc22 	lsr	x2, x1, #16
    9fe8:	f949fe63 	ldr	x3, [x19, #5112]
    9fec:	9b077c42 	mul	x2, x2, x7
    9ff0:	8b020068 	add	x8, x3, x2
    9ff4:	f9401100 	ldr	x0, [x8, #32]
    9ff8:	b4001160 	cbz	x0, a224 <fwp_hof0.constprop.0+0x1854>
    9ffc:	38626863 	ldrb	w3, [x3, x2]
    a000:	7100087f 	cmp	w3, #0x2
    a004:	540010c0 	b.eq	a21c <fwp_hof0.constprop.0+0x184c>  // b.none
    a008:	7100047f 	cmp	w3, #0x1
    a00c:	540010c1 	b.ne	a224 <fwp_hof0.constprop.0+0x1854>  // b.any
    a010:	29431502 	ldp	w2, w5, [x8, #24]
    a014:	92403c21 	and	x1, x1, #0xffff
    a018:	9b027c22 	mul	x2, x1, x2
    a01c:	d360fc42 	lsr	x2, x2, #32
    a020:	eb05005f 	cmp	x2, x5
    a024:	54001002 	b.cs	a224 <fwp_hof0.constprop.0+0x1854>  // b.hs, b.nlast
    a028:	8b020000 	add	x0, x0, x2
    a02c:	39400002 	ldrb	w2, [x0]
    a030:	34000fa2 	cbz	w2, a224 <fwp_hof0.constprop.0+0x1854>
    a034:	7100045f 	cmp	w2, #0x1
    a038:	54000d60 	b.eq	a1e4 <fwp_hof0.constprop.0+0x1814>  // b.none
    a03c:	aa1503f3 	mov	x19, x21
    a040:	f9402bf5 	ldr	x21, [sp, #80]
    a044:	7103fc5f 	cmp	w2, #0xff
    a048:	540020e0 	b.eq	a464 <fwp_hof0.constprop.0+0x1a94>  // b.none
    a04c:	51000442 	sub	w2, w2, #0x1
    a050:	39000002 	strb	w2, [x0]
    a054:	911882c4 	add	x4, x22, #0x620
    a058:	f9002bf5 	str	x21, [sp, #80]
    a05c:	aa1303f5 	mov	x21, x19
    a060:	aa0403f3 	mov	x19, x4
    a064:	d2800507 	mov	x7, #0x28                  	// #40
    a068:	f949da60 	ldr	x0, [x19, #5040]
    a06c:	f949ee61 	ldr	x1, [x19, #5080]
    a070:	cb000340 	sub	x0, x26, x0
    a074:	eb01401f 	cmp	x0, x1, lsl #16
    a078:	54000b02 	b.cs	a1d8 <fwp_hof0.constprop.0+0x1808>  // b.hs, b.nlast
    a07c:	d350fc01 	lsr	x1, x0, #16
    a080:	f949fe62 	ldr	x2, [x19, #5112]
    a084:	9b077c21 	mul	x1, x1, x7
    a088:	8b010043 	add	x3, x2, x1
    a08c:	f9401077 	ldr	x23, [x3, #32]
    a090:	b4000a57 	cbz	x23, a1d8 <fwp_hof0.constprop.0+0x1808>
    a094:	38616845 	ldrb	w5, [x2, x1]
    a098:	710008bf 	cmp	w5, #0x2
    a09c:	540009a0 	b.eq	a1d0 <fwp_hof0.constprop.0+0x1800>  // b.none
    a0a0:	710004bf 	cmp	w5, #0x1
    a0a4:	540009a1 	b.ne	a1d8 <fwp_hof0.constprop.0+0x1808>  // b.any
    a0a8:	29430861 	ldp	w1, w2, [x3, #24]
    a0ac:	92403c00 	and	x0, x0, #0xffff
    a0b0:	9b017c01 	mul	x1, x0, x1
    a0b4:	d360fc21 	lsr	x1, x1, #32
    a0b8:	eb02003f 	cmp	x1, x2
    a0bc:	540008e2 	b.cs	a1d8 <fwp_hof0.constprop.0+0x1808>  // b.hs, b.nlast
    a0c0:	8b0102f7 	add	x23, x23, x1
    a0c4:	394002e2 	ldrb	w2, [x23]
    a0c8:	34000882 	cbz	w2, a1d8 <fwp_hof0.constprop.0+0x1808>
    a0cc:	7100045f 	cmp	w2, #0x1
    a0d0:	54001280 	b.eq	a320 <fwp_hof0.constprop.0+0x1950>  // b.none
    a0d4:	aa1503f3 	mov	x19, x21
    a0d8:	f9402bf5 	ldr	x21, [sp, #80]
    a0dc:	7103fc5f 	cmp	w2, #0xff
    a0e0:	54001020 	b.eq	a2e4 <fwp_hof0.constprop.0+0x1914>  // b.none
    a0e4:	51000442 	sub	w2, w2, #0x1
    a0e8:	390002e2 	strb	w2, [x23]
    a0ec:	f9400fe0 	ldr	x0, [sp, #24]
    a0f0:	b4ff70a0 	cbz	x0, 8f04 <fwp_hof0.constprop.0+0x534>
    a0f4:	f9400fe0 	ldr	x0, [sp, #24]
    a0f8:	f1000400 	subs	x0, x0, #0x1
    a0fc:	f9000fe0 	str	x0, [sp, #24]
    a100:	54002286 	b.vs	a550 <fwp_hof0.constprop.0+0x1b80>
    a104:	911882c0 	add	x0, x22, #0x620
    a108:	f949ec04 	ldr	x4, [x0, #5080]
    a10c:	f949d801 	ldr	x1, [x0, #5040]
    a110:	d370bc84 	lsl	x4, x4, #16
    a114:	17fffa7b 	b	8b00 <fwp_hof0.constprop.0+0x130>
    a118:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x780>
    a11c:	9100a000 	add	x0, x0, #0x28
    a120:	97ffe871 	bl	42e4 <fwp_trap>
    a124:	aa1a03e0 	mov	x0, x26
    a128:	97ffef5a 	bl	5e90 <fwp_rc_free_arr>
    a12c:	17fffbeb 	b	90d8 <fwp_hof0.constprop.0+0x708>
    a130:	72003c3f 	tst	w1, #0xffff
    a134:	54ff7d21 	b.ne	90d8 <fwp_hof0.constprop.0+0x708>  // b.any
    a138:	17fffbe0 	b	90b8 <fwp_hof0.constprop.0+0x6e8>
    a13c:	72003c3f 	tst	w1, #0xffff
    a140:	54ff7701 	b.ne	9020 <fwp_hof0.constprop.0+0x650>  // b.any
    a144:	17fffbb2 	b	900c <fwp_hof0.constprop.0+0x63c>
    a148:	f9000fe0 	str	x0, [sp, #24]
    a14c:	f90017e3 	str	x3, [sp, #40]
    a150:	97ffe885 	bl	4364 <fwp_rc_forget_slot.part.0>
    a154:	f9400fe0 	ldr	x0, [sp, #24]
    a158:	f94017e3 	ldr	x3, [sp, #40]
    a15c:	17fffbaf 	b	9018 <fwp_hof0.constprop.0+0x648>
    a160:	ca5546a1 	eor	x1, x21, x21, lsr #17
    a164:	911882c2 	add	x2, x22, #0x620
    a168:	ca412421 	eor	x1, x1, x1, lsr #9
    a16c:	92401c21 	and	x1, x1, #0xff
    a170:	910a2420 	add	x0, x1, #0x289
    a174:	8b010c41 	add	x1, x2, x1, lsl #3
    a178:	8b000c40 	add	x0, x2, x0, lsl #3
    a17c:	f94a2421 	ldr	x1, [x1, #5192]
    a180:	b50000a1 	cbnz	x1, a194 <fwp_hof0.constprop.0+0x17c4>
    a184:	17fffe45 	b	9a98 <fwp_hof0.constprop.0+0x10c8>
    a188:	91004020 	add	x0, x1, #0x10
    a18c:	f9400821 	ldr	x1, [x1, #16]
    a190:	b4ffc841 	cbz	x1, 9a98 <fwp_hof0.constprop.0+0x10c8>
    a194:	f9400022 	ldr	x2, [x1]
    a198:	eb0202bf 	cmp	x21, x2
    a19c:	54ffff61 	b.ne	a188 <fwp_hof0.constprop.0+0x17b8>  // b.any
    a1a0:	f9400001 	ldr	x1, [x0]
    a1a4:	f9400420 	ldr	x0, [x1, #8]
    a1a8:	d1000400 	sub	x0, x0, #0x1
    a1ac:	f9000420 	str	x0, [x1, #8]
    a1b0:	f103f81f 	cmp	x0, #0xfe
    a1b4:	54ff7921 	b.ne	90d8 <fwp_hof0.constprop.0+0x708>  // b.any
    a1b8:	394002a0 	ldrb	w0, [x21]
    a1bc:	7103fc1f 	cmp	w0, #0xff
    a1c0:	54000e40 	b.eq	a388 <fwp_hof0.constprop.0+0x19b8>  // b.none
    a1c4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a1c8:	390002a0 	strb	w0, [x21]
    a1cc:	17fffbc3 	b	90d8 <fwp_hof0.constprop.0+0x708>
    a1d0:	f2403c00 	ands	x0, x0, #0xffff
    a1d4:	54fff780 	b.eq	a0c4 <fwp_hof0.constprop.0+0x16f4>  // b.none
    a1d8:	aa1503f3 	mov	x19, x21
    a1dc:	f9402bf5 	ldr	x21, [sp, #80]
    a1e0:	17ffffc3 	b	a0ec <fwp_hof0.constprop.0+0x171c>
    a1e4:	f94002e2 	ldr	x2, [x23]
    a1e8:	aa1703e0 	mov	x0, x23
    a1ec:	b7f81782 	tbnz	x2, #63, a4dc <fwp_hof0.constprop.0+0x1b0c>
    a1f0:	aa1503f3 	mov	x19, x21
    a1f4:	f9402bf5 	ldr	x21, [sp, #80]
    a1f8:	7100087f 	cmp	w3, #0x2
    a1fc:	54001520 	b.eq	a4a0 <fwp_hof0.constprop.0+0x1ad0>  // b.none
    a200:	29430102 	ldp	w2, w0, [x8, #24]
    a204:	9b027c21 	mul	x1, x1, x2
    a208:	eb41801f 	cmp	x0, x1, lsr #32
    a20c:	54fff249 	b.ls	a054 <fwp_hof0.constprop.0+0x1684>  // b.plast
    a210:	aa1703e0 	mov	x0, x23
    a214:	97ffe8ef 	bl	45d0 <fwp_mem_free>
    a218:	17ffff8f 	b	a054 <fwp_hof0.constprop.0+0x1684>
    a21c:	f2403c21 	ands	x1, x1, #0xffff
    a220:	54fff060 	b.eq	a02c <fwp_hof0.constprop.0+0x165c>  // b.none
    a224:	aa1503f3 	mov	x19, x21
    a228:	f9402bf5 	ldr	x21, [sp, #80]
    a22c:	17ffff8a 	b	a054 <fwp_hof0.constprop.0+0x1684>
    a230:	72003c1f 	tst	w0, #0xffff
    a234:	54ffdc01 	b.ne	9db4 <fwp_hof0.constprop.0+0x13e4>  // b.any
    a238:	17fffedc 	b	9da8 <fwp_hof0.constprop.0+0x13d8>
    a23c:	d1000521 	sub	x1, x9, #0x1
    a240:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    a244:	eb00003f 	cmp	x1, x0
    a248:	540003e8 	b.hi	a2c4 <fwp_hof0.constprop.0+0x18f4>  // b.pmore
    a24c:	d00002a0 	adrp	x0, 60000 <ad_raw_checkpoints+0x2fbc0>
    a250:	d2800003 	mov	x3, #0x0                   	// #0
    a254:	91110001 	add	x1, x0, #0x440
    a258:	14000005 	b	a26c <fwp_hof0.constprop.0+0x189c>
    a25c:	91000463 	add	x3, x3, #0x1
    a260:	91006021 	add	x1, x1, #0x18
    a264:	f140047f 	cmp	x3, #0x1, lsl #12
    a268:	54000380 	b.eq	a2d8 <fwp_hof0.constprop.0+0x1908>  // b.none
    a26c:	f9400022 	ldr	x2, [x1]
    a270:	b5ffff62 	cbnz	x2, a25c <fwp_hof0.constprop.0+0x188c>
    a274:	91110002 	add	x2, x0, #0x440
    a278:	d2800304 	mov	x4, #0x18                  	// #24
    a27c:	aa0903e0 	mov	x0, x9
    a280:	d2800101 	mov	x1, #0x8                   	// #8
    a284:	a90623e9 	stp	x9, x8, [sp, #96]
    a288:	9b04087a 	madd	x26, x3, x4, x2
    a28c:	97ffe16d 	bl	2840 <calloc@plt>
    a290:	aa0003e4 	mov	x4, x0
    a294:	a94623e9 	ldp	x9, x8, [sp, #96]
    a298:	b4ffc240 	cbz	x0, 9ae0 <fwp_hof0.constprop.0+0x1110>
    a29c:	d37df122 	lsl	x2, x9, #3
    a2a0:	aa0403e1 	mov	x1, x4
    a2a4:	aa1a03e0 	mov	x0, x26
    a2a8:	52800063 	mov	w3, #0x3                   	// #3
    a2ac:	a90627e4 	stp	x4, x9, [sp, #96]
    a2b0:	f9003be8 	str	x8, [sp, #112]
    a2b4:	97ffe327 	bl	2f50 <ad_raw_record>
    a2b8:	a94627e4 	ldp	x4, x9, [sp, #96]
    a2bc:	f9403be8 	ldr	x8, [sp, #112]
    a2c0:	17fffd16 	b	9718 <fwp_hof0.constprop.0+0xd48>
    a2c4:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x42c>
    a2c8:	913f4000 	add	x0, x0, #0xfd0
    a2cc:	97ffe41d 	bl	3340 <ad_raw_fail>
    a2d0:	d2800007 	mov	x7, #0x0                   	// #0
    a2d4:	17fffebb 	b	9dc0 <fwp_hof0.constprop.0+0x13f0>
    a2d8:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x42c>
    a2dc:	912c2000 	add	x0, x0, #0xb08
    a2e0:	97ffe418 	bl	3340 <ad_raw_fail>
    a2e4:	ca5746e1 	eor	x1, x23, x23, lsr #17
    a2e8:	911882c0 	add	x0, x22, #0x620
    a2ec:	ca412421 	eor	x1, x1, x1, lsr #9
    a2f0:	92401c21 	and	x1, x1, #0xff
    a2f4:	910a2422 	add	x2, x1, #0x289
    a2f8:	8b010c01 	add	x1, x0, x1, lsl #3
    a2fc:	8b020c02 	add	x2, x0, x2, lsl #3
    a300:	f94a2420 	ldr	x0, [x1, #5192]
    a304:	b4ffbca0 	cbz	x0, 9a98 <fwp_hof0.constprop.0+0x10c8>
    a308:	f9400001 	ldr	x1, [x0]
    a30c:	eb17003f 	cmp	x1, x23
    a310:	54000240 	b.eq	a358 <fwp_hof0.constprop.0+0x1988>  // b.none
    a314:	91004002 	add	x2, x0, #0x10
    a318:	f9400800 	ldr	x0, [x0, #16]
    a31c:	17fffffa 	b	a304 <fwp_hof0.constprop.0+0x1934>
    a320:	aa1a03e1 	mov	x1, x26
    a324:	f9400b5a 	ldr	x26, [x26, #16]
    a328:	710008bf 	cmp	w5, #0x2
    a32c:	54000120 	b.eq	a350 <fwp_hof0.constprop.0+0x1980>  // b.none
    a330:	29430865 	ldp	w5, w2, [x3, #24]
    a334:	9b057c00 	mul	x0, x0, x5
    a338:	eb40805f 	cmp	x2, x0, lsr #32
    a33c:	54ffe969 	b.ls	a068 <fwp_hof0.constprop.0+0x1698>  // b.plast
    a340:	aa0103e0 	mov	x0, x1
    a344:	97ffe8a3 	bl	45d0 <fwp_mem_free>
    a348:	d2800507 	mov	x7, #0x28                  	// #40
    a34c:	17ffff47 	b	a068 <fwp_hof0.constprop.0+0x1698>
    a350:	b5ffe8c0 	cbnz	x0, a068 <fwp_hof0.constprop.0+0x1698>
    a354:	17fffffb 	b	a340 <fwp_hof0.constprop.0+0x1970>
    a358:	f9400041 	ldr	x1, [x2]
    a35c:	f9400420 	ldr	x0, [x1, #8]
    a360:	d1000400 	sub	x0, x0, #0x1
    a364:	f9000420 	str	x0, [x1, #8]
    a368:	f103f81f 	cmp	x0, #0xfe
    a36c:	54ffec01 	b.ne	a0ec <fwp_hof0.constprop.0+0x171c>  // b.any
    a370:	394002e0 	ldrb	w0, [x23]
    a374:	7103fc1f 	cmp	w0, #0xff
    a378:	540000e0 	b.eq	a394 <fwp_hof0.constprop.0+0x19c4>  // b.none
    a37c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a380:	390002e0 	strb	w0, [x23]
    a384:	17ffff5a 	b	a0ec <fwp_hof0.constprop.0+0x171c>
    a388:	aa1503e0 	mov	x0, x21
    a38c:	97ffe7f6 	bl	4364 <fwp_rc_forget_slot.part.0>
    a390:	17ffff8d 	b	a1c4 <fwp_hof0.constprop.0+0x17f4>
    a394:	aa1703e0 	mov	x0, x23
    a398:	97ffe7f3 	bl	4364 <fwp_rc_forget_slot.part.0>
    a39c:	17fffff8 	b	a37c <fwp_hof0.constprop.0+0x19ac>
    a3a0:	aa1903fa 	mov	x26, x25
    a3a4:	aa0303f9 	mov	x25, x3
    a3a8:	17ffff03 	b	9fb4 <fwp_hof0.constprop.0+0x15e4>
    a3ac:	aa1a03e0 	mov	x0, x26
    a3b0:	f90037e3 	str	x3, [sp, #104]
    a3b4:	97ffe7ec 	bl	4364 <fwp_rc_forget_slot.part.0>
    a3b8:	f94037e3 	ldr	x3, [sp, #104]
    a3bc:	17fffedc 	b	9f2c <fwp_hof0.constprop.0+0x155c>
    a3c0:	aa1903fa 	mov	x26, x25
    a3c4:	d2800000 	mov	x0, #0x0                   	// #0
    a3c8:	f8607822 	ldr	x2, [x1, x0, lsl #3]
    a3cc:	91000400 	add	x0, x0, #0x1
    a3d0:	f9000742 	str	x2, [x26, #8]
    a3d4:	aa1a03e2 	mov	x2, x26
    a3d8:	f9400b5a 	ldr	x26, [x26, #16]
    a3dc:	eb0000ff 	cmp	x7, x0
    a3e0:	54ffff48 	b.hi	a3c8 <fwp_hof0.constprop.0+0x19f8>  // b.pmore
    a3e4:	f9000843 	str	x3, [x2, #16]
    a3e8:	7100013f 	cmp	w9, #0x0
    a3ec:	9a8113e8 	csel	x8, xzr, x1, ne	// ne = any
    a3f0:	17fffef1 	b	9fb4 <fwp_hof0.constprop.0+0x15e4>
    a3f4:	a9080fe0 	stp	x0, x3, [sp, #128]
    a3f8:	97ffe7db 	bl	4364 <fwp_rc_forget_slot.part.0>
    a3fc:	a9480fe0 	ldp	x0, x3, [sp, #128]
    a400:	17fffe8b 	b	9e2c <fwp_hof0.constprop.0+0x145c>
    a404:	f90023e2 	str	x2, [sp, #64]
    a408:	f9002be0 	str	x0, [sp, #80]
    a40c:	97ffe7d6 	bl	4364 <fwp_rc_forget_slot.part.0>
    a410:	f94023e2 	ldr	x2, [sp, #64]
    a414:	f9402be0 	ldr	x0, [sp, #80]
    a418:	17fffe20 	b	9c98 <fwp_hof0.constprop.0+0x12c8>
    a41c:	72003c3f 	tst	w1, #0xffff
    a420:	54ffc360 	b.eq	9c8c <fwp_hof0.constprop.0+0x12bc>  // b.none
    a424:	aa1a03e0 	mov	x0, x26
    a428:	17fffd4c 	b	9958 <fwp_hof0.constprop.0+0xf88>
    a42c:	aa1703e0 	mov	x0, x23
    a430:	97ffe7cd 	bl	4364 <fwp_rc_forget_slot.part.0>
    a434:	91014280 	add	x0, x20, #0x50
    a438:	f941c004 	ldr	x4, [x0, #896]
    a43c:	17fffd1c 	b	98ac <fwp_hof0.constprop.0+0xedc>
    a440:	f90023e0 	str	x0, [sp, #64]
    a444:	97ffe7c8 	bl	4364 <fwp_rc_forget_slot.part.0>
    a448:	f94023e0 	ldr	x0, [sp, #64]
    a44c:	17fffdd7 	b	9ba8 <fwp_hof0.constprop.0+0x11d8>
    a450:	a91253f3 	stp	x19, x20, [sp, #288]
    a454:	a9135bf5 	stp	x21, x22, [sp, #304]
    a458:	a91463f7 	stp	x23, x24, [sp, #320]
    a45c:	a9156bf9 	stp	x25, x26, [sp, #336]
    a460:	97ffe100 	bl	2860 <__stack_chk_fail@plt>
    a464:	ca404401 	eor	x1, x0, x0, lsr #17
    a468:	911882c3 	add	x3, x22, #0x620
    a46c:	ca412421 	eor	x1, x1, x1, lsr #9
    a470:	92401c21 	and	x1, x1, #0xff
    a474:	910a2422 	add	x2, x1, #0x289
    a478:	8b010c61 	add	x1, x3, x1, lsl #3
    a47c:	8b020c62 	add	x2, x3, x2, lsl #3
    a480:	f94a2421 	ldr	x1, [x1, #5192]
    a484:	b4ffb0a1 	cbz	x1, 9a98 <fwp_hof0.constprop.0+0x10c8>
    a488:	f9400023 	ldr	x3, [x1]
    a48c:	eb00007f 	cmp	x3, x0
    a490:	540003a0 	b.eq	a504 <fwp_hof0.constprop.0+0x1b34>  // b.none
    a494:	91004022 	add	x2, x1, #0x10
    a498:	f9400821 	ldr	x1, [x1, #16]
    a49c:	17fffffa 	b	a484 <fwp_hof0.constprop.0+0x1ab4>
    a4a0:	b5ffdda1 	cbnz	x1, a054 <fwp_hof0.constprop.0+0x1684>
    a4a4:	17ffff5b 	b	a210 <fwp_hof0.constprop.0+0x1840>
    a4a8:	f94002e2 	ldr	x2, [x23]
    a4ac:	b7f80082 	tbnz	x2, #63, a4bc <fwp_hof0.constprop.0+0x1aec>
    a4b0:	9240f842 	and	x2, x2, #0x7fffffffffffffff
    a4b4:	d280001a 	mov	x26, #0x0                   	// #0
    a4b8:	17fffd43 	b	99c4 <fwp_hof0.constprop.0+0xff4>
    a4bc:	52800041 	mov	w1, #0x2                   	// #2
    a4c0:	d2800100 	mov	x0, #0x8                   	// #8
    a4c4:	97ffeaff 	bl	50c0 <fwp_heap_alloc>
    a4c8:	aa0003e1 	mov	x1, x0
    a4cc:	52800009 	mov	w9, #0x0                   	// #0
    a4d0:	aa1903fa 	mov	x26, x25
    a4d4:	d2800019 	mov	x25, #0x0                   	// #0
    a4d8:	17ffffc4 	b	a3e8 <fwp_hof0.constprop.0+0x1a18>
    a4dc:	f94006f7 	ldr	x23, [x23, #8]
    a4e0:	7100087f 	cmp	w3, #0x2
    a4e4:	54000280 	b.eq	a534 <fwp_hof0.constprop.0+0x1b64>  // b.none
    a4e8:	29430903 	ldp	w3, w2, [x8, #24]
    a4ec:	9b037c21 	mul	x1, x1, x3
    a4f0:	eb41805f 	cmp	x2, x1, lsr #32
    a4f4:	54ffd6e9 	b.ls	9fd0 <fwp_hof0.constprop.0+0x1600>  // b.plast
    a4f8:	97ffe836 	bl	45d0 <fwp_mem_free>
    a4fc:	d2800507 	mov	x7, #0x28                  	// #40
    a500:	17fffeb4 	b	9fd0 <fwp_hof0.constprop.0+0x1600>
    a504:	f9400042 	ldr	x2, [x2]
    a508:	f9400441 	ldr	x1, [x2, #8]
    a50c:	d1000421 	sub	x1, x1, #0x1
    a510:	f9000441 	str	x1, [x2, #8]
    a514:	f103f83f 	cmp	x1, #0xfe
    a518:	54ffd9e1 	b.ne	a054 <fwp_hof0.constprop.0+0x1684>  // b.any
    a51c:	39400001 	ldrb	w1, [x0]
    a520:	7103fc3f 	cmp	w1, #0xff
    a524:	540000c0 	b.eq	a53c <fwp_hof0.constprop.0+0x1b6c>  // b.none
    a528:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a52c:	39000001 	strb	w1, [x0]
    a530:	17fffec9 	b	a054 <fwp_hof0.constprop.0+0x1684>
    a534:	b5ffd4e1 	cbnz	x1, 9fd0 <fwp_hof0.constprop.0+0x1600>
    a538:	17fffff0 	b	a4f8 <fwp_hof0.constprop.0+0x1b28>
    a53c:	f9002be0 	str	x0, [sp, #80]
    a540:	97ffe789 	bl	4364 <fwp_rc_forget_slot.part.0>
    a544:	f9402be0 	ldr	x0, [sp, #80]
    a548:	17fffff8 	b	a528 <fwp_hof0.constprop.0+0x1b58>
    a54c:	97ffe0d9 	bl	28b0 <abort@plt>
    a550:	97ffe13c 	bl	2a40 <fwp_trap_overflow.constprop.0>

000000000000a554 <f0>:
    a554:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a558:	910003fd 	mov	x29, sp
    a55c:	a90153f3 	stp	x19, x20, [sp, #16]
    a560:	a9025bf5 	stp	x21, x22, [sp, #32]
    a564:	a90363f7 	stp	x23, x24, [sp, #48]
    a568:	a9046bf9 	stp	x25, x26, [sp, #64]
    a56c:	a90573fb 	stp	x27, x28, [sp, #80]
    a570:	d121c3ff 	sub	sp, sp, #0x870
    a574:	f90203ff 	str	xzr, [sp, #1024]
    a578:	d00000a0 	adrp	x0, 20000 <__data_start>
    a57c:	91014003 	add	x3, x0, #0x50
    a580:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    a584:	f947f400 	ldr	x0, [x0, #4072]
    a588:	f0000374 	adrp	x20, 79000 <fwp_root_context+0xbc0>
    a58c:	f941c065 	ldr	x5, [x3, #896]
    a590:	f9400001 	ldr	x1, [x0]
    a594:	f90437e1 	str	x1, [sp, #2152]
    a598:	d2800001 	mov	x1, #0x0                   	// #0
    a59c:	91188299 	add	x25, x20, #0x620
    a5a0:	912163f6 	add	x22, sp, #0x858
    a5a4:	910063e4 	add	x4, sp, #0x18
    a5a8:	9100c3e1 	add	x1, sp, #0x30
    a5ac:	90ffffe0 	adrp	x0, 6000 <fwp_owned_entry173+0x30>
    a5b0:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    a5b4:	910dc000 	add	x0, x0, #0x370
    a5b8:	913c4042 	add	x2, x2, #0xf10
    a5bc:	d2800013 	mov	x19, #0x0                   	// #0
    a5c0:	d280011a 	mov	x26, #0x8                   	// #8
    a5c4:	d2800015 	mov	x21, #0x0                   	// #0
    a5c8:	52800037 	mov	w23, #0x1                   	// #1
    a5cc:	f90007e4 	str	x4, [sp, #8]
    a5d0:	a9018be5 	stp	x5, x2, [sp, #24]
    a5d4:	a902ffe1 	stp	x1, xzr, [sp, #40]
    a5d8:	a90403ff 	stp	xzr, x0, [sp, #64]
    a5dc:	f901c064 	str	x4, [x3, #896]
    a5e0:	f100075b 	subs	x27, x26, #0x1
    a5e4:	aa1603e1 	mov	x1, x22
    a5e8:	da1f02b8 	sbc	x24, x21, xzr
    a5ec:	52800020 	mov	w0, #0x1                   	// #1
    a5f0:	f9001ffb 	str	x27, [sp, #56]
    a5f4:	aa1b03fa 	mov	x26, x27
    a5f8:	f9042ffb 	str	x27, [sp, #2136]
    a5fc:	aa1803f5 	mov	x21, x24
    a600:	f90433f3 	str	x19, [sp, #2144]
    a604:	97ffeb13 	bl	5250 <fwp_data.part.0.constprop.0>
    a608:	f949db22 	ldr	x2, [x25, #5040]
    a60c:	aa0003f3 	mov	x19, x0
    a610:	f949ef20 	ldr	x0, [x25, #5080]
    a614:	cb020262 	sub	x2, x19, x2
    a618:	eb00405f 	cmp	x2, x0, lsl #16
    a61c:	54000302 	b.cs	a67c <f0+0x128>  // b.hs, b.nlast
    a620:	d350fc40 	lsr	x0, x2, #16
    a624:	f949ff25 	ldr	x5, [x25, #5112]
    a628:	8b000800 	add	x0, x0, x0, lsl #2
    a62c:	d37df001 	lsl	x1, x0, #3
    a630:	8b0100a0 	add	x0, x5, x1
    a634:	f940101c 	ldr	x28, [x0, #32]
    a638:	b400023c 	cbz	x28, a67c <f0+0x128>
    a63c:	386168a1 	ldrb	w1, [x5, x1]
    a640:	7100083f 	cmp	w1, #0x2
    a644:	54010ea0 	b.eq	c818 <f0+0x22c4>  // b.none
    a648:	7100043f 	cmp	w1, #0x1
    a64c:	54000181 	b.ne	a67c <f0+0x128>  // b.any
    a650:	29430001 	ldp	w1, w0, [x0, #24]
    a654:	92403c42 	and	x2, x2, #0xffff
    a658:	9b017c42 	mul	x2, x2, x1
    a65c:	d360fc42 	lsr	x2, x2, #32
    a660:	eb00005f 	cmp	x2, x0
    a664:	540000c2 	b.cs	a67c <f0+0x128>  // b.hs, b.nlast
    a668:	8b02039c 	add	x28, x28, x2
    a66c:	39400380 	ldrb	w0, [x28]
    a670:	7103fc1f 	cmp	w0, #0xff
    a674:	54010cc0 	b.eq	c80c <f0+0x22b8>  // b.none
    a678:	39000397 	strb	w23, [x28]
    a67c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    a680:	aa18037b 	orr	x27, x27, x24
    a684:	b5fffafb 	cbnz	x27, a5e0 <f0+0x8c>
    a688:	d00000a0 	adrp	x0, 20000 <__data_start>
    a68c:	91014018 	add	x24, x0, #0x50
    a690:	f94007e1 	ldr	x1, [sp, #8]
    a694:	f9001bff 	str	xzr, [sp, #48]
    a698:	f941c300 	ldr	x0, [x24, #896]
    a69c:	eb01001f 	cmp	x0, x1
    a6a0:	54012981 	b.ne	cbd0 <f0+0x267c>  // b.any
    a6a4:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x780>
    a6a8:	910143e1 	add	x1, sp, #0x50
    a6ac:	f9400fe2 	ldr	x2, [sp, #24]
    a6b0:	f901c302 	str	x2, [x24, #896]
    a6b4:	3dc22400 	ldr	q0, [x0, #2192]
    a6b8:	52800020 	mov	w0, #0x1                   	// #1
    a6bc:	3d8017e0 	str	q0, [sp, #80]
    a6c0:	97ffeae4 	bl	5250 <fwp_data.part.0.constprop.0>
    a6c4:	91188283 	add	x3, x20, #0x620
    a6c8:	aa0003f5 	mov	x21, x0
    a6cc:	f949d861 	ldr	x1, [x3, #5040]
    a6d0:	f949ec60 	ldr	x0, [x3, #5080]
    a6d4:	cb0102a1 	sub	x1, x21, x1
    a6d8:	eb00403f 	cmp	x1, x0, lsl #16
    a6dc:	54000322 	b.cs	a740 <f0+0x1ec>  // b.hs, b.nlast
    a6e0:	d350fc22 	lsr	x2, x1, #16
    a6e4:	f949fc63 	ldr	x3, [x3, #5112]
    a6e8:	8b020842 	add	x2, x2, x2, lsl #2
    a6ec:	d37df042 	lsl	x2, x2, #3
    a6f0:	8b020060 	add	x0, x3, x2
    a6f4:	f9401017 	ldr	x23, [x0, #32]
    a6f8:	b4000257 	cbz	x23, a740 <f0+0x1ec>
    a6fc:	38626862 	ldrb	w2, [x3, x2]
    a700:	7100085f 	cmp	w2, #0x2
    a704:	54010900 	b.eq	c824 <f0+0x22d0>  // b.none
    a708:	7100045f 	cmp	w2, #0x1
    a70c:	540001a1 	b.ne	a740 <f0+0x1ec>  // b.any
    a710:	29430002 	ldp	w2, w0, [x0, #24]
    a714:	92403c21 	and	x1, x1, #0xffff
    a718:	9b027c21 	mul	x1, x1, x2
    a71c:	d360fc21 	lsr	x1, x1, #32
    a720:	eb00003f 	cmp	x1, x0
    a724:	540000e2 	b.cs	a740 <f0+0x1ec>  // b.hs, b.nlast
    a728:	8b0102f7 	add	x23, x23, x1
    a72c:	394002e0 	ldrb	w0, [x23]
    a730:	7103fc1f 	cmp	w0, #0xff
    a734:	54011680 	b.eq	ca04 <f0+0x24b0>  // b.none
    a738:	52800020 	mov	w0, #0x1                   	// #1
    a73c:	390002e0 	strb	w0, [x23]
    a740:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a744:	9101a3e1 	add	x1, sp, #0x68
    a748:	52800020 	mov	w0, #0x1                   	// #1
    a74c:	a906d7e2 	stp	x2, x21, [sp, #104]
    a750:	97ffeac0 	bl	5250 <fwp_data.part.0.constprop.0>
    a754:	91188283 	add	x3, x20, #0x620
    a758:	aa0003f5 	mov	x21, x0
    a75c:	f949d861 	ldr	x1, [x3, #5040]
    a760:	f949ec60 	ldr	x0, [x3, #5080]
    a764:	cb0102a1 	sub	x1, x21, x1
    a768:	eb00403f 	cmp	x1, x0, lsl #16
    a76c:	54000322 	b.cs	a7d0 <f0+0x27c>  // b.hs, b.nlast
    a770:	d350fc22 	lsr	x2, x1, #16
    a774:	f949fc63 	ldr	x3, [x3, #5112]
    a778:	8b020842 	add	x2, x2, x2, lsl #2
    a77c:	d37df042 	lsl	x2, x2, #3
    a780:	8b020060 	add	x0, x3, x2
    a784:	f9401017 	ldr	x23, [x0, #32]
    a788:	b4000257 	cbz	x23, a7d0 <f0+0x27c>
    a78c:	38626862 	ldrb	w2, [x3, x2]
    a790:	7100085f 	cmp	w2, #0x2
    a794:	54010540 	b.eq	c83c <f0+0x22e8>  // b.none
    a798:	7100045f 	cmp	w2, #0x1
    a79c:	540001a1 	b.ne	a7d0 <f0+0x27c>  // b.any
    a7a0:	29430002 	ldp	w2, w0, [x0, #24]
    a7a4:	92403c21 	and	x1, x1, #0xffff
    a7a8:	9b027c21 	mul	x1, x1, x2
    a7ac:	d360fc21 	lsr	x1, x1, #32
    a7b0:	eb00003f 	cmp	x1, x0
    a7b4:	540000e2 	b.cs	a7d0 <f0+0x27c>  // b.hs, b.nlast
    a7b8:	8b0102f7 	add	x23, x23, x1
    a7bc:	394002e0 	ldrb	w0, [x23]
    a7c0:	7103fc1f 	cmp	w0, #0xff
    a7c4:	54011260 	b.eq	ca10 <f0+0x24bc>  // b.none
    a7c8:	52800020 	mov	w0, #0x1                   	// #1
    a7cc:	390002e0 	strb	w0, [x23]
    a7d0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a7d4:	9101e3e1 	add	x1, sp, #0x78
    a7d8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a7dc:	52800020 	mov	w0, #0x1                   	// #1
    a7e0:	a907d7e2 	stp	x2, x21, [sp, #120]
    a7e4:	97ffea9b 	bl	5250 <fwp_data.part.0.constprop.0>
    a7e8:	97ffed7a 	bl	5dd0 <fwp_rc_fresh>
    a7ec:	aa0003e2 	mov	x2, x0
    a7f0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a7f4:	910223e1 	add	x1, sp, #0x88
    a7f8:	52800020 	mov	w0, #0x1                   	// #1
    a7fc:	a9088be3 	stp	x3, x2, [sp, #136]
    a800:	97ffea94 	bl	5250 <fwp_data.part.0.constprop.0>
    a804:	91188283 	add	x3, x20, #0x620
    a808:	aa0003f7 	mov	x23, x0
    a80c:	f949d861 	ldr	x1, [x3, #5040]
    a810:	f949ec60 	ldr	x0, [x3, #5080]
    a814:	cb0102e1 	sub	x1, x23, x1
    a818:	eb00403f 	cmp	x1, x0, lsl #16
    a81c:	54000322 	b.cs	a880 <f0+0x32c>  // b.hs, b.nlast
    a820:	d350fc22 	lsr	x2, x1, #16
    a824:	f949fc63 	ldr	x3, [x3, #5112]
    a828:	8b020842 	add	x2, x2, x2, lsl #2
    a82c:	d37df042 	lsl	x2, x2, #3
    a830:	8b020060 	add	x0, x3, x2
    a834:	f9401015 	ldr	x21, [x0, #32]
    a838:	b4000255 	cbz	x21, a880 <f0+0x32c>
    a83c:	38626862 	ldrb	w2, [x3, x2]
    a840:	7100085f 	cmp	w2, #0x2
    a844:	5400ff60 	b.eq	c830 <f0+0x22dc>  // b.none
    a848:	7100045f 	cmp	w2, #0x1
    a84c:	540001a1 	b.ne	a880 <f0+0x32c>  // b.any
    a850:	29430002 	ldp	w2, w0, [x0, #24]
    a854:	92403c21 	and	x1, x1, #0xffff
    a858:	9b027c21 	mul	x1, x1, x2
    a85c:	d360fc21 	lsr	x1, x1, #32
    a860:	eb00003f 	cmp	x1, x0
    a864:	540000e2 	b.cs	a880 <f0+0x32c>  // b.hs, b.nlast
    a868:	8b0102b5 	add	x21, x21, x1
    a86c:	394002a0 	ldrb	w0, [x21]
    a870:	7103fc1f 	cmp	w0, #0xff
    a874:	54010d40 	b.eq	ca1c <f0+0x24c8>  // b.none
    a878:	52800020 	mov	w0, #0x1                   	// #1
    a87c:	390002a0 	strb	w0, [x21]
    a880:	910263e1 	add	x1, sp, #0x98
    a884:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a888:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a88c:	52800020 	mov	w0, #0x1                   	// #1
    a890:	a909dff5 	stp	x21, x23, [sp, #152]
    a894:	97ffea6f 	bl	5250 <fwp_data.part.0.constprop.0>
    a898:	97ffed4e 	bl	5dd0 <fwp_rc_fresh>
    a89c:	aa0003e2 	mov	x2, x0
    a8a0:	9102a3e1 	add	x1, sp, #0xa8
    a8a4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a8a8:	52800020 	mov	w0, #0x1                   	// #1
    a8ac:	a90a8bf7 	stp	x23, x2, [sp, #168]
    a8b0:	97ffea68 	bl	5250 <fwp_data.part.0.constprop.0>
    a8b4:	97ffed47 	bl	5dd0 <fwp_rc_fresh>
    a8b8:	aa0003e2 	mov	x2, x0
    a8bc:	9102e3e1 	add	x1, sp, #0xb8
    a8c0:	52800020 	mov	w0, #0x1                   	// #1
    a8c4:	a90b8bf5 	stp	x21, x2, [sp, #184]
    a8c8:	97ffea62 	bl	5250 <fwp_data.part.0.constprop.0>
    a8cc:	97ffed41 	bl	5dd0 <fwp_rc_fresh>
    a8d0:	aa0003e2 	mov	x2, x0
    a8d4:	910323e1 	add	x1, sp, #0xc8
    a8d8:	52800020 	mov	w0, #0x1                   	// #1
    a8dc:	a90c8bf7 	stp	x23, x2, [sp, #200]
    a8e0:	97ffea5c 	bl	5250 <fwp_data.part.0.constprop.0>
    a8e4:	97ffed3b 	bl	5dd0 <fwp_rc_fresh>
    a8e8:	aa0003e2 	mov	x2, x0
    a8ec:	910363e1 	add	x1, sp, #0xd8
    a8f0:	52800020 	mov	w0, #0x1                   	// #1
    a8f4:	a90d8bf5 	stp	x21, x2, [sp, #216]
    a8f8:	97ffea56 	bl	5250 <fwp_data.part.0.constprop.0>
    a8fc:	97ffed35 	bl	5dd0 <fwp_rc_fresh>
    a900:	aa0003e2 	mov	x2, x0
    a904:	9103a3e1 	add	x1, sp, #0xe8
    a908:	52800020 	mov	w0, #0x1                   	// #1
    a90c:	a90e8bf7 	stp	x23, x2, [sp, #232]
    a910:	97ffea50 	bl	5250 <fwp_data.part.0.constprop.0>
    a914:	97ffed2f 	bl	5dd0 <fwp_rc_fresh>
    a918:	aa0003e2 	mov	x2, x0
    a91c:	9103e3e1 	add	x1, sp, #0xf8
    a920:	52800020 	mov	w0, #0x1                   	// #1
    a924:	a90f8bf5 	stp	x21, x2, [sp, #248]
    a928:	97ffea4a 	bl	5250 <fwp_data.part.0.constprop.0>
    a92c:	91188283 	add	x3, x20, #0x620
    a930:	aa0003f5 	mov	x21, x0
    a934:	f949d861 	ldr	x1, [x3, #5040]
    a938:	f949ec60 	ldr	x0, [x3, #5080]
    a93c:	cb0102a1 	sub	x1, x21, x1
    a940:	eb00403f 	cmp	x1, x0, lsl #16
    a944:	54000322 	b.cs	a9a8 <f0+0x454>  // b.hs, b.nlast
    a948:	d350fc22 	lsr	x2, x1, #16
    a94c:	f949fc63 	ldr	x3, [x3, #5112]
    a950:	8b020842 	add	x2, x2, x2, lsl #2
    a954:	d37df042 	lsl	x2, x2, #3
    a958:	8b020060 	add	x0, x3, x2
    a95c:	f9401017 	ldr	x23, [x0, #32]
    a960:	b4000257 	cbz	x23, a9a8 <f0+0x454>
    a964:	38626862 	ldrb	w2, [x3, x2]
    a968:	7100085f 	cmp	w2, #0x2
    a96c:	5400f740 	b.eq	c854 <f0+0x2300>  // b.none
    a970:	7100045f 	cmp	w2, #0x1
    a974:	540001a1 	b.ne	a9a8 <f0+0x454>  // b.any
    a978:	29430002 	ldp	w2, w0, [x0, #24]
    a97c:	92403c21 	and	x1, x1, #0xffff
    a980:	9b027c21 	mul	x1, x1, x2
    a984:	d360fc21 	lsr	x1, x1, #32
    a988:	eb00003f 	cmp	x1, x0
    a98c:	540000e2 	b.cs	a9a8 <f0+0x454>  // b.hs, b.nlast
    a990:	8b0102f7 	add	x23, x23, x1
    a994:	394002e0 	ldrb	w0, [x23]
    a998:	7103fc1f 	cmp	w0, #0xff
    a99c:	54010460 	b.eq	ca28 <f0+0x24d4>  // b.none
    a9a0:	52800020 	mov	w0, #0x1                   	// #1
    a9a4:	390002e0 	strb	w0, [x23]
    a9a8:	910423e1 	add	x1, sp, #0x108
    a9ac:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a9b0:	52800020 	mov	w0, #0x1                   	// #1
    a9b4:	a910d7f7 	stp	x23, x21, [sp, #264]
    a9b8:	97ffea26 	bl	5250 <fwp_data.part.0.constprop.0>
    a9bc:	97ffed05 	bl	5dd0 <fwp_rc_fresh>
    a9c0:	aa0003e2 	mov	x2, x0
    a9c4:	910463e1 	add	x1, sp, #0x118
    a9c8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a9cc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a9d0:	52800020 	mov	w0, #0x1                   	// #1
    a9d4:	a9118bf5 	stp	x21, x2, [sp, #280]
    a9d8:	97ffea1e 	bl	5250 <fwp_data.part.0.constprop.0>
    a9dc:	97ffecfd 	bl	5dd0 <fwp_rc_fresh>
    a9e0:	aa0003e2 	mov	x2, x0
    a9e4:	9104a3e1 	add	x1, sp, #0x128
    a9e8:	52800020 	mov	w0, #0x1                   	// #1
    a9ec:	a9128bf7 	stp	x23, x2, [sp, #296]
    a9f0:	97ffea18 	bl	5250 <fwp_data.part.0.constprop.0>
    a9f4:	97ffecf7 	bl	5dd0 <fwp_rc_fresh>
    a9f8:	aa0003e2 	mov	x2, x0
    a9fc:	9104e3e1 	add	x1, sp, #0x138
    aa00:	52800020 	mov	w0, #0x1                   	// #1
    aa04:	a9138bf5 	stp	x21, x2, [sp, #312]
    aa08:	97ffea12 	bl	5250 <fwp_data.part.0.constprop.0>
    aa0c:	97ffecf1 	bl	5dd0 <fwp_rc_fresh>
    aa10:	aa0003e2 	mov	x2, x0
    aa14:	910523e1 	add	x1, sp, #0x148
    aa18:	52800020 	mov	w0, #0x1                   	// #1
    aa1c:	a9148bf7 	stp	x23, x2, [sp, #328]
    aa20:	97ffea0c 	bl	5250 <fwp_data.part.0.constprop.0>
    aa24:	97ffeceb 	bl	5dd0 <fwp_rc_fresh>
    aa28:	aa0003e2 	mov	x2, x0
    aa2c:	910563e1 	add	x1, sp, #0x158
    aa30:	52800020 	mov	w0, #0x1                   	// #1
    aa34:	a9158bf5 	stp	x21, x2, [sp, #344]
    aa38:	97ffea06 	bl	5250 <fwp_data.part.0.constprop.0>
    aa3c:	91188283 	add	x3, x20, #0x620
    aa40:	aa0003f5 	mov	x21, x0
    aa44:	f949d861 	ldr	x1, [x3, #5040]
    aa48:	f949ec60 	ldr	x0, [x3, #5080]
    aa4c:	cb0102a1 	sub	x1, x21, x1
    aa50:	eb00403f 	cmp	x1, x0, lsl #16
    aa54:	54000322 	b.cs	aab8 <f0+0x564>  // b.hs, b.nlast
    aa58:	d350fc22 	lsr	x2, x1, #16
    aa5c:	f949fc63 	ldr	x3, [x3, #5112]
    aa60:	8b020842 	add	x2, x2, x2, lsl #2
    aa64:	d37df042 	lsl	x2, x2, #3
    aa68:	8b020060 	add	x0, x3, x2
    aa6c:	f9401017 	ldr	x23, [x0, #32]
    aa70:	b4000257 	cbz	x23, aab8 <f0+0x564>
    aa74:	38626862 	ldrb	w2, [x3, x2]
    aa78:	7100085f 	cmp	w2, #0x2
    aa7c:	5400ee60 	b.eq	c848 <f0+0x22f4>  // b.none
    aa80:	7100045f 	cmp	w2, #0x1
    aa84:	540001a1 	b.ne	aab8 <f0+0x564>  // b.any
    aa88:	29430002 	ldp	w2, w0, [x0, #24]
    aa8c:	92403c21 	and	x1, x1, #0xffff
    aa90:	9b027c21 	mul	x1, x1, x2
    aa94:	d360fc21 	lsr	x1, x1, #32
    aa98:	eb00003f 	cmp	x1, x0
    aa9c:	540000e2 	b.cs	aab8 <f0+0x564>  // b.hs, b.nlast
    aaa0:	8b0102f7 	add	x23, x23, x1
    aaa4:	394002e0 	ldrb	w0, [x23]
    aaa8:	7103fc1f 	cmp	w0, #0xff
    aaac:	5400fc40 	b.eq	ca34 <f0+0x24e0>  // b.none
    aab0:	52800020 	mov	w0, #0x1                   	// #1
    aab4:	390002e0 	strb	w0, [x23]
    aab8:	9105a3e1 	add	x1, sp, #0x168
    aabc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aac0:	52800020 	mov	w0, #0x1                   	// #1
    aac4:	a916d7e2 	stp	x2, x21, [sp, #360]
    aac8:	97ffe9e2 	bl	5250 <fwp_data.part.0.constprop.0>
    aacc:	97ffecc1 	bl	5dd0 <fwp_rc_fresh>
    aad0:	aa0003e2 	mov	x2, x0
    aad4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aad8:	9105e3e1 	add	x1, sp, #0x178
    aadc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aae0:	52800020 	mov	w0, #0x1                   	// #1
    aae4:	a9178be3 	stp	x3, x2, [sp, #376]
    aae8:	97ffe9da 	bl	5250 <fwp_data.part.0.constprop.0>
    aaec:	91188283 	add	x3, x20, #0x620
    aaf0:	aa0003f5 	mov	x21, x0
    aaf4:	f949d861 	ldr	x1, [x3, #5040]
    aaf8:	f949ec60 	ldr	x0, [x3, #5080]
    aafc:	cb0102a1 	sub	x1, x21, x1
    ab00:	eb00403f 	cmp	x1, x0, lsl #16
    ab04:	54000322 	b.cs	ab68 <f0+0x614>  // b.hs, b.nlast
    ab08:	d350fc22 	lsr	x2, x1, #16
    ab0c:	f949fc63 	ldr	x3, [x3, #5112]
    ab10:	8b020842 	add	x2, x2, x2, lsl #2
    ab14:	d37df042 	lsl	x2, x2, #3
    ab18:	8b020060 	add	x0, x3, x2
    ab1c:	f9401017 	ldr	x23, [x0, #32]
    ab20:	b4000257 	cbz	x23, ab68 <f0+0x614>
    ab24:	38626862 	ldrb	w2, [x3, x2]
    ab28:	7100085f 	cmp	w2, #0x2
    ab2c:	5400ea00 	b.eq	c86c <f0+0x2318>  // b.none
    ab30:	7100045f 	cmp	w2, #0x1
    ab34:	540001a1 	b.ne	ab68 <f0+0x614>  // b.any
    ab38:	29430002 	ldp	w2, w0, [x0, #24]
    ab3c:	92403c21 	and	x1, x1, #0xffff
    ab40:	9b027c21 	mul	x1, x1, x2
    ab44:	d360fc21 	lsr	x1, x1, #32
    ab48:	eb00003f 	cmp	x1, x0
    ab4c:	540000e2 	b.cs	ab68 <f0+0x614>  // b.hs, b.nlast
    ab50:	8b0102f7 	add	x23, x23, x1
    ab54:	394002e0 	ldrb	w0, [x23]
    ab58:	7103fc1f 	cmp	w0, #0xff
    ab5c:	5400f720 	b.eq	ca40 <f0+0x24ec>  // b.none
    ab60:	52800020 	mov	w0, #0x1                   	// #1
    ab64:	390002e0 	strb	w0, [x23]
    ab68:	910623e1 	add	x1, sp, #0x188
    ab6c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab70:	52800020 	mov	w0, #0x1                   	// #1
    ab74:	a918d7e2 	stp	x2, x21, [sp, #392]
    ab78:	97ffe9b6 	bl	5250 <fwp_data.part.0.constprop.0>
    ab7c:	97ffec95 	bl	5dd0 <fwp_rc_fresh>
    ab80:	aa0003e2 	mov	x2, x0
    ab84:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ab88:	910663e1 	add	x1, sp, #0x198
    ab8c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ab90:	52800020 	mov	w0, #0x1                   	// #1
    ab94:	a9198be3 	stp	x3, x2, [sp, #408]
    ab98:	97ffe9ae 	bl	5250 <fwp_data.part.0.constprop.0>
    ab9c:	91188283 	add	x3, x20, #0x620
    aba0:	aa0003f5 	mov	x21, x0
    aba4:	f949d861 	ldr	x1, [x3, #5040]
    aba8:	f949ec60 	ldr	x0, [x3, #5080]
    abac:	cb0102a1 	sub	x1, x21, x1
    abb0:	eb00403f 	cmp	x1, x0, lsl #16
    abb4:	54000322 	b.cs	ac18 <f0+0x6c4>  // b.hs, b.nlast
    abb8:	d350fc22 	lsr	x2, x1, #16
    abbc:	f949fc63 	ldr	x3, [x3, #5112]
    abc0:	8b020842 	add	x2, x2, x2, lsl #2
    abc4:	d37df042 	lsl	x2, x2, #3
    abc8:	8b020060 	add	x0, x3, x2
    abcc:	f9401017 	ldr	x23, [x0, #32]
    abd0:	b4000257 	cbz	x23, ac18 <f0+0x6c4>
    abd4:	38626862 	ldrb	w2, [x3, x2]
    abd8:	7100085f 	cmp	w2, #0x2
    abdc:	5400e420 	b.eq	c860 <f0+0x230c>  // b.none
    abe0:	7100045f 	cmp	w2, #0x1
    abe4:	540001a1 	b.ne	ac18 <f0+0x6c4>  // b.any
    abe8:	29430002 	ldp	w2, w0, [x0, #24]
    abec:	92403c21 	and	x1, x1, #0xffff
    abf0:	9b027c21 	mul	x1, x1, x2
    abf4:	d360fc21 	lsr	x1, x1, #32
    abf8:	eb00003f 	cmp	x1, x0
    abfc:	540000e2 	b.cs	ac18 <f0+0x6c4>  // b.hs, b.nlast
    ac00:	8b0102f7 	add	x23, x23, x1
    ac04:	394002e0 	ldrb	w0, [x23]
    ac08:	7103fc1f 	cmp	w0, #0xff
    ac0c:	5400f200 	b.eq	ca4c <f0+0x24f8>  // b.none
    ac10:	52800020 	mov	w0, #0x1                   	// #1
    ac14:	390002e0 	strb	w0, [x23]
    ac18:	9106a3e1 	add	x1, sp, #0x1a8
    ac1c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ac20:	52800020 	mov	w0, #0x1                   	// #1
    ac24:	a91ad7e2 	stp	x2, x21, [sp, #424]
    ac28:	97ffe98a 	bl	5250 <fwp_data.part.0.constprop.0>
    ac2c:	97ffec69 	bl	5dd0 <fwp_rc_fresh>
    ac30:	aa0003e2 	mov	x2, x0
    ac34:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ac38:	9106e3e1 	add	x1, sp, #0x1b8
    ac3c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ac40:	52800020 	mov	w0, #0x1                   	// #1
    ac44:	a91b8be3 	stp	x3, x2, [sp, #440]
    ac48:	97ffe982 	bl	5250 <fwp_data.part.0.constprop.0>
    ac4c:	91188283 	add	x3, x20, #0x620
    ac50:	aa0003f5 	mov	x21, x0
    ac54:	f949d861 	ldr	x1, [x3, #5040]
    ac58:	f949ec60 	ldr	x0, [x3, #5080]
    ac5c:	cb0102a1 	sub	x1, x21, x1
    ac60:	eb00403f 	cmp	x1, x0, lsl #16
    ac64:	54000322 	b.cs	acc8 <f0+0x774>  // b.hs, b.nlast
    ac68:	d350fc22 	lsr	x2, x1, #16
    ac6c:	f949fc63 	ldr	x3, [x3, #5112]
    ac70:	8b020842 	add	x2, x2, x2, lsl #2
    ac74:	d37df042 	lsl	x2, x2, #3
    ac78:	8b020060 	add	x0, x3, x2
    ac7c:	f9401017 	ldr	x23, [x0, #32]
    ac80:	b4000257 	cbz	x23, acc8 <f0+0x774>
    ac84:	38626862 	ldrb	w2, [x3, x2]
    ac88:	7100085f 	cmp	w2, #0x2
    ac8c:	5400e5c0 	b.eq	c944 <f0+0x23f0>  // b.none
    ac90:	7100045f 	cmp	w2, #0x1
    ac94:	540001a1 	b.ne	acc8 <f0+0x774>  // b.any
    ac98:	29430002 	ldp	w2, w0, [x0, #24]
    ac9c:	92403c21 	and	x1, x1, #0xffff
    aca0:	9b027c21 	mul	x1, x1, x2
    aca4:	d360fc21 	lsr	x1, x1, #32
    aca8:	eb00003f 	cmp	x1, x0
    acac:	540000e2 	b.cs	acc8 <f0+0x774>  // b.hs, b.nlast
    acb0:	8b0102f7 	add	x23, x23, x1
    acb4:	394002e0 	ldrb	w0, [x23]
    acb8:	7103fc1f 	cmp	w0, #0xff
    acbc:	5400ece0 	b.eq	ca58 <f0+0x2504>  // b.none
    acc0:	52800020 	mov	w0, #0x1                   	// #1
    acc4:	390002e0 	strb	w0, [x23]
    acc8:	910723e1 	add	x1, sp, #0x1c8
    accc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    acd0:	52800020 	mov	w0, #0x1                   	// #1
    acd4:	a91cd7e2 	stp	x2, x21, [sp, #456]
    acd8:	97ffe95e 	bl	5250 <fwp_data.part.0.constprop.0>
    acdc:	97ffec3d 	bl	5dd0 <fwp_rc_fresh>
    ace0:	aa0003e2 	mov	x2, x0
    ace4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ace8:	910763e1 	add	x1, sp, #0x1d8
    acec:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    acf0:	52800020 	mov	w0, #0x1                   	// #1
    acf4:	a91d8be3 	stp	x3, x2, [sp, #472]
    acf8:	97ffe956 	bl	5250 <fwp_data.part.0.constprop.0>
    acfc:	91188283 	add	x3, x20, #0x620
    ad00:	aa0003f5 	mov	x21, x0
    ad04:	f949d861 	ldr	x1, [x3, #5040]
    ad08:	f949ec60 	ldr	x0, [x3, #5080]
    ad0c:	cb0102a1 	sub	x1, x21, x1
    ad10:	eb00403f 	cmp	x1, x0, lsl #16
    ad14:	54000322 	b.cs	ad78 <f0+0x824>  // b.hs, b.nlast
    ad18:	d350fc22 	lsr	x2, x1, #16
    ad1c:	f949fc63 	ldr	x3, [x3, #5112]
    ad20:	8b020842 	add	x2, x2, x2, lsl #2
    ad24:	d37df042 	lsl	x2, x2, #3
    ad28:	8b020060 	add	x0, x3, x2
    ad2c:	f9401017 	ldr	x23, [x0, #32]
    ad30:	b4000257 	cbz	x23, ad78 <f0+0x824>
    ad34:	38626862 	ldrb	w2, [x3, x2]
    ad38:	7100085f 	cmp	w2, #0x2
    ad3c:	5400dfe0 	b.eq	c938 <f0+0x23e4>  // b.none
    ad40:	7100045f 	cmp	w2, #0x1
    ad44:	540001a1 	b.ne	ad78 <f0+0x824>  // b.any
    ad48:	29430002 	ldp	w2, w0, [x0, #24]
    ad4c:	92403c21 	and	x1, x1, #0xffff
    ad50:	9b027c21 	mul	x1, x1, x2
    ad54:	d360fc21 	lsr	x1, x1, #32
    ad58:	eb00003f 	cmp	x1, x0
    ad5c:	540000e2 	b.cs	ad78 <f0+0x824>  // b.hs, b.nlast
    ad60:	8b0102f7 	add	x23, x23, x1
    ad64:	394002e0 	ldrb	w0, [x23]
    ad68:	7103fc1f 	cmp	w0, #0xff
    ad6c:	5400e7c0 	b.eq	ca64 <f0+0x2510>  // b.none
    ad70:	52800020 	mov	w0, #0x1                   	// #1
    ad74:	390002e0 	strb	w0, [x23]
    ad78:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ad7c:	9107a3e1 	add	x1, sp, #0x1e8
    ad80:	52800020 	mov	w0, #0x1                   	// #1
    ad84:	a91ed7e2 	stp	x2, x21, [sp, #488]
    ad88:	97ffe932 	bl	5250 <fwp_data.part.0.constprop.0>
    ad8c:	91188283 	add	x3, x20, #0x620
    ad90:	aa0003f5 	mov	x21, x0
    ad94:	f949d861 	ldr	x1, [x3, #5040]
    ad98:	f949ec60 	ldr	x0, [x3, #5080]
    ad9c:	cb0102a1 	sub	x1, x21, x1
    ada0:	eb00403f 	cmp	x1, x0, lsl #16
    ada4:	54000322 	b.cs	ae08 <f0+0x8b4>  // b.hs, b.nlast
    ada8:	d350fc22 	lsr	x2, x1, #16
    adac:	f949fc63 	ldr	x3, [x3, #5112]
    adb0:	8b020842 	add	x2, x2, x2, lsl #2
    adb4:	d37df042 	lsl	x2, x2, #3
    adb8:	8b020060 	add	x0, x3, x2
    adbc:	f9401017 	ldr	x23, [x0, #32]
    adc0:	b4000257 	cbz	x23, ae08 <f0+0x8b4>
    adc4:	38626862 	ldrb	w2, [x3, x2]
    adc8:	7100085f 	cmp	w2, #0x2
    adcc:	5400dc80 	b.eq	c95c <f0+0x2408>  // b.none
    add0:	7100045f 	cmp	w2, #0x1
    add4:	540001a1 	b.ne	ae08 <f0+0x8b4>  // b.any
    add8:	29430002 	ldp	w2, w0, [x0, #24]
    addc:	92403c21 	and	x1, x1, #0xffff
    ade0:	9b027c21 	mul	x1, x1, x2
    ade4:	d360fc21 	lsr	x1, x1, #32
    ade8:	eb00003f 	cmp	x1, x0
    adec:	540000e2 	b.cs	ae08 <f0+0x8b4>  // b.hs, b.nlast
    adf0:	8b0102f7 	add	x23, x23, x1
    adf4:	394002e0 	ldrb	w0, [x23]
    adf8:	7103fc1f 	cmp	w0, #0xff
    adfc:	5400e3a0 	b.eq	ca70 <f0+0x251c>  // b.none
    ae00:	52800020 	mov	w0, #0x1                   	// #1
    ae04:	390002e0 	strb	w0, [x23]
    ae08:	9107e3e1 	add	x1, sp, #0x1f8
    ae0c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ae10:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ae14:	52800020 	mov	w0, #0x1                   	// #1
    ae18:	a91fd7f7 	stp	x23, x21, [sp, #504]
    ae1c:	97ffe90d 	bl	5250 <fwp_data.part.0.constprop.0>
    ae20:	97ffebec 	bl	5dd0 <fwp_rc_fresh>
    ae24:	aa0003e2 	mov	x2, x0
    ae28:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ae2c:	910823e1 	add	x1, sp, #0x208
    ae30:	52800020 	mov	w0, #0x1                   	// #1
    ae34:	f90107e3 	str	x3, [sp, #520]
    ae38:	f9010be2 	str	x2, [sp, #528]
    ae3c:	97ffe905 	bl	5250 <fwp_data.part.0.constprop.0>
    ae40:	97ffebe4 	bl	5dd0 <fwp_rc_fresh>
    ae44:	aa0003e2 	mov	x2, x0
    ae48:	910863e1 	add	x1, sp, #0x218
    ae4c:	52800020 	mov	w0, #0x1                   	// #1
    ae50:	f9010ff7 	str	x23, [sp, #536]
    ae54:	f90113e2 	str	x2, [sp, #544]
    ae58:	97ffe8fe 	bl	5250 <fwp_data.part.0.constprop.0>
    ae5c:	91188283 	add	x3, x20, #0x620
    ae60:	aa0003f5 	mov	x21, x0
    ae64:	f949d861 	ldr	x1, [x3, #5040]
    ae68:	f949ec60 	ldr	x0, [x3, #5080]
    ae6c:	cb0102a1 	sub	x1, x21, x1
    ae70:	eb00403f 	cmp	x1, x0, lsl #16
    ae74:	54000322 	b.cs	aed8 <f0+0x984>  // b.hs, b.nlast
    ae78:	d350fc22 	lsr	x2, x1, #16
    ae7c:	f949fc63 	ldr	x3, [x3, #5112]
    ae80:	8b020842 	add	x2, x2, x2, lsl #2
    ae84:	d37df042 	lsl	x2, x2, #3
    ae88:	8b020060 	add	x0, x3, x2
    ae8c:	f9401017 	ldr	x23, [x0, #32]
    ae90:	b4000257 	cbz	x23, aed8 <f0+0x984>
    ae94:	38626862 	ldrb	w2, [x3, x2]
    ae98:	7100085f 	cmp	w2, #0x2
    ae9c:	5400d5a0 	b.eq	c950 <f0+0x23fc>  // b.none
    aea0:	7100045f 	cmp	w2, #0x1
    aea4:	540001a1 	b.ne	aed8 <f0+0x984>  // b.any
    aea8:	29430002 	ldp	w2, w0, [x0, #24]
    aeac:	92403c21 	and	x1, x1, #0xffff
    aeb0:	9b027c21 	mul	x1, x1, x2
    aeb4:	d360fc21 	lsr	x1, x1, #32
    aeb8:	eb00003f 	cmp	x1, x0
    aebc:	540000e2 	b.cs	aed8 <f0+0x984>  // b.hs, b.nlast
    aec0:	8b0102f7 	add	x23, x23, x1
    aec4:	394002e0 	ldrb	w0, [x23]
    aec8:	7103fc1f 	cmp	w0, #0xff
    aecc:	5400dd80 	b.eq	ca7c <f0+0x2528>  // b.none
    aed0:	52800020 	mov	w0, #0x1                   	// #1
    aed4:	390002e0 	strb	w0, [x23]
    aed8:	9108a3e1 	add	x1, sp, #0x228
    aedc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aee0:	52800020 	mov	w0, #0x1                   	// #1
    aee4:	f90117e2 	str	x2, [sp, #552]
    aee8:	f9011bf5 	str	x21, [sp, #560]
    aeec:	97ffe8d9 	bl	5250 <fwp_data.part.0.constprop.0>
    aef0:	97ffebb8 	bl	5dd0 <fwp_rc_fresh>
    aef4:	aa0003e2 	mov	x2, x0
    aef8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aefc:	9108e3e1 	add	x1, sp, #0x238
    af00:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    af04:	52800020 	mov	w0, #0x1                   	// #1
    af08:	f9011fe3 	str	x3, [sp, #568]
    af0c:	f90123e2 	str	x2, [sp, #576]
    af10:	97ffe8d0 	bl	5250 <fwp_data.part.0.constprop.0>
    af14:	91188283 	add	x3, x20, #0x620
    af18:	aa0003f5 	mov	x21, x0
    af1c:	f949d861 	ldr	x1, [x3, #5040]
    af20:	f949ec60 	ldr	x0, [x3, #5080]
    af24:	cb0102a1 	sub	x1, x21, x1
    af28:	eb00403f 	cmp	x1, x0, lsl #16
    af2c:	54000322 	b.cs	af90 <f0+0xa3c>  // b.hs, b.nlast
    af30:	d350fc22 	lsr	x2, x1, #16
    af34:	f949fc63 	ldr	x3, [x3, #5112]
    af38:	8b020842 	add	x2, x2, x2, lsl #2
    af3c:	d37df042 	lsl	x2, x2, #3
    af40:	8b020060 	add	x0, x3, x2
    af44:	f9401017 	ldr	x23, [x0, #32]
    af48:	b4000257 	cbz	x23, af90 <f0+0xa3c>
    af4c:	38626862 	ldrb	w2, [x3, x2]
    af50:	7100085f 	cmp	w2, #0x2
    af54:	5400d100 	b.eq	c974 <f0+0x2420>  // b.none
    af58:	7100045f 	cmp	w2, #0x1
    af5c:	540001a1 	b.ne	af90 <f0+0xa3c>  // b.any
    af60:	29430002 	ldp	w2, w0, [x0, #24]
    af64:	92403c21 	and	x1, x1, #0xffff
    af68:	9b027c21 	mul	x1, x1, x2
    af6c:	d360fc21 	lsr	x1, x1, #32
    af70:	eb00003f 	cmp	x1, x0
    af74:	540000e2 	b.cs	af90 <f0+0xa3c>  // b.hs, b.nlast
    af78:	8b0102f7 	add	x23, x23, x1
    af7c:	394002e0 	ldrb	w0, [x23]
    af80:	7103fc1f 	cmp	w0, #0xff
    af84:	5400d820 	b.eq	ca88 <f0+0x2534>  // b.none
    af88:	52800020 	mov	w0, #0x1                   	// #1
    af8c:	390002e0 	strb	w0, [x23]
    af90:	910923e1 	add	x1, sp, #0x248
    af94:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    af98:	52800020 	mov	w0, #0x1                   	// #1
    af9c:	f90127f7 	str	x23, [sp, #584]
    afa0:	f9012bf5 	str	x21, [sp, #592]
    afa4:	97ffe8ab 	bl	5250 <fwp_data.part.0.constprop.0>
    afa8:	97ffeb8a 	bl	5dd0 <fwp_rc_fresh>
    afac:	aa0003e2 	mov	x2, x0
    afb0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    afb4:	910963e1 	add	x1, sp, #0x258
    afb8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    afbc:	52800020 	mov	w0, #0x1                   	// #1
    afc0:	f9012fe3 	str	x3, [sp, #600]
    afc4:	f90133e2 	str	x2, [sp, #608]
    afc8:	97ffe8a2 	bl	5250 <fwp_data.part.0.constprop.0>
    afcc:	97ffeb81 	bl	5dd0 <fwp_rc_fresh>
    afd0:	aa0003e2 	mov	x2, x0
    afd4:	9109a3e1 	add	x1, sp, #0x268
    afd8:	52800020 	mov	w0, #0x1                   	// #1
    afdc:	f90137f7 	str	x23, [sp, #616]
    afe0:	f9013be2 	str	x2, [sp, #624]
    afe4:	97ffe89b 	bl	5250 <fwp_data.part.0.constprop.0>
    afe8:	91188283 	add	x3, x20, #0x620
    afec:	aa0003f5 	mov	x21, x0
    aff0:	f949d861 	ldr	x1, [x3, #5040]
    aff4:	f949ec60 	ldr	x0, [x3, #5080]
    aff8:	cb0102a1 	sub	x1, x21, x1
    affc:	eb00403f 	cmp	x1, x0, lsl #16
    b000:	54000322 	b.cs	b064 <f0+0xb10>  // b.hs, b.nlast
    b004:	d350fc22 	lsr	x2, x1, #16
    b008:	f949fc63 	ldr	x3, [x3, #5112]
    b00c:	8b020842 	add	x2, x2, x2, lsl #2
    b010:	d37df042 	lsl	x2, x2, #3
    b014:	8b020060 	add	x0, x3, x2
    b018:	f9401017 	ldr	x23, [x0, #32]
    b01c:	b4000257 	cbz	x23, b064 <f0+0xb10>
    b020:	38626862 	ldrb	w2, [x3, x2]
    b024:	7100085f 	cmp	w2, #0x2
    b028:	5400ca00 	b.eq	c968 <f0+0x2414>  // b.none
    b02c:	7100045f 	cmp	w2, #0x1
    b030:	540001a1 	b.ne	b064 <f0+0xb10>  // b.any
    b034:	29430002 	ldp	w2, w0, [x0, #24]
    b038:	92403c21 	and	x1, x1, #0xffff
    b03c:	9b027c21 	mul	x1, x1, x2
    b040:	d360fc21 	lsr	x1, x1, #32
    b044:	eb00003f 	cmp	x1, x0
    b048:	540000e2 	b.cs	b064 <f0+0xb10>  // b.hs, b.nlast
    b04c:	8b0102f7 	add	x23, x23, x1
    b050:	394002e0 	ldrb	w0, [x23]
    b054:	7103fc1f 	cmp	w0, #0xff
    b058:	5400d1e0 	b.eq	ca94 <f0+0x2540>  // b.none
    b05c:	52800020 	mov	w0, #0x1                   	// #1
    b060:	390002e0 	strb	w0, [x23]
    b064:	9109e3e1 	add	x1, sp, #0x278
    b068:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b06c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b070:	52800020 	mov	w0, #0x1                   	// #1
    b074:	f9013ff7 	str	x23, [sp, #632]
    b078:	f90143f5 	str	x21, [sp, #640]
    b07c:	97ffe875 	bl	5250 <fwp_data.part.0.constprop.0>
    b080:	97ffeb54 	bl	5dd0 <fwp_rc_fresh>
    b084:	aa0003e2 	mov	x2, x0
    b088:	910a23e1 	add	x1, sp, #0x288
    b08c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b090:	52800020 	mov	w0, #0x1                   	// #1
    b094:	f90147f5 	str	x21, [sp, #648]
    b098:	f9014be2 	str	x2, [sp, #656]
    b09c:	97ffe86d 	bl	5250 <fwp_data.part.0.constprop.0>
    b0a0:	97ffeb4c 	bl	5dd0 <fwp_rc_fresh>
    b0a4:	aa0003e2 	mov	x2, x0
    b0a8:	910a63e1 	add	x1, sp, #0x298
    b0ac:	52800020 	mov	w0, #0x1                   	// #1
    b0b0:	f9014ff7 	str	x23, [sp, #664]
    b0b4:	f90153e2 	str	x2, [sp, #672]
    b0b8:	97ffe866 	bl	5250 <fwp_data.part.0.constprop.0>
    b0bc:	97ffeb45 	bl	5dd0 <fwp_rc_fresh>
    b0c0:	aa0003e2 	mov	x2, x0
    b0c4:	910aa3e1 	add	x1, sp, #0x2a8
    b0c8:	52800020 	mov	w0, #0x1                   	// #1
    b0cc:	f90157f5 	str	x21, [sp, #680]
    b0d0:	f9015be2 	str	x2, [sp, #688]
    b0d4:	97ffe85f 	bl	5250 <fwp_data.part.0.constprop.0>
    b0d8:	91188283 	add	x3, x20, #0x620
    b0dc:	aa0003f5 	mov	x21, x0
    b0e0:	f949d861 	ldr	x1, [x3, #5040]
    b0e4:	f949ec60 	ldr	x0, [x3, #5080]
    b0e8:	cb0102a1 	sub	x1, x21, x1
    b0ec:	eb00403f 	cmp	x1, x0, lsl #16
    b0f0:	54000322 	b.cs	b154 <f0+0xc00>  // b.hs, b.nlast
    b0f4:	d350fc22 	lsr	x2, x1, #16
    b0f8:	f949fc63 	ldr	x3, [x3, #5112]
    b0fc:	8b020842 	add	x2, x2, x2, lsl #2
    b100:	d37df042 	lsl	x2, x2, #3
    b104:	8b020060 	add	x0, x3, x2
    b108:	f9401017 	ldr	x23, [x0, #32]
    b10c:	b4000257 	cbz	x23, b154 <f0+0xc00>
    b110:	38626862 	ldrb	w2, [x3, x2]
    b114:	7100085f 	cmp	w2, #0x2
    b118:	5400c3a0 	b.eq	c98c <f0+0x2438>  // b.none
    b11c:	7100045f 	cmp	w2, #0x1
    b120:	540001a1 	b.ne	b154 <f0+0xc00>  // b.any
    b124:	29430002 	ldp	w2, w0, [x0, #24]
    b128:	92403c21 	and	x1, x1, #0xffff
    b12c:	9b027c21 	mul	x1, x1, x2
    b130:	d360fc21 	lsr	x1, x1, #32
    b134:	eb00003f 	cmp	x1, x0
    b138:	540000e2 	b.cs	b154 <f0+0xc00>  // b.hs, b.nlast
    b13c:	8b0102f7 	add	x23, x23, x1
    b140:	394002e0 	ldrb	w0, [x23]
    b144:	7103fc1f 	cmp	w0, #0xff
    b148:	5400cac0 	b.eq	caa0 <f0+0x254c>  // b.none
    b14c:	52800020 	mov	w0, #0x1                   	// #1
    b150:	390002e0 	strb	w0, [x23]
    b154:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b158:	910ae3e1 	add	x1, sp, #0x2b8
    b15c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b160:	52800020 	mov	w0, #0x1                   	// #1
    b164:	f9015fe2 	str	x2, [sp, #696]
    b168:	f90163f5 	str	x21, [sp, #704]
    b16c:	97ffe839 	bl	5250 <fwp_data.part.0.constprop.0>
    b170:	91188283 	add	x3, x20, #0x620
    b174:	aa0003f5 	mov	x21, x0
    b178:	f949d861 	ldr	x1, [x3, #5040]
    b17c:	f949ec60 	ldr	x0, [x3, #5080]
    b180:	cb0102a1 	sub	x1, x21, x1
    b184:	eb00403f 	cmp	x1, x0, lsl #16
    b188:	54000322 	b.cs	b1ec <f0+0xc98>  // b.hs, b.nlast
    b18c:	d350fc22 	lsr	x2, x1, #16
    b190:	f949fc63 	ldr	x3, [x3, #5112]
    b194:	8b020842 	add	x2, x2, x2, lsl #2
    b198:	d37df042 	lsl	x2, x2, #3
    b19c:	8b020060 	add	x0, x3, x2
    b1a0:	f9401017 	ldr	x23, [x0, #32]
    b1a4:	b4000257 	cbz	x23, b1ec <f0+0xc98>
    b1a8:	38626862 	ldrb	w2, [x3, x2]
    b1ac:	7100085f 	cmp	w2, #0x2
    b1b0:	5400be80 	b.eq	c980 <f0+0x242c>  // b.none
    b1b4:	7100045f 	cmp	w2, #0x1
    b1b8:	540001a1 	b.ne	b1ec <f0+0xc98>  // b.any
    b1bc:	29430002 	ldp	w2, w0, [x0, #24]
    b1c0:	92403c21 	and	x1, x1, #0xffff
    b1c4:	9b027c21 	mul	x1, x1, x2
    b1c8:	d360fc21 	lsr	x1, x1, #32
    b1cc:	eb00003f 	cmp	x1, x0
    b1d0:	540000e2 	b.cs	b1ec <f0+0xc98>  // b.hs, b.nlast
    b1d4:	8b0102f7 	add	x23, x23, x1
    b1d8:	394002e0 	ldrb	w0, [x23]
    b1dc:	7103fc1f 	cmp	w0, #0xff
    b1e0:	5400c660 	b.eq	caac <f0+0x2558>  // b.none
    b1e4:	52800020 	mov	w0, #0x1                   	// #1
    b1e8:	390002e0 	strb	w0, [x23]
    b1ec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b1f0:	910b23e1 	add	x1, sp, #0x2c8
    b1f4:	52800020 	mov	w0, #0x1                   	// #1
    b1f8:	f90167e2 	str	x2, [sp, #712]
    b1fc:	f9016bf5 	str	x21, [sp, #720]
    b200:	97ffe814 	bl	5250 <fwp_data.part.0.constprop.0>
    b204:	91188283 	add	x3, x20, #0x620
    b208:	aa0003f5 	mov	x21, x0
    b20c:	f949d861 	ldr	x1, [x3, #5040]
    b210:	f949ec60 	ldr	x0, [x3, #5080]
    b214:	cb0102a1 	sub	x1, x21, x1
    b218:	eb00403f 	cmp	x1, x0, lsl #16
    b21c:	54000322 	b.cs	b280 <f0+0xd2c>  // b.hs, b.nlast
    b220:	d350fc22 	lsr	x2, x1, #16
    b224:	f949fc63 	ldr	x3, [x3, #5112]
    b228:	8b020842 	add	x2, x2, x2, lsl #2
    b22c:	d37df042 	lsl	x2, x2, #3
    b230:	8b020060 	add	x0, x3, x2
    b234:	f9401017 	ldr	x23, [x0, #32]
    b238:	b4000257 	cbz	x23, b280 <f0+0xd2c>
    b23c:	38626862 	ldrb	w2, [x3, x2]
    b240:	7100085f 	cmp	w2, #0x2
    b244:	5400bb00 	b.eq	c9a4 <f0+0x2450>  // b.none
    b248:	7100045f 	cmp	w2, #0x1
    b24c:	540001a1 	b.ne	b280 <f0+0xd2c>  // b.any
    b250:	29430002 	ldp	w2, w0, [x0, #24]
    b254:	92403c21 	and	x1, x1, #0xffff
    b258:	9b027c21 	mul	x1, x1, x2
    b25c:	d360fc21 	lsr	x1, x1, #32
    b260:	eb00003f 	cmp	x1, x0
    b264:	540000e2 	b.cs	b280 <f0+0xd2c>  // b.hs, b.nlast
    b268:	8b0102f7 	add	x23, x23, x1
    b26c:	394002e0 	ldrb	w0, [x23]
    b270:	7103fc1f 	cmp	w0, #0xff
    b274:	5400c220 	b.eq	cab8 <f0+0x2564>  // b.none
    b278:	52800020 	mov	w0, #0x1                   	// #1
    b27c:	390002e0 	strb	w0, [x23]
    b280:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b284:	910b63e1 	add	x1, sp, #0x2d8
    b288:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b28c:	52800020 	mov	w0, #0x1                   	// #1
    b290:	f9016fe2 	str	x2, [sp, #728]
    b294:	f90173f5 	str	x21, [sp, #736]
    b298:	97ffe7ee 	bl	5250 <fwp_data.part.0.constprop.0>
    b29c:	91188283 	add	x3, x20, #0x620
    b2a0:	aa0003f5 	mov	x21, x0
    b2a4:	f949d861 	ldr	x1, [x3, #5040]
    b2a8:	f949ec60 	ldr	x0, [x3, #5080]
    b2ac:	cb0102a1 	sub	x1, x21, x1
    b2b0:	eb00403f 	cmp	x1, x0, lsl #16
    b2b4:	54000322 	b.cs	b318 <f0+0xdc4>  // b.hs, b.nlast
    b2b8:	d350fc22 	lsr	x2, x1, #16
    b2bc:	f949fc63 	ldr	x3, [x3, #5112]
    b2c0:	8b020842 	add	x2, x2, x2, lsl #2
    b2c4:	d37df042 	lsl	x2, x2, #3
    b2c8:	8b020060 	add	x0, x3, x2
    b2cc:	f9401017 	ldr	x23, [x0, #32]
    b2d0:	b4000257 	cbz	x23, b318 <f0+0xdc4>
    b2d4:	38626862 	ldrb	w2, [x3, x2]
    b2d8:	7100085f 	cmp	w2, #0x2
    b2dc:	5400b5e0 	b.eq	c998 <f0+0x2444>  // b.none
    b2e0:	7100045f 	cmp	w2, #0x1
    b2e4:	540001a1 	b.ne	b318 <f0+0xdc4>  // b.any
    b2e8:	29430002 	ldp	w2, w0, [x0, #24]
    b2ec:	92403c21 	and	x1, x1, #0xffff
    b2f0:	9b027c21 	mul	x1, x1, x2
    b2f4:	d360fc21 	lsr	x1, x1, #32
    b2f8:	eb00003f 	cmp	x1, x0
    b2fc:	540000e2 	b.cs	b318 <f0+0xdc4>  // b.hs, b.nlast
    b300:	8b0102f7 	add	x23, x23, x1
    b304:	394002e0 	ldrb	w0, [x23]
    b308:	7103fc1f 	cmp	w0, #0xff
    b30c:	5400bdc0 	b.eq	cac4 <f0+0x2570>  // b.none
    b310:	52800020 	mov	w0, #0x1                   	// #1
    b314:	390002e0 	strb	w0, [x23]
    b318:	910ba3e1 	add	x1, sp, #0x2e8
    b31c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b320:	52800020 	mov	w0, #0x1                   	// #1
    b324:	f90177e2 	str	x2, [sp, #744]
    b328:	f9017bf5 	str	x21, [sp, #752]
    b32c:	97ffe7c9 	bl	5250 <fwp_data.part.0.constprop.0>
    b330:	97ffeaa8 	bl	5dd0 <fwp_rc_fresh>
    b334:	aa0003e2 	mov	x2, x0
    b338:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b33c:	910be3e1 	add	x1, sp, #0x2f8
    b340:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b344:	52800020 	mov	w0, #0x1                   	// #1
    b348:	f9017fe3 	str	x3, [sp, #760]
    b34c:	f90183e2 	str	x2, [sp, #768]
    b350:	97ffe7c0 	bl	5250 <fwp_data.part.0.constprop.0>
    b354:	91188283 	add	x3, x20, #0x620
    b358:	aa0003f5 	mov	x21, x0
    b35c:	f949d861 	ldr	x1, [x3, #5040]
    b360:	f949ec60 	ldr	x0, [x3, #5080]
    b364:	cb0102a1 	sub	x1, x21, x1
    b368:	eb00403f 	cmp	x1, x0, lsl #16
    b36c:	54000322 	b.cs	b3d0 <f0+0xe7c>  // b.hs, b.nlast
    b370:	d350fc22 	lsr	x2, x1, #16
    b374:	f949fc63 	ldr	x3, [x3, #5112]
    b378:	8b020842 	add	x2, x2, x2, lsl #2
    b37c:	d37df042 	lsl	x2, x2, #3
    b380:	8b020060 	add	x0, x3, x2
    b384:	f9401017 	ldr	x23, [x0, #32]
    b388:	b4000257 	cbz	x23, b3d0 <f0+0xe7c>
    b38c:	38626862 	ldrb	w2, [x3, x2]
    b390:	7100085f 	cmp	w2, #0x2
    b394:	5400b140 	b.eq	c9bc <f0+0x2468>  // b.none
    b398:	7100045f 	cmp	w2, #0x1
    b39c:	540001a1 	b.ne	b3d0 <f0+0xe7c>  // b.any
    b3a0:	29430002 	ldp	w2, w0, [x0, #24]
    b3a4:	92403c21 	and	x1, x1, #0xffff
    b3a8:	9b027c21 	mul	x1, x1, x2
    b3ac:	d360fc21 	lsr	x1, x1, #32
    b3b0:	eb00003f 	cmp	x1, x0
    b3b4:	540000e2 	b.cs	b3d0 <f0+0xe7c>  // b.hs, b.nlast
    b3b8:	8b0102f7 	add	x23, x23, x1
    b3bc:	394002e0 	ldrb	w0, [x23]
    b3c0:	7103fc1f 	cmp	w0, #0xff
    b3c4:	5400b860 	b.eq	cad0 <f0+0x257c>  // b.none
    b3c8:	52800020 	mov	w0, #0x1                   	// #1
    b3cc:	390002e0 	strb	w0, [x23]
    b3d0:	910c23e1 	add	x1, sp, #0x308
    b3d4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b3d8:	52800020 	mov	w0, #0x1                   	// #1
    b3dc:	f90187f7 	str	x23, [sp, #776]
    b3e0:	f9018bf5 	str	x21, [sp, #784]
    b3e4:	97ffe79b 	bl	5250 <fwp_data.part.0.constprop.0>
    b3e8:	97ffea7a 	bl	5dd0 <fwp_rc_fresh>
    b3ec:	aa0003e2 	mov	x2, x0
    b3f0:	910c63e1 	add	x1, sp, #0x318
    b3f4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b3f8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b3fc:	52800020 	mov	w0, #0x1                   	// #1
    b400:	f9018ff5 	str	x21, [sp, #792]
    b404:	f90193e2 	str	x2, [sp, #800]
    b408:	97ffe792 	bl	5250 <fwp_data.part.0.constprop.0>
    b40c:	97ffea71 	bl	5dd0 <fwp_rc_fresh>
    b410:	aa0003e2 	mov	x2, x0
    b414:	910ca3e1 	add	x1, sp, #0x328
    b418:	52800020 	mov	w0, #0x1                   	// #1
    b41c:	f90197f7 	str	x23, [sp, #808]
    b420:	f9019be2 	str	x2, [sp, #816]
    b424:	97ffe78b 	bl	5250 <fwp_data.part.0.constprop.0>
    b428:	97ffea6a 	bl	5dd0 <fwp_rc_fresh>
    b42c:	aa0003e2 	mov	x2, x0
    b430:	910ce3e1 	add	x1, sp, #0x338
    b434:	52800020 	mov	w0, #0x1                   	// #1
    b438:	f9019ff5 	str	x21, [sp, #824]
    b43c:	f901a3e2 	str	x2, [sp, #832]
    b440:	97ffe784 	bl	5250 <fwp_data.part.0.constprop.0>
    b444:	91188283 	add	x3, x20, #0x620
    b448:	aa0003f5 	mov	x21, x0
    b44c:	f949d861 	ldr	x1, [x3, #5040]
    b450:	f949ec60 	ldr	x0, [x3, #5080]
    b454:	cb0102a1 	sub	x1, x21, x1
    b458:	eb00403f 	cmp	x1, x0, lsl #16
    b45c:	54000322 	b.cs	b4c0 <f0+0xf6c>  // b.hs, b.nlast
    b460:	d350fc22 	lsr	x2, x1, #16
    b464:	f949fc63 	ldr	x3, [x3, #5112]
    b468:	8b020842 	add	x2, x2, x2, lsl #2
    b46c:	d37df042 	lsl	x2, x2, #3
    b470:	8b020060 	add	x0, x3, x2
    b474:	f9401017 	ldr	x23, [x0, #32]
    b478:	b4000257 	cbz	x23, b4c0 <f0+0xf6c>
    b47c:	38626862 	ldrb	w2, [x3, x2]
    b480:	7100085f 	cmp	w2, #0x2
    b484:	5400a960 	b.eq	c9b0 <f0+0x245c>  // b.none
    b488:	7100045f 	cmp	w2, #0x1
    b48c:	540001a1 	b.ne	b4c0 <f0+0xf6c>  // b.any
    b490:	29430002 	ldp	w2, w0, [x0, #24]
    b494:	92403c21 	and	x1, x1, #0xffff
    b498:	9b027c21 	mul	x1, x1, x2
    b49c:	d360fc21 	lsr	x1, x1, #32
    b4a0:	eb00003f 	cmp	x1, x0
    b4a4:	540000e2 	b.cs	b4c0 <f0+0xf6c>  // b.hs, b.nlast
    b4a8:	8b0102f7 	add	x23, x23, x1
    b4ac:	394002e0 	ldrb	w0, [x23]
    b4b0:	7103fc1f 	cmp	w0, #0xff
    b4b4:	5400b140 	b.eq	cadc <f0+0x2588>  // b.none
    b4b8:	52800020 	mov	w0, #0x1                   	// #1
    b4bc:	390002e0 	strb	w0, [x23]
    b4c0:	910d23e1 	add	x1, sp, #0x348
    b4c4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b4c8:	52800020 	mov	w0, #0x1                   	// #1
    b4cc:	f901a7f7 	str	x23, [sp, #840]
    b4d0:	f901abf5 	str	x21, [sp, #848]
    b4d4:	97ffe75f 	bl	5250 <fwp_data.part.0.constprop.0>
    b4d8:	97ffea3e 	bl	5dd0 <fwp_rc_fresh>
    b4dc:	aa0003e2 	mov	x2, x0
    b4e0:	910d63e1 	add	x1, sp, #0x358
    b4e4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b4e8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b4ec:	52800020 	mov	w0, #0x1                   	// #1
    b4f0:	f901aff5 	str	x21, [sp, #856]
    b4f4:	f901b3e2 	str	x2, [sp, #864]
    b4f8:	97ffe756 	bl	5250 <fwp_data.part.0.constprop.0>
    b4fc:	97ffea35 	bl	5dd0 <fwp_rc_fresh>
    b500:	aa0003e2 	mov	x2, x0
    b504:	910da3e1 	add	x1, sp, #0x368
    b508:	52800020 	mov	w0, #0x1                   	// #1
    b50c:	f901b7f7 	str	x23, [sp, #872]
    b510:	f901bbe2 	str	x2, [sp, #880]
    b514:	97ffe74f 	bl	5250 <fwp_data.part.0.constprop.0>
    b518:	97ffea2e 	bl	5dd0 <fwp_rc_fresh>
    b51c:	aa0003e2 	mov	x2, x0
    b520:	910de3e1 	add	x1, sp, #0x378
    b524:	52800020 	mov	w0, #0x1                   	// #1
    b528:	f901bff5 	str	x21, [sp, #888]
    b52c:	f901c3e2 	str	x2, [sp, #896]
    b530:	97ffe748 	bl	5250 <fwp_data.part.0.constprop.0>
    b534:	97ffea27 	bl	5dd0 <fwp_rc_fresh>
    b538:	aa0003e2 	mov	x2, x0
    b53c:	910e23e1 	add	x1, sp, #0x388
    b540:	52800020 	mov	w0, #0x1                   	// #1
    b544:	f901c7f7 	str	x23, [sp, #904]
    b548:	f901cbe2 	str	x2, [sp, #912]
    b54c:	97ffe741 	bl	5250 <fwp_data.part.0.constprop.0>
    b550:	97ffea20 	bl	5dd0 <fwp_rc_fresh>
    b554:	aa0003e2 	mov	x2, x0
    b558:	910e63e1 	add	x1, sp, #0x398
    b55c:	52800020 	mov	w0, #0x1                   	// #1
    b560:	f901cff5 	str	x21, [sp, #920]
    b564:	f901d3e2 	str	x2, [sp, #928]
    b568:	97ffe73a 	bl	5250 <fwp_data.part.0.constprop.0>
    b56c:	97ffea19 	bl	5dd0 <fwp_rc_fresh>
    b570:	aa0003e2 	mov	x2, x0
    b574:	910ea3e1 	add	x1, sp, #0x3a8
    b578:	52800020 	mov	w0, #0x1                   	// #1
    b57c:	f901d7f7 	str	x23, [sp, #936]
    b580:	f901dbe2 	str	x2, [sp, #944]
    b584:	97ffe733 	bl	5250 <fwp_data.part.0.constprop.0>
    b588:	97ffea12 	bl	5dd0 <fwp_rc_fresh>
    b58c:	aa0003e2 	mov	x2, x0
    b590:	910ee3e1 	add	x1, sp, #0x3b8
    b594:	52800020 	mov	w0, #0x1                   	// #1
    b598:	f901dff5 	str	x21, [sp, #952]
    b59c:	f901e3e2 	str	x2, [sp, #960]
    b5a0:	97ffe72c 	bl	5250 <fwp_data.part.0.constprop.0>
    b5a4:	97ffea0b 	bl	5dd0 <fwp_rc_fresh>
    b5a8:	aa0003e2 	mov	x2, x0
    b5ac:	910f23e1 	add	x1, sp, #0x3c8
    b5b0:	52800020 	mov	w0, #0x1                   	// #1
    b5b4:	f901e7f7 	str	x23, [sp, #968]
    b5b8:	f901ebe2 	str	x2, [sp, #976]
    b5bc:	97ffe725 	bl	5250 <fwp_data.part.0.constprop.0>
    b5c0:	97ffea04 	bl	5dd0 <fwp_rc_fresh>
    b5c4:	aa0003e2 	mov	x2, x0
    b5c8:	910f63e1 	add	x1, sp, #0x3d8
    b5cc:	52800020 	mov	w0, #0x1                   	// #1
    b5d0:	f901eff5 	str	x21, [sp, #984]
    b5d4:	f901f3e2 	str	x2, [sp, #992]
    b5d8:	97ffe71e 	bl	5250 <fwp_data.part.0.constprop.0>
    b5dc:	97ffe9fd 	bl	5dd0 <fwp_rc_fresh>
    b5e0:	aa0003e2 	mov	x2, x0
    b5e4:	910fa3e1 	add	x1, sp, #0x3e8
    b5e8:	52800020 	mov	w0, #0x1                   	// #1
    b5ec:	f901f7f7 	str	x23, [sp, #1000]
    b5f0:	f901fbe2 	str	x2, [sp, #1008]
    b5f4:	97ffe717 	bl	5250 <fwp_data.part.0.constprop.0>
    b5f8:	97ffe9f6 	bl	5dd0 <fwp_rc_fresh>
    b5fc:	aa0003e2 	mov	x2, x0
    b600:	910fe3e1 	add	x1, sp, #0x3f8
    b604:	52800020 	mov	w0, #0x1                   	// #1
    b608:	f901fff5 	str	x21, [sp, #1016]
    b60c:	f90203e2 	str	x2, [sp, #1024]
    b610:	97ffe710 	bl	5250 <fwp_data.part.0.constprop.0>
    b614:	91188283 	add	x3, x20, #0x620
    b618:	aa0003f5 	mov	x21, x0
    b61c:	f949d861 	ldr	x1, [x3, #5040]
    b620:	f949ec60 	ldr	x0, [x3, #5080]
    b624:	cb0102a1 	sub	x1, x21, x1
    b628:	eb00403f 	cmp	x1, x0, lsl #16
    b62c:	54000322 	b.cs	b690 <f0+0x113c>  // b.hs, b.nlast
    b630:	d350fc22 	lsr	x2, x1, #16
    b634:	f949fc63 	ldr	x3, [x3, #5112]
    b638:	8b020842 	add	x2, x2, x2, lsl #2
    b63c:	d37df042 	lsl	x2, x2, #3
    b640:	8b020060 	add	x0, x3, x2
    b644:	f9401017 	ldr	x23, [x0, #32]
    b648:	b4000257 	cbz	x23, b690 <f0+0x113c>
    b64c:	38626862 	ldrb	w2, [x3, x2]
    b650:	7100085f 	cmp	w2, #0x2
    b654:	54009c00 	b.eq	c9d4 <f0+0x2480>  // b.none
    b658:	7100045f 	cmp	w2, #0x1
    b65c:	540001a1 	b.ne	b690 <f0+0x113c>  // b.any
    b660:	29430002 	ldp	w2, w0, [x0, #24]
    b664:	92403c21 	and	x1, x1, #0xffff
    b668:	9b027c21 	mul	x1, x1, x2
    b66c:	d360fc21 	lsr	x1, x1, #32
    b670:	eb00003f 	cmp	x1, x0
    b674:	540000e2 	b.cs	b690 <f0+0x113c>  // b.hs, b.nlast
    b678:	8b0102f7 	add	x23, x23, x1
    b67c:	394002e0 	ldrb	w0, [x23]
    b680:	7103fc1f 	cmp	w0, #0xff
    b684:	5400a320 	b.eq	cae8 <f0+0x2594>  // b.none
    b688:	52800020 	mov	w0, #0x1                   	// #1
    b68c:	390002e0 	strb	w0, [x23]
    b690:	911023e1 	add	x1, sp, #0x408
    b694:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b698:	52800020 	mov	w0, #0x1                   	// #1
    b69c:	f90207f7 	str	x23, [sp, #1032]
    b6a0:	f9020bf5 	str	x21, [sp, #1040]
    b6a4:	97ffe6eb 	bl	5250 <fwp_data.part.0.constprop.0>
    b6a8:	97ffe9ca 	bl	5dd0 <fwp_rc_fresh>
    b6ac:	aa0003e2 	mov	x2, x0
    b6b0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b6b4:	911063e1 	add	x1, sp, #0x418
    b6b8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b6bc:	52800020 	mov	w0, #0x1                   	// #1
    b6c0:	f9020fe3 	str	x3, [sp, #1048]
    b6c4:	f90213e2 	str	x2, [sp, #1056]
    b6c8:	97ffe6e2 	bl	5250 <fwp_data.part.0.constprop.0>
    b6cc:	97ffe9c1 	bl	5dd0 <fwp_rc_fresh>
    b6d0:	aa0003e2 	mov	x2, x0
    b6d4:	9110a3e1 	add	x1, sp, #0x428
    b6d8:	52800020 	mov	w0, #0x1                   	// #1
    b6dc:	f90217f7 	str	x23, [sp, #1064]
    b6e0:	f9021be2 	str	x2, [sp, #1072]
    b6e4:	97ffe6db 	bl	5250 <fwp_data.part.0.constprop.0>
    b6e8:	91188283 	add	x3, x20, #0x620
    b6ec:	aa0003f5 	mov	x21, x0
    b6f0:	f949d861 	ldr	x1, [x3, #5040]
    b6f4:	f949ec60 	ldr	x0, [x3, #5080]
    b6f8:	cb0102a1 	sub	x1, x21, x1
    b6fc:	eb00403f 	cmp	x1, x0, lsl #16
    b700:	54000322 	b.cs	b764 <f0+0x1210>  // b.hs, b.nlast
    b704:	d350fc22 	lsr	x2, x1, #16
    b708:	f949fc63 	ldr	x3, [x3, #5112]
    b70c:	8b020842 	add	x2, x2, x2, lsl #2
    b710:	d37df042 	lsl	x2, x2, #3
    b714:	8b020060 	add	x0, x3, x2
    b718:	f9401017 	ldr	x23, [x0, #32]
    b71c:	b4000257 	cbz	x23, b764 <f0+0x1210>
    b720:	38626862 	ldrb	w2, [x3, x2]
    b724:	7100085f 	cmp	w2, #0x2
    b728:	54009500 	b.eq	c9c8 <f0+0x2474>  // b.none
    b72c:	7100045f 	cmp	w2, #0x1
    b730:	540001a1 	b.ne	b764 <f0+0x1210>  // b.any
    b734:	29430002 	ldp	w2, w0, [x0, #24]
    b738:	92403c21 	and	x1, x1, #0xffff
    b73c:	9b027c21 	mul	x1, x1, x2
    b740:	d360fc21 	lsr	x1, x1, #32
    b744:	eb00003f 	cmp	x1, x0
    b748:	540000e2 	b.cs	b764 <f0+0x1210>  // b.hs, b.nlast
    b74c:	8b0102f7 	add	x23, x23, x1
    b750:	394002e0 	ldrb	w0, [x23]
    b754:	7103fc1f 	cmp	w0, #0xff
    b758:	54009ce0 	b.eq	caf4 <f0+0x25a0>  // b.none
    b75c:	52800020 	mov	w0, #0x1                   	// #1
    b760:	390002e0 	strb	w0, [x23]
    b764:	9110e3e1 	add	x1, sp, #0x438
    b768:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b76c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b770:	52800020 	mov	w0, #0x1                   	// #1
    b774:	f9021ff7 	str	x23, [sp, #1080]
    b778:	f90223f5 	str	x21, [sp, #1088]
    b77c:	97ffe6b5 	bl	5250 <fwp_data.part.0.constprop.0>
    b780:	97ffe994 	bl	5dd0 <fwp_rc_fresh>
    b784:	aa0003e2 	mov	x2, x0
    b788:	911123e1 	add	x1, sp, #0x448
    b78c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b790:	52800020 	mov	w0, #0x1                   	// #1
    b794:	f90227f5 	str	x21, [sp, #1096]
    b798:	f9022be2 	str	x2, [sp, #1104]
    b79c:	97ffe6ad 	bl	5250 <fwp_data.part.0.constprop.0>
    b7a0:	97ffe98c 	bl	5dd0 <fwp_rc_fresh>
    b7a4:	aa0003e2 	mov	x2, x0
    b7a8:	911163e1 	add	x1, sp, #0x458
    b7ac:	52800020 	mov	w0, #0x1                   	// #1
    b7b0:	f9022ff7 	str	x23, [sp, #1112]
    b7b4:	f90233e2 	str	x2, [sp, #1120]
    b7b8:	97ffe6a6 	bl	5250 <fwp_data.part.0.constprop.0>
    b7bc:	97ffe985 	bl	5dd0 <fwp_rc_fresh>
    b7c0:	aa0003e2 	mov	x2, x0
    b7c4:	9111a3e1 	add	x1, sp, #0x468
    b7c8:	52800020 	mov	w0, #0x1                   	// #1
    b7cc:	f90237f5 	str	x21, [sp, #1128]
    b7d0:	f9023be2 	str	x2, [sp, #1136]
    b7d4:	97ffe69f 	bl	5250 <fwp_data.part.0.constprop.0>
    b7d8:	97ffe97e 	bl	5dd0 <fwp_rc_fresh>
    b7dc:	aa0003e2 	mov	x2, x0
    b7e0:	9111e3e1 	add	x1, sp, #0x478
    b7e4:	52800020 	mov	w0, #0x1                   	// #1
    b7e8:	f9023ff7 	str	x23, [sp, #1144]
    b7ec:	f90243e2 	str	x2, [sp, #1152]
    b7f0:	97ffe698 	bl	5250 <fwp_data.part.0.constprop.0>
    b7f4:	91188283 	add	x3, x20, #0x620
    b7f8:	aa0003f5 	mov	x21, x0
    b7fc:	f949d861 	ldr	x1, [x3, #5040]
    b800:	f949ec60 	ldr	x0, [x3, #5080]
    b804:	cb0102a1 	sub	x1, x21, x1
    b808:	eb00403f 	cmp	x1, x0, lsl #16
    b80c:	54000322 	b.cs	b870 <f0+0x131c>  // b.hs, b.nlast
    b810:	d350fc22 	lsr	x2, x1, #16
    b814:	f949fc63 	ldr	x3, [x3, #5112]
    b818:	8b020842 	add	x2, x2, x2, lsl #2
    b81c:	d37df042 	lsl	x2, x2, #3
    b820:	8b020060 	add	x0, x3, x2
    b824:	f9401017 	ldr	x23, [x0, #32]
    b828:	b4000257 	cbz	x23, b870 <f0+0x131c>
    b82c:	38626862 	ldrb	w2, [x3, x2]
    b830:	7100085f 	cmp	w2, #0x2
    b834:	54008dc0 	b.eq	c9ec <f0+0x2498>  // b.none
    b838:	7100045f 	cmp	w2, #0x1
    b83c:	540001a1 	b.ne	b870 <f0+0x131c>  // b.any
    b840:	29430002 	ldp	w2, w0, [x0, #24]
    b844:	92403c21 	and	x1, x1, #0xffff
    b848:	9b027c21 	mul	x1, x1, x2
    b84c:	d360fc21 	lsr	x1, x1, #32
    b850:	eb00003f 	cmp	x1, x0
    b854:	540000e2 	b.cs	b870 <f0+0x131c>  // b.hs, b.nlast
    b858:	8b0102f7 	add	x23, x23, x1
    b85c:	394002e0 	ldrb	w0, [x23]
    b860:	7103fc1f 	cmp	w0, #0xff
    b864:	540094e0 	b.eq	cb00 <f0+0x25ac>  // b.none
    b868:	52800020 	mov	w0, #0x1                   	// #1
    b86c:	390002e0 	strb	w0, [x23]
    b870:	911223e1 	add	x1, sp, #0x488
    b874:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b878:	52800020 	mov	w0, #0x1                   	// #1
    b87c:	f90247f7 	str	x23, [sp, #1160]
    b880:	f9024bf5 	str	x21, [sp, #1168]
    b884:	97ffe673 	bl	5250 <fwp_data.part.0.constprop.0>
    b888:	97ffe952 	bl	5dd0 <fwp_rc_fresh>
    b88c:	aa0003e2 	mov	x2, x0
    b890:	911263e1 	add	x1, sp, #0x498
    b894:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b898:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b89c:	52800020 	mov	w0, #0x1                   	// #1
    b8a0:	f9024ff5 	str	x21, [sp, #1176]
    b8a4:	f90253e2 	str	x2, [sp, #1184]
    b8a8:	97ffe66a 	bl	5250 <fwp_data.part.0.constprop.0>
    b8ac:	97ffe949 	bl	5dd0 <fwp_rc_fresh>
    b8b0:	aa0003e2 	mov	x2, x0
    b8b4:	9112a3e1 	add	x1, sp, #0x4a8
    b8b8:	52800020 	mov	w0, #0x1                   	// #1
    b8bc:	f90257f7 	str	x23, [sp, #1192]
    b8c0:	f9025be2 	str	x2, [sp, #1200]
    b8c4:	97ffe663 	bl	5250 <fwp_data.part.0.constprop.0>
    b8c8:	97ffe942 	bl	5dd0 <fwp_rc_fresh>
    b8cc:	aa0003e2 	mov	x2, x0
    b8d0:	9112e3e1 	add	x1, sp, #0x4b8
    b8d4:	52800020 	mov	w0, #0x1                   	// #1
    b8d8:	f9025ff5 	str	x21, [sp, #1208]
    b8dc:	f90263e2 	str	x2, [sp, #1216]
    b8e0:	97ffe65c 	bl	5250 <fwp_data.part.0.constprop.0>
    b8e4:	91188283 	add	x3, x20, #0x620
    b8e8:	aa0003f5 	mov	x21, x0
    b8ec:	f949d861 	ldr	x1, [x3, #5040]
    b8f0:	f949ec60 	ldr	x0, [x3, #5080]
    b8f4:	cb0102a1 	sub	x1, x21, x1
    b8f8:	eb00403f 	cmp	x1, x0, lsl #16
    b8fc:	54000322 	b.cs	b960 <f0+0x140c>  // b.hs, b.nlast
    b900:	d350fc22 	lsr	x2, x1, #16
    b904:	f949fc63 	ldr	x3, [x3, #5112]
    b908:	8b020842 	add	x2, x2, x2, lsl #2
    b90c:	d37df042 	lsl	x2, x2, #3
    b910:	8b020060 	add	x0, x3, x2
    b914:	f9401017 	ldr	x23, [x0, #32]
    b918:	b4000257 	cbz	x23, b960 <f0+0x140c>
    b91c:	38626862 	ldrb	w2, [x3, x2]
    b920:	7100085f 	cmp	w2, #0x2
    b924:	540085e0 	b.eq	c9e0 <f0+0x248c>  // b.none
    b928:	7100045f 	cmp	w2, #0x1
    b92c:	540001a1 	b.ne	b960 <f0+0x140c>  // b.any
    b930:	29430002 	ldp	w2, w0, [x0, #24]
    b934:	92403c21 	and	x1, x1, #0xffff
    b938:	9b027c21 	mul	x1, x1, x2
    b93c:	d360fc21 	lsr	x1, x1, #32
    b940:	eb00003f 	cmp	x1, x0
    b944:	540000e2 	b.cs	b960 <f0+0x140c>  // b.hs, b.nlast
    b948:	8b0102f7 	add	x23, x23, x1
    b94c:	394002e0 	ldrb	w0, [x23]
    b950:	7103fc1f 	cmp	w0, #0xff
    b954:	54008dc0 	b.eq	cb0c <f0+0x25b8>  // b.none
    b958:	52800020 	mov	w0, #0x1                   	// #1
    b95c:	390002e0 	strb	w0, [x23]
    b960:	911323e1 	add	x1, sp, #0x4c8
    b964:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b968:	52800020 	mov	w0, #0x1                   	// #1
    b96c:	f90267f7 	str	x23, [sp, #1224]
    b970:	f9026bf5 	str	x21, [sp, #1232]
    b974:	97ffe637 	bl	5250 <fwp_data.part.0.constprop.0>
    b978:	97ffe916 	bl	5dd0 <fwp_rc_fresh>
    b97c:	aa0003e2 	mov	x2, x0
    b980:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b984:	911363e1 	add	x1, sp, #0x4d8
    b988:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b98c:	52800020 	mov	w0, #0x1                   	// #1
    b990:	f9026fe3 	str	x3, [sp, #1240]
    b994:	f90273e2 	str	x2, [sp, #1248]
    b998:	97ffe62e 	bl	5250 <fwp_data.part.0.constprop.0>
    b99c:	97ffe90d 	bl	5dd0 <fwp_rc_fresh>
    b9a0:	aa0003e2 	mov	x2, x0
    b9a4:	9113a3e1 	add	x1, sp, #0x4e8
    b9a8:	52800020 	mov	w0, #0x1                   	// #1
    b9ac:	f90277f7 	str	x23, [sp, #1256]
    b9b0:	f9027be2 	str	x2, [sp, #1264]
    b9b4:	97ffe627 	bl	5250 <fwp_data.part.0.constprop.0>
    b9b8:	91188283 	add	x3, x20, #0x620
    b9bc:	aa0003f5 	mov	x21, x0
    b9c0:	f949d861 	ldr	x1, [x3, #5040]
    b9c4:	f949ec60 	ldr	x0, [x3, #5080]
    b9c8:	cb0102a1 	sub	x1, x21, x1
    b9cc:	eb00403f 	cmp	x1, x0, lsl #16
    b9d0:	54000322 	b.cs	ba34 <f0+0x14e0>  // b.hs, b.nlast
    b9d4:	d350fc22 	lsr	x2, x1, #16
    b9d8:	f949fc63 	ldr	x3, [x3, #5112]
    b9dc:	8b020842 	add	x2, x2, x2, lsl #2
    b9e0:	d37df042 	lsl	x2, x2, #3
    b9e4:	8b020060 	add	x0, x3, x2
    b9e8:	f9401017 	ldr	x23, [x0, #32]
    b9ec:	b4000257 	cbz	x23, ba34 <f0+0x14e0>
    b9f0:	38626862 	ldrb	w2, [x3, x2]
    b9f4:	7100085f 	cmp	w2, #0x2
    b9f8:	54007460 	b.eq	c884 <f0+0x2330>  // b.none
    b9fc:	7100045f 	cmp	w2, #0x1
    ba00:	540001a1 	b.ne	ba34 <f0+0x14e0>  // b.any
    ba04:	29430002 	ldp	w2, w0, [x0, #24]
    ba08:	92403c21 	and	x1, x1, #0xffff
    ba0c:	9b027c21 	mul	x1, x1, x2
    ba10:	d360fc21 	lsr	x1, x1, #32
    ba14:	eb00003f 	cmp	x1, x0
    ba18:	540000e2 	b.cs	ba34 <f0+0x14e0>  // b.hs, b.nlast
    ba1c:	8b0102f7 	add	x23, x23, x1
    ba20:	394002e0 	ldrb	w0, [x23]
    ba24:	7103fc1f 	cmp	w0, #0xff
    ba28:	54008780 	b.eq	cb18 <f0+0x25c4>  // b.none
    ba2c:	52800020 	mov	w0, #0x1                   	// #1
    ba30:	390002e0 	strb	w0, [x23]
    ba34:	9113e3e1 	add	x1, sp, #0x4f8
    ba38:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ba3c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ba40:	52800020 	mov	w0, #0x1                   	// #1
    ba44:	f9027ff7 	str	x23, [sp, #1272]
    ba48:	f90283f5 	str	x21, [sp, #1280]
    ba4c:	97ffe601 	bl	5250 <fwp_data.part.0.constprop.0>
    ba50:	97ffe8e0 	bl	5dd0 <fwp_rc_fresh>
    ba54:	aa0003e2 	mov	x2, x0
    ba58:	911423e1 	add	x1, sp, #0x508
    ba5c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ba60:	52800020 	mov	w0, #0x1                   	// #1
    ba64:	f90287f5 	str	x21, [sp, #1288]
    ba68:	f9028be2 	str	x2, [sp, #1296]
    ba6c:	97ffe5f9 	bl	5250 <fwp_data.part.0.constprop.0>
    ba70:	97ffe8d8 	bl	5dd0 <fwp_rc_fresh>
    ba74:	aa0003e2 	mov	x2, x0
    ba78:	911463e1 	add	x1, sp, #0x518
    ba7c:	52800020 	mov	w0, #0x1                   	// #1
    ba80:	f9028ff7 	str	x23, [sp, #1304]
    ba84:	f90293e2 	str	x2, [sp, #1312]
    ba88:	97ffe5f2 	bl	5250 <fwp_data.part.0.constprop.0>
    ba8c:	97ffe8d1 	bl	5dd0 <fwp_rc_fresh>
    ba90:	aa0003e2 	mov	x2, x0
    ba94:	9114a3e1 	add	x1, sp, #0x528
    ba98:	52800020 	mov	w0, #0x1                   	// #1
    ba9c:	f90297f5 	str	x21, [sp, #1320]
    baa0:	f9029be2 	str	x2, [sp, #1328]
    baa4:	97ffe5eb 	bl	5250 <fwp_data.part.0.constprop.0>
    baa8:	97ffe8ca 	bl	5dd0 <fwp_rc_fresh>
    baac:	aa0003e2 	mov	x2, x0
    bab0:	9114e3e1 	add	x1, sp, #0x538
    bab4:	52800020 	mov	w0, #0x1                   	// #1
    bab8:	f9029ff7 	str	x23, [sp, #1336]
    babc:	f902a3e2 	str	x2, [sp, #1344]
    bac0:	97ffe5e4 	bl	5250 <fwp_data.part.0.constprop.0>
    bac4:	91188283 	add	x3, x20, #0x620
    bac8:	aa0003f7 	mov	x23, x0
    bacc:	f949d861 	ldr	x1, [x3, #5040]
    bad0:	f949ec60 	ldr	x0, [x3, #5080]
    bad4:	cb0102e1 	sub	x1, x23, x1
    bad8:	eb00403f 	cmp	x1, x0, lsl #16
    badc:	54000322 	b.cs	bb40 <f0+0x15ec>  // b.hs, b.nlast
    bae0:	d350fc22 	lsr	x2, x1, #16
    bae4:	f949fc63 	ldr	x3, [x3, #5112]
    bae8:	8b020842 	add	x2, x2, x2, lsl #2
    baec:	d37df042 	lsl	x2, x2, #3
    baf0:	8b020060 	add	x0, x3, x2
    baf4:	f9401015 	ldr	x21, [x0, #32]
    baf8:	b4000255 	cbz	x21, bb40 <f0+0x15ec>
    bafc:	38626862 	ldrb	w2, [x3, x2]
    bb00:	7100085f 	cmp	w2, #0x2
    bb04:	54006ba0 	b.eq	c878 <f0+0x2324>  // b.none
    bb08:	7100045f 	cmp	w2, #0x1
    bb0c:	540001a1 	b.ne	bb40 <f0+0x15ec>  // b.any
    bb10:	29430002 	ldp	w2, w0, [x0, #24]
    bb14:	92403c21 	and	x1, x1, #0xffff
    bb18:	9b027c21 	mul	x1, x1, x2
    bb1c:	d360fc21 	lsr	x1, x1, #32
    bb20:	eb00003f 	cmp	x1, x0
    bb24:	540000e2 	b.cs	bb40 <f0+0x15ec>  // b.hs, b.nlast
    bb28:	8b0102b5 	add	x21, x21, x1
    bb2c:	394002a0 	ldrb	w0, [x21]
    bb30:	7103fc1f 	cmp	w0, #0xff
    bb34:	54007f80 	b.eq	cb24 <f0+0x25d0>  // b.none
    bb38:	52800020 	mov	w0, #0x1                   	// #1
    bb3c:	390002a0 	strb	w0, [x21]
    bb40:	911523e1 	add	x1, sp, #0x548
    bb44:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bb48:	52800020 	mov	w0, #0x1                   	// #1
    bb4c:	f902a7f5 	str	x21, [sp, #1352]
    bb50:	f902abf7 	str	x23, [sp, #1360]
    bb54:	97ffe5bf 	bl	5250 <fwp_data.part.0.constprop.0>
    bb58:	97ffe89e 	bl	5dd0 <fwp_rc_fresh>
    bb5c:	aa0003e2 	mov	x2, x0
    bb60:	911563e1 	add	x1, sp, #0x558
    bb64:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bb68:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bb6c:	52800020 	mov	w0, #0x1                   	// #1
    bb70:	f902aff7 	str	x23, [sp, #1368]
    bb74:	f902b3e2 	str	x2, [sp, #1376]
    bb78:	97ffe5b6 	bl	5250 <fwp_data.part.0.constprop.0>
    bb7c:	97ffe895 	bl	5dd0 <fwp_rc_fresh>
    bb80:	aa0003e2 	mov	x2, x0
    bb84:	9115a3e1 	add	x1, sp, #0x568
    bb88:	52800020 	mov	w0, #0x1                   	// #1
    bb8c:	f902b7f5 	str	x21, [sp, #1384]
    bb90:	f902bbe2 	str	x2, [sp, #1392]
    bb94:	97ffe5af 	bl	5250 <fwp_data.part.0.constprop.0>
    bb98:	97ffe88e 	bl	5dd0 <fwp_rc_fresh>
    bb9c:	aa0003e2 	mov	x2, x0
    bba0:	9115e3e1 	add	x1, sp, #0x578
    bba4:	52800020 	mov	w0, #0x1                   	// #1
    bba8:	f902bff7 	str	x23, [sp, #1400]
    bbac:	f902c3e2 	str	x2, [sp, #1408]
    bbb0:	97ffe5a8 	bl	5250 <fwp_data.part.0.constprop.0>
    bbb4:	97ffe887 	bl	5dd0 <fwp_rc_fresh>
    bbb8:	aa0003e2 	mov	x2, x0
    bbbc:	911623e1 	add	x1, sp, #0x588
    bbc0:	52800020 	mov	w0, #0x1                   	// #1
    bbc4:	f902c7f5 	str	x21, [sp, #1416]
    bbc8:	f902cbe2 	str	x2, [sp, #1424]
    bbcc:	97ffe5a1 	bl	5250 <fwp_data.part.0.constprop.0>
    bbd0:	97ffe880 	bl	5dd0 <fwp_rc_fresh>
    bbd4:	aa0003e2 	mov	x2, x0
    bbd8:	911663e1 	add	x1, sp, #0x598
    bbdc:	52800020 	mov	w0, #0x1                   	// #1
    bbe0:	f902cff7 	str	x23, [sp, #1432]
    bbe4:	f902d3e2 	str	x2, [sp, #1440]
    bbe8:	97ffe59a 	bl	5250 <fwp_data.part.0.constprop.0>
    bbec:	97ffe879 	bl	5dd0 <fwp_rc_fresh>
    bbf0:	aa0003e2 	mov	x2, x0
    bbf4:	9116a3e1 	add	x1, sp, #0x5a8
    bbf8:	52800020 	mov	w0, #0x1                   	// #1
    bbfc:	f902d7f5 	str	x21, [sp, #1448]
    bc00:	f902dbe2 	str	x2, [sp, #1456]
    bc04:	97ffe593 	bl	5250 <fwp_data.part.0.constprop.0>
    bc08:	97ffe872 	bl	5dd0 <fwp_rc_fresh>
    bc0c:	aa0003e2 	mov	x2, x0
    bc10:	9116e3e1 	add	x1, sp, #0x5b8
    bc14:	52800020 	mov	w0, #0x1                   	// #1
    bc18:	f902dff7 	str	x23, [sp, #1464]
    bc1c:	f902e3e2 	str	x2, [sp, #1472]
    bc20:	97ffe58c 	bl	5250 <fwp_data.part.0.constprop.0>
    bc24:	97ffe86b 	bl	5dd0 <fwp_rc_fresh>
    bc28:	aa0003e2 	mov	x2, x0
    bc2c:	911723e1 	add	x1, sp, #0x5c8
    bc30:	52800020 	mov	w0, #0x1                   	// #1
    bc34:	f902e7f5 	str	x21, [sp, #1480]
    bc38:	f902ebe2 	str	x2, [sp, #1488]
    bc3c:	97ffe585 	bl	5250 <fwp_data.part.0.constprop.0>
    bc40:	97ffe864 	bl	5dd0 <fwp_rc_fresh>
    bc44:	aa0003e2 	mov	x2, x0
    bc48:	911763e1 	add	x1, sp, #0x5d8
    bc4c:	52800020 	mov	w0, #0x1                   	// #1
    bc50:	f902eff7 	str	x23, [sp, #1496]
    bc54:	f902f3e2 	str	x2, [sp, #1504]
    bc58:	97ffe57e 	bl	5250 <fwp_data.part.0.constprop.0>
    bc5c:	97ffe85d 	bl	5dd0 <fwp_rc_fresh>
    bc60:	aa0003e2 	mov	x2, x0
    bc64:	9117a3e1 	add	x1, sp, #0x5e8
    bc68:	52800020 	mov	w0, #0x1                   	// #1
    bc6c:	f902f7f5 	str	x21, [sp, #1512]
    bc70:	f902fbe2 	str	x2, [sp, #1520]
    bc74:	97ffe577 	bl	5250 <fwp_data.part.0.constprop.0>
    bc78:	91188283 	add	x3, x20, #0x620
    bc7c:	aa0003f5 	mov	x21, x0
    bc80:	f949d861 	ldr	x1, [x3, #5040]
    bc84:	f949ec60 	ldr	x0, [x3, #5080]
    bc88:	cb0102a1 	sub	x1, x21, x1
    bc8c:	eb00403f 	cmp	x1, x0, lsl #16
    bc90:	54000322 	b.cs	bcf4 <f0+0x17a0>  // b.hs, b.nlast
    bc94:	d350fc22 	lsr	x2, x1, #16
    bc98:	f949fc63 	ldr	x3, [x3, #5112]
    bc9c:	8b020842 	add	x2, x2, x2, lsl #2
    bca0:	d37df042 	lsl	x2, x2, #3
    bca4:	8b020060 	add	x0, x3, x2
    bca8:	f9401017 	ldr	x23, [x0, #32]
    bcac:	b4000257 	cbz	x23, bcf4 <f0+0x17a0>
    bcb0:	38626862 	ldrb	w2, [x3, x2]
    bcb4:	7100085f 	cmp	w2, #0x2
    bcb8:	54005f20 	b.eq	c89c <f0+0x2348>  // b.none
    bcbc:	7100045f 	cmp	w2, #0x1
    bcc0:	540001a1 	b.ne	bcf4 <f0+0x17a0>  // b.any
    bcc4:	29430002 	ldp	w2, w0, [x0, #24]
    bcc8:	92403c21 	and	x1, x1, #0xffff
    bccc:	9b027c21 	mul	x1, x1, x2
    bcd0:	d360fc21 	lsr	x1, x1, #32
    bcd4:	eb00003f 	cmp	x1, x0
    bcd8:	540000e2 	b.cs	bcf4 <f0+0x17a0>  // b.hs, b.nlast
    bcdc:	8b0102f7 	add	x23, x23, x1
    bce0:	394002e0 	ldrb	w0, [x23]
    bce4:	7103fc1f 	cmp	w0, #0xff
    bce8:	54007240 	b.eq	cb30 <f0+0x25dc>  // b.none
    bcec:	52800020 	mov	w0, #0x1                   	// #1
    bcf0:	390002e0 	strb	w0, [x23]
    bcf4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bcf8:	9117e3e1 	add	x1, sp, #0x5f8
    bcfc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bd00:	52800020 	mov	w0, #0x1                   	// #1
    bd04:	f902ffe2 	str	x2, [sp, #1528]
    bd08:	f90303f5 	str	x21, [sp, #1536]
    bd0c:	97ffe551 	bl	5250 <fwp_data.part.0.constprop.0>
    bd10:	91188283 	add	x3, x20, #0x620
    bd14:	aa0003f5 	mov	x21, x0
    bd18:	f949d861 	ldr	x1, [x3, #5040]
    bd1c:	f949ec60 	ldr	x0, [x3, #5080]
    bd20:	cb0102a1 	sub	x1, x21, x1
    bd24:	eb00403f 	cmp	x1, x0, lsl #16
    bd28:	54000322 	b.cs	bd8c <f0+0x1838>  // b.hs, b.nlast
    bd2c:	d350fc22 	lsr	x2, x1, #16
    bd30:	f949fc63 	ldr	x3, [x3, #5112]
    bd34:	8b020842 	add	x2, x2, x2, lsl #2
    bd38:	d37df042 	lsl	x2, x2, #3
    bd3c:	8b020060 	add	x0, x3, x2
    bd40:	f9401017 	ldr	x23, [x0, #32]
    bd44:	b4000257 	cbz	x23, bd8c <f0+0x1838>
    bd48:	38626862 	ldrb	w2, [x3, x2]
    bd4c:	7100085f 	cmp	w2, #0x2
    bd50:	54005a00 	b.eq	c890 <f0+0x233c>  // b.none
    bd54:	7100045f 	cmp	w2, #0x1
    bd58:	540001a1 	b.ne	bd8c <f0+0x1838>  // b.any
    bd5c:	29430002 	ldp	w2, w0, [x0, #24]
    bd60:	92403c21 	and	x1, x1, #0xffff
    bd64:	9b027c21 	mul	x1, x1, x2
    bd68:	d360fc21 	lsr	x1, x1, #32
    bd6c:	eb00003f 	cmp	x1, x0
    bd70:	540000e2 	b.cs	bd8c <f0+0x1838>  // b.hs, b.nlast
    bd74:	8b0102f7 	add	x23, x23, x1
    bd78:	394002e0 	ldrb	w0, [x23]
    bd7c:	7103fc1f 	cmp	w0, #0xff
    bd80:	54006de0 	b.eq	cb3c <f0+0x25e8>  // b.none
    bd84:	52800020 	mov	w0, #0x1                   	// #1
    bd88:	390002e0 	strb	w0, [x23]
    bd8c:	911823e1 	add	x1, sp, #0x608
    bd90:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bd94:	52800020 	mov	w0, #0x1                   	// #1
    bd98:	f90307f7 	str	x23, [sp, #1544]
    bd9c:	f9030bf5 	str	x21, [sp, #1552]
    bda0:	97ffe52c 	bl	5250 <fwp_data.part.0.constprop.0>
    bda4:	97ffe80b 	bl	5dd0 <fwp_rc_fresh>
    bda8:	aa0003e2 	mov	x2, x0
    bdac:	911863e1 	add	x1, sp, #0x618
    bdb0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bdb4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bdb8:	52800020 	mov	w0, #0x1                   	// #1
    bdbc:	f9030ff5 	str	x21, [sp, #1560]
    bdc0:	f90313e2 	str	x2, [sp, #1568]
    bdc4:	97ffe523 	bl	5250 <fwp_data.part.0.constprop.0>
    bdc8:	97ffe802 	bl	5dd0 <fwp_rc_fresh>
    bdcc:	aa0003e2 	mov	x2, x0
    bdd0:	9118a3e1 	add	x1, sp, #0x628
    bdd4:	52800020 	mov	w0, #0x1                   	// #1
    bdd8:	f90317f7 	str	x23, [sp, #1576]
    bddc:	f9031be2 	str	x2, [sp, #1584]
    bde0:	97ffe51c 	bl	5250 <fwp_data.part.0.constprop.0>
    bde4:	97ffe7fb 	bl	5dd0 <fwp_rc_fresh>
    bde8:	aa0003e2 	mov	x2, x0
    bdec:	9118e3e1 	add	x1, sp, #0x638
    bdf0:	52800020 	mov	w0, #0x1                   	// #1
    bdf4:	f9031ff5 	str	x21, [sp, #1592]
    bdf8:	f90323e2 	str	x2, [sp, #1600]
    bdfc:	97ffe515 	bl	5250 <fwp_data.part.0.constprop.0>
    be00:	91188283 	add	x3, x20, #0x620
    be04:	aa0003f5 	mov	x21, x0
    be08:	f949d861 	ldr	x1, [x3, #5040]
    be0c:	f949ec60 	ldr	x0, [x3, #5080]
    be10:	cb0102a1 	sub	x1, x21, x1
    be14:	eb00403f 	cmp	x1, x0, lsl #16
    be18:	54000322 	b.cs	be7c <f0+0x1928>  // b.hs, b.nlast
    be1c:	d350fc22 	lsr	x2, x1, #16
    be20:	f949fc63 	ldr	x3, [x3, #5112]
    be24:	8b020842 	add	x2, x2, x2, lsl #2
    be28:	d37df042 	lsl	x2, x2, #3
    be2c:	8b020060 	add	x0, x3, x2
    be30:	f9401017 	ldr	x23, [x0, #32]
    be34:	b4000257 	cbz	x23, be7c <f0+0x1928>
    be38:	38626862 	ldrb	w2, [x3, x2]
    be3c:	7100085f 	cmp	w2, #0x2
    be40:	540053a0 	b.eq	c8b4 <f0+0x2360>  // b.none
    be44:	7100045f 	cmp	w2, #0x1
    be48:	540001a1 	b.ne	be7c <f0+0x1928>  // b.any
    be4c:	29430002 	ldp	w2, w0, [x0, #24]
    be50:	92403c21 	and	x1, x1, #0xffff
    be54:	9b027c21 	mul	x1, x1, x2
    be58:	d360fc21 	lsr	x1, x1, #32
    be5c:	eb00003f 	cmp	x1, x0
    be60:	540000e2 	b.cs	be7c <f0+0x1928>  // b.hs, b.nlast
    be64:	8b0102f7 	add	x23, x23, x1
    be68:	394002e0 	ldrb	w0, [x23]
    be6c:	7103fc1f 	cmp	w0, #0xff
    be70:	540066c0 	b.eq	cb48 <f0+0x25f4>  // b.none
    be74:	52800020 	mov	w0, #0x1                   	// #1
    be78:	390002e0 	strb	w0, [x23]
    be7c:	911923e1 	add	x1, sp, #0x648
    be80:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    be84:	52800020 	mov	w0, #0x1                   	// #1
    be88:	f90327f7 	str	x23, [sp, #1608]
    be8c:	f9032bf5 	str	x21, [sp, #1616]
    be90:	97ffe4f0 	bl	5250 <fwp_data.part.0.constprop.0>
    be94:	97ffe7cf 	bl	5dd0 <fwp_rc_fresh>
    be98:	aa0003e2 	mov	x2, x0
    be9c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bea0:	911963e1 	add	x1, sp, #0x658
    bea4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bea8:	52800020 	mov	w0, #0x1                   	// #1
    beac:	f9032fe3 	str	x3, [sp, #1624]
    beb0:	f90333e2 	str	x2, [sp, #1632]
    beb4:	97ffe4e7 	bl	5250 <fwp_data.part.0.constprop.0>
    beb8:	97ffe7c6 	bl	5dd0 <fwp_rc_fresh>
    bebc:	aa0003e2 	mov	x2, x0
    bec0:	9119a3e1 	add	x1, sp, #0x668
    bec4:	52800020 	mov	w0, #0x1                   	// #1
    bec8:	f90337f7 	str	x23, [sp, #1640]
    becc:	f9033be2 	str	x2, [sp, #1648]
    bed0:	97ffe4e0 	bl	5250 <fwp_data.part.0.constprop.0>
    bed4:	91188283 	add	x3, x20, #0x620
    bed8:	aa0003f5 	mov	x21, x0
    bedc:	f949d861 	ldr	x1, [x3, #5040]
    bee0:	f949ec60 	ldr	x0, [x3, #5080]
    bee4:	cb0102a1 	sub	x1, x21, x1
    bee8:	eb00403f 	cmp	x1, x0, lsl #16
    beec:	54000322 	b.cs	bf50 <f0+0x19fc>  // b.hs, b.nlast
    bef0:	d350fc22 	lsr	x2, x1, #16
    bef4:	f949fc63 	ldr	x3, [x3, #5112]
    bef8:	8b020842 	add	x2, x2, x2, lsl #2
    befc:	d37df042 	lsl	x2, x2, #3
    bf00:	8b020060 	add	x0, x3, x2
    bf04:	f9401017 	ldr	x23, [x0, #32]
    bf08:	b4000257 	cbz	x23, bf50 <f0+0x19fc>
    bf0c:	38626862 	ldrb	w2, [x3, x2]
    bf10:	7100085f 	cmp	w2, #0x2
    bf14:	54004ca0 	b.eq	c8a8 <f0+0x2354>  // b.none
    bf18:	7100045f 	cmp	w2, #0x1
    bf1c:	540001a1 	b.ne	bf50 <f0+0x19fc>  // b.any
    bf20:	29430002 	ldp	w2, w0, [x0, #24]
    bf24:	92403c21 	and	x1, x1, #0xffff
    bf28:	9b027c21 	mul	x1, x1, x2
    bf2c:	d360fc21 	lsr	x1, x1, #32
    bf30:	eb00003f 	cmp	x1, x0
    bf34:	540000e2 	b.cs	bf50 <f0+0x19fc>  // b.hs, b.nlast
    bf38:	8b0102f7 	add	x23, x23, x1
    bf3c:	394002e0 	ldrb	w0, [x23]
    bf40:	7103fc1f 	cmp	w0, #0xff
    bf44:	54006080 	b.eq	cb54 <f0+0x2600>  // b.none
    bf48:	52800020 	mov	w0, #0x1                   	// #1
    bf4c:	390002e0 	strb	w0, [x23]
    bf50:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bf54:	9119e3e1 	add	x1, sp, #0x678
    bf58:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bf5c:	52800020 	mov	w0, #0x1                   	// #1
    bf60:	f9033fe2 	str	x2, [sp, #1656]
    bf64:	f90343f5 	str	x21, [sp, #1664]
    bf68:	97ffe4ba 	bl	5250 <fwp_data.part.0.constprop.0>
    bf6c:	91188283 	add	x3, x20, #0x620
    bf70:	aa0003f5 	mov	x21, x0
    bf74:	f949d861 	ldr	x1, [x3, #5040]
    bf78:	f949ec60 	ldr	x0, [x3, #5080]
    bf7c:	cb0102a1 	sub	x1, x21, x1
    bf80:	eb00403f 	cmp	x1, x0, lsl #16
    bf84:	54000322 	b.cs	bfe8 <f0+0x1a94>  // b.hs, b.nlast
    bf88:	d350fc22 	lsr	x2, x1, #16
    bf8c:	f949fc63 	ldr	x3, [x3, #5112]
    bf90:	8b020842 	add	x2, x2, x2, lsl #2
    bf94:	d37df042 	lsl	x2, x2, #3
    bf98:	8b020060 	add	x0, x3, x2
    bf9c:	f9401017 	ldr	x23, [x0, #32]
    bfa0:	b4000257 	cbz	x23, bfe8 <f0+0x1a94>
    bfa4:	38626862 	ldrb	w2, [x3, x2]
    bfa8:	7100085f 	cmp	w2, #0x2
    bfac:	54004900 	b.eq	c8cc <f0+0x2378>  // b.none
    bfb0:	7100045f 	cmp	w2, #0x1
    bfb4:	540001a1 	b.ne	bfe8 <f0+0x1a94>  // b.any
    bfb8:	29430002 	ldp	w2, w0, [x0, #24]
    bfbc:	92403c21 	and	x1, x1, #0xffff
    bfc0:	9b027c21 	mul	x1, x1, x2
    bfc4:	d360fc21 	lsr	x1, x1, #32
    bfc8:	eb00003f 	cmp	x1, x0
    bfcc:	540000e2 	b.cs	bfe8 <f0+0x1a94>  // b.hs, b.nlast
    bfd0:	8b0102f7 	add	x23, x23, x1
    bfd4:	394002e0 	ldrb	w0, [x23]
    bfd8:	7103fc1f 	cmp	w0, #0xff
    bfdc:	54005c20 	b.eq	cb60 <f0+0x260c>  // b.none
    bfe0:	52800020 	mov	w0, #0x1                   	// #1
    bfe4:	390002e0 	strb	w0, [x23]
    bfe8:	911a23e1 	add	x1, sp, #0x688
    bfec:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bff0:	52800020 	mov	w0, #0x1                   	// #1
    bff4:	f90347f7 	str	x23, [sp, #1672]
    bff8:	f9034bf5 	str	x21, [sp, #1680]
    bffc:	97ffe495 	bl	5250 <fwp_data.part.0.constprop.0>
    c000:	97ffe774 	bl	5dd0 <fwp_rc_fresh>
    c004:	aa0003e2 	mov	x2, x0
    c008:	911a63e1 	add	x1, sp, #0x698
    c00c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c010:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c014:	52800020 	mov	w0, #0x1                   	// #1
    c018:	f9034ff5 	str	x21, [sp, #1688]
    c01c:	f90353e2 	str	x2, [sp, #1696]
    c020:	97ffe48c 	bl	5250 <fwp_data.part.0.constprop.0>
    c024:	97ffe76b 	bl	5dd0 <fwp_rc_fresh>
    c028:	aa0003e2 	mov	x2, x0
    c02c:	911aa3e1 	add	x1, sp, #0x6a8
    c030:	52800020 	mov	w0, #0x1                   	// #1
    c034:	f90357f7 	str	x23, [sp, #1704]
    c038:	f9035be2 	str	x2, [sp, #1712]
    c03c:	97ffe485 	bl	5250 <fwp_data.part.0.constprop.0>
    c040:	97ffe764 	bl	5dd0 <fwp_rc_fresh>
    c044:	aa0003e2 	mov	x2, x0
    c048:	911ae3e1 	add	x1, sp, #0x6b8
    c04c:	52800020 	mov	w0, #0x1                   	// #1
    c050:	f9035ff5 	str	x21, [sp, #1720]
    c054:	f90363e2 	str	x2, [sp, #1728]
    c058:	97ffe47e 	bl	5250 <fwp_data.part.0.constprop.0>
    c05c:	91188283 	add	x3, x20, #0x620
    c060:	aa0003f5 	mov	x21, x0
    c064:	f949d861 	ldr	x1, [x3, #5040]
    c068:	f949ec60 	ldr	x0, [x3, #5080]
    c06c:	cb0102a1 	sub	x1, x21, x1
    c070:	eb00403f 	cmp	x1, x0, lsl #16
    c074:	54000322 	b.cs	c0d8 <f0+0x1b84>  // b.hs, b.nlast
    c078:	d350fc22 	lsr	x2, x1, #16
    c07c:	f949fc63 	ldr	x3, [x3, #5112]
    c080:	8b020842 	add	x2, x2, x2, lsl #2
    c084:	d37df042 	lsl	x2, x2, #3
    c088:	8b020060 	add	x0, x3, x2
    c08c:	f9401017 	ldr	x23, [x0, #32]
    c090:	b4000257 	cbz	x23, c0d8 <f0+0x1b84>
    c094:	38626862 	ldrb	w2, [x3, x2]
    c098:	7100085f 	cmp	w2, #0x2
    c09c:	54004120 	b.eq	c8c0 <f0+0x236c>  // b.none
    c0a0:	7100045f 	cmp	w2, #0x1
    c0a4:	540001a1 	b.ne	c0d8 <f0+0x1b84>  // b.any
    c0a8:	29430002 	ldp	w2, w0, [x0, #24]
    c0ac:	92403c21 	and	x1, x1, #0xffff
    c0b0:	9b027c21 	mul	x1, x1, x2
    c0b4:	d360fc21 	lsr	x1, x1, #32
    c0b8:	eb00003f 	cmp	x1, x0
    c0bc:	540000e2 	b.cs	c0d8 <f0+0x1b84>  // b.hs, b.nlast
    c0c0:	8b0102f7 	add	x23, x23, x1
    c0c4:	394002e0 	ldrb	w0, [x23]
    c0c8:	7103fc1f 	cmp	w0, #0xff
    c0cc:	54005500 	b.eq	cb6c <f0+0x2618>  // b.none
    c0d0:	52800020 	mov	w0, #0x1                   	// #1
    c0d4:	390002e0 	strb	w0, [x23]
    c0d8:	911b23e1 	add	x1, sp, #0x6c8
    c0dc:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c0e0:	52800020 	mov	w0, #0x1                   	// #1
    c0e4:	f90367f7 	str	x23, [sp, #1736]
    c0e8:	f9036bf5 	str	x21, [sp, #1744]
    c0ec:	97ffe459 	bl	5250 <fwp_data.part.0.constprop.0>
    c0f0:	97ffe738 	bl	5dd0 <fwp_rc_fresh>
    c0f4:	aa0003e2 	mov	x2, x0
    c0f8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c0fc:	911b63e1 	add	x1, sp, #0x6d8
    c100:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c104:	52800020 	mov	w0, #0x1                   	// #1
    c108:	f9036fe3 	str	x3, [sp, #1752]
    c10c:	f90373e2 	str	x2, [sp, #1760]
    c110:	97ffe450 	bl	5250 <fwp_data.part.0.constprop.0>
    c114:	97ffe72f 	bl	5dd0 <fwp_rc_fresh>
    c118:	aa0003e2 	mov	x2, x0
    c11c:	911ba3e1 	add	x1, sp, #0x6e8
    c120:	52800020 	mov	w0, #0x1                   	// #1
    c124:	f90377f7 	str	x23, [sp, #1768]
    c128:	f9037be2 	str	x2, [sp, #1776]
    c12c:	97ffe449 	bl	5250 <fwp_data.part.0.constprop.0>
    c130:	91188283 	add	x3, x20, #0x620
    c134:	aa0003f5 	mov	x21, x0
    c138:	f949d861 	ldr	x1, [x3, #5040]
    c13c:	f949ec60 	ldr	x0, [x3, #5080]
    c140:	cb0102a1 	sub	x1, x21, x1
    c144:	eb00403f 	cmp	x1, x0, lsl #16
    c148:	54000322 	b.cs	c1ac <f0+0x1c58>  // b.hs, b.nlast
    c14c:	d350fc22 	lsr	x2, x1, #16
    c150:	f949fc63 	ldr	x3, [x3, #5112]
    c154:	8b020842 	add	x2, x2, x2, lsl #2
    c158:	d37df042 	lsl	x2, x2, #3
    c15c:	8b020060 	add	x0, x3, x2
    c160:	f9401017 	ldr	x23, [x0, #32]
    c164:	b4000257 	cbz	x23, c1ac <f0+0x1c58>
    c168:	38626862 	ldrb	w2, [x3, x2]
    c16c:	7100085f 	cmp	w2, #0x2
    c170:	54003ba0 	b.eq	c8e4 <f0+0x2390>  // b.none
    c174:	7100045f 	cmp	w2, #0x1
    c178:	540001a1 	b.ne	c1ac <f0+0x1c58>  // b.any
    c17c:	29430002 	ldp	w2, w0, [x0, #24]
    c180:	92403c21 	and	x1, x1, #0xffff
    c184:	9b027c21 	mul	x1, x1, x2
    c188:	d360fc21 	lsr	x1, x1, #32
    c18c:	eb00003f 	cmp	x1, x0
    c190:	540000e2 	b.cs	c1ac <f0+0x1c58>  // b.hs, b.nlast
    c194:	8b0102f7 	add	x23, x23, x1
    c198:	394002e0 	ldrb	w0, [x23]
    c19c:	7103fc1f 	cmp	w0, #0xff
    c1a0:	54004ec0 	b.eq	cb78 <f0+0x2624>  // b.none
    c1a4:	52800020 	mov	w0, #0x1                   	// #1
    c1a8:	390002e0 	strb	w0, [x23]
    c1ac:	911be3e1 	add	x1, sp, #0x6f8
    c1b0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c1b4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c1b8:	52800020 	mov	w0, #0x1                   	// #1
    c1bc:	f9037ff7 	str	x23, [sp, #1784]
    c1c0:	f90383f5 	str	x21, [sp, #1792]
    c1c4:	97ffe423 	bl	5250 <fwp_data.part.0.constprop.0>
    c1c8:	97ffe702 	bl	5dd0 <fwp_rc_fresh>
    c1cc:	aa0003e2 	mov	x2, x0
    c1d0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c1d4:	911c23e1 	add	x1, sp, #0x708
    c1d8:	52800020 	mov	w0, #0x1                   	// #1
    c1dc:	f90387e3 	str	x3, [sp, #1800]
    c1e0:	f9038be2 	str	x2, [sp, #1808]
    c1e4:	97ffe41b 	bl	5250 <fwp_data.part.0.constprop.0>
    c1e8:	97ffe6fa 	bl	5dd0 <fwp_rc_fresh>
    c1ec:	aa0003e2 	mov	x2, x0
    c1f0:	911c63e1 	add	x1, sp, #0x718
    c1f4:	52800020 	mov	w0, #0x1                   	// #1
    c1f8:	f9038ff7 	str	x23, [sp, #1816]
    c1fc:	f90393e2 	str	x2, [sp, #1824]
    c200:	97ffe414 	bl	5250 <fwp_data.part.0.constprop.0>
    c204:	91188283 	add	x3, x20, #0x620
    c208:	aa0003f5 	mov	x21, x0
    c20c:	f949d861 	ldr	x1, [x3, #5040]
    c210:	f949ec60 	ldr	x0, [x3, #5080]
    c214:	cb0102a1 	sub	x1, x21, x1
    c218:	eb00403f 	cmp	x1, x0, lsl #16
    c21c:	54000322 	b.cs	c280 <f0+0x1d2c>  // b.hs, b.nlast
    c220:	d350fc22 	lsr	x2, x1, #16
    c224:	f949fc63 	ldr	x3, [x3, #5112]
    c228:	8b020842 	add	x2, x2, x2, lsl #2
    c22c:	d37df042 	lsl	x2, x2, #3
    c230:	8b020060 	add	x0, x3, x2
    c234:	f9401017 	ldr	x23, [x0, #32]
    c238:	b4000257 	cbz	x23, c280 <f0+0x1d2c>
    c23c:	38626862 	ldrb	w2, [x3, x2]
    c240:	7100085f 	cmp	w2, #0x2
    c244:	540034a0 	b.eq	c8d8 <f0+0x2384>  // b.none
    c248:	7100045f 	cmp	w2, #0x1
    c24c:	540001a1 	b.ne	c280 <f0+0x1d2c>  // b.any
    c250:	29430002 	ldp	w2, w0, [x0, #24]
    c254:	92403c21 	and	x1, x1, #0xffff
    c258:	9b027c21 	mul	x1, x1, x2
    c25c:	d360fc21 	lsr	x1, x1, #32
    c260:	eb00003f 	cmp	x1, x0
    c264:	540000e2 	b.cs	c280 <f0+0x1d2c>  // b.hs, b.nlast
    c268:	8b0102f7 	add	x23, x23, x1
    c26c:	394002e0 	ldrb	w0, [x23]
    c270:	7103fc1f 	cmp	w0, #0xff
    c274:	54004880 	b.eq	cb84 <f0+0x2630>  // b.none
    c278:	52800020 	mov	w0, #0x1                   	// #1
    c27c:	390002e0 	strb	w0, [x23]
    c280:	911ca3e1 	add	x1, sp, #0x728
    c284:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c288:	52800020 	mov	w0, #0x1                   	// #1
    c28c:	f90397e2 	str	x2, [sp, #1832]
    c290:	f9039bf5 	str	x21, [sp, #1840]
    c294:	97ffe3ef 	bl	5250 <fwp_data.part.0.constprop.0>
    c298:	97ffe6ce 	bl	5dd0 <fwp_rc_fresh>
    c29c:	aa0003e2 	mov	x2, x0
    c2a0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c2a4:	911ce3e1 	add	x1, sp, #0x738
    c2a8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c2ac:	52800020 	mov	w0, #0x1                   	// #1
    c2b0:	f9039fe3 	str	x3, [sp, #1848]
    c2b4:	f903a3e2 	str	x2, [sp, #1856]
    c2b8:	97ffe3e6 	bl	5250 <fwp_data.part.0.constprop.0>
    c2bc:	91188283 	add	x3, x20, #0x620
    c2c0:	aa0003f5 	mov	x21, x0
    c2c4:	f949d861 	ldr	x1, [x3, #5040]
    c2c8:	f949ec60 	ldr	x0, [x3, #5080]
    c2cc:	cb0102a1 	sub	x1, x21, x1
    c2d0:	eb00403f 	cmp	x1, x0, lsl #16
    c2d4:	54000322 	b.cs	c338 <f0+0x1de4>  // b.hs, b.nlast
    c2d8:	d350fc22 	lsr	x2, x1, #16
    c2dc:	f949fc63 	ldr	x3, [x3, #5112]
    c2e0:	8b020842 	add	x2, x2, x2, lsl #2
    c2e4:	d37df042 	lsl	x2, x2, #3
    c2e8:	8b020060 	add	x0, x3, x2
    c2ec:	f9401017 	ldr	x23, [x0, #32]
    c2f0:	b4000257 	cbz	x23, c338 <f0+0x1de4>
    c2f4:	38626862 	ldrb	w2, [x3, x2]
    c2f8:	7100085f 	cmp	w2, #0x2
    c2fc:	54003000 	b.eq	c8fc <f0+0x23a8>  // b.none
    c300:	7100045f 	cmp	w2, #0x1
    c304:	540001a1 	b.ne	c338 <f0+0x1de4>  // b.any
    c308:	29430002 	ldp	w2, w0, [x0, #24]
    c30c:	92403c21 	and	x1, x1, #0xffff
    c310:	9b027c21 	mul	x1, x1, x2
    c314:	d360fc21 	lsr	x1, x1, #32
    c318:	eb00003f 	cmp	x1, x0
    c31c:	540000e2 	b.cs	c338 <f0+0x1de4>  // b.hs, b.nlast
    c320:	8b0102f7 	add	x23, x23, x1
    c324:	394002e0 	ldrb	w0, [x23]
    c328:	7103fc1f 	cmp	w0, #0xff
    c32c:	54004320 	b.eq	cb90 <f0+0x263c>  // b.none
    c330:	52800020 	mov	w0, #0x1                   	// #1
    c334:	390002e0 	strb	w0, [x23]
    c338:	911d23e1 	add	x1, sp, #0x748
    c33c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c340:	52800020 	mov	w0, #0x1                   	// #1
    c344:	f903a7f7 	str	x23, [sp, #1864]
    c348:	f903abf5 	str	x21, [sp, #1872]
    c34c:	97ffe3c1 	bl	5250 <fwp_data.part.0.constprop.0>
    c350:	97ffe6a0 	bl	5dd0 <fwp_rc_fresh>
    c354:	aa0003e2 	mov	x2, x0
    c358:	911d63e1 	add	x1, sp, #0x758
    c35c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c360:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c364:	52800020 	mov	w0, #0x1                   	// #1
    c368:	f903aff5 	str	x21, [sp, #1880]
    c36c:	f903b3e2 	str	x2, [sp, #1888]
    c370:	97ffe3b8 	bl	5250 <fwp_data.part.0.constprop.0>
    c374:	97ffe697 	bl	5dd0 <fwp_rc_fresh>
    c378:	aa0003e2 	mov	x2, x0
    c37c:	911da3e1 	add	x1, sp, #0x768
    c380:	52800020 	mov	w0, #0x1                   	// #1
    c384:	f903b7f7 	str	x23, [sp, #1896]
    c388:	f903bbe2 	str	x2, [sp, #1904]
    c38c:	97ffe3b1 	bl	5250 <fwp_data.part.0.constprop.0>
    c390:	97ffe690 	bl	5dd0 <fwp_rc_fresh>
    c394:	aa0003e2 	mov	x2, x0
    c398:	911de3e1 	add	x1, sp, #0x778
    c39c:	52800020 	mov	w0, #0x1                   	// #1
    c3a0:	f903bff5 	str	x21, [sp, #1912]
    c3a4:	f903c3e2 	str	x2, [sp, #1920]
    c3a8:	97ffe3aa 	bl	5250 <fwp_data.part.0.constprop.0>
    c3ac:	91188283 	add	x3, x20, #0x620
    c3b0:	aa0003f5 	mov	x21, x0
    c3b4:	f949d861 	ldr	x1, [x3, #5040]
    c3b8:	f949ec60 	ldr	x0, [x3, #5080]
    c3bc:	cb0102a1 	sub	x1, x21, x1
    c3c0:	eb00403f 	cmp	x1, x0, lsl #16
    c3c4:	54000322 	b.cs	c428 <f0+0x1ed4>  // b.hs, b.nlast
    c3c8:	d350fc22 	lsr	x2, x1, #16
    c3cc:	f949fc63 	ldr	x3, [x3, #5112]
    c3d0:	8b020842 	add	x2, x2, x2, lsl #2
    c3d4:	d37df042 	lsl	x2, x2, #3
    c3d8:	8b020060 	add	x0, x3, x2
    c3dc:	f9401017 	ldr	x23, [x0, #32]
    c3e0:	b4000257 	cbz	x23, c428 <f0+0x1ed4>
    c3e4:	38626862 	ldrb	w2, [x3, x2]
    c3e8:	7100085f 	cmp	w2, #0x2
    c3ec:	54002820 	b.eq	c8f0 <f0+0x239c>  // b.none
    c3f0:	7100045f 	cmp	w2, #0x1
    c3f4:	540001a1 	b.ne	c428 <f0+0x1ed4>  // b.any
    c3f8:	29430002 	ldp	w2, w0, [x0, #24]
    c3fc:	92403c21 	and	x1, x1, #0xffff
    c400:	9b027c21 	mul	x1, x1, x2
    c404:	d360fc21 	lsr	x1, x1, #32
    c408:	eb00003f 	cmp	x1, x0
    c40c:	540000e2 	b.cs	c428 <f0+0x1ed4>  // b.hs, b.nlast
    c410:	8b0102f7 	add	x23, x23, x1
    c414:	394002e0 	ldrb	w0, [x23]
    c418:	7103fc1f 	cmp	w0, #0xff
    c41c:	54003c00 	b.eq	cb9c <f0+0x2648>  // b.none
    c420:	52800020 	mov	w0, #0x1                   	// #1
    c424:	390002e0 	strb	w0, [x23]
    c428:	911e23e1 	add	x1, sp, #0x788
    c42c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c430:	52800020 	mov	w0, #0x1                   	// #1
    c434:	f903c7e2 	str	x2, [sp, #1928]
    c438:	f903cbf5 	str	x21, [sp, #1936]
    c43c:	97ffe385 	bl	5250 <fwp_data.part.0.constprop.0>
    c440:	97ffe664 	bl	5dd0 <fwp_rc_fresh>
    c444:	aa0003e2 	mov	x2, x0
    c448:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c44c:	911e63e1 	add	x1, sp, #0x798
    c450:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c454:	52800020 	mov	w0, #0x1                   	// #1
    c458:	f903cfe3 	str	x3, [sp, #1944]
    c45c:	f903d3e2 	str	x2, [sp, #1952]
    c460:	97ffe37c 	bl	5250 <fwp_data.part.0.constprop.0>
    c464:	91188283 	add	x3, x20, #0x620
    c468:	aa0003f5 	mov	x21, x0
    c46c:	f949d861 	ldr	x1, [x3, #5040]
    c470:	f949ec60 	ldr	x0, [x3, #5080]
    c474:	cb0102a1 	sub	x1, x21, x1
    c478:	eb00403f 	cmp	x1, x0, lsl #16
    c47c:	54000322 	b.cs	c4e0 <f0+0x1f8c>  // b.hs, b.nlast
    c480:	d350fc22 	lsr	x2, x1, #16
    c484:	f949fc63 	ldr	x3, [x3, #5112]
    c488:	8b020842 	add	x2, x2, x2, lsl #2
    c48c:	d37df042 	lsl	x2, x2, #3
    c490:	8b020060 	add	x0, x3, x2
    c494:	f9401017 	ldr	x23, [x0, #32]
    c498:	b4000257 	cbz	x23, c4e0 <f0+0x1f8c>
    c49c:	38626862 	ldrb	w2, [x3, x2]
    c4a0:	7100085f 	cmp	w2, #0x2
    c4a4:	54002380 	b.eq	c914 <f0+0x23c0>  // b.none
    c4a8:	7100045f 	cmp	w2, #0x1
    c4ac:	540001a1 	b.ne	c4e0 <f0+0x1f8c>  // b.any
    c4b0:	29430002 	ldp	w2, w0, [x0, #24]
    c4b4:	92403c21 	and	x1, x1, #0xffff
    c4b8:	9b027c21 	mul	x1, x1, x2
    c4bc:	d360fc21 	lsr	x1, x1, #32
    c4c0:	eb00003f 	cmp	x1, x0
    c4c4:	540000e2 	b.cs	c4e0 <f0+0x1f8c>  // b.hs, b.nlast
    c4c8:	8b0102f7 	add	x23, x23, x1
    c4cc:	394002e0 	ldrb	w0, [x23]
    c4d0:	7103fc1f 	cmp	w0, #0xff
    c4d4:	540036a0 	b.eq	cba8 <f0+0x2654>  // b.none
    c4d8:	52800020 	mov	w0, #0x1                   	// #1
    c4dc:	390002e0 	strb	w0, [x23]
    c4e0:	911ea3e1 	add	x1, sp, #0x7a8
    c4e4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c4e8:	52800020 	mov	w0, #0x1                   	// #1
    c4ec:	f903d7e2 	str	x2, [sp, #1960]
    c4f0:	f903dbf5 	str	x21, [sp, #1968]
    c4f4:	97ffe357 	bl	5250 <fwp_data.part.0.constprop.0>
    c4f8:	97ffe636 	bl	5dd0 <fwp_rc_fresh>
    c4fc:	aa0003e2 	mov	x2, x0
    c500:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c504:	911ee3e1 	add	x1, sp, #0x7b8
    c508:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c50c:	52800020 	mov	w0, #0x1                   	// #1
    c510:	f903dfe3 	str	x3, [sp, #1976]
    c514:	f903e3e2 	str	x2, [sp, #1984]
    c518:	97ffe34e 	bl	5250 <fwp_data.part.0.constprop.0>
    c51c:	91188283 	add	x3, x20, #0x620
    c520:	aa0003f5 	mov	x21, x0
    c524:	f949d861 	ldr	x1, [x3, #5040]
    c528:	f949ec60 	ldr	x0, [x3, #5080]
    c52c:	cb0102a1 	sub	x1, x21, x1
    c530:	eb00403f 	cmp	x1, x0, lsl #16
    c534:	54000322 	b.cs	c598 <f0+0x2044>  // b.hs, b.nlast
    c538:	d350fc22 	lsr	x2, x1, #16
    c53c:	f949fc63 	ldr	x3, [x3, #5112]
    c540:	8b020842 	add	x2, x2, x2, lsl #2
    c544:	d37df042 	lsl	x2, x2, #3
    c548:	8b020060 	add	x0, x3, x2
    c54c:	f9401017 	ldr	x23, [x0, #32]
    c550:	b4000257 	cbz	x23, c598 <f0+0x2044>
    c554:	38626862 	ldrb	w2, [x3, x2]
    c558:	7100085f 	cmp	w2, #0x2
    c55c:	54001d60 	b.eq	c908 <f0+0x23b4>  // b.none
    c560:	7100045f 	cmp	w2, #0x1
    c564:	540001a1 	b.ne	c598 <f0+0x2044>  // b.any
    c568:	29430002 	ldp	w2, w0, [x0, #24]
    c56c:	92403c21 	and	x1, x1, #0xffff
    c570:	9b027c21 	mul	x1, x1, x2
    c574:	d360fc21 	lsr	x1, x1, #32
    c578:	eb00003f 	cmp	x1, x0
    c57c:	540000e2 	b.cs	c598 <f0+0x2044>  // b.hs, b.nlast
    c580:	8b0102f7 	add	x23, x23, x1
    c584:	394002e0 	ldrb	w0, [x23]
    c588:	7103fc1f 	cmp	w0, #0xff
    c58c:	54003140 	b.eq	cbb4 <f0+0x2660>  // b.none
    c590:	52800020 	mov	w0, #0x1                   	// #1
    c594:	390002e0 	strb	w0, [x23]
    c598:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c59c:	911f23e1 	add	x1, sp, #0x7c8
    c5a0:	52800020 	mov	w0, #0x1                   	// #1
    c5a4:	f903e7e2 	str	x2, [sp, #1992]
    c5a8:	f903ebf5 	str	x21, [sp, #2000]
    c5ac:	97ffe329 	bl	5250 <fwp_data.part.0.constprop.0>
    c5b0:	91188283 	add	x3, x20, #0x620
    c5b4:	aa0003f5 	mov	x21, x0
    c5b8:	f949d861 	ldr	x1, [x3, #5040]
    c5bc:	f949ec60 	ldr	x0, [x3, #5080]
    c5c0:	cb0102a1 	sub	x1, x21, x1
    c5c4:	eb00403f 	cmp	x1, x0, lsl #16
    c5c8:	54000322 	b.cs	c62c <f0+0x20d8>  // b.hs, b.nlast
    c5cc:	d350fc22 	lsr	x2, x1, #16
    c5d0:	f949fc63 	ldr	x3, [x3, #5112]
    c5d4:	8b020842 	add	x2, x2, x2, lsl #2
    c5d8:	d37df042 	lsl	x2, x2, #3
    c5dc:	8b020060 	add	x0, x3, x2
    c5e0:	f9401017 	ldr	x23, [x0, #32]
    c5e4:	b4000257 	cbz	x23, c62c <f0+0x20d8>
    c5e8:	38626862 	ldrb	w2, [x3, x2]
    c5ec:	7100085f 	cmp	w2, #0x2
    c5f0:	540019e0 	b.eq	c92c <f0+0x23d8>  // b.none
    c5f4:	7100045f 	cmp	w2, #0x1
    c5f8:	540001a1 	b.ne	c62c <f0+0x20d8>  // b.any
    c5fc:	29430002 	ldp	w2, w0, [x0, #24]
    c600:	92403c21 	and	x1, x1, #0xffff
    c604:	9b027c21 	mul	x1, x1, x2
    c608:	d360fc21 	lsr	x1, x1, #32
    c60c:	eb00003f 	cmp	x1, x0
    c610:	540000e2 	b.cs	c62c <f0+0x20d8>  // b.hs, b.nlast
    c614:	8b0102f7 	add	x23, x23, x1
    c618:	394002e0 	ldrb	w0, [x23]
    c61c:	7103fc1f 	cmp	w0, #0xff
    c620:	54002d00 	b.eq	cbc0 <f0+0x266c>  // b.none
    c624:	52800020 	mov	w0, #0x1                   	// #1
    c628:	390002e0 	strb	w0, [x23]
    c62c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c630:	91188294 	add	x20, x20, #0x620
    c634:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c638:	911f63e1 	add	x1, sp, #0x7d8
    c63c:	52800020 	mov	w0, #0x1                   	// #1
    c640:	f903efe2 	str	x2, [sp, #2008]
    c644:	f903f3f5 	str	x21, [sp, #2016]
    c648:	97ffe302 	bl	5250 <fwp_data.part.0.constprop.0>
    c64c:	f949da81 	ldr	x1, [x20, #5040]
    c650:	aa0003f7 	mov	x23, x0
    c654:	f949ee80 	ldr	x0, [x20, #5080]
    c658:	cb0102e1 	sub	x1, x23, x1
    c65c:	eb00403f 	cmp	x1, x0, lsl #16
    c660:	54000322 	b.cs	c6c4 <f0+0x2170>  // b.hs, b.nlast
    c664:	d350fc22 	lsr	x2, x1, #16
    c668:	f949fe83 	ldr	x3, [x20, #5112]
    c66c:	8b020842 	add	x2, x2, x2, lsl #2
    c670:	d37df042 	lsl	x2, x2, #3
    c674:	8b020060 	add	x0, x3, x2
    c678:	f9401014 	ldr	x20, [x0, #32]
    c67c:	b4000254 	cbz	x20, c6c4 <f0+0x2170>
    c680:	38626862 	ldrb	w2, [x3, x2]
    c684:	7100085f 	cmp	w2, #0x2
    c688:	540014c0 	b.eq	c920 <f0+0x23cc>  // b.none
    c68c:	7100045f 	cmp	w2, #0x1
    c690:	540001a1 	b.ne	c6c4 <f0+0x2170>  // b.any
    c694:	29430002 	ldp	w2, w0, [x0, #24]
    c698:	92403c21 	and	x1, x1, #0xffff
    c69c:	9b027c21 	mul	x1, x1, x2
    c6a0:	d360fc21 	lsr	x1, x1, #32
    c6a4:	eb00003f 	cmp	x1, x0
    c6a8:	540000e2 	b.cs	c6c4 <f0+0x2170>  // b.hs, b.nlast
    c6ac:	8b010294 	add	x20, x20, x1
    c6b0:	39400280 	ldrb	w0, [x20]
    c6b4:	7103fc1f 	cmp	w0, #0xff
    c6b8:	54001a00 	b.eq	c9f8 <f0+0x24a4>  // b.none
    c6bc:	52800020 	mov	w0, #0x1                   	// #1
    c6c0:	39000280 	strb	w0, [x20]
    c6c4:	911fa3e1 	add	x1, sp, #0x7e8
    c6c8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c6cc:	52800020 	mov	w0, #0x1                   	// #1
    c6d0:	f903f7f5 	str	x21, [sp, #2024]
    c6d4:	f903fbf7 	str	x23, [sp, #2032]
    c6d8:	97ffe2de 	bl	5250 <fwp_data.part.0.constprop.0>
    c6dc:	97ffe5bd 	bl	5dd0 <fwp_rc_fresh>
    c6e0:	aa0003e2 	mov	x2, x0
    c6e4:	911fe3e1 	add	x1, sp, #0x7f8
    c6e8:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c6ec:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c6f0:	52800020 	mov	w0, #0x1                   	// #1
    c6f4:	f903fff4 	str	x20, [sp, #2040]
    c6f8:	f90403e2 	str	x2, [sp, #2048]
    c6fc:	97ffe2d5 	bl	5250 <fwp_data.part.0.constprop.0>
    c700:	97ffe5b4 	bl	5dd0 <fwp_rc_fresh>
    c704:	aa0003e2 	mov	x2, x0
    c708:	912023e1 	add	x1, sp, #0x808
    c70c:	52800020 	mov	w0, #0x1                   	// #1
    c710:	f90407f5 	str	x21, [sp, #2056]
    c714:	f9040be2 	str	x2, [sp, #2064]
    c718:	97ffe2ce 	bl	5250 <fwp_data.part.0.constprop.0>
    c71c:	97ffe5ad 	bl	5dd0 <fwp_rc_fresh>
    c720:	aa0003e2 	mov	x2, x0
    c724:	912063e1 	add	x1, sp, #0x818
    c728:	52800020 	mov	w0, #0x1                   	// #1
    c72c:	f9040ff4 	str	x20, [sp, #2072]
    c730:	f90413e2 	str	x2, [sp, #2080]
    c734:	97ffe2c7 	bl	5250 <fwp_data.part.0.constprop.0>
    c738:	97ffe5a6 	bl	5dd0 <fwp_rc_fresh>
    c73c:	aa0003e2 	mov	x2, x0
    c740:	9120a3e1 	add	x1, sp, #0x828
    c744:	52800020 	mov	w0, #0x1                   	// #1
    c748:	f90417f5 	str	x21, [sp, #2088]
    c74c:	f9041be2 	str	x2, [sp, #2096]
    c750:	97ffe2c0 	bl	5250 <fwp_data.part.0.constprop.0>
    c754:	97ffe59f 	bl	5dd0 <fwp_rc_fresh>
    c758:	aa0003e2 	mov	x2, x0
    c75c:	9120e3e1 	add	x1, sp, #0x838
    c760:	52800020 	mov	w0, #0x1                   	// #1
    c764:	f9041ff4 	str	x20, [sp, #2104]
    c768:	f90423e2 	str	x2, [sp, #2112]
    c76c:	97ffe2b9 	bl	5250 <fwp_data.part.0.constprop.0>
    c770:	97ffe598 	bl	5dd0 <fwp_rc_fresh>
    c774:	aa0003e2 	mov	x2, x0
    c778:	912123e1 	add	x1, sp, #0x848
    c77c:	52800020 	mov	w0, #0x1                   	// #1
    c780:	f90427f5 	str	x21, [sp, #2120]
    c784:	f9042be2 	str	x2, [sp, #2128]
    c788:	97ffe2b2 	bl	5250 <fwp_data.part.0.constprop.0>
    c78c:	97ffe591 	bl	5dd0 <fwp_rc_fresh>
    c790:	aa0003e2 	mov	x2, x0
    c794:	aa1603e1 	mov	x1, x22
    c798:	52800020 	mov	w0, #0x1                   	// #1
    c79c:	f9042ff4 	str	x20, [sp, #2136]
    c7a0:	f90433e2 	str	x2, [sp, #2144]
    c7a4:	97ffe2ab 	bl	5250 <fwp_data.part.0.constprop.0>
    c7a8:	97ffe58a 	bl	5dd0 <fwp_rc_fresh>
    c7ac:	aa0003f5 	mov	x21, x0
    c7b0:	aa1303e1 	mov	x1, x19
    c7b4:	97fff087 	bl	89d0 <fwp_hof0.constprop.0>
    c7b8:	aa0003f4 	mov	x20, x0
    c7bc:	aa1503e0 	mov	x0, x21
    c7c0:	97ffe690 	bl	6200 <fwp_drop0>
    c7c4:	aa1303e0 	mov	x0, x19
    c7c8:	97ffe68e 	bl	6200 <fwp_drop0>
    c7cc:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    c7d0:	f947f400 	ldr	x0, [x0, #4072]
    c7d4:	f94437e2 	ldr	x2, [sp, #2152]
    c7d8:	f9400001 	ldr	x1, [x0]
    c7dc:	eb010042 	subs	x2, x2, x1
    c7e0:	d2800001 	mov	x1, #0x0                   	// #0
    c7e4:	54001f41 	b.ne	cbcc <f0+0x2678>  // b.any
    c7e8:	9121c3ff 	add	sp, sp, #0x870
    c7ec:	aa1403e0 	mov	x0, x20
    c7f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    c7f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c7f8:	a94363f7 	ldp	x23, x24, [sp, #48]
    c7fc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c800:	a94573fb 	ldp	x27, x28, [sp, #80]
    c804:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c808:	d65f03c0 	ret
    c80c:	aa1c03e0 	mov	x0, x28
    c810:	97ffded5 	bl	4364 <fwp_rc_forget_slot.part.0>
    c814:	17fff799 	b	a678 <f0+0x124>
    c818:	72003c5f 	tst	w2, #0xffff
    c81c:	54fef301 	b.ne	a67c <f0+0x128>  // b.any
    c820:	17fff793 	b	a66c <f0+0x118>
    c824:	72003c3f 	tst	w1, #0xffff
    c828:	54fef8c1 	b.ne	a740 <f0+0x1ec>  // b.any
    c82c:	17fff7c0 	b	a72c <f0+0x1d8>
    c830:	72003c3f 	tst	w1, #0xffff
    c834:	54ff0261 	b.ne	a880 <f0+0x32c>  // b.any
    c838:	17fff80d 	b	a86c <f0+0x318>
    c83c:	72003c3f 	tst	w1, #0xffff
    c840:	54fefc81 	b.ne	a7d0 <f0+0x27c>  // b.any
    c844:	17fff7de 	b	a7bc <f0+0x268>
    c848:	72003c3f 	tst	w1, #0xffff
    c84c:	54ff1361 	b.ne	aab8 <f0+0x564>  // b.any
    c850:	17fff895 	b	aaa4 <f0+0x550>
    c854:	72003c3f 	tst	w1, #0xffff
    c858:	54ff0a81 	b.ne	a9a8 <f0+0x454>  // b.any
    c85c:	17fff84e 	b	a994 <f0+0x440>
    c860:	72003c3f 	tst	w1, #0xffff
    c864:	54ff1da1 	b.ne	ac18 <f0+0x6c4>  // b.any
    c868:	17fff8e7 	b	ac04 <f0+0x6b0>
    c86c:	72003c3f 	tst	w1, #0xffff
    c870:	54ff17c1 	b.ne	ab68 <f0+0x614>  // b.any
    c874:	17fff8b8 	b	ab54 <f0+0x600>
    c878:	72003c3f 	tst	w1, #0xffff
    c87c:	54ff9621 	b.ne	bb40 <f0+0x15ec>  // b.any
    c880:	17fffcab 	b	bb2c <f0+0x15d8>
    c884:	72003c3f 	tst	w1, #0xffff
    c888:	54ff8d61 	b.ne	ba34 <f0+0x14e0>  // b.any
    c88c:	17fffc65 	b	ba20 <f0+0x14cc>
    c890:	72003c3f 	tst	w1, #0xffff
    c894:	54ffa7c1 	b.ne	bd8c <f0+0x1838>  // b.any
    c898:	17fffd38 	b	bd78 <f0+0x1824>
    c89c:	72003c3f 	tst	w1, #0xffff
    c8a0:	54ffa2a1 	b.ne	bcf4 <f0+0x17a0>  // b.any
    c8a4:	17fffd0f 	b	bce0 <f0+0x178c>
    c8a8:	72003c3f 	tst	w1, #0xffff
    c8ac:	54ffb521 	b.ne	bf50 <f0+0x19fc>  // b.any
    c8b0:	17fffda3 	b	bf3c <f0+0x19e8>
    c8b4:	72003c3f 	tst	w1, #0xffff
    c8b8:	54ffae21 	b.ne	be7c <f0+0x1928>  // b.any
    c8bc:	17fffd6b 	b	be68 <f0+0x1914>
    c8c0:	72003c3f 	tst	w1, #0xffff
    c8c4:	54ffc0a1 	b.ne	c0d8 <f0+0x1b84>  // b.any
    c8c8:	17fffdff 	b	c0c4 <f0+0x1b70>
    c8cc:	72003c3f 	tst	w1, #0xffff
    c8d0:	54ffb8c1 	b.ne	bfe8 <f0+0x1a94>  // b.any
    c8d4:	17fffdc0 	b	bfd4 <f0+0x1a80>
    c8d8:	72003c3f 	tst	w1, #0xffff
    c8dc:	54ffcd21 	b.ne	c280 <f0+0x1d2c>  // b.any
    c8e0:	17fffe63 	b	c26c <f0+0x1d18>
    c8e4:	72003c3f 	tst	w1, #0xffff
    c8e8:	54ffc621 	b.ne	c1ac <f0+0x1c58>  // b.any
    c8ec:	17fffe2b 	b	c198 <f0+0x1c44>
    c8f0:	72003c3f 	tst	w1, #0xffff
    c8f4:	54ffd9a1 	b.ne	c428 <f0+0x1ed4>  // b.any
    c8f8:	17fffec7 	b	c414 <f0+0x1ec0>
    c8fc:	72003c3f 	tst	w1, #0xffff
    c900:	54ffd1c1 	b.ne	c338 <f0+0x1de4>  // b.any
    c904:	17fffe88 	b	c324 <f0+0x1dd0>
    c908:	72003c3f 	tst	w1, #0xffff
    c90c:	54ffe461 	b.ne	c598 <f0+0x2044>  // b.any
    c910:	17ffff1d 	b	c584 <f0+0x2030>
    c914:	72003c3f 	tst	w1, #0xffff
    c918:	54ffde41 	b.ne	c4e0 <f0+0x1f8c>  // b.any
    c91c:	17fffeec 	b	c4cc <f0+0x1f78>
    c920:	72003c3f 	tst	w1, #0xffff
    c924:	54ffed01 	b.ne	c6c4 <f0+0x2170>  // b.any
    c928:	17ffff62 	b	c6b0 <f0+0x215c>
    c92c:	72003c3f 	tst	w1, #0xffff
    c930:	54ffe7e1 	b.ne	c62c <f0+0x20d8>  // b.any
    c934:	17ffff39 	b	c618 <f0+0x20c4>
    c938:	72003c3f 	tst	w1, #0xffff
    c93c:	54ff21e1 	b.ne	ad78 <f0+0x824>  // b.any
    c940:	17fff909 	b	ad64 <f0+0x810>
    c944:	72003c3f 	tst	w1, #0xffff
    c948:	54ff1c01 	b.ne	acc8 <f0+0x774>  // b.any
    c94c:	17fff8da 	b	acb4 <f0+0x760>
    c950:	72003c3f 	tst	w1, #0xffff
    c954:	54ff2c21 	b.ne	aed8 <f0+0x984>  // b.any
    c958:	17fff95b 	b	aec4 <f0+0x970>
    c95c:	72003c3f 	tst	w1, #0xffff
    c960:	54ff2541 	b.ne	ae08 <f0+0x8b4>  // b.any
    c964:	17fff924 	b	adf4 <f0+0x8a0>
    c968:	72003c3f 	tst	w1, #0xffff
    c96c:	54ff37c1 	b.ne	b064 <f0+0xb10>  // b.any
    c970:	17fff9b8 	b	b050 <f0+0xafc>
    c974:	72003c3f 	tst	w1, #0xffff
    c978:	54ff30c1 	b.ne	af90 <f0+0xa3c>  // b.any
    c97c:	17fff980 	b	af7c <f0+0xa28>
    c980:	72003c3f 	tst	w1, #0xffff
    c984:	54ff4341 	b.ne	b1ec <f0+0xc98>  // b.any
    c988:	17fffa14 	b	b1d8 <f0+0xc84>
    c98c:	72003c3f 	tst	w1, #0xffff
    c990:	54ff3e21 	b.ne	b154 <f0+0xc00>  // b.any
    c994:	17fff9eb 	b	b140 <f0+0xbec>
    c998:	72003c3f 	tst	w1, #0xffff
    c99c:	54ff4be1 	b.ne	b318 <f0+0xdc4>  // b.any
    c9a0:	17fffa59 	b	b304 <f0+0xdb0>
    c9a4:	72003c3f 	tst	w1, #0xffff
    c9a8:	54ff46c1 	b.ne	b280 <f0+0xd2c>  // b.any
    c9ac:	17fffa30 	b	b26c <f0+0xd18>
    c9b0:	72003c3f 	tst	w1, #0xffff
    c9b4:	54ff5861 	b.ne	b4c0 <f0+0xf6c>  // b.any
    c9b8:	17fffabd 	b	b4ac <f0+0xf58>
    c9bc:	72003c3f 	tst	w1, #0xffff
    c9c0:	54ff5081 	b.ne	b3d0 <f0+0xe7c>  // b.any
    c9c4:	17fffa7e 	b	b3bc <f0+0xe68>
    c9c8:	72003c3f 	tst	w1, #0xffff
    c9cc:	54ff6cc1 	b.ne	b764 <f0+0x1210>  // b.any
    c9d0:	17fffb60 	b	b750 <f0+0x11fc>
    c9d4:	72003c3f 	tst	w1, #0xffff
    c9d8:	54ff65c1 	b.ne	b690 <f0+0x113c>  // b.any
    c9dc:	17fffb28 	b	b67c <f0+0x1128>
    c9e0:	72003c3f 	tst	w1, #0xffff
    c9e4:	54ff7be1 	b.ne	b960 <f0+0x140c>  // b.any
    c9e8:	17fffbd9 	b	b94c <f0+0x13f8>
    c9ec:	72003c3f 	tst	w1, #0xffff
    c9f0:	54ff7401 	b.ne	b870 <f0+0x131c>  // b.any
    c9f4:	17fffb9a 	b	b85c <f0+0x1308>
    c9f8:	aa1403e0 	mov	x0, x20
    c9fc:	97ffde5a 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca00:	17ffff2f 	b	c6bc <f0+0x2168>
    ca04:	aa1703e0 	mov	x0, x23
    ca08:	97ffde57 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca0c:	17fff74b 	b	a738 <f0+0x1e4>
    ca10:	aa1703e0 	mov	x0, x23
    ca14:	97ffde54 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca18:	17fff76c 	b	a7c8 <f0+0x274>
    ca1c:	aa1503e0 	mov	x0, x21
    ca20:	97ffde51 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca24:	17fff795 	b	a878 <f0+0x324>
    ca28:	aa1703e0 	mov	x0, x23
    ca2c:	97ffde4e 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca30:	17fff7dc 	b	a9a0 <f0+0x44c>
    ca34:	aa1703e0 	mov	x0, x23
    ca38:	97ffde4b 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca3c:	17fff81d 	b	aab0 <f0+0x55c>
    ca40:	aa1703e0 	mov	x0, x23
    ca44:	97ffde48 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca48:	17fff846 	b	ab60 <f0+0x60c>
    ca4c:	aa1703e0 	mov	x0, x23
    ca50:	97ffde45 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca54:	17fff86f 	b	ac10 <f0+0x6bc>
    ca58:	aa1703e0 	mov	x0, x23
    ca5c:	97ffde42 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca60:	17fff898 	b	acc0 <f0+0x76c>
    ca64:	aa1703e0 	mov	x0, x23
    ca68:	97ffde3f 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca6c:	17fff8c1 	b	ad70 <f0+0x81c>
    ca70:	aa1703e0 	mov	x0, x23
    ca74:	97ffde3c 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca78:	17fff8e2 	b	ae00 <f0+0x8ac>
    ca7c:	aa1703e0 	mov	x0, x23
    ca80:	97ffde39 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca84:	17fff913 	b	aed0 <f0+0x97c>
    ca88:	aa1703e0 	mov	x0, x23
    ca8c:	97ffde36 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca90:	17fff93e 	b	af88 <f0+0xa34>
    ca94:	aa1703e0 	mov	x0, x23
    ca98:	97ffde33 	bl	4364 <fwp_rc_forget_slot.part.0>
    ca9c:	17fff970 	b	b05c <f0+0xb08>
    caa0:	aa1703e0 	mov	x0, x23
    caa4:	97ffde30 	bl	4364 <fwp_rc_forget_slot.part.0>
    caa8:	17fff9a9 	b	b14c <f0+0xbf8>
    caac:	aa1703e0 	mov	x0, x23
    cab0:	97ffde2d 	bl	4364 <fwp_rc_forget_slot.part.0>
    cab4:	17fff9cc 	b	b1e4 <f0+0xc90>
    cab8:	aa1703e0 	mov	x0, x23
    cabc:	97ffde2a 	bl	4364 <fwp_rc_forget_slot.part.0>
    cac0:	17fff9ee 	b	b278 <f0+0xd24>
    cac4:	aa1703e0 	mov	x0, x23
    cac8:	97ffde27 	bl	4364 <fwp_rc_forget_slot.part.0>
    cacc:	17fffa11 	b	b310 <f0+0xdbc>
    cad0:	aa1703e0 	mov	x0, x23
    cad4:	97ffde24 	bl	4364 <fwp_rc_forget_slot.part.0>
    cad8:	17fffa3c 	b	b3c8 <f0+0xe74>
    cadc:	aa1703e0 	mov	x0, x23
    cae0:	97ffde21 	bl	4364 <fwp_rc_forget_slot.part.0>
    cae4:	17fffa75 	b	b4b8 <f0+0xf64>
    cae8:	aa1703e0 	mov	x0, x23
    caec:	97ffde1e 	bl	4364 <fwp_rc_forget_slot.part.0>
    caf0:	17fffae6 	b	b688 <f0+0x1134>
    caf4:	aa1703e0 	mov	x0, x23
    caf8:	97ffde1b 	bl	4364 <fwp_rc_forget_slot.part.0>
    cafc:	17fffb18 	b	b75c <f0+0x1208>
    cb00:	aa1703e0 	mov	x0, x23
    cb04:	97ffde18 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb08:	17fffb58 	b	b868 <f0+0x1314>
    cb0c:	aa1703e0 	mov	x0, x23
    cb10:	97ffde15 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb14:	17fffb91 	b	b958 <f0+0x1404>
    cb18:	aa1703e0 	mov	x0, x23
    cb1c:	97ffde12 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb20:	17fffbc3 	b	ba2c <f0+0x14d8>
    cb24:	aa1503e0 	mov	x0, x21
    cb28:	97ffde0f 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb2c:	17fffc03 	b	bb38 <f0+0x15e4>
    cb30:	aa1703e0 	mov	x0, x23
    cb34:	97ffde0c 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb38:	17fffc6d 	b	bcec <f0+0x1798>
    cb3c:	aa1703e0 	mov	x0, x23
    cb40:	97ffde09 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb44:	17fffc90 	b	bd84 <f0+0x1830>
    cb48:	aa1703e0 	mov	x0, x23
    cb4c:	97ffde06 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb50:	17fffcc9 	b	be74 <f0+0x1920>
    cb54:	aa1703e0 	mov	x0, x23
    cb58:	97ffde03 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb5c:	17fffcfb 	b	bf48 <f0+0x19f4>
    cb60:	aa1703e0 	mov	x0, x23
    cb64:	97ffde00 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb68:	17fffd1e 	b	bfe0 <f0+0x1a8c>
    cb6c:	aa1703e0 	mov	x0, x23
    cb70:	97ffddfd 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb74:	17fffd57 	b	c0d0 <f0+0x1b7c>
    cb78:	aa1703e0 	mov	x0, x23
    cb7c:	97ffddfa 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb80:	17fffd89 	b	c1a4 <f0+0x1c50>
    cb84:	aa1703e0 	mov	x0, x23
    cb88:	97ffddf7 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb8c:	17fffdbb 	b	c278 <f0+0x1d24>
    cb90:	aa1703e0 	mov	x0, x23
    cb94:	97ffddf4 	bl	4364 <fwp_rc_forget_slot.part.0>
    cb98:	17fffde6 	b	c330 <f0+0x1ddc>
    cb9c:	aa1703e0 	mov	x0, x23
    cba0:	97ffddf1 	bl	4364 <fwp_rc_forget_slot.part.0>
    cba4:	17fffe1f 	b	c420 <f0+0x1ecc>
    cba8:	aa1703e0 	mov	x0, x23
    cbac:	97ffddee 	bl	4364 <fwp_rc_forget_slot.part.0>
    cbb0:	17fffe4a 	b	c4d8 <f0+0x1f84>
    cbb4:	aa1703e0 	mov	x0, x23
    cbb8:	97ffddeb 	bl	4364 <fwp_rc_forget_slot.part.0>
    cbbc:	17fffe75 	b	c590 <f0+0x203c>
    cbc0:	aa1703e0 	mov	x0, x23
    cbc4:	97ffdde8 	bl	4364 <fwp_rc_forget_slot.part.0>
    cbc8:	17fffe97 	b	c624 <f0+0x20d0>
    cbcc:	97ffd725 	bl	2860 <__stack_chk_fail@plt>
    cbd0:	97ffd738 	bl	28b0 <abort@plt>

000000000000cbd4 <fwp_main_thread>:
    cbd4:	d10443ff 	sub	sp, sp, #0x110
    cbd8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    cbdc:	f947f400 	ldr	x0, [x0, #4072]
    cbe0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    cbe4:	910303fd 	add	x29, sp, #0xc0
    cbe8:	a90d53f3 	stp	x19, x20, [sp, #208]
    cbec:	b0000374 	adrp	x20, 79000 <fwp_root_context+0xbc0>
    cbf0:	91188281 	add	x1, x20, #0x620
    cbf4:	a90e5bf5 	stp	x21, x22, [sp, #224]
    cbf8:	a90f63f7 	stp	x23, x24, [sp, #240]
    cbfc:	b953a421 	ldr	w1, [x1, #5028]
    cc00:	a9106bf9 	stp	x25, x26, [sp, #256]
    cc04:	f9400002 	ldr	x2, [x0]
    cc08:	f9005fe2 	str	x2, [sp, #184]
    cc0c:	d2800002 	mov	x2, #0x0                   	// #0
    cc10:	34000f01 	cbz	w1, cdf0 <fwp_main_thread+0x21c>
    cc14:	91188280 	add	x0, x20, #0x620
    cc18:	b953a800 	ldr	w0, [x0, #5032]
    cc1c:	35000e20 	cbnz	w0, cde0 <fwp_main_thread+0x20c>
    cc20:	91001fe2 	add	x2, sp, #0x7
    cc24:	900000b5 	adrp	x21, 20000 <__data_start>
    cc28:	900000a3 	adrp	x3, 20000 <__data_start>
    cc2c:	910142b3 	add	x19, x21, #0x50
    cc30:	91110063 	add	x3, x3, #0x440
    cc34:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    cc38:	d2a00025 	mov	x5, #0x10000               	// #65536
    cc3c:	910023e0 	add	x0, sp, #0x8
    cc40:	d2800001 	mov	x1, #0x0                   	// #0
    cc44:	f90007e3 	str	x3, [sp, #8]
    cc48:	b90013ff 	str	wzr, [sp, #16]
    cc4c:	f9000fe5 	str	x5, [sp, #24]
    cc50:	a90a1262 	stp	x2, x4, [x19, #160]
    cc54:	97ffd69f 	bl	26d0 <sigaltstack@plt>
    cc58:	35000220 	cbnz	w0, cc9c <fwp_main_thread+0xc8>
    cc5c:	4f000400 	movi	v0.4s, #0x0
    cc60:	9100a3e0 	add	x0, sp, #0x28
    cc64:	f0ffffa1 	adrp	x1, 3000 <fwp_tape_unlink_scope+0x2c>
    cc68:	52800082 	mov	w2, #0x4                   	// #4
    cc6c:	9101c021 	add	x1, x1, #0x70
    cc70:	72a10002 	movk	w2, #0x800, lsl #16
    cc74:	910083f6 	add	x22, sp, #0x20
    cc78:	f90013e1 	str	x1, [sp, #32]
    cc7c:	3d802000 	str	q0, [x0, #128]
    cc80:	b900abe2 	str	w2, [sp, #168]
    cc84:	ad000000 	stp	q0, q0, [x0]
    cc88:	ad010000 	stp	q0, q0, [x0, #32]
    cc8c:	ad020000 	stp	q0, q0, [x0, #64]
    cc90:	ad030000 	stp	q0, q0, [x0, #96]
    cc94:	97ffd6e3 	bl	2820 <sigemptyset@plt>
    cc98:	34000080 	cbz	w0, cca8 <fwp_main_thread+0xd4>
    cc9c:	d0000000 	adrp	x0, e000 <_IO_stdin_used+0x780>
    cca0:	9101c000 	add	x0, x0, #0x70
    cca4:	97ffdd90 	bl	42e4 <fwp_trap>
    cca8:	aa1603e1 	mov	x1, x22
    ccac:	d2800002 	mov	x2, #0x0                   	// #0
    ccb0:	52800160 	mov	w0, #0xb                   	// #11
    ccb4:	97ffd6f3 	bl	2880 <sigaction@plt>
    ccb8:	35ffff20 	cbnz	w0, cc9c <fwp_main_thread+0xc8>
    ccbc:	aa1603e1 	mov	x1, x22
    ccc0:	d2800002 	mov	x2, #0x0                   	// #0
    ccc4:	528000e0 	mov	w0, #0x7                   	// #7
    ccc8:	97ffd6ee 	bl	2880 <sigaction@plt>
    cccc:	35fffe80 	cbnz	w0, cc9c <fwp_main_thread+0xc8>
    ccd0:	91188281 	add	x1, x20, #0x620
    ccd4:	52800036 	mov	w22, #0x1                   	// #1
    ccd8:	f0ffffa0 	adrp	x0, 3000 <fwp_tape_unlink_scope+0x2c>
    ccdc:	910dc000 	add	x0, x0, #0x370
    cce0:	b9012276 	str	w22, [x19, #288]
    cce4:	fd4a1020 	ldr	d0, [x1, #5152]
    cce8:	7e61d800 	ucvtf	d0, d0
    ccec:	fd009e60 	str	d0, [x19, #312]
    ccf0:	940002d8 	bl	d850 <atexit>
    ccf4:	350022c0 	cbnz	w0, d14c <fwp_main_thread+0x578>
    ccf8:	b943ba60 	ldr	w0, [x19, #952]
    ccfc:	34001c60 	cbz	w0, d088 <fwp_main_thread+0x4b4>
    cd00:	910142ba 	add	x26, x21, #0x50
    cd04:	f9404f56 	ldr	x22, [x26, #152]
    cd08:	b40007b6 	cbz	x22, cdfc <fwp_main_thread+0x228>
    cd0c:	910102d7 	add	x23, x22, #0x40
    cd10:	39414ad9 	ldrb	w25, [x22, #82]
    cd14:	52800038 	mov	w24, #0x1                   	// #1
    cd18:	39014ad8 	strb	w24, [x22, #82]
    cd1c:	d503201f 	nop
    cd20:	f94016c0 	ldr	x0, [x22, #40]
    cd24:	b40006a0 	cbz	x0, cdf8 <fwp_main_thread+0x224>
    cd28:	f94032c1 	ldr	x1, [x22, #96]
    cd2c:	394146c0 	ldrb	w0, [x22, #81]
    cd30:	b4001c61 	cbz	x1, d0bc <fwp_main_thread+0x4e8>
    cd34:	36001b20 	tbz	w0, #0, d098 <fwp_main_thread+0x4c4>
    cd38:	f9404f53 	ldr	x19, [x26, #152]
    cd3c:	f94022c0 	ldr	x0, [x22, #64]
    cd40:	39414a61 	ldrb	w1, [x19, #82]
    cd44:	37001e81 	tbnz	w1, #0, d114 <fwp_main_thread+0x540>
    cd48:	f9403261 	ldr	x1, [x19, #96]
    cd4c:	a911fe77 	stp	x23, xzr, [x19, #280]
    cd50:	f9009660 	str	x0, [x19, #296]
    cd54:	b4000040 	cbz	x0, cd5c <fwp_main_thread+0x188>
    cd58:	f9009013 	str	x19, [x0, #288]
    cd5c:	f90022d3 	str	x19, [x22, #64]
    cd60:	b4000101 	cbz	x1, cd80 <fwp_main_thread+0x1ac>
    cd64:	f9408f40 	ldr	x0, [x26, #280]
    cd68:	39015678 	strb	w24, [x19, #85]
    cd6c:	f9003661 	str	x1, [x19, #104]
    cd70:	a910827f 	stp	xzr, x0, [x19, #264]
    cd74:	b4000040 	cbz	x0, cd7c <fwp_main_thread+0x1a8>
    cd78:	f9008413 	str	x19, [x0, #264]
    cd7c:	f9008f53 	str	x19, [x26, #280]
    cd80:	39015a7f 	strb	wzr, [x19, #86]
    cd84:	97ffe877 	bl	6f60 <fwp_block>
    cd88:	f9408e62 	ldr	x2, [x19, #280]
    cd8c:	b4000142 	cbz	x2, cdb4 <fwp_main_thread+0x1e0>
    cd90:	a9520261 	ldp	x1, x0, [x19, #288]
    cd94:	b4001cc1 	cbz	x1, d12c <fwp_main_thread+0x558>
    cd98:	f9009420 	str	x0, [x1, #296]
    cd9c:	f9409660 	ldr	x0, [x19, #296]
    cda0:	b4000040 	cbz	x0, cda8 <fwp_main_thread+0x1d4>
    cda4:	f9009001 	str	x1, [x0, #288]
    cda8:	91080260 	add	x0, x19, #0x200
    cdac:	f900967f 	str	xzr, [x19, #296]
    cdb0:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    cdb4:	39415660 	ldrb	w0, [x19, #85]
    cdb8:	3607fb40 	tbz	w0, #0, cd20 <fwp_main_thread+0x14c>
    cdbc:	a9508261 	ldp	x1, x0, [x19, #264]
    cdc0:	b4001ba1 	cbz	x1, d134 <fwp_main_thread+0x560>
    cdc4:	f9008820 	str	x0, [x1, #272]
    cdc8:	b4000040 	cbz	x0, cdd0 <fwp_main_thread+0x1fc>
    cdcc:	f9008401 	str	x1, [x0, #264]
    cdd0:	91080260 	add	x0, x19, #0x200
    cdd4:	3901567f 	strb	wzr, [x19, #85]
    cdd8:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    cddc:	17ffffd1 	b	cd20 <fwp_main_thread+0x14c>
    cde0:	f0ffffa0 	adrp	x0, 3000 <fwp_tape_unlink_scope+0x2c>
    cde4:	912f1000 	add	x0, x0, #0xbc4
    cde8:	9400029a 	bl	d850 <atexit>
    cdec:	17ffff8d 	b	cc20 <fwp_main_thread+0x4c>
    cdf0:	97ffdbd0 	bl	3d30 <fwp_heap_init>
    cdf4:	17ffff88 	b	cc14 <fwp_main_thread+0x40>
    cdf8:	39014ad9 	strb	w25, [x22, #82]
    cdfc:	910142b3 	add	x19, x21, #0x50
    ce00:	f941ce60 	ldr	x0, [x19, #920]
    ce04:	b5000180 	cbnz	x0, ce34 <fwp_main_thread+0x260>
    ce08:	f941d660 	ldr	x0, [x19, #936]
    ce0c:	b5000140 	cbnz	x0, ce34 <fwp_main_thread+0x260>
    ce10:	f941ca60 	ldr	x0, [x19, #912]
    ce14:	97ffddef 	bl	45d0 <fwp_mem_free>
    ce18:	f901ca7f 	str	xzr, [x19, #912]
    ce1c:	f9404e60 	ldr	x0, [x19, #152]
    ce20:	f901d27f 	str	xzr, [x19, #928]
    ce24:	b40000c0 	cbz	x0, ce3c <fwp_main_thread+0x268>
    ce28:	f900541f 	str	xzr, [x0, #168]
    ce2c:	f9005c1f 	str	xzr, [x0, #184]
    ce30:	14000003 	b	ce3c <fwp_main_thread+0x268>
    ce34:	910142a0 	add	x0, x21, #0x50
    ce38:	f9404c00 	ldr	x0, [x0, #152]
    ce3c:	910142a1 	add	x1, x21, #0x50
    ce40:	f941e826 	ldr	x6, [x1, #976]
    ce44:	b903c83f 	str	wzr, [x1, #968]
    ce48:	eb0000df 	cmp	x6, x0
    ce4c:	54001861 	b.ne	d158 <fwp_main_thread+0x584>  // b.any
    ce50:	b40003a0 	cbz	x0, cec4 <fwp_main_thread+0x2f0>
    ce54:	f941b825 	ldr	x5, [x1, #880]
    ce58:	52800021 	mov	w1, #0x1                   	// #1
    ce5c:	39014801 	strb	w1, [x0, #82]
    ce60:	b4000325 	cbz	x5, cec4 <fwp_main_thread+0x2f0>
    ce64:	d503201f 	nop
    ce68:	394140a0 	ldrb	w0, [x5, #80]
    ce6c:	37000060 	tbnz	w0, #0, ce78 <fwp_main_thread+0x2a4>
    ce70:	aa0503e0 	mov	x0, x5
    ce74:	97ffda0f 	bl	36b0 <fwp_cancel_tree.part.0>
    ce78:	f9409ca5 	ldr	x5, [x5, #312]
    ce7c:	b5ffff65 	cbnz	x5, ce68 <fwp_main_thread+0x294>
    ce80:	910142b3 	add	x19, x21, #0x50
    ce84:	52800036 	mov	w22, #0x1                   	// #1
    ce88:	f94028c0 	ldr	x0, [x6, #80]
    ce8c:	f2001c1f 	tst	x0, #0xff000000ff
    ce90:	540000e1 	b.ne	ceac <fwp_main_thread+0x2d8>  // b.any
    ce94:	f9406260 	ldr	x0, [x19, #192]
    ce98:	390150d6 	strb	w22, [x6, #84]
    ce9c:	f90080df 	str	xzr, [x6, #256]
    cea0:	b4001360 	cbz	x0, d10c <fwp_main_thread+0x538>
    cea4:	f9008006 	str	x6, [x0, #256]
    cea8:	f9006266 	str	x6, [x19, #192]
    ceac:	97ffe82d 	bl	6f60 <fwp_block>
    ceb0:	97ffe7b4 	bl	6d80 <fwp_free_zombie>
    ceb4:	f941ba60 	ldr	x0, [x19, #880]
    ceb8:	b4000060 	cbz	x0, cec4 <fwp_main_thread+0x2f0>
    cebc:	f941ea66 	ldr	x6, [x19, #976]
    cec0:	17fffff2 	b	ce88 <fwp_main_thread+0x2b4>
    cec4:	910142b6 	add	x22, x21, #0x50
    cec8:	97ffe7ae 	bl	6d80 <fwp_free_zombie>
    cecc:	f94066c0 	ldr	x0, [x22, #200]
    ced0:	b5001440 	cbnz	x0, d158 <fwp_main_thread+0x584>
    ced4:	f9408ec0 	ldr	x0, [x22, #280]
    ced8:	b5001400 	cbnz	x0, d158 <fwp_main_thread+0x584>
    cedc:	b94162d3 	ldr	w19, [x22, #352]
    cee0:	340001f3 	cbz	w19, cf1c <fwp_main_thread+0x348>
    cee4:	93407e77 	sxtw	x23, w19
    cee8:	51000673 	sub	w19, w19, #0x1
    ceec:	d1000af7 	sub	x23, x23, #0x2
    cef0:	9105c2d8 	add	x24, x22, #0x170
    cef4:	cb3342f7 	sub	x23, x23, w19, uxtw
    cef8:	93407e73 	sxtw	x19, w19
    cefc:	d503201f 	nop
    cf00:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    cf04:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cf08:	b90162d3 	str	w19, [x22, #352]
    cf0c:	d1000673 	sub	x19, x19, #0x1
    cf10:	97ffd69c 	bl	2980 <munmap@plt>
    cf14:	eb1302ff 	cmp	x23, x19
    cf18:	54ffff41 	b.ne	cf00 <fwp_main_thread+0x32c>  // b.any
    cf1c:	900000b3 	adrp	x19, 20000 <__data_start>
    cf20:	91004260 	add	x0, x19, #0x10
    cf24:	b9402800 	ldr	w0, [x0, #40]
    cf28:	36f80ac0 	tbz	w0, #31, d080 <fwp_main_thread+0x4ac>
    cf2c:	910142b6 	add	x22, x21, #0x50
    cf30:	91004273 	add	x19, x19, #0x10
    cf34:	12800001 	mov	w1, #0xffffffff            	// #-1
    cf38:	f941f2c0 	ldr	x0, [x22, #992]
    cf3c:	b9002a61 	str	w1, [x19, #40]
    cf40:	f941eec1 	ldr	x1, [x22, #984]
    cf44:	b40001e0 	cbz	x0, cf80 <fwp_main_thread+0x3ac>
    cf48:	d2800013 	mov	x19, #0x0                   	// #0
    cf4c:	d503201f 	nop
    cf50:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    cf54:	b40000e0 	cbz	x0, cf70 <fwp_main_thread+0x39c>
    cf58:	f9400001 	ldr	x1, [x0]
    cf5c:	b5000fe1 	cbnz	x1, d158 <fwp_main_thread+0x584>
    cf60:	f9400401 	ldr	x1, [x0, #8]
    cf64:	b5000fa1 	cbnz	x1, d158 <fwp_main_thread+0x584>
    cf68:	97ffdd9a 	bl	45d0 <fwp_mem_free>
    cf6c:	f941eec1 	ldr	x1, [x22, #984]
    cf70:	91000673 	add	x19, x19, #0x1
    cf74:	f941f2c0 	ldr	x0, [x22, #992]
    cf78:	eb00027f 	cmp	x19, x0
    cf7c:	54fffea3 	b.cc	cf50 <fwp_main_thread+0x37c>  // b.lo, b.ul, b.last
    cf80:	aa0103e0 	mov	x0, x1
    cf84:	97ffdd93 	bl	45d0 <fwp_mem_free>
    cf88:	910142a0 	add	x0, x21, #0x50
    cf8c:	f941e813 	ldr	x19, [x0, #976]
    cf90:	f901ec1f 	str	xzr, [x0, #984]
    cf94:	f901f01f 	str	xzr, [x0, #992]
    cf98:	b40001f3 	cbz	x19, cfd4 <fwp_main_thread+0x400>
    cf9c:	f9401661 	ldr	x1, [x19, #40]
    cfa0:	b5000dc1 	cbnz	x1, d158 <fwp_main_thread+0x584>
    cfa4:	f9405661 	ldr	x1, [x19, #168]
    cfa8:	b5000d81 	cbnz	x1, d158 <fwp_main_thread+0x584>
    cfac:	f941cc01 	ldr	x1, [x0, #920]
    cfb0:	b5000d41 	cbnz	x1, d158 <fwp_main_thread+0x584>
    cfb4:	f941d400 	ldr	x0, [x0, #936]
    cfb8:	b5000d00 	cbnz	x0, d158 <fwp_main_thread+0x584>
    cfbc:	d2823a02 	mov	x2, #0x11d0                	// #4560
    cfc0:	90000360 	adrp	x0, 78000 <ad_raw_blocks+0x17bc0>
    cfc4:	91110000 	add	x0, x0, #0x440
    cfc8:	97ffd61a 	bl	2830 <memset@plt>
    cfcc:	aa1303e0 	mov	x0, x19
    cfd0:	97ffdd80 	bl	45d0 <fwp_mem_free>
    cfd4:	910142a6 	add	x6, x21, #0x50
    cfd8:	91188294 	add	x20, x20, #0x620
    cfdc:	3dc016a1 	ldr	q1, [x21, #80]
    cfe0:	52800041 	mov	w1, #0x2                   	// #2
    cfe4:	3dc004c2 	ldr	q2, [x6, #16]
    cfe8:	d0000002 	adrp	x2, e000 <_IO_stdin_used+0x780>
    cfec:	fd4a1280 	ldr	d0, [x20, #5152]
    cff0:	9102e042 	add	x2, x2, #0xb8
    cff4:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    cff8:	fd409cc1 	ldr	d1, [x6, #312]
    cffc:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    d000:	f947e800 	ldr	x0, [x0, #4048]
    d004:	7e61d800 	ucvtf	d0, d0
    d008:	a95290c3 	ldp	x3, x4, [x6, #296]
    d00c:	f9004cdf 	str	xzr, [x6, #152]
    d010:	f9400000 	ldr	x0, [x0]
    d014:	1e613801 	fsub	d1, d0, d1
    d018:	f940a4c5 	ldr	x5, [x6, #328]
    d01c:	b90120df 	str	wzr, [x6, #288]
    d020:	5ef1b842 	addp	d2, v2.2d
    d024:	fd40a0c0 	ldr	d0, [x6, #320]
    d028:	f901e8df 	str	xzr, [x6, #976]
    d02c:	fd0058c2 	str	d2, [x6, #176]
    d030:	97ffd628 	bl	28d0 <__fprintf_chk@plt>
    d034:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    d038:	f947ec00 	ldr	x0, [x0, #4056]
    d03c:	f9400000 	ldr	x0, [x0]
    d040:	97ffd654 	bl	2990 <fflush@plt>
    d044:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    d048:	f947f400 	ldr	x0, [x0, #4072]
    d04c:	f9405fe2 	ldr	x2, [sp, #184]
    d050:	f9400001 	ldr	x1, [x0]
    d054:	eb010042 	subs	x2, x2, x1
    d058:	d2800001 	mov	x1, #0x0                   	// #0
    d05c:	54000761 	b.ne	d148 <fwp_main_thread+0x574>  // b.any
    d060:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    d064:	d2800000 	mov	x0, #0x0                   	// #0
    d068:	a94d53f3 	ldp	x19, x20, [sp, #208]
    d06c:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    d070:	a94f63f7 	ldp	x23, x24, [sp, #240]
    d074:	a9506bf9 	ldp	x25, x26, [sp, #256]
    d078:	910443ff 	add	sp, sp, #0x110
    d07c:	d65f03c0 	ret
    d080:	97ffd5fc 	bl	2870 <close@plt>
    d084:	17ffffaa 	b	cf2c <fwp_main_thread+0x358>
    d088:	97fff533 	bl	a554 <f0>
    d08c:	b903ba76 	str	w22, [x19, #952]
    d090:	f901e260 	str	x0, [x19, #960]
    d094:	17ffff1b 	b	cd00 <fwp_main_thread+0x12c>
    d098:	97ffdeb2 	bl	4b60 <fwp_now_ns>
    d09c:	f94032c1 	ldr	x1, [x22, #96]
    d0a0:	eb01001f 	cmp	x0, x1
    d0a4:	540000ab 	b.lt	d0b8 <fwp_main_thread+0x4e4>  // b.tstop
    d0a8:	394142c0 	ldrb	w0, [x22, #80]
    d0ac:	37000060 	tbnz	w0, #0, d0b8 <fwp_main_thread+0x4e4>
    d0b0:	aa1603e0 	mov	x0, x22
    d0b4:	97ffd97f 	bl	36b0 <fwp_cancel_tree.part.0>
    d0b8:	394146c0 	ldrb	w0, [x22, #81]
    d0bc:	f9404f53 	ldr	x19, [x26, #152]
    d0c0:	39414a62 	ldrb	w2, [x19, #82]
    d0c4:	3707e3a0 	tbnz	w0, #0, cd38 <fwp_main_thread+0x164>
    d0c8:	f94032c1 	ldr	x1, [x22, #96]
    d0cc:	370001c2 	tbnz	w2, #0, d104 <fwp_main_thread+0x530>
    d0d0:	f9403260 	ldr	x0, [x19, #96]
    d0d4:	b4000180 	cbz	x0, d104 <fwp_main_thread+0x530>
    d0d8:	b4000061 	cbz	x1, d0e4 <fwp_main_thread+0x510>
    d0dc:	eb01001f 	cmp	x0, x1
    d0e0:	9a81d000 	csel	x0, x0, x1, le
    d0e4:	f94022c1 	ldr	x1, [x22, #64]
    d0e8:	a911fe77 	stp	x23, xzr, [x19, #280]
    d0ec:	f9009661 	str	x1, [x19, #296]
    d0f0:	b4000261 	cbz	x1, d13c <fwp_main_thread+0x568>
    d0f4:	f9009033 	str	x19, [x1, #288]
    d0f8:	aa0003e1 	mov	x1, x0
    d0fc:	f90022d3 	str	x19, [x22, #64]
    d100:	17ffff19 	b	cd64 <fwp_main_thread+0x190>
    d104:	f94022c0 	ldr	x0, [x22, #64]
    d108:	17ffff11 	b	cd4c <fwp_main_thread+0x178>
    d10c:	f9006666 	str	x6, [x19, #200]
    d110:	17ffff66 	b	cea8 <fwp_main_thread+0x2d4>
    d114:	a911fe77 	stp	x23, xzr, [x19, #280]
    d118:	f9009660 	str	x0, [x19, #296]
    d11c:	b4000040 	cbz	x0, d124 <fwp_main_thread+0x550>
    d120:	f9009013 	str	x19, [x0, #288]
    d124:	f90022d3 	str	x19, [x22, #64]
    d128:	17ffff16 	b	cd80 <fwp_main_thread+0x1ac>
    d12c:	f9000040 	str	x0, [x2]
    d130:	17ffff1c 	b	cda0 <fwp_main_thread+0x1cc>
    d134:	f9008f40 	str	x0, [x26, #280]
    d138:	17ffff24 	b	cdc8 <fwp_main_thread+0x1f4>
    d13c:	aa0003e1 	mov	x1, x0
    d140:	f90022d3 	str	x19, [x22, #64]
    d144:	17ffff08 	b	cd64 <fwp_main_thread+0x190>
    d148:	97ffd5c6 	bl	2860 <__stack_chk_fail@plt>
    d14c:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x780>
    d150:	91026000 	add	x0, x0, #0x98
    d154:	97ffd87b 	bl	3340 <ad_raw_fail>
    d158:	97ffd5d6 	bl	28b0 <abort@plt>
    d15c:	d503201f 	nop

000000000000d160 <__divti3>:
    d160:	d503245f 	bti	c
    d164:	d2800004 	mov	x4, #0x0                   	// #0
    d168:	b7f80721 	tbnz	x1, #63, d24c <__divti3+0xec>
    d16c:	b6f80083 	tbz	x3, #63, d17c <__divti3+0x1c>
    d170:	eb0203e2 	negs	x2, x2
    d174:	aa2403e4 	mvn	x4, x4
    d178:	da0303e3 	ngc	x3, x3
    d17c:	aa0203e6 	mov	x6, x2
    d180:	aa0003e7 	mov	x7, x0
    d184:	aa0103e5 	mov	x5, x1
    d188:	b5000583 	cbnz	x3, d238 <__divti3+0xd8>
    d18c:	eb01005f 	cmp	x2, x1
    d190:	54000e69 	b.ls	d35c <__divti3+0x1fc>  // b.plast
    d194:	dac01040 	clz	x0, x2
    d198:	b40000e0 	cbz	x0, d1b4 <__divti3+0x54>
    d19c:	4b0003e1 	neg	w1, w0
    d1a0:	9ac020a5 	lsl	x5, x5, x0
    d1a4:	9ac02046 	lsl	x6, x2, x0
    d1a8:	9ac124e1 	lsr	x1, x7, x1
    d1ac:	aa050025 	orr	x5, x1, x5
    d1b0:	9ac020e7 	lsl	x7, x7, x0
    d1b4:	d360fcc8 	lsr	x8, x6, #32
    d1b8:	92407cc2 	and	x2, x6, #0xffffffff
    d1bc:	9ac808a3 	udiv	x3, x5, x8
    d1c0:	9b089465 	msub	x5, x3, x8, x5
    d1c4:	aa0303e0 	mov	x0, x3
    d1c8:	9b037c41 	mul	x1, x2, x3
    d1cc:	93c780a5 	extr	x5, x5, x7, #32
    d1d0:	eb05003f 	cmp	x1, x5
    d1d4:	540000a9 	b.ls	d1e8 <__divti3+0x88>  // b.plast
    d1d8:	ab0500c5 	adds	x5, x6, x5
    d1dc:	d1000460 	sub	x0, x3, #0x1
    d1e0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d1e4:	540015a8 	b.hi	d498 <__divti3+0x338>  // b.pmore
    d1e8:	cb0100a5 	sub	x5, x5, x1
    d1ec:	9ac808a3 	udiv	x3, x5, x8
    d1f0:	9b089465 	msub	x5, x3, x8, x5
    d1f4:	aa0303e1 	mov	x1, x3
    d1f8:	9b037c42 	mul	x2, x2, x3
    d1fc:	aa0703e3 	mov	x3, x7
    d200:	b3607ca3 	bfi	x3, x5, #32, #32
    d204:	eb03005f 	cmp	x2, x3
    d208:	540000c9 	b.ls	d220 <__divti3+0xc0>  // b.plast
    d20c:	ab0300c3 	adds	x3, x6, x3
    d210:	d1000425 	sub	x5, x1, #0x1
    d214:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d218:	d1000821 	sub	x1, x1, #0x2
    d21c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d220:	aa008020 	orr	x0, x1, x0, lsl #32
    d224:	d2800001 	mov	x1, #0x0                   	// #0
    d228:	b4000064 	cbz	x4, d234 <__divti3+0xd4>
    d22c:	eb0003e0 	negs	x0, x0
    d230:	da0103e1 	ngc	x1, x1
    d234:	d65f03c0 	ret
    d238:	eb01007f 	cmp	x3, x1
    d23c:	54000109 	b.ls	d25c <__divti3+0xfc>  // b.plast
    d240:	d2800001 	mov	x1, #0x0                   	// #0
    d244:	d2800000 	mov	x0, #0x0                   	// #0
    d248:	17fffff8 	b	d228 <__divti3+0xc8>
    d24c:	eb0003e0 	negs	x0, x0
    d250:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d254:	da0103e1 	ngc	x1, x1
    d258:	17ffffc5 	b	d16c <__divti3+0xc>
    d25c:	dac01067 	clz	x7, x3
    d260:	b40010e7 	cbz	x7, d47c <__divti3+0x31c>
    d264:	d2800805 	mov	x5, #0x40                  	// #64
    d268:	cb0700a5 	sub	x5, x5, x7
    d26c:	9ac72063 	lsl	x3, x3, x7
    d270:	9ac52448 	lsr	x8, x2, x5
    d274:	aa030108 	orr	x8, x8, x3
    d278:	9ac52426 	lsr	x6, x1, x5
    d27c:	92407d0a 	and	x10, x8, #0xffffffff
    d280:	d360fd09 	lsr	x9, x8, #32
    d284:	9ac52403 	lsr	x3, x0, x5
    d288:	9ac72021 	lsl	x1, x1, x7
    d28c:	aa010063 	orr	x3, x3, x1
    d290:	9ac72042 	lsl	x2, x2, x7
    d294:	9ac908cb 	udiv	x11, x6, x9
    d298:	9b099965 	msub	x5, x11, x9, x6
    d29c:	aa0b03e1 	mov	x1, x11
    d2a0:	9b0b7d46 	mul	x6, x10, x11
    d2a4:	93c380a5 	extr	x5, x5, x3, #32
    d2a8:	eb0500df 	cmp	x6, x5
    d2ac:	540000a9 	b.ls	d2c0 <__divti3+0x160>  // b.plast
    d2b0:	ab050105 	adds	x5, x8, x5
    d2b4:	d1000561 	sub	x1, x11, #0x1
    d2b8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d2bc:	54000f48 	b.hi	d4a4 <__divti3+0x344>  // b.pmore
    d2c0:	cb0600a6 	sub	x6, x5, x6
    d2c4:	9ac908cb 	udiv	x11, x6, x9
    d2c8:	9b099969 	msub	x9, x11, x9, x6
    d2cc:	aa0b03e5 	mov	x5, x11
    d2d0:	9b0b7d4a 	mul	x10, x10, x11
    d2d4:	b3607d23 	bfi	x3, x9, #32, #32
    d2d8:	eb03015f 	cmp	x10, x3
    d2dc:	540000a9 	b.ls	d2f0 <__divti3+0x190>  // b.plast
    d2e0:	ab030103 	adds	x3, x8, x3
    d2e4:	d1000565 	sub	x5, x11, #0x1
    d2e8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d2ec:	54000e28 	b.hi	d4b0 <__divti3+0x350>  // b.pmore
    d2f0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d2f4:	92407c48 	and	x8, x2, #0xffffffff
    d2f8:	2a0503e5 	mov	w5, w5
    d2fc:	d360fc42 	lsr	x2, x2, #32
    d300:	d360fc26 	lsr	x6, x1, #32
    d304:	cb0a0063 	sub	x3, x3, x10
    d308:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d30c:	9b087caa 	mul	x10, x5, x8
    d310:	9b087cc8 	mul	x8, x6, x8
    d314:	9b0220a5 	madd	x5, x5, x2, x8
    d318:	9b027cc6 	mul	x6, x6, x2
    d31c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d320:	8b0900c5 	add	x5, x6, x9
    d324:	eb02011f 	cmp	x8, x2
    d328:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d32c:	8b4280c6 	add	x6, x6, x2, lsr #32
    d330:	eb06007f 	cmp	x3, x6
    d334:	540000e3 	b.cc	d350 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d338:	92407d4a 	and	x10, x10, #0xffffffff
    d33c:	9ac72000 	lsl	x0, x0, x7
    d340:	8b028142 	add	x2, x10, x2, lsl #32
    d344:	eb02001f 	cmp	x0, x2
    d348:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d34c:	54000a01 	b.ne	d48c <__divti3+0x32c>  // b.any
    d350:	d1000420 	sub	x0, x1, #0x1
    d354:	d2800001 	mov	x1, #0x0                   	// #0
    d358:	17ffffb4 	b	d228 <__divti3+0xc8>
    d35c:	b5000062 	cbnz	x2, d368 <__divti3+0x208>
    d360:	d2800022 	mov	x2, #0x1                   	// #1
    d364:	9ac30846 	udiv	x6, x2, x3
    d368:	dac010c8 	clz	x8, x6
    d36c:	b5000408 	cbnz	x8, d3ec <__divti3+0x28c>
    d370:	d360fcc9 	lsr	x9, x6, #32
    d374:	92407cc5 	and	x5, x6, #0xffffffff
    d378:	cb060023 	sub	x3, x1, x6
    d37c:	d2800021 	mov	x1, #0x1                   	// #1
    d380:	9ac90868 	udiv	x8, x3, x9
    d384:	9b098d03 	msub	x3, x8, x9, x3
    d388:	aa0803e0 	mov	x0, x8
    d38c:	9b057d02 	mul	x2, x8, x5
    d390:	93c78063 	extr	x3, x3, x7, #32
    d394:	eb03005f 	cmp	x2, x3
    d398:	540000a9 	b.ls	d3ac <__divti3+0x24c>  // b.plast
    d39c:	ab0300c3 	adds	x3, x6, x3
    d3a0:	d1000500 	sub	x0, x8, #0x1
    d3a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d3a8:	54000968 	b.hi	d4d4 <__divti3+0x374>  // b.pmore
    d3ac:	cb020063 	sub	x3, x3, x2
    d3b0:	9ac90862 	udiv	x2, x3, x9
    d3b4:	aa0203e8 	mov	x8, x2
    d3b8:	9b098c42 	msub	x2, x2, x9, x3
    d3bc:	aa0703e3 	mov	x3, x7
    d3c0:	9b057d05 	mul	x5, x8, x5
    d3c4:	b3607c43 	bfi	x3, x2, #32, #32
    d3c8:	eb0300bf 	cmp	x5, x3
    d3cc:	540000c9 	b.ls	d3e4 <__divti3+0x284>  // b.plast
    d3d0:	ab0300c2 	adds	x2, x6, x3
    d3d4:	d1000503 	sub	x3, x8, #0x1
    d3d8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d3dc:	d1000908 	sub	x8, x8, #0x2
    d3e0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d3e4:	aa008100 	orr	x0, x8, x0, lsl #32
    d3e8:	17ffff90 	b	d228 <__divti3+0xc8>
    d3ec:	9ac820c6 	lsl	x6, x6, x8
    d3f0:	d2800803 	mov	x3, #0x40                  	// #64
    d3f4:	cb080063 	sub	x3, x3, x8
    d3f8:	d360fcc9 	lsr	x9, x6, #32
    d3fc:	9ac82027 	lsl	x7, x1, x8
    d400:	92407cc5 	and	x5, x6, #0xffffffff
    d404:	9ac32422 	lsr	x2, x1, x3
    d408:	9ac32403 	lsr	x3, x0, x3
    d40c:	aa070063 	orr	x3, x3, x7
    d410:	9ac9084a 	udiv	x10, x2, x9
    d414:	9ac82007 	lsl	x7, x0, x8
    d418:	9b098940 	msub	x0, x10, x9, x2
    d41c:	aa0a03e1 	mov	x1, x10
    d420:	9b0a7ca2 	mul	x2, x5, x10
    d424:	93c38000 	extr	x0, x0, x3, #32
    d428:	eb00005f 	cmp	x2, x0
    d42c:	540000a9 	b.ls	d440 <__divti3+0x2e0>  // b.plast
    d430:	ab0000c0 	adds	x0, x6, x0
    d434:	d1000541 	sub	x1, x10, #0x1
    d438:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d43c:	54000468 	b.hi	d4c8 <__divti3+0x368>  // b.pmore
    d440:	cb020000 	sub	x0, x0, x2
    d444:	9ac9080a 	udiv	x10, x0, x9
    d448:	9b098140 	msub	x0, x10, x9, x0
    d44c:	aa0a03e2 	mov	x2, x10
    d450:	9b0a7ca8 	mul	x8, x5, x10
    d454:	b3607c03 	bfi	x3, x0, #32, #32
    d458:	eb03011f 	cmp	x8, x3
    d45c:	540000a9 	b.ls	d470 <__divti3+0x310>  // b.plast
    d460:	ab0300c3 	adds	x3, x6, x3
    d464:	d1000542 	sub	x2, x10, #0x1
    d468:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d46c:	54000288 	b.hi	d4bc <__divti3+0x35c>  // b.pmore
    d470:	cb080063 	sub	x3, x3, x8
    d474:	aa018041 	orr	x1, x2, x1, lsl #32
    d478:	17ffffc2 	b	d380 <__divti3+0x220>
    d47c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d480:	d2800001 	mov	x1, #0x0                   	// #0
    d484:	9a9f87e0 	cset	x0, ls	// ls = plast
    d488:	17ffff68 	b	d228 <__divti3+0xc8>
    d48c:	aa0103e0 	mov	x0, x1
    d490:	d2800001 	mov	x1, #0x0                   	// #0
    d494:	17ffff65 	b	d228 <__divti3+0xc8>
    d498:	d1000860 	sub	x0, x3, #0x2
    d49c:	8b0600a5 	add	x5, x5, x6
    d4a0:	17ffff52 	b	d1e8 <__divti3+0x88>
    d4a4:	d1000961 	sub	x1, x11, #0x2
    d4a8:	8b0800a5 	add	x5, x5, x8
    d4ac:	17ffff85 	b	d2c0 <__divti3+0x160>
    d4b0:	d1000965 	sub	x5, x11, #0x2
    d4b4:	8b080063 	add	x3, x3, x8
    d4b8:	17ffff8e 	b	d2f0 <__divti3+0x190>
    d4bc:	d1000942 	sub	x2, x10, #0x2
    d4c0:	8b060063 	add	x3, x3, x6
    d4c4:	17ffffeb 	b	d470 <__divti3+0x310>
    d4c8:	d1000941 	sub	x1, x10, #0x2
    d4cc:	8b060000 	add	x0, x0, x6
    d4d0:	17ffffdc 	b	d440 <__divti3+0x2e0>
    d4d4:	d1000900 	sub	x0, x8, #0x2
    d4d8:	8b060063 	add	x3, x3, x6
    d4dc:	17ffffb4 	b	d3ac <__divti3+0x24c>

000000000000d4e0 <__modti3>:
    d4e0:	d503245f 	bti	c
    d4e4:	d2800004 	mov	x4, #0x0                   	// #0
    d4e8:	b6f80081 	tbz	x1, #63, d4f8 <__modti3+0x18>
    d4ec:	eb0003e0 	negs	x0, x0
    d4f0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d4f4:	da0103e1 	ngc	x1, x1
    d4f8:	f100007f 	cmp	x3, #0x0
    d4fc:	5400128b 	b.lt	d74c <__modti3+0x26c>  // b.tstop
    d500:	aa0003e7 	mov	x7, x0
    d504:	aa0103e6 	mov	x6, x1
    d508:	540004e1 	b.ne	d5a4 <__modti3+0xc4>  // b.any
    d50c:	eb02003f 	cmp	x1, x2
    d510:	54000dc2 	b.cs	d6c8 <__modti3+0x1e8>  // b.hs, b.nlast
    d514:	dac01043 	clz	x3, x2
    d518:	aa0303e5 	mov	x5, x3
    d51c:	b40000e3 	cbz	x3, d538 <__modti3+0x58>
    d520:	4b0303e6 	neg	w6, w3
    d524:	9ac32021 	lsl	x1, x1, x3
    d528:	9ac32042 	lsl	x2, x2, x3
    d52c:	9ac62406 	lsr	x6, x0, x6
    d530:	aa0100c6 	orr	x6, x6, x1
    d534:	9ac32007 	lsl	x7, x0, x3
    d538:	d360fc40 	lsr	x0, x2, #32
    d53c:	92407c43 	and	x3, x2, #0xffffffff
    d540:	9ac008c1 	udiv	x1, x6, x0
    d544:	9b009826 	msub	x6, x1, x0, x6
    d548:	9b017c61 	mul	x1, x3, x1
    d54c:	93c780c6 	extr	x6, x6, x7, #32
    d550:	eb06003f 	cmp	x1, x6
    d554:	540000a9 	b.ls	d568 <__modti3+0x88>  // b.plast
    d558:	ab060046 	adds	x6, x2, x6
    d55c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d560:	8b0200c8 	add	x8, x6, x2
    d564:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d568:	cb0100c6 	sub	x6, x6, x1
    d56c:	9ac008c8 	udiv	x8, x6, x0
    d570:	9b009901 	msub	x1, x8, x0, x6
    d574:	aa0703e0 	mov	x0, x7
    d578:	9b087c63 	mul	x3, x3, x8
    d57c:	b3607c20 	bfi	x0, x1, #32, #32
    d580:	eb00007f 	cmp	x3, x0
    d584:	54001088 	b.hi	d794 <__modti3+0x2b4>  // b.pmore
    d588:	cb030000 	sub	x0, x0, x3
    d58c:	9ac52400 	lsr	x0, x0, x5
    d590:	d2800001 	mov	x1, #0x0                   	// #0
    d594:	b4000064 	cbz	x4, d5a0 <__modti3+0xc0>
    d598:	eb0003e0 	negs	x0, x0
    d59c:	da0103e1 	ngc	x1, x1
    d5a0:	d65f03c0 	ret
    d5a4:	dac01066 	clz	x6, x3
    d5a8:	eb03003f 	cmp	x1, x3
    d5ac:	54ffff43 	b.cc	d594 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d5b0:	93407cc5 	sxtw	x5, w6
    d5b4:	d2800808 	mov	x8, #0x40                  	// #64
    d5b8:	cb050108 	sub	x8, x8, x5
    d5bc:	9ac62063 	lsl	x3, x3, x6
    d5c0:	9ac62025 	lsl	x5, x1, x6
    d5c4:	9ac82447 	lsr	x7, x2, x8
    d5c8:	aa0300e7 	orr	x7, x7, x3
    d5cc:	9ac82423 	lsr	x3, x1, x8
    d5d0:	92407cec 	and	x12, x7, #0xffffffff
    d5d4:	d360fcea 	lsr	x10, x7, #32
    d5d8:	9ac82401 	lsr	x1, x0, x8
    d5dc:	aa050021 	orr	x1, x1, x5
    d5e0:	9ac62042 	lsl	x2, x2, x6
    d5e4:	9ac62000 	lsl	x0, x0, x6
    d5e8:	9aca086b 	udiv	x11, x3, x10
    d5ec:	9b0a8d63 	msub	x3, x11, x10, x3
    d5f0:	aa0b03e5 	mov	x5, x11
    d5f4:	9b0b7d89 	mul	x9, x12, x11
    d5f8:	93c18063 	extr	x3, x3, x1, #32
    d5fc:	eb03013f 	cmp	x9, x3
    d600:	540000a9 	b.ls	d614 <__modti3+0x134>  // b.plast
    d604:	ab0300e3 	adds	x3, x7, x3
    d608:	d1000565 	sub	x5, x11, #0x1
    d60c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d610:	54001168 	b.hi	d83c <__modti3+0x35c>  // b.pmore
    d614:	cb090063 	sub	x3, x3, x9
    d618:	9aca086b 	udiv	x11, x3, x10
    d61c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d620:	aa0b03e9 	mov	x9, x11
    d624:	9b0b7d8c 	mul	x12, x12, x11
    d628:	b3607d41 	bfi	x1, x10, #32, #32
    d62c:	eb01019f 	cmp	x12, x1
    d630:	540000a9 	b.ls	d644 <__modti3+0x164>  // b.plast
    d634:	ab0100e1 	adds	x1, x7, x1
    d638:	d1000569 	sub	x9, x11, #0x1
    d63c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d640:	54000f88 	b.hi	d830 <__modti3+0x350>  // b.pmore
    d644:	aa058123 	orr	x3, x9, x5, lsl #32
    d648:	92407c4b 	and	x11, x2, #0xffffffff
    d64c:	2a0903e9 	mov	w9, w9
    d650:	d360fc4a 	lsr	x10, x2, #32
    d654:	d360fc63 	lsr	x3, x3, #32
    d658:	cb0c0021 	sub	x1, x1, x12
    d65c:	aa0a03ec 	mov	x12, x10
    d660:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d664:	9b0b7d25 	mul	x5, x9, x11
    d668:	9b0b7c6b 	mul	x11, x3, x11
    d66c:	9b0a2d29 	madd	x9, x9, x10, x11
    d670:	92407caa 	and	x10, x5, #0xffffffff
    d674:	9b0c7c63 	mul	x3, x3, x12
    d678:	8b458125 	add	x5, x9, x5, lsr #32
    d67c:	8b0d0069 	add	x9, x3, x13
    d680:	eb05017f 	cmp	x11, x5
    d684:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d688:	8b058149 	add	x9, x10, x5, lsl #32
    d68c:	8b458063 	add	x3, x3, x5, lsr #32
    d690:	eb03003f 	cmp	x1, x3
    d694:	54000063 	b.cc	d6a0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d698:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d69c:	54000082 	b.cs	d6ac <__modti3+0x1cc>  // b.hs, b.nlast
    d6a0:	eb020129 	subs	x9, x9, x2
    d6a4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d6a8:	cb070063 	sub	x3, x3, x7
    d6ac:	eb090000 	subs	x0, x0, x9
    d6b0:	da030021 	sbc	x1, x1, x3
    d6b4:	9ac62400 	lsr	x0, x0, x6
    d6b8:	9ac82028 	lsl	x8, x1, x8
    d6bc:	aa000100 	orr	x0, x8, x0
    d6c0:	9ac62421 	lsr	x1, x1, x6
    d6c4:	17ffffb4 	b	d594 <__modti3+0xb4>
    d6c8:	b5000062 	cbnz	x2, d6d4 <__modti3+0x1f4>
    d6cc:	d2800023 	mov	x3, #0x1                   	// #1
    d6d0:	9ac20862 	udiv	x2, x3, x2
    d6d4:	dac01048 	clz	x8, x2
    d6d8:	aa0803e5 	mov	x5, x8
    d6dc:	b5000668 	cbnz	x8, d7a8 <__modti3+0x2c8>
    d6e0:	cb020020 	sub	x0, x1, x2
    d6e4:	d360fc49 	lsr	x9, x2, #32
    d6e8:	92407c4a 	and	x10, x2, #0xffffffff
    d6ec:	9ac90801 	udiv	x1, x0, x9
    d6f0:	9b098020 	msub	x0, x1, x9, x0
    d6f4:	9b0a7c21 	mul	x1, x1, x10
    d6f8:	93c78000 	extr	x0, x0, x7, #32
    d6fc:	eb00003f 	cmp	x1, x0
    d700:	540000a9 	b.ls	d714 <__modti3+0x234>  // b.plast
    d704:	ab000040 	adds	x0, x2, x0
    d708:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d70c:	8b020003 	add	x3, x0, x2
    d710:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d714:	cb010001 	sub	x1, x0, x1
    d718:	9ac90820 	udiv	x0, x1, x9
    d71c:	9b098403 	msub	x3, x0, x9, x1
    d720:	aa0703e1 	mov	x1, x7
    d724:	9b0a7c00 	mul	x0, x0, x10
    d728:	b3607c61 	bfi	x1, x3, #32, #32
    d72c:	eb01001f 	cmp	x0, x1
    d730:	540000a9 	b.ls	d744 <__modti3+0x264>  // b.plast
    d734:	ab010041 	adds	x1, x2, x1
    d738:	8b020022 	add	x2, x1, x2
    d73c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d740:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d744:	cb000020 	sub	x0, x1, x0
    d748:	17ffff91 	b	d58c <__modti3+0xac>
    d74c:	eb0203e5 	negs	x5, x2
    d750:	aa0003e7 	mov	x7, x0
    d754:	da0303e8 	ngc	x8, x3
    d758:	aa0503e2 	mov	x2, x5
    d75c:	aa0803e3 	mov	x3, x8
    d760:	aa0103e6 	mov	x6, x1
    d764:	b4ffed48 	cbz	x8, d50c <__modti3+0x2c>
    d768:	eb01011f 	cmp	x8, x1
    d76c:	54fff148 	b.hi	d594 <__modti3+0xb4>  // b.pmore
    d770:	dac01109 	clz	x9, x8
    d774:	2a0903e6 	mov	w6, w9
    d778:	b5fff1c9 	cbnz	x9, d5b0 <__modti3+0xd0>
    d77c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d780:	54000068 	b.hi	d78c <__modti3+0x2ac>  // b.pmore
    d784:	eb050007 	subs	x7, x0, x5
    d788:	da080021 	sbc	x1, x1, x8
    d78c:	aa0703e0 	mov	x0, x7
    d790:	17ffff81 	b	d594 <__modti3+0xb4>
    d794:	ab000040 	adds	x0, x2, x0
    d798:	8b020002 	add	x2, x0, x2
    d79c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d7a0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d7a4:	17ffff79 	b	d588 <__modti3+0xa8>
    d7a8:	9ac82042 	lsl	x2, x2, x8
    d7ac:	d2800803 	mov	x3, #0x40                  	// #64
    d7b0:	cb080063 	sub	x3, x3, x8
    d7b4:	d360fc49 	lsr	x9, x2, #32
    d7b8:	9ac82027 	lsl	x7, x1, x8
    d7bc:	92407c4a 	and	x10, x2, #0xffffffff
    d7c0:	9ac32426 	lsr	x6, x1, x3
    d7c4:	9ac32403 	lsr	x3, x0, x3
    d7c8:	aa070063 	orr	x3, x3, x7
    d7cc:	9ac908c1 	udiv	x1, x6, x9
    d7d0:	9ac82007 	lsl	x7, x0, x8
    d7d4:	9b099820 	msub	x0, x1, x9, x6
    d7d8:	9b017d41 	mul	x1, x10, x1
    d7dc:	93c38000 	extr	x0, x0, x3, #32
    d7e0:	eb00003f 	cmp	x1, x0
    d7e4:	540000a9 	b.ls	d7f8 <__modti3+0x318>  // b.plast
    d7e8:	ab000040 	adds	x0, x2, x0
    d7ec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d7f0:	8b020006 	add	x6, x0, x2
    d7f4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d7f8:	cb010000 	sub	x0, x0, x1
    d7fc:	9ac90801 	udiv	x1, x0, x9
    d800:	9b098026 	msub	x6, x1, x9, x0
    d804:	aa0303e0 	mov	x0, x3
    d808:	9b017d41 	mul	x1, x10, x1
    d80c:	b3607cc0 	bfi	x0, x6, #32, #32
    d810:	eb00003f 	cmp	x1, x0
    d814:	540000a9 	b.ls	d828 <__modti3+0x348>  // b.plast
    d818:	ab000040 	adds	x0, x2, x0
    d81c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d820:	8b020003 	add	x3, x0, x2
    d824:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d828:	cb010000 	sub	x0, x0, x1
    d82c:	17ffffb0 	b	d6ec <__modti3+0x20c>
    d830:	d1000969 	sub	x9, x11, #0x2
    d834:	8b070021 	add	x1, x1, x7
    d838:	17ffff83 	b	d644 <__modti3+0x164>
    d83c:	d1000965 	sub	x5, x11, #0x2
    d840:	8b070063 	add	x3, x3, x7
    d844:	17ffff74 	b	d614 <__modti3+0x134>
    d848:	d503201f 	nop
    d84c:	d503201f 	nop

000000000000d850 <atexit>:
    d850:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d854:	f0000082 	adrp	x2, 20000 <__data_start>
    d858:	d2800001 	mov	x1, #0x0                   	// #0
    d85c:	910003fd 	mov	x29, sp
    d860:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d864:	f9400442 	ldr	x2, [x2, #8]
    d868:	17ffd3be 	b	2760 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d86c <_fini>:
    d86c:	d503201f 	nop
    d870:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d874:	910003fd 	mov	x29, sp
    d878:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d87c:	d65f03c0 	ret
