
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/129-199/fwp-explicit-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001370 <_init>:
    1370:	d503201f 	nop
    1374:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1378:	910003fd 	mov	x29, sp
    137c:	9400018e 	bl	19b4 <call_weak_fn>
    1380:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1384:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001390 <.plt>:
    1390:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1394:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1398:	f946fe11 	ldr	x17, [x16, #3576]
    139c:	9137e210 	add	x16, x16, #0xdf8
    13a0:	d61f0220 	br	x17
    13a4:	d503201f 	nop
    13a8:	d503201f 	nop
    13ac:	d503201f 	nop

00000000000013b0 <memcpy@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    13b4:	f9470211 	ldr	x17, [x16, #3584]
    13b8:	91380210 	add	x16, x16, #0xe00
    13bc:	d61f0220 	br	x17

00000000000013c0 <sigaltstack@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    13c4:	f9470611 	ldr	x17, [x16, #3592]
    13c8:	91382210 	add	x16, x16, #0xe08
    13cc:	d61f0220 	br	x17

00000000000013d0 <_exit@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    13d4:	f9470a11 	ldr	x17, [x16, #3600]
    13d8:	91384210 	add	x16, x16, #0xe10
    13dc:	d61f0220 	br	x17

00000000000013e0 <strlen@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    13e4:	f9470e11 	ldr	x17, [x16, #3608]
    13e8:	91386210 	add	x16, x16, #0xe18
    13ec:	d61f0220 	br	x17

00000000000013f0 <__sprintf_chk@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    13f4:	f9471211 	ldr	x17, [x16, #3616]
    13f8:	91388210 	add	x16, x16, #0xe20
    13fc:	d61f0220 	br	x17

0000000000001400 <exit@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1404:	f9471611 	ldr	x17, [x16, #3624]
    1408:	9138a210 	add	x16, x16, #0xe28
    140c:	d61f0220 	br	x17

0000000000001410 <__libc_start_main@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1414:	f9471a11 	ldr	x17, [x16, #3632]
    1418:	9138c210 	add	x16, x16, #0xe30
    141c:	d61f0220 	br	x17

0000000000001420 <strtoll@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1424:	f9471e11 	ldr	x17, [x16, #3640]
    1428:	9138e210 	add	x16, x16, #0xe38
    142c:	d61f0220 	br	x17

0000000000001430 <strtod@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1434:	f9472211 	ldr	x17, [x16, #3648]
    1438:	91390210 	add	x16, x16, #0xe40
    143c:	d61f0220 	br	x17

0000000000001440 <__cxa_finalize@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1444:	f9472611 	ldr	x17, [x16, #3656]
    1448:	91392210 	add	x16, x16, #0xe48
    144c:	d61f0220 	br	x17

0000000000001450 <__cxa_atexit@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1454:	f9472a11 	ldr	x17, [x16, #3664]
    1458:	91394210 	add	x16, x16, #0xe50
    145c:	d61f0220 	br	x17

0000000000001460 <pthread_attr_init@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1464:	f9472e11 	ldr	x17, [x16, #3672]
    1468:	91396210 	add	x16, x16, #0xe58
    146c:	d61f0220 	br	x17

0000000000001470 <fputc@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1474:	f9473211 	ldr	x17, [x16, #3680]
    1478:	91398210 	add	x16, x16, #0xe60
    147c:	d61f0220 	br	x17

0000000000001480 <clock_gettime@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1484:	f9473611 	ldr	x17, [x16, #3688]
    1488:	9139a210 	add	x16, x16, #0xe68
    148c:	d61f0220 	br	x17

0000000000001490 <setvbuf@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1494:	f9473a11 	ldr	x17, [x16, #3696]
    1498:	9139c210 	add	x16, x16, #0xe70
    149c:	d61f0220 	br	x17

00000000000014a0 <__memcpy_chk@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    14a4:	f9473e11 	ldr	x17, [x16, #3704]
    14a8:	9139e210 	add	x16, x16, #0xe78
    14ac:	d61f0220 	br	x17

00000000000014b0 <signal@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    14b4:	f9474211 	ldr	x17, [x16, #3712]
    14b8:	913a0210 	add	x16, x16, #0xe80
    14bc:	d61f0220 	br	x17

00000000000014c0 <__snprintf_chk@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    14c4:	f9474611 	ldr	x17, [x16, #3720]
    14c8:	913a2210 	add	x16, x16, #0xe88
    14cc:	d61f0220 	br	x17

00000000000014d0 <fclose@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    14d4:	f9474a11 	ldr	x17, [x16, #3728]
    14d8:	913a4210 	add	x16, x16, #0xe90
    14dc:	d61f0220 	br	x17

00000000000014e0 <fopen@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    14e4:	f9474e11 	ldr	x17, [x16, #3736]
    14e8:	913a6210 	add	x16, x16, #0xe98
    14ec:	d61f0220 	br	x17

00000000000014f0 <malloc@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    14f4:	f9475211 	ldr	x17, [x16, #3744]
    14f8:	913a8210 	add	x16, x16, #0xea0
    14fc:	d61f0220 	br	x17

0000000000001500 <pthread_attr_destroy@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1504:	f9475611 	ldr	x17, [x16, #3752]
    1508:	913aa210 	add	x16, x16, #0xea8
    150c:	d61f0220 	br	x17

0000000000001510 <sigemptyset@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1514:	f9475a11 	ldr	x17, [x16, #3760]
    1518:	913ac210 	add	x16, x16, #0xeb0
    151c:	d61f0220 	br	x17

0000000000001520 <memset@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1524:	f9475e11 	ldr	x17, [x16, #3768]
    1528:	913ae210 	add	x16, x16, #0xeb8
    152c:	d61f0220 	br	x17

0000000000001530 <calloc@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1534:	f9476211 	ldr	x17, [x16, #3776]
    1538:	913b0210 	add	x16, x16, #0xec0
    153c:	d61f0220 	br	x17

0000000000001540 <realloc@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1544:	f9476611 	ldr	x17, [x16, #3784]
    1548:	913b2210 	add	x16, x16, #0xec8
    154c:	d61f0220 	br	x17

0000000000001550 <__stack_chk_fail@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1554:	f9476a11 	ldr	x17, [x16, #3792]
    1558:	913b4210 	add	x16, x16, #0xed0
    155c:	d61f0220 	br	x17

0000000000001560 <close@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1564:	f9476e11 	ldr	x17, [x16, #3800]
    1568:	913b6210 	add	x16, x16, #0xed8
    156c:	d61f0220 	br	x17

0000000000001570 <sigaction@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1574:	f9477211 	ldr	x17, [x16, #3808]
    1578:	913b8210 	add	x16, x16, #0xee0
    157c:	d61f0220 	br	x17

0000000000001580 <__gmon_start__@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1584:	f9477611 	ldr	x17, [x16, #3816]
    1588:	913ba210 	add	x16, x16, #0xee8
    158c:	d61f0220 	br	x17

0000000000001590 <write@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1594:	f9477a11 	ldr	x17, [x16, #3824]
    1598:	913bc210 	add	x16, x16, #0xef0
    159c:	d61f0220 	br	x17

00000000000015a0 <abort@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    15a4:	f9477e11 	ldr	x17, [x16, #3832]
    15a8:	913be210 	add	x16, x16, #0xef8
    15ac:	d61f0220 	br	x17

00000000000015b0 <swapcontext@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    15b4:	f9478211 	ldr	x17, [x16, #3840]
    15b8:	913c0210 	add	x16, x16, #0xf00
    15bc:	d61f0220 	br	x17

00000000000015c0 <__fprintf_chk@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    15c4:	f9478611 	ldr	x17, [x16, #3848]
    15c8:	913c2210 	add	x16, x16, #0xf08
    15cc:	d61f0220 	br	x17

00000000000015d0 <strcmp@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    15d4:	f9478a11 	ldr	x17, [x16, #3856]
    15d8:	913c4210 	add	x16, x16, #0xf10
    15dc:	d61f0220 	br	x17

00000000000015e0 <mmap@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    15e4:	f9478e11 	ldr	x17, [x16, #3864]
    15e8:	913c6210 	add	x16, x16, #0xf18
    15ec:	d61f0220 	br	x17

00000000000015f0 <strtol@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    15f4:	f9479211 	ldr	x17, [x16, #3872]
    15f8:	913c8210 	add	x16, x16, #0xf20
    15fc:	d61f0220 	br	x17

0000000000001600 <strtof@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1604:	f9479611 	ldr	x17, [x16, #3880]
    1608:	913ca210 	add	x16, x16, #0xf28
    160c:	d61f0220 	br	x17

0000000000001610 <free@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1614:	f9479a11 	ldr	x17, [x16, #3888]
    1618:	913cc210 	add	x16, x16, #0xf30
    161c:	d61f0220 	br	x17

0000000000001620 <nanosleep@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1624:	f9479e11 	ldr	x17, [x16, #3896]
    1628:	913ce210 	add	x16, x16, #0xf38
    162c:	d61f0220 	br	x17

0000000000001630 <strchr@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1634:	f947a211 	ldr	x17, [x16, #3904]
    1638:	913d0210 	add	x16, x16, #0xf40
    163c:	d61f0220 	br	x17

0000000000001640 <strtoull@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1644:	f947a611 	ldr	x17, [x16, #3912]
    1648:	913d2210 	add	x16, x16, #0xf48
    164c:	d61f0220 	br	x17

0000000000001650 <fwrite@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1654:	f947aa11 	ldr	x17, [x16, #3920]
    1658:	913d4210 	add	x16, x16, #0xf50
    165c:	d61f0220 	br	x17

0000000000001660 <pthread_create@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1664:	f947ae11 	ldr	x17, [x16, #3928]
    1668:	913d6210 	add	x16, x16, #0xf58
    166c:	d61f0220 	br	x17

0000000000001670 <munmap@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1674:	f947b211 	ldr	x17, [x16, #3936]
    1678:	913d8210 	add	x16, x16, #0xf60
    167c:	d61f0220 	br	x17

0000000000001680 <fflush@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1684:	f947b611 	ldr	x17, [x16, #3944]
    1688:	913da210 	add	x16, x16, #0xf68
    168c:	d61f0220 	br	x17

0000000000001690 <strcpy@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1694:	f947ba11 	ldr	x17, [x16, #3952]
    1698:	913dc210 	add	x16, x16, #0xf70
    169c:	d61f0220 	br	x17

00000000000016a0 <sysconf@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    16a4:	f947be11 	ldr	x17, [x16, #3960]
    16a8:	913de210 	add	x16, x16, #0xf78
    16ac:	d61f0220 	br	x17

00000000000016b0 <strstr@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    16b4:	f947c211 	ldr	x17, [x16, #3968]
    16b8:	913e0210 	add	x16, x16, #0xf80
    16bc:	d61f0220 	br	x17

00000000000016c0 <_Exit@plt>:
    16c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    16c4:	f947c611 	ldr	x17, [x16, #3976]
    16c8:	913e2210 	add	x16, x16, #0xf88
    16cc:	d61f0220 	br	x17

00000000000016d0 <pthread_join@plt>:
    16d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    16d4:	f947ca11 	ldr	x17, [x16, #3984]
    16d8:	913e4210 	add	x16, x16, #0xf90
    16dc:	d61f0220 	br	x17

00000000000016e0 <getenv@plt>:
    16e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    16e4:	f947ce11 	ldr	x17, [x16, #3992]
    16e8:	913e6210 	add	x16, x16, #0xf98
    16ec:	d61f0220 	br	x17

00000000000016f0 <mprotect@plt>:
    16f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    16f4:	f947d211 	ldr	x17, [x16, #4000]
    16f8:	913e8210 	add	x16, x16, #0xfa0
    16fc:	d61f0220 	br	x17

0000000000001700 <fgets@plt>:
    1700:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1704:	f947d611 	ldr	x17, [x16, #4008]
    1708:	913ea210 	add	x16, x16, #0xfa8
    170c:	d61f0220 	br	x17

0000000000001710 <pthread_attr_setstacksize@plt>:
    1710:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x132b8>
    1714:	f947da11 	ldr	x17, [x16, #4016]
    1718:	913ec210 	add	x16, x16, #0xfb0
    171c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001740 <fwp_trap_overflow.constprop.0>:
    1740:	d10243ff 	sub	sp, sp, #0x90
    1744:	d2800c03 	mov	x3, #0x60                  	// #96
    1748:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x132b8>
    174c:	f947f421 	ldr	x1, [x1, #4072]
    1750:	b0000045 	adrp	x5, a000 <__divti3+0x2e0>
    1754:	a9077bfd 	stp	x29, x30, [sp, #112]
    1758:	9101c3fd 	add	x29, sp, #0x70
    175c:	911a40a5 	add	x5, x5, #0x690
    1760:	b0000044 	adrp	x4, a000 <__divti3+0x2e0>
    1764:	f90043f3 	str	x19, [sp, #128]
    1768:	911a6084 	add	x4, x4, #0x698
    176c:	910023f3 	add	x19, sp, #0x8
    1770:	f9400022 	ldr	x2, [x1]
    1774:	f90037e2 	str	x2, [sp, #104]
    1778:	d2800002 	mov	x2, #0x0                   	// #0
    177c:	aa0303e1 	mov	x1, x3
    1780:	52800042 	mov	w2, #0x2                   	// #2
    1784:	aa1303e0 	mov	x0, x19
    1788:	97ffff4e 	bl	14c0 <__snprintf_chk@plt>
    178c:	aa1303e0 	mov	x0, x19
    1790:	940002dc 	bl	2300 <fwp_trap>
    1794:	d503201f 	nop
    1798:	d503201f 	nop
    179c:	d503201f 	nop

00000000000017a0 <main>:
    17a0:	d10243ff 	sub	sp, sp, #0x90
    17a4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    17a8:	f947f400 	ldr	x0, [x0, #4072]
    17ac:	a9067bfd 	stp	x29, x30, [sp, #96]
    17b0:	910183fd 	add	x29, sp, #0x60
    17b4:	a90753f3 	stp	x19, x20, [sp, #112]
    17b8:	f00000f3 	adrp	x19, 20000 <__data_start>
    17bc:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x132b8>
    17c0:	f947ee94 	ldr	x20, [x20, #4056]
    17c4:	f9400281 	ldr	x1, [x20]
    17c8:	f90043f5 	str	x21, [sp, #128]
    17cc:	f9400002 	ldr	x2, [x0]
    17d0:	f9002fe2 	str	x2, [sp, #88]
    17d4:	d2800002 	mov	x2, #0x0                   	// #0
    17d8:	f9002a61 	str	x1, [x19, #80]
    17dc:	940002d9 	bl	2340 <fwp_now_ns>
    17e0:	b0000040 	adrp	x0, a000 <__divti3+0x2e0>
    17e4:	9125e000 	add	x0, x0, #0x978
    17e8:	97ffffbe 	bl	16e0 <getenv@plt>
    17ec:	b4000080 	cbz	x0, 17fc <main+0x5c>
    17f0:	39400001 	ldrb	w1, [x0]
    17f4:	aa0003f5 	mov	x21, x0
    17f8:	35000801 	cbnz	w1, 18f8 <main+0x158>
    17fc:	910023e1 	add	x1, sp, #0x8
    1800:	52800000 	mov	w0, #0x0                   	// #0
    1804:	97ffff1f 	bl	1480 <clock_gettime@plt>
    1808:	35000900 	cbnz	w0, 1928 <main+0x188>
    180c:	a9408be0 	ldp	x0, x2, [sp, #8]
    1810:	d2994003 	mov	x3, #0xca00                	// #51712
    1814:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    1818:	9b037c01 	mul	x1, x0, x3
    181c:	9b437c00 	smulh	x0, x0, x3
    1820:	ab020021 	adds	x1, x1, x2
    1824:	937ffc42 	asr	x2, x2, #63
    1828:	9a020000 	adc	x0, x0, x2
    182c:	f100003f 	cmp	x1, #0x0
    1830:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    1834:	b50009a0 	cbnz	x0, 1968 <main+0x1c8>
    1838:	f9400280 	ldr	x0, [x20]
    183c:	d2a00023 	mov	x3, #0x10000               	// #65536
    1840:	52800002 	mov	w2, #0x0                   	// #0
    1844:	d2800001 	mov	x1, #0x0                   	// #0
    1848:	910063f5 	add	x21, sp, #0x18
    184c:	97ffff11 	bl	1490 <setvbuf@plt>
    1850:	d2800021 	mov	x1, #0x1                   	// #1
    1854:	528001a0 	mov	w0, #0xd                   	// #13
    1858:	97ffff16 	bl	14b0 <signal@plt>
    185c:	aa1503e0 	mov	x0, x21
    1860:	97ffff00 	bl	1460 <pthread_attr_init@plt>
    1864:	350007c0 	cbnz	w0, 195c <main+0x1bc>
    1868:	aa1503e0 	mov	x0, x21
    186c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    1870:	97ffffa8 	bl	1710 <pthread_attr_setstacksize@plt>
    1874:	35000680 	cbnz	w0, 1944 <main+0x1a4>
    1878:	aa1503e1 	mov	x1, x21
    187c:	910023e0 	add	x0, sp, #0x8
    1880:	90000042 	adrp	x2, 9000 <f0+0x1f0c>
    1884:	d2800003 	mov	x3, #0x0                   	// #0
    1888:	911dc042 	add	x2, x2, #0x770
    188c:	97ffff75 	bl	1660 <pthread_create@plt>
    1890:	2a0003e1 	mov	w1, w0
    1894:	aa1503e0 	mov	x0, x21
    1898:	2a0103f5 	mov	w21, w1
    189c:	97ffff19 	bl	1500 <pthread_attr_destroy@plt>
    18a0:	350006a0 	cbnz	w0, 1974 <main+0x1d4>
    18a4:	350004b5 	cbnz	w21, 1938 <main+0x198>
    18a8:	f94007e0 	ldr	x0, [sp, #8]
    18ac:	d2800001 	mov	x1, #0x0                   	// #0
    18b0:	97ffff88 	bl	16d0 <pthread_join@plt>
    18b4:	35000600 	cbnz	w0, 1974 <main+0x1d4>
    18b8:	f9400280 	ldr	x0, [x20]
    18bc:	91014273 	add	x19, x19, #0x50
    18c0:	97ffff70 	bl	1680 <fflush@plt>
    18c4:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x132b8>
    18c8:	f947f421 	ldr	x1, [x1, #4072]
    18cc:	b942da60 	ldr	w0, [x19, #728]
    18d0:	f9402fe3 	ldr	x3, [sp, #88]
    18d4:	f9400022 	ldr	x2, [x1]
    18d8:	eb020063 	subs	x3, x3, x2
    18dc:	d2800002 	mov	x2, #0x0                   	// #0
    18e0:	540002a1 	b.ne	1934 <main+0x194>  // b.any
    18e4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    18e8:	a94753f3 	ldp	x19, x20, [sp, #112]
    18ec:	f94043f5 	ldr	x21, [sp, #128]
    18f0:	910243ff 	add	sp, sp, #0x90
    18f4:	d65f03c0 	ret
    18f8:	910003e1 	mov	x1, sp
    18fc:	52800142 	mov	w2, #0xa                   	// #10
    1900:	97ffff50 	bl	1640 <strtoull@plt>
    1904:	f94003e0 	ldr	x0, [sp]
    1908:	39400000 	ldrb	w0, [x0]
    190c:	35fff780 	cbnz	w0, 17fc <main+0x5c>
    1910:	394002a0 	ldrb	w0, [x21]
    1914:	52801fa1 	mov	w1, #0xfd                  	// #253
    1918:	5100ac00 	sub	w0, w0, #0x2b
    191c:	6a01001f 	tst	w0, w1
    1920:	54fff6e0 	b.eq	17fc <main+0x5c>  // b.none
    1924:	17ffffc5 	b	1838 <main+0x98>
    1928:	b0000040 	adrp	x0, a000 <__divti3+0x2e0>
    192c:	91262000 	add	x0, x0, #0x988
    1930:	94000274 	bl	2300 <fwp_trap>
    1934:	97ffff07 	bl	1550 <__stack_chk_fail@plt>
    1938:	b0000040 	adrp	x0, a000 <__divti3+0x2e0>
    193c:	9128a000 	add	x0, x0, #0xa28
    1940:	94000270 	bl	2300 <fwp_trap>
    1944:	aa1503e0 	mov	x0, x21
    1948:	97fffeee 	bl	1500 <pthread_attr_destroy@plt>
    194c:	35000140 	cbnz	w0, 1974 <main+0x1d4>
    1950:	b0000040 	adrp	x0, a000 <__divti3+0x2e0>
    1954:	91280000 	add	x0, x0, #0xa00
    1958:	9400026a 	bl	2300 <fwp_trap>
    195c:	b0000040 	adrp	x0, a000 <__divti3+0x2e0>
    1960:	91274000 	add	x0, x0, #0x9d0
    1964:	94000267 	bl	2300 <fwp_trap>
    1968:	b0000040 	adrp	x0, a000 <__divti3+0x2e0>
    196c:	9126a000 	add	x0, x0, #0x9a8
    1970:	94000264 	bl	2300 <fwp_trap>
    1974:	97ffff0b 	bl	15a0 <abort@plt>
    1978:	d503201f 	nop
    197c:	d503201f 	nop

0000000000001980 <_start>:
    1980:	d503201f 	nop
    1984:	d280001d 	mov	x29, #0x0                   	// #0
    1988:	d280001e 	mov	x30, #0x0                   	// #0
    198c:	aa0003e5 	mov	x5, x0
    1990:	f94003e1 	ldr	x1, [sp]
    1994:	910023e2 	add	x2, sp, #0x8
    1998:	910003e6 	mov	x6, sp
    199c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    19a0:	f947f800 	ldr	x0, [x0, #4080]
    19a4:	d2800003 	mov	x3, #0x0                   	// #0
    19a8:	d2800004 	mov	x4, #0x0                   	// #0
    19ac:	97fffe99 	bl	1410 <__libc_start_main@plt>
    19b0:	97fffefc 	bl	15a0 <abort@plt>

00000000000019b4 <call_weak_fn>:
    19b4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    19b8:	f947f000 	ldr	x0, [x0, #4064]
    19bc:	b4000040 	cbz	x0, 19c4 <call_weak_fn+0x10>
    19c0:	17fffef0 	b	1580 <__gmon_start__@plt>
    19c4:	d65f03c0 	ret
    19c8:	d503201f 	nop
    19cc:	d503201f 	nop

00000000000019d0 <deregister_tm_clones>:
    19d0:	f00000e0 	adrp	x0, 20000 <__data_start>
    19d4:	9100e000 	add	x0, x0, #0x38
    19d8:	f00000e1 	adrp	x1, 20000 <__data_start>
    19dc:	9100e021 	add	x1, x1, #0x38
    19e0:	eb00003f 	cmp	x1, x0
    19e4:	540000c0 	b.eq	19fc <deregister_tm_clones+0x2c>  // b.none
    19e8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x132b8>
    19ec:	f947e021 	ldr	x1, [x1, #4032]
    19f0:	b4000061 	cbz	x1, 19fc <deregister_tm_clones+0x2c>
    19f4:	aa0103f0 	mov	x16, x1
    19f8:	d61f0200 	br	x16
    19fc:	d65f03c0 	ret

0000000000001a00 <register_tm_clones>:
    1a00:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a04:	9100e000 	add	x0, x0, #0x38
    1a08:	f00000e1 	adrp	x1, 20000 <__data_start>
    1a0c:	9100e021 	add	x1, x1, #0x38
    1a10:	cb000021 	sub	x1, x1, x0
    1a14:	d37ffc22 	lsr	x2, x1, #63
    1a18:	8b810c41 	add	x1, x2, x1, asr #3
    1a1c:	9341fc21 	asr	x1, x1, #1
    1a20:	b40000c1 	cbz	x1, 1a38 <register_tm_clones+0x38>
    1a24:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x132b8>
    1a28:	f947fc42 	ldr	x2, [x2, #4088]
    1a2c:	b4000062 	cbz	x2, 1a38 <register_tm_clones+0x38>
    1a30:	aa0203f0 	mov	x16, x2
    1a34:	d61f0200 	br	x16
    1a38:	d65f03c0 	ret
    1a3c:	d503201f 	nop

0000000000001a40 <__do_global_dtors_aux>:
    1a40:	d503233f 	paciasp
    1a44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1a48:	910003fd 	mov	x29, sp
    1a4c:	f9000bf3 	str	x19, [sp, #16]
    1a50:	f00000f3 	adrp	x19, 20000 <__data_start>
    1a54:	39410260 	ldrb	w0, [x19, #64]
    1a58:	37000140 	tbnz	w0, #0, 1a80 <__do_global_dtors_aux+0x40>
    1a5c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    1a60:	f947e400 	ldr	x0, [x0, #4040]
    1a64:	b4000080 	cbz	x0, 1a74 <__do_global_dtors_aux+0x34>
    1a68:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a6c:	f9400400 	ldr	x0, [x0, #8]
    1a70:	97fffe74 	bl	1440 <__cxa_finalize@plt>
    1a74:	97ffffd7 	bl	19d0 <deregister_tm_clones>
    1a78:	52800020 	mov	w0, #0x1                   	// #1
    1a7c:	39010260 	strb	w0, [x19, #64]
    1a80:	f9400bf3 	ldr	x19, [sp, #16]
    1a84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a88:	d50323bf 	autiasp
    1a8c:	d65f03c0 	ret

0000000000001a90 <frame_dummy>:
    1a90:	d503245f 	bti	c
    1a94:	17ffffdb 	b	1a00 <register_tm_clones>
    1a98:	d503201f 	nop
    1a9c:	d503201f 	nop

0000000000001aa0 <fwp_fmt_u128>:
    1aa0:	d10183ff 	sub	sp, sp, #0x60
    1aa4:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x132b8>
    1aa8:	f947f421 	ldr	x1, [x1, #4072]
    1aac:	a9057bfd 	stp	x29, x30, [sp, #80]
    1ab0:	910143fd 	add	x29, sp, #0x50
    1ab4:	f9400024 	ldr	x4, [x1]
    1ab8:	f90027e4 	str	x4, [sp, #72]
    1abc:	d2800004 	mov	x4, #0x0                   	// #0
    1ac0:	aa030041 	orr	x1, x2, x3
    1ac4:	b5000361 	cbnz	x1, 1b30 <fwp_fmt_u128+0x90>
    1ac8:	910023e9 	add	x9, sp, #0x8
    1acc:	52800601 	mov	w1, #0x30                  	// #48
    1ad0:	5280002d 	mov	w13, #0x1                   	// #1
    1ad4:	390023e1 	strb	w1, [sp, #8]
    1ad8:	93407dad 	sxtw	x13, w13
    1adc:	aa0d03e1 	mov	x1, x13
    1ae0:	8b0d0004 	add	x4, x0, x13
    1ae4:	d503201f 	nop
    1ae8:	8b010123 	add	x3, x9, x1
    1aec:	cb0103e2 	neg	x2, x1
    1af0:	d1000421 	sub	x1, x1, #0x1
    1af4:	385ff063 	ldurb	w3, [x3, #-1]
    1af8:	38226883 	strb	w3, [x4, x2]
    1afc:	35ffff61 	cbnz	w1, 1ae8 <fwp_fmt_u128+0x48>
    1b00:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x132b8>
    1b04:	f947f421 	ldr	x1, [x1, #4072]
    1b08:	382d681f 	strb	wzr, [x0, x13]
    1b0c:	aa0103e0 	mov	x0, x1
    1b10:	f94027e2 	ldr	x2, [sp, #72]
    1b14:	f9400001 	ldr	x1, [x0]
    1b18:	eb010042 	subs	x2, x2, x1
    1b1c:	d2800001 	mov	x1, #0x0                   	// #0
    1b20:	54000561 	b.ne	1bcc <fwp_fmt_u128+0x12c>  // b.any
    1b24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1b28:	910183ff 	add	sp, sp, #0x60
    1b2c:	d65f03c0 	ret
    1b30:	b0000041 	adrp	x1, a000 <__divti3+0x2e0>
    1b34:	912c4021 	add	x1, x1, #0xb10
    1b38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1b3c:	910023e9 	add	x9, sp, #0x8
    1b40:	d2800027 	mov	x7, #0x1                   	// #1
    1b44:	f29999af 	movk	x15, #0xcccd
    1b48:	a9402826 	ldp	x6, x10, [x1]
    1b4c:	d503201f 	nop
    1b50:	ab030041 	adds	x1, x2, x3
    1b54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1b58:	aa0303eb 	mov	x11, x3
    1b5c:	8b070128 	add	x8, x9, x7
    1b60:	aa0203ee 	mov	x14, x2
    1b64:	aa0703ed 	mov	x13, x7
    1b68:	910004e7 	add	x7, x7, #0x1
    1b6c:	9bcf7c24 	umulh	x4, x1, x15
    1b70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1b74:	8b4408a4 	add	x4, x5, x4, lsr #2
    1b78:	cb040021 	sub	x1, x1, x4
    1b7c:	eb010041 	subs	x1, x2, x1
    1b80:	da1f0063 	sbc	x3, x3, xzr
    1b84:	9bc67c24 	umulh	x4, x1, x6
    1b88:	9b061064 	madd	x4, x3, x6, x4
    1b8c:	9b067c2c 	mul	x12, x1, x6
    1b90:	9b0a1024 	madd	x4, x1, x10, x4
    1b94:	9bc67c25 	umulh	x5, x1, x6
    1b98:	9b061465 	madd	x5, x3, x6, x5
    1b9c:	9b0a1425 	madd	x5, x1, x10, x5
    1ba0:	93cc0484 	extr	x4, x4, x12, #1
    1ba4:	8b040884 	add	x4, x4, x4, lsl #2
    1ba8:	d341fca3 	lsr	x3, x5, #1
    1bac:	cb040444 	sub	x4, x2, x4, lsl #1
    1bb0:	93cc04a2 	extr	x2, x5, x12, #1
    1bb4:	1100c084 	add	w4, w4, #0x30
    1bb8:	381ff104 	sturb	w4, [x8, #-1]
    1bbc:	b5fffcab 	cbnz	x11, 1b50 <fwp_fmt_u128+0xb0>
    1bc0:	f10025df 	cmp	x14, #0x9
    1bc4:	54fffc68 	b.hi	1b50 <fwp_fmt_u128+0xb0>  // b.pmore
    1bc8:	17ffffc4 	b	1ad8 <fwp_fmt_u128+0x38>
    1bcc:	97fffe61 	bl	1550 <__stack_chk_fail@plt>

0000000000001bd0 <fwp_range_release>:
    1bd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1bd4:	910003fd 	mov	x29, sp
    1bd8:	f9400801 	ldr	x1, [x0, #16]
    1bdc:	f9000bf3 	str	x19, [sp, #16]
    1be0:	aa0003f3 	mov	x19, x0
    1be4:	b4000061 	cbz	x1, 1bf0 <fwp_range_release+0x20>
    1be8:	f9400400 	ldr	x0, [x0, #8]
    1bec:	d63f0020 	blr	x1
    1bf0:	f9400260 	ldr	x0, [x19]
    1bf4:	f9400e61 	ldr	x1, [x19, #24]
    1bf8:	f9400bf3 	ldr	x19, [sp, #16]
    1bfc:	aa0103f0 	mov	x16, x1
    1c00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1c04:	d61f0200 	br	x16
    1c08:	d503201f 	nop
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_owned_entry32>:
    1c10:	6d400001 	ldp	d1, d0, [x0]
    1c14:	1e613800 	fsub	d0, d0, d1
    1c18:	9e660000 	fmov	x0, d0
    1c1c:	d65f03c0 	ret

0000000000001c20 <fwp_args32>:
    1c20:	d65f03c0 	ret

0000000000001c24 <fwp_owned_entry45>:
    1c24:	6d400400 	ldp	d0, d1, [x0]
    1c28:	1e612800 	fadd	d0, d0, d1
    1c2c:	9e660000 	fmov	x0, d0
    1c30:	d65f03c0 	ret

0000000000001c34 <fwp_owned_entry69>:
    1c34:	b0000041 	adrp	x1, a000 <__divti3+0x2e0>
    1c38:	fd400001 	ldr	d1, [x0]
    1c3c:	fd45a020 	ldr	d0, [x1, #2880]
    1c40:	1e610800 	fmul	d0, d0, d1
    1c44:	9e660000 	fmov	x0, d0
    1c48:	d65f03c0 	ret
    1c4c:	d503201f 	nop

0000000000001c50 <fwp_flush>:
    1c50:	f00000e0 	adrp	x0, 20000 <__data_start>
    1c54:	f9402800 	ldr	x0, [x0, #80]
    1c58:	b4000120 	cbz	x0, 1c7c <fwp_flush+0x2c>
    1c5c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1c60:	910003fd 	mov	x29, sp
    1c64:	97fffe87 	bl	1680 <fflush@plt>
    1c68:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    1c6c:	f947ec00 	ldr	x0, [x0, #4056]
    1c70:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1c74:	f9400000 	ldr	x0, [x0]
    1c78:	17fffe82 	b	1680 <fflush@plt>
    1c7c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    1c80:	f947ec00 	ldr	x0, [x0, #4056]
    1c84:	f9400000 	ldr	x0, [x0]
    1c88:	17fffe7e 	b	1680 <fflush@plt>
    1c8c:	d503201f 	nop

0000000000001c90 <fwp_segv>:
    1c90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c94:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c98:	91014043 	add	x3, x2, #0x50
    1c9c:	910003fd 	mov	x29, sp
    1ca0:	a90153f3 	stp	x19, x20, [sp, #16]
    1ca4:	2a0003f3 	mov	w19, w0
    1ca8:	f9400460 	ldr	x0, [x3, #8]
    1cac:	f90013f5 	str	x21, [sp, #32]
    1cb0:	f9400835 	ldr	x21, [x1, #16]
    1cb4:	b4000280 	cbz	x0, 1d04 <fwp_segv+0x74>
    1cb8:	f9400814 	ldr	x20, [x0, #16]
    1cbc:	b4000254 	cbz	x20, 1d04 <fwp_segv+0x74>
    1cc0:	528003c0 	mov	w0, #0x1e                  	// #30
    1cc4:	97fffe77 	bl	16a0 <sysconf@plt>
    1cc8:	f144029f 	cmp	x20, #0x100, lsl #12
    1ccc:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1cd0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1cd4:	8b000294 	add	x20, x20, x0
    1cd8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1cdc:	eb0102bf 	cmp	x21, x1
    1ce0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1ce4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1ce8:	35000240 	cbnz	w0, 1d30 <fwp_segv+0xa0>
    1cec:	f94013f5 	ldr	x21, [sp, #32]
    1cf0:	2a1303e0 	mov	w0, w19
    1cf4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1cf8:	d2800001 	mov	x1, #0x0                   	// #0
    1cfc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1d00:	17fffdec 	b	14b0 <signal@plt>
    1d04:	91014042 	add	x2, x2, #0x50
    1d08:	f9400840 	ldr	x0, [x2, #16]
    1d0c:	b4ffff00 	cbz	x0, 1cec <fwp_segv+0x5c>
    1d10:	f9400c41 	ldr	x1, [x2, #24]
    1d14:	cb010000 	sub	x0, x0, x1
    1d18:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1d1c:	91440000 	add	x0, x0, #0x100, lsl #12
    1d20:	eb15003f 	cmp	x1, x21
    1d24:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1d28:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1d2c:	34fffe00 	cbz	w0, 1cec <fwp_segv+0x5c>
    1d30:	97ffffc8 	bl	1c50 <fwp_flush>
    1d34:	b0000041 	adrp	x1, a000 <__divti3+0x2e0>
    1d38:	912bc021 	add	x1, x1, #0xaf0
    1d3c:	d2800342 	mov	x2, #0x1a                  	// #26
    1d40:	52800040 	mov	w0, #0x2                   	// #2
    1d44:	97fffe13 	bl	1590 <write@plt>
    1d48:	52800ca0 	mov	w0, #0x65                  	// #101
    1d4c:	97fffda1 	bl	13d0 <_exit@plt>

0000000000001d50 <fwp_heap_oom>:
    1d50:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x132b8>
    1d54:	f947e863 	ldr	x3, [x3, #4048]
    1d58:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1d5c:	d2800262 	mov	x2, #0x13                  	// #19
    1d60:	910003fd 	mov	x29, sp
    1d64:	f9400063 	ldr	x3, [x3]
    1d68:	d2800021 	mov	x1, #0x1                   	// #1
    1d6c:	b0000040 	adrp	x0, a000 <__divti3+0x2e0>
    1d70:	91112000 	add	x0, x0, #0x448
    1d74:	97fffe37 	bl	1650 <fwrite@plt>
    1d78:	d2800000 	mov	x0, #0x0                   	// #0
    1d7c:	97fffe41 	bl	1680 <fflush@plt>
    1d80:	52800cc0 	mov	w0, #0x66                  	// #102
    1d84:	97fffe4f 	bl	16c0 <_Exit@plt>
    1d88:	d503201f 	nop
    1d8c:	d503201f 	nop

0000000000001d90 <fwp_heap_chunks>:
    1d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d94:	910003fd 	mov	x29, sp
    1d98:	a90153f3 	stp	x19, x20, [sp, #16]
    1d9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1da0:	90000195 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    1da4:	9114c2a1 	add	x1, x21, #0x530
    1da8:	f100041f 	cmp	x0, #0x1
    1dac:	54000ca0 	b.eq	1f40 <fwp_heap_chunks+0x1b0>  // b.none
    1db0:	f949f822 	ldr	x2, [x1, #5104]
    1db4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xad0>
    1db8:	912480a5 	add	x5, x5, #0x920
    1dbc:	9114c2a1 	add	x1, x21, #0x530
    1dc0:	f949ec34 	ldr	x20, [x1, #5080]
    1dc4:	eb14005f 	cmp	x2, x20
    1dc8:	54000c42 	b.cs	1f50 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1dcc:	f949fc23 	ldr	x3, [x1, #5112]
    1dd0:	8b020841 	add	x1, x2, x2, lsl #2
    1dd4:	d2800004 	mov	x4, #0x0                   	// #0
    1dd8:	8b010c61 	add	x1, x3, x1, lsl #3
    1ddc:	14000009 	b	1e00 <fwp_heap_chunks+0x70>
    1de0:	91000483 	add	x3, x4, #0x1
    1de4:	eb03001f 	cmp	x0, x3
    1de8:	54000940 	b.eq	1f10 <fwp_heap_chunks+0x180>  // b.none
    1dec:	91000442 	add	x2, x2, #0x1
    1df0:	aa0303e4 	mov	x4, x3
    1df4:	9100a021 	add	x1, x1, #0x28
    1df8:	eb02029f 	cmp	x20, x2
    1dfc:	54000100 	b.eq	1e1c <fwp_heap_chunks+0x8c>  // b.none
    1e00:	39400023 	ldrb	w3, [x1]
    1e04:	34fffee3 	cbz	w3, 1de0 <fwp_heap_chunks+0x50>
    1e08:	91000442 	add	x2, x2, #0x1
    1e0c:	9100a021 	add	x1, x1, #0x28
    1e10:	d2800004 	mov	x4, #0x0                   	// #0
    1e14:	eb02029f 	cmp	x20, x2
    1e18:	54ffff41 	b.ne	1e00 <fwp_heap_chunks+0x70>  // b.any
    1e1c:	cb040294 	sub	x20, x20, x4
    1e20:	f9001bf7 	str	x23, [sp, #48]
    1e24:	9114c2b7 	add	x23, x21, #0x530
    1e28:	8b140013 	add	x19, x0, x20
    1e2c:	f94a1ae1 	ldr	x1, [x23, #5168]
    1e30:	f949f2e0 	ldr	x0, [x23, #5088]
    1e34:	cb040021 	sub	x1, x1, x4
    1e38:	f90a1ae1 	str	x1, [x23, #5168]
    1e3c:	eb00027f 	cmp	x19, x0
    1e40:	54000429 	b.ls	1ec4 <fwp_heap_chunks+0x134>  // b.plast
    1e44:	f949eae1 	ldr	x1, [x23, #5072]
    1e48:	eb01027f 	cmp	x19, x1
    1e4c:	54000888 	b.hi	1f5c <fwp_heap_chunks+0x1cc>  // b.pmore
    1e50:	91010276 	add	x22, x19, #0x40
    1e54:	52800062 	mov	w2, #0x3                   	// #3
    1e58:	f949dae3 	ldr	x3, [x23, #5040]
    1e5c:	eb0102df 	cmp	x22, x1
    1e60:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1e64:	cb0002c1 	sub	x1, x22, x0
    1e68:	8b004060 	add	x0, x3, x0, lsl #16
    1e6c:	d370bc21 	lsl	x1, x1, #16
    1e70:	97fffe20 	bl	16f0 <mprotect@plt>
    1e74:	35000740 	cbnz	w0, 1f5c <fwp_heap_chunks+0x1cc>
    1e78:	528003c0 	mov	w0, #0x1e                  	// #30
    1e7c:	97fffe09 	bl	16a0 <sysconf@plt>
    1e80:	f949f2e2 	ldr	x2, [x23, #5088]
    1e84:	cb0003e5 	neg	x5, x0
    1e88:	aa0003e4 	mov	x4, x0
    1e8c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e90:	f949fee0 	ldr	x0, [x23, #5112]
    1e94:	8b020843 	add	x3, x2, x2, lsl #2
    1e98:	52800062 	mov	w2, #0x3                   	// #3
    1e9c:	8b010c01 	add	x1, x0, x1, lsl #3
    1ea0:	8b030c03 	add	x3, x0, x3, lsl #3
    1ea4:	d1000421 	sub	x1, x1, #0x1
    1ea8:	8a050060 	and	x0, x3, x5
    1eac:	8b040021 	add	x1, x1, x4
    1eb0:	8a050021 	and	x1, x1, x5
    1eb4:	cb000021 	sub	x1, x1, x0
    1eb8:	97fffe0e 	bl	16f0 <mprotect@plt>
    1ebc:	35000500 	cbnz	w0, 1f5c <fwp_heap_chunks+0x1cc>
    1ec0:	f909f2f6 	str	x22, [x23, #5088]
    1ec4:	9114c2b5 	add	x21, x21, #0x530
    1ec8:	d370be60 	lsl	x0, x19, #16
    1ecc:	f949e6a1 	ldr	x1, [x21, #5064]
    1ed0:	f909eeb3 	str	x19, [x21, #5080]
    1ed4:	eb01001f 	cmp	x0, x1
    1ed8:	540000e8 	b.hi	1ef4 <fwp_heap_chunks+0x164>  // b.pmore
    1edc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1ee0:	aa1403e0 	mov	x0, x20
    1ee4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ee8:	f9401bf7 	ldr	x23, [sp, #48]
    1eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ef0:	d65f03c0 	ret
    1ef4:	f9401bf7 	ldr	x23, [sp, #48]
    1ef8:	f909e6a0 	str	x0, [x21, #5064]
    1efc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1f00:	aa1403e0 	mov	x0, x20
    1f04:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f08:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1f0c:	d65f03c0 	ret
    1f10:	9114c2b5 	add	x21, x21, #0x530
    1f14:	91000441 	add	x1, x2, #0x1
    1f18:	f90000a1 	str	x1, [x5]
    1f1c:	cb040054 	sub	x20, x2, x4
    1f20:	f94a1aa1 	ldr	x1, [x21, #5168]
    1f24:	cb000020 	sub	x0, x1, x0
    1f28:	f90a1aa0 	str	x0, [x21, #5168]
    1f2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1f30:	aa1403e0 	mov	x0, x20
    1f34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f38:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1f3c:	d65f03c0 	ret
    1f40:	f949f422 	ldr	x2, [x1, #5096]
    1f44:	b0000185 	adrp	x5, 32000 <fwp_heap+0xad0>
    1f48:	912460a5 	add	x5, x5, #0x918
    1f4c:	17ffff9c 	b	1dbc <fwp_heap_chunks+0x2c>
    1f50:	d2800004 	mov	x4, #0x0                   	// #0
    1f54:	f9001bf7 	str	x23, [sp, #48]
    1f58:	17ffffb3 	b	1e24 <fwp_heap_chunks+0x94>
    1f5c:	97ffff7d 	bl	1d50 <fwp_heap_oom>

0000000000001f60 <ad_raw_fail>:
    1f60:	d00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x132b8>
    1f64:	f947e884 	ldr	x4, [x4, #4048]
    1f68:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1f6c:	aa0003e3 	mov	x3, x0
    1f70:	910003fd 	mov	x29, sp
    1f74:	f9400080 	ldr	x0, [x4]
    1f78:	b0000042 	adrp	x2, a000 <__divti3+0x2e0>
    1f7c:	91118042 	add	x2, x2, #0x460
    1f80:	52800041 	mov	w1, #0x2                   	// #2
    1f84:	97fffd8f 	bl	15c0 <__fprintf_chk@plt>
    1f88:	52801d00 	mov	w0, #0xe8                  	// #232
    1f8c:	97fffd1d 	bl	1400 <exit@plt>

0000000000001f90 <ad_raw_report>:
    1f90:	d101c3ff 	sub	sp, sp, #0x70
    1f94:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f98:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x132b8>
    1f9c:	f947f463 	ldr	x3, [x3, #4072]
    1fa0:	b0000042 	adrp	x2, a000 <__divti3+0x2e0>
    1fa4:	a9037bfd 	stp	x29, x30, [sp, #48]
    1fa8:	9100c3fd 	add	x29, sp, #0x30
    1fac:	91124042 	add	x2, x2, #0x490
    1fb0:	d2800005 	mov	x5, #0x0                   	// #0
    1fb4:	a9055bf5 	stp	x21, x22, [sp, #80]
    1fb8:	b0000056 	adrp	x22, a000 <__divti3+0x2e0>
    1fbc:	9113c2d6 	add	x22, x22, #0x4f0
    1fc0:	d00000f5 	adrp	x21, 1f000 <__FRAME_END__+0x132b8>
    1fc4:	f947eab5 	ldr	x21, [x21, #4048]
    1fc8:	a90453f3 	stp	x19, x20, [sp, #64]
    1fcc:	52800013 	mov	w19, #0x0                   	// #0
    1fd0:	f94002a0 	ldr	x0, [x21]
    1fd4:	f90033f7 	str	x23, [sp, #96]
    1fd8:	b0000057 	adrp	x23, a000 <__divti3+0x2e0>
    1fdc:	911222f7 	add	x23, x23, #0x488
    1fe0:	f9400064 	ldr	x4, [x3]
    1fe4:	f90017e4 	str	x4, [sp, #40]
    1fe8:	d2800004 	mov	x4, #0x0                   	// #0
    1fec:	d2800003 	mov	x3, #0x0                   	// #0
    1ff0:	f9403824 	ldr	x4, [x1, #112]
    1ff4:	52800041 	mov	w1, #0x2                   	// #2
    1ff8:	97fffd72 	bl	15c0 <__fprintf_chk@plt>
    1ffc:	f00000e1 	adrp	x1, 20000 <__data_start>
    2000:	91004021 	add	x1, x1, #0x10
    2004:	f94002a0 	ldr	x0, [x21]
    2008:	910023e2 	add	x2, sp, #0x8
    200c:	4c40a020 	ld1	{v0.16b-v1.16b}, [x1]
    2010:	90000043 	adrp	x3, a000 <__divti3+0x2e0>
    2014:	aa0203f4 	mov	x20, x2
    2018:	91120063 	add	x3, x3, #0x480
    201c:	4c00a040 	st1	{v0.16b-v1.16b}, [x2]
    2020:	aa1603e2 	mov	x2, x22
    2024:	f8408684 	ldr	x4, [x20], #8
    2028:	d2800007 	mov	x7, #0x0                   	// #0
    202c:	d2800006 	mov	x6, #0x0                   	// #0
    2030:	d2800005 	mov	x5, #0x0                   	// #0
    2034:	52800041 	mov	w1, #0x2                   	// #2
    2038:	11000673 	add	w19, w19, #0x1
    203c:	97fffd61 	bl	15c0 <__fprintf_chk@plt>
    2040:	7100127f 	cmp	w19, #0x4
    2044:	54000080 	b.eq	2054 <ad_raw_report+0xc4>  // b.none
    2048:	f94002a0 	ldr	x0, [x21]
    204c:	aa1703e3 	mov	x3, x23
    2050:	17fffff4 	b	2020 <ad_raw_report+0x90>
    2054:	f94002a3 	ldr	x3, [x21]
    2058:	d2800262 	mov	x2, #0x13                  	// #19
    205c:	d2800021 	mov	x1, #0x1                   	// #1
    2060:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    2064:	9114c000 	add	x0, x0, #0x530
    2068:	97fffd7a 	bl	1650 <fwrite@plt>
    206c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    2070:	f947f400 	ldr	x0, [x0, #4072]
    2074:	f94017e2 	ldr	x2, [sp, #40]
    2078:	f9400001 	ldr	x1, [x0]
    207c:	eb010042 	subs	x2, x2, x1
    2080:	d2800001 	mov	x1, #0x0                   	// #0
    2084:	54000181 	b.ne	20b4 <ad_raw_report+0x124>  // b.any
    2088:	f94002a3 	ldr	x3, [x21]
    208c:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    2090:	a9437bfd 	ldp	x29, x30, [sp, #48]
    2094:	91152000 	add	x0, x0, #0x548
    2098:	a94453f3 	ldp	x19, x20, [sp, #64]
    209c:	d2800082 	mov	x2, #0x4                   	// #4
    20a0:	a9455bf5 	ldp	x21, x22, [sp, #80]
    20a4:	d2800021 	mov	x1, #0x1                   	// #1
    20a8:	f94033f7 	ldr	x23, [sp, #96]
    20ac:	9101c3ff 	add	sp, sp, #0x70
    20b0:	17fffd68 	b	1650 <fwrite@plt>
    20b4:	97fffd27 	bl	1550 <__stack_chk_fail@plt>
    20b8:	d503201f 	nop
    20bc:	d503201f 	nop

00000000000020c0 <buf_grow>:
    20c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    20c4:	910003fd 	mov	x29, sp
    20c8:	a90153f3 	stp	x19, x20, [sp, #16]
    20cc:	aa0003f4 	mov	x20, x0
    20d0:	f9400400 	ldr	x0, [x0, #8]
    20d4:	b100041f 	cmn	x0, #0x1
    20d8:	54000400 	b.eq	2158 <buf_grow+0x98>  // b.none
    20dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    20e0:	cb000042 	sub	x2, x2, x0
    20e4:	eb01005f 	cmp	x2, x1
    20e8:	54000383 	b.cc	2158 <buf_grow+0x98>  // b.lo, b.ul, b.last
    20ec:	f9400a82 	ldr	x2, [x20, #16]
    20f0:	91000421 	add	x1, x1, #0x1
    20f4:	8b000033 	add	x19, x1, x0
    20f8:	eb13005f 	cmp	x2, x19
    20fc:	54000242 	b.cs	2144 <buf_grow+0x84>  // b.hs, b.nlast
    2100:	f100005f 	cmp	x2, #0x0
    2104:	b5000262 	cbnz	x2, 2150 <buf_grow+0x90>
    2108:	d2800802 	mov	x2, #0x40                  	// #64
    210c:	eb02027f 	cmp	x19, x2
    2110:	54000068 	b.hi	211c <buf_grow+0x5c>  // b.pmore
    2114:	14000005 	b	2128 <buf_grow+0x68>
    2118:	b7f800a2 	tbnz	x2, #63, 212c <buf_grow+0x6c>
    211c:	d37ff842 	lsl	x2, x2, #1
    2120:	eb02027f 	cmp	x19, x2
    2124:	54ffffa8 	b.hi	2118 <buf_grow+0x58>  // b.pmore
    2128:	aa0203f3 	mov	x19, x2
    212c:	f9400280 	ldr	x0, [x20]
    2130:	aa1303e1 	mov	x1, x19
    2134:	97fffd03 	bl	1540 <realloc@plt>
    2138:	b4000100 	cbz	x0, 2158 <buf_grow+0x98>
    213c:	f9000280 	str	x0, [x20]
    2140:	f9000a93 	str	x19, [x20, #16]
    2144:	a94153f3 	ldp	x19, x20, [sp, #16]
    2148:	a8c27bfd 	ldp	x29, x30, [sp], #32
    214c:	d65f03c0 	ret
    2150:	54fffe6a 	b.ge	211c <buf_grow+0x5c>  // b.tcont
    2154:	17fffff6 	b	212c <buf_grow+0x6c>
    2158:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x132b8>
    215c:	f947e863 	ldr	x3, [x3, #4048]
    2160:	d2800262 	mov	x2, #0x13                  	// #19
    2164:	d2800021 	mov	x1, #0x1                   	// #1
    2168:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    216c:	91112000 	add	x0, x0, #0x448
    2170:	f9400063 	ldr	x3, [x3]
    2174:	97fffd37 	bl	1650 <fwrite@plt>
    2178:	d2800000 	mov	x0, #0x0                   	// #0
    217c:	97fffd41 	bl	1680 <fflush@plt>
    2180:	52800cc0 	mov	w0, #0x66                  	// #102
    2184:	97fffd4f 	bl	16c0 <_Exit@plt>
    2188:	d503201f 	nop
    218c:	d503201f 	nop

0000000000002190 <buf_put>:
    2190:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2194:	910003fd 	mov	x29, sp
    2198:	a90153f3 	stp	x19, x20, [sp, #16]
    219c:	aa0003f4 	mov	x20, x0
    21a0:	aa0203f3 	mov	x19, x2
    21a4:	f90013f5 	str	x21, [sp, #32]
    21a8:	aa0103f5 	mov	x21, x1
    21ac:	aa0203e1 	mov	x1, x2
    21b0:	97ffffc4 	bl	20c0 <buf_grow>
    21b4:	a9400283 	ldp	x3, x0, [x20]
    21b8:	aa1503e1 	mov	x1, x21
    21bc:	aa1303e2 	mov	x2, x19
    21c0:	8b000060 	add	x0, x3, x0
    21c4:	97fffc7b 	bl	13b0 <memcpy@plt>
    21c8:	a9400680 	ldp	x0, x1, [x20]
    21cc:	8b010273 	add	x19, x19, x1
    21d0:	f9000693 	str	x19, [x20, #8]
    21d4:	3833681f 	strb	wzr, [x0, x19]
    21d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    21dc:	f94013f5 	ldr	x21, [sp, #32]
    21e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    21e4:	d65f03c0 	ret
    21e8:	d503201f 	nop
    21ec:	d503201f 	nop

00000000000021f0 <fwp_cancel_tree.part.0>:
    21f0:	d00000e1 	adrp	x1, 20000 <__data_start>
    21f4:	91014022 	add	x2, x1, #0x50
    21f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    21fc:	52800023 	mov	w3, #0x1                   	// #1
    2200:	910003fd 	mov	x29, sp
    2204:	f9400444 	ldr	x4, [x2, #8]
    2208:	f9000bf3 	str	x19, [sp, #16]
    220c:	39014403 	strb	w3, [x0, #81]
    2210:	eb04001f 	cmp	x0, x4
    2214:	54000160 	b.eq	2240 <fwp_cancel_tree.part.0+0x50>  // b.none
    2218:	f9402804 	ldr	x4, [x0, #80]
    221c:	f2001c9f 	tst	x4, #0xff000000ff
    2220:	54000101 	b.ne	2240 <fwp_cancel_tree.part.0+0x50>  // b.any
    2224:	f9401444 	ldr	x4, [x2, #40]
    2228:	39015003 	strb	w3, [x0, #84]
    222c:	f900801f 	str	xzr, [x0, #256]
    2230:	b40001e4 	cbz	x4, 226c <fwp_cancel_tree.part.0+0x7c>
    2234:	f9008080 	str	x0, [x4, #256]
    2238:	91014021 	add	x1, x1, #0x50
    223c:	f9001420 	str	x0, [x1, #40]
    2240:	f9401413 	ldr	x19, [x0, #40]
    2244:	b40000f3 	cbz	x19, 2260 <fwp_cancel_tree.part.0+0x70>
    2248:	39414261 	ldrb	w1, [x19, #80]
    224c:	aa1303e0 	mov	x0, x19
    2250:	37000041 	tbnz	w1, #0, 2258 <fwp_cancel_tree.part.0+0x68>
    2254:	97ffffe7 	bl	21f0 <fwp_cancel_tree.part.0>
    2258:	f9401a73 	ldr	x19, [x19, #48]
    225c:	b5ffff73 	cbnz	x19, 2248 <fwp_cancel_tree.part.0+0x58>
    2260:	f9400bf3 	ldr	x19, [sp, #16]
    2264:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2268:	d65f03c0 	ret
    226c:	f9001840 	str	x0, [x2, #48]
    2270:	17fffff2 	b	2238 <fwp_cancel_tree.part.0+0x48>

0000000000002274 <fwp_finish_float>:
    2274:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2278:	528005c1 	mov	w1, #0x2e                  	// #46
    227c:	910003fd 	mov	x29, sp
    2280:	f9000bf3 	str	x19, [sp, #16]
    2284:	aa0003f3 	mov	x19, x0
    2288:	97fffcea 	bl	1630 <strchr@plt>
    228c:	b4000080 	cbz	x0, 229c <fwp_finish_float+0x28>
    2290:	f9400bf3 	ldr	x19, [sp, #16]
    2294:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2298:	d65f03c0 	ret
    229c:	aa1303e0 	mov	x0, x19
    22a0:	52800ca1 	mov	w1, #0x65                  	// #101
    22a4:	97fffce3 	bl	1630 <strchr@plt>
    22a8:	b5ffff40 	cbnz	x0, 2290 <fwp_finish_float+0x1c>
    22ac:	90000041 	adrp	x1, a000 <__divti3+0x2e0>
    22b0:	aa1303e0 	mov	x0, x19
    22b4:	91154021 	add	x1, x1, #0x550
    22b8:	97fffcfe 	bl	16b0 <strstr@plt>
    22bc:	b5fffea0 	cbnz	x0, 2290 <fwp_finish_float+0x1c>
    22c0:	90000041 	adrp	x1, a000 <__divti3+0x2e0>
    22c4:	aa1303e0 	mov	x0, x19
    22c8:	91156021 	add	x1, x1, #0x558
    22cc:	97fffcf9 	bl	16b0 <strstr@plt>
    22d0:	b5fffe00 	cbnz	x0, 2290 <fwp_finish_float+0x1c>
    22d4:	aa1303e0 	mov	x0, x19
    22d8:	97fffc42 	bl	13e0 <strlen@plt>
    22dc:	90000041 	adrp	x1, a000 <__divti3+0x2e0>
    22e0:	91158021 	add	x1, x1, #0x560
    22e4:	8b000262 	add	x2, x19, x0
    22e8:	79400023 	ldrh	w3, [x1]
    22ec:	39400821 	ldrb	w1, [x1, #2]
    22f0:	78206a63 	strh	w3, [x19, x0]
    22f4:	39000841 	strb	w1, [x2, #2]
    22f8:	17ffffe6 	b	2290 <fwp_finish_float+0x1c>
    22fc:	d503201f 	nop

0000000000002300 <fwp_trap>:
    2300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2304:	910003fd 	mov	x29, sp
    2308:	f9000bf3 	str	x19, [sp, #16]
    230c:	aa0003f3 	mov	x19, x0
    2310:	97fffe50 	bl	1c50 <fwp_flush>
    2314:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x132b8>
    2318:	f947e884 	ldr	x4, [x4, #4048]
    231c:	aa1303e3 	mov	x3, x19
    2320:	90000042 	adrp	x2, a000 <__divti3+0x2e0>
    2324:	9115a042 	add	x2, x2, #0x568
    2328:	52800041 	mov	w1, #0x2                   	// #2
    232c:	f9400080 	ldr	x0, [x4]
    2330:	97fffca4 	bl	15c0 <__fprintf_chk@plt>
    2334:	52800ca0 	mov	w0, #0x65                  	// #101
    2338:	97fffc32 	bl	1400 <exit@plt>
    233c:	d503201f 	nop

0000000000002340 <fwp_now_ns>:
    2340:	d100c3ff 	sub	sp, sp, #0x30
    2344:	52800020 	mov	w0, #0x1                   	// #1
    2348:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x132b8>
    234c:	f947f442 	ldr	x2, [x2, #4072]
    2350:	910023e1 	add	x1, sp, #0x8
    2354:	a9027bfd 	stp	x29, x30, [sp, #32]
    2358:	910083fd 	add	x29, sp, #0x20
    235c:	f9400043 	ldr	x3, [x2]
    2360:	f9000fe3 	str	x3, [sp, #24]
    2364:	d2800003 	mov	x3, #0x0                   	// #0
    2368:	97fffc46 	bl	1480 <clock_gettime@plt>
    236c:	350002c0 	cbnz	w0, 23c4 <fwp_now_ns+0x84>
    2370:	a9408be1 	ldp	x1, x2, [sp, #8]
    2374:	d2994003 	mov	x3, #0xca00                	// #51712
    2378:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    237c:	9b037c20 	mul	x0, x1, x3
    2380:	9b437c21 	smulh	x1, x1, x3
    2384:	ab020000 	adds	x0, x0, x2
    2388:	937ffc42 	asr	x2, x2, #63
    238c:	9a020021 	adc	x1, x1, x2
    2390:	f100001f 	cmp	x0, #0x0
    2394:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2398:	b50001e1 	cbnz	x1, 23d4 <fwp_now_ns+0x94>
    239c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x132b8>
    23a0:	f947f421 	ldr	x1, [x1, #4072]
    23a4:	f9400fe3 	ldr	x3, [sp, #24]
    23a8:	f9400022 	ldr	x2, [x1]
    23ac:	eb020063 	subs	x3, x3, x2
    23b0:	d2800002 	mov	x2, #0x0                   	// #0
    23b4:	540000e1 	b.ne	23d0 <fwp_now_ns+0x90>  // b.any
    23b8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    23bc:	9100c3ff 	add	sp, sp, #0x30
    23c0:	d65f03c0 	ret
    23c4:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    23c8:	9115e000 	add	x0, x0, #0x578
    23cc:	97ffffcd 	bl	2300 <fwp_trap>
    23d0:	97fffc60 	bl	1550 <__stack_chk_fail@plt>
    23d4:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    23d8:	91166000 	add	x0, x0, #0x598
    23dc:	97ffffc9 	bl	2300 <fwp_trap>

00000000000023e0 <fwp_args74>:
    23e0:	d65f03c0 	ret

00000000000023e4 <fwp_format_g.constprop.0>:
    23e4:	d10483ff 	sub	sp, sp, #0x120
    23e8:	90000044 	adrp	x4, a000 <__divti3+0x2e0>
    23ec:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x132b8>
    23f0:	f947f442 	ldr	x2, [x2, #4072]
    23f4:	91170084 	add	x4, x4, #0x5c0
    23f8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    23fc:	9102c3fd 	add	x29, sp, #0xb0
    2400:	d2800803 	mov	x3, #0x40                  	// #64
    2404:	a90e63f7 	stp	x23, x24, [sp, #224]
    2408:	93407c38 	sxtw	x24, w1
    240c:	aa0303e1 	mov	x1, x3
    2410:	fd008be8 	str	d8, [sp, #272]
    2414:	1e604008 	fmov	d8, d0
    2418:	a90c53f3 	stp	x19, x20, [sp, #192]
    241c:	910083f4 	add	x20, sp, #0x20
    2420:	a90d5bf5 	stp	x21, x22, [sp, #208]
    2424:	aa0003f5 	mov	x21, x0
    2428:	a91073fb 	stp	x27, x28, [sp, #256]
    242c:	5100071c 	sub	w28, w24, #0x1
    2430:	2a1c03e5 	mov	w5, w28
    2434:	f9400040 	ldr	x0, [x2]
    2438:	f90057e0 	str	x0, [sp, #168]
    243c:	d2800000 	mov	x0, #0x0                   	// #0
    2440:	52800042 	mov	w2, #0x2                   	// #2
    2444:	aa1403e0 	mov	x0, x20
    2448:	97fffc1e 	bl	14c0 <__snprintf_chk@plt>
    244c:	52800ca1 	mov	w1, #0x65                  	// #101
    2450:	aa1403e0 	mov	x0, x20
    2454:	97fffc77 	bl	1630 <strchr@plt>
    2458:	aa0003f3 	mov	x19, x0
    245c:	52800142 	mov	w2, #0xa                   	// #10
    2460:	91000400 	add	x0, x0, #0x1
    2464:	d2800001 	mov	x1, #0x0                   	// #0
    2468:	97fffc62 	bl	15f0 <strtol@plt>
    246c:	aa0003f7 	mov	x23, x0
    2470:	11001400 	add	w0, w0, #0x5
    2474:	7100541f 	cmp	w0, #0x15
    2478:	54000d88 	b.hi	2628 <fwp_format_g.constprop.0+0x244>  // b.pmore
    247c:	4b170385 	sub	w5, w28, w23
    2480:	710000bf 	cmp	w5, #0x0
    2484:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2488:	54000ba0 	b.eq	25fc <fwp_format_g.constprop.0+0x218>  // b.none
    248c:	394083e0 	ldrb	w0, [sp, #32]
    2490:	cb180273 	sub	x19, x19, x24
    2494:	91000673 	add	x19, x19, #0x1
    2498:	a90f6bf9 	stp	x25, x26, [sp, #240]
    249c:	7100b41f 	cmp	w0, #0x2d
    24a0:	9a941681 	cinc	x1, x20, eq	// eq = none
    24a4:	1a9f17e4 	cset	w4, eq	// eq = none
    24a8:	cb010266 	sub	x6, x19, x1
    24ac:	d10004da 	sub	x26, x6, #0x1
    24b0:	540018c0 	b.eq	27c8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    24b4:	910183f9 	add	x25, sp, #0x60
    24b8:	d280091b 	mov	x27, #0x48                  	// #72
    24bc:	aa1903e7 	mov	x7, x25
    24c0:	91000423 	add	x3, x1, #0x1
    24c4:	91011cc6 	add	x6, x6, #0x47
    24c8:	910004f6 	add	x22, x7, #0x1
    24cc:	37f81017 	tbnz	w23, #31, 26cc <fwp_format_g.constprop.0+0x2e8>
    24d0:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    24d4:	93407ef7 	sxtw	x23, w23
    24d8:	390000e4 	strb	w4, [x7]
    24dc:	aa1303e1 	mov	x1, x19
    24e0:	aa1703e2 	mov	x2, x23
    24e4:	aa1603e0 	mov	x0, x22
    24e8:	b9000be5 	str	w5, [sp, #8]
    24ec:	cb170374 	sub	x20, x27, x23
    24f0:	a9011be3 	stp	x3, x6, [sp, #16]
    24f4:	97fffbaf 	bl	13b0 <memcpy@plt>
    24f8:	d1000694 	sub	x20, x20, #0x1
    24fc:	f9400be3 	ldr	x3, [sp, #16]
    2500:	8b1702d6 	add	x22, x22, x23
    2504:	aa1603e0 	mov	x0, x22
    2508:	aa1a03e2 	mov	x2, x26
    250c:	aa0303e1 	mov	x1, x3
    2510:	aa1403e3 	mov	x3, x20
    2514:	97fffbe3 	bl	14a0 <__memcpy_chk@plt>
    2518:	8b1a02d6 	add	x22, x22, x26
    251c:	f9400fe6 	ldr	x6, [sp, #24]
    2520:	d2800900 	mov	x0, #0x48                  	// #72
    2524:	b9400be5 	ldr	w5, [sp, #8]
    2528:	8b170261 	add	x1, x19, x23
    252c:	cb1400c3 	sub	x3, x6, x20
    2530:	cb060294 	sub	x20, x20, x6
    2534:	f101207f 	cmp	x3, #0x48
    2538:	93407cb8 	sxtw	x24, w5
    253c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2540:	aa1803e2 	mov	x2, x24
    2544:	8b1802d3 	add	x19, x22, x24
    2548:	8b140063 	add	x3, x3, x20
    254c:	aa1603e0 	mov	x0, x22
    2550:	97fffbd4 	bl	14a0 <__memcpy_chk@plt>
    2554:	cb190273 	sub	x19, x19, x25
    2558:	d28031e0 	mov	x0, #0x18f                 	// #399
    255c:	eb00027f 	cmp	x19, x0
    2560:	aa1903e1 	mov	x1, x25
    2564:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    2568:	aa1503e0 	mov	x0, x21
    256c:	aa1303e2 	mov	x2, x19
    2570:	97fffb90 	bl	13b0 <memcpy@plt>
    2574:	38336abf 	strb	wzr, [x21, x19]
    2578:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    257c:	aa1503e0 	mov	x0, x21
    2580:	97fffb98 	bl	13e0 <strlen@plt>
    2584:	aa0003f3 	mov	x19, x0
    2588:	528005c1 	mov	w1, #0x2e                  	// #46
    258c:	aa1503e0 	mov	x0, x21
    2590:	97fffc28 	bl	1630 <strchr@plt>
    2594:	b4000160 	cbz	x0, 25c0 <fwp_format_g.constprop.0+0x1dc>
    2598:	b4000153 	cbz	x19, 25c0 <fwp_format_g.constprop.0+0x1dc>
    259c:	d503201f 	nop
    25a0:	aa1303e1 	mov	x1, x19
    25a4:	d1000673 	sub	x19, x19, #0x1
    25a8:	38736aa0 	ldrb	w0, [x21, x19]
    25ac:	7100c01f 	cmp	w0, #0x30
    25b0:	54001001 	b.ne	27b0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    25b4:	38336abf 	strb	wzr, [x21, x19]
    25b8:	b5ffff53 	cbnz	x19, 25a0 <fwp_format_g.constprop.0+0x1bc>
    25bc:	d503201f 	nop
    25c0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    25c4:	f947f400 	ldr	x0, [x0, #4072]
    25c8:	f94057e2 	ldr	x2, [sp, #168]
    25cc:	f9400001 	ldr	x1, [x0]
    25d0:	eb010042 	subs	x2, x2, x1
    25d4:	d2800001 	mov	x1, #0x0                   	// #0
    25d8:	54001061 	b.ne	27e4 <fwp_format_g.constprop.0+0x400>  // b.any
    25dc:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    25e0:	a94c53f3 	ldp	x19, x20, [sp, #192]
    25e4:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    25e8:	a94e63f7 	ldp	x23, x24, [sp, #224]
    25ec:	a95073fb 	ldp	x27, x28, [sp, #256]
    25f0:	fd408be8 	ldr	d8, [sp, #272]
    25f4:	910483ff 	add	sp, sp, #0x120
    25f8:	d65f03c0 	ret
    25fc:	1e604100 	fmov	d0, d8
    2600:	710000bf 	cmp	w5, #0x0
    2604:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2608:	aa1503e0 	mov	x0, x21
    260c:	90000044 	adrp	x4, a000 <__divti3+0x2e0>
    2610:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2614:	91176084 	add	x4, x4, #0x5d8
    2618:	52800042 	mov	w2, #0x2                   	// #2
    261c:	d2803201 	mov	x1, #0x190                 	// #400
    2620:	97fffba8 	bl	14c0 <__snprintf_chk@plt>
    2624:	17ffffd6 	b	257c <fwp_format_g.constprop.0+0x198>
    2628:	cb140273 	sub	x19, x19, x20
    262c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2630:	910183f9 	add	x25, sp, #0x60
    2634:	aa1303e2 	mov	x2, x19
    2638:	aa1403e1 	mov	x1, x20
    263c:	aa1903e0 	mov	x0, x25
    2640:	d2800803 	mov	x3, #0x40                  	// #64
    2644:	97fffb97 	bl	14a0 <__memcpy_chk@plt>
    2648:	38336b3f 	strb	wzr, [x25, x19]
    264c:	aa1903e0 	mov	x0, x25
    2650:	528005c1 	mov	w1, #0x2e                  	// #46
    2654:	97fffbf7 	bl	1630 <strchr@plt>
    2658:	b40001c0 	cbz	x0, 2690 <fwp_format_g.constprop.0+0x2ac>
    265c:	b50000b3 	cbnz	x19, 2670 <fwp_format_g.constprop.0+0x28c>
    2660:	1400000c 	b	2690 <fwp_format_g.constprop.0+0x2ac>
    2664:	381ff01f 	sturb	wzr, [x0, #-1]
    2668:	f1000673 	subs	x19, x19, #0x1
    266c:	54000120 	b.eq	2690 <fwp_format_g.constprop.0+0x2ac>  // b.none
    2670:	8b130320 	add	x0, x25, x19
    2674:	385ff001 	ldurb	w1, [x0, #-1]
    2678:	7100c03f 	cmp	w1, #0x30
    267c:	54ffff40 	b.eq	2664 <fwp_format_g.constprop.0+0x280>  // b.none
    2680:	d1000673 	sub	x19, x19, #0x1
    2684:	38736b20 	ldrb	w0, [x25, x19]
    2688:	7100b81f 	cmp	w0, #0x2e
    268c:	54000a80 	b.eq	27dc <fwp_format_g.constprop.0+0x3f8>  // b.none
    2690:	710002ff 	cmp	w23, #0x0
    2694:	528005a1 	mov	w1, #0x2d                  	// #45
    2698:	aa1903e5 	mov	x5, x25
    269c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    26a0:	aa1503e0 	mov	x0, x21
    26a4:	52800566 	mov	w6, #0x2b                  	// #43
    26a8:	90000044 	adrp	x4, a000 <__divti3+0x2e0>
    26ac:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    26b0:	91172084 	add	x4, x4, #0x5c8
    26b4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    26b8:	52800042 	mov	w2, #0x2                   	// #2
    26bc:	d2803201 	mov	x1, #0x190                 	// #400
    26c0:	97fffb80 	bl	14c0 <__snprintf_chk@plt>
    26c4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    26c8:	17ffffbe 	b	25c0 <fwp_format_g.constprop.0+0x1dc>
    26cc:	52800605 	mov	w5, #0x30                  	// #48
    26d0:	390000e5 	strb	w5, [x7]
    26d4:	d100077b 	sub	x27, x27, #0x1
    26d8:	aa0303e1 	mov	x1, x3
    26dc:	aa1603e0 	mov	x0, x22
    26e0:	aa1b03e3 	mov	x3, x27
    26e4:	aa1a03e2 	mov	x2, x26
    26e8:	f90007e6 	str	x6, [sp, #8]
    26ec:	b90013e4 	str	w4, [sp, #16]
    26f0:	8b1a02d6 	add	x22, x22, x26
    26f4:	b9001be5 	str	w5, [sp, #24]
    26f8:	97fffb6a 	bl	14a0 <__memcpy_chk@plt>
    26fc:	f94007e6 	ldr	x6, [sp, #8]
    2700:	2a3703e7 	mvn	w7, w23
    2704:	b94013e4 	ldr	w4, [sp, #16]
    2708:	cb1b00c1 	sub	x1, x6, x27
    270c:	cb06037b 	sub	x27, x27, x6
    2710:	f101203f 	cmp	x1, #0x48
    2714:	d2800906 	mov	x6, #0x48                  	// #72
    2718:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    271c:	8b1b0023 	add	x3, x1, x27
    2720:	310006ff 	cmn	w23, #0x1
    2724:	54000220 	b.eq	2768 <fwp_format_g.constprop.0+0x384>  // b.none
    2728:	b9401be5 	ldr	w5, [sp, #24]
    272c:	d2800001 	mov	x1, #0x0                   	// #0
    2730:	f101207f 	cmp	x3, #0x48
    2734:	d1000462 	sub	x2, x3, #0x1
    2738:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    273c:	38216ac5 	strb	w5, [x22, x1]
    2740:	cb030003 	sub	x3, x0, x3
    2744:	91000421 	add	x1, x1, #0x1
    2748:	91000463 	add	x3, x3, #0x1
    274c:	eb00007f 	cmp	x3, x0
    2750:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2754:	cb000063 	sub	x3, x3, x0
    2758:	8b020063 	add	x3, x3, x2
    275c:	6b0100ff 	cmp	w7, w1
    2760:	54fffe8c 	b.gt	2730 <fwp_format_g.constprop.0+0x34c>
    2764:	8b2742d6 	add	x22, x22, w7, uxtw
    2768:	f101207f 	cmp	x3, #0x48
    276c:	d2800905 	mov	x5, #0x48                  	// #72
    2770:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    2774:	aa1603e0 	mov	x0, x22
    2778:	cb0300a1 	sub	x1, x5, x3
    277c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    2780:	91000421 	add	x1, x1, #0x1
    2784:	d1000463 	sub	x3, x3, #0x1
    2788:	eb05003f 	cmp	x1, x5
    278c:	38001402 	strb	w2, [x0], #1
    2790:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    2794:	93407f82 	sxtw	x2, w28
    2798:	cb050025 	sub	x5, x1, x5
    279c:	aa1303e1 	mov	x1, x19
    27a0:	8b0300a3 	add	x3, x5, x3
    27a4:	8b1802d3 	add	x19, x22, x24
    27a8:	97fffb3e 	bl	14a0 <__memcpy_chk@plt>
    27ac:	17ffff6a 	b	2554 <fwp_format_g.constprop.0+0x170>
    27b0:	d1000421 	sub	x1, x1, #0x1
    27b4:	38616aa0 	ldrb	w0, [x21, x1]
    27b8:	7100b81f 	cmp	w0, #0x2e
    27bc:	54fff021 	b.ne	25c0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    27c0:	38216abf 	strb	wzr, [x21, x1]
    27c4:	17ffff7f 	b	25c0 <fwp_format_g.constprop.0+0x1dc>
    27c8:	910187e7 	add	x7, sp, #0x61
    27cc:	910183f9 	add	x25, sp, #0x60
    27d0:	d28008fb 	mov	x27, #0x47                  	// #71
    27d4:	390183e0 	strb	w0, [sp, #96]
    27d8:	17ffff3a 	b	24c0 <fwp_format_g.constprop.0+0xdc>
    27dc:	38336b3f 	strb	wzr, [x25, x19]
    27e0:	17ffffac 	b	2690 <fwp_format_g.constprop.0+0x2ac>
    27e4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    27e8:	97fffb5a 	bl	1550 <__stack_chk_fail@plt>
    27ec:	d503201f 	nop

00000000000027f0 <fwp_heap_report>:
    27f0:	d105c3ff 	sub	sp, sp, #0x170
    27f4:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    27f8:	9114c042 	add	x2, x2, #0x530
    27fc:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x132b8>
    2800:	f947e821 	ldr	x1, [x1, #4048]
    2804:	a9117bfd 	stp	x29, x30, [sp, #272]
    2808:	910443fd 	add	x29, sp, #0x110
    280c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    2810:	f947f400 	ldr	x0, [x0, #4072]
    2814:	a9135bf5 	stp	x21, x22, [sp, #304]
    2818:	a91463f7 	stp	x23, x24, [sp, #320]
    281c:	a9156bf9 	stp	x25, x26, [sp, #336]
    2820:	6d1627e8 	stp	d8, d9, [sp, #352]
    2824:	fd4a1c48 	ldr	d8, [x2, #5176]
    2828:	fd4a2049 	ldr	d9, [x2, #5184]
    282c:	f9400036 	ldr	x22, [x1]
    2830:	f9400001 	ldr	x1, [x0]
    2834:	f90087e1 	str	x1, [sp, #264]
    2838:	d2800001 	mov	x1, #0x0                   	// #0
    283c:	f949e459 	ldr	x25, [x2, #5064]
    2840:	90000041 	adrp	x1, a000 <__divti3+0x2e0>
    2844:	f94a1057 	ldr	x23, [x2, #5152]
    2848:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    284c:	f94a1458 	ldr	x24, [x2, #5160]
    2850:	91178021 	add	x1, x1, #0x5e0
    2854:	9117a000 	add	x0, x0, #0x5e8
    2858:	97fffb22 	bl	14e0 <fopen@plt>
    285c:	b4000740 	cbz	x0, 2944 <fwp_heap_report+0x154>
    2860:	528daad5 	mov	w21, #0x6d56                	// #27990
    2864:	a91253f3 	stp	x19, x20, [sp, #288]
    2868:	aa0003f4 	mov	x20, x0
    286c:	910023f3 	add	x19, sp, #0x8
    2870:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2874:	72aae915 	movk	w21, #0x5748, lsl #16
    2878:	aa1403e2 	mov	x2, x20
    287c:	aa1303e0 	mov	x0, x19
    2880:	52802001 	mov	w1, #0x100                 	// #256
    2884:	97fffb9f 	bl	1700 <fgets@plt>
    2888:	b4000280 	cbz	x0, 28d8 <fwp_heap_report+0xe8>
    288c:	b9400261 	ldr	w1, [x19]
    2890:	6b15003f 	cmp	w1, w21
    2894:	54ffff21 	b.ne	2878 <fwp_heap_report+0x88>  // b.any
    2898:	39401260 	ldrb	w0, [x19, #4]
    289c:	7101341f 	cmp	w0, #0x4d
    28a0:	54fffec1 	b.ne	2878 <fwp_heap_report+0x88>  // b.any
    28a4:	394037e0 	ldrb	w0, [sp, #13]
    28a8:	7100e81f 	cmp	w0, #0x3a
    28ac:	54fffe61 	b.ne	2878 <fwp_heap_report+0x88>  // b.any
    28b0:	52800142 	mov	w2, #0xa                   	// #10
    28b4:	d2800001 	mov	x1, #0x0                   	// #0
    28b8:	91003be0 	add	x0, sp, #0xe
    28bc:	97fffb4d 	bl	15f0 <strtol@plt>
    28c0:	aa1403e2 	mov	x2, x20
    28c4:	aa0003fa 	mov	x26, x0
    28c8:	52802001 	mov	w1, #0x100                 	// #256
    28cc:	aa1303e0 	mov	x0, x19
    28d0:	97fffb8c 	bl	1700 <fgets@plt>
    28d4:	b5fffdc0 	cbnz	x0, 288c <fwp_heap_report+0x9c>
    28d8:	aa1403e0 	mov	x0, x20
    28dc:	97fffafd 	bl	14d0 <fclose@plt>
    28e0:	a95253f3 	ldp	x19, x20, [sp, #288]
    28e4:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    28e8:	f947f400 	ldr	x0, [x0, #4072]
    28ec:	f94087e2 	ldr	x2, [sp, #264]
    28f0:	f9400001 	ldr	x1, [x0]
    28f4:	eb010042 	subs	x2, x2, x1
    28f8:	d2800001 	mov	x1, #0x0                   	// #0
    28fc:	54000281 	b.ne	294c <fwp_heap_report+0x15c>  // b.any
    2900:	a9517bfd 	ldp	x29, x30, [sp, #272]
    2904:	aa1a03e6 	mov	x6, x26
    2908:	aa1903e5 	mov	x5, x25
    290c:	aa1803e4 	mov	x4, x24
    2910:	a9556bf9 	ldp	x25, x26, [sp, #336]
    2914:	aa1703e3 	mov	x3, x23
    2918:	a95463f7 	ldp	x23, x24, [sp, #320]
    291c:	aa1603e0 	mov	x0, x22
    2920:	a9535bf5 	ldp	x21, x22, [sp, #304]
    2924:	1e604121 	fmov	d1, d9
    2928:	1e604100 	fmov	d0, d8
    292c:	90000042 	adrp	x2, a000 <__divti3+0x2e0>
    2930:	6d5627e8 	ldp	d8, d9, [sp, #352]
    2934:	91182042 	add	x2, x2, #0x608
    2938:	9105c3ff 	add	sp, sp, #0x170
    293c:	52800041 	mov	w1, #0x2                   	// #2
    2940:	17fffb20 	b	15c0 <__fprintf_chk@plt>
    2944:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2948:	17ffffe7 	b	28e4 <fwp_heap_report+0xf4>
    294c:	a91253f3 	stp	x19, x20, [sp, #288]
    2950:	97fffb00 	bl	1550 <__stack_chk_fail@plt>

0000000000002954 <fwp_heap_init>:
    2954:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2958:	90000183 	adrp	x3, 32000 <fwp_heap+0xad0>
    295c:	9110c061 	add	x1, x3, #0x430
    2960:	910003fd 	mov	x29, sp
    2964:	a90153f3 	stp	x19, x20, [sp, #16]
    2968:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    296c:	9114c262 	add	x2, x19, #0x530
    2970:	a9025bf5 	stp	x21, x22, [sp, #32]
    2974:	52800024 	mov	w4, #0x1                   	// #1
    2978:	52800200 	mov	w0, #0x10                  	// #16
    297c:	b913a444 	str	w4, [x2, #5028]
    2980:	b8004420 	str	w0, [x1], #4
    2984:	11004000 	add	w0, w0, #0x10
    2988:	7104401f 	cmp	w0, #0x110
    298c:	54ffffa1 	b.ne	2980 <fwp_heap_init+0x2c>  // b.any
    2990:	90000042 	adrp	x2, a000 <__divti3+0x2e0>
    2994:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2998:	90000181 	adrp	x1, 32000 <fwp_heap+0xad0>
    299c:	9111c021 	add	x1, x1, #0x470
    29a0:	3dc2c843 	ldr	q3, [x2, #2848]
    29a4:	d2800000 	mov	x0, #0x0                   	// #0
    29a8:	4e040401 	dup	v1.4s, v0.s[0]
    29ac:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    29b0:	0f215400 	shl	v0.2s, v0.2s, #1
    29b4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    29b8:	3ca06821 	str	q1, [x1, x0]
    29bc:	91004000 	add	x0, x0, #0x10
    29c0:	f101801f 	cmp	x0, #0x60
    29c4:	54ffff21 	b.ne	29a8 <fwp_heap_init+0x54>  // b.any
    29c8:	90000184 	adrp	x4, 32000 <fwp_heap+0xad0>
    29cc:	9110c063 	add	x3, x3, #0x430
    29d0:	91134084 	add	x4, x4, #0x4d0
    29d4:	9114c266 	add	x6, x19, #0x530
    29d8:	d2800002 	mov	x2, #0x0                   	// #0
    29dc:	d2800000 	mov	x0, #0x0                   	// #0
    29e0:	d2880205 	mov	x5, #0x4010                	// #16400
    29e4:	d503201f 	nop
    29e8:	910f0001 	add	x1, x0, #0x3c0
    29ec:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    29f0:	eb02003f 	cmp	x1, x2
    29f4:	540000a2 	b.cs	2a08 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    29f8:	91000400 	add	x0, x0, #0x1
    29fc:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2a00:	eb02003f 	cmp	x1, x2
    2a04:	54ffffa3 	b.cc	29f8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    2a08:	91004042 	add	x2, x2, #0x10
    2a0c:	38001480 	strb	w0, [x4], #1
    2a10:	eb05005f 	cmp	x2, x5
    2a14:	54fffea1 	b.ne	29e8 <fwp_heap_init+0x94>  // b.any
    2a18:	528000b5 	mov	w21, #0x5                   	// #5
    2a1c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    2a20:	14000004 	b	2a30 <fwp_heap_init+0xdc>
    2a24:	d342fe94 	lsr	x20, x20, #2
    2a28:	710006b5 	subs	w21, w21, #0x1
    2a2c:	54000720 	b.eq	2b10 <fwp_heap_init+0x1bc>  // b.none
    2a30:	91404296 	add	x22, x20, #0x10, lsl #12
    2a34:	d2800005 	mov	x5, #0x0                   	// #0
    2a38:	aa1603e1 	mov	x1, x22
    2a3c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a40:	52880443 	mov	w3, #0x4022                	// #16418
    2a44:	52800002 	mov	w2, #0x0                   	// #0
    2a48:	d2800000 	mov	x0, #0x0                   	// #0
    2a4c:	97fffae5 	bl	15e0 <mmap@plt>
    2a50:	aa0003e6 	mov	x6, x0
    2a54:	b100041f 	cmn	x0, #0x1
    2a58:	54fffe60 	b.eq	2a24 <fwp_heap_init+0xd0>  // b.none
    2a5c:	b40005a0 	cbz	x0, 2b10 <fwp_heap_init+0x1bc>
    2a60:	d350fe94 	lsr	x20, x20, #16
    2a64:	d29fffe0 	mov	x0, #0xffff                	// #65535
    2a68:	8b0000c7 	add	x7, x6, x0
    2a6c:	9114c275 	add	x21, x19, #0x530
    2a70:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    2a74:	8b140a81 	add	x1, x20, x20, lsl #2
    2a78:	d2800005 	mov	x5, #0x0                   	// #0
    2a7c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a80:	d37df021 	lsl	x1, x1, #3
    2a84:	52880443 	mov	w3, #0x4022                	// #16418
    2a88:	52800002 	mov	w2, #0x0                   	// #0
    2a8c:	d2800000 	mov	x0, #0x0                   	// #0
    2a90:	f909daa7 	str	x7, [x21, #5040]
    2a94:	f909dea6 	str	x6, [x21, #5048]
    2a98:	f909e2b6 	str	x22, [x21, #5056]
    2a9c:	f909eab4 	str	x20, [x21, #5072]
    2aa0:	f90a02a1 	str	x1, [x21, #5120]
    2aa4:	97fffacf 	bl	15e0 <mmap@plt>
    2aa8:	aa0003e1 	mov	x1, x0
    2aac:	b100041f 	cmn	x0, #0x1
    2ab0:	54000300 	b.eq	2b10 <fwp_heap_init+0x1bc>  // b.none
    2ab4:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    2ab8:	911ae000 	add	x0, x0, #0x6b8
    2abc:	f909fea1 	str	x1, [x21, #5112]
    2ac0:	97fffb08 	bl	16e0 <getenv@plt>
    2ac4:	52800002 	mov	w2, #0x0                   	// #0
    2ac8:	aa0003e1 	mov	x1, x0
    2acc:	b40000e0 	cbz	x0, 2ae8 <fwp_heap_init+0x194>
    2ad0:	39400000 	ldrb	w0, [x0]
    2ad4:	340000a0 	cbz	w0, 2ae8 <fwp_heap_init+0x194>
    2ad8:	7100c000 	subs	w0, w0, #0x30
    2adc:	54000120 	b.eq	2b00 <fwp_heap_init+0x1ac>  // b.none
    2ae0:	7100001f 	cmp	w0, #0x0
    2ae4:	1a9f07e2 	cset	w2, ne	// ne = any
    2ae8:	9114c273 	add	x19, x19, #0x530
    2aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2af0:	b913aa62 	str	w2, [x19, #5032]
    2af4:	a94153f3 	ldp	x19, x20, [sp, #16]
    2af8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2afc:	d65f03c0 	ret
    2b00:	39400420 	ldrb	w0, [x1, #1]
    2b04:	7100001f 	cmp	w0, #0x0
    2b08:	1a9f07e2 	cset	w2, ne	// ne = any
    2b0c:	17fffff7 	b	2ae8 <fwp_heap_init+0x194>
    2b10:	97fffc90 	bl	1d50 <fwp_heap_oom>

0000000000002b14 <fwp_args45>:
    2b14:	d65f03c0 	ret
    2b18:	d503201f 	nop
    2b1c:	d503201f 	nop

0000000000002b20 <fwp_args69>:
    2b20:	d65f03c0 	ret

0000000000002b24 <fwp_wake_io>:
    2b24:	d00000e9 	adrp	x9, 20000 <__data_start>
    2b28:	91014122 	add	x2, x9, #0x50
    2b2c:	f9400001 	ldr	x1, [x0]
    2b30:	5280000a 	mov	w10, #0x0                   	// #0
    2b34:	f9401446 	ldr	x6, [x2, #40]
    2b38:	52800008 	mov	w8, #0x0                   	// #0
    2b3c:	4f000400 	movi	v0.4s, #0x0
    2b40:	52800027 	mov	w7, #0x1                   	// #1
    2b44:	aa0103e2 	mov	x2, x1
    2b48:	b4000321 	cbz	x1, 2bac <fwp_wake_io+0x88>
    2b4c:	f9408c25 	ldr	x5, [x1, #280]
    2b50:	39015c27 	strb	w7, [x1, #87]
    2b54:	b4000165 	cbz	x5, 2b80 <fwp_wake_io+0x5c>
    2b58:	a9520c24 	ldp	x4, x3, [x1, #288]
    2b5c:	b4000364 	cbz	x4, 2bc8 <fwp_wake_io+0xa4>
    2b60:	f9009483 	str	x3, [x4, #296]
    2b64:	f9409423 	ldr	x3, [x1, #296]
    2b68:	b4000043 	cbz	x3, 2b70 <fwp_wake_io+0x4c>
    2b6c:	f9009064 	str	x4, [x3, #288]
    2b70:	91080023 	add	x3, x1, #0x200
    2b74:	f900943f 	str	xzr, [x1, #296]
    2b78:	3c918060 	stur	q0, [x3, #-232]
    2b7c:	f9400001 	ldr	x1, [x0]
    2b80:	f9402843 	ldr	x3, [x2, #80]
    2b84:	f2001c7f 	tst	x3, #0xff000000ff
    2b88:	54fffde1 	b.ne	2b44 <fwp_wake_io+0x20>  // b.any
    2b8c:	39015047 	strb	w7, [x2, #84]
    2b90:	f900805f 	str	xzr, [x2, #256]
    2b94:	b40001e6 	cbz	x6, 2bd0 <fwp_wake_io+0xac>
    2b98:	f90080c2 	str	x2, [x6, #256]
    2b9c:	aa0203e6 	mov	x6, x2
    2ba0:	52800028 	mov	w8, #0x1                   	// #1
    2ba4:	aa0103e2 	mov	x2, x1
    2ba8:	b5fffd21 	cbnz	x1, 2b4c <fwp_wake_io+0x28>
    2bac:	3400006a 	cbz	w10, 2bb8 <fwp_wake_io+0x94>
    2bb0:	91014120 	add	x0, x9, #0x50
    2bb4:	f900180b 	str	x11, [x0, #48]
    2bb8:	34000068 	cbz	w8, 2bc4 <fwp_wake_io+0xa0>
    2bbc:	91014129 	add	x9, x9, #0x50
    2bc0:	f9001526 	str	x6, [x9, #40]
    2bc4:	d65f03c0 	ret
    2bc8:	f90000a3 	str	x3, [x5]
    2bcc:	17ffffe7 	b	2b68 <fwp_wake_io+0x44>
    2bd0:	aa0203eb 	mov	x11, x2
    2bd4:	5280002a 	mov	w10, #0x1                   	// #1
    2bd8:	17fffff1 	b	2b9c <fwp_wake_io+0x78>
    2bdc:	d503201f 	nop

0000000000002be0 <fwp_poll_events>:
    2be0:	d10103ff 	sub	sp, sp, #0x40
    2be4:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    2be8:	f947f400 	ldr	x0, [x0, #4072]
    2bec:	a9027bfd 	stp	x29, x30, [sp, #32]
    2bf0:	910083fd 	add	x29, sp, #0x20
    2bf4:	a90353f3 	stp	x19, x20, [sp, #48]
    2bf8:	d00000f4 	adrp	x20, 20000 <__data_start>
    2bfc:	f9400001 	ldr	x1, [x0]
    2c00:	f9000fe1 	str	x1, [sp, #24]
    2c04:	d2800001 	mov	x1, #0x0                   	// #0
    2c08:	97fffdce 	bl	2340 <fwp_now_ns>
    2c0c:	91014281 	add	x1, x20, #0x50
    2c10:	f9401c33 	ldr	x19, [x1, #56]
    2c14:	b4000e93 	cbz	x19, 2de4 <fwp_poll_events+0x204>
    2c18:	aa1303e1 	mov	x1, x19
    2c1c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2c20:	14000005 	b	2c34 <fwp_poll_events+0x54>
    2c24:	f9408821 	ldr	x1, [x1, #272]
    2c28:	eb03005f 	cmp	x2, x3
    2c2c:	9a83d042 	csel	x2, x2, x3, le
    2c30:	b40000c1 	cbz	x1, 2c48 <fwp_poll_events+0x68>
    2c34:	f9403423 	ldr	x3, [x1, #104]
    2c38:	b6ffff62 	tbz	x2, #63, 2c24 <fwp_poll_events+0x44>
    2c3c:	f9408821 	ldr	x1, [x1, #272]
    2c40:	aa0303e2 	mov	x2, x3
    2c44:	b5ffff81 	cbnz	x1, 2c34 <fwp_poll_events+0x54>
    2c48:	b7f80ce2 	tbnz	x2, #63, 2de4 <fwp_poll_events+0x204>
    2c4c:	cb000042 	sub	x2, x2, x0
    2c50:	f100005f 	cmp	x2, #0x0
    2c54:	540005cd 	b.le	2d0c <fwp_poll_events+0x12c>
    2c58:	d2869b60 	mov	x0, #0x34db                	// #13531
    2c5c:	d2884801 	mov	x1, #0x4240                	// #16960
    2c60:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2c64:	f2a001e1 	movk	x1, #0xf, lsl #16
    2c68:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2c6c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2c70:	f2e86360 	movk	x0, #0x431b, lsl #48
    2c74:	9b407c40 	smulh	x0, x2, x0
    2c78:	9352fc00 	asr	x0, x0, #18
    2c7c:	cb82fc00 	sub	x0, x0, x2, asr #63
    2c80:	9b018802 	msub	x2, x0, x1, x2
    2c84:	f100005f 	cmp	x2, #0x0
    2c88:	9a800400 	cinc	x0, x0, ne	// ne = any
    2c8c:	eb03001f 	cmp	x0, x3
    2c90:	54000a0c 	b.gt	2dd0 <fwp_poll_events+0x1f0>
    2c94:	340003c0 	cbz	w0, 2d0c <fwp_poll_events+0x12c>
    2c98:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2c9c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2ca0:	72a20c42 	movk	w2, #0x1062, lsl #16
    2ca4:	9ba27c02 	umull	x2, w0, w2
    2ca8:	d366fc43 	lsr	x3, x2, #38
    2cac:	aa0303e2 	mov	x2, x3
    2cb0:	1b048063 	msub	w3, w3, w4, w0
    2cb4:	9b217c63 	smull	x3, w3, w1
    2cb8:	d2800001 	mov	x1, #0x0                   	// #0
    2cbc:	910023e0 	add	x0, sp, #0x8
    2cc0:	a9008fe2 	stp	x2, x3, [sp, #8]
    2cc4:	97fffa57 	bl	1620 <nanosleep@plt>
    2cc8:	91014280 	add	x0, x20, #0x50
    2ccc:	f9401c13 	ldr	x19, [x0, #56]
    2cd0:	97fffd9c 	bl	2340 <fwp_now_ns>
    2cd4:	aa0003e6 	mov	x6, x0
    2cd8:	b50001f3 	cbnz	x19, 2d14 <fwp_poll_events+0x134>
    2cdc:	d503201f 	nop
    2ce0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    2ce4:	f947f400 	ldr	x0, [x0, #4072]
    2ce8:	f9400fe2 	ldr	x2, [sp, #24]
    2cec:	f9400001 	ldr	x1, [x0]
    2cf0:	eb010042 	subs	x2, x2, x1
    2cf4:	d2800001 	mov	x1, #0x0                   	// #0
    2cf8:	540008c1 	b.ne	2e10 <fwp_poll_events+0x230>  // b.any
    2cfc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2d00:	a94353f3 	ldp	x19, x20, [sp, #48]
    2d04:	910103ff 	add	sp, sp, #0x40
    2d08:	d65f03c0 	ret
    2d0c:	97fffd8d 	bl	2340 <fwp_now_ns>
    2d10:	aa0003e6 	mov	x6, x0
    2d14:	4f000400 	movi	v0.4s, #0x0
    2d18:	91014288 	add	x8, x20, #0x50
    2d1c:	52800027 	mov	w7, #0x1                   	// #1
    2d20:	f9403661 	ldr	x1, [x19, #104]
    2d24:	aa1303e5 	mov	x5, x19
    2d28:	f9408a73 	ldr	x19, [x19, #272]
    2d2c:	eb06003f 	cmp	x1, x6
    2d30:	5400032c 	b.gt	2d94 <fwp_poll_events+0x1b4>
    2d34:	394154a0 	ldrb	w0, [x5, #85]
    2d38:	36000120 	tbz	w0, #0, 2d5c <fwp_poll_events+0x17c>
    2d3c:	f94084a0 	ldr	x0, [x5, #264]
    2d40:	b40003c0 	cbz	x0, 2db8 <fwp_poll_events+0x1d8>
    2d44:	f9008813 	str	x19, [x0, #272]
    2d48:	b4000053 	cbz	x19, 2d50 <fwp_poll_events+0x170>
    2d4c:	f9008660 	str	x0, [x19, #264]
    2d50:	910800a0 	add	x0, x5, #0x200
    2d54:	390154bf 	strb	wzr, [x5, #85]
    2d58:	3c908000 	stur	q0, [x0, #-248]
    2d5c:	f94030a0 	ldr	x0, [x5, #96]
    2d60:	390158a7 	strb	w7, [x5, #86]
    2d64:	f100001f 	cmp	x0, #0x0
    2d68:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2d6c:	5400018d 	b.le	2d9c <fwp_poll_events+0x1bc>
    2d70:	f94028a0 	ldr	x0, [x5, #80]
    2d74:	f2001c1f 	tst	x0, #0xff000000ff
    2d78:	540000e1 	b.ne	2d94 <fwp_poll_events+0x1b4>  // b.any
    2d7c:	f9401500 	ldr	x0, [x8, #40]
    2d80:	390150a7 	strb	w7, [x5, #84]
    2d84:	f90080bf 	str	xzr, [x5, #256]
    2d88:	b40001e0 	cbz	x0, 2dc4 <fwp_poll_events+0x1e4>
    2d8c:	f9001505 	str	x5, [x8, #40]
    2d90:	f9008005 	str	x5, [x0, #256]
    2d94:	b5fffc73 	cbnz	x19, 2d20 <fwp_poll_events+0x140>
    2d98:	17ffffd2 	b	2ce0 <fwp_poll_events+0x100>
    2d9c:	394144a0 	ldrb	w0, [x5, #81]
    2da0:	3707fe80 	tbnz	w0, #0, 2d70 <fwp_poll_events+0x190>
    2da4:	394140a0 	ldrb	w0, [x5, #80]
    2da8:	3707fe40 	tbnz	w0, #0, 2d70 <fwp_poll_events+0x190>
    2dac:	aa0503e0 	mov	x0, x5
    2db0:	97fffd10 	bl	21f0 <fwp_cancel_tree.part.0>
    2db4:	17ffffef 	b	2d70 <fwp_poll_events+0x190>
    2db8:	91014281 	add	x1, x20, #0x50
    2dbc:	f9001c33 	str	x19, [x1, #56]
    2dc0:	17ffffe2 	b	2d48 <fwp_poll_events+0x168>
    2dc4:	f9001505 	str	x5, [x8, #40]
    2dc8:	f9001905 	str	x5, [x8, #48]
    2dcc:	17fffff2 	b	2d94 <fwp_poll_events+0x1b4>
    2dd0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2dd4:	d2989362 	mov	x2, #0xc49b                	// #50331
    2dd8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2ddc:	f2a00402 	movk	x2, #0x20, lsl #16
    2de0:	17ffffb6 	b	2cb8 <fwp_poll_events+0xd8>
    2de4:	97fffb9b 	bl	1c50 <fwp_flush>
    2de8:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x132b8>
    2dec:	f947e863 	ldr	x3, [x3, #4048]
    2df0:	d2800562 	mov	x2, #0x2b                  	// #43
    2df4:	d2800021 	mov	x1, #0x1                   	// #1
    2df8:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    2dfc:	911b2000 	add	x0, x0, #0x6c8
    2e00:	f9400063 	ldr	x3, [x3]
    2e04:	97fffa13 	bl	1650 <fwrite@plt>
    2e08:	52800ca0 	mov	w0, #0x65                  	// #101
    2e0c:	97fff97d 	bl	1400 <exit@plt>
    2e10:	97fff9d0 	bl	1550 <__stack_chk_fail@plt>

0000000000002e14 <fwp_rc_wide_dup>:
    2e14:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2e18:	910003fd 	mov	x29, sp
    2e1c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e20:	aa0003f3 	mov	x19, x0
    2e24:	ca404400 	eor	x0, x0, x0, lsr #17
    2e28:	f90013f5 	str	x21, [sp, #32]
    2e2c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    2e30:	ca402400 	eor	x0, x0, x0, lsr #9
    2e34:	9114c2a2 	add	x2, x21, #0x530
    2e38:	92401c00 	and	x0, x0, #0xff
    2e3c:	910a2403 	add	x3, x0, #0x289
    2e40:	8b000c40 	add	x0, x2, x0, lsl #3
    2e44:	8b030c54 	add	x20, x2, x3, lsl #3
    2e48:	f94a2401 	ldr	x1, [x0, #5192]
    2e4c:	b50000a1 	cbnz	x1, 2e60 <fwp_rc_wide_dup+0x4c>
    2e50:	1400002d 	b	2f04 <fwp_rc_wide_dup+0xf0>
    2e54:	91004034 	add	x20, x1, #0x10
    2e58:	f9400821 	ldr	x1, [x1, #16]
    2e5c:	b4000241 	cbz	x1, 2ea4 <fwp_rc_wide_dup+0x90>
    2e60:	f9400022 	ldr	x2, [x1]
    2e64:	eb02027f 	cmp	x19, x2
    2e68:	54ffff61 	b.ne	2e54 <fwp_rc_wide_dup+0x40>  // b.any
    2e6c:	f9400281 	ldr	x1, [x20]
    2e70:	39400260 	ldrb	w0, [x19]
    2e74:	7103f81f 	cmp	w0, #0xfe
    2e78:	54000220 	b.eq	2ebc <fwp_rc_wide_dup+0xa8>  // b.none
    2e7c:	b40001a1 	cbz	x1, 2eb0 <fwp_rc_wide_dup+0x9c>
    2e80:	f9400420 	ldr	x0, [x1, #8]
    2e84:	b100041f 	cmn	x0, #0x1
    2e88:	540004a0 	b.eq	2f1c <fwp_rc_wide_dup+0x108>  // b.none
    2e8c:	91000400 	add	x0, x0, #0x1
    2e90:	f9000420 	str	x0, [x1, #8]
    2e94:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e98:	f94013f5 	ldr	x21, [sp, #32]
    2e9c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2ea0:	d65f03c0 	ret
    2ea4:	39400260 	ldrb	w0, [x19]
    2ea8:	7103f81f 	cmp	w0, #0xfe
    2eac:	540000a0 	b.eq	2ec0 <fwp_rc_wide_dup+0xac>  // b.none
    2eb0:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    2eb4:	911c8000 	add	x0, x0, #0x720
    2eb8:	97fffd12 	bl	2300 <fwp_trap>
    2ebc:	b5000281 	cbnz	x1, 2f0c <fwp_rc_wide_dup+0xf8>
    2ec0:	d2800300 	mov	x0, #0x18                  	// #24
    2ec4:	97fff98b 	bl	14f0 <malloc@plt>
    2ec8:	b4000280 	cbz	x0, 2f18 <fwp_rc_wide_dup+0x104>
    2ecc:	d2801fe1 	mov	x1, #0xff                  	// #255
    2ed0:	a9000413 	stp	x19, x1, [x0]
    2ed4:	9114c2b5 	add	x21, x21, #0x530
    2ed8:	f900081f 	str	xzr, [x0, #16]
    2edc:	12800001 	mov	w1, #0xffffffff            	// #-1
    2ee0:	f9000280 	str	x0, [x20]
    2ee4:	39000261 	strb	w1, [x19]
    2ee8:	f94e26a0 	ldr	x0, [x21, #7240]
    2eec:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ef0:	91000400 	add	x0, x0, #0x1
    2ef4:	f90e26a0 	str	x0, [x21, #7240]
    2ef8:	f94013f5 	ldr	x21, [sp, #32]
    2efc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f00:	d65f03c0 	ret
    2f04:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    2f08:	17ffffda 	b	2e70 <fwp_rc_wide_dup+0x5c>
    2f0c:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    2f10:	911be000 	add	x0, x0, #0x6f8
    2f14:	97fffcfb 	bl	2300 <fwp_trap>
    2f18:	97fffb8e 	bl	1d50 <fwp_heap_oom>
    2f1c:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    2f20:	911d2000 	add	x0, x0, #0x748
    2f24:	97fffcf7 	bl	2300 <fwp_trap>
    2f28:	d503201f 	nop
    2f2c:	d503201f 	nop

0000000000002f30 <fwp_rc_forget_slot>:
    2f30:	aa0003e1 	mov	x1, x0
    2f34:	39400000 	ldrb	w0, [x0]
    2f38:	7103fc1f 	cmp	w0, #0xff
    2f3c:	54000040 	b.eq	2f44 <fwp_rc_forget_slot+0x14>  // b.none
    2f40:	d65f03c0 	ret
    2f44:	ca414420 	eor	x0, x1, x1, lsr #17
    2f48:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f4c:	ca402400 	eor	x0, x0, x0, lsr #9
    2f50:	910003fd 	mov	x29, sp
    2f54:	92401c00 	and	x0, x0, #0xff
    2f58:	f9000bf3 	str	x19, [sp, #16]
    2f5c:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    2f60:	9114c262 	add	x2, x19, #0x530
    2f64:	910a2403 	add	x3, x0, #0x289
    2f68:	8b000c40 	add	x0, x2, x0, lsl #3
    2f6c:	8b030c43 	add	x3, x2, x3, lsl #3
    2f70:	f94a2400 	ldr	x0, [x0, #5192]
    2f74:	b50000a0 	cbnz	x0, 2f88 <fwp_rc_forget_slot+0x58>
    2f78:	14000011 	b	2fbc <fwp_rc_forget_slot+0x8c>
    2f7c:	91004003 	add	x3, x0, #0x10
    2f80:	f9400800 	ldr	x0, [x0, #16]
    2f84:	b40001c0 	cbz	x0, 2fbc <fwp_rc_forget_slot+0x8c>
    2f88:	f9400002 	ldr	x2, [x0]
    2f8c:	eb02003f 	cmp	x1, x2
    2f90:	54ffff61 	b.ne	2f7c <fwp_rc_forget_slot+0x4c>  // b.any
    2f94:	f9400801 	ldr	x1, [x0, #16]
    2f98:	9114c273 	add	x19, x19, #0x530
    2f9c:	f9000061 	str	x1, [x3]
    2fa0:	97fff99c 	bl	1610 <free@plt>
    2fa4:	f94e2660 	ldr	x0, [x19, #7240]
    2fa8:	d1000400 	sub	x0, x0, #0x1
    2fac:	f90e2660 	str	x0, [x19, #7240]
    2fb0:	f9400bf3 	ldr	x19, [sp, #16]
    2fb4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2fb8:	d65f03c0 	ret
    2fbc:	90000040 	adrp	x0, a000 <__divti3+0x2e0>
    2fc0:	911c8000 	add	x0, x0, #0x720
    2fc4:	97fffccf 	bl	2300 <fwp_trap>
    2fc8:	d503201f 	nop
    2fcc:	d503201f 	nop

0000000000002fd0 <fwp_rc_prepare_chunk>:
    2fd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    2fdc:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    2fe0:	9114c2c2 	add	x2, x22, #0x530
    2fe4:	b9401c03 	ldr	w3, [x0, #28]
    2fe8:	aa0103f5 	mov	x21, x1
    2fec:	a90153f3 	stp	x19, x20, [sp, #16]
    2ff0:	aa0003f4 	mov	x20, x0
    2ff4:	f94e2440 	ldr	x0, [x2, #7240]
    2ff8:	b4000440 	cbz	x0, 3080 <fwp_rc_prepare_chunk+0xb0>
    2ffc:	d2800013 	mov	x19, #0x0                   	// #0
    3000:	35000203 	cbnz	w3, 3040 <fwp_rc_prepare_chunk+0x70>
    3004:	b4000361 	cbz	x1, 3070 <fwp_rc_prepare_chunk+0xa0>
    3008:	f9401280 	ldr	x0, [x20, #32]
    300c:	97fff981 	bl	1610 <free@plt>
    3010:	aa1503e0 	mov	x0, x21
    3014:	d2800021 	mov	x1, #0x1                   	// #1
    3018:	97fff946 	bl	1530 <calloc@plt>
    301c:	f9001280 	str	x0, [x20, #32]
    3020:	b5000460 	cbnz	x0, 30ac <fwp_rc_prepare_chunk+0xdc>
    3024:	97fffb4b 	bl	1d50 <fwp_heap_oom>
    3028:	97ffffc2 	bl	2f30 <fwp_rc_forget_slot>
    302c:	91000673 	add	x19, x19, #0x1
    3030:	b9401e83 	ldr	w3, [x20, #28]
    3034:	eb13007f 	cmp	x3, x19
    3038:	54000169 	b.ls	3064 <fwp_rc_prepare_chunk+0x94>  // b.plast
    303c:	d503201f 	nop
    3040:	f9401283 	ldr	x3, [x20, #32]
    3044:	8b130060 	add	x0, x3, x19
    3048:	38736863 	ldrb	w3, [x3, x19]
    304c:	7103fc7f 	cmp	w3, #0xff
    3050:	54fffec0 	b.eq	3028 <fwp_rc_prepare_chunk+0x58>  // b.none
    3054:	b9401e83 	ldr	w3, [x20, #28]
    3058:	91000673 	add	x19, x19, #0x1
    305c:	eb13007f 	cmp	x3, x19
    3060:	54ffff08 	b.hi	3040 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    3064:	eb0302bf 	cmp	x21, x3
    3068:	54000121 	b.ne	308c <fwp_rc_prepare_chunk+0xbc>  // b.any
    306c:	b5000335 	cbnz	x21, 30d0 <fwp_rc_prepare_chunk+0x100>
    3070:	a94153f3 	ldp	x19, x20, [sp, #16]
    3074:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3078:	a8c37bfd 	ldp	x29, x30, [sp], #48
    307c:	d65f03c0 	ret
    3080:	2a0303e3 	mov	w3, w3
    3084:	eb0302bf 	cmp	x21, x3
    3088:	54ffff20 	b.eq	306c <fwp_rc_prepare_chunk+0x9c>  // b.none
    308c:	9114c2c2 	add	x2, x22, #0x530
    3090:	f9401280 	ldr	x0, [x20, #32]
    3094:	f94e2841 	ldr	x1, [x2, #7248]
    3098:	cb030021 	sub	x1, x1, x3
    309c:	f90e2841 	str	x1, [x2, #7248]
    30a0:	97fff95c 	bl	1610 <free@plt>
    30a4:	b5fffb75 	cbnz	x21, 3010 <fwp_rc_prepare_chunk+0x40>
    30a8:	f900129f 	str	xzr, [x20, #32]
    30ac:	9114c2d6 	add	x22, x22, #0x530
    30b0:	f94e2ac0 	ldr	x0, [x22, #7248]
    30b4:	b9001e95 	str	w21, [x20, #28]
    30b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    30bc:	8b150000 	add	x0, x0, x21
    30c0:	f90e2ac0 	str	x0, [x22, #7248]
    30c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    30c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30cc:	d65f03c0 	ret
    30d0:	f9401280 	ldr	x0, [x20, #32]
    30d4:	aa1503e2 	mov	x2, x21
    30d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    30dc:	52800001 	mov	w1, #0x0                   	// #0
    30e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    30e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e8:	17fff90e 	b	1520 <memset@plt>
    30ec:	d503201f 	nop

00000000000030f0 <fwp_heap_refill>:
    30f0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30f4:	910003fd 	mov	x29, sp
    30f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    30fc:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    3100:	9114c2b5 	add	x21, x21, #0x530
    3104:	aa0003f6 	mov	x22, x0
    3108:	d2800020 	mov	x0, #0x1                   	// #1
    310c:	a90153f3 	stp	x19, x20, [sp, #16]
    3110:	a90363f7 	stp	x23, x24, [sp, #48]
    3114:	2a0103f7 	mov	w23, w1
    3118:	2a0203f8 	mov	w24, w2
    311c:	97fffb1d 	bl	1d90 <fwp_heap_chunks>
    3120:	aa0003f3 	mov	x19, x0
    3124:	f949fea2 	ldr	x2, [x21, #5112]
    3128:	8b000800 	add	x0, x0, x0, lsl #2
    312c:	2a1703e1 	mov	w1, w23
    3130:	52800025 	mov	w5, #0x1                   	// #1
    3134:	d37df000 	lsl	x0, x0, #3
    3138:	910f0021 	add	x1, x1, #0x3c0
    313c:	8b000054 	add	x20, x2, x0
    3140:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    3144:	52a00024 	mov	w4, #0x10000               	// #65536
    3148:	38206845 	strb	w5, [x2, x0]
    314c:	aa1403e0 	mov	x0, x20
    3150:	39000698 	strb	w24, [x20, #1]
    3154:	39000a97 	strb	w23, [x20, #2]
    3158:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    315c:	b9000681 	str	w1, [x20, #4]
    3160:	2a0103e5 	mov	w5, w1
    3164:	8b0300a2 	add	x2, x5, x3
    3168:	1ac10881 	udiv	w1, w4, w1
    316c:	9ac50842 	udiv	x2, x2, x5
    3170:	b9000a81 	str	w1, [x20, #8]
    3174:	92404021 	and	x1, x1, #0x1ffff
    3178:	b9001a82 	str	w2, [x20, #24]
    317c:	97ffff95 	bl	2fd0 <fwp_rc_prepare_chunk>
    3180:	f949daa0 	ldr	x0, [x21, #5040]
    3184:	29408a81 	ldp	w1, w2, [x20, #4]
    3188:	8b134000 	add	x0, x0, x19, lsl #16
    318c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3190:	8b214003 	add	x3, x0, w1, uxtw
    3194:	9ba20021 	umaddl	x1, w1, w2, x0
    3198:	a94363f7 	ldp	x23, x24, [sp, #48]
    319c:	a90086c3 	stp	x3, x1, [x22, #8]
    31a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    31a4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    31a8:	d65f03c0 	ret
    31ac:	d503201f 	nop

00000000000031b0 <fwp_mem_free>:
    31b0:	b40003c0 	cbz	x0, 3228 <fwp_mem_free+0x78>
    31b4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    31b8:	910003fd 	mov	x29, sp
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    31c4:	9114c2a1 	add	x1, x21, #0x530
    31c8:	a90153f3 	stp	x19, x20, [sp, #16]
    31cc:	aa0003f3 	mov	x19, x0
    31d0:	f949d823 	ldr	x3, [x1, #5040]
    31d4:	f949ec22 	ldr	x2, [x1, #5080]
    31d8:	cb030000 	sub	x0, x0, x3
    31dc:	eb02401f 	cmp	x0, x2, lsl #16
    31e0:	540001c2 	b.cs	3218 <fwp_mem_free+0x68>  // b.hs, b.nlast
    31e4:	d350fc16 	lsr	x22, x0, #16
    31e8:	a90363f7 	stp	x23, x24, [sp, #48]
    31ec:	f949fc22 	ldr	x2, [x1, #5112]
    31f0:	8b160ad4 	add	x20, x22, x22, lsl #2
    31f4:	d37df294 	lsl	x20, x20, #3
    31f8:	ab140057 	adds	x23, x2, x20
    31fc:	540000c0 	b.eq	3214 <fwp_mem_free+0x64>  // b.none
    3200:	38746842 	ldrb	w2, [x2, x20]
    3204:	7100045f 	cmp	w2, #0x1
    3208:	54000120 	b.eq	322c <fwp_mem_free+0x7c>  // b.none
    320c:	7100085f 	cmp	w2, #0x2
    3210:	540005e0 	b.eq	32cc <fwp_mem_free+0x11c>  // b.none
    3214:	a94363f7 	ldp	x23, x24, [sp, #48]
    3218:	a94153f3 	ldp	x19, x20, [sp, #16]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3224:	d65f03c0 	ret
    3228:	d65f03c0 	ret
    322c:	f94012f8 	ldr	x24, [x23, #32]
    3230:	b94006e1 	ldr	w1, [x23, #4]
    3234:	f90023f9 	str	x25, [sp, #64]
    3238:	2a0103e2 	mov	w2, w1
    323c:	394006f9 	ldrb	w25, [x23, #1]
    3240:	39400af4 	ldrb	w20, [x23, #2]
    3244:	b4000158 	cbz	x24, 326c <fwp_mem_free+0xbc>
    3248:	92403e76 	and	x22, x19, #0xffff
    324c:	9ac20ad6 	udiv	x22, x22, x2
    3250:	38766b01 	ldrb	w1, [x24, x22]
    3254:	8b160300 	add	x0, x24, x22
    3258:	7103fc3f 	cmp	w1, #0xff
    325c:	54000980 	b.eq	338c <fwp_mem_free+0x1dc>  // b.none
    3260:	38366b1f 	strb	wzr, [x24, x22]
    3264:	b94006e1 	ldr	w1, [x23, #4]
    3268:	2a0103e2 	mov	w2, w1
    326c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    3270:	d37f1e83 	ubfiz	x3, x20, #1, #8
    3274:	cb390000 	sub	x0, x0, w25, uxtb
    3278:	8b340074 	add	x20, x3, w20, uxtb
    327c:	9114c2b5 	add	x21, x21, #0x530
    3280:	1e630021 	ucvtf	d1, w1
    3284:	d37ae400 	lsl	x0, x0, #6
    3288:	8b140c14 	add	x20, x0, x20, lsl #3
    328c:	a94363f7 	ldp	x23, x24, [sp, #48]
    3290:	f8746aa0 	ldr	x0, [x21, x20]
    3294:	f94023f9 	ldr	x25, [sp, #64]
    3298:	aa2003e0 	mvn	x0, x0
    329c:	fd4a22a0 	ldr	d0, [x21, #5184]
    32a0:	f9000260 	str	x0, [x19]
    32a4:	f8346ab3 	str	x19, [x21, x20]
    32a8:	f94a12a0 	ldr	x0, [x21, #5152]
    32ac:	1e612800 	fadd	d0, d0, d1
    32b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32b4:	cb020000 	sub	x0, x0, x2
    32b8:	f90a12a0 	str	x0, [x21, #5152]
    32bc:	fd0a22a0 	str	d0, [x21, #5184]
    32c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32c4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    32c8:	d65f03c0 	ret
    32cc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    32d0:	8b000063 	add	x3, x3, x0
    32d4:	eb03027f 	cmp	x19, x3
    32d8:	54fff9e1 	b.ne	3214 <fwp_mem_free+0x64>  // b.any
    32dc:	fd400ae1 	ldr	d1, [x23, #16]
    32e0:	fd4a2020 	ldr	d0, [x1, #5184]
    32e4:	f9400ae0 	ldr	x0, [x23, #16]
    32e8:	7e61d821 	ucvtf	d1, d1
    32ec:	f94a1022 	ldr	x2, [x1, #5152]
    32f0:	f94012f3 	ldr	x19, [x23, #32]
    32f4:	1e612800 	fadd	d0, d0, d1
    32f8:	cb000042 	sub	x2, x2, x0
    32fc:	f90a1022 	str	x2, [x1, #5152]
    3300:	fd0a2020 	str	d0, [x1, #5184]
    3304:	b40000b3 	cbz	x19, 3318 <fwp_mem_free+0x168>
    3308:	39400260 	ldrb	w0, [x19]
    330c:	7103fc1f 	cmp	w0, #0xff
    3310:	54000380 	b.eq	3380 <fwp_mem_free+0x1d0>  // b.none
    3314:	3900027f 	strb	wzr, [x19]
    3318:	b9400ee2 	ldr	w2, [x23, #12]
    331c:	b4000142 	cbz	x2, 3344 <fwp_mem_free+0x194>
    3320:	9114c2a1 	add	x1, x21, #0x530
    3324:	8b160040 	add	x0, x2, x22
    3328:	8b000800 	add	x0, x0, x0, lsl #2
    332c:	f949fc21 	ldr	x1, [x1, #5112]
    3330:	8b140034 	add	x20, x1, x20
    3334:	8b000c20 	add	x0, x1, x0, lsl #3
    3338:	3802869f 	strb	wzr, [x20], #40
    333c:	eb00029f 	cmp	x20, x0
    3340:	54ffffc1 	b.ne	3338 <fwp_mem_free+0x188>  // b.any
    3344:	9114c2a0 	add	x0, x21, #0x530
    3348:	f94a1801 	ldr	x1, [x0, #5168]
    334c:	f949f803 	ldr	x3, [x0, #5104]
    3350:	8b020021 	add	x1, x1, x2
    3354:	f90a1801 	str	x1, [x0, #5168]
    3358:	eb16007f 	cmp	x3, x22
    335c:	54000049 	b.ls	3364 <fwp_mem_free+0x1b4>  // b.plast
    3360:	f909f816 	str	x22, [x0, #5104]
    3364:	9114c2b5 	add	x21, x21, #0x530
    3368:	f949f6a0 	ldr	x0, [x21, #5096]
    336c:	eb16001f 	cmp	x0, x22
    3370:	54fff529 	b.ls	3214 <fwp_mem_free+0x64>  // b.plast
    3374:	a94363f7 	ldp	x23, x24, [sp, #48]
    3378:	f909f6b6 	str	x22, [x21, #5096]
    337c:	17ffffa7 	b	3218 <fwp_mem_free+0x68>
    3380:	aa1303e0 	mov	x0, x19
    3384:	97fffeeb 	bl	2f30 <fwp_rc_forget_slot>
    3388:	17ffffe3 	b	3314 <fwp_mem_free+0x164>
    338c:	97fffee9 	bl	2f30 <fwp_rc_forget_slot>
    3390:	17ffffb4 	b	3260 <fwp_mem_free+0xb0>

0000000000003394 <fwp_heap_alloc_big>:
    3394:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    3398:	910003fd 	mov	x29, sp
    339c:	a90153f3 	stp	x19, x20, [sp, #16]
    33a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    33a4:	a90363f7 	stp	x23, x24, [sp, #48]
    33a8:	aa0003f7 	mov	x23, x0
    33ac:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    33b0:	a9046bf9 	stp	x25, x26, [sp, #64]
    33b4:	eb0002ff 	cmp	x23, x0
    33b8:	54000888 	b.hi	34c8 <fwp_heap_alloc_big+0x134>  // b.pmore
    33bc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    33c0:	8b0002f4 	add	x20, x23, x0
    33c4:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xcb0>
    33c8:	9114c359 	add	x25, x26, #0x530
    33cc:	d350fe94 	lsr	x20, x20, #16
    33d0:	2a0103f5 	mov	w21, w1
    33d4:	aa1403e0 	mov	x0, x20
    33d8:	97fffa6e 	bl	1d90 <fwp_heap_chunks>
    33dc:	f949ff22 	ldr	x2, [x25, #5112]
    33e0:	8b000813 	add	x19, x0, x0, lsl #2
    33e4:	aa0003f8 	mov	x24, x0
    33e8:	52800043 	mov	w3, #0x2                   	// #2
    33ec:	d37df273 	lsl	x19, x19, #3
    33f0:	d2800021 	mov	x1, #0x1                   	// #1
    33f4:	8b130040 	add	x0, x2, x19
    33f8:	38336843 	strb	w3, [x2, x19]
    33fc:	39000415 	strb	w21, [x0, #1]
    3400:	b9000c14 	str	w20, [x0, #12]
    3404:	f9000817 	str	x23, [x0, #16]
    3408:	97fffef2 	bl	2fd0 <fwp_rc_prepare_chunk>
    340c:	f100069f 	cmp	x20, #0x1
    3410:	54000269 	b.ls	345c <fwp_heap_alloc_big+0xc8>  // b.plast
    3414:	8b180294 	add	x20, x20, x24
    3418:	9100a273 	add	x19, x19, #0x28
    341c:	a90573fb 	stp	x27, x28, [sp, #80]
    3420:	5280007b 	mov	w27, #0x3                   	// #3
    3424:	8b140a94 	add	x20, x20, x20, lsl #2
    3428:	2a1803fc 	mov	w28, w24
    342c:	9adb2296 	lsl	x22, x20, x27
    3430:	f949ff35 	ldr	x21, [x25, #5112]
    3434:	d2800001 	mov	x1, #0x0                   	// #0
    3438:	8b1302b4 	add	x20, x21, x19
    343c:	aa1403e0 	mov	x0, x20
    3440:	97fffee4 	bl	2fd0 <fwp_rc_prepare_chunk>
    3444:	38336abb 	strb	w27, [x21, x19]
    3448:	9100a273 	add	x19, x19, #0x28
    344c:	b9000e9c 	str	w28, [x20, #12]
    3450:	eb1302df 	cmp	x22, x19
    3454:	54fffee1 	b.ne	3430 <fwp_heap_alloc_big+0x9c>  // b.any
    3458:	a94573fb 	ldp	x27, x28, [sp, #80]
    345c:	9114c353 	add	x19, x26, #0x530
    3460:	aa1703e2 	mov	x2, x23
    3464:	52800001 	mov	w1, #0x0                   	// #0
    3468:	f949da60 	ldr	x0, [x19, #5040]
    346c:	8b184018 	add	x24, x0, x24, lsl #16
    3470:	aa1803e0 	mov	x0, x24
    3474:	97fff82b 	bl	1520 <memset@plt>
    3478:	f94a1260 	ldr	x0, [x19, #5152]
    347c:	ab170000 	adds	x0, x0, x23
    3480:	54000242 	b.cs	34c8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    3484:	f94a1661 	ldr	x1, [x19, #5160]
    3488:	f90a1260 	str	x0, [x19, #5152]
    348c:	eb01001f 	cmp	x0, x1
    3490:	54000049 	b.ls	3498 <fwp_heap_alloc_big+0x104>  // b.plast
    3494:	f90a1660 	str	x0, [x19, #5160]
    3498:	9114c35a 	add	x26, x26, #0x530
    349c:	9e6202e0 	scvtf	d0, x23
    34a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a4:	aa1803e0 	mov	x0, x24
    34a8:	fd4a1f41 	ldr	d1, [x26, #5176]
    34ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34b0:	1e602820 	fadd	d0, d1, d0
    34b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    34b8:	fd0a1f40 	str	d0, [x26, #5176]
    34bc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    34c0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    34c4:	d65f03c0 	ret
    34c8:	a90573fb 	stp	x27, x28, [sp, #80]
    34cc:	97fffa21 	bl	1d50 <fwp_heap_oom>

00000000000034d0 <fwp_heap_alloc_slow>:
    34d0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    34d4:	910003fd 	mov	x29, sp
    34d8:	a90153f3 	stp	x19, x20, [sp, #16]
    34dc:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    34e0:	9114c262 	add	x2, x19, #0x530
    34e4:	a9025bf5 	stp	x21, x22, [sp, #32]
    34e8:	aa0003f5 	mov	x21, x0
    34ec:	2a0103f4 	mov	w20, w1
    34f0:	b953a440 	ldr	w0, [x2, #5028]
    34f4:	34000600 	cbz	w0, 35b4 <fwp_heap_alloc_slow+0xe4>
    34f8:	f14012bf 	cmp	x21, #0x4, lsl #12
    34fc:	54000628 	b.hi	35c0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3500:	91003ea0 	add	x0, x21, #0xf
    3504:	9114c262 	add	x2, x19, #0x530
    3508:	f9001bf7 	str	x23, [sp, #48]
    350c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3510:	8b401040 	add	x0, x2, x0, lsr #4
    3514:	cb34c084 	sub	x4, x4, w20, sxtw
    3518:	d37ae484 	lsl	x4, x4, #6
    351c:	397e8003 	ldrb	w3, [x0, #4000]
    3520:	910f0060 	add	x0, x3, #0x3c0
    3524:	aa0303e1 	mov	x1, x3
    3528:	8b030463 	add	x3, x3, x3, lsl #1
    352c:	8b030c83 	add	x3, x4, x3, lsl #3
    3530:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3534:	2a1703f6 	mov	w22, w23
    3538:	f8636844 	ldr	x4, [x2, x3]
    353c:	b40004e4 	cbz	x4, 35d8 <fwp_heap_alloc_slow+0x108>
    3540:	f9400080 	ldr	x0, [x4]
    3544:	aa2003e0 	mvn	x0, x0
    3548:	f8236840 	str	x0, [x2, x3]
    354c:	7100069f 	cmp	w20, #0x1
    3550:	aa0403e0 	mov	x0, x4
    3554:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    3558:	52800001 	mov	w1, #0x0                   	// #0
    355c:	97fff7f1 	bl	1520 <memset@plt>
    3560:	aa0003e4 	mov	x4, x0
    3564:	9114c260 	add	x0, x19, #0x530
    3568:	f94a1001 	ldr	x1, [x0, #5152]
    356c:	ab160021 	adds	x1, x1, x22
    3570:	540005c2 	b.cs	3628 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    3574:	f94a1402 	ldr	x2, [x0, #5160]
    3578:	f90a1001 	str	x1, [x0, #5152]
    357c:	eb02003f 	cmp	x1, x2
    3580:	54000049 	b.ls	3588 <fwp_heap_alloc_slow+0xb8>  // b.plast
    3584:	f90a1401 	str	x1, [x0, #5160]
    3588:	9114c273 	add	x19, x19, #0x530
    358c:	1e6302e1 	ucvtf	d1, w23
    3590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3594:	aa0403e0 	mov	x0, x4
    3598:	fd4a1e60 	ldr	d0, [x19, #5176]
    359c:	f9401bf7 	ldr	x23, [sp, #48]
    35a0:	1e612800 	fadd	d0, d0, d1
    35a4:	fd0a1e60 	str	d0, [x19, #5176]
    35a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35ac:	a8c47bfd 	ldp	x29, x30, [sp], #64
    35b0:	d65f03c0 	ret
    35b4:	97fffce8 	bl	2954 <fwp_heap_init>
    35b8:	f14012bf 	cmp	x21, #0x4, lsl #12
    35bc:	54fffa29 	b.ls	3500 <fwp_heap_alloc_slow+0x30>  // b.plast
    35c0:	2a1403e1 	mov	w1, w20
    35c4:	aa1503e0 	mov	x0, x21
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35d0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    35d4:	17ffff70 	b	3394 <fwp_heap_alloc_big>
    35d8:	8b030042 	add	x2, x2, x3
    35dc:	f9400444 	ldr	x4, [x2, #8]
    35e0:	b4000104 	cbz	x4, 3600 <fwp_heap_alloc_slow+0x130>
    35e4:	f9400840 	ldr	x0, [x2, #16]
    35e8:	cb040000 	sub	x0, x0, x4
    35ec:	eb16001f 	cmp	x0, x22
    35f0:	54000083 	b.cc	3600 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    35f4:	8b160080 	add	x0, x4, x22
    35f8:	f9000440 	str	x0, [x2, #8]
    35fc:	17ffffd4 	b	354c <fwp_heap_alloc_slow+0x7c>
    3600:	52800302 	mov	w2, #0x18                  	// #24
    3604:	52807804 	mov	w4, #0x3c0                 	// #960
    3608:	9114c260 	add	x0, x19, #0x530
    360c:	9ba27c23 	umull	x3, w1, w2
    3610:	2a1403e2 	mov	w2, w20
    3614:	9b240e84 	smaddl	x4, w20, w4, x3
    3618:	8b040000 	add	x0, x0, x4
    361c:	97fffeb5 	bl	30f0 <fwp_heap_refill>
    3620:	aa0003e4 	mov	x4, x0
    3624:	17ffffca 	b	354c <fwp_heap_alloc_slow+0x7c>
    3628:	97fff9ca 	bl	1d50 <fwp_heap_oom>
    362c:	d503201f 	nop

0000000000003630 <fwp_rc_share>:
    3630:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    3634:	9114c042 	add	x2, x2, #0x530
    3638:	f949d843 	ldr	x3, [x2, #5040]
    363c:	f949ec41 	ldr	x1, [x2, #5080]
    3640:	cb030000 	sub	x0, x0, x3
    3644:	eb01401f 	cmp	x0, x1, lsl #16
    3648:	540002c2 	b.cs	36a0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    364c:	d350fc01 	lsr	x1, x0, #16
    3650:	f949fc44 	ldr	x4, [x2, #5112]
    3654:	8b010821 	add	x1, x1, x1, lsl #2
    3658:	d37df021 	lsl	x1, x1, #3
    365c:	8b010083 	add	x3, x4, x1
    3660:	f9401062 	ldr	x2, [x3, #32]
    3664:	b40001e2 	cbz	x2, 36a0 <fwp_rc_share+0x70>
    3668:	38616881 	ldrb	w1, [x4, x1]
    366c:	7100083f 	cmp	w1, #0x2
    3670:	540001a0 	b.eq	36a4 <fwp_rc_share+0x74>  // b.none
    3674:	7100043f 	cmp	w1, #0x1
    3678:	54000141 	b.ne	36a0 <fwp_rc_share+0x70>  // b.any
    367c:	29430464 	ldp	w4, w1, [x3, #24]
    3680:	92403c00 	and	x0, x0, #0xffff
    3684:	9b047c00 	mul	x0, x0, x4
    3688:	d360fc00 	lsr	x0, x0, #32
    368c:	eb01001f 	cmp	x0, x1
    3690:	54000082 	b.cs	36a0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    3694:	8b000042 	add	x2, x2, x0
    3698:	39400040 	ldrb	w0, [x2]
    369c:	350000a0 	cbnz	w0, 36b0 <fwp_rc_share+0x80>
    36a0:	d65f03c0 	ret
    36a4:	72003c1f 	tst	w0, #0xffff
    36a8:	54ffff80 	b.eq	3698 <fwp_rc_share+0x68>  // b.none
    36ac:	d65f03c0 	ret
    36b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    36b4:	f0000020 	adrp	x0, a000 <__divti3+0x2e0>
    36b8:	911da000 	add	x0, x0, #0x768
    36bc:	910003fd 	mov	x29, sp
    36c0:	97fffb10 	bl	2300 <fwp_trap>

00000000000036c4 <e69>:
    36c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36c8:	f0000021 	adrp	x1, a000 <__divti3+0x2e0>
    36cc:	910003fd 	mov	x29, sp
    36d0:	fd400001 	ldr	d1, [x0]
    36d4:	f9000bf3 	str	x19, [sp, #16]
    36d8:	fd45a020 	ldr	d0, [x1, #2880]
    36dc:	1e610800 	fmul	d0, d0, d1
    36e0:	9e660013 	fmov	x19, d0
    36e4:	aa1303e0 	mov	x0, x19
    36e8:	97ffffd2 	bl	3630 <fwp_rc_share>
    36ec:	aa1303e0 	mov	x0, x19
    36f0:	f9400bf3 	ldr	x19, [sp, #16]
    36f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36f8:	d65f03c0 	ret
    36fc:	d503201f 	nop

0000000000003700 <e45>:
    3700:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3704:	910003fd 	mov	x29, sp
    3708:	6d400001 	ldp	d1, d0, [x0]
    370c:	f9000bf3 	str	x19, [sp, #16]
    3710:	1e612800 	fadd	d0, d0, d1
    3714:	9e660013 	fmov	x19, d0
    3718:	aa1303e0 	mov	x0, x19
    371c:	97ffffc5 	bl	3630 <fwp_rc_share>
    3720:	aa1303e0 	mov	x0, x19
    3724:	f9400bf3 	ldr	x19, [sp, #16]
    3728:	a8c27bfd 	ldp	x29, x30, [sp], #32
    372c:	d65f03c0 	ret

0000000000003730 <e32>:
    3730:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3734:	910003fd 	mov	x29, sp
    3738:	6d400001 	ldp	d1, d0, [x0]
    373c:	f9000bf3 	str	x19, [sp, #16]
    3740:	1e613800 	fsub	d0, d0, d1
    3744:	9e660013 	fmov	x19, d0
    3748:	aa1303e0 	mov	x0, x19
    374c:	97ffffb9 	bl	3630 <fwp_rc_share>
    3750:	aa1303e0 	mov	x0, x19
    3754:	f9400bf3 	ldr	x19, [sp, #16]
    3758:	a8c27bfd 	ldp	x29, x30, [sp], #32
    375c:	d65f03c0 	ret

0000000000003760 <fwp_rc_fresh>:
    3760:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3764:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3768:	9114c063 	add	x3, x3, #0x530
    376c:	910003fd 	mov	x29, sp
    3770:	a90153f3 	stp	x19, x20, [sp, #16]
    3774:	aa0003f3 	mov	x19, x0
    3778:	f949d861 	ldr	x1, [x3, #5040]
    377c:	f949ec60 	ldr	x0, [x3, #5080]
    3780:	cb010261 	sub	x1, x19, x1
    3784:	eb00403f 	cmp	x1, x0, lsl #16
    3788:	54000322 	b.cs	37ec <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    378c:	d350fc22 	lsr	x2, x1, #16
    3790:	f949fc63 	ldr	x3, [x3, #5112]
    3794:	8b020842 	add	x2, x2, x2, lsl #2
    3798:	d37df042 	lsl	x2, x2, #3
    379c:	8b020060 	add	x0, x3, x2
    37a0:	f9401014 	ldr	x20, [x0, #32]
    37a4:	b4000254 	cbz	x20, 37ec <fwp_rc_fresh+0x8c>
    37a8:	38626862 	ldrb	w2, [x3, x2]
    37ac:	7100085f 	cmp	w2, #0x2
    37b0:	54000260 	b.eq	37fc <fwp_rc_fresh+0x9c>  // b.none
    37b4:	7100045f 	cmp	w2, #0x1
    37b8:	540001a1 	b.ne	37ec <fwp_rc_fresh+0x8c>  // b.any
    37bc:	29430002 	ldp	w2, w0, [x0, #24]
    37c0:	92403c21 	and	x1, x1, #0xffff
    37c4:	9b027c21 	mul	x1, x1, x2
    37c8:	d360fc21 	lsr	x1, x1, #32
    37cc:	eb00003f 	cmp	x1, x0
    37d0:	540000e2 	b.cs	37ec <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    37d4:	8b010294 	add	x20, x20, x1
    37d8:	39400280 	ldrb	w0, [x20]
    37dc:	7103fc1f 	cmp	w0, #0xff
    37e0:	540001a0 	b.eq	3814 <fwp_rc_fresh+0xb4>  // b.none
    37e4:	52800020 	mov	w0, #0x1                   	// #1
    37e8:	39000280 	strb	w0, [x20]
    37ec:	aa1303e0 	mov	x0, x19
    37f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    37f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37f8:	d65f03c0 	ret
    37fc:	72003c3f 	tst	w1, #0xffff
    3800:	54fffec0 	b.eq	37d8 <fwp_rc_fresh+0x78>  // b.none
    3804:	aa1303e0 	mov	x0, x19
    3808:	a94153f3 	ldp	x19, x20, [sp, #16]
    380c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3810:	d65f03c0 	ret
    3814:	aa1403e0 	mov	x0, x20
    3818:	97fffdc6 	bl	2f30 <fwp_rc_forget_slot>
    381c:	17fffff2 	b	37e4 <fwp_rc_fresh+0x84>

0000000000003820 <fwp_rc_dup>:
    3820:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    3824:	9114c042 	add	x2, x2, #0x530
    3828:	f949d841 	ldr	x1, [x2, #5040]
    382c:	f949ec43 	ldr	x3, [x2, #5080]
    3830:	cb010001 	sub	x1, x0, x1
    3834:	eb03403f 	cmp	x1, x3, lsl #16
    3838:	540003c2 	b.cs	38b0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    383c:	d350fc20 	lsr	x0, x1, #16
    3840:	f949fc44 	ldr	x4, [x2, #5112]
    3844:	8b000800 	add	x0, x0, x0, lsl #2
    3848:	d37df002 	lsl	x2, x0, #3
    384c:	8b020083 	add	x3, x4, x2
    3850:	f9401060 	ldr	x0, [x3, #32]
    3854:	b40002e0 	cbz	x0, 38b0 <fwp_rc_dup+0x90>
    3858:	38626882 	ldrb	w2, [x4, x2]
    385c:	7100085f 	cmp	w2, #0x2
    3860:	540002a0 	b.eq	38b4 <fwp_rc_dup+0x94>  // b.none
    3864:	7100045f 	cmp	w2, #0x1
    3868:	54000241 	b.ne	38b0 <fwp_rc_dup+0x90>  // b.any
    386c:	29430864 	ldp	w4, w2, [x3, #24]
    3870:	92403c21 	and	x1, x1, #0xffff
    3874:	9b047c21 	mul	x1, x1, x4
    3878:	d360fc21 	lsr	x1, x1, #32
    387c:	eb02003f 	cmp	x1, x2
    3880:	54000182 	b.cs	38b0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    3884:	8b010000 	add	x0, x0, x1
    3888:	39400001 	ldrb	w1, [x0]
    388c:	34000121 	cbz	w1, 38b0 <fwp_rc_dup+0x90>
    3890:	b00000e2 	adrp	x2, 20000 <__data_start>
    3894:	91014042 	add	x2, x2, #0x50
    3898:	b9404043 	ldr	w3, [x2, #64]
    389c:	35000123 	cbnz	w3, 38c0 <fwp_rc_dup+0xa0>
    38a0:	7103f43f 	cmp	w1, #0xfd
    38a4:	54000168 	b.hi	38d0 <fwp_rc_dup+0xb0>  // b.pmore
    38a8:	11000421 	add	w1, w1, #0x1
    38ac:	39000001 	strb	w1, [x0]
    38b0:	d65f03c0 	ret
    38b4:	72003c3f 	tst	w1, #0xffff
    38b8:	54fffe80 	b.eq	3888 <fwp_rc_dup+0x68>  // b.none
    38bc:	d65f03c0 	ret
    38c0:	f9402443 	ldr	x3, [x2, #72]
    38c4:	91000463 	add	x3, x3, #0x1
    38c8:	f9002443 	str	x3, [x2, #72]
    38cc:	17fffff5 	b	38a0 <fwp_rc_dup+0x80>
    38d0:	17fffd51 	b	2e14 <fwp_rc_wide_dup>

00000000000038d4 <fwp_task_dispose>:
    38d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    38d8:	910003fd 	mov	x29, sp
    38dc:	f9000bf3 	str	x19, [sp, #16]
    38e0:	aa0003f3 	mov	x19, x0
    38e4:	39414000 	ldrb	w0, [x0, #80]
    38e8:	36000720 	tbz	w0, #0, 39cc <fwp_task_dispose+0xf8>
    38ec:	f9400a60 	ldr	x0, [x19, #16]
    38f0:	b50006e0 	cbnz	x0, 39cc <fwp_task_dispose+0xf8>
    38f4:	a9478660 	ldp	x0, x1, [x19, #120]
    38f8:	39014e7f 	strb	wzr, [x19, #83]
    38fc:	f9003e7f 	str	xzr, [x19, #120]
    3900:	f100003f 	cmp	x1, #0x0
    3904:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3908:	54000040 	b.eq	3910 <fwp_task_dispose+0x3c>  // b.none
    390c:	d63f0020 	blr	x1
    3910:	f9405660 	ldr	x0, [x19, #168]
    3914:	97fffe27 	bl	31b0 <fwp_mem_free>
    3918:	f900567f 	str	xzr, [x19, #168]
    391c:	b9405e60 	ldr	w0, [x19, #92]
    3920:	7100041f 	cmp	w0, #0x1
    3924:	54000420 	b.eq	39a8 <fwp_task_dispose+0xd4>  // b.none
    3928:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    392c:	9114c042 	add	x2, x2, #0x530
    3930:	f949d840 	ldr	x0, [x2, #5040]
    3934:	f949ec41 	ldr	x1, [x2, #5080]
    3938:	cb000260 	sub	x0, x19, x0
    393c:	eb01401f 	cmp	x0, x1, lsl #16
    3940:	540002e2 	b.cs	399c <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3944:	d350fc01 	lsr	x1, x0, #16
    3948:	f949fc44 	ldr	x4, [x2, #5112]
    394c:	8b010821 	add	x1, x1, x1, lsl #2
    3950:	d37df021 	lsl	x1, x1, #3
    3954:	8b010083 	add	x3, x4, x1
    3958:	f9401062 	ldr	x2, [x3, #32]
    395c:	b4000202 	cbz	x2, 399c <fwp_task_dispose+0xc8>
    3960:	38616881 	ldrb	w1, [x4, x1]
    3964:	7100083f 	cmp	w1, #0x2
    3968:	54000280 	b.eq	39b8 <fwp_task_dispose+0xe4>  // b.none
    396c:	7100043f 	cmp	w1, #0x1
    3970:	54000161 	b.ne	399c <fwp_task_dispose+0xc8>  // b.any
    3974:	29430464 	ldp	w4, w1, [x3, #24]
    3978:	92403c00 	and	x0, x0, #0xffff
    397c:	9b047c00 	mul	x0, x0, x4
    3980:	d360fc00 	lsr	x0, x0, #32
    3984:	eb01001f 	cmp	x0, x1
    3988:	540000a2 	b.cs	399c <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    398c:	8b000042 	add	x2, x2, x0
    3990:	39400040 	ldrb	w0, [x2]
    3994:	7100041f 	cmp	w0, #0x1
    3998:	54000080 	b.eq	39a8 <fwp_task_dispose+0xd4>  // b.none
    399c:	f9400bf3 	ldr	x19, [sp, #16]
    39a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39a4:	d65f03c0 	ret
    39a8:	aa1303e0 	mov	x0, x19
    39ac:	f9400bf3 	ldr	x19, [sp, #16]
    39b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39b4:	17fffdff 	b	31b0 <fwp_mem_free>
    39b8:	72003c1f 	tst	w0, #0xffff
    39bc:	54fffea0 	b.eq	3990 <fwp_task_dispose+0xbc>  // b.none
    39c0:	f9400bf3 	ldr	x19, [sp, #16]
    39c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39c8:	d65f03c0 	ret
    39cc:	97fff6f5 	bl	15a0 <abort@plt>

00000000000039d0 <fwp_free_zombie>:
    39d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    39d4:	910003fd 	mov	x29, sp
    39d8:	a90153f3 	stp	x19, x20, [sp, #16]
    39dc:	b00000f4 	adrp	x20, 20000 <__data_start>
    39e0:	91014281 	add	x1, x20, #0x50
    39e4:	f9402833 	ldr	x19, [x1, #80]
    39e8:	b4000333 	cbz	x19, 3a4c <fwp_free_zombie+0x7c>
    39ec:	f9400420 	ldr	x0, [x1, #8]
    39f0:	eb00027f 	cmp	x19, x0
    39f4:	540002c0 	b.eq	3a4c <fwp_free_zombie+0x7c>  // b.none
    39f8:	b9405822 	ldr	w2, [x1, #88]
    39fc:	f9400a60 	ldr	x0, [x19, #16]
    3a00:	7100fc5f 	cmp	w2, #0x3f
    3a04:	5400078c 	b.gt	3af4 <fwp_free_zombie+0x124>
    3a08:	91018023 	add	x3, x1, #0x60
    3a0c:	11000444 	add	w4, w2, #0x1
    3a10:	b9005824 	str	w4, [x1, #88]
    3a14:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3a18:	f822d860 	str	x0, [x3, w2, sxtw #3]
    3a1c:	a9530261 	ldp	x1, x0, [x19, #304]
    3a20:	b4000741 	cbz	x1, 3b08 <fwp_free_zombie+0x138>
    3a24:	f9009c20 	str	x0, [x1, #312]
    3a28:	b4000040 	cbz	x0, 3a30 <fwp_free_zombie+0x60>
    3a2c:	f9009801 	str	x1, [x0, #304]
    3a30:	91014294 	add	x20, x20, #0x50
    3a34:	b9405e60 	ldr	w0, [x19, #92]
    3a38:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    3a3c:	f9002a9f 	str	xzr, [x20, #80]
    3a40:	34000140 	cbz	w0, 3a68 <fwp_free_zombie+0x98>
    3a44:	7100041f 	cmp	w0, #0x1
    3a48:	54000080 	b.eq	3a58 <fwp_free_zombie+0x88>  // b.none
    3a4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3a54:	d65f03c0 	ret
    3a58:	aa1303e0 	mov	x0, x19
    3a5c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a60:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3a64:	17ffff9c 	b	38d4 <fwp_task_dispose>
    3a68:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xcb0>
    3a6c:	9114c082 	add	x2, x4, #0x530
    3a70:	f949d841 	ldr	x1, [x2, #5040]
    3a74:	f949ec40 	ldr	x0, [x2, #5080]
    3a78:	cb010261 	sub	x1, x19, x1
    3a7c:	eb00403f 	cmp	x1, x0, lsl #16
    3a80:	54fffe62 	b.cs	3a4c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3a84:	d350fc20 	lsr	x0, x1, #16
    3a88:	f949fc43 	ldr	x3, [x2, #5112]
    3a8c:	8b000800 	add	x0, x0, x0, lsl #2
    3a90:	d37df000 	lsl	x0, x0, #3
    3a94:	8b000062 	add	x2, x3, x0
    3a98:	f9401054 	ldr	x20, [x2, #32]
    3a9c:	b4fffd94 	cbz	x20, 3a4c <fwp_free_zombie+0x7c>
    3aa0:	38606860 	ldrb	w0, [x3, x0]
    3aa4:	7100081f 	cmp	w0, #0x2
    3aa8:	54000360 	b.eq	3b14 <fwp_free_zombie+0x144>  // b.none
    3aac:	7100041f 	cmp	w0, #0x1
    3ab0:	54fffce1 	b.ne	3a4c <fwp_free_zombie+0x7c>  // b.any
    3ab4:	29430043 	ldp	w3, w0, [x2, #24]
    3ab8:	92403c21 	and	x1, x1, #0xffff
    3abc:	9b037c21 	mul	x1, x1, x3
    3ac0:	d360fc21 	lsr	x1, x1, #32
    3ac4:	eb00003f 	cmp	x1, x0
    3ac8:	54fffc22 	b.cs	3a4c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3acc:	8b010294 	add	x20, x20, x1
    3ad0:	39400280 	ldrb	w0, [x20]
    3ad4:	34fffbc0 	cbz	w0, 3a4c <fwp_free_zombie+0x7c>
    3ad8:	7100041f 	cmp	w0, #0x1
    3adc:	54fffbe0 	b.eq	3a58 <fwp_free_zombie+0x88>  // b.none
    3ae0:	7103fc1f 	cmp	w0, #0xff
    3ae4:	540001e0 	b.eq	3b20 <fwp_free_zombie+0x150>  // b.none
    3ae8:	51000400 	sub	w0, w0, #0x1
    3aec:	39000280 	strb	w0, [x20]
    3af0:	17ffffd7 	b	3a4c <fwp_free_zombie+0x7c>
    3af4:	f9400e61 	ldr	x1, [x19, #24]
    3af8:	97fff6de 	bl	1670 <munmap@plt>
    3afc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3b00:	a9530261 	ldp	x1, x0, [x19, #304]
    3b04:	b5fff901 	cbnz	x1, 3a24 <fwp_free_zombie+0x54>
    3b08:	91014282 	add	x2, x20, #0x50
    3b0c:	f9013040 	str	x0, [x2, #608]
    3b10:	17ffffc6 	b	3a28 <fwp_free_zombie+0x58>
    3b14:	72003c3f 	tst	w1, #0xffff
    3b18:	54fff9a1 	b.ne	3a4c <fwp_free_zombie+0x7c>  // b.any
    3b1c:	17ffffed 	b	3ad0 <fwp_free_zombie+0x100>
    3b20:	ca544680 	eor	x0, x20, x20, lsr #17
    3b24:	9114c084 	add	x4, x4, #0x530
    3b28:	ca402400 	eor	x0, x0, x0, lsr #9
    3b2c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3b30:	f94a2400 	ldr	x0, [x0, #5192]
    3b34:	b5000080 	cbnz	x0, 3b44 <fwp_free_zombie+0x174>
    3b38:	14000010 	b	3b78 <fwp_free_zombie+0x1a8>
    3b3c:	f9400800 	ldr	x0, [x0, #16]
    3b40:	b40001c0 	cbz	x0, 3b78 <fwp_free_zombie+0x1a8>
    3b44:	f9400001 	ldr	x1, [x0]
    3b48:	eb14003f 	cmp	x1, x20
    3b4c:	54ffff81 	b.ne	3b3c <fwp_free_zombie+0x16c>  // b.any
    3b50:	f9400401 	ldr	x1, [x0, #8]
    3b54:	d1000421 	sub	x1, x1, #0x1
    3b58:	f9000401 	str	x1, [x0, #8]
    3b5c:	f103f83f 	cmp	x1, #0xfe
    3b60:	54fff761 	b.ne	3a4c <fwp_free_zombie+0x7c>  // b.any
    3b64:	aa1403e0 	mov	x0, x20
    3b68:	97fffcf2 	bl	2f30 <fwp_rc_forget_slot>
    3b6c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3b70:	39000280 	strb	w0, [x20]
    3b74:	17ffffb6 	b	3a4c <fwp_free_zombie+0x7c>
    3b78:	f0000020 	adrp	x0, a000 <__divti3+0x2e0>
    3b7c:	911c8000 	add	x0, x0, #0x720
    3b80:	97fff9e0 	bl	2300 <fwp_trap>

0000000000003b84 <fwp_block>:
    3b84:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3b88:	910003fd 	mov	x29, sp
    3b8c:	a90153f3 	stp	x19, x20, [sp, #16]
    3b90:	b00000f3 	adrp	x19, 20000 <__data_start>
    3b94:	91014274 	add	x20, x19, #0x50
    3b98:	f9401a82 	ldr	x2, [x20, #48]
    3b9c:	b4000622 	cbz	x2, 3c60 <fwp_block+0xdc>
    3ba0:	91014261 	add	x1, x19, #0x50
    3ba4:	f9408040 	ldr	x0, [x2, #256]
    3ba8:	f9001820 	str	x0, [x1, #48]
    3bac:	b4000680 	cbz	x0, 3c7c <fwp_block+0xf8>
    3bb0:	91014263 	add	x3, x19, #0x50
    3bb4:	3901505f 	strb	wzr, [x2, #84]
    3bb8:	f9400464 	ldr	x4, [x3, #8]
    3bbc:	eb02009f 	cmp	x4, x2
    3bc0:	54000440 	b.eq	3c48 <fwp_block+0xc4>  // b.none
    3bc4:	f9413465 	ldr	x5, [x3, #616]
    3bc8:	f9000462 	str	x2, [x3, #8]
    3bcc:	f9400441 	ldr	x1, [x2, #8]
    3bd0:	f9004885 	str	x5, [x4, #144]
    3bd4:	f9413865 	ldr	x5, [x3, #624]
    3bd8:	f9004c85 	str	x5, [x4, #152]
    3bdc:	f9413c65 	ldr	x5, [x3, #632]
    3be0:	f9005085 	str	x5, [x4, #160]
    3be4:	f9414065 	ldr	x5, [x3, #640]
    3be8:	f9005485 	str	x5, [x4, #168]
    3bec:	f9414465 	ldr	x5, [x3, #648]
    3bf0:	f9005885 	str	x5, [x4, #176]
    3bf4:	f9414865 	ldr	x5, [x3, #656]
    3bf8:	f9005c85 	str	x5, [x4, #184]
    3bfc:	f9414c65 	ldr	x5, [x3, #664]
    3c00:	f9006085 	str	x5, [x4, #192]
    3c04:	f9400480 	ldr	x0, [x4, #8]
    3c08:	f9404844 	ldr	x4, [x2, #144]
    3c0c:	f9013464 	str	x4, [x3, #616]
    3c10:	f9404c44 	ldr	x4, [x2, #152]
    3c14:	f9013864 	str	x4, [x3, #624]
    3c18:	f9405044 	ldr	x4, [x2, #160]
    3c1c:	f9013c64 	str	x4, [x3, #632]
    3c20:	f9405444 	ldr	x4, [x2, #168]
    3c24:	f9014064 	str	x4, [x3, #640]
    3c28:	f9405844 	ldr	x4, [x2, #176]
    3c2c:	f9014464 	str	x4, [x3, #648]
    3c30:	a94b8844 	ldp	x4, x2, [x2, #184]
    3c34:	f9014864 	str	x4, [x3, #656]
    3c38:	f9014c62 	str	x2, [x3, #664]
    3c3c:	97fff65d 	bl	15b0 <swapcontext@plt>
    3c40:	97ffff64 	bl	39d0 <fwp_free_zombie>
    3c44:	d503201f 	nop
    3c48:	91014260 	add	x0, x19, #0x50
    3c4c:	b942a000 	ldr	w0, [x0, #672]
    3c50:	340001a0 	cbz	w0, 3c84 <fwp_block+0x100>
    3c54:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c58:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c5c:	d65f03c0 	ret
    3c60:	97fffbe0 	bl	2be0 <fwp_poll_events>
    3c64:	f9401a82 	ldr	x2, [x20, #48]
    3c68:	b4ffffc2 	cbz	x2, 3c60 <fwp_block+0xdc>
    3c6c:	91014261 	add	x1, x19, #0x50
    3c70:	f9408040 	ldr	x0, [x2, #256]
    3c74:	f9001820 	str	x0, [x1, #48]
    3c78:	b5fff9c0 	cbnz	x0, 3bb0 <fwp_block+0x2c>
    3c7c:	f900143f 	str	xzr, [x1, #40]
    3c80:	17ffffcc 	b	3bb0 <fwp_block+0x2c>
    3c84:	f0000020 	adrp	x0, a000 <__divti3+0x2e0>
    3c88:	911e6000 	add	x0, x0, #0x798
    3c8c:	97fff695 	bl	16e0 <getenv@plt>
    3c90:	5284e202 	mov	w2, #0x2710                	// #10000
    3c94:	b4000060 	cbz	x0, 3ca0 <fwp_block+0x11c>
    3c98:	39400001 	ldrb	w1, [x0]
    3c9c:	350000c1 	cbnz	w1, 3cb4 <fwp_block+0x130>
    3ca0:	91014273 	add	x19, x19, #0x50
    3ca4:	b902a262 	str	w2, [x19, #672]
    3ca8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3cac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3cb0:	d65f03c0 	ret
    3cb4:	52800142 	mov	w2, #0xa                   	// #10
    3cb8:	d2800001 	mov	x1, #0x0                   	// #0
    3cbc:	97fff5d9 	bl	1420 <strtoll@plt>
    3cc0:	d1000403 	sub	x3, x0, #0x1
    3cc4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3cc8:	eb02007f 	cmp	x3, x2
    3ccc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3cd0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3cd4:	17fffff3 	b	3ca0 <fwp_block+0x11c>
    3cd8:	d503201f 	nop
    3cdc:	d503201f 	nop

0000000000003ce0 <fwp_caps32>:
    3ce0:	34000041 	cbz	w1, 3ce8 <fwp_caps32+0x8>
    3ce4:	d65f03c0 	ret
    3ce8:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3cec:	9114c063 	add	x3, x3, #0x530
    3cf0:	f949d861 	ldr	x1, [x3, #5040]
    3cf4:	f949ec62 	ldr	x2, [x3, #5080]
    3cf8:	cb010001 	sub	x1, x0, x1
    3cfc:	eb02403f 	cmp	x1, x2, lsl #16
    3d00:	54ffff22 	b.cs	3ce4 <fwp_caps32+0x4>  // b.hs, b.nlast
    3d04:	d350fc22 	lsr	x2, x1, #16
    3d08:	f949fc65 	ldr	x5, [x3, #5112]
    3d0c:	8b020842 	add	x2, x2, x2, lsl #2
    3d10:	d37df042 	lsl	x2, x2, #3
    3d14:	8b0200a4 	add	x4, x5, x2
    3d18:	f9401083 	ldr	x3, [x4, #32]
    3d1c:	b4fffe43 	cbz	x3, 3ce4 <fwp_caps32+0x4>
    3d20:	386268a2 	ldrb	w2, [x5, x2]
    3d24:	7100085f 	cmp	w2, #0x2
    3d28:	540001c0 	b.eq	3d60 <fwp_caps32+0x80>  // b.none
    3d2c:	7100045f 	cmp	w2, #0x1
    3d30:	54fffda1 	b.ne	3ce4 <fwp_caps32+0x4>  // b.any
    3d34:	29430885 	ldp	w5, w2, [x4, #24]
    3d38:	92403c21 	and	x1, x1, #0xffff
    3d3c:	9b057c21 	mul	x1, x1, x5
    3d40:	d360fc21 	lsr	x1, x1, #32
    3d44:	eb02003f 	cmp	x1, x2
    3d48:	54fffce2 	b.cs	3ce4 <fwp_caps32+0x4>  // b.hs, b.nlast
    3d4c:	8b010063 	add	x3, x3, x1
    3d50:	39400061 	ldrb	w1, [x3]
    3d54:	7100043f 	cmp	w1, #0x1
    3d58:	54fffc61 	b.ne	3ce4 <fwp_caps32+0x4>  // b.any
    3d5c:	17fffd15 	b	31b0 <fwp_mem_free>
    3d60:	72003c3f 	tst	w1, #0xffff
    3d64:	54ffff60 	b.eq	3d50 <fwp_caps32+0x70>  // b.none
    3d68:	d65f03c0 	ret
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_caps74>:
    3d70:	34000041 	cbz	w1, 3d78 <fwp_caps74+0x8>
    3d74:	d65f03c0 	ret
    3d78:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3d7c:	9114c063 	add	x3, x3, #0x530
    3d80:	f949d861 	ldr	x1, [x3, #5040]
    3d84:	f949ec62 	ldr	x2, [x3, #5080]
    3d88:	cb010001 	sub	x1, x0, x1
    3d8c:	eb02403f 	cmp	x1, x2, lsl #16
    3d90:	54ffff22 	b.cs	3d74 <fwp_caps74+0x4>  // b.hs, b.nlast
    3d94:	d350fc22 	lsr	x2, x1, #16
    3d98:	f949fc65 	ldr	x5, [x3, #5112]
    3d9c:	8b020842 	add	x2, x2, x2, lsl #2
    3da0:	d37df042 	lsl	x2, x2, #3
    3da4:	8b0200a4 	add	x4, x5, x2
    3da8:	f9401083 	ldr	x3, [x4, #32]
    3dac:	b4fffe43 	cbz	x3, 3d74 <fwp_caps74+0x4>
    3db0:	386268a2 	ldrb	w2, [x5, x2]
    3db4:	7100085f 	cmp	w2, #0x2
    3db8:	540001c0 	b.eq	3df0 <fwp_caps74+0x80>  // b.none
    3dbc:	7100045f 	cmp	w2, #0x1
    3dc0:	54fffda1 	b.ne	3d74 <fwp_caps74+0x4>  // b.any
    3dc4:	29430885 	ldp	w5, w2, [x4, #24]
    3dc8:	92403c21 	and	x1, x1, #0xffff
    3dcc:	9b057c21 	mul	x1, x1, x5
    3dd0:	d360fc21 	lsr	x1, x1, #32
    3dd4:	eb02003f 	cmp	x1, x2
    3dd8:	54fffce2 	b.cs	3d74 <fwp_caps74+0x4>  // b.hs, b.nlast
    3ddc:	8b010063 	add	x3, x3, x1
    3de0:	39400061 	ldrb	w1, [x3]
    3de4:	7100043f 	cmp	w1, #0x1
    3de8:	54fffc61 	b.ne	3d74 <fwp_caps74+0x4>  // b.any
    3dec:	17fffcf1 	b	31b0 <fwp_mem_free>
    3df0:	72003c3f 	tst	w1, #0xffff
    3df4:	54ffff60 	b.eq	3de0 <fwp_caps74+0x70>  // b.none
    3df8:	d65f03c0 	ret
    3dfc:	d503201f 	nop

0000000000003e00 <fwp_caps69>:
    3e00:	34000041 	cbz	w1, 3e08 <fwp_caps69+0x8>
    3e04:	d65f03c0 	ret
    3e08:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3e0c:	9114c063 	add	x3, x3, #0x530
    3e10:	f949d861 	ldr	x1, [x3, #5040]
    3e14:	f949ec62 	ldr	x2, [x3, #5080]
    3e18:	cb010001 	sub	x1, x0, x1
    3e1c:	eb02403f 	cmp	x1, x2, lsl #16
    3e20:	54ffff22 	b.cs	3e04 <fwp_caps69+0x4>  // b.hs, b.nlast
    3e24:	d350fc22 	lsr	x2, x1, #16
    3e28:	f949fc65 	ldr	x5, [x3, #5112]
    3e2c:	8b020842 	add	x2, x2, x2, lsl #2
    3e30:	d37df042 	lsl	x2, x2, #3
    3e34:	8b0200a4 	add	x4, x5, x2
    3e38:	f9401083 	ldr	x3, [x4, #32]
    3e3c:	b4fffe43 	cbz	x3, 3e04 <fwp_caps69+0x4>
    3e40:	386268a2 	ldrb	w2, [x5, x2]
    3e44:	7100085f 	cmp	w2, #0x2
    3e48:	540001c0 	b.eq	3e80 <fwp_caps69+0x80>  // b.none
    3e4c:	7100045f 	cmp	w2, #0x1
    3e50:	54fffda1 	b.ne	3e04 <fwp_caps69+0x4>  // b.any
    3e54:	29430885 	ldp	w5, w2, [x4, #24]
    3e58:	92403c21 	and	x1, x1, #0xffff
    3e5c:	9b057c21 	mul	x1, x1, x5
    3e60:	d360fc21 	lsr	x1, x1, #32
    3e64:	eb02003f 	cmp	x1, x2
    3e68:	54fffce2 	b.cs	3e04 <fwp_caps69+0x4>  // b.hs, b.nlast
    3e6c:	8b010063 	add	x3, x3, x1
    3e70:	39400061 	ldrb	w1, [x3]
    3e74:	7100043f 	cmp	w1, #0x1
    3e78:	54fffc61 	b.ne	3e04 <fwp_caps69+0x4>  // b.any
    3e7c:	17fffccd 	b	31b0 <fwp_mem_free>
    3e80:	72003c3f 	tst	w1, #0xffff
    3e84:	54ffff60 	b.eq	3e70 <fwp_caps69+0x70>  // b.none
    3e88:	d65f03c0 	ret
    3e8c:	d503201f 	nop

0000000000003e90 <fwp_caps45>:
    3e90:	34000041 	cbz	w1, 3e98 <fwp_caps45+0x8>
    3e94:	d65f03c0 	ret
    3e98:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3e9c:	9114c063 	add	x3, x3, #0x530
    3ea0:	f949d861 	ldr	x1, [x3, #5040]
    3ea4:	f949ec62 	ldr	x2, [x3, #5080]
    3ea8:	cb010001 	sub	x1, x0, x1
    3eac:	eb02403f 	cmp	x1, x2, lsl #16
    3eb0:	54ffff22 	b.cs	3e94 <fwp_caps45+0x4>  // b.hs, b.nlast
    3eb4:	d350fc22 	lsr	x2, x1, #16
    3eb8:	f949fc65 	ldr	x5, [x3, #5112]
    3ebc:	8b020842 	add	x2, x2, x2, lsl #2
    3ec0:	d37df042 	lsl	x2, x2, #3
    3ec4:	8b0200a4 	add	x4, x5, x2
    3ec8:	f9401083 	ldr	x3, [x4, #32]
    3ecc:	b4fffe43 	cbz	x3, 3e94 <fwp_caps45+0x4>
    3ed0:	386268a2 	ldrb	w2, [x5, x2]
    3ed4:	7100085f 	cmp	w2, #0x2
    3ed8:	540001c0 	b.eq	3f10 <fwp_caps45+0x80>  // b.none
    3edc:	7100045f 	cmp	w2, #0x1
    3ee0:	54fffda1 	b.ne	3e94 <fwp_caps45+0x4>  // b.any
    3ee4:	29430885 	ldp	w5, w2, [x4, #24]
    3ee8:	92403c21 	and	x1, x1, #0xffff
    3eec:	9b057c21 	mul	x1, x1, x5
    3ef0:	d360fc21 	lsr	x1, x1, #32
    3ef4:	eb02003f 	cmp	x1, x2
    3ef8:	54fffce2 	b.cs	3e94 <fwp_caps45+0x4>  // b.hs, b.nlast
    3efc:	8b010063 	add	x3, x3, x1
    3f00:	39400061 	ldrb	w1, [x3]
    3f04:	7100043f 	cmp	w1, #0x1
    3f08:	54fffc61 	b.ne	3e94 <fwp_caps45+0x4>  // b.any
    3f0c:	17fffca9 	b	31b0 <fwp_mem_free>
    3f10:	72003c3f 	tst	w1, #0xffff
    3f14:	54ffff60 	b.eq	3f00 <fwp_caps45+0x70>  // b.none
    3f18:	d65f03c0 	ret
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_data.part.0.constprop.0>:
    3f20:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3f24:	910003fd 	mov	x29, sp
    3f28:	a90363f7 	stp	x23, x24, [sp, #48]
    3f2c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3f30:	91014302 	add	x2, x24, #0x50
    3f34:	a9046bf9 	stp	x25, x26, [sp, #64]
    3f38:	b9404059 	ldr	w25, [x2, #64]
    3f3c:	a90153f3 	stp	x19, x20, [sp, #16]
    3f40:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    3f44:	a9025bf5 	stp	x21, x22, [sp, #32]
    3f48:	2a0003f6 	mov	w22, w0
    3f4c:	aa0103f5 	mov	x21, x1
    3f50:	350005f9 	cbnz	w25, 400c <fwp_data.part.0.constprop.0+0xec>
    3f54:	9114c280 	add	x0, x20, #0x530
    3f58:	b953a400 	ldr	w0, [x0, #5028]
    3f5c:	34000c80 	cbz	w0, 40ec <fwp_data.part.0.constprop.0+0x1cc>
    3f60:	9114c283 	add	x3, x20, #0x530
    3f64:	397e8862 	ldrb	w2, [x3, #4002]
    3f68:	910f0040 	add	x0, x2, #0x3c0
    3f6c:	8b020442 	add	x2, x2, x2, lsl #1
    3f70:	d37df042 	lsl	x2, x2, #3
    3f74:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    3f78:	2a1a03f7 	mov	w23, w26
    3f7c:	f8626873 	ldr	x19, [x3, x2]
    3f80:	b4000753 	cbz	x19, 4068 <fwp_data.part.0.constprop.0+0x148>
    3f84:	f9400260 	ldr	x0, [x19]
    3f88:	aa2003e0 	mvn	x0, x0
    3f8c:	f8226860 	str	x0, [x3, x2]
    3f90:	f10062ff 	cmp	x23, #0x18
    3f94:	540000e9 	b.ls	3fb0 <fwp_data.part.0.constprop.0+0x90>  // b.plast
    3f98:	d10066e2 	sub	x2, x23, #0x19
    3f9c:	91006260 	add	x0, x19, #0x18
    3fa0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    3fa4:	52800001 	mov	w1, #0x0                   	// #0
    3fa8:	91002042 	add	x2, x2, #0x8
    3fac:	97fff55d 	bl	1520 <memset@plt>
    3fb0:	9114c280 	add	x0, x20, #0x530
    3fb4:	f94a1002 	ldr	x2, [x0, #5152]
    3fb8:	ab170042 	adds	x2, x2, x23
    3fbc:	54000a22 	b.cs	4100 <fwp_data.part.0.constprop.0+0x1e0>  // b.hs, b.nlast
    3fc0:	f94a1401 	ldr	x1, [x0, #5160]
    3fc4:	f90a1002 	str	x2, [x0, #5152]
    3fc8:	eb01005f 	cmp	x2, x1
    3fcc:	54000049 	b.ls	3fd4 <fwp_data.part.0.constprop.0+0xb4>  // b.plast
    3fd0:	f90a1402 	str	x2, [x0, #5160]
    3fd4:	9114c294 	add	x20, x20, #0x530
    3fd8:	1e630341 	ucvtf	d1, w26
    3fdc:	fd4a1e80 	ldr	d0, [x20, #5176]
    3fe0:	1e612800 	fadd	d0, d0, d1
    3fe4:	fd0a1e80 	str	d0, [x20, #5176]
    3fe8:	34000599 	cbz	w25, 4098 <fwp_data.part.0.constprop.0+0x178>
    3fec:	91014300 	add	x0, x24, #0x50
    3ff0:	9e630040 	ucvtf	d0, x2
    3ff4:	fd415c02 	ldr	d2, [x0, #696]
    3ff8:	fd416001 	ldr	d1, [x0, #704]
    3ffc:	1e623800 	fsub	d0, d0, d2
    4000:	1e602030 	fcmpe	d1, d0
    4004:	54000464 	b.mi	4090 <fwp_data.part.0.constprop.0+0x170>  // b.first
    4008:	14000024 	b	4098 <fwp_data.part.0.constprop.0+0x178>
    400c:	9114c283 	add	x3, x20, #0x530
    4010:	f9415441 	ldr	x1, [x2, #680]
    4014:	f9415840 	ldr	x0, [x2, #688]
    4018:	91000421 	add	x1, x1, #0x1
    401c:	b953a463 	ldr	w3, [x3, #5028]
    4020:	91006000 	add	x0, x0, #0x18
    4024:	f9015441 	str	x1, [x2, #680]
    4028:	f9015840 	str	x0, [x2, #688]
    402c:	35fff9a3 	cbnz	w3, 3f60 <fwp_data.part.0.constprop.0+0x40>
    4030:	52800001 	mov	w1, #0x0                   	// #0
    4034:	d2800300 	mov	x0, #0x18                  	// #24
    4038:	97fffd26 	bl	34d0 <fwp_heap_alloc_slow>
    403c:	aa0003f3 	mov	x19, x0
    4040:	9114c294 	add	x20, x20, #0x530
    4044:	91014300 	add	x0, x24, #0x50
    4048:	fd4a1280 	ldr	d0, [x20, #5152]
    404c:	fd415c02 	ldr	d2, [x0, #696]
    4050:	fd416001 	ldr	d1, [x0, #704]
    4054:	7e61d800 	ucvtf	d0, d0
    4058:	1e623800 	fsub	d0, d0, d2
    405c:	1e612010 	fcmpe	d0, d1
    4060:	5400042c 	b.gt	40e4 <fwp_data.part.0.constprop.0+0x1c4>
    4064:	17ffffe7 	b	4000 <fwp_data.part.0.constprop.0+0xe0>
    4068:	8b020063 	add	x3, x3, x2
    406c:	f9400473 	ldr	x19, [x3, #8]
    4070:	b40002f3 	cbz	x19, 40cc <fwp_data.part.0.constprop.0+0x1ac>
    4074:	f9400860 	ldr	x0, [x3, #16]
    4078:	cb130000 	sub	x0, x0, x19
    407c:	eb17001f 	cmp	x0, x23
    4080:	54000263 	b.cc	40cc <fwp_data.part.0.constprop.0+0x1ac>  // b.lo, b.ul, b.last
    4084:	8b170260 	add	x0, x19, x23
    4088:	f9000460 	str	x0, [x3, #8]
    408c:	17ffffc1 	b	3f90 <fwp_data.part.0.constprop.0+0x70>
    4090:	91014318 	add	x24, x24, #0x50
    4094:	fd016300 	str	d0, [x24, #704]
    4098:	52800040 	mov	w0, #0x2                   	// #2
    409c:	29000276 	stp	w22, w0, [x19]
    40a0:	aa1303e0 	mov	x0, x19
    40a4:	f94002a1 	ldr	x1, [x21]
    40a8:	f9000661 	str	x1, [x19, #8]
    40ac:	f94006a1 	ldr	x1, [x21, #8]
    40b0:	f9000a61 	str	x1, [x19, #16]
    40b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    40b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    40c0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    40c4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    40c8:	d65f03c0 	ret
    40cc:	52800001 	mov	w1, #0x0                   	// #0
    40d0:	d2800300 	mov	x0, #0x18                  	// #24
    40d4:	97fffcff 	bl	34d0 <fwp_heap_alloc_slow>
    40d8:	aa0003f3 	mov	x19, x0
    40dc:	34fffdf9 	cbz	w25, 4098 <fwp_data.part.0.constprop.0+0x178>
    40e0:	17ffffd8 	b	4040 <fwp_data.part.0.constprop.0+0x120>
    40e4:	fd016000 	str	d0, [x0, #704]
    40e8:	17ffffec 	b	4098 <fwp_data.part.0.constprop.0+0x178>
    40ec:	52800001 	mov	w1, #0x0                   	// #0
    40f0:	d2800300 	mov	x0, #0x18                  	// #24
    40f4:	97fffcf7 	bl	34d0 <fwp_heap_alloc_slow>
    40f8:	aa0003f3 	mov	x19, x0
    40fc:	17ffffe7 	b	4098 <fwp_data.part.0.constprop.0+0x178>
    4100:	97fff714 	bl	1d50 <fwp_heap_oom>

0000000000004104 <fwp_map_finish_protected.isra.0>:
    4104:	d10183ff 	sub	sp, sp, #0x60
    4108:	a9027bfd 	stp	x29, x30, [sp, #32]
    410c:	910083fd 	add	x29, sp, #0x20
    4110:	a90563f7 	stp	x23, x24, [sp, #80]
    4114:	aa0003f7 	mov	x23, x0
    4118:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    411c:	f947f400 	ldr	x0, [x0, #4072]
    4120:	a9045bf5 	stp	x21, x22, [sp, #64]
    4124:	a940d6e2 	ldp	x2, x21, [x23, #8]
    4128:	f9400001 	ldr	x1, [x0]
    412c:	f9000fe1 	str	x1, [sp, #24]
    4130:	d2800001 	mov	x1, #0x0                   	// #0
    4134:	b4000602 	cbz	x2, 41f4 <fwp_map_finish_protected.isra.0+0xf0>
    4138:	b0000178 	adrp	x24, 31000 <fwp_root_context+0xcb0>
    413c:	9114c318 	add	x24, x24, #0x530
    4140:	a90353f3 	stp	x19, x20, [sp, #48]
    4144:	910023f3 	add	x19, sp, #0x8
    4148:	52800034 	mov	w20, #0x1                   	// #1
    414c:	d503201f 	nop
    4150:	f94002e3 	ldr	x3, [x23]
    4154:	aa1303e1 	mov	x1, x19
    4158:	52800020 	mov	w0, #0x1                   	// #1
    415c:	8b020c62 	add	x2, x3, x2, lsl #3
    4160:	f85f8042 	ldur	x2, [x2, #-8]
    4164:	a900d7e2 	stp	x2, x21, [sp, #8]
    4168:	97ffff6e 	bl	3f20 <fwp_data.part.0.constprop.0>
    416c:	aa0003f5 	mov	x21, x0
    4170:	f949db01 	ldr	x1, [x24, #5040]
    4174:	f949ef02 	ldr	x2, [x24, #5080]
    4178:	cb010001 	sub	x1, x0, x1
    417c:	eb02403f 	cmp	x1, x2, lsl #16
    4180:	54000302 	b.cs	41e0 <fwp_map_finish_protected.isra.0+0xdc>  // b.hs, b.nlast
    4184:	d350fc22 	lsr	x2, x1, #16
    4188:	f949ff04 	ldr	x4, [x24, #5112]
    418c:	8b020842 	add	x2, x2, x2, lsl #2
    4190:	d37df042 	lsl	x2, x2, #3
    4194:	8b020083 	add	x3, x4, x2
    4198:	f9401076 	ldr	x22, [x3, #32]
    419c:	b4000236 	cbz	x22, 41e0 <fwp_map_finish_protected.isra.0+0xdc>
    41a0:	38626882 	ldrb	w2, [x4, x2]
    41a4:	7100085f 	cmp	w2, #0x2
    41a8:	540004a0 	b.eq	423c <fwp_map_finish_protected.isra.0+0x138>  // b.none
    41ac:	7100045f 	cmp	w2, #0x1
    41b0:	54000181 	b.ne	41e0 <fwp_map_finish_protected.isra.0+0xdc>  // b.any
    41b4:	29430062 	ldp	w2, w0, [x3, #24]
    41b8:	92403c21 	and	x1, x1, #0xffff
    41bc:	9b027c21 	mul	x1, x1, x2
    41c0:	d360fc21 	lsr	x1, x1, #32
    41c4:	eb00003f 	cmp	x1, x0
    41c8:	540000c2 	b.cs	41e0 <fwp_map_finish_protected.isra.0+0xdc>  // b.hs, b.nlast
    41cc:	8b0102d6 	add	x22, x22, x1
    41d0:	394002c0 	ldrb	w0, [x22]
    41d4:	7103fc1f 	cmp	w0, #0xff
    41d8:	540002c0 	b.eq	4230 <fwp_map_finish_protected.isra.0+0x12c>  // b.none
    41dc:	390002d4 	strb	w20, [x22]
    41e0:	f94006e2 	ldr	x2, [x23, #8]
    41e4:	d1000442 	sub	x2, x2, #0x1
    41e8:	a900d6e2 	stp	x2, x21, [x23, #8]
    41ec:	b5fffb22 	cbnz	x2, 4150 <fwp_map_finish_protected.isra.0+0x4c>
    41f0:	a94353f3 	ldp	x19, x20, [sp, #48]
    41f4:	f94002e0 	ldr	x0, [x23]
    41f8:	97fffbee 	bl	31b0 <fwp_mem_free>
    41fc:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    4200:	f947f400 	ldr	x0, [x0, #4072]
    4204:	f9400fe2 	ldr	x2, [sp, #24]
    4208:	f9400001 	ldr	x1, [x0]
    420c:	eb010042 	subs	x2, x2, x1
    4210:	d2800001 	mov	x1, #0x0                   	// #0
    4214:	540001a1 	b.ne	4248 <fwp_map_finish_protected.isra.0+0x144>  // b.any
    4218:	a9427bfd 	ldp	x29, x30, [sp, #32]
    421c:	aa1503e0 	mov	x0, x21
    4220:	a9445bf5 	ldp	x21, x22, [sp, #64]
    4224:	a94563f7 	ldp	x23, x24, [sp, #80]
    4228:	910183ff 	add	sp, sp, #0x60
    422c:	d65f03c0 	ret
    4230:	aa1603e0 	mov	x0, x22
    4234:	97fffb3f 	bl	2f30 <fwp_rc_forget_slot>
    4238:	17ffffe9 	b	41dc <fwp_map_finish_protected.isra.0+0xd8>
    423c:	72003c3f 	tst	w1, #0xffff
    4240:	54fffd01 	b.ne	41e0 <fwp_map_finish_protected.isra.0+0xdc>  // b.any
    4244:	17ffffe3 	b	41d0 <fwp_map_finish_protected.isra.0+0xcc>
    4248:	a90353f3 	stp	x19, x20, [sp, #48]
    424c:	97fff4c1 	bl	1550 <__stack_chk_fail@plt>

0000000000004250 <fwp_map_items>:
    4250:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4254:	910003fd 	mov	x29, sp
    4258:	a90153f3 	stp	x19, x20, [sp, #16]
    425c:	aa0003f3 	mov	x19, x0
    4260:	a9025bf5 	stp	x21, x22, [sp, #32]
    4264:	a90363f7 	stp	x23, x24, [sp, #48]
    4268:	f90023f9 	str	x25, [sp, #64]
    426c:	b4000dc0 	cbz	x0, 4424 <fwp_map_items+0x1d4>
    4270:	aa0003e2 	mov	x2, x0
    4274:	d2800000 	mov	x0, #0x0                   	// #0
    4278:	f9400842 	ldr	x2, [x2, #16]
    427c:	aa0003e3 	mov	x3, x0
    4280:	91000400 	add	x0, x0, #0x1
    4284:	b5ffffa2 	cbnz	x2, 4278 <fwp_map_items+0x28>
    4288:	f9000020 	str	x0, [x1]
    428c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    4290:	eb01001f 	cmp	x0, x1
    4294:	54000d28 	b.hi	4438 <fwp_map_items+0x1e8>  // b.pmore
    4298:	91000860 	add	x0, x3, #0x2
    429c:	d37df000 	lsl	x0, x0, #3
    42a0:	f140101f 	cmp	x0, #0x4, lsl #12
    42a4:	1a9f87e4 	cset	w4, ls	// ls = plast
    42a8:	900000f4 	adrp	x20, 20000 <__data_start>
    42ac:	91014281 	add	x1, x20, #0x50
    42b0:	b9404035 	ldr	w21, [x1, #64]
    42b4:	350007d5 	cbnz	w21, 43ac <fwp_map_items+0x15c>
    42b8:	b0000178 	adrp	x24, 31000 <fwp_root_context+0xcb0>
    42bc:	9114c319 	add	x25, x24, #0x530
    42c0:	b953a721 	ldr	w1, [x25, #5028]
    42c4:	7100003f 	cmp	w1, #0x0
    42c8:	7a401884 	ccmp	w4, #0x0, #0x4, ne	// ne = any
    42cc:	54000880 	b.eq	43dc <fwp_map_items+0x18c>  // b.none
    42d0:	91003c01 	add	x1, x0, #0xf
    42d4:	8b411321 	add	x1, x25, x1, lsr #4
    42d8:	397e8021 	ldrb	w1, [x1, #4000]
    42dc:	910f0022 	add	x2, x1, #0x3c0
    42e0:	8b010421 	add	x1, x1, x1, lsl #1
    42e4:	8b010f23 	add	x3, x25, x1, lsl #3
    42e8:	b8627b37 	ldr	w23, [x25, x2, lsl #2]
    42ec:	2a1703f6 	mov	w22, w23
    42f0:	f943c064 	ldr	x4, [x3, #1920]
    42f4:	b40007c4 	cbz	x4, 43ec <fwp_map_items+0x19c>
    42f8:	f9400085 	ldr	x5, [x4]
    42fc:	aa1603e2 	mov	x2, x22
    4300:	aa0403e0 	mov	x0, x4
    4304:	52800001 	mov	w1, #0x0                   	// #0
    4308:	aa2503e5 	mvn	x5, x5
    430c:	f903c065 	str	x5, [x3, #1920]
    4310:	97fff484 	bl	1520 <memset@plt>
    4314:	aa0003e4 	mov	x4, x0
    4318:	f94a1320 	ldr	x0, [x25, #5152]
    431c:	ab160000 	adds	x0, x0, x22
    4320:	540008a2 	b.cs	4434 <fwp_map_items+0x1e4>  // b.hs, b.nlast
    4324:	f94a1721 	ldr	x1, [x25, #5160]
    4328:	f90a1320 	str	x0, [x25, #5152]
    432c:	eb01001f 	cmp	x0, x1
    4330:	54000049 	b.ls	4338 <fwp_map_items+0xe8>  // b.plast
    4334:	f90a1720 	str	x0, [x25, #5160]
    4338:	9114c300 	add	x0, x24, #0x530
    433c:	1e6302e1 	ucvtf	d1, w23
    4340:	fd4a1c00 	ldr	d0, [x0, #5176]
    4344:	1e612800 	fadd	d0, d0, d1
    4348:	fd0a1c00 	str	d0, [x0, #5176]
    434c:	34000155 	cbz	w21, 4374 <fwp_map_items+0x124>
    4350:	9114c300 	add	x0, x24, #0x530
    4354:	91014294 	add	x20, x20, #0x50
    4358:	fd4a1000 	ldr	d0, [x0, #5152]
    435c:	fd415e82 	ldr	d2, [x20, #696]
    4360:	fd416281 	ldr	d1, [x20, #704]
    4364:	7e61d800 	ucvtf	d0, d0
    4368:	1e623800 	fsub	d0, d0, d2
    436c:	1e612010 	fcmpe	d0, d1
    4370:	5400056c 	b.gt	441c <fwp_map_items+0x1cc>
    4374:	aa0403e1 	mov	x1, x4
    4378:	b40000d3 	cbz	x19, 4390 <fwp_map_items+0x140>
    437c:	d503201f 	nop
    4380:	f9400662 	ldr	x2, [x19, #8]
    4384:	f8008422 	str	x2, [x1], #8
    4388:	f9400a73 	ldr	x19, [x19, #16]
    438c:	b5ffffb3 	cbnz	x19, 4380 <fwp_map_items+0x130>
    4390:	a94153f3 	ldp	x19, x20, [sp, #16]
    4394:	aa0403e0 	mov	x0, x4
    4398:	a9425bf5 	ldp	x21, x22, [sp, #32]
    439c:	a94363f7 	ldp	x23, x24, [sp, #48]
    43a0:	f94023f9 	ldr	x25, [sp, #64]
    43a4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    43a8:	d65f03c0 	ret
    43ac:	f9415423 	ldr	x3, [x1, #680]
    43b0:	b0000178 	adrp	x24, 31000 <fwp_root_context+0xcb0>
    43b4:	f9415822 	ldr	x2, [x1, #688]
    43b8:	9114c319 	add	x25, x24, #0x530
    43bc:	91000463 	add	x3, x3, #0x1
    43c0:	f9015423 	str	x3, [x1, #680]
    43c4:	8b000042 	add	x2, x2, x0
    43c8:	f9015822 	str	x2, [x1, #688]
    43cc:	b953a721 	ldr	w1, [x25, #5028]
    43d0:	7100003f 	cmp	w1, #0x0
    43d4:	7a401884 	ccmp	w4, #0x0, #0x4, ne	// ne = any
    43d8:	54fff7c1 	b.ne	42d0 <fwp_map_items+0x80>  // b.any
    43dc:	52800041 	mov	w1, #0x2                   	// #2
    43e0:	97fffc3c 	bl	34d0 <fwp_heap_alloc_slow>
    43e4:	aa0003e4 	mov	x4, x0
    43e8:	17ffffd9 	b	434c <fwp_map_items+0xfc>
    43ec:	f943c464 	ldr	x4, [x3, #1928]
    43f0:	b4ffff64 	cbz	x4, 43dc <fwp_map_items+0x18c>
    43f4:	f943c861 	ldr	x1, [x3, #1936]
    43f8:	cb040021 	sub	x1, x1, x4
    43fc:	eb0102df 	cmp	x22, x1
    4400:	54fffee8 	b.hi	43dc <fwp_map_items+0x18c>  // b.pmore
    4404:	8b160085 	add	x5, x4, x22
    4408:	aa1603e2 	mov	x2, x22
    440c:	aa0403e0 	mov	x0, x4
    4410:	52800001 	mov	w1, #0x0                   	// #0
    4414:	f903c465 	str	x5, [x3, #1928]
    4418:	17ffffbe 	b	4310 <fwp_map_items+0xc0>
    441c:	fd016280 	str	d0, [x20, #704]
    4420:	17ffffd5 	b	4374 <fwp_map_items+0x124>
    4424:	52800024 	mov	w4, #0x1                   	// #1
    4428:	d2800100 	mov	x0, #0x8                   	// #8
    442c:	f900003f 	str	xzr, [x1]
    4430:	17ffff9e 	b	42a8 <fwp_map_items+0x58>
    4434:	97fff647 	bl	1d50 <fwp_heap_oom>
    4438:	d0000020 	adrp	x0, a000 <__divti3+0x2e0>
    443c:	911ea000 	add	x0, x0, #0x7a8
    4440:	97fff7b0 	bl	2300 <fwp_trap>

0000000000004444 <fwp_drop4>:
    4444:	b0000165 	adrp	x5, 31000 <fwp_root_context+0xcb0>
    4448:	9114c0a3 	add	x3, x5, #0x530
    444c:	f949d861 	ldr	x1, [x3, #5040]
    4450:	f949ec62 	ldr	x2, [x3, #5080]
    4454:	cb010001 	sub	x1, x0, x1
    4458:	eb02403f 	cmp	x1, x2, lsl #16
    445c:	54000542 	b.cs	4504 <fwp_drop4+0xc0>  // b.hs, b.nlast
    4460:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4464:	d350fc22 	lsr	x2, x1, #16
    4468:	910003fd 	mov	x29, sp
    446c:	8b020842 	add	x2, x2, x2, lsl #2
    4470:	f949fc64 	ldr	x4, [x3, #5112]
    4474:	d37df042 	lsl	x2, x2, #3
    4478:	f9000bf3 	str	x19, [sp, #16]
    447c:	8b020083 	add	x3, x4, x2
    4480:	f9401073 	ldr	x19, [x3, #32]
    4484:	b40002b3 	cbz	x19, 44d8 <fwp_drop4+0x94>
    4488:	38626882 	ldrb	w2, [x4, x2]
    448c:	7100085f 	cmp	w2, #0x2
    4490:	540002a0 	b.eq	44e4 <fwp_drop4+0xa0>  // b.none
    4494:	7100045f 	cmp	w2, #0x1
    4498:	54000201 	b.ne	44d8 <fwp_drop4+0x94>  // b.any
    449c:	29430864 	ldp	w4, w2, [x3, #24]
    44a0:	92403c21 	and	x1, x1, #0xffff
    44a4:	9b047c21 	mul	x1, x1, x4
    44a8:	d360fc21 	lsr	x1, x1, #32
    44ac:	eb02003f 	cmp	x1, x2
    44b0:	54000142 	b.cs	44d8 <fwp_drop4+0x94>  // b.hs, b.nlast
    44b4:	8b010273 	add	x19, x19, x1
    44b8:	39400261 	ldrb	w1, [x19]
    44bc:	340000e1 	cbz	w1, 44d8 <fwp_drop4+0x94>
    44c0:	7100043f 	cmp	w1, #0x1
    44c4:	540001a0 	b.eq	44f8 <fwp_drop4+0xb4>  // b.none
    44c8:	7103fc3f 	cmp	w1, #0xff
    44cc:	540001e0 	b.eq	4508 <fwp_drop4+0xc4>  // b.none
    44d0:	51000421 	sub	w1, w1, #0x1
    44d4:	39000261 	strb	w1, [x19]
    44d8:	f9400bf3 	ldr	x19, [sp, #16]
    44dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    44e0:	d65f03c0 	ret
    44e4:	72003c3f 	tst	w1, #0xffff
    44e8:	54fffe80 	b.eq	44b8 <fwp_drop4+0x74>  // b.none
    44ec:	f9400bf3 	ldr	x19, [sp, #16]
    44f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    44f4:	d65f03c0 	ret
    44f8:	f9400bf3 	ldr	x19, [sp, #16]
    44fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4500:	17fffb2c 	b	31b0 <fwp_mem_free>
    4504:	d65f03c0 	ret
    4508:	ca534660 	eor	x0, x19, x19, lsr #17
    450c:	9114c0a5 	add	x5, x5, #0x530
    4510:	ca402400 	eor	x0, x0, x0, lsr #9
    4514:	8b200ca0 	add	x0, x5, w0, uxtb #3
    4518:	f94a2400 	ldr	x0, [x0, #5192]
    451c:	b5000080 	cbnz	x0, 452c <fwp_drop4+0xe8>
    4520:	14000010 	b	4560 <fwp_drop4+0x11c>
    4524:	f9400800 	ldr	x0, [x0, #16]
    4528:	b40001c0 	cbz	x0, 4560 <fwp_drop4+0x11c>
    452c:	f9400001 	ldr	x1, [x0]
    4530:	eb13003f 	cmp	x1, x19
    4534:	54ffff81 	b.ne	4524 <fwp_drop4+0xe0>  // b.any
    4538:	f9400401 	ldr	x1, [x0, #8]
    453c:	d1000421 	sub	x1, x1, #0x1
    4540:	f9000401 	str	x1, [x0, #8]
    4544:	f103f83f 	cmp	x1, #0xfe
    4548:	54fffc81 	b.ne	44d8 <fwp_drop4+0x94>  // b.any
    454c:	aa1303e0 	mov	x0, x19
    4550:	97fffa78 	bl	2f30 <fwp_rc_forget_slot>
    4554:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4558:	39000260 	strb	w0, [x19]
    455c:	17ffffdf 	b	44d8 <fwp_drop4+0x94>
    4560:	d0000020 	adrp	x0, a000 <__divti3+0x2e0>
    4564:	911c8000 	add	x0, x0, #0x720
    4568:	97fff766 	bl	2300 <fwp_trap>
    456c:	d503201f 	nop

0000000000004570 <fwp_owned_entry50>:
    4570:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4574:	910003fd 	mov	x29, sp
    4578:	f9400000 	ldr	x0, [x0]
    457c:	f9000bf3 	str	x19, [sp, #16]
    4580:	f9400813 	ldr	x19, [x0, #16]
    4584:	97ffffb0 	bl	4444 <fwp_drop4>
    4588:	aa1303e0 	mov	x0, x19
    458c:	f9400bf3 	ldr	x19, [sp, #16]
    4590:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4594:	d65f03c0 	ret
    4598:	d503201f 	nop
    459c:	d503201f 	nop

00000000000045a0 <fwp_owned_entry47>:
    45a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    45a4:	910003fd 	mov	x29, sp
    45a8:	f9400000 	ldr	x0, [x0]
    45ac:	f9000bf3 	str	x19, [sp, #16]
    45b0:	f9400413 	ldr	x19, [x0, #8]
    45b4:	97ffffa4 	bl	4444 <fwp_drop4>
    45b8:	aa1303e0 	mov	x0, x19
    45bc:	f9400bf3 	ldr	x19, [sp, #16]
    45c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45c4:	d65f03c0 	ret
    45c8:	d503201f 	nop
    45cc:	d503201f 	nop

00000000000045d0 <fwp_arg_drop47>:
    45d0:	7100003f 	cmp	w1, #0x0
    45d4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    45d8:	54000041 	b.ne	45e0 <fwp_arg_drop47+0x10>  // b.any
    45dc:	d65f03c0 	ret
    45e0:	f9400000 	ldr	x0, [x0]
    45e4:	17ffff98 	b	4444 <fwp_drop4>
    45e8:	d503201f 	nop
    45ec:	d503201f 	nop

00000000000045f0 <e50>:
    45f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    45f4:	910003fd 	mov	x29, sp
    45f8:	a90153f3 	stp	x19, x20, [sp, #16]
    45fc:	f9400013 	ldr	x19, [x0]
    4600:	aa1303e0 	mov	x0, x19
    4604:	97fffc0b 	bl	3630 <fwp_rc_share>
    4608:	f9400a74 	ldr	x20, [x19, #16]
    460c:	aa1303e0 	mov	x0, x19
    4610:	97ffff8d 	bl	4444 <fwp_drop4>
    4614:	aa1403e0 	mov	x0, x20
    4618:	97fffc06 	bl	3630 <fwp_rc_share>
    461c:	aa1403e0 	mov	x0, x20
    4620:	a94153f3 	ldp	x19, x20, [sp, #16]
    4624:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4628:	d65f03c0 	ret
    462c:	d503201f 	nop

0000000000004630 <e47>:
    4630:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4634:	910003fd 	mov	x29, sp
    4638:	a90153f3 	stp	x19, x20, [sp, #16]
    463c:	f9400013 	ldr	x19, [x0]
    4640:	aa1303e0 	mov	x0, x19
    4644:	97fffbfb 	bl	3630 <fwp_rc_share>
    4648:	f9400674 	ldr	x20, [x19, #8]
    464c:	aa1303e0 	mov	x0, x19
    4650:	97ffff7d 	bl	4444 <fwp_drop4>
    4654:	aa1403e0 	mov	x0, x20
    4658:	97fffbf6 	bl	3630 <fwp_rc_share>
    465c:	aa1403e0 	mov	x0, x20
    4660:	a94153f3 	ldp	x19, x20, [sp, #16]
    4664:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4668:	d65f03c0 	ret
    466c:	d503201f 	nop

0000000000004670 <fwp_arg_drop50>:
    4670:	7100003f 	cmp	w1, #0x0
    4674:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4678:	54000041 	b.ne	4680 <fwp_arg_drop50+0x10>  // b.any
    467c:	d65f03c0 	ret
    4680:	f9400000 	ldr	x0, [x0]
    4684:	17ffff70 	b	4444 <fwp_drop4>
    4688:	d503201f 	nop
    468c:	d503201f 	nop

0000000000004690 <fwp_drop0>:
    4690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4694:	910003fd 	mov	x29, sp
    4698:	a90153f3 	stp	x19, x20, [sp, #16]
    469c:	f90013f5 	str	x21, [sp, #32]
    46a0:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    46a4:	9114c2b4 	add	x20, x21, #0x530
    46a8:	f949da81 	ldr	x1, [x20, #5040]
    46ac:	f949ee82 	ldr	x2, [x20, #5080]
    46b0:	cb010001 	sub	x1, x0, x1
    46b4:	eb02403f 	cmp	x1, x2, lsl #16
    46b8:	54000382 	b.cs	4728 <fwp_drop0+0x98>  // b.hs, b.nlast
    46bc:	d350fc22 	lsr	x2, x1, #16
    46c0:	f949fe83 	ldr	x3, [x20, #5112]
    46c4:	8b020842 	add	x2, x2, x2, lsl #2
    46c8:	d37df042 	lsl	x2, x2, #3
    46cc:	8b020064 	add	x4, x3, x2
    46d0:	f9401093 	ldr	x19, [x4, #32]
    46d4:	b40002b3 	cbz	x19, 4728 <fwp_drop0+0x98>
    46d8:	38626862 	ldrb	w2, [x3, x2]
    46dc:	7100085f 	cmp	w2, #0x2
    46e0:	540002c0 	b.eq	4738 <fwp_drop0+0xa8>  // b.none
    46e4:	7100045f 	cmp	w2, #0x1
    46e8:	54000201 	b.ne	4728 <fwp_drop0+0x98>  // b.any
    46ec:	29430885 	ldp	w5, w2, [x4, #24]
    46f0:	92403c21 	and	x1, x1, #0xffff
    46f4:	9b057c21 	mul	x1, x1, x5
    46f8:	d360fc21 	lsr	x1, x1, #32
    46fc:	eb02003f 	cmp	x1, x2
    4700:	54000142 	b.cs	4728 <fwp_drop0+0x98>  // b.hs, b.nlast
    4704:	8b010273 	add	x19, x19, x1
    4708:	39400261 	ldrb	w1, [x19]
    470c:	340000e1 	cbz	w1, 4728 <fwp_drop0+0x98>
    4710:	7100043f 	cmp	w1, #0x1
    4714:	540001e0 	b.eq	4750 <fwp_drop0+0xc0>  // b.none
    4718:	7103fc3f 	cmp	w1, #0xff
    471c:	540006e0 	b.eq	47f8 <fwp_drop0+0x168>  // b.none
    4720:	51000421 	sub	w1, w1, #0x1
    4724:	39000261 	strb	w1, [x19]
    4728:	a94153f3 	ldp	x19, x20, [sp, #16]
    472c:	f94013f5 	ldr	x21, [sp, #32]
    4730:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4734:	d65f03c0 	ret
    4738:	72003c3f 	tst	w1, #0xffff
    473c:	54fffe60 	b.eq	4708 <fwp_drop0+0x78>  // b.none
    4740:	a94153f3 	ldp	x19, x20, [sp, #16]
    4744:	f94013f5 	ldr	x21, [sp, #32]
    4748:	a8c37bfd 	ldp	x29, x30, [sp], #48
    474c:	d65f03c0 	ret
    4750:	9114c2a1 	add	x1, x21, #0x530
    4754:	f9400813 	ldr	x19, [x0, #16]
    4758:	f949ec25 	ldr	x5, [x1, #5080]
    475c:	f949d821 	ldr	x1, [x1, #5040]
    4760:	d370bca5 	lsl	x5, x5, #16
    4764:	cb010002 	sub	x2, x0, x1
    4768:	eb05005f 	cmp	x2, x5
    476c:	54000362 	b.cs	47d8 <fwp_drop0+0x148>  // b.hs, b.nlast
    4770:	d350fc44 	lsr	x4, x2, #16
    4774:	8b040884 	add	x4, x4, x4, lsl #2
    4778:	d37df084 	lsl	x4, x4, #3
    477c:	8b040067 	add	x7, x3, x4
    4780:	f94010e6 	ldr	x6, [x7, #32]
    4784:	b40002a6 	cbz	x6, 47d8 <fwp_drop0+0x148>
    4788:	38646863 	ldrb	w3, [x3, x4]
    478c:	7100087f 	cmp	w3, #0x2
    4790:	540002e0 	b.eq	47ec <fwp_drop0+0x15c>  // b.none
    4794:	7100047f 	cmp	w3, #0x1
    4798:	54000201 	b.ne	47d8 <fwp_drop0+0x148>  // b.any
    479c:	29430ce4 	ldp	w4, w3, [x7, #24]
    47a0:	92403c42 	and	x2, x2, #0xffff
    47a4:	9b047c42 	mul	x2, x2, x4
    47a8:	d360fc42 	lsr	x2, x2, #32
    47ac:	eb03005f 	cmp	x2, x3
    47b0:	54000142 	b.cs	47d8 <fwp_drop0+0x148>  // b.hs, b.nlast
    47b4:	8b0200c6 	add	x6, x6, x2
    47b8:	394000c2 	ldrb	w2, [x6]
    47bc:	7100045f 	cmp	w2, #0x1
    47c0:	540000c1 	b.ne	47d8 <fwp_drop0+0x148>  // b.any
    47c4:	97fffa7b 	bl	31b0 <fwp_mem_free>
    47c8:	9114c2a0 	add	x0, x21, #0x530
    47cc:	f949ec05 	ldr	x5, [x0, #5080]
    47d0:	f949d801 	ldr	x1, [x0, #5040]
    47d4:	d370bca5 	lsl	x5, x5, #16
    47d8:	cb010261 	sub	x1, x19, x1
    47dc:	eb05003f 	cmp	x1, x5
    47e0:	54fffa42 	b.cs	4728 <fwp_drop0+0x98>  // b.hs, b.nlast
    47e4:	aa1303e0 	mov	x0, x19
    47e8:	17ffffb5 	b	46bc <fwp_drop0+0x2c>
    47ec:	72003c5f 	tst	w2, #0xffff
    47f0:	54ffff41 	b.ne	47d8 <fwp_drop0+0x148>  // b.any
    47f4:	17fffff1 	b	47b8 <fwp_drop0+0x128>
    47f8:	ca534661 	eor	x1, x19, x19, lsr #17
    47fc:	9114c2a0 	add	x0, x21, #0x530
    4800:	ca412421 	eor	x1, x1, x1, lsr #9
    4804:	8b210c01 	add	x1, x0, w1, uxtb #3
    4808:	f94a2420 	ldr	x0, [x1, #5192]
    480c:	b5000080 	cbnz	x0, 481c <fwp_drop0+0x18c>
    4810:	14000010 	b	4850 <fwp_drop0+0x1c0>
    4814:	f9400800 	ldr	x0, [x0, #16]
    4818:	b40001c0 	cbz	x0, 4850 <fwp_drop0+0x1c0>
    481c:	f9400001 	ldr	x1, [x0]
    4820:	eb13003f 	cmp	x1, x19
    4824:	54ffff81 	b.ne	4814 <fwp_drop0+0x184>  // b.any
    4828:	f9400401 	ldr	x1, [x0, #8]
    482c:	d1000421 	sub	x1, x1, #0x1
    4830:	f9000401 	str	x1, [x0, #8]
    4834:	f103f83f 	cmp	x1, #0xfe
    4838:	54fff781 	b.ne	4728 <fwp_drop0+0x98>  // b.any
    483c:	aa1303e0 	mov	x0, x19
    4840:	97fff9bc 	bl	2f30 <fwp_rc_forget_slot>
    4844:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4848:	39000260 	strb	w0, [x19]
    484c:	17ffffb7 	b	4728 <fwp_drop0+0x98>
    4850:	d0000020 	adrp	x0, a000 <__divti3+0x2e0>
    4854:	911c8000 	add	x0, x0, #0x720
    4858:	97fff6aa 	bl	2300 <fwp_trap>
    485c:	d503201f 	nop

0000000000004860 <fwp_drop1>:
    4860:	17ffff8c 	b	4690 <fwp_drop0>

0000000000004864 <fwp_drop6>:
    4864:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4868:	910003fd 	mov	x29, sp
    486c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4870:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    4874:	9114c2d5 	add	x21, x22, #0x530
    4878:	a90153f3 	stp	x19, x20, [sp, #16]
    487c:	aa0003f3 	mov	x19, x0
    4880:	f949daa1 	ldr	x1, [x21, #5040]
    4884:	f949eea0 	ldr	x0, [x21, #5080]
    4888:	cb010261 	sub	x1, x19, x1
    488c:	eb00403f 	cmp	x1, x0, lsl #16
    4890:	54000382 	b.cs	4900 <fwp_drop6+0x9c>  // b.hs, b.nlast
    4894:	d350fc22 	lsr	x2, x1, #16
    4898:	f949fea3 	ldr	x3, [x21, #5112]
    489c:	8b020842 	add	x2, x2, x2, lsl #2
    48a0:	d37df042 	lsl	x2, x2, #3
    48a4:	8b020060 	add	x0, x3, x2
    48a8:	f9401014 	ldr	x20, [x0, #32]
    48ac:	b40002b4 	cbz	x20, 4900 <fwp_drop6+0x9c>
    48b0:	38626862 	ldrb	w2, [x3, x2]
    48b4:	7100085f 	cmp	w2, #0x2
    48b8:	540002c0 	b.eq	4910 <fwp_drop6+0xac>  // b.none
    48bc:	7100045f 	cmp	w2, #0x1
    48c0:	54000201 	b.ne	4900 <fwp_drop6+0x9c>  // b.any
    48c4:	29430002 	ldp	w2, w0, [x0, #24]
    48c8:	92403c21 	and	x1, x1, #0xffff
    48cc:	9b027c21 	mul	x1, x1, x2
    48d0:	d360fc21 	lsr	x1, x1, #32
    48d4:	eb00003f 	cmp	x1, x0
    48d8:	54000142 	b.cs	4900 <fwp_drop6+0x9c>  // b.hs, b.nlast
    48dc:	8b010294 	add	x20, x20, x1
    48e0:	39400280 	ldrb	w0, [x20]
    48e4:	340000e0 	cbz	w0, 4900 <fwp_drop6+0x9c>
    48e8:	7100041f 	cmp	w0, #0x1
    48ec:	540001e0 	b.eq	4928 <fwp_drop6+0xc4>  // b.none
    48f0:	7103fc1f 	cmp	w0, #0xff
    48f4:	54000760 	b.eq	49e0 <fwp_drop6+0x17c>  // b.none
    48f8:	51000400 	sub	w0, w0, #0x1
    48fc:	39000280 	strb	w0, [x20]
    4900:	a94153f3 	ldp	x19, x20, [sp, #16]
    4904:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4908:	a8c37bfd 	ldp	x29, x30, [sp], #48
    490c:	d65f03c0 	ret
    4910:	72003c3f 	tst	w1, #0xffff
    4914:	54fffe60 	b.eq	48e0 <fwp_drop6+0x7c>  // b.none
    4918:	a94153f3 	ldp	x19, x20, [sp, #16]
    491c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4920:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4924:	d65f03c0 	ret
    4928:	f9400660 	ldr	x0, [x19, #8]
    492c:	97fffec6 	bl	4444 <fwp_drop4>
    4930:	9114c2c4 	add	x4, x22, #0x530
    4934:	f9400a74 	ldr	x20, [x19, #16]
    4938:	f949ec83 	ldr	x3, [x4, #5080]
    493c:	f949d881 	ldr	x1, [x4, #5040]
    4940:	d370bc63 	lsl	x3, x3, #16
    4944:	cb010262 	sub	x2, x19, x1
    4948:	eb03005f 	cmp	x2, x3
    494c:	540003a2 	b.cs	49c0 <fwp_drop6+0x15c>  // b.hs, b.nlast
    4950:	d350fc40 	lsr	x0, x2, #16
    4954:	f949fc86 	ldr	x6, [x4, #5112]
    4958:	8b000800 	add	x0, x0, x0, lsl #2
    495c:	d37df000 	lsl	x0, x0, #3
    4960:	8b0000c5 	add	x5, x6, x0
    4964:	f94010a4 	ldr	x4, [x5, #32]
    4968:	b40002c4 	cbz	x4, 49c0 <fwp_drop6+0x15c>
    496c:	386068c0 	ldrb	w0, [x6, x0]
    4970:	7100081f 	cmp	w0, #0x2
    4974:	54000300 	b.eq	49d4 <fwp_drop6+0x170>  // b.none
    4978:	7100041f 	cmp	w0, #0x1
    497c:	54000221 	b.ne	49c0 <fwp_drop6+0x15c>  // b.any
    4980:	92403c40 	and	x0, x2, #0xffff
    4984:	294308a6 	ldp	w6, w2, [x5, #24]
    4988:	9b067c00 	mul	x0, x0, x6
    498c:	d360fc00 	lsr	x0, x0, #32
    4990:	eb02001f 	cmp	x0, x2
    4994:	54000162 	b.cs	49c0 <fwp_drop6+0x15c>  // b.hs, b.nlast
    4998:	8b000084 	add	x4, x4, x0
    499c:	39400080 	ldrb	w0, [x4]
    49a0:	7100041f 	cmp	w0, #0x1
    49a4:	540000e1 	b.ne	49c0 <fwp_drop6+0x15c>  // b.any
    49a8:	aa1303e0 	mov	x0, x19
    49ac:	97fffa01 	bl	31b0 <fwp_mem_free>
    49b0:	9114c2c0 	add	x0, x22, #0x530
    49b4:	f949ec03 	ldr	x3, [x0, #5080]
    49b8:	f949d801 	ldr	x1, [x0, #5040]
    49bc:	d370bc63 	lsl	x3, x3, #16
    49c0:	cb010281 	sub	x1, x20, x1
    49c4:	eb01007f 	cmp	x3, x1
    49c8:	54fff9c9 	b.ls	4900 <fwp_drop6+0x9c>  // b.plast
    49cc:	aa1403f3 	mov	x19, x20
    49d0:	17ffffb1 	b	4894 <fwp_drop6+0x30>
    49d4:	72003c5f 	tst	w2, #0xffff
    49d8:	54ffff41 	b.ne	49c0 <fwp_drop6+0x15c>  // b.any
    49dc:	17fffff0 	b	499c <fwp_drop6+0x138>
    49e0:	ca544681 	eor	x1, x20, x20, lsr #17
    49e4:	9114c2c0 	add	x0, x22, #0x530
    49e8:	ca412421 	eor	x1, x1, x1, lsr #9
    49ec:	8b210c01 	add	x1, x0, w1, uxtb #3
    49f0:	f94a2420 	ldr	x0, [x1, #5192]
    49f4:	b5000080 	cbnz	x0, 4a04 <fwp_drop6+0x1a0>
    49f8:	14000010 	b	4a38 <fwp_drop6+0x1d4>
    49fc:	f9400800 	ldr	x0, [x0, #16]
    4a00:	b40001c0 	cbz	x0, 4a38 <fwp_drop6+0x1d4>
    4a04:	f9400001 	ldr	x1, [x0]
    4a08:	eb14003f 	cmp	x1, x20
    4a0c:	54ffff81 	b.ne	49fc <fwp_drop6+0x198>  // b.any
    4a10:	f9400401 	ldr	x1, [x0, #8]
    4a14:	d1000421 	sub	x1, x1, #0x1
    4a18:	f9000401 	str	x1, [x0, #8]
    4a1c:	f103f83f 	cmp	x1, #0xfe
    4a20:	54fff701 	b.ne	4900 <fwp_drop6+0x9c>  // b.any
    4a24:	aa1403e0 	mov	x0, x20
    4a28:	97fff942 	bl	2f30 <fwp_rc_forget_slot>
    4a2c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4a30:	39000280 	strb	w0, [x20]
    4a34:	17ffffb3 	b	4900 <fwp_drop6+0x9c>
    4a38:	d0000020 	adrp	x0, a000 <__divti3+0x2e0>
    4a3c:	911c8000 	add	x0, x0, #0x720
    4a40:	97fff630 	bl	2300 <fwp_trap>

0000000000004a44 <fwp_args47>:
    4a44:	7100003f 	cmp	w1, #0x0
    4a48:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4a4c:	54000041 	b.ne	4a54 <fwp_args47+0x10>  // b.any
    4a50:	d65f03c0 	ret
    4a54:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    4a58:	9114c042 	add	x2, x2, #0x530
    4a5c:	f9400001 	ldr	x1, [x0]
    4a60:	f949d843 	ldr	x3, [x2, #5040]
    4a64:	f949ec40 	ldr	x0, [x2, #5080]
    4a68:	cb030021 	sub	x1, x1, x3
    4a6c:	eb00403f 	cmp	x1, x0, lsl #16
    4a70:	54ffff02 	b.cs	4a50 <fwp_args47+0xc>  // b.hs, b.nlast
    4a74:	d350fc20 	lsr	x0, x1, #16
    4a78:	f949fc44 	ldr	x4, [x2, #5112]
    4a7c:	8b000800 	add	x0, x0, x0, lsl #2
    4a80:	d37df002 	lsl	x2, x0, #3
    4a84:	8b020083 	add	x3, x4, x2
    4a88:	f9401060 	ldr	x0, [x3, #32]
    4a8c:	b4fffe20 	cbz	x0, 4a50 <fwp_args47+0xc>
    4a90:	38626882 	ldrb	w2, [x4, x2]
    4a94:	7100085f 	cmp	w2, #0x2
    4a98:	54000320 	b.eq	4afc <fwp_args47+0xb8>  // b.none
    4a9c:	7100045f 	cmp	w2, #0x1
    4aa0:	54fffd81 	b.ne	4a50 <fwp_args47+0xc>  // b.any
    4aa4:	29430864 	ldp	w4, w2, [x3, #24]
    4aa8:	92403c21 	and	x1, x1, #0xffff
    4aac:	9b047c21 	mul	x1, x1, x4
    4ab0:	d360fc21 	lsr	x1, x1, #32
    4ab4:	eb02003f 	cmp	x1, x2
    4ab8:	54fffcc2 	b.cs	4a50 <fwp_args47+0xc>  // b.hs, b.nlast
    4abc:	8b010000 	add	x0, x0, x1
    4ac0:	39400001 	ldrb	w1, [x0]
    4ac4:	34fffc61 	cbz	w1, 4a50 <fwp_args47+0xc>
    4ac8:	900000e2 	adrp	x2, 20000 <__data_start>
    4acc:	91014042 	add	x2, x2, #0x50
    4ad0:	b9404043 	ldr	w3, [x2, #64]
    4ad4:	350000c3 	cbnz	w3, 4aec <fwp_args47+0xa8>
    4ad8:	7103f43f 	cmp	w1, #0xfd
    4adc:	54000168 	b.hi	4b08 <fwp_args47+0xc4>  // b.pmore
    4ae0:	11000421 	add	w1, w1, #0x1
    4ae4:	39000001 	strb	w1, [x0]
    4ae8:	d65f03c0 	ret
    4aec:	f9402443 	ldr	x3, [x2, #72]
    4af0:	91000463 	add	x3, x3, #0x1
    4af4:	f9002443 	str	x3, [x2, #72]
    4af8:	17fffff8 	b	4ad8 <fwp_args47+0x94>
    4afc:	72003c3f 	tst	w1, #0xffff
    4b00:	54fffe00 	b.eq	4ac0 <fwp_args47+0x7c>  // b.none
    4b04:	d65f03c0 	ret
    4b08:	17fff8c3 	b	2e14 <fwp_rc_wide_dup>
    4b0c:	d503201f 	nop

0000000000004b10 <fwp_args50>:
    4b10:	7100003f 	cmp	w1, #0x0
    4b14:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4b18:	54000041 	b.ne	4b20 <fwp_args50+0x10>  // b.any
    4b1c:	d65f03c0 	ret
    4b20:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    4b24:	9114c042 	add	x2, x2, #0x530
    4b28:	f9400001 	ldr	x1, [x0]
    4b2c:	f949d843 	ldr	x3, [x2, #5040]
    4b30:	f949ec40 	ldr	x0, [x2, #5080]
    4b34:	cb030021 	sub	x1, x1, x3
    4b38:	eb00403f 	cmp	x1, x0, lsl #16
    4b3c:	54ffff02 	b.cs	4b1c <fwp_args50+0xc>  // b.hs, b.nlast
    4b40:	d350fc20 	lsr	x0, x1, #16
    4b44:	f949fc44 	ldr	x4, [x2, #5112]
    4b48:	8b000800 	add	x0, x0, x0, lsl #2
    4b4c:	d37df002 	lsl	x2, x0, #3
    4b50:	8b020083 	add	x3, x4, x2
    4b54:	f9401060 	ldr	x0, [x3, #32]
    4b58:	b4fffe20 	cbz	x0, 4b1c <fwp_args50+0xc>
    4b5c:	38626882 	ldrb	w2, [x4, x2]
    4b60:	7100085f 	cmp	w2, #0x2
    4b64:	54000320 	b.eq	4bc8 <fwp_args50+0xb8>  // b.none
    4b68:	7100045f 	cmp	w2, #0x1
    4b6c:	54fffd81 	b.ne	4b1c <fwp_args50+0xc>  // b.any
    4b70:	29430864 	ldp	w4, w2, [x3, #24]
    4b74:	92403c21 	and	x1, x1, #0xffff
    4b78:	9b047c21 	mul	x1, x1, x4
    4b7c:	d360fc21 	lsr	x1, x1, #32
    4b80:	eb02003f 	cmp	x1, x2
    4b84:	54fffcc2 	b.cs	4b1c <fwp_args50+0xc>  // b.hs, b.nlast
    4b88:	8b010000 	add	x0, x0, x1
    4b8c:	39400001 	ldrb	w1, [x0]
    4b90:	34fffc61 	cbz	w1, 4b1c <fwp_args50+0xc>
    4b94:	900000e2 	adrp	x2, 20000 <__data_start>
    4b98:	91014042 	add	x2, x2, #0x50
    4b9c:	b9404043 	ldr	w3, [x2, #64]
    4ba0:	350000c3 	cbnz	w3, 4bb8 <fwp_args50+0xa8>
    4ba4:	7103f43f 	cmp	w1, #0xfd
    4ba8:	54000168 	b.hi	4bd4 <fwp_args50+0xc4>  // b.pmore
    4bac:	11000421 	add	w1, w1, #0x1
    4bb0:	39000001 	strb	w1, [x0]
    4bb4:	d65f03c0 	ret
    4bb8:	f9402443 	ldr	x3, [x2, #72]
    4bbc:	91000463 	add	x3, x3, #0x1
    4bc0:	f9002443 	str	x3, [x2, #72]
    4bc4:	17fffff8 	b	4ba4 <fwp_args50+0x94>
    4bc8:	72003c3f 	tst	w1, #0xffff
    4bcc:	54fffe00 	b.eq	4b8c <fwp_args50+0x7c>  // b.none
    4bd0:	d65f03c0 	ret
    4bd4:	17fff890 	b	2e14 <fwp_rc_wide_dup>
    4bd8:	d503201f 	nop
    4bdc:	d503201f 	nop

0000000000004be0 <fwp_owned_entry74>:
    4be0:	d10103ff 	sub	sp, sp, #0x40
    4be4:	aa0003e2 	mov	x2, x0
    4be8:	d2f80f21 	mov	x1, #0xc079000000000000    	// #-4577627546245398528
    4bec:	1e6e1002 	fmov	d2, #1.000000000000000000e+00
    4bf0:	9e670020 	fmov	d0, x1
    4bf4:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    4bf8:	a9027bfd 	stp	x29, x30, [sp, #32]
    4bfc:	910083fd 	add	x29, sp, #0x20
    4c00:	9e670004 	fmov	d4, x0
    4c04:	fd400043 	ldr	d3, [x2]
    4c08:	fd400441 	ldr	d1, [x2, #8]
    4c0c:	a90353f3 	stp	x19, x20, [sp, #48]
    4c10:	1e630865 	fmul	d5, d3, d3
    4c14:	1e600860 	fmul	d0, d3, d0
    4c18:	1e633842 	fsub	d2, d2, d3
    4c1c:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x132b8>
    4c20:	f947f442 	ldr	x2, [x2, #4072]
    4c24:	910023e1 	add	x1, sp, #0x8
    4c28:	1e653821 	fsub	d1, d1, d5
    4c2c:	52800000 	mov	w0, #0x0                   	// #0
    4c30:	1e622842 	fadd	d2, d2, d2
    4c34:	f9400043 	ldr	x3, [x2]
    4c38:	f9000fe3 	str	x3, [sp, #24]
    4c3c:	d2800003 	mov	x3, #0x0                   	// #0
    4c40:	1e610800 	fmul	d0, d0, d1
    4c44:	1e640821 	fmul	d1, d1, d4
    4c48:	1e623800 	fsub	d0, d0, d2
    4c4c:	6d0087e0 	stp	d0, d1, [sp, #8]
    4c50:	97fffcb4 	bl	3f20 <fwp_data.part.0.constprop.0>
    4c54:	b0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    4c58:	9114c063 	add	x3, x3, #0x530
    4c5c:	aa0003f3 	mov	x19, x0
    4c60:	f949d861 	ldr	x1, [x3, #5040]
    4c64:	f949ec60 	ldr	x0, [x3, #5080]
    4c68:	cb010261 	sub	x1, x19, x1
    4c6c:	eb00403f 	cmp	x1, x0, lsl #16
    4c70:	54000322 	b.cs	4cd4 <fwp_owned_entry74+0xf4>  // b.hs, b.nlast
    4c74:	d350fc22 	lsr	x2, x1, #16
    4c78:	f949fc63 	ldr	x3, [x3, #5112]
    4c7c:	8b020842 	add	x2, x2, x2, lsl #2
    4c80:	d37df042 	lsl	x2, x2, #3
    4c84:	8b020060 	add	x0, x3, x2
    4c88:	f9401014 	ldr	x20, [x0, #32]
    4c8c:	b4000254 	cbz	x20, 4cd4 <fwp_owned_entry74+0xf4>
    4c90:	38626862 	ldrb	w2, [x3, x2]
    4c94:	7100085f 	cmp	w2, #0x2
    4c98:	54000360 	b.eq	4d04 <fwp_owned_entry74+0x124>  // b.none
    4c9c:	7100045f 	cmp	w2, #0x1
    4ca0:	540001a1 	b.ne	4cd4 <fwp_owned_entry74+0xf4>  // b.any
    4ca4:	29430002 	ldp	w2, w0, [x0, #24]
    4ca8:	92403c21 	and	x1, x1, #0xffff
    4cac:	9b027c21 	mul	x1, x1, x2
    4cb0:	d360fc21 	lsr	x1, x1, #32
    4cb4:	eb00003f 	cmp	x1, x0
    4cb8:	540000e2 	b.cs	4cd4 <fwp_owned_entry74+0xf4>  // b.hs, b.nlast
    4cbc:	8b010294 	add	x20, x20, x1
    4cc0:	39400280 	ldrb	w0, [x20]
    4cc4:	7103fc1f 	cmp	w0, #0xff
    4cc8:	54000240 	b.eq	4d10 <fwp_owned_entry74+0x130>  // b.none
    4ccc:	52800020 	mov	w0, #0x1                   	// #1
    4cd0:	39000280 	strb	w0, [x20]
    4cd4:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    4cd8:	f947f400 	ldr	x0, [x0, #4072]
    4cdc:	f9400fe2 	ldr	x2, [sp, #24]
    4ce0:	f9400001 	ldr	x1, [x0]
    4ce4:	eb010042 	subs	x2, x2, x1
    4ce8:	d2800001 	mov	x1, #0x0                   	// #0
    4cec:	54000181 	b.ne	4d1c <fwp_owned_entry74+0x13c>  // b.any
    4cf0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4cf4:	aa1303e0 	mov	x0, x19
    4cf8:	a94353f3 	ldp	x19, x20, [sp, #48]
    4cfc:	910103ff 	add	sp, sp, #0x40
    4d00:	d65f03c0 	ret
    4d04:	72003c3f 	tst	w1, #0xffff
    4d08:	54fffe61 	b.ne	4cd4 <fwp_owned_entry74+0xf4>  // b.any
    4d0c:	17ffffed 	b	4cc0 <fwp_owned_entry74+0xe0>
    4d10:	aa1403e0 	mov	x0, x20
    4d14:	97fff887 	bl	2f30 <fwp_rc_forget_slot>
    4d18:	17ffffed 	b	4ccc <fwp_owned_entry74+0xec>
    4d1c:	97fff20d 	bl	1550 <__stack_chk_fail@plt>

0000000000004d20 <e74>:
    4d20:	d10103ff 	sub	sp, sp, #0x40
    4d24:	aa0003e2 	mov	x2, x0
    4d28:	d2f80f21 	mov	x1, #0xc079000000000000    	// #-4577627546245398528
    4d2c:	1e6e1002 	fmov	d2, #1.000000000000000000e+00
    4d30:	9e670020 	fmov	d0, x1
    4d34:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    4d38:	a9027bfd 	stp	x29, x30, [sp, #32]
    4d3c:	910083fd 	add	x29, sp, #0x20
    4d40:	9e670004 	fmov	d4, x0
    4d44:	fd400043 	ldr	d3, [x2]
    4d48:	fd400441 	ldr	d1, [x2, #8]
    4d4c:	a90353f3 	stp	x19, x20, [sp, #48]
    4d50:	1e630865 	fmul	d5, d3, d3
    4d54:	1e600860 	fmul	d0, d3, d0
    4d58:	1e633842 	fsub	d2, d2, d3
    4d5c:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x132b8>
    4d60:	f947f442 	ldr	x2, [x2, #4072]
    4d64:	910023e1 	add	x1, sp, #0x8
    4d68:	1e653821 	fsub	d1, d1, d5
    4d6c:	52800000 	mov	w0, #0x0                   	// #0
    4d70:	1e622842 	fadd	d2, d2, d2
    4d74:	f9400043 	ldr	x3, [x2]
    4d78:	f9000fe3 	str	x3, [sp, #24]
    4d7c:	d2800003 	mov	x3, #0x0                   	// #0
    4d80:	1e610800 	fmul	d0, d0, d1
    4d84:	1e640821 	fmul	d1, d1, d4
    4d88:	1e623800 	fsub	d0, d0, d2
    4d8c:	6d0087e0 	stp	d0, d1, [sp, #8]
    4d90:	97fffc64 	bl	3f20 <fwp_data.part.0.constprop.0>
    4d94:	b0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    4d98:	9114c063 	add	x3, x3, #0x530
    4d9c:	aa0003f3 	mov	x19, x0
    4da0:	f949d861 	ldr	x1, [x3, #5040]
    4da4:	f949ec60 	ldr	x0, [x3, #5080]
    4da8:	cb010261 	sub	x1, x19, x1
    4dac:	eb00403f 	cmp	x1, x0, lsl #16
    4db0:	54000322 	b.cs	4e14 <e74+0xf4>  // b.hs, b.nlast
    4db4:	d350fc22 	lsr	x2, x1, #16
    4db8:	f949fc63 	ldr	x3, [x3, #5112]
    4dbc:	8b020842 	add	x2, x2, x2, lsl #2
    4dc0:	d37df042 	lsl	x2, x2, #3
    4dc4:	8b020060 	add	x0, x3, x2
    4dc8:	f9401014 	ldr	x20, [x0, #32]
    4dcc:	b4000254 	cbz	x20, 4e14 <e74+0xf4>
    4dd0:	38626862 	ldrb	w2, [x3, x2]
    4dd4:	7100085f 	cmp	w2, #0x2
    4dd8:	540003a0 	b.eq	4e4c <e74+0x12c>  // b.none
    4ddc:	7100045f 	cmp	w2, #0x1
    4de0:	540001a1 	b.ne	4e14 <e74+0xf4>  // b.any
    4de4:	29430002 	ldp	w2, w0, [x0, #24]
    4de8:	92403c21 	and	x1, x1, #0xffff
    4dec:	9b027c21 	mul	x1, x1, x2
    4df0:	d360fc21 	lsr	x1, x1, #32
    4df4:	eb00003f 	cmp	x1, x0
    4df8:	540000e2 	b.cs	4e14 <e74+0xf4>  // b.hs, b.nlast
    4dfc:	8b010294 	add	x20, x20, x1
    4e00:	39400280 	ldrb	w0, [x20]
    4e04:	7103fc1f 	cmp	w0, #0xff
    4e08:	54000280 	b.eq	4e58 <e74+0x138>  // b.none
    4e0c:	52800020 	mov	w0, #0x1                   	// #1
    4e10:	39000280 	strb	w0, [x20]
    4e14:	aa1303e0 	mov	x0, x19
    4e18:	97fffa06 	bl	3630 <fwp_rc_share>
    4e1c:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    4e20:	f947f400 	ldr	x0, [x0, #4072]
    4e24:	f9400fe2 	ldr	x2, [sp, #24]
    4e28:	f9400001 	ldr	x1, [x0]
    4e2c:	eb010042 	subs	x2, x2, x1
    4e30:	d2800001 	mov	x1, #0x0                   	// #0
    4e34:	54000181 	b.ne	4e64 <e74+0x144>  // b.any
    4e38:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	a94353f3 	ldp	x19, x20, [sp, #48]
    4e44:	910103ff 	add	sp, sp, #0x40
    4e48:	d65f03c0 	ret
    4e4c:	72003c3f 	tst	w1, #0xffff
    4e50:	54fffe21 	b.ne	4e14 <e74+0xf4>  // b.any
    4e54:	17ffffeb 	b	4e00 <e74+0xe0>
    4e58:	aa1403e0 	mov	x0, x20
    4e5c:	97fff835 	bl	2f30 <fwp_rc_forget_slot>
    4e60:	17ffffeb 	b	4e0c <e74+0xec>
    4e64:	97fff1bb 	bl	1550 <__stack_chk_fail@plt>
    4e68:	d503201f 	nop
    4e6c:	d503201f 	nop

0000000000004e70 <fwp_caps50>:
    4e70:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4e74:	910003fd 	mov	x29, sp
    4e78:	f9000bf3 	str	x19, [sp, #16]
    4e7c:	aa0003f3 	mov	x19, x0
    4e80:	b9400400 	ldr	w0, [x0, #4]
    4e84:	340004a0 	cbz	w0, 4f18 <fwp_caps50+0xa8>
    4e88:	f9400660 	ldr	x0, [x19, #8]
    4e8c:	350004e1 	cbnz	w1, 4f28 <fwp_caps50+0xb8>
    4e90:	97fffd6d 	bl	4444 <fwp_drop4>
    4e94:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    4e98:	9114c042 	add	x2, x2, #0x530
    4e9c:	f949d840 	ldr	x0, [x2, #5040]
    4ea0:	f949ec41 	ldr	x1, [x2, #5080]
    4ea4:	cb000260 	sub	x0, x19, x0
    4ea8:	eb01401f 	cmp	x0, x1, lsl #16
    4eac:	54000382 	b.cs	4f1c <fwp_caps50+0xac>  // b.hs, b.nlast
    4eb0:	d350fc01 	lsr	x1, x0, #16
    4eb4:	f949fc44 	ldr	x4, [x2, #5112]
    4eb8:	8b010821 	add	x1, x1, x1, lsl #2
    4ebc:	d37df021 	lsl	x1, x1, #3
    4ec0:	8b010083 	add	x3, x4, x1
    4ec4:	f9401062 	ldr	x2, [x3, #32]
    4ec8:	b40002a2 	cbz	x2, 4f1c <fwp_caps50+0xac>
    4ecc:	38616881 	ldrb	w1, [x4, x1]
    4ed0:	7100083f 	cmp	w1, #0x2
    4ed4:	54000740 	b.eq	4fbc <fwp_caps50+0x14c>  // b.none
    4ed8:	7100043f 	cmp	w1, #0x1
    4edc:	54000201 	b.ne	4f1c <fwp_caps50+0xac>  // b.any
    4ee0:	29430464 	ldp	w4, w1, [x3, #24]
    4ee4:	92403c00 	and	x0, x0, #0xffff
    4ee8:	9b047c00 	mul	x0, x0, x4
    4eec:	d360fc00 	lsr	x0, x0, #32
    4ef0:	eb01001f 	cmp	x0, x1
    4ef4:	54000142 	b.cs	4f1c <fwp_caps50+0xac>  // b.hs, b.nlast
    4ef8:	8b000042 	add	x2, x2, x0
    4efc:	39400040 	ldrb	w0, [x2]
    4f00:	7100041f 	cmp	w0, #0x1
    4f04:	540000c1 	b.ne	4f1c <fwp_caps50+0xac>  // b.any
    4f08:	aa1303e0 	mov	x0, x19
    4f0c:	f9400bf3 	ldr	x19, [sp, #16]
    4f10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4f14:	17fff8a7 	b	31b0 <fwp_mem_free>
    4f18:	34fffbe1 	cbz	w1, 4e94 <fwp_caps50+0x24>
    4f1c:	f9400bf3 	ldr	x19, [sp, #16]
    4f20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4f24:	d65f03c0 	ret
    4f28:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    4f2c:	9114c042 	add	x2, x2, #0x530
    4f30:	f949d843 	ldr	x3, [x2, #5040]
    4f34:	f949ec41 	ldr	x1, [x2, #5080]
    4f38:	cb030000 	sub	x0, x0, x3
    4f3c:	eb01401f 	cmp	x0, x1, lsl #16
    4f40:	54fffee2 	b.cs	4f1c <fwp_caps50+0xac>  // b.hs, b.nlast
    4f44:	d350fc01 	lsr	x1, x0, #16
    4f48:	f949fc44 	ldr	x4, [x2, #5112]
    4f4c:	8b010821 	add	x1, x1, x1, lsl #2
    4f50:	d37df021 	lsl	x1, x1, #3
    4f54:	8b010083 	add	x3, x4, x1
    4f58:	f9401062 	ldr	x2, [x3, #32]
    4f5c:	b4fffe02 	cbz	x2, 4f1c <fwp_caps50+0xac>
    4f60:	38616881 	ldrb	w1, [x4, x1]
    4f64:	7100083f 	cmp	w1, #0x2
    4f68:	54000300 	b.eq	4fc8 <fwp_caps50+0x158>  // b.none
    4f6c:	7100043f 	cmp	w1, #0x1
    4f70:	54fffd61 	b.ne	4f1c <fwp_caps50+0xac>  // b.any
    4f74:	92403c01 	and	x1, x0, #0xffff
    4f78:	29430064 	ldp	w4, w0, [x3, #24]
    4f7c:	9b047c21 	mul	x1, x1, x4
    4f80:	d360fc21 	lsr	x1, x1, #32
    4f84:	eb00003f 	cmp	x1, x0
    4f88:	54fffca2 	b.cs	4f1c <fwp_caps50+0xac>  // b.hs, b.nlast
    4f8c:	8b010042 	add	x2, x2, x1
    4f90:	39400040 	ldrb	w0, [x2]
    4f94:	34fffc40 	cbz	w0, 4f1c <fwp_caps50+0xac>
    4f98:	900000e1 	adrp	x1, 20000 <__data_start>
    4f9c:	91014021 	add	x1, x1, #0x50
    4fa0:	b9404023 	ldr	w3, [x1, #64]
    4fa4:	35000183 	cbnz	w3, 4fd4 <fwp_caps50+0x164>
    4fa8:	7103f41f 	cmp	w0, #0xfd
    4fac:	540001c8 	b.hi	4fe4 <fwp_caps50+0x174>  // b.pmore
    4fb0:	11000400 	add	w0, w0, #0x1
    4fb4:	39000040 	strb	w0, [x2]
    4fb8:	17ffffd9 	b	4f1c <fwp_caps50+0xac>
    4fbc:	72003c1f 	tst	w0, #0xffff
    4fc0:	54fffae1 	b.ne	4f1c <fwp_caps50+0xac>  // b.any
    4fc4:	17ffffce 	b	4efc <fwp_caps50+0x8c>
    4fc8:	72003c1f 	tst	w0, #0xffff
    4fcc:	54fffa81 	b.ne	4f1c <fwp_caps50+0xac>  // b.any
    4fd0:	17fffff0 	b	4f90 <fwp_caps50+0x120>
    4fd4:	f9402423 	ldr	x3, [x1, #72]
    4fd8:	91000463 	add	x3, x3, #0x1
    4fdc:	f9002423 	str	x3, [x1, #72]
    4fe0:	17fffff2 	b	4fa8 <fwp_caps50+0x138>
    4fe4:	f9400bf3 	ldr	x19, [sp, #16]
    4fe8:	aa0203e0 	mov	x0, x2
    4fec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4ff0:	17fff789 	b	2e14 <fwp_rc_wide_dup>

0000000000004ff4 <fwp_caps47>:
    4ff4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4ff8:	910003fd 	mov	x29, sp
    4ffc:	f9000bf3 	str	x19, [sp, #16]
    5000:	aa0003f3 	mov	x19, x0
    5004:	b9400400 	ldr	w0, [x0, #4]
    5008:	340004a0 	cbz	w0, 509c <fwp_caps47+0xa8>
    500c:	f9400660 	ldr	x0, [x19, #8]
    5010:	350004e1 	cbnz	w1, 50ac <fwp_caps47+0xb8>
    5014:	97fffd0c 	bl	4444 <fwp_drop4>
    5018:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    501c:	9114c042 	add	x2, x2, #0x530
    5020:	f949d840 	ldr	x0, [x2, #5040]
    5024:	f949ec41 	ldr	x1, [x2, #5080]
    5028:	cb000260 	sub	x0, x19, x0
    502c:	eb01401f 	cmp	x0, x1, lsl #16
    5030:	54000382 	b.cs	50a0 <fwp_caps47+0xac>  // b.hs, b.nlast
    5034:	d350fc01 	lsr	x1, x0, #16
    5038:	f949fc44 	ldr	x4, [x2, #5112]
    503c:	8b010821 	add	x1, x1, x1, lsl #2
    5040:	d37df021 	lsl	x1, x1, #3
    5044:	8b010083 	add	x3, x4, x1
    5048:	f9401062 	ldr	x2, [x3, #32]
    504c:	b40002a2 	cbz	x2, 50a0 <fwp_caps47+0xac>
    5050:	38616881 	ldrb	w1, [x4, x1]
    5054:	7100083f 	cmp	w1, #0x2
    5058:	54000740 	b.eq	5140 <fwp_caps47+0x14c>  // b.none
    505c:	7100043f 	cmp	w1, #0x1
    5060:	54000201 	b.ne	50a0 <fwp_caps47+0xac>  // b.any
    5064:	29430464 	ldp	w4, w1, [x3, #24]
    5068:	92403c00 	and	x0, x0, #0xffff
    506c:	9b047c00 	mul	x0, x0, x4
    5070:	d360fc00 	lsr	x0, x0, #32
    5074:	eb01001f 	cmp	x0, x1
    5078:	54000142 	b.cs	50a0 <fwp_caps47+0xac>  // b.hs, b.nlast
    507c:	8b000042 	add	x2, x2, x0
    5080:	39400040 	ldrb	w0, [x2]
    5084:	7100041f 	cmp	w0, #0x1
    5088:	540000c1 	b.ne	50a0 <fwp_caps47+0xac>  // b.any
    508c:	aa1303e0 	mov	x0, x19
    5090:	f9400bf3 	ldr	x19, [sp, #16]
    5094:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5098:	17fff846 	b	31b0 <fwp_mem_free>
    509c:	34fffbe1 	cbz	w1, 5018 <fwp_caps47+0x24>
    50a0:	f9400bf3 	ldr	x19, [sp, #16]
    50a4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    50a8:	d65f03c0 	ret
    50ac:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    50b0:	9114c042 	add	x2, x2, #0x530
    50b4:	f949d843 	ldr	x3, [x2, #5040]
    50b8:	f949ec41 	ldr	x1, [x2, #5080]
    50bc:	cb030000 	sub	x0, x0, x3
    50c0:	eb01401f 	cmp	x0, x1, lsl #16
    50c4:	54fffee2 	b.cs	50a0 <fwp_caps47+0xac>  // b.hs, b.nlast
    50c8:	d350fc01 	lsr	x1, x0, #16
    50cc:	f949fc44 	ldr	x4, [x2, #5112]
    50d0:	8b010821 	add	x1, x1, x1, lsl #2
    50d4:	d37df021 	lsl	x1, x1, #3
    50d8:	8b010083 	add	x3, x4, x1
    50dc:	f9401062 	ldr	x2, [x3, #32]
    50e0:	b4fffe02 	cbz	x2, 50a0 <fwp_caps47+0xac>
    50e4:	38616881 	ldrb	w1, [x4, x1]
    50e8:	7100083f 	cmp	w1, #0x2
    50ec:	54000300 	b.eq	514c <fwp_caps47+0x158>  // b.none
    50f0:	7100043f 	cmp	w1, #0x1
    50f4:	54fffd61 	b.ne	50a0 <fwp_caps47+0xac>  // b.any
    50f8:	92403c01 	and	x1, x0, #0xffff
    50fc:	29430064 	ldp	w4, w0, [x3, #24]
    5100:	9b047c21 	mul	x1, x1, x4
    5104:	d360fc21 	lsr	x1, x1, #32
    5108:	eb00003f 	cmp	x1, x0
    510c:	54fffca2 	b.cs	50a0 <fwp_caps47+0xac>  // b.hs, b.nlast
    5110:	8b010042 	add	x2, x2, x1
    5114:	39400040 	ldrb	w0, [x2]
    5118:	34fffc40 	cbz	w0, 50a0 <fwp_caps47+0xac>
    511c:	f00000c1 	adrp	x1, 20000 <__data_start>
    5120:	91014021 	add	x1, x1, #0x50
    5124:	b9404023 	ldr	w3, [x1, #64]
    5128:	35000183 	cbnz	w3, 5158 <fwp_caps47+0x164>
    512c:	7103f41f 	cmp	w0, #0xfd
    5130:	540001c8 	b.hi	5168 <fwp_caps47+0x174>  // b.pmore
    5134:	11000400 	add	w0, w0, #0x1
    5138:	39000040 	strb	w0, [x2]
    513c:	17ffffd9 	b	50a0 <fwp_caps47+0xac>
    5140:	72003c1f 	tst	w0, #0xffff
    5144:	54fffae1 	b.ne	50a0 <fwp_caps47+0xac>  // b.any
    5148:	17ffffce 	b	5080 <fwp_caps47+0x8c>
    514c:	72003c1f 	tst	w0, #0xffff
    5150:	54fffa81 	b.ne	50a0 <fwp_caps47+0xac>  // b.any
    5154:	17fffff0 	b	5114 <fwp_caps47+0x120>
    5158:	f9402423 	ldr	x3, [x1, #72]
    515c:	91000463 	add	x3, x3, #0x1
    5160:	f9002423 	str	x3, [x1, #72]
    5164:	17fffff2 	b	512c <fwp_caps47+0x138>
    5168:	f9400bf3 	ldr	x19, [sp, #16]
    516c:	aa0203e0 	mov	x0, x2
    5170:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5174:	17fff728 	b	2e14 <fwp_rc_wide_dup>
    5178:	d503201f 	nop
    517c:	d503201f 	nop

0000000000005180 <fwp_loop_fields68.constprop.0>:
    5180:	d104c3ff 	sub	sp, sp, #0x130
    5184:	d00000c1 	adrp	x1, 1f000 <__FRAME_END__+0x132b8>
    5188:	f947f421 	ldr	x1, [x1, #4072]
    518c:	a90b7bfd 	stp	x29, x30, [sp, #176]
    5190:	9102c3fd 	add	x29, sp, #0xb0
    5194:	f90007e0 	str	x0, [sp, #8]
    5198:	a90c53f3 	stp	x19, x20, [sp, #192]
    519c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    51a0:	f00000d5 	adrp	x21, 20000 <__data_start>
    51a4:	910142b5 	add	x21, x21, #0x50
    51a8:	a90e63f7 	stp	x23, x24, [sp, #224]
    51ac:	910143f7 	add	x23, sp, #0x50
    51b0:	a90f6bf9 	stp	x25, x26, [sp, #240]
    51b4:	a91073fb 	stp	x27, x28, [sp, #256]
    51b8:	6d1127e8 	stp	d8, d9, [sp, #272]
    51bc:	6d122fea 	stp	d10, d11, [sp, #288]
    51c0:	f9400020 	ldr	x0, [x1]
    51c4:	f90057e0 	str	x0, [sp, #168]
    51c8:	d2800000 	mov	x0, #0x0                   	// #0
    51cc:	90000160 	adrp	x0, 31000 <fwp_root_context+0xcb0>
    51d0:	9114c01c 	add	x28, x0, #0x530
    51d4:	d28018c0 	mov	x0, #0xc6                  	// #198
    51d8:	f9000fe0 	str	x0, [sp, #24]
    51dc:	910103e0 	add	x0, sp, #0x40
    51e0:	f90013e0 	str	x0, [sp, #32]
    51e4:	910123e0 	add	x0, sp, #0x48
    51e8:	f90003e0 	str	x0, [sp]
    51ec:	910203e0 	add	x0, sp, #0x80
    51f0:	f9001fe0 	str	x0, [sp, #56]
    51f4:	b0000020 	adrp	x0, a000 <__divti3+0x2e0>
    51f8:	fd45a00b 	ldr	d11, [x0, #2880]
    51fc:	f94007e0 	ldr	x0, [sp, #8]
    5200:	b4004580 	cbz	x0, 5ab0 <fwp_loop_fields68.constprop.0+0x930>
    5204:	d503201f 	nop
    5208:	f9400800 	ldr	x0, [x0, #16]
    520c:	f9000be0 	str	x0, [sp, #16]
    5210:	f9400be2 	ldr	x2, [sp, #16]
    5214:	f949db81 	ldr	x1, [x28, #5040]
    5218:	f949ef80 	ldr	x0, [x28, #5080]
    521c:	cb010041 	sub	x1, x2, x1
    5220:	eb00403f 	cmp	x1, x0, lsl #16
    5224:	540003e2 	b.cs	52a0 <fwp_loop_fields68.constprop.0+0x120>  // b.hs, b.nlast
    5228:	d350fc20 	lsr	x0, x1, #16
    522c:	f949ff85 	ldr	x5, [x28, #5112]
    5230:	8b000800 	add	x0, x0, x0, lsl #2
    5234:	d37df003 	lsl	x3, x0, #3
    5238:	8b0300a4 	add	x4, x5, x3
    523c:	f9401080 	ldr	x0, [x4, #32]
    5240:	b4000300 	cbz	x0, 52a0 <fwp_loop_fields68.constprop.0+0x120>
    5244:	386368a3 	ldrb	w3, [x5, x3]
    5248:	7100087f 	cmp	w3, #0x2
    524c:	54004780 	b.eq	5b3c <fwp_loop_fields68.constprop.0+0x9bc>  // b.none
    5250:	7100047f 	cmp	w3, #0x1
    5254:	54000261 	b.ne	52a0 <fwp_loop_fields68.constprop.0+0x120>  // b.any
    5258:	29430c85 	ldp	w5, w3, [x4, #24]
    525c:	92403c21 	and	x1, x1, #0xffff
    5260:	9b057c21 	mul	x1, x1, x5
    5264:	d360fc21 	lsr	x1, x1, #32
    5268:	eb03003f 	cmp	x1, x3
    526c:	540001a2 	b.cs	52a0 <fwp_loop_fields68.constprop.0+0x120>  // b.hs, b.nlast
    5270:	8b010000 	add	x0, x0, x1
    5274:	39400001 	ldrb	w1, [x0]
    5278:	34000141 	cbz	w1, 52a0 <fwp_loop_fields68.constprop.0+0x120>
    527c:	b94042a3 	ldr	w3, [x21, #64]
    5280:	34000083 	cbz	w3, 5290 <fwp_loop_fields68.constprop.0+0x110>
    5284:	f94026a3 	ldr	x3, [x21, #72]
    5288:	91000463 	add	x3, x3, #0x1
    528c:	f90026a3 	str	x3, [x21, #72]
    5290:	7103f43f 	cmp	w1, #0xfd
    5294:	540051c8 	b.hi	5ccc <fwp_loop_fields68.constprop.0+0xb4c>  // b.pmore
    5298:	11000421 	add	w1, w1, #0x1
    529c:	39000001 	strb	w1, [x0]
    52a0:	f9400be0 	ldr	x0, [sp, #16]
    52a4:	910263f4 	add	x20, sp, #0x98
    52a8:	f94013e1 	ldr	x1, [sp, #32]
    52ac:	d2800018 	mov	x24, #0x0                   	// #0
    52b0:	97fffbe8 	bl	4250 <fwp_map_items>
    52b4:	aa0003fa 	mov	x26, x0
    52b8:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0xe0>
    52bc:	91111005 	add	x5, x0, #0x444
    52c0:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0xe0>
    52c4:	91219003 	add	x3, x0, #0x864
    52c8:	a94003e1 	ldp	x1, x0, [sp]
    52cc:	f9002bfa 	str	x26, [sp, #80]
    52d0:	a905ffff 	stp	xzr, xzr, [sp, #88]
    52d4:	a9068fe5 	stp	x5, x3, [sp, #104]
    52d8:	97fffbde 	bl	4250 <fwp_map_items>
    52dc:	aa0003f9 	mov	x25, x0
    52e0:	a9444fe1 	ldp	x1, x19, [sp, #64]
    52e4:	eb01027f 	cmp	x19, x1
    52e8:	9a819273 	csel	x19, x19, x1, ls	// ls = plast
    52ec:	b4004013 	cbz	x19, 5aec <fwp_loop_fields68.constprop.0+0x96c>
    52f0:	d2f80f21 	mov	x1, #0xc079000000000000    	// #-4577627546245398528
    52f4:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    52f8:	9e670029 	fmov	d9, x1
    52fc:	9e670008 	fmov	d8, x0
    5300:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5304:	52800036 	mov	w22, #0x1                   	// #1
    5308:	fc787b20 	ldr	d0, [x25, x24, lsl #3]
    530c:	aa1403e1 	mov	x1, x20
    5310:	fc787b41 	ldr	d1, [x26, x24, lsl #3]
    5314:	52800000 	mov	w0, #0x0                   	// #0
    5318:	1e600803 	fmul	d3, d0, d0
    531c:	1e690802 	fmul	d2, d0, d9
    5320:	1e603940 	fsub	d0, d10, d0
    5324:	1e633821 	fsub	d1, d1, d3
    5328:	1e602800 	fadd	d0, d0, d0
    532c:	1e610842 	fmul	d2, d2, d1
    5330:	1e680821 	fmul	d1, d1, d8
    5334:	1e603840 	fsub	d0, d2, d0
    5338:	6d0987e0 	stp	d0, d1, [sp, #152]
    533c:	97fffaf9 	bl	3f20 <fwp_data.part.0.constprop.0>
    5340:	aa0003fb 	mov	x27, x0
    5344:	f949db81 	ldr	x1, [x28, #5040]
    5348:	f949ef80 	ldr	x0, [x28, #5080]
    534c:	cb010361 	sub	x1, x27, x1
    5350:	eb00403f 	cmp	x1, x0, lsl #16
    5354:	54000302 	b.cs	53b4 <fwp_loop_fields68.constprop.0+0x234>  // b.hs, b.nlast
    5358:	d350fc23 	lsr	x3, x1, #16
    535c:	f949ff87 	ldr	x7, [x28, #5112]
    5360:	8b030863 	add	x3, x3, x3, lsl #2
    5364:	d37df063 	lsl	x3, x3, #3
    5368:	8b0300e6 	add	x6, x7, x3
    536c:	f94010c0 	ldr	x0, [x6, #32]
    5370:	b4000220 	cbz	x0, 53b4 <fwp_loop_fields68.constprop.0+0x234>
    5374:	386368e3 	ldrb	w3, [x7, x3]
    5378:	7100087f 	cmp	w3, #0x2
    537c:	54003a60 	b.eq	5ac8 <fwp_loop_fields68.constprop.0+0x948>  // b.none
    5380:	7100047f 	cmp	w3, #0x1
    5384:	54000181 	b.ne	53b4 <fwp_loop_fields68.constprop.0+0x234>  // b.any
    5388:	29430cc7 	ldp	w7, w3, [x6, #24]
    538c:	92403c21 	and	x1, x1, #0xffff
    5390:	9b077c21 	mul	x1, x1, x7
    5394:	d360fc21 	lsr	x1, x1, #32
    5398:	eb03003f 	cmp	x1, x3
    539c:	540000c2 	b.cs	53b4 <fwp_loop_fields68.constprop.0+0x234>  // b.hs, b.nlast
    53a0:	8b010000 	add	x0, x0, x1
    53a4:	39400001 	ldrb	w1, [x0]
    53a8:	7103fc3f 	cmp	w1, #0xff
    53ac:	54003860 	b.eq	5ab8 <fwp_loop_fields68.constprop.0+0x938>  // b.none
    53b0:	39000016 	strb	w22, [x0]
    53b4:	f8387b5b 	str	x27, [x26, x24, lsl #3]
    53b8:	91000718 	add	x24, x24, #0x1
    53bc:	f9002ff8 	str	x24, [sp, #88]
    53c0:	eb18027f 	cmp	x19, x24
    53c4:	54fffa21 	b.ne	5308 <fwp_loop_fields68.constprop.0+0x188>  // b.any
    53c8:	aa1903e0 	mov	x0, x25
    53cc:	97fff779 	bl	31b0 <fwp_mem_free>
    53d0:	aa1703e0 	mov	x0, x23
    53d4:	97fffb4c 	bl	4104 <fwp_map_finish_protected.isra.0>
    53d8:	aa0003f8 	mov	x24, x0
    53dc:	f9400be0 	ldr	x0, [sp, #16]
    53e0:	97fffcac 	bl	4690 <fwp_drop0>
    53e4:	a9087fff 	stp	xzr, xzr, [sp, #128]
    53e8:	52800020 	mov	w0, #0x1                   	// #1
    53ec:	f9401fe1 	ldr	x1, [sp, #56]
    53f0:	97fffacc 	bl	3f20 <fwp_data.part.0.constprop.0>
    53f4:	aa0003e2 	mov	x2, x0
    53f8:	f949db81 	ldr	x1, [x28, #5040]
    53fc:	f9000be2 	str	x2, [sp, #16]
    5400:	f949ef80 	ldr	x0, [x28, #5080]
    5404:	cb010041 	sub	x1, x2, x1
    5408:	eb00403f 	cmp	x1, x0, lsl #16
    540c:	54000322 	b.cs	5470 <fwp_loop_fields68.constprop.0+0x2f0>  // b.hs, b.nlast
    5410:	d350fc20 	lsr	x0, x1, #16
    5414:	f949ff84 	ldr	x4, [x28, #5112]
    5418:	8b000800 	add	x0, x0, x0, lsl #2
    541c:	d37df003 	lsl	x3, x0, #3
    5420:	8b030080 	add	x0, x4, x3
    5424:	f9401013 	ldr	x19, [x0, #32]
    5428:	b4000253 	cbz	x19, 5470 <fwp_loop_fields68.constprop.0+0x2f0>
    542c:	38636883 	ldrb	w3, [x4, x3]
    5430:	7100087f 	cmp	w3, #0x2
    5434:	54003740 	b.eq	5b1c <fwp_loop_fields68.constprop.0+0x99c>  // b.none
    5438:	7100047f 	cmp	w3, #0x1
    543c:	540001a1 	b.ne	5470 <fwp_loop_fields68.constprop.0+0x2f0>  // b.any
    5440:	29430003 	ldp	w3, w0, [x0, #24]
    5444:	92403c21 	and	x1, x1, #0xffff
    5448:	9b037c21 	mul	x1, x1, x3
    544c:	d360fc21 	lsr	x1, x1, #32
    5450:	eb00003f 	cmp	x1, x0
    5454:	540000e2 	b.cs	5470 <fwp_loop_fields68.constprop.0+0x2f0>  // b.hs, b.nlast
    5458:	8b010273 	add	x19, x19, x1
    545c:	39400260 	ldrb	w0, [x19]
    5460:	7103fc1f 	cmp	w0, #0xff
    5464:	54003660 	b.eq	5b30 <fwp_loop_fields68.constprop.0+0x9b0>  // b.none
    5468:	52800020 	mov	w0, #0x1                   	// #1
    546c:	39000260 	strb	w0, [x19]
    5470:	f94003e1 	ldr	x1, [sp]
    5474:	aa1803e0 	mov	x0, x24
    5478:	d2800014 	mov	x20, #0x0                   	// #0
    547c:	97fffb75 	bl	4250 <fwp_map_items>
    5480:	aa0003fb 	mov	x27, x0
    5484:	f94027f3 	ldr	x19, [sp, #72]
    5488:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0xe0>
    548c:	911a4000 	add	x0, x0, #0x690
    5490:	f9002bfb 	str	x27, [sp, #80]
    5494:	a905ffff 	stp	xzr, xzr, [sp, #88]
    5498:	a90683ff 	stp	xzr, x0, [sp, #104]
    549c:	b50003d3 	cbnz	x19, 5514 <fwp_loop_fields68.constprop.0+0x394>
    54a0:	14000038 	b	5580 <fwp_loop_fields68.constprop.0+0x400>
    54a4:	7100047f 	cmp	w3, #0x1
    54a8:	54000261 	b.ne	54f4 <fwp_loop_fields68.constprop.0+0x374>  // b.any
    54ac:	29430c85 	ldp	w5, w3, [x4, #24]
    54b0:	92403c21 	and	x1, x1, #0xffff
    54b4:	9b057c21 	mul	x1, x1, x5
    54b8:	d360fc21 	lsr	x1, x1, #32
    54bc:	eb03003f 	cmp	x1, x3
    54c0:	540001a2 	b.cs	54f4 <fwp_loop_fields68.constprop.0+0x374>  // b.hs, b.nlast
    54c4:	8b010000 	add	x0, x0, x1
    54c8:	39400001 	ldrb	w1, [x0]
    54cc:	34000141 	cbz	w1, 54f4 <fwp_loop_fields68.constprop.0+0x374>
    54d0:	b94042a3 	ldr	w3, [x21, #64]
    54d4:	34000083 	cbz	w3, 54e4 <fwp_loop_fields68.constprop.0+0x364>
    54d8:	f94026a3 	ldr	x3, [x21, #72]
    54dc:	91000463 	add	x3, x3, #0x1
    54e0:	f90026a3 	str	x3, [x21, #72]
    54e4:	7103f43f 	cmp	w1, #0xfd
    54e8:	54003108 	b.hi	5b08 <fwp_loop_fields68.constprop.0+0x988>  // b.pmore
    54ec:	11000421 	add	w1, w1, #0x1
    54f0:	39000001 	strb	w1, [x0]
    54f4:	f94006d9 	ldr	x25, [x22, #8]
    54f8:	aa1603e0 	mov	x0, x22
    54fc:	97fffbd2 	bl	4444 <fwp_drop4>
    5500:	f8347b79 	str	x25, [x27, x20, lsl #3]
    5504:	91000694 	add	x20, x20, #0x1
    5508:	f9002ff4 	str	x20, [sp, #88]
    550c:	eb13029f 	cmp	x20, x19
    5510:	54000380 	b.eq	5580 <fwp_loop_fields68.constprop.0+0x400>  // b.none
    5514:	f8747b76 	ldr	x22, [x27, x20, lsl #3]
    5518:	f949db81 	ldr	x1, [x28, #5040]
    551c:	f949ef80 	ldr	x0, [x28, #5080]
    5520:	cb0102c1 	sub	x1, x22, x1
    5524:	eb00403f 	cmp	x1, x0, lsl #16
    5528:	54fffe62 	b.cs	54f4 <fwp_loop_fields68.constprop.0+0x374>  // b.hs, b.nlast
    552c:	d350fc23 	lsr	x3, x1, #16
    5530:	f949ff85 	ldr	x5, [x28, #5112]
    5534:	8b030863 	add	x3, x3, x3, lsl #2
    5538:	d37df063 	lsl	x3, x3, #3
    553c:	8b0300a4 	add	x4, x5, x3
    5540:	f9401080 	ldr	x0, [x4, #32]
    5544:	b4fffd80 	cbz	x0, 54f4 <fwp_loop_fields68.constprop.0+0x374>
    5548:	386368a3 	ldrb	w3, [x5, x3]
    554c:	7100087f 	cmp	w3, #0x2
    5550:	54fffaa1 	b.ne	54a4 <fwp_loop_fields68.constprop.0+0x324>  // b.any
    5554:	72003c3f 	tst	w1, #0xffff
    5558:	54fffb80 	b.eq	54c8 <fwp_loop_fields68.constprop.0+0x348>  // b.none
    555c:	f94006d9 	ldr	x25, [x22, #8]
    5560:	aa1603e0 	mov	x0, x22
    5564:	97fffbb8 	bl	4444 <fwp_drop4>
    5568:	f8347b79 	str	x25, [x27, x20, lsl #3]
    556c:	91000694 	add	x20, x20, #0x1
    5570:	f9002ff4 	str	x20, [sp, #88]
    5574:	eb13029f 	cmp	x20, x19
    5578:	54fffce1 	b.ne	5514 <fwp_loop_fields68.constprop.0+0x394>  // b.any
    557c:	d503201f 	nop
    5580:	aa1703e0 	mov	x0, x23
    5584:	97fffae0 	bl	4104 <fwp_map_finish_protected.isra.0>
    5588:	aa1703e1 	mov	x1, x23
    558c:	f9001be0 	str	x0, [sp, #48]
    5590:	97fffb30 	bl	4250 <fwp_map_items>
    5594:	f90017e0 	str	x0, [sp, #40]
    5598:	f9400be2 	ldr	x2, [sp, #16]
    559c:	f949db81 	ldr	x1, [x28, #5040]
    55a0:	f949ef80 	ldr	x0, [x28, #5080]
    55a4:	cb010041 	sub	x1, x2, x1
    55a8:	eb00403f 	cmp	x1, x0, lsl #16
    55ac:	540003e2 	b.cs	5628 <fwp_loop_fields68.constprop.0+0x4a8>  // b.hs, b.nlast
    55b0:	d350fc20 	lsr	x0, x1, #16
    55b4:	f949ff85 	ldr	x5, [x28, #5112]
    55b8:	8b000800 	add	x0, x0, x0, lsl #2
    55bc:	d37df003 	lsl	x3, x0, #3
    55c0:	8b0300a4 	add	x4, x5, x3
    55c4:	f9401080 	ldr	x0, [x4, #32]
    55c8:	b4000300 	cbz	x0, 5628 <fwp_loop_fields68.constprop.0+0x4a8>
    55cc:	386368a3 	ldrb	w3, [x5, x3]
    55d0:	7100087f 	cmp	w3, #0x2
    55d4:	540029e0 	b.eq	5b10 <fwp_loop_fields68.constprop.0+0x990>  // b.none
    55d8:	7100047f 	cmp	w3, #0x1
    55dc:	54000261 	b.ne	5628 <fwp_loop_fields68.constprop.0+0x4a8>  // b.any
    55e0:	29430c85 	ldp	w5, w3, [x4, #24]
    55e4:	92403c21 	and	x1, x1, #0xffff
    55e8:	9b057c21 	mul	x1, x1, x5
    55ec:	d360fc21 	lsr	x1, x1, #32
    55f0:	eb03003f 	cmp	x1, x3
    55f4:	540001a2 	b.cs	5628 <fwp_loop_fields68.constprop.0+0x4a8>  // b.hs, b.nlast
    55f8:	8b010000 	add	x0, x0, x1
    55fc:	39400001 	ldrb	w1, [x0]
    5600:	34000141 	cbz	w1, 5628 <fwp_loop_fields68.constprop.0+0x4a8>
    5604:	b94042a3 	ldr	w3, [x21, #64]
    5608:	34000083 	cbz	w3, 5618 <fwp_loop_fields68.constprop.0+0x498>
    560c:	f94026a3 	ldr	x3, [x21, #72]
    5610:	91000463 	add	x3, x3, #0x1
    5614:	f90026a3 	str	x3, [x21, #72]
    5618:	7103f43f 	cmp	w1, #0xfd
    561c:	540035c8 	b.hi	5cd4 <fwp_loop_fields68.constprop.0+0xb54>  // b.pmore
    5620:	11000421 	add	w1, w1, #0x1
    5624:	39000001 	strb	w1, [x0]
    5628:	f9402bf9 	ldr	x25, [sp, #80]
    562c:	f9400bf3 	ldr	x19, [sp, #16]
    5630:	b4000559 	cbz	x25, 56d8 <fwp_loop_fields68.constprop.0+0x558>
    5634:	f94017e0 	ldr	x0, [sp, #40]
    5638:	910263f4 	add	x20, sp, #0x98
    563c:	5280003b 	mov	w27, #0x1                   	// #1
    5640:	d1002016 	sub	x22, x0, #0x8
    5644:	d503201f 	nop
    5648:	f8797ac3 	ldr	x3, [x22, x25, lsl #3]
    564c:	aa1403e1 	mov	x1, x20
    5650:	52800020 	mov	w0, #0x1                   	// #1
    5654:	a909cfe3 	stp	x3, x19, [sp, #152]
    5658:	97fffa32 	bl	3f20 <fwp_data.part.0.constprop.0>
    565c:	aa0003f3 	mov	x19, x0
    5660:	f949db81 	ldr	x1, [x28, #5040]
    5664:	f949ef80 	ldr	x0, [x28, #5080]
    5668:	cb010261 	sub	x1, x19, x1
    566c:	eb00403f 	cmp	x1, x0, lsl #16
    5670:	54000302 	b.cs	56d0 <fwp_loop_fields68.constprop.0+0x550>  // b.hs, b.nlast
    5674:	d350fc20 	lsr	x0, x1, #16
    5678:	f949ff86 	ldr	x6, [x28, #5112]
    567c:	8b000800 	add	x0, x0, x0, lsl #2
    5680:	d37df003 	lsl	x3, x0, #3
    5684:	8b0300c5 	add	x5, x6, x3
    5688:	f94010ba 	ldr	x26, [x5, #32]
    568c:	b400023a 	cbz	x26, 56d0 <fwp_loop_fields68.constprop.0+0x550>
    5690:	386368c3 	ldrb	w3, [x6, x3]
    5694:	7100087f 	cmp	w3, #0x2
    5698:	54002240 	b.eq	5ae0 <fwp_loop_fields68.constprop.0+0x960>  // b.none
    569c:	7100047f 	cmp	w3, #0x1
    56a0:	54000181 	b.ne	56d0 <fwp_loop_fields68.constprop.0+0x550>  // b.any
    56a4:	29430ca6 	ldp	w6, w3, [x5, #24]
    56a8:	92403c21 	and	x1, x1, #0xffff
    56ac:	9b067c21 	mul	x1, x1, x6
    56b0:	d360fc21 	lsr	x1, x1, #32
    56b4:	eb03003f 	cmp	x1, x3
    56b8:	540000c2 	b.cs	56d0 <fwp_loop_fields68.constprop.0+0x550>  // b.hs, b.nlast
    56bc:	8b01035a 	add	x26, x26, x1
    56c0:	39400341 	ldrb	w1, [x26]
    56c4:	7103fc3f 	cmp	w1, #0xff
    56c8:	54002060 	b.eq	5ad4 <fwp_loop_fields68.constprop.0+0x954>  // b.none
    56cc:	3900035b 	strb	w27, [x26]
    56d0:	f1000739 	subs	x25, x25, #0x1
    56d4:	54fffba1 	b.ne	5648 <fwp_loop_fields68.constprop.0+0x4c8>  // b.any
    56d8:	f94017e0 	ldr	x0, [sp, #40]
    56dc:	b4000040 	cbz	x0, 56e4 <fwp_loop_fields68.constprop.0+0x564>
    56e0:	97fff6b4 	bl	31b0 <fwp_mem_free>
    56e4:	f9400be0 	ldr	x0, [sp, #16]
    56e8:	d2800016 	mov	x22, #0x0                   	// #0
    56ec:	97fffbe9 	bl	4690 <fwp_drop0>
    56f0:	f9401be0 	ldr	x0, [sp, #48]
    56f4:	97fffbe7 	bl	4690 <fwp_drop0>
    56f8:	f94003e1 	ldr	x1, [sp]
    56fc:	aa1803e0 	mov	x0, x24
    5700:	97fffad4 	bl	4250 <fwp_map_items>
    5704:	aa0003fb 	mov	x27, x0
    5708:	f94027f4 	ldr	x20, [sp, #72]
    570c:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0xe0>
    5710:	911a4000 	add	x0, x0, #0x690
    5714:	f9002bfb 	str	x27, [sp, #80]
    5718:	a905ffff 	stp	xzr, xzr, [sp, #88]
    571c:	a90683ff 	stp	xzr, x0, [sp, #104]
    5720:	b50003d4 	cbnz	x20, 5798 <fwp_loop_fields68.constprop.0+0x618>
    5724:	14000037 	b	5800 <fwp_loop_fields68.constprop.0+0x680>
    5728:	7100047f 	cmp	w3, #0x1
    572c:	54000261 	b.ne	5778 <fwp_loop_fields68.constprop.0+0x5f8>  // b.any
    5730:	29430c85 	ldp	w5, w3, [x4, #24]
    5734:	92403c21 	and	x1, x1, #0xffff
    5738:	9b057c21 	mul	x1, x1, x5
    573c:	d360fc21 	lsr	x1, x1, #32
    5740:	eb03003f 	cmp	x1, x3
    5744:	540001a2 	b.cs	5778 <fwp_loop_fields68.constprop.0+0x5f8>  // b.hs, b.nlast
    5748:	8b010000 	add	x0, x0, x1
    574c:	39400001 	ldrb	w1, [x0]
    5750:	34000141 	cbz	w1, 5778 <fwp_loop_fields68.constprop.0+0x5f8>
    5754:	b94042a3 	ldr	w3, [x21, #64]
    5758:	34000083 	cbz	w3, 5768 <fwp_loop_fields68.constprop.0+0x5e8>
    575c:	f94026a3 	ldr	x3, [x21, #72]
    5760:	91000463 	add	x3, x3, #0x1
    5764:	f90026a3 	str	x3, [x21, #72]
    5768:	7103f43f 	cmp	w1, #0xfd
    576c:	54001ca8 	b.hi	5b00 <fwp_loop_fields68.constprop.0+0x980>  // b.pmore
    5770:	11000421 	add	w1, w1, #0x1
    5774:	39000001 	strb	w1, [x0]
    5778:	f9400b3a 	ldr	x26, [x25, #16]
    577c:	aa1903e0 	mov	x0, x25
    5780:	97fffb31 	bl	4444 <fwp_drop4>
    5784:	f8367b7a 	str	x26, [x27, x22, lsl #3]
    5788:	910006d6 	add	x22, x22, #0x1
    578c:	f9002ff6 	str	x22, [sp, #88]
    5790:	eb1402df 	cmp	x22, x20
    5794:	54000360 	b.eq	5800 <fwp_loop_fields68.constprop.0+0x680>  // b.none
    5798:	f8767b79 	ldr	x25, [x27, x22, lsl #3]
    579c:	f949db81 	ldr	x1, [x28, #5040]
    57a0:	f949ef80 	ldr	x0, [x28, #5080]
    57a4:	cb010321 	sub	x1, x25, x1
    57a8:	eb00403f 	cmp	x1, x0, lsl #16
    57ac:	54fffe62 	b.cs	5778 <fwp_loop_fields68.constprop.0+0x5f8>  // b.hs, b.nlast
    57b0:	d350fc23 	lsr	x3, x1, #16
    57b4:	f949ff85 	ldr	x5, [x28, #5112]
    57b8:	8b030863 	add	x3, x3, x3, lsl #2
    57bc:	d37df063 	lsl	x3, x3, #3
    57c0:	8b0300a4 	add	x4, x5, x3
    57c4:	f9401080 	ldr	x0, [x4, #32]
    57c8:	b4fffd80 	cbz	x0, 5778 <fwp_loop_fields68.constprop.0+0x5f8>
    57cc:	386368a3 	ldrb	w3, [x5, x3]
    57d0:	7100087f 	cmp	w3, #0x2
    57d4:	54fffaa1 	b.ne	5728 <fwp_loop_fields68.constprop.0+0x5a8>  // b.any
    57d8:	72003c3f 	tst	w1, #0xffff
    57dc:	54fffb80 	b.eq	574c <fwp_loop_fields68.constprop.0+0x5cc>  // b.none
    57e0:	f9400b3a 	ldr	x26, [x25, #16]
    57e4:	aa1903e0 	mov	x0, x25
    57e8:	97fffb17 	bl	4444 <fwp_drop4>
    57ec:	f8367b7a 	str	x26, [x27, x22, lsl #3]
    57f0:	910006d6 	add	x22, x22, #0x1
    57f4:	f9002ff6 	str	x22, [sp, #88]
    57f8:	eb1402df 	cmp	x22, x20
    57fc:	54fffce1 	b.ne	5798 <fwp_loop_fields68.constprop.0+0x618>  // b.any
    5800:	aa1703e0 	mov	x0, x23
    5804:	97fffa40 	bl	4104 <fwp_map_finish_protected.isra.0>
    5808:	f949db81 	ldr	x1, [x28, #5040]
    580c:	aa0003f6 	mov	x22, x0
    5810:	f949ef80 	ldr	x0, [x28, #5080]
    5814:	cb010301 	sub	x1, x24, x1
    5818:	eb00403f 	cmp	x1, x0, lsl #16
    581c:	540003a2 	b.cs	5890 <fwp_loop_fields68.constprop.0+0x710>  // b.hs, b.nlast
    5820:	d350fc23 	lsr	x3, x1, #16
    5824:	f949ff84 	ldr	x4, [x28, #5112]
    5828:	8b030863 	add	x3, x3, x3, lsl #2
    582c:	d37df063 	lsl	x3, x3, #3
    5830:	8b030080 	add	x0, x4, x3
    5834:	f9401014 	ldr	x20, [x0, #32]
    5838:	b40002d4 	cbz	x20, 5890 <fwp_loop_fields68.constprop.0+0x710>
    583c:	38636883 	ldrb	w3, [x4, x3]
    5840:	7100087f 	cmp	w3, #0x2
    5844:	54001580 	b.eq	5af4 <fwp_loop_fields68.constprop.0+0x974>  // b.none
    5848:	7100047f 	cmp	w3, #0x1
    584c:	54000221 	b.ne	5890 <fwp_loop_fields68.constprop.0+0x710>  // b.any
    5850:	29430003 	ldp	w3, w0, [x0, #24]
    5854:	92403c21 	and	x1, x1, #0xffff
    5858:	9b037c21 	mul	x1, x1, x3
    585c:	d360fc21 	lsr	x1, x1, #32
    5860:	eb00003f 	cmp	x1, x0
    5864:	54000162 	b.cs	5890 <fwp_loop_fields68.constprop.0+0x710>  // b.hs, b.nlast
    5868:	8b010294 	add	x20, x20, x1
    586c:	39400280 	ldrb	w0, [x20]
    5870:	34000100 	cbz	w0, 5890 <fwp_loop_fields68.constprop.0+0x710>
    5874:	7100041f 	cmp	w0, #0x1
    5878:	540016e0 	b.eq	5b54 <fwp_loop_fields68.constprop.0+0x9d4>  // b.none
    587c:	7103fc1f 	cmp	w0, #0xff
    5880:	54001f80 	b.eq	5c70 <fwp_loop_fields68.constprop.0+0xaf0>  // b.none
    5884:	51000400 	sub	w0, w0, #0x1
    5888:	39000280 	strb	w0, [x20]
    588c:	d503201f 	nop
    5890:	910263e1 	add	x1, sp, #0x98
    5894:	52800020 	mov	w0, #0x1                   	// #1
    5898:	a909dbff 	stp	xzr, x22, [sp, #152]
    589c:	97fff9a1 	bl	3f20 <fwp_data.part.0.constprop.0>
    58a0:	aa0003f4 	mov	x20, x0
    58a4:	f949db81 	ldr	x1, [x28, #5040]
    58a8:	f949ef80 	ldr	x0, [x28, #5080]
    58ac:	cb010281 	sub	x1, x20, x1
    58b0:	eb00403f 	cmp	x1, x0, lsl #16
    58b4:	54000322 	b.cs	5918 <fwp_loop_fields68.constprop.0+0x798>  // b.hs, b.nlast
    58b8:	d350fc20 	lsr	x0, x1, #16
    58bc:	f949ff84 	ldr	x4, [x28, #5112]
    58c0:	8b000800 	add	x0, x0, x0, lsl #2
    58c4:	d37df003 	lsl	x3, x0, #3
    58c8:	8b030080 	add	x0, x4, x3
    58cc:	f9401016 	ldr	x22, [x0, #32]
    58d0:	b4000256 	cbz	x22, 5918 <fwp_loop_fields68.constprop.0+0x798>
    58d4:	38636883 	ldrb	w3, [x4, x3]
    58d8:	7100087f 	cmp	w3, #0x2
    58dc:	54001360 	b.eq	5b48 <fwp_loop_fields68.constprop.0+0x9c8>  // b.none
    58e0:	7100047f 	cmp	w3, #0x1
    58e4:	540001a1 	b.ne	5918 <fwp_loop_fields68.constprop.0+0x798>  // b.any
    58e8:	29430003 	ldp	w3, w0, [x0, #24]
    58ec:	92403c21 	and	x1, x1, #0xffff
    58f0:	9b037c21 	mul	x1, x1, x3
    58f4:	d360fc21 	lsr	x1, x1, #32
    58f8:	eb00003f 	cmp	x1, x0
    58fc:	540000e2 	b.cs	5918 <fwp_loop_fields68.constprop.0+0x798>  // b.hs, b.nlast
    5900:	8b0102d6 	add	x22, x22, x1
    5904:	394002c0 	ldrb	w0, [x22]
    5908:	7103fc1f 	cmp	w0, #0xff
    590c:	54001a60 	b.eq	5c58 <fwp_loop_fields68.constprop.0+0xad8>  // b.none
    5910:	52800020 	mov	w0, #0x1                   	// #1
    5914:	390002c0 	strb	w0, [x22]
    5918:	f94013e1 	ldr	x1, [sp, #32]
    591c:	aa1403e0 	mov	x0, x20
    5920:	97fffa4c 	bl	4250 <fwp_map_items>
    5924:	aa0003f6 	mov	x22, x0
    5928:	f94003e1 	ldr	x1, [sp]
    592c:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0xe0>
    5930:	911a4003 	add	x3, x0, #0x690
    5934:	aa1303e0 	mov	x0, x19
    5938:	f9002bf6 	str	x22, [sp, #80]
    593c:	a905ffff 	stp	xzr, xzr, [sp, #88]
    5940:	a9068fff 	stp	xzr, x3, [sp, #104]
    5944:	97fffa43 	bl	4250 <fwp_map_items>
    5948:	a9440fe1 	ldp	x1, x3, [sp, #64]
    594c:	eb01007f 	cmp	x3, x1
    5950:	9a819063 	csel	x3, x3, x1, ls	// ls = plast
    5954:	b40017e3 	cbz	x3, 5c50 <fwp_loop_fields68.constprop.0+0xad0>
    5958:	d2800001 	mov	x1, #0x0                   	// #0
    595c:	d503201f 	nop
    5960:	fc617800 	ldr	d0, [x0, x1, lsl #3]
    5964:	fc617ac1 	ldr	d1, [x22, x1, lsl #3]
    5968:	1e612800 	fadd	d0, d0, d1
    596c:	fc217ac0 	str	d0, [x22, x1, lsl #3]
    5970:	91000421 	add	x1, x1, #0x1
    5974:	eb01007f 	cmp	x3, x1
    5978:	54ffff41 	b.ne	5960 <fwp_loop_fields68.constprop.0+0x7e0>  // b.any
    597c:	f9002fe3 	str	x3, [sp, #88]
    5980:	97fff60c 	bl	31b0 <fwp_mem_free>
    5984:	aa1703e0 	mov	x0, x23
    5988:	97fff9df 	bl	4104 <fwp_map_finish_protected.isra.0>
    598c:	aa0003e1 	mov	x1, x0
    5990:	aa1303e0 	mov	x0, x19
    5994:	aa0103f3 	mov	x19, x1
    5998:	97fffb3e 	bl	4690 <fwp_drop0>
    599c:	aa1403e0 	mov	x0, x20
    59a0:	97fffb3c 	bl	4690 <fwp_drop0>
    59a4:	f94003e1 	ldr	x1, [sp]
    59a8:	aa1303e0 	mov	x0, x19
    59ac:	97fffa29 	bl	4250 <fwp_map_items>
    59b0:	f9002be0 	str	x0, [sp, #80]
    59b4:	f94027e3 	ldr	x3, [sp, #72]
    59b8:	f0ffffe1 	adrp	x1, 4000 <fwp_data.part.0.constprop.0+0xe0>
    59bc:	911a4021 	add	x1, x1, #0x690
    59c0:	a905ffff 	stp	xzr, xzr, [sp, #88]
    59c4:	a90687ff 	stp	xzr, x1, [sp, #104]
    59c8:	b4000103 	cbz	x3, 59e8 <fwp_loop_fields68.constprop.0+0x868>
    59cc:	8b030c01 	add	x1, x0, x3, lsl #3
    59d0:	fd400000 	ldr	d0, [x0]
    59d4:	1e600960 	fmul	d0, d11, d0
    59d8:	fc008400 	str	d0, [x0], #8
    59dc:	eb01001f 	cmp	x0, x1
    59e0:	54ffff81 	b.ne	59d0 <fwp_loop_fields68.constprop.0+0x850>  // b.any
    59e4:	f9002fe3 	str	x3, [sp, #88]
    59e8:	aa1703e0 	mov	x0, x23
    59ec:	97fff9c6 	bl	4104 <fwp_map_finish_protected.isra.0>
    59f0:	aa0003e1 	mov	x1, x0
    59f4:	aa1303e0 	mov	x0, x19
    59f8:	aa0103f3 	mov	x19, x1
    59fc:	97fffb25 	bl	4690 <fwp_drop0>
    5a00:	f94007e0 	ldr	x0, [sp, #8]
    5a04:	f94013e1 	ldr	x1, [sp, #32]
    5a08:	97fffa12 	bl	4250 <fwp_map_items>
    5a0c:	aa0003f4 	mov	x20, x0
    5a10:	f94003e1 	ldr	x1, [sp]
    5a14:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0xe0>
    5a18:	911a4003 	add	x3, x0, #0x690
    5a1c:	aa1303e0 	mov	x0, x19
    5a20:	f9002bf4 	str	x20, [sp, #80]
    5a24:	a905ffff 	stp	xzr, xzr, [sp, #88]
    5a28:	a9068fff 	stp	xzr, x3, [sp, #104]
    5a2c:	97fffa09 	bl	4250 <fwp_map_items>
    5a30:	a9440fe1 	ldp	x1, x3, [sp, #64]
    5a34:	eb01007f 	cmp	x3, x1
    5a38:	9a819063 	csel	x3, x3, x1, ls	// ls = plast
    5a3c:	b4001063 	cbz	x3, 5c48 <fwp_loop_fields68.constprop.0+0xac8>
    5a40:	d2800001 	mov	x1, #0x0                   	// #0
    5a44:	d503201f 	nop
    5a48:	fc617a80 	ldr	d0, [x20, x1, lsl #3]
    5a4c:	fc617801 	ldr	d1, [x0, x1, lsl #3]
    5a50:	1e613800 	fsub	d0, d0, d1
    5a54:	fc217a80 	str	d0, [x20, x1, lsl #3]
    5a58:	91000421 	add	x1, x1, #0x1
    5a5c:	eb01007f 	cmp	x3, x1
    5a60:	54ffff41 	b.ne	5a48 <fwp_loop_fields68.constprop.0+0x8c8>  // b.any
    5a64:	f9002fe3 	str	x3, [sp, #88]
    5a68:	97fff5d2 	bl	31b0 <fwp_mem_free>
    5a6c:	aa1703e0 	mov	x0, x23
    5a70:	97fff9a5 	bl	4104 <fwp_map_finish_protected.isra.0>
    5a74:	aa0003e1 	mov	x1, x0
    5a78:	aa1303e0 	mov	x0, x19
    5a7c:	aa0103f3 	mov	x19, x1
    5a80:	97fffb04 	bl	4690 <fwp_drop0>
    5a84:	f94007e0 	ldr	x0, [sp, #8]
    5a88:	97fffb02 	bl	4690 <fwp_drop0>
    5a8c:	f9400fe0 	ldr	x0, [sp, #24]
    5a90:	b4000b80 	cbz	x0, 5c00 <fwp_loop_fields68.constprop.0+0xa80>
    5a94:	f9400fe0 	ldr	x0, [sp, #24]
    5a98:	f1000400 	subs	x0, x0, #0x1
    5a9c:	f9000fe0 	str	x0, [sp, #24]
    5aa0:	54001266 	b.vs	5cec <fwp_loop_fields68.constprop.0+0xb6c>
    5aa4:	f90007f3 	str	x19, [sp, #8]
    5aa8:	f94007e0 	ldr	x0, [sp, #8]
    5aac:	b5ffbae0 	cbnz	x0, 5208 <fwp_loop_fields68.constprop.0+0x88>
    5ab0:	f9000bff 	str	xzr, [sp, #16]
    5ab4:	17fffdd7 	b	5210 <fwp_loop_fields68.constprop.0+0x90>
    5ab8:	f90017e0 	str	x0, [sp, #40]
    5abc:	97fff51d 	bl	2f30 <fwp_rc_forget_slot>
    5ac0:	f94017e0 	ldr	x0, [sp, #40]
    5ac4:	17fffe3b 	b	53b0 <fwp_loop_fields68.constprop.0+0x230>
    5ac8:	72003c3f 	tst	w1, #0xffff
    5acc:	54ffc741 	b.ne	53b4 <fwp_loop_fields68.constprop.0+0x234>  // b.any
    5ad0:	17fffe35 	b	53a4 <fwp_loop_fields68.constprop.0+0x224>
    5ad4:	aa1a03e0 	mov	x0, x26
    5ad8:	97fff516 	bl	2f30 <fwp_rc_forget_slot>
    5adc:	17fffefc 	b	56cc <fwp_loop_fields68.constprop.0+0x54c>
    5ae0:	72003c3f 	tst	w1, #0xffff
    5ae4:	54ffdf61 	b.ne	56d0 <fwp_loop_fields68.constprop.0+0x550>  // b.any
    5ae8:	17fffef6 	b	56c0 <fwp_loop_fields68.constprop.0+0x540>
    5aec:	b4ffc720 	cbz	x0, 53d0 <fwp_loop_fields68.constprop.0+0x250>
    5af0:	17fffe36 	b	53c8 <fwp_loop_fields68.constprop.0+0x248>
    5af4:	72003c3f 	tst	w1, #0xffff
    5af8:	54ffecc1 	b.ne	5890 <fwp_loop_fields68.constprop.0+0x710>  // b.any
    5afc:	17ffff5c 	b	586c <fwp_loop_fields68.constprop.0+0x6ec>
    5b00:	97fff4c5 	bl	2e14 <fwp_rc_wide_dup>
    5b04:	17ffff1d 	b	5778 <fwp_loop_fields68.constprop.0+0x5f8>
    5b08:	97fff4c3 	bl	2e14 <fwp_rc_wide_dup>
    5b0c:	17fffe7a 	b	54f4 <fwp_loop_fields68.constprop.0+0x374>
    5b10:	72003c3f 	tst	w1, #0xffff
    5b14:	54ffd8a1 	b.ne	5628 <fwp_loop_fields68.constprop.0+0x4a8>  // b.any
    5b18:	17fffeb9 	b	55fc <fwp_loop_fields68.constprop.0+0x47c>
    5b1c:	72003c3f 	tst	w1, #0xffff
    5b20:	54ffca81 	b.ne	5470 <fwp_loop_fields68.constprop.0+0x2f0>  // b.any
    5b24:	39400260 	ldrb	w0, [x19]
    5b28:	7103fc1f 	cmp	w0, #0xff
    5b2c:	54ffc9e1 	b.ne	5468 <fwp_loop_fields68.constprop.0+0x2e8>  // b.any
    5b30:	aa1303e0 	mov	x0, x19
    5b34:	97fff4ff 	bl	2f30 <fwp_rc_forget_slot>
    5b38:	17fffe4c 	b	5468 <fwp_loop_fields68.constprop.0+0x2e8>
    5b3c:	72003c3f 	tst	w1, #0xffff
    5b40:	54ffbb01 	b.ne	52a0 <fwp_loop_fields68.constprop.0+0x120>  // b.any
    5b44:	17fffdcc 	b	5274 <fwp_loop_fields68.constprop.0+0xf4>
    5b48:	72003c3f 	tst	w1, #0xffff
    5b4c:	54ffee61 	b.ne	5918 <fwp_loop_fields68.constprop.0+0x798>  // b.any
    5b50:	17ffff6d 	b	5904 <fwp_loop_fields68.constprop.0+0x784>
    5b54:	f9400700 	ldr	x0, [x24, #8]
    5b58:	97fffa3b 	bl	4444 <fwp_drop4>
    5b5c:	f949ef84 	ldr	x4, [x28, #5080]
    5b60:	f949db81 	ldr	x1, [x28, #5040]
    5b64:	d370bc84 	lsl	x4, x4, #16
    5b68:	cb010303 	sub	x3, x24, x1
    5b6c:	f9400b14 	ldr	x20, [x24, #16]
    5b70:	eb04007f 	cmp	x3, x4
    5b74:	540003c2 	b.cs	5bec <fwp_loop_fields68.constprop.0+0xa6c>  // b.hs, b.nlast
    5b78:	d350fc60 	lsr	x0, x3, #16
    5b7c:	f949ff87 	ldr	x7, [x28, #5112]
    5b80:	8b000800 	add	x0, x0, x0, lsl #2
    5b84:	d37df000 	lsl	x0, x0, #3
    5b88:	8b0000e6 	add	x6, x7, x0
    5b8c:	f94010c5 	ldr	x5, [x6, #32]
    5b90:	b40002e5 	cbz	x5, 5bec <fwp_loop_fields68.constprop.0+0xa6c>
    5b94:	386068e0 	ldrb	w0, [x7, x0]
    5b98:	7100081f 	cmp	w0, #0x2
    5b9c:	54000640 	b.eq	5c64 <fwp_loop_fields68.constprop.0+0xae4>  // b.none
    5ba0:	7100041f 	cmp	w0, #0x1
    5ba4:	54000241 	b.ne	5bec <fwp_loop_fields68.constprop.0+0xa6c>  // b.any
    5ba8:	92403c60 	and	x0, x3, #0xffff
    5bac:	29430cc7 	ldp	w7, w3, [x6, #24]
    5bb0:	9b077c00 	mul	x0, x0, x7
    5bb4:	d360fc00 	lsr	x0, x0, #32
    5bb8:	eb03001f 	cmp	x0, x3
    5bbc:	54000182 	b.cs	5bec <fwp_loop_fields68.constprop.0+0xa6c>  // b.hs, b.nlast
    5bc0:	8b0000a5 	add	x5, x5, x0
    5bc4:	394000a0 	ldrb	w0, [x5]
    5bc8:	7100041f 	cmp	w0, #0x1
    5bcc:	54000101 	b.ne	5bec <fwp_loop_fields68.constprop.0+0xa6c>  // b.any
    5bd0:	aa1803e0 	mov	x0, x24
    5bd4:	97fff577 	bl	31b0 <fwp_mem_free>
    5bd8:	90000160 	adrp	x0, 31000 <fwp_root_context+0xcb0>
    5bdc:	9114c000 	add	x0, x0, #0x530
    5be0:	f949ec04 	ldr	x4, [x0, #5080]
    5be4:	f949d801 	ldr	x1, [x0, #5040]
    5be8:	d370bc84 	lsl	x4, x4, #16
    5bec:	cb010281 	sub	x1, x20, x1
    5bf0:	eb01009f 	cmp	x4, x1
    5bf4:	54ffe4e9 	b.ls	5890 <fwp_loop_fields68.constprop.0+0x710>  // b.plast
    5bf8:	aa1403f8 	mov	x24, x20
    5bfc:	17ffff09 	b	5820 <fwp_loop_fields68.constprop.0+0x6a0>
    5c00:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    5c04:	f947f400 	ldr	x0, [x0, #4072]
    5c08:	f94057e2 	ldr	x2, [sp, #168]
    5c0c:	f9400001 	ldr	x1, [x0]
    5c10:	eb010042 	subs	x2, x2, x1
    5c14:	d2800001 	mov	x1, #0x0                   	// #0
    5c18:	54000681 	b.ne	5ce8 <fwp_loop_fields68.constprop.0+0xb68>  // b.any
    5c1c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    5c20:	aa1303e0 	mov	x0, x19
    5c24:	a94c53f3 	ldp	x19, x20, [sp, #192]
    5c28:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    5c2c:	a94e63f7 	ldp	x23, x24, [sp, #224]
    5c30:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    5c34:	a95073fb 	ldp	x27, x28, [sp, #256]
    5c38:	6d5127e8 	ldp	d8, d9, [sp, #272]
    5c3c:	6d522fea 	ldp	d10, d11, [sp, #288]
    5c40:	9104c3ff 	add	sp, sp, #0x130
    5c44:	d65f03c0 	ret
    5c48:	b4fff120 	cbz	x0, 5a6c <fwp_loop_fields68.constprop.0+0x8ec>
    5c4c:	17ffff87 	b	5a68 <fwp_loop_fields68.constprop.0+0x8e8>
    5c50:	b4ffe9a0 	cbz	x0, 5984 <fwp_loop_fields68.constprop.0+0x804>
    5c54:	17ffff4b 	b	5980 <fwp_loop_fields68.constprop.0+0x800>
    5c58:	aa1603e0 	mov	x0, x22
    5c5c:	97fff4b5 	bl	2f30 <fwp_rc_forget_slot>
    5c60:	17ffff2c 	b	5910 <fwp_loop_fields68.constprop.0+0x790>
    5c64:	72003c7f 	tst	w3, #0xffff
    5c68:	54fffc21 	b.ne	5bec <fwp_loop_fields68.constprop.0+0xa6c>  // b.any
    5c6c:	17ffffd6 	b	5bc4 <fwp_loop_fields68.constprop.0+0xa44>
    5c70:	ca544680 	eor	x0, x20, x20, lsr #17
    5c74:	90000161 	adrp	x1, 31000 <fwp_root_context+0xcb0>
    5c78:	9114c021 	add	x1, x1, #0x530
    5c7c:	ca402400 	eor	x0, x0, x0, lsr #9
    5c80:	8b200c20 	add	x0, x1, w0, uxtb #3
    5c84:	f94a2400 	ldr	x0, [x0, #5192]
    5c88:	b5000080 	cbnz	x0, 5c98 <fwp_loop_fields68.constprop.0+0xb18>
    5c8c:	14000014 	b	5cdc <fwp_loop_fields68.constprop.0+0xb5c>
    5c90:	f9400800 	ldr	x0, [x0, #16]
    5c94:	b4000240 	cbz	x0, 5cdc <fwp_loop_fields68.constprop.0+0xb5c>
    5c98:	f9400001 	ldr	x1, [x0]
    5c9c:	eb01029f 	cmp	x20, x1
    5ca0:	54ffff81 	b.ne	5c90 <fwp_loop_fields68.constprop.0+0xb10>  // b.any
    5ca4:	f9400401 	ldr	x1, [x0, #8]
    5ca8:	d1000421 	sub	x1, x1, #0x1
    5cac:	f9000401 	str	x1, [x0, #8]
    5cb0:	f103f83f 	cmp	x1, #0xfe
    5cb4:	54ffdee1 	b.ne	5890 <fwp_loop_fields68.constprop.0+0x710>  // b.any
    5cb8:	aa1403e0 	mov	x0, x20
    5cbc:	97fff49d 	bl	2f30 <fwp_rc_forget_slot>
    5cc0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5cc4:	39000280 	strb	w0, [x20]
    5cc8:	17fffef2 	b	5890 <fwp_loop_fields68.constprop.0+0x710>
    5ccc:	97fff452 	bl	2e14 <fwp_rc_wide_dup>
    5cd0:	17fffd74 	b	52a0 <fwp_loop_fields68.constprop.0+0x120>
    5cd4:	97fff450 	bl	2e14 <fwp_rc_wide_dup>
    5cd8:	17fffe54 	b	5628 <fwp_loop_fields68.constprop.0+0x4a8>
    5cdc:	b0000020 	adrp	x0, a000 <__divti3+0x2e0>
    5ce0:	911c8000 	add	x0, x0, #0x720
    5ce4:	97fff187 	bl	2300 <fwp_trap>
    5ce8:	97ffee1a 	bl	1550 <__stack_chk_fail@plt>
    5cec:	97ffee95 	bl	1740 <fwp_trap_overflow.constprop.0>

0000000000005cf0 <fwp_write>:
    5cf0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5cf4:	910003fd 	mov	x29, sp
    5cf8:	d00000c4 	adrp	x4, 1f000 <__FRAME_END__+0x132b8>
    5cfc:	f947f484 	ldr	x4, [x4, #4072]
    5d00:	a90153f3 	stp	x19, x20, [sp, #16]
    5d04:	d10943ff 	sub	sp, sp, #0x250
    5d08:	b9400045 	ldr	w5, [x2]
    5d0c:	aa0003f4 	mov	x20, x0
    5d10:	f9400080 	ldr	x0, [x4]
    5d14:	f90127e0 	str	x0, [sp, #584]
    5d18:	d2800000 	mov	x0, #0x0                   	// #0
    5d1c:	710064bf 	cmp	w5, #0x19
    5d20:	54000408 	b.hi	5da0 <fwp_write+0xb0>  // b.pmore
    5d24:	b0000020 	adrp	x0, a000 <__divti3+0x2e0>
    5d28:	aa0103f3 	mov	x19, x1
    5d2c:	912ac000 	add	x0, x0, #0xab0
    5d30:	f9013bf5 	str	x21, [sp, #624]
    5d34:	f9013ff6 	str	x22, [sp, #632]
    5d38:	f90153fb 	str	x27, [sp, #672]
    5d3c:	f90157fc 	str	x28, [sp, #680]
    5d40:	aa0203fc 	mov	x28, x2
    5d44:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    5d48:	10000061 	adr	x1, 5d54 <fwp_write+0x64>
    5d4c:	8b20a820 	add	x0, x1, w0, sxth #2
    5d50:	d61f0000 	br	x0
    5d54:	910123e0 	add	x0, sp, #0x48
    5d58:	aa1303e5 	mov	x5, x19
    5d5c:	b0000024 	adrp	x4, a000 <__divti3+0x2e0>
    5d60:	aa0003f3 	mov	x19, x0
    5d64:	911fc084 	add	x4, x4, #0x7f0
    5d68:	d2804003 	mov	x3, #0x200                 	// #512
    5d6c:	aa0303e1 	mov	x1, x3
    5d70:	52800042 	mov	w2, #0x2                   	// #2
    5d74:	97ffedd3 	bl	14c0 <__snprintf_chk@plt>
    5d78:	aa1303e0 	mov	x0, x19
    5d7c:	97ffed99 	bl	13e0 <strlen@plt>
    5d80:	aa1303e1 	mov	x1, x19
    5d84:	aa0003e2 	mov	x2, x0
    5d88:	aa1403e0 	mov	x0, x20
    5d8c:	97fff101 	bl	2190 <buf_put>
    5d90:	f9413bf5 	ldr	x21, [sp, #624]
    5d94:	f9413ff6 	ldr	x22, [sp, #632]
    5d98:	f94153fb 	ldr	x27, [sp, #672]
    5d9c:	f94157fc 	ldr	x28, [sp, #680]
    5da0:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    5da4:	f947f400 	ldr	x0, [x0, #4072]
    5da8:	f94127e2 	ldr	x2, [sp, #584]
    5dac:	f9400001 	ldr	x1, [x0]
    5db0:	eb010042 	subs	x2, x2, x1
    5db4:	d2800001 	mov	x1, #0x0                   	// #0
    5db8:	540077c1 	b.ne	6cb0 <fwp_write+0xfc0>  // b.any
    5dbc:	910943ff 	add	sp, sp, #0x250
    5dc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5dc4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5dc8:	d65f03c0 	ret
    5dcc:	910123e0 	add	x0, sp, #0x48
    5dd0:	aa1303e5 	mov	x5, x19
    5dd4:	b0000024 	adrp	x4, a000 <__divti3+0x2e0>
    5dd8:	aa0003f3 	mov	x19, x0
    5ddc:	911fa084 	add	x4, x4, #0x7e8
    5de0:	d2804003 	mov	x3, #0x200                 	// #512
    5de4:	17ffffe2 	b	5d6c <fwp_write+0x7c>
    5de8:	71004cbf 	cmp	w5, #0x13
    5dec:	b0000020 	adrp	x0, a000 <__divti3+0x2e0>
    5df0:	b0000021 	adrp	x1, a000 <__divti3+0x2e0>
    5df4:	911f6000 	add	x0, x0, #0x7d8
    5df8:	911f8021 	add	x1, x1, #0x7e0
    5dfc:	d2800082 	mov	x2, #0x4                   	// #4
    5e00:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    5e04:	aa1403e0 	mov	x0, x20
    5e08:	f90143f7 	str	x23, [sp, #640]
    5e0c:	d2800016 	mov	x22, #0x0                   	// #0
    5e10:	f90147f8 	str	x24, [sp, #648]
    5e14:	97fff0df 	bl	2190 <buf_put>
    5e18:	f9400260 	ldr	x0, [x19]
    5e1c:	b0000037 	adrp	x23, a000 <__divti3+0x2e0>
    5e20:	d2800015 	mov	x21, #0x0                   	// #0
    5e24:	912182f7 	add	x23, x23, #0x860
    5e28:	b40047a0 	cbz	x0, 671c <fwp_write+0xa2c>
    5e2c:	b9400380 	ldr	w0, [x28]
    5e30:	52800003 	mov	w3, #0x0                   	// #0
    5e34:	f9401f82 	ldr	x2, [x28, #56]
    5e38:	71004c1f 	cmp	w0, #0x13
    5e3c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    5e40:	aa1403e0 	mov	x0, x20
    5e44:	8b010e61 	add	x1, x19, x1, lsl #3
    5e48:	f9400421 	ldr	x1, [x1, #8]
    5e4c:	97ffffa9 	bl	5cf0 <fwp_write>
    5e50:	b9400380 	ldr	w0, [x28]
    5e54:	7100481f 	cmp	w0, #0x12
    5e58:	54004b40 	b.eq	67c0 <fwp_write+0xad0>  // b.none
    5e5c:	f9400260 	ldr	x0, [x19]
    5e60:	910006b5 	add	x21, x21, #0x1
    5e64:	91000ad6 	add	x22, x22, #0x2
    5e68:	eb15001f 	cmp	x0, x21
    5e6c:	54004589 	b.ls	671c <fwp_write+0xa2c>  // b.plast
    5e70:	aa1703e1 	mov	x1, x23
    5e74:	aa1403e0 	mov	x0, x20
    5e78:	d2800042 	mov	x2, #0x2                   	// #2
    5e7c:	97fff0c5 	bl	2190 <buf_put>
    5e80:	17ffffeb 	b	5e2c <fwp_write+0x13c>
    5e84:	b0000021 	adrp	x1, a000 <__divti3+0x2e0>
    5e88:	91206021 	add	x1, x1, #0x818
    5e8c:	d28000c2 	mov	x2, #0x6                   	// #6
    5e90:	aa1403e0 	mov	x0, x20
    5e94:	91004273 	add	x19, x19, #0x10
    5e98:	97fff0be 	bl	2190 <buf_put>
    5e9c:	aa1303e0 	mov	x0, x19
    5ea0:	97ffed50 	bl	13e0 <strlen@plt>
    5ea4:	aa1303e1 	mov	x1, x19
    5ea8:	aa0003e2 	mov	x2, x0
    5eac:	aa1403e0 	mov	x0, x20
    5eb0:	97fff0b8 	bl	2190 <buf_put>
    5eb4:	528007c3 	mov	w3, #0x3e                  	// #62
    5eb8:	aa1403e0 	mov	x0, x20
    5ebc:	91001fe1 	add	x1, sp, #0x7
    5ec0:	d2800022 	mov	x2, #0x1                   	// #1
    5ec4:	39001fe3 	strb	w3, [sp, #7]
    5ec8:	17ffffb1 	b	5d8c <fwp_write+0x9c>
    5ecc:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    5ed0:	f947f400 	ldr	x0, [x0, #4072]
    5ed4:	f94127e2 	ldr	x2, [sp, #584]
    5ed8:	f9400001 	ldr	x1, [x0]
    5edc:	eb010042 	subs	x2, x2, x1
    5ee0:	d2800001 	mov	x1, #0x0                   	// #0
    5ee4:	540034e1 	b.ne	6580 <fwp_write+0x890>  // b.any
    5ee8:	f9413bf5 	ldr	x21, [sp, #624]
    5eec:	b0000021 	adrp	x1, a000 <__divti3+0x2e0>
    5ef0:	f9413ff6 	ldr	x22, [sp, #632]
    5ef4:	aa1403e0 	mov	x0, x20
    5ef8:	911fe021 	add	x1, x1, #0x7f8
    5efc:	d2800142 	mov	x2, #0xa                   	// #10
    5f00:	f94153fb 	ldr	x27, [sp, #672]
    5f04:	f94157fc 	ldr	x28, [sp, #680]
    5f08:	910943ff 	add	sp, sp, #0x250
    5f0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f10:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5f14:	17fff09f 	b	2190 <buf_put>
    5f18:	f9400456 	ldr	x22, [x2, #8]
    5f1c:	f90143f7 	str	x23, [sp, #640]
    5f20:	f90147f8 	str	x24, [sp, #648]
    5f24:	b4005b16 	cbz	x22, 6a84 <fwp_write+0xd94>
    5f28:	aa1603e0 	mov	x0, x22
    5f2c:	b0000021 	adrp	x1, a000 <__divti3+0x2e0>
    5f30:	9121e021 	add	x1, x1, #0x878
    5f34:	97ffeda7 	bl	15d0 <strcmp@plt>
    5f38:	2a0003f5 	mov	w21, w0
    5f3c:	34005fe0 	cbz	w0, 6b38 <fwp_write+0xe48>
    5f40:	aa1603e0 	mov	x0, x22
    5f44:	97ffed27 	bl	13e0 <strlen@plt>
    5f48:	aa1603e1 	mov	x1, x22
    5f4c:	aa0003e2 	mov	x2, x0
    5f50:	aa1403e0 	mov	x0, x20
    5f54:	97fff08f 	bl	2190 <buf_put>
    5f58:	52800403 	mov	w3, #0x20                  	// #32
    5f5c:	91001ff5 	add	x21, sp, #0x7
    5f60:	aa1503e1 	mov	x1, x21
    5f64:	aa1403e0 	mov	x0, x20
    5f68:	d2800022 	mov	x2, #0x1                   	// #1
    5f6c:	39001fe3 	strb	w3, [sp, #7]
    5f70:	97fff088 	bl	2190 <buf_put>
    5f74:	52800f63 	mov	w3, #0x7b                  	// #123
    5f78:	aa1403e0 	mov	x0, x20
    5f7c:	aa1503e1 	mov	x1, x21
    5f80:	d2800022 	mov	x2, #0x1                   	// #1
    5f84:	39001fe3 	strb	w3, [sp, #7]
    5f88:	97fff082 	bl	2190 <buf_put>
    5f8c:	b9401380 	ldr	w0, [x28, #16]
    5f90:	52800018 	mov	w24, #0x0                   	// #0
    5f94:	7100001f 	cmp	w0, #0x0
    5f98:	54003aad 	b.le	66ec <fwp_write+0x9fc>
    5f9c:	f9014bf9 	str	x25, [sp, #656]
    5fa0:	b0000039 	adrp	x25, a000 <__divti3+0x2e0>
    5fa4:	91228339 	add	x25, x25, #0x8a0
    5fa8:	f9014ffa 	str	x26, [sp, #664]
    5fac:	b000003a 	adrp	x26, a000 <__divti3+0x2e0>
    5fb0:	9121835a 	add	x26, x26, #0x860
    5fb4:	91002276 	add	x22, x19, #0x8
    5fb8:	d2800013 	mov	x19, #0x0                   	// #0
    5fbc:	b5003e93 	cbnz	x19, 678c <fwp_write+0xa9c>
    5fc0:	d37df277 	lsl	x23, x19, #3
    5fc4:	34003cb8 	cbz	w24, 6758 <fwp_write+0xa68>
    5fc8:	f9401382 	ldr	x2, [x28, #32]
    5fcc:	aa1403e0 	mov	x0, x20
    5fd0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    5fd4:	52800003 	mov	w3, #0x0                   	// #0
    5fd8:	f8776842 	ldr	x2, [x2, x23]
    5fdc:	91000673 	add	x19, x19, #0x1
    5fe0:	97ffff44 	bl	5cf0 <fwp_write>
    5fe4:	b9401380 	ldr	w0, [x28, #16]
    5fe8:	6b13001f 	cmp	w0, w19
    5fec:	54fffe8c 	b.gt	5fbc <fwp_write+0x2cc>
    5ff0:	f9414bf9 	ldr	x25, [sp, #656]
    5ff4:	f9414ffa 	ldr	x26, [sp, #664]
    5ff8:	340037b8 	cbz	w24, 66ec <fwp_write+0x9fc>
    5ffc:	52800523 	mov	w3, #0x29                  	// #41
    6000:	aa1503e1 	mov	x1, x21
    6004:	aa1403e0 	mov	x0, x20
    6008:	d2800022 	mov	x2, #0x1                   	// #1
    600c:	39001fe3 	strb	w3, [sp, #7]
    6010:	97fff060 	bl	2190 <buf_put>
    6014:	f9413bf5 	ldr	x21, [sp, #624]
    6018:	f9413ff6 	ldr	x22, [sp, #632]
    601c:	f94143f7 	ldr	x23, [sp, #640]
    6020:	f94147f8 	ldr	x24, [sp, #648]
    6024:	f94153fb 	ldr	x27, [sp, #672]
    6028:	f94157fc 	ldr	x28, [sp, #680]
    602c:	17ffff5d 	b	5da0 <fwp_write+0xb0>
    6030:	b9404855 	ldr	w21, [x2, #72]
    6034:	aa1403e0 	mov	x0, x20
    6038:	93407eb6 	sxtw	x22, w21
    603c:	91000ac1 	add	x1, x22, #0x2
    6040:	97fff020 	bl	20c0 <buf_grow>
    6044:	a9400281 	ldp	x1, x0, [x20]
    6048:	528e8603 	mov	w3, #0x7430                	// #29744
    604c:	78206823 	strh	w3, [x1, x0]
    6050:	8b000022 	add	x2, x1, x0
    6054:	710002bf 	cmp	w21, #0x0
    6058:	540036cd 	b.le	6730 <fwp_write+0xa40>
    605c:	110006a3 	add	w3, w21, #0x1
    6060:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    6064:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    6068:	91000449 	add	x9, x2, #0x1
    606c:	8b23c043 	add	x3, x2, w3, sxtw
    6070:	f28aaac6 	movk	x6, #0x5556
    6074:	f2955568 	movk	x8, #0xaaab
    6078:	1400000d 	b	60ac <fwp_write+0x3bc>
    607c:	d2800021 	mov	x1, #0x1                   	// #1
    6080:	528005a5 	mov	w5, #0x2d                  	// #45
    6084:	f100001f 	cmp	x0, #0x0
    6088:	9b467e60 	smulh	x0, x19, x6
    608c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    6090:	381ff465 	strb	w5, [x3], #-1
    6094:	cb040000 	sub	x0, x0, x4
    6098:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    609c:	cb020000 	sub	x0, x0, x2
    60a0:	8b010013 	add	x19, x0, x1
    60a4:	eb03013f 	cmp	x9, x3
    60a8:	54003440 	b.eq	6730 <fwp_write+0xa40>  // b.none
    60ac:	9b467e60 	smulh	x0, x19, x6
    60b0:	937ffe64 	asr	x4, x19, #63
    60b4:	52800605 	mov	w5, #0x30                  	// #48
    60b8:	cb040000 	sub	x0, x0, x4
    60bc:	8b000400 	add	x0, x0, x0, lsl #1
    60c0:	cb000260 	sub	x0, x19, x0
    60c4:	91000c01 	add	x1, x0, #0x3
    60c8:	9bc87c22 	umulh	x2, x1, x8
    60cc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    60d0:	8b4204e2 	add	x2, x7, x2, lsr #1
    60d4:	eb020021 	subs	x1, x1, x2
    60d8:	54fffd60 	b.eq	6084 <fwp_write+0x394>  // b.none
    60dc:	f100043f 	cmp	x1, #0x1
    60e0:	54fffce1 	b.ne	607c <fwp_write+0x38c>  // b.any
    60e4:	d2800001 	mov	x1, #0x0                   	// #0
    60e8:	52800565 	mov	w5, #0x2b                  	// #43
    60ec:	17ffffe6 	b	6084 <fwp_write+0x394>
    60f0:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    60f4:	f947f400 	ldr	x0, [x0, #4072]
    60f8:	f94127e2 	ldr	x2, [sp, #584]
    60fc:	f9400001 	ldr	x1, [x0]
    6100:	eb010042 	subs	x2, x2, x1
    6104:	d2800001 	mov	x1, #0x0                   	// #0
    6108:	540023c1 	b.ne	6580 <fwp_write+0x890>  // b.any
    610c:	f9413bf5 	ldr	x21, [sp, #624]
    6110:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    6114:	f9413ff6 	ldr	x22, [sp, #632]
    6118:	aa1403e0 	mov	x0, x20
    611c:	91202021 	add	x1, x1, #0x808
    6120:	d2800102 	mov	x2, #0x8                   	// #8
    6124:	17ffff77 	b	5f00 <fwp_write+0x210>
    6128:	aa1403e0 	mov	x0, x20
    612c:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    6130:	d28000c2 	mov	x2, #0x6                   	// #6
    6134:	9121a021 	add	x1, x1, #0x868
    6138:	97fff016 	bl	2190 <buf_put>
    613c:	d2800015 	mov	x21, #0x0                   	// #0
    6140:	f9400263 	ldr	x3, [x19]
    6144:	f240f87f 	tst	x3, #0x7fffffffffffffff
    6148:	54002c60 	b.eq	66d4 <fwp_write+0x9e4>  // b.none
    614c:	f9401f82 	ldr	x2, [x28, #56]
    6150:	f90143f7 	str	x23, [sp, #640]
    6154:	f90147f8 	str	x24, [sp, #648]
    6158:	d2800857 	mov	x23, #0x42                  	// #66
    615c:	f9014bf9 	str	x25, [sp, #656]
    6160:	90000036 	adrp	x22, a000 <__divti3+0x2e0>
    6164:	f9014ffa 	str	x26, [sp, #664]
    6168:	912182d6 	add	x22, x22, #0x860
    616c:	d2800038 	mov	x24, #0x1                   	// #1
    6170:	f2a18017 	movk	x23, #0xc00, lsl #16
    6174:	d2809099 	mov	x25, #0x484                 	// #1156
    6178:	b40004a2 	cbz	x2, 620c <fwp_write+0x51c>
    617c:	b9400040 	ldr	w0, [x2]
    6180:	7100701f 	cmp	w0, #0x1c
    6184:	540042c0 	b.eq	69dc <fwp_write+0xcec>  // b.none
    6188:	71006c1f 	cmp	w0, #0x1b
    618c:	54000408 	b.hi	620c <fwp_write+0x51c>  // b.pmore
    6190:	9ac02301 	lsl	x1, x24, x0
    6194:	ea17003f 	tst	x1, x23
    6198:	540036a1 	b.ne	686c <fwp_write+0xb7c>  // b.any
    619c:	ea19003f 	tst	x1, x25
    61a0:	54003521 	b.ne	6844 <fwp_write+0xb54>  // b.any
    61a4:	d2800424 	mov	x4, #0x21                  	// #33
    61a8:	ea04003f 	tst	x1, x4
    61ac:	54000300 	b.eq	620c <fwp_write+0x51c>  // b.none
    61b0:	b7f849c3 	tbnz	x3, #63, 6ae8 <fwp_write+0xdf8>
    61b4:	91002261 	add	x1, x19, #0x8
    61b8:	8b150021 	add	x1, x1, x21
    61bc:	39400021 	ldrb	w1, [x1]
    61c0:	7100001f 	cmp	w0, #0x0
    61c4:	93401c23 	sxtb	x3, w1
    61c8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    61cc:	d503201f 	nop
    61d0:	aa1403e0 	mov	x0, x20
    61d4:	52800003 	mov	w3, #0x0                   	// #0
    61d8:	97fffec6 	bl	5cf0 <fwp_write>
    61dc:	910006b5 	add	x21, x21, #0x1
    61e0:	f9400260 	ldr	x0, [x19]
    61e4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    61e8:	eb0002bf 	cmp	x21, x0
    61ec:	540026c2 	b.cs	66c4 <fwp_write+0x9d4>  // b.hs, b.nlast
    61f0:	d2800042 	mov	x2, #0x2                   	// #2
    61f4:	aa1603e1 	mov	x1, x22
    61f8:	aa1403e0 	mov	x0, x20
    61fc:	97ffefe5 	bl	2190 <buf_put>
    6200:	f9401f82 	ldr	x2, [x28, #56]
    6204:	f9400263 	ldr	x3, [x19]
    6208:	b5fffba2 	cbnz	x2, 617c <fwp_write+0x48c>
    620c:	d37df2a0 	lsl	x0, x21, #3
    6210:	b7f83f03 	tbnz	x3, #63, 69f0 <fwp_write+0xd00>
    6214:	91002261 	add	x1, x19, #0x8
    6218:	8b000020 	add	x0, x1, x0
    621c:	f9400001 	ldr	x1, [x0]
    6220:	17ffffec 	b	61d0 <fwp_write+0x4e0>
    6224:	a9400e62 	ldp	x2, x3, [x19]
    6228:	b7f83ca3 	tbnz	x3, #63, 69bc <fwp_write+0xccc>
    622c:	910123f5 	add	x21, sp, #0x48
    6230:	aa1503e0 	mov	x0, x21
    6234:	97ffee1b 	bl	1aa0 <fwp_fmt_u128>
    6238:	aa1503e0 	mov	x0, x21
    623c:	97ffec69 	bl	13e0 <strlen@plt>
    6240:	aa1503e1 	mov	x1, x21
    6244:	aa0003e2 	mov	x2, x0
    6248:	17fffed0 	b	5d88 <fwp_write+0x98>
    624c:	fd015be8 	str	d8, [sp, #688]
    6250:	1e270268 	fmov	s8, w19
    6254:	fd015fe9 	str	d9, [sp, #696]
    6258:	1e282100 	fcmp	s8, s8
    625c:	54004d26 	b.vs	6c00 <fwp_write+0xf10>
    6260:	1e20c101 	fabs	s1, s8
    6264:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    6268:	1e270000 	fmov	s0, w0
    626c:	1e202020 	fcmp	s1, s0
    6270:	54002c0d 	b.le	67f0 <fwp_write+0xb00>
    6274:	1e202118 	fcmpe	s8, #0.0
    6278:	90000022 	adrp	x2, a000 <__divti3+0x2e0>
    627c:	91154042 	add	x2, x2, #0x550
    6280:	910123f5 	add	x21, sp, #0x48
    6284:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    6288:	911ee021 	add	x1, x1, #0x7b8
    628c:	aa1503e0 	mov	x0, x21
    6290:	9a81c041 	csel	x1, x2, x1, gt
    6294:	97ffecff 	bl	1690 <strcpy@plt>
    6298:	aa1503e0 	mov	x0, x21
    629c:	97ffec51 	bl	13e0 <strlen@plt>
    62a0:	aa1503e1 	mov	x1, x21
    62a4:	aa0003e2 	mov	x2, x0
    62a8:	aa1403e0 	mov	x0, x20
    62ac:	97ffefb9 	bl	2190 <buf_put>
    62b0:	f9413bf5 	ldr	x21, [sp, #624]
    62b4:	f9413ff6 	ldr	x22, [sp, #632]
    62b8:	f94153fb 	ldr	x27, [sp, #672]
    62bc:	f94157fc 	ldr	x28, [sp, #680]
    62c0:	fd415be8 	ldr	d8, [sp, #688]
    62c4:	fd415fe9 	ldr	d9, [sp, #696]
    62c8:	17fffeb6 	b	5da0 <fwp_write+0xb0>
    62cc:	f9400276 	ldr	x22, [x19]
    62d0:	34002e03 	cbz	w3, 6890 <fwp_write+0xba0>
    62d4:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    62d8:	f947f400 	ldr	x0, [x0, #4072]
    62dc:	f94127e2 	ldr	x2, [sp, #584]
    62e0:	f9400001 	ldr	x1, [x0]
    62e4:	eb010042 	subs	x2, x2, x1
    62e8:	d2800001 	mov	x1, #0x0                   	// #0
    62ec:	540014a1 	b.ne	6580 <fwp_write+0x890>  // b.any
    62f0:	aa1603e2 	mov	x2, x22
    62f4:	91002261 	add	x1, x19, #0x8
    62f8:	f9413bf5 	ldr	x21, [sp, #624]
    62fc:	aa1403e0 	mov	x0, x20
    6300:	f9413ff6 	ldr	x22, [sp, #632]
    6304:	17fffeff 	b	5f00 <fwp_write+0x210>
    6308:	fd015be8 	str	d8, [sp, #688]
    630c:	9e670268 	fmov	d8, x19
    6310:	fd015fe9 	str	d9, [sp, #696]
    6314:	1e682100 	fcmp	d8, d8
    6318:	54004746 	b.vs	6c00 <fwp_write+0xf10>
    631c:	1e60c101 	fabs	d1, d8
    6320:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    6324:	9e670000 	fmov	d0, x0
    6328:	910123f5 	add	x21, sp, #0x48
    632c:	52800033 	mov	w19, #0x1                   	// #1
    6330:	1e602020 	fcmp	d1, d0
    6334:	540001ad 	b.le	6368 <fwp_write+0x678>
    6338:	1e602118 	fcmpe	d8, #0.0
    633c:	90000022 	adrp	x2, a000 <__divti3+0x2e0>
    6340:	91154042 	add	x2, x2, #0x550
    6344:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    6348:	911ee021 	add	x1, x1, #0x7b8
    634c:	aa1503e0 	mov	x0, x21
    6350:	9a81c041 	csel	x1, x2, x1, gt
    6354:	97ffeccf 	bl	1690 <strcpy@plt>
    6358:	17ffffd0 	b	6298 <fwp_write+0x5a8>
    635c:	11000673 	add	w19, w19, #0x1
    6360:	71004a7f 	cmp	w19, #0x12
    6364:	54003860 	b.eq	6a70 <fwp_write+0xd80>  // b.none
    6368:	1e604100 	fmov	d0, d8
    636c:	2a1303e1 	mov	w1, w19
    6370:	aa1503e0 	mov	x0, x21
    6374:	97fff01c 	bl	23e4 <fwp_format_g.constprop.0>
    6378:	aa1503e0 	mov	x0, x21
    637c:	d2800001 	mov	x1, #0x0                   	// #0
    6380:	97ffec2c 	bl	1430 <strtod@plt>
    6384:	1e602100 	fcmp	d8, d0
    6388:	54fffea1 	b.ne	635c <fwp_write+0x66c>  // b.any
    638c:	aa1503e0 	mov	x0, x21
    6390:	97ffefb9 	bl	2274 <fwp_finish_float>
    6394:	17ffffc1 	b	6298 <fwp_write+0x5a8>
    6398:	a9400e62 	ldp	x2, x3, [x19]
    639c:	910123f3 	add	x19, sp, #0x48
    63a0:	aa1303e0 	mov	x0, x19
    63a4:	97ffedbf 	bl	1aa0 <fwp_fmt_u128>
    63a8:	17fffe74 	b	5d78 <fwp_write+0x88>
    63ac:	f90143f7 	str	x23, [sp, #640]
    63b0:	f90147f8 	str	x24, [sp, #648]
    63b4:	2a1303f8 	mov	w24, w19
    63b8:	f9014bf9 	str	x25, [sp, #656]
    63bc:	f9014ffa 	str	x26, [sp, #664]
    63c0:	f13ffe7f 	cmp	x19, #0xfff
    63c4:	54000049 	b.ls	63cc <fwp_write+0x6dc>  // b.plast
    63c8:	b9400278 	ldr	w24, [x19]
    63cc:	f9400f80 	ldr	x0, [x28, #24]
    63d0:	2a1803f5 	mov	w21, w24
    63d4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    63d8:	d37ef6b9 	lsl	x25, x21, #2
    63dc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    63e0:	aa1603e0 	mov	x0, x22
    63e4:	97ffebff 	bl	13e0 <strlen@plt>
    63e8:	aa1603e1 	mov	x1, x22
    63ec:	aa0003e2 	mov	x2, x0
    63f0:	aa1403e0 	mov	x0, x20
    63f4:	97ffef67 	bl	2190 <buf_put>
    63f8:	f9401780 	ldr	x0, [x28, #40]
    63fc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    6400:	7100001f 	cmp	w0, #0x0
    6404:	5400068d 	b.le	64d4 <fwp_write+0x7e4>
    6408:	91002276 	add	x22, x19, #0x8
    640c:	91001ff5 	add	x21, sp, #0x7
    6410:	d280001b 	mov	x27, #0x0                   	// #0
    6414:	5280041a 	mov	w26, #0x20                  	// #32
    6418:	f9401b80 	ldr	x0, [x28, #48]
    641c:	aa1503e1 	mov	x1, x21
    6420:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    6424:	d2800022 	mov	x2, #0x1                   	// #1
    6428:	f8786803 	ldr	x3, [x0, x24]
    642c:	aa1403e0 	mov	x0, x20
    6430:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    6434:	39001ffa 	strb	w26, [sp, #7]
    6438:	97ffef56 	bl	2190 <buf_put>
    643c:	f13ffeff 	cmp	x23, #0xfff
    6440:	b9400261 	ldr	w1, [x19]
    6444:	1a9f97e0 	cset	w0, hi	// hi = pmore
    6448:	7100383f 	cmp	w1, #0xe
    644c:	54000160 	b.eq	6478 <fwp_write+0x788>  // b.none
    6450:	7100403f 	cmp	w1, #0x10
    6454:	54001a60 	b.eq	67a0 <fwp_write+0xab0>  // b.none
    6458:	7100283f 	cmp	w1, #0xa
    645c:	54002aa0 	b.eq	69b0 <fwp_write+0xcc0>  // b.none
    6460:	540014ac 	b.gt	66f4 <fwp_write+0xa04>
    6464:	71000c3f 	cmp	w1, #0x3
    6468:	540029ac 	b.gt	699c <fwp_write+0xcac>
    646c:	d37ffee0 	lsr	x0, x23, #63
    6470:	37f814a1 	tbnz	w1, #31, 6704 <fwp_write+0xa14>
    6474:	d503201f 	nop
    6478:	34001460 	cbz	w0, 6704 <fwp_write+0xa14>
    647c:	52800503 	mov	w3, #0x28                  	// #40
    6480:	aa1503e1 	mov	x1, x21
    6484:	aa1403e0 	mov	x0, x20
    6488:	d2800022 	mov	x2, #0x1                   	// #1
    648c:	39001fe3 	strb	w3, [sp, #7]
    6490:	97ffef40 	bl	2190 <buf_put>
    6494:	aa1303e2 	mov	x2, x19
    6498:	aa1703e1 	mov	x1, x23
    649c:	aa1403e0 	mov	x0, x20
    64a0:	52800003 	mov	w3, #0x0                   	// #0
    64a4:	97fffe13 	bl	5cf0 <fwp_write>
    64a8:	52800523 	mov	w3, #0x29                  	// #41
    64ac:	aa1503e1 	mov	x1, x21
    64b0:	aa1403e0 	mov	x0, x20
    64b4:	d2800022 	mov	x2, #0x1                   	// #1
    64b8:	39001fe3 	strb	w3, [sp, #7]
    64bc:	97ffef35 	bl	2190 <buf_put>
    64c0:	f9401780 	ldr	x0, [x28, #40]
    64c4:	9100077b 	add	x27, x27, #0x1
    64c8:	b8796800 	ldr	w0, [x0, x25]
    64cc:	6b1b001f 	cmp	w0, w27
    64d0:	54fffa4c 	b.gt	6418 <fwp_write+0x728>
    64d4:	f9413bf5 	ldr	x21, [sp, #624]
    64d8:	f9413ff6 	ldr	x22, [sp, #632]
    64dc:	f94143f7 	ldr	x23, [sp, #640]
    64e0:	f94147f8 	ldr	x24, [sp, #648]
    64e4:	f9414bf9 	ldr	x25, [sp, #656]
    64e8:	f9414ffa 	ldr	x26, [sp, #664]
    64ec:	f94153fb 	ldr	x27, [sp, #672]
    64f0:	f94157fc 	ldr	x28, [sp, #680]
    64f4:	17fffe2b 	b	5da0 <fwp_write+0xb0>
    64f8:	52800783 	mov	w3, #0x3c                  	// #60
    64fc:	91001ff3 	add	x19, sp, #0x7
    6500:	aa1303e1 	mov	x1, x19
    6504:	d2800022 	mov	x2, #0x1                   	// #1
    6508:	aa1403e0 	mov	x0, x20
    650c:	39001fe3 	strb	w3, [sp, #7]
    6510:	97ffef20 	bl	2190 <buf_put>
    6514:	f9400795 	ldr	x21, [x28, #8]
    6518:	aa1503e0 	mov	x0, x21
    651c:	97ffebb1 	bl	13e0 <strlen@plt>
    6520:	aa1503e1 	mov	x1, x21
    6524:	aa0003e2 	mov	x2, x0
    6528:	aa1403e0 	mov	x0, x20
    652c:	97ffef19 	bl	2190 <buf_put>
    6530:	528007c3 	mov	w3, #0x3e                  	// #62
    6534:	aa1303e1 	mov	x1, x19
    6538:	aa1403e0 	mov	x0, x20
    653c:	d2800022 	mov	x2, #0x1                   	// #1
    6540:	39001fe3 	strb	w3, [sp, #7]
    6544:	17fffe12 	b	5d8c <fwp_write+0x9c>
    6548:	f100067f 	cmp	x19, #0x1
    654c:	540025a0 	b.eq	6a00 <fwp_write+0xd10>  // b.none
    6550:	b100067f 	cmn	x19, #0x1
    6554:	54002bc0 	b.eq	6acc <fwp_write+0xddc>  // b.none
    6558:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    655c:	911f0021 	add	x1, x1, #0x7c0
    6560:	d2800022 	mov	x2, #0x1                   	// #1
    6564:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    6568:	f947f400 	ldr	x0, [x0, #4072]
    656c:	f94127e4 	ldr	x4, [sp, #584]
    6570:	f9400003 	ldr	x3, [x0]
    6574:	eb030084 	subs	x4, x4, x3
    6578:	d2800003 	mov	x3, #0x0                   	// #0
    657c:	54ffebe0 	b.eq	62f8 <fwp_write+0x608>  // b.none
    6580:	f90143f7 	str	x23, [sp, #640]
    6584:	f90147f8 	str	x24, [sp, #648]
    6588:	f9014bf9 	str	x25, [sp, #656]
    658c:	f9014ffa 	str	x26, [sp, #664]
    6590:	fd015be8 	str	d8, [sp, #688]
    6594:	fd015fe9 	str	d9, [sp, #696]
    6598:	97ffebee 	bl	1550 <__stack_chk_fail@plt>
    659c:	52800b63 	mov	w3, #0x5b                  	// #91
    65a0:	91001ff5 	add	x21, sp, #0x7
    65a4:	aa1503e1 	mov	x1, x21
    65a8:	aa1403e0 	mov	x0, x20
    65ac:	d2800022 	mov	x2, #0x1                   	// #1
    65b0:	90000036 	adrp	x22, a000 <__divti3+0x2e0>
    65b4:	912182d6 	add	x22, x22, #0x860
    65b8:	39001fe3 	strb	w3, [sp, #7]
    65bc:	97ffeef5 	bl	2190 <buf_put>
    65c0:	b4000273 	cbz	x19, 660c <fwp_write+0x91c>
    65c4:	f9400661 	ldr	x1, [x19, #8]
    65c8:	aa1403e0 	mov	x0, x20
    65cc:	f9401f82 	ldr	x2, [x28, #56]
    65d0:	52800003 	mov	w3, #0x0                   	// #0
    65d4:	97fffdc7 	bl	5cf0 <fwp_write>
    65d8:	f9400a73 	ldr	x19, [x19, #16]
    65dc:	b4000193 	cbz	x19, 660c <fwp_write+0x91c>
    65e0:	aa1603e1 	mov	x1, x22
    65e4:	aa1403e0 	mov	x0, x20
    65e8:	d2800042 	mov	x2, #0x2                   	// #2
    65ec:	97ffeee9 	bl	2190 <buf_put>
    65f0:	f9400661 	ldr	x1, [x19, #8]
    65f4:	aa1403e0 	mov	x0, x20
    65f8:	f9401f82 	ldr	x2, [x28, #56]
    65fc:	52800003 	mov	w3, #0x0                   	// #0
    6600:	97fffdbc 	bl	5cf0 <fwp_write>
    6604:	f9400a73 	ldr	x19, [x19, #16]
    6608:	b5fffed3 	cbnz	x19, 65e0 <fwp_write+0x8f0>
    660c:	52800ba3 	mov	w3, #0x5d                  	// #93
    6610:	aa1503e1 	mov	x1, x21
    6614:	aa1403e0 	mov	x0, x20
    6618:	d2800022 	mov	x2, #0x1                   	// #1
    661c:	39001fe3 	strb	w3, [sp, #7]
    6620:	17fffddb 	b	5d8c <fwp_write+0x9c>
    6624:	aa1403e0 	mov	x0, x20
    6628:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    662c:	d28000c2 	mov	x2, #0x6                   	// #6
    6630:	91214021 	add	x1, x1, #0x850
    6634:	97ffeed7 	bl	2190 <buf_put>
    6638:	f9400260 	ldr	x0, [x19]
    663c:	b40004c0 	cbz	x0, 66d4 <fwp_write+0x9e4>
    6640:	910123f5 	add	x21, sp, #0x48
    6644:	91002276 	add	x22, x19, #0x8
    6648:	f90143f7 	str	x23, [sp, #640]
    664c:	d2800017 	mov	x23, #0x0                   	// #0
    6650:	f90147f8 	str	x24, [sp, #648]
    6654:	90000038 	adrp	x24, a000 <__divti3+0x2e0>
    6658:	91216318 	add	x24, x24, #0x858
    665c:	f9014bf9 	str	x25, [sp, #656]
    6660:	90000039 	adrp	x25, a000 <__divti3+0x2e0>
    6664:	91218339 	add	x25, x25, #0x860
    6668:	f9014ffa 	str	x26, [sp, #664]
    666c:	14000005 	b	6680 <fwp_write+0x990>
    6670:	aa1903e1 	mov	x1, x25
    6674:	aa1403e0 	mov	x0, x20
    6678:	d2800042 	mov	x2, #0x2                   	// #2
    667c:	97ffeec5 	bl	2190 <buf_put>
    6680:	38776ac5 	ldrb	w5, [x22, x23]
    6684:	d2804003 	mov	x3, #0x200                 	// #512
    6688:	aa1803e4 	mov	x4, x24
    668c:	aa0303e1 	mov	x1, x3
    6690:	52800042 	mov	w2, #0x2                   	// #2
    6694:	aa1503e0 	mov	x0, x21
    6698:	910006f7 	add	x23, x23, #0x1
    669c:	97ffeb89 	bl	14c0 <__snprintf_chk@plt>
    66a0:	aa1503e0 	mov	x0, x21
    66a4:	97ffeb4f 	bl	13e0 <strlen@plt>
    66a8:	aa1503e1 	mov	x1, x21
    66ac:	aa0003e2 	mov	x2, x0
    66b0:	aa1403e0 	mov	x0, x20
    66b4:	97ffeeb7 	bl	2190 <buf_put>
    66b8:	f9400260 	ldr	x0, [x19]
    66bc:	eb17001f 	cmp	x0, x23
    66c0:	54fffd88 	b.hi	6670 <fwp_write+0x980>  // b.pmore
    66c4:	f94143f7 	ldr	x23, [sp, #640]
    66c8:	f94147f8 	ldr	x24, [sp, #648]
    66cc:	f9414bf9 	ldr	x25, [sp, #656]
    66d0:	f9414ffa 	ldr	x26, [sp, #664]
    66d4:	52800ba3 	mov	w3, #0x5d                  	// #93
    66d8:	aa1403e0 	mov	x0, x20
    66dc:	91001fe1 	add	x1, sp, #0x7
    66e0:	d2800022 	mov	x2, #0x1                   	// #1
    66e4:	39001fe3 	strb	w3, [sp, #7]
    66e8:	17fffda9 	b	5d8c <fwp_write+0x9c>
    66ec:	52800fa3 	mov	w3, #0x7d                  	// #125
    66f0:	17fffe44 	b	6000 <fwp_write+0x310>
    66f4:	f10002ff 	cmp	x23, #0x0
    66f8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    66fc:	71002c3f 	cmp	w1, #0xb
    6700:	54ffebc0 	b.eq	6478 <fwp_write+0x788>  // b.none
    6704:	aa1303e2 	mov	x2, x19
    6708:	aa1703e1 	mov	x1, x23
    670c:	aa1403e0 	mov	x0, x20
    6710:	52800003 	mov	w3, #0x0                   	// #0
    6714:	97fffd77 	bl	5cf0 <fwp_write>
    6718:	17ffff6a 	b	64c0 <fwp_write+0x7d0>
    671c:	aa1403e0 	mov	x0, x20
    6720:	91001fe1 	add	x1, sp, #0x7
    6724:	52800fa3 	mov	w3, #0x7d                  	// #125
    6728:	d2800022 	mov	x2, #0x1                   	// #1
    672c:	17fffe38 	b	600c <fwp_write+0x31c>
    6730:	a9400281 	ldp	x1, x0, [x20]
    6734:	91000800 	add	x0, x0, #0x2
    6738:	8b160000 	add	x0, x0, x22
    673c:	f9000680 	str	x0, [x20, #8]
    6740:	3820683f 	strb	wzr, [x1, x0]
    6744:	f9413bf5 	ldr	x21, [sp, #624]
    6748:	f9413ff6 	ldr	x22, [sp, #632]
    674c:	f94153fb 	ldr	x27, [sp, #672]
    6750:	f94157fc 	ldr	x28, [sp, #680]
    6754:	17fffd93 	b	5da0 <fwp_write+0xb0>
    6758:	f9400f80 	ldr	x0, [x28, #24]
    675c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    6760:	aa1b03e0 	mov	x0, x27
    6764:	97ffeb1f 	bl	13e0 <strlen@plt>
    6768:	aa1b03e1 	mov	x1, x27
    676c:	aa0003e2 	mov	x2, x0
    6770:	aa1403e0 	mov	x0, x20
    6774:	97ffee87 	bl	2190 <buf_put>
    6778:	aa1903e1 	mov	x1, x25
    677c:	aa1403e0 	mov	x0, x20
    6780:	d2800062 	mov	x2, #0x3                   	// #3
    6784:	97ffee83 	bl	2190 <buf_put>
    6788:	17fffe10 	b	5fc8 <fwp_write+0x2d8>
    678c:	aa1a03e1 	mov	x1, x26
    6790:	aa1403e0 	mov	x0, x20
    6794:	d2800042 	mov	x2, #0x2                   	// #2
    6798:	97ffee7e 	bl	2190 <buf_put>
    679c:	17fffe09 	b	5fc0 <fwp_write+0x2d0>
    67a0:	f9400660 	ldr	x0, [x19, #8]
    67a4:	b4fffb00 	cbz	x0, 6704 <fwp_write+0xa14>
    67a8:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    67ac:	9121e021 	add	x1, x1, #0x878
    67b0:	97ffeb88 	bl	15d0 <strcmp@plt>
    67b4:	7100001f 	cmp	w0, #0x0
    67b8:	1a9f07e0 	cset	w0, ne	// ne = any
    67bc:	17ffff2f 	b	6478 <fwp_write+0x788>
    67c0:	aa1403e0 	mov	x0, x20
    67c4:	d2800042 	mov	x2, #0x2                   	// #2
    67c8:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    67cc:	9121c021 	add	x1, x1, #0x870
    67d0:	97ffee70 	bl	2190 <buf_put>
    67d4:	91004261 	add	x1, x19, #0x10
    67d8:	aa1403e0 	mov	x0, x20
    67dc:	f9402382 	ldr	x2, [x28, #64]
    67e0:	52800003 	mov	w3, #0x0                   	// #0
    67e4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    67e8:	97fffd42 	bl	5cf0 <fwp_write>
    67ec:	17fffd9c 	b	5e5c <fwp_write+0x16c>
    67f0:	1e22c109 	fcvt	d9, s8
    67f4:	910123f5 	add	x21, sp, #0x48
    67f8:	52800033 	mov	w19, #0x1                   	// #1
    67fc:	d503201f 	nop
    6800:	1e604120 	fmov	d0, d9
    6804:	2a1303e1 	mov	w1, w19
    6808:	aa1503e0 	mov	x0, x21
    680c:	97ffeef6 	bl	23e4 <fwp_format_g.constprop.0>
    6810:	aa1503e0 	mov	x0, x21
    6814:	d2800001 	mov	x1, #0x0                   	// #0
    6818:	97ffeb7a 	bl	1600 <strtof@plt>
    681c:	1e202100 	fcmp	s8, s0
    6820:	54ffdb60 	b.eq	638c <fwp_write+0x69c>  // b.none
    6824:	11000673 	add	w19, w19, #0x1
    6828:	71002a7f 	cmp	w19, #0xa
    682c:	54fffea1 	b.ne	6800 <fwp_write+0xb10>  // b.any
    6830:	1e604120 	fmov	d0, d9
    6834:	aa1503e0 	mov	x0, x21
    6838:	52800121 	mov	w1, #0x9                   	// #9
    683c:	97ffeeea 	bl	23e4 <fwp_format_g.constprop.0>
    6840:	17fffed3 	b	638c <fwp_write+0x69c>
    6844:	d37ef6a1 	lsl	x1, x21, #2
    6848:	b7f81563 	tbnz	x3, #63, 6af4 <fwp_write+0xe04>
    684c:	91002263 	add	x3, x19, #0x8
    6850:	8b010061 	add	x1, x3, x1
    6854:	b9400023 	ldr	w3, [x1]
    6858:	7100081f 	cmp	w0, #0x2
    685c:	2a0303e1 	mov	w1, w3
    6860:	93407c63 	sxtw	x3, w3
    6864:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    6868:	17fffe5a 	b	61d0 <fwp_write+0x4e0>
    686c:	d37ffaa1 	lsl	x1, x21, #1
    6870:	b7f81363 	tbnz	x3, #63, 6adc <fwp_write+0xdec>
    6874:	91002263 	add	x3, x19, #0x8
    6878:	8b010061 	add	x1, x3, x1
    687c:	79400021 	ldrh	w1, [x1]
    6880:	7100041f 	cmp	w0, #0x1
    6884:	93403c23 	sxth	x3, w1
    6888:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    688c:	17fffe51 	b	61d0 <fwp_write+0x4e0>
    6890:	52800443 	mov	w3, #0x22                  	// #34
    6894:	91001ff5 	add	x21, sp, #0x7
    6898:	91002273 	add	x19, x19, #0x8
    689c:	aa1503e1 	mov	x1, x21
    68a0:	aa1403e0 	mov	x0, x20
    68a4:	d2800022 	mov	x2, #0x1                   	// #1
    68a8:	39001fe3 	strb	w3, [sp, #7]
    68ac:	f90143f7 	str	x23, [sp, #640]
    68b0:	8b160277 	add	x23, x19, x22
    68b4:	f90147f8 	str	x24, [sp, #648]
    68b8:	97ffee36 	bl	2190 <buf_put>
    68bc:	b4000696 	cbz	x22, 698c <fwp_write+0xc9c>
    68c0:	90000038 	adrp	x24, a000 <__divti3+0x2e0>
    68c4:	91208318 	add	x24, x24, #0x820
    68c8:	f9014bf9 	str	x25, [sp, #656]
    68cc:	90000039 	adrp	x25, a000 <__divti3+0x2e0>
    68d0:	91210339 	add	x25, x25, #0x840
    68d4:	f9014ffa 	str	x26, [sp, #664]
    68d8:	1400000d 	b	690c <fwp_write+0xc1c>
    68dc:	710024bf 	cmp	w5, #0x9
    68e0:	54000460 	b.eq	696c <fwp_write+0xc7c>  // b.none
    68e4:	710028bf 	cmp	w5, #0xa
    68e8:	54000a61 	b.ne	6a34 <fwp_write+0xd44>  // b.any
    68ec:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    68f0:	aa1403e0 	mov	x0, x20
    68f4:	9120c021 	add	x1, x1, #0x830
    68f8:	d2800042 	mov	x2, #0x2                   	// #2
    68fc:	97ffee25 	bl	2190 <buf_put>
    6900:	91000673 	add	x19, x19, #0x1
    6904:	eb17027f 	cmp	x19, x23
    6908:	540003e0 	b.eq	6984 <fwp_write+0xc94>  // b.none
    690c:	39400265 	ldrb	w5, [x19]
    6910:	710034bf 	cmp	w5, #0xd
    6914:	54000180 	b.eq	6944 <fwp_write+0xc54>  // b.none
    6918:	54fffe29 	b.ls	68dc <fwp_write+0xbec>  // b.plast
    691c:	710088bf 	cmp	w5, #0x22
    6920:	540001c0 	b.eq	6958 <fwp_write+0xc68>  // b.none
    6924:	710170bf 	cmp	w5, #0x5c
    6928:	54000741 	b.ne	6a10 <fwp_write+0xd20>  // b.any
    692c:	aa1403e0 	mov	x0, x20
    6930:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    6934:	d2800042 	mov	x2, #0x2                   	// #2
    6938:	9120a021 	add	x1, x1, #0x828
    693c:	97ffee15 	bl	2190 <buf_put>
    6940:	17fffff0 	b	6900 <fwp_write+0xc10>
    6944:	aa1903e1 	mov	x1, x25
    6948:	aa1403e0 	mov	x0, x20
    694c:	d2800042 	mov	x2, #0x2                   	// #2
    6950:	97ffee10 	bl	2190 <buf_put>
    6954:	17ffffeb 	b	6900 <fwp_write+0xc10>
    6958:	aa1803e1 	mov	x1, x24
    695c:	aa1403e0 	mov	x0, x20
    6960:	d2800042 	mov	x2, #0x2                   	// #2
    6964:	97ffee0b 	bl	2190 <buf_put>
    6968:	17ffffe6 	b	6900 <fwp_write+0xc10>
    696c:	aa1403e0 	mov	x0, x20
    6970:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    6974:	d2800042 	mov	x2, #0x2                   	// #2
    6978:	9120e021 	add	x1, x1, #0x838
    697c:	97ffee05 	bl	2190 <buf_put>
    6980:	17ffffe0 	b	6900 <fwp_write+0xc10>
    6984:	f9414bf9 	ldr	x25, [sp, #656]
    6988:	f9414ffa 	ldr	x26, [sp, #664]
    698c:	aa1503e1 	mov	x1, x21
    6990:	aa1403e0 	mov	x0, x20
    6994:	52800443 	mov	w3, #0x22                  	// #34
    6998:	17fffd9c 	b	6008 <fwp_write+0x318>
    699c:	7100103f 	cmp	w1, #0x4
    69a0:	54ffeb21 	b.ne	6704 <fwp_write+0xa14>  // b.any
    69a4:	f94006e0 	ldr	x0, [x23, #8]
    69a8:	d37ffc00 	lsr	x0, x0, #63
    69ac:	17fffeb3 	b	6478 <fwp_write+0x788>
    69b0:	710002ff 	cmp	w23, #0x0
    69b4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    69b8:	17fffeb0 	b	6478 <fwp_write+0x788>
    69bc:	528005a1 	mov	w1, #0x2d                  	// #45
    69c0:	eb0203e2 	negs	x2, x2
    69c4:	da0303e3 	ngc	x3, x3
    69c8:	910127e0 	add	x0, sp, #0x49
    69cc:	910123f5 	add	x21, sp, #0x48
    69d0:	390123e1 	strb	w1, [sp, #72]
    69d4:	97ffec33 	bl	1aa0 <fwp_fmt_u128>
    69d8:	17fffe18 	b	6238 <fwp_write+0x548>
    69dc:	d37ceea1 	lsl	x1, x21, #4
    69e0:	b7f810a3 	tbnz	x3, #63, 6bf4 <fwp_write+0xf04>
    69e4:	91002260 	add	x0, x19, #0x8
    69e8:	8b010001 	add	x1, x0, x1
    69ec:	17fffdf9 	b	61d0 <fwp_write+0x4e0>
    69f0:	f9400a61 	ldr	x1, [x19, #16]
    69f4:	8b010000 	add	x0, x0, x1
    69f8:	f9400001 	ldr	x1, [x0]
    69fc:	17fffdf5 	b	61d0 <fwp_write+0x4e0>
    6a00:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    6a04:	d2800042 	mov	x2, #0x2                   	// #2
    6a08:	911f2021 	add	x1, x1, #0x7c8
    6a0c:	17fffed6 	b	6564 <fwp_write+0x874>
    6a10:	7101fcbf 	cmp	w5, #0x7f
    6a14:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    6a18:	540000e9 	b.ls	6a34 <fwp_write+0xd44>  // b.plast
    6a1c:	aa1503e1 	mov	x1, x21
    6a20:	aa1403e0 	mov	x0, x20
    6a24:	d2800022 	mov	x2, #0x1                   	// #1
    6a28:	39001fe5 	strb	w5, [sp, #7]
    6a2c:	97ffedd9 	bl	2190 <buf_put>
    6a30:	17ffffb4 	b	6900 <fwp_write+0xc10>
    6a34:	d2800203 	mov	x3, #0x10                  	// #16
    6a38:	90000024 	adrp	x4, a000 <__divti3+0x2e0>
    6a3c:	aa0303e1 	mov	x1, x3
    6a40:	91212084 	add	x4, x4, #0x848
    6a44:	910123f6 	add	x22, sp, #0x48
    6a48:	52800042 	mov	w2, #0x2                   	// #2
    6a4c:	aa1603e0 	mov	x0, x22
    6a50:	97ffea9c 	bl	14c0 <__snprintf_chk@plt>
    6a54:	aa1603e0 	mov	x0, x22
    6a58:	97ffea62 	bl	13e0 <strlen@plt>
    6a5c:	aa1603e1 	mov	x1, x22
    6a60:	aa0003e2 	mov	x2, x0
    6a64:	aa1403e0 	mov	x0, x20
    6a68:	97ffedca 	bl	2190 <buf_put>
    6a6c:	17ffffa5 	b	6900 <fwp_write+0xc10>
    6a70:	1e604100 	fmov	d0, d8
    6a74:	aa1503e0 	mov	x0, x21
    6a78:	52800221 	mov	w1, #0x11                  	// #17
    6a7c:	97ffee5a 	bl	23e4 <fwp_format_g.constprop.0>
    6a80:	17fffe43 	b	638c <fwp_write+0x69c>
    6a84:	b9401040 	ldr	w0, [x2, #16]
    6a88:	350003c0 	cbnz	w0, 6b00 <fwp_write+0xe10>
    6a8c:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    6a90:	f947f400 	ldr	x0, [x0, #4072]
    6a94:	f94127e2 	ldr	x2, [sp, #584]
    6a98:	f9400001 	ldr	x1, [x0]
    6a9c:	eb010042 	subs	x2, x2, x1
    6aa0:	d2800001 	mov	x1, #0x0                   	// #0
    6aa4:	54ffd721 	b.ne	6588 <fwp_write+0x898>  // b.any
    6aa8:	f9413bf5 	ldr	x21, [sp, #624]
    6aac:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    6ab0:	f9413ff6 	ldr	x22, [sp, #632]
    6ab4:	aa1403e0 	mov	x0, x20
    6ab8:	f94143f7 	ldr	x23, [sp, #640]
    6abc:	91226021 	add	x1, x1, #0x898
    6ac0:	f94147f8 	ldr	x24, [sp, #648]
    6ac4:	d2800042 	mov	x2, #0x2                   	// #2
    6ac8:	17fffd0e 	b	5f00 <fwp_write+0x210>
    6acc:	90000021 	adrp	x1, a000 <__divti3+0x2e0>
    6ad0:	d2800042 	mov	x2, #0x2                   	// #2
    6ad4:	911f4021 	add	x1, x1, #0x7d0
    6ad8:	17fffea3 	b	6564 <fwp_write+0x874>
    6adc:	f9400a63 	ldr	x3, [x19, #16]
    6ae0:	8b030021 	add	x1, x1, x3
    6ae4:	17ffff66 	b	687c <fwp_write+0xb8c>
    6ae8:	f9400a61 	ldr	x1, [x19, #16]
    6aec:	8b0102a1 	add	x1, x21, x1
    6af0:	17fffdb3 	b	61bc <fwp_write+0x4cc>
    6af4:	f9400a63 	ldr	x3, [x19, #16]
    6af8:	8b030021 	add	x1, x1, x3
    6afc:	17ffff56 	b	6854 <fwp_write+0xb64>
    6b00:	b9404840 	ldr	w0, [x2, #72]
    6b04:	91001ff5 	add	x21, sp, #0x7
    6b08:	34ffa360 	cbz	w0, 5f74 <fwp_write+0x284>
    6b0c:	52800503 	mov	w3, #0x28                  	// #40
    6b10:	aa1403e0 	mov	x0, x20
    6b14:	aa1503e1 	mov	x1, x21
    6b18:	d2800022 	mov	x2, #0x1                   	// #1
    6b1c:	39001fe3 	strb	w3, [sp, #7]
    6b20:	97ffed9c 	bl	2190 <buf_put>
    6b24:	b9401380 	ldr	w0, [x28, #16]
    6b28:	52800038 	mov	w24, #0x1                   	// #1
    6b2c:	7100001f 	cmp	w0, #0x0
    6b30:	54ffa36c 	b.gt	5f9c <fwp_write+0x2ac>
    6b34:	17fffd32 	b	5ffc <fwp_write+0x30c>
    6b38:	f9014bf9 	str	x25, [sp, #656]
    6b3c:	b00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x132b8>
    6b40:	f9014ffa 	str	x26, [sp, #664]
    6b44:	f9400676 	ldr	x22, [x19, #8]
    6b48:	912ae333 	add	x19, x25, #0xab8
    6b4c:	91002273 	add	x19, x19, #0x8
    6b50:	937ffed8 	asr	x24, x22, #63
    6b54:	aa1802c0 	orr	x0, x22, x24
    6b58:	b5000320 	cbnz	x0, 6bbc <fwp_write+0xecc>
    6b5c:	110006b5 	add	w21, w21, #0x1
    6b60:	710016bf 	cmp	w21, #0x5
    6b64:	54ffffc1 	b.ne	6b5c <fwp_write+0xe6c>  // b.any
    6b68:	b7f80578 	tbnz	x24, #63, 6c14 <fwp_write+0xf24>
    6b6c:	910023f3 	add	x19, sp, #0x8
    6b70:	aa1603e2 	mov	x2, x22
    6b74:	aa1303e0 	mov	x0, x19
    6b78:	d2800003 	mov	x3, #0x0                   	// #0
    6b7c:	97ffebc9 	bl	1aa0 <fwp_fmt_u128>
    6b80:	910123f5 	add	x21, sp, #0x48
    6b84:	90000023 	adrp	x3, a000 <__divti3+0x2e0>
    6b88:	aa1303e4 	mov	x4, x19
    6b8c:	aa1503e0 	mov	x0, x21
    6b90:	91224063 	add	x3, x3, #0x890
    6b94:	d2804002 	mov	x2, #0x200                 	// #512
    6b98:	52800041 	mov	w1, #0x2                   	// #2
    6b9c:	97ffea15 	bl	13f0 <__sprintf_chk@plt>
    6ba0:	aa1503e0 	mov	x0, x21
    6ba4:	97ffea0f 	bl	13e0 <strlen@plt>
    6ba8:	aa1503e1 	mov	x1, x21
    6bac:	aa0003e2 	mov	x2, x0
    6bb0:	aa1403e0 	mov	x0, x20
    6bb4:	97ffed77 	bl	2190 <buf_put>
    6bb8:	17fffe47 	b	64d4 <fwp_write+0x7e4>
    6bbc:	f9400277 	ldr	x23, [x19]
    6bc0:	aa1603e0 	mov	x0, x22
    6bc4:	aa1803e1 	mov	x1, x24
    6bc8:	aa1703e2 	mov	x2, x23
    6bcc:	937ffefa 	asr	x26, x23, #63
    6bd0:	aa1a03e3 	mov	x3, x26
    6bd4:	94000d33 	bl	a0a0 <__modti3>
    6bd8:	aa010000 	orr	x0, x0, x1
    6bdc:	b40002c0 	cbz	x0, 6c34 <fwp_write+0xf44>
    6be0:	110006b5 	add	w21, w21, #0x1
    6be4:	91004273 	add	x19, x19, #0x10
    6be8:	710016bf 	cmp	w21, #0x5
    6bec:	54fffe81 	b.ne	6bbc <fwp_write+0xecc>  // b.any
    6bf0:	17ffffde 	b	6b68 <fwp_write+0xe78>
    6bf4:	f9400a60 	ldr	x0, [x19, #16]
    6bf8:	8b000021 	add	x1, x1, x0
    6bfc:	17fffd75 	b	61d0 <fwp_write+0x4e0>
    6c00:	528c29c0 	mov	w0, #0x614e                	// #24910
    6c04:	910123f5 	add	x21, sp, #0x48
    6c08:	72a009c0 	movk	w0, #0x4e, lsl #16
    6c0c:	b9004be0 	str	w0, [sp, #72]
    6c10:	17fffda2 	b	6298 <fwp_write+0x5a8>
    6c14:	528005a1 	mov	w1, #0x2d                  	// #45
    6c18:	eb1603e2 	negs	x2, x22
    6c1c:	da1803e3 	ngc	x3, x24
    6c20:	910027e0 	add	x0, sp, #0x9
    6c24:	910023f3 	add	x19, sp, #0x8
    6c28:	390023e1 	strb	w1, [sp, #8]
    6c2c:	97ffeb9d 	bl	1aa0 <fwp_fmt_u128>
    6c30:	17ffffd4 	b	6b80 <fwp_write+0xe90>
    6c34:	aa1703e2 	mov	x2, x23
    6c38:	aa1a03e3 	mov	x3, x26
    6c3c:	aa1603e0 	mov	x0, x22
    6c40:	aa1803e1 	mov	x1, x24
    6c44:	94000c37 	bl	9d20 <__divti3>
    6c48:	aa0003e2 	mov	x2, x0
    6c4c:	aa0103e3 	mov	x3, x1
    6c50:	b7f80201 	tbnz	x1, #63, 6c90 <fwp_write+0xfa0>
    6c54:	910023f3 	add	x19, sp, #0x8
    6c58:	aa1303e0 	mov	x0, x19
    6c5c:	97ffeb91 	bl	1aa0 <fwp_fmt_u128>
    6c60:	937c7ea1 	sbfiz	x1, x21, #4, #32
    6c64:	912ae339 	add	x25, x25, #0xab8
    6c68:	910123f5 	add	x21, sp, #0x48
    6c6c:	aa1303e4 	mov	x4, x19
    6c70:	aa1503e0 	mov	x0, x21
    6c74:	90000023 	adrp	x3, a000 <__divti3+0x2e0>
    6c78:	f8616b25 	ldr	x5, [x25, x1]
    6c7c:	91222063 	add	x3, x3, #0x888
    6c80:	d2804002 	mov	x2, #0x200                 	// #512
    6c84:	52800041 	mov	w1, #0x2                   	// #2
    6c88:	97ffe9da 	bl	13f0 <__sprintf_chk@plt>
    6c8c:	17ffffc5 	b	6ba0 <fwp_write+0xeb0>
    6c90:	528005a4 	mov	w4, #0x2d                  	// #45
    6c94:	eb0003e2 	negs	x2, x0
    6c98:	da0103e3 	ngc	x3, x1
    6c9c:	910027e0 	add	x0, sp, #0x9
    6ca0:	910023f3 	add	x19, sp, #0x8
    6ca4:	390023e4 	strb	w4, [sp, #8]
    6ca8:	97ffeb7e 	bl	1aa0 <fwp_fmt_u128>
    6cac:	17ffffed 	b	6c60 <fwp_write+0xf70>
    6cb0:	f9013bf5 	str	x21, [sp, #624]
    6cb4:	f9013ff6 	str	x22, [sp, #632]
    6cb8:	f90143f7 	str	x23, [sp, #640]
    6cbc:	f90147f8 	str	x24, [sp, #648]
    6cc0:	f9014bf9 	str	x25, [sp, #656]
    6cc4:	f9014ffa 	str	x26, [sp, #664]
    6cc8:	f90153fb 	str	x27, [sp, #672]
    6ccc:	f90157fc 	str	x28, [sp, #680]
    6cd0:	fd015be8 	str	d8, [sp, #688]
    6cd4:	fd015fe9 	str	d9, [sp, #696]
    6cd8:	97ffea1e 	bl	1550 <__stack_chk_fail@plt>
    6cdc:	d503201f 	nop

0000000000006ce0 <fwp_hof0.constprop.0>:
    6ce0:	d10283ff 	sub	sp, sp, #0xa0
    6ce4:	b00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x132b8>
    6ce8:	f947f442 	ldr	x2, [x2, #4072]
    6cec:	a9047bfd 	stp	x29, x30, [sp, #64]
    6cf0:	910103fd 	add	x29, sp, #0x40
    6cf4:	a90763f7 	stp	x23, x24, [sp, #112]
    6cf8:	aa0003f8 	mov	x24, x0
    6cfc:	f9400040 	ldr	x0, [x2]
    6d00:	f9001fe0 	str	x0, [sp, #56]
    6d04:	d2800000 	mov	x0, #0x0                   	// #0
    6d08:	b4001621 	cbz	x1, 6fcc <fwp_hof0.constprop.0+0x2ec>
    6d0c:	a9086bf9 	stp	x25, x26, [sp, #128]
    6d10:	b00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x132b8>
    6d14:	912ae339 	add	x25, x25, #0xab8
    6d18:	91014320 	add	x0, x25, #0x50
    6d1c:	9000003a 	adrp	x26, a000 <__divti3+0x2e0>
    6d20:	aa0103f7 	mov	x23, x1
    6d24:	9112035a 	add	x26, x26, #0x480
    6d28:	f90003e0 	str	x0, [sp]
    6d2c:	f0000140 	adrp	x0, 31000 <fwp_root_context+0xcb0>
    6d30:	a9065bf5 	stp	x21, x22, [sp, #96]
    6d34:	d00000d5 	adrp	x21, 20000 <__data_start>
    6d38:	910142b5 	add	x21, x21, #0x50
    6d3c:	a90553f3 	stp	x19, x20, [sp, #80]
    6d40:	9114c013 	add	x19, x0, #0x530
    6d44:	910083e0 	add	x0, sp, #0x20
    6d48:	f90007e0 	str	x0, [sp, #8]
    6d4c:	a90973fb 	stp	x27, x28, [sp, #144]
    6d50:	f949da61 	ldr	x1, [x19, #5040]
    6d54:	f949ee60 	ldr	x0, [x19, #5080]
    6d58:	cb010301 	sub	x1, x24, x1
    6d5c:	eb00403f 	cmp	x1, x0, lsl #16
    6d60:	540003e2 	b.cs	6ddc <fwp_hof0.constprop.0+0xfc>  // b.hs, b.nlast
    6d64:	d350fc20 	lsr	x0, x1, #16
    6d68:	f949fe64 	ldr	x4, [x19, #5112]
    6d6c:	8b000800 	add	x0, x0, x0, lsl #2
    6d70:	d37df002 	lsl	x2, x0, #3
    6d74:	8b020083 	add	x3, x4, x2
    6d78:	f9401060 	ldr	x0, [x3, #32]
    6d7c:	b4000300 	cbz	x0, 6ddc <fwp_hof0.constprop.0+0xfc>
    6d80:	38626882 	ldrb	w2, [x4, x2]
    6d84:	7100085f 	cmp	w2, #0x2
    6d88:	54001840 	b.eq	7090 <fwp_hof0.constprop.0+0x3b0>  // b.none
    6d8c:	7100045f 	cmp	w2, #0x1
    6d90:	54000261 	b.ne	6ddc <fwp_hof0.constprop.0+0xfc>  // b.any
    6d94:	29430864 	ldp	w4, w2, [x3, #24]
    6d98:	92403c21 	and	x1, x1, #0xffff
    6d9c:	9b047c21 	mul	x1, x1, x4
    6da0:	d360fc21 	lsr	x1, x1, #32
    6da4:	eb02003f 	cmp	x1, x2
    6da8:	540001a2 	b.cs	6ddc <fwp_hof0.constprop.0+0xfc>  // b.hs, b.nlast
    6dac:	8b010000 	add	x0, x0, x1
    6db0:	39400001 	ldrb	w1, [x0]
    6db4:	34000141 	cbz	w1, 6ddc <fwp_hof0.constprop.0+0xfc>
    6db8:	b94042a2 	ldr	w2, [x21, #64]
    6dbc:	34000082 	cbz	w2, 6dcc <fwp_hof0.constprop.0+0xec>
    6dc0:	f94026a2 	ldr	x2, [x21, #72]
    6dc4:	91000442 	add	x2, x2, #0x1
    6dc8:	f90026a2 	str	x2, [x21, #72]
    6dcc:	7103f43f 	cmp	w1, #0xfd
    6dd0:	540017c8 	b.hi	70c8 <fwp_hof0.constprop.0+0x3e8>  // b.pmore
    6dd4:	11000421 	add	w1, w1, #0x1
    6dd8:	39000001 	strb	w1, [x0]
    6ddc:	aa1803e0 	mov	x0, x24
    6de0:	97fff8e8 	bl	5180 <fwp_loop_fields68.constprop.0>
    6de4:	aa0003e1 	mov	x1, x0
    6de8:	aa0003f6 	mov	x22, x0
    6dec:	a94003e2 	ldp	x2, x0, [sp]
    6df0:	52800023 	mov	w3, #0x1                   	// #1
    6df4:	a9027fff 	stp	xzr, xzr, [sp, #32]
    6df8:	f9001bff 	str	xzr, [sp, #48]
    6dfc:	97fffbbd 	bl	5cf0 <fwp_write>
    6e00:	a9426ff9 	ldp	x25, x27, [sp, #32]
    6e04:	f100033f 	cmp	x25, #0x0
    6e08:	9a990359 	csel	x25, x26, x25, eq	// eq = none
    6e0c:	b1002b7f 	cmn	x27, #0xa
    6e10:	54001608 	b.hi	70d0 <fwp_hof0.constprop.0+0x3f0>  // b.pmore
    6e14:	b94042bc 	ldr	w28, [x21, #64]
    6e18:	91002762 	add	x2, x27, #0x9
    6e1c:	340000fc 	cbz	w28, 6e38 <fwp_hof0.constprop.0+0x158>
    6e20:	f94156a1 	ldr	x1, [x21, #680]
    6e24:	f9415aa0 	ldr	x0, [x21, #688]
    6e28:	91000421 	add	x1, x1, #0x1
    6e2c:	f90156a1 	str	x1, [x21, #680]
    6e30:	8b020000 	add	x0, x0, x2
    6e34:	f9015aa0 	str	x0, [x21, #688]
    6e38:	b953a660 	ldr	w0, [x19, #5028]
    6e3c:	f140105f 	cmp	x2, #0x4, lsl #12
    6e40:	7a409804 	ccmp	w0, #0x0, #0x4, ls	// ls = plast
    6e44:	54000e80 	b.eq	7014 <fwp_hof0.constprop.0+0x334>  // b.none
    6e48:	91006360 	add	x0, x27, #0x18
    6e4c:	8b401260 	add	x0, x19, x0, lsr #4
    6e50:	397e8001 	ldrb	w1, [x0, #4000]
    6e54:	910f0020 	add	x0, x1, #0x3c0
    6e58:	8b010421 	add	x1, x1, x1, lsl #1
    6e5c:	8b010e64 	add	x4, x19, x1, lsl #3
    6e60:	b8607a68 	ldr	w8, [x19, x0, lsl #2]
    6e64:	2a0803e7 	mov	w7, w8
    6e68:	f941e094 	ldr	x20, [x4, #960]
    6e6c:	b4000c94 	cbz	x20, 6ffc <fwp_hof0.constprop.0+0x31c>
    6e70:	f9400289 	ldr	x9, [x20]
    6e74:	aa1403e0 	mov	x0, x20
    6e78:	52800001 	mov	w1, #0x0                   	// #0
    6e7c:	b90013e8 	str	w8, [sp, #16]
    6e80:	aa2903e9 	mvn	x9, x9
    6e84:	f9000fe7 	str	x7, [sp, #24]
    6e88:	f901e089 	str	x9, [x4, #960]
    6e8c:	97ffe9a5 	bl	1520 <memset@plt>
    6e90:	f9400fe7 	ldr	x7, [sp, #24]
    6e94:	f94a1260 	ldr	x0, [x19, #5152]
    6e98:	ab070000 	adds	x0, x0, x7
    6e9c:	54001202 	b.cs	70dc <fwp_hof0.constprop.0+0x3fc>  // b.hs, b.nlast
    6ea0:	f94a1661 	ldr	x1, [x19, #5160]
    6ea4:	f90a1260 	str	x0, [x19, #5152]
    6ea8:	b94013e8 	ldr	w8, [sp, #16]
    6eac:	eb01001f 	cmp	x0, x1
    6eb0:	54000049 	b.ls	6eb8 <fwp_hof0.constprop.0+0x1d8>  // b.plast
    6eb4:	f90a1660 	str	x0, [x19, #5160]
    6eb8:	1e630101 	ucvtf	d1, w8
    6ebc:	fd4a1e60 	ldr	d0, [x19, #5176]
    6ec0:	1e612800 	fadd	d0, d0, d1
    6ec4:	fd0a1e60 	str	d0, [x19, #5176]
    6ec8:	3400011c 	cbz	w28, 6ee8 <fwp_hof0.constprop.0+0x208>
    6ecc:	fd4a1260 	ldr	d0, [x19, #5152]
    6ed0:	fd415ea2 	ldr	d2, [x21, #696]
    6ed4:	fd4162a1 	ldr	d1, [x21, #704]
    6ed8:	7e61d800 	ucvtf	d0, d0
    6edc:	1e623800 	fsub	d0, d0, d2
    6ee0:	1e612010 	fcmpe	d0, d1
    6ee4:	54000eec 	b.gt	70c0 <fwp_hof0.constprop.0+0x3e0>
    6ee8:	aa1403fc 	mov	x28, x20
    6eec:	aa1903e1 	mov	x1, x25
    6ef0:	aa1b03e2 	mov	x2, x27
    6ef4:	f800879b 	str	x27, [x28], #8
    6ef8:	aa1c03e0 	mov	x0, x28
    6efc:	97ffe92d 	bl	13b0 <memcpy@plt>
    6f00:	8b1b0283 	add	x3, x20, x27
    6f04:	f94013e0 	ldr	x0, [sp, #32]
    6f08:	3900207f 	strb	wzr, [x3, #8]
    6f0c:	97ffe9c1 	bl	1610 <free@plt>
    6f10:	f949da61 	ldr	x1, [x19, #5040]
    6f14:	f949ee60 	ldr	x0, [x19, #5080]
    6f18:	cb010281 	sub	x1, x20, x1
    6f1c:	eb00403f 	cmp	x1, x0, lsl #16
    6f20:	54000322 	b.cs	6f84 <fwp_hof0.constprop.0+0x2a4>  // b.hs, b.nlast
    6f24:	d350fc20 	lsr	x0, x1, #16
    6f28:	f949fe65 	ldr	x5, [x19, #5112]
    6f2c:	8b000800 	add	x0, x0, x0, lsl #2
    6f30:	d37df002 	lsl	x2, x0, #3
    6f34:	8b0200a3 	add	x3, x5, x2
    6f38:	f9401060 	ldr	x0, [x3, #32]
    6f3c:	b4000240 	cbz	x0, 6f84 <fwp_hof0.constprop.0+0x2a4>
    6f40:	386268a2 	ldrb	w2, [x5, x2]
    6f44:	7100085f 	cmp	w2, #0x2
    6f48:	54000aa0 	b.eq	709c <fwp_hof0.constprop.0+0x3bc>  // b.none
    6f4c:	7100045f 	cmp	w2, #0x1
    6f50:	540001a1 	b.ne	6f84 <fwp_hof0.constprop.0+0x2a4>  // b.any
    6f54:	29430865 	ldp	w5, w2, [x3, #24]
    6f58:	92403c21 	and	x1, x1, #0xffff
    6f5c:	9b057c21 	mul	x1, x1, x5
    6f60:	d360fc21 	lsr	x1, x1, #32
    6f64:	eb02003f 	cmp	x1, x2
    6f68:	540000e2 	b.cs	6f84 <fwp_hof0.constprop.0+0x2a4>  // b.hs, b.nlast
    6f6c:	8b010000 	add	x0, x0, x1
    6f70:	39400001 	ldrb	w1, [x0]
    6f74:	7103fc3f 	cmp	w1, #0xff
    6f78:	540009c0 	b.eq	70b0 <fwp_hof0.constprop.0+0x3d0>  // b.none
    6f7c:	52800021 	mov	w1, #0x1                   	// #1
    6f80:	39000001 	strb	w1, [x0]
    6f84:	aa1603e0 	mov	x0, x22
    6f88:	97fff5c2 	bl	4690 <fwp_drop0>
    6f8c:	f9400282 	ldr	x2, [x20]
    6f90:	d2800021 	mov	x1, #0x1                   	// #1
    6f94:	f94002a3 	ldr	x3, [x21]
    6f98:	aa1c03e0 	mov	x0, x28
    6f9c:	97ffe9ad 	bl	1650 <fwrite@plt>
    6fa0:	f94002a1 	ldr	x1, [x21]
    6fa4:	52800140 	mov	w0, #0xa                   	// #10
    6fa8:	97ffe932 	bl	1470 <fputc@plt>
    6fac:	aa1403e0 	mov	x0, x20
    6fb0:	97fff525 	bl	4444 <fwp_drop4>
    6fb4:	f9400af7 	ldr	x23, [x23, #16]
    6fb8:	b5ffecd7 	cbnz	x23, 6d50 <fwp_hof0.constprop.0+0x70>
    6fbc:	a94553f3 	ldp	x19, x20, [sp, #80]
    6fc0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6fc4:	a9486bf9 	ldp	x25, x26, [sp, #128]
    6fc8:	a94973fb 	ldp	x27, x28, [sp, #144]
    6fcc:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    6fd0:	f947f400 	ldr	x0, [x0, #4072]
    6fd4:	f9401fe2 	ldr	x2, [sp, #56]
    6fd8:	f9400001 	ldr	x1, [x0]
    6fdc:	eb010042 	subs	x2, x2, x1
    6fe0:	d2800001 	mov	x1, #0x0                   	// #0
    6fe4:	540007e1 	b.ne	70e0 <fwp_hof0.constprop.0+0x400>  // b.any
    6fe8:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6fec:	d2800000 	mov	x0, #0x0                   	// #0
    6ff0:	a94763f7 	ldp	x23, x24, [sp, #112]
    6ff4:	910283ff 	add	sp, sp, #0xa0
    6ff8:	d65f03c0 	ret
    6ffc:	f941e494 	ldr	x20, [x4, #968]
    7000:	b40000b4 	cbz	x20, 7014 <fwp_hof0.constprop.0+0x334>
    7004:	f941e880 	ldr	x0, [x4, #976]
    7008:	cb140000 	sub	x0, x0, x20
    700c:	eb0000ff 	cmp	x7, x0
    7010:	540000c9 	b.ls	7028 <fwp_hof0.constprop.0+0x348>  // b.plast
    7014:	aa0203e0 	mov	x0, x2
    7018:	52800021 	mov	w1, #0x1                   	// #1
    701c:	97fff12d 	bl	34d0 <fwp_heap_alloc_slow>
    7020:	aa0003f4 	mov	x20, x0
    7024:	17ffffa9 	b	6ec8 <fwp_hof0.constprop.0+0x1e8>
    7028:	8b070289 	add	x9, x20, x7
    702c:	aa1403e0 	mov	x0, x20
    7030:	52800001 	mov	w1, #0x0                   	// #0
    7034:	f9000be7 	str	x7, [sp, #16]
    7038:	b9001be8 	str	w8, [sp, #24]
    703c:	f901e489 	str	x9, [x4, #968]
    7040:	97ffe938 	bl	1520 <memset@plt>
    7044:	f9400be7 	ldr	x7, [sp, #16]
    7048:	f94a1260 	ldr	x0, [x19, #5152]
    704c:	ab070000 	adds	x0, x0, x7
    7050:	54000462 	b.cs	70dc <fwp_hof0.constprop.0+0x3fc>  // b.hs, b.nlast
    7054:	d0000141 	adrp	x1, 31000 <fwp_root_context+0xcb0>
    7058:	9114c021 	add	x1, x1, #0x530
    705c:	b9401be8 	ldr	w8, [sp, #24]
    7060:	f94a1422 	ldr	x2, [x1, #5160]
    7064:	f90a1020 	str	x0, [x1, #5152]
    7068:	eb02001f 	cmp	x0, x2
    706c:	54000049 	b.ls	7074 <fwp_hof0.constprop.0+0x394>  // b.plast
    7070:	f90a1420 	str	x0, [x1, #5160]
    7074:	d0000140 	adrp	x0, 31000 <fwp_root_context+0xcb0>
    7078:	9114c000 	add	x0, x0, #0x530
    707c:	1e630101 	ucvtf	d1, w8
    7080:	fd4a1c00 	ldr	d0, [x0, #5176]
    7084:	1e612800 	fadd	d0, d0, d1
    7088:	fd0a1c00 	str	d0, [x0, #5176]
    708c:	17ffff8f 	b	6ec8 <fwp_hof0.constprop.0+0x1e8>
    7090:	72003c3f 	tst	w1, #0xffff
    7094:	54ffea41 	b.ne	6ddc <fwp_hof0.constprop.0+0xfc>  // b.any
    7098:	17ffff46 	b	6db0 <fwp_hof0.constprop.0+0xd0>
    709c:	72003c3f 	tst	w1, #0xffff
    70a0:	54fff721 	b.ne	6f84 <fwp_hof0.constprop.0+0x2a4>  // b.any
    70a4:	39400001 	ldrb	w1, [x0]
    70a8:	7103fc3f 	cmp	w1, #0xff
    70ac:	54fff681 	b.ne	6f7c <fwp_hof0.constprop.0+0x29c>  // b.any
    70b0:	f9000be0 	str	x0, [sp, #16]
    70b4:	97ffef9f 	bl	2f30 <fwp_rc_forget_slot>
    70b8:	f9400be0 	ldr	x0, [sp, #16]
    70bc:	17ffffb0 	b	6f7c <fwp_hof0.constprop.0+0x29c>
    70c0:	fd0162a0 	str	d0, [x21, #704]
    70c4:	17ffff89 	b	6ee8 <fwp_hof0.constprop.0+0x208>
    70c8:	97ffef53 	bl	2e14 <fwp_rc_wide_dup>
    70cc:	17ffff44 	b	6ddc <fwp_hof0.constprop.0+0xfc>
    70d0:	f0000000 	adrp	x0, a000 <__divti3+0x2e0>
    70d4:	9122a000 	add	x0, x0, #0x8a8
    70d8:	97ffec8a 	bl	2300 <fwp_trap>
    70dc:	97ffeb1d 	bl	1d50 <fwp_heap_oom>
    70e0:	a90553f3 	stp	x19, x20, [sp, #80]
    70e4:	a9065bf5 	stp	x21, x22, [sp, #96]
    70e8:	a9086bf9 	stp	x25, x26, [sp, #128]
    70ec:	a90973fb 	stp	x27, x28, [sp, #144]
    70f0:	97ffe918 	bl	1550 <__stack_chk_fail@plt>

00000000000070f4 <f0>:
    70f4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    70f8:	910003fd 	mov	x29, sp
    70fc:	a90153f3 	stp	x19, x20, [sp, #16]
    7100:	a9025bf5 	stp	x21, x22, [sp, #32]
    7104:	a90363f7 	stp	x23, x24, [sp, #48]
    7108:	a9046bf9 	stp	x25, x26, [sp, #64]
    710c:	a90573fb 	stp	x27, x28, [sp, #80]
    7110:	d12183ff 	sub	sp, sp, #0x860
    7114:	f90203ff 	str	xzr, [sp, #1024]
    7118:	b00000c0 	adrp	x0, 20000 <__data_start>
    711c:	91014005 	add	x5, x0, #0x50
    7120:	900000c0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    7124:	f947f400 	ldr	x0, [x0, #4072]
    7128:	d0000154 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    712c:	f94138a6 	ldr	x6, [x5, #624]
    7130:	f9400001 	ldr	x1, [x0]
    7134:	f9042fe1 	str	x1, [sp, #2136]
    7138:	d2800001 	mov	x1, #0x0                   	// #0
    713c:	9114c298 	add	x24, x20, #0x530
    7140:	912123f6 	add	x22, sp, #0x848
    7144:	910023e0 	add	x0, sp, #0x8
    7148:	910083e2 	add	x2, sp, #0x20
    714c:	b0ffffe1 	adrp	x1, 4000 <fwp_data.part.0.constprop.0+0xe0>
    7150:	d0ffffc4 	adrp	x4, 1000 <__abi_tag+0xd88>
    7154:	91218021 	add	x1, x1, #0x860
    7158:	912f4084 	add	x4, x4, #0xbd0
    715c:	d2800013 	mov	x19, #0x0                   	// #0
    7160:	d2800119 	mov	x25, #0x8                   	// #8
    7164:	d2800015 	mov	x21, #0x0                   	// #0
    7168:	52800037 	mov	w23, #0x1                   	// #1
    716c:	a90093e6 	stp	x6, x4, [sp, #8]
    7170:	a901ffe2 	stp	x2, xzr, [sp, #24]
    7174:	a90307ff 	stp	xzr, x1, [sp, #48]
    7178:	f90138a0 	str	x0, [x5, #624]
    717c:	d503201f 	nop
    7180:	f100073a 	subs	x26, x25, #0x1
    7184:	aa1603e1 	mov	x1, x22
    7188:	da1f02bc 	sbc	x28, x21, xzr
    718c:	52800020 	mov	w0, #0x1                   	// #1
    7190:	f90017fa 	str	x26, [sp, #40]
    7194:	aa1a03f9 	mov	x25, x26
    7198:	f90427fa 	str	x26, [sp, #2120]
    719c:	aa1c03f5 	mov	x21, x28
    71a0:	f9042bf3 	str	x19, [sp, #2128]
    71a4:	97fff35f 	bl	3f20 <fwp_data.part.0.constprop.0>
    71a8:	f949db02 	ldr	x2, [x24, #5040]
    71ac:	aa0003f3 	mov	x19, x0
    71b0:	f949ef00 	ldr	x0, [x24, #5080]
    71b4:	cb020262 	sub	x2, x19, x2
    71b8:	eb00405f 	cmp	x2, x0, lsl #16
    71bc:	54000302 	b.cs	721c <f0+0x128>  // b.hs, b.nlast
    71c0:	d350fc40 	lsr	x0, x2, #16
    71c4:	f949ff04 	ldr	x4, [x24, #5112]
    71c8:	8b000800 	add	x0, x0, x0, lsl #2
    71cc:	d37df001 	lsl	x1, x0, #3
    71d0:	8b010080 	add	x0, x4, x1
    71d4:	f940101b 	ldr	x27, [x0, #32]
    71d8:	b400023b 	cbz	x27, 721c <f0+0x128>
    71dc:	38616881 	ldrb	w1, [x4, x1]
    71e0:	7100083f 	cmp	w1, #0x2
    71e4:	54010ea0 	b.eq	93b8 <f0+0x22c4>  // b.none
    71e8:	7100043f 	cmp	w1, #0x1
    71ec:	54000181 	b.ne	721c <f0+0x128>  // b.any
    71f0:	29430001 	ldp	w1, w0, [x0, #24]
    71f4:	92403c42 	and	x2, x2, #0xffff
    71f8:	9b017c42 	mul	x2, x2, x1
    71fc:	d360fc42 	lsr	x2, x2, #32
    7200:	eb00005f 	cmp	x2, x0
    7204:	540000c2 	b.cs	721c <f0+0x128>  // b.hs, b.nlast
    7208:	8b02037b 	add	x27, x27, x2
    720c:	39400360 	ldrb	w0, [x27]
    7210:	7103fc1f 	cmp	w0, #0xff
    7214:	54010cc0 	b.eq	93ac <f0+0x22b8>  // b.none
    7218:	39000377 	strb	w23, [x27]
    721c:	f90013f3 	str	x19, [sp, #32]
    7220:	aa1c035a 	orr	x26, x26, x28
    7224:	b5fffafa 	cbnz	x26, 7180 <f0+0x8c>
    7228:	f0000000 	adrp	x0, a000 <__divti3+0x2e0>
    722c:	910103e1 	add	x1, sp, #0x40
    7230:	f94007e2 	ldr	x2, [sp, #8]
    7234:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7238:	3dc2cc00 	ldr	q0, [x0, #2864]
    723c:	b00000c0 	adrp	x0, 20000 <__data_start>
    7240:	91014018 	add	x24, x0, #0x50
    7244:	52800020 	mov	w0, #0x1                   	// #1
    7248:	3d8013e0 	str	q0, [sp, #64]
    724c:	f9013b02 	str	x2, [x24, #624]
    7250:	97fff334 	bl	3f20 <fwp_data.part.0.constprop.0>
    7254:	97fff143 	bl	3760 <fwp_rc_fresh>
    7258:	aa0003e2 	mov	x2, x0
    725c:	910163e1 	add	x1, sp, #0x58
    7260:	52800020 	mov	w0, #0x1                   	// #1
    7264:	a9058bf5 	stp	x21, x2, [sp, #88]
    7268:	97fff32e 	bl	3f20 <fwp_data.part.0.constprop.0>
    726c:	97fff13d 	bl	3760 <fwp_rc_fresh>
    7270:	aa0003e2 	mov	x2, x0
    7274:	f0000003 	adrp	x3, a000 <__divti3+0x2e0>
    7278:	9101a3e1 	add	x1, sp, #0x68
    727c:	52800020 	mov	w0, #0x1                   	// #1
    7280:	f9003be2 	str	x2, [sp, #112]
    7284:	3dc2cc60 	ldr	q0, [x3, #2864]
    7288:	fd0037e0 	str	d0, [sp, #104]
    728c:	97fff325 	bl	3f20 <fwp_data.part.0.constprop.0>
    7290:	97fff134 	bl	3760 <fwp_rc_fresh>
    7294:	aa0003e2 	mov	x2, x0
    7298:	9101e3e1 	add	x1, sp, #0x78
    729c:	52800020 	mov	w0, #0x1                   	// #1
    72a0:	a9078bf5 	stp	x21, x2, [sp, #120]
    72a4:	97fff31f 	bl	3f20 <fwp_data.part.0.constprop.0>
    72a8:	97fff12e 	bl	3760 <fwp_rc_fresh>
    72ac:	aa0003e2 	mov	x2, x0
    72b0:	f0000003 	adrp	x3, a000 <__divti3+0x2e0>
    72b4:	910223e1 	add	x1, sp, #0x88
    72b8:	52800020 	mov	w0, #0x1                   	// #1
    72bc:	f9004be2 	str	x2, [sp, #144]
    72c0:	3dc2cc60 	ldr	q0, [x3, #2864]
    72c4:	fd0047e0 	str	d0, [sp, #136]
    72c8:	97fff316 	bl	3f20 <fwp_data.part.0.constprop.0>
    72cc:	97fff125 	bl	3760 <fwp_rc_fresh>
    72d0:	aa0003e2 	mov	x2, x0
    72d4:	910263e1 	add	x1, sp, #0x98
    72d8:	52800020 	mov	w0, #0x1                   	// #1
    72dc:	a9098bf5 	stp	x21, x2, [sp, #152]
    72e0:	97fff310 	bl	3f20 <fwp_data.part.0.constprop.0>
    72e4:	9114c283 	add	x3, x20, #0x530
    72e8:	aa0003f5 	mov	x21, x0
    72ec:	f949d861 	ldr	x1, [x3, #5040]
    72f0:	f949ec60 	ldr	x0, [x3, #5080]
    72f4:	cb0102a1 	sub	x1, x21, x1
    72f8:	eb00403f 	cmp	x1, x0, lsl #16
    72fc:	54000322 	b.cs	7360 <f0+0x26c>  // b.hs, b.nlast
    7300:	d350fc22 	lsr	x2, x1, #16
    7304:	f949fc63 	ldr	x3, [x3, #5112]
    7308:	8b020842 	add	x2, x2, x2, lsl #2
    730c:	d37df042 	lsl	x2, x2, #3
    7310:	8b020060 	add	x0, x3, x2
    7314:	f9401017 	ldr	x23, [x0, #32]
    7318:	b4000257 	cbz	x23, 7360 <f0+0x26c>
    731c:	38626862 	ldrb	w2, [x3, x2]
    7320:	7100085f 	cmp	w2, #0x2
    7324:	540108c0 	b.eq	943c <f0+0x2348>  // b.none
    7328:	7100045f 	cmp	w2, #0x1
    732c:	540001a1 	b.ne	7360 <f0+0x26c>  // b.any
    7330:	29430002 	ldp	w2, w0, [x0, #24]
    7334:	92403c21 	and	x1, x1, #0xffff
    7338:	9b027c21 	mul	x1, x1, x2
    733c:	d360fc21 	lsr	x1, x1, #32
    7340:	eb00003f 	cmp	x1, x0
    7344:	540000e2 	b.cs	7360 <f0+0x26c>  // b.hs, b.nlast
    7348:	8b0102f7 	add	x23, x23, x1
    734c:	394002e0 	ldrb	w0, [x23]
    7350:	7103fc1f 	cmp	w0, #0xff
    7354:	54011280 	b.eq	95a4 <f0+0x24b0>  // b.none
    7358:	52800020 	mov	w0, #0x1                   	// #1
    735c:	390002e0 	strb	w0, [x23]
    7360:	9102a3e1 	add	x1, sp, #0xa8
    7364:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7368:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    736c:	52800020 	mov	w0, #0x1                   	// #1
    7370:	a90ad7f7 	stp	x23, x21, [sp, #168]
    7374:	97fff2eb 	bl	3f20 <fwp_data.part.0.constprop.0>
    7378:	97fff0fa 	bl	3760 <fwp_rc_fresh>
    737c:	aa0003e2 	mov	x2, x0
    7380:	9102e3e1 	add	x1, sp, #0xb8
    7384:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7388:	52800020 	mov	w0, #0x1                   	// #1
    738c:	a90b8bf5 	stp	x21, x2, [sp, #184]
    7390:	97fff2e4 	bl	3f20 <fwp_data.part.0.constprop.0>
    7394:	97fff0f3 	bl	3760 <fwp_rc_fresh>
    7398:	aa0003e2 	mov	x2, x0
    739c:	910323e1 	add	x1, sp, #0xc8
    73a0:	52800020 	mov	w0, #0x1                   	// #1
    73a4:	a90c8bf7 	stp	x23, x2, [sp, #200]
    73a8:	97fff2de 	bl	3f20 <fwp_data.part.0.constprop.0>
    73ac:	97fff0ed 	bl	3760 <fwp_rc_fresh>
    73b0:	aa0003e2 	mov	x2, x0
    73b4:	910363e1 	add	x1, sp, #0xd8
    73b8:	52800020 	mov	w0, #0x1                   	// #1
    73bc:	a90d8bf5 	stp	x21, x2, [sp, #216]
    73c0:	97fff2d8 	bl	3f20 <fwp_data.part.0.constprop.0>
    73c4:	97fff0e7 	bl	3760 <fwp_rc_fresh>
    73c8:	aa0003e2 	mov	x2, x0
    73cc:	9103a3e1 	add	x1, sp, #0xe8
    73d0:	52800020 	mov	w0, #0x1                   	// #1
    73d4:	a90e8bf7 	stp	x23, x2, [sp, #232]
    73d8:	97fff2d2 	bl	3f20 <fwp_data.part.0.constprop.0>
    73dc:	97fff0e1 	bl	3760 <fwp_rc_fresh>
    73e0:	aa0003e2 	mov	x2, x0
    73e4:	9103e3e1 	add	x1, sp, #0xf8
    73e8:	52800020 	mov	w0, #0x1                   	// #1
    73ec:	a90f8bf5 	stp	x21, x2, [sp, #248]
    73f0:	97fff2cc 	bl	3f20 <fwp_data.part.0.constprop.0>
    73f4:	97fff0db 	bl	3760 <fwp_rc_fresh>
    73f8:	aa0003e2 	mov	x2, x0
    73fc:	910423e1 	add	x1, sp, #0x108
    7400:	52800020 	mov	w0, #0x1                   	// #1
    7404:	a9108bf7 	stp	x23, x2, [sp, #264]
    7408:	97fff2c6 	bl	3f20 <fwp_data.part.0.constprop.0>
    740c:	97fff0d5 	bl	3760 <fwp_rc_fresh>
    7410:	aa0003e2 	mov	x2, x0
    7414:	910463e1 	add	x1, sp, #0x118
    7418:	52800020 	mov	w0, #0x1                   	// #1
    741c:	a9118bf5 	stp	x21, x2, [sp, #280]
    7420:	97fff2c0 	bl	3f20 <fwp_data.part.0.constprop.0>
    7424:	97fff0cf 	bl	3760 <fwp_rc_fresh>
    7428:	aa0003e2 	mov	x2, x0
    742c:	9104a3e1 	add	x1, sp, #0x128
    7430:	52800020 	mov	w0, #0x1                   	// #1
    7434:	a9128bf7 	stp	x23, x2, [sp, #296]
    7438:	97fff2ba 	bl	3f20 <fwp_data.part.0.constprop.0>
    743c:	97fff0c9 	bl	3760 <fwp_rc_fresh>
    7440:	aa0003e2 	mov	x2, x0
    7444:	9104e3e1 	add	x1, sp, #0x138
    7448:	52800020 	mov	w0, #0x1                   	// #1
    744c:	a9138bf5 	stp	x21, x2, [sp, #312]
    7450:	97fff2b4 	bl	3f20 <fwp_data.part.0.constprop.0>
    7454:	97fff0c3 	bl	3760 <fwp_rc_fresh>
    7458:	aa0003e2 	mov	x2, x0
    745c:	910523e1 	add	x1, sp, #0x148
    7460:	52800020 	mov	w0, #0x1                   	// #1
    7464:	a9148bf7 	stp	x23, x2, [sp, #328]
    7468:	97fff2ae 	bl	3f20 <fwp_data.part.0.constprop.0>
    746c:	97fff0bd 	bl	3760 <fwp_rc_fresh>
    7470:	aa0003e2 	mov	x2, x0
    7474:	910563e1 	add	x1, sp, #0x158
    7478:	52800020 	mov	w0, #0x1                   	// #1
    747c:	a9158bf5 	stp	x21, x2, [sp, #344]
    7480:	97fff2a8 	bl	3f20 <fwp_data.part.0.constprop.0>
    7484:	9114c283 	add	x3, x20, #0x530
    7488:	aa0003f5 	mov	x21, x0
    748c:	f949d861 	ldr	x1, [x3, #5040]
    7490:	f949ec60 	ldr	x0, [x3, #5080]
    7494:	cb0102a1 	sub	x1, x21, x1
    7498:	eb00403f 	cmp	x1, x0, lsl #16
    749c:	54000322 	b.cs	7500 <f0+0x40c>  // b.hs, b.nlast
    74a0:	d350fc22 	lsr	x2, x1, #16
    74a4:	f949fc63 	ldr	x3, [x3, #5112]
    74a8:	8b020842 	add	x2, x2, x2, lsl #2
    74ac:	d37df042 	lsl	x2, x2, #3
    74b0:	8b020060 	add	x0, x3, x2
    74b4:	f9401017 	ldr	x23, [x0, #32]
    74b8:	b4000257 	cbz	x23, 7500 <f0+0x40c>
    74bc:	38626862 	ldrb	w2, [x3, x2]
    74c0:	7100085f 	cmp	w2, #0x2
    74c4:	5400fb60 	b.eq	9430 <f0+0x233c>  // b.none
    74c8:	7100045f 	cmp	w2, #0x1
    74cc:	540001a1 	b.ne	7500 <f0+0x40c>  // b.any
    74d0:	29430002 	ldp	w2, w0, [x0, #24]
    74d4:	92403c21 	and	x1, x1, #0xffff
    74d8:	9b027c21 	mul	x1, x1, x2
    74dc:	d360fc21 	lsr	x1, x1, #32
    74e0:	eb00003f 	cmp	x1, x0
    74e4:	540000e2 	b.cs	7500 <f0+0x40c>  // b.hs, b.nlast
    74e8:	8b0102f7 	add	x23, x23, x1
    74ec:	394002e0 	ldrb	w0, [x23]
    74f0:	7103fc1f 	cmp	w0, #0xff
    74f4:	540105e0 	b.eq	95b0 <f0+0x24bc>  // b.none
    74f8:	52800020 	mov	w0, #0x1                   	// #1
    74fc:	390002e0 	strb	w0, [x23]
    7500:	9105a3e1 	add	x1, sp, #0x168
    7504:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7508:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    750c:	52800020 	mov	w0, #0x1                   	// #1
    7510:	a916d7f7 	stp	x23, x21, [sp, #360]
    7514:	97fff283 	bl	3f20 <fwp_data.part.0.constprop.0>
    7518:	97fff092 	bl	3760 <fwp_rc_fresh>
    751c:	aa0003e2 	mov	x2, x0
    7520:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    7524:	9105e3e1 	add	x1, sp, #0x178
    7528:	52800020 	mov	w0, #0x1                   	// #1
    752c:	a9178be3 	stp	x3, x2, [sp, #376]
    7530:	97fff27c 	bl	3f20 <fwp_data.part.0.constprop.0>
    7534:	97fff08b 	bl	3760 <fwp_rc_fresh>
    7538:	aa0003e2 	mov	x2, x0
    753c:	910623e1 	add	x1, sp, #0x188
    7540:	52800020 	mov	w0, #0x1                   	// #1
    7544:	a9188bf7 	stp	x23, x2, [sp, #392]
    7548:	97fff276 	bl	3f20 <fwp_data.part.0.constprop.0>
    754c:	9114c283 	add	x3, x20, #0x530
    7550:	aa0003f5 	mov	x21, x0
    7554:	f949d861 	ldr	x1, [x3, #5040]
    7558:	f949ec60 	ldr	x0, [x3, #5080]
    755c:	cb0102a1 	sub	x1, x21, x1
    7560:	eb00403f 	cmp	x1, x0, lsl #16
    7564:	54000322 	b.cs	75c8 <f0+0x4d4>  // b.hs, b.nlast
    7568:	d350fc22 	lsr	x2, x1, #16
    756c:	f949fc63 	ldr	x3, [x3, #5112]
    7570:	8b020842 	add	x2, x2, x2, lsl #2
    7574:	d37df042 	lsl	x2, x2, #3
    7578:	8b020060 	add	x0, x3, x2
    757c:	f9401017 	ldr	x23, [x0, #32]
    7580:	b4000257 	cbz	x23, 75c8 <f0+0x4d4>
    7584:	38626862 	ldrb	w2, [x3, x2]
    7588:	7100085f 	cmp	w2, #0x2
    758c:	5400f4c0 	b.eq	9424 <f0+0x2330>  // b.none
    7590:	7100045f 	cmp	w2, #0x1
    7594:	540001a1 	b.ne	75c8 <f0+0x4d4>  // b.any
    7598:	29430002 	ldp	w2, w0, [x0, #24]
    759c:	92403c21 	and	x1, x1, #0xffff
    75a0:	9b027c21 	mul	x1, x1, x2
    75a4:	d360fc21 	lsr	x1, x1, #32
    75a8:	eb00003f 	cmp	x1, x0
    75ac:	540000e2 	b.cs	75c8 <f0+0x4d4>  // b.hs, b.nlast
    75b0:	8b0102f7 	add	x23, x23, x1
    75b4:	394002e0 	ldrb	w0, [x23]
    75b8:	7103fc1f 	cmp	w0, #0xff
    75bc:	54010000 	b.eq	95bc <f0+0x24c8>  // b.none
    75c0:	52800020 	mov	w0, #0x1                   	// #1
    75c4:	390002e0 	strb	w0, [x23]
    75c8:	910663e1 	add	x1, sp, #0x198
    75cc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    75d0:	52800020 	mov	w0, #0x1                   	// #1
    75d4:	a919d7e2 	stp	x2, x21, [sp, #408]
    75d8:	97fff252 	bl	3f20 <fwp_data.part.0.constprop.0>
    75dc:	97fff061 	bl	3760 <fwp_rc_fresh>
    75e0:	aa0003e2 	mov	x2, x0
    75e4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    75e8:	9106a3e1 	add	x1, sp, #0x1a8
    75ec:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    75f0:	52800020 	mov	w0, #0x1                   	// #1
    75f4:	a91a8be3 	stp	x3, x2, [sp, #424]
    75f8:	97fff24a 	bl	3f20 <fwp_data.part.0.constprop.0>
    75fc:	9114c283 	add	x3, x20, #0x530
    7600:	aa0003f5 	mov	x21, x0
    7604:	f949d861 	ldr	x1, [x3, #5040]
    7608:	f949ec60 	ldr	x0, [x3, #5080]
    760c:	cb0102a1 	sub	x1, x21, x1
    7610:	eb00403f 	cmp	x1, x0, lsl #16
    7614:	54000322 	b.cs	7678 <f0+0x584>  // b.hs, b.nlast
    7618:	d350fc22 	lsr	x2, x1, #16
    761c:	f949fc63 	ldr	x3, [x3, #5112]
    7620:	8b020842 	add	x2, x2, x2, lsl #2
    7624:	d37df042 	lsl	x2, x2, #3
    7628:	8b020060 	add	x0, x3, x2
    762c:	f9401017 	ldr	x23, [x0, #32]
    7630:	b4000257 	cbz	x23, 7678 <f0+0x584>
    7634:	38626862 	ldrb	w2, [x3, x2]
    7638:	7100085f 	cmp	w2, #0x2
    763c:	5400f180 	b.eq	946c <f0+0x2378>  // b.none
    7640:	7100045f 	cmp	w2, #0x1
    7644:	540001a1 	b.ne	7678 <f0+0x584>  // b.any
    7648:	29430002 	ldp	w2, w0, [x0, #24]
    764c:	92403c21 	and	x1, x1, #0xffff
    7650:	9b027c21 	mul	x1, x1, x2
    7654:	d360fc21 	lsr	x1, x1, #32
    7658:	eb00003f 	cmp	x1, x0
    765c:	540000e2 	b.cs	7678 <f0+0x584>  // b.hs, b.nlast
    7660:	8b0102f7 	add	x23, x23, x1
    7664:	394002e0 	ldrb	w0, [x23]
    7668:	7103fc1f 	cmp	w0, #0xff
    766c:	5400fae0 	b.eq	95c8 <f0+0x24d4>  // b.none
    7670:	52800020 	mov	w0, #0x1                   	// #1
    7674:	390002e0 	strb	w0, [x23]
    7678:	9106e3e1 	add	x1, sp, #0x1b8
    767c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7680:	52800020 	mov	w0, #0x1                   	// #1
    7684:	a91bd7e2 	stp	x2, x21, [sp, #440]
    7688:	97fff226 	bl	3f20 <fwp_data.part.0.constprop.0>
    768c:	97fff035 	bl	3760 <fwp_rc_fresh>
    7690:	aa0003e2 	mov	x2, x0
    7694:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7698:	910723e1 	add	x1, sp, #0x1c8
    769c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    76a0:	52800020 	mov	w0, #0x1                   	// #1
    76a4:	a91c8be3 	stp	x3, x2, [sp, #456]
    76a8:	97fff21e 	bl	3f20 <fwp_data.part.0.constprop.0>
    76ac:	9114c283 	add	x3, x20, #0x530
    76b0:	aa0003f5 	mov	x21, x0
    76b4:	f949d861 	ldr	x1, [x3, #5040]
    76b8:	f949ec60 	ldr	x0, [x3, #5080]
    76bc:	cb0102a1 	sub	x1, x21, x1
    76c0:	eb00403f 	cmp	x1, x0, lsl #16
    76c4:	54000322 	b.cs	7728 <f0+0x634>  // b.hs, b.nlast
    76c8:	d350fc22 	lsr	x2, x1, #16
    76cc:	f949fc63 	ldr	x3, [x3, #5112]
    76d0:	8b020842 	add	x2, x2, x2, lsl #2
    76d4:	d37df042 	lsl	x2, x2, #3
    76d8:	8b020060 	add	x0, x3, x2
    76dc:	f9401017 	ldr	x23, [x0, #32]
    76e0:	b4000257 	cbz	x23, 7728 <f0+0x634>
    76e4:	38626862 	ldrb	w2, [x3, x2]
    76e8:	7100085f 	cmp	w2, #0x2
    76ec:	5400eba0 	b.eq	9460 <f0+0x236c>  // b.none
    76f0:	7100045f 	cmp	w2, #0x1
    76f4:	540001a1 	b.ne	7728 <f0+0x634>  // b.any
    76f8:	29430002 	ldp	w2, w0, [x0, #24]
    76fc:	92403c21 	and	x1, x1, #0xffff
    7700:	9b027c21 	mul	x1, x1, x2
    7704:	d360fc21 	lsr	x1, x1, #32
    7708:	eb00003f 	cmp	x1, x0
    770c:	540000e2 	b.cs	7728 <f0+0x634>  // b.hs, b.nlast
    7710:	8b0102f7 	add	x23, x23, x1
    7714:	394002e0 	ldrb	w0, [x23]
    7718:	7103fc1f 	cmp	w0, #0xff
    771c:	5400f5c0 	b.eq	95d4 <f0+0x24e0>  // b.none
    7720:	52800020 	mov	w0, #0x1                   	// #1
    7724:	390002e0 	strb	w0, [x23]
    7728:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    772c:	910763e1 	add	x1, sp, #0x1d8
    7730:	52800020 	mov	w0, #0x1                   	// #1
    7734:	a91dd7e2 	stp	x2, x21, [sp, #472]
    7738:	97fff1fa 	bl	3f20 <fwp_data.part.0.constprop.0>
    773c:	9114c283 	add	x3, x20, #0x530
    7740:	aa0003f5 	mov	x21, x0
    7744:	f949d861 	ldr	x1, [x3, #5040]
    7748:	f949ec60 	ldr	x0, [x3, #5080]
    774c:	cb0102a1 	sub	x1, x21, x1
    7750:	eb00403f 	cmp	x1, x0, lsl #16
    7754:	54000322 	b.cs	77b8 <f0+0x6c4>  // b.hs, b.nlast
    7758:	d350fc22 	lsr	x2, x1, #16
    775c:	f949fc63 	ldr	x3, [x3, #5112]
    7760:	8b020842 	add	x2, x2, x2, lsl #2
    7764:	d37df042 	lsl	x2, x2, #3
    7768:	8b020060 	add	x0, x3, x2
    776c:	f9401017 	ldr	x23, [x0, #32]
    7770:	b4000257 	cbz	x23, 77b8 <f0+0x6c4>
    7774:	38626862 	ldrb	w2, [x3, x2]
    7778:	7100085f 	cmp	w2, #0x2
    777c:	5400e6c0 	b.eq	9454 <f0+0x2360>  // b.none
    7780:	7100045f 	cmp	w2, #0x1
    7784:	540001a1 	b.ne	77b8 <f0+0x6c4>  // b.any
    7788:	29430002 	ldp	w2, w0, [x0, #24]
    778c:	92403c21 	and	x1, x1, #0xffff
    7790:	9b027c21 	mul	x1, x1, x2
    7794:	d360fc21 	lsr	x1, x1, #32
    7798:	eb00003f 	cmp	x1, x0
    779c:	540000e2 	b.cs	77b8 <f0+0x6c4>  // b.hs, b.nlast
    77a0:	8b0102f7 	add	x23, x23, x1
    77a4:	394002e0 	ldrb	w0, [x23]
    77a8:	7103fc1f 	cmp	w0, #0xff
    77ac:	5400f1a0 	b.eq	95e0 <f0+0x24ec>  // b.none
    77b0:	52800020 	mov	w0, #0x1                   	// #1
    77b4:	390002e0 	strb	w0, [x23]
    77b8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    77bc:	9107a3e1 	add	x1, sp, #0x1e8
    77c0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    77c4:	52800020 	mov	w0, #0x1                   	// #1
    77c8:	a91ed7e2 	stp	x2, x21, [sp, #488]
    77cc:	97fff1d5 	bl	3f20 <fwp_data.part.0.constprop.0>
    77d0:	9114c283 	add	x3, x20, #0x530
    77d4:	aa0003f5 	mov	x21, x0
    77d8:	f949d861 	ldr	x1, [x3, #5040]
    77dc:	f949ec60 	ldr	x0, [x3, #5080]
    77e0:	cb0102a1 	sub	x1, x21, x1
    77e4:	eb00403f 	cmp	x1, x0, lsl #16
    77e8:	54000322 	b.cs	784c <f0+0x758>  // b.hs, b.nlast
    77ec:	d350fc22 	lsr	x2, x1, #16
    77f0:	f949fc63 	ldr	x3, [x3, #5112]
    77f4:	8b020842 	add	x2, x2, x2, lsl #2
    77f8:	d37df042 	lsl	x2, x2, #3
    77fc:	8b020060 	add	x0, x3, x2
    7800:	f9401017 	ldr	x23, [x0, #32]
    7804:	b4000257 	cbz	x23, 784c <f0+0x758>
    7808:	38626862 	ldrb	w2, [x3, x2]
    780c:	7100085f 	cmp	w2, #0x2
    7810:	5400e1c0 	b.eq	9448 <f0+0x2354>  // b.none
    7814:	7100045f 	cmp	w2, #0x1
    7818:	540001a1 	b.ne	784c <f0+0x758>  // b.any
    781c:	29430002 	ldp	w2, w0, [x0, #24]
    7820:	92403c21 	and	x1, x1, #0xffff
    7824:	9b027c21 	mul	x1, x1, x2
    7828:	d360fc21 	lsr	x1, x1, #32
    782c:	eb00003f 	cmp	x1, x0
    7830:	540000e2 	b.cs	784c <f0+0x758>  // b.hs, b.nlast
    7834:	8b0102f7 	add	x23, x23, x1
    7838:	394002e0 	ldrb	w0, [x23]
    783c:	7103fc1f 	cmp	w0, #0xff
    7840:	5400ed60 	b.eq	95ec <f0+0x24f8>  // b.none
    7844:	52800020 	mov	w0, #0x1                   	// #1
    7848:	390002e0 	strb	w0, [x23]
    784c:	9107e3e1 	add	x1, sp, #0x1f8
    7850:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7854:	52800020 	mov	w0, #0x1                   	// #1
    7858:	a91fd7f7 	stp	x23, x21, [sp, #504]
    785c:	97fff1b1 	bl	3f20 <fwp_data.part.0.constprop.0>
    7860:	97ffefc0 	bl	3760 <fwp_rc_fresh>
    7864:	aa0003e2 	mov	x2, x0
    7868:	910823e1 	add	x1, sp, #0x208
    786c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    7870:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    7874:	52800020 	mov	w0, #0x1                   	// #1
    7878:	f90107f5 	str	x21, [sp, #520]
    787c:	f9010be2 	str	x2, [sp, #528]
    7880:	97fff1a8 	bl	3f20 <fwp_data.part.0.constprop.0>
    7884:	97ffefb7 	bl	3760 <fwp_rc_fresh>
    7888:	aa0003e2 	mov	x2, x0
    788c:	910863e1 	add	x1, sp, #0x218
    7890:	52800020 	mov	w0, #0x1                   	// #1
    7894:	f9010ff7 	str	x23, [sp, #536]
    7898:	f90113e2 	str	x2, [sp, #544]
    789c:	97fff1a1 	bl	3f20 <fwp_data.part.0.constprop.0>
    78a0:	97ffefb0 	bl	3760 <fwp_rc_fresh>
    78a4:	aa0003e2 	mov	x2, x0
    78a8:	9108a3e1 	add	x1, sp, #0x228
    78ac:	52800020 	mov	w0, #0x1                   	// #1
    78b0:	f90117f5 	str	x21, [sp, #552]
    78b4:	f9011be2 	str	x2, [sp, #560]
    78b8:	97fff19a 	bl	3f20 <fwp_data.part.0.constprop.0>
    78bc:	97ffefa9 	bl	3760 <fwp_rc_fresh>
    78c0:	aa0003e2 	mov	x2, x0
    78c4:	9108e3e1 	add	x1, sp, #0x238
    78c8:	52800020 	mov	w0, #0x1                   	// #1
    78cc:	f9011ff7 	str	x23, [sp, #568]
    78d0:	f90123e2 	str	x2, [sp, #576]
    78d4:	97fff193 	bl	3f20 <fwp_data.part.0.constprop.0>
    78d8:	97ffefa2 	bl	3760 <fwp_rc_fresh>
    78dc:	aa0003e2 	mov	x2, x0
    78e0:	910923e1 	add	x1, sp, #0x248
    78e4:	52800020 	mov	w0, #0x1                   	// #1
    78e8:	f90127f5 	str	x21, [sp, #584]
    78ec:	f9012be2 	str	x2, [sp, #592]
    78f0:	97fff18c 	bl	3f20 <fwp_data.part.0.constprop.0>
    78f4:	97ffef9b 	bl	3760 <fwp_rc_fresh>
    78f8:	aa0003e2 	mov	x2, x0
    78fc:	910963e1 	add	x1, sp, #0x258
    7900:	52800020 	mov	w0, #0x1                   	// #1
    7904:	f9012ff7 	str	x23, [sp, #600]
    7908:	f90133e2 	str	x2, [sp, #608]
    790c:	97fff185 	bl	3f20 <fwp_data.part.0.constprop.0>
    7910:	97ffef94 	bl	3760 <fwp_rc_fresh>
    7914:	aa0003e2 	mov	x2, x0
    7918:	9109a3e1 	add	x1, sp, #0x268
    791c:	52800020 	mov	w0, #0x1                   	// #1
    7920:	f90137f5 	str	x21, [sp, #616]
    7924:	f9013be2 	str	x2, [sp, #624]
    7928:	97fff17e 	bl	3f20 <fwp_data.part.0.constprop.0>
    792c:	9114c283 	add	x3, x20, #0x530
    7930:	aa0003f5 	mov	x21, x0
    7934:	f949d861 	ldr	x1, [x3, #5040]
    7938:	f949ec60 	ldr	x0, [x3, #5080]
    793c:	cb0102a1 	sub	x1, x21, x1
    7940:	eb00403f 	cmp	x1, x0, lsl #16
    7944:	54000322 	b.cs	79a8 <f0+0x8b4>  // b.hs, b.nlast
    7948:	d350fc22 	lsr	x2, x1, #16
    794c:	f949fc63 	ldr	x3, [x3, #5112]
    7950:	8b020842 	add	x2, x2, x2, lsl #2
    7954:	d37df042 	lsl	x2, x2, #3
    7958:	8b020060 	add	x0, x3, x2
    795c:	f9401017 	ldr	x23, [x0, #32]
    7960:	b4000257 	cbz	x23, 79a8 <f0+0x8b4>
    7964:	38626862 	ldrb	w2, [x3, x2]
    7968:	7100085f 	cmp	w2, #0x2
    796c:	5400db00 	b.eq	94cc <f0+0x23d8>  // b.none
    7970:	7100045f 	cmp	w2, #0x1
    7974:	540001a1 	b.ne	79a8 <f0+0x8b4>  // b.any
    7978:	29430002 	ldp	w2, w0, [x0, #24]
    797c:	92403c21 	and	x1, x1, #0xffff
    7980:	9b027c21 	mul	x1, x1, x2
    7984:	d360fc21 	lsr	x1, x1, #32
    7988:	eb00003f 	cmp	x1, x0
    798c:	540000e2 	b.cs	79a8 <f0+0x8b4>  // b.hs, b.nlast
    7990:	8b0102f7 	add	x23, x23, x1
    7994:	394002e0 	ldrb	w0, [x23]
    7998:	7103fc1f 	cmp	w0, #0xff
    799c:	5400e2e0 	b.eq	95f8 <f0+0x2504>  // b.none
    79a0:	52800020 	mov	w0, #0x1                   	// #1
    79a4:	390002e0 	strb	w0, [x23]
    79a8:	9109e3e1 	add	x1, sp, #0x278
    79ac:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    79b0:	52800020 	mov	w0, #0x1                   	// #1
    79b4:	f9013ff7 	str	x23, [sp, #632]
    79b8:	f90143f5 	str	x21, [sp, #640]
    79bc:	97fff159 	bl	3f20 <fwp_data.part.0.constprop.0>
    79c0:	97ffef68 	bl	3760 <fwp_rc_fresh>
    79c4:	aa0003e2 	mov	x2, x0
    79c8:	910a23e1 	add	x1, sp, #0x288
    79cc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    79d0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    79d4:	52800020 	mov	w0, #0x1                   	// #1
    79d8:	f90147f5 	str	x21, [sp, #648]
    79dc:	f9014be2 	str	x2, [sp, #656]
    79e0:	97fff150 	bl	3f20 <fwp_data.part.0.constprop.0>
    79e4:	97ffef5f 	bl	3760 <fwp_rc_fresh>
    79e8:	aa0003e2 	mov	x2, x0
    79ec:	910a63e1 	add	x1, sp, #0x298
    79f0:	52800020 	mov	w0, #0x1                   	// #1
    79f4:	f9014ff7 	str	x23, [sp, #664]
    79f8:	f90153e2 	str	x2, [sp, #672]
    79fc:	97fff149 	bl	3f20 <fwp_data.part.0.constprop.0>
    7a00:	97ffef58 	bl	3760 <fwp_rc_fresh>
    7a04:	aa0003e2 	mov	x2, x0
    7a08:	910aa3e1 	add	x1, sp, #0x2a8
    7a0c:	52800020 	mov	w0, #0x1                   	// #1
    7a10:	f90157f5 	str	x21, [sp, #680]
    7a14:	f9015be2 	str	x2, [sp, #688]
    7a18:	97fff142 	bl	3f20 <fwp_data.part.0.constprop.0>
    7a1c:	9114c283 	add	x3, x20, #0x530
    7a20:	aa0003f5 	mov	x21, x0
    7a24:	f949d861 	ldr	x1, [x3, #5040]
    7a28:	f949ec60 	ldr	x0, [x3, #5080]
    7a2c:	cb0102a1 	sub	x1, x21, x1
    7a30:	eb00403f 	cmp	x1, x0, lsl #16
    7a34:	54000322 	b.cs	7a98 <f0+0x9a4>  // b.hs, b.nlast
    7a38:	d350fc22 	lsr	x2, x1, #16
    7a3c:	f949fc63 	ldr	x3, [x3, #5112]
    7a40:	8b020842 	add	x2, x2, x2, lsl #2
    7a44:	d37df042 	lsl	x2, x2, #3
    7a48:	8b020060 	add	x0, x3, x2
    7a4c:	f9401017 	ldr	x23, [x0, #32]
    7a50:	b4000257 	cbz	x23, 7a98 <f0+0x9a4>
    7a54:	38626862 	ldrb	w2, [x3, x2]
    7a58:	7100085f 	cmp	w2, #0x2
    7a5c:	5400d320 	b.eq	94c0 <f0+0x23cc>  // b.none
    7a60:	7100045f 	cmp	w2, #0x1
    7a64:	540001a1 	b.ne	7a98 <f0+0x9a4>  // b.any
    7a68:	29430002 	ldp	w2, w0, [x0, #24]
    7a6c:	92403c21 	and	x1, x1, #0xffff
    7a70:	9b027c21 	mul	x1, x1, x2
    7a74:	d360fc21 	lsr	x1, x1, #32
    7a78:	eb00003f 	cmp	x1, x0
    7a7c:	540000e2 	b.cs	7a98 <f0+0x9a4>  // b.hs, b.nlast
    7a80:	8b0102f7 	add	x23, x23, x1
    7a84:	394002e0 	ldrb	w0, [x23]
    7a88:	7103fc1f 	cmp	w0, #0xff
    7a8c:	5400dbc0 	b.eq	9604 <f0+0x2510>  // b.none
    7a90:	52800020 	mov	w0, #0x1                   	// #1
    7a94:	390002e0 	strb	w0, [x23]
    7a98:	910ae3e1 	add	x1, sp, #0x2b8
    7a9c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7aa0:	52800020 	mov	w0, #0x1                   	// #1
    7aa4:	f9015ff7 	str	x23, [sp, #696]
    7aa8:	f90163f5 	str	x21, [sp, #704]
    7aac:	97fff11d 	bl	3f20 <fwp_data.part.0.constprop.0>
    7ab0:	97ffef2c 	bl	3760 <fwp_rc_fresh>
    7ab4:	aa0003e2 	mov	x2, x0
    7ab8:	910b23e1 	add	x1, sp, #0x2c8
    7abc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    7ac0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    7ac4:	52800020 	mov	w0, #0x1                   	// #1
    7ac8:	f90167f5 	str	x21, [sp, #712]
    7acc:	f9016be2 	str	x2, [sp, #720]
    7ad0:	97fff114 	bl	3f20 <fwp_data.part.0.constprop.0>
    7ad4:	97ffef23 	bl	3760 <fwp_rc_fresh>
    7ad8:	aa0003e2 	mov	x2, x0
    7adc:	910b63e1 	add	x1, sp, #0x2d8
    7ae0:	52800020 	mov	w0, #0x1                   	// #1
    7ae4:	f9016ff7 	str	x23, [sp, #728]
    7ae8:	f90173e2 	str	x2, [sp, #736]
    7aec:	97fff10d 	bl	3f20 <fwp_data.part.0.constprop.0>
    7af0:	97ffef1c 	bl	3760 <fwp_rc_fresh>
    7af4:	aa0003e2 	mov	x2, x0
    7af8:	910ba3e1 	add	x1, sp, #0x2e8
    7afc:	52800020 	mov	w0, #0x1                   	// #1
    7b00:	f90177f5 	str	x21, [sp, #744]
    7b04:	f9017be2 	str	x2, [sp, #752]
    7b08:	97fff106 	bl	3f20 <fwp_data.part.0.constprop.0>
    7b0c:	9114c283 	add	x3, x20, #0x530
    7b10:	aa0003f5 	mov	x21, x0
    7b14:	f949d861 	ldr	x1, [x3, #5040]
    7b18:	f949ec60 	ldr	x0, [x3, #5080]
    7b1c:	cb0102a1 	sub	x1, x21, x1
    7b20:	eb00403f 	cmp	x1, x0, lsl #16
    7b24:	54000322 	b.cs	7b88 <f0+0xa94>  // b.hs, b.nlast
    7b28:	d350fc22 	lsr	x2, x1, #16
    7b2c:	f949fc63 	ldr	x3, [x3, #5112]
    7b30:	8b020842 	add	x2, x2, x2, lsl #2
    7b34:	d37df042 	lsl	x2, x2, #3
    7b38:	8b020060 	add	x0, x3, x2
    7b3c:	f9401017 	ldr	x23, [x0, #32]
    7b40:	b4000257 	cbz	x23, 7b88 <f0+0xa94>
    7b44:	38626862 	ldrb	w2, [x3, x2]
    7b48:	7100085f 	cmp	w2, #0x2
    7b4c:	5400cb40 	b.eq	94b4 <f0+0x23c0>  // b.none
    7b50:	7100045f 	cmp	w2, #0x1
    7b54:	540001a1 	b.ne	7b88 <f0+0xa94>  // b.any
    7b58:	29430002 	ldp	w2, w0, [x0, #24]
    7b5c:	92403c21 	and	x1, x1, #0xffff
    7b60:	9b027c21 	mul	x1, x1, x2
    7b64:	d360fc21 	lsr	x1, x1, #32
    7b68:	eb00003f 	cmp	x1, x0
    7b6c:	540000e2 	b.cs	7b88 <f0+0xa94>  // b.hs, b.nlast
    7b70:	8b0102f7 	add	x23, x23, x1
    7b74:	394002e0 	ldrb	w0, [x23]
    7b78:	7103fc1f 	cmp	w0, #0xff
    7b7c:	5400d4a0 	b.eq	9610 <f0+0x251c>  // b.none
    7b80:	52800020 	mov	w0, #0x1                   	// #1
    7b84:	390002e0 	strb	w0, [x23]
    7b88:	910be3e1 	add	x1, sp, #0x2f8
    7b8c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7b90:	52800020 	mov	w0, #0x1                   	// #1
    7b94:	f9017ff7 	str	x23, [sp, #760]
    7b98:	f90183f5 	str	x21, [sp, #768]
    7b9c:	97fff0e1 	bl	3f20 <fwp_data.part.0.constprop.0>
    7ba0:	97ffeef0 	bl	3760 <fwp_rc_fresh>
    7ba4:	aa0003e2 	mov	x2, x0
    7ba8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    7bac:	910c23e1 	add	x1, sp, #0x308
    7bb0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    7bb4:	52800020 	mov	w0, #0x1                   	// #1
    7bb8:	f90187e3 	str	x3, [sp, #776]
    7bbc:	f9018be2 	str	x2, [sp, #784]
    7bc0:	97fff0d8 	bl	3f20 <fwp_data.part.0.constprop.0>
    7bc4:	97ffeee7 	bl	3760 <fwp_rc_fresh>
    7bc8:	aa0003e2 	mov	x2, x0
    7bcc:	910c63e1 	add	x1, sp, #0x318
    7bd0:	52800020 	mov	w0, #0x1                   	// #1
    7bd4:	f9018ff7 	str	x23, [sp, #792]
    7bd8:	f90193e2 	str	x2, [sp, #800]
    7bdc:	97fff0d1 	bl	3f20 <fwp_data.part.0.constprop.0>
    7be0:	9114c283 	add	x3, x20, #0x530
    7be4:	aa0003f5 	mov	x21, x0
    7be8:	f949d861 	ldr	x1, [x3, #5040]
    7bec:	f949ec60 	ldr	x0, [x3, #5080]
    7bf0:	cb0102a1 	sub	x1, x21, x1
    7bf4:	eb00403f 	cmp	x1, x0, lsl #16
    7bf8:	54000322 	b.cs	7c5c <f0+0xb68>  // b.hs, b.nlast
    7bfc:	d350fc22 	lsr	x2, x1, #16
    7c00:	f949fc63 	ldr	x3, [x3, #5112]
    7c04:	8b020842 	add	x2, x2, x2, lsl #2
    7c08:	d37df042 	lsl	x2, x2, #3
    7c0c:	8b020060 	add	x0, x3, x2
    7c10:	f9401017 	ldr	x23, [x0, #32]
    7c14:	b4000257 	cbz	x23, 7c5c <f0+0xb68>
    7c18:	38626862 	ldrb	w2, [x3, x2]
    7c1c:	7100085f 	cmp	w2, #0x2
    7c20:	5400c440 	b.eq	94a8 <f0+0x23b4>  // b.none
    7c24:	7100045f 	cmp	w2, #0x1
    7c28:	540001a1 	b.ne	7c5c <f0+0xb68>  // b.any
    7c2c:	29430002 	ldp	w2, w0, [x0, #24]
    7c30:	92403c21 	and	x1, x1, #0xffff
    7c34:	9b027c21 	mul	x1, x1, x2
    7c38:	d360fc21 	lsr	x1, x1, #32
    7c3c:	eb00003f 	cmp	x1, x0
    7c40:	540000e2 	b.cs	7c5c <f0+0xb68>  // b.hs, b.nlast
    7c44:	8b0102f7 	add	x23, x23, x1
    7c48:	394002e0 	ldrb	w0, [x23]
    7c4c:	7103fc1f 	cmp	w0, #0xff
    7c50:	5400ce60 	b.eq	961c <f0+0x2528>  // b.none
    7c54:	52800020 	mov	w0, #0x1                   	// #1
    7c58:	390002e0 	strb	w0, [x23]
    7c5c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    7c60:	910ca3e1 	add	x1, sp, #0x328
    7c64:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    7c68:	52800020 	mov	w0, #0x1                   	// #1
    7c6c:	f90197e2 	str	x2, [sp, #808]
    7c70:	f9019bf5 	str	x21, [sp, #816]
    7c74:	97fff0ab 	bl	3f20 <fwp_data.part.0.constprop.0>
    7c78:	9114c283 	add	x3, x20, #0x530
    7c7c:	aa0003f5 	mov	x21, x0
    7c80:	f949d861 	ldr	x1, [x3, #5040]
    7c84:	f949ec60 	ldr	x0, [x3, #5080]
    7c88:	cb0102a1 	sub	x1, x21, x1
    7c8c:	eb00403f 	cmp	x1, x0, lsl #16
    7c90:	54000322 	b.cs	7cf4 <f0+0xc00>  // b.hs, b.nlast
    7c94:	d350fc22 	lsr	x2, x1, #16
    7c98:	f949fc63 	ldr	x3, [x3, #5112]
    7c9c:	8b020842 	add	x2, x2, x2, lsl #2
    7ca0:	d37df042 	lsl	x2, x2, #3
    7ca4:	8b020060 	add	x0, x3, x2
    7ca8:	f9401017 	ldr	x23, [x0, #32]
    7cac:	b4000257 	cbz	x23, 7cf4 <f0+0xc00>
    7cb0:	38626862 	ldrb	w2, [x3, x2]
    7cb4:	7100085f 	cmp	w2, #0x2
    7cb8:	5400bf20 	b.eq	949c <f0+0x23a8>  // b.none
    7cbc:	7100045f 	cmp	w2, #0x1
    7cc0:	540001a1 	b.ne	7cf4 <f0+0xc00>  // b.any
    7cc4:	29430002 	ldp	w2, w0, [x0, #24]
    7cc8:	92403c21 	and	x1, x1, #0xffff
    7ccc:	9b027c21 	mul	x1, x1, x2
    7cd0:	d360fc21 	lsr	x1, x1, #32
    7cd4:	eb00003f 	cmp	x1, x0
    7cd8:	540000e2 	b.cs	7cf4 <f0+0xc00>  // b.hs, b.nlast
    7cdc:	8b0102f7 	add	x23, x23, x1
    7ce0:	394002e0 	ldrb	w0, [x23]
    7ce4:	7103fc1f 	cmp	w0, #0xff
    7ce8:	5400ca00 	b.eq	9628 <f0+0x2534>  // b.none
    7cec:	52800020 	mov	w0, #0x1                   	// #1
    7cf0:	390002e0 	strb	w0, [x23]
    7cf4:	910ce3e1 	add	x1, sp, #0x338
    7cf8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    7cfc:	52800020 	mov	w0, #0x1                   	// #1
    7d00:	f9019ff7 	str	x23, [sp, #824]
    7d04:	f901a3f5 	str	x21, [sp, #832]
    7d08:	97fff086 	bl	3f20 <fwp_data.part.0.constprop.0>
    7d0c:	97ffee95 	bl	3760 <fwp_rc_fresh>
    7d10:	aa0003e2 	mov	x2, x0
    7d14:	910d23e1 	add	x1, sp, #0x348
    7d18:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    7d1c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    7d20:	52800020 	mov	w0, #0x1                   	// #1
    7d24:	f901a7f5 	str	x21, [sp, #840]
    7d28:	f901abe2 	str	x2, [sp, #848]
    7d2c:	97fff07d 	bl	3f20 <fwp_data.part.0.constprop.0>
    7d30:	97ffee8c 	bl	3760 <fwp_rc_fresh>
    7d34:	aa0003e2 	mov	x2, x0
    7d38:	910d63e1 	add	x1, sp, #0x358
    7d3c:	52800020 	mov	w0, #0x1                   	// #1
    7d40:	f901aff7 	str	x23, [sp, #856]
    7d44:	f901b3e2 	str	x2, [sp, #864]
    7d48:	97fff076 	bl	3f20 <fwp_data.part.0.constprop.0>
    7d4c:	97ffee85 	bl	3760 <fwp_rc_fresh>
    7d50:	aa0003e2 	mov	x2, x0
    7d54:	910da3e1 	add	x1, sp, #0x368
    7d58:	52800020 	mov	w0, #0x1                   	// #1
    7d5c:	f901b7f5 	str	x21, [sp, #872]
    7d60:	f901bbe2 	str	x2, [sp, #880]
    7d64:	97fff06f 	bl	3f20 <fwp_data.part.0.constprop.0>
    7d68:	9114c283 	add	x3, x20, #0x530
    7d6c:	aa0003f7 	mov	x23, x0
    7d70:	f949d861 	ldr	x1, [x3, #5040]
    7d74:	f949ec60 	ldr	x0, [x3, #5080]
    7d78:	cb0102e1 	sub	x1, x23, x1
    7d7c:	eb00403f 	cmp	x1, x0, lsl #16
    7d80:	54000322 	b.cs	7de4 <f0+0xcf0>  // b.hs, b.nlast
    7d84:	d350fc22 	lsr	x2, x1, #16
    7d88:	f949fc63 	ldr	x3, [x3, #5112]
    7d8c:	8b020842 	add	x2, x2, x2, lsl #2
    7d90:	d37df042 	lsl	x2, x2, #3
    7d94:	8b020060 	add	x0, x3, x2
    7d98:	f9401015 	ldr	x21, [x0, #32]
    7d9c:	b4000255 	cbz	x21, 7de4 <f0+0xcf0>
    7da0:	38626862 	ldrb	w2, [x3, x2]
    7da4:	7100085f 	cmp	w2, #0x2
    7da8:	5400b740 	b.eq	9490 <f0+0x239c>  // b.none
    7dac:	7100045f 	cmp	w2, #0x1
    7db0:	540001a1 	b.ne	7de4 <f0+0xcf0>  // b.any
    7db4:	29430002 	ldp	w2, w0, [x0, #24]
    7db8:	92403c21 	and	x1, x1, #0xffff
    7dbc:	9b027c21 	mul	x1, x1, x2
    7dc0:	d360fc21 	lsr	x1, x1, #32
    7dc4:	eb00003f 	cmp	x1, x0
    7dc8:	540000e2 	b.cs	7de4 <f0+0xcf0>  // b.hs, b.nlast
    7dcc:	8b0102b5 	add	x21, x21, x1
    7dd0:	394002a0 	ldrb	w0, [x21]
    7dd4:	7103fc1f 	cmp	w0, #0xff
    7dd8:	5400c2e0 	b.eq	9634 <f0+0x2540>  // b.none
    7ddc:	52800020 	mov	w0, #0x1                   	// #1
    7de0:	390002a0 	strb	w0, [x21]
    7de4:	910de3e1 	add	x1, sp, #0x378
    7de8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7dec:	52800020 	mov	w0, #0x1                   	// #1
    7df0:	f901bff5 	str	x21, [sp, #888]
    7df4:	f901c3f7 	str	x23, [sp, #896]
    7df8:	97fff04a 	bl	3f20 <fwp_data.part.0.constprop.0>
    7dfc:	97ffee59 	bl	3760 <fwp_rc_fresh>
    7e00:	aa0003e2 	mov	x2, x0
    7e04:	910e23e1 	add	x1, sp, #0x388
    7e08:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7e0c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7e10:	52800020 	mov	w0, #0x1                   	// #1
    7e14:	f901c7f7 	str	x23, [sp, #904]
    7e18:	f901cbe2 	str	x2, [sp, #912]
    7e1c:	97fff041 	bl	3f20 <fwp_data.part.0.constprop.0>
    7e20:	97ffee50 	bl	3760 <fwp_rc_fresh>
    7e24:	aa0003e2 	mov	x2, x0
    7e28:	910e63e1 	add	x1, sp, #0x398
    7e2c:	52800020 	mov	w0, #0x1                   	// #1
    7e30:	f901cff5 	str	x21, [sp, #920]
    7e34:	f901d3e2 	str	x2, [sp, #928]
    7e38:	97fff03a 	bl	3f20 <fwp_data.part.0.constprop.0>
    7e3c:	97ffee49 	bl	3760 <fwp_rc_fresh>
    7e40:	aa0003e2 	mov	x2, x0
    7e44:	910ea3e1 	add	x1, sp, #0x3a8
    7e48:	52800020 	mov	w0, #0x1                   	// #1
    7e4c:	f901d7f7 	str	x23, [sp, #936]
    7e50:	f901dbe2 	str	x2, [sp, #944]
    7e54:	97fff033 	bl	3f20 <fwp_data.part.0.constprop.0>
    7e58:	97ffee42 	bl	3760 <fwp_rc_fresh>
    7e5c:	aa0003e2 	mov	x2, x0
    7e60:	910ee3e1 	add	x1, sp, #0x3b8
    7e64:	52800020 	mov	w0, #0x1                   	// #1
    7e68:	f901dff5 	str	x21, [sp, #952]
    7e6c:	f901e3e2 	str	x2, [sp, #960]
    7e70:	97fff02c 	bl	3f20 <fwp_data.part.0.constprop.0>
    7e74:	97ffee3b 	bl	3760 <fwp_rc_fresh>
    7e78:	aa0003e2 	mov	x2, x0
    7e7c:	910f23e1 	add	x1, sp, #0x3c8
    7e80:	52800020 	mov	w0, #0x1                   	// #1
    7e84:	f901e7f7 	str	x23, [sp, #968]
    7e88:	f901ebe2 	str	x2, [sp, #976]
    7e8c:	97fff025 	bl	3f20 <fwp_data.part.0.constprop.0>
    7e90:	97ffee34 	bl	3760 <fwp_rc_fresh>
    7e94:	aa0003e2 	mov	x2, x0
    7e98:	910f63e1 	add	x1, sp, #0x3d8
    7e9c:	52800020 	mov	w0, #0x1                   	// #1
    7ea0:	f901eff5 	str	x21, [sp, #984]
    7ea4:	f901f3e2 	str	x2, [sp, #992]
    7ea8:	97fff01e 	bl	3f20 <fwp_data.part.0.constprop.0>
    7eac:	9114c283 	add	x3, x20, #0x530
    7eb0:	aa0003f5 	mov	x21, x0
    7eb4:	f949d861 	ldr	x1, [x3, #5040]
    7eb8:	f949ec60 	ldr	x0, [x3, #5080]
    7ebc:	cb0102a1 	sub	x1, x21, x1
    7ec0:	eb00403f 	cmp	x1, x0, lsl #16
    7ec4:	54000322 	b.cs	7f28 <f0+0xe34>  // b.hs, b.nlast
    7ec8:	d350fc22 	lsr	x2, x1, #16
    7ecc:	f949fc63 	ldr	x3, [x3, #5112]
    7ed0:	8b020842 	add	x2, x2, x2, lsl #2
    7ed4:	d37df042 	lsl	x2, x2, #3
    7ed8:	8b020060 	add	x0, x3, x2
    7edc:	f9401017 	ldr	x23, [x0, #32]
    7ee0:	b4000257 	cbz	x23, 7f28 <f0+0xe34>
    7ee4:	38626862 	ldrb	w2, [x3, x2]
    7ee8:	7100085f 	cmp	w2, #0x2
    7eec:	5400acc0 	b.eq	9484 <f0+0x2390>  // b.none
    7ef0:	7100045f 	cmp	w2, #0x1
    7ef4:	540001a1 	b.ne	7f28 <f0+0xe34>  // b.any
    7ef8:	29430002 	ldp	w2, w0, [x0, #24]
    7efc:	92403c21 	and	x1, x1, #0xffff
    7f00:	9b027c21 	mul	x1, x1, x2
    7f04:	d360fc21 	lsr	x1, x1, #32
    7f08:	eb00003f 	cmp	x1, x0
    7f0c:	540000e2 	b.cs	7f28 <f0+0xe34>  // b.hs, b.nlast
    7f10:	8b0102f7 	add	x23, x23, x1
    7f14:	394002e0 	ldrb	w0, [x23]
    7f18:	7103fc1f 	cmp	w0, #0xff
    7f1c:	5400b920 	b.eq	9640 <f0+0x254c>  // b.none
    7f20:	52800020 	mov	w0, #0x1                   	// #1
    7f24:	390002e0 	strb	w0, [x23]
    7f28:	910fa3e1 	add	x1, sp, #0x3e8
    7f2c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    7f30:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    7f34:	52800020 	mov	w0, #0x1                   	// #1
    7f38:	f901f7f7 	str	x23, [sp, #1000]
    7f3c:	f901fbf5 	str	x21, [sp, #1008]
    7f40:	97ffeff8 	bl	3f20 <fwp_data.part.0.constprop.0>
    7f44:	97ffee07 	bl	3760 <fwp_rc_fresh>
    7f48:	aa0003e2 	mov	x2, x0
    7f4c:	910fe3e1 	add	x1, sp, #0x3f8
    7f50:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    7f54:	52800020 	mov	w0, #0x1                   	// #1
    7f58:	f901fff5 	str	x21, [sp, #1016]
    7f5c:	f90203e2 	str	x2, [sp, #1024]
    7f60:	97ffeff0 	bl	3f20 <fwp_data.part.0.constprop.0>
    7f64:	97ffedff 	bl	3760 <fwp_rc_fresh>
    7f68:	aa0003e2 	mov	x2, x0
    7f6c:	911023e1 	add	x1, sp, #0x408
    7f70:	52800020 	mov	w0, #0x1                   	// #1
    7f74:	f90207f7 	str	x23, [sp, #1032]
    7f78:	f9020be2 	str	x2, [sp, #1040]
    7f7c:	97ffefe9 	bl	3f20 <fwp_data.part.0.constprop.0>
    7f80:	97ffedf8 	bl	3760 <fwp_rc_fresh>
    7f84:	aa0003e2 	mov	x2, x0
    7f88:	911063e1 	add	x1, sp, #0x418
    7f8c:	52800020 	mov	w0, #0x1                   	// #1
    7f90:	f9020ff5 	str	x21, [sp, #1048]
    7f94:	f90213e2 	str	x2, [sp, #1056]
    7f98:	97ffefe2 	bl	3f20 <fwp_data.part.0.constprop.0>
    7f9c:	97ffedf1 	bl	3760 <fwp_rc_fresh>
    7fa0:	aa0003e2 	mov	x2, x0
    7fa4:	9110a3e1 	add	x1, sp, #0x428
    7fa8:	52800020 	mov	w0, #0x1                   	// #1
    7fac:	f90217f7 	str	x23, [sp, #1064]
    7fb0:	f9021be2 	str	x2, [sp, #1072]
    7fb4:	97ffefdb 	bl	3f20 <fwp_data.part.0.constprop.0>
    7fb8:	97ffedea 	bl	3760 <fwp_rc_fresh>
    7fbc:	aa0003e2 	mov	x2, x0
    7fc0:	9110e3e1 	add	x1, sp, #0x438
    7fc4:	52800020 	mov	w0, #0x1                   	// #1
    7fc8:	f9021ff5 	str	x21, [sp, #1080]
    7fcc:	f90223e2 	str	x2, [sp, #1088]
    7fd0:	97ffefd4 	bl	3f20 <fwp_data.part.0.constprop.0>
    7fd4:	97ffede3 	bl	3760 <fwp_rc_fresh>
    7fd8:	aa0003e2 	mov	x2, x0
    7fdc:	911123e1 	add	x1, sp, #0x448
    7fe0:	52800020 	mov	w0, #0x1                   	// #1
    7fe4:	f90227f7 	str	x23, [sp, #1096]
    7fe8:	f9022be2 	str	x2, [sp, #1104]
    7fec:	97ffefcd 	bl	3f20 <fwp_data.part.0.constprop.0>
    7ff0:	97ffeddc 	bl	3760 <fwp_rc_fresh>
    7ff4:	aa0003e2 	mov	x2, x0
    7ff8:	911163e1 	add	x1, sp, #0x458
    7ffc:	52800020 	mov	w0, #0x1                   	// #1
    8000:	f9022ff5 	str	x21, [sp, #1112]
    8004:	f90233e2 	str	x2, [sp, #1120]
    8008:	97ffefc6 	bl	3f20 <fwp_data.part.0.constprop.0>
    800c:	9114c283 	add	x3, x20, #0x530
    8010:	aa0003f5 	mov	x21, x0
    8014:	f949d861 	ldr	x1, [x3, #5040]
    8018:	f949ec60 	ldr	x0, [x3, #5080]
    801c:	cb0102a1 	sub	x1, x21, x1
    8020:	eb00403f 	cmp	x1, x0, lsl #16
    8024:	54000322 	b.cs	8088 <f0+0xf94>  // b.hs, b.nlast
    8028:	d350fc22 	lsr	x2, x1, #16
    802c:	f949fc63 	ldr	x3, [x3, #5112]
    8030:	8b020842 	add	x2, x2, x2, lsl #2
    8034:	d37df042 	lsl	x2, x2, #3
    8038:	8b020060 	add	x0, x3, x2
    803c:	f9401017 	ldr	x23, [x0, #32]
    8040:	b4000257 	cbz	x23, 8088 <f0+0xf94>
    8044:	38626862 	ldrb	w2, [x3, x2]
    8048:	7100085f 	cmp	w2, #0x2
    804c:	5400a160 	b.eq	9478 <f0+0x2384>  // b.none
    8050:	7100045f 	cmp	w2, #0x1
    8054:	540001a1 	b.ne	8088 <f0+0xf94>  // b.any
    8058:	29430002 	ldp	w2, w0, [x0, #24]
    805c:	92403c21 	and	x1, x1, #0xffff
    8060:	9b027c21 	mul	x1, x1, x2
    8064:	d360fc21 	lsr	x1, x1, #32
    8068:	eb00003f 	cmp	x1, x0
    806c:	540000e2 	b.cs	8088 <f0+0xf94>  // b.hs, b.nlast
    8070:	8b0102f7 	add	x23, x23, x1
    8074:	394002e0 	ldrb	w0, [x23]
    8078:	7103fc1f 	cmp	w0, #0xff
    807c:	5400ae80 	b.eq	964c <f0+0x2558>  // b.none
    8080:	52800020 	mov	w0, #0x1                   	// #1
    8084:	390002e0 	strb	w0, [x23]
    8088:	9111a3e1 	add	x1, sp, #0x468
    808c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    8090:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    8094:	52800020 	mov	w0, #0x1                   	// #1
    8098:	f90237f7 	str	x23, [sp, #1128]
    809c:	f9023bf5 	str	x21, [sp, #1136]
    80a0:	97ffefa0 	bl	3f20 <fwp_data.part.0.constprop.0>
    80a4:	97ffedaf 	bl	3760 <fwp_rc_fresh>
    80a8:	aa0003e2 	mov	x2, x0
    80ac:	9111e3e1 	add	x1, sp, #0x478
    80b0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    80b4:	52800020 	mov	w0, #0x1                   	// #1
    80b8:	f9023ff5 	str	x21, [sp, #1144]
    80bc:	f90243e2 	str	x2, [sp, #1152]
    80c0:	97ffef98 	bl	3f20 <fwp_data.part.0.constprop.0>
    80c4:	97ffeda7 	bl	3760 <fwp_rc_fresh>
    80c8:	aa0003e2 	mov	x2, x0
    80cc:	911223e1 	add	x1, sp, #0x488
    80d0:	52800020 	mov	w0, #0x1                   	// #1
    80d4:	f90247f7 	str	x23, [sp, #1160]
    80d8:	f9024be2 	str	x2, [sp, #1168]
    80dc:	97ffef91 	bl	3f20 <fwp_data.part.0.constprop.0>
    80e0:	97ffeda0 	bl	3760 <fwp_rc_fresh>
    80e4:	aa0003e2 	mov	x2, x0
    80e8:	911263e1 	add	x1, sp, #0x498
    80ec:	52800020 	mov	w0, #0x1                   	// #1
    80f0:	f9024ff5 	str	x21, [sp, #1176]
    80f4:	f90253e2 	str	x2, [sp, #1184]
    80f8:	97ffef8a 	bl	3f20 <fwp_data.part.0.constprop.0>
    80fc:	97ffed99 	bl	3760 <fwp_rc_fresh>
    8100:	aa0003e2 	mov	x2, x0
    8104:	9112a3e1 	add	x1, sp, #0x4a8
    8108:	52800020 	mov	w0, #0x1                   	// #1
    810c:	f90257f7 	str	x23, [sp, #1192]
    8110:	f9025be2 	str	x2, [sp, #1200]
    8114:	97ffef83 	bl	3f20 <fwp_data.part.0.constprop.0>
    8118:	97ffed92 	bl	3760 <fwp_rc_fresh>
    811c:	aa0003e2 	mov	x2, x0
    8120:	9112e3e1 	add	x1, sp, #0x4b8
    8124:	52800020 	mov	w0, #0x1                   	// #1
    8128:	f9025ff5 	str	x21, [sp, #1208]
    812c:	f90263e2 	str	x2, [sp, #1216]
    8130:	97ffef7c 	bl	3f20 <fwp_data.part.0.constprop.0>
    8134:	97ffed8b 	bl	3760 <fwp_rc_fresh>
    8138:	aa0003e2 	mov	x2, x0
    813c:	911323e1 	add	x1, sp, #0x4c8
    8140:	52800020 	mov	w0, #0x1                   	// #1
    8144:	f90267f7 	str	x23, [sp, #1224]
    8148:	f9026be2 	str	x2, [sp, #1232]
    814c:	97ffef75 	bl	3f20 <fwp_data.part.0.constprop.0>
    8150:	97ffed84 	bl	3760 <fwp_rc_fresh>
    8154:	aa0003e2 	mov	x2, x0
    8158:	911363e1 	add	x1, sp, #0x4d8
    815c:	52800020 	mov	w0, #0x1                   	// #1
    8160:	f9026ff5 	str	x21, [sp, #1240]
    8164:	f90273e2 	str	x2, [sp, #1248]
    8168:	97ffef6e 	bl	3f20 <fwp_data.part.0.constprop.0>
    816c:	9114c283 	add	x3, x20, #0x530
    8170:	aa0003f5 	mov	x21, x0
    8174:	f949d861 	ldr	x1, [x3, #5040]
    8178:	f949ec60 	ldr	x0, [x3, #5080]
    817c:	cb0102a1 	sub	x1, x21, x1
    8180:	eb00403f 	cmp	x1, x0, lsl #16
    8184:	54000322 	b.cs	81e8 <f0+0x10f4>  // b.hs, b.nlast
    8188:	d350fc22 	lsr	x2, x1, #16
    818c:	f949fc63 	ldr	x3, [x3, #5112]
    8190:	8b020842 	add	x2, x2, x2, lsl #2
    8194:	d37df042 	lsl	x2, x2, #3
    8198:	8b020060 	add	x0, x3, x2
    819c:	f9401017 	ldr	x23, [x0, #32]
    81a0:	b4000257 	cbz	x23, 81e8 <f0+0x10f4>
    81a4:	38626862 	ldrb	w2, [x3, x2]
    81a8:	7100085f 	cmp	w2, #0x2
    81ac:	54009360 	b.eq	9418 <f0+0x2324>  // b.none
    81b0:	7100045f 	cmp	w2, #0x1
    81b4:	540001a1 	b.ne	81e8 <f0+0x10f4>  // b.any
    81b8:	29430002 	ldp	w2, w0, [x0, #24]
    81bc:	92403c21 	and	x1, x1, #0xffff
    81c0:	9b027c21 	mul	x1, x1, x2
    81c4:	d360fc21 	lsr	x1, x1, #32
    81c8:	eb00003f 	cmp	x1, x0
    81cc:	540000e2 	b.cs	81e8 <f0+0x10f4>  // b.hs, b.nlast
    81d0:	8b0102f7 	add	x23, x23, x1
    81d4:	394002e0 	ldrb	w0, [x23]
    81d8:	7103fc1f 	cmp	w0, #0xff
    81dc:	5400a3e0 	b.eq	9658 <f0+0x2564>  // b.none
    81e0:	52800020 	mov	w0, #0x1                   	// #1
    81e4:	390002e0 	strb	w0, [x23]
    81e8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    81ec:	9113a3e1 	add	x1, sp, #0x4e8
    81f0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    81f4:	52800020 	mov	w0, #0x1                   	// #1
    81f8:	f90277e2 	str	x2, [sp, #1256]
    81fc:	f9027bf5 	str	x21, [sp, #1264]
    8200:	97ffef48 	bl	3f20 <fwp_data.part.0.constprop.0>
    8204:	9114c283 	add	x3, x20, #0x530
    8208:	aa0003f5 	mov	x21, x0
    820c:	f949d861 	ldr	x1, [x3, #5040]
    8210:	f949ec60 	ldr	x0, [x3, #5080]
    8214:	cb0102a1 	sub	x1, x21, x1
    8218:	eb00403f 	cmp	x1, x0, lsl #16
    821c:	54000322 	b.cs	8280 <f0+0x118c>  // b.hs, b.nlast
    8220:	d350fc22 	lsr	x2, x1, #16
    8224:	f949fc63 	ldr	x3, [x3, #5112]
    8228:	8b020842 	add	x2, x2, x2, lsl #2
    822c:	d37df042 	lsl	x2, x2, #3
    8230:	8b020060 	add	x0, x3, x2
    8234:	f9401017 	ldr	x23, [x0, #32]
    8238:	b4000257 	cbz	x23, 8280 <f0+0x118c>
    823c:	38626862 	ldrb	w2, [x3, x2]
    8240:	7100085f 	cmp	w2, #0x2
    8244:	54008e40 	b.eq	940c <f0+0x2318>  // b.none
    8248:	7100045f 	cmp	w2, #0x1
    824c:	540001a1 	b.ne	8280 <f0+0x118c>  // b.any
    8250:	29430002 	ldp	w2, w0, [x0, #24]
    8254:	92403c21 	and	x1, x1, #0xffff
    8258:	9b027c21 	mul	x1, x1, x2
    825c:	d360fc21 	lsr	x1, x1, #32
    8260:	eb00003f 	cmp	x1, x0
    8264:	540000e2 	b.cs	8280 <f0+0x118c>  // b.hs, b.nlast
    8268:	8b0102f7 	add	x23, x23, x1
    826c:	394002e0 	ldrb	w0, [x23]
    8270:	7103fc1f 	cmp	w0, #0xff
    8274:	54009f80 	b.eq	9664 <f0+0x2570>  // b.none
    8278:	52800020 	mov	w0, #0x1                   	// #1
    827c:	390002e0 	strb	w0, [x23]
    8280:	9113e3e1 	add	x1, sp, #0x4f8
    8284:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    8288:	52800020 	mov	w0, #0x1                   	// #1
    828c:	f9027ff7 	str	x23, [sp, #1272]
    8290:	f90283f5 	str	x21, [sp, #1280]
    8294:	97ffef23 	bl	3f20 <fwp_data.part.0.constprop.0>
    8298:	97ffed32 	bl	3760 <fwp_rc_fresh>
    829c:	aa0003e2 	mov	x2, x0
    82a0:	911423e1 	add	x1, sp, #0x508
    82a4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    82a8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    82ac:	52800020 	mov	w0, #0x1                   	// #1
    82b0:	f90287f5 	str	x21, [sp, #1288]
    82b4:	f9028be2 	str	x2, [sp, #1296]
    82b8:	97ffef1a 	bl	3f20 <fwp_data.part.0.constprop.0>
    82bc:	97ffed29 	bl	3760 <fwp_rc_fresh>
    82c0:	aa0003e2 	mov	x2, x0
    82c4:	911463e1 	add	x1, sp, #0x518
    82c8:	52800020 	mov	w0, #0x1                   	// #1
    82cc:	f9028ff7 	str	x23, [sp, #1304]
    82d0:	f90293e2 	str	x2, [sp, #1312]
    82d4:	97ffef13 	bl	3f20 <fwp_data.part.0.constprop.0>
    82d8:	97ffed22 	bl	3760 <fwp_rc_fresh>
    82dc:	aa0003e2 	mov	x2, x0
    82e0:	9114a3e1 	add	x1, sp, #0x528
    82e4:	52800020 	mov	w0, #0x1                   	// #1
    82e8:	f90297f5 	str	x21, [sp, #1320]
    82ec:	f9029be2 	str	x2, [sp, #1328]
    82f0:	97ffef0c 	bl	3f20 <fwp_data.part.0.constprop.0>
    82f4:	9114c283 	add	x3, x20, #0x530
    82f8:	aa0003f5 	mov	x21, x0
    82fc:	f949d861 	ldr	x1, [x3, #5040]
    8300:	f949ec60 	ldr	x0, [x3, #5080]
    8304:	cb0102a1 	sub	x1, x21, x1
    8308:	eb00403f 	cmp	x1, x0, lsl #16
    830c:	54000322 	b.cs	8370 <f0+0x127c>  // b.hs, b.nlast
    8310:	d350fc22 	lsr	x2, x1, #16
    8314:	f949fc63 	ldr	x3, [x3, #5112]
    8318:	8b020842 	add	x2, x2, x2, lsl #2
    831c:	d37df042 	lsl	x2, x2, #3
    8320:	8b020060 	add	x0, x3, x2
    8324:	f9401017 	ldr	x23, [x0, #32]
    8328:	b4000257 	cbz	x23, 8370 <f0+0x127c>
    832c:	38626862 	ldrb	w2, [x3, x2]
    8330:	7100085f 	cmp	w2, #0x2
    8334:	54008660 	b.eq	9400 <f0+0x230c>  // b.none
    8338:	7100045f 	cmp	w2, #0x1
    833c:	540001a1 	b.ne	8370 <f0+0x127c>  // b.any
    8340:	29430002 	ldp	w2, w0, [x0, #24]
    8344:	92403c21 	and	x1, x1, #0xffff
    8348:	9b027c21 	mul	x1, x1, x2
    834c:	d360fc21 	lsr	x1, x1, #32
    8350:	eb00003f 	cmp	x1, x0
    8354:	540000e2 	b.cs	8370 <f0+0x127c>  // b.hs, b.nlast
    8358:	8b0102f7 	add	x23, x23, x1
    835c:	394002e0 	ldrb	w0, [x23]
    8360:	7103fc1f 	cmp	w0, #0xff
    8364:	54009860 	b.eq	9670 <f0+0x257c>  // b.none
    8368:	52800020 	mov	w0, #0x1                   	// #1
    836c:	390002e0 	strb	w0, [x23]
    8370:	9114e3e1 	add	x1, sp, #0x538
    8374:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    8378:	52800020 	mov	w0, #0x1                   	// #1
    837c:	f9029ff7 	str	x23, [sp, #1336]
    8380:	f902a3f5 	str	x21, [sp, #1344]
    8384:	97ffeee7 	bl	3f20 <fwp_data.part.0.constprop.0>
    8388:	97ffecf6 	bl	3760 <fwp_rc_fresh>
    838c:	aa0003e2 	mov	x2, x0
    8390:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8394:	911523e1 	add	x1, sp, #0x548
    8398:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    839c:	52800020 	mov	w0, #0x1                   	// #1
    83a0:	f902a7e3 	str	x3, [sp, #1352]
    83a4:	f902abe2 	str	x2, [sp, #1360]
    83a8:	97ffeede 	bl	3f20 <fwp_data.part.0.constprop.0>
    83ac:	97ffeced 	bl	3760 <fwp_rc_fresh>
    83b0:	aa0003e2 	mov	x2, x0
    83b4:	911563e1 	add	x1, sp, #0x558
    83b8:	52800020 	mov	w0, #0x1                   	// #1
    83bc:	f902aff7 	str	x23, [sp, #1368]
    83c0:	f902b3e2 	str	x2, [sp, #1376]
    83c4:	97ffeed7 	bl	3f20 <fwp_data.part.0.constprop.0>
    83c8:	9114c283 	add	x3, x20, #0x530
    83cc:	aa0003f5 	mov	x21, x0
    83d0:	f949d861 	ldr	x1, [x3, #5040]
    83d4:	f949ec60 	ldr	x0, [x3, #5080]
    83d8:	cb0102a1 	sub	x1, x21, x1
    83dc:	eb00403f 	cmp	x1, x0, lsl #16
    83e0:	54000322 	b.cs	8444 <f0+0x1350>  // b.hs, b.nlast
    83e4:	d350fc22 	lsr	x2, x1, #16
    83e8:	f949fc63 	ldr	x3, [x3, #5112]
    83ec:	8b020842 	add	x2, x2, x2, lsl #2
    83f0:	d37df042 	lsl	x2, x2, #3
    83f4:	8b020060 	add	x0, x3, x2
    83f8:	f9401017 	ldr	x23, [x0, #32]
    83fc:	b4000257 	cbz	x23, 8444 <f0+0x1350>
    8400:	38626862 	ldrb	w2, [x3, x2]
    8404:	7100085f 	cmp	w2, #0x2
    8408:	54007f60 	b.eq	93f4 <f0+0x2300>  // b.none
    840c:	7100045f 	cmp	w2, #0x1
    8410:	540001a1 	b.ne	8444 <f0+0x1350>  // b.any
    8414:	29430002 	ldp	w2, w0, [x0, #24]
    8418:	92403c21 	and	x1, x1, #0xffff
    841c:	9b027c21 	mul	x1, x1, x2
    8420:	d360fc21 	lsr	x1, x1, #32
    8424:	eb00003f 	cmp	x1, x0
    8428:	540000e2 	b.cs	8444 <f0+0x1350>  // b.hs, b.nlast
    842c:	8b0102f7 	add	x23, x23, x1
    8430:	394002e0 	ldrb	w0, [x23]
    8434:	7103fc1f 	cmp	w0, #0xff
    8438:	54009220 	b.eq	967c <f0+0x2588>  // b.none
    843c:	52800020 	mov	w0, #0x1                   	// #1
    8440:	390002e0 	strb	w0, [x23]
    8444:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8448:	9115a3e1 	add	x1, sp, #0x568
    844c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8450:	52800020 	mov	w0, #0x1                   	// #1
    8454:	f902b7e2 	str	x2, [sp, #1384]
    8458:	f902bbf5 	str	x21, [sp, #1392]
    845c:	97ffeeb1 	bl	3f20 <fwp_data.part.0.constprop.0>
    8460:	9114c283 	add	x3, x20, #0x530
    8464:	aa0003f5 	mov	x21, x0
    8468:	f949d861 	ldr	x1, [x3, #5040]
    846c:	f949ec60 	ldr	x0, [x3, #5080]
    8470:	cb0102a1 	sub	x1, x21, x1
    8474:	eb00403f 	cmp	x1, x0, lsl #16
    8478:	54000322 	b.cs	84dc <f0+0x13e8>  // b.hs, b.nlast
    847c:	d350fc22 	lsr	x2, x1, #16
    8480:	f949fc63 	ldr	x3, [x3, #5112]
    8484:	8b020842 	add	x2, x2, x2, lsl #2
    8488:	d37df042 	lsl	x2, x2, #3
    848c:	8b020060 	add	x0, x3, x2
    8490:	f9401017 	ldr	x23, [x0, #32]
    8494:	b4000257 	cbz	x23, 84dc <f0+0x13e8>
    8498:	38626862 	ldrb	w2, [x3, x2]
    849c:	7100085f 	cmp	w2, #0x2
    84a0:	54007a40 	b.eq	93e8 <f0+0x22f4>  // b.none
    84a4:	7100045f 	cmp	w2, #0x1
    84a8:	540001a1 	b.ne	84dc <f0+0x13e8>  // b.any
    84ac:	29430002 	ldp	w2, w0, [x0, #24]
    84b0:	92403c21 	and	x1, x1, #0xffff
    84b4:	9b027c21 	mul	x1, x1, x2
    84b8:	d360fc21 	lsr	x1, x1, #32
    84bc:	eb00003f 	cmp	x1, x0
    84c0:	540000e2 	b.cs	84dc <f0+0x13e8>  // b.hs, b.nlast
    84c4:	8b0102f7 	add	x23, x23, x1
    84c8:	394002e0 	ldrb	w0, [x23]
    84cc:	7103fc1f 	cmp	w0, #0xff
    84d0:	54008dc0 	b.eq	9688 <f0+0x2594>  // b.none
    84d4:	52800020 	mov	w0, #0x1                   	// #1
    84d8:	390002e0 	strb	w0, [x23]
    84dc:	9115e3e1 	add	x1, sp, #0x578
    84e0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    84e4:	52800020 	mov	w0, #0x1                   	// #1
    84e8:	f902bff7 	str	x23, [sp, #1400]
    84ec:	f902c3f5 	str	x21, [sp, #1408]
    84f0:	97ffee8c 	bl	3f20 <fwp_data.part.0.constprop.0>
    84f4:	97ffec9b 	bl	3760 <fwp_rc_fresh>
    84f8:	aa0003e2 	mov	x2, x0
    84fc:	911623e1 	add	x1, sp, #0x588
    8500:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    8504:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    8508:	52800020 	mov	w0, #0x1                   	// #1
    850c:	f902c7f5 	str	x21, [sp, #1416]
    8510:	f902cbe2 	str	x2, [sp, #1424]
    8514:	97ffee83 	bl	3f20 <fwp_data.part.0.constprop.0>
    8518:	97ffec92 	bl	3760 <fwp_rc_fresh>
    851c:	aa0003e2 	mov	x2, x0
    8520:	911663e1 	add	x1, sp, #0x598
    8524:	52800020 	mov	w0, #0x1                   	// #1
    8528:	f902cff7 	str	x23, [sp, #1432]
    852c:	f902d3e2 	str	x2, [sp, #1440]
    8530:	97ffee7c 	bl	3f20 <fwp_data.part.0.constprop.0>
    8534:	97ffec8b 	bl	3760 <fwp_rc_fresh>
    8538:	aa0003e2 	mov	x2, x0
    853c:	9116a3e1 	add	x1, sp, #0x5a8
    8540:	52800020 	mov	w0, #0x1                   	// #1
    8544:	f902d7f5 	str	x21, [sp, #1448]
    8548:	f902dbe2 	str	x2, [sp, #1456]
    854c:	97ffee75 	bl	3f20 <fwp_data.part.0.constprop.0>
    8550:	9114c283 	add	x3, x20, #0x530
    8554:	aa0003f5 	mov	x21, x0
    8558:	f949d861 	ldr	x1, [x3, #5040]
    855c:	f949ec60 	ldr	x0, [x3, #5080]
    8560:	cb0102a1 	sub	x1, x21, x1
    8564:	eb00403f 	cmp	x1, x0, lsl #16
    8568:	54000322 	b.cs	85cc <f0+0x14d8>  // b.hs, b.nlast
    856c:	d350fc22 	lsr	x2, x1, #16
    8570:	f949fc63 	ldr	x3, [x3, #5112]
    8574:	8b020842 	add	x2, x2, x2, lsl #2
    8578:	d37df042 	lsl	x2, x2, #3
    857c:	8b020060 	add	x0, x3, x2
    8580:	f9401017 	ldr	x23, [x0, #32]
    8584:	b4000257 	cbz	x23, 85cc <f0+0x14d8>
    8588:	38626862 	ldrb	w2, [x3, x2]
    858c:	7100085f 	cmp	w2, #0x2
    8590:	54007260 	b.eq	93dc <f0+0x22e8>  // b.none
    8594:	7100045f 	cmp	w2, #0x1
    8598:	540001a1 	b.ne	85cc <f0+0x14d8>  // b.any
    859c:	29430002 	ldp	w2, w0, [x0, #24]
    85a0:	92403c21 	and	x1, x1, #0xffff
    85a4:	9b027c21 	mul	x1, x1, x2
    85a8:	d360fc21 	lsr	x1, x1, #32
    85ac:	eb00003f 	cmp	x1, x0
    85b0:	540000e2 	b.cs	85cc <f0+0x14d8>  // b.hs, b.nlast
    85b4:	8b0102f7 	add	x23, x23, x1
    85b8:	394002e0 	ldrb	w0, [x23]
    85bc:	7103fc1f 	cmp	w0, #0xff
    85c0:	540086a0 	b.eq	9694 <f0+0x25a0>  // b.none
    85c4:	52800020 	mov	w0, #0x1                   	// #1
    85c8:	390002e0 	strb	w0, [x23]
    85cc:	9116e3e1 	add	x1, sp, #0x5b8
    85d0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    85d4:	52800020 	mov	w0, #0x1                   	// #1
    85d8:	f902dfe2 	str	x2, [sp, #1464]
    85dc:	f902e3f5 	str	x21, [sp, #1472]
    85e0:	97ffee50 	bl	3f20 <fwp_data.part.0.constprop.0>
    85e4:	97ffec5f 	bl	3760 <fwp_rc_fresh>
    85e8:	aa0003e2 	mov	x2, x0
    85ec:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    85f0:	911723e1 	add	x1, sp, #0x5c8
    85f4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    85f8:	52800020 	mov	w0, #0x1                   	// #1
    85fc:	f902e7e3 	str	x3, [sp, #1480]
    8600:	f902ebe2 	str	x2, [sp, #1488]
    8604:	97ffee47 	bl	3f20 <fwp_data.part.0.constprop.0>
    8608:	9114c283 	add	x3, x20, #0x530
    860c:	aa0003f5 	mov	x21, x0
    8610:	f949d861 	ldr	x1, [x3, #5040]
    8614:	f949ec60 	ldr	x0, [x3, #5080]
    8618:	cb0102a1 	sub	x1, x21, x1
    861c:	eb00403f 	cmp	x1, x0, lsl #16
    8620:	54000322 	b.cs	8684 <f0+0x1590>  // b.hs, b.nlast
    8624:	d350fc22 	lsr	x2, x1, #16
    8628:	f949fc63 	ldr	x3, [x3, #5112]
    862c:	8b020842 	add	x2, x2, x2, lsl #2
    8630:	d37df042 	lsl	x2, x2, #3
    8634:	8b020060 	add	x0, x3, x2
    8638:	f9401017 	ldr	x23, [x0, #32]
    863c:	b4000257 	cbz	x23, 8684 <f0+0x1590>
    8640:	38626862 	ldrb	w2, [x3, x2]
    8644:	7100085f 	cmp	w2, #0x2
    8648:	54006c40 	b.eq	93d0 <f0+0x22dc>  // b.none
    864c:	7100045f 	cmp	w2, #0x1
    8650:	540001a1 	b.ne	8684 <f0+0x1590>  // b.any
    8654:	29430002 	ldp	w2, w0, [x0, #24]
    8658:	92403c21 	and	x1, x1, #0xffff
    865c:	9b027c21 	mul	x1, x1, x2
    8660:	d360fc21 	lsr	x1, x1, #32
    8664:	eb00003f 	cmp	x1, x0
    8668:	540000e2 	b.cs	8684 <f0+0x1590>  // b.hs, b.nlast
    866c:	8b0102f7 	add	x23, x23, x1
    8670:	394002e0 	ldrb	w0, [x23]
    8674:	7103fc1f 	cmp	w0, #0xff
    8678:	54008140 	b.eq	96a0 <f0+0x25ac>  // b.none
    867c:	52800020 	mov	w0, #0x1                   	// #1
    8680:	390002e0 	strb	w0, [x23]
    8684:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8688:	911763e1 	add	x1, sp, #0x5d8
    868c:	52800020 	mov	w0, #0x1                   	// #1
    8690:	f902efe2 	str	x2, [sp, #1496]
    8694:	f902f3f5 	str	x21, [sp, #1504]
    8698:	97ffee22 	bl	3f20 <fwp_data.part.0.constprop.0>
    869c:	9114c283 	add	x3, x20, #0x530
    86a0:	aa0003f5 	mov	x21, x0
    86a4:	f949d861 	ldr	x1, [x3, #5040]
    86a8:	f949ec60 	ldr	x0, [x3, #5080]
    86ac:	cb0102a1 	sub	x1, x21, x1
    86b0:	eb00403f 	cmp	x1, x0, lsl #16
    86b4:	54000322 	b.cs	8718 <f0+0x1624>  // b.hs, b.nlast
    86b8:	d350fc22 	lsr	x2, x1, #16
    86bc:	f949fc63 	ldr	x3, [x3, #5112]
    86c0:	8b020842 	add	x2, x2, x2, lsl #2
    86c4:	d37df042 	lsl	x2, x2, #3
    86c8:	8b020060 	add	x0, x3, x2
    86cc:	f9401017 	ldr	x23, [x0, #32]
    86d0:	b4000257 	cbz	x23, 8718 <f0+0x1624>
    86d4:	38626862 	ldrb	w2, [x3, x2]
    86d8:	7100085f 	cmp	w2, #0x2
    86dc:	54006740 	b.eq	93c4 <f0+0x22d0>  // b.none
    86e0:	7100045f 	cmp	w2, #0x1
    86e4:	540001a1 	b.ne	8718 <f0+0x1624>  // b.any
    86e8:	29430002 	ldp	w2, w0, [x0, #24]
    86ec:	92403c21 	and	x1, x1, #0xffff
    86f0:	9b027c21 	mul	x1, x1, x2
    86f4:	d360fc21 	lsr	x1, x1, #32
    86f8:	eb00003f 	cmp	x1, x0
    86fc:	540000e2 	b.cs	8718 <f0+0x1624>  // b.hs, b.nlast
    8700:	8b0102f7 	add	x23, x23, x1
    8704:	394002e0 	ldrb	w0, [x23]
    8708:	7103fc1f 	cmp	w0, #0xff
    870c:	54007d00 	b.eq	96ac <f0+0x25b8>  // b.none
    8710:	52800020 	mov	w0, #0x1                   	// #1
    8714:	390002e0 	strb	w0, [x23]
    8718:	9117a3e1 	add	x1, sp, #0x5e8
    871c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    8720:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    8724:	52800020 	mov	w0, #0x1                   	// #1
    8728:	f902f7f7 	str	x23, [sp, #1512]
    872c:	f902fbf5 	str	x21, [sp, #1520]
    8730:	97ffedfc 	bl	3f20 <fwp_data.part.0.constprop.0>
    8734:	97ffec0b 	bl	3760 <fwp_rc_fresh>
    8738:	aa0003e2 	mov	x2, x0
    873c:	9117e3e1 	add	x1, sp, #0x5f8
    8740:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    8744:	52800020 	mov	w0, #0x1                   	// #1
    8748:	f902fff5 	str	x21, [sp, #1528]
    874c:	f90303e2 	str	x2, [sp, #1536]
    8750:	97ffedf4 	bl	3f20 <fwp_data.part.0.constprop.0>
    8754:	97ffec03 	bl	3760 <fwp_rc_fresh>
    8758:	aa0003e2 	mov	x2, x0
    875c:	911823e1 	add	x1, sp, #0x608
    8760:	52800020 	mov	w0, #0x1                   	// #1
    8764:	f90307f7 	str	x23, [sp, #1544]
    8768:	f9030be2 	str	x2, [sp, #1552]
    876c:	97ffeded 	bl	3f20 <fwp_data.part.0.constprop.0>
    8770:	97ffebfc 	bl	3760 <fwp_rc_fresh>
    8774:	aa0003e2 	mov	x2, x0
    8778:	911863e1 	add	x1, sp, #0x618
    877c:	52800020 	mov	w0, #0x1                   	// #1
    8780:	f9030ff5 	str	x21, [sp, #1560]
    8784:	f90313e2 	str	x2, [sp, #1568]
    8788:	97ffede6 	bl	3f20 <fwp_data.part.0.constprop.0>
    878c:	97ffebf5 	bl	3760 <fwp_rc_fresh>
    8790:	aa0003e2 	mov	x2, x0
    8794:	9118a3e1 	add	x1, sp, #0x628
    8798:	52800020 	mov	w0, #0x1                   	// #1
    879c:	f90317f7 	str	x23, [sp, #1576]
    87a0:	f9031be2 	str	x2, [sp, #1584]
    87a4:	97ffeddf 	bl	3f20 <fwp_data.part.0.constprop.0>
    87a8:	9114c283 	add	x3, x20, #0x530
    87ac:	aa0003f5 	mov	x21, x0
    87b0:	f949d861 	ldr	x1, [x3, #5040]
    87b4:	f949ec60 	ldr	x0, [x3, #5080]
    87b8:	cb0102a1 	sub	x1, x21, x1
    87bc:	eb00403f 	cmp	x1, x0, lsl #16
    87c0:	54000322 	b.cs	8824 <f0+0x1730>  // b.hs, b.nlast
    87c4:	d350fc22 	lsr	x2, x1, #16
    87c8:	f949fc63 	ldr	x3, [x3, #5112]
    87cc:	8b020842 	add	x2, x2, x2, lsl #2
    87d0:	d37df042 	lsl	x2, x2, #3
    87d4:	8b020060 	add	x0, x3, x2
    87d8:	f9401017 	ldr	x23, [x0, #32]
    87dc:	b4000257 	cbz	x23, 8824 <f0+0x1730>
    87e0:	38626862 	ldrb	w2, [x3, x2]
    87e4:	7100085f 	cmp	w2, #0x2
    87e8:	54006d20 	b.eq	958c <f0+0x2498>  // b.none
    87ec:	7100045f 	cmp	w2, #0x1
    87f0:	540001a1 	b.ne	8824 <f0+0x1730>  // b.any
    87f4:	29430002 	ldp	w2, w0, [x0, #24]
    87f8:	92403c21 	and	x1, x1, #0xffff
    87fc:	9b027c21 	mul	x1, x1, x2
    8800:	d360fc21 	lsr	x1, x1, #32
    8804:	eb00003f 	cmp	x1, x0
    8808:	540000e2 	b.cs	8824 <f0+0x1730>  // b.hs, b.nlast
    880c:	8b0102f7 	add	x23, x23, x1
    8810:	394002e0 	ldrb	w0, [x23]
    8814:	7103fc1f 	cmp	w0, #0xff
    8818:	54007500 	b.eq	96b8 <f0+0x25c4>  // b.none
    881c:	52800020 	mov	w0, #0x1                   	// #1
    8820:	390002e0 	strb	w0, [x23]
    8824:	9118e3e1 	add	x1, sp, #0x638
    8828:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    882c:	52800020 	mov	w0, #0x1                   	// #1
    8830:	f9031fe2 	str	x2, [sp, #1592]
    8834:	f90323f5 	str	x21, [sp, #1600]
    8838:	97ffedba 	bl	3f20 <fwp_data.part.0.constprop.0>
    883c:	97ffebc9 	bl	3760 <fwp_rc_fresh>
    8840:	aa0003e2 	mov	x2, x0
    8844:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8848:	911923e1 	add	x1, sp, #0x648
    884c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8850:	52800020 	mov	w0, #0x1                   	// #1
    8854:	f90327e3 	str	x3, [sp, #1608]
    8858:	f9032be2 	str	x2, [sp, #1616]
    885c:	97ffedb1 	bl	3f20 <fwp_data.part.0.constprop.0>
    8860:	9114c283 	add	x3, x20, #0x530
    8864:	aa0003f5 	mov	x21, x0
    8868:	f949d861 	ldr	x1, [x3, #5040]
    886c:	f949ec60 	ldr	x0, [x3, #5080]
    8870:	cb0102a1 	sub	x1, x21, x1
    8874:	eb00403f 	cmp	x1, x0, lsl #16
    8878:	54000322 	b.cs	88dc <f0+0x17e8>  // b.hs, b.nlast
    887c:	d350fc22 	lsr	x2, x1, #16
    8880:	f949fc63 	ldr	x3, [x3, #5112]
    8884:	8b020842 	add	x2, x2, x2, lsl #2
    8888:	d37df042 	lsl	x2, x2, #3
    888c:	8b020060 	add	x0, x3, x2
    8890:	f9401017 	ldr	x23, [x0, #32]
    8894:	b4000257 	cbz	x23, 88dc <f0+0x17e8>
    8898:	38626862 	ldrb	w2, [x3, x2]
    889c:	7100085f 	cmp	w2, #0x2
    88a0:	54006700 	b.eq	9580 <f0+0x248c>  // b.none
    88a4:	7100045f 	cmp	w2, #0x1
    88a8:	540001a1 	b.ne	88dc <f0+0x17e8>  // b.any
    88ac:	29430002 	ldp	w2, w0, [x0, #24]
    88b0:	92403c21 	and	x1, x1, #0xffff
    88b4:	9b027c21 	mul	x1, x1, x2
    88b8:	d360fc21 	lsr	x1, x1, #32
    88bc:	eb00003f 	cmp	x1, x0
    88c0:	540000e2 	b.cs	88dc <f0+0x17e8>  // b.hs, b.nlast
    88c4:	8b0102f7 	add	x23, x23, x1
    88c8:	394002e0 	ldrb	w0, [x23]
    88cc:	7103fc1f 	cmp	w0, #0xff
    88d0:	54006fa0 	b.eq	96c4 <f0+0x25d0>  // b.none
    88d4:	52800020 	mov	w0, #0x1                   	// #1
    88d8:	390002e0 	strb	w0, [x23]
    88dc:	911963e1 	add	x1, sp, #0x658
    88e0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    88e4:	52800020 	mov	w0, #0x1                   	// #1
    88e8:	f9032fe2 	str	x2, [sp, #1624]
    88ec:	f90333f5 	str	x21, [sp, #1632]
    88f0:	97ffed8c 	bl	3f20 <fwp_data.part.0.constprop.0>
    88f4:	97ffeb9b 	bl	3760 <fwp_rc_fresh>
    88f8:	aa0003e2 	mov	x2, x0
    88fc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8900:	9119a3e1 	add	x1, sp, #0x668
    8904:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8908:	52800020 	mov	w0, #0x1                   	// #1
    890c:	f90337e3 	str	x3, [sp, #1640]
    8910:	f9033be2 	str	x2, [sp, #1648]
    8914:	97ffed83 	bl	3f20 <fwp_data.part.0.constprop.0>
    8918:	9114c283 	add	x3, x20, #0x530
    891c:	aa0003f5 	mov	x21, x0
    8920:	f949d861 	ldr	x1, [x3, #5040]
    8924:	f949ec60 	ldr	x0, [x3, #5080]
    8928:	cb0102a1 	sub	x1, x21, x1
    892c:	eb00403f 	cmp	x1, x0, lsl #16
    8930:	54000322 	b.cs	8994 <f0+0x18a0>  // b.hs, b.nlast
    8934:	d350fc22 	lsr	x2, x1, #16
    8938:	f949fc63 	ldr	x3, [x3, #5112]
    893c:	8b020842 	add	x2, x2, x2, lsl #2
    8940:	d37df042 	lsl	x2, x2, #3
    8944:	8b020060 	add	x0, x3, x2
    8948:	f9401017 	ldr	x23, [x0, #32]
    894c:	b4000257 	cbz	x23, 8994 <f0+0x18a0>
    8950:	38626862 	ldrb	w2, [x3, x2]
    8954:	7100085f 	cmp	w2, #0x2
    8958:	540060e0 	b.eq	9574 <f0+0x2480>  // b.none
    895c:	7100045f 	cmp	w2, #0x1
    8960:	540001a1 	b.ne	8994 <f0+0x18a0>  // b.any
    8964:	29430002 	ldp	w2, w0, [x0, #24]
    8968:	92403c21 	and	x1, x1, #0xffff
    896c:	9b027c21 	mul	x1, x1, x2
    8970:	d360fc21 	lsr	x1, x1, #32
    8974:	eb00003f 	cmp	x1, x0
    8978:	540000e2 	b.cs	8994 <f0+0x18a0>  // b.hs, b.nlast
    897c:	8b0102f7 	add	x23, x23, x1
    8980:	394002e0 	ldrb	w0, [x23]
    8984:	7103fc1f 	cmp	w0, #0xff
    8988:	54006a40 	b.eq	96d0 <f0+0x25dc>  // b.none
    898c:	52800020 	mov	w0, #0x1                   	// #1
    8990:	390002e0 	strb	w0, [x23]
    8994:	9119e3e1 	add	x1, sp, #0x678
    8998:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    899c:	52800020 	mov	w0, #0x1                   	// #1
    89a0:	f9033fe2 	str	x2, [sp, #1656]
    89a4:	f90343f5 	str	x21, [sp, #1664]
    89a8:	97ffed5e 	bl	3f20 <fwp_data.part.0.constprop.0>
    89ac:	97ffeb6d 	bl	3760 <fwp_rc_fresh>
    89b0:	aa0003e2 	mov	x2, x0
    89b4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    89b8:	911a23e1 	add	x1, sp, #0x688
    89bc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    89c0:	52800020 	mov	w0, #0x1                   	// #1
    89c4:	f90347e3 	str	x3, [sp, #1672]
    89c8:	f9034be2 	str	x2, [sp, #1680]
    89cc:	97ffed55 	bl	3f20 <fwp_data.part.0.constprop.0>
    89d0:	9114c283 	add	x3, x20, #0x530
    89d4:	aa0003f5 	mov	x21, x0
    89d8:	f949d861 	ldr	x1, [x3, #5040]
    89dc:	f949ec60 	ldr	x0, [x3, #5080]
    89e0:	cb0102a1 	sub	x1, x21, x1
    89e4:	eb00403f 	cmp	x1, x0, lsl #16
    89e8:	54000322 	b.cs	8a4c <f0+0x1958>  // b.hs, b.nlast
    89ec:	d350fc22 	lsr	x2, x1, #16
    89f0:	f949fc63 	ldr	x3, [x3, #5112]
    89f4:	8b020842 	add	x2, x2, x2, lsl #2
    89f8:	d37df042 	lsl	x2, x2, #3
    89fc:	8b020060 	add	x0, x3, x2
    8a00:	f9401017 	ldr	x23, [x0, #32]
    8a04:	b4000257 	cbz	x23, 8a4c <f0+0x1958>
    8a08:	38626862 	ldrb	w2, [x3, x2]
    8a0c:	7100085f 	cmp	w2, #0x2
    8a10:	54005ac0 	b.eq	9568 <f0+0x2474>  // b.none
    8a14:	7100045f 	cmp	w2, #0x1
    8a18:	540001a1 	b.ne	8a4c <f0+0x1958>  // b.any
    8a1c:	29430002 	ldp	w2, w0, [x0, #24]
    8a20:	92403c21 	and	x1, x1, #0xffff
    8a24:	9b027c21 	mul	x1, x1, x2
    8a28:	d360fc21 	lsr	x1, x1, #32
    8a2c:	eb00003f 	cmp	x1, x0
    8a30:	540000e2 	b.cs	8a4c <f0+0x1958>  // b.hs, b.nlast
    8a34:	8b0102f7 	add	x23, x23, x1
    8a38:	394002e0 	ldrb	w0, [x23]
    8a3c:	7103fc1f 	cmp	w0, #0xff
    8a40:	540064e0 	b.eq	96dc <f0+0x25e8>  // b.none
    8a44:	52800020 	mov	w0, #0x1                   	// #1
    8a48:	390002e0 	strb	w0, [x23]
    8a4c:	911a63e1 	add	x1, sp, #0x698
    8a50:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8a54:	52800020 	mov	w0, #0x1                   	// #1
    8a58:	f9034fe2 	str	x2, [sp, #1688]
    8a5c:	f90353f5 	str	x21, [sp, #1696]
    8a60:	97ffed30 	bl	3f20 <fwp_data.part.0.constprop.0>
    8a64:	97ffeb3f 	bl	3760 <fwp_rc_fresh>
    8a68:	aa0003e2 	mov	x2, x0
    8a6c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8a70:	911aa3e1 	add	x1, sp, #0x6a8
    8a74:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8a78:	52800020 	mov	w0, #0x1                   	// #1
    8a7c:	f90357e3 	str	x3, [sp, #1704]
    8a80:	f9035be2 	str	x2, [sp, #1712]
    8a84:	97ffed27 	bl	3f20 <fwp_data.part.0.constprop.0>
    8a88:	9114c283 	add	x3, x20, #0x530
    8a8c:	aa0003f5 	mov	x21, x0
    8a90:	f949d861 	ldr	x1, [x3, #5040]
    8a94:	f949ec60 	ldr	x0, [x3, #5080]
    8a98:	cb0102a1 	sub	x1, x21, x1
    8a9c:	eb00403f 	cmp	x1, x0, lsl #16
    8aa0:	54000322 	b.cs	8b04 <f0+0x1a10>  // b.hs, b.nlast
    8aa4:	d350fc22 	lsr	x2, x1, #16
    8aa8:	f949fc63 	ldr	x3, [x3, #5112]
    8aac:	8b020842 	add	x2, x2, x2, lsl #2
    8ab0:	d37df042 	lsl	x2, x2, #3
    8ab4:	8b020060 	add	x0, x3, x2
    8ab8:	f9401017 	ldr	x23, [x0, #32]
    8abc:	b4000257 	cbz	x23, 8b04 <f0+0x1a10>
    8ac0:	38626862 	ldrb	w2, [x3, x2]
    8ac4:	7100085f 	cmp	w2, #0x2
    8ac8:	540054a0 	b.eq	955c <f0+0x2468>  // b.none
    8acc:	7100045f 	cmp	w2, #0x1
    8ad0:	540001a1 	b.ne	8b04 <f0+0x1a10>  // b.any
    8ad4:	29430002 	ldp	w2, w0, [x0, #24]
    8ad8:	92403c21 	and	x1, x1, #0xffff
    8adc:	9b027c21 	mul	x1, x1, x2
    8ae0:	d360fc21 	lsr	x1, x1, #32
    8ae4:	eb00003f 	cmp	x1, x0
    8ae8:	540000e2 	b.cs	8b04 <f0+0x1a10>  // b.hs, b.nlast
    8aec:	8b0102f7 	add	x23, x23, x1
    8af0:	394002e0 	ldrb	w0, [x23]
    8af4:	7103fc1f 	cmp	w0, #0xff
    8af8:	54005f80 	b.eq	96e8 <f0+0x25f4>  // b.none
    8afc:	52800020 	mov	w0, #0x1                   	// #1
    8b00:	390002e0 	strb	w0, [x23]
    8b04:	911ae3e1 	add	x1, sp, #0x6b8
    8b08:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8b0c:	52800020 	mov	w0, #0x1                   	// #1
    8b10:	f9035fe2 	str	x2, [sp, #1720]
    8b14:	f90363f5 	str	x21, [sp, #1728]
    8b18:	97ffed02 	bl	3f20 <fwp_data.part.0.constprop.0>
    8b1c:	97ffeb11 	bl	3760 <fwp_rc_fresh>
    8b20:	aa0003e2 	mov	x2, x0
    8b24:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8b28:	911b23e1 	add	x1, sp, #0x6c8
    8b2c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8b30:	52800020 	mov	w0, #0x1                   	// #1
    8b34:	f90367e3 	str	x3, [sp, #1736]
    8b38:	f9036be2 	str	x2, [sp, #1744]
    8b3c:	97ffecf9 	bl	3f20 <fwp_data.part.0.constprop.0>
    8b40:	9114c283 	add	x3, x20, #0x530
    8b44:	aa0003f5 	mov	x21, x0
    8b48:	f949d861 	ldr	x1, [x3, #5040]
    8b4c:	f949ec60 	ldr	x0, [x3, #5080]
    8b50:	cb0102a1 	sub	x1, x21, x1
    8b54:	eb00403f 	cmp	x1, x0, lsl #16
    8b58:	54000322 	b.cs	8bbc <f0+0x1ac8>  // b.hs, b.nlast
    8b5c:	d350fc22 	lsr	x2, x1, #16
    8b60:	f949fc63 	ldr	x3, [x3, #5112]
    8b64:	8b020842 	add	x2, x2, x2, lsl #2
    8b68:	d37df042 	lsl	x2, x2, #3
    8b6c:	8b020060 	add	x0, x3, x2
    8b70:	f9401017 	ldr	x23, [x0, #32]
    8b74:	b4000257 	cbz	x23, 8bbc <f0+0x1ac8>
    8b78:	38626862 	ldrb	w2, [x3, x2]
    8b7c:	7100085f 	cmp	w2, #0x2
    8b80:	54004e80 	b.eq	9550 <f0+0x245c>  // b.none
    8b84:	7100045f 	cmp	w2, #0x1
    8b88:	540001a1 	b.ne	8bbc <f0+0x1ac8>  // b.any
    8b8c:	29430002 	ldp	w2, w0, [x0, #24]
    8b90:	92403c21 	and	x1, x1, #0xffff
    8b94:	9b027c21 	mul	x1, x1, x2
    8b98:	d360fc21 	lsr	x1, x1, #32
    8b9c:	eb00003f 	cmp	x1, x0
    8ba0:	540000e2 	b.cs	8bbc <f0+0x1ac8>  // b.hs, b.nlast
    8ba4:	8b0102f7 	add	x23, x23, x1
    8ba8:	394002e0 	ldrb	w0, [x23]
    8bac:	7103fc1f 	cmp	w0, #0xff
    8bb0:	54005a20 	b.eq	96f4 <f0+0x2600>  // b.none
    8bb4:	52800020 	mov	w0, #0x1                   	// #1
    8bb8:	390002e0 	strb	w0, [x23]
    8bbc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8bc0:	911b63e1 	add	x1, sp, #0x6d8
    8bc4:	52800020 	mov	w0, #0x1                   	// #1
    8bc8:	f9036fe2 	str	x2, [sp, #1752]
    8bcc:	f90373f5 	str	x21, [sp, #1760]
    8bd0:	97ffecd4 	bl	3f20 <fwp_data.part.0.constprop.0>
    8bd4:	9114c283 	add	x3, x20, #0x530
    8bd8:	aa0003f5 	mov	x21, x0
    8bdc:	f949d861 	ldr	x1, [x3, #5040]
    8be0:	f949ec60 	ldr	x0, [x3, #5080]
    8be4:	cb0102a1 	sub	x1, x21, x1
    8be8:	eb00403f 	cmp	x1, x0, lsl #16
    8bec:	54000322 	b.cs	8c50 <f0+0x1b5c>  // b.hs, b.nlast
    8bf0:	d350fc22 	lsr	x2, x1, #16
    8bf4:	f949fc63 	ldr	x3, [x3, #5112]
    8bf8:	8b020842 	add	x2, x2, x2, lsl #2
    8bfc:	d37df042 	lsl	x2, x2, #3
    8c00:	8b020060 	add	x0, x3, x2
    8c04:	f9401017 	ldr	x23, [x0, #32]
    8c08:	b4000257 	cbz	x23, 8c50 <f0+0x1b5c>
    8c0c:	38626862 	ldrb	w2, [x3, x2]
    8c10:	7100085f 	cmp	w2, #0x2
    8c14:	54004980 	b.eq	9544 <f0+0x2450>  // b.none
    8c18:	7100045f 	cmp	w2, #0x1
    8c1c:	540001a1 	b.ne	8c50 <f0+0x1b5c>  // b.any
    8c20:	29430002 	ldp	w2, w0, [x0, #24]
    8c24:	92403c21 	and	x1, x1, #0xffff
    8c28:	9b027c21 	mul	x1, x1, x2
    8c2c:	d360fc21 	lsr	x1, x1, #32
    8c30:	eb00003f 	cmp	x1, x0
    8c34:	540000e2 	b.cs	8c50 <f0+0x1b5c>  // b.hs, b.nlast
    8c38:	8b0102f7 	add	x23, x23, x1
    8c3c:	394002e0 	ldrb	w0, [x23]
    8c40:	7103fc1f 	cmp	w0, #0xff
    8c44:	540055e0 	b.eq	9700 <f0+0x260c>  // b.none
    8c48:	52800020 	mov	w0, #0x1                   	// #1
    8c4c:	390002e0 	strb	w0, [x23]
    8c50:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8c54:	911ba3e1 	add	x1, sp, #0x6e8
    8c58:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8c5c:	52800020 	mov	w0, #0x1                   	// #1
    8c60:	f90377e2 	str	x2, [sp, #1768]
    8c64:	f9037bf5 	str	x21, [sp, #1776]
    8c68:	97ffecae 	bl	3f20 <fwp_data.part.0.constprop.0>
    8c6c:	9114c283 	add	x3, x20, #0x530
    8c70:	aa0003f5 	mov	x21, x0
    8c74:	f949d861 	ldr	x1, [x3, #5040]
    8c78:	f949ec60 	ldr	x0, [x3, #5080]
    8c7c:	cb0102a1 	sub	x1, x21, x1
    8c80:	eb00403f 	cmp	x1, x0, lsl #16
    8c84:	54000322 	b.cs	8ce8 <f0+0x1bf4>  // b.hs, b.nlast
    8c88:	d350fc22 	lsr	x2, x1, #16
    8c8c:	f949fc63 	ldr	x3, [x3, #5112]
    8c90:	8b020842 	add	x2, x2, x2, lsl #2
    8c94:	d37df042 	lsl	x2, x2, #3
    8c98:	8b020060 	add	x0, x3, x2
    8c9c:	f9401017 	ldr	x23, [x0, #32]
    8ca0:	b4000257 	cbz	x23, 8ce8 <f0+0x1bf4>
    8ca4:	38626862 	ldrb	w2, [x3, x2]
    8ca8:	7100085f 	cmp	w2, #0x2
    8cac:	54004460 	b.eq	9538 <f0+0x2444>  // b.none
    8cb0:	7100045f 	cmp	w2, #0x1
    8cb4:	540001a1 	b.ne	8ce8 <f0+0x1bf4>  // b.any
    8cb8:	29430002 	ldp	w2, w0, [x0, #24]
    8cbc:	92403c21 	and	x1, x1, #0xffff
    8cc0:	9b027c21 	mul	x1, x1, x2
    8cc4:	d360fc21 	lsr	x1, x1, #32
    8cc8:	eb00003f 	cmp	x1, x0
    8ccc:	540000e2 	b.cs	8ce8 <f0+0x1bf4>  // b.hs, b.nlast
    8cd0:	8b0102f7 	add	x23, x23, x1
    8cd4:	394002e0 	ldrb	w0, [x23]
    8cd8:	7103fc1f 	cmp	w0, #0xff
    8cdc:	54005180 	b.eq	970c <f0+0x2618>  // b.none
    8ce0:	52800020 	mov	w0, #0x1                   	// #1
    8ce4:	390002e0 	strb	w0, [x23]
    8ce8:	911be3e1 	add	x1, sp, #0x6f8
    8cec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8cf0:	52800020 	mov	w0, #0x1                   	// #1
    8cf4:	f9037fe2 	str	x2, [sp, #1784]
    8cf8:	f90383f5 	str	x21, [sp, #1792]
    8cfc:	97ffec89 	bl	3f20 <fwp_data.part.0.constprop.0>
    8d00:	97ffea98 	bl	3760 <fwp_rc_fresh>
    8d04:	aa0003e2 	mov	x2, x0
    8d08:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8d0c:	911c23e1 	add	x1, sp, #0x708
    8d10:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8d14:	52800020 	mov	w0, #0x1                   	// #1
    8d18:	f90387e3 	str	x3, [sp, #1800]
    8d1c:	f9038be2 	str	x2, [sp, #1808]
    8d20:	97ffec80 	bl	3f20 <fwp_data.part.0.constprop.0>
    8d24:	9114c283 	add	x3, x20, #0x530
    8d28:	aa0003f5 	mov	x21, x0
    8d2c:	f949d861 	ldr	x1, [x3, #5040]
    8d30:	f949ec60 	ldr	x0, [x3, #5080]
    8d34:	cb0102a1 	sub	x1, x21, x1
    8d38:	eb00403f 	cmp	x1, x0, lsl #16
    8d3c:	54000322 	b.cs	8da0 <f0+0x1cac>  // b.hs, b.nlast
    8d40:	d350fc22 	lsr	x2, x1, #16
    8d44:	f949fc63 	ldr	x3, [x3, #5112]
    8d48:	8b020842 	add	x2, x2, x2, lsl #2
    8d4c:	d37df042 	lsl	x2, x2, #3
    8d50:	8b020060 	add	x0, x3, x2
    8d54:	f9401017 	ldr	x23, [x0, #32]
    8d58:	b4000257 	cbz	x23, 8da0 <f0+0x1cac>
    8d5c:	38626862 	ldrb	w2, [x3, x2]
    8d60:	7100085f 	cmp	w2, #0x2
    8d64:	54003e40 	b.eq	952c <f0+0x2438>  // b.none
    8d68:	7100045f 	cmp	w2, #0x1
    8d6c:	540001a1 	b.ne	8da0 <f0+0x1cac>  // b.any
    8d70:	29430002 	ldp	w2, w0, [x0, #24]
    8d74:	92403c21 	and	x1, x1, #0xffff
    8d78:	9b027c21 	mul	x1, x1, x2
    8d7c:	d360fc21 	lsr	x1, x1, #32
    8d80:	eb00003f 	cmp	x1, x0
    8d84:	540000e2 	b.cs	8da0 <f0+0x1cac>  // b.hs, b.nlast
    8d88:	8b0102f7 	add	x23, x23, x1
    8d8c:	394002e0 	ldrb	w0, [x23]
    8d90:	7103fc1f 	cmp	w0, #0xff
    8d94:	54004c20 	b.eq	9718 <f0+0x2624>  // b.none
    8d98:	52800020 	mov	w0, #0x1                   	// #1
    8d9c:	390002e0 	strb	w0, [x23]
    8da0:	911c63e1 	add	x1, sp, #0x718
    8da4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8da8:	52800020 	mov	w0, #0x1                   	// #1
    8dac:	f9038fe2 	str	x2, [sp, #1816]
    8db0:	f90393f5 	str	x21, [sp, #1824]
    8db4:	97ffec5b 	bl	3f20 <fwp_data.part.0.constprop.0>
    8db8:	97ffea6a 	bl	3760 <fwp_rc_fresh>
    8dbc:	aa0003e2 	mov	x2, x0
    8dc0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8dc4:	911ca3e1 	add	x1, sp, #0x728
    8dc8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8dcc:	52800020 	mov	w0, #0x1                   	// #1
    8dd0:	f90397e3 	str	x3, [sp, #1832]
    8dd4:	f9039be2 	str	x2, [sp, #1840]
    8dd8:	97ffec52 	bl	3f20 <fwp_data.part.0.constprop.0>
    8ddc:	9114c283 	add	x3, x20, #0x530
    8de0:	aa0003f5 	mov	x21, x0
    8de4:	f949d861 	ldr	x1, [x3, #5040]
    8de8:	f949ec60 	ldr	x0, [x3, #5080]
    8dec:	cb0102a1 	sub	x1, x21, x1
    8df0:	eb00403f 	cmp	x1, x0, lsl #16
    8df4:	54000322 	b.cs	8e58 <f0+0x1d64>  // b.hs, b.nlast
    8df8:	d350fc22 	lsr	x2, x1, #16
    8dfc:	f949fc63 	ldr	x3, [x3, #5112]
    8e00:	8b020842 	add	x2, x2, x2, lsl #2
    8e04:	d37df042 	lsl	x2, x2, #3
    8e08:	8b020060 	add	x0, x3, x2
    8e0c:	f9401017 	ldr	x23, [x0, #32]
    8e10:	b4000257 	cbz	x23, 8e58 <f0+0x1d64>
    8e14:	38626862 	ldrb	w2, [x3, x2]
    8e18:	7100085f 	cmp	w2, #0x2
    8e1c:	54003820 	b.eq	9520 <f0+0x242c>  // b.none
    8e20:	7100045f 	cmp	w2, #0x1
    8e24:	540001a1 	b.ne	8e58 <f0+0x1d64>  // b.any
    8e28:	29430002 	ldp	w2, w0, [x0, #24]
    8e2c:	92403c21 	and	x1, x1, #0xffff
    8e30:	9b027c21 	mul	x1, x1, x2
    8e34:	d360fc21 	lsr	x1, x1, #32
    8e38:	eb00003f 	cmp	x1, x0
    8e3c:	540000e2 	b.cs	8e58 <f0+0x1d64>  // b.hs, b.nlast
    8e40:	8b0102f7 	add	x23, x23, x1
    8e44:	394002e0 	ldrb	w0, [x23]
    8e48:	7103fc1f 	cmp	w0, #0xff
    8e4c:	540046c0 	b.eq	9724 <f0+0x2630>  // b.none
    8e50:	52800020 	mov	w0, #0x1                   	// #1
    8e54:	390002e0 	strb	w0, [x23]
    8e58:	911ce3e1 	add	x1, sp, #0x738
    8e5c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    8e60:	52800020 	mov	w0, #0x1                   	// #1
    8e64:	f9039ff7 	str	x23, [sp, #1848]
    8e68:	f903a3f5 	str	x21, [sp, #1856]
    8e6c:	97ffec2d 	bl	3f20 <fwp_data.part.0.constprop.0>
    8e70:	97ffea3c 	bl	3760 <fwp_rc_fresh>
    8e74:	aa0003e2 	mov	x2, x0
    8e78:	911d23e1 	add	x1, sp, #0x748
    8e7c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    8e80:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    8e84:	52800020 	mov	w0, #0x1                   	// #1
    8e88:	f903a7f5 	str	x21, [sp, #1864]
    8e8c:	f903abe2 	str	x2, [sp, #1872]
    8e90:	97ffec24 	bl	3f20 <fwp_data.part.0.constprop.0>
    8e94:	97ffea33 	bl	3760 <fwp_rc_fresh>
    8e98:	aa0003e2 	mov	x2, x0
    8e9c:	911d63e1 	add	x1, sp, #0x758
    8ea0:	52800020 	mov	w0, #0x1                   	// #1
    8ea4:	f903aff7 	str	x23, [sp, #1880]
    8ea8:	f903b3e2 	str	x2, [sp, #1888]
    8eac:	97ffec1d 	bl	3f20 <fwp_data.part.0.constprop.0>
    8eb0:	97ffea2c 	bl	3760 <fwp_rc_fresh>
    8eb4:	aa0003e2 	mov	x2, x0
    8eb8:	911da3e1 	add	x1, sp, #0x768
    8ebc:	52800020 	mov	w0, #0x1                   	// #1
    8ec0:	f903b7f5 	str	x21, [sp, #1896]
    8ec4:	f903bbe2 	str	x2, [sp, #1904]
    8ec8:	97ffec16 	bl	3f20 <fwp_data.part.0.constprop.0>
    8ecc:	9114c283 	add	x3, x20, #0x530
    8ed0:	aa0003f5 	mov	x21, x0
    8ed4:	f949d861 	ldr	x1, [x3, #5040]
    8ed8:	f949ec60 	ldr	x0, [x3, #5080]
    8edc:	cb0102a1 	sub	x1, x21, x1
    8ee0:	eb00403f 	cmp	x1, x0, lsl #16
    8ee4:	54000322 	b.cs	8f48 <f0+0x1e54>  // b.hs, b.nlast
    8ee8:	d350fc22 	lsr	x2, x1, #16
    8eec:	f949fc63 	ldr	x3, [x3, #5112]
    8ef0:	8b020842 	add	x2, x2, x2, lsl #2
    8ef4:	d37df042 	lsl	x2, x2, #3
    8ef8:	8b020060 	add	x0, x3, x2
    8efc:	f9401017 	ldr	x23, [x0, #32]
    8f00:	b4000257 	cbz	x23, 8f48 <f0+0x1e54>
    8f04:	38626862 	ldrb	w2, [x3, x2]
    8f08:	7100085f 	cmp	w2, #0x2
    8f0c:	54003040 	b.eq	9514 <f0+0x2420>  // b.none
    8f10:	7100045f 	cmp	w2, #0x1
    8f14:	540001a1 	b.ne	8f48 <f0+0x1e54>  // b.any
    8f18:	29430002 	ldp	w2, w0, [x0, #24]
    8f1c:	92403c21 	and	x1, x1, #0xffff
    8f20:	9b027c21 	mul	x1, x1, x2
    8f24:	d360fc21 	lsr	x1, x1, #32
    8f28:	eb00003f 	cmp	x1, x0
    8f2c:	540000e2 	b.cs	8f48 <f0+0x1e54>  // b.hs, b.nlast
    8f30:	8b0102f7 	add	x23, x23, x1
    8f34:	394002e0 	ldrb	w0, [x23]
    8f38:	7103fc1f 	cmp	w0, #0xff
    8f3c:	54003fa0 	b.eq	9730 <f0+0x263c>  // b.none
    8f40:	52800020 	mov	w0, #0x1                   	// #1
    8f44:	390002e0 	strb	w0, [x23]
    8f48:	911de3e1 	add	x1, sp, #0x778
    8f4c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    8f50:	52800020 	mov	w0, #0x1                   	// #1
    8f54:	f903bff7 	str	x23, [sp, #1912]
    8f58:	f903c3f5 	str	x21, [sp, #1920]
    8f5c:	97ffebf1 	bl	3f20 <fwp_data.part.0.constprop.0>
    8f60:	97ffea00 	bl	3760 <fwp_rc_fresh>
    8f64:	aa0003e2 	mov	x2, x0
    8f68:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    8f6c:	911e23e1 	add	x1, sp, #0x788
    8f70:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    8f74:	52800020 	mov	w0, #0x1                   	// #1
    8f78:	f903c7e3 	str	x3, [sp, #1928]
    8f7c:	f903cbe2 	str	x2, [sp, #1936]
    8f80:	97ffebe8 	bl	3f20 <fwp_data.part.0.constprop.0>
    8f84:	97ffe9f7 	bl	3760 <fwp_rc_fresh>
    8f88:	aa0003e2 	mov	x2, x0
    8f8c:	911e63e1 	add	x1, sp, #0x798
    8f90:	52800020 	mov	w0, #0x1                   	// #1
    8f94:	f903cff7 	str	x23, [sp, #1944]
    8f98:	f903d3e2 	str	x2, [sp, #1952]
    8f9c:	97ffebe1 	bl	3f20 <fwp_data.part.0.constprop.0>
    8fa0:	9114c283 	add	x3, x20, #0x530
    8fa4:	aa0003f5 	mov	x21, x0
    8fa8:	f949d861 	ldr	x1, [x3, #5040]
    8fac:	f949ec60 	ldr	x0, [x3, #5080]
    8fb0:	cb0102a1 	sub	x1, x21, x1
    8fb4:	eb00403f 	cmp	x1, x0, lsl #16
    8fb8:	54000322 	b.cs	901c <f0+0x1f28>  // b.hs, b.nlast
    8fbc:	d350fc22 	lsr	x2, x1, #16
    8fc0:	f949fc63 	ldr	x3, [x3, #5112]
    8fc4:	8b020842 	add	x2, x2, x2, lsl #2
    8fc8:	d37df042 	lsl	x2, x2, #3
    8fcc:	8b020060 	add	x0, x3, x2
    8fd0:	f9401017 	ldr	x23, [x0, #32]
    8fd4:	b4000257 	cbz	x23, 901c <f0+0x1f28>
    8fd8:	38626862 	ldrb	w2, [x3, x2]
    8fdc:	7100085f 	cmp	w2, #0x2
    8fe0:	54002940 	b.eq	9508 <f0+0x2414>  // b.none
    8fe4:	7100045f 	cmp	w2, #0x1
    8fe8:	540001a1 	b.ne	901c <f0+0x1f28>  // b.any
    8fec:	29430002 	ldp	w2, w0, [x0, #24]
    8ff0:	92403c21 	and	x1, x1, #0xffff
    8ff4:	9b027c21 	mul	x1, x1, x2
    8ff8:	d360fc21 	lsr	x1, x1, #32
    8ffc:	eb00003f 	cmp	x1, x0
    9000:	540000e2 	b.cs	901c <f0+0x1f28>  // b.hs, b.nlast
    9004:	8b0102f7 	add	x23, x23, x1
    9008:	394002e0 	ldrb	w0, [x23]
    900c:	7103fc1f 	cmp	w0, #0xff
    9010:	54003960 	b.eq	973c <f0+0x2648>  // b.none
    9014:	52800020 	mov	w0, #0x1                   	// #1
    9018:	390002e0 	strb	w0, [x23]
    901c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9020:	911ea3e1 	add	x1, sp, #0x7a8
    9024:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9028:	52800020 	mov	w0, #0x1                   	// #1
    902c:	f903d7e2 	str	x2, [sp, #1960]
    9030:	f903dbf5 	str	x21, [sp, #1968]
    9034:	97ffebbb 	bl	3f20 <fwp_data.part.0.constprop.0>
    9038:	9114c283 	add	x3, x20, #0x530
    903c:	aa0003f5 	mov	x21, x0
    9040:	f949d861 	ldr	x1, [x3, #5040]
    9044:	f949ec60 	ldr	x0, [x3, #5080]
    9048:	cb0102a1 	sub	x1, x21, x1
    904c:	eb00403f 	cmp	x1, x0, lsl #16
    9050:	54000322 	b.cs	90b4 <f0+0x1fc0>  // b.hs, b.nlast
    9054:	d350fc22 	lsr	x2, x1, #16
    9058:	f949fc63 	ldr	x3, [x3, #5112]
    905c:	8b020842 	add	x2, x2, x2, lsl #2
    9060:	d37df042 	lsl	x2, x2, #3
    9064:	8b020060 	add	x0, x3, x2
    9068:	f9401017 	ldr	x23, [x0, #32]
    906c:	b4000257 	cbz	x23, 90b4 <f0+0x1fc0>
    9070:	38626862 	ldrb	w2, [x3, x2]
    9074:	7100085f 	cmp	w2, #0x2
    9078:	54002420 	b.eq	94fc <f0+0x2408>  // b.none
    907c:	7100045f 	cmp	w2, #0x1
    9080:	540001a1 	b.ne	90b4 <f0+0x1fc0>  // b.any
    9084:	29430002 	ldp	w2, w0, [x0, #24]
    9088:	92403c21 	and	x1, x1, #0xffff
    908c:	9b027c21 	mul	x1, x1, x2
    9090:	d360fc21 	lsr	x1, x1, #32
    9094:	eb00003f 	cmp	x1, x0
    9098:	540000e2 	b.cs	90b4 <f0+0x1fc0>  // b.hs, b.nlast
    909c:	8b0102f7 	add	x23, x23, x1
    90a0:	394002e0 	ldrb	w0, [x23]
    90a4:	7103fc1f 	cmp	w0, #0xff
    90a8:	54003500 	b.eq	9748 <f0+0x2654>  // b.none
    90ac:	52800020 	mov	w0, #0x1                   	// #1
    90b0:	390002e0 	strb	w0, [x23]
    90b4:	911ee3e1 	add	x1, sp, #0x7b8
    90b8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    90bc:	52800020 	mov	w0, #0x1                   	// #1
    90c0:	f903dff7 	str	x23, [sp, #1976]
    90c4:	f903e3f5 	str	x21, [sp, #1984]
    90c8:	97ffeb96 	bl	3f20 <fwp_data.part.0.constprop.0>
    90cc:	97ffe9a5 	bl	3760 <fwp_rc_fresh>
    90d0:	aa0003e2 	mov	x2, x0
    90d4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    90d8:	911f23e1 	add	x1, sp, #0x7c8
    90dc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    90e0:	52800020 	mov	w0, #0x1                   	// #1
    90e4:	f903e7e3 	str	x3, [sp, #1992]
    90e8:	f903ebe2 	str	x2, [sp, #2000]
    90ec:	97ffeb8d 	bl	3f20 <fwp_data.part.0.constprop.0>
    90f0:	97ffe99c 	bl	3760 <fwp_rc_fresh>
    90f4:	aa0003e2 	mov	x2, x0
    90f8:	911f63e1 	add	x1, sp, #0x7d8
    90fc:	52800020 	mov	w0, #0x1                   	// #1
    9100:	f903eff7 	str	x23, [sp, #2008]
    9104:	f903f3e2 	str	x2, [sp, #2016]
    9108:	97ffeb86 	bl	3f20 <fwp_data.part.0.constprop.0>
    910c:	9114c283 	add	x3, x20, #0x530
    9110:	aa0003f5 	mov	x21, x0
    9114:	f949d861 	ldr	x1, [x3, #5040]
    9118:	f949ec60 	ldr	x0, [x3, #5080]
    911c:	cb0102a1 	sub	x1, x21, x1
    9120:	eb00403f 	cmp	x1, x0, lsl #16
    9124:	54000322 	b.cs	9188 <f0+0x2094>  // b.hs, b.nlast
    9128:	d350fc22 	lsr	x2, x1, #16
    912c:	f949fc63 	ldr	x3, [x3, #5112]
    9130:	8b020842 	add	x2, x2, x2, lsl #2
    9134:	d37df042 	lsl	x2, x2, #3
    9138:	8b020060 	add	x0, x3, x2
    913c:	f9401017 	ldr	x23, [x0, #32]
    9140:	b4000257 	cbz	x23, 9188 <f0+0x2094>
    9144:	38626862 	ldrb	w2, [x3, x2]
    9148:	7100085f 	cmp	w2, #0x2
    914c:	54001d20 	b.eq	94f0 <f0+0x23fc>  // b.none
    9150:	7100045f 	cmp	w2, #0x1
    9154:	540001a1 	b.ne	9188 <f0+0x2094>  // b.any
    9158:	29430002 	ldp	w2, w0, [x0, #24]
    915c:	92403c21 	and	x1, x1, #0xffff
    9160:	9b027c21 	mul	x1, x1, x2
    9164:	d360fc21 	lsr	x1, x1, #32
    9168:	eb00003f 	cmp	x1, x0
    916c:	540000e2 	b.cs	9188 <f0+0x2094>  // b.hs, b.nlast
    9170:	8b0102f7 	add	x23, x23, x1
    9174:	394002e0 	ldrb	w0, [x23]
    9178:	7103fc1f 	cmp	w0, #0xff
    917c:	54002ec0 	b.eq	9754 <f0+0x2660>  // b.none
    9180:	52800020 	mov	w0, #0x1                   	// #1
    9184:	390002e0 	strb	w0, [x23]
    9188:	911fa3e1 	add	x1, sp, #0x7e8
    918c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    9190:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    9194:	52800020 	mov	w0, #0x1                   	// #1
    9198:	f903f7f7 	str	x23, [sp, #2024]
    919c:	f903fbf5 	str	x21, [sp, #2032]
    91a0:	97ffeb60 	bl	3f20 <fwp_data.part.0.constprop.0>
    91a4:	97ffe96f 	bl	3760 <fwp_rc_fresh>
    91a8:	aa0003e2 	mov	x2, x0
    91ac:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    91b0:	911fe3e1 	add	x1, sp, #0x7f8
    91b4:	52800020 	mov	w0, #0x1                   	// #1
    91b8:	f903ffe3 	str	x3, [sp, #2040]
    91bc:	f90403e2 	str	x2, [sp, #2048]
    91c0:	97ffeb58 	bl	3f20 <fwp_data.part.0.constprop.0>
    91c4:	97ffe967 	bl	3760 <fwp_rc_fresh>
    91c8:	aa0003e2 	mov	x2, x0
    91cc:	912023e1 	add	x1, sp, #0x808
    91d0:	52800020 	mov	w0, #0x1                   	// #1
    91d4:	f90407f7 	str	x23, [sp, #2056]
    91d8:	f9040be2 	str	x2, [sp, #2064]
    91dc:	97ffeb51 	bl	3f20 <fwp_data.part.0.constprop.0>
    91e0:	9114c283 	add	x3, x20, #0x530
    91e4:	aa0003f5 	mov	x21, x0
    91e8:	f949d861 	ldr	x1, [x3, #5040]
    91ec:	f949ec60 	ldr	x0, [x3, #5080]
    91f0:	cb0102a1 	sub	x1, x21, x1
    91f4:	eb00403f 	cmp	x1, x0, lsl #16
    91f8:	54000322 	b.cs	925c <f0+0x2168>  // b.hs, b.nlast
    91fc:	d350fc22 	lsr	x2, x1, #16
    9200:	f949fc63 	ldr	x3, [x3, #5112]
    9204:	8b020842 	add	x2, x2, x2, lsl #2
    9208:	d37df042 	lsl	x2, x2, #3
    920c:	8b020060 	add	x0, x3, x2
    9210:	f9401017 	ldr	x23, [x0, #32]
    9214:	b4000257 	cbz	x23, 925c <f0+0x2168>
    9218:	38626862 	ldrb	w2, [x3, x2]
    921c:	7100085f 	cmp	w2, #0x2
    9220:	54001620 	b.eq	94e4 <f0+0x23f0>  // b.none
    9224:	7100045f 	cmp	w2, #0x1
    9228:	540001a1 	b.ne	925c <f0+0x2168>  // b.any
    922c:	29430002 	ldp	w2, w0, [x0, #24]
    9230:	92403c21 	and	x1, x1, #0xffff
    9234:	9b027c21 	mul	x1, x1, x2
    9238:	d360fc21 	lsr	x1, x1, #32
    923c:	eb00003f 	cmp	x1, x0
    9240:	540000e2 	b.cs	925c <f0+0x2168>  // b.hs, b.nlast
    9244:	8b0102f7 	add	x23, x23, x1
    9248:	394002e0 	ldrb	w0, [x23]
    924c:	7103fc1f 	cmp	w0, #0xff
    9250:	54002880 	b.eq	9760 <f0+0x266c>  // b.none
    9254:	52800020 	mov	w0, #0x1                   	// #1
    9258:	390002e0 	strb	w0, [x23]
    925c:	9114c294 	add	x20, x20, #0x530
    9260:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9264:	912063e1 	add	x1, sp, #0x818
    9268:	52800020 	mov	w0, #0x1                   	// #1
    926c:	f9040fe2 	str	x2, [sp, #2072]
    9270:	f90413f5 	str	x21, [sp, #2080]
    9274:	97ffeb2b 	bl	3f20 <fwp_data.part.0.constprop.0>
    9278:	f949da81 	ldr	x1, [x20, #5040]
    927c:	aa0003f5 	mov	x21, x0
    9280:	f949ee80 	ldr	x0, [x20, #5080]
    9284:	cb0102a1 	sub	x1, x21, x1
    9288:	eb00403f 	cmp	x1, x0, lsl #16
    928c:	54000322 	b.cs	92f0 <f0+0x21fc>  // b.hs, b.nlast
    9290:	d350fc22 	lsr	x2, x1, #16
    9294:	f949fe83 	ldr	x3, [x20, #5112]
    9298:	8b020842 	add	x2, x2, x2, lsl #2
    929c:	d37df042 	lsl	x2, x2, #3
    92a0:	8b020060 	add	x0, x3, x2
    92a4:	f9401014 	ldr	x20, [x0, #32]
    92a8:	b4000254 	cbz	x20, 92f0 <f0+0x21fc>
    92ac:	38626862 	ldrb	w2, [x3, x2]
    92b0:	7100085f 	cmp	w2, #0x2
    92b4:	54001120 	b.eq	94d8 <f0+0x23e4>  // b.none
    92b8:	7100045f 	cmp	w2, #0x1
    92bc:	540001a1 	b.ne	92f0 <f0+0x21fc>  // b.any
    92c0:	29430002 	ldp	w2, w0, [x0, #24]
    92c4:	92403c21 	and	x1, x1, #0xffff
    92c8:	9b027c21 	mul	x1, x1, x2
    92cc:	d360fc21 	lsr	x1, x1, #32
    92d0:	eb00003f 	cmp	x1, x0
    92d4:	540000e2 	b.cs	92f0 <f0+0x21fc>  // b.hs, b.nlast
    92d8:	8b010294 	add	x20, x20, x1
    92dc:	39400280 	ldrb	w0, [x20]
    92e0:	7103fc1f 	cmp	w0, #0xff
    92e4:	540015a0 	b.eq	9598 <f0+0x24a4>  // b.none
    92e8:	52800020 	mov	w0, #0x1                   	// #1
    92ec:	39000280 	strb	w0, [x20]
    92f0:	9120a3e1 	add	x1, sp, #0x828
    92f4:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    92f8:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    92fc:	52800020 	mov	w0, #0x1                   	// #1
    9300:	f90417f4 	str	x20, [sp, #2088]
    9304:	f9041bf5 	str	x21, [sp, #2096]
    9308:	97ffeb06 	bl	3f20 <fwp_data.part.0.constprop.0>
    930c:	97ffe915 	bl	3760 <fwp_rc_fresh>
    9310:	aa0003e2 	mov	x2, x0
    9314:	9120e3e1 	add	x1, sp, #0x838
    9318:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    931c:	52800020 	mov	w0, #0x1                   	// #1
    9320:	f9041fe3 	str	x3, [sp, #2104]
    9324:	f90423e2 	str	x2, [sp, #2112]
    9328:	97ffeafe 	bl	3f20 <fwp_data.part.0.constprop.0>
    932c:	97ffe90d 	bl	3760 <fwp_rc_fresh>
    9330:	aa0003e2 	mov	x2, x0
    9334:	aa1603e1 	mov	x1, x22
    9338:	52800020 	mov	w0, #0x1                   	// #1
    933c:	f90427f4 	str	x20, [sp, #2120]
    9340:	f9042be2 	str	x2, [sp, #2128]
    9344:	97ffeaf7 	bl	3f20 <fwp_data.part.0.constprop.0>
    9348:	97ffe906 	bl	3760 <fwp_rc_fresh>
    934c:	aa0003f5 	mov	x21, x0
    9350:	aa1303e1 	mov	x1, x19
    9354:	97fff663 	bl	6ce0 <fwp_hof0.constprop.0>
    9358:	aa0003f4 	mov	x20, x0
    935c:	aa1503e0 	mov	x0, x21
    9360:	97ffeccc 	bl	4690 <fwp_drop0>
    9364:	aa1303e0 	mov	x0, x19
    9368:	97ffecca 	bl	4690 <fwp_drop0>
    936c:	d00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    9370:	f947f400 	ldr	x0, [x0, #4072]
    9374:	f9442fe2 	ldr	x2, [sp, #2136]
    9378:	f9400001 	ldr	x1, [x0]
    937c:	eb010042 	subs	x2, x2, x1
    9380:	d2800001 	mov	x1, #0x0                   	// #0
    9384:	54001f41 	b.ne	976c <f0+0x2678>  // b.any
    9388:	912183ff 	add	sp, sp, #0x860
    938c:	aa1403e0 	mov	x0, x20
    9390:	a94153f3 	ldp	x19, x20, [sp, #16]
    9394:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9398:	a94363f7 	ldp	x23, x24, [sp, #48]
    939c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    93a0:	a94573fb 	ldp	x27, x28, [sp, #80]
    93a4:	a8c67bfd 	ldp	x29, x30, [sp], #96
    93a8:	d65f03c0 	ret
    93ac:	aa1b03e0 	mov	x0, x27
    93b0:	97ffe6e0 	bl	2f30 <fwp_rc_forget_slot>
    93b4:	17fff799 	b	7218 <f0+0x124>
    93b8:	72003c5f 	tst	w2, #0xffff
    93bc:	54fef301 	b.ne	721c <f0+0x128>  // b.any
    93c0:	17fff793 	b	720c <f0+0x118>
    93c4:	72003c3f 	tst	w1, #0xffff
    93c8:	54ff9a81 	b.ne	8718 <f0+0x1624>  // b.any
    93cc:	17fffcce 	b	8704 <f0+0x1610>
    93d0:	72003c3f 	tst	w1, #0xffff
    93d4:	54ff9581 	b.ne	8684 <f0+0x1590>  // b.any
    93d8:	17fffca6 	b	8670 <f0+0x157c>
    93dc:	72003c3f 	tst	w1, #0xffff
    93e0:	54ff8f61 	b.ne	85cc <f0+0x14d8>  // b.any
    93e4:	17fffc75 	b	85b8 <f0+0x14c4>
    93e8:	72003c3f 	tst	w1, #0xffff
    93ec:	54ff8781 	b.ne	84dc <f0+0x13e8>  // b.any
    93f0:	17fffc36 	b	84c8 <f0+0x13d4>
    93f4:	72003c3f 	tst	w1, #0xffff
    93f8:	54ff8261 	b.ne	8444 <f0+0x1350>  // b.any
    93fc:	17fffc0d 	b	8430 <f0+0x133c>
    9400:	72003c3f 	tst	w1, #0xffff
    9404:	54ff7b61 	b.ne	8370 <f0+0x127c>  // b.any
    9408:	17fffbd5 	b	835c <f0+0x1268>
    940c:	72003c3f 	tst	w1, #0xffff
    9410:	54ff7381 	b.ne	8280 <f0+0x118c>  // b.any
    9414:	17fffb96 	b	826c <f0+0x1178>
    9418:	72003c3f 	tst	w1, #0xffff
    941c:	54ff6e61 	b.ne	81e8 <f0+0x10f4>  // b.any
    9420:	17fffb6d 	b	81d4 <f0+0x10e0>
    9424:	72003c3f 	tst	w1, #0xffff
    9428:	54ff0d01 	b.ne	75c8 <f0+0x4d4>  // b.any
    942c:	17fff862 	b	75b4 <f0+0x4c0>
    9430:	72003c3f 	tst	w1, #0xffff
    9434:	54ff0661 	b.ne	7500 <f0+0x40c>  // b.any
    9438:	17fff82d 	b	74ec <f0+0x3f8>
    943c:	72003c3f 	tst	w1, #0xffff
    9440:	54fef901 	b.ne	7360 <f0+0x26c>  // b.any
    9444:	17fff7c2 	b	734c <f0+0x258>
    9448:	72003c3f 	tst	w1, #0xffff
    944c:	54ff2001 	b.ne	784c <f0+0x758>  // b.any
    9450:	17fff8fa 	b	7838 <f0+0x744>
    9454:	72003c3f 	tst	w1, #0xffff
    9458:	54ff1b01 	b.ne	77b8 <f0+0x6c4>  // b.any
    945c:	17fff8d2 	b	77a4 <f0+0x6b0>
    9460:	72003c3f 	tst	w1, #0xffff
    9464:	54ff1621 	b.ne	7728 <f0+0x634>  // b.any
    9468:	17fff8ab 	b	7714 <f0+0x620>
    946c:	72003c3f 	tst	w1, #0xffff
    9470:	54ff1041 	b.ne	7678 <f0+0x584>  // b.any
    9474:	17fff87c 	b	7664 <f0+0x570>
    9478:	72003c3f 	tst	w1, #0xffff
    947c:	54ff6061 	b.ne	8088 <f0+0xf94>  // b.any
    9480:	17fffafd 	b	8074 <f0+0xf80>
    9484:	72003c3f 	tst	w1, #0xffff
    9488:	54ff5501 	b.ne	7f28 <f0+0xe34>  // b.any
    948c:	17fffaa2 	b	7f14 <f0+0xe20>
    9490:	72003c3f 	tst	w1, #0xffff
    9494:	54ff4a81 	b.ne	7de4 <f0+0xcf0>  // b.any
    9498:	17fffa4e 	b	7dd0 <f0+0xcdc>
    949c:	72003c3f 	tst	w1, #0xffff
    94a0:	54ff42a1 	b.ne	7cf4 <f0+0xc00>  // b.any
    94a4:	17fffa0f 	b	7ce0 <f0+0xbec>
    94a8:	72003c3f 	tst	w1, #0xffff
    94ac:	54ff3d81 	b.ne	7c5c <f0+0xb68>  // b.any
    94b0:	17fff9e6 	b	7c48 <f0+0xb54>
    94b4:	72003c3f 	tst	w1, #0xffff
    94b8:	54ff3681 	b.ne	7b88 <f0+0xa94>  // b.any
    94bc:	17fff9ae 	b	7b74 <f0+0xa80>
    94c0:	72003c3f 	tst	w1, #0xffff
    94c4:	54ff2ea1 	b.ne	7a98 <f0+0x9a4>  // b.any
    94c8:	17fff96f 	b	7a84 <f0+0x990>
    94cc:	72003c3f 	tst	w1, #0xffff
    94d0:	54ff26c1 	b.ne	79a8 <f0+0x8b4>  // b.any
    94d4:	17fff930 	b	7994 <f0+0x8a0>
    94d8:	72003c3f 	tst	w1, #0xffff
    94dc:	54fff0a1 	b.ne	92f0 <f0+0x21fc>  // b.any
    94e0:	17ffff7f 	b	92dc <f0+0x21e8>
    94e4:	72003c3f 	tst	w1, #0xffff
    94e8:	54ffeba1 	b.ne	925c <f0+0x2168>  // b.any
    94ec:	17ffff57 	b	9248 <f0+0x2154>
    94f0:	72003c3f 	tst	w1, #0xffff
    94f4:	54ffe4a1 	b.ne	9188 <f0+0x2094>  // b.any
    94f8:	17ffff1f 	b	9174 <f0+0x2080>
    94fc:	72003c3f 	tst	w1, #0xffff
    9500:	54ffdda1 	b.ne	90b4 <f0+0x1fc0>  // b.any
    9504:	17fffee7 	b	90a0 <f0+0x1fac>
    9508:	72003c3f 	tst	w1, #0xffff
    950c:	54ffd881 	b.ne	901c <f0+0x1f28>  // b.any
    9510:	17fffebe 	b	9008 <f0+0x1f14>
    9514:	72003c3f 	tst	w1, #0xffff
    9518:	54ffd181 	b.ne	8f48 <f0+0x1e54>  // b.any
    951c:	17fffe86 	b	8f34 <f0+0x1e40>
    9520:	72003c3f 	tst	w1, #0xffff
    9524:	54ffc9a1 	b.ne	8e58 <f0+0x1d64>  // b.any
    9528:	17fffe47 	b	8e44 <f0+0x1d50>
    952c:	72003c3f 	tst	w1, #0xffff
    9530:	54ffc381 	b.ne	8da0 <f0+0x1cac>  // b.any
    9534:	17fffe16 	b	8d8c <f0+0x1c98>
    9538:	72003c3f 	tst	w1, #0xffff
    953c:	54ffbd61 	b.ne	8ce8 <f0+0x1bf4>  // b.any
    9540:	17fffde5 	b	8cd4 <f0+0x1be0>
    9544:	72003c3f 	tst	w1, #0xffff
    9548:	54ffb841 	b.ne	8c50 <f0+0x1b5c>  // b.any
    954c:	17fffdbc 	b	8c3c <f0+0x1b48>
    9550:	72003c3f 	tst	w1, #0xffff
    9554:	54ffb341 	b.ne	8bbc <f0+0x1ac8>  // b.any
    9558:	17fffd94 	b	8ba8 <f0+0x1ab4>
    955c:	72003c3f 	tst	w1, #0xffff
    9560:	54ffad21 	b.ne	8b04 <f0+0x1a10>  // b.any
    9564:	17fffd63 	b	8af0 <f0+0x19fc>
    9568:	72003c3f 	tst	w1, #0xffff
    956c:	54ffa701 	b.ne	8a4c <f0+0x1958>  // b.any
    9570:	17fffd32 	b	8a38 <f0+0x1944>
    9574:	72003c3f 	tst	w1, #0xffff
    9578:	54ffa0e1 	b.ne	8994 <f0+0x18a0>  // b.any
    957c:	17fffd01 	b	8980 <f0+0x188c>
    9580:	72003c3f 	tst	w1, #0xffff
    9584:	54ff9ac1 	b.ne	88dc <f0+0x17e8>  // b.any
    9588:	17fffcd0 	b	88c8 <f0+0x17d4>
    958c:	72003c3f 	tst	w1, #0xffff
    9590:	54ff94a1 	b.ne	8824 <f0+0x1730>  // b.any
    9594:	17fffc9f 	b	8810 <f0+0x171c>
    9598:	aa1403e0 	mov	x0, x20
    959c:	97ffe665 	bl	2f30 <fwp_rc_forget_slot>
    95a0:	17ffff52 	b	92e8 <f0+0x21f4>
    95a4:	aa1703e0 	mov	x0, x23
    95a8:	97ffe662 	bl	2f30 <fwp_rc_forget_slot>
    95ac:	17fff76b 	b	7358 <f0+0x264>
    95b0:	aa1703e0 	mov	x0, x23
    95b4:	97ffe65f 	bl	2f30 <fwp_rc_forget_slot>
    95b8:	17fff7d0 	b	74f8 <f0+0x404>
    95bc:	aa1703e0 	mov	x0, x23
    95c0:	97ffe65c 	bl	2f30 <fwp_rc_forget_slot>
    95c4:	17fff7ff 	b	75c0 <f0+0x4cc>
    95c8:	aa1703e0 	mov	x0, x23
    95cc:	97ffe659 	bl	2f30 <fwp_rc_forget_slot>
    95d0:	17fff828 	b	7670 <f0+0x57c>
    95d4:	aa1703e0 	mov	x0, x23
    95d8:	97ffe656 	bl	2f30 <fwp_rc_forget_slot>
    95dc:	17fff851 	b	7720 <f0+0x62c>
    95e0:	aa1703e0 	mov	x0, x23
    95e4:	97ffe653 	bl	2f30 <fwp_rc_forget_slot>
    95e8:	17fff872 	b	77b0 <f0+0x6bc>
    95ec:	aa1703e0 	mov	x0, x23
    95f0:	97ffe650 	bl	2f30 <fwp_rc_forget_slot>
    95f4:	17fff894 	b	7844 <f0+0x750>
    95f8:	aa1703e0 	mov	x0, x23
    95fc:	97ffe64d 	bl	2f30 <fwp_rc_forget_slot>
    9600:	17fff8e8 	b	79a0 <f0+0x8ac>
    9604:	aa1703e0 	mov	x0, x23
    9608:	97ffe64a 	bl	2f30 <fwp_rc_forget_slot>
    960c:	17fff921 	b	7a90 <f0+0x99c>
    9610:	aa1703e0 	mov	x0, x23
    9614:	97ffe647 	bl	2f30 <fwp_rc_forget_slot>
    9618:	17fff95a 	b	7b80 <f0+0xa8c>
    961c:	aa1703e0 	mov	x0, x23
    9620:	97ffe644 	bl	2f30 <fwp_rc_forget_slot>
    9624:	17fff98c 	b	7c54 <f0+0xb60>
    9628:	aa1703e0 	mov	x0, x23
    962c:	97ffe641 	bl	2f30 <fwp_rc_forget_slot>
    9630:	17fff9af 	b	7cec <f0+0xbf8>
    9634:	aa1503e0 	mov	x0, x21
    9638:	97ffe63e 	bl	2f30 <fwp_rc_forget_slot>
    963c:	17fff9e8 	b	7ddc <f0+0xce8>
    9640:	aa1703e0 	mov	x0, x23
    9644:	97ffe63b 	bl	2f30 <fwp_rc_forget_slot>
    9648:	17fffa36 	b	7f20 <f0+0xe2c>
    964c:	aa1703e0 	mov	x0, x23
    9650:	97ffe638 	bl	2f30 <fwp_rc_forget_slot>
    9654:	17fffa8b 	b	8080 <f0+0xf8c>
    9658:	aa1703e0 	mov	x0, x23
    965c:	97ffe635 	bl	2f30 <fwp_rc_forget_slot>
    9660:	17fffae0 	b	81e0 <f0+0x10ec>
    9664:	aa1703e0 	mov	x0, x23
    9668:	97ffe632 	bl	2f30 <fwp_rc_forget_slot>
    966c:	17fffb03 	b	8278 <f0+0x1184>
    9670:	aa1703e0 	mov	x0, x23
    9674:	97ffe62f 	bl	2f30 <fwp_rc_forget_slot>
    9678:	17fffb3c 	b	8368 <f0+0x1274>
    967c:	aa1703e0 	mov	x0, x23
    9680:	97ffe62c 	bl	2f30 <fwp_rc_forget_slot>
    9684:	17fffb6e 	b	843c <f0+0x1348>
    9688:	aa1703e0 	mov	x0, x23
    968c:	97ffe629 	bl	2f30 <fwp_rc_forget_slot>
    9690:	17fffb91 	b	84d4 <f0+0x13e0>
    9694:	aa1703e0 	mov	x0, x23
    9698:	97ffe626 	bl	2f30 <fwp_rc_forget_slot>
    969c:	17fffbca 	b	85c4 <f0+0x14d0>
    96a0:	aa1703e0 	mov	x0, x23
    96a4:	97ffe623 	bl	2f30 <fwp_rc_forget_slot>
    96a8:	17fffbf5 	b	867c <f0+0x1588>
    96ac:	aa1703e0 	mov	x0, x23
    96b0:	97ffe620 	bl	2f30 <fwp_rc_forget_slot>
    96b4:	17fffc17 	b	8710 <f0+0x161c>
    96b8:	aa1703e0 	mov	x0, x23
    96bc:	97ffe61d 	bl	2f30 <fwp_rc_forget_slot>
    96c0:	17fffc57 	b	881c <f0+0x1728>
    96c4:	aa1703e0 	mov	x0, x23
    96c8:	97ffe61a 	bl	2f30 <fwp_rc_forget_slot>
    96cc:	17fffc82 	b	88d4 <f0+0x17e0>
    96d0:	aa1703e0 	mov	x0, x23
    96d4:	97ffe617 	bl	2f30 <fwp_rc_forget_slot>
    96d8:	17fffcad 	b	898c <f0+0x1898>
    96dc:	aa1703e0 	mov	x0, x23
    96e0:	97ffe614 	bl	2f30 <fwp_rc_forget_slot>
    96e4:	17fffcd8 	b	8a44 <f0+0x1950>
    96e8:	aa1703e0 	mov	x0, x23
    96ec:	97ffe611 	bl	2f30 <fwp_rc_forget_slot>
    96f0:	17fffd03 	b	8afc <f0+0x1a08>
    96f4:	aa1703e0 	mov	x0, x23
    96f8:	97ffe60e 	bl	2f30 <fwp_rc_forget_slot>
    96fc:	17fffd2e 	b	8bb4 <f0+0x1ac0>
    9700:	aa1703e0 	mov	x0, x23
    9704:	97ffe60b 	bl	2f30 <fwp_rc_forget_slot>
    9708:	17fffd50 	b	8c48 <f0+0x1b54>
    970c:	aa1703e0 	mov	x0, x23
    9710:	97ffe608 	bl	2f30 <fwp_rc_forget_slot>
    9714:	17fffd73 	b	8ce0 <f0+0x1bec>
    9718:	aa1703e0 	mov	x0, x23
    971c:	97ffe605 	bl	2f30 <fwp_rc_forget_slot>
    9720:	17fffd9e 	b	8d98 <f0+0x1ca4>
    9724:	aa1703e0 	mov	x0, x23
    9728:	97ffe602 	bl	2f30 <fwp_rc_forget_slot>
    972c:	17fffdc9 	b	8e50 <f0+0x1d5c>
    9730:	aa1703e0 	mov	x0, x23
    9734:	97ffe5ff 	bl	2f30 <fwp_rc_forget_slot>
    9738:	17fffe02 	b	8f40 <f0+0x1e4c>
    973c:	aa1703e0 	mov	x0, x23
    9740:	97ffe5fc 	bl	2f30 <fwp_rc_forget_slot>
    9744:	17fffe34 	b	9014 <f0+0x1f20>
    9748:	aa1703e0 	mov	x0, x23
    974c:	97ffe5f9 	bl	2f30 <fwp_rc_forget_slot>
    9750:	17fffe57 	b	90ac <f0+0x1fb8>
    9754:	aa1703e0 	mov	x0, x23
    9758:	97ffe5f6 	bl	2f30 <fwp_rc_forget_slot>
    975c:	17fffe89 	b	9180 <f0+0x208c>
    9760:	aa1703e0 	mov	x0, x23
    9764:	97ffe5f3 	bl	2f30 <fwp_rc_forget_slot>
    9768:	17fffebb 	b	9254 <f0+0x2160>
    976c:	97ffdf79 	bl	1550 <__stack_chk_fail@plt>

0000000000009770 <fwp_main_thread>:
    9770:	d10443ff 	sub	sp, sp, #0x110
    9774:	d00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    9778:	f947f400 	ldr	x0, [x0, #4072]
    977c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    9780:	910303fd 	add	x29, sp, #0xc0
    9784:	a90e5bf5 	stp	x21, x22, [sp, #224]
    9788:	90000156 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    978c:	9114c2c1 	add	x1, x22, #0x530
    9790:	a90d53f3 	stp	x19, x20, [sp, #208]
    9794:	a90f63f7 	stp	x23, x24, [sp, #240]
    9798:	b953a421 	ldr	w1, [x1, #5028]
    979c:	a9106bf9 	stp	x25, x26, [sp, #256]
    97a0:	f9400002 	ldr	x2, [x0]
    97a4:	f9005fe2 	str	x2, [sp, #184]
    97a8:	d2800002 	mov	x2, #0x0                   	// #0
    97ac:	34002901 	cbz	w1, 9ccc <fwp_main_thread+0x55c>
    97b0:	9114c2c0 	add	x0, x22, #0x530
    97b4:	b953a800 	ldr	w0, [x0, #5032]
    97b8:	35002820 	cbnz	w0, 9cbc <fwp_main_thread+0x54c>
    97bc:	91001fe2 	add	x2, sp, #0x7
    97c0:	f00000b5 	adrp	x21, 20000 <__data_start>
    97c4:	f00000a3 	adrp	x3, 20000 <__data_start>
    97c8:	910142b3 	add	x19, x21, #0x50
    97cc:	910d4063 	add	x3, x3, #0x350
    97d0:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    97d4:	d2a00025 	mov	x5, #0x10000               	// #65536
    97d8:	910023e0 	add	x0, sp, #0x8
    97dc:	d2800001 	mov	x1, #0x0                   	// #0
    97e0:	f90007e3 	str	x3, [sp, #8]
    97e4:	a9011262 	stp	x2, x4, [x19, #16]
    97e8:	b90013ff 	str	wzr, [sp, #16]
    97ec:	f9000fe5 	str	x5, [sp, #24]
    97f0:	97ffdef4 	bl	13c0 <sigaltstack@plt>
    97f4:	35002840 	cbnz	w0, 9cfc <fwp_main_thread+0x58c>
    97f8:	4f000400 	movi	v0.4s, #0x0
    97fc:	9100a3e0 	add	x0, sp, #0x28
    9800:	90ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    9804:	52800082 	mov	w2, #0x4                   	// #4
    9808:	91324021 	add	x1, x1, #0xc90
    980c:	72a10002 	movk	w2, #0x800, lsl #16
    9810:	910083f4 	add	x20, sp, #0x20
    9814:	f90013e1 	str	x1, [sp, #32]
    9818:	3d802000 	str	q0, [x0, #128]
    981c:	b900abe2 	str	w2, [sp, #168]
    9820:	ad000000 	stp	q0, q0, [x0]
    9824:	ad010000 	stp	q0, q0, [x0, #32]
    9828:	ad020000 	stp	q0, q0, [x0, #64]
    982c:	ad030000 	stp	q0, q0, [x0, #96]
    9830:	97ffdf38 	bl	1510 <sigemptyset@plt>
    9834:	35002640 	cbnz	w0, 9cfc <fwp_main_thread+0x58c>
    9838:	aa1403e1 	mov	x1, x20
    983c:	d2800002 	mov	x2, #0x0                   	// #0
    9840:	52800160 	mov	w0, #0xb                   	// #11
    9844:	97ffdf4b 	bl	1570 <sigaction@plt>
    9848:	350025a0 	cbnz	w0, 9cfc <fwp_main_thread+0x58c>
    984c:	aa1403e1 	mov	x1, x20
    9850:	d2800002 	mov	x2, #0x0                   	// #0
    9854:	528000e0 	mov	w0, #0x7                   	// #7
    9858:	97ffdf46 	bl	1570 <sigaction@plt>
    985c:	35002500 	cbnz	w0, 9cfc <fwp_main_thread+0x58c>
    9860:	9114c2c1 	add	x1, x22, #0x530
    9864:	52800034 	mov	w20, #0x1                   	// #1
    9868:	90ffffc0 	adrp	x0, 1000 <__abi_tag+0xd88>
    986c:	913e4000 	add	x0, x0, #0xf90
    9870:	b9004274 	str	w20, [x19, #64]
    9874:	fd4a1020 	ldr	d0, [x1, #5152]
    9878:	7e61d800 	ucvtf	d0, d0
    987c:	fd015e60 	str	d0, [x19, #696]
    9880:	940002e4 	bl	a410 <atexit>
    9884:	35002420 	cbnz	w0, 9d08 <fwp_main_thread+0x598>
    9888:	b942ca60 	ldr	w0, [x19, #712]
    988c:	34002240 	cbz	w0, 9cd4 <fwp_main_thread+0x564>
    9890:	910142ba 	add	x26, x21, #0x50
    9894:	f9400754 	ldr	x20, [x26, #8]
    9898:	b40010b4 	cbz	x20, 9aac <fwp_main_thread+0x33c>
    989c:	aa1403f3 	mov	x19, x20
    98a0:	91010297 	add	x23, x20, #0x40
    98a4:	39414a99 	ldrb	w25, [x20, #82]
    98a8:	52800038 	mov	w24, #0x1                   	// #1
    98ac:	39014a98 	strb	w24, [x20, #82]
    98b0:	f9401680 	ldr	x0, [x20, #40]
    98b4:	b4000620 	cbz	x0, 9978 <fwp_main_thread+0x208>
    98b8:	f9403281 	ldr	x1, [x20, #96]
    98bc:	39414680 	ldrb	w0, [x20, #81]
    98c0:	b4000b41 	cbz	x1, 9a28 <fwp_main_thread+0x2b8>
    98c4:	36000a80 	tbz	w0, #0, 9a14 <fwp_main_thread+0x2a4>
    98c8:	39414a62 	ldrb	w2, [x19, #82]
    98cc:	f9402280 	ldr	x0, [x20, #64]
    98d0:	37000d62 	tbnz	w2, #0, 9a7c <fwp_main_thread+0x30c>
    98d4:	f9403261 	ldr	x1, [x19, #96]
    98d8:	a911fe77 	stp	x23, xzr, [x19, #280]
    98dc:	f9009660 	str	x0, [x19, #296]
    98e0:	b4000040 	cbz	x0, 98e8 <fwp_main_thread+0x178>
    98e4:	f9009013 	str	x19, [x0, #288]
    98e8:	f9002293 	str	x19, [x20, #64]
    98ec:	b4000101 	cbz	x1, 990c <fwp_main_thread+0x19c>
    98f0:	f9401f40 	ldr	x0, [x26, #56]
    98f4:	39015678 	strb	w24, [x19, #85]
    98f8:	f9003661 	str	x1, [x19, #104]
    98fc:	a910827f 	stp	xzr, x0, [x19, #264]
    9900:	b4000040 	cbz	x0, 9908 <fwp_main_thread+0x198>
    9904:	f9008413 	str	x19, [x0, #264]
    9908:	f9001f53 	str	x19, [x26, #56]
    990c:	39015a7f 	strb	wzr, [x19, #86]
    9910:	97ffe89d 	bl	3b84 <fwp_block>
    9914:	f9408e62 	ldr	x2, [x19, #280]
    9918:	b4000142 	cbz	x2, 9940 <fwp_main_thread+0x1d0>
    991c:	a9520261 	ldp	x1, x0, [x19, #288]
    9920:	b4000ba1 	cbz	x1, 9a94 <fwp_main_thread+0x324>
    9924:	f9009420 	str	x0, [x1, #296]
    9928:	f9409660 	ldr	x0, [x19, #296]
    992c:	b4000040 	cbz	x0, 9934 <fwp_main_thread+0x1c4>
    9930:	f9009001 	str	x1, [x0, #288]
    9934:	91080260 	add	x0, x19, #0x200
    9938:	f900967f 	str	xzr, [x19, #296]
    993c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9940:	39415660 	ldrb	w0, [x19, #85]
    9944:	f9400742 	ldr	x2, [x26, #8]
    9948:	36000960 	tbz	w0, #0, 9a74 <fwp_main_thread+0x304>
    994c:	a9508261 	ldp	x1, x0, [x19, #264]
    9950:	b4000a61 	cbz	x1, 9a9c <fwp_main_thread+0x32c>
    9954:	f9008820 	str	x0, [x1, #272]
    9958:	b4000040 	cbz	x0, 9960 <fwp_main_thread+0x1f0>
    995c:	f9008401 	str	x1, [x0, #264]
    9960:	91080260 	add	x0, x19, #0x200
    9964:	3901567f 	strb	wzr, [x19, #85]
    9968:	aa0203f3 	mov	x19, x2
    996c:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9970:	f9401680 	ldr	x0, [x20, #40]
    9974:	b5fffa20 	cbnz	x0, 98b8 <fwp_main_thread+0x148>
    9978:	910142a0 	add	x0, x21, #0x50
    997c:	39014a99 	strb	w25, [x20, #82]
    9980:	f9414400 	ldr	x0, [x0, #648]
    9984:	b40017e0 	cbz	x0, 9c80 <fwp_main_thread+0x510>
    9988:	910142a0 	add	x0, x21, #0x50
    998c:	f9417001 	ldr	x1, [x0, #736]
    9990:	b902d81f 	str	wzr, [x0, #728]
    9994:	eb13003f 	cmp	x1, x19
    9998:	54001901 	b.ne	9cb8 <fwp_main_thread+0x548>  // b.any
    999c:	b4000933 	cbz	x19, 9ac0 <fwp_main_thread+0x350>
    99a0:	910142a0 	add	x0, x21, #0x50
    99a4:	52800021 	mov	w1, #0x1                   	// #1
    99a8:	39014a61 	strb	w1, [x19, #82]
    99ac:	f9413005 	ldr	x5, [x0, #608]
    99b0:	b4000885 	cbz	x5, 9ac0 <fwp_main_thread+0x350>
    99b4:	d503201f 	nop
    99b8:	394140a0 	ldrb	w0, [x5, #80]
    99bc:	37000060 	tbnz	w0, #0, 99c8 <fwp_main_thread+0x258>
    99c0:	aa0503e0 	mov	x0, x5
    99c4:	97ffe20b 	bl	21f0 <fwp_cancel_tree.part.0>
    99c8:	f9409ca5 	ldr	x5, [x5, #312]
    99cc:	b5ffff65 	cbnz	x5, 99b8 <fwp_main_thread+0x248>
    99d0:	910142b4 	add	x20, x21, #0x50
    99d4:	52800037 	mov	w23, #0x1                   	// #1
    99d8:	f9402a60 	ldr	x0, [x19, #80]
    99dc:	f2001c1f 	tst	x0, #0xff000000ff
    99e0:	540000e1 	b.ne	99fc <fwp_main_thread+0x28c>  // b.any
    99e4:	f9401680 	ldr	x0, [x20, #40]
    99e8:	39015277 	strb	w23, [x19, #84]
    99ec:	f900827f 	str	xzr, [x19, #256]
    99f0:	b40005a0 	cbz	x0, 9aa4 <fwp_main_thread+0x334>
    99f4:	f9008013 	str	x19, [x0, #256]
    99f8:	f9001693 	str	x19, [x20, #40]
    99fc:	97ffe862 	bl	3b84 <fwp_block>
    9a00:	97ffe7f4 	bl	39d0 <fwp_free_zombie>
    9a04:	f9413280 	ldr	x0, [x20, #608]
    9a08:	b40005c0 	cbz	x0, 9ac0 <fwp_main_thread+0x350>
    9a0c:	f9417293 	ldr	x19, [x20, #736]
    9a10:	17fffff2 	b	99d8 <fwp_main_thread+0x268>
    9a14:	97ffe24b 	bl	2340 <fwp_now_ns>
    9a18:	f9403281 	ldr	x1, [x20, #96]
    9a1c:	eb01001f 	cmp	x0, x1
    9a20:	5400122a 	b.ge	9c64 <fwp_main_thread+0x4f4>  // b.tcont
    9a24:	39414680 	ldrb	w0, [x20, #81]
    9a28:	39414a62 	ldrb	w2, [x19, #82]
    9a2c:	3707f500 	tbnz	w0, #0, 98cc <fwp_main_thread+0x15c>
    9a30:	f9403281 	ldr	x1, [x20, #96]
    9a34:	370001c2 	tbnz	w2, #0, 9a6c <fwp_main_thread+0x2fc>
    9a38:	f9403260 	ldr	x0, [x19, #96]
    9a3c:	b4000180 	cbz	x0, 9a6c <fwp_main_thread+0x2fc>
    9a40:	b4000061 	cbz	x1, 9a4c <fwp_main_thread+0x2dc>
    9a44:	eb01001f 	cmp	x0, x1
    9a48:	9a81d000 	csel	x0, x0, x1, le
    9a4c:	f9402281 	ldr	x1, [x20, #64]
    9a50:	a911fe77 	stp	x23, xzr, [x19, #280]
    9a54:	f9009661 	str	x1, [x19, #296]
    9a58:	b4001461 	cbz	x1, 9ce4 <fwp_main_thread+0x574>
    9a5c:	f9009033 	str	x19, [x1, #288]
    9a60:	aa0003e1 	mov	x1, x0
    9a64:	f9002293 	str	x19, [x20, #64]
    9a68:	17ffffa2 	b	98f0 <fwp_main_thread+0x180>
    9a6c:	f9402280 	ldr	x0, [x20, #64]
    9a70:	17ffff9a 	b	98d8 <fwp_main_thread+0x168>
    9a74:	aa0203f3 	mov	x19, x2
    9a78:	17ffff8e 	b	98b0 <fwp_main_thread+0x140>
    9a7c:	a911fe77 	stp	x23, xzr, [x19, #280]
    9a80:	f9009660 	str	x0, [x19, #296]
    9a84:	b4000040 	cbz	x0, 9a8c <fwp_main_thread+0x31c>
    9a88:	f9009013 	str	x19, [x0, #288]
    9a8c:	f9002293 	str	x19, [x20, #64]
    9a90:	17ffff9f 	b	990c <fwp_main_thread+0x19c>
    9a94:	f9000040 	str	x0, [x2]
    9a98:	17ffffa5 	b	992c <fwp_main_thread+0x1bc>
    9a9c:	f9001f40 	str	x0, [x26, #56]
    9aa0:	17ffffae 	b	9958 <fwp_main_thread+0x1e8>
    9aa4:	f9001a93 	str	x19, [x20, #48]
    9aa8:	17ffffd4 	b	99f8 <fwp_main_thread+0x288>
    9aac:	f9414740 	ldr	x0, [x26, #648]
    9ab0:	b4000e60 	cbz	x0, 9c7c <fwp_main_thread+0x50c>
    9ab4:	f9417340 	ldr	x0, [x26, #736]
    9ab8:	b902db5f 	str	wzr, [x26, #728]
    9abc:	b5000fe0 	cbnz	x0, 9cb8 <fwp_main_thread+0x548>
    9ac0:	910142b4 	add	x20, x21, #0x50
    9ac4:	97ffe7c3 	bl	39d0 <fwp_free_zombie>
    9ac8:	f9401a80 	ldr	x0, [x20, #48]
    9acc:	b5000f60 	cbnz	x0, 9cb8 <fwp_main_thread+0x548>
    9ad0:	f9401e80 	ldr	x0, [x20, #56]
    9ad4:	b5000f20 	cbnz	x0, 9cb8 <fwp_main_thread+0x548>
    9ad8:	b9405a93 	ldr	w19, [x20, #88]
    9adc:	340001d3 	cbz	w19, 9b14 <fwp_main_thread+0x3a4>
    9ae0:	93407e77 	sxtw	x23, w19
    9ae4:	51000673 	sub	w19, w19, #0x1
    9ae8:	d1000af7 	sub	x23, x23, #0x2
    9aec:	91018298 	add	x24, x20, #0x60
    9af0:	cb3342f7 	sub	x23, x23, w19, uxtw
    9af4:	93407e73 	sxtw	x19, w19
    9af8:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    9afc:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    9b00:	b9005a93 	str	w19, [x20, #88]
    9b04:	d1000673 	sub	x19, x19, #0x1
    9b08:	97ffdeda 	bl	1670 <munmap@plt>
    9b0c:	eb1302ff 	cmp	x23, x19
    9b10:	54ffff41 	b.ne	9af8 <fwp_main_thread+0x388>  // b.any
    9b14:	f00000b3 	adrp	x19, 20000 <__data_start>
    9b18:	91004260 	add	x0, x19, #0x10
    9b1c:	b9402000 	ldr	w0, [x0, #32]
    9b20:	37f80040 	tbnz	w0, #31, 9b28 <fwp_main_thread+0x3b8>
    9b24:	97ffde8f 	bl	1560 <close@plt>
    9b28:	910142a0 	add	x0, x21, #0x50
    9b2c:	91004261 	add	x1, x19, #0x10
    9b30:	12800002 	mov	w2, #0xffffffff            	// #-1
    9b34:	d2800013 	mov	x19, #0x0                   	// #0
    9b38:	f9417417 	ldr	x23, [x0, #744]
    9b3c:	b9002022 	str	w2, [x1, #32]
    9b40:	f9417814 	ldr	x20, [x0, #752]
    9b44:	b4000177 	cbz	x23, 9b70 <fwp_main_thread+0x400>
    9b48:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    9b4c:	b40000c0 	cbz	x0, 9b64 <fwp_main_thread+0x3f4>
    9b50:	f9400001 	ldr	x1, [x0]
    9b54:	b5000b21 	cbnz	x1, 9cb8 <fwp_main_thread+0x548>
    9b58:	f9400401 	ldr	x1, [x0, #8]
    9b5c:	b5000ae1 	cbnz	x1, 9cb8 <fwp_main_thread+0x548>
    9b60:	97ffe594 	bl	31b0 <fwp_mem_free>
    9b64:	91000673 	add	x19, x19, #0x1
    9b68:	eb1302ff 	cmp	x23, x19
    9b6c:	54fffee1 	b.ne	9b48 <fwp_main_thread+0x3d8>  // b.any
    9b70:	aa1403e0 	mov	x0, x20
    9b74:	97ffe58f 	bl	31b0 <fwp_mem_free>
    9b78:	910142a0 	add	x0, x21, #0x50
    9b7c:	f9417013 	ldr	x19, [x0, #736]
    9b80:	f901741f 	str	xzr, [x0, #744]
    9b84:	f901781f 	str	xzr, [x0, #752]
    9b88:	b40001f3 	cbz	x19, 9bc4 <fwp_main_thread+0x454>
    9b8c:	f9401661 	ldr	x1, [x19, #40]
    9b90:	b5000941 	cbnz	x1, 9cb8 <fwp_main_thread+0x548>
    9b94:	f9405661 	ldr	x1, [x19, #168]
    9b98:	b5000901 	cbnz	x1, 9cb8 <fwp_main_thread+0x548>
    9b9c:	f9414401 	ldr	x1, [x0, #648]
    9ba0:	b50008c1 	cbnz	x1, 9cb8 <fwp_main_thread+0x548>
    9ba4:	f9414c00 	ldr	x0, [x0, #664]
    9ba8:	b5000880 	cbnz	x0, 9cb8 <fwp_main_thread+0x548>
    9bac:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9bb0:	f0000120 	adrp	x0, 30000 <alt.4+0xfcb0>
    9bb4:	910d4000 	add	x0, x0, #0x350
    9bb8:	97ffde5a 	bl	1520 <memset@plt>
    9bbc:	aa1303e0 	mov	x0, x19
    9bc0:	97ffe57c 	bl	31b0 <fwp_mem_free>
    9bc4:	9114c2d6 	add	x22, x22, #0x530
    9bc8:	910142b5 	add	x21, x21, #0x50
    9bcc:	d00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    9bd0:	f947e800 	ldr	x0, [x0, #4048]
    9bd4:	52800041 	mov	w1, #0x2                   	// #2
    9bd8:	fd4a12c0 	ldr	d0, [x22, #5152]
    9bdc:	b0000002 	adrp	x2, a000 <__divti3+0x2e0>
    9be0:	fd415ea1 	ldr	d1, [x21, #696]
    9be4:	91242042 	add	x2, x2, #0x908
    9be8:	f9400000 	ldr	x0, [x0]
    9bec:	7e61d800 	ucvtf	d0, d0
    9bf0:	f94026a5 	ldr	x5, [x21, #72]
    9bf4:	f90006bf 	str	xzr, [x21, #8]
    9bf8:	f94156a3 	ldr	x3, [x21, #680]
    9bfc:	1e613801 	fsub	d1, d0, d1
    9c00:	f9415aa4 	ldr	x4, [x21, #688]
    9c04:	f90012bf 	str	xzr, [x21, #32]
    9c08:	fd4162a0 	ldr	d0, [x21, #704]
    9c0c:	b90042bf 	str	wzr, [x21, #64]
    9c10:	f90172bf 	str	xzr, [x21, #736]
    9c14:	97ffde6b 	bl	15c0 <__fprintf_chk@plt>
    9c18:	d00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    9c1c:	f947ec00 	ldr	x0, [x0, #4056]
    9c20:	f9400000 	ldr	x0, [x0]
    9c24:	97ffde97 	bl	1680 <fflush@plt>
    9c28:	d00000a0 	adrp	x0, 1f000 <__FRAME_END__+0x132b8>
    9c2c:	f947f400 	ldr	x0, [x0, #4072]
    9c30:	f9405fe2 	ldr	x2, [sp, #184]
    9c34:	f9400001 	ldr	x1, [x0]
    9c38:	eb010042 	subs	x2, x2, x1
    9c3c:	d2800001 	mov	x1, #0x0                   	// #0
    9c40:	540006a1 	b.ne	9d14 <fwp_main_thread+0x5a4>  // b.any
    9c44:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    9c48:	d2800000 	mov	x0, #0x0                   	// #0
    9c4c:	a94d53f3 	ldp	x19, x20, [sp, #208]
    9c50:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    9c54:	a94f63f7 	ldp	x23, x24, [sp, #240]
    9c58:	a9506bf9 	ldp	x25, x26, [sp, #256]
    9c5c:	910443ff 	add	sp, sp, #0x110
    9c60:	d65f03c0 	ret
    9c64:	39414280 	ldrb	w0, [x20, #80]
    9c68:	3707ede0 	tbnz	w0, #0, 9a24 <fwp_main_thread+0x2b4>
    9c6c:	aa1403e0 	mov	x0, x20
    9c70:	97ffe160 	bl	21f0 <fwp_cancel_tree.part.0>
    9c74:	39414680 	ldrb	w0, [x20, #81]
    9c78:	17ffff6c 	b	9a28 <fwp_main_thread+0x2b8>
    9c7c:	d2800013 	mov	x19, #0x0                   	// #0
    9c80:	910142b4 	add	x20, x21, #0x50
    9c84:	f9414e80 	ldr	x0, [x20, #664]
    9c88:	b5ffe800 	cbnz	x0, 9988 <fwp_main_thread+0x218>
    9c8c:	f9414280 	ldr	x0, [x20, #640]
    9c90:	97ffe548 	bl	31b0 <fwp_mem_free>
    9c94:	f901429f 	str	xzr, [x20, #640]
    9c98:	f9014a9f 	str	xzr, [x20, #656]
    9c9c:	f9417280 	ldr	x0, [x20, #736]
    9ca0:	b4000293 	cbz	x19, 9cf0 <fwp_main_thread+0x580>
    9ca4:	f900567f 	str	xzr, [x19, #168]
    9ca8:	f9005e7f 	str	xzr, [x19, #184]
    9cac:	b902da9f 	str	wzr, [x20, #728]
    9cb0:	eb13001f 	cmp	x0, x19
    9cb4:	54ffe760 	b.eq	99a0 <fwp_main_thread+0x230>  // b.none
    9cb8:	97ffde3a 	bl	15a0 <abort@plt>
    9cbc:	b0ffffc0 	adrp	x0, 2000 <ad_raw_report+0x70>
    9cc0:	911fc000 	add	x0, x0, #0x7f0
    9cc4:	940001d3 	bl	a410 <atexit>
    9cc8:	17fffebd 	b	97bc <fwp_main_thread+0x4c>
    9ccc:	97ffe322 	bl	2954 <fwp_heap_init>
    9cd0:	17fffeb8 	b	97b0 <fwp_main_thread+0x40>
    9cd4:	97fff508 	bl	70f4 <f0>
    9cd8:	b902ca74 	str	w20, [x19, #712]
    9cdc:	f9016a60 	str	x0, [x19, #720]
    9ce0:	17fffeec 	b	9890 <fwp_main_thread+0x120>
    9ce4:	aa0003e1 	mov	x1, x0
    9ce8:	f9002293 	str	x19, [x20, #64]
    9cec:	17ffff01 	b	98f0 <fwp_main_thread+0x180>
    9cf0:	b902da9f 	str	wzr, [x20, #728]
    9cf4:	b4ffee60 	cbz	x0, 9ac0 <fwp_main_thread+0x350>
    9cf8:	97ffde2a 	bl	15a0 <abort@plt>
    9cfc:	b0000000 	adrp	x0, a000 <__divti3+0x2e0>
    9d00:	91230000 	add	x0, x0, #0x8c0
    9d04:	97ffe17f 	bl	2300 <fwp_trap>
    9d08:	b0000000 	adrp	x0, a000 <__divti3+0x2e0>
    9d0c:	9123a000 	add	x0, x0, #0x8e8
    9d10:	97ffe094 	bl	1f60 <ad_raw_fail>
    9d14:	97ffde0f 	bl	1550 <__stack_chk_fail@plt>
    9d18:	d503201f 	nop
    9d1c:	d503201f 	nop

0000000000009d20 <__divti3>:
    9d20:	d503245f 	bti	c
    9d24:	d2800004 	mov	x4, #0x0                   	// #0
    9d28:	b7f80721 	tbnz	x1, #63, 9e0c <__divti3+0xec>
    9d2c:	b6f80083 	tbz	x3, #63, 9d3c <__divti3+0x1c>
    9d30:	eb0203e2 	negs	x2, x2
    9d34:	aa2403e4 	mvn	x4, x4
    9d38:	da0303e3 	ngc	x3, x3
    9d3c:	aa0203e6 	mov	x6, x2
    9d40:	aa0003e7 	mov	x7, x0
    9d44:	aa0103e5 	mov	x5, x1
    9d48:	b5000583 	cbnz	x3, 9df8 <__divti3+0xd8>
    9d4c:	eb01005f 	cmp	x2, x1
    9d50:	54000e69 	b.ls	9f1c <__divti3+0x1fc>  // b.plast
    9d54:	dac01040 	clz	x0, x2
    9d58:	b40000e0 	cbz	x0, 9d74 <__divti3+0x54>
    9d5c:	4b0003e1 	neg	w1, w0
    9d60:	9ac020a5 	lsl	x5, x5, x0
    9d64:	9ac02046 	lsl	x6, x2, x0
    9d68:	9ac124e1 	lsr	x1, x7, x1
    9d6c:	aa050025 	orr	x5, x1, x5
    9d70:	9ac020e7 	lsl	x7, x7, x0
    9d74:	d360fcc8 	lsr	x8, x6, #32
    9d78:	92407cc2 	and	x2, x6, #0xffffffff
    9d7c:	9ac808a3 	udiv	x3, x5, x8
    9d80:	9b089465 	msub	x5, x3, x8, x5
    9d84:	aa0303e0 	mov	x0, x3
    9d88:	9b037c41 	mul	x1, x2, x3
    9d8c:	93c780a5 	extr	x5, x5, x7, #32
    9d90:	eb05003f 	cmp	x1, x5
    9d94:	540000a9 	b.ls	9da8 <__divti3+0x88>  // b.plast
    9d98:	ab0500c5 	adds	x5, x6, x5
    9d9c:	d1000460 	sub	x0, x3, #0x1
    9da0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    9da4:	540015a8 	b.hi	a058 <__divti3+0x338>  // b.pmore
    9da8:	cb0100a5 	sub	x5, x5, x1
    9dac:	9ac808a3 	udiv	x3, x5, x8
    9db0:	9b089465 	msub	x5, x3, x8, x5
    9db4:	aa0303e1 	mov	x1, x3
    9db8:	9b037c42 	mul	x2, x2, x3
    9dbc:	aa0703e3 	mov	x3, x7
    9dc0:	b3607ca3 	bfi	x3, x5, #32, #32
    9dc4:	eb03005f 	cmp	x2, x3
    9dc8:	540000c9 	b.ls	9de0 <__divti3+0xc0>  // b.plast
    9dcc:	ab0300c3 	adds	x3, x6, x3
    9dd0:	d1000425 	sub	x5, x1, #0x1
    9dd4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9dd8:	d1000821 	sub	x1, x1, #0x2
    9ddc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    9de0:	aa008020 	orr	x0, x1, x0, lsl #32
    9de4:	d2800001 	mov	x1, #0x0                   	// #0
    9de8:	b4000064 	cbz	x4, 9df4 <__divti3+0xd4>
    9dec:	eb0003e0 	negs	x0, x0
    9df0:	da0103e1 	ngc	x1, x1
    9df4:	d65f03c0 	ret
    9df8:	eb01007f 	cmp	x3, x1
    9dfc:	54000109 	b.ls	9e1c <__divti3+0xfc>  // b.plast
    9e00:	d2800001 	mov	x1, #0x0                   	// #0
    9e04:	d2800000 	mov	x0, #0x0                   	// #0
    9e08:	17fffff8 	b	9de8 <__divti3+0xc8>
    9e0c:	eb0003e0 	negs	x0, x0
    9e10:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9e14:	da0103e1 	ngc	x1, x1
    9e18:	17ffffc5 	b	9d2c <__divti3+0xc>
    9e1c:	dac01067 	clz	x7, x3
    9e20:	b40010e7 	cbz	x7, a03c <__divti3+0x31c>
    9e24:	d2800805 	mov	x5, #0x40                  	// #64
    9e28:	cb0700a5 	sub	x5, x5, x7
    9e2c:	9ac72063 	lsl	x3, x3, x7
    9e30:	9ac52448 	lsr	x8, x2, x5
    9e34:	aa030108 	orr	x8, x8, x3
    9e38:	9ac52426 	lsr	x6, x1, x5
    9e3c:	92407d0a 	and	x10, x8, #0xffffffff
    9e40:	d360fd09 	lsr	x9, x8, #32
    9e44:	9ac52403 	lsr	x3, x0, x5
    9e48:	9ac72021 	lsl	x1, x1, x7
    9e4c:	aa010063 	orr	x3, x3, x1
    9e50:	9ac72042 	lsl	x2, x2, x7
    9e54:	9ac908cb 	udiv	x11, x6, x9
    9e58:	9b099965 	msub	x5, x11, x9, x6
    9e5c:	aa0b03e1 	mov	x1, x11
    9e60:	9b0b7d46 	mul	x6, x10, x11
    9e64:	93c380a5 	extr	x5, x5, x3, #32
    9e68:	eb0500df 	cmp	x6, x5
    9e6c:	540000a9 	b.ls	9e80 <__divti3+0x160>  // b.plast
    9e70:	ab050105 	adds	x5, x8, x5
    9e74:	d1000561 	sub	x1, x11, #0x1
    9e78:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    9e7c:	54000f48 	b.hi	a064 <__divti3+0x344>  // b.pmore
    9e80:	cb0600a6 	sub	x6, x5, x6
    9e84:	9ac908cb 	udiv	x11, x6, x9
    9e88:	9b099969 	msub	x9, x11, x9, x6
    9e8c:	aa0b03e5 	mov	x5, x11
    9e90:	9b0b7d4a 	mul	x10, x10, x11
    9e94:	b3607d23 	bfi	x3, x9, #32, #32
    9e98:	eb03015f 	cmp	x10, x3
    9e9c:	540000a9 	b.ls	9eb0 <__divti3+0x190>  // b.plast
    9ea0:	ab030103 	adds	x3, x8, x3
    9ea4:	d1000565 	sub	x5, x11, #0x1
    9ea8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    9eac:	54000e28 	b.hi	a070 <__divti3+0x350>  // b.pmore
    9eb0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    9eb4:	92407c48 	and	x8, x2, #0xffffffff
    9eb8:	2a0503e5 	mov	w5, w5
    9ebc:	d360fc42 	lsr	x2, x2, #32
    9ec0:	d360fc26 	lsr	x6, x1, #32
    9ec4:	cb0a0063 	sub	x3, x3, x10
    9ec8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    9ecc:	9b087caa 	mul	x10, x5, x8
    9ed0:	9b087cc8 	mul	x8, x6, x8
    9ed4:	9b0220a5 	madd	x5, x5, x2, x8
    9ed8:	9b027cc6 	mul	x6, x6, x2
    9edc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    9ee0:	8b0900c5 	add	x5, x6, x9
    9ee4:	eb02011f 	cmp	x8, x2
    9ee8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    9eec:	8b4280c6 	add	x6, x6, x2, lsr #32
    9ef0:	eb06007f 	cmp	x3, x6
    9ef4:	540000e3 	b.cc	9f10 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    9ef8:	92407d4a 	and	x10, x10, #0xffffffff
    9efc:	9ac72000 	lsl	x0, x0, x7
    9f00:	8b028142 	add	x2, x10, x2, lsl #32
    9f04:	eb02001f 	cmp	x0, x2
    9f08:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    9f0c:	54000a01 	b.ne	a04c <__divti3+0x32c>  // b.any
    9f10:	d1000420 	sub	x0, x1, #0x1
    9f14:	d2800001 	mov	x1, #0x0                   	// #0
    9f18:	17ffffb4 	b	9de8 <__divti3+0xc8>
    9f1c:	b5000062 	cbnz	x2, 9f28 <__divti3+0x208>
    9f20:	d2800022 	mov	x2, #0x1                   	// #1
    9f24:	9ac30846 	udiv	x6, x2, x3
    9f28:	dac010c8 	clz	x8, x6
    9f2c:	b5000408 	cbnz	x8, 9fac <__divti3+0x28c>
    9f30:	d360fcc9 	lsr	x9, x6, #32
    9f34:	92407cc5 	and	x5, x6, #0xffffffff
    9f38:	cb060023 	sub	x3, x1, x6
    9f3c:	d2800021 	mov	x1, #0x1                   	// #1
    9f40:	9ac90868 	udiv	x8, x3, x9
    9f44:	9b098d03 	msub	x3, x8, x9, x3
    9f48:	aa0803e0 	mov	x0, x8
    9f4c:	9b057d02 	mul	x2, x8, x5
    9f50:	93c78063 	extr	x3, x3, x7, #32
    9f54:	eb03005f 	cmp	x2, x3
    9f58:	540000a9 	b.ls	9f6c <__divti3+0x24c>  // b.plast
    9f5c:	ab0300c3 	adds	x3, x6, x3
    9f60:	d1000500 	sub	x0, x8, #0x1
    9f64:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9f68:	54000968 	b.hi	a094 <__divti3+0x374>  // b.pmore
    9f6c:	cb020063 	sub	x3, x3, x2
    9f70:	9ac90862 	udiv	x2, x3, x9
    9f74:	aa0203e8 	mov	x8, x2
    9f78:	9b098c42 	msub	x2, x2, x9, x3
    9f7c:	aa0703e3 	mov	x3, x7
    9f80:	9b057d05 	mul	x5, x8, x5
    9f84:	b3607c43 	bfi	x3, x2, #32, #32
    9f88:	eb0300bf 	cmp	x5, x3
    9f8c:	540000c9 	b.ls	9fa4 <__divti3+0x284>  // b.plast
    9f90:	ab0300c2 	adds	x2, x6, x3
    9f94:	d1000503 	sub	x3, x8, #0x1
    9f98:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    9f9c:	d1000908 	sub	x8, x8, #0x2
    9fa0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    9fa4:	aa008100 	orr	x0, x8, x0, lsl #32
    9fa8:	17ffff90 	b	9de8 <__divti3+0xc8>
    9fac:	9ac820c6 	lsl	x6, x6, x8
    9fb0:	d2800803 	mov	x3, #0x40                  	// #64
    9fb4:	cb080063 	sub	x3, x3, x8
    9fb8:	d360fcc9 	lsr	x9, x6, #32
    9fbc:	9ac82027 	lsl	x7, x1, x8
    9fc0:	92407cc5 	and	x5, x6, #0xffffffff
    9fc4:	9ac32422 	lsr	x2, x1, x3
    9fc8:	9ac32403 	lsr	x3, x0, x3
    9fcc:	aa070063 	orr	x3, x3, x7
    9fd0:	9ac9084a 	udiv	x10, x2, x9
    9fd4:	9ac82007 	lsl	x7, x0, x8
    9fd8:	9b098940 	msub	x0, x10, x9, x2
    9fdc:	aa0a03e1 	mov	x1, x10
    9fe0:	9b0a7ca2 	mul	x2, x5, x10
    9fe4:	93c38000 	extr	x0, x0, x3, #32
    9fe8:	eb00005f 	cmp	x2, x0
    9fec:	540000a9 	b.ls	a000 <__divti3+0x2e0>  // b.plast
    9ff0:	ab0000c0 	adds	x0, x6, x0
    9ff4:	d1000541 	sub	x1, x10, #0x1
    9ff8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    9ffc:	54000468 	b.hi	a088 <__divti3+0x368>  // b.pmore
    a000:	cb020000 	sub	x0, x0, x2
    a004:	9ac9080a 	udiv	x10, x0, x9
    a008:	9b098140 	msub	x0, x10, x9, x0
    a00c:	aa0a03e2 	mov	x2, x10
    a010:	9b0a7ca8 	mul	x8, x5, x10
    a014:	b3607c03 	bfi	x3, x0, #32, #32
    a018:	eb03011f 	cmp	x8, x3
    a01c:	540000a9 	b.ls	a030 <__divti3+0x310>  // b.plast
    a020:	ab0300c3 	adds	x3, x6, x3
    a024:	d1000542 	sub	x2, x10, #0x1
    a028:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    a02c:	54000288 	b.hi	a07c <__divti3+0x35c>  // b.pmore
    a030:	cb080063 	sub	x3, x3, x8
    a034:	aa018041 	orr	x1, x2, x1, lsl #32
    a038:	17ffffc2 	b	9f40 <__divti3+0x220>
    a03c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    a040:	d2800001 	mov	x1, #0x0                   	// #0
    a044:	9a9f87e0 	cset	x0, ls	// ls = plast
    a048:	17ffff68 	b	9de8 <__divti3+0xc8>
    a04c:	aa0103e0 	mov	x0, x1
    a050:	d2800001 	mov	x1, #0x0                   	// #0
    a054:	17ffff65 	b	9de8 <__divti3+0xc8>
    a058:	d1000860 	sub	x0, x3, #0x2
    a05c:	8b0600a5 	add	x5, x5, x6
    a060:	17ffff52 	b	9da8 <__divti3+0x88>
    a064:	d1000961 	sub	x1, x11, #0x2
    a068:	8b0800a5 	add	x5, x5, x8
    a06c:	17ffff85 	b	9e80 <__divti3+0x160>
    a070:	d1000965 	sub	x5, x11, #0x2
    a074:	8b080063 	add	x3, x3, x8
    a078:	17ffff8e 	b	9eb0 <__divti3+0x190>
    a07c:	d1000942 	sub	x2, x10, #0x2
    a080:	8b060063 	add	x3, x3, x6
    a084:	17ffffeb 	b	a030 <__divti3+0x310>
    a088:	d1000941 	sub	x1, x10, #0x2
    a08c:	8b060000 	add	x0, x0, x6
    a090:	17ffffdc 	b	a000 <__divti3+0x2e0>
    a094:	d1000900 	sub	x0, x8, #0x2
    a098:	8b060063 	add	x3, x3, x6
    a09c:	17ffffb4 	b	9f6c <__divti3+0x24c>

000000000000a0a0 <__modti3>:
    a0a0:	d503245f 	bti	c
    a0a4:	d2800004 	mov	x4, #0x0                   	// #0
    a0a8:	b6f80081 	tbz	x1, #63, a0b8 <__modti3+0x18>
    a0ac:	eb0003e0 	negs	x0, x0
    a0b0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a0b4:	da0103e1 	ngc	x1, x1
    a0b8:	f100007f 	cmp	x3, #0x0
    a0bc:	5400128b 	b.lt	a30c <__modti3+0x26c>  // b.tstop
    a0c0:	aa0003e7 	mov	x7, x0
    a0c4:	aa0103e6 	mov	x6, x1
    a0c8:	540004e1 	b.ne	a164 <__modti3+0xc4>  // b.any
    a0cc:	eb02003f 	cmp	x1, x2
    a0d0:	54000dc2 	b.cs	a288 <__modti3+0x1e8>  // b.hs, b.nlast
    a0d4:	dac01043 	clz	x3, x2
    a0d8:	aa0303e5 	mov	x5, x3
    a0dc:	b40000e3 	cbz	x3, a0f8 <__modti3+0x58>
    a0e0:	4b0303e6 	neg	w6, w3
    a0e4:	9ac32021 	lsl	x1, x1, x3
    a0e8:	9ac32042 	lsl	x2, x2, x3
    a0ec:	9ac62406 	lsr	x6, x0, x6
    a0f0:	aa0100c6 	orr	x6, x6, x1
    a0f4:	9ac32007 	lsl	x7, x0, x3
    a0f8:	d360fc40 	lsr	x0, x2, #32
    a0fc:	92407c43 	and	x3, x2, #0xffffffff
    a100:	9ac008c1 	udiv	x1, x6, x0
    a104:	9b009826 	msub	x6, x1, x0, x6
    a108:	9b017c61 	mul	x1, x3, x1
    a10c:	93c780c6 	extr	x6, x6, x7, #32
    a110:	eb06003f 	cmp	x1, x6
    a114:	540000a9 	b.ls	a128 <__modti3+0x88>  // b.plast
    a118:	ab060046 	adds	x6, x2, x6
    a11c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    a120:	8b0200c8 	add	x8, x6, x2
    a124:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    a128:	cb0100c6 	sub	x6, x6, x1
    a12c:	9ac008c8 	udiv	x8, x6, x0
    a130:	9b009901 	msub	x1, x8, x0, x6
    a134:	aa0703e0 	mov	x0, x7
    a138:	9b087c63 	mul	x3, x3, x8
    a13c:	b3607c20 	bfi	x0, x1, #32, #32
    a140:	eb00007f 	cmp	x3, x0
    a144:	54001088 	b.hi	a354 <__modti3+0x2b4>  // b.pmore
    a148:	cb030000 	sub	x0, x0, x3
    a14c:	9ac52400 	lsr	x0, x0, x5
    a150:	d2800001 	mov	x1, #0x0                   	// #0
    a154:	b4000064 	cbz	x4, a160 <__modti3+0xc0>
    a158:	eb0003e0 	negs	x0, x0
    a15c:	da0103e1 	ngc	x1, x1
    a160:	d65f03c0 	ret
    a164:	dac01066 	clz	x6, x3
    a168:	eb03003f 	cmp	x1, x3
    a16c:	54ffff43 	b.cc	a154 <__modti3+0xb4>  // b.lo, b.ul, b.last
    a170:	93407cc5 	sxtw	x5, w6
    a174:	d2800808 	mov	x8, #0x40                  	// #64
    a178:	cb050108 	sub	x8, x8, x5
    a17c:	9ac62063 	lsl	x3, x3, x6
    a180:	9ac62025 	lsl	x5, x1, x6
    a184:	9ac82447 	lsr	x7, x2, x8
    a188:	aa0300e7 	orr	x7, x7, x3
    a18c:	9ac82423 	lsr	x3, x1, x8
    a190:	92407cec 	and	x12, x7, #0xffffffff
    a194:	d360fcea 	lsr	x10, x7, #32
    a198:	9ac82401 	lsr	x1, x0, x8
    a19c:	aa050021 	orr	x1, x1, x5
    a1a0:	9ac62042 	lsl	x2, x2, x6
    a1a4:	9ac62000 	lsl	x0, x0, x6
    a1a8:	9aca086b 	udiv	x11, x3, x10
    a1ac:	9b0a8d63 	msub	x3, x11, x10, x3
    a1b0:	aa0b03e5 	mov	x5, x11
    a1b4:	9b0b7d89 	mul	x9, x12, x11
    a1b8:	93c18063 	extr	x3, x3, x1, #32
    a1bc:	eb03013f 	cmp	x9, x3
    a1c0:	540000a9 	b.ls	a1d4 <__modti3+0x134>  // b.plast
    a1c4:	ab0300e3 	adds	x3, x7, x3
    a1c8:	d1000565 	sub	x5, x11, #0x1
    a1cc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    a1d0:	54001168 	b.hi	a3fc <__modti3+0x35c>  // b.pmore
    a1d4:	cb090063 	sub	x3, x3, x9
    a1d8:	9aca086b 	udiv	x11, x3, x10
    a1dc:	9b0a8d6a 	msub	x10, x11, x10, x3
    a1e0:	aa0b03e9 	mov	x9, x11
    a1e4:	9b0b7d8c 	mul	x12, x12, x11
    a1e8:	b3607d41 	bfi	x1, x10, #32, #32
    a1ec:	eb01019f 	cmp	x12, x1
    a1f0:	540000a9 	b.ls	a204 <__modti3+0x164>  // b.plast
    a1f4:	ab0100e1 	adds	x1, x7, x1
    a1f8:	d1000569 	sub	x9, x11, #0x1
    a1fc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    a200:	54000f88 	b.hi	a3f0 <__modti3+0x350>  // b.pmore
    a204:	aa058123 	orr	x3, x9, x5, lsl #32
    a208:	92407c4b 	and	x11, x2, #0xffffffff
    a20c:	2a0903e9 	mov	w9, w9
    a210:	d360fc4a 	lsr	x10, x2, #32
    a214:	d360fc63 	lsr	x3, x3, #32
    a218:	cb0c0021 	sub	x1, x1, x12
    a21c:	aa0a03ec 	mov	x12, x10
    a220:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    a224:	9b0b7d25 	mul	x5, x9, x11
    a228:	9b0b7c6b 	mul	x11, x3, x11
    a22c:	9b0a2d29 	madd	x9, x9, x10, x11
    a230:	92407caa 	and	x10, x5, #0xffffffff
    a234:	9b0c7c63 	mul	x3, x3, x12
    a238:	8b458125 	add	x5, x9, x5, lsr #32
    a23c:	8b0d0069 	add	x9, x3, x13
    a240:	eb05017f 	cmp	x11, x5
    a244:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    a248:	8b058149 	add	x9, x10, x5, lsl #32
    a24c:	8b458063 	add	x3, x3, x5, lsr #32
    a250:	eb03003f 	cmp	x1, x3
    a254:	54000063 	b.cc	a260 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    a258:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    a25c:	54000082 	b.cs	a26c <__modti3+0x1cc>  // b.hs, b.nlast
    a260:	eb020129 	subs	x9, x9, x2
    a264:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    a268:	cb070063 	sub	x3, x3, x7
    a26c:	eb090000 	subs	x0, x0, x9
    a270:	da030021 	sbc	x1, x1, x3
    a274:	9ac62400 	lsr	x0, x0, x6
    a278:	9ac82028 	lsl	x8, x1, x8
    a27c:	aa000100 	orr	x0, x8, x0
    a280:	9ac62421 	lsr	x1, x1, x6
    a284:	17ffffb4 	b	a154 <__modti3+0xb4>
    a288:	b5000062 	cbnz	x2, a294 <__modti3+0x1f4>
    a28c:	d2800023 	mov	x3, #0x1                   	// #1
    a290:	9ac20862 	udiv	x2, x3, x2
    a294:	dac01048 	clz	x8, x2
    a298:	aa0803e5 	mov	x5, x8
    a29c:	b5000668 	cbnz	x8, a368 <__modti3+0x2c8>
    a2a0:	cb020020 	sub	x0, x1, x2
    a2a4:	d360fc49 	lsr	x9, x2, #32
    a2a8:	92407c4a 	and	x10, x2, #0xffffffff
    a2ac:	9ac90801 	udiv	x1, x0, x9
    a2b0:	9b098020 	msub	x0, x1, x9, x0
    a2b4:	9b0a7c21 	mul	x1, x1, x10
    a2b8:	93c78000 	extr	x0, x0, x7, #32
    a2bc:	eb00003f 	cmp	x1, x0
    a2c0:	540000a9 	b.ls	a2d4 <__modti3+0x234>  // b.plast
    a2c4:	ab000040 	adds	x0, x2, x0
    a2c8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a2cc:	8b020003 	add	x3, x0, x2
    a2d0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a2d4:	cb010001 	sub	x1, x0, x1
    a2d8:	9ac90820 	udiv	x0, x1, x9
    a2dc:	9b098403 	msub	x3, x0, x9, x1
    a2e0:	aa0703e1 	mov	x1, x7
    a2e4:	9b0a7c00 	mul	x0, x0, x10
    a2e8:	b3607c61 	bfi	x1, x3, #32, #32
    a2ec:	eb01001f 	cmp	x0, x1
    a2f0:	540000a9 	b.ls	a304 <__modti3+0x264>  // b.plast
    a2f4:	ab010041 	adds	x1, x2, x1
    a2f8:	8b020022 	add	x2, x1, x2
    a2fc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    a300:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    a304:	cb000020 	sub	x0, x1, x0
    a308:	17ffff91 	b	a14c <__modti3+0xac>
    a30c:	eb0203e5 	negs	x5, x2
    a310:	aa0003e7 	mov	x7, x0
    a314:	da0303e8 	ngc	x8, x3
    a318:	aa0503e2 	mov	x2, x5
    a31c:	aa0803e3 	mov	x3, x8
    a320:	aa0103e6 	mov	x6, x1
    a324:	b4ffed48 	cbz	x8, a0cc <__modti3+0x2c>
    a328:	eb01011f 	cmp	x8, x1
    a32c:	54fff148 	b.hi	a154 <__modti3+0xb4>  // b.pmore
    a330:	dac01109 	clz	x9, x8
    a334:	2a0903e6 	mov	w6, w9
    a338:	b5fff1c9 	cbnz	x9, a170 <__modti3+0xd0>
    a33c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    a340:	54000068 	b.hi	a34c <__modti3+0x2ac>  // b.pmore
    a344:	eb050007 	subs	x7, x0, x5
    a348:	da080021 	sbc	x1, x1, x8
    a34c:	aa0703e0 	mov	x0, x7
    a350:	17ffff81 	b	a154 <__modti3+0xb4>
    a354:	ab000040 	adds	x0, x2, x0
    a358:	8b020002 	add	x2, x0, x2
    a35c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    a360:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    a364:	17ffff79 	b	a148 <__modti3+0xa8>
    a368:	9ac82042 	lsl	x2, x2, x8
    a36c:	d2800803 	mov	x3, #0x40                  	// #64
    a370:	cb080063 	sub	x3, x3, x8
    a374:	d360fc49 	lsr	x9, x2, #32
    a378:	9ac82027 	lsl	x7, x1, x8
    a37c:	92407c4a 	and	x10, x2, #0xffffffff
    a380:	9ac32426 	lsr	x6, x1, x3
    a384:	9ac32403 	lsr	x3, x0, x3
    a388:	aa070063 	orr	x3, x3, x7
    a38c:	9ac908c1 	udiv	x1, x6, x9
    a390:	9ac82007 	lsl	x7, x0, x8
    a394:	9b099820 	msub	x0, x1, x9, x6
    a398:	9b017d41 	mul	x1, x10, x1
    a39c:	93c38000 	extr	x0, x0, x3, #32
    a3a0:	eb00003f 	cmp	x1, x0
    a3a4:	540000a9 	b.ls	a3b8 <__modti3+0x318>  // b.plast
    a3a8:	ab000040 	adds	x0, x2, x0
    a3ac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a3b0:	8b020006 	add	x6, x0, x2
    a3b4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    a3b8:	cb010000 	sub	x0, x0, x1
    a3bc:	9ac90801 	udiv	x1, x0, x9
    a3c0:	9b098026 	msub	x6, x1, x9, x0
    a3c4:	aa0303e0 	mov	x0, x3
    a3c8:	9b017d41 	mul	x1, x10, x1
    a3cc:	b3607cc0 	bfi	x0, x6, #32, #32
    a3d0:	eb00003f 	cmp	x1, x0
    a3d4:	540000a9 	b.ls	a3e8 <__modti3+0x348>  // b.plast
    a3d8:	ab000040 	adds	x0, x2, x0
    a3dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a3e0:	8b020003 	add	x3, x0, x2
    a3e4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    a3e8:	cb010000 	sub	x0, x0, x1
    a3ec:	17ffffb0 	b	a2ac <__modti3+0x20c>
    a3f0:	d1000969 	sub	x9, x11, #0x2
    a3f4:	8b070021 	add	x1, x1, x7
    a3f8:	17ffff83 	b	a204 <__modti3+0x164>
    a3fc:	d1000965 	sub	x5, x11, #0x2
    a400:	8b070063 	add	x3, x3, x7
    a404:	17ffff74 	b	a1d4 <__modti3+0x134>
    a408:	d503201f 	nop
    a40c:	d503201f 	nop

000000000000a410 <atexit>:
    a410:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    a414:	d00000a2 	adrp	x2, 20000 <__data_start>
    a418:	d2800001 	mov	x1, #0x0                   	// #0
    a41c:	910003fd 	mov	x29, sp
    a420:	a8c17bfd 	ldp	x29, x30, [sp], #16
    a424:	f9400442 	ldr	x2, [x2, #8]
    a428:	17ffdc0a 	b	1450 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000a42c <_fini>:
    a42c:	d503201f 	nop
    a430:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    a434:	910003fd 	mov	x29, sp
    a438:	a8c17bfd 	ldp	x29, x30, [sp], #16
    a43c:	d65f03c0 	ret
