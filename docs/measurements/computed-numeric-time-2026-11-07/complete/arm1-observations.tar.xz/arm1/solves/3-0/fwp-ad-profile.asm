
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-0/fwp-ad-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002680 <_init>:
    2680:	d503201f 	nop
    2684:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2688:	910003fd 	mov	x29, sp
    268c:	9400019a 	bl	2cf4 <call_weak_fn>
    2690:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2694:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026a0 <.plt>:
    26a0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26a4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26a8:	f946fe11 	ldr	x17, [x16, #3576]
    26ac:	9137e210 	add	x16, x16, #0xdf8
    26b0:	d61f0220 	br	x17
    26b4:	d503201f 	nop
    26b8:	d503201f 	nop
    26bc:	d503201f 	nop

00000000000026c0 <memcpy@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26c4:	f9470211 	ldr	x17, [x16, #3584]
    26c8:	91380210 	add	x16, x16, #0xe00
    26cc:	d61f0220 	br	x17

00000000000026d0 <sigaltstack@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26d4:	f9470611 	ldr	x17, [x16, #3592]
    26d8:	91382210 	add	x16, x16, #0xe08
    26dc:	d61f0220 	br	x17

00000000000026e0 <_exit@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26e4:	f9470a11 	ldr	x17, [x16, #3600]
    26e8:	91384210 	add	x16, x16, #0xe10
    26ec:	d61f0220 	br	x17

00000000000026f0 <strlen@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26f4:	f9470e11 	ldr	x17, [x16, #3608]
    26f8:	91386210 	add	x16, x16, #0xe18
    26fc:	d61f0220 	br	x17

0000000000002700 <__sprintf_chk@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2704:	f9471211 	ldr	x17, [x16, #3616]
    2708:	91388210 	add	x16, x16, #0xe20
    270c:	d61f0220 	br	x17

0000000000002710 <exit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2714:	f9471611 	ldr	x17, [x16, #3624]
    2718:	9138a210 	add	x16, x16, #0xe28
    271c:	d61f0220 	br	x17

0000000000002720 <__libc_start_main@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2724:	f9471a11 	ldr	x17, [x16, #3632]
    2728:	9138c210 	add	x16, x16, #0xe30
    272c:	d61f0220 	br	x17

0000000000002730 <strtoll@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2734:	f9471e11 	ldr	x17, [x16, #3640]
    2738:	9138e210 	add	x16, x16, #0xe38
    273c:	d61f0220 	br	x17

0000000000002740 <strtod@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2744:	f9472211 	ldr	x17, [x16, #3648]
    2748:	91390210 	add	x16, x16, #0xe40
    274c:	d61f0220 	br	x17

0000000000002750 <__cxa_finalize@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2754:	f9472611 	ldr	x17, [x16, #3656]
    2758:	91392210 	add	x16, x16, #0xe48
    275c:	d61f0220 	br	x17

0000000000002760 <__cxa_atexit@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2764:	f9472a11 	ldr	x17, [x16, #3664]
    2768:	91394210 	add	x16, x16, #0xe50
    276c:	d61f0220 	br	x17

0000000000002770 <pthread_attr_init@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2774:	f9472e11 	ldr	x17, [x16, #3672]
    2778:	91396210 	add	x16, x16, #0xe58
    277c:	d61f0220 	br	x17

0000000000002780 <fputc@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2784:	f9473211 	ldr	x17, [x16, #3680]
    2788:	91398210 	add	x16, x16, #0xe60
    278c:	d61f0220 	br	x17

0000000000002790 <clock_gettime@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2794:	f9473611 	ldr	x17, [x16, #3688]
    2798:	9139a210 	add	x16, x16, #0xe68
    279c:	d61f0220 	br	x17

00000000000027a0 <setvbuf@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27a4:	f9473a11 	ldr	x17, [x16, #3696]
    27a8:	9139c210 	add	x16, x16, #0xe70
    27ac:	d61f0220 	br	x17

00000000000027b0 <__memcpy_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27b4:	f9473e11 	ldr	x17, [x16, #3704]
    27b8:	9139e210 	add	x16, x16, #0xe78
    27bc:	d61f0220 	br	x17

00000000000027c0 <signal@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27c4:	f9474211 	ldr	x17, [x16, #3712]
    27c8:	913a0210 	add	x16, x16, #0xe80
    27cc:	d61f0220 	br	x17

00000000000027d0 <__snprintf_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27d4:	f9474611 	ldr	x17, [x16, #3720]
    27d8:	913a2210 	add	x16, x16, #0xe88
    27dc:	d61f0220 	br	x17

00000000000027e0 <fclose@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27e4:	f9474a11 	ldr	x17, [x16, #3728]
    27e8:	913a4210 	add	x16, x16, #0xe90
    27ec:	d61f0220 	br	x17

00000000000027f0 <fopen@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27f4:	f9474e11 	ldr	x17, [x16, #3736]
    27f8:	913a6210 	add	x16, x16, #0xe98
    27fc:	d61f0220 	br	x17

0000000000002800 <malloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2804:	f9475211 	ldr	x17, [x16, #3744]
    2808:	913a8210 	add	x16, x16, #0xea0
    280c:	d61f0220 	br	x17

0000000000002810 <pthread_attr_destroy@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2814:	f9475611 	ldr	x17, [x16, #3752]
    2818:	913aa210 	add	x16, x16, #0xea8
    281c:	d61f0220 	br	x17

0000000000002820 <sigemptyset@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2824:	f9475a11 	ldr	x17, [x16, #3760]
    2828:	913ac210 	add	x16, x16, #0xeb0
    282c:	d61f0220 	br	x17

0000000000002830 <memset@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2834:	f9475e11 	ldr	x17, [x16, #3768]
    2838:	913ae210 	add	x16, x16, #0xeb8
    283c:	d61f0220 	br	x17

0000000000002840 <calloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2844:	f9476211 	ldr	x17, [x16, #3776]
    2848:	913b0210 	add	x16, x16, #0xec0
    284c:	d61f0220 	br	x17

0000000000002850 <realloc@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2854:	f9476611 	ldr	x17, [x16, #3784]
    2858:	913b2210 	add	x16, x16, #0xec8
    285c:	d61f0220 	br	x17

0000000000002860 <__stack_chk_fail@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2864:	f9476a11 	ldr	x17, [x16, #3792]
    2868:	913b4210 	add	x16, x16, #0xed0
    286c:	d61f0220 	br	x17

0000000000002870 <close@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2874:	f9476e11 	ldr	x17, [x16, #3800]
    2878:	913b6210 	add	x16, x16, #0xed8
    287c:	d61f0220 	br	x17

0000000000002880 <sigaction@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2884:	f9477211 	ldr	x17, [x16, #3808]
    2888:	913b8210 	add	x16, x16, #0xee0
    288c:	d61f0220 	br	x17

0000000000002890 <__gmon_start__@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2894:	f9477611 	ldr	x17, [x16, #3816]
    2898:	913ba210 	add	x16, x16, #0xee8
    289c:	d61f0220 	br	x17

00000000000028a0 <write@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28a4:	f9477a11 	ldr	x17, [x16, #3824]
    28a8:	913bc210 	add	x16, x16, #0xef0
    28ac:	d61f0220 	br	x17

00000000000028b0 <abort@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28b4:	f9477e11 	ldr	x17, [x16, #3832]
    28b8:	913be210 	add	x16, x16, #0xef8
    28bc:	d61f0220 	br	x17

00000000000028c0 <swapcontext@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28c4:	f9478211 	ldr	x17, [x16, #3840]
    28c8:	913c0210 	add	x16, x16, #0xf00
    28cc:	d61f0220 	br	x17

00000000000028d0 <__fprintf_chk@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28d4:	f9478611 	ldr	x17, [x16, #3848]
    28d8:	913c2210 	add	x16, x16, #0xf08
    28dc:	d61f0220 	br	x17

00000000000028e0 <strcmp@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28e4:	f9478a11 	ldr	x17, [x16, #3856]
    28e8:	913c4210 	add	x16, x16, #0xf10
    28ec:	d61f0220 	br	x17

00000000000028f0 <mmap@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28f4:	f9478e11 	ldr	x17, [x16, #3864]
    28f8:	913c6210 	add	x16, x16, #0xf18
    28fc:	d61f0220 	br	x17

0000000000002900 <strtol@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2904:	f9479211 	ldr	x17, [x16, #3872]
    2908:	913c8210 	add	x16, x16, #0xf20
    290c:	d61f0220 	br	x17

0000000000002910 <strtof@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2914:	f9479611 	ldr	x17, [x16, #3880]
    2918:	913ca210 	add	x16, x16, #0xf28
    291c:	d61f0220 	br	x17

0000000000002920 <free@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2924:	f9479a11 	ldr	x17, [x16, #3888]
    2928:	913cc210 	add	x16, x16, #0xf30
    292c:	d61f0220 	br	x17

0000000000002930 <nanosleep@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2934:	f9479e11 	ldr	x17, [x16, #3896]
    2938:	913ce210 	add	x16, x16, #0xf38
    293c:	d61f0220 	br	x17

0000000000002940 <strchr@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2944:	f947a211 	ldr	x17, [x16, #3904]
    2948:	913d0210 	add	x16, x16, #0xf40
    294c:	d61f0220 	br	x17

0000000000002950 <strtoull@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2954:	f947a611 	ldr	x17, [x16, #3912]
    2958:	913d2210 	add	x16, x16, #0xf48
    295c:	d61f0220 	br	x17

0000000000002960 <fwrite@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2964:	f947aa11 	ldr	x17, [x16, #3920]
    2968:	913d4210 	add	x16, x16, #0xf50
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_create@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2974:	f947ae11 	ldr	x17, [x16, #3928]
    2978:	913d6210 	add	x16, x16, #0xf58
    297c:	d61f0220 	br	x17

0000000000002980 <munmap@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2984:	f947b211 	ldr	x17, [x16, #3936]
    2988:	913d8210 	add	x16, x16, #0xf60
    298c:	d61f0220 	br	x17

0000000000002990 <fflush@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2994:	f947b611 	ldr	x17, [x16, #3944]
    2998:	913da210 	add	x16, x16, #0xf68
    299c:	d61f0220 	br	x17

00000000000029a0 <strcpy@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29a4:	f947ba11 	ldr	x17, [x16, #3952]
    29a8:	913dc210 	add	x16, x16, #0xf70
    29ac:	d61f0220 	br	x17

00000000000029b0 <sysconf@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29b4:	f947be11 	ldr	x17, [x16, #3960]
    29b8:	913de210 	add	x16, x16, #0xf78
    29bc:	d61f0220 	br	x17

00000000000029c0 <strstr@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29c4:	f947c211 	ldr	x17, [x16, #3968]
    29c8:	913e0210 	add	x16, x16, #0xf80
    29cc:	d61f0220 	br	x17

00000000000029d0 <_Exit@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29d4:	f947c611 	ldr	x17, [x16, #3976]
    29d8:	913e2210 	add	x16, x16, #0xf88
    29dc:	d61f0220 	br	x17

00000000000029e0 <pthread_join@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29e4:	f947ca11 	ldr	x17, [x16, #3984]
    29e8:	913e4210 	add	x16, x16, #0xf90
    29ec:	d61f0220 	br	x17

00000000000029f0 <getenv@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29f4:	f947ce11 	ldr	x17, [x16, #3992]
    29f8:	913e6210 	add	x16, x16, #0xf98
    29fc:	d61f0220 	br	x17

0000000000002a00 <mprotect@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a04:	f947d211 	ldr	x17, [x16, #4000]
    2a08:	913e8210 	add	x16, x16, #0xfa0
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fgets@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a14:	f947d611 	ldr	x17, [x16, #4008]
    2a18:	913ea210 	add	x16, x16, #0xfa8
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_attr_setstacksize@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a24:	f947da11 	ldr	x17, [x16, #4016]
    2a28:	913ec210 	add	x16, x16, #0xfb0
    2a2c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a40 <fwp_trap_overflow.constprop.0>:
    2a40:	d10243ff 	sub	sp, sp, #0x90
    2a44:	d2800c03 	mov	x3, #0x60                  	// #96
    2a48:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2a4c:	f947f421 	ldr	x1, [x1, #4072]
    2a50:	90000045 	adrp	x5, a000 <_IO_stdin_used+0x3c0>
    2a54:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a58:	9101c3fd 	add	x29, sp, #0x70
    2a5c:	910480a5 	add	x5, x5, #0x120
    2a60:	90000044 	adrp	x4, a000 <_IO_stdin_used+0x3c0>
    2a64:	f90043f3 	str	x19, [sp, #128]
    2a68:	9104a084 	add	x4, x4, #0x128
    2a6c:	910023f3 	add	x19, sp, #0x8
    2a70:	f9400022 	ldr	x2, [x1]
    2a74:	f90037e2 	str	x2, [sp, #104]
    2a78:	d2800002 	mov	x2, #0x0                   	// #0
    2a7c:	aa0303e1 	mov	x1, x3
    2a80:	52800042 	mov	w2, #0x2                   	// #2
    2a84:	aa1303e0 	mov	x0, x19
    2a88:	97ffff52 	bl	27d0 <__snprintf_chk@plt>
    2a8c:	aa1303e0 	mov	x0, x19
    2a90:	94000615 	bl	42e4 <fwp_trap>
    2a94:	d503201f 	nop
    2a98:	d503201f 	nop
    2a9c:	d503201f 	nop

0000000000002aa0 <main>:
    2aa0:	d10243ff 	sub	sp, sp, #0x90
    2aa4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2aa8:	f947f400 	ldr	x0, [x0, #4072]
    2aac:	a9067bfd 	stp	x29, x30, [sp, #96]
    2ab0:	910183fd 	add	x29, sp, #0x60
    2ab4:	a90753f3 	stp	x19, x20, [sp, #112]
    2ab8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc88>
    2abc:	f947ee94 	ldr	x20, [x20, #4056]
    2ac0:	f9400282 	ldr	x2, [x20]
    2ac4:	f90043f5 	str	x21, [sp, #128]
    2ac8:	d00000f5 	adrp	x21, 20000 <__data_start>
    2acc:	910142a1 	add	x1, x21, #0x50
    2ad0:	f9400003 	ldr	x3, [x0]
    2ad4:	f9002fe3 	str	x3, [sp, #88]
    2ad8:	d2800003 	mov	x3, #0x0                   	// #0
    2adc:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x12128>
    2ae0:	910de000 	add	x0, x0, #0x378
    2ae4:	f9004822 	str	x2, [x1, #144]
    2ae8:	f9008420 	str	x0, [x1, #264]
    2aec:	9400081d 	bl	4b60 <fwp_now_ns>
    2af0:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    2af4:	91104000 	add	x0, x0, #0x410
    2af8:	97ffffbe 	bl	29f0 <getenv@plt>
    2afc:	b4000080 	cbz	x0, 2b0c <main+0x6c>
    2b00:	39400001 	ldrb	w1, [x0]
    2b04:	aa0003f3 	mov	x19, x0
    2b08:	350008c1 	cbnz	w1, 2c20 <main+0x180>
    2b0c:	910023e1 	add	x1, sp, #0x8
    2b10:	52800000 	mov	w0, #0x0                   	// #0
    2b14:	97ffff1f 	bl	2790 <clock_gettime@plt>
    2b18:	350007e0 	cbnz	w0, 2c14 <main+0x174>
    2b1c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b20:	d2994003 	mov	x3, #0xca00                	// #51712
    2b24:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b28:	9b037c01 	mul	x1, x0, x3
    2b2c:	9b437c00 	smulh	x0, x0, x3
    2b30:	ab020021 	adds	x1, x1, x2
    2b34:	937ffc42 	asr	x2, x2, #63
    2b38:	9a020000 	adc	x0, x0, x2
    2b3c:	f100003f 	cmp	x1, #0x0
    2b40:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b44:	b5000620 	cbnz	x0, 2c08 <main+0x168>
    2b48:	f9400280 	ldr	x0, [x20]
    2b4c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b50:	52800002 	mov	w2, #0x0                   	// #0
    2b54:	d2800001 	mov	x1, #0x0                   	// #0
    2b58:	910063f3 	add	x19, sp, #0x18
    2b5c:	97ffff11 	bl	27a0 <setvbuf@plt>
    2b60:	d2800021 	mov	x1, #0x1                   	// #1
    2b64:	528001a0 	mov	w0, #0xd                   	// #13
    2b68:	97ffff16 	bl	27c0 <signal@plt>
    2b6c:	aa1303e0 	mov	x0, x19
    2b70:	97ffff00 	bl	2770 <pthread_attr_init@plt>
    2b74:	350007a0 	cbnz	w0, 2c68 <main+0x1c8>
    2b78:	aa1303e0 	mov	x0, x19
    2b7c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b80:	97ffffa8 	bl	2a20 <pthread_attr_setstacksize@plt>
    2b84:	35000660 	cbnz	w0, 2c50 <main+0x1b0>
    2b88:	aa1303e1 	mov	x1, x19
    2b8c:	910023e0 	add	x0, sp, #0x8
    2b90:	d0000022 	adrp	x2, 8000 <fwp_write+0x6dc>
    2b94:	d2800003 	mov	x3, #0x0                   	// #0
    2b98:	91244042 	add	x2, x2, #0x910
    2b9c:	97ffff75 	bl	2970 <pthread_create@plt>
    2ba0:	2a0003e1 	mov	w1, w0
    2ba4:	aa1303e0 	mov	x0, x19
    2ba8:	2a0103f3 	mov	w19, w1
    2bac:	97ffff19 	bl	2810 <pthread_attr_destroy@plt>
    2bb0:	350006a0 	cbnz	w0, 2c84 <main+0x1e4>
    2bb4:	35000613 	cbnz	w19, 2c74 <main+0x1d4>
    2bb8:	f94007e0 	ldr	x0, [sp, #8]
    2bbc:	d2800001 	mov	x1, #0x0                   	// #0
    2bc0:	97ffff88 	bl	29e0 <pthread_join@plt>
    2bc4:	35000600 	cbnz	w0, 2c84 <main+0x1e4>
    2bc8:	f9400280 	ldr	x0, [x20]
    2bcc:	910142b5 	add	x21, x21, #0x50
    2bd0:	97ffff70 	bl	2990 <fflush@plt>
    2bd4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2bd8:	f947f421 	ldr	x1, [x1, #4072]
    2bdc:	b943c2a0 	ldr	w0, [x21, #960]
    2be0:	f9402fe3 	ldr	x3, [sp, #88]
    2be4:	f9400022 	ldr	x2, [x1]
    2be8:	eb020063 	subs	x3, x3, x2
    2bec:	d2800002 	mov	x2, #0x0                   	// #0
    2bf0:	54000481 	b.ne	2c80 <main+0x1e0>  // b.any
    2bf4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bf8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bfc:	f94043f5 	ldr	x21, [sp, #128]
    2c00:	910243ff 	add	sp, sp, #0x90
    2c04:	d65f03c0 	ret
    2c08:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    2c0c:	91110000 	add	x0, x0, #0x440
    2c10:	940005b5 	bl	42e4 <fwp_trap>
    2c14:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    2c18:	91108000 	add	x0, x0, #0x420
    2c1c:	940005b2 	bl	42e4 <fwp_trap>
    2c20:	910003e1 	mov	x1, sp
    2c24:	52800142 	mov	w2, #0xa                   	// #10
    2c28:	97ffff4a 	bl	2950 <strtoull@plt>
    2c2c:	f94003e0 	ldr	x0, [sp]
    2c30:	39400000 	ldrb	w0, [x0]
    2c34:	35fff6c0 	cbnz	w0, 2b0c <main+0x6c>
    2c38:	39400260 	ldrb	w0, [x19]
    2c3c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c40:	5100ac00 	sub	w0, w0, #0x2b
    2c44:	6a01001f 	tst	w0, w1
    2c48:	54fff620 	b.eq	2b0c <main+0x6c>  // b.none
    2c4c:	17ffffbf 	b	2b48 <main+0xa8>
    2c50:	aa1303e0 	mov	x0, x19
    2c54:	97fffeef 	bl	2810 <pthread_attr_destroy@plt>
    2c58:	35000160 	cbnz	w0, 2c84 <main+0x1e4>
    2c5c:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    2c60:	91126000 	add	x0, x0, #0x498
    2c64:	940005a0 	bl	42e4 <fwp_trap>
    2c68:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    2c6c:	9111a000 	add	x0, x0, #0x468
    2c70:	9400059d 	bl	42e4 <fwp_trap>
    2c74:	90000040 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    2c78:	91130000 	add	x0, x0, #0x4c0
    2c7c:	9400059a 	bl	42e4 <fwp_trap>
    2c80:	97fffef8 	bl	2860 <__stack_chk_fail@plt>
    2c84:	97ffff0b 	bl	28b0 <abort@plt>
    2c88:	d503201f 	nop
    2c8c:	d503201f 	nop
    2c90:	d503201f 	nop
    2c94:	d503201f 	nop
    2c98:	d503201f 	nop
    2c9c:	d503201f 	nop
    2ca0:	d503201f 	nop
    2ca4:	d503201f 	nop
    2ca8:	d503201f 	nop
    2cac:	d503201f 	nop
    2cb0:	d503201f 	nop
    2cb4:	d503201f 	nop
    2cb8:	d503201f 	nop
    2cbc:	d503201f 	nop

0000000000002cc0 <_start>:
    2cc0:	d503201f 	nop
    2cc4:	d280001d 	mov	x29, #0x0                   	// #0
    2cc8:	d280001e 	mov	x30, #0x0                   	// #0
    2ccc:	aa0003e5 	mov	x5, x0
    2cd0:	f94003e1 	ldr	x1, [sp]
    2cd4:	910023e2 	add	x2, sp, #0x8
    2cd8:	910003e6 	mov	x6, sp
    2cdc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2ce0:	f947f800 	ldr	x0, [x0, #4080]
    2ce4:	d2800003 	mov	x3, #0x0                   	// #0
    2ce8:	d2800004 	mov	x4, #0x0                   	// #0
    2cec:	97fffe8d 	bl	2720 <__libc_start_main@plt>
    2cf0:	97fffef0 	bl	28b0 <abort@plt>

0000000000002cf4 <call_weak_fn>:
    2cf4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2cf8:	f947f000 	ldr	x0, [x0, #4064]
    2cfc:	b4000040 	cbz	x0, 2d04 <call_weak_fn+0x10>
    2d00:	17fffee4 	b	2890 <__gmon_start__@plt>
    2d04:	d65f03c0 	ret
    2d08:	d503201f 	nop
    2d0c:	d503201f 	nop

0000000000002d10 <deregister_tm_clones>:
    2d10:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d14:	9100e000 	add	x0, x0, #0x38
    2d18:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d1c:	9100e021 	add	x1, x1, #0x38
    2d20:	eb00003f 	cmp	x1, x0
    2d24:	540000c0 	b.eq	2d3c <deregister_tm_clones+0x2c>  // b.none
    2d28:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2d2c:	f947e021 	ldr	x1, [x1, #4032]
    2d30:	b4000061 	cbz	x1, 2d3c <deregister_tm_clones+0x2c>
    2d34:	aa0103f0 	mov	x16, x1
    2d38:	d61f0200 	br	x16
    2d3c:	d65f03c0 	ret

0000000000002d40 <register_tm_clones>:
    2d40:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d44:	9100e000 	add	x0, x0, #0x38
    2d48:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d4c:	9100e021 	add	x1, x1, #0x38
    2d50:	cb000021 	sub	x1, x1, x0
    2d54:	d37ffc22 	lsr	x2, x1, #63
    2d58:	8b810c41 	add	x1, x2, x1, asr #3
    2d5c:	9341fc21 	asr	x1, x1, #1
    2d60:	b40000c1 	cbz	x1, 2d78 <register_tm_clones+0x38>
    2d64:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    2d68:	f947fc42 	ldr	x2, [x2, #4088]
    2d6c:	b4000062 	cbz	x2, 2d78 <register_tm_clones+0x38>
    2d70:	aa0203f0 	mov	x16, x2
    2d74:	d61f0200 	br	x16
    2d78:	d65f03c0 	ret
    2d7c:	d503201f 	nop

0000000000002d80 <__do_global_dtors_aux>:
    2d80:	d503233f 	paciasp
    2d84:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d88:	910003fd 	mov	x29, sp
    2d8c:	f9000bf3 	str	x19, [sp, #16]
    2d90:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d94:	39410260 	ldrb	w0, [x19, #64]
    2d98:	37000140 	tbnz	w0, #0, 2dc0 <__do_global_dtors_aux+0x40>
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2da0:	f947e400 	ldr	x0, [x0, #4040]
    2da4:	b4000080 	cbz	x0, 2db4 <__do_global_dtors_aux+0x34>
    2da8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dac:	f9400400 	ldr	x0, [x0, #8]
    2db0:	97fffe68 	bl	2750 <__cxa_finalize@plt>
    2db4:	97ffffd7 	bl	2d10 <deregister_tm_clones>
    2db8:	52800020 	mov	w0, #0x1                   	// #1
    2dbc:	39010260 	strb	w0, [x19, #64]
    2dc0:	f9400bf3 	ldr	x19, [sp, #16]
    2dc4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2dc8:	d50323bf 	autiasp
    2dcc:	d65f03c0 	ret

0000000000002dd0 <frame_dummy>:
    2dd0:	d503245f 	bti	c
    2dd4:	17ffffdb 	b	2d40 <register_tm_clones>
    2dd8:	d503201f 	nop
    2ddc:	d503201f 	nop

0000000000002de0 <fwp_fmt_u128>:
    2de0:	d10183ff 	sub	sp, sp, #0x60
    2de4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2de8:	f947f421 	ldr	x1, [x1, #4072]
    2dec:	a9057bfd 	stp	x29, x30, [sp, #80]
    2df0:	910143fd 	add	x29, sp, #0x50
    2df4:	f9400024 	ldr	x4, [x1]
    2df8:	f90027e4 	str	x4, [sp, #72]
    2dfc:	d2800004 	mov	x4, #0x0                   	// #0
    2e00:	aa030041 	orr	x1, x2, x3
    2e04:	b5000361 	cbnz	x1, 2e70 <fwp_fmt_u128+0x90>
    2e08:	910023e9 	add	x9, sp, #0x8
    2e0c:	52800601 	mov	w1, #0x30                  	// #48
    2e10:	5280002d 	mov	w13, #0x1                   	// #1
    2e14:	390023e1 	strb	w1, [sp, #8]
    2e18:	93407dad 	sxtw	x13, w13
    2e1c:	aa0d03e1 	mov	x1, x13
    2e20:	8b0d0004 	add	x4, x0, x13
    2e24:	d503201f 	nop
    2e28:	8b010123 	add	x3, x9, x1
    2e2c:	cb0103e2 	neg	x2, x1
    2e30:	d1000421 	sub	x1, x1, #0x1
    2e34:	385ff063 	ldurb	w3, [x3, #-1]
    2e38:	38226883 	strb	w3, [x4, x2]
    2e3c:	35ffff61 	cbnz	w1, 2e28 <fwp_fmt_u128+0x48>
    2e40:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2e44:	f947f421 	ldr	x1, [x1, #4072]
    2e48:	382d681f 	strb	wzr, [x0, x13]
    2e4c:	aa0103e0 	mov	x0, x1
    2e50:	f94027e2 	ldr	x2, [sp, #72]
    2e54:	f9400001 	ldr	x1, [x0]
    2e58:	eb010042 	subs	x2, x2, x1
    2e5c:	d2800001 	mov	x1, #0x0                   	// #0
    2e60:	54000561 	b.ne	2f0c <fwp_fmt_u128+0x12c>  // b.any
    2e64:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e68:	910183ff 	add	sp, sp, #0x60
    2e6c:	d65f03c0 	ret
    2e70:	90000041 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    2e74:	912c4021 	add	x1, x1, #0xb10
    2e78:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e7c:	910023e9 	add	x9, sp, #0x8
    2e80:	d2800027 	mov	x7, #0x1                   	// #1
    2e84:	f29999af 	movk	x15, #0xcccd
    2e88:	a9402826 	ldp	x6, x10, [x1]
    2e8c:	d503201f 	nop
    2e90:	ab030041 	adds	x1, x2, x3
    2e94:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e98:	aa0303eb 	mov	x11, x3
    2e9c:	8b070128 	add	x8, x9, x7
    2ea0:	aa0203ee 	mov	x14, x2
    2ea4:	aa0703ed 	mov	x13, x7
    2ea8:	910004e7 	add	x7, x7, #0x1
    2eac:	9bcf7c24 	umulh	x4, x1, x15
    2eb0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2eb4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2eb8:	cb040021 	sub	x1, x1, x4
    2ebc:	eb010041 	subs	x1, x2, x1
    2ec0:	da1f0063 	sbc	x3, x3, xzr
    2ec4:	9bc67c24 	umulh	x4, x1, x6
    2ec8:	9b061064 	madd	x4, x3, x6, x4
    2ecc:	9b067c2c 	mul	x12, x1, x6
    2ed0:	9b0a1024 	madd	x4, x1, x10, x4
    2ed4:	9bc67c25 	umulh	x5, x1, x6
    2ed8:	9b061465 	madd	x5, x3, x6, x5
    2edc:	9b0a1425 	madd	x5, x1, x10, x5
    2ee0:	93cc0484 	extr	x4, x4, x12, #1
    2ee4:	8b040884 	add	x4, x4, x4, lsl #2
    2ee8:	d341fca3 	lsr	x3, x5, #1
    2eec:	cb040444 	sub	x4, x2, x4, lsl #1
    2ef0:	93cc04a2 	extr	x2, x5, x12, #1
    2ef4:	1100c084 	add	w4, w4, #0x30
    2ef8:	381ff104 	sturb	w4, [x8, #-1]
    2efc:	b5fffcab 	cbnz	x11, 2e90 <fwp_fmt_u128+0xb0>
    2f00:	f10025df 	cmp	x14, #0x9
    2f04:	54fffc68 	b.hi	2e90 <fwp_fmt_u128+0xb0>  // b.pmore
    2f08:	17ffffc4 	b	2e18 <fwp_fmt_u128+0x38>
    2f0c:	97fffe55 	bl	2860 <__stack_chk_fail@plt>

0000000000002f10 <fwp_range_release>:
    2f10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f14:	910003fd 	mov	x29, sp
    2f18:	f9400801 	ldr	x1, [x0, #16]
    2f1c:	f9000bf3 	str	x19, [sp, #16]
    2f20:	aa0003f3 	mov	x19, x0
    2f24:	b4000061 	cbz	x1, 2f30 <fwp_range_release+0x20>
    2f28:	f9400400 	ldr	x0, [x0, #8]
    2f2c:	d63f0020 	blr	x1
    2f30:	f9400260 	ldr	x0, [x19]
    2f34:	f9400e61 	ldr	x1, [x19, #24]
    2f38:	f9400bf3 	ldr	x19, [sp, #16]
    2f3c:	aa0103f0 	mov	x16, x1
    2f40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f44:	d61f0200 	br	x16
    2f48:	d503201f 	nop
    2f4c:	d503201f 	nop

0000000000002f50 <ad_raw_record>:
    2f50:	2a0303e4 	mov	w4, w3
    2f54:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f58:	910140e6 	add	x6, x7, #0x50
    2f5c:	b9001003 	str	w3, [x0, #16]
    2f60:	f940040c 	ldr	x12, [x0, #8]
    2f64:	910080ca 	add	x10, x6, #0x20
    2f68:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f6c:	910100c9 	add	x9, x6, #0x40
    2f70:	910180cb 	add	x11, x6, #0x60
    2f74:	a9000801 	stp	x1, x2, [x0]
    2f78:	cb0c00a1 	sub	x1, x5, x12
    2f7c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f80:	8b020021 	add	x1, x1, x2
    2f84:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f88:	91000508 	add	x8, x8, #0x1
    2f8c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f90:	8b0200a5 	add	x5, x5, x2
    2f94:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f98:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f9c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fa0:	eb0c003f 	cmp	x1, x12
    2fa4:	54000049 	b.ls	2fac <ad_raw_record+0x5c>  // b.plast
    2fa8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fac:	910140e1 	add	x1, x7, #0x50
    2fb0:	ad400021 	ldp	q1, q0, [x1]
    2fb4:	f9404022 	ldr	x2, [x1, #128]
    2fb8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2fbc:	5ef1b800 	addp	d0, v0.2d
    2fc0:	9e660000 	fmov	x0, d0
    2fc4:	eb00005f 	cmp	x2, x0
    2fc8:	54000042 	b.cs	2fd0 <ad_raw_record+0x80>  // b.hs, b.nlast
    2fcc:	fd004020 	str	d0, [x1, #128]
    2fd0:	d65f03c0 	ret

0000000000002fd4 <fwp_tape_unlink_scope>:
    2fd4:	f9402003 	ldr	x3, [x0, #64]
    2fd8:	b4000223 	cbz	x3, 301c <fwp_tape_unlink_scope+0x48>
    2fdc:	29490402 	ldp	w2, w1, [x0, #72]
    2fe0:	37f80202 	tbnz	w2, #31, 3020 <fwp_tape_unlink_scope+0x4c>
    2fe4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fe8:	52800b03 	mov	w3, #0x58                  	// #88
    2fec:	f9406c84 	ldr	x4, [x4, #216]
    2ff0:	9b231043 	smaddl	x3, w2, w3, x4
    2ff4:	b9004c61 	str	w1, [x3, #76]
    2ff8:	37f800c1 	tbnz	w1, #31, 3010 <fwp_tape_unlink_scope+0x3c>
    2ffc:	d00000e3 	adrp	x3, 20000 <__data_start>
    3000:	52800b04 	mov	w4, #0x58                  	// #88
    3004:	f9406c63 	ldr	x3, [x3, #216]
    3008:	9b240c21 	smaddl	x1, w1, w4, x3
    300c:	b9004822 	str	w2, [x1, #72]
    3010:	2f000400 	mvni	v0.2s, #0x0
    3014:	f900201f 	str	xzr, [x0, #64]
    3018:	fd002400 	str	d0, [x0, #72]
    301c:	d65f03c0 	ret
    3020:	b9000061 	str	w1, [x3]
    3024:	17fffff5 	b	2ff8 <fwp_tape_unlink_scope+0x24>
    3028:	d503201f 	nop
    302c:	d503201f 	nop

0000000000003030 <fwp_args173>:
    3030:	d65f03c0 	ret

0000000000003034 <fwp_flush>:
    3034:	b00000e0 	adrp	x0, 20000 <__data_start>
    3038:	f9407000 	ldr	x0, [x0, #224]
    303c:	b4000120 	cbz	x0, 3060 <fwp_flush+0x2c>
    3040:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3044:	910003fd 	mov	x29, sp
    3048:	97fffe52 	bl	2990 <fflush@plt>
    304c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3050:	f947ec00 	ldr	x0, [x0, #4056]
    3054:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3058:	f9400000 	ldr	x0, [x0]
    305c:	17fffe4d 	b	2990 <fflush@plt>
    3060:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3064:	f947ec00 	ldr	x0, [x0, #4056]
    3068:	f9400000 	ldr	x0, [x0]
    306c:	17fffe49 	b	2990 <fflush@plt>

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	91014043 	add	x3, x2, #0x50
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9404c60 	ldr	x0, [x3, #152]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe43 	bl	29b0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdb8 	b	27c0 <signal@plt>
    30e4:	91014042 	add	x2, x2, #0x50
    30e8:	f9405040 	ldr	x0, [x2, #160]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9405441 	ldr	x1, [x2, #168]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffc9 	bl	3034 <fwp_flush>
    3114:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    3118:	912bc021 	add	x1, x1, #0xaf0
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffddf 	bl	28a0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd6d 	bl	26e0 <_exit@plt>

0000000000003130 <fwp_heap_oom>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800262 	mov	x2, #0x13                  	// #19
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    3150:	91312000 	add	x0, x0, #0xc48
    3154:	97fffe03 	bl	2960 <fwrite@plt>
    3158:	d2800000 	mov	x0, #0x0                   	// #0
    315c:	97fffe0d 	bl	2990 <fflush@plt>
    3160:	52800cc0 	mov	w0, #0x66                  	// #102
    3164:	97fffe1b 	bl	29d0 <_Exit@plt>
    3168:	d503201f 	nop
    316c:	d503201f 	nop

0000000000003170 <fwp_heap_chunks>:
    3170:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3174:	910003fd 	mov	x29, sp
    3178:	a90153f3 	stp	x19, x20, [sp, #16]
    317c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3180:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbd0>
    3184:	911842a1 	add	x1, x21, #0x610
    3188:	f100041f 	cmp	x0, #0x1
    318c:	54000ca0 	b.eq	3320 <fwp_heap_chunks+0x1b0>  // b.none
    3190:	f949f822 	ldr	x2, [x1, #5104]
    3194:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9f0>
    3198:	912800a5 	add	x5, x5, #0xa00
    319c:	911842a1 	add	x1, x21, #0x610
    31a0:	f949ec34 	ldr	x20, [x1, #5080]
    31a4:	eb14005f 	cmp	x2, x20
    31a8:	54000c42 	b.cs	3330 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ac:	f949fc23 	ldr	x3, [x1, #5112]
    31b0:	8b020841 	add	x1, x2, x2, lsl #2
    31b4:	d2800004 	mov	x4, #0x0                   	// #0
    31b8:	8b010c61 	add	x1, x3, x1, lsl #3
    31bc:	14000009 	b	31e0 <fwp_heap_chunks+0x70>
    31c0:	91000483 	add	x3, x4, #0x1
    31c4:	eb03001f 	cmp	x0, x3
    31c8:	54000940 	b.eq	32f0 <fwp_heap_chunks+0x180>  // b.none
    31cc:	91000442 	add	x2, x2, #0x1
    31d0:	aa0303e4 	mov	x4, x3
    31d4:	9100a021 	add	x1, x1, #0x28
    31d8:	eb02029f 	cmp	x20, x2
    31dc:	54000100 	b.eq	31fc <fwp_heap_chunks+0x8c>  // b.none
    31e0:	39400023 	ldrb	w3, [x1]
    31e4:	34fffee3 	cbz	w3, 31c0 <fwp_heap_chunks+0x50>
    31e8:	91000442 	add	x2, x2, #0x1
    31ec:	9100a021 	add	x1, x1, #0x28
    31f0:	d2800004 	mov	x4, #0x0                   	// #0
    31f4:	eb02029f 	cmp	x20, x2
    31f8:	54ffff41 	b.ne	31e0 <fwp_heap_chunks+0x70>  // b.any
    31fc:	cb040294 	sub	x20, x20, x4
    3200:	f9001bf7 	str	x23, [sp, #48]
    3204:	911842b7 	add	x23, x21, #0x610
    3208:	8b140013 	add	x19, x0, x20
    320c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3210:	f949f2e0 	ldr	x0, [x23, #5088]
    3214:	cb040021 	sub	x1, x1, x4
    3218:	f90a1ae1 	str	x1, [x23, #5168]
    321c:	eb00027f 	cmp	x19, x0
    3220:	54000429 	b.ls	32a4 <fwp_heap_chunks+0x134>  // b.plast
    3224:	f949eae1 	ldr	x1, [x23, #5072]
    3228:	eb01027f 	cmp	x19, x1
    322c:	54000888 	b.hi	333c <fwp_heap_chunks+0x1cc>  // b.pmore
    3230:	91010276 	add	x22, x19, #0x40
    3234:	52800062 	mov	w2, #0x3                   	// #3
    3238:	f949dae3 	ldr	x3, [x23, #5040]
    323c:	eb0102df 	cmp	x22, x1
    3240:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3244:	cb0002c1 	sub	x1, x22, x0
    3248:	8b004060 	add	x0, x3, x0, lsl #16
    324c:	d370bc21 	lsl	x1, x1, #16
    3250:	97fffdec 	bl	2a00 <mprotect@plt>
    3254:	35000740 	cbnz	w0, 333c <fwp_heap_chunks+0x1cc>
    3258:	528003c0 	mov	w0, #0x1e                  	// #30
    325c:	97fffdd5 	bl	29b0 <sysconf@plt>
    3260:	f949f2e2 	ldr	x2, [x23, #5088]
    3264:	cb0003e5 	neg	x5, x0
    3268:	aa0003e4 	mov	x4, x0
    326c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3270:	f949fee0 	ldr	x0, [x23, #5112]
    3274:	8b020843 	add	x3, x2, x2, lsl #2
    3278:	52800062 	mov	w2, #0x3                   	// #3
    327c:	8b010c01 	add	x1, x0, x1, lsl #3
    3280:	8b030c03 	add	x3, x0, x3, lsl #3
    3284:	d1000421 	sub	x1, x1, #0x1
    3288:	8a050060 	and	x0, x3, x5
    328c:	8b040021 	add	x1, x1, x4
    3290:	8a050021 	and	x1, x1, x5
    3294:	cb000021 	sub	x1, x1, x0
    3298:	97fffdda 	bl	2a00 <mprotect@plt>
    329c:	35000500 	cbnz	w0, 333c <fwp_heap_chunks+0x1cc>
    32a0:	f909f2f6 	str	x22, [x23, #5088]
    32a4:	911842b5 	add	x21, x21, #0x610
    32a8:	d370be60 	lsl	x0, x19, #16
    32ac:	f949e6a1 	ldr	x1, [x21, #5064]
    32b0:	f909eeb3 	str	x19, [x21, #5080]
    32b4:	eb01001f 	cmp	x0, x1
    32b8:	540000e8 	b.hi	32d4 <fwp_heap_chunks+0x164>  // b.pmore
    32bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32c0:	aa1403e0 	mov	x0, x20
    32c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32c8:	f9401bf7 	ldr	x23, [sp, #48]
    32cc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32d0:	d65f03c0 	ret
    32d4:	f9401bf7 	ldr	x23, [sp, #48]
    32d8:	f909e6a0 	str	x0, [x21, #5064]
    32dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32e0:	aa1403e0 	mov	x0, x20
    32e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32e8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ec:	d65f03c0 	ret
    32f0:	911842b5 	add	x21, x21, #0x610
    32f4:	91000441 	add	x1, x2, #0x1
    32f8:	f90000a1 	str	x1, [x5]
    32fc:	cb040054 	sub	x20, x2, x4
    3300:	f94a1aa1 	ldr	x1, [x21, #5168]
    3304:	cb000020 	sub	x0, x1, x0
    3308:	f90a1aa0 	str	x0, [x21, #5168]
    330c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3310:	aa1403e0 	mov	x0, x20
    3314:	a94153f3 	ldp	x19, x20, [sp, #16]
    3318:	a8c47bfd 	ldp	x29, x30, [sp], #64
    331c:	d65f03c0 	ret
    3320:	f949f422 	ldr	x2, [x1, #5096]
    3324:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9f0>
    3328:	9127e0a5 	add	x5, x5, #0x9f8
    332c:	17ffff9c 	b	319c <fwp_heap_chunks+0x2c>
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	f9001bf7 	str	x23, [sp, #48]
    3338:	17ffffb3 	b	3204 <fwp_heap_chunks+0x94>
    333c:	97ffff7d 	bl	3130 <fwp_heap_oom>

0000000000003340 <ad_raw_fail>:
    3340:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc88>
    3344:	f947e884 	ldr	x4, [x4, #4048]
    3348:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    334c:	aa0003e3 	mov	x3, x0
    3350:	910003fd 	mov	x29, sp
    3354:	f9400080 	ldr	x0, [x4]
    3358:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0x6f0>
    335c:	91318042 	add	x2, x2, #0xc60
    3360:	52800041 	mov	w1, #0x2                   	// #2
    3364:	97fffd5b 	bl	28d0 <__fprintf_chk@plt>
    3368:	52801d00 	mov	w0, #0xe8                  	// #232
    336c:	97fffce9 	bl	2710 <exit@plt>

0000000000003370 <ad_raw_report>:
    3370:	d10243ff 	sub	sp, sp, #0x90
    3374:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3378:	f947f400 	ldr	x0, [x0, #4072]
    337c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3380:	9100c3fd 	add	x29, sp, #0x30
    3384:	a9055bf5 	stp	x21, x22, [sp, #80]
    3388:	a90663f7 	stp	x23, x24, [sp, #96]
    338c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3390:	91014315 	add	x21, x24, #0x50
    3394:	a90453f3 	stp	x19, x20, [sp, #64]
    3398:	ad4002a1 	ldp	q1, q0, [x21]
    339c:	a9076bf9 	stp	x25, x26, [sp, #112]
    33a0:	a90873fb 	stp	x27, x28, [sp, #128]
    33a4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33a8:	f9400001 	ldr	x1, [x0]
    33ac:	f90017e1 	str	x1, [sp, #40]
    33b0:	d2800001 	mov	x1, #0x0                   	// #0
    33b4:	5ef1b800 	addp	d0, v0.2d
    33b8:	9e660014 	fmov	x20, d0
    33bc:	b5000d74 	cbnz	x20, 3568 <ad_raw_report+0x1f8>
    33c0:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc88>
    33c4:	f947ead6 	ldr	x22, [x22, #4048]
    33c8:	52800041 	mov	w1, #0x2                   	// #2
    33cc:	f94042a3 	ldr	x3, [x21, #128]
    33d0:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0x6f0>
    33d4:	f94002c0 	ldr	x0, [x22]
    33d8:	9132e042 	add	x2, x2, #0xcb8
    33dc:	f9405aa4 	ldr	x4, [x21, #176]
    33e0:	d2800005 	mov	x5, #0x0                   	// #0
    33e4:	d0000039 	adrp	x25, 9000 <fwp_main_thread+0x6f0>
    33e8:	d000003a 	adrp	x26, 9000 <fwp_main_thread+0x6f0>
    33ec:	91346339 	add	x25, x25, #0xd18
    33f0:	9132035a 	add	x26, x26, #0xc80
    33f4:	97fffd37 	bl	28d0 <__fprintf_chk@plt>
    33f8:	d2800013 	mov	x19, #0x0                   	// #0
    33fc:	b00000e0 	adrp	x0, 20000 <__data_start>
    3400:	91004000 	add	x0, x0, #0x10
    3404:	910023e1 	add	x1, sp, #0x8
    3408:	d000003b 	adrp	x27, 9000 <fwp_main_thread+0x6f0>
    340c:	aa0103fc 	mov	x28, x1
    3410:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3414:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3418:	f94002c0 	ldr	x0, [x22]
    341c:	b4000273 	cbz	x19, 3468 <ad_raw_report+0xf8>
    3420:	910182a3 	add	x3, x21, #0x60
    3424:	910102a2 	add	x2, x21, #0x40
    3428:	910082a1 	add	x1, x21, #0x20
    342c:	91322377 	add	x23, x27, #0xc88
    3430:	f9400384 	ldr	x4, [x28]
    3434:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3438:	aa1703e3 	mov	x3, x23
    343c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3440:	aa1903e2 	mov	x2, x25
    3444:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3448:	91000673 	add	x19, x19, #0x1
    344c:	52800041 	mov	w1, #0x2                   	// #2
    3450:	97fffd20 	bl	28d0 <__fprintf_chk@plt>
    3454:	f100127f 	cmp	x19, #0x4
    3458:	540001c0 	b.eq	3490 <ad_raw_report+0x120>  // b.none
    345c:	f94002c0 	ldr	x0, [x22]
    3460:	9100239c 	add	x28, x28, #0x8
    3464:	b5fffdf3 	cbnz	x19, 3420 <ad_raw_report+0xb0>
    3468:	f8408784 	ldr	x4, [x28], #8
    346c:	aa1a03e3 	mov	x3, x26
    3470:	f94012a5 	ldr	x5, [x21, #32]
    3474:	aa1903e2 	mov	x2, x25
    3478:	f94022a6 	ldr	x6, [x21, #64]
    347c:	52800041 	mov	w1, #0x2                   	// #2
    3480:	f94032a7 	ldr	x7, [x21, #96]
    3484:	d2800033 	mov	x19, #0x1                   	// #1
    3488:	97fffd12 	bl	28d0 <__fprintf_chk@plt>
    348c:	17ffffe3 	b	3418 <ad_raw_report+0xa8>
    3490:	f94002c3 	ldr	x3, [x22]
    3494:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    3498:	d2800262 	mov	x2, #0x13                  	// #19
    349c:	91356000 	add	x0, x0, #0xd58
    34a0:	d2800021 	mov	x1, #0x1                   	// #1
    34a4:	97fffd2f 	bl	2960 <fwrite@plt>
    34a8:	f9405ea0 	ldr	x0, [x21, #184]
    34ac:	b4000360 	cbz	x0, 3518 <ad_raw_report+0x1a8>
    34b0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbd0>
    34b4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbd0>
    34b8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbd0>
    34bc:	d0000023 	adrp	x3, 9000 <fwp_main_thread+0x6f0>
    34c0:	f94002c0 	ldr	x0, [x22]
    34c4:	d0000035 	adrp	x21, 9000 <fwp_main_thread+0x6f0>
    34c8:	f9421824 	ldr	x4, [x1, #1072]
    34cc:	91014318 	add	x24, x24, #0x50
    34d0:	f9421ca5 	ldr	x5, [x5, #1080]
    34d4:	9110c033 	add	x19, x1, #0x430
    34d8:	f9422046 	ldr	x6, [x2, #1088]
    34dc:	91320063 	add	x3, x3, #0xc80
    34e0:	9135c2b5 	add	x21, x21, #0xd70
    34e4:	14000005 	b	34f8 <ad_raw_report+0x188>
    34e8:	a9401664 	ldp	x4, x5, [x19]
    34ec:	aa1703e3 	mov	x3, x23
    34f0:	f94002c0 	ldr	x0, [x22]
    34f4:	f9400a66 	ldr	x6, [x19, #16]
    34f8:	aa1503e2 	mov	x2, x21
    34fc:	52800041 	mov	w1, #0x2                   	// #2
    3500:	97fffcf4 	bl	28d0 <__fprintf_chk@plt>
    3504:	f9405f00 	ldr	x0, [x24, #184]
    3508:	91000694 	add	x20, x20, #0x1
    350c:	91006273 	add	x19, x19, #0x18
    3510:	eb14001f 	cmp	x0, x20
    3514:	54fffea8 	b.hi	34e8 <ad_raw_report+0x178>  // b.pmore
    3518:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    351c:	f947f400 	ldr	x0, [x0, #4072]
    3520:	f94017e2 	ldr	x2, [sp, #40]
    3524:	f9400001 	ldr	x1, [x0]
    3528:	eb010042 	subs	x2, x2, x1
    352c:	d2800001 	mov	x1, #0x0                   	// #0
    3530:	54000221 	b.ne	3574 <ad_raw_report+0x204>  // b.any
    3534:	f94002c3 	ldr	x3, [x22]
    3538:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    353c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3540:	9136c000 	add	x0, x0, #0xdb0
    3544:	a94453f3 	ldp	x19, x20, [sp, #64]
    3548:	d2800082 	mov	x2, #0x4                   	// #4
    354c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3550:	d2800021 	mov	x1, #0x1                   	// #1
    3554:	a94663f7 	ldp	x23, x24, [sp, #96]
    3558:	a9476bf9 	ldp	x25, x26, [sp, #112]
    355c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3560:	910243ff 	add	sp, sp, #0x90
    3564:	17fffcff 	b	2960 <fwrite@plt>
    3568:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    356c:	91324000 	add	x0, x0, #0xc90
    3570:	97ffff74 	bl	3340 <ad_raw_fail>
    3574:	97fffcbb 	bl	2860 <__stack_chk_fail@plt>
    3578:	d503201f 	nop
    357c:	d503201f 	nop

0000000000003580 <buf_grow>:
    3580:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3584:	910003fd 	mov	x29, sp
    3588:	a90153f3 	stp	x19, x20, [sp, #16]
    358c:	aa0003f4 	mov	x20, x0
    3590:	f9400400 	ldr	x0, [x0, #8]
    3594:	b100041f 	cmn	x0, #0x1
    3598:	54000400 	b.eq	3618 <buf_grow+0x98>  // b.none
    359c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35a0:	cb000042 	sub	x2, x2, x0
    35a4:	eb01005f 	cmp	x2, x1
    35a8:	54000383 	b.cc	3618 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ac:	f9400a82 	ldr	x2, [x20, #16]
    35b0:	91000421 	add	x1, x1, #0x1
    35b4:	8b000033 	add	x19, x1, x0
    35b8:	eb13005f 	cmp	x2, x19
    35bc:	54000242 	b.cs	3604 <buf_grow+0x84>  // b.hs, b.nlast
    35c0:	f100005f 	cmp	x2, #0x0
    35c4:	b5000262 	cbnz	x2, 3610 <buf_grow+0x90>
    35c8:	d2800802 	mov	x2, #0x40                  	// #64
    35cc:	eb02027f 	cmp	x19, x2
    35d0:	54000068 	b.hi	35dc <buf_grow+0x5c>  // b.pmore
    35d4:	14000005 	b	35e8 <buf_grow+0x68>
    35d8:	b7f800a2 	tbnz	x2, #63, 35ec <buf_grow+0x6c>
    35dc:	d37ff842 	lsl	x2, x2, #1
    35e0:	eb02027f 	cmp	x19, x2
    35e4:	54ffffa8 	b.hi	35d8 <buf_grow+0x58>  // b.pmore
    35e8:	aa0203f3 	mov	x19, x2
    35ec:	f9400280 	ldr	x0, [x20]
    35f0:	aa1303e1 	mov	x1, x19
    35f4:	97fffc97 	bl	2850 <realloc@plt>
    35f8:	b4000100 	cbz	x0, 3618 <buf_grow+0x98>
    35fc:	f9000280 	str	x0, [x20]
    3600:	f9000a93 	str	x19, [x20, #16]
    3604:	a94153f3 	ldp	x19, x20, [sp, #16]
    3608:	a8c27bfd 	ldp	x29, x30, [sp], #32
    360c:	d65f03c0 	ret
    3610:	54fffe6a 	b.ge	35dc <buf_grow+0x5c>  // b.tcont
    3614:	17fffff6 	b	35ec <buf_grow+0x6c>
    3618:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    361c:	f947e863 	ldr	x3, [x3, #4048]
    3620:	d2800262 	mov	x2, #0x13                  	// #19
    3624:	d2800021 	mov	x1, #0x1                   	// #1
    3628:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    362c:	91312000 	add	x0, x0, #0xc48
    3630:	f9400063 	ldr	x3, [x3]
    3634:	97fffccb 	bl	2960 <fwrite@plt>
    3638:	d2800000 	mov	x0, #0x0                   	// #0
    363c:	97fffcd5 	bl	2990 <fflush@plt>
    3640:	52800cc0 	mov	w0, #0x66                  	// #102
    3644:	97fffce3 	bl	29d0 <_Exit@plt>
    3648:	d503201f 	nop
    364c:	d503201f 	nop

0000000000003650 <buf_put>:
    3650:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3654:	910003fd 	mov	x29, sp
    3658:	a90153f3 	stp	x19, x20, [sp, #16]
    365c:	aa0003f4 	mov	x20, x0
    3660:	aa0203f3 	mov	x19, x2
    3664:	f90013f5 	str	x21, [sp, #32]
    3668:	aa0103f5 	mov	x21, x1
    366c:	aa0203e1 	mov	x1, x2
    3670:	97ffffc4 	bl	3580 <buf_grow>
    3674:	a9400283 	ldp	x3, x0, [x20]
    3678:	aa1503e1 	mov	x1, x21
    367c:	aa1303e2 	mov	x2, x19
    3680:	8b000060 	add	x0, x3, x0
    3684:	97fffc0f 	bl	26c0 <memcpy@plt>
    3688:	a9400680 	ldp	x0, x1, [x20]
    368c:	8b010273 	add	x19, x19, x1
    3690:	f9000693 	str	x19, [x20, #8]
    3694:	3833681f 	strb	wzr, [x0, x19]
    3698:	a94153f3 	ldp	x19, x20, [sp, #16]
    369c:	f94013f5 	ldr	x21, [sp, #32]
    36a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36a4:	d65f03c0 	ret
    36a8:	d503201f 	nop
    36ac:	d503201f 	nop

00000000000036b0 <fwp_cancel_tree.part.0>:
    36b0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36b4:	91014022 	add	x2, x1, #0x50
    36b8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36bc:	52800023 	mov	w3, #0x1                   	// #1
    36c0:	910003fd 	mov	x29, sp
    36c4:	f9404c44 	ldr	x4, [x2, #152]
    36c8:	f9000bf3 	str	x19, [sp, #16]
    36cc:	39014403 	strb	w3, [x0, #81]
    36d0:	eb04001f 	cmp	x0, x4
    36d4:	54000160 	b.eq	3700 <fwp_cancel_tree.part.0+0x50>  // b.none
    36d8:	f9402804 	ldr	x4, [x0, #80]
    36dc:	f2001c9f 	tst	x4, #0xff000000ff
    36e0:	54000101 	b.ne	3700 <fwp_cancel_tree.part.0+0x50>  // b.any
    36e4:	f9406044 	ldr	x4, [x2, #192]
    36e8:	39015003 	strb	w3, [x0, #84]
    36ec:	f900801f 	str	xzr, [x0, #256]
    36f0:	b40001e4 	cbz	x4, 372c <fwp_cancel_tree.part.0+0x7c>
    36f4:	f9008080 	str	x0, [x4, #256]
    36f8:	91014021 	add	x1, x1, #0x50
    36fc:	f9006020 	str	x0, [x1, #192]
    3700:	f9401413 	ldr	x19, [x0, #40]
    3704:	b40000f3 	cbz	x19, 3720 <fwp_cancel_tree.part.0+0x70>
    3708:	39414261 	ldrb	w1, [x19, #80]
    370c:	aa1303e0 	mov	x0, x19
    3710:	37000041 	tbnz	w1, #0, 3718 <fwp_cancel_tree.part.0+0x68>
    3714:	97ffffe7 	bl	36b0 <fwp_cancel_tree.part.0>
    3718:	f9401a73 	ldr	x19, [x19, #48]
    371c:	b5ffff73 	cbnz	x19, 3708 <fwp_cancel_tree.part.0+0x58>
    3720:	f9400bf3 	ldr	x19, [sp, #16]
    3724:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3728:	d65f03c0 	ret
    372c:	f9006440 	str	x0, [x2, #200]
    3730:	17fffff2 	b	36f8 <fwp_cancel_tree.part.0+0x48>

0000000000003734 <fwp_finish_float>:
    3734:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3738:	528005c1 	mov	w1, #0x2e                  	// #46
    373c:	910003fd 	mov	x29, sp
    3740:	f9000bf3 	str	x19, [sp, #16]
    3744:	aa0003f3 	mov	x19, x0
    3748:	97fffc7e 	bl	2940 <strchr@plt>
    374c:	b4000080 	cbz	x0, 375c <fwp_finish_float+0x28>
    3750:	f9400bf3 	ldr	x19, [sp, #16]
    3754:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3758:	d65f03c0 	ret
    375c:	aa1303e0 	mov	x0, x19
    3760:	52800ca1 	mov	w1, #0x65                  	// #101
    3764:	97fffc77 	bl	2940 <strchr@plt>
    3768:	b5ffff40 	cbnz	x0, 3750 <fwp_finish_float+0x1c>
    376c:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x6f0>
    3770:	aa1303e0 	mov	x0, x19
    3774:	9136e021 	add	x1, x1, #0xdb8
    3778:	97fffc92 	bl	29c0 <strstr@plt>
    377c:	b5fffea0 	cbnz	x0, 3750 <fwp_finish_float+0x1c>
    3780:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x6f0>
    3784:	aa1303e0 	mov	x0, x19
    3788:	91370021 	add	x1, x1, #0xdc0
    378c:	97fffc8d 	bl	29c0 <strstr@plt>
    3790:	b5fffe00 	cbnz	x0, 3750 <fwp_finish_float+0x1c>
    3794:	aa1303e0 	mov	x0, x19
    3798:	97fffbd6 	bl	26f0 <strlen@plt>
    379c:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x6f0>
    37a0:	91372021 	add	x1, x1, #0xdc8
    37a4:	8b000262 	add	x2, x19, x0
    37a8:	79400023 	ldrh	w3, [x1]
    37ac:	39400821 	ldrb	w1, [x1, #2]
    37b0:	78206a63 	strh	w3, [x19, x0]
    37b4:	39000841 	strb	w1, [x2, #2]
    37b8:	17ffffe6 	b	3750 <fwp_finish_float+0x1c>
    37bc:	d503201f 	nop

00000000000037c0 <fwp_format_g.constprop.0>:
    37c0:	d10483ff 	sub	sp, sp, #0x120
    37c4:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0x6f0>
    37c8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    37cc:	f947f442 	ldr	x2, [x2, #4072]
    37d0:	91374084 	add	x4, x4, #0xdd0
    37d4:	a90b7bfd 	stp	x29, x30, [sp, #176]
    37d8:	9102c3fd 	add	x29, sp, #0xb0
    37dc:	d2800803 	mov	x3, #0x40                  	// #64
    37e0:	a90e63f7 	stp	x23, x24, [sp, #224]
    37e4:	93407c38 	sxtw	x24, w1
    37e8:	aa0303e1 	mov	x1, x3
    37ec:	fd008be8 	str	d8, [sp, #272]
    37f0:	1e604008 	fmov	d8, d0
    37f4:	a90c53f3 	stp	x19, x20, [sp, #192]
    37f8:	910083f4 	add	x20, sp, #0x20
    37fc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3800:	aa0003f5 	mov	x21, x0
    3804:	a91073fb 	stp	x27, x28, [sp, #256]
    3808:	5100071c 	sub	w28, w24, #0x1
    380c:	2a1c03e5 	mov	w5, w28
    3810:	f9400040 	ldr	x0, [x2]
    3814:	f90057e0 	str	x0, [sp, #168]
    3818:	d2800000 	mov	x0, #0x0                   	// #0
    381c:	52800042 	mov	w2, #0x2                   	// #2
    3820:	aa1403e0 	mov	x0, x20
    3824:	97fffbeb 	bl	27d0 <__snprintf_chk@plt>
    3828:	52800ca1 	mov	w1, #0x65                  	// #101
    382c:	aa1403e0 	mov	x0, x20
    3830:	97fffc44 	bl	2940 <strchr@plt>
    3834:	aa0003f3 	mov	x19, x0
    3838:	52800142 	mov	w2, #0xa                   	// #10
    383c:	91000400 	add	x0, x0, #0x1
    3840:	d2800001 	mov	x1, #0x0                   	// #0
    3844:	97fffc2f 	bl	2900 <strtol@plt>
    3848:	aa0003f7 	mov	x23, x0
    384c:	11001400 	add	w0, w0, #0x5
    3850:	7100541f 	cmp	w0, #0x15
    3854:	54000d68 	b.hi	3a00 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3858:	4b170385 	sub	w5, w28, w23
    385c:	710000bf 	cmp	w5, #0x0
    3860:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3864:	54000b80 	b.eq	39d4 <fwp_format_g.constprop.0+0x214>  // b.none
    3868:	394083e0 	ldrb	w0, [sp, #32]
    386c:	cb180273 	sub	x19, x19, x24
    3870:	91000673 	add	x19, x19, #0x1
    3874:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3878:	7100b41f 	cmp	w0, #0x2d
    387c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3880:	1a9f17e4 	cset	w4, eq	// eq = none
    3884:	cb010266 	sub	x6, x19, x1
    3888:	d10004da 	sub	x26, x6, #0x1
    388c:	540018a0 	b.eq	3ba0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3890:	910183f9 	add	x25, sp, #0x60
    3894:	d280091b 	mov	x27, #0x48                  	// #72
    3898:	aa1903e7 	mov	x7, x25
    389c:	91000423 	add	x3, x1, #0x1
    38a0:	91011cc6 	add	x6, x6, #0x47
    38a4:	910004f6 	add	x22, x7, #0x1
    38a8:	37f80ff7 	tbnz	w23, #31, 3aa4 <fwp_format_g.constprop.0+0x2e4>
    38ac:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38b0:	93407ef7 	sxtw	x23, w23
    38b4:	390000e4 	strb	w4, [x7]
    38b8:	aa1303e1 	mov	x1, x19
    38bc:	aa1703e2 	mov	x2, x23
    38c0:	aa1603e0 	mov	x0, x22
    38c4:	b9000be5 	str	w5, [sp, #8]
    38c8:	cb170374 	sub	x20, x27, x23
    38cc:	a9011be3 	stp	x3, x6, [sp, #16]
    38d0:	97fffb7c 	bl	26c0 <memcpy@plt>
    38d4:	d1000694 	sub	x20, x20, #0x1
    38d8:	f9400be3 	ldr	x3, [sp, #16]
    38dc:	8b1702d6 	add	x22, x22, x23
    38e0:	aa1603e0 	mov	x0, x22
    38e4:	aa1a03e2 	mov	x2, x26
    38e8:	aa0303e1 	mov	x1, x3
    38ec:	aa1403e3 	mov	x3, x20
    38f0:	97fffbb0 	bl	27b0 <__memcpy_chk@plt>
    38f4:	8b1a02d6 	add	x22, x22, x26
    38f8:	f9400fe6 	ldr	x6, [sp, #24]
    38fc:	d2800900 	mov	x0, #0x48                  	// #72
    3900:	b9400be5 	ldr	w5, [sp, #8]
    3904:	8b170261 	add	x1, x19, x23
    3908:	cb1400c3 	sub	x3, x6, x20
    390c:	cb060294 	sub	x20, x20, x6
    3910:	f101207f 	cmp	x3, #0x48
    3914:	93407cb8 	sxtw	x24, w5
    3918:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    391c:	aa1803e2 	mov	x2, x24
    3920:	8b1802d3 	add	x19, x22, x24
    3924:	8b140063 	add	x3, x3, x20
    3928:	aa1603e0 	mov	x0, x22
    392c:	97fffba1 	bl	27b0 <__memcpy_chk@plt>
    3930:	cb190273 	sub	x19, x19, x25
    3934:	d28031e0 	mov	x0, #0x18f                 	// #399
    3938:	eb00027f 	cmp	x19, x0
    393c:	aa1903e1 	mov	x1, x25
    3940:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3944:	aa1503e0 	mov	x0, x21
    3948:	aa1303e2 	mov	x2, x19
    394c:	97fffb5d 	bl	26c0 <memcpy@plt>
    3950:	38336abf 	strb	wzr, [x21, x19]
    3954:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3958:	aa1503e0 	mov	x0, x21
    395c:	97fffb65 	bl	26f0 <strlen@plt>
    3960:	aa0003f3 	mov	x19, x0
    3964:	528005c1 	mov	w1, #0x2e                  	// #46
    3968:	aa1503e0 	mov	x0, x21
    396c:	97fffbf5 	bl	2940 <strchr@plt>
    3970:	b4000140 	cbz	x0, 3998 <fwp_format_g.constprop.0+0x1d8>
    3974:	b4000133 	cbz	x19, 3998 <fwp_format_g.constprop.0+0x1d8>
    3978:	aa1303e1 	mov	x1, x19
    397c:	d1000673 	sub	x19, x19, #0x1
    3980:	38736aa0 	ldrb	w0, [x21, x19]
    3984:	7100c01f 	cmp	w0, #0x30
    3988:	54001001 	b.ne	3b88 <fwp_format_g.constprop.0+0x3c8>  // b.any
    398c:	38336abf 	strb	wzr, [x21, x19]
    3990:	b5ffff53 	cbnz	x19, 3978 <fwp_format_g.constprop.0+0x1b8>
    3994:	d503201f 	nop
    3998:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    399c:	f947f400 	ldr	x0, [x0, #4072]
    39a0:	f94057e2 	ldr	x2, [sp, #168]
    39a4:	f9400001 	ldr	x1, [x0]
    39a8:	eb010042 	subs	x2, x2, x1
    39ac:	d2800001 	mov	x1, #0x0                   	// #0
    39b0:	54001061 	b.ne	3bbc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39b4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39b8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39bc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    39c0:	a94e63f7 	ldp	x23, x24, [sp, #224]
    39c4:	a95073fb 	ldp	x27, x28, [sp, #256]
    39c8:	fd408be8 	ldr	d8, [sp, #272]
    39cc:	910483ff 	add	sp, sp, #0x120
    39d0:	d65f03c0 	ret
    39d4:	1e604100 	fmov	d0, d8
    39d8:	710000bf 	cmp	w5, #0x0
    39dc:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    39e0:	aa1503e0 	mov	x0, x21
    39e4:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0x6f0>
    39e8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    39ec:	9137a084 	add	x4, x4, #0xde8
    39f0:	52800042 	mov	w2, #0x2                   	// #2
    39f4:	d2803201 	mov	x1, #0x190                 	// #400
    39f8:	97fffb76 	bl	27d0 <__snprintf_chk@plt>
    39fc:	17ffffd7 	b	3958 <fwp_format_g.constprop.0+0x198>
    3a00:	cb140273 	sub	x19, x19, x20
    3a04:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a08:	910183f9 	add	x25, sp, #0x60
    3a0c:	aa1303e2 	mov	x2, x19
    3a10:	aa1403e1 	mov	x1, x20
    3a14:	aa1903e0 	mov	x0, x25
    3a18:	d2800803 	mov	x3, #0x40                  	// #64
    3a1c:	97fffb65 	bl	27b0 <__memcpy_chk@plt>
    3a20:	38336b3f 	strb	wzr, [x25, x19]
    3a24:	aa1903e0 	mov	x0, x25
    3a28:	528005c1 	mov	w1, #0x2e                  	// #46
    3a2c:	97fffbc5 	bl	2940 <strchr@plt>
    3a30:	b40001c0 	cbz	x0, 3a68 <fwp_format_g.constprop.0+0x2a8>
    3a34:	b50000b3 	cbnz	x19, 3a48 <fwp_format_g.constprop.0+0x288>
    3a38:	1400000c 	b	3a68 <fwp_format_g.constprop.0+0x2a8>
    3a3c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a40:	f1000673 	subs	x19, x19, #0x1
    3a44:	54000120 	b.eq	3a68 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a48:	8b130320 	add	x0, x25, x19
    3a4c:	385ff001 	ldurb	w1, [x0, #-1]
    3a50:	7100c03f 	cmp	w1, #0x30
    3a54:	54ffff40 	b.eq	3a3c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a58:	d1000673 	sub	x19, x19, #0x1
    3a5c:	38736b20 	ldrb	w0, [x25, x19]
    3a60:	7100b81f 	cmp	w0, #0x2e
    3a64:	54000a80 	b.eq	3bb4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3a68:	710002ff 	cmp	w23, #0x0
    3a6c:	528005a1 	mov	w1, #0x2d                  	// #45
    3a70:	aa1903e5 	mov	x5, x25
    3a74:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3a78:	aa1503e0 	mov	x0, x21
    3a7c:	52800566 	mov	w6, #0x2b                  	// #43
    3a80:	d0000024 	adrp	x4, 9000 <fwp_main_thread+0x6f0>
    3a84:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3a88:	91376084 	add	x4, x4, #0xdd8
    3a8c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a90:	52800042 	mov	w2, #0x2                   	// #2
    3a94:	d2803201 	mov	x1, #0x190                 	// #400
    3a98:	97fffb4e 	bl	27d0 <__snprintf_chk@plt>
    3a9c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3aa0:	17ffffbe 	b	3998 <fwp_format_g.constprop.0+0x1d8>
    3aa4:	52800605 	mov	w5, #0x30                  	// #48
    3aa8:	390000e5 	strb	w5, [x7]
    3aac:	d100077b 	sub	x27, x27, #0x1
    3ab0:	aa0303e1 	mov	x1, x3
    3ab4:	aa1603e0 	mov	x0, x22
    3ab8:	aa1b03e3 	mov	x3, x27
    3abc:	aa1a03e2 	mov	x2, x26
    3ac0:	f90007e6 	str	x6, [sp, #8]
    3ac4:	b90013e4 	str	w4, [sp, #16]
    3ac8:	8b1a02d6 	add	x22, x22, x26
    3acc:	b9001be5 	str	w5, [sp, #24]
    3ad0:	97fffb38 	bl	27b0 <__memcpy_chk@plt>
    3ad4:	f94007e6 	ldr	x6, [sp, #8]
    3ad8:	2a3703e7 	mvn	w7, w23
    3adc:	b94013e4 	ldr	w4, [sp, #16]
    3ae0:	cb1b00c1 	sub	x1, x6, x27
    3ae4:	cb06037b 	sub	x27, x27, x6
    3ae8:	f101203f 	cmp	x1, #0x48
    3aec:	d2800906 	mov	x6, #0x48                  	// #72
    3af0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3af4:	8b1b0023 	add	x3, x1, x27
    3af8:	310006ff 	cmn	w23, #0x1
    3afc:	54000220 	b.eq	3b40 <fwp_format_g.constprop.0+0x380>  // b.none
    3b00:	b9401be5 	ldr	w5, [sp, #24]
    3b04:	d2800001 	mov	x1, #0x0                   	// #0
    3b08:	f101207f 	cmp	x3, #0x48
    3b0c:	d1000462 	sub	x2, x3, #0x1
    3b10:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b14:	38216ac5 	strb	w5, [x22, x1]
    3b18:	cb030003 	sub	x3, x0, x3
    3b1c:	91000421 	add	x1, x1, #0x1
    3b20:	91000463 	add	x3, x3, #0x1
    3b24:	eb00007f 	cmp	x3, x0
    3b28:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b2c:	cb000063 	sub	x3, x3, x0
    3b30:	8b020063 	add	x3, x3, x2
    3b34:	6b0100ff 	cmp	w7, w1
    3b38:	54fffe8c 	b.gt	3b08 <fwp_format_g.constprop.0+0x348>
    3b3c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b40:	f101207f 	cmp	x3, #0x48
    3b44:	d2800905 	mov	x5, #0x48                  	// #72
    3b48:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b4c:	aa1603e0 	mov	x0, x22
    3b50:	cb0300a1 	sub	x1, x5, x3
    3b54:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b58:	91000421 	add	x1, x1, #0x1
    3b5c:	d1000463 	sub	x3, x3, #0x1
    3b60:	eb05003f 	cmp	x1, x5
    3b64:	38001402 	strb	w2, [x0], #1
    3b68:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3b6c:	93407f82 	sxtw	x2, w28
    3b70:	cb050025 	sub	x5, x1, x5
    3b74:	aa1303e1 	mov	x1, x19
    3b78:	8b0300a3 	add	x3, x5, x3
    3b7c:	8b1802d3 	add	x19, x22, x24
    3b80:	97fffb0c 	bl	27b0 <__memcpy_chk@plt>
    3b84:	17ffff6b 	b	3930 <fwp_format_g.constprop.0+0x170>
    3b88:	d1000421 	sub	x1, x1, #0x1
    3b8c:	38616aa0 	ldrb	w0, [x21, x1]
    3b90:	7100b81f 	cmp	w0, #0x2e
    3b94:	54fff021 	b.ne	3998 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3b98:	38216abf 	strb	wzr, [x21, x1]
    3b9c:	17ffff7f 	b	3998 <fwp_format_g.constprop.0+0x1d8>
    3ba0:	910187e7 	add	x7, sp, #0x61
    3ba4:	910183f9 	add	x25, sp, #0x60
    3ba8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bac:	390183e0 	strb	w0, [sp, #96]
    3bb0:	17ffff3b 	b	389c <fwp_format_g.constprop.0+0xdc>
    3bb4:	38336b3f 	strb	wzr, [x25, x19]
    3bb8:	17ffffac 	b	3a68 <fwp_format_g.constprop.0+0x2a8>
    3bbc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3bc0:	97fffb28 	bl	2860 <__stack_chk_fail@plt>

0000000000003bc4 <fwp_heap_report>:
    3bc4:	d105c3ff 	sub	sp, sp, #0x170
    3bc8:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbd0>
    3bcc:	91184042 	add	x2, x2, #0x610
    3bd0:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    3bd4:	f947e821 	ldr	x1, [x1, #4048]
    3bd8:	a9117bfd 	stp	x29, x30, [sp, #272]
    3bdc:	910443fd 	add	x29, sp, #0x110
    3be0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3be4:	f947f400 	ldr	x0, [x0, #4072]
    3be8:	a9135bf5 	stp	x21, x22, [sp, #304]
    3bec:	a91463f7 	stp	x23, x24, [sp, #320]
    3bf0:	a9156bf9 	stp	x25, x26, [sp, #336]
    3bf4:	6d1627e8 	stp	d8, d9, [sp, #352]
    3bf8:	fd4a1c48 	ldr	d8, [x2, #5176]
    3bfc:	fd4a2049 	ldr	d9, [x2, #5184]
    3c00:	f9400036 	ldr	x22, [x1]
    3c04:	f9400001 	ldr	x1, [x0]
    3c08:	f90087e1 	str	x1, [sp, #264]
    3c0c:	d2800001 	mov	x1, #0x0                   	// #0
    3c10:	f949e459 	ldr	x25, [x2, #5064]
    3c14:	d0000021 	adrp	x1, 9000 <fwp_main_thread+0x6f0>
    3c18:	f94a1057 	ldr	x23, [x2, #5152]
    3c1c:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    3c20:	f94a1458 	ldr	x24, [x2, #5160]
    3c24:	9137c021 	add	x1, x1, #0xdf0
    3c28:	9137e000 	add	x0, x0, #0xdf8
    3c2c:	97fffaf1 	bl	27f0 <fopen@plt>
    3c30:	b4000760 	cbz	x0, 3d1c <fwp_heap_report+0x158>
    3c34:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c38:	a91253f3 	stp	x19, x20, [sp, #288]
    3c3c:	aa0003f4 	mov	x20, x0
    3c40:	910023f3 	add	x19, sp, #0x8
    3c44:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c48:	72aae915 	movk	w21, #0x5748, lsl #16
    3c4c:	d503201f 	nop
    3c50:	aa1403e2 	mov	x2, x20
    3c54:	aa1303e0 	mov	x0, x19
    3c58:	52802001 	mov	w1, #0x100                 	// #256
    3c5c:	97fffb6d 	bl	2a10 <fgets@plt>
    3c60:	b4000280 	cbz	x0, 3cb0 <fwp_heap_report+0xec>
    3c64:	b9400261 	ldr	w1, [x19]
    3c68:	6b15003f 	cmp	w1, w21
    3c6c:	54ffff21 	b.ne	3c50 <fwp_heap_report+0x8c>  // b.any
    3c70:	39401260 	ldrb	w0, [x19, #4]
    3c74:	7101341f 	cmp	w0, #0x4d
    3c78:	54fffec1 	b.ne	3c50 <fwp_heap_report+0x8c>  // b.any
    3c7c:	394037e0 	ldrb	w0, [sp, #13]
    3c80:	7100e81f 	cmp	w0, #0x3a
    3c84:	54fffe61 	b.ne	3c50 <fwp_heap_report+0x8c>  // b.any
    3c88:	52800142 	mov	w2, #0xa                   	// #10
    3c8c:	d2800001 	mov	x1, #0x0                   	// #0
    3c90:	91003be0 	add	x0, sp, #0xe
    3c94:	97fffb1b 	bl	2900 <strtol@plt>
    3c98:	aa1403e2 	mov	x2, x20
    3c9c:	aa0003fa 	mov	x26, x0
    3ca0:	52802001 	mov	w1, #0x100                 	// #256
    3ca4:	aa1303e0 	mov	x0, x19
    3ca8:	97fffb5a 	bl	2a10 <fgets@plt>
    3cac:	b5fffdc0 	cbnz	x0, 3c64 <fwp_heap_report+0xa0>
    3cb0:	aa1403e0 	mov	x0, x20
    3cb4:	97fffacb 	bl	27e0 <fclose@plt>
    3cb8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3cc0:	f947f400 	ldr	x0, [x0, #4072]
    3cc4:	f94087e2 	ldr	x2, [sp, #264]
    3cc8:	f9400001 	ldr	x1, [x0]
    3ccc:	eb010042 	subs	x2, x2, x1
    3cd0:	d2800001 	mov	x1, #0x0                   	// #0
    3cd4:	54000281 	b.ne	3d24 <fwp_heap_report+0x160>  // b.any
    3cd8:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3cdc:	aa1a03e6 	mov	x6, x26
    3ce0:	aa1903e5 	mov	x5, x25
    3ce4:	aa1803e4 	mov	x4, x24
    3ce8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3cec:	aa1703e3 	mov	x3, x23
    3cf0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3cf4:	aa1603e0 	mov	x0, x22
    3cf8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3cfc:	1e604121 	fmov	d1, d9
    3d00:	1e604100 	fmov	d0, d8
    3d04:	d0000022 	adrp	x2, 9000 <fwp_main_thread+0x6f0>
    3d08:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d0c:	91386042 	add	x2, x2, #0xe18
    3d10:	9105c3ff 	add	sp, sp, #0x170
    3d14:	52800041 	mov	w1, #0x2                   	// #2
    3d18:	17fffaee 	b	28d0 <__fprintf_chk@plt>
    3d1c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d20:	17ffffe7 	b	3cbc <fwp_heap_report+0xf8>
    3d24:	a91253f3 	stp	x19, x20, [sp, #288]
    3d28:	97ffface 	bl	2860 <__stack_chk_fail@plt>
    3d2c:	d503201f 	nop

0000000000003d30 <fwp_heap_init>:
    3d30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d34:	f00003a3 	adrp	x3, 7a000 <fwp_heap+0x9f0>
    3d38:	91144061 	add	x1, x3, #0x510
    3d3c:	910003fd 	mov	x29, sp
    3d40:	a90153f3 	stp	x19, x20, [sp, #16]
    3d44:	d00003b3 	adrp	x19, 79000 <fwp_root_context+0xbd0>
    3d48:	91184262 	add	x2, x19, #0x610
    3d4c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d50:	52800024 	mov	w4, #0x1                   	// #1
    3d54:	52800200 	mov	w0, #0x10                  	// #16
    3d58:	b913a444 	str	w4, [x2, #5028]
    3d5c:	d503201f 	nop
    3d60:	b8004420 	str	w0, [x1], #4
    3d64:	11004000 	add	w0, w0, #0x10
    3d68:	7104401f 	cmp	w0, #0x110
    3d6c:	54ffffa1 	b.ne	3d60 <fwp_heap_init+0x30>  // b.any
    3d70:	f0000022 	adrp	x2, a000 <_IO_stdin_used+0x3c0>
    3d74:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3d78:	f00003a1 	adrp	x1, 7a000 <fwp_heap+0x9f0>
    3d7c:	91154021 	add	x1, x1, #0x550
    3d80:	3dc2c843 	ldr	q3, [x2, #2848]
    3d84:	d2800000 	mov	x0, #0x0                   	// #0
    3d88:	4e040401 	dup	v1.4s, v0.s[0]
    3d8c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3d90:	0f215400 	shl	v0.2s, v0.2s, #1
    3d94:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3d98:	3ca06821 	str	q1, [x1, x0]
    3d9c:	91004000 	add	x0, x0, #0x10
    3da0:	f101801f 	cmp	x0, #0x60
    3da4:	54ffff21 	b.ne	3d88 <fwp_heap_init+0x58>  // b.any
    3da8:	f00003a4 	adrp	x4, 7a000 <fwp_heap+0x9f0>
    3dac:	91144063 	add	x3, x3, #0x510
    3db0:	9116c084 	add	x4, x4, #0x5b0
    3db4:	91184266 	add	x6, x19, #0x610
    3db8:	d2800002 	mov	x2, #0x0                   	// #0
    3dbc:	d2800000 	mov	x0, #0x0                   	// #0
    3dc0:	d2880205 	mov	x5, #0x4010                	// #16400
    3dc4:	d503201f 	nop
    3dc8:	910f0001 	add	x1, x0, #0x3c0
    3dcc:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3dd0:	eb02003f 	cmp	x1, x2
    3dd4:	540000a2 	b.cs	3de8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3dd8:	91000400 	add	x0, x0, #0x1
    3ddc:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3de0:	eb02003f 	cmp	x1, x2
    3de4:	54ffffa3 	b.cc	3dd8 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3de8:	91004042 	add	x2, x2, #0x10
    3dec:	38001480 	strb	w0, [x4], #1
    3df0:	eb05005f 	cmp	x2, x5
    3df4:	54fffea1 	b.ne	3dc8 <fwp_heap_init+0x98>  // b.any
    3df8:	528000b5 	mov	w21, #0x5                   	// #5
    3dfc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e00:	14000004 	b	3e10 <fwp_heap_init+0xe0>
    3e04:	d342fe94 	lsr	x20, x20, #2
    3e08:	710006b5 	subs	w21, w21, #0x1
    3e0c:	54000720 	b.eq	3ef0 <fwp_heap_init+0x1c0>  // b.none
    3e10:	91404296 	add	x22, x20, #0x10, lsl #12
    3e14:	d2800005 	mov	x5, #0x0                   	// #0
    3e18:	aa1603e1 	mov	x1, x22
    3e1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e20:	52880443 	mov	w3, #0x4022                	// #16418
    3e24:	52800002 	mov	w2, #0x0                   	// #0
    3e28:	d2800000 	mov	x0, #0x0                   	// #0
    3e2c:	97fffab1 	bl	28f0 <mmap@plt>
    3e30:	aa0003e6 	mov	x6, x0
    3e34:	b100041f 	cmn	x0, #0x1
    3e38:	54fffe60 	b.eq	3e04 <fwp_heap_init+0xd4>  // b.none
    3e3c:	b40005a0 	cbz	x0, 3ef0 <fwp_heap_init+0x1c0>
    3e40:	d350fe94 	lsr	x20, x20, #16
    3e44:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e48:	8b0000c7 	add	x7, x6, x0
    3e4c:	91184275 	add	x21, x19, #0x610
    3e50:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e54:	8b140a81 	add	x1, x20, x20, lsl #2
    3e58:	d2800005 	mov	x5, #0x0                   	// #0
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	d37df021 	lsl	x1, x1, #3
    3e64:	52880443 	mov	w3, #0x4022                	// #16418
    3e68:	52800002 	mov	w2, #0x0                   	// #0
    3e6c:	d2800000 	mov	x0, #0x0                   	// #0
    3e70:	f909daa7 	str	x7, [x21, #5040]
    3e74:	f909dea6 	str	x6, [x21, #5048]
    3e78:	f909e2b6 	str	x22, [x21, #5056]
    3e7c:	f909eab4 	str	x20, [x21, #5072]
    3e80:	f90a02a1 	str	x1, [x21, #5120]
    3e84:	97fffa9b 	bl	28f0 <mmap@plt>
    3e88:	aa0003e1 	mov	x1, x0
    3e8c:	b100041f 	cmn	x0, #0x1
    3e90:	54000300 	b.eq	3ef0 <fwp_heap_init+0x1c0>  // b.none
    3e94:	d0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    3e98:	913a8000 	add	x0, x0, #0xea0
    3e9c:	f909fea1 	str	x1, [x21, #5112]
    3ea0:	97fffad4 	bl	29f0 <getenv@plt>
    3ea4:	52800002 	mov	w2, #0x0                   	// #0
    3ea8:	aa0003e1 	mov	x1, x0
    3eac:	b40000e0 	cbz	x0, 3ec8 <fwp_heap_init+0x198>
    3eb0:	39400000 	ldrb	w0, [x0]
    3eb4:	340000a0 	cbz	w0, 3ec8 <fwp_heap_init+0x198>
    3eb8:	7100c000 	subs	w0, w0, #0x30
    3ebc:	54000120 	b.eq	3ee0 <fwp_heap_init+0x1b0>  // b.none
    3ec0:	7100001f 	cmp	w0, #0x0
    3ec4:	1a9f07e2 	cset	w2, ne	// ne = any
    3ec8:	91184273 	add	x19, x19, #0x610
    3ecc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3ed0:	b913aa62 	str	w2, [x19, #5032]
    3ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3ed8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3edc:	d65f03c0 	ret
    3ee0:	39400420 	ldrb	w0, [x1, #1]
    3ee4:	7100001f 	cmp	w0, #0x0
    3ee8:	1a9f07e2 	cset	w2, ne	// ne = any
    3eec:	17fffff7 	b	3ec8 <fwp_heap_init+0x198>
    3ef0:	97fffc90 	bl	3130 <fwp_heap_oom>

0000000000003ef4 <fwp_wake_io>:
    3ef4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3ef8:	91014122 	add	x2, x9, #0x50
    3efc:	f9400001 	ldr	x1, [x0]
    3f00:	5280000a 	mov	w10, #0x0                   	// #0
    3f04:	f9406046 	ldr	x6, [x2, #192]
    3f08:	52800008 	mov	w8, #0x0                   	// #0
    3f0c:	4f000400 	movi	v0.4s, #0x0
    3f10:	52800027 	mov	w7, #0x1                   	// #1
    3f14:	aa0103e2 	mov	x2, x1
    3f18:	b4000321 	cbz	x1, 3f7c <fwp_wake_io+0x88>
    3f1c:	f9408c25 	ldr	x5, [x1, #280]
    3f20:	39015c27 	strb	w7, [x1, #87]
    3f24:	b4000165 	cbz	x5, 3f50 <fwp_wake_io+0x5c>
    3f28:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f2c:	b4000364 	cbz	x4, 3f98 <fwp_wake_io+0xa4>
    3f30:	f9009483 	str	x3, [x4, #296]
    3f34:	f9409423 	ldr	x3, [x1, #296]
    3f38:	b4000043 	cbz	x3, 3f40 <fwp_wake_io+0x4c>
    3f3c:	f9009064 	str	x4, [x3, #288]
    3f40:	91080023 	add	x3, x1, #0x200
    3f44:	f900943f 	str	xzr, [x1, #296]
    3f48:	3c918060 	stur	q0, [x3, #-232]
    3f4c:	f9400001 	ldr	x1, [x0]
    3f50:	f9402843 	ldr	x3, [x2, #80]
    3f54:	f2001c7f 	tst	x3, #0xff000000ff
    3f58:	54fffde1 	b.ne	3f14 <fwp_wake_io+0x20>  // b.any
    3f5c:	39015047 	strb	w7, [x2, #84]
    3f60:	f900805f 	str	xzr, [x2, #256]
    3f64:	b40001e6 	cbz	x6, 3fa0 <fwp_wake_io+0xac>
    3f68:	f90080c2 	str	x2, [x6, #256]
    3f6c:	aa0203e6 	mov	x6, x2
    3f70:	52800028 	mov	w8, #0x1                   	// #1
    3f74:	aa0103e2 	mov	x2, x1
    3f78:	b5fffd21 	cbnz	x1, 3f1c <fwp_wake_io+0x28>
    3f7c:	3400006a 	cbz	w10, 3f88 <fwp_wake_io+0x94>
    3f80:	91014120 	add	x0, x9, #0x50
    3f84:	f900640b 	str	x11, [x0, #200]
    3f88:	34000068 	cbz	w8, 3f94 <fwp_wake_io+0xa0>
    3f8c:	91014129 	add	x9, x9, #0x50
    3f90:	f9006126 	str	x6, [x9, #192]
    3f94:	d65f03c0 	ret
    3f98:	f90000a3 	str	x3, [x5]
    3f9c:	17ffffe7 	b	3f38 <fwp_wake_io+0x44>
    3fa0:	aa0203eb 	mov	x11, x2
    3fa4:	5280002a 	mov	w10, #0x1                   	// #1
    3fa8:	17fffff1 	b	3f6c <fwp_wake_io+0x78>
    3fac:	d503201f 	nop

0000000000003fb0 <ad_raw_free.part.0>:
    3fb0:	b00002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbd0>
    3fb4:	d2800001 	mov	x1, #0x0                   	// #0
    3fb8:	9110c082 	add	x2, x4, #0x430
    3fbc:	14000005 	b	3fd0 <ad_raw_free.part.0+0x20>
    3fc0:	91000421 	add	x1, x1, #0x1
    3fc4:	91006042 	add	x2, x2, #0x18
    3fc8:	f140043f 	cmp	x1, #0x1, lsl #12
    3fcc:	54000220 	b.eq	4010 <ad_raw_free.part.0+0x60>  // b.none
    3fd0:	f9400043 	ldr	x3, [x2]
    3fd4:	eb03001f 	cmp	x0, x3
    3fd8:	54ffff41 	b.ne	3fc0 <ad_raw_free.part.0+0x10>  // b.any
    3fdc:	8b010421 	add	x1, x1, x1, lsl #1
    3fe0:	9110c084 	add	x4, x4, #0x430
    3fe4:	b00000e2 	adrp	x2, 20000 <__data_start>
    3fe8:	91014042 	add	x2, x2, #0x50
    3fec:	8b010c81 	add	x1, x4, x1, lsl #3
    3ff0:	b9401024 	ldr	w4, [x1, #16]
    3ff4:	f9400425 	ldr	x5, [x1, #8]
    3ff8:	a9007c3f 	stp	xzr, xzr, [x1]
    3ffc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4000:	f900083f 	str	xzr, [x1, #16]
    4004:	cb050061 	sub	x1, x3, x5
    4008:	f8247841 	str	x1, [x2, x4, lsl #3]
    400c:	17fffa45 	b	2920 <free@plt>
    4010:	f100001f 	cmp	x0, #0x0
    4014:	b0000021 	adrp	x1, 9000 <fwp_main_thread+0x6f0>
    4018:	913b2021 	add	x1, x1, #0xec8
    401c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4020:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    4024:	913ac000 	add	x0, x0, #0xeb0
    4028:	910003fd 	mov	x29, sp
    402c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4030:	97fffcc4 	bl	3340 <ad_raw_fail>

0000000000004034 <fwp_tape_buffers_dispose>:
    4034:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4038:	910003fd 	mov	x29, sp
    403c:	f9000bf3 	str	x19, [sp, #16]
    4040:	aa0003f3 	mov	x19, x0
    4044:	f9400000 	ldr	x0, [x0]
    4048:	b4000040 	cbz	x0, 4050 <fwp_tape_buffers_dispose+0x1c>
    404c:	97ffffd9 	bl	3fb0 <ad_raw_free.part.0>
    4050:	f9400660 	ldr	x0, [x19, #8]
    4054:	b4000040 	cbz	x0, 405c <fwp_tape_buffers_dispose+0x28>
    4058:	97ffffd6 	bl	3fb0 <ad_raw_free.part.0>
    405c:	f9400a60 	ldr	x0, [x19, #16]
    4060:	b4000040 	cbz	x0, 4068 <fwp_tape_buffers_dispose+0x34>
    4064:	97ffffd3 	bl	3fb0 <ad_raw_free.part.0>
    4068:	a9007e7f 	stp	xzr, xzr, [x19]
    406c:	a9017e7f 	stp	xzr, xzr, [x19, #16]
    4070:	f900127f 	str	xzr, [x19, #32]
    4074:	f9400bf3 	ldr	x19, [sp, #16]
    4078:	a8c27bfd 	ldp	x29, x30, [sp], #32
    407c:	d65f03c0 	ret

0000000000004080 <ad_raw_realloc>:
    4080:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4084:	910003fd 	mov	x29, sp
    4088:	a90153f3 	stp	x19, x20, [sp, #16]
    408c:	f90013f5 	str	x21, [sp, #32]
    4090:	b40005a1 	cbz	x1, 4144 <ad_raw_realloc+0xc4>
    4094:	aa0103f4 	mov	x20, x1
    4098:	2a0203f5 	mov	w21, w2
    409c:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbd0>
    40a0:	d2800004 	mov	x4, #0x0                   	// #0
    40a4:	9110c025 	add	x5, x1, #0x430
    40a8:	14000005 	b	40bc <ad_raw_realloc+0x3c>
    40ac:	91000484 	add	x4, x4, #0x1
    40b0:	910060a5 	add	x5, x5, #0x18
    40b4:	f140049f 	cmp	x4, #0x1, lsl #12
    40b8:	54000320 	b.eq	411c <ad_raw_realloc+0x9c>  // b.none
    40bc:	f94000a6 	ldr	x6, [x5]
    40c0:	eb06001f 	cmp	x0, x6
    40c4:	54ffff41 	b.ne	40ac <ad_raw_realloc+0x2c>  // b.any
    40c8:	8b040484 	add	x4, x4, x4, lsl #1
    40cc:	9110c021 	add	x1, x1, #0x430
    40d0:	8b040c33 	add	x19, x1, x4, lsl #3
    40d4:	b4000080 	cbz	x0, 40e4 <ad_raw_realloc+0x64>
    40d8:	b9401261 	ldr	w1, [x19, #16]
    40dc:	6b15003f 	cmp	w1, w21
    40e0:	540002c1 	b.ne	4138 <ad_raw_realloc+0xb8>  // b.any
    40e4:	aa1403e1 	mov	x1, x20
    40e8:	97fff9da 	bl	2850 <realloc@plt>
    40ec:	aa0003ed 	mov	x13, x0
    40f0:	b40000c0 	cbz	x0, 4108 <ad_raw_realloc+0x88>
    40f4:	2a1503e3 	mov	w3, w21
    40f8:	aa1403e2 	mov	x2, x20
    40fc:	aa1303e0 	mov	x0, x19
    4100:	aa0d03e1 	mov	x1, x13
    4104:	97fffb93 	bl	2f50 <ad_raw_record>
    4108:	a94153f3 	ldp	x19, x20, [sp, #16]
    410c:	aa0d03e0 	mov	x0, x13
    4110:	f94013f5 	ldr	x21, [sp, #32]
    4114:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4118:	d65f03c0 	ret
    411c:	f100001f 	cmp	x0, #0x0
    4120:	b0000021 	adrp	x1, 9000 <fwp_main_thread+0x6f0>
    4124:	913b2021 	add	x1, x1, #0xec8
    4128:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    412c:	913ac000 	add	x0, x0, #0xeb0
    4130:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4134:	97fffc83 	bl	3340 <ad_raw_fail>
    4138:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    413c:	913c2000 	add	x0, x0, #0xf08
    4140:	97fffc80 	bl	3340 <ad_raw_fail>
    4144:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    4148:	913ba000 	add	x0, x0, #0xee8
    414c:	97fffc7d 	bl	3340 <ad_raw_fail>

0000000000004150 <fwp_tape_buffers_release>:
    4150:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4154:	910003fd 	mov	x29, sp
    4158:	a90153f3 	stp	x19, x20, [sp, #16]
    415c:	aa0003f4 	mov	x20, x0
    4160:	f9400c00 	ldr	x0, [x0, #24]
    4164:	a9025bf5 	stp	x21, x22, [sp, #32]
    4168:	b7f80500 	tbnz	x0, #63, 4208 <fwp_tape_buffers_release+0xb8>
    416c:	f9401293 	ldr	x19, [x20, #32]
    4170:	b7f804d3 	tbnz	x19, #63, 4208 <fwp_tape_buffers_release+0xb8>
    4174:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    4178:	eb01001f 	cmp	x0, x1
    417c:	54000468 	b.hi	4208 <fwp_tape_buffers_release+0xb8>  // b.pmore
    4180:	8b000400 	add	x0, x0, x0, lsl #1
    4184:	d2a00101 	mov	x1, #0x80000               	// #524288
    4188:	d37df000 	lsl	x0, x0, #3
    418c:	cb000021 	sub	x1, x1, x0
    4190:	eb410e7f 	cmp	x19, x1, lsr #3
    4194:	540003a8 	b.hi	4208 <fwp_tape_buffers_release+0xb8>  // b.pmore
    4198:	8b130c13 	add	x19, x0, x19, lsl #3
    419c:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    41a0:	913c8000 	add	x0, x0, #0xf20
    41a4:	97fffa13 	bl	29f0 <getenv@plt>
    41a8:	b4000080 	cbz	x0, 41b8 <fwp_tape_buffers_release+0x68>
    41ac:	39400001 	ldrb	w1, [x0]
    41b0:	7100c03f 	cmp	w1, #0x30
    41b4:	54000820 	b.eq	42b8 <fwp_tape_buffers_release+0x168>  // b.none
    41b8:	d1000661 	sub	x1, x19, #0x1
    41bc:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    41c0:	eb00003f 	cmp	x1, x0
    41c4:	540002c8 	b.hi	421c <fwp_tape_buffers_release+0xcc>  // b.pmore
    41c8:	900000f5 	adrp	x21, 20000 <__data_start>
    41cc:	f9001bf7 	str	x23, [sp, #48]
    41d0:	910142b7 	add	x23, x21, #0x50
    41d4:	910342f6 	add	x22, x23, #0xd0
    41d8:	aa1603e0 	mov	x0, x22
    41dc:	97ffff96 	bl	4034 <fwp_tape_buffers_dispose>
    41e0:	ad400680 	ldp	q0, q1, [x20]
    41e4:	f9007ef3 	str	x19, [x23, #248]
    41e8:	ad0006c0 	stp	q0, q1, [x22]
    41ec:	f9401280 	ldr	x0, [x20, #32]
    41f0:	f90012c0 	str	x0, [x22, #32]
    41f4:	a9007e9f 	stp	xzr, xzr, [x20]
    41f8:	a9017e9f 	stp	xzr, xzr, [x20, #16]
    41fc:	f900129f 	str	xzr, [x20, #32]
    4200:	f9401bf7 	ldr	x23, [sp, #48]
    4204:	1400000b 	b	4230 <fwp_tape_buffers_release+0xe0>
    4208:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    420c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4210:	913c8000 	add	x0, x0, #0xf20
    4214:	97fff9f7 	bl	29f0 <getenv@plt>
    4218:	b5fffca0 	cbnz	x0, 41ac <fwp_tape_buffers_release+0x5c>
    421c:	aa1403e0 	mov	x0, x20
    4220:	97ffff85 	bl	4034 <fwp_tape_buffers_dispose>
    4224:	900000f5 	adrp	x21, 20000 <__data_start>
    4228:	910142a0 	add	x0, x21, #0x50
    422c:	f9407c13 	ldr	x19, [x0, #248]
    4230:	910142a2 	add	x2, x21, #0x50
    4234:	f9408044 	ldr	x4, [x2, #256]
    4238:	a9400c45 	ldp	x5, x3, [x2]
    423c:	a9411841 	ldp	x1, x6, [x2, #16]
    4240:	8b040480 	add	x0, x4, x4, lsl #1
    4244:	d37ef400 	lsl	x0, x0, #2
    4248:	cb040000 	sub	x0, x0, x4
    424c:	8b0300a3 	add	x3, x5, x3
    4250:	8b060021 	add	x1, x1, x6
    4254:	d37df000 	lsl	x0, x0, #3
    4258:	8b030021 	add	x1, x1, x3
    425c:	eb05001f 	cmp	x0, x5
    4260:	54000321 	b.ne	42c4 <fwp_tape_buffers_release+0x174>  // b.any
    4264:	8b130003 	add	x3, x0, x19
    4268:	eb01007f 	cmp	x3, x1
    426c:	540002c8 	b.hi	42c4 <fwp_tape_buffers_release+0x174>  // b.pmore
    4270:	f9405c43 	ldr	x3, [x2, #184]
    4274:	f140087f 	cmp	x3, #0x2, lsl #12
    4278:	540002e0 	b.eq	42d4 <fwp_tape_buffers_release+0x184>  // b.none
    427c:	8b030464 	add	x4, x3, x3, lsl #1
    4280:	90000165 	adrp	x5, 30000 <alt.5+0xfbd0>
    4284:	9110c0a5 	add	x5, x5, #0x430
    4288:	cb000021 	sub	x1, x1, x0
    428c:	d37df084 	lsl	x4, x4, #3
    4290:	cb130021 	sub	x1, x1, x19
    4294:	8b0400a6 	add	x6, x5, x4
    4298:	91000463 	add	x3, x3, #0x1
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	f82468a0 	str	x0, [x5, x4]
    42a4:	a90084d3 	stp	x19, x1, [x6, #8]
    42a8:	f9005c43 	str	x3, [x2, #184]
    42ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    42b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    42b4:	d65f03c0 	ret
    42b8:	39400400 	ldrb	w0, [x0, #1]
    42bc:	34fffb00 	cbz	w0, 421c <fwp_tape_buffers_release+0xcc>
    42c0:	17ffffbe 	b	41b8 <fwp_tape_buffers_release+0x68>
    42c4:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    42c8:	913ce000 	add	x0, x0, #0xf38
    42cc:	f9001bf7 	str	x23, [sp, #48]
    42d0:	97fffc1c 	bl	3340 <ad_raw_fail>
    42d4:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    42d8:	913da000 	add	x0, x0, #0xf68
    42dc:	f9001bf7 	str	x23, [sp, #48]
    42e0:	97fffc18 	bl	3340 <ad_raw_fail>

00000000000042e4 <fwp_trap>:
    42e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    42e8:	900000e2 	adrp	x2, 20000 <__data_start>
    42ec:	d53bd041 	mrs	x1, tpidr_el0
    42f0:	910003fd 	mov	x29, sp
    42f4:	f9407042 	ldr	x2, [x2, #224]
    42f8:	91400021 	add	x1, x1, #0x0, lsl #12
    42fc:	91004021 	add	x1, x1, #0x10
    4300:	a90153f3 	stp	x19, x20, [sp, #16]
    4304:	aa0003f3 	mov	x19, x0
    4308:	f9400034 	ldr	x20, [x1]
    430c:	b4000062 	cbz	x2, 4318 <fwp_trap+0x34>
    4310:	aa0203e0 	mov	x0, x2
    4314:	97fff99f 	bl	2990 <fflush@plt>
    4318:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    431c:	f947ec00 	ldr	x0, [x0, #4056]
    4320:	f9400000 	ldr	x0, [x0]
    4324:	97fff99b 	bl	2990 <fflush@plt>
    4328:	aa1303e3 	mov	x3, x19
    432c:	b0000022 	adrp	x2, 9000 <fwp_main_thread+0x6f0>
    4330:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc88>
    4334:	f947ea73 	ldr	x19, [x19, #4048]
    4338:	913e2042 	add	x2, x2, #0xf88
    433c:	52800041 	mov	w1, #0x2                   	// #2
    4340:	f9400260 	ldr	x0, [x19]
    4344:	97fff963 	bl	28d0 <__fprintf_chk@plt>
    4348:	b40000b4 	cbz	x20, 435c <fwp_trap+0x78>
    434c:	f9400260 	ldr	x0, [x19]
    4350:	97fff990 	bl	2990 <fflush@plt>
    4354:	52800ca0 	mov	w0, #0x65                  	// #101
    4358:	97fff99e 	bl	29d0 <_Exit@plt>
    435c:	52800ca0 	mov	w0, #0x65                  	// #101
    4360:	97fff8ec 	bl	2710 <exit@plt>

0000000000004364 <fwp_rc_forget_slot.part.0>:
    4364:	ca404401 	eor	x1, x0, x0, lsr #17
    4368:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    436c:	ca412421 	eor	x1, x1, x1, lsr #9
    4370:	910003fd 	mov	x29, sp
    4374:	92401c21 	and	x1, x1, #0xff
    4378:	f9000bf3 	str	x19, [sp, #16]
    437c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbd0>
    4380:	91184262 	add	x2, x19, #0x610
    4384:	910a2423 	add	x3, x1, #0x289
    4388:	8b010c41 	add	x1, x2, x1, lsl #3
    438c:	8b030c43 	add	x3, x2, x3, lsl #3
    4390:	f94a2421 	ldr	x1, [x1, #5192]
    4394:	b50000a1 	cbnz	x1, 43a8 <fwp_rc_forget_slot.part.0+0x44>
    4398:	14000012 	b	43e0 <fwp_rc_forget_slot.part.0+0x7c>
    439c:	91004023 	add	x3, x1, #0x10
    43a0:	f9400821 	ldr	x1, [x1, #16]
    43a4:	b40001e1 	cbz	x1, 43e0 <fwp_rc_forget_slot.part.0+0x7c>
    43a8:	f9400022 	ldr	x2, [x1]
    43ac:	eb02001f 	cmp	x0, x2
    43b0:	54ffff61 	b.ne	439c <fwp_rc_forget_slot.part.0+0x38>  // b.any
    43b4:	f9400060 	ldr	x0, [x3]
    43b8:	91184273 	add	x19, x19, #0x610
    43bc:	f9400801 	ldr	x1, [x0, #16]
    43c0:	f9000061 	str	x1, [x3]
    43c4:	97fff957 	bl	2920 <free@plt>
    43c8:	f94e2660 	ldr	x0, [x19, #7240]
    43cc:	d1000400 	sub	x0, x0, #0x1
    43d0:	f90e2660 	str	x0, [x19, #7240]
    43d4:	f9400bf3 	ldr	x19, [sp, #16]
    43d8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43dc:	d65f03c0 	ret
    43e0:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    43e4:	913e6000 	add	x0, x0, #0xf98
    43e8:	97ffffbf 	bl	42e4 <fwp_trap>
    43ec:	d503201f 	nop

00000000000043f0 <fwp_rc_prepare_chunk>:
    43f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43f4:	910003fd 	mov	x29, sp
    43f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    43fc:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbd0>
    4400:	911842c2 	add	x2, x22, #0x610
    4404:	b9401c03 	ldr	w3, [x0, #28]
    4408:	aa0103f5 	mov	x21, x1
    440c:	a90153f3 	stp	x19, x20, [sp, #16]
    4410:	aa0003f4 	mov	x20, x0
    4414:	f94e2440 	ldr	x0, [x2, #7240]
    4418:	b4000440 	cbz	x0, 44a0 <fwp_rc_prepare_chunk+0xb0>
    441c:	d2800013 	mov	x19, #0x0                   	// #0
    4420:	35000203 	cbnz	w3, 4460 <fwp_rc_prepare_chunk+0x70>
    4424:	b4000361 	cbz	x1, 4490 <fwp_rc_prepare_chunk+0xa0>
    4428:	f9401280 	ldr	x0, [x20, #32]
    442c:	97fff93d 	bl	2920 <free@plt>
    4430:	aa1503e0 	mov	x0, x21
    4434:	d2800021 	mov	x1, #0x1                   	// #1
    4438:	97fff902 	bl	2840 <calloc@plt>
    443c:	f9001280 	str	x0, [x20, #32]
    4440:	b5000460 	cbnz	x0, 44cc <fwp_rc_prepare_chunk+0xdc>
    4444:	97fffb3b 	bl	3130 <fwp_heap_oom>
    4448:	97ffffc7 	bl	4364 <fwp_rc_forget_slot.part.0>
    444c:	91000673 	add	x19, x19, #0x1
    4450:	b9401e83 	ldr	w3, [x20, #28]
    4454:	eb13007f 	cmp	x3, x19
    4458:	54000169 	b.ls	4484 <fwp_rc_prepare_chunk+0x94>  // b.plast
    445c:	d503201f 	nop
    4460:	f9401283 	ldr	x3, [x20, #32]
    4464:	8b130060 	add	x0, x3, x19
    4468:	38736863 	ldrb	w3, [x3, x19]
    446c:	7103fc7f 	cmp	w3, #0xff
    4470:	54fffec0 	b.eq	4448 <fwp_rc_prepare_chunk+0x58>  // b.none
    4474:	b9401e83 	ldr	w3, [x20, #28]
    4478:	91000673 	add	x19, x19, #0x1
    447c:	eb13007f 	cmp	x3, x19
    4480:	54ffff08 	b.hi	4460 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4484:	eb0302bf 	cmp	x21, x3
    4488:	54000121 	b.ne	44ac <fwp_rc_prepare_chunk+0xbc>  // b.any
    448c:	b5000335 	cbnz	x21, 44f0 <fwp_rc_prepare_chunk+0x100>
    4490:	a94153f3 	ldp	x19, x20, [sp, #16]
    4494:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4498:	a8c37bfd 	ldp	x29, x30, [sp], #48
    449c:	d65f03c0 	ret
    44a0:	2a0303e3 	mov	w3, w3
    44a4:	eb0302bf 	cmp	x21, x3
    44a8:	54ffff20 	b.eq	448c <fwp_rc_prepare_chunk+0x9c>  // b.none
    44ac:	911842c2 	add	x2, x22, #0x610
    44b0:	f9401280 	ldr	x0, [x20, #32]
    44b4:	f94e2841 	ldr	x1, [x2, #7248]
    44b8:	cb030021 	sub	x1, x1, x3
    44bc:	f90e2841 	str	x1, [x2, #7248]
    44c0:	97fff918 	bl	2920 <free@plt>
    44c4:	b5fffb75 	cbnz	x21, 4430 <fwp_rc_prepare_chunk+0x40>
    44c8:	f900129f 	str	xzr, [x20, #32]
    44cc:	911842d6 	add	x22, x22, #0x610
    44d0:	f94e2ac0 	ldr	x0, [x22, #7248]
    44d4:	b9001e95 	str	w21, [x20, #28]
    44d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44dc:	8b150000 	add	x0, x0, x21
    44e0:	f90e2ac0 	str	x0, [x22, #7248]
    44e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	f9401280 	ldr	x0, [x20, #32]
    44f4:	aa1503e2 	mov	x2, x21
    44f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44fc:	52800001 	mov	w1, #0x0                   	// #0
    4500:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4504:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4508:	17fff8ca 	b	2830 <memset@plt>
    450c:	d503201f 	nop

0000000000004510 <fwp_heap_refill>:
    4510:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4514:	910003fd 	mov	x29, sp
    4518:	a9025bf5 	stp	x21, x22, [sp, #32]
    451c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbd0>
    4520:	911842b5 	add	x21, x21, #0x610
    4524:	aa0003f6 	mov	x22, x0
    4528:	d2800020 	mov	x0, #0x1                   	// #1
    452c:	a90153f3 	stp	x19, x20, [sp, #16]
    4530:	a90363f7 	stp	x23, x24, [sp, #48]
    4534:	2a0103f7 	mov	w23, w1
    4538:	2a0203f8 	mov	w24, w2
    453c:	97fffb0d 	bl	3170 <fwp_heap_chunks>
    4540:	aa0003f3 	mov	x19, x0
    4544:	f949fea2 	ldr	x2, [x21, #5112]
    4548:	8b000800 	add	x0, x0, x0, lsl #2
    454c:	2a1703e1 	mov	w1, w23
    4550:	52800025 	mov	w5, #0x1                   	// #1
    4554:	d37df000 	lsl	x0, x0, #3
    4558:	910f0021 	add	x1, x1, #0x3c0
    455c:	8b000054 	add	x20, x2, x0
    4560:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4564:	52a00024 	mov	w4, #0x10000               	// #65536
    4568:	38206845 	strb	w5, [x2, x0]
    456c:	aa1403e0 	mov	x0, x20
    4570:	39000698 	strb	w24, [x20, #1]
    4574:	39000a97 	strb	w23, [x20, #2]
    4578:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    457c:	b9000681 	str	w1, [x20, #4]
    4580:	2a0103e5 	mov	w5, w1
    4584:	8b0300a2 	add	x2, x5, x3
    4588:	1ac10881 	udiv	w1, w4, w1
    458c:	9ac50842 	udiv	x2, x2, x5
    4590:	b9000a81 	str	w1, [x20, #8]
    4594:	92404021 	and	x1, x1, #0x1ffff
    4598:	b9001a82 	str	w2, [x20, #24]
    459c:	97ffff95 	bl	43f0 <fwp_rc_prepare_chunk>
    45a0:	f949daa0 	ldr	x0, [x21, #5040]
    45a4:	29408a81 	ldp	w1, w2, [x20, #4]
    45a8:	8b134000 	add	x0, x0, x19, lsl #16
    45ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    45b0:	8b214003 	add	x3, x0, w1, uxtw
    45b4:	9ba20021 	umaddl	x1, w1, w2, x0
    45b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    45bc:	a90086c3 	stp	x3, x1, [x22, #8]
    45c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    45c4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    45c8:	d65f03c0 	ret
    45cc:	d503201f 	nop

00000000000045d0 <fwp_mem_free>:
    45d0:	b40003c0 	cbz	x0, 4648 <fwp_mem_free+0x78>
    45d4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    45d8:	910003fd 	mov	x29, sp
    45dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    45e0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbd0>
    45e4:	911842a1 	add	x1, x21, #0x610
    45e8:	a90153f3 	stp	x19, x20, [sp, #16]
    45ec:	aa0003f3 	mov	x19, x0
    45f0:	f949d823 	ldr	x3, [x1, #5040]
    45f4:	f949ec22 	ldr	x2, [x1, #5080]
    45f8:	cb030000 	sub	x0, x0, x3
    45fc:	eb02401f 	cmp	x0, x2, lsl #16
    4600:	540001c2 	b.cs	4638 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4604:	d350fc16 	lsr	x22, x0, #16
    4608:	a90363f7 	stp	x23, x24, [sp, #48]
    460c:	f949fc22 	ldr	x2, [x1, #5112]
    4610:	8b160ad4 	add	x20, x22, x22, lsl #2
    4614:	d37df294 	lsl	x20, x20, #3
    4618:	ab140057 	adds	x23, x2, x20
    461c:	540000c0 	b.eq	4634 <fwp_mem_free+0x64>  // b.none
    4620:	38746842 	ldrb	w2, [x2, x20]
    4624:	7100045f 	cmp	w2, #0x1
    4628:	54000120 	b.eq	464c <fwp_mem_free+0x7c>  // b.none
    462c:	7100085f 	cmp	w2, #0x2
    4630:	540005e0 	b.eq	46ec <fwp_mem_free+0x11c>  // b.none
    4634:	a94363f7 	ldp	x23, x24, [sp, #48]
    4638:	a94153f3 	ldp	x19, x20, [sp, #16]
    463c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4640:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4644:	d65f03c0 	ret
    4648:	d65f03c0 	ret
    464c:	f94012f8 	ldr	x24, [x23, #32]
    4650:	b94006e1 	ldr	w1, [x23, #4]
    4654:	f90023f9 	str	x25, [sp, #64]
    4658:	2a0103e2 	mov	w2, w1
    465c:	394006f9 	ldrb	w25, [x23, #1]
    4660:	39400af4 	ldrb	w20, [x23, #2]
    4664:	b4000158 	cbz	x24, 468c <fwp_mem_free+0xbc>
    4668:	92403e76 	and	x22, x19, #0xffff
    466c:	9ac20ad6 	udiv	x22, x22, x2
    4670:	38766b01 	ldrb	w1, [x24, x22]
    4674:	8b160300 	add	x0, x24, x22
    4678:	7103fc3f 	cmp	w1, #0xff
    467c:	54000980 	b.eq	47ac <fwp_mem_free+0x1dc>  // b.none
    4680:	38366b1f 	strb	wzr, [x24, x22]
    4684:	b94006e1 	ldr	w1, [x23, #4]
    4688:	2a0103e2 	mov	w2, w1
    468c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4690:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4694:	cb390000 	sub	x0, x0, w25, uxtb
    4698:	8b340074 	add	x20, x3, w20, uxtb
    469c:	911842b5 	add	x21, x21, #0x610
    46a0:	1e630021 	ucvtf	d1, w1
    46a4:	d37ae400 	lsl	x0, x0, #6
    46a8:	8b140c14 	add	x20, x0, x20, lsl #3
    46ac:	a94363f7 	ldp	x23, x24, [sp, #48]
    46b0:	f8746aa0 	ldr	x0, [x21, x20]
    46b4:	f94023f9 	ldr	x25, [sp, #64]
    46b8:	aa2003e0 	mvn	x0, x0
    46bc:	fd4a22a0 	ldr	d0, [x21, #5184]
    46c0:	f9000260 	str	x0, [x19]
    46c4:	f8346ab3 	str	x19, [x21, x20]
    46c8:	f94a12a0 	ldr	x0, [x21, #5152]
    46cc:	1e612800 	fadd	d0, d0, d1
    46d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46d4:	cb020000 	sub	x0, x0, x2
    46d8:	f90a12a0 	str	x0, [x21, #5152]
    46dc:	fd0a22a0 	str	d0, [x21, #5184]
    46e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    46e8:	d65f03c0 	ret
    46ec:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    46f0:	8b000063 	add	x3, x3, x0
    46f4:	eb03027f 	cmp	x19, x3
    46f8:	54fff9e1 	b.ne	4634 <fwp_mem_free+0x64>  // b.any
    46fc:	fd400ae1 	ldr	d1, [x23, #16]
    4700:	fd4a2020 	ldr	d0, [x1, #5184]
    4704:	f9400ae0 	ldr	x0, [x23, #16]
    4708:	7e61d821 	ucvtf	d1, d1
    470c:	f94a1022 	ldr	x2, [x1, #5152]
    4710:	f94012f3 	ldr	x19, [x23, #32]
    4714:	1e612800 	fadd	d0, d0, d1
    4718:	cb000042 	sub	x2, x2, x0
    471c:	f90a1022 	str	x2, [x1, #5152]
    4720:	fd0a2020 	str	d0, [x1, #5184]
    4724:	b40000b3 	cbz	x19, 4738 <fwp_mem_free+0x168>
    4728:	39400260 	ldrb	w0, [x19]
    472c:	7103fc1f 	cmp	w0, #0xff
    4730:	54000380 	b.eq	47a0 <fwp_mem_free+0x1d0>  // b.none
    4734:	3900027f 	strb	wzr, [x19]
    4738:	b9400ee2 	ldr	w2, [x23, #12]
    473c:	b4000142 	cbz	x2, 4764 <fwp_mem_free+0x194>
    4740:	911842a1 	add	x1, x21, #0x610
    4744:	8b160040 	add	x0, x2, x22
    4748:	8b000800 	add	x0, x0, x0, lsl #2
    474c:	f949fc21 	ldr	x1, [x1, #5112]
    4750:	8b140034 	add	x20, x1, x20
    4754:	8b000c20 	add	x0, x1, x0, lsl #3
    4758:	3802869f 	strb	wzr, [x20], #40
    475c:	eb00029f 	cmp	x20, x0
    4760:	54ffffc1 	b.ne	4758 <fwp_mem_free+0x188>  // b.any
    4764:	911842a0 	add	x0, x21, #0x610
    4768:	f94a1801 	ldr	x1, [x0, #5168]
    476c:	f949f803 	ldr	x3, [x0, #5104]
    4770:	8b020021 	add	x1, x1, x2
    4774:	f90a1801 	str	x1, [x0, #5168]
    4778:	eb16007f 	cmp	x3, x22
    477c:	54000049 	b.ls	4784 <fwp_mem_free+0x1b4>  // b.plast
    4780:	f909f816 	str	x22, [x0, #5104]
    4784:	911842b5 	add	x21, x21, #0x610
    4788:	f949f6a0 	ldr	x0, [x21, #5096]
    478c:	eb16001f 	cmp	x0, x22
    4790:	54fff529 	b.ls	4634 <fwp_mem_free+0x64>  // b.plast
    4794:	a94363f7 	ldp	x23, x24, [sp, #48]
    4798:	f909f6b6 	str	x22, [x21, #5096]
    479c:	17ffffa7 	b	4638 <fwp_mem_free+0x68>
    47a0:	aa1303e0 	mov	x0, x19
    47a4:	97fffef0 	bl	4364 <fwp_rc_forget_slot.part.0>
    47a8:	17ffffe3 	b	4734 <fwp_mem_free+0x164>
    47ac:	97fffeee 	bl	4364 <fwp_rc_forget_slot.part.0>
    47b0:	17ffffb4 	b	4680 <fwp_mem_free+0xb0>

00000000000047b4 <fwp_rc_wide_dup>:
    47b4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    47b8:	910003fd 	mov	x29, sp
    47bc:	a90153f3 	stp	x19, x20, [sp, #16]
    47c0:	aa0003f3 	mov	x19, x0
    47c4:	ca404400 	eor	x0, x0, x0, lsr #17
    47c8:	f90013f5 	str	x21, [sp, #32]
    47cc:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbd0>
    47d0:	ca402400 	eor	x0, x0, x0, lsr #9
    47d4:	911842a2 	add	x2, x21, #0x610
    47d8:	92401c00 	and	x0, x0, #0xff
    47dc:	910a2403 	add	x3, x0, #0x289
    47e0:	8b000c40 	add	x0, x2, x0, lsl #3
    47e4:	8b030c54 	add	x20, x2, x3, lsl #3
    47e8:	f94a2401 	ldr	x1, [x0, #5192]
    47ec:	b50000a1 	cbnz	x1, 4800 <fwp_rc_wide_dup+0x4c>
    47f0:	14000033 	b	48bc <fwp_rc_wide_dup+0x108>
    47f4:	91004034 	add	x20, x1, #0x10
    47f8:	f9400821 	ldr	x1, [x1, #16]
    47fc:	b4000241 	cbz	x1, 4844 <fwp_rc_wide_dup+0x90>
    4800:	f9400022 	ldr	x2, [x1]
    4804:	eb02027f 	cmp	x19, x2
    4808:	54ffff61 	b.ne	47f4 <fwp_rc_wide_dup+0x40>  // b.any
    480c:	f9400281 	ldr	x1, [x20]
    4810:	39400260 	ldrb	w0, [x19]
    4814:	7103f81f 	cmp	w0, #0xfe
    4818:	54000220 	b.eq	485c <fwp_rc_wide_dup+0xa8>  // b.none
    481c:	b40001a1 	cbz	x1, 4850 <fwp_rc_wide_dup+0x9c>
    4820:	f9400420 	ldr	x0, [x1, #8]
    4824:	b100041f 	cmn	x0, #0x1
    4828:	54000440 	b.eq	48b0 <fwp_rc_wide_dup+0xfc>  // b.none
    482c:	91000400 	add	x0, x0, #0x1
    4830:	f9000420 	str	x0, [x1, #8]
    4834:	a94153f3 	ldp	x19, x20, [sp, #16]
    4838:	f94013f5 	ldr	x21, [sp, #32]
    483c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4840:	d65f03c0 	ret
    4844:	39400260 	ldrb	w0, [x19]
    4848:	7103f81f 	cmp	w0, #0xfe
    484c:	54000100 	b.eq	486c <fwp_rc_wide_dup+0xb8>  // b.none
    4850:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    4854:	913e6000 	add	x0, x0, #0xf98
    4858:	97fffea3 	bl	42e4 <fwp_trap>
    485c:	b4000081 	cbz	x1, 486c <fwp_rc_wide_dup+0xb8>
    4860:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    4864:	913f0000 	add	x0, x0, #0xfc0
    4868:	97fffe9f 	bl	42e4 <fwp_trap>
    486c:	d2800300 	mov	x0, #0x18                  	// #24
    4870:	97fff7e4 	bl	2800 <malloc@plt>
    4874:	b4000280 	cbz	x0, 48c4 <fwp_rc_wide_dup+0x110>
    4878:	d2801fe1 	mov	x1, #0xff                  	// #255
    487c:	a9000413 	stp	x19, x1, [x0]
    4880:	911842b5 	add	x21, x21, #0x610
    4884:	f900081f 	str	xzr, [x0, #16]
    4888:	12800001 	mov	w1, #0xffffffff            	// #-1
    488c:	f9000280 	str	x0, [x20]
    4890:	39000261 	strb	w1, [x19]
    4894:	f94e26a0 	ldr	x0, [x21, #7240]
    4898:	a94153f3 	ldp	x19, x20, [sp, #16]
    489c:	91000400 	add	x0, x0, #0x1
    48a0:	f90e26a0 	str	x0, [x21, #7240]
    48a4:	f94013f5 	ldr	x21, [sp, #32]
    48a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    48ac:	d65f03c0 	ret
    48b0:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    48b4:	913fa000 	add	x0, x0, #0xfe8
    48b8:	97fffe8b 	bl	42e4 <fwp_trap>
    48bc:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    48c0:	17ffffd4 	b	4810 <fwp_rc_wide_dup+0x5c>
    48c4:	97fffa1b 	bl	3130 <fwp_heap_oom>
    48c8:	d503201f 	nop
    48cc:	d503201f 	nop

00000000000048d0 <fwp_closure_drop_push>:
    48d0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    48d4:	910003fd 	mov	x29, sp
    48d8:	a90153f3 	stp	x19, x20, [sp, #16]
    48dc:	aa0003f3 	mov	x19, x0
    48e0:	a9408014 	ldp	x20, x0, [x0, #8]
    48e4:	a9025bf5 	stp	x21, x22, [sp, #32]
    48e8:	aa0103f5 	mov	x21, x1
    48ec:	a90363f7 	stp	x23, x24, [sp, #48]
    48f0:	eb00029f 	cmp	x20, x0
    48f4:	54000160 	b.eq	4920 <fwp_closure_drop_push+0x50>  // b.none
    48f8:	f9400276 	ldr	x22, [x19]
    48fc:	d37df297 	lsl	x23, x20, #3
    4900:	91000694 	add	x20, x20, #0x1
    4904:	f9000674 	str	x20, [x19, #8]
    4908:	a94153f3 	ldp	x19, x20, [sp, #16]
    490c:	f8376ad5 	str	x21, [x22, x23]
    4910:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4914:	a94363f7 	ldp	x23, x24, [sp, #48]
    4918:	a8c57bfd 	ldp	x29, x30, [sp], #80
    491c:	d65f03c0 	ret
    4920:	a9046bf9 	stp	x25, x26, [sp, #64]
    4924:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4928:	eb00029f 	cmp	x20, x0
    492c:	540003e8 	b.hi	49a8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4930:	d37cee99 	lsl	x25, x20, #4
    4934:	d37ffa9a 	lsl	x26, x20, #1
    4938:	aa1903e0 	mov	x0, x25
    493c:	97fff7b1 	bl	2800 <malloc@plt>
    4940:	aa0003f6 	mov	x22, x0
    4944:	b4000380 	cbz	x0, 49b4 <fwp_closure_drop_push+0xe4>
    4948:	aa1303f8 	mov	x24, x19
    494c:	aa1903e3 	mov	x3, x25
    4950:	d37df297 	lsl	x23, x20, #3
    4954:	aa1703e2 	mov	x2, x23
    4958:	f8418719 	ldr	x25, [x24], #24
    495c:	aa1903e1 	mov	x1, x25
    4960:	97fff794 	bl	27b0 <__memcpy_chk@plt>
    4964:	eb18033f 	cmp	x25, x24
    4968:	540000a0 	b.eq	497c <fwp_closure_drop_push+0xac>  // b.none
    496c:	aa1903e0 	mov	x0, x25
    4970:	97fff7ec 	bl	2920 <free@plt>
    4974:	f9400674 	ldr	x20, [x19, #8]
    4978:	d37df297 	lsl	x23, x20, #3
    497c:	91000694 	add	x20, x20, #0x1
    4980:	f9000276 	str	x22, [x19]
    4984:	f9000a7a 	str	x26, [x19, #16]
    4988:	a9446bf9 	ldp	x25, x26, [sp, #64]
    498c:	f9000674 	str	x20, [x19, #8]
    4990:	f8376ad5 	str	x21, [x22, x23]
    4994:	a94153f3 	ldp	x19, x20, [sp, #16]
    4998:	a9425bf5 	ldp	x21, x22, [sp, #32]
    499c:	a94363f7 	ldp	x23, x24, [sp, #48]
    49a0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    49a4:	d65f03c0 	ret
    49a8:	d0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    49ac:	91002000 	add	x0, x0, #0x8
    49b0:	97fffe4d 	bl	42e4 <fwp_trap>
    49b4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    49b8:	f947e863 	ldr	x3, [x3, #4048]
    49bc:	d2800262 	mov	x2, #0x13                  	// #19
    49c0:	d2800021 	mov	x1, #0x1                   	// #1
    49c4:	b0000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    49c8:	91312000 	add	x0, x0, #0xc48
    49cc:	f9400063 	ldr	x3, [x3]
    49d0:	97fff7e4 	bl	2960 <fwrite@plt>
    49d4:	d2800000 	mov	x0, #0x0                   	// #0
    49d8:	97fff7ee 	bl	2990 <fflush@plt>
    49dc:	52800cc0 	mov	w0, #0x66                  	// #102
    49e0:	97fff7fc 	bl	29d0 <_Exit@plt>

00000000000049e4 <fwp_closure_drop.part.0>:
    49e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    49e8:	d0000021 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    49ec:	910003fd 	mov	x29, sp
    49f0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    49f4:	f947f463 	ldr	x3, [x3, #4072]
    49f8:	a90153f3 	stp	x19, x20, [sp, #16]
    49fc:	d10883ff 	sub	sp, sp, #0x220
    4a00:	910003e2 	mov	x2, sp
    4a04:	d53bd053 	mrs	x19, tpidr_el0
    4a08:	910063f4 	add	x20, sp, #0x18
    4a0c:	3dc2cc20 	ldr	q0, [x1, #2864]
    4a10:	91400264 	add	x4, x19, #0x0, lsl #12
    4a14:	91004084 	add	x4, x4, #0x10
    4a18:	aa0003e1 	mov	x1, x0
    4a1c:	aa0203e0 	mov	x0, x2
    4a20:	f9400062 	ldr	x2, [x3]
    4a24:	f9010fe2 	str	x2, [sp, #536]
    4a28:	d2800002 	mov	x2, #0x0                   	// #0
    4a2c:	f90003f4 	str	x20, [sp]
    4a30:	f9000080 	str	x0, [x4]
    4a34:	3c8083e0 	stur	q0, [sp, #8]
    4a38:	97ffffa6 	bl	48d0 <fwp_closure_drop_push>
    4a3c:	f94007e0 	ldr	x0, [sp, #8]
    4a40:	b40002e0 	cbz	x0, 4a9c <fwp_closure_drop.part.0+0xb8>
    4a44:	f90123f5 	str	x21, [sp, #576]
    4a48:	900000f5 	adrp	x21, 20000 <__data_start>
    4a4c:	910142b5 	add	x21, x21, #0x50
    4a50:	14000006 	b	4a68 <fwp_closure_drop.part.0+0x84>
    4a54:	f9400422 	ldr	x2, [x1, #8]
    4a58:	52800001 	mov	w1, #0x0                   	// #0
    4a5c:	d63f0040 	blr	x2
    4a60:	f94007e0 	ldr	x0, [sp, #8]
    4a64:	b40001a0 	cbz	x0, 4a98 <fwp_closure_drop.part.0+0xb4>
    4a68:	f94003e1 	ldr	x1, [sp]
    4a6c:	d1000400 	sub	x0, x0, #0x1
    4a70:	f90007e0 	str	x0, [sp, #8]
    4a74:	f94086a2 	ldr	x2, [x21, #264]
    4a78:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    4a7c:	b9400001 	ldr	w1, [x0]
    4a80:	8b011441 	add	x1, x2, x1, lsl #5
    4a84:	f9400c21 	ldr	x1, [x1, #24]
    4a88:	b5fffe61 	cbnz	x1, 4a54 <fwp_closure_drop.part.0+0x70>
    4a8c:	d0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    4a90:	9100a000 	add	x0, x0, #0x28
    4a94:	97fffe14 	bl	42e4 <fwp_trap>
    4a98:	f94123f5 	ldr	x21, [sp, #576]
    4a9c:	91400273 	add	x19, x19, #0x0, lsl #12
    4aa0:	91004273 	add	x19, x19, #0x10
    4aa4:	f94003e0 	ldr	x0, [sp]
    4aa8:	f900027f 	str	xzr, [x19]
    4aac:	eb14001f 	cmp	x0, x20
    4ab0:	54000040 	b.eq	4ab8 <fwp_closure_drop.part.0+0xd4>  // b.none
    4ab4:	97fff79b 	bl	2920 <free@plt>
    4ab8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4abc:	f947f400 	ldr	x0, [x0, #4072]
    4ac0:	f9410fe2 	ldr	x2, [sp, #536]
    4ac4:	f9400001 	ldr	x1, [x0]
    4ac8:	eb010042 	subs	x2, x2, x1
    4acc:	d2800001 	mov	x1, #0x0                   	// #0
    4ad0:	540000a1 	b.ne	4ae4 <fwp_closure_drop.part.0+0x100>  // b.any
    4ad4:	910883ff 	add	sp, sp, #0x220
    4ad8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4adc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ae0:	d65f03c0 	ret
    4ae4:	f90123f5 	str	x21, [sp, #576]
    4ae8:	97fff75e 	bl	2860 <__stack_chk_fail@plt>
    4aec:	d503201f 	nop

0000000000004af0 <fwp_tape_of>:
    4af0:	aa0003e1 	mov	x1, x0
    4af4:	92403c00 	and	x0, x0, #0xffff
    4af8:	b40000e0 	cbz	x0, 4b14 <fwp_tape_of+0x24>
    4afc:	d1000403 	sub	x3, x0, #0x1
    4b00:	900000e0 	adrp	x0, 20000 <__data_start>
    4b04:	91014000 	add	x0, x0, #0x50
    4b08:	f9408802 	ldr	x2, [x0, #272]
    4b0c:	eb03005f 	cmp	x2, x3
    4b10:	540000cc 	b.gt	4b28 <fwp_tape_of+0x38>
    4b14:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4b18:	d0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    4b1c:	91016000 	add	x0, x0, #0x58
    4b20:	910003fd 	mov	x29, sp
    4b24:	97fffdf0 	bl	42e4 <fwp_trap>
    4b28:	8b030462 	add	x2, x3, x3, lsl #1
    4b2c:	f9404404 	ldr	x4, [x0, #136]
    4b30:	d37ef442 	lsl	x2, x2, #2
    4b34:	cb030042 	sub	x2, x2, x3
    4b38:	d37df042 	lsl	x2, x2, #3
    4b3c:	8b020080 	add	x0, x4, x2
    4b40:	b9400403 	ldr	w3, [x0, #4]
    4b44:	34fffe83 	cbz	w3, 4b14 <fwp_tape_of+0x24>
    4b48:	b8626882 	ldr	w2, [x4, x2]
    4b4c:	9350fc21 	asr	x1, x1, #16
    4b50:	6b01005f 	cmp	w2, w1
    4b54:	54fffe01 	b.ne	4b14 <fwp_tape_of+0x24>  // b.any
    4b58:	d65f03c0 	ret
    4b5c:	d503201f 	nop

0000000000004b60 <fwp_now_ns>:
    4b60:	d100c3ff 	sub	sp, sp, #0x30
    4b64:	52800020 	mov	w0, #0x1                   	// #1
    4b68:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    4b6c:	f947f442 	ldr	x2, [x2, #4072]
    4b70:	910023e1 	add	x1, sp, #0x8
    4b74:	a9027bfd 	stp	x29, x30, [sp, #32]
    4b78:	910083fd 	add	x29, sp, #0x20
    4b7c:	f9400043 	ldr	x3, [x2]
    4b80:	f9000fe3 	str	x3, [sp, #24]
    4b84:	d2800003 	mov	x3, #0x0                   	// #0
    4b88:	97fff702 	bl	2790 <clock_gettime@plt>
    4b8c:	350002c0 	cbnz	w0, 4be4 <fwp_now_ns+0x84>
    4b90:	a9408be1 	ldp	x1, x2, [sp, #8]
    4b94:	d2994003 	mov	x3, #0xca00                	// #51712
    4b98:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4b9c:	9b037c20 	mul	x0, x1, x3
    4ba0:	9b437c21 	smulh	x1, x1, x3
    4ba4:	ab020000 	adds	x0, x0, x2
    4ba8:	937ffc42 	asr	x2, x2, #63
    4bac:	9a020021 	adc	x1, x1, x2
    4bb0:	f100001f 	cmp	x0, #0x0
    4bb4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4bb8:	b50001c1 	cbnz	x1, 4bf0 <fwp_now_ns+0x90>
    4bbc:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    4bc0:	f947f421 	ldr	x1, [x1, #4072]
    4bc4:	f9400fe3 	ldr	x3, [sp, #24]
    4bc8:	f9400022 	ldr	x2, [x1]
    4bcc:	eb020063 	subs	x3, x3, x2
    4bd0:	d2800002 	mov	x2, #0x0                   	// #0
    4bd4:	54000141 	b.ne	4bfc <fwp_now_ns+0x9c>  // b.any
    4bd8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bdc:	9100c3ff 	add	sp, sp, #0x30
    4be0:	d65f03c0 	ret
    4be4:	d0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    4be8:	9102a000 	add	x0, x0, #0xa8
    4bec:	97fffdbe 	bl	42e4 <fwp_trap>
    4bf0:	d0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    4bf4:	91032000 	add	x0, x0, #0xc8
    4bf8:	97fffdbb 	bl	42e4 <fwp_trap>
    4bfc:	97fff719 	bl	2860 <__stack_chk_fail@plt>

0000000000004c00 <fwp_poll_events>:
    4c00:	d10103ff 	sub	sp, sp, #0x40
    4c04:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4c08:	f947f400 	ldr	x0, [x0, #4072]
    4c0c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4c10:	910083fd 	add	x29, sp, #0x20
    4c14:	f9001bf3 	str	x19, [sp, #48]
    4c18:	900000f3 	adrp	x19, 20000 <__data_start>
    4c1c:	f9400001 	ldr	x1, [x0]
    4c20:	f9000fe1 	str	x1, [sp, #24]
    4c24:	d2800001 	mov	x1, #0x0                   	// #0
    4c28:	97ffffce 	bl	4b60 <fwp_now_ns>
    4c2c:	91014261 	add	x1, x19, #0x50
    4c30:	f9408c21 	ldr	x1, [x1, #280]
    4c34:	b4000e01 	cbz	x1, 4df4 <fwp_poll_events+0x1f4>
    4c38:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4c3c:	14000005 	b	4c50 <fwp_poll_events+0x50>
    4c40:	f9408821 	ldr	x1, [x1, #272]
    4c44:	eb03005f 	cmp	x2, x3
    4c48:	9a83d042 	csel	x2, x2, x3, le
    4c4c:	b40000c1 	cbz	x1, 4c64 <fwp_poll_events+0x64>
    4c50:	f9403423 	ldr	x3, [x1, #104]
    4c54:	b6ffff62 	tbz	x2, #63, 4c40 <fwp_poll_events+0x40>
    4c58:	f9408821 	ldr	x1, [x1, #272]
    4c5c:	aa0303e2 	mov	x2, x3
    4c60:	b5ffff81 	cbnz	x1, 4c50 <fwp_poll_events+0x50>
    4c64:	b7f80c82 	tbnz	x2, #63, 4df4 <fwp_poll_events+0x1f4>
    4c68:	cb000042 	sub	x2, x2, x0
    4c6c:	f100005f 	cmp	x2, #0x0
    4c70:	540003ad 	b.le	4ce4 <fwp_poll_events+0xe4>
    4c74:	d2869b60 	mov	x0, #0x34db                	// #13531
    4c78:	d2884804 	mov	x4, #0x4240                	// #16960
    4c7c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4c80:	f2a001e4 	movk	x4, #0xf, lsl #16
    4c84:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4c88:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4c8c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4c90:	9b407c40 	smulh	x0, x2, x0
    4c94:	9352fc00 	asr	x0, x0, #18
    4c98:	cb82fc00 	sub	x0, x0, x2, asr #63
    4c9c:	9b048802 	msub	x2, x0, x4, x2
    4ca0:	f100005f 	cmp	x2, #0x0
    4ca4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4ca8:	eb01001f 	cmp	x0, x1
    4cac:	5400098c 	b.gt	4ddc <fwp_poll_events+0x1dc>
    4cb0:	340001a0 	cbz	w0, 4ce4 <fwp_poll_events+0xe4>
    4cb4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4cb8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4cbc:	72a20c41 	movk	w1, #0x1062, lsl #16
    4cc0:	9ba17c01 	umull	x1, w0, w1
    4cc4:	d366fc23 	lsr	x3, x1, #38
    4cc8:	aa0303e2 	mov	x2, x3
    4ccc:	1b058063 	msub	w3, w3, w5, w0
    4cd0:	9b247c63 	smull	x3, w3, w4
    4cd4:	910023e0 	add	x0, sp, #0x8
    4cd8:	d2800001 	mov	x1, #0x0                   	// #0
    4cdc:	a9008fe2 	stp	x2, x3, [sp, #8]
    4ce0:	97fff714 	bl	2930 <nanosleep@plt>
    4ce4:	97ffff9f 	bl	4b60 <fwp_now_ns>
    4ce8:	91014268 	add	x8, x19, #0x50
    4cec:	aa0003e7 	mov	x7, x0
    4cf0:	4f000400 	movi	v0.4s, #0x0
    4cf4:	52800029 	mov	w9, #0x1                   	// #1
    4cf8:	f9408d06 	ldr	x6, [x8, #280]
    4cfc:	d503201f 	nop
    4d00:	b40003e6 	cbz	x6, 4d7c <fwp_poll_events+0x17c>
    4d04:	f94034c1 	ldr	x1, [x6, #104]
    4d08:	aa0603e5 	mov	x5, x6
    4d0c:	f94088c6 	ldr	x6, [x6, #272]
    4d10:	eb07003f 	cmp	x1, x7
    4d14:	54ffff6c 	b.gt	4d00 <fwp_poll_events+0x100>
    4d18:	394154a0 	ldrb	w0, [x5, #85]
    4d1c:	36000120 	tbz	w0, #0, 4d40 <fwp_poll_events+0x140>
    4d20:	f94084a0 	ldr	x0, [x5, #264]
    4d24:	b4000560 	cbz	x0, 4dd0 <fwp_poll_events+0x1d0>
    4d28:	f9008806 	str	x6, [x0, #272]
    4d2c:	b4000046 	cbz	x6, 4d34 <fwp_poll_events+0x134>
    4d30:	f90084c0 	str	x0, [x6, #264]
    4d34:	910800a0 	add	x0, x5, #0x200
    4d38:	390154bf 	strb	wzr, [x5, #85]
    4d3c:	3c908000 	stur	q0, [x0, #-248]
    4d40:	f94030a0 	ldr	x0, [x5, #96]
    4d44:	390158a9 	strb	w9, [x5, #86]
    4d48:	f100001f 	cmp	x0, #0x0
    4d4c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4d50:	540002cd 	b.le	4da8 <fwp_poll_events+0x1a8>
    4d54:	f94028a0 	ldr	x0, [x5, #80]
    4d58:	f2001c1f 	tst	x0, #0xff000000ff
    4d5c:	54fffd21 	b.ne	4d00 <fwp_poll_events+0x100>  // b.any
    4d60:	f9406100 	ldr	x0, [x8, #192]
    4d64:	390150a9 	strb	w9, [x5, #84]
    4d68:	f90080bf 	str	xzr, [x5, #256]
    4d6c:	b40002c0 	cbz	x0, 4dc4 <fwp_poll_events+0x1c4>
    4d70:	f9006105 	str	x5, [x8, #192]
    4d74:	f9008005 	str	x5, [x0, #256]
    4d78:	b5fffc66 	cbnz	x6, 4d04 <fwp_poll_events+0x104>
    4d7c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4d80:	f947f400 	ldr	x0, [x0, #4072]
    4d84:	f9400fe2 	ldr	x2, [sp, #24]
    4d88:	f9400001 	ldr	x1, [x0]
    4d8c:	eb010042 	subs	x2, x2, x1
    4d90:	d2800001 	mov	x1, #0x0                   	// #0
    4d94:	540002e1 	b.ne	4df0 <fwp_poll_events+0x1f0>  // b.any
    4d98:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4d9c:	f9401bf3 	ldr	x19, [sp, #48]
    4da0:	910103ff 	add	sp, sp, #0x40
    4da4:	d65f03c0 	ret
    4da8:	394144a0 	ldrb	w0, [x5, #81]
    4dac:	3707fd40 	tbnz	w0, #0, 4d54 <fwp_poll_events+0x154>
    4db0:	394140a0 	ldrb	w0, [x5, #80]
    4db4:	3707fd00 	tbnz	w0, #0, 4d54 <fwp_poll_events+0x154>
    4db8:	aa0503e0 	mov	x0, x5
    4dbc:	97fffa3d 	bl	36b0 <fwp_cancel_tree.part.0>
    4dc0:	17ffffe5 	b	4d54 <fwp_poll_events+0x154>
    4dc4:	f9006105 	str	x5, [x8, #192]
    4dc8:	f9006505 	str	x5, [x8, #200]
    4dcc:	17ffffeb 	b	4d78 <fwp_poll_events+0x178>
    4dd0:	91014261 	add	x1, x19, #0x50
    4dd4:	f9008c26 	str	x6, [x1, #280]
    4dd8:	17ffffd5 	b	4d2c <fwp_poll_events+0x12c>
    4ddc:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4de0:	d2989362 	mov	x2, #0xc49b                	// #50331
    4de4:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4de8:	f2a00402 	movk	x2, #0x20, lsl #16
    4dec:	17ffffba 	b	4cd4 <fwp_poll_events+0xd4>
    4df0:	97fff69c 	bl	2860 <__stack_chk_fail@plt>
    4df4:	97fff890 	bl	3034 <fwp_flush>
    4df8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    4dfc:	f947e863 	ldr	x3, [x3, #4048]
    4e00:	d2800562 	mov	x2, #0x2b                  	// #43
    4e04:	d2800021 	mov	x1, #0x1                   	// #1
    4e08:	d0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    4e0c:	9103c000 	add	x0, x0, #0xf0
    4e10:	f9400063 	ldr	x3, [x3]
    4e14:	97fff6d3 	bl	2960 <fwrite@plt>
    4e18:	52800ca0 	mov	w0, #0x65                  	// #101
    4e1c:	97fff63d 	bl	2710 <exit@plt>

0000000000004e20 <fwp_heap_alloc_big>:
    4e20:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e24:	910003fd 	mov	x29, sp
    4e28:	a90153f3 	stp	x19, x20, [sp, #16]
    4e2c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e30:	a90363f7 	stp	x23, x24, [sp, #48]
    4e34:	aa0003f7 	mov	x23, x0
    4e38:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e3c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e40:	eb0002ff 	cmp	x23, x0
    4e44:	540008a8 	b.hi	4f58 <fwp_heap_alloc_big+0x138>  // b.pmore
    4e48:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e4c:	8b0002f4 	add	x20, x23, x0
    4e50:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbd0>
    4e54:	91184359 	add	x25, x26, #0x610
    4e58:	d350fe94 	lsr	x20, x20, #16
    4e5c:	2a0103f5 	mov	w21, w1
    4e60:	aa1403e0 	mov	x0, x20
    4e64:	97fff8c3 	bl	3170 <fwp_heap_chunks>
    4e68:	f949ff22 	ldr	x2, [x25, #5112]
    4e6c:	8b000813 	add	x19, x0, x0, lsl #2
    4e70:	aa0003f8 	mov	x24, x0
    4e74:	52800043 	mov	w3, #0x2                   	// #2
    4e78:	d37df273 	lsl	x19, x19, #3
    4e7c:	d2800021 	mov	x1, #0x1                   	// #1
    4e80:	8b130040 	add	x0, x2, x19
    4e84:	38336843 	strb	w3, [x2, x19]
    4e88:	39000415 	strb	w21, [x0, #1]
    4e8c:	b9000c14 	str	w20, [x0, #12]
    4e90:	f9000817 	str	x23, [x0, #16]
    4e94:	97fffd57 	bl	43f0 <fwp_rc_prepare_chunk>
    4e98:	f100069f 	cmp	x20, #0x1
    4e9c:	54000289 	b.ls	4eec <fwp_heap_alloc_big+0xcc>  // b.plast
    4ea0:	8b180294 	add	x20, x20, x24
    4ea4:	9100a273 	add	x19, x19, #0x28
    4ea8:	a90573fb 	stp	x27, x28, [sp, #80]
    4eac:	5280007b 	mov	w27, #0x3                   	// #3
    4eb0:	8b140a94 	add	x20, x20, x20, lsl #2
    4eb4:	2a1803fc 	mov	w28, w24
    4eb8:	9adb2296 	lsl	x22, x20, x27
    4ebc:	d503201f 	nop
    4ec0:	f949ff35 	ldr	x21, [x25, #5112]
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	8b1302b4 	add	x20, x21, x19
    4ecc:	aa1403e0 	mov	x0, x20
    4ed0:	97fffd48 	bl	43f0 <fwp_rc_prepare_chunk>
    4ed4:	38336abb 	strb	w27, [x21, x19]
    4ed8:	9100a273 	add	x19, x19, #0x28
    4edc:	b9000e9c 	str	w28, [x20, #12]
    4ee0:	eb1302df 	cmp	x22, x19
    4ee4:	54fffee1 	b.ne	4ec0 <fwp_heap_alloc_big+0xa0>  // b.any
    4ee8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4eec:	91184353 	add	x19, x26, #0x610
    4ef0:	aa1703e2 	mov	x2, x23
    4ef4:	52800001 	mov	w1, #0x0                   	// #0
    4ef8:	f949da60 	ldr	x0, [x19, #5040]
    4efc:	8b184018 	add	x24, x0, x24, lsl #16
    4f00:	aa1803e0 	mov	x0, x24
    4f04:	97fff64b 	bl	2830 <memset@plt>
    4f08:	f94a1260 	ldr	x0, [x19, #5152]
    4f0c:	ab170000 	adds	x0, x0, x23
    4f10:	54000242 	b.cs	4f58 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4f14:	f94a1661 	ldr	x1, [x19, #5160]
    4f18:	f90a1260 	str	x0, [x19, #5152]
    4f1c:	eb01001f 	cmp	x0, x1
    4f20:	54000049 	b.ls	4f28 <fwp_heap_alloc_big+0x108>  // b.plast
    4f24:	f90a1660 	str	x0, [x19, #5160]
    4f28:	9118435a 	add	x26, x26, #0x610
    4f2c:	9e6202e0 	scvtf	d0, x23
    4f30:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f34:	aa1803e0 	mov	x0, x24
    4f38:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f3c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f40:	1e602820 	fadd	d0, d1, d0
    4f44:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f48:	fd0a1f40 	str	d0, [x26, #5176]
    4f4c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f50:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f54:	d65f03c0 	ret
    4f58:	a90573fb 	stp	x27, x28, [sp, #80]
    4f5c:	97fff875 	bl	3130 <fwp_heap_oom>

0000000000004f60 <fwp_heap_alloc_slow>:
    4f60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f64:	910003fd 	mov	x29, sp
    4f68:	a90153f3 	stp	x19, x20, [sp, #16]
    4f6c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbd0>
    4f70:	91184262 	add	x2, x19, #0x610
    4f74:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f78:	aa0003f5 	mov	x21, x0
    4f7c:	2a0103f4 	mov	w20, w1
    4f80:	b953a440 	ldr	w0, [x2, #5028]
    4f84:	34000600 	cbz	w0, 5044 <fwp_heap_alloc_slow+0xe4>
    4f88:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f8c:	54000628 	b.hi	5050 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f90:	91003ea0 	add	x0, x21, #0xf
    4f94:	91184262 	add	x2, x19, #0x610
    4f98:	f9001bf7 	str	x23, [sp, #48]
    4f9c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4fa0:	8b401040 	add	x0, x2, x0, lsr #4
    4fa4:	cb34c084 	sub	x4, x4, w20, sxtw
    4fa8:	d37ae484 	lsl	x4, x4, #6
    4fac:	397e8003 	ldrb	w3, [x0, #4000]
    4fb0:	910f0060 	add	x0, x3, #0x3c0
    4fb4:	aa0303e1 	mov	x1, x3
    4fb8:	8b030463 	add	x3, x3, x3, lsl #1
    4fbc:	8b030c83 	add	x3, x4, x3, lsl #3
    4fc0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4fc4:	2a1703f6 	mov	w22, w23
    4fc8:	f8636844 	ldr	x4, [x2, x3]
    4fcc:	b40004e4 	cbz	x4, 5068 <fwp_heap_alloc_slow+0x108>
    4fd0:	f9400080 	ldr	x0, [x4]
    4fd4:	aa2003e0 	mvn	x0, x0
    4fd8:	f8236840 	str	x0, [x2, x3]
    4fdc:	7100069f 	cmp	w20, #0x1
    4fe0:	aa0403e0 	mov	x0, x4
    4fe4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fe8:	52800001 	mov	w1, #0x0                   	// #0
    4fec:	97fff611 	bl	2830 <memset@plt>
    4ff0:	aa0003e4 	mov	x4, x0
    4ff4:	91184260 	add	x0, x19, #0x610
    4ff8:	f94a1001 	ldr	x1, [x0, #5152]
    4ffc:	ab160021 	adds	x1, x1, x22
    5000:	540005c2 	b.cs	50b8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5004:	f94a1402 	ldr	x2, [x0, #5160]
    5008:	f90a1001 	str	x1, [x0, #5152]
    500c:	eb02003f 	cmp	x1, x2
    5010:	54000049 	b.ls	5018 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5014:	f90a1401 	str	x1, [x0, #5160]
    5018:	91184273 	add	x19, x19, #0x610
    501c:	1e6302e1 	ucvtf	d1, w23
    5020:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5024:	aa0403e0 	mov	x0, x4
    5028:	fd4a1e60 	ldr	d0, [x19, #5176]
    502c:	f9401bf7 	ldr	x23, [sp, #48]
    5030:	1e612800 	fadd	d0, d0, d1
    5034:	fd0a1e60 	str	d0, [x19, #5176]
    5038:	a94153f3 	ldp	x19, x20, [sp, #16]
    503c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5040:	d65f03c0 	ret
    5044:	97fffb3b 	bl	3d30 <fwp_heap_init>
    5048:	f14012bf 	cmp	x21, #0x4, lsl #12
    504c:	54fffa29 	b.ls	4f90 <fwp_heap_alloc_slow+0x30>  // b.plast
    5050:	2a1403e1 	mov	w1, w20
    5054:	aa1503e0 	mov	x0, x21
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5060:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5064:	17ffff6f 	b	4e20 <fwp_heap_alloc_big>
    5068:	8b030042 	add	x2, x2, x3
    506c:	f9400444 	ldr	x4, [x2, #8]
    5070:	b4000104 	cbz	x4, 5090 <fwp_heap_alloc_slow+0x130>
    5074:	f9400840 	ldr	x0, [x2, #16]
    5078:	cb040000 	sub	x0, x0, x4
    507c:	eb16001f 	cmp	x0, x22
    5080:	54000083 	b.cc	5090 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5084:	8b160080 	add	x0, x4, x22
    5088:	f9000440 	str	x0, [x2, #8]
    508c:	17ffffd4 	b	4fdc <fwp_heap_alloc_slow+0x7c>
    5090:	52800302 	mov	w2, #0x18                  	// #24
    5094:	52807804 	mov	w4, #0x3c0                 	// #960
    5098:	91184260 	add	x0, x19, #0x610
    509c:	9ba27c23 	umull	x3, w1, w2
    50a0:	2a1403e2 	mov	w2, w20
    50a4:	9b240e84 	smaddl	x4, w20, w4, x3
    50a8:	8b040000 	add	x0, x0, x4
    50ac:	97fffd19 	bl	4510 <fwp_heap_refill>
    50b0:	aa0003e4 	mov	x4, x0
    50b4:	17ffffca 	b	4fdc <fwp_heap_alloc_slow+0x7c>
    50b8:	97fff81e 	bl	3130 <fwp_heap_oom>
    50bc:	d503201f 	nop

00000000000050c0 <fwp_heap_alloc>:
    50c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    50c4:	910003fd 	mov	x29, sp
    50c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    50cc:	f00000d6 	adrp	x22, 20000 <__data_start>
    50d0:	910142c2 	add	x2, x22, #0x50
    50d4:	a90363f7 	stp	x23, x24, [sp, #48]
    50d8:	b9412058 	ldr	w24, [x2, #288]
    50dc:	a90153f3 	stp	x19, x20, [sp, #16]
    50e0:	7100031f 	cmp	w24, #0x0
    50e4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50e8:	540008a1 	b.ne	51fc <fwp_heap_alloc+0x13c>  // b.any
    50ec:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbd0>
    50f0:	911842f3 	add	x19, x23, #0x610
    50f4:	f140101f 	cmp	x0, #0x4, lsl #12
    50f8:	b953a662 	ldr	w2, [x19, #5028]
    50fc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5100:	54000740 	b.eq	51e8 <fwp_heap_alloc+0x128>  // b.none
    5104:	91003c03 	add	x3, x0, #0xf
    5108:	937c7c22 	sbfiz	x2, x1, #4, #32
    510c:	cb21c042 	sub	x2, x2, w1, sxtw
    5110:	8b431263 	add	x3, x19, x3, lsr #4
    5114:	d37ae442 	lsl	x2, x2, #6
    5118:	397e8063 	ldrb	w3, [x3, #4000]
    511c:	910f0064 	add	x4, x3, #0x3c0
    5120:	8b030463 	add	x3, x3, x3, lsl #1
    5124:	8b030c43 	add	x3, x2, x3, lsl #3
    5128:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    512c:	2a1503f4 	mov	w20, w21
    5130:	f8636a64 	ldr	x4, [x19, x3]
    5134:	b40004c4 	cbz	x4, 51cc <fwp_heap_alloc+0x10c>
    5138:	f9400085 	ldr	x5, [x4]
    513c:	7100043f 	cmp	w1, #0x1
    5140:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5144:	aa0403e0 	mov	x0, x4
    5148:	aa2503e5 	mvn	x5, x5
    514c:	52800001 	mov	w1, #0x0                   	// #0
    5150:	f8236a65 	str	x5, [x19, x3]
    5154:	97fff5b7 	bl	2830 <memset@plt>
    5158:	aa0003e4 	mov	x4, x0
    515c:	f94a1260 	ldr	x0, [x19, #5152]
    5160:	ab140000 	adds	x0, x0, x20
    5164:	54000722 	b.cs	5248 <fwp_heap_alloc+0x188>  // b.hs, b.nlast
    5168:	f94a1661 	ldr	x1, [x19, #5160]
    516c:	f90a1260 	str	x0, [x19, #5152]
    5170:	eb01001f 	cmp	x0, x1
    5174:	54000049 	b.ls	517c <fwp_heap_alloc+0xbc>  // b.plast
    5178:	f90a1660 	str	x0, [x19, #5160]
    517c:	911842e0 	add	x0, x23, #0x610
    5180:	1e6302a1 	ucvtf	d1, w21
    5184:	fd4a1c00 	ldr	d0, [x0, #5176]
    5188:	1e612800 	fadd	d0, d0, d1
    518c:	fd0a1c00 	str	d0, [x0, #5176]
    5190:	34000138 	cbz	w24, 51b4 <fwp_heap_alloc+0xf4>
    5194:	911842e1 	add	x1, x23, #0x610
    5198:	910142c0 	add	x0, x22, #0x50
    519c:	fd4a1020 	ldr	d0, [x1, #5152]
    51a0:	6d538402 	ldp	d2, d1, [x0, #312]
    51a4:	7e61d800 	ucvtf	d0, d0
    51a8:	1e623800 	fsub	d0, d0, d2
    51ac:	1e612010 	fcmpe	d0, d1
    51b0:	5400030c 	b.gt	5210 <fwp_heap_alloc+0x150>
    51b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    51b8:	aa0403e0 	mov	x0, x4
    51bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51c0:	a94363f7 	ldp	x23, x24, [sp, #48]
    51c4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51c8:	d65f03c0 	ret
    51cc:	8b030263 	add	x3, x19, x3
    51d0:	f9400464 	ldr	x4, [x3, #8]
    51d4:	b40000a4 	cbz	x4, 51e8 <fwp_heap_alloc+0x128>
    51d8:	f9400862 	ldr	x2, [x3, #16]
    51dc:	cb040042 	sub	x2, x2, x4
    51e0:	eb02029f 	cmp	x20, x2
    51e4:	54000249 	b.ls	522c <fwp_heap_alloc+0x16c>  // b.plast
    51e8:	97ffff5e 	bl	4f60 <fwp_heap_alloc_slow>
    51ec:	aa0003e4 	mov	x4, x0
    51f0:	910142c1 	add	x1, x22, #0x50
    51f4:	b9412038 	ldr	w24, [x1, #288]
    51f8:	17ffffe6 	b	5190 <fwp_heap_alloc+0xd0>
    51fc:	a9528c44 	ldp	x4, x3, [x2, #296]
    5200:	91000484 	add	x4, x4, #0x1
    5204:	8b000063 	add	x3, x3, x0
    5208:	a9128c44 	stp	x4, x3, [x2, #296]
    520c:	17ffffb8 	b	50ec <fwp_heap_alloc+0x2c>
    5210:	a94153f3 	ldp	x19, x20, [sp, #16]
    5214:	fd00a000 	str	d0, [x0, #320]
    5218:	a9425bf5 	ldp	x21, x22, [sp, #32]
    521c:	aa0403e0 	mov	x0, x4
    5220:	a94363f7 	ldp	x23, x24, [sp, #48]
    5224:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5228:	d65f03c0 	ret
    522c:	7100043f 	cmp	w1, #0x1
    5230:	8b140085 	add	x5, x4, x20
    5234:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5238:	52800001 	mov	w1, #0x0                   	// #0
    523c:	aa0403e0 	mov	x0, x4
    5240:	f9000465 	str	x5, [x3, #8]
    5244:	17ffffc4 	b	5154 <fwp_heap_alloc+0x94>
    5248:	97fff7ba 	bl	3130 <fwp_heap_oom>
    524c:	d503201f 	nop

0000000000005250 <fwp_data.part.0.constprop.0>:
    5250:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5254:	910003fd 	mov	x29, sp
    5258:	a9025bf5 	stp	x21, x22, [sp, #32]
    525c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5260:	910142c2 	add	x2, x22, #0x50
    5264:	a9046bf9 	stp	x25, x26, [sp, #64]
    5268:	b9412059 	ldr	w25, [x2, #288]
    526c:	a90153f3 	stp	x19, x20, [sp, #16]
    5270:	aa0103f4 	mov	x20, x1
    5274:	a90363f7 	stp	x23, x24, [sp, #48]
    5278:	2a0003f7 	mov	w23, w0
    527c:	340000b9 	cbz	w25, 5290 <fwp_data.part.0.constprop.0+0x40>
    5280:	a9528041 	ldp	x1, x0, [x2, #296]
    5284:	91000421 	add	x1, x1, #0x1
    5288:	91006000 	add	x0, x0, #0x18
    528c:	a9128041 	stp	x1, x0, [x2, #296]
    5290:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbd0>
    5294:	911842a3 	add	x3, x21, #0x610
    5298:	b953a460 	ldr	w0, [x3, #5028]
    529c:	34000840 	cbz	w0, 53a4 <fwp_data.part.0.constprop.0+0x154>
    52a0:	397e8862 	ldrb	w2, [x3, #4002]
    52a4:	910f0040 	add	x0, x2, #0x3c0
    52a8:	8b020442 	add	x2, x2, x2, lsl #1
    52ac:	d37df042 	lsl	x2, x2, #3
    52b0:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    52b4:	2a1a03f8 	mov	w24, w26
    52b8:	f8626873 	ldr	x19, [x3, x2]
    52bc:	b4000613 	cbz	x19, 537c <fwp_data.part.0.constprop.0+0x12c>
    52c0:	f9400260 	ldr	x0, [x19]
    52c4:	aa2003e0 	mvn	x0, x0
    52c8:	f8226860 	str	x0, [x3, x2]
    52cc:	f100631f 	cmp	x24, #0x18
    52d0:	540000e9 	b.ls	52ec <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    52d4:	d1006702 	sub	x2, x24, #0x19
    52d8:	91006260 	add	x0, x19, #0x18
    52dc:	927df042 	and	x2, x2, #0xfffffffffffffff8
    52e0:	52800001 	mov	w1, #0x0                   	// #0
    52e4:	91002042 	add	x2, x2, #0x8
    52e8:	97fff552 	bl	2830 <memset@plt>
    52ec:	911842a0 	add	x0, x21, #0x610
    52f0:	f94a1001 	ldr	x1, [x0, #5152]
    52f4:	ab180021 	adds	x1, x1, x24
    52f8:	54000682 	b.cs	53c8 <fwp_data.part.0.constprop.0+0x178>  // b.hs, b.nlast
    52fc:	f94a1402 	ldr	x2, [x0, #5160]
    5300:	f90a1001 	str	x1, [x0, #5152]
    5304:	eb02003f 	cmp	x1, x2
    5308:	54000049 	b.ls	5310 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    530c:	f90a1401 	str	x1, [x0, #5160]
    5310:	911842a0 	add	x0, x21, #0x610
    5314:	1e630341 	ucvtf	d1, w26
    5318:	fd4a1c00 	ldr	d0, [x0, #5176]
    531c:	1e612800 	fadd	d0, d0, d1
    5320:	fd0a1c00 	str	d0, [x0, #5176]
    5324:	34000139 	cbz	w25, 5348 <fwp_data.part.0.constprop.0+0xf8>
    5328:	911842b5 	add	x21, x21, #0x610
    532c:	910142d6 	add	x22, x22, #0x50
    5330:	fd4a12a0 	ldr	d0, [x21, #5152]
    5334:	6d5386c2 	ldp	d2, d1, [x22, #312]
    5338:	7e61d800 	ucvtf	d0, d0
    533c:	1e623800 	fsub	d0, d0, d2
    5340:	1e612010 	fcmpe	d0, d1
    5344:	540003ec 	b.gt	53c0 <fwp_data.part.0.constprop.0+0x170>
    5348:	52800040 	mov	w0, #0x2                   	// #2
    534c:	29000277 	stp	w23, w0, [x19]
    5350:	aa1303e0 	mov	x0, x19
    5354:	f9400281 	ldr	x1, [x20]
    5358:	f9000661 	str	x1, [x19, #8]
    535c:	f9400681 	ldr	x1, [x20, #8]
    5360:	f9000a61 	str	x1, [x19, #16]
    5364:	a94153f3 	ldp	x19, x20, [sp, #16]
    5368:	a9425bf5 	ldp	x21, x22, [sp, #32]
    536c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5370:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5374:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5378:	d65f03c0 	ret
    537c:	8b020063 	add	x3, x3, x2
    5380:	f9400473 	ldr	x19, [x3, #8]
    5384:	b4000113 	cbz	x19, 53a4 <fwp_data.part.0.constprop.0+0x154>
    5388:	f9400860 	ldr	x0, [x3, #16]
    538c:	cb130000 	sub	x0, x0, x19
    5390:	eb00031f 	cmp	x24, x0
    5394:	54000088 	b.hi	53a4 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5398:	8b180260 	add	x0, x19, x24
    539c:	f9000460 	str	x0, [x3, #8]
    53a0:	17ffffcb 	b	52cc <fwp_data.part.0.constprop.0+0x7c>
    53a4:	52800001 	mov	w1, #0x0                   	// #0
    53a8:	d2800300 	mov	x0, #0x18                  	// #24
    53ac:	97ffff45 	bl	50c0 <fwp_heap_alloc>
    53b0:	aa0003f3 	mov	x19, x0
    53b4:	910142c1 	add	x1, x22, #0x50
    53b8:	b9412039 	ldr	w25, [x1, #288]
    53bc:	17ffffda 	b	5324 <fwp_data.part.0.constprop.0+0xd4>
    53c0:	fd00a2c0 	str	d0, [x22, #320]
    53c4:	17ffffe1 	b	5348 <fwp_data.part.0.constprop.0+0xf8>
    53c8:	97fff75a 	bl	3130 <fwp_heap_oom>
    53cc:	d503201f 	nop

00000000000053d0 <fwp_tape_grow.constprop.0>:
    53d0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    53d4:	d2800802 	mov	x2, #0x40                  	// #64
    53d8:	910003fd 	mov	x29, sp
    53dc:	a90153f3 	stp	x19, x20, [sp, #16]
    53e0:	aa0003f4 	mov	x20, x0
    53e4:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    53e8:	f9400e93 	ldr	x19, [x20, #24]
    53ec:	f100027f 	cmp	x19, #0x0
    53f0:	9a821273 	csel	x19, x19, x2, ne	// ne = any
    53f4:	eb13003f 	cmp	x1, x19
    53f8:	540000ed 	b.le	5414 <fwp_tape_grow.constprop.0+0x44>
    53fc:	eb00027f 	cmp	x19, x0
    5400:	5400066d 	b.le	54cc <fwp_tape_grow.constprop.0+0xfc>
    5404:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    5408:	eb13003f 	cmp	x1, x19
    540c:	5400004d 	b.le	5414 <fwp_tape_grow.constprop.0+0x44>
    5410:	14000000 	b	5410 <fwp_tape_grow.constprop.0+0x40>
    5414:	a9025bf5 	stp	x21, x22, [sp, #32]
    5418:	f9402a95 	ldr	x21, [x20, #80]
    541c:	b40005d5 	cbz	x21, 54d4 <fwp_tape_grow.constprop.0+0x104>
    5420:	f9401680 	ldr	x0, [x20, #40]
    5424:	d37df261 	lsl	x1, x19, #3
    5428:	52800022 	mov	w2, #0x1                   	// #1
    542c:	97fffb15 	bl	4080 <ad_raw_realloc>
    5430:	b4000700 	cbz	x0, 5510 <fwp_tape_grow.constprop.0+0x140>
    5434:	f94032b6 	ldr	x22, [x21, #96]
    5438:	f9001680 	str	x0, [x20, #40]
    543c:	eb1302df 	cmp	x22, x19
    5440:	540003ca 	b.ge	54b8 <fwp_tape_grow.constprop.0+0xe8>  // b.tcont
    5444:	a90363f7 	stp	x23, x24, [sp, #48]
    5448:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    544c:	f90023f9 	str	x25, [sp, #64]
    5450:	eb00027f 	cmp	x19, x0
    5454:	54000588 	b.hi	5504 <fwp_tape_grow.constprop.0+0x134>  // b.pmore
    5458:	f94022b8 	ldr	x24, [x21, #64]
    545c:	d37cee79 	lsl	x25, x19, #4
    5460:	aa1903e0 	mov	x0, x25
    5464:	52800041 	mov	w1, #0x2                   	// #2
    5468:	97ffff16 	bl	50c0 <fwp_heap_alloc>
    546c:	aa0003f7 	mov	x23, x0
    5470:	b4000118 	cbz	x24, 5490 <fwp_tape_grow.constprop.0+0xc0>
    5474:	d37ceed6 	lsl	x22, x22, #4
    5478:	aa1803e1 	mov	x1, x24
    547c:	eb1902df 	cmp	x22, x25
    5480:	9a9992c2 	csel	x2, x22, x25, ls	// ls = plast
    5484:	97fff48f 	bl	26c0 <memcpy@plt>
    5488:	aa1803e0 	mov	x0, x24
    548c:	97fffc51 	bl	45d0 <fwp_mem_free>
    5490:	f94032a0 	ldr	x0, [x21, #96]
    5494:	52800001 	mov	w1, #0x0                   	// #0
    5498:	cb000262 	sub	x2, x19, x0
    549c:	8b0012e0 	add	x0, x23, x0, lsl #4
    54a0:	d37cec42 	lsl	x2, x2, #4
    54a4:	97fff4e3 	bl	2830 <memset@plt>
    54a8:	f94023f9 	ldr	x25, [sp, #64]
    54ac:	f90022b7 	str	x23, [x21, #64]
    54b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    54b4:	f90032b3 	str	x19, [x21, #96]
    54b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    54bc:	f9000e93 	str	x19, [x20, #24]
    54c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    54c4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    54c8:	d65f03c0 	ret
    54cc:	d37ffa73 	lsl	x19, x19, #1
    54d0:	17ffffc9 	b	53f4 <fwp_tape_grow.constprop.0+0x24>
    54d4:	f9401280 	ldr	x0, [x20, #32]
    54d8:	8b130661 	add	x1, x19, x19, lsl #1
    54dc:	52800042 	mov	w2, #0x2                   	// #2
    54e0:	d37df021 	lsl	x1, x1, #3
    54e4:	97fffae7 	bl	4080 <ad_raw_realloc>
    54e8:	b4000140 	cbz	x0, 5510 <fwp_tape_grow.constprop.0+0x140>
    54ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    54f0:	f9000e93 	str	x19, [x20, #24]
    54f4:	f9001280 	str	x0, [x20, #32]
    54f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    54fc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5500:	d65f03c0 	ret
    5504:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5508:	91052000 	add	x0, x0, #0x148
    550c:	97fffb76 	bl	42e4 <fwp_trap>
    5510:	aa1403e0 	mov	x0, x20
    5514:	a90363f7 	stp	x23, x24, [sp, #48]
    5518:	f90023f9 	str	x25, [sp, #64]
    551c:	97fff6ae 	bl	2fd4 <fwp_tape_unlink_scope>
    5520:	f9401280 	ldr	x0, [x20, #32]
    5524:	b4000040 	cbz	x0, 552c <fwp_tape_grow.constprop.0+0x15c>
    5528:	97fffaa2 	bl	3fb0 <ad_raw_free.part.0>
    552c:	f9401680 	ldr	x0, [x20, #40]
    5530:	b4000040 	cbz	x0, 5538 <fwp_tape_grow.constprop.0+0x168>
    5534:	97fffa9f 	bl	3fb0 <ad_raw_free.part.0>
    5538:	f9401a80 	ldr	x0, [x20, #48]
    553c:	b4000040 	cbz	x0, 5544 <fwp_tape_grow.constprop.0+0x174>
    5540:	97fffa9c 	bl	3fb0 <ad_raw_free.part.0>
    5544:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    5548:	f947e821 	ldr	x1, [x1, #4048]
    554c:	f9000e9f 	str	xzr, [x20, #24]
    5550:	4f000400 	movi	v0.4s, #0x0
    5554:	a9037e9f 	stp	xzr, xzr, [x20, #48]
    5558:	d2800262 	mov	x2, #0x13                  	// #19
    555c:	f9400023 	ldr	x3, [x1]
    5560:	b900069f 	str	wzr, [x20, #4]
    5564:	d2800021 	mov	x1, #0x1                   	// #1
    5568:	90000020 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    556c:	91312000 	add	x0, x0, #0xc48
    5570:	3c808280 	stur	q0, [x20, #8]
    5574:	3d800a80 	str	q0, [x20, #32]
    5578:	97fff4fa 	bl	2960 <fwrite@plt>
    557c:	d2800000 	mov	x0, #0x0                   	// #0
    5580:	97fff504 	bl	2990 <fflush@plt>
    5584:	52800cc0 	mov	w0, #0x66                  	// #102
    5588:	97fff512 	bl	29d0 <_Exit@plt>
    558c:	d503201f 	nop

0000000000005590 <w123>:
    5590:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5594:	910003fd 	mov	x29, sp
    5598:	6d0427e8 	stp	d8, d9, [sp, #64]
    559c:	1e612808 	fadd	d8, d0, d1
    55a0:	ea01001f 	tst	x0, x1
    55a4:	54000b44 	b.mi	570c <w123+0x17c>  // b.first
    55a8:	a90153f3 	stp	x19, x20, [sp, #16]
    55ac:	aa0003f4 	mov	x20, x0
    55b0:	aa0103f3 	mov	x19, x1
    55b4:	a9025bf5 	stp	x21, x22, [sp, #32]
    55b8:	aa010000 	orr	x0, x0, x1
    55bc:	aa0203f5 	mov	x21, x2
    55c0:	f9001bf7 	str	x23, [sp, #48]
    55c4:	b7f80200 	tbnz	x0, #63, 5604 <w123+0x74>
    55c8:	9360fc37 	asr	x23, x1, #32
    55cc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    55d0:	eb9482ff 	cmp	x23, x20, asr #32
    55d4:	54000a61 	b.ne	5720 <w123+0x190>  // b.any
    55d8:	f94002a0 	ldr	x0, [x21]
    55dc:	eb17001f 	cmp	x0, x23
    55e0:	54000220 	b.eq	5624 <w123+0x94>  // b.none
    55e4:	aa1703e0 	mov	x0, x23
    55e8:	97fffd42 	bl	4af0 <fwp_tape_of>
    55ec:	aa0003f6 	mov	x22, x0
    55f0:	f9402800 	ldr	x0, [x0, #80]
    55f4:	b40002e0 	cbz	x0, 5650 <w123+0xc0>
    55f8:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    55fc:	9106c000 	add	x0, x0, #0x1b0
    5600:	97fffb39 	bl	42e4 <fwp_trap>
    5604:	b6f80214 	tbz	x20, #63, 5644 <w123+0xb4>
    5608:	f94002a0 	ldr	x0, [x21]
    560c:	9360fc37 	asr	x23, x1, #32
    5610:	2f00e409 	movi	d9, #0x0
    5614:	aa0103f4 	mov	x20, x1
    5618:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    561c:	eb17001f 	cmp	x0, x23
    5620:	54fffe21 	b.ne	55e4 <w123+0x54>  // b.any
    5624:	f94006b6 	ldr	x22, [x21, #8]
    5628:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    562c:	f9400ad7 	ldr	x23, [x22, #16]
    5630:	eb0002ff 	cmp	x23, x0
    5634:	5400018d 	b.le	5664 <w123+0xd4>
    5638:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    563c:	91052000 	add	x0, x0, #0x148
    5640:	97fffb29 	bl	42e4 <fwp_trap>
    5644:	9360fe97 	asr	x23, x20, #32
    5648:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    564c:	17ffffe3 	b	55d8 <w123+0x48>
    5650:	a9005ab7 	stp	x23, x22, [x21]
    5654:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5658:	f9400ad7 	ldr	x23, [x22, #16]
    565c:	eb0002ff 	cmp	x23, x0
    5660:	54fffecc 	b.gt	5638 <w123+0xa8>
    5664:	eb3442ff 	cmp	x23, w20, uxtw
    5668:	540004cd 	b.le	5700 <w123+0x170>
    566c:	b7f80073 	tbnz	x19, #63, 5678 <w123+0xe8>
    5670:	eb3342ff 	cmp	x23, w19, uxtw
    5674:	5400046d 	b.le	5700 <w123+0x170>
    5678:	f94006d5 	ldr	x21, [x22, #8]
    567c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5680:	cb1502f5 	sub	x21, x23, x21
    5684:	910006a1 	add	x1, x21, #0x1
    5688:	eb00003f 	cmp	x1, x0
    568c:	54fffd68 	b.hi	5638 <w123+0xa8>  // b.pmore
    5690:	f9400ec0 	ldr	x0, [x22, #24]
    5694:	eb00003f 	cmp	x1, x0
    5698:	5400006d 	b.le	56a4 <w123+0x114>
    569c:	aa1603e0 	mov	x0, x22
    56a0:	97ffff4c 	bl	53d0 <fwp_tape_grow.constprop.0>
    56a4:	f100027f 	cmp	x19, #0x0
    56a8:	9e670282 	fmov	d2, x20
    56ac:	da9fa273 	csinv	x19, x19, xzr, ge	// ge = tcont
    56b0:	8b1506b5 	add	x21, x21, x21, lsl #1
    56b4:	f94012c2 	ldr	x2, [x22, #32]
    56b8:	4e181e62 	mov	v2.d[1], x19
    56bc:	d37df2b5 	lsl	x21, x21, #3
    56c0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    56c4:	8b150040 	add	x0, x2, x21
    56c8:	92607e81 	and	x1, x20, #0xffffffff00000000
    56cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    56d0:	aa170021 	orr	x1, x1, x23
    56d4:	0ea12842 	xtn	v2.2s, v2.2d
    56d8:	910006f7 	add	x23, x23, #0x1
    56dc:	fc356842 	str	d2, [x2, x21]
    56e0:	6d00a400 	stp	d0, d9, [x0, #8]
    56e4:	9e660100 	fmov	x0, d8
    56e8:	f9000ad7 	str	x23, [x22, #16]
    56ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    56f0:	f9401bf7 	ldr	x23, [sp, #48]
    56f4:	6d4427e8 	ldp	d8, d9, [sp, #64]
    56f8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    56fc:	d65f03c0 	ret
    5700:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5704:	91078000 	add	x0, x0, #0x1e0
    5708:	97fffaf7 	bl	42e4 <fwp_trap>
    570c:	9e660100 	fmov	x0, d8
    5710:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    5714:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5718:	a8c57bfd 	ldp	x29, x30, [sp], #80
    571c:	d65f03c0 	ret
    5720:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5724:	9105a000 	add	x0, x0, #0x168
    5728:	97fffaef 	bl	42e4 <fwp_trap>
    572c:	d503201f 	nop

0000000000005730 <w120>:
    5730:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5734:	910003fd 	mov	x29, sp
    5738:	a90153f3 	stp	x19, x20, [sp, #16]
    573c:	aa0203f3 	mov	x19, x2
    5740:	a9025bf5 	stp	x21, x22, [sp, #32]
    5744:	aa0003f6 	mov	x22, x0
    5748:	aa0103f5 	mov	x21, x1
    574c:	a90363f7 	stp	x23, x24, [sp, #48]
    5750:	f90023f9 	str	x25, [sp, #64]
    5754:	fd0027ea 	str	d10, [sp, #72]
    5758:	1e60080a 	fmul	d10, d0, d0
    575c:	6d0527e8 	stp	d8, d9, [sp, #80]
    5760:	1e604008 	fmov	d8, d0
    5764:	1e604029 	fmov	d9, d1
    5768:	b7f82500 	tbnz	x0, #63, 5c08 <w120+0x4d8>
    576c:	9360fc14 	asr	x20, x0, #32
    5770:	f9400040 	ldr	x0, [x2]
    5774:	eb14001f 	cmp	x0, x20
    5778:	54002340 	b.eq	5be0 <w120+0x4b0>  // b.none
    577c:	aa1403e0 	mov	x0, x20
    5780:	97fffcdc 	bl	4af0 <fwp_tape_of>
    5784:	aa0003f7 	mov	x23, x0
    5788:	f9402800 	ldr	x0, [x0, #80]
    578c:	b4000080 	cbz	x0, 579c <w120+0x6c>
    5790:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5794:	9106c000 	add	x0, x0, #0x1b0
    5798:	97fffad3 	bl	42e4 <fwp_trap>
    579c:	a9005e74 	stp	x20, x23, [x19]
    57a0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    57a4:	f9400af8 	ldr	x24, [x23, #16]
    57a8:	eb00031f 	cmp	x24, x0
    57ac:	5400210c 	b.gt	5bcc <w120+0x49c>
    57b0:	eb36431f 	cmp	x24, w22, uxtw
    57b4:	5400206d 	b.le	5bc0 <w120+0x490>
    57b8:	f94006f4 	ldr	x20, [x23, #8]
    57bc:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    57c0:	cb140314 	sub	x20, x24, x20
    57c4:	91000681 	add	x1, x20, #0x1
    57c8:	eb00003f 	cmp	x1, x0
    57cc:	54002008 	b.hi	5bcc <w120+0x49c>  // b.pmore
    57d0:	f9400ee0 	ldr	x0, [x23, #24]
    57d4:	eb00003f 	cmp	x1, x0
    57d8:	5400006d 	b.le	57e4 <w120+0xb4>
    57dc:	aa1703e0 	mov	x0, x23
    57e0:	97fffefc 	bl	53d0 <fwp_tape_grow.constprop.0>
    57e4:	8b140681 	add	x1, x20, x20, lsl #1
    57e8:	92607ed4 	and	x20, x22, #0xffffffff00000000
    57ec:	f94012e2 	ldr	x2, [x23, #32]
    57f0:	d37df021 	lsl	x1, x1, #3
    57f4:	aa180294 	orr	x20, x20, x24
    57f8:	91000718 	add	x24, x24, #0x1
    57fc:	8b010040 	add	x0, x2, x1
    5800:	b8216856 	str	w22, [x2, x1]
    5804:	9360fe99 	asr	x25, x20, #32
    5808:	b9000416 	str	w22, [x0, #4]
    580c:	6d00a008 	stp	d8, d8, [x0, #8]
    5810:	f9000af8 	str	x24, [x23, #16]
    5814:	b7f80075 	tbnz	x21, #63, 5820 <w120+0xf0>
    5818:	eb95833f 	cmp	x25, x21, asr #32
    581c:	540021c1 	b.ne	5c54 <w120+0x524>  // b.any
    5820:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5824:	1e6a3929 	fsub	d9, d9, d10
    5828:	3dc2d400 	ldr	q0, [x0, #2896]
    582c:	3d801be0 	str	q0, [sp, #96]
    5830:	f9400260 	ldr	x0, [x19]
    5834:	eb19001f 	cmp	x0, x25
    5838:	54001d00 	b.eq	5bd8 <w120+0x4a8>  // b.none
    583c:	aa1903e0 	mov	x0, x25
    5840:	97fffcac 	bl	4af0 <fwp_tape_of>
    5844:	aa0003f8 	mov	x24, x0
    5848:	f9402800 	ldr	x0, [x0, #80]
    584c:	b5fffa20 	cbnz	x0, 5790 <w120+0x60>
    5850:	a9006279 	stp	x25, x24, [x19]
    5854:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5858:	f9400b19 	ldr	x25, [x24, #16]
    585c:	eb00033f 	cmp	x25, x0
    5860:	54001b6c 	b.gt	5bcc <w120+0x49c>
    5864:	eb34433f 	cmp	x25, w20, uxtw
    5868:	54001acd 	b.le	5bc0 <w120+0x490>
    586c:	b7f80075 	tbnz	x21, #63, 5878 <w120+0x148>
    5870:	eb35433f 	cmp	x25, w21, uxtw
    5874:	54001a6d 	b.le	5bc0 <w120+0x490>
    5878:	f9400717 	ldr	x23, [x24, #8]
    587c:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5880:	cb170337 	sub	x23, x25, x23
    5884:	910006e1 	add	x1, x23, #0x1
    5888:	eb00003f 	cmp	x1, x0
    588c:	54001a08 	b.hi	5bcc <w120+0x49c>  // b.pmore
    5890:	f9400f00 	ldr	x0, [x24, #24]
    5894:	eb00003f 	cmp	x1, x0
    5898:	5400006d 	b.le	58a4 <w120+0x174>
    589c:	aa1803e0 	mov	x0, x24
    58a0:	97fffecc 	bl	53d0 <fwp_tape_grow.constprop.0>
    58a4:	f10002bf 	cmp	x21, #0x0
    58a8:	9e670282 	fmov	d2, x20
    58ac:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    58b0:	9a81a2b5 	csel	x21, x21, x1, ge	// ge = tcont
    58b4:	f9401300 	ldr	x0, [x24, #32]
    58b8:	4e181ea2 	mov	v2.d[1], x21
    58bc:	8b1706f7 	add	x23, x23, x23, lsl #1
    58c0:	91000722 	add	x2, x25, #0x1
    58c4:	3dc01be0 	ldr	q0, [sp, #96]
    58c8:	d37df2f7 	lsl	x23, x23, #3
    58cc:	0ea12842 	xtn	v2.2s, v2.2d
    58d0:	8b170003 	add	x3, x0, x23
    58d4:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    58d8:	92607e94 	and	x20, x20, #0xffffffff00000000
    58dc:	aa190294 	orr	x20, x20, x25
    58e0:	1e68394a 	fsub	d10, d10, d8
    58e4:	fc376802 	str	d2, [x0, x23]
    58e8:	3c808060 	stur	q0, [x3, #8]
    58ec:	f9000b02 	str	x2, [x24, #16]
    58f0:	b7f81b96 	tbnz	x22, #63, 5c60 <w120+0x530>
    58f4:	f9400260 	ldr	x0, [x19]
    58f8:	9360fed5 	asr	x21, x22, #32
    58fc:	eb15001f 	cmp	x0, x21
    5900:	54001800 	b.eq	5c00 <w120+0x4d0>  // b.none
    5904:	aa1503e0 	mov	x0, x21
    5908:	97fffc7a 	bl	4af0 <fwp_tape_of>
    590c:	aa0003f7 	mov	x23, x0
    5910:	f9402800 	ldr	x0, [x0, #80]
    5914:	b5fff3e0 	cbnz	x0, 5790 <w120+0x60>
    5918:	a9005e75 	stp	x21, x23, [x19]
    591c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5920:	f9400af8 	ldr	x24, [x23, #16]
    5924:	eb00031f 	cmp	x24, x0
    5928:	5400152c 	b.gt	5bcc <w120+0x49c>
    592c:	eb36431f 	cmp	x24, w22, uxtw
    5930:	5400148d 	b.le	5bc0 <w120+0x490>
    5934:	f94006f5 	ldr	x21, [x23, #8]
    5938:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    593c:	cb150315 	sub	x21, x24, x21
    5940:	910006a1 	add	x1, x21, #0x1
    5944:	eb00003f 	cmp	x1, x0
    5948:	54001428 	b.hi	5bcc <w120+0x49c>  // b.pmore
    594c:	f9400ee0 	ldr	x0, [x23, #24]
    5950:	eb00003f 	cmp	x1, x0
    5954:	5400006d 	b.le	5960 <w120+0x230>
    5958:	aa1703e0 	mov	x0, x23
    595c:	97fffe9d 	bl	53d0 <fwp_tape_grow.constprop.0>
    5960:	8b1506b5 	add	x21, x21, x21, lsl #1
    5964:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5968:	f94012e2 	ldr	x2, [x23, #32]
    596c:	d37df2a1 	lsl	x1, x21, #3
    5970:	3dc2d400 	ldr	q0, [x0, #2896]
    5974:	8b010040 	add	x0, x2, x1
    5978:	b8216856 	str	w22, [x2, x1]
    597c:	92607ec3 	and	x3, x22, #0xffffffff00000000
    5980:	12800001 	mov	w1, #0xffffffff            	// #-1
    5984:	aa180075 	orr	x21, x3, x24
    5988:	b9000401 	str	w1, [x0, #4]
    598c:	91000718 	add	x24, x24, #0x1
    5990:	3c808000 	stur	q0, [x0, #8]
    5994:	f9000af8 	str	x24, [x23, #16]
    5998:	f9400260 	ldr	x0, [x19]
    599c:	9360fe96 	asr	x22, x20, #32
    59a0:	1e690928 	fmul	d8, d9, d9
    59a4:	eb16001f 	cmp	x0, x22
    59a8:	54001280 	b.eq	5bf8 <w120+0x4c8>  // b.none
    59ac:	aa1603e0 	mov	x0, x22
    59b0:	97fffc50 	bl	4af0 <fwp_tape_of>
    59b4:	aa0003f7 	mov	x23, x0
    59b8:	f9402800 	ldr	x0, [x0, #80]
    59bc:	b5ffeea0 	cbnz	x0, 5790 <w120+0x60>
    59c0:	a9005e76 	stp	x22, x23, [x19]
    59c4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    59c8:	f9400af9 	ldr	x25, [x23, #16]
    59cc:	eb00033f 	cmp	x25, x0
    59d0:	54000fec 	b.gt	5bcc <w120+0x49c>
    59d4:	eb34433f 	cmp	x25, w20, uxtw
    59d8:	54000f4d 	b.le	5bc0 <w120+0x490>
    59dc:	f94006f6 	ldr	x22, [x23, #8]
    59e0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    59e4:	cb160336 	sub	x22, x25, x22
    59e8:	910006c1 	add	x1, x22, #0x1
    59ec:	eb00003f 	cmp	x1, x0
    59f0:	54000ee8 	b.hi	5bcc <w120+0x49c>  // b.pmore
    59f4:	f9400ee0 	ldr	x0, [x23, #24]
    59f8:	eb00003f 	cmp	x1, x0
    59fc:	5400006d 	b.le	5a08 <w120+0x2d8>
    5a00:	aa1703e0 	mov	x0, x23
    5a04:	97fffe73 	bl	53d0 <fwp_tape_grow.constprop.0>
    5a08:	8b1606d6 	add	x22, x22, x22, lsl #1
    5a0c:	92607e98 	and	x24, x20, #0xffffffff00000000
    5a10:	f94012e0 	ldr	x0, [x23, #32]
    5a14:	d37df2d6 	lsl	x22, x22, #3
    5a18:	f9400262 	ldr	x2, [x19]
    5a1c:	8b160001 	add	x1, x0, x22
    5a20:	b8366814 	str	w20, [x0, x22]
    5a24:	aa190318 	orr	x24, x24, x25
    5a28:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a2c:	9e670000 	fmov	d0, x0
    5a30:	b9000434 	str	w20, [x1, #4]
    5a34:	91000739 	add	x25, x25, #0x1
    5a38:	6d00a429 	stp	d9, d9, [x1, #8]
    5a3c:	9360ff14 	asr	x20, x24, #32
    5a40:	1e600908 	fmul	d8, d8, d0
    5a44:	f9000af9 	str	x25, [x23, #16]
    5a48:	eb14005f 	cmp	x2, x20
    5a4c:	54000d20 	b.eq	5bf0 <w120+0x4c0>  // b.none
    5a50:	aa1403e0 	mov	x0, x20
    5a54:	97fffc27 	bl	4af0 <fwp_tape_of>
    5a58:	aa0003f6 	mov	x22, x0
    5a5c:	f9402800 	ldr	x0, [x0, #80]
    5a60:	b5ffe980 	cbnz	x0, 5790 <w120+0x60>
    5a64:	a9005a74 	stp	x20, x22, [x19]
    5a68:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5a6c:	f9400ad7 	ldr	x23, [x22, #16]
    5a70:	eb0002ff 	cmp	x23, x0
    5a74:	54000acc 	b.gt	5bcc <w120+0x49c>
    5a78:	eb3842ff 	cmp	x23, w24, uxtw
    5a7c:	54000a2d 	b.le	5bc0 <w120+0x490>
    5a80:	f94006d4 	ldr	x20, [x22, #8]
    5a84:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5a88:	cb1402f4 	sub	x20, x23, x20
    5a8c:	91000681 	add	x1, x20, #0x1
    5a90:	eb00003f 	cmp	x1, x0
    5a94:	540009c8 	b.hi	5bcc <w120+0x49c>  // b.pmore
    5a98:	f9400ec0 	ldr	x0, [x22, #24]
    5a9c:	eb00003f 	cmp	x1, x0
    5aa0:	5400006d 	b.le	5aac <w120+0x37c>
    5aa4:	aa1603e0 	mov	x0, x22
    5aa8:	97fffe4a 	bl	53d0 <fwp_tape_grow.constprop.0>
    5aac:	8b140694 	add	x20, x20, x20, lsl #1
    5ab0:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5ab4:	f94012c1 	ldr	x1, [x22, #32]
    5ab8:	d37df294 	lsl	x20, x20, #3
    5abc:	3dc2d800 	ldr	q0, [x0, #2912]
    5ac0:	8b140020 	add	x0, x1, x20
    5ac4:	b8346838 	str	w24, [x1, x20]
    5ac8:	12800002 	mov	w2, #0xffffffff            	// #-1
    5acc:	92607f18 	and	x24, x24, #0xffffffff00000000
    5ad0:	910006e1 	add	x1, x23, #0x1
    5ad4:	b9000402 	str	w2, [x0, #4]
    5ad8:	1e6a0949 	fmul	d9, d10, d10
    5adc:	3c808000 	stur	q0, [x0, #8]
    5ae0:	aa170318 	orr	x24, x24, x23
    5ae4:	aa1503e0 	mov	x0, x21
    5ae8:	f9000ac1 	str	x1, [x22, #16]
    5aec:	b10006bf 	cmn	x21, #0x1
    5af0:	540004e0 	b.eq	5b8c <w120+0x45c>  // b.none
    5af4:	f9400260 	ldr	x0, [x19]
    5af8:	9360feb4 	asr	x20, x21, #32
    5afc:	eb14001f 	cmp	x0, x20
    5b00:	54000740 	b.eq	5be8 <w120+0x4b8>  // b.none
    5b04:	aa1403e0 	mov	x0, x20
    5b08:	97fffbfa 	bl	4af0 <fwp_tape_of>
    5b0c:	aa0003f6 	mov	x22, x0
    5b10:	f9402800 	ldr	x0, [x0, #80]
    5b14:	b5ffe3e0 	cbnz	x0, 5790 <w120+0x60>
    5b18:	a9005a74 	stp	x20, x22, [x19]
    5b1c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5b20:	f9400ad7 	ldr	x23, [x22, #16]
    5b24:	eb0002ff 	cmp	x23, x0
    5b28:	5400052c 	b.gt	5bcc <w120+0x49c>
    5b2c:	eb3542ff 	cmp	x23, w21, uxtw
    5b30:	5400048d 	b.le	5bc0 <w120+0x490>
    5b34:	f94006d4 	ldr	x20, [x22, #8]
    5b38:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5b3c:	cb1402f4 	sub	x20, x23, x20
    5b40:	91000681 	add	x1, x20, #0x1
    5b44:	eb00003f 	cmp	x1, x0
    5b48:	54000428 	b.hi	5bcc <w120+0x49c>  // b.pmore
    5b4c:	f9400ec0 	ldr	x0, [x22, #24]
    5b50:	eb00003f 	cmp	x1, x0
    5b54:	5400006d 	b.le	5b60 <w120+0x430>
    5b58:	aa1603e0 	mov	x0, x22
    5b5c:	97fffe1d 	bl	53d0 <fwp_tape_grow.constprop.0>
    5b60:	8b140694 	add	x20, x20, x20, lsl #1
    5b64:	92607ea0 	and	x0, x21, #0xffffffff00000000
    5b68:	f94012c2 	ldr	x2, [x22, #32]
    5b6c:	d37df294 	lsl	x20, x20, #3
    5b70:	aa170000 	orr	x0, x0, x23
    5b74:	910006f7 	add	x23, x23, #0x1
    5b78:	8b140041 	add	x1, x2, x20
    5b7c:	b8346855 	str	w21, [x2, x20]
    5b80:	b9000435 	str	w21, [x1, #4]
    5b84:	6d00a82a 	stp	d10, d10, [x1, #8]
    5b88:	f9000ad7 	str	x23, [x22, #16]
    5b8c:	1e604101 	fmov	d1, d8
    5b90:	1e604120 	fmov	d0, d9
    5b94:	aa1303e2 	mov	x2, x19
    5b98:	aa1803e1 	mov	x1, x24
    5b9c:	97fffe7d 	bl	5590 <w123>
    5ba0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ba4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5ba8:	a94363f7 	ldp	x23, x24, [sp, #48]
    5bac:	f94023f9 	ldr	x25, [sp, #64]
    5bb0:	fd4027ea 	ldr	d10, [sp, #72]
    5bb4:	6d4527e8 	ldp	d8, d9, [sp, #80]
    5bb8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5bbc:	d65f03c0 	ret
    5bc0:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5bc4:	91078000 	add	x0, x0, #0x1e0
    5bc8:	97fff9c7 	bl	42e4 <fwp_trap>
    5bcc:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5bd0:	91052000 	add	x0, x0, #0x148
    5bd4:	97fff9c4 	bl	42e4 <fwp_trap>
    5bd8:	f9400678 	ldr	x24, [x19, #8]
    5bdc:	17ffff1e 	b	5854 <w120+0x124>
    5be0:	f9400457 	ldr	x23, [x2, #8]
    5be4:	17fffeef 	b	57a0 <w120+0x70>
    5be8:	f9400676 	ldr	x22, [x19, #8]
    5bec:	17ffffcc 	b	5b1c <w120+0x3ec>
    5bf0:	f9400676 	ldr	x22, [x19, #8]
    5bf4:	17ffff9d 	b	5a68 <w120+0x338>
    5bf8:	f9400677 	ldr	x23, [x19, #8]
    5bfc:	17ffff72 	b	59c4 <w120+0x294>
    5c00:	f9400677 	ldr	x23, [x19, #8]
    5c04:	17ffff46 	b	591c <w120+0x1ec>
    5c08:	1e6a3829 	fsub	d9, d1, d10
    5c0c:	b6f80161 	tbz	x1, #63, 5c38 <w120+0x508>
    5c10:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5c14:	1e690921 	fmul	d1, d9, d9
    5c18:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5c1c:	9e670002 	fmov	d2, x0
    5c20:	1e683809 	fsub	d9, d0, d8
    5c24:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5c28:	aa1803e0 	mov	x0, x24
    5c2c:	1e620828 	fmul	d8, d1, d2
    5c30:	1e690929 	fmul	d9, d9, d9
    5c34:	17ffffd6 	b	5b8c <w120+0x45c>
    5c38:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5c3c:	9360fc39 	asr	x25, x1, #32
    5c40:	aa0103f4 	mov	x20, x1
    5c44:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5c48:	3dc2d000 	ldr	q0, [x0, #2880]
    5c4c:	3d801be0 	str	q0, [sp, #96]
    5c50:	17fffef8 	b	5830 <w120+0x100>
    5c54:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5c58:	9105a000 	add	x0, x0, #0x168
    5c5c:	97fff9a2 	bl	42e4 <fwp_trap>
    5c60:	aa0103f5 	mov	x21, x1
    5c64:	17ffff4d 	b	5998 <w120+0x268>
    5c68:	d503201f 	nop
    5c6c:	d503201f 	nop

0000000000005c70 <w176.constprop.0>:
    5c70:	d10183ff 	sub	sp, sp, #0x60
    5c74:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    5c78:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    5c7c:	f947f421 	ldr	x1, [x1, #4072]
    5c80:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c84:	910083fd 	add	x29, sp, #0x20
    5c88:	a9045bf5 	stp	x21, x22, [sp, #64]
    5c8c:	f9400015 	ldr	x21, [x0]
    5c90:	f9400023 	ldr	x3, [x1]
    5c94:	f9000fe3 	str	x3, [sp, #24]
    5c98:	d2800003 	mov	x3, #0x0                   	// #0
    5c9c:	a900ffe2 	stp	x2, xzr, [sp, #8]
    5ca0:	b4000435 	cbz	x21, 5d24 <w176.constprop.0+0xb4>
    5ca4:	2f00e400 	movi	d0, #0x0
    5ca8:	91004016 	add	x22, x0, #0x10
    5cac:	a90353f3 	stp	x19, x20, [sp, #48]
    5cb0:	91002014 	add	x20, x0, #0x8
    5cb4:	d2800013 	mov	x19, #0x0                   	// #0
    5cb8:	f9002bf7 	str	x23, [sp, #80]
    5cbc:	910023f7 	add	x23, sp, #0x8
    5cc0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    5cc4:	aa0203e0 	mov	x0, x2
    5cc8:	fc737a81 	ldr	d1, [x20, x19, lsl #3]
    5ccc:	aa1703e2 	mov	x2, x23
    5cd0:	91000a73 	add	x19, x19, #0x2
    5cd4:	97fffe2f 	bl	5590 <w123>
    5cd8:	aa0103e2 	mov	x2, x1
    5cdc:	9e670000 	fmov	d0, x0
    5ce0:	eb1302bf 	cmp	x21, x19
    5ce4:	54fffee8 	b.hi	5cc0 <w176.constprop.0+0x50>  // b.pmore
    5ce8:	a94353f3 	ldp	x19, x20, [sp, #48]
    5cec:	f9402bf7 	ldr	x23, [sp, #80]
    5cf0:	9e660000 	fmov	x0, d0
    5cf4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    5cf8:	f947f421 	ldr	x1, [x1, #4072]
    5cfc:	f9400fe4 	ldr	x4, [sp, #24]
    5d00:	f9400023 	ldr	x3, [x1]
    5d04:	eb030084 	subs	x4, x4, x3
    5d08:	d2800003 	mov	x3, #0x0                   	// #0
    5d0c:	54000101 	b.ne	5d2c <w176.constprop.0+0xbc>  // b.any
    5d10:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d14:	aa0203e1 	mov	x1, x2
    5d18:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5d1c:	910183ff 	add	sp, sp, #0x60
    5d20:	d65f03c0 	ret
    5d24:	2f00e400 	movi	d0, #0x0
    5d28:	17fffff2 	b	5cf0 <w176.constprop.0+0x80>
    5d2c:	a90353f3 	stp	x19, x20, [sp, #48]
    5d30:	f9002bf7 	str	x23, [sp, #80]
    5d34:	97fff2cb 	bl	2860 <__stack_chk_fail@plt>
    5d38:	d503201f 	nop
    5d3c:	d503201f 	nop

0000000000005d40 <fwp_rc_share>:
    5d40:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbd0>
    5d44:	91184042 	add	x2, x2, #0x610
    5d48:	f949d843 	ldr	x3, [x2, #5040]
    5d4c:	f949ec41 	ldr	x1, [x2, #5080]
    5d50:	cb030000 	sub	x0, x0, x3
    5d54:	eb01401f 	cmp	x0, x1, lsl #16
    5d58:	540003a2 	b.cs	5dcc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5d5c:	d350fc01 	lsr	x1, x0, #16
    5d60:	f949fc44 	ldr	x4, [x2, #5112]
    5d64:	8b010821 	add	x1, x1, x1, lsl #2
    5d68:	d37df021 	lsl	x1, x1, #3
    5d6c:	8b010083 	add	x3, x4, x1
    5d70:	f9401062 	ldr	x2, [x3, #32]
    5d74:	b40002c2 	cbz	x2, 5dcc <fwp_rc_share+0x8c>
    5d78:	38616881 	ldrb	w1, [x4, x1]
    5d7c:	7100083f 	cmp	w1, #0x2
    5d80:	54000220 	b.eq	5dc4 <fwp_rc_share+0x84>  // b.none
    5d84:	7100043f 	cmp	w1, #0x1
    5d88:	54000221 	b.ne	5dcc <fwp_rc_share+0x8c>  // b.any
    5d8c:	29430464 	ldp	w4, w1, [x3, #24]
    5d90:	92403c00 	and	x0, x0, #0xffff
    5d94:	9b047c00 	mul	x0, x0, x4
    5d98:	d360fc00 	lsr	x0, x0, #32
    5d9c:	eb01001f 	cmp	x0, x1
    5da0:	54000162 	b.cs	5dcc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5da4:	8b000042 	add	x2, x2, x0
    5da8:	39400040 	ldrb	w0, [x2]
    5dac:	34000100 	cbz	w0, 5dcc <fwp_rc_share+0x8c>
    5db0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5db4:	b0000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    5db8:	91080000 	add	x0, x0, #0x200
    5dbc:	910003fd 	mov	x29, sp
    5dc0:	97fff949 	bl	42e4 <fwp_trap>
    5dc4:	72003c1f 	tst	w0, #0xffff
    5dc8:	54ffff00 	b.eq	5da8 <fwp_rc_share+0x68>  // b.none
    5dcc:	d65f03c0 	ret

0000000000005dd0 <fwp_rc_free_arr>:
    5dd0:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbd0>
    5dd4:	91184063 	add	x3, x3, #0x610
    5dd8:	f949d861 	ldr	x1, [x3, #5040]
    5ddc:	f949ec62 	ldr	x2, [x3, #5080]
    5de0:	cb010001 	sub	x1, x0, x1
    5de4:	eb02403f 	cmp	x1, x2, lsl #16
    5de8:	54000342 	b.cs	5e50 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5dec:	d350fc22 	lsr	x2, x1, #16
    5df0:	f949fc65 	ldr	x5, [x3, #5112]
    5df4:	8b020842 	add	x2, x2, x2, lsl #2
    5df8:	d37df042 	lsl	x2, x2, #3
    5dfc:	8b0200a4 	add	x4, x5, x2
    5e00:	f9401083 	ldr	x3, [x4, #32]
    5e04:	b4000263 	cbz	x3, 5e50 <fwp_rc_free_arr+0x80>
    5e08:	386268a2 	ldrb	w2, [x5, x2]
    5e0c:	7100085f 	cmp	w2, #0x2
    5e10:	540001c0 	b.eq	5e48 <fwp_rc_free_arr+0x78>  // b.none
    5e14:	7100045f 	cmp	w2, #0x1
    5e18:	540001c1 	b.ne	5e50 <fwp_rc_free_arr+0x80>  // b.any
    5e1c:	29430885 	ldp	w5, w2, [x4, #24]
    5e20:	92403c21 	and	x1, x1, #0xffff
    5e24:	9b057c21 	mul	x1, x1, x5
    5e28:	d360fc21 	lsr	x1, x1, #32
    5e2c:	eb02003f 	cmp	x1, x2
    5e30:	54000102 	b.cs	5e50 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5e34:	8b010063 	add	x3, x3, x1
    5e38:	39400061 	ldrb	w1, [x3]
    5e3c:	7100043f 	cmp	w1, #0x1
    5e40:	54000081 	b.ne	5e50 <fwp_rc_free_arr+0x80>  // b.any
    5e44:	17fff9e3 	b	45d0 <fwp_mem_free>
    5e48:	72003c3f 	tst	w1, #0xffff
    5e4c:	54ffff60 	b.eq	5e38 <fwp_rc_free_arr+0x68>  // b.none
    5e50:	d65f03c0 	ret

0000000000005e54 <fwp_rc_dup>:
    5e54:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbd0>
    5e58:	91184042 	add	x2, x2, #0x610
    5e5c:	f949d841 	ldr	x1, [x2, #5040]
    5e60:	f949ec43 	ldr	x3, [x2, #5080]
    5e64:	cb010001 	sub	x1, x0, x1
    5e68:	eb03403f 	cmp	x1, x3, lsl #16
    5e6c:	540003c2 	b.cs	5ee4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5e70:	d350fc20 	lsr	x0, x1, #16
    5e74:	f949fc44 	ldr	x4, [x2, #5112]
    5e78:	8b000800 	add	x0, x0, x0, lsl #2
    5e7c:	d37df002 	lsl	x2, x0, #3
    5e80:	8b020083 	add	x3, x4, x2
    5e84:	f9401060 	ldr	x0, [x3, #32]
    5e88:	b40002e0 	cbz	x0, 5ee4 <fwp_rc_dup+0x90>
    5e8c:	38626882 	ldrb	w2, [x4, x2]
    5e90:	7100085f 	cmp	w2, #0x2
    5e94:	540002a0 	b.eq	5ee8 <fwp_rc_dup+0x94>  // b.none
    5e98:	7100045f 	cmp	w2, #0x1
    5e9c:	54000241 	b.ne	5ee4 <fwp_rc_dup+0x90>  // b.any
    5ea0:	29430864 	ldp	w4, w2, [x3, #24]
    5ea4:	92403c21 	and	x1, x1, #0xffff
    5ea8:	9b047c21 	mul	x1, x1, x4
    5eac:	d360fc21 	lsr	x1, x1, #32
    5eb0:	eb02003f 	cmp	x1, x2
    5eb4:	54000182 	b.cs	5ee4 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5eb8:	8b010000 	add	x0, x0, x1
    5ebc:	39400001 	ldrb	w1, [x0]
    5ec0:	34000121 	cbz	w1, 5ee4 <fwp_rc_dup+0x90>
    5ec4:	f00000c2 	adrp	x2, 20000 <__data_start>
    5ec8:	91014042 	add	x2, x2, #0x50
    5ecc:	b9412043 	ldr	w3, [x2, #288]
    5ed0:	35000123 	cbnz	w3, 5ef4 <fwp_rc_dup+0xa0>
    5ed4:	7103f43f 	cmp	w1, #0xfd
    5ed8:	54000168 	b.hi	5f04 <fwp_rc_dup+0xb0>  // b.pmore
    5edc:	11000421 	add	w1, w1, #0x1
    5ee0:	39000001 	strb	w1, [x0]
    5ee4:	d65f03c0 	ret
    5ee8:	72003c3f 	tst	w1, #0xffff
    5eec:	54fffe80 	b.eq	5ebc <fwp_rc_dup+0x68>  // b.none
    5ef0:	d65f03c0 	ret
    5ef4:	f940a443 	ldr	x3, [x2, #328]
    5ef8:	91000463 	add	x3, x3, #0x1
    5efc:	f900a443 	str	x3, [x2, #328]
    5f00:	17fffff5 	b	5ed4 <fwp_rc_dup+0x80>
    5f04:	17fffa2c 	b	47b4 <fwp_rc_wide_dup>
    5f08:	d503201f 	nop
    5f0c:	d503201f 	nop

0000000000005f10 <fwp_owned_entry173>:
    5f10:	d10103ff 	sub	sp, sp, #0x40
    5f14:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    5f18:	f947f442 	ldr	x2, [x2, #4072]
    5f1c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5f20:	910083fd 	add	x29, sp, #0x20
    5f24:	a90353f3 	stp	x19, x20, [sp, #48]
    5f28:	f9400043 	ldr	x3, [x2]
    5f2c:	f9000fe3 	str	x3, [sp, #24]
    5f30:	d2800003 	mov	x3, #0x0                   	// #0
    5f34:	a9400c01 	ldp	x1, x3, [x0]
    5f38:	f9400802 	ldr	x2, [x0, #16]
    5f3c:	ab020022 	adds	x2, x1, x2
    5f40:	540006e6 	b.vs	601c <fwp_owned_entry173+0x10c>
    5f44:	910023e1 	add	x1, sp, #0x8
    5f48:	52800000 	mov	w0, #0x0                   	// #0
    5f4c:	a9008be3 	stp	x3, x2, [sp, #8]
    5f50:	97fffcc0 	bl	5250 <fwp_data.part.0.constprop.0>
    5f54:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbd0>
    5f58:	91184063 	add	x3, x3, #0x610
    5f5c:	aa0003f3 	mov	x19, x0
    5f60:	f949d861 	ldr	x1, [x3, #5040]
    5f64:	f949ec60 	ldr	x0, [x3, #5080]
    5f68:	cb010261 	sub	x1, x19, x1
    5f6c:	eb00403f 	cmp	x1, x0, lsl #16
    5f70:	54000322 	b.cs	5fd4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5f74:	d350fc22 	lsr	x2, x1, #16
    5f78:	f949fc63 	ldr	x3, [x3, #5112]
    5f7c:	8b020842 	add	x2, x2, x2, lsl #2
    5f80:	d37df042 	lsl	x2, x2, #3
    5f84:	8b020060 	add	x0, x3, x2
    5f88:	f9401014 	ldr	x20, [x0, #32]
    5f8c:	b4000254 	cbz	x20, 5fd4 <fwp_owned_entry173+0xc4>
    5f90:	38626862 	ldrb	w2, [x3, x2]
    5f94:	7100085f 	cmp	w2, #0x2
    5f98:	54000360 	b.eq	6004 <fwp_owned_entry173+0xf4>  // b.none
    5f9c:	7100045f 	cmp	w2, #0x1
    5fa0:	540001a1 	b.ne	5fd4 <fwp_owned_entry173+0xc4>  // b.any
    5fa4:	29430002 	ldp	w2, w0, [x0, #24]
    5fa8:	92403c21 	and	x1, x1, #0xffff
    5fac:	9b027c21 	mul	x1, x1, x2
    5fb0:	d360fc21 	lsr	x1, x1, #32
    5fb4:	eb00003f 	cmp	x1, x0
    5fb8:	540000e2 	b.cs	5fd4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5fbc:	8b010294 	add	x20, x20, x1
    5fc0:	39400280 	ldrb	w0, [x20]
    5fc4:	7103fc1f 	cmp	w0, #0xff
    5fc8:	54000240 	b.eq	6010 <fwp_owned_entry173+0x100>  // b.none
    5fcc:	52800020 	mov	w0, #0x1                   	// #1
    5fd0:	39000280 	strb	w0, [x20]
    5fd4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    5fd8:	f947f400 	ldr	x0, [x0, #4072]
    5fdc:	f9400fe2 	ldr	x2, [sp, #24]
    5fe0:	f9400001 	ldr	x1, [x0]
    5fe4:	eb010042 	subs	x2, x2, x1
    5fe8:	d2800001 	mov	x1, #0x0                   	// #0
    5fec:	540001a1 	b.ne	6020 <fwp_owned_entry173+0x110>  // b.any
    5ff0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5ff4:	aa1303e0 	mov	x0, x19
    5ff8:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ffc:	910103ff 	add	sp, sp, #0x40
    6000:	d65f03c0 	ret
    6004:	72003c3f 	tst	w1, #0xffff
    6008:	54fffe61 	b.ne	5fd4 <fwp_owned_entry173+0xc4>  // b.any
    600c:	17ffffed 	b	5fc0 <fwp_owned_entry173+0xb0>
    6010:	aa1403e0 	mov	x0, x20
    6014:	97fff8d4 	bl	4364 <fwp_rc_forget_slot.part.0>
    6018:	17ffffed 	b	5fcc <fwp_owned_entry173+0xbc>
    601c:	97fff289 	bl	2a40 <fwp_trap_overflow.constprop.0>
    6020:	97fff210 	bl	2860 <__stack_chk_fail@plt>

0000000000006024 <e173>:
    6024:	d10103ff 	sub	sp, sp, #0x40
    6028:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    602c:	f947f442 	ldr	x2, [x2, #4072]
    6030:	a9027bfd 	stp	x29, x30, [sp, #32]
    6034:	910083fd 	add	x29, sp, #0x20
    6038:	a90353f3 	stp	x19, x20, [sp, #48]
    603c:	f9400043 	ldr	x3, [x2]
    6040:	f9000fe3 	str	x3, [sp, #24]
    6044:	d2800003 	mov	x3, #0x0                   	// #0
    6048:	a9400c01 	ldp	x1, x3, [x0]
    604c:	f9400802 	ldr	x2, [x0, #16]
    6050:	ab020022 	adds	x2, x1, x2
    6054:	54000726 	b.vs	6138 <e173+0x114>
    6058:	910023e1 	add	x1, sp, #0x8
    605c:	52800000 	mov	w0, #0x0                   	// #0
    6060:	a9008be3 	stp	x3, x2, [sp, #8]
    6064:	97fffc7b 	bl	5250 <fwp_data.part.0.constprop.0>
    6068:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbd0>
    606c:	91184063 	add	x3, x3, #0x610
    6070:	aa0003f3 	mov	x19, x0
    6074:	f949d861 	ldr	x1, [x3, #5040]
    6078:	f949ec60 	ldr	x0, [x3, #5080]
    607c:	cb010261 	sub	x1, x19, x1
    6080:	eb00403f 	cmp	x1, x0, lsl #16
    6084:	54000322 	b.cs	60e8 <e173+0xc4>  // b.hs, b.nlast
    6088:	d350fc22 	lsr	x2, x1, #16
    608c:	f949fc63 	ldr	x3, [x3, #5112]
    6090:	8b020842 	add	x2, x2, x2, lsl #2
    6094:	d37df042 	lsl	x2, x2, #3
    6098:	8b020060 	add	x0, x3, x2
    609c:	f9401014 	ldr	x20, [x0, #32]
    60a0:	b4000254 	cbz	x20, 60e8 <e173+0xc4>
    60a4:	38626862 	ldrb	w2, [x3, x2]
    60a8:	7100085f 	cmp	w2, #0x2
    60ac:	540003a0 	b.eq	6120 <e173+0xfc>  // b.none
    60b0:	7100045f 	cmp	w2, #0x1
    60b4:	540001a1 	b.ne	60e8 <e173+0xc4>  // b.any
    60b8:	29430002 	ldp	w2, w0, [x0, #24]
    60bc:	92403c21 	and	x1, x1, #0xffff
    60c0:	9b027c21 	mul	x1, x1, x2
    60c4:	d360fc21 	lsr	x1, x1, #32
    60c8:	eb00003f 	cmp	x1, x0
    60cc:	540000e2 	b.cs	60e8 <e173+0xc4>  // b.hs, b.nlast
    60d0:	8b010294 	add	x20, x20, x1
    60d4:	39400280 	ldrb	w0, [x20]
    60d8:	7103fc1f 	cmp	w0, #0xff
    60dc:	54000280 	b.eq	612c <e173+0x108>  // b.none
    60e0:	52800020 	mov	w0, #0x1                   	// #1
    60e4:	39000280 	strb	w0, [x20]
    60e8:	aa1303e0 	mov	x0, x19
    60ec:	97ffff15 	bl	5d40 <fwp_rc_share>
    60f0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    60f4:	f947f400 	ldr	x0, [x0, #4072]
    60f8:	f9400fe2 	ldr	x2, [sp, #24]
    60fc:	f9400001 	ldr	x1, [x0]
    6100:	eb010042 	subs	x2, x2, x1
    6104:	d2800001 	mov	x1, #0x0                   	// #0
    6108:	540001a1 	b.ne	613c <e173+0x118>  // b.any
    610c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6110:	aa1303e0 	mov	x0, x19
    6114:	a94353f3 	ldp	x19, x20, [sp, #48]
    6118:	910103ff 	add	sp, sp, #0x40
    611c:	d65f03c0 	ret
    6120:	72003c3f 	tst	w1, #0xffff
    6124:	54fffe21 	b.ne	60e8 <e173+0xc4>  // b.any
    6128:	17ffffeb 	b	60d4 <e173+0xb0>
    612c:	aa1403e0 	mov	x0, x20
    6130:	97fff88d 	bl	4364 <fwp_rc_forget_slot.part.0>
    6134:	17ffffeb 	b	60e0 <e173+0xbc>
    6138:	97fff242 	bl	2a40 <fwp_trap_overflow.constprop.0>
    613c:	97fff1c9 	bl	2860 <__stack_chk_fail@plt>

0000000000006140 <fwp_drop0>:
    6140:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6144:	910003fd 	mov	x29, sp
    6148:	a90153f3 	stp	x19, x20, [sp, #16]
    614c:	f90013f5 	str	x21, [sp, #32]
    6150:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbd0>
    6154:	911842b4 	add	x20, x21, #0x610
    6158:	f949da81 	ldr	x1, [x20, #5040]
    615c:	f949ee82 	ldr	x2, [x20, #5080]
    6160:	cb010001 	sub	x1, x0, x1
    6164:	eb02403f 	cmp	x1, x2, lsl #16
    6168:	54000382 	b.cs	61d8 <fwp_drop0+0x98>  // b.hs, b.nlast
    616c:	d350fc22 	lsr	x2, x1, #16
    6170:	f949fe84 	ldr	x4, [x20, #5112]
    6174:	8b020842 	add	x2, x2, x2, lsl #2
    6178:	d37df042 	lsl	x2, x2, #3
    617c:	8b020083 	add	x3, x4, x2
    6180:	f9401073 	ldr	x19, [x3, #32]
    6184:	b40002b3 	cbz	x19, 61d8 <fwp_drop0+0x98>
    6188:	38626882 	ldrb	w2, [x4, x2]
    618c:	7100085f 	cmp	w2, #0x2
    6190:	540002c0 	b.eq	61e8 <fwp_drop0+0xa8>  // b.none
    6194:	7100045f 	cmp	w2, #0x1
    6198:	54000201 	b.ne	61d8 <fwp_drop0+0x98>  // b.any
    619c:	29430864 	ldp	w4, w2, [x3, #24]
    61a0:	92403c21 	and	x1, x1, #0xffff
    61a4:	9b047c21 	mul	x1, x1, x4
    61a8:	d360fc21 	lsr	x1, x1, #32
    61ac:	eb02003f 	cmp	x1, x2
    61b0:	54000142 	b.cs	61d8 <fwp_drop0+0x98>  // b.hs, b.nlast
    61b4:	8b010273 	add	x19, x19, x1
    61b8:	39400261 	ldrb	w1, [x19]
    61bc:	340000e1 	cbz	w1, 61d8 <fwp_drop0+0x98>
    61c0:	7100043f 	cmp	w1, #0x1
    61c4:	540001e0 	b.eq	6200 <fwp_drop0+0xc0>  // b.none
    61c8:	7103fc3f 	cmp	w1, #0xff
    61cc:	540002e0 	b.eq	6228 <fwp_drop0+0xe8>  // b.none
    61d0:	51000421 	sub	w1, w1, #0x1
    61d4:	39000261 	strb	w1, [x19]
    61d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    61dc:	f94013f5 	ldr	x21, [sp, #32]
    61e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    61e4:	d65f03c0 	ret
    61e8:	72003c3f 	tst	w1, #0xffff
    61ec:	54fffe60 	b.eq	61b8 <fwp_drop0+0x78>  // b.none
    61f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    61f4:	f94013f5 	ldr	x21, [sp, #32]
    61f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    61fc:	d65f03c0 	ret
    6200:	f9400813 	ldr	x19, [x0, #16]
    6204:	97fffef3 	bl	5dd0 <fwp_rc_free_arr>
    6208:	911842a0 	add	x0, x21, #0x610
    620c:	f949d801 	ldr	x1, [x0, #5040]
    6210:	f949ec00 	ldr	x0, [x0, #5080]
    6214:	cb010261 	sub	x1, x19, x1
    6218:	eb00403f 	cmp	x1, x0, lsl #16
    621c:	54fffde2 	b.cs	61d8 <fwp_drop0+0x98>  // b.hs, b.nlast
    6220:	aa1303e0 	mov	x0, x19
    6224:	17ffffd2 	b	616c <fwp_drop0+0x2c>
    6228:	ca534660 	eor	x0, x19, x19, lsr #17
    622c:	911842b5 	add	x21, x21, #0x610
    6230:	ca402400 	eor	x0, x0, x0, lsr #9
    6234:	92401c00 	and	x0, x0, #0xff
    6238:	910a2402 	add	x2, x0, #0x289
    623c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6240:	8b020ea2 	add	x2, x21, x2, lsl #3
    6244:	f94a2400 	ldr	x0, [x0, #5192]
    6248:	b50000a0 	cbnz	x0, 625c <fwp_drop0+0x11c>
    624c:	14000013 	b	6298 <fwp_drop0+0x158>
    6250:	91004002 	add	x2, x0, #0x10
    6254:	f9400800 	ldr	x0, [x0, #16]
    6258:	b4000200 	cbz	x0, 6298 <fwp_drop0+0x158>
    625c:	f9400001 	ldr	x1, [x0]
    6260:	eb13003f 	cmp	x1, x19
    6264:	54ffff61 	b.ne	6250 <fwp_drop0+0x110>  // b.any
    6268:	f9400041 	ldr	x1, [x2]
    626c:	f9400420 	ldr	x0, [x1, #8]
    6270:	d1000400 	sub	x0, x0, #0x1
    6274:	f9000420 	str	x0, [x1, #8]
    6278:	f103f81f 	cmp	x0, #0xfe
    627c:	54fffae1 	b.ne	61d8 <fwp_drop0+0x98>  // b.any
    6280:	39400260 	ldrb	w0, [x19]
    6284:	7103fc1f 	cmp	w0, #0xff
    6288:	540000e0 	b.eq	62a4 <fwp_drop0+0x164>  // b.none
    628c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6290:	39000260 	strb	w0, [x19]
    6294:	17ffffd1 	b	61d8 <fwp_drop0+0x98>
    6298:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    629c:	913e6000 	add	x0, x0, #0xf98
    62a0:	97fff811 	bl	42e4 <fwp_trap>
    62a4:	aa1303e0 	mov	x0, x19
    62a8:	97fff82f 	bl	4364 <fwp_rc_forget_slot.part.0>
    62ac:	17fffff8 	b	628c <fwp_drop0+0x14c>

00000000000062b0 <fwp_drop1>:
    62b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    62b4:	910003fd 	mov	x29, sp
    62b8:	a90153f3 	stp	x19, x20, [sp, #16]
    62bc:	f90013f5 	str	x21, [sp, #32]
    62c0:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbd0>
    62c4:	911842b4 	add	x20, x21, #0x610
    62c8:	f949da81 	ldr	x1, [x20, #5040]
    62cc:	f949ee82 	ldr	x2, [x20, #5080]
    62d0:	cb010001 	sub	x1, x0, x1
    62d4:	eb02403f 	cmp	x1, x2, lsl #16
    62d8:	54000382 	b.cs	6348 <fwp_drop1+0x98>  // b.hs, b.nlast
    62dc:	d350fc22 	lsr	x2, x1, #16
    62e0:	f949fe84 	ldr	x4, [x20, #5112]
    62e4:	8b020842 	add	x2, x2, x2, lsl #2
    62e8:	d37df042 	lsl	x2, x2, #3
    62ec:	8b020083 	add	x3, x4, x2
    62f0:	f9401073 	ldr	x19, [x3, #32]
    62f4:	b40002b3 	cbz	x19, 6348 <fwp_drop1+0x98>
    62f8:	38626882 	ldrb	w2, [x4, x2]
    62fc:	7100085f 	cmp	w2, #0x2
    6300:	540002c0 	b.eq	6358 <fwp_drop1+0xa8>  // b.none
    6304:	7100045f 	cmp	w2, #0x1
    6308:	54000201 	b.ne	6348 <fwp_drop1+0x98>  // b.any
    630c:	29430864 	ldp	w4, w2, [x3, #24]
    6310:	92403c21 	and	x1, x1, #0xffff
    6314:	9b047c21 	mul	x1, x1, x4
    6318:	d360fc21 	lsr	x1, x1, #32
    631c:	eb02003f 	cmp	x1, x2
    6320:	54000142 	b.cs	6348 <fwp_drop1+0x98>  // b.hs, b.nlast
    6324:	8b010273 	add	x19, x19, x1
    6328:	39400261 	ldrb	w1, [x19]
    632c:	340000e1 	cbz	w1, 6348 <fwp_drop1+0x98>
    6330:	7100043f 	cmp	w1, #0x1
    6334:	540001e0 	b.eq	6370 <fwp_drop1+0xc0>  // b.none
    6338:	7103fc3f 	cmp	w1, #0xff
    633c:	540002e0 	b.eq	6398 <fwp_drop1+0xe8>  // b.none
    6340:	51000421 	sub	w1, w1, #0x1
    6344:	39000261 	strb	w1, [x19]
    6348:	a94153f3 	ldp	x19, x20, [sp, #16]
    634c:	f94013f5 	ldr	x21, [sp, #32]
    6350:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6354:	d65f03c0 	ret
    6358:	72003c3f 	tst	w1, #0xffff
    635c:	54fffe60 	b.eq	6328 <fwp_drop1+0x78>  // b.none
    6360:	a94153f3 	ldp	x19, x20, [sp, #16]
    6364:	f94013f5 	ldr	x21, [sp, #32]
    6368:	a8c37bfd 	ldp	x29, x30, [sp], #48
    636c:	d65f03c0 	ret
    6370:	f9400813 	ldr	x19, [x0, #16]
    6374:	97fffe97 	bl	5dd0 <fwp_rc_free_arr>
    6378:	911842a0 	add	x0, x21, #0x610
    637c:	f949d801 	ldr	x1, [x0, #5040]
    6380:	f949ec00 	ldr	x0, [x0, #5080]
    6384:	cb010261 	sub	x1, x19, x1
    6388:	eb00403f 	cmp	x1, x0, lsl #16
    638c:	54fffde2 	b.cs	6348 <fwp_drop1+0x98>  // b.hs, b.nlast
    6390:	aa1303e0 	mov	x0, x19
    6394:	17ffffd2 	b	62dc <fwp_drop1+0x2c>
    6398:	ca534660 	eor	x0, x19, x19, lsr #17
    639c:	911842b5 	add	x21, x21, #0x610
    63a0:	ca402400 	eor	x0, x0, x0, lsr #9
    63a4:	92401c00 	and	x0, x0, #0xff
    63a8:	910a2402 	add	x2, x0, #0x289
    63ac:	8b000ea0 	add	x0, x21, x0, lsl #3
    63b0:	8b020ea2 	add	x2, x21, x2, lsl #3
    63b4:	f94a2400 	ldr	x0, [x0, #5192]
    63b8:	b50000a0 	cbnz	x0, 63cc <fwp_drop1+0x11c>
    63bc:	14000013 	b	6408 <fwp_drop1+0x158>
    63c0:	91004002 	add	x2, x0, #0x10
    63c4:	f9400800 	ldr	x0, [x0, #16]
    63c8:	b4000200 	cbz	x0, 6408 <fwp_drop1+0x158>
    63cc:	f9400001 	ldr	x1, [x0]
    63d0:	eb13003f 	cmp	x1, x19
    63d4:	54ffff61 	b.ne	63c0 <fwp_drop1+0x110>  // b.any
    63d8:	f9400041 	ldr	x1, [x2]
    63dc:	f9400420 	ldr	x0, [x1, #8]
    63e0:	d1000400 	sub	x0, x0, #0x1
    63e4:	f9000420 	str	x0, [x1, #8]
    63e8:	f103f81f 	cmp	x0, #0xfe
    63ec:	54fffae1 	b.ne	6348 <fwp_drop1+0x98>  // b.any
    63f0:	39400260 	ldrb	w0, [x19]
    63f4:	7103fc1f 	cmp	w0, #0xff
    63f8:	540000e0 	b.eq	6414 <fwp_drop1+0x164>  // b.none
    63fc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6400:	39000260 	strb	w0, [x19]
    6404:	17ffffd1 	b	6348 <fwp_drop1+0x98>
    6408:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    640c:	913e6000 	add	x0, x0, #0xf98
    6410:	97fff7b5 	bl	42e4 <fwp_trap>
    6414:	aa1303e0 	mov	x0, x19
    6418:	97fff7d3 	bl	4364 <fwp_rc_forget_slot.part.0>
    641c:	17fffff8 	b	63fc <fwp_drop1+0x14c>

0000000000006420 <fwp_closure_drop>:
    6420:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xbd0>
    6424:	911840a4 	add	x4, x5, #0x610
    6428:	aa0003e1 	mov	x1, x0
    642c:	f949d882 	ldr	x2, [x4, #5040]
    6430:	f949ec80 	ldr	x0, [x4, #5080]
    6434:	cb020022 	sub	x2, x1, x2
    6438:	eb00405f 	cmp	x2, x0, lsl #16
    643c:	54000662 	b.cs	6508 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6440:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6444:	d350fc43 	lsr	x3, x2, #16
    6448:	910003fd 	mov	x29, sp
    644c:	8b030863 	add	x3, x3, x3, lsl #2
    6450:	f949fc84 	ldr	x4, [x4, #5112]
    6454:	d37df063 	lsl	x3, x3, #3
    6458:	f9000bf3 	str	x19, [sp, #16]
    645c:	8b030080 	add	x0, x4, x3
    6460:	f9401013 	ldr	x19, [x0, #32]
    6464:	b40002b3 	cbz	x19, 64b8 <fwp_closure_drop+0x98>
    6468:	38636883 	ldrb	w3, [x4, x3]
    646c:	7100087f 	cmp	w3, #0x2
    6470:	54000420 	b.eq	64f4 <fwp_closure_drop+0xd4>  // b.none
    6474:	7100047f 	cmp	w3, #0x1
    6478:	54000201 	b.ne	64b8 <fwp_closure_drop+0x98>  // b.any
    647c:	29430003 	ldp	w3, w0, [x0, #24]
    6480:	92403c42 	and	x2, x2, #0xffff
    6484:	9b037c42 	mul	x2, x2, x3
    6488:	d360fc42 	lsr	x2, x2, #32
    648c:	eb00005f 	cmp	x2, x0
    6490:	54000142 	b.cs	64b8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6494:	8b020273 	add	x19, x19, x2
    6498:	39400260 	ldrb	w0, [x19]
    649c:	340000e0 	cbz	w0, 64b8 <fwp_closure_drop+0x98>
    64a0:	7100041f 	cmp	w0, #0x1
    64a4:	54000100 	b.eq	64c4 <fwp_closure_drop+0xa4>  // b.none
    64a8:	7103fc1f 	cmp	w0, #0xff
    64ac:	54000300 	b.eq	650c <fwp_closure_drop+0xec>  // b.none
    64b0:	51000400 	sub	w0, w0, #0x1
    64b4:	39000260 	strb	w0, [x19]
    64b8:	f9400bf3 	ldr	x19, [sp, #16]
    64bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64c0:	d65f03c0 	ret
    64c4:	d53bd040 	mrs	x0, tpidr_el0
    64c8:	91400000 	add	x0, x0, #0x0, lsl #12
    64cc:	91004000 	add	x0, x0, #0x10
    64d0:	f9400000 	ldr	x0, [x0]
    64d4:	b4000080 	cbz	x0, 64e4 <fwp_closure_drop+0xc4>
    64d8:	f9400bf3 	ldr	x19, [sp, #16]
    64dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64e0:	17fff8fc 	b	48d0 <fwp_closure_drop_push>
    64e4:	f9400bf3 	ldr	x19, [sp, #16]
    64e8:	aa0103e0 	mov	x0, x1
    64ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    64f0:	17fff93d 	b	49e4 <fwp_closure_drop.part.0>
    64f4:	72003c5f 	tst	w2, #0xffff
    64f8:	54fffd00 	b.eq	6498 <fwp_closure_drop+0x78>  // b.none
    64fc:	f9400bf3 	ldr	x19, [sp, #16]
    6500:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6504:	d65f03c0 	ret
    6508:	d65f03c0 	ret
    650c:	ca534660 	eor	x0, x19, x19, lsr #17
    6510:	911840a5 	add	x5, x5, #0x610
    6514:	ca402400 	eor	x0, x0, x0, lsr #9
    6518:	92401c00 	and	x0, x0, #0xff
    651c:	910a2402 	add	x2, x0, #0x289
    6520:	8b000ca0 	add	x0, x5, x0, lsl #3
    6524:	8b020ca2 	add	x2, x5, x2, lsl #3
    6528:	f94a2400 	ldr	x0, [x0, #5192]
    652c:	b50000a0 	cbnz	x0, 6540 <fwp_closure_drop+0x120>
    6530:	14000013 	b	657c <fwp_closure_drop+0x15c>
    6534:	91004002 	add	x2, x0, #0x10
    6538:	f9400800 	ldr	x0, [x0, #16]
    653c:	b4000200 	cbz	x0, 657c <fwp_closure_drop+0x15c>
    6540:	f9400001 	ldr	x1, [x0]
    6544:	eb13003f 	cmp	x1, x19
    6548:	54ffff61 	b.ne	6534 <fwp_closure_drop+0x114>  // b.any
    654c:	f9400041 	ldr	x1, [x2]
    6550:	f9400420 	ldr	x0, [x1, #8]
    6554:	d1000400 	sub	x0, x0, #0x1
    6558:	f9000420 	str	x0, [x1, #8]
    655c:	f103f81f 	cmp	x0, #0xfe
    6560:	54fffac1 	b.ne	64b8 <fwp_closure_drop+0x98>  // b.any
    6564:	39400260 	ldrb	w0, [x19]
    6568:	7103fc1f 	cmp	w0, #0xff
    656c:	540000e0 	b.eq	6588 <fwp_closure_drop+0x168>  // b.none
    6570:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6574:	39000260 	strb	w0, [x19]
    6578:	17ffffd0 	b	64b8 <fwp_closure_drop+0x98>
    657c:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    6580:	913e6000 	add	x0, x0, #0xf98
    6584:	97fff758 	bl	42e4 <fwp_trap>
    6588:	aa1303e0 	mov	x0, x19
    658c:	97fff776 	bl	4364 <fwp_rc_forget_slot.part.0>
    6590:	17fffff8 	b	6570 <fwp_closure_drop+0x150>

0000000000006594 <fwp_owned_tape_release>:
    6594:	b4000920 	cbz	x0, 66b8 <fwp_owned_tape_release+0x124>
    6598:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    659c:	910003fd 	mov	x29, sp
    65a0:	a90153f3 	stp	x19, x20, [sp, #16]
    65a4:	aa0003f3 	mov	x19, x0
    65a8:	f9400000 	ldr	x0, [x0]
    65ac:	b4000060 	cbz	x0, 65b8 <fwp_owned_tape_release+0x24>
    65b0:	f9400661 	ldr	x1, [x19, #8]
    65b4:	f9000401 	str	x1, [x0, #8]
    65b8:	f9400661 	ldr	x1, [x19, #8]
    65bc:	b4000041 	cbz	x1, 65c4 <fwp_owned_tape_release+0x30>
    65c0:	f9000020 	str	x0, [x1]
    65c4:	f9400a60 	ldr	x0, [x19, #16]
    65c8:	f9403401 	ldr	x1, [x0, #104]
    65cc:	b40005a1 	cbz	x1, 6680 <fwp_owned_tape_release+0xec>
    65d0:	a9450a60 	ldp	x0, x2, [x19, #80]
    65d4:	eb00005f 	cmp	x2, x0
    65d8:	540002cd 	b.le	6630 <fwp_owned_tape_release+0x9c>
    65dc:	d2800014 	mov	x20, #0x0                   	// #0
    65e0:	f90013f5 	str	x21, [sp, #32]
    65e4:	d2800015 	mov	x21, #0x0                   	// #0
    65e8:	f9402260 	ldr	x0, [x19, #64]
    65ec:	910006b5 	add	x21, x21, #0x1
    65f0:	f8746800 	ldr	x0, [x0, x20]
    65f4:	d63f0020 	blr	x1
    65f8:	f9402260 	ldr	x0, [x19, #64]
    65fc:	f9400a61 	ldr	x1, [x19, #16]
    6600:	8b140000 	add	x0, x0, x20
    6604:	91004294 	add	x20, x20, #0x10
    6608:	f9400400 	ldr	x0, [x0, #8]
    660c:	f9403421 	ldr	x1, [x1, #104]
    6610:	d63f0020 	blr	x1
    6614:	a9450261 	ldp	x1, x0, [x19, #80]
    6618:	cb010000 	sub	x0, x0, x1
    661c:	eb15001f 	cmp	x0, x21
    6620:	f9400a60 	ldr	x0, [x19, #16]
    6624:	f9403401 	ldr	x1, [x0, #104]
    6628:	54fffe0c 	b.gt	65e8 <fwp_owned_tape_release+0x54>
    662c:	f94013f5 	ldr	x21, [sp, #32]
    6630:	f9403663 	ldr	x3, [x19, #104]
    6634:	f9401262 	ldr	x2, [x19, #32]
    6638:	f100007f 	cmp	x3, #0x0
    663c:	540001ed 	b.le	6678 <fwp_owned_tape_release+0xe4>
    6640:	d2800014 	mov	x20, #0x0                   	// #0
    6644:	d503201f 	nop
    6648:	f9402660 	ldr	x0, [x19, #72]
    664c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6650:	eb02001f 	cmp	x0, x2
    6654:	540000c0 	b.eq	666c <fwp_owned_tape_release+0xd8>  // b.none
    6658:	d63f0020 	blr	x1
    665c:	f9400a60 	ldr	x0, [x19, #16]
    6660:	f9401262 	ldr	x2, [x19, #32]
    6664:	f9403663 	ldr	x3, [x19, #104]
    6668:	f9403401 	ldr	x1, [x0, #104]
    666c:	91000694 	add	x20, x20, #0x1
    6670:	eb14007f 	cmp	x3, x20
    6674:	54fffeac 	b.gt	6648 <fwp_owned_tape_release+0xb4>
    6678:	aa0203e0 	mov	x0, x2
    667c:	d63f0020 	blr	x1
    6680:	f9401660 	ldr	x0, [x19, #40]
    6684:	97ffff67 	bl	6420 <fwp_closure_drop>
    6688:	f9401a60 	ldr	x0, [x19, #48]
    668c:	97ffff65 	bl	6420 <fwp_closure_drop>
    6690:	f9401e60 	ldr	x0, [x19, #56]
    6694:	97ffff63 	bl	6420 <fwp_closure_drop>
    6698:	f9402260 	ldr	x0, [x19, #64]
    669c:	97fff7cd 	bl	45d0 <fwp_mem_free>
    66a0:	f9402660 	ldr	x0, [x19, #72]
    66a4:	97fff7cb 	bl	45d0 <fwp_mem_free>
    66a8:	aa1303e0 	mov	x0, x19
    66ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    66b0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66b4:	17fff7c7 	b	45d0 <fwp_mem_free>
    66b8:	d65f03c0 	ret
    66bc:	d503201f 	nop

00000000000066c0 <fwp_tape_finish>:
    66c0:	d101c3ff 	sub	sp, sp, #0x70
    66c4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    66c8:	f947f421 	ldr	x1, [x1, #4072]
    66cc:	a9037bfd 	stp	x29, x30, [sp, #48]
    66d0:	9100c3fd 	add	x29, sp, #0x30
    66d4:	a9055bf5 	stp	x21, x22, [sp, #80]
    66d8:	a90663f7 	stp	x23, x24, [sp, #96]
    66dc:	d00000d7 	adrp	x23, 20000 <__data_start>
    66e0:	910142f6 	add	x22, x23, #0x50
    66e4:	f9400022 	ldr	x2, [x1]
    66e8:	f90017e2 	str	x2, [sp, #40]
    66ec:	d2800002 	mov	x2, #0x0                   	// #0
    66f0:	910342c0 	add	x0, x22, #0xd0
    66f4:	97fff650 	bl	4034 <fwp_tape_buffers_dispose>
    66f8:	f9007edf 	str	xzr, [x22, #248]
    66fc:	f9408ac0 	ldr	x0, [x22, #272]
    6700:	f100001f 	cmp	x0, #0x0
    6704:	5400036d 	b.le	6770 <fwp_tape_finish+0xb0>
    6708:	910003f8 	mov	x24, sp
    670c:	d2800015 	mov	x21, #0x0                   	// #0
    6710:	a90453f3 	stp	x19, x20, [sp, #64]
    6714:	d2800014 	mov	x20, #0x0                   	// #0
    6718:	91000694 	add	x20, x20, #0x1
    671c:	f94046d3 	ldr	x19, [x22, #136]
    6720:	8b150273 	add	x19, x19, x21
    6724:	910162b5 	add	x21, x21, #0x58
    6728:	aa1303e0 	mov	x0, x19
    672c:	97fff22a 	bl	2fd4 <fwp_tape_unlink_scope>
    6730:	aa1803e0 	mov	x0, x24
    6734:	f9400e61 	ldr	x1, [x19, #24]
    6738:	f9401a62 	ldr	x2, [x19, #48]
    673c:	a90107e2 	stp	x2, x1, [sp, #16]
    6740:	3dc00a60 	ldr	q0, [x19, #32]
    6744:	f9401e61 	ldr	x1, [x19, #56]
    6748:	f90013e1 	str	x1, [sp, #32]
    674c:	3d8003e0 	str	q0, [sp]
    6750:	97fff639 	bl	4034 <fwp_tape_buffers_dispose>
    6754:	f9402a60 	ldr	x0, [x19, #80]
    6758:	97ffff8f 	bl	6594 <fwp_owned_tape_release>
    675c:	f9002a7f 	str	xzr, [x19, #80]
    6760:	f9408ac0 	ldr	x0, [x22, #272]
    6764:	eb14001f 	cmp	x0, x20
    6768:	54fffd8c 	b.gt	6718 <fwp_tape_finish+0x58>
    676c:	a94453f3 	ldp	x19, x20, [sp, #64]
    6770:	910142e0 	add	x0, x23, #0x50
    6774:	f9404400 	ldr	x0, [x0, #136]
    6778:	b4000040 	cbz	x0, 6780 <fwp_tape_finish+0xc0>
    677c:	97fff60d 	bl	3fb0 <ad_raw_free.part.0>
    6780:	910142f7 	add	x23, x23, #0x50
    6784:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    6788:	f947f400 	ldr	x0, [x0, #4072]
    678c:	f90046ff 	str	xzr, [x23, #136]
    6790:	f90082ff 	str	xzr, [x23, #256]
    6794:	f9008aff 	str	xzr, [x23, #272]
    6798:	f900aaff 	str	xzr, [x23, #336]
    679c:	f94017e2 	ldr	x2, [sp, #40]
    67a0:	f9400001 	ldr	x1, [x0]
    67a4:	eb010042 	subs	x2, x2, x1
    67a8:	d2800001 	mov	x1, #0x0                   	// #0
    67ac:	540000c1 	b.ne	67c4 <fwp_tape_finish+0x104>  // b.any
    67b0:	a9437bfd 	ldp	x29, x30, [sp, #48]
    67b4:	a9455bf5 	ldp	x21, x22, [sp, #80]
    67b8:	a94663f7 	ldp	x23, x24, [sp, #96]
    67bc:	9101c3ff 	add	sp, sp, #0x70
    67c0:	d65f03c0 	ret
    67c4:	a90453f3 	stp	x19, x20, [sp, #64]
    67c8:	97fff026 	bl	2860 <__stack_chk_fail@plt>
    67cc:	d503201f 	nop

00000000000067d0 <fwp_tape_scope_release>:
    67d0:	d10203ff 	sub	sp, sp, #0x80
    67d4:	a9037bfd 	stp	x29, x30, [sp, #48]
    67d8:	9100c3fd 	add	x29, sp, #0x30
    67dc:	a90453f3 	stp	x19, x20, [sp, #64]
    67e0:	aa0003f4 	mov	x20, x0
    67e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    67e8:	f947f400 	ldr	x0, [x0, #4072]
    67ec:	b9400285 	ldr	w5, [x20]
    67f0:	f9400001 	ldr	x1, [x0]
    67f4:	f90017e1 	str	x1, [sp, #40]
    67f8:	d2800001 	mov	x1, #0x0                   	// #0
    67fc:	37f806e5 	tbnz	w5, #31, 68d8 <fwp_tape_scope_release+0x108>
    6800:	a90663f7 	stp	x23, x24, [sp, #96]
    6804:	d2917478 	mov	x24, #0x8ba3                	// #35747
    6808:	f2b745d8 	movk	x24, #0xba2e, lsl #16
    680c:	f2d45d18 	movk	x24, #0xa2e8, lsl #32
    6810:	d00000d3 	adrp	x19, 20000 <__data_start>
    6814:	910003f7 	mov	x23, sp
    6818:	91014273 	add	x19, x19, #0x50
    681c:	f2e5d178 	movk	x24, #0x2e8b, lsl #48
    6820:	a9055bf5 	stp	x21, x22, [sp, #80]
    6824:	52800b16 	mov	w22, #0x58                  	// #88
    6828:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    682c:	f9003bf9 	str	x25, [sp, #112]
    6830:	14000006 	b	6848 <fwp_tape_scope_release+0x78>
    6834:	97fff600 	bl	4034 <fwp_tape_buffers_dispose>
    6838:	aa1903e0 	mov	x0, x25
    683c:	97ffff56 	bl	6594 <fwp_owned_tape_release>
    6840:	b9400285 	ldr	w5, [x20]
    6844:	37f80445 	tbnz	w5, #31, 68cc <fwp_tape_scope_release+0xfc>
    6848:	f9404666 	ldr	x6, [x19, #136]
    684c:	9b367ca5 	smull	x5, w5, w22
    6850:	8b0500c0 	add	x0, x6, x5
    6854:	97fff1e0 	bl	2fd4 <fwp_tape_unlink_scope>
    6858:	3dc00800 	ldr	q0, [x0, #32]
    685c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6860:	f9400c03 	ldr	x3, [x0, #24]
    6864:	3d8003e0 	str	q0, [sp]
    6868:	b86568c1 	ldr	w1, [x6, x5]
    686c:	f9401802 	ldr	x2, [x0, #48]
    6870:	a9010fe2 	stp	x2, x3, [sp, #16]
    6874:	f9401c02 	ldr	x2, [x0, #56]
    6878:	b900041f 	str	wzr, [x0, #4]
    687c:	f9402819 	ldr	x25, [x0, #80]
    6880:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6884:	f9000c1f 	str	xzr, [x0, #24]
    6888:	f90013e2 	str	x2, [sp, #32]
    688c:	f900181f 	str	xzr, [x0, #48]
    6890:	f9001c1f 	str	xzr, [x0, #56]
    6894:	f900281f 	str	xzr, [x0, #80]
    6898:	6b15003f 	cmp	w1, w21
    689c:	540000e8 	b.hi	68b8 <fwp_tape_scope_release+0xe8>  // b.pmore
    68a0:	9343fca5 	asr	x5, x5, #3
    68a4:	f940aa60 	ldr	x0, [x19, #336]
    68a8:	9b187ca5 	mul	x5, x5, x24
    68ac:	eb0000bf 	cmp	x5, x0
    68b0:	5400004a 	b.ge	68b8 <fwp_tape_scope_release+0xe8>  // b.tcont
    68b4:	f900aa65 	str	x5, [x19, #336]
    68b8:	aa1703e0 	mov	x0, x23
    68bc:	b5fffbd9 	cbnz	x25, 6834 <fwp_tape_scope_release+0x64>
    68c0:	97fff624 	bl	4150 <fwp_tape_buffers_release>
    68c4:	b9400285 	ldr	w5, [x20]
    68c8:	36fffc05 	tbz	w5, #31, 6848 <fwp_tape_scope_release+0x78>
    68cc:	a9455bf5 	ldp	x21, x22, [sp, #80]
    68d0:	a94663f7 	ldp	x23, x24, [sp, #96]
    68d4:	f9403bf9 	ldr	x25, [sp, #112]
    68d8:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    68dc:	f947f400 	ldr	x0, [x0, #4072]
    68e0:	f94017e2 	ldr	x2, [sp, #40]
    68e4:	f9400001 	ldr	x1, [x0]
    68e8:	eb010042 	subs	x2, x2, x1
    68ec:	d2800001 	mov	x1, #0x0                   	// #0
    68f0:	540000a1 	b.ne	6904 <fwp_tape_scope_release+0x134>  // b.any
    68f4:	a9437bfd 	ldp	x29, x30, [sp, #48]
    68f8:	a94453f3 	ldp	x19, x20, [sp, #64]
    68fc:	910203ff 	add	sp, sp, #0x80
    6900:	d65f03c0 	ret
    6904:	a9055bf5 	stp	x21, x22, [sp, #80]
    6908:	a90663f7 	stp	x23, x24, [sp, #96]
    690c:	f9003bf9 	str	x25, [sp, #112]
    6910:	97ffefd4 	bl	2860 <__stack_chk_fail@plt>

0000000000006914 <fwp_drop4>:
    6914:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6918:	910003fd 	mov	x29, sp
    691c:	a9025bf5 	stp	x21, x22, [sp, #32]
    6920:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbd0>
    6924:	911842d5 	add	x21, x22, #0x610
    6928:	a90153f3 	stp	x19, x20, [sp, #16]
    692c:	aa0003f3 	mov	x19, x0
    6930:	f949daa1 	ldr	x1, [x21, #5040]
    6934:	f949eea0 	ldr	x0, [x21, #5080]
    6938:	cb010261 	sub	x1, x19, x1
    693c:	eb00403f 	cmp	x1, x0, lsl #16
    6940:	54000382 	b.cs	69b0 <fwp_drop4+0x9c>  // b.hs, b.nlast
    6944:	d350fc22 	lsr	x2, x1, #16
    6948:	f949fea3 	ldr	x3, [x21, #5112]
    694c:	8b020842 	add	x2, x2, x2, lsl #2
    6950:	d37df042 	lsl	x2, x2, #3
    6954:	8b020060 	add	x0, x3, x2
    6958:	f9401014 	ldr	x20, [x0, #32]
    695c:	b40002b4 	cbz	x20, 69b0 <fwp_drop4+0x9c>
    6960:	38626862 	ldrb	w2, [x3, x2]
    6964:	7100085f 	cmp	w2, #0x2
    6968:	540002c0 	b.eq	69c0 <fwp_drop4+0xac>  // b.none
    696c:	7100045f 	cmp	w2, #0x1
    6970:	54000201 	b.ne	69b0 <fwp_drop4+0x9c>  // b.any
    6974:	29430002 	ldp	w2, w0, [x0, #24]
    6978:	92403c21 	and	x1, x1, #0xffff
    697c:	9b027c21 	mul	x1, x1, x2
    6980:	d360fc21 	lsr	x1, x1, #32
    6984:	eb00003f 	cmp	x1, x0
    6988:	54000142 	b.cs	69b0 <fwp_drop4+0x9c>  // b.hs, b.nlast
    698c:	8b010294 	add	x20, x20, x1
    6990:	39400280 	ldrb	w0, [x20]
    6994:	340000e0 	cbz	w0, 69b0 <fwp_drop4+0x9c>
    6998:	7100041f 	cmp	w0, #0x1
    699c:	540001e0 	b.eq	69d8 <fwp_drop4+0xc4>  // b.none
    69a0:	7103fc1f 	cmp	w0, #0xff
    69a4:	540007e0 	b.eq	6aa0 <fwp_drop4+0x18c>  // b.none
    69a8:	51000400 	sub	w0, w0, #0x1
    69ac:	39000280 	strb	w0, [x20]
    69b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    69b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    69b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69bc:	d65f03c0 	ret
    69c0:	72003c3f 	tst	w1, #0xffff
    69c4:	54fffe60 	b.eq	6990 <fwp_drop4+0x7c>  // b.none
    69c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    69cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    69d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69d4:	d65f03c0 	ret
    69d8:	911842c2 	add	x2, x22, #0x610
    69dc:	f9400660 	ldr	x0, [x19, #8]
    69e0:	f949d841 	ldr	x1, [x2, #5040]
    69e4:	f949ec42 	ldr	x2, [x2, #5080]
    69e8:	cb010001 	sub	x1, x0, x1
    69ec:	eb02403f 	cmp	x1, x2, lsl #16
    69f0:	54000382 	b.cs	6a60 <fwp_drop4+0x14c>  // b.hs, b.nlast
    69f4:	d350fc22 	lsr	x2, x1, #16
    69f8:	8b020842 	add	x2, x2, x2, lsl #2
    69fc:	d37df042 	lsl	x2, x2, #3
    6a00:	8b020064 	add	x4, x3, x2
    6a04:	f9401094 	ldr	x20, [x4, #32]
    6a08:	b40002d4 	cbz	x20, 6a60 <fwp_drop4+0x14c>
    6a0c:	38626862 	ldrb	w2, [x3, x2]
    6a10:	7100085f 	cmp	w2, #0x2
    6a14:	54000400 	b.eq	6a94 <fwp_drop4+0x180>  // b.none
    6a18:	7100045f 	cmp	w2, #0x1
    6a1c:	54000221 	b.ne	6a60 <fwp_drop4+0x14c>  // b.any
    6a20:	29430883 	ldp	w3, w2, [x4, #24]
    6a24:	92403c21 	and	x1, x1, #0xffff
    6a28:	9b037c21 	mul	x1, x1, x3
    6a2c:	d360fc21 	lsr	x1, x1, #32
    6a30:	eb02003f 	cmp	x1, x2
    6a34:	54000162 	b.cs	6a60 <fwp_drop4+0x14c>  // b.hs, b.nlast
    6a38:	8b010294 	add	x20, x20, x1
    6a3c:	39400281 	ldrb	w1, [x20]
    6a40:	34000101 	cbz	w1, 6a60 <fwp_drop4+0x14c>
    6a44:	7100043f 	cmp	w1, #0x1
    6a48:	54000220 	b.eq	6a8c <fwp_drop4+0x178>  // b.none
    6a4c:	7103fc3f 	cmp	w1, #0xff
    6a50:	54000660 	b.eq	6b1c <fwp_drop4+0x208>  // b.none
    6a54:	51000421 	sub	w1, w1, #0x1
    6a58:	39000281 	strb	w1, [x20]
    6a5c:	d503201f 	nop
    6a60:	f9400a74 	ldr	x20, [x19, #16]
    6a64:	aa1303e0 	mov	x0, x19
    6a68:	97fffcda 	bl	5dd0 <fwp_rc_free_arr>
    6a6c:	911842c0 	add	x0, x22, #0x610
    6a70:	f949d801 	ldr	x1, [x0, #5040]
    6a74:	f949ec00 	ldr	x0, [x0, #5080]
    6a78:	cb010281 	sub	x1, x20, x1
    6a7c:	eb00403f 	cmp	x1, x0, lsl #16
    6a80:	54fff982 	b.cs	69b0 <fwp_drop4+0x9c>  // b.hs, b.nlast
    6a84:	aa1403f3 	mov	x19, x20
    6a88:	17ffffaf 	b	6944 <fwp_drop4+0x30>
    6a8c:	97fffcd1 	bl	5dd0 <fwp_rc_free_arr>
    6a90:	17fffff4 	b	6a60 <fwp_drop4+0x14c>
    6a94:	72003c3f 	tst	w1, #0xffff
    6a98:	54fffe41 	b.ne	6a60 <fwp_drop4+0x14c>  // b.any
    6a9c:	17ffffe8 	b	6a3c <fwp_drop4+0x128>
    6aa0:	ca544681 	eor	x1, x20, x20, lsr #17
    6aa4:	911842c0 	add	x0, x22, #0x610
    6aa8:	ca412421 	eor	x1, x1, x1, lsr #9
    6aac:	92401c21 	and	x1, x1, #0xff
    6ab0:	910a2422 	add	x2, x1, #0x289
    6ab4:	8b010c01 	add	x1, x0, x1, lsl #3
    6ab8:	8b020c02 	add	x2, x0, x2, lsl #3
    6abc:	f94a2420 	ldr	x0, [x1, #5192]
    6ac0:	b50000a0 	cbnz	x0, 6ad4 <fwp_drop4+0x1c0>
    6ac4:	14000013 	b	6b10 <fwp_drop4+0x1fc>
    6ac8:	91004002 	add	x2, x0, #0x10
    6acc:	f9400800 	ldr	x0, [x0, #16]
    6ad0:	b4000200 	cbz	x0, 6b10 <fwp_drop4+0x1fc>
    6ad4:	f9400001 	ldr	x1, [x0]
    6ad8:	eb14003f 	cmp	x1, x20
    6adc:	54ffff61 	b.ne	6ac8 <fwp_drop4+0x1b4>  // b.any
    6ae0:	f9400041 	ldr	x1, [x2]
    6ae4:	f9400420 	ldr	x0, [x1, #8]
    6ae8:	d1000400 	sub	x0, x0, #0x1
    6aec:	f9000420 	str	x0, [x1, #8]
    6af0:	f103f81f 	cmp	x0, #0xfe
    6af4:	54fff5e1 	b.ne	69b0 <fwp_drop4+0x9c>  // b.any
    6af8:	39400280 	ldrb	w0, [x20]
    6afc:	7103fc1f 	cmp	w0, #0xff
    6b00:	54000460 	b.eq	6b8c <fwp_drop4+0x278>  // b.none
    6b04:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b08:	39000280 	strb	w0, [x20]
    6b0c:	17ffffa9 	b	69b0 <fwp_drop4+0x9c>
    6b10:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    6b14:	913e6000 	add	x0, x0, #0xf98
    6b18:	97fff5f3 	bl	42e4 <fwp_trap>
    6b1c:	ca544680 	eor	x0, x20, x20, lsr #17
    6b20:	911842c1 	add	x1, x22, #0x610
    6b24:	ca402400 	eor	x0, x0, x0, lsr #9
    6b28:	92401c00 	and	x0, x0, #0xff
    6b2c:	910a2402 	add	x2, x0, #0x289
    6b30:	8b000c20 	add	x0, x1, x0, lsl #3
    6b34:	8b020c22 	add	x2, x1, x2, lsl #3
    6b38:	f94a2400 	ldr	x0, [x0, #5192]
    6b3c:	b50000a0 	cbnz	x0, 6b50 <fwp_drop4+0x23c>
    6b40:	17fffff4 	b	6b10 <fwp_drop4+0x1fc>
    6b44:	91004002 	add	x2, x0, #0x10
    6b48:	f9400800 	ldr	x0, [x0, #16]
    6b4c:	b4fffe20 	cbz	x0, 6b10 <fwp_drop4+0x1fc>
    6b50:	f9400001 	ldr	x1, [x0]
    6b54:	eb14003f 	cmp	x1, x20
    6b58:	54ffff61 	b.ne	6b44 <fwp_drop4+0x230>  // b.any
    6b5c:	f9400041 	ldr	x1, [x2]
    6b60:	f9400420 	ldr	x0, [x1, #8]
    6b64:	d1000400 	sub	x0, x0, #0x1
    6b68:	f9000420 	str	x0, [x1, #8]
    6b6c:	f103f81f 	cmp	x0, #0xfe
    6b70:	54fff781 	b.ne	6a60 <fwp_drop4+0x14c>  // b.any
    6b74:	39400280 	ldrb	w0, [x20]
    6b78:	7103fc1f 	cmp	w0, #0xff
    6b7c:	540000e0 	b.eq	6b98 <fwp_drop4+0x284>  // b.none
    6b80:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b84:	39000280 	strb	w0, [x20]
    6b88:	17ffffb6 	b	6a60 <fwp_drop4+0x14c>
    6b8c:	aa1403e0 	mov	x0, x20
    6b90:	97fff5f5 	bl	4364 <fwp_rc_forget_slot.part.0>
    6b94:	17ffffdc 	b	6b04 <fwp_drop4+0x1f0>
    6b98:	aa1403e0 	mov	x0, x20
    6b9c:	97fff5f2 	bl	4364 <fwp_rc_forget_slot.part.0>
    6ba0:	17fffff8 	b	6b80 <fwp_drop4+0x26c>

0000000000006ba4 <fwp_arg_drop37>:
    6ba4:	7100003f 	cmp	w1, #0x0
    6ba8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6bac:	54000041 	b.ne	6bb4 <fwp_arg_drop37+0x10>  // b.any
    6bb0:	d65f03c0 	ret
    6bb4:	f9400000 	ldr	x0, [x0]
    6bb8:	17ffff57 	b	6914 <fwp_drop4>
    6bbc:	d503201f 	nop

0000000000006bc0 <fwp_task_dispose>:
    6bc0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6bc4:	910003fd 	mov	x29, sp
    6bc8:	f9000bf3 	str	x19, [sp, #16]
    6bcc:	aa0003f3 	mov	x19, x0
    6bd0:	39414000 	ldrb	w0, [x0, #80]
    6bd4:	36000720 	tbz	w0, #0, 6cb8 <fwp_task_dispose+0xf8>
    6bd8:	f9400a60 	ldr	x0, [x19, #16]
    6bdc:	b50006e0 	cbnz	x0, 6cb8 <fwp_task_dispose+0xf8>
    6be0:	a9478660 	ldp	x0, x1, [x19, #120]
    6be4:	39014e7f 	strb	wzr, [x19, #83]
    6be8:	f9003e7f 	str	xzr, [x19, #120]
    6bec:	f100003f 	cmp	x1, #0x0
    6bf0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6bf4:	54000040 	b.eq	6bfc <fwp_task_dispose+0x3c>  // b.none
    6bf8:	d63f0020 	blr	x1
    6bfc:	f9405660 	ldr	x0, [x19, #168]
    6c00:	97fff674 	bl	45d0 <fwp_mem_free>
    6c04:	f900567f 	str	xzr, [x19, #168]
    6c08:	b9405e60 	ldr	w0, [x19, #92]
    6c0c:	7100041f 	cmp	w0, #0x1
    6c10:	54000420 	b.eq	6c94 <fwp_task_dispose+0xd4>  // b.none
    6c14:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbd0>
    6c18:	91184042 	add	x2, x2, #0x610
    6c1c:	f949d840 	ldr	x0, [x2, #5040]
    6c20:	f949ec41 	ldr	x1, [x2, #5080]
    6c24:	cb000260 	sub	x0, x19, x0
    6c28:	eb01401f 	cmp	x0, x1, lsl #16
    6c2c:	540002e2 	b.cs	6c88 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6c30:	d350fc01 	lsr	x1, x0, #16
    6c34:	f949fc44 	ldr	x4, [x2, #5112]
    6c38:	8b010821 	add	x1, x1, x1, lsl #2
    6c3c:	d37df021 	lsl	x1, x1, #3
    6c40:	8b010083 	add	x3, x4, x1
    6c44:	f9401062 	ldr	x2, [x3, #32]
    6c48:	b4000202 	cbz	x2, 6c88 <fwp_task_dispose+0xc8>
    6c4c:	38616881 	ldrb	w1, [x4, x1]
    6c50:	7100083f 	cmp	w1, #0x2
    6c54:	54000280 	b.eq	6ca4 <fwp_task_dispose+0xe4>  // b.none
    6c58:	7100043f 	cmp	w1, #0x1
    6c5c:	54000161 	b.ne	6c88 <fwp_task_dispose+0xc8>  // b.any
    6c60:	29430464 	ldp	w4, w1, [x3, #24]
    6c64:	92403c00 	and	x0, x0, #0xffff
    6c68:	9b047c00 	mul	x0, x0, x4
    6c6c:	d360fc00 	lsr	x0, x0, #32
    6c70:	eb01001f 	cmp	x0, x1
    6c74:	540000a2 	b.cs	6c88 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6c78:	8b000042 	add	x2, x2, x0
    6c7c:	39400040 	ldrb	w0, [x2]
    6c80:	7100041f 	cmp	w0, #0x1
    6c84:	54000080 	b.eq	6c94 <fwp_task_dispose+0xd4>  // b.none
    6c88:	f9400bf3 	ldr	x19, [sp, #16]
    6c8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c90:	d65f03c0 	ret
    6c94:	aa1303e0 	mov	x0, x19
    6c98:	f9400bf3 	ldr	x19, [sp, #16]
    6c9c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ca0:	17fff64c 	b	45d0 <fwp_mem_free>
    6ca4:	72003c1f 	tst	w0, #0xffff
    6ca8:	54fffea0 	b.eq	6c7c <fwp_task_dispose+0xbc>  // b.none
    6cac:	f9400bf3 	ldr	x19, [sp, #16]
    6cb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6cb4:	d65f03c0 	ret
    6cb8:	97ffeefe 	bl	28b0 <abort@plt>
    6cbc:	d503201f 	nop

0000000000006cc0 <fwp_free_zombie>:
    6cc0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6cc4:	910003fd 	mov	x29, sp
    6cc8:	a90153f3 	stp	x19, x20, [sp, #16]
    6ccc:	d00000d4 	adrp	x20, 20000 <__data_start>
    6cd0:	91014281 	add	x1, x20, #0x50
    6cd4:	f940ac33 	ldr	x19, [x1, #344]
    6cd8:	b4000333 	cbz	x19, 6d3c <fwp_free_zombie+0x7c>
    6cdc:	f9404c20 	ldr	x0, [x1, #152]
    6ce0:	eb00027f 	cmp	x19, x0
    6ce4:	540002c0 	b.eq	6d3c <fwp_free_zombie+0x7c>  // b.none
    6ce8:	b9416022 	ldr	w2, [x1, #352]
    6cec:	f9400a60 	ldr	x0, [x19, #16]
    6cf0:	7100fc5f 	cmp	w2, #0x3f
    6cf4:	5400078c 	b.gt	6de4 <fwp_free_zombie+0x124>
    6cf8:	9105c023 	add	x3, x1, #0x170
    6cfc:	11000444 	add	w4, w2, #0x1
    6d00:	b9016024 	str	w4, [x1, #352]
    6d04:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6d08:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6d0c:	a9530261 	ldp	x1, x0, [x19, #304]
    6d10:	b4000741 	cbz	x1, 6df8 <fwp_free_zombie+0x138>
    6d14:	f9009c20 	str	x0, [x1, #312]
    6d18:	b4000040 	cbz	x0, 6d20 <fwp_free_zombie+0x60>
    6d1c:	f9009801 	str	x1, [x0, #304]
    6d20:	91014294 	add	x20, x20, #0x50
    6d24:	b9405e60 	ldr	w0, [x19, #92]
    6d28:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6d2c:	f900ae9f 	str	xzr, [x20, #344]
    6d30:	34000140 	cbz	w0, 6d58 <fwp_free_zombie+0x98>
    6d34:	7100041f 	cmp	w0, #0x1
    6d38:	54000080 	b.eq	6d48 <fwp_free_zombie+0x88>  // b.none
    6d3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d44:	d65f03c0 	ret
    6d48:	aa1303e0 	mov	x0, x19
    6d4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d54:	17ffff9b 	b	6bc0 <fwp_task_dispose>
    6d58:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbd0>
    6d5c:	91184082 	add	x2, x4, #0x610
    6d60:	f949d841 	ldr	x1, [x2, #5040]
    6d64:	f949ec40 	ldr	x0, [x2, #5080]
    6d68:	cb010261 	sub	x1, x19, x1
    6d6c:	eb00403f 	cmp	x1, x0, lsl #16
    6d70:	54fffe62 	b.cs	6d3c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6d74:	d350fc20 	lsr	x0, x1, #16
    6d78:	f949fc43 	ldr	x3, [x2, #5112]
    6d7c:	8b000800 	add	x0, x0, x0, lsl #2
    6d80:	d37df000 	lsl	x0, x0, #3
    6d84:	8b000062 	add	x2, x3, x0
    6d88:	f9401054 	ldr	x20, [x2, #32]
    6d8c:	b4fffd94 	cbz	x20, 6d3c <fwp_free_zombie+0x7c>
    6d90:	38606860 	ldrb	w0, [x3, x0]
    6d94:	7100081f 	cmp	w0, #0x2
    6d98:	54000360 	b.eq	6e04 <fwp_free_zombie+0x144>  // b.none
    6d9c:	7100041f 	cmp	w0, #0x1
    6da0:	54fffce1 	b.ne	6d3c <fwp_free_zombie+0x7c>  // b.any
    6da4:	29430043 	ldp	w3, w0, [x2, #24]
    6da8:	92403c21 	and	x1, x1, #0xffff
    6dac:	9b037c21 	mul	x1, x1, x3
    6db0:	d360fc21 	lsr	x1, x1, #32
    6db4:	eb00003f 	cmp	x1, x0
    6db8:	54fffc22 	b.cs	6d3c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6dbc:	8b010294 	add	x20, x20, x1
    6dc0:	39400280 	ldrb	w0, [x20]
    6dc4:	34fffbc0 	cbz	w0, 6d3c <fwp_free_zombie+0x7c>
    6dc8:	7100041f 	cmp	w0, #0x1
    6dcc:	54fffbe0 	b.eq	6d48 <fwp_free_zombie+0x88>  // b.none
    6dd0:	7103fc1f 	cmp	w0, #0xff
    6dd4:	540001e0 	b.eq	6e10 <fwp_free_zombie+0x150>  // b.none
    6dd8:	51000400 	sub	w0, w0, #0x1
    6ddc:	39000280 	strb	w0, [x20]
    6de0:	17ffffd7 	b	6d3c <fwp_free_zombie+0x7c>
    6de4:	f9400e61 	ldr	x1, [x19, #24]
    6de8:	97ffeee6 	bl	2980 <munmap@plt>
    6dec:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6df0:	a9530261 	ldp	x1, x0, [x19, #304]
    6df4:	b5fff901 	cbnz	x1, 6d14 <fwp_free_zombie+0x54>
    6df8:	91014282 	add	x2, x20, #0x50
    6dfc:	f901b840 	str	x0, [x2, #880]
    6e00:	17ffffc6 	b	6d18 <fwp_free_zombie+0x58>
    6e04:	72003c3f 	tst	w1, #0xffff
    6e08:	54fff9a1 	b.ne	6d3c <fwp_free_zombie+0x7c>  // b.any
    6e0c:	17ffffed 	b	6dc0 <fwp_free_zombie+0x100>
    6e10:	ca544680 	eor	x0, x20, x20, lsr #17
    6e14:	91184084 	add	x4, x4, #0x610
    6e18:	ca402400 	eor	x0, x0, x0, lsr #9
    6e1c:	92401c00 	and	x0, x0, #0xff
    6e20:	910a2402 	add	x2, x0, #0x289
    6e24:	8b000c80 	add	x0, x4, x0, lsl #3
    6e28:	8b020c82 	add	x2, x4, x2, lsl #3
    6e2c:	f94a2400 	ldr	x0, [x0, #5192]
    6e30:	b50000a0 	cbnz	x0, 6e44 <fwp_free_zombie+0x184>
    6e34:	14000013 	b	6e80 <fwp_free_zombie+0x1c0>
    6e38:	91004002 	add	x2, x0, #0x10
    6e3c:	f9400800 	ldr	x0, [x0, #16]
    6e40:	b4000200 	cbz	x0, 6e80 <fwp_free_zombie+0x1c0>
    6e44:	f9400001 	ldr	x1, [x0]
    6e48:	eb14003f 	cmp	x1, x20
    6e4c:	54ffff61 	b.ne	6e38 <fwp_free_zombie+0x178>  // b.any
    6e50:	f9400041 	ldr	x1, [x2]
    6e54:	f9400420 	ldr	x0, [x1, #8]
    6e58:	d1000400 	sub	x0, x0, #0x1
    6e5c:	f9000420 	str	x0, [x1, #8]
    6e60:	f103f81f 	cmp	x0, #0xfe
    6e64:	54fff6c1 	b.ne	6d3c <fwp_free_zombie+0x7c>  // b.any
    6e68:	39400280 	ldrb	w0, [x20]
    6e6c:	7103fc1f 	cmp	w0, #0xff
    6e70:	540000e0 	b.eq	6e8c <fwp_free_zombie+0x1cc>  // b.none
    6e74:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6e78:	39000280 	strb	w0, [x20]
    6e7c:	17ffffb0 	b	6d3c <fwp_free_zombie+0x7c>
    6e80:	f0000000 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    6e84:	913e6000 	add	x0, x0, #0xf98
    6e88:	97fff517 	bl	42e4 <fwp_trap>
    6e8c:	aa1403e0 	mov	x0, x20
    6e90:	97fff535 	bl	4364 <fwp_rc_forget_slot.part.0>
    6e94:	17fffff8 	b	6e74 <fwp_free_zombie+0x1b4>
    6e98:	d503201f 	nop
    6e9c:	d503201f 	nop

0000000000006ea0 <fwp_block>:
    6ea0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6ea4:	910003fd 	mov	x29, sp
    6ea8:	a90153f3 	stp	x19, x20, [sp, #16]
    6eac:	d00000d3 	adrp	x19, 20000 <__data_start>
    6eb0:	91014274 	add	x20, x19, #0x50
    6eb4:	f9406682 	ldr	x2, [x20, #200]
    6eb8:	b4000642 	cbz	x2, 6f80 <fwp_block+0xe0>
    6ebc:	91014261 	add	x1, x19, #0x50
    6ec0:	f9408040 	ldr	x0, [x2, #256]
    6ec4:	f9006420 	str	x0, [x1, #200]
    6ec8:	b40006a0 	cbz	x0, 6f9c <fwp_block+0xfc>
    6ecc:	d503201f 	nop
    6ed0:	91014263 	add	x3, x19, #0x50
    6ed4:	3901505f 	strb	wzr, [x2, #84]
    6ed8:	f9404c64 	ldr	x4, [x3, #152]
    6edc:	eb02009f 	cmp	x4, x2
    6ee0:	54000440 	b.eq	6f68 <fwp_block+0xc8>  // b.none
    6ee4:	f941bc65 	ldr	x5, [x3, #888]
    6ee8:	f9004c62 	str	x2, [x3, #152]
    6eec:	f9400441 	ldr	x1, [x2, #8]
    6ef0:	f9004885 	str	x5, [x4, #144]
    6ef4:	f941c065 	ldr	x5, [x3, #896]
    6ef8:	f9004c85 	str	x5, [x4, #152]
    6efc:	f941c465 	ldr	x5, [x3, #904]
    6f00:	f9005085 	str	x5, [x4, #160]
    6f04:	f941c865 	ldr	x5, [x3, #912]
    6f08:	f9005485 	str	x5, [x4, #168]
    6f0c:	f941cc65 	ldr	x5, [x3, #920]
    6f10:	f9005885 	str	x5, [x4, #176]
    6f14:	f941d065 	ldr	x5, [x3, #928]
    6f18:	f9005c85 	str	x5, [x4, #184]
    6f1c:	f941d465 	ldr	x5, [x3, #936]
    6f20:	f9006085 	str	x5, [x4, #192]
    6f24:	f9400480 	ldr	x0, [x4, #8]
    6f28:	f9404844 	ldr	x4, [x2, #144]
    6f2c:	f901bc64 	str	x4, [x3, #888]
    6f30:	f9404c44 	ldr	x4, [x2, #152]
    6f34:	f901c064 	str	x4, [x3, #896]
    6f38:	f9405044 	ldr	x4, [x2, #160]
    6f3c:	f901c464 	str	x4, [x3, #904]
    6f40:	f9405444 	ldr	x4, [x2, #168]
    6f44:	f901c864 	str	x4, [x3, #912]
    6f48:	f9405844 	ldr	x4, [x2, #176]
    6f4c:	f901cc64 	str	x4, [x3, #920]
    6f50:	a94b8844 	ldp	x4, x2, [x2, #184]
    6f54:	f901d064 	str	x4, [x3, #928]
    6f58:	f901d462 	str	x2, [x3, #936]
    6f5c:	97ffee59 	bl	28c0 <swapcontext@plt>
    6f60:	97ffff58 	bl	6cc0 <fwp_free_zombie>
    6f64:	d503201f 	nop
    6f68:	91014260 	add	x0, x19, #0x50
    6f6c:	b943b000 	ldr	w0, [x0, #944]
    6f70:	340001a0 	cbz	w0, 6fa4 <fwp_block+0x104>
    6f74:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f78:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f7c:	d65f03c0 	ret
    6f80:	97fff720 	bl	4c00 <fwp_poll_events>
    6f84:	f9406682 	ldr	x2, [x20, #200]
    6f88:	b4ffffc2 	cbz	x2, 6f80 <fwp_block+0xe0>
    6f8c:	91014261 	add	x1, x19, #0x50
    6f90:	f9408040 	ldr	x0, [x2, #256]
    6f94:	f9006420 	str	x0, [x1, #200]
    6f98:	b5fff9c0 	cbnz	x0, 6ed0 <fwp_block+0x30>
    6f9c:	f900603f 	str	xzr, [x1, #192]
    6fa0:	17ffffcc 	b	6ed0 <fwp_block+0x30>
    6fa4:	90000020 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    6fa8:	9108c000 	add	x0, x0, #0x230
    6fac:	97ffee91 	bl	29f0 <getenv@plt>
    6fb0:	5284e202 	mov	w2, #0x2710                	// #10000
    6fb4:	b4000060 	cbz	x0, 6fc0 <fwp_block+0x120>
    6fb8:	39400001 	ldrb	w1, [x0]
    6fbc:	350000c1 	cbnz	w1, 6fd4 <fwp_block+0x134>
    6fc0:	91014273 	add	x19, x19, #0x50
    6fc4:	b903b262 	str	w2, [x19, #944]
    6fc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6fcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6fd0:	d65f03c0 	ret
    6fd4:	52800142 	mov	w2, #0xa                   	// #10
    6fd8:	d2800001 	mov	x1, #0x0                   	// #0
    6fdc:	97ffedd5 	bl	2730 <strtoll@plt>
    6fe0:	d1000403 	sub	x3, x0, #0x1
    6fe4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6fe8:	eb02007f 	cmp	x3, x2
    6fec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6ff0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6ff4:	17fffff3 	b	6fc0 <fwp_block+0x120>
    6ff8:	d503201f 	nop
    6ffc:	d503201f 	nop

0000000000007000 <fwp_drop10>:
    7000:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7004:	910003fd 	mov	x29, sp
    7008:	a90153f3 	stp	x19, x20, [sp, #16]
    700c:	d0000393 	adrp	x19, 79000 <fwp_root_context+0xbd0>
    7010:	f90013f5 	str	x21, [sp, #32]
    7014:	91184275 	add	x21, x19, #0x610
    7018:	f949daa1 	ldr	x1, [x21, #5040]
    701c:	f949eea2 	ldr	x2, [x21, #5080]
    7020:	cb010001 	sub	x1, x0, x1
    7024:	eb02403f 	cmp	x1, x2, lsl #16
    7028:	54000382 	b.cs	7098 <fwp_drop10+0x98>  // b.hs, b.nlast
    702c:	d350fc22 	lsr	x2, x1, #16
    7030:	f949fea3 	ldr	x3, [x21, #5112]
    7034:	8b020842 	add	x2, x2, x2, lsl #2
    7038:	d37df042 	lsl	x2, x2, #3
    703c:	8b020064 	add	x4, x3, x2
    7040:	f9401094 	ldr	x20, [x4, #32]
    7044:	b40002b4 	cbz	x20, 7098 <fwp_drop10+0x98>
    7048:	38626862 	ldrb	w2, [x3, x2]
    704c:	7100085f 	cmp	w2, #0x2
    7050:	540007a0 	b.eq	7144 <fwp_drop10+0x144>  // b.none
    7054:	7100045f 	cmp	w2, #0x1
    7058:	54000201 	b.ne	7098 <fwp_drop10+0x98>  // b.any
    705c:	29430885 	ldp	w5, w2, [x4, #24]
    7060:	92403c21 	and	x1, x1, #0xffff
    7064:	9b057c21 	mul	x1, x1, x5
    7068:	d360fc21 	lsr	x1, x1, #32
    706c:	eb02003f 	cmp	x1, x2
    7070:	54000142 	b.cs	7098 <fwp_drop10+0x98>  // b.hs, b.nlast
    7074:	8b010294 	add	x20, x20, x1
    7078:	39400281 	ldrb	w1, [x20]
    707c:	340000e1 	cbz	w1, 7098 <fwp_drop10+0x98>
    7080:	7100043f 	cmp	w1, #0x1
    7084:	54000120 	b.eq	70a8 <fwp_drop10+0xa8>  // b.none
    7088:	7103fc3f 	cmp	w1, #0xff
    708c:	540007c0 	b.eq	7184 <fwp_drop10+0x184>  // b.none
    7090:	51000421 	sub	w1, w1, #0x1
    7094:	39000281 	strb	w1, [x20]
    7098:	a94153f3 	ldp	x19, x20, [sp, #16]
    709c:	f94013f5 	ldr	x21, [sp, #32]
    70a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    70a4:	d65f03c0 	ret
    70a8:	f9400001 	ldr	x1, [x0]
    70ac:	b7f80581 	tbnz	x1, #63, 715c <fwp_drop10+0x15c>
    70b0:	91184273 	add	x19, x19, #0x610
    70b4:	f949da61 	ldr	x1, [x19, #5040]
    70b8:	f949ee62 	ldr	x2, [x19, #5080]
    70bc:	cb010001 	sub	x1, x0, x1
    70c0:	eb02403f 	cmp	x1, x2, lsl #16
    70c4:	54fffea2 	b.cs	7098 <fwp_drop10+0x98>  // b.hs, b.nlast
    70c8:	d350fc22 	lsr	x2, x1, #16
    70cc:	8b020842 	add	x2, x2, x2, lsl #2
    70d0:	d37df042 	lsl	x2, x2, #3
    70d4:	8b020065 	add	x5, x3, x2
    70d8:	f94010a4 	ldr	x4, [x5, #32]
    70dc:	b4fffde4 	cbz	x4, 7098 <fwp_drop10+0x98>
    70e0:	38626862 	ldrb	w2, [x3, x2]
    70e4:	7100085f 	cmp	w2, #0x2
    70e8:	54000220 	b.eq	712c <fwp_drop10+0x12c>  // b.none
    70ec:	7100045f 	cmp	w2, #0x1
    70f0:	54fffd41 	b.ne	7098 <fwp_drop10+0x98>  // b.any
    70f4:	294308a3 	ldp	w3, w2, [x5, #24]
    70f8:	92403c21 	and	x1, x1, #0xffff
    70fc:	9b037c21 	mul	x1, x1, x3
    7100:	d360fc21 	lsr	x1, x1, #32
    7104:	eb02003f 	cmp	x1, x2
    7108:	54fffc82 	b.cs	7098 <fwp_drop10+0x98>  // b.hs, b.nlast
    710c:	8b010084 	add	x4, x4, x1
    7110:	39400081 	ldrb	w1, [x4]
    7114:	7100043f 	cmp	w1, #0x1
    7118:	54fffc01 	b.ne	7098 <fwp_drop10+0x98>  // b.any
    711c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7120:	f94013f5 	ldr	x21, [sp, #32]
    7124:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7128:	17fff52a 	b	45d0 <fwp_mem_free>
    712c:	72003c3f 	tst	w1, #0xffff
    7130:	54ffff00 	b.eq	7110 <fwp_drop10+0x110>  // b.none
    7134:	a94153f3 	ldp	x19, x20, [sp, #16]
    7138:	f94013f5 	ldr	x21, [sp, #32]
    713c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7140:	d65f03c0 	ret
    7144:	72003c3f 	tst	w1, #0xffff
    7148:	54fff980 	b.eq	7078 <fwp_drop10+0x78>  // b.none
    714c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7150:	f94013f5 	ldr	x21, [sp, #32]
    7154:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7158:	d65f03c0 	ret
    715c:	f9400414 	ldr	x20, [x0, #8]
    7160:	97fffb1c 	bl	5dd0 <fwp_rc_free_arr>
    7164:	91184260 	add	x0, x19, #0x610
    7168:	f949d801 	ldr	x1, [x0, #5040]
    716c:	f949ec00 	ldr	x0, [x0, #5080]
    7170:	cb010281 	sub	x1, x20, x1
    7174:	eb00403f 	cmp	x1, x0, lsl #16
    7178:	54fff902 	b.cs	7098 <fwp_drop10+0x98>  // b.hs, b.nlast
    717c:	aa1403e0 	mov	x0, x20
    7180:	17ffffab 	b	702c <fwp_drop10+0x2c>
    7184:	ca544680 	eor	x0, x20, x20, lsr #17
    7188:	91184273 	add	x19, x19, #0x610
    718c:	ca402400 	eor	x0, x0, x0, lsr #9
    7190:	92401c00 	and	x0, x0, #0xff
    7194:	910a2402 	add	x2, x0, #0x289
    7198:	8b000e60 	add	x0, x19, x0, lsl #3
    719c:	8b020e62 	add	x2, x19, x2, lsl #3
    71a0:	f94a2400 	ldr	x0, [x0, #5192]
    71a4:	b50000a0 	cbnz	x0, 71b8 <fwp_drop10+0x1b8>
    71a8:	14000013 	b	71f4 <fwp_drop10+0x1f4>
    71ac:	91004002 	add	x2, x0, #0x10
    71b0:	f9400800 	ldr	x0, [x0, #16]
    71b4:	b4000200 	cbz	x0, 71f4 <fwp_drop10+0x1f4>
    71b8:	f9400001 	ldr	x1, [x0]
    71bc:	eb14003f 	cmp	x1, x20
    71c0:	54ffff61 	b.ne	71ac <fwp_drop10+0x1ac>  // b.any
    71c4:	f9400041 	ldr	x1, [x2]
    71c8:	f9400420 	ldr	x0, [x1, #8]
    71cc:	d1000400 	sub	x0, x0, #0x1
    71d0:	f9000420 	str	x0, [x1, #8]
    71d4:	f103f81f 	cmp	x0, #0xfe
    71d8:	54fff601 	b.ne	7098 <fwp_drop10+0x98>  // b.any
    71dc:	39400280 	ldrb	w0, [x20]
    71e0:	7103fc1f 	cmp	w0, #0xff
    71e4:	540000e0 	b.eq	7200 <fwp_drop10+0x200>  // b.none
    71e8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    71ec:	39000280 	strb	w0, [x20]
    71f0:	17ffffaa 	b	7098 <fwp_drop10+0x98>
    71f4:	d0000000 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    71f8:	913e6000 	add	x0, x0, #0xf98
    71fc:	97fff43a 	bl	42e4 <fwp_trap>
    7200:	aa1403e0 	mov	x0, x20
    7204:	97fff458 	bl	4364 <fwp_rc_forget_slot.part.0>
    7208:	17fffff8 	b	71e8 <fwp_drop10+0x1e8>
    720c:	d503201f 	nop

0000000000007210 <fwp_caps173>:
    7210:	34000041 	cbz	w1, 7218 <fwp_caps173+0x8>
    7214:	d65f03c0 	ret
    7218:	d0000383 	adrp	x3, 79000 <fwp_root_context+0xbd0>
    721c:	91184063 	add	x3, x3, #0x610
    7220:	f949d861 	ldr	x1, [x3, #5040]
    7224:	f949ec62 	ldr	x2, [x3, #5080]
    7228:	cb010001 	sub	x1, x0, x1
    722c:	eb02403f 	cmp	x1, x2, lsl #16
    7230:	54ffff22 	b.cs	7214 <fwp_caps173+0x4>  // b.hs, b.nlast
    7234:	d350fc22 	lsr	x2, x1, #16
    7238:	f949fc65 	ldr	x5, [x3, #5112]
    723c:	8b020842 	add	x2, x2, x2, lsl #2
    7240:	d37df042 	lsl	x2, x2, #3
    7244:	8b0200a4 	add	x4, x5, x2
    7248:	f9401083 	ldr	x3, [x4, #32]
    724c:	b4fffe43 	cbz	x3, 7214 <fwp_caps173+0x4>
    7250:	386268a2 	ldrb	w2, [x5, x2]
    7254:	7100085f 	cmp	w2, #0x2
    7258:	540001c0 	b.eq	7290 <fwp_caps173+0x80>  // b.none
    725c:	7100045f 	cmp	w2, #0x1
    7260:	54fffda1 	b.ne	7214 <fwp_caps173+0x4>  // b.any
    7264:	29430885 	ldp	w5, w2, [x4, #24]
    7268:	92403c21 	and	x1, x1, #0xffff
    726c:	9b057c21 	mul	x1, x1, x5
    7270:	d360fc21 	lsr	x1, x1, #32
    7274:	eb02003f 	cmp	x1, x2
    7278:	54fffce2 	b.cs	7214 <fwp_caps173+0x4>  // b.hs, b.nlast
    727c:	8b010063 	add	x3, x3, x1
    7280:	39400061 	ldrb	w1, [x3]
    7284:	7100043f 	cmp	w1, #0x1
    7288:	54fffc61 	b.ne	7214 <fwp_caps173+0x4>  // b.any
    728c:	17fff4d1 	b	45d0 <fwp_mem_free>
    7290:	72003c3f 	tst	w1, #0xffff
    7294:	54ffff60 	b.eq	7280 <fwp_caps173+0x70>  // b.none
    7298:	d65f03c0 	ret
    729c:	d503201f 	nop

00000000000072a0 <f37>:
    72a0:	d10243ff 	sub	sp, sp, #0x90
    72a4:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    72a8:	f947f421 	ldr	x1, [x1, #4072]
    72ac:	a9037bfd 	stp	x29, x30, [sp, #48]
    72b0:	9100c3fd 	add	x29, sp, #0x30
    72b4:	a9055bf5 	stp	x21, x22, [sp, #80]
    72b8:	d0000396 	adrp	x22, 79000 <fwp_root_context+0xbd0>
    72bc:	911842c3 	add	x3, x22, #0x610
    72c0:	a90453f3 	stp	x19, x20, [sp, #64]
    72c4:	aa0003f5 	mov	x21, x0
    72c8:	a90663f7 	stp	x23, x24, [sp, #96]
    72cc:	a90873fb 	stp	x27, x28, [sp, #128]
    72d0:	f949ec62 	ldr	x2, [x3, #5080]
    72d4:	f9400024 	ldr	x4, [x1]
    72d8:	f90017e4 	str	x4, [sp, #40]
    72dc:	d2800004 	mov	x4, #0x0                   	// #0
    72e0:	f949d861 	ldr	x1, [x3, #5040]
    72e4:	d370bc42 	lsl	x2, x2, #16
    72e8:	b4001820 	cbz	x0, 75ec <f37+0x34c>
    72ec:	f9400817 	ldr	x23, [x0, #16]
    72f0:	cb0102e1 	sub	x1, x23, x1
    72f4:	eb02003f 	cmp	x1, x2
    72f8:	540003e2 	b.cs	7374 <f37+0xd4>  // b.hs, b.nlast
    72fc:	f949fc60 	ldr	x0, [x3, #5112]
    7300:	d350fc22 	lsr	x2, x1, #16
    7304:	8b020842 	add	x2, x2, x2, lsl #2
    7308:	8b020c02 	add	x2, x0, x2, lsl #3
    730c:	f9401040 	ldr	x0, [x2, #32]
    7310:	b4000320 	cbz	x0, 7374 <f37+0xd4>
    7314:	39400043 	ldrb	w3, [x2]
    7318:	7100087f 	cmp	w3, #0x2
    731c:	540014e0 	b.eq	75b8 <f37+0x318>  // b.none
    7320:	7100047f 	cmp	w3, #0x1
    7324:	54000241 	b.ne	736c <f37+0xcc>  // b.any
    7328:	29430843 	ldp	w3, w2, [x2, #24]
    732c:	92403c21 	and	x1, x1, #0xffff
    7330:	9b037c21 	mul	x1, x1, x3
    7334:	d360fc21 	lsr	x1, x1, #32
    7338:	eb02003f 	cmp	x1, x2
    733c:	54000182 	b.cs	736c <f37+0xcc>  // b.hs, b.nlast
    7340:	8b010000 	add	x0, x0, x1
    7344:	39400001 	ldrb	w1, [x0]
    7348:	34000121 	cbz	w1, 736c <f37+0xcc>
    734c:	b00000c2 	adrp	x2, 20000 <__data_start>
    7350:	91014042 	add	x2, x2, #0x50
    7354:	b9412043 	ldr	w3, [x2, #288]
    7358:	35001363 	cbnz	w3, 75c4 <f37+0x324>
    735c:	7103f43f 	cmp	w1, #0xfd
    7360:	540017a8 	b.hi	7654 <f37+0x3b4>  // b.pmore
    7364:	11000421 	add	w1, w1, #0x1
    7368:	39000001 	strb	w1, [x0]
    736c:	d2800002 	mov	x2, #0x0                   	// #0
    7370:	b40000f5 	cbz	x21, 738c <f37+0xec>
    7374:	aa1503e1 	mov	x1, x21
    7378:	d2800002 	mov	x2, #0x0                   	// #0
    737c:	d503201f 	nop
    7380:	f9400821 	ldr	x1, [x1, #16]
    7384:	91000442 	add	x2, x2, #0x1
    7388:	b5ffffc1 	cbnz	x1, 7380 <f37+0xe0>
    738c:	b4001377 	cbz	x23, 75f8 <f37+0x358>
    7390:	aa1703e1 	mov	x1, x23
    7394:	d2800003 	mov	x3, #0x0                   	// #0
    7398:	f9400821 	ldr	x1, [x1, #16]
    739c:	91000463 	add	x3, x3, #0x1
    73a0:	b5ffffc1 	cbnz	x1, 7398 <f37+0xf8>
    73a4:	eb02007f 	cmp	x3, x2
    73a8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    73ac:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    73b0:	eb00027f 	cmp	x19, x0
    73b4:	54000fa8 	b.hi	75a8 <f37+0x308>  // b.pmore
    73b8:	d37ffa74 	lsl	x20, x19, #1
    73bc:	52800041 	mov	w1, #0x2                   	// #2
    73c0:	91000680 	add	x0, x20, #0x1
    73c4:	d37df000 	lsl	x0, x0, #3
    73c8:	97fff73e 	bl	50c0 <fwp_heap_alloc>
    73cc:	911842c1 	add	x1, x22, #0x610
    73d0:	aa0003fb 	mov	x27, x0
    73d4:	f9000014 	str	x20, [x0]
    73d8:	aa0103e0 	mov	x0, x1
    73dc:	f949d821 	ldr	x1, [x1, #5040]
    73e0:	f949ec00 	ldr	x0, [x0, #5080]
    73e4:	cb010361 	sub	x1, x27, x1
    73e8:	eb00403f 	cmp	x1, x0, lsl #16
    73ec:	54000342 	b.cs	7454 <f37+0x1b4>  // b.hs, b.nlast
    73f0:	911842c2 	add	x2, x22, #0x610
    73f4:	d350fc20 	lsr	x0, x1, #16
    73f8:	8b000800 	add	x0, x0, x0, lsl #2
    73fc:	f949fc43 	ldr	x3, [x2, #5112]
    7400:	d37df002 	lsl	x2, x0, #3
    7404:	8b020060 	add	x0, x3, x2
    7408:	f9401014 	ldr	x20, [x0, #32]
    740c:	b4000254 	cbz	x20, 7454 <f37+0x1b4>
    7410:	38626862 	ldrb	w2, [x3, x2]
    7414:	7100085f 	cmp	w2, #0x2
    7418:	54000de0 	b.eq	75d4 <f37+0x334>  // b.none
    741c:	7100045f 	cmp	w2, #0x1
    7420:	540001a1 	b.ne	7454 <f37+0x1b4>  // b.any
    7424:	29430002 	ldp	w2, w0, [x0, #24]
    7428:	92403c21 	and	x1, x1, #0xffff
    742c:	9b027c21 	mul	x1, x1, x2
    7430:	d360fc21 	lsr	x1, x1, #32
    7434:	eb00003f 	cmp	x1, x0
    7438:	540000e2 	b.cs	7454 <f37+0x1b4>  // b.hs, b.nlast
    743c:	8b010294 	add	x20, x20, x1
    7440:	39400280 	ldrb	w0, [x20]
    7444:	7103fc1f 	cmp	w0, #0xff
    7448:	540010a0 	b.eq	765c <f37+0x3bc>  // b.none
    744c:	52800020 	mov	w0, #0x1                   	// #1
    7450:	39000280 	strb	w0, [x20]
    7454:	b4000333 	cbz	x19, 74b8 <f37+0x218>
    7458:	8b131373 	add	x19, x27, x19, lsl #4
    745c:	aa1b03f4 	mov	x20, x27
    7460:	aa1703f8 	mov	x24, x23
    7464:	910023fc 	add	x28, sp, #0x8
    7468:	a9076bf9 	stp	x25, x26, [sp, #112]
    746c:	aa1503f9 	mov	x25, x21
    7470:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    7474:	d503201f 	nop
    7478:	f9400704 	ldr	x4, [x24, #8]
    747c:	aa1c03e2 	mov	x2, x28
    7480:	f9400723 	ldr	x3, [x25, #8]
    7484:	a900fffa 	stp	x26, xzr, [sp, #8]
    7488:	fd400481 	ldr	d1, [x4, #8]
    748c:	f9400881 	ldr	x1, [x4, #16]
    7490:	f9400860 	ldr	x0, [x3, #16]
    7494:	fd400460 	ldr	d0, [x3, #8]
    7498:	97fff8a6 	bl	5730 <w120>
    749c:	f9000680 	str	x0, [x20, #8]
    74a0:	f8010e81 	str	x1, [x20, #16]!
    74a4:	f9400b18 	ldr	x24, [x24, #16]
    74a8:	f9400b39 	ldr	x25, [x25, #16]
    74ac:	eb14027f 	cmp	x19, x20
    74b0:	54fffe41 	b.ne	7478 <f37+0x1d8>  // b.any
    74b4:	a9476bf9 	ldp	x25, x26, [sp, #112]
    74b8:	aa1703e0 	mov	x0, x23
    74bc:	97fffd16 	bl	6914 <fwp_drop4>
    74c0:	911842d6 	add	x22, x22, #0x610
    74c4:	aa1503e0 	mov	x0, x21
    74c8:	97fffd13 	bl	6914 <fwp_drop4>
    74cc:	aa1b03e0 	mov	x0, x27
    74d0:	97fff9e8 	bl	5c70 <w176.constprop.0>
    74d4:	aa0103f3 	mov	x19, x1
    74d8:	aa0003f4 	mov	x20, x0
    74dc:	aa1b03e0 	mov	x0, x27
    74e0:	97fffec8 	bl	7000 <fwp_drop10>
    74e4:	910063e1 	add	x1, sp, #0x18
    74e8:	52800000 	mov	w0, #0x0                   	// #0
    74ec:	a901cff4 	stp	x20, x19, [sp, #24]
    74f0:	97fff758 	bl	5250 <fwp_data.part.0.constprop.0>
    74f4:	aa0003f3 	mov	x19, x0
    74f8:	f949dac1 	ldr	x1, [x22, #5040]
    74fc:	f949eec0 	ldr	x0, [x22, #5080]
    7500:	cb010261 	sub	x1, x19, x1
    7504:	eb00403f 	cmp	x1, x0, lsl #16
    7508:	54000322 	b.cs	756c <f37+0x2cc>  // b.hs, b.nlast
    750c:	d350fc22 	lsr	x2, x1, #16
    7510:	f949fec3 	ldr	x3, [x22, #5112]
    7514:	8b020842 	add	x2, x2, x2, lsl #2
    7518:	d37df042 	lsl	x2, x2, #3
    751c:	8b020060 	add	x0, x3, x2
    7520:	f9401014 	ldr	x20, [x0, #32]
    7524:	b4000254 	cbz	x20, 756c <f37+0x2cc>
    7528:	38626862 	ldrb	w2, [x3, x2]
    752c:	7100085f 	cmp	w2, #0x2
    7530:	54000580 	b.eq	75e0 <f37+0x340>  // b.none
    7534:	7100045f 	cmp	w2, #0x1
    7538:	540001a1 	b.ne	756c <f37+0x2cc>  // b.any
    753c:	29430002 	ldp	w2, w0, [x0, #24]
    7540:	92403c21 	and	x1, x1, #0xffff
    7544:	9b027c21 	mul	x1, x1, x2
    7548:	d360fc21 	lsr	x1, x1, #32
    754c:	eb00003f 	cmp	x1, x0
    7550:	540000e2 	b.cs	756c <f37+0x2cc>  // b.hs, b.nlast
    7554:	8b010294 	add	x20, x20, x1
    7558:	39400280 	ldrb	w0, [x20]
    755c:	7103fc1f 	cmp	w0, #0xff
    7560:	54000840 	b.eq	7668 <f37+0x3c8>  // b.none
    7564:	52800020 	mov	w0, #0x1                   	// #1
    7568:	39000280 	strb	w0, [x20]
    756c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7570:	f947f400 	ldr	x0, [x0, #4072]
    7574:	f94017e2 	ldr	x2, [sp, #40]
    7578:	f9400001 	ldr	x1, [x0]
    757c:	eb010042 	subs	x2, x2, x1
    7580:	d2800001 	mov	x1, #0x0                   	// #0
    7584:	54000781 	b.ne	7674 <f37+0x3d4>  // b.any
    7588:	a9437bfd 	ldp	x29, x30, [sp, #48]
    758c:	aa1303e0 	mov	x0, x19
    7590:	a94453f3 	ldp	x19, x20, [sp, #64]
    7594:	a9455bf5 	ldp	x21, x22, [sp, #80]
    7598:	a94663f7 	ldp	x23, x24, [sp, #96]
    759c:	a94873fb 	ldp	x27, x28, [sp, #128]
    75a0:	910243ff 	add	sp, sp, #0x90
    75a4:	d65f03c0 	ret
    75a8:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    75ac:	91090000 	add	x0, x0, #0x240
    75b0:	a9076bf9 	stp	x25, x26, [sp, #112]
    75b4:	97fff34c 	bl	42e4 <fwp_trap>
    75b8:	72003c3f 	tst	w1, #0xffff
    75bc:	54ffed81 	b.ne	736c <f37+0xcc>  // b.any
    75c0:	17ffff61 	b	7344 <f37+0xa4>
    75c4:	f940a443 	ldr	x3, [x2, #328]
    75c8:	91000463 	add	x3, x3, #0x1
    75cc:	f900a443 	str	x3, [x2, #328]
    75d0:	17ffff63 	b	735c <f37+0xbc>
    75d4:	72003c3f 	tst	w1, #0xffff
    75d8:	54fff3e1 	b.ne	7454 <f37+0x1b4>  // b.any
    75dc:	17ffff99 	b	7440 <f37+0x1a0>
    75e0:	72003c3f 	tst	w1, #0xffff
    75e4:	54fffc41 	b.ne	756c <f37+0x2cc>  // b.any
    75e8:	17ffffdc 	b	7558 <f37+0x2b8>
    75ec:	cb0103e1 	neg	x1, x1
    75f0:	eb02003f 	cmp	x1, x2
    75f4:	54000203 	b.cc	7634 <f37+0x394>  // b.lo, b.ul, b.last
    75f8:	52800041 	mov	w1, #0x2                   	// #2
    75fc:	d2800100 	mov	x0, #0x8                   	// #8
    7600:	97fff6b0 	bl	50c0 <fwp_heap_alloc>
    7604:	aa0003e1 	mov	x1, x0
    7608:	911842c0 	add	x0, x22, #0x610
    760c:	aa0103fb 	mov	x27, x1
    7610:	d2800017 	mov	x23, #0x0                   	// #0
    7614:	f900003f 	str	xzr, [x1]
    7618:	f949d801 	ldr	x1, [x0, #5040]
    761c:	f949ec00 	ldr	x0, [x0, #5080]
    7620:	cb010361 	sub	x1, x27, x1
    7624:	eb00403f 	cmp	x1, x0, lsl #16
    7628:	54fff482 	b.cs	74b8 <f37+0x218>  // b.hs, b.nlast
    762c:	d2800013 	mov	x19, #0x0                   	// #0
    7630:	17ffff70 	b	73f0 <f37+0x150>
    7634:	f949fc62 	ldr	x2, [x3, #5112]
    7638:	d350fc20 	lsr	x0, x1, #16
    763c:	8b000800 	add	x0, x0, x0, lsl #2
    7640:	8b000c42 	add	x2, x2, x0, lsl #3
    7644:	f9401040 	ldr	x0, [x2, #32]
    7648:	b4fffd80 	cbz	x0, 75f8 <f37+0x358>
    764c:	d2800017 	mov	x23, #0x0                   	// #0
    7650:	17ffff31 	b	7314 <f37+0x74>
    7654:	97fff458 	bl	47b4 <fwp_rc_wide_dup>
    7658:	17ffff45 	b	736c <f37+0xcc>
    765c:	aa1403e0 	mov	x0, x20
    7660:	97fff341 	bl	4364 <fwp_rc_forget_slot.part.0>
    7664:	17ffff7a 	b	744c <f37+0x1ac>
    7668:	aa1403e0 	mov	x0, x20
    766c:	97fff33e 	bl	4364 <fwp_rc_forget_slot.part.0>
    7670:	17ffffbd 	b	7564 <f37+0x2c4>
    7674:	a9076bf9 	stp	x25, x26, [sp, #112]
    7678:	97ffec7a 	bl	2860 <__stack_chk_fail@plt>
    767c:	d503201f 	nop

0000000000007680 <fwp_owned_entry37>:
    7680:	f9400000 	ldr	x0, [x0]
    7684:	17ffff07 	b	72a0 <f37>
    7688:	d503201f 	nop
    768c:	d503201f 	nop

0000000000007690 <e37>:
    7690:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7694:	910003fd 	mov	x29, sp
    7698:	f9000bf3 	str	x19, [sp, #16]
    769c:	f9400013 	ldr	x19, [x0]
    76a0:	aa1303e0 	mov	x0, x19
    76a4:	97fff9a7 	bl	5d40 <fwp_rc_share>
    76a8:	aa1303e0 	mov	x0, x19
    76ac:	97fffefd 	bl	72a0 <f37>
    76b0:	aa0003f3 	mov	x19, x0
    76b4:	97fff9a3 	bl	5d40 <fwp_rc_share>
    76b8:	aa1303e0 	mov	x0, x19
    76bc:	f9400bf3 	ldr	x19, [sp, #16]
    76c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    76c4:	d65f03c0 	ret
    76c8:	d503201f 	nop
    76cc:	d503201f 	nop

00000000000076d0 <fwp_args37>:
    76d0:	7100003f 	cmp	w1, #0x0
    76d4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    76d8:	54000041 	b.ne	76e0 <fwp_args37+0x10>  // b.any
    76dc:	d65f03c0 	ret
    76e0:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbd0>
    76e4:	91184042 	add	x2, x2, #0x610
    76e8:	f9400001 	ldr	x1, [x0]
    76ec:	f949d843 	ldr	x3, [x2, #5040]
    76f0:	f949ec40 	ldr	x0, [x2, #5080]
    76f4:	cb030021 	sub	x1, x1, x3
    76f8:	eb00403f 	cmp	x1, x0, lsl #16
    76fc:	54ffff02 	b.cs	76dc <fwp_args37+0xc>  // b.hs, b.nlast
    7700:	d350fc20 	lsr	x0, x1, #16
    7704:	f949fc44 	ldr	x4, [x2, #5112]
    7708:	8b000800 	add	x0, x0, x0, lsl #2
    770c:	d37df002 	lsl	x2, x0, #3
    7710:	8b020083 	add	x3, x4, x2
    7714:	f9401060 	ldr	x0, [x3, #32]
    7718:	b4fffe20 	cbz	x0, 76dc <fwp_args37+0xc>
    771c:	38626882 	ldrb	w2, [x4, x2]
    7720:	7100085f 	cmp	w2, #0x2
    7724:	54000320 	b.eq	7788 <fwp_args37+0xb8>  // b.none
    7728:	7100045f 	cmp	w2, #0x1
    772c:	54fffd81 	b.ne	76dc <fwp_args37+0xc>  // b.any
    7730:	29430864 	ldp	w4, w2, [x3, #24]
    7734:	92403c21 	and	x1, x1, #0xffff
    7738:	9b047c21 	mul	x1, x1, x4
    773c:	d360fc21 	lsr	x1, x1, #32
    7740:	eb02003f 	cmp	x1, x2
    7744:	54fffcc2 	b.cs	76dc <fwp_args37+0xc>  // b.hs, b.nlast
    7748:	8b010000 	add	x0, x0, x1
    774c:	39400001 	ldrb	w1, [x0]
    7750:	34fffc61 	cbz	w1, 76dc <fwp_args37+0xc>
    7754:	b00000c2 	adrp	x2, 20000 <__data_start>
    7758:	91014042 	add	x2, x2, #0x50
    775c:	b9412043 	ldr	w3, [x2, #288]
    7760:	350000c3 	cbnz	w3, 7778 <fwp_args37+0xa8>
    7764:	7103f43f 	cmp	w1, #0xfd
    7768:	54000168 	b.hi	7794 <fwp_args37+0xc4>  // b.pmore
    776c:	11000421 	add	w1, w1, #0x1
    7770:	39000001 	strb	w1, [x0]
    7774:	d65f03c0 	ret
    7778:	f940a443 	ldr	x3, [x2, #328]
    777c:	91000463 	add	x3, x3, #0x1
    7780:	f900a443 	str	x3, [x2, #328]
    7784:	17fffff8 	b	7764 <fwp_args37+0x94>
    7788:	72003c3f 	tst	w1, #0xffff
    778c:	54fffe00 	b.eq	774c <fwp_args37+0x7c>  // b.none
    7790:	d65f03c0 	ret
    7794:	17fff408 	b	47b4 <fwp_rc_wide_dup>
    7798:	d503201f 	nop
    779c:	d503201f 	nop

00000000000077a0 <fwp_caps37>:
    77a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    77a4:	910003fd 	mov	x29, sp
    77a8:	f9000bf3 	str	x19, [sp, #16]
    77ac:	aa0003f3 	mov	x19, x0
    77b0:	b9400400 	ldr	w0, [x0, #4]
    77b4:	340004a0 	cbz	w0, 7848 <fwp_caps37+0xa8>
    77b8:	f9400660 	ldr	x0, [x19, #8]
    77bc:	350004e1 	cbnz	w1, 7858 <fwp_caps37+0xb8>
    77c0:	97fffc55 	bl	6914 <fwp_drop4>
    77c4:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbd0>
    77c8:	91184042 	add	x2, x2, #0x610
    77cc:	f949d840 	ldr	x0, [x2, #5040]
    77d0:	f949ec41 	ldr	x1, [x2, #5080]
    77d4:	cb000260 	sub	x0, x19, x0
    77d8:	eb01401f 	cmp	x0, x1, lsl #16
    77dc:	54000382 	b.cs	784c <fwp_caps37+0xac>  // b.hs, b.nlast
    77e0:	d350fc01 	lsr	x1, x0, #16
    77e4:	f949fc44 	ldr	x4, [x2, #5112]
    77e8:	8b010821 	add	x1, x1, x1, lsl #2
    77ec:	d37df021 	lsl	x1, x1, #3
    77f0:	8b010083 	add	x3, x4, x1
    77f4:	f9401062 	ldr	x2, [x3, #32]
    77f8:	b40002a2 	cbz	x2, 784c <fwp_caps37+0xac>
    77fc:	38616881 	ldrb	w1, [x4, x1]
    7800:	7100083f 	cmp	w1, #0x2
    7804:	54000740 	b.eq	78ec <fwp_caps37+0x14c>  // b.none
    7808:	7100043f 	cmp	w1, #0x1
    780c:	54000201 	b.ne	784c <fwp_caps37+0xac>  // b.any
    7810:	29430464 	ldp	w4, w1, [x3, #24]
    7814:	92403c00 	and	x0, x0, #0xffff
    7818:	9b047c00 	mul	x0, x0, x4
    781c:	d360fc00 	lsr	x0, x0, #32
    7820:	eb01001f 	cmp	x0, x1
    7824:	54000142 	b.cs	784c <fwp_caps37+0xac>  // b.hs, b.nlast
    7828:	8b000042 	add	x2, x2, x0
    782c:	39400040 	ldrb	w0, [x2]
    7830:	7100041f 	cmp	w0, #0x1
    7834:	540000c1 	b.ne	784c <fwp_caps37+0xac>  // b.any
    7838:	aa1303e0 	mov	x0, x19
    783c:	f9400bf3 	ldr	x19, [sp, #16]
    7840:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7844:	17fff363 	b	45d0 <fwp_mem_free>
    7848:	34fffbe1 	cbz	w1, 77c4 <fwp_caps37+0x24>
    784c:	f9400bf3 	ldr	x19, [sp, #16]
    7850:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7854:	d65f03c0 	ret
    7858:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbd0>
    785c:	91184042 	add	x2, x2, #0x610
    7860:	f949d843 	ldr	x3, [x2, #5040]
    7864:	f949ec41 	ldr	x1, [x2, #5080]
    7868:	cb030000 	sub	x0, x0, x3
    786c:	eb01401f 	cmp	x0, x1, lsl #16
    7870:	54fffee2 	b.cs	784c <fwp_caps37+0xac>  // b.hs, b.nlast
    7874:	d350fc01 	lsr	x1, x0, #16
    7878:	f949fc44 	ldr	x4, [x2, #5112]
    787c:	8b010821 	add	x1, x1, x1, lsl #2
    7880:	d37df021 	lsl	x1, x1, #3
    7884:	8b010083 	add	x3, x4, x1
    7888:	f9401062 	ldr	x2, [x3, #32]
    788c:	b4fffe02 	cbz	x2, 784c <fwp_caps37+0xac>
    7890:	38616881 	ldrb	w1, [x4, x1]
    7894:	7100083f 	cmp	w1, #0x2
    7898:	54000300 	b.eq	78f8 <fwp_caps37+0x158>  // b.none
    789c:	7100043f 	cmp	w1, #0x1
    78a0:	54fffd61 	b.ne	784c <fwp_caps37+0xac>  // b.any
    78a4:	92403c01 	and	x1, x0, #0xffff
    78a8:	29430064 	ldp	w4, w0, [x3, #24]
    78ac:	9b047c21 	mul	x1, x1, x4
    78b0:	d360fc21 	lsr	x1, x1, #32
    78b4:	eb00003f 	cmp	x1, x0
    78b8:	54fffca2 	b.cs	784c <fwp_caps37+0xac>  // b.hs, b.nlast
    78bc:	8b010042 	add	x2, x2, x1
    78c0:	39400040 	ldrb	w0, [x2]
    78c4:	34fffc40 	cbz	w0, 784c <fwp_caps37+0xac>
    78c8:	b00000c1 	adrp	x1, 20000 <__data_start>
    78cc:	91014021 	add	x1, x1, #0x50
    78d0:	b9412023 	ldr	w3, [x1, #288]
    78d4:	35000183 	cbnz	w3, 7904 <fwp_caps37+0x164>
    78d8:	7103f41f 	cmp	w0, #0xfd
    78dc:	540001c8 	b.hi	7914 <fwp_caps37+0x174>  // b.pmore
    78e0:	11000400 	add	w0, w0, #0x1
    78e4:	39000040 	strb	w0, [x2]
    78e8:	17ffffd9 	b	784c <fwp_caps37+0xac>
    78ec:	72003c1f 	tst	w0, #0xffff
    78f0:	54fffae1 	b.ne	784c <fwp_caps37+0xac>  // b.any
    78f4:	17ffffce 	b	782c <fwp_caps37+0x8c>
    78f8:	72003c1f 	tst	w0, #0xffff
    78fc:	54fffa81 	b.ne	784c <fwp_caps37+0xac>  // b.any
    7900:	17fffff0 	b	78c0 <fwp_caps37+0x120>
    7904:	f940a423 	ldr	x3, [x1, #328]
    7908:	91000463 	add	x3, x3, #0x1
    790c:	f900a423 	str	x3, [x1, #328]
    7910:	17fffff2 	b	78d8 <fwp_caps37+0x138>
    7914:	f9400bf3 	ldr	x19, [sp, #16]
    7918:	aa0203e0 	mov	x0, x2
    791c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7920:	17fff3a5 	b	47b4 <fwp_rc_wide_dup>

0000000000007924 <fwp_write>:
    7924:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7928:	910003fd 	mov	x29, sp
    792c:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc88>
    7930:	f947f484 	ldr	x4, [x4, #4072]
    7934:	a90153f3 	stp	x19, x20, [sp, #16]
    7938:	d10943ff 	sub	sp, sp, #0x250
    793c:	b9400045 	ldr	w5, [x2]
    7940:	aa0003f4 	mov	x20, x0
    7944:	f9400080 	ldr	x0, [x4]
    7948:	f90127e0 	str	x0, [sp, #584]
    794c:	d2800000 	mov	x0, #0x0                   	// #0
    7950:	710064bf 	cmp	w5, #0x19
    7954:	54000408 	b.hi	79d4 <fwp_write+0xb0>  // b.pmore
    7958:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    795c:	aa0103f3 	mov	x19, x1
    7960:	912ac000 	add	x0, x0, #0xab0
    7964:	f9013bf5 	str	x21, [sp, #624]
    7968:	f9013ff6 	str	x22, [sp, #632]
    796c:	f90153fb 	str	x27, [sp, #672]
    7970:	f90157fc 	str	x28, [sp, #680]
    7974:	aa0203fc 	mov	x28, x2
    7978:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    797c:	10000061 	adr	x1, 7988 <fwp_write+0x64>
    7980:	8b20a820 	add	x0, x1, w0, sxth #2
    7984:	d61f0000 	br	x0
    7988:	910123e0 	add	x0, sp, #0x48
    798c:	aa1303e5 	mov	x5, x19
    7990:	f0000004 	adrp	x4, a000 <_IO_stdin_used+0x3c0>
    7994:	aa0003f3 	mov	x19, x0
    7998:	910a2084 	add	x4, x4, #0x288
    799c:	d2804003 	mov	x3, #0x200                 	// #512
    79a0:	aa0303e1 	mov	x1, x3
    79a4:	52800042 	mov	w2, #0x2                   	// #2
    79a8:	97ffeb8a 	bl	27d0 <__snprintf_chk@plt>
    79ac:	aa1303e0 	mov	x0, x19
    79b0:	97ffeb50 	bl	26f0 <strlen@plt>
    79b4:	aa1303e1 	mov	x1, x19
    79b8:	aa0003e2 	mov	x2, x0
    79bc:	aa1403e0 	mov	x0, x20
    79c0:	97ffef24 	bl	3650 <buf_put>
    79c4:	f9413bf5 	ldr	x21, [sp, #624]
    79c8:	f9413ff6 	ldr	x22, [sp, #632]
    79cc:	f94153fb 	ldr	x27, [sp, #672]
    79d0:	f94157fc 	ldr	x28, [sp, #680]
    79d4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    79d8:	f947f400 	ldr	x0, [x0, #4072]
    79dc:	f94127e2 	ldr	x2, [sp, #584]
    79e0:	f9400001 	ldr	x1, [x0]
    79e4:	eb010042 	subs	x2, x2, x1
    79e8:	d2800001 	mov	x1, #0x0                   	// #0
    79ec:	540077a1 	b.ne	88e0 <fwp_write+0xfbc>  // b.any
    79f0:	910943ff 	add	sp, sp, #0x250
    79f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    79f8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    79fc:	d65f03c0 	ret
    7a00:	910123e0 	add	x0, sp, #0x48
    7a04:	aa1303e5 	mov	x5, x19
    7a08:	f0000004 	adrp	x4, a000 <_IO_stdin_used+0x3c0>
    7a0c:	aa0003f3 	mov	x19, x0
    7a10:	910a0084 	add	x4, x4, #0x280
    7a14:	d2804003 	mov	x3, #0x200                 	// #512
    7a18:	17ffffe2 	b	79a0 <fwp_write+0x7c>
    7a1c:	71004cbf 	cmp	w5, #0x13
    7a20:	f0000000 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    7a24:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    7a28:	9109c000 	add	x0, x0, #0x270
    7a2c:	9109e021 	add	x1, x1, #0x278
    7a30:	d2800082 	mov	x2, #0x4                   	// #4
    7a34:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7a38:	aa1403e0 	mov	x0, x20
    7a3c:	f90143f7 	str	x23, [sp, #640]
    7a40:	d2800016 	mov	x22, #0x0                   	// #0
    7a44:	f90147f8 	str	x24, [sp, #648]
    7a48:	97ffef02 	bl	3650 <buf_put>
    7a4c:	f9400260 	ldr	x0, [x19]
    7a50:	f0000017 	adrp	x23, a000 <_IO_stdin_used+0x3c0>
    7a54:	d2800015 	mov	x21, #0x0                   	// #0
    7a58:	910be2f7 	add	x23, x23, #0x2f8
    7a5c:	b4004780 	cbz	x0, 834c <fwp_write+0xa28>
    7a60:	b9400380 	ldr	w0, [x28]
    7a64:	52800003 	mov	w3, #0x0                   	// #0
    7a68:	f9401f82 	ldr	x2, [x28, #56]
    7a6c:	71004c1f 	cmp	w0, #0x13
    7a70:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7a74:	aa1403e0 	mov	x0, x20
    7a78:	8b010e61 	add	x1, x19, x1, lsl #3
    7a7c:	f9400421 	ldr	x1, [x1, #8]
    7a80:	97ffffa9 	bl	7924 <fwp_write>
    7a84:	b9400380 	ldr	w0, [x28]
    7a88:	7100481f 	cmp	w0, #0x12
    7a8c:	54004b20 	b.eq	83f0 <fwp_write+0xacc>  // b.none
    7a90:	f9400260 	ldr	x0, [x19]
    7a94:	910006b5 	add	x21, x21, #0x1
    7a98:	91000ad6 	add	x22, x22, #0x2
    7a9c:	eb15001f 	cmp	x0, x21
    7aa0:	54004569 	b.ls	834c <fwp_write+0xa28>  // b.plast
    7aa4:	aa1703e1 	mov	x1, x23
    7aa8:	aa1403e0 	mov	x0, x20
    7aac:	d2800042 	mov	x2, #0x2                   	// #2
    7ab0:	97ffeee8 	bl	3650 <buf_put>
    7ab4:	17ffffeb 	b	7a60 <fwp_write+0x13c>
    7ab8:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    7abc:	910ac021 	add	x1, x1, #0x2b0
    7ac0:	d28000c2 	mov	x2, #0x6                   	// #6
    7ac4:	aa1403e0 	mov	x0, x20
    7ac8:	91004273 	add	x19, x19, #0x10
    7acc:	97ffeee1 	bl	3650 <buf_put>
    7ad0:	aa1303e0 	mov	x0, x19
    7ad4:	97ffeb07 	bl	26f0 <strlen@plt>
    7ad8:	aa1303e1 	mov	x1, x19
    7adc:	aa0003e2 	mov	x2, x0
    7ae0:	aa1403e0 	mov	x0, x20
    7ae4:	97ffeedb 	bl	3650 <buf_put>
    7ae8:	528007c3 	mov	w3, #0x3e                  	// #62
    7aec:	aa1403e0 	mov	x0, x20
    7af0:	91001fe1 	add	x1, sp, #0x7
    7af4:	d2800022 	mov	x2, #0x1                   	// #1
    7af8:	39001fe3 	strb	w3, [sp, #7]
    7afc:	17ffffb1 	b	79c0 <fwp_write+0x9c>
    7b00:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7b04:	f947f400 	ldr	x0, [x0, #4072]
    7b08:	f94127e2 	ldr	x2, [sp, #584]
    7b0c:	f9400001 	ldr	x1, [x0]
    7b10:	eb010042 	subs	x2, x2, x1
    7b14:	d2800001 	mov	x1, #0x0                   	// #0
    7b18:	540034c1 	b.ne	81b0 <fwp_write+0x88c>  // b.any
    7b1c:	f9413bf5 	ldr	x21, [sp, #624]
    7b20:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    7b24:	f9413ff6 	ldr	x22, [sp, #632]
    7b28:	aa1403e0 	mov	x0, x20
    7b2c:	910a4021 	add	x1, x1, #0x290
    7b30:	d2800142 	mov	x2, #0xa                   	// #10
    7b34:	f94153fb 	ldr	x27, [sp, #672]
    7b38:	f94157fc 	ldr	x28, [sp, #680]
    7b3c:	910943ff 	add	sp, sp, #0x250
    7b40:	a94153f3 	ldp	x19, x20, [sp, #16]
    7b44:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7b48:	17ffeec2 	b	3650 <buf_put>
    7b4c:	f9400456 	ldr	x22, [x2, #8]
    7b50:	f90143f7 	str	x23, [sp, #640]
    7b54:	f90147f8 	str	x24, [sp, #648]
    7b58:	b4005af6 	cbz	x22, 86b4 <fwp_write+0xd90>
    7b5c:	aa1603e0 	mov	x0, x22
    7b60:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    7b64:	910c4021 	add	x1, x1, #0x310
    7b68:	97ffeb5e 	bl	28e0 <strcmp@plt>
    7b6c:	2a0003f5 	mov	w21, w0
    7b70:	34005fc0 	cbz	w0, 8768 <fwp_write+0xe44>
    7b74:	aa1603e0 	mov	x0, x22
    7b78:	97ffeade 	bl	26f0 <strlen@plt>
    7b7c:	aa1603e1 	mov	x1, x22
    7b80:	aa0003e2 	mov	x2, x0
    7b84:	aa1403e0 	mov	x0, x20
    7b88:	97ffeeb2 	bl	3650 <buf_put>
    7b8c:	52800403 	mov	w3, #0x20                  	// #32
    7b90:	91001ff5 	add	x21, sp, #0x7
    7b94:	aa1503e1 	mov	x1, x21
    7b98:	aa1403e0 	mov	x0, x20
    7b9c:	d2800022 	mov	x2, #0x1                   	// #1
    7ba0:	39001fe3 	strb	w3, [sp, #7]
    7ba4:	97ffeeab 	bl	3650 <buf_put>
    7ba8:	52800f63 	mov	w3, #0x7b                  	// #123
    7bac:	aa1403e0 	mov	x0, x20
    7bb0:	aa1503e1 	mov	x1, x21
    7bb4:	d2800022 	mov	x2, #0x1                   	// #1
    7bb8:	39001fe3 	strb	w3, [sp, #7]
    7bbc:	97ffeea5 	bl	3650 <buf_put>
    7bc0:	b9401380 	ldr	w0, [x28, #16]
    7bc4:	52800018 	mov	w24, #0x0                   	// #0
    7bc8:	7100001f 	cmp	w0, #0x0
    7bcc:	54003a8d 	b.le	831c <fwp_write+0x9f8>
    7bd0:	f9014bf9 	str	x25, [sp, #656]
    7bd4:	f0000019 	adrp	x25, a000 <_IO_stdin_used+0x3c0>
    7bd8:	910ce339 	add	x25, x25, #0x338
    7bdc:	f9014ffa 	str	x26, [sp, #664]
    7be0:	f000001a 	adrp	x26, a000 <_IO_stdin_used+0x3c0>
    7be4:	910be35a 	add	x26, x26, #0x2f8
    7be8:	91002276 	add	x22, x19, #0x8
    7bec:	d2800013 	mov	x19, #0x0                   	// #0
    7bf0:	b5003e73 	cbnz	x19, 83bc <fwp_write+0xa98>
    7bf4:	d37df277 	lsl	x23, x19, #3
    7bf8:	34003c98 	cbz	w24, 8388 <fwp_write+0xa64>
    7bfc:	f9401382 	ldr	x2, [x28, #32]
    7c00:	aa1403e0 	mov	x0, x20
    7c04:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7c08:	52800003 	mov	w3, #0x0                   	// #0
    7c0c:	f8776842 	ldr	x2, [x2, x23]
    7c10:	91000673 	add	x19, x19, #0x1
    7c14:	97ffff44 	bl	7924 <fwp_write>
    7c18:	b9401380 	ldr	w0, [x28, #16]
    7c1c:	6b13001f 	cmp	w0, w19
    7c20:	54fffe8c 	b.gt	7bf0 <fwp_write+0x2cc>
    7c24:	f9414bf9 	ldr	x25, [sp, #656]
    7c28:	f9414ffa 	ldr	x26, [sp, #664]
    7c2c:	34003798 	cbz	w24, 831c <fwp_write+0x9f8>
    7c30:	52800523 	mov	w3, #0x29                  	// #41
    7c34:	aa1503e1 	mov	x1, x21
    7c38:	aa1403e0 	mov	x0, x20
    7c3c:	d2800022 	mov	x2, #0x1                   	// #1
    7c40:	39001fe3 	strb	w3, [sp, #7]
    7c44:	97ffee83 	bl	3650 <buf_put>
    7c48:	f9413bf5 	ldr	x21, [sp, #624]
    7c4c:	f9413ff6 	ldr	x22, [sp, #632]
    7c50:	f94143f7 	ldr	x23, [sp, #640]
    7c54:	f94147f8 	ldr	x24, [sp, #648]
    7c58:	f94153fb 	ldr	x27, [sp, #672]
    7c5c:	f94157fc 	ldr	x28, [sp, #680]
    7c60:	17ffff5d 	b	79d4 <fwp_write+0xb0>
    7c64:	b9404855 	ldr	w21, [x2, #72]
    7c68:	aa1403e0 	mov	x0, x20
    7c6c:	93407eb6 	sxtw	x22, w21
    7c70:	91000ac1 	add	x1, x22, #0x2
    7c74:	97ffee43 	bl	3580 <buf_grow>
    7c78:	a9400281 	ldp	x1, x0, [x20]
    7c7c:	528e8603 	mov	w3, #0x7430                	// #29744
    7c80:	78206823 	strh	w3, [x1, x0]
    7c84:	8b000022 	add	x2, x1, x0
    7c88:	710002bf 	cmp	w21, #0x0
    7c8c:	540036ad 	b.le	8360 <fwp_write+0xa3c>
    7c90:	110006a3 	add	w3, w21, #0x1
    7c94:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7c98:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7c9c:	91000449 	add	x9, x2, #0x1
    7ca0:	8b23c043 	add	x3, x2, w3, sxtw
    7ca4:	f28aaac6 	movk	x6, #0x5556
    7ca8:	f2955568 	movk	x8, #0xaaab
    7cac:	1400000d 	b	7ce0 <fwp_write+0x3bc>
    7cb0:	d2800021 	mov	x1, #0x1                   	// #1
    7cb4:	528005a5 	mov	w5, #0x2d                  	// #45
    7cb8:	f100001f 	cmp	x0, #0x0
    7cbc:	9b467e60 	smulh	x0, x19, x6
    7cc0:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7cc4:	381ff465 	strb	w5, [x3], #-1
    7cc8:	cb040000 	sub	x0, x0, x4
    7ccc:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7cd0:	cb020000 	sub	x0, x0, x2
    7cd4:	8b010013 	add	x19, x0, x1
    7cd8:	eb03013f 	cmp	x9, x3
    7cdc:	54003420 	b.eq	8360 <fwp_write+0xa3c>  // b.none
    7ce0:	9b467e60 	smulh	x0, x19, x6
    7ce4:	937ffe64 	asr	x4, x19, #63
    7ce8:	52800605 	mov	w5, #0x30                  	// #48
    7cec:	cb040000 	sub	x0, x0, x4
    7cf0:	8b000400 	add	x0, x0, x0, lsl #1
    7cf4:	cb000260 	sub	x0, x19, x0
    7cf8:	91000c01 	add	x1, x0, #0x3
    7cfc:	9bc87c22 	umulh	x2, x1, x8
    7d00:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7d04:	8b4204e2 	add	x2, x7, x2, lsr #1
    7d08:	eb020021 	subs	x1, x1, x2
    7d0c:	54fffd60 	b.eq	7cb8 <fwp_write+0x394>  // b.none
    7d10:	f100043f 	cmp	x1, #0x1
    7d14:	54fffce1 	b.ne	7cb0 <fwp_write+0x38c>  // b.any
    7d18:	d2800001 	mov	x1, #0x0                   	// #0
    7d1c:	52800565 	mov	w5, #0x2b                  	// #43
    7d20:	17ffffe6 	b	7cb8 <fwp_write+0x394>
    7d24:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7d28:	f947f400 	ldr	x0, [x0, #4072]
    7d2c:	f94127e2 	ldr	x2, [sp, #584]
    7d30:	f9400001 	ldr	x1, [x0]
    7d34:	eb010042 	subs	x2, x2, x1
    7d38:	d2800001 	mov	x1, #0x0                   	// #0
    7d3c:	540023a1 	b.ne	81b0 <fwp_write+0x88c>  // b.any
    7d40:	f9413bf5 	ldr	x21, [sp, #624]
    7d44:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    7d48:	f9413ff6 	ldr	x22, [sp, #632]
    7d4c:	aa1403e0 	mov	x0, x20
    7d50:	910a8021 	add	x1, x1, #0x2a0
    7d54:	d2800102 	mov	x2, #0x8                   	// #8
    7d58:	17ffff77 	b	7b34 <fwp_write+0x210>
    7d5c:	aa1403e0 	mov	x0, x20
    7d60:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    7d64:	d28000c2 	mov	x2, #0x6                   	// #6
    7d68:	910c0021 	add	x1, x1, #0x300
    7d6c:	97ffee39 	bl	3650 <buf_put>
    7d70:	d2800015 	mov	x21, #0x0                   	// #0
    7d74:	f9400263 	ldr	x3, [x19]
    7d78:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7d7c:	54002c40 	b.eq	8304 <fwp_write+0x9e0>  // b.none
    7d80:	f9401f82 	ldr	x2, [x28, #56]
    7d84:	f90143f7 	str	x23, [sp, #640]
    7d88:	f90147f8 	str	x24, [sp, #648]
    7d8c:	d2800857 	mov	x23, #0x42                  	// #66
    7d90:	f9014bf9 	str	x25, [sp, #656]
    7d94:	f0000016 	adrp	x22, a000 <_IO_stdin_used+0x3c0>
    7d98:	f9014ffa 	str	x26, [sp, #664]
    7d9c:	910be2d6 	add	x22, x22, #0x2f8
    7da0:	d2800038 	mov	x24, #0x1                   	// #1
    7da4:	f2a18017 	movk	x23, #0xc00, lsl #16
    7da8:	d2809099 	mov	x25, #0x484                 	// #1156
    7dac:	b4000482 	cbz	x2, 7e3c <fwp_write+0x518>
    7db0:	b9400040 	ldr	w0, [x2]
    7db4:	7100701f 	cmp	w0, #0x1c
    7db8:	540042a0 	b.eq	860c <fwp_write+0xce8>  // b.none
    7dbc:	71006c1f 	cmp	w0, #0x1b
    7dc0:	540003e8 	b.hi	7e3c <fwp_write+0x518>  // b.pmore
    7dc4:	9ac02301 	lsl	x1, x24, x0
    7dc8:	ea17003f 	tst	x1, x23
    7dcc:	54003681 	b.ne	849c <fwp_write+0xb78>  // b.any
    7dd0:	ea19003f 	tst	x1, x25
    7dd4:	54003501 	b.ne	8474 <fwp_write+0xb50>  // b.any
    7dd8:	d2800424 	mov	x4, #0x21                  	// #33
    7ddc:	ea04003f 	tst	x1, x4
    7de0:	540002e0 	b.eq	7e3c <fwp_write+0x518>  // b.none
    7de4:	b7f849a3 	tbnz	x3, #63, 8718 <fwp_write+0xdf4>
    7de8:	91002261 	add	x1, x19, #0x8
    7dec:	8b150021 	add	x1, x1, x21
    7df0:	39400021 	ldrb	w1, [x1]
    7df4:	7100001f 	cmp	w0, #0x0
    7df8:	93401c23 	sxtb	x3, w1
    7dfc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e00:	aa1403e0 	mov	x0, x20
    7e04:	52800003 	mov	w3, #0x0                   	// #0
    7e08:	97fffec7 	bl	7924 <fwp_write>
    7e0c:	910006b5 	add	x21, x21, #0x1
    7e10:	f9400260 	ldr	x0, [x19]
    7e14:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7e18:	eb0002bf 	cmp	x21, x0
    7e1c:	540026c2 	b.cs	82f4 <fwp_write+0x9d0>  // b.hs, b.nlast
    7e20:	d2800042 	mov	x2, #0x2                   	// #2
    7e24:	aa1603e1 	mov	x1, x22
    7e28:	aa1403e0 	mov	x0, x20
    7e2c:	97ffee09 	bl	3650 <buf_put>
    7e30:	f9401f82 	ldr	x2, [x28, #56]
    7e34:	f9400263 	ldr	x3, [x19]
    7e38:	b5fffbc2 	cbnz	x2, 7db0 <fwp_write+0x48c>
    7e3c:	d37df2a0 	lsl	x0, x21, #3
    7e40:	b7f83f03 	tbnz	x3, #63, 8620 <fwp_write+0xcfc>
    7e44:	91002261 	add	x1, x19, #0x8
    7e48:	8b000020 	add	x0, x1, x0
    7e4c:	f9400001 	ldr	x1, [x0]
    7e50:	17ffffec 	b	7e00 <fwp_write+0x4dc>
    7e54:	a9400e62 	ldp	x2, x3, [x19]
    7e58:	b7f83ca3 	tbnz	x3, #63, 85ec <fwp_write+0xcc8>
    7e5c:	910123f5 	add	x21, sp, #0x48
    7e60:	aa1503e0 	mov	x0, x21
    7e64:	97ffebdf 	bl	2de0 <fwp_fmt_u128>
    7e68:	aa1503e0 	mov	x0, x21
    7e6c:	97ffea21 	bl	26f0 <strlen@plt>
    7e70:	aa1503e1 	mov	x1, x21
    7e74:	aa0003e2 	mov	x2, x0
    7e78:	17fffed1 	b	79bc <fwp_write+0x98>
    7e7c:	fd015be8 	str	d8, [sp, #688]
    7e80:	1e270268 	fmov	s8, w19
    7e84:	fd015fe9 	str	d9, [sp, #696]
    7e88:	1e282100 	fcmp	s8, s8
    7e8c:	54004d26 	b.vs	8830 <fwp_write+0xf0c>
    7e90:	1e20c101 	fabs	s1, s8
    7e94:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7e98:	1e270000 	fmov	s0, w0
    7e9c:	1e202020 	fcmp	s1, s0
    7ea0:	54002c0d 	b.le	8420 <fwp_write+0xafc>
    7ea4:	1e202118 	fcmpe	s8, #0.0
    7ea8:	d0000002 	adrp	x2, 9000 <fwp_main_thread+0x6f0>
    7eac:	9136e042 	add	x2, x2, #0xdb8
    7eb0:	910123f5 	add	x21, sp, #0x48
    7eb4:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    7eb8:	91094021 	add	x1, x1, #0x250
    7ebc:	aa1503e0 	mov	x0, x21
    7ec0:	9a81c041 	csel	x1, x2, x1, gt
    7ec4:	97ffeab7 	bl	29a0 <strcpy@plt>
    7ec8:	aa1503e0 	mov	x0, x21
    7ecc:	97ffea09 	bl	26f0 <strlen@plt>
    7ed0:	aa1503e1 	mov	x1, x21
    7ed4:	aa0003e2 	mov	x2, x0
    7ed8:	aa1403e0 	mov	x0, x20
    7edc:	97ffeddd 	bl	3650 <buf_put>
    7ee0:	f9413bf5 	ldr	x21, [sp, #624]
    7ee4:	f9413ff6 	ldr	x22, [sp, #632]
    7ee8:	f94153fb 	ldr	x27, [sp, #672]
    7eec:	f94157fc 	ldr	x28, [sp, #680]
    7ef0:	fd415be8 	ldr	d8, [sp, #688]
    7ef4:	fd415fe9 	ldr	d9, [sp, #696]
    7ef8:	17fffeb7 	b	79d4 <fwp_write+0xb0>
    7efc:	f9400276 	ldr	x22, [x19]
    7f00:	34002e03 	cbz	w3, 84c0 <fwp_write+0xb9c>
    7f04:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7f08:	f947f400 	ldr	x0, [x0, #4072]
    7f0c:	f94127e2 	ldr	x2, [sp, #584]
    7f10:	f9400001 	ldr	x1, [x0]
    7f14:	eb010042 	subs	x2, x2, x1
    7f18:	d2800001 	mov	x1, #0x0                   	// #0
    7f1c:	540014a1 	b.ne	81b0 <fwp_write+0x88c>  // b.any
    7f20:	aa1603e2 	mov	x2, x22
    7f24:	91002261 	add	x1, x19, #0x8
    7f28:	f9413bf5 	ldr	x21, [sp, #624]
    7f2c:	aa1403e0 	mov	x0, x20
    7f30:	f9413ff6 	ldr	x22, [sp, #632]
    7f34:	17ffff00 	b	7b34 <fwp_write+0x210>
    7f38:	fd015be8 	str	d8, [sp, #688]
    7f3c:	9e670268 	fmov	d8, x19
    7f40:	fd015fe9 	str	d9, [sp, #696]
    7f44:	1e682100 	fcmp	d8, d8
    7f48:	54004746 	b.vs	8830 <fwp_write+0xf0c>
    7f4c:	1e60c101 	fabs	d1, d8
    7f50:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7f54:	9e670000 	fmov	d0, x0
    7f58:	910123f5 	add	x21, sp, #0x48
    7f5c:	52800033 	mov	w19, #0x1                   	// #1
    7f60:	1e602020 	fcmp	d1, d0
    7f64:	540001ad 	b.le	7f98 <fwp_write+0x674>
    7f68:	1e602118 	fcmpe	d8, #0.0
    7f6c:	d0000002 	adrp	x2, 9000 <fwp_main_thread+0x6f0>
    7f70:	9136e042 	add	x2, x2, #0xdb8
    7f74:	f0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    7f78:	91094021 	add	x1, x1, #0x250
    7f7c:	aa1503e0 	mov	x0, x21
    7f80:	9a81c041 	csel	x1, x2, x1, gt
    7f84:	97ffea87 	bl	29a0 <strcpy@plt>
    7f88:	17ffffd0 	b	7ec8 <fwp_write+0x5a4>
    7f8c:	11000673 	add	w19, w19, #0x1
    7f90:	71004a7f 	cmp	w19, #0x12
    7f94:	54003860 	b.eq	86a0 <fwp_write+0xd7c>  // b.none
    7f98:	1e604100 	fmov	d0, d8
    7f9c:	2a1303e1 	mov	w1, w19
    7fa0:	aa1503e0 	mov	x0, x21
    7fa4:	97ffee07 	bl	37c0 <fwp_format_g.constprop.0>
    7fa8:	aa1503e0 	mov	x0, x21
    7fac:	d2800001 	mov	x1, #0x0                   	// #0
    7fb0:	97ffe9e4 	bl	2740 <strtod@plt>
    7fb4:	1e602100 	fcmp	d8, d0
    7fb8:	54fffea1 	b.ne	7f8c <fwp_write+0x668>  // b.any
    7fbc:	aa1503e0 	mov	x0, x21
    7fc0:	97ffeddd 	bl	3734 <fwp_finish_float>
    7fc4:	17ffffc1 	b	7ec8 <fwp_write+0x5a4>
    7fc8:	a9400e62 	ldp	x2, x3, [x19]
    7fcc:	910123f3 	add	x19, sp, #0x48
    7fd0:	aa1303e0 	mov	x0, x19
    7fd4:	97ffeb83 	bl	2de0 <fwp_fmt_u128>
    7fd8:	17fffe75 	b	79ac <fwp_write+0x88>
    7fdc:	f90143f7 	str	x23, [sp, #640]
    7fe0:	f90147f8 	str	x24, [sp, #648]
    7fe4:	2a1303f8 	mov	w24, w19
    7fe8:	f9014bf9 	str	x25, [sp, #656]
    7fec:	f9014ffa 	str	x26, [sp, #664]
    7ff0:	f13ffe7f 	cmp	x19, #0xfff
    7ff4:	54000049 	b.ls	7ffc <fwp_write+0x6d8>  // b.plast
    7ff8:	b9400278 	ldr	w24, [x19]
    7ffc:	f9400f80 	ldr	x0, [x28, #24]
    8000:	2a1803f5 	mov	w21, w24
    8004:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8008:	d37ef6b9 	lsl	x25, x21, #2
    800c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8010:	aa1603e0 	mov	x0, x22
    8014:	97ffe9b7 	bl	26f0 <strlen@plt>
    8018:	aa1603e1 	mov	x1, x22
    801c:	aa0003e2 	mov	x2, x0
    8020:	aa1403e0 	mov	x0, x20
    8024:	97ffed8b 	bl	3650 <buf_put>
    8028:	f9401780 	ldr	x0, [x28, #40]
    802c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8030:	7100001f 	cmp	w0, #0x0
    8034:	5400068d 	b.le	8104 <fwp_write+0x7e0>
    8038:	91002276 	add	x22, x19, #0x8
    803c:	91001ff5 	add	x21, sp, #0x7
    8040:	d280001b 	mov	x27, #0x0                   	// #0
    8044:	5280041a 	mov	w26, #0x20                  	// #32
    8048:	f9401b80 	ldr	x0, [x28, #48]
    804c:	aa1503e1 	mov	x1, x21
    8050:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8054:	d2800022 	mov	x2, #0x1                   	// #1
    8058:	f8786803 	ldr	x3, [x0, x24]
    805c:	aa1403e0 	mov	x0, x20
    8060:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8064:	39001ffa 	strb	w26, [sp, #7]
    8068:	97ffed7a 	bl	3650 <buf_put>
    806c:	f13ffeff 	cmp	x23, #0xfff
    8070:	b9400261 	ldr	w1, [x19]
    8074:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8078:	7100383f 	cmp	w1, #0xe
    807c:	54000160 	b.eq	80a8 <fwp_write+0x784>  // b.none
    8080:	7100403f 	cmp	w1, #0x10
    8084:	54001a60 	b.eq	83d0 <fwp_write+0xaac>  // b.none
    8088:	7100283f 	cmp	w1, #0xa
    808c:	54002aa0 	b.eq	85e0 <fwp_write+0xcbc>  // b.none
    8090:	540014ac 	b.gt	8324 <fwp_write+0xa00>
    8094:	71000c3f 	cmp	w1, #0x3
    8098:	540029ac 	b.gt	85cc <fwp_write+0xca8>
    809c:	d37ffee0 	lsr	x0, x23, #63
    80a0:	37f814a1 	tbnz	w1, #31, 8334 <fwp_write+0xa10>
    80a4:	d503201f 	nop
    80a8:	34001460 	cbz	w0, 8334 <fwp_write+0xa10>
    80ac:	52800503 	mov	w3, #0x28                  	// #40
    80b0:	aa1503e1 	mov	x1, x21
    80b4:	aa1403e0 	mov	x0, x20
    80b8:	d2800022 	mov	x2, #0x1                   	// #1
    80bc:	39001fe3 	strb	w3, [sp, #7]
    80c0:	97ffed64 	bl	3650 <buf_put>
    80c4:	aa1303e2 	mov	x2, x19
    80c8:	aa1703e1 	mov	x1, x23
    80cc:	aa1403e0 	mov	x0, x20
    80d0:	52800003 	mov	w3, #0x0                   	// #0
    80d4:	97fffe14 	bl	7924 <fwp_write>
    80d8:	52800523 	mov	w3, #0x29                  	// #41
    80dc:	aa1503e1 	mov	x1, x21
    80e0:	aa1403e0 	mov	x0, x20
    80e4:	d2800022 	mov	x2, #0x1                   	// #1
    80e8:	39001fe3 	strb	w3, [sp, #7]
    80ec:	97ffed59 	bl	3650 <buf_put>
    80f0:	f9401780 	ldr	x0, [x28, #40]
    80f4:	9100077b 	add	x27, x27, #0x1
    80f8:	b8796800 	ldr	w0, [x0, x25]
    80fc:	6b1b001f 	cmp	w0, w27
    8100:	54fffa4c 	b.gt	8048 <fwp_write+0x724>
    8104:	f9413bf5 	ldr	x21, [sp, #624]
    8108:	f9413ff6 	ldr	x22, [sp, #632]
    810c:	f94143f7 	ldr	x23, [sp, #640]
    8110:	f94147f8 	ldr	x24, [sp, #648]
    8114:	f9414bf9 	ldr	x25, [sp, #656]
    8118:	f9414ffa 	ldr	x26, [sp, #664]
    811c:	f94153fb 	ldr	x27, [sp, #672]
    8120:	f94157fc 	ldr	x28, [sp, #680]
    8124:	17fffe2c 	b	79d4 <fwp_write+0xb0>
    8128:	52800783 	mov	w3, #0x3c                  	// #60
    812c:	91001ff3 	add	x19, sp, #0x7
    8130:	aa1303e1 	mov	x1, x19
    8134:	d2800022 	mov	x2, #0x1                   	// #1
    8138:	aa1403e0 	mov	x0, x20
    813c:	39001fe3 	strb	w3, [sp, #7]
    8140:	97ffed44 	bl	3650 <buf_put>
    8144:	f9400795 	ldr	x21, [x28, #8]
    8148:	aa1503e0 	mov	x0, x21
    814c:	97ffe969 	bl	26f0 <strlen@plt>
    8150:	aa1503e1 	mov	x1, x21
    8154:	aa0003e2 	mov	x2, x0
    8158:	aa1403e0 	mov	x0, x20
    815c:	97ffed3d 	bl	3650 <buf_put>
    8160:	528007c3 	mov	w3, #0x3e                  	// #62
    8164:	aa1303e1 	mov	x1, x19
    8168:	aa1403e0 	mov	x0, x20
    816c:	d2800022 	mov	x2, #0x1                   	// #1
    8170:	39001fe3 	strb	w3, [sp, #7]
    8174:	17fffe13 	b	79c0 <fwp_write+0x9c>
    8178:	f100067f 	cmp	x19, #0x1
    817c:	540025a0 	b.eq	8630 <fwp_write+0xd0c>  // b.none
    8180:	b100067f 	cmn	x19, #0x1
    8184:	54002bc0 	b.eq	86fc <fwp_write+0xdd8>  // b.none
    8188:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    818c:	91096021 	add	x1, x1, #0x258
    8190:	d2800022 	mov	x2, #0x1                   	// #1
    8194:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8198:	f947f400 	ldr	x0, [x0, #4072]
    819c:	f94127e4 	ldr	x4, [sp, #584]
    81a0:	f9400003 	ldr	x3, [x0]
    81a4:	eb030084 	subs	x4, x4, x3
    81a8:	d2800003 	mov	x3, #0x0                   	// #0
    81ac:	54ffebe0 	b.eq	7f28 <fwp_write+0x604>  // b.none
    81b0:	f90143f7 	str	x23, [sp, #640]
    81b4:	f90147f8 	str	x24, [sp, #648]
    81b8:	f9014bf9 	str	x25, [sp, #656]
    81bc:	f9014ffa 	str	x26, [sp, #664]
    81c0:	fd015be8 	str	d8, [sp, #688]
    81c4:	fd015fe9 	str	d9, [sp, #696]
    81c8:	97ffe9a6 	bl	2860 <__stack_chk_fail@plt>
    81cc:	52800b63 	mov	w3, #0x5b                  	// #91
    81d0:	91001ff5 	add	x21, sp, #0x7
    81d4:	aa1503e1 	mov	x1, x21
    81d8:	aa1403e0 	mov	x0, x20
    81dc:	d2800022 	mov	x2, #0x1                   	// #1
    81e0:	d0000016 	adrp	x22, a000 <_IO_stdin_used+0x3c0>
    81e4:	910be2d6 	add	x22, x22, #0x2f8
    81e8:	39001fe3 	strb	w3, [sp, #7]
    81ec:	97ffed19 	bl	3650 <buf_put>
    81f0:	b4000273 	cbz	x19, 823c <fwp_write+0x918>
    81f4:	f9400661 	ldr	x1, [x19, #8]
    81f8:	aa1403e0 	mov	x0, x20
    81fc:	f9401f82 	ldr	x2, [x28, #56]
    8200:	52800003 	mov	w3, #0x0                   	// #0
    8204:	97fffdc8 	bl	7924 <fwp_write>
    8208:	f9400a73 	ldr	x19, [x19, #16]
    820c:	b4000193 	cbz	x19, 823c <fwp_write+0x918>
    8210:	aa1603e1 	mov	x1, x22
    8214:	aa1403e0 	mov	x0, x20
    8218:	d2800042 	mov	x2, #0x2                   	// #2
    821c:	97ffed0d 	bl	3650 <buf_put>
    8220:	f9400661 	ldr	x1, [x19, #8]
    8224:	aa1403e0 	mov	x0, x20
    8228:	f9401f82 	ldr	x2, [x28, #56]
    822c:	52800003 	mov	w3, #0x0                   	// #0
    8230:	97fffdbd 	bl	7924 <fwp_write>
    8234:	f9400a73 	ldr	x19, [x19, #16]
    8238:	b5fffed3 	cbnz	x19, 8210 <fwp_write+0x8ec>
    823c:	52800ba3 	mov	w3, #0x5d                  	// #93
    8240:	aa1503e1 	mov	x1, x21
    8244:	aa1403e0 	mov	x0, x20
    8248:	d2800022 	mov	x2, #0x1                   	// #1
    824c:	39001fe3 	strb	w3, [sp, #7]
    8250:	17fffddc 	b	79c0 <fwp_write+0x9c>
    8254:	aa1403e0 	mov	x0, x20
    8258:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    825c:	d28000c2 	mov	x2, #0x6                   	// #6
    8260:	910ba021 	add	x1, x1, #0x2e8
    8264:	97ffecfb 	bl	3650 <buf_put>
    8268:	f9400260 	ldr	x0, [x19]
    826c:	b40004c0 	cbz	x0, 8304 <fwp_write+0x9e0>
    8270:	910123f5 	add	x21, sp, #0x48
    8274:	91002276 	add	x22, x19, #0x8
    8278:	f90143f7 	str	x23, [sp, #640]
    827c:	d2800017 	mov	x23, #0x0                   	// #0
    8280:	f90147f8 	str	x24, [sp, #648]
    8284:	d0000018 	adrp	x24, a000 <_IO_stdin_used+0x3c0>
    8288:	910bc318 	add	x24, x24, #0x2f0
    828c:	f9014bf9 	str	x25, [sp, #656]
    8290:	d0000019 	adrp	x25, a000 <_IO_stdin_used+0x3c0>
    8294:	910be339 	add	x25, x25, #0x2f8
    8298:	f9014ffa 	str	x26, [sp, #664]
    829c:	14000005 	b	82b0 <fwp_write+0x98c>
    82a0:	aa1903e1 	mov	x1, x25
    82a4:	aa1403e0 	mov	x0, x20
    82a8:	d2800042 	mov	x2, #0x2                   	// #2
    82ac:	97ffece9 	bl	3650 <buf_put>
    82b0:	38776ac5 	ldrb	w5, [x22, x23]
    82b4:	d2804003 	mov	x3, #0x200                 	// #512
    82b8:	aa1803e4 	mov	x4, x24
    82bc:	aa0303e1 	mov	x1, x3
    82c0:	52800042 	mov	w2, #0x2                   	// #2
    82c4:	aa1503e0 	mov	x0, x21
    82c8:	910006f7 	add	x23, x23, #0x1
    82cc:	97ffe941 	bl	27d0 <__snprintf_chk@plt>
    82d0:	aa1503e0 	mov	x0, x21
    82d4:	97ffe907 	bl	26f0 <strlen@plt>
    82d8:	aa1503e1 	mov	x1, x21
    82dc:	aa0003e2 	mov	x2, x0
    82e0:	aa1403e0 	mov	x0, x20
    82e4:	97ffecdb 	bl	3650 <buf_put>
    82e8:	f9400260 	ldr	x0, [x19]
    82ec:	eb17001f 	cmp	x0, x23
    82f0:	54fffd88 	b.hi	82a0 <fwp_write+0x97c>  // b.pmore
    82f4:	f94143f7 	ldr	x23, [sp, #640]
    82f8:	f94147f8 	ldr	x24, [sp, #648]
    82fc:	f9414bf9 	ldr	x25, [sp, #656]
    8300:	f9414ffa 	ldr	x26, [sp, #664]
    8304:	52800ba3 	mov	w3, #0x5d                  	// #93
    8308:	aa1403e0 	mov	x0, x20
    830c:	91001fe1 	add	x1, sp, #0x7
    8310:	d2800022 	mov	x2, #0x1                   	// #1
    8314:	39001fe3 	strb	w3, [sp, #7]
    8318:	17fffdaa 	b	79c0 <fwp_write+0x9c>
    831c:	52800fa3 	mov	w3, #0x7d                  	// #125
    8320:	17fffe45 	b	7c34 <fwp_write+0x310>
    8324:	f10002ff 	cmp	x23, #0x0
    8328:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    832c:	71002c3f 	cmp	w1, #0xb
    8330:	54ffebc0 	b.eq	80a8 <fwp_write+0x784>  // b.none
    8334:	aa1303e2 	mov	x2, x19
    8338:	aa1703e1 	mov	x1, x23
    833c:	aa1403e0 	mov	x0, x20
    8340:	52800003 	mov	w3, #0x0                   	// #0
    8344:	97fffd78 	bl	7924 <fwp_write>
    8348:	17ffff6a 	b	80f0 <fwp_write+0x7cc>
    834c:	aa1403e0 	mov	x0, x20
    8350:	91001fe1 	add	x1, sp, #0x7
    8354:	52800fa3 	mov	w3, #0x7d                  	// #125
    8358:	d2800022 	mov	x2, #0x1                   	// #1
    835c:	17fffe39 	b	7c40 <fwp_write+0x31c>
    8360:	a9400281 	ldp	x1, x0, [x20]
    8364:	91000800 	add	x0, x0, #0x2
    8368:	8b160000 	add	x0, x0, x22
    836c:	f9000680 	str	x0, [x20, #8]
    8370:	3820683f 	strb	wzr, [x1, x0]
    8374:	f9413bf5 	ldr	x21, [sp, #624]
    8378:	f9413ff6 	ldr	x22, [sp, #632]
    837c:	f94153fb 	ldr	x27, [sp, #672]
    8380:	f94157fc 	ldr	x28, [sp, #680]
    8384:	17fffd94 	b	79d4 <fwp_write+0xb0>
    8388:	f9400f80 	ldr	x0, [x28, #24]
    838c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8390:	aa1b03e0 	mov	x0, x27
    8394:	97ffe8d7 	bl	26f0 <strlen@plt>
    8398:	aa1b03e1 	mov	x1, x27
    839c:	aa0003e2 	mov	x2, x0
    83a0:	aa1403e0 	mov	x0, x20
    83a4:	97ffecab 	bl	3650 <buf_put>
    83a8:	aa1903e1 	mov	x1, x25
    83ac:	aa1403e0 	mov	x0, x20
    83b0:	d2800062 	mov	x2, #0x3                   	// #3
    83b4:	97ffeca7 	bl	3650 <buf_put>
    83b8:	17fffe11 	b	7bfc <fwp_write+0x2d8>
    83bc:	aa1a03e1 	mov	x1, x26
    83c0:	aa1403e0 	mov	x0, x20
    83c4:	d2800042 	mov	x2, #0x2                   	// #2
    83c8:	97ffeca2 	bl	3650 <buf_put>
    83cc:	17fffe0a 	b	7bf4 <fwp_write+0x2d0>
    83d0:	f9400660 	ldr	x0, [x19, #8]
    83d4:	b4fffb00 	cbz	x0, 8334 <fwp_write+0xa10>
    83d8:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    83dc:	910c4021 	add	x1, x1, #0x310
    83e0:	97ffe940 	bl	28e0 <strcmp@plt>
    83e4:	7100001f 	cmp	w0, #0x0
    83e8:	1a9f07e0 	cset	w0, ne	// ne = any
    83ec:	17ffff2f 	b	80a8 <fwp_write+0x784>
    83f0:	aa1403e0 	mov	x0, x20
    83f4:	d2800042 	mov	x2, #0x2                   	// #2
    83f8:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    83fc:	910c2021 	add	x1, x1, #0x308
    8400:	97ffec94 	bl	3650 <buf_put>
    8404:	91004261 	add	x1, x19, #0x10
    8408:	aa1403e0 	mov	x0, x20
    840c:	f9402382 	ldr	x2, [x28, #64]
    8410:	52800003 	mov	w3, #0x0                   	// #0
    8414:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8418:	97fffd43 	bl	7924 <fwp_write>
    841c:	17fffd9d 	b	7a90 <fwp_write+0x16c>
    8420:	1e22c109 	fcvt	d9, s8
    8424:	910123f5 	add	x21, sp, #0x48
    8428:	52800033 	mov	w19, #0x1                   	// #1
    842c:	d503201f 	nop
    8430:	1e604120 	fmov	d0, d9
    8434:	2a1303e1 	mov	w1, w19
    8438:	aa1503e0 	mov	x0, x21
    843c:	97ffece1 	bl	37c0 <fwp_format_g.constprop.0>
    8440:	aa1503e0 	mov	x0, x21
    8444:	d2800001 	mov	x1, #0x0                   	// #0
    8448:	97ffe932 	bl	2910 <strtof@plt>
    844c:	1e202100 	fcmp	s8, s0
    8450:	54ffdb60 	b.eq	7fbc <fwp_write+0x698>  // b.none
    8454:	11000673 	add	w19, w19, #0x1
    8458:	71002a7f 	cmp	w19, #0xa
    845c:	54fffea1 	b.ne	8430 <fwp_write+0xb0c>  // b.any
    8460:	1e604120 	fmov	d0, d9
    8464:	aa1503e0 	mov	x0, x21
    8468:	52800121 	mov	w1, #0x9                   	// #9
    846c:	97ffecd5 	bl	37c0 <fwp_format_g.constprop.0>
    8470:	17fffed3 	b	7fbc <fwp_write+0x698>
    8474:	d37ef6a1 	lsl	x1, x21, #2
    8478:	b7f81563 	tbnz	x3, #63, 8724 <fwp_write+0xe00>
    847c:	91002263 	add	x3, x19, #0x8
    8480:	8b010061 	add	x1, x3, x1
    8484:	b9400023 	ldr	w3, [x1]
    8488:	7100081f 	cmp	w0, #0x2
    848c:	2a0303e1 	mov	w1, w3
    8490:	93407c63 	sxtw	x3, w3
    8494:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8498:	17fffe5a 	b	7e00 <fwp_write+0x4dc>
    849c:	d37ffaa1 	lsl	x1, x21, #1
    84a0:	b7f81363 	tbnz	x3, #63, 870c <fwp_write+0xde8>
    84a4:	91002263 	add	x3, x19, #0x8
    84a8:	8b010061 	add	x1, x3, x1
    84ac:	79400021 	ldrh	w1, [x1]
    84b0:	7100041f 	cmp	w0, #0x1
    84b4:	93403c23 	sxth	x3, w1
    84b8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    84bc:	17fffe51 	b	7e00 <fwp_write+0x4dc>
    84c0:	52800443 	mov	w3, #0x22                  	// #34
    84c4:	91001ff5 	add	x21, sp, #0x7
    84c8:	91002273 	add	x19, x19, #0x8
    84cc:	aa1503e1 	mov	x1, x21
    84d0:	aa1403e0 	mov	x0, x20
    84d4:	d2800022 	mov	x2, #0x1                   	// #1
    84d8:	39001fe3 	strb	w3, [sp, #7]
    84dc:	f90143f7 	str	x23, [sp, #640]
    84e0:	8b160277 	add	x23, x19, x22
    84e4:	f90147f8 	str	x24, [sp, #648]
    84e8:	97ffec5a 	bl	3650 <buf_put>
    84ec:	b4000696 	cbz	x22, 85bc <fwp_write+0xc98>
    84f0:	d0000018 	adrp	x24, a000 <_IO_stdin_used+0x3c0>
    84f4:	910ae318 	add	x24, x24, #0x2b8
    84f8:	f9014bf9 	str	x25, [sp, #656]
    84fc:	d0000019 	adrp	x25, a000 <_IO_stdin_used+0x3c0>
    8500:	910b6339 	add	x25, x25, #0x2d8
    8504:	f9014ffa 	str	x26, [sp, #664]
    8508:	1400000d 	b	853c <fwp_write+0xc18>
    850c:	710024bf 	cmp	w5, #0x9
    8510:	54000460 	b.eq	859c <fwp_write+0xc78>  // b.none
    8514:	710028bf 	cmp	w5, #0xa
    8518:	54000a61 	b.ne	8664 <fwp_write+0xd40>  // b.any
    851c:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    8520:	aa1403e0 	mov	x0, x20
    8524:	910b2021 	add	x1, x1, #0x2c8
    8528:	d2800042 	mov	x2, #0x2                   	// #2
    852c:	97ffec49 	bl	3650 <buf_put>
    8530:	91000673 	add	x19, x19, #0x1
    8534:	eb17027f 	cmp	x19, x23
    8538:	540003e0 	b.eq	85b4 <fwp_write+0xc90>  // b.none
    853c:	39400265 	ldrb	w5, [x19]
    8540:	710034bf 	cmp	w5, #0xd
    8544:	54000180 	b.eq	8574 <fwp_write+0xc50>  // b.none
    8548:	54fffe29 	b.ls	850c <fwp_write+0xbe8>  // b.plast
    854c:	710088bf 	cmp	w5, #0x22
    8550:	540001c0 	b.eq	8588 <fwp_write+0xc64>  // b.none
    8554:	710170bf 	cmp	w5, #0x5c
    8558:	54000741 	b.ne	8640 <fwp_write+0xd1c>  // b.any
    855c:	aa1403e0 	mov	x0, x20
    8560:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    8564:	d2800042 	mov	x2, #0x2                   	// #2
    8568:	910b0021 	add	x1, x1, #0x2c0
    856c:	97ffec39 	bl	3650 <buf_put>
    8570:	17fffff0 	b	8530 <fwp_write+0xc0c>
    8574:	aa1903e1 	mov	x1, x25
    8578:	aa1403e0 	mov	x0, x20
    857c:	d2800042 	mov	x2, #0x2                   	// #2
    8580:	97ffec34 	bl	3650 <buf_put>
    8584:	17ffffeb 	b	8530 <fwp_write+0xc0c>
    8588:	aa1803e1 	mov	x1, x24
    858c:	aa1403e0 	mov	x0, x20
    8590:	d2800042 	mov	x2, #0x2                   	// #2
    8594:	97ffec2f 	bl	3650 <buf_put>
    8598:	17ffffe6 	b	8530 <fwp_write+0xc0c>
    859c:	aa1403e0 	mov	x0, x20
    85a0:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    85a4:	d2800042 	mov	x2, #0x2                   	// #2
    85a8:	910b4021 	add	x1, x1, #0x2d0
    85ac:	97ffec29 	bl	3650 <buf_put>
    85b0:	17ffffe0 	b	8530 <fwp_write+0xc0c>
    85b4:	f9414bf9 	ldr	x25, [sp, #656]
    85b8:	f9414ffa 	ldr	x26, [sp, #664]
    85bc:	aa1503e1 	mov	x1, x21
    85c0:	aa1403e0 	mov	x0, x20
    85c4:	52800443 	mov	w3, #0x22                  	// #34
    85c8:	17fffd9d 	b	7c3c <fwp_write+0x318>
    85cc:	7100103f 	cmp	w1, #0x4
    85d0:	54ffeb21 	b.ne	8334 <fwp_write+0xa10>  // b.any
    85d4:	f94006e0 	ldr	x0, [x23, #8]
    85d8:	d37ffc00 	lsr	x0, x0, #63
    85dc:	17fffeb3 	b	80a8 <fwp_write+0x784>
    85e0:	710002ff 	cmp	w23, #0x0
    85e4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    85e8:	17fffeb0 	b	80a8 <fwp_write+0x784>
    85ec:	528005a1 	mov	w1, #0x2d                  	// #45
    85f0:	eb0203e2 	negs	x2, x2
    85f4:	da0303e3 	ngc	x3, x3
    85f8:	910127e0 	add	x0, sp, #0x49
    85fc:	910123f5 	add	x21, sp, #0x48
    8600:	390123e1 	strb	w1, [sp, #72]
    8604:	97ffe9f7 	bl	2de0 <fwp_fmt_u128>
    8608:	17fffe18 	b	7e68 <fwp_write+0x544>
    860c:	d37ceea1 	lsl	x1, x21, #4
    8610:	b7f810a3 	tbnz	x3, #63, 8824 <fwp_write+0xf00>
    8614:	91002260 	add	x0, x19, #0x8
    8618:	8b010001 	add	x1, x0, x1
    861c:	17fffdf9 	b	7e00 <fwp_write+0x4dc>
    8620:	f9400a61 	ldr	x1, [x19, #16]
    8624:	8b010000 	add	x0, x0, x1
    8628:	f9400001 	ldr	x1, [x0]
    862c:	17fffdf5 	b	7e00 <fwp_write+0x4dc>
    8630:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    8634:	d2800042 	mov	x2, #0x2                   	// #2
    8638:	91098021 	add	x1, x1, #0x260
    863c:	17fffed6 	b	8194 <fwp_write+0x870>
    8640:	7101fcbf 	cmp	w5, #0x7f
    8644:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8648:	540000e9 	b.ls	8664 <fwp_write+0xd40>  // b.plast
    864c:	aa1503e1 	mov	x1, x21
    8650:	aa1403e0 	mov	x0, x20
    8654:	d2800022 	mov	x2, #0x1                   	// #1
    8658:	39001fe5 	strb	w5, [sp, #7]
    865c:	97ffebfd 	bl	3650 <buf_put>
    8660:	17ffffb4 	b	8530 <fwp_write+0xc0c>
    8664:	d2800203 	mov	x3, #0x10                  	// #16
    8668:	d0000004 	adrp	x4, a000 <_IO_stdin_used+0x3c0>
    866c:	aa0303e1 	mov	x1, x3
    8670:	910b8084 	add	x4, x4, #0x2e0
    8674:	910123f6 	add	x22, sp, #0x48
    8678:	52800042 	mov	w2, #0x2                   	// #2
    867c:	aa1603e0 	mov	x0, x22
    8680:	97ffe854 	bl	27d0 <__snprintf_chk@plt>
    8684:	aa1603e0 	mov	x0, x22
    8688:	97ffe81a 	bl	26f0 <strlen@plt>
    868c:	aa1603e1 	mov	x1, x22
    8690:	aa0003e2 	mov	x2, x0
    8694:	aa1403e0 	mov	x0, x20
    8698:	97ffebee 	bl	3650 <buf_put>
    869c:	17ffffa5 	b	8530 <fwp_write+0xc0c>
    86a0:	1e604100 	fmov	d0, d8
    86a4:	aa1503e0 	mov	x0, x21
    86a8:	52800221 	mov	w1, #0x11                  	// #17
    86ac:	97ffec45 	bl	37c0 <fwp_format_g.constprop.0>
    86b0:	17fffe43 	b	7fbc <fwp_write+0x698>
    86b4:	b9401040 	ldr	w0, [x2, #16]
    86b8:	350003c0 	cbnz	w0, 8730 <fwp_write+0xe0c>
    86bc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    86c0:	f947f400 	ldr	x0, [x0, #4072]
    86c4:	f94127e2 	ldr	x2, [sp, #584]
    86c8:	f9400001 	ldr	x1, [x0]
    86cc:	eb010042 	subs	x2, x2, x1
    86d0:	d2800001 	mov	x1, #0x0                   	// #0
    86d4:	54ffd721 	b.ne	81b8 <fwp_write+0x894>  // b.any
    86d8:	f9413bf5 	ldr	x21, [sp, #624]
    86dc:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    86e0:	f9413ff6 	ldr	x22, [sp, #632]
    86e4:	aa1403e0 	mov	x0, x20
    86e8:	f94143f7 	ldr	x23, [sp, #640]
    86ec:	910cc021 	add	x1, x1, #0x330
    86f0:	f94147f8 	ldr	x24, [sp, #648]
    86f4:	d2800042 	mov	x2, #0x2                   	// #2
    86f8:	17fffd0f 	b	7b34 <fwp_write+0x210>
    86fc:	d0000001 	adrp	x1, a000 <_IO_stdin_used+0x3c0>
    8700:	d2800042 	mov	x2, #0x2                   	// #2
    8704:	9109a021 	add	x1, x1, #0x268
    8708:	17fffea3 	b	8194 <fwp_write+0x870>
    870c:	f9400a63 	ldr	x3, [x19, #16]
    8710:	8b030021 	add	x1, x1, x3
    8714:	17ffff66 	b	84ac <fwp_write+0xb88>
    8718:	f9400a61 	ldr	x1, [x19, #16]
    871c:	8b0102a1 	add	x1, x21, x1
    8720:	17fffdb4 	b	7df0 <fwp_write+0x4cc>
    8724:	f9400a63 	ldr	x3, [x19, #16]
    8728:	8b030021 	add	x1, x1, x3
    872c:	17ffff56 	b	8484 <fwp_write+0xb60>
    8730:	b9404840 	ldr	w0, [x2, #72]
    8734:	91001ff5 	add	x21, sp, #0x7
    8738:	34ffa380 	cbz	w0, 7ba8 <fwp_write+0x284>
    873c:	52800503 	mov	w3, #0x28                  	// #40
    8740:	aa1403e0 	mov	x0, x20
    8744:	aa1503e1 	mov	x1, x21
    8748:	d2800022 	mov	x2, #0x1                   	// #1
    874c:	39001fe3 	strb	w3, [sp, #7]
    8750:	97ffebc0 	bl	3650 <buf_put>
    8754:	b9401380 	ldr	w0, [x28, #16]
    8758:	52800038 	mov	w24, #0x1                   	// #1
    875c:	7100001f 	cmp	w0, #0x0
    8760:	54ffa38c 	b.gt	7bd0 <fwp_write+0x2ac>
    8764:	17fffd33 	b	7c30 <fwp_write+0x30c>
    8768:	f9014bf9 	str	x25, [sp, #656]
    876c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x12128>
    8770:	f9014ffa 	str	x26, [sp, #664]
    8774:	f9400676 	ldr	x22, [x19, #8]
    8778:	910ae333 	add	x19, x25, #0x2b8
    877c:	91002273 	add	x19, x19, #0x8
    8780:	937ffed8 	asr	x24, x22, #63
    8784:	aa1802c0 	orr	x0, x22, x24
    8788:	b5000320 	cbnz	x0, 87ec <fwp_write+0xec8>
    878c:	110006b5 	add	w21, w21, #0x1
    8790:	710016bf 	cmp	w21, #0x5
    8794:	54ffffc1 	b.ne	878c <fwp_write+0xe68>  // b.any
    8798:	b7f80578 	tbnz	x24, #63, 8844 <fwp_write+0xf20>
    879c:	910023f3 	add	x19, sp, #0x8
    87a0:	aa1603e2 	mov	x2, x22
    87a4:	aa1303e0 	mov	x0, x19
    87a8:	d2800003 	mov	x3, #0x0                   	// #0
    87ac:	97ffe98d 	bl	2de0 <fwp_fmt_u128>
    87b0:	910123f5 	add	x21, sp, #0x48
    87b4:	d0000003 	adrp	x3, a000 <_IO_stdin_used+0x3c0>
    87b8:	aa1303e4 	mov	x4, x19
    87bc:	aa1503e0 	mov	x0, x21
    87c0:	910ca063 	add	x3, x3, #0x328
    87c4:	d2804002 	mov	x2, #0x200                 	// #512
    87c8:	52800041 	mov	w1, #0x2                   	// #2
    87cc:	97ffe7cd 	bl	2700 <__sprintf_chk@plt>
    87d0:	aa1503e0 	mov	x0, x21
    87d4:	97ffe7c7 	bl	26f0 <strlen@plt>
    87d8:	aa1503e1 	mov	x1, x21
    87dc:	aa0003e2 	mov	x2, x0
    87e0:	aa1403e0 	mov	x0, x20
    87e4:	97ffeb9b 	bl	3650 <buf_put>
    87e8:	17fffe47 	b	8104 <fwp_write+0x7e0>
    87ec:	f9400277 	ldr	x23, [x19]
    87f0:	aa1603e0 	mov	x0, x22
    87f4:	aa1803e1 	mov	x1, x24
    87f8:	aa1703e2 	mov	x2, x23
    87fc:	937ffefa 	asr	x26, x23, #63
    8800:	aa1a03e3 	mov	x3, x26
    8804:	94000427 	bl	98a0 <__modti3>
    8808:	aa010000 	orr	x0, x0, x1
    880c:	b40002c0 	cbz	x0, 8864 <fwp_write+0xf40>
    8810:	110006b5 	add	w21, w21, #0x1
    8814:	91004273 	add	x19, x19, #0x10
    8818:	710016bf 	cmp	w21, #0x5
    881c:	54fffe81 	b.ne	87ec <fwp_write+0xec8>  // b.any
    8820:	17ffffde 	b	8798 <fwp_write+0xe74>
    8824:	f9400a60 	ldr	x0, [x19, #16]
    8828:	8b000021 	add	x1, x1, x0
    882c:	17fffd75 	b	7e00 <fwp_write+0x4dc>
    8830:	528c29c0 	mov	w0, #0x614e                	// #24910
    8834:	910123f5 	add	x21, sp, #0x48
    8838:	72a009c0 	movk	w0, #0x4e, lsl #16
    883c:	b9004be0 	str	w0, [sp, #72]
    8840:	17fffda2 	b	7ec8 <fwp_write+0x5a4>
    8844:	528005a1 	mov	w1, #0x2d                  	// #45
    8848:	eb1603e2 	negs	x2, x22
    884c:	da1803e3 	ngc	x3, x24
    8850:	910027e0 	add	x0, sp, #0x9
    8854:	910023f3 	add	x19, sp, #0x8
    8858:	390023e1 	strb	w1, [sp, #8]
    885c:	97ffe961 	bl	2de0 <fwp_fmt_u128>
    8860:	17ffffd4 	b	87b0 <fwp_write+0xe8c>
    8864:	aa1703e2 	mov	x2, x23
    8868:	aa1a03e3 	mov	x3, x26
    886c:	aa1603e0 	mov	x0, x22
    8870:	aa1803e1 	mov	x1, x24
    8874:	9400032b 	bl	9520 <__divti3>
    8878:	aa0003e2 	mov	x2, x0
    887c:	aa0103e3 	mov	x3, x1
    8880:	b7f80201 	tbnz	x1, #63, 88c0 <fwp_write+0xf9c>
    8884:	910023f3 	add	x19, sp, #0x8
    8888:	aa1303e0 	mov	x0, x19
    888c:	97ffe955 	bl	2de0 <fwp_fmt_u128>
    8890:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8894:	910ae339 	add	x25, x25, #0x2b8
    8898:	910123f5 	add	x21, sp, #0x48
    889c:	aa1303e4 	mov	x4, x19
    88a0:	aa1503e0 	mov	x0, x21
    88a4:	d0000003 	adrp	x3, a000 <_IO_stdin_used+0x3c0>
    88a8:	f8616b25 	ldr	x5, [x25, x1]
    88ac:	910c8063 	add	x3, x3, #0x320
    88b0:	d2804002 	mov	x2, #0x200                 	// #512
    88b4:	52800041 	mov	w1, #0x2                   	// #2
    88b8:	97ffe792 	bl	2700 <__sprintf_chk@plt>
    88bc:	17ffffc5 	b	87d0 <fwp_write+0xeac>
    88c0:	528005a4 	mov	w4, #0x2d                  	// #45
    88c4:	eb0003e2 	negs	x2, x0
    88c8:	da0103e3 	ngc	x3, x1
    88cc:	910027e0 	add	x0, sp, #0x9
    88d0:	910023f3 	add	x19, sp, #0x8
    88d4:	390023e4 	strb	w4, [sp, #8]
    88d8:	97ffe942 	bl	2de0 <fwp_fmt_u128>
    88dc:	17ffffed 	b	8890 <fwp_write+0xf6c>
    88e0:	f9013bf5 	str	x21, [sp, #624]
    88e4:	f9013ff6 	str	x22, [sp, #632]
    88e8:	f90143f7 	str	x23, [sp, #640]
    88ec:	f90147f8 	str	x24, [sp, #648]
    88f0:	f9014bf9 	str	x25, [sp, #656]
    88f4:	f9014ffa 	str	x26, [sp, #664]
    88f8:	f90153fb 	str	x27, [sp, #672]
    88fc:	f90157fc 	str	x28, [sp, #680]
    8900:	fd015be8 	str	d8, [sp, #688]
    8904:	fd015fe9 	str	d9, [sp, #696]
    8908:	97ffe7d6 	bl	2860 <__stack_chk_fail@plt>
    890c:	d503201f 	nop

0000000000008910 <fwp_main_thread>:
    8910:	d10603ff 	sub	sp, sp, #0x180
    8914:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8918:	f947f400 	ldr	x0, [x0, #4072]
    891c:	a9127bfd 	stp	x29, x30, [sp, #288]
    8920:	910483fd 	add	x29, sp, #0x120
    8924:	a91353f3 	stp	x19, x20, [sp, #304]
    8928:	b0000393 	adrp	x19, 79000 <fwp_root_context+0xbd0>
    892c:	91184261 	add	x1, x19, #0x610
    8930:	a9145bf5 	stp	x21, x22, [sp, #320]
    8934:	a91563f7 	stp	x23, x24, [sp, #336]
    8938:	b953a421 	ldr	w1, [x1, #5028]
    893c:	f9400002 	ldr	x2, [x0]
    8940:	f9008fe2 	str	x2, [sp, #280]
    8944:	d2800002 	mov	x2, #0x0                   	// #0
    8948:	34000f81 	cbz	w1, 8b38 <fwp_main_thread+0x228>
    894c:	91184260 	add	x0, x19, #0x610
    8950:	b953a800 	ldr	w0, [x0, #5032]
    8954:	35000ea0 	cbnz	w0, 8b28 <fwp_main_thread+0x218>
    8958:	900000d5 	adrp	x21, 20000 <__data_start>
    895c:	900000c2 	adrp	x2, 20000 <__data_start>
    8960:	910142b4 	add	x20, x21, #0x50
    8964:	9110c042 	add	x2, x2, #0x430
    8968:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    896c:	d2a00024 	mov	x4, #0x10000               	// #65536
    8970:	910103f7 	add	x23, sp, #0x40
    8974:	9100a3f6 	add	x22, sp, #0x28
    8978:	aa1703e0 	mov	x0, x23
    897c:	d2800001 	mov	x1, #0x0                   	// #0
    8980:	f90023e2 	str	x2, [sp, #64]
    8984:	b9004bff 	str	wzr, [sp, #72]
    8988:	f9002be4 	str	x4, [sp, #80]
    898c:	a90a0e96 	stp	x22, x3, [x20, #160]
    8990:	97ffe750 	bl	26d0 <sigaltstack@plt>
    8994:	35000220 	cbnz	w0, 89d8 <fwp_main_thread+0xc8>
    8998:	4f000400 	movi	v0.4s, #0x0
    899c:	910223e0 	add	x0, sp, #0x88
    89a0:	f0ffffc1 	adrp	x1, 3000 <fwp_tape_unlink_scope+0x2c>
    89a4:	9101c021 	add	x1, x1, #0x70
    89a8:	f90043e1 	str	x1, [sp, #128]
    89ac:	52800082 	mov	w2, #0x4                   	// #4
    89b0:	72a10002 	movk	w2, #0x800, lsl #16
    89b4:	910203f8 	add	x24, sp, #0x80
    89b8:	3d802000 	str	q0, [x0, #128]
    89bc:	b9010be2 	str	w2, [sp, #264]
    89c0:	ad000000 	stp	q0, q0, [x0]
    89c4:	ad010000 	stp	q0, q0, [x0, #32]
    89c8:	ad020000 	stp	q0, q0, [x0, #64]
    89cc:	ad030000 	stp	q0, q0, [x0, #96]
    89d0:	97ffe794 	bl	2820 <sigemptyset@plt>
    89d4:	340000c0 	cbz	w0, 89ec <fwp_main_thread+0xdc>
    89d8:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    89dc:	910d0000 	add	x0, x0, #0x340
    89e0:	a9166bf9 	stp	x25, x26, [sp, #352]
    89e4:	a91773fb 	stp	x27, x28, [sp, #368]
    89e8:	97ffee3f 	bl	42e4 <fwp_trap>
    89ec:	aa1803e1 	mov	x1, x24
    89f0:	d2800002 	mov	x2, #0x0                   	// #0
    89f4:	52800160 	mov	w0, #0xb                   	// #11
    89f8:	97ffe7a2 	bl	2880 <sigaction@plt>
    89fc:	35fffee0 	cbnz	w0, 89d8 <fwp_main_thread+0xc8>
    8a00:	aa1803e1 	mov	x1, x24
    8a04:	d2800002 	mov	x2, #0x0                   	// #0
    8a08:	528000e0 	mov	w0, #0x7                   	// #7
    8a0c:	97ffe79d 	bl	2880 <sigaction@plt>
    8a10:	35fffe40 	cbnz	w0, 89d8 <fwp_main_thread+0xc8>
    8a14:	a9166bf9 	stp	x25, x26, [sp, #352]
    8a18:	9118427a 	add	x26, x19, #0x610
    8a1c:	52800039 	mov	w25, #0x1                   	// #1
    8a20:	f0ffffc0 	adrp	x0, 3000 <fwp_tape_unlink_scope+0x2c>
    8a24:	910dc000 	add	x0, x0, #0x370
    8a28:	fd4a1340 	ldr	d0, [x26, #5152]
    8a2c:	b9012299 	str	w25, [x20, #288]
    8a30:	7e61d800 	ucvtf	d0, d0
    8a34:	fd009e80 	str	d0, [x20, #312]
    8a38:	94000476 	bl	9c10 <atexit>
    8a3c:	35005120 	cbnz	w0, 9460 <fwp_main_thread+0xb50>
    8a40:	b943b680 	ldr	w0, [x20, #948]
    8a44:	340007e0 	cbz	w0, 8b40 <fwp_main_thread+0x230>
    8a48:	910142ba 	add	x26, x21, #0x50
    8a4c:	f9404f56 	ldr	x22, [x26, #152]
    8a50:	b40013f6 	cbz	x22, 8ccc <fwp_main_thread+0x3bc>
    8a54:	910102d7 	add	x23, x22, #0x40
    8a58:	39414ad9 	ldrb	w25, [x22, #82]
    8a5c:	52800038 	mov	w24, #0x1                   	// #1
    8a60:	39014ad8 	strb	w24, [x22, #82]
    8a64:	d503201f 	nop
    8a68:	f94016c0 	ldr	x0, [x22, #40]
    8a6c:	b40012e0 	cbz	x0, 8cc8 <fwp_main_thread+0x3b8>
    8a70:	f94032c1 	ldr	x1, [x22, #96]
    8a74:	394146c0 	ldrb	w0, [x22, #81]
    8a78:	b4000f01 	cbz	x1, 8c58 <fwp_main_thread+0x348>
    8a7c:	36000dc0 	tbz	w0, #0, 8c34 <fwp_main_thread+0x324>
    8a80:	f9404f54 	ldr	x20, [x26, #152]
    8a84:	f94022c0 	ldr	x0, [x22, #64]
    8a88:	39414a81 	ldrb	w1, [x20, #82]
    8a8c:	370010e1 	tbnz	w1, #0, 8ca8 <fwp_main_thread+0x398>
    8a90:	f9403281 	ldr	x1, [x20, #96]
    8a94:	a911fe97 	stp	x23, xzr, [x20, #280]
    8a98:	f9009680 	str	x0, [x20, #296]
    8a9c:	b4000040 	cbz	x0, 8aa4 <fwp_main_thread+0x194>
    8aa0:	f9009014 	str	x20, [x0, #288]
    8aa4:	f90022d4 	str	x20, [x22, #64]
    8aa8:	b4000101 	cbz	x1, 8ac8 <fwp_main_thread+0x1b8>
    8aac:	f9408f40 	ldr	x0, [x26, #280]
    8ab0:	39015698 	strb	w24, [x20, #85]
    8ab4:	f9003681 	str	x1, [x20, #104]
    8ab8:	a910829f 	stp	xzr, x0, [x20, #264]
    8abc:	b4000040 	cbz	x0, 8ac4 <fwp_main_thread+0x1b4>
    8ac0:	f9008414 	str	x20, [x0, #264]
    8ac4:	f9008f54 	str	x20, [x26, #280]
    8ac8:	39015a9f 	strb	wzr, [x20, #86]
    8acc:	97fff8f5 	bl	6ea0 <fwp_block>
    8ad0:	f9408e82 	ldr	x2, [x20, #280]
    8ad4:	b4000142 	cbz	x2, 8afc <fwp_main_thread+0x1ec>
    8ad8:	a9520281 	ldp	x1, x0, [x20, #288]
    8adc:	b4000f21 	cbz	x1, 8cc0 <fwp_main_thread+0x3b0>
    8ae0:	f9009420 	str	x0, [x1, #296]
    8ae4:	f9409680 	ldr	x0, [x20, #296]
    8ae8:	b4000040 	cbz	x0, 8af0 <fwp_main_thread+0x1e0>
    8aec:	f9009001 	str	x1, [x0, #288]
    8af0:	91080280 	add	x0, x20, #0x200
    8af4:	f900969f 	str	xzr, [x20, #296]
    8af8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8afc:	39415680 	ldrb	w0, [x20, #85]
    8b00:	3607fb40 	tbz	w0, #0, 8a68 <fwp_main_thread+0x158>
    8b04:	a9508281 	ldp	x1, x0, [x20, #264]
    8b08:	b4002141 	cbz	x1, 8f30 <fwp_main_thread+0x620>
    8b0c:	f9008820 	str	x0, [x1, #272]
    8b10:	b4000040 	cbz	x0, 8b18 <fwp_main_thread+0x208>
    8b14:	f9008401 	str	x1, [x0, #264]
    8b18:	91080280 	add	x0, x20, #0x200
    8b1c:	3901569f 	strb	wzr, [x20, #85]
    8b20:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8b24:	17ffffd1 	b	8a68 <fwp_main_thread+0x158>
    8b28:	f0ffffc0 	adrp	x0, 3000 <fwp_tape_unlink_scope+0x2c>
    8b2c:	912f1000 	add	x0, x0, #0xbc4
    8b30:	94000438 	bl	9c10 <atexit>
    8b34:	17ffff89 	b	8958 <fwp_main_thread+0x48>
    8b38:	97ffec7e 	bl	3d30 <fwp_heap_init>
    8b3c:	17ffff84 	b	894c <fwp_main_thread+0x3c>
    8b40:	f941c282 	ldr	x2, [x20, #896]
    8b44:	a91773fb 	stp	x27, x28, [sp, #368]
    8b48:	d0ffffe0 	adrp	x0, 6000 <fwp_owned_entry173+0xf0>
    8b4c:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    8b50:	910ac000 	add	x0, x0, #0x2b0
    8b54:	913c4021 	add	x1, x1, #0xf10
    8b58:	d280001b 	mov	x27, #0x0                   	// #0
    8b5c:	d290001c 	mov	x28, #0x8000                	// #32768
    8b60:	f90007ff 	str	xzr, [sp, #8]
    8b64:	390043f9 	strb	w25, [sp, #16]
    8b68:	a90287e2 	stp	x2, x1, [sp, #40]
    8b6c:	a903fff7 	stp	x23, xzr, [sp, #56]
    8b70:	a90503ff 	stp	xzr, x0, [sp, #80]
    8b74:	f901c296 	str	x22, [x20, #896]
    8b78:	14000012 	b	8bc0 <fwp_main_thread+0x2b0>
    8b7c:	7100045f 	cmp	w2, #0x1
    8b80:	540001a1 	b.ne	8bb4 <fwp_main_thread+0x2a4>  // b.any
    8b84:	294308a6 	ldp	w6, w2, [x5, #24]
    8b88:	92403c21 	and	x1, x1, #0xffff
    8b8c:	9b067c21 	mul	x1, x1, x6
    8b90:	d360fc21 	lsr	x1, x1, #32
    8b94:	eb02003f 	cmp	x1, x2
    8b98:	540000e2 	b.cs	8bb4 <fwp_main_thread+0x2a4>  // b.hs, b.nlast
    8b9c:	8b010000 	add	x0, x0, x1
    8ba0:	39400001 	ldrb	w1, [x0]
    8ba4:	7103fc3f 	cmp	w1, #0xff
    8ba8:	54003f60 	b.eq	9394 <fwp_main_thread+0xa84>  // b.none
    8bac:	394043e1 	ldrb	w1, [sp, #16]
    8bb0:	39000001 	strb	w1, [x0]
    8bb4:	a9047ffb 	stp	x27, xzr, [sp, #64]
    8bb8:	aa190294 	orr	x20, x20, x25
    8bbc:	b4001bf4 	cbz	x20, 8f38 <fwp_main_thread+0x628>
    8bc0:	f94007e0 	ldr	x0, [sp, #8]
    8bc4:	f1000794 	subs	x20, x28, #0x1
    8bc8:	aa1803e1 	mov	x1, x24
    8bcc:	f90027f4 	str	x20, [sp, #72]
    8bd0:	da1f0019 	sbc	x25, x0, xzr
    8bd4:	52800020 	mov	w0, #0x1                   	// #1
    8bd8:	f90007f9 	str	x25, [sp, #8]
    8bdc:	aa1403fc 	mov	x28, x20
    8be0:	a9086ff4 	stp	x20, x27, [sp, #128]
    8be4:	97fff19b 	bl	5250 <fwp_data.part.0.constprop.0>
    8be8:	aa0003fb 	mov	x27, x0
    8bec:	f949db41 	ldr	x1, [x26, #5040]
    8bf0:	f949ef40 	ldr	x0, [x26, #5080]
    8bf4:	cb010361 	sub	x1, x27, x1
    8bf8:	eb00403f 	cmp	x1, x0, lsl #16
    8bfc:	54fffdc2 	b.cs	8bb4 <fwp_main_thread+0x2a4>  // b.hs, b.nlast
    8c00:	d350fc22 	lsr	x2, x1, #16
    8c04:	f949ff46 	ldr	x6, [x26, #5112]
    8c08:	8b020842 	add	x2, x2, x2, lsl #2
    8c0c:	d37df042 	lsl	x2, x2, #3
    8c10:	8b0200c5 	add	x5, x6, x2
    8c14:	f94010a0 	ldr	x0, [x5, #32]
    8c18:	b4fffce0 	cbz	x0, 8bb4 <fwp_main_thread+0x2a4>
    8c1c:	386268c2 	ldrb	w2, [x6, x2]
    8c20:	7100085f 	cmp	w2, #0x2
    8c24:	54fffac1 	b.ne	8b7c <fwp_main_thread+0x26c>  // b.any
    8c28:	72003c3f 	tst	w1, #0xffff
    8c2c:	54fffc41 	b.ne	8bb4 <fwp_main_thread+0x2a4>  // b.any
    8c30:	17ffffdc 	b	8ba0 <fwp_main_thread+0x290>
    8c34:	97ffefcb 	bl	4b60 <fwp_now_ns>
    8c38:	f94032c1 	ldr	x1, [x22, #96]
    8c3c:	eb01001f 	cmp	x0, x1
    8c40:	540000ab 	b.lt	8c54 <fwp_main_thread+0x344>  // b.tstop
    8c44:	394142c0 	ldrb	w0, [x22, #80]
    8c48:	37000060 	tbnz	w0, #0, 8c54 <fwp_main_thread+0x344>
    8c4c:	aa1603e0 	mov	x0, x22
    8c50:	97ffea98 	bl	36b0 <fwp_cancel_tree.part.0>
    8c54:	394146c0 	ldrb	w0, [x22, #81]
    8c58:	f9404f54 	ldr	x20, [x26, #152]
    8c5c:	39414a82 	ldrb	w2, [x20, #82]
    8c60:	3707f100 	tbnz	w0, #0, 8a80 <fwp_main_thread+0x170>
    8c64:	f94032c1 	ldr	x1, [x22, #96]
    8c68:	370001c2 	tbnz	w2, #0, 8ca0 <fwp_main_thread+0x390>
    8c6c:	f9403280 	ldr	x0, [x20, #96]
    8c70:	b4000180 	cbz	x0, 8ca0 <fwp_main_thread+0x390>
    8c74:	b4000061 	cbz	x1, 8c80 <fwp_main_thread+0x370>
    8c78:	eb01001f 	cmp	x0, x1
    8c7c:	9a81d000 	csel	x0, x0, x1, le
    8c80:	f94022c1 	ldr	x1, [x22, #64]
    8c84:	a911fe97 	stp	x23, xzr, [x20, #280]
    8c88:	f9009681 	str	x1, [x20, #296]
    8c8c:	b40038c1 	cbz	x1, 93a4 <fwp_main_thread+0xa94>
    8c90:	f9009034 	str	x20, [x1, #288]
    8c94:	aa0003e1 	mov	x1, x0
    8c98:	f90022d4 	str	x20, [x22, #64]
    8c9c:	17ffff84 	b	8aac <fwp_main_thread+0x19c>
    8ca0:	f94022c0 	ldr	x0, [x22, #64]
    8ca4:	17ffff7c 	b	8a94 <fwp_main_thread+0x184>
    8ca8:	a911fe97 	stp	x23, xzr, [x20, #280]
    8cac:	f9009680 	str	x0, [x20, #296]
    8cb0:	b4000040 	cbz	x0, 8cb8 <fwp_main_thread+0x3a8>
    8cb4:	f9009014 	str	x20, [x0, #288]
    8cb8:	f90022d4 	str	x20, [x22, #64]
    8cbc:	17ffff83 	b	8ac8 <fwp_main_thread+0x1b8>
    8cc0:	f9000040 	str	x0, [x2]
    8cc4:	17ffff89 	b	8ae8 <fwp_main_thread+0x1d8>
    8cc8:	39014ad9 	strb	w25, [x22, #82]
    8ccc:	910142b4 	add	x20, x21, #0x50
    8cd0:	f941ce80 	ldr	x0, [x20, #920]
    8cd4:	b5000060 	cbnz	x0, 8ce0 <fwp_main_thread+0x3d0>
    8cd8:	f941d680 	ldr	x0, [x20, #936]
    8cdc:	b4003820 	cbz	x0, 93e0 <fwp_main_thread+0xad0>
    8ce0:	910142a0 	add	x0, x21, #0x50
    8ce4:	f9404c00 	ldr	x0, [x0, #152]
    8ce8:	910142a1 	add	x1, x21, #0x50
    8cec:	f941e426 	ldr	x6, [x1, #968]
    8cf0:	b903c03f 	str	wzr, [x1, #960]
    8cf4:	eb0000df 	cmp	x6, x0
    8cf8:	540040a1 	b.ne	950c <fwp_main_thread+0xbfc>  // b.any
    8cfc:	b40003c0 	cbz	x0, 8d74 <fwp_main_thread+0x464>
    8d00:	f941b825 	ldr	x5, [x1, #880]
    8d04:	52800021 	mov	w1, #0x1                   	// #1
    8d08:	39014801 	strb	w1, [x0, #82]
    8d0c:	b4000345 	cbz	x5, 8d74 <fwp_main_thread+0x464>
    8d10:	394140a0 	ldrb	w0, [x5, #80]
    8d14:	37000060 	tbnz	w0, #0, 8d20 <fwp_main_thread+0x410>
    8d18:	aa0503e0 	mov	x0, x5
    8d1c:	97ffea65 	bl	36b0 <fwp_cancel_tree.part.0>
    8d20:	f9409ca5 	ldr	x5, [x5, #312]
    8d24:	b5ffff65 	cbnz	x5, 8d10 <fwp_main_thread+0x400>
    8d28:	910142b4 	add	x20, x21, #0x50
    8d2c:	52800036 	mov	w22, #0x1                   	// #1
    8d30:	f94028c0 	ldr	x0, [x6, #80]
    8d34:	f2001c1f 	tst	x0, #0xff000000ff
    8d38:	540000e1 	b.ne	8d54 <fwp_main_thread+0x444>  // b.any
    8d3c:	f9406280 	ldr	x0, [x20, #192]
    8d40:	390150d6 	strb	w22, [x6, #84]
    8d44:	f90080df 	str	xzr, [x6, #256]
    8d48:	b4000120 	cbz	x0, 8d6c <fwp_main_thread+0x45c>
    8d4c:	f9008006 	str	x6, [x0, #256]
    8d50:	f9006286 	str	x6, [x20, #192]
    8d54:	97fff853 	bl	6ea0 <fwp_block>
    8d58:	97fff7da 	bl	6cc0 <fwp_free_zombie>
    8d5c:	f941ba80 	ldr	x0, [x20, #880]
    8d60:	b40000a0 	cbz	x0, 8d74 <fwp_main_thread+0x464>
    8d64:	f941e686 	ldr	x6, [x20, #968]
    8d68:	17fffff2 	b	8d30 <fwp_main_thread+0x420>
    8d6c:	f9006686 	str	x6, [x20, #200]
    8d70:	17fffff8 	b	8d50 <fwp_main_thread+0x440>
    8d74:	910142b6 	add	x22, x21, #0x50
    8d78:	97fff7d2 	bl	6cc0 <fwp_free_zombie>
    8d7c:	f94066c0 	ldr	x0, [x22, #200]
    8d80:	b5003c60 	cbnz	x0, 950c <fwp_main_thread+0xbfc>
    8d84:	f9408ec0 	ldr	x0, [x22, #280]
    8d88:	b5003c20 	cbnz	x0, 950c <fwp_main_thread+0xbfc>
    8d8c:	b94162d4 	ldr	w20, [x22, #352]
    8d90:	340001f4 	cbz	w20, 8dcc <fwp_main_thread+0x4bc>
    8d94:	93407e97 	sxtw	x23, w20
    8d98:	51000694 	sub	w20, w20, #0x1
    8d9c:	d1000af7 	sub	x23, x23, #0x2
    8da0:	9105c2d8 	add	x24, x22, #0x170
    8da4:	cb3442f7 	sub	x23, x23, w20, uxtw
    8da8:	93407e94 	sxtw	x20, w20
    8dac:	d503201f 	nop
    8db0:	f8747b00 	ldr	x0, [x24, x20, lsl #3]
    8db4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8db8:	b90162d4 	str	w20, [x22, #352]
    8dbc:	d1000694 	sub	x20, x20, #0x1
    8dc0:	97ffe6f0 	bl	2980 <munmap@plt>
    8dc4:	eb17029f 	cmp	x20, x23
    8dc8:	54ffff41 	b.ne	8db0 <fwp_main_thread+0x4a0>  // b.any
    8dcc:	900000d4 	adrp	x20, 20000 <__data_start>
    8dd0:	91004280 	add	x0, x20, #0x10
    8dd4:	b9402000 	ldr	w0, [x0, #32]
    8dd8:	37f80040 	tbnz	w0, #31, 8de0 <fwp_main_thread+0x4d0>
    8ddc:	97ffe6a5 	bl	2870 <close@plt>
    8de0:	910142b6 	add	x22, x21, #0x50
    8de4:	91004294 	add	x20, x20, #0x10
    8de8:	12800001 	mov	w1, #0xffffffff            	// #-1
    8dec:	f941eec0 	ldr	x0, [x22, #984]
    8df0:	b9002281 	str	w1, [x20, #32]
    8df4:	f941eac1 	ldr	x1, [x22, #976]
    8df8:	b40001c0 	cbz	x0, 8e30 <fwp_main_thread+0x520>
    8dfc:	d2800014 	mov	x20, #0x0                   	// #0
    8e00:	f8747820 	ldr	x0, [x1, x20, lsl #3]
    8e04:	b40000e0 	cbz	x0, 8e20 <fwp_main_thread+0x510>
    8e08:	f9400001 	ldr	x1, [x0]
    8e0c:	b5003801 	cbnz	x1, 950c <fwp_main_thread+0xbfc>
    8e10:	f9400401 	ldr	x1, [x0, #8]
    8e14:	b50037c1 	cbnz	x1, 950c <fwp_main_thread+0xbfc>
    8e18:	97ffedee 	bl	45d0 <fwp_mem_free>
    8e1c:	f941eac1 	ldr	x1, [x22, #976]
    8e20:	91000694 	add	x20, x20, #0x1
    8e24:	f941eec0 	ldr	x0, [x22, #984]
    8e28:	eb00029f 	cmp	x20, x0
    8e2c:	54fffea3 	b.cc	8e00 <fwp_main_thread+0x4f0>  // b.lo, b.ul, b.last
    8e30:	aa0103e0 	mov	x0, x1
    8e34:	97ffede7 	bl	45d0 <fwp_mem_free>
    8e38:	910142a0 	add	x0, x21, #0x50
    8e3c:	f941e414 	ldr	x20, [x0, #968]
    8e40:	f901e81f 	str	xzr, [x0, #976]
    8e44:	f901ec1f 	str	xzr, [x0, #984]
    8e48:	b40001f4 	cbz	x20, 8e84 <fwp_main_thread+0x574>
    8e4c:	f9401681 	ldr	x1, [x20, #40]
    8e50:	b50035e1 	cbnz	x1, 950c <fwp_main_thread+0xbfc>
    8e54:	f9405681 	ldr	x1, [x20, #168]
    8e58:	b50035a1 	cbnz	x1, 950c <fwp_main_thread+0xbfc>
    8e5c:	f941cc01 	ldr	x1, [x0, #920]
    8e60:	b5003561 	cbnz	x1, 950c <fwp_main_thread+0xbfc>
    8e64:	f941d400 	ldr	x0, [x0, #936]
    8e68:	b5003520 	cbnz	x0, 950c <fwp_main_thread+0xbfc>
    8e6c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8e70:	90000380 	adrp	x0, 78000 <ad_raw_blocks+0x17bd0>
    8e74:	9110c000 	add	x0, x0, #0x430
    8e78:	97ffe66e 	bl	2830 <memset@plt>
    8e7c:	aa1403e0 	mov	x0, x20
    8e80:	97ffedd4 	bl	45d0 <fwp_mem_free>
    8e84:	910142a6 	add	x6, x21, #0x50
    8e88:	91184273 	add	x19, x19, #0x610
    8e8c:	3dc016a1 	ldr	q1, [x21, #80]
    8e90:	52800041 	mov	w1, #0x2                   	// #2
    8e94:	3dc004c2 	ldr	q2, [x6, #16]
    8e98:	d0000002 	adrp	x2, a000 <_IO_stdin_used+0x3c0>
    8e9c:	fd4a1260 	ldr	d0, [x19, #5152]
    8ea0:	910e8042 	add	x2, x2, #0x3a0
    8ea4:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    8ea8:	fd409cc1 	ldr	d1, [x6, #312]
    8eac:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8eb0:	f947e800 	ldr	x0, [x0, #4048]
    8eb4:	7e61d800 	ucvtf	d0, d0
    8eb8:	a95290c3 	ldp	x3, x4, [x6, #296]
    8ebc:	f9004cdf 	str	xzr, [x6, #152]
    8ec0:	f9400000 	ldr	x0, [x0]
    8ec4:	1e613801 	fsub	d1, d0, d1
    8ec8:	f940a4c5 	ldr	x5, [x6, #328]
    8ecc:	b90120df 	str	wzr, [x6, #288]
    8ed0:	5ef1b842 	addp	d2, v2.2d
    8ed4:	fd40a0c0 	ldr	d0, [x6, #320]
    8ed8:	f901e4df 	str	xzr, [x6, #968]
    8edc:	fd0058c2 	str	d2, [x6, #176]
    8ee0:	97ffe67c 	bl	28d0 <__fprintf_chk@plt>
    8ee4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8ee8:	f947ec00 	ldr	x0, [x0, #4056]
    8eec:	f9400000 	ldr	x0, [x0]
    8ef0:	97ffe6a8 	bl	2990 <fflush@plt>
    8ef4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8ef8:	f947f400 	ldr	x0, [x0, #4072]
    8efc:	f9408fe2 	ldr	x2, [sp, #280]
    8f00:	f9400001 	ldr	x1, [x0]
    8f04:	eb010042 	subs	x2, x2, x1
    8f08:	d2800001 	mov	x1, #0x0                   	// #0
    8f0c:	54002b21 	b.ne	9470 <fwp_main_thread+0xb60>  // b.any
    8f10:	a9527bfd 	ldp	x29, x30, [sp, #288]
    8f14:	d2800000 	mov	x0, #0x0                   	// #0
    8f18:	a95353f3 	ldp	x19, x20, [sp, #304]
    8f1c:	a9545bf5 	ldp	x21, x22, [sp, #320]
    8f20:	a95563f7 	ldp	x23, x24, [sp, #336]
    8f24:	a9566bf9 	ldp	x25, x26, [sp, #352]
    8f28:	910603ff 	add	sp, sp, #0x180
    8f2c:	d65f03c0 	ret
    8f30:	f9008f40 	str	x0, [x26, #280]
    8f34:	17fffef7 	b	8b10 <fwp_main_thread+0x200>
    8f38:	910142a2 	add	x2, x21, #0x50
    8f3c:	f90023ff 	str	xzr, [sp, #64]
    8f40:	f941c040 	ldr	x0, [x2, #896]
    8f44:	eb16001f 	cmp	x0, x22
    8f48:	54002e41 	b.ne	9510 <fwp_main_thread+0xc00>  // b.any
    8f4c:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    8f50:	910183e1 	add	x1, sp, #0x60
    8f54:	f94017e3 	ldr	x3, [sp, #40]
    8f58:	f901c043 	str	x3, [x2, #896]
    8f5c:	3dc2dc00 	ldr	q0, [x0, #2928]
    8f60:	52800020 	mov	w0, #0x1                   	// #1
    8f64:	3d801be0 	str	q0, [sp, #96]
    8f68:	97fff0ba 	bl	5250 <fwp_data.part.0.constprop.0>
    8f6c:	91184263 	add	x3, x19, #0x610
    8f70:	aa0003f4 	mov	x20, x0
    8f74:	f949d861 	ldr	x1, [x3, #5040]
    8f78:	f949ec60 	ldr	x0, [x3, #5080]
    8f7c:	cb010281 	sub	x1, x20, x1
    8f80:	eb00403f 	cmp	x1, x0, lsl #16
    8f84:	54000322 	b.cs	8fe8 <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    8f88:	d350fc22 	lsr	x2, x1, #16
    8f8c:	f949fc63 	ldr	x3, [x3, #5112]
    8f90:	8b020842 	add	x2, x2, x2, lsl #2
    8f94:	d37df042 	lsl	x2, x2, #3
    8f98:	8b020060 	add	x0, x3, x2
    8f9c:	f9401016 	ldr	x22, [x0, #32]
    8fa0:	b4000256 	cbz	x22, 8fe8 <fwp_main_thread+0x6d8>
    8fa4:	38626862 	ldrb	w2, [x3, x2]
    8fa8:	7100085f 	cmp	w2, #0x2
    8fac:	54002020 	b.eq	93b0 <fwp_main_thread+0xaa0>  // b.none
    8fb0:	7100045f 	cmp	w2, #0x1
    8fb4:	540001a1 	b.ne	8fe8 <fwp_main_thread+0x6d8>  // b.any
    8fb8:	29430002 	ldp	w2, w0, [x0, #24]
    8fbc:	92403c21 	and	x1, x1, #0xffff
    8fc0:	9b027c21 	mul	x1, x1, x2
    8fc4:	d360fc21 	lsr	x1, x1, #32
    8fc8:	eb00003f 	cmp	x1, x0
    8fcc:	540000e2 	b.cs	8fe8 <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    8fd0:	8b0102d6 	add	x22, x22, x1
    8fd4:	394002c0 	ldrb	w0, [x22]
    8fd8:	7103fc1f 	cmp	w0, #0xff
    8fdc:	54002200 	b.eq	941c <fwp_main_thread+0xb0c>  // b.none
    8fe0:	52800020 	mov	w0, #0x1                   	// #1
    8fe4:	390002c0 	strb	w0, [x22]
    8fe8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8fec:	aa1803e1 	mov	x1, x24
    8ff0:	52800020 	mov	w0, #0x1                   	// #1
    8ff4:	a90853e2 	stp	x2, x20, [sp, #128]
    8ff8:	97fff096 	bl	5250 <fwp_data.part.0.constprop.0>
    8ffc:	91184263 	add	x3, x19, #0x610
    9000:	aa0003f4 	mov	x20, x0
    9004:	f949d861 	ldr	x1, [x3, #5040]
    9008:	f949ec60 	ldr	x0, [x3, #5080]
    900c:	cb010281 	sub	x1, x20, x1
    9010:	eb00403f 	cmp	x1, x0, lsl #16
    9014:	54000322 	b.cs	9078 <fwp_main_thread+0x768>  // b.hs, b.nlast
    9018:	d350fc22 	lsr	x2, x1, #16
    901c:	f949fc63 	ldr	x3, [x3, #5112]
    9020:	8b020842 	add	x2, x2, x2, lsl #2
    9024:	d37df042 	lsl	x2, x2, #3
    9028:	8b020060 	add	x0, x3, x2
    902c:	f9401016 	ldr	x22, [x0, #32]
    9030:	b4000256 	cbz	x22, 9078 <fwp_main_thread+0x768>
    9034:	38626862 	ldrb	w2, [x3, x2]
    9038:	7100085f 	cmp	w2, #0x2
    903c:	54001c00 	b.eq	93bc <fwp_main_thread+0xaac>  // b.none
    9040:	7100045f 	cmp	w2, #0x1
    9044:	540001a1 	b.ne	9078 <fwp_main_thread+0x768>  // b.any
    9048:	29430002 	ldp	w2, w0, [x0, #24]
    904c:	92403c21 	and	x1, x1, #0xffff
    9050:	9b027c21 	mul	x1, x1, x2
    9054:	d360fc21 	lsr	x1, x1, #32
    9058:	eb00003f 	cmp	x1, x0
    905c:	540000e2 	b.cs	9078 <fwp_main_thread+0x768>  // b.hs, b.nlast
    9060:	8b0102d6 	add	x22, x22, x1
    9064:	394002c0 	ldrb	w0, [x22]
    9068:	7103fc1f 	cmp	w0, #0xff
    906c:	54001cc0 	b.eq	9404 <fwp_main_thread+0xaf4>  // b.none
    9070:	52800020 	mov	w0, #0x1                   	// #1
    9074:	390002c0 	strb	w0, [x22]
    9078:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    907c:	9101c3e1 	add	x1, sp, #0x70
    9080:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9084:	52800020 	mov	w0, #0x1                   	// #1
    9088:	a90753e2 	stp	x2, x20, [sp, #112]
    908c:	97fff071 	bl	5250 <fwp_data.part.0.constprop.0>
    9090:	91184263 	add	x3, x19, #0x610
    9094:	aa0003f9 	mov	x25, x0
    9098:	f949d861 	ldr	x1, [x3, #5040]
    909c:	f949ec60 	ldr	x0, [x3, #5080]
    90a0:	cb010321 	sub	x1, x25, x1
    90a4:	eb00403f 	cmp	x1, x0, lsl #16
    90a8:	54000322 	b.cs	910c <fwp_main_thread+0x7fc>  // b.hs, b.nlast
    90ac:	d350fc22 	lsr	x2, x1, #16
    90b0:	f949fc63 	ldr	x3, [x3, #5112]
    90b4:	8b020842 	add	x2, x2, x2, lsl #2
    90b8:	d37df042 	lsl	x2, x2, #3
    90bc:	8b020060 	add	x0, x3, x2
    90c0:	f9401014 	ldr	x20, [x0, #32]
    90c4:	b4000254 	cbz	x20, 910c <fwp_main_thread+0x7fc>
    90c8:	38626862 	ldrb	w2, [x3, x2]
    90cc:	7100085f 	cmp	w2, #0x2
    90d0:	540017c0 	b.eq	93c8 <fwp_main_thread+0xab8>  // b.none
    90d4:	7100045f 	cmp	w2, #0x1
    90d8:	540001a1 	b.ne	910c <fwp_main_thread+0x7fc>  // b.any
    90dc:	29430002 	ldp	w2, w0, [x0, #24]
    90e0:	92403c21 	and	x1, x1, #0xffff
    90e4:	9b027c21 	mul	x1, x1, x2
    90e8:	d360fc21 	lsr	x1, x1, #32
    90ec:	eb00003f 	cmp	x1, x0
    90f0:	540000e2 	b.cs	910c <fwp_main_thread+0x7fc>  // b.hs, b.nlast
    90f4:	8b010294 	add	x20, x20, x1
    90f8:	39400280 	ldrb	w0, [x20]
    90fc:	7103fc1f 	cmp	w0, #0xff
    9100:	54001880 	b.eq	9410 <fwp_main_thread+0xb00>  // b.none
    9104:	52800020 	mov	w0, #0x1                   	// #1
    9108:	39000280 	strb	w0, [x20]
    910c:	aa1b03f8 	mov	x24, x27
    9110:	b00000a0 	adrp	x0, 1e000 <__FRAME_END__+0x12128>
    9114:	b40012db 	cbz	x27, 936c <fwp_main_thread+0xa5c>
    9118:	910ae000 	add	x0, x0, #0x2b8
    911c:	90000016 	adrp	x22, 9000 <fwp_main_thread+0x6f0>
    9120:	91014014 	add	x20, x0, #0x50
    9124:	913202d6 	add	x22, x22, #0xc80
    9128:	9118427a 	add	x26, x19, #0x610
    912c:	f949db41 	ldr	x1, [x26, #5040]
    9130:	f949ef40 	ldr	x0, [x26, #5080]
    9134:	cb010321 	sub	x1, x25, x1
    9138:	eb00403f 	cmp	x1, x0, lsl #16
    913c:	54000402 	b.cs	91bc <fwp_main_thread+0x8ac>  // b.hs, b.nlast
    9140:	d350fc22 	lsr	x2, x1, #16
    9144:	f949ff45 	ldr	x5, [x26, #5112]
    9148:	8b020842 	add	x2, x2, x2, lsl #2
    914c:	d37df042 	lsl	x2, x2, #3
    9150:	8b0200a3 	add	x3, x5, x2
    9154:	f9401060 	ldr	x0, [x3, #32]
    9158:	b4000320 	cbz	x0, 91bc <fwp_main_thread+0x8ac>
    915c:	386268a2 	ldrb	w2, [x5, x2]
    9160:	7100085f 	cmp	w2, #0x2
    9164:	54001380 	b.eq	93d4 <fwp_main_thread+0xac4>  // b.none
    9168:	7100045f 	cmp	w2, #0x1
    916c:	54000281 	b.ne	91bc <fwp_main_thread+0x8ac>  // b.any
    9170:	29430865 	ldp	w5, w2, [x3, #24]
    9174:	92403c21 	and	x1, x1, #0xffff
    9178:	9b057c21 	mul	x1, x1, x5
    917c:	d360fc21 	lsr	x1, x1, #32
    9180:	eb02003f 	cmp	x1, x2
    9184:	540001c2 	b.cs	91bc <fwp_main_thread+0x8ac>  // b.hs, b.nlast
    9188:	8b010000 	add	x0, x0, x1
    918c:	39400001 	ldrb	w1, [x0]
    9190:	34000161 	cbz	w1, 91bc <fwp_main_thread+0x8ac>
    9194:	910142a2 	add	x2, x21, #0x50
    9198:	b9412043 	ldr	w3, [x2, #288]
    919c:	34000083 	cbz	w3, 91ac <fwp_main_thread+0x89c>
    91a0:	f940a443 	ldr	x3, [x2, #328]
    91a4:	91000463 	add	x3, x3, #0x1
    91a8:	f900a443 	str	x3, [x2, #328]
    91ac:	7103f43f 	cmp	w1, #0xfd
    91b0:	540013c8 	b.hi	9428 <fwp_main_thread+0xb18>  // b.pmore
    91b4:	11000421 	add	w1, w1, #0x1
    91b8:	39000001 	strb	w1, [x0]
    91bc:	aa1403e2 	mov	x2, x20
    91c0:	aa1903e1 	mov	x1, x25
    91c4:	aa1703e0 	mov	x0, x23
    91c8:	52800023 	mov	w3, #0x1                   	// #1
    91cc:	a9047fff 	stp	xzr, xzr, [sp, #64]
    91d0:	f9002bff 	str	xzr, [sp, #80]
    91d4:	97fff9d4 	bl	7924 <fwp_write>
    91d8:	a9440bfc 	ldp	x28, x2, [sp, #64]
    91dc:	f100039f 	cmp	x28, #0x0
    91e0:	9a9c02dc 	csel	x28, x22, x28, eq	// eq = none
    91e4:	b100285f 	cmn	x2, #0xa
    91e8:	54001248 	b.hi	9430 <fwp_main_thread+0xb20>  // b.pmore
    91ec:	91002440 	add	x0, x2, #0x9
    91f0:	52800021 	mov	w1, #0x1                   	// #1
    91f4:	f9000be2 	str	x2, [sp, #16]
    91f8:	97ffefb2 	bl	50c0 <fwp_heap_alloc>
    91fc:	aa1c03e1 	mov	x1, x28
    9200:	aa0003fc 	mov	x28, x0
    9204:	f9400be2 	ldr	x2, [sp, #16]
    9208:	f90007e0 	str	x0, [sp, #8]
    920c:	f8008782 	str	x2, [x28], #8
    9210:	aa1c03e0 	mov	x0, x28
    9214:	97ffe52b 	bl	26c0 <memcpy@plt>
    9218:	a9408be0 	ldp	x0, x2, [sp, #8]
    921c:	8b020002 	add	x2, x0, x2
    9220:	3900205f 	strb	wzr, [x2, #8]
    9224:	f94023e0 	ldr	x0, [sp, #64]
    9228:	97ffe5be 	bl	2920 <free@plt>
    922c:	91184260 	add	x0, x19, #0x610
    9230:	f94007e3 	ldr	x3, [sp, #8]
    9234:	f949d801 	ldr	x1, [x0, #5040]
    9238:	f949ec02 	ldr	x2, [x0, #5080]
    923c:	cb010061 	sub	x1, x3, x1
    9240:	eb02403f 	cmp	x1, x2, lsl #16
    9244:	54000322 	b.cs	92a8 <fwp_main_thread+0x998>  // b.hs, b.nlast
    9248:	d350fc22 	lsr	x2, x1, #16
    924c:	d2800503 	mov	x3, #0x28                  	// #40
    9250:	f949fc05 	ldr	x5, [x0, #5112]
    9254:	9b037c42 	mul	x2, x2, x3
    9258:	8b0200a3 	add	x3, x5, x2
    925c:	f9401060 	ldr	x0, [x3, #32]
    9260:	b4000240 	cbz	x0, 92a8 <fwp_main_thread+0x998>
    9264:	386268a2 	ldrb	w2, [x5, x2]
    9268:	7100085f 	cmp	w2, #0x2
    926c:	54000f40 	b.eq	9454 <fwp_main_thread+0xb44>  // b.none
    9270:	7100045f 	cmp	w2, #0x1
    9274:	540001a1 	b.ne	92a8 <fwp_main_thread+0x998>  // b.any
    9278:	29430865 	ldp	w5, w2, [x3, #24]
    927c:	92403c21 	and	x1, x1, #0xffff
    9280:	9b057c21 	mul	x1, x1, x5
    9284:	d360fc21 	lsr	x1, x1, #32
    9288:	eb02003f 	cmp	x1, x2
    928c:	540000e2 	b.cs	92a8 <fwp_main_thread+0x998>  // b.hs, b.nlast
    9290:	8b010000 	add	x0, x0, x1
    9294:	39400001 	ldrb	w1, [x0]
    9298:	7103fc3f 	cmp	w1, #0xff
    929c:	540010c0 	b.eq	94b4 <fwp_main_thread+0xba4>  // b.none
    92a0:	52800021 	mov	w1, #0x1                   	// #1
    92a4:	39000001 	strb	w1, [x0]
    92a8:	aa1903e0 	mov	x0, x25
    92ac:	97fff3a5 	bl	6140 <fwp_drop0>
    92b0:	f94007e1 	ldr	x1, [sp, #8]
    92b4:	910142a3 	add	x3, x21, #0x50
    92b8:	aa1c03e0 	mov	x0, x28
    92bc:	aa0303fc 	mov	x28, x3
    92c0:	f9400022 	ldr	x2, [x1]
    92c4:	d2800021 	mov	x1, #0x1                   	// #1
    92c8:	f9404863 	ldr	x3, [x3, #144]
    92cc:	97ffe5a5 	bl	2960 <fwrite@plt>
    92d0:	f9404b81 	ldr	x1, [x28, #144]
    92d4:	52800140 	mov	w0, #0xa                   	// #10
    92d8:	97ffe52a 	bl	2780 <fputc@plt>
    92dc:	91184262 	add	x2, x19, #0x610
    92e0:	f94007e3 	ldr	x3, [sp, #8]
    92e4:	f949d841 	ldr	x1, [x2, #5040]
    92e8:	f949ec40 	ldr	x0, [x2, #5080]
    92ec:	cb010061 	sub	x1, x3, x1
    92f0:	eb00403f 	cmp	x1, x0, lsl #16
    92f4:	54000382 	b.cs	9364 <fwp_main_thread+0xa54>  // b.hs, b.nlast
    92f8:	d350fc20 	lsr	x0, x1, #16
    92fc:	d2800505 	mov	x5, #0x28                  	// #40
    9300:	f949fc43 	ldr	x3, [x2, #5112]
    9304:	9b057c00 	mul	x0, x0, x5
    9308:	8b000062 	add	x2, x3, x0
    930c:	f940105c 	ldr	x28, [x2, #32]
    9310:	b40002bc 	cbz	x28, 9364 <fwp_main_thread+0xa54>
    9314:	38606860 	ldrb	w0, [x3, x0]
    9318:	7100081f 	cmp	w0, #0x2
    931c:	54000960 	b.eq	9448 <fwp_main_thread+0xb38>  // b.none
    9320:	7100041f 	cmp	w0, #0x1
    9324:	54000201 	b.ne	9364 <fwp_main_thread+0xa54>  // b.any
    9328:	29430043 	ldp	w3, w0, [x2, #24]
    932c:	92403c21 	and	x1, x1, #0xffff
    9330:	9b037c21 	mul	x1, x1, x3
    9334:	d360fc21 	lsr	x1, x1, #32
    9338:	eb00003f 	cmp	x1, x0
    933c:	54000142 	b.cs	9364 <fwp_main_thread+0xa54>  // b.hs, b.nlast
    9340:	8b01039c 	add	x28, x28, x1
    9344:	39400380 	ldrb	w0, [x28]
    9348:	340000e0 	cbz	w0, 9364 <fwp_main_thread+0xa54>
    934c:	7100041f 	cmp	w0, #0x1
    9350:	54000760 	b.eq	943c <fwp_main_thread+0xb2c>  // b.none
    9354:	7103fc1f 	cmp	w0, #0xff
    9358:	54000900 	b.eq	9478 <fwp_main_thread+0xb68>  // b.none
    935c:	51000400 	sub	w0, w0, #0x1
    9360:	39000380 	strb	w0, [x28]
    9364:	f9400b18 	ldr	x24, [x24, #16]
    9368:	b5ffee38 	cbnz	x24, 912c <fwp_main_thread+0x81c>
    936c:	aa1903e0 	mov	x0, x25
    9370:	97fff374 	bl	6140 <fwp_drop0>
    9374:	aa1b03e0 	mov	x0, x27
    9378:	97fff372 	bl	6140 <fwp_drop0>
    937c:	910142a0 	add	x0, x21, #0x50
    9380:	52800021 	mov	w1, #0x1                   	// #1
    9384:	a95773fb 	ldp	x27, x28, [sp, #368]
    9388:	b903b401 	str	w1, [x0, #948]
    938c:	f901dc1f 	str	xzr, [x0, #952]
    9390:	17fffdae 	b	8a48 <fwp_main_thread+0x138>
    9394:	f9000fe0 	str	x0, [sp, #24]
    9398:	97ffebf3 	bl	4364 <fwp_rc_forget_slot.part.0>
    939c:	f9400fe0 	ldr	x0, [sp, #24]
    93a0:	17fffe03 	b	8bac <fwp_main_thread+0x29c>
    93a4:	aa0003e1 	mov	x1, x0
    93a8:	f90022d4 	str	x20, [x22, #64]
    93ac:	17fffdc0 	b	8aac <fwp_main_thread+0x19c>
    93b0:	72003c3f 	tst	w1, #0xffff
    93b4:	54ffe1a1 	b.ne	8fe8 <fwp_main_thread+0x6d8>  // b.any
    93b8:	17ffff07 	b	8fd4 <fwp_main_thread+0x6c4>
    93bc:	72003c3f 	tst	w1, #0xffff
    93c0:	54ffe5c1 	b.ne	9078 <fwp_main_thread+0x768>  // b.any
    93c4:	17ffff28 	b	9064 <fwp_main_thread+0x754>
    93c8:	72003c3f 	tst	w1, #0xffff
    93cc:	54ffea01 	b.ne	910c <fwp_main_thread+0x7fc>  // b.any
    93d0:	17ffff4a 	b	90f8 <fwp_main_thread+0x7e8>
    93d4:	72003c3f 	tst	w1, #0xffff
    93d8:	54ffef21 	b.ne	91bc <fwp_main_thread+0x8ac>  // b.any
    93dc:	17ffff6c 	b	918c <fwp_main_thread+0x87c>
    93e0:	f941ca80 	ldr	x0, [x20, #912]
    93e4:	97ffec7b 	bl	45d0 <fwp_mem_free>
    93e8:	f901ca9f 	str	xzr, [x20, #912]
    93ec:	f9404e80 	ldr	x0, [x20, #152]
    93f0:	f901d29f 	str	xzr, [x20, #928]
    93f4:	b4ffc7a0 	cbz	x0, 8ce8 <fwp_main_thread+0x3d8>
    93f8:	f900541f 	str	xzr, [x0, #168]
    93fc:	f9005c1f 	str	xzr, [x0, #184]
    9400:	17fffe3a 	b	8ce8 <fwp_main_thread+0x3d8>
    9404:	aa1603e0 	mov	x0, x22
    9408:	97ffebd7 	bl	4364 <fwp_rc_forget_slot.part.0>
    940c:	17ffff19 	b	9070 <fwp_main_thread+0x760>
    9410:	aa1403e0 	mov	x0, x20
    9414:	97ffebd4 	bl	4364 <fwp_rc_forget_slot.part.0>
    9418:	17ffff3b 	b	9104 <fwp_main_thread+0x7f4>
    941c:	aa1603e0 	mov	x0, x22
    9420:	97ffebd1 	bl	4364 <fwp_rc_forget_slot.part.0>
    9424:	17fffeef 	b	8fe0 <fwp_main_thread+0x6d0>
    9428:	97ffece3 	bl	47b4 <fwp_rc_wide_dup>
    942c:	17ffff64 	b	91bc <fwp_main_thread+0x8ac>
    9430:	b0000000 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    9434:	910e2000 	add	x0, x0, #0x388
    9438:	97ffebab 	bl	42e4 <fwp_trap>
    943c:	f94007e0 	ldr	x0, [sp, #8]
    9440:	97fff264 	bl	5dd0 <fwp_rc_free_arr>
    9444:	17ffffc8 	b	9364 <fwp_main_thread+0xa54>
    9448:	72003c3f 	tst	w1, #0xffff
    944c:	54fff8c1 	b.ne	9364 <fwp_main_thread+0xa54>  // b.any
    9450:	17ffffbd 	b	9344 <fwp_main_thread+0xa34>
    9454:	72003c3f 	tst	w1, #0xffff
    9458:	54fff281 	b.ne	92a8 <fwp_main_thread+0x998>  // b.any
    945c:	17ffff8e 	b	9294 <fwp_main_thread+0x984>
    9460:	b0000000 	adrp	x0, a000 <_IO_stdin_used+0x3c0>
    9464:	910da000 	add	x0, x0, #0x368
    9468:	a91773fb 	stp	x27, x28, [sp, #368]
    946c:	97ffe7b5 	bl	3340 <ad_raw_fail>
    9470:	a91773fb 	stp	x27, x28, [sp, #368]
    9474:	97ffe4fb 	bl	2860 <__stack_chk_fail@plt>
    9478:	ca5c4780 	eor	x0, x28, x28, lsr #17
    947c:	91184262 	add	x2, x19, #0x610
    9480:	ca402400 	eor	x0, x0, x0, lsr #9
    9484:	92401c00 	and	x0, x0, #0xff
    9488:	910a2401 	add	x1, x0, #0x289
    948c:	8b000c40 	add	x0, x2, x0, lsl #3
    9490:	8b010c41 	add	x1, x2, x1, lsl #3
    9494:	f94a2400 	ldr	x0, [x0, #5192]
    9498:	b40002e0 	cbz	x0, 94f4 <fwp_main_thread+0xbe4>
    949c:	f9400002 	ldr	x2, [x0]
    94a0:	eb02039f 	cmp	x28, x2
    94a4:	54000100 	b.eq	94c4 <fwp_main_thread+0xbb4>  // b.none
    94a8:	91004001 	add	x1, x0, #0x10
    94ac:	f9400800 	ldr	x0, [x0, #16]
    94b0:	17fffffa 	b	9498 <fwp_main_thread+0xb88>
    94b4:	f9000be0 	str	x0, [sp, #16]
    94b8:	97ffebab 	bl	4364 <fwp_rc_forget_slot.part.0>
    94bc:	f9400be0 	ldr	x0, [sp, #16]
    94c0:	17ffff78 	b	92a0 <fwp_main_thread+0x990>
    94c4:	f9400021 	ldr	x1, [x1]
    94c8:	f9400420 	ldr	x0, [x1, #8]
    94cc:	d1000400 	sub	x0, x0, #0x1
    94d0:	f9000420 	str	x0, [x1, #8]
    94d4:	f103f81f 	cmp	x0, #0xfe
    94d8:	54fff461 	b.ne	9364 <fwp_main_thread+0xa54>  // b.any
    94dc:	39400380 	ldrb	w0, [x28]
    94e0:	7103fc1f 	cmp	w0, #0xff
    94e4:	540000e0 	b.eq	9500 <fwp_main_thread+0xbf0>  // b.none
    94e8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    94ec:	39000380 	strb	w0, [x28]
    94f0:	17ffff9d 	b	9364 <fwp_main_thread+0xa54>
    94f4:	90000000 	adrp	x0, 9000 <fwp_main_thread+0x6f0>
    94f8:	913e6000 	add	x0, x0, #0xf98
    94fc:	97ffeb7a 	bl	42e4 <fwp_trap>
    9500:	aa1c03e0 	mov	x0, x28
    9504:	97ffeb98 	bl	4364 <fwp_rc_forget_slot.part.0>
    9508:	17fffff8 	b	94e8 <fwp_main_thread+0xbd8>
    950c:	a91773fb 	stp	x27, x28, [sp, #368]
    9510:	97ffe4e8 	bl	28b0 <abort@plt>
    9514:	d503201f 	nop
    9518:	d503201f 	nop
    951c:	d503201f 	nop

0000000000009520 <__divti3>:
    9520:	d503245f 	bti	c
    9524:	d2800004 	mov	x4, #0x0                   	// #0
    9528:	b7f80721 	tbnz	x1, #63, 960c <__divti3+0xec>
    952c:	b6f80083 	tbz	x3, #63, 953c <__divti3+0x1c>
    9530:	eb0203e2 	negs	x2, x2
    9534:	aa2403e4 	mvn	x4, x4
    9538:	da0303e3 	ngc	x3, x3
    953c:	aa0203e6 	mov	x6, x2
    9540:	aa0003e7 	mov	x7, x0
    9544:	aa0103e5 	mov	x5, x1
    9548:	b5000583 	cbnz	x3, 95f8 <__divti3+0xd8>
    954c:	eb01005f 	cmp	x2, x1
    9550:	54000e69 	b.ls	971c <__divti3+0x1fc>  // b.plast
    9554:	dac01040 	clz	x0, x2
    9558:	b40000e0 	cbz	x0, 9574 <__divti3+0x54>
    955c:	4b0003e1 	neg	w1, w0
    9560:	9ac020a5 	lsl	x5, x5, x0
    9564:	9ac02046 	lsl	x6, x2, x0
    9568:	9ac124e1 	lsr	x1, x7, x1
    956c:	aa050025 	orr	x5, x1, x5
    9570:	9ac020e7 	lsl	x7, x7, x0
    9574:	d360fcc8 	lsr	x8, x6, #32
    9578:	92407cc2 	and	x2, x6, #0xffffffff
    957c:	9ac808a3 	udiv	x3, x5, x8
    9580:	9b089465 	msub	x5, x3, x8, x5
    9584:	aa0303e0 	mov	x0, x3
    9588:	9b037c41 	mul	x1, x2, x3
    958c:	93c780a5 	extr	x5, x5, x7, #32
    9590:	eb05003f 	cmp	x1, x5
    9594:	540000a9 	b.ls	95a8 <__divti3+0x88>  // b.plast
    9598:	ab0500c5 	adds	x5, x6, x5
    959c:	d1000460 	sub	x0, x3, #0x1
    95a0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    95a4:	540015a8 	b.hi	9858 <__divti3+0x338>  // b.pmore
    95a8:	cb0100a5 	sub	x5, x5, x1
    95ac:	9ac808a3 	udiv	x3, x5, x8
    95b0:	9b089465 	msub	x5, x3, x8, x5
    95b4:	aa0303e1 	mov	x1, x3
    95b8:	9b037c42 	mul	x2, x2, x3
    95bc:	aa0703e3 	mov	x3, x7
    95c0:	b3607ca3 	bfi	x3, x5, #32, #32
    95c4:	eb03005f 	cmp	x2, x3
    95c8:	540000c9 	b.ls	95e0 <__divti3+0xc0>  // b.plast
    95cc:	ab0300c3 	adds	x3, x6, x3
    95d0:	d1000425 	sub	x5, x1, #0x1
    95d4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    95d8:	d1000821 	sub	x1, x1, #0x2
    95dc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    95e0:	aa008020 	orr	x0, x1, x0, lsl #32
    95e4:	d2800001 	mov	x1, #0x0                   	// #0
    95e8:	b4000064 	cbz	x4, 95f4 <__divti3+0xd4>
    95ec:	eb0003e0 	negs	x0, x0
    95f0:	da0103e1 	ngc	x1, x1
    95f4:	d65f03c0 	ret
    95f8:	eb01007f 	cmp	x3, x1
    95fc:	54000109 	b.ls	961c <__divti3+0xfc>  // b.plast
    9600:	d2800001 	mov	x1, #0x0                   	// #0
    9604:	d2800000 	mov	x0, #0x0                   	// #0
    9608:	17fffff8 	b	95e8 <__divti3+0xc8>
    960c:	eb0003e0 	negs	x0, x0
    9610:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    9614:	da0103e1 	ngc	x1, x1
    9618:	17ffffc5 	b	952c <__divti3+0xc>
    961c:	dac01067 	clz	x7, x3
    9620:	b40010e7 	cbz	x7, 983c <__divti3+0x31c>
    9624:	d2800805 	mov	x5, #0x40                  	// #64
    9628:	cb0700a5 	sub	x5, x5, x7
    962c:	9ac72063 	lsl	x3, x3, x7
    9630:	9ac52448 	lsr	x8, x2, x5
    9634:	aa030108 	orr	x8, x8, x3
    9638:	9ac52426 	lsr	x6, x1, x5
    963c:	92407d0a 	and	x10, x8, #0xffffffff
    9640:	d360fd09 	lsr	x9, x8, #32
    9644:	9ac52403 	lsr	x3, x0, x5
    9648:	9ac72021 	lsl	x1, x1, x7
    964c:	aa010063 	orr	x3, x3, x1
    9650:	9ac72042 	lsl	x2, x2, x7
    9654:	9ac908cb 	udiv	x11, x6, x9
    9658:	9b099965 	msub	x5, x11, x9, x6
    965c:	aa0b03e1 	mov	x1, x11
    9660:	9b0b7d46 	mul	x6, x10, x11
    9664:	93c380a5 	extr	x5, x5, x3, #32
    9668:	eb0500df 	cmp	x6, x5
    966c:	540000a9 	b.ls	9680 <__divti3+0x160>  // b.plast
    9670:	ab050105 	adds	x5, x8, x5
    9674:	d1000561 	sub	x1, x11, #0x1
    9678:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    967c:	54000f48 	b.hi	9864 <__divti3+0x344>  // b.pmore
    9680:	cb0600a6 	sub	x6, x5, x6
    9684:	9ac908cb 	udiv	x11, x6, x9
    9688:	9b099969 	msub	x9, x11, x9, x6
    968c:	aa0b03e5 	mov	x5, x11
    9690:	9b0b7d4a 	mul	x10, x10, x11
    9694:	b3607d23 	bfi	x3, x9, #32, #32
    9698:	eb03015f 	cmp	x10, x3
    969c:	540000a9 	b.ls	96b0 <__divti3+0x190>  // b.plast
    96a0:	ab030103 	adds	x3, x8, x3
    96a4:	d1000565 	sub	x5, x11, #0x1
    96a8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    96ac:	54000e28 	b.hi	9870 <__divti3+0x350>  // b.pmore
    96b0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    96b4:	92407c48 	and	x8, x2, #0xffffffff
    96b8:	2a0503e5 	mov	w5, w5
    96bc:	d360fc42 	lsr	x2, x2, #32
    96c0:	d360fc26 	lsr	x6, x1, #32
    96c4:	cb0a0063 	sub	x3, x3, x10
    96c8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    96cc:	9b087caa 	mul	x10, x5, x8
    96d0:	9b087cc8 	mul	x8, x6, x8
    96d4:	9b0220a5 	madd	x5, x5, x2, x8
    96d8:	9b027cc6 	mul	x6, x6, x2
    96dc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    96e0:	8b0900c5 	add	x5, x6, x9
    96e4:	eb02011f 	cmp	x8, x2
    96e8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    96ec:	8b4280c6 	add	x6, x6, x2, lsr #32
    96f0:	eb06007f 	cmp	x3, x6
    96f4:	540000e3 	b.cc	9710 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    96f8:	92407d4a 	and	x10, x10, #0xffffffff
    96fc:	9ac72000 	lsl	x0, x0, x7
    9700:	8b028142 	add	x2, x10, x2, lsl #32
    9704:	eb02001f 	cmp	x0, x2
    9708:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    970c:	54000a01 	b.ne	984c <__divti3+0x32c>  // b.any
    9710:	d1000420 	sub	x0, x1, #0x1
    9714:	d2800001 	mov	x1, #0x0                   	// #0
    9718:	17ffffb4 	b	95e8 <__divti3+0xc8>
    971c:	b5000062 	cbnz	x2, 9728 <__divti3+0x208>
    9720:	d2800022 	mov	x2, #0x1                   	// #1
    9724:	9ac30846 	udiv	x6, x2, x3
    9728:	dac010c8 	clz	x8, x6
    972c:	b5000408 	cbnz	x8, 97ac <__divti3+0x28c>
    9730:	d360fcc9 	lsr	x9, x6, #32
    9734:	92407cc5 	and	x5, x6, #0xffffffff
    9738:	cb060023 	sub	x3, x1, x6
    973c:	d2800021 	mov	x1, #0x1                   	// #1
    9740:	9ac90868 	udiv	x8, x3, x9
    9744:	9b098d03 	msub	x3, x8, x9, x3
    9748:	aa0803e0 	mov	x0, x8
    974c:	9b057d02 	mul	x2, x8, x5
    9750:	93c78063 	extr	x3, x3, x7, #32
    9754:	eb03005f 	cmp	x2, x3
    9758:	540000a9 	b.ls	976c <__divti3+0x24c>  // b.plast
    975c:	ab0300c3 	adds	x3, x6, x3
    9760:	d1000500 	sub	x0, x8, #0x1
    9764:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    9768:	54000968 	b.hi	9894 <__divti3+0x374>  // b.pmore
    976c:	cb020063 	sub	x3, x3, x2
    9770:	9ac90862 	udiv	x2, x3, x9
    9774:	aa0203e8 	mov	x8, x2
    9778:	9b098c42 	msub	x2, x2, x9, x3
    977c:	aa0703e3 	mov	x3, x7
    9780:	9b057d05 	mul	x5, x8, x5
    9784:	b3607c43 	bfi	x3, x2, #32, #32
    9788:	eb0300bf 	cmp	x5, x3
    978c:	540000c9 	b.ls	97a4 <__divti3+0x284>  // b.plast
    9790:	ab0300c2 	adds	x2, x6, x3
    9794:	d1000503 	sub	x3, x8, #0x1
    9798:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    979c:	d1000908 	sub	x8, x8, #0x2
    97a0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    97a4:	aa008100 	orr	x0, x8, x0, lsl #32
    97a8:	17ffff90 	b	95e8 <__divti3+0xc8>
    97ac:	9ac820c6 	lsl	x6, x6, x8
    97b0:	d2800803 	mov	x3, #0x40                  	// #64
    97b4:	cb080063 	sub	x3, x3, x8
    97b8:	d360fcc9 	lsr	x9, x6, #32
    97bc:	9ac82027 	lsl	x7, x1, x8
    97c0:	92407cc5 	and	x5, x6, #0xffffffff
    97c4:	9ac32422 	lsr	x2, x1, x3
    97c8:	9ac32403 	lsr	x3, x0, x3
    97cc:	aa070063 	orr	x3, x3, x7
    97d0:	9ac9084a 	udiv	x10, x2, x9
    97d4:	9ac82007 	lsl	x7, x0, x8
    97d8:	9b098940 	msub	x0, x10, x9, x2
    97dc:	aa0a03e1 	mov	x1, x10
    97e0:	9b0a7ca2 	mul	x2, x5, x10
    97e4:	93c38000 	extr	x0, x0, x3, #32
    97e8:	eb00005f 	cmp	x2, x0
    97ec:	540000a9 	b.ls	9800 <__divti3+0x2e0>  // b.plast
    97f0:	ab0000c0 	adds	x0, x6, x0
    97f4:	d1000541 	sub	x1, x10, #0x1
    97f8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    97fc:	54000468 	b.hi	9888 <__divti3+0x368>  // b.pmore
    9800:	cb020000 	sub	x0, x0, x2
    9804:	9ac9080a 	udiv	x10, x0, x9
    9808:	9b098140 	msub	x0, x10, x9, x0
    980c:	aa0a03e2 	mov	x2, x10
    9810:	9b0a7ca8 	mul	x8, x5, x10
    9814:	b3607c03 	bfi	x3, x0, #32, #32
    9818:	eb03011f 	cmp	x8, x3
    981c:	540000a9 	b.ls	9830 <__divti3+0x310>  // b.plast
    9820:	ab0300c3 	adds	x3, x6, x3
    9824:	d1000542 	sub	x2, x10, #0x1
    9828:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    982c:	54000288 	b.hi	987c <__divti3+0x35c>  // b.pmore
    9830:	cb080063 	sub	x3, x3, x8
    9834:	aa018041 	orr	x1, x2, x1, lsl #32
    9838:	17ffffc2 	b	9740 <__divti3+0x220>
    983c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    9840:	d2800001 	mov	x1, #0x0                   	// #0
    9844:	9a9f87e0 	cset	x0, ls	// ls = plast
    9848:	17ffff68 	b	95e8 <__divti3+0xc8>
    984c:	aa0103e0 	mov	x0, x1
    9850:	d2800001 	mov	x1, #0x0                   	// #0
    9854:	17ffff65 	b	95e8 <__divti3+0xc8>
    9858:	d1000860 	sub	x0, x3, #0x2
    985c:	8b0600a5 	add	x5, x5, x6
    9860:	17ffff52 	b	95a8 <__divti3+0x88>
    9864:	d1000961 	sub	x1, x11, #0x2
    9868:	8b0800a5 	add	x5, x5, x8
    986c:	17ffff85 	b	9680 <__divti3+0x160>
    9870:	d1000965 	sub	x5, x11, #0x2
    9874:	8b080063 	add	x3, x3, x8
    9878:	17ffff8e 	b	96b0 <__divti3+0x190>
    987c:	d1000942 	sub	x2, x10, #0x2
    9880:	8b060063 	add	x3, x3, x6
    9884:	17ffffeb 	b	9830 <__divti3+0x310>
    9888:	d1000941 	sub	x1, x10, #0x2
    988c:	8b060000 	add	x0, x0, x6
    9890:	17ffffdc 	b	9800 <__divti3+0x2e0>
    9894:	d1000900 	sub	x0, x8, #0x2
    9898:	8b060063 	add	x3, x3, x6
    989c:	17ffffb4 	b	976c <__divti3+0x24c>

00000000000098a0 <__modti3>:
    98a0:	d503245f 	bti	c
    98a4:	d2800004 	mov	x4, #0x0                   	// #0
    98a8:	b6f80081 	tbz	x1, #63, 98b8 <__modti3+0x18>
    98ac:	eb0003e0 	negs	x0, x0
    98b0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    98b4:	da0103e1 	ngc	x1, x1
    98b8:	f100007f 	cmp	x3, #0x0
    98bc:	5400128b 	b.lt	9b0c <__modti3+0x26c>  // b.tstop
    98c0:	aa0003e7 	mov	x7, x0
    98c4:	aa0103e6 	mov	x6, x1
    98c8:	540004e1 	b.ne	9964 <__modti3+0xc4>  // b.any
    98cc:	eb02003f 	cmp	x1, x2
    98d0:	54000dc2 	b.cs	9a88 <__modti3+0x1e8>  // b.hs, b.nlast
    98d4:	dac01043 	clz	x3, x2
    98d8:	aa0303e5 	mov	x5, x3
    98dc:	b40000e3 	cbz	x3, 98f8 <__modti3+0x58>
    98e0:	4b0303e6 	neg	w6, w3
    98e4:	9ac32021 	lsl	x1, x1, x3
    98e8:	9ac32042 	lsl	x2, x2, x3
    98ec:	9ac62406 	lsr	x6, x0, x6
    98f0:	aa0100c6 	orr	x6, x6, x1
    98f4:	9ac32007 	lsl	x7, x0, x3
    98f8:	d360fc40 	lsr	x0, x2, #32
    98fc:	92407c43 	and	x3, x2, #0xffffffff
    9900:	9ac008c1 	udiv	x1, x6, x0
    9904:	9b009826 	msub	x6, x1, x0, x6
    9908:	9b017c61 	mul	x1, x3, x1
    990c:	93c780c6 	extr	x6, x6, x7, #32
    9910:	eb06003f 	cmp	x1, x6
    9914:	540000a9 	b.ls	9928 <__modti3+0x88>  // b.plast
    9918:	ab060046 	adds	x6, x2, x6
    991c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    9920:	8b0200c8 	add	x8, x6, x2
    9924:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    9928:	cb0100c6 	sub	x6, x6, x1
    992c:	9ac008c8 	udiv	x8, x6, x0
    9930:	9b009901 	msub	x1, x8, x0, x6
    9934:	aa0703e0 	mov	x0, x7
    9938:	9b087c63 	mul	x3, x3, x8
    993c:	b3607c20 	bfi	x0, x1, #32, #32
    9940:	eb00007f 	cmp	x3, x0
    9944:	54001088 	b.hi	9b54 <__modti3+0x2b4>  // b.pmore
    9948:	cb030000 	sub	x0, x0, x3
    994c:	9ac52400 	lsr	x0, x0, x5
    9950:	d2800001 	mov	x1, #0x0                   	// #0
    9954:	b4000064 	cbz	x4, 9960 <__modti3+0xc0>
    9958:	eb0003e0 	negs	x0, x0
    995c:	da0103e1 	ngc	x1, x1
    9960:	d65f03c0 	ret
    9964:	dac01066 	clz	x6, x3
    9968:	eb03003f 	cmp	x1, x3
    996c:	54ffff43 	b.cc	9954 <__modti3+0xb4>  // b.lo, b.ul, b.last
    9970:	93407cc5 	sxtw	x5, w6
    9974:	d2800808 	mov	x8, #0x40                  	// #64
    9978:	cb050108 	sub	x8, x8, x5
    997c:	9ac62063 	lsl	x3, x3, x6
    9980:	9ac62025 	lsl	x5, x1, x6
    9984:	9ac82447 	lsr	x7, x2, x8
    9988:	aa0300e7 	orr	x7, x7, x3
    998c:	9ac82423 	lsr	x3, x1, x8
    9990:	92407cec 	and	x12, x7, #0xffffffff
    9994:	d360fcea 	lsr	x10, x7, #32
    9998:	9ac82401 	lsr	x1, x0, x8
    999c:	aa050021 	orr	x1, x1, x5
    99a0:	9ac62042 	lsl	x2, x2, x6
    99a4:	9ac62000 	lsl	x0, x0, x6
    99a8:	9aca086b 	udiv	x11, x3, x10
    99ac:	9b0a8d63 	msub	x3, x11, x10, x3
    99b0:	aa0b03e5 	mov	x5, x11
    99b4:	9b0b7d89 	mul	x9, x12, x11
    99b8:	93c18063 	extr	x3, x3, x1, #32
    99bc:	eb03013f 	cmp	x9, x3
    99c0:	540000a9 	b.ls	99d4 <__modti3+0x134>  // b.plast
    99c4:	ab0300e3 	adds	x3, x7, x3
    99c8:	d1000565 	sub	x5, x11, #0x1
    99cc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    99d0:	54001168 	b.hi	9bfc <__modti3+0x35c>  // b.pmore
    99d4:	cb090063 	sub	x3, x3, x9
    99d8:	9aca086b 	udiv	x11, x3, x10
    99dc:	9b0a8d6a 	msub	x10, x11, x10, x3
    99e0:	aa0b03e9 	mov	x9, x11
    99e4:	9b0b7d8c 	mul	x12, x12, x11
    99e8:	b3607d41 	bfi	x1, x10, #32, #32
    99ec:	eb01019f 	cmp	x12, x1
    99f0:	540000a9 	b.ls	9a04 <__modti3+0x164>  // b.plast
    99f4:	ab0100e1 	adds	x1, x7, x1
    99f8:	d1000569 	sub	x9, x11, #0x1
    99fc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    9a00:	54000f88 	b.hi	9bf0 <__modti3+0x350>  // b.pmore
    9a04:	aa058123 	orr	x3, x9, x5, lsl #32
    9a08:	92407c4b 	and	x11, x2, #0xffffffff
    9a0c:	2a0903e9 	mov	w9, w9
    9a10:	d360fc4a 	lsr	x10, x2, #32
    9a14:	d360fc63 	lsr	x3, x3, #32
    9a18:	cb0c0021 	sub	x1, x1, x12
    9a1c:	aa0a03ec 	mov	x12, x10
    9a20:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    9a24:	9b0b7d25 	mul	x5, x9, x11
    9a28:	9b0b7c6b 	mul	x11, x3, x11
    9a2c:	9b0a2d29 	madd	x9, x9, x10, x11
    9a30:	92407caa 	and	x10, x5, #0xffffffff
    9a34:	9b0c7c63 	mul	x3, x3, x12
    9a38:	8b458125 	add	x5, x9, x5, lsr #32
    9a3c:	8b0d0069 	add	x9, x3, x13
    9a40:	eb05017f 	cmp	x11, x5
    9a44:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    9a48:	8b058149 	add	x9, x10, x5, lsl #32
    9a4c:	8b458063 	add	x3, x3, x5, lsr #32
    9a50:	eb03003f 	cmp	x1, x3
    9a54:	54000063 	b.cc	9a60 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    9a58:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    9a5c:	54000082 	b.cs	9a6c <__modti3+0x1cc>  // b.hs, b.nlast
    9a60:	eb020129 	subs	x9, x9, x2
    9a64:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    9a68:	cb070063 	sub	x3, x3, x7
    9a6c:	eb090000 	subs	x0, x0, x9
    9a70:	da030021 	sbc	x1, x1, x3
    9a74:	9ac62400 	lsr	x0, x0, x6
    9a78:	9ac82028 	lsl	x8, x1, x8
    9a7c:	aa000100 	orr	x0, x8, x0
    9a80:	9ac62421 	lsr	x1, x1, x6
    9a84:	17ffffb4 	b	9954 <__modti3+0xb4>
    9a88:	b5000062 	cbnz	x2, 9a94 <__modti3+0x1f4>
    9a8c:	d2800023 	mov	x3, #0x1                   	// #1
    9a90:	9ac20862 	udiv	x2, x3, x2
    9a94:	dac01048 	clz	x8, x2
    9a98:	aa0803e5 	mov	x5, x8
    9a9c:	b5000668 	cbnz	x8, 9b68 <__modti3+0x2c8>
    9aa0:	cb020020 	sub	x0, x1, x2
    9aa4:	d360fc49 	lsr	x9, x2, #32
    9aa8:	92407c4a 	and	x10, x2, #0xffffffff
    9aac:	9ac90801 	udiv	x1, x0, x9
    9ab0:	9b098020 	msub	x0, x1, x9, x0
    9ab4:	9b0a7c21 	mul	x1, x1, x10
    9ab8:	93c78000 	extr	x0, x0, x7, #32
    9abc:	eb00003f 	cmp	x1, x0
    9ac0:	540000a9 	b.ls	9ad4 <__modti3+0x234>  // b.plast
    9ac4:	ab000040 	adds	x0, x2, x0
    9ac8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9acc:	8b020003 	add	x3, x0, x2
    9ad0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9ad4:	cb010001 	sub	x1, x0, x1
    9ad8:	9ac90820 	udiv	x0, x1, x9
    9adc:	9b098403 	msub	x3, x0, x9, x1
    9ae0:	aa0703e1 	mov	x1, x7
    9ae4:	9b0a7c00 	mul	x0, x0, x10
    9ae8:	b3607c61 	bfi	x1, x3, #32, #32
    9aec:	eb01001f 	cmp	x0, x1
    9af0:	540000a9 	b.ls	9b04 <__modti3+0x264>  // b.plast
    9af4:	ab010041 	adds	x1, x2, x1
    9af8:	8b020022 	add	x2, x1, x2
    9afc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9b00:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9b04:	cb000020 	sub	x0, x1, x0
    9b08:	17ffff91 	b	994c <__modti3+0xac>
    9b0c:	eb0203e5 	negs	x5, x2
    9b10:	aa0003e7 	mov	x7, x0
    9b14:	da0303e8 	ngc	x8, x3
    9b18:	aa0503e2 	mov	x2, x5
    9b1c:	aa0803e3 	mov	x3, x8
    9b20:	aa0103e6 	mov	x6, x1
    9b24:	b4ffed48 	cbz	x8, 98cc <__modti3+0x2c>
    9b28:	eb01011f 	cmp	x8, x1
    9b2c:	54fff148 	b.hi	9954 <__modti3+0xb4>  // b.pmore
    9b30:	dac01109 	clz	x9, x8
    9b34:	2a0903e6 	mov	w6, w9
    9b38:	b5fff1c9 	cbnz	x9, 9970 <__modti3+0xd0>
    9b3c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9b40:	54000068 	b.hi	9b4c <__modti3+0x2ac>  // b.pmore
    9b44:	eb050007 	subs	x7, x0, x5
    9b48:	da080021 	sbc	x1, x1, x8
    9b4c:	aa0703e0 	mov	x0, x7
    9b50:	17ffff81 	b	9954 <__modti3+0xb4>
    9b54:	ab000040 	adds	x0, x2, x0
    9b58:	8b020002 	add	x2, x0, x2
    9b5c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    9b60:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    9b64:	17ffff79 	b	9948 <__modti3+0xa8>
    9b68:	9ac82042 	lsl	x2, x2, x8
    9b6c:	d2800803 	mov	x3, #0x40                  	// #64
    9b70:	cb080063 	sub	x3, x3, x8
    9b74:	d360fc49 	lsr	x9, x2, #32
    9b78:	9ac82027 	lsl	x7, x1, x8
    9b7c:	92407c4a 	and	x10, x2, #0xffffffff
    9b80:	9ac32426 	lsr	x6, x1, x3
    9b84:	9ac32403 	lsr	x3, x0, x3
    9b88:	aa070063 	orr	x3, x3, x7
    9b8c:	9ac908c1 	udiv	x1, x6, x9
    9b90:	9ac82007 	lsl	x7, x0, x8
    9b94:	9b099820 	msub	x0, x1, x9, x6
    9b98:	9b017d41 	mul	x1, x10, x1
    9b9c:	93c38000 	extr	x0, x0, x3, #32
    9ba0:	eb00003f 	cmp	x1, x0
    9ba4:	540000a9 	b.ls	9bb8 <__modti3+0x318>  // b.plast
    9ba8:	ab000040 	adds	x0, x2, x0
    9bac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9bb0:	8b020006 	add	x6, x0, x2
    9bb4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    9bb8:	cb010000 	sub	x0, x0, x1
    9bbc:	9ac90801 	udiv	x1, x0, x9
    9bc0:	9b098026 	msub	x6, x1, x9, x0
    9bc4:	aa0303e0 	mov	x0, x3
    9bc8:	9b017d41 	mul	x1, x10, x1
    9bcc:	b3607cc0 	bfi	x0, x6, #32, #32
    9bd0:	eb00003f 	cmp	x1, x0
    9bd4:	540000a9 	b.ls	9be8 <__modti3+0x348>  // b.plast
    9bd8:	ab000040 	adds	x0, x2, x0
    9bdc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9be0:	8b020003 	add	x3, x0, x2
    9be4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9be8:	cb010000 	sub	x0, x0, x1
    9bec:	17ffffb0 	b	9aac <__modti3+0x20c>
    9bf0:	d1000969 	sub	x9, x11, #0x2
    9bf4:	8b070021 	add	x1, x1, x7
    9bf8:	17ffff83 	b	9a04 <__modti3+0x164>
    9bfc:	d1000965 	sub	x5, x11, #0x2
    9c00:	8b070063 	add	x3, x3, x7
    9c04:	17ffff74 	b	99d4 <__modti3+0x134>
    9c08:	d503201f 	nop
    9c0c:	d503201f 	nop

0000000000009c10 <atexit>:
    9c10:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9c14:	f00000a2 	adrp	x2, 20000 <__data_start>
    9c18:	d2800001 	mov	x1, #0x0                   	// #0
    9c1c:	910003fd 	mov	x29, sp
    9c20:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9c24:	f9400442 	ldr	x2, [x2, #8]
    9c28:	17ffe2ce 	b	2760 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000009c2c <_fini>:
    9c2c:	d503201f 	nop
    9c30:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9c34:	910003fd 	mov	x29, sp
    9c38:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9c3c:	d65f03c0 	ret
