
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-0/fwp-explicit-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001370 <_init>:
    1370:	d503201f 	nop
    1374:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1378:	910003fd 	mov	x29, sp
    137c:	9400018e 	bl	19b4 <call_weak_fn>
    1380:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1384:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001390 <.plt>:
    1390:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1394:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1398:	f946fe11 	ldr	x17, [x16, #3576]
    139c:	9137e210 	add	x16, x16, #0xdf8
    13a0:	d61f0220 	br	x17
    13a4:	d503201f 	nop
    13a8:	d503201f 	nop
    13ac:	d503201f 	nop

00000000000013b0 <memcpy@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    13b4:	f9470211 	ldr	x17, [x16, #3584]
    13b8:	91380210 	add	x16, x16, #0xe00
    13bc:	d61f0220 	br	x17

00000000000013c0 <sigaltstack@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    13c4:	f9470611 	ldr	x17, [x16, #3592]
    13c8:	91382210 	add	x16, x16, #0xe08
    13cc:	d61f0220 	br	x17

00000000000013d0 <_exit@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    13d4:	f9470a11 	ldr	x17, [x16, #3600]
    13d8:	91384210 	add	x16, x16, #0xe10
    13dc:	d61f0220 	br	x17

00000000000013e0 <strlen@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    13e4:	f9470e11 	ldr	x17, [x16, #3608]
    13e8:	91386210 	add	x16, x16, #0xe18
    13ec:	d61f0220 	br	x17

00000000000013f0 <__sprintf_chk@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    13f4:	f9471211 	ldr	x17, [x16, #3616]
    13f8:	91388210 	add	x16, x16, #0xe20
    13fc:	d61f0220 	br	x17

0000000000001400 <exit@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1404:	f9471611 	ldr	x17, [x16, #3624]
    1408:	9138a210 	add	x16, x16, #0xe28
    140c:	d61f0220 	br	x17

0000000000001410 <__libc_start_main@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1414:	f9471a11 	ldr	x17, [x16, #3632]
    1418:	9138c210 	add	x16, x16, #0xe30
    141c:	d61f0220 	br	x17

0000000000001420 <strtoll@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1424:	f9471e11 	ldr	x17, [x16, #3640]
    1428:	9138e210 	add	x16, x16, #0xe38
    142c:	d61f0220 	br	x17

0000000000001430 <strtod@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1434:	f9472211 	ldr	x17, [x16, #3648]
    1438:	91390210 	add	x16, x16, #0xe40
    143c:	d61f0220 	br	x17

0000000000001440 <__cxa_finalize@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1444:	f9472611 	ldr	x17, [x16, #3656]
    1448:	91392210 	add	x16, x16, #0xe48
    144c:	d61f0220 	br	x17

0000000000001450 <__cxa_atexit@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1454:	f9472a11 	ldr	x17, [x16, #3664]
    1458:	91394210 	add	x16, x16, #0xe50
    145c:	d61f0220 	br	x17

0000000000001460 <pthread_attr_init@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1464:	f9472e11 	ldr	x17, [x16, #3672]
    1468:	91396210 	add	x16, x16, #0xe58
    146c:	d61f0220 	br	x17

0000000000001470 <fputc@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1474:	f9473211 	ldr	x17, [x16, #3680]
    1478:	91398210 	add	x16, x16, #0xe60
    147c:	d61f0220 	br	x17

0000000000001480 <clock_gettime@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1484:	f9473611 	ldr	x17, [x16, #3688]
    1488:	9139a210 	add	x16, x16, #0xe68
    148c:	d61f0220 	br	x17

0000000000001490 <setvbuf@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1494:	f9473a11 	ldr	x17, [x16, #3696]
    1498:	9139c210 	add	x16, x16, #0xe70
    149c:	d61f0220 	br	x17

00000000000014a0 <__memcpy_chk@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    14a4:	f9473e11 	ldr	x17, [x16, #3704]
    14a8:	9139e210 	add	x16, x16, #0xe78
    14ac:	d61f0220 	br	x17

00000000000014b0 <signal@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    14b4:	f9474211 	ldr	x17, [x16, #3712]
    14b8:	913a0210 	add	x16, x16, #0xe80
    14bc:	d61f0220 	br	x17

00000000000014c0 <__snprintf_chk@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    14c4:	f9474611 	ldr	x17, [x16, #3720]
    14c8:	913a2210 	add	x16, x16, #0xe88
    14cc:	d61f0220 	br	x17

00000000000014d0 <fclose@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    14d4:	f9474a11 	ldr	x17, [x16, #3728]
    14d8:	913a4210 	add	x16, x16, #0xe90
    14dc:	d61f0220 	br	x17

00000000000014e0 <fopen@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    14e4:	f9474e11 	ldr	x17, [x16, #3736]
    14e8:	913a6210 	add	x16, x16, #0xe98
    14ec:	d61f0220 	br	x17

00000000000014f0 <malloc@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    14f4:	f9475211 	ldr	x17, [x16, #3744]
    14f8:	913a8210 	add	x16, x16, #0xea0
    14fc:	d61f0220 	br	x17

0000000000001500 <pthread_attr_destroy@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1504:	f9475611 	ldr	x17, [x16, #3752]
    1508:	913aa210 	add	x16, x16, #0xea8
    150c:	d61f0220 	br	x17

0000000000001510 <sigemptyset@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1514:	f9475a11 	ldr	x17, [x16, #3760]
    1518:	913ac210 	add	x16, x16, #0xeb0
    151c:	d61f0220 	br	x17

0000000000001520 <memset@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1524:	f9475e11 	ldr	x17, [x16, #3768]
    1528:	913ae210 	add	x16, x16, #0xeb8
    152c:	d61f0220 	br	x17

0000000000001530 <calloc@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1534:	f9476211 	ldr	x17, [x16, #3776]
    1538:	913b0210 	add	x16, x16, #0xec0
    153c:	d61f0220 	br	x17

0000000000001540 <realloc@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1544:	f9476611 	ldr	x17, [x16, #3784]
    1548:	913b2210 	add	x16, x16, #0xec8
    154c:	d61f0220 	br	x17

0000000000001550 <__stack_chk_fail@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1554:	f9476a11 	ldr	x17, [x16, #3792]
    1558:	913b4210 	add	x16, x16, #0xed0
    155c:	d61f0220 	br	x17

0000000000001560 <close@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1564:	f9476e11 	ldr	x17, [x16, #3800]
    1568:	913b6210 	add	x16, x16, #0xed8
    156c:	d61f0220 	br	x17

0000000000001570 <sigaction@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1574:	f9477211 	ldr	x17, [x16, #3808]
    1578:	913b8210 	add	x16, x16, #0xee0
    157c:	d61f0220 	br	x17

0000000000001580 <__gmon_start__@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1584:	f9477611 	ldr	x17, [x16, #3816]
    1588:	913ba210 	add	x16, x16, #0xee8
    158c:	d61f0220 	br	x17

0000000000001590 <write@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1594:	f9477a11 	ldr	x17, [x16, #3824]
    1598:	913bc210 	add	x16, x16, #0xef0
    159c:	d61f0220 	br	x17

00000000000015a0 <abort@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    15a4:	f9477e11 	ldr	x17, [x16, #3832]
    15a8:	913be210 	add	x16, x16, #0xef8
    15ac:	d61f0220 	br	x17

00000000000015b0 <swapcontext@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    15b4:	f9478211 	ldr	x17, [x16, #3840]
    15b8:	913c0210 	add	x16, x16, #0xf00
    15bc:	d61f0220 	br	x17

00000000000015c0 <__fprintf_chk@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    15c4:	f9478611 	ldr	x17, [x16, #3848]
    15c8:	913c2210 	add	x16, x16, #0xf08
    15cc:	d61f0220 	br	x17

00000000000015d0 <strcmp@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    15d4:	f9478a11 	ldr	x17, [x16, #3856]
    15d8:	913c4210 	add	x16, x16, #0xf10
    15dc:	d61f0220 	br	x17

00000000000015e0 <mmap@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    15e4:	f9478e11 	ldr	x17, [x16, #3864]
    15e8:	913c6210 	add	x16, x16, #0xf18
    15ec:	d61f0220 	br	x17

00000000000015f0 <strtol@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    15f4:	f9479211 	ldr	x17, [x16, #3872]
    15f8:	913c8210 	add	x16, x16, #0xf20
    15fc:	d61f0220 	br	x17

0000000000001600 <strtof@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1604:	f9479611 	ldr	x17, [x16, #3880]
    1608:	913ca210 	add	x16, x16, #0xf28
    160c:	d61f0220 	br	x17

0000000000001610 <free@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1614:	f9479a11 	ldr	x17, [x16, #3888]
    1618:	913cc210 	add	x16, x16, #0xf30
    161c:	d61f0220 	br	x17

0000000000001620 <nanosleep@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1624:	f9479e11 	ldr	x17, [x16, #3896]
    1628:	913ce210 	add	x16, x16, #0xf38
    162c:	d61f0220 	br	x17

0000000000001630 <strchr@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1634:	f947a211 	ldr	x17, [x16, #3904]
    1638:	913d0210 	add	x16, x16, #0xf40
    163c:	d61f0220 	br	x17

0000000000001640 <strtoull@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1644:	f947a611 	ldr	x17, [x16, #3912]
    1648:	913d2210 	add	x16, x16, #0xf48
    164c:	d61f0220 	br	x17

0000000000001650 <fwrite@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1654:	f947aa11 	ldr	x17, [x16, #3920]
    1658:	913d4210 	add	x16, x16, #0xf50
    165c:	d61f0220 	br	x17

0000000000001660 <pthread_create@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1664:	f947ae11 	ldr	x17, [x16, #3928]
    1668:	913d6210 	add	x16, x16, #0xf58
    166c:	d61f0220 	br	x17

0000000000001670 <munmap@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1674:	f947b211 	ldr	x17, [x16, #3936]
    1678:	913d8210 	add	x16, x16, #0xf60
    167c:	d61f0220 	br	x17

0000000000001680 <fflush@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1684:	f947b611 	ldr	x17, [x16, #3944]
    1688:	913da210 	add	x16, x16, #0xf68
    168c:	d61f0220 	br	x17

0000000000001690 <strcpy@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1694:	f947ba11 	ldr	x17, [x16, #3952]
    1698:	913dc210 	add	x16, x16, #0xf70
    169c:	d61f0220 	br	x17

00000000000016a0 <sysconf@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    16a4:	f947be11 	ldr	x17, [x16, #3960]
    16a8:	913de210 	add	x16, x16, #0xf78
    16ac:	d61f0220 	br	x17

00000000000016b0 <strstr@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    16b4:	f947c211 	ldr	x17, [x16, #3968]
    16b8:	913e0210 	add	x16, x16, #0xf80
    16bc:	d61f0220 	br	x17

00000000000016c0 <_Exit@plt>:
    16c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    16c4:	f947c611 	ldr	x17, [x16, #3976]
    16c8:	913e2210 	add	x16, x16, #0xf88
    16cc:	d61f0220 	br	x17

00000000000016d0 <pthread_join@plt>:
    16d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    16d4:	f947ca11 	ldr	x17, [x16, #3984]
    16d8:	913e4210 	add	x16, x16, #0xf90
    16dc:	d61f0220 	br	x17

00000000000016e0 <getenv@plt>:
    16e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    16e4:	f947ce11 	ldr	x17, [x16, #3992]
    16e8:	913e6210 	add	x16, x16, #0xf98
    16ec:	d61f0220 	br	x17

00000000000016f0 <mprotect@plt>:
    16f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    16f4:	f947d211 	ldr	x17, [x16, #4000]
    16f8:	913e8210 	add	x16, x16, #0xfa0
    16fc:	d61f0220 	br	x17

0000000000001700 <fgets@plt>:
    1700:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1704:	f947d611 	ldr	x17, [x16, #4008]
    1708:	913ea210 	add	x16, x16, #0xfa8
    170c:	d61f0220 	br	x17

0000000000001710 <pthread_attr_setstacksize@plt>:
    1710:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x165f8>
    1714:	f947da11 	ldr	x17, [x16, #4016]
    1718:	913ec210 	add	x16, x16, #0xfb0
    171c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001740 <fwp_trap_overflow.constprop.0>:
    1740:	d10243ff 	sub	sp, sp, #0x90
    1744:	d2800c03 	mov	x3, #0x60                  	// #96
    1748:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x165f8>
    174c:	f947f421 	ldr	x1, [x1, #4072]
    1750:	d0000025 	adrp	x5, 7000 <__modti3+0x1a0>
    1754:	a9077bfd 	stp	x29, x30, [sp, #112]
    1758:	9101c3fd 	add	x29, sp, #0x70
    175c:	911140a5 	add	x5, x5, #0x450
    1760:	d0000024 	adrp	x4, 7000 <__modti3+0x1a0>
    1764:	f90043f3 	str	x19, [sp, #128]
    1768:	91116084 	add	x4, x4, #0x458
    176c:	910023f3 	add	x19, sp, #0x8
    1770:	f9400022 	ldr	x2, [x1]
    1774:	f90037e2 	str	x2, [sp, #104]
    1778:	d2800002 	mov	x2, #0x0                   	// #0
    177c:	aa0303e1 	mov	x1, x3
    1780:	52800042 	mov	w2, #0x2                   	// #2
    1784:	aa1303e0 	mov	x0, x19
    1788:	97ffff4e 	bl	14c0 <__snprintf_chk@plt>
    178c:	aa1303e0 	mov	x0, x19
    1790:	940002dc 	bl	2300 <fwp_trap>
    1794:	d503201f 	nop
    1798:	d503201f 	nop
    179c:	d503201f 	nop

00000000000017a0 <main>:
    17a0:	d10243ff 	sub	sp, sp, #0x90
    17a4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    17a8:	f947f400 	ldr	x0, [x0, #4072]
    17ac:	a9067bfd 	stp	x29, x30, [sp, #96]
    17b0:	910183fd 	add	x29, sp, #0x60
    17b4:	a90753f3 	stp	x19, x20, [sp, #112]
    17b8:	f00000f3 	adrp	x19, 20000 <__data_start>
    17bc:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x165f8>
    17c0:	f947ee94 	ldr	x20, [x20, #4056]
    17c4:	f9400281 	ldr	x1, [x20]
    17c8:	f90043f5 	str	x21, [sp, #128]
    17cc:	f9400002 	ldr	x2, [x0]
    17d0:	f9002fe2 	str	x2, [sp, #88]
    17d4:	d2800002 	mov	x2, #0x0                   	// #0
    17d8:	f9002a61 	str	x1, [x19, #80]
    17dc:	940002d9 	bl	2340 <fwp_now_ns>
    17e0:	d0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    17e4:	911ce000 	add	x0, x0, #0x738
    17e8:	97ffffbe 	bl	16e0 <getenv@plt>
    17ec:	b4000080 	cbz	x0, 17fc <main+0x5c>
    17f0:	39400001 	ldrb	w1, [x0]
    17f4:	aa0003f5 	mov	x21, x0
    17f8:	35000801 	cbnz	w1, 18f8 <main+0x158>
    17fc:	910023e1 	add	x1, sp, #0x8
    1800:	52800000 	mov	w0, #0x0                   	// #0
    1804:	97ffff1f 	bl	1480 <clock_gettime@plt>
    1808:	35000900 	cbnz	w0, 1928 <main+0x188>
    180c:	a9408be0 	ldp	x0, x2, [sp, #8]
    1810:	d2994003 	mov	x3, #0xca00                	// #51712
    1814:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    1818:	9b037c01 	mul	x1, x0, x3
    181c:	9b437c00 	smulh	x0, x0, x3
    1820:	ab020021 	adds	x1, x1, x2
    1824:	937ffc42 	asr	x2, x2, #63
    1828:	9a020000 	adc	x0, x0, x2
    182c:	f100003f 	cmp	x1, #0x0
    1830:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    1834:	b50009a0 	cbnz	x0, 1968 <main+0x1c8>
    1838:	f9400280 	ldr	x0, [x20]
    183c:	d2a00023 	mov	x3, #0x10000               	// #65536
    1840:	52800002 	mov	w2, #0x0                   	// #0
    1844:	d2800001 	mov	x1, #0x0                   	// #0
    1848:	910063f5 	add	x21, sp, #0x18
    184c:	97ffff11 	bl	1490 <setvbuf@plt>
    1850:	d2800021 	mov	x1, #0x1                   	// #1
    1854:	528001a0 	mov	w0, #0xd                   	// #13
    1858:	97ffff16 	bl	14b0 <signal@plt>
    185c:	aa1503e0 	mov	x0, x21
    1860:	97ffff00 	bl	1460 <pthread_attr_init@plt>
    1864:	350007c0 	cbnz	w0, 195c <main+0x1bc>
    1868:	aa1503e0 	mov	x0, x21
    186c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    1870:	97ffffa8 	bl	1710 <pthread_attr_setstacksize@plt>
    1874:	35000680 	cbnz	w0, 1944 <main+0x1a4>
    1878:	aa1503e1 	mov	x1, x21
    187c:	910023e0 	add	x0, sp, #0x8
    1880:	90000022 	adrp	x2, 5000 <fwp_write+0x10>
    1884:	d2800003 	mov	x3, #0x0                   	// #0
    1888:	913f8042 	add	x2, x2, #0xfe0
    188c:	97ffff75 	bl	1660 <pthread_create@plt>
    1890:	2a0003e1 	mov	w1, w0
    1894:	aa1503e0 	mov	x0, x21
    1898:	2a0103f5 	mov	w21, w1
    189c:	97ffff19 	bl	1500 <pthread_attr_destroy@plt>
    18a0:	350006a0 	cbnz	w0, 1974 <main+0x1d4>
    18a4:	350004b5 	cbnz	w21, 1938 <main+0x198>
    18a8:	f94007e0 	ldr	x0, [sp, #8]
    18ac:	d2800001 	mov	x1, #0x0                   	// #0
    18b0:	97ffff88 	bl	16d0 <pthread_join@plt>
    18b4:	35000600 	cbnz	w0, 1974 <main+0x1d4>
    18b8:	f9400280 	ldr	x0, [x20]
    18bc:	91014273 	add	x19, x19, #0x50
    18c0:	97ffff70 	bl	1680 <fflush@plt>
    18c4:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x165f8>
    18c8:	f947f421 	ldr	x1, [x1, #4072]
    18cc:	b942da60 	ldr	w0, [x19, #728]
    18d0:	f9402fe3 	ldr	x3, [sp, #88]
    18d4:	f9400022 	ldr	x2, [x1]
    18d8:	eb020063 	subs	x3, x3, x2
    18dc:	d2800002 	mov	x2, #0x0                   	// #0
    18e0:	540002a1 	b.ne	1934 <main+0x194>  // b.any
    18e4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    18e8:	a94753f3 	ldp	x19, x20, [sp, #112]
    18ec:	f94043f5 	ldr	x21, [sp, #128]
    18f0:	910243ff 	add	sp, sp, #0x90
    18f4:	d65f03c0 	ret
    18f8:	910003e1 	mov	x1, sp
    18fc:	52800142 	mov	w2, #0xa                   	// #10
    1900:	97ffff50 	bl	1640 <strtoull@plt>
    1904:	f94003e0 	ldr	x0, [sp]
    1908:	39400000 	ldrb	w0, [x0]
    190c:	35fff780 	cbnz	w0, 17fc <main+0x5c>
    1910:	394002a0 	ldrb	w0, [x21]
    1914:	52801fa1 	mov	w1, #0xfd                  	// #253
    1918:	5100ac00 	sub	w0, w0, #0x2b
    191c:	6a01001f 	tst	w0, w1
    1920:	54fff6e0 	b.eq	17fc <main+0x5c>  // b.none
    1924:	17ffffc5 	b	1838 <main+0x98>
    1928:	d0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    192c:	911d2000 	add	x0, x0, #0x748
    1930:	94000274 	bl	2300 <fwp_trap>
    1934:	97ffff07 	bl	1550 <__stack_chk_fail@plt>
    1938:	d0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    193c:	911fa000 	add	x0, x0, #0x7e8
    1940:	94000270 	bl	2300 <fwp_trap>
    1944:	aa1503e0 	mov	x0, x21
    1948:	97fffeee 	bl	1500 <pthread_attr_destroy@plt>
    194c:	35000140 	cbnz	w0, 1974 <main+0x1d4>
    1950:	d0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    1954:	911f0000 	add	x0, x0, #0x7c0
    1958:	9400026a 	bl	2300 <fwp_trap>
    195c:	d0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    1960:	911e4000 	add	x0, x0, #0x790
    1964:	94000267 	bl	2300 <fwp_trap>
    1968:	d0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    196c:	911da000 	add	x0, x0, #0x768
    1970:	94000264 	bl	2300 <fwp_trap>
    1974:	97ffff0b 	bl	15a0 <abort@plt>
    1978:	d503201f 	nop
    197c:	d503201f 	nop

0000000000001980 <_start>:
    1980:	d503201f 	nop
    1984:	d280001d 	mov	x29, #0x0                   	// #0
    1988:	d280001e 	mov	x30, #0x0                   	// #0
    198c:	aa0003e5 	mov	x5, x0
    1990:	f94003e1 	ldr	x1, [sp]
    1994:	910023e2 	add	x2, sp, #0x8
    1998:	910003e6 	mov	x6, sp
    199c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    19a0:	f947f800 	ldr	x0, [x0, #4080]
    19a4:	d2800003 	mov	x3, #0x0                   	// #0
    19a8:	d2800004 	mov	x4, #0x0                   	// #0
    19ac:	97fffe99 	bl	1410 <__libc_start_main@plt>
    19b0:	97fffefc 	bl	15a0 <abort@plt>

00000000000019b4 <call_weak_fn>:
    19b4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    19b8:	f947f000 	ldr	x0, [x0, #4064]
    19bc:	b4000040 	cbz	x0, 19c4 <call_weak_fn+0x10>
    19c0:	17fffef0 	b	1580 <__gmon_start__@plt>
    19c4:	d65f03c0 	ret
    19c8:	d503201f 	nop
    19cc:	d503201f 	nop

00000000000019d0 <deregister_tm_clones>:
    19d0:	f00000e0 	adrp	x0, 20000 <__data_start>
    19d4:	9100e000 	add	x0, x0, #0x38
    19d8:	f00000e1 	adrp	x1, 20000 <__data_start>
    19dc:	9100e021 	add	x1, x1, #0x38
    19e0:	eb00003f 	cmp	x1, x0
    19e4:	540000c0 	b.eq	19fc <deregister_tm_clones+0x2c>  // b.none
    19e8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x165f8>
    19ec:	f947e021 	ldr	x1, [x1, #4032]
    19f0:	b4000061 	cbz	x1, 19fc <deregister_tm_clones+0x2c>
    19f4:	aa0103f0 	mov	x16, x1
    19f8:	d61f0200 	br	x16
    19fc:	d65f03c0 	ret

0000000000001a00 <register_tm_clones>:
    1a00:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a04:	9100e000 	add	x0, x0, #0x38
    1a08:	f00000e1 	adrp	x1, 20000 <__data_start>
    1a0c:	9100e021 	add	x1, x1, #0x38
    1a10:	cb000021 	sub	x1, x1, x0
    1a14:	d37ffc22 	lsr	x2, x1, #63
    1a18:	8b810c41 	add	x1, x2, x1, asr #3
    1a1c:	9341fc21 	asr	x1, x1, #1
    1a20:	b40000c1 	cbz	x1, 1a38 <register_tm_clones+0x38>
    1a24:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x165f8>
    1a28:	f947fc42 	ldr	x2, [x2, #4088]
    1a2c:	b4000062 	cbz	x2, 1a38 <register_tm_clones+0x38>
    1a30:	aa0203f0 	mov	x16, x2
    1a34:	d61f0200 	br	x16
    1a38:	d65f03c0 	ret
    1a3c:	d503201f 	nop

0000000000001a40 <__do_global_dtors_aux>:
    1a40:	d503233f 	paciasp
    1a44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1a48:	910003fd 	mov	x29, sp
    1a4c:	f9000bf3 	str	x19, [sp, #16]
    1a50:	f00000f3 	adrp	x19, 20000 <__data_start>
    1a54:	39410260 	ldrb	w0, [x19, #64]
    1a58:	37000140 	tbnz	w0, #0, 1a80 <__do_global_dtors_aux+0x40>
    1a5c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    1a60:	f947e400 	ldr	x0, [x0, #4040]
    1a64:	b4000080 	cbz	x0, 1a74 <__do_global_dtors_aux+0x34>
    1a68:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a6c:	f9400400 	ldr	x0, [x0, #8]
    1a70:	97fffe74 	bl	1440 <__cxa_finalize@plt>
    1a74:	97ffffd7 	bl	19d0 <deregister_tm_clones>
    1a78:	52800020 	mov	w0, #0x1                   	// #1
    1a7c:	39010260 	strb	w0, [x19, #64]
    1a80:	f9400bf3 	ldr	x19, [sp, #16]
    1a84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a88:	d50323bf 	autiasp
    1a8c:	d65f03c0 	ret

0000000000001a90 <frame_dummy>:
    1a90:	d503245f 	bti	c
    1a94:	17ffffdb 	b	1a00 <register_tm_clones>
    1a98:	d503201f 	nop
    1a9c:	d503201f 	nop

0000000000001aa0 <fwp_fmt_u128>:
    1aa0:	d10183ff 	sub	sp, sp, #0x60
    1aa4:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x165f8>
    1aa8:	f947f421 	ldr	x1, [x1, #4072]
    1aac:	a9057bfd 	stp	x29, x30, [sp, #80]
    1ab0:	910143fd 	add	x29, sp, #0x50
    1ab4:	f9400024 	ldr	x4, [x1]
    1ab8:	f90027e4 	str	x4, [sp, #72]
    1abc:	d2800004 	mov	x4, #0x0                   	// #0
    1ac0:	aa030041 	orr	x1, x2, x3
    1ac4:	b5000361 	cbnz	x1, 1b30 <fwp_fmt_u128+0x90>
    1ac8:	910023e9 	add	x9, sp, #0x8
    1acc:	52800601 	mov	w1, #0x30                  	// #48
    1ad0:	5280002d 	mov	w13, #0x1                   	// #1
    1ad4:	390023e1 	strb	w1, [sp, #8]
    1ad8:	93407dad 	sxtw	x13, w13
    1adc:	aa0d03e1 	mov	x1, x13
    1ae0:	8b0d0004 	add	x4, x0, x13
    1ae4:	d503201f 	nop
    1ae8:	8b010123 	add	x3, x9, x1
    1aec:	cb0103e2 	neg	x2, x1
    1af0:	d1000421 	sub	x1, x1, #0x1
    1af4:	385ff063 	ldurb	w3, [x3, #-1]
    1af8:	38226883 	strb	w3, [x4, x2]
    1afc:	35ffff61 	cbnz	w1, 1ae8 <fwp_fmt_u128+0x48>
    1b00:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x165f8>
    1b04:	f947f421 	ldr	x1, [x1, #4072]
    1b08:	382d681f 	strb	wzr, [x0, x13]
    1b0c:	aa0103e0 	mov	x0, x1
    1b10:	f94027e2 	ldr	x2, [sp, #72]
    1b14:	f9400001 	ldr	x1, [x0]
    1b18:	eb010042 	subs	x2, x2, x1
    1b1c:	d2800001 	mov	x1, #0x0                   	// #0
    1b20:	54000561 	b.ne	1bcc <fwp_fmt_u128+0x12c>  // b.any
    1b24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1b28:	910183ff 	add	sp, sp, #0x60
    1b2c:	d65f03c0 	ret
    1b30:	d0000021 	adrp	x1, 7000 <__modti3+0x1a0>
    1b34:	91234021 	add	x1, x1, #0x8d0
    1b38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1b3c:	910023e9 	add	x9, sp, #0x8
    1b40:	d2800027 	mov	x7, #0x1                   	// #1
    1b44:	f29999af 	movk	x15, #0xcccd
    1b48:	a9402826 	ldp	x6, x10, [x1]
    1b4c:	d503201f 	nop
    1b50:	ab030041 	adds	x1, x2, x3
    1b54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1b58:	aa0303eb 	mov	x11, x3
    1b5c:	8b070128 	add	x8, x9, x7
    1b60:	aa0203ee 	mov	x14, x2
    1b64:	aa0703ed 	mov	x13, x7
    1b68:	910004e7 	add	x7, x7, #0x1
    1b6c:	9bcf7c24 	umulh	x4, x1, x15
    1b70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1b74:	8b4408a4 	add	x4, x5, x4, lsr #2
    1b78:	cb040021 	sub	x1, x1, x4
    1b7c:	eb010041 	subs	x1, x2, x1
    1b80:	da1f0063 	sbc	x3, x3, xzr
    1b84:	9bc67c24 	umulh	x4, x1, x6
    1b88:	9b061064 	madd	x4, x3, x6, x4
    1b8c:	9b067c2c 	mul	x12, x1, x6
    1b90:	9b0a1024 	madd	x4, x1, x10, x4
    1b94:	9bc67c25 	umulh	x5, x1, x6
    1b98:	9b061465 	madd	x5, x3, x6, x5
    1b9c:	9b0a1425 	madd	x5, x1, x10, x5
    1ba0:	93cc0484 	extr	x4, x4, x12, #1
    1ba4:	8b040884 	add	x4, x4, x4, lsl #2
    1ba8:	d341fca3 	lsr	x3, x5, #1
    1bac:	cb040444 	sub	x4, x2, x4, lsl #1
    1bb0:	93cc04a2 	extr	x2, x5, x12, #1
    1bb4:	1100c084 	add	w4, w4, #0x30
    1bb8:	381ff104 	sturb	w4, [x8, #-1]
    1bbc:	b5fffcab 	cbnz	x11, 1b50 <fwp_fmt_u128+0xb0>
    1bc0:	f10025df 	cmp	x14, #0x9
    1bc4:	54fffc68 	b.hi	1b50 <fwp_fmt_u128+0xb0>  // b.pmore
    1bc8:	17ffffc4 	b	1ad8 <fwp_fmt_u128+0x38>
    1bcc:	97fffe61 	bl	1550 <__stack_chk_fail@plt>

0000000000001bd0 <fwp_range_release>:
    1bd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1bd4:	910003fd 	mov	x29, sp
    1bd8:	f9400801 	ldr	x1, [x0, #16]
    1bdc:	f9000bf3 	str	x19, [sp, #16]
    1be0:	aa0003f3 	mov	x19, x0
    1be4:	b4000061 	cbz	x1, 1bf0 <fwp_range_release+0x20>
    1be8:	f9400400 	ldr	x0, [x0, #8]
    1bec:	d63f0020 	blr	x1
    1bf0:	f9400260 	ldr	x0, [x19]
    1bf4:	f9400e61 	ldr	x1, [x19, #24]
    1bf8:	f9400bf3 	ldr	x19, [sp, #16]
    1bfc:	aa0103f0 	mov	x16, x1
    1c00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1c04:	d61f0200 	br	x16
    1c08:	d503201f 	nop
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_owned_entry32>:
    1c10:	6d400001 	ldp	d1, d0, [x0]
    1c14:	1e613800 	fsub	d0, d0, d1
    1c18:	9e660000 	fmov	x0, d0
    1c1c:	d65f03c0 	ret

0000000000001c20 <fwp_args32>:
    1c20:	d65f03c0 	ret

0000000000001c24 <fwp_owned_entry45>:
    1c24:	6d400400 	ldp	d0, d1, [x0]
    1c28:	1e612800 	fadd	d0, d0, d1
    1c2c:	9e660000 	fmov	x0, d0
    1c30:	d65f03c0 	ret

0000000000001c34 <fwp_owned_entry69>:
    1c34:	d0000021 	adrp	x1, 7000 <__modti3+0x1a0>
    1c38:	fd400001 	ldr	d1, [x0]
    1c3c:	fd448020 	ldr	d0, [x1, #2304]
    1c40:	1e610800 	fmul	d0, d0, d1
    1c44:	9e660000 	fmov	x0, d0
    1c48:	d65f03c0 	ret
    1c4c:	d503201f 	nop

0000000000001c50 <fwp_flush>:
    1c50:	f00000e0 	adrp	x0, 20000 <__data_start>
    1c54:	f9402800 	ldr	x0, [x0, #80]
    1c58:	b4000120 	cbz	x0, 1c7c <fwp_flush+0x2c>
    1c5c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1c60:	910003fd 	mov	x29, sp
    1c64:	97fffe87 	bl	1680 <fflush@plt>
    1c68:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    1c6c:	f947ec00 	ldr	x0, [x0, #4056]
    1c70:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1c74:	f9400000 	ldr	x0, [x0]
    1c78:	17fffe82 	b	1680 <fflush@plt>
    1c7c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    1c80:	f947ec00 	ldr	x0, [x0, #4056]
    1c84:	f9400000 	ldr	x0, [x0]
    1c88:	17fffe7e 	b	1680 <fflush@plt>
    1c8c:	d503201f 	nop

0000000000001c90 <fwp_segv>:
    1c90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c94:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c98:	91014043 	add	x3, x2, #0x50
    1c9c:	910003fd 	mov	x29, sp
    1ca0:	a90153f3 	stp	x19, x20, [sp, #16]
    1ca4:	2a0003f3 	mov	w19, w0
    1ca8:	f9400460 	ldr	x0, [x3, #8]
    1cac:	f90013f5 	str	x21, [sp, #32]
    1cb0:	f9400835 	ldr	x21, [x1, #16]
    1cb4:	b4000280 	cbz	x0, 1d04 <fwp_segv+0x74>
    1cb8:	f9400814 	ldr	x20, [x0, #16]
    1cbc:	b4000254 	cbz	x20, 1d04 <fwp_segv+0x74>
    1cc0:	528003c0 	mov	w0, #0x1e                  	// #30
    1cc4:	97fffe77 	bl	16a0 <sysconf@plt>
    1cc8:	f144029f 	cmp	x20, #0x100, lsl #12
    1ccc:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1cd0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1cd4:	8b000294 	add	x20, x20, x0
    1cd8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1cdc:	eb0102bf 	cmp	x21, x1
    1ce0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1ce4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1ce8:	35000240 	cbnz	w0, 1d30 <fwp_segv+0xa0>
    1cec:	f94013f5 	ldr	x21, [sp, #32]
    1cf0:	2a1303e0 	mov	w0, w19
    1cf4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1cf8:	d2800001 	mov	x1, #0x0                   	// #0
    1cfc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1d00:	17fffdec 	b	14b0 <signal@plt>
    1d04:	91014042 	add	x2, x2, #0x50
    1d08:	f9400840 	ldr	x0, [x2, #16]
    1d0c:	b4ffff00 	cbz	x0, 1cec <fwp_segv+0x5c>
    1d10:	f9400c41 	ldr	x1, [x2, #24]
    1d14:	cb010000 	sub	x0, x0, x1
    1d18:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1d1c:	91440000 	add	x0, x0, #0x100, lsl #12
    1d20:	eb15003f 	cmp	x1, x21
    1d24:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1d28:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1d2c:	34fffe00 	cbz	w0, 1cec <fwp_segv+0x5c>
    1d30:	97ffffc8 	bl	1c50 <fwp_flush>
    1d34:	d0000021 	adrp	x1, 7000 <__modti3+0x1a0>
    1d38:	9122c021 	add	x1, x1, #0x8b0
    1d3c:	d2800342 	mov	x2, #0x1a                  	// #26
    1d40:	52800040 	mov	w0, #0x2                   	// #2
    1d44:	97fffe13 	bl	1590 <write@plt>
    1d48:	52800ca0 	mov	w0, #0x65                  	// #101
    1d4c:	97fffda1 	bl	13d0 <_exit@plt>

0000000000001d50 <fwp_heap_oom>:
    1d50:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x165f8>
    1d54:	f947e863 	ldr	x3, [x3, #4048]
    1d58:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1d5c:	d2800262 	mov	x2, #0x13                  	// #19
    1d60:	910003fd 	mov	x29, sp
    1d64:	f9400063 	ldr	x3, [x3]
    1d68:	d2800021 	mov	x1, #0x1                   	// #1
    1d6c:	d0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    1d70:	91082000 	add	x0, x0, #0x208
    1d74:	97fffe37 	bl	1650 <fwrite@plt>
    1d78:	d2800000 	mov	x0, #0x0                   	// #0
    1d7c:	97fffe41 	bl	1680 <fflush@plt>
    1d80:	52800cc0 	mov	w0, #0x66                  	// #102
    1d84:	97fffe4f 	bl	16c0 <_Exit@plt>
    1d88:	d503201f 	nop
    1d8c:	d503201f 	nop

0000000000001d90 <fwp_heap_chunks>:
    1d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d94:	910003fd 	mov	x29, sp
    1d98:	a90153f3 	stp	x19, x20, [sp, #16]
    1d9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1da0:	90000195 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    1da4:	9114c2a1 	add	x1, x21, #0x530
    1da8:	f100041f 	cmp	x0, #0x1
    1dac:	54000ca0 	b.eq	1f40 <fwp_heap_chunks+0x1b0>  // b.none
    1db0:	f949f822 	ldr	x2, [x1, #5104]
    1db4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xad0>
    1db8:	912480a5 	add	x5, x5, #0x920
    1dbc:	9114c2a1 	add	x1, x21, #0x530
    1dc0:	f949ec34 	ldr	x20, [x1, #5080]
    1dc4:	eb14005f 	cmp	x2, x20
    1dc8:	54000c42 	b.cs	1f50 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1dcc:	f949fc23 	ldr	x3, [x1, #5112]
    1dd0:	8b020841 	add	x1, x2, x2, lsl #2
    1dd4:	d2800004 	mov	x4, #0x0                   	// #0
    1dd8:	8b010c61 	add	x1, x3, x1, lsl #3
    1ddc:	14000009 	b	1e00 <fwp_heap_chunks+0x70>
    1de0:	91000483 	add	x3, x4, #0x1
    1de4:	eb03001f 	cmp	x0, x3
    1de8:	54000940 	b.eq	1f10 <fwp_heap_chunks+0x180>  // b.none
    1dec:	91000442 	add	x2, x2, #0x1
    1df0:	aa0303e4 	mov	x4, x3
    1df4:	9100a021 	add	x1, x1, #0x28
    1df8:	eb02029f 	cmp	x20, x2
    1dfc:	54000100 	b.eq	1e1c <fwp_heap_chunks+0x8c>  // b.none
    1e00:	39400023 	ldrb	w3, [x1]
    1e04:	34fffee3 	cbz	w3, 1de0 <fwp_heap_chunks+0x50>
    1e08:	91000442 	add	x2, x2, #0x1
    1e0c:	9100a021 	add	x1, x1, #0x28
    1e10:	d2800004 	mov	x4, #0x0                   	// #0
    1e14:	eb02029f 	cmp	x20, x2
    1e18:	54ffff41 	b.ne	1e00 <fwp_heap_chunks+0x70>  // b.any
    1e1c:	cb040294 	sub	x20, x20, x4
    1e20:	f9001bf7 	str	x23, [sp, #48]
    1e24:	9114c2b7 	add	x23, x21, #0x530
    1e28:	8b140013 	add	x19, x0, x20
    1e2c:	f94a1ae1 	ldr	x1, [x23, #5168]
    1e30:	f949f2e0 	ldr	x0, [x23, #5088]
    1e34:	cb040021 	sub	x1, x1, x4
    1e38:	f90a1ae1 	str	x1, [x23, #5168]
    1e3c:	eb00027f 	cmp	x19, x0
    1e40:	54000429 	b.ls	1ec4 <fwp_heap_chunks+0x134>  // b.plast
    1e44:	f949eae1 	ldr	x1, [x23, #5072]
    1e48:	eb01027f 	cmp	x19, x1
    1e4c:	54000888 	b.hi	1f5c <fwp_heap_chunks+0x1cc>  // b.pmore
    1e50:	91010276 	add	x22, x19, #0x40
    1e54:	52800062 	mov	w2, #0x3                   	// #3
    1e58:	f949dae3 	ldr	x3, [x23, #5040]
    1e5c:	eb0102df 	cmp	x22, x1
    1e60:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1e64:	cb0002c1 	sub	x1, x22, x0
    1e68:	8b004060 	add	x0, x3, x0, lsl #16
    1e6c:	d370bc21 	lsl	x1, x1, #16
    1e70:	97fffe20 	bl	16f0 <mprotect@plt>
    1e74:	35000740 	cbnz	w0, 1f5c <fwp_heap_chunks+0x1cc>
    1e78:	528003c0 	mov	w0, #0x1e                  	// #30
    1e7c:	97fffe09 	bl	16a0 <sysconf@plt>
    1e80:	f949f2e2 	ldr	x2, [x23, #5088]
    1e84:	cb0003e5 	neg	x5, x0
    1e88:	aa0003e4 	mov	x4, x0
    1e8c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e90:	f949fee0 	ldr	x0, [x23, #5112]
    1e94:	8b020843 	add	x3, x2, x2, lsl #2
    1e98:	52800062 	mov	w2, #0x3                   	// #3
    1e9c:	8b010c01 	add	x1, x0, x1, lsl #3
    1ea0:	8b030c03 	add	x3, x0, x3, lsl #3
    1ea4:	d1000421 	sub	x1, x1, #0x1
    1ea8:	8a050060 	and	x0, x3, x5
    1eac:	8b040021 	add	x1, x1, x4
    1eb0:	8a050021 	and	x1, x1, x5
    1eb4:	cb000021 	sub	x1, x1, x0
    1eb8:	97fffe0e 	bl	16f0 <mprotect@plt>
    1ebc:	35000500 	cbnz	w0, 1f5c <fwp_heap_chunks+0x1cc>
    1ec0:	f909f2f6 	str	x22, [x23, #5088]
    1ec4:	9114c2b5 	add	x21, x21, #0x530
    1ec8:	d370be60 	lsl	x0, x19, #16
    1ecc:	f949e6a1 	ldr	x1, [x21, #5064]
    1ed0:	f909eeb3 	str	x19, [x21, #5080]
    1ed4:	eb01001f 	cmp	x0, x1
    1ed8:	540000e8 	b.hi	1ef4 <fwp_heap_chunks+0x164>  // b.pmore
    1edc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1ee0:	aa1403e0 	mov	x0, x20
    1ee4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ee8:	f9401bf7 	ldr	x23, [sp, #48]
    1eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ef0:	d65f03c0 	ret
    1ef4:	f9401bf7 	ldr	x23, [sp, #48]
    1ef8:	f909e6a0 	str	x0, [x21, #5064]
    1efc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1f00:	aa1403e0 	mov	x0, x20
    1f04:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f08:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1f0c:	d65f03c0 	ret
    1f10:	9114c2b5 	add	x21, x21, #0x530
    1f14:	91000441 	add	x1, x2, #0x1
    1f18:	f90000a1 	str	x1, [x5]
    1f1c:	cb040054 	sub	x20, x2, x4
    1f20:	f94a1aa1 	ldr	x1, [x21, #5168]
    1f24:	cb000020 	sub	x0, x1, x0
    1f28:	f90a1aa0 	str	x0, [x21, #5168]
    1f2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1f30:	aa1403e0 	mov	x0, x20
    1f34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f38:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1f3c:	d65f03c0 	ret
    1f40:	f949f422 	ldr	x2, [x1, #5096]
    1f44:	b0000185 	adrp	x5, 32000 <fwp_heap+0xad0>
    1f48:	912460a5 	add	x5, x5, #0x918
    1f4c:	17ffff9c 	b	1dbc <fwp_heap_chunks+0x2c>
    1f50:	d2800004 	mov	x4, #0x0                   	// #0
    1f54:	f9001bf7 	str	x23, [sp, #48]
    1f58:	17ffffb3 	b	1e24 <fwp_heap_chunks+0x94>
    1f5c:	97ffff7d 	bl	1d50 <fwp_heap_oom>

0000000000001f60 <ad_raw_fail>:
    1f60:	d00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x165f8>
    1f64:	f947e884 	ldr	x4, [x4, #4048]
    1f68:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1f6c:	aa0003e3 	mov	x3, x0
    1f70:	910003fd 	mov	x29, sp
    1f74:	f9400080 	ldr	x0, [x4]
    1f78:	d0000022 	adrp	x2, 7000 <__modti3+0x1a0>
    1f7c:	91088042 	add	x2, x2, #0x220
    1f80:	52800041 	mov	w1, #0x2                   	// #2
    1f84:	97fffd8f 	bl	15c0 <__fprintf_chk@plt>
    1f88:	52801d00 	mov	w0, #0xe8                  	// #232
    1f8c:	97fffd1d 	bl	1400 <exit@plt>

0000000000001f90 <ad_raw_report>:
    1f90:	d101c3ff 	sub	sp, sp, #0x70
    1f94:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f98:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x165f8>
    1f9c:	f947f463 	ldr	x3, [x3, #4072]
    1fa0:	d0000022 	adrp	x2, 7000 <__modti3+0x1a0>
    1fa4:	a9037bfd 	stp	x29, x30, [sp, #48]
    1fa8:	9100c3fd 	add	x29, sp, #0x30
    1fac:	91094042 	add	x2, x2, #0x250
    1fb0:	d2800005 	mov	x5, #0x0                   	// #0
    1fb4:	a9055bf5 	stp	x21, x22, [sp, #80]
    1fb8:	d0000036 	adrp	x22, 7000 <__modti3+0x1a0>
    1fbc:	910ac2d6 	add	x22, x22, #0x2b0
    1fc0:	d00000f5 	adrp	x21, 1f000 <__FRAME_END__+0x165f8>
    1fc4:	f947eab5 	ldr	x21, [x21, #4048]
    1fc8:	a90453f3 	stp	x19, x20, [sp, #64]
    1fcc:	52800013 	mov	w19, #0x0                   	// #0
    1fd0:	f94002a0 	ldr	x0, [x21]
    1fd4:	f90033f7 	str	x23, [sp, #96]
    1fd8:	d0000037 	adrp	x23, 7000 <__modti3+0x1a0>
    1fdc:	910922f7 	add	x23, x23, #0x248
    1fe0:	f9400064 	ldr	x4, [x3]
    1fe4:	f90017e4 	str	x4, [sp, #40]
    1fe8:	d2800004 	mov	x4, #0x0                   	// #0
    1fec:	d2800003 	mov	x3, #0x0                   	// #0
    1ff0:	f9403824 	ldr	x4, [x1, #112]
    1ff4:	52800041 	mov	w1, #0x2                   	// #2
    1ff8:	97fffd72 	bl	15c0 <__fprintf_chk@plt>
    1ffc:	f00000e1 	adrp	x1, 20000 <__data_start>
    2000:	91004021 	add	x1, x1, #0x10
    2004:	f94002a0 	ldr	x0, [x21]
    2008:	910023e2 	add	x2, sp, #0x8
    200c:	4c40a020 	ld1	{v0.16b-v1.16b}, [x1]
    2010:	b0000023 	adrp	x3, 7000 <__modti3+0x1a0>
    2014:	aa0203f4 	mov	x20, x2
    2018:	91090063 	add	x3, x3, #0x240
    201c:	4c00a040 	st1	{v0.16b-v1.16b}, [x2]
    2020:	aa1603e2 	mov	x2, x22
    2024:	f8408684 	ldr	x4, [x20], #8
    2028:	d2800007 	mov	x7, #0x0                   	// #0
    202c:	d2800006 	mov	x6, #0x0                   	// #0
    2030:	d2800005 	mov	x5, #0x0                   	// #0
    2034:	52800041 	mov	w1, #0x2                   	// #2
    2038:	11000673 	add	w19, w19, #0x1
    203c:	97fffd61 	bl	15c0 <__fprintf_chk@plt>
    2040:	7100127f 	cmp	w19, #0x4
    2044:	54000080 	b.eq	2054 <ad_raw_report+0xc4>  // b.none
    2048:	f94002a0 	ldr	x0, [x21]
    204c:	aa1703e3 	mov	x3, x23
    2050:	17fffff4 	b	2020 <ad_raw_report+0x90>
    2054:	f94002a3 	ldr	x3, [x21]
    2058:	d2800262 	mov	x2, #0x13                  	// #19
    205c:	d2800021 	mov	x1, #0x1                   	// #1
    2060:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    2064:	910bc000 	add	x0, x0, #0x2f0
    2068:	97fffd7a 	bl	1650 <fwrite@plt>
    206c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    2070:	f947f400 	ldr	x0, [x0, #4072]
    2074:	f94017e2 	ldr	x2, [sp, #40]
    2078:	f9400001 	ldr	x1, [x0]
    207c:	eb010042 	subs	x2, x2, x1
    2080:	d2800001 	mov	x1, #0x0                   	// #0
    2084:	54000181 	b.ne	20b4 <ad_raw_report+0x124>  // b.any
    2088:	f94002a3 	ldr	x3, [x21]
    208c:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    2090:	a9437bfd 	ldp	x29, x30, [sp, #48]
    2094:	910c2000 	add	x0, x0, #0x308
    2098:	a94453f3 	ldp	x19, x20, [sp, #64]
    209c:	d2800082 	mov	x2, #0x4                   	// #4
    20a0:	a9455bf5 	ldp	x21, x22, [sp, #80]
    20a4:	d2800021 	mov	x1, #0x1                   	// #1
    20a8:	f94033f7 	ldr	x23, [sp, #96]
    20ac:	9101c3ff 	add	sp, sp, #0x70
    20b0:	17fffd68 	b	1650 <fwrite@plt>
    20b4:	97fffd27 	bl	1550 <__stack_chk_fail@plt>
    20b8:	d503201f 	nop
    20bc:	d503201f 	nop

00000000000020c0 <buf_grow>:
    20c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    20c4:	910003fd 	mov	x29, sp
    20c8:	a90153f3 	stp	x19, x20, [sp, #16]
    20cc:	aa0003f4 	mov	x20, x0
    20d0:	f9400400 	ldr	x0, [x0, #8]
    20d4:	b100041f 	cmn	x0, #0x1
    20d8:	54000400 	b.eq	2158 <buf_grow+0x98>  // b.none
    20dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    20e0:	cb000042 	sub	x2, x2, x0
    20e4:	eb01005f 	cmp	x2, x1
    20e8:	54000383 	b.cc	2158 <buf_grow+0x98>  // b.lo, b.ul, b.last
    20ec:	f9400a82 	ldr	x2, [x20, #16]
    20f0:	91000421 	add	x1, x1, #0x1
    20f4:	8b000033 	add	x19, x1, x0
    20f8:	eb13005f 	cmp	x2, x19
    20fc:	54000242 	b.cs	2144 <buf_grow+0x84>  // b.hs, b.nlast
    2100:	f100005f 	cmp	x2, #0x0
    2104:	b5000262 	cbnz	x2, 2150 <buf_grow+0x90>
    2108:	d2800802 	mov	x2, #0x40                  	// #64
    210c:	eb02027f 	cmp	x19, x2
    2110:	54000068 	b.hi	211c <buf_grow+0x5c>  // b.pmore
    2114:	14000005 	b	2128 <buf_grow+0x68>
    2118:	b7f800a2 	tbnz	x2, #63, 212c <buf_grow+0x6c>
    211c:	d37ff842 	lsl	x2, x2, #1
    2120:	eb02027f 	cmp	x19, x2
    2124:	54ffffa8 	b.hi	2118 <buf_grow+0x58>  // b.pmore
    2128:	aa0203f3 	mov	x19, x2
    212c:	f9400280 	ldr	x0, [x20]
    2130:	aa1303e1 	mov	x1, x19
    2134:	97fffd03 	bl	1540 <realloc@plt>
    2138:	b4000100 	cbz	x0, 2158 <buf_grow+0x98>
    213c:	f9000280 	str	x0, [x20]
    2140:	f9000a93 	str	x19, [x20, #16]
    2144:	a94153f3 	ldp	x19, x20, [sp, #16]
    2148:	a8c27bfd 	ldp	x29, x30, [sp], #32
    214c:	d65f03c0 	ret
    2150:	54fffe6a 	b.ge	211c <buf_grow+0x5c>  // b.tcont
    2154:	17fffff6 	b	212c <buf_grow+0x6c>
    2158:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x165f8>
    215c:	f947e863 	ldr	x3, [x3, #4048]
    2160:	d2800262 	mov	x2, #0x13                  	// #19
    2164:	d2800021 	mov	x1, #0x1                   	// #1
    2168:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    216c:	91082000 	add	x0, x0, #0x208
    2170:	f9400063 	ldr	x3, [x3]
    2174:	97fffd37 	bl	1650 <fwrite@plt>
    2178:	d2800000 	mov	x0, #0x0                   	// #0
    217c:	97fffd41 	bl	1680 <fflush@plt>
    2180:	52800cc0 	mov	w0, #0x66                  	// #102
    2184:	97fffd4f 	bl	16c0 <_Exit@plt>
    2188:	d503201f 	nop
    218c:	d503201f 	nop

0000000000002190 <buf_put>:
    2190:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2194:	910003fd 	mov	x29, sp
    2198:	a90153f3 	stp	x19, x20, [sp, #16]
    219c:	aa0003f4 	mov	x20, x0
    21a0:	aa0203f3 	mov	x19, x2
    21a4:	f90013f5 	str	x21, [sp, #32]
    21a8:	aa0103f5 	mov	x21, x1
    21ac:	aa0203e1 	mov	x1, x2
    21b0:	97ffffc4 	bl	20c0 <buf_grow>
    21b4:	a9400283 	ldp	x3, x0, [x20]
    21b8:	aa1503e1 	mov	x1, x21
    21bc:	aa1303e2 	mov	x2, x19
    21c0:	8b000060 	add	x0, x3, x0
    21c4:	97fffc7b 	bl	13b0 <memcpy@plt>
    21c8:	a9400680 	ldp	x0, x1, [x20]
    21cc:	8b010273 	add	x19, x19, x1
    21d0:	f9000693 	str	x19, [x20, #8]
    21d4:	3833681f 	strb	wzr, [x0, x19]
    21d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    21dc:	f94013f5 	ldr	x21, [sp, #32]
    21e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    21e4:	d65f03c0 	ret
    21e8:	d503201f 	nop
    21ec:	d503201f 	nop

00000000000021f0 <fwp_cancel_tree.part.0>:
    21f0:	d00000e1 	adrp	x1, 20000 <__data_start>
    21f4:	91014022 	add	x2, x1, #0x50
    21f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    21fc:	52800023 	mov	w3, #0x1                   	// #1
    2200:	910003fd 	mov	x29, sp
    2204:	f9400444 	ldr	x4, [x2, #8]
    2208:	f9000bf3 	str	x19, [sp, #16]
    220c:	39014403 	strb	w3, [x0, #81]
    2210:	eb04001f 	cmp	x0, x4
    2214:	54000160 	b.eq	2240 <fwp_cancel_tree.part.0+0x50>  // b.none
    2218:	f9402804 	ldr	x4, [x0, #80]
    221c:	f2001c9f 	tst	x4, #0xff000000ff
    2220:	54000101 	b.ne	2240 <fwp_cancel_tree.part.0+0x50>  // b.any
    2224:	f9401444 	ldr	x4, [x2, #40]
    2228:	39015003 	strb	w3, [x0, #84]
    222c:	f900801f 	str	xzr, [x0, #256]
    2230:	b40001e4 	cbz	x4, 226c <fwp_cancel_tree.part.0+0x7c>
    2234:	f9008080 	str	x0, [x4, #256]
    2238:	91014021 	add	x1, x1, #0x50
    223c:	f9001420 	str	x0, [x1, #40]
    2240:	f9401413 	ldr	x19, [x0, #40]
    2244:	b40000f3 	cbz	x19, 2260 <fwp_cancel_tree.part.0+0x70>
    2248:	39414261 	ldrb	w1, [x19, #80]
    224c:	aa1303e0 	mov	x0, x19
    2250:	37000041 	tbnz	w1, #0, 2258 <fwp_cancel_tree.part.0+0x68>
    2254:	97ffffe7 	bl	21f0 <fwp_cancel_tree.part.0>
    2258:	f9401a73 	ldr	x19, [x19, #48]
    225c:	b5ffff73 	cbnz	x19, 2248 <fwp_cancel_tree.part.0+0x58>
    2260:	f9400bf3 	ldr	x19, [sp, #16]
    2264:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2268:	d65f03c0 	ret
    226c:	f9001840 	str	x0, [x2, #48]
    2270:	17fffff2 	b	2238 <fwp_cancel_tree.part.0+0x48>

0000000000002274 <fwp_finish_float>:
    2274:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2278:	528005c1 	mov	w1, #0x2e                  	// #46
    227c:	910003fd 	mov	x29, sp
    2280:	f9000bf3 	str	x19, [sp, #16]
    2284:	aa0003f3 	mov	x19, x0
    2288:	97fffcea 	bl	1630 <strchr@plt>
    228c:	b4000080 	cbz	x0, 229c <fwp_finish_float+0x28>
    2290:	f9400bf3 	ldr	x19, [sp, #16]
    2294:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2298:	d65f03c0 	ret
    229c:	aa1303e0 	mov	x0, x19
    22a0:	52800ca1 	mov	w1, #0x65                  	// #101
    22a4:	97fffce3 	bl	1630 <strchr@plt>
    22a8:	b5ffff40 	cbnz	x0, 2290 <fwp_finish_float+0x1c>
    22ac:	b0000021 	adrp	x1, 7000 <__modti3+0x1a0>
    22b0:	aa1303e0 	mov	x0, x19
    22b4:	910c4021 	add	x1, x1, #0x310
    22b8:	97fffcfe 	bl	16b0 <strstr@plt>
    22bc:	b5fffea0 	cbnz	x0, 2290 <fwp_finish_float+0x1c>
    22c0:	b0000021 	adrp	x1, 7000 <__modti3+0x1a0>
    22c4:	aa1303e0 	mov	x0, x19
    22c8:	910c6021 	add	x1, x1, #0x318
    22cc:	97fffcf9 	bl	16b0 <strstr@plt>
    22d0:	b5fffe00 	cbnz	x0, 2290 <fwp_finish_float+0x1c>
    22d4:	aa1303e0 	mov	x0, x19
    22d8:	97fffc42 	bl	13e0 <strlen@plt>
    22dc:	b0000021 	adrp	x1, 7000 <__modti3+0x1a0>
    22e0:	910c8021 	add	x1, x1, #0x320
    22e4:	8b000262 	add	x2, x19, x0
    22e8:	79400023 	ldrh	w3, [x1]
    22ec:	39400821 	ldrb	w1, [x1, #2]
    22f0:	78206a63 	strh	w3, [x19, x0]
    22f4:	39000841 	strb	w1, [x2, #2]
    22f8:	17ffffe6 	b	2290 <fwp_finish_float+0x1c>
    22fc:	d503201f 	nop

0000000000002300 <fwp_trap>:
    2300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2304:	910003fd 	mov	x29, sp
    2308:	f9000bf3 	str	x19, [sp, #16]
    230c:	aa0003f3 	mov	x19, x0
    2310:	97fffe50 	bl	1c50 <fwp_flush>
    2314:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x165f8>
    2318:	f947e884 	ldr	x4, [x4, #4048]
    231c:	aa1303e3 	mov	x3, x19
    2320:	b0000022 	adrp	x2, 7000 <__modti3+0x1a0>
    2324:	910ca042 	add	x2, x2, #0x328
    2328:	52800041 	mov	w1, #0x2                   	// #2
    232c:	f9400080 	ldr	x0, [x4]
    2330:	97fffca4 	bl	15c0 <__fprintf_chk@plt>
    2334:	52800ca0 	mov	w0, #0x65                  	// #101
    2338:	97fffc32 	bl	1400 <exit@plt>
    233c:	d503201f 	nop

0000000000002340 <fwp_now_ns>:
    2340:	d100c3ff 	sub	sp, sp, #0x30
    2344:	52800020 	mov	w0, #0x1                   	// #1
    2348:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x165f8>
    234c:	f947f442 	ldr	x2, [x2, #4072]
    2350:	910023e1 	add	x1, sp, #0x8
    2354:	a9027bfd 	stp	x29, x30, [sp, #32]
    2358:	910083fd 	add	x29, sp, #0x20
    235c:	f9400043 	ldr	x3, [x2]
    2360:	f9000fe3 	str	x3, [sp, #24]
    2364:	d2800003 	mov	x3, #0x0                   	// #0
    2368:	97fffc46 	bl	1480 <clock_gettime@plt>
    236c:	350002c0 	cbnz	w0, 23c4 <fwp_now_ns+0x84>
    2370:	a9408be1 	ldp	x1, x2, [sp, #8]
    2374:	d2994003 	mov	x3, #0xca00                	// #51712
    2378:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    237c:	9b037c20 	mul	x0, x1, x3
    2380:	9b437c21 	smulh	x1, x1, x3
    2384:	ab020000 	adds	x0, x0, x2
    2388:	937ffc42 	asr	x2, x2, #63
    238c:	9a020021 	adc	x1, x1, x2
    2390:	f100001f 	cmp	x0, #0x0
    2394:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2398:	b50001e1 	cbnz	x1, 23d4 <fwp_now_ns+0x94>
    239c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x165f8>
    23a0:	f947f421 	ldr	x1, [x1, #4072]
    23a4:	f9400fe3 	ldr	x3, [sp, #24]
    23a8:	f9400022 	ldr	x2, [x1]
    23ac:	eb020063 	subs	x3, x3, x2
    23b0:	d2800002 	mov	x2, #0x0                   	// #0
    23b4:	540000e1 	b.ne	23d0 <fwp_now_ns+0x90>  // b.any
    23b8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    23bc:	9100c3ff 	add	sp, sp, #0x30
    23c0:	d65f03c0 	ret
    23c4:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    23c8:	910ce000 	add	x0, x0, #0x338
    23cc:	97ffffcd 	bl	2300 <fwp_trap>
    23d0:	97fffc60 	bl	1550 <__stack_chk_fail@plt>
    23d4:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    23d8:	910d6000 	add	x0, x0, #0x358
    23dc:	97ffffc9 	bl	2300 <fwp_trap>

00000000000023e0 <fwp_args74>:
    23e0:	d65f03c0 	ret

00000000000023e4 <fwp_format_g.constprop.0>:
    23e4:	d10483ff 	sub	sp, sp, #0x120
    23e8:	b0000024 	adrp	x4, 7000 <__modti3+0x1a0>
    23ec:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x165f8>
    23f0:	f947f442 	ldr	x2, [x2, #4072]
    23f4:	910e0084 	add	x4, x4, #0x380
    23f8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    23fc:	9102c3fd 	add	x29, sp, #0xb0
    2400:	d2800803 	mov	x3, #0x40                  	// #64
    2404:	a90e63f7 	stp	x23, x24, [sp, #224]
    2408:	93407c38 	sxtw	x24, w1
    240c:	aa0303e1 	mov	x1, x3
    2410:	fd008be8 	str	d8, [sp, #272]
    2414:	1e604008 	fmov	d8, d0
    2418:	a90c53f3 	stp	x19, x20, [sp, #192]
    241c:	910083f4 	add	x20, sp, #0x20
    2420:	a90d5bf5 	stp	x21, x22, [sp, #208]
    2424:	aa0003f5 	mov	x21, x0
    2428:	a91073fb 	stp	x27, x28, [sp, #256]
    242c:	5100071c 	sub	w28, w24, #0x1
    2430:	2a1c03e5 	mov	w5, w28
    2434:	f9400040 	ldr	x0, [x2]
    2438:	f90057e0 	str	x0, [sp, #168]
    243c:	d2800000 	mov	x0, #0x0                   	// #0
    2440:	52800042 	mov	w2, #0x2                   	// #2
    2444:	aa1403e0 	mov	x0, x20
    2448:	97fffc1e 	bl	14c0 <__snprintf_chk@plt>
    244c:	52800ca1 	mov	w1, #0x65                  	// #101
    2450:	aa1403e0 	mov	x0, x20
    2454:	97fffc77 	bl	1630 <strchr@plt>
    2458:	aa0003f3 	mov	x19, x0
    245c:	52800142 	mov	w2, #0xa                   	// #10
    2460:	91000400 	add	x0, x0, #0x1
    2464:	d2800001 	mov	x1, #0x0                   	// #0
    2468:	97fffc62 	bl	15f0 <strtol@plt>
    246c:	aa0003f7 	mov	x23, x0
    2470:	11001400 	add	w0, w0, #0x5
    2474:	7100541f 	cmp	w0, #0x15
    2478:	54000d88 	b.hi	2628 <fwp_format_g.constprop.0+0x244>  // b.pmore
    247c:	4b170385 	sub	w5, w28, w23
    2480:	710000bf 	cmp	w5, #0x0
    2484:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2488:	54000ba0 	b.eq	25fc <fwp_format_g.constprop.0+0x218>  // b.none
    248c:	394083e0 	ldrb	w0, [sp, #32]
    2490:	cb180273 	sub	x19, x19, x24
    2494:	91000673 	add	x19, x19, #0x1
    2498:	a90f6bf9 	stp	x25, x26, [sp, #240]
    249c:	7100b41f 	cmp	w0, #0x2d
    24a0:	9a941681 	cinc	x1, x20, eq	// eq = none
    24a4:	1a9f17e4 	cset	w4, eq	// eq = none
    24a8:	cb010266 	sub	x6, x19, x1
    24ac:	d10004da 	sub	x26, x6, #0x1
    24b0:	540018c0 	b.eq	27c8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    24b4:	910183f9 	add	x25, sp, #0x60
    24b8:	d280091b 	mov	x27, #0x48                  	// #72
    24bc:	aa1903e7 	mov	x7, x25
    24c0:	91000423 	add	x3, x1, #0x1
    24c4:	91011cc6 	add	x6, x6, #0x47
    24c8:	910004f6 	add	x22, x7, #0x1
    24cc:	37f81017 	tbnz	w23, #31, 26cc <fwp_format_g.constprop.0+0x2e8>
    24d0:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    24d4:	93407ef7 	sxtw	x23, w23
    24d8:	390000e4 	strb	w4, [x7]
    24dc:	aa1303e1 	mov	x1, x19
    24e0:	aa1703e2 	mov	x2, x23
    24e4:	aa1603e0 	mov	x0, x22
    24e8:	b9000be5 	str	w5, [sp, #8]
    24ec:	cb170374 	sub	x20, x27, x23
    24f0:	a9011be3 	stp	x3, x6, [sp, #16]
    24f4:	97fffbaf 	bl	13b0 <memcpy@plt>
    24f8:	d1000694 	sub	x20, x20, #0x1
    24fc:	f9400be3 	ldr	x3, [sp, #16]
    2500:	8b1702d6 	add	x22, x22, x23
    2504:	aa1603e0 	mov	x0, x22
    2508:	aa1a03e2 	mov	x2, x26
    250c:	aa0303e1 	mov	x1, x3
    2510:	aa1403e3 	mov	x3, x20
    2514:	97fffbe3 	bl	14a0 <__memcpy_chk@plt>
    2518:	8b1a02d6 	add	x22, x22, x26
    251c:	f9400fe6 	ldr	x6, [sp, #24]
    2520:	d2800900 	mov	x0, #0x48                  	// #72
    2524:	b9400be5 	ldr	w5, [sp, #8]
    2528:	8b170261 	add	x1, x19, x23
    252c:	cb1400c3 	sub	x3, x6, x20
    2530:	cb060294 	sub	x20, x20, x6
    2534:	f101207f 	cmp	x3, #0x48
    2538:	93407cb8 	sxtw	x24, w5
    253c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2540:	aa1803e2 	mov	x2, x24
    2544:	8b1802d3 	add	x19, x22, x24
    2548:	8b140063 	add	x3, x3, x20
    254c:	aa1603e0 	mov	x0, x22
    2550:	97fffbd4 	bl	14a0 <__memcpy_chk@plt>
    2554:	cb190273 	sub	x19, x19, x25
    2558:	d28031e0 	mov	x0, #0x18f                 	// #399
    255c:	eb00027f 	cmp	x19, x0
    2560:	aa1903e1 	mov	x1, x25
    2564:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    2568:	aa1503e0 	mov	x0, x21
    256c:	aa1303e2 	mov	x2, x19
    2570:	97fffb90 	bl	13b0 <memcpy@plt>
    2574:	38336abf 	strb	wzr, [x21, x19]
    2578:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    257c:	aa1503e0 	mov	x0, x21
    2580:	97fffb98 	bl	13e0 <strlen@plt>
    2584:	aa0003f3 	mov	x19, x0
    2588:	528005c1 	mov	w1, #0x2e                  	// #46
    258c:	aa1503e0 	mov	x0, x21
    2590:	97fffc28 	bl	1630 <strchr@plt>
    2594:	b4000160 	cbz	x0, 25c0 <fwp_format_g.constprop.0+0x1dc>
    2598:	b4000153 	cbz	x19, 25c0 <fwp_format_g.constprop.0+0x1dc>
    259c:	d503201f 	nop
    25a0:	aa1303e1 	mov	x1, x19
    25a4:	d1000673 	sub	x19, x19, #0x1
    25a8:	38736aa0 	ldrb	w0, [x21, x19]
    25ac:	7100c01f 	cmp	w0, #0x30
    25b0:	54001001 	b.ne	27b0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    25b4:	38336abf 	strb	wzr, [x21, x19]
    25b8:	b5ffff53 	cbnz	x19, 25a0 <fwp_format_g.constprop.0+0x1bc>
    25bc:	d503201f 	nop
    25c0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    25c4:	f947f400 	ldr	x0, [x0, #4072]
    25c8:	f94057e2 	ldr	x2, [sp, #168]
    25cc:	f9400001 	ldr	x1, [x0]
    25d0:	eb010042 	subs	x2, x2, x1
    25d4:	d2800001 	mov	x1, #0x0                   	// #0
    25d8:	54001061 	b.ne	27e4 <fwp_format_g.constprop.0+0x400>  // b.any
    25dc:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    25e0:	a94c53f3 	ldp	x19, x20, [sp, #192]
    25e4:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    25e8:	a94e63f7 	ldp	x23, x24, [sp, #224]
    25ec:	a95073fb 	ldp	x27, x28, [sp, #256]
    25f0:	fd408be8 	ldr	d8, [sp, #272]
    25f4:	910483ff 	add	sp, sp, #0x120
    25f8:	d65f03c0 	ret
    25fc:	1e604100 	fmov	d0, d8
    2600:	710000bf 	cmp	w5, #0x0
    2604:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2608:	aa1503e0 	mov	x0, x21
    260c:	b0000024 	adrp	x4, 7000 <__modti3+0x1a0>
    2610:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2614:	910e6084 	add	x4, x4, #0x398
    2618:	52800042 	mov	w2, #0x2                   	// #2
    261c:	d2803201 	mov	x1, #0x190                 	// #400
    2620:	97fffba8 	bl	14c0 <__snprintf_chk@plt>
    2624:	17ffffd6 	b	257c <fwp_format_g.constprop.0+0x198>
    2628:	cb140273 	sub	x19, x19, x20
    262c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2630:	910183f9 	add	x25, sp, #0x60
    2634:	aa1303e2 	mov	x2, x19
    2638:	aa1403e1 	mov	x1, x20
    263c:	aa1903e0 	mov	x0, x25
    2640:	d2800803 	mov	x3, #0x40                  	// #64
    2644:	97fffb97 	bl	14a0 <__memcpy_chk@plt>
    2648:	38336b3f 	strb	wzr, [x25, x19]
    264c:	aa1903e0 	mov	x0, x25
    2650:	528005c1 	mov	w1, #0x2e                  	// #46
    2654:	97fffbf7 	bl	1630 <strchr@plt>
    2658:	b40001c0 	cbz	x0, 2690 <fwp_format_g.constprop.0+0x2ac>
    265c:	b50000b3 	cbnz	x19, 2670 <fwp_format_g.constprop.0+0x28c>
    2660:	1400000c 	b	2690 <fwp_format_g.constprop.0+0x2ac>
    2664:	381ff01f 	sturb	wzr, [x0, #-1]
    2668:	f1000673 	subs	x19, x19, #0x1
    266c:	54000120 	b.eq	2690 <fwp_format_g.constprop.0+0x2ac>  // b.none
    2670:	8b130320 	add	x0, x25, x19
    2674:	385ff001 	ldurb	w1, [x0, #-1]
    2678:	7100c03f 	cmp	w1, #0x30
    267c:	54ffff40 	b.eq	2664 <fwp_format_g.constprop.0+0x280>  // b.none
    2680:	d1000673 	sub	x19, x19, #0x1
    2684:	38736b20 	ldrb	w0, [x25, x19]
    2688:	7100b81f 	cmp	w0, #0x2e
    268c:	54000a80 	b.eq	27dc <fwp_format_g.constprop.0+0x3f8>  // b.none
    2690:	710002ff 	cmp	w23, #0x0
    2694:	528005a1 	mov	w1, #0x2d                  	// #45
    2698:	aa1903e5 	mov	x5, x25
    269c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    26a0:	aa1503e0 	mov	x0, x21
    26a4:	52800566 	mov	w6, #0x2b                  	// #43
    26a8:	b0000024 	adrp	x4, 7000 <__modti3+0x1a0>
    26ac:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    26b0:	910e2084 	add	x4, x4, #0x388
    26b4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    26b8:	52800042 	mov	w2, #0x2                   	// #2
    26bc:	d2803201 	mov	x1, #0x190                 	// #400
    26c0:	97fffb80 	bl	14c0 <__snprintf_chk@plt>
    26c4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    26c8:	17ffffbe 	b	25c0 <fwp_format_g.constprop.0+0x1dc>
    26cc:	52800605 	mov	w5, #0x30                  	// #48
    26d0:	390000e5 	strb	w5, [x7]
    26d4:	d100077b 	sub	x27, x27, #0x1
    26d8:	aa0303e1 	mov	x1, x3
    26dc:	aa1603e0 	mov	x0, x22
    26e0:	aa1b03e3 	mov	x3, x27
    26e4:	aa1a03e2 	mov	x2, x26
    26e8:	f90007e6 	str	x6, [sp, #8]
    26ec:	b90013e4 	str	w4, [sp, #16]
    26f0:	8b1a02d6 	add	x22, x22, x26
    26f4:	b9001be5 	str	w5, [sp, #24]
    26f8:	97fffb6a 	bl	14a0 <__memcpy_chk@plt>
    26fc:	f94007e6 	ldr	x6, [sp, #8]
    2700:	2a3703e7 	mvn	w7, w23
    2704:	b94013e4 	ldr	w4, [sp, #16]
    2708:	cb1b00c1 	sub	x1, x6, x27
    270c:	cb06037b 	sub	x27, x27, x6
    2710:	f101203f 	cmp	x1, #0x48
    2714:	d2800906 	mov	x6, #0x48                  	// #72
    2718:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    271c:	8b1b0023 	add	x3, x1, x27
    2720:	310006ff 	cmn	w23, #0x1
    2724:	54000220 	b.eq	2768 <fwp_format_g.constprop.0+0x384>  // b.none
    2728:	b9401be5 	ldr	w5, [sp, #24]
    272c:	d2800001 	mov	x1, #0x0                   	// #0
    2730:	f101207f 	cmp	x3, #0x48
    2734:	d1000462 	sub	x2, x3, #0x1
    2738:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    273c:	38216ac5 	strb	w5, [x22, x1]
    2740:	cb030003 	sub	x3, x0, x3
    2744:	91000421 	add	x1, x1, #0x1
    2748:	91000463 	add	x3, x3, #0x1
    274c:	eb00007f 	cmp	x3, x0
    2750:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2754:	cb000063 	sub	x3, x3, x0
    2758:	8b020063 	add	x3, x3, x2
    275c:	6b0100ff 	cmp	w7, w1
    2760:	54fffe8c 	b.gt	2730 <fwp_format_g.constprop.0+0x34c>
    2764:	8b2742d6 	add	x22, x22, w7, uxtw
    2768:	f101207f 	cmp	x3, #0x48
    276c:	d2800905 	mov	x5, #0x48                  	// #72
    2770:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    2774:	aa1603e0 	mov	x0, x22
    2778:	cb0300a1 	sub	x1, x5, x3
    277c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    2780:	91000421 	add	x1, x1, #0x1
    2784:	d1000463 	sub	x3, x3, #0x1
    2788:	eb05003f 	cmp	x1, x5
    278c:	38001402 	strb	w2, [x0], #1
    2790:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    2794:	93407f82 	sxtw	x2, w28
    2798:	cb050025 	sub	x5, x1, x5
    279c:	aa1303e1 	mov	x1, x19
    27a0:	8b0300a3 	add	x3, x5, x3
    27a4:	8b1802d3 	add	x19, x22, x24
    27a8:	97fffb3e 	bl	14a0 <__memcpy_chk@plt>
    27ac:	17ffff6a 	b	2554 <fwp_format_g.constprop.0+0x170>
    27b0:	d1000421 	sub	x1, x1, #0x1
    27b4:	38616aa0 	ldrb	w0, [x21, x1]
    27b8:	7100b81f 	cmp	w0, #0x2e
    27bc:	54fff021 	b.ne	25c0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    27c0:	38216abf 	strb	wzr, [x21, x1]
    27c4:	17ffff7f 	b	25c0 <fwp_format_g.constprop.0+0x1dc>
    27c8:	910187e7 	add	x7, sp, #0x61
    27cc:	910183f9 	add	x25, sp, #0x60
    27d0:	d28008fb 	mov	x27, #0x47                  	// #71
    27d4:	390183e0 	strb	w0, [sp, #96]
    27d8:	17ffff3a 	b	24c0 <fwp_format_g.constprop.0+0xdc>
    27dc:	38336b3f 	strb	wzr, [x25, x19]
    27e0:	17ffffac 	b	2690 <fwp_format_g.constprop.0+0x2ac>
    27e4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    27e8:	97fffb5a 	bl	1550 <__stack_chk_fail@plt>
    27ec:	d503201f 	nop

00000000000027f0 <fwp_heap_report>:
    27f0:	d105c3ff 	sub	sp, sp, #0x170
    27f4:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    27f8:	9114c042 	add	x2, x2, #0x530
    27fc:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x165f8>
    2800:	f947e821 	ldr	x1, [x1, #4048]
    2804:	a9117bfd 	stp	x29, x30, [sp, #272]
    2808:	910443fd 	add	x29, sp, #0x110
    280c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    2810:	f947f400 	ldr	x0, [x0, #4072]
    2814:	a9135bf5 	stp	x21, x22, [sp, #304]
    2818:	a91463f7 	stp	x23, x24, [sp, #320]
    281c:	a9156bf9 	stp	x25, x26, [sp, #336]
    2820:	6d1627e8 	stp	d8, d9, [sp, #352]
    2824:	fd4a1c48 	ldr	d8, [x2, #5176]
    2828:	fd4a2049 	ldr	d9, [x2, #5184]
    282c:	f9400036 	ldr	x22, [x1]
    2830:	f9400001 	ldr	x1, [x0]
    2834:	f90087e1 	str	x1, [sp, #264]
    2838:	d2800001 	mov	x1, #0x0                   	// #0
    283c:	f949e459 	ldr	x25, [x2, #5064]
    2840:	b0000021 	adrp	x1, 7000 <__modti3+0x1a0>
    2844:	f94a1057 	ldr	x23, [x2, #5152]
    2848:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    284c:	f94a1458 	ldr	x24, [x2, #5160]
    2850:	910e8021 	add	x1, x1, #0x3a0
    2854:	910ea000 	add	x0, x0, #0x3a8
    2858:	97fffb22 	bl	14e0 <fopen@plt>
    285c:	b4000740 	cbz	x0, 2944 <fwp_heap_report+0x154>
    2860:	528daad5 	mov	w21, #0x6d56                	// #27990
    2864:	a91253f3 	stp	x19, x20, [sp, #288]
    2868:	aa0003f4 	mov	x20, x0
    286c:	910023f3 	add	x19, sp, #0x8
    2870:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2874:	72aae915 	movk	w21, #0x5748, lsl #16
    2878:	aa1403e2 	mov	x2, x20
    287c:	aa1303e0 	mov	x0, x19
    2880:	52802001 	mov	w1, #0x100                 	// #256
    2884:	97fffb9f 	bl	1700 <fgets@plt>
    2888:	b4000280 	cbz	x0, 28d8 <fwp_heap_report+0xe8>
    288c:	b9400261 	ldr	w1, [x19]
    2890:	6b15003f 	cmp	w1, w21
    2894:	54ffff21 	b.ne	2878 <fwp_heap_report+0x88>  // b.any
    2898:	39401260 	ldrb	w0, [x19, #4]
    289c:	7101341f 	cmp	w0, #0x4d
    28a0:	54fffec1 	b.ne	2878 <fwp_heap_report+0x88>  // b.any
    28a4:	394037e0 	ldrb	w0, [sp, #13]
    28a8:	7100e81f 	cmp	w0, #0x3a
    28ac:	54fffe61 	b.ne	2878 <fwp_heap_report+0x88>  // b.any
    28b0:	52800142 	mov	w2, #0xa                   	// #10
    28b4:	d2800001 	mov	x1, #0x0                   	// #0
    28b8:	91003be0 	add	x0, sp, #0xe
    28bc:	97fffb4d 	bl	15f0 <strtol@plt>
    28c0:	aa1403e2 	mov	x2, x20
    28c4:	aa0003fa 	mov	x26, x0
    28c8:	52802001 	mov	w1, #0x100                 	// #256
    28cc:	aa1303e0 	mov	x0, x19
    28d0:	97fffb8c 	bl	1700 <fgets@plt>
    28d4:	b5fffdc0 	cbnz	x0, 288c <fwp_heap_report+0x9c>
    28d8:	aa1403e0 	mov	x0, x20
    28dc:	97fffafd 	bl	14d0 <fclose@plt>
    28e0:	a95253f3 	ldp	x19, x20, [sp, #288]
    28e4:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    28e8:	f947f400 	ldr	x0, [x0, #4072]
    28ec:	f94087e2 	ldr	x2, [sp, #264]
    28f0:	f9400001 	ldr	x1, [x0]
    28f4:	eb010042 	subs	x2, x2, x1
    28f8:	d2800001 	mov	x1, #0x0                   	// #0
    28fc:	54000281 	b.ne	294c <fwp_heap_report+0x15c>  // b.any
    2900:	a9517bfd 	ldp	x29, x30, [sp, #272]
    2904:	aa1a03e6 	mov	x6, x26
    2908:	aa1903e5 	mov	x5, x25
    290c:	aa1803e4 	mov	x4, x24
    2910:	a9556bf9 	ldp	x25, x26, [sp, #336]
    2914:	aa1703e3 	mov	x3, x23
    2918:	a95463f7 	ldp	x23, x24, [sp, #320]
    291c:	aa1603e0 	mov	x0, x22
    2920:	a9535bf5 	ldp	x21, x22, [sp, #304]
    2924:	1e604121 	fmov	d1, d9
    2928:	1e604100 	fmov	d0, d8
    292c:	b0000022 	adrp	x2, 7000 <__modti3+0x1a0>
    2930:	6d5627e8 	ldp	d8, d9, [sp, #352]
    2934:	910f2042 	add	x2, x2, #0x3c8
    2938:	9105c3ff 	add	sp, sp, #0x170
    293c:	52800041 	mov	w1, #0x2                   	// #2
    2940:	17fffb20 	b	15c0 <__fprintf_chk@plt>
    2944:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2948:	17ffffe7 	b	28e4 <fwp_heap_report+0xf4>
    294c:	a91253f3 	stp	x19, x20, [sp, #288]
    2950:	97fffb00 	bl	1550 <__stack_chk_fail@plt>

0000000000002954 <fwp_heap_init>:
    2954:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2958:	90000183 	adrp	x3, 32000 <fwp_heap+0xad0>
    295c:	9110c061 	add	x1, x3, #0x430
    2960:	910003fd 	mov	x29, sp
    2964:	a90153f3 	stp	x19, x20, [sp, #16]
    2968:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    296c:	9114c262 	add	x2, x19, #0x530
    2970:	a9025bf5 	stp	x21, x22, [sp, #32]
    2974:	52800024 	mov	w4, #0x1                   	// #1
    2978:	52800200 	mov	w0, #0x10                  	// #16
    297c:	b913a444 	str	w4, [x2, #5028]
    2980:	b8004420 	str	w0, [x1], #4
    2984:	11004000 	add	w0, w0, #0x10
    2988:	7104401f 	cmp	w0, #0x110
    298c:	54ffffa1 	b.ne	2980 <fwp_heap_init+0x2c>  // b.any
    2990:	b0000022 	adrp	x2, 7000 <__modti3+0x1a0>
    2994:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2998:	90000181 	adrp	x1, 32000 <fwp_heap+0xad0>
    299c:	9111c021 	add	x1, x1, #0x470
    29a0:	3dc23843 	ldr	q3, [x2, #2272]
    29a4:	d2800000 	mov	x0, #0x0                   	// #0
    29a8:	4e040401 	dup	v1.4s, v0.s[0]
    29ac:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    29b0:	0f215400 	shl	v0.2s, v0.2s, #1
    29b4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    29b8:	3ca06821 	str	q1, [x1, x0]
    29bc:	91004000 	add	x0, x0, #0x10
    29c0:	f101801f 	cmp	x0, #0x60
    29c4:	54ffff21 	b.ne	29a8 <fwp_heap_init+0x54>  // b.any
    29c8:	90000184 	adrp	x4, 32000 <fwp_heap+0xad0>
    29cc:	9110c063 	add	x3, x3, #0x430
    29d0:	91134084 	add	x4, x4, #0x4d0
    29d4:	9114c266 	add	x6, x19, #0x530
    29d8:	d2800002 	mov	x2, #0x0                   	// #0
    29dc:	d2800000 	mov	x0, #0x0                   	// #0
    29e0:	d2880205 	mov	x5, #0x4010                	// #16400
    29e4:	d503201f 	nop
    29e8:	910f0001 	add	x1, x0, #0x3c0
    29ec:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    29f0:	eb02003f 	cmp	x1, x2
    29f4:	540000a2 	b.cs	2a08 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    29f8:	91000400 	add	x0, x0, #0x1
    29fc:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2a00:	eb02003f 	cmp	x1, x2
    2a04:	54ffffa3 	b.cc	29f8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    2a08:	91004042 	add	x2, x2, #0x10
    2a0c:	38001480 	strb	w0, [x4], #1
    2a10:	eb05005f 	cmp	x2, x5
    2a14:	54fffea1 	b.ne	29e8 <fwp_heap_init+0x94>  // b.any
    2a18:	528000b5 	mov	w21, #0x5                   	// #5
    2a1c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    2a20:	14000004 	b	2a30 <fwp_heap_init+0xdc>
    2a24:	d342fe94 	lsr	x20, x20, #2
    2a28:	710006b5 	subs	w21, w21, #0x1
    2a2c:	54000720 	b.eq	2b10 <fwp_heap_init+0x1bc>  // b.none
    2a30:	91404296 	add	x22, x20, #0x10, lsl #12
    2a34:	d2800005 	mov	x5, #0x0                   	// #0
    2a38:	aa1603e1 	mov	x1, x22
    2a3c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a40:	52880443 	mov	w3, #0x4022                	// #16418
    2a44:	52800002 	mov	w2, #0x0                   	// #0
    2a48:	d2800000 	mov	x0, #0x0                   	// #0
    2a4c:	97fffae5 	bl	15e0 <mmap@plt>
    2a50:	aa0003e6 	mov	x6, x0
    2a54:	b100041f 	cmn	x0, #0x1
    2a58:	54fffe60 	b.eq	2a24 <fwp_heap_init+0xd0>  // b.none
    2a5c:	b40005a0 	cbz	x0, 2b10 <fwp_heap_init+0x1bc>
    2a60:	d350fe94 	lsr	x20, x20, #16
    2a64:	d29fffe0 	mov	x0, #0xffff                	// #65535
    2a68:	8b0000c7 	add	x7, x6, x0
    2a6c:	9114c275 	add	x21, x19, #0x530
    2a70:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    2a74:	8b140a81 	add	x1, x20, x20, lsl #2
    2a78:	d2800005 	mov	x5, #0x0                   	// #0
    2a7c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a80:	d37df021 	lsl	x1, x1, #3
    2a84:	52880443 	mov	w3, #0x4022                	// #16418
    2a88:	52800002 	mov	w2, #0x0                   	// #0
    2a8c:	d2800000 	mov	x0, #0x0                   	// #0
    2a90:	f909daa7 	str	x7, [x21, #5040]
    2a94:	f909dea6 	str	x6, [x21, #5048]
    2a98:	f909e2b6 	str	x22, [x21, #5056]
    2a9c:	f909eab4 	str	x20, [x21, #5072]
    2aa0:	f90a02a1 	str	x1, [x21, #5120]
    2aa4:	97fffacf 	bl	15e0 <mmap@plt>
    2aa8:	aa0003e1 	mov	x1, x0
    2aac:	b100041f 	cmn	x0, #0x1
    2ab0:	54000300 	b.eq	2b10 <fwp_heap_init+0x1bc>  // b.none
    2ab4:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    2ab8:	9111e000 	add	x0, x0, #0x478
    2abc:	f909fea1 	str	x1, [x21, #5112]
    2ac0:	97fffb08 	bl	16e0 <getenv@plt>
    2ac4:	52800002 	mov	w2, #0x0                   	// #0
    2ac8:	aa0003e1 	mov	x1, x0
    2acc:	b40000e0 	cbz	x0, 2ae8 <fwp_heap_init+0x194>
    2ad0:	39400000 	ldrb	w0, [x0]
    2ad4:	340000a0 	cbz	w0, 2ae8 <fwp_heap_init+0x194>
    2ad8:	7100c000 	subs	w0, w0, #0x30
    2adc:	54000120 	b.eq	2b00 <fwp_heap_init+0x1ac>  // b.none
    2ae0:	7100001f 	cmp	w0, #0x0
    2ae4:	1a9f07e2 	cset	w2, ne	// ne = any
    2ae8:	9114c273 	add	x19, x19, #0x530
    2aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2af0:	b913aa62 	str	w2, [x19, #5032]
    2af4:	a94153f3 	ldp	x19, x20, [sp, #16]
    2af8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2afc:	d65f03c0 	ret
    2b00:	39400420 	ldrb	w0, [x1, #1]
    2b04:	7100001f 	cmp	w0, #0x0
    2b08:	1a9f07e2 	cset	w2, ne	// ne = any
    2b0c:	17fffff7 	b	2ae8 <fwp_heap_init+0x194>
    2b10:	97fffc90 	bl	1d50 <fwp_heap_oom>

0000000000002b14 <fwp_args45>:
    2b14:	d65f03c0 	ret
    2b18:	d503201f 	nop
    2b1c:	d503201f 	nop

0000000000002b20 <fwp_args69>:
    2b20:	d65f03c0 	ret

0000000000002b24 <fwp_wake_io>:
    2b24:	d00000e9 	adrp	x9, 20000 <__data_start>
    2b28:	91014122 	add	x2, x9, #0x50
    2b2c:	f9400001 	ldr	x1, [x0]
    2b30:	5280000a 	mov	w10, #0x0                   	// #0
    2b34:	f9401446 	ldr	x6, [x2, #40]
    2b38:	52800008 	mov	w8, #0x0                   	// #0
    2b3c:	4f000400 	movi	v0.4s, #0x0
    2b40:	52800027 	mov	w7, #0x1                   	// #1
    2b44:	aa0103e2 	mov	x2, x1
    2b48:	b4000321 	cbz	x1, 2bac <fwp_wake_io+0x88>
    2b4c:	f9408c25 	ldr	x5, [x1, #280]
    2b50:	39015c27 	strb	w7, [x1, #87]
    2b54:	b4000165 	cbz	x5, 2b80 <fwp_wake_io+0x5c>
    2b58:	a9520c24 	ldp	x4, x3, [x1, #288]
    2b5c:	b4000364 	cbz	x4, 2bc8 <fwp_wake_io+0xa4>
    2b60:	f9009483 	str	x3, [x4, #296]
    2b64:	f9409423 	ldr	x3, [x1, #296]
    2b68:	b4000043 	cbz	x3, 2b70 <fwp_wake_io+0x4c>
    2b6c:	f9009064 	str	x4, [x3, #288]
    2b70:	91080023 	add	x3, x1, #0x200
    2b74:	f900943f 	str	xzr, [x1, #296]
    2b78:	3c918060 	stur	q0, [x3, #-232]
    2b7c:	f9400001 	ldr	x1, [x0]
    2b80:	f9402843 	ldr	x3, [x2, #80]
    2b84:	f2001c7f 	tst	x3, #0xff000000ff
    2b88:	54fffde1 	b.ne	2b44 <fwp_wake_io+0x20>  // b.any
    2b8c:	39015047 	strb	w7, [x2, #84]
    2b90:	f900805f 	str	xzr, [x2, #256]
    2b94:	b40001e6 	cbz	x6, 2bd0 <fwp_wake_io+0xac>
    2b98:	f90080c2 	str	x2, [x6, #256]
    2b9c:	aa0203e6 	mov	x6, x2
    2ba0:	52800028 	mov	w8, #0x1                   	// #1
    2ba4:	aa0103e2 	mov	x2, x1
    2ba8:	b5fffd21 	cbnz	x1, 2b4c <fwp_wake_io+0x28>
    2bac:	3400006a 	cbz	w10, 2bb8 <fwp_wake_io+0x94>
    2bb0:	91014120 	add	x0, x9, #0x50
    2bb4:	f900180b 	str	x11, [x0, #48]
    2bb8:	34000068 	cbz	w8, 2bc4 <fwp_wake_io+0xa0>
    2bbc:	91014129 	add	x9, x9, #0x50
    2bc0:	f9001526 	str	x6, [x9, #40]
    2bc4:	d65f03c0 	ret
    2bc8:	f90000a3 	str	x3, [x5]
    2bcc:	17ffffe7 	b	2b68 <fwp_wake_io+0x44>
    2bd0:	aa0203eb 	mov	x11, x2
    2bd4:	5280002a 	mov	w10, #0x1                   	// #1
    2bd8:	17fffff1 	b	2b9c <fwp_wake_io+0x78>
    2bdc:	d503201f 	nop

0000000000002be0 <fwp_poll_events>:
    2be0:	d10103ff 	sub	sp, sp, #0x40
    2be4:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    2be8:	f947f400 	ldr	x0, [x0, #4072]
    2bec:	a9027bfd 	stp	x29, x30, [sp, #32]
    2bf0:	910083fd 	add	x29, sp, #0x20
    2bf4:	a90353f3 	stp	x19, x20, [sp, #48]
    2bf8:	d00000f4 	adrp	x20, 20000 <__data_start>
    2bfc:	f9400001 	ldr	x1, [x0]
    2c00:	f9000fe1 	str	x1, [sp, #24]
    2c04:	d2800001 	mov	x1, #0x0                   	// #0
    2c08:	97fffdce 	bl	2340 <fwp_now_ns>
    2c0c:	91014281 	add	x1, x20, #0x50
    2c10:	f9401c33 	ldr	x19, [x1, #56]
    2c14:	b4000e93 	cbz	x19, 2de4 <fwp_poll_events+0x204>
    2c18:	aa1303e1 	mov	x1, x19
    2c1c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2c20:	14000005 	b	2c34 <fwp_poll_events+0x54>
    2c24:	f9408821 	ldr	x1, [x1, #272]
    2c28:	eb03005f 	cmp	x2, x3
    2c2c:	9a83d042 	csel	x2, x2, x3, le
    2c30:	b40000c1 	cbz	x1, 2c48 <fwp_poll_events+0x68>
    2c34:	f9403423 	ldr	x3, [x1, #104]
    2c38:	b6ffff62 	tbz	x2, #63, 2c24 <fwp_poll_events+0x44>
    2c3c:	f9408821 	ldr	x1, [x1, #272]
    2c40:	aa0303e2 	mov	x2, x3
    2c44:	b5ffff81 	cbnz	x1, 2c34 <fwp_poll_events+0x54>
    2c48:	b7f80ce2 	tbnz	x2, #63, 2de4 <fwp_poll_events+0x204>
    2c4c:	cb000042 	sub	x2, x2, x0
    2c50:	f100005f 	cmp	x2, #0x0
    2c54:	540005cd 	b.le	2d0c <fwp_poll_events+0x12c>
    2c58:	d2869b60 	mov	x0, #0x34db                	// #13531
    2c5c:	d2884801 	mov	x1, #0x4240                	// #16960
    2c60:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2c64:	f2a001e1 	movk	x1, #0xf, lsl #16
    2c68:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2c6c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2c70:	f2e86360 	movk	x0, #0x431b, lsl #48
    2c74:	9b407c40 	smulh	x0, x2, x0
    2c78:	9352fc00 	asr	x0, x0, #18
    2c7c:	cb82fc00 	sub	x0, x0, x2, asr #63
    2c80:	9b018802 	msub	x2, x0, x1, x2
    2c84:	f100005f 	cmp	x2, #0x0
    2c88:	9a800400 	cinc	x0, x0, ne	// ne = any
    2c8c:	eb03001f 	cmp	x0, x3
    2c90:	54000a0c 	b.gt	2dd0 <fwp_poll_events+0x1f0>
    2c94:	340003c0 	cbz	w0, 2d0c <fwp_poll_events+0x12c>
    2c98:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2c9c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2ca0:	72a20c42 	movk	w2, #0x1062, lsl #16
    2ca4:	9ba27c02 	umull	x2, w0, w2
    2ca8:	d366fc43 	lsr	x3, x2, #38
    2cac:	aa0303e2 	mov	x2, x3
    2cb0:	1b048063 	msub	w3, w3, w4, w0
    2cb4:	9b217c63 	smull	x3, w3, w1
    2cb8:	d2800001 	mov	x1, #0x0                   	// #0
    2cbc:	910023e0 	add	x0, sp, #0x8
    2cc0:	a9008fe2 	stp	x2, x3, [sp, #8]
    2cc4:	97fffa57 	bl	1620 <nanosleep@plt>
    2cc8:	91014280 	add	x0, x20, #0x50
    2ccc:	f9401c13 	ldr	x19, [x0, #56]
    2cd0:	97fffd9c 	bl	2340 <fwp_now_ns>
    2cd4:	aa0003e6 	mov	x6, x0
    2cd8:	b50001f3 	cbnz	x19, 2d14 <fwp_poll_events+0x134>
    2cdc:	d503201f 	nop
    2ce0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    2ce4:	f947f400 	ldr	x0, [x0, #4072]
    2ce8:	f9400fe2 	ldr	x2, [sp, #24]
    2cec:	f9400001 	ldr	x1, [x0]
    2cf0:	eb010042 	subs	x2, x2, x1
    2cf4:	d2800001 	mov	x1, #0x0                   	// #0
    2cf8:	540008c1 	b.ne	2e10 <fwp_poll_events+0x230>  // b.any
    2cfc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2d00:	a94353f3 	ldp	x19, x20, [sp, #48]
    2d04:	910103ff 	add	sp, sp, #0x40
    2d08:	d65f03c0 	ret
    2d0c:	97fffd8d 	bl	2340 <fwp_now_ns>
    2d10:	aa0003e6 	mov	x6, x0
    2d14:	4f000400 	movi	v0.4s, #0x0
    2d18:	91014288 	add	x8, x20, #0x50
    2d1c:	52800027 	mov	w7, #0x1                   	// #1
    2d20:	f9403661 	ldr	x1, [x19, #104]
    2d24:	aa1303e5 	mov	x5, x19
    2d28:	f9408a73 	ldr	x19, [x19, #272]
    2d2c:	eb06003f 	cmp	x1, x6
    2d30:	5400032c 	b.gt	2d94 <fwp_poll_events+0x1b4>
    2d34:	394154a0 	ldrb	w0, [x5, #85]
    2d38:	36000120 	tbz	w0, #0, 2d5c <fwp_poll_events+0x17c>
    2d3c:	f94084a0 	ldr	x0, [x5, #264]
    2d40:	b40003c0 	cbz	x0, 2db8 <fwp_poll_events+0x1d8>
    2d44:	f9008813 	str	x19, [x0, #272]
    2d48:	b4000053 	cbz	x19, 2d50 <fwp_poll_events+0x170>
    2d4c:	f9008660 	str	x0, [x19, #264]
    2d50:	910800a0 	add	x0, x5, #0x200
    2d54:	390154bf 	strb	wzr, [x5, #85]
    2d58:	3c908000 	stur	q0, [x0, #-248]
    2d5c:	f94030a0 	ldr	x0, [x5, #96]
    2d60:	390158a7 	strb	w7, [x5, #86]
    2d64:	f100001f 	cmp	x0, #0x0
    2d68:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2d6c:	5400018d 	b.le	2d9c <fwp_poll_events+0x1bc>
    2d70:	f94028a0 	ldr	x0, [x5, #80]
    2d74:	f2001c1f 	tst	x0, #0xff000000ff
    2d78:	540000e1 	b.ne	2d94 <fwp_poll_events+0x1b4>  // b.any
    2d7c:	f9401500 	ldr	x0, [x8, #40]
    2d80:	390150a7 	strb	w7, [x5, #84]
    2d84:	f90080bf 	str	xzr, [x5, #256]
    2d88:	b40001e0 	cbz	x0, 2dc4 <fwp_poll_events+0x1e4>
    2d8c:	f9001505 	str	x5, [x8, #40]
    2d90:	f9008005 	str	x5, [x0, #256]
    2d94:	b5fffc73 	cbnz	x19, 2d20 <fwp_poll_events+0x140>
    2d98:	17ffffd2 	b	2ce0 <fwp_poll_events+0x100>
    2d9c:	394144a0 	ldrb	w0, [x5, #81]
    2da0:	3707fe80 	tbnz	w0, #0, 2d70 <fwp_poll_events+0x190>
    2da4:	394140a0 	ldrb	w0, [x5, #80]
    2da8:	3707fe40 	tbnz	w0, #0, 2d70 <fwp_poll_events+0x190>
    2dac:	aa0503e0 	mov	x0, x5
    2db0:	97fffd10 	bl	21f0 <fwp_cancel_tree.part.0>
    2db4:	17ffffef 	b	2d70 <fwp_poll_events+0x190>
    2db8:	91014281 	add	x1, x20, #0x50
    2dbc:	f9001c33 	str	x19, [x1, #56]
    2dc0:	17ffffe2 	b	2d48 <fwp_poll_events+0x168>
    2dc4:	f9001505 	str	x5, [x8, #40]
    2dc8:	f9001905 	str	x5, [x8, #48]
    2dcc:	17fffff2 	b	2d94 <fwp_poll_events+0x1b4>
    2dd0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2dd4:	d2989362 	mov	x2, #0xc49b                	// #50331
    2dd8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2ddc:	f2a00402 	movk	x2, #0x20, lsl #16
    2de0:	17ffffb6 	b	2cb8 <fwp_poll_events+0xd8>
    2de4:	97fffb9b 	bl	1c50 <fwp_flush>
    2de8:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x165f8>
    2dec:	f947e863 	ldr	x3, [x3, #4048]
    2df0:	d2800562 	mov	x2, #0x2b                  	// #43
    2df4:	d2800021 	mov	x1, #0x1                   	// #1
    2df8:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    2dfc:	91122000 	add	x0, x0, #0x488
    2e00:	f9400063 	ldr	x3, [x3]
    2e04:	97fffa13 	bl	1650 <fwrite@plt>
    2e08:	52800ca0 	mov	w0, #0x65                  	// #101
    2e0c:	97fff97d 	bl	1400 <exit@plt>
    2e10:	97fff9d0 	bl	1550 <__stack_chk_fail@plt>

0000000000002e14 <fwp_rc_wide_dup>:
    2e14:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2e18:	910003fd 	mov	x29, sp
    2e1c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e20:	aa0003f3 	mov	x19, x0
    2e24:	ca404400 	eor	x0, x0, x0, lsr #17
    2e28:	f90013f5 	str	x21, [sp, #32]
    2e2c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    2e30:	ca402400 	eor	x0, x0, x0, lsr #9
    2e34:	9114c2a2 	add	x2, x21, #0x530
    2e38:	92401c00 	and	x0, x0, #0xff
    2e3c:	910a2403 	add	x3, x0, #0x289
    2e40:	8b000c40 	add	x0, x2, x0, lsl #3
    2e44:	8b030c54 	add	x20, x2, x3, lsl #3
    2e48:	f94a2401 	ldr	x1, [x0, #5192]
    2e4c:	b50000a1 	cbnz	x1, 2e60 <fwp_rc_wide_dup+0x4c>
    2e50:	1400002d 	b	2f04 <fwp_rc_wide_dup+0xf0>
    2e54:	91004034 	add	x20, x1, #0x10
    2e58:	f9400821 	ldr	x1, [x1, #16]
    2e5c:	b4000241 	cbz	x1, 2ea4 <fwp_rc_wide_dup+0x90>
    2e60:	f9400022 	ldr	x2, [x1]
    2e64:	eb02027f 	cmp	x19, x2
    2e68:	54ffff61 	b.ne	2e54 <fwp_rc_wide_dup+0x40>  // b.any
    2e6c:	f9400281 	ldr	x1, [x20]
    2e70:	39400260 	ldrb	w0, [x19]
    2e74:	7103f81f 	cmp	w0, #0xfe
    2e78:	54000220 	b.eq	2ebc <fwp_rc_wide_dup+0xa8>  // b.none
    2e7c:	b40001a1 	cbz	x1, 2eb0 <fwp_rc_wide_dup+0x9c>
    2e80:	f9400420 	ldr	x0, [x1, #8]
    2e84:	b100041f 	cmn	x0, #0x1
    2e88:	540004a0 	b.eq	2f1c <fwp_rc_wide_dup+0x108>  // b.none
    2e8c:	91000400 	add	x0, x0, #0x1
    2e90:	f9000420 	str	x0, [x1, #8]
    2e94:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e98:	f94013f5 	ldr	x21, [sp, #32]
    2e9c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2ea0:	d65f03c0 	ret
    2ea4:	39400260 	ldrb	w0, [x19]
    2ea8:	7103f81f 	cmp	w0, #0xfe
    2eac:	540000a0 	b.eq	2ec0 <fwp_rc_wide_dup+0xac>  // b.none
    2eb0:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    2eb4:	91138000 	add	x0, x0, #0x4e0
    2eb8:	97fffd12 	bl	2300 <fwp_trap>
    2ebc:	b5000281 	cbnz	x1, 2f0c <fwp_rc_wide_dup+0xf8>
    2ec0:	d2800300 	mov	x0, #0x18                  	// #24
    2ec4:	97fff98b 	bl	14f0 <malloc@plt>
    2ec8:	b4000280 	cbz	x0, 2f18 <fwp_rc_wide_dup+0x104>
    2ecc:	d2801fe1 	mov	x1, #0xff                  	// #255
    2ed0:	a9000413 	stp	x19, x1, [x0]
    2ed4:	9114c2b5 	add	x21, x21, #0x530
    2ed8:	f900081f 	str	xzr, [x0, #16]
    2edc:	12800001 	mov	w1, #0xffffffff            	// #-1
    2ee0:	f9000280 	str	x0, [x20]
    2ee4:	39000261 	strb	w1, [x19]
    2ee8:	f94e26a0 	ldr	x0, [x21, #7240]
    2eec:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ef0:	91000400 	add	x0, x0, #0x1
    2ef4:	f90e26a0 	str	x0, [x21, #7240]
    2ef8:	f94013f5 	ldr	x21, [sp, #32]
    2efc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f00:	d65f03c0 	ret
    2f04:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    2f08:	17ffffda 	b	2e70 <fwp_rc_wide_dup+0x5c>
    2f0c:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    2f10:	9112e000 	add	x0, x0, #0x4b8
    2f14:	97fffcfb 	bl	2300 <fwp_trap>
    2f18:	97fffb8e 	bl	1d50 <fwp_heap_oom>
    2f1c:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    2f20:	91142000 	add	x0, x0, #0x508
    2f24:	97fffcf7 	bl	2300 <fwp_trap>
    2f28:	d503201f 	nop
    2f2c:	d503201f 	nop

0000000000002f30 <fwp_rc_forget_slot>:
    2f30:	aa0003e1 	mov	x1, x0
    2f34:	39400000 	ldrb	w0, [x0]
    2f38:	7103fc1f 	cmp	w0, #0xff
    2f3c:	54000040 	b.eq	2f44 <fwp_rc_forget_slot+0x14>  // b.none
    2f40:	d65f03c0 	ret
    2f44:	ca414420 	eor	x0, x1, x1, lsr #17
    2f48:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f4c:	ca402400 	eor	x0, x0, x0, lsr #9
    2f50:	910003fd 	mov	x29, sp
    2f54:	92401c00 	and	x0, x0, #0xff
    2f58:	f9000bf3 	str	x19, [sp, #16]
    2f5c:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    2f60:	9114c262 	add	x2, x19, #0x530
    2f64:	910a2403 	add	x3, x0, #0x289
    2f68:	8b000c40 	add	x0, x2, x0, lsl #3
    2f6c:	8b030c43 	add	x3, x2, x3, lsl #3
    2f70:	f94a2400 	ldr	x0, [x0, #5192]
    2f74:	b50000a0 	cbnz	x0, 2f88 <fwp_rc_forget_slot+0x58>
    2f78:	14000011 	b	2fbc <fwp_rc_forget_slot+0x8c>
    2f7c:	91004003 	add	x3, x0, #0x10
    2f80:	f9400800 	ldr	x0, [x0, #16]
    2f84:	b40001c0 	cbz	x0, 2fbc <fwp_rc_forget_slot+0x8c>
    2f88:	f9400002 	ldr	x2, [x0]
    2f8c:	eb02003f 	cmp	x1, x2
    2f90:	54ffff61 	b.ne	2f7c <fwp_rc_forget_slot+0x4c>  // b.any
    2f94:	f9400801 	ldr	x1, [x0, #16]
    2f98:	9114c273 	add	x19, x19, #0x530
    2f9c:	f9000061 	str	x1, [x3]
    2fa0:	97fff99c 	bl	1610 <free@plt>
    2fa4:	f94e2660 	ldr	x0, [x19, #7240]
    2fa8:	d1000400 	sub	x0, x0, #0x1
    2fac:	f90e2660 	str	x0, [x19, #7240]
    2fb0:	f9400bf3 	ldr	x19, [sp, #16]
    2fb4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2fb8:	d65f03c0 	ret
    2fbc:	b0000020 	adrp	x0, 7000 <__modti3+0x1a0>
    2fc0:	91138000 	add	x0, x0, #0x4e0
    2fc4:	97fffccf 	bl	2300 <fwp_trap>
    2fc8:	d503201f 	nop
    2fcc:	d503201f 	nop

0000000000002fd0 <fwp_rc_prepare_chunk>:
    2fd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    2fdc:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    2fe0:	9114c2c2 	add	x2, x22, #0x530
    2fe4:	b9401c03 	ldr	w3, [x0, #28]
    2fe8:	aa0103f5 	mov	x21, x1
    2fec:	a90153f3 	stp	x19, x20, [sp, #16]
    2ff0:	aa0003f4 	mov	x20, x0
    2ff4:	f94e2440 	ldr	x0, [x2, #7240]
    2ff8:	b4000440 	cbz	x0, 3080 <fwp_rc_prepare_chunk+0xb0>
    2ffc:	d2800013 	mov	x19, #0x0                   	// #0
    3000:	35000203 	cbnz	w3, 3040 <fwp_rc_prepare_chunk+0x70>
    3004:	b4000361 	cbz	x1, 3070 <fwp_rc_prepare_chunk+0xa0>
    3008:	f9401280 	ldr	x0, [x20, #32]
    300c:	97fff981 	bl	1610 <free@plt>
    3010:	aa1503e0 	mov	x0, x21
    3014:	d2800021 	mov	x1, #0x1                   	// #1
    3018:	97fff946 	bl	1530 <calloc@plt>
    301c:	f9001280 	str	x0, [x20, #32]
    3020:	b5000460 	cbnz	x0, 30ac <fwp_rc_prepare_chunk+0xdc>
    3024:	97fffb4b 	bl	1d50 <fwp_heap_oom>
    3028:	97ffffc2 	bl	2f30 <fwp_rc_forget_slot>
    302c:	91000673 	add	x19, x19, #0x1
    3030:	b9401e83 	ldr	w3, [x20, #28]
    3034:	eb13007f 	cmp	x3, x19
    3038:	54000169 	b.ls	3064 <fwp_rc_prepare_chunk+0x94>  // b.plast
    303c:	d503201f 	nop
    3040:	f9401283 	ldr	x3, [x20, #32]
    3044:	8b130060 	add	x0, x3, x19
    3048:	38736863 	ldrb	w3, [x3, x19]
    304c:	7103fc7f 	cmp	w3, #0xff
    3050:	54fffec0 	b.eq	3028 <fwp_rc_prepare_chunk+0x58>  // b.none
    3054:	b9401e83 	ldr	w3, [x20, #28]
    3058:	91000673 	add	x19, x19, #0x1
    305c:	eb13007f 	cmp	x3, x19
    3060:	54ffff08 	b.hi	3040 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    3064:	eb0302bf 	cmp	x21, x3
    3068:	54000121 	b.ne	308c <fwp_rc_prepare_chunk+0xbc>  // b.any
    306c:	b5000335 	cbnz	x21, 30d0 <fwp_rc_prepare_chunk+0x100>
    3070:	a94153f3 	ldp	x19, x20, [sp, #16]
    3074:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3078:	a8c37bfd 	ldp	x29, x30, [sp], #48
    307c:	d65f03c0 	ret
    3080:	2a0303e3 	mov	w3, w3
    3084:	eb0302bf 	cmp	x21, x3
    3088:	54ffff20 	b.eq	306c <fwp_rc_prepare_chunk+0x9c>  // b.none
    308c:	9114c2c2 	add	x2, x22, #0x530
    3090:	f9401280 	ldr	x0, [x20, #32]
    3094:	f94e2841 	ldr	x1, [x2, #7248]
    3098:	cb030021 	sub	x1, x1, x3
    309c:	f90e2841 	str	x1, [x2, #7248]
    30a0:	97fff95c 	bl	1610 <free@plt>
    30a4:	b5fffb75 	cbnz	x21, 3010 <fwp_rc_prepare_chunk+0x40>
    30a8:	f900129f 	str	xzr, [x20, #32]
    30ac:	9114c2d6 	add	x22, x22, #0x530
    30b0:	f94e2ac0 	ldr	x0, [x22, #7248]
    30b4:	b9001e95 	str	w21, [x20, #28]
    30b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    30bc:	8b150000 	add	x0, x0, x21
    30c0:	f90e2ac0 	str	x0, [x22, #7248]
    30c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    30c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30cc:	d65f03c0 	ret
    30d0:	f9401280 	ldr	x0, [x20, #32]
    30d4:	aa1503e2 	mov	x2, x21
    30d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    30dc:	52800001 	mov	w1, #0x0                   	// #0
    30e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    30e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e8:	17fff90e 	b	1520 <memset@plt>
    30ec:	d503201f 	nop

00000000000030f0 <fwp_heap_refill>:
    30f0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30f4:	910003fd 	mov	x29, sp
    30f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    30fc:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    3100:	9114c2b5 	add	x21, x21, #0x530
    3104:	aa0003f6 	mov	x22, x0
    3108:	d2800020 	mov	x0, #0x1                   	// #1
    310c:	a90153f3 	stp	x19, x20, [sp, #16]
    3110:	a90363f7 	stp	x23, x24, [sp, #48]
    3114:	2a0103f7 	mov	w23, w1
    3118:	2a0203f8 	mov	w24, w2
    311c:	97fffb1d 	bl	1d90 <fwp_heap_chunks>
    3120:	aa0003f3 	mov	x19, x0
    3124:	f949fea2 	ldr	x2, [x21, #5112]
    3128:	8b000800 	add	x0, x0, x0, lsl #2
    312c:	2a1703e1 	mov	w1, w23
    3130:	52800025 	mov	w5, #0x1                   	// #1
    3134:	d37df000 	lsl	x0, x0, #3
    3138:	910f0021 	add	x1, x1, #0x3c0
    313c:	8b000054 	add	x20, x2, x0
    3140:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    3144:	52a00024 	mov	w4, #0x10000               	// #65536
    3148:	38206845 	strb	w5, [x2, x0]
    314c:	aa1403e0 	mov	x0, x20
    3150:	39000698 	strb	w24, [x20, #1]
    3154:	39000a97 	strb	w23, [x20, #2]
    3158:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    315c:	b9000681 	str	w1, [x20, #4]
    3160:	2a0103e5 	mov	w5, w1
    3164:	8b0300a2 	add	x2, x5, x3
    3168:	1ac10881 	udiv	w1, w4, w1
    316c:	9ac50842 	udiv	x2, x2, x5
    3170:	b9000a81 	str	w1, [x20, #8]
    3174:	92404021 	and	x1, x1, #0x1ffff
    3178:	b9001a82 	str	w2, [x20, #24]
    317c:	97ffff95 	bl	2fd0 <fwp_rc_prepare_chunk>
    3180:	f949daa0 	ldr	x0, [x21, #5040]
    3184:	29408a81 	ldp	w1, w2, [x20, #4]
    3188:	8b134000 	add	x0, x0, x19, lsl #16
    318c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3190:	8b214003 	add	x3, x0, w1, uxtw
    3194:	9ba20021 	umaddl	x1, w1, w2, x0
    3198:	a94363f7 	ldp	x23, x24, [sp, #48]
    319c:	a90086c3 	stp	x3, x1, [x22, #8]
    31a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    31a4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    31a8:	d65f03c0 	ret
    31ac:	d503201f 	nop

00000000000031b0 <fwp_mem_free>:
    31b0:	b40003c0 	cbz	x0, 3228 <fwp_mem_free+0x78>
    31b4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    31b8:	910003fd 	mov	x29, sp
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    31c4:	9114c2a1 	add	x1, x21, #0x530
    31c8:	a90153f3 	stp	x19, x20, [sp, #16]
    31cc:	aa0003f3 	mov	x19, x0
    31d0:	f949d823 	ldr	x3, [x1, #5040]
    31d4:	f949ec22 	ldr	x2, [x1, #5080]
    31d8:	cb030000 	sub	x0, x0, x3
    31dc:	eb02401f 	cmp	x0, x2, lsl #16
    31e0:	540001c2 	b.cs	3218 <fwp_mem_free+0x68>  // b.hs, b.nlast
    31e4:	d350fc16 	lsr	x22, x0, #16
    31e8:	a90363f7 	stp	x23, x24, [sp, #48]
    31ec:	f949fc22 	ldr	x2, [x1, #5112]
    31f0:	8b160ad4 	add	x20, x22, x22, lsl #2
    31f4:	d37df294 	lsl	x20, x20, #3
    31f8:	ab140057 	adds	x23, x2, x20
    31fc:	540000c0 	b.eq	3214 <fwp_mem_free+0x64>  // b.none
    3200:	38746842 	ldrb	w2, [x2, x20]
    3204:	7100045f 	cmp	w2, #0x1
    3208:	54000120 	b.eq	322c <fwp_mem_free+0x7c>  // b.none
    320c:	7100085f 	cmp	w2, #0x2
    3210:	540005e0 	b.eq	32cc <fwp_mem_free+0x11c>  // b.none
    3214:	a94363f7 	ldp	x23, x24, [sp, #48]
    3218:	a94153f3 	ldp	x19, x20, [sp, #16]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3224:	d65f03c0 	ret
    3228:	d65f03c0 	ret
    322c:	f94012f8 	ldr	x24, [x23, #32]
    3230:	b94006e1 	ldr	w1, [x23, #4]
    3234:	f90023f9 	str	x25, [sp, #64]
    3238:	2a0103e2 	mov	w2, w1
    323c:	394006f9 	ldrb	w25, [x23, #1]
    3240:	39400af4 	ldrb	w20, [x23, #2]
    3244:	b4000158 	cbz	x24, 326c <fwp_mem_free+0xbc>
    3248:	92403e76 	and	x22, x19, #0xffff
    324c:	9ac20ad6 	udiv	x22, x22, x2
    3250:	38766b01 	ldrb	w1, [x24, x22]
    3254:	8b160300 	add	x0, x24, x22
    3258:	7103fc3f 	cmp	w1, #0xff
    325c:	54000980 	b.eq	338c <fwp_mem_free+0x1dc>  // b.none
    3260:	38366b1f 	strb	wzr, [x24, x22]
    3264:	b94006e1 	ldr	w1, [x23, #4]
    3268:	2a0103e2 	mov	w2, w1
    326c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    3270:	d37f1e83 	ubfiz	x3, x20, #1, #8
    3274:	cb390000 	sub	x0, x0, w25, uxtb
    3278:	8b340074 	add	x20, x3, w20, uxtb
    327c:	9114c2b5 	add	x21, x21, #0x530
    3280:	1e630021 	ucvtf	d1, w1
    3284:	d37ae400 	lsl	x0, x0, #6
    3288:	8b140c14 	add	x20, x0, x20, lsl #3
    328c:	a94363f7 	ldp	x23, x24, [sp, #48]
    3290:	f8746aa0 	ldr	x0, [x21, x20]
    3294:	f94023f9 	ldr	x25, [sp, #64]
    3298:	aa2003e0 	mvn	x0, x0
    329c:	fd4a22a0 	ldr	d0, [x21, #5184]
    32a0:	f9000260 	str	x0, [x19]
    32a4:	f8346ab3 	str	x19, [x21, x20]
    32a8:	f94a12a0 	ldr	x0, [x21, #5152]
    32ac:	1e612800 	fadd	d0, d0, d1
    32b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32b4:	cb020000 	sub	x0, x0, x2
    32b8:	f90a12a0 	str	x0, [x21, #5152]
    32bc:	fd0a22a0 	str	d0, [x21, #5184]
    32c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32c4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    32c8:	d65f03c0 	ret
    32cc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    32d0:	8b000063 	add	x3, x3, x0
    32d4:	eb03027f 	cmp	x19, x3
    32d8:	54fff9e1 	b.ne	3214 <fwp_mem_free+0x64>  // b.any
    32dc:	fd400ae1 	ldr	d1, [x23, #16]
    32e0:	fd4a2020 	ldr	d0, [x1, #5184]
    32e4:	f9400ae0 	ldr	x0, [x23, #16]
    32e8:	7e61d821 	ucvtf	d1, d1
    32ec:	f94a1022 	ldr	x2, [x1, #5152]
    32f0:	f94012f3 	ldr	x19, [x23, #32]
    32f4:	1e612800 	fadd	d0, d0, d1
    32f8:	cb000042 	sub	x2, x2, x0
    32fc:	f90a1022 	str	x2, [x1, #5152]
    3300:	fd0a2020 	str	d0, [x1, #5184]
    3304:	b40000b3 	cbz	x19, 3318 <fwp_mem_free+0x168>
    3308:	39400260 	ldrb	w0, [x19]
    330c:	7103fc1f 	cmp	w0, #0xff
    3310:	54000380 	b.eq	3380 <fwp_mem_free+0x1d0>  // b.none
    3314:	3900027f 	strb	wzr, [x19]
    3318:	b9400ee2 	ldr	w2, [x23, #12]
    331c:	b4000142 	cbz	x2, 3344 <fwp_mem_free+0x194>
    3320:	9114c2a1 	add	x1, x21, #0x530
    3324:	8b160040 	add	x0, x2, x22
    3328:	8b000800 	add	x0, x0, x0, lsl #2
    332c:	f949fc21 	ldr	x1, [x1, #5112]
    3330:	8b140034 	add	x20, x1, x20
    3334:	8b000c20 	add	x0, x1, x0, lsl #3
    3338:	3802869f 	strb	wzr, [x20], #40
    333c:	eb00029f 	cmp	x20, x0
    3340:	54ffffc1 	b.ne	3338 <fwp_mem_free+0x188>  // b.any
    3344:	9114c2a0 	add	x0, x21, #0x530
    3348:	f94a1801 	ldr	x1, [x0, #5168]
    334c:	f949f803 	ldr	x3, [x0, #5104]
    3350:	8b020021 	add	x1, x1, x2
    3354:	f90a1801 	str	x1, [x0, #5168]
    3358:	eb16007f 	cmp	x3, x22
    335c:	54000049 	b.ls	3364 <fwp_mem_free+0x1b4>  // b.plast
    3360:	f909f816 	str	x22, [x0, #5104]
    3364:	9114c2b5 	add	x21, x21, #0x530
    3368:	f949f6a0 	ldr	x0, [x21, #5096]
    336c:	eb16001f 	cmp	x0, x22
    3370:	54fff529 	b.ls	3214 <fwp_mem_free+0x64>  // b.plast
    3374:	a94363f7 	ldp	x23, x24, [sp, #48]
    3378:	f909f6b6 	str	x22, [x21, #5096]
    337c:	17ffffa7 	b	3218 <fwp_mem_free+0x68>
    3380:	aa1303e0 	mov	x0, x19
    3384:	97fffeeb 	bl	2f30 <fwp_rc_forget_slot>
    3388:	17ffffe3 	b	3314 <fwp_mem_free+0x164>
    338c:	97fffee9 	bl	2f30 <fwp_rc_forget_slot>
    3390:	17ffffb4 	b	3260 <fwp_mem_free+0xb0>

0000000000003394 <fwp_heap_alloc_big>:
    3394:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    3398:	910003fd 	mov	x29, sp
    339c:	a90153f3 	stp	x19, x20, [sp, #16]
    33a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    33a4:	a90363f7 	stp	x23, x24, [sp, #48]
    33a8:	aa0003f7 	mov	x23, x0
    33ac:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    33b0:	a9046bf9 	stp	x25, x26, [sp, #64]
    33b4:	eb0002ff 	cmp	x23, x0
    33b8:	54000888 	b.hi	34c8 <fwp_heap_alloc_big+0x134>  // b.pmore
    33bc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    33c0:	8b0002f4 	add	x20, x23, x0
    33c4:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xcb0>
    33c8:	9114c359 	add	x25, x26, #0x530
    33cc:	d350fe94 	lsr	x20, x20, #16
    33d0:	2a0103f5 	mov	w21, w1
    33d4:	aa1403e0 	mov	x0, x20
    33d8:	97fffa6e 	bl	1d90 <fwp_heap_chunks>
    33dc:	f949ff22 	ldr	x2, [x25, #5112]
    33e0:	8b000813 	add	x19, x0, x0, lsl #2
    33e4:	aa0003f8 	mov	x24, x0
    33e8:	52800043 	mov	w3, #0x2                   	// #2
    33ec:	d37df273 	lsl	x19, x19, #3
    33f0:	d2800021 	mov	x1, #0x1                   	// #1
    33f4:	8b130040 	add	x0, x2, x19
    33f8:	38336843 	strb	w3, [x2, x19]
    33fc:	39000415 	strb	w21, [x0, #1]
    3400:	b9000c14 	str	w20, [x0, #12]
    3404:	f9000817 	str	x23, [x0, #16]
    3408:	97fffef2 	bl	2fd0 <fwp_rc_prepare_chunk>
    340c:	f100069f 	cmp	x20, #0x1
    3410:	54000269 	b.ls	345c <fwp_heap_alloc_big+0xc8>  // b.plast
    3414:	8b180294 	add	x20, x20, x24
    3418:	9100a273 	add	x19, x19, #0x28
    341c:	a90573fb 	stp	x27, x28, [sp, #80]
    3420:	5280007b 	mov	w27, #0x3                   	// #3
    3424:	8b140a94 	add	x20, x20, x20, lsl #2
    3428:	2a1803fc 	mov	w28, w24
    342c:	9adb2296 	lsl	x22, x20, x27
    3430:	f949ff35 	ldr	x21, [x25, #5112]
    3434:	d2800001 	mov	x1, #0x0                   	// #0
    3438:	8b1302b4 	add	x20, x21, x19
    343c:	aa1403e0 	mov	x0, x20
    3440:	97fffee4 	bl	2fd0 <fwp_rc_prepare_chunk>
    3444:	38336abb 	strb	w27, [x21, x19]
    3448:	9100a273 	add	x19, x19, #0x28
    344c:	b9000e9c 	str	w28, [x20, #12]
    3450:	eb1302df 	cmp	x22, x19
    3454:	54fffee1 	b.ne	3430 <fwp_heap_alloc_big+0x9c>  // b.any
    3458:	a94573fb 	ldp	x27, x28, [sp, #80]
    345c:	9114c353 	add	x19, x26, #0x530
    3460:	aa1703e2 	mov	x2, x23
    3464:	52800001 	mov	w1, #0x0                   	// #0
    3468:	f949da60 	ldr	x0, [x19, #5040]
    346c:	8b184018 	add	x24, x0, x24, lsl #16
    3470:	aa1803e0 	mov	x0, x24
    3474:	97fff82b 	bl	1520 <memset@plt>
    3478:	f94a1260 	ldr	x0, [x19, #5152]
    347c:	ab170000 	adds	x0, x0, x23
    3480:	54000242 	b.cs	34c8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    3484:	f94a1661 	ldr	x1, [x19, #5160]
    3488:	f90a1260 	str	x0, [x19, #5152]
    348c:	eb01001f 	cmp	x0, x1
    3490:	54000049 	b.ls	3498 <fwp_heap_alloc_big+0x104>  // b.plast
    3494:	f90a1660 	str	x0, [x19, #5160]
    3498:	9114c35a 	add	x26, x26, #0x530
    349c:	9e6202e0 	scvtf	d0, x23
    34a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a4:	aa1803e0 	mov	x0, x24
    34a8:	fd4a1f41 	ldr	d1, [x26, #5176]
    34ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34b0:	1e602820 	fadd	d0, d1, d0
    34b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    34b8:	fd0a1f40 	str	d0, [x26, #5176]
    34bc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    34c0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    34c4:	d65f03c0 	ret
    34c8:	a90573fb 	stp	x27, x28, [sp, #80]
    34cc:	97fffa21 	bl	1d50 <fwp_heap_oom>

00000000000034d0 <fwp_heap_alloc_slow>:
    34d0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    34d4:	910003fd 	mov	x29, sp
    34d8:	a90153f3 	stp	x19, x20, [sp, #16]
    34dc:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    34e0:	9114c262 	add	x2, x19, #0x530
    34e4:	a9025bf5 	stp	x21, x22, [sp, #32]
    34e8:	aa0003f5 	mov	x21, x0
    34ec:	2a0103f4 	mov	w20, w1
    34f0:	b953a440 	ldr	w0, [x2, #5028]
    34f4:	34000600 	cbz	w0, 35b4 <fwp_heap_alloc_slow+0xe4>
    34f8:	f14012bf 	cmp	x21, #0x4, lsl #12
    34fc:	54000628 	b.hi	35c0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3500:	91003ea0 	add	x0, x21, #0xf
    3504:	9114c262 	add	x2, x19, #0x530
    3508:	f9001bf7 	str	x23, [sp, #48]
    350c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3510:	8b401040 	add	x0, x2, x0, lsr #4
    3514:	cb34c084 	sub	x4, x4, w20, sxtw
    3518:	d37ae484 	lsl	x4, x4, #6
    351c:	397e8003 	ldrb	w3, [x0, #4000]
    3520:	910f0060 	add	x0, x3, #0x3c0
    3524:	aa0303e1 	mov	x1, x3
    3528:	8b030463 	add	x3, x3, x3, lsl #1
    352c:	8b030c83 	add	x3, x4, x3, lsl #3
    3530:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3534:	2a1703f6 	mov	w22, w23
    3538:	f8636844 	ldr	x4, [x2, x3]
    353c:	b40004e4 	cbz	x4, 35d8 <fwp_heap_alloc_slow+0x108>
    3540:	f9400080 	ldr	x0, [x4]
    3544:	aa2003e0 	mvn	x0, x0
    3548:	f8236840 	str	x0, [x2, x3]
    354c:	7100069f 	cmp	w20, #0x1
    3550:	aa0403e0 	mov	x0, x4
    3554:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    3558:	52800001 	mov	w1, #0x0                   	// #0
    355c:	97fff7f1 	bl	1520 <memset@plt>
    3560:	aa0003e4 	mov	x4, x0
    3564:	9114c260 	add	x0, x19, #0x530
    3568:	f94a1001 	ldr	x1, [x0, #5152]
    356c:	ab160021 	adds	x1, x1, x22
    3570:	540005c2 	b.cs	3628 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    3574:	f94a1402 	ldr	x2, [x0, #5160]
    3578:	f90a1001 	str	x1, [x0, #5152]
    357c:	eb02003f 	cmp	x1, x2
    3580:	54000049 	b.ls	3588 <fwp_heap_alloc_slow+0xb8>  // b.plast
    3584:	f90a1401 	str	x1, [x0, #5160]
    3588:	9114c273 	add	x19, x19, #0x530
    358c:	1e6302e1 	ucvtf	d1, w23
    3590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3594:	aa0403e0 	mov	x0, x4
    3598:	fd4a1e60 	ldr	d0, [x19, #5176]
    359c:	f9401bf7 	ldr	x23, [sp, #48]
    35a0:	1e612800 	fadd	d0, d0, d1
    35a4:	fd0a1e60 	str	d0, [x19, #5176]
    35a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35ac:	a8c47bfd 	ldp	x29, x30, [sp], #64
    35b0:	d65f03c0 	ret
    35b4:	97fffce8 	bl	2954 <fwp_heap_init>
    35b8:	f14012bf 	cmp	x21, #0x4, lsl #12
    35bc:	54fffa29 	b.ls	3500 <fwp_heap_alloc_slow+0x30>  // b.plast
    35c0:	2a1403e1 	mov	w1, w20
    35c4:	aa1503e0 	mov	x0, x21
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35d0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    35d4:	17ffff70 	b	3394 <fwp_heap_alloc_big>
    35d8:	8b030042 	add	x2, x2, x3
    35dc:	f9400444 	ldr	x4, [x2, #8]
    35e0:	b4000104 	cbz	x4, 3600 <fwp_heap_alloc_slow+0x130>
    35e4:	f9400840 	ldr	x0, [x2, #16]
    35e8:	cb040000 	sub	x0, x0, x4
    35ec:	eb16001f 	cmp	x0, x22
    35f0:	54000083 	b.cc	3600 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    35f4:	8b160080 	add	x0, x4, x22
    35f8:	f9000440 	str	x0, [x2, #8]
    35fc:	17ffffd4 	b	354c <fwp_heap_alloc_slow+0x7c>
    3600:	52800302 	mov	w2, #0x18                  	// #24
    3604:	52807804 	mov	w4, #0x3c0                 	// #960
    3608:	9114c260 	add	x0, x19, #0x530
    360c:	9ba27c23 	umull	x3, w1, w2
    3610:	2a1403e2 	mov	w2, w20
    3614:	9b240e84 	smaddl	x4, w20, w4, x3
    3618:	8b040000 	add	x0, x0, x4
    361c:	97fffeb5 	bl	30f0 <fwp_heap_refill>
    3620:	aa0003e4 	mov	x4, x0
    3624:	17ffffca 	b	354c <fwp_heap_alloc_slow+0x7c>
    3628:	97fff9ca 	bl	1d50 <fwp_heap_oom>
    362c:	d503201f 	nop

0000000000003630 <fwp_rc_share>:
    3630:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    3634:	9114c042 	add	x2, x2, #0x530
    3638:	f949d843 	ldr	x3, [x2, #5040]
    363c:	f949ec41 	ldr	x1, [x2, #5080]
    3640:	cb030000 	sub	x0, x0, x3
    3644:	eb01401f 	cmp	x0, x1, lsl #16
    3648:	540002c2 	b.cs	36a0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    364c:	d350fc01 	lsr	x1, x0, #16
    3650:	f949fc44 	ldr	x4, [x2, #5112]
    3654:	8b010821 	add	x1, x1, x1, lsl #2
    3658:	d37df021 	lsl	x1, x1, #3
    365c:	8b010083 	add	x3, x4, x1
    3660:	f9401062 	ldr	x2, [x3, #32]
    3664:	b40001e2 	cbz	x2, 36a0 <fwp_rc_share+0x70>
    3668:	38616881 	ldrb	w1, [x4, x1]
    366c:	7100083f 	cmp	w1, #0x2
    3670:	540001a0 	b.eq	36a4 <fwp_rc_share+0x74>  // b.none
    3674:	7100043f 	cmp	w1, #0x1
    3678:	54000141 	b.ne	36a0 <fwp_rc_share+0x70>  // b.any
    367c:	29430464 	ldp	w4, w1, [x3, #24]
    3680:	92403c00 	and	x0, x0, #0xffff
    3684:	9b047c00 	mul	x0, x0, x4
    3688:	d360fc00 	lsr	x0, x0, #32
    368c:	eb01001f 	cmp	x0, x1
    3690:	54000082 	b.cs	36a0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    3694:	8b000042 	add	x2, x2, x0
    3698:	39400040 	ldrb	w0, [x2]
    369c:	350000a0 	cbnz	w0, 36b0 <fwp_rc_share+0x80>
    36a0:	d65f03c0 	ret
    36a4:	72003c1f 	tst	w0, #0xffff
    36a8:	54ffff80 	b.eq	3698 <fwp_rc_share+0x68>  // b.none
    36ac:	d65f03c0 	ret
    36b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    36b4:	90000020 	adrp	x0, 7000 <__modti3+0x1a0>
    36b8:	9114a000 	add	x0, x0, #0x528
    36bc:	910003fd 	mov	x29, sp
    36c0:	97fffb10 	bl	2300 <fwp_trap>

00000000000036c4 <e69>:
    36c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36c8:	90000021 	adrp	x1, 7000 <__modti3+0x1a0>
    36cc:	910003fd 	mov	x29, sp
    36d0:	fd400001 	ldr	d1, [x0]
    36d4:	f9000bf3 	str	x19, [sp, #16]
    36d8:	fd448020 	ldr	d0, [x1, #2304]
    36dc:	1e610800 	fmul	d0, d0, d1
    36e0:	9e660013 	fmov	x19, d0
    36e4:	aa1303e0 	mov	x0, x19
    36e8:	97ffffd2 	bl	3630 <fwp_rc_share>
    36ec:	aa1303e0 	mov	x0, x19
    36f0:	f9400bf3 	ldr	x19, [sp, #16]
    36f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36f8:	d65f03c0 	ret
    36fc:	d503201f 	nop

0000000000003700 <e45>:
    3700:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3704:	910003fd 	mov	x29, sp
    3708:	6d400001 	ldp	d1, d0, [x0]
    370c:	f9000bf3 	str	x19, [sp, #16]
    3710:	1e612800 	fadd	d0, d0, d1
    3714:	9e660013 	fmov	x19, d0
    3718:	aa1303e0 	mov	x0, x19
    371c:	97ffffc5 	bl	3630 <fwp_rc_share>
    3720:	aa1303e0 	mov	x0, x19
    3724:	f9400bf3 	ldr	x19, [sp, #16]
    3728:	a8c27bfd 	ldp	x29, x30, [sp], #32
    372c:	d65f03c0 	ret

0000000000003730 <e32>:
    3730:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3734:	910003fd 	mov	x29, sp
    3738:	6d400001 	ldp	d1, d0, [x0]
    373c:	f9000bf3 	str	x19, [sp, #16]
    3740:	1e613800 	fsub	d0, d0, d1
    3744:	9e660013 	fmov	x19, d0
    3748:	aa1303e0 	mov	x0, x19
    374c:	97ffffb9 	bl	3630 <fwp_rc_share>
    3750:	aa1303e0 	mov	x0, x19
    3754:	f9400bf3 	ldr	x19, [sp, #16]
    3758:	a8c27bfd 	ldp	x29, x30, [sp], #32
    375c:	d65f03c0 	ret

0000000000003760 <fwp_rc_dup>:
    3760:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    3764:	9114c042 	add	x2, x2, #0x530
    3768:	f949d841 	ldr	x1, [x2, #5040]
    376c:	f949ec43 	ldr	x3, [x2, #5080]
    3770:	cb010001 	sub	x1, x0, x1
    3774:	eb03403f 	cmp	x1, x3, lsl #16
    3778:	540003c2 	b.cs	37f0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    377c:	d350fc20 	lsr	x0, x1, #16
    3780:	f949fc44 	ldr	x4, [x2, #5112]
    3784:	8b000800 	add	x0, x0, x0, lsl #2
    3788:	d37df002 	lsl	x2, x0, #3
    378c:	8b020083 	add	x3, x4, x2
    3790:	f9401060 	ldr	x0, [x3, #32]
    3794:	b40002e0 	cbz	x0, 37f0 <fwp_rc_dup+0x90>
    3798:	38626882 	ldrb	w2, [x4, x2]
    379c:	7100085f 	cmp	w2, #0x2
    37a0:	540002a0 	b.eq	37f4 <fwp_rc_dup+0x94>  // b.none
    37a4:	7100045f 	cmp	w2, #0x1
    37a8:	54000241 	b.ne	37f0 <fwp_rc_dup+0x90>  // b.any
    37ac:	29430864 	ldp	w4, w2, [x3, #24]
    37b0:	92403c21 	and	x1, x1, #0xffff
    37b4:	9b047c21 	mul	x1, x1, x4
    37b8:	d360fc21 	lsr	x1, x1, #32
    37bc:	eb02003f 	cmp	x1, x2
    37c0:	54000182 	b.cs	37f0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    37c4:	8b010000 	add	x0, x0, x1
    37c8:	39400001 	ldrb	w1, [x0]
    37cc:	34000121 	cbz	w1, 37f0 <fwp_rc_dup+0x90>
    37d0:	b00000e2 	adrp	x2, 20000 <__data_start>
    37d4:	91014042 	add	x2, x2, #0x50
    37d8:	b9404043 	ldr	w3, [x2, #64]
    37dc:	35000123 	cbnz	w3, 3800 <fwp_rc_dup+0xa0>
    37e0:	7103f43f 	cmp	w1, #0xfd
    37e4:	54000168 	b.hi	3810 <fwp_rc_dup+0xb0>  // b.pmore
    37e8:	11000421 	add	w1, w1, #0x1
    37ec:	39000001 	strb	w1, [x0]
    37f0:	d65f03c0 	ret
    37f4:	72003c3f 	tst	w1, #0xffff
    37f8:	54fffe80 	b.eq	37c8 <fwp_rc_dup+0x68>  // b.none
    37fc:	d65f03c0 	ret
    3800:	f9402443 	ldr	x3, [x2, #72]
    3804:	91000463 	add	x3, x3, #0x1
    3808:	f9002443 	str	x3, [x2, #72]
    380c:	17fffff5 	b	37e0 <fwp_rc_dup+0x80>
    3810:	17fffd81 	b	2e14 <fwp_rc_wide_dup>

0000000000003814 <fwp_task_dispose>:
    3814:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3818:	910003fd 	mov	x29, sp
    381c:	f9000bf3 	str	x19, [sp, #16]
    3820:	aa0003f3 	mov	x19, x0
    3824:	39414000 	ldrb	w0, [x0, #80]
    3828:	36000720 	tbz	w0, #0, 390c <fwp_task_dispose+0xf8>
    382c:	f9400a60 	ldr	x0, [x19, #16]
    3830:	b50006e0 	cbnz	x0, 390c <fwp_task_dispose+0xf8>
    3834:	a9478660 	ldp	x0, x1, [x19, #120]
    3838:	39014e7f 	strb	wzr, [x19, #83]
    383c:	f9003e7f 	str	xzr, [x19, #120]
    3840:	f100003f 	cmp	x1, #0x0
    3844:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3848:	54000040 	b.eq	3850 <fwp_task_dispose+0x3c>  // b.none
    384c:	d63f0020 	blr	x1
    3850:	f9405660 	ldr	x0, [x19, #168]
    3854:	97fffe57 	bl	31b0 <fwp_mem_free>
    3858:	f900567f 	str	xzr, [x19, #168]
    385c:	b9405e60 	ldr	w0, [x19, #92]
    3860:	7100041f 	cmp	w0, #0x1
    3864:	54000420 	b.eq	38e8 <fwp_task_dispose+0xd4>  // b.none
    3868:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    386c:	9114c042 	add	x2, x2, #0x530
    3870:	f949d840 	ldr	x0, [x2, #5040]
    3874:	f949ec41 	ldr	x1, [x2, #5080]
    3878:	cb000260 	sub	x0, x19, x0
    387c:	eb01401f 	cmp	x0, x1, lsl #16
    3880:	540002e2 	b.cs	38dc <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3884:	d350fc01 	lsr	x1, x0, #16
    3888:	f949fc44 	ldr	x4, [x2, #5112]
    388c:	8b010821 	add	x1, x1, x1, lsl #2
    3890:	d37df021 	lsl	x1, x1, #3
    3894:	8b010083 	add	x3, x4, x1
    3898:	f9401062 	ldr	x2, [x3, #32]
    389c:	b4000202 	cbz	x2, 38dc <fwp_task_dispose+0xc8>
    38a0:	38616881 	ldrb	w1, [x4, x1]
    38a4:	7100083f 	cmp	w1, #0x2
    38a8:	54000280 	b.eq	38f8 <fwp_task_dispose+0xe4>  // b.none
    38ac:	7100043f 	cmp	w1, #0x1
    38b0:	54000161 	b.ne	38dc <fwp_task_dispose+0xc8>  // b.any
    38b4:	29430464 	ldp	w4, w1, [x3, #24]
    38b8:	92403c00 	and	x0, x0, #0xffff
    38bc:	9b047c00 	mul	x0, x0, x4
    38c0:	d360fc00 	lsr	x0, x0, #32
    38c4:	eb01001f 	cmp	x0, x1
    38c8:	540000a2 	b.cs	38dc <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    38cc:	8b000042 	add	x2, x2, x0
    38d0:	39400040 	ldrb	w0, [x2]
    38d4:	7100041f 	cmp	w0, #0x1
    38d8:	54000080 	b.eq	38e8 <fwp_task_dispose+0xd4>  // b.none
    38dc:	f9400bf3 	ldr	x19, [sp, #16]
    38e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    38e4:	d65f03c0 	ret
    38e8:	aa1303e0 	mov	x0, x19
    38ec:	f9400bf3 	ldr	x19, [sp, #16]
    38f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    38f4:	17fffe2f 	b	31b0 <fwp_mem_free>
    38f8:	72003c1f 	tst	w0, #0xffff
    38fc:	54fffea0 	b.eq	38d0 <fwp_task_dispose+0xbc>  // b.none
    3900:	f9400bf3 	ldr	x19, [sp, #16]
    3904:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3908:	d65f03c0 	ret
    390c:	97fff725 	bl	15a0 <abort@plt>

0000000000003910 <fwp_free_zombie>:
    3910:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3914:	910003fd 	mov	x29, sp
    3918:	a90153f3 	stp	x19, x20, [sp, #16]
    391c:	b00000f4 	adrp	x20, 20000 <__data_start>
    3920:	91014281 	add	x1, x20, #0x50
    3924:	f9402833 	ldr	x19, [x1, #80]
    3928:	b4000333 	cbz	x19, 398c <fwp_free_zombie+0x7c>
    392c:	f9400420 	ldr	x0, [x1, #8]
    3930:	eb00027f 	cmp	x19, x0
    3934:	540002c0 	b.eq	398c <fwp_free_zombie+0x7c>  // b.none
    3938:	b9405822 	ldr	w2, [x1, #88]
    393c:	f9400a60 	ldr	x0, [x19, #16]
    3940:	7100fc5f 	cmp	w2, #0x3f
    3944:	5400078c 	b.gt	3a34 <fwp_free_zombie+0x124>
    3948:	91018023 	add	x3, x1, #0x60
    394c:	11000444 	add	w4, w2, #0x1
    3950:	b9005824 	str	w4, [x1, #88]
    3954:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3958:	f822d860 	str	x0, [x3, w2, sxtw #3]
    395c:	a9530261 	ldp	x1, x0, [x19, #304]
    3960:	b4000741 	cbz	x1, 3a48 <fwp_free_zombie+0x138>
    3964:	f9009c20 	str	x0, [x1, #312]
    3968:	b4000040 	cbz	x0, 3970 <fwp_free_zombie+0x60>
    396c:	f9009801 	str	x1, [x0, #304]
    3970:	91014294 	add	x20, x20, #0x50
    3974:	b9405e60 	ldr	w0, [x19, #92]
    3978:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    397c:	f9002a9f 	str	xzr, [x20, #80]
    3980:	34000140 	cbz	w0, 39a8 <fwp_free_zombie+0x98>
    3984:	7100041f 	cmp	w0, #0x1
    3988:	54000080 	b.eq	3998 <fwp_free_zombie+0x88>  // b.none
    398c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3990:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3994:	d65f03c0 	ret
    3998:	aa1303e0 	mov	x0, x19
    399c:	a94153f3 	ldp	x19, x20, [sp, #16]
    39a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39a4:	17ffff9c 	b	3814 <fwp_task_dispose>
    39a8:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xcb0>
    39ac:	9114c082 	add	x2, x4, #0x530
    39b0:	f949d841 	ldr	x1, [x2, #5040]
    39b4:	f949ec40 	ldr	x0, [x2, #5080]
    39b8:	cb010261 	sub	x1, x19, x1
    39bc:	eb00403f 	cmp	x1, x0, lsl #16
    39c0:	54fffe62 	b.cs	398c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    39c4:	d350fc20 	lsr	x0, x1, #16
    39c8:	f949fc43 	ldr	x3, [x2, #5112]
    39cc:	8b000800 	add	x0, x0, x0, lsl #2
    39d0:	d37df000 	lsl	x0, x0, #3
    39d4:	8b000062 	add	x2, x3, x0
    39d8:	f9401054 	ldr	x20, [x2, #32]
    39dc:	b4fffd94 	cbz	x20, 398c <fwp_free_zombie+0x7c>
    39e0:	38606860 	ldrb	w0, [x3, x0]
    39e4:	7100081f 	cmp	w0, #0x2
    39e8:	54000360 	b.eq	3a54 <fwp_free_zombie+0x144>  // b.none
    39ec:	7100041f 	cmp	w0, #0x1
    39f0:	54fffce1 	b.ne	398c <fwp_free_zombie+0x7c>  // b.any
    39f4:	29430043 	ldp	w3, w0, [x2, #24]
    39f8:	92403c21 	and	x1, x1, #0xffff
    39fc:	9b037c21 	mul	x1, x1, x3
    3a00:	d360fc21 	lsr	x1, x1, #32
    3a04:	eb00003f 	cmp	x1, x0
    3a08:	54fffc22 	b.cs	398c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3a0c:	8b010294 	add	x20, x20, x1
    3a10:	39400280 	ldrb	w0, [x20]
    3a14:	34fffbc0 	cbz	w0, 398c <fwp_free_zombie+0x7c>
    3a18:	7100041f 	cmp	w0, #0x1
    3a1c:	54fffbe0 	b.eq	3998 <fwp_free_zombie+0x88>  // b.none
    3a20:	7103fc1f 	cmp	w0, #0xff
    3a24:	540001e0 	b.eq	3a60 <fwp_free_zombie+0x150>  // b.none
    3a28:	51000400 	sub	w0, w0, #0x1
    3a2c:	39000280 	strb	w0, [x20]
    3a30:	17ffffd7 	b	398c <fwp_free_zombie+0x7c>
    3a34:	f9400e61 	ldr	x1, [x19, #24]
    3a38:	97fff70e 	bl	1670 <munmap@plt>
    3a3c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3a40:	a9530261 	ldp	x1, x0, [x19, #304]
    3a44:	b5fff901 	cbnz	x1, 3964 <fwp_free_zombie+0x54>
    3a48:	91014282 	add	x2, x20, #0x50
    3a4c:	f9013040 	str	x0, [x2, #608]
    3a50:	17ffffc6 	b	3968 <fwp_free_zombie+0x58>
    3a54:	72003c3f 	tst	w1, #0xffff
    3a58:	54fff9a1 	b.ne	398c <fwp_free_zombie+0x7c>  // b.any
    3a5c:	17ffffed 	b	3a10 <fwp_free_zombie+0x100>
    3a60:	ca544680 	eor	x0, x20, x20, lsr #17
    3a64:	9114c084 	add	x4, x4, #0x530
    3a68:	ca402400 	eor	x0, x0, x0, lsr #9
    3a6c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3a70:	f94a2400 	ldr	x0, [x0, #5192]
    3a74:	b5000080 	cbnz	x0, 3a84 <fwp_free_zombie+0x174>
    3a78:	14000010 	b	3ab8 <fwp_free_zombie+0x1a8>
    3a7c:	f9400800 	ldr	x0, [x0, #16]
    3a80:	b40001c0 	cbz	x0, 3ab8 <fwp_free_zombie+0x1a8>
    3a84:	f9400001 	ldr	x1, [x0]
    3a88:	eb14003f 	cmp	x1, x20
    3a8c:	54ffff81 	b.ne	3a7c <fwp_free_zombie+0x16c>  // b.any
    3a90:	f9400401 	ldr	x1, [x0, #8]
    3a94:	d1000421 	sub	x1, x1, #0x1
    3a98:	f9000401 	str	x1, [x0, #8]
    3a9c:	f103f83f 	cmp	x1, #0xfe
    3aa0:	54fff761 	b.ne	398c <fwp_free_zombie+0x7c>  // b.any
    3aa4:	aa1403e0 	mov	x0, x20
    3aa8:	97fffd22 	bl	2f30 <fwp_rc_forget_slot>
    3aac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3ab0:	39000280 	strb	w0, [x20]
    3ab4:	17ffffb6 	b	398c <fwp_free_zombie+0x7c>
    3ab8:	90000020 	adrp	x0, 7000 <__modti3+0x1a0>
    3abc:	91138000 	add	x0, x0, #0x4e0
    3ac0:	97fffa10 	bl	2300 <fwp_trap>

0000000000003ac4 <fwp_block>:
    3ac4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3ac8:	910003fd 	mov	x29, sp
    3acc:	a90153f3 	stp	x19, x20, [sp, #16]
    3ad0:	b00000f3 	adrp	x19, 20000 <__data_start>
    3ad4:	91014274 	add	x20, x19, #0x50
    3ad8:	f9401a82 	ldr	x2, [x20, #48]
    3adc:	b4000622 	cbz	x2, 3ba0 <fwp_block+0xdc>
    3ae0:	91014261 	add	x1, x19, #0x50
    3ae4:	f9408040 	ldr	x0, [x2, #256]
    3ae8:	f9001820 	str	x0, [x1, #48]
    3aec:	b4000680 	cbz	x0, 3bbc <fwp_block+0xf8>
    3af0:	91014263 	add	x3, x19, #0x50
    3af4:	3901505f 	strb	wzr, [x2, #84]
    3af8:	f9400464 	ldr	x4, [x3, #8]
    3afc:	eb02009f 	cmp	x4, x2
    3b00:	54000440 	b.eq	3b88 <fwp_block+0xc4>  // b.none
    3b04:	f9413465 	ldr	x5, [x3, #616]
    3b08:	f9000462 	str	x2, [x3, #8]
    3b0c:	f9400441 	ldr	x1, [x2, #8]
    3b10:	f9004885 	str	x5, [x4, #144]
    3b14:	f9413865 	ldr	x5, [x3, #624]
    3b18:	f9004c85 	str	x5, [x4, #152]
    3b1c:	f9413c65 	ldr	x5, [x3, #632]
    3b20:	f9005085 	str	x5, [x4, #160]
    3b24:	f9414065 	ldr	x5, [x3, #640]
    3b28:	f9005485 	str	x5, [x4, #168]
    3b2c:	f9414465 	ldr	x5, [x3, #648]
    3b30:	f9005885 	str	x5, [x4, #176]
    3b34:	f9414865 	ldr	x5, [x3, #656]
    3b38:	f9005c85 	str	x5, [x4, #184]
    3b3c:	f9414c65 	ldr	x5, [x3, #664]
    3b40:	f9006085 	str	x5, [x4, #192]
    3b44:	f9400480 	ldr	x0, [x4, #8]
    3b48:	f9404844 	ldr	x4, [x2, #144]
    3b4c:	f9013464 	str	x4, [x3, #616]
    3b50:	f9404c44 	ldr	x4, [x2, #152]
    3b54:	f9013864 	str	x4, [x3, #624]
    3b58:	f9405044 	ldr	x4, [x2, #160]
    3b5c:	f9013c64 	str	x4, [x3, #632]
    3b60:	f9405444 	ldr	x4, [x2, #168]
    3b64:	f9014064 	str	x4, [x3, #640]
    3b68:	f9405844 	ldr	x4, [x2, #176]
    3b6c:	f9014464 	str	x4, [x3, #648]
    3b70:	a94b8844 	ldp	x4, x2, [x2, #184]
    3b74:	f9014864 	str	x4, [x3, #656]
    3b78:	f9014c62 	str	x2, [x3, #664]
    3b7c:	97fff68d 	bl	15b0 <swapcontext@plt>
    3b80:	97ffff64 	bl	3910 <fwp_free_zombie>
    3b84:	d503201f 	nop
    3b88:	91014260 	add	x0, x19, #0x50
    3b8c:	b942a000 	ldr	w0, [x0, #672]
    3b90:	340001a0 	cbz	w0, 3bc4 <fwp_block+0x100>
    3b94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b98:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3b9c:	d65f03c0 	ret
    3ba0:	97fffc10 	bl	2be0 <fwp_poll_events>
    3ba4:	f9401a82 	ldr	x2, [x20, #48]
    3ba8:	b4ffffc2 	cbz	x2, 3ba0 <fwp_block+0xdc>
    3bac:	91014261 	add	x1, x19, #0x50
    3bb0:	f9408040 	ldr	x0, [x2, #256]
    3bb4:	f9001820 	str	x0, [x1, #48]
    3bb8:	b5fff9c0 	cbnz	x0, 3af0 <fwp_block+0x2c>
    3bbc:	f900143f 	str	xzr, [x1, #40]
    3bc0:	17ffffcc 	b	3af0 <fwp_block+0x2c>
    3bc4:	90000020 	adrp	x0, 7000 <__modti3+0x1a0>
    3bc8:	91156000 	add	x0, x0, #0x558
    3bcc:	97fff6c5 	bl	16e0 <getenv@plt>
    3bd0:	5284e202 	mov	w2, #0x2710                	// #10000
    3bd4:	b4000060 	cbz	x0, 3be0 <fwp_block+0x11c>
    3bd8:	39400001 	ldrb	w1, [x0]
    3bdc:	350000c1 	cbnz	w1, 3bf4 <fwp_block+0x130>
    3be0:	91014273 	add	x19, x19, #0x50
    3be4:	b902a262 	str	w2, [x19, #672]
    3be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3bec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3bf0:	d65f03c0 	ret
    3bf4:	52800142 	mov	w2, #0xa                   	// #10
    3bf8:	d2800001 	mov	x1, #0x0                   	// #0
    3bfc:	97fff609 	bl	1420 <strtoll@plt>
    3c00:	d1000403 	sub	x3, x0, #0x1
    3c04:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3c08:	eb02007f 	cmp	x3, x2
    3c0c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3c10:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3c14:	17fffff3 	b	3be0 <fwp_block+0x11c>
    3c18:	d503201f 	nop
    3c1c:	d503201f 	nop

0000000000003c20 <fwp_caps69>:
    3c20:	34000041 	cbz	w1, 3c28 <fwp_caps69+0x8>
    3c24:	d65f03c0 	ret
    3c28:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3c2c:	9114c063 	add	x3, x3, #0x530
    3c30:	f949d861 	ldr	x1, [x3, #5040]
    3c34:	f949ec62 	ldr	x2, [x3, #5080]
    3c38:	cb010001 	sub	x1, x0, x1
    3c3c:	eb02403f 	cmp	x1, x2, lsl #16
    3c40:	54ffff22 	b.cs	3c24 <fwp_caps69+0x4>  // b.hs, b.nlast
    3c44:	d350fc22 	lsr	x2, x1, #16
    3c48:	f949fc65 	ldr	x5, [x3, #5112]
    3c4c:	8b020842 	add	x2, x2, x2, lsl #2
    3c50:	d37df042 	lsl	x2, x2, #3
    3c54:	8b0200a4 	add	x4, x5, x2
    3c58:	f9401083 	ldr	x3, [x4, #32]
    3c5c:	b4fffe43 	cbz	x3, 3c24 <fwp_caps69+0x4>
    3c60:	386268a2 	ldrb	w2, [x5, x2]
    3c64:	7100085f 	cmp	w2, #0x2
    3c68:	540001c0 	b.eq	3ca0 <fwp_caps69+0x80>  // b.none
    3c6c:	7100045f 	cmp	w2, #0x1
    3c70:	54fffda1 	b.ne	3c24 <fwp_caps69+0x4>  // b.any
    3c74:	29430885 	ldp	w5, w2, [x4, #24]
    3c78:	92403c21 	and	x1, x1, #0xffff
    3c7c:	9b057c21 	mul	x1, x1, x5
    3c80:	d360fc21 	lsr	x1, x1, #32
    3c84:	eb02003f 	cmp	x1, x2
    3c88:	54fffce2 	b.cs	3c24 <fwp_caps69+0x4>  // b.hs, b.nlast
    3c8c:	8b010063 	add	x3, x3, x1
    3c90:	39400061 	ldrb	w1, [x3]
    3c94:	7100043f 	cmp	w1, #0x1
    3c98:	54fffc61 	b.ne	3c24 <fwp_caps69+0x4>  // b.any
    3c9c:	17fffd45 	b	31b0 <fwp_mem_free>
    3ca0:	72003c3f 	tst	w1, #0xffff
    3ca4:	54ffff60 	b.eq	3c90 <fwp_caps69+0x70>  // b.none
    3ca8:	d65f03c0 	ret
    3cac:	d503201f 	nop

0000000000003cb0 <fwp_caps45>:
    3cb0:	34000041 	cbz	w1, 3cb8 <fwp_caps45+0x8>
    3cb4:	d65f03c0 	ret
    3cb8:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3cbc:	9114c063 	add	x3, x3, #0x530
    3cc0:	f949d861 	ldr	x1, [x3, #5040]
    3cc4:	f949ec62 	ldr	x2, [x3, #5080]
    3cc8:	cb010001 	sub	x1, x0, x1
    3ccc:	eb02403f 	cmp	x1, x2, lsl #16
    3cd0:	54ffff22 	b.cs	3cb4 <fwp_caps45+0x4>  // b.hs, b.nlast
    3cd4:	d350fc22 	lsr	x2, x1, #16
    3cd8:	f949fc65 	ldr	x5, [x3, #5112]
    3cdc:	8b020842 	add	x2, x2, x2, lsl #2
    3ce0:	d37df042 	lsl	x2, x2, #3
    3ce4:	8b0200a4 	add	x4, x5, x2
    3ce8:	f9401083 	ldr	x3, [x4, #32]
    3cec:	b4fffe43 	cbz	x3, 3cb4 <fwp_caps45+0x4>
    3cf0:	386268a2 	ldrb	w2, [x5, x2]
    3cf4:	7100085f 	cmp	w2, #0x2
    3cf8:	540001c0 	b.eq	3d30 <fwp_caps45+0x80>  // b.none
    3cfc:	7100045f 	cmp	w2, #0x1
    3d00:	54fffda1 	b.ne	3cb4 <fwp_caps45+0x4>  // b.any
    3d04:	29430885 	ldp	w5, w2, [x4, #24]
    3d08:	92403c21 	and	x1, x1, #0xffff
    3d0c:	9b057c21 	mul	x1, x1, x5
    3d10:	d360fc21 	lsr	x1, x1, #32
    3d14:	eb02003f 	cmp	x1, x2
    3d18:	54fffce2 	b.cs	3cb4 <fwp_caps45+0x4>  // b.hs, b.nlast
    3d1c:	8b010063 	add	x3, x3, x1
    3d20:	39400061 	ldrb	w1, [x3]
    3d24:	7100043f 	cmp	w1, #0x1
    3d28:	54fffc61 	b.ne	3cb4 <fwp_caps45+0x4>  // b.any
    3d2c:	17fffd21 	b	31b0 <fwp_mem_free>
    3d30:	72003c3f 	tst	w1, #0xffff
    3d34:	54ffff60 	b.eq	3d20 <fwp_caps45+0x70>  // b.none
    3d38:	d65f03c0 	ret
    3d3c:	d503201f 	nop

0000000000003d40 <fwp_caps74>:
    3d40:	34000041 	cbz	w1, 3d48 <fwp_caps74+0x8>
    3d44:	d65f03c0 	ret
    3d48:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3d4c:	9114c063 	add	x3, x3, #0x530
    3d50:	f949d861 	ldr	x1, [x3, #5040]
    3d54:	f949ec62 	ldr	x2, [x3, #5080]
    3d58:	cb010001 	sub	x1, x0, x1
    3d5c:	eb02403f 	cmp	x1, x2, lsl #16
    3d60:	54ffff22 	b.cs	3d44 <fwp_caps74+0x4>  // b.hs, b.nlast
    3d64:	d350fc22 	lsr	x2, x1, #16
    3d68:	f949fc65 	ldr	x5, [x3, #5112]
    3d6c:	8b020842 	add	x2, x2, x2, lsl #2
    3d70:	d37df042 	lsl	x2, x2, #3
    3d74:	8b0200a4 	add	x4, x5, x2
    3d78:	f9401083 	ldr	x3, [x4, #32]
    3d7c:	b4fffe43 	cbz	x3, 3d44 <fwp_caps74+0x4>
    3d80:	386268a2 	ldrb	w2, [x5, x2]
    3d84:	7100085f 	cmp	w2, #0x2
    3d88:	540001c0 	b.eq	3dc0 <fwp_caps74+0x80>  // b.none
    3d8c:	7100045f 	cmp	w2, #0x1
    3d90:	54fffda1 	b.ne	3d44 <fwp_caps74+0x4>  // b.any
    3d94:	29430885 	ldp	w5, w2, [x4, #24]
    3d98:	92403c21 	and	x1, x1, #0xffff
    3d9c:	9b057c21 	mul	x1, x1, x5
    3da0:	d360fc21 	lsr	x1, x1, #32
    3da4:	eb02003f 	cmp	x1, x2
    3da8:	54fffce2 	b.cs	3d44 <fwp_caps74+0x4>  // b.hs, b.nlast
    3dac:	8b010063 	add	x3, x3, x1
    3db0:	39400061 	ldrb	w1, [x3]
    3db4:	7100043f 	cmp	w1, #0x1
    3db8:	54fffc61 	b.ne	3d44 <fwp_caps74+0x4>  // b.any
    3dbc:	17fffcfd 	b	31b0 <fwp_mem_free>
    3dc0:	72003c3f 	tst	w1, #0xffff
    3dc4:	54ffff60 	b.eq	3db0 <fwp_caps74+0x70>  // b.none
    3dc8:	d65f03c0 	ret
    3dcc:	d503201f 	nop

0000000000003dd0 <fwp_caps32>:
    3dd0:	34000041 	cbz	w1, 3dd8 <fwp_caps32+0x8>
    3dd4:	d65f03c0 	ret
    3dd8:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3ddc:	9114c063 	add	x3, x3, #0x530
    3de0:	f949d861 	ldr	x1, [x3, #5040]
    3de4:	f949ec62 	ldr	x2, [x3, #5080]
    3de8:	cb010001 	sub	x1, x0, x1
    3dec:	eb02403f 	cmp	x1, x2, lsl #16
    3df0:	54ffff22 	b.cs	3dd4 <fwp_caps32+0x4>  // b.hs, b.nlast
    3df4:	d350fc22 	lsr	x2, x1, #16
    3df8:	f949fc65 	ldr	x5, [x3, #5112]
    3dfc:	8b020842 	add	x2, x2, x2, lsl #2
    3e00:	d37df042 	lsl	x2, x2, #3
    3e04:	8b0200a4 	add	x4, x5, x2
    3e08:	f9401083 	ldr	x3, [x4, #32]
    3e0c:	b4fffe43 	cbz	x3, 3dd4 <fwp_caps32+0x4>
    3e10:	386268a2 	ldrb	w2, [x5, x2]
    3e14:	7100085f 	cmp	w2, #0x2
    3e18:	540001c0 	b.eq	3e50 <fwp_caps32+0x80>  // b.none
    3e1c:	7100045f 	cmp	w2, #0x1
    3e20:	54fffda1 	b.ne	3dd4 <fwp_caps32+0x4>  // b.any
    3e24:	29430885 	ldp	w5, w2, [x4, #24]
    3e28:	92403c21 	and	x1, x1, #0xffff
    3e2c:	9b057c21 	mul	x1, x1, x5
    3e30:	d360fc21 	lsr	x1, x1, #32
    3e34:	eb02003f 	cmp	x1, x2
    3e38:	54fffce2 	b.cs	3dd4 <fwp_caps32+0x4>  // b.hs, b.nlast
    3e3c:	8b010063 	add	x3, x3, x1
    3e40:	39400061 	ldrb	w1, [x3]
    3e44:	7100043f 	cmp	w1, #0x1
    3e48:	54fffc61 	b.ne	3dd4 <fwp_caps32+0x4>  // b.any
    3e4c:	17fffcd9 	b	31b0 <fwp_mem_free>
    3e50:	72003c3f 	tst	w1, #0xffff
    3e54:	54ffff60 	b.eq	3e40 <fwp_caps32+0x70>  // b.none
    3e58:	d65f03c0 	ret
    3e5c:	d503201f 	nop

0000000000003e60 <fwp_data.part.0.constprop.0>:
    3e60:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3e64:	910003fd 	mov	x29, sp
    3e68:	a90363f7 	stp	x23, x24, [sp, #48]
    3e6c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3e70:	91014302 	add	x2, x24, #0x50
    3e74:	a9046bf9 	stp	x25, x26, [sp, #64]
    3e78:	b9404059 	ldr	w25, [x2, #64]
    3e7c:	a90153f3 	stp	x19, x20, [sp, #16]
    3e80:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    3e84:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e88:	2a0003f6 	mov	w22, w0
    3e8c:	aa0103f5 	mov	x21, x1
    3e90:	350005f9 	cbnz	w25, 3f4c <fwp_data.part.0.constprop.0+0xec>
    3e94:	9114c280 	add	x0, x20, #0x530
    3e98:	b953a400 	ldr	w0, [x0, #5028]
    3e9c:	34000c80 	cbz	w0, 402c <fwp_data.part.0.constprop.0+0x1cc>
    3ea0:	9114c283 	add	x3, x20, #0x530
    3ea4:	397e8862 	ldrb	w2, [x3, #4002]
    3ea8:	910f0040 	add	x0, x2, #0x3c0
    3eac:	8b020442 	add	x2, x2, x2, lsl #1
    3eb0:	d37df042 	lsl	x2, x2, #3
    3eb4:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    3eb8:	2a1a03f7 	mov	w23, w26
    3ebc:	f8626873 	ldr	x19, [x3, x2]
    3ec0:	b4000753 	cbz	x19, 3fa8 <fwp_data.part.0.constprop.0+0x148>
    3ec4:	f9400260 	ldr	x0, [x19]
    3ec8:	aa2003e0 	mvn	x0, x0
    3ecc:	f8226860 	str	x0, [x3, x2]
    3ed0:	f10062ff 	cmp	x23, #0x18
    3ed4:	540000e9 	b.ls	3ef0 <fwp_data.part.0.constprop.0+0x90>  // b.plast
    3ed8:	d10066e2 	sub	x2, x23, #0x19
    3edc:	91006260 	add	x0, x19, #0x18
    3ee0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    3ee4:	52800001 	mov	w1, #0x0                   	// #0
    3ee8:	91002042 	add	x2, x2, #0x8
    3eec:	97fff58d 	bl	1520 <memset@plt>
    3ef0:	9114c280 	add	x0, x20, #0x530
    3ef4:	f94a1002 	ldr	x2, [x0, #5152]
    3ef8:	ab170042 	adds	x2, x2, x23
    3efc:	54000a22 	b.cs	4040 <fwp_data.part.0.constprop.0+0x1e0>  // b.hs, b.nlast
    3f00:	f94a1401 	ldr	x1, [x0, #5160]
    3f04:	f90a1002 	str	x2, [x0, #5152]
    3f08:	eb01005f 	cmp	x2, x1
    3f0c:	54000049 	b.ls	3f14 <fwp_data.part.0.constprop.0+0xb4>  // b.plast
    3f10:	f90a1402 	str	x2, [x0, #5160]
    3f14:	9114c294 	add	x20, x20, #0x530
    3f18:	1e630341 	ucvtf	d1, w26
    3f1c:	fd4a1e80 	ldr	d0, [x20, #5176]
    3f20:	1e612800 	fadd	d0, d0, d1
    3f24:	fd0a1e80 	str	d0, [x20, #5176]
    3f28:	34000599 	cbz	w25, 3fd8 <fwp_data.part.0.constprop.0+0x178>
    3f2c:	91014300 	add	x0, x24, #0x50
    3f30:	9e630040 	ucvtf	d0, x2
    3f34:	fd415c02 	ldr	d2, [x0, #696]
    3f38:	fd416001 	ldr	d1, [x0, #704]
    3f3c:	1e623800 	fsub	d0, d0, d2
    3f40:	1e602030 	fcmpe	d1, d0
    3f44:	54000464 	b.mi	3fd0 <fwp_data.part.0.constprop.0+0x170>  // b.first
    3f48:	14000024 	b	3fd8 <fwp_data.part.0.constprop.0+0x178>
    3f4c:	9114c283 	add	x3, x20, #0x530
    3f50:	f9415441 	ldr	x1, [x2, #680]
    3f54:	f9415840 	ldr	x0, [x2, #688]
    3f58:	91000421 	add	x1, x1, #0x1
    3f5c:	b953a463 	ldr	w3, [x3, #5028]
    3f60:	91006000 	add	x0, x0, #0x18
    3f64:	f9015441 	str	x1, [x2, #680]
    3f68:	f9015840 	str	x0, [x2, #688]
    3f6c:	35fff9a3 	cbnz	w3, 3ea0 <fwp_data.part.0.constprop.0+0x40>
    3f70:	52800001 	mov	w1, #0x0                   	// #0
    3f74:	d2800300 	mov	x0, #0x18                  	// #24
    3f78:	97fffd56 	bl	34d0 <fwp_heap_alloc_slow>
    3f7c:	aa0003f3 	mov	x19, x0
    3f80:	9114c294 	add	x20, x20, #0x530
    3f84:	91014300 	add	x0, x24, #0x50
    3f88:	fd4a1280 	ldr	d0, [x20, #5152]
    3f8c:	fd415c02 	ldr	d2, [x0, #696]
    3f90:	fd416001 	ldr	d1, [x0, #704]
    3f94:	7e61d800 	ucvtf	d0, d0
    3f98:	1e623800 	fsub	d0, d0, d2
    3f9c:	1e612010 	fcmpe	d0, d1
    3fa0:	5400042c 	b.gt	4024 <fwp_data.part.0.constprop.0+0x1c4>
    3fa4:	17ffffe7 	b	3f40 <fwp_data.part.0.constprop.0+0xe0>
    3fa8:	8b020063 	add	x3, x3, x2
    3fac:	f9400473 	ldr	x19, [x3, #8]
    3fb0:	b40002f3 	cbz	x19, 400c <fwp_data.part.0.constprop.0+0x1ac>
    3fb4:	f9400860 	ldr	x0, [x3, #16]
    3fb8:	cb130000 	sub	x0, x0, x19
    3fbc:	eb17001f 	cmp	x0, x23
    3fc0:	54000263 	b.cc	400c <fwp_data.part.0.constprop.0+0x1ac>  // b.lo, b.ul, b.last
    3fc4:	8b170260 	add	x0, x19, x23
    3fc8:	f9000460 	str	x0, [x3, #8]
    3fcc:	17ffffc1 	b	3ed0 <fwp_data.part.0.constprop.0+0x70>
    3fd0:	91014318 	add	x24, x24, #0x50
    3fd4:	fd016300 	str	d0, [x24, #704]
    3fd8:	52800040 	mov	w0, #0x2                   	// #2
    3fdc:	29000276 	stp	w22, w0, [x19]
    3fe0:	aa1303e0 	mov	x0, x19
    3fe4:	f94002a1 	ldr	x1, [x21]
    3fe8:	f9000661 	str	x1, [x19, #8]
    3fec:	f94006a1 	ldr	x1, [x21, #8]
    3ff0:	f9000a61 	str	x1, [x19, #16]
    3ff4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3ff8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3ffc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4000:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4004:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4008:	d65f03c0 	ret
    400c:	52800001 	mov	w1, #0x0                   	// #0
    4010:	d2800300 	mov	x0, #0x18                  	// #24
    4014:	97fffd2f 	bl	34d0 <fwp_heap_alloc_slow>
    4018:	aa0003f3 	mov	x19, x0
    401c:	34fffdf9 	cbz	w25, 3fd8 <fwp_data.part.0.constprop.0+0x178>
    4020:	17ffffd8 	b	3f80 <fwp_data.part.0.constprop.0+0x120>
    4024:	fd016000 	str	d0, [x0, #704]
    4028:	17ffffec 	b	3fd8 <fwp_data.part.0.constprop.0+0x178>
    402c:	52800001 	mov	w1, #0x0                   	// #0
    4030:	d2800300 	mov	x0, #0x18                  	// #24
    4034:	97fffd27 	bl	34d0 <fwp_heap_alloc_slow>
    4038:	aa0003f3 	mov	x19, x0
    403c:	17ffffe7 	b	3fd8 <fwp_data.part.0.constprop.0+0x178>
    4040:	97fff744 	bl	1d50 <fwp_heap_oom>

0000000000004044 <f74>:
    4044:	9e670003 	fmov	d3, x0
    4048:	9e670021 	fmov	d1, x1
    404c:	d2f80f20 	mov	x0, #0xc079000000000000    	// #-4577627546245398528
    4050:	1e6e1002 	fmov	d2, #1.000000000000000000e+00
    4054:	1e630865 	fmul	d5, d3, d3
    4058:	9e670000 	fmov	d0, x0
    405c:	1e633842 	fsub	d2, d2, d3
    4060:	d10103ff 	sub	sp, sp, #0x40
    4064:	1e600860 	fmul	d0, d3, d0
    4068:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    406c:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x165f8>
    4070:	f947f442 	ldr	x2, [x2, #4072]
    4074:	1e653821 	fsub	d1, d1, d5
    4078:	1e622842 	fadd	d2, d2, d2
    407c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4080:	9e670004 	fmov	d4, x0
    4084:	910083fd 	add	x29, sp, #0x20
    4088:	1e610800 	fmul	d0, d0, d1
    408c:	a90353f3 	stp	x19, x20, [sp, #48]
    4090:	1e640821 	fmul	d1, d1, d4
    4094:	f9400043 	ldr	x3, [x2]
    4098:	f9000fe3 	str	x3, [sp, #24]
    409c:	d2800003 	mov	x3, #0x0                   	// #0
    40a0:	910023e1 	add	x1, sp, #0x8
    40a4:	52800000 	mov	w0, #0x0                   	// #0
    40a8:	1e623800 	fsub	d0, d0, d2
    40ac:	6d0087e0 	stp	d0, d1, [sp, #8]
    40b0:	97ffff6c 	bl	3e60 <fwp_data.part.0.constprop.0>
    40b4:	b0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    40b8:	9114c063 	add	x3, x3, #0x530
    40bc:	aa0003f3 	mov	x19, x0
    40c0:	f949d861 	ldr	x1, [x3, #5040]
    40c4:	f949ec60 	ldr	x0, [x3, #5080]
    40c8:	cb010261 	sub	x1, x19, x1
    40cc:	eb00403f 	cmp	x1, x0, lsl #16
    40d0:	54000322 	b.cs	4134 <f74+0xf0>  // b.hs, b.nlast
    40d4:	d350fc22 	lsr	x2, x1, #16
    40d8:	f949fc63 	ldr	x3, [x3, #5112]
    40dc:	8b020842 	add	x2, x2, x2, lsl #2
    40e0:	d37df042 	lsl	x2, x2, #3
    40e4:	8b020060 	add	x0, x3, x2
    40e8:	f9401014 	ldr	x20, [x0, #32]
    40ec:	b4000254 	cbz	x20, 4134 <f74+0xf0>
    40f0:	38626862 	ldrb	w2, [x3, x2]
    40f4:	7100085f 	cmp	w2, #0x2
    40f8:	54000360 	b.eq	4164 <f74+0x120>  // b.none
    40fc:	7100045f 	cmp	w2, #0x1
    4100:	540001a1 	b.ne	4134 <f74+0xf0>  // b.any
    4104:	29430002 	ldp	w2, w0, [x0, #24]
    4108:	92403c21 	and	x1, x1, #0xffff
    410c:	9b027c21 	mul	x1, x1, x2
    4110:	d360fc21 	lsr	x1, x1, #32
    4114:	eb00003f 	cmp	x1, x0
    4118:	540000e2 	b.cs	4134 <f74+0xf0>  // b.hs, b.nlast
    411c:	8b010294 	add	x20, x20, x1
    4120:	39400280 	ldrb	w0, [x20]
    4124:	7103fc1f 	cmp	w0, #0xff
    4128:	54000240 	b.eq	4170 <f74+0x12c>  // b.none
    412c:	52800020 	mov	w0, #0x1                   	// #1
    4130:	39000280 	strb	w0, [x20]
    4134:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    4138:	f947f400 	ldr	x0, [x0, #4072]
    413c:	f9400fe2 	ldr	x2, [sp, #24]
    4140:	f9400001 	ldr	x1, [x0]
    4144:	eb010042 	subs	x2, x2, x1
    4148:	d2800001 	mov	x1, #0x0                   	// #0
    414c:	54000181 	b.ne	417c <f74+0x138>  // b.any
    4150:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4154:	aa1303e0 	mov	x0, x19
    4158:	a94353f3 	ldp	x19, x20, [sp, #48]
    415c:	910103ff 	add	sp, sp, #0x40
    4160:	d65f03c0 	ret
    4164:	72003c3f 	tst	w1, #0xffff
    4168:	54fffe61 	b.ne	4134 <f74+0xf0>  // b.any
    416c:	17ffffed 	b	4120 <f74+0xdc>
    4170:	aa1403e0 	mov	x0, x20
    4174:	97fffb6f 	bl	2f30 <fwp_rc_forget_slot>
    4178:	17ffffed 	b	412c <f74+0xe8>
    417c:	97fff4f5 	bl	1550 <__stack_chk_fail@plt>

0000000000004180 <fwp_owned_entry74>:
    4180:	a9400400 	ldp	x0, x1, [x0]
    4184:	17ffffb0 	b	4044 <f74>
    4188:	d503201f 	nop
    418c:	d503201f 	nop

0000000000004190 <e74>:
    4190:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4194:	910003fd 	mov	x29, sp
    4198:	a9400400 	ldp	x0, x1, [x0]
    419c:	f9000bf3 	str	x19, [sp, #16]
    41a0:	97ffffa9 	bl	4044 <f74>
    41a4:	aa0003f3 	mov	x19, x0
    41a8:	97fffd22 	bl	3630 <fwp_rc_share>
    41ac:	aa1303e0 	mov	x0, x19
    41b0:	f9400bf3 	ldr	x19, [sp, #16]
    41b4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    41b8:	d65f03c0 	ret
    41bc:	d503201f 	nop

00000000000041c0 <fwp_map_finish_protected.isra.0>:
    41c0:	d10183ff 	sub	sp, sp, #0x60
    41c4:	a9027bfd 	stp	x29, x30, [sp, #32]
    41c8:	910083fd 	add	x29, sp, #0x20
    41cc:	a90563f7 	stp	x23, x24, [sp, #80]
    41d0:	aa0003f7 	mov	x23, x0
    41d4:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    41d8:	f947f400 	ldr	x0, [x0, #4072]
    41dc:	a9045bf5 	stp	x21, x22, [sp, #64]
    41e0:	a940d6e2 	ldp	x2, x21, [x23, #8]
    41e4:	f9400001 	ldr	x1, [x0]
    41e8:	f9000fe1 	str	x1, [sp, #24]
    41ec:	d2800001 	mov	x1, #0x0                   	// #0
    41f0:	b40005e2 	cbz	x2, 42ac <fwp_map_finish_protected.isra.0+0xec>
    41f4:	b0000178 	adrp	x24, 31000 <fwp_root_context+0xcb0>
    41f8:	9114c318 	add	x24, x24, #0x530
    41fc:	a90353f3 	stp	x19, x20, [sp, #48]
    4200:	910023f3 	add	x19, sp, #0x8
    4204:	52800034 	mov	w20, #0x1                   	// #1
    4208:	f94002e3 	ldr	x3, [x23]
    420c:	aa1303e1 	mov	x1, x19
    4210:	52800020 	mov	w0, #0x1                   	// #1
    4214:	8b020c62 	add	x2, x3, x2, lsl #3
    4218:	f85f8042 	ldur	x2, [x2, #-8]
    421c:	a900d7e2 	stp	x2, x21, [sp, #8]
    4220:	97ffff10 	bl	3e60 <fwp_data.part.0.constprop.0>
    4224:	aa0003f5 	mov	x21, x0
    4228:	f949db01 	ldr	x1, [x24, #5040]
    422c:	f949ef02 	ldr	x2, [x24, #5080]
    4230:	cb010001 	sub	x1, x0, x1
    4234:	eb02403f 	cmp	x1, x2, lsl #16
    4238:	54000302 	b.cs	4298 <fwp_map_finish_protected.isra.0+0xd8>  // b.hs, b.nlast
    423c:	d350fc22 	lsr	x2, x1, #16
    4240:	f949ff04 	ldr	x4, [x24, #5112]
    4244:	8b020842 	add	x2, x2, x2, lsl #2
    4248:	d37df042 	lsl	x2, x2, #3
    424c:	8b020083 	add	x3, x4, x2
    4250:	f9401076 	ldr	x22, [x3, #32]
    4254:	b4000236 	cbz	x22, 4298 <fwp_map_finish_protected.isra.0+0xd8>
    4258:	38626882 	ldrb	w2, [x4, x2]
    425c:	7100085f 	cmp	w2, #0x2
    4260:	540004a0 	b.eq	42f4 <fwp_map_finish_protected.isra.0+0x134>  // b.none
    4264:	7100045f 	cmp	w2, #0x1
    4268:	54000181 	b.ne	4298 <fwp_map_finish_protected.isra.0+0xd8>  // b.any
    426c:	29430062 	ldp	w2, w0, [x3, #24]
    4270:	92403c21 	and	x1, x1, #0xffff
    4274:	9b027c21 	mul	x1, x1, x2
    4278:	d360fc21 	lsr	x1, x1, #32
    427c:	eb00003f 	cmp	x1, x0
    4280:	540000c2 	b.cs	4298 <fwp_map_finish_protected.isra.0+0xd8>  // b.hs, b.nlast
    4284:	8b0102d6 	add	x22, x22, x1
    4288:	394002c0 	ldrb	w0, [x22]
    428c:	7103fc1f 	cmp	w0, #0xff
    4290:	540002c0 	b.eq	42e8 <fwp_map_finish_protected.isra.0+0x128>  // b.none
    4294:	390002d4 	strb	w20, [x22]
    4298:	f94006e2 	ldr	x2, [x23, #8]
    429c:	d1000442 	sub	x2, x2, #0x1
    42a0:	a900d6e2 	stp	x2, x21, [x23, #8]
    42a4:	b5fffb22 	cbnz	x2, 4208 <fwp_map_finish_protected.isra.0+0x48>
    42a8:	a94353f3 	ldp	x19, x20, [sp, #48]
    42ac:	f94002e0 	ldr	x0, [x23]
    42b0:	97fffbc0 	bl	31b0 <fwp_mem_free>
    42b4:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    42b8:	f947f400 	ldr	x0, [x0, #4072]
    42bc:	f9400fe2 	ldr	x2, [sp, #24]
    42c0:	f9400001 	ldr	x1, [x0]
    42c4:	eb010042 	subs	x2, x2, x1
    42c8:	d2800001 	mov	x1, #0x0                   	// #0
    42cc:	540001a1 	b.ne	4300 <fwp_map_finish_protected.isra.0+0x140>  // b.any
    42d0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    42d4:	aa1503e0 	mov	x0, x21
    42d8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    42dc:	a94563f7 	ldp	x23, x24, [sp, #80]
    42e0:	910183ff 	add	sp, sp, #0x60
    42e4:	d65f03c0 	ret
    42e8:	aa1603e0 	mov	x0, x22
    42ec:	97fffb11 	bl	2f30 <fwp_rc_forget_slot>
    42f0:	17ffffe9 	b	4294 <fwp_map_finish_protected.isra.0+0xd4>
    42f4:	72003c3f 	tst	w1, #0xffff
    42f8:	54fffd01 	b.ne	4298 <fwp_map_finish_protected.isra.0+0xd8>  // b.any
    42fc:	17ffffe3 	b	4288 <fwp_map_finish_protected.isra.0+0xc8>
    4300:	a90353f3 	stp	x19, x20, [sp, #48]
    4304:	97fff493 	bl	1550 <__stack_chk_fail@plt>
    4308:	d503201f 	nop
    430c:	d503201f 	nop

0000000000004310 <fwp_heap_alloc>:
    4310:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4314:	910003fd 	mov	x29, sp
    4318:	a9025bf5 	stp	x21, x22, [sp, #32]
    431c:	900000f6 	adrp	x22, 20000 <__data_start>
    4320:	910142c2 	add	x2, x22, #0x50
    4324:	a90363f7 	stp	x23, x24, [sp, #48]
    4328:	b9404058 	ldr	w24, [x2, #64]
    432c:	a90153f3 	stp	x19, x20, [sp, #16]
    4330:	7100031f 	cmp	w24, #0x0
    4334:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    4338:	54000881 	b.ne	4448 <fwp_heap_alloc+0x138>  // b.any
    433c:	b0000177 	adrp	x23, 31000 <fwp_root_context+0xcb0>
    4340:	9114c2f3 	add	x19, x23, #0x530
    4344:	f140101f 	cmp	x0, #0x4, lsl #12
    4348:	b953a662 	ldr	w2, [x19, #5028]
    434c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4350:	54000760 	b.eq	443c <fwp_heap_alloc+0x12c>  // b.none
    4354:	91003c03 	add	x3, x0, #0xf
    4358:	937c7c22 	sbfiz	x2, x1, #4, #32
    435c:	cb21c042 	sub	x2, x2, w1, sxtw
    4360:	8b431263 	add	x3, x19, x3, lsr #4
    4364:	d37ae442 	lsl	x2, x2, #6
    4368:	397e8063 	ldrb	w3, [x3, #4000]
    436c:	910f0064 	add	x4, x3, #0x3c0
    4370:	8b030463 	add	x3, x3, x3, lsl #1
    4374:	8b030c43 	add	x3, x2, x3, lsl #3
    4378:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    437c:	2a1503f4 	mov	w20, w21
    4380:	f8636a64 	ldr	x4, [x19, x3]
    4384:	b40004e4 	cbz	x4, 4420 <fwp_heap_alloc+0x110>
    4388:	f9400085 	ldr	x5, [x4]
    438c:	7100043f 	cmp	w1, #0x1
    4390:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    4394:	aa0403e0 	mov	x0, x4
    4398:	aa2503e5 	mvn	x5, x5
    439c:	52800001 	mov	w1, #0x0                   	// #0
    43a0:	f8236a65 	str	x5, [x19, x3]
    43a4:	97fff45f 	bl	1520 <memset@plt>
    43a8:	aa0003e4 	mov	x4, x0
    43ac:	f94a1260 	ldr	x0, [x19, #5152]
    43b0:	ab140000 	adds	x0, x0, x20
    43b4:	54000742 	b.cs	449c <fwp_heap_alloc+0x18c>  // b.hs, b.nlast
    43b8:	f94a1661 	ldr	x1, [x19, #5160]
    43bc:	f90a1260 	str	x0, [x19, #5152]
    43c0:	eb01001f 	cmp	x0, x1
    43c4:	54000049 	b.ls	43cc <fwp_heap_alloc+0xbc>  // b.plast
    43c8:	f90a1660 	str	x0, [x19, #5160]
    43cc:	9114c2e0 	add	x0, x23, #0x530
    43d0:	1e6302a1 	ucvtf	d1, w21
    43d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    43d8:	1e612800 	fadd	d0, d0, d1
    43dc:	fd0a1c00 	str	d0, [x0, #5176]
    43e0:	34000158 	cbz	w24, 4408 <fwp_heap_alloc+0xf8>
    43e4:	9114c2e1 	add	x1, x23, #0x530
    43e8:	910142c0 	add	x0, x22, #0x50
    43ec:	fd4a1020 	ldr	d0, [x1, #5152]
    43f0:	fd415c02 	ldr	d2, [x0, #696]
    43f4:	fd416001 	ldr	d1, [x0, #704]
    43f8:	7e61d800 	ucvtf	d0, d0
    43fc:	1e623800 	fsub	d0, d0, d2
    4400:	1e612010 	fcmpe	d0, d1
    4404:	5400030c 	b.gt	4464 <fwp_heap_alloc+0x154>
    4408:	a94153f3 	ldp	x19, x20, [sp, #16]
    440c:	aa0403e0 	mov	x0, x4
    4410:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4414:	a94363f7 	ldp	x23, x24, [sp, #48]
    4418:	a8c47bfd 	ldp	x29, x30, [sp], #64
    441c:	d65f03c0 	ret
    4420:	8b030263 	add	x3, x19, x3
    4424:	f9400464 	ldr	x4, [x3, #8]
    4428:	b40000a4 	cbz	x4, 443c <fwp_heap_alloc+0x12c>
    442c:	f9400862 	ldr	x2, [x3, #16]
    4430:	cb040042 	sub	x2, x2, x4
    4434:	eb02029f 	cmp	x20, x2
    4438:	54000249 	b.ls	4480 <fwp_heap_alloc+0x170>  // b.plast
    443c:	97fffc25 	bl	34d0 <fwp_heap_alloc_slow>
    4440:	aa0003e4 	mov	x4, x0
    4444:	17ffffe7 	b	43e0 <fwp_heap_alloc+0xd0>
    4448:	f9415444 	ldr	x4, [x2, #680]
    444c:	f9415843 	ldr	x3, [x2, #688]
    4450:	91000484 	add	x4, x4, #0x1
    4454:	f9015444 	str	x4, [x2, #680]
    4458:	8b000063 	add	x3, x3, x0
    445c:	f9015843 	str	x3, [x2, #688]
    4460:	17ffffb7 	b	433c <fwp_heap_alloc+0x2c>
    4464:	a94153f3 	ldp	x19, x20, [sp, #16]
    4468:	fd016000 	str	d0, [x0, #704]
    446c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4470:	aa0403e0 	mov	x0, x4
    4474:	a94363f7 	ldp	x23, x24, [sp, #48]
    4478:	a8c47bfd 	ldp	x29, x30, [sp], #64
    447c:	d65f03c0 	ret
    4480:	7100043f 	cmp	w1, #0x1
    4484:	8b140085 	add	x5, x4, x20
    4488:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    448c:	52800001 	mov	w1, #0x0                   	// #0
    4490:	aa0403e0 	mov	x0, x4
    4494:	f9000465 	str	x5, [x3, #8]
    4498:	17ffffc3 	b	43a4 <fwp_heap_alloc+0x94>
    449c:	97fff62d 	bl	1d50 <fwp_heap_oom>

00000000000044a0 <fwp_map_items>:
    44a0:	b40003a0 	cbz	x0, 4514 <fwp_map_items+0x74>
    44a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    44a8:	aa0003e3 	mov	x3, x0
    44ac:	d2800002 	mov	x2, #0x0                   	// #0
    44b0:	910003fd 	mov	x29, sp
    44b4:	f9000bf3 	str	x19, [sp, #16]
    44b8:	aa0003f3 	mov	x19, x0
    44bc:	d503201f 	nop
    44c0:	f9400863 	ldr	x3, [x3, #16]
    44c4:	aa0203e0 	mov	x0, x2
    44c8:	91000442 	add	x2, x2, #0x1
    44cc:	b5ffffa3 	cbnz	x3, 44c0 <fwp_map_items+0x20>
    44d0:	f9000022 	str	x2, [x1]
    44d4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    44d8:	eb01005f 	cmp	x2, x1
    44dc:	54000248 	b.hi	4524 <fwp_map_items+0x84>  // b.pmore
    44e0:	91000800 	add	x0, x0, #0x2
    44e4:	52800041 	mov	w1, #0x2                   	// #2
    44e8:	d37df000 	lsl	x0, x0, #3
    44ec:	97ffff89 	bl	4310 <fwp_heap_alloc>
    44f0:	aa0003e1 	mov	x1, x0
    44f4:	d503201f 	nop
    44f8:	f9400662 	ldr	x2, [x19, #8]
    44fc:	f8008422 	str	x2, [x1], #8
    4500:	f9400a73 	ldr	x19, [x19, #16]
    4504:	b5ffffb3 	cbnz	x19, 44f8 <fwp_map_items+0x58>
    4508:	f9400bf3 	ldr	x19, [sp, #16]
    450c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4510:	d65f03c0 	ret
    4514:	f900003f 	str	xzr, [x1]
    4518:	d2800100 	mov	x0, #0x8                   	// #8
    451c:	52800041 	mov	w1, #0x2                   	// #2
    4520:	17ffff7c 	b	4310 <fwp_heap_alloc>
    4524:	f0000000 	adrp	x0, 7000 <__modti3+0x1a0>
    4528:	9115a000 	add	x0, x0, #0x568
    452c:	97fff775 	bl	2300 <fwp_trap>

0000000000004530 <fwp_drop4>:
    4530:	b0000165 	adrp	x5, 31000 <fwp_root_context+0xcb0>
    4534:	9114c0a3 	add	x3, x5, #0x530
    4538:	f949d861 	ldr	x1, [x3, #5040]
    453c:	f949ec62 	ldr	x2, [x3, #5080]
    4540:	cb010001 	sub	x1, x0, x1
    4544:	eb02403f 	cmp	x1, x2, lsl #16
    4548:	54000542 	b.cs	45f0 <fwp_drop4+0xc0>  // b.hs, b.nlast
    454c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4550:	d350fc22 	lsr	x2, x1, #16
    4554:	910003fd 	mov	x29, sp
    4558:	8b020842 	add	x2, x2, x2, lsl #2
    455c:	f949fc64 	ldr	x4, [x3, #5112]
    4560:	d37df042 	lsl	x2, x2, #3
    4564:	f9000bf3 	str	x19, [sp, #16]
    4568:	8b020083 	add	x3, x4, x2
    456c:	f9401073 	ldr	x19, [x3, #32]
    4570:	b40002b3 	cbz	x19, 45c4 <fwp_drop4+0x94>
    4574:	38626882 	ldrb	w2, [x4, x2]
    4578:	7100085f 	cmp	w2, #0x2
    457c:	540002a0 	b.eq	45d0 <fwp_drop4+0xa0>  // b.none
    4580:	7100045f 	cmp	w2, #0x1
    4584:	54000201 	b.ne	45c4 <fwp_drop4+0x94>  // b.any
    4588:	29430864 	ldp	w4, w2, [x3, #24]
    458c:	92403c21 	and	x1, x1, #0xffff
    4590:	9b047c21 	mul	x1, x1, x4
    4594:	d360fc21 	lsr	x1, x1, #32
    4598:	eb02003f 	cmp	x1, x2
    459c:	54000142 	b.cs	45c4 <fwp_drop4+0x94>  // b.hs, b.nlast
    45a0:	8b010273 	add	x19, x19, x1
    45a4:	39400261 	ldrb	w1, [x19]
    45a8:	340000e1 	cbz	w1, 45c4 <fwp_drop4+0x94>
    45ac:	7100043f 	cmp	w1, #0x1
    45b0:	540001a0 	b.eq	45e4 <fwp_drop4+0xb4>  // b.none
    45b4:	7103fc3f 	cmp	w1, #0xff
    45b8:	540001e0 	b.eq	45f4 <fwp_drop4+0xc4>  // b.none
    45bc:	51000421 	sub	w1, w1, #0x1
    45c0:	39000261 	strb	w1, [x19]
    45c4:	f9400bf3 	ldr	x19, [sp, #16]
    45c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45cc:	d65f03c0 	ret
    45d0:	72003c3f 	tst	w1, #0xffff
    45d4:	54fffe80 	b.eq	45a4 <fwp_drop4+0x74>  // b.none
    45d8:	f9400bf3 	ldr	x19, [sp, #16]
    45dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45e0:	d65f03c0 	ret
    45e4:	f9400bf3 	ldr	x19, [sp, #16]
    45e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45ec:	17fffaf1 	b	31b0 <fwp_mem_free>
    45f0:	d65f03c0 	ret
    45f4:	ca534660 	eor	x0, x19, x19, lsr #17
    45f8:	9114c0a5 	add	x5, x5, #0x530
    45fc:	ca402400 	eor	x0, x0, x0, lsr #9
    4600:	8b200ca0 	add	x0, x5, w0, uxtb #3
    4604:	f94a2400 	ldr	x0, [x0, #5192]
    4608:	b5000080 	cbnz	x0, 4618 <fwp_drop4+0xe8>
    460c:	14000010 	b	464c <fwp_drop4+0x11c>
    4610:	f9400800 	ldr	x0, [x0, #16]
    4614:	b40001c0 	cbz	x0, 464c <fwp_drop4+0x11c>
    4618:	f9400001 	ldr	x1, [x0]
    461c:	eb13003f 	cmp	x1, x19
    4620:	54ffff81 	b.ne	4610 <fwp_drop4+0xe0>  // b.any
    4624:	f9400401 	ldr	x1, [x0, #8]
    4628:	d1000421 	sub	x1, x1, #0x1
    462c:	f9000401 	str	x1, [x0, #8]
    4630:	f103f83f 	cmp	x1, #0xfe
    4634:	54fffc81 	b.ne	45c4 <fwp_drop4+0x94>  // b.any
    4638:	aa1303e0 	mov	x0, x19
    463c:	97fffa3d 	bl	2f30 <fwp_rc_forget_slot>
    4640:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4644:	39000260 	strb	w0, [x19]
    4648:	17ffffdf 	b	45c4 <fwp_drop4+0x94>
    464c:	f0000000 	adrp	x0, 7000 <__modti3+0x1a0>
    4650:	91138000 	add	x0, x0, #0x4e0
    4654:	97fff72b 	bl	2300 <fwp_trap>
    4658:	d503201f 	nop
    465c:	d503201f 	nop

0000000000004660 <fwp_owned_entry50>:
    4660:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4664:	910003fd 	mov	x29, sp
    4668:	f9400000 	ldr	x0, [x0]
    466c:	f9000bf3 	str	x19, [sp, #16]
    4670:	f9400813 	ldr	x19, [x0, #16]
    4674:	97ffffaf 	bl	4530 <fwp_drop4>
    4678:	aa1303e0 	mov	x0, x19
    467c:	f9400bf3 	ldr	x19, [sp, #16]
    4680:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4684:	d65f03c0 	ret
    4688:	d503201f 	nop
    468c:	d503201f 	nop

0000000000004690 <fwp_owned_entry47>:
    4690:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4694:	910003fd 	mov	x29, sp
    4698:	f9400000 	ldr	x0, [x0]
    469c:	f9000bf3 	str	x19, [sp, #16]
    46a0:	f9400413 	ldr	x19, [x0, #8]
    46a4:	97ffffa3 	bl	4530 <fwp_drop4>
    46a8:	aa1303e0 	mov	x0, x19
    46ac:	f9400bf3 	ldr	x19, [sp, #16]
    46b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    46b4:	d65f03c0 	ret
    46b8:	d503201f 	nop
    46bc:	d503201f 	nop

00000000000046c0 <fwp_arg_drop47>:
    46c0:	7100003f 	cmp	w1, #0x0
    46c4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    46c8:	54000041 	b.ne	46d0 <fwp_arg_drop47+0x10>  // b.any
    46cc:	d65f03c0 	ret
    46d0:	f9400000 	ldr	x0, [x0]
    46d4:	17ffff97 	b	4530 <fwp_drop4>
    46d8:	d503201f 	nop
    46dc:	d503201f 	nop

00000000000046e0 <e50>:
    46e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    46e4:	910003fd 	mov	x29, sp
    46e8:	a90153f3 	stp	x19, x20, [sp, #16]
    46ec:	f9400013 	ldr	x19, [x0]
    46f0:	aa1303e0 	mov	x0, x19
    46f4:	97fffbcf 	bl	3630 <fwp_rc_share>
    46f8:	f9400a74 	ldr	x20, [x19, #16]
    46fc:	aa1303e0 	mov	x0, x19
    4700:	97ffff8c 	bl	4530 <fwp_drop4>
    4704:	aa1403e0 	mov	x0, x20
    4708:	97fffbca 	bl	3630 <fwp_rc_share>
    470c:	aa1403e0 	mov	x0, x20
    4710:	a94153f3 	ldp	x19, x20, [sp, #16]
    4714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4718:	d65f03c0 	ret
    471c:	d503201f 	nop

0000000000004720 <e47>:
    4720:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4724:	910003fd 	mov	x29, sp
    4728:	a90153f3 	stp	x19, x20, [sp, #16]
    472c:	f9400013 	ldr	x19, [x0]
    4730:	aa1303e0 	mov	x0, x19
    4734:	97fffbbf 	bl	3630 <fwp_rc_share>
    4738:	f9400674 	ldr	x20, [x19, #8]
    473c:	aa1303e0 	mov	x0, x19
    4740:	97ffff7c 	bl	4530 <fwp_drop4>
    4744:	aa1403e0 	mov	x0, x20
    4748:	97fffbba 	bl	3630 <fwp_rc_share>
    474c:	aa1403e0 	mov	x0, x20
    4750:	a94153f3 	ldp	x19, x20, [sp, #16]
    4754:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4758:	d65f03c0 	ret
    475c:	d503201f 	nop

0000000000004760 <fwp_arg_drop50>:
    4760:	7100003f 	cmp	w1, #0x0
    4764:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4768:	54000041 	b.ne	4770 <fwp_arg_drop50+0x10>  // b.any
    476c:	d65f03c0 	ret
    4770:	f9400000 	ldr	x0, [x0]
    4774:	17ffff6f 	b	4530 <fwp_drop4>
    4778:	d503201f 	nop
    477c:	d503201f 	nop

0000000000004780 <fwp_drop0>:
    4780:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4784:	910003fd 	mov	x29, sp
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	f90013f5 	str	x21, [sp, #32]
    4790:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4794:	9114c2b4 	add	x20, x21, #0x530
    4798:	f949da81 	ldr	x1, [x20, #5040]
    479c:	f949ee82 	ldr	x2, [x20, #5080]
    47a0:	cb010001 	sub	x1, x0, x1
    47a4:	eb02403f 	cmp	x1, x2, lsl #16
    47a8:	54000382 	b.cs	4818 <fwp_drop0+0x98>  // b.hs, b.nlast
    47ac:	d350fc22 	lsr	x2, x1, #16
    47b0:	f949fe83 	ldr	x3, [x20, #5112]
    47b4:	8b020842 	add	x2, x2, x2, lsl #2
    47b8:	d37df042 	lsl	x2, x2, #3
    47bc:	8b020064 	add	x4, x3, x2
    47c0:	f9401093 	ldr	x19, [x4, #32]
    47c4:	b40002b3 	cbz	x19, 4818 <fwp_drop0+0x98>
    47c8:	38626862 	ldrb	w2, [x3, x2]
    47cc:	7100085f 	cmp	w2, #0x2
    47d0:	540002c0 	b.eq	4828 <fwp_drop0+0xa8>  // b.none
    47d4:	7100045f 	cmp	w2, #0x1
    47d8:	54000201 	b.ne	4818 <fwp_drop0+0x98>  // b.any
    47dc:	29430885 	ldp	w5, w2, [x4, #24]
    47e0:	92403c21 	and	x1, x1, #0xffff
    47e4:	9b057c21 	mul	x1, x1, x5
    47e8:	d360fc21 	lsr	x1, x1, #32
    47ec:	eb02003f 	cmp	x1, x2
    47f0:	54000142 	b.cs	4818 <fwp_drop0+0x98>  // b.hs, b.nlast
    47f4:	8b010273 	add	x19, x19, x1
    47f8:	39400261 	ldrb	w1, [x19]
    47fc:	340000e1 	cbz	w1, 4818 <fwp_drop0+0x98>
    4800:	7100043f 	cmp	w1, #0x1
    4804:	540001e0 	b.eq	4840 <fwp_drop0+0xc0>  // b.none
    4808:	7103fc3f 	cmp	w1, #0xff
    480c:	540006e0 	b.eq	48e8 <fwp_drop0+0x168>  // b.none
    4810:	51000421 	sub	w1, w1, #0x1
    4814:	39000261 	strb	w1, [x19]
    4818:	a94153f3 	ldp	x19, x20, [sp, #16]
    481c:	f94013f5 	ldr	x21, [sp, #32]
    4820:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4824:	d65f03c0 	ret
    4828:	72003c3f 	tst	w1, #0xffff
    482c:	54fffe60 	b.eq	47f8 <fwp_drop0+0x78>  // b.none
    4830:	a94153f3 	ldp	x19, x20, [sp, #16]
    4834:	f94013f5 	ldr	x21, [sp, #32]
    4838:	a8c37bfd 	ldp	x29, x30, [sp], #48
    483c:	d65f03c0 	ret
    4840:	9114c2a1 	add	x1, x21, #0x530
    4844:	f9400813 	ldr	x19, [x0, #16]
    4848:	f949ec25 	ldr	x5, [x1, #5080]
    484c:	f949d821 	ldr	x1, [x1, #5040]
    4850:	d370bca5 	lsl	x5, x5, #16
    4854:	cb010002 	sub	x2, x0, x1
    4858:	eb05005f 	cmp	x2, x5
    485c:	54000362 	b.cs	48c8 <fwp_drop0+0x148>  // b.hs, b.nlast
    4860:	d350fc44 	lsr	x4, x2, #16
    4864:	8b040884 	add	x4, x4, x4, lsl #2
    4868:	d37df084 	lsl	x4, x4, #3
    486c:	8b040067 	add	x7, x3, x4
    4870:	f94010e6 	ldr	x6, [x7, #32]
    4874:	b40002a6 	cbz	x6, 48c8 <fwp_drop0+0x148>
    4878:	38646863 	ldrb	w3, [x3, x4]
    487c:	7100087f 	cmp	w3, #0x2
    4880:	540002e0 	b.eq	48dc <fwp_drop0+0x15c>  // b.none
    4884:	7100047f 	cmp	w3, #0x1
    4888:	54000201 	b.ne	48c8 <fwp_drop0+0x148>  // b.any
    488c:	29430ce4 	ldp	w4, w3, [x7, #24]
    4890:	92403c42 	and	x2, x2, #0xffff
    4894:	9b047c42 	mul	x2, x2, x4
    4898:	d360fc42 	lsr	x2, x2, #32
    489c:	eb03005f 	cmp	x2, x3
    48a0:	54000142 	b.cs	48c8 <fwp_drop0+0x148>  // b.hs, b.nlast
    48a4:	8b0200c6 	add	x6, x6, x2
    48a8:	394000c2 	ldrb	w2, [x6]
    48ac:	7100045f 	cmp	w2, #0x1
    48b0:	540000c1 	b.ne	48c8 <fwp_drop0+0x148>  // b.any
    48b4:	97fffa3f 	bl	31b0 <fwp_mem_free>
    48b8:	9114c2a0 	add	x0, x21, #0x530
    48bc:	f949ec05 	ldr	x5, [x0, #5080]
    48c0:	f949d801 	ldr	x1, [x0, #5040]
    48c4:	d370bca5 	lsl	x5, x5, #16
    48c8:	cb010261 	sub	x1, x19, x1
    48cc:	eb05003f 	cmp	x1, x5
    48d0:	54fffa42 	b.cs	4818 <fwp_drop0+0x98>  // b.hs, b.nlast
    48d4:	aa1303e0 	mov	x0, x19
    48d8:	17ffffb5 	b	47ac <fwp_drop0+0x2c>
    48dc:	72003c5f 	tst	w2, #0xffff
    48e0:	54ffff41 	b.ne	48c8 <fwp_drop0+0x148>  // b.any
    48e4:	17fffff1 	b	48a8 <fwp_drop0+0x128>
    48e8:	ca534661 	eor	x1, x19, x19, lsr #17
    48ec:	9114c2a0 	add	x0, x21, #0x530
    48f0:	ca412421 	eor	x1, x1, x1, lsr #9
    48f4:	8b210c01 	add	x1, x0, w1, uxtb #3
    48f8:	f94a2420 	ldr	x0, [x1, #5192]
    48fc:	b5000080 	cbnz	x0, 490c <fwp_drop0+0x18c>
    4900:	14000010 	b	4940 <fwp_drop0+0x1c0>
    4904:	f9400800 	ldr	x0, [x0, #16]
    4908:	b40001c0 	cbz	x0, 4940 <fwp_drop0+0x1c0>
    490c:	f9400001 	ldr	x1, [x0]
    4910:	eb13003f 	cmp	x1, x19
    4914:	54ffff81 	b.ne	4904 <fwp_drop0+0x184>  // b.any
    4918:	f9400401 	ldr	x1, [x0, #8]
    491c:	d1000421 	sub	x1, x1, #0x1
    4920:	f9000401 	str	x1, [x0, #8]
    4924:	f103f83f 	cmp	x1, #0xfe
    4928:	54fff781 	b.ne	4818 <fwp_drop0+0x98>  // b.any
    492c:	aa1303e0 	mov	x0, x19
    4930:	97fff980 	bl	2f30 <fwp_rc_forget_slot>
    4934:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4938:	39000260 	strb	w0, [x19]
    493c:	17ffffb7 	b	4818 <fwp_drop0+0x98>
    4940:	f0000000 	adrp	x0, 7000 <__modti3+0x1a0>
    4944:	91138000 	add	x0, x0, #0x4e0
    4948:	97fff66e 	bl	2300 <fwp_trap>
    494c:	d503201f 	nop

0000000000004950 <fwp_drop1>:
    4950:	17ffff8c 	b	4780 <fwp_drop0>

0000000000004954 <fwp_loop_fields68.constprop.0>:
    4954:	d65f03c0 	ret
    4958:	d503201f 	nop
    495c:	d503201f 	nop

0000000000004960 <fwp_drop6>:
    4960:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4964:	910003fd 	mov	x29, sp
    4968:	a9025bf5 	stp	x21, x22, [sp, #32]
    496c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    4970:	9114c2d5 	add	x21, x22, #0x530
    4974:	a90153f3 	stp	x19, x20, [sp, #16]
    4978:	aa0003f3 	mov	x19, x0
    497c:	f949daa1 	ldr	x1, [x21, #5040]
    4980:	f949eea0 	ldr	x0, [x21, #5080]
    4984:	cb010261 	sub	x1, x19, x1
    4988:	eb00403f 	cmp	x1, x0, lsl #16
    498c:	54000382 	b.cs	49fc <fwp_drop6+0x9c>  // b.hs, b.nlast
    4990:	d350fc22 	lsr	x2, x1, #16
    4994:	f949fea3 	ldr	x3, [x21, #5112]
    4998:	8b020842 	add	x2, x2, x2, lsl #2
    499c:	d37df042 	lsl	x2, x2, #3
    49a0:	8b020060 	add	x0, x3, x2
    49a4:	f9401014 	ldr	x20, [x0, #32]
    49a8:	b40002b4 	cbz	x20, 49fc <fwp_drop6+0x9c>
    49ac:	38626862 	ldrb	w2, [x3, x2]
    49b0:	7100085f 	cmp	w2, #0x2
    49b4:	540002c0 	b.eq	4a0c <fwp_drop6+0xac>  // b.none
    49b8:	7100045f 	cmp	w2, #0x1
    49bc:	54000201 	b.ne	49fc <fwp_drop6+0x9c>  // b.any
    49c0:	29430002 	ldp	w2, w0, [x0, #24]
    49c4:	92403c21 	and	x1, x1, #0xffff
    49c8:	9b027c21 	mul	x1, x1, x2
    49cc:	d360fc21 	lsr	x1, x1, #32
    49d0:	eb00003f 	cmp	x1, x0
    49d4:	54000142 	b.cs	49fc <fwp_drop6+0x9c>  // b.hs, b.nlast
    49d8:	8b010294 	add	x20, x20, x1
    49dc:	39400280 	ldrb	w0, [x20]
    49e0:	340000e0 	cbz	w0, 49fc <fwp_drop6+0x9c>
    49e4:	7100041f 	cmp	w0, #0x1
    49e8:	540001e0 	b.eq	4a24 <fwp_drop6+0xc4>  // b.none
    49ec:	7103fc1f 	cmp	w0, #0xff
    49f0:	54000760 	b.eq	4adc <fwp_drop6+0x17c>  // b.none
    49f4:	51000400 	sub	w0, w0, #0x1
    49f8:	39000280 	strb	w0, [x20]
    49fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a08:	d65f03c0 	ret
    4a0c:	72003c3f 	tst	w1, #0xffff
    4a10:	54fffe60 	b.eq	49dc <fwp_drop6+0x7c>  // b.none
    4a14:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a1c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4a20:	d65f03c0 	ret
    4a24:	f9400660 	ldr	x0, [x19, #8]
    4a28:	97fffec2 	bl	4530 <fwp_drop4>
    4a2c:	9114c2c4 	add	x4, x22, #0x530
    4a30:	f9400a74 	ldr	x20, [x19, #16]
    4a34:	f949ec83 	ldr	x3, [x4, #5080]
    4a38:	f949d881 	ldr	x1, [x4, #5040]
    4a3c:	d370bc63 	lsl	x3, x3, #16
    4a40:	cb010262 	sub	x2, x19, x1
    4a44:	eb03005f 	cmp	x2, x3
    4a48:	540003a2 	b.cs	4abc <fwp_drop6+0x15c>  // b.hs, b.nlast
    4a4c:	d350fc40 	lsr	x0, x2, #16
    4a50:	f949fc86 	ldr	x6, [x4, #5112]
    4a54:	8b000800 	add	x0, x0, x0, lsl #2
    4a58:	d37df000 	lsl	x0, x0, #3
    4a5c:	8b0000c5 	add	x5, x6, x0
    4a60:	f94010a4 	ldr	x4, [x5, #32]
    4a64:	b40002c4 	cbz	x4, 4abc <fwp_drop6+0x15c>
    4a68:	386068c0 	ldrb	w0, [x6, x0]
    4a6c:	7100081f 	cmp	w0, #0x2
    4a70:	54000300 	b.eq	4ad0 <fwp_drop6+0x170>  // b.none
    4a74:	7100041f 	cmp	w0, #0x1
    4a78:	54000221 	b.ne	4abc <fwp_drop6+0x15c>  // b.any
    4a7c:	92403c40 	and	x0, x2, #0xffff
    4a80:	294308a6 	ldp	w6, w2, [x5, #24]
    4a84:	9b067c00 	mul	x0, x0, x6
    4a88:	d360fc00 	lsr	x0, x0, #32
    4a8c:	eb02001f 	cmp	x0, x2
    4a90:	54000162 	b.cs	4abc <fwp_drop6+0x15c>  // b.hs, b.nlast
    4a94:	8b000084 	add	x4, x4, x0
    4a98:	39400080 	ldrb	w0, [x4]
    4a9c:	7100041f 	cmp	w0, #0x1
    4aa0:	540000e1 	b.ne	4abc <fwp_drop6+0x15c>  // b.any
    4aa4:	aa1303e0 	mov	x0, x19
    4aa8:	97fff9c2 	bl	31b0 <fwp_mem_free>
    4aac:	9114c2c0 	add	x0, x22, #0x530
    4ab0:	f949ec03 	ldr	x3, [x0, #5080]
    4ab4:	f949d801 	ldr	x1, [x0, #5040]
    4ab8:	d370bc63 	lsl	x3, x3, #16
    4abc:	cb010281 	sub	x1, x20, x1
    4ac0:	eb01007f 	cmp	x3, x1
    4ac4:	54fff9c9 	b.ls	49fc <fwp_drop6+0x9c>  // b.plast
    4ac8:	aa1403f3 	mov	x19, x20
    4acc:	17ffffb1 	b	4990 <fwp_drop6+0x30>
    4ad0:	72003c5f 	tst	w2, #0xffff
    4ad4:	54ffff41 	b.ne	4abc <fwp_drop6+0x15c>  // b.any
    4ad8:	17fffff0 	b	4a98 <fwp_drop6+0x138>
    4adc:	ca544681 	eor	x1, x20, x20, lsr #17
    4ae0:	9114c2c0 	add	x0, x22, #0x530
    4ae4:	ca412421 	eor	x1, x1, x1, lsr #9
    4ae8:	8b210c01 	add	x1, x0, w1, uxtb #3
    4aec:	f94a2420 	ldr	x0, [x1, #5192]
    4af0:	b5000080 	cbnz	x0, 4b00 <fwp_drop6+0x1a0>
    4af4:	14000010 	b	4b34 <fwp_drop6+0x1d4>
    4af8:	f9400800 	ldr	x0, [x0, #16]
    4afc:	b40001c0 	cbz	x0, 4b34 <fwp_drop6+0x1d4>
    4b00:	f9400001 	ldr	x1, [x0]
    4b04:	eb14003f 	cmp	x1, x20
    4b08:	54ffff81 	b.ne	4af8 <fwp_drop6+0x198>  // b.any
    4b0c:	f9400401 	ldr	x1, [x0, #8]
    4b10:	d1000421 	sub	x1, x1, #0x1
    4b14:	f9000401 	str	x1, [x0, #8]
    4b18:	f103f83f 	cmp	x1, #0xfe
    4b1c:	54fff701 	b.ne	49fc <fwp_drop6+0x9c>  // b.any
    4b20:	aa1403e0 	mov	x0, x20
    4b24:	97fff903 	bl	2f30 <fwp_rc_forget_slot>
    4b28:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4b2c:	39000280 	strb	w0, [x20]
    4b30:	17ffffb3 	b	49fc <fwp_drop6+0x9c>
    4b34:	f0000000 	adrp	x0, 7000 <__modti3+0x1a0>
    4b38:	91138000 	add	x0, x0, #0x4e0
    4b3c:	97fff5f1 	bl	2300 <fwp_trap>

0000000000004b40 <fwp_args47>:
    4b40:	7100003f 	cmp	w1, #0x0
    4b44:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4b48:	54000041 	b.ne	4b50 <fwp_args47+0x10>  // b.any
    4b4c:	d65f03c0 	ret
    4b50:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    4b54:	9114c042 	add	x2, x2, #0x530
    4b58:	f9400001 	ldr	x1, [x0]
    4b5c:	f949d843 	ldr	x3, [x2, #5040]
    4b60:	f949ec40 	ldr	x0, [x2, #5080]
    4b64:	cb030021 	sub	x1, x1, x3
    4b68:	eb00403f 	cmp	x1, x0, lsl #16
    4b6c:	54ffff02 	b.cs	4b4c <fwp_args47+0xc>  // b.hs, b.nlast
    4b70:	d350fc20 	lsr	x0, x1, #16
    4b74:	f949fc44 	ldr	x4, [x2, #5112]
    4b78:	8b000800 	add	x0, x0, x0, lsl #2
    4b7c:	d37df002 	lsl	x2, x0, #3
    4b80:	8b020083 	add	x3, x4, x2
    4b84:	f9401060 	ldr	x0, [x3, #32]
    4b88:	b4fffe20 	cbz	x0, 4b4c <fwp_args47+0xc>
    4b8c:	38626882 	ldrb	w2, [x4, x2]
    4b90:	7100085f 	cmp	w2, #0x2
    4b94:	54000320 	b.eq	4bf8 <fwp_args47+0xb8>  // b.none
    4b98:	7100045f 	cmp	w2, #0x1
    4b9c:	54fffd81 	b.ne	4b4c <fwp_args47+0xc>  // b.any
    4ba0:	29430864 	ldp	w4, w2, [x3, #24]
    4ba4:	92403c21 	and	x1, x1, #0xffff
    4ba8:	9b047c21 	mul	x1, x1, x4
    4bac:	d360fc21 	lsr	x1, x1, #32
    4bb0:	eb02003f 	cmp	x1, x2
    4bb4:	54fffcc2 	b.cs	4b4c <fwp_args47+0xc>  // b.hs, b.nlast
    4bb8:	8b010000 	add	x0, x0, x1
    4bbc:	39400001 	ldrb	w1, [x0]
    4bc0:	34fffc61 	cbz	w1, 4b4c <fwp_args47+0xc>
    4bc4:	900000e2 	adrp	x2, 20000 <__data_start>
    4bc8:	91014042 	add	x2, x2, #0x50
    4bcc:	b9404043 	ldr	w3, [x2, #64]
    4bd0:	350000c3 	cbnz	w3, 4be8 <fwp_args47+0xa8>
    4bd4:	7103f43f 	cmp	w1, #0xfd
    4bd8:	54000168 	b.hi	4c04 <fwp_args47+0xc4>  // b.pmore
    4bdc:	11000421 	add	w1, w1, #0x1
    4be0:	39000001 	strb	w1, [x0]
    4be4:	d65f03c0 	ret
    4be8:	f9402443 	ldr	x3, [x2, #72]
    4bec:	91000463 	add	x3, x3, #0x1
    4bf0:	f9002443 	str	x3, [x2, #72]
    4bf4:	17fffff8 	b	4bd4 <fwp_args47+0x94>
    4bf8:	72003c3f 	tst	w1, #0xffff
    4bfc:	54fffe00 	b.eq	4bbc <fwp_args47+0x7c>  // b.none
    4c00:	d65f03c0 	ret
    4c04:	17fff884 	b	2e14 <fwp_rc_wide_dup>
    4c08:	d503201f 	nop
    4c0c:	d503201f 	nop

0000000000004c10 <fwp_args50>:
    4c10:	7100003f 	cmp	w1, #0x0
    4c14:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4c18:	54000041 	b.ne	4c20 <fwp_args50+0x10>  // b.any
    4c1c:	d65f03c0 	ret
    4c20:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    4c24:	9114c042 	add	x2, x2, #0x530
    4c28:	f9400001 	ldr	x1, [x0]
    4c2c:	f949d843 	ldr	x3, [x2, #5040]
    4c30:	f949ec40 	ldr	x0, [x2, #5080]
    4c34:	cb030021 	sub	x1, x1, x3
    4c38:	eb00403f 	cmp	x1, x0, lsl #16
    4c3c:	54ffff02 	b.cs	4c1c <fwp_args50+0xc>  // b.hs, b.nlast
    4c40:	d350fc20 	lsr	x0, x1, #16
    4c44:	f949fc44 	ldr	x4, [x2, #5112]
    4c48:	8b000800 	add	x0, x0, x0, lsl #2
    4c4c:	d37df002 	lsl	x2, x0, #3
    4c50:	8b020083 	add	x3, x4, x2
    4c54:	f9401060 	ldr	x0, [x3, #32]
    4c58:	b4fffe20 	cbz	x0, 4c1c <fwp_args50+0xc>
    4c5c:	38626882 	ldrb	w2, [x4, x2]
    4c60:	7100085f 	cmp	w2, #0x2
    4c64:	54000320 	b.eq	4cc8 <fwp_args50+0xb8>  // b.none
    4c68:	7100045f 	cmp	w2, #0x1
    4c6c:	54fffd81 	b.ne	4c1c <fwp_args50+0xc>  // b.any
    4c70:	29430864 	ldp	w4, w2, [x3, #24]
    4c74:	92403c21 	and	x1, x1, #0xffff
    4c78:	9b047c21 	mul	x1, x1, x4
    4c7c:	d360fc21 	lsr	x1, x1, #32
    4c80:	eb02003f 	cmp	x1, x2
    4c84:	54fffcc2 	b.cs	4c1c <fwp_args50+0xc>  // b.hs, b.nlast
    4c88:	8b010000 	add	x0, x0, x1
    4c8c:	39400001 	ldrb	w1, [x0]
    4c90:	34fffc61 	cbz	w1, 4c1c <fwp_args50+0xc>
    4c94:	900000e2 	adrp	x2, 20000 <__data_start>
    4c98:	91014042 	add	x2, x2, #0x50
    4c9c:	b9404043 	ldr	w3, [x2, #64]
    4ca0:	350000c3 	cbnz	w3, 4cb8 <fwp_args50+0xa8>
    4ca4:	7103f43f 	cmp	w1, #0xfd
    4ca8:	54000168 	b.hi	4cd4 <fwp_args50+0xc4>  // b.pmore
    4cac:	11000421 	add	w1, w1, #0x1
    4cb0:	39000001 	strb	w1, [x0]
    4cb4:	d65f03c0 	ret
    4cb8:	f9402443 	ldr	x3, [x2, #72]
    4cbc:	91000463 	add	x3, x3, #0x1
    4cc0:	f9002443 	str	x3, [x2, #72]
    4cc4:	17fffff8 	b	4ca4 <fwp_args50+0x94>
    4cc8:	72003c3f 	tst	w1, #0xffff
    4ccc:	54fffe00 	b.eq	4c8c <fwp_args50+0x7c>  // b.none
    4cd0:	d65f03c0 	ret
    4cd4:	17fff850 	b	2e14 <fwp_rc_wide_dup>
    4cd8:	d503201f 	nop
    4cdc:	d503201f 	nop

0000000000004ce0 <fwp_caps50>:
    4ce0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4ce4:	910003fd 	mov	x29, sp
    4ce8:	f9000bf3 	str	x19, [sp, #16]
    4cec:	aa0003f3 	mov	x19, x0
    4cf0:	b9400400 	ldr	w0, [x0, #4]
    4cf4:	340004a0 	cbz	w0, 4d88 <fwp_caps50+0xa8>
    4cf8:	f9400660 	ldr	x0, [x19, #8]
    4cfc:	350004e1 	cbnz	w1, 4d98 <fwp_caps50+0xb8>
    4d00:	97fffe0c 	bl	4530 <fwp_drop4>
    4d04:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    4d08:	9114c042 	add	x2, x2, #0x530
    4d0c:	f949d840 	ldr	x0, [x2, #5040]
    4d10:	f949ec41 	ldr	x1, [x2, #5080]
    4d14:	cb000260 	sub	x0, x19, x0
    4d18:	eb01401f 	cmp	x0, x1, lsl #16
    4d1c:	54000382 	b.cs	4d8c <fwp_caps50+0xac>  // b.hs, b.nlast
    4d20:	d350fc01 	lsr	x1, x0, #16
    4d24:	f949fc44 	ldr	x4, [x2, #5112]
    4d28:	8b010821 	add	x1, x1, x1, lsl #2
    4d2c:	d37df021 	lsl	x1, x1, #3
    4d30:	8b010083 	add	x3, x4, x1
    4d34:	f9401062 	ldr	x2, [x3, #32]
    4d38:	b40002a2 	cbz	x2, 4d8c <fwp_caps50+0xac>
    4d3c:	38616881 	ldrb	w1, [x4, x1]
    4d40:	7100083f 	cmp	w1, #0x2
    4d44:	54000740 	b.eq	4e2c <fwp_caps50+0x14c>  // b.none
    4d48:	7100043f 	cmp	w1, #0x1
    4d4c:	54000201 	b.ne	4d8c <fwp_caps50+0xac>  // b.any
    4d50:	29430464 	ldp	w4, w1, [x3, #24]
    4d54:	92403c00 	and	x0, x0, #0xffff
    4d58:	9b047c00 	mul	x0, x0, x4
    4d5c:	d360fc00 	lsr	x0, x0, #32
    4d60:	eb01001f 	cmp	x0, x1
    4d64:	54000142 	b.cs	4d8c <fwp_caps50+0xac>  // b.hs, b.nlast
    4d68:	8b000042 	add	x2, x2, x0
    4d6c:	39400040 	ldrb	w0, [x2]
    4d70:	7100041f 	cmp	w0, #0x1
    4d74:	540000c1 	b.ne	4d8c <fwp_caps50+0xac>  // b.any
    4d78:	aa1303e0 	mov	x0, x19
    4d7c:	f9400bf3 	ldr	x19, [sp, #16]
    4d80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4d84:	17fff90b 	b	31b0 <fwp_mem_free>
    4d88:	34fffbe1 	cbz	w1, 4d04 <fwp_caps50+0x24>
    4d8c:	f9400bf3 	ldr	x19, [sp, #16]
    4d90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4d94:	d65f03c0 	ret
    4d98:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    4d9c:	9114c042 	add	x2, x2, #0x530
    4da0:	f949d843 	ldr	x3, [x2, #5040]
    4da4:	f949ec41 	ldr	x1, [x2, #5080]
    4da8:	cb030000 	sub	x0, x0, x3
    4dac:	eb01401f 	cmp	x0, x1, lsl #16
    4db0:	54fffee2 	b.cs	4d8c <fwp_caps50+0xac>  // b.hs, b.nlast
    4db4:	d350fc01 	lsr	x1, x0, #16
    4db8:	f949fc44 	ldr	x4, [x2, #5112]
    4dbc:	8b010821 	add	x1, x1, x1, lsl #2
    4dc0:	d37df021 	lsl	x1, x1, #3
    4dc4:	8b010083 	add	x3, x4, x1
    4dc8:	f9401062 	ldr	x2, [x3, #32]
    4dcc:	b4fffe02 	cbz	x2, 4d8c <fwp_caps50+0xac>
    4dd0:	38616881 	ldrb	w1, [x4, x1]
    4dd4:	7100083f 	cmp	w1, #0x2
    4dd8:	54000300 	b.eq	4e38 <fwp_caps50+0x158>  // b.none
    4ddc:	7100043f 	cmp	w1, #0x1
    4de0:	54fffd61 	b.ne	4d8c <fwp_caps50+0xac>  // b.any
    4de4:	92403c01 	and	x1, x0, #0xffff
    4de8:	29430064 	ldp	w4, w0, [x3, #24]
    4dec:	9b047c21 	mul	x1, x1, x4
    4df0:	d360fc21 	lsr	x1, x1, #32
    4df4:	eb00003f 	cmp	x1, x0
    4df8:	54fffca2 	b.cs	4d8c <fwp_caps50+0xac>  // b.hs, b.nlast
    4dfc:	8b010042 	add	x2, x2, x1
    4e00:	39400040 	ldrb	w0, [x2]
    4e04:	34fffc40 	cbz	w0, 4d8c <fwp_caps50+0xac>
    4e08:	900000e1 	adrp	x1, 20000 <__data_start>
    4e0c:	91014021 	add	x1, x1, #0x50
    4e10:	b9404023 	ldr	w3, [x1, #64]
    4e14:	35000183 	cbnz	w3, 4e44 <fwp_caps50+0x164>
    4e18:	7103f41f 	cmp	w0, #0xfd
    4e1c:	540001c8 	b.hi	4e54 <fwp_caps50+0x174>  // b.pmore
    4e20:	11000400 	add	w0, w0, #0x1
    4e24:	39000040 	strb	w0, [x2]
    4e28:	17ffffd9 	b	4d8c <fwp_caps50+0xac>
    4e2c:	72003c1f 	tst	w0, #0xffff
    4e30:	54fffae1 	b.ne	4d8c <fwp_caps50+0xac>  // b.any
    4e34:	17ffffce 	b	4d6c <fwp_caps50+0x8c>
    4e38:	72003c1f 	tst	w0, #0xffff
    4e3c:	54fffa81 	b.ne	4d8c <fwp_caps50+0xac>  // b.any
    4e40:	17fffff0 	b	4e00 <fwp_caps50+0x120>
    4e44:	f9402423 	ldr	x3, [x1, #72]
    4e48:	91000463 	add	x3, x3, #0x1
    4e4c:	f9002423 	str	x3, [x1, #72]
    4e50:	17fffff2 	b	4e18 <fwp_caps50+0x138>
    4e54:	f9400bf3 	ldr	x19, [sp, #16]
    4e58:	aa0203e0 	mov	x0, x2
    4e5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4e60:	17fff7ed 	b	2e14 <fwp_rc_wide_dup>

0000000000004e64 <fwp_caps47>:
    4e64:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4e68:	910003fd 	mov	x29, sp
    4e6c:	f9000bf3 	str	x19, [sp, #16]
    4e70:	aa0003f3 	mov	x19, x0
    4e74:	b9400400 	ldr	w0, [x0, #4]
    4e78:	340004a0 	cbz	w0, 4f0c <fwp_caps47+0xa8>
    4e7c:	f9400660 	ldr	x0, [x19, #8]
    4e80:	350004e1 	cbnz	w1, 4f1c <fwp_caps47+0xb8>
    4e84:	97fffdab 	bl	4530 <fwp_drop4>
    4e88:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    4e8c:	9114c042 	add	x2, x2, #0x530
    4e90:	f949d840 	ldr	x0, [x2, #5040]
    4e94:	f949ec41 	ldr	x1, [x2, #5080]
    4e98:	cb000260 	sub	x0, x19, x0
    4e9c:	eb01401f 	cmp	x0, x1, lsl #16
    4ea0:	54000382 	b.cs	4f10 <fwp_caps47+0xac>  // b.hs, b.nlast
    4ea4:	d350fc01 	lsr	x1, x0, #16
    4ea8:	f949fc44 	ldr	x4, [x2, #5112]
    4eac:	8b010821 	add	x1, x1, x1, lsl #2
    4eb0:	d37df021 	lsl	x1, x1, #3
    4eb4:	8b010083 	add	x3, x4, x1
    4eb8:	f9401062 	ldr	x2, [x3, #32]
    4ebc:	b40002a2 	cbz	x2, 4f10 <fwp_caps47+0xac>
    4ec0:	38616881 	ldrb	w1, [x4, x1]
    4ec4:	7100083f 	cmp	w1, #0x2
    4ec8:	54000740 	b.eq	4fb0 <fwp_caps47+0x14c>  // b.none
    4ecc:	7100043f 	cmp	w1, #0x1
    4ed0:	54000201 	b.ne	4f10 <fwp_caps47+0xac>  // b.any
    4ed4:	29430464 	ldp	w4, w1, [x3, #24]
    4ed8:	92403c00 	and	x0, x0, #0xffff
    4edc:	9b047c00 	mul	x0, x0, x4
    4ee0:	d360fc00 	lsr	x0, x0, #32
    4ee4:	eb01001f 	cmp	x0, x1
    4ee8:	54000142 	b.cs	4f10 <fwp_caps47+0xac>  // b.hs, b.nlast
    4eec:	8b000042 	add	x2, x2, x0
    4ef0:	39400040 	ldrb	w0, [x2]
    4ef4:	7100041f 	cmp	w0, #0x1
    4ef8:	540000c1 	b.ne	4f10 <fwp_caps47+0xac>  // b.any
    4efc:	aa1303e0 	mov	x0, x19
    4f00:	f9400bf3 	ldr	x19, [sp, #16]
    4f04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4f08:	17fff8aa 	b	31b0 <fwp_mem_free>
    4f0c:	34fffbe1 	cbz	w1, 4e88 <fwp_caps47+0x24>
    4f10:	f9400bf3 	ldr	x19, [sp, #16]
    4f14:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4f18:	d65f03c0 	ret
    4f1c:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    4f20:	9114c042 	add	x2, x2, #0x530
    4f24:	f949d843 	ldr	x3, [x2, #5040]
    4f28:	f949ec41 	ldr	x1, [x2, #5080]
    4f2c:	cb030000 	sub	x0, x0, x3
    4f30:	eb01401f 	cmp	x0, x1, lsl #16
    4f34:	54fffee2 	b.cs	4f10 <fwp_caps47+0xac>  // b.hs, b.nlast
    4f38:	d350fc01 	lsr	x1, x0, #16
    4f3c:	f949fc44 	ldr	x4, [x2, #5112]
    4f40:	8b010821 	add	x1, x1, x1, lsl #2
    4f44:	d37df021 	lsl	x1, x1, #3
    4f48:	8b010083 	add	x3, x4, x1
    4f4c:	f9401062 	ldr	x2, [x3, #32]
    4f50:	b4fffe02 	cbz	x2, 4f10 <fwp_caps47+0xac>
    4f54:	38616881 	ldrb	w1, [x4, x1]
    4f58:	7100083f 	cmp	w1, #0x2
    4f5c:	54000300 	b.eq	4fbc <fwp_caps47+0x158>  // b.none
    4f60:	7100043f 	cmp	w1, #0x1
    4f64:	54fffd61 	b.ne	4f10 <fwp_caps47+0xac>  // b.any
    4f68:	92403c01 	and	x1, x0, #0xffff
    4f6c:	29430064 	ldp	w4, w0, [x3, #24]
    4f70:	9b047c21 	mul	x1, x1, x4
    4f74:	d360fc21 	lsr	x1, x1, #32
    4f78:	eb00003f 	cmp	x1, x0
    4f7c:	54fffca2 	b.cs	4f10 <fwp_caps47+0xac>  // b.hs, b.nlast
    4f80:	8b010042 	add	x2, x2, x1
    4f84:	39400040 	ldrb	w0, [x2]
    4f88:	34fffc40 	cbz	w0, 4f10 <fwp_caps47+0xac>
    4f8c:	900000e1 	adrp	x1, 20000 <__data_start>
    4f90:	91014021 	add	x1, x1, #0x50
    4f94:	b9404023 	ldr	w3, [x1, #64]
    4f98:	35000183 	cbnz	w3, 4fc8 <fwp_caps47+0x164>
    4f9c:	7103f41f 	cmp	w0, #0xfd
    4fa0:	540001c8 	b.hi	4fd8 <fwp_caps47+0x174>  // b.pmore
    4fa4:	11000400 	add	w0, w0, #0x1
    4fa8:	39000040 	strb	w0, [x2]
    4fac:	17ffffd9 	b	4f10 <fwp_caps47+0xac>
    4fb0:	72003c1f 	tst	w0, #0xffff
    4fb4:	54fffae1 	b.ne	4f10 <fwp_caps47+0xac>  // b.any
    4fb8:	17ffffce 	b	4ef0 <fwp_caps47+0x8c>
    4fbc:	72003c1f 	tst	w0, #0xffff
    4fc0:	54fffa81 	b.ne	4f10 <fwp_caps47+0xac>  // b.any
    4fc4:	17fffff0 	b	4f84 <fwp_caps47+0x120>
    4fc8:	f9402423 	ldr	x3, [x1, #72]
    4fcc:	91000463 	add	x3, x3, #0x1
    4fd0:	f9002423 	str	x3, [x1, #72]
    4fd4:	17fffff2 	b	4f9c <fwp_caps47+0x138>
    4fd8:	f9400bf3 	ldr	x19, [sp, #16]
    4fdc:	aa0203e0 	mov	x0, x2
    4fe0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4fe4:	17fff78c 	b	2e14 <fwp_rc_wide_dup>
    4fe8:	d503201f 	nop
    4fec:	d503201f 	nop

0000000000004ff0 <fwp_write>:
    4ff0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    4ff4:	910003fd 	mov	x29, sp
    4ff8:	f00000c4 	adrp	x4, 1f000 <__FRAME_END__+0x165f8>
    4ffc:	f947f484 	ldr	x4, [x4, #4072]
    5000:	a90153f3 	stp	x19, x20, [sp, #16]
    5004:	d10943ff 	sub	sp, sp, #0x250
    5008:	b9400045 	ldr	w5, [x2]
    500c:	aa0003f4 	mov	x20, x0
    5010:	f9400080 	ldr	x0, [x4]
    5014:	f90127e0 	str	x0, [sp, #584]
    5018:	d2800000 	mov	x0, #0x0                   	// #0
    501c:	710064bf 	cmp	w5, #0x19
    5020:	54000408 	b.hi	50a0 <fwp_write+0xb0>  // b.pmore
    5024:	d0000000 	adrp	x0, 7000 <__modti3+0x1a0>
    5028:	aa0103f3 	mov	x19, x1
    502c:	9121c000 	add	x0, x0, #0x870
    5030:	f9013bf5 	str	x21, [sp, #624]
    5034:	f9013ff6 	str	x22, [sp, #632]
    5038:	f90153fb 	str	x27, [sp, #672]
    503c:	f90157fc 	str	x28, [sp, #680]
    5040:	aa0203fc 	mov	x28, x2
    5044:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    5048:	10000061 	adr	x1, 5054 <fwp_write+0x64>
    504c:	8b20a820 	add	x0, x1, w0, sxth #2
    5050:	d61f0000 	br	x0
    5054:	910123e0 	add	x0, sp, #0x48
    5058:	aa1303e5 	mov	x5, x19
    505c:	d0000004 	adrp	x4, 7000 <__modti3+0x1a0>
    5060:	aa0003f3 	mov	x19, x0
    5064:	9116c084 	add	x4, x4, #0x5b0
    5068:	d2804003 	mov	x3, #0x200                 	// #512
    506c:	aa0303e1 	mov	x1, x3
    5070:	52800042 	mov	w2, #0x2                   	// #2
    5074:	97fff113 	bl	14c0 <__snprintf_chk@plt>
    5078:	aa1303e0 	mov	x0, x19
    507c:	97fff0d9 	bl	13e0 <strlen@plt>
    5080:	aa1303e1 	mov	x1, x19
    5084:	aa0003e2 	mov	x2, x0
    5088:	aa1403e0 	mov	x0, x20
    508c:	97fff441 	bl	2190 <buf_put>
    5090:	f9413bf5 	ldr	x21, [sp, #624]
    5094:	f9413ff6 	ldr	x22, [sp, #632]
    5098:	f94153fb 	ldr	x27, [sp, #672]
    509c:	f94157fc 	ldr	x28, [sp, #680]
    50a0:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    50a4:	f947f400 	ldr	x0, [x0, #4072]
    50a8:	f94127e2 	ldr	x2, [sp, #584]
    50ac:	f9400001 	ldr	x1, [x0]
    50b0:	eb010042 	subs	x2, x2, x1
    50b4:	d2800001 	mov	x1, #0x0                   	// #0
    50b8:	540077c1 	b.ne	5fb0 <fwp_write+0xfc0>  // b.any
    50bc:	910943ff 	add	sp, sp, #0x250
    50c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    50c4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    50c8:	d65f03c0 	ret
    50cc:	910123e0 	add	x0, sp, #0x48
    50d0:	aa1303e5 	mov	x5, x19
    50d4:	d0000004 	adrp	x4, 7000 <__modti3+0x1a0>
    50d8:	aa0003f3 	mov	x19, x0
    50dc:	9116a084 	add	x4, x4, #0x5a8
    50e0:	d2804003 	mov	x3, #0x200                 	// #512
    50e4:	17ffffe2 	b	506c <fwp_write+0x7c>
    50e8:	71004cbf 	cmp	w5, #0x13
    50ec:	d0000000 	adrp	x0, 7000 <__modti3+0x1a0>
    50f0:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    50f4:	91166000 	add	x0, x0, #0x598
    50f8:	91168021 	add	x1, x1, #0x5a0
    50fc:	d2800082 	mov	x2, #0x4                   	// #4
    5100:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    5104:	aa1403e0 	mov	x0, x20
    5108:	f90143f7 	str	x23, [sp, #640]
    510c:	d2800016 	mov	x22, #0x0                   	// #0
    5110:	f90147f8 	str	x24, [sp, #648]
    5114:	97fff41f 	bl	2190 <buf_put>
    5118:	f9400260 	ldr	x0, [x19]
    511c:	d0000017 	adrp	x23, 7000 <__modti3+0x1a0>
    5120:	d2800015 	mov	x21, #0x0                   	// #0
    5124:	911882f7 	add	x23, x23, #0x620
    5128:	b40047a0 	cbz	x0, 5a1c <fwp_write+0xa2c>
    512c:	b9400380 	ldr	w0, [x28]
    5130:	52800003 	mov	w3, #0x0                   	// #0
    5134:	f9401f82 	ldr	x2, [x28, #56]
    5138:	71004c1f 	cmp	w0, #0x13
    513c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    5140:	aa1403e0 	mov	x0, x20
    5144:	8b010e61 	add	x1, x19, x1, lsl #3
    5148:	f9400421 	ldr	x1, [x1, #8]
    514c:	97ffffa9 	bl	4ff0 <fwp_write>
    5150:	b9400380 	ldr	w0, [x28]
    5154:	7100481f 	cmp	w0, #0x12
    5158:	54004b40 	b.eq	5ac0 <fwp_write+0xad0>  // b.none
    515c:	f9400260 	ldr	x0, [x19]
    5160:	910006b5 	add	x21, x21, #0x1
    5164:	91000ad6 	add	x22, x22, #0x2
    5168:	eb15001f 	cmp	x0, x21
    516c:	54004589 	b.ls	5a1c <fwp_write+0xa2c>  // b.plast
    5170:	aa1703e1 	mov	x1, x23
    5174:	aa1403e0 	mov	x0, x20
    5178:	d2800042 	mov	x2, #0x2                   	// #2
    517c:	97fff405 	bl	2190 <buf_put>
    5180:	17ffffeb 	b	512c <fwp_write+0x13c>
    5184:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5188:	91176021 	add	x1, x1, #0x5d8
    518c:	d28000c2 	mov	x2, #0x6                   	// #6
    5190:	aa1403e0 	mov	x0, x20
    5194:	91004273 	add	x19, x19, #0x10
    5198:	97fff3fe 	bl	2190 <buf_put>
    519c:	aa1303e0 	mov	x0, x19
    51a0:	97fff090 	bl	13e0 <strlen@plt>
    51a4:	aa1303e1 	mov	x1, x19
    51a8:	aa0003e2 	mov	x2, x0
    51ac:	aa1403e0 	mov	x0, x20
    51b0:	97fff3f8 	bl	2190 <buf_put>
    51b4:	528007c3 	mov	w3, #0x3e                  	// #62
    51b8:	aa1403e0 	mov	x0, x20
    51bc:	91001fe1 	add	x1, sp, #0x7
    51c0:	d2800022 	mov	x2, #0x1                   	// #1
    51c4:	39001fe3 	strb	w3, [sp, #7]
    51c8:	17ffffb1 	b	508c <fwp_write+0x9c>
    51cc:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    51d0:	f947f400 	ldr	x0, [x0, #4072]
    51d4:	f94127e2 	ldr	x2, [sp, #584]
    51d8:	f9400001 	ldr	x1, [x0]
    51dc:	eb010042 	subs	x2, x2, x1
    51e0:	d2800001 	mov	x1, #0x0                   	// #0
    51e4:	540034e1 	b.ne	5880 <fwp_write+0x890>  // b.any
    51e8:	f9413bf5 	ldr	x21, [sp, #624]
    51ec:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    51f0:	f9413ff6 	ldr	x22, [sp, #632]
    51f4:	aa1403e0 	mov	x0, x20
    51f8:	9116e021 	add	x1, x1, #0x5b8
    51fc:	d2800142 	mov	x2, #0xa                   	// #10
    5200:	f94153fb 	ldr	x27, [sp, #672]
    5204:	f94157fc 	ldr	x28, [sp, #680]
    5208:	910943ff 	add	sp, sp, #0x250
    520c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5210:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5214:	17fff3df 	b	2190 <buf_put>
    5218:	f9400456 	ldr	x22, [x2, #8]
    521c:	f90143f7 	str	x23, [sp, #640]
    5220:	f90147f8 	str	x24, [sp, #648]
    5224:	b4005b16 	cbz	x22, 5d84 <fwp_write+0xd94>
    5228:	aa1603e0 	mov	x0, x22
    522c:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5230:	9118e021 	add	x1, x1, #0x638
    5234:	97fff0e7 	bl	15d0 <strcmp@plt>
    5238:	2a0003f5 	mov	w21, w0
    523c:	34005fe0 	cbz	w0, 5e38 <fwp_write+0xe48>
    5240:	aa1603e0 	mov	x0, x22
    5244:	97fff067 	bl	13e0 <strlen@plt>
    5248:	aa1603e1 	mov	x1, x22
    524c:	aa0003e2 	mov	x2, x0
    5250:	aa1403e0 	mov	x0, x20
    5254:	97fff3cf 	bl	2190 <buf_put>
    5258:	52800403 	mov	w3, #0x20                  	// #32
    525c:	91001ff5 	add	x21, sp, #0x7
    5260:	aa1503e1 	mov	x1, x21
    5264:	aa1403e0 	mov	x0, x20
    5268:	d2800022 	mov	x2, #0x1                   	// #1
    526c:	39001fe3 	strb	w3, [sp, #7]
    5270:	97fff3c8 	bl	2190 <buf_put>
    5274:	52800f63 	mov	w3, #0x7b                  	// #123
    5278:	aa1403e0 	mov	x0, x20
    527c:	aa1503e1 	mov	x1, x21
    5280:	d2800022 	mov	x2, #0x1                   	// #1
    5284:	39001fe3 	strb	w3, [sp, #7]
    5288:	97fff3c2 	bl	2190 <buf_put>
    528c:	b9401380 	ldr	w0, [x28, #16]
    5290:	52800018 	mov	w24, #0x0                   	// #0
    5294:	7100001f 	cmp	w0, #0x0
    5298:	54003aad 	b.le	59ec <fwp_write+0x9fc>
    529c:	f9014bf9 	str	x25, [sp, #656]
    52a0:	d0000019 	adrp	x25, 7000 <__modti3+0x1a0>
    52a4:	91198339 	add	x25, x25, #0x660
    52a8:	f9014ffa 	str	x26, [sp, #664]
    52ac:	d000001a 	adrp	x26, 7000 <__modti3+0x1a0>
    52b0:	9118835a 	add	x26, x26, #0x620
    52b4:	91002276 	add	x22, x19, #0x8
    52b8:	d2800013 	mov	x19, #0x0                   	// #0
    52bc:	b5003e93 	cbnz	x19, 5a8c <fwp_write+0xa9c>
    52c0:	d37df277 	lsl	x23, x19, #3
    52c4:	34003cb8 	cbz	w24, 5a58 <fwp_write+0xa68>
    52c8:	f9401382 	ldr	x2, [x28, #32]
    52cc:	aa1403e0 	mov	x0, x20
    52d0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    52d4:	52800003 	mov	w3, #0x0                   	// #0
    52d8:	f8776842 	ldr	x2, [x2, x23]
    52dc:	91000673 	add	x19, x19, #0x1
    52e0:	97ffff44 	bl	4ff0 <fwp_write>
    52e4:	b9401380 	ldr	w0, [x28, #16]
    52e8:	6b13001f 	cmp	w0, w19
    52ec:	54fffe8c 	b.gt	52bc <fwp_write+0x2cc>
    52f0:	f9414bf9 	ldr	x25, [sp, #656]
    52f4:	f9414ffa 	ldr	x26, [sp, #664]
    52f8:	340037b8 	cbz	w24, 59ec <fwp_write+0x9fc>
    52fc:	52800523 	mov	w3, #0x29                  	// #41
    5300:	aa1503e1 	mov	x1, x21
    5304:	aa1403e0 	mov	x0, x20
    5308:	d2800022 	mov	x2, #0x1                   	// #1
    530c:	39001fe3 	strb	w3, [sp, #7]
    5310:	97fff3a0 	bl	2190 <buf_put>
    5314:	f9413bf5 	ldr	x21, [sp, #624]
    5318:	f9413ff6 	ldr	x22, [sp, #632]
    531c:	f94143f7 	ldr	x23, [sp, #640]
    5320:	f94147f8 	ldr	x24, [sp, #648]
    5324:	f94153fb 	ldr	x27, [sp, #672]
    5328:	f94157fc 	ldr	x28, [sp, #680]
    532c:	17ffff5d 	b	50a0 <fwp_write+0xb0>
    5330:	b9404855 	ldr	w21, [x2, #72]
    5334:	aa1403e0 	mov	x0, x20
    5338:	93407eb6 	sxtw	x22, w21
    533c:	91000ac1 	add	x1, x22, #0x2
    5340:	97fff360 	bl	20c0 <buf_grow>
    5344:	a9400281 	ldp	x1, x0, [x20]
    5348:	528e8603 	mov	w3, #0x7430                	// #29744
    534c:	78206823 	strh	w3, [x1, x0]
    5350:	8b000022 	add	x2, x1, x0
    5354:	710002bf 	cmp	w21, #0x0
    5358:	540036cd 	b.le	5a30 <fwp_write+0xa40>
    535c:	110006a3 	add	w3, w21, #0x1
    5360:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    5364:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    5368:	91000449 	add	x9, x2, #0x1
    536c:	8b23c043 	add	x3, x2, w3, sxtw
    5370:	f28aaac6 	movk	x6, #0x5556
    5374:	f2955568 	movk	x8, #0xaaab
    5378:	1400000d 	b	53ac <fwp_write+0x3bc>
    537c:	d2800021 	mov	x1, #0x1                   	// #1
    5380:	528005a5 	mov	w5, #0x2d                  	// #45
    5384:	f100001f 	cmp	x0, #0x0
    5388:	9b467e60 	smulh	x0, x19, x6
    538c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    5390:	381ff465 	strb	w5, [x3], #-1
    5394:	cb040000 	sub	x0, x0, x4
    5398:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    539c:	cb020000 	sub	x0, x0, x2
    53a0:	8b010013 	add	x19, x0, x1
    53a4:	eb03013f 	cmp	x9, x3
    53a8:	54003440 	b.eq	5a30 <fwp_write+0xa40>  // b.none
    53ac:	9b467e60 	smulh	x0, x19, x6
    53b0:	937ffe64 	asr	x4, x19, #63
    53b4:	52800605 	mov	w5, #0x30                  	// #48
    53b8:	cb040000 	sub	x0, x0, x4
    53bc:	8b000400 	add	x0, x0, x0, lsl #1
    53c0:	cb000260 	sub	x0, x19, x0
    53c4:	91000c01 	add	x1, x0, #0x3
    53c8:	9bc87c22 	umulh	x2, x1, x8
    53cc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    53d0:	8b4204e2 	add	x2, x7, x2, lsr #1
    53d4:	eb020021 	subs	x1, x1, x2
    53d8:	54fffd60 	b.eq	5384 <fwp_write+0x394>  // b.none
    53dc:	f100043f 	cmp	x1, #0x1
    53e0:	54fffce1 	b.ne	537c <fwp_write+0x38c>  // b.any
    53e4:	d2800001 	mov	x1, #0x0                   	// #0
    53e8:	52800565 	mov	w5, #0x2b                  	// #43
    53ec:	17ffffe6 	b	5384 <fwp_write+0x394>
    53f0:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    53f4:	f947f400 	ldr	x0, [x0, #4072]
    53f8:	f94127e2 	ldr	x2, [sp, #584]
    53fc:	f9400001 	ldr	x1, [x0]
    5400:	eb010042 	subs	x2, x2, x1
    5404:	d2800001 	mov	x1, #0x0                   	// #0
    5408:	540023c1 	b.ne	5880 <fwp_write+0x890>  // b.any
    540c:	f9413bf5 	ldr	x21, [sp, #624]
    5410:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5414:	f9413ff6 	ldr	x22, [sp, #632]
    5418:	aa1403e0 	mov	x0, x20
    541c:	91172021 	add	x1, x1, #0x5c8
    5420:	d2800102 	mov	x2, #0x8                   	// #8
    5424:	17ffff77 	b	5200 <fwp_write+0x210>
    5428:	aa1403e0 	mov	x0, x20
    542c:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5430:	d28000c2 	mov	x2, #0x6                   	// #6
    5434:	9118a021 	add	x1, x1, #0x628
    5438:	97fff356 	bl	2190 <buf_put>
    543c:	d2800015 	mov	x21, #0x0                   	// #0
    5440:	f9400263 	ldr	x3, [x19]
    5444:	f240f87f 	tst	x3, #0x7fffffffffffffff
    5448:	54002c60 	b.eq	59d4 <fwp_write+0x9e4>  // b.none
    544c:	f9401f82 	ldr	x2, [x28, #56]
    5450:	f90143f7 	str	x23, [sp, #640]
    5454:	f90147f8 	str	x24, [sp, #648]
    5458:	d2800857 	mov	x23, #0x42                  	// #66
    545c:	f9014bf9 	str	x25, [sp, #656]
    5460:	d0000016 	adrp	x22, 7000 <__modti3+0x1a0>
    5464:	f9014ffa 	str	x26, [sp, #664]
    5468:	911882d6 	add	x22, x22, #0x620
    546c:	d2800038 	mov	x24, #0x1                   	// #1
    5470:	f2a18017 	movk	x23, #0xc00, lsl #16
    5474:	d2809099 	mov	x25, #0x484                 	// #1156
    5478:	b40004a2 	cbz	x2, 550c <fwp_write+0x51c>
    547c:	b9400040 	ldr	w0, [x2]
    5480:	7100701f 	cmp	w0, #0x1c
    5484:	540042c0 	b.eq	5cdc <fwp_write+0xcec>  // b.none
    5488:	71006c1f 	cmp	w0, #0x1b
    548c:	54000408 	b.hi	550c <fwp_write+0x51c>  // b.pmore
    5490:	9ac02301 	lsl	x1, x24, x0
    5494:	ea17003f 	tst	x1, x23
    5498:	540036a1 	b.ne	5b6c <fwp_write+0xb7c>  // b.any
    549c:	ea19003f 	tst	x1, x25
    54a0:	54003521 	b.ne	5b44 <fwp_write+0xb54>  // b.any
    54a4:	d2800424 	mov	x4, #0x21                  	// #33
    54a8:	ea04003f 	tst	x1, x4
    54ac:	54000300 	b.eq	550c <fwp_write+0x51c>  // b.none
    54b0:	b7f849c3 	tbnz	x3, #63, 5de8 <fwp_write+0xdf8>
    54b4:	91002261 	add	x1, x19, #0x8
    54b8:	8b150021 	add	x1, x1, x21
    54bc:	39400021 	ldrb	w1, [x1]
    54c0:	7100001f 	cmp	w0, #0x0
    54c4:	93401c23 	sxtb	x3, w1
    54c8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    54cc:	d503201f 	nop
    54d0:	aa1403e0 	mov	x0, x20
    54d4:	52800003 	mov	w3, #0x0                   	// #0
    54d8:	97fffec6 	bl	4ff0 <fwp_write>
    54dc:	910006b5 	add	x21, x21, #0x1
    54e0:	f9400260 	ldr	x0, [x19]
    54e4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    54e8:	eb0002bf 	cmp	x21, x0
    54ec:	540026c2 	b.cs	59c4 <fwp_write+0x9d4>  // b.hs, b.nlast
    54f0:	d2800042 	mov	x2, #0x2                   	// #2
    54f4:	aa1603e1 	mov	x1, x22
    54f8:	aa1403e0 	mov	x0, x20
    54fc:	97fff325 	bl	2190 <buf_put>
    5500:	f9401f82 	ldr	x2, [x28, #56]
    5504:	f9400263 	ldr	x3, [x19]
    5508:	b5fffba2 	cbnz	x2, 547c <fwp_write+0x48c>
    550c:	d37df2a0 	lsl	x0, x21, #3
    5510:	b7f83f03 	tbnz	x3, #63, 5cf0 <fwp_write+0xd00>
    5514:	91002261 	add	x1, x19, #0x8
    5518:	8b000020 	add	x0, x1, x0
    551c:	f9400001 	ldr	x1, [x0]
    5520:	17ffffec 	b	54d0 <fwp_write+0x4e0>
    5524:	a9400e62 	ldp	x2, x3, [x19]
    5528:	b7f83ca3 	tbnz	x3, #63, 5cbc <fwp_write+0xccc>
    552c:	910123f5 	add	x21, sp, #0x48
    5530:	aa1503e0 	mov	x0, x21
    5534:	97fff15b 	bl	1aa0 <fwp_fmt_u128>
    5538:	aa1503e0 	mov	x0, x21
    553c:	97ffefa9 	bl	13e0 <strlen@plt>
    5540:	aa1503e1 	mov	x1, x21
    5544:	aa0003e2 	mov	x2, x0
    5548:	17fffed0 	b	5088 <fwp_write+0x98>
    554c:	fd015be8 	str	d8, [sp, #688]
    5550:	1e270268 	fmov	s8, w19
    5554:	fd015fe9 	str	d9, [sp, #696]
    5558:	1e282100 	fcmp	s8, s8
    555c:	54004d26 	b.vs	5f00 <fwp_write+0xf10>
    5560:	1e20c101 	fabs	s1, s8
    5564:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    5568:	1e270000 	fmov	s0, w0
    556c:	1e202020 	fcmp	s1, s0
    5570:	54002c0d 	b.le	5af0 <fwp_write+0xb00>
    5574:	1e202118 	fcmpe	s8, #0.0
    5578:	d0000002 	adrp	x2, 7000 <__modti3+0x1a0>
    557c:	910c4042 	add	x2, x2, #0x310
    5580:	910123f5 	add	x21, sp, #0x48
    5584:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5588:	9115e021 	add	x1, x1, #0x578
    558c:	aa1503e0 	mov	x0, x21
    5590:	9a81c041 	csel	x1, x2, x1, gt
    5594:	97fff03f 	bl	1690 <strcpy@plt>
    5598:	aa1503e0 	mov	x0, x21
    559c:	97ffef91 	bl	13e0 <strlen@plt>
    55a0:	aa1503e1 	mov	x1, x21
    55a4:	aa0003e2 	mov	x2, x0
    55a8:	aa1403e0 	mov	x0, x20
    55ac:	97fff2f9 	bl	2190 <buf_put>
    55b0:	f9413bf5 	ldr	x21, [sp, #624]
    55b4:	f9413ff6 	ldr	x22, [sp, #632]
    55b8:	f94153fb 	ldr	x27, [sp, #672]
    55bc:	f94157fc 	ldr	x28, [sp, #680]
    55c0:	fd415be8 	ldr	d8, [sp, #688]
    55c4:	fd415fe9 	ldr	d9, [sp, #696]
    55c8:	17fffeb6 	b	50a0 <fwp_write+0xb0>
    55cc:	f9400276 	ldr	x22, [x19]
    55d0:	34002e03 	cbz	w3, 5b90 <fwp_write+0xba0>
    55d4:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    55d8:	f947f400 	ldr	x0, [x0, #4072]
    55dc:	f94127e2 	ldr	x2, [sp, #584]
    55e0:	f9400001 	ldr	x1, [x0]
    55e4:	eb010042 	subs	x2, x2, x1
    55e8:	d2800001 	mov	x1, #0x0                   	// #0
    55ec:	540014a1 	b.ne	5880 <fwp_write+0x890>  // b.any
    55f0:	aa1603e2 	mov	x2, x22
    55f4:	91002261 	add	x1, x19, #0x8
    55f8:	f9413bf5 	ldr	x21, [sp, #624]
    55fc:	aa1403e0 	mov	x0, x20
    5600:	f9413ff6 	ldr	x22, [sp, #632]
    5604:	17fffeff 	b	5200 <fwp_write+0x210>
    5608:	fd015be8 	str	d8, [sp, #688]
    560c:	9e670268 	fmov	d8, x19
    5610:	fd015fe9 	str	d9, [sp, #696]
    5614:	1e682100 	fcmp	d8, d8
    5618:	54004746 	b.vs	5f00 <fwp_write+0xf10>
    561c:	1e60c101 	fabs	d1, d8
    5620:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    5624:	9e670000 	fmov	d0, x0
    5628:	910123f5 	add	x21, sp, #0x48
    562c:	52800033 	mov	w19, #0x1                   	// #1
    5630:	1e602020 	fcmp	d1, d0
    5634:	540001ad 	b.le	5668 <fwp_write+0x678>
    5638:	1e602118 	fcmpe	d8, #0.0
    563c:	d0000002 	adrp	x2, 7000 <__modti3+0x1a0>
    5640:	910c4042 	add	x2, x2, #0x310
    5644:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5648:	9115e021 	add	x1, x1, #0x578
    564c:	aa1503e0 	mov	x0, x21
    5650:	9a81c041 	csel	x1, x2, x1, gt
    5654:	97fff00f 	bl	1690 <strcpy@plt>
    5658:	17ffffd0 	b	5598 <fwp_write+0x5a8>
    565c:	11000673 	add	w19, w19, #0x1
    5660:	71004a7f 	cmp	w19, #0x12
    5664:	54003860 	b.eq	5d70 <fwp_write+0xd80>  // b.none
    5668:	1e604100 	fmov	d0, d8
    566c:	2a1303e1 	mov	w1, w19
    5670:	aa1503e0 	mov	x0, x21
    5674:	97fff35c 	bl	23e4 <fwp_format_g.constprop.0>
    5678:	aa1503e0 	mov	x0, x21
    567c:	d2800001 	mov	x1, #0x0                   	// #0
    5680:	97ffef6c 	bl	1430 <strtod@plt>
    5684:	1e602100 	fcmp	d8, d0
    5688:	54fffea1 	b.ne	565c <fwp_write+0x66c>  // b.any
    568c:	aa1503e0 	mov	x0, x21
    5690:	97fff2f9 	bl	2274 <fwp_finish_float>
    5694:	17ffffc1 	b	5598 <fwp_write+0x5a8>
    5698:	a9400e62 	ldp	x2, x3, [x19]
    569c:	910123f3 	add	x19, sp, #0x48
    56a0:	aa1303e0 	mov	x0, x19
    56a4:	97fff0ff 	bl	1aa0 <fwp_fmt_u128>
    56a8:	17fffe74 	b	5078 <fwp_write+0x88>
    56ac:	f90143f7 	str	x23, [sp, #640]
    56b0:	f90147f8 	str	x24, [sp, #648]
    56b4:	2a1303f8 	mov	w24, w19
    56b8:	f9014bf9 	str	x25, [sp, #656]
    56bc:	f9014ffa 	str	x26, [sp, #664]
    56c0:	f13ffe7f 	cmp	x19, #0xfff
    56c4:	54000049 	b.ls	56cc <fwp_write+0x6dc>  // b.plast
    56c8:	b9400278 	ldr	w24, [x19]
    56cc:	f9400f80 	ldr	x0, [x28, #24]
    56d0:	2a1803f5 	mov	w21, w24
    56d4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    56d8:	d37ef6b9 	lsl	x25, x21, #2
    56dc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    56e0:	aa1603e0 	mov	x0, x22
    56e4:	97ffef3f 	bl	13e0 <strlen@plt>
    56e8:	aa1603e1 	mov	x1, x22
    56ec:	aa0003e2 	mov	x2, x0
    56f0:	aa1403e0 	mov	x0, x20
    56f4:	97fff2a7 	bl	2190 <buf_put>
    56f8:	f9401780 	ldr	x0, [x28, #40]
    56fc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    5700:	7100001f 	cmp	w0, #0x0
    5704:	5400068d 	b.le	57d4 <fwp_write+0x7e4>
    5708:	91002276 	add	x22, x19, #0x8
    570c:	91001ff5 	add	x21, sp, #0x7
    5710:	d280001b 	mov	x27, #0x0                   	// #0
    5714:	5280041a 	mov	w26, #0x20                  	// #32
    5718:	f9401b80 	ldr	x0, [x28, #48]
    571c:	aa1503e1 	mov	x1, x21
    5720:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    5724:	d2800022 	mov	x2, #0x1                   	// #1
    5728:	f8786803 	ldr	x3, [x0, x24]
    572c:	aa1403e0 	mov	x0, x20
    5730:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    5734:	39001ffa 	strb	w26, [sp, #7]
    5738:	97fff296 	bl	2190 <buf_put>
    573c:	f13ffeff 	cmp	x23, #0xfff
    5740:	b9400261 	ldr	w1, [x19]
    5744:	1a9f97e0 	cset	w0, hi	// hi = pmore
    5748:	7100383f 	cmp	w1, #0xe
    574c:	54000160 	b.eq	5778 <fwp_write+0x788>  // b.none
    5750:	7100403f 	cmp	w1, #0x10
    5754:	54001a60 	b.eq	5aa0 <fwp_write+0xab0>  // b.none
    5758:	7100283f 	cmp	w1, #0xa
    575c:	54002aa0 	b.eq	5cb0 <fwp_write+0xcc0>  // b.none
    5760:	540014ac 	b.gt	59f4 <fwp_write+0xa04>
    5764:	71000c3f 	cmp	w1, #0x3
    5768:	540029ac 	b.gt	5c9c <fwp_write+0xcac>
    576c:	d37ffee0 	lsr	x0, x23, #63
    5770:	37f814a1 	tbnz	w1, #31, 5a04 <fwp_write+0xa14>
    5774:	d503201f 	nop
    5778:	34001460 	cbz	w0, 5a04 <fwp_write+0xa14>
    577c:	52800503 	mov	w3, #0x28                  	// #40
    5780:	aa1503e1 	mov	x1, x21
    5784:	aa1403e0 	mov	x0, x20
    5788:	d2800022 	mov	x2, #0x1                   	// #1
    578c:	39001fe3 	strb	w3, [sp, #7]
    5790:	97fff280 	bl	2190 <buf_put>
    5794:	aa1303e2 	mov	x2, x19
    5798:	aa1703e1 	mov	x1, x23
    579c:	aa1403e0 	mov	x0, x20
    57a0:	52800003 	mov	w3, #0x0                   	// #0
    57a4:	97fffe13 	bl	4ff0 <fwp_write>
    57a8:	52800523 	mov	w3, #0x29                  	// #41
    57ac:	aa1503e1 	mov	x1, x21
    57b0:	aa1403e0 	mov	x0, x20
    57b4:	d2800022 	mov	x2, #0x1                   	// #1
    57b8:	39001fe3 	strb	w3, [sp, #7]
    57bc:	97fff275 	bl	2190 <buf_put>
    57c0:	f9401780 	ldr	x0, [x28, #40]
    57c4:	9100077b 	add	x27, x27, #0x1
    57c8:	b8796800 	ldr	w0, [x0, x25]
    57cc:	6b1b001f 	cmp	w0, w27
    57d0:	54fffa4c 	b.gt	5718 <fwp_write+0x728>
    57d4:	f9413bf5 	ldr	x21, [sp, #624]
    57d8:	f9413ff6 	ldr	x22, [sp, #632]
    57dc:	f94143f7 	ldr	x23, [sp, #640]
    57e0:	f94147f8 	ldr	x24, [sp, #648]
    57e4:	f9414bf9 	ldr	x25, [sp, #656]
    57e8:	f9414ffa 	ldr	x26, [sp, #664]
    57ec:	f94153fb 	ldr	x27, [sp, #672]
    57f0:	f94157fc 	ldr	x28, [sp, #680]
    57f4:	17fffe2b 	b	50a0 <fwp_write+0xb0>
    57f8:	52800783 	mov	w3, #0x3c                  	// #60
    57fc:	91001ff3 	add	x19, sp, #0x7
    5800:	aa1303e1 	mov	x1, x19
    5804:	d2800022 	mov	x2, #0x1                   	// #1
    5808:	aa1403e0 	mov	x0, x20
    580c:	39001fe3 	strb	w3, [sp, #7]
    5810:	97fff260 	bl	2190 <buf_put>
    5814:	f9400795 	ldr	x21, [x28, #8]
    5818:	aa1503e0 	mov	x0, x21
    581c:	97ffeef1 	bl	13e0 <strlen@plt>
    5820:	aa1503e1 	mov	x1, x21
    5824:	aa0003e2 	mov	x2, x0
    5828:	aa1403e0 	mov	x0, x20
    582c:	97fff259 	bl	2190 <buf_put>
    5830:	528007c3 	mov	w3, #0x3e                  	// #62
    5834:	aa1303e1 	mov	x1, x19
    5838:	aa1403e0 	mov	x0, x20
    583c:	d2800022 	mov	x2, #0x1                   	// #1
    5840:	39001fe3 	strb	w3, [sp, #7]
    5844:	17fffe12 	b	508c <fwp_write+0x9c>
    5848:	f100067f 	cmp	x19, #0x1
    584c:	540025a0 	b.eq	5d00 <fwp_write+0xd10>  // b.none
    5850:	b100067f 	cmn	x19, #0x1
    5854:	54002bc0 	b.eq	5dcc <fwp_write+0xddc>  // b.none
    5858:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    585c:	91160021 	add	x1, x1, #0x580
    5860:	d2800022 	mov	x2, #0x1                   	// #1
    5864:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    5868:	f947f400 	ldr	x0, [x0, #4072]
    586c:	f94127e4 	ldr	x4, [sp, #584]
    5870:	f9400003 	ldr	x3, [x0]
    5874:	eb030084 	subs	x4, x4, x3
    5878:	d2800003 	mov	x3, #0x0                   	// #0
    587c:	54ffebe0 	b.eq	55f8 <fwp_write+0x608>  // b.none
    5880:	f90143f7 	str	x23, [sp, #640]
    5884:	f90147f8 	str	x24, [sp, #648]
    5888:	f9014bf9 	str	x25, [sp, #656]
    588c:	f9014ffa 	str	x26, [sp, #664]
    5890:	fd015be8 	str	d8, [sp, #688]
    5894:	fd015fe9 	str	d9, [sp, #696]
    5898:	97ffef2e 	bl	1550 <__stack_chk_fail@plt>
    589c:	52800b63 	mov	w3, #0x5b                  	// #91
    58a0:	91001ff5 	add	x21, sp, #0x7
    58a4:	aa1503e1 	mov	x1, x21
    58a8:	aa1403e0 	mov	x0, x20
    58ac:	d2800022 	mov	x2, #0x1                   	// #1
    58b0:	d0000016 	adrp	x22, 7000 <__modti3+0x1a0>
    58b4:	911882d6 	add	x22, x22, #0x620
    58b8:	39001fe3 	strb	w3, [sp, #7]
    58bc:	97fff235 	bl	2190 <buf_put>
    58c0:	b4000273 	cbz	x19, 590c <fwp_write+0x91c>
    58c4:	f9400661 	ldr	x1, [x19, #8]
    58c8:	aa1403e0 	mov	x0, x20
    58cc:	f9401f82 	ldr	x2, [x28, #56]
    58d0:	52800003 	mov	w3, #0x0                   	// #0
    58d4:	97fffdc7 	bl	4ff0 <fwp_write>
    58d8:	f9400a73 	ldr	x19, [x19, #16]
    58dc:	b4000193 	cbz	x19, 590c <fwp_write+0x91c>
    58e0:	aa1603e1 	mov	x1, x22
    58e4:	aa1403e0 	mov	x0, x20
    58e8:	d2800042 	mov	x2, #0x2                   	// #2
    58ec:	97fff229 	bl	2190 <buf_put>
    58f0:	f9400661 	ldr	x1, [x19, #8]
    58f4:	aa1403e0 	mov	x0, x20
    58f8:	f9401f82 	ldr	x2, [x28, #56]
    58fc:	52800003 	mov	w3, #0x0                   	// #0
    5900:	97fffdbc 	bl	4ff0 <fwp_write>
    5904:	f9400a73 	ldr	x19, [x19, #16]
    5908:	b5fffed3 	cbnz	x19, 58e0 <fwp_write+0x8f0>
    590c:	52800ba3 	mov	w3, #0x5d                  	// #93
    5910:	aa1503e1 	mov	x1, x21
    5914:	aa1403e0 	mov	x0, x20
    5918:	d2800022 	mov	x2, #0x1                   	// #1
    591c:	39001fe3 	strb	w3, [sp, #7]
    5920:	17fffddb 	b	508c <fwp_write+0x9c>
    5924:	aa1403e0 	mov	x0, x20
    5928:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    592c:	d28000c2 	mov	x2, #0x6                   	// #6
    5930:	91184021 	add	x1, x1, #0x610
    5934:	97fff217 	bl	2190 <buf_put>
    5938:	f9400260 	ldr	x0, [x19]
    593c:	b40004c0 	cbz	x0, 59d4 <fwp_write+0x9e4>
    5940:	910123f5 	add	x21, sp, #0x48
    5944:	91002276 	add	x22, x19, #0x8
    5948:	f90143f7 	str	x23, [sp, #640]
    594c:	d2800017 	mov	x23, #0x0                   	// #0
    5950:	f90147f8 	str	x24, [sp, #648]
    5954:	d0000018 	adrp	x24, 7000 <__modti3+0x1a0>
    5958:	91186318 	add	x24, x24, #0x618
    595c:	f9014bf9 	str	x25, [sp, #656]
    5960:	d0000019 	adrp	x25, 7000 <__modti3+0x1a0>
    5964:	91188339 	add	x25, x25, #0x620
    5968:	f9014ffa 	str	x26, [sp, #664]
    596c:	14000005 	b	5980 <fwp_write+0x990>
    5970:	aa1903e1 	mov	x1, x25
    5974:	aa1403e0 	mov	x0, x20
    5978:	d2800042 	mov	x2, #0x2                   	// #2
    597c:	97fff205 	bl	2190 <buf_put>
    5980:	38776ac5 	ldrb	w5, [x22, x23]
    5984:	d2804003 	mov	x3, #0x200                 	// #512
    5988:	aa1803e4 	mov	x4, x24
    598c:	aa0303e1 	mov	x1, x3
    5990:	52800042 	mov	w2, #0x2                   	// #2
    5994:	aa1503e0 	mov	x0, x21
    5998:	910006f7 	add	x23, x23, #0x1
    599c:	97ffeec9 	bl	14c0 <__snprintf_chk@plt>
    59a0:	aa1503e0 	mov	x0, x21
    59a4:	97ffee8f 	bl	13e0 <strlen@plt>
    59a8:	aa1503e1 	mov	x1, x21
    59ac:	aa0003e2 	mov	x2, x0
    59b0:	aa1403e0 	mov	x0, x20
    59b4:	97fff1f7 	bl	2190 <buf_put>
    59b8:	f9400260 	ldr	x0, [x19]
    59bc:	eb17001f 	cmp	x0, x23
    59c0:	54fffd88 	b.hi	5970 <fwp_write+0x980>  // b.pmore
    59c4:	f94143f7 	ldr	x23, [sp, #640]
    59c8:	f94147f8 	ldr	x24, [sp, #648]
    59cc:	f9414bf9 	ldr	x25, [sp, #656]
    59d0:	f9414ffa 	ldr	x26, [sp, #664]
    59d4:	52800ba3 	mov	w3, #0x5d                  	// #93
    59d8:	aa1403e0 	mov	x0, x20
    59dc:	91001fe1 	add	x1, sp, #0x7
    59e0:	d2800022 	mov	x2, #0x1                   	// #1
    59e4:	39001fe3 	strb	w3, [sp, #7]
    59e8:	17fffda9 	b	508c <fwp_write+0x9c>
    59ec:	52800fa3 	mov	w3, #0x7d                  	// #125
    59f0:	17fffe44 	b	5300 <fwp_write+0x310>
    59f4:	f10002ff 	cmp	x23, #0x0
    59f8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    59fc:	71002c3f 	cmp	w1, #0xb
    5a00:	54ffebc0 	b.eq	5778 <fwp_write+0x788>  // b.none
    5a04:	aa1303e2 	mov	x2, x19
    5a08:	aa1703e1 	mov	x1, x23
    5a0c:	aa1403e0 	mov	x0, x20
    5a10:	52800003 	mov	w3, #0x0                   	// #0
    5a14:	97fffd77 	bl	4ff0 <fwp_write>
    5a18:	17ffff6a 	b	57c0 <fwp_write+0x7d0>
    5a1c:	aa1403e0 	mov	x0, x20
    5a20:	91001fe1 	add	x1, sp, #0x7
    5a24:	52800fa3 	mov	w3, #0x7d                  	// #125
    5a28:	d2800022 	mov	x2, #0x1                   	// #1
    5a2c:	17fffe38 	b	530c <fwp_write+0x31c>
    5a30:	a9400281 	ldp	x1, x0, [x20]
    5a34:	91000800 	add	x0, x0, #0x2
    5a38:	8b160000 	add	x0, x0, x22
    5a3c:	f9000680 	str	x0, [x20, #8]
    5a40:	3820683f 	strb	wzr, [x1, x0]
    5a44:	f9413bf5 	ldr	x21, [sp, #624]
    5a48:	f9413ff6 	ldr	x22, [sp, #632]
    5a4c:	f94153fb 	ldr	x27, [sp, #672]
    5a50:	f94157fc 	ldr	x28, [sp, #680]
    5a54:	17fffd93 	b	50a0 <fwp_write+0xb0>
    5a58:	f9400f80 	ldr	x0, [x28, #24]
    5a5c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    5a60:	aa1b03e0 	mov	x0, x27
    5a64:	97ffee5f 	bl	13e0 <strlen@plt>
    5a68:	aa1b03e1 	mov	x1, x27
    5a6c:	aa0003e2 	mov	x2, x0
    5a70:	aa1403e0 	mov	x0, x20
    5a74:	97fff1c7 	bl	2190 <buf_put>
    5a78:	aa1903e1 	mov	x1, x25
    5a7c:	aa1403e0 	mov	x0, x20
    5a80:	d2800062 	mov	x2, #0x3                   	// #3
    5a84:	97fff1c3 	bl	2190 <buf_put>
    5a88:	17fffe10 	b	52c8 <fwp_write+0x2d8>
    5a8c:	aa1a03e1 	mov	x1, x26
    5a90:	aa1403e0 	mov	x0, x20
    5a94:	d2800042 	mov	x2, #0x2                   	// #2
    5a98:	97fff1be 	bl	2190 <buf_put>
    5a9c:	17fffe09 	b	52c0 <fwp_write+0x2d0>
    5aa0:	f9400660 	ldr	x0, [x19, #8]
    5aa4:	b4fffb00 	cbz	x0, 5a04 <fwp_write+0xa14>
    5aa8:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5aac:	9118e021 	add	x1, x1, #0x638
    5ab0:	97ffeec8 	bl	15d0 <strcmp@plt>
    5ab4:	7100001f 	cmp	w0, #0x0
    5ab8:	1a9f07e0 	cset	w0, ne	// ne = any
    5abc:	17ffff2f 	b	5778 <fwp_write+0x788>
    5ac0:	aa1403e0 	mov	x0, x20
    5ac4:	d2800042 	mov	x2, #0x2                   	// #2
    5ac8:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5acc:	9118c021 	add	x1, x1, #0x630
    5ad0:	97fff1b0 	bl	2190 <buf_put>
    5ad4:	91004261 	add	x1, x19, #0x10
    5ad8:	aa1403e0 	mov	x0, x20
    5adc:	f9402382 	ldr	x2, [x28, #64]
    5ae0:	52800003 	mov	w3, #0x0                   	// #0
    5ae4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    5ae8:	97fffd42 	bl	4ff0 <fwp_write>
    5aec:	17fffd9c 	b	515c <fwp_write+0x16c>
    5af0:	1e22c109 	fcvt	d9, s8
    5af4:	910123f5 	add	x21, sp, #0x48
    5af8:	52800033 	mov	w19, #0x1                   	// #1
    5afc:	d503201f 	nop
    5b00:	1e604120 	fmov	d0, d9
    5b04:	2a1303e1 	mov	w1, w19
    5b08:	aa1503e0 	mov	x0, x21
    5b0c:	97fff236 	bl	23e4 <fwp_format_g.constprop.0>
    5b10:	aa1503e0 	mov	x0, x21
    5b14:	d2800001 	mov	x1, #0x0                   	// #0
    5b18:	97ffeeba 	bl	1600 <strtof@plt>
    5b1c:	1e202100 	fcmp	s8, s0
    5b20:	54ffdb60 	b.eq	568c <fwp_write+0x69c>  // b.none
    5b24:	11000673 	add	w19, w19, #0x1
    5b28:	71002a7f 	cmp	w19, #0xa
    5b2c:	54fffea1 	b.ne	5b00 <fwp_write+0xb10>  // b.any
    5b30:	1e604120 	fmov	d0, d9
    5b34:	aa1503e0 	mov	x0, x21
    5b38:	52800121 	mov	w1, #0x9                   	// #9
    5b3c:	97fff22a 	bl	23e4 <fwp_format_g.constprop.0>
    5b40:	17fffed3 	b	568c <fwp_write+0x69c>
    5b44:	d37ef6a1 	lsl	x1, x21, #2
    5b48:	b7f81563 	tbnz	x3, #63, 5df4 <fwp_write+0xe04>
    5b4c:	91002263 	add	x3, x19, #0x8
    5b50:	8b010061 	add	x1, x3, x1
    5b54:	b9400023 	ldr	w3, [x1]
    5b58:	7100081f 	cmp	w0, #0x2
    5b5c:	2a0303e1 	mov	w1, w3
    5b60:	93407c63 	sxtw	x3, w3
    5b64:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    5b68:	17fffe5a 	b	54d0 <fwp_write+0x4e0>
    5b6c:	d37ffaa1 	lsl	x1, x21, #1
    5b70:	b7f81363 	tbnz	x3, #63, 5ddc <fwp_write+0xdec>
    5b74:	91002263 	add	x3, x19, #0x8
    5b78:	8b010061 	add	x1, x3, x1
    5b7c:	79400021 	ldrh	w1, [x1]
    5b80:	7100041f 	cmp	w0, #0x1
    5b84:	93403c23 	sxth	x3, w1
    5b88:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    5b8c:	17fffe51 	b	54d0 <fwp_write+0x4e0>
    5b90:	52800443 	mov	w3, #0x22                  	// #34
    5b94:	91001ff5 	add	x21, sp, #0x7
    5b98:	91002273 	add	x19, x19, #0x8
    5b9c:	aa1503e1 	mov	x1, x21
    5ba0:	aa1403e0 	mov	x0, x20
    5ba4:	d2800022 	mov	x2, #0x1                   	// #1
    5ba8:	39001fe3 	strb	w3, [sp, #7]
    5bac:	f90143f7 	str	x23, [sp, #640]
    5bb0:	8b160277 	add	x23, x19, x22
    5bb4:	f90147f8 	str	x24, [sp, #648]
    5bb8:	97fff176 	bl	2190 <buf_put>
    5bbc:	b4000696 	cbz	x22, 5c8c <fwp_write+0xc9c>
    5bc0:	d0000018 	adrp	x24, 7000 <__modti3+0x1a0>
    5bc4:	91178318 	add	x24, x24, #0x5e0
    5bc8:	f9014bf9 	str	x25, [sp, #656]
    5bcc:	d0000019 	adrp	x25, 7000 <__modti3+0x1a0>
    5bd0:	91180339 	add	x25, x25, #0x600
    5bd4:	f9014ffa 	str	x26, [sp, #664]
    5bd8:	1400000d 	b	5c0c <fwp_write+0xc1c>
    5bdc:	710024bf 	cmp	w5, #0x9
    5be0:	54000460 	b.eq	5c6c <fwp_write+0xc7c>  // b.none
    5be4:	710028bf 	cmp	w5, #0xa
    5be8:	54000a61 	b.ne	5d34 <fwp_write+0xd44>  // b.any
    5bec:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5bf0:	aa1403e0 	mov	x0, x20
    5bf4:	9117c021 	add	x1, x1, #0x5f0
    5bf8:	d2800042 	mov	x2, #0x2                   	// #2
    5bfc:	97fff165 	bl	2190 <buf_put>
    5c00:	91000673 	add	x19, x19, #0x1
    5c04:	eb17027f 	cmp	x19, x23
    5c08:	540003e0 	b.eq	5c84 <fwp_write+0xc94>  // b.none
    5c0c:	39400265 	ldrb	w5, [x19]
    5c10:	710034bf 	cmp	w5, #0xd
    5c14:	54000180 	b.eq	5c44 <fwp_write+0xc54>  // b.none
    5c18:	54fffe29 	b.ls	5bdc <fwp_write+0xbec>  // b.plast
    5c1c:	710088bf 	cmp	w5, #0x22
    5c20:	540001c0 	b.eq	5c58 <fwp_write+0xc68>  // b.none
    5c24:	710170bf 	cmp	w5, #0x5c
    5c28:	54000741 	b.ne	5d10 <fwp_write+0xd20>  // b.any
    5c2c:	aa1403e0 	mov	x0, x20
    5c30:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5c34:	d2800042 	mov	x2, #0x2                   	// #2
    5c38:	9117a021 	add	x1, x1, #0x5e8
    5c3c:	97fff155 	bl	2190 <buf_put>
    5c40:	17fffff0 	b	5c00 <fwp_write+0xc10>
    5c44:	aa1903e1 	mov	x1, x25
    5c48:	aa1403e0 	mov	x0, x20
    5c4c:	d2800042 	mov	x2, #0x2                   	// #2
    5c50:	97fff150 	bl	2190 <buf_put>
    5c54:	17ffffeb 	b	5c00 <fwp_write+0xc10>
    5c58:	aa1803e1 	mov	x1, x24
    5c5c:	aa1403e0 	mov	x0, x20
    5c60:	d2800042 	mov	x2, #0x2                   	// #2
    5c64:	97fff14b 	bl	2190 <buf_put>
    5c68:	17ffffe6 	b	5c00 <fwp_write+0xc10>
    5c6c:	aa1403e0 	mov	x0, x20
    5c70:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5c74:	d2800042 	mov	x2, #0x2                   	// #2
    5c78:	9117e021 	add	x1, x1, #0x5f8
    5c7c:	97fff145 	bl	2190 <buf_put>
    5c80:	17ffffe0 	b	5c00 <fwp_write+0xc10>
    5c84:	f9414bf9 	ldr	x25, [sp, #656]
    5c88:	f9414ffa 	ldr	x26, [sp, #664]
    5c8c:	aa1503e1 	mov	x1, x21
    5c90:	aa1403e0 	mov	x0, x20
    5c94:	52800443 	mov	w3, #0x22                  	// #34
    5c98:	17fffd9c 	b	5308 <fwp_write+0x318>
    5c9c:	7100103f 	cmp	w1, #0x4
    5ca0:	54ffeb21 	b.ne	5a04 <fwp_write+0xa14>  // b.any
    5ca4:	f94006e0 	ldr	x0, [x23, #8]
    5ca8:	d37ffc00 	lsr	x0, x0, #63
    5cac:	17fffeb3 	b	5778 <fwp_write+0x788>
    5cb0:	710002ff 	cmp	w23, #0x0
    5cb4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    5cb8:	17fffeb0 	b	5778 <fwp_write+0x788>
    5cbc:	528005a1 	mov	w1, #0x2d                  	// #45
    5cc0:	eb0203e2 	negs	x2, x2
    5cc4:	da0303e3 	ngc	x3, x3
    5cc8:	910127e0 	add	x0, sp, #0x49
    5ccc:	910123f5 	add	x21, sp, #0x48
    5cd0:	390123e1 	strb	w1, [sp, #72]
    5cd4:	97ffef73 	bl	1aa0 <fwp_fmt_u128>
    5cd8:	17fffe18 	b	5538 <fwp_write+0x548>
    5cdc:	d37ceea1 	lsl	x1, x21, #4
    5ce0:	b7f810a3 	tbnz	x3, #63, 5ef4 <fwp_write+0xf04>
    5ce4:	91002260 	add	x0, x19, #0x8
    5ce8:	8b010001 	add	x1, x0, x1
    5cec:	17fffdf9 	b	54d0 <fwp_write+0x4e0>
    5cf0:	f9400a61 	ldr	x1, [x19, #16]
    5cf4:	8b010000 	add	x0, x0, x1
    5cf8:	f9400001 	ldr	x1, [x0]
    5cfc:	17fffdf5 	b	54d0 <fwp_write+0x4e0>
    5d00:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5d04:	d2800042 	mov	x2, #0x2                   	// #2
    5d08:	91162021 	add	x1, x1, #0x588
    5d0c:	17fffed6 	b	5864 <fwp_write+0x874>
    5d10:	7101fcbf 	cmp	w5, #0x7f
    5d14:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    5d18:	540000e9 	b.ls	5d34 <fwp_write+0xd44>  // b.plast
    5d1c:	aa1503e1 	mov	x1, x21
    5d20:	aa1403e0 	mov	x0, x20
    5d24:	d2800022 	mov	x2, #0x1                   	// #1
    5d28:	39001fe5 	strb	w5, [sp, #7]
    5d2c:	97fff119 	bl	2190 <buf_put>
    5d30:	17ffffb4 	b	5c00 <fwp_write+0xc10>
    5d34:	d2800203 	mov	x3, #0x10                  	// #16
    5d38:	d0000004 	adrp	x4, 7000 <__modti3+0x1a0>
    5d3c:	aa0303e1 	mov	x1, x3
    5d40:	91182084 	add	x4, x4, #0x608
    5d44:	910123f6 	add	x22, sp, #0x48
    5d48:	52800042 	mov	w2, #0x2                   	// #2
    5d4c:	aa1603e0 	mov	x0, x22
    5d50:	97ffeddc 	bl	14c0 <__snprintf_chk@plt>
    5d54:	aa1603e0 	mov	x0, x22
    5d58:	97ffeda2 	bl	13e0 <strlen@plt>
    5d5c:	aa1603e1 	mov	x1, x22
    5d60:	aa0003e2 	mov	x2, x0
    5d64:	aa1403e0 	mov	x0, x20
    5d68:	97fff10a 	bl	2190 <buf_put>
    5d6c:	17ffffa5 	b	5c00 <fwp_write+0xc10>
    5d70:	1e604100 	fmov	d0, d8
    5d74:	aa1503e0 	mov	x0, x21
    5d78:	52800221 	mov	w1, #0x11                  	// #17
    5d7c:	97fff19a 	bl	23e4 <fwp_format_g.constprop.0>
    5d80:	17fffe43 	b	568c <fwp_write+0x69c>
    5d84:	b9401040 	ldr	w0, [x2, #16]
    5d88:	350003c0 	cbnz	w0, 5e00 <fwp_write+0xe10>
    5d8c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    5d90:	f947f400 	ldr	x0, [x0, #4072]
    5d94:	f94127e2 	ldr	x2, [sp, #584]
    5d98:	f9400001 	ldr	x1, [x0]
    5d9c:	eb010042 	subs	x2, x2, x1
    5da0:	d2800001 	mov	x1, #0x0                   	// #0
    5da4:	54ffd721 	b.ne	5888 <fwp_write+0x898>  // b.any
    5da8:	f9413bf5 	ldr	x21, [sp, #624]
    5dac:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5db0:	f9413ff6 	ldr	x22, [sp, #632]
    5db4:	aa1403e0 	mov	x0, x20
    5db8:	f94143f7 	ldr	x23, [sp, #640]
    5dbc:	91196021 	add	x1, x1, #0x658
    5dc0:	f94147f8 	ldr	x24, [sp, #648]
    5dc4:	d2800042 	mov	x2, #0x2                   	// #2
    5dc8:	17fffd0e 	b	5200 <fwp_write+0x210>
    5dcc:	d0000001 	adrp	x1, 7000 <__modti3+0x1a0>
    5dd0:	d2800042 	mov	x2, #0x2                   	// #2
    5dd4:	91164021 	add	x1, x1, #0x590
    5dd8:	17fffea3 	b	5864 <fwp_write+0x874>
    5ddc:	f9400a63 	ldr	x3, [x19, #16]
    5de0:	8b030021 	add	x1, x1, x3
    5de4:	17ffff66 	b	5b7c <fwp_write+0xb8c>
    5de8:	f9400a61 	ldr	x1, [x19, #16]
    5dec:	8b0102a1 	add	x1, x21, x1
    5df0:	17fffdb3 	b	54bc <fwp_write+0x4cc>
    5df4:	f9400a63 	ldr	x3, [x19, #16]
    5df8:	8b030021 	add	x1, x1, x3
    5dfc:	17ffff56 	b	5b54 <fwp_write+0xb64>
    5e00:	b9404840 	ldr	w0, [x2, #72]
    5e04:	91001ff5 	add	x21, sp, #0x7
    5e08:	34ffa360 	cbz	w0, 5274 <fwp_write+0x284>
    5e0c:	52800503 	mov	w3, #0x28                  	// #40
    5e10:	aa1403e0 	mov	x0, x20
    5e14:	aa1503e1 	mov	x1, x21
    5e18:	d2800022 	mov	x2, #0x1                   	// #1
    5e1c:	39001fe3 	strb	w3, [sp, #7]
    5e20:	97fff0dc 	bl	2190 <buf_put>
    5e24:	b9401380 	ldr	w0, [x28, #16]
    5e28:	52800038 	mov	w24, #0x1                   	// #1
    5e2c:	7100001f 	cmp	w0, #0x0
    5e30:	54ffa36c 	b.gt	529c <fwp_write+0x2ac>
    5e34:	17fffd32 	b	52fc <fwp_write+0x30c>
    5e38:	f9014bf9 	str	x25, [sp, #656]
    5e3c:	d00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x165f8>
    5e40:	f9014ffa 	str	x26, [sp, #664]
    5e44:	f9400676 	ldr	x22, [x19, #8]
    5e48:	912ae333 	add	x19, x25, #0xab8
    5e4c:	91002273 	add	x19, x19, #0x8
    5e50:	937ffed8 	asr	x24, x22, #63
    5e54:	aa1802c0 	orr	x0, x22, x24
    5e58:	b5000320 	cbnz	x0, 5ebc <fwp_write+0xecc>
    5e5c:	110006b5 	add	w21, w21, #0x1
    5e60:	710016bf 	cmp	w21, #0x5
    5e64:	54ffffc1 	b.ne	5e5c <fwp_write+0xe6c>  // b.any
    5e68:	b7f80578 	tbnz	x24, #63, 5f14 <fwp_write+0xf24>
    5e6c:	910023f3 	add	x19, sp, #0x8
    5e70:	aa1603e2 	mov	x2, x22
    5e74:	aa1303e0 	mov	x0, x19
    5e78:	d2800003 	mov	x3, #0x0                   	// #0
    5e7c:	97ffef09 	bl	1aa0 <fwp_fmt_u128>
    5e80:	910123f5 	add	x21, sp, #0x48
    5e84:	d0000003 	adrp	x3, 7000 <__modti3+0x1a0>
    5e88:	aa1303e4 	mov	x4, x19
    5e8c:	aa1503e0 	mov	x0, x21
    5e90:	91194063 	add	x3, x3, #0x650
    5e94:	d2804002 	mov	x2, #0x200                 	// #512
    5e98:	52800041 	mov	w1, #0x2                   	// #2
    5e9c:	97ffed55 	bl	13f0 <__sprintf_chk@plt>
    5ea0:	aa1503e0 	mov	x0, x21
    5ea4:	97ffed4f 	bl	13e0 <strlen@plt>
    5ea8:	aa1503e1 	mov	x1, x21
    5eac:	aa0003e2 	mov	x2, x0
    5eb0:	aa1403e0 	mov	x0, x20
    5eb4:	97fff0b7 	bl	2190 <buf_put>
    5eb8:	17fffe47 	b	57d4 <fwp_write+0x7e4>
    5ebc:	f9400277 	ldr	x23, [x19]
    5ec0:	aa1603e0 	mov	x0, x22
    5ec4:	aa1803e1 	mov	x1, x24
    5ec8:	aa1703e2 	mov	x2, x23
    5ecc:	937ffefa 	asr	x26, x23, #63
    5ed0:	aa1a03e3 	mov	x3, x26
    5ed4:	940003e3 	bl	6e60 <__modti3>
    5ed8:	aa010000 	orr	x0, x0, x1
    5edc:	b40002c0 	cbz	x0, 5f34 <fwp_write+0xf44>
    5ee0:	110006b5 	add	w21, w21, #0x1
    5ee4:	91004273 	add	x19, x19, #0x10
    5ee8:	710016bf 	cmp	w21, #0x5
    5eec:	54fffe81 	b.ne	5ebc <fwp_write+0xecc>  // b.any
    5ef0:	17ffffde 	b	5e68 <fwp_write+0xe78>
    5ef4:	f9400a60 	ldr	x0, [x19, #16]
    5ef8:	8b000021 	add	x1, x1, x0
    5efc:	17fffd75 	b	54d0 <fwp_write+0x4e0>
    5f00:	528c29c0 	mov	w0, #0x614e                	// #24910
    5f04:	910123f5 	add	x21, sp, #0x48
    5f08:	72a009c0 	movk	w0, #0x4e, lsl #16
    5f0c:	b9004be0 	str	w0, [sp, #72]
    5f10:	17fffda2 	b	5598 <fwp_write+0x5a8>
    5f14:	528005a1 	mov	w1, #0x2d                  	// #45
    5f18:	eb1603e2 	negs	x2, x22
    5f1c:	da1803e3 	ngc	x3, x24
    5f20:	910027e0 	add	x0, sp, #0x9
    5f24:	910023f3 	add	x19, sp, #0x8
    5f28:	390023e1 	strb	w1, [sp, #8]
    5f2c:	97ffeedd 	bl	1aa0 <fwp_fmt_u128>
    5f30:	17ffffd4 	b	5e80 <fwp_write+0xe90>
    5f34:	aa1703e2 	mov	x2, x23
    5f38:	aa1a03e3 	mov	x3, x26
    5f3c:	aa1603e0 	mov	x0, x22
    5f40:	aa1803e1 	mov	x1, x24
    5f44:	940002e7 	bl	6ae0 <__divti3>
    5f48:	aa0003e2 	mov	x2, x0
    5f4c:	aa0103e3 	mov	x3, x1
    5f50:	b7f80201 	tbnz	x1, #63, 5f90 <fwp_write+0xfa0>
    5f54:	910023f3 	add	x19, sp, #0x8
    5f58:	aa1303e0 	mov	x0, x19
    5f5c:	97ffeed1 	bl	1aa0 <fwp_fmt_u128>
    5f60:	937c7ea1 	sbfiz	x1, x21, #4, #32
    5f64:	912ae339 	add	x25, x25, #0xab8
    5f68:	910123f5 	add	x21, sp, #0x48
    5f6c:	aa1303e4 	mov	x4, x19
    5f70:	aa1503e0 	mov	x0, x21
    5f74:	d0000003 	adrp	x3, 7000 <__modti3+0x1a0>
    5f78:	f8616b25 	ldr	x5, [x25, x1]
    5f7c:	91192063 	add	x3, x3, #0x648
    5f80:	d2804002 	mov	x2, #0x200                 	// #512
    5f84:	52800041 	mov	w1, #0x2                   	// #2
    5f88:	97ffed1a 	bl	13f0 <__sprintf_chk@plt>
    5f8c:	17ffffc5 	b	5ea0 <fwp_write+0xeb0>
    5f90:	528005a4 	mov	w4, #0x2d                  	// #45
    5f94:	eb0003e2 	negs	x2, x0
    5f98:	da0103e3 	ngc	x3, x1
    5f9c:	910027e0 	add	x0, sp, #0x9
    5fa0:	910023f3 	add	x19, sp, #0x8
    5fa4:	390023e4 	strb	w4, [sp, #8]
    5fa8:	97ffeebe 	bl	1aa0 <fwp_fmt_u128>
    5fac:	17ffffed 	b	5f60 <fwp_write+0xf70>
    5fb0:	f9013bf5 	str	x21, [sp, #624]
    5fb4:	f9013ff6 	str	x22, [sp, #632]
    5fb8:	f90143f7 	str	x23, [sp, #640]
    5fbc:	f90147f8 	str	x24, [sp, #648]
    5fc0:	f9014bf9 	str	x25, [sp, #656]
    5fc4:	f9014ffa 	str	x26, [sp, #664]
    5fc8:	f90153fb 	str	x27, [sp, #672]
    5fcc:	f90157fc 	str	x28, [sp, #680]
    5fd0:	fd015be8 	str	d8, [sp, #688]
    5fd4:	fd015fe9 	str	d9, [sp, #696]
    5fd8:	97ffed5e 	bl	1550 <__stack_chk_fail@plt>
    5fdc:	d503201f 	nop

0000000000005fe0 <fwp_main_thread>:
    5fe0:	d10643ff 	sub	sp, sp, #0x190
    5fe4:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    5fe8:	f947f400 	ldr	x0, [x0, #4072]
    5fec:	a9137bfd 	stp	x29, x30, [sp, #304]
    5ff0:	9104c3fd 	add	x29, sp, #0x130
    5ff4:	a91663f7 	stp	x23, x24, [sp, #352]
    5ff8:	90000178 	adrp	x24, 31000 <fwp_root_context+0xcb0>
    5ffc:	9114c301 	add	x1, x24, #0x530
    6000:	a91453f3 	stp	x19, x20, [sp, #320]
    6004:	a9155bf5 	stp	x21, x22, [sp, #336]
    6008:	b953a421 	ldr	w1, [x1, #5028]
    600c:	a9176bf9 	stp	x25, x26, [sp, #368]
    6010:	a91873fb 	stp	x27, x28, [sp, #384]
    6014:	f9400002 	ldr	x2, [x0]
    6018:	f90097e2 	str	x2, [sp, #296]
    601c:	d2800002 	mov	x2, #0x0                   	// #0
    6020:	34002941 	cbz	w1, 6548 <fwp_main_thread+0x568>
    6024:	9114c300 	add	x0, x24, #0x530
    6028:	b953a800 	ldr	w0, [x0, #5032]
    602c:	35002860 	cbnz	w0, 6538 <fwp_main_thread+0x558>
    6030:	d00000d4 	adrp	x20, 20000 <__data_start>
    6034:	d00000c2 	adrp	x2, 20000 <__data_start>
    6038:	9101429a 	add	x26, x20, #0x50
    603c:	910d4042 	add	x2, x2, #0x350
    6040:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    6044:	d2a00024 	mov	x4, #0x10000               	// #65536
    6048:	910143e0 	add	x0, sp, #0x50
    604c:	9100e3fc 	add	x28, sp, #0x38
    6050:	d2800001 	mov	x1, #0x0                   	// #0
    6054:	a9010f5c 	stp	x28, x3, [x26, #16]
    6058:	f9000be0 	str	x0, [sp, #16]
    605c:	f9002be2 	str	x2, [sp, #80]
    6060:	b9005bff 	str	wzr, [sp, #88]
    6064:	f90033e4 	str	x4, [sp, #96]
    6068:	97ffecd6 	bl	13c0 <sigaltstack@plt>
    606c:	35005260 	cbnz	w0, 6ab8 <fwp_main_thread+0xad8>
    6070:	4f000400 	movi	v0.4s, #0x0
    6074:	910263e0 	add	x0, sp, #0x98
    6078:	f0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    607c:	91324021 	add	x1, x1, #0xc90
    6080:	f9004be1 	str	x1, [sp, #144]
    6084:	52800082 	mov	w2, #0x4                   	// #4
    6088:	72a10002 	movk	w2, #0x800, lsl #16
    608c:	910243f3 	add	x19, sp, #0x90
    6090:	3d802000 	str	q0, [x0, #128]
    6094:	b9011be2 	str	w2, [sp, #280]
    6098:	ad000000 	stp	q0, q0, [x0]
    609c:	ad010000 	stp	q0, q0, [x0, #32]
    60a0:	ad020000 	stp	q0, q0, [x0, #64]
    60a4:	ad030000 	stp	q0, q0, [x0, #96]
    60a8:	97ffed1a 	bl	1510 <sigemptyset@plt>
    60ac:	35005060 	cbnz	w0, 6ab8 <fwp_main_thread+0xad8>
    60b0:	aa1303e1 	mov	x1, x19
    60b4:	d2800002 	mov	x2, #0x0                   	// #0
    60b8:	52800160 	mov	w0, #0xb                   	// #11
    60bc:	97ffed2d 	bl	1570 <sigaction@plt>
    60c0:	35004fc0 	cbnz	w0, 6ab8 <fwp_main_thread+0xad8>
    60c4:	aa1303e1 	mov	x1, x19
    60c8:	d2800002 	mov	x2, #0x0                   	// #0
    60cc:	528000e0 	mov	w0, #0x7                   	// #7
    60d0:	97ffed28 	bl	1570 <sigaction@plt>
    60d4:	35004f20 	cbnz	w0, 6ab8 <fwp_main_thread+0xad8>
    60d8:	9114c31b 	add	x27, x24, #0x530
    60dc:	52800037 	mov	w23, #0x1                   	// #1
    60e0:	f0ffffc0 	adrp	x0, 1000 <__abi_tag+0xd88>
    60e4:	913e4000 	add	x0, x0, #0xf90
    60e8:	b9004357 	str	w23, [x26, #64]
    60ec:	fd4a1360 	ldr	d0, [x27, #5152]
    60f0:	7e61d800 	ucvtf	d0, d0
    60f4:	fd015f40 	str	d0, [x26, #696]
    60f8:	94000436 	bl	71d0 <atexit>
    60fc:	35004ec0 	cbnz	w0, 6ad4 <fwp_main_thread+0xaf4>
    6100:	b942cb40 	ldr	w0, [x26, #712]
    6104:	34002260 	cbz	w0, 6550 <fwp_main_thread+0x570>
    6108:	9101429a 	add	x26, x20, #0x50
    610c:	f9400755 	ldr	x21, [x26, #8]
    6110:	b40010b5 	cbz	x21, 6324 <fwp_main_thread+0x344>
    6114:	aa1503f3 	mov	x19, x21
    6118:	910102b6 	add	x22, x21, #0x40
    611c:	39414ab9 	ldrb	w25, [x21, #82]
    6120:	52800037 	mov	w23, #0x1                   	// #1
    6124:	39014ab7 	strb	w23, [x21, #82]
    6128:	f94016a0 	ldr	x0, [x21, #40]
    612c:	b4000620 	cbz	x0, 61f0 <fwp_main_thread+0x210>
    6130:	f94032a1 	ldr	x1, [x21, #96]
    6134:	394146a0 	ldrb	w0, [x21, #81]
    6138:	b4000b41 	cbz	x1, 62a0 <fwp_main_thread+0x2c0>
    613c:	36000a80 	tbz	w0, #0, 628c <fwp_main_thread+0x2ac>
    6140:	39414a62 	ldrb	w2, [x19, #82]
    6144:	f94022a0 	ldr	x0, [x21, #64]
    6148:	37000d62 	tbnz	w2, #0, 62f4 <fwp_main_thread+0x314>
    614c:	f9403261 	ldr	x1, [x19, #96]
    6150:	a911fe76 	stp	x22, xzr, [x19, #280]
    6154:	f9009660 	str	x0, [x19, #296]
    6158:	b4000040 	cbz	x0, 6160 <fwp_main_thread+0x180>
    615c:	f9009013 	str	x19, [x0, #288]
    6160:	f90022b3 	str	x19, [x21, #64]
    6164:	b4000101 	cbz	x1, 6184 <fwp_main_thread+0x1a4>
    6168:	f9401f40 	ldr	x0, [x26, #56]
    616c:	39015677 	strb	w23, [x19, #85]
    6170:	f9003661 	str	x1, [x19, #104]
    6174:	a910827f 	stp	xzr, x0, [x19, #264]
    6178:	b4000040 	cbz	x0, 6180 <fwp_main_thread+0x1a0>
    617c:	f9008413 	str	x19, [x0, #264]
    6180:	f9001f53 	str	x19, [x26, #56]
    6184:	39015a7f 	strb	wzr, [x19, #86]
    6188:	97fff64f 	bl	3ac4 <fwp_block>
    618c:	f9408e62 	ldr	x2, [x19, #280]
    6190:	b4000142 	cbz	x2, 61b8 <fwp_main_thread+0x1d8>
    6194:	a9520261 	ldp	x1, x0, [x19, #288]
    6198:	b4000ba1 	cbz	x1, 630c <fwp_main_thread+0x32c>
    619c:	f9009420 	str	x0, [x1, #296]
    61a0:	f9409660 	ldr	x0, [x19, #296]
    61a4:	b4000040 	cbz	x0, 61ac <fwp_main_thread+0x1cc>
    61a8:	f9009001 	str	x1, [x0, #288]
    61ac:	91080260 	add	x0, x19, #0x200
    61b0:	f900967f 	str	xzr, [x19, #296]
    61b4:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    61b8:	39415660 	ldrb	w0, [x19, #85]
    61bc:	f9400742 	ldr	x2, [x26, #8]
    61c0:	36000960 	tbz	w0, #0, 62ec <fwp_main_thread+0x30c>
    61c4:	a9508261 	ldp	x1, x0, [x19, #264]
    61c8:	b4000a61 	cbz	x1, 6314 <fwp_main_thread+0x334>
    61cc:	f9008820 	str	x0, [x1, #272]
    61d0:	b4000040 	cbz	x0, 61d8 <fwp_main_thread+0x1f8>
    61d4:	f9008401 	str	x1, [x0, #264]
    61d8:	91080260 	add	x0, x19, #0x200
    61dc:	3901567f 	strb	wzr, [x19, #85]
    61e0:	aa0203f3 	mov	x19, x2
    61e4:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    61e8:	f94016a0 	ldr	x0, [x21, #40]
    61ec:	b5fffa20 	cbnz	x0, 6130 <fwp_main_thread+0x150>
    61f0:	91014280 	add	x0, x20, #0x50
    61f4:	39014ab9 	strb	w25, [x21, #82]
    61f8:	f9414400 	ldr	x0, [x0, #648]
    61fc:	b4001800 	cbz	x0, 64fc <fwp_main_thread+0x51c>
    6200:	91014280 	add	x0, x20, #0x50
    6204:	f9417001 	ldr	x1, [x0, #736]
    6208:	b902d81f 	str	wzr, [x0, #728]
    620c:	eb13003f 	cmp	x1, x19
    6210:	54001921 	b.ne	6534 <fwp_main_thread+0x554>  // b.any
    6214:	b4000933 	cbz	x19, 6338 <fwp_main_thread+0x358>
    6218:	91014280 	add	x0, x20, #0x50
    621c:	52800021 	mov	w1, #0x1                   	// #1
    6220:	39014a61 	strb	w1, [x19, #82]
    6224:	f9413005 	ldr	x5, [x0, #608]
    6228:	b4000885 	cbz	x5, 6338 <fwp_main_thread+0x358>
    622c:	d503201f 	nop
    6230:	394140a0 	ldrb	w0, [x5, #80]
    6234:	37000060 	tbnz	w0, #0, 6240 <fwp_main_thread+0x260>
    6238:	aa0503e0 	mov	x0, x5
    623c:	97ffefed 	bl	21f0 <fwp_cancel_tree.part.0>
    6240:	f9409ca5 	ldr	x5, [x5, #312]
    6244:	b5ffff65 	cbnz	x5, 6230 <fwp_main_thread+0x250>
    6248:	91014295 	add	x21, x20, #0x50
    624c:	52800036 	mov	w22, #0x1                   	// #1
    6250:	f9402a60 	ldr	x0, [x19, #80]
    6254:	f2001c1f 	tst	x0, #0xff000000ff
    6258:	540000e1 	b.ne	6274 <fwp_main_thread+0x294>  // b.any
    625c:	f94016a0 	ldr	x0, [x21, #40]
    6260:	39015276 	strb	w22, [x19, #84]
    6264:	f900827f 	str	xzr, [x19, #256]
    6268:	b40005a0 	cbz	x0, 631c <fwp_main_thread+0x33c>
    626c:	f9008013 	str	x19, [x0, #256]
    6270:	f90016b3 	str	x19, [x21, #40]
    6274:	97fff614 	bl	3ac4 <fwp_block>
    6278:	97fff5a6 	bl	3910 <fwp_free_zombie>
    627c:	f94132a0 	ldr	x0, [x21, #608]
    6280:	b40005c0 	cbz	x0, 6338 <fwp_main_thread+0x358>
    6284:	f94172b3 	ldr	x19, [x21, #736]
    6288:	17fffff2 	b	6250 <fwp_main_thread+0x270>
    628c:	97fff02d 	bl	2340 <fwp_now_ns>
    6290:	f94032a1 	ldr	x1, [x21, #96]
    6294:	eb01001f 	cmp	x0, x1
    6298:	5400124a 	b.ge	64e0 <fwp_main_thread+0x500>  // b.tcont
    629c:	394146a0 	ldrb	w0, [x21, #81]
    62a0:	39414a62 	ldrb	w2, [x19, #82]
    62a4:	3707f500 	tbnz	w0, #0, 6144 <fwp_main_thread+0x164>
    62a8:	f94032a1 	ldr	x1, [x21, #96]
    62ac:	370001c2 	tbnz	w2, #0, 62e4 <fwp_main_thread+0x304>
    62b0:	f9403260 	ldr	x0, [x19, #96]
    62b4:	b4000180 	cbz	x0, 62e4 <fwp_main_thread+0x304>
    62b8:	b4000061 	cbz	x1, 62c4 <fwp_main_thread+0x2e4>
    62bc:	eb01001f 	cmp	x0, x1
    62c0:	9a81d000 	csel	x0, x0, x1, le
    62c4:	f94022a1 	ldr	x1, [x21, #64]
    62c8:	a911fe76 	stp	x22, xzr, [x19, #280]
    62cc:	f9009661 	str	x1, [x19, #296]
    62d0:	b4003b21 	cbz	x1, 6a34 <fwp_main_thread+0xa54>
    62d4:	f9009033 	str	x19, [x1, #288]
    62d8:	aa0003e1 	mov	x1, x0
    62dc:	f90022b3 	str	x19, [x21, #64]
    62e0:	17ffffa2 	b	6168 <fwp_main_thread+0x188>
    62e4:	f94022a0 	ldr	x0, [x21, #64]
    62e8:	17ffff9a 	b	6150 <fwp_main_thread+0x170>
    62ec:	aa0203f3 	mov	x19, x2
    62f0:	17ffff8e 	b	6128 <fwp_main_thread+0x148>
    62f4:	a911fe76 	stp	x22, xzr, [x19, #280]
    62f8:	f9009660 	str	x0, [x19, #296]
    62fc:	b4000040 	cbz	x0, 6304 <fwp_main_thread+0x324>
    6300:	f9009013 	str	x19, [x0, #288]
    6304:	f90022b3 	str	x19, [x21, #64]
    6308:	17ffff9f 	b	6184 <fwp_main_thread+0x1a4>
    630c:	f9000040 	str	x0, [x2]
    6310:	17ffffa5 	b	61a4 <fwp_main_thread+0x1c4>
    6314:	f9001f40 	str	x0, [x26, #56]
    6318:	17ffffae 	b	61d0 <fwp_main_thread+0x1f0>
    631c:	f9001ab3 	str	x19, [x21, #48]
    6320:	17ffffd4 	b	6270 <fwp_main_thread+0x290>
    6324:	f9414740 	ldr	x0, [x26, #648]
    6328:	b4000e80 	cbz	x0, 64f8 <fwp_main_thread+0x518>
    632c:	f9417340 	ldr	x0, [x26, #736]
    6330:	b902db5f 	str	wzr, [x26, #728]
    6334:	b5001000 	cbnz	x0, 6534 <fwp_main_thread+0x554>
    6338:	91014295 	add	x21, x20, #0x50
    633c:	97fff575 	bl	3910 <fwp_free_zombie>
    6340:	f9401aa0 	ldr	x0, [x21, #48]
    6344:	b5000f80 	cbnz	x0, 6534 <fwp_main_thread+0x554>
    6348:	f9401ea0 	ldr	x0, [x21, #56]
    634c:	b5000f40 	cbnz	x0, 6534 <fwp_main_thread+0x554>
    6350:	b9405ab3 	ldr	w19, [x21, #88]
    6354:	340001d3 	cbz	w19, 638c <fwp_main_thread+0x3ac>
    6358:	93407e76 	sxtw	x22, w19
    635c:	51000673 	sub	w19, w19, #0x1
    6360:	d1000ad6 	sub	x22, x22, #0x2
    6364:	910182b7 	add	x23, x21, #0x60
    6368:	cb3342d6 	sub	x22, x22, w19, uxtw
    636c:	93407e73 	sxtw	x19, w19
    6370:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    6374:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    6378:	b9005ab3 	str	w19, [x21, #88]
    637c:	d1000673 	sub	x19, x19, #0x1
    6380:	97ffecbc 	bl	1670 <munmap@plt>
    6384:	eb1302df 	cmp	x22, x19
    6388:	54ffff41 	b.ne	6370 <fwp_main_thread+0x390>  // b.any
    638c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6390:	91004260 	add	x0, x19, #0x10
    6394:	b9402000 	ldr	w0, [x0, #32]
    6398:	37f80040 	tbnz	w0, #31, 63a0 <fwp_main_thread+0x3c0>
    639c:	97ffec71 	bl	1560 <close@plt>
    63a0:	91014280 	add	x0, x20, #0x50
    63a4:	91004261 	add	x1, x19, #0x10
    63a8:	12800002 	mov	w2, #0xffffffff            	// #-1
    63ac:	d2800013 	mov	x19, #0x0                   	// #0
    63b0:	f9417416 	ldr	x22, [x0, #744]
    63b4:	b9002022 	str	w2, [x1, #32]
    63b8:	f9417815 	ldr	x21, [x0, #752]
    63bc:	b4000176 	cbz	x22, 63e8 <fwp_main_thread+0x408>
    63c0:	f8737aa0 	ldr	x0, [x21, x19, lsl #3]
    63c4:	b40000c0 	cbz	x0, 63dc <fwp_main_thread+0x3fc>
    63c8:	f9400001 	ldr	x1, [x0]
    63cc:	b5000b41 	cbnz	x1, 6534 <fwp_main_thread+0x554>
    63d0:	f9400401 	ldr	x1, [x0, #8]
    63d4:	b5000b01 	cbnz	x1, 6534 <fwp_main_thread+0x554>
    63d8:	97fff376 	bl	31b0 <fwp_mem_free>
    63dc:	91000673 	add	x19, x19, #0x1
    63e0:	eb16027f 	cmp	x19, x22
    63e4:	54fffee1 	b.ne	63c0 <fwp_main_thread+0x3e0>  // b.any
    63e8:	aa1503e0 	mov	x0, x21
    63ec:	97fff371 	bl	31b0 <fwp_mem_free>
    63f0:	91014280 	add	x0, x20, #0x50
    63f4:	f9417013 	ldr	x19, [x0, #736]
    63f8:	f901741f 	str	xzr, [x0, #744]
    63fc:	f901781f 	str	xzr, [x0, #752]
    6400:	b40001f3 	cbz	x19, 643c <fwp_main_thread+0x45c>
    6404:	f9401661 	ldr	x1, [x19, #40]
    6408:	b5000961 	cbnz	x1, 6534 <fwp_main_thread+0x554>
    640c:	f9405661 	ldr	x1, [x19, #168]
    6410:	b5000921 	cbnz	x1, 6534 <fwp_main_thread+0x554>
    6414:	f9414401 	ldr	x1, [x0, #648]
    6418:	b50008e1 	cbnz	x1, 6534 <fwp_main_thread+0x554>
    641c:	f9414c00 	ldr	x0, [x0, #664]
    6420:	b50008a0 	cbnz	x0, 6534 <fwp_main_thread+0x554>
    6424:	d2823a02 	mov	x2, #0x11d0                	// #4560
    6428:	d0000140 	adrp	x0, 30000 <alt.4+0xfcb0>
    642c:	910d4000 	add	x0, x0, #0x350
    6430:	97ffec3c 	bl	1520 <memset@plt>
    6434:	aa1303e0 	mov	x0, x19
    6438:	97fff35e 	bl	31b0 <fwp_mem_free>
    643c:	9114c318 	add	x24, x24, #0x530
    6440:	91014294 	add	x20, x20, #0x50
    6444:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    6448:	f947e800 	ldr	x0, [x0, #4048]
    644c:	52800041 	mov	w1, #0x2                   	// #2
    6450:	fd4a1300 	ldr	d0, [x24, #5152]
    6454:	b0000002 	adrp	x2, 7000 <__modti3+0x1a0>
    6458:	fd415e81 	ldr	d1, [x20, #696]
    645c:	911b2042 	add	x2, x2, #0x6c8
    6460:	f9400000 	ldr	x0, [x0]
    6464:	7e61d800 	ucvtf	d0, d0
    6468:	f9402685 	ldr	x5, [x20, #72]
    646c:	f900069f 	str	xzr, [x20, #8]
    6470:	f9415683 	ldr	x3, [x20, #680]
    6474:	1e613801 	fsub	d1, d0, d1
    6478:	f9415a84 	ldr	x4, [x20, #688]
    647c:	f900129f 	str	xzr, [x20, #32]
    6480:	fd416280 	ldr	d0, [x20, #704]
    6484:	b900429f 	str	wzr, [x20, #64]
    6488:	f901729f 	str	xzr, [x20, #736]
    648c:	97ffec4d 	bl	15c0 <__fprintf_chk@plt>
    6490:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    6494:	f947ec00 	ldr	x0, [x0, #4056]
    6498:	f9400000 	ldr	x0, [x0]
    649c:	97ffec79 	bl	1680 <fflush@plt>
    64a0:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    64a4:	f947f400 	ldr	x0, [x0, #4072]
    64a8:	f94097e2 	ldr	x2, [sp, #296]
    64ac:	f9400001 	ldr	x1, [x0]
    64b0:	eb010042 	subs	x2, x2, x1
    64b4:	d2800001 	mov	x1, #0x0                   	// #0
    64b8:	540030c1 	b.ne	6ad0 <fwp_main_thread+0xaf0>  // b.any
    64bc:	a9537bfd 	ldp	x29, x30, [sp, #304]
    64c0:	d2800000 	mov	x0, #0x0                   	// #0
    64c4:	a95453f3 	ldp	x19, x20, [sp, #320]
    64c8:	a9555bf5 	ldp	x21, x22, [sp, #336]
    64cc:	a95663f7 	ldp	x23, x24, [sp, #352]
    64d0:	a9576bf9 	ldp	x25, x26, [sp, #368]
    64d4:	a95873fb 	ldp	x27, x28, [sp, #384]
    64d8:	910643ff 	add	sp, sp, #0x190
    64dc:	d65f03c0 	ret
    64e0:	394142a0 	ldrb	w0, [x21, #80]
    64e4:	3707edc0 	tbnz	w0, #0, 629c <fwp_main_thread+0x2bc>
    64e8:	aa1503e0 	mov	x0, x21
    64ec:	97ffef41 	bl	21f0 <fwp_cancel_tree.part.0>
    64f0:	394146a0 	ldrb	w0, [x21, #81]
    64f4:	17ffff6b 	b	62a0 <fwp_main_thread+0x2c0>
    64f8:	d2800013 	mov	x19, #0x0                   	// #0
    64fc:	91014295 	add	x21, x20, #0x50
    6500:	f9414ea0 	ldr	x0, [x21, #664]
    6504:	b5ffe7e0 	cbnz	x0, 6200 <fwp_main_thread+0x220>
    6508:	f94142a0 	ldr	x0, [x21, #640]
    650c:	97fff329 	bl	31b0 <fwp_mem_free>
    6510:	f90142bf 	str	xzr, [x21, #640]
    6514:	f9014abf 	str	xzr, [x21, #656]
    6518:	f94172a0 	ldr	x0, [x21, #736]
    651c:	b4002b73 	cbz	x19, 6a88 <fwp_main_thread+0xaa8>
    6520:	f900567f 	str	xzr, [x19, #168]
    6524:	f9005e7f 	str	xzr, [x19, #184]
    6528:	b902dabf 	str	wzr, [x21, #728]
    652c:	eb00027f 	cmp	x19, x0
    6530:	54ffe740 	b.eq	6218 <fwp_main_thread+0x238>  // b.none
    6534:	97ffec1b 	bl	15a0 <abort@plt>
    6538:	90ffffe0 	adrp	x0, 2000 <ad_raw_report+0x70>
    653c:	911fc000 	add	x0, x0, #0x7f0
    6540:	94000324 	bl	71d0 <atexit>
    6544:	17fffebb 	b	6030 <fwp_main_thread+0x50>
    6548:	97fff103 	bl	2954 <fwp_heap_init>
    654c:	17fffeb6 	b	6024 <fwp_main_thread+0x44>
    6550:	f9413b42 	ldr	x2, [x26, #624]
    6554:	f0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    6558:	912f4021 	add	x1, x1, #0xbd0
    655c:	a90387e2 	stp	x2, x1, [sp, #56]
    6560:	d0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x1a0>
    6564:	f9400be1 	ldr	x1, [sp, #16]
    6568:	91254000 	add	x0, x0, #0x950
    656c:	d2800015 	mov	x21, #0x0                   	// #0
    6570:	d2900019 	mov	x25, #0x8000                	// #32768
    6574:	d2800016 	mov	x22, #0x0                   	// #0
    6578:	390023f7 	strb	w23, [sp, #8]
    657c:	f90027e1 	str	x1, [sp, #72]
    6580:	f9002bff 	str	xzr, [sp, #80]
    6584:	a90603ff 	stp	xzr, x0, [sp, #96]
    6588:	f9013b5c 	str	x28, [x26, #624]
    658c:	14000012 	b	65d4 <fwp_main_thread+0x5f4>
    6590:	7100045f 	cmp	w2, #0x1
    6594:	540001a1 	b.ne	65c8 <fwp_main_thread+0x5e8>  // b.any
    6598:	29430002 	ldp	w2, w0, [x0, #24]
    659c:	92403c21 	and	x1, x1, #0xffff
    65a0:	9b027c21 	mul	x1, x1, x2
    65a4:	d360fc21 	lsr	x1, x1, #32
    65a8:	eb00003f 	cmp	x1, x0
    65ac:	540000e2 	b.cs	65c8 <fwp_main_thread+0x5e8>  // b.hs, b.nlast
    65b0:	8b01039c 	add	x28, x28, x1
    65b4:	39400380 	ldrb	w0, [x28]
    65b8:	7103fc1f 	cmp	w0, #0xff
    65bc:	54002540 	b.eq	6a64 <fwp_main_thread+0xa84>  // b.none
    65c0:	394023e0 	ldrb	w0, [sp, #8]
    65c4:	39000380 	strb	w0, [x28]
    65c8:	f9002bf5 	str	x21, [sp, #80]
    65cc:	aa17035a 	orr	x26, x26, x23
    65d0:	b400041a 	cbz	x26, 6650 <fwp_main_thread+0x670>
    65d4:	f100073a 	subs	x26, x25, #0x1
    65d8:	aa1303e1 	mov	x1, x19
    65dc:	da1f02d7 	sbc	x23, x22, xzr
    65e0:	52800020 	mov	w0, #0x1                   	// #1
    65e4:	f9002ffa 	str	x26, [sp, #88]
    65e8:	aa1a03f9 	mov	x25, x26
    65ec:	a90957fa 	stp	x26, x21, [sp, #144]
    65f0:	97fff61c 	bl	3e60 <fwp_data.part.0.constprop.0>
    65f4:	aa0003f5 	mov	x21, x0
    65f8:	f949db61 	ldr	x1, [x27, #5040]
    65fc:	aa1703f6 	mov	x22, x23
    6600:	f949ef60 	ldr	x0, [x27, #5080]
    6604:	cb0102a1 	sub	x1, x21, x1
    6608:	eb00403f 	cmp	x1, x0, lsl #16
    660c:	54fffde2 	b.cs	65c8 <fwp_main_thread+0x5e8>  // b.hs, b.nlast
    6610:	d350fc20 	lsr	x0, x1, #16
    6614:	f949ff65 	ldr	x5, [x27, #5112]
    6618:	8b000800 	add	x0, x0, x0, lsl #2
    661c:	d37df002 	lsl	x2, x0, #3
    6620:	8b0200a0 	add	x0, x5, x2
    6624:	f940101c 	ldr	x28, [x0, #32]
    6628:	b4fffd1c 	cbz	x28, 65c8 <fwp_main_thread+0x5e8>
    662c:	386268a2 	ldrb	w2, [x5, x2]
    6630:	7100085f 	cmp	w2, #0x2
    6634:	54fffae1 	b.ne	6590 <fwp_main_thread+0x5b0>  // b.any
    6638:	72003c3f 	tst	w1, #0xffff
    663c:	54fffbc0 	b.eq	65b4 <fwp_main_thread+0x5d4>  // b.none
    6640:	f9002bf5 	str	x21, [sp, #80]
    6644:	aa17035a 	orr	x26, x26, x23
    6648:	b5fffc7a 	cbnz	x26, 65d4 <fwp_main_thread+0x5f4>
    664c:	d503201f 	nop
    6650:	b0000000 	adrp	x0, 7000 <__modti3+0x1a0>
    6654:	91014282 	add	x2, x20, #0x50
    6658:	f9401fe3 	ldr	x3, [sp, #56]
    665c:	9101c3e1 	add	x1, sp, #0x70
    6660:	3dc23c00 	ldr	q0, [x0, #2288]
    6664:	52800020 	mov	w0, #0x1                   	// #1
    6668:	f9013843 	str	x3, [x2, #624]
    666c:	3d801fe0 	str	q0, [sp, #112]
    6670:	97fff5fc 	bl	3e60 <fwp_data.part.0.constprop.0>
    6674:	9114c303 	add	x3, x24, #0x530
    6678:	aa0003f6 	mov	x22, x0
    667c:	f949d861 	ldr	x1, [x3, #5040]
    6680:	f949ec60 	ldr	x0, [x3, #5080]
    6684:	cb0102c1 	sub	x1, x22, x1
    6688:	eb00403f 	cmp	x1, x0, lsl #16
    668c:	54000322 	b.cs	66f0 <fwp_main_thread+0x710>  // b.hs, b.nlast
    6690:	d350fc22 	lsr	x2, x1, #16
    6694:	f949fc63 	ldr	x3, [x3, #5112]
    6698:	8b020842 	add	x2, x2, x2, lsl #2
    669c:	d37df042 	lsl	x2, x2, #3
    66a0:	8b020060 	add	x0, x3, x2
    66a4:	f9401017 	ldr	x23, [x0, #32]
    66a8:	b4000257 	cbz	x23, 66f0 <fwp_main_thread+0x710>
    66ac:	38626862 	ldrb	w2, [x3, x2]
    66b0:	7100085f 	cmp	w2, #0x2
    66b4:	54001cc0 	b.eq	6a4c <fwp_main_thread+0xa6c>  // b.none
    66b8:	7100045f 	cmp	w2, #0x1
    66bc:	540001a1 	b.ne	66f0 <fwp_main_thread+0x710>  // b.any
    66c0:	29430002 	ldp	w2, w0, [x0, #24]
    66c4:	92403c21 	and	x1, x1, #0xffff
    66c8:	9b027c21 	mul	x1, x1, x2
    66cc:	d360fc21 	lsr	x1, x1, #32
    66d0:	eb00003f 	cmp	x1, x0
    66d4:	540000e2 	b.cs	66f0 <fwp_main_thread+0x710>  // b.hs, b.nlast
    66d8:	8b0102f7 	add	x23, x23, x1
    66dc:	394002e0 	ldrb	w0, [x23]
    66e0:	7103fc1f 	cmp	w0, #0xff
    66e4:	54001de0 	b.eq	6aa0 <fwp_main_thread+0xac0>  // b.none
    66e8:	52800020 	mov	w0, #0x1                   	// #1
    66ec:	390002e0 	strb	w0, [x23]
    66f0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    66f4:	aa1303e1 	mov	x1, x19
    66f8:	52800020 	mov	w0, #0x1                   	// #1
    66fc:	a9095be2 	stp	x2, x22, [sp, #144]
    6700:	97fff5d8 	bl	3e60 <fwp_data.part.0.constprop.0>
    6704:	9114c303 	add	x3, x24, #0x530
    6708:	aa0003f3 	mov	x19, x0
    670c:	f949d861 	ldr	x1, [x3, #5040]
    6710:	f949ec60 	ldr	x0, [x3, #5080]
    6714:	cb010261 	sub	x1, x19, x1
    6718:	eb00403f 	cmp	x1, x0, lsl #16
    671c:	54000322 	b.cs	6780 <fwp_main_thread+0x7a0>  // b.hs, b.nlast
    6720:	d350fc22 	lsr	x2, x1, #16
    6724:	f949fc63 	ldr	x3, [x3, #5112]
    6728:	8b020842 	add	x2, x2, x2, lsl #2
    672c:	d37df042 	lsl	x2, x2, #3
    6730:	8b020060 	add	x0, x3, x2
    6734:	f9401016 	ldr	x22, [x0, #32]
    6738:	b4000256 	cbz	x22, 6780 <fwp_main_thread+0x7a0>
    673c:	38626862 	ldrb	w2, [x3, x2]
    6740:	7100085f 	cmp	w2, #0x2
    6744:	540018a0 	b.eq	6a58 <fwp_main_thread+0xa78>  // b.none
    6748:	7100045f 	cmp	w2, #0x1
    674c:	540001a1 	b.ne	6780 <fwp_main_thread+0x7a0>  // b.any
    6750:	29430002 	ldp	w2, w0, [x0, #24]
    6754:	92403c21 	and	x1, x1, #0xffff
    6758:	9b027c21 	mul	x1, x1, x2
    675c:	d360fc21 	lsr	x1, x1, #32
    6760:	eb00003f 	cmp	x1, x0
    6764:	540000e2 	b.cs	6780 <fwp_main_thread+0x7a0>  // b.hs, b.nlast
    6768:	8b0102d6 	add	x22, x22, x1
    676c:	394002c0 	ldrb	w0, [x22]
    6770:	7103fc1f 	cmp	w0, #0xff
    6774:	540019c0 	b.eq	6aac <fwp_main_thread+0xacc>  // b.none
    6778:	52800020 	mov	w0, #0x1                   	// #1
    677c:	390002c0 	strb	w0, [x22]
    6780:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6784:	910203e1 	add	x1, sp, #0x80
    6788:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    678c:	52800020 	mov	w0, #0x1                   	// #1
    6790:	a9084fe2 	stp	x2, x19, [sp, #128]
    6794:	97fff5b3 	bl	3e60 <fwp_data.part.0.constprop.0>
    6798:	9114c302 	add	x2, x24, #0x530
    679c:	aa0003e3 	mov	x3, x0
    67a0:	f90007e3 	str	x3, [sp, #8]
    67a4:	f949d841 	ldr	x1, [x2, #5040]
    67a8:	f949ec40 	ldr	x0, [x2, #5080]
    67ac:	cb010061 	sub	x1, x3, x1
    67b0:	eb00403f 	cmp	x1, x0, lsl #16
    67b4:	54000322 	b.cs	6818 <fwp_main_thread+0x838>  // b.hs, b.nlast
    67b8:	d350fc20 	lsr	x0, x1, #16
    67bc:	f949fc43 	ldr	x3, [x2, #5112]
    67c0:	8b000800 	add	x0, x0, x0, lsl #2
    67c4:	d37df002 	lsl	x2, x0, #3
    67c8:	8b020060 	add	x0, x3, x2
    67cc:	f9401013 	ldr	x19, [x0, #32]
    67d0:	b4000253 	cbz	x19, 6818 <fwp_main_thread+0x838>
    67d4:	38626862 	ldrb	w2, [x3, x2]
    67d8:	7100085f 	cmp	w2, #0x2
    67dc:	54001320 	b.eq	6a40 <fwp_main_thread+0xa60>  // b.none
    67e0:	7100045f 	cmp	w2, #0x1
    67e4:	540001a1 	b.ne	6818 <fwp_main_thread+0x838>  // b.any
    67e8:	29430002 	ldp	w2, w0, [x0, #24]
    67ec:	92403c21 	and	x1, x1, #0xffff
    67f0:	9b027c21 	mul	x1, x1, x2
    67f4:	d360fc21 	lsr	x1, x1, #32
    67f8:	eb00003f 	cmp	x1, x0
    67fc:	540000e2 	b.cs	6818 <fwp_main_thread+0x838>  // b.hs, b.nlast
    6800:	8b010273 	add	x19, x19, x1
    6804:	39400260 	ldrb	w0, [x19]
    6808:	7103fc1f 	cmp	w0, #0xff
    680c:	54001440 	b.eq	6a94 <fwp_main_thread+0xab4>  // b.none
    6810:	52800020 	mov	w0, #0x1                   	// #1
    6814:	39000260 	strb	w0, [x19]
    6818:	aa1503f7 	mov	x23, x21
    681c:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x165f8>
    6820:	b4000f95 	cbz	x21, 6a10 <fwp_main_thread+0xa30>
    6824:	912ae000 	add	x0, x0, #0xab8
    6828:	b000001c 	adrp	x28, 7000 <__modti3+0x1a0>
    682c:	91014000 	add	x0, x0, #0x50
    6830:	91014299 	add	x25, x20, #0x50
    6834:	f9000fe0 	str	x0, [sp, #24]
    6838:	91090380 	add	x0, x28, #0x240
    683c:	9114c31c 	add	x28, x24, #0x530
    6840:	f90013e0 	str	x0, [sp, #32]
    6844:	1400005d 	b	69b8 <fwp_main_thread+0x9d8>
    6848:	7100045f 	cmp	w2, #0x1
    684c:	54000261 	b.ne	6898 <fwp_main_thread+0x8b8>  // b.any
    6850:	29430865 	ldp	w5, w2, [x3, #24]
    6854:	92403c21 	and	x1, x1, #0xffff
    6858:	9b057c21 	mul	x1, x1, x5
    685c:	d360fc21 	lsr	x1, x1, #32
    6860:	eb02003f 	cmp	x1, x2
    6864:	540001a2 	b.cs	6898 <fwp_main_thread+0x8b8>  // b.hs, b.nlast
    6868:	8b010000 	add	x0, x0, x1
    686c:	39400001 	ldrb	w1, [x0]
    6870:	34000141 	cbz	w1, 6898 <fwp_main_thread+0x8b8>
    6874:	b9404322 	ldr	w2, [x25, #64]
    6878:	34000082 	cbz	w2, 6888 <fwp_main_thread+0x8a8>
    687c:	f9402722 	ldr	x2, [x25, #72]
    6880:	91000442 	add	x2, x2, #0x1
    6884:	f9002722 	str	x2, [x25, #72]
    6888:	7103f43f 	cmp	w1, #0xfd
    688c:	54000fa8 	b.hi	6a80 <fwp_main_thread+0xaa0>  // b.pmore
    6890:	11000421 	add	w1, w1, #0x1
    6894:	39000001 	strb	w1, [x0]
    6898:	f94007e0 	ldr	x0, [sp, #8]
    689c:	52800023 	mov	w3, #0x1                   	// #1
    68a0:	97fff82d 	bl	4954 <fwp_loop_fields68.constprop.0>
    68a4:	aa0003e1 	mov	x1, x0
    68a8:	aa0003f6 	mov	x22, x0
    68ac:	a9057fff 	stp	xzr, xzr, [sp, #80]
    68b0:	a9410be0 	ldp	x0, x2, [sp, #16]
    68b4:	f90033ff 	str	xzr, [sp, #96]
    68b8:	97fff9ce 	bl	4ff0 <fwp_write>
    68bc:	a9456bfb 	ldp	x27, x26, [sp, #80]
    68c0:	f94013e0 	ldr	x0, [sp, #32]
    68c4:	f100037f 	cmp	x27, #0x0
    68c8:	9a9b001b 	csel	x27, x0, x27, eq	// eq = none
    68cc:	b1002b5f 	cmn	x26, #0xa
    68d0:	54000fa8 	b.hi	6ac4 <fwp_main_thread+0xae4>  // b.pmore
    68d4:	52800021 	mov	w1, #0x1                   	// #1
    68d8:	91002740 	add	x0, x26, #0x9
    68dc:	97fff68d 	bl	4310 <fwp_heap_alloc>
    68e0:	aa0003f3 	mov	x19, x0
    68e4:	aa1b03e1 	mov	x1, x27
    68e8:	aa0003fb 	mov	x27, x0
    68ec:	aa1a03e2 	mov	x2, x26
    68f0:	f800877a 	str	x26, [x27], #8
    68f4:	aa1b03e0 	mov	x0, x27
    68f8:	97ffeaae 	bl	13b0 <memcpy@plt>
    68fc:	8b1a0262 	add	x2, x19, x26
    6900:	3900205f 	strb	wzr, [x2, #8]
    6904:	f9402be0 	ldr	x0, [sp, #80]
    6908:	97ffeb42 	bl	1610 <free@plt>
    690c:	f949db81 	ldr	x1, [x28, #5040]
    6910:	f949ef80 	ldr	x0, [x28, #5080]
    6914:	cb010261 	sub	x1, x19, x1
    6918:	eb00403f 	cmp	x1, x0, lsl #16
    691c:	54000322 	b.cs	6980 <fwp_main_thread+0x9a0>  // b.hs, b.nlast
    6920:	d350fc20 	lsr	x0, x1, #16
    6924:	f949ff86 	ldr	x6, [x28, #5112]
    6928:	8b000800 	add	x0, x0, x0, lsl #2
    692c:	d37df002 	lsl	x2, x0, #3
    6930:	8b0200c3 	add	x3, x6, x2
    6934:	f9401060 	ldr	x0, [x3, #32]
    6938:	b4000240 	cbz	x0, 6980 <fwp_main_thread+0x9a0>
    693c:	386268c2 	ldrb	w2, [x6, x2]
    6940:	7100085f 	cmp	w2, #0x2
    6944:	54000600 	b.eq	6a04 <fwp_main_thread+0xa24>  // b.none
    6948:	7100045f 	cmp	w2, #0x1
    694c:	540001a1 	b.ne	6980 <fwp_main_thread+0x9a0>  // b.any
    6950:	29430866 	ldp	w6, w2, [x3, #24]
    6954:	92403c21 	and	x1, x1, #0xffff
    6958:	9b067c21 	mul	x1, x1, x6
    695c:	d360fc21 	lsr	x1, x1, #32
    6960:	eb02003f 	cmp	x1, x2
    6964:	540000e2 	b.cs	6980 <fwp_main_thread+0x9a0>  // b.hs, b.nlast
    6968:	8b010000 	add	x0, x0, x1
    696c:	39400001 	ldrb	w1, [x0]
    6970:	7103fc3f 	cmp	w1, #0xff
    6974:	540007e0 	b.eq	6a70 <fwp_main_thread+0xa90>  // b.none
    6978:	52800021 	mov	w1, #0x1                   	// #1
    697c:	39000001 	strb	w1, [x0]
    6980:	aa1603e0 	mov	x0, x22
    6984:	97fff77f 	bl	4780 <fwp_drop0>
    6988:	f9400262 	ldr	x2, [x19]
    698c:	d2800021 	mov	x1, #0x1                   	// #1
    6990:	f9400323 	ldr	x3, [x25]
    6994:	aa1b03e0 	mov	x0, x27
    6998:	97ffeb2e 	bl	1650 <fwrite@plt>
    699c:	f9400321 	ldr	x1, [x25]
    69a0:	52800140 	mov	w0, #0xa                   	// #10
    69a4:	97ffeab3 	bl	1470 <fputc@plt>
    69a8:	aa1303e0 	mov	x0, x19
    69ac:	97fff6e1 	bl	4530 <fwp_drop4>
    69b0:	f9400af7 	ldr	x23, [x23, #16]
    69b4:	b40002f7 	cbz	x23, 6a10 <fwp_main_thread+0xa30>
    69b8:	f94007e2 	ldr	x2, [sp, #8]
    69bc:	f949db81 	ldr	x1, [x28, #5040]
    69c0:	f949ef80 	ldr	x0, [x28, #5080]
    69c4:	cb010041 	sub	x1, x2, x1
    69c8:	eb00403f 	cmp	x1, x0, lsl #16
    69cc:	54fff662 	b.cs	6898 <fwp_main_thread+0x8b8>  // b.hs, b.nlast
    69d0:	d350fc20 	lsr	x0, x1, #16
    69d4:	f949ff85 	ldr	x5, [x28, #5112]
    69d8:	8b000800 	add	x0, x0, x0, lsl #2
    69dc:	d37df002 	lsl	x2, x0, #3
    69e0:	8b0200a3 	add	x3, x5, x2
    69e4:	f9401060 	ldr	x0, [x3, #32]
    69e8:	b4fff580 	cbz	x0, 6898 <fwp_main_thread+0x8b8>
    69ec:	386268a2 	ldrb	w2, [x5, x2]
    69f0:	7100085f 	cmp	w2, #0x2
    69f4:	54fff2a1 	b.ne	6848 <fwp_main_thread+0x868>  // b.any
    69f8:	72003c3f 	tst	w1, #0xffff
    69fc:	54fff4e1 	b.ne	6898 <fwp_main_thread+0x8b8>  // b.any
    6a00:	17ffff9b 	b	686c <fwp_main_thread+0x88c>
    6a04:	72003c3f 	tst	w1, #0xffff
    6a08:	54fffbc1 	b.ne	6980 <fwp_main_thread+0x9a0>  // b.any
    6a0c:	17ffffd8 	b	696c <fwp_main_thread+0x98c>
    6a10:	f94007e0 	ldr	x0, [sp, #8]
    6a14:	97fff75b 	bl	4780 <fwp_drop0>
    6a18:	aa1503e0 	mov	x0, x21
    6a1c:	97fff759 	bl	4780 <fwp_drop0>
    6a20:	91014280 	add	x0, x20, #0x50
    6a24:	52800021 	mov	w1, #0x1                   	// #1
    6a28:	b902c801 	str	w1, [x0, #712]
    6a2c:	f901681f 	str	xzr, [x0, #720]
    6a30:	17fffdb6 	b	6108 <fwp_main_thread+0x128>
    6a34:	aa0003e1 	mov	x1, x0
    6a38:	f90022b3 	str	x19, [x21, #64]
    6a3c:	17fffdcb 	b	6168 <fwp_main_thread+0x188>
    6a40:	72003c3f 	tst	w1, #0xffff
    6a44:	54ffeea1 	b.ne	6818 <fwp_main_thread+0x838>  // b.any
    6a48:	17ffff6f 	b	6804 <fwp_main_thread+0x824>
    6a4c:	72003c3f 	tst	w1, #0xffff
    6a50:	54ffe501 	b.ne	66f0 <fwp_main_thread+0x710>  // b.any
    6a54:	17ffff22 	b	66dc <fwp_main_thread+0x6fc>
    6a58:	72003c3f 	tst	w1, #0xffff
    6a5c:	54ffe921 	b.ne	6780 <fwp_main_thread+0x7a0>  // b.any
    6a60:	17ffff43 	b	676c <fwp_main_thread+0x78c>
    6a64:	aa1c03e0 	mov	x0, x28
    6a68:	97fff132 	bl	2f30 <fwp_rc_forget_slot>
    6a6c:	17fffed5 	b	65c0 <fwp_main_thread+0x5e0>
    6a70:	f90017e0 	str	x0, [sp, #40]
    6a74:	97fff12f 	bl	2f30 <fwp_rc_forget_slot>
    6a78:	f94017e0 	ldr	x0, [sp, #40]
    6a7c:	17ffffbf 	b	6978 <fwp_main_thread+0x998>
    6a80:	97fff0e5 	bl	2e14 <fwp_rc_wide_dup>
    6a84:	17ffff85 	b	6898 <fwp_main_thread+0x8b8>
    6a88:	b902dabf 	str	wzr, [x21, #728]
    6a8c:	b4ffc560 	cbz	x0, 6338 <fwp_main_thread+0x358>
    6a90:	97ffeac4 	bl	15a0 <abort@plt>
    6a94:	aa1303e0 	mov	x0, x19
    6a98:	97fff126 	bl	2f30 <fwp_rc_forget_slot>
    6a9c:	17ffff5d 	b	6810 <fwp_main_thread+0x830>
    6aa0:	aa1703e0 	mov	x0, x23
    6aa4:	97fff123 	bl	2f30 <fwp_rc_forget_slot>
    6aa8:	17ffff10 	b	66e8 <fwp_main_thread+0x708>
    6aac:	aa1603e0 	mov	x0, x22
    6ab0:	97fff120 	bl	2f30 <fwp_rc_forget_slot>
    6ab4:	17ffff31 	b	6778 <fwp_main_thread+0x798>
    6ab8:	b0000000 	adrp	x0, 7000 <__modti3+0x1a0>
    6abc:	9119a000 	add	x0, x0, #0x668
    6ac0:	97ffee10 	bl	2300 <fwp_trap>
    6ac4:	b0000000 	adrp	x0, 7000 <__modti3+0x1a0>
    6ac8:	911ac000 	add	x0, x0, #0x6b0
    6acc:	97ffee0d 	bl	2300 <fwp_trap>
    6ad0:	97ffeaa0 	bl	1550 <__stack_chk_fail@plt>
    6ad4:	b0000000 	adrp	x0, 7000 <__modti3+0x1a0>
    6ad8:	911a4000 	add	x0, x0, #0x690
    6adc:	97ffed21 	bl	1f60 <ad_raw_fail>

0000000000006ae0 <__divti3>:
    6ae0:	d503245f 	bti	c
    6ae4:	d2800004 	mov	x4, #0x0                   	// #0
    6ae8:	b7f80721 	tbnz	x1, #63, 6bcc <__divti3+0xec>
    6aec:	b6f80083 	tbz	x3, #63, 6afc <__divti3+0x1c>
    6af0:	eb0203e2 	negs	x2, x2
    6af4:	aa2403e4 	mvn	x4, x4
    6af8:	da0303e3 	ngc	x3, x3
    6afc:	aa0203e6 	mov	x6, x2
    6b00:	aa0003e7 	mov	x7, x0
    6b04:	aa0103e5 	mov	x5, x1
    6b08:	b5000583 	cbnz	x3, 6bb8 <__divti3+0xd8>
    6b0c:	eb01005f 	cmp	x2, x1
    6b10:	54000e69 	b.ls	6cdc <__divti3+0x1fc>  // b.plast
    6b14:	dac01040 	clz	x0, x2
    6b18:	b40000e0 	cbz	x0, 6b34 <__divti3+0x54>
    6b1c:	4b0003e1 	neg	w1, w0
    6b20:	9ac020a5 	lsl	x5, x5, x0
    6b24:	9ac02046 	lsl	x6, x2, x0
    6b28:	9ac124e1 	lsr	x1, x7, x1
    6b2c:	aa050025 	orr	x5, x1, x5
    6b30:	9ac020e7 	lsl	x7, x7, x0
    6b34:	d360fcc8 	lsr	x8, x6, #32
    6b38:	92407cc2 	and	x2, x6, #0xffffffff
    6b3c:	9ac808a3 	udiv	x3, x5, x8
    6b40:	9b089465 	msub	x5, x3, x8, x5
    6b44:	aa0303e0 	mov	x0, x3
    6b48:	9b037c41 	mul	x1, x2, x3
    6b4c:	93c780a5 	extr	x5, x5, x7, #32
    6b50:	eb05003f 	cmp	x1, x5
    6b54:	540000a9 	b.ls	6b68 <__divti3+0x88>  // b.plast
    6b58:	ab0500c5 	adds	x5, x6, x5
    6b5c:	d1000460 	sub	x0, x3, #0x1
    6b60:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    6b64:	540015a8 	b.hi	6e18 <__divti3+0x338>  // b.pmore
    6b68:	cb0100a5 	sub	x5, x5, x1
    6b6c:	9ac808a3 	udiv	x3, x5, x8
    6b70:	9b089465 	msub	x5, x3, x8, x5
    6b74:	aa0303e1 	mov	x1, x3
    6b78:	9b037c42 	mul	x2, x2, x3
    6b7c:	aa0703e3 	mov	x3, x7
    6b80:	b3607ca3 	bfi	x3, x5, #32, #32
    6b84:	eb03005f 	cmp	x2, x3
    6b88:	540000c9 	b.ls	6ba0 <__divti3+0xc0>  // b.plast
    6b8c:	ab0300c3 	adds	x3, x6, x3
    6b90:	d1000425 	sub	x5, x1, #0x1
    6b94:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    6b98:	d1000821 	sub	x1, x1, #0x2
    6b9c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    6ba0:	aa008020 	orr	x0, x1, x0, lsl #32
    6ba4:	d2800001 	mov	x1, #0x0                   	// #0
    6ba8:	b4000064 	cbz	x4, 6bb4 <__divti3+0xd4>
    6bac:	eb0003e0 	negs	x0, x0
    6bb0:	da0103e1 	ngc	x1, x1
    6bb4:	d65f03c0 	ret
    6bb8:	eb01007f 	cmp	x3, x1
    6bbc:	54000109 	b.ls	6bdc <__divti3+0xfc>  // b.plast
    6bc0:	d2800001 	mov	x1, #0x0                   	// #0
    6bc4:	d2800000 	mov	x0, #0x0                   	// #0
    6bc8:	17fffff8 	b	6ba8 <__divti3+0xc8>
    6bcc:	eb0003e0 	negs	x0, x0
    6bd0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    6bd4:	da0103e1 	ngc	x1, x1
    6bd8:	17ffffc5 	b	6aec <__divti3+0xc>
    6bdc:	dac01067 	clz	x7, x3
    6be0:	b40010e7 	cbz	x7, 6dfc <__divti3+0x31c>
    6be4:	d2800805 	mov	x5, #0x40                  	// #64
    6be8:	cb0700a5 	sub	x5, x5, x7
    6bec:	9ac72063 	lsl	x3, x3, x7
    6bf0:	9ac52448 	lsr	x8, x2, x5
    6bf4:	aa030108 	orr	x8, x8, x3
    6bf8:	9ac52426 	lsr	x6, x1, x5
    6bfc:	92407d0a 	and	x10, x8, #0xffffffff
    6c00:	d360fd09 	lsr	x9, x8, #32
    6c04:	9ac52403 	lsr	x3, x0, x5
    6c08:	9ac72021 	lsl	x1, x1, x7
    6c0c:	aa010063 	orr	x3, x3, x1
    6c10:	9ac72042 	lsl	x2, x2, x7
    6c14:	9ac908cb 	udiv	x11, x6, x9
    6c18:	9b099965 	msub	x5, x11, x9, x6
    6c1c:	aa0b03e1 	mov	x1, x11
    6c20:	9b0b7d46 	mul	x6, x10, x11
    6c24:	93c380a5 	extr	x5, x5, x3, #32
    6c28:	eb0500df 	cmp	x6, x5
    6c2c:	540000a9 	b.ls	6c40 <__divti3+0x160>  // b.plast
    6c30:	ab050105 	adds	x5, x8, x5
    6c34:	d1000561 	sub	x1, x11, #0x1
    6c38:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    6c3c:	54000f48 	b.hi	6e24 <__divti3+0x344>  // b.pmore
    6c40:	cb0600a6 	sub	x6, x5, x6
    6c44:	9ac908cb 	udiv	x11, x6, x9
    6c48:	9b099969 	msub	x9, x11, x9, x6
    6c4c:	aa0b03e5 	mov	x5, x11
    6c50:	9b0b7d4a 	mul	x10, x10, x11
    6c54:	b3607d23 	bfi	x3, x9, #32, #32
    6c58:	eb03015f 	cmp	x10, x3
    6c5c:	540000a9 	b.ls	6c70 <__divti3+0x190>  // b.plast
    6c60:	ab030103 	adds	x3, x8, x3
    6c64:	d1000565 	sub	x5, x11, #0x1
    6c68:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    6c6c:	54000e28 	b.hi	6e30 <__divti3+0x350>  // b.pmore
    6c70:	aa0180a1 	orr	x1, x5, x1, lsl #32
    6c74:	92407c48 	and	x8, x2, #0xffffffff
    6c78:	2a0503e5 	mov	w5, w5
    6c7c:	d360fc42 	lsr	x2, x2, #32
    6c80:	d360fc26 	lsr	x6, x1, #32
    6c84:	cb0a0063 	sub	x3, x3, x10
    6c88:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    6c8c:	9b087caa 	mul	x10, x5, x8
    6c90:	9b087cc8 	mul	x8, x6, x8
    6c94:	9b0220a5 	madd	x5, x5, x2, x8
    6c98:	9b027cc6 	mul	x6, x6, x2
    6c9c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    6ca0:	8b0900c5 	add	x5, x6, x9
    6ca4:	eb02011f 	cmp	x8, x2
    6ca8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    6cac:	8b4280c6 	add	x6, x6, x2, lsr #32
    6cb0:	eb06007f 	cmp	x3, x6
    6cb4:	540000e3 	b.cc	6cd0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    6cb8:	92407d4a 	and	x10, x10, #0xffffffff
    6cbc:	9ac72000 	lsl	x0, x0, x7
    6cc0:	8b028142 	add	x2, x10, x2, lsl #32
    6cc4:	eb02001f 	cmp	x0, x2
    6cc8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    6ccc:	54000a01 	b.ne	6e0c <__divti3+0x32c>  // b.any
    6cd0:	d1000420 	sub	x0, x1, #0x1
    6cd4:	d2800001 	mov	x1, #0x0                   	// #0
    6cd8:	17ffffb4 	b	6ba8 <__divti3+0xc8>
    6cdc:	b5000062 	cbnz	x2, 6ce8 <__divti3+0x208>
    6ce0:	d2800022 	mov	x2, #0x1                   	// #1
    6ce4:	9ac30846 	udiv	x6, x2, x3
    6ce8:	dac010c8 	clz	x8, x6
    6cec:	b5000408 	cbnz	x8, 6d6c <__divti3+0x28c>
    6cf0:	d360fcc9 	lsr	x9, x6, #32
    6cf4:	92407cc5 	and	x5, x6, #0xffffffff
    6cf8:	cb060023 	sub	x3, x1, x6
    6cfc:	d2800021 	mov	x1, #0x1                   	// #1
    6d00:	9ac90868 	udiv	x8, x3, x9
    6d04:	9b098d03 	msub	x3, x8, x9, x3
    6d08:	aa0803e0 	mov	x0, x8
    6d0c:	9b057d02 	mul	x2, x8, x5
    6d10:	93c78063 	extr	x3, x3, x7, #32
    6d14:	eb03005f 	cmp	x2, x3
    6d18:	540000a9 	b.ls	6d2c <__divti3+0x24c>  // b.plast
    6d1c:	ab0300c3 	adds	x3, x6, x3
    6d20:	d1000500 	sub	x0, x8, #0x1
    6d24:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    6d28:	54000968 	b.hi	6e54 <__divti3+0x374>  // b.pmore
    6d2c:	cb020063 	sub	x3, x3, x2
    6d30:	9ac90862 	udiv	x2, x3, x9
    6d34:	aa0203e8 	mov	x8, x2
    6d38:	9b098c42 	msub	x2, x2, x9, x3
    6d3c:	aa0703e3 	mov	x3, x7
    6d40:	9b057d05 	mul	x5, x8, x5
    6d44:	b3607c43 	bfi	x3, x2, #32, #32
    6d48:	eb0300bf 	cmp	x5, x3
    6d4c:	540000c9 	b.ls	6d64 <__divti3+0x284>  // b.plast
    6d50:	ab0300c2 	adds	x2, x6, x3
    6d54:	d1000503 	sub	x3, x8, #0x1
    6d58:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    6d5c:	d1000908 	sub	x8, x8, #0x2
    6d60:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    6d64:	aa008100 	orr	x0, x8, x0, lsl #32
    6d68:	17ffff90 	b	6ba8 <__divti3+0xc8>
    6d6c:	9ac820c6 	lsl	x6, x6, x8
    6d70:	d2800803 	mov	x3, #0x40                  	// #64
    6d74:	cb080063 	sub	x3, x3, x8
    6d78:	d360fcc9 	lsr	x9, x6, #32
    6d7c:	9ac82027 	lsl	x7, x1, x8
    6d80:	92407cc5 	and	x5, x6, #0xffffffff
    6d84:	9ac32422 	lsr	x2, x1, x3
    6d88:	9ac32403 	lsr	x3, x0, x3
    6d8c:	aa070063 	orr	x3, x3, x7
    6d90:	9ac9084a 	udiv	x10, x2, x9
    6d94:	9ac82007 	lsl	x7, x0, x8
    6d98:	9b098940 	msub	x0, x10, x9, x2
    6d9c:	aa0a03e1 	mov	x1, x10
    6da0:	9b0a7ca2 	mul	x2, x5, x10
    6da4:	93c38000 	extr	x0, x0, x3, #32
    6da8:	eb00005f 	cmp	x2, x0
    6dac:	540000a9 	b.ls	6dc0 <__divti3+0x2e0>  // b.plast
    6db0:	ab0000c0 	adds	x0, x6, x0
    6db4:	d1000541 	sub	x1, x10, #0x1
    6db8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    6dbc:	54000468 	b.hi	6e48 <__divti3+0x368>  // b.pmore
    6dc0:	cb020000 	sub	x0, x0, x2
    6dc4:	9ac9080a 	udiv	x10, x0, x9
    6dc8:	9b098140 	msub	x0, x10, x9, x0
    6dcc:	aa0a03e2 	mov	x2, x10
    6dd0:	9b0a7ca8 	mul	x8, x5, x10
    6dd4:	b3607c03 	bfi	x3, x0, #32, #32
    6dd8:	eb03011f 	cmp	x8, x3
    6ddc:	540000a9 	b.ls	6df0 <__divti3+0x310>  // b.plast
    6de0:	ab0300c3 	adds	x3, x6, x3
    6de4:	d1000542 	sub	x2, x10, #0x1
    6de8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    6dec:	54000288 	b.hi	6e3c <__divti3+0x35c>  // b.pmore
    6df0:	cb080063 	sub	x3, x3, x8
    6df4:	aa018041 	orr	x1, x2, x1, lsl #32
    6df8:	17ffffc2 	b	6d00 <__divti3+0x220>
    6dfc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    6e00:	d2800001 	mov	x1, #0x0                   	// #0
    6e04:	9a9f87e0 	cset	x0, ls	// ls = plast
    6e08:	17ffff68 	b	6ba8 <__divti3+0xc8>
    6e0c:	aa0103e0 	mov	x0, x1
    6e10:	d2800001 	mov	x1, #0x0                   	// #0
    6e14:	17ffff65 	b	6ba8 <__divti3+0xc8>
    6e18:	d1000860 	sub	x0, x3, #0x2
    6e1c:	8b0600a5 	add	x5, x5, x6
    6e20:	17ffff52 	b	6b68 <__divti3+0x88>
    6e24:	d1000961 	sub	x1, x11, #0x2
    6e28:	8b0800a5 	add	x5, x5, x8
    6e2c:	17ffff85 	b	6c40 <__divti3+0x160>
    6e30:	d1000965 	sub	x5, x11, #0x2
    6e34:	8b080063 	add	x3, x3, x8
    6e38:	17ffff8e 	b	6c70 <__divti3+0x190>
    6e3c:	d1000942 	sub	x2, x10, #0x2
    6e40:	8b060063 	add	x3, x3, x6
    6e44:	17ffffeb 	b	6df0 <__divti3+0x310>
    6e48:	d1000941 	sub	x1, x10, #0x2
    6e4c:	8b060000 	add	x0, x0, x6
    6e50:	17ffffdc 	b	6dc0 <__divti3+0x2e0>
    6e54:	d1000900 	sub	x0, x8, #0x2
    6e58:	8b060063 	add	x3, x3, x6
    6e5c:	17ffffb4 	b	6d2c <__divti3+0x24c>

0000000000006e60 <__modti3>:
    6e60:	d503245f 	bti	c
    6e64:	d2800004 	mov	x4, #0x0                   	// #0
    6e68:	b6f80081 	tbz	x1, #63, 6e78 <__modti3+0x18>
    6e6c:	eb0003e0 	negs	x0, x0
    6e70:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    6e74:	da0103e1 	ngc	x1, x1
    6e78:	f100007f 	cmp	x3, #0x0
    6e7c:	5400128b 	b.lt	70cc <__modti3+0x26c>  // b.tstop
    6e80:	aa0003e7 	mov	x7, x0
    6e84:	aa0103e6 	mov	x6, x1
    6e88:	540004e1 	b.ne	6f24 <__modti3+0xc4>  // b.any
    6e8c:	eb02003f 	cmp	x1, x2
    6e90:	54000dc2 	b.cs	7048 <__modti3+0x1e8>  // b.hs, b.nlast
    6e94:	dac01043 	clz	x3, x2
    6e98:	aa0303e5 	mov	x5, x3
    6e9c:	b40000e3 	cbz	x3, 6eb8 <__modti3+0x58>
    6ea0:	4b0303e6 	neg	w6, w3
    6ea4:	9ac32021 	lsl	x1, x1, x3
    6ea8:	9ac32042 	lsl	x2, x2, x3
    6eac:	9ac62406 	lsr	x6, x0, x6
    6eb0:	aa0100c6 	orr	x6, x6, x1
    6eb4:	9ac32007 	lsl	x7, x0, x3
    6eb8:	d360fc40 	lsr	x0, x2, #32
    6ebc:	92407c43 	and	x3, x2, #0xffffffff
    6ec0:	9ac008c1 	udiv	x1, x6, x0
    6ec4:	9b009826 	msub	x6, x1, x0, x6
    6ec8:	9b017c61 	mul	x1, x3, x1
    6ecc:	93c780c6 	extr	x6, x6, x7, #32
    6ed0:	eb06003f 	cmp	x1, x6
    6ed4:	540000a9 	b.ls	6ee8 <__modti3+0x88>  // b.plast
    6ed8:	ab060046 	adds	x6, x2, x6
    6edc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    6ee0:	8b0200c8 	add	x8, x6, x2
    6ee4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    6ee8:	cb0100c6 	sub	x6, x6, x1
    6eec:	9ac008c8 	udiv	x8, x6, x0
    6ef0:	9b009901 	msub	x1, x8, x0, x6
    6ef4:	aa0703e0 	mov	x0, x7
    6ef8:	9b087c63 	mul	x3, x3, x8
    6efc:	b3607c20 	bfi	x0, x1, #32, #32
    6f00:	eb00007f 	cmp	x3, x0
    6f04:	54001088 	b.hi	7114 <__modti3+0x2b4>  // b.pmore
    6f08:	cb030000 	sub	x0, x0, x3
    6f0c:	9ac52400 	lsr	x0, x0, x5
    6f10:	d2800001 	mov	x1, #0x0                   	// #0
    6f14:	b4000064 	cbz	x4, 6f20 <__modti3+0xc0>
    6f18:	eb0003e0 	negs	x0, x0
    6f1c:	da0103e1 	ngc	x1, x1
    6f20:	d65f03c0 	ret
    6f24:	dac01066 	clz	x6, x3
    6f28:	eb03003f 	cmp	x1, x3
    6f2c:	54ffff43 	b.cc	6f14 <__modti3+0xb4>  // b.lo, b.ul, b.last
    6f30:	93407cc5 	sxtw	x5, w6
    6f34:	d2800808 	mov	x8, #0x40                  	// #64
    6f38:	cb050108 	sub	x8, x8, x5
    6f3c:	9ac62063 	lsl	x3, x3, x6
    6f40:	9ac62025 	lsl	x5, x1, x6
    6f44:	9ac82447 	lsr	x7, x2, x8
    6f48:	aa0300e7 	orr	x7, x7, x3
    6f4c:	9ac82423 	lsr	x3, x1, x8
    6f50:	92407cec 	and	x12, x7, #0xffffffff
    6f54:	d360fcea 	lsr	x10, x7, #32
    6f58:	9ac82401 	lsr	x1, x0, x8
    6f5c:	aa050021 	orr	x1, x1, x5
    6f60:	9ac62042 	lsl	x2, x2, x6
    6f64:	9ac62000 	lsl	x0, x0, x6
    6f68:	9aca086b 	udiv	x11, x3, x10
    6f6c:	9b0a8d63 	msub	x3, x11, x10, x3
    6f70:	aa0b03e5 	mov	x5, x11
    6f74:	9b0b7d89 	mul	x9, x12, x11
    6f78:	93c18063 	extr	x3, x3, x1, #32
    6f7c:	eb03013f 	cmp	x9, x3
    6f80:	540000a9 	b.ls	6f94 <__modti3+0x134>  // b.plast
    6f84:	ab0300e3 	adds	x3, x7, x3
    6f88:	d1000565 	sub	x5, x11, #0x1
    6f8c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    6f90:	54001168 	b.hi	71bc <__modti3+0x35c>  // b.pmore
    6f94:	cb090063 	sub	x3, x3, x9
    6f98:	9aca086b 	udiv	x11, x3, x10
    6f9c:	9b0a8d6a 	msub	x10, x11, x10, x3
    6fa0:	aa0b03e9 	mov	x9, x11
    6fa4:	9b0b7d8c 	mul	x12, x12, x11
    6fa8:	b3607d41 	bfi	x1, x10, #32, #32
    6fac:	eb01019f 	cmp	x12, x1
    6fb0:	540000a9 	b.ls	6fc4 <__modti3+0x164>  // b.plast
    6fb4:	ab0100e1 	adds	x1, x7, x1
    6fb8:	d1000569 	sub	x9, x11, #0x1
    6fbc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    6fc0:	54000f88 	b.hi	71b0 <__modti3+0x350>  // b.pmore
    6fc4:	aa058123 	orr	x3, x9, x5, lsl #32
    6fc8:	92407c4b 	and	x11, x2, #0xffffffff
    6fcc:	2a0903e9 	mov	w9, w9
    6fd0:	d360fc4a 	lsr	x10, x2, #32
    6fd4:	d360fc63 	lsr	x3, x3, #32
    6fd8:	cb0c0021 	sub	x1, x1, x12
    6fdc:	aa0a03ec 	mov	x12, x10
    6fe0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    6fe4:	9b0b7d25 	mul	x5, x9, x11
    6fe8:	9b0b7c6b 	mul	x11, x3, x11
    6fec:	9b0a2d29 	madd	x9, x9, x10, x11
    6ff0:	92407caa 	and	x10, x5, #0xffffffff
    6ff4:	9b0c7c63 	mul	x3, x3, x12
    6ff8:	8b458125 	add	x5, x9, x5, lsr #32
    6ffc:	8b0d0069 	add	x9, x3, x13
    7000:	eb05017f 	cmp	x11, x5
    7004:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    7008:	8b058149 	add	x9, x10, x5, lsl #32
    700c:	8b458063 	add	x3, x3, x5, lsr #32
    7010:	eb03003f 	cmp	x1, x3
    7014:	54000063 	b.cc	7020 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    7018:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    701c:	54000082 	b.cs	702c <__modti3+0x1cc>  // b.hs, b.nlast
    7020:	eb020129 	subs	x9, x9, x2
    7024:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    7028:	cb070063 	sub	x3, x3, x7
    702c:	eb090000 	subs	x0, x0, x9
    7030:	da030021 	sbc	x1, x1, x3
    7034:	9ac62400 	lsr	x0, x0, x6
    7038:	9ac82028 	lsl	x8, x1, x8
    703c:	aa000100 	orr	x0, x8, x0
    7040:	9ac62421 	lsr	x1, x1, x6
    7044:	17ffffb4 	b	6f14 <__modti3+0xb4>
    7048:	b5000062 	cbnz	x2, 7054 <__modti3+0x1f4>
    704c:	d2800023 	mov	x3, #0x1                   	// #1
    7050:	9ac20862 	udiv	x2, x3, x2
    7054:	dac01048 	clz	x8, x2
    7058:	aa0803e5 	mov	x5, x8
    705c:	b5000668 	cbnz	x8, 7128 <__modti3+0x2c8>
    7060:	cb020020 	sub	x0, x1, x2
    7064:	d360fc49 	lsr	x9, x2, #32
    7068:	92407c4a 	and	x10, x2, #0xffffffff
    706c:	9ac90801 	udiv	x1, x0, x9
    7070:	9b098020 	msub	x0, x1, x9, x0
    7074:	9b0a7c21 	mul	x1, x1, x10
    7078:	93c78000 	extr	x0, x0, x7, #32
    707c:	eb00003f 	cmp	x1, x0
    7080:	540000a9 	b.ls	7094 <__modti3+0x234>  // b.plast
    7084:	ab000040 	adds	x0, x2, x0
    7088:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    708c:	8b020003 	add	x3, x0, x2
    7090:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    7094:	cb010001 	sub	x1, x0, x1
    7098:	9ac90820 	udiv	x0, x1, x9
    709c:	9b098403 	msub	x3, x0, x9, x1
    70a0:	aa0703e1 	mov	x1, x7
    70a4:	9b0a7c00 	mul	x0, x0, x10
    70a8:	b3607c61 	bfi	x1, x3, #32, #32
    70ac:	eb01001f 	cmp	x0, x1
    70b0:	540000a9 	b.ls	70c4 <__modti3+0x264>  // b.plast
    70b4:	ab010041 	adds	x1, x2, x1
    70b8:	8b020022 	add	x2, x1, x2
    70bc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    70c0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    70c4:	cb000020 	sub	x0, x1, x0
    70c8:	17ffff91 	b	6f0c <__modti3+0xac>
    70cc:	eb0203e5 	negs	x5, x2
    70d0:	aa0003e7 	mov	x7, x0
    70d4:	da0303e8 	ngc	x8, x3
    70d8:	aa0503e2 	mov	x2, x5
    70dc:	aa0803e3 	mov	x3, x8
    70e0:	aa0103e6 	mov	x6, x1
    70e4:	b4ffed48 	cbz	x8, 6e8c <__modti3+0x2c>
    70e8:	eb01011f 	cmp	x8, x1
    70ec:	54fff148 	b.hi	6f14 <__modti3+0xb4>  // b.pmore
    70f0:	dac01109 	clz	x9, x8
    70f4:	2a0903e6 	mov	w6, w9
    70f8:	b5fff1c9 	cbnz	x9, 6f30 <__modti3+0xd0>
    70fc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    7100:	54000068 	b.hi	710c <__modti3+0x2ac>  // b.pmore
    7104:	eb050007 	subs	x7, x0, x5
    7108:	da080021 	sbc	x1, x1, x8
    710c:	aa0703e0 	mov	x0, x7
    7110:	17ffff81 	b	6f14 <__modti3+0xb4>
    7114:	ab000040 	adds	x0, x2, x0
    7118:	8b020002 	add	x2, x0, x2
    711c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    7120:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    7124:	17ffff79 	b	6f08 <__modti3+0xa8>
    7128:	9ac82042 	lsl	x2, x2, x8
    712c:	d2800803 	mov	x3, #0x40                  	// #64
    7130:	cb080063 	sub	x3, x3, x8
    7134:	d360fc49 	lsr	x9, x2, #32
    7138:	9ac82027 	lsl	x7, x1, x8
    713c:	92407c4a 	and	x10, x2, #0xffffffff
    7140:	9ac32426 	lsr	x6, x1, x3
    7144:	9ac32403 	lsr	x3, x0, x3
    7148:	aa070063 	orr	x3, x3, x7
    714c:	9ac908c1 	udiv	x1, x6, x9
    7150:	9ac82007 	lsl	x7, x0, x8
    7154:	9b099820 	msub	x0, x1, x9, x6
    7158:	9b017d41 	mul	x1, x10, x1
    715c:	93c38000 	extr	x0, x0, x3, #32
    7160:	eb00003f 	cmp	x1, x0
    7164:	540000a9 	b.ls	7178 <__modti3+0x318>  // b.plast
    7168:	ab000040 	adds	x0, x2, x0
    716c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    7170:	8b020006 	add	x6, x0, x2
    7174:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    7178:	cb010000 	sub	x0, x0, x1
    717c:	9ac90801 	udiv	x1, x0, x9
    7180:	9b098026 	msub	x6, x1, x9, x0
    7184:	aa0303e0 	mov	x0, x3
    7188:	9b017d41 	mul	x1, x10, x1
    718c:	b3607cc0 	bfi	x0, x6, #32, #32
    7190:	eb00003f 	cmp	x1, x0
    7194:	540000a9 	b.ls	71a8 <__modti3+0x348>  // b.plast
    7198:	ab000040 	adds	x0, x2, x0
    719c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    71a0:	8b020003 	add	x3, x0, x2
    71a4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    71a8:	cb010000 	sub	x0, x0, x1
    71ac:	17ffffb0 	b	706c <__modti3+0x20c>
    71b0:	d1000969 	sub	x9, x11, #0x2
    71b4:	8b070021 	add	x1, x1, x7
    71b8:	17ffff83 	b	6fc4 <__modti3+0x164>
    71bc:	d1000965 	sub	x5, x11, #0x2
    71c0:	8b070063 	add	x3, x3, x7
    71c4:	17ffff74 	b	6f94 <__modti3+0x134>
    71c8:	d503201f 	nop
    71cc:	d503201f 	nop

00000000000071d0 <atexit>:
    71d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    71d4:	b00000c2 	adrp	x2, 20000 <__data_start>
    71d8:	d2800001 	mov	x1, #0x0                   	// #0
    71dc:	910003fd 	mov	x29, sp
    71e0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    71e4:	f9400442 	ldr	x2, [x2, #8]
    71e8:	17ffe89a 	b	1450 <__cxa_atexit@plt>

Disassembly of section .fini:

00000000000071ec <_fini>:
    71ec:	d503201f 	nop
    71f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    71f4:	910003fd 	mov	x29, sp
    71f8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    71fc:	d65f03c0 	ret
