
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-0/fwp-packed-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001328 <_init>:
    1328:	d503201f 	nop
    132c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1330:	910003fd 	mov	x29, sp
    1334:	94000190 	bl	1974 <call_weak_fn>
    1338:	a8c17bfd 	ldp	x29, x30, [sp], #16
    133c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001340 <.plt>:
    1340:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1344:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1348:	f946fe11 	ldr	x17, [x16, #3576]
    134c:	9137e210 	add	x16, x16, #0xdf8
    1350:	d61f0220 	br	x17
    1354:	d503201f 	nop
    1358:	d503201f 	nop
    135c:	d503201f 	nop

0000000000001360 <memcpy@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1364:	f9470211 	ldr	x17, [x16, #3584]
    1368:	91380210 	add	x16, x16, #0xe00
    136c:	d61f0220 	br	x17

0000000000001370 <sigaltstack@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1374:	f9470611 	ldr	x17, [x16, #3592]
    1378:	91382210 	add	x16, x16, #0xe08
    137c:	d61f0220 	br	x17

0000000000001380 <_exit@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1384:	f9470a11 	ldr	x17, [x16, #3600]
    1388:	91384210 	add	x16, x16, #0xe10
    138c:	d61f0220 	br	x17

0000000000001390 <strlen@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1394:	f9470e11 	ldr	x17, [x16, #3608]
    1398:	91386210 	add	x16, x16, #0xe18
    139c:	d61f0220 	br	x17

00000000000013a0 <__sprintf_chk@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    13a4:	f9471211 	ldr	x17, [x16, #3616]
    13a8:	91388210 	add	x16, x16, #0xe20
    13ac:	d61f0220 	br	x17

00000000000013b0 <exit@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    13b4:	f9471611 	ldr	x17, [x16, #3624]
    13b8:	9138a210 	add	x16, x16, #0xe28
    13bc:	d61f0220 	br	x17

00000000000013c0 <__libc_start_main@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    13c4:	f9471a11 	ldr	x17, [x16, #3632]
    13c8:	9138c210 	add	x16, x16, #0xe30
    13cc:	d61f0220 	br	x17

00000000000013d0 <strtoll@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    13d4:	f9471e11 	ldr	x17, [x16, #3640]
    13d8:	9138e210 	add	x16, x16, #0xe38
    13dc:	d61f0220 	br	x17

00000000000013e0 <strtod@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    13e4:	f9472211 	ldr	x17, [x16, #3648]
    13e8:	91390210 	add	x16, x16, #0xe40
    13ec:	d61f0220 	br	x17

00000000000013f0 <__cxa_finalize@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    13f4:	f9472611 	ldr	x17, [x16, #3656]
    13f8:	91392210 	add	x16, x16, #0xe48
    13fc:	d61f0220 	br	x17

0000000000001400 <__cxa_atexit@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1404:	f9472a11 	ldr	x17, [x16, #3664]
    1408:	91394210 	add	x16, x16, #0xe50
    140c:	d61f0220 	br	x17

0000000000001410 <pthread_attr_init@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1414:	f9472e11 	ldr	x17, [x16, #3672]
    1418:	91396210 	add	x16, x16, #0xe58
    141c:	d61f0220 	br	x17

0000000000001420 <fputc@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1424:	f9473211 	ldr	x17, [x16, #3680]
    1428:	91398210 	add	x16, x16, #0xe60
    142c:	d61f0220 	br	x17

0000000000001430 <clock_gettime@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1434:	f9473611 	ldr	x17, [x16, #3688]
    1438:	9139a210 	add	x16, x16, #0xe68
    143c:	d61f0220 	br	x17

0000000000001440 <setvbuf@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1444:	f9473a11 	ldr	x17, [x16, #3696]
    1448:	9139c210 	add	x16, x16, #0xe70
    144c:	d61f0220 	br	x17

0000000000001450 <__memcpy_chk@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1454:	f9473e11 	ldr	x17, [x16, #3704]
    1458:	9139e210 	add	x16, x16, #0xe78
    145c:	d61f0220 	br	x17

0000000000001460 <signal@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1464:	f9474211 	ldr	x17, [x16, #3712]
    1468:	913a0210 	add	x16, x16, #0xe80
    146c:	d61f0220 	br	x17

0000000000001470 <__snprintf_chk@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1474:	f9474611 	ldr	x17, [x16, #3720]
    1478:	913a2210 	add	x16, x16, #0xe88
    147c:	d61f0220 	br	x17

0000000000001480 <fclose@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1484:	f9474a11 	ldr	x17, [x16, #3728]
    1488:	913a4210 	add	x16, x16, #0xe90
    148c:	d61f0220 	br	x17

0000000000001490 <fopen@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1494:	f9474e11 	ldr	x17, [x16, #3736]
    1498:	913a6210 	add	x16, x16, #0xe98
    149c:	d61f0220 	br	x17

00000000000014a0 <malloc@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    14a4:	f9475211 	ldr	x17, [x16, #3744]
    14a8:	913a8210 	add	x16, x16, #0xea0
    14ac:	d61f0220 	br	x17

00000000000014b0 <pthread_attr_destroy@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    14b4:	f9475611 	ldr	x17, [x16, #3752]
    14b8:	913aa210 	add	x16, x16, #0xea8
    14bc:	d61f0220 	br	x17

00000000000014c0 <sigemptyset@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    14c4:	f9475a11 	ldr	x17, [x16, #3760]
    14c8:	913ac210 	add	x16, x16, #0xeb0
    14cc:	d61f0220 	br	x17

00000000000014d0 <memset@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    14d4:	f9475e11 	ldr	x17, [x16, #3768]
    14d8:	913ae210 	add	x16, x16, #0xeb8
    14dc:	d61f0220 	br	x17

00000000000014e0 <calloc@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    14e4:	f9476211 	ldr	x17, [x16, #3776]
    14e8:	913b0210 	add	x16, x16, #0xec0
    14ec:	d61f0220 	br	x17

00000000000014f0 <realloc@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    14f4:	f9476611 	ldr	x17, [x16, #3784]
    14f8:	913b2210 	add	x16, x16, #0xec8
    14fc:	d61f0220 	br	x17

0000000000001500 <__stack_chk_fail@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1504:	f9476a11 	ldr	x17, [x16, #3792]
    1508:	913b4210 	add	x16, x16, #0xed0
    150c:	d61f0220 	br	x17

0000000000001510 <close@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1514:	f9476e11 	ldr	x17, [x16, #3800]
    1518:	913b6210 	add	x16, x16, #0xed8
    151c:	d61f0220 	br	x17

0000000000001520 <sigaction@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1524:	f9477211 	ldr	x17, [x16, #3808]
    1528:	913b8210 	add	x16, x16, #0xee0
    152c:	d61f0220 	br	x17

0000000000001530 <__gmon_start__@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1534:	f9477611 	ldr	x17, [x16, #3816]
    1538:	913ba210 	add	x16, x16, #0xee8
    153c:	d61f0220 	br	x17

0000000000001540 <write@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1544:	f9477a11 	ldr	x17, [x16, #3824]
    1548:	913bc210 	add	x16, x16, #0xef0
    154c:	d61f0220 	br	x17

0000000000001550 <abort@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1554:	f9477e11 	ldr	x17, [x16, #3832]
    1558:	913be210 	add	x16, x16, #0xef8
    155c:	d61f0220 	br	x17

0000000000001560 <swapcontext@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1564:	f9478211 	ldr	x17, [x16, #3840]
    1568:	913c0210 	add	x16, x16, #0xf00
    156c:	d61f0220 	br	x17

0000000000001570 <__fprintf_chk@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1574:	f9478611 	ldr	x17, [x16, #3848]
    1578:	913c2210 	add	x16, x16, #0xf08
    157c:	d61f0220 	br	x17

0000000000001580 <strcmp@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1584:	f9478a11 	ldr	x17, [x16, #3856]
    1588:	913c4210 	add	x16, x16, #0xf10
    158c:	d61f0220 	br	x17

0000000000001590 <mmap@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1594:	f9478e11 	ldr	x17, [x16, #3864]
    1598:	913c6210 	add	x16, x16, #0xf18
    159c:	d61f0220 	br	x17

00000000000015a0 <strtol@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    15a4:	f9479211 	ldr	x17, [x16, #3872]
    15a8:	913c8210 	add	x16, x16, #0xf20
    15ac:	d61f0220 	br	x17

00000000000015b0 <strtof@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    15b4:	f9479611 	ldr	x17, [x16, #3880]
    15b8:	913ca210 	add	x16, x16, #0xf28
    15bc:	d61f0220 	br	x17

00000000000015c0 <free@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    15c4:	f9479a11 	ldr	x17, [x16, #3888]
    15c8:	913cc210 	add	x16, x16, #0xf30
    15cc:	d61f0220 	br	x17

00000000000015d0 <nanosleep@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    15d4:	f9479e11 	ldr	x17, [x16, #3896]
    15d8:	913ce210 	add	x16, x16, #0xf38
    15dc:	d61f0220 	br	x17

00000000000015e0 <strchr@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    15e4:	f947a211 	ldr	x17, [x16, #3904]
    15e8:	913d0210 	add	x16, x16, #0xf40
    15ec:	d61f0220 	br	x17

00000000000015f0 <strtoull@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    15f4:	f947a611 	ldr	x17, [x16, #3912]
    15f8:	913d2210 	add	x16, x16, #0xf48
    15fc:	d61f0220 	br	x17

0000000000001600 <fwrite@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1604:	f947aa11 	ldr	x17, [x16, #3920]
    1608:	913d4210 	add	x16, x16, #0xf50
    160c:	d61f0220 	br	x17

0000000000001610 <pthread_create@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1614:	f947ae11 	ldr	x17, [x16, #3928]
    1618:	913d6210 	add	x16, x16, #0xf58
    161c:	d61f0220 	br	x17

0000000000001620 <munmap@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1624:	f947b211 	ldr	x17, [x16, #3936]
    1628:	913d8210 	add	x16, x16, #0xf60
    162c:	d61f0220 	br	x17

0000000000001630 <fflush@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1634:	f947b611 	ldr	x17, [x16, #3944]
    1638:	913da210 	add	x16, x16, #0xf68
    163c:	d61f0220 	br	x17

0000000000001640 <strcpy@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1644:	f947ba11 	ldr	x17, [x16, #3952]
    1648:	913dc210 	add	x16, x16, #0xf70
    164c:	d61f0220 	br	x17

0000000000001650 <sysconf@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1654:	f947be11 	ldr	x17, [x16, #3960]
    1658:	913de210 	add	x16, x16, #0xf78
    165c:	d61f0220 	br	x17

0000000000001660 <strstr@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1664:	f947c211 	ldr	x17, [x16, #3968]
    1668:	913e0210 	add	x16, x16, #0xf80
    166c:	d61f0220 	br	x17

0000000000001670 <_Exit@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1674:	f947c611 	ldr	x17, [x16, #3976]
    1678:	913e2210 	add	x16, x16, #0xf88
    167c:	d61f0220 	br	x17

0000000000001680 <pthread_join@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1684:	f947ca11 	ldr	x17, [x16, #3984]
    1688:	913e4210 	add	x16, x16, #0xf90
    168c:	d61f0220 	br	x17

0000000000001690 <getenv@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    1694:	f947ce11 	ldr	x17, [x16, #3992]
    1698:	913e6210 	add	x16, x16, #0xf98
    169c:	d61f0220 	br	x17

00000000000016a0 <mprotect@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    16a4:	f947d211 	ldr	x17, [x16, #4000]
    16a8:	913e8210 	add	x16, x16, #0xfa0
    16ac:	d61f0220 	br	x17

00000000000016b0 <fgets@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    16b4:	f947d611 	ldr	x17, [x16, #4008]
    16b8:	913ea210 	add	x16, x16, #0xfa8
    16bc:	d61f0220 	br	x17

00000000000016c0 <pthread_attr_setstacksize@plt>:
    16c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x175b8>
    16c4:	f947da11 	ldr	x17, [x16, #4016]
    16c8:	913ec210 	add	x16, x16, #0xfb0
    16cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001700 <fwp_trap_overflow.constprop.0>:
    1700:	d10243ff 	sub	sp, sp, #0x90
    1704:	d2800c03 	mov	x3, #0x60                  	// #96
    1708:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x175b8>
    170c:	f947f421 	ldr	x1, [x1, #4072]
    1710:	b0000025 	adrp	x5, 6000 <fwp_main_thread+0x114c>
    1714:	a9077bfd 	stp	x29, x30, [sp, #112]
    1718:	9101c3fd 	add	x29, sp, #0x70
    171c:	912640a5 	add	x5, x5, #0x990
    1720:	b0000024 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    1724:	f90043f3 	str	x19, [sp, #128]
    1728:	91266084 	add	x4, x4, #0x998
    172c:	910023f3 	add	x19, sp, #0x8
    1730:	f9400022 	ldr	x2, [x1]
    1734:	f90037e2 	str	x2, [sp, #104]
    1738:	d2800002 	mov	x2, #0x0                   	// #0
    173c:	aa0303e1 	mov	x1, x3
    1740:	52800042 	mov	w2, #0x2                   	// #2
    1744:	aa1303e0 	mov	x0, x19
    1748:	97ffff4a 	bl	1470 <__snprintf_chk@plt>
    174c:	aa1303e0 	mov	x0, x19
    1750:	940002cc 	bl	2280 <fwp_trap>
    1754:	d503201f 	nop
    1758:	d503201f 	nop
    175c:	d503201f 	nop

0000000000001760 <main>:
    1760:	d10243ff 	sub	sp, sp, #0x90
    1764:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    1768:	f947f400 	ldr	x0, [x0, #4072]
    176c:	a9067bfd 	stp	x29, x30, [sp, #96]
    1770:	910183fd 	add	x29, sp, #0x60
    1774:	a90753f3 	stp	x19, x20, [sp, #112]
    1778:	f00000f3 	adrp	x19, 20000 <__data_start>
    177c:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x175b8>
    1780:	f947ee94 	ldr	x20, [x20, #4056]
    1784:	f9400281 	ldr	x1, [x20]
    1788:	f90043f5 	str	x21, [sp, #128]
    178c:	f9400002 	ldr	x2, [x0]
    1790:	f9002fe2 	str	x2, [sp, #88]
    1794:	d2800002 	mov	x2, #0x0                   	// #0
    1798:	f9002a61 	str	x1, [x19, #80]
    179c:	940002c9 	bl	22c0 <fwp_now_ns>
    17a0:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    17a4:	9131c000 	add	x0, x0, #0xc70
    17a8:	97ffffba 	bl	1690 <getenv@plt>
    17ac:	b4000080 	cbz	x0, 17bc <main+0x5c>
    17b0:	39400001 	ldrb	w1, [x0]
    17b4:	aa0003f5 	mov	x21, x0
    17b8:	35000801 	cbnz	w1, 18b8 <main+0x158>
    17bc:	910023e1 	add	x1, sp, #0x8
    17c0:	52800000 	mov	w0, #0x0                   	// #0
    17c4:	97ffff1b 	bl	1430 <clock_gettime@plt>
    17c8:	35000900 	cbnz	w0, 18e8 <main+0x188>
    17cc:	a9408be0 	ldp	x0, x2, [sp, #8]
    17d0:	d2994003 	mov	x3, #0xca00                	// #51712
    17d4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    17d8:	9b037c01 	mul	x1, x0, x3
    17dc:	9b437c00 	smulh	x0, x0, x3
    17e0:	ab020021 	adds	x1, x1, x2
    17e4:	937ffc42 	asr	x2, x2, #63
    17e8:	9a020000 	adc	x0, x0, x2
    17ec:	f100003f 	cmp	x1, #0x0
    17f0:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    17f4:	b50009a0 	cbnz	x0, 1928 <main+0x1c8>
    17f8:	f9400280 	ldr	x0, [x20]
    17fc:	d2a00023 	mov	x3, #0x10000               	// #65536
    1800:	52800002 	mov	w2, #0x0                   	// #0
    1804:	d2800001 	mov	x1, #0x0                   	// #0
    1808:	910063f5 	add	x21, sp, #0x18
    180c:	97ffff0d 	bl	1440 <setvbuf@plt>
    1810:	d2800021 	mov	x1, #0x1                   	// #1
    1814:	528001a0 	mov	w0, #0xd                   	// #13
    1818:	97ffff12 	bl	1460 <signal@plt>
    181c:	aa1503e0 	mov	x0, x21
    1820:	97fffefc 	bl	1410 <pthread_attr_init@plt>
    1824:	350007c0 	cbnz	w0, 191c <main+0x1bc>
    1828:	aa1503e0 	mov	x0, x21
    182c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    1830:	97ffffa4 	bl	16c0 <pthread_attr_setstacksize@plt>
    1834:	35000680 	cbnz	w0, 1904 <main+0x1a4>
    1838:	aa1503e1 	mov	x1, x21
    183c:	910023e0 	add	x0, sp, #0x8
    1840:	f0000002 	adrp	x2, 4000 <fwp_write.constprop.0+0xf0>
    1844:	d2800003 	mov	x3, #0x0                   	// #0
    1848:	913ad042 	add	x2, x2, #0xeb4
    184c:	97ffff71 	bl	1610 <pthread_create@plt>
    1850:	2a0003e1 	mov	w1, w0
    1854:	aa1503e0 	mov	x0, x21
    1858:	2a0103f5 	mov	w21, w1
    185c:	97ffff15 	bl	14b0 <pthread_attr_destroy@plt>
    1860:	350006a0 	cbnz	w0, 1934 <main+0x1d4>
    1864:	350004b5 	cbnz	w21, 18f8 <main+0x198>
    1868:	f94007e0 	ldr	x0, [sp, #8]
    186c:	d2800001 	mov	x1, #0x0                   	// #0
    1870:	97ffff84 	bl	1680 <pthread_join@plt>
    1874:	35000600 	cbnz	w0, 1934 <main+0x1d4>
    1878:	f9400280 	ldr	x0, [x20]
    187c:	91014273 	add	x19, x19, #0x50
    1880:	97ffff6c 	bl	1630 <fflush@plt>
    1884:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x175b8>
    1888:	f947f421 	ldr	x1, [x1, #4072]
    188c:	b942da60 	ldr	w0, [x19, #728]
    1890:	f9402fe3 	ldr	x3, [sp, #88]
    1894:	f9400022 	ldr	x2, [x1]
    1898:	eb020063 	subs	x3, x3, x2
    189c:	d2800002 	mov	x2, #0x0                   	// #0
    18a0:	540002a1 	b.ne	18f4 <main+0x194>  // b.any
    18a4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    18a8:	a94753f3 	ldp	x19, x20, [sp, #112]
    18ac:	f94043f5 	ldr	x21, [sp, #128]
    18b0:	910243ff 	add	sp, sp, #0x90
    18b4:	d65f03c0 	ret
    18b8:	910003e1 	mov	x1, sp
    18bc:	52800142 	mov	w2, #0xa                   	// #10
    18c0:	97ffff4c 	bl	15f0 <strtoull@plt>
    18c4:	f94003e0 	ldr	x0, [sp]
    18c8:	39400000 	ldrb	w0, [x0]
    18cc:	35fff780 	cbnz	w0, 17bc <main+0x5c>
    18d0:	394002a0 	ldrb	w0, [x21]
    18d4:	52801fa1 	mov	w1, #0xfd                  	// #253
    18d8:	5100ac00 	sub	w0, w0, #0x2b
    18dc:	6a01001f 	tst	w0, w1
    18e0:	54fff6e0 	b.eq	17bc <main+0x5c>  // b.none
    18e4:	17ffffc5 	b	17f8 <main+0x98>
    18e8:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    18ec:	91320000 	add	x0, x0, #0xc80
    18f0:	94000264 	bl	2280 <fwp_trap>
    18f4:	97ffff03 	bl	1500 <__stack_chk_fail@plt>
    18f8:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    18fc:	91348000 	add	x0, x0, #0xd20
    1900:	94000260 	bl	2280 <fwp_trap>
    1904:	aa1503e0 	mov	x0, x21
    1908:	97fffeea 	bl	14b0 <pthread_attr_destroy@plt>
    190c:	35000140 	cbnz	w0, 1934 <main+0x1d4>
    1910:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    1914:	9133e000 	add	x0, x0, #0xcf8
    1918:	9400025a 	bl	2280 <fwp_trap>
    191c:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    1920:	91332000 	add	x0, x0, #0xcc8
    1924:	94000257 	bl	2280 <fwp_trap>
    1928:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    192c:	91328000 	add	x0, x0, #0xca0
    1930:	94000254 	bl	2280 <fwp_trap>
    1934:	97ffff07 	bl	1550 <abort@plt>
    1938:	d503201f 	nop
    193c:	d503201f 	nop

0000000000001940 <_start>:
    1940:	d503201f 	nop
    1944:	d280001d 	mov	x29, #0x0                   	// #0
    1948:	d280001e 	mov	x30, #0x0                   	// #0
    194c:	aa0003e5 	mov	x5, x0
    1950:	f94003e1 	ldr	x1, [sp]
    1954:	910023e2 	add	x2, sp, #0x8
    1958:	910003e6 	mov	x6, sp
    195c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    1960:	f947f800 	ldr	x0, [x0, #4080]
    1964:	d2800003 	mov	x3, #0x0                   	// #0
    1968:	d2800004 	mov	x4, #0x0                   	// #0
    196c:	97fffe95 	bl	13c0 <__libc_start_main@plt>
    1970:	97fffef8 	bl	1550 <abort@plt>

0000000000001974 <call_weak_fn>:
    1974:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    1978:	f947f000 	ldr	x0, [x0, #4064]
    197c:	b4000040 	cbz	x0, 1984 <call_weak_fn+0x10>
    1980:	17fffeec 	b	1530 <__gmon_start__@plt>
    1984:	d65f03c0 	ret
    1988:	d503201f 	nop
    198c:	d503201f 	nop

0000000000001990 <deregister_tm_clones>:
    1990:	f00000e0 	adrp	x0, 20000 <__data_start>
    1994:	9100e000 	add	x0, x0, #0x38
    1998:	f00000e1 	adrp	x1, 20000 <__data_start>
    199c:	9100e021 	add	x1, x1, #0x38
    19a0:	eb00003f 	cmp	x1, x0
    19a4:	540000c0 	b.eq	19bc <deregister_tm_clones+0x2c>  // b.none
    19a8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x175b8>
    19ac:	f947e021 	ldr	x1, [x1, #4032]
    19b0:	b4000061 	cbz	x1, 19bc <deregister_tm_clones+0x2c>
    19b4:	aa0103f0 	mov	x16, x1
    19b8:	d61f0200 	br	x16
    19bc:	d65f03c0 	ret

00000000000019c0 <register_tm_clones>:
    19c0:	f00000e0 	adrp	x0, 20000 <__data_start>
    19c4:	9100e000 	add	x0, x0, #0x38
    19c8:	f00000e1 	adrp	x1, 20000 <__data_start>
    19cc:	9100e021 	add	x1, x1, #0x38
    19d0:	cb000021 	sub	x1, x1, x0
    19d4:	d37ffc22 	lsr	x2, x1, #63
    19d8:	8b810c41 	add	x1, x2, x1, asr #3
    19dc:	9341fc21 	asr	x1, x1, #1
    19e0:	b40000c1 	cbz	x1, 19f8 <register_tm_clones+0x38>
    19e4:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x175b8>
    19e8:	f947fc42 	ldr	x2, [x2, #4088]
    19ec:	b4000062 	cbz	x2, 19f8 <register_tm_clones+0x38>
    19f0:	aa0203f0 	mov	x16, x2
    19f4:	d61f0200 	br	x16
    19f8:	d65f03c0 	ret
    19fc:	d503201f 	nop

0000000000001a00 <__do_global_dtors_aux>:
    1a00:	d503233f 	paciasp
    1a04:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1a08:	910003fd 	mov	x29, sp
    1a0c:	f9000bf3 	str	x19, [sp, #16]
    1a10:	f00000f3 	adrp	x19, 20000 <__data_start>
    1a14:	39410260 	ldrb	w0, [x19, #64]
    1a18:	37000140 	tbnz	w0, #0, 1a40 <__do_global_dtors_aux+0x40>
    1a1c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    1a20:	f947e400 	ldr	x0, [x0, #4040]
    1a24:	b4000080 	cbz	x0, 1a34 <__do_global_dtors_aux+0x34>
    1a28:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a2c:	f9400400 	ldr	x0, [x0, #8]
    1a30:	97fffe70 	bl	13f0 <__cxa_finalize@plt>
    1a34:	97ffffd7 	bl	1990 <deregister_tm_clones>
    1a38:	52800020 	mov	w0, #0x1                   	// #1
    1a3c:	39010260 	strb	w0, [x19, #64]
    1a40:	f9400bf3 	ldr	x19, [sp, #16]
    1a44:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a48:	d50323bf 	autiasp
    1a4c:	d65f03c0 	ret

0000000000001a50 <frame_dummy>:
    1a50:	d503245f 	bti	c
    1a54:	17ffffdb 	b	19c0 <register_tm_clones>
    1a58:	d503201f 	nop
    1a5c:	d503201f 	nop

0000000000001a60 <fwp_fmt_u128>:
    1a60:	d10183ff 	sub	sp, sp, #0x60
    1a64:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x175b8>
    1a68:	f947f421 	ldr	x1, [x1, #4072]
    1a6c:	a9057bfd 	stp	x29, x30, [sp, #80]
    1a70:	910143fd 	add	x29, sp, #0x50
    1a74:	f9400024 	ldr	x4, [x1]
    1a78:	f90027e4 	str	x4, [sp, #72]
    1a7c:	d2800004 	mov	x4, #0x0                   	// #0
    1a80:	aa030041 	orr	x1, x2, x3
    1a84:	b5000361 	cbnz	x1, 1af0 <fwp_fmt_u128+0x90>
    1a88:	910023e9 	add	x9, sp, #0x8
    1a8c:	52800601 	mov	w1, #0x30                  	// #48
    1a90:	5280002d 	mov	w13, #0x1                   	// #1
    1a94:	390023e1 	strb	w1, [sp, #8]
    1a98:	93407dad 	sxtw	x13, w13
    1a9c:	aa0d03e1 	mov	x1, x13
    1aa0:	8b0d0004 	add	x4, x0, x13
    1aa4:	d503201f 	nop
    1aa8:	8b010123 	add	x3, x9, x1
    1aac:	cb0103e2 	neg	x2, x1
    1ab0:	d1000421 	sub	x1, x1, #0x1
    1ab4:	385ff063 	ldurb	w3, [x3, #-1]
    1ab8:	38226883 	strb	w3, [x4, x2]
    1abc:	35ffff61 	cbnz	w1, 1aa8 <fwp_fmt_u128+0x48>
    1ac0:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x175b8>
    1ac4:	f947f421 	ldr	x1, [x1, #4072]
    1ac8:	382d681f 	strb	wzr, [x0, x13]
    1acc:	aa0103e0 	mov	x0, x1
    1ad0:	f94027e2 	ldr	x2, [sp, #72]
    1ad4:	f9400001 	ldr	x1, [x0]
    1ad8:	eb010042 	subs	x2, x2, x1
    1adc:	d2800001 	mov	x1, #0x0                   	// #0
    1ae0:	54000561 	b.ne	1b8c <fwp_fmt_u128+0x12c>  // b.any
    1ae4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1ae8:	910183ff 	add	sp, sp, #0x60
    1aec:	d65f03c0 	ret
    1af0:	b0000021 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    1af4:	91384021 	add	x1, x1, #0xe10
    1af8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1afc:	910023e9 	add	x9, sp, #0x8
    1b00:	d2800027 	mov	x7, #0x1                   	// #1
    1b04:	f29999af 	movk	x15, #0xcccd
    1b08:	a9402826 	ldp	x6, x10, [x1]
    1b0c:	d503201f 	nop
    1b10:	ab030041 	adds	x1, x2, x3
    1b14:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1b18:	aa0303eb 	mov	x11, x3
    1b1c:	8b070128 	add	x8, x9, x7
    1b20:	aa0203ee 	mov	x14, x2
    1b24:	aa0703ed 	mov	x13, x7
    1b28:	910004e7 	add	x7, x7, #0x1
    1b2c:	9bcf7c24 	umulh	x4, x1, x15
    1b30:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1b34:	8b4408a4 	add	x4, x5, x4, lsr #2
    1b38:	cb040021 	sub	x1, x1, x4
    1b3c:	eb010041 	subs	x1, x2, x1
    1b40:	da1f0063 	sbc	x3, x3, xzr
    1b44:	9bc67c24 	umulh	x4, x1, x6
    1b48:	9b061064 	madd	x4, x3, x6, x4
    1b4c:	9b067c2c 	mul	x12, x1, x6
    1b50:	9b0a1024 	madd	x4, x1, x10, x4
    1b54:	9bc67c25 	umulh	x5, x1, x6
    1b58:	9b061465 	madd	x5, x3, x6, x5
    1b5c:	9b0a1425 	madd	x5, x1, x10, x5
    1b60:	93cc0484 	extr	x4, x4, x12, #1
    1b64:	8b040884 	add	x4, x4, x4, lsl #2
    1b68:	d341fca3 	lsr	x3, x5, #1
    1b6c:	cb040444 	sub	x4, x2, x4, lsl #1
    1b70:	93cc04a2 	extr	x2, x5, x12, #1
    1b74:	1100c084 	add	w4, w4, #0x30
    1b78:	381ff104 	sturb	w4, [x8, #-1]
    1b7c:	b5fffcab 	cbnz	x11, 1b10 <fwp_fmt_u128+0xb0>
    1b80:	f10025df 	cmp	x14, #0x9
    1b84:	54fffc68 	b.hi	1b10 <fwp_fmt_u128+0xb0>  // b.pmore
    1b88:	17ffffc4 	b	1a98 <fwp_fmt_u128+0x38>
    1b8c:	97fffe5d 	bl	1500 <__stack_chk_fail@plt>

0000000000001b90 <fwp_range_release>:
    1b90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b94:	910003fd 	mov	x29, sp
    1b98:	f9400801 	ldr	x1, [x0, #16]
    1b9c:	f9000bf3 	str	x19, [sp, #16]
    1ba0:	aa0003f3 	mov	x19, x0
    1ba4:	b4000061 	cbz	x1, 1bb0 <fwp_range_release+0x20>
    1ba8:	f9400400 	ldr	x0, [x0, #8]
    1bac:	d63f0020 	blr	x1
    1bb0:	f9400260 	ldr	x0, [x19]
    1bb4:	f9400e61 	ldr	x1, [x19, #24]
    1bb8:	f9400bf3 	ldr	x19, [sp, #16]
    1bbc:	aa0103f0 	mov	x16, x1
    1bc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1bc4:	d61f0200 	br	x16
    1bc8:	d503201f 	nop
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_flush>:
    1bd0:	f00000e0 	adrp	x0, 20000 <__data_start>
    1bd4:	f9402800 	ldr	x0, [x0, #80]
    1bd8:	b4000120 	cbz	x0, 1bfc <fwp_flush+0x2c>
    1bdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1be0:	910003fd 	mov	x29, sp
    1be4:	97fffe93 	bl	1630 <fflush@plt>
    1be8:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    1bec:	f947ec00 	ldr	x0, [x0, #4056]
    1bf0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1bf4:	f9400000 	ldr	x0, [x0]
    1bf8:	17fffe8e 	b	1630 <fflush@plt>
    1bfc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    1c00:	f947ec00 	ldr	x0, [x0, #4056]
    1c04:	f9400000 	ldr	x0, [x0]
    1c08:	17fffe8a 	b	1630 <fflush@plt>
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_segv>:
    1c10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c14:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c18:	91014043 	add	x3, x2, #0x50
    1c1c:	910003fd 	mov	x29, sp
    1c20:	a90153f3 	stp	x19, x20, [sp, #16]
    1c24:	2a0003f3 	mov	w19, w0
    1c28:	f9400460 	ldr	x0, [x3, #8]
    1c2c:	f90013f5 	str	x21, [sp, #32]
    1c30:	f9400835 	ldr	x21, [x1, #16]
    1c34:	b4000280 	cbz	x0, 1c84 <fwp_segv+0x74>
    1c38:	f9400814 	ldr	x20, [x0, #16]
    1c3c:	b4000254 	cbz	x20, 1c84 <fwp_segv+0x74>
    1c40:	528003c0 	mov	w0, #0x1e                  	// #30
    1c44:	97fffe83 	bl	1650 <sysconf@plt>
    1c48:	f144029f 	cmp	x20, #0x100, lsl #12
    1c4c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c50:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c54:	8b000294 	add	x20, x20, x0
    1c58:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c5c:	eb0102bf 	cmp	x21, x1
    1c60:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1c64:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c68:	35000240 	cbnz	w0, 1cb0 <fwp_segv+0xa0>
    1c6c:	f94013f5 	ldr	x21, [sp, #32]
    1c70:	2a1303e0 	mov	w0, w19
    1c74:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c78:	d2800001 	mov	x1, #0x0                   	// #0
    1c7c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c80:	17fffdf8 	b	1460 <signal@plt>
    1c84:	91014042 	add	x2, x2, #0x50
    1c88:	f9400840 	ldr	x0, [x2, #16]
    1c8c:	b4ffff00 	cbz	x0, 1c6c <fwp_segv+0x5c>
    1c90:	f9400c41 	ldr	x1, [x2, #24]
    1c94:	cb010000 	sub	x0, x0, x1
    1c98:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1c9c:	91440000 	add	x0, x0, #0x100, lsl #12
    1ca0:	eb15003f 	cmp	x1, x21
    1ca4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1ca8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1cac:	34fffe00 	cbz	w0, 1c6c <fwp_segv+0x5c>
    1cb0:	97ffffc8 	bl	1bd0 <fwp_flush>
    1cb4:	b0000021 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    1cb8:	9137c021 	add	x1, x1, #0xdf0
    1cbc:	d2800342 	mov	x2, #0x1a                  	// #26
    1cc0:	52800040 	mov	w0, #0x2                   	// #2
    1cc4:	97fffe1f 	bl	1540 <write@plt>
    1cc8:	52800ca0 	mov	w0, #0x65                  	// #101
    1ccc:	97fffdad 	bl	1380 <_exit@plt>

0000000000001cd0 <fwp_heap_oom>:
    1cd0:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x175b8>
    1cd4:	f947e863 	ldr	x3, [x3, #4048]
    1cd8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1cdc:	d2800262 	mov	x2, #0x13                  	// #19
    1ce0:	910003fd 	mov	x29, sp
    1ce4:	f9400063 	ldr	x3, [x3]
    1ce8:	d2800021 	mov	x1, #0x1                   	// #1
    1cec:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    1cf0:	911d2000 	add	x0, x0, #0x748
    1cf4:	97fffe43 	bl	1600 <fwrite@plt>
    1cf8:	d2800000 	mov	x0, #0x0                   	// #0
    1cfc:	97fffe4d 	bl	1630 <fflush@plt>
    1d00:	52800cc0 	mov	w0, #0x66                  	// #102
    1d04:	97fffe5b 	bl	1670 <_Exit@plt>
    1d08:	d503201f 	nop
    1d0c:	d503201f 	nop

0000000000001d10 <fwp_heap_chunks>:
    1d10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d14:	910003fd 	mov	x29, sp
    1d18:	a90153f3 	stp	x19, x20, [sp, #16]
    1d1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1d20:	90000195 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    1d24:	9114c2a1 	add	x1, x21, #0x530
    1d28:	f100041f 	cmp	x0, #0x1
    1d2c:	54000ca0 	b.eq	1ec0 <fwp_heap_chunks+0x1b0>  // b.none
    1d30:	f949f822 	ldr	x2, [x1, #5104]
    1d34:	b0000185 	adrp	x5, 32000 <fwp_heap+0xad0>
    1d38:	912480a5 	add	x5, x5, #0x920
    1d3c:	9114c2a1 	add	x1, x21, #0x530
    1d40:	f949ec34 	ldr	x20, [x1, #5080]
    1d44:	eb14005f 	cmp	x2, x20
    1d48:	54000c42 	b.cs	1ed0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1d4c:	f949fc23 	ldr	x3, [x1, #5112]
    1d50:	8b020841 	add	x1, x2, x2, lsl #2
    1d54:	d2800004 	mov	x4, #0x0                   	// #0
    1d58:	8b010c61 	add	x1, x3, x1, lsl #3
    1d5c:	14000009 	b	1d80 <fwp_heap_chunks+0x70>
    1d60:	91000483 	add	x3, x4, #0x1
    1d64:	eb03001f 	cmp	x0, x3
    1d68:	54000940 	b.eq	1e90 <fwp_heap_chunks+0x180>  // b.none
    1d6c:	91000442 	add	x2, x2, #0x1
    1d70:	aa0303e4 	mov	x4, x3
    1d74:	9100a021 	add	x1, x1, #0x28
    1d78:	eb02029f 	cmp	x20, x2
    1d7c:	54000100 	b.eq	1d9c <fwp_heap_chunks+0x8c>  // b.none
    1d80:	39400023 	ldrb	w3, [x1]
    1d84:	34fffee3 	cbz	w3, 1d60 <fwp_heap_chunks+0x50>
    1d88:	91000442 	add	x2, x2, #0x1
    1d8c:	9100a021 	add	x1, x1, #0x28
    1d90:	d2800004 	mov	x4, #0x0                   	// #0
    1d94:	eb02029f 	cmp	x20, x2
    1d98:	54ffff41 	b.ne	1d80 <fwp_heap_chunks+0x70>  // b.any
    1d9c:	cb040294 	sub	x20, x20, x4
    1da0:	f9001bf7 	str	x23, [sp, #48]
    1da4:	9114c2b7 	add	x23, x21, #0x530
    1da8:	8b140013 	add	x19, x0, x20
    1dac:	f94a1ae1 	ldr	x1, [x23, #5168]
    1db0:	f949f2e0 	ldr	x0, [x23, #5088]
    1db4:	cb040021 	sub	x1, x1, x4
    1db8:	f90a1ae1 	str	x1, [x23, #5168]
    1dbc:	eb00027f 	cmp	x19, x0
    1dc0:	54000429 	b.ls	1e44 <fwp_heap_chunks+0x134>  // b.plast
    1dc4:	f949eae1 	ldr	x1, [x23, #5072]
    1dc8:	eb01027f 	cmp	x19, x1
    1dcc:	54000888 	b.hi	1edc <fwp_heap_chunks+0x1cc>  // b.pmore
    1dd0:	91010276 	add	x22, x19, #0x40
    1dd4:	52800062 	mov	w2, #0x3                   	// #3
    1dd8:	f949dae3 	ldr	x3, [x23, #5040]
    1ddc:	eb0102df 	cmp	x22, x1
    1de0:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1de4:	cb0002c1 	sub	x1, x22, x0
    1de8:	8b004060 	add	x0, x3, x0, lsl #16
    1dec:	d370bc21 	lsl	x1, x1, #16
    1df0:	97fffe2c 	bl	16a0 <mprotect@plt>
    1df4:	35000740 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1df8:	528003c0 	mov	w0, #0x1e                  	// #30
    1dfc:	97fffe15 	bl	1650 <sysconf@plt>
    1e00:	f949f2e2 	ldr	x2, [x23, #5088]
    1e04:	cb0003e5 	neg	x5, x0
    1e08:	aa0003e4 	mov	x4, x0
    1e0c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e10:	f949fee0 	ldr	x0, [x23, #5112]
    1e14:	8b020843 	add	x3, x2, x2, lsl #2
    1e18:	52800062 	mov	w2, #0x3                   	// #3
    1e1c:	8b010c01 	add	x1, x0, x1, lsl #3
    1e20:	8b030c03 	add	x3, x0, x3, lsl #3
    1e24:	d1000421 	sub	x1, x1, #0x1
    1e28:	8a050060 	and	x0, x3, x5
    1e2c:	8b040021 	add	x1, x1, x4
    1e30:	8a050021 	and	x1, x1, x5
    1e34:	cb000021 	sub	x1, x1, x0
    1e38:	97fffe1a 	bl	16a0 <mprotect@plt>
    1e3c:	35000500 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1e40:	f909f2f6 	str	x22, [x23, #5088]
    1e44:	9114c2b5 	add	x21, x21, #0x530
    1e48:	d370be60 	lsl	x0, x19, #16
    1e4c:	f949e6a1 	ldr	x1, [x21, #5064]
    1e50:	f909eeb3 	str	x19, [x21, #5080]
    1e54:	eb01001f 	cmp	x0, x1
    1e58:	540000e8 	b.hi	1e74 <fwp_heap_chunks+0x164>  // b.pmore
    1e5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e60:	aa1403e0 	mov	x0, x20
    1e64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e68:	f9401bf7 	ldr	x23, [sp, #48]
    1e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e70:	d65f03c0 	ret
    1e74:	f9401bf7 	ldr	x23, [sp, #48]
    1e78:	f909e6a0 	str	x0, [x21, #5064]
    1e7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e80:	aa1403e0 	mov	x0, x20
    1e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e88:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e8c:	d65f03c0 	ret
    1e90:	9114c2b5 	add	x21, x21, #0x530
    1e94:	91000441 	add	x1, x2, #0x1
    1e98:	f90000a1 	str	x1, [x5]
    1e9c:	cb040054 	sub	x20, x2, x4
    1ea0:	f94a1aa1 	ldr	x1, [x21, #5168]
    1ea4:	cb000020 	sub	x0, x1, x0
    1ea8:	f90a1aa0 	str	x0, [x21, #5168]
    1eac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1eb0:	aa1403e0 	mov	x0, x20
    1eb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1eb8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ebc:	d65f03c0 	ret
    1ec0:	f949f422 	ldr	x2, [x1, #5096]
    1ec4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xad0>
    1ec8:	912460a5 	add	x5, x5, #0x918
    1ecc:	17ffff9c 	b	1d3c <fwp_heap_chunks+0x2c>
    1ed0:	d2800004 	mov	x4, #0x0                   	// #0
    1ed4:	f9001bf7 	str	x23, [sp, #48]
    1ed8:	17ffffb3 	b	1da4 <fwp_heap_chunks+0x94>
    1edc:	97ffff7d 	bl	1cd0 <fwp_heap_oom>

0000000000001ee0 <ad_raw_fail>:
    1ee0:	d00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x175b8>
    1ee4:	f947e884 	ldr	x4, [x4, #4048]
    1ee8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1eec:	aa0003e3 	mov	x3, x0
    1ef0:	910003fd 	mov	x29, sp
    1ef4:	f9400080 	ldr	x0, [x4]
    1ef8:	b0000022 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    1efc:	911d8042 	add	x2, x2, #0x760
    1f00:	52800041 	mov	w1, #0x2                   	// #2
    1f04:	97fffd9b 	bl	1570 <__fprintf_chk@plt>
    1f08:	52801d00 	mov	w0, #0xe8                  	// #232
    1f0c:	97fffd29 	bl	13b0 <exit@plt>

0000000000001f10 <ad_raw_report>:
    1f10:	d101c3ff 	sub	sp, sp, #0x70
    1f14:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f18:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x175b8>
    1f1c:	f947f463 	ldr	x3, [x3, #4072]
    1f20:	b0000022 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    1f24:	a9037bfd 	stp	x29, x30, [sp, #48]
    1f28:	9100c3fd 	add	x29, sp, #0x30
    1f2c:	911e4042 	add	x2, x2, #0x790
    1f30:	d2800005 	mov	x5, #0x0                   	// #0
    1f34:	a9055bf5 	stp	x21, x22, [sp, #80]
    1f38:	b0000036 	adrp	x22, 6000 <fwp_main_thread+0x114c>
    1f3c:	911fc2d6 	add	x22, x22, #0x7f0
    1f40:	d00000f5 	adrp	x21, 1f000 <__FRAME_END__+0x175b8>
    1f44:	f947eab5 	ldr	x21, [x21, #4048]
    1f48:	a90453f3 	stp	x19, x20, [sp, #64]
    1f4c:	52800013 	mov	w19, #0x0                   	// #0
    1f50:	f94002a0 	ldr	x0, [x21]
    1f54:	f90033f7 	str	x23, [sp, #96]
    1f58:	b0000037 	adrp	x23, 6000 <fwp_main_thread+0x114c>
    1f5c:	911e22f7 	add	x23, x23, #0x788
    1f60:	f9400064 	ldr	x4, [x3]
    1f64:	f90017e4 	str	x4, [sp, #40]
    1f68:	d2800004 	mov	x4, #0x0                   	// #0
    1f6c:	d2800003 	mov	x3, #0x0                   	// #0
    1f70:	f9403824 	ldr	x4, [x1, #112]
    1f74:	52800041 	mov	w1, #0x2                   	// #2
    1f78:	97fffd7e 	bl	1570 <__fprintf_chk@plt>
    1f7c:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f80:	91004021 	add	x1, x1, #0x10
    1f84:	f94002a0 	ldr	x0, [x21]
    1f88:	910023e2 	add	x2, sp, #0x8
    1f8c:	4c40a020 	ld1	{v0.16b-v1.16b}, [x1]
    1f90:	b0000023 	adrp	x3, 6000 <fwp_main_thread+0x114c>
    1f94:	aa0203f4 	mov	x20, x2
    1f98:	911e0063 	add	x3, x3, #0x780
    1f9c:	4c00a040 	st1	{v0.16b-v1.16b}, [x2]
    1fa0:	aa1603e2 	mov	x2, x22
    1fa4:	f8408684 	ldr	x4, [x20], #8
    1fa8:	d2800007 	mov	x7, #0x0                   	// #0
    1fac:	d2800006 	mov	x6, #0x0                   	// #0
    1fb0:	d2800005 	mov	x5, #0x0                   	// #0
    1fb4:	52800041 	mov	w1, #0x2                   	// #2
    1fb8:	11000673 	add	w19, w19, #0x1
    1fbc:	97fffd6d 	bl	1570 <__fprintf_chk@plt>
    1fc0:	7100127f 	cmp	w19, #0x4
    1fc4:	54000080 	b.eq	1fd4 <ad_raw_report+0xc4>  // b.none
    1fc8:	f94002a0 	ldr	x0, [x21]
    1fcc:	aa1703e3 	mov	x3, x23
    1fd0:	17fffff4 	b	1fa0 <ad_raw_report+0x90>
    1fd4:	f94002a3 	ldr	x3, [x21]
    1fd8:	d2800262 	mov	x2, #0x13                  	// #19
    1fdc:	d2800021 	mov	x1, #0x1                   	// #1
    1fe0:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    1fe4:	9120c000 	add	x0, x0, #0x830
    1fe8:	97fffd86 	bl	1600 <fwrite@plt>
    1fec:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    1ff0:	f947f400 	ldr	x0, [x0, #4072]
    1ff4:	f94017e2 	ldr	x2, [sp, #40]
    1ff8:	f9400001 	ldr	x1, [x0]
    1ffc:	eb010042 	subs	x2, x2, x1
    2000:	d2800001 	mov	x1, #0x0                   	// #0
    2004:	54000181 	b.ne	2034 <ad_raw_report+0x124>  // b.any
    2008:	f94002a3 	ldr	x3, [x21]
    200c:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2010:	a9437bfd 	ldp	x29, x30, [sp, #48]
    2014:	91212000 	add	x0, x0, #0x848
    2018:	a94453f3 	ldp	x19, x20, [sp, #64]
    201c:	d2800082 	mov	x2, #0x4                   	// #4
    2020:	a9455bf5 	ldp	x21, x22, [sp, #80]
    2024:	d2800021 	mov	x1, #0x1                   	// #1
    2028:	f94033f7 	ldr	x23, [sp, #96]
    202c:	9101c3ff 	add	sp, sp, #0x70
    2030:	17fffd74 	b	1600 <fwrite@plt>
    2034:	97fffd33 	bl	1500 <__stack_chk_fail@plt>
    2038:	d503201f 	nop
    203c:	d503201f 	nop

0000000000002040 <buf_grow>:
    2040:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2044:	910003fd 	mov	x29, sp
    2048:	a90153f3 	stp	x19, x20, [sp, #16]
    204c:	aa0003f4 	mov	x20, x0
    2050:	f9400400 	ldr	x0, [x0, #8]
    2054:	b100041f 	cmn	x0, #0x1
    2058:	54000400 	b.eq	20d8 <buf_grow+0x98>  // b.none
    205c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    2060:	cb000042 	sub	x2, x2, x0
    2064:	eb01005f 	cmp	x2, x1
    2068:	54000383 	b.cc	20d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    206c:	f9400a82 	ldr	x2, [x20, #16]
    2070:	91000421 	add	x1, x1, #0x1
    2074:	8b000033 	add	x19, x1, x0
    2078:	eb13005f 	cmp	x2, x19
    207c:	54000242 	b.cs	20c4 <buf_grow+0x84>  // b.hs, b.nlast
    2080:	f100005f 	cmp	x2, #0x0
    2084:	b5000262 	cbnz	x2, 20d0 <buf_grow+0x90>
    2088:	d2800802 	mov	x2, #0x40                  	// #64
    208c:	eb02027f 	cmp	x19, x2
    2090:	54000068 	b.hi	209c <buf_grow+0x5c>  // b.pmore
    2094:	14000005 	b	20a8 <buf_grow+0x68>
    2098:	b7f800a2 	tbnz	x2, #63, 20ac <buf_grow+0x6c>
    209c:	d37ff842 	lsl	x2, x2, #1
    20a0:	eb02027f 	cmp	x19, x2
    20a4:	54ffffa8 	b.hi	2098 <buf_grow+0x58>  // b.pmore
    20a8:	aa0203f3 	mov	x19, x2
    20ac:	f9400280 	ldr	x0, [x20]
    20b0:	aa1303e1 	mov	x1, x19
    20b4:	97fffd0f 	bl	14f0 <realloc@plt>
    20b8:	b4000100 	cbz	x0, 20d8 <buf_grow+0x98>
    20bc:	f9000280 	str	x0, [x20]
    20c0:	f9000a93 	str	x19, [x20, #16]
    20c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    20c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    20cc:	d65f03c0 	ret
    20d0:	54fffe6a 	b.ge	209c <buf_grow+0x5c>  // b.tcont
    20d4:	17fffff6 	b	20ac <buf_grow+0x6c>
    20d8:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x175b8>
    20dc:	f947e863 	ldr	x3, [x3, #4048]
    20e0:	d2800262 	mov	x2, #0x13                  	// #19
    20e4:	d2800021 	mov	x1, #0x1                   	// #1
    20e8:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    20ec:	911d2000 	add	x0, x0, #0x748
    20f0:	f9400063 	ldr	x3, [x3]
    20f4:	97fffd43 	bl	1600 <fwrite@plt>
    20f8:	d2800000 	mov	x0, #0x0                   	// #0
    20fc:	97fffd4d 	bl	1630 <fflush@plt>
    2100:	52800cc0 	mov	w0, #0x66                  	// #102
    2104:	97fffd5b 	bl	1670 <_Exit@plt>
    2108:	d503201f 	nop
    210c:	d503201f 	nop

0000000000002110 <buf_put>:
    2110:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2114:	910003fd 	mov	x29, sp
    2118:	a90153f3 	stp	x19, x20, [sp, #16]
    211c:	aa0003f4 	mov	x20, x0
    2120:	aa0203f3 	mov	x19, x2
    2124:	f90013f5 	str	x21, [sp, #32]
    2128:	aa0103f5 	mov	x21, x1
    212c:	aa0203e1 	mov	x1, x2
    2130:	97ffffc4 	bl	2040 <buf_grow>
    2134:	a9400283 	ldp	x3, x0, [x20]
    2138:	aa1503e1 	mov	x1, x21
    213c:	aa1303e2 	mov	x2, x19
    2140:	8b000060 	add	x0, x3, x0
    2144:	97fffc87 	bl	1360 <memcpy@plt>
    2148:	a9400680 	ldp	x0, x1, [x20]
    214c:	8b010273 	add	x19, x19, x1
    2150:	f9000693 	str	x19, [x20, #8]
    2154:	3833681f 	strb	wzr, [x0, x19]
    2158:	a94153f3 	ldp	x19, x20, [sp, #16]
    215c:	f94013f5 	ldr	x21, [sp, #32]
    2160:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2164:	d65f03c0 	ret
    2168:	d503201f 	nop
    216c:	d503201f 	nop

0000000000002170 <fwp_cancel_tree.part.0>:
    2170:	d00000e1 	adrp	x1, 20000 <__data_start>
    2174:	91014022 	add	x2, x1, #0x50
    2178:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    217c:	52800023 	mov	w3, #0x1                   	// #1
    2180:	910003fd 	mov	x29, sp
    2184:	f9400444 	ldr	x4, [x2, #8]
    2188:	f9000bf3 	str	x19, [sp, #16]
    218c:	39014403 	strb	w3, [x0, #81]
    2190:	eb04001f 	cmp	x0, x4
    2194:	54000160 	b.eq	21c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    2198:	f9402804 	ldr	x4, [x0, #80]
    219c:	f2001c9f 	tst	x4, #0xff000000ff
    21a0:	54000101 	b.ne	21c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    21a4:	f9401444 	ldr	x4, [x2, #40]
    21a8:	39015003 	strb	w3, [x0, #84]
    21ac:	f900801f 	str	xzr, [x0, #256]
    21b0:	b40001e4 	cbz	x4, 21ec <fwp_cancel_tree.part.0+0x7c>
    21b4:	f9008080 	str	x0, [x4, #256]
    21b8:	91014021 	add	x1, x1, #0x50
    21bc:	f9001420 	str	x0, [x1, #40]
    21c0:	f9401413 	ldr	x19, [x0, #40]
    21c4:	b40000f3 	cbz	x19, 21e0 <fwp_cancel_tree.part.0+0x70>
    21c8:	39414261 	ldrb	w1, [x19, #80]
    21cc:	aa1303e0 	mov	x0, x19
    21d0:	37000041 	tbnz	w1, #0, 21d8 <fwp_cancel_tree.part.0+0x68>
    21d4:	97ffffe7 	bl	2170 <fwp_cancel_tree.part.0>
    21d8:	f9401a73 	ldr	x19, [x19, #48]
    21dc:	b5ffff73 	cbnz	x19, 21c8 <fwp_cancel_tree.part.0+0x58>
    21e0:	f9400bf3 	ldr	x19, [sp, #16]
    21e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    21e8:	d65f03c0 	ret
    21ec:	f9001840 	str	x0, [x2, #48]
    21f0:	17fffff2 	b	21b8 <fwp_cancel_tree.part.0+0x48>

00000000000021f4 <fwp_finish_float>:
    21f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    21f8:	528005c1 	mov	w1, #0x2e                  	// #46
    21fc:	910003fd 	mov	x29, sp
    2200:	f9000bf3 	str	x19, [sp, #16]
    2204:	aa0003f3 	mov	x19, x0
    2208:	97fffcf6 	bl	15e0 <strchr@plt>
    220c:	b4000080 	cbz	x0, 221c <fwp_finish_float+0x28>
    2210:	f9400bf3 	ldr	x19, [sp, #16]
    2214:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2218:	d65f03c0 	ret
    221c:	aa1303e0 	mov	x0, x19
    2220:	52800ca1 	mov	w1, #0x65                  	// #101
    2224:	97fffcef 	bl	15e0 <strchr@plt>
    2228:	b5ffff40 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    222c:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    2230:	aa1303e0 	mov	x0, x19
    2234:	91214021 	add	x1, x1, #0x850
    2238:	97fffd0a 	bl	1660 <strstr@plt>
    223c:	b5fffea0 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2240:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    2244:	aa1303e0 	mov	x0, x19
    2248:	91216021 	add	x1, x1, #0x858
    224c:	97fffd05 	bl	1660 <strstr@plt>
    2250:	b5fffe00 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2254:	aa1303e0 	mov	x0, x19
    2258:	97fffc4e 	bl	1390 <strlen@plt>
    225c:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    2260:	91218021 	add	x1, x1, #0x860
    2264:	8b000262 	add	x2, x19, x0
    2268:	79400023 	ldrh	w3, [x1]
    226c:	39400821 	ldrb	w1, [x1, #2]
    2270:	78206a63 	strh	w3, [x19, x0]
    2274:	39000841 	strb	w1, [x2, #2]
    2278:	17ffffe6 	b	2210 <fwp_finish_float+0x1c>
    227c:	d503201f 	nop

0000000000002280 <fwp_trap>:
    2280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2284:	910003fd 	mov	x29, sp
    2288:	f9000bf3 	str	x19, [sp, #16]
    228c:	aa0003f3 	mov	x19, x0
    2290:	97fffe50 	bl	1bd0 <fwp_flush>
    2294:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x175b8>
    2298:	f947e884 	ldr	x4, [x4, #4048]
    229c:	aa1303e3 	mov	x3, x19
    22a0:	90000022 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    22a4:	9121a042 	add	x2, x2, #0x868
    22a8:	52800041 	mov	w1, #0x2                   	// #2
    22ac:	f9400080 	ldr	x0, [x4]
    22b0:	97fffcb0 	bl	1570 <__fprintf_chk@plt>
    22b4:	52800ca0 	mov	w0, #0x65                  	// #101
    22b8:	97fffc3e 	bl	13b0 <exit@plt>
    22bc:	d503201f 	nop

00000000000022c0 <fwp_now_ns>:
    22c0:	d100c3ff 	sub	sp, sp, #0x30
    22c4:	52800020 	mov	w0, #0x1                   	// #1
    22c8:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x175b8>
    22cc:	f947f442 	ldr	x2, [x2, #4072]
    22d0:	910023e1 	add	x1, sp, #0x8
    22d4:	a9027bfd 	stp	x29, x30, [sp, #32]
    22d8:	910083fd 	add	x29, sp, #0x20
    22dc:	f9400043 	ldr	x3, [x2]
    22e0:	f9000fe3 	str	x3, [sp, #24]
    22e4:	d2800003 	mov	x3, #0x0                   	// #0
    22e8:	97fffc52 	bl	1430 <clock_gettime@plt>
    22ec:	350002c0 	cbnz	w0, 2344 <fwp_now_ns+0x84>
    22f0:	a9408be1 	ldp	x1, x2, [sp, #8]
    22f4:	d2994003 	mov	x3, #0xca00                	// #51712
    22f8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    22fc:	9b037c20 	mul	x0, x1, x3
    2300:	9b437c21 	smulh	x1, x1, x3
    2304:	ab020000 	adds	x0, x0, x2
    2308:	937ffc42 	asr	x2, x2, #63
    230c:	9a020021 	adc	x1, x1, x2
    2310:	f100001f 	cmp	x0, #0x0
    2314:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2318:	b50001e1 	cbnz	x1, 2354 <fwp_now_ns+0x94>
    231c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x175b8>
    2320:	f947f421 	ldr	x1, [x1, #4072]
    2324:	f9400fe3 	ldr	x3, [sp, #24]
    2328:	f9400022 	ldr	x2, [x1]
    232c:	eb020063 	subs	x3, x3, x2
    2330:	d2800002 	mov	x2, #0x0                   	// #0
    2334:	540000e1 	b.ne	2350 <fwp_now_ns+0x90>  // b.any
    2338:	a9427bfd 	ldp	x29, x30, [sp, #32]
    233c:	9100c3ff 	add	sp, sp, #0x30
    2340:	d65f03c0 	ret
    2344:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2348:	9121e000 	add	x0, x0, #0x878
    234c:	97ffffcd 	bl	2280 <fwp_trap>
    2350:	97fffc6c 	bl	1500 <__stack_chk_fail@plt>
    2354:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2358:	91226000 	add	x0, x0, #0x898
    235c:	97ffffc9 	bl	2280 <fwp_trap>

0000000000002360 <fwp_format_g.constprop.0>:
    2360:	d10483ff 	sub	sp, sp, #0x120
    2364:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    2368:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x175b8>
    236c:	f947f442 	ldr	x2, [x2, #4072]
    2370:	91230084 	add	x4, x4, #0x8c0
    2374:	a90b7bfd 	stp	x29, x30, [sp, #176]
    2378:	9102c3fd 	add	x29, sp, #0xb0
    237c:	d2800803 	mov	x3, #0x40                  	// #64
    2380:	a90e63f7 	stp	x23, x24, [sp, #224]
    2384:	93407c38 	sxtw	x24, w1
    2388:	aa0303e1 	mov	x1, x3
    238c:	fd008be8 	str	d8, [sp, #272]
    2390:	1e604008 	fmov	d8, d0
    2394:	a90c53f3 	stp	x19, x20, [sp, #192]
    2398:	910083f4 	add	x20, sp, #0x20
    239c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    23a0:	aa0003f5 	mov	x21, x0
    23a4:	a91073fb 	stp	x27, x28, [sp, #256]
    23a8:	5100071c 	sub	w28, w24, #0x1
    23ac:	2a1c03e5 	mov	w5, w28
    23b0:	f9400040 	ldr	x0, [x2]
    23b4:	f90057e0 	str	x0, [sp, #168]
    23b8:	d2800000 	mov	x0, #0x0                   	// #0
    23bc:	52800042 	mov	w2, #0x2                   	// #2
    23c0:	aa1403e0 	mov	x0, x20
    23c4:	97fffc2b 	bl	1470 <__snprintf_chk@plt>
    23c8:	52800ca1 	mov	w1, #0x65                  	// #101
    23cc:	aa1403e0 	mov	x0, x20
    23d0:	97fffc84 	bl	15e0 <strchr@plt>
    23d4:	aa0003f3 	mov	x19, x0
    23d8:	52800142 	mov	w2, #0xa                   	// #10
    23dc:	91000400 	add	x0, x0, #0x1
    23e0:	d2800001 	mov	x1, #0x0                   	// #0
    23e4:	97fffc6f 	bl	15a0 <strtol@plt>
    23e8:	aa0003f7 	mov	x23, x0
    23ec:	11001400 	add	w0, w0, #0x5
    23f0:	7100541f 	cmp	w0, #0x15
    23f4:	54000d68 	b.hi	25a0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    23f8:	4b170385 	sub	w5, w28, w23
    23fc:	710000bf 	cmp	w5, #0x0
    2400:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2404:	54000b80 	b.eq	2574 <fwp_format_g.constprop.0+0x214>  // b.none
    2408:	394083e0 	ldrb	w0, [sp, #32]
    240c:	cb180273 	sub	x19, x19, x24
    2410:	91000673 	add	x19, x19, #0x1
    2414:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2418:	7100b41f 	cmp	w0, #0x2d
    241c:	9a941681 	cinc	x1, x20, eq	// eq = none
    2420:	1a9f17e4 	cset	w4, eq	// eq = none
    2424:	cb010266 	sub	x6, x19, x1
    2428:	d10004da 	sub	x26, x6, #0x1
    242c:	540018a0 	b.eq	2740 <fwp_format_g.constprop.0+0x3e0>  // b.none
    2430:	910183f9 	add	x25, sp, #0x60
    2434:	d280091b 	mov	x27, #0x48                  	// #72
    2438:	aa1903e7 	mov	x7, x25
    243c:	91000423 	add	x3, x1, #0x1
    2440:	91011cc6 	add	x6, x6, #0x47
    2444:	910004f6 	add	x22, x7, #0x1
    2448:	37f80ff7 	tbnz	w23, #31, 2644 <fwp_format_g.constprop.0+0x2e4>
    244c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    2450:	93407ef7 	sxtw	x23, w23
    2454:	390000e4 	strb	w4, [x7]
    2458:	aa1303e1 	mov	x1, x19
    245c:	aa1703e2 	mov	x2, x23
    2460:	aa1603e0 	mov	x0, x22
    2464:	b9000be5 	str	w5, [sp, #8]
    2468:	cb170374 	sub	x20, x27, x23
    246c:	a9011be3 	stp	x3, x6, [sp, #16]
    2470:	97fffbbc 	bl	1360 <memcpy@plt>
    2474:	d1000694 	sub	x20, x20, #0x1
    2478:	f9400be3 	ldr	x3, [sp, #16]
    247c:	8b1702d6 	add	x22, x22, x23
    2480:	aa1603e0 	mov	x0, x22
    2484:	aa1a03e2 	mov	x2, x26
    2488:	aa0303e1 	mov	x1, x3
    248c:	aa1403e3 	mov	x3, x20
    2490:	97fffbf0 	bl	1450 <__memcpy_chk@plt>
    2494:	8b1a02d6 	add	x22, x22, x26
    2498:	f9400fe6 	ldr	x6, [sp, #24]
    249c:	d2800900 	mov	x0, #0x48                  	// #72
    24a0:	b9400be5 	ldr	w5, [sp, #8]
    24a4:	8b170261 	add	x1, x19, x23
    24a8:	cb1400c3 	sub	x3, x6, x20
    24ac:	cb060294 	sub	x20, x20, x6
    24b0:	f101207f 	cmp	x3, #0x48
    24b4:	93407cb8 	sxtw	x24, w5
    24b8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    24bc:	aa1803e2 	mov	x2, x24
    24c0:	8b1802d3 	add	x19, x22, x24
    24c4:	8b140063 	add	x3, x3, x20
    24c8:	aa1603e0 	mov	x0, x22
    24cc:	97fffbe1 	bl	1450 <__memcpy_chk@plt>
    24d0:	cb190273 	sub	x19, x19, x25
    24d4:	d28031e0 	mov	x0, #0x18f                 	// #399
    24d8:	eb00027f 	cmp	x19, x0
    24dc:	aa1903e1 	mov	x1, x25
    24e0:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    24e4:	aa1503e0 	mov	x0, x21
    24e8:	aa1303e2 	mov	x2, x19
    24ec:	97fffb9d 	bl	1360 <memcpy@plt>
    24f0:	38336abf 	strb	wzr, [x21, x19]
    24f4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    24f8:	aa1503e0 	mov	x0, x21
    24fc:	97fffba5 	bl	1390 <strlen@plt>
    2500:	aa0003f3 	mov	x19, x0
    2504:	528005c1 	mov	w1, #0x2e                  	// #46
    2508:	aa1503e0 	mov	x0, x21
    250c:	97fffc35 	bl	15e0 <strchr@plt>
    2510:	b4000140 	cbz	x0, 2538 <fwp_format_g.constprop.0+0x1d8>
    2514:	b4000133 	cbz	x19, 2538 <fwp_format_g.constprop.0+0x1d8>
    2518:	aa1303e1 	mov	x1, x19
    251c:	d1000673 	sub	x19, x19, #0x1
    2520:	38736aa0 	ldrb	w0, [x21, x19]
    2524:	7100c01f 	cmp	w0, #0x30
    2528:	54001001 	b.ne	2728 <fwp_format_g.constprop.0+0x3c8>  // b.any
    252c:	38336abf 	strb	wzr, [x21, x19]
    2530:	b5ffff53 	cbnz	x19, 2518 <fwp_format_g.constprop.0+0x1b8>
    2534:	d503201f 	nop
    2538:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    253c:	f947f400 	ldr	x0, [x0, #4072]
    2540:	f94057e2 	ldr	x2, [sp, #168]
    2544:	f9400001 	ldr	x1, [x0]
    2548:	eb010042 	subs	x2, x2, x1
    254c:	d2800001 	mov	x1, #0x0                   	// #0
    2550:	54001061 	b.ne	275c <fwp_format_g.constprop.0+0x3fc>  // b.any
    2554:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2558:	a94c53f3 	ldp	x19, x20, [sp, #192]
    255c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2560:	a94e63f7 	ldp	x23, x24, [sp, #224]
    2564:	a95073fb 	ldp	x27, x28, [sp, #256]
    2568:	fd408be8 	ldr	d8, [sp, #272]
    256c:	910483ff 	add	sp, sp, #0x120
    2570:	d65f03c0 	ret
    2574:	1e604100 	fmov	d0, d8
    2578:	710000bf 	cmp	w5, #0x0
    257c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2580:	aa1503e0 	mov	x0, x21
    2584:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    2588:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    258c:	91236084 	add	x4, x4, #0x8d8
    2590:	52800042 	mov	w2, #0x2                   	// #2
    2594:	d2803201 	mov	x1, #0x190                 	// #400
    2598:	97fffbb6 	bl	1470 <__snprintf_chk@plt>
    259c:	17ffffd7 	b	24f8 <fwp_format_g.constprop.0+0x198>
    25a0:	cb140273 	sub	x19, x19, x20
    25a4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    25a8:	910183f9 	add	x25, sp, #0x60
    25ac:	aa1303e2 	mov	x2, x19
    25b0:	aa1403e1 	mov	x1, x20
    25b4:	aa1903e0 	mov	x0, x25
    25b8:	d2800803 	mov	x3, #0x40                  	// #64
    25bc:	97fffba5 	bl	1450 <__memcpy_chk@plt>
    25c0:	38336b3f 	strb	wzr, [x25, x19]
    25c4:	aa1903e0 	mov	x0, x25
    25c8:	528005c1 	mov	w1, #0x2e                  	// #46
    25cc:	97fffc05 	bl	15e0 <strchr@plt>
    25d0:	b40001c0 	cbz	x0, 2608 <fwp_format_g.constprop.0+0x2a8>
    25d4:	b50000b3 	cbnz	x19, 25e8 <fwp_format_g.constprop.0+0x288>
    25d8:	1400000c 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    25dc:	381ff01f 	sturb	wzr, [x0, #-1]
    25e0:	f1000673 	subs	x19, x19, #0x1
    25e4:	54000120 	b.eq	2608 <fwp_format_g.constprop.0+0x2a8>  // b.none
    25e8:	8b130320 	add	x0, x25, x19
    25ec:	385ff001 	ldurb	w1, [x0, #-1]
    25f0:	7100c03f 	cmp	w1, #0x30
    25f4:	54ffff40 	b.eq	25dc <fwp_format_g.constprop.0+0x27c>  // b.none
    25f8:	d1000673 	sub	x19, x19, #0x1
    25fc:	38736b20 	ldrb	w0, [x25, x19]
    2600:	7100b81f 	cmp	w0, #0x2e
    2604:	54000a80 	b.eq	2754 <fwp_format_g.constprop.0+0x3f4>  // b.none
    2608:	710002ff 	cmp	w23, #0x0
    260c:	528005a1 	mov	w1, #0x2d                  	// #45
    2610:	aa1903e5 	mov	x5, x25
    2614:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    2618:	aa1503e0 	mov	x0, x21
    261c:	52800566 	mov	w6, #0x2b                  	// #43
    2620:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    2624:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    2628:	91232084 	add	x4, x4, #0x8c8
    262c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2630:	52800042 	mov	w2, #0x2                   	// #2
    2634:	d2803201 	mov	x1, #0x190                 	// #400
    2638:	97fffb8e 	bl	1470 <__snprintf_chk@plt>
    263c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2640:	17ffffbe 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2644:	52800605 	mov	w5, #0x30                  	// #48
    2648:	390000e5 	strb	w5, [x7]
    264c:	d100077b 	sub	x27, x27, #0x1
    2650:	aa0303e1 	mov	x1, x3
    2654:	aa1603e0 	mov	x0, x22
    2658:	aa1b03e3 	mov	x3, x27
    265c:	aa1a03e2 	mov	x2, x26
    2660:	f90007e6 	str	x6, [sp, #8]
    2664:	b90013e4 	str	w4, [sp, #16]
    2668:	8b1a02d6 	add	x22, x22, x26
    266c:	b9001be5 	str	w5, [sp, #24]
    2670:	97fffb78 	bl	1450 <__memcpy_chk@plt>
    2674:	f94007e6 	ldr	x6, [sp, #8]
    2678:	2a3703e7 	mvn	w7, w23
    267c:	b94013e4 	ldr	w4, [sp, #16]
    2680:	cb1b00c1 	sub	x1, x6, x27
    2684:	cb06037b 	sub	x27, x27, x6
    2688:	f101203f 	cmp	x1, #0x48
    268c:	d2800906 	mov	x6, #0x48                  	// #72
    2690:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    2694:	8b1b0023 	add	x3, x1, x27
    2698:	310006ff 	cmn	w23, #0x1
    269c:	54000220 	b.eq	26e0 <fwp_format_g.constprop.0+0x380>  // b.none
    26a0:	b9401be5 	ldr	w5, [sp, #24]
    26a4:	d2800001 	mov	x1, #0x0                   	// #0
    26a8:	f101207f 	cmp	x3, #0x48
    26ac:	d1000462 	sub	x2, x3, #0x1
    26b0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    26b4:	38216ac5 	strb	w5, [x22, x1]
    26b8:	cb030003 	sub	x3, x0, x3
    26bc:	91000421 	add	x1, x1, #0x1
    26c0:	91000463 	add	x3, x3, #0x1
    26c4:	eb00007f 	cmp	x3, x0
    26c8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    26cc:	cb000063 	sub	x3, x3, x0
    26d0:	8b020063 	add	x3, x3, x2
    26d4:	6b0100ff 	cmp	w7, w1
    26d8:	54fffe8c 	b.gt	26a8 <fwp_format_g.constprop.0+0x348>
    26dc:	8b2742d6 	add	x22, x22, w7, uxtw
    26e0:	f101207f 	cmp	x3, #0x48
    26e4:	d2800905 	mov	x5, #0x48                  	// #72
    26e8:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    26ec:	aa1603e0 	mov	x0, x22
    26f0:	cb0300a1 	sub	x1, x5, x3
    26f4:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    26f8:	91000421 	add	x1, x1, #0x1
    26fc:	d1000463 	sub	x3, x3, #0x1
    2700:	eb05003f 	cmp	x1, x5
    2704:	38001402 	strb	w2, [x0], #1
    2708:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    270c:	93407f82 	sxtw	x2, w28
    2710:	cb050025 	sub	x5, x1, x5
    2714:	aa1303e1 	mov	x1, x19
    2718:	8b0300a3 	add	x3, x5, x3
    271c:	8b1802d3 	add	x19, x22, x24
    2720:	97fffb4c 	bl	1450 <__memcpy_chk@plt>
    2724:	17ffff6b 	b	24d0 <fwp_format_g.constprop.0+0x170>
    2728:	d1000421 	sub	x1, x1, #0x1
    272c:	38616aa0 	ldrb	w0, [x21, x1]
    2730:	7100b81f 	cmp	w0, #0x2e
    2734:	54fff021 	b.ne	2538 <fwp_format_g.constprop.0+0x1d8>  // b.any
    2738:	38216abf 	strb	wzr, [x21, x1]
    273c:	17ffff7f 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2740:	910187e7 	add	x7, sp, #0x61
    2744:	910183f9 	add	x25, sp, #0x60
    2748:	d28008fb 	mov	x27, #0x47                  	// #71
    274c:	390183e0 	strb	w0, [sp, #96]
    2750:	17ffff3b 	b	243c <fwp_format_g.constprop.0+0xdc>
    2754:	38336b3f 	strb	wzr, [x25, x19]
    2758:	17ffffac 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    275c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2760:	97fffb68 	bl	1500 <__stack_chk_fail@plt>

0000000000002764 <fwp_heap_report>:
    2764:	d105c3ff 	sub	sp, sp, #0x170
    2768:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    276c:	9114c042 	add	x2, x2, #0x530
    2770:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x175b8>
    2774:	f947e821 	ldr	x1, [x1, #4048]
    2778:	a9117bfd 	stp	x29, x30, [sp, #272]
    277c:	910443fd 	add	x29, sp, #0x110
    2780:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    2784:	f947f400 	ldr	x0, [x0, #4072]
    2788:	a9135bf5 	stp	x21, x22, [sp, #304]
    278c:	a91463f7 	stp	x23, x24, [sp, #320]
    2790:	a9156bf9 	stp	x25, x26, [sp, #336]
    2794:	6d1627e8 	stp	d8, d9, [sp, #352]
    2798:	fd4a1c48 	ldr	d8, [x2, #5176]
    279c:	fd4a2049 	ldr	d9, [x2, #5184]
    27a0:	f9400036 	ldr	x22, [x1]
    27a4:	f9400001 	ldr	x1, [x0]
    27a8:	f90087e1 	str	x1, [sp, #264]
    27ac:	d2800001 	mov	x1, #0x0                   	// #0
    27b0:	f949e459 	ldr	x25, [x2, #5064]
    27b4:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    27b8:	f94a1057 	ldr	x23, [x2, #5152]
    27bc:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    27c0:	f94a1458 	ldr	x24, [x2, #5160]
    27c4:	91238021 	add	x1, x1, #0x8e0
    27c8:	9123a000 	add	x0, x0, #0x8e8
    27cc:	97fffb31 	bl	1490 <fopen@plt>
    27d0:	b4000760 	cbz	x0, 28bc <fwp_heap_report+0x158>
    27d4:	528daad5 	mov	w21, #0x6d56                	// #27990
    27d8:	a91253f3 	stp	x19, x20, [sp, #288]
    27dc:	aa0003f4 	mov	x20, x0
    27e0:	910023f3 	add	x19, sp, #0x8
    27e4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    27e8:	72aae915 	movk	w21, #0x5748, lsl #16
    27ec:	d503201f 	nop
    27f0:	aa1403e2 	mov	x2, x20
    27f4:	aa1303e0 	mov	x0, x19
    27f8:	52802001 	mov	w1, #0x100                 	// #256
    27fc:	97fffbad 	bl	16b0 <fgets@plt>
    2800:	b4000280 	cbz	x0, 2850 <fwp_heap_report+0xec>
    2804:	b9400261 	ldr	w1, [x19]
    2808:	6b15003f 	cmp	w1, w21
    280c:	54ffff21 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2810:	39401260 	ldrb	w0, [x19, #4]
    2814:	7101341f 	cmp	w0, #0x4d
    2818:	54fffec1 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    281c:	394037e0 	ldrb	w0, [sp, #13]
    2820:	7100e81f 	cmp	w0, #0x3a
    2824:	54fffe61 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2828:	52800142 	mov	w2, #0xa                   	// #10
    282c:	d2800001 	mov	x1, #0x0                   	// #0
    2830:	91003be0 	add	x0, sp, #0xe
    2834:	97fffb5b 	bl	15a0 <strtol@plt>
    2838:	aa1403e2 	mov	x2, x20
    283c:	aa0003fa 	mov	x26, x0
    2840:	52802001 	mov	w1, #0x100                 	// #256
    2844:	aa1303e0 	mov	x0, x19
    2848:	97fffb9a 	bl	16b0 <fgets@plt>
    284c:	b5fffdc0 	cbnz	x0, 2804 <fwp_heap_report+0xa0>
    2850:	aa1403e0 	mov	x0, x20
    2854:	97fffb0b 	bl	1480 <fclose@plt>
    2858:	a95253f3 	ldp	x19, x20, [sp, #288]
    285c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    2860:	f947f400 	ldr	x0, [x0, #4072]
    2864:	f94087e2 	ldr	x2, [sp, #264]
    2868:	f9400001 	ldr	x1, [x0]
    286c:	eb010042 	subs	x2, x2, x1
    2870:	d2800001 	mov	x1, #0x0                   	// #0
    2874:	54000281 	b.ne	28c4 <fwp_heap_report+0x160>  // b.any
    2878:	a9517bfd 	ldp	x29, x30, [sp, #272]
    287c:	aa1a03e6 	mov	x6, x26
    2880:	aa1903e5 	mov	x5, x25
    2884:	aa1803e4 	mov	x4, x24
    2888:	a9556bf9 	ldp	x25, x26, [sp, #336]
    288c:	aa1703e3 	mov	x3, x23
    2890:	a95463f7 	ldp	x23, x24, [sp, #320]
    2894:	aa1603e0 	mov	x0, x22
    2898:	a9535bf5 	ldp	x21, x22, [sp, #304]
    289c:	1e604121 	fmov	d1, d9
    28a0:	1e604100 	fmov	d0, d8
    28a4:	90000022 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    28a8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    28ac:	91242042 	add	x2, x2, #0x908
    28b0:	9105c3ff 	add	sp, sp, #0x170
    28b4:	52800041 	mov	w1, #0x2                   	// #2
    28b8:	17fffb2e 	b	1570 <__fprintf_chk@plt>
    28bc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    28c0:	17ffffe7 	b	285c <fwp_heap_report+0xf8>
    28c4:	a91253f3 	stp	x19, x20, [sp, #288]
    28c8:	97fffb0e 	bl	1500 <__stack_chk_fail@plt>
    28cc:	d503201f 	nop

00000000000028d0 <fwp_heap_init>:
    28d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    28d4:	90000183 	adrp	x3, 32000 <fwp_heap+0xad0>
    28d8:	9110c061 	add	x1, x3, #0x430
    28dc:	910003fd 	mov	x29, sp
    28e0:	a90153f3 	stp	x19, x20, [sp, #16]
    28e4:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    28e8:	9114c262 	add	x2, x19, #0x530
    28ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    28f0:	52800024 	mov	w4, #0x1                   	// #1
    28f4:	52800200 	mov	w0, #0x10                  	// #16
    28f8:	b913a444 	str	w4, [x2, #5028]
    28fc:	d503201f 	nop
    2900:	b8004420 	str	w0, [x1], #4
    2904:	11004000 	add	w0, w0, #0x10
    2908:	7104401f 	cmp	w0, #0x110
    290c:	54ffffa1 	b.ne	2900 <fwp_heap_init+0x30>  // b.any
    2910:	90000022 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    2914:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2918:	90000181 	adrp	x1, 32000 <fwp_heap+0xad0>
    291c:	9111c021 	add	x1, x1, #0x470
    2920:	3dc38843 	ldr	q3, [x2, #3616]
    2924:	d2800000 	mov	x0, #0x0                   	// #0
    2928:	4e040401 	dup	v1.4s, v0.s[0]
    292c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    2930:	0f215400 	shl	v0.2s, v0.2s, #1
    2934:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    2938:	3ca06821 	str	q1, [x1, x0]
    293c:	91004000 	add	x0, x0, #0x10
    2940:	f101801f 	cmp	x0, #0x60
    2944:	54ffff21 	b.ne	2928 <fwp_heap_init+0x58>  // b.any
    2948:	90000184 	adrp	x4, 32000 <fwp_heap+0xad0>
    294c:	9110c063 	add	x3, x3, #0x430
    2950:	91134084 	add	x4, x4, #0x4d0
    2954:	9114c266 	add	x6, x19, #0x530
    2958:	d2800002 	mov	x2, #0x0                   	// #0
    295c:	d2800000 	mov	x0, #0x0                   	// #0
    2960:	d2880205 	mov	x5, #0x4010                	// #16400
    2964:	d503201f 	nop
    2968:	910f0001 	add	x1, x0, #0x3c0
    296c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2970:	eb02003f 	cmp	x1, x2
    2974:	540000a2 	b.cs	2988 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    2978:	91000400 	add	x0, x0, #0x1
    297c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2980:	eb02003f 	cmp	x1, x2
    2984:	54ffffa3 	b.cc	2978 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    2988:	91004042 	add	x2, x2, #0x10
    298c:	38001480 	strb	w0, [x4], #1
    2990:	eb05005f 	cmp	x2, x5
    2994:	54fffea1 	b.ne	2968 <fwp_heap_init+0x98>  // b.any
    2998:	528000b5 	mov	w21, #0x5                   	// #5
    299c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    29a0:	14000004 	b	29b0 <fwp_heap_init+0xe0>
    29a4:	d342fe94 	lsr	x20, x20, #2
    29a8:	710006b5 	subs	w21, w21, #0x1
    29ac:	54000720 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    29b0:	91404296 	add	x22, x20, #0x10, lsl #12
    29b4:	d2800005 	mov	x5, #0x0                   	// #0
    29b8:	aa1603e1 	mov	x1, x22
    29bc:	12800004 	mov	w4, #0xffffffff            	// #-1
    29c0:	52880443 	mov	w3, #0x4022                	// #16418
    29c4:	52800002 	mov	w2, #0x0                   	// #0
    29c8:	d2800000 	mov	x0, #0x0                   	// #0
    29cc:	97fffaf1 	bl	1590 <mmap@plt>
    29d0:	aa0003e6 	mov	x6, x0
    29d4:	b100041f 	cmn	x0, #0x1
    29d8:	54fffe60 	b.eq	29a4 <fwp_heap_init+0xd4>  // b.none
    29dc:	b40005a0 	cbz	x0, 2a90 <fwp_heap_init+0x1c0>
    29e0:	d350fe94 	lsr	x20, x20, #16
    29e4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    29e8:	8b0000c7 	add	x7, x6, x0
    29ec:	9114c275 	add	x21, x19, #0x530
    29f0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    29f4:	8b140a81 	add	x1, x20, x20, lsl #2
    29f8:	d2800005 	mov	x5, #0x0                   	// #0
    29fc:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a00:	d37df021 	lsl	x1, x1, #3
    2a04:	52880443 	mov	w3, #0x4022                	// #16418
    2a08:	52800002 	mov	w2, #0x0                   	// #0
    2a0c:	d2800000 	mov	x0, #0x0                   	// #0
    2a10:	f909daa7 	str	x7, [x21, #5040]
    2a14:	f909dea6 	str	x6, [x21, #5048]
    2a18:	f909e2b6 	str	x22, [x21, #5056]
    2a1c:	f909eab4 	str	x20, [x21, #5072]
    2a20:	f90a02a1 	str	x1, [x21, #5120]
    2a24:	97fffadb 	bl	1590 <mmap@plt>
    2a28:	aa0003e1 	mov	x1, x0
    2a2c:	b100041f 	cmn	x0, #0x1
    2a30:	54000300 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    2a34:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2a38:	9126e000 	add	x0, x0, #0x9b8
    2a3c:	f909fea1 	str	x1, [x21, #5112]
    2a40:	97fffb14 	bl	1690 <getenv@plt>
    2a44:	52800002 	mov	w2, #0x0                   	// #0
    2a48:	aa0003e1 	mov	x1, x0
    2a4c:	b40000e0 	cbz	x0, 2a68 <fwp_heap_init+0x198>
    2a50:	39400000 	ldrb	w0, [x0]
    2a54:	340000a0 	cbz	w0, 2a68 <fwp_heap_init+0x198>
    2a58:	7100c000 	subs	w0, w0, #0x30
    2a5c:	54000120 	b.eq	2a80 <fwp_heap_init+0x1b0>  // b.none
    2a60:	7100001f 	cmp	w0, #0x0
    2a64:	1a9f07e2 	cset	w2, ne	// ne = any
    2a68:	9114c273 	add	x19, x19, #0x530
    2a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2a70:	b913aa62 	str	w2, [x19, #5032]
    2a74:	a94153f3 	ldp	x19, x20, [sp, #16]
    2a78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2a7c:	d65f03c0 	ret
    2a80:	39400420 	ldrb	w0, [x1, #1]
    2a84:	7100001f 	cmp	w0, #0x0
    2a88:	1a9f07e2 	cset	w2, ne	// ne = any
    2a8c:	17fffff7 	b	2a68 <fwp_heap_init+0x198>
    2a90:	97fffc90 	bl	1cd0 <fwp_heap_oom>

0000000000002a94 <fwp_wake_io>:
    2a94:	d00000e9 	adrp	x9, 20000 <__data_start>
    2a98:	91014122 	add	x2, x9, #0x50
    2a9c:	f9400001 	ldr	x1, [x0]
    2aa0:	5280000a 	mov	w10, #0x0                   	// #0
    2aa4:	f9401446 	ldr	x6, [x2, #40]
    2aa8:	52800008 	mov	w8, #0x0                   	// #0
    2aac:	4f000400 	movi	v0.4s, #0x0
    2ab0:	52800027 	mov	w7, #0x1                   	// #1
    2ab4:	aa0103e2 	mov	x2, x1
    2ab8:	b4000321 	cbz	x1, 2b1c <fwp_wake_io+0x88>
    2abc:	f9408c25 	ldr	x5, [x1, #280]
    2ac0:	39015c27 	strb	w7, [x1, #87]
    2ac4:	b4000165 	cbz	x5, 2af0 <fwp_wake_io+0x5c>
    2ac8:	a9520c24 	ldp	x4, x3, [x1, #288]
    2acc:	b4000364 	cbz	x4, 2b38 <fwp_wake_io+0xa4>
    2ad0:	f9009483 	str	x3, [x4, #296]
    2ad4:	f9409423 	ldr	x3, [x1, #296]
    2ad8:	b4000043 	cbz	x3, 2ae0 <fwp_wake_io+0x4c>
    2adc:	f9009064 	str	x4, [x3, #288]
    2ae0:	91080023 	add	x3, x1, #0x200
    2ae4:	f900943f 	str	xzr, [x1, #296]
    2ae8:	3c918060 	stur	q0, [x3, #-232]
    2aec:	f9400001 	ldr	x1, [x0]
    2af0:	f9402843 	ldr	x3, [x2, #80]
    2af4:	f2001c7f 	tst	x3, #0xff000000ff
    2af8:	54fffde1 	b.ne	2ab4 <fwp_wake_io+0x20>  // b.any
    2afc:	39015047 	strb	w7, [x2, #84]
    2b00:	f900805f 	str	xzr, [x2, #256]
    2b04:	b40001e6 	cbz	x6, 2b40 <fwp_wake_io+0xac>
    2b08:	f90080c2 	str	x2, [x6, #256]
    2b0c:	aa0203e6 	mov	x6, x2
    2b10:	52800028 	mov	w8, #0x1                   	// #1
    2b14:	aa0103e2 	mov	x2, x1
    2b18:	b5fffd21 	cbnz	x1, 2abc <fwp_wake_io+0x28>
    2b1c:	3400006a 	cbz	w10, 2b28 <fwp_wake_io+0x94>
    2b20:	91014120 	add	x0, x9, #0x50
    2b24:	f900180b 	str	x11, [x0, #48]
    2b28:	34000068 	cbz	w8, 2b34 <fwp_wake_io+0xa0>
    2b2c:	91014129 	add	x9, x9, #0x50
    2b30:	f9001526 	str	x6, [x9, #40]
    2b34:	d65f03c0 	ret
    2b38:	f90000a3 	str	x3, [x5]
    2b3c:	17ffffe7 	b	2ad8 <fwp_wake_io+0x44>
    2b40:	aa0203eb 	mov	x11, x2
    2b44:	5280002a 	mov	w10, #0x1                   	// #1
    2b48:	17fffff1 	b	2b0c <fwp_wake_io+0x78>
    2b4c:	d503201f 	nop

0000000000002b50 <fwp_poll_events>:
    2b50:	d10103ff 	sub	sp, sp, #0x40
    2b54:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    2b58:	f947f400 	ldr	x0, [x0, #4072]
    2b5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2b60:	910083fd 	add	x29, sp, #0x20
    2b64:	a90353f3 	stp	x19, x20, [sp, #48]
    2b68:	d00000f4 	adrp	x20, 20000 <__data_start>
    2b6c:	f9400001 	ldr	x1, [x0]
    2b70:	f9000fe1 	str	x1, [sp, #24]
    2b74:	d2800001 	mov	x1, #0x0                   	// #0
    2b78:	97fffdd2 	bl	22c0 <fwp_now_ns>
    2b7c:	91014281 	add	x1, x20, #0x50
    2b80:	f9401c33 	ldr	x19, [x1, #56]
    2b84:	b4000e93 	cbz	x19, 2d54 <fwp_poll_events+0x204>
    2b88:	aa1303e1 	mov	x1, x19
    2b8c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2b90:	14000005 	b	2ba4 <fwp_poll_events+0x54>
    2b94:	f9408821 	ldr	x1, [x1, #272]
    2b98:	eb03005f 	cmp	x2, x3
    2b9c:	9a83d042 	csel	x2, x2, x3, le
    2ba0:	b40000c1 	cbz	x1, 2bb8 <fwp_poll_events+0x68>
    2ba4:	f9403423 	ldr	x3, [x1, #104]
    2ba8:	b6ffff62 	tbz	x2, #63, 2b94 <fwp_poll_events+0x44>
    2bac:	f9408821 	ldr	x1, [x1, #272]
    2bb0:	aa0303e2 	mov	x2, x3
    2bb4:	b5ffff81 	cbnz	x1, 2ba4 <fwp_poll_events+0x54>
    2bb8:	b7f80ce2 	tbnz	x2, #63, 2d54 <fwp_poll_events+0x204>
    2bbc:	cb000042 	sub	x2, x2, x0
    2bc0:	f100005f 	cmp	x2, #0x0
    2bc4:	540005cd 	b.le	2c7c <fwp_poll_events+0x12c>
    2bc8:	d2869b60 	mov	x0, #0x34db                	// #13531
    2bcc:	d2884801 	mov	x1, #0x4240                	// #16960
    2bd0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2bd4:	f2a001e1 	movk	x1, #0xf, lsl #16
    2bd8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2bdc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2be0:	f2e86360 	movk	x0, #0x431b, lsl #48
    2be4:	9b407c40 	smulh	x0, x2, x0
    2be8:	9352fc00 	asr	x0, x0, #18
    2bec:	cb82fc00 	sub	x0, x0, x2, asr #63
    2bf0:	9b018802 	msub	x2, x0, x1, x2
    2bf4:	f100005f 	cmp	x2, #0x0
    2bf8:	9a800400 	cinc	x0, x0, ne	// ne = any
    2bfc:	eb03001f 	cmp	x0, x3
    2c00:	54000a0c 	b.gt	2d40 <fwp_poll_events+0x1f0>
    2c04:	340003c0 	cbz	w0, 2c7c <fwp_poll_events+0x12c>
    2c08:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2c0c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2c10:	72a20c42 	movk	w2, #0x1062, lsl #16
    2c14:	9ba27c02 	umull	x2, w0, w2
    2c18:	d366fc43 	lsr	x3, x2, #38
    2c1c:	aa0303e2 	mov	x2, x3
    2c20:	1b048063 	msub	w3, w3, w4, w0
    2c24:	9b217c63 	smull	x3, w3, w1
    2c28:	d2800001 	mov	x1, #0x0                   	// #0
    2c2c:	910023e0 	add	x0, sp, #0x8
    2c30:	a9008fe2 	stp	x2, x3, [sp, #8]
    2c34:	97fffa67 	bl	15d0 <nanosleep@plt>
    2c38:	91014280 	add	x0, x20, #0x50
    2c3c:	f9401c13 	ldr	x19, [x0, #56]
    2c40:	97fffda0 	bl	22c0 <fwp_now_ns>
    2c44:	aa0003e6 	mov	x6, x0
    2c48:	b50001f3 	cbnz	x19, 2c84 <fwp_poll_events+0x134>
    2c4c:	d503201f 	nop
    2c50:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    2c54:	f947f400 	ldr	x0, [x0, #4072]
    2c58:	f9400fe2 	ldr	x2, [sp, #24]
    2c5c:	f9400001 	ldr	x1, [x0]
    2c60:	eb010042 	subs	x2, x2, x1
    2c64:	d2800001 	mov	x1, #0x0                   	// #0
    2c68:	540008c1 	b.ne	2d80 <fwp_poll_events+0x230>  // b.any
    2c6c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2c70:	a94353f3 	ldp	x19, x20, [sp, #48]
    2c74:	910103ff 	add	sp, sp, #0x40
    2c78:	d65f03c0 	ret
    2c7c:	97fffd91 	bl	22c0 <fwp_now_ns>
    2c80:	aa0003e6 	mov	x6, x0
    2c84:	4f000400 	movi	v0.4s, #0x0
    2c88:	91014288 	add	x8, x20, #0x50
    2c8c:	52800027 	mov	w7, #0x1                   	// #1
    2c90:	f9403661 	ldr	x1, [x19, #104]
    2c94:	aa1303e5 	mov	x5, x19
    2c98:	f9408a73 	ldr	x19, [x19, #272]
    2c9c:	eb06003f 	cmp	x1, x6
    2ca0:	5400032c 	b.gt	2d04 <fwp_poll_events+0x1b4>
    2ca4:	394154a0 	ldrb	w0, [x5, #85]
    2ca8:	36000120 	tbz	w0, #0, 2ccc <fwp_poll_events+0x17c>
    2cac:	f94084a0 	ldr	x0, [x5, #264]
    2cb0:	b40003c0 	cbz	x0, 2d28 <fwp_poll_events+0x1d8>
    2cb4:	f9008813 	str	x19, [x0, #272]
    2cb8:	b4000053 	cbz	x19, 2cc0 <fwp_poll_events+0x170>
    2cbc:	f9008660 	str	x0, [x19, #264]
    2cc0:	910800a0 	add	x0, x5, #0x200
    2cc4:	390154bf 	strb	wzr, [x5, #85]
    2cc8:	3c908000 	stur	q0, [x0, #-248]
    2ccc:	f94030a0 	ldr	x0, [x5, #96]
    2cd0:	390158a7 	strb	w7, [x5, #86]
    2cd4:	f100001f 	cmp	x0, #0x0
    2cd8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2cdc:	5400018d 	b.le	2d0c <fwp_poll_events+0x1bc>
    2ce0:	f94028a0 	ldr	x0, [x5, #80]
    2ce4:	f2001c1f 	tst	x0, #0xff000000ff
    2ce8:	540000e1 	b.ne	2d04 <fwp_poll_events+0x1b4>  // b.any
    2cec:	f9401500 	ldr	x0, [x8, #40]
    2cf0:	390150a7 	strb	w7, [x5, #84]
    2cf4:	f90080bf 	str	xzr, [x5, #256]
    2cf8:	b40001e0 	cbz	x0, 2d34 <fwp_poll_events+0x1e4>
    2cfc:	f9001505 	str	x5, [x8, #40]
    2d00:	f9008005 	str	x5, [x0, #256]
    2d04:	b5fffc73 	cbnz	x19, 2c90 <fwp_poll_events+0x140>
    2d08:	17ffffd2 	b	2c50 <fwp_poll_events+0x100>
    2d0c:	394144a0 	ldrb	w0, [x5, #81]
    2d10:	3707fe80 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d14:	394140a0 	ldrb	w0, [x5, #80]
    2d18:	3707fe40 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d1c:	aa0503e0 	mov	x0, x5
    2d20:	97fffd14 	bl	2170 <fwp_cancel_tree.part.0>
    2d24:	17ffffef 	b	2ce0 <fwp_poll_events+0x190>
    2d28:	91014281 	add	x1, x20, #0x50
    2d2c:	f9001c33 	str	x19, [x1, #56]
    2d30:	17ffffe2 	b	2cb8 <fwp_poll_events+0x168>
    2d34:	f9001505 	str	x5, [x8, #40]
    2d38:	f9001905 	str	x5, [x8, #48]
    2d3c:	17fffff2 	b	2d04 <fwp_poll_events+0x1b4>
    2d40:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2d44:	d2989362 	mov	x2, #0xc49b                	// #50331
    2d48:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2d4c:	f2a00402 	movk	x2, #0x20, lsl #16
    2d50:	17ffffb6 	b	2c28 <fwp_poll_events+0xd8>
    2d54:	97fffb9f 	bl	1bd0 <fwp_flush>
    2d58:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x175b8>
    2d5c:	f947e863 	ldr	x3, [x3, #4048]
    2d60:	d2800562 	mov	x2, #0x2b                  	// #43
    2d64:	d2800021 	mov	x1, #0x1                   	// #1
    2d68:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2d6c:	91272000 	add	x0, x0, #0x9c8
    2d70:	f9400063 	ldr	x3, [x3]
    2d74:	97fffa23 	bl	1600 <fwrite@plt>
    2d78:	52800ca0 	mov	w0, #0x65                  	// #101
    2d7c:	97fff98d 	bl	13b0 <exit@plt>
    2d80:	97fff9e0 	bl	1500 <__stack_chk_fail@plt>

0000000000002d84 <fwp_rc_forget_slot>:
    2d84:	aa0003e1 	mov	x1, x0
    2d88:	39400000 	ldrb	w0, [x0]
    2d8c:	7103fc1f 	cmp	w0, #0xff
    2d90:	54000040 	b.eq	2d98 <fwp_rc_forget_slot+0x14>  // b.none
    2d94:	d65f03c0 	ret
    2d98:	ca414420 	eor	x0, x1, x1, lsr #17
    2d9c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2da0:	ca402400 	eor	x0, x0, x0, lsr #9
    2da4:	910003fd 	mov	x29, sp
    2da8:	92401c00 	and	x0, x0, #0xff
    2dac:	f9000bf3 	str	x19, [sp, #16]
    2db0:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    2db4:	9114c262 	add	x2, x19, #0x530
    2db8:	910a2403 	add	x3, x0, #0x289
    2dbc:	8b000c40 	add	x0, x2, x0, lsl #3
    2dc0:	8b030c43 	add	x3, x2, x3, lsl #3
    2dc4:	f94a2400 	ldr	x0, [x0, #5192]
    2dc8:	b50000a0 	cbnz	x0, 2ddc <fwp_rc_forget_slot+0x58>
    2dcc:	14000011 	b	2e10 <fwp_rc_forget_slot+0x8c>
    2dd0:	91004003 	add	x3, x0, #0x10
    2dd4:	f9400800 	ldr	x0, [x0, #16]
    2dd8:	b40001c0 	cbz	x0, 2e10 <fwp_rc_forget_slot+0x8c>
    2ddc:	f9400002 	ldr	x2, [x0]
    2de0:	eb02003f 	cmp	x1, x2
    2de4:	54ffff61 	b.ne	2dd0 <fwp_rc_forget_slot+0x4c>  // b.any
    2de8:	f9400801 	ldr	x1, [x0, #16]
    2dec:	9114c273 	add	x19, x19, #0x530
    2df0:	f9000061 	str	x1, [x3]
    2df4:	97fff9f3 	bl	15c0 <free@plt>
    2df8:	f94e2660 	ldr	x0, [x19, #7240]
    2dfc:	d1000400 	sub	x0, x0, #0x1
    2e00:	f90e2660 	str	x0, [x19, #7240]
    2e04:	f9400bf3 	ldr	x19, [sp, #16]
    2e08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e0c:	d65f03c0 	ret
    2e10:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2e14:	9127e000 	add	x0, x0, #0x9f8
    2e18:	97fffd1a 	bl	2280 <fwp_trap>
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_rc_prepare_chunk>:
    2e20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2e24:	910003fd 	mov	x29, sp
    2e28:	a9025bf5 	stp	x21, x22, [sp, #32]
    2e2c:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    2e30:	9114c2c2 	add	x2, x22, #0x530
    2e34:	b9401c03 	ldr	w3, [x0, #28]
    2e38:	aa0103f5 	mov	x21, x1
    2e3c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e40:	aa0003f4 	mov	x20, x0
    2e44:	f94e2440 	ldr	x0, [x2, #7240]
    2e48:	b4000440 	cbz	x0, 2ed0 <fwp_rc_prepare_chunk+0xb0>
    2e4c:	d2800013 	mov	x19, #0x0                   	// #0
    2e50:	35000203 	cbnz	w3, 2e90 <fwp_rc_prepare_chunk+0x70>
    2e54:	b4000361 	cbz	x1, 2ec0 <fwp_rc_prepare_chunk+0xa0>
    2e58:	f9401280 	ldr	x0, [x20, #32]
    2e5c:	97fff9d9 	bl	15c0 <free@plt>
    2e60:	aa1503e0 	mov	x0, x21
    2e64:	d2800021 	mov	x1, #0x1                   	// #1
    2e68:	97fff99e 	bl	14e0 <calloc@plt>
    2e6c:	f9001280 	str	x0, [x20, #32]
    2e70:	b5000460 	cbnz	x0, 2efc <fwp_rc_prepare_chunk+0xdc>
    2e74:	97fffb97 	bl	1cd0 <fwp_heap_oom>
    2e78:	97ffffc3 	bl	2d84 <fwp_rc_forget_slot>
    2e7c:	91000673 	add	x19, x19, #0x1
    2e80:	b9401e83 	ldr	w3, [x20, #28]
    2e84:	eb13007f 	cmp	x3, x19
    2e88:	54000169 	b.ls	2eb4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2e8c:	d503201f 	nop
    2e90:	f9401283 	ldr	x3, [x20, #32]
    2e94:	8b130060 	add	x0, x3, x19
    2e98:	38736863 	ldrb	w3, [x3, x19]
    2e9c:	7103fc7f 	cmp	w3, #0xff
    2ea0:	54fffec0 	b.eq	2e78 <fwp_rc_prepare_chunk+0x58>  // b.none
    2ea4:	b9401e83 	ldr	w3, [x20, #28]
    2ea8:	91000673 	add	x19, x19, #0x1
    2eac:	eb13007f 	cmp	x3, x19
    2eb0:	54ffff08 	b.hi	2e90 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2eb4:	eb0302bf 	cmp	x21, x3
    2eb8:	54000121 	b.ne	2edc <fwp_rc_prepare_chunk+0xbc>  // b.any
    2ebc:	b5000335 	cbnz	x21, 2f20 <fwp_rc_prepare_chunk+0x100>
    2ec0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ec4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ec8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2ecc:	d65f03c0 	ret
    2ed0:	2a0303e3 	mov	w3, w3
    2ed4:	eb0302bf 	cmp	x21, x3
    2ed8:	54ffff20 	b.eq	2ebc <fwp_rc_prepare_chunk+0x9c>  // b.none
    2edc:	9114c2c2 	add	x2, x22, #0x530
    2ee0:	f9401280 	ldr	x0, [x20, #32]
    2ee4:	f94e2841 	ldr	x1, [x2, #7248]
    2ee8:	cb030021 	sub	x1, x1, x3
    2eec:	f90e2841 	str	x1, [x2, #7248]
    2ef0:	97fff9b4 	bl	15c0 <free@plt>
    2ef4:	b5fffb75 	cbnz	x21, 2e60 <fwp_rc_prepare_chunk+0x40>
    2ef8:	f900129f 	str	xzr, [x20, #32]
    2efc:	9114c2d6 	add	x22, x22, #0x530
    2f00:	f94e2ac0 	ldr	x0, [x22, #7248]
    2f04:	b9001e95 	str	w21, [x20, #28]
    2f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f0c:	8b150000 	add	x0, x0, x21
    2f10:	f90e2ac0 	str	x0, [x22, #7248]
    2f14:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f1c:	d65f03c0 	ret
    2f20:	f9401280 	ldr	x0, [x20, #32]
    2f24:	aa1503e2 	mov	x2, x21
    2f28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f2c:	52800001 	mov	w1, #0x0                   	// #0
    2f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f38:	17fff966 	b	14d0 <memset@plt>
    2f3c:	d503201f 	nop

0000000000002f40 <fwp_heap_refill>:
    2f40:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2f44:	910003fd 	mov	x29, sp
    2f48:	a9025bf5 	stp	x21, x22, [sp, #32]
    2f4c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    2f50:	9114c2b5 	add	x21, x21, #0x530
    2f54:	aa0003f6 	mov	x22, x0
    2f58:	d2800020 	mov	x0, #0x1                   	// #1
    2f5c:	a90153f3 	stp	x19, x20, [sp, #16]
    2f60:	a90363f7 	stp	x23, x24, [sp, #48]
    2f64:	2a0103f7 	mov	w23, w1
    2f68:	2a0203f8 	mov	w24, w2
    2f6c:	97fffb69 	bl	1d10 <fwp_heap_chunks>
    2f70:	aa0003f3 	mov	x19, x0
    2f74:	f949fea2 	ldr	x2, [x21, #5112]
    2f78:	8b000800 	add	x0, x0, x0, lsl #2
    2f7c:	2a1703e1 	mov	w1, w23
    2f80:	52800025 	mov	w5, #0x1                   	// #1
    2f84:	d37df000 	lsl	x0, x0, #3
    2f88:	910f0021 	add	x1, x1, #0x3c0
    2f8c:	8b000054 	add	x20, x2, x0
    2f90:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2f94:	52a00024 	mov	w4, #0x10000               	// #65536
    2f98:	38206845 	strb	w5, [x2, x0]
    2f9c:	aa1403e0 	mov	x0, x20
    2fa0:	39000698 	strb	w24, [x20, #1]
    2fa4:	39000a97 	strb	w23, [x20, #2]
    2fa8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2fac:	b9000681 	str	w1, [x20, #4]
    2fb0:	2a0103e5 	mov	w5, w1
    2fb4:	8b0300a2 	add	x2, x5, x3
    2fb8:	1ac10881 	udiv	w1, w4, w1
    2fbc:	9ac50842 	udiv	x2, x2, x5
    2fc0:	b9000a81 	str	w1, [x20, #8]
    2fc4:	92404021 	and	x1, x1, #0x1ffff
    2fc8:	b9001a82 	str	w2, [x20, #24]
    2fcc:	97ffff95 	bl	2e20 <fwp_rc_prepare_chunk>
    2fd0:	f949daa0 	ldr	x0, [x21, #5040]
    2fd4:	29408a81 	ldp	w1, w2, [x20, #4]
    2fd8:	8b134000 	add	x0, x0, x19, lsl #16
    2fdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2fe0:	8b214003 	add	x3, x0, w1, uxtw
    2fe4:	9ba20021 	umaddl	x1, w1, w2, x0
    2fe8:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fec:	a90086c3 	stp	x3, x1, [x22, #8]
    2ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ff4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2ff8:	d65f03c0 	ret
    2ffc:	d503201f 	nop

0000000000003000 <fwp_mem_free>:
    3000:	b40003c0 	cbz	x0, 3078 <fwp_mem_free+0x78>
    3004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3008:	910003fd 	mov	x29, sp
    300c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3010:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    3014:	9114c2a1 	add	x1, x21, #0x530
    3018:	a90153f3 	stp	x19, x20, [sp, #16]
    301c:	aa0003f3 	mov	x19, x0
    3020:	f949d823 	ldr	x3, [x1, #5040]
    3024:	f949ec22 	ldr	x2, [x1, #5080]
    3028:	cb030000 	sub	x0, x0, x3
    302c:	eb02401f 	cmp	x0, x2, lsl #16
    3030:	540001c2 	b.cs	3068 <fwp_mem_free+0x68>  // b.hs, b.nlast
    3034:	d350fc16 	lsr	x22, x0, #16
    3038:	a90363f7 	stp	x23, x24, [sp, #48]
    303c:	f949fc22 	ldr	x2, [x1, #5112]
    3040:	8b160ad4 	add	x20, x22, x22, lsl #2
    3044:	d37df294 	lsl	x20, x20, #3
    3048:	ab140057 	adds	x23, x2, x20
    304c:	540000c0 	b.eq	3064 <fwp_mem_free+0x64>  // b.none
    3050:	38746842 	ldrb	w2, [x2, x20]
    3054:	7100045f 	cmp	w2, #0x1
    3058:	54000120 	b.eq	307c <fwp_mem_free+0x7c>  // b.none
    305c:	7100085f 	cmp	w2, #0x2
    3060:	540005e0 	b.eq	311c <fwp_mem_free+0x11c>  // b.none
    3064:	a94363f7 	ldp	x23, x24, [sp, #48]
    3068:	a94153f3 	ldp	x19, x20, [sp, #16]
    306c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3070:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3074:	d65f03c0 	ret
    3078:	d65f03c0 	ret
    307c:	f94012f8 	ldr	x24, [x23, #32]
    3080:	b94006e1 	ldr	w1, [x23, #4]
    3084:	f90023f9 	str	x25, [sp, #64]
    3088:	2a0103e2 	mov	w2, w1
    308c:	394006f9 	ldrb	w25, [x23, #1]
    3090:	39400af4 	ldrb	w20, [x23, #2]
    3094:	b4000158 	cbz	x24, 30bc <fwp_mem_free+0xbc>
    3098:	92403e76 	and	x22, x19, #0xffff
    309c:	9ac20ad6 	udiv	x22, x22, x2
    30a0:	38766b01 	ldrb	w1, [x24, x22]
    30a4:	8b160300 	add	x0, x24, x22
    30a8:	7103fc3f 	cmp	w1, #0xff
    30ac:	54000980 	b.eq	31dc <fwp_mem_free+0x1dc>  // b.none
    30b0:	38366b1f 	strb	wzr, [x24, x22]
    30b4:	b94006e1 	ldr	w1, [x23, #4]
    30b8:	2a0103e2 	mov	w2, w1
    30bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    30c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    30c4:	cb390000 	sub	x0, x0, w25, uxtb
    30c8:	8b340074 	add	x20, x3, w20, uxtb
    30cc:	9114c2b5 	add	x21, x21, #0x530
    30d0:	1e630021 	ucvtf	d1, w1
    30d4:	d37ae400 	lsl	x0, x0, #6
    30d8:	8b140c14 	add	x20, x0, x20, lsl #3
    30dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    30e0:	f8746aa0 	ldr	x0, [x21, x20]
    30e4:	f94023f9 	ldr	x25, [sp, #64]
    30e8:	aa2003e0 	mvn	x0, x0
    30ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    30f0:	f9000260 	str	x0, [x19]
    30f4:	f8346ab3 	str	x19, [x21, x20]
    30f8:	f94a12a0 	ldr	x0, [x21, #5152]
    30fc:	1e612800 	fadd	d0, d0, d1
    3100:	a94153f3 	ldp	x19, x20, [sp, #16]
    3104:	cb020000 	sub	x0, x0, x2
    3108:	f90a12a0 	str	x0, [x21, #5152]
    310c:	fd0a22a0 	str	d0, [x21, #5184]
    3110:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3114:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3118:	d65f03c0 	ret
    311c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    3120:	8b000063 	add	x3, x3, x0
    3124:	eb03027f 	cmp	x19, x3
    3128:	54fff9e1 	b.ne	3064 <fwp_mem_free+0x64>  // b.any
    312c:	fd400ae1 	ldr	d1, [x23, #16]
    3130:	fd4a2020 	ldr	d0, [x1, #5184]
    3134:	f9400ae0 	ldr	x0, [x23, #16]
    3138:	7e61d821 	ucvtf	d1, d1
    313c:	f94a1022 	ldr	x2, [x1, #5152]
    3140:	f94012f3 	ldr	x19, [x23, #32]
    3144:	1e612800 	fadd	d0, d0, d1
    3148:	cb000042 	sub	x2, x2, x0
    314c:	f90a1022 	str	x2, [x1, #5152]
    3150:	fd0a2020 	str	d0, [x1, #5184]
    3154:	b40000b3 	cbz	x19, 3168 <fwp_mem_free+0x168>
    3158:	39400260 	ldrb	w0, [x19]
    315c:	7103fc1f 	cmp	w0, #0xff
    3160:	54000380 	b.eq	31d0 <fwp_mem_free+0x1d0>  // b.none
    3164:	3900027f 	strb	wzr, [x19]
    3168:	b9400ee2 	ldr	w2, [x23, #12]
    316c:	b4000142 	cbz	x2, 3194 <fwp_mem_free+0x194>
    3170:	9114c2a1 	add	x1, x21, #0x530
    3174:	8b160040 	add	x0, x2, x22
    3178:	8b000800 	add	x0, x0, x0, lsl #2
    317c:	f949fc21 	ldr	x1, [x1, #5112]
    3180:	8b140034 	add	x20, x1, x20
    3184:	8b000c20 	add	x0, x1, x0, lsl #3
    3188:	3802869f 	strb	wzr, [x20], #40
    318c:	eb00029f 	cmp	x20, x0
    3190:	54ffffc1 	b.ne	3188 <fwp_mem_free+0x188>  // b.any
    3194:	9114c2a0 	add	x0, x21, #0x530
    3198:	f94a1801 	ldr	x1, [x0, #5168]
    319c:	f949f803 	ldr	x3, [x0, #5104]
    31a0:	8b020021 	add	x1, x1, x2
    31a4:	f90a1801 	str	x1, [x0, #5168]
    31a8:	eb16007f 	cmp	x3, x22
    31ac:	54000049 	b.ls	31b4 <fwp_mem_free+0x1b4>  // b.plast
    31b0:	f909f816 	str	x22, [x0, #5104]
    31b4:	9114c2b5 	add	x21, x21, #0x530
    31b8:	f949f6a0 	ldr	x0, [x21, #5096]
    31bc:	eb16001f 	cmp	x0, x22
    31c0:	54fff529 	b.ls	3064 <fwp_mem_free+0x64>  // b.plast
    31c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    31c8:	f909f6b6 	str	x22, [x21, #5096]
    31cc:	17ffffa7 	b	3068 <fwp_mem_free+0x68>
    31d0:	aa1303e0 	mov	x0, x19
    31d4:	97fffeec 	bl	2d84 <fwp_rc_forget_slot>
    31d8:	17ffffe3 	b	3164 <fwp_mem_free+0x164>
    31dc:	97fffeea 	bl	2d84 <fwp_rc_forget_slot>
    31e0:	17ffffb4 	b	30b0 <fwp_mem_free+0xb0>

00000000000031e4 <fwp_heap_alloc_big>:
    31e4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    31e8:	910003fd 	mov	x29, sp
    31ec:	a90153f3 	stp	x19, x20, [sp, #16]
    31f0:	a9025bf5 	stp	x21, x22, [sp, #32]
    31f4:	a90363f7 	stp	x23, x24, [sp, #48]
    31f8:	aa0003f7 	mov	x23, x0
    31fc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    3200:	a9046bf9 	stp	x25, x26, [sp, #64]
    3204:	eb0002ff 	cmp	x23, x0
    3208:	54000888 	b.hi	3318 <fwp_heap_alloc_big+0x134>  // b.pmore
    320c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3210:	8b0002f4 	add	x20, x23, x0
    3214:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xcb0>
    3218:	9114c359 	add	x25, x26, #0x530
    321c:	d350fe94 	lsr	x20, x20, #16
    3220:	2a0103f5 	mov	w21, w1
    3224:	aa1403e0 	mov	x0, x20
    3228:	97fffaba 	bl	1d10 <fwp_heap_chunks>
    322c:	f949ff22 	ldr	x2, [x25, #5112]
    3230:	8b000813 	add	x19, x0, x0, lsl #2
    3234:	aa0003f8 	mov	x24, x0
    3238:	52800043 	mov	w3, #0x2                   	// #2
    323c:	d37df273 	lsl	x19, x19, #3
    3240:	d2800021 	mov	x1, #0x1                   	// #1
    3244:	8b130040 	add	x0, x2, x19
    3248:	38336843 	strb	w3, [x2, x19]
    324c:	39000415 	strb	w21, [x0, #1]
    3250:	b9000c14 	str	w20, [x0, #12]
    3254:	f9000817 	str	x23, [x0, #16]
    3258:	97fffef2 	bl	2e20 <fwp_rc_prepare_chunk>
    325c:	f100069f 	cmp	x20, #0x1
    3260:	54000269 	b.ls	32ac <fwp_heap_alloc_big+0xc8>  // b.plast
    3264:	8b180294 	add	x20, x20, x24
    3268:	9100a273 	add	x19, x19, #0x28
    326c:	a90573fb 	stp	x27, x28, [sp, #80]
    3270:	5280007b 	mov	w27, #0x3                   	// #3
    3274:	8b140a94 	add	x20, x20, x20, lsl #2
    3278:	2a1803fc 	mov	w28, w24
    327c:	9adb2296 	lsl	x22, x20, x27
    3280:	f949ff35 	ldr	x21, [x25, #5112]
    3284:	d2800001 	mov	x1, #0x0                   	// #0
    3288:	8b1302b4 	add	x20, x21, x19
    328c:	aa1403e0 	mov	x0, x20
    3290:	97fffee4 	bl	2e20 <fwp_rc_prepare_chunk>
    3294:	38336abb 	strb	w27, [x21, x19]
    3298:	9100a273 	add	x19, x19, #0x28
    329c:	b9000e9c 	str	w28, [x20, #12]
    32a0:	eb1302df 	cmp	x22, x19
    32a4:	54fffee1 	b.ne	3280 <fwp_heap_alloc_big+0x9c>  // b.any
    32a8:	a94573fb 	ldp	x27, x28, [sp, #80]
    32ac:	9114c353 	add	x19, x26, #0x530
    32b0:	aa1703e2 	mov	x2, x23
    32b4:	52800001 	mov	w1, #0x0                   	// #0
    32b8:	f949da60 	ldr	x0, [x19, #5040]
    32bc:	8b184018 	add	x24, x0, x24, lsl #16
    32c0:	aa1803e0 	mov	x0, x24
    32c4:	97fff883 	bl	14d0 <memset@plt>
    32c8:	f94a1260 	ldr	x0, [x19, #5152]
    32cc:	ab170000 	adds	x0, x0, x23
    32d0:	54000242 	b.cs	3318 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    32d4:	f94a1661 	ldr	x1, [x19, #5160]
    32d8:	f90a1260 	str	x0, [x19, #5152]
    32dc:	eb01001f 	cmp	x0, x1
    32e0:	54000049 	b.ls	32e8 <fwp_heap_alloc_big+0x104>  // b.plast
    32e4:	f90a1660 	str	x0, [x19, #5160]
    32e8:	9114c35a 	add	x26, x26, #0x530
    32ec:	9e6202e0 	scvtf	d0, x23
    32f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32f4:	aa1803e0 	mov	x0, x24
    32f8:	fd4a1f41 	ldr	d1, [x26, #5176]
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	1e602820 	fadd	d0, d1, d0
    3304:	a94363f7 	ldp	x23, x24, [sp, #48]
    3308:	fd0a1f40 	str	d0, [x26, #5176]
    330c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3310:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3314:	d65f03c0 	ret
    3318:	a90573fb 	stp	x27, x28, [sp, #80]
    331c:	97fffa6d 	bl	1cd0 <fwp_heap_oom>

0000000000003320 <fwp_heap_alloc_slow>:
    3320:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3324:	910003fd 	mov	x29, sp
    3328:	a90153f3 	stp	x19, x20, [sp, #16]
    332c:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    3330:	9114c262 	add	x2, x19, #0x530
    3334:	a9025bf5 	stp	x21, x22, [sp, #32]
    3338:	aa0003f5 	mov	x21, x0
    333c:	2a0103f4 	mov	w20, w1
    3340:	b953a440 	ldr	w0, [x2, #5028]
    3344:	34000600 	cbz	w0, 3404 <fwp_heap_alloc_slow+0xe4>
    3348:	f14012bf 	cmp	x21, #0x4, lsl #12
    334c:	54000628 	b.hi	3410 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3350:	91003ea0 	add	x0, x21, #0xf
    3354:	9114c262 	add	x2, x19, #0x530
    3358:	f9001bf7 	str	x23, [sp, #48]
    335c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3360:	8b401040 	add	x0, x2, x0, lsr #4
    3364:	cb34c084 	sub	x4, x4, w20, sxtw
    3368:	d37ae484 	lsl	x4, x4, #6
    336c:	397e8003 	ldrb	w3, [x0, #4000]
    3370:	910f0060 	add	x0, x3, #0x3c0
    3374:	aa0303e1 	mov	x1, x3
    3378:	8b030463 	add	x3, x3, x3, lsl #1
    337c:	8b030c83 	add	x3, x4, x3, lsl #3
    3380:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3384:	2a1703f6 	mov	w22, w23
    3388:	f8636844 	ldr	x4, [x2, x3]
    338c:	b40004e4 	cbz	x4, 3428 <fwp_heap_alloc_slow+0x108>
    3390:	f9400080 	ldr	x0, [x4]
    3394:	aa2003e0 	mvn	x0, x0
    3398:	f8236840 	str	x0, [x2, x3]
    339c:	7100069f 	cmp	w20, #0x1
    33a0:	aa0403e0 	mov	x0, x4
    33a4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    33a8:	52800001 	mov	w1, #0x0                   	// #0
    33ac:	97fff849 	bl	14d0 <memset@plt>
    33b0:	aa0003e4 	mov	x4, x0
    33b4:	9114c260 	add	x0, x19, #0x530
    33b8:	f94a1001 	ldr	x1, [x0, #5152]
    33bc:	ab160021 	adds	x1, x1, x22
    33c0:	540005c2 	b.cs	3478 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    33c4:	f94a1402 	ldr	x2, [x0, #5160]
    33c8:	f90a1001 	str	x1, [x0, #5152]
    33cc:	eb02003f 	cmp	x1, x2
    33d0:	54000049 	b.ls	33d8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    33d4:	f90a1401 	str	x1, [x0, #5160]
    33d8:	9114c273 	add	x19, x19, #0x530
    33dc:	1e6302e1 	ucvtf	d1, w23
    33e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33e4:	aa0403e0 	mov	x0, x4
    33e8:	fd4a1e60 	ldr	d0, [x19, #5176]
    33ec:	f9401bf7 	ldr	x23, [sp, #48]
    33f0:	1e612800 	fadd	d0, d0, d1
    33f4:	fd0a1e60 	str	d0, [x19, #5176]
    33f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3400:	d65f03c0 	ret
    3404:	97fffd33 	bl	28d0 <fwp_heap_init>
    3408:	f14012bf 	cmp	x21, #0x4, lsl #12
    340c:	54fffa29 	b.ls	3350 <fwp_heap_alloc_slow+0x30>  // b.plast
    3410:	2a1403e1 	mov	w1, w20
    3414:	aa1503e0 	mov	x0, x21
    3418:	a94153f3 	ldp	x19, x20, [sp, #16]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3424:	17ffff70 	b	31e4 <fwp_heap_alloc_big>
    3428:	8b030042 	add	x2, x2, x3
    342c:	f9400444 	ldr	x4, [x2, #8]
    3430:	b4000104 	cbz	x4, 3450 <fwp_heap_alloc_slow+0x130>
    3434:	f9400840 	ldr	x0, [x2, #16]
    3438:	cb040000 	sub	x0, x0, x4
    343c:	eb16001f 	cmp	x0, x22
    3440:	54000083 	b.cc	3450 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3444:	8b160080 	add	x0, x4, x22
    3448:	f9000440 	str	x0, [x2, #8]
    344c:	17ffffd4 	b	339c <fwp_heap_alloc_slow+0x7c>
    3450:	52800302 	mov	w2, #0x18                  	// #24
    3454:	52807804 	mov	w4, #0x3c0                 	// #960
    3458:	9114c260 	add	x0, x19, #0x530
    345c:	9ba27c23 	umull	x3, w1, w2
    3460:	2a1403e2 	mov	w2, w20
    3464:	9b240e84 	smaddl	x4, w20, w4, x3
    3468:	8b040000 	add	x0, x0, x4
    346c:	97fffeb5 	bl	2f40 <fwp_heap_refill>
    3470:	aa0003e4 	mov	x4, x0
    3474:	17ffffca 	b	339c <fwp_heap_alloc_slow+0x7c>
    3478:	97fffa16 	bl	1cd0 <fwp_heap_oom>
    347c:	d503201f 	nop

0000000000003480 <fwp_rc_free_arr>:
    3480:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3484:	9114c063 	add	x3, x3, #0x530
    3488:	f949d861 	ldr	x1, [x3, #5040]
    348c:	f949ec62 	ldr	x2, [x3, #5080]
    3490:	cb010001 	sub	x1, x0, x1
    3494:	eb02403f 	cmp	x1, x2, lsl #16
    3498:	54000342 	b.cs	3500 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    349c:	d350fc22 	lsr	x2, x1, #16
    34a0:	f949fc65 	ldr	x5, [x3, #5112]
    34a4:	8b020842 	add	x2, x2, x2, lsl #2
    34a8:	d37df042 	lsl	x2, x2, #3
    34ac:	8b0200a4 	add	x4, x5, x2
    34b0:	f9401083 	ldr	x3, [x4, #32]
    34b4:	b4000263 	cbz	x3, 3500 <fwp_rc_free_arr+0x80>
    34b8:	386268a2 	ldrb	w2, [x5, x2]
    34bc:	7100085f 	cmp	w2, #0x2
    34c0:	540001c0 	b.eq	34f8 <fwp_rc_free_arr+0x78>  // b.none
    34c4:	7100045f 	cmp	w2, #0x1
    34c8:	540001c1 	b.ne	3500 <fwp_rc_free_arr+0x80>  // b.any
    34cc:	29430885 	ldp	w5, w2, [x4, #24]
    34d0:	92403c21 	and	x1, x1, #0xffff
    34d4:	9b057c21 	mul	x1, x1, x5
    34d8:	d360fc21 	lsr	x1, x1, #32
    34dc:	eb02003f 	cmp	x1, x2
    34e0:	54000102 	b.cs	3500 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    34e4:	8b010063 	add	x3, x3, x1
    34e8:	39400061 	ldrb	w1, [x3]
    34ec:	7100043f 	cmp	w1, #0x1
    34f0:	54000081 	b.ne	3500 <fwp_rc_free_arr+0x80>  // b.any
    34f4:	17fffec3 	b	3000 <fwp_mem_free>
    34f8:	72003c3f 	tst	w1, #0xffff
    34fc:	54ffff60 	b.eq	34e8 <fwp_rc_free_arr+0x68>  // b.none
    3500:	d65f03c0 	ret

0000000000003504 <fwp_heap_alloc>:
    3504:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3508:	910003fd 	mov	x29, sp
    350c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3510:	b00000f6 	adrp	x22, 20000 <__data_start>
    3514:	910142c2 	add	x2, x22, #0x50
    3518:	a90363f7 	stp	x23, x24, [sp, #48]
    351c:	b9404058 	ldr	w24, [x2, #64]
    3520:	a90153f3 	stp	x19, x20, [sp, #16]
    3524:	7100031f 	cmp	w24, #0x0
    3528:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    352c:	54000861 	b.ne	3638 <fwp_heap_alloc+0x134>  // b.any
    3530:	d0000177 	adrp	x23, 31000 <fwp_root_context+0xcb0>
    3534:	9114c2f3 	add	x19, x23, #0x530
    3538:	f140101f 	cmp	x0, #0x4, lsl #12
    353c:	b953a662 	ldr	w2, [x19, #5028]
    3540:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3544:	54000740 	b.eq	362c <fwp_heap_alloc+0x128>  // b.none
    3548:	91003c03 	add	x3, x0, #0xf
    354c:	937c7c22 	sbfiz	x2, x1, #4, #32
    3550:	cb21c042 	sub	x2, x2, w1, sxtw
    3554:	8b431263 	add	x3, x19, x3, lsr #4
    3558:	d37ae442 	lsl	x2, x2, #6
    355c:	397e8063 	ldrb	w3, [x3, #4000]
    3560:	910f0064 	add	x4, x3, #0x3c0
    3564:	8b030463 	add	x3, x3, x3, lsl #1
    3568:	8b030c43 	add	x3, x2, x3, lsl #3
    356c:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    3570:	2a1503f4 	mov	w20, w21
    3574:	f8636a64 	ldr	x4, [x19, x3]
    3578:	b40004c4 	cbz	x4, 3610 <fwp_heap_alloc+0x10c>
    357c:	f9400085 	ldr	x5, [x4]
    3580:	7100043f 	cmp	w1, #0x1
    3584:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3588:	aa0403e0 	mov	x0, x4
    358c:	aa2503e5 	mvn	x5, x5
    3590:	52800001 	mov	w1, #0x0                   	// #0
    3594:	f8236a65 	str	x5, [x19, x3]
    3598:	97fff7ce 	bl	14d0 <memset@plt>
    359c:	aa0003e4 	mov	x4, x0
    35a0:	f94a1260 	ldr	x0, [x19, #5152]
    35a4:	ab140000 	adds	x0, x0, x20
    35a8:	540006e2 	b.cs	3684 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    35ac:	f94a1661 	ldr	x1, [x19, #5160]
    35b0:	f90a1260 	str	x0, [x19, #5152]
    35b4:	eb01001f 	cmp	x0, x1
    35b8:	54000049 	b.ls	35c0 <fwp_heap_alloc+0xbc>  // b.plast
    35bc:	f90a1660 	str	x0, [x19, #5160]
    35c0:	9114c2e0 	add	x0, x23, #0x530
    35c4:	1e6302a1 	ucvtf	d1, w21
    35c8:	fd4a1c00 	ldr	d0, [x0, #5176]
    35cc:	1e612800 	fadd	d0, d0, d1
    35d0:	fd0a1c00 	str	d0, [x0, #5176]
    35d4:	34000138 	cbz	w24, 35f8 <fwp_heap_alloc+0xf4>
    35d8:	9114c2e1 	add	x1, x23, #0x530
    35dc:	910142c0 	add	x0, x22, #0x50
    35e0:	fd4a1020 	ldr	d0, [x1, #5152]
    35e4:	6d458402 	ldp	d2, d1, [x0, #88]
    35e8:	7e61d800 	ucvtf	d0, d0
    35ec:	1e623800 	fsub	d0, d0, d2
    35f0:	1e612010 	fcmpe	d0, d1
    35f4:	540002cc 	b.gt	364c <fwp_heap_alloc+0x148>
    35f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35fc:	aa0403e0 	mov	x0, x4
    3600:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3604:	a94363f7 	ldp	x23, x24, [sp, #48]
    3608:	a8c47bfd 	ldp	x29, x30, [sp], #64
    360c:	d65f03c0 	ret
    3610:	8b030263 	add	x3, x19, x3
    3614:	f9400464 	ldr	x4, [x3, #8]
    3618:	b40000a4 	cbz	x4, 362c <fwp_heap_alloc+0x128>
    361c:	f9400862 	ldr	x2, [x3, #16]
    3620:	cb040042 	sub	x2, x2, x4
    3624:	eb02029f 	cmp	x20, x2
    3628:	54000209 	b.ls	3668 <fwp_heap_alloc+0x164>  // b.plast
    362c:	97ffff3d 	bl	3320 <fwp_heap_alloc_slow>
    3630:	aa0003e4 	mov	x4, x0
    3634:	17ffffe8 	b	35d4 <fwp_heap_alloc+0xd0>
    3638:	a9448c44 	ldp	x4, x3, [x2, #72]
    363c:	91000484 	add	x4, x4, #0x1
    3640:	8b000063 	add	x3, x3, x0
    3644:	a9048c44 	stp	x4, x3, [x2, #72]
    3648:	17ffffba 	b	3530 <fwp_heap_alloc+0x2c>
    364c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3650:	fd003000 	str	d0, [x0, #96]
    3654:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3658:	aa0403e0 	mov	x0, x4
    365c:	a94363f7 	ldp	x23, x24, [sp, #48]
    3660:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3664:	d65f03c0 	ret
    3668:	7100043f 	cmp	w1, #0x1
    366c:	8b140085 	add	x5, x4, x20
    3670:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3674:	52800001 	mov	w1, #0x0                   	// #0
    3678:	aa0403e0 	mov	x0, x4
    367c:	f9000465 	str	x5, [x3, #8]
    3680:	17ffffc6 	b	3598 <fwp_heap_alloc+0x94>
    3684:	97fff993 	bl	1cd0 <fwp_heap_oom>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <fwp_data.part.0.constprop.0>:
    3690:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3694:	910003fd 	mov	x29, sp
    3698:	a9025bf5 	stp	x21, x22, [sp, #32]
    369c:	b00000f6 	adrp	x22, 20000 <__data_start>
    36a0:	910142c1 	add	x1, x22, #0x50
    36a4:	a90363f7 	stp	x23, x24, [sp, #48]
    36a8:	b9404038 	ldr	w24, [x1, #64]
    36ac:	a90153f3 	stp	x19, x20, [sp, #16]
    36b0:	aa0003f4 	mov	x20, x0
    36b4:	340000b8 	cbz	w24, 36c8 <fwp_data.part.0.constprop.0+0x38>
    36b8:	a9448022 	ldp	x2, x0, [x1, #72]
    36bc:	91000442 	add	x2, x2, #0x1
    36c0:	91006000 	add	x0, x0, #0x18
    36c4:	a9048022 	stp	x2, x0, [x1, #72]
    36c8:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    36cc:	9114c2a2 	add	x2, x21, #0x530
    36d0:	b953a440 	ldr	w0, [x2, #5028]
    36d4:	34000840 	cbz	w0, 37dc <fwp_data.part.0.constprop.0+0x14c>
    36d8:	f90023f9 	str	x25, [sp, #64]
    36dc:	397e8841 	ldrb	w1, [x2, #4002]
    36e0:	910f0020 	add	x0, x1, #0x3c0
    36e4:	8b010421 	add	x1, x1, x1, lsl #1
    36e8:	d37df021 	lsl	x1, x1, #3
    36ec:	b8607859 	ldr	w25, [x2, x0, lsl #2]
    36f0:	2a1903f7 	mov	w23, w25
    36f4:	f8616853 	ldr	x19, [x2, x1]
    36f8:	b4000633 	cbz	x19, 37bc <fwp_data.part.0.constprop.0+0x12c>
    36fc:	f9400260 	ldr	x0, [x19]
    3700:	aa2003e0 	mvn	x0, x0
    3704:	f8216840 	str	x0, [x2, x1]
    3708:	f10062ff 	cmp	x23, #0x18
    370c:	540000e9 	b.ls	3728 <fwp_data.part.0.constprop.0+0x98>  // b.plast
    3710:	d10066e2 	sub	x2, x23, #0x19
    3714:	91006260 	add	x0, x19, #0x18
    3718:	927df042 	and	x2, x2, #0xfffffffffffffff8
    371c:	52800001 	mov	w1, #0x0                   	// #0
    3720:	91002042 	add	x2, x2, #0x8
    3724:	97fff76b 	bl	14d0 <memset@plt>
    3728:	9114c2a1 	add	x1, x21, #0x530
    372c:	f94a1020 	ldr	x0, [x1, #5152]
    3730:	ab170000 	adds	x0, x0, x23
    3734:	54000682 	b.cs	3804 <fwp_data.part.0.constprop.0+0x174>  // b.hs, b.nlast
    3738:	f94a1422 	ldr	x2, [x1, #5160]
    373c:	f90a1020 	str	x0, [x1, #5152]
    3740:	eb02001f 	cmp	x0, x2
    3744:	54000049 	b.ls	374c <fwp_data.part.0.constprop.0+0xbc>  // b.plast
    3748:	f90a1420 	str	x0, [x1, #5160]
    374c:	9114c2a0 	add	x0, x21, #0x530
    3750:	1e630321 	ucvtf	d1, w25
    3754:	f94023f9 	ldr	x25, [sp, #64]
    3758:	fd4a1c00 	ldr	d0, [x0, #5176]
    375c:	1e612800 	fadd	d0, d0, d1
    3760:	fd0a1c00 	str	d0, [x0, #5176]
    3764:	34000138 	cbz	w24, 3788 <fwp_data.part.0.constprop.0+0xf8>
    3768:	9114c2b5 	add	x21, x21, #0x530
    376c:	910142d6 	add	x22, x22, #0x50
    3770:	fd4a12a0 	ldr	d0, [x21, #5152]
    3774:	6d4586c2 	ldp	d2, d1, [x22, #88]
    3778:	7e61d800 	ucvtf	d0, d0
    377c:	1e623800 	fsub	d0, d0, d2
    3780:	1e612010 	fcmpe	d0, d1
    3784:	5400036c 	b.gt	37f0 <fwp_data.part.0.constprop.0+0x160>
    3788:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    378c:	fd471000 	ldr	d0, [x0, #3616]
    3790:	aa1303e0 	mov	x0, x19
    3794:	fd000260 	str	d0, [x19]
    3798:	f9400281 	ldr	x1, [x20]
    379c:	f9000661 	str	x1, [x19, #8]
    37a0:	f9400681 	ldr	x1, [x20, #8]
    37a4:	f9000a61 	str	x1, [x19, #16]
    37a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    37ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    37b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    37b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    37b8:	d65f03c0 	ret
    37bc:	8b010042 	add	x2, x2, x1
    37c0:	f9400453 	ldr	x19, [x2, #8]
    37c4:	b40000b3 	cbz	x19, 37d8 <fwp_data.part.0.constprop.0+0x148>
    37c8:	f9400840 	ldr	x0, [x2, #16]
    37cc:	cb130000 	sub	x0, x0, x19
    37d0:	eb0002ff 	cmp	x23, x0
    37d4:	54000129 	b.ls	37f8 <fwp_data.part.0.constprop.0+0x168>  // b.plast
    37d8:	f94023f9 	ldr	x25, [sp, #64]
    37dc:	52800001 	mov	w1, #0x0                   	// #0
    37e0:	d2800300 	mov	x0, #0x18                  	// #24
    37e4:	97ffff48 	bl	3504 <fwp_heap_alloc>
    37e8:	aa0003f3 	mov	x19, x0
    37ec:	17ffffde 	b	3764 <fwp_data.part.0.constprop.0+0xd4>
    37f0:	fd0032c0 	str	d0, [x22, #96]
    37f4:	17ffffe5 	b	3788 <fwp_data.part.0.constprop.0+0xf8>
    37f8:	8b170260 	add	x0, x19, x23
    37fc:	f9000440 	str	x0, [x2, #8]
    3800:	17ffffc2 	b	3708 <fwp_data.part.0.constprop.0+0x78>
    3804:	97fff933 	bl	1cd0 <fwp_heap_oom>
    3808:	d503201f 	nop
    380c:	d503201f 	nop

0000000000003810 <fwp_array_new_packed.constprop.0>:
    3810:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3814:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    3818:	910003fd 	mov	x29, sp
    381c:	f9000bf3 	str	x19, [sp, #16]
    3820:	eb01001f 	cmp	x0, x1
    3824:	54000148 	b.hi	384c <fwp_array_new_packed.constprop.0+0x3c>  // b.pmore
    3828:	aa0003f3 	mov	x19, x0
    382c:	91000400 	add	x0, x0, #0x1
    3830:	52800021 	mov	w1, #0x1                   	// #1
    3834:	d37df000 	lsl	x0, x0, #3
    3838:	97ffff33 	bl	3504 <fwp_heap_alloc>
    383c:	f9000013 	str	x19, [x0]
    3840:	f9400bf3 	ldr	x19, [sp, #16]
    3844:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3848:	d65f03c0 	ret
    384c:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    3850:	91288000 	add	x0, x0, #0xa20
    3854:	97fffa8b 	bl	2280 <fwp_trap>
    3858:	d503201f 	nop
    385c:	d503201f 	nop

0000000000003860 <fwp_drop1>:
    3860:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3864:	910003fd 	mov	x29, sp
    3868:	a90153f3 	stp	x19, x20, [sp, #16]
    386c:	f90013f5 	str	x21, [sp, #32]
    3870:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    3874:	9114c2b4 	add	x20, x21, #0x530
    3878:	f949da81 	ldr	x1, [x20, #5040]
    387c:	f949ee82 	ldr	x2, [x20, #5080]
    3880:	cb010001 	sub	x1, x0, x1
    3884:	eb02403f 	cmp	x1, x2, lsl #16
    3888:	54000382 	b.cs	38f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    388c:	d350fc22 	lsr	x2, x1, #16
    3890:	f949fe84 	ldr	x4, [x20, #5112]
    3894:	8b020842 	add	x2, x2, x2, lsl #2
    3898:	d37df042 	lsl	x2, x2, #3
    389c:	8b020083 	add	x3, x4, x2
    38a0:	f9401073 	ldr	x19, [x3, #32]
    38a4:	b40002b3 	cbz	x19, 38f8 <fwp_drop1+0x98>
    38a8:	38626882 	ldrb	w2, [x4, x2]
    38ac:	7100085f 	cmp	w2, #0x2
    38b0:	540002c0 	b.eq	3908 <fwp_drop1+0xa8>  // b.none
    38b4:	7100045f 	cmp	w2, #0x1
    38b8:	54000201 	b.ne	38f8 <fwp_drop1+0x98>  // b.any
    38bc:	29430864 	ldp	w4, w2, [x3, #24]
    38c0:	92403c21 	and	x1, x1, #0xffff
    38c4:	9b047c21 	mul	x1, x1, x4
    38c8:	d360fc21 	lsr	x1, x1, #32
    38cc:	eb02003f 	cmp	x1, x2
    38d0:	54000142 	b.cs	38f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    38d4:	8b010273 	add	x19, x19, x1
    38d8:	39400261 	ldrb	w1, [x19]
    38dc:	340000e1 	cbz	w1, 38f8 <fwp_drop1+0x98>
    38e0:	7100043f 	cmp	w1, #0x1
    38e4:	540001e0 	b.eq	3920 <fwp_drop1+0xc0>  // b.none
    38e8:	7103fc3f 	cmp	w1, #0xff
    38ec:	540002e0 	b.eq	3948 <fwp_drop1+0xe8>  // b.none
    38f0:	51000421 	sub	w1, w1, #0x1
    38f4:	39000261 	strb	w1, [x19]
    38f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    38fc:	f94013f5 	ldr	x21, [sp, #32]
    3900:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3904:	d65f03c0 	ret
    3908:	72003c3f 	tst	w1, #0xffff
    390c:	54fffe60 	b.eq	38d8 <fwp_drop1+0x78>  // b.none
    3910:	a94153f3 	ldp	x19, x20, [sp, #16]
    3914:	f94013f5 	ldr	x21, [sp, #32]
    3918:	a8c37bfd 	ldp	x29, x30, [sp], #48
    391c:	d65f03c0 	ret
    3920:	f9400813 	ldr	x19, [x0, #16]
    3924:	97fffed7 	bl	3480 <fwp_rc_free_arr>
    3928:	9114c2a0 	add	x0, x21, #0x530
    392c:	f949d801 	ldr	x1, [x0, #5040]
    3930:	f949ec00 	ldr	x0, [x0, #5080]
    3934:	cb010261 	sub	x1, x19, x1
    3938:	eb00403f 	cmp	x1, x0, lsl #16
    393c:	54fffde2 	b.cs	38f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    3940:	aa1303e0 	mov	x0, x19
    3944:	17ffffd2 	b	388c <fwp_drop1+0x2c>
    3948:	ca534660 	eor	x0, x19, x19, lsr #17
    394c:	9114c2b5 	add	x21, x21, #0x530
    3950:	ca402400 	eor	x0, x0, x0, lsr #9
    3954:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3958:	f94a2400 	ldr	x0, [x0, #5192]
    395c:	b5000080 	cbnz	x0, 396c <fwp_drop1+0x10c>
    3960:	14000010 	b	39a0 <fwp_drop1+0x140>
    3964:	f9400800 	ldr	x0, [x0, #16]
    3968:	b40001c0 	cbz	x0, 39a0 <fwp_drop1+0x140>
    396c:	f9400001 	ldr	x1, [x0]
    3970:	eb13003f 	cmp	x1, x19
    3974:	54ffff81 	b.ne	3964 <fwp_drop1+0x104>  // b.any
    3978:	f9400401 	ldr	x1, [x0, #8]
    397c:	d1000421 	sub	x1, x1, #0x1
    3980:	f9000401 	str	x1, [x0, #8]
    3984:	f103f83f 	cmp	x1, #0xfe
    3988:	54fffb81 	b.ne	38f8 <fwp_drop1+0x98>  // b.any
    398c:	aa1303e0 	mov	x0, x19
    3990:	97fffcfd 	bl	2d84 <fwp_rc_forget_slot>
    3994:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3998:	39000260 	strb	w0, [x19]
    399c:	17ffffd7 	b	38f8 <fwp_drop1+0x98>
    39a0:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    39a4:	9127e000 	add	x0, x0, #0x9f8
    39a8:	97fffa36 	bl	2280 <fwp_trap>
    39ac:	d503201f 	nop

00000000000039b0 <fwp_drop0>:
    39b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39b4:	910003fd 	mov	x29, sp
    39b8:	a90153f3 	stp	x19, x20, [sp, #16]
    39bc:	f90013f5 	str	x21, [sp, #32]
    39c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    39c4:	9114c2b4 	add	x20, x21, #0x530
    39c8:	f949da81 	ldr	x1, [x20, #5040]
    39cc:	f949ee82 	ldr	x2, [x20, #5080]
    39d0:	cb010001 	sub	x1, x0, x1
    39d4:	eb02403f 	cmp	x1, x2, lsl #16
    39d8:	54000382 	b.cs	3a48 <fwp_drop0+0x98>  // b.hs, b.nlast
    39dc:	d350fc22 	lsr	x2, x1, #16
    39e0:	f949fe84 	ldr	x4, [x20, #5112]
    39e4:	8b020842 	add	x2, x2, x2, lsl #2
    39e8:	d37df042 	lsl	x2, x2, #3
    39ec:	8b020083 	add	x3, x4, x2
    39f0:	f9401073 	ldr	x19, [x3, #32]
    39f4:	b40002b3 	cbz	x19, 3a48 <fwp_drop0+0x98>
    39f8:	38626882 	ldrb	w2, [x4, x2]
    39fc:	7100085f 	cmp	w2, #0x2
    3a00:	540002c0 	b.eq	3a58 <fwp_drop0+0xa8>  // b.none
    3a04:	7100045f 	cmp	w2, #0x1
    3a08:	54000201 	b.ne	3a48 <fwp_drop0+0x98>  // b.any
    3a0c:	29430864 	ldp	w4, w2, [x3, #24]
    3a10:	92403c21 	and	x1, x1, #0xffff
    3a14:	9b047c21 	mul	x1, x1, x4
    3a18:	d360fc21 	lsr	x1, x1, #32
    3a1c:	eb02003f 	cmp	x1, x2
    3a20:	54000142 	b.cs	3a48 <fwp_drop0+0x98>  // b.hs, b.nlast
    3a24:	8b010273 	add	x19, x19, x1
    3a28:	39400261 	ldrb	w1, [x19]
    3a2c:	340000e1 	cbz	w1, 3a48 <fwp_drop0+0x98>
    3a30:	7100043f 	cmp	w1, #0x1
    3a34:	540001e0 	b.eq	3a70 <fwp_drop0+0xc0>  // b.none
    3a38:	7103fc3f 	cmp	w1, #0xff
    3a3c:	540002e0 	b.eq	3a98 <fwp_drop0+0xe8>  // b.none
    3a40:	51000421 	sub	w1, w1, #0x1
    3a44:	39000261 	strb	w1, [x19]
    3a48:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a4c:	f94013f5 	ldr	x21, [sp, #32]
    3a50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a54:	d65f03c0 	ret
    3a58:	72003c3f 	tst	w1, #0xffff
    3a5c:	54fffe60 	b.eq	3a28 <fwp_drop0+0x78>  // b.none
    3a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a64:	f94013f5 	ldr	x21, [sp, #32]
    3a68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a6c:	d65f03c0 	ret
    3a70:	f9400813 	ldr	x19, [x0, #16]
    3a74:	97fffe83 	bl	3480 <fwp_rc_free_arr>
    3a78:	9114c2a0 	add	x0, x21, #0x530
    3a7c:	f949d801 	ldr	x1, [x0, #5040]
    3a80:	f949ec00 	ldr	x0, [x0, #5080]
    3a84:	cb010261 	sub	x1, x19, x1
    3a88:	eb00403f 	cmp	x1, x0, lsl #16
    3a8c:	54fffde2 	b.cs	3a48 <fwp_drop0+0x98>  // b.hs, b.nlast
    3a90:	aa1303e0 	mov	x0, x19
    3a94:	17ffffd2 	b	39dc <fwp_drop0+0x2c>
    3a98:	ca534660 	eor	x0, x19, x19, lsr #17
    3a9c:	9114c2b5 	add	x21, x21, #0x530
    3aa0:	ca402400 	eor	x0, x0, x0, lsr #9
    3aa4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3aa8:	f94a2400 	ldr	x0, [x0, #5192]
    3aac:	b5000080 	cbnz	x0, 3abc <fwp_drop0+0x10c>
    3ab0:	14000010 	b	3af0 <fwp_drop0+0x140>
    3ab4:	f9400800 	ldr	x0, [x0, #16]
    3ab8:	b40001c0 	cbz	x0, 3af0 <fwp_drop0+0x140>
    3abc:	f9400001 	ldr	x1, [x0]
    3ac0:	eb13003f 	cmp	x1, x19
    3ac4:	54ffff81 	b.ne	3ab4 <fwp_drop0+0x104>  // b.any
    3ac8:	f9400401 	ldr	x1, [x0, #8]
    3acc:	d1000421 	sub	x1, x1, #0x1
    3ad0:	f9000401 	str	x1, [x0, #8]
    3ad4:	f103f83f 	cmp	x1, #0xfe
    3ad8:	54fffb81 	b.ne	3a48 <fwp_drop0+0x98>  // b.any
    3adc:	aa1303e0 	mov	x0, x19
    3ae0:	97fffca9 	bl	2d84 <fwp_rc_forget_slot>
    3ae4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3ae8:	39000260 	strb	w0, [x19]
    3aec:	17ffffd7 	b	3a48 <fwp_drop0+0x98>
    3af0:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    3af4:	9127e000 	add	x0, x0, #0x9f8
    3af8:	97fff9e2 	bl	2280 <fwp_trap>
    3afc:	d503201f 	nop

0000000000003b00 <fwp_task_dispose>:
    3b00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3b04:	910003fd 	mov	x29, sp
    3b08:	f9000bf3 	str	x19, [sp, #16]
    3b0c:	aa0003f3 	mov	x19, x0
    3b10:	39414000 	ldrb	w0, [x0, #80]
    3b14:	36000720 	tbz	w0, #0, 3bf8 <fwp_task_dispose+0xf8>
    3b18:	f9400a60 	ldr	x0, [x19, #16]
    3b1c:	b50006e0 	cbnz	x0, 3bf8 <fwp_task_dispose+0xf8>
    3b20:	a9478660 	ldp	x0, x1, [x19, #120]
    3b24:	39014e7f 	strb	wzr, [x19, #83]
    3b28:	f9003e7f 	str	xzr, [x19, #120]
    3b2c:	f100003f 	cmp	x1, #0x0
    3b30:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3b34:	54000040 	b.eq	3b3c <fwp_task_dispose+0x3c>  // b.none
    3b38:	d63f0020 	blr	x1
    3b3c:	f9405660 	ldr	x0, [x19, #168]
    3b40:	97fffd30 	bl	3000 <fwp_mem_free>
    3b44:	f900567f 	str	xzr, [x19, #168]
    3b48:	b9405e60 	ldr	w0, [x19, #92]
    3b4c:	7100041f 	cmp	w0, #0x1
    3b50:	54000420 	b.eq	3bd4 <fwp_task_dispose+0xd4>  // b.none
    3b54:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    3b58:	9114c042 	add	x2, x2, #0x530
    3b5c:	f949d840 	ldr	x0, [x2, #5040]
    3b60:	f949ec41 	ldr	x1, [x2, #5080]
    3b64:	cb000260 	sub	x0, x19, x0
    3b68:	eb01401f 	cmp	x0, x1, lsl #16
    3b6c:	540002e2 	b.cs	3bc8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3b70:	d350fc01 	lsr	x1, x0, #16
    3b74:	f949fc44 	ldr	x4, [x2, #5112]
    3b78:	8b010821 	add	x1, x1, x1, lsl #2
    3b7c:	d37df021 	lsl	x1, x1, #3
    3b80:	8b010083 	add	x3, x4, x1
    3b84:	f9401062 	ldr	x2, [x3, #32]
    3b88:	b4000202 	cbz	x2, 3bc8 <fwp_task_dispose+0xc8>
    3b8c:	38616881 	ldrb	w1, [x4, x1]
    3b90:	7100083f 	cmp	w1, #0x2
    3b94:	54000280 	b.eq	3be4 <fwp_task_dispose+0xe4>  // b.none
    3b98:	7100043f 	cmp	w1, #0x1
    3b9c:	54000161 	b.ne	3bc8 <fwp_task_dispose+0xc8>  // b.any
    3ba0:	29430464 	ldp	w4, w1, [x3, #24]
    3ba4:	92403c00 	and	x0, x0, #0xffff
    3ba8:	9b047c00 	mul	x0, x0, x4
    3bac:	d360fc00 	lsr	x0, x0, #32
    3bb0:	eb01001f 	cmp	x0, x1
    3bb4:	540000a2 	b.cs	3bc8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3bb8:	8b000042 	add	x2, x2, x0
    3bbc:	39400040 	ldrb	w0, [x2]
    3bc0:	7100041f 	cmp	w0, #0x1
    3bc4:	54000080 	b.eq	3bd4 <fwp_task_dispose+0xd4>  // b.none
    3bc8:	f9400bf3 	ldr	x19, [sp, #16]
    3bcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3bd0:	d65f03c0 	ret
    3bd4:	aa1303e0 	mov	x0, x19
    3bd8:	f9400bf3 	ldr	x19, [sp, #16]
    3bdc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3be0:	17fffd08 	b	3000 <fwp_mem_free>
    3be4:	72003c1f 	tst	w0, #0xffff
    3be8:	54fffea0 	b.eq	3bbc <fwp_task_dispose+0xbc>  // b.none
    3bec:	f9400bf3 	ldr	x19, [sp, #16]
    3bf0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3bf4:	d65f03c0 	ret
    3bf8:	97fff656 	bl	1550 <abort@plt>
    3bfc:	d503201f 	nop

0000000000003c00 <fwp_free_zombie>:
    3c00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3c04:	910003fd 	mov	x29, sp
    3c08:	a90153f3 	stp	x19, x20, [sp, #16]
    3c0c:	b00000f4 	adrp	x20, 20000 <__data_start>
    3c10:	91014281 	add	x1, x20, #0x50
    3c14:	f9403433 	ldr	x19, [x1, #104]
    3c18:	b4000333 	cbz	x19, 3c7c <fwp_free_zombie+0x7c>
    3c1c:	f9400420 	ldr	x0, [x1, #8]
    3c20:	eb00027f 	cmp	x19, x0
    3c24:	540002c0 	b.eq	3c7c <fwp_free_zombie+0x7c>  // b.none
    3c28:	b9407022 	ldr	w2, [x1, #112]
    3c2c:	f9400a60 	ldr	x0, [x19, #16]
    3c30:	7100fc5f 	cmp	w2, #0x3f
    3c34:	5400078c 	b.gt	3d24 <fwp_free_zombie+0x124>
    3c38:	91020023 	add	x3, x1, #0x80
    3c3c:	11000444 	add	w4, w2, #0x1
    3c40:	b9007024 	str	w4, [x1, #112]
    3c44:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3c48:	f822d860 	str	x0, [x3, w2, sxtw #3]
    3c4c:	a9530261 	ldp	x1, x0, [x19, #304]
    3c50:	b4000741 	cbz	x1, 3d38 <fwp_free_zombie+0x138>
    3c54:	f9009c20 	str	x0, [x1, #312]
    3c58:	b4000040 	cbz	x0, 3c60 <fwp_free_zombie+0x60>
    3c5c:	f9009801 	str	x1, [x0, #304]
    3c60:	91014294 	add	x20, x20, #0x50
    3c64:	b9405e60 	ldr	w0, [x19, #92]
    3c68:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    3c6c:	f900369f 	str	xzr, [x20, #104]
    3c70:	34000140 	cbz	w0, 3c98 <fwp_free_zombie+0x98>
    3c74:	7100041f 	cmp	w0, #0x1
    3c78:	54000080 	b.eq	3c88 <fwp_free_zombie+0x88>  // b.none
    3c7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c84:	d65f03c0 	ret
    3c88:	aa1303e0 	mov	x0, x19
    3c8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c94:	17ffff9b 	b	3b00 <fwp_task_dispose>
    3c98:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xcb0>
    3c9c:	9114c082 	add	x2, x4, #0x530
    3ca0:	f949d841 	ldr	x1, [x2, #5040]
    3ca4:	f949ec40 	ldr	x0, [x2, #5080]
    3ca8:	cb010261 	sub	x1, x19, x1
    3cac:	eb00403f 	cmp	x1, x0, lsl #16
    3cb0:	54fffe62 	b.cs	3c7c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3cb4:	d350fc20 	lsr	x0, x1, #16
    3cb8:	f949fc43 	ldr	x3, [x2, #5112]
    3cbc:	8b000800 	add	x0, x0, x0, lsl #2
    3cc0:	d37df000 	lsl	x0, x0, #3
    3cc4:	8b000062 	add	x2, x3, x0
    3cc8:	f9401054 	ldr	x20, [x2, #32]
    3ccc:	b4fffd94 	cbz	x20, 3c7c <fwp_free_zombie+0x7c>
    3cd0:	38606860 	ldrb	w0, [x3, x0]
    3cd4:	7100081f 	cmp	w0, #0x2
    3cd8:	54000360 	b.eq	3d44 <fwp_free_zombie+0x144>  // b.none
    3cdc:	7100041f 	cmp	w0, #0x1
    3ce0:	54fffce1 	b.ne	3c7c <fwp_free_zombie+0x7c>  // b.any
    3ce4:	29430043 	ldp	w3, w0, [x2, #24]
    3ce8:	92403c21 	and	x1, x1, #0xffff
    3cec:	9b037c21 	mul	x1, x1, x3
    3cf0:	d360fc21 	lsr	x1, x1, #32
    3cf4:	eb00003f 	cmp	x1, x0
    3cf8:	54fffc22 	b.cs	3c7c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3cfc:	8b010294 	add	x20, x20, x1
    3d00:	39400280 	ldrb	w0, [x20]
    3d04:	34fffbc0 	cbz	w0, 3c7c <fwp_free_zombie+0x7c>
    3d08:	7100041f 	cmp	w0, #0x1
    3d0c:	54fffbe0 	b.eq	3c88 <fwp_free_zombie+0x88>  // b.none
    3d10:	7103fc1f 	cmp	w0, #0xff
    3d14:	540001e0 	b.eq	3d50 <fwp_free_zombie+0x150>  // b.none
    3d18:	51000400 	sub	w0, w0, #0x1
    3d1c:	39000280 	strb	w0, [x20]
    3d20:	17ffffd7 	b	3c7c <fwp_free_zombie+0x7c>
    3d24:	f9400e61 	ldr	x1, [x19, #24]
    3d28:	97fff63e 	bl	1620 <munmap@plt>
    3d2c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3d30:	a9530261 	ldp	x1, x0, [x19, #304]
    3d34:	b5fff901 	cbnz	x1, 3c54 <fwp_free_zombie+0x54>
    3d38:	91014282 	add	x2, x20, #0x50
    3d3c:	f9014040 	str	x0, [x2, #640]
    3d40:	17ffffc6 	b	3c58 <fwp_free_zombie+0x58>
    3d44:	72003c3f 	tst	w1, #0xffff
    3d48:	54fff9a1 	b.ne	3c7c <fwp_free_zombie+0x7c>  // b.any
    3d4c:	17ffffed 	b	3d00 <fwp_free_zombie+0x100>
    3d50:	ca544680 	eor	x0, x20, x20, lsr #17
    3d54:	9114c084 	add	x4, x4, #0x530
    3d58:	ca402400 	eor	x0, x0, x0, lsr #9
    3d5c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3d60:	f94a2400 	ldr	x0, [x0, #5192]
    3d64:	b5000080 	cbnz	x0, 3d74 <fwp_free_zombie+0x174>
    3d68:	14000010 	b	3da8 <fwp_free_zombie+0x1a8>
    3d6c:	f9400800 	ldr	x0, [x0, #16]
    3d70:	b40001c0 	cbz	x0, 3da8 <fwp_free_zombie+0x1a8>
    3d74:	f9400001 	ldr	x1, [x0]
    3d78:	eb14003f 	cmp	x1, x20
    3d7c:	54ffff81 	b.ne	3d6c <fwp_free_zombie+0x16c>  // b.any
    3d80:	f9400401 	ldr	x1, [x0, #8]
    3d84:	d1000421 	sub	x1, x1, #0x1
    3d88:	f9000401 	str	x1, [x0, #8]
    3d8c:	f103f83f 	cmp	x1, #0xfe
    3d90:	54fff761 	b.ne	3c7c <fwp_free_zombie+0x7c>  // b.any
    3d94:	aa1403e0 	mov	x0, x20
    3d98:	97fffbfb 	bl	2d84 <fwp_rc_forget_slot>
    3d9c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3da0:	39000280 	strb	w0, [x20]
    3da4:	17ffffb6 	b	3c7c <fwp_free_zombie+0x7c>
    3da8:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    3dac:	9127e000 	add	x0, x0, #0x9f8
    3db0:	97fff934 	bl	2280 <fwp_trap>

0000000000003db4 <fwp_block>:
    3db4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3db8:	910003fd 	mov	x29, sp
    3dbc:	a90153f3 	stp	x19, x20, [sp, #16]
    3dc0:	b00000f3 	adrp	x19, 20000 <__data_start>
    3dc4:	91014274 	add	x20, x19, #0x50
    3dc8:	f9401a82 	ldr	x2, [x20, #48]
    3dcc:	b4000622 	cbz	x2, 3e90 <fwp_block+0xdc>
    3dd0:	91014261 	add	x1, x19, #0x50
    3dd4:	f9408040 	ldr	x0, [x2, #256]
    3dd8:	f9001820 	str	x0, [x1, #48]
    3ddc:	b4000680 	cbz	x0, 3eac <fwp_block+0xf8>
    3de0:	91014263 	add	x3, x19, #0x50
    3de4:	3901505f 	strb	wzr, [x2, #84]
    3de8:	f9400464 	ldr	x4, [x3, #8]
    3dec:	eb02009f 	cmp	x4, x2
    3df0:	54000440 	b.eq	3e78 <fwp_block+0xc4>  // b.none
    3df4:	f9414465 	ldr	x5, [x3, #648]
    3df8:	f9000462 	str	x2, [x3, #8]
    3dfc:	f9400441 	ldr	x1, [x2, #8]
    3e00:	f9004885 	str	x5, [x4, #144]
    3e04:	f9414865 	ldr	x5, [x3, #656]
    3e08:	f9004c85 	str	x5, [x4, #152]
    3e0c:	f9414c65 	ldr	x5, [x3, #664]
    3e10:	f9005085 	str	x5, [x4, #160]
    3e14:	f9415065 	ldr	x5, [x3, #672]
    3e18:	f9005485 	str	x5, [x4, #168]
    3e1c:	f9415465 	ldr	x5, [x3, #680]
    3e20:	f9005885 	str	x5, [x4, #176]
    3e24:	f9415865 	ldr	x5, [x3, #688]
    3e28:	f9005c85 	str	x5, [x4, #184]
    3e2c:	f9415c65 	ldr	x5, [x3, #696]
    3e30:	f9006085 	str	x5, [x4, #192]
    3e34:	f9400480 	ldr	x0, [x4, #8]
    3e38:	f9404844 	ldr	x4, [x2, #144]
    3e3c:	f9014464 	str	x4, [x3, #648]
    3e40:	f9404c44 	ldr	x4, [x2, #152]
    3e44:	f9014864 	str	x4, [x3, #656]
    3e48:	f9405044 	ldr	x4, [x2, #160]
    3e4c:	f9014c64 	str	x4, [x3, #664]
    3e50:	f9405444 	ldr	x4, [x2, #168]
    3e54:	f9015064 	str	x4, [x3, #672]
    3e58:	f9405844 	ldr	x4, [x2, #176]
    3e5c:	f9015464 	str	x4, [x3, #680]
    3e60:	a94b8844 	ldp	x4, x2, [x2, #184]
    3e64:	f9015864 	str	x4, [x3, #688]
    3e68:	f9015c62 	str	x2, [x3, #696]
    3e6c:	97fff5bd 	bl	1560 <swapcontext@plt>
    3e70:	97ffff64 	bl	3c00 <fwp_free_zombie>
    3e74:	d503201f 	nop
    3e78:	91014260 	add	x0, x19, #0x50
    3e7c:	b942c000 	ldr	w0, [x0, #704]
    3e80:	340001a0 	cbz	w0, 3eb4 <fwp_block+0x100>
    3e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e88:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3e8c:	d65f03c0 	ret
    3e90:	97fffb30 	bl	2b50 <fwp_poll_events>
    3e94:	f9401a82 	ldr	x2, [x20, #48]
    3e98:	b4ffffc2 	cbz	x2, 3e90 <fwp_block+0xdc>
    3e9c:	91014261 	add	x1, x19, #0x50
    3ea0:	f9408040 	ldr	x0, [x2, #256]
    3ea4:	f9001820 	str	x0, [x1, #48]
    3ea8:	b5fff9c0 	cbnz	x0, 3de0 <fwp_block+0x2c>
    3eac:	f900143f 	str	xzr, [x1, #40]
    3eb0:	17ffffcc 	b	3de0 <fwp_block+0x2c>
    3eb4:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    3eb8:	9128c000 	add	x0, x0, #0xa30
    3ebc:	97fff5f5 	bl	1690 <getenv@plt>
    3ec0:	5284e202 	mov	w2, #0x2710                	// #10000
    3ec4:	b4000060 	cbz	x0, 3ed0 <fwp_block+0x11c>
    3ec8:	39400001 	ldrb	w1, [x0]
    3ecc:	350000c1 	cbnz	w1, 3ee4 <fwp_block+0x130>
    3ed0:	91014273 	add	x19, x19, #0x50
    3ed4:	b902c262 	str	w2, [x19, #704]
    3ed8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3edc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3ee0:	d65f03c0 	ret
    3ee4:	52800142 	mov	w2, #0xa                   	// #10
    3ee8:	d2800001 	mov	x1, #0x0                   	// #0
    3eec:	97fff539 	bl	13d0 <strtoll@plt>
    3ef0:	d1000403 	sub	x3, x0, #0x1
    3ef4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3ef8:	eb02007f 	cmp	x3, x2
    3efc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3f00:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3f04:	17fffff3 	b	3ed0 <fwp_block+0x11c>
    3f08:	d503201f 	nop
    3f0c:	d503201f 	nop

0000000000003f10 <fwp_write.constprop.0>:
    3f10:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3f14:	910003fd 	mov	x29, sp
    3f18:	900000e3 	adrp	x3, 1f000 <__FRAME_END__+0x175b8>
    3f1c:	f947f463 	ldr	x3, [x3, #4072]
    3f20:	a90153f3 	stp	x19, x20, [sp, #16]
    3f24:	d10943ff 	sub	sp, sp, #0x250
    3f28:	aa0003f4 	mov	x20, x0
    3f2c:	b9400040 	ldr	w0, [x2]
    3f30:	aa0103f3 	mov	x19, x1
    3f34:	f9400061 	ldr	x1, [x3]
    3f38:	f90127e1 	str	x1, [sp, #584]
    3f3c:	d2800001 	mov	x1, #0x0                   	// #0
    3f40:	7100641f 	cmp	w0, #0x19
    3f44:	540003e8 	b.hi	3fc0 <fwp_write.constprop.0+0xb0>  // b.pmore
    3f48:	f0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    3f4c:	9136c021 	add	x1, x1, #0xdb0
    3f50:	f9013bf5 	str	x21, [sp, #624]
    3f54:	f9013ff6 	str	x22, [sp, #632]
    3f58:	f90153fb 	str	x27, [sp, #672]
    3f5c:	f90157fc 	str	x28, [sp, #680]
    3f60:	aa0203fc 	mov	x28, x2
    3f64:	78605821 	ldrh	w1, [x1, w0, uxtw #1]
    3f68:	10000062 	adr	x2, 3f74 <fwp_write.constprop.0+0x64>
    3f6c:	8b21a841 	add	x1, x2, w1, sxth #2
    3f70:	d61f0020 	br	x1
    3f74:	910123e0 	add	x0, sp, #0x48
    3f78:	aa1303e5 	mov	x5, x19
    3f7c:	f0000004 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    3f80:	aa0003f3 	mov	x19, x0
    3f84:	9129e084 	add	x4, x4, #0xa78
    3f88:	d2804003 	mov	x3, #0x200                 	// #512
    3f8c:	aa0303e1 	mov	x1, x3
    3f90:	52800042 	mov	w2, #0x2                   	// #2
    3f94:	97fff537 	bl	1470 <__snprintf_chk@plt>
    3f98:	aa1303e0 	mov	x0, x19
    3f9c:	97fff4fd 	bl	1390 <strlen@plt>
    3fa0:	aa1303e1 	mov	x1, x19
    3fa4:	aa0003e2 	mov	x2, x0
    3fa8:	aa1403e0 	mov	x0, x20
    3fac:	97fff859 	bl	2110 <buf_put>
    3fb0:	f9413bf5 	ldr	x21, [sp, #624]
    3fb4:	f9413ff6 	ldr	x22, [sp, #632]
    3fb8:	f94153fb 	ldr	x27, [sp, #672]
    3fbc:	f94157fc 	ldr	x28, [sp, #680]
    3fc0:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    3fc4:	f947f400 	ldr	x0, [x0, #4072]
    3fc8:	f94127e2 	ldr	x2, [sp, #584]
    3fcc:	f9400001 	ldr	x1, [x0]
    3fd0:	eb010042 	subs	x2, x2, x1
    3fd4:	d2800001 	mov	x1, #0x0                   	// #0
    3fd8:	540074a1 	b.ne	4e6c <fwp_write.constprop.0+0xf5c>  // b.any
    3fdc:	910943ff 	add	sp, sp, #0x250
    3fe0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fe4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3fe8:	d65f03c0 	ret
    3fec:	910123e0 	add	x0, sp, #0x48
    3ff0:	aa1303e5 	mov	x5, x19
    3ff4:	f0000004 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    3ff8:	aa0003f3 	mov	x19, x0
    3ffc:	9129c084 	add	x4, x4, #0xa70
    4000:	d2804003 	mov	x3, #0x200                 	// #512
    4004:	17ffffe2 	b	3f8c <fwp_write.constprop.0+0x7c>
    4008:	71004c1f 	cmp	w0, #0x13
    400c:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4010:	d0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    4014:	9129a021 	add	x1, x1, #0xa68
    4018:	91298000 	add	x0, x0, #0xa60
    401c:	d2800082 	mov	x2, #0x4                   	// #4
    4020:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    4024:	aa1403e0 	mov	x0, x20
    4028:	f90143f7 	str	x23, [sp, #640]
    402c:	d2800016 	mov	x22, #0x0                   	// #0
    4030:	f90147f8 	str	x24, [sp, #648]
    4034:	97fff837 	bl	2110 <buf_put>
    4038:	f9400260 	ldr	x0, [x19]
    403c:	d0000017 	adrp	x23, 6000 <fwp_main_thread+0x114c>
    4040:	d2800015 	mov	x21, #0x0                   	// #0
    4044:	912ba2f7 	add	x23, x23, #0xae8
    4048:	b4004e40 	cbz	x0, 4a10 <fwp_write.constprop.0+0xb00>
    404c:	b9400381 	ldr	w1, [x28]
    4050:	aa1403e0 	mov	x0, x20
    4054:	f9401f82 	ldr	x2, [x28, #56]
    4058:	71004c3f 	cmp	w1, #0x13
    405c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    4060:	8b010e61 	add	x1, x19, x1, lsl #3
    4064:	f9400421 	ldr	x1, [x1, #8]
    4068:	97ffffaa 	bl	3f10 <fwp_write.constprop.0>
    406c:	b9400380 	ldr	w0, [x28]
    4070:	7100481f 	cmp	w0, #0x12
    4074:	540050c0 	b.eq	4a8c <fwp_write.constprop.0+0xb7c>  // b.none
    4078:	f9400260 	ldr	x0, [x19]
    407c:	910006b5 	add	x21, x21, #0x1
    4080:	91000ad6 	add	x22, x22, #0x2
    4084:	eb0002bf 	cmp	x21, x0
    4088:	54004c42 	b.cs	4a10 <fwp_write.constprop.0+0xb00>  // b.hs, b.nlast
    408c:	aa1703e1 	mov	x1, x23
    4090:	aa1403e0 	mov	x0, x20
    4094:	d2800042 	mov	x2, #0x2                   	// #2
    4098:	97fff81e 	bl	2110 <buf_put>
    409c:	17ffffec 	b	404c <fwp_write.constprop.0+0x13c>
    40a0:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    40a4:	912a8021 	add	x1, x1, #0xaa0
    40a8:	d28000c2 	mov	x2, #0x6                   	// #6
    40ac:	aa1403e0 	mov	x0, x20
    40b0:	91004273 	add	x19, x19, #0x10
    40b4:	97fff817 	bl	2110 <buf_put>
    40b8:	aa1303e0 	mov	x0, x19
    40bc:	97fff4b5 	bl	1390 <strlen@plt>
    40c0:	aa1303e1 	mov	x1, x19
    40c4:	aa0003e2 	mov	x2, x0
    40c8:	aa1403e0 	mov	x0, x20
    40cc:	97fff811 	bl	2110 <buf_put>
    40d0:	528007c3 	mov	w3, #0x3e                  	// #62
    40d4:	aa1403e0 	mov	x0, x20
    40d8:	91001fe1 	add	x1, sp, #0x7
    40dc:	d2800022 	mov	x2, #0x1                   	// #1
    40e0:	39001fe3 	strb	w3, [sp, #7]
    40e4:	17ffffb2 	b	3fac <fwp_write.constprop.0+0x9c>
    40e8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    40ec:	f947f400 	ldr	x0, [x0, #4072]
    40f0:	f94127e2 	ldr	x2, [sp, #584]
    40f4:	f9400001 	ldr	x1, [x0]
    40f8:	eb010042 	subs	x2, x2, x1
    40fc:	d2800001 	mov	x1, #0x0                   	// #0
    4100:	54006cc1 	b.ne	4e98 <fwp_write.constprop.0+0xf88>  // b.any
    4104:	f9413bf5 	ldr	x21, [sp, #624]
    4108:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    410c:	f9413ff6 	ldr	x22, [sp, #632]
    4110:	aa1403e0 	mov	x0, x20
    4114:	912a0021 	add	x1, x1, #0xa80
    4118:	d2800142 	mov	x2, #0xa                   	// #10
    411c:	f94153fb 	ldr	x27, [sp, #672]
    4120:	f94157fc 	ldr	x28, [sp, #680]
    4124:	910943ff 	add	sp, sp, #0x250
    4128:	a94153f3 	ldp	x19, x20, [sp, #16]
    412c:	a8c77bfd 	ldp	x29, x30, [sp], #112
    4130:	17fff7f8 	b	2110 <buf_put>
    4134:	f9400796 	ldr	x22, [x28, #8]
    4138:	f90143f7 	str	x23, [sp, #640]
    413c:	f90147f8 	str	x24, [sp, #648]
    4140:	b4005816 	cbz	x22, 4c40 <fwp_write.constprop.0+0xd30>
    4144:	aa1603e0 	mov	x0, x22
    4148:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    414c:	912c0021 	add	x1, x1, #0xb00
    4150:	97fff50c 	bl	1580 <strcmp@plt>
    4154:	2a0003f5 	mov	w21, w0
    4158:	34005ce0 	cbz	w0, 4cf4 <fwp_write.constprop.0+0xde4>
    415c:	aa1603e0 	mov	x0, x22
    4160:	97fff48c 	bl	1390 <strlen@plt>
    4164:	aa1603e1 	mov	x1, x22
    4168:	aa0003e2 	mov	x2, x0
    416c:	aa1403e0 	mov	x0, x20
    4170:	97fff7e8 	bl	2110 <buf_put>
    4174:	52800403 	mov	w3, #0x20                  	// #32
    4178:	91001ff5 	add	x21, sp, #0x7
    417c:	aa1503e1 	mov	x1, x21
    4180:	aa1403e0 	mov	x0, x20
    4184:	d2800022 	mov	x2, #0x1                   	// #1
    4188:	39001fe3 	strb	w3, [sp, #7]
    418c:	97fff7e1 	bl	2110 <buf_put>
    4190:	52800f63 	mov	w3, #0x7b                  	// #123
    4194:	aa1403e0 	mov	x0, x20
    4198:	aa1503e1 	mov	x1, x21
    419c:	d2800022 	mov	x2, #0x1                   	// #1
    41a0:	39001fe3 	strb	w3, [sp, #7]
    41a4:	97fff7db 	bl	2110 <buf_put>
    41a8:	b9401380 	ldr	w0, [x28, #16]
    41ac:	52800018 	mov	w24, #0x0                   	// #0
    41b0:	7100001f 	cmp	w0, #0x0
    41b4:	54003d8d 	b.le	4964 <fwp_write.constprop.0+0xa54>
    41b8:	f9014bf9 	str	x25, [sp, #656]
    41bc:	d0000019 	adrp	x25, 6000 <fwp_main_thread+0x114c>
    41c0:	912ca339 	add	x25, x25, #0xb28
    41c4:	f9014ffa 	str	x26, [sp, #664]
    41c8:	d000001a 	adrp	x26, 6000 <fwp_main_thread+0x114c>
    41cc:	912ba35a 	add	x26, x26, #0xae8
    41d0:	91002276 	add	x22, x19, #0x8
    41d4:	d2800013 	mov	x19, #0x0                   	// #0
    41d8:	b5004413 	cbnz	x19, 4a58 <fwp_write.constprop.0+0xb48>
    41dc:	d37df277 	lsl	x23, x19, #3
    41e0:	34004238 	cbz	w24, 4a24 <fwp_write.constprop.0+0xb14>
    41e4:	f9401382 	ldr	x2, [x28, #32]
    41e8:	aa1403e0 	mov	x0, x20
    41ec:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    41f0:	91000673 	add	x19, x19, #0x1
    41f4:	f8776842 	ldr	x2, [x2, x23]
    41f8:	97ffff46 	bl	3f10 <fwp_write.constprop.0>
    41fc:	b9401380 	ldr	w0, [x28, #16]
    4200:	6b13001f 	cmp	w0, w19
    4204:	54fffeac 	b.gt	41d8 <fwp_write.constprop.0+0x2c8>
    4208:	f9414bf9 	ldr	x25, [sp, #656]
    420c:	f9414ffa 	ldr	x26, [sp, #664]
    4210:	34003ab8 	cbz	w24, 4964 <fwp_write.constprop.0+0xa54>
    4214:	52800523 	mov	w3, #0x29                  	// #41
    4218:	aa1503e1 	mov	x1, x21
    421c:	aa1403e0 	mov	x0, x20
    4220:	d2800022 	mov	x2, #0x1                   	// #1
    4224:	39001fe3 	strb	w3, [sp, #7]
    4228:	97fff7ba 	bl	2110 <buf_put>
    422c:	f9413bf5 	ldr	x21, [sp, #624]
    4230:	f9413ff6 	ldr	x22, [sp, #632]
    4234:	f94143f7 	ldr	x23, [sp, #640]
    4238:	f94147f8 	ldr	x24, [sp, #648]
    423c:	f94153fb 	ldr	x27, [sp, #672]
    4240:	f94157fc 	ldr	x28, [sp, #680]
    4244:	17ffff5f 	b	3fc0 <fwp_write.constprop.0+0xb0>
    4248:	b9404b95 	ldr	w21, [x28, #72]
    424c:	aa1403e0 	mov	x0, x20
    4250:	93407eb6 	sxtw	x22, w21
    4254:	91000ac1 	add	x1, x22, #0x2
    4258:	97fff77a 	bl	2040 <buf_grow>
    425c:	a9400281 	ldp	x1, x0, [x20]
    4260:	528e8603 	mov	w3, #0x7430                	// #29744
    4264:	78206823 	strh	w3, [x1, x0]
    4268:	8b000022 	add	x2, x1, x0
    426c:	710002bf 	cmp	w21, #0x0
    4270:	54003bcd 	b.le	49e8 <fwp_write.constprop.0+0xad8>
    4274:	110006a3 	add	w3, w21, #0x1
    4278:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    427c:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    4280:	91000449 	add	x9, x2, #0x1
    4284:	8b23c043 	add	x3, x2, w3, sxtw
    4288:	f28aaac6 	movk	x6, #0x5556
    428c:	f2955568 	movk	x8, #0xaaab
    4290:	1400000d 	b	42c4 <fwp_write.constprop.0+0x3b4>
    4294:	d2800021 	mov	x1, #0x1                   	// #1
    4298:	528005a5 	mov	w5, #0x2d                  	// #45
    429c:	f100001f 	cmp	x0, #0x0
    42a0:	9b467e60 	smulh	x0, x19, x6
    42a4:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    42a8:	381ff465 	strb	w5, [x3], #-1
    42ac:	cb040000 	sub	x0, x0, x4
    42b0:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    42b4:	cb020000 	sub	x0, x0, x2
    42b8:	8b010013 	add	x19, x0, x1
    42bc:	eb03013f 	cmp	x9, x3
    42c0:	54003940 	b.eq	49e8 <fwp_write.constprop.0+0xad8>  // b.none
    42c4:	9b467e60 	smulh	x0, x19, x6
    42c8:	937ffe64 	asr	x4, x19, #63
    42cc:	52800605 	mov	w5, #0x30                  	// #48
    42d0:	cb040000 	sub	x0, x0, x4
    42d4:	8b000400 	add	x0, x0, x0, lsl #1
    42d8:	cb000260 	sub	x0, x19, x0
    42dc:	91000c01 	add	x1, x0, #0x3
    42e0:	9bc87c22 	umulh	x2, x1, x8
    42e4:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    42e8:	8b4204e2 	add	x2, x7, x2, lsr #1
    42ec:	eb020021 	subs	x1, x1, x2
    42f0:	54fffd60 	b.eq	429c <fwp_write.constprop.0+0x38c>  // b.none
    42f4:	f100043f 	cmp	x1, #0x1
    42f8:	54fffce1 	b.ne	4294 <fwp_write.constprop.0+0x384>  // b.any
    42fc:	d2800001 	mov	x1, #0x0                   	// #0
    4300:	52800565 	mov	w5, #0x2b                  	// #43
    4304:	17ffffe6 	b	429c <fwp_write.constprop.0+0x38c>
    4308:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    430c:	f947f400 	ldr	x0, [x0, #4072]
    4310:	f94127e2 	ldr	x2, [sp, #584]
    4314:	f9400001 	ldr	x1, [x0]
    4318:	eb010042 	subs	x2, x2, x1
    431c:	d2800001 	mov	x1, #0x0                   	// #0
    4320:	54005bc1 	b.ne	4e98 <fwp_write.constprop.0+0xf88>  // b.any
    4324:	f9413bf5 	ldr	x21, [sp, #624]
    4328:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    432c:	f9413ff6 	ldr	x22, [sp, #632]
    4330:	aa1403e0 	mov	x0, x20
    4334:	912a4021 	add	x1, x1, #0xa90
    4338:	d2800102 	mov	x2, #0x8                   	// #8
    433c:	17ffff78 	b	411c <fwp_write.constprop.0+0x20c>
    4340:	aa1403e0 	mov	x0, x20
    4344:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4348:	d28000c2 	mov	x2, #0x6                   	// #6
    434c:	912bc021 	add	x1, x1, #0xaf0
    4350:	97fff770 	bl	2110 <buf_put>
    4354:	d2800015 	mov	x21, #0x0                   	// #0
    4358:	f9400263 	ldr	x3, [x19]
    435c:	f240f87f 	tst	x3, #0x7fffffffffffffff
    4360:	540026a0 	b.eq	4834 <fwp_write.constprop.0+0x924>  // b.none
    4364:	f9401f82 	ldr	x2, [x28, #56]
    4368:	f90143f7 	str	x23, [sp, #640]
    436c:	f90147f8 	str	x24, [sp, #648]
    4370:	d2800857 	mov	x23, #0x42                  	// #66
    4374:	f9014bf9 	str	x25, [sp, #656]
    4378:	d0000016 	adrp	x22, 6000 <fwp_main_thread+0x114c>
    437c:	f9014ffa 	str	x26, [sp, #664]
    4380:	912ba2d6 	add	x22, x22, #0xae8
    4384:	d2800038 	mov	x24, #0x1                   	// #1
    4388:	f2a18017 	movk	x23, #0xc00, lsl #16
    438c:	d2809099 	mov	x25, #0x484                 	// #1156
    4390:	b4000482 	cbz	x2, 4420 <fwp_write.constprop.0+0x510>
    4394:	b9400040 	ldr	w0, [x2]
    4398:	7100701f 	cmp	w0, #0x1c
    439c:	540042e0 	b.eq	4bf8 <fwp_write.constprop.0+0xce8>  // b.none
    43a0:	71006c1f 	cmp	w0, #0x1b
    43a4:	540003e8 	b.hi	4420 <fwp_write.constprop.0+0x510>  // b.pmore
    43a8:	9ac02301 	lsl	x1, x24, x0
    43ac:	ea17003f 	tst	x1, x23
    43b0:	54003f21 	b.ne	4b94 <fwp_write.constprop.0+0xc84>  // b.any
    43b4:	ea19003f 	tst	x1, x25
    43b8:	54003da1 	b.ne	4b6c <fwp_write.constprop.0+0xc5c>  // b.any
    43bc:	d2800425 	mov	x5, #0x21                  	// #33
    43c0:	ea05003f 	tst	x1, x5
    43c4:	540002e0 	b.eq	4420 <fwp_write.constprop.0+0x510>  // b.none
    43c8:	b7f84743 	tbnz	x3, #63, 4cb0 <fwp_write.constprop.0+0xda0>
    43cc:	91002261 	add	x1, x19, #0x8
    43d0:	8b150021 	add	x1, x1, x21
    43d4:	39400021 	ldrb	w1, [x1]
    43d8:	7100001f 	cmp	w0, #0x0
    43dc:	93401c23 	sxtb	x3, w1
    43e0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    43e4:	d503201f 	nop
    43e8:	aa1403e0 	mov	x0, x20
    43ec:	97fffec9 	bl	3f10 <fwp_write.constprop.0>
    43f0:	f9400260 	ldr	x0, [x19]
    43f4:	910006b5 	add	x21, x21, #0x1
    43f8:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    43fc:	eb0002bf 	cmp	x21, x0
    4400:	54002122 	b.cs	4824 <fwp_write.constprop.0+0x914>  // b.hs, b.nlast
    4404:	d2800042 	mov	x2, #0x2                   	// #2
    4408:	aa1603e1 	mov	x1, x22
    440c:	aa1403e0 	mov	x0, x20
    4410:	97fff740 	bl	2110 <buf_put>
    4414:	f9401f82 	ldr	x2, [x28, #56]
    4418:	f9400263 	ldr	x3, [x19]
    441c:	b5fffbc2 	cbnz	x2, 4394 <fwp_write.constprop.0+0x484>
    4420:	d37df2a0 	lsl	x0, x21, #3
    4424:	b7f83f43 	tbnz	x3, #63, 4c0c <fwp_write.constprop.0+0xcfc>
    4428:	91002261 	add	x1, x19, #0x8
    442c:	8b000020 	add	x0, x1, x0
    4430:	f9400001 	ldr	x1, [x0]
    4434:	17ffffed 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4438:	a9400e62 	ldp	x2, x3, [x19]
    443c:	b7f83ce3 	tbnz	x3, #63, 4bd8 <fwp_write.constprop.0+0xcc8>
    4440:	910123f5 	add	x21, sp, #0x48
    4444:	aa1503e0 	mov	x0, x21
    4448:	97fff586 	bl	1a60 <fwp_fmt_u128>
    444c:	aa1503e0 	mov	x0, x21
    4450:	97fff3d0 	bl	1390 <strlen@plt>
    4454:	aa1503e1 	mov	x1, x21
    4458:	aa0003e2 	mov	x2, x0
    445c:	17fffed3 	b	3fa8 <fwp_write.constprop.0+0x98>
    4460:	fd015be8 	str	d8, [sp, #688]
    4464:	1e270268 	fmov	s8, w19
    4468:	fd015fe9 	str	d9, [sp, #696]
    446c:	1e282100 	fcmp	s8, s8
    4470:	54004a66 	b.vs	4dbc <fwp_write.constprop.0+0xeac>
    4474:	1e20c101 	fabs	s1, s8
    4478:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    447c:	1e270000 	fmov	s0, w0
    4480:	1e202020 	fcmp	s1, s0
    4484:	540034ad 	b.le	4b18 <fwp_write.constprop.0+0xc08>
    4488:	1e202118 	fcmpe	s8, #0.0
    448c:	d0000002 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    4490:	91214042 	add	x2, x2, #0x850
    4494:	910123f5 	add	x21, sp, #0x48
    4498:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    449c:	91290021 	add	x1, x1, #0xa40
    44a0:	aa1503e0 	mov	x0, x21
    44a4:	9a81c041 	csel	x1, x2, x1, gt
    44a8:	97fff466 	bl	1640 <strcpy@plt>
    44ac:	d503201f 	nop
    44b0:	aa1503e0 	mov	x0, x21
    44b4:	97fff3b7 	bl	1390 <strlen@plt>
    44b8:	aa1503e1 	mov	x1, x21
    44bc:	aa0003e2 	mov	x2, x0
    44c0:	aa1403e0 	mov	x0, x20
    44c4:	97fff713 	bl	2110 <buf_put>
    44c8:	f9413bf5 	ldr	x21, [sp, #624]
    44cc:	f9413ff6 	ldr	x22, [sp, #632]
    44d0:	f94153fb 	ldr	x27, [sp, #672]
    44d4:	f94157fc 	ldr	x28, [sp, #680]
    44d8:	fd415be8 	ldr	d8, [sp, #688]
    44dc:	fd415fe9 	ldr	d9, [sp, #696]
    44e0:	17fffeb8 	b	3fc0 <fwp_write.constprop.0+0xb0>
    44e4:	f90143f7 	str	x23, [sp, #640]
    44e8:	52800443 	mov	w3, #0x22                  	// #34
    44ec:	f90147f8 	str	x24, [sp, #648]
    44f0:	91001ff5 	add	x21, sp, #0x7
    44f4:	aa1503e1 	mov	x1, x21
    44f8:	aa1403e0 	mov	x0, x20
    44fc:	f8408677 	ldr	x23, [x19], #8
    4500:	d2800022 	mov	x2, #0x1                   	// #1
    4504:	39001fe3 	strb	w3, [sp, #7]
    4508:	97fff702 	bl	2110 <buf_put>
    450c:	8b1302f6 	add	x22, x23, x19
    4510:	b4002657 	cbz	x23, 49d8 <fwp_write.constprop.0+0xac8>
    4514:	d0000018 	adrp	x24, 6000 <fwp_main_thread+0x114c>
    4518:	912aa318 	add	x24, x24, #0xaa8
    451c:	f9014bf9 	str	x25, [sp, #656]
    4520:	d0000019 	adrp	x25, 6000 <fwp_main_thread+0x114c>
    4524:	912b2339 	add	x25, x25, #0xac8
    4528:	f9014ffa 	str	x26, [sp, #664]
    452c:	1400000e 	b	4564 <fwp_write.constprop.0+0x654>
    4530:	710024bf 	cmp	w5, #0x9
    4534:	54002380 	b.eq	49a4 <fwp_write.constprop.0+0xa94>  // b.none
    4538:	710028bf 	cmp	w5, #0xa
    453c:	54002be1 	b.ne	4ab8 <fwp_write.constprop.0+0xba8>  // b.any
    4540:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4544:	aa1403e0 	mov	x0, x20
    4548:	912ae021 	add	x1, x1, #0xab8
    454c:	d2800042 	mov	x2, #0x2                   	// #2
    4550:	97fff6f0 	bl	2110 <buf_put>
    4554:	d503201f 	nop
    4558:	91000673 	add	x19, x19, #0x1
    455c:	eb16027f 	cmp	x19, x22
    4560:	54002380 	b.eq	49d0 <fwp_write.constprop.0+0xac0>  // b.none
    4564:	39400265 	ldrb	w5, [x19]
    4568:	710034bf 	cmp	w5, #0xd
    456c:	54002120 	b.eq	4990 <fwp_write.constprop.0+0xa80>  // b.none
    4570:	54fffe09 	b.ls	4530 <fwp_write.constprop.0+0x620>  // b.plast
    4574:	710088bf 	cmp	w5, #0x22
    4578:	54002220 	b.eq	49bc <fwp_write.constprop.0+0xaac>  // b.none
    457c:	710170bf 	cmp	w5, #0x5c
    4580:	54002ba1 	b.ne	4af4 <fwp_write.constprop.0+0xbe4>  // b.any
    4584:	aa1403e0 	mov	x0, x20
    4588:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    458c:	d2800042 	mov	x2, #0x2                   	// #2
    4590:	912ac021 	add	x1, x1, #0xab0
    4594:	97fff6df 	bl	2110 <buf_put>
    4598:	17fffff0 	b	4558 <fwp_write.constprop.0+0x648>
    459c:	fd015be8 	str	d8, [sp, #688]
    45a0:	9e670268 	fmov	d8, x19
    45a4:	fd015fe9 	str	d9, [sp, #696]
    45a8:	1e682100 	fcmp	d8, d8
    45ac:	54004086 	b.vs	4dbc <fwp_write.constprop.0+0xeac>
    45b0:	1e60c101 	fabs	d1, d8
    45b4:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    45b8:	9e670000 	fmov	d0, x0
    45bc:	910123f5 	add	x21, sp, #0x48
    45c0:	52800033 	mov	w19, #0x1                   	// #1
    45c4:	1e602020 	fcmp	d1, d0
    45c8:	540001ad 	b.le	45fc <fwp_write.constprop.0+0x6ec>
    45cc:	1e602118 	fcmpe	d8, #0.0
    45d0:	d0000002 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    45d4:	91214042 	add	x2, x2, #0x850
    45d8:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    45dc:	91290021 	add	x1, x1, #0xa40
    45e0:	aa1503e0 	mov	x0, x21
    45e4:	9a81c041 	csel	x1, x2, x1, gt
    45e8:	97fff416 	bl	1640 <strcpy@plt>
    45ec:	17ffffb1 	b	44b0 <fwp_write.constprop.0+0x5a0>
    45f0:	11000673 	add	w19, w19, #0x1
    45f4:	71004a7f 	cmp	w19, #0x12
    45f8:	540031a0 	b.eq	4c2c <fwp_write.constprop.0+0xd1c>  // b.none
    45fc:	1e604100 	fmov	d0, d8
    4600:	2a1303e1 	mov	w1, w19
    4604:	aa1503e0 	mov	x0, x21
    4608:	97fff756 	bl	2360 <fwp_format_g.constprop.0>
    460c:	aa1503e0 	mov	x0, x21
    4610:	d2800001 	mov	x1, #0x0                   	// #0
    4614:	97fff373 	bl	13e0 <strtod@plt>
    4618:	1e602100 	fcmp	d8, d0
    461c:	54fffea1 	b.ne	45f0 <fwp_write.constprop.0+0x6e0>  // b.any
    4620:	aa1503e0 	mov	x0, x21
    4624:	97fff6f4 	bl	21f4 <fwp_finish_float>
    4628:	17ffffa2 	b	44b0 <fwp_write.constprop.0+0x5a0>
    462c:	a9400e62 	ldp	x2, x3, [x19]
    4630:	910123f3 	add	x19, sp, #0x48
    4634:	aa1303e0 	mov	x0, x19
    4638:	97fff50a 	bl	1a60 <fwp_fmt_u128>
    463c:	17fffe57 	b	3f98 <fwp_write.constprop.0+0x88>
    4640:	f90143f7 	str	x23, [sp, #640]
    4644:	f90147f8 	str	x24, [sp, #648]
    4648:	2a1303f8 	mov	w24, w19
    464c:	f9014bf9 	str	x25, [sp, #656]
    4650:	f9014ffa 	str	x26, [sp, #664]
    4654:	f13ffe7f 	cmp	x19, #0xfff
    4658:	54000049 	b.ls	4660 <fwp_write.constprop.0+0x750>  // b.plast
    465c:	b9400278 	ldr	w24, [x19]
    4660:	f9400f80 	ldr	x0, [x28, #24]
    4664:	2a1803f5 	mov	w21, w24
    4668:	d37d7f18 	ubfiz	x24, x24, #3, #32
    466c:	d37ef6b9 	lsl	x25, x21, #2
    4670:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    4674:	aa1603e0 	mov	x0, x22
    4678:	97fff346 	bl	1390 <strlen@plt>
    467c:	aa1603e1 	mov	x1, x22
    4680:	aa0003e2 	mov	x2, x0
    4684:	aa1403e0 	mov	x0, x20
    4688:	97fff6a2 	bl	2110 <buf_put>
    468c:	f9401780 	ldr	x0, [x28, #40]
    4690:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    4694:	7100001f 	cmp	w0, #0x0
    4698:	5400064d 	b.le	4760 <fwp_write.constprop.0+0x850>
    469c:	91002276 	add	x22, x19, #0x8
    46a0:	91001ff5 	add	x21, sp, #0x7
    46a4:	d280001b 	mov	x27, #0x0                   	// #0
    46a8:	5280041a 	mov	w26, #0x20                  	// #32
    46ac:	f9401b80 	ldr	x0, [x28, #48]
    46b0:	aa1503e1 	mov	x1, x21
    46b4:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    46b8:	d2800022 	mov	x2, #0x1                   	// #1
    46bc:	f8786805 	ldr	x5, [x0, x24]
    46c0:	aa1403e0 	mov	x0, x20
    46c4:	f87b78b3 	ldr	x19, [x5, x27, lsl #3]
    46c8:	39001ffa 	strb	w26, [sp, #7]
    46cc:	97fff691 	bl	2110 <buf_put>
    46d0:	f13ffeff 	cmp	x23, #0xfff
    46d4:	b9400261 	ldr	w1, [x19]
    46d8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    46dc:	7100383f 	cmp	w1, #0xe
    46e0:	54000140 	b.eq	4708 <fwp_write.constprop.0+0x7f8>  // b.none
    46e4:	7100403f 	cmp	w1, #0x10
    46e8:	54001c20 	b.eq	4a6c <fwp_write.constprop.0+0xb5c>  // b.none
    46ec:	7100283f 	cmp	w1, #0xa
    46f0:	540026e0 	b.eq	4bcc <fwp_write.constprop.0+0xcbc>  // b.none
    46f4:	540013cc 	b.gt	496c <fwp_write.constprop.0+0xa5c>
    46f8:	71000c3f 	cmp	w1, #0x3
    46fc:	540025ec 	b.gt	4bb8 <fwp_write.constprop.0+0xca8>
    4700:	d37ffee0 	lsr	x0, x23, #63
    4704:	37f813c1 	tbnz	w1, #31, 497c <fwp_write.constprop.0+0xa6c>
    4708:	340013a0 	cbz	w0, 497c <fwp_write.constprop.0+0xa6c>
    470c:	52800503 	mov	w3, #0x28                  	// #40
    4710:	aa1503e1 	mov	x1, x21
    4714:	aa1403e0 	mov	x0, x20
    4718:	d2800022 	mov	x2, #0x1                   	// #1
    471c:	39001fe3 	strb	w3, [sp, #7]
    4720:	97fff67c 	bl	2110 <buf_put>
    4724:	aa1303e2 	mov	x2, x19
    4728:	aa1703e1 	mov	x1, x23
    472c:	aa1403e0 	mov	x0, x20
    4730:	97fffdf8 	bl	3f10 <fwp_write.constprop.0>
    4734:	52800523 	mov	w3, #0x29                  	// #41
    4738:	aa1503e1 	mov	x1, x21
    473c:	aa1403e0 	mov	x0, x20
    4740:	d2800022 	mov	x2, #0x1                   	// #1
    4744:	39001fe3 	strb	w3, [sp, #7]
    4748:	97fff672 	bl	2110 <buf_put>
    474c:	f9401780 	ldr	x0, [x28, #40]
    4750:	9100077b 	add	x27, x27, #0x1
    4754:	b8796800 	ldr	w0, [x0, x25]
    4758:	6b1b001f 	cmp	w0, w27
    475c:	54fffa8c 	b.gt	46ac <fwp_write.constprop.0+0x79c>
    4760:	f9413bf5 	ldr	x21, [sp, #624]
    4764:	f9413ff6 	ldr	x22, [sp, #632]
    4768:	f94143f7 	ldr	x23, [sp, #640]
    476c:	f94147f8 	ldr	x24, [sp, #648]
    4770:	f9414bf9 	ldr	x25, [sp, #656]
    4774:	f9414ffa 	ldr	x26, [sp, #664]
    4778:	f94153fb 	ldr	x27, [sp, #672]
    477c:	f94157fc 	ldr	x28, [sp, #680]
    4780:	17fffe10 	b	3fc0 <fwp_write.constprop.0+0xb0>
    4784:	aa1403e0 	mov	x0, x20
    4788:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    478c:	d28000c2 	mov	x2, #0x6                   	// #6
    4790:	912b6021 	add	x1, x1, #0xad8
    4794:	97fff65f 	bl	2110 <buf_put>
    4798:	f9400260 	ldr	x0, [x19]
    479c:	b40004c0 	cbz	x0, 4834 <fwp_write.constprop.0+0x924>
    47a0:	910123f5 	add	x21, sp, #0x48
    47a4:	91002276 	add	x22, x19, #0x8
    47a8:	f90143f7 	str	x23, [sp, #640]
    47ac:	d2800017 	mov	x23, #0x0                   	// #0
    47b0:	f90147f8 	str	x24, [sp, #648]
    47b4:	d0000018 	adrp	x24, 6000 <fwp_main_thread+0x114c>
    47b8:	912b8318 	add	x24, x24, #0xae0
    47bc:	f9014bf9 	str	x25, [sp, #656]
    47c0:	d0000019 	adrp	x25, 6000 <fwp_main_thread+0x114c>
    47c4:	912ba339 	add	x25, x25, #0xae8
    47c8:	f9014ffa 	str	x26, [sp, #664]
    47cc:	14000005 	b	47e0 <fwp_write.constprop.0+0x8d0>
    47d0:	aa1903e1 	mov	x1, x25
    47d4:	aa1403e0 	mov	x0, x20
    47d8:	d2800042 	mov	x2, #0x2                   	// #2
    47dc:	97fff64d 	bl	2110 <buf_put>
    47e0:	38776ac5 	ldrb	w5, [x22, x23]
    47e4:	d2804003 	mov	x3, #0x200                 	// #512
    47e8:	aa1803e4 	mov	x4, x24
    47ec:	aa0303e1 	mov	x1, x3
    47f0:	52800042 	mov	w2, #0x2                   	// #2
    47f4:	aa1503e0 	mov	x0, x21
    47f8:	910006f7 	add	x23, x23, #0x1
    47fc:	97fff31d 	bl	1470 <__snprintf_chk@plt>
    4800:	aa1503e0 	mov	x0, x21
    4804:	97fff2e3 	bl	1390 <strlen@plt>
    4808:	aa1503e1 	mov	x1, x21
    480c:	aa0003e2 	mov	x2, x0
    4810:	aa1403e0 	mov	x0, x20
    4814:	97fff63f 	bl	2110 <buf_put>
    4818:	f9400260 	ldr	x0, [x19]
    481c:	eb0002ff 	cmp	x23, x0
    4820:	54fffd83 	b.cc	47d0 <fwp_write.constprop.0+0x8c0>  // b.lo, b.ul, b.last
    4824:	f94143f7 	ldr	x23, [sp, #640]
    4828:	f94147f8 	ldr	x24, [sp, #648]
    482c:	f9414bf9 	ldr	x25, [sp, #656]
    4830:	f9414ffa 	ldr	x26, [sp, #664]
    4834:	52800ba3 	mov	w3, #0x5d                  	// #93
    4838:	aa1403e0 	mov	x0, x20
    483c:	91001fe1 	add	x1, sp, #0x7
    4840:	d2800022 	mov	x2, #0x1                   	// #1
    4844:	39001fe3 	strb	w3, [sp, #7]
    4848:	17fffdd9 	b	3fac <fwp_write.constprop.0+0x9c>
    484c:	52800b63 	mov	w3, #0x5b                  	// #91
    4850:	91001ff5 	add	x21, sp, #0x7
    4854:	aa1503e1 	mov	x1, x21
    4858:	aa1403e0 	mov	x0, x20
    485c:	d2800022 	mov	x2, #0x1                   	// #1
    4860:	d0000016 	adrp	x22, 6000 <fwp_main_thread+0x114c>
    4864:	912ba2d6 	add	x22, x22, #0xae8
    4868:	39001fe3 	strb	w3, [sp, #7]
    486c:	97fff629 	bl	2110 <buf_put>
    4870:	b4000233 	cbz	x19, 48b4 <fwp_write.constprop.0+0x9a4>
    4874:	f9400661 	ldr	x1, [x19, #8]
    4878:	aa1403e0 	mov	x0, x20
    487c:	f9401f82 	ldr	x2, [x28, #56]
    4880:	97fffda4 	bl	3f10 <fwp_write.constprop.0>
    4884:	f9400a73 	ldr	x19, [x19, #16]
    4888:	b4000173 	cbz	x19, 48b4 <fwp_write.constprop.0+0x9a4>
    488c:	aa1603e1 	mov	x1, x22
    4890:	aa1403e0 	mov	x0, x20
    4894:	d2800042 	mov	x2, #0x2                   	// #2
    4898:	97fff61e 	bl	2110 <buf_put>
    489c:	f9400661 	ldr	x1, [x19, #8]
    48a0:	aa1403e0 	mov	x0, x20
    48a4:	f9401f82 	ldr	x2, [x28, #56]
    48a8:	97fffd9a 	bl	3f10 <fwp_write.constprop.0>
    48ac:	f9400a73 	ldr	x19, [x19, #16]
    48b0:	b5fffef3 	cbnz	x19, 488c <fwp_write.constprop.0+0x97c>
    48b4:	52800ba3 	mov	w3, #0x5d                  	// #93
    48b8:	aa1503e1 	mov	x1, x21
    48bc:	aa1403e0 	mov	x0, x20
    48c0:	d2800022 	mov	x2, #0x1                   	// #1
    48c4:	39001fe3 	strb	w3, [sp, #7]
    48c8:	17fffdb9 	b	3fac <fwp_write.constprop.0+0x9c>
    48cc:	52800783 	mov	w3, #0x3c                  	// #60
    48d0:	91001ff3 	add	x19, sp, #0x7
    48d4:	aa1303e1 	mov	x1, x19
    48d8:	d2800022 	mov	x2, #0x1                   	// #1
    48dc:	aa1403e0 	mov	x0, x20
    48e0:	39001fe3 	strb	w3, [sp, #7]
    48e4:	97fff60b 	bl	2110 <buf_put>
    48e8:	f9400795 	ldr	x21, [x28, #8]
    48ec:	aa1503e0 	mov	x0, x21
    48f0:	97fff2a8 	bl	1390 <strlen@plt>
    48f4:	aa1503e1 	mov	x1, x21
    48f8:	aa0003e2 	mov	x2, x0
    48fc:	aa1403e0 	mov	x0, x20
    4900:	97fff604 	bl	2110 <buf_put>
    4904:	528007c3 	mov	w3, #0x3e                  	// #62
    4908:	aa1303e1 	mov	x1, x19
    490c:	aa1403e0 	mov	x0, x20
    4910:	d2800022 	mov	x2, #0x1                   	// #1
    4914:	39001fe3 	strb	w3, [sp, #7]
    4918:	17fffda5 	b	3fac <fwp_write.constprop.0+0x9c>
    491c:	f100067f 	cmp	x19, #0x1
    4920:	540017e0 	b.eq	4c1c <fwp_write.constprop.0+0xd0c>  // b.none
    4924:	b100067f 	cmn	x19, #0x1
    4928:	54001b00 	b.eq	4c88 <fwp_write.constprop.0+0xd78>  // b.none
    492c:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4930:	91296021 	add	x1, x1, #0xa58
    4934:	d2800022 	mov	x2, #0x1                   	// #1
    4938:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    493c:	f947f400 	ldr	x0, [x0, #4072]
    4940:	f94127e4 	ldr	x4, [sp, #584]
    4944:	f9400003 	ldr	x3, [x0]
    4948:	eb030084 	subs	x4, x4, x3
    494c:	d2800003 	mov	x3, #0x0                   	// #0
    4950:	54002a41 	b.ne	4e98 <fwp_write.constprop.0+0xf88>  // b.any
    4954:	f9413bf5 	ldr	x21, [sp, #624]
    4958:	aa1403e0 	mov	x0, x20
    495c:	f9413ff6 	ldr	x22, [sp, #632]
    4960:	17fffdef 	b	411c <fwp_write.constprop.0+0x20c>
    4964:	52800fa3 	mov	w3, #0x7d                  	// #125
    4968:	17fffe2c 	b	4218 <fwp_write.constprop.0+0x308>
    496c:	f10002ff 	cmp	x23, #0x0
    4970:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4974:	71002c3f 	cmp	w1, #0xb
    4978:	54ffec80 	b.eq	4708 <fwp_write.constprop.0+0x7f8>  // b.none
    497c:	aa1303e2 	mov	x2, x19
    4980:	aa1703e1 	mov	x1, x23
    4984:	aa1403e0 	mov	x0, x20
    4988:	97fffd62 	bl	3f10 <fwp_write.constprop.0>
    498c:	17ffff70 	b	474c <fwp_write.constprop.0+0x83c>
    4990:	aa1903e1 	mov	x1, x25
    4994:	aa1403e0 	mov	x0, x20
    4998:	d2800042 	mov	x2, #0x2                   	// #2
    499c:	97fff5dd 	bl	2110 <buf_put>
    49a0:	17fffeee 	b	4558 <fwp_write.constprop.0+0x648>
    49a4:	aa1403e0 	mov	x0, x20
    49a8:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    49ac:	d2800042 	mov	x2, #0x2                   	// #2
    49b0:	912b0021 	add	x1, x1, #0xac0
    49b4:	97fff5d7 	bl	2110 <buf_put>
    49b8:	17fffee8 	b	4558 <fwp_write.constprop.0+0x648>
    49bc:	aa1803e1 	mov	x1, x24
    49c0:	aa1403e0 	mov	x0, x20
    49c4:	d2800042 	mov	x2, #0x2                   	// #2
    49c8:	97fff5d2 	bl	2110 <buf_put>
    49cc:	17fffee3 	b	4558 <fwp_write.constprop.0+0x648>
    49d0:	f9414bf9 	ldr	x25, [sp, #656]
    49d4:	f9414ffa 	ldr	x26, [sp, #664]
    49d8:	aa1503e1 	mov	x1, x21
    49dc:	aa1403e0 	mov	x0, x20
    49e0:	52800443 	mov	w3, #0x22                  	// #34
    49e4:	17fffe0f 	b	4220 <fwp_write.constprop.0+0x310>
    49e8:	a9400281 	ldp	x1, x0, [x20]
    49ec:	91000800 	add	x0, x0, #0x2
    49f0:	8b160000 	add	x0, x0, x22
    49f4:	f9000680 	str	x0, [x20, #8]
    49f8:	3820683f 	strb	wzr, [x1, x0]
    49fc:	f9413bf5 	ldr	x21, [sp, #624]
    4a00:	f9413ff6 	ldr	x22, [sp, #632]
    4a04:	f94153fb 	ldr	x27, [sp, #672]
    4a08:	f94157fc 	ldr	x28, [sp, #680]
    4a0c:	17fffd6d 	b	3fc0 <fwp_write.constprop.0+0xb0>
    4a10:	aa1403e0 	mov	x0, x20
    4a14:	91001fe1 	add	x1, sp, #0x7
    4a18:	52800fa3 	mov	w3, #0x7d                  	// #125
    4a1c:	d2800022 	mov	x2, #0x1                   	// #1
    4a20:	17fffe01 	b	4224 <fwp_write.constprop.0+0x314>
    4a24:	f9400f80 	ldr	x0, [x28, #24]
    4a28:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    4a2c:	aa1b03e0 	mov	x0, x27
    4a30:	97fff258 	bl	1390 <strlen@plt>
    4a34:	aa1b03e1 	mov	x1, x27
    4a38:	aa0003e2 	mov	x2, x0
    4a3c:	aa1403e0 	mov	x0, x20
    4a40:	97fff5b4 	bl	2110 <buf_put>
    4a44:	aa1903e1 	mov	x1, x25
    4a48:	aa1403e0 	mov	x0, x20
    4a4c:	d2800062 	mov	x2, #0x3                   	// #3
    4a50:	97fff5b0 	bl	2110 <buf_put>
    4a54:	17fffde4 	b	41e4 <fwp_write.constprop.0+0x2d4>
    4a58:	aa1a03e1 	mov	x1, x26
    4a5c:	aa1403e0 	mov	x0, x20
    4a60:	d2800042 	mov	x2, #0x2                   	// #2
    4a64:	97fff5ab 	bl	2110 <buf_put>
    4a68:	17fffddd 	b	41dc <fwp_write.constprop.0+0x2cc>
    4a6c:	f9400660 	ldr	x0, [x19, #8]
    4a70:	b4fff860 	cbz	x0, 497c <fwp_write.constprop.0+0xa6c>
    4a74:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4a78:	912c0021 	add	x1, x1, #0xb00
    4a7c:	97fff2c1 	bl	1580 <strcmp@plt>
    4a80:	7100001f 	cmp	w0, #0x0
    4a84:	1a9f07e0 	cset	w0, ne	// ne = any
    4a88:	17ffff20 	b	4708 <fwp_write.constprop.0+0x7f8>
    4a8c:	aa1403e0 	mov	x0, x20
    4a90:	d2800042 	mov	x2, #0x2                   	// #2
    4a94:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4a98:	912be021 	add	x1, x1, #0xaf8
    4a9c:	97fff59d 	bl	2110 <buf_put>
    4aa0:	91004261 	add	x1, x19, #0x10
    4aa4:	aa1403e0 	mov	x0, x20
    4aa8:	f9402382 	ldr	x2, [x28, #64]
    4aac:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    4ab0:	97fffd18 	bl	3f10 <fwp_write.constprop.0>
    4ab4:	17fffd71 	b	4078 <fwp_write.constprop.0+0x168>
    4ab8:	d2800203 	mov	x3, #0x10                  	// #16
    4abc:	d0000004 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    4ac0:	aa0303e1 	mov	x1, x3
    4ac4:	912b4084 	add	x4, x4, #0xad0
    4ac8:	910123f7 	add	x23, sp, #0x48
    4acc:	52800042 	mov	w2, #0x2                   	// #2
    4ad0:	aa1703e0 	mov	x0, x23
    4ad4:	97fff267 	bl	1470 <__snprintf_chk@plt>
    4ad8:	aa1703e0 	mov	x0, x23
    4adc:	97fff22d 	bl	1390 <strlen@plt>
    4ae0:	aa1703e1 	mov	x1, x23
    4ae4:	aa0003e2 	mov	x2, x0
    4ae8:	aa1403e0 	mov	x0, x20
    4aec:	97fff589 	bl	2110 <buf_put>
    4af0:	17fffe9a 	b	4558 <fwp_write.constprop.0+0x648>
    4af4:	7101fcbf 	cmp	w5, #0x7f
    4af8:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    4afc:	54fffde9 	b.ls	4ab8 <fwp_write.constprop.0+0xba8>  // b.plast
    4b00:	aa1503e1 	mov	x1, x21
    4b04:	aa1403e0 	mov	x0, x20
    4b08:	d2800022 	mov	x2, #0x1                   	// #1
    4b0c:	39001fe5 	strb	w5, [sp, #7]
    4b10:	97fff580 	bl	2110 <buf_put>
    4b14:	17fffe91 	b	4558 <fwp_write.constprop.0+0x648>
    4b18:	1e22c109 	fcvt	d9, s8
    4b1c:	910123f5 	add	x21, sp, #0x48
    4b20:	52800033 	mov	w19, #0x1                   	// #1
    4b24:	d503201f 	nop
    4b28:	1e604120 	fmov	d0, d9
    4b2c:	2a1303e1 	mov	w1, w19
    4b30:	aa1503e0 	mov	x0, x21
    4b34:	97fff60b 	bl	2360 <fwp_format_g.constprop.0>
    4b38:	aa1503e0 	mov	x0, x21
    4b3c:	d2800001 	mov	x1, #0x0                   	// #0
    4b40:	97fff29c 	bl	15b0 <strtof@plt>
    4b44:	1e202100 	fcmp	s8, s0
    4b48:	54ffd6c0 	b.eq	4620 <fwp_write.constprop.0+0x710>  // b.none
    4b4c:	11000673 	add	w19, w19, #0x1
    4b50:	71002a7f 	cmp	w19, #0xa
    4b54:	54fffea1 	b.ne	4b28 <fwp_write.constprop.0+0xc18>  // b.any
    4b58:	1e604120 	fmov	d0, d9
    4b5c:	aa1503e0 	mov	x0, x21
    4b60:	52800121 	mov	w1, #0x9                   	// #9
    4b64:	97fff5ff 	bl	2360 <fwp_format_g.constprop.0>
    4b68:	17fffeae 	b	4620 <fwp_write.constprop.0+0x710>
    4b6c:	d37ef6a1 	lsl	x1, x21, #2
    4b70:	b7f809a3 	tbnz	x3, #63, 4ca4 <fwp_write.constprop.0+0xd94>
    4b74:	91002263 	add	x3, x19, #0x8
    4b78:	8b010061 	add	x1, x3, x1
    4b7c:	b9400023 	ldr	w3, [x1]
    4b80:	7100081f 	cmp	w0, #0x2
    4b84:	2a0303e1 	mov	w1, w3
    4b88:	93407c63 	sxtw	x3, w3
    4b8c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4b90:	17fffe16 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4b94:	d37ffaa1 	lsl	x1, x21, #1
    4b98:	b7f80803 	tbnz	x3, #63, 4c98 <fwp_write.constprop.0+0xd88>
    4b9c:	91002263 	add	x3, x19, #0x8
    4ba0:	8b010061 	add	x1, x3, x1
    4ba4:	79400021 	ldrh	w1, [x1]
    4ba8:	7100041f 	cmp	w0, #0x1
    4bac:	93403c23 	sxth	x3, w1
    4bb0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4bb4:	17fffe0d 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4bb8:	7100103f 	cmp	w1, #0x4
    4bbc:	54ffee01 	b.ne	497c <fwp_write.constprop.0+0xa6c>  // b.any
    4bc0:	f94006e0 	ldr	x0, [x23, #8]
    4bc4:	d37ffc00 	lsr	x0, x0, #63
    4bc8:	17fffed0 	b	4708 <fwp_write.constprop.0+0x7f8>
    4bcc:	710002ff 	cmp	w23, #0x0
    4bd0:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4bd4:	17fffecd 	b	4708 <fwp_write.constprop.0+0x7f8>
    4bd8:	528005a1 	mov	w1, #0x2d                  	// #45
    4bdc:	eb0203e2 	negs	x2, x2
    4be0:	da0303e3 	ngc	x3, x3
    4be4:	910127e0 	add	x0, sp, #0x49
    4be8:	910123f5 	add	x21, sp, #0x48
    4bec:	390123e1 	strb	w1, [sp, #72]
    4bf0:	97fff39c 	bl	1a60 <fwp_fmt_u128>
    4bf4:	17fffe16 	b	444c <fwp_write.constprop.0+0x53c>
    4bf8:	d37ceea1 	lsl	x1, x21, #4
    4bfc:	b7f80da3 	tbnz	x3, #63, 4db0 <fwp_write.constprop.0+0xea0>
    4c00:	91002260 	add	x0, x19, #0x8
    4c04:	8b010001 	add	x1, x0, x1
    4c08:	17fffdf8 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4c0c:	f9400a61 	ldr	x1, [x19, #16]
    4c10:	8b010000 	add	x0, x0, x1
    4c14:	f9400001 	ldr	x1, [x0]
    4c18:	17fffdf4 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4c1c:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4c20:	d2800042 	mov	x2, #0x2                   	// #2
    4c24:	91292021 	add	x1, x1, #0xa48
    4c28:	17ffff44 	b	4938 <fwp_write.constprop.0+0xa28>
    4c2c:	1e604100 	fmov	d0, d8
    4c30:	aa1503e0 	mov	x0, x21
    4c34:	52800221 	mov	w1, #0x11                  	// #17
    4c38:	97fff5ca 	bl	2360 <fwp_format_g.constprop.0>
    4c3c:	17fffe79 	b	4620 <fwp_write.constprop.0+0x710>
    4c40:	b9401380 	ldr	w0, [x28, #16]
    4c44:	350003c0 	cbnz	w0, 4cbc <fwp_write.constprop.0+0xdac>
    4c48:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    4c4c:	f947f400 	ldr	x0, [x0, #4072]
    4c50:	f94127e2 	ldr	x2, [sp, #584]
    4c54:	f9400001 	ldr	x1, [x0]
    4c58:	eb010042 	subs	x2, x2, x1
    4c5c:	d2800001 	mov	x1, #0x0                   	// #0
    4c60:	54001201 	b.ne	4ea0 <fwp_write.constprop.0+0xf90>  // b.any
    4c64:	f9413bf5 	ldr	x21, [sp, #624]
    4c68:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4c6c:	f9413ff6 	ldr	x22, [sp, #632]
    4c70:	aa1403e0 	mov	x0, x20
    4c74:	f94143f7 	ldr	x23, [sp, #640]
    4c78:	912c8021 	add	x1, x1, #0xb20
    4c7c:	f94147f8 	ldr	x24, [sp, #648]
    4c80:	d2800042 	mov	x2, #0x2                   	// #2
    4c84:	17fffd26 	b	411c <fwp_write.constprop.0+0x20c>
    4c88:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4c8c:	d2800042 	mov	x2, #0x2                   	// #2
    4c90:	91294021 	add	x1, x1, #0xa50
    4c94:	17ffff29 	b	4938 <fwp_write.constprop.0+0xa28>
    4c98:	f9400a63 	ldr	x3, [x19, #16]
    4c9c:	8b030021 	add	x1, x1, x3
    4ca0:	17ffffc1 	b	4ba4 <fwp_write.constprop.0+0xc94>
    4ca4:	f9400a63 	ldr	x3, [x19, #16]
    4ca8:	8b030021 	add	x1, x1, x3
    4cac:	17ffffb4 	b	4b7c <fwp_write.constprop.0+0xc6c>
    4cb0:	f9400a61 	ldr	x1, [x19, #16]
    4cb4:	8b0102a1 	add	x1, x21, x1
    4cb8:	17fffdc7 	b	43d4 <fwp_write.constprop.0+0x4c4>
    4cbc:	b9404b80 	ldr	w0, [x28, #72]
    4cc0:	91001ff5 	add	x21, sp, #0x7
    4cc4:	34ffa660 	cbz	w0, 4190 <fwp_write.constprop.0+0x280>
    4cc8:	52800503 	mov	w3, #0x28                  	// #40
    4ccc:	aa1403e0 	mov	x0, x20
    4cd0:	aa1503e1 	mov	x1, x21
    4cd4:	d2800022 	mov	x2, #0x1                   	// #1
    4cd8:	39001fe3 	strb	w3, [sp, #7]
    4cdc:	97fff50d 	bl	2110 <buf_put>
    4ce0:	b9401380 	ldr	w0, [x28, #16]
    4ce4:	52800038 	mov	w24, #0x1                   	// #1
    4ce8:	7100001f 	cmp	w0, #0x0
    4cec:	54ffa66c 	b.gt	41b8 <fwp_write.constprop.0+0x2a8>
    4cf0:	17fffd49 	b	4214 <fwp_write.constprop.0+0x304>
    4cf4:	f9014bf9 	str	x25, [sp, #656]
    4cf8:	f00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x175b8>
    4cfc:	f9014ffa 	str	x26, [sp, #664]
    4d00:	f9400676 	ldr	x22, [x19, #8]
    4d04:	912ca333 	add	x19, x25, #0xb28
    4d08:	91002273 	add	x19, x19, #0x8
    4d0c:	937ffed8 	asr	x24, x22, #63
    4d10:	aa1802c0 	orr	x0, x22, x24
    4d14:	b5000320 	cbnz	x0, 4d78 <fwp_write.constprop.0+0xe68>
    4d18:	110006b5 	add	w21, w21, #0x1
    4d1c:	710016bf 	cmp	w21, #0x5
    4d20:	54ffffc1 	b.ne	4d18 <fwp_write.constprop.0+0xe08>  // b.any
    4d24:	b7f80578 	tbnz	x24, #63, 4dd0 <fwp_write.constprop.0+0xec0>
    4d28:	910023f3 	add	x19, sp, #0x8
    4d2c:	aa1603e2 	mov	x2, x22
    4d30:	aa1303e0 	mov	x0, x19
    4d34:	d2800003 	mov	x3, #0x0                   	// #0
    4d38:	97fff34a 	bl	1a60 <fwp_fmt_u128>
    4d3c:	910123f5 	add	x21, sp, #0x48
    4d40:	d0000003 	adrp	x3, 6000 <fwp_main_thread+0x114c>
    4d44:	aa1303e4 	mov	x4, x19
    4d48:	aa1503e0 	mov	x0, x21
    4d4c:	912c6063 	add	x3, x3, #0xb18
    4d50:	d2804002 	mov	x2, #0x200                 	// #512
    4d54:	52800041 	mov	w1, #0x2                   	// #2
    4d58:	97fff192 	bl	13a0 <__sprintf_chk@plt>
    4d5c:	aa1503e0 	mov	x0, x21
    4d60:	97fff18c 	bl	1390 <strlen@plt>
    4d64:	aa1503e1 	mov	x1, x21
    4d68:	aa0003e2 	mov	x2, x0
    4d6c:	aa1403e0 	mov	x0, x20
    4d70:	97fff4e8 	bl	2110 <buf_put>
    4d74:	17fffe7b 	b	4760 <fwp_write.constprop.0+0x850>
    4d78:	f9400277 	ldr	x23, [x19]
    4d7c:	aa1603e0 	mov	x0, x22
    4d80:	aa1803e1 	mov	x1, x24
    4d84:	aa1703e2 	mov	x2, x23
    4d88:	937ffefa 	asr	x26, x23, #63
    4d8c:	aa1a03e3 	mov	x3, x26
    4d90:	94000584 	bl	63a0 <__modti3>
    4d94:	aa010000 	orr	x0, x0, x1
    4d98:	b40002c0 	cbz	x0, 4df0 <fwp_write.constprop.0+0xee0>
    4d9c:	110006b5 	add	w21, w21, #0x1
    4da0:	91004273 	add	x19, x19, #0x10
    4da4:	710016bf 	cmp	w21, #0x5
    4da8:	54fffe81 	b.ne	4d78 <fwp_write.constprop.0+0xe68>  // b.any
    4dac:	17ffffde 	b	4d24 <fwp_write.constprop.0+0xe14>
    4db0:	f9400a60 	ldr	x0, [x19, #16]
    4db4:	8b000021 	add	x1, x1, x0
    4db8:	17fffd8c 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4dbc:	528c29c0 	mov	w0, #0x614e                	// #24910
    4dc0:	910123f5 	add	x21, sp, #0x48
    4dc4:	72a009c0 	movk	w0, #0x4e, lsl #16
    4dc8:	b9004be0 	str	w0, [sp, #72]
    4dcc:	17fffdb9 	b	44b0 <fwp_write.constprop.0+0x5a0>
    4dd0:	528005a1 	mov	w1, #0x2d                  	// #45
    4dd4:	eb1603e2 	negs	x2, x22
    4dd8:	da1803e3 	ngc	x3, x24
    4ddc:	910027e0 	add	x0, sp, #0x9
    4de0:	910023f3 	add	x19, sp, #0x8
    4de4:	390023e1 	strb	w1, [sp, #8]
    4de8:	97fff31e 	bl	1a60 <fwp_fmt_u128>
    4dec:	17ffffd4 	b	4d3c <fwp_write.constprop.0+0xe2c>
    4df0:	aa1703e2 	mov	x2, x23
    4df4:	aa1a03e3 	mov	x3, x26
    4df8:	aa1603e0 	mov	x0, x22
    4dfc:	aa1803e1 	mov	x1, x24
    4e00:	94000488 	bl	6020 <__divti3>
    4e04:	aa0003e2 	mov	x2, x0
    4e08:	aa0103e3 	mov	x3, x1
    4e0c:	b7f80201 	tbnz	x1, #63, 4e4c <fwp_write.constprop.0+0xf3c>
    4e10:	910023f3 	add	x19, sp, #0x8
    4e14:	aa1303e0 	mov	x0, x19
    4e18:	97fff312 	bl	1a60 <fwp_fmt_u128>
    4e1c:	937c7ea1 	sbfiz	x1, x21, #4, #32
    4e20:	912ca339 	add	x25, x25, #0xb28
    4e24:	910123f5 	add	x21, sp, #0x48
    4e28:	aa1303e4 	mov	x4, x19
    4e2c:	aa1503e0 	mov	x0, x21
    4e30:	d0000003 	adrp	x3, 6000 <fwp_main_thread+0x114c>
    4e34:	f8616b25 	ldr	x5, [x25, x1]
    4e38:	912c4063 	add	x3, x3, #0xb10
    4e3c:	d2804002 	mov	x2, #0x200                 	// #512
    4e40:	52800041 	mov	w1, #0x2                   	// #2
    4e44:	97fff157 	bl	13a0 <__sprintf_chk@plt>
    4e48:	17ffffc5 	b	4d5c <fwp_write.constprop.0+0xe4c>
    4e4c:	528005a4 	mov	w4, #0x2d                  	// #45
    4e50:	eb0003e2 	negs	x2, x0
    4e54:	da0103e3 	ngc	x3, x1
    4e58:	910027e0 	add	x0, sp, #0x9
    4e5c:	910023f3 	add	x19, sp, #0x8
    4e60:	390023e4 	strb	w4, [sp, #8]
    4e64:	97fff2ff 	bl	1a60 <fwp_fmt_u128>
    4e68:	17ffffed 	b	4e1c <fwp_write.constprop.0+0xf0c>
    4e6c:	f9013bf5 	str	x21, [sp, #624]
    4e70:	f9013ff6 	str	x22, [sp, #632]
    4e74:	f90143f7 	str	x23, [sp, #640]
    4e78:	f90147f8 	str	x24, [sp, #648]
    4e7c:	f9014bf9 	str	x25, [sp, #656]
    4e80:	f9014ffa 	str	x26, [sp, #664]
    4e84:	f90153fb 	str	x27, [sp, #672]
    4e88:	f90157fc 	str	x28, [sp, #680]
    4e8c:	fd015be8 	str	d8, [sp, #688]
    4e90:	fd015fe9 	str	d9, [sp, #696]
    4e94:	97fff19b 	bl	1500 <__stack_chk_fail@plt>
    4e98:	f90143f7 	str	x23, [sp, #640]
    4e9c:	f90147f8 	str	x24, [sp, #648]
    4ea0:	f9014bf9 	str	x25, [sp, #656]
    4ea4:	f9014ffa 	str	x26, [sp, #664]
    4ea8:	fd015be8 	str	d8, [sp, #688]
    4eac:	fd015fe9 	str	d9, [sp, #696]
    4eb0:	97fff194 	bl	1500 <__stack_chk_fail@plt>

0000000000004eb4 <fwp_main_thread>:
    4eb4:	d10603ff 	sub	sp, sp, #0x180
    4eb8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    4ebc:	f947f400 	ldr	x0, [x0, #4072]
    4ec0:	a9127bfd 	stp	x29, x30, [sp, #288]
    4ec4:	910483fd 	add	x29, sp, #0x120
    4ec8:	a9145bf5 	stp	x21, x22, [sp, #320]
    4ecc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4ed0:	9114c2a1 	add	x1, x21, #0x530
    4ed4:	a91353f3 	stp	x19, x20, [sp, #304]
    4ed8:	a91563f7 	stp	x23, x24, [sp, #336]
    4edc:	b953a421 	ldr	w1, [x1, #5028]
    4ee0:	a9166bf9 	stp	x25, x26, [sp, #352]
    4ee4:	a91773fb 	stp	x27, x28, [sp, #368]
    4ee8:	f9400002 	ldr	x2, [x0]
    4eec:	f9008fe2 	str	x2, [sp, #280]
    4ef0:	d2800002 	mov	x2, #0x0                   	// #0
    4ef4:	34002741 	cbz	w1, 53dc <fwp_main_thread+0x528>
    4ef8:	9114c2a0 	add	x0, x21, #0x530
    4efc:	b953a800 	ldr	w0, [x0, #5032]
    4f00:	35002760 	cbnz	w0, 53ec <fwp_main_thread+0x538>
    4f04:	9100a3e5 	add	x5, sp, #0x28
    4f08:	900000f4 	adrp	x20, 20000 <__data_start>
    4f0c:	900000e2 	adrp	x2, 20000 <__data_start>
    4f10:	9101429a 	add	x26, x20, #0x50
    4f14:	910d4042 	add	x2, x2, #0x350
    4f18:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    4f1c:	d2a00024 	mov	x4, #0x10000               	// #65536
    4f20:	910103f3 	add	x19, sp, #0x40
    4f24:	aa1303e0 	mov	x0, x19
    4f28:	d2800001 	mov	x1, #0x0                   	// #0
    4f2c:	f90007e5 	str	x5, [sp, #8]
    4f30:	a9010f45 	stp	x5, x3, [x26, #16]
    4f34:	f90023e2 	str	x2, [sp, #64]
    4f38:	b9004bff 	str	wzr, [sp, #72]
    4f3c:	f9002be4 	str	x4, [sp, #80]
    4f40:	97fff10c 	bl	1370 <sigaltstack@plt>
    4f44:	35008660 	cbnz	w0, 6010 <fwp_main_thread+0x115c>
    4f48:	4f000400 	movi	v0.4s, #0x0
    4f4c:	910223e0 	add	x0, sp, #0x88
    4f50:	b0ffffe1 	adrp	x1, 1000 <__abi_tag+0xd88>
    4f54:	91304021 	add	x1, x1, #0xc10
    4f58:	f90043e1 	str	x1, [sp, #128]
    4f5c:	52800082 	mov	w2, #0x4                   	// #4
    4f60:	72a10002 	movk	w2, #0x800, lsl #16
    4f64:	910203f6 	add	x22, sp, #0x80
    4f68:	3d802000 	str	q0, [x0, #128]
    4f6c:	b9010be2 	str	w2, [sp, #264]
    4f70:	f90003f6 	str	x22, [sp]
    4f74:	ad000000 	stp	q0, q0, [x0]
    4f78:	ad010000 	stp	q0, q0, [x0, #32]
    4f7c:	ad020000 	stp	q0, q0, [x0, #64]
    4f80:	ad030000 	stp	q0, q0, [x0, #96]
    4f84:	97fff14f 	bl	14c0 <sigemptyset@plt>
    4f88:	35008440 	cbnz	w0, 6010 <fwp_main_thread+0x115c>
    4f8c:	aa1603e1 	mov	x1, x22
    4f90:	d2800002 	mov	x2, #0x0                   	// #0
    4f94:	52800160 	mov	w0, #0xb                   	// #11
    4f98:	97fff162 	bl	1520 <sigaction@plt>
    4f9c:	350083a0 	cbnz	w0, 6010 <fwp_main_thread+0x115c>
    4fa0:	aa1603e1 	mov	x1, x22
    4fa4:	d2800002 	mov	x2, #0x0                   	// #0
    4fa8:	528000e0 	mov	w0, #0x7                   	// #7
    4fac:	97fff15d 	bl	1520 <sigaction@plt>
    4fb0:	35008300 	cbnz	w0, 6010 <fwp_main_thread+0x115c>
    4fb4:	9114c2bc 	add	x28, x21, #0x530
    4fb8:	52800038 	mov	w24, #0x1                   	// #1
    4fbc:	b0ffffe0 	adrp	x0, 1000 <__abi_tag+0xd88>
    4fc0:	913c4000 	add	x0, x0, #0xf10
    4fc4:	b9004358 	str	w24, [x26, #64]
    4fc8:	fd4a1380 	ldr	d0, [x28, #5152]
    4fcc:	7e61d800 	ucvtf	d0, d0
    4fd0:	fd002f40 	str	d0, [x26, #88]
    4fd4:	940005cf 	bl	6710 <atexit>
    4fd8:	35008100 	cbnz	w0, 5ff8 <fwp_main_thread+0x1144>
    4fdc:	b942c740 	ldr	w0, [x26, #708]
    4fe0:	340020e0 	cbz	w0, 53fc <fwp_main_thread+0x548>
    4fe4:	9101429a 	add	x26, x20, #0x50
    4fe8:	f9400756 	ldr	x22, [x26, #8]
    4fec:	b4000c56 	cbz	x22, 5174 <fwp_main_thread+0x2c0>
    4ff0:	aa1603f3 	mov	x19, x22
    4ff4:	910102d7 	add	x23, x22, #0x40
    4ff8:	39414ad9 	ldrb	w25, [x22, #82]
    4ffc:	52800038 	mov	w24, #0x1                   	// #1
    5000:	39014ad8 	strb	w24, [x22, #82]
    5004:	f94016c0 	ldr	x0, [x22, #40]
    5008:	b4000620 	cbz	x0, 50cc <fwp_main_thread+0x218>
    500c:	f94032c1 	ldr	x1, [x22, #96]
    5010:	394146c0 	ldrb	w0, [x22, #81]
    5014:	b4000ca1 	cbz	x1, 51a8 <fwp_main_thread+0x2f4>
    5018:	36000b60 	tbz	w0, #0, 5184 <fwp_main_thread+0x2d0>
    501c:	39414a62 	ldrb	w2, [x19, #82]
    5020:	f94022c0 	ldr	x0, [x22, #64]
    5024:	37000ec2 	tbnz	w2, #0, 51fc <fwp_main_thread+0x348>
    5028:	f9403261 	ldr	x1, [x19, #96]
    502c:	a911fe77 	stp	x23, xzr, [x19, #280]
    5030:	f9009660 	str	x0, [x19, #296]
    5034:	b4000040 	cbz	x0, 503c <fwp_main_thread+0x188>
    5038:	f9009013 	str	x19, [x0, #288]
    503c:	f90022d3 	str	x19, [x22, #64]
    5040:	b4000101 	cbz	x1, 5060 <fwp_main_thread+0x1ac>
    5044:	f9401f40 	ldr	x0, [x26, #56]
    5048:	39015678 	strb	w24, [x19, #85]
    504c:	f9003661 	str	x1, [x19, #104]
    5050:	a910827f 	stp	xzr, x0, [x19, #264]
    5054:	b4000040 	cbz	x0, 505c <fwp_main_thread+0x1a8>
    5058:	f9008413 	str	x19, [x0, #264]
    505c:	f9001f53 	str	x19, [x26, #56]
    5060:	39015a7f 	strb	wzr, [x19, #86]
    5064:	97fffb54 	bl	3db4 <fwp_block>
    5068:	f9408e62 	ldr	x2, [x19, #280]
    506c:	b4000142 	cbz	x2, 5094 <fwp_main_thread+0x1e0>
    5070:	a9520261 	ldp	x1, x0, [x19, #288]
    5074:	b4000d01 	cbz	x1, 5214 <fwp_main_thread+0x360>
    5078:	f9009420 	str	x0, [x1, #296]
    507c:	f9409660 	ldr	x0, [x19, #296]
    5080:	b4000040 	cbz	x0, 5088 <fwp_main_thread+0x1d4>
    5084:	f9009001 	str	x1, [x0, #288]
    5088:	91080260 	add	x0, x19, #0x200
    508c:	f900967f 	str	xzr, [x19, #296]
    5090:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    5094:	39415660 	ldrb	w0, [x19, #85]
    5098:	f9400742 	ldr	x2, [x26, #8]
    509c:	36000ac0 	tbz	w0, #0, 51f4 <fwp_main_thread+0x340>
    50a0:	a9508261 	ldp	x1, x0, [x19, #264]
    50a4:	b4000bc1 	cbz	x1, 521c <fwp_main_thread+0x368>
    50a8:	f9008820 	str	x0, [x1, #272]
    50ac:	b4000040 	cbz	x0, 50b4 <fwp_main_thread+0x200>
    50b0:	f9008401 	str	x1, [x0, #264]
    50b4:	91080260 	add	x0, x19, #0x200
    50b8:	3901567f 	strb	wzr, [x19, #85]
    50bc:	aa0203f3 	mov	x19, x2
    50c0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    50c4:	f94016c0 	ldr	x0, [x22, #40]
    50c8:	b5fffa20 	cbnz	x0, 500c <fwp_main_thread+0x158>
    50cc:	91014280 	add	x0, x20, #0x50
    50d0:	39014ad9 	strb	w25, [x22, #82]
    50d4:	f9415400 	ldr	x0, [x0, #680]
    50d8:	b5000080 	cbnz	x0, 50e8 <fwp_main_thread+0x234>
    50dc:	91014296 	add	x22, x20, #0x50
    50e0:	f9415ec0 	ldr	x0, [x22, #696]
    50e4:	b4006860 	cbz	x0, 5df0 <fwp_main_thread+0xf3c>
    50e8:	91014280 	add	x0, x20, #0x50
    50ec:	f9417001 	ldr	x1, [x0, #736]
    50f0:	b902d81f 	str	wzr, [x0, #728]
    50f4:	eb13003f 	cmp	x1, x19
    50f8:	54006921 	b.ne	5e1c <fwp_main_thread+0xf68>  // b.any
    50fc:	b40009f3 	cbz	x19, 5238 <fwp_main_thread+0x384>
    5100:	91014280 	add	x0, x20, #0x50
    5104:	52800021 	mov	w1, #0x1                   	// #1
    5108:	39014a61 	strb	w1, [x19, #82]
    510c:	f9414005 	ldr	x5, [x0, #640]
    5110:	b4000945 	cbz	x5, 5238 <fwp_main_thread+0x384>
    5114:	d503201f 	nop
    5118:	394140a0 	ldrb	w0, [x5, #80]
    511c:	37000060 	tbnz	w0, #0, 5128 <fwp_main_thread+0x274>
    5120:	aa0503e0 	mov	x0, x5
    5124:	97fff413 	bl	2170 <fwp_cancel_tree.part.0>
    5128:	f9409ca5 	ldr	x5, [x5, #312]
    512c:	b5ffff65 	cbnz	x5, 5118 <fwp_main_thread+0x264>
    5130:	91014296 	add	x22, x20, #0x50
    5134:	52800037 	mov	w23, #0x1                   	// #1
    5138:	f9402a60 	ldr	x0, [x19, #80]
    513c:	f2001c1f 	tst	x0, #0xff000000ff
    5140:	540000e1 	b.ne	515c <fwp_main_thread+0x2a8>  // b.any
    5144:	f94016c0 	ldr	x0, [x22, #40]
    5148:	39015277 	strb	w23, [x19, #84]
    514c:	f900827f 	str	xzr, [x19, #256]
    5150:	b40006a0 	cbz	x0, 5224 <fwp_main_thread+0x370>
    5154:	f9008013 	str	x19, [x0, #256]
    5158:	f90016d3 	str	x19, [x22, #40]
    515c:	97fffb16 	bl	3db4 <fwp_block>
    5160:	97fffaa8 	bl	3c00 <fwp_free_zombie>
    5164:	f94142c0 	ldr	x0, [x22, #640]
    5168:	b4000680 	cbz	x0, 5238 <fwp_main_thread+0x384>
    516c:	f94172d3 	ldr	x19, [x22, #736]
    5170:	17fffff2 	b	5138 <fwp_main_thread+0x284>
    5174:	f9415740 	ldr	x0, [x26, #680]
    5178:	b50005a0 	cbnz	x0, 522c <fwp_main_thread+0x378>
    517c:	d2800013 	mov	x19, #0x0                   	// #0
    5180:	17ffffd7 	b	50dc <fwp_main_thread+0x228>
    5184:	97fff44f 	bl	22c0 <fwp_now_ns>
    5188:	f94032c1 	ldr	x1, [x22, #96]
    518c:	eb01001f 	cmp	x0, x1
    5190:	540000ab 	b.lt	51a4 <fwp_main_thread+0x2f0>  // b.tstop
    5194:	394142c0 	ldrb	w0, [x22, #80]
    5198:	37000060 	tbnz	w0, #0, 51a4 <fwp_main_thread+0x2f0>
    519c:	aa1603e0 	mov	x0, x22
    51a0:	97fff3f4 	bl	2170 <fwp_cancel_tree.part.0>
    51a4:	394146c0 	ldrb	w0, [x22, #81]
    51a8:	39414a62 	ldrb	w2, [x19, #82]
    51ac:	3707f3a0 	tbnz	w0, #0, 5020 <fwp_main_thread+0x16c>
    51b0:	f94032c1 	ldr	x1, [x22, #96]
    51b4:	370001c2 	tbnz	w2, #0, 51ec <fwp_main_thread+0x338>
    51b8:	f9403260 	ldr	x0, [x19, #96]
    51bc:	b4000180 	cbz	x0, 51ec <fwp_main_thread+0x338>
    51c0:	b4000061 	cbz	x1, 51cc <fwp_main_thread+0x318>
    51c4:	eb01001f 	cmp	x0, x1
    51c8:	9a81d000 	csel	x0, x0, x1, le
    51cc:	f94022c1 	ldr	x1, [x22, #64]
    51d0:	a911fe77 	stp	x23, xzr, [x19, #280]
    51d4:	f9009661 	str	x1, [x19, #296]
    51d8:	b4005fa1 	cbz	x1, 5dcc <fwp_main_thread+0xf18>
    51dc:	f9009033 	str	x19, [x1, #288]
    51e0:	aa0003e1 	mov	x1, x0
    51e4:	f90022d3 	str	x19, [x22, #64]
    51e8:	17ffff97 	b	5044 <fwp_main_thread+0x190>
    51ec:	f94022c0 	ldr	x0, [x22, #64]
    51f0:	17ffff8f 	b	502c <fwp_main_thread+0x178>
    51f4:	aa0203f3 	mov	x19, x2
    51f8:	17ffff83 	b	5004 <fwp_main_thread+0x150>
    51fc:	a911fe77 	stp	x23, xzr, [x19, #280]
    5200:	f9009660 	str	x0, [x19, #296]
    5204:	b4000040 	cbz	x0, 520c <fwp_main_thread+0x358>
    5208:	f9009013 	str	x19, [x0, #288]
    520c:	f90022d3 	str	x19, [x22, #64]
    5210:	17ffff94 	b	5060 <fwp_main_thread+0x1ac>
    5214:	f9000040 	str	x0, [x2]
    5218:	17ffff9a 	b	5080 <fwp_main_thread+0x1cc>
    521c:	f9001f40 	str	x0, [x26, #56]
    5220:	17ffffa3 	b	50ac <fwp_main_thread+0x1f8>
    5224:	f9001ad3 	str	x19, [x22, #48]
    5228:	17ffffcc 	b	5158 <fwp_main_thread+0x2a4>
    522c:	f9417340 	ldr	x0, [x26, #736]
    5230:	b902db5f 	str	wzr, [x26, #728]
    5234:	b5005f40 	cbnz	x0, 5e1c <fwp_main_thread+0xf68>
    5238:	91014296 	add	x22, x20, #0x50
    523c:	97fffa71 	bl	3c00 <fwp_free_zombie>
    5240:	f9401ac0 	ldr	x0, [x22, #48]
    5244:	b5005ec0 	cbnz	x0, 5e1c <fwp_main_thread+0xf68>
    5248:	f9401ec0 	ldr	x0, [x22, #56]
    524c:	b5005e80 	cbnz	x0, 5e1c <fwp_main_thread+0xf68>
    5250:	b94072c0 	ldr	w0, [x22, #112]
    5254:	340001c0 	cbz	w0, 528c <fwp_main_thread+0x3d8>
    5258:	93407c17 	sxtw	x23, w0
    525c:	51000400 	sub	w0, w0, #0x1
    5260:	d1000af7 	sub	x23, x23, #0x2
    5264:	910202d8 	add	x24, x22, #0x80
    5268:	cb2042f7 	sub	x23, x23, w0, uxtw
    526c:	93407c13 	sxtw	x19, w0
    5270:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    5274:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    5278:	b90072d3 	str	w19, [x22, #112]
    527c:	d1000673 	sub	x19, x19, #0x1
    5280:	97fff0e8 	bl	1620 <munmap@plt>
    5284:	eb1302ff 	cmp	x23, x19
    5288:	54ffff41 	b.ne	5270 <fwp_main_thread+0x3bc>  // b.any
    528c:	f00000d3 	adrp	x19, 20000 <__data_start>
    5290:	91004260 	add	x0, x19, #0x10
    5294:	b9402000 	ldr	w0, [x0, #32]
    5298:	37f80040 	tbnz	w0, #31, 52a0 <fwp_main_thread+0x3ec>
    529c:	97fff09d 	bl	1510 <close@plt>
    52a0:	91014280 	add	x0, x20, #0x50
    52a4:	91004261 	add	x1, x19, #0x10
    52a8:	12800002 	mov	w2, #0xffffffff            	// #-1
    52ac:	d2800013 	mov	x19, #0x0                   	// #0
    52b0:	f9417417 	ldr	x23, [x0, #744]
    52b4:	b9002022 	str	w2, [x1, #32]
    52b8:	f9417816 	ldr	x22, [x0, #752]
    52bc:	b4000177 	cbz	x23, 52e8 <fwp_main_thread+0x434>
    52c0:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    52c4:	b40000c0 	cbz	x0, 52dc <fwp_main_thread+0x428>
    52c8:	f9400001 	ldr	x1, [x0]
    52cc:	b5005a81 	cbnz	x1, 5e1c <fwp_main_thread+0xf68>
    52d0:	f9400401 	ldr	x1, [x0, #8]
    52d4:	b5005a41 	cbnz	x1, 5e1c <fwp_main_thread+0xf68>
    52d8:	97fff74a 	bl	3000 <fwp_mem_free>
    52dc:	91000673 	add	x19, x19, #0x1
    52e0:	eb1302ff 	cmp	x23, x19
    52e4:	54fffee1 	b.ne	52c0 <fwp_main_thread+0x40c>  // b.any
    52e8:	aa1603e0 	mov	x0, x22
    52ec:	97fff745 	bl	3000 <fwp_mem_free>
    52f0:	91014280 	add	x0, x20, #0x50
    52f4:	f9417013 	ldr	x19, [x0, #736]
    52f8:	f901741f 	str	xzr, [x0, #744]
    52fc:	f901781f 	str	xzr, [x0, #752]
    5300:	b40001f3 	cbz	x19, 533c <fwp_main_thread+0x488>
    5304:	f9401661 	ldr	x1, [x19, #40]
    5308:	b50058a1 	cbnz	x1, 5e1c <fwp_main_thread+0xf68>
    530c:	f9405661 	ldr	x1, [x19, #168]
    5310:	b5005861 	cbnz	x1, 5e1c <fwp_main_thread+0xf68>
    5314:	f9415401 	ldr	x1, [x0, #680]
    5318:	b5005821 	cbnz	x1, 5e1c <fwp_main_thread+0xf68>
    531c:	f9415c00 	ldr	x0, [x0, #696]
    5320:	b50057e0 	cbnz	x0, 5e1c <fwp_main_thread+0xf68>
    5324:	d2823a02 	mov	x2, #0x11d0                	// #4560
    5328:	f0000140 	adrp	x0, 30000 <alt.4+0xfcb0>
    532c:	910d4000 	add	x0, x0, #0x350
    5330:	97fff068 	bl	14d0 <memset@plt>
    5334:	aa1303e0 	mov	x0, x19
    5338:	97fff732 	bl	3000 <fwp_mem_free>
    533c:	9114c2b5 	add	x21, x21, #0x530
    5340:	91014294 	add	x20, x20, #0x50
    5344:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    5348:	f947e800 	ldr	x0, [x0, #4048]
    534c:	52800041 	mov	w1, #0x2                   	// #2
    5350:	fd4a12a0 	ldr	d0, [x21, #5152]
    5354:	b0000002 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    5358:	fd402e81 	ldr	d1, [x20, #88]
    535c:	91300042 	add	x2, x2, #0xc00
    5360:	a9449283 	ldp	x3, x4, [x20, #72]
    5364:	7e61d800 	ucvtf	d0, d0
    5368:	f9400000 	ldr	x0, [x0]
    536c:	f900069f 	str	xzr, [x20, #8]
    5370:	f9416685 	ldr	x5, [x20, #712]
    5374:	1e613801 	fsub	d1, d0, d1
    5378:	fd403280 	ldr	d0, [x20, #96]
    537c:	f900129f 	str	xzr, [x20, #32]
    5380:	b900429f 	str	wzr, [x20, #64]
    5384:	f901729f 	str	xzr, [x20, #736]
    5388:	97fff07a 	bl	1570 <__fprintf_chk@plt>
    538c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    5390:	f947ec00 	ldr	x0, [x0, #4056]
    5394:	f9400000 	ldr	x0, [x0]
    5398:	97fff0a6 	bl	1630 <fflush@plt>
    539c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x175b8>
    53a0:	f947f400 	ldr	x0, [x0, #4072]
    53a4:	f9408fe2 	ldr	x2, [sp, #280]
    53a8:	f9400001 	ldr	x1, [x0]
    53ac:	eb010042 	subs	x2, x2, x1
    53b0:	d2800001 	mov	x1, #0x0                   	// #0
    53b4:	54006201 	b.ne	5ff4 <fwp_main_thread+0x1140>  // b.any
    53b8:	a9527bfd 	ldp	x29, x30, [sp, #288]
    53bc:	d2800000 	mov	x0, #0x0                   	// #0
    53c0:	a95353f3 	ldp	x19, x20, [sp, #304]
    53c4:	a9545bf5 	ldp	x21, x22, [sp, #320]
    53c8:	a95563f7 	ldp	x23, x24, [sp, #336]
    53cc:	a9566bf9 	ldp	x25, x26, [sp, #352]
    53d0:	a95773fb 	ldp	x27, x28, [sp, #368]
    53d4:	910603ff 	add	sp, sp, #0x180
    53d8:	d65f03c0 	ret
    53dc:	97fff53d 	bl	28d0 <fwp_heap_init>
    53e0:	9114c2a0 	add	x0, x21, #0x530
    53e4:	b953a800 	ldr	w0, [x0, #5032]
    53e8:	34ffd8e0 	cbz	w0, 4f04 <fwp_main_thread+0x50>
    53ec:	b0ffffe0 	adrp	x0, 2000 <ad_raw_report+0xf0>
    53f0:	911d9000 	add	x0, x0, #0x764
    53f4:	940004c7 	bl	6710 <atexit>
    53f8:	17fffec3 	b	4f04 <fwp_main_thread+0x50>
    53fc:	d0ffffe0 	adrp	x0, 3000 <fwp_mem_free>
    5400:	91218000 	add	x0, x0, #0x860
    5404:	f9414b42 	ldr	x2, [x26, #656]
    5408:	a90503ff 	stp	xzr, x0, [sp, #80]
    540c:	90ffffe1 	adrp	x1, 1000 <__abi_tag+0xd88>
    5410:	f94007e0 	ldr	x0, [sp, #8]
    5414:	912e4021 	add	x1, x1, #0xb90
    5418:	d2800016 	mov	x22, #0x0                   	// #0
    541c:	d2900019 	mov	x25, #0x8000                	// #32768
    5420:	390043f8 	strb	w24, [sp, #16]
    5424:	d2800018 	mov	x24, #0x0                   	// #0
    5428:	a90287e2 	stp	x2, x1, [sp, #40]
    542c:	a903fff3 	stp	x19, xzr, [sp, #56]
    5430:	f9014b40 	str	x0, [x26, #656]
    5434:	14000012 	b	547c <fwp_main_thread+0x5c8>
    5438:	7100045f 	cmp	w2, #0x1
    543c:	540001a1 	b.ne	5470 <fwp_main_thread+0x5bc>  // b.any
    5440:	29430002 	ldp	w2, w0, [x0, #24]
    5444:	92403c21 	and	x1, x1, #0xffff
    5448:	9b027c21 	mul	x1, x1, x2
    544c:	d360fc21 	lsr	x1, x1, #32
    5450:	eb00003f 	cmp	x1, x0
    5454:	540000e2 	b.cs	5470 <fwp_main_thread+0x5bc>  // b.hs, b.nlast
    5458:	8b01037b 	add	x27, x27, x1
    545c:	39400360 	ldrb	w0, [x27]
    5460:	7103fc1f 	cmp	w0, #0xff
    5464:	54004ae0 	b.eq	5dc0 <fwp_main_thread+0xf0c>  // b.none
    5468:	394043e0 	ldrb	w0, [sp, #16]
    546c:	39000360 	strb	w0, [x27]
    5470:	f90023f6 	str	x22, [sp, #64]
    5474:	aa17035a 	orr	x26, x26, x23
    5478:	b40003da 	cbz	x26, 54f0 <fwp_main_thread+0x63c>
    547c:	f94003e0 	ldr	x0, [sp]
    5480:	f100073a 	subs	x26, x25, #0x1
    5484:	da1f0317 	sbc	x23, x24, xzr
    5488:	f90027fa 	str	x26, [sp, #72]
    548c:	a9085bfa 	stp	x26, x22, [sp, #128]
    5490:	aa1a03f9 	mov	x25, x26
    5494:	97fff87f 	bl	3690 <fwp_data.part.0.constprop.0>
    5498:	f949db81 	ldr	x1, [x28, #5040]
    549c:	aa0003f6 	mov	x22, x0
    54a0:	f949ef80 	ldr	x0, [x28, #5080]
    54a4:	cb0102c1 	sub	x1, x22, x1
    54a8:	aa1703f8 	mov	x24, x23
    54ac:	eb00403f 	cmp	x1, x0, lsl #16
    54b0:	54fffe02 	b.cs	5470 <fwp_main_thread+0x5bc>  // b.hs, b.nlast
    54b4:	d350fc20 	lsr	x0, x1, #16
    54b8:	f949ff85 	ldr	x5, [x28, #5112]
    54bc:	8b000800 	add	x0, x0, x0, lsl #2
    54c0:	d37df002 	lsl	x2, x0, #3
    54c4:	8b0200a0 	add	x0, x5, x2
    54c8:	f940101b 	ldr	x27, [x0, #32]
    54cc:	b4fffd3b 	cbz	x27, 5470 <fwp_main_thread+0x5bc>
    54d0:	386268a2 	ldrb	w2, [x5, x2]
    54d4:	7100085f 	cmp	w2, #0x2
    54d8:	54fffb01 	b.ne	5438 <fwp_main_thread+0x584>  // b.any
    54dc:	72003c3f 	tst	w1, #0xffff
    54e0:	54fffbe0 	b.eq	545c <fwp_main_thread+0x5a8>  // b.none
    54e4:	f90023f6 	str	x22, [sp, #64]
    54e8:	aa17035a 	orr	x26, x26, x23
    54ec:	b5fffc9a 	cbnz	x26, 547c <fwp_main_thread+0x5c8>
    54f0:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    54f4:	91014281 	add	x1, x20, #0x50
    54f8:	f94017e2 	ldr	x2, [sp, #40]
    54fc:	3dc38c00 	ldr	q0, [x0, #3632]
    5500:	910183e0 	add	x0, sp, #0x60
    5504:	f9014822 	str	x2, [x1, #656]
    5508:	3d801be0 	str	q0, [sp, #96]
    550c:	97fff861 	bl	3690 <fwp_data.part.0.constprop.0>
    5510:	9114c2a3 	add	x3, x21, #0x530
    5514:	aa0003f8 	mov	x24, x0
    5518:	f949d862 	ldr	x2, [x3, #5040]
    551c:	f949ec60 	ldr	x0, [x3, #5080]
    5520:	cb020302 	sub	x2, x24, x2
    5524:	eb00405f 	cmp	x2, x0, lsl #16
    5528:	54000322 	b.cs	558c <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    552c:	d350fc41 	lsr	x1, x2, #16
    5530:	f949fc63 	ldr	x3, [x3, #5112]
    5534:	8b010821 	add	x1, x1, x1, lsl #2
    5538:	d37df021 	lsl	x1, x1, #3
    553c:	8b010060 	add	x0, x3, x1
    5540:	f9401019 	ldr	x25, [x0, #32]
    5544:	b4000259 	cbz	x25, 558c <fwp_main_thread+0x6d8>
    5548:	38616861 	ldrb	w1, [x3, x1]
    554c:	7100083f 	cmp	w1, #0x2
    5550:	54004320 	b.eq	5db4 <fwp_main_thread+0xf00>  // b.none
    5554:	7100043f 	cmp	w1, #0x1
    5558:	540001a1 	b.ne	558c <fwp_main_thread+0x6d8>  // b.any
    555c:	29430003 	ldp	w3, w0, [x0, #24]
    5560:	92403c41 	and	x1, x2, #0xffff
    5564:	9b037c21 	mul	x1, x1, x3
    5568:	d360fc21 	lsr	x1, x1, #32
    556c:	eb00003f 	cmp	x1, x0
    5570:	540000e2 	b.cs	558c <fwp_main_thread+0x6d8>  // b.hs, b.nlast
    5574:	8b010339 	add	x25, x25, x1
    5578:	39400320 	ldrb	w0, [x25]
    557c:	7103fc1f 	cmp	w0, #0xff
    5580:	54004f80 	b.eq	5f70 <fwp_main_thread+0x10bc>  // b.none
    5584:	52800020 	mov	w0, #0x1                   	// #1
    5588:	39000320 	strb	w0, [x25]
    558c:	f94003e0 	ldr	x0, [sp]
    5590:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    5594:	a90863e1 	stp	x1, x24, [sp, #128]
    5598:	97fff83e 	bl	3690 <fwp_data.part.0.constprop.0>
    559c:	aa0003f7 	mov	x23, x0
    55a0:	9114c2a3 	add	x3, x21, #0x530
    55a4:	f949d862 	ldr	x2, [x3, #5040]
    55a8:	f949ec60 	ldr	x0, [x3, #5080]
    55ac:	cb0202e2 	sub	x2, x23, x2
    55b0:	eb00405f 	cmp	x2, x0, lsl #16
    55b4:	54000322 	b.cs	5618 <fwp_main_thread+0x764>  // b.hs, b.nlast
    55b8:	d350fc41 	lsr	x1, x2, #16
    55bc:	f949fc63 	ldr	x3, [x3, #5112]
    55c0:	8b010821 	add	x1, x1, x1, lsl #2
    55c4:	d37df021 	lsl	x1, x1, #3
    55c8:	8b010060 	add	x0, x3, x1
    55cc:	f9401018 	ldr	x24, [x0, #32]
    55d0:	b4000258 	cbz	x24, 5618 <fwp_main_thread+0x764>
    55d4:	38616861 	ldrb	w1, [x3, x1]
    55d8:	7100083f 	cmp	w1, #0x2
    55dc:	54003e60 	b.eq	5da8 <fwp_main_thread+0xef4>  // b.none
    55e0:	7100043f 	cmp	w1, #0x1
    55e4:	540001a1 	b.ne	5618 <fwp_main_thread+0x764>  // b.any
    55e8:	29430003 	ldp	w3, w0, [x0, #24]
    55ec:	92403c41 	and	x1, x2, #0xffff
    55f0:	9b037c21 	mul	x1, x1, x3
    55f4:	d360fc21 	lsr	x1, x1, #32
    55f8:	eb00003f 	cmp	x1, x0
    55fc:	540000e2 	b.cs	5618 <fwp_main_thread+0x764>  // b.hs, b.nlast
    5600:	8b010318 	add	x24, x24, x1
    5604:	39400300 	ldrb	w0, [x24]
    5608:	7103fc1f 	cmp	w0, #0xff
    560c:	54004a60 	b.eq	5f58 <fwp_main_thread+0x10a4>  // b.none
    5610:	52800020 	mov	w0, #0x1                   	// #1
    5614:	39000300 	strb	w0, [x24]
    5618:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    561c:	9101c3e0 	add	x0, sp, #0x70
    5620:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    5624:	a9075fe1 	stp	x1, x23, [sp, #112]
    5628:	97fff81a 	bl	3690 <fwp_data.part.0.constprop.0>
    562c:	aa0003fb 	mov	x27, x0
    5630:	9114c2a1 	add	x1, x21, #0x530
    5634:	f949d822 	ldr	x2, [x1, #5040]
    5638:	f949ec20 	ldr	x0, [x1, #5080]
    563c:	cb020362 	sub	x2, x27, x2
    5640:	eb00405f 	cmp	x2, x0, lsl #16
    5644:	54000322 	b.cs	56a8 <fwp_main_thread+0x7f4>  // b.hs, b.nlast
    5648:	d350fc40 	lsr	x0, x2, #16
    564c:	f949fc23 	ldr	x3, [x1, #5112]
    5650:	8b000800 	add	x0, x0, x0, lsl #2
    5654:	d37df001 	lsl	x1, x0, #3
    5658:	8b010060 	add	x0, x3, x1
    565c:	f9401017 	ldr	x23, [x0, #32]
    5660:	b4000257 	cbz	x23, 56a8 <fwp_main_thread+0x7f4>
    5664:	38616861 	ldrb	w1, [x3, x1]
    5668:	7100083f 	cmp	w1, #0x2
    566c:	54003980 	b.eq	5d9c <fwp_main_thread+0xee8>  // b.none
    5670:	7100043f 	cmp	w1, #0x1
    5674:	540001a1 	b.ne	56a8 <fwp_main_thread+0x7f4>  // b.any
    5678:	29430003 	ldp	w3, w0, [x0, #24]
    567c:	92403c41 	and	x1, x2, #0xffff
    5680:	9b037c21 	mul	x1, x1, x3
    5684:	d360fc21 	lsr	x1, x1, #32
    5688:	eb00003f 	cmp	x1, x0
    568c:	540000e2 	b.cs	56a8 <fwp_main_thread+0x7f4>  // b.hs, b.nlast
    5690:	8b0102f7 	add	x23, x23, x1
    5694:	394002e0 	ldrb	w0, [x23]
    5698:	7103fc1f 	cmp	w0, #0xff
    569c:	54004640 	b.eq	5f64 <fwp_main_thread+0x10b0>  // b.none
    56a0:	52800020 	mov	w0, #0x1                   	// #1
    56a4:	390002e0 	strb	w0, [x23]
    56a8:	d00000d8 	adrp	x24, 1f000 <__FRAME_END__+0x175b8>
    56ac:	912ca318 	add	x24, x24, #0xb28
    56b0:	91014300 	add	x0, x24, #0x50
    56b4:	f90003e0 	str	x0, [sp]
    56b8:	f9000bf6 	str	x22, [sp, #16]
    56bc:	b4002af6 	cbz	x22, 5c18 <fwp_main_thread+0xd64>
    56c0:	9114c2a2 	add	x2, x21, #0x530
    56c4:	f949d840 	ldr	x0, [x2, #5040]
    56c8:	f949ec41 	ldr	x1, [x2, #5080]
    56cc:	cb000360 	sub	x0, x27, x0
    56d0:	eb01401f 	cmp	x0, x1, lsl #16
    56d4:	54000402 	b.cs	5754 <fwp_main_thread+0x8a0>  // b.hs, b.nlast
    56d8:	d350fc01 	lsr	x1, x0, #16
    56dc:	f949fc43 	ldr	x3, [x2, #5112]
    56e0:	8b010821 	add	x1, x1, x1, lsl #2
    56e4:	d37df021 	lsl	x1, x1, #3
    56e8:	8b010062 	add	x2, x3, x1
    56ec:	f9401057 	ldr	x23, [x2, #32]
    56f0:	b4000337 	cbz	x23, 5754 <fwp_main_thread+0x8a0>
    56f4:	38616861 	ldrb	w1, [x3, x1]
    56f8:	7100083f 	cmp	w1, #0x2
    56fc:	54003100 	b.eq	5d1c <fwp_main_thread+0xe68>  // b.none
    5700:	7100043f 	cmp	w1, #0x1
    5704:	54000281 	b.ne	5754 <fwp_main_thread+0x8a0>  // b.any
    5708:	29430443 	ldp	w3, w1, [x2, #24]
    570c:	92403c00 	and	x0, x0, #0xffff
    5710:	9b037c00 	mul	x0, x0, x3
    5714:	d360fc00 	lsr	x0, x0, #32
    5718:	eb01001f 	cmp	x0, x1
    571c:	540001c2 	b.cs	5754 <fwp_main_thread+0x8a0>  // b.hs, b.nlast
    5720:	8b0002f7 	add	x23, x23, x0
    5724:	394002e0 	ldrb	w0, [x23]
    5728:	34000160 	cbz	w0, 5754 <fwp_main_thread+0x8a0>
    572c:	91014281 	add	x1, x20, #0x50
    5730:	b9404022 	ldr	w2, [x1, #64]
    5734:	34000082 	cbz	w2, 5744 <fwp_main_thread+0x890>
    5738:	f9416422 	ldr	x2, [x1, #712]
    573c:	91000442 	add	x2, x2, #0x1
    5740:	f9016422 	str	x2, [x1, #712]
    5744:	7103f41f 	cmp	w0, #0xfd
    5748:	54003988 	b.hi	5e78 <fwp_main_thread+0xfc4>  // b.pmore
    574c:	11000400 	add	w0, w0, #0x1
    5750:	390002e0 	strb	w0, [x23]
    5754:	b4002ebb 	cbz	x27, 5d28 <fwp_main_thread+0xe74>
    5758:	aa1b03e1 	mov	x1, x27
    575c:	d2800000 	mov	x0, #0x0                   	// #0
    5760:	f9400821 	ldr	x1, [x1, #16]
    5764:	91000400 	add	x0, x0, #0x1
    5768:	b5ffffc1 	cbnz	x1, 5760 <fwp_main_thread+0x8ac>
    576c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    5770:	eb01001f 	cmp	x0, x1
    5774:	54004488 	b.hi	6004 <fwp_main_thread+0x1150>  // b.pmore
    5778:	97fff826 	bl	3810 <fwp_array_new_packed.constprop.0>
    577c:	aa0003fc 	mov	x28, x0
    5780:	9114c2a1 	add	x1, x21, #0x530
    5784:	aa0103e0 	mov	x0, x1
    5788:	f949d821 	ldr	x1, [x1, #5040]
    578c:	f949ec00 	ldr	x0, [x0, #5080]
    5790:	cb010381 	sub	x1, x28, x1
    5794:	eb00403f 	cmp	x1, x0, lsl #16
    5798:	54000362 	b.cs	5804 <fwp_main_thread+0x950>  // b.hs, b.nlast
    579c:	9114c2a2 	add	x2, x21, #0x530
    57a0:	d350fc20 	lsr	x0, x1, #16
    57a4:	8b000800 	add	x0, x0, x0, lsl #2
    57a8:	f949fc43 	ldr	x3, [x2, #5112]
    57ac:	d37df002 	lsl	x2, x0, #3
    57b0:	8b020060 	add	x0, x3, x2
    57b4:	f9401017 	ldr	x23, [x0, #32]
    57b8:	b4000257 	cbz	x23, 5800 <fwp_main_thread+0x94c>
    57bc:	38626862 	ldrb	w2, [x3, x2]
    57c0:	7100085f 	cmp	w2, #0x2
    57c4:	54002ca0 	b.eq	5d58 <fwp_main_thread+0xea4>  // b.none
    57c8:	7100045f 	cmp	w2, #0x1
    57cc:	540001a1 	b.ne	5800 <fwp_main_thread+0x94c>  // b.any
    57d0:	29430002 	ldp	w2, w0, [x0, #24]
    57d4:	92403c21 	and	x1, x1, #0xffff
    57d8:	9b027c21 	mul	x1, x1, x2
    57dc:	d360fc21 	lsr	x1, x1, #32
    57e0:	eb00003f 	cmp	x1, x0
    57e4:	540000e2 	b.cs	5800 <fwp_main_thread+0x94c>  // b.hs, b.nlast
    57e8:	8b0102f7 	add	x23, x23, x1
    57ec:	394002e0 	ldrb	w0, [x23]
    57f0:	7103fc1f 	cmp	w0, #0xff
    57f4:	54002f20 	b.eq	5dd8 <fwp_main_thread+0xf24>  // b.none
    57f8:	52800020 	mov	w0, #0x1                   	// #1
    57fc:	390002e0 	strb	w0, [x23]
    5800:	b4002a9b 	cbz	x27, 5d50 <fwp_main_thread+0xe9c>
    5804:	91002399 	add	x25, x28, #0x8
    5808:	aa1b03e0 	mov	x0, x27
    580c:	aa1b03f7 	mov	x23, x27
    5810:	9114c2ba 	add	x26, x21, #0x530
    5814:	52800038 	mov	w24, #0x1                   	// #1
    5818:	14000014 	b	5868 <fwp_main_thread+0x9b4>
    581c:	7100045f 	cmp	w2, #0x1
    5820:	54000181 	b.ne	5850 <fwp_main_thread+0x99c>  // b.any
    5824:	2943092a 	ldp	w10, w2, [x9, #24]
    5828:	92403c21 	and	x1, x1, #0xffff
    582c:	9b0a7c21 	mul	x1, x1, x10
    5830:	d360fc21 	lsr	x1, x1, #32
    5834:	eb02003f 	cmp	x1, x2
    5838:	540000c2 	b.cs	5850 <fwp_main_thread+0x99c>  // b.hs, b.nlast
    583c:	8b010108 	add	x8, x8, x1
    5840:	39400101 	ldrb	w1, [x8]
    5844:	7100043f 	cmp	w1, #0x1
    5848:	54000400 	b.eq	58c8 <fwp_main_thread+0xa14>  // b.none
    584c:	d503201f 	nop
    5850:	f9400381 	ldr	x1, [x28]
    5854:	b7f83b01 	tbnz	x1, #63, 5fb4 <fwp_main_thread+0x1100>
    5858:	f9000326 	str	x6, [x25]
    585c:	52800018 	mov	w24, #0x0                   	// #0
    5860:	91002339 	add	x25, x25, #0x8
    5864:	b4000777 	cbz	x23, 5950 <fwp_main_thread+0xa9c>
    5868:	aa1703e7 	mov	x7, x23
    586c:	aa1703e3 	mov	x3, x23
    5870:	a940dee6 	ldp	x6, x23, [x23, #8]
    5874:	34fffef8 	cbz	w24, 5850 <fwp_main_thread+0x99c>
    5878:	f949db41 	ldr	x1, [x26, #5040]
    587c:	f949ef42 	ldr	x2, [x26, #5080]
    5880:	cb0100e1 	sub	x1, x7, x1
    5884:	eb02403f 	cmp	x1, x2, lsl #16
    5888:	54fffe42 	b.cs	5850 <fwp_main_thread+0x99c>  // b.hs, b.nlast
    588c:	d350fc22 	lsr	x2, x1, #16
    5890:	f949ff4a 	ldr	x10, [x26, #5112]
    5894:	8b020842 	add	x2, x2, x2, lsl #2
    5898:	d37df042 	lsl	x2, x2, #3
    589c:	8b020149 	add	x9, x10, x2
    58a0:	f9401128 	ldr	x8, [x9, #32]
    58a4:	b4fffd68 	cbz	x8, 5850 <fwp_main_thread+0x99c>
    58a8:	38626942 	ldrb	w2, [x10, x2]
    58ac:	7100085f 	cmp	w2, #0x2
    58b0:	54fffb61 	b.ne	581c <fwp_main_thread+0x968>  // b.any
    58b4:	72003c3f 	tst	w1, #0xffff
    58b8:	54fffcc1 	b.ne	5850 <fwp_main_thread+0x99c>  // b.any
    58bc:	39400101 	ldrb	w1, [x8]
    58c0:	7100043f 	cmp	w1, #0x1
    58c4:	54fffc61 	b.ne	5850 <fwp_main_thread+0x99c>  // b.any
    58c8:	f9400380 	ldr	x0, [x28]
    58cc:	b7f83740 	tbnz	x0, #63, 5fb4 <fwp_main_thread+0x1100>
    58d0:	f9000326 	str	x6, [x25]
    58d4:	f949db41 	ldr	x1, [x26, #5040]
    58d8:	f949ef40 	ldr	x0, [x26, #5080]
    58dc:	cb010063 	sub	x3, x3, x1
    58e0:	eb00407f 	cmp	x3, x0, lsl #16
    58e4:	540002e2 	b.cs	5940 <fwp_main_thread+0xa8c>  // b.hs, b.nlast
    58e8:	d350fc60 	lsr	x0, x3, #16
    58ec:	f949ff41 	ldr	x1, [x26, #5112]
    58f0:	8b000800 	add	x0, x0, x0, lsl #2
    58f4:	d37df000 	lsl	x0, x0, #3
    58f8:	8b000026 	add	x6, x1, x0
    58fc:	f94010c2 	ldr	x2, [x6, #32]
    5900:	b4000202 	cbz	x2, 5940 <fwp_main_thread+0xa8c>
    5904:	38606820 	ldrb	w0, [x1, x0]
    5908:	7100081f 	cmp	w0, #0x2
    590c:	54001e00 	b.eq	5ccc <fwp_main_thread+0xe18>  // b.none
    5910:	7100041f 	cmp	w0, #0x1
    5914:	54000161 	b.ne	5940 <fwp_main_thread+0xa8c>  // b.any
    5918:	294300c8 	ldp	w8, w0, [x6, #24]
    591c:	92403c61 	and	x1, x3, #0xffff
    5920:	9b087c21 	mul	x1, x1, x8
    5924:	d360fc21 	lsr	x1, x1, #32
    5928:	eb00003f 	cmp	x1, x0
    592c:	540000a2 	b.cs	5940 <fwp_main_thread+0xa8c>  // b.hs, b.nlast
    5930:	8b010042 	add	x2, x2, x1
    5934:	39400040 	ldrb	w0, [x2]
    5938:	7100041f 	cmp	w0, #0x1
    593c:	54001800 	b.eq	5c3c <fwp_main_thread+0xd88>  // b.none
    5940:	aa1703e0 	mov	x0, x23
    5944:	d503201f 	nop
    5948:	91002339 	add	x25, x25, #0x8
    594c:	b5fff8f7 	cbnz	x23, 5868 <fwp_main_thread+0x9b4>
    5950:	97fff818 	bl	39b0 <fwp_drop0>
    5954:	a9047fff 	stp	xzr, xzr, [sp, #64]
    5958:	52800b63 	mov	w3, #0x5b                  	// #91
    595c:	f94007e1 	ldr	x1, [sp, #8]
    5960:	aa1303e0 	mov	x0, x19
    5964:	d2800022 	mov	x2, #0x1                   	// #1
    5968:	3900a3e3 	strb	w3, [sp, #40]
    596c:	f9002bff 	str	xzr, [sp, #80]
    5970:	b0000017 	adrp	x23, 6000 <fwp_main_thread+0x114c>
    5974:	97fff1e7 	bl	2110 <buf_put>
    5978:	9100239a 	add	x26, x28, #0x8
    597c:	f9400380 	ldr	x0, [x28]
    5980:	912ba2f7 	add	x23, x23, #0xae8
    5984:	d2800018 	mov	x24, #0x0                   	// #0
    5988:	f240f819 	ands	x25, x0, #0x7fffffffffffffff
    598c:	540001c1 	b.ne	59c4 <fwp_main_thread+0xb10>  // b.any
    5990:	14000017 	b	59ec <fwp_main_thread+0xb38>
    5994:	f8787821 	ldr	x1, [x1, x24, lsl #3]
    5998:	aa1303e0 	mov	x0, x19
    599c:	f94003e2 	ldr	x2, [sp]
    59a0:	91000718 	add	x24, x24, #0x1
    59a4:	97fff95b 	bl	3f10 <fwp_write.constprop.0>
    59a8:	eb18033f 	cmp	x25, x24
    59ac:	54000200 	b.eq	59ec <fwp_main_thread+0xb38>  // b.none
    59b0:	aa1303e0 	mov	x0, x19
    59b4:	aa1703e1 	mov	x1, x23
    59b8:	d2800042 	mov	x2, #0x2                   	// #2
    59bc:	97fff1d5 	bl	2110 <buf_put>
    59c0:	f9400380 	ldr	x0, [x28]
    59c4:	aa1a03e1 	mov	x1, x26
    59c8:	b6fffe60 	tbz	x0, #63, 5994 <fwp_main_thread+0xae0>
    59cc:	f9400b81 	ldr	x1, [x28, #16]
    59d0:	aa1303e0 	mov	x0, x19
    59d4:	f94003e2 	ldr	x2, [sp]
    59d8:	f8787821 	ldr	x1, [x1, x24, lsl #3]
    59dc:	91000718 	add	x24, x24, #0x1
    59e0:	97fff94c 	bl	3f10 <fwp_write.constprop.0>
    59e4:	eb18033f 	cmp	x25, x24
    59e8:	54fffe41 	b.ne	59b0 <fwp_main_thread+0xafc>  // b.any
    59ec:	f94007e1 	ldr	x1, [sp, #8]
    59f0:	52800ba3 	mov	w3, #0x5d                  	// #93
    59f4:	aa1303e0 	mov	x0, x19
    59f8:	d2800022 	mov	x2, #0x1                   	// #1
    59fc:	3900a3e3 	strb	w3, [sp, #40]
    5a00:	97fff1c4 	bl	2110 <buf_put>
    5a04:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5a08:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    5a0c:	911e0000 	add	x0, x0, #0x780
    5a10:	f100033f 	cmp	x25, #0x0
    5a14:	9a990019 	csel	x25, x0, x25, eq	// eq = none
    5a18:	b1002b5f 	cmn	x26, #0xa
    5a1c:	54002e08 	b.hi	5fdc <fwp_main_thread+0x1128>  // b.pmore
    5a20:	91002740 	add	x0, x26, #0x9
    5a24:	52800021 	mov	w1, #0x1                   	// #1
    5a28:	97fff6b7 	bl	3504 <fwp_heap_alloc>
    5a2c:	aa0003f7 	mov	x23, x0
    5a30:	aa1903e1 	mov	x1, x25
    5a34:	aa0003f9 	mov	x25, x0
    5a38:	aa1a03e2 	mov	x2, x26
    5a3c:	f800873a 	str	x26, [x25], #8
    5a40:	8b1a02fa 	add	x26, x23, x26
    5a44:	aa1903e0 	mov	x0, x25
    5a48:	97ffee46 	bl	1360 <memcpy@plt>
    5a4c:	3900235f 	strb	wzr, [x26, #8]
    5a50:	f94023e0 	ldr	x0, [sp, #64]
    5a54:	97ffeedb 	bl	15c0 <free@plt>
    5a58:	9114c2a2 	add	x2, x21, #0x530
    5a5c:	f949ec43 	ldr	x3, [x2, #5080]
    5a60:	f949d841 	ldr	x1, [x2, #5040]
    5a64:	d370bc63 	lsl	x3, x3, #16
    5a68:	cb0102e5 	sub	x5, x23, x1
    5a6c:	eb0300bf 	cmp	x5, x3
    5a70:	540003a2 	b.cs	5ae4 <fwp_main_thread+0xc30>  // b.hs, b.nlast
    5a74:	d350fca0 	lsr	x0, x5, #16
    5a78:	f949fc46 	ldr	x6, [x2, #5112]
    5a7c:	8b000800 	add	x0, x0, x0, lsl #2
    5a80:	d37df002 	lsl	x2, x0, #3
    5a84:	8b0200c0 	add	x0, x6, x2
    5a88:	f940101a 	ldr	x26, [x0, #32]
    5a8c:	b40002da 	cbz	x26, 5ae4 <fwp_main_thread+0xc30>
    5a90:	386268c2 	ldrb	w2, [x6, x2]
    5a94:	7100085f 	cmp	w2, #0x2
    5a98:	54001660 	b.eq	5d64 <fwp_main_thread+0xeb0>  // b.none
    5a9c:	7100045f 	cmp	w2, #0x1
    5aa0:	54000221 	b.ne	5ae4 <fwp_main_thread+0xc30>  // b.any
    5aa4:	29430006 	ldp	w6, w0, [x0, #24]
    5aa8:	92403ca2 	and	x2, x5, #0xffff
    5aac:	9b067c42 	mul	x2, x2, x6
    5ab0:	d360fc42 	lsr	x2, x2, #32
    5ab4:	eb00005f 	cmp	x2, x0
    5ab8:	54000162 	b.cs	5ae4 <fwp_main_thread+0xc30>  // b.hs, b.nlast
    5abc:	8b02035a 	add	x26, x26, x2
    5ac0:	39400340 	ldrb	w0, [x26]
    5ac4:	7103fc1f 	cmp	w0, #0xff
    5ac8:	540018e0 	b.eq	5de4 <fwp_main_thread+0xf30>  // b.none
    5acc:	9114c2a0 	add	x0, x21, #0x530
    5ad0:	52800021 	mov	w1, #0x1                   	// #1
    5ad4:	39000341 	strb	w1, [x26]
    5ad8:	f949ec03 	ldr	x3, [x0, #5080]
    5adc:	f949d801 	ldr	x1, [x0, #5040]
    5ae0:	d370bc63 	lsl	x3, x3, #16
    5ae4:	cb010381 	sub	x1, x28, x1
    5ae8:	9114c2a5 	add	x5, x21, #0x530
    5aec:	eb03003f 	cmp	x1, x3
    5af0:	54000382 	b.cs	5b60 <fwp_main_thread+0xcac>  // b.hs, b.nlast
    5af4:	d350fc20 	lsr	x0, x1, #16
    5af8:	f949fca3 	ldr	x3, [x5, #5112]
    5afc:	8b000800 	add	x0, x0, x0, lsl #2
    5b00:	d37df002 	lsl	x2, x0, #3
    5b04:	8b020060 	add	x0, x3, x2
    5b08:	f940101a 	ldr	x26, [x0, #32]
    5b0c:	b40002ba 	cbz	x26, 5b60 <fwp_main_thread+0xcac>
    5b10:	38626862 	ldrb	w2, [x3, x2]
    5b14:	7100085f 	cmp	w2, #0x2
    5b18:	54000e20 	b.eq	5cdc <fwp_main_thread+0xe28>  // b.none
    5b1c:	7100045f 	cmp	w2, #0x1
    5b20:	54000201 	b.ne	5b60 <fwp_main_thread+0xcac>  // b.any
    5b24:	29430002 	ldp	w2, w0, [x0, #24]
    5b28:	92403c21 	and	x1, x1, #0xffff
    5b2c:	9b027c21 	mul	x1, x1, x2
    5b30:	d360fc21 	lsr	x1, x1, #32
    5b34:	eb00003f 	cmp	x1, x0
    5b38:	54000142 	b.cs	5b60 <fwp_main_thread+0xcac>  // b.hs, b.nlast
    5b3c:	8b01035a 	add	x26, x26, x1
    5b40:	39400340 	ldrb	w0, [x26]
    5b44:	340000e0 	cbz	w0, 5b60 <fwp_main_thread+0xcac>
    5b48:	7100041f 	cmp	w0, #0x1
    5b4c:	54000800 	b.eq	5c4c <fwp_main_thread+0xd98>  // b.none
    5b50:	7103fc1f 	cmp	w0, #0xff
    5b54:	54001660 	b.eq	5e20 <fwp_main_thread+0xf6c>  // b.none
    5b58:	51000400 	sub	w0, w0, #0x1
    5b5c:	39000340 	strb	w0, [x26]
    5b60:	f94002e2 	ldr	x2, [x23]
    5b64:	d2800021 	mov	x1, #0x1                   	// #1
    5b68:	f9402a83 	ldr	x3, [x20, #80]
    5b6c:	aa1903e0 	mov	x0, x25
    5b70:	97ffeea4 	bl	1600 <fwrite@plt>
    5b74:	f9402a81 	ldr	x1, [x20, #80]
    5b78:	52800140 	mov	w0, #0xa                   	// #10
    5b7c:	97ffee29 	bl	1420 <fputc@plt>
    5b80:	9114c2a2 	add	x2, x21, #0x530
    5b84:	f949d841 	ldr	x1, [x2, #5040]
    5b88:	f949ec40 	ldr	x0, [x2, #5080]
    5b8c:	cb0102e1 	sub	x1, x23, x1
    5b90:	eb00403f 	cmp	x1, x0, lsl #16
    5b94:	540003a2 	b.cs	5c08 <fwp_main_thread+0xd54>  // b.hs, b.nlast
    5b98:	d350fc20 	lsr	x0, x1, #16
    5b9c:	f949fc43 	ldr	x3, [x2, #5112]
    5ba0:	8b000800 	add	x0, x0, x0, lsl #2
    5ba4:	d37df002 	lsl	x2, x0, #3
    5ba8:	8b020060 	add	x0, x3, x2
    5bac:	f9401019 	ldr	x25, [x0, #32]
    5bb0:	b40002d9 	cbz	x25, 5c08 <fwp_main_thread+0xd54>
    5bb4:	38626862 	ldrb	w2, [x3, x2]
    5bb8:	7100085f 	cmp	w2, #0x2
    5bbc:	54000da0 	b.eq	5d70 <fwp_main_thread+0xebc>  // b.none
    5bc0:	7100045f 	cmp	w2, #0x1
    5bc4:	54000221 	b.ne	5c08 <fwp_main_thread+0xd54>  // b.any
    5bc8:	29430002 	ldp	w2, w0, [x0, #24]
    5bcc:	92403c21 	and	x1, x1, #0xffff
    5bd0:	9b027c21 	mul	x1, x1, x2
    5bd4:	d360fc21 	lsr	x1, x1, #32
    5bd8:	eb00003f 	cmp	x1, x0
    5bdc:	54000162 	b.cs	5c08 <fwp_main_thread+0xd54>  // b.hs, b.nlast
    5be0:	8b010339 	add	x25, x25, x1
    5be4:	39400320 	ldrb	w0, [x25]
    5be8:	34000100 	cbz	w0, 5c08 <fwp_main_thread+0xd54>
    5bec:	7100041f 	cmp	w0, #0x1
    5bf0:	54000d00 	b.eq	5d90 <fwp_main_thread+0xedc>  // b.none
    5bf4:	7103fc1f 	cmp	w0, #0xff
    5bf8:	54001740 	b.eq	5ee0 <fwp_main_thread+0x102c>  // b.none
    5bfc:	51000400 	sub	w0, w0, #0x1
    5c00:	39000320 	strb	w0, [x25]
    5c04:	d503201f 	nop
    5c08:	f9400be0 	ldr	x0, [sp, #16]
    5c0c:	f9400800 	ldr	x0, [x0, #16]
    5c10:	f9000be0 	str	x0, [sp, #16]
    5c14:	b5ffd560 	cbnz	x0, 56c0 <fwp_main_thread+0x80c>
    5c18:	aa1b03e0 	mov	x0, x27
    5c1c:	97fff765 	bl	39b0 <fwp_drop0>
    5c20:	aa1603e0 	mov	x0, x22
    5c24:	97fff763 	bl	39b0 <fwp_drop0>
    5c28:	91014280 	add	x0, x20, #0x50
    5c2c:	52800021 	mov	w1, #0x1                   	// #1
    5c30:	b902c401 	str	w1, [x0, #708]
    5c34:	f901681f 	str	xzr, [x0, #720]
    5c38:	17fffceb 	b	4fe4 <fwp_main_thread+0x130>
    5c3c:	aa0703e0 	mov	x0, x7
    5c40:	97fff4f0 	bl	3000 <fwp_mem_free>
    5c44:	aa1703e0 	mov	x0, x23
    5c48:	17ffff40 	b	5948 <fwp_main_thread+0xa94>
    5c4c:	f9400380 	ldr	x0, [x28]
    5c50:	b7f804c0 	tbnz	x0, #63, 5ce8 <fwp_main_thread+0xe34>
    5c54:	9114c2a1 	add	x1, x21, #0x530
    5c58:	f949d820 	ldr	x0, [x1, #5040]
    5c5c:	f949ec21 	ldr	x1, [x1, #5080]
    5c60:	cb000380 	sub	x0, x28, x0
    5c64:	eb01401f 	cmp	x0, x1, lsl #16
    5c68:	54fff7c2 	b.cs	5b60 <fwp_main_thread+0xcac>  // b.hs, b.nlast
    5c6c:	d350fc01 	lsr	x1, x0, #16
    5c70:	8b010821 	add	x1, x1, x1, lsl #2
    5c74:	d37df021 	lsl	x1, x1, #3
    5c78:	8b010065 	add	x5, x3, x1
    5c7c:	f94010a2 	ldr	x2, [x5, #32]
    5c80:	b4fff702 	cbz	x2, 5b60 <fwp_main_thread+0xcac>
    5c84:	38616861 	ldrb	w1, [x3, x1]
    5c88:	7100083f 	cmp	w1, #0x2
    5c8c:	540007c0 	b.eq	5d84 <fwp_main_thread+0xed0>  // b.none
    5c90:	7100043f 	cmp	w1, #0x1
    5c94:	54fff661 	b.ne	5b60 <fwp_main_thread+0xcac>  // b.any
    5c98:	294304a3 	ldp	w3, w1, [x5, #24]
    5c9c:	92403c00 	and	x0, x0, #0xffff
    5ca0:	9b037c00 	mul	x0, x0, x3
    5ca4:	d360fc00 	lsr	x0, x0, #32
    5ca8:	eb01001f 	cmp	x0, x1
    5cac:	54fff5a2 	b.cs	5b60 <fwp_main_thread+0xcac>  // b.hs, b.nlast
    5cb0:	8b000042 	add	x2, x2, x0
    5cb4:	39400040 	ldrb	w0, [x2]
    5cb8:	7100041f 	cmp	w0, #0x1
    5cbc:	54fff521 	b.ne	5b60 <fwp_main_thread+0xcac>  // b.any
    5cc0:	aa1c03e0 	mov	x0, x28
    5cc4:	97fff4cf 	bl	3000 <fwp_mem_free>
    5cc8:	17ffffa6 	b	5b60 <fwp_main_thread+0xcac>
    5ccc:	72003c7f 	tst	w3, #0xffff
    5cd0:	54ffe320 	b.eq	5934 <fwp_main_thread+0xa80>  // b.none
    5cd4:	aa1703e0 	mov	x0, x23
    5cd8:	17ffff1c 	b	5948 <fwp_main_thread+0xa94>
    5cdc:	72003c3f 	tst	w1, #0xffff
    5ce0:	54fff401 	b.ne	5b60 <fwp_main_thread+0xcac>  // b.any
    5ce4:	17ffff97 	b	5b40 <fwp_main_thread+0xc8c>
    5ce8:	f940079a 	ldr	x26, [x28, #8]
    5cec:	aa1c03e0 	mov	x0, x28
    5cf0:	f9000fe5 	str	x5, [sp, #24]
    5cf4:	97fff5e3 	bl	3480 <fwp_rc_free_arr>
    5cf8:	9114c2a0 	add	x0, x21, #0x530
    5cfc:	f949d801 	ldr	x1, [x0, #5040]
    5d00:	f949ec00 	ldr	x0, [x0, #5080]
    5d04:	cb010341 	sub	x1, x26, x1
    5d08:	eb00403f 	cmp	x1, x0, lsl #16
    5d0c:	54fff2a2 	b.cs	5b60 <fwp_main_thread+0xcac>  // b.hs, b.nlast
    5d10:	f9400fe5 	ldr	x5, [sp, #24]
    5d14:	aa1a03fc 	mov	x28, x26
    5d18:	17ffff77 	b	5af4 <fwp_main_thread+0xc40>
    5d1c:	72003c1f 	tst	w0, #0xffff
    5d20:	54ffd020 	b.eq	5724 <fwp_main_thread+0x870>  // b.none
    5d24:	b5ffd1bb 	cbnz	x27, 5758 <fwp_main_thread+0x8a4>
    5d28:	d2800000 	mov	x0, #0x0                   	// #0
    5d2c:	97fff6b9 	bl	3810 <fwp_array_new_packed.constprop.0>
    5d30:	9114c2a1 	add	x1, x21, #0x530
    5d34:	aa0003fc 	mov	x28, x0
    5d38:	aa0103e0 	mov	x0, x1
    5d3c:	f949d821 	ldr	x1, [x1, #5040]
    5d40:	f949ec00 	ldr	x0, [x0, #5080]
    5d44:	cb010381 	sub	x1, x28, x1
    5d48:	eb00403f 	cmp	x1, x0, lsl #16
    5d4c:	54ffd283 	b.cc	579c <fwp_main_thread+0x8e8>  // b.lo, b.ul, b.last
    5d50:	d2800000 	mov	x0, #0x0                   	// #0
    5d54:	17fffeff 	b	5950 <fwp_main_thread+0xa9c>
    5d58:	72003c3f 	tst	w1, #0xffff
    5d5c:	54ffd521 	b.ne	5800 <fwp_main_thread+0x94c>  // b.any
    5d60:	17fffea3 	b	57ec <fwp_main_thread+0x938>
    5d64:	72003cbf 	tst	w5, #0xffff
    5d68:	54ffebe1 	b.ne	5ae4 <fwp_main_thread+0xc30>  // b.any
    5d6c:	17ffff55 	b	5ac0 <fwp_main_thread+0xc0c>
    5d70:	72003c3f 	tst	w1, #0xffff
    5d74:	54fff4a1 	b.ne	5c08 <fwp_main_thread+0xd54>  // b.any
    5d78:	39400320 	ldrb	w0, [x25]
    5d7c:	35fff380 	cbnz	w0, 5bec <fwp_main_thread+0xd38>
    5d80:	17ffffa2 	b	5c08 <fwp_main_thread+0xd54>
    5d84:	72003c1f 	tst	w0, #0xffff
    5d88:	54ffeec1 	b.ne	5b60 <fwp_main_thread+0xcac>  // b.any
    5d8c:	17ffffca 	b	5cb4 <fwp_main_thread+0xe00>
    5d90:	aa1703e0 	mov	x0, x23
    5d94:	97fff49b 	bl	3000 <fwp_mem_free>
    5d98:	17ffff9c 	b	5c08 <fwp_main_thread+0xd54>
    5d9c:	72003c5f 	tst	w2, #0xffff
    5da0:	54ffc841 	b.ne	56a8 <fwp_main_thread+0x7f4>  // b.any
    5da4:	17fffe3c 	b	5694 <fwp_main_thread+0x7e0>
    5da8:	72003c5f 	tst	w2, #0xffff
    5dac:	54ffc361 	b.ne	5618 <fwp_main_thread+0x764>  // b.any
    5db0:	17fffe15 	b	5604 <fwp_main_thread+0x750>
    5db4:	72003c5f 	tst	w2, #0xffff
    5db8:	54ffbea1 	b.ne	558c <fwp_main_thread+0x6d8>  // b.any
    5dbc:	17fffdef 	b	5578 <fwp_main_thread+0x6c4>
    5dc0:	aa1b03e0 	mov	x0, x27
    5dc4:	97fff3f0 	bl	2d84 <fwp_rc_forget_slot>
    5dc8:	17fffda8 	b	5468 <fwp_main_thread+0x5b4>
    5dcc:	aa0003e1 	mov	x1, x0
    5dd0:	f90022d3 	str	x19, [x22, #64]
    5dd4:	17fffc9c 	b	5044 <fwp_main_thread+0x190>
    5dd8:	aa1703e0 	mov	x0, x23
    5ddc:	97fff3ea 	bl	2d84 <fwp_rc_forget_slot>
    5de0:	17fffe86 	b	57f8 <fwp_main_thread+0x944>
    5de4:	aa1a03e0 	mov	x0, x26
    5de8:	97fff3e7 	bl	2d84 <fwp_rc_forget_slot>
    5dec:	17ffff38 	b	5acc <fwp_main_thread+0xc18>
    5df0:	f94152c0 	ldr	x0, [x22, #672]
    5df4:	97fff483 	bl	3000 <fwp_mem_free>
    5df8:	f90152df 	str	xzr, [x22, #672]
    5dfc:	f9015adf 	str	xzr, [x22, #688]
    5e00:	f94172c0 	ldr	x0, [x22, #736]
    5e04:	b4000a53 	cbz	x19, 5f4c <fwp_main_thread+0x1098>
    5e08:	f900567f 	str	xzr, [x19, #168]
    5e0c:	f9005e7f 	str	xzr, [x19, #184]
    5e10:	b902dadf 	str	wzr, [x22, #728]
    5e14:	eb13001f 	cmp	x0, x19
    5e18:	54ff9740 	b.eq	5100 <fwp_main_thread+0x24c>  // b.none
    5e1c:	97ffedcd 	bl	1550 <abort@plt>
    5e20:	ca5a4740 	eor	x0, x26, x26, lsr #17
    5e24:	9114c2a1 	add	x1, x21, #0x530
    5e28:	ca402400 	eor	x0, x0, x0, lsr #9
    5e2c:	8b200c20 	add	x0, x1, w0, uxtb #3
    5e30:	f94a2400 	ldr	x0, [x0, #5192]
    5e34:	b5000080 	cbnz	x0, 5e44 <fwp_main_thread+0xf90>
    5e38:	14000042 	b	5f40 <fwp_main_thread+0x108c>
    5e3c:	f9400800 	ldr	x0, [x0, #16]
    5e40:	b4000800 	cbz	x0, 5f40 <fwp_main_thread+0x108c>
    5e44:	f9400001 	ldr	x1, [x0]
    5e48:	eb01035f 	cmp	x26, x1
    5e4c:	54ffff81 	b.ne	5e3c <fwp_main_thread+0xf88>  // b.any
    5e50:	f9400401 	ldr	x1, [x0, #8]
    5e54:	d1000421 	sub	x1, x1, #0x1
    5e58:	f9000401 	str	x1, [x0, #8]
    5e5c:	f103f83f 	cmp	x1, #0xfe
    5e60:	54ffe801 	b.ne	5b60 <fwp_main_thread+0xcac>  // b.any
    5e64:	aa1a03e0 	mov	x0, x26
    5e68:	97fff3c7 	bl	2d84 <fwp_rc_forget_slot>
    5e6c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e70:	39000340 	strb	w0, [x26]
    5e74:	17ffff3b 	b	5b60 <fwp_main_thread+0xcac>
    5e78:	ca5746e1 	eor	x1, x23, x23, lsr #17
    5e7c:	9114c2a2 	add	x2, x21, #0x530
    5e80:	ca412421 	eor	x1, x1, x1, lsr #9
    5e84:	92401c21 	and	x1, x1, #0xff
    5e88:	910a2423 	add	x3, x1, #0x289
    5e8c:	8b010c41 	add	x1, x2, x1, lsl #3
    5e90:	8b030c59 	add	x25, x2, x3, lsl #3
    5e94:	f94a2421 	ldr	x1, [x1, #5192]
    5e98:	b50000a1 	cbnz	x1, 5eac <fwp_main_thread+0xff8>
    5e9c:	14000054 	b	5fec <fwp_main_thread+0x1138>
    5ea0:	91004039 	add	x25, x1, #0x10
    5ea4:	f9400821 	ldr	x1, [x1, #16]
    5ea8:	b4000481 	cbz	x1, 5f38 <fwp_main_thread+0x1084>
    5eac:	f9400022 	ldr	x2, [x1]
    5eb0:	eb17005f 	cmp	x2, x23
    5eb4:	54ffff61 	b.ne	5ea0 <fwp_main_thread+0xfec>  // b.any
    5eb8:	f9400321 	ldr	x1, [x25]
    5ebc:	7103f81f 	cmp	w0, #0xfe
    5ec0:	54000800 	b.eq	5fc0 <fwp_main_thread+0x110c>  // b.none
    5ec4:	b40003e1 	cbz	x1, 5f40 <fwp_main_thread+0x108c>
    5ec8:	f9400420 	ldr	x0, [x1, #8]
    5ecc:	b100041f 	cmn	x0, #0x1
    5ed0:	54000800 	b.eq	5fd0 <fwp_main_thread+0x111c>  // b.none
    5ed4:	91000400 	add	x0, x0, #0x1
    5ed8:	f9000420 	str	x0, [x1, #8]
    5edc:	17fffe1e 	b	5754 <fwp_main_thread+0x8a0>
    5ee0:	ca594720 	eor	x0, x25, x25, lsr #17
    5ee4:	9114c2a1 	add	x1, x21, #0x530
    5ee8:	ca402400 	eor	x0, x0, x0, lsr #9
    5eec:	8b200c20 	add	x0, x1, w0, uxtb #3
    5ef0:	f94a2400 	ldr	x0, [x0, #5192]
    5ef4:	b5000080 	cbnz	x0, 5f04 <fwp_main_thread+0x1050>
    5ef8:	14000012 	b	5f40 <fwp_main_thread+0x108c>
    5efc:	f9400800 	ldr	x0, [x0, #16]
    5f00:	b4000200 	cbz	x0, 5f40 <fwp_main_thread+0x108c>
    5f04:	f9400001 	ldr	x1, [x0]
    5f08:	eb19003f 	cmp	x1, x25
    5f0c:	54ffff81 	b.ne	5efc <fwp_main_thread+0x1048>  // b.any
    5f10:	f9400401 	ldr	x1, [x0, #8]
    5f14:	d1000421 	sub	x1, x1, #0x1
    5f18:	f9000401 	str	x1, [x0, #8]
    5f1c:	f103f83f 	cmp	x1, #0xfe
    5f20:	54ffe741 	b.ne	5c08 <fwp_main_thread+0xd54>  // b.any
    5f24:	aa1903e0 	mov	x0, x25
    5f28:	97fff397 	bl	2d84 <fwp_rc_forget_slot>
    5f2c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f30:	39000320 	strb	w0, [x25]
    5f34:	17ffff35 	b	5c08 <fwp_main_thread+0xd54>
    5f38:	7103f81f 	cmp	w0, #0xfe
    5f3c:	54000200 	b.eq	5f7c <fwp_main_thread+0x10c8>  // b.none
    5f40:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    5f44:	9127e000 	add	x0, x0, #0x9f8
    5f48:	97fff0ce 	bl	2280 <fwp_trap>
    5f4c:	b902dadf 	str	wzr, [x22, #728]
    5f50:	b4ff9740 	cbz	x0, 5238 <fwp_main_thread+0x384>
    5f54:	97ffed7f 	bl	1550 <abort@plt>
    5f58:	aa1803e0 	mov	x0, x24
    5f5c:	97fff38a 	bl	2d84 <fwp_rc_forget_slot>
    5f60:	17fffdac 	b	5610 <fwp_main_thread+0x75c>
    5f64:	aa1703e0 	mov	x0, x23
    5f68:	97fff387 	bl	2d84 <fwp_rc_forget_slot>
    5f6c:	17fffdcd 	b	56a0 <fwp_main_thread+0x7ec>
    5f70:	aa1903e0 	mov	x0, x25
    5f74:	97fff384 	bl	2d84 <fwp_rc_forget_slot>
    5f78:	17fffd83 	b	5584 <fwp_main_thread+0x6d0>
    5f7c:	d2800300 	mov	x0, #0x18                  	// #24
    5f80:	97ffed48 	bl	14a0 <malloc@plt>
    5f84:	b4000320 	cbz	x0, 5fe8 <fwp_main_thread+0x1134>
    5f88:	d2801fe1 	mov	x1, #0xff                  	// #255
    5f8c:	a9000417 	stp	x23, x1, [x0]
    5f90:	9114c2a1 	add	x1, x21, #0x530
    5f94:	f900081f 	str	xzr, [x0, #16]
    5f98:	12800002 	mov	w2, #0xffffffff            	// #-1
    5f9c:	f9000320 	str	x0, [x25]
    5fa0:	390002e2 	strb	w2, [x23]
    5fa4:	f94e2420 	ldr	x0, [x1, #7240]
    5fa8:	91000400 	add	x0, x0, #0x1
    5fac:	f90e2420 	str	x0, [x1, #7240]
    5fb0:	17fffde9 	b	5754 <fwp_main_thread+0x8a0>
    5fb4:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    5fb8:	912f0000 	add	x0, x0, #0xbc0
    5fbc:	97fff0b1 	bl	2280 <fwp_trap>
    5fc0:	b4fffde1 	cbz	x1, 5f7c <fwp_main_thread+0x10c8>
    5fc4:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    5fc8:	912de000 	add	x0, x0, #0xb78
    5fcc:	97fff0ad 	bl	2280 <fwp_trap>
    5fd0:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    5fd4:	912e8000 	add	x0, x0, #0xba0
    5fd8:	97fff0aa 	bl	2280 <fwp_trap>
    5fdc:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    5fe0:	912fa000 	add	x0, x0, #0xbe8
    5fe4:	97fff0a7 	bl	2280 <fwp_trap>
    5fe8:	97ffef3a 	bl	1cd0 <fwp_heap_oom>
    5fec:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    5ff0:	17ffffb3 	b	5ebc <fwp_main_thread+0x1008>
    5ff4:	97ffed43 	bl	1500 <__stack_chk_fail@plt>
    5ff8:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    5ffc:	912d6000 	add	x0, x0, #0xb58
    6000:	97ffefb8 	bl	1ee0 <ad_raw_fail>
    6004:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    6008:	91288000 	add	x0, x0, #0xa20
    600c:	97fff09d 	bl	2280 <fwp_trap>
    6010:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    6014:	912cc000 	add	x0, x0, #0xb30
    6018:	97fff09a 	bl	2280 <fwp_trap>
    601c:	d503201f 	nop

0000000000006020 <__divti3>:
    6020:	d503245f 	bti	c
    6024:	d2800004 	mov	x4, #0x0                   	// #0
    6028:	b7f80721 	tbnz	x1, #63, 610c <__divti3+0xec>
    602c:	b6f80083 	tbz	x3, #63, 603c <__divti3+0x1c>
    6030:	eb0203e2 	negs	x2, x2
    6034:	aa2403e4 	mvn	x4, x4
    6038:	da0303e3 	ngc	x3, x3
    603c:	aa0203e6 	mov	x6, x2
    6040:	aa0003e7 	mov	x7, x0
    6044:	aa0103e5 	mov	x5, x1
    6048:	b5000583 	cbnz	x3, 60f8 <__divti3+0xd8>
    604c:	eb01005f 	cmp	x2, x1
    6050:	54000e69 	b.ls	621c <__divti3+0x1fc>  // b.plast
    6054:	dac01040 	clz	x0, x2
    6058:	b40000e0 	cbz	x0, 6074 <__divti3+0x54>
    605c:	4b0003e1 	neg	w1, w0
    6060:	9ac020a5 	lsl	x5, x5, x0
    6064:	9ac02046 	lsl	x6, x2, x0
    6068:	9ac124e1 	lsr	x1, x7, x1
    606c:	aa050025 	orr	x5, x1, x5
    6070:	9ac020e7 	lsl	x7, x7, x0
    6074:	d360fcc8 	lsr	x8, x6, #32
    6078:	92407cc2 	and	x2, x6, #0xffffffff
    607c:	9ac808a3 	udiv	x3, x5, x8
    6080:	9b089465 	msub	x5, x3, x8, x5
    6084:	aa0303e0 	mov	x0, x3
    6088:	9b037c41 	mul	x1, x2, x3
    608c:	93c780a5 	extr	x5, x5, x7, #32
    6090:	eb05003f 	cmp	x1, x5
    6094:	540000a9 	b.ls	60a8 <__divti3+0x88>  // b.plast
    6098:	ab0500c5 	adds	x5, x6, x5
    609c:	d1000460 	sub	x0, x3, #0x1
    60a0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    60a4:	540015a8 	b.hi	6358 <__divti3+0x338>  // b.pmore
    60a8:	cb0100a5 	sub	x5, x5, x1
    60ac:	9ac808a3 	udiv	x3, x5, x8
    60b0:	9b089465 	msub	x5, x3, x8, x5
    60b4:	aa0303e1 	mov	x1, x3
    60b8:	9b037c42 	mul	x2, x2, x3
    60bc:	aa0703e3 	mov	x3, x7
    60c0:	b3607ca3 	bfi	x3, x5, #32, #32
    60c4:	eb03005f 	cmp	x2, x3
    60c8:	540000c9 	b.ls	60e0 <__divti3+0xc0>  // b.plast
    60cc:	ab0300c3 	adds	x3, x6, x3
    60d0:	d1000425 	sub	x5, x1, #0x1
    60d4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    60d8:	d1000821 	sub	x1, x1, #0x2
    60dc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    60e0:	aa008020 	orr	x0, x1, x0, lsl #32
    60e4:	d2800001 	mov	x1, #0x0                   	// #0
    60e8:	b4000064 	cbz	x4, 60f4 <__divti3+0xd4>
    60ec:	eb0003e0 	negs	x0, x0
    60f0:	da0103e1 	ngc	x1, x1
    60f4:	d65f03c0 	ret
    60f8:	eb01007f 	cmp	x3, x1
    60fc:	54000109 	b.ls	611c <__divti3+0xfc>  // b.plast
    6100:	d2800001 	mov	x1, #0x0                   	// #0
    6104:	d2800000 	mov	x0, #0x0                   	// #0
    6108:	17fffff8 	b	60e8 <__divti3+0xc8>
    610c:	eb0003e0 	negs	x0, x0
    6110:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    6114:	da0103e1 	ngc	x1, x1
    6118:	17ffffc5 	b	602c <__divti3+0xc>
    611c:	dac01067 	clz	x7, x3
    6120:	b40010e7 	cbz	x7, 633c <__divti3+0x31c>
    6124:	d2800805 	mov	x5, #0x40                  	// #64
    6128:	cb0700a5 	sub	x5, x5, x7
    612c:	9ac72063 	lsl	x3, x3, x7
    6130:	9ac52448 	lsr	x8, x2, x5
    6134:	aa030108 	orr	x8, x8, x3
    6138:	9ac52426 	lsr	x6, x1, x5
    613c:	92407d0a 	and	x10, x8, #0xffffffff
    6140:	d360fd09 	lsr	x9, x8, #32
    6144:	9ac52403 	lsr	x3, x0, x5
    6148:	9ac72021 	lsl	x1, x1, x7
    614c:	aa010063 	orr	x3, x3, x1
    6150:	9ac72042 	lsl	x2, x2, x7
    6154:	9ac908cb 	udiv	x11, x6, x9
    6158:	9b099965 	msub	x5, x11, x9, x6
    615c:	aa0b03e1 	mov	x1, x11
    6160:	9b0b7d46 	mul	x6, x10, x11
    6164:	93c380a5 	extr	x5, x5, x3, #32
    6168:	eb0500df 	cmp	x6, x5
    616c:	540000a9 	b.ls	6180 <__divti3+0x160>  // b.plast
    6170:	ab050105 	adds	x5, x8, x5
    6174:	d1000561 	sub	x1, x11, #0x1
    6178:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    617c:	54000f48 	b.hi	6364 <__divti3+0x344>  // b.pmore
    6180:	cb0600a6 	sub	x6, x5, x6
    6184:	9ac908cb 	udiv	x11, x6, x9
    6188:	9b099969 	msub	x9, x11, x9, x6
    618c:	aa0b03e5 	mov	x5, x11
    6190:	9b0b7d4a 	mul	x10, x10, x11
    6194:	b3607d23 	bfi	x3, x9, #32, #32
    6198:	eb03015f 	cmp	x10, x3
    619c:	540000a9 	b.ls	61b0 <__divti3+0x190>  // b.plast
    61a0:	ab030103 	adds	x3, x8, x3
    61a4:	d1000565 	sub	x5, x11, #0x1
    61a8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    61ac:	54000e28 	b.hi	6370 <__divti3+0x350>  // b.pmore
    61b0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    61b4:	92407c48 	and	x8, x2, #0xffffffff
    61b8:	2a0503e5 	mov	w5, w5
    61bc:	d360fc42 	lsr	x2, x2, #32
    61c0:	d360fc26 	lsr	x6, x1, #32
    61c4:	cb0a0063 	sub	x3, x3, x10
    61c8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    61cc:	9b087caa 	mul	x10, x5, x8
    61d0:	9b087cc8 	mul	x8, x6, x8
    61d4:	9b0220a5 	madd	x5, x5, x2, x8
    61d8:	9b027cc6 	mul	x6, x6, x2
    61dc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    61e0:	8b0900c5 	add	x5, x6, x9
    61e4:	eb02011f 	cmp	x8, x2
    61e8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    61ec:	8b4280c6 	add	x6, x6, x2, lsr #32
    61f0:	eb06007f 	cmp	x3, x6
    61f4:	540000e3 	b.cc	6210 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    61f8:	92407d4a 	and	x10, x10, #0xffffffff
    61fc:	9ac72000 	lsl	x0, x0, x7
    6200:	8b028142 	add	x2, x10, x2, lsl #32
    6204:	eb02001f 	cmp	x0, x2
    6208:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    620c:	54000a01 	b.ne	634c <__divti3+0x32c>  // b.any
    6210:	d1000420 	sub	x0, x1, #0x1
    6214:	d2800001 	mov	x1, #0x0                   	// #0
    6218:	17ffffb4 	b	60e8 <__divti3+0xc8>
    621c:	b5000062 	cbnz	x2, 6228 <__divti3+0x208>
    6220:	d2800022 	mov	x2, #0x1                   	// #1
    6224:	9ac30846 	udiv	x6, x2, x3
    6228:	dac010c8 	clz	x8, x6
    622c:	b5000408 	cbnz	x8, 62ac <__divti3+0x28c>
    6230:	d360fcc9 	lsr	x9, x6, #32
    6234:	92407cc5 	and	x5, x6, #0xffffffff
    6238:	cb060023 	sub	x3, x1, x6
    623c:	d2800021 	mov	x1, #0x1                   	// #1
    6240:	9ac90868 	udiv	x8, x3, x9
    6244:	9b098d03 	msub	x3, x8, x9, x3
    6248:	aa0803e0 	mov	x0, x8
    624c:	9b057d02 	mul	x2, x8, x5
    6250:	93c78063 	extr	x3, x3, x7, #32
    6254:	eb03005f 	cmp	x2, x3
    6258:	540000a9 	b.ls	626c <__divti3+0x24c>  // b.plast
    625c:	ab0300c3 	adds	x3, x6, x3
    6260:	d1000500 	sub	x0, x8, #0x1
    6264:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    6268:	54000968 	b.hi	6394 <__divti3+0x374>  // b.pmore
    626c:	cb020063 	sub	x3, x3, x2
    6270:	9ac90862 	udiv	x2, x3, x9
    6274:	aa0203e8 	mov	x8, x2
    6278:	9b098c42 	msub	x2, x2, x9, x3
    627c:	aa0703e3 	mov	x3, x7
    6280:	9b057d05 	mul	x5, x8, x5
    6284:	b3607c43 	bfi	x3, x2, #32, #32
    6288:	eb0300bf 	cmp	x5, x3
    628c:	540000c9 	b.ls	62a4 <__divti3+0x284>  // b.plast
    6290:	ab0300c2 	adds	x2, x6, x3
    6294:	d1000503 	sub	x3, x8, #0x1
    6298:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    629c:	d1000908 	sub	x8, x8, #0x2
    62a0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    62a4:	aa008100 	orr	x0, x8, x0, lsl #32
    62a8:	17ffff90 	b	60e8 <__divti3+0xc8>
    62ac:	9ac820c6 	lsl	x6, x6, x8
    62b0:	d2800803 	mov	x3, #0x40                  	// #64
    62b4:	cb080063 	sub	x3, x3, x8
    62b8:	d360fcc9 	lsr	x9, x6, #32
    62bc:	9ac82027 	lsl	x7, x1, x8
    62c0:	92407cc5 	and	x5, x6, #0xffffffff
    62c4:	9ac32422 	lsr	x2, x1, x3
    62c8:	9ac32403 	lsr	x3, x0, x3
    62cc:	aa070063 	orr	x3, x3, x7
    62d0:	9ac9084a 	udiv	x10, x2, x9
    62d4:	9ac82007 	lsl	x7, x0, x8
    62d8:	9b098940 	msub	x0, x10, x9, x2
    62dc:	aa0a03e1 	mov	x1, x10
    62e0:	9b0a7ca2 	mul	x2, x5, x10
    62e4:	93c38000 	extr	x0, x0, x3, #32
    62e8:	eb00005f 	cmp	x2, x0
    62ec:	540000a9 	b.ls	6300 <__divti3+0x2e0>  // b.plast
    62f0:	ab0000c0 	adds	x0, x6, x0
    62f4:	d1000541 	sub	x1, x10, #0x1
    62f8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    62fc:	54000468 	b.hi	6388 <__divti3+0x368>  // b.pmore
    6300:	cb020000 	sub	x0, x0, x2
    6304:	9ac9080a 	udiv	x10, x0, x9
    6308:	9b098140 	msub	x0, x10, x9, x0
    630c:	aa0a03e2 	mov	x2, x10
    6310:	9b0a7ca8 	mul	x8, x5, x10
    6314:	b3607c03 	bfi	x3, x0, #32, #32
    6318:	eb03011f 	cmp	x8, x3
    631c:	540000a9 	b.ls	6330 <__divti3+0x310>  // b.plast
    6320:	ab0300c3 	adds	x3, x6, x3
    6324:	d1000542 	sub	x2, x10, #0x1
    6328:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    632c:	54000288 	b.hi	637c <__divti3+0x35c>  // b.pmore
    6330:	cb080063 	sub	x3, x3, x8
    6334:	aa018041 	orr	x1, x2, x1, lsl #32
    6338:	17ffffc2 	b	6240 <__divti3+0x220>
    633c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    6340:	d2800001 	mov	x1, #0x0                   	// #0
    6344:	9a9f87e0 	cset	x0, ls	// ls = plast
    6348:	17ffff68 	b	60e8 <__divti3+0xc8>
    634c:	aa0103e0 	mov	x0, x1
    6350:	d2800001 	mov	x1, #0x0                   	// #0
    6354:	17ffff65 	b	60e8 <__divti3+0xc8>
    6358:	d1000860 	sub	x0, x3, #0x2
    635c:	8b0600a5 	add	x5, x5, x6
    6360:	17ffff52 	b	60a8 <__divti3+0x88>
    6364:	d1000961 	sub	x1, x11, #0x2
    6368:	8b0800a5 	add	x5, x5, x8
    636c:	17ffff85 	b	6180 <__divti3+0x160>
    6370:	d1000965 	sub	x5, x11, #0x2
    6374:	8b080063 	add	x3, x3, x8
    6378:	17ffff8e 	b	61b0 <__divti3+0x190>
    637c:	d1000942 	sub	x2, x10, #0x2
    6380:	8b060063 	add	x3, x3, x6
    6384:	17ffffeb 	b	6330 <__divti3+0x310>
    6388:	d1000941 	sub	x1, x10, #0x2
    638c:	8b060000 	add	x0, x0, x6
    6390:	17ffffdc 	b	6300 <__divti3+0x2e0>
    6394:	d1000900 	sub	x0, x8, #0x2
    6398:	8b060063 	add	x3, x3, x6
    639c:	17ffffb4 	b	626c <__divti3+0x24c>

00000000000063a0 <__modti3>:
    63a0:	d503245f 	bti	c
    63a4:	d2800004 	mov	x4, #0x0                   	// #0
    63a8:	b6f80081 	tbz	x1, #63, 63b8 <__modti3+0x18>
    63ac:	eb0003e0 	negs	x0, x0
    63b0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    63b4:	da0103e1 	ngc	x1, x1
    63b8:	f100007f 	cmp	x3, #0x0
    63bc:	5400128b 	b.lt	660c <__modti3+0x26c>  // b.tstop
    63c0:	aa0003e7 	mov	x7, x0
    63c4:	aa0103e6 	mov	x6, x1
    63c8:	540004e1 	b.ne	6464 <__modti3+0xc4>  // b.any
    63cc:	eb02003f 	cmp	x1, x2
    63d0:	54000dc2 	b.cs	6588 <__modti3+0x1e8>  // b.hs, b.nlast
    63d4:	dac01043 	clz	x3, x2
    63d8:	aa0303e5 	mov	x5, x3
    63dc:	b40000e3 	cbz	x3, 63f8 <__modti3+0x58>
    63e0:	4b0303e6 	neg	w6, w3
    63e4:	9ac32021 	lsl	x1, x1, x3
    63e8:	9ac32042 	lsl	x2, x2, x3
    63ec:	9ac62406 	lsr	x6, x0, x6
    63f0:	aa0100c6 	orr	x6, x6, x1
    63f4:	9ac32007 	lsl	x7, x0, x3
    63f8:	d360fc40 	lsr	x0, x2, #32
    63fc:	92407c43 	and	x3, x2, #0xffffffff
    6400:	9ac008c1 	udiv	x1, x6, x0
    6404:	9b009826 	msub	x6, x1, x0, x6
    6408:	9b017c61 	mul	x1, x3, x1
    640c:	93c780c6 	extr	x6, x6, x7, #32
    6410:	eb06003f 	cmp	x1, x6
    6414:	540000a9 	b.ls	6428 <__modti3+0x88>  // b.plast
    6418:	ab060046 	adds	x6, x2, x6
    641c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    6420:	8b0200c8 	add	x8, x6, x2
    6424:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    6428:	cb0100c6 	sub	x6, x6, x1
    642c:	9ac008c8 	udiv	x8, x6, x0
    6430:	9b009901 	msub	x1, x8, x0, x6
    6434:	aa0703e0 	mov	x0, x7
    6438:	9b087c63 	mul	x3, x3, x8
    643c:	b3607c20 	bfi	x0, x1, #32, #32
    6440:	eb00007f 	cmp	x3, x0
    6444:	54001088 	b.hi	6654 <__modti3+0x2b4>  // b.pmore
    6448:	cb030000 	sub	x0, x0, x3
    644c:	9ac52400 	lsr	x0, x0, x5
    6450:	d2800001 	mov	x1, #0x0                   	// #0
    6454:	b4000064 	cbz	x4, 6460 <__modti3+0xc0>
    6458:	eb0003e0 	negs	x0, x0
    645c:	da0103e1 	ngc	x1, x1
    6460:	d65f03c0 	ret
    6464:	dac01066 	clz	x6, x3
    6468:	eb03003f 	cmp	x1, x3
    646c:	54ffff43 	b.cc	6454 <__modti3+0xb4>  // b.lo, b.ul, b.last
    6470:	93407cc5 	sxtw	x5, w6
    6474:	d2800808 	mov	x8, #0x40                  	// #64
    6478:	cb050108 	sub	x8, x8, x5
    647c:	9ac62063 	lsl	x3, x3, x6
    6480:	9ac62025 	lsl	x5, x1, x6
    6484:	9ac82447 	lsr	x7, x2, x8
    6488:	aa0300e7 	orr	x7, x7, x3
    648c:	9ac82423 	lsr	x3, x1, x8
    6490:	92407cec 	and	x12, x7, #0xffffffff
    6494:	d360fcea 	lsr	x10, x7, #32
    6498:	9ac82401 	lsr	x1, x0, x8
    649c:	aa050021 	orr	x1, x1, x5
    64a0:	9ac62042 	lsl	x2, x2, x6
    64a4:	9ac62000 	lsl	x0, x0, x6
    64a8:	9aca086b 	udiv	x11, x3, x10
    64ac:	9b0a8d63 	msub	x3, x11, x10, x3
    64b0:	aa0b03e5 	mov	x5, x11
    64b4:	9b0b7d89 	mul	x9, x12, x11
    64b8:	93c18063 	extr	x3, x3, x1, #32
    64bc:	eb03013f 	cmp	x9, x3
    64c0:	540000a9 	b.ls	64d4 <__modti3+0x134>  // b.plast
    64c4:	ab0300e3 	adds	x3, x7, x3
    64c8:	d1000565 	sub	x5, x11, #0x1
    64cc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    64d0:	54001168 	b.hi	66fc <__modti3+0x35c>  // b.pmore
    64d4:	cb090063 	sub	x3, x3, x9
    64d8:	9aca086b 	udiv	x11, x3, x10
    64dc:	9b0a8d6a 	msub	x10, x11, x10, x3
    64e0:	aa0b03e9 	mov	x9, x11
    64e4:	9b0b7d8c 	mul	x12, x12, x11
    64e8:	b3607d41 	bfi	x1, x10, #32, #32
    64ec:	eb01019f 	cmp	x12, x1
    64f0:	540000a9 	b.ls	6504 <__modti3+0x164>  // b.plast
    64f4:	ab0100e1 	adds	x1, x7, x1
    64f8:	d1000569 	sub	x9, x11, #0x1
    64fc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    6500:	54000f88 	b.hi	66f0 <__modti3+0x350>  // b.pmore
    6504:	aa058123 	orr	x3, x9, x5, lsl #32
    6508:	92407c4b 	and	x11, x2, #0xffffffff
    650c:	2a0903e9 	mov	w9, w9
    6510:	d360fc4a 	lsr	x10, x2, #32
    6514:	d360fc63 	lsr	x3, x3, #32
    6518:	cb0c0021 	sub	x1, x1, x12
    651c:	aa0a03ec 	mov	x12, x10
    6520:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    6524:	9b0b7d25 	mul	x5, x9, x11
    6528:	9b0b7c6b 	mul	x11, x3, x11
    652c:	9b0a2d29 	madd	x9, x9, x10, x11
    6530:	92407caa 	and	x10, x5, #0xffffffff
    6534:	9b0c7c63 	mul	x3, x3, x12
    6538:	8b458125 	add	x5, x9, x5, lsr #32
    653c:	8b0d0069 	add	x9, x3, x13
    6540:	eb05017f 	cmp	x11, x5
    6544:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    6548:	8b058149 	add	x9, x10, x5, lsl #32
    654c:	8b458063 	add	x3, x3, x5, lsr #32
    6550:	eb03003f 	cmp	x1, x3
    6554:	54000063 	b.cc	6560 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    6558:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    655c:	54000082 	b.cs	656c <__modti3+0x1cc>  // b.hs, b.nlast
    6560:	eb020129 	subs	x9, x9, x2
    6564:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    6568:	cb070063 	sub	x3, x3, x7
    656c:	eb090000 	subs	x0, x0, x9
    6570:	da030021 	sbc	x1, x1, x3
    6574:	9ac62400 	lsr	x0, x0, x6
    6578:	9ac82028 	lsl	x8, x1, x8
    657c:	aa000100 	orr	x0, x8, x0
    6580:	9ac62421 	lsr	x1, x1, x6
    6584:	17ffffb4 	b	6454 <__modti3+0xb4>
    6588:	b5000062 	cbnz	x2, 6594 <__modti3+0x1f4>
    658c:	d2800023 	mov	x3, #0x1                   	// #1
    6590:	9ac20862 	udiv	x2, x3, x2
    6594:	dac01048 	clz	x8, x2
    6598:	aa0803e5 	mov	x5, x8
    659c:	b5000668 	cbnz	x8, 6668 <__modti3+0x2c8>
    65a0:	cb020020 	sub	x0, x1, x2
    65a4:	d360fc49 	lsr	x9, x2, #32
    65a8:	92407c4a 	and	x10, x2, #0xffffffff
    65ac:	9ac90801 	udiv	x1, x0, x9
    65b0:	9b098020 	msub	x0, x1, x9, x0
    65b4:	9b0a7c21 	mul	x1, x1, x10
    65b8:	93c78000 	extr	x0, x0, x7, #32
    65bc:	eb00003f 	cmp	x1, x0
    65c0:	540000a9 	b.ls	65d4 <__modti3+0x234>  // b.plast
    65c4:	ab000040 	adds	x0, x2, x0
    65c8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    65cc:	8b020003 	add	x3, x0, x2
    65d0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    65d4:	cb010001 	sub	x1, x0, x1
    65d8:	9ac90820 	udiv	x0, x1, x9
    65dc:	9b098403 	msub	x3, x0, x9, x1
    65e0:	aa0703e1 	mov	x1, x7
    65e4:	9b0a7c00 	mul	x0, x0, x10
    65e8:	b3607c61 	bfi	x1, x3, #32, #32
    65ec:	eb01001f 	cmp	x0, x1
    65f0:	540000a9 	b.ls	6604 <__modti3+0x264>  // b.plast
    65f4:	ab010041 	adds	x1, x2, x1
    65f8:	8b020022 	add	x2, x1, x2
    65fc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    6600:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    6604:	cb000020 	sub	x0, x1, x0
    6608:	17ffff91 	b	644c <__modti3+0xac>
    660c:	eb0203e5 	negs	x5, x2
    6610:	aa0003e7 	mov	x7, x0
    6614:	da0303e8 	ngc	x8, x3
    6618:	aa0503e2 	mov	x2, x5
    661c:	aa0803e3 	mov	x3, x8
    6620:	aa0103e6 	mov	x6, x1
    6624:	b4ffed48 	cbz	x8, 63cc <__modti3+0x2c>
    6628:	eb01011f 	cmp	x8, x1
    662c:	54fff148 	b.hi	6454 <__modti3+0xb4>  // b.pmore
    6630:	dac01109 	clz	x9, x8
    6634:	2a0903e6 	mov	w6, w9
    6638:	b5fff1c9 	cbnz	x9, 6470 <__modti3+0xd0>
    663c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    6640:	54000068 	b.hi	664c <__modti3+0x2ac>  // b.pmore
    6644:	eb050007 	subs	x7, x0, x5
    6648:	da080021 	sbc	x1, x1, x8
    664c:	aa0703e0 	mov	x0, x7
    6650:	17ffff81 	b	6454 <__modti3+0xb4>
    6654:	ab000040 	adds	x0, x2, x0
    6658:	8b020002 	add	x2, x0, x2
    665c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    6660:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    6664:	17ffff79 	b	6448 <__modti3+0xa8>
    6668:	9ac82042 	lsl	x2, x2, x8
    666c:	d2800803 	mov	x3, #0x40                  	// #64
    6670:	cb080063 	sub	x3, x3, x8
    6674:	d360fc49 	lsr	x9, x2, #32
    6678:	9ac82027 	lsl	x7, x1, x8
    667c:	92407c4a 	and	x10, x2, #0xffffffff
    6680:	9ac32426 	lsr	x6, x1, x3
    6684:	9ac32403 	lsr	x3, x0, x3
    6688:	aa070063 	orr	x3, x3, x7
    668c:	9ac908c1 	udiv	x1, x6, x9
    6690:	9ac82007 	lsl	x7, x0, x8
    6694:	9b099820 	msub	x0, x1, x9, x6
    6698:	9b017d41 	mul	x1, x10, x1
    669c:	93c38000 	extr	x0, x0, x3, #32
    66a0:	eb00003f 	cmp	x1, x0
    66a4:	540000a9 	b.ls	66b8 <__modti3+0x318>  // b.plast
    66a8:	ab000040 	adds	x0, x2, x0
    66ac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    66b0:	8b020006 	add	x6, x0, x2
    66b4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    66b8:	cb010000 	sub	x0, x0, x1
    66bc:	9ac90801 	udiv	x1, x0, x9
    66c0:	9b098026 	msub	x6, x1, x9, x0
    66c4:	aa0303e0 	mov	x0, x3
    66c8:	9b017d41 	mul	x1, x10, x1
    66cc:	b3607cc0 	bfi	x0, x6, #32, #32
    66d0:	eb00003f 	cmp	x1, x0
    66d4:	540000a9 	b.ls	66e8 <__modti3+0x348>  // b.plast
    66d8:	ab000040 	adds	x0, x2, x0
    66dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    66e0:	8b020003 	add	x3, x0, x2
    66e4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    66e8:	cb010000 	sub	x0, x0, x1
    66ec:	17ffffb0 	b	65ac <__modti3+0x20c>
    66f0:	d1000969 	sub	x9, x11, #0x2
    66f4:	8b070021 	add	x1, x1, x7
    66f8:	17ffff83 	b	6504 <__modti3+0x164>
    66fc:	d1000965 	sub	x5, x11, #0x2
    6700:	8b070063 	add	x3, x3, x7
    6704:	17ffff74 	b	64d4 <__modti3+0x134>
    6708:	d503201f 	nop
    670c:	d503201f 	nop

0000000000006710 <atexit>:
    6710:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    6714:	d00000c2 	adrp	x2, 20000 <__data_start>
    6718:	d2800001 	mov	x1, #0x0                   	// #0
    671c:	910003fd 	mov	x29, sp
    6720:	a8c17bfd 	ldp	x29, x30, [sp], #16
    6724:	f9400442 	ldr	x2, [x2, #8]
    6728:	17ffeb36 	b	1400 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000672c <_fini>:
    672c:	d503201f 	nop
    6730:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    6734:	910003fd 	mov	x29, sp
    6738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    673c:	d65f03c0 	ret
