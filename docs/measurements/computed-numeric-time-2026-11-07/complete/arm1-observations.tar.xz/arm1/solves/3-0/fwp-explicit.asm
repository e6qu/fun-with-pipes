
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-0/fwp-explicit:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001310 <_init>:
    1310:	d503201f 	nop
    1314:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1318:	910003fd 	mov	x29, sp
    131c:	94000186 	bl	1934 <call_weak_fn>
    1320:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1324:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001330 <.plt>:
    1330:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1334:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1338:	f946fe11 	ldr	x17, [x16, #3576]
    133c:	9137e210 	add	x16, x16, #0xdf8
    1340:	d61f0220 	br	x17
    1344:	d503201f 	nop
    1348:	d503201f 	nop
    134c:	d503201f 	nop

0000000000001350 <memcpy@plt>:
    1350:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1354:	f9470211 	ldr	x17, [x16, #3584]
    1358:	91380210 	add	x16, x16, #0xe00
    135c:	d61f0220 	br	x17

0000000000001360 <sigaltstack@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1364:	f9470611 	ldr	x17, [x16, #3592]
    1368:	91382210 	add	x16, x16, #0xe08
    136c:	d61f0220 	br	x17

0000000000001370 <_exit@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1374:	f9470a11 	ldr	x17, [x16, #3600]
    1378:	91384210 	add	x16, x16, #0xe10
    137c:	d61f0220 	br	x17

0000000000001380 <strlen@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1384:	f9470e11 	ldr	x17, [x16, #3608]
    1388:	91386210 	add	x16, x16, #0xe18
    138c:	d61f0220 	br	x17

0000000000001390 <__sprintf_chk@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1394:	f9471211 	ldr	x17, [x16, #3616]
    1398:	91388210 	add	x16, x16, #0xe20
    139c:	d61f0220 	br	x17

00000000000013a0 <exit@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    13a4:	f9471611 	ldr	x17, [x16, #3624]
    13a8:	9138a210 	add	x16, x16, #0xe28
    13ac:	d61f0220 	br	x17

00000000000013b0 <__libc_start_main@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    13b4:	f9471a11 	ldr	x17, [x16, #3632]
    13b8:	9138c210 	add	x16, x16, #0xe30
    13bc:	d61f0220 	br	x17

00000000000013c0 <strtoll@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    13c4:	f9471e11 	ldr	x17, [x16, #3640]
    13c8:	9138e210 	add	x16, x16, #0xe38
    13cc:	d61f0220 	br	x17

00000000000013d0 <strtod@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    13d4:	f9472211 	ldr	x17, [x16, #3648]
    13d8:	91390210 	add	x16, x16, #0xe40
    13dc:	d61f0220 	br	x17

00000000000013e0 <__cxa_finalize@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    13e4:	f9472611 	ldr	x17, [x16, #3656]
    13e8:	91392210 	add	x16, x16, #0xe48
    13ec:	d61f0220 	br	x17

00000000000013f0 <__cxa_atexit@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    13f4:	f9472a11 	ldr	x17, [x16, #3664]
    13f8:	91394210 	add	x16, x16, #0xe50
    13fc:	d61f0220 	br	x17

0000000000001400 <pthread_attr_init@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1404:	f9472e11 	ldr	x17, [x16, #3672]
    1408:	91396210 	add	x16, x16, #0xe58
    140c:	d61f0220 	br	x17

0000000000001410 <fputc@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1414:	f9473211 	ldr	x17, [x16, #3680]
    1418:	91398210 	add	x16, x16, #0xe60
    141c:	d61f0220 	br	x17

0000000000001420 <clock_gettime@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1424:	f9473611 	ldr	x17, [x16, #3688]
    1428:	9139a210 	add	x16, x16, #0xe68
    142c:	d61f0220 	br	x17

0000000000001430 <setvbuf@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1434:	f9473a11 	ldr	x17, [x16, #3696]
    1438:	9139c210 	add	x16, x16, #0xe70
    143c:	d61f0220 	br	x17

0000000000001440 <__memcpy_chk@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1444:	f9473e11 	ldr	x17, [x16, #3704]
    1448:	9139e210 	add	x16, x16, #0xe78
    144c:	d61f0220 	br	x17

0000000000001450 <signal@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1454:	f9474211 	ldr	x17, [x16, #3712]
    1458:	913a0210 	add	x16, x16, #0xe80
    145c:	d61f0220 	br	x17

0000000000001460 <__snprintf_chk@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1464:	f9474611 	ldr	x17, [x16, #3720]
    1468:	913a2210 	add	x16, x16, #0xe88
    146c:	d61f0220 	br	x17

0000000000001470 <fclose@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1474:	f9474a11 	ldr	x17, [x16, #3728]
    1478:	913a4210 	add	x16, x16, #0xe90
    147c:	d61f0220 	br	x17

0000000000001480 <fopen@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1484:	f9474e11 	ldr	x17, [x16, #3736]
    1488:	913a6210 	add	x16, x16, #0xe98
    148c:	d61f0220 	br	x17

0000000000001490 <malloc@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1494:	f9475211 	ldr	x17, [x16, #3744]
    1498:	913a8210 	add	x16, x16, #0xea0
    149c:	d61f0220 	br	x17

00000000000014a0 <pthread_attr_destroy@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    14a4:	f9475611 	ldr	x17, [x16, #3752]
    14a8:	913aa210 	add	x16, x16, #0xea8
    14ac:	d61f0220 	br	x17

00000000000014b0 <sigemptyset@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    14b4:	f9475a11 	ldr	x17, [x16, #3760]
    14b8:	913ac210 	add	x16, x16, #0xeb0
    14bc:	d61f0220 	br	x17

00000000000014c0 <memset@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    14c4:	f9475e11 	ldr	x17, [x16, #3768]
    14c8:	913ae210 	add	x16, x16, #0xeb8
    14cc:	d61f0220 	br	x17

00000000000014d0 <calloc@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    14d4:	f9476211 	ldr	x17, [x16, #3776]
    14d8:	913b0210 	add	x16, x16, #0xec0
    14dc:	d61f0220 	br	x17

00000000000014e0 <realloc@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    14e4:	f9476611 	ldr	x17, [x16, #3784]
    14e8:	913b2210 	add	x16, x16, #0xec8
    14ec:	d61f0220 	br	x17

00000000000014f0 <__stack_chk_fail@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    14f4:	f9476a11 	ldr	x17, [x16, #3792]
    14f8:	913b4210 	add	x16, x16, #0xed0
    14fc:	d61f0220 	br	x17

0000000000001500 <close@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1504:	f9476e11 	ldr	x17, [x16, #3800]
    1508:	913b6210 	add	x16, x16, #0xed8
    150c:	d61f0220 	br	x17

0000000000001510 <sigaction@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1514:	f9477211 	ldr	x17, [x16, #3808]
    1518:	913b8210 	add	x16, x16, #0xee0
    151c:	d61f0220 	br	x17

0000000000001520 <__gmon_start__@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1524:	f9477611 	ldr	x17, [x16, #3816]
    1528:	913ba210 	add	x16, x16, #0xee8
    152c:	d61f0220 	br	x17

0000000000001530 <write@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1534:	f9477a11 	ldr	x17, [x16, #3824]
    1538:	913bc210 	add	x16, x16, #0xef0
    153c:	d61f0220 	br	x17

0000000000001540 <abort@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1544:	f9477e11 	ldr	x17, [x16, #3832]
    1548:	913be210 	add	x16, x16, #0xef8
    154c:	d61f0220 	br	x17

0000000000001550 <swapcontext@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1554:	f9478211 	ldr	x17, [x16, #3840]
    1558:	913c0210 	add	x16, x16, #0xf00
    155c:	d61f0220 	br	x17

0000000000001560 <__fprintf_chk@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1564:	f9478611 	ldr	x17, [x16, #3848]
    1568:	913c2210 	add	x16, x16, #0xf08
    156c:	d61f0220 	br	x17

0000000000001570 <strcmp@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1574:	f9478a11 	ldr	x17, [x16, #3856]
    1578:	913c4210 	add	x16, x16, #0xf10
    157c:	d61f0220 	br	x17

0000000000001580 <mmap@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1584:	f9478e11 	ldr	x17, [x16, #3864]
    1588:	913c6210 	add	x16, x16, #0xf18
    158c:	d61f0220 	br	x17

0000000000001590 <strtol@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1594:	f9479211 	ldr	x17, [x16, #3872]
    1598:	913c8210 	add	x16, x16, #0xf20
    159c:	d61f0220 	br	x17

00000000000015a0 <strtof@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    15a4:	f9479611 	ldr	x17, [x16, #3880]
    15a8:	913ca210 	add	x16, x16, #0xf28
    15ac:	d61f0220 	br	x17

00000000000015b0 <free@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    15b4:	f9479a11 	ldr	x17, [x16, #3888]
    15b8:	913cc210 	add	x16, x16, #0xf30
    15bc:	d61f0220 	br	x17

00000000000015c0 <nanosleep@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    15c4:	f9479e11 	ldr	x17, [x16, #3896]
    15c8:	913ce210 	add	x16, x16, #0xf38
    15cc:	d61f0220 	br	x17

00000000000015d0 <strchr@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    15d4:	f947a211 	ldr	x17, [x16, #3904]
    15d8:	913d0210 	add	x16, x16, #0xf40
    15dc:	d61f0220 	br	x17

00000000000015e0 <strtoull@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    15e4:	f947a611 	ldr	x17, [x16, #3912]
    15e8:	913d2210 	add	x16, x16, #0xf48
    15ec:	d61f0220 	br	x17

00000000000015f0 <fwrite@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    15f4:	f947aa11 	ldr	x17, [x16, #3920]
    15f8:	913d4210 	add	x16, x16, #0xf50
    15fc:	d61f0220 	br	x17

0000000000001600 <pthread_create@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1604:	f947ae11 	ldr	x17, [x16, #3928]
    1608:	913d6210 	add	x16, x16, #0xf58
    160c:	d61f0220 	br	x17

0000000000001610 <munmap@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1614:	f947b211 	ldr	x17, [x16, #3936]
    1618:	913d8210 	add	x16, x16, #0xf60
    161c:	d61f0220 	br	x17

0000000000001620 <fflush@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1624:	f947b611 	ldr	x17, [x16, #3944]
    1628:	913da210 	add	x16, x16, #0xf68
    162c:	d61f0220 	br	x17

0000000000001630 <strcpy@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1634:	f947ba11 	ldr	x17, [x16, #3952]
    1638:	913dc210 	add	x16, x16, #0xf70
    163c:	d61f0220 	br	x17

0000000000001640 <sysconf@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1644:	f947be11 	ldr	x17, [x16, #3960]
    1648:	913de210 	add	x16, x16, #0xf78
    164c:	d61f0220 	br	x17

0000000000001650 <strstr@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1654:	f947c211 	ldr	x17, [x16, #3968]
    1658:	913e0210 	add	x16, x16, #0xf80
    165c:	d61f0220 	br	x17

0000000000001660 <_Exit@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1664:	f947c611 	ldr	x17, [x16, #3976]
    1668:	913e2210 	add	x16, x16, #0xf88
    166c:	d61f0220 	br	x17

0000000000001670 <pthread_join@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1674:	f947ca11 	ldr	x17, [x16, #3984]
    1678:	913e4210 	add	x16, x16, #0xf90
    167c:	d61f0220 	br	x17

0000000000001680 <getenv@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1684:	f947ce11 	ldr	x17, [x16, #3992]
    1688:	913e6210 	add	x16, x16, #0xf98
    168c:	d61f0220 	br	x17

0000000000001690 <mprotect@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    1694:	f947d211 	ldr	x17, [x16, #4000]
    1698:	913e8210 	add	x16, x16, #0xfa0
    169c:	d61f0220 	br	x17

00000000000016a0 <fgets@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    16a4:	f947d611 	ldr	x17, [x16, #4008]
    16a8:	913ea210 	add	x16, x16, #0xfa8
    16ac:	d61f0220 	br	x17

00000000000016b0 <pthread_attr_setstacksize@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x16b00>
    16b4:	f947da11 	ldr	x17, [x16, #4016]
    16b8:	913ec210 	add	x16, x16, #0xfb0
    16bc:	d61f0220 	br	x17

Disassembly of section .text:

00000000000016c0 <fwp_trap_overflow.constprop.0>:
    16c0:	d10243ff 	sub	sp, sp, #0x90
    16c4:	d2800c03 	mov	x3, #0x60                  	// #96
    16c8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b00>
    16cc:	f947f421 	ldr	x1, [x1, #4072]
    16d0:	d0000025 	adrp	x5, 7000 <_IO_stdin_used+0x140>
    16d4:	a9077bfd 	stp	x29, x30, [sp, #112]
    16d8:	9101c3fd 	add	x29, sp, #0x70
    16dc:	910080a5 	add	x5, x5, #0x20
    16e0:	d0000024 	adrp	x4, 7000 <_IO_stdin_used+0x140>
    16e4:	f90043f3 	str	x19, [sp, #128]
    16e8:	9100a084 	add	x4, x4, #0x28
    16ec:	910023f3 	add	x19, sp, #0x8
    16f0:	f9400022 	ldr	x2, [x1]
    16f4:	f90037e2 	str	x2, [sp, #104]
    16f8:	d2800002 	mov	x2, #0x0                   	// #0
    16fc:	aa0303e1 	mov	x1, x3
    1700:	52800042 	mov	w2, #0x2                   	// #2
    1704:	aa1303e0 	mov	x0, x19
    1708:	97ffff56 	bl	1460 <__snprintf_chk@plt>
    170c:	aa1303e0 	mov	x0, x19
    1710:	94000284 	bl	2120 <fwp_trap>
    1714:	d503201f 	nop
    1718:	d503201f 	nop
    171c:	d503201f 	nop

0000000000001720 <main>:
    1720:	d10243ff 	sub	sp, sp, #0x90
    1724:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    1728:	f947f400 	ldr	x0, [x0, #4072]
    172c:	a9067bfd 	stp	x29, x30, [sp, #96]
    1730:	910183fd 	add	x29, sp, #0x60
    1734:	a90753f3 	stp	x19, x20, [sp, #112]
    1738:	f00000f3 	adrp	x19, 20000 <__data_start>
    173c:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x16b00>
    1740:	f947ee94 	ldr	x20, [x20, #4056]
    1744:	f9400281 	ldr	x1, [x20]
    1748:	f90043f5 	str	x21, [sp, #128]
    174c:	f9400002 	ldr	x2, [x0]
    1750:	f9002fe2 	str	x2, [sp, #88]
    1754:	d2800002 	mov	x2, #0x0                   	// #0
    1758:	f9001a61 	str	x1, [x19, #48]
    175c:	94000281 	bl	2160 <fwp_now_ns>
    1760:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    1764:	9109e000 	add	x0, x0, #0x278
    1768:	97ffffc6 	bl	1680 <getenv@plt>
    176c:	b4000080 	cbz	x0, 177c <main+0x5c>
    1770:	39400001 	ldrb	w1, [x0]
    1774:	aa0003f5 	mov	x21, x0
    1778:	35000801 	cbnz	w1, 1878 <main+0x158>
    177c:	910023e1 	add	x1, sp, #0x8
    1780:	52800000 	mov	w0, #0x0                   	// #0
    1784:	97ffff27 	bl	1420 <clock_gettime@plt>
    1788:	35000900 	cbnz	w0, 18a8 <main+0x188>
    178c:	a9408be0 	ldp	x0, x2, [sp, #8]
    1790:	d2994003 	mov	x3, #0xca00                	// #51712
    1794:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    1798:	9b037c01 	mul	x1, x0, x3
    179c:	9b437c00 	smulh	x0, x0, x3
    17a0:	ab020021 	adds	x1, x1, x2
    17a4:	937ffc42 	asr	x2, x2, #63
    17a8:	9a020000 	adc	x0, x0, x2
    17ac:	f100003f 	cmp	x1, #0x0
    17b0:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    17b4:	b50009a0 	cbnz	x0, 18e8 <main+0x1c8>
    17b8:	f9400280 	ldr	x0, [x20]
    17bc:	d2a00023 	mov	x3, #0x10000               	// #65536
    17c0:	52800002 	mov	w2, #0x0                   	// #0
    17c4:	d2800001 	mov	x1, #0x0                   	// #0
    17c8:	910063f5 	add	x21, sp, #0x18
    17cc:	97ffff19 	bl	1430 <setvbuf@plt>
    17d0:	d2800021 	mov	x1, #0x1                   	// #1
    17d4:	528001a0 	mov	w0, #0xd                   	// #13
    17d8:	97ffff1e 	bl	1450 <signal@plt>
    17dc:	aa1503e0 	mov	x0, x21
    17e0:	97ffff08 	bl	1400 <pthread_attr_init@plt>
    17e4:	350007c0 	cbnz	w0, 18dc <main+0x1bc>
    17e8:	aa1503e0 	mov	x0, x21
    17ec:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    17f0:	97ffffb0 	bl	16b0 <pthread_attr_setstacksize@plt>
    17f4:	35000680 	cbnz	w0, 18c4 <main+0x1a4>
    17f8:	aa1503e1 	mov	x1, x21
    17fc:	910023e0 	add	x0, sp, #0x8
    1800:	90000022 	adrp	x2, 5000 <fwp_write+0x3e0>
    1804:	d2800003 	mov	x3, #0x0                   	// #0
    1808:	91304042 	add	x2, x2, #0xc10
    180c:	97ffff7d 	bl	1600 <pthread_create@plt>
    1810:	2a0003e1 	mov	w1, w0
    1814:	aa1503e0 	mov	x0, x21
    1818:	2a0103f5 	mov	w21, w1
    181c:	97ffff21 	bl	14a0 <pthread_attr_destroy@plt>
    1820:	350006a0 	cbnz	w0, 18f4 <main+0x1d4>
    1824:	350004b5 	cbnz	w21, 18b8 <main+0x198>
    1828:	f94007e0 	ldr	x0, [sp, #8]
    182c:	d2800001 	mov	x1, #0x0                   	// #0
    1830:	97ffff90 	bl	1670 <pthread_join@plt>
    1834:	35000600 	cbnz	w0, 18f4 <main+0x1d4>
    1838:	f9400280 	ldr	x0, [x20]
    183c:	9100c273 	add	x19, x19, #0x30
    1840:	97ffff78 	bl	1620 <fflush@plt>
    1844:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b00>
    1848:	f947f421 	ldr	x1, [x1, #4072]
    184c:	b942a260 	ldr	w0, [x19, #672]
    1850:	f9402fe3 	ldr	x3, [sp, #88]
    1854:	f9400022 	ldr	x2, [x1]
    1858:	eb020063 	subs	x3, x3, x2
    185c:	d2800002 	mov	x2, #0x0                   	// #0
    1860:	540002a1 	b.ne	18b4 <main+0x194>  // b.any
    1864:	a9467bfd 	ldp	x29, x30, [sp, #96]
    1868:	a94753f3 	ldp	x19, x20, [sp, #112]
    186c:	f94043f5 	ldr	x21, [sp, #128]
    1870:	910243ff 	add	sp, sp, #0x90
    1874:	d65f03c0 	ret
    1878:	910003e1 	mov	x1, sp
    187c:	52800142 	mov	w2, #0xa                   	// #10
    1880:	97ffff58 	bl	15e0 <strtoull@plt>
    1884:	f94003e0 	ldr	x0, [sp]
    1888:	39400000 	ldrb	w0, [x0]
    188c:	35fff780 	cbnz	w0, 177c <main+0x5c>
    1890:	394002a0 	ldrb	w0, [x21]
    1894:	52801fa1 	mov	w1, #0xfd                  	// #253
    1898:	5100ac00 	sub	w0, w0, #0x2b
    189c:	6a01001f 	tst	w0, w1
    18a0:	54fff6e0 	b.eq	177c <main+0x5c>  // b.none
    18a4:	17ffffc5 	b	17b8 <main+0x98>
    18a8:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    18ac:	910a2000 	add	x0, x0, #0x288
    18b0:	9400021c 	bl	2120 <fwp_trap>
    18b4:	97ffff0f 	bl	14f0 <__stack_chk_fail@plt>
    18b8:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    18bc:	910ca000 	add	x0, x0, #0x328
    18c0:	94000218 	bl	2120 <fwp_trap>
    18c4:	aa1503e0 	mov	x0, x21
    18c8:	97fffef6 	bl	14a0 <pthread_attr_destroy@plt>
    18cc:	35000140 	cbnz	w0, 18f4 <main+0x1d4>
    18d0:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    18d4:	910c0000 	add	x0, x0, #0x300
    18d8:	94000212 	bl	2120 <fwp_trap>
    18dc:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    18e0:	910b4000 	add	x0, x0, #0x2d0
    18e4:	9400020f 	bl	2120 <fwp_trap>
    18e8:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    18ec:	910aa000 	add	x0, x0, #0x2a8
    18f0:	9400020c 	bl	2120 <fwp_trap>
    18f4:	97ffff13 	bl	1540 <abort@plt>
    18f8:	d503201f 	nop
    18fc:	d503201f 	nop

0000000000001900 <_start>:
    1900:	d503201f 	nop
    1904:	d280001d 	mov	x29, #0x0                   	// #0
    1908:	d280001e 	mov	x30, #0x0                   	// #0
    190c:	aa0003e5 	mov	x5, x0
    1910:	f94003e1 	ldr	x1, [sp]
    1914:	910023e2 	add	x2, sp, #0x8
    1918:	910003e6 	mov	x6, sp
    191c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    1920:	f947f800 	ldr	x0, [x0, #4080]
    1924:	d2800003 	mov	x3, #0x0                   	// #0
    1928:	d2800004 	mov	x4, #0x0                   	// #0
    192c:	97fffea1 	bl	13b0 <__libc_start_main@plt>
    1930:	97ffff04 	bl	1540 <abort@plt>

0000000000001934 <call_weak_fn>:
    1934:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    1938:	f947f000 	ldr	x0, [x0, #4064]
    193c:	b4000040 	cbz	x0, 1944 <call_weak_fn+0x10>
    1940:	17fffef8 	b	1520 <__gmon_start__@plt>
    1944:	d65f03c0 	ret
    1948:	d503201f 	nop
    194c:	d503201f 	nop

0000000000001950 <deregister_tm_clones>:
    1950:	f00000e0 	adrp	x0, 20000 <__data_start>
    1954:	91006000 	add	x0, x0, #0x18
    1958:	f00000e1 	adrp	x1, 20000 <__data_start>
    195c:	91006021 	add	x1, x1, #0x18
    1960:	eb00003f 	cmp	x1, x0
    1964:	540000c0 	b.eq	197c <deregister_tm_clones+0x2c>  // b.none
    1968:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b00>
    196c:	f947e021 	ldr	x1, [x1, #4032]
    1970:	b4000061 	cbz	x1, 197c <deregister_tm_clones+0x2c>
    1974:	aa0103f0 	mov	x16, x1
    1978:	d61f0200 	br	x16
    197c:	d65f03c0 	ret

0000000000001980 <register_tm_clones>:
    1980:	f00000e0 	adrp	x0, 20000 <__data_start>
    1984:	91006000 	add	x0, x0, #0x18
    1988:	f00000e1 	adrp	x1, 20000 <__data_start>
    198c:	91006021 	add	x1, x1, #0x18
    1990:	cb000021 	sub	x1, x1, x0
    1994:	d37ffc22 	lsr	x2, x1, #63
    1998:	8b810c41 	add	x1, x2, x1, asr #3
    199c:	9341fc21 	asr	x1, x1, #1
    19a0:	b40000c1 	cbz	x1, 19b8 <register_tm_clones+0x38>
    19a4:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x16b00>
    19a8:	f947fc42 	ldr	x2, [x2, #4088]
    19ac:	b4000062 	cbz	x2, 19b8 <register_tm_clones+0x38>
    19b0:	aa0203f0 	mov	x16, x2
    19b4:	d61f0200 	br	x16
    19b8:	d65f03c0 	ret
    19bc:	d503201f 	nop

00000000000019c0 <__do_global_dtors_aux>:
    19c0:	d503233f 	paciasp
    19c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    19c8:	910003fd 	mov	x29, sp
    19cc:	f9000bf3 	str	x19, [sp, #16]
    19d0:	f00000f3 	adrp	x19, 20000 <__data_start>
    19d4:	39408260 	ldrb	w0, [x19, #32]
    19d8:	37000140 	tbnz	w0, #0, 1a00 <__do_global_dtors_aux+0x40>
    19dc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    19e0:	f947e400 	ldr	x0, [x0, #4040]
    19e4:	b4000080 	cbz	x0, 19f4 <__do_global_dtors_aux+0x34>
    19e8:	f00000e0 	adrp	x0, 20000 <__data_start>
    19ec:	f9400400 	ldr	x0, [x0, #8]
    19f0:	97fffe7c 	bl	13e0 <__cxa_finalize@plt>
    19f4:	97ffffd7 	bl	1950 <deregister_tm_clones>
    19f8:	52800020 	mov	w0, #0x1                   	// #1
    19fc:	39008260 	strb	w0, [x19, #32]
    1a00:	f9400bf3 	ldr	x19, [sp, #16]
    1a04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a08:	d50323bf 	autiasp
    1a0c:	d65f03c0 	ret

0000000000001a10 <frame_dummy>:
    1a10:	d503245f 	bti	c
    1a14:	17ffffdb 	b	1980 <register_tm_clones>
    1a18:	d503201f 	nop
    1a1c:	d503201f 	nop

0000000000001a20 <fwp_fmt_u128>:
    1a20:	d10183ff 	sub	sp, sp, #0x60
    1a24:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b00>
    1a28:	f947f421 	ldr	x1, [x1, #4072]
    1a2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    1a30:	910143fd 	add	x29, sp, #0x50
    1a34:	f9400024 	ldr	x4, [x1]
    1a38:	f90027e4 	str	x4, [sp, #72]
    1a3c:	d2800004 	mov	x4, #0x0                   	// #0
    1a40:	aa030041 	orr	x1, x2, x3
    1a44:	b5000361 	cbnz	x1, 1ab0 <fwp_fmt_u128+0x90>
    1a48:	910023e9 	add	x9, sp, #0x8
    1a4c:	52800601 	mov	w1, #0x30                  	// #48
    1a50:	5280002d 	mov	w13, #0x1                   	// #1
    1a54:	390023e1 	strb	w1, [sp, #8]
    1a58:	93407dad 	sxtw	x13, w13
    1a5c:	aa0d03e1 	mov	x1, x13
    1a60:	8b0d0004 	add	x4, x0, x13
    1a64:	d503201f 	nop
    1a68:	8b010123 	add	x3, x9, x1
    1a6c:	cb0103e2 	neg	x2, x1
    1a70:	d1000421 	sub	x1, x1, #0x1
    1a74:	385ff063 	ldurb	w3, [x3, #-1]
    1a78:	38226883 	strb	w3, [x4, x2]
    1a7c:	35ffff61 	cbnz	w1, 1a68 <fwp_fmt_u128+0x48>
    1a80:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b00>
    1a84:	f947f421 	ldr	x1, [x1, #4072]
    1a88:	382d681f 	strb	wzr, [x0, x13]
    1a8c:	aa0103e0 	mov	x0, x1
    1a90:	f94027e2 	ldr	x2, [sp, #72]
    1a94:	f9400001 	ldr	x1, [x0]
    1a98:	eb010042 	subs	x2, x2, x1
    1a9c:	d2800001 	mov	x1, #0x0                   	// #0
    1aa0:	54000561 	b.ne	1b4c <fwp_fmt_u128+0x12c>  // b.any
    1aa4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1aa8:	910183ff 	add	sp, sp, #0x60
    1aac:	d65f03c0 	ret
    1ab0:	d0000021 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    1ab4:	910f8021 	add	x1, x1, #0x3e0
    1ab8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1abc:	910023e9 	add	x9, sp, #0x8
    1ac0:	d2800027 	mov	x7, #0x1                   	// #1
    1ac4:	f29999af 	movk	x15, #0xcccd
    1ac8:	a9402826 	ldp	x6, x10, [x1]
    1acc:	d503201f 	nop
    1ad0:	ab030041 	adds	x1, x2, x3
    1ad4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1ad8:	aa0303eb 	mov	x11, x3
    1adc:	8b070128 	add	x8, x9, x7
    1ae0:	aa0203ee 	mov	x14, x2
    1ae4:	aa0703ed 	mov	x13, x7
    1ae8:	910004e7 	add	x7, x7, #0x1
    1aec:	9bcf7c24 	umulh	x4, x1, x15
    1af0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1af4:	8b4408a4 	add	x4, x5, x4, lsr #2
    1af8:	cb040021 	sub	x1, x1, x4
    1afc:	eb010041 	subs	x1, x2, x1
    1b00:	da1f0063 	sbc	x3, x3, xzr
    1b04:	9bc67c24 	umulh	x4, x1, x6
    1b08:	9b061064 	madd	x4, x3, x6, x4
    1b0c:	9b067c2c 	mul	x12, x1, x6
    1b10:	9b0a1024 	madd	x4, x1, x10, x4
    1b14:	9bc67c25 	umulh	x5, x1, x6
    1b18:	9b061465 	madd	x5, x3, x6, x5
    1b1c:	9b0a1425 	madd	x5, x1, x10, x5
    1b20:	93cc0484 	extr	x4, x4, x12, #1
    1b24:	8b040884 	add	x4, x4, x4, lsl #2
    1b28:	d341fca3 	lsr	x3, x5, #1
    1b2c:	cb040444 	sub	x4, x2, x4, lsl #1
    1b30:	93cc04a2 	extr	x2, x5, x12, #1
    1b34:	1100c084 	add	w4, w4, #0x30
    1b38:	381ff104 	sturb	w4, [x8, #-1]
    1b3c:	b5fffcab 	cbnz	x11, 1ad0 <fwp_fmt_u128+0xb0>
    1b40:	f10025df 	cmp	x14, #0x9
    1b44:	54fffc68 	b.hi	1ad0 <fwp_fmt_u128+0xb0>  // b.pmore
    1b48:	17ffffc4 	b	1a58 <fwp_fmt_u128+0x38>
    1b4c:	97fffe69 	bl	14f0 <__stack_chk_fail@plt>

0000000000001b50 <fwp_range_release>:
    1b50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b54:	910003fd 	mov	x29, sp
    1b58:	f9400801 	ldr	x1, [x0, #16]
    1b5c:	f9000bf3 	str	x19, [sp, #16]
    1b60:	aa0003f3 	mov	x19, x0
    1b64:	b4000061 	cbz	x1, 1b70 <fwp_range_release+0x20>
    1b68:	f9400400 	ldr	x0, [x0, #8]
    1b6c:	d63f0020 	blr	x1
    1b70:	f9400260 	ldr	x0, [x19]
    1b74:	f9400e61 	ldr	x1, [x19, #24]
    1b78:	f9400bf3 	ldr	x19, [sp, #16]
    1b7c:	aa0103f0 	mov	x16, x1
    1b80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1b84:	d61f0200 	br	x16
    1b88:	d503201f 	nop
    1b8c:	d503201f 	nop

0000000000001b90 <fwp_owned_entry32>:
    1b90:	6d400001 	ldp	d1, d0, [x0]
    1b94:	1e613800 	fsub	d0, d0, d1
    1b98:	9e660000 	fmov	x0, d0
    1b9c:	d65f03c0 	ret

0000000000001ba0 <fwp_args32>:
    1ba0:	d65f03c0 	ret

0000000000001ba4 <fwp_owned_entry45>:
    1ba4:	6d400400 	ldp	d0, d1, [x0]
    1ba8:	1e612800 	fadd	d0, d0, d1
    1bac:	9e660000 	fmov	x0, d0
    1bb0:	d65f03c0 	ret

0000000000001bb4 <fwp_owned_entry69>:
    1bb4:	d0000021 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    1bb8:	fd400001 	ldr	d1, [x0]
    1bbc:	fd420820 	ldr	d0, [x1, #1040]
    1bc0:	1e610800 	fmul	d0, d0, d1
    1bc4:	9e660000 	fmov	x0, d0
    1bc8:	d65f03c0 	ret
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_flush>:
    1bd0:	f00000e0 	adrp	x0, 20000 <__data_start>
    1bd4:	f9401800 	ldr	x0, [x0, #48]
    1bd8:	b4000120 	cbz	x0, 1bfc <fwp_flush+0x2c>
    1bdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1be0:	910003fd 	mov	x29, sp
    1be4:	97fffe8f 	bl	1620 <fflush@plt>
    1be8:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    1bec:	f947ec00 	ldr	x0, [x0, #4056]
    1bf0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1bf4:	f9400000 	ldr	x0, [x0]
    1bf8:	17fffe8a 	b	1620 <fflush@plt>
    1bfc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    1c00:	f947ec00 	ldr	x0, [x0, #4056]
    1c04:	f9400000 	ldr	x0, [x0]
    1c08:	17fffe86 	b	1620 <fflush@plt>
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_heap_oom>:
    1c10:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x16b00>
    1c14:	f947e863 	ldr	x3, [x3, #4048]
    1c18:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1c1c:	d2800262 	mov	x2, #0x13                  	// #19
    1c20:	910003fd 	mov	x29, sp
    1c24:	f9400063 	ldr	x3, [x3]
    1c28:	d2800021 	mov	x1, #0x1                   	// #1
    1c2c:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x3f0>
    1c30:	913b2000 	add	x0, x0, #0xec8
    1c34:	97fffe6f 	bl	15f0 <fwrite@plt>
    1c38:	d2800000 	mov	x0, #0x0                   	// #0
    1c3c:	97fffe79 	bl	1620 <fflush@plt>
    1c40:	52800cc0 	mov	w0, #0x66                  	// #102
    1c44:	97fffe87 	bl	1660 <_Exit@plt>
    1c48:	d503201f 	nop
    1c4c:	d503201f 	nop

0000000000001c50 <fwp_segv>:
    1c50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c54:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c58:	9100c043 	add	x3, x2, #0x30
    1c5c:	910003fd 	mov	x29, sp
    1c60:	a90153f3 	stp	x19, x20, [sp, #16]
    1c64:	2a0003f3 	mov	w19, w0
    1c68:	f9400460 	ldr	x0, [x3, #8]
    1c6c:	f90013f5 	str	x21, [sp, #32]
    1c70:	f9400835 	ldr	x21, [x1, #16]
    1c74:	b4000280 	cbz	x0, 1cc4 <fwp_segv+0x74>
    1c78:	f9400814 	ldr	x20, [x0, #16]
    1c7c:	b4000254 	cbz	x20, 1cc4 <fwp_segv+0x74>
    1c80:	528003c0 	mov	w0, #0x1e                  	// #30
    1c84:	97fffe6f 	bl	1640 <sysconf@plt>
    1c88:	f144029f 	cmp	x20, #0x100, lsl #12
    1c8c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c90:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c94:	8b000294 	add	x20, x20, x0
    1c98:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c9c:	eb0102bf 	cmp	x21, x1
    1ca0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1ca4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1ca8:	35000240 	cbnz	w0, 1cf0 <fwp_segv+0xa0>
    1cac:	f94013f5 	ldr	x21, [sp, #32]
    1cb0:	2a1303e0 	mov	w0, w19
    1cb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1cb8:	d2800001 	mov	x1, #0x0                   	// #0
    1cbc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1cc0:	17fffde4 	b	1450 <signal@plt>
    1cc4:	9100c042 	add	x2, x2, #0x30
    1cc8:	f9400840 	ldr	x0, [x2, #16]
    1ccc:	b4ffff00 	cbz	x0, 1cac <fwp_segv+0x5c>
    1cd0:	f9400c41 	ldr	x1, [x2, #24]
    1cd4:	cb010000 	sub	x0, x0, x1
    1cd8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1cdc:	91440000 	add	x0, x0, #0x100, lsl #12
    1ce0:	eb15003f 	cmp	x1, x21
    1ce4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1ce8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1cec:	34fffe00 	cbz	w0, 1cac <fwp_segv+0x5c>
    1cf0:	97ffffb8 	bl	1bd0 <fwp_flush>
    1cf4:	d0000021 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    1cf8:	910f0021 	add	x1, x1, #0x3c0
    1cfc:	d2800342 	mov	x2, #0x1a                  	// #26
    1d00:	52800040 	mov	w0, #0x2                   	// #2
    1d04:	97fffe0b 	bl	1530 <write@plt>
    1d08:	52800ca0 	mov	w0, #0x65                  	// #101
    1d0c:	97fffd99 	bl	1370 <_exit@plt>

0000000000001d10 <fwp_heap_chunks>:
    1d10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d14:	910003fd 	mov	x29, sp
    1d18:	a90153f3 	stp	x19, x20, [sp, #16]
    1d1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1d20:	90000195 	adrp	x21, 31000 <fwp_root_context+0xd10>
    1d24:	911342a1 	add	x1, x21, #0x4d0
    1d28:	f100041f 	cmp	x0, #0x1
    1d2c:	54000ca0 	b.eq	1ec0 <fwp_heap_chunks+0x1b0>  // b.none
    1d30:	f949f822 	ldr	x2, [x1, #5104]
    1d34:	b0000185 	adrp	x5, 32000 <fwp_heap+0xb30>
    1d38:	912300a5 	add	x5, x5, #0x8c0
    1d3c:	911342a1 	add	x1, x21, #0x4d0
    1d40:	f949ec34 	ldr	x20, [x1, #5080]
    1d44:	eb14005f 	cmp	x2, x20
    1d48:	54000c42 	b.cs	1ed0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1d4c:	f949fc23 	ldr	x3, [x1, #5112]
    1d50:	8b020841 	add	x1, x2, x2, lsl #2
    1d54:	d2800004 	mov	x4, #0x0                   	// #0
    1d58:	8b010c61 	add	x1, x3, x1, lsl #3
    1d5c:	14000009 	b	1d80 <fwp_heap_chunks+0x70>
    1d60:	91000483 	add	x3, x4, #0x1
    1d64:	eb03001f 	cmp	x0, x3
    1d68:	54000940 	b.eq	1e90 <fwp_heap_chunks+0x180>  // b.none
    1d6c:	91000442 	add	x2, x2, #0x1
    1d70:	aa0303e4 	mov	x4, x3
    1d74:	9100a021 	add	x1, x1, #0x28
    1d78:	eb02029f 	cmp	x20, x2
    1d7c:	54000100 	b.eq	1d9c <fwp_heap_chunks+0x8c>  // b.none
    1d80:	39400023 	ldrb	w3, [x1]
    1d84:	34fffee3 	cbz	w3, 1d60 <fwp_heap_chunks+0x50>
    1d88:	91000442 	add	x2, x2, #0x1
    1d8c:	9100a021 	add	x1, x1, #0x28
    1d90:	d2800004 	mov	x4, #0x0                   	// #0
    1d94:	eb02029f 	cmp	x20, x2
    1d98:	54ffff41 	b.ne	1d80 <fwp_heap_chunks+0x70>  // b.any
    1d9c:	cb040294 	sub	x20, x20, x4
    1da0:	f9001bf7 	str	x23, [sp, #48]
    1da4:	911342b7 	add	x23, x21, #0x4d0
    1da8:	8b140013 	add	x19, x0, x20
    1dac:	f94a1ae1 	ldr	x1, [x23, #5168]
    1db0:	f949f2e0 	ldr	x0, [x23, #5088]
    1db4:	cb040021 	sub	x1, x1, x4
    1db8:	f90a1ae1 	str	x1, [x23, #5168]
    1dbc:	eb00027f 	cmp	x19, x0
    1dc0:	54000429 	b.ls	1e44 <fwp_heap_chunks+0x134>  // b.plast
    1dc4:	f949eae1 	ldr	x1, [x23, #5072]
    1dc8:	eb01027f 	cmp	x19, x1
    1dcc:	54000888 	b.hi	1edc <fwp_heap_chunks+0x1cc>  // b.pmore
    1dd0:	91010276 	add	x22, x19, #0x40
    1dd4:	52800062 	mov	w2, #0x3                   	// #3
    1dd8:	f949dae3 	ldr	x3, [x23, #5040]
    1ddc:	eb0102df 	cmp	x22, x1
    1de0:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1de4:	cb0002c1 	sub	x1, x22, x0
    1de8:	8b004060 	add	x0, x3, x0, lsl #16
    1dec:	d370bc21 	lsl	x1, x1, #16
    1df0:	97fffe28 	bl	1690 <mprotect@plt>
    1df4:	35000740 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1df8:	528003c0 	mov	w0, #0x1e                  	// #30
    1dfc:	97fffe11 	bl	1640 <sysconf@plt>
    1e00:	f949f2e2 	ldr	x2, [x23, #5088]
    1e04:	cb0003e5 	neg	x5, x0
    1e08:	aa0003e4 	mov	x4, x0
    1e0c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e10:	f949fee0 	ldr	x0, [x23, #5112]
    1e14:	8b020843 	add	x3, x2, x2, lsl #2
    1e18:	52800062 	mov	w2, #0x3                   	// #3
    1e1c:	8b010c01 	add	x1, x0, x1, lsl #3
    1e20:	8b030c03 	add	x3, x0, x3, lsl #3
    1e24:	d1000421 	sub	x1, x1, #0x1
    1e28:	8a050060 	and	x0, x3, x5
    1e2c:	8b040021 	add	x1, x1, x4
    1e30:	8a050021 	and	x1, x1, x5
    1e34:	cb000021 	sub	x1, x1, x0
    1e38:	97fffe16 	bl	1690 <mprotect@plt>
    1e3c:	35000500 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1e40:	f909f2f6 	str	x22, [x23, #5088]
    1e44:	911342b5 	add	x21, x21, #0x4d0
    1e48:	d370be60 	lsl	x0, x19, #16
    1e4c:	f949e6a1 	ldr	x1, [x21, #5064]
    1e50:	f909eeb3 	str	x19, [x21, #5080]
    1e54:	eb01001f 	cmp	x0, x1
    1e58:	540000e8 	b.hi	1e74 <fwp_heap_chunks+0x164>  // b.pmore
    1e5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e60:	aa1403e0 	mov	x0, x20
    1e64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e68:	f9401bf7 	ldr	x23, [sp, #48]
    1e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e70:	d65f03c0 	ret
    1e74:	f9401bf7 	ldr	x23, [sp, #48]
    1e78:	f909e6a0 	str	x0, [x21, #5064]
    1e7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e80:	aa1403e0 	mov	x0, x20
    1e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e88:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e8c:	d65f03c0 	ret
    1e90:	911342b5 	add	x21, x21, #0x4d0
    1e94:	91000441 	add	x1, x2, #0x1
    1e98:	f90000a1 	str	x1, [x5]
    1e9c:	cb040054 	sub	x20, x2, x4
    1ea0:	f94a1aa1 	ldr	x1, [x21, #5168]
    1ea4:	cb000020 	sub	x0, x1, x0
    1ea8:	f90a1aa0 	str	x0, [x21, #5168]
    1eac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1eb0:	aa1403e0 	mov	x0, x20
    1eb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1eb8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ebc:	d65f03c0 	ret
    1ec0:	f949f422 	ldr	x2, [x1, #5096]
    1ec4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xb30>
    1ec8:	9122e0a5 	add	x5, x5, #0x8b8
    1ecc:	17ffff9c 	b	1d3c <fwp_heap_chunks+0x2c>
    1ed0:	d2800004 	mov	x4, #0x0                   	// #0
    1ed4:	f9001bf7 	str	x23, [sp, #48]
    1ed8:	17ffffb3 	b	1da4 <fwp_heap_chunks+0x94>
    1edc:	97ffff4d 	bl	1c10 <fwp_heap_oom>

0000000000001ee0 <buf_grow>:
    1ee0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1ee4:	910003fd 	mov	x29, sp
    1ee8:	a90153f3 	stp	x19, x20, [sp, #16]
    1eec:	aa0003f4 	mov	x20, x0
    1ef0:	f9400400 	ldr	x0, [x0, #8]
    1ef4:	b100041f 	cmn	x0, #0x1
    1ef8:	54000400 	b.eq	1f78 <buf_grow+0x98>  // b.none
    1efc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    1f00:	cb000042 	sub	x2, x2, x0
    1f04:	eb01005f 	cmp	x2, x1
    1f08:	54000383 	b.cc	1f78 <buf_grow+0x98>  // b.lo, b.ul, b.last
    1f0c:	f9400a82 	ldr	x2, [x20, #16]
    1f10:	91000421 	add	x1, x1, #0x1
    1f14:	8b000033 	add	x19, x1, x0
    1f18:	eb13005f 	cmp	x2, x19
    1f1c:	54000242 	b.cs	1f64 <buf_grow+0x84>  // b.hs, b.nlast
    1f20:	f100005f 	cmp	x2, #0x0
    1f24:	b5000262 	cbnz	x2, 1f70 <buf_grow+0x90>
    1f28:	d2800802 	mov	x2, #0x40                  	// #64
    1f2c:	eb02027f 	cmp	x19, x2
    1f30:	54000068 	b.hi	1f3c <buf_grow+0x5c>  // b.pmore
    1f34:	14000005 	b	1f48 <buf_grow+0x68>
    1f38:	b7f800a2 	tbnz	x2, #63, 1f4c <buf_grow+0x6c>
    1f3c:	d37ff842 	lsl	x2, x2, #1
    1f40:	eb02027f 	cmp	x19, x2
    1f44:	54ffffa8 	b.hi	1f38 <buf_grow+0x58>  // b.pmore
    1f48:	aa0203f3 	mov	x19, x2
    1f4c:	f9400280 	ldr	x0, [x20]
    1f50:	aa1303e1 	mov	x1, x19
    1f54:	97fffd63 	bl	14e0 <realloc@plt>
    1f58:	b4000100 	cbz	x0, 1f78 <buf_grow+0x98>
    1f5c:	f9000280 	str	x0, [x20]
    1f60:	f9000a93 	str	x19, [x20, #16]
    1f64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f68:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1f6c:	d65f03c0 	ret
    1f70:	54fffe6a 	b.ge	1f3c <buf_grow+0x5c>  // b.tcont
    1f74:	17fffff6 	b	1f4c <buf_grow+0x6c>
    1f78:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x16b00>
    1f7c:	f947e863 	ldr	x3, [x3, #4048]
    1f80:	d2800262 	mov	x2, #0x13                  	// #19
    1f84:	d2800021 	mov	x1, #0x1                   	// #1
    1f88:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x3f0>
    1f8c:	913b2000 	add	x0, x0, #0xec8
    1f90:	f9400063 	ldr	x3, [x3]
    1f94:	97fffd97 	bl	15f0 <fwrite@plt>
    1f98:	d2800000 	mov	x0, #0x0                   	// #0
    1f9c:	97fffda1 	bl	1620 <fflush@plt>
    1fa0:	52800cc0 	mov	w0, #0x66                  	// #102
    1fa4:	97fffdaf 	bl	1660 <_Exit@plt>
    1fa8:	d503201f 	nop
    1fac:	d503201f 	nop

0000000000001fb0 <buf_put>:
    1fb0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1fb4:	910003fd 	mov	x29, sp
    1fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    1fbc:	aa0003f4 	mov	x20, x0
    1fc0:	aa0203f3 	mov	x19, x2
    1fc4:	f90013f5 	str	x21, [sp, #32]
    1fc8:	aa0103f5 	mov	x21, x1
    1fcc:	aa0203e1 	mov	x1, x2
    1fd0:	97ffffc4 	bl	1ee0 <buf_grow>
    1fd4:	a9400283 	ldp	x3, x0, [x20]
    1fd8:	aa1503e1 	mov	x1, x21
    1fdc:	aa1303e2 	mov	x2, x19
    1fe0:	8b000060 	add	x0, x3, x0
    1fe4:	97fffcdb 	bl	1350 <memcpy@plt>
    1fe8:	a9400680 	ldp	x0, x1, [x20]
    1fec:	8b010273 	add	x19, x19, x1
    1ff0:	f9000693 	str	x19, [x20, #8]
    1ff4:	3833681f 	strb	wzr, [x0, x19]
    1ff8:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ffc:	f94013f5 	ldr	x21, [sp, #32]
    2000:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2004:	d65f03c0 	ret
    2008:	d503201f 	nop
    200c:	d503201f 	nop

0000000000002010 <fwp_cancel_tree.part.0>:
    2010:	d00000e1 	adrp	x1, 20000 <__data_start>
    2014:	9100c022 	add	x2, x1, #0x30
    2018:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    201c:	52800023 	mov	w3, #0x1                   	// #1
    2020:	910003fd 	mov	x29, sp
    2024:	f9400444 	ldr	x4, [x2, #8]
    2028:	f9000bf3 	str	x19, [sp, #16]
    202c:	39014403 	strb	w3, [x0, #81]
    2030:	eb04001f 	cmp	x0, x4
    2034:	54000160 	b.eq	2060 <fwp_cancel_tree.part.0+0x50>  // b.none
    2038:	f9402804 	ldr	x4, [x0, #80]
    203c:	f2001c9f 	tst	x4, #0xff000000ff
    2040:	54000101 	b.ne	2060 <fwp_cancel_tree.part.0+0x50>  // b.any
    2044:	f9401044 	ldr	x4, [x2, #32]
    2048:	39015003 	strb	w3, [x0, #84]
    204c:	f900801f 	str	xzr, [x0, #256]
    2050:	b40001e4 	cbz	x4, 208c <fwp_cancel_tree.part.0+0x7c>
    2054:	f9008080 	str	x0, [x4, #256]
    2058:	9100c021 	add	x1, x1, #0x30
    205c:	f9001020 	str	x0, [x1, #32]
    2060:	f9401413 	ldr	x19, [x0, #40]
    2064:	b40000f3 	cbz	x19, 2080 <fwp_cancel_tree.part.0+0x70>
    2068:	39414261 	ldrb	w1, [x19, #80]
    206c:	aa1303e0 	mov	x0, x19
    2070:	37000041 	tbnz	w1, #0, 2078 <fwp_cancel_tree.part.0+0x68>
    2074:	97ffffe7 	bl	2010 <fwp_cancel_tree.part.0>
    2078:	f9401a73 	ldr	x19, [x19, #48]
    207c:	b5ffff73 	cbnz	x19, 2068 <fwp_cancel_tree.part.0+0x58>
    2080:	f9400bf3 	ldr	x19, [sp, #16]
    2084:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2088:	d65f03c0 	ret
    208c:	f9001440 	str	x0, [x2, #40]
    2090:	17fffff2 	b	2058 <fwp_cancel_tree.part.0+0x48>

0000000000002094 <fwp_finish_float>:
    2094:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2098:	528005c1 	mov	w1, #0x2e                  	// #46
    209c:	910003fd 	mov	x29, sp
    20a0:	f9000bf3 	str	x19, [sp, #16]
    20a4:	aa0003f3 	mov	x19, x0
    20a8:	97fffd4a 	bl	15d0 <strchr@plt>
    20ac:	b4000080 	cbz	x0, 20bc <fwp_finish_float+0x28>
    20b0:	f9400bf3 	ldr	x19, [sp, #16]
    20b4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    20b8:	d65f03c0 	ret
    20bc:	aa1303e0 	mov	x0, x19
    20c0:	52800ca1 	mov	w1, #0x65                  	// #101
    20c4:	97fffd43 	bl	15d0 <strchr@plt>
    20c8:	b5ffff40 	cbnz	x0, 20b0 <fwp_finish_float+0x1c>
    20cc:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x3f0>
    20d0:	aa1303e0 	mov	x0, x19
    20d4:	913b8021 	add	x1, x1, #0xee0
    20d8:	97fffd5e 	bl	1650 <strstr@plt>
    20dc:	b5fffea0 	cbnz	x0, 20b0 <fwp_finish_float+0x1c>
    20e0:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x3f0>
    20e4:	aa1303e0 	mov	x0, x19
    20e8:	913ba021 	add	x1, x1, #0xee8
    20ec:	97fffd59 	bl	1650 <strstr@plt>
    20f0:	b5fffe00 	cbnz	x0, 20b0 <fwp_finish_float+0x1c>
    20f4:	aa1303e0 	mov	x0, x19
    20f8:	97fffca2 	bl	1380 <strlen@plt>
    20fc:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x3f0>
    2100:	913bc021 	add	x1, x1, #0xef0
    2104:	8b000262 	add	x2, x19, x0
    2108:	79400023 	ldrh	w3, [x1]
    210c:	39400821 	ldrb	w1, [x1, #2]
    2110:	78206a63 	strh	w3, [x19, x0]
    2114:	39000841 	strb	w1, [x2, #2]
    2118:	17ffffe6 	b	20b0 <fwp_finish_float+0x1c>
    211c:	d503201f 	nop

0000000000002120 <fwp_trap>:
    2120:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2124:	910003fd 	mov	x29, sp
    2128:	f9000bf3 	str	x19, [sp, #16]
    212c:	aa0003f3 	mov	x19, x0
    2130:	97fffea8 	bl	1bd0 <fwp_flush>
    2134:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x16b00>
    2138:	f947e884 	ldr	x4, [x4, #4048]
    213c:	aa1303e3 	mov	x3, x19
    2140:	90000022 	adrp	x2, 6000 <fwp_main_thread+0x3f0>
    2144:	913be042 	add	x2, x2, #0xef8
    2148:	52800041 	mov	w1, #0x2                   	// #2
    214c:	f9400080 	ldr	x0, [x4]
    2150:	97fffd04 	bl	1560 <__fprintf_chk@plt>
    2154:	52800ca0 	mov	w0, #0x65                  	// #101
    2158:	97fffc92 	bl	13a0 <exit@plt>
    215c:	d503201f 	nop

0000000000002160 <fwp_now_ns>:
    2160:	d100c3ff 	sub	sp, sp, #0x30
    2164:	52800020 	mov	w0, #0x1                   	// #1
    2168:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x16b00>
    216c:	f947f442 	ldr	x2, [x2, #4072]
    2170:	910023e1 	add	x1, sp, #0x8
    2174:	a9027bfd 	stp	x29, x30, [sp, #32]
    2178:	910083fd 	add	x29, sp, #0x20
    217c:	f9400043 	ldr	x3, [x2]
    2180:	f9000fe3 	str	x3, [sp, #24]
    2184:	d2800003 	mov	x3, #0x0                   	// #0
    2188:	97fffca6 	bl	1420 <clock_gettime@plt>
    218c:	350002c0 	cbnz	w0, 21e4 <fwp_now_ns+0x84>
    2190:	a9408be1 	ldp	x1, x2, [sp, #8]
    2194:	d2994003 	mov	x3, #0xca00                	// #51712
    2198:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    219c:	9b037c20 	mul	x0, x1, x3
    21a0:	9b437c21 	smulh	x1, x1, x3
    21a4:	ab020000 	adds	x0, x0, x2
    21a8:	937ffc42 	asr	x2, x2, #63
    21ac:	9a020021 	adc	x1, x1, x2
    21b0:	f100001f 	cmp	x0, #0x0
    21b4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    21b8:	b50001e1 	cbnz	x1, 21f4 <fwp_now_ns+0x94>
    21bc:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b00>
    21c0:	f947f421 	ldr	x1, [x1, #4072]
    21c4:	f9400fe3 	ldr	x3, [sp, #24]
    21c8:	f9400022 	ldr	x2, [x1]
    21cc:	eb020063 	subs	x3, x3, x2
    21d0:	d2800002 	mov	x2, #0x0                   	// #0
    21d4:	540000e1 	b.ne	21f0 <fwp_now_ns+0x90>  // b.any
    21d8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    21dc:	9100c3ff 	add	sp, sp, #0x30
    21e0:	d65f03c0 	ret
    21e4:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x3f0>
    21e8:	913c2000 	add	x0, x0, #0xf08
    21ec:	97ffffcd 	bl	2120 <fwp_trap>
    21f0:	97fffcc0 	bl	14f0 <__stack_chk_fail@plt>
    21f4:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x3f0>
    21f8:	913ca000 	add	x0, x0, #0xf28
    21fc:	97ffffc9 	bl	2120 <fwp_trap>

0000000000002200 <fwp_args74>:
    2200:	d65f03c0 	ret

0000000000002204 <fwp_format_g.constprop.0>:
    2204:	d10483ff 	sub	sp, sp, #0x120
    2208:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x3f0>
    220c:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x16b00>
    2210:	f947f442 	ldr	x2, [x2, #4072]
    2214:	913d4084 	add	x4, x4, #0xf50
    2218:	a90b7bfd 	stp	x29, x30, [sp, #176]
    221c:	9102c3fd 	add	x29, sp, #0xb0
    2220:	d2800803 	mov	x3, #0x40                  	// #64
    2224:	a90e63f7 	stp	x23, x24, [sp, #224]
    2228:	93407c38 	sxtw	x24, w1
    222c:	aa0303e1 	mov	x1, x3
    2230:	fd008be8 	str	d8, [sp, #272]
    2234:	1e604008 	fmov	d8, d0
    2238:	a90c53f3 	stp	x19, x20, [sp, #192]
    223c:	910083f4 	add	x20, sp, #0x20
    2240:	a90d5bf5 	stp	x21, x22, [sp, #208]
    2244:	aa0003f5 	mov	x21, x0
    2248:	a91073fb 	stp	x27, x28, [sp, #256]
    224c:	5100071c 	sub	w28, w24, #0x1
    2250:	2a1c03e5 	mov	w5, w28
    2254:	f9400040 	ldr	x0, [x2]
    2258:	f90057e0 	str	x0, [sp, #168]
    225c:	d2800000 	mov	x0, #0x0                   	// #0
    2260:	52800042 	mov	w2, #0x2                   	// #2
    2264:	aa1403e0 	mov	x0, x20
    2268:	97fffc7e 	bl	1460 <__snprintf_chk@plt>
    226c:	52800ca1 	mov	w1, #0x65                  	// #101
    2270:	aa1403e0 	mov	x0, x20
    2274:	97fffcd7 	bl	15d0 <strchr@plt>
    2278:	aa0003f3 	mov	x19, x0
    227c:	52800142 	mov	w2, #0xa                   	// #10
    2280:	91000400 	add	x0, x0, #0x1
    2284:	d2800001 	mov	x1, #0x0                   	// #0
    2288:	97fffcc2 	bl	1590 <strtol@plt>
    228c:	aa0003f7 	mov	x23, x0
    2290:	11001400 	add	w0, w0, #0x5
    2294:	7100541f 	cmp	w0, #0x15
    2298:	54000d88 	b.hi	2448 <fwp_format_g.constprop.0+0x244>  // b.pmore
    229c:	4b170385 	sub	w5, w28, w23
    22a0:	710000bf 	cmp	w5, #0x0
    22a4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    22a8:	54000ba0 	b.eq	241c <fwp_format_g.constprop.0+0x218>  // b.none
    22ac:	394083e0 	ldrb	w0, [sp, #32]
    22b0:	cb180273 	sub	x19, x19, x24
    22b4:	91000673 	add	x19, x19, #0x1
    22b8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    22bc:	7100b41f 	cmp	w0, #0x2d
    22c0:	9a941681 	cinc	x1, x20, eq	// eq = none
    22c4:	1a9f17e4 	cset	w4, eq	// eq = none
    22c8:	cb010266 	sub	x6, x19, x1
    22cc:	d10004da 	sub	x26, x6, #0x1
    22d0:	540018c0 	b.eq	25e8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    22d4:	910183f9 	add	x25, sp, #0x60
    22d8:	d280091b 	mov	x27, #0x48                  	// #72
    22dc:	aa1903e7 	mov	x7, x25
    22e0:	91000423 	add	x3, x1, #0x1
    22e4:	91011cc6 	add	x6, x6, #0x47
    22e8:	910004f6 	add	x22, x7, #0x1
    22ec:	37f81017 	tbnz	w23, #31, 24ec <fwp_format_g.constprop.0+0x2e8>
    22f0:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    22f4:	93407ef7 	sxtw	x23, w23
    22f8:	390000e4 	strb	w4, [x7]
    22fc:	aa1303e1 	mov	x1, x19
    2300:	aa1703e2 	mov	x2, x23
    2304:	aa1603e0 	mov	x0, x22
    2308:	b9000be5 	str	w5, [sp, #8]
    230c:	cb170374 	sub	x20, x27, x23
    2310:	a9011be3 	stp	x3, x6, [sp, #16]
    2314:	97fffc0f 	bl	1350 <memcpy@plt>
    2318:	d1000694 	sub	x20, x20, #0x1
    231c:	f9400be3 	ldr	x3, [sp, #16]
    2320:	8b1702d6 	add	x22, x22, x23
    2324:	aa1603e0 	mov	x0, x22
    2328:	aa1a03e2 	mov	x2, x26
    232c:	aa0303e1 	mov	x1, x3
    2330:	aa1403e3 	mov	x3, x20
    2334:	97fffc43 	bl	1440 <__memcpy_chk@plt>
    2338:	8b1a02d6 	add	x22, x22, x26
    233c:	f9400fe6 	ldr	x6, [sp, #24]
    2340:	d2800900 	mov	x0, #0x48                  	// #72
    2344:	b9400be5 	ldr	w5, [sp, #8]
    2348:	8b170261 	add	x1, x19, x23
    234c:	cb1400c3 	sub	x3, x6, x20
    2350:	cb060294 	sub	x20, x20, x6
    2354:	f101207f 	cmp	x3, #0x48
    2358:	93407cb8 	sxtw	x24, w5
    235c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2360:	aa1803e2 	mov	x2, x24
    2364:	8b1802d3 	add	x19, x22, x24
    2368:	8b140063 	add	x3, x3, x20
    236c:	aa1603e0 	mov	x0, x22
    2370:	97fffc34 	bl	1440 <__memcpy_chk@plt>
    2374:	cb190273 	sub	x19, x19, x25
    2378:	d28031e0 	mov	x0, #0x18f                 	// #399
    237c:	eb00027f 	cmp	x19, x0
    2380:	aa1903e1 	mov	x1, x25
    2384:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    2388:	aa1503e0 	mov	x0, x21
    238c:	aa1303e2 	mov	x2, x19
    2390:	97fffbf0 	bl	1350 <memcpy@plt>
    2394:	38336abf 	strb	wzr, [x21, x19]
    2398:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    239c:	aa1503e0 	mov	x0, x21
    23a0:	97fffbf8 	bl	1380 <strlen@plt>
    23a4:	aa0003f3 	mov	x19, x0
    23a8:	528005c1 	mov	w1, #0x2e                  	// #46
    23ac:	aa1503e0 	mov	x0, x21
    23b0:	97fffc88 	bl	15d0 <strchr@plt>
    23b4:	b4000160 	cbz	x0, 23e0 <fwp_format_g.constprop.0+0x1dc>
    23b8:	b4000153 	cbz	x19, 23e0 <fwp_format_g.constprop.0+0x1dc>
    23bc:	d503201f 	nop
    23c0:	aa1303e1 	mov	x1, x19
    23c4:	d1000673 	sub	x19, x19, #0x1
    23c8:	38736aa0 	ldrb	w0, [x21, x19]
    23cc:	7100c01f 	cmp	w0, #0x30
    23d0:	54001001 	b.ne	25d0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    23d4:	38336abf 	strb	wzr, [x21, x19]
    23d8:	b5ffff53 	cbnz	x19, 23c0 <fwp_format_g.constprop.0+0x1bc>
    23dc:	d503201f 	nop
    23e0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    23e4:	f947f400 	ldr	x0, [x0, #4072]
    23e8:	f94057e2 	ldr	x2, [sp, #168]
    23ec:	f9400001 	ldr	x1, [x0]
    23f0:	eb010042 	subs	x2, x2, x1
    23f4:	d2800001 	mov	x1, #0x0                   	// #0
    23f8:	54001061 	b.ne	2604 <fwp_format_g.constprop.0+0x400>  // b.any
    23fc:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2400:	a94c53f3 	ldp	x19, x20, [sp, #192]
    2404:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2408:	a94e63f7 	ldp	x23, x24, [sp, #224]
    240c:	a95073fb 	ldp	x27, x28, [sp, #256]
    2410:	fd408be8 	ldr	d8, [sp, #272]
    2414:	910483ff 	add	sp, sp, #0x120
    2418:	d65f03c0 	ret
    241c:	1e604100 	fmov	d0, d8
    2420:	710000bf 	cmp	w5, #0x0
    2424:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2428:	aa1503e0 	mov	x0, x21
    242c:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x3f0>
    2430:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2434:	913da084 	add	x4, x4, #0xf68
    2438:	52800042 	mov	w2, #0x2                   	// #2
    243c:	d2803201 	mov	x1, #0x190                 	// #400
    2440:	97fffc08 	bl	1460 <__snprintf_chk@plt>
    2444:	17ffffd6 	b	239c <fwp_format_g.constprop.0+0x198>
    2448:	cb140273 	sub	x19, x19, x20
    244c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2450:	910183f9 	add	x25, sp, #0x60
    2454:	aa1303e2 	mov	x2, x19
    2458:	aa1403e1 	mov	x1, x20
    245c:	aa1903e0 	mov	x0, x25
    2460:	d2800803 	mov	x3, #0x40                  	// #64
    2464:	97fffbf7 	bl	1440 <__memcpy_chk@plt>
    2468:	38336b3f 	strb	wzr, [x25, x19]
    246c:	aa1903e0 	mov	x0, x25
    2470:	528005c1 	mov	w1, #0x2e                  	// #46
    2474:	97fffc57 	bl	15d0 <strchr@plt>
    2478:	b40001c0 	cbz	x0, 24b0 <fwp_format_g.constprop.0+0x2ac>
    247c:	b50000b3 	cbnz	x19, 2490 <fwp_format_g.constprop.0+0x28c>
    2480:	1400000c 	b	24b0 <fwp_format_g.constprop.0+0x2ac>
    2484:	381ff01f 	sturb	wzr, [x0, #-1]
    2488:	f1000673 	subs	x19, x19, #0x1
    248c:	54000120 	b.eq	24b0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    2490:	8b130320 	add	x0, x25, x19
    2494:	385ff001 	ldurb	w1, [x0, #-1]
    2498:	7100c03f 	cmp	w1, #0x30
    249c:	54ffff40 	b.eq	2484 <fwp_format_g.constprop.0+0x280>  // b.none
    24a0:	d1000673 	sub	x19, x19, #0x1
    24a4:	38736b20 	ldrb	w0, [x25, x19]
    24a8:	7100b81f 	cmp	w0, #0x2e
    24ac:	54000a80 	b.eq	25fc <fwp_format_g.constprop.0+0x3f8>  // b.none
    24b0:	710002ff 	cmp	w23, #0x0
    24b4:	528005a1 	mov	w1, #0x2d                  	// #45
    24b8:	aa1903e5 	mov	x5, x25
    24bc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    24c0:	aa1503e0 	mov	x0, x21
    24c4:	52800566 	mov	w6, #0x2b                  	// #43
    24c8:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x3f0>
    24cc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    24d0:	913d6084 	add	x4, x4, #0xf58
    24d4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    24d8:	52800042 	mov	w2, #0x2                   	// #2
    24dc:	d2803201 	mov	x1, #0x190                 	// #400
    24e0:	97fffbe0 	bl	1460 <__snprintf_chk@plt>
    24e4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    24e8:	17ffffbe 	b	23e0 <fwp_format_g.constprop.0+0x1dc>
    24ec:	52800605 	mov	w5, #0x30                  	// #48
    24f0:	390000e5 	strb	w5, [x7]
    24f4:	d100077b 	sub	x27, x27, #0x1
    24f8:	aa0303e1 	mov	x1, x3
    24fc:	aa1603e0 	mov	x0, x22
    2500:	aa1b03e3 	mov	x3, x27
    2504:	aa1a03e2 	mov	x2, x26
    2508:	f90007e6 	str	x6, [sp, #8]
    250c:	b90013e4 	str	w4, [sp, #16]
    2510:	8b1a02d6 	add	x22, x22, x26
    2514:	b9001be5 	str	w5, [sp, #24]
    2518:	97fffbca 	bl	1440 <__memcpy_chk@plt>
    251c:	f94007e6 	ldr	x6, [sp, #8]
    2520:	2a3703e7 	mvn	w7, w23
    2524:	b94013e4 	ldr	w4, [sp, #16]
    2528:	cb1b00c1 	sub	x1, x6, x27
    252c:	cb06037b 	sub	x27, x27, x6
    2530:	f101203f 	cmp	x1, #0x48
    2534:	d2800906 	mov	x6, #0x48                  	// #72
    2538:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    253c:	8b1b0023 	add	x3, x1, x27
    2540:	310006ff 	cmn	w23, #0x1
    2544:	54000220 	b.eq	2588 <fwp_format_g.constprop.0+0x384>  // b.none
    2548:	b9401be5 	ldr	w5, [sp, #24]
    254c:	d2800001 	mov	x1, #0x0                   	// #0
    2550:	f101207f 	cmp	x3, #0x48
    2554:	d1000462 	sub	x2, x3, #0x1
    2558:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    255c:	38216ac5 	strb	w5, [x22, x1]
    2560:	cb030003 	sub	x3, x0, x3
    2564:	91000421 	add	x1, x1, #0x1
    2568:	91000463 	add	x3, x3, #0x1
    256c:	eb00007f 	cmp	x3, x0
    2570:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2574:	cb000063 	sub	x3, x3, x0
    2578:	8b020063 	add	x3, x3, x2
    257c:	6b0100ff 	cmp	w7, w1
    2580:	54fffe8c 	b.gt	2550 <fwp_format_g.constprop.0+0x34c>
    2584:	8b2742d6 	add	x22, x22, w7, uxtw
    2588:	f101207f 	cmp	x3, #0x48
    258c:	d2800905 	mov	x5, #0x48                  	// #72
    2590:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    2594:	aa1603e0 	mov	x0, x22
    2598:	cb0300a1 	sub	x1, x5, x3
    259c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    25a0:	91000421 	add	x1, x1, #0x1
    25a4:	d1000463 	sub	x3, x3, #0x1
    25a8:	eb05003f 	cmp	x1, x5
    25ac:	38001402 	strb	w2, [x0], #1
    25b0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    25b4:	93407f82 	sxtw	x2, w28
    25b8:	cb050025 	sub	x5, x1, x5
    25bc:	aa1303e1 	mov	x1, x19
    25c0:	8b0300a3 	add	x3, x5, x3
    25c4:	8b1802d3 	add	x19, x22, x24
    25c8:	97fffb9e 	bl	1440 <__memcpy_chk@plt>
    25cc:	17ffff6a 	b	2374 <fwp_format_g.constprop.0+0x170>
    25d0:	d1000421 	sub	x1, x1, #0x1
    25d4:	38616aa0 	ldrb	w0, [x21, x1]
    25d8:	7100b81f 	cmp	w0, #0x2e
    25dc:	54fff021 	b.ne	23e0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    25e0:	38216abf 	strb	wzr, [x21, x1]
    25e4:	17ffff7f 	b	23e0 <fwp_format_g.constprop.0+0x1dc>
    25e8:	910187e7 	add	x7, sp, #0x61
    25ec:	910183f9 	add	x25, sp, #0x60
    25f0:	d28008fb 	mov	x27, #0x47                  	// #71
    25f4:	390183e0 	strb	w0, [sp, #96]
    25f8:	17ffff3a 	b	22e0 <fwp_format_g.constprop.0+0xdc>
    25fc:	38336b3f 	strb	wzr, [x25, x19]
    2600:	17ffffac 	b	24b0 <fwp_format_g.constprop.0+0x2ac>
    2604:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2608:	97fffbba 	bl	14f0 <__stack_chk_fail@plt>
    260c:	d503201f 	nop

0000000000002610 <fwp_heap_report>:
    2610:	d105c3ff 	sub	sp, sp, #0x170
    2614:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    2618:	91134042 	add	x2, x2, #0x4d0
    261c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x16b00>
    2620:	f947e821 	ldr	x1, [x1, #4048]
    2624:	a9117bfd 	stp	x29, x30, [sp, #272]
    2628:	910443fd 	add	x29, sp, #0x110
    262c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    2630:	f947f400 	ldr	x0, [x0, #4072]
    2634:	a9135bf5 	stp	x21, x22, [sp, #304]
    2638:	a91463f7 	stp	x23, x24, [sp, #320]
    263c:	a9156bf9 	stp	x25, x26, [sp, #336]
    2640:	6d1627e8 	stp	d8, d9, [sp, #352]
    2644:	fd4a1c48 	ldr	d8, [x2, #5176]
    2648:	fd4a2049 	ldr	d9, [x2, #5184]
    264c:	f9400036 	ldr	x22, [x1]
    2650:	f9400001 	ldr	x1, [x0]
    2654:	f90087e1 	str	x1, [sp, #264]
    2658:	d2800001 	mov	x1, #0x0                   	// #0
    265c:	f949e459 	ldr	x25, [x2, #5064]
    2660:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x3f0>
    2664:	f94a1057 	ldr	x23, [x2, #5152]
    2668:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x3f0>
    266c:	f94a1458 	ldr	x24, [x2, #5160]
    2670:	913dc021 	add	x1, x1, #0xf70
    2674:	913de000 	add	x0, x0, #0xf78
    2678:	97fffb82 	bl	1480 <fopen@plt>
    267c:	b4000740 	cbz	x0, 2764 <fwp_heap_report+0x154>
    2680:	528daad5 	mov	w21, #0x6d56                	// #27990
    2684:	a91253f3 	stp	x19, x20, [sp, #288]
    2688:	aa0003f4 	mov	x20, x0
    268c:	910023f3 	add	x19, sp, #0x8
    2690:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2694:	72aae915 	movk	w21, #0x5748, lsl #16
    2698:	aa1403e2 	mov	x2, x20
    269c:	aa1303e0 	mov	x0, x19
    26a0:	52802001 	mov	w1, #0x100                 	// #256
    26a4:	97fffbff 	bl	16a0 <fgets@plt>
    26a8:	b4000280 	cbz	x0, 26f8 <fwp_heap_report+0xe8>
    26ac:	b9400261 	ldr	w1, [x19]
    26b0:	6b15003f 	cmp	w1, w21
    26b4:	54ffff21 	b.ne	2698 <fwp_heap_report+0x88>  // b.any
    26b8:	39401260 	ldrb	w0, [x19, #4]
    26bc:	7101341f 	cmp	w0, #0x4d
    26c0:	54fffec1 	b.ne	2698 <fwp_heap_report+0x88>  // b.any
    26c4:	394037e0 	ldrb	w0, [sp, #13]
    26c8:	7100e81f 	cmp	w0, #0x3a
    26cc:	54fffe61 	b.ne	2698 <fwp_heap_report+0x88>  // b.any
    26d0:	52800142 	mov	w2, #0xa                   	// #10
    26d4:	d2800001 	mov	x1, #0x0                   	// #0
    26d8:	91003be0 	add	x0, sp, #0xe
    26dc:	97fffbad 	bl	1590 <strtol@plt>
    26e0:	aa1403e2 	mov	x2, x20
    26e4:	aa0003fa 	mov	x26, x0
    26e8:	52802001 	mov	w1, #0x100                 	// #256
    26ec:	aa1303e0 	mov	x0, x19
    26f0:	97fffbec 	bl	16a0 <fgets@plt>
    26f4:	b5fffdc0 	cbnz	x0, 26ac <fwp_heap_report+0x9c>
    26f8:	aa1403e0 	mov	x0, x20
    26fc:	97fffb5d 	bl	1470 <fclose@plt>
    2700:	a95253f3 	ldp	x19, x20, [sp, #288]
    2704:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    2708:	f947f400 	ldr	x0, [x0, #4072]
    270c:	f94087e2 	ldr	x2, [sp, #264]
    2710:	f9400001 	ldr	x1, [x0]
    2714:	eb010042 	subs	x2, x2, x1
    2718:	d2800001 	mov	x1, #0x0                   	// #0
    271c:	54000281 	b.ne	276c <fwp_heap_report+0x15c>  // b.any
    2720:	a9517bfd 	ldp	x29, x30, [sp, #272]
    2724:	aa1a03e6 	mov	x6, x26
    2728:	aa1903e5 	mov	x5, x25
    272c:	aa1803e4 	mov	x4, x24
    2730:	a9556bf9 	ldp	x25, x26, [sp, #336]
    2734:	aa1703e3 	mov	x3, x23
    2738:	a95463f7 	ldp	x23, x24, [sp, #320]
    273c:	aa1603e0 	mov	x0, x22
    2740:	a9535bf5 	ldp	x21, x22, [sp, #304]
    2744:	1e604121 	fmov	d1, d9
    2748:	1e604100 	fmov	d0, d8
    274c:	90000022 	adrp	x2, 6000 <fwp_main_thread+0x3f0>
    2750:	6d5627e8 	ldp	d8, d9, [sp, #352]
    2754:	913e6042 	add	x2, x2, #0xf98
    2758:	9105c3ff 	add	sp, sp, #0x170
    275c:	52800041 	mov	w1, #0x2                   	// #2
    2760:	17fffb80 	b	1560 <__fprintf_chk@plt>
    2764:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2768:	17ffffe7 	b	2704 <fwp_heap_report+0xf4>
    276c:	a91253f3 	stp	x19, x20, [sp, #288]
    2770:	97fffb60 	bl	14f0 <__stack_chk_fail@plt>

0000000000002774 <fwp_heap_init>:
    2774:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2778:	90000183 	adrp	x3, 32000 <fwp_heap+0xb30>
    277c:	910f4061 	add	x1, x3, #0x3d0
    2780:	910003fd 	mov	x29, sp
    2784:	a90153f3 	stp	x19, x20, [sp, #16]
    2788:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xd10>
    278c:	91134262 	add	x2, x19, #0x4d0
    2790:	a9025bf5 	stp	x21, x22, [sp, #32]
    2794:	52800024 	mov	w4, #0x1                   	// #1
    2798:	52800200 	mov	w0, #0x10                  	// #16
    279c:	b913a444 	str	w4, [x2, #5028]
    27a0:	b8004420 	str	w0, [x1], #4
    27a4:	11004000 	add	w0, w0, #0x10
    27a8:	7104401f 	cmp	w0, #0x110
    27ac:	54ffffa1 	b.ne	27a0 <fwp_heap_init+0x2c>  // b.any
    27b0:	b0000022 	adrp	x2, 7000 <_IO_stdin_used+0x140>
    27b4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    27b8:	90000181 	adrp	x1, 32000 <fwp_heap+0xb30>
    27bc:	91104021 	add	x1, x1, #0x410
    27c0:	3dc0fc43 	ldr	q3, [x2, #1008]
    27c4:	d2800000 	mov	x0, #0x0                   	// #0
    27c8:	4e040401 	dup	v1.4s, v0.s[0]
    27cc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    27d0:	0f215400 	shl	v0.2s, v0.2s, #1
    27d4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    27d8:	3ca06821 	str	q1, [x1, x0]
    27dc:	91004000 	add	x0, x0, #0x10
    27e0:	f101801f 	cmp	x0, #0x60
    27e4:	54ffff21 	b.ne	27c8 <fwp_heap_init+0x54>  // b.any
    27e8:	90000184 	adrp	x4, 32000 <fwp_heap+0xb30>
    27ec:	910f4063 	add	x3, x3, #0x3d0
    27f0:	9111c084 	add	x4, x4, #0x470
    27f4:	91134266 	add	x6, x19, #0x4d0
    27f8:	d2800002 	mov	x2, #0x0                   	// #0
    27fc:	d2800000 	mov	x0, #0x0                   	// #0
    2800:	d2880205 	mov	x5, #0x4010                	// #16400
    2804:	d503201f 	nop
    2808:	910f0001 	add	x1, x0, #0x3c0
    280c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2810:	eb02003f 	cmp	x1, x2
    2814:	540000a2 	b.cs	2828 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    2818:	91000400 	add	x0, x0, #0x1
    281c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2820:	eb02003f 	cmp	x1, x2
    2824:	54ffffa3 	b.cc	2818 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    2828:	91004042 	add	x2, x2, #0x10
    282c:	38001480 	strb	w0, [x4], #1
    2830:	eb05005f 	cmp	x2, x5
    2834:	54fffea1 	b.ne	2808 <fwp_heap_init+0x94>  // b.any
    2838:	528000b5 	mov	w21, #0x5                   	// #5
    283c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    2840:	14000004 	b	2850 <fwp_heap_init+0xdc>
    2844:	d342fe94 	lsr	x20, x20, #2
    2848:	710006b5 	subs	w21, w21, #0x1
    284c:	54000720 	b.eq	2930 <fwp_heap_init+0x1bc>  // b.none
    2850:	91404296 	add	x22, x20, #0x10, lsl #12
    2854:	d2800005 	mov	x5, #0x0                   	// #0
    2858:	aa1603e1 	mov	x1, x22
    285c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2860:	52880443 	mov	w3, #0x4022                	// #16418
    2864:	52800002 	mov	w2, #0x0                   	// #0
    2868:	d2800000 	mov	x0, #0x0                   	// #0
    286c:	97fffb45 	bl	1580 <mmap@plt>
    2870:	aa0003e6 	mov	x6, x0
    2874:	b100041f 	cmn	x0, #0x1
    2878:	54fffe60 	b.eq	2844 <fwp_heap_init+0xd0>  // b.none
    287c:	b40005a0 	cbz	x0, 2930 <fwp_heap_init+0x1bc>
    2880:	d350fe94 	lsr	x20, x20, #16
    2884:	d29fffe0 	mov	x0, #0xffff                	// #65535
    2888:	8b0000c7 	add	x7, x6, x0
    288c:	91134275 	add	x21, x19, #0x4d0
    2890:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    2894:	8b140a81 	add	x1, x20, x20, lsl #2
    2898:	d2800005 	mov	x5, #0x0                   	// #0
    289c:	12800004 	mov	w4, #0xffffffff            	// #-1
    28a0:	d37df021 	lsl	x1, x1, #3
    28a4:	52880443 	mov	w3, #0x4022                	// #16418
    28a8:	52800002 	mov	w2, #0x0                   	// #0
    28ac:	d2800000 	mov	x0, #0x0                   	// #0
    28b0:	f909daa7 	str	x7, [x21, #5040]
    28b4:	f909dea6 	str	x6, [x21, #5048]
    28b8:	f909e2b6 	str	x22, [x21, #5056]
    28bc:	f909eab4 	str	x20, [x21, #5072]
    28c0:	f90a02a1 	str	x1, [x21, #5120]
    28c4:	97fffb2f 	bl	1580 <mmap@plt>
    28c8:	aa0003e1 	mov	x1, x0
    28cc:	b100041f 	cmn	x0, #0x1
    28d0:	54000300 	b.eq	2930 <fwp_heap_init+0x1bc>  // b.none
    28d4:	b0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    28d8:	91012000 	add	x0, x0, #0x48
    28dc:	f909fea1 	str	x1, [x21, #5112]
    28e0:	97fffb68 	bl	1680 <getenv@plt>
    28e4:	52800002 	mov	w2, #0x0                   	// #0
    28e8:	aa0003e1 	mov	x1, x0
    28ec:	b40000e0 	cbz	x0, 2908 <fwp_heap_init+0x194>
    28f0:	39400000 	ldrb	w0, [x0]
    28f4:	340000a0 	cbz	w0, 2908 <fwp_heap_init+0x194>
    28f8:	7100c000 	subs	w0, w0, #0x30
    28fc:	54000120 	b.eq	2920 <fwp_heap_init+0x1ac>  // b.none
    2900:	7100001f 	cmp	w0, #0x0
    2904:	1a9f07e2 	cset	w2, ne	// ne = any
    2908:	91134273 	add	x19, x19, #0x4d0
    290c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2910:	b913aa62 	str	w2, [x19, #5032]
    2914:	a94153f3 	ldp	x19, x20, [sp, #16]
    2918:	a8c37bfd 	ldp	x29, x30, [sp], #48
    291c:	d65f03c0 	ret
    2920:	39400420 	ldrb	w0, [x1, #1]
    2924:	7100001f 	cmp	w0, #0x0
    2928:	1a9f07e2 	cset	w2, ne	// ne = any
    292c:	17fffff7 	b	2908 <fwp_heap_init+0x194>
    2930:	97fffcb8 	bl	1c10 <fwp_heap_oom>

0000000000002934 <fwp_args45>:
    2934:	d65f03c0 	ret
    2938:	d503201f 	nop
    293c:	d503201f 	nop

0000000000002940 <fwp_args69>:
    2940:	d65f03c0 	ret

0000000000002944 <fwp_wake_io>:
    2944:	d00000e9 	adrp	x9, 20000 <__data_start>
    2948:	9100c122 	add	x2, x9, #0x30
    294c:	f9400001 	ldr	x1, [x0]
    2950:	5280000a 	mov	w10, #0x0                   	// #0
    2954:	f9401046 	ldr	x6, [x2, #32]
    2958:	52800008 	mov	w8, #0x0                   	// #0
    295c:	4f000400 	movi	v0.4s, #0x0
    2960:	52800027 	mov	w7, #0x1                   	// #1
    2964:	aa0103e2 	mov	x2, x1
    2968:	b4000321 	cbz	x1, 29cc <fwp_wake_io+0x88>
    296c:	f9408c25 	ldr	x5, [x1, #280]
    2970:	39015c27 	strb	w7, [x1, #87]
    2974:	b4000165 	cbz	x5, 29a0 <fwp_wake_io+0x5c>
    2978:	a9520c24 	ldp	x4, x3, [x1, #288]
    297c:	b4000364 	cbz	x4, 29e8 <fwp_wake_io+0xa4>
    2980:	f9009483 	str	x3, [x4, #296]
    2984:	f9409423 	ldr	x3, [x1, #296]
    2988:	b4000043 	cbz	x3, 2990 <fwp_wake_io+0x4c>
    298c:	f9009064 	str	x4, [x3, #288]
    2990:	91080023 	add	x3, x1, #0x200
    2994:	f900943f 	str	xzr, [x1, #296]
    2998:	3c918060 	stur	q0, [x3, #-232]
    299c:	f9400001 	ldr	x1, [x0]
    29a0:	f9402843 	ldr	x3, [x2, #80]
    29a4:	f2001c7f 	tst	x3, #0xff000000ff
    29a8:	54fffde1 	b.ne	2964 <fwp_wake_io+0x20>  // b.any
    29ac:	39015047 	strb	w7, [x2, #84]
    29b0:	f900805f 	str	xzr, [x2, #256]
    29b4:	b40001e6 	cbz	x6, 29f0 <fwp_wake_io+0xac>
    29b8:	f90080c2 	str	x2, [x6, #256]
    29bc:	aa0203e6 	mov	x6, x2
    29c0:	52800028 	mov	w8, #0x1                   	// #1
    29c4:	aa0103e2 	mov	x2, x1
    29c8:	b5fffd21 	cbnz	x1, 296c <fwp_wake_io+0x28>
    29cc:	3400006a 	cbz	w10, 29d8 <fwp_wake_io+0x94>
    29d0:	9100c120 	add	x0, x9, #0x30
    29d4:	f900140b 	str	x11, [x0, #40]
    29d8:	34000068 	cbz	w8, 29e4 <fwp_wake_io+0xa0>
    29dc:	9100c129 	add	x9, x9, #0x30
    29e0:	f9001126 	str	x6, [x9, #32]
    29e4:	d65f03c0 	ret
    29e8:	f90000a3 	str	x3, [x5]
    29ec:	17ffffe7 	b	2988 <fwp_wake_io+0x44>
    29f0:	aa0203eb 	mov	x11, x2
    29f4:	5280002a 	mov	w10, #0x1                   	// #1
    29f8:	17fffff1 	b	29bc <fwp_wake_io+0x78>
    29fc:	d503201f 	nop

0000000000002a00 <fwp_poll_events>:
    2a00:	d10103ff 	sub	sp, sp, #0x40
    2a04:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    2a08:	f947f400 	ldr	x0, [x0, #4072]
    2a0c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2a10:	910083fd 	add	x29, sp, #0x20
    2a14:	a90353f3 	stp	x19, x20, [sp, #48]
    2a18:	d00000f4 	adrp	x20, 20000 <__data_start>
    2a1c:	f9400001 	ldr	x1, [x0]
    2a20:	f9000fe1 	str	x1, [sp, #24]
    2a24:	d2800001 	mov	x1, #0x0                   	// #0
    2a28:	97fffdce 	bl	2160 <fwp_now_ns>
    2a2c:	9100c281 	add	x1, x20, #0x30
    2a30:	f9401833 	ldr	x19, [x1, #48]
    2a34:	b4000e93 	cbz	x19, 2c04 <fwp_poll_events+0x204>
    2a38:	aa1303e1 	mov	x1, x19
    2a3c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2a40:	14000005 	b	2a54 <fwp_poll_events+0x54>
    2a44:	f9408821 	ldr	x1, [x1, #272]
    2a48:	eb03005f 	cmp	x2, x3
    2a4c:	9a83d042 	csel	x2, x2, x3, le
    2a50:	b40000c1 	cbz	x1, 2a68 <fwp_poll_events+0x68>
    2a54:	f9403423 	ldr	x3, [x1, #104]
    2a58:	b6ffff62 	tbz	x2, #63, 2a44 <fwp_poll_events+0x44>
    2a5c:	f9408821 	ldr	x1, [x1, #272]
    2a60:	aa0303e2 	mov	x2, x3
    2a64:	b5ffff81 	cbnz	x1, 2a54 <fwp_poll_events+0x54>
    2a68:	b7f80ce2 	tbnz	x2, #63, 2c04 <fwp_poll_events+0x204>
    2a6c:	cb000042 	sub	x2, x2, x0
    2a70:	f100005f 	cmp	x2, #0x0
    2a74:	540005cd 	b.le	2b2c <fwp_poll_events+0x12c>
    2a78:	d2869b60 	mov	x0, #0x34db                	// #13531
    2a7c:	d2884801 	mov	x1, #0x4240                	// #16960
    2a80:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2a84:	f2a001e1 	movk	x1, #0xf, lsl #16
    2a88:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2a8c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2a90:	f2e86360 	movk	x0, #0x431b, lsl #48
    2a94:	9b407c40 	smulh	x0, x2, x0
    2a98:	9352fc00 	asr	x0, x0, #18
    2a9c:	cb82fc00 	sub	x0, x0, x2, asr #63
    2aa0:	9b018802 	msub	x2, x0, x1, x2
    2aa4:	f100005f 	cmp	x2, #0x0
    2aa8:	9a800400 	cinc	x0, x0, ne	// ne = any
    2aac:	eb03001f 	cmp	x0, x3
    2ab0:	54000a0c 	b.gt	2bf0 <fwp_poll_events+0x1f0>
    2ab4:	340003c0 	cbz	w0, 2b2c <fwp_poll_events+0x12c>
    2ab8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2abc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2ac0:	72a20c42 	movk	w2, #0x1062, lsl #16
    2ac4:	9ba27c02 	umull	x2, w0, w2
    2ac8:	d366fc43 	lsr	x3, x2, #38
    2acc:	aa0303e2 	mov	x2, x3
    2ad0:	1b048063 	msub	w3, w3, w4, w0
    2ad4:	9b217c63 	smull	x3, w3, w1
    2ad8:	d2800001 	mov	x1, #0x0                   	// #0
    2adc:	910023e0 	add	x0, sp, #0x8
    2ae0:	a9008fe2 	stp	x2, x3, [sp, #8]
    2ae4:	97fffab7 	bl	15c0 <nanosleep@plt>
    2ae8:	9100c280 	add	x0, x20, #0x30
    2aec:	f9401813 	ldr	x19, [x0, #48]
    2af0:	97fffd9c 	bl	2160 <fwp_now_ns>
    2af4:	aa0003e6 	mov	x6, x0
    2af8:	b50001f3 	cbnz	x19, 2b34 <fwp_poll_events+0x134>
    2afc:	d503201f 	nop
    2b00:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    2b04:	f947f400 	ldr	x0, [x0, #4072]
    2b08:	f9400fe2 	ldr	x2, [sp, #24]
    2b0c:	f9400001 	ldr	x1, [x0]
    2b10:	eb010042 	subs	x2, x2, x1
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	540008c1 	b.ne	2c30 <fwp_poll_events+0x230>  // b.any
    2b1c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2b20:	a94353f3 	ldp	x19, x20, [sp, #48]
    2b24:	910103ff 	add	sp, sp, #0x40
    2b28:	d65f03c0 	ret
    2b2c:	97fffd8d 	bl	2160 <fwp_now_ns>
    2b30:	aa0003e6 	mov	x6, x0
    2b34:	4f000400 	movi	v0.4s, #0x0
    2b38:	9100c288 	add	x8, x20, #0x30
    2b3c:	52800027 	mov	w7, #0x1                   	// #1
    2b40:	f9403661 	ldr	x1, [x19, #104]
    2b44:	aa1303e5 	mov	x5, x19
    2b48:	f9408a73 	ldr	x19, [x19, #272]
    2b4c:	eb06003f 	cmp	x1, x6
    2b50:	5400032c 	b.gt	2bb4 <fwp_poll_events+0x1b4>
    2b54:	394154a0 	ldrb	w0, [x5, #85]
    2b58:	36000120 	tbz	w0, #0, 2b7c <fwp_poll_events+0x17c>
    2b5c:	f94084a0 	ldr	x0, [x5, #264]
    2b60:	b40003c0 	cbz	x0, 2bd8 <fwp_poll_events+0x1d8>
    2b64:	f9008813 	str	x19, [x0, #272]
    2b68:	b4000053 	cbz	x19, 2b70 <fwp_poll_events+0x170>
    2b6c:	f9008660 	str	x0, [x19, #264]
    2b70:	910800a0 	add	x0, x5, #0x200
    2b74:	390154bf 	strb	wzr, [x5, #85]
    2b78:	3c908000 	stur	q0, [x0, #-248]
    2b7c:	f94030a0 	ldr	x0, [x5, #96]
    2b80:	390158a7 	strb	w7, [x5, #86]
    2b84:	f100001f 	cmp	x0, #0x0
    2b88:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2b8c:	5400018d 	b.le	2bbc <fwp_poll_events+0x1bc>
    2b90:	f94028a0 	ldr	x0, [x5, #80]
    2b94:	f2001c1f 	tst	x0, #0xff000000ff
    2b98:	540000e1 	b.ne	2bb4 <fwp_poll_events+0x1b4>  // b.any
    2b9c:	f9401100 	ldr	x0, [x8, #32]
    2ba0:	390150a7 	strb	w7, [x5, #84]
    2ba4:	f90080bf 	str	xzr, [x5, #256]
    2ba8:	b40001e0 	cbz	x0, 2be4 <fwp_poll_events+0x1e4>
    2bac:	f9001105 	str	x5, [x8, #32]
    2bb0:	f9008005 	str	x5, [x0, #256]
    2bb4:	b5fffc73 	cbnz	x19, 2b40 <fwp_poll_events+0x140>
    2bb8:	17ffffd2 	b	2b00 <fwp_poll_events+0x100>
    2bbc:	394144a0 	ldrb	w0, [x5, #81]
    2bc0:	3707fe80 	tbnz	w0, #0, 2b90 <fwp_poll_events+0x190>
    2bc4:	394140a0 	ldrb	w0, [x5, #80]
    2bc8:	3707fe40 	tbnz	w0, #0, 2b90 <fwp_poll_events+0x190>
    2bcc:	aa0503e0 	mov	x0, x5
    2bd0:	97fffd10 	bl	2010 <fwp_cancel_tree.part.0>
    2bd4:	17ffffef 	b	2b90 <fwp_poll_events+0x190>
    2bd8:	9100c281 	add	x1, x20, #0x30
    2bdc:	f9001833 	str	x19, [x1, #48]
    2be0:	17ffffe2 	b	2b68 <fwp_poll_events+0x168>
    2be4:	f9001105 	str	x5, [x8, #32]
    2be8:	f9001505 	str	x5, [x8, #40]
    2bec:	17fffff2 	b	2bb4 <fwp_poll_events+0x1b4>
    2bf0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2bf4:	d2989362 	mov	x2, #0xc49b                	// #50331
    2bf8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2bfc:	f2a00402 	movk	x2, #0x20, lsl #16
    2c00:	17ffffb6 	b	2ad8 <fwp_poll_events+0xd8>
    2c04:	97fffbf3 	bl	1bd0 <fwp_flush>
    2c08:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x16b00>
    2c0c:	f947e863 	ldr	x3, [x3, #4048]
    2c10:	d2800562 	mov	x2, #0x2b                  	// #43
    2c14:	d2800021 	mov	x1, #0x1                   	// #1
    2c18:	b0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    2c1c:	91016000 	add	x0, x0, #0x58
    2c20:	f9400063 	ldr	x3, [x3]
    2c24:	97fffa73 	bl	15f0 <fwrite@plt>
    2c28:	52800ca0 	mov	w0, #0x65                  	// #101
    2c2c:	97fff9dd 	bl	13a0 <exit@plt>
    2c30:	97fffa30 	bl	14f0 <__stack_chk_fail@plt>

0000000000002c34 <fwp_rc_wide_dup>:
    2c34:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2c38:	910003fd 	mov	x29, sp
    2c3c:	a90153f3 	stp	x19, x20, [sp, #16]
    2c40:	aa0003f3 	mov	x19, x0
    2c44:	ca404400 	eor	x0, x0, x0, lsr #17
    2c48:	f90013f5 	str	x21, [sp, #32]
    2c4c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    2c50:	ca402400 	eor	x0, x0, x0, lsr #9
    2c54:	911342a2 	add	x2, x21, #0x4d0
    2c58:	92401c00 	and	x0, x0, #0xff
    2c5c:	910a2403 	add	x3, x0, #0x289
    2c60:	8b000c40 	add	x0, x2, x0, lsl #3
    2c64:	8b030c54 	add	x20, x2, x3, lsl #3
    2c68:	f94a2401 	ldr	x1, [x0, #5192]
    2c6c:	b50000a1 	cbnz	x1, 2c80 <fwp_rc_wide_dup+0x4c>
    2c70:	1400002d 	b	2d24 <fwp_rc_wide_dup+0xf0>
    2c74:	91004034 	add	x20, x1, #0x10
    2c78:	f9400821 	ldr	x1, [x1, #16]
    2c7c:	b4000241 	cbz	x1, 2cc4 <fwp_rc_wide_dup+0x90>
    2c80:	f9400022 	ldr	x2, [x1]
    2c84:	eb02027f 	cmp	x19, x2
    2c88:	54ffff61 	b.ne	2c74 <fwp_rc_wide_dup+0x40>  // b.any
    2c8c:	f9400281 	ldr	x1, [x20]
    2c90:	39400260 	ldrb	w0, [x19]
    2c94:	7103f81f 	cmp	w0, #0xfe
    2c98:	54000220 	b.eq	2cdc <fwp_rc_wide_dup+0xa8>  // b.none
    2c9c:	b40001a1 	cbz	x1, 2cd0 <fwp_rc_wide_dup+0x9c>
    2ca0:	f9400420 	ldr	x0, [x1, #8]
    2ca4:	b100041f 	cmn	x0, #0x1
    2ca8:	540004a0 	b.eq	2d3c <fwp_rc_wide_dup+0x108>  // b.none
    2cac:	91000400 	add	x0, x0, #0x1
    2cb0:	f9000420 	str	x0, [x1, #8]
    2cb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    2cb8:	f94013f5 	ldr	x21, [sp, #32]
    2cbc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2cc0:	d65f03c0 	ret
    2cc4:	39400260 	ldrb	w0, [x19]
    2cc8:	7103f81f 	cmp	w0, #0xfe
    2ccc:	540000a0 	b.eq	2ce0 <fwp_rc_wide_dup+0xac>  // b.none
    2cd0:	b0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    2cd4:	9102c000 	add	x0, x0, #0xb0
    2cd8:	97fffd12 	bl	2120 <fwp_trap>
    2cdc:	b5000281 	cbnz	x1, 2d2c <fwp_rc_wide_dup+0xf8>
    2ce0:	d2800300 	mov	x0, #0x18                  	// #24
    2ce4:	97fff9eb 	bl	1490 <malloc@plt>
    2ce8:	b4000280 	cbz	x0, 2d38 <fwp_rc_wide_dup+0x104>
    2cec:	d2801fe1 	mov	x1, #0xff                  	// #255
    2cf0:	a9000413 	stp	x19, x1, [x0]
    2cf4:	911342b5 	add	x21, x21, #0x4d0
    2cf8:	f900081f 	str	xzr, [x0, #16]
    2cfc:	12800001 	mov	w1, #0xffffffff            	// #-1
    2d00:	f9000280 	str	x0, [x20]
    2d04:	39000261 	strb	w1, [x19]
    2d08:	f94e26a0 	ldr	x0, [x21, #7240]
    2d0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d10:	91000400 	add	x0, x0, #0x1
    2d14:	f90e26a0 	str	x0, [x21, #7240]
    2d18:	f94013f5 	ldr	x21, [sp, #32]
    2d1c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d20:	d65f03c0 	ret
    2d24:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    2d28:	17ffffda 	b	2c90 <fwp_rc_wide_dup+0x5c>
    2d2c:	b0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    2d30:	91022000 	add	x0, x0, #0x88
    2d34:	97fffcfb 	bl	2120 <fwp_trap>
    2d38:	97fffbb6 	bl	1c10 <fwp_heap_oom>
    2d3c:	b0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    2d40:	91036000 	add	x0, x0, #0xd8
    2d44:	97fffcf7 	bl	2120 <fwp_trap>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <fwp_rc_forget_slot>:
    2d50:	aa0003e1 	mov	x1, x0
    2d54:	39400000 	ldrb	w0, [x0]
    2d58:	7103fc1f 	cmp	w0, #0xff
    2d5c:	54000040 	b.eq	2d64 <fwp_rc_forget_slot+0x14>  // b.none
    2d60:	d65f03c0 	ret
    2d64:	ca414420 	eor	x0, x1, x1, lsr #17
    2d68:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d6c:	ca402400 	eor	x0, x0, x0, lsr #9
    2d70:	910003fd 	mov	x29, sp
    2d74:	92401c00 	and	x0, x0, #0xff
    2d78:	f9000bf3 	str	x19, [sp, #16]
    2d7c:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xd10>
    2d80:	91134262 	add	x2, x19, #0x4d0
    2d84:	910a2403 	add	x3, x0, #0x289
    2d88:	8b000c40 	add	x0, x2, x0, lsl #3
    2d8c:	8b030c43 	add	x3, x2, x3, lsl #3
    2d90:	f94a2400 	ldr	x0, [x0, #5192]
    2d94:	b50000a0 	cbnz	x0, 2da8 <fwp_rc_forget_slot+0x58>
    2d98:	14000011 	b	2ddc <fwp_rc_forget_slot+0x8c>
    2d9c:	91004003 	add	x3, x0, #0x10
    2da0:	f9400800 	ldr	x0, [x0, #16]
    2da4:	b40001c0 	cbz	x0, 2ddc <fwp_rc_forget_slot+0x8c>
    2da8:	f9400002 	ldr	x2, [x0]
    2dac:	eb02003f 	cmp	x1, x2
    2db0:	54ffff61 	b.ne	2d9c <fwp_rc_forget_slot+0x4c>  // b.any
    2db4:	f9400801 	ldr	x1, [x0, #16]
    2db8:	91134273 	add	x19, x19, #0x4d0
    2dbc:	f9000061 	str	x1, [x3]
    2dc0:	97fff9fc 	bl	15b0 <free@plt>
    2dc4:	f94e2660 	ldr	x0, [x19, #7240]
    2dc8:	d1000400 	sub	x0, x0, #0x1
    2dcc:	f90e2660 	str	x0, [x19, #7240]
    2dd0:	f9400bf3 	ldr	x19, [sp, #16]
    2dd4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2dd8:	d65f03c0 	ret
    2ddc:	b0000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    2de0:	9102c000 	add	x0, x0, #0xb0
    2de4:	97fffccf 	bl	2120 <fwp_trap>
    2de8:	d503201f 	nop
    2dec:	d503201f 	nop

0000000000002df0 <fwp_rc_prepare_chunk>:
    2df0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2df4:	910003fd 	mov	x29, sp
    2df8:	a9025bf5 	stp	x21, x22, [sp, #32]
    2dfc:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xd10>
    2e00:	911342c2 	add	x2, x22, #0x4d0
    2e04:	b9401c03 	ldr	w3, [x0, #28]
    2e08:	aa0103f5 	mov	x21, x1
    2e0c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e10:	aa0003f4 	mov	x20, x0
    2e14:	f94e2440 	ldr	x0, [x2, #7240]
    2e18:	b4000440 	cbz	x0, 2ea0 <fwp_rc_prepare_chunk+0xb0>
    2e1c:	d2800013 	mov	x19, #0x0                   	// #0
    2e20:	35000203 	cbnz	w3, 2e60 <fwp_rc_prepare_chunk+0x70>
    2e24:	b4000361 	cbz	x1, 2e90 <fwp_rc_prepare_chunk+0xa0>
    2e28:	f9401280 	ldr	x0, [x20, #32]
    2e2c:	97fff9e1 	bl	15b0 <free@plt>
    2e30:	aa1503e0 	mov	x0, x21
    2e34:	d2800021 	mov	x1, #0x1                   	// #1
    2e38:	97fff9a6 	bl	14d0 <calloc@plt>
    2e3c:	f9001280 	str	x0, [x20, #32]
    2e40:	b5000460 	cbnz	x0, 2ecc <fwp_rc_prepare_chunk+0xdc>
    2e44:	97fffb73 	bl	1c10 <fwp_heap_oom>
    2e48:	97ffffc2 	bl	2d50 <fwp_rc_forget_slot>
    2e4c:	91000673 	add	x19, x19, #0x1
    2e50:	b9401e83 	ldr	w3, [x20, #28]
    2e54:	eb13007f 	cmp	x3, x19
    2e58:	54000169 	b.ls	2e84 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2e5c:	d503201f 	nop
    2e60:	f9401283 	ldr	x3, [x20, #32]
    2e64:	8b130060 	add	x0, x3, x19
    2e68:	38736863 	ldrb	w3, [x3, x19]
    2e6c:	7103fc7f 	cmp	w3, #0xff
    2e70:	54fffec0 	b.eq	2e48 <fwp_rc_prepare_chunk+0x58>  // b.none
    2e74:	b9401e83 	ldr	w3, [x20, #28]
    2e78:	91000673 	add	x19, x19, #0x1
    2e7c:	eb13007f 	cmp	x3, x19
    2e80:	54ffff08 	b.hi	2e60 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2e84:	eb0302bf 	cmp	x21, x3
    2e88:	54000121 	b.ne	2eac <fwp_rc_prepare_chunk+0xbc>  // b.any
    2e8c:	b5000335 	cbnz	x21, 2ef0 <fwp_rc_prepare_chunk+0x100>
    2e90:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e94:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2e9c:	d65f03c0 	ret
    2ea0:	2a0303e3 	mov	w3, w3
    2ea4:	eb0302bf 	cmp	x21, x3
    2ea8:	54ffff20 	b.eq	2e8c <fwp_rc_prepare_chunk+0x9c>  // b.none
    2eac:	911342c2 	add	x2, x22, #0x4d0
    2eb0:	f9401280 	ldr	x0, [x20, #32]
    2eb4:	f94e2841 	ldr	x1, [x2, #7248]
    2eb8:	cb030021 	sub	x1, x1, x3
    2ebc:	f90e2841 	str	x1, [x2, #7248]
    2ec0:	97fff9bc 	bl	15b0 <free@plt>
    2ec4:	b5fffb75 	cbnz	x21, 2e30 <fwp_rc_prepare_chunk+0x40>
    2ec8:	f900129f 	str	xzr, [x20, #32]
    2ecc:	911342d6 	add	x22, x22, #0x4d0
    2ed0:	f94e2ac0 	ldr	x0, [x22, #7248]
    2ed4:	b9001e95 	str	w21, [x20, #28]
    2ed8:	a94153f3 	ldp	x19, x20, [sp, #16]
    2edc:	8b150000 	add	x0, x0, x21
    2ee0:	f90e2ac0 	str	x0, [x22, #7248]
    2ee4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ee8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2eec:	d65f03c0 	ret
    2ef0:	f9401280 	ldr	x0, [x20, #32]
    2ef4:	aa1503e2 	mov	x2, x21
    2ef8:	a94153f3 	ldp	x19, x20, [sp, #16]
    2efc:	52800001 	mov	w1, #0x0                   	// #0
    2f00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f08:	17fff96e 	b	14c0 <memset@plt>
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_heap_refill>:
    2f10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2f14:	910003fd 	mov	x29, sp
    2f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    2f1c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    2f20:	911342b5 	add	x21, x21, #0x4d0
    2f24:	aa0003f6 	mov	x22, x0
    2f28:	d2800020 	mov	x0, #0x1                   	// #1
    2f2c:	a90153f3 	stp	x19, x20, [sp, #16]
    2f30:	a90363f7 	stp	x23, x24, [sp, #48]
    2f34:	2a0103f7 	mov	w23, w1
    2f38:	2a0203f8 	mov	w24, w2
    2f3c:	97fffb75 	bl	1d10 <fwp_heap_chunks>
    2f40:	aa0003f3 	mov	x19, x0
    2f44:	f949fea2 	ldr	x2, [x21, #5112]
    2f48:	8b000800 	add	x0, x0, x0, lsl #2
    2f4c:	2a1703e1 	mov	w1, w23
    2f50:	52800025 	mov	w5, #0x1                   	// #1
    2f54:	d37df000 	lsl	x0, x0, #3
    2f58:	910f0021 	add	x1, x1, #0x3c0
    2f5c:	8b000054 	add	x20, x2, x0
    2f60:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2f64:	52a00024 	mov	w4, #0x10000               	// #65536
    2f68:	38206845 	strb	w5, [x2, x0]
    2f6c:	aa1403e0 	mov	x0, x20
    2f70:	39000698 	strb	w24, [x20, #1]
    2f74:	39000a97 	strb	w23, [x20, #2]
    2f78:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2f7c:	b9000681 	str	w1, [x20, #4]
    2f80:	2a0103e5 	mov	w5, w1
    2f84:	8b0300a2 	add	x2, x5, x3
    2f88:	1ac10881 	udiv	w1, w4, w1
    2f8c:	9ac50842 	udiv	x2, x2, x5
    2f90:	b9000a81 	str	w1, [x20, #8]
    2f94:	92404021 	and	x1, x1, #0x1ffff
    2f98:	b9001a82 	str	w2, [x20, #24]
    2f9c:	97ffff95 	bl	2df0 <fwp_rc_prepare_chunk>
    2fa0:	f949daa0 	ldr	x0, [x21, #5040]
    2fa4:	29408a81 	ldp	w1, w2, [x20, #4]
    2fa8:	8b134000 	add	x0, x0, x19, lsl #16
    2fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    2fb0:	8b214003 	add	x3, x0, w1, uxtw
    2fb4:	9ba20021 	umaddl	x1, w1, w2, x0
    2fb8:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fbc:	a90086c3 	stp	x3, x1, [x22, #8]
    2fc0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2fc4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2fc8:	d65f03c0 	ret
    2fcc:	d503201f 	nop

0000000000002fd0 <fwp_mem_free>:
    2fd0:	b40003c0 	cbz	x0, 3048 <fwp_mem_free+0x78>
    2fd4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2fd8:	910003fd 	mov	x29, sp
    2fdc:	a9025bf5 	stp	x21, x22, [sp, #32]
    2fe0:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    2fe4:	911342a1 	add	x1, x21, #0x4d0
    2fe8:	a90153f3 	stp	x19, x20, [sp, #16]
    2fec:	aa0003f3 	mov	x19, x0
    2ff0:	f949d823 	ldr	x3, [x1, #5040]
    2ff4:	f949ec22 	ldr	x2, [x1, #5080]
    2ff8:	cb030000 	sub	x0, x0, x3
    2ffc:	eb02401f 	cmp	x0, x2, lsl #16
    3000:	540001c2 	b.cs	3038 <fwp_mem_free+0x68>  // b.hs, b.nlast
    3004:	d350fc16 	lsr	x22, x0, #16
    3008:	a90363f7 	stp	x23, x24, [sp, #48]
    300c:	f949fc22 	ldr	x2, [x1, #5112]
    3010:	8b160ad4 	add	x20, x22, x22, lsl #2
    3014:	d37df294 	lsl	x20, x20, #3
    3018:	ab140057 	adds	x23, x2, x20
    301c:	540000c0 	b.eq	3034 <fwp_mem_free+0x64>  // b.none
    3020:	38746842 	ldrb	w2, [x2, x20]
    3024:	7100045f 	cmp	w2, #0x1
    3028:	54000120 	b.eq	304c <fwp_mem_free+0x7c>  // b.none
    302c:	7100085f 	cmp	w2, #0x2
    3030:	540005e0 	b.eq	30ec <fwp_mem_free+0x11c>  // b.none
    3034:	a94363f7 	ldp	x23, x24, [sp, #48]
    3038:	a94153f3 	ldp	x19, x20, [sp, #16]
    303c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3040:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3044:	d65f03c0 	ret
    3048:	d65f03c0 	ret
    304c:	f94012f8 	ldr	x24, [x23, #32]
    3050:	b94006e1 	ldr	w1, [x23, #4]
    3054:	f90023f9 	str	x25, [sp, #64]
    3058:	2a0103e2 	mov	w2, w1
    305c:	394006f9 	ldrb	w25, [x23, #1]
    3060:	39400af4 	ldrb	w20, [x23, #2]
    3064:	b4000158 	cbz	x24, 308c <fwp_mem_free+0xbc>
    3068:	92403e76 	and	x22, x19, #0xffff
    306c:	9ac20ad6 	udiv	x22, x22, x2
    3070:	38766b01 	ldrb	w1, [x24, x22]
    3074:	8b160300 	add	x0, x24, x22
    3078:	7103fc3f 	cmp	w1, #0xff
    307c:	54000980 	b.eq	31ac <fwp_mem_free+0x1dc>  // b.none
    3080:	38366b1f 	strb	wzr, [x24, x22]
    3084:	b94006e1 	ldr	w1, [x23, #4]
    3088:	2a0103e2 	mov	w2, w1
    308c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    3090:	d37f1e83 	ubfiz	x3, x20, #1, #8
    3094:	cb390000 	sub	x0, x0, w25, uxtb
    3098:	8b340074 	add	x20, x3, w20, uxtb
    309c:	911342b5 	add	x21, x21, #0x4d0
    30a0:	1e630021 	ucvtf	d1, w1
    30a4:	d37ae400 	lsl	x0, x0, #6
    30a8:	8b140c14 	add	x20, x0, x20, lsl #3
    30ac:	a94363f7 	ldp	x23, x24, [sp, #48]
    30b0:	f8746aa0 	ldr	x0, [x21, x20]
    30b4:	f94023f9 	ldr	x25, [sp, #64]
    30b8:	aa2003e0 	mvn	x0, x0
    30bc:	fd4a22a0 	ldr	d0, [x21, #5184]
    30c0:	f9000260 	str	x0, [x19]
    30c4:	f8346ab3 	str	x19, [x21, x20]
    30c8:	f94a12a0 	ldr	x0, [x21, #5152]
    30cc:	1e612800 	fadd	d0, d0, d1
    30d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d4:	cb020000 	sub	x0, x0, x2
    30d8:	f90a12a0 	str	x0, [x21, #5152]
    30dc:	fd0a22a0 	str	d0, [x21, #5184]
    30e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    30e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    30e8:	d65f03c0 	ret
    30ec:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    30f0:	8b000063 	add	x3, x3, x0
    30f4:	eb03027f 	cmp	x19, x3
    30f8:	54fff9e1 	b.ne	3034 <fwp_mem_free+0x64>  // b.any
    30fc:	fd400ae1 	ldr	d1, [x23, #16]
    3100:	fd4a2020 	ldr	d0, [x1, #5184]
    3104:	f9400ae0 	ldr	x0, [x23, #16]
    3108:	7e61d821 	ucvtf	d1, d1
    310c:	f94a1022 	ldr	x2, [x1, #5152]
    3110:	f94012f3 	ldr	x19, [x23, #32]
    3114:	1e612800 	fadd	d0, d0, d1
    3118:	cb000042 	sub	x2, x2, x0
    311c:	f90a1022 	str	x2, [x1, #5152]
    3120:	fd0a2020 	str	d0, [x1, #5184]
    3124:	b40000b3 	cbz	x19, 3138 <fwp_mem_free+0x168>
    3128:	39400260 	ldrb	w0, [x19]
    312c:	7103fc1f 	cmp	w0, #0xff
    3130:	54000380 	b.eq	31a0 <fwp_mem_free+0x1d0>  // b.none
    3134:	3900027f 	strb	wzr, [x19]
    3138:	b9400ee2 	ldr	w2, [x23, #12]
    313c:	b4000142 	cbz	x2, 3164 <fwp_mem_free+0x194>
    3140:	911342a1 	add	x1, x21, #0x4d0
    3144:	8b160040 	add	x0, x2, x22
    3148:	8b000800 	add	x0, x0, x0, lsl #2
    314c:	f949fc21 	ldr	x1, [x1, #5112]
    3150:	8b140034 	add	x20, x1, x20
    3154:	8b000c20 	add	x0, x1, x0, lsl #3
    3158:	3802869f 	strb	wzr, [x20], #40
    315c:	eb00029f 	cmp	x20, x0
    3160:	54ffffc1 	b.ne	3158 <fwp_mem_free+0x188>  // b.any
    3164:	911342a0 	add	x0, x21, #0x4d0
    3168:	f94a1801 	ldr	x1, [x0, #5168]
    316c:	f949f803 	ldr	x3, [x0, #5104]
    3170:	8b020021 	add	x1, x1, x2
    3174:	f90a1801 	str	x1, [x0, #5168]
    3178:	eb16007f 	cmp	x3, x22
    317c:	54000049 	b.ls	3184 <fwp_mem_free+0x1b4>  // b.plast
    3180:	f909f816 	str	x22, [x0, #5104]
    3184:	911342b5 	add	x21, x21, #0x4d0
    3188:	f949f6a0 	ldr	x0, [x21, #5096]
    318c:	eb16001f 	cmp	x0, x22
    3190:	54fff529 	b.ls	3034 <fwp_mem_free+0x64>  // b.plast
    3194:	a94363f7 	ldp	x23, x24, [sp, #48]
    3198:	f909f6b6 	str	x22, [x21, #5096]
    319c:	17ffffa7 	b	3038 <fwp_mem_free+0x68>
    31a0:	aa1303e0 	mov	x0, x19
    31a4:	97fffeeb 	bl	2d50 <fwp_rc_forget_slot>
    31a8:	17ffffe3 	b	3134 <fwp_mem_free+0x164>
    31ac:	97fffee9 	bl	2d50 <fwp_rc_forget_slot>
    31b0:	17ffffb4 	b	3080 <fwp_mem_free+0xb0>

00000000000031b4 <fwp_heap_alloc_big>:
    31b4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    31b8:	910003fd 	mov	x29, sp
    31bc:	a90153f3 	stp	x19, x20, [sp, #16]
    31c0:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c4:	a90363f7 	stp	x23, x24, [sp, #48]
    31c8:	aa0003f7 	mov	x23, x0
    31cc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    31d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    31d4:	eb0002ff 	cmp	x23, x0
    31d8:	54000888 	b.hi	32e8 <fwp_heap_alloc_big+0x134>  // b.pmore
    31dc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    31e0:	8b0002f4 	add	x20, x23, x0
    31e4:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xd10>
    31e8:	91134359 	add	x25, x26, #0x4d0
    31ec:	d350fe94 	lsr	x20, x20, #16
    31f0:	2a0103f5 	mov	w21, w1
    31f4:	aa1403e0 	mov	x0, x20
    31f8:	97fffac6 	bl	1d10 <fwp_heap_chunks>
    31fc:	f949ff22 	ldr	x2, [x25, #5112]
    3200:	8b000813 	add	x19, x0, x0, lsl #2
    3204:	aa0003f8 	mov	x24, x0
    3208:	52800043 	mov	w3, #0x2                   	// #2
    320c:	d37df273 	lsl	x19, x19, #3
    3210:	d2800021 	mov	x1, #0x1                   	// #1
    3214:	8b130040 	add	x0, x2, x19
    3218:	38336843 	strb	w3, [x2, x19]
    321c:	39000415 	strb	w21, [x0, #1]
    3220:	b9000c14 	str	w20, [x0, #12]
    3224:	f9000817 	str	x23, [x0, #16]
    3228:	97fffef2 	bl	2df0 <fwp_rc_prepare_chunk>
    322c:	f100069f 	cmp	x20, #0x1
    3230:	54000269 	b.ls	327c <fwp_heap_alloc_big+0xc8>  // b.plast
    3234:	8b180294 	add	x20, x20, x24
    3238:	9100a273 	add	x19, x19, #0x28
    323c:	a90573fb 	stp	x27, x28, [sp, #80]
    3240:	5280007b 	mov	w27, #0x3                   	// #3
    3244:	8b140a94 	add	x20, x20, x20, lsl #2
    3248:	2a1803fc 	mov	w28, w24
    324c:	9adb2296 	lsl	x22, x20, x27
    3250:	f949ff35 	ldr	x21, [x25, #5112]
    3254:	d2800001 	mov	x1, #0x0                   	// #0
    3258:	8b1302b4 	add	x20, x21, x19
    325c:	aa1403e0 	mov	x0, x20
    3260:	97fffee4 	bl	2df0 <fwp_rc_prepare_chunk>
    3264:	38336abb 	strb	w27, [x21, x19]
    3268:	9100a273 	add	x19, x19, #0x28
    326c:	b9000e9c 	str	w28, [x20, #12]
    3270:	eb1302df 	cmp	x22, x19
    3274:	54fffee1 	b.ne	3250 <fwp_heap_alloc_big+0x9c>  // b.any
    3278:	a94573fb 	ldp	x27, x28, [sp, #80]
    327c:	91134353 	add	x19, x26, #0x4d0
    3280:	aa1703e2 	mov	x2, x23
    3284:	52800001 	mov	w1, #0x0                   	// #0
    3288:	f949da60 	ldr	x0, [x19, #5040]
    328c:	8b184018 	add	x24, x0, x24, lsl #16
    3290:	aa1803e0 	mov	x0, x24
    3294:	97fff88b 	bl	14c0 <memset@plt>
    3298:	f94a1260 	ldr	x0, [x19, #5152]
    329c:	ab170000 	adds	x0, x0, x23
    32a0:	54000242 	b.cs	32e8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    32a4:	f94a1661 	ldr	x1, [x19, #5160]
    32a8:	f90a1260 	str	x0, [x19, #5152]
    32ac:	eb01001f 	cmp	x0, x1
    32b0:	54000049 	b.ls	32b8 <fwp_heap_alloc_big+0x104>  // b.plast
    32b4:	f90a1660 	str	x0, [x19, #5160]
    32b8:	9113435a 	add	x26, x26, #0x4d0
    32bc:	9e6202e0 	scvtf	d0, x23
    32c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32c4:	aa1803e0 	mov	x0, x24
    32c8:	fd4a1f41 	ldr	d1, [x26, #5176]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	1e602820 	fadd	d0, d1, d0
    32d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    32d8:	fd0a1f40 	str	d0, [x26, #5176]
    32dc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    32e0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    32e4:	d65f03c0 	ret
    32e8:	a90573fb 	stp	x27, x28, [sp, #80]
    32ec:	97fffa49 	bl	1c10 <fwp_heap_oom>

00000000000032f0 <fwp_heap_alloc_slow>:
    32f0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32f4:	910003fd 	mov	x29, sp
    32f8:	a90153f3 	stp	x19, x20, [sp, #16]
    32fc:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xd10>
    3300:	91134262 	add	x2, x19, #0x4d0
    3304:	a9025bf5 	stp	x21, x22, [sp, #32]
    3308:	aa0003f5 	mov	x21, x0
    330c:	2a0103f4 	mov	w20, w1
    3310:	b953a440 	ldr	w0, [x2, #5028]
    3314:	34000600 	cbz	w0, 33d4 <fwp_heap_alloc_slow+0xe4>
    3318:	f14012bf 	cmp	x21, #0x4, lsl #12
    331c:	54000628 	b.hi	33e0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3320:	91003ea0 	add	x0, x21, #0xf
    3324:	91134262 	add	x2, x19, #0x4d0
    3328:	f9001bf7 	str	x23, [sp, #48]
    332c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3330:	8b401040 	add	x0, x2, x0, lsr #4
    3334:	cb34c084 	sub	x4, x4, w20, sxtw
    3338:	d37ae484 	lsl	x4, x4, #6
    333c:	397e8003 	ldrb	w3, [x0, #4000]
    3340:	910f0060 	add	x0, x3, #0x3c0
    3344:	aa0303e1 	mov	x1, x3
    3348:	8b030463 	add	x3, x3, x3, lsl #1
    334c:	8b030c83 	add	x3, x4, x3, lsl #3
    3350:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3354:	2a1703f6 	mov	w22, w23
    3358:	f8636844 	ldr	x4, [x2, x3]
    335c:	b40004e4 	cbz	x4, 33f8 <fwp_heap_alloc_slow+0x108>
    3360:	f9400080 	ldr	x0, [x4]
    3364:	aa2003e0 	mvn	x0, x0
    3368:	f8236840 	str	x0, [x2, x3]
    336c:	7100069f 	cmp	w20, #0x1
    3370:	aa0403e0 	mov	x0, x4
    3374:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    3378:	52800001 	mov	w1, #0x0                   	// #0
    337c:	97fff851 	bl	14c0 <memset@plt>
    3380:	aa0003e4 	mov	x4, x0
    3384:	91134260 	add	x0, x19, #0x4d0
    3388:	f94a1001 	ldr	x1, [x0, #5152]
    338c:	ab160021 	adds	x1, x1, x22
    3390:	540005c2 	b.cs	3448 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    3394:	f94a1402 	ldr	x2, [x0, #5160]
    3398:	f90a1001 	str	x1, [x0, #5152]
    339c:	eb02003f 	cmp	x1, x2
    33a0:	54000049 	b.ls	33a8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    33a4:	f90a1401 	str	x1, [x0, #5160]
    33a8:	91134273 	add	x19, x19, #0x4d0
    33ac:	1e6302e1 	ucvtf	d1, w23
    33b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33b4:	aa0403e0 	mov	x0, x4
    33b8:	fd4a1e60 	ldr	d0, [x19, #5176]
    33bc:	f9401bf7 	ldr	x23, [sp, #48]
    33c0:	1e612800 	fadd	d0, d0, d1
    33c4:	fd0a1e60 	str	d0, [x19, #5176]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    33d0:	d65f03c0 	ret
    33d4:	97fffce8 	bl	2774 <fwp_heap_init>
    33d8:	f14012bf 	cmp	x21, #0x4, lsl #12
    33dc:	54fffa29 	b.ls	3320 <fwp_heap_alloc_slow+0x30>  // b.plast
    33e0:	2a1403e1 	mov	w1, w20
    33e4:	aa1503e0 	mov	x0, x21
    33e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33f0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    33f4:	17ffff70 	b	31b4 <fwp_heap_alloc_big>
    33f8:	8b030042 	add	x2, x2, x3
    33fc:	f9400444 	ldr	x4, [x2, #8]
    3400:	b4000104 	cbz	x4, 3420 <fwp_heap_alloc_slow+0x130>
    3404:	f9400840 	ldr	x0, [x2, #16]
    3408:	cb040000 	sub	x0, x0, x4
    340c:	eb16001f 	cmp	x0, x22
    3410:	54000083 	b.cc	3420 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3414:	8b160080 	add	x0, x4, x22
    3418:	f9000440 	str	x0, [x2, #8]
    341c:	17ffffd4 	b	336c <fwp_heap_alloc_slow+0x7c>
    3420:	52800302 	mov	w2, #0x18                  	// #24
    3424:	52807804 	mov	w4, #0x3c0                 	// #960
    3428:	91134260 	add	x0, x19, #0x4d0
    342c:	9ba27c23 	umull	x3, w1, w2
    3430:	2a1403e2 	mov	w2, w20
    3434:	9b240e84 	smaddl	x4, w20, w4, x3
    3438:	8b040000 	add	x0, x0, x4
    343c:	97fffeb5 	bl	2f10 <fwp_heap_refill>
    3440:	aa0003e4 	mov	x4, x0
    3444:	17ffffca 	b	336c <fwp_heap_alloc_slow+0x7c>
    3448:	97fff9f2 	bl	1c10 <fwp_heap_oom>
    344c:	d503201f 	nop

0000000000003450 <fwp_rc_share>:
    3450:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    3454:	91134042 	add	x2, x2, #0x4d0
    3458:	f949d843 	ldr	x3, [x2, #5040]
    345c:	f949ec41 	ldr	x1, [x2, #5080]
    3460:	cb030000 	sub	x0, x0, x3
    3464:	eb01401f 	cmp	x0, x1, lsl #16
    3468:	540002c2 	b.cs	34c0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    346c:	d350fc01 	lsr	x1, x0, #16
    3470:	f949fc44 	ldr	x4, [x2, #5112]
    3474:	8b010821 	add	x1, x1, x1, lsl #2
    3478:	d37df021 	lsl	x1, x1, #3
    347c:	8b010083 	add	x3, x4, x1
    3480:	f9401062 	ldr	x2, [x3, #32]
    3484:	b40001e2 	cbz	x2, 34c0 <fwp_rc_share+0x70>
    3488:	38616881 	ldrb	w1, [x4, x1]
    348c:	7100083f 	cmp	w1, #0x2
    3490:	540001a0 	b.eq	34c4 <fwp_rc_share+0x74>  // b.none
    3494:	7100043f 	cmp	w1, #0x1
    3498:	54000141 	b.ne	34c0 <fwp_rc_share+0x70>  // b.any
    349c:	29430464 	ldp	w4, w1, [x3, #24]
    34a0:	92403c00 	and	x0, x0, #0xffff
    34a4:	9b047c00 	mul	x0, x0, x4
    34a8:	d360fc00 	lsr	x0, x0, #32
    34ac:	eb01001f 	cmp	x0, x1
    34b0:	54000082 	b.cs	34c0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    34b4:	8b000042 	add	x2, x2, x0
    34b8:	39400040 	ldrb	w0, [x2]
    34bc:	350000a0 	cbnz	w0, 34d0 <fwp_rc_share+0x80>
    34c0:	d65f03c0 	ret
    34c4:	72003c1f 	tst	w0, #0xffff
    34c8:	54ffff80 	b.eq	34b8 <fwp_rc_share+0x68>  // b.none
    34cc:	d65f03c0 	ret
    34d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    34d4:	90000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    34d8:	9103e000 	add	x0, x0, #0xf8
    34dc:	910003fd 	mov	x29, sp
    34e0:	97fffb10 	bl	2120 <fwp_trap>

00000000000034e4 <e69>:
    34e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34e8:	90000021 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    34ec:	910003fd 	mov	x29, sp
    34f0:	fd400001 	ldr	d1, [x0]
    34f4:	f9000bf3 	str	x19, [sp, #16]
    34f8:	fd420820 	ldr	d0, [x1, #1040]
    34fc:	1e610800 	fmul	d0, d0, d1
    3500:	9e660013 	fmov	x19, d0
    3504:	aa1303e0 	mov	x0, x19
    3508:	97ffffd2 	bl	3450 <fwp_rc_share>
    350c:	aa1303e0 	mov	x0, x19
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	d503201f 	nop

0000000000003520 <e45>:
    3520:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3524:	910003fd 	mov	x29, sp
    3528:	6d400001 	ldp	d1, d0, [x0]
    352c:	f9000bf3 	str	x19, [sp, #16]
    3530:	1e612800 	fadd	d0, d0, d1
    3534:	9e660013 	fmov	x19, d0
    3538:	aa1303e0 	mov	x0, x19
    353c:	97ffffc5 	bl	3450 <fwp_rc_share>
    3540:	aa1303e0 	mov	x0, x19
    3544:	f9400bf3 	ldr	x19, [sp, #16]
    3548:	a8c27bfd 	ldp	x29, x30, [sp], #32
    354c:	d65f03c0 	ret

0000000000003550 <e32>:
    3550:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3554:	910003fd 	mov	x29, sp
    3558:	6d400001 	ldp	d1, d0, [x0]
    355c:	f9000bf3 	str	x19, [sp, #16]
    3560:	1e613800 	fsub	d0, d0, d1
    3564:	9e660013 	fmov	x19, d0
    3568:	aa1303e0 	mov	x0, x19
    356c:	97ffffb9 	bl	3450 <fwp_rc_share>
    3570:	aa1303e0 	mov	x0, x19
    3574:	f9400bf3 	ldr	x19, [sp, #16]
    3578:	a8c27bfd 	ldp	x29, x30, [sp], #32
    357c:	d65f03c0 	ret

0000000000003580 <fwp_rc_dup>:
    3580:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    3584:	91134042 	add	x2, x2, #0x4d0
    3588:	f949d841 	ldr	x1, [x2, #5040]
    358c:	f949ec43 	ldr	x3, [x2, #5080]
    3590:	cb010001 	sub	x1, x0, x1
    3594:	eb03403f 	cmp	x1, x3, lsl #16
    3598:	54000342 	b.cs	3600 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    359c:	d350fc20 	lsr	x0, x1, #16
    35a0:	f949fc44 	ldr	x4, [x2, #5112]
    35a4:	8b000800 	add	x0, x0, x0, lsl #2
    35a8:	d37df002 	lsl	x2, x0, #3
    35ac:	8b020083 	add	x3, x4, x2
    35b0:	f9401060 	ldr	x0, [x3, #32]
    35b4:	b4000260 	cbz	x0, 3600 <fwp_rc_dup+0x80>
    35b8:	38626882 	ldrb	w2, [x4, x2]
    35bc:	7100085f 	cmp	w2, #0x2
    35c0:	54000220 	b.eq	3604 <fwp_rc_dup+0x84>  // b.none
    35c4:	7100045f 	cmp	w2, #0x1
    35c8:	540001c1 	b.ne	3600 <fwp_rc_dup+0x80>  // b.any
    35cc:	29430864 	ldp	w4, w2, [x3, #24]
    35d0:	92403c21 	and	x1, x1, #0xffff
    35d4:	9b047c21 	mul	x1, x1, x4
    35d8:	d360fc21 	lsr	x1, x1, #32
    35dc:	eb02003f 	cmp	x1, x2
    35e0:	54000102 	b.cs	3600 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    35e4:	8b010000 	add	x0, x0, x1
    35e8:	39400001 	ldrb	w1, [x0]
    35ec:	340000a1 	cbz	w1, 3600 <fwp_rc_dup+0x80>
    35f0:	7103f43f 	cmp	w1, #0xfd
    35f4:	540000e8 	b.hi	3610 <fwp_rc_dup+0x90>  // b.pmore
    35f8:	11000421 	add	w1, w1, #0x1
    35fc:	39000001 	strb	w1, [x0]
    3600:	d65f03c0 	ret
    3604:	72003c3f 	tst	w1, #0xffff
    3608:	54ffff00 	b.eq	35e8 <fwp_rc_dup+0x68>  // b.none
    360c:	d65f03c0 	ret
    3610:	17fffd89 	b	2c34 <fwp_rc_wide_dup>

0000000000003614 <fwp_task_dispose>:
    3614:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3618:	910003fd 	mov	x29, sp
    361c:	f9000bf3 	str	x19, [sp, #16]
    3620:	aa0003f3 	mov	x19, x0
    3624:	39414000 	ldrb	w0, [x0, #80]
    3628:	36000720 	tbz	w0, #0, 370c <fwp_task_dispose+0xf8>
    362c:	f9400a60 	ldr	x0, [x19, #16]
    3630:	b50006e0 	cbnz	x0, 370c <fwp_task_dispose+0xf8>
    3634:	a9478660 	ldp	x0, x1, [x19, #120]
    3638:	39014e7f 	strb	wzr, [x19, #83]
    363c:	f9003e7f 	str	xzr, [x19, #120]
    3640:	f100003f 	cmp	x1, #0x0
    3644:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3648:	54000040 	b.eq	3650 <fwp_task_dispose+0x3c>  // b.none
    364c:	d63f0020 	blr	x1
    3650:	f9405660 	ldr	x0, [x19, #168]
    3654:	97fffe5f 	bl	2fd0 <fwp_mem_free>
    3658:	f900567f 	str	xzr, [x19, #168]
    365c:	b9405e60 	ldr	w0, [x19, #92]
    3660:	7100041f 	cmp	w0, #0x1
    3664:	54000420 	b.eq	36e8 <fwp_task_dispose+0xd4>  // b.none
    3668:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    366c:	91134042 	add	x2, x2, #0x4d0
    3670:	f949d840 	ldr	x0, [x2, #5040]
    3674:	f949ec41 	ldr	x1, [x2, #5080]
    3678:	cb000260 	sub	x0, x19, x0
    367c:	eb01401f 	cmp	x0, x1, lsl #16
    3680:	540002e2 	b.cs	36dc <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3684:	d350fc01 	lsr	x1, x0, #16
    3688:	f949fc44 	ldr	x4, [x2, #5112]
    368c:	8b010821 	add	x1, x1, x1, lsl #2
    3690:	d37df021 	lsl	x1, x1, #3
    3694:	8b010083 	add	x3, x4, x1
    3698:	f9401062 	ldr	x2, [x3, #32]
    369c:	b4000202 	cbz	x2, 36dc <fwp_task_dispose+0xc8>
    36a0:	38616881 	ldrb	w1, [x4, x1]
    36a4:	7100083f 	cmp	w1, #0x2
    36a8:	54000280 	b.eq	36f8 <fwp_task_dispose+0xe4>  // b.none
    36ac:	7100043f 	cmp	w1, #0x1
    36b0:	54000161 	b.ne	36dc <fwp_task_dispose+0xc8>  // b.any
    36b4:	29430464 	ldp	w4, w1, [x3, #24]
    36b8:	92403c00 	and	x0, x0, #0xffff
    36bc:	9b047c00 	mul	x0, x0, x4
    36c0:	d360fc00 	lsr	x0, x0, #32
    36c4:	eb01001f 	cmp	x0, x1
    36c8:	540000a2 	b.cs	36dc <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    36cc:	8b000042 	add	x2, x2, x0
    36d0:	39400040 	ldrb	w0, [x2]
    36d4:	7100041f 	cmp	w0, #0x1
    36d8:	54000080 	b.eq	36e8 <fwp_task_dispose+0xd4>  // b.none
    36dc:	f9400bf3 	ldr	x19, [sp, #16]
    36e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e4:	d65f03c0 	ret
    36e8:	aa1303e0 	mov	x0, x19
    36ec:	f9400bf3 	ldr	x19, [sp, #16]
    36f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36f4:	17fffe37 	b	2fd0 <fwp_mem_free>
    36f8:	72003c1f 	tst	w0, #0xffff
    36fc:	54fffea0 	b.eq	36d0 <fwp_task_dispose+0xbc>  // b.none
    3700:	f9400bf3 	ldr	x19, [sp, #16]
    3704:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3708:	d65f03c0 	ret
    370c:	97fff78d 	bl	1540 <abort@plt>

0000000000003710 <fwp_free_zombie>:
    3710:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3714:	910003fd 	mov	x29, sp
    3718:	a90153f3 	stp	x19, x20, [sp, #16]
    371c:	b00000f4 	adrp	x20, 20000 <__data_start>
    3720:	9100c281 	add	x1, x20, #0x30
    3724:	f9401c33 	ldr	x19, [x1, #56]
    3728:	b4000333 	cbz	x19, 378c <fwp_free_zombie+0x7c>
    372c:	f9400420 	ldr	x0, [x1, #8]
    3730:	eb00027f 	cmp	x19, x0
    3734:	540002c0 	b.eq	378c <fwp_free_zombie+0x7c>  // b.none
    3738:	b9404022 	ldr	w2, [x1, #64]
    373c:	f9400a60 	ldr	x0, [x19, #16]
    3740:	7100fc5f 	cmp	w2, #0x3f
    3744:	5400078c 	b.gt	3834 <fwp_free_zombie+0x124>
    3748:	91014023 	add	x3, x1, #0x50
    374c:	11000444 	add	w4, w2, #0x1
    3750:	b9004024 	str	w4, [x1, #64]
    3754:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3758:	f822d860 	str	x0, [x3, w2, sxtw #3]
    375c:	a9530261 	ldp	x1, x0, [x19, #304]
    3760:	b4000741 	cbz	x1, 3848 <fwp_free_zombie+0x138>
    3764:	f9009c20 	str	x0, [x1, #312]
    3768:	b4000040 	cbz	x0, 3770 <fwp_free_zombie+0x60>
    376c:	f9009801 	str	x1, [x0, #304]
    3770:	9100c294 	add	x20, x20, #0x30
    3774:	b9405e60 	ldr	w0, [x19, #92]
    3778:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    377c:	f9001e9f 	str	xzr, [x20, #56]
    3780:	34000140 	cbz	w0, 37a8 <fwp_free_zombie+0x98>
    3784:	7100041f 	cmp	w0, #0x1
    3788:	54000080 	b.eq	3798 <fwp_free_zombie+0x88>  // b.none
    378c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3790:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3794:	d65f03c0 	ret
    3798:	aa1303e0 	mov	x0, x19
    379c:	a94153f3 	ldp	x19, x20, [sp, #16]
    37a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37a4:	17ffff9c 	b	3614 <fwp_task_dispose>
    37a8:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xd10>
    37ac:	91134082 	add	x2, x4, #0x4d0
    37b0:	f949d841 	ldr	x1, [x2, #5040]
    37b4:	f949ec40 	ldr	x0, [x2, #5080]
    37b8:	cb010261 	sub	x1, x19, x1
    37bc:	eb00403f 	cmp	x1, x0, lsl #16
    37c0:	54fffe62 	b.cs	378c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    37c4:	d350fc20 	lsr	x0, x1, #16
    37c8:	f949fc43 	ldr	x3, [x2, #5112]
    37cc:	8b000800 	add	x0, x0, x0, lsl #2
    37d0:	d37df000 	lsl	x0, x0, #3
    37d4:	8b000062 	add	x2, x3, x0
    37d8:	f9401054 	ldr	x20, [x2, #32]
    37dc:	b4fffd94 	cbz	x20, 378c <fwp_free_zombie+0x7c>
    37e0:	38606860 	ldrb	w0, [x3, x0]
    37e4:	7100081f 	cmp	w0, #0x2
    37e8:	54000360 	b.eq	3854 <fwp_free_zombie+0x144>  // b.none
    37ec:	7100041f 	cmp	w0, #0x1
    37f0:	54fffce1 	b.ne	378c <fwp_free_zombie+0x7c>  // b.any
    37f4:	29430043 	ldp	w3, w0, [x2, #24]
    37f8:	92403c21 	and	x1, x1, #0xffff
    37fc:	9b037c21 	mul	x1, x1, x3
    3800:	d360fc21 	lsr	x1, x1, #32
    3804:	eb00003f 	cmp	x1, x0
    3808:	54fffc22 	b.cs	378c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    380c:	8b010294 	add	x20, x20, x1
    3810:	39400280 	ldrb	w0, [x20]
    3814:	34fffbc0 	cbz	w0, 378c <fwp_free_zombie+0x7c>
    3818:	7100041f 	cmp	w0, #0x1
    381c:	54fffbe0 	b.eq	3798 <fwp_free_zombie+0x88>  // b.none
    3820:	7103fc1f 	cmp	w0, #0xff
    3824:	540001e0 	b.eq	3860 <fwp_free_zombie+0x150>  // b.none
    3828:	51000400 	sub	w0, w0, #0x1
    382c:	39000280 	strb	w0, [x20]
    3830:	17ffffd7 	b	378c <fwp_free_zombie+0x7c>
    3834:	f9400e61 	ldr	x1, [x19, #24]
    3838:	97fff776 	bl	1610 <munmap@plt>
    383c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3840:	a9530261 	ldp	x1, x0, [x19, #304]
    3844:	b5fff901 	cbnz	x1, 3764 <fwp_free_zombie+0x54>
    3848:	9100c282 	add	x2, x20, #0x30
    384c:	f9012840 	str	x0, [x2, #592]
    3850:	17ffffc6 	b	3768 <fwp_free_zombie+0x58>
    3854:	72003c3f 	tst	w1, #0xffff
    3858:	54fff9a1 	b.ne	378c <fwp_free_zombie+0x7c>  // b.any
    385c:	17ffffed 	b	3810 <fwp_free_zombie+0x100>
    3860:	ca544680 	eor	x0, x20, x20, lsr #17
    3864:	91134084 	add	x4, x4, #0x4d0
    3868:	ca402400 	eor	x0, x0, x0, lsr #9
    386c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3870:	f94a2400 	ldr	x0, [x0, #5192]
    3874:	b5000080 	cbnz	x0, 3884 <fwp_free_zombie+0x174>
    3878:	14000010 	b	38b8 <fwp_free_zombie+0x1a8>
    387c:	f9400800 	ldr	x0, [x0, #16]
    3880:	b40001c0 	cbz	x0, 38b8 <fwp_free_zombie+0x1a8>
    3884:	f9400001 	ldr	x1, [x0]
    3888:	eb14003f 	cmp	x1, x20
    388c:	54ffff81 	b.ne	387c <fwp_free_zombie+0x16c>  // b.any
    3890:	f9400401 	ldr	x1, [x0, #8]
    3894:	d1000421 	sub	x1, x1, #0x1
    3898:	f9000401 	str	x1, [x0, #8]
    389c:	f103f83f 	cmp	x1, #0xfe
    38a0:	54fff761 	b.ne	378c <fwp_free_zombie+0x7c>  // b.any
    38a4:	aa1403e0 	mov	x0, x20
    38a8:	97fffd2a 	bl	2d50 <fwp_rc_forget_slot>
    38ac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    38b0:	39000280 	strb	w0, [x20]
    38b4:	17ffffb6 	b	378c <fwp_free_zombie+0x7c>
    38b8:	90000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    38bc:	9102c000 	add	x0, x0, #0xb0
    38c0:	97fffa18 	bl	2120 <fwp_trap>

00000000000038c4 <fwp_block>:
    38c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    38c8:	910003fd 	mov	x29, sp
    38cc:	a90153f3 	stp	x19, x20, [sp, #16]
    38d0:	b00000f3 	adrp	x19, 20000 <__data_start>
    38d4:	9100c274 	add	x20, x19, #0x30
    38d8:	f9401682 	ldr	x2, [x20, #40]
    38dc:	b4000622 	cbz	x2, 39a0 <fwp_block+0xdc>
    38e0:	9100c261 	add	x1, x19, #0x30
    38e4:	f9408040 	ldr	x0, [x2, #256]
    38e8:	f9001420 	str	x0, [x1, #40]
    38ec:	b4000680 	cbz	x0, 39bc <fwp_block+0xf8>
    38f0:	9100c263 	add	x3, x19, #0x30
    38f4:	3901505f 	strb	wzr, [x2, #84]
    38f8:	f9400464 	ldr	x4, [x3, #8]
    38fc:	eb02009f 	cmp	x4, x2
    3900:	54000440 	b.eq	3988 <fwp_block+0xc4>  // b.none
    3904:	f9412c65 	ldr	x5, [x3, #600]
    3908:	f9000462 	str	x2, [x3, #8]
    390c:	f9400441 	ldr	x1, [x2, #8]
    3910:	f9004885 	str	x5, [x4, #144]
    3914:	f9413065 	ldr	x5, [x3, #608]
    3918:	f9004c85 	str	x5, [x4, #152]
    391c:	f9413465 	ldr	x5, [x3, #616]
    3920:	f9005085 	str	x5, [x4, #160]
    3924:	f9413865 	ldr	x5, [x3, #624]
    3928:	f9005485 	str	x5, [x4, #168]
    392c:	f9413c65 	ldr	x5, [x3, #632]
    3930:	f9005885 	str	x5, [x4, #176]
    3934:	f9414065 	ldr	x5, [x3, #640]
    3938:	f9005c85 	str	x5, [x4, #184]
    393c:	f9414465 	ldr	x5, [x3, #648]
    3940:	f9006085 	str	x5, [x4, #192]
    3944:	f9400480 	ldr	x0, [x4, #8]
    3948:	f9404844 	ldr	x4, [x2, #144]
    394c:	f9012c64 	str	x4, [x3, #600]
    3950:	f9404c44 	ldr	x4, [x2, #152]
    3954:	f9013064 	str	x4, [x3, #608]
    3958:	f9405044 	ldr	x4, [x2, #160]
    395c:	f9013464 	str	x4, [x3, #616]
    3960:	f9405444 	ldr	x4, [x2, #168]
    3964:	f9013864 	str	x4, [x3, #624]
    3968:	f9405844 	ldr	x4, [x2, #176]
    396c:	f9013c64 	str	x4, [x3, #632]
    3970:	a94b8844 	ldp	x4, x2, [x2, #184]
    3974:	f9014064 	str	x4, [x3, #640]
    3978:	f9014462 	str	x2, [x3, #648]
    397c:	97fff6f5 	bl	1550 <swapcontext@plt>
    3980:	97ffff64 	bl	3710 <fwp_free_zombie>
    3984:	d503201f 	nop
    3988:	9100c260 	add	x0, x19, #0x30
    398c:	b9429000 	ldr	w0, [x0, #656]
    3990:	340001a0 	cbz	w0, 39c4 <fwp_block+0x100>
    3994:	a94153f3 	ldp	x19, x20, [sp, #16]
    3998:	a8c27bfd 	ldp	x29, x30, [sp], #32
    399c:	d65f03c0 	ret
    39a0:	97fffc18 	bl	2a00 <fwp_poll_events>
    39a4:	f9401682 	ldr	x2, [x20, #40]
    39a8:	b4ffffc2 	cbz	x2, 39a0 <fwp_block+0xdc>
    39ac:	9100c261 	add	x1, x19, #0x30
    39b0:	f9408040 	ldr	x0, [x2, #256]
    39b4:	f9001420 	str	x0, [x1, #40]
    39b8:	b5fff9c0 	cbnz	x0, 38f0 <fwp_block+0x2c>
    39bc:	f900103f 	str	xzr, [x1, #32]
    39c0:	17ffffcc 	b	38f0 <fwp_block+0x2c>
    39c4:	90000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    39c8:	9104a000 	add	x0, x0, #0x128
    39cc:	97fff72d 	bl	1680 <getenv@plt>
    39d0:	5284e202 	mov	w2, #0x2710                	// #10000
    39d4:	b4000060 	cbz	x0, 39e0 <fwp_block+0x11c>
    39d8:	39400001 	ldrb	w1, [x0]
    39dc:	350000c1 	cbnz	w1, 39f4 <fwp_block+0x130>
    39e0:	9100c273 	add	x19, x19, #0x30
    39e4:	b9029262 	str	w2, [x19, #656]
    39e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39f0:	d65f03c0 	ret
    39f4:	52800142 	mov	w2, #0xa                   	// #10
    39f8:	d2800001 	mov	x1, #0x0                   	// #0
    39fc:	97fff671 	bl	13c0 <strtoll@plt>
    3a00:	d1000403 	sub	x3, x0, #0x1
    3a04:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3a08:	eb02007f 	cmp	x3, x2
    3a0c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3a10:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3a14:	17fffff3 	b	39e0 <fwp_block+0x11c>
    3a18:	d503201f 	nop
    3a1c:	d503201f 	nop

0000000000003a20 <fwp_map_items>:
    3a20:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3a24:	910003fd 	mov	x29, sp
    3a28:	a90153f3 	stp	x19, x20, [sp, #16]
    3a2c:	aa0003f3 	mov	x19, x0
    3a30:	b4000a80 	cbz	x0, 3b80 <fwp_map_items+0x160>
    3a34:	aa0003e2 	mov	x2, x0
    3a38:	d2800000 	mov	x0, #0x0                   	// #0
    3a3c:	d503201f 	nop
    3a40:	f9400842 	ldr	x2, [x2, #16]
    3a44:	aa0003e3 	mov	x3, x0
    3a48:	91000400 	add	x0, x0, #0x1
    3a4c:	b5ffffa2 	cbnz	x2, 3a40 <fwp_map_items+0x20>
    3a50:	f9000020 	str	x0, [x1]
    3a54:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    3a58:	a9025bf5 	stp	x21, x22, [sp, #32]
    3a5c:	eb01001f 	cmp	x0, x1
    3a60:	540009c8 	b.hi	3b98 <fwp_map_items+0x178>  // b.pmore
    3a64:	91000860 	add	x0, x3, #0x2
    3a68:	d37df000 	lsl	x0, x0, #3
    3a6c:	f140101f 	cmp	x0, #0x4, lsl #12
    3a70:	1a9f87e2 	cset	w2, ls	// ls = plast
    3a74:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    3a78:	911342b4 	add	x20, x21, #0x4d0
    3a7c:	b953a681 	ldr	w1, [x20, #5028]
    3a80:	7100003f 	cmp	w1, #0x0
    3a84:	7a401844 	ccmp	w2, #0x0, #0x4, ne	// ne = any
    3a88:	54000680 	b.eq	3b58 <fwp_map_items+0x138>  // b.none
    3a8c:	91003c01 	add	x1, x0, #0xf
    3a90:	f9001bf7 	str	x23, [sp, #48]
    3a94:	8b411281 	add	x1, x20, x1, lsr #4
    3a98:	397e8021 	ldrb	w1, [x1, #4000]
    3a9c:	910f0022 	add	x2, x1, #0x3c0
    3aa0:	8b010421 	add	x1, x1, x1, lsl #1
    3aa4:	8b010e83 	add	x3, x20, x1, lsl #3
    3aa8:	b8627a97 	ldr	w23, [x20, x2, lsl #2]
    3aac:	2a1703f6 	mov	w22, w23
    3ab0:	f943c064 	ldr	x4, [x3, #1920]
    3ab4:	b4000444 	cbz	x4, 3b3c <fwp_map_items+0x11c>
    3ab8:	f9400085 	ldr	x5, [x4]
    3abc:	aa1603e2 	mov	x2, x22
    3ac0:	aa0403e0 	mov	x0, x4
    3ac4:	52800001 	mov	w1, #0x0                   	// #0
    3ac8:	aa2503e5 	mvn	x5, x5
    3acc:	f903c065 	str	x5, [x3, #1920]
    3ad0:	97fff67c 	bl	14c0 <memset@plt>
    3ad4:	aa0003e4 	mov	x4, x0
    3ad8:	f94a1280 	ldr	x0, [x20, #5152]
    3adc:	ab160000 	adds	x0, x0, x22
    3ae0:	540005a2 	b.cs	3b94 <fwp_map_items+0x174>  // b.hs, b.nlast
    3ae4:	f94a1681 	ldr	x1, [x20, #5160]
    3ae8:	f90a1280 	str	x0, [x20, #5152]
    3aec:	eb01001f 	cmp	x0, x1
    3af0:	54000049 	b.ls	3af8 <fwp_map_items+0xd8>  // b.plast
    3af4:	f90a1680 	str	x0, [x20, #5160]
    3af8:	911342b5 	add	x21, x21, #0x4d0
    3afc:	1e6302e1 	ucvtf	d1, w23
    3b00:	f9401bf7 	ldr	x23, [sp, #48]
    3b04:	fd4a1ea0 	ldr	d0, [x21, #5176]
    3b08:	1e612800 	fadd	d0, d0, d1
    3b0c:	fd0a1ea0 	str	d0, [x21, #5176]
    3b10:	aa0403e1 	mov	x1, x4
    3b14:	b40000b3 	cbz	x19, 3b28 <fwp_map_items+0x108>
    3b18:	f9400662 	ldr	x2, [x19, #8]
    3b1c:	f8008422 	str	x2, [x1], #8
    3b20:	f9400a73 	ldr	x19, [x19, #16]
    3b24:	b5ffffb3 	cbnz	x19, 3b18 <fwp_map_items+0xf8>
    3b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b2c:	aa0403e0 	mov	x0, x4
    3b30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3b34:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3b38:	d65f03c0 	ret
    3b3c:	f943c464 	ldr	x4, [x3, #1928]
    3b40:	b40000a4 	cbz	x4, 3b54 <fwp_map_items+0x134>
    3b44:	f943c861 	ldr	x1, [x3, #1936]
    3b48:	cb040021 	sub	x1, x1, x4
    3b4c:	eb0102df 	cmp	x22, x1
    3b50:	540000c9 	b.ls	3b68 <fwp_map_items+0x148>  // b.plast
    3b54:	f9401bf7 	ldr	x23, [sp, #48]
    3b58:	52800041 	mov	w1, #0x2                   	// #2
    3b5c:	97fffde5 	bl	32f0 <fwp_heap_alloc_slow>
    3b60:	aa0003e4 	mov	x4, x0
    3b64:	17ffffeb 	b	3b10 <fwp_map_items+0xf0>
    3b68:	8b160085 	add	x5, x4, x22
    3b6c:	aa1603e2 	mov	x2, x22
    3b70:	aa0403e0 	mov	x0, x4
    3b74:	52800001 	mov	w1, #0x0                   	// #0
    3b78:	f903c465 	str	x5, [x3, #1928]
    3b7c:	17ffffd5 	b	3ad0 <fwp_map_items+0xb0>
    3b80:	a9025bf5 	stp	x21, x22, [sp, #32]
    3b84:	52800022 	mov	w2, #0x1                   	// #1
    3b88:	d2800100 	mov	x0, #0x8                   	// #8
    3b8c:	f900003f 	str	xzr, [x1]
    3b90:	17ffffb9 	b	3a74 <fwp_map_items+0x54>
    3b94:	97fff81f 	bl	1c10 <fwp_heap_oom>
    3b98:	90000020 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    3b9c:	9104e000 	add	x0, x0, #0x138
    3ba0:	f9001bf7 	str	x23, [sp, #48]
    3ba4:	97fff95f 	bl	2120 <fwp_trap>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_caps32>:
    3bb0:	34000041 	cbz	w1, 3bb8 <fwp_caps32+0x8>
    3bb4:	d65f03c0 	ret
    3bb8:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3bbc:	91134063 	add	x3, x3, #0x4d0
    3bc0:	f949d861 	ldr	x1, [x3, #5040]
    3bc4:	f949ec62 	ldr	x2, [x3, #5080]
    3bc8:	cb010001 	sub	x1, x0, x1
    3bcc:	eb02403f 	cmp	x1, x2, lsl #16
    3bd0:	54ffff22 	b.cs	3bb4 <fwp_caps32+0x4>  // b.hs, b.nlast
    3bd4:	d350fc22 	lsr	x2, x1, #16
    3bd8:	f949fc65 	ldr	x5, [x3, #5112]
    3bdc:	8b020842 	add	x2, x2, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b0200a4 	add	x4, x5, x2
    3be8:	f9401083 	ldr	x3, [x4, #32]
    3bec:	b4fffe43 	cbz	x3, 3bb4 <fwp_caps32+0x4>
    3bf0:	386268a2 	ldrb	w2, [x5, x2]
    3bf4:	7100085f 	cmp	w2, #0x2
    3bf8:	540001c0 	b.eq	3c30 <fwp_caps32+0x80>  // b.none
    3bfc:	7100045f 	cmp	w2, #0x1
    3c00:	54fffda1 	b.ne	3bb4 <fwp_caps32+0x4>  // b.any
    3c04:	29430885 	ldp	w5, w2, [x4, #24]
    3c08:	92403c21 	and	x1, x1, #0xffff
    3c0c:	9b057c21 	mul	x1, x1, x5
    3c10:	d360fc21 	lsr	x1, x1, #32
    3c14:	eb02003f 	cmp	x1, x2
    3c18:	54fffce2 	b.cs	3bb4 <fwp_caps32+0x4>  // b.hs, b.nlast
    3c1c:	8b010063 	add	x3, x3, x1
    3c20:	39400061 	ldrb	w1, [x3]
    3c24:	7100043f 	cmp	w1, #0x1
    3c28:	54fffc61 	b.ne	3bb4 <fwp_caps32+0x4>  // b.any
    3c2c:	17fffce9 	b	2fd0 <fwp_mem_free>
    3c30:	72003c3f 	tst	w1, #0xffff
    3c34:	54ffff60 	b.eq	3c20 <fwp_caps32+0x70>  // b.none
    3c38:	d65f03c0 	ret
    3c3c:	d503201f 	nop

0000000000003c40 <fwp_caps45>:
    3c40:	34000041 	cbz	w1, 3c48 <fwp_caps45+0x8>
    3c44:	d65f03c0 	ret
    3c48:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3c4c:	91134063 	add	x3, x3, #0x4d0
    3c50:	f949d861 	ldr	x1, [x3, #5040]
    3c54:	f949ec62 	ldr	x2, [x3, #5080]
    3c58:	cb010001 	sub	x1, x0, x1
    3c5c:	eb02403f 	cmp	x1, x2, lsl #16
    3c60:	54ffff22 	b.cs	3c44 <fwp_caps45+0x4>  // b.hs, b.nlast
    3c64:	d350fc22 	lsr	x2, x1, #16
    3c68:	f949fc65 	ldr	x5, [x3, #5112]
    3c6c:	8b020842 	add	x2, x2, x2, lsl #2
    3c70:	d37df042 	lsl	x2, x2, #3
    3c74:	8b0200a4 	add	x4, x5, x2
    3c78:	f9401083 	ldr	x3, [x4, #32]
    3c7c:	b4fffe43 	cbz	x3, 3c44 <fwp_caps45+0x4>
    3c80:	386268a2 	ldrb	w2, [x5, x2]
    3c84:	7100085f 	cmp	w2, #0x2
    3c88:	540001c0 	b.eq	3cc0 <fwp_caps45+0x80>  // b.none
    3c8c:	7100045f 	cmp	w2, #0x1
    3c90:	54fffda1 	b.ne	3c44 <fwp_caps45+0x4>  // b.any
    3c94:	29430885 	ldp	w5, w2, [x4, #24]
    3c98:	92403c21 	and	x1, x1, #0xffff
    3c9c:	9b057c21 	mul	x1, x1, x5
    3ca0:	d360fc21 	lsr	x1, x1, #32
    3ca4:	eb02003f 	cmp	x1, x2
    3ca8:	54fffce2 	b.cs	3c44 <fwp_caps45+0x4>  // b.hs, b.nlast
    3cac:	8b010063 	add	x3, x3, x1
    3cb0:	39400061 	ldrb	w1, [x3]
    3cb4:	7100043f 	cmp	w1, #0x1
    3cb8:	54fffc61 	b.ne	3c44 <fwp_caps45+0x4>  // b.any
    3cbc:	17fffcc5 	b	2fd0 <fwp_mem_free>
    3cc0:	72003c3f 	tst	w1, #0xffff
    3cc4:	54ffff60 	b.eq	3cb0 <fwp_caps45+0x70>  // b.none
    3cc8:	d65f03c0 	ret
    3ccc:	d503201f 	nop

0000000000003cd0 <fwp_caps69>:
    3cd0:	34000041 	cbz	w1, 3cd8 <fwp_caps69+0x8>
    3cd4:	d65f03c0 	ret
    3cd8:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3cdc:	91134063 	add	x3, x3, #0x4d0
    3ce0:	f949d861 	ldr	x1, [x3, #5040]
    3ce4:	f949ec62 	ldr	x2, [x3, #5080]
    3ce8:	cb010001 	sub	x1, x0, x1
    3cec:	eb02403f 	cmp	x1, x2, lsl #16
    3cf0:	54ffff22 	b.cs	3cd4 <fwp_caps69+0x4>  // b.hs, b.nlast
    3cf4:	d350fc22 	lsr	x2, x1, #16
    3cf8:	f949fc65 	ldr	x5, [x3, #5112]
    3cfc:	8b020842 	add	x2, x2, x2, lsl #2
    3d00:	d37df042 	lsl	x2, x2, #3
    3d04:	8b0200a4 	add	x4, x5, x2
    3d08:	f9401083 	ldr	x3, [x4, #32]
    3d0c:	b4fffe43 	cbz	x3, 3cd4 <fwp_caps69+0x4>
    3d10:	386268a2 	ldrb	w2, [x5, x2]
    3d14:	7100085f 	cmp	w2, #0x2
    3d18:	540001c0 	b.eq	3d50 <fwp_caps69+0x80>  // b.none
    3d1c:	7100045f 	cmp	w2, #0x1
    3d20:	54fffda1 	b.ne	3cd4 <fwp_caps69+0x4>  // b.any
    3d24:	29430885 	ldp	w5, w2, [x4, #24]
    3d28:	92403c21 	and	x1, x1, #0xffff
    3d2c:	9b057c21 	mul	x1, x1, x5
    3d30:	d360fc21 	lsr	x1, x1, #32
    3d34:	eb02003f 	cmp	x1, x2
    3d38:	54fffce2 	b.cs	3cd4 <fwp_caps69+0x4>  // b.hs, b.nlast
    3d3c:	8b010063 	add	x3, x3, x1
    3d40:	39400061 	ldrb	w1, [x3]
    3d44:	7100043f 	cmp	w1, #0x1
    3d48:	54fffc61 	b.ne	3cd4 <fwp_caps69+0x4>  // b.any
    3d4c:	17fffca1 	b	2fd0 <fwp_mem_free>
    3d50:	72003c3f 	tst	w1, #0xffff
    3d54:	54ffff60 	b.eq	3d40 <fwp_caps69+0x70>  // b.none
    3d58:	d65f03c0 	ret
    3d5c:	d503201f 	nop

0000000000003d60 <fwp_caps74>:
    3d60:	34000041 	cbz	w1, 3d68 <fwp_caps74+0x8>
    3d64:	d65f03c0 	ret
    3d68:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3d6c:	91134063 	add	x3, x3, #0x4d0
    3d70:	f949d861 	ldr	x1, [x3, #5040]
    3d74:	f949ec62 	ldr	x2, [x3, #5080]
    3d78:	cb010001 	sub	x1, x0, x1
    3d7c:	eb02403f 	cmp	x1, x2, lsl #16
    3d80:	54ffff22 	b.cs	3d64 <fwp_caps74+0x4>  // b.hs, b.nlast
    3d84:	d350fc22 	lsr	x2, x1, #16
    3d88:	f949fc65 	ldr	x5, [x3, #5112]
    3d8c:	8b020842 	add	x2, x2, x2, lsl #2
    3d90:	d37df042 	lsl	x2, x2, #3
    3d94:	8b0200a4 	add	x4, x5, x2
    3d98:	f9401083 	ldr	x3, [x4, #32]
    3d9c:	b4fffe43 	cbz	x3, 3d64 <fwp_caps74+0x4>
    3da0:	386268a2 	ldrb	w2, [x5, x2]
    3da4:	7100085f 	cmp	w2, #0x2
    3da8:	540001c0 	b.eq	3de0 <fwp_caps74+0x80>  // b.none
    3dac:	7100045f 	cmp	w2, #0x1
    3db0:	54fffda1 	b.ne	3d64 <fwp_caps74+0x4>  // b.any
    3db4:	29430885 	ldp	w5, w2, [x4, #24]
    3db8:	92403c21 	and	x1, x1, #0xffff
    3dbc:	9b057c21 	mul	x1, x1, x5
    3dc0:	d360fc21 	lsr	x1, x1, #32
    3dc4:	eb02003f 	cmp	x1, x2
    3dc8:	54fffce2 	b.cs	3d64 <fwp_caps74+0x4>  // b.hs, b.nlast
    3dcc:	8b010063 	add	x3, x3, x1
    3dd0:	39400061 	ldrb	w1, [x3]
    3dd4:	7100043f 	cmp	w1, #0x1
    3dd8:	54fffc61 	b.ne	3d64 <fwp_caps74+0x4>  // b.any
    3ddc:	17fffc7d 	b	2fd0 <fwp_mem_free>
    3de0:	72003c3f 	tst	w1, #0xffff
    3de4:	54ffff60 	b.eq	3dd0 <fwp_caps74+0x70>  // b.none
    3de8:	d65f03c0 	ret
    3dec:	d503201f 	nop

0000000000003df0 <fwp_data.part.0.constprop.0>:
    3df0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3df4:	910003fd 	mov	x29, sp
    3df8:	a90153f3 	stp	x19, x20, [sp, #16]
    3dfc:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xd10>
    3e00:	91134283 	add	x3, x20, #0x4d0
    3e04:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e08:	aa0103f5 	mov	x21, x1
    3e0c:	b953a461 	ldr	w1, [x3, #5028]
    3e10:	a90363f7 	stp	x23, x24, [sp, #48]
    3e14:	2a0003f8 	mov	w24, w0
    3e18:	34000701 	cbz	w1, 3ef8 <fwp_data.part.0.constprop.0+0x108>
    3e1c:	397e8862 	ldrb	w2, [x3, #4002]
    3e20:	910f0040 	add	x0, x2, #0x3c0
    3e24:	8b020442 	add	x2, x2, x2, lsl #1
    3e28:	d37df042 	lsl	x2, x2, #3
    3e2c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    3e30:	2a1703f6 	mov	w22, w23
    3e34:	f8626873 	ldr	x19, [x3, x2]
    3e38:	b40004d3 	cbz	x19, 3ed0 <fwp_data.part.0.constprop.0+0xe0>
    3e3c:	f9400260 	ldr	x0, [x19]
    3e40:	aa2003e0 	mvn	x0, x0
    3e44:	f8226860 	str	x0, [x3, x2]
    3e48:	f10062df 	cmp	x22, #0x18
    3e4c:	540000e9 	b.ls	3e68 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    3e50:	d10066c2 	sub	x2, x22, #0x19
    3e54:	91006260 	add	x0, x19, #0x18
    3e58:	927df042 	and	x2, x2, #0xfffffffffffffff8
    3e5c:	52800001 	mov	w1, #0x0                   	// #0
    3e60:	91002042 	add	x2, x2, #0x8
    3e64:	97fff597 	bl	14c0 <memset@plt>
    3e68:	91134282 	add	x2, x20, #0x4d0
    3e6c:	f94a1041 	ldr	x1, [x2, #5152]
    3e70:	ab160021 	adds	x1, x1, x22
    3e74:	540004c2 	b.cs	3f0c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    3e78:	f94a1440 	ldr	x0, [x2, #5160]
    3e7c:	f90a1041 	str	x1, [x2, #5152]
    3e80:	eb00003f 	cmp	x1, x0
    3e84:	54000049 	b.ls	3e8c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    3e88:	f90a1441 	str	x1, [x2, #5160]
    3e8c:	91134294 	add	x20, x20, #0x4d0
    3e90:	1e6302e1 	ucvtf	d1, w23
    3e94:	fd4a1e80 	ldr	d0, [x20, #5176]
    3e98:	1e612800 	fadd	d0, d0, d1
    3e9c:	fd0a1e80 	str	d0, [x20, #5176]
    3ea0:	52800041 	mov	w1, #0x2                   	// #2
    3ea4:	29000678 	stp	w24, w1, [x19]
    3ea8:	aa1303e0 	mov	x0, x19
    3eac:	f94002a1 	ldr	x1, [x21]
    3eb0:	f9000661 	str	x1, [x19, #8]
    3eb4:	f94006a1 	ldr	x1, [x21, #8]
    3eb8:	f9000a61 	str	x1, [x19, #16]
    3ebc:	a94153f3 	ldp	x19, x20, [sp, #16]
    3ec0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3ec4:	a94363f7 	ldp	x23, x24, [sp, #48]
    3ec8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3ecc:	d65f03c0 	ret
    3ed0:	8b020063 	add	x3, x3, x2
    3ed4:	f9400473 	ldr	x19, [x3, #8]
    3ed8:	b4000113 	cbz	x19, 3ef8 <fwp_data.part.0.constprop.0+0x108>
    3edc:	f9400860 	ldr	x0, [x3, #16]
    3ee0:	cb130000 	sub	x0, x0, x19
    3ee4:	eb0002df 	cmp	x22, x0
    3ee8:	54000088 	b.hi	3ef8 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    3eec:	8b160260 	add	x0, x19, x22
    3ef0:	f9000460 	str	x0, [x3, #8]
    3ef4:	17ffffd5 	b	3e48 <fwp_data.part.0.constprop.0+0x58>
    3ef8:	52800001 	mov	w1, #0x0                   	// #0
    3efc:	d2800300 	mov	x0, #0x18                  	// #24
    3f00:	97fffcfc 	bl	32f0 <fwp_heap_alloc_slow>
    3f04:	aa0003f3 	mov	x19, x0
    3f08:	17ffffe6 	b	3ea0 <fwp_data.part.0.constprop.0+0xb0>
    3f0c:	97fff741 	bl	1c10 <fwp_heap_oom>

0000000000003f10 <f74>:
    3f10:	9e670003 	fmov	d3, x0
    3f14:	9e670021 	fmov	d1, x1
    3f18:	d2f80f20 	mov	x0, #0xc079000000000000    	// #-4577627546245398528
    3f1c:	1e6e1002 	fmov	d2, #1.000000000000000000e+00
    3f20:	1e630865 	fmul	d5, d3, d3
    3f24:	9e670000 	fmov	d0, x0
    3f28:	1e633842 	fsub	d2, d2, d3
    3f2c:	d10103ff 	sub	sp, sp, #0x40
    3f30:	1e600860 	fmul	d0, d3, d0
    3f34:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    3f38:	900000e2 	adrp	x2, 1f000 <__FRAME_END__+0x16b00>
    3f3c:	f947f442 	ldr	x2, [x2, #4072]
    3f40:	1e653821 	fsub	d1, d1, d5
    3f44:	1e622842 	fadd	d2, d2, d2
    3f48:	a9027bfd 	stp	x29, x30, [sp, #32]
    3f4c:	9e670004 	fmov	d4, x0
    3f50:	910083fd 	add	x29, sp, #0x20
    3f54:	1e610800 	fmul	d0, d0, d1
    3f58:	a90353f3 	stp	x19, x20, [sp, #48]
    3f5c:	1e640821 	fmul	d1, d1, d4
    3f60:	f9400043 	ldr	x3, [x2]
    3f64:	f9000fe3 	str	x3, [sp, #24]
    3f68:	d2800003 	mov	x3, #0x0                   	// #0
    3f6c:	910023e1 	add	x1, sp, #0x8
    3f70:	52800000 	mov	w0, #0x0                   	// #0
    3f74:	1e623800 	fsub	d0, d0, d2
    3f78:	6d0087e0 	stp	d0, d1, [sp, #8]
    3f7c:	97ffff9d 	bl	3df0 <fwp_data.part.0.constprop.0>
    3f80:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3f84:	91134063 	add	x3, x3, #0x4d0
    3f88:	aa0003f3 	mov	x19, x0
    3f8c:	f949d861 	ldr	x1, [x3, #5040]
    3f90:	f949ec60 	ldr	x0, [x3, #5080]
    3f94:	cb010261 	sub	x1, x19, x1
    3f98:	eb00403f 	cmp	x1, x0, lsl #16
    3f9c:	54000322 	b.cs	4000 <f74+0xf0>  // b.hs, b.nlast
    3fa0:	d350fc22 	lsr	x2, x1, #16
    3fa4:	f949fc63 	ldr	x3, [x3, #5112]
    3fa8:	8b020842 	add	x2, x2, x2, lsl #2
    3fac:	d37df042 	lsl	x2, x2, #3
    3fb0:	8b020060 	add	x0, x3, x2
    3fb4:	f9401014 	ldr	x20, [x0, #32]
    3fb8:	b4000254 	cbz	x20, 4000 <f74+0xf0>
    3fbc:	38626862 	ldrb	w2, [x3, x2]
    3fc0:	7100085f 	cmp	w2, #0x2
    3fc4:	54000360 	b.eq	4030 <f74+0x120>  // b.none
    3fc8:	7100045f 	cmp	w2, #0x1
    3fcc:	540001a1 	b.ne	4000 <f74+0xf0>  // b.any
    3fd0:	29430002 	ldp	w2, w0, [x0, #24]
    3fd4:	92403c21 	and	x1, x1, #0xffff
    3fd8:	9b027c21 	mul	x1, x1, x2
    3fdc:	d360fc21 	lsr	x1, x1, #32
    3fe0:	eb00003f 	cmp	x1, x0
    3fe4:	540000e2 	b.cs	4000 <f74+0xf0>  // b.hs, b.nlast
    3fe8:	8b010294 	add	x20, x20, x1
    3fec:	39400280 	ldrb	w0, [x20]
    3ff0:	7103fc1f 	cmp	w0, #0xff
    3ff4:	54000240 	b.eq	403c <f74+0x12c>  // b.none
    3ff8:	52800020 	mov	w0, #0x1                   	// #1
    3ffc:	39000280 	strb	w0, [x20]
    4000:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    4004:	f947f400 	ldr	x0, [x0, #4072]
    4008:	f9400fe2 	ldr	x2, [sp, #24]
    400c:	f9400001 	ldr	x1, [x0]
    4010:	eb010042 	subs	x2, x2, x1
    4014:	d2800001 	mov	x1, #0x0                   	// #0
    4018:	54000181 	b.ne	4048 <f74+0x138>  // b.any
    401c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4020:	aa1303e0 	mov	x0, x19
    4024:	a94353f3 	ldp	x19, x20, [sp, #48]
    4028:	910103ff 	add	sp, sp, #0x40
    402c:	d65f03c0 	ret
    4030:	72003c3f 	tst	w1, #0xffff
    4034:	54fffe61 	b.ne	4000 <f74+0xf0>  // b.any
    4038:	17ffffed 	b	3fec <f74+0xdc>
    403c:	aa1403e0 	mov	x0, x20
    4040:	97fffb44 	bl	2d50 <fwp_rc_forget_slot>
    4044:	17ffffed 	b	3ff8 <f74+0xe8>
    4048:	97fff52a 	bl	14f0 <__stack_chk_fail@plt>
    404c:	d503201f 	nop

0000000000004050 <fwp_owned_entry74>:
    4050:	a9400400 	ldp	x0, x1, [x0]
    4054:	17ffffaf 	b	3f10 <f74>
    4058:	d503201f 	nop
    405c:	d503201f 	nop

0000000000004060 <e74>:
    4060:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4064:	910003fd 	mov	x29, sp
    4068:	a9400400 	ldp	x0, x1, [x0]
    406c:	f9000bf3 	str	x19, [sp, #16]
    4070:	97ffffa8 	bl	3f10 <f74>
    4074:	aa0003f3 	mov	x19, x0
    4078:	97fffcf6 	bl	3450 <fwp_rc_share>
    407c:	aa1303e0 	mov	x0, x19
    4080:	f9400bf3 	ldr	x19, [sp, #16]
    4084:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4088:	d65f03c0 	ret
    408c:	d503201f 	nop

0000000000004090 <fwp_map_finish_protected.isra.0>:
    4090:	d10183ff 	sub	sp, sp, #0x60
    4094:	a9027bfd 	stp	x29, x30, [sp, #32]
    4098:	910083fd 	add	x29, sp, #0x20
    409c:	a90563f7 	stp	x23, x24, [sp, #80]
    40a0:	aa0003f7 	mov	x23, x0
    40a4:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    40a8:	f947f400 	ldr	x0, [x0, #4072]
    40ac:	a9045bf5 	stp	x21, x22, [sp, #64]
    40b0:	a940d6e2 	ldp	x2, x21, [x23, #8]
    40b4:	f9400001 	ldr	x1, [x0]
    40b8:	f9000fe1 	str	x1, [sp, #24]
    40bc:	d2800001 	mov	x1, #0x0                   	// #0
    40c0:	b40005e2 	cbz	x2, 417c <fwp_map_finish_protected.isra.0+0xec>
    40c4:	b0000178 	adrp	x24, 31000 <fwp_root_context+0xd10>
    40c8:	91134318 	add	x24, x24, #0x4d0
    40cc:	a90353f3 	stp	x19, x20, [sp, #48]
    40d0:	910023f3 	add	x19, sp, #0x8
    40d4:	52800034 	mov	w20, #0x1                   	// #1
    40d8:	f94002e3 	ldr	x3, [x23]
    40dc:	aa1303e1 	mov	x1, x19
    40e0:	52800020 	mov	w0, #0x1                   	// #1
    40e4:	8b020c62 	add	x2, x3, x2, lsl #3
    40e8:	f85f8042 	ldur	x2, [x2, #-8]
    40ec:	a900d7e2 	stp	x2, x21, [sp, #8]
    40f0:	97ffff40 	bl	3df0 <fwp_data.part.0.constprop.0>
    40f4:	aa0003f5 	mov	x21, x0
    40f8:	f949db01 	ldr	x1, [x24, #5040]
    40fc:	f949ef02 	ldr	x2, [x24, #5080]
    4100:	cb010001 	sub	x1, x0, x1
    4104:	eb02403f 	cmp	x1, x2, lsl #16
    4108:	54000302 	b.cs	4168 <fwp_map_finish_protected.isra.0+0xd8>  // b.hs, b.nlast
    410c:	d350fc22 	lsr	x2, x1, #16
    4110:	f949ff04 	ldr	x4, [x24, #5112]
    4114:	8b020842 	add	x2, x2, x2, lsl #2
    4118:	d37df042 	lsl	x2, x2, #3
    411c:	8b020083 	add	x3, x4, x2
    4120:	f9401076 	ldr	x22, [x3, #32]
    4124:	b4000236 	cbz	x22, 4168 <fwp_map_finish_protected.isra.0+0xd8>
    4128:	38626882 	ldrb	w2, [x4, x2]
    412c:	7100085f 	cmp	w2, #0x2
    4130:	540004a0 	b.eq	41c4 <fwp_map_finish_protected.isra.0+0x134>  // b.none
    4134:	7100045f 	cmp	w2, #0x1
    4138:	54000181 	b.ne	4168 <fwp_map_finish_protected.isra.0+0xd8>  // b.any
    413c:	29430062 	ldp	w2, w0, [x3, #24]
    4140:	92403c21 	and	x1, x1, #0xffff
    4144:	9b027c21 	mul	x1, x1, x2
    4148:	d360fc21 	lsr	x1, x1, #32
    414c:	eb00003f 	cmp	x1, x0
    4150:	540000c2 	b.cs	4168 <fwp_map_finish_protected.isra.0+0xd8>  // b.hs, b.nlast
    4154:	8b0102d6 	add	x22, x22, x1
    4158:	394002c0 	ldrb	w0, [x22]
    415c:	7103fc1f 	cmp	w0, #0xff
    4160:	540002c0 	b.eq	41b8 <fwp_map_finish_protected.isra.0+0x128>  // b.none
    4164:	390002d4 	strb	w20, [x22]
    4168:	f94006e2 	ldr	x2, [x23, #8]
    416c:	d1000442 	sub	x2, x2, #0x1
    4170:	a900d6e2 	stp	x2, x21, [x23, #8]
    4174:	b5fffb22 	cbnz	x2, 40d8 <fwp_map_finish_protected.isra.0+0x48>
    4178:	a94353f3 	ldp	x19, x20, [sp, #48]
    417c:	f94002e0 	ldr	x0, [x23]
    4180:	97fffb94 	bl	2fd0 <fwp_mem_free>
    4184:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    4188:	f947f400 	ldr	x0, [x0, #4072]
    418c:	f9400fe2 	ldr	x2, [sp, #24]
    4190:	f9400001 	ldr	x1, [x0]
    4194:	eb010042 	subs	x2, x2, x1
    4198:	d2800001 	mov	x1, #0x0                   	// #0
    419c:	540001a1 	b.ne	41d0 <fwp_map_finish_protected.isra.0+0x140>  // b.any
    41a0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    41a4:	aa1503e0 	mov	x0, x21
    41a8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    41ac:	a94563f7 	ldp	x23, x24, [sp, #80]
    41b0:	910183ff 	add	sp, sp, #0x60
    41b4:	d65f03c0 	ret
    41b8:	aa1603e0 	mov	x0, x22
    41bc:	97fffae5 	bl	2d50 <fwp_rc_forget_slot>
    41c0:	17ffffe9 	b	4164 <fwp_map_finish_protected.isra.0+0xd4>
    41c4:	72003c3f 	tst	w1, #0xffff
    41c8:	54fffd01 	b.ne	4168 <fwp_map_finish_protected.isra.0+0xd8>  // b.any
    41cc:	17ffffe3 	b	4158 <fwp_map_finish_protected.isra.0+0xc8>
    41d0:	a90353f3 	stp	x19, x20, [sp, #48]
    41d4:	97fff4c7 	bl	14f0 <__stack_chk_fail@plt>
    41d8:	d503201f 	nop
    41dc:	d503201f 	nop

00000000000041e0 <fwp_drop4>:
    41e0:	b0000165 	adrp	x5, 31000 <fwp_root_context+0xd10>
    41e4:	911340a3 	add	x3, x5, #0x4d0
    41e8:	f949d861 	ldr	x1, [x3, #5040]
    41ec:	f949ec62 	ldr	x2, [x3, #5080]
    41f0:	cb010001 	sub	x1, x0, x1
    41f4:	eb02403f 	cmp	x1, x2, lsl #16
    41f8:	54000542 	b.cs	42a0 <fwp_drop4+0xc0>  // b.hs, b.nlast
    41fc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4200:	d350fc22 	lsr	x2, x1, #16
    4204:	910003fd 	mov	x29, sp
    4208:	8b020842 	add	x2, x2, x2, lsl #2
    420c:	f949fc64 	ldr	x4, [x3, #5112]
    4210:	d37df042 	lsl	x2, x2, #3
    4214:	f9000bf3 	str	x19, [sp, #16]
    4218:	8b020083 	add	x3, x4, x2
    421c:	f9401073 	ldr	x19, [x3, #32]
    4220:	b40002b3 	cbz	x19, 4274 <fwp_drop4+0x94>
    4224:	38626882 	ldrb	w2, [x4, x2]
    4228:	7100085f 	cmp	w2, #0x2
    422c:	540002a0 	b.eq	4280 <fwp_drop4+0xa0>  // b.none
    4230:	7100045f 	cmp	w2, #0x1
    4234:	54000201 	b.ne	4274 <fwp_drop4+0x94>  // b.any
    4238:	29430864 	ldp	w4, w2, [x3, #24]
    423c:	92403c21 	and	x1, x1, #0xffff
    4240:	9b047c21 	mul	x1, x1, x4
    4244:	d360fc21 	lsr	x1, x1, #32
    4248:	eb02003f 	cmp	x1, x2
    424c:	54000142 	b.cs	4274 <fwp_drop4+0x94>  // b.hs, b.nlast
    4250:	8b010273 	add	x19, x19, x1
    4254:	39400261 	ldrb	w1, [x19]
    4258:	340000e1 	cbz	w1, 4274 <fwp_drop4+0x94>
    425c:	7100043f 	cmp	w1, #0x1
    4260:	540001a0 	b.eq	4294 <fwp_drop4+0xb4>  // b.none
    4264:	7103fc3f 	cmp	w1, #0xff
    4268:	540001e0 	b.eq	42a4 <fwp_drop4+0xc4>  // b.none
    426c:	51000421 	sub	w1, w1, #0x1
    4270:	39000261 	strb	w1, [x19]
    4274:	f9400bf3 	ldr	x19, [sp, #16]
    4278:	a8c27bfd 	ldp	x29, x30, [sp], #32
    427c:	d65f03c0 	ret
    4280:	72003c3f 	tst	w1, #0xffff
    4284:	54fffe80 	b.eq	4254 <fwp_drop4+0x74>  // b.none
    4288:	f9400bf3 	ldr	x19, [sp, #16]
    428c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4290:	d65f03c0 	ret
    4294:	f9400bf3 	ldr	x19, [sp, #16]
    4298:	a8c27bfd 	ldp	x29, x30, [sp], #32
    429c:	17fffb4d 	b	2fd0 <fwp_mem_free>
    42a0:	d65f03c0 	ret
    42a4:	ca534660 	eor	x0, x19, x19, lsr #17
    42a8:	911340a5 	add	x5, x5, #0x4d0
    42ac:	ca402400 	eor	x0, x0, x0, lsr #9
    42b0:	8b200ca0 	add	x0, x5, w0, uxtb #3
    42b4:	f94a2400 	ldr	x0, [x0, #5192]
    42b8:	b5000080 	cbnz	x0, 42c8 <fwp_drop4+0xe8>
    42bc:	14000010 	b	42fc <fwp_drop4+0x11c>
    42c0:	f9400800 	ldr	x0, [x0, #16]
    42c4:	b40001c0 	cbz	x0, 42fc <fwp_drop4+0x11c>
    42c8:	f9400001 	ldr	x1, [x0]
    42cc:	eb13003f 	cmp	x1, x19
    42d0:	54ffff81 	b.ne	42c0 <fwp_drop4+0xe0>  // b.any
    42d4:	f9400401 	ldr	x1, [x0, #8]
    42d8:	d1000421 	sub	x1, x1, #0x1
    42dc:	f9000401 	str	x1, [x0, #8]
    42e0:	f103f83f 	cmp	x1, #0xfe
    42e4:	54fffc81 	b.ne	4274 <fwp_drop4+0x94>  // b.any
    42e8:	aa1303e0 	mov	x0, x19
    42ec:	97fffa99 	bl	2d50 <fwp_rc_forget_slot>
    42f0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    42f4:	39000260 	strb	w0, [x19]
    42f8:	17ffffdf 	b	4274 <fwp_drop4+0x94>
    42fc:	f0000000 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    4300:	9102c000 	add	x0, x0, #0xb0
    4304:	97fff787 	bl	2120 <fwp_trap>
    4308:	d503201f 	nop
    430c:	d503201f 	nop

0000000000004310 <fwp_owned_entry50>:
    4310:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4314:	910003fd 	mov	x29, sp
    4318:	f9400000 	ldr	x0, [x0]
    431c:	f9000bf3 	str	x19, [sp, #16]
    4320:	f9400813 	ldr	x19, [x0, #16]
    4324:	97ffffaf 	bl	41e0 <fwp_drop4>
    4328:	aa1303e0 	mov	x0, x19
    432c:	f9400bf3 	ldr	x19, [sp, #16]
    4330:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4334:	d65f03c0 	ret
    4338:	d503201f 	nop
    433c:	d503201f 	nop

0000000000004340 <fwp_owned_entry47>:
    4340:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4344:	910003fd 	mov	x29, sp
    4348:	f9400000 	ldr	x0, [x0]
    434c:	f9000bf3 	str	x19, [sp, #16]
    4350:	f9400413 	ldr	x19, [x0, #8]
    4354:	97ffffa3 	bl	41e0 <fwp_drop4>
    4358:	aa1303e0 	mov	x0, x19
    435c:	f9400bf3 	ldr	x19, [sp, #16]
    4360:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4364:	d65f03c0 	ret
    4368:	d503201f 	nop
    436c:	d503201f 	nop

0000000000004370 <fwp_arg_drop47>:
    4370:	7100003f 	cmp	w1, #0x0
    4374:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4378:	54000041 	b.ne	4380 <fwp_arg_drop47+0x10>  // b.any
    437c:	d65f03c0 	ret
    4380:	f9400000 	ldr	x0, [x0]
    4384:	17ffff97 	b	41e0 <fwp_drop4>
    4388:	d503201f 	nop
    438c:	d503201f 	nop

0000000000004390 <e50>:
    4390:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4394:	910003fd 	mov	x29, sp
    4398:	a90153f3 	stp	x19, x20, [sp, #16]
    439c:	f9400013 	ldr	x19, [x0]
    43a0:	aa1303e0 	mov	x0, x19
    43a4:	97fffc2b 	bl	3450 <fwp_rc_share>
    43a8:	f9400a74 	ldr	x20, [x19, #16]
    43ac:	aa1303e0 	mov	x0, x19
    43b0:	97ffff8c 	bl	41e0 <fwp_drop4>
    43b4:	aa1403e0 	mov	x0, x20
    43b8:	97fffc26 	bl	3450 <fwp_rc_share>
    43bc:	aa1403e0 	mov	x0, x20
    43c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    43c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43c8:	d65f03c0 	ret
    43cc:	d503201f 	nop

00000000000043d0 <e47>:
    43d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    43d4:	910003fd 	mov	x29, sp
    43d8:	a90153f3 	stp	x19, x20, [sp, #16]
    43dc:	f9400013 	ldr	x19, [x0]
    43e0:	aa1303e0 	mov	x0, x19
    43e4:	97fffc1b 	bl	3450 <fwp_rc_share>
    43e8:	f9400674 	ldr	x20, [x19, #8]
    43ec:	aa1303e0 	mov	x0, x19
    43f0:	97ffff7c 	bl	41e0 <fwp_drop4>
    43f4:	aa1403e0 	mov	x0, x20
    43f8:	97fffc16 	bl	3450 <fwp_rc_share>
    43fc:	aa1403e0 	mov	x0, x20
    4400:	a94153f3 	ldp	x19, x20, [sp, #16]
    4404:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4408:	d65f03c0 	ret
    440c:	d503201f 	nop

0000000000004410 <fwp_arg_drop50>:
    4410:	7100003f 	cmp	w1, #0x0
    4414:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4418:	54000041 	b.ne	4420 <fwp_arg_drop50+0x10>  // b.any
    441c:	d65f03c0 	ret
    4420:	f9400000 	ldr	x0, [x0]
    4424:	17ffff6f 	b	41e0 <fwp_drop4>
    4428:	d503201f 	nop
    442c:	d503201f 	nop

0000000000004430 <fwp_args47>:
    4430:	7100003f 	cmp	w1, #0x0
    4434:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4438:	54000041 	b.ne	4440 <fwp_args47+0x10>  // b.any
    443c:	d65f03c0 	ret
    4440:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    4444:	91134042 	add	x2, x2, #0x4d0
    4448:	f9400001 	ldr	x1, [x0]
    444c:	f949d843 	ldr	x3, [x2, #5040]
    4450:	f949ec40 	ldr	x0, [x2, #5080]
    4454:	cb030021 	sub	x1, x1, x3
    4458:	eb00403f 	cmp	x1, x0, lsl #16
    445c:	54ffff02 	b.cs	443c <fwp_args47+0xc>  // b.hs, b.nlast
    4460:	d350fc20 	lsr	x0, x1, #16
    4464:	f949fc44 	ldr	x4, [x2, #5112]
    4468:	8b000800 	add	x0, x0, x0, lsl #2
    446c:	d37df002 	lsl	x2, x0, #3
    4470:	8b020083 	add	x3, x4, x2
    4474:	f9401060 	ldr	x0, [x3, #32]
    4478:	b4fffe20 	cbz	x0, 443c <fwp_args47+0xc>
    447c:	38626882 	ldrb	w2, [x4, x2]
    4480:	7100085f 	cmp	w2, #0x2
    4484:	54000220 	b.eq	44c8 <fwp_args47+0x98>  // b.none
    4488:	7100045f 	cmp	w2, #0x1
    448c:	54fffd81 	b.ne	443c <fwp_args47+0xc>  // b.any
    4490:	29430864 	ldp	w4, w2, [x3, #24]
    4494:	92403c21 	and	x1, x1, #0xffff
    4498:	9b047c21 	mul	x1, x1, x4
    449c:	d360fc21 	lsr	x1, x1, #32
    44a0:	eb02003f 	cmp	x1, x2
    44a4:	54fffcc2 	b.cs	443c <fwp_args47+0xc>  // b.hs, b.nlast
    44a8:	8b010000 	add	x0, x0, x1
    44ac:	39400001 	ldrb	w1, [x0]
    44b0:	34fffc61 	cbz	w1, 443c <fwp_args47+0xc>
    44b4:	7103f43f 	cmp	w1, #0xfd
    44b8:	540000e8 	b.hi	44d4 <fwp_args47+0xa4>  // b.pmore
    44bc:	11000421 	add	w1, w1, #0x1
    44c0:	39000001 	strb	w1, [x0]
    44c4:	d65f03c0 	ret
    44c8:	72003c3f 	tst	w1, #0xffff
    44cc:	54ffff00 	b.eq	44ac <fwp_args47+0x7c>  // b.none
    44d0:	d65f03c0 	ret
    44d4:	17fff9d8 	b	2c34 <fwp_rc_wide_dup>
    44d8:	d503201f 	nop
    44dc:	d503201f 	nop

00000000000044e0 <fwp_args50>:
    44e0:	7100003f 	cmp	w1, #0x0
    44e4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    44e8:	54000041 	b.ne	44f0 <fwp_args50+0x10>  // b.any
    44ec:	d65f03c0 	ret
    44f0:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    44f4:	91134042 	add	x2, x2, #0x4d0
    44f8:	f9400001 	ldr	x1, [x0]
    44fc:	f949d843 	ldr	x3, [x2, #5040]
    4500:	f949ec40 	ldr	x0, [x2, #5080]
    4504:	cb030021 	sub	x1, x1, x3
    4508:	eb00403f 	cmp	x1, x0, lsl #16
    450c:	54ffff02 	b.cs	44ec <fwp_args50+0xc>  // b.hs, b.nlast
    4510:	d350fc20 	lsr	x0, x1, #16
    4514:	f949fc44 	ldr	x4, [x2, #5112]
    4518:	8b000800 	add	x0, x0, x0, lsl #2
    451c:	d37df002 	lsl	x2, x0, #3
    4520:	8b020083 	add	x3, x4, x2
    4524:	f9401060 	ldr	x0, [x3, #32]
    4528:	b4fffe20 	cbz	x0, 44ec <fwp_args50+0xc>
    452c:	38626882 	ldrb	w2, [x4, x2]
    4530:	7100085f 	cmp	w2, #0x2
    4534:	54000220 	b.eq	4578 <fwp_args50+0x98>  // b.none
    4538:	7100045f 	cmp	w2, #0x1
    453c:	54fffd81 	b.ne	44ec <fwp_args50+0xc>  // b.any
    4540:	29430864 	ldp	w4, w2, [x3, #24]
    4544:	92403c21 	and	x1, x1, #0xffff
    4548:	9b047c21 	mul	x1, x1, x4
    454c:	d360fc21 	lsr	x1, x1, #32
    4550:	eb02003f 	cmp	x1, x2
    4554:	54fffcc2 	b.cs	44ec <fwp_args50+0xc>  // b.hs, b.nlast
    4558:	8b010000 	add	x0, x0, x1
    455c:	39400001 	ldrb	w1, [x0]
    4560:	34fffc61 	cbz	w1, 44ec <fwp_args50+0xc>
    4564:	7103f43f 	cmp	w1, #0xfd
    4568:	540000e8 	b.hi	4584 <fwp_args50+0xa4>  // b.pmore
    456c:	11000421 	add	w1, w1, #0x1
    4570:	39000001 	strb	w1, [x0]
    4574:	d65f03c0 	ret
    4578:	72003c3f 	tst	w1, #0xffff
    457c:	54ffff00 	b.eq	455c <fwp_args50+0x7c>  // b.none
    4580:	d65f03c0 	ret
    4584:	17fff9ac 	b	2c34 <fwp_rc_wide_dup>
    4588:	d503201f 	nop
    458c:	d503201f 	nop

0000000000004590 <fwp_caps47>:
    4590:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4594:	910003fd 	mov	x29, sp
    4598:	f9000bf3 	str	x19, [sp, #16]
    459c:	aa0003f3 	mov	x19, x0
    45a0:	b9400400 	ldr	w0, [x0, #4]
    45a4:	340004a0 	cbz	w0, 4638 <fwp_caps47+0xa8>
    45a8:	f9400660 	ldr	x0, [x19, #8]
    45ac:	350004e1 	cbnz	w1, 4648 <fwp_caps47+0xb8>
    45b0:	97ffff0c 	bl	41e0 <fwp_drop4>
    45b4:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    45b8:	91134042 	add	x2, x2, #0x4d0
    45bc:	f949d840 	ldr	x0, [x2, #5040]
    45c0:	f949ec41 	ldr	x1, [x2, #5080]
    45c4:	cb000260 	sub	x0, x19, x0
    45c8:	eb01401f 	cmp	x0, x1, lsl #16
    45cc:	54000382 	b.cs	463c <fwp_caps47+0xac>  // b.hs, b.nlast
    45d0:	d350fc01 	lsr	x1, x0, #16
    45d4:	f949fc44 	ldr	x4, [x2, #5112]
    45d8:	8b010821 	add	x1, x1, x1, lsl #2
    45dc:	d37df021 	lsl	x1, x1, #3
    45e0:	8b010083 	add	x3, x4, x1
    45e4:	f9401062 	ldr	x2, [x3, #32]
    45e8:	b40002a2 	cbz	x2, 463c <fwp_caps47+0xac>
    45ec:	38616881 	ldrb	w1, [x4, x1]
    45f0:	7100083f 	cmp	w1, #0x2
    45f4:	540006c0 	b.eq	46cc <fwp_caps47+0x13c>  // b.none
    45f8:	7100043f 	cmp	w1, #0x1
    45fc:	54000201 	b.ne	463c <fwp_caps47+0xac>  // b.any
    4600:	29430464 	ldp	w4, w1, [x3, #24]
    4604:	92403c00 	and	x0, x0, #0xffff
    4608:	9b047c00 	mul	x0, x0, x4
    460c:	d360fc00 	lsr	x0, x0, #32
    4610:	eb01001f 	cmp	x0, x1
    4614:	54000142 	b.cs	463c <fwp_caps47+0xac>  // b.hs, b.nlast
    4618:	8b000042 	add	x2, x2, x0
    461c:	39400040 	ldrb	w0, [x2]
    4620:	7100041f 	cmp	w0, #0x1
    4624:	540000c1 	b.ne	463c <fwp_caps47+0xac>  // b.any
    4628:	aa1303e0 	mov	x0, x19
    462c:	f9400bf3 	ldr	x19, [sp, #16]
    4630:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4634:	17fffa67 	b	2fd0 <fwp_mem_free>
    4638:	34fffbe1 	cbz	w1, 45b4 <fwp_caps47+0x24>
    463c:	f9400bf3 	ldr	x19, [sp, #16]
    4640:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4644:	d65f03c0 	ret
    4648:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    464c:	91134042 	add	x2, x2, #0x4d0
    4650:	f949d843 	ldr	x3, [x2, #5040]
    4654:	f949ec41 	ldr	x1, [x2, #5080]
    4658:	cb030000 	sub	x0, x0, x3
    465c:	eb01401f 	cmp	x0, x1, lsl #16
    4660:	54fffee2 	b.cs	463c <fwp_caps47+0xac>  // b.hs, b.nlast
    4664:	d350fc01 	lsr	x1, x0, #16
    4668:	f949fc44 	ldr	x4, [x2, #5112]
    466c:	8b010821 	add	x1, x1, x1, lsl #2
    4670:	d37df021 	lsl	x1, x1, #3
    4674:	8b010083 	add	x3, x4, x1
    4678:	f9401062 	ldr	x2, [x3, #32]
    467c:	b4fffe02 	cbz	x2, 463c <fwp_caps47+0xac>
    4680:	38616881 	ldrb	w1, [x4, x1]
    4684:	7100083f 	cmp	w1, #0x2
    4688:	54000280 	b.eq	46d8 <fwp_caps47+0x148>  // b.none
    468c:	7100043f 	cmp	w1, #0x1
    4690:	54fffd61 	b.ne	463c <fwp_caps47+0xac>  // b.any
    4694:	92403c01 	and	x1, x0, #0xffff
    4698:	29430064 	ldp	w4, w0, [x3, #24]
    469c:	9b047c21 	mul	x1, x1, x4
    46a0:	d360fc21 	lsr	x1, x1, #32
    46a4:	eb00003f 	cmp	x1, x0
    46a8:	54fffca2 	b.cs	463c <fwp_caps47+0xac>  // b.hs, b.nlast
    46ac:	8b010042 	add	x2, x2, x1
    46b0:	39400040 	ldrb	w0, [x2]
    46b4:	34fffc40 	cbz	w0, 463c <fwp_caps47+0xac>
    46b8:	7103f41f 	cmp	w0, #0xfd
    46bc:	54000148 	b.hi	46e4 <fwp_caps47+0x154>  // b.pmore
    46c0:	11000400 	add	w0, w0, #0x1
    46c4:	39000040 	strb	w0, [x2]
    46c8:	17ffffdd 	b	463c <fwp_caps47+0xac>
    46cc:	72003c1f 	tst	w0, #0xffff
    46d0:	54fffb61 	b.ne	463c <fwp_caps47+0xac>  // b.any
    46d4:	17ffffd2 	b	461c <fwp_caps47+0x8c>
    46d8:	72003c1f 	tst	w0, #0xffff
    46dc:	54fffb01 	b.ne	463c <fwp_caps47+0xac>  // b.any
    46e0:	17fffff4 	b	46b0 <fwp_caps47+0x120>
    46e4:	f9400bf3 	ldr	x19, [sp, #16]
    46e8:	aa0203e0 	mov	x0, x2
    46ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    46f0:	17fff951 	b	2c34 <fwp_rc_wide_dup>

00000000000046f4 <fwp_caps50>:
    46f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    46f8:	910003fd 	mov	x29, sp
    46fc:	f9000bf3 	str	x19, [sp, #16]
    4700:	aa0003f3 	mov	x19, x0
    4704:	b9400400 	ldr	w0, [x0, #4]
    4708:	340004a0 	cbz	w0, 479c <fwp_caps50+0xa8>
    470c:	f9400660 	ldr	x0, [x19, #8]
    4710:	350004e1 	cbnz	w1, 47ac <fwp_caps50+0xb8>
    4714:	97fffeb3 	bl	41e0 <fwp_drop4>
    4718:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    471c:	91134042 	add	x2, x2, #0x4d0
    4720:	f949d840 	ldr	x0, [x2, #5040]
    4724:	f949ec41 	ldr	x1, [x2, #5080]
    4728:	cb000260 	sub	x0, x19, x0
    472c:	eb01401f 	cmp	x0, x1, lsl #16
    4730:	54000382 	b.cs	47a0 <fwp_caps50+0xac>  // b.hs, b.nlast
    4734:	d350fc01 	lsr	x1, x0, #16
    4738:	f949fc44 	ldr	x4, [x2, #5112]
    473c:	8b010821 	add	x1, x1, x1, lsl #2
    4740:	d37df021 	lsl	x1, x1, #3
    4744:	8b010083 	add	x3, x4, x1
    4748:	f9401062 	ldr	x2, [x3, #32]
    474c:	b40002a2 	cbz	x2, 47a0 <fwp_caps50+0xac>
    4750:	38616881 	ldrb	w1, [x4, x1]
    4754:	7100083f 	cmp	w1, #0x2
    4758:	540006c0 	b.eq	4830 <fwp_caps50+0x13c>  // b.none
    475c:	7100043f 	cmp	w1, #0x1
    4760:	54000201 	b.ne	47a0 <fwp_caps50+0xac>  // b.any
    4764:	29430464 	ldp	w4, w1, [x3, #24]
    4768:	92403c00 	and	x0, x0, #0xffff
    476c:	9b047c00 	mul	x0, x0, x4
    4770:	d360fc00 	lsr	x0, x0, #32
    4774:	eb01001f 	cmp	x0, x1
    4778:	54000142 	b.cs	47a0 <fwp_caps50+0xac>  // b.hs, b.nlast
    477c:	8b000042 	add	x2, x2, x0
    4780:	39400040 	ldrb	w0, [x2]
    4784:	7100041f 	cmp	w0, #0x1
    4788:	540000c1 	b.ne	47a0 <fwp_caps50+0xac>  // b.any
    478c:	aa1303e0 	mov	x0, x19
    4790:	f9400bf3 	ldr	x19, [sp, #16]
    4794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4798:	17fffa0e 	b	2fd0 <fwp_mem_free>
    479c:	34fffbe1 	cbz	w1, 4718 <fwp_caps50+0x24>
    47a0:	f9400bf3 	ldr	x19, [sp, #16]
    47a4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    47a8:	d65f03c0 	ret
    47ac:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    47b0:	91134042 	add	x2, x2, #0x4d0
    47b4:	f949d843 	ldr	x3, [x2, #5040]
    47b8:	f949ec41 	ldr	x1, [x2, #5080]
    47bc:	cb030000 	sub	x0, x0, x3
    47c0:	eb01401f 	cmp	x0, x1, lsl #16
    47c4:	54fffee2 	b.cs	47a0 <fwp_caps50+0xac>  // b.hs, b.nlast
    47c8:	d350fc01 	lsr	x1, x0, #16
    47cc:	f949fc44 	ldr	x4, [x2, #5112]
    47d0:	8b010821 	add	x1, x1, x1, lsl #2
    47d4:	d37df021 	lsl	x1, x1, #3
    47d8:	8b010083 	add	x3, x4, x1
    47dc:	f9401062 	ldr	x2, [x3, #32]
    47e0:	b4fffe02 	cbz	x2, 47a0 <fwp_caps50+0xac>
    47e4:	38616881 	ldrb	w1, [x4, x1]
    47e8:	7100083f 	cmp	w1, #0x2
    47ec:	54000280 	b.eq	483c <fwp_caps50+0x148>  // b.none
    47f0:	7100043f 	cmp	w1, #0x1
    47f4:	54fffd61 	b.ne	47a0 <fwp_caps50+0xac>  // b.any
    47f8:	92403c01 	and	x1, x0, #0xffff
    47fc:	29430064 	ldp	w4, w0, [x3, #24]
    4800:	9b047c21 	mul	x1, x1, x4
    4804:	d360fc21 	lsr	x1, x1, #32
    4808:	eb00003f 	cmp	x1, x0
    480c:	54fffca2 	b.cs	47a0 <fwp_caps50+0xac>  // b.hs, b.nlast
    4810:	8b010042 	add	x2, x2, x1
    4814:	39400040 	ldrb	w0, [x2]
    4818:	34fffc40 	cbz	w0, 47a0 <fwp_caps50+0xac>
    481c:	7103f41f 	cmp	w0, #0xfd
    4820:	54000148 	b.hi	4848 <fwp_caps50+0x154>  // b.pmore
    4824:	11000400 	add	w0, w0, #0x1
    4828:	39000040 	strb	w0, [x2]
    482c:	17ffffdd 	b	47a0 <fwp_caps50+0xac>
    4830:	72003c1f 	tst	w0, #0xffff
    4834:	54fffb61 	b.ne	47a0 <fwp_caps50+0xac>  // b.any
    4838:	17ffffd2 	b	4780 <fwp_caps50+0x8c>
    483c:	72003c1f 	tst	w0, #0xffff
    4840:	54fffb01 	b.ne	47a0 <fwp_caps50+0xac>  // b.any
    4844:	17fffff4 	b	4814 <fwp_caps50+0x120>
    4848:	f9400bf3 	ldr	x19, [sp, #16]
    484c:	aa0203e0 	mov	x0, x2
    4850:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4854:	17fff8f8 	b	2c34 <fwp_rc_wide_dup>
    4858:	d503201f 	nop
    485c:	d503201f 	nop

0000000000004860 <fwp_drop0>:
    4860:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4864:	910003fd 	mov	x29, sp
    4868:	a90153f3 	stp	x19, x20, [sp, #16]
    486c:	f90013f5 	str	x21, [sp, #32]
    4870:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    4874:	911342b4 	add	x20, x21, #0x4d0
    4878:	f949da81 	ldr	x1, [x20, #5040]
    487c:	f949ee82 	ldr	x2, [x20, #5080]
    4880:	cb010001 	sub	x1, x0, x1
    4884:	eb02403f 	cmp	x1, x2, lsl #16
    4888:	54000382 	b.cs	48f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    488c:	d350fc22 	lsr	x2, x1, #16
    4890:	f949fe83 	ldr	x3, [x20, #5112]
    4894:	8b020842 	add	x2, x2, x2, lsl #2
    4898:	d37df042 	lsl	x2, x2, #3
    489c:	8b020064 	add	x4, x3, x2
    48a0:	f9401093 	ldr	x19, [x4, #32]
    48a4:	b40002b3 	cbz	x19, 48f8 <fwp_drop0+0x98>
    48a8:	38626862 	ldrb	w2, [x3, x2]
    48ac:	7100085f 	cmp	w2, #0x2
    48b0:	540002c0 	b.eq	4908 <fwp_drop0+0xa8>  // b.none
    48b4:	7100045f 	cmp	w2, #0x1
    48b8:	54000201 	b.ne	48f8 <fwp_drop0+0x98>  // b.any
    48bc:	29430885 	ldp	w5, w2, [x4, #24]
    48c0:	92403c21 	and	x1, x1, #0xffff
    48c4:	9b057c21 	mul	x1, x1, x5
    48c8:	d360fc21 	lsr	x1, x1, #32
    48cc:	eb02003f 	cmp	x1, x2
    48d0:	54000142 	b.cs	48f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    48d4:	8b010273 	add	x19, x19, x1
    48d8:	39400261 	ldrb	w1, [x19]
    48dc:	340000e1 	cbz	w1, 48f8 <fwp_drop0+0x98>
    48e0:	7100043f 	cmp	w1, #0x1
    48e4:	540001e0 	b.eq	4920 <fwp_drop0+0xc0>  // b.none
    48e8:	7103fc3f 	cmp	w1, #0xff
    48ec:	540006e0 	b.eq	49c8 <fwp_drop0+0x168>  // b.none
    48f0:	51000421 	sub	w1, w1, #0x1
    48f4:	39000261 	strb	w1, [x19]
    48f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48fc:	f94013f5 	ldr	x21, [sp, #32]
    4900:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4904:	d65f03c0 	ret
    4908:	72003c3f 	tst	w1, #0xffff
    490c:	54fffe60 	b.eq	48d8 <fwp_drop0+0x78>  // b.none
    4910:	a94153f3 	ldp	x19, x20, [sp, #16]
    4914:	f94013f5 	ldr	x21, [sp, #32]
    4918:	a8c37bfd 	ldp	x29, x30, [sp], #48
    491c:	d65f03c0 	ret
    4920:	911342a1 	add	x1, x21, #0x4d0
    4924:	f9400813 	ldr	x19, [x0, #16]
    4928:	f949ec25 	ldr	x5, [x1, #5080]
    492c:	f949d821 	ldr	x1, [x1, #5040]
    4930:	d370bca5 	lsl	x5, x5, #16
    4934:	cb010002 	sub	x2, x0, x1
    4938:	eb05005f 	cmp	x2, x5
    493c:	54000362 	b.cs	49a8 <fwp_drop0+0x148>  // b.hs, b.nlast
    4940:	d350fc44 	lsr	x4, x2, #16
    4944:	8b040884 	add	x4, x4, x4, lsl #2
    4948:	d37df084 	lsl	x4, x4, #3
    494c:	8b040067 	add	x7, x3, x4
    4950:	f94010e6 	ldr	x6, [x7, #32]
    4954:	b40002a6 	cbz	x6, 49a8 <fwp_drop0+0x148>
    4958:	38646863 	ldrb	w3, [x3, x4]
    495c:	7100087f 	cmp	w3, #0x2
    4960:	540002e0 	b.eq	49bc <fwp_drop0+0x15c>  // b.none
    4964:	7100047f 	cmp	w3, #0x1
    4968:	54000201 	b.ne	49a8 <fwp_drop0+0x148>  // b.any
    496c:	29430ce4 	ldp	w4, w3, [x7, #24]
    4970:	92403c42 	and	x2, x2, #0xffff
    4974:	9b047c42 	mul	x2, x2, x4
    4978:	d360fc42 	lsr	x2, x2, #32
    497c:	eb03005f 	cmp	x2, x3
    4980:	54000142 	b.cs	49a8 <fwp_drop0+0x148>  // b.hs, b.nlast
    4984:	8b0200c6 	add	x6, x6, x2
    4988:	394000c2 	ldrb	w2, [x6]
    498c:	7100045f 	cmp	w2, #0x1
    4990:	540000c1 	b.ne	49a8 <fwp_drop0+0x148>  // b.any
    4994:	97fff98f 	bl	2fd0 <fwp_mem_free>
    4998:	911342a0 	add	x0, x21, #0x4d0
    499c:	f949ec05 	ldr	x5, [x0, #5080]
    49a0:	f949d801 	ldr	x1, [x0, #5040]
    49a4:	d370bca5 	lsl	x5, x5, #16
    49a8:	cb010261 	sub	x1, x19, x1
    49ac:	eb05003f 	cmp	x1, x5
    49b0:	54fffa42 	b.cs	48f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    49b4:	aa1303e0 	mov	x0, x19
    49b8:	17ffffb5 	b	488c <fwp_drop0+0x2c>
    49bc:	72003c5f 	tst	w2, #0xffff
    49c0:	54ffff41 	b.ne	49a8 <fwp_drop0+0x148>  // b.any
    49c4:	17fffff1 	b	4988 <fwp_drop0+0x128>
    49c8:	ca534661 	eor	x1, x19, x19, lsr #17
    49cc:	911342a0 	add	x0, x21, #0x4d0
    49d0:	ca412421 	eor	x1, x1, x1, lsr #9
    49d4:	8b210c01 	add	x1, x0, w1, uxtb #3
    49d8:	f94a2420 	ldr	x0, [x1, #5192]
    49dc:	b5000080 	cbnz	x0, 49ec <fwp_drop0+0x18c>
    49e0:	14000010 	b	4a20 <fwp_drop0+0x1c0>
    49e4:	f9400800 	ldr	x0, [x0, #16]
    49e8:	b40001c0 	cbz	x0, 4a20 <fwp_drop0+0x1c0>
    49ec:	f9400001 	ldr	x1, [x0]
    49f0:	eb13003f 	cmp	x1, x19
    49f4:	54ffff81 	b.ne	49e4 <fwp_drop0+0x184>  // b.any
    49f8:	f9400401 	ldr	x1, [x0, #8]
    49fc:	d1000421 	sub	x1, x1, #0x1
    4a00:	f9000401 	str	x1, [x0, #8]
    4a04:	f103f83f 	cmp	x1, #0xfe
    4a08:	54fff781 	b.ne	48f8 <fwp_drop0+0x98>  // b.any
    4a0c:	aa1303e0 	mov	x0, x19
    4a10:	97fff8d0 	bl	2d50 <fwp_rc_forget_slot>
    4a14:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4a18:	39000260 	strb	w0, [x19]
    4a1c:	17ffffb7 	b	48f8 <fwp_drop0+0x98>
    4a20:	f0000000 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    4a24:	9102c000 	add	x0, x0, #0xb0
    4a28:	97fff5be 	bl	2120 <fwp_trap>
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_drop1>:
    4a30:	17ffff8c 	b	4860 <fwp_drop0>

0000000000004a34 <fwp_loop_fields68.constprop.0>:
    4a34:	d65f03c0 	ret
    4a38:	d503201f 	nop
    4a3c:	d503201f 	nop

0000000000004a40 <fwp_drop6>:
    4a40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a44:	910003fd 	mov	x29, sp
    4a48:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a4c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xd10>
    4a50:	911342d5 	add	x21, x22, #0x4d0
    4a54:	a90153f3 	stp	x19, x20, [sp, #16]
    4a58:	aa0003f3 	mov	x19, x0
    4a5c:	f949daa1 	ldr	x1, [x21, #5040]
    4a60:	f949eea0 	ldr	x0, [x21, #5080]
    4a64:	cb010261 	sub	x1, x19, x1
    4a68:	eb00403f 	cmp	x1, x0, lsl #16
    4a6c:	54000382 	b.cs	4adc <fwp_drop6+0x9c>  // b.hs, b.nlast
    4a70:	d350fc22 	lsr	x2, x1, #16
    4a74:	f949fea3 	ldr	x3, [x21, #5112]
    4a78:	8b020842 	add	x2, x2, x2, lsl #2
    4a7c:	d37df042 	lsl	x2, x2, #3
    4a80:	8b020060 	add	x0, x3, x2
    4a84:	f9401014 	ldr	x20, [x0, #32]
    4a88:	b40002b4 	cbz	x20, 4adc <fwp_drop6+0x9c>
    4a8c:	38626862 	ldrb	w2, [x3, x2]
    4a90:	7100085f 	cmp	w2, #0x2
    4a94:	540002c0 	b.eq	4aec <fwp_drop6+0xac>  // b.none
    4a98:	7100045f 	cmp	w2, #0x1
    4a9c:	54000201 	b.ne	4adc <fwp_drop6+0x9c>  // b.any
    4aa0:	29430002 	ldp	w2, w0, [x0, #24]
    4aa4:	92403c21 	and	x1, x1, #0xffff
    4aa8:	9b027c21 	mul	x1, x1, x2
    4aac:	d360fc21 	lsr	x1, x1, #32
    4ab0:	eb00003f 	cmp	x1, x0
    4ab4:	54000142 	b.cs	4adc <fwp_drop6+0x9c>  // b.hs, b.nlast
    4ab8:	8b010294 	add	x20, x20, x1
    4abc:	39400280 	ldrb	w0, [x20]
    4ac0:	340000e0 	cbz	w0, 4adc <fwp_drop6+0x9c>
    4ac4:	7100041f 	cmp	w0, #0x1
    4ac8:	540001e0 	b.eq	4b04 <fwp_drop6+0xc4>  // b.none
    4acc:	7103fc1f 	cmp	w0, #0xff
    4ad0:	54000760 	b.eq	4bbc <fwp_drop6+0x17c>  // b.none
    4ad4:	51000400 	sub	w0, w0, #0x1
    4ad8:	39000280 	strb	w0, [x20]
    4adc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ae4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ae8:	d65f03c0 	ret
    4aec:	72003c3f 	tst	w1, #0xffff
    4af0:	54fffe60 	b.eq	4abc <fwp_drop6+0x7c>  // b.none
    4af4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4af8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4afc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b00:	d65f03c0 	ret
    4b04:	f9400660 	ldr	x0, [x19, #8]
    4b08:	97fffdb6 	bl	41e0 <fwp_drop4>
    4b0c:	911342c4 	add	x4, x22, #0x4d0
    4b10:	f9400a74 	ldr	x20, [x19, #16]
    4b14:	f949ec83 	ldr	x3, [x4, #5080]
    4b18:	f949d881 	ldr	x1, [x4, #5040]
    4b1c:	d370bc63 	lsl	x3, x3, #16
    4b20:	cb010262 	sub	x2, x19, x1
    4b24:	eb03005f 	cmp	x2, x3
    4b28:	540003a2 	b.cs	4b9c <fwp_drop6+0x15c>  // b.hs, b.nlast
    4b2c:	d350fc40 	lsr	x0, x2, #16
    4b30:	f949fc86 	ldr	x6, [x4, #5112]
    4b34:	8b000800 	add	x0, x0, x0, lsl #2
    4b38:	d37df000 	lsl	x0, x0, #3
    4b3c:	8b0000c5 	add	x5, x6, x0
    4b40:	f94010a4 	ldr	x4, [x5, #32]
    4b44:	b40002c4 	cbz	x4, 4b9c <fwp_drop6+0x15c>
    4b48:	386068c0 	ldrb	w0, [x6, x0]
    4b4c:	7100081f 	cmp	w0, #0x2
    4b50:	54000300 	b.eq	4bb0 <fwp_drop6+0x170>  // b.none
    4b54:	7100041f 	cmp	w0, #0x1
    4b58:	54000221 	b.ne	4b9c <fwp_drop6+0x15c>  // b.any
    4b5c:	92403c40 	and	x0, x2, #0xffff
    4b60:	294308a6 	ldp	w6, w2, [x5, #24]
    4b64:	9b067c00 	mul	x0, x0, x6
    4b68:	d360fc00 	lsr	x0, x0, #32
    4b6c:	eb02001f 	cmp	x0, x2
    4b70:	54000162 	b.cs	4b9c <fwp_drop6+0x15c>  // b.hs, b.nlast
    4b74:	8b000084 	add	x4, x4, x0
    4b78:	39400080 	ldrb	w0, [x4]
    4b7c:	7100041f 	cmp	w0, #0x1
    4b80:	540000e1 	b.ne	4b9c <fwp_drop6+0x15c>  // b.any
    4b84:	aa1303e0 	mov	x0, x19
    4b88:	97fff912 	bl	2fd0 <fwp_mem_free>
    4b8c:	911342c0 	add	x0, x22, #0x4d0
    4b90:	f949ec03 	ldr	x3, [x0, #5080]
    4b94:	f949d801 	ldr	x1, [x0, #5040]
    4b98:	d370bc63 	lsl	x3, x3, #16
    4b9c:	cb010281 	sub	x1, x20, x1
    4ba0:	eb01007f 	cmp	x3, x1
    4ba4:	54fff9c9 	b.ls	4adc <fwp_drop6+0x9c>  // b.plast
    4ba8:	aa1403f3 	mov	x19, x20
    4bac:	17ffffb1 	b	4a70 <fwp_drop6+0x30>
    4bb0:	72003c5f 	tst	w2, #0xffff
    4bb4:	54ffff41 	b.ne	4b9c <fwp_drop6+0x15c>  // b.any
    4bb8:	17fffff0 	b	4b78 <fwp_drop6+0x138>
    4bbc:	ca544681 	eor	x1, x20, x20, lsr #17
    4bc0:	911342c0 	add	x0, x22, #0x4d0
    4bc4:	ca412421 	eor	x1, x1, x1, lsr #9
    4bc8:	8b210c01 	add	x1, x0, w1, uxtb #3
    4bcc:	f94a2420 	ldr	x0, [x1, #5192]
    4bd0:	b5000080 	cbnz	x0, 4be0 <fwp_drop6+0x1a0>
    4bd4:	14000010 	b	4c14 <fwp_drop6+0x1d4>
    4bd8:	f9400800 	ldr	x0, [x0, #16]
    4bdc:	b40001c0 	cbz	x0, 4c14 <fwp_drop6+0x1d4>
    4be0:	f9400001 	ldr	x1, [x0]
    4be4:	eb14003f 	cmp	x1, x20
    4be8:	54ffff81 	b.ne	4bd8 <fwp_drop6+0x198>  // b.any
    4bec:	f9400401 	ldr	x1, [x0, #8]
    4bf0:	d1000421 	sub	x1, x1, #0x1
    4bf4:	f9000401 	str	x1, [x0, #8]
    4bf8:	f103f83f 	cmp	x1, #0xfe
    4bfc:	54fff701 	b.ne	4adc <fwp_drop6+0x9c>  // b.any
    4c00:	aa1403e0 	mov	x0, x20
    4c04:	97fff853 	bl	2d50 <fwp_rc_forget_slot>
    4c08:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4c0c:	39000280 	strb	w0, [x20]
    4c10:	17ffffb3 	b	4adc <fwp_drop6+0x9c>
    4c14:	f0000000 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    4c18:	9102c000 	add	x0, x0, #0xb0
    4c1c:	97fff541 	bl	2120 <fwp_trap>

0000000000004c20 <fwp_write>:
    4c20:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    4c24:	910003fd 	mov	x29, sp
    4c28:	f00000c4 	adrp	x4, 1f000 <__FRAME_END__+0x16b00>
    4c2c:	f947f484 	ldr	x4, [x4, #4072]
    4c30:	a90153f3 	stp	x19, x20, [sp, #16]
    4c34:	d10943ff 	sub	sp, sp, #0x250
    4c38:	b9400045 	ldr	w5, [x2]
    4c3c:	aa0003f4 	mov	x20, x0
    4c40:	f9400080 	ldr	x0, [x4]
    4c44:	f90127e0 	str	x0, [sp, #584]
    4c48:	d2800000 	mov	x0, #0x0                   	// #0
    4c4c:	710064bf 	cmp	w5, #0x19
    4c50:	54000408 	b.hi	4cd0 <fwp_write+0xb0>  // b.pmore
    4c54:	f0000000 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    4c58:	aa0103f3 	mov	x19, x1
    4c5c:	910e0000 	add	x0, x0, #0x380
    4c60:	f9013bf5 	str	x21, [sp, #624]
    4c64:	f9013ff6 	str	x22, [sp, #632]
    4c68:	f90153fb 	str	x27, [sp, #672]
    4c6c:	f90157fc 	str	x28, [sp, #680]
    4c70:	aa0203fc 	mov	x28, x2
    4c74:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    4c78:	10000061 	adr	x1, 4c84 <fwp_write+0x64>
    4c7c:	8b20a820 	add	x0, x1, w0, sxth #2
    4c80:	d61f0000 	br	x0
    4c84:	910123e0 	add	x0, sp, #0x48
    4c88:	aa1303e5 	mov	x5, x19
    4c8c:	f0000004 	adrp	x4, 7000 <_IO_stdin_used+0x140>
    4c90:	aa0003f3 	mov	x19, x0
    4c94:	91060084 	add	x4, x4, #0x180
    4c98:	d2804003 	mov	x3, #0x200                 	// #512
    4c9c:	aa0303e1 	mov	x1, x3
    4ca0:	52800042 	mov	w2, #0x2                   	// #2
    4ca4:	97fff1ef 	bl	1460 <__snprintf_chk@plt>
    4ca8:	aa1303e0 	mov	x0, x19
    4cac:	97fff1b5 	bl	1380 <strlen@plt>
    4cb0:	aa1303e1 	mov	x1, x19
    4cb4:	aa0003e2 	mov	x2, x0
    4cb8:	aa1403e0 	mov	x0, x20
    4cbc:	97fff4bd 	bl	1fb0 <buf_put>
    4cc0:	f9413bf5 	ldr	x21, [sp, #624]
    4cc4:	f9413ff6 	ldr	x22, [sp, #632]
    4cc8:	f94153fb 	ldr	x27, [sp, #672]
    4ccc:	f94157fc 	ldr	x28, [sp, #680]
    4cd0:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    4cd4:	f947f400 	ldr	x0, [x0, #4072]
    4cd8:	f94127e2 	ldr	x2, [sp, #584]
    4cdc:	f9400001 	ldr	x1, [x0]
    4ce0:	eb010042 	subs	x2, x2, x1
    4ce4:	d2800001 	mov	x1, #0x0                   	// #0
    4ce8:	540077c1 	b.ne	5be0 <fwp_write+0xfc0>  // b.any
    4cec:	910943ff 	add	sp, sp, #0x250
    4cf0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cf4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    4cf8:	d65f03c0 	ret
    4cfc:	910123e0 	add	x0, sp, #0x48
    4d00:	aa1303e5 	mov	x5, x19
    4d04:	f0000004 	adrp	x4, 7000 <_IO_stdin_used+0x140>
    4d08:	aa0003f3 	mov	x19, x0
    4d0c:	9105e084 	add	x4, x4, #0x178
    4d10:	d2804003 	mov	x3, #0x200                 	// #512
    4d14:	17ffffe2 	b	4c9c <fwp_write+0x7c>
    4d18:	71004cbf 	cmp	w5, #0x13
    4d1c:	f0000000 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    4d20:	f0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    4d24:	9105a000 	add	x0, x0, #0x168
    4d28:	9105c021 	add	x1, x1, #0x170
    4d2c:	d2800082 	mov	x2, #0x4                   	// #4
    4d30:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    4d34:	aa1403e0 	mov	x0, x20
    4d38:	f90143f7 	str	x23, [sp, #640]
    4d3c:	d2800016 	mov	x22, #0x0                   	// #0
    4d40:	f90147f8 	str	x24, [sp, #648]
    4d44:	97fff49b 	bl	1fb0 <buf_put>
    4d48:	f9400260 	ldr	x0, [x19]
    4d4c:	f0000017 	adrp	x23, 7000 <_IO_stdin_used+0x140>
    4d50:	d2800015 	mov	x21, #0x0                   	// #0
    4d54:	9107c2f7 	add	x23, x23, #0x1f0
    4d58:	b40047a0 	cbz	x0, 564c <fwp_write+0xa2c>
    4d5c:	b9400380 	ldr	w0, [x28]
    4d60:	52800003 	mov	w3, #0x0                   	// #0
    4d64:	f9401f82 	ldr	x2, [x28, #56]
    4d68:	71004c1f 	cmp	w0, #0x13
    4d6c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    4d70:	aa1403e0 	mov	x0, x20
    4d74:	8b010e61 	add	x1, x19, x1, lsl #3
    4d78:	f9400421 	ldr	x1, [x1, #8]
    4d7c:	97ffffa9 	bl	4c20 <fwp_write>
    4d80:	b9400380 	ldr	w0, [x28]
    4d84:	7100481f 	cmp	w0, #0x12
    4d88:	54004b40 	b.eq	56f0 <fwp_write+0xad0>  // b.none
    4d8c:	f9400260 	ldr	x0, [x19]
    4d90:	910006b5 	add	x21, x21, #0x1
    4d94:	91000ad6 	add	x22, x22, #0x2
    4d98:	eb15001f 	cmp	x0, x21
    4d9c:	54004589 	b.ls	564c <fwp_write+0xa2c>  // b.plast
    4da0:	aa1703e1 	mov	x1, x23
    4da4:	aa1403e0 	mov	x0, x20
    4da8:	d2800042 	mov	x2, #0x2                   	// #2
    4dac:	97fff481 	bl	1fb0 <buf_put>
    4db0:	17ffffeb 	b	4d5c <fwp_write+0x13c>
    4db4:	f0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    4db8:	9106a021 	add	x1, x1, #0x1a8
    4dbc:	d28000c2 	mov	x2, #0x6                   	// #6
    4dc0:	aa1403e0 	mov	x0, x20
    4dc4:	91004273 	add	x19, x19, #0x10
    4dc8:	97fff47a 	bl	1fb0 <buf_put>
    4dcc:	aa1303e0 	mov	x0, x19
    4dd0:	97fff16c 	bl	1380 <strlen@plt>
    4dd4:	aa1303e1 	mov	x1, x19
    4dd8:	aa0003e2 	mov	x2, x0
    4ddc:	aa1403e0 	mov	x0, x20
    4de0:	97fff474 	bl	1fb0 <buf_put>
    4de4:	528007c3 	mov	w3, #0x3e                  	// #62
    4de8:	aa1403e0 	mov	x0, x20
    4dec:	91001fe1 	add	x1, sp, #0x7
    4df0:	d2800022 	mov	x2, #0x1                   	// #1
    4df4:	39001fe3 	strb	w3, [sp, #7]
    4df8:	17ffffb1 	b	4cbc <fwp_write+0x9c>
    4dfc:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    4e00:	f947f400 	ldr	x0, [x0, #4072]
    4e04:	f94127e2 	ldr	x2, [sp, #584]
    4e08:	f9400001 	ldr	x1, [x0]
    4e0c:	eb010042 	subs	x2, x2, x1
    4e10:	d2800001 	mov	x1, #0x0                   	// #0
    4e14:	540034e1 	b.ne	54b0 <fwp_write+0x890>  // b.any
    4e18:	f9413bf5 	ldr	x21, [sp, #624]
    4e1c:	f0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    4e20:	f9413ff6 	ldr	x22, [sp, #632]
    4e24:	aa1403e0 	mov	x0, x20
    4e28:	91062021 	add	x1, x1, #0x188
    4e2c:	d2800142 	mov	x2, #0xa                   	// #10
    4e30:	f94153fb 	ldr	x27, [sp, #672]
    4e34:	f94157fc 	ldr	x28, [sp, #680]
    4e38:	910943ff 	add	sp, sp, #0x250
    4e3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e40:	a8c77bfd 	ldp	x29, x30, [sp], #112
    4e44:	17fff45b 	b	1fb0 <buf_put>
    4e48:	f9400456 	ldr	x22, [x2, #8]
    4e4c:	f90143f7 	str	x23, [sp, #640]
    4e50:	f90147f8 	str	x24, [sp, #648]
    4e54:	b4005b16 	cbz	x22, 59b4 <fwp_write+0xd94>
    4e58:	aa1603e0 	mov	x0, x22
    4e5c:	f0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    4e60:	91082021 	add	x1, x1, #0x208
    4e64:	97fff1c3 	bl	1570 <strcmp@plt>
    4e68:	2a0003f5 	mov	w21, w0
    4e6c:	34005fe0 	cbz	w0, 5a68 <fwp_write+0xe48>
    4e70:	aa1603e0 	mov	x0, x22
    4e74:	97fff143 	bl	1380 <strlen@plt>
    4e78:	aa1603e1 	mov	x1, x22
    4e7c:	aa0003e2 	mov	x2, x0
    4e80:	aa1403e0 	mov	x0, x20
    4e84:	97fff44b 	bl	1fb0 <buf_put>
    4e88:	52800403 	mov	w3, #0x20                  	// #32
    4e8c:	91001ff5 	add	x21, sp, #0x7
    4e90:	aa1503e1 	mov	x1, x21
    4e94:	aa1403e0 	mov	x0, x20
    4e98:	d2800022 	mov	x2, #0x1                   	// #1
    4e9c:	39001fe3 	strb	w3, [sp, #7]
    4ea0:	97fff444 	bl	1fb0 <buf_put>
    4ea4:	52800f63 	mov	w3, #0x7b                  	// #123
    4ea8:	aa1403e0 	mov	x0, x20
    4eac:	aa1503e1 	mov	x1, x21
    4eb0:	d2800022 	mov	x2, #0x1                   	// #1
    4eb4:	39001fe3 	strb	w3, [sp, #7]
    4eb8:	97fff43e 	bl	1fb0 <buf_put>
    4ebc:	b9401380 	ldr	w0, [x28, #16]
    4ec0:	52800018 	mov	w24, #0x0                   	// #0
    4ec4:	7100001f 	cmp	w0, #0x0
    4ec8:	54003aad 	b.le	561c <fwp_write+0x9fc>
    4ecc:	f9014bf9 	str	x25, [sp, #656]
    4ed0:	f0000019 	adrp	x25, 7000 <_IO_stdin_used+0x140>
    4ed4:	9108c339 	add	x25, x25, #0x230
    4ed8:	f9014ffa 	str	x26, [sp, #664]
    4edc:	f000001a 	adrp	x26, 7000 <_IO_stdin_used+0x140>
    4ee0:	9107c35a 	add	x26, x26, #0x1f0
    4ee4:	91002276 	add	x22, x19, #0x8
    4ee8:	d2800013 	mov	x19, #0x0                   	// #0
    4eec:	b5003e93 	cbnz	x19, 56bc <fwp_write+0xa9c>
    4ef0:	d37df277 	lsl	x23, x19, #3
    4ef4:	34003cb8 	cbz	w24, 5688 <fwp_write+0xa68>
    4ef8:	f9401382 	ldr	x2, [x28, #32]
    4efc:	aa1403e0 	mov	x0, x20
    4f00:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    4f04:	52800003 	mov	w3, #0x0                   	// #0
    4f08:	f8776842 	ldr	x2, [x2, x23]
    4f0c:	91000673 	add	x19, x19, #0x1
    4f10:	97ffff44 	bl	4c20 <fwp_write>
    4f14:	b9401380 	ldr	w0, [x28, #16]
    4f18:	6b13001f 	cmp	w0, w19
    4f1c:	54fffe8c 	b.gt	4eec <fwp_write+0x2cc>
    4f20:	f9414bf9 	ldr	x25, [sp, #656]
    4f24:	f9414ffa 	ldr	x26, [sp, #664]
    4f28:	340037b8 	cbz	w24, 561c <fwp_write+0x9fc>
    4f2c:	52800523 	mov	w3, #0x29                  	// #41
    4f30:	aa1503e1 	mov	x1, x21
    4f34:	aa1403e0 	mov	x0, x20
    4f38:	d2800022 	mov	x2, #0x1                   	// #1
    4f3c:	39001fe3 	strb	w3, [sp, #7]
    4f40:	97fff41c 	bl	1fb0 <buf_put>
    4f44:	f9413bf5 	ldr	x21, [sp, #624]
    4f48:	f9413ff6 	ldr	x22, [sp, #632]
    4f4c:	f94143f7 	ldr	x23, [sp, #640]
    4f50:	f94147f8 	ldr	x24, [sp, #648]
    4f54:	f94153fb 	ldr	x27, [sp, #672]
    4f58:	f94157fc 	ldr	x28, [sp, #680]
    4f5c:	17ffff5d 	b	4cd0 <fwp_write+0xb0>
    4f60:	b9404855 	ldr	w21, [x2, #72]
    4f64:	aa1403e0 	mov	x0, x20
    4f68:	93407eb6 	sxtw	x22, w21
    4f6c:	91000ac1 	add	x1, x22, #0x2
    4f70:	97fff3dc 	bl	1ee0 <buf_grow>
    4f74:	a9400281 	ldp	x1, x0, [x20]
    4f78:	528e8603 	mov	w3, #0x7430                	// #29744
    4f7c:	78206823 	strh	w3, [x1, x0]
    4f80:	8b000022 	add	x2, x1, x0
    4f84:	710002bf 	cmp	w21, #0x0
    4f88:	540036cd 	b.le	5660 <fwp_write+0xa40>
    4f8c:	110006a3 	add	w3, w21, #0x1
    4f90:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    4f94:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    4f98:	91000449 	add	x9, x2, #0x1
    4f9c:	8b23c043 	add	x3, x2, w3, sxtw
    4fa0:	f28aaac6 	movk	x6, #0x5556
    4fa4:	f2955568 	movk	x8, #0xaaab
    4fa8:	1400000d 	b	4fdc <fwp_write+0x3bc>
    4fac:	d2800021 	mov	x1, #0x1                   	// #1
    4fb0:	528005a5 	mov	w5, #0x2d                  	// #45
    4fb4:	f100001f 	cmp	x0, #0x0
    4fb8:	9b467e60 	smulh	x0, x19, x6
    4fbc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    4fc0:	381ff465 	strb	w5, [x3], #-1
    4fc4:	cb040000 	sub	x0, x0, x4
    4fc8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    4fcc:	cb020000 	sub	x0, x0, x2
    4fd0:	8b010013 	add	x19, x0, x1
    4fd4:	eb03013f 	cmp	x9, x3
    4fd8:	54003440 	b.eq	5660 <fwp_write+0xa40>  // b.none
    4fdc:	9b467e60 	smulh	x0, x19, x6
    4fe0:	937ffe64 	asr	x4, x19, #63
    4fe4:	52800605 	mov	w5, #0x30                  	// #48
    4fe8:	cb040000 	sub	x0, x0, x4
    4fec:	8b000400 	add	x0, x0, x0, lsl #1
    4ff0:	cb000260 	sub	x0, x19, x0
    4ff4:	91000c01 	add	x1, x0, #0x3
    4ff8:	9bc87c22 	umulh	x2, x1, x8
    4ffc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    5000:	8b4204e2 	add	x2, x7, x2, lsr #1
    5004:	eb020021 	subs	x1, x1, x2
    5008:	54fffd60 	b.eq	4fb4 <fwp_write+0x394>  // b.none
    500c:	f100043f 	cmp	x1, #0x1
    5010:	54fffce1 	b.ne	4fac <fwp_write+0x38c>  // b.any
    5014:	d2800001 	mov	x1, #0x0                   	// #0
    5018:	52800565 	mov	w5, #0x2b                  	// #43
    501c:	17ffffe6 	b	4fb4 <fwp_write+0x394>
    5020:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    5024:	f947f400 	ldr	x0, [x0, #4072]
    5028:	f94127e2 	ldr	x2, [sp, #584]
    502c:	f9400001 	ldr	x1, [x0]
    5030:	eb010042 	subs	x2, x2, x1
    5034:	d2800001 	mov	x1, #0x0                   	// #0
    5038:	540023c1 	b.ne	54b0 <fwp_write+0x890>  // b.any
    503c:	f9413bf5 	ldr	x21, [sp, #624]
    5040:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    5044:	f9413ff6 	ldr	x22, [sp, #632]
    5048:	aa1403e0 	mov	x0, x20
    504c:	91066021 	add	x1, x1, #0x198
    5050:	d2800102 	mov	x2, #0x8                   	// #8
    5054:	17ffff77 	b	4e30 <fwp_write+0x210>
    5058:	aa1403e0 	mov	x0, x20
    505c:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    5060:	d28000c2 	mov	x2, #0x6                   	// #6
    5064:	9107e021 	add	x1, x1, #0x1f8
    5068:	97fff3d2 	bl	1fb0 <buf_put>
    506c:	d2800015 	mov	x21, #0x0                   	// #0
    5070:	f9400263 	ldr	x3, [x19]
    5074:	f240f87f 	tst	x3, #0x7fffffffffffffff
    5078:	54002c60 	b.eq	5604 <fwp_write+0x9e4>  // b.none
    507c:	f9401f82 	ldr	x2, [x28, #56]
    5080:	f90143f7 	str	x23, [sp, #640]
    5084:	f90147f8 	str	x24, [sp, #648]
    5088:	d2800857 	mov	x23, #0x42                  	// #66
    508c:	f9014bf9 	str	x25, [sp, #656]
    5090:	d0000016 	adrp	x22, 7000 <_IO_stdin_used+0x140>
    5094:	f9014ffa 	str	x26, [sp, #664]
    5098:	9107c2d6 	add	x22, x22, #0x1f0
    509c:	d2800038 	mov	x24, #0x1                   	// #1
    50a0:	f2a18017 	movk	x23, #0xc00, lsl #16
    50a4:	d2809099 	mov	x25, #0x484                 	// #1156
    50a8:	b40004a2 	cbz	x2, 513c <fwp_write+0x51c>
    50ac:	b9400040 	ldr	w0, [x2]
    50b0:	7100701f 	cmp	w0, #0x1c
    50b4:	540042c0 	b.eq	590c <fwp_write+0xcec>  // b.none
    50b8:	71006c1f 	cmp	w0, #0x1b
    50bc:	54000408 	b.hi	513c <fwp_write+0x51c>  // b.pmore
    50c0:	9ac02301 	lsl	x1, x24, x0
    50c4:	ea17003f 	tst	x1, x23
    50c8:	540036a1 	b.ne	579c <fwp_write+0xb7c>  // b.any
    50cc:	ea19003f 	tst	x1, x25
    50d0:	54003521 	b.ne	5774 <fwp_write+0xb54>  // b.any
    50d4:	d2800424 	mov	x4, #0x21                  	// #33
    50d8:	ea04003f 	tst	x1, x4
    50dc:	54000300 	b.eq	513c <fwp_write+0x51c>  // b.none
    50e0:	b7f849c3 	tbnz	x3, #63, 5a18 <fwp_write+0xdf8>
    50e4:	91002261 	add	x1, x19, #0x8
    50e8:	8b150021 	add	x1, x1, x21
    50ec:	39400021 	ldrb	w1, [x1]
    50f0:	7100001f 	cmp	w0, #0x0
    50f4:	93401c23 	sxtb	x3, w1
    50f8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    50fc:	d503201f 	nop
    5100:	aa1403e0 	mov	x0, x20
    5104:	52800003 	mov	w3, #0x0                   	// #0
    5108:	97fffec6 	bl	4c20 <fwp_write>
    510c:	910006b5 	add	x21, x21, #0x1
    5110:	f9400260 	ldr	x0, [x19]
    5114:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    5118:	eb0002bf 	cmp	x21, x0
    511c:	540026c2 	b.cs	55f4 <fwp_write+0x9d4>  // b.hs, b.nlast
    5120:	d2800042 	mov	x2, #0x2                   	// #2
    5124:	aa1603e1 	mov	x1, x22
    5128:	aa1403e0 	mov	x0, x20
    512c:	97fff3a1 	bl	1fb0 <buf_put>
    5130:	f9401f82 	ldr	x2, [x28, #56]
    5134:	f9400263 	ldr	x3, [x19]
    5138:	b5fffba2 	cbnz	x2, 50ac <fwp_write+0x48c>
    513c:	d37df2a0 	lsl	x0, x21, #3
    5140:	b7f83f03 	tbnz	x3, #63, 5920 <fwp_write+0xd00>
    5144:	91002261 	add	x1, x19, #0x8
    5148:	8b000020 	add	x0, x1, x0
    514c:	f9400001 	ldr	x1, [x0]
    5150:	17ffffec 	b	5100 <fwp_write+0x4e0>
    5154:	a9400e62 	ldp	x2, x3, [x19]
    5158:	b7f83ca3 	tbnz	x3, #63, 58ec <fwp_write+0xccc>
    515c:	910123f5 	add	x21, sp, #0x48
    5160:	aa1503e0 	mov	x0, x21
    5164:	97fff22f 	bl	1a20 <fwp_fmt_u128>
    5168:	aa1503e0 	mov	x0, x21
    516c:	97fff085 	bl	1380 <strlen@plt>
    5170:	aa1503e1 	mov	x1, x21
    5174:	aa0003e2 	mov	x2, x0
    5178:	17fffed0 	b	4cb8 <fwp_write+0x98>
    517c:	fd015be8 	str	d8, [sp, #688]
    5180:	1e270268 	fmov	s8, w19
    5184:	fd015fe9 	str	d9, [sp, #696]
    5188:	1e282100 	fcmp	s8, s8
    518c:	54004d26 	b.vs	5b30 <fwp_write+0xf10>
    5190:	1e20c101 	fabs	s1, s8
    5194:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    5198:	1e270000 	fmov	s0, w0
    519c:	1e202020 	fcmp	s1, s0
    51a0:	54002c0d 	b.le	5720 <fwp_write+0xb00>
    51a4:	1e202118 	fcmpe	s8, #0.0
    51a8:	b0000002 	adrp	x2, 6000 <fwp_main_thread+0x3f0>
    51ac:	913b8042 	add	x2, x2, #0xee0
    51b0:	910123f5 	add	x21, sp, #0x48
    51b4:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    51b8:	91052021 	add	x1, x1, #0x148
    51bc:	aa1503e0 	mov	x0, x21
    51c0:	9a81c041 	csel	x1, x2, x1, gt
    51c4:	97fff11b 	bl	1630 <strcpy@plt>
    51c8:	aa1503e0 	mov	x0, x21
    51cc:	97fff06d 	bl	1380 <strlen@plt>
    51d0:	aa1503e1 	mov	x1, x21
    51d4:	aa0003e2 	mov	x2, x0
    51d8:	aa1403e0 	mov	x0, x20
    51dc:	97fff375 	bl	1fb0 <buf_put>
    51e0:	f9413bf5 	ldr	x21, [sp, #624]
    51e4:	f9413ff6 	ldr	x22, [sp, #632]
    51e8:	f94153fb 	ldr	x27, [sp, #672]
    51ec:	f94157fc 	ldr	x28, [sp, #680]
    51f0:	fd415be8 	ldr	d8, [sp, #688]
    51f4:	fd415fe9 	ldr	d9, [sp, #696]
    51f8:	17fffeb6 	b	4cd0 <fwp_write+0xb0>
    51fc:	f9400276 	ldr	x22, [x19]
    5200:	34002e03 	cbz	w3, 57c0 <fwp_write+0xba0>
    5204:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    5208:	f947f400 	ldr	x0, [x0, #4072]
    520c:	f94127e2 	ldr	x2, [sp, #584]
    5210:	f9400001 	ldr	x1, [x0]
    5214:	eb010042 	subs	x2, x2, x1
    5218:	d2800001 	mov	x1, #0x0                   	// #0
    521c:	540014a1 	b.ne	54b0 <fwp_write+0x890>  // b.any
    5220:	aa1603e2 	mov	x2, x22
    5224:	91002261 	add	x1, x19, #0x8
    5228:	f9413bf5 	ldr	x21, [sp, #624]
    522c:	aa1403e0 	mov	x0, x20
    5230:	f9413ff6 	ldr	x22, [sp, #632]
    5234:	17fffeff 	b	4e30 <fwp_write+0x210>
    5238:	fd015be8 	str	d8, [sp, #688]
    523c:	9e670268 	fmov	d8, x19
    5240:	fd015fe9 	str	d9, [sp, #696]
    5244:	1e682100 	fcmp	d8, d8
    5248:	54004746 	b.vs	5b30 <fwp_write+0xf10>
    524c:	1e60c101 	fabs	d1, d8
    5250:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    5254:	9e670000 	fmov	d0, x0
    5258:	910123f5 	add	x21, sp, #0x48
    525c:	52800033 	mov	w19, #0x1                   	// #1
    5260:	1e602020 	fcmp	d1, d0
    5264:	540001ad 	b.le	5298 <fwp_write+0x678>
    5268:	1e602118 	fcmpe	d8, #0.0
    526c:	b0000002 	adrp	x2, 6000 <fwp_main_thread+0x3f0>
    5270:	913b8042 	add	x2, x2, #0xee0
    5274:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    5278:	91052021 	add	x1, x1, #0x148
    527c:	aa1503e0 	mov	x0, x21
    5280:	9a81c041 	csel	x1, x2, x1, gt
    5284:	97fff0eb 	bl	1630 <strcpy@plt>
    5288:	17ffffd0 	b	51c8 <fwp_write+0x5a8>
    528c:	11000673 	add	w19, w19, #0x1
    5290:	71004a7f 	cmp	w19, #0x12
    5294:	54003860 	b.eq	59a0 <fwp_write+0xd80>  // b.none
    5298:	1e604100 	fmov	d0, d8
    529c:	2a1303e1 	mov	w1, w19
    52a0:	aa1503e0 	mov	x0, x21
    52a4:	97fff3d8 	bl	2204 <fwp_format_g.constprop.0>
    52a8:	aa1503e0 	mov	x0, x21
    52ac:	d2800001 	mov	x1, #0x0                   	// #0
    52b0:	97fff048 	bl	13d0 <strtod@plt>
    52b4:	1e602100 	fcmp	d8, d0
    52b8:	54fffea1 	b.ne	528c <fwp_write+0x66c>  // b.any
    52bc:	aa1503e0 	mov	x0, x21
    52c0:	97fff375 	bl	2094 <fwp_finish_float>
    52c4:	17ffffc1 	b	51c8 <fwp_write+0x5a8>
    52c8:	a9400e62 	ldp	x2, x3, [x19]
    52cc:	910123f3 	add	x19, sp, #0x48
    52d0:	aa1303e0 	mov	x0, x19
    52d4:	97fff1d3 	bl	1a20 <fwp_fmt_u128>
    52d8:	17fffe74 	b	4ca8 <fwp_write+0x88>
    52dc:	f90143f7 	str	x23, [sp, #640]
    52e0:	f90147f8 	str	x24, [sp, #648]
    52e4:	2a1303f8 	mov	w24, w19
    52e8:	f9014bf9 	str	x25, [sp, #656]
    52ec:	f9014ffa 	str	x26, [sp, #664]
    52f0:	f13ffe7f 	cmp	x19, #0xfff
    52f4:	54000049 	b.ls	52fc <fwp_write+0x6dc>  // b.plast
    52f8:	b9400278 	ldr	w24, [x19]
    52fc:	f9400f80 	ldr	x0, [x28, #24]
    5300:	2a1803f5 	mov	w21, w24
    5304:	d37d7f18 	ubfiz	x24, x24, #3, #32
    5308:	d37ef6b9 	lsl	x25, x21, #2
    530c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    5310:	aa1603e0 	mov	x0, x22
    5314:	97fff01b 	bl	1380 <strlen@plt>
    5318:	aa1603e1 	mov	x1, x22
    531c:	aa0003e2 	mov	x2, x0
    5320:	aa1403e0 	mov	x0, x20
    5324:	97fff323 	bl	1fb0 <buf_put>
    5328:	f9401780 	ldr	x0, [x28, #40]
    532c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    5330:	7100001f 	cmp	w0, #0x0
    5334:	5400068d 	b.le	5404 <fwp_write+0x7e4>
    5338:	91002276 	add	x22, x19, #0x8
    533c:	91001ff5 	add	x21, sp, #0x7
    5340:	d280001b 	mov	x27, #0x0                   	// #0
    5344:	5280041a 	mov	w26, #0x20                  	// #32
    5348:	f9401b80 	ldr	x0, [x28, #48]
    534c:	aa1503e1 	mov	x1, x21
    5350:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    5354:	d2800022 	mov	x2, #0x1                   	// #1
    5358:	f8786803 	ldr	x3, [x0, x24]
    535c:	aa1403e0 	mov	x0, x20
    5360:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    5364:	39001ffa 	strb	w26, [sp, #7]
    5368:	97fff312 	bl	1fb0 <buf_put>
    536c:	f13ffeff 	cmp	x23, #0xfff
    5370:	b9400261 	ldr	w1, [x19]
    5374:	1a9f97e0 	cset	w0, hi	// hi = pmore
    5378:	7100383f 	cmp	w1, #0xe
    537c:	54000160 	b.eq	53a8 <fwp_write+0x788>  // b.none
    5380:	7100403f 	cmp	w1, #0x10
    5384:	54001a60 	b.eq	56d0 <fwp_write+0xab0>  // b.none
    5388:	7100283f 	cmp	w1, #0xa
    538c:	54002aa0 	b.eq	58e0 <fwp_write+0xcc0>  // b.none
    5390:	540014ac 	b.gt	5624 <fwp_write+0xa04>
    5394:	71000c3f 	cmp	w1, #0x3
    5398:	540029ac 	b.gt	58cc <fwp_write+0xcac>
    539c:	d37ffee0 	lsr	x0, x23, #63
    53a0:	37f814a1 	tbnz	w1, #31, 5634 <fwp_write+0xa14>
    53a4:	d503201f 	nop
    53a8:	34001460 	cbz	w0, 5634 <fwp_write+0xa14>
    53ac:	52800503 	mov	w3, #0x28                  	// #40
    53b0:	aa1503e1 	mov	x1, x21
    53b4:	aa1403e0 	mov	x0, x20
    53b8:	d2800022 	mov	x2, #0x1                   	// #1
    53bc:	39001fe3 	strb	w3, [sp, #7]
    53c0:	97fff2fc 	bl	1fb0 <buf_put>
    53c4:	aa1303e2 	mov	x2, x19
    53c8:	aa1703e1 	mov	x1, x23
    53cc:	aa1403e0 	mov	x0, x20
    53d0:	52800003 	mov	w3, #0x0                   	// #0
    53d4:	97fffe13 	bl	4c20 <fwp_write>
    53d8:	52800523 	mov	w3, #0x29                  	// #41
    53dc:	aa1503e1 	mov	x1, x21
    53e0:	aa1403e0 	mov	x0, x20
    53e4:	d2800022 	mov	x2, #0x1                   	// #1
    53e8:	39001fe3 	strb	w3, [sp, #7]
    53ec:	97fff2f1 	bl	1fb0 <buf_put>
    53f0:	f9401780 	ldr	x0, [x28, #40]
    53f4:	9100077b 	add	x27, x27, #0x1
    53f8:	b8796800 	ldr	w0, [x0, x25]
    53fc:	6b1b001f 	cmp	w0, w27
    5400:	54fffa4c 	b.gt	5348 <fwp_write+0x728>
    5404:	f9413bf5 	ldr	x21, [sp, #624]
    5408:	f9413ff6 	ldr	x22, [sp, #632]
    540c:	f94143f7 	ldr	x23, [sp, #640]
    5410:	f94147f8 	ldr	x24, [sp, #648]
    5414:	f9414bf9 	ldr	x25, [sp, #656]
    5418:	f9414ffa 	ldr	x26, [sp, #664]
    541c:	f94153fb 	ldr	x27, [sp, #672]
    5420:	f94157fc 	ldr	x28, [sp, #680]
    5424:	17fffe2b 	b	4cd0 <fwp_write+0xb0>
    5428:	52800783 	mov	w3, #0x3c                  	// #60
    542c:	91001ff3 	add	x19, sp, #0x7
    5430:	aa1303e1 	mov	x1, x19
    5434:	d2800022 	mov	x2, #0x1                   	// #1
    5438:	aa1403e0 	mov	x0, x20
    543c:	39001fe3 	strb	w3, [sp, #7]
    5440:	97fff2dc 	bl	1fb0 <buf_put>
    5444:	f9400795 	ldr	x21, [x28, #8]
    5448:	aa1503e0 	mov	x0, x21
    544c:	97ffefcd 	bl	1380 <strlen@plt>
    5450:	aa1503e1 	mov	x1, x21
    5454:	aa0003e2 	mov	x2, x0
    5458:	aa1403e0 	mov	x0, x20
    545c:	97fff2d5 	bl	1fb0 <buf_put>
    5460:	528007c3 	mov	w3, #0x3e                  	// #62
    5464:	aa1303e1 	mov	x1, x19
    5468:	aa1403e0 	mov	x0, x20
    546c:	d2800022 	mov	x2, #0x1                   	// #1
    5470:	39001fe3 	strb	w3, [sp, #7]
    5474:	17fffe12 	b	4cbc <fwp_write+0x9c>
    5478:	f100067f 	cmp	x19, #0x1
    547c:	540025a0 	b.eq	5930 <fwp_write+0xd10>  // b.none
    5480:	b100067f 	cmn	x19, #0x1
    5484:	54002bc0 	b.eq	59fc <fwp_write+0xddc>  // b.none
    5488:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    548c:	91054021 	add	x1, x1, #0x150
    5490:	d2800022 	mov	x2, #0x1                   	// #1
    5494:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    5498:	f947f400 	ldr	x0, [x0, #4072]
    549c:	f94127e4 	ldr	x4, [sp, #584]
    54a0:	f9400003 	ldr	x3, [x0]
    54a4:	eb030084 	subs	x4, x4, x3
    54a8:	d2800003 	mov	x3, #0x0                   	// #0
    54ac:	54ffebe0 	b.eq	5228 <fwp_write+0x608>  // b.none
    54b0:	f90143f7 	str	x23, [sp, #640]
    54b4:	f90147f8 	str	x24, [sp, #648]
    54b8:	f9014bf9 	str	x25, [sp, #656]
    54bc:	f9014ffa 	str	x26, [sp, #664]
    54c0:	fd015be8 	str	d8, [sp, #688]
    54c4:	fd015fe9 	str	d9, [sp, #696]
    54c8:	97fff00a 	bl	14f0 <__stack_chk_fail@plt>
    54cc:	52800b63 	mov	w3, #0x5b                  	// #91
    54d0:	91001ff5 	add	x21, sp, #0x7
    54d4:	aa1503e1 	mov	x1, x21
    54d8:	aa1403e0 	mov	x0, x20
    54dc:	d2800022 	mov	x2, #0x1                   	// #1
    54e0:	d0000016 	adrp	x22, 7000 <_IO_stdin_used+0x140>
    54e4:	9107c2d6 	add	x22, x22, #0x1f0
    54e8:	39001fe3 	strb	w3, [sp, #7]
    54ec:	97fff2b1 	bl	1fb0 <buf_put>
    54f0:	b4000273 	cbz	x19, 553c <fwp_write+0x91c>
    54f4:	f9400661 	ldr	x1, [x19, #8]
    54f8:	aa1403e0 	mov	x0, x20
    54fc:	f9401f82 	ldr	x2, [x28, #56]
    5500:	52800003 	mov	w3, #0x0                   	// #0
    5504:	97fffdc7 	bl	4c20 <fwp_write>
    5508:	f9400a73 	ldr	x19, [x19, #16]
    550c:	b4000193 	cbz	x19, 553c <fwp_write+0x91c>
    5510:	aa1603e1 	mov	x1, x22
    5514:	aa1403e0 	mov	x0, x20
    5518:	d2800042 	mov	x2, #0x2                   	// #2
    551c:	97fff2a5 	bl	1fb0 <buf_put>
    5520:	f9400661 	ldr	x1, [x19, #8]
    5524:	aa1403e0 	mov	x0, x20
    5528:	f9401f82 	ldr	x2, [x28, #56]
    552c:	52800003 	mov	w3, #0x0                   	// #0
    5530:	97fffdbc 	bl	4c20 <fwp_write>
    5534:	f9400a73 	ldr	x19, [x19, #16]
    5538:	b5fffed3 	cbnz	x19, 5510 <fwp_write+0x8f0>
    553c:	52800ba3 	mov	w3, #0x5d                  	// #93
    5540:	aa1503e1 	mov	x1, x21
    5544:	aa1403e0 	mov	x0, x20
    5548:	d2800022 	mov	x2, #0x1                   	// #1
    554c:	39001fe3 	strb	w3, [sp, #7]
    5550:	17fffddb 	b	4cbc <fwp_write+0x9c>
    5554:	aa1403e0 	mov	x0, x20
    5558:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    555c:	d28000c2 	mov	x2, #0x6                   	// #6
    5560:	91078021 	add	x1, x1, #0x1e0
    5564:	97fff293 	bl	1fb0 <buf_put>
    5568:	f9400260 	ldr	x0, [x19]
    556c:	b40004c0 	cbz	x0, 5604 <fwp_write+0x9e4>
    5570:	910123f5 	add	x21, sp, #0x48
    5574:	91002276 	add	x22, x19, #0x8
    5578:	f90143f7 	str	x23, [sp, #640]
    557c:	d2800017 	mov	x23, #0x0                   	// #0
    5580:	f90147f8 	str	x24, [sp, #648]
    5584:	d0000018 	adrp	x24, 7000 <_IO_stdin_used+0x140>
    5588:	9107a318 	add	x24, x24, #0x1e8
    558c:	f9014bf9 	str	x25, [sp, #656]
    5590:	d0000019 	adrp	x25, 7000 <_IO_stdin_used+0x140>
    5594:	9107c339 	add	x25, x25, #0x1f0
    5598:	f9014ffa 	str	x26, [sp, #664]
    559c:	14000005 	b	55b0 <fwp_write+0x990>
    55a0:	aa1903e1 	mov	x1, x25
    55a4:	aa1403e0 	mov	x0, x20
    55a8:	d2800042 	mov	x2, #0x2                   	// #2
    55ac:	97fff281 	bl	1fb0 <buf_put>
    55b0:	38776ac5 	ldrb	w5, [x22, x23]
    55b4:	d2804003 	mov	x3, #0x200                 	// #512
    55b8:	aa1803e4 	mov	x4, x24
    55bc:	aa0303e1 	mov	x1, x3
    55c0:	52800042 	mov	w2, #0x2                   	// #2
    55c4:	aa1503e0 	mov	x0, x21
    55c8:	910006f7 	add	x23, x23, #0x1
    55cc:	97ffefa5 	bl	1460 <__snprintf_chk@plt>
    55d0:	aa1503e0 	mov	x0, x21
    55d4:	97ffef6b 	bl	1380 <strlen@plt>
    55d8:	aa1503e1 	mov	x1, x21
    55dc:	aa0003e2 	mov	x2, x0
    55e0:	aa1403e0 	mov	x0, x20
    55e4:	97fff273 	bl	1fb0 <buf_put>
    55e8:	f9400260 	ldr	x0, [x19]
    55ec:	eb17001f 	cmp	x0, x23
    55f0:	54fffd88 	b.hi	55a0 <fwp_write+0x980>  // b.pmore
    55f4:	f94143f7 	ldr	x23, [sp, #640]
    55f8:	f94147f8 	ldr	x24, [sp, #648]
    55fc:	f9414bf9 	ldr	x25, [sp, #656]
    5600:	f9414ffa 	ldr	x26, [sp, #664]
    5604:	52800ba3 	mov	w3, #0x5d                  	// #93
    5608:	aa1403e0 	mov	x0, x20
    560c:	91001fe1 	add	x1, sp, #0x7
    5610:	d2800022 	mov	x2, #0x1                   	// #1
    5614:	39001fe3 	strb	w3, [sp, #7]
    5618:	17fffda9 	b	4cbc <fwp_write+0x9c>
    561c:	52800fa3 	mov	w3, #0x7d                  	// #125
    5620:	17fffe44 	b	4f30 <fwp_write+0x310>
    5624:	f10002ff 	cmp	x23, #0x0
    5628:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    562c:	71002c3f 	cmp	w1, #0xb
    5630:	54ffebc0 	b.eq	53a8 <fwp_write+0x788>  // b.none
    5634:	aa1303e2 	mov	x2, x19
    5638:	aa1703e1 	mov	x1, x23
    563c:	aa1403e0 	mov	x0, x20
    5640:	52800003 	mov	w3, #0x0                   	// #0
    5644:	97fffd77 	bl	4c20 <fwp_write>
    5648:	17ffff6a 	b	53f0 <fwp_write+0x7d0>
    564c:	aa1403e0 	mov	x0, x20
    5650:	91001fe1 	add	x1, sp, #0x7
    5654:	52800fa3 	mov	w3, #0x7d                  	// #125
    5658:	d2800022 	mov	x2, #0x1                   	// #1
    565c:	17fffe38 	b	4f3c <fwp_write+0x31c>
    5660:	a9400281 	ldp	x1, x0, [x20]
    5664:	91000800 	add	x0, x0, #0x2
    5668:	8b160000 	add	x0, x0, x22
    566c:	f9000680 	str	x0, [x20, #8]
    5670:	3820683f 	strb	wzr, [x1, x0]
    5674:	f9413bf5 	ldr	x21, [sp, #624]
    5678:	f9413ff6 	ldr	x22, [sp, #632]
    567c:	f94153fb 	ldr	x27, [sp, #672]
    5680:	f94157fc 	ldr	x28, [sp, #680]
    5684:	17fffd93 	b	4cd0 <fwp_write+0xb0>
    5688:	f9400f80 	ldr	x0, [x28, #24]
    568c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    5690:	aa1b03e0 	mov	x0, x27
    5694:	97ffef3b 	bl	1380 <strlen@plt>
    5698:	aa1b03e1 	mov	x1, x27
    569c:	aa0003e2 	mov	x2, x0
    56a0:	aa1403e0 	mov	x0, x20
    56a4:	97fff243 	bl	1fb0 <buf_put>
    56a8:	aa1903e1 	mov	x1, x25
    56ac:	aa1403e0 	mov	x0, x20
    56b0:	d2800062 	mov	x2, #0x3                   	// #3
    56b4:	97fff23f 	bl	1fb0 <buf_put>
    56b8:	17fffe10 	b	4ef8 <fwp_write+0x2d8>
    56bc:	aa1a03e1 	mov	x1, x26
    56c0:	aa1403e0 	mov	x0, x20
    56c4:	d2800042 	mov	x2, #0x2                   	// #2
    56c8:	97fff23a 	bl	1fb0 <buf_put>
    56cc:	17fffe09 	b	4ef0 <fwp_write+0x2d0>
    56d0:	f9400660 	ldr	x0, [x19, #8]
    56d4:	b4fffb00 	cbz	x0, 5634 <fwp_write+0xa14>
    56d8:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    56dc:	91082021 	add	x1, x1, #0x208
    56e0:	97ffefa4 	bl	1570 <strcmp@plt>
    56e4:	7100001f 	cmp	w0, #0x0
    56e8:	1a9f07e0 	cset	w0, ne	// ne = any
    56ec:	17ffff2f 	b	53a8 <fwp_write+0x788>
    56f0:	aa1403e0 	mov	x0, x20
    56f4:	d2800042 	mov	x2, #0x2                   	// #2
    56f8:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    56fc:	91080021 	add	x1, x1, #0x200
    5700:	97fff22c 	bl	1fb0 <buf_put>
    5704:	91004261 	add	x1, x19, #0x10
    5708:	aa1403e0 	mov	x0, x20
    570c:	f9402382 	ldr	x2, [x28, #64]
    5710:	52800003 	mov	w3, #0x0                   	// #0
    5714:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    5718:	97fffd42 	bl	4c20 <fwp_write>
    571c:	17fffd9c 	b	4d8c <fwp_write+0x16c>
    5720:	1e22c109 	fcvt	d9, s8
    5724:	910123f5 	add	x21, sp, #0x48
    5728:	52800033 	mov	w19, #0x1                   	// #1
    572c:	d503201f 	nop
    5730:	1e604120 	fmov	d0, d9
    5734:	2a1303e1 	mov	w1, w19
    5738:	aa1503e0 	mov	x0, x21
    573c:	97fff2b2 	bl	2204 <fwp_format_g.constprop.0>
    5740:	aa1503e0 	mov	x0, x21
    5744:	d2800001 	mov	x1, #0x0                   	// #0
    5748:	97ffef96 	bl	15a0 <strtof@plt>
    574c:	1e202100 	fcmp	s8, s0
    5750:	54ffdb60 	b.eq	52bc <fwp_write+0x69c>  // b.none
    5754:	11000673 	add	w19, w19, #0x1
    5758:	71002a7f 	cmp	w19, #0xa
    575c:	54fffea1 	b.ne	5730 <fwp_write+0xb10>  // b.any
    5760:	1e604120 	fmov	d0, d9
    5764:	aa1503e0 	mov	x0, x21
    5768:	52800121 	mov	w1, #0x9                   	// #9
    576c:	97fff2a6 	bl	2204 <fwp_format_g.constprop.0>
    5770:	17fffed3 	b	52bc <fwp_write+0x69c>
    5774:	d37ef6a1 	lsl	x1, x21, #2
    5778:	b7f81563 	tbnz	x3, #63, 5a24 <fwp_write+0xe04>
    577c:	91002263 	add	x3, x19, #0x8
    5780:	8b010061 	add	x1, x3, x1
    5784:	b9400023 	ldr	w3, [x1]
    5788:	7100081f 	cmp	w0, #0x2
    578c:	2a0303e1 	mov	w1, w3
    5790:	93407c63 	sxtw	x3, w3
    5794:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    5798:	17fffe5a 	b	5100 <fwp_write+0x4e0>
    579c:	d37ffaa1 	lsl	x1, x21, #1
    57a0:	b7f81363 	tbnz	x3, #63, 5a0c <fwp_write+0xdec>
    57a4:	91002263 	add	x3, x19, #0x8
    57a8:	8b010061 	add	x1, x3, x1
    57ac:	79400021 	ldrh	w1, [x1]
    57b0:	7100041f 	cmp	w0, #0x1
    57b4:	93403c23 	sxth	x3, w1
    57b8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    57bc:	17fffe51 	b	5100 <fwp_write+0x4e0>
    57c0:	52800443 	mov	w3, #0x22                  	// #34
    57c4:	91001ff5 	add	x21, sp, #0x7
    57c8:	91002273 	add	x19, x19, #0x8
    57cc:	aa1503e1 	mov	x1, x21
    57d0:	aa1403e0 	mov	x0, x20
    57d4:	d2800022 	mov	x2, #0x1                   	// #1
    57d8:	39001fe3 	strb	w3, [sp, #7]
    57dc:	f90143f7 	str	x23, [sp, #640]
    57e0:	8b160277 	add	x23, x19, x22
    57e4:	f90147f8 	str	x24, [sp, #648]
    57e8:	97fff1f2 	bl	1fb0 <buf_put>
    57ec:	b4000696 	cbz	x22, 58bc <fwp_write+0xc9c>
    57f0:	d0000018 	adrp	x24, 7000 <_IO_stdin_used+0x140>
    57f4:	9106c318 	add	x24, x24, #0x1b0
    57f8:	f9014bf9 	str	x25, [sp, #656]
    57fc:	d0000019 	adrp	x25, 7000 <_IO_stdin_used+0x140>
    5800:	91074339 	add	x25, x25, #0x1d0
    5804:	f9014ffa 	str	x26, [sp, #664]
    5808:	1400000d 	b	583c <fwp_write+0xc1c>
    580c:	710024bf 	cmp	w5, #0x9
    5810:	54000460 	b.eq	589c <fwp_write+0xc7c>  // b.none
    5814:	710028bf 	cmp	w5, #0xa
    5818:	54000a61 	b.ne	5964 <fwp_write+0xd44>  // b.any
    581c:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    5820:	aa1403e0 	mov	x0, x20
    5824:	91070021 	add	x1, x1, #0x1c0
    5828:	d2800042 	mov	x2, #0x2                   	// #2
    582c:	97fff1e1 	bl	1fb0 <buf_put>
    5830:	91000673 	add	x19, x19, #0x1
    5834:	eb17027f 	cmp	x19, x23
    5838:	540003e0 	b.eq	58b4 <fwp_write+0xc94>  // b.none
    583c:	39400265 	ldrb	w5, [x19]
    5840:	710034bf 	cmp	w5, #0xd
    5844:	54000180 	b.eq	5874 <fwp_write+0xc54>  // b.none
    5848:	54fffe29 	b.ls	580c <fwp_write+0xbec>  // b.plast
    584c:	710088bf 	cmp	w5, #0x22
    5850:	540001c0 	b.eq	5888 <fwp_write+0xc68>  // b.none
    5854:	710170bf 	cmp	w5, #0x5c
    5858:	54000741 	b.ne	5940 <fwp_write+0xd20>  // b.any
    585c:	aa1403e0 	mov	x0, x20
    5860:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    5864:	d2800042 	mov	x2, #0x2                   	// #2
    5868:	9106e021 	add	x1, x1, #0x1b8
    586c:	97fff1d1 	bl	1fb0 <buf_put>
    5870:	17fffff0 	b	5830 <fwp_write+0xc10>
    5874:	aa1903e1 	mov	x1, x25
    5878:	aa1403e0 	mov	x0, x20
    587c:	d2800042 	mov	x2, #0x2                   	// #2
    5880:	97fff1cc 	bl	1fb0 <buf_put>
    5884:	17ffffeb 	b	5830 <fwp_write+0xc10>
    5888:	aa1803e1 	mov	x1, x24
    588c:	aa1403e0 	mov	x0, x20
    5890:	d2800042 	mov	x2, #0x2                   	// #2
    5894:	97fff1c7 	bl	1fb0 <buf_put>
    5898:	17ffffe6 	b	5830 <fwp_write+0xc10>
    589c:	aa1403e0 	mov	x0, x20
    58a0:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    58a4:	d2800042 	mov	x2, #0x2                   	// #2
    58a8:	91072021 	add	x1, x1, #0x1c8
    58ac:	97fff1c1 	bl	1fb0 <buf_put>
    58b0:	17ffffe0 	b	5830 <fwp_write+0xc10>
    58b4:	f9414bf9 	ldr	x25, [sp, #656]
    58b8:	f9414ffa 	ldr	x26, [sp, #664]
    58bc:	aa1503e1 	mov	x1, x21
    58c0:	aa1403e0 	mov	x0, x20
    58c4:	52800443 	mov	w3, #0x22                  	// #34
    58c8:	17fffd9c 	b	4f38 <fwp_write+0x318>
    58cc:	7100103f 	cmp	w1, #0x4
    58d0:	54ffeb21 	b.ne	5634 <fwp_write+0xa14>  // b.any
    58d4:	f94006e0 	ldr	x0, [x23, #8]
    58d8:	d37ffc00 	lsr	x0, x0, #63
    58dc:	17fffeb3 	b	53a8 <fwp_write+0x788>
    58e0:	710002ff 	cmp	w23, #0x0
    58e4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    58e8:	17fffeb0 	b	53a8 <fwp_write+0x788>
    58ec:	528005a1 	mov	w1, #0x2d                  	// #45
    58f0:	eb0203e2 	negs	x2, x2
    58f4:	da0303e3 	ngc	x3, x3
    58f8:	910127e0 	add	x0, sp, #0x49
    58fc:	910123f5 	add	x21, sp, #0x48
    5900:	390123e1 	strb	w1, [sp, #72]
    5904:	97fff047 	bl	1a20 <fwp_fmt_u128>
    5908:	17fffe18 	b	5168 <fwp_write+0x548>
    590c:	d37ceea1 	lsl	x1, x21, #4
    5910:	b7f810a3 	tbnz	x3, #63, 5b24 <fwp_write+0xf04>
    5914:	91002260 	add	x0, x19, #0x8
    5918:	8b010001 	add	x1, x0, x1
    591c:	17fffdf9 	b	5100 <fwp_write+0x4e0>
    5920:	f9400a61 	ldr	x1, [x19, #16]
    5924:	8b010000 	add	x0, x0, x1
    5928:	f9400001 	ldr	x1, [x0]
    592c:	17fffdf5 	b	5100 <fwp_write+0x4e0>
    5930:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    5934:	d2800042 	mov	x2, #0x2                   	// #2
    5938:	91056021 	add	x1, x1, #0x158
    593c:	17fffed6 	b	5494 <fwp_write+0x874>
    5940:	7101fcbf 	cmp	w5, #0x7f
    5944:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    5948:	540000e9 	b.ls	5964 <fwp_write+0xd44>  // b.plast
    594c:	aa1503e1 	mov	x1, x21
    5950:	aa1403e0 	mov	x0, x20
    5954:	d2800022 	mov	x2, #0x1                   	// #1
    5958:	39001fe5 	strb	w5, [sp, #7]
    595c:	97fff195 	bl	1fb0 <buf_put>
    5960:	17ffffb4 	b	5830 <fwp_write+0xc10>
    5964:	d2800203 	mov	x3, #0x10                  	// #16
    5968:	d0000004 	adrp	x4, 7000 <_IO_stdin_used+0x140>
    596c:	aa0303e1 	mov	x1, x3
    5970:	91076084 	add	x4, x4, #0x1d8
    5974:	910123f6 	add	x22, sp, #0x48
    5978:	52800042 	mov	w2, #0x2                   	// #2
    597c:	aa1603e0 	mov	x0, x22
    5980:	97ffeeb8 	bl	1460 <__snprintf_chk@plt>
    5984:	aa1603e0 	mov	x0, x22
    5988:	97ffee7e 	bl	1380 <strlen@plt>
    598c:	aa1603e1 	mov	x1, x22
    5990:	aa0003e2 	mov	x2, x0
    5994:	aa1403e0 	mov	x0, x20
    5998:	97fff186 	bl	1fb0 <buf_put>
    599c:	17ffffa5 	b	5830 <fwp_write+0xc10>
    59a0:	1e604100 	fmov	d0, d8
    59a4:	aa1503e0 	mov	x0, x21
    59a8:	52800221 	mov	w1, #0x11                  	// #17
    59ac:	97fff216 	bl	2204 <fwp_format_g.constprop.0>
    59b0:	17fffe43 	b	52bc <fwp_write+0x69c>
    59b4:	b9401040 	ldr	w0, [x2, #16]
    59b8:	350003c0 	cbnz	w0, 5a30 <fwp_write+0xe10>
    59bc:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    59c0:	f947f400 	ldr	x0, [x0, #4072]
    59c4:	f94127e2 	ldr	x2, [sp, #584]
    59c8:	f9400001 	ldr	x1, [x0]
    59cc:	eb010042 	subs	x2, x2, x1
    59d0:	d2800001 	mov	x1, #0x0                   	// #0
    59d4:	54ffd721 	b.ne	54b8 <fwp_write+0x898>  // b.any
    59d8:	f9413bf5 	ldr	x21, [sp, #624]
    59dc:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    59e0:	f9413ff6 	ldr	x22, [sp, #632]
    59e4:	aa1403e0 	mov	x0, x20
    59e8:	f94143f7 	ldr	x23, [sp, #640]
    59ec:	9108a021 	add	x1, x1, #0x228
    59f0:	f94147f8 	ldr	x24, [sp, #648]
    59f4:	d2800042 	mov	x2, #0x2                   	// #2
    59f8:	17fffd0e 	b	4e30 <fwp_write+0x210>
    59fc:	d0000001 	adrp	x1, 7000 <_IO_stdin_used+0x140>
    5a00:	d2800042 	mov	x2, #0x2                   	// #2
    5a04:	91058021 	add	x1, x1, #0x160
    5a08:	17fffea3 	b	5494 <fwp_write+0x874>
    5a0c:	f9400a63 	ldr	x3, [x19, #16]
    5a10:	8b030021 	add	x1, x1, x3
    5a14:	17ffff66 	b	57ac <fwp_write+0xb8c>
    5a18:	f9400a61 	ldr	x1, [x19, #16]
    5a1c:	8b0102a1 	add	x1, x21, x1
    5a20:	17fffdb3 	b	50ec <fwp_write+0x4cc>
    5a24:	f9400a63 	ldr	x3, [x19, #16]
    5a28:	8b030021 	add	x1, x1, x3
    5a2c:	17ffff56 	b	5784 <fwp_write+0xb64>
    5a30:	b9404840 	ldr	w0, [x2, #72]
    5a34:	91001ff5 	add	x21, sp, #0x7
    5a38:	34ffa360 	cbz	w0, 4ea4 <fwp_write+0x284>
    5a3c:	52800503 	mov	w3, #0x28                  	// #40
    5a40:	aa1403e0 	mov	x0, x20
    5a44:	aa1503e1 	mov	x1, x21
    5a48:	d2800022 	mov	x2, #0x1                   	// #1
    5a4c:	39001fe3 	strb	w3, [sp, #7]
    5a50:	97fff158 	bl	1fb0 <buf_put>
    5a54:	b9401380 	ldr	w0, [x28, #16]
    5a58:	52800038 	mov	w24, #0x1                   	// #1
    5a5c:	7100001f 	cmp	w0, #0x0
    5a60:	54ffa36c 	b.gt	4ecc <fwp_write+0x2ac>
    5a64:	17fffd32 	b	4f2c <fwp_write+0x30c>
    5a68:	f9014bf9 	str	x25, [sp, #656]
    5a6c:	d00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x16b00>
    5a70:	f9014ffa 	str	x26, [sp, #664]
    5a74:	f9400676 	ldr	x22, [x19, #8]
    5a78:	912ae333 	add	x19, x25, #0xab8
    5a7c:	91002273 	add	x19, x19, #0x8
    5a80:	937ffed8 	asr	x24, x22, #63
    5a84:	aa1802c0 	orr	x0, x22, x24
    5a88:	b5000320 	cbnz	x0, 5aec <fwp_write+0xecc>
    5a8c:	110006b5 	add	w21, w21, #0x1
    5a90:	710016bf 	cmp	w21, #0x5
    5a94:	54ffffc1 	b.ne	5a8c <fwp_write+0xe6c>  // b.any
    5a98:	b7f80578 	tbnz	x24, #63, 5b44 <fwp_write+0xf24>
    5a9c:	910023f3 	add	x19, sp, #0x8
    5aa0:	aa1603e2 	mov	x2, x22
    5aa4:	aa1303e0 	mov	x0, x19
    5aa8:	d2800003 	mov	x3, #0x0                   	// #0
    5aac:	97ffefdd 	bl	1a20 <fwp_fmt_u128>
    5ab0:	910123f5 	add	x21, sp, #0x48
    5ab4:	d0000003 	adrp	x3, 7000 <_IO_stdin_used+0x140>
    5ab8:	aa1303e4 	mov	x4, x19
    5abc:	aa1503e0 	mov	x0, x21
    5ac0:	91088063 	add	x3, x3, #0x220
    5ac4:	d2804002 	mov	x2, #0x200                 	// #512
    5ac8:	52800041 	mov	w1, #0x2                   	// #2
    5acc:	97ffee31 	bl	1390 <__sprintf_chk@plt>
    5ad0:	aa1503e0 	mov	x0, x21
    5ad4:	97ffee2b 	bl	1380 <strlen@plt>
    5ad8:	aa1503e1 	mov	x1, x21
    5adc:	aa0003e2 	mov	x2, x0
    5ae0:	aa1403e0 	mov	x0, x20
    5ae4:	97fff133 	bl	1fb0 <buf_put>
    5ae8:	17fffe47 	b	5404 <fwp_write+0x7e4>
    5aec:	f9400277 	ldr	x23, [x19]
    5af0:	aa1603e0 	mov	x0, x22
    5af4:	aa1803e1 	mov	x1, x24
    5af8:	aa1703e2 	mov	x2, x23
    5afc:	937ffefa 	asr	x26, x23, #63
    5b00:	aa1a03e3 	mov	x3, x26
    5b04:	94000407 	bl	6b20 <__modti3>
    5b08:	aa010000 	orr	x0, x0, x1
    5b0c:	b40002c0 	cbz	x0, 5b64 <fwp_write+0xf44>
    5b10:	110006b5 	add	w21, w21, #0x1
    5b14:	91004273 	add	x19, x19, #0x10
    5b18:	710016bf 	cmp	w21, #0x5
    5b1c:	54fffe81 	b.ne	5aec <fwp_write+0xecc>  // b.any
    5b20:	17ffffde 	b	5a98 <fwp_write+0xe78>
    5b24:	f9400a60 	ldr	x0, [x19, #16]
    5b28:	8b000021 	add	x1, x1, x0
    5b2c:	17fffd75 	b	5100 <fwp_write+0x4e0>
    5b30:	528c29c0 	mov	w0, #0x614e                	// #24910
    5b34:	910123f5 	add	x21, sp, #0x48
    5b38:	72a009c0 	movk	w0, #0x4e, lsl #16
    5b3c:	b9004be0 	str	w0, [sp, #72]
    5b40:	17fffda2 	b	51c8 <fwp_write+0x5a8>
    5b44:	528005a1 	mov	w1, #0x2d                  	// #45
    5b48:	eb1603e2 	negs	x2, x22
    5b4c:	da1803e3 	ngc	x3, x24
    5b50:	910027e0 	add	x0, sp, #0x9
    5b54:	910023f3 	add	x19, sp, #0x8
    5b58:	390023e1 	strb	w1, [sp, #8]
    5b5c:	97ffefb1 	bl	1a20 <fwp_fmt_u128>
    5b60:	17ffffd4 	b	5ab0 <fwp_write+0xe90>
    5b64:	aa1703e2 	mov	x2, x23
    5b68:	aa1a03e3 	mov	x3, x26
    5b6c:	aa1603e0 	mov	x0, x22
    5b70:	aa1803e1 	mov	x1, x24
    5b74:	9400030b 	bl	67a0 <__divti3>
    5b78:	aa0003e2 	mov	x2, x0
    5b7c:	aa0103e3 	mov	x3, x1
    5b80:	b7f80201 	tbnz	x1, #63, 5bc0 <fwp_write+0xfa0>
    5b84:	910023f3 	add	x19, sp, #0x8
    5b88:	aa1303e0 	mov	x0, x19
    5b8c:	97ffefa5 	bl	1a20 <fwp_fmt_u128>
    5b90:	937c7ea1 	sbfiz	x1, x21, #4, #32
    5b94:	912ae339 	add	x25, x25, #0xab8
    5b98:	910123f5 	add	x21, sp, #0x48
    5b9c:	aa1303e4 	mov	x4, x19
    5ba0:	aa1503e0 	mov	x0, x21
    5ba4:	d0000003 	adrp	x3, 7000 <_IO_stdin_used+0x140>
    5ba8:	f8616b25 	ldr	x5, [x25, x1]
    5bac:	91086063 	add	x3, x3, #0x218
    5bb0:	d2804002 	mov	x2, #0x200                 	// #512
    5bb4:	52800041 	mov	w1, #0x2                   	// #2
    5bb8:	97ffedf6 	bl	1390 <__sprintf_chk@plt>
    5bbc:	17ffffc5 	b	5ad0 <fwp_write+0xeb0>
    5bc0:	528005a4 	mov	w4, #0x2d                  	// #45
    5bc4:	eb0003e2 	negs	x2, x0
    5bc8:	da0103e3 	ngc	x3, x1
    5bcc:	910027e0 	add	x0, sp, #0x9
    5bd0:	910023f3 	add	x19, sp, #0x8
    5bd4:	390023e4 	strb	w4, [sp, #8]
    5bd8:	97ffef92 	bl	1a20 <fwp_fmt_u128>
    5bdc:	17ffffed 	b	5b90 <fwp_write+0xf70>
    5be0:	f9013bf5 	str	x21, [sp, #624]
    5be4:	f9013ff6 	str	x22, [sp, #632]
    5be8:	f90143f7 	str	x23, [sp, #640]
    5bec:	f90147f8 	str	x24, [sp, #648]
    5bf0:	f9014bf9 	str	x25, [sp, #656]
    5bf4:	f9014ffa 	str	x26, [sp, #664]
    5bf8:	f90153fb 	str	x27, [sp, #672]
    5bfc:	f90157fc 	str	x28, [sp, #680]
    5c00:	fd015be8 	str	d8, [sp, #688]
    5c04:	fd015fe9 	str	d9, [sp, #696]
    5c08:	97ffee3a 	bl	14f0 <__stack_chk_fail@plt>
    5c0c:	d503201f 	nop

0000000000005c10 <fwp_main_thread>:
    5c10:	d10603ff 	sub	sp, sp, #0x180
    5c14:	90000160 	adrp	x0, 31000 <fwp_root_context+0xd10>
    5c18:	91134001 	add	x1, x0, #0x4d0
    5c1c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    5c20:	f947f400 	ldr	x0, [x0, #4072]
    5c24:	a9127bfd 	stp	x29, x30, [sp, #288]
    5c28:	910483fd 	add	x29, sp, #0x120
    5c2c:	b953a421 	ldr	w1, [x1, #5028]
    5c30:	a91353f3 	stp	x19, x20, [sp, #304]
    5c34:	a9145bf5 	stp	x21, x22, [sp, #320]
    5c38:	a91773fb 	stp	x27, x28, [sp, #368]
    5c3c:	f9400002 	ldr	x2, [x0]
    5c40:	f9008fe2 	str	x2, [sp, #280]
    5c44:	d2800002 	mov	x2, #0x0                   	// #0
    5c48:	34005061 	cbz	w1, 6654 <fwp_main_thread+0xa44>
    5c4c:	90000160 	adrp	x0, 31000 <fwp_root_context+0xd10>
    5c50:	91134000 	add	x0, x0, #0x4d0
    5c54:	b953a800 	ldr	w0, [x0, #5032]
    5c58:	35004f60 	cbnz	w0, 6644 <fwp_main_thread+0xa34>
    5c5c:	f00000d4 	adrp	x20, 20000 <__data_start>
    5c60:	f00000c2 	adrp	x2, 20000 <__data_start>
    5c64:	9100c29b 	add	x27, x20, #0x30
    5c68:	910bc042 	add	x2, x2, #0x2f0
    5c6c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    5c70:	d2a00024 	mov	x4, #0x10000               	// #65536
    5c74:	910103e0 	add	x0, sp, #0x40
    5c78:	9100a3fc 	add	x28, sp, #0x28
    5c7c:	d2800001 	mov	x1, #0x0                   	// #0
    5c80:	f90003e0 	str	x0, [sp]
    5c84:	a9010f7c 	stp	x28, x3, [x27, #16]
    5c88:	f90023e2 	str	x2, [sp, #64]
    5c8c:	b9004bff 	str	wzr, [sp, #72]
    5c90:	f9002be4 	str	x4, [sp, #80]
    5c94:	97ffedb3 	bl	1360 <sigaltstack@plt>
    5c98:	350056e0 	cbnz	w0, 6774 <fwp_main_thread+0xb64>
    5c9c:	4f000400 	movi	v0.4s, #0x0
    5ca0:	910223e0 	add	x0, sp, #0x88
    5ca4:	90ffffe1 	adrp	x1, 1000 <__abi_tag+0xd88>
    5ca8:	91314021 	add	x1, x1, #0xc50
    5cac:	f90043e1 	str	x1, [sp, #128]
    5cb0:	52800082 	mov	w2, #0x4                   	// #4
    5cb4:	72a10002 	movk	w2, #0x800, lsl #16
    5cb8:	910203f5 	add	x21, sp, #0x80
    5cbc:	3d802000 	str	q0, [x0, #128]
    5cc0:	b9010be2 	str	w2, [sp, #264]
    5cc4:	ad000000 	stp	q0, q0, [x0]
    5cc8:	ad010000 	stp	q0, q0, [x0, #32]
    5ccc:	ad020000 	stp	q0, q0, [x0, #64]
    5cd0:	ad030000 	stp	q0, q0, [x0, #96]
    5cd4:	97ffedf7 	bl	14b0 <sigemptyset@plt>
    5cd8:	350054e0 	cbnz	w0, 6774 <fwp_main_thread+0xb64>
    5cdc:	aa1503e1 	mov	x1, x21
    5ce0:	d2800002 	mov	x2, #0x0                   	// #0
    5ce4:	52800160 	mov	w0, #0xb                   	// #11
    5ce8:	97ffee0a 	bl	1510 <sigaction@plt>
    5cec:	35005440 	cbnz	w0, 6774 <fwp_main_thread+0xb64>
    5cf0:	aa1503e1 	mov	x1, x21
    5cf4:	d2800002 	mov	x2, #0x0                   	// #0
    5cf8:	528000e0 	mov	w0, #0x7                   	// #7
    5cfc:	97ffee05 	bl	1510 <sigaction@plt>
    5d00:	350053a0 	cbnz	w0, 6774 <fwp_main_thread+0xb64>
    5d04:	b9429760 	ldr	w0, [x27, #660]
    5d08:	a91563f7 	stp	x23, x24, [sp, #336]
    5d0c:	34001f60 	cbz	w0, 60f8 <fwp_main_thread+0x4e8>
    5d10:	9100c296 	add	x22, x20, #0x30
    5d14:	f94006d5 	ldr	x21, [x22, #8]
    5d18:	b40010f5 	cbz	x21, 5f34 <fwp_main_thread+0x324>
    5d1c:	aa1503f3 	mov	x19, x21
    5d20:	910102b7 	add	x23, x21, #0x40
    5d24:	a9166bf9 	stp	x25, x26, [sp, #352]
    5d28:	52800038 	mov	w24, #0x1                   	// #1
    5d2c:	39414ab9 	ldrb	w25, [x21, #82]
    5d30:	39014ab8 	strb	w24, [x21, #82]
    5d34:	f94016a0 	ldr	x0, [x21, #40]
    5d38:	b4000620 	cbz	x0, 5dfc <fwp_main_thread+0x1ec>
    5d3c:	f94032a1 	ldr	x1, [x21, #96]
    5d40:	394146a0 	ldrb	w0, [x21, #81]
    5d44:	b4000b61 	cbz	x1, 5eb0 <fwp_main_thread+0x2a0>
    5d48:	36000aa0 	tbz	w0, #0, 5e9c <fwp_main_thread+0x28c>
    5d4c:	39414a62 	ldrb	w2, [x19, #82]
    5d50:	f94022a0 	ldr	x0, [x21, #64]
    5d54:	37000d82 	tbnz	w2, #0, 5f04 <fwp_main_thread+0x2f4>
    5d58:	f9403261 	ldr	x1, [x19, #96]
    5d5c:	a911fe77 	stp	x23, xzr, [x19, #280]
    5d60:	f9009660 	str	x0, [x19, #296]
    5d64:	b4000040 	cbz	x0, 5d6c <fwp_main_thread+0x15c>
    5d68:	f9009013 	str	x19, [x0, #288]
    5d6c:	f90022b3 	str	x19, [x21, #64]
    5d70:	b4000101 	cbz	x1, 5d90 <fwp_main_thread+0x180>
    5d74:	f9401ac0 	ldr	x0, [x22, #48]
    5d78:	39015678 	strb	w24, [x19, #85]
    5d7c:	f9003661 	str	x1, [x19, #104]
    5d80:	a910827f 	stp	xzr, x0, [x19, #264]
    5d84:	b4000040 	cbz	x0, 5d8c <fwp_main_thread+0x17c>
    5d88:	f9008413 	str	x19, [x0, #264]
    5d8c:	f9001ad3 	str	x19, [x22, #48]
    5d90:	39015a7f 	strb	wzr, [x19, #86]
    5d94:	97fff6cc 	bl	38c4 <fwp_block>
    5d98:	f9408e62 	ldr	x2, [x19, #280]
    5d9c:	b4000142 	cbz	x2, 5dc4 <fwp_main_thread+0x1b4>
    5da0:	a9520261 	ldp	x1, x0, [x19, #288]
    5da4:	b4000bc1 	cbz	x1, 5f1c <fwp_main_thread+0x30c>
    5da8:	f9009420 	str	x0, [x1, #296]
    5dac:	f9409660 	ldr	x0, [x19, #296]
    5db0:	b4000040 	cbz	x0, 5db8 <fwp_main_thread+0x1a8>
    5db4:	f9009001 	str	x1, [x0, #288]
    5db8:	91080260 	add	x0, x19, #0x200
    5dbc:	f900967f 	str	xzr, [x19, #296]
    5dc0:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    5dc4:	39415660 	ldrb	w0, [x19, #85]
    5dc8:	f94006c2 	ldr	x2, [x22, #8]
    5dcc:	36000980 	tbz	w0, #0, 5efc <fwp_main_thread+0x2ec>
    5dd0:	a9508261 	ldp	x1, x0, [x19, #264]
    5dd4:	b4000a81 	cbz	x1, 5f24 <fwp_main_thread+0x314>
    5dd8:	f9008820 	str	x0, [x1, #272]
    5ddc:	b4000040 	cbz	x0, 5de4 <fwp_main_thread+0x1d4>
    5de0:	f9008401 	str	x1, [x0, #264]
    5de4:	91080260 	add	x0, x19, #0x200
    5de8:	3901567f 	strb	wzr, [x19, #85]
    5dec:	aa0203f3 	mov	x19, x2
    5df0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    5df4:	f94016a0 	ldr	x0, [x21, #40]
    5df8:	b5fffa20 	cbnz	x0, 5d3c <fwp_main_thread+0x12c>
    5dfc:	9100c280 	add	x0, x20, #0x30
    5e00:	39014ab9 	strb	w25, [x21, #82]
    5e04:	a9566bf9 	ldp	x25, x26, [sp, #352]
    5e08:	f9413c00 	ldr	x0, [x0, #632]
    5e0c:	b4001560 	cbz	x0, 60b8 <fwp_main_thread+0x4a8>
    5e10:	9100c280 	add	x0, x20, #0x30
    5e14:	f9415401 	ldr	x1, [x0, #680]
    5e18:	b902a01f 	str	wzr, [x0, #672]
    5e1c:	eb13003f 	cmp	x1, x19
    5e20:	54001681 	b.ne	60f0 <fwp_main_thread+0x4e0>  // b.any
    5e24:	b4000933 	cbz	x19, 5f48 <fwp_main_thread+0x338>
    5e28:	9100c280 	add	x0, x20, #0x30
    5e2c:	52800021 	mov	w1, #0x1                   	// #1
    5e30:	39014a61 	strb	w1, [x19, #82]
    5e34:	f9412805 	ldr	x5, [x0, #592]
    5e38:	b4000885 	cbz	x5, 5f48 <fwp_main_thread+0x338>
    5e3c:	d503201f 	nop
    5e40:	394140a0 	ldrb	w0, [x5, #80]
    5e44:	37000060 	tbnz	w0, #0, 5e50 <fwp_main_thread+0x240>
    5e48:	aa0503e0 	mov	x0, x5
    5e4c:	97fff071 	bl	2010 <fwp_cancel_tree.part.0>
    5e50:	f9409ca5 	ldr	x5, [x5, #312]
    5e54:	b5ffff65 	cbnz	x5, 5e40 <fwp_main_thread+0x230>
    5e58:	9100c295 	add	x21, x20, #0x30
    5e5c:	52800036 	mov	w22, #0x1                   	// #1
    5e60:	f9402a60 	ldr	x0, [x19, #80]
    5e64:	f2001c1f 	tst	x0, #0xff000000ff
    5e68:	540000e1 	b.ne	5e84 <fwp_main_thread+0x274>  // b.any
    5e6c:	f94012a0 	ldr	x0, [x21, #32]
    5e70:	39015276 	strb	w22, [x19, #84]
    5e74:	f900827f 	str	xzr, [x19, #256]
    5e78:	b40005a0 	cbz	x0, 5f2c <fwp_main_thread+0x31c>
    5e7c:	f9008013 	str	x19, [x0, #256]
    5e80:	f90012b3 	str	x19, [x21, #32]
    5e84:	97fff690 	bl	38c4 <fwp_block>
    5e88:	97fff622 	bl	3710 <fwp_free_zombie>
    5e8c:	f9412aa0 	ldr	x0, [x21, #592]
    5e90:	b40005c0 	cbz	x0, 5f48 <fwp_main_thread+0x338>
    5e94:	f94156b3 	ldr	x19, [x21, #680]
    5e98:	17fffff2 	b	5e60 <fwp_main_thread+0x250>
    5e9c:	97fff0b1 	bl	2160 <fwp_now_ns>
    5ea0:	f94032a1 	ldr	x1, [x21, #96]
    5ea4:	eb01001f 	cmp	x0, x1
    5ea8:	54000faa 	b.ge	609c <fwp_main_thread+0x48c>  // b.tcont
    5eac:	394146a0 	ldrb	w0, [x21, #81]
    5eb0:	39414a62 	ldrb	w2, [x19, #82]
    5eb4:	3707f4e0 	tbnz	w0, #0, 5d50 <fwp_main_thread+0x140>
    5eb8:	f94032a1 	ldr	x1, [x21, #96]
    5ebc:	370001c2 	tbnz	w2, #0, 5ef4 <fwp_main_thread+0x2e4>
    5ec0:	f9403260 	ldr	x0, [x19, #96]
    5ec4:	b4000180 	cbz	x0, 5ef4 <fwp_main_thread+0x2e4>
    5ec8:	b4000061 	cbz	x1, 5ed4 <fwp_main_thread+0x2c4>
    5ecc:	eb01001f 	cmp	x0, x1
    5ed0:	9a81d000 	csel	x0, x0, x1, le
    5ed4:	f94022a1 	ldr	x1, [x21, #64]
    5ed8:	a911fe77 	stp	x23, xzr, [x19, #280]
    5edc:	f9009661 	str	x1, [x19, #296]
    5ee0:	b40040e1 	cbz	x1, 66fc <fwp_main_thread+0xaec>
    5ee4:	f9009033 	str	x19, [x1, #288]
    5ee8:	aa0003e1 	mov	x1, x0
    5eec:	f90022b3 	str	x19, [x21, #64]
    5ef0:	17ffffa1 	b	5d74 <fwp_main_thread+0x164>
    5ef4:	f94022a0 	ldr	x0, [x21, #64]
    5ef8:	17ffff99 	b	5d5c <fwp_main_thread+0x14c>
    5efc:	aa0203f3 	mov	x19, x2
    5f00:	17ffff8d 	b	5d34 <fwp_main_thread+0x124>
    5f04:	a911fe77 	stp	x23, xzr, [x19, #280]
    5f08:	f9009660 	str	x0, [x19, #296]
    5f0c:	b4000040 	cbz	x0, 5f14 <fwp_main_thread+0x304>
    5f10:	f9009013 	str	x19, [x0, #288]
    5f14:	f90022b3 	str	x19, [x21, #64]
    5f18:	17ffff9e 	b	5d90 <fwp_main_thread+0x180>
    5f1c:	f9000040 	str	x0, [x2]
    5f20:	17ffffa4 	b	5db0 <fwp_main_thread+0x1a0>
    5f24:	f9001ac0 	str	x0, [x22, #48]
    5f28:	17ffffad 	b	5ddc <fwp_main_thread+0x1cc>
    5f2c:	f90016b3 	str	x19, [x21, #40]
    5f30:	17ffffd4 	b	5e80 <fwp_main_thread+0x270>
    5f34:	f9413ec0 	ldr	x0, [x22, #632]
    5f38:	b4000be0 	cbz	x0, 60b4 <fwp_main_thread+0x4a4>
    5f3c:	f94156c0 	ldr	x0, [x22, #680]
    5f40:	b902a2df 	str	wzr, [x22, #672]
    5f44:	b5000d60 	cbnz	x0, 60f0 <fwp_main_thread+0x4e0>
    5f48:	9100c295 	add	x21, x20, #0x30
    5f4c:	97fff5f1 	bl	3710 <fwp_free_zombie>
    5f50:	f94016a0 	ldr	x0, [x21, #40]
    5f54:	b5000ce0 	cbnz	x0, 60f0 <fwp_main_thread+0x4e0>
    5f58:	f9401aa0 	ldr	x0, [x21, #48]
    5f5c:	b5000ca0 	cbnz	x0, 60f0 <fwp_main_thread+0x4e0>
    5f60:	b94042b3 	ldr	w19, [x21, #64]
    5f64:	340001d3 	cbz	w19, 5f9c <fwp_main_thread+0x38c>
    5f68:	93407e76 	sxtw	x22, w19
    5f6c:	51000673 	sub	w19, w19, #0x1
    5f70:	d1000ad6 	sub	x22, x22, #0x2
    5f74:	910142b7 	add	x23, x21, #0x50
    5f78:	cb3342d6 	sub	x22, x22, w19, uxtw
    5f7c:	93407e73 	sxtw	x19, w19
    5f80:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    5f84:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    5f88:	b90042b3 	str	w19, [x21, #64]
    5f8c:	d1000673 	sub	x19, x19, #0x1
    5f90:	97ffeda0 	bl	1610 <munmap@plt>
    5f94:	eb1302df 	cmp	x22, x19
    5f98:	54ffff41 	b.ne	5f80 <fwp_main_thread+0x370>  // b.any
    5f9c:	f00000d3 	adrp	x19, 20000 <__data_start>
    5fa0:	b9401260 	ldr	w0, [x19, #16]
    5fa4:	37f80040 	tbnz	w0, #31, 5fac <fwp_main_thread+0x39c>
    5fa8:	97ffed56 	bl	1500 <close@plt>
    5fac:	9100c280 	add	x0, x20, #0x30
    5fb0:	12800001 	mov	w1, #0xffffffff            	// #-1
    5fb4:	b9001261 	str	w1, [x19, #16]
    5fb8:	d2800013 	mov	x19, #0x0                   	// #0
    5fbc:	f9415816 	ldr	x22, [x0, #688]
    5fc0:	f9415c15 	ldr	x21, [x0, #696]
    5fc4:	b4000176 	cbz	x22, 5ff0 <fwp_main_thread+0x3e0>
    5fc8:	f8737aa0 	ldr	x0, [x21, x19, lsl #3]
    5fcc:	b40000c0 	cbz	x0, 5fe4 <fwp_main_thread+0x3d4>
    5fd0:	f9400001 	ldr	x1, [x0]
    5fd4:	b50008e1 	cbnz	x1, 60f0 <fwp_main_thread+0x4e0>
    5fd8:	f9400401 	ldr	x1, [x0, #8]
    5fdc:	b50008a1 	cbnz	x1, 60f0 <fwp_main_thread+0x4e0>
    5fe0:	97fff3fc 	bl	2fd0 <fwp_mem_free>
    5fe4:	91000673 	add	x19, x19, #0x1
    5fe8:	eb16027f 	cmp	x19, x22
    5fec:	54fffee1 	b.ne	5fc8 <fwp_main_thread+0x3b8>  // b.any
    5ff0:	aa1503e0 	mov	x0, x21
    5ff4:	97fff3f7 	bl	2fd0 <fwp_mem_free>
    5ff8:	9100c280 	add	x0, x20, #0x30
    5ffc:	f9415413 	ldr	x19, [x0, #680]
    6000:	f901581f 	str	xzr, [x0, #688]
    6004:	f9015c1f 	str	xzr, [x0, #696]
    6008:	b40001f3 	cbz	x19, 6044 <fwp_main_thread+0x434>
    600c:	f9401661 	ldr	x1, [x19, #40]
    6010:	b5000701 	cbnz	x1, 60f0 <fwp_main_thread+0x4e0>
    6014:	f9405661 	ldr	x1, [x19, #168]
    6018:	b50006c1 	cbnz	x1, 60f0 <fwp_main_thread+0x4e0>
    601c:	f9413c01 	ldr	x1, [x0, #632]
    6020:	b5000681 	cbnz	x1, 60f0 <fwp_main_thread+0x4e0>
    6024:	f9414400 	ldr	x0, [x0, #648]
    6028:	b5000640 	cbnz	x0, 60f0 <fwp_main_thread+0x4e0>
    602c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    6030:	d0000140 	adrp	x0, 30000 <alt.4+0xfd10>
    6034:	910bc000 	add	x0, x0, #0x2f0
    6038:	97ffed22 	bl	14c0 <memset@plt>
    603c:	aa1303e0 	mov	x0, x19
    6040:	97fff3e4 	bl	2fd0 <fwp_mem_free>
    6044:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    6048:	f947ec00 	ldr	x0, [x0, #4056]
    604c:	9100c294 	add	x20, x20, #0x30
    6050:	f9400000 	ldr	x0, [x0]
    6054:	f900069f 	str	xzr, [x20, #8]
    6058:	f901569f 	str	xzr, [x20, #680]
    605c:	97ffed71 	bl	1620 <fflush@plt>
    6060:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x16b00>
    6064:	f947f400 	ldr	x0, [x0, #4072]
    6068:	f9408fe2 	ldr	x2, [sp, #280]
    606c:	f9400001 	ldr	x1, [x0]
    6070:	eb010042 	subs	x2, x2, x1
    6074:	d2800001 	mov	x1, #0x0                   	// #0
    6078:	54003901 	b.ne	6798 <fwp_main_thread+0xb88>  // b.any
    607c:	a9527bfd 	ldp	x29, x30, [sp, #288]
    6080:	d2800000 	mov	x0, #0x0                   	// #0
    6084:	a95353f3 	ldp	x19, x20, [sp, #304]
    6088:	a9545bf5 	ldp	x21, x22, [sp, #320]
    608c:	a95563f7 	ldp	x23, x24, [sp, #336]
    6090:	a95773fb 	ldp	x27, x28, [sp, #368]
    6094:	910603ff 	add	sp, sp, #0x180
    6098:	d65f03c0 	ret
    609c:	394142a0 	ldrb	w0, [x21, #80]
    60a0:	3707f060 	tbnz	w0, #0, 5eac <fwp_main_thread+0x29c>
    60a4:	aa1503e0 	mov	x0, x21
    60a8:	97ffefda 	bl	2010 <fwp_cancel_tree.part.0>
    60ac:	394146a0 	ldrb	w0, [x21, #81]
    60b0:	17ffff80 	b	5eb0 <fwp_main_thread+0x2a0>
    60b4:	d2800013 	mov	x19, #0x0                   	// #0
    60b8:	9100c295 	add	x21, x20, #0x30
    60bc:	f94146a0 	ldr	x0, [x21, #648]
    60c0:	b5ffea80 	cbnz	x0, 5e10 <fwp_main_thread+0x200>
    60c4:	f9413aa0 	ldr	x0, [x21, #624]
    60c8:	97fff3c2 	bl	2fd0 <fwp_mem_free>
    60cc:	f9013abf 	str	xzr, [x21, #624]
    60d0:	f90142bf 	str	xzr, [x21, #640]
    60d4:	f94156a0 	ldr	x0, [x21, #680]
    60d8:	b4003373 	cbz	x19, 6744 <fwp_main_thread+0xb34>
    60dc:	f900567f 	str	xzr, [x19, #168]
    60e0:	f9005e7f 	str	xzr, [x19, #184]
    60e4:	b902a2bf 	str	wzr, [x21, #672]
    60e8:	eb13001f 	cmp	x0, x19
    60ec:	54ffe9e0 	b.eq	5e28 <fwp_main_thread+0x218>  // b.none
    60f0:	a9166bf9 	stp	x25, x26, [sp, #352]
    60f4:	97ffed13 	bl	1540 <abort@plt>
    60f8:	f9413362 	ldr	x2, [x27, #608]
    60fc:	f0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    6100:	912d4021 	add	x1, x1, #0xb50
    6104:	f0000140 	adrp	x0, 31000 <fwp_root_context+0xd10>
    6108:	a90287e2 	stp	x2, x1, [sp, #40]
    610c:	91134017 	add	x23, x0, #0x4d0
    6110:	d2800013 	mov	x19, #0x0                   	// #0
    6114:	f94003e1 	ldr	x1, [sp]
    6118:	a9166bf9 	stp	x25, x26, [sp, #352]
    611c:	d0ffffe0 	adrp	x0, 4000 <f74+0xf0>
    6120:	d290001a 	mov	x26, #0x8000                	// #32768
    6124:	9128c000 	add	x0, x0, #0xa30
    6128:	d2800016 	mov	x22, #0x0                   	// #0
    612c:	52800039 	mov	w25, #0x1                   	// #1
    6130:	f9001fe1 	str	x1, [sp, #56]
    6134:	f90023ff 	str	xzr, [sp, #64]
    6138:	a90503ff 	stp	xzr, x0, [sp, #80]
    613c:	f901337c 	str	x28, [x27, #608]
    6140:	f100075b 	subs	x27, x26, #0x1
    6144:	aa1503e1 	mov	x1, x21
    6148:	da1f02d8 	sbc	x24, x22, xzr
    614c:	52800020 	mov	w0, #0x1                   	// #1
    6150:	f90027fb 	str	x27, [sp, #72]
    6154:	aa1b03fa 	mov	x26, x27
    6158:	a9084ffb 	stp	x27, x19, [sp, #128]
    615c:	97fff725 	bl	3df0 <fwp_data.part.0.constprop.0>
    6160:	aa0003f3 	mov	x19, x0
    6164:	f949dae1 	ldr	x1, [x23, #5040]
    6168:	aa1803f6 	mov	x22, x24
    616c:	f949eee0 	ldr	x0, [x23, #5080]
    6170:	cb010261 	sub	x1, x19, x1
    6174:	eb00403f 	cmp	x1, x0, lsl #16
    6178:	54000302 	b.cs	61d8 <fwp_main_thread+0x5c8>  // b.hs, b.nlast
    617c:	d350fc20 	lsr	x0, x1, #16
    6180:	f949fee5 	ldr	x5, [x23, #5112]
    6184:	8b000800 	add	x0, x0, x0, lsl #2
    6188:	d37df002 	lsl	x2, x0, #3
    618c:	8b0200a0 	add	x0, x5, x2
    6190:	f940101c 	ldr	x28, [x0, #32]
    6194:	b400023c 	cbz	x28, 61d8 <fwp_main_thread+0x5c8>
    6198:	386268a2 	ldrb	w2, [x5, x2]
    619c:	7100085f 	cmp	w2, #0x2
    61a0:	54002420 	b.eq	6624 <fwp_main_thread+0xa14>  // b.none
    61a4:	7100045f 	cmp	w2, #0x1
    61a8:	54000181 	b.ne	61d8 <fwp_main_thread+0x5c8>  // b.any
    61ac:	29430002 	ldp	w2, w0, [x0, #24]
    61b0:	92403c21 	and	x1, x1, #0xffff
    61b4:	9b027c21 	mul	x1, x1, x2
    61b8:	d360fc21 	lsr	x1, x1, #32
    61bc:	eb00003f 	cmp	x1, x0
    61c0:	540000c2 	b.cs	61d8 <fwp_main_thread+0x5c8>  // b.hs, b.nlast
    61c4:	8b01039c 	add	x28, x28, x1
    61c8:	39400380 	ldrb	w0, [x28]
    61cc:	7103fc1f 	cmp	w0, #0xff
    61d0:	54002340 	b.eq	6638 <fwp_main_thread+0xa28>  // b.none
    61d4:	39000399 	strb	w25, [x28]
    61d8:	f90023f3 	str	x19, [sp, #64]
    61dc:	aa18037b 	orr	x27, x27, x24
    61e0:	b5fffb1b 	cbnz	x27, 6140 <fwp_main_thread+0x530>
    61e4:	b0000000 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    61e8:	9100c282 	add	x2, x20, #0x30
    61ec:	f94017e3 	ldr	x3, [sp, #40]
    61f0:	910183e1 	add	x1, sp, #0x60
    61f4:	3dc10000 	ldr	q0, [x0, #1024]
    61f8:	52800020 	mov	w0, #0x1                   	// #1
    61fc:	f9013043 	str	x3, [x2, #608]
    6200:	3d801be0 	str	q0, [sp, #96]
    6204:	97fff6fb 	bl	3df0 <fwp_data.part.0.constprop.0>
    6208:	f0000141 	adrp	x1, 31000 <fwp_root_context+0xd10>
    620c:	91134023 	add	x3, x1, #0x4d0
    6210:	aa0003f6 	mov	x22, x0
    6214:	f949d861 	ldr	x1, [x3, #5040]
    6218:	f949ec60 	ldr	x0, [x3, #5080]
    621c:	cb0102c1 	sub	x1, x22, x1
    6220:	eb00403f 	cmp	x1, x0, lsl #16
    6224:	54000322 	b.cs	6288 <fwp_main_thread+0x678>  // b.hs, b.nlast
    6228:	d350fc22 	lsr	x2, x1, #16
    622c:	f949fc63 	ldr	x3, [x3, #5112]
    6230:	8b020842 	add	x2, x2, x2, lsl #2
    6234:	d37df042 	lsl	x2, x2, #3
    6238:	8b020060 	add	x0, x3, x2
    623c:	f9401017 	ldr	x23, [x0, #32]
    6240:	b4000257 	cbz	x23, 6288 <fwp_main_thread+0x678>
    6244:	38626862 	ldrb	w2, [x3, x2]
    6248:	7100085f 	cmp	w2, #0x2
    624c:	540025e0 	b.eq	6708 <fwp_main_thread+0xaf8>  // b.none
    6250:	7100045f 	cmp	w2, #0x1
    6254:	540001a1 	b.ne	6288 <fwp_main_thread+0x678>  // b.any
    6258:	29430002 	ldp	w2, w0, [x0, #24]
    625c:	92403c21 	and	x1, x1, #0xffff
    6260:	9b027c21 	mul	x1, x1, x2
    6264:	d360fc21 	lsr	x1, x1, #32
    6268:	eb00003f 	cmp	x1, x0
    626c:	540000e2 	b.cs	6288 <fwp_main_thread+0x678>  // b.hs, b.nlast
    6270:	8b0102f7 	add	x23, x23, x1
    6274:	394002e0 	ldrb	w0, [x23]
    6278:	7103fc1f 	cmp	w0, #0xff
    627c:	54002700 	b.eq	675c <fwp_main_thread+0xb4c>  // b.none
    6280:	52800020 	mov	w0, #0x1                   	// #1
    6284:	390002e0 	strb	w0, [x23]
    6288:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    628c:	aa1503e1 	mov	x1, x21
    6290:	52800020 	mov	w0, #0x1                   	// #1
    6294:	a9085be2 	stp	x2, x22, [sp, #128]
    6298:	97fff6d6 	bl	3df0 <fwp_data.part.0.constprop.0>
    629c:	f0000141 	adrp	x1, 31000 <fwp_root_context+0xd10>
    62a0:	91134023 	add	x3, x1, #0x4d0
    62a4:	aa0003f5 	mov	x21, x0
    62a8:	f949d861 	ldr	x1, [x3, #5040]
    62ac:	f949ec60 	ldr	x0, [x3, #5080]
    62b0:	cb0102a1 	sub	x1, x21, x1
    62b4:	eb00403f 	cmp	x1, x0, lsl #16
    62b8:	54000322 	b.cs	631c <fwp_main_thread+0x70c>  // b.hs, b.nlast
    62bc:	d350fc22 	lsr	x2, x1, #16
    62c0:	f949fc63 	ldr	x3, [x3, #5112]
    62c4:	8b020842 	add	x2, x2, x2, lsl #2
    62c8:	d37df042 	lsl	x2, x2, #3
    62cc:	8b020060 	add	x0, x3, x2
    62d0:	f9401016 	ldr	x22, [x0, #32]
    62d4:	b4000256 	cbz	x22, 631c <fwp_main_thread+0x70c>
    62d8:	38626862 	ldrb	w2, [x3, x2]
    62dc:	7100085f 	cmp	w2, #0x2
    62e0:	54002200 	b.eq	6720 <fwp_main_thread+0xb10>  // b.none
    62e4:	7100045f 	cmp	w2, #0x1
    62e8:	540001a1 	b.ne	631c <fwp_main_thread+0x70c>  // b.any
    62ec:	29430002 	ldp	w2, w0, [x0, #24]
    62f0:	92403c21 	and	x1, x1, #0xffff
    62f4:	9b027c21 	mul	x1, x1, x2
    62f8:	d360fc21 	lsr	x1, x1, #32
    62fc:	eb00003f 	cmp	x1, x0
    6300:	540000e2 	b.cs	631c <fwp_main_thread+0x70c>  // b.hs, b.nlast
    6304:	8b0102d6 	add	x22, x22, x1
    6308:	394002c0 	ldrb	w0, [x22]
    630c:	7103fc1f 	cmp	w0, #0xff
    6310:	540022c0 	b.eq	6768 <fwp_main_thread+0xb58>  // b.none
    6314:	52800020 	mov	w0, #0x1                   	// #1
    6318:	390002c0 	strb	w0, [x22]
    631c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6320:	9101c3e1 	add	x1, sp, #0x70
    6324:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6328:	52800020 	mov	w0, #0x1                   	// #1
    632c:	a90757e2 	stp	x2, x21, [sp, #112]
    6330:	97fff6b0 	bl	3df0 <fwp_data.part.0.constprop.0>
    6334:	f0000141 	adrp	x1, 31000 <fwp_root_context+0xd10>
    6338:	91134022 	add	x2, x1, #0x4d0
    633c:	aa0003f7 	mov	x23, x0
    6340:	f949d841 	ldr	x1, [x2, #5040]
    6344:	f949ec40 	ldr	x0, [x2, #5080]
    6348:	cb0102e1 	sub	x1, x23, x1
    634c:	eb00403f 	cmp	x1, x0, lsl #16
    6350:	54000322 	b.cs	63b4 <fwp_main_thread+0x7a4>  // b.hs, b.nlast
    6354:	d350fc20 	lsr	x0, x1, #16
    6358:	f949fc43 	ldr	x3, [x2, #5112]
    635c:	8b000800 	add	x0, x0, x0, lsl #2
    6360:	d37df002 	lsl	x2, x0, #3
    6364:	8b020060 	add	x0, x3, x2
    6368:	f9401015 	ldr	x21, [x0, #32]
    636c:	b4000255 	cbz	x21, 63b4 <fwp_main_thread+0x7a4>
    6370:	38626862 	ldrb	w2, [x3, x2]
    6374:	7100085f 	cmp	w2, #0x2
    6378:	54001ce0 	b.eq	6714 <fwp_main_thread+0xb04>  // b.none
    637c:	7100045f 	cmp	w2, #0x1
    6380:	540001a1 	b.ne	63b4 <fwp_main_thread+0x7a4>  // b.any
    6384:	29430002 	ldp	w2, w0, [x0, #24]
    6388:	92403c21 	and	x1, x1, #0xffff
    638c:	9b027c21 	mul	x1, x1, x2
    6390:	d360fc21 	lsr	x1, x1, #32
    6394:	eb00003f 	cmp	x1, x0
    6398:	540000e2 	b.cs	63b4 <fwp_main_thread+0x7a4>  // b.hs, b.nlast
    639c:	8b0102b5 	add	x21, x21, x1
    63a0:	394002a0 	ldrb	w0, [x21]
    63a4:	7103fc1f 	cmp	w0, #0xff
    63a8:	54001d40 	b.eq	6750 <fwp_main_thread+0xb40>  // b.none
    63ac:	52800020 	mov	w0, #0x1                   	// #1
    63b0:	390002a0 	strb	w0, [x21]
    63b4:	aa1303f6 	mov	x22, x19
    63b8:	b00000da 	adrp	x26, 1f000 <__FRAME_END__+0x16b00>
    63bc:	b40015d3 	cbz	x19, 6674 <fwp_main_thread+0xa64>
    63c0:	912ae35a 	add	x26, x26, #0xab8
    63c4:	b000001b 	adrp	x27, 7000 <_IO_stdin_used+0x140>
    63c8:	91014340 	add	x0, x26, #0x50
    63cc:	f90007e0 	str	x0, [sp, #8]
    63d0:	91068360 	add	x0, x27, #0x1a0
    63d4:	f9000be0 	str	x0, [sp, #16]
    63d8:	f0000140 	adrp	x0, 31000 <fwp_root_context+0xd10>
    63dc:	9113401c 	add	x28, x0, #0x4d0
    63e0:	1400004a 	b	6508 <fwp_main_thread+0x8f8>
    63e4:	f940034a 	ldr	x10, [x26]
    63e8:	aa1a03e0 	mov	x0, x26
    63ec:	52800001 	mov	w1, #0x0                   	// #0
    63f0:	f9000fe8 	str	x8, [sp, #24]
    63f4:	aa2a03ea 	mvn	x10, x10
    63f8:	f901e0ca 	str	x10, [x6, #960]
    63fc:	97ffec31 	bl	14c0 <memset@plt>
    6400:	f9400fe8 	ldr	x8, [sp, #24]
    6404:	f94a1380 	ldr	x0, [x28, #5152]
    6408:	ab080000 	adds	x0, x0, x8
    640c:	54001be2 	b.cs	6788 <fwp_main_thread+0xb78>  // b.hs, b.nlast
    6410:	f94a1781 	ldr	x1, [x28, #5160]
    6414:	f90a1380 	str	x0, [x28, #5152]
    6418:	eb01001f 	cmp	x0, x1
    641c:	54000049 	b.ls	6424 <fwp_main_thread+0x814>  // b.plast
    6420:	f90a1780 	str	x0, [x28, #5160]
    6424:	1e630361 	ucvtf	d1, w27
    6428:	fd4a1f80 	ldr	d0, [x28, #5176]
    642c:	1e612800 	fadd	d0, d0, d1
    6430:	fd0a1f80 	str	d0, [x28, #5176]
    6434:	aa1a03fb 	mov	x27, x26
    6438:	aa1803e1 	mov	x1, x24
    643c:	aa1903e2 	mov	x2, x25
    6440:	f8008779 	str	x25, [x27], #8
    6444:	aa1b03e0 	mov	x0, x27
    6448:	97ffebc2 	bl	1350 <memcpy@plt>
    644c:	8b190343 	add	x3, x26, x25
    6450:	3900207f 	strb	wzr, [x3, #8]
    6454:	f94023e0 	ldr	x0, [sp, #64]
    6458:	97ffec56 	bl	15b0 <free@plt>
    645c:	f949db81 	ldr	x1, [x28, #5040]
    6460:	f949ef80 	ldr	x0, [x28, #5080]
    6464:	cb010341 	sub	x1, x26, x1
    6468:	eb00403f 	cmp	x1, x0, lsl #16
    646c:	54000322 	b.cs	64d0 <fwp_main_thread+0x8c0>  // b.hs, b.nlast
    6470:	d350fc20 	lsr	x0, x1, #16
    6474:	f949ff87 	ldr	x7, [x28, #5112]
    6478:	8b000800 	add	x0, x0, x0, lsl #2
    647c:	d37df002 	lsl	x2, x0, #3
    6480:	8b0200e3 	add	x3, x7, x2
    6484:	f9401060 	ldr	x0, [x3, #32]
    6488:	b4000240 	cbz	x0, 64d0 <fwp_main_thread+0x8c0>
    648c:	386268e2 	ldrb	w2, [x7, x2]
    6490:	7100085f 	cmp	w2, #0x2
    6494:	54000e40 	b.eq	665c <fwp_main_thread+0xa4c>  // b.none
    6498:	7100045f 	cmp	w2, #0x1
    649c:	540001a1 	b.ne	64d0 <fwp_main_thread+0x8c0>  // b.any
    64a0:	29430867 	ldp	w7, w2, [x3, #24]
    64a4:	92403c21 	and	x1, x1, #0xffff
    64a8:	9b077c21 	mul	x1, x1, x7
    64ac:	d360fc21 	lsr	x1, x1, #32
    64b0:	eb02003f 	cmp	x1, x2
    64b4:	540000e2 	b.cs	64d0 <fwp_main_thread+0x8c0>  // b.hs, b.nlast
    64b8:	8b010000 	add	x0, x0, x1
    64bc:	39400001 	ldrb	w1, [x0]
    64c0:	7103fc3f 	cmp	w1, #0xff
    64c4:	54001340 	b.eq	672c <fwp_main_thread+0xb1c>  // b.none
    64c8:	52800021 	mov	w1, #0x1                   	// #1
    64cc:	39000001 	strb	w1, [x0]
    64d0:	aa1503e0 	mov	x0, x21
    64d4:	97fff8e3 	bl	4860 <fwp_drop0>
    64d8:	f9400342 	ldr	x2, [x26]
    64dc:	d2800021 	mov	x1, #0x1                   	// #1
    64e0:	f9401a83 	ldr	x3, [x20, #48]
    64e4:	aa1b03e0 	mov	x0, x27
    64e8:	97ffec42 	bl	15f0 <fwrite@plt>
    64ec:	f9401a81 	ldr	x1, [x20, #48]
    64f0:	52800140 	mov	w0, #0xa                   	// #10
    64f4:	97ffebc7 	bl	1410 <fputc@plt>
    64f8:	aa1a03e0 	mov	x0, x26
    64fc:	97fff739 	bl	41e0 <fwp_drop4>
    6500:	f9400ad6 	ldr	x22, [x22, #16]
    6504:	b4000b96 	cbz	x22, 6674 <fwp_main_thread+0xa64>
    6508:	f949db81 	ldr	x1, [x28, #5040]
    650c:	f949ef80 	ldr	x0, [x28, #5080]
    6510:	cb0102e1 	sub	x1, x23, x1
    6514:	eb00403f 	cmp	x1, x0, lsl #16
    6518:	54000342 	b.cs	6580 <fwp_main_thread+0x970>  // b.hs, b.nlast
    651c:	d350fc20 	lsr	x0, x1, #16
    6520:	f949ff85 	ldr	x5, [x28, #5112]
    6524:	8b000800 	add	x0, x0, x0, lsl #2
    6528:	d37df002 	lsl	x2, x0, #3
    652c:	8b0200a3 	add	x3, x5, x2
    6530:	f9401060 	ldr	x0, [x3, #32]
    6534:	b4000260 	cbz	x0, 6580 <fwp_main_thread+0x970>
    6538:	386268a2 	ldrb	w2, [x5, x2]
    653c:	7100085f 	cmp	w2, #0x2
    6540:	54000940 	b.eq	6668 <fwp_main_thread+0xa58>  // b.none
    6544:	7100045f 	cmp	w2, #0x1
    6548:	540001c1 	b.ne	6580 <fwp_main_thread+0x970>  // b.any
    654c:	29430865 	ldp	w5, w2, [x3, #24]
    6550:	92403c21 	and	x1, x1, #0xffff
    6554:	9b057c21 	mul	x1, x1, x5
    6558:	d360fc21 	lsr	x1, x1, #32
    655c:	eb02003f 	cmp	x1, x2
    6560:	54000102 	b.cs	6580 <fwp_main_thread+0x970>  // b.hs, b.nlast
    6564:	8b010000 	add	x0, x0, x1
    6568:	39400001 	ldrb	w1, [x0]
    656c:	340000a1 	cbz	w1, 6580 <fwp_main_thread+0x970>
    6570:	7103f43f 	cmp	w1, #0xfd
    6574:	54000e48 	b.hi	673c <fwp_main_thread+0xb2c>  // b.pmore
    6578:	11000421 	add	w1, w1, #0x1
    657c:	39000001 	strb	w1, [x0]
    6580:	aa1703e0 	mov	x0, x23
    6584:	97fff92c 	bl	4a34 <fwp_loop_fields68.constprop.0>
    6588:	aa0003e1 	mov	x1, x0
    658c:	aa0003f5 	mov	x21, x0
    6590:	a9400be0 	ldp	x0, x2, [sp]
    6594:	52800023 	mov	w3, #0x1                   	// #1
    6598:	a9047fff 	stp	xzr, xzr, [sp, #64]
    659c:	f9002bff 	str	xzr, [sp, #80]
    65a0:	97fff9a0 	bl	4c20 <fwp_write>
    65a4:	a94467f8 	ldp	x24, x25, [sp, #64]
    65a8:	f9400be0 	ldr	x0, [sp, #16]
    65ac:	f100031f 	cmp	x24, #0x0
    65b0:	9a980018 	csel	x24, x0, x24, eq	// eq = none
    65b4:	b1002b3f 	cmn	x25, #0xa
    65b8:	54000ea8 	b.hi	678c <fwp_main_thread+0xb7c>  // b.pmore
    65bc:	b953a780 	ldr	w0, [x28, #5028]
    65c0:	91002722 	add	x2, x25, #0x9
    65c4:	f140105f 	cmp	x2, #0x4, lsl #12
    65c8:	7a409804 	ccmp	w0, #0x0, #0x4, ls	// ls = plast
    65cc:	54000220 	b.eq	6610 <fwp_main_thread+0xa00>  // b.none
    65d0:	91006321 	add	x1, x25, #0x18
    65d4:	8b411381 	add	x1, x28, x1, lsr #4
    65d8:	397e8021 	ldrb	w1, [x1, #4000]
    65dc:	910f0020 	add	x0, x1, #0x3c0
    65e0:	8b010421 	add	x1, x1, x1, lsl #1
    65e4:	8b010f86 	add	x6, x28, x1, lsl #3
    65e8:	b8607b9b 	ldr	w27, [x28, x0, lsl #2]
    65ec:	2a1b03e8 	mov	w8, w27
    65f0:	f941e0da 	ldr	x26, [x6, #960]
    65f4:	b5ffef9a 	cbnz	x26, 63e4 <fwp_main_thread+0x7d4>
    65f8:	f941e4da 	ldr	x26, [x6, #968]
    65fc:	b40000ba 	cbz	x26, 6610 <fwp_main_thread+0xa00>
    6600:	f941e8c0 	ldr	x0, [x6, #976]
    6604:	cb1a0000 	sub	x0, x0, x26
    6608:	eb00011f 	cmp	x8, x0
    660c:	54000489 	b.ls	669c <fwp_main_thread+0xa8c>  // b.plast
    6610:	aa0203e0 	mov	x0, x2
    6614:	52800021 	mov	w1, #0x1                   	// #1
    6618:	97fff336 	bl	32f0 <fwp_heap_alloc_slow>
    661c:	aa0003fa 	mov	x26, x0
    6620:	17ffff85 	b	6434 <fwp_main_thread+0x824>
    6624:	72003c3f 	tst	w1, #0xffff
    6628:	54ffdd81 	b.ne	61d8 <fwp_main_thread+0x5c8>  // b.any
    662c:	39400380 	ldrb	w0, [x28]
    6630:	7103fc1f 	cmp	w0, #0xff
    6634:	54ffdd01 	b.ne	61d4 <fwp_main_thread+0x5c4>  // b.any
    6638:	aa1c03e0 	mov	x0, x28
    663c:	97fff1c5 	bl	2d50 <fwp_rc_forget_slot>
    6640:	17fffee5 	b	61d4 <fwp_main_thread+0x5c4>
    6644:	90ffffe0 	adrp	x0, 2000 <buf_put+0x50>
    6648:	91184000 	add	x0, x0, #0x610
    664c:	94000211 	bl	6e90 <atexit>
    6650:	17fffd83 	b	5c5c <fwp_main_thread+0x4c>
    6654:	97fff048 	bl	2774 <fwp_heap_init>
    6658:	17fffd7d 	b	5c4c <fwp_main_thread+0x3c>
    665c:	72003c3f 	tst	w1, #0xffff
    6660:	54fff381 	b.ne	64d0 <fwp_main_thread+0x8c0>  // b.any
    6664:	17ffff96 	b	64bc <fwp_main_thread+0x8ac>
    6668:	72003c3f 	tst	w1, #0xffff
    666c:	54fff8a1 	b.ne	6580 <fwp_main_thread+0x970>  // b.any
    6670:	17ffffbe 	b	6568 <fwp_main_thread+0x958>
    6674:	aa1703e0 	mov	x0, x23
    6678:	97fff87a 	bl	4860 <fwp_drop0>
    667c:	aa1303e0 	mov	x0, x19
    6680:	97fff878 	bl	4860 <fwp_drop0>
    6684:	9100c280 	add	x0, x20, #0x30
    6688:	52800021 	mov	w1, #0x1                   	// #1
    668c:	a9566bf9 	ldp	x25, x26, [sp, #352]
    6690:	b9029401 	str	w1, [x0, #660]
    6694:	f9014c1f 	str	xzr, [x0, #664]
    6698:	17fffd9e 	b	5d10 <fwp_main_thread+0x100>
    669c:	8b080340 	add	x0, x26, x8
    66a0:	52800001 	mov	w1, #0x0                   	// #0
    66a4:	f9000fe8 	str	x8, [sp, #24]
    66a8:	f901e4c0 	str	x0, [x6, #968]
    66ac:	aa1a03e0 	mov	x0, x26
    66b0:	97ffeb84 	bl	14c0 <memset@plt>
    66b4:	f9400fe8 	ldr	x8, [sp, #24]
    66b8:	f94a1380 	ldr	x0, [x28, #5152]
    66bc:	ab080000 	adds	x0, x0, x8
    66c0:	54000642 	b.cs	6788 <fwp_main_thread+0xb78>  // b.hs, b.nlast
    66c4:	f0000141 	adrp	x1, 31000 <fwp_root_context+0xd10>
    66c8:	91134021 	add	x1, x1, #0x4d0
    66cc:	f94a1422 	ldr	x2, [x1, #5160]
    66d0:	f90a1020 	str	x0, [x1, #5152]
    66d4:	eb02001f 	cmp	x0, x2
    66d8:	54000049 	b.ls	66e0 <fwp_main_thread+0xad0>  // b.plast
    66dc:	f90a1420 	str	x0, [x1, #5160]
    66e0:	f0000140 	adrp	x0, 31000 <fwp_root_context+0xd10>
    66e4:	91134000 	add	x0, x0, #0x4d0
    66e8:	1e630361 	ucvtf	d1, w27
    66ec:	fd4a1c00 	ldr	d0, [x0, #5176]
    66f0:	1e612800 	fadd	d0, d0, d1
    66f4:	fd0a1c00 	str	d0, [x0, #5176]
    66f8:	17ffff4f 	b	6434 <fwp_main_thread+0x824>
    66fc:	aa0003e1 	mov	x1, x0
    6700:	f90022b3 	str	x19, [x21, #64]
    6704:	17fffd9c 	b	5d74 <fwp_main_thread+0x164>
    6708:	72003c3f 	tst	w1, #0xffff
    670c:	54ffdbe1 	b.ne	6288 <fwp_main_thread+0x678>  // b.any
    6710:	17fffed9 	b	6274 <fwp_main_thread+0x664>
    6714:	72003c3f 	tst	w1, #0xffff
    6718:	54ffe4e1 	b.ne	63b4 <fwp_main_thread+0x7a4>  // b.any
    671c:	17ffff21 	b	63a0 <fwp_main_thread+0x790>
    6720:	72003c3f 	tst	w1, #0xffff
    6724:	54ffdfc1 	b.ne	631c <fwp_main_thread+0x70c>  // b.any
    6728:	17fffef8 	b	6308 <fwp_main_thread+0x6f8>
    672c:	f9000fe0 	str	x0, [sp, #24]
    6730:	97fff188 	bl	2d50 <fwp_rc_forget_slot>
    6734:	f9400fe0 	ldr	x0, [sp, #24]
    6738:	17ffff64 	b	64c8 <fwp_main_thread+0x8b8>
    673c:	97fff13e 	bl	2c34 <fwp_rc_wide_dup>
    6740:	17ffff90 	b	6580 <fwp_main_thread+0x970>
    6744:	b902a2bf 	str	wzr, [x21, #672]
    6748:	b4ffc000 	cbz	x0, 5f48 <fwp_main_thread+0x338>
    674c:	17fffe69 	b	60f0 <fwp_main_thread+0x4e0>
    6750:	aa1503e0 	mov	x0, x21
    6754:	97fff17f 	bl	2d50 <fwp_rc_forget_slot>
    6758:	17ffff15 	b	63ac <fwp_main_thread+0x79c>
    675c:	aa1703e0 	mov	x0, x23
    6760:	97fff17c 	bl	2d50 <fwp_rc_forget_slot>
    6764:	17fffec7 	b	6280 <fwp_main_thread+0x670>
    6768:	aa1603e0 	mov	x0, x22
    676c:	97fff179 	bl	2d50 <fwp_rc_forget_slot>
    6770:	17fffee9 	b	6314 <fwp_main_thread+0x704>
    6774:	b0000000 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    6778:	9108e000 	add	x0, x0, #0x238
    677c:	a91563f7 	stp	x23, x24, [sp, #336]
    6780:	a9166bf9 	stp	x25, x26, [sp, #352]
    6784:	97ffee67 	bl	2120 <fwp_trap>
    6788:	97ffed22 	bl	1c10 <fwp_heap_oom>
    678c:	b0000000 	adrp	x0, 7000 <_IO_stdin_used+0x140>
    6790:	91098000 	add	x0, x0, #0x260
    6794:	97ffee63 	bl	2120 <fwp_trap>
    6798:	a9166bf9 	stp	x25, x26, [sp, #352]
    679c:	97ffeb55 	bl	14f0 <__stack_chk_fail@plt>

00000000000067a0 <__divti3>:
    67a0:	d503245f 	bti	c
    67a4:	d2800004 	mov	x4, #0x0                   	// #0
    67a8:	b7f80721 	tbnz	x1, #63, 688c <__divti3+0xec>
    67ac:	b6f80083 	tbz	x3, #63, 67bc <__divti3+0x1c>
    67b0:	eb0203e2 	negs	x2, x2
    67b4:	aa2403e4 	mvn	x4, x4
    67b8:	da0303e3 	ngc	x3, x3
    67bc:	aa0203e6 	mov	x6, x2
    67c0:	aa0003e7 	mov	x7, x0
    67c4:	aa0103e5 	mov	x5, x1
    67c8:	b5000583 	cbnz	x3, 6878 <__divti3+0xd8>
    67cc:	eb01005f 	cmp	x2, x1
    67d0:	54000e69 	b.ls	699c <__divti3+0x1fc>  // b.plast
    67d4:	dac01040 	clz	x0, x2
    67d8:	b40000e0 	cbz	x0, 67f4 <__divti3+0x54>
    67dc:	4b0003e1 	neg	w1, w0
    67e0:	9ac020a5 	lsl	x5, x5, x0
    67e4:	9ac02046 	lsl	x6, x2, x0
    67e8:	9ac124e1 	lsr	x1, x7, x1
    67ec:	aa050025 	orr	x5, x1, x5
    67f0:	9ac020e7 	lsl	x7, x7, x0
    67f4:	d360fcc8 	lsr	x8, x6, #32
    67f8:	92407cc2 	and	x2, x6, #0xffffffff
    67fc:	9ac808a3 	udiv	x3, x5, x8
    6800:	9b089465 	msub	x5, x3, x8, x5
    6804:	aa0303e0 	mov	x0, x3
    6808:	9b037c41 	mul	x1, x2, x3
    680c:	93c780a5 	extr	x5, x5, x7, #32
    6810:	eb05003f 	cmp	x1, x5
    6814:	540000a9 	b.ls	6828 <__divti3+0x88>  // b.plast
    6818:	ab0500c5 	adds	x5, x6, x5
    681c:	d1000460 	sub	x0, x3, #0x1
    6820:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    6824:	540015a8 	b.hi	6ad8 <__divti3+0x338>  // b.pmore
    6828:	cb0100a5 	sub	x5, x5, x1
    682c:	9ac808a3 	udiv	x3, x5, x8
    6830:	9b089465 	msub	x5, x3, x8, x5
    6834:	aa0303e1 	mov	x1, x3
    6838:	9b037c42 	mul	x2, x2, x3
    683c:	aa0703e3 	mov	x3, x7
    6840:	b3607ca3 	bfi	x3, x5, #32, #32
    6844:	eb03005f 	cmp	x2, x3
    6848:	540000c9 	b.ls	6860 <__divti3+0xc0>  // b.plast
    684c:	ab0300c3 	adds	x3, x6, x3
    6850:	d1000425 	sub	x5, x1, #0x1
    6854:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    6858:	d1000821 	sub	x1, x1, #0x2
    685c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    6860:	aa008020 	orr	x0, x1, x0, lsl #32
    6864:	d2800001 	mov	x1, #0x0                   	// #0
    6868:	b4000064 	cbz	x4, 6874 <__divti3+0xd4>
    686c:	eb0003e0 	negs	x0, x0
    6870:	da0103e1 	ngc	x1, x1
    6874:	d65f03c0 	ret
    6878:	eb01007f 	cmp	x3, x1
    687c:	54000109 	b.ls	689c <__divti3+0xfc>  // b.plast
    6880:	d2800001 	mov	x1, #0x0                   	// #0
    6884:	d2800000 	mov	x0, #0x0                   	// #0
    6888:	17fffff8 	b	6868 <__divti3+0xc8>
    688c:	eb0003e0 	negs	x0, x0
    6890:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    6894:	da0103e1 	ngc	x1, x1
    6898:	17ffffc5 	b	67ac <__divti3+0xc>
    689c:	dac01067 	clz	x7, x3
    68a0:	b40010e7 	cbz	x7, 6abc <__divti3+0x31c>
    68a4:	d2800805 	mov	x5, #0x40                  	// #64
    68a8:	cb0700a5 	sub	x5, x5, x7
    68ac:	9ac72063 	lsl	x3, x3, x7
    68b0:	9ac52448 	lsr	x8, x2, x5
    68b4:	aa030108 	orr	x8, x8, x3
    68b8:	9ac52426 	lsr	x6, x1, x5
    68bc:	92407d0a 	and	x10, x8, #0xffffffff
    68c0:	d360fd09 	lsr	x9, x8, #32
    68c4:	9ac52403 	lsr	x3, x0, x5
    68c8:	9ac72021 	lsl	x1, x1, x7
    68cc:	aa010063 	orr	x3, x3, x1
    68d0:	9ac72042 	lsl	x2, x2, x7
    68d4:	9ac908cb 	udiv	x11, x6, x9
    68d8:	9b099965 	msub	x5, x11, x9, x6
    68dc:	aa0b03e1 	mov	x1, x11
    68e0:	9b0b7d46 	mul	x6, x10, x11
    68e4:	93c380a5 	extr	x5, x5, x3, #32
    68e8:	eb0500df 	cmp	x6, x5
    68ec:	540000a9 	b.ls	6900 <__divti3+0x160>  // b.plast
    68f0:	ab050105 	adds	x5, x8, x5
    68f4:	d1000561 	sub	x1, x11, #0x1
    68f8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    68fc:	54000f48 	b.hi	6ae4 <__divti3+0x344>  // b.pmore
    6900:	cb0600a6 	sub	x6, x5, x6
    6904:	9ac908cb 	udiv	x11, x6, x9
    6908:	9b099969 	msub	x9, x11, x9, x6
    690c:	aa0b03e5 	mov	x5, x11
    6910:	9b0b7d4a 	mul	x10, x10, x11
    6914:	b3607d23 	bfi	x3, x9, #32, #32
    6918:	eb03015f 	cmp	x10, x3
    691c:	540000a9 	b.ls	6930 <__divti3+0x190>  // b.plast
    6920:	ab030103 	adds	x3, x8, x3
    6924:	d1000565 	sub	x5, x11, #0x1
    6928:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    692c:	54000e28 	b.hi	6af0 <__divti3+0x350>  // b.pmore
    6930:	aa0180a1 	orr	x1, x5, x1, lsl #32
    6934:	92407c48 	and	x8, x2, #0xffffffff
    6938:	2a0503e5 	mov	w5, w5
    693c:	d360fc42 	lsr	x2, x2, #32
    6940:	d360fc26 	lsr	x6, x1, #32
    6944:	cb0a0063 	sub	x3, x3, x10
    6948:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    694c:	9b087caa 	mul	x10, x5, x8
    6950:	9b087cc8 	mul	x8, x6, x8
    6954:	9b0220a5 	madd	x5, x5, x2, x8
    6958:	9b027cc6 	mul	x6, x6, x2
    695c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    6960:	8b0900c5 	add	x5, x6, x9
    6964:	eb02011f 	cmp	x8, x2
    6968:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    696c:	8b4280c6 	add	x6, x6, x2, lsr #32
    6970:	eb06007f 	cmp	x3, x6
    6974:	540000e3 	b.cc	6990 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    6978:	92407d4a 	and	x10, x10, #0xffffffff
    697c:	9ac72000 	lsl	x0, x0, x7
    6980:	8b028142 	add	x2, x10, x2, lsl #32
    6984:	eb02001f 	cmp	x0, x2
    6988:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    698c:	54000a01 	b.ne	6acc <__divti3+0x32c>  // b.any
    6990:	d1000420 	sub	x0, x1, #0x1
    6994:	d2800001 	mov	x1, #0x0                   	// #0
    6998:	17ffffb4 	b	6868 <__divti3+0xc8>
    699c:	b5000062 	cbnz	x2, 69a8 <__divti3+0x208>
    69a0:	d2800022 	mov	x2, #0x1                   	// #1
    69a4:	9ac30846 	udiv	x6, x2, x3
    69a8:	dac010c8 	clz	x8, x6
    69ac:	b5000408 	cbnz	x8, 6a2c <__divti3+0x28c>
    69b0:	d360fcc9 	lsr	x9, x6, #32
    69b4:	92407cc5 	and	x5, x6, #0xffffffff
    69b8:	cb060023 	sub	x3, x1, x6
    69bc:	d2800021 	mov	x1, #0x1                   	// #1
    69c0:	9ac90868 	udiv	x8, x3, x9
    69c4:	9b098d03 	msub	x3, x8, x9, x3
    69c8:	aa0803e0 	mov	x0, x8
    69cc:	9b057d02 	mul	x2, x8, x5
    69d0:	93c78063 	extr	x3, x3, x7, #32
    69d4:	eb03005f 	cmp	x2, x3
    69d8:	540000a9 	b.ls	69ec <__divti3+0x24c>  // b.plast
    69dc:	ab0300c3 	adds	x3, x6, x3
    69e0:	d1000500 	sub	x0, x8, #0x1
    69e4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    69e8:	54000968 	b.hi	6b14 <__divti3+0x374>  // b.pmore
    69ec:	cb020063 	sub	x3, x3, x2
    69f0:	9ac90862 	udiv	x2, x3, x9
    69f4:	aa0203e8 	mov	x8, x2
    69f8:	9b098c42 	msub	x2, x2, x9, x3
    69fc:	aa0703e3 	mov	x3, x7
    6a00:	9b057d05 	mul	x5, x8, x5
    6a04:	b3607c43 	bfi	x3, x2, #32, #32
    6a08:	eb0300bf 	cmp	x5, x3
    6a0c:	540000c9 	b.ls	6a24 <__divti3+0x284>  // b.plast
    6a10:	ab0300c2 	adds	x2, x6, x3
    6a14:	d1000503 	sub	x3, x8, #0x1
    6a18:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    6a1c:	d1000908 	sub	x8, x8, #0x2
    6a20:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    6a24:	aa008100 	orr	x0, x8, x0, lsl #32
    6a28:	17ffff90 	b	6868 <__divti3+0xc8>
    6a2c:	9ac820c6 	lsl	x6, x6, x8
    6a30:	d2800803 	mov	x3, #0x40                  	// #64
    6a34:	cb080063 	sub	x3, x3, x8
    6a38:	d360fcc9 	lsr	x9, x6, #32
    6a3c:	9ac82027 	lsl	x7, x1, x8
    6a40:	92407cc5 	and	x5, x6, #0xffffffff
    6a44:	9ac32422 	lsr	x2, x1, x3
    6a48:	9ac32403 	lsr	x3, x0, x3
    6a4c:	aa070063 	orr	x3, x3, x7
    6a50:	9ac9084a 	udiv	x10, x2, x9
    6a54:	9ac82007 	lsl	x7, x0, x8
    6a58:	9b098940 	msub	x0, x10, x9, x2
    6a5c:	aa0a03e1 	mov	x1, x10
    6a60:	9b0a7ca2 	mul	x2, x5, x10
    6a64:	93c38000 	extr	x0, x0, x3, #32
    6a68:	eb00005f 	cmp	x2, x0
    6a6c:	540000a9 	b.ls	6a80 <__divti3+0x2e0>  // b.plast
    6a70:	ab0000c0 	adds	x0, x6, x0
    6a74:	d1000541 	sub	x1, x10, #0x1
    6a78:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    6a7c:	54000468 	b.hi	6b08 <__divti3+0x368>  // b.pmore
    6a80:	cb020000 	sub	x0, x0, x2
    6a84:	9ac9080a 	udiv	x10, x0, x9
    6a88:	9b098140 	msub	x0, x10, x9, x0
    6a8c:	aa0a03e2 	mov	x2, x10
    6a90:	9b0a7ca8 	mul	x8, x5, x10
    6a94:	b3607c03 	bfi	x3, x0, #32, #32
    6a98:	eb03011f 	cmp	x8, x3
    6a9c:	540000a9 	b.ls	6ab0 <__divti3+0x310>  // b.plast
    6aa0:	ab0300c3 	adds	x3, x6, x3
    6aa4:	d1000542 	sub	x2, x10, #0x1
    6aa8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    6aac:	54000288 	b.hi	6afc <__divti3+0x35c>  // b.pmore
    6ab0:	cb080063 	sub	x3, x3, x8
    6ab4:	aa018041 	orr	x1, x2, x1, lsl #32
    6ab8:	17ffffc2 	b	69c0 <__divti3+0x220>
    6abc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    6ac0:	d2800001 	mov	x1, #0x0                   	// #0
    6ac4:	9a9f87e0 	cset	x0, ls	// ls = plast
    6ac8:	17ffff68 	b	6868 <__divti3+0xc8>
    6acc:	aa0103e0 	mov	x0, x1
    6ad0:	d2800001 	mov	x1, #0x0                   	// #0
    6ad4:	17ffff65 	b	6868 <__divti3+0xc8>
    6ad8:	d1000860 	sub	x0, x3, #0x2
    6adc:	8b0600a5 	add	x5, x5, x6
    6ae0:	17ffff52 	b	6828 <__divti3+0x88>
    6ae4:	d1000961 	sub	x1, x11, #0x2
    6ae8:	8b0800a5 	add	x5, x5, x8
    6aec:	17ffff85 	b	6900 <__divti3+0x160>
    6af0:	d1000965 	sub	x5, x11, #0x2
    6af4:	8b080063 	add	x3, x3, x8
    6af8:	17ffff8e 	b	6930 <__divti3+0x190>
    6afc:	d1000942 	sub	x2, x10, #0x2
    6b00:	8b060063 	add	x3, x3, x6
    6b04:	17ffffeb 	b	6ab0 <__divti3+0x310>
    6b08:	d1000941 	sub	x1, x10, #0x2
    6b0c:	8b060000 	add	x0, x0, x6
    6b10:	17ffffdc 	b	6a80 <__divti3+0x2e0>
    6b14:	d1000900 	sub	x0, x8, #0x2
    6b18:	8b060063 	add	x3, x3, x6
    6b1c:	17ffffb4 	b	69ec <__divti3+0x24c>

0000000000006b20 <__modti3>:
    6b20:	d503245f 	bti	c
    6b24:	d2800004 	mov	x4, #0x0                   	// #0
    6b28:	b6f80081 	tbz	x1, #63, 6b38 <__modti3+0x18>
    6b2c:	eb0003e0 	negs	x0, x0
    6b30:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    6b34:	da0103e1 	ngc	x1, x1
    6b38:	f100007f 	cmp	x3, #0x0
    6b3c:	5400128b 	b.lt	6d8c <__modti3+0x26c>  // b.tstop
    6b40:	aa0003e7 	mov	x7, x0
    6b44:	aa0103e6 	mov	x6, x1
    6b48:	540004e1 	b.ne	6be4 <__modti3+0xc4>  // b.any
    6b4c:	eb02003f 	cmp	x1, x2
    6b50:	54000dc2 	b.cs	6d08 <__modti3+0x1e8>  // b.hs, b.nlast
    6b54:	dac01043 	clz	x3, x2
    6b58:	aa0303e5 	mov	x5, x3
    6b5c:	b40000e3 	cbz	x3, 6b78 <__modti3+0x58>
    6b60:	4b0303e6 	neg	w6, w3
    6b64:	9ac32021 	lsl	x1, x1, x3
    6b68:	9ac32042 	lsl	x2, x2, x3
    6b6c:	9ac62406 	lsr	x6, x0, x6
    6b70:	aa0100c6 	orr	x6, x6, x1
    6b74:	9ac32007 	lsl	x7, x0, x3
    6b78:	d360fc40 	lsr	x0, x2, #32
    6b7c:	92407c43 	and	x3, x2, #0xffffffff
    6b80:	9ac008c1 	udiv	x1, x6, x0
    6b84:	9b009826 	msub	x6, x1, x0, x6
    6b88:	9b017c61 	mul	x1, x3, x1
    6b8c:	93c780c6 	extr	x6, x6, x7, #32
    6b90:	eb06003f 	cmp	x1, x6
    6b94:	540000a9 	b.ls	6ba8 <__modti3+0x88>  // b.plast
    6b98:	ab060046 	adds	x6, x2, x6
    6b9c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    6ba0:	8b0200c8 	add	x8, x6, x2
    6ba4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    6ba8:	cb0100c6 	sub	x6, x6, x1
    6bac:	9ac008c8 	udiv	x8, x6, x0
    6bb0:	9b009901 	msub	x1, x8, x0, x6
    6bb4:	aa0703e0 	mov	x0, x7
    6bb8:	9b087c63 	mul	x3, x3, x8
    6bbc:	b3607c20 	bfi	x0, x1, #32, #32
    6bc0:	eb00007f 	cmp	x3, x0
    6bc4:	54001088 	b.hi	6dd4 <__modti3+0x2b4>  // b.pmore
    6bc8:	cb030000 	sub	x0, x0, x3
    6bcc:	9ac52400 	lsr	x0, x0, x5
    6bd0:	d2800001 	mov	x1, #0x0                   	// #0
    6bd4:	b4000064 	cbz	x4, 6be0 <__modti3+0xc0>
    6bd8:	eb0003e0 	negs	x0, x0
    6bdc:	da0103e1 	ngc	x1, x1
    6be0:	d65f03c0 	ret
    6be4:	dac01066 	clz	x6, x3
    6be8:	eb03003f 	cmp	x1, x3
    6bec:	54ffff43 	b.cc	6bd4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    6bf0:	93407cc5 	sxtw	x5, w6
    6bf4:	d2800808 	mov	x8, #0x40                  	// #64
    6bf8:	cb050108 	sub	x8, x8, x5
    6bfc:	9ac62063 	lsl	x3, x3, x6
    6c00:	9ac62025 	lsl	x5, x1, x6
    6c04:	9ac82447 	lsr	x7, x2, x8
    6c08:	aa0300e7 	orr	x7, x7, x3
    6c0c:	9ac82423 	lsr	x3, x1, x8
    6c10:	92407cec 	and	x12, x7, #0xffffffff
    6c14:	d360fcea 	lsr	x10, x7, #32
    6c18:	9ac82401 	lsr	x1, x0, x8
    6c1c:	aa050021 	orr	x1, x1, x5
    6c20:	9ac62042 	lsl	x2, x2, x6
    6c24:	9ac62000 	lsl	x0, x0, x6
    6c28:	9aca086b 	udiv	x11, x3, x10
    6c2c:	9b0a8d63 	msub	x3, x11, x10, x3
    6c30:	aa0b03e5 	mov	x5, x11
    6c34:	9b0b7d89 	mul	x9, x12, x11
    6c38:	93c18063 	extr	x3, x3, x1, #32
    6c3c:	eb03013f 	cmp	x9, x3
    6c40:	540000a9 	b.ls	6c54 <__modti3+0x134>  // b.plast
    6c44:	ab0300e3 	adds	x3, x7, x3
    6c48:	d1000565 	sub	x5, x11, #0x1
    6c4c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    6c50:	54001168 	b.hi	6e7c <__modti3+0x35c>  // b.pmore
    6c54:	cb090063 	sub	x3, x3, x9
    6c58:	9aca086b 	udiv	x11, x3, x10
    6c5c:	9b0a8d6a 	msub	x10, x11, x10, x3
    6c60:	aa0b03e9 	mov	x9, x11
    6c64:	9b0b7d8c 	mul	x12, x12, x11
    6c68:	b3607d41 	bfi	x1, x10, #32, #32
    6c6c:	eb01019f 	cmp	x12, x1
    6c70:	540000a9 	b.ls	6c84 <__modti3+0x164>  // b.plast
    6c74:	ab0100e1 	adds	x1, x7, x1
    6c78:	d1000569 	sub	x9, x11, #0x1
    6c7c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    6c80:	54000f88 	b.hi	6e70 <__modti3+0x350>  // b.pmore
    6c84:	aa058123 	orr	x3, x9, x5, lsl #32
    6c88:	92407c4b 	and	x11, x2, #0xffffffff
    6c8c:	2a0903e9 	mov	w9, w9
    6c90:	d360fc4a 	lsr	x10, x2, #32
    6c94:	d360fc63 	lsr	x3, x3, #32
    6c98:	cb0c0021 	sub	x1, x1, x12
    6c9c:	aa0a03ec 	mov	x12, x10
    6ca0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    6ca4:	9b0b7d25 	mul	x5, x9, x11
    6ca8:	9b0b7c6b 	mul	x11, x3, x11
    6cac:	9b0a2d29 	madd	x9, x9, x10, x11
    6cb0:	92407caa 	and	x10, x5, #0xffffffff
    6cb4:	9b0c7c63 	mul	x3, x3, x12
    6cb8:	8b458125 	add	x5, x9, x5, lsr #32
    6cbc:	8b0d0069 	add	x9, x3, x13
    6cc0:	eb05017f 	cmp	x11, x5
    6cc4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    6cc8:	8b058149 	add	x9, x10, x5, lsl #32
    6ccc:	8b458063 	add	x3, x3, x5, lsr #32
    6cd0:	eb03003f 	cmp	x1, x3
    6cd4:	54000063 	b.cc	6ce0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    6cd8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    6cdc:	54000082 	b.cs	6cec <__modti3+0x1cc>  // b.hs, b.nlast
    6ce0:	eb020129 	subs	x9, x9, x2
    6ce4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    6ce8:	cb070063 	sub	x3, x3, x7
    6cec:	eb090000 	subs	x0, x0, x9
    6cf0:	da030021 	sbc	x1, x1, x3
    6cf4:	9ac62400 	lsr	x0, x0, x6
    6cf8:	9ac82028 	lsl	x8, x1, x8
    6cfc:	aa000100 	orr	x0, x8, x0
    6d00:	9ac62421 	lsr	x1, x1, x6
    6d04:	17ffffb4 	b	6bd4 <__modti3+0xb4>
    6d08:	b5000062 	cbnz	x2, 6d14 <__modti3+0x1f4>
    6d0c:	d2800023 	mov	x3, #0x1                   	// #1
    6d10:	9ac20862 	udiv	x2, x3, x2
    6d14:	dac01048 	clz	x8, x2
    6d18:	aa0803e5 	mov	x5, x8
    6d1c:	b5000668 	cbnz	x8, 6de8 <__modti3+0x2c8>
    6d20:	cb020020 	sub	x0, x1, x2
    6d24:	d360fc49 	lsr	x9, x2, #32
    6d28:	92407c4a 	and	x10, x2, #0xffffffff
    6d2c:	9ac90801 	udiv	x1, x0, x9
    6d30:	9b098020 	msub	x0, x1, x9, x0
    6d34:	9b0a7c21 	mul	x1, x1, x10
    6d38:	93c78000 	extr	x0, x0, x7, #32
    6d3c:	eb00003f 	cmp	x1, x0
    6d40:	540000a9 	b.ls	6d54 <__modti3+0x234>  // b.plast
    6d44:	ab000040 	adds	x0, x2, x0
    6d48:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    6d4c:	8b020003 	add	x3, x0, x2
    6d50:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    6d54:	cb010001 	sub	x1, x0, x1
    6d58:	9ac90820 	udiv	x0, x1, x9
    6d5c:	9b098403 	msub	x3, x0, x9, x1
    6d60:	aa0703e1 	mov	x1, x7
    6d64:	9b0a7c00 	mul	x0, x0, x10
    6d68:	b3607c61 	bfi	x1, x3, #32, #32
    6d6c:	eb01001f 	cmp	x0, x1
    6d70:	540000a9 	b.ls	6d84 <__modti3+0x264>  // b.plast
    6d74:	ab010041 	adds	x1, x2, x1
    6d78:	8b020022 	add	x2, x1, x2
    6d7c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    6d80:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    6d84:	cb000020 	sub	x0, x1, x0
    6d88:	17ffff91 	b	6bcc <__modti3+0xac>
    6d8c:	eb0203e5 	negs	x5, x2
    6d90:	aa0003e7 	mov	x7, x0
    6d94:	da0303e8 	ngc	x8, x3
    6d98:	aa0503e2 	mov	x2, x5
    6d9c:	aa0803e3 	mov	x3, x8
    6da0:	aa0103e6 	mov	x6, x1
    6da4:	b4ffed48 	cbz	x8, 6b4c <__modti3+0x2c>
    6da8:	eb01011f 	cmp	x8, x1
    6dac:	54fff148 	b.hi	6bd4 <__modti3+0xb4>  // b.pmore
    6db0:	dac01109 	clz	x9, x8
    6db4:	2a0903e6 	mov	w6, w9
    6db8:	b5fff1c9 	cbnz	x9, 6bf0 <__modti3+0xd0>
    6dbc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    6dc0:	54000068 	b.hi	6dcc <__modti3+0x2ac>  // b.pmore
    6dc4:	eb050007 	subs	x7, x0, x5
    6dc8:	da080021 	sbc	x1, x1, x8
    6dcc:	aa0703e0 	mov	x0, x7
    6dd0:	17ffff81 	b	6bd4 <__modti3+0xb4>
    6dd4:	ab000040 	adds	x0, x2, x0
    6dd8:	8b020002 	add	x2, x0, x2
    6ddc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    6de0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    6de4:	17ffff79 	b	6bc8 <__modti3+0xa8>
    6de8:	9ac82042 	lsl	x2, x2, x8
    6dec:	d2800803 	mov	x3, #0x40                  	// #64
    6df0:	cb080063 	sub	x3, x3, x8
    6df4:	d360fc49 	lsr	x9, x2, #32
    6df8:	9ac82027 	lsl	x7, x1, x8
    6dfc:	92407c4a 	and	x10, x2, #0xffffffff
    6e00:	9ac32426 	lsr	x6, x1, x3
    6e04:	9ac32403 	lsr	x3, x0, x3
    6e08:	aa070063 	orr	x3, x3, x7
    6e0c:	9ac908c1 	udiv	x1, x6, x9
    6e10:	9ac82007 	lsl	x7, x0, x8
    6e14:	9b099820 	msub	x0, x1, x9, x6
    6e18:	9b017d41 	mul	x1, x10, x1
    6e1c:	93c38000 	extr	x0, x0, x3, #32
    6e20:	eb00003f 	cmp	x1, x0
    6e24:	540000a9 	b.ls	6e38 <__modti3+0x318>  // b.plast
    6e28:	ab000040 	adds	x0, x2, x0
    6e2c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    6e30:	8b020006 	add	x6, x0, x2
    6e34:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    6e38:	cb010000 	sub	x0, x0, x1
    6e3c:	9ac90801 	udiv	x1, x0, x9
    6e40:	9b098026 	msub	x6, x1, x9, x0
    6e44:	aa0303e0 	mov	x0, x3
    6e48:	9b017d41 	mul	x1, x10, x1
    6e4c:	b3607cc0 	bfi	x0, x6, #32, #32
    6e50:	eb00003f 	cmp	x1, x0
    6e54:	540000a9 	b.ls	6e68 <__modti3+0x348>  // b.plast
    6e58:	ab000040 	adds	x0, x2, x0
    6e5c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    6e60:	8b020003 	add	x3, x0, x2
    6e64:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    6e68:	cb010000 	sub	x0, x0, x1
    6e6c:	17ffffb0 	b	6d2c <__modti3+0x20c>
    6e70:	d1000969 	sub	x9, x11, #0x2
    6e74:	8b070021 	add	x1, x1, x7
    6e78:	17ffff83 	b	6c84 <__modti3+0x164>
    6e7c:	d1000965 	sub	x5, x11, #0x2
    6e80:	8b070063 	add	x3, x3, x7
    6e84:	17ffff74 	b	6c54 <__modti3+0x134>
    6e88:	d503201f 	nop
    6e8c:	d503201f 	nop

0000000000006e90 <atexit>:
    6e90:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    6e94:	d00000c2 	adrp	x2, 20000 <__data_start>
    6e98:	d2800001 	mov	x1, #0x0                   	// #0
    6e9c:	910003fd 	mov	x29, sp
    6ea0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    6ea4:	f9400442 	ldr	x2, [x2, #8]
    6ea8:	17ffe952 	b	13f0 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000006eac <_fini>:
    6eac:	d503201f 	nop
    6eb0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    6eb4:	910003fd 	mov	x29, sp
    6eb8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    6ebc:	d65f03c0 	ret
