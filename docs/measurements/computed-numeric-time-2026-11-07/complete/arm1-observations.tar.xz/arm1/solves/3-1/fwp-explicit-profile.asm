
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1/fwp-explicit-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001370 <_init>:
    1370:	d503201f 	nop
    1374:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1378:	910003fd 	mov	x29, sp
    137c:	9400018e 	bl	19b4 <call_weak_fn>
    1380:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1384:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001390 <.plt>:
    1390:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1394:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1398:	f946fe11 	ldr	x17, [x16, #3576]
    139c:	9137e210 	add	x16, x16, #0xdf8
    13a0:	d61f0220 	br	x17
    13a4:	d503201f 	nop
    13a8:	d503201f 	nop
    13ac:	d503201f 	nop

00000000000013b0 <memcpy@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    13b4:	f9470211 	ldr	x17, [x16, #3584]
    13b8:	91380210 	add	x16, x16, #0xe00
    13bc:	d61f0220 	br	x17

00000000000013c0 <sigaltstack@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    13c4:	f9470611 	ldr	x17, [x16, #3592]
    13c8:	91382210 	add	x16, x16, #0xe08
    13cc:	d61f0220 	br	x17

00000000000013d0 <_exit@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    13d4:	f9470a11 	ldr	x17, [x16, #3600]
    13d8:	91384210 	add	x16, x16, #0xe10
    13dc:	d61f0220 	br	x17

00000000000013e0 <strlen@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    13e4:	f9470e11 	ldr	x17, [x16, #3608]
    13e8:	91386210 	add	x16, x16, #0xe18
    13ec:	d61f0220 	br	x17

00000000000013f0 <__sprintf_chk@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    13f4:	f9471211 	ldr	x17, [x16, #3616]
    13f8:	91388210 	add	x16, x16, #0xe20
    13fc:	d61f0220 	br	x17

0000000000001400 <exit@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1404:	f9471611 	ldr	x17, [x16, #3624]
    1408:	9138a210 	add	x16, x16, #0xe28
    140c:	d61f0220 	br	x17

0000000000001410 <__libc_start_main@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1414:	f9471a11 	ldr	x17, [x16, #3632]
    1418:	9138c210 	add	x16, x16, #0xe30
    141c:	d61f0220 	br	x17

0000000000001420 <strtoll@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1424:	f9471e11 	ldr	x17, [x16, #3640]
    1428:	9138e210 	add	x16, x16, #0xe38
    142c:	d61f0220 	br	x17

0000000000001430 <strtod@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1434:	f9472211 	ldr	x17, [x16, #3648]
    1438:	91390210 	add	x16, x16, #0xe40
    143c:	d61f0220 	br	x17

0000000000001440 <__cxa_finalize@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1444:	f9472611 	ldr	x17, [x16, #3656]
    1448:	91392210 	add	x16, x16, #0xe48
    144c:	d61f0220 	br	x17

0000000000001450 <__cxa_atexit@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1454:	f9472a11 	ldr	x17, [x16, #3664]
    1458:	91394210 	add	x16, x16, #0xe50
    145c:	d61f0220 	br	x17

0000000000001460 <pthread_attr_init@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1464:	f9472e11 	ldr	x17, [x16, #3672]
    1468:	91396210 	add	x16, x16, #0xe58
    146c:	d61f0220 	br	x17

0000000000001470 <fputc@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1474:	f9473211 	ldr	x17, [x16, #3680]
    1478:	91398210 	add	x16, x16, #0xe60
    147c:	d61f0220 	br	x17

0000000000001480 <clock_gettime@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1484:	f9473611 	ldr	x17, [x16, #3688]
    1488:	9139a210 	add	x16, x16, #0xe68
    148c:	d61f0220 	br	x17

0000000000001490 <setvbuf@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1494:	f9473a11 	ldr	x17, [x16, #3696]
    1498:	9139c210 	add	x16, x16, #0xe70
    149c:	d61f0220 	br	x17

00000000000014a0 <__memcpy_chk@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    14a4:	f9473e11 	ldr	x17, [x16, #3704]
    14a8:	9139e210 	add	x16, x16, #0xe78
    14ac:	d61f0220 	br	x17

00000000000014b0 <signal@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    14b4:	f9474211 	ldr	x17, [x16, #3712]
    14b8:	913a0210 	add	x16, x16, #0xe80
    14bc:	d61f0220 	br	x17

00000000000014c0 <__snprintf_chk@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    14c4:	f9474611 	ldr	x17, [x16, #3720]
    14c8:	913a2210 	add	x16, x16, #0xe88
    14cc:	d61f0220 	br	x17

00000000000014d0 <fclose@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    14d4:	f9474a11 	ldr	x17, [x16, #3728]
    14d8:	913a4210 	add	x16, x16, #0xe90
    14dc:	d61f0220 	br	x17

00000000000014e0 <fopen@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    14e4:	f9474e11 	ldr	x17, [x16, #3736]
    14e8:	913a6210 	add	x16, x16, #0xe98
    14ec:	d61f0220 	br	x17

00000000000014f0 <malloc@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    14f4:	f9475211 	ldr	x17, [x16, #3744]
    14f8:	913a8210 	add	x16, x16, #0xea0
    14fc:	d61f0220 	br	x17

0000000000001500 <pthread_attr_destroy@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1504:	f9475611 	ldr	x17, [x16, #3752]
    1508:	913aa210 	add	x16, x16, #0xea8
    150c:	d61f0220 	br	x17

0000000000001510 <sigemptyset@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1514:	f9475a11 	ldr	x17, [x16, #3760]
    1518:	913ac210 	add	x16, x16, #0xeb0
    151c:	d61f0220 	br	x17

0000000000001520 <memset@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1524:	f9475e11 	ldr	x17, [x16, #3768]
    1528:	913ae210 	add	x16, x16, #0xeb8
    152c:	d61f0220 	br	x17

0000000000001530 <calloc@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1534:	f9476211 	ldr	x17, [x16, #3776]
    1538:	913b0210 	add	x16, x16, #0xec0
    153c:	d61f0220 	br	x17

0000000000001540 <realloc@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1544:	f9476611 	ldr	x17, [x16, #3784]
    1548:	913b2210 	add	x16, x16, #0xec8
    154c:	d61f0220 	br	x17

0000000000001550 <__stack_chk_fail@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1554:	f9476a11 	ldr	x17, [x16, #3792]
    1558:	913b4210 	add	x16, x16, #0xed0
    155c:	d61f0220 	br	x17

0000000000001560 <close@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1564:	f9476e11 	ldr	x17, [x16, #3800]
    1568:	913b6210 	add	x16, x16, #0xed8
    156c:	d61f0220 	br	x17

0000000000001570 <sigaction@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1574:	f9477211 	ldr	x17, [x16, #3808]
    1578:	913b8210 	add	x16, x16, #0xee0
    157c:	d61f0220 	br	x17

0000000000001580 <__gmon_start__@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1584:	f9477611 	ldr	x17, [x16, #3816]
    1588:	913ba210 	add	x16, x16, #0xee8
    158c:	d61f0220 	br	x17

0000000000001590 <write@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1594:	f9477a11 	ldr	x17, [x16, #3824]
    1598:	913bc210 	add	x16, x16, #0xef0
    159c:	d61f0220 	br	x17

00000000000015a0 <abort@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    15a4:	f9477e11 	ldr	x17, [x16, #3832]
    15a8:	913be210 	add	x16, x16, #0xef8
    15ac:	d61f0220 	br	x17

00000000000015b0 <swapcontext@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    15b4:	f9478211 	ldr	x17, [x16, #3840]
    15b8:	913c0210 	add	x16, x16, #0xf00
    15bc:	d61f0220 	br	x17

00000000000015c0 <__fprintf_chk@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    15c4:	f9478611 	ldr	x17, [x16, #3848]
    15c8:	913c2210 	add	x16, x16, #0xf08
    15cc:	d61f0220 	br	x17

00000000000015d0 <strcmp@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    15d4:	f9478a11 	ldr	x17, [x16, #3856]
    15d8:	913c4210 	add	x16, x16, #0xf10
    15dc:	d61f0220 	br	x17

00000000000015e0 <mmap@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    15e4:	f9478e11 	ldr	x17, [x16, #3864]
    15e8:	913c6210 	add	x16, x16, #0xf18
    15ec:	d61f0220 	br	x17

00000000000015f0 <strtol@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    15f4:	f9479211 	ldr	x17, [x16, #3872]
    15f8:	913c8210 	add	x16, x16, #0xf20
    15fc:	d61f0220 	br	x17

0000000000001600 <strtof@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1604:	f9479611 	ldr	x17, [x16, #3880]
    1608:	913ca210 	add	x16, x16, #0xf28
    160c:	d61f0220 	br	x17

0000000000001610 <free@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1614:	f9479a11 	ldr	x17, [x16, #3888]
    1618:	913cc210 	add	x16, x16, #0xf30
    161c:	d61f0220 	br	x17

0000000000001620 <nanosleep@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1624:	f9479e11 	ldr	x17, [x16, #3896]
    1628:	913ce210 	add	x16, x16, #0xf38
    162c:	d61f0220 	br	x17

0000000000001630 <strchr@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1634:	f947a211 	ldr	x17, [x16, #3904]
    1638:	913d0210 	add	x16, x16, #0xf40
    163c:	d61f0220 	br	x17

0000000000001640 <strtoull@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1644:	f947a611 	ldr	x17, [x16, #3912]
    1648:	913d2210 	add	x16, x16, #0xf48
    164c:	d61f0220 	br	x17

0000000000001650 <fwrite@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1654:	f947aa11 	ldr	x17, [x16, #3920]
    1658:	913d4210 	add	x16, x16, #0xf50
    165c:	d61f0220 	br	x17

0000000000001660 <pthread_create@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1664:	f947ae11 	ldr	x17, [x16, #3928]
    1668:	913d6210 	add	x16, x16, #0xf58
    166c:	d61f0220 	br	x17

0000000000001670 <munmap@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1674:	f947b211 	ldr	x17, [x16, #3936]
    1678:	913d8210 	add	x16, x16, #0xf60
    167c:	d61f0220 	br	x17

0000000000001680 <fflush@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1684:	f947b611 	ldr	x17, [x16, #3944]
    1688:	913da210 	add	x16, x16, #0xf68
    168c:	d61f0220 	br	x17

0000000000001690 <strcpy@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1694:	f947ba11 	ldr	x17, [x16, #3952]
    1698:	913dc210 	add	x16, x16, #0xf70
    169c:	d61f0220 	br	x17

00000000000016a0 <sysconf@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    16a4:	f947be11 	ldr	x17, [x16, #3960]
    16a8:	913de210 	add	x16, x16, #0xf78
    16ac:	d61f0220 	br	x17

00000000000016b0 <strstr@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    16b4:	f947c211 	ldr	x17, [x16, #3968]
    16b8:	913e0210 	add	x16, x16, #0xf80
    16bc:	d61f0220 	br	x17

00000000000016c0 <_Exit@plt>:
    16c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    16c4:	f947c611 	ldr	x17, [x16, #3976]
    16c8:	913e2210 	add	x16, x16, #0xf88
    16cc:	d61f0220 	br	x17

00000000000016d0 <pthread_join@plt>:
    16d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    16d4:	f947ca11 	ldr	x17, [x16, #3984]
    16d8:	913e4210 	add	x16, x16, #0xf90
    16dc:	d61f0220 	br	x17

00000000000016e0 <getenv@plt>:
    16e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    16e4:	f947ce11 	ldr	x17, [x16, #3992]
    16e8:	913e6210 	add	x16, x16, #0xf98
    16ec:	d61f0220 	br	x17

00000000000016f0 <mprotect@plt>:
    16f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    16f4:	f947d211 	ldr	x17, [x16, #4000]
    16f8:	913e8210 	add	x16, x16, #0xfa0
    16fc:	d61f0220 	br	x17

0000000000001700 <fgets@plt>:
    1700:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1704:	f947d611 	ldr	x17, [x16, #4008]
    1708:	913ea210 	add	x16, x16, #0xfa8
    170c:	d61f0220 	br	x17

0000000000001710 <pthread_attr_setstacksize@plt>:
    1710:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15a68>
    1714:	f947da11 	ldr	x17, [x16, #4016]
    1718:	913ec210 	add	x16, x16, #0xfb0
    171c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001740 <fwp_trap_overflow.constprop.0>:
    1740:	d10243ff 	sub	sp, sp, #0x90
    1744:	d2800c03 	mov	x3, #0x60                  	// #96
    1748:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15a68>
    174c:	f947f421 	ldr	x1, [x1, #4072]
    1750:	d0000025 	adrp	x5, 7000 <fwp_main_thread+0x4d0>
    1754:	a9077bfd 	stp	x29, x30, [sp, #112]
    1758:	9101c3fd 	add	x29, sp, #0x70
    175c:	913e80a5 	add	x5, x5, #0xfa0
    1760:	d0000024 	adrp	x4, 7000 <fwp_main_thread+0x4d0>
    1764:	f90043f3 	str	x19, [sp, #128]
    1768:	913ea084 	add	x4, x4, #0xfa8
    176c:	910023f3 	add	x19, sp, #0x8
    1770:	f9400022 	ldr	x2, [x1]
    1774:	f90037e2 	str	x2, [sp, #104]
    1778:	d2800002 	mov	x2, #0x0                   	// #0
    177c:	aa0303e1 	mov	x1, x3
    1780:	52800042 	mov	w2, #0x2                   	// #2
    1784:	aa1303e0 	mov	x0, x19
    1788:	97ffff4e 	bl	14c0 <__snprintf_chk@plt>
    178c:	aa1303e0 	mov	x0, x19
    1790:	940002dc 	bl	2300 <fwp_trap>
    1794:	d503201f 	nop
    1798:	d503201f 	nop
    179c:	d503201f 	nop

00000000000017a0 <main>:
    17a0:	d10243ff 	sub	sp, sp, #0x90
    17a4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    17a8:	f947f400 	ldr	x0, [x0, #4072]
    17ac:	a9067bfd 	stp	x29, x30, [sp, #96]
    17b0:	910183fd 	add	x29, sp, #0x60
    17b4:	a90753f3 	stp	x19, x20, [sp, #112]
    17b8:	f00000f3 	adrp	x19, 20000 <__data_start>
    17bc:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x15a68>
    17c0:	f947ee94 	ldr	x20, [x20, #4056]
    17c4:	f9400281 	ldr	x1, [x20]
    17c8:	f90043f5 	str	x21, [sp, #128]
    17cc:	f9400002 	ldr	x2, [x0]
    17d0:	f9002fe2 	str	x2, [sp, #88]
    17d4:	d2800002 	mov	x2, #0x0                   	// #0
    17d8:	f9002a61 	str	x1, [x19, #80]
    17dc:	940002d9 	bl	2340 <fwp_now_ns>
    17e0:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    17e4:	910a2000 	add	x0, x0, #0x288
    17e8:	97ffffbe 	bl	16e0 <getenv@plt>
    17ec:	b4000080 	cbz	x0, 17fc <main+0x5c>
    17f0:	39400001 	ldrb	w1, [x0]
    17f4:	aa0003f5 	mov	x21, x0
    17f8:	35000801 	cbnz	w1, 18f8 <main+0x158>
    17fc:	910023e1 	add	x1, sp, #0x8
    1800:	52800000 	mov	w0, #0x0                   	// #0
    1804:	97ffff1f 	bl	1480 <clock_gettime@plt>
    1808:	35000900 	cbnz	w0, 1928 <main+0x188>
    180c:	a9408be0 	ldp	x0, x2, [sp, #8]
    1810:	d2994003 	mov	x3, #0xca00                	// #51712
    1814:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    1818:	9b037c01 	mul	x1, x0, x3
    181c:	9b437c00 	smulh	x0, x0, x3
    1820:	ab020021 	adds	x1, x1, x2
    1824:	937ffc42 	asr	x2, x2, #63
    1828:	9a020000 	adc	x0, x0, x2
    182c:	f100003f 	cmp	x1, #0x0
    1830:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    1834:	b50009a0 	cbnz	x0, 1968 <main+0x1c8>
    1838:	f9400280 	ldr	x0, [x20]
    183c:	d2a00023 	mov	x3, #0x10000               	// #65536
    1840:	52800002 	mov	w2, #0x0                   	// #0
    1844:	d2800001 	mov	x1, #0x0                   	// #0
    1848:	910063f5 	add	x21, sp, #0x18
    184c:	97ffff11 	bl	1490 <setvbuf@plt>
    1850:	d2800021 	mov	x1, #0x1                   	// #1
    1854:	528001a0 	mov	w0, #0xd                   	// #13
    1858:	97ffff16 	bl	14b0 <signal@plt>
    185c:	aa1503e0 	mov	x0, x21
    1860:	97ffff00 	bl	1460 <pthread_attr_init@plt>
    1864:	350007c0 	cbnz	w0, 195c <main+0x1bc>
    1868:	aa1503e0 	mov	x0, x21
    186c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    1870:	97ffffa8 	bl	1710 <pthread_attr_setstacksize@plt>
    1874:	35000680 	cbnz	w0, 1944 <main+0x1a4>
    1878:	aa1503e1 	mov	x1, x21
    187c:	910023e0 	add	x0, sp, #0x8
    1880:	b0000022 	adrp	x2, 6000 <fwp_write+0x4c0>
    1884:	d2800003 	mov	x3, #0x0                   	// #0
    1888:	912cc042 	add	x2, x2, #0xb30
    188c:	97ffff75 	bl	1660 <pthread_create@plt>
    1890:	2a0003e1 	mov	w1, w0
    1894:	aa1503e0 	mov	x0, x21
    1898:	2a0103f5 	mov	w21, w1
    189c:	97ffff19 	bl	1500 <pthread_attr_destroy@plt>
    18a0:	350006a0 	cbnz	w0, 1974 <main+0x1d4>
    18a4:	350004b5 	cbnz	w21, 1938 <main+0x198>
    18a8:	f94007e0 	ldr	x0, [sp, #8]
    18ac:	d2800001 	mov	x1, #0x0                   	// #0
    18b0:	97ffff88 	bl	16d0 <pthread_join@plt>
    18b4:	35000600 	cbnz	w0, 1974 <main+0x1d4>
    18b8:	f9400280 	ldr	x0, [x20]
    18bc:	91014273 	add	x19, x19, #0x50
    18c0:	97ffff70 	bl	1680 <fflush@plt>
    18c4:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15a68>
    18c8:	f947f421 	ldr	x1, [x1, #4072]
    18cc:	b942da60 	ldr	w0, [x19, #728]
    18d0:	f9402fe3 	ldr	x3, [sp, #88]
    18d4:	f9400022 	ldr	x2, [x1]
    18d8:	eb020063 	subs	x3, x3, x2
    18dc:	d2800002 	mov	x2, #0x0                   	// #0
    18e0:	540002a1 	b.ne	1934 <main+0x194>  // b.any
    18e4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    18e8:	a94753f3 	ldp	x19, x20, [sp, #112]
    18ec:	f94043f5 	ldr	x21, [sp, #128]
    18f0:	910243ff 	add	sp, sp, #0x90
    18f4:	d65f03c0 	ret
    18f8:	910003e1 	mov	x1, sp
    18fc:	52800142 	mov	w2, #0xa                   	// #10
    1900:	97ffff50 	bl	1640 <strtoull@plt>
    1904:	f94003e0 	ldr	x0, [sp]
    1908:	39400000 	ldrb	w0, [x0]
    190c:	35fff780 	cbnz	w0, 17fc <main+0x5c>
    1910:	394002a0 	ldrb	w0, [x21]
    1914:	52801fa1 	mov	w1, #0xfd                  	// #253
    1918:	5100ac00 	sub	w0, w0, #0x2b
    191c:	6a01001f 	tst	w0, w1
    1920:	54fff6e0 	b.eq	17fc <main+0x5c>  // b.none
    1924:	17ffffc5 	b	1838 <main+0x98>
    1928:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    192c:	910a6000 	add	x0, x0, #0x298
    1930:	94000274 	bl	2300 <fwp_trap>
    1934:	97ffff07 	bl	1550 <__stack_chk_fail@plt>
    1938:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    193c:	910ce000 	add	x0, x0, #0x338
    1940:	94000270 	bl	2300 <fwp_trap>
    1944:	aa1503e0 	mov	x0, x21
    1948:	97fffeee 	bl	1500 <pthread_attr_destroy@plt>
    194c:	35000140 	cbnz	w0, 1974 <main+0x1d4>
    1950:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    1954:	910c4000 	add	x0, x0, #0x310
    1958:	9400026a 	bl	2300 <fwp_trap>
    195c:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    1960:	910b8000 	add	x0, x0, #0x2e0
    1964:	94000267 	bl	2300 <fwp_trap>
    1968:	f0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    196c:	910ae000 	add	x0, x0, #0x2b8
    1970:	94000264 	bl	2300 <fwp_trap>
    1974:	97ffff0b 	bl	15a0 <abort@plt>
    1978:	d503201f 	nop
    197c:	d503201f 	nop

0000000000001980 <_start>:
    1980:	d503201f 	nop
    1984:	d280001d 	mov	x29, #0x0                   	// #0
    1988:	d280001e 	mov	x30, #0x0                   	// #0
    198c:	aa0003e5 	mov	x5, x0
    1990:	f94003e1 	ldr	x1, [sp]
    1994:	910023e2 	add	x2, sp, #0x8
    1998:	910003e6 	mov	x6, sp
    199c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    19a0:	f947f800 	ldr	x0, [x0, #4080]
    19a4:	d2800003 	mov	x3, #0x0                   	// #0
    19a8:	d2800004 	mov	x4, #0x0                   	// #0
    19ac:	97fffe99 	bl	1410 <__libc_start_main@plt>
    19b0:	97fffefc 	bl	15a0 <abort@plt>

00000000000019b4 <call_weak_fn>:
    19b4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    19b8:	f947f000 	ldr	x0, [x0, #4064]
    19bc:	b4000040 	cbz	x0, 19c4 <call_weak_fn+0x10>
    19c0:	17fffef0 	b	1580 <__gmon_start__@plt>
    19c4:	d65f03c0 	ret
    19c8:	d503201f 	nop
    19cc:	d503201f 	nop

00000000000019d0 <deregister_tm_clones>:
    19d0:	f00000e0 	adrp	x0, 20000 <__data_start>
    19d4:	9100e000 	add	x0, x0, #0x38
    19d8:	f00000e1 	adrp	x1, 20000 <__data_start>
    19dc:	9100e021 	add	x1, x1, #0x38
    19e0:	eb00003f 	cmp	x1, x0
    19e4:	540000c0 	b.eq	19fc <deregister_tm_clones+0x2c>  // b.none
    19e8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15a68>
    19ec:	f947e021 	ldr	x1, [x1, #4032]
    19f0:	b4000061 	cbz	x1, 19fc <deregister_tm_clones+0x2c>
    19f4:	aa0103f0 	mov	x16, x1
    19f8:	d61f0200 	br	x16
    19fc:	d65f03c0 	ret

0000000000001a00 <register_tm_clones>:
    1a00:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a04:	9100e000 	add	x0, x0, #0x38
    1a08:	f00000e1 	adrp	x1, 20000 <__data_start>
    1a0c:	9100e021 	add	x1, x1, #0x38
    1a10:	cb000021 	sub	x1, x1, x0
    1a14:	d37ffc22 	lsr	x2, x1, #63
    1a18:	8b810c41 	add	x1, x2, x1, asr #3
    1a1c:	9341fc21 	asr	x1, x1, #1
    1a20:	b40000c1 	cbz	x1, 1a38 <register_tm_clones+0x38>
    1a24:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x15a68>
    1a28:	f947fc42 	ldr	x2, [x2, #4088]
    1a2c:	b4000062 	cbz	x2, 1a38 <register_tm_clones+0x38>
    1a30:	aa0203f0 	mov	x16, x2
    1a34:	d61f0200 	br	x16
    1a38:	d65f03c0 	ret
    1a3c:	d503201f 	nop

0000000000001a40 <__do_global_dtors_aux>:
    1a40:	d503233f 	paciasp
    1a44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1a48:	910003fd 	mov	x29, sp
    1a4c:	f9000bf3 	str	x19, [sp, #16]
    1a50:	f00000f3 	adrp	x19, 20000 <__data_start>
    1a54:	39410260 	ldrb	w0, [x19, #64]
    1a58:	37000140 	tbnz	w0, #0, 1a80 <__do_global_dtors_aux+0x40>
    1a5c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    1a60:	f947e400 	ldr	x0, [x0, #4040]
    1a64:	b4000080 	cbz	x0, 1a74 <__do_global_dtors_aux+0x34>
    1a68:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a6c:	f9400400 	ldr	x0, [x0, #8]
    1a70:	97fffe74 	bl	1440 <__cxa_finalize@plt>
    1a74:	97ffffd7 	bl	19d0 <deregister_tm_clones>
    1a78:	52800020 	mov	w0, #0x1                   	// #1
    1a7c:	39010260 	strb	w0, [x19, #64]
    1a80:	f9400bf3 	ldr	x19, [sp, #16]
    1a84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a88:	d50323bf 	autiasp
    1a8c:	d65f03c0 	ret

0000000000001a90 <frame_dummy>:
    1a90:	d503245f 	bti	c
    1a94:	17ffffdb 	b	1a00 <register_tm_clones>
    1a98:	d503201f 	nop
    1a9c:	d503201f 	nop

0000000000001aa0 <fwp_fmt_u128>:
    1aa0:	d10183ff 	sub	sp, sp, #0x60
    1aa4:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15a68>
    1aa8:	f947f421 	ldr	x1, [x1, #4072]
    1aac:	a9057bfd 	stp	x29, x30, [sp, #80]
    1ab0:	910143fd 	add	x29, sp, #0x50
    1ab4:	f9400024 	ldr	x4, [x1]
    1ab8:	f90027e4 	str	x4, [sp, #72]
    1abc:	d2800004 	mov	x4, #0x0                   	// #0
    1ac0:	aa030041 	orr	x1, x2, x3
    1ac4:	b5000361 	cbnz	x1, 1b30 <fwp_fmt_u128+0x90>
    1ac8:	910023e9 	add	x9, sp, #0x8
    1acc:	52800601 	mov	w1, #0x30                  	// #48
    1ad0:	5280002d 	mov	w13, #0x1                   	// #1
    1ad4:	390023e1 	strb	w1, [sp, #8]
    1ad8:	93407dad 	sxtw	x13, w13
    1adc:	aa0d03e1 	mov	x1, x13
    1ae0:	8b0d0004 	add	x4, x0, x13
    1ae4:	d503201f 	nop
    1ae8:	8b010123 	add	x3, x9, x1
    1aec:	cb0103e2 	neg	x2, x1
    1af0:	d1000421 	sub	x1, x1, #0x1
    1af4:	385ff063 	ldurb	w3, [x3, #-1]
    1af8:	38226883 	strb	w3, [x4, x2]
    1afc:	35ffff61 	cbnz	w1, 1ae8 <fwp_fmt_u128+0x48>
    1b00:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15a68>
    1b04:	f947f421 	ldr	x1, [x1, #4072]
    1b08:	382d681f 	strb	wzr, [x0, x13]
    1b0c:	aa0103e0 	mov	x0, x1
    1b10:	f94027e2 	ldr	x2, [sp, #72]
    1b14:	f9400001 	ldr	x1, [x0]
    1b18:	eb010042 	subs	x2, x2, x1
    1b1c:	d2800001 	mov	x1, #0x0                   	// #0
    1b20:	54000561 	b.ne	1bcc <fwp_fmt_u128+0x12c>  // b.any
    1b24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1b28:	910183ff 	add	sp, sp, #0x60
    1b2c:	d65f03c0 	ret
    1b30:	f0000021 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    1b34:	91108021 	add	x1, x1, #0x420
    1b38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1b3c:	910023e9 	add	x9, sp, #0x8
    1b40:	d2800027 	mov	x7, #0x1                   	// #1
    1b44:	f29999af 	movk	x15, #0xcccd
    1b48:	a9402826 	ldp	x6, x10, [x1]
    1b4c:	d503201f 	nop
    1b50:	ab030041 	adds	x1, x2, x3
    1b54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1b58:	aa0303eb 	mov	x11, x3
    1b5c:	8b070128 	add	x8, x9, x7
    1b60:	aa0203ee 	mov	x14, x2
    1b64:	aa0703ed 	mov	x13, x7
    1b68:	910004e7 	add	x7, x7, #0x1
    1b6c:	9bcf7c24 	umulh	x4, x1, x15
    1b70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1b74:	8b4408a4 	add	x4, x5, x4, lsr #2
    1b78:	cb040021 	sub	x1, x1, x4
    1b7c:	eb010041 	subs	x1, x2, x1
    1b80:	da1f0063 	sbc	x3, x3, xzr
    1b84:	9bc67c24 	umulh	x4, x1, x6
    1b88:	9b061064 	madd	x4, x3, x6, x4
    1b8c:	9b067c2c 	mul	x12, x1, x6
    1b90:	9b0a1024 	madd	x4, x1, x10, x4
    1b94:	9bc67c25 	umulh	x5, x1, x6
    1b98:	9b061465 	madd	x5, x3, x6, x5
    1b9c:	9b0a1425 	madd	x5, x1, x10, x5
    1ba0:	93cc0484 	extr	x4, x4, x12, #1
    1ba4:	8b040884 	add	x4, x4, x4, lsl #2
    1ba8:	d341fca3 	lsr	x3, x5, #1
    1bac:	cb040444 	sub	x4, x2, x4, lsl #1
    1bb0:	93cc04a2 	extr	x2, x5, x12, #1
    1bb4:	1100c084 	add	w4, w4, #0x30
    1bb8:	381ff104 	sturb	w4, [x8, #-1]
    1bbc:	b5fffcab 	cbnz	x11, 1b50 <fwp_fmt_u128+0xb0>
    1bc0:	f10025df 	cmp	x14, #0x9
    1bc4:	54fffc68 	b.hi	1b50 <fwp_fmt_u128+0xb0>  // b.pmore
    1bc8:	17ffffc4 	b	1ad8 <fwp_fmt_u128+0x38>
    1bcc:	97fffe61 	bl	1550 <__stack_chk_fail@plt>

0000000000001bd0 <fwp_range_release>:
    1bd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1bd4:	910003fd 	mov	x29, sp
    1bd8:	f9400801 	ldr	x1, [x0, #16]
    1bdc:	f9000bf3 	str	x19, [sp, #16]
    1be0:	aa0003f3 	mov	x19, x0
    1be4:	b4000061 	cbz	x1, 1bf0 <fwp_range_release+0x20>
    1be8:	f9400400 	ldr	x0, [x0, #8]
    1bec:	d63f0020 	blr	x1
    1bf0:	f9400260 	ldr	x0, [x19]
    1bf4:	f9400e61 	ldr	x1, [x19, #24]
    1bf8:	f9400bf3 	ldr	x19, [sp, #16]
    1bfc:	aa0103f0 	mov	x16, x1
    1c00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1c04:	d61f0200 	br	x16
    1c08:	d503201f 	nop
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_owned_entry32>:
    1c10:	6d400001 	ldp	d1, d0, [x0]
    1c14:	1e613800 	fsub	d0, d0, d1
    1c18:	9e660000 	fmov	x0, d0
    1c1c:	d65f03c0 	ret

0000000000001c20 <fwp_args32>:
    1c20:	d65f03c0 	ret

0000000000001c24 <fwp_owned_entry45>:
    1c24:	6d400400 	ldp	d0, d1, [x0]
    1c28:	1e612800 	fadd	d0, d0, d1
    1c2c:	9e660000 	fmov	x0, d0
    1c30:	d65f03c0 	ret

0000000000001c34 <fwp_owned_entry69>:
    1c34:	f0000021 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    1c38:	fd400001 	ldr	d1, [x0]
    1c3c:	fd422820 	ldr	d0, [x1, #1104]
    1c40:	1e610800 	fmul	d0, d0, d1
    1c44:	9e660000 	fmov	x0, d0
    1c48:	d65f03c0 	ret
    1c4c:	d503201f 	nop

0000000000001c50 <fwp_flush>:
    1c50:	f00000e0 	adrp	x0, 20000 <__data_start>
    1c54:	f9402800 	ldr	x0, [x0, #80]
    1c58:	b4000120 	cbz	x0, 1c7c <fwp_flush+0x2c>
    1c5c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1c60:	910003fd 	mov	x29, sp
    1c64:	97fffe87 	bl	1680 <fflush@plt>
    1c68:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    1c6c:	f947ec00 	ldr	x0, [x0, #4056]
    1c70:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1c74:	f9400000 	ldr	x0, [x0]
    1c78:	17fffe82 	b	1680 <fflush@plt>
    1c7c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    1c80:	f947ec00 	ldr	x0, [x0, #4056]
    1c84:	f9400000 	ldr	x0, [x0]
    1c88:	17fffe7e 	b	1680 <fflush@plt>
    1c8c:	d503201f 	nop

0000000000001c90 <fwp_segv>:
    1c90:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c94:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c98:	91014043 	add	x3, x2, #0x50
    1c9c:	910003fd 	mov	x29, sp
    1ca0:	a90153f3 	stp	x19, x20, [sp, #16]
    1ca4:	2a0003f3 	mov	w19, w0
    1ca8:	f9400460 	ldr	x0, [x3, #8]
    1cac:	f90013f5 	str	x21, [sp, #32]
    1cb0:	f9400835 	ldr	x21, [x1, #16]
    1cb4:	b4000280 	cbz	x0, 1d04 <fwp_segv+0x74>
    1cb8:	f9400814 	ldr	x20, [x0, #16]
    1cbc:	b4000254 	cbz	x20, 1d04 <fwp_segv+0x74>
    1cc0:	528003c0 	mov	w0, #0x1e                  	// #30
    1cc4:	97fffe77 	bl	16a0 <sysconf@plt>
    1cc8:	f144029f 	cmp	x20, #0x100, lsl #12
    1ccc:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1cd0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1cd4:	8b000294 	add	x20, x20, x0
    1cd8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1cdc:	eb0102bf 	cmp	x21, x1
    1ce0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1ce4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1ce8:	35000240 	cbnz	w0, 1d30 <fwp_segv+0xa0>
    1cec:	f94013f5 	ldr	x21, [sp, #32]
    1cf0:	2a1303e0 	mov	w0, w19
    1cf4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1cf8:	d2800001 	mov	x1, #0x0                   	// #0
    1cfc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1d00:	17fffdec 	b	14b0 <signal@plt>
    1d04:	91014042 	add	x2, x2, #0x50
    1d08:	f9400840 	ldr	x0, [x2, #16]
    1d0c:	b4ffff00 	cbz	x0, 1cec <fwp_segv+0x5c>
    1d10:	f9400c41 	ldr	x1, [x2, #24]
    1d14:	cb010000 	sub	x0, x0, x1
    1d18:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1d1c:	91440000 	add	x0, x0, #0x100, lsl #12
    1d20:	eb15003f 	cmp	x1, x21
    1d24:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1d28:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1d2c:	34fffe00 	cbz	w0, 1cec <fwp_segv+0x5c>
    1d30:	97ffffc8 	bl	1c50 <fwp_flush>
    1d34:	f0000021 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    1d38:	91100021 	add	x1, x1, #0x400
    1d3c:	d2800342 	mov	x2, #0x1a                  	// #26
    1d40:	52800040 	mov	w0, #0x2                   	// #2
    1d44:	97fffe13 	bl	1590 <write@plt>
    1d48:	52800ca0 	mov	w0, #0x65                  	// #101
    1d4c:	97fffda1 	bl	13d0 <_exit@plt>

0000000000001d50 <fwp_heap_oom>:
    1d50:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x15a68>
    1d54:	f947e863 	ldr	x3, [x3, #4048]
    1d58:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1d5c:	d2800262 	mov	x2, #0x13                  	// #19
    1d60:	910003fd 	mov	x29, sp
    1d64:	f9400063 	ldr	x3, [x3]
    1d68:	d2800021 	mov	x1, #0x1                   	// #1
    1d6c:	d0000020 	adrp	x0, 7000 <fwp_main_thread+0x4d0>
    1d70:	91356000 	add	x0, x0, #0xd58
    1d74:	97fffe37 	bl	1650 <fwrite@plt>
    1d78:	d2800000 	mov	x0, #0x0                   	// #0
    1d7c:	97fffe41 	bl	1680 <fflush@plt>
    1d80:	52800cc0 	mov	w0, #0x66                  	// #102
    1d84:	97fffe4f 	bl	16c0 <_Exit@plt>
    1d88:	d503201f 	nop
    1d8c:	d503201f 	nop

0000000000001d90 <fwp_heap_chunks>:
    1d90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d94:	910003fd 	mov	x29, sp
    1d98:	a90153f3 	stp	x19, x20, [sp, #16]
    1d9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1da0:	90000195 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    1da4:	9114c2a1 	add	x1, x21, #0x530
    1da8:	f100041f 	cmp	x0, #0x1
    1dac:	54000ca0 	b.eq	1f40 <fwp_heap_chunks+0x1b0>  // b.none
    1db0:	f949f822 	ldr	x2, [x1, #5104]
    1db4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xad0>
    1db8:	912480a5 	add	x5, x5, #0x920
    1dbc:	9114c2a1 	add	x1, x21, #0x530
    1dc0:	f949ec34 	ldr	x20, [x1, #5080]
    1dc4:	eb14005f 	cmp	x2, x20
    1dc8:	54000c42 	b.cs	1f50 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1dcc:	f949fc23 	ldr	x3, [x1, #5112]
    1dd0:	8b020841 	add	x1, x2, x2, lsl #2
    1dd4:	d2800004 	mov	x4, #0x0                   	// #0
    1dd8:	8b010c61 	add	x1, x3, x1, lsl #3
    1ddc:	14000009 	b	1e00 <fwp_heap_chunks+0x70>
    1de0:	91000483 	add	x3, x4, #0x1
    1de4:	eb03001f 	cmp	x0, x3
    1de8:	54000940 	b.eq	1f10 <fwp_heap_chunks+0x180>  // b.none
    1dec:	91000442 	add	x2, x2, #0x1
    1df0:	aa0303e4 	mov	x4, x3
    1df4:	9100a021 	add	x1, x1, #0x28
    1df8:	eb02029f 	cmp	x20, x2
    1dfc:	54000100 	b.eq	1e1c <fwp_heap_chunks+0x8c>  // b.none
    1e00:	39400023 	ldrb	w3, [x1]
    1e04:	34fffee3 	cbz	w3, 1de0 <fwp_heap_chunks+0x50>
    1e08:	91000442 	add	x2, x2, #0x1
    1e0c:	9100a021 	add	x1, x1, #0x28
    1e10:	d2800004 	mov	x4, #0x0                   	// #0
    1e14:	eb02029f 	cmp	x20, x2
    1e18:	54ffff41 	b.ne	1e00 <fwp_heap_chunks+0x70>  // b.any
    1e1c:	cb040294 	sub	x20, x20, x4
    1e20:	f9001bf7 	str	x23, [sp, #48]
    1e24:	9114c2b7 	add	x23, x21, #0x530
    1e28:	8b140013 	add	x19, x0, x20
    1e2c:	f94a1ae1 	ldr	x1, [x23, #5168]
    1e30:	f949f2e0 	ldr	x0, [x23, #5088]
    1e34:	cb040021 	sub	x1, x1, x4
    1e38:	f90a1ae1 	str	x1, [x23, #5168]
    1e3c:	eb00027f 	cmp	x19, x0
    1e40:	54000429 	b.ls	1ec4 <fwp_heap_chunks+0x134>  // b.plast
    1e44:	f949eae1 	ldr	x1, [x23, #5072]
    1e48:	eb01027f 	cmp	x19, x1
    1e4c:	54000888 	b.hi	1f5c <fwp_heap_chunks+0x1cc>  // b.pmore
    1e50:	91010276 	add	x22, x19, #0x40
    1e54:	52800062 	mov	w2, #0x3                   	// #3
    1e58:	f949dae3 	ldr	x3, [x23, #5040]
    1e5c:	eb0102df 	cmp	x22, x1
    1e60:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1e64:	cb0002c1 	sub	x1, x22, x0
    1e68:	8b004060 	add	x0, x3, x0, lsl #16
    1e6c:	d370bc21 	lsl	x1, x1, #16
    1e70:	97fffe20 	bl	16f0 <mprotect@plt>
    1e74:	35000740 	cbnz	w0, 1f5c <fwp_heap_chunks+0x1cc>
    1e78:	528003c0 	mov	w0, #0x1e                  	// #30
    1e7c:	97fffe09 	bl	16a0 <sysconf@plt>
    1e80:	f949f2e2 	ldr	x2, [x23, #5088]
    1e84:	cb0003e5 	neg	x5, x0
    1e88:	aa0003e4 	mov	x4, x0
    1e8c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e90:	f949fee0 	ldr	x0, [x23, #5112]
    1e94:	8b020843 	add	x3, x2, x2, lsl #2
    1e98:	52800062 	mov	w2, #0x3                   	// #3
    1e9c:	8b010c01 	add	x1, x0, x1, lsl #3
    1ea0:	8b030c03 	add	x3, x0, x3, lsl #3
    1ea4:	d1000421 	sub	x1, x1, #0x1
    1ea8:	8a050060 	and	x0, x3, x5
    1eac:	8b040021 	add	x1, x1, x4
    1eb0:	8a050021 	and	x1, x1, x5
    1eb4:	cb000021 	sub	x1, x1, x0
    1eb8:	97fffe0e 	bl	16f0 <mprotect@plt>
    1ebc:	35000500 	cbnz	w0, 1f5c <fwp_heap_chunks+0x1cc>
    1ec0:	f909f2f6 	str	x22, [x23, #5088]
    1ec4:	9114c2b5 	add	x21, x21, #0x530
    1ec8:	d370be60 	lsl	x0, x19, #16
    1ecc:	f949e6a1 	ldr	x1, [x21, #5064]
    1ed0:	f909eeb3 	str	x19, [x21, #5080]
    1ed4:	eb01001f 	cmp	x0, x1
    1ed8:	540000e8 	b.hi	1ef4 <fwp_heap_chunks+0x164>  // b.pmore
    1edc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1ee0:	aa1403e0 	mov	x0, x20
    1ee4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ee8:	f9401bf7 	ldr	x23, [sp, #48]
    1eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ef0:	d65f03c0 	ret
    1ef4:	f9401bf7 	ldr	x23, [sp, #48]
    1ef8:	f909e6a0 	str	x0, [x21, #5064]
    1efc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1f00:	aa1403e0 	mov	x0, x20
    1f04:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f08:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1f0c:	d65f03c0 	ret
    1f10:	9114c2b5 	add	x21, x21, #0x530
    1f14:	91000441 	add	x1, x2, #0x1
    1f18:	f90000a1 	str	x1, [x5]
    1f1c:	cb040054 	sub	x20, x2, x4
    1f20:	f94a1aa1 	ldr	x1, [x21, #5168]
    1f24:	cb000020 	sub	x0, x1, x0
    1f28:	f90a1aa0 	str	x0, [x21, #5168]
    1f2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1f30:	aa1403e0 	mov	x0, x20
    1f34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f38:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1f3c:	d65f03c0 	ret
    1f40:	f949f422 	ldr	x2, [x1, #5096]
    1f44:	b0000185 	adrp	x5, 32000 <fwp_heap+0xad0>
    1f48:	912460a5 	add	x5, x5, #0x918
    1f4c:	17ffff9c 	b	1dbc <fwp_heap_chunks+0x2c>
    1f50:	d2800004 	mov	x4, #0x0                   	// #0
    1f54:	f9001bf7 	str	x23, [sp, #48]
    1f58:	17ffffb3 	b	1e24 <fwp_heap_chunks+0x94>
    1f5c:	97ffff7d 	bl	1d50 <fwp_heap_oom>

0000000000001f60 <ad_raw_fail>:
    1f60:	d00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x15a68>
    1f64:	f947e884 	ldr	x4, [x4, #4048]
    1f68:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1f6c:	aa0003e3 	mov	x3, x0
    1f70:	910003fd 	mov	x29, sp
    1f74:	f9400080 	ldr	x0, [x4]
    1f78:	d0000022 	adrp	x2, 7000 <fwp_main_thread+0x4d0>
    1f7c:	9135c042 	add	x2, x2, #0xd70
    1f80:	52800041 	mov	w1, #0x2                   	// #2
    1f84:	97fffd8f 	bl	15c0 <__fprintf_chk@plt>
    1f88:	52801d00 	mov	w0, #0xe8                  	// #232
    1f8c:	97fffd1d 	bl	1400 <exit@plt>

0000000000001f90 <ad_raw_report>:
    1f90:	d101c3ff 	sub	sp, sp, #0x70
    1f94:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f98:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x15a68>
    1f9c:	f947f463 	ldr	x3, [x3, #4072]
    1fa0:	d0000022 	adrp	x2, 7000 <fwp_main_thread+0x4d0>
    1fa4:	a9037bfd 	stp	x29, x30, [sp, #48]
    1fa8:	9100c3fd 	add	x29, sp, #0x30
    1fac:	91368042 	add	x2, x2, #0xda0
    1fb0:	d2800005 	mov	x5, #0x0                   	// #0
    1fb4:	a9055bf5 	stp	x21, x22, [sp, #80]
    1fb8:	d0000036 	adrp	x22, 7000 <fwp_main_thread+0x4d0>
    1fbc:	913802d6 	add	x22, x22, #0xe00
    1fc0:	d00000f5 	adrp	x21, 1f000 <__FRAME_END__+0x15a68>
    1fc4:	f947eab5 	ldr	x21, [x21, #4048]
    1fc8:	a90453f3 	stp	x19, x20, [sp, #64]
    1fcc:	52800013 	mov	w19, #0x0                   	// #0
    1fd0:	f94002a0 	ldr	x0, [x21]
    1fd4:	f90033f7 	str	x23, [sp, #96]
    1fd8:	d0000037 	adrp	x23, 7000 <fwp_main_thread+0x4d0>
    1fdc:	913662f7 	add	x23, x23, #0xd98
    1fe0:	f9400064 	ldr	x4, [x3]
    1fe4:	f90017e4 	str	x4, [sp, #40]
    1fe8:	d2800004 	mov	x4, #0x0                   	// #0
    1fec:	d2800003 	mov	x3, #0x0                   	// #0
    1ff0:	f9403824 	ldr	x4, [x1, #112]
    1ff4:	52800041 	mov	w1, #0x2                   	// #2
    1ff8:	97fffd72 	bl	15c0 <__fprintf_chk@plt>
    1ffc:	f00000e1 	adrp	x1, 20000 <__data_start>
    2000:	91004021 	add	x1, x1, #0x10
    2004:	f94002a0 	ldr	x0, [x21]
    2008:	910023e2 	add	x2, sp, #0x8
    200c:	4c40a020 	ld1	{v0.16b-v1.16b}, [x1]
    2010:	b0000023 	adrp	x3, 7000 <fwp_main_thread+0x4d0>
    2014:	aa0203f4 	mov	x20, x2
    2018:	91364063 	add	x3, x3, #0xd90
    201c:	4c00a040 	st1	{v0.16b-v1.16b}, [x2]
    2020:	aa1603e2 	mov	x2, x22
    2024:	f8408684 	ldr	x4, [x20], #8
    2028:	d2800007 	mov	x7, #0x0                   	// #0
    202c:	d2800006 	mov	x6, #0x0                   	// #0
    2030:	d2800005 	mov	x5, #0x0                   	// #0
    2034:	52800041 	mov	w1, #0x2                   	// #2
    2038:	11000673 	add	w19, w19, #0x1
    203c:	97fffd61 	bl	15c0 <__fprintf_chk@plt>
    2040:	7100127f 	cmp	w19, #0x4
    2044:	54000080 	b.eq	2054 <ad_raw_report+0xc4>  // b.none
    2048:	f94002a0 	ldr	x0, [x21]
    204c:	aa1703e3 	mov	x3, x23
    2050:	17fffff4 	b	2020 <ad_raw_report+0x90>
    2054:	f94002a3 	ldr	x3, [x21]
    2058:	d2800262 	mov	x2, #0x13                  	// #19
    205c:	d2800021 	mov	x1, #0x1                   	// #1
    2060:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x4d0>
    2064:	91390000 	add	x0, x0, #0xe40
    2068:	97fffd7a 	bl	1650 <fwrite@plt>
    206c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    2070:	f947f400 	ldr	x0, [x0, #4072]
    2074:	f94017e2 	ldr	x2, [sp, #40]
    2078:	f9400001 	ldr	x1, [x0]
    207c:	eb010042 	subs	x2, x2, x1
    2080:	d2800001 	mov	x1, #0x0                   	// #0
    2084:	54000181 	b.ne	20b4 <ad_raw_report+0x124>  // b.any
    2088:	f94002a3 	ldr	x3, [x21]
    208c:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x4d0>
    2090:	a9437bfd 	ldp	x29, x30, [sp, #48]
    2094:	91396000 	add	x0, x0, #0xe58
    2098:	a94453f3 	ldp	x19, x20, [sp, #64]
    209c:	d2800082 	mov	x2, #0x4                   	// #4
    20a0:	a9455bf5 	ldp	x21, x22, [sp, #80]
    20a4:	d2800021 	mov	x1, #0x1                   	// #1
    20a8:	f94033f7 	ldr	x23, [sp, #96]
    20ac:	9101c3ff 	add	sp, sp, #0x70
    20b0:	17fffd68 	b	1650 <fwrite@plt>
    20b4:	97fffd27 	bl	1550 <__stack_chk_fail@plt>
    20b8:	d503201f 	nop
    20bc:	d503201f 	nop

00000000000020c0 <buf_grow>:
    20c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    20c4:	910003fd 	mov	x29, sp
    20c8:	a90153f3 	stp	x19, x20, [sp, #16]
    20cc:	aa0003f4 	mov	x20, x0
    20d0:	f9400400 	ldr	x0, [x0, #8]
    20d4:	b100041f 	cmn	x0, #0x1
    20d8:	54000400 	b.eq	2158 <buf_grow+0x98>  // b.none
    20dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    20e0:	cb000042 	sub	x2, x2, x0
    20e4:	eb01005f 	cmp	x2, x1
    20e8:	54000383 	b.cc	2158 <buf_grow+0x98>  // b.lo, b.ul, b.last
    20ec:	f9400a82 	ldr	x2, [x20, #16]
    20f0:	91000421 	add	x1, x1, #0x1
    20f4:	8b000033 	add	x19, x1, x0
    20f8:	eb13005f 	cmp	x2, x19
    20fc:	54000242 	b.cs	2144 <buf_grow+0x84>  // b.hs, b.nlast
    2100:	f100005f 	cmp	x2, #0x0
    2104:	b5000262 	cbnz	x2, 2150 <buf_grow+0x90>
    2108:	d2800802 	mov	x2, #0x40                  	// #64
    210c:	eb02027f 	cmp	x19, x2
    2110:	54000068 	b.hi	211c <buf_grow+0x5c>  // b.pmore
    2114:	14000005 	b	2128 <buf_grow+0x68>
    2118:	b7f800a2 	tbnz	x2, #63, 212c <buf_grow+0x6c>
    211c:	d37ff842 	lsl	x2, x2, #1
    2120:	eb02027f 	cmp	x19, x2
    2124:	54ffffa8 	b.hi	2118 <buf_grow+0x58>  // b.pmore
    2128:	aa0203f3 	mov	x19, x2
    212c:	f9400280 	ldr	x0, [x20]
    2130:	aa1303e1 	mov	x1, x19
    2134:	97fffd03 	bl	1540 <realloc@plt>
    2138:	b4000100 	cbz	x0, 2158 <buf_grow+0x98>
    213c:	f9000280 	str	x0, [x20]
    2140:	f9000a93 	str	x19, [x20, #16]
    2144:	a94153f3 	ldp	x19, x20, [sp, #16]
    2148:	a8c27bfd 	ldp	x29, x30, [sp], #32
    214c:	d65f03c0 	ret
    2150:	54fffe6a 	b.ge	211c <buf_grow+0x5c>  // b.tcont
    2154:	17fffff6 	b	212c <buf_grow+0x6c>
    2158:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x15a68>
    215c:	f947e863 	ldr	x3, [x3, #4048]
    2160:	d2800262 	mov	x2, #0x13                  	// #19
    2164:	d2800021 	mov	x1, #0x1                   	// #1
    2168:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x4d0>
    216c:	91356000 	add	x0, x0, #0xd58
    2170:	f9400063 	ldr	x3, [x3]
    2174:	97fffd37 	bl	1650 <fwrite@plt>
    2178:	d2800000 	mov	x0, #0x0                   	// #0
    217c:	97fffd41 	bl	1680 <fflush@plt>
    2180:	52800cc0 	mov	w0, #0x66                  	// #102
    2184:	97fffd4f 	bl	16c0 <_Exit@plt>
    2188:	d503201f 	nop
    218c:	d503201f 	nop

0000000000002190 <buf_put>:
    2190:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2194:	910003fd 	mov	x29, sp
    2198:	a90153f3 	stp	x19, x20, [sp, #16]
    219c:	aa0003f4 	mov	x20, x0
    21a0:	aa0203f3 	mov	x19, x2
    21a4:	f90013f5 	str	x21, [sp, #32]
    21a8:	aa0103f5 	mov	x21, x1
    21ac:	aa0203e1 	mov	x1, x2
    21b0:	97ffffc4 	bl	20c0 <buf_grow>
    21b4:	a9400283 	ldp	x3, x0, [x20]
    21b8:	aa1503e1 	mov	x1, x21
    21bc:	aa1303e2 	mov	x2, x19
    21c0:	8b000060 	add	x0, x3, x0
    21c4:	97fffc7b 	bl	13b0 <memcpy@plt>
    21c8:	a9400680 	ldp	x0, x1, [x20]
    21cc:	8b010273 	add	x19, x19, x1
    21d0:	f9000693 	str	x19, [x20, #8]
    21d4:	3833681f 	strb	wzr, [x0, x19]
    21d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    21dc:	f94013f5 	ldr	x21, [sp, #32]
    21e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    21e4:	d65f03c0 	ret
    21e8:	d503201f 	nop
    21ec:	d503201f 	nop

00000000000021f0 <fwp_cancel_tree.part.0>:
    21f0:	d00000e1 	adrp	x1, 20000 <__data_start>
    21f4:	91014022 	add	x2, x1, #0x50
    21f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    21fc:	52800023 	mov	w3, #0x1                   	// #1
    2200:	910003fd 	mov	x29, sp
    2204:	f9400444 	ldr	x4, [x2, #8]
    2208:	f9000bf3 	str	x19, [sp, #16]
    220c:	39014403 	strb	w3, [x0, #81]
    2210:	eb04001f 	cmp	x0, x4
    2214:	54000160 	b.eq	2240 <fwp_cancel_tree.part.0+0x50>  // b.none
    2218:	f9402804 	ldr	x4, [x0, #80]
    221c:	f2001c9f 	tst	x4, #0xff000000ff
    2220:	54000101 	b.ne	2240 <fwp_cancel_tree.part.0+0x50>  // b.any
    2224:	f9401444 	ldr	x4, [x2, #40]
    2228:	39015003 	strb	w3, [x0, #84]
    222c:	f900801f 	str	xzr, [x0, #256]
    2230:	b40001e4 	cbz	x4, 226c <fwp_cancel_tree.part.0+0x7c>
    2234:	f9008080 	str	x0, [x4, #256]
    2238:	91014021 	add	x1, x1, #0x50
    223c:	f9001420 	str	x0, [x1, #40]
    2240:	f9401413 	ldr	x19, [x0, #40]
    2244:	b40000f3 	cbz	x19, 2260 <fwp_cancel_tree.part.0+0x70>
    2248:	39414261 	ldrb	w1, [x19, #80]
    224c:	aa1303e0 	mov	x0, x19
    2250:	37000041 	tbnz	w1, #0, 2258 <fwp_cancel_tree.part.0+0x68>
    2254:	97ffffe7 	bl	21f0 <fwp_cancel_tree.part.0>
    2258:	f9401a73 	ldr	x19, [x19, #48]
    225c:	b5ffff73 	cbnz	x19, 2248 <fwp_cancel_tree.part.0+0x58>
    2260:	f9400bf3 	ldr	x19, [sp, #16]
    2264:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2268:	d65f03c0 	ret
    226c:	f9001840 	str	x0, [x2, #48]
    2270:	17fffff2 	b	2238 <fwp_cancel_tree.part.0+0x48>

0000000000002274 <fwp_finish_float>:
    2274:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2278:	528005c1 	mov	w1, #0x2e                  	// #46
    227c:	910003fd 	mov	x29, sp
    2280:	f9000bf3 	str	x19, [sp, #16]
    2284:	aa0003f3 	mov	x19, x0
    2288:	97fffcea 	bl	1630 <strchr@plt>
    228c:	b4000080 	cbz	x0, 229c <fwp_finish_float+0x28>
    2290:	f9400bf3 	ldr	x19, [sp, #16]
    2294:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2298:	d65f03c0 	ret
    229c:	aa1303e0 	mov	x0, x19
    22a0:	52800ca1 	mov	w1, #0x65                  	// #101
    22a4:	97fffce3 	bl	1630 <strchr@plt>
    22a8:	b5ffff40 	cbnz	x0, 2290 <fwp_finish_float+0x1c>
    22ac:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x4d0>
    22b0:	aa1303e0 	mov	x0, x19
    22b4:	91398021 	add	x1, x1, #0xe60
    22b8:	97fffcfe 	bl	16b0 <strstr@plt>
    22bc:	b5fffea0 	cbnz	x0, 2290 <fwp_finish_float+0x1c>
    22c0:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x4d0>
    22c4:	aa1303e0 	mov	x0, x19
    22c8:	9139a021 	add	x1, x1, #0xe68
    22cc:	97fffcf9 	bl	16b0 <strstr@plt>
    22d0:	b5fffe00 	cbnz	x0, 2290 <fwp_finish_float+0x1c>
    22d4:	aa1303e0 	mov	x0, x19
    22d8:	97fffc42 	bl	13e0 <strlen@plt>
    22dc:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x4d0>
    22e0:	9139c021 	add	x1, x1, #0xe70
    22e4:	8b000262 	add	x2, x19, x0
    22e8:	79400023 	ldrh	w3, [x1]
    22ec:	39400821 	ldrb	w1, [x1, #2]
    22f0:	78206a63 	strh	w3, [x19, x0]
    22f4:	39000841 	strb	w1, [x2, #2]
    22f8:	17ffffe6 	b	2290 <fwp_finish_float+0x1c>
    22fc:	d503201f 	nop

0000000000002300 <fwp_trap>:
    2300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2304:	910003fd 	mov	x29, sp
    2308:	f9000bf3 	str	x19, [sp, #16]
    230c:	aa0003f3 	mov	x19, x0
    2310:	97fffe50 	bl	1c50 <fwp_flush>
    2314:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x15a68>
    2318:	f947e884 	ldr	x4, [x4, #4048]
    231c:	aa1303e3 	mov	x3, x19
    2320:	b0000022 	adrp	x2, 7000 <fwp_main_thread+0x4d0>
    2324:	9139e042 	add	x2, x2, #0xe78
    2328:	52800041 	mov	w1, #0x2                   	// #2
    232c:	f9400080 	ldr	x0, [x4]
    2330:	97fffca4 	bl	15c0 <__fprintf_chk@plt>
    2334:	52800ca0 	mov	w0, #0x65                  	// #101
    2338:	97fffc32 	bl	1400 <exit@plt>
    233c:	d503201f 	nop

0000000000002340 <fwp_now_ns>:
    2340:	d100c3ff 	sub	sp, sp, #0x30
    2344:	52800020 	mov	w0, #0x1                   	// #1
    2348:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x15a68>
    234c:	f947f442 	ldr	x2, [x2, #4072]
    2350:	910023e1 	add	x1, sp, #0x8
    2354:	a9027bfd 	stp	x29, x30, [sp, #32]
    2358:	910083fd 	add	x29, sp, #0x20
    235c:	f9400043 	ldr	x3, [x2]
    2360:	f9000fe3 	str	x3, [sp, #24]
    2364:	d2800003 	mov	x3, #0x0                   	// #0
    2368:	97fffc46 	bl	1480 <clock_gettime@plt>
    236c:	350002c0 	cbnz	w0, 23c4 <fwp_now_ns+0x84>
    2370:	a9408be1 	ldp	x1, x2, [sp, #8]
    2374:	d2994003 	mov	x3, #0xca00                	// #51712
    2378:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    237c:	9b037c20 	mul	x0, x1, x3
    2380:	9b437c21 	smulh	x1, x1, x3
    2384:	ab020000 	adds	x0, x0, x2
    2388:	937ffc42 	asr	x2, x2, #63
    238c:	9a020021 	adc	x1, x1, x2
    2390:	f100001f 	cmp	x0, #0x0
    2394:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2398:	b50001e1 	cbnz	x1, 23d4 <fwp_now_ns+0x94>
    239c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15a68>
    23a0:	f947f421 	ldr	x1, [x1, #4072]
    23a4:	f9400fe3 	ldr	x3, [sp, #24]
    23a8:	f9400022 	ldr	x2, [x1]
    23ac:	eb020063 	subs	x3, x3, x2
    23b0:	d2800002 	mov	x2, #0x0                   	// #0
    23b4:	540000e1 	b.ne	23d0 <fwp_now_ns+0x90>  // b.any
    23b8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    23bc:	9100c3ff 	add	sp, sp, #0x30
    23c0:	d65f03c0 	ret
    23c4:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x4d0>
    23c8:	913a2000 	add	x0, x0, #0xe88
    23cc:	97ffffcd 	bl	2300 <fwp_trap>
    23d0:	97fffc60 	bl	1550 <__stack_chk_fail@plt>
    23d4:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x4d0>
    23d8:	913aa000 	add	x0, x0, #0xea8
    23dc:	97ffffc9 	bl	2300 <fwp_trap>

00000000000023e0 <fwp_args74>:
    23e0:	d65f03c0 	ret

00000000000023e4 <fwp_format_g.constprop.0>:
    23e4:	d10483ff 	sub	sp, sp, #0x120
    23e8:	b0000024 	adrp	x4, 7000 <fwp_main_thread+0x4d0>
    23ec:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x15a68>
    23f0:	f947f442 	ldr	x2, [x2, #4072]
    23f4:	913b4084 	add	x4, x4, #0xed0
    23f8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    23fc:	9102c3fd 	add	x29, sp, #0xb0
    2400:	d2800803 	mov	x3, #0x40                  	// #64
    2404:	a90e63f7 	stp	x23, x24, [sp, #224]
    2408:	93407c38 	sxtw	x24, w1
    240c:	aa0303e1 	mov	x1, x3
    2410:	fd008be8 	str	d8, [sp, #272]
    2414:	1e604008 	fmov	d8, d0
    2418:	a90c53f3 	stp	x19, x20, [sp, #192]
    241c:	910083f4 	add	x20, sp, #0x20
    2420:	a90d5bf5 	stp	x21, x22, [sp, #208]
    2424:	aa0003f5 	mov	x21, x0
    2428:	a91073fb 	stp	x27, x28, [sp, #256]
    242c:	5100071c 	sub	w28, w24, #0x1
    2430:	2a1c03e5 	mov	w5, w28
    2434:	f9400040 	ldr	x0, [x2]
    2438:	f90057e0 	str	x0, [sp, #168]
    243c:	d2800000 	mov	x0, #0x0                   	// #0
    2440:	52800042 	mov	w2, #0x2                   	// #2
    2444:	aa1403e0 	mov	x0, x20
    2448:	97fffc1e 	bl	14c0 <__snprintf_chk@plt>
    244c:	52800ca1 	mov	w1, #0x65                  	// #101
    2450:	aa1403e0 	mov	x0, x20
    2454:	97fffc77 	bl	1630 <strchr@plt>
    2458:	aa0003f3 	mov	x19, x0
    245c:	52800142 	mov	w2, #0xa                   	// #10
    2460:	91000400 	add	x0, x0, #0x1
    2464:	d2800001 	mov	x1, #0x0                   	// #0
    2468:	97fffc62 	bl	15f0 <strtol@plt>
    246c:	aa0003f7 	mov	x23, x0
    2470:	11001400 	add	w0, w0, #0x5
    2474:	7100541f 	cmp	w0, #0x15
    2478:	54000d88 	b.hi	2628 <fwp_format_g.constprop.0+0x244>  // b.pmore
    247c:	4b170385 	sub	w5, w28, w23
    2480:	710000bf 	cmp	w5, #0x0
    2484:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2488:	54000ba0 	b.eq	25fc <fwp_format_g.constprop.0+0x218>  // b.none
    248c:	394083e0 	ldrb	w0, [sp, #32]
    2490:	cb180273 	sub	x19, x19, x24
    2494:	91000673 	add	x19, x19, #0x1
    2498:	a90f6bf9 	stp	x25, x26, [sp, #240]
    249c:	7100b41f 	cmp	w0, #0x2d
    24a0:	9a941681 	cinc	x1, x20, eq	// eq = none
    24a4:	1a9f17e4 	cset	w4, eq	// eq = none
    24a8:	cb010266 	sub	x6, x19, x1
    24ac:	d10004da 	sub	x26, x6, #0x1
    24b0:	540018c0 	b.eq	27c8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    24b4:	910183f9 	add	x25, sp, #0x60
    24b8:	d280091b 	mov	x27, #0x48                  	// #72
    24bc:	aa1903e7 	mov	x7, x25
    24c0:	91000423 	add	x3, x1, #0x1
    24c4:	91011cc6 	add	x6, x6, #0x47
    24c8:	910004f6 	add	x22, x7, #0x1
    24cc:	37f81017 	tbnz	w23, #31, 26cc <fwp_format_g.constprop.0+0x2e8>
    24d0:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    24d4:	93407ef7 	sxtw	x23, w23
    24d8:	390000e4 	strb	w4, [x7]
    24dc:	aa1303e1 	mov	x1, x19
    24e0:	aa1703e2 	mov	x2, x23
    24e4:	aa1603e0 	mov	x0, x22
    24e8:	b9000be5 	str	w5, [sp, #8]
    24ec:	cb170374 	sub	x20, x27, x23
    24f0:	a9011be3 	stp	x3, x6, [sp, #16]
    24f4:	97fffbaf 	bl	13b0 <memcpy@plt>
    24f8:	d1000694 	sub	x20, x20, #0x1
    24fc:	f9400be3 	ldr	x3, [sp, #16]
    2500:	8b1702d6 	add	x22, x22, x23
    2504:	aa1603e0 	mov	x0, x22
    2508:	aa1a03e2 	mov	x2, x26
    250c:	aa0303e1 	mov	x1, x3
    2510:	aa1403e3 	mov	x3, x20
    2514:	97fffbe3 	bl	14a0 <__memcpy_chk@plt>
    2518:	8b1a02d6 	add	x22, x22, x26
    251c:	f9400fe6 	ldr	x6, [sp, #24]
    2520:	d2800900 	mov	x0, #0x48                  	// #72
    2524:	b9400be5 	ldr	w5, [sp, #8]
    2528:	8b170261 	add	x1, x19, x23
    252c:	cb1400c3 	sub	x3, x6, x20
    2530:	cb060294 	sub	x20, x20, x6
    2534:	f101207f 	cmp	x3, #0x48
    2538:	93407cb8 	sxtw	x24, w5
    253c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2540:	aa1803e2 	mov	x2, x24
    2544:	8b1802d3 	add	x19, x22, x24
    2548:	8b140063 	add	x3, x3, x20
    254c:	aa1603e0 	mov	x0, x22
    2550:	97fffbd4 	bl	14a0 <__memcpy_chk@plt>
    2554:	cb190273 	sub	x19, x19, x25
    2558:	d28031e0 	mov	x0, #0x18f                 	// #399
    255c:	eb00027f 	cmp	x19, x0
    2560:	aa1903e1 	mov	x1, x25
    2564:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    2568:	aa1503e0 	mov	x0, x21
    256c:	aa1303e2 	mov	x2, x19
    2570:	97fffb90 	bl	13b0 <memcpy@plt>
    2574:	38336abf 	strb	wzr, [x21, x19]
    2578:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    257c:	aa1503e0 	mov	x0, x21
    2580:	97fffb98 	bl	13e0 <strlen@plt>
    2584:	aa0003f3 	mov	x19, x0
    2588:	528005c1 	mov	w1, #0x2e                  	// #46
    258c:	aa1503e0 	mov	x0, x21
    2590:	97fffc28 	bl	1630 <strchr@plt>
    2594:	b4000160 	cbz	x0, 25c0 <fwp_format_g.constprop.0+0x1dc>
    2598:	b4000153 	cbz	x19, 25c0 <fwp_format_g.constprop.0+0x1dc>
    259c:	d503201f 	nop
    25a0:	aa1303e1 	mov	x1, x19
    25a4:	d1000673 	sub	x19, x19, #0x1
    25a8:	38736aa0 	ldrb	w0, [x21, x19]
    25ac:	7100c01f 	cmp	w0, #0x30
    25b0:	54001001 	b.ne	27b0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    25b4:	38336abf 	strb	wzr, [x21, x19]
    25b8:	b5ffff53 	cbnz	x19, 25a0 <fwp_format_g.constprop.0+0x1bc>
    25bc:	d503201f 	nop
    25c0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    25c4:	f947f400 	ldr	x0, [x0, #4072]
    25c8:	f94057e2 	ldr	x2, [sp, #168]
    25cc:	f9400001 	ldr	x1, [x0]
    25d0:	eb010042 	subs	x2, x2, x1
    25d4:	d2800001 	mov	x1, #0x0                   	// #0
    25d8:	54001061 	b.ne	27e4 <fwp_format_g.constprop.0+0x400>  // b.any
    25dc:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    25e0:	a94c53f3 	ldp	x19, x20, [sp, #192]
    25e4:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    25e8:	a94e63f7 	ldp	x23, x24, [sp, #224]
    25ec:	a95073fb 	ldp	x27, x28, [sp, #256]
    25f0:	fd408be8 	ldr	d8, [sp, #272]
    25f4:	910483ff 	add	sp, sp, #0x120
    25f8:	d65f03c0 	ret
    25fc:	1e604100 	fmov	d0, d8
    2600:	710000bf 	cmp	w5, #0x0
    2604:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2608:	aa1503e0 	mov	x0, x21
    260c:	b0000024 	adrp	x4, 7000 <fwp_main_thread+0x4d0>
    2610:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2614:	913ba084 	add	x4, x4, #0xee8
    2618:	52800042 	mov	w2, #0x2                   	// #2
    261c:	d2803201 	mov	x1, #0x190                 	// #400
    2620:	97fffba8 	bl	14c0 <__snprintf_chk@plt>
    2624:	17ffffd6 	b	257c <fwp_format_g.constprop.0+0x198>
    2628:	cb140273 	sub	x19, x19, x20
    262c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2630:	910183f9 	add	x25, sp, #0x60
    2634:	aa1303e2 	mov	x2, x19
    2638:	aa1403e1 	mov	x1, x20
    263c:	aa1903e0 	mov	x0, x25
    2640:	d2800803 	mov	x3, #0x40                  	// #64
    2644:	97fffb97 	bl	14a0 <__memcpy_chk@plt>
    2648:	38336b3f 	strb	wzr, [x25, x19]
    264c:	aa1903e0 	mov	x0, x25
    2650:	528005c1 	mov	w1, #0x2e                  	// #46
    2654:	97fffbf7 	bl	1630 <strchr@plt>
    2658:	b40001c0 	cbz	x0, 2690 <fwp_format_g.constprop.0+0x2ac>
    265c:	b50000b3 	cbnz	x19, 2670 <fwp_format_g.constprop.0+0x28c>
    2660:	1400000c 	b	2690 <fwp_format_g.constprop.0+0x2ac>
    2664:	381ff01f 	sturb	wzr, [x0, #-1]
    2668:	f1000673 	subs	x19, x19, #0x1
    266c:	54000120 	b.eq	2690 <fwp_format_g.constprop.0+0x2ac>  // b.none
    2670:	8b130320 	add	x0, x25, x19
    2674:	385ff001 	ldurb	w1, [x0, #-1]
    2678:	7100c03f 	cmp	w1, #0x30
    267c:	54ffff40 	b.eq	2664 <fwp_format_g.constprop.0+0x280>  // b.none
    2680:	d1000673 	sub	x19, x19, #0x1
    2684:	38736b20 	ldrb	w0, [x25, x19]
    2688:	7100b81f 	cmp	w0, #0x2e
    268c:	54000a80 	b.eq	27dc <fwp_format_g.constprop.0+0x3f8>  // b.none
    2690:	710002ff 	cmp	w23, #0x0
    2694:	528005a1 	mov	w1, #0x2d                  	// #45
    2698:	aa1903e5 	mov	x5, x25
    269c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    26a0:	aa1503e0 	mov	x0, x21
    26a4:	52800566 	mov	w6, #0x2b                  	// #43
    26a8:	b0000024 	adrp	x4, 7000 <fwp_main_thread+0x4d0>
    26ac:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    26b0:	913b6084 	add	x4, x4, #0xed8
    26b4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    26b8:	52800042 	mov	w2, #0x2                   	// #2
    26bc:	d2803201 	mov	x1, #0x190                 	// #400
    26c0:	97fffb80 	bl	14c0 <__snprintf_chk@plt>
    26c4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    26c8:	17ffffbe 	b	25c0 <fwp_format_g.constprop.0+0x1dc>
    26cc:	52800605 	mov	w5, #0x30                  	// #48
    26d0:	390000e5 	strb	w5, [x7]
    26d4:	d100077b 	sub	x27, x27, #0x1
    26d8:	aa0303e1 	mov	x1, x3
    26dc:	aa1603e0 	mov	x0, x22
    26e0:	aa1b03e3 	mov	x3, x27
    26e4:	aa1a03e2 	mov	x2, x26
    26e8:	f90007e6 	str	x6, [sp, #8]
    26ec:	b90013e4 	str	w4, [sp, #16]
    26f0:	8b1a02d6 	add	x22, x22, x26
    26f4:	b9001be5 	str	w5, [sp, #24]
    26f8:	97fffb6a 	bl	14a0 <__memcpy_chk@plt>
    26fc:	f94007e6 	ldr	x6, [sp, #8]
    2700:	2a3703e7 	mvn	w7, w23
    2704:	b94013e4 	ldr	w4, [sp, #16]
    2708:	cb1b00c1 	sub	x1, x6, x27
    270c:	cb06037b 	sub	x27, x27, x6
    2710:	f101203f 	cmp	x1, #0x48
    2714:	d2800906 	mov	x6, #0x48                  	// #72
    2718:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    271c:	8b1b0023 	add	x3, x1, x27
    2720:	310006ff 	cmn	w23, #0x1
    2724:	54000220 	b.eq	2768 <fwp_format_g.constprop.0+0x384>  // b.none
    2728:	b9401be5 	ldr	w5, [sp, #24]
    272c:	d2800001 	mov	x1, #0x0                   	// #0
    2730:	f101207f 	cmp	x3, #0x48
    2734:	d1000462 	sub	x2, x3, #0x1
    2738:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    273c:	38216ac5 	strb	w5, [x22, x1]
    2740:	cb030003 	sub	x3, x0, x3
    2744:	91000421 	add	x1, x1, #0x1
    2748:	91000463 	add	x3, x3, #0x1
    274c:	eb00007f 	cmp	x3, x0
    2750:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2754:	cb000063 	sub	x3, x3, x0
    2758:	8b020063 	add	x3, x3, x2
    275c:	6b0100ff 	cmp	w7, w1
    2760:	54fffe8c 	b.gt	2730 <fwp_format_g.constprop.0+0x34c>
    2764:	8b2742d6 	add	x22, x22, w7, uxtw
    2768:	f101207f 	cmp	x3, #0x48
    276c:	d2800905 	mov	x5, #0x48                  	// #72
    2770:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    2774:	aa1603e0 	mov	x0, x22
    2778:	cb0300a1 	sub	x1, x5, x3
    277c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    2780:	91000421 	add	x1, x1, #0x1
    2784:	d1000463 	sub	x3, x3, #0x1
    2788:	eb05003f 	cmp	x1, x5
    278c:	38001402 	strb	w2, [x0], #1
    2790:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    2794:	93407f82 	sxtw	x2, w28
    2798:	cb050025 	sub	x5, x1, x5
    279c:	aa1303e1 	mov	x1, x19
    27a0:	8b0300a3 	add	x3, x5, x3
    27a4:	8b1802d3 	add	x19, x22, x24
    27a8:	97fffb3e 	bl	14a0 <__memcpy_chk@plt>
    27ac:	17ffff6a 	b	2554 <fwp_format_g.constprop.0+0x170>
    27b0:	d1000421 	sub	x1, x1, #0x1
    27b4:	38616aa0 	ldrb	w0, [x21, x1]
    27b8:	7100b81f 	cmp	w0, #0x2e
    27bc:	54fff021 	b.ne	25c0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    27c0:	38216abf 	strb	wzr, [x21, x1]
    27c4:	17ffff7f 	b	25c0 <fwp_format_g.constprop.0+0x1dc>
    27c8:	910187e7 	add	x7, sp, #0x61
    27cc:	910183f9 	add	x25, sp, #0x60
    27d0:	d28008fb 	mov	x27, #0x47                  	// #71
    27d4:	390183e0 	strb	w0, [sp, #96]
    27d8:	17ffff3a 	b	24c0 <fwp_format_g.constprop.0+0xdc>
    27dc:	38336b3f 	strb	wzr, [x25, x19]
    27e0:	17ffffac 	b	2690 <fwp_format_g.constprop.0+0x2ac>
    27e4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    27e8:	97fffb5a 	bl	1550 <__stack_chk_fail@plt>
    27ec:	d503201f 	nop

00000000000027f0 <fwp_heap_report>:
    27f0:	d105c3ff 	sub	sp, sp, #0x170
    27f4:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    27f8:	9114c042 	add	x2, x2, #0x530
    27fc:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15a68>
    2800:	f947e821 	ldr	x1, [x1, #4048]
    2804:	a9117bfd 	stp	x29, x30, [sp, #272]
    2808:	910443fd 	add	x29, sp, #0x110
    280c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    2810:	f947f400 	ldr	x0, [x0, #4072]
    2814:	a9135bf5 	stp	x21, x22, [sp, #304]
    2818:	a91463f7 	stp	x23, x24, [sp, #320]
    281c:	a9156bf9 	stp	x25, x26, [sp, #336]
    2820:	6d1627e8 	stp	d8, d9, [sp, #352]
    2824:	fd4a1c48 	ldr	d8, [x2, #5176]
    2828:	fd4a2049 	ldr	d9, [x2, #5184]
    282c:	f9400036 	ldr	x22, [x1]
    2830:	f9400001 	ldr	x1, [x0]
    2834:	f90087e1 	str	x1, [sp, #264]
    2838:	d2800001 	mov	x1, #0x0                   	// #0
    283c:	f949e459 	ldr	x25, [x2, #5064]
    2840:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x4d0>
    2844:	f94a1057 	ldr	x23, [x2, #5152]
    2848:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x4d0>
    284c:	f94a1458 	ldr	x24, [x2, #5160]
    2850:	913bc021 	add	x1, x1, #0xef0
    2854:	913be000 	add	x0, x0, #0xef8
    2858:	97fffb22 	bl	14e0 <fopen@plt>
    285c:	b4000740 	cbz	x0, 2944 <fwp_heap_report+0x154>
    2860:	528daad5 	mov	w21, #0x6d56                	// #27990
    2864:	a91253f3 	stp	x19, x20, [sp, #288]
    2868:	aa0003f4 	mov	x20, x0
    286c:	910023f3 	add	x19, sp, #0x8
    2870:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2874:	72aae915 	movk	w21, #0x5748, lsl #16
    2878:	aa1403e2 	mov	x2, x20
    287c:	aa1303e0 	mov	x0, x19
    2880:	52802001 	mov	w1, #0x100                 	// #256
    2884:	97fffb9f 	bl	1700 <fgets@plt>
    2888:	b4000280 	cbz	x0, 28d8 <fwp_heap_report+0xe8>
    288c:	b9400261 	ldr	w1, [x19]
    2890:	6b15003f 	cmp	w1, w21
    2894:	54ffff21 	b.ne	2878 <fwp_heap_report+0x88>  // b.any
    2898:	39401260 	ldrb	w0, [x19, #4]
    289c:	7101341f 	cmp	w0, #0x4d
    28a0:	54fffec1 	b.ne	2878 <fwp_heap_report+0x88>  // b.any
    28a4:	394037e0 	ldrb	w0, [sp, #13]
    28a8:	7100e81f 	cmp	w0, #0x3a
    28ac:	54fffe61 	b.ne	2878 <fwp_heap_report+0x88>  // b.any
    28b0:	52800142 	mov	w2, #0xa                   	// #10
    28b4:	d2800001 	mov	x1, #0x0                   	// #0
    28b8:	91003be0 	add	x0, sp, #0xe
    28bc:	97fffb4d 	bl	15f0 <strtol@plt>
    28c0:	aa1403e2 	mov	x2, x20
    28c4:	aa0003fa 	mov	x26, x0
    28c8:	52802001 	mov	w1, #0x100                 	// #256
    28cc:	aa1303e0 	mov	x0, x19
    28d0:	97fffb8c 	bl	1700 <fgets@plt>
    28d4:	b5fffdc0 	cbnz	x0, 288c <fwp_heap_report+0x9c>
    28d8:	aa1403e0 	mov	x0, x20
    28dc:	97fffafd 	bl	14d0 <fclose@plt>
    28e0:	a95253f3 	ldp	x19, x20, [sp, #288]
    28e4:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    28e8:	f947f400 	ldr	x0, [x0, #4072]
    28ec:	f94087e2 	ldr	x2, [sp, #264]
    28f0:	f9400001 	ldr	x1, [x0]
    28f4:	eb010042 	subs	x2, x2, x1
    28f8:	d2800001 	mov	x1, #0x0                   	// #0
    28fc:	54000281 	b.ne	294c <fwp_heap_report+0x15c>  // b.any
    2900:	a9517bfd 	ldp	x29, x30, [sp, #272]
    2904:	aa1a03e6 	mov	x6, x26
    2908:	aa1903e5 	mov	x5, x25
    290c:	aa1803e4 	mov	x4, x24
    2910:	a9556bf9 	ldp	x25, x26, [sp, #336]
    2914:	aa1703e3 	mov	x3, x23
    2918:	a95463f7 	ldp	x23, x24, [sp, #320]
    291c:	aa1603e0 	mov	x0, x22
    2920:	a9535bf5 	ldp	x21, x22, [sp, #304]
    2924:	1e604121 	fmov	d1, d9
    2928:	1e604100 	fmov	d0, d8
    292c:	b0000022 	adrp	x2, 7000 <fwp_main_thread+0x4d0>
    2930:	6d5627e8 	ldp	d8, d9, [sp, #352]
    2934:	913c6042 	add	x2, x2, #0xf18
    2938:	9105c3ff 	add	sp, sp, #0x170
    293c:	52800041 	mov	w1, #0x2                   	// #2
    2940:	17fffb20 	b	15c0 <__fprintf_chk@plt>
    2944:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2948:	17ffffe7 	b	28e4 <fwp_heap_report+0xf4>
    294c:	a91253f3 	stp	x19, x20, [sp, #288]
    2950:	97fffb00 	bl	1550 <__stack_chk_fail@plt>

0000000000002954 <fwp_heap_init>:
    2954:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2958:	90000183 	adrp	x3, 32000 <fwp_heap+0xad0>
    295c:	9110c061 	add	x1, x3, #0x430
    2960:	910003fd 	mov	x29, sp
    2964:	a90153f3 	stp	x19, x20, [sp, #16]
    2968:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    296c:	9114c262 	add	x2, x19, #0x530
    2970:	a9025bf5 	stp	x21, x22, [sp, #32]
    2974:	52800024 	mov	w4, #0x1                   	// #1
    2978:	52800200 	mov	w0, #0x10                  	// #16
    297c:	b913a444 	str	w4, [x2, #5028]
    2980:	b8004420 	str	w0, [x1], #4
    2984:	11004000 	add	w0, w0, #0x10
    2988:	7104401f 	cmp	w0, #0x110
    298c:	54ffffa1 	b.ne	2980 <fwp_heap_init+0x2c>  // b.any
    2990:	d0000022 	adrp	x2, 8000 <_IO_stdin_used+0x2b0>
    2994:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2998:	90000181 	adrp	x1, 32000 <fwp_heap+0xad0>
    299c:	9111c021 	add	x1, x1, #0x470
    29a0:	3dc10c43 	ldr	q3, [x2, #1072]
    29a4:	d2800000 	mov	x0, #0x0                   	// #0
    29a8:	4e040401 	dup	v1.4s, v0.s[0]
    29ac:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    29b0:	0f215400 	shl	v0.2s, v0.2s, #1
    29b4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    29b8:	3ca06821 	str	q1, [x1, x0]
    29bc:	91004000 	add	x0, x0, #0x10
    29c0:	f101801f 	cmp	x0, #0x60
    29c4:	54ffff21 	b.ne	29a8 <fwp_heap_init+0x54>  // b.any
    29c8:	90000184 	adrp	x4, 32000 <fwp_heap+0xad0>
    29cc:	9110c063 	add	x3, x3, #0x430
    29d0:	91134084 	add	x4, x4, #0x4d0
    29d4:	9114c266 	add	x6, x19, #0x530
    29d8:	d2800002 	mov	x2, #0x0                   	// #0
    29dc:	d2800000 	mov	x0, #0x0                   	// #0
    29e0:	d2880205 	mov	x5, #0x4010                	// #16400
    29e4:	d503201f 	nop
    29e8:	910f0001 	add	x1, x0, #0x3c0
    29ec:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    29f0:	eb02003f 	cmp	x1, x2
    29f4:	540000a2 	b.cs	2a08 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    29f8:	91000400 	add	x0, x0, #0x1
    29fc:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2a00:	eb02003f 	cmp	x1, x2
    2a04:	54ffffa3 	b.cc	29f8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    2a08:	91004042 	add	x2, x2, #0x10
    2a0c:	38001480 	strb	w0, [x4], #1
    2a10:	eb05005f 	cmp	x2, x5
    2a14:	54fffea1 	b.ne	29e8 <fwp_heap_init+0x94>  // b.any
    2a18:	528000b5 	mov	w21, #0x5                   	// #5
    2a1c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    2a20:	14000004 	b	2a30 <fwp_heap_init+0xdc>
    2a24:	d342fe94 	lsr	x20, x20, #2
    2a28:	710006b5 	subs	w21, w21, #0x1
    2a2c:	54000720 	b.eq	2b10 <fwp_heap_init+0x1bc>  // b.none
    2a30:	91404296 	add	x22, x20, #0x10, lsl #12
    2a34:	d2800005 	mov	x5, #0x0                   	// #0
    2a38:	aa1603e1 	mov	x1, x22
    2a3c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a40:	52880443 	mov	w3, #0x4022                	// #16418
    2a44:	52800002 	mov	w2, #0x0                   	// #0
    2a48:	d2800000 	mov	x0, #0x0                   	// #0
    2a4c:	97fffae5 	bl	15e0 <mmap@plt>
    2a50:	aa0003e6 	mov	x6, x0
    2a54:	b100041f 	cmn	x0, #0x1
    2a58:	54fffe60 	b.eq	2a24 <fwp_heap_init+0xd0>  // b.none
    2a5c:	b40005a0 	cbz	x0, 2b10 <fwp_heap_init+0x1bc>
    2a60:	d350fe94 	lsr	x20, x20, #16
    2a64:	d29fffe0 	mov	x0, #0xffff                	// #65535
    2a68:	8b0000c7 	add	x7, x6, x0
    2a6c:	9114c275 	add	x21, x19, #0x530
    2a70:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    2a74:	8b140a81 	add	x1, x20, x20, lsl #2
    2a78:	d2800005 	mov	x5, #0x0                   	// #0
    2a7c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a80:	d37df021 	lsl	x1, x1, #3
    2a84:	52880443 	mov	w3, #0x4022                	// #16418
    2a88:	52800002 	mov	w2, #0x0                   	// #0
    2a8c:	d2800000 	mov	x0, #0x0                   	// #0
    2a90:	f909daa7 	str	x7, [x21, #5040]
    2a94:	f909dea6 	str	x6, [x21, #5048]
    2a98:	f909e2b6 	str	x22, [x21, #5056]
    2a9c:	f909eab4 	str	x20, [x21, #5072]
    2aa0:	f90a02a1 	str	x1, [x21, #5120]
    2aa4:	97fffacf 	bl	15e0 <mmap@plt>
    2aa8:	aa0003e1 	mov	x1, x0
    2aac:	b100041f 	cmn	x0, #0x1
    2ab0:	54000300 	b.eq	2b10 <fwp_heap_init+0x1bc>  // b.none
    2ab4:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x4d0>
    2ab8:	913f2000 	add	x0, x0, #0xfc8
    2abc:	f909fea1 	str	x1, [x21, #5112]
    2ac0:	97fffb08 	bl	16e0 <getenv@plt>
    2ac4:	52800002 	mov	w2, #0x0                   	// #0
    2ac8:	aa0003e1 	mov	x1, x0
    2acc:	b40000e0 	cbz	x0, 2ae8 <fwp_heap_init+0x194>
    2ad0:	39400000 	ldrb	w0, [x0]
    2ad4:	340000a0 	cbz	w0, 2ae8 <fwp_heap_init+0x194>
    2ad8:	7100c000 	subs	w0, w0, #0x30
    2adc:	54000120 	b.eq	2b00 <fwp_heap_init+0x1ac>  // b.none
    2ae0:	7100001f 	cmp	w0, #0x0
    2ae4:	1a9f07e2 	cset	w2, ne	// ne = any
    2ae8:	9114c273 	add	x19, x19, #0x530
    2aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2af0:	b913aa62 	str	w2, [x19, #5032]
    2af4:	a94153f3 	ldp	x19, x20, [sp, #16]
    2af8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2afc:	d65f03c0 	ret
    2b00:	39400420 	ldrb	w0, [x1, #1]
    2b04:	7100001f 	cmp	w0, #0x0
    2b08:	1a9f07e2 	cset	w2, ne	// ne = any
    2b0c:	17fffff7 	b	2ae8 <fwp_heap_init+0x194>
    2b10:	97fffc90 	bl	1d50 <fwp_heap_oom>

0000000000002b14 <fwp_args45>:
    2b14:	d65f03c0 	ret
    2b18:	d503201f 	nop
    2b1c:	d503201f 	nop

0000000000002b20 <fwp_args69>:
    2b20:	d65f03c0 	ret

0000000000002b24 <fwp_wake_io>:
    2b24:	d00000e9 	adrp	x9, 20000 <__data_start>
    2b28:	91014122 	add	x2, x9, #0x50
    2b2c:	f9400001 	ldr	x1, [x0]
    2b30:	5280000a 	mov	w10, #0x0                   	// #0
    2b34:	f9401446 	ldr	x6, [x2, #40]
    2b38:	52800008 	mov	w8, #0x0                   	// #0
    2b3c:	4f000400 	movi	v0.4s, #0x0
    2b40:	52800027 	mov	w7, #0x1                   	// #1
    2b44:	aa0103e2 	mov	x2, x1
    2b48:	b4000321 	cbz	x1, 2bac <fwp_wake_io+0x88>
    2b4c:	f9408c25 	ldr	x5, [x1, #280]
    2b50:	39015c27 	strb	w7, [x1, #87]
    2b54:	b4000165 	cbz	x5, 2b80 <fwp_wake_io+0x5c>
    2b58:	a9520c24 	ldp	x4, x3, [x1, #288]
    2b5c:	b4000364 	cbz	x4, 2bc8 <fwp_wake_io+0xa4>
    2b60:	f9009483 	str	x3, [x4, #296]
    2b64:	f9409423 	ldr	x3, [x1, #296]
    2b68:	b4000043 	cbz	x3, 2b70 <fwp_wake_io+0x4c>
    2b6c:	f9009064 	str	x4, [x3, #288]
    2b70:	91080023 	add	x3, x1, #0x200
    2b74:	f900943f 	str	xzr, [x1, #296]
    2b78:	3c918060 	stur	q0, [x3, #-232]
    2b7c:	f9400001 	ldr	x1, [x0]
    2b80:	f9402843 	ldr	x3, [x2, #80]
    2b84:	f2001c7f 	tst	x3, #0xff000000ff
    2b88:	54fffde1 	b.ne	2b44 <fwp_wake_io+0x20>  // b.any
    2b8c:	39015047 	strb	w7, [x2, #84]
    2b90:	f900805f 	str	xzr, [x2, #256]
    2b94:	b40001e6 	cbz	x6, 2bd0 <fwp_wake_io+0xac>
    2b98:	f90080c2 	str	x2, [x6, #256]
    2b9c:	aa0203e6 	mov	x6, x2
    2ba0:	52800028 	mov	w8, #0x1                   	// #1
    2ba4:	aa0103e2 	mov	x2, x1
    2ba8:	b5fffd21 	cbnz	x1, 2b4c <fwp_wake_io+0x28>
    2bac:	3400006a 	cbz	w10, 2bb8 <fwp_wake_io+0x94>
    2bb0:	91014120 	add	x0, x9, #0x50
    2bb4:	f900180b 	str	x11, [x0, #48]
    2bb8:	34000068 	cbz	w8, 2bc4 <fwp_wake_io+0xa0>
    2bbc:	91014129 	add	x9, x9, #0x50
    2bc0:	f9001526 	str	x6, [x9, #40]
    2bc4:	d65f03c0 	ret
    2bc8:	f90000a3 	str	x3, [x5]
    2bcc:	17ffffe7 	b	2b68 <fwp_wake_io+0x44>
    2bd0:	aa0203eb 	mov	x11, x2
    2bd4:	5280002a 	mov	w10, #0x1                   	// #1
    2bd8:	17fffff1 	b	2b9c <fwp_wake_io+0x78>
    2bdc:	d503201f 	nop

0000000000002be0 <fwp_poll_events>:
    2be0:	d10103ff 	sub	sp, sp, #0x40
    2be4:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    2be8:	f947f400 	ldr	x0, [x0, #4072]
    2bec:	a9027bfd 	stp	x29, x30, [sp, #32]
    2bf0:	910083fd 	add	x29, sp, #0x20
    2bf4:	a90353f3 	stp	x19, x20, [sp, #48]
    2bf8:	d00000f4 	adrp	x20, 20000 <__data_start>
    2bfc:	f9400001 	ldr	x1, [x0]
    2c00:	f9000fe1 	str	x1, [sp, #24]
    2c04:	d2800001 	mov	x1, #0x0                   	// #0
    2c08:	97fffdce 	bl	2340 <fwp_now_ns>
    2c0c:	91014281 	add	x1, x20, #0x50
    2c10:	f9401c33 	ldr	x19, [x1, #56]
    2c14:	b4000e93 	cbz	x19, 2de4 <fwp_poll_events+0x204>
    2c18:	aa1303e1 	mov	x1, x19
    2c1c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2c20:	14000005 	b	2c34 <fwp_poll_events+0x54>
    2c24:	f9408821 	ldr	x1, [x1, #272]
    2c28:	eb03005f 	cmp	x2, x3
    2c2c:	9a83d042 	csel	x2, x2, x3, le
    2c30:	b40000c1 	cbz	x1, 2c48 <fwp_poll_events+0x68>
    2c34:	f9403423 	ldr	x3, [x1, #104]
    2c38:	b6ffff62 	tbz	x2, #63, 2c24 <fwp_poll_events+0x44>
    2c3c:	f9408821 	ldr	x1, [x1, #272]
    2c40:	aa0303e2 	mov	x2, x3
    2c44:	b5ffff81 	cbnz	x1, 2c34 <fwp_poll_events+0x54>
    2c48:	b7f80ce2 	tbnz	x2, #63, 2de4 <fwp_poll_events+0x204>
    2c4c:	cb000042 	sub	x2, x2, x0
    2c50:	f100005f 	cmp	x2, #0x0
    2c54:	540005cd 	b.le	2d0c <fwp_poll_events+0x12c>
    2c58:	d2869b60 	mov	x0, #0x34db                	// #13531
    2c5c:	d2884801 	mov	x1, #0x4240                	// #16960
    2c60:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2c64:	f2a001e1 	movk	x1, #0xf, lsl #16
    2c68:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2c6c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2c70:	f2e86360 	movk	x0, #0x431b, lsl #48
    2c74:	9b407c40 	smulh	x0, x2, x0
    2c78:	9352fc00 	asr	x0, x0, #18
    2c7c:	cb82fc00 	sub	x0, x0, x2, asr #63
    2c80:	9b018802 	msub	x2, x0, x1, x2
    2c84:	f100005f 	cmp	x2, #0x0
    2c88:	9a800400 	cinc	x0, x0, ne	// ne = any
    2c8c:	eb03001f 	cmp	x0, x3
    2c90:	54000a0c 	b.gt	2dd0 <fwp_poll_events+0x1f0>
    2c94:	340003c0 	cbz	w0, 2d0c <fwp_poll_events+0x12c>
    2c98:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2c9c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2ca0:	72a20c42 	movk	w2, #0x1062, lsl #16
    2ca4:	9ba27c02 	umull	x2, w0, w2
    2ca8:	d366fc43 	lsr	x3, x2, #38
    2cac:	aa0303e2 	mov	x2, x3
    2cb0:	1b048063 	msub	w3, w3, w4, w0
    2cb4:	9b217c63 	smull	x3, w3, w1
    2cb8:	d2800001 	mov	x1, #0x0                   	// #0
    2cbc:	910023e0 	add	x0, sp, #0x8
    2cc0:	a9008fe2 	stp	x2, x3, [sp, #8]
    2cc4:	97fffa57 	bl	1620 <nanosleep@plt>
    2cc8:	91014280 	add	x0, x20, #0x50
    2ccc:	f9401c13 	ldr	x19, [x0, #56]
    2cd0:	97fffd9c 	bl	2340 <fwp_now_ns>
    2cd4:	aa0003e6 	mov	x6, x0
    2cd8:	b50001f3 	cbnz	x19, 2d14 <fwp_poll_events+0x134>
    2cdc:	d503201f 	nop
    2ce0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    2ce4:	f947f400 	ldr	x0, [x0, #4072]
    2ce8:	f9400fe2 	ldr	x2, [sp, #24]
    2cec:	f9400001 	ldr	x1, [x0]
    2cf0:	eb010042 	subs	x2, x2, x1
    2cf4:	d2800001 	mov	x1, #0x0                   	// #0
    2cf8:	540008c1 	b.ne	2e10 <fwp_poll_events+0x230>  // b.any
    2cfc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2d00:	a94353f3 	ldp	x19, x20, [sp, #48]
    2d04:	910103ff 	add	sp, sp, #0x40
    2d08:	d65f03c0 	ret
    2d0c:	97fffd8d 	bl	2340 <fwp_now_ns>
    2d10:	aa0003e6 	mov	x6, x0
    2d14:	4f000400 	movi	v0.4s, #0x0
    2d18:	91014288 	add	x8, x20, #0x50
    2d1c:	52800027 	mov	w7, #0x1                   	// #1
    2d20:	f9403661 	ldr	x1, [x19, #104]
    2d24:	aa1303e5 	mov	x5, x19
    2d28:	f9408a73 	ldr	x19, [x19, #272]
    2d2c:	eb06003f 	cmp	x1, x6
    2d30:	5400032c 	b.gt	2d94 <fwp_poll_events+0x1b4>
    2d34:	394154a0 	ldrb	w0, [x5, #85]
    2d38:	36000120 	tbz	w0, #0, 2d5c <fwp_poll_events+0x17c>
    2d3c:	f94084a0 	ldr	x0, [x5, #264]
    2d40:	b40003c0 	cbz	x0, 2db8 <fwp_poll_events+0x1d8>
    2d44:	f9008813 	str	x19, [x0, #272]
    2d48:	b4000053 	cbz	x19, 2d50 <fwp_poll_events+0x170>
    2d4c:	f9008660 	str	x0, [x19, #264]
    2d50:	910800a0 	add	x0, x5, #0x200
    2d54:	390154bf 	strb	wzr, [x5, #85]
    2d58:	3c908000 	stur	q0, [x0, #-248]
    2d5c:	f94030a0 	ldr	x0, [x5, #96]
    2d60:	390158a7 	strb	w7, [x5, #86]
    2d64:	f100001f 	cmp	x0, #0x0
    2d68:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2d6c:	5400018d 	b.le	2d9c <fwp_poll_events+0x1bc>
    2d70:	f94028a0 	ldr	x0, [x5, #80]
    2d74:	f2001c1f 	tst	x0, #0xff000000ff
    2d78:	540000e1 	b.ne	2d94 <fwp_poll_events+0x1b4>  // b.any
    2d7c:	f9401500 	ldr	x0, [x8, #40]
    2d80:	390150a7 	strb	w7, [x5, #84]
    2d84:	f90080bf 	str	xzr, [x5, #256]
    2d88:	b40001e0 	cbz	x0, 2dc4 <fwp_poll_events+0x1e4>
    2d8c:	f9001505 	str	x5, [x8, #40]
    2d90:	f9008005 	str	x5, [x0, #256]
    2d94:	b5fffc73 	cbnz	x19, 2d20 <fwp_poll_events+0x140>
    2d98:	17ffffd2 	b	2ce0 <fwp_poll_events+0x100>
    2d9c:	394144a0 	ldrb	w0, [x5, #81]
    2da0:	3707fe80 	tbnz	w0, #0, 2d70 <fwp_poll_events+0x190>
    2da4:	394140a0 	ldrb	w0, [x5, #80]
    2da8:	3707fe40 	tbnz	w0, #0, 2d70 <fwp_poll_events+0x190>
    2dac:	aa0503e0 	mov	x0, x5
    2db0:	97fffd10 	bl	21f0 <fwp_cancel_tree.part.0>
    2db4:	17ffffef 	b	2d70 <fwp_poll_events+0x190>
    2db8:	91014281 	add	x1, x20, #0x50
    2dbc:	f9001c33 	str	x19, [x1, #56]
    2dc0:	17ffffe2 	b	2d48 <fwp_poll_events+0x168>
    2dc4:	f9001505 	str	x5, [x8, #40]
    2dc8:	f9001905 	str	x5, [x8, #48]
    2dcc:	17fffff2 	b	2d94 <fwp_poll_events+0x1b4>
    2dd0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2dd4:	d2989362 	mov	x2, #0xc49b                	// #50331
    2dd8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2ddc:	f2a00402 	movk	x2, #0x20, lsl #16
    2de0:	17ffffb6 	b	2cb8 <fwp_poll_events+0xd8>
    2de4:	97fffb9b 	bl	1c50 <fwp_flush>
    2de8:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x15a68>
    2dec:	f947e863 	ldr	x3, [x3, #4048]
    2df0:	d2800562 	mov	x2, #0x2b                  	// #43
    2df4:	d2800021 	mov	x1, #0x1                   	// #1
    2df8:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x4d0>
    2dfc:	913f6000 	add	x0, x0, #0xfd8
    2e00:	f9400063 	ldr	x3, [x3]
    2e04:	97fffa13 	bl	1650 <fwrite@plt>
    2e08:	52800ca0 	mov	w0, #0x65                  	// #101
    2e0c:	97fff97d 	bl	1400 <exit@plt>
    2e10:	97fff9d0 	bl	1550 <__stack_chk_fail@plt>

0000000000002e14 <fwp_rc_wide_dup>:
    2e14:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2e18:	910003fd 	mov	x29, sp
    2e1c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e20:	aa0003f3 	mov	x19, x0
    2e24:	ca404400 	eor	x0, x0, x0, lsr #17
    2e28:	f90013f5 	str	x21, [sp, #32]
    2e2c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    2e30:	ca402400 	eor	x0, x0, x0, lsr #9
    2e34:	9114c2a2 	add	x2, x21, #0x530
    2e38:	92401c00 	and	x0, x0, #0xff
    2e3c:	910a2403 	add	x3, x0, #0x289
    2e40:	8b000c40 	add	x0, x2, x0, lsl #3
    2e44:	8b030c54 	add	x20, x2, x3, lsl #3
    2e48:	f94a2401 	ldr	x1, [x0, #5192]
    2e4c:	b50000a1 	cbnz	x1, 2e60 <fwp_rc_wide_dup+0x4c>
    2e50:	1400002d 	b	2f04 <fwp_rc_wide_dup+0xf0>
    2e54:	91004034 	add	x20, x1, #0x10
    2e58:	f9400821 	ldr	x1, [x1, #16]
    2e5c:	b4000241 	cbz	x1, 2ea4 <fwp_rc_wide_dup+0x90>
    2e60:	f9400022 	ldr	x2, [x1]
    2e64:	eb02027f 	cmp	x19, x2
    2e68:	54ffff61 	b.ne	2e54 <fwp_rc_wide_dup+0x40>  // b.any
    2e6c:	f9400281 	ldr	x1, [x20]
    2e70:	39400260 	ldrb	w0, [x19]
    2e74:	7103f81f 	cmp	w0, #0xfe
    2e78:	54000220 	b.eq	2ebc <fwp_rc_wide_dup+0xa8>  // b.none
    2e7c:	b40001a1 	cbz	x1, 2eb0 <fwp_rc_wide_dup+0x9c>
    2e80:	f9400420 	ldr	x0, [x1, #8]
    2e84:	b100041f 	cmn	x0, #0x1
    2e88:	540004a0 	b.eq	2f1c <fwp_rc_wide_dup+0x108>  // b.none
    2e8c:	91000400 	add	x0, x0, #0x1
    2e90:	f9000420 	str	x0, [x1, #8]
    2e94:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e98:	f94013f5 	ldr	x21, [sp, #32]
    2e9c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2ea0:	d65f03c0 	ret
    2ea4:	39400260 	ldrb	w0, [x19]
    2ea8:	7103f81f 	cmp	w0, #0xfe
    2eac:	540000a0 	b.eq	2ec0 <fwp_rc_wide_dup+0xac>  // b.none
    2eb0:	d0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    2eb4:	9100c000 	add	x0, x0, #0x30
    2eb8:	97fffd12 	bl	2300 <fwp_trap>
    2ebc:	b5000281 	cbnz	x1, 2f0c <fwp_rc_wide_dup+0xf8>
    2ec0:	d2800300 	mov	x0, #0x18                  	// #24
    2ec4:	97fff98b 	bl	14f0 <malloc@plt>
    2ec8:	b4000280 	cbz	x0, 2f18 <fwp_rc_wide_dup+0x104>
    2ecc:	d2801fe1 	mov	x1, #0xff                  	// #255
    2ed0:	a9000413 	stp	x19, x1, [x0]
    2ed4:	9114c2b5 	add	x21, x21, #0x530
    2ed8:	f900081f 	str	xzr, [x0, #16]
    2edc:	12800001 	mov	w1, #0xffffffff            	// #-1
    2ee0:	f9000280 	str	x0, [x20]
    2ee4:	39000261 	strb	w1, [x19]
    2ee8:	f94e26a0 	ldr	x0, [x21, #7240]
    2eec:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ef0:	91000400 	add	x0, x0, #0x1
    2ef4:	f90e26a0 	str	x0, [x21, #7240]
    2ef8:	f94013f5 	ldr	x21, [sp, #32]
    2efc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f00:	d65f03c0 	ret
    2f04:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    2f08:	17ffffda 	b	2e70 <fwp_rc_wide_dup+0x5c>
    2f0c:	d0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    2f10:	91002000 	add	x0, x0, #0x8
    2f14:	97fffcfb 	bl	2300 <fwp_trap>
    2f18:	97fffb8e 	bl	1d50 <fwp_heap_oom>
    2f1c:	d0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    2f20:	91016000 	add	x0, x0, #0x58
    2f24:	97fffcf7 	bl	2300 <fwp_trap>
    2f28:	d503201f 	nop
    2f2c:	d503201f 	nop

0000000000002f30 <fwp_rc_forget_slot>:
    2f30:	aa0003e1 	mov	x1, x0
    2f34:	39400000 	ldrb	w0, [x0]
    2f38:	7103fc1f 	cmp	w0, #0xff
    2f3c:	54000040 	b.eq	2f44 <fwp_rc_forget_slot+0x14>  // b.none
    2f40:	d65f03c0 	ret
    2f44:	ca414420 	eor	x0, x1, x1, lsr #17
    2f48:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f4c:	ca402400 	eor	x0, x0, x0, lsr #9
    2f50:	910003fd 	mov	x29, sp
    2f54:	92401c00 	and	x0, x0, #0xff
    2f58:	f9000bf3 	str	x19, [sp, #16]
    2f5c:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    2f60:	9114c262 	add	x2, x19, #0x530
    2f64:	910a2403 	add	x3, x0, #0x289
    2f68:	8b000c40 	add	x0, x2, x0, lsl #3
    2f6c:	8b030c43 	add	x3, x2, x3, lsl #3
    2f70:	f94a2400 	ldr	x0, [x0, #5192]
    2f74:	b50000a0 	cbnz	x0, 2f88 <fwp_rc_forget_slot+0x58>
    2f78:	14000011 	b	2fbc <fwp_rc_forget_slot+0x8c>
    2f7c:	91004003 	add	x3, x0, #0x10
    2f80:	f9400800 	ldr	x0, [x0, #16]
    2f84:	b40001c0 	cbz	x0, 2fbc <fwp_rc_forget_slot+0x8c>
    2f88:	f9400002 	ldr	x2, [x0]
    2f8c:	eb02003f 	cmp	x1, x2
    2f90:	54ffff61 	b.ne	2f7c <fwp_rc_forget_slot+0x4c>  // b.any
    2f94:	f9400801 	ldr	x1, [x0, #16]
    2f98:	9114c273 	add	x19, x19, #0x530
    2f9c:	f9000061 	str	x1, [x3]
    2fa0:	97fff99c 	bl	1610 <free@plt>
    2fa4:	f94e2660 	ldr	x0, [x19, #7240]
    2fa8:	d1000400 	sub	x0, x0, #0x1
    2fac:	f90e2660 	str	x0, [x19, #7240]
    2fb0:	f9400bf3 	ldr	x19, [sp, #16]
    2fb4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2fb8:	d65f03c0 	ret
    2fbc:	d0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    2fc0:	9100c000 	add	x0, x0, #0x30
    2fc4:	97fffccf 	bl	2300 <fwp_trap>
    2fc8:	d503201f 	nop
    2fcc:	d503201f 	nop

0000000000002fd0 <fwp_rc_prepare_chunk>:
    2fd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    2fdc:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    2fe0:	9114c2c2 	add	x2, x22, #0x530
    2fe4:	b9401c03 	ldr	w3, [x0, #28]
    2fe8:	aa0103f5 	mov	x21, x1
    2fec:	a90153f3 	stp	x19, x20, [sp, #16]
    2ff0:	aa0003f4 	mov	x20, x0
    2ff4:	f94e2440 	ldr	x0, [x2, #7240]
    2ff8:	b4000440 	cbz	x0, 3080 <fwp_rc_prepare_chunk+0xb0>
    2ffc:	d2800013 	mov	x19, #0x0                   	// #0
    3000:	35000203 	cbnz	w3, 3040 <fwp_rc_prepare_chunk+0x70>
    3004:	b4000361 	cbz	x1, 3070 <fwp_rc_prepare_chunk+0xa0>
    3008:	f9401280 	ldr	x0, [x20, #32]
    300c:	97fff981 	bl	1610 <free@plt>
    3010:	aa1503e0 	mov	x0, x21
    3014:	d2800021 	mov	x1, #0x1                   	// #1
    3018:	97fff946 	bl	1530 <calloc@plt>
    301c:	f9001280 	str	x0, [x20, #32]
    3020:	b5000460 	cbnz	x0, 30ac <fwp_rc_prepare_chunk+0xdc>
    3024:	97fffb4b 	bl	1d50 <fwp_heap_oom>
    3028:	97ffffc2 	bl	2f30 <fwp_rc_forget_slot>
    302c:	91000673 	add	x19, x19, #0x1
    3030:	b9401e83 	ldr	w3, [x20, #28]
    3034:	eb13007f 	cmp	x3, x19
    3038:	54000169 	b.ls	3064 <fwp_rc_prepare_chunk+0x94>  // b.plast
    303c:	d503201f 	nop
    3040:	f9401283 	ldr	x3, [x20, #32]
    3044:	8b130060 	add	x0, x3, x19
    3048:	38736863 	ldrb	w3, [x3, x19]
    304c:	7103fc7f 	cmp	w3, #0xff
    3050:	54fffec0 	b.eq	3028 <fwp_rc_prepare_chunk+0x58>  // b.none
    3054:	b9401e83 	ldr	w3, [x20, #28]
    3058:	91000673 	add	x19, x19, #0x1
    305c:	eb13007f 	cmp	x3, x19
    3060:	54ffff08 	b.hi	3040 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    3064:	eb0302bf 	cmp	x21, x3
    3068:	54000121 	b.ne	308c <fwp_rc_prepare_chunk+0xbc>  // b.any
    306c:	b5000335 	cbnz	x21, 30d0 <fwp_rc_prepare_chunk+0x100>
    3070:	a94153f3 	ldp	x19, x20, [sp, #16]
    3074:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3078:	a8c37bfd 	ldp	x29, x30, [sp], #48
    307c:	d65f03c0 	ret
    3080:	2a0303e3 	mov	w3, w3
    3084:	eb0302bf 	cmp	x21, x3
    3088:	54ffff20 	b.eq	306c <fwp_rc_prepare_chunk+0x9c>  // b.none
    308c:	9114c2c2 	add	x2, x22, #0x530
    3090:	f9401280 	ldr	x0, [x20, #32]
    3094:	f94e2841 	ldr	x1, [x2, #7248]
    3098:	cb030021 	sub	x1, x1, x3
    309c:	f90e2841 	str	x1, [x2, #7248]
    30a0:	97fff95c 	bl	1610 <free@plt>
    30a4:	b5fffb75 	cbnz	x21, 3010 <fwp_rc_prepare_chunk+0x40>
    30a8:	f900129f 	str	xzr, [x20, #32]
    30ac:	9114c2d6 	add	x22, x22, #0x530
    30b0:	f94e2ac0 	ldr	x0, [x22, #7248]
    30b4:	b9001e95 	str	w21, [x20, #28]
    30b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    30bc:	8b150000 	add	x0, x0, x21
    30c0:	f90e2ac0 	str	x0, [x22, #7248]
    30c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    30c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30cc:	d65f03c0 	ret
    30d0:	f9401280 	ldr	x0, [x20, #32]
    30d4:	aa1503e2 	mov	x2, x21
    30d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    30dc:	52800001 	mov	w1, #0x0                   	// #0
    30e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    30e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e8:	17fff90e 	b	1520 <memset@plt>
    30ec:	d503201f 	nop

00000000000030f0 <fwp_heap_refill>:
    30f0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30f4:	910003fd 	mov	x29, sp
    30f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    30fc:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    3100:	9114c2b5 	add	x21, x21, #0x530
    3104:	aa0003f6 	mov	x22, x0
    3108:	d2800020 	mov	x0, #0x1                   	// #1
    310c:	a90153f3 	stp	x19, x20, [sp, #16]
    3110:	a90363f7 	stp	x23, x24, [sp, #48]
    3114:	2a0103f7 	mov	w23, w1
    3118:	2a0203f8 	mov	w24, w2
    311c:	97fffb1d 	bl	1d90 <fwp_heap_chunks>
    3120:	aa0003f3 	mov	x19, x0
    3124:	f949fea2 	ldr	x2, [x21, #5112]
    3128:	8b000800 	add	x0, x0, x0, lsl #2
    312c:	2a1703e1 	mov	w1, w23
    3130:	52800025 	mov	w5, #0x1                   	// #1
    3134:	d37df000 	lsl	x0, x0, #3
    3138:	910f0021 	add	x1, x1, #0x3c0
    313c:	8b000054 	add	x20, x2, x0
    3140:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    3144:	52a00024 	mov	w4, #0x10000               	// #65536
    3148:	38206845 	strb	w5, [x2, x0]
    314c:	aa1403e0 	mov	x0, x20
    3150:	39000698 	strb	w24, [x20, #1]
    3154:	39000a97 	strb	w23, [x20, #2]
    3158:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    315c:	b9000681 	str	w1, [x20, #4]
    3160:	2a0103e5 	mov	w5, w1
    3164:	8b0300a2 	add	x2, x5, x3
    3168:	1ac10881 	udiv	w1, w4, w1
    316c:	9ac50842 	udiv	x2, x2, x5
    3170:	b9000a81 	str	w1, [x20, #8]
    3174:	92404021 	and	x1, x1, #0x1ffff
    3178:	b9001a82 	str	w2, [x20, #24]
    317c:	97ffff95 	bl	2fd0 <fwp_rc_prepare_chunk>
    3180:	f949daa0 	ldr	x0, [x21, #5040]
    3184:	29408a81 	ldp	w1, w2, [x20, #4]
    3188:	8b134000 	add	x0, x0, x19, lsl #16
    318c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3190:	8b214003 	add	x3, x0, w1, uxtw
    3194:	9ba20021 	umaddl	x1, w1, w2, x0
    3198:	a94363f7 	ldp	x23, x24, [sp, #48]
    319c:	a90086c3 	stp	x3, x1, [x22, #8]
    31a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    31a4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    31a8:	d65f03c0 	ret
    31ac:	d503201f 	nop

00000000000031b0 <fwp_mem_free>:
    31b0:	b40003c0 	cbz	x0, 3228 <fwp_mem_free+0x78>
    31b4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    31b8:	910003fd 	mov	x29, sp
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    31c4:	9114c2a1 	add	x1, x21, #0x530
    31c8:	a90153f3 	stp	x19, x20, [sp, #16]
    31cc:	aa0003f3 	mov	x19, x0
    31d0:	f949d823 	ldr	x3, [x1, #5040]
    31d4:	f949ec22 	ldr	x2, [x1, #5080]
    31d8:	cb030000 	sub	x0, x0, x3
    31dc:	eb02401f 	cmp	x0, x2, lsl #16
    31e0:	540001c2 	b.cs	3218 <fwp_mem_free+0x68>  // b.hs, b.nlast
    31e4:	d350fc16 	lsr	x22, x0, #16
    31e8:	a90363f7 	stp	x23, x24, [sp, #48]
    31ec:	f949fc22 	ldr	x2, [x1, #5112]
    31f0:	8b160ad4 	add	x20, x22, x22, lsl #2
    31f4:	d37df294 	lsl	x20, x20, #3
    31f8:	ab140057 	adds	x23, x2, x20
    31fc:	540000c0 	b.eq	3214 <fwp_mem_free+0x64>  // b.none
    3200:	38746842 	ldrb	w2, [x2, x20]
    3204:	7100045f 	cmp	w2, #0x1
    3208:	54000120 	b.eq	322c <fwp_mem_free+0x7c>  // b.none
    320c:	7100085f 	cmp	w2, #0x2
    3210:	540005e0 	b.eq	32cc <fwp_mem_free+0x11c>  // b.none
    3214:	a94363f7 	ldp	x23, x24, [sp, #48]
    3218:	a94153f3 	ldp	x19, x20, [sp, #16]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3224:	d65f03c0 	ret
    3228:	d65f03c0 	ret
    322c:	f94012f8 	ldr	x24, [x23, #32]
    3230:	b94006e1 	ldr	w1, [x23, #4]
    3234:	f90023f9 	str	x25, [sp, #64]
    3238:	2a0103e2 	mov	w2, w1
    323c:	394006f9 	ldrb	w25, [x23, #1]
    3240:	39400af4 	ldrb	w20, [x23, #2]
    3244:	b4000158 	cbz	x24, 326c <fwp_mem_free+0xbc>
    3248:	92403e76 	and	x22, x19, #0xffff
    324c:	9ac20ad6 	udiv	x22, x22, x2
    3250:	38766b01 	ldrb	w1, [x24, x22]
    3254:	8b160300 	add	x0, x24, x22
    3258:	7103fc3f 	cmp	w1, #0xff
    325c:	54000980 	b.eq	338c <fwp_mem_free+0x1dc>  // b.none
    3260:	38366b1f 	strb	wzr, [x24, x22]
    3264:	b94006e1 	ldr	w1, [x23, #4]
    3268:	2a0103e2 	mov	w2, w1
    326c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    3270:	d37f1e83 	ubfiz	x3, x20, #1, #8
    3274:	cb390000 	sub	x0, x0, w25, uxtb
    3278:	8b340074 	add	x20, x3, w20, uxtb
    327c:	9114c2b5 	add	x21, x21, #0x530
    3280:	1e630021 	ucvtf	d1, w1
    3284:	d37ae400 	lsl	x0, x0, #6
    3288:	8b140c14 	add	x20, x0, x20, lsl #3
    328c:	a94363f7 	ldp	x23, x24, [sp, #48]
    3290:	f8746aa0 	ldr	x0, [x21, x20]
    3294:	f94023f9 	ldr	x25, [sp, #64]
    3298:	aa2003e0 	mvn	x0, x0
    329c:	fd4a22a0 	ldr	d0, [x21, #5184]
    32a0:	f9000260 	str	x0, [x19]
    32a4:	f8346ab3 	str	x19, [x21, x20]
    32a8:	f94a12a0 	ldr	x0, [x21, #5152]
    32ac:	1e612800 	fadd	d0, d0, d1
    32b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32b4:	cb020000 	sub	x0, x0, x2
    32b8:	f90a12a0 	str	x0, [x21, #5152]
    32bc:	fd0a22a0 	str	d0, [x21, #5184]
    32c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32c4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    32c8:	d65f03c0 	ret
    32cc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    32d0:	8b000063 	add	x3, x3, x0
    32d4:	eb03027f 	cmp	x19, x3
    32d8:	54fff9e1 	b.ne	3214 <fwp_mem_free+0x64>  // b.any
    32dc:	fd400ae1 	ldr	d1, [x23, #16]
    32e0:	fd4a2020 	ldr	d0, [x1, #5184]
    32e4:	f9400ae0 	ldr	x0, [x23, #16]
    32e8:	7e61d821 	ucvtf	d1, d1
    32ec:	f94a1022 	ldr	x2, [x1, #5152]
    32f0:	f94012f3 	ldr	x19, [x23, #32]
    32f4:	1e612800 	fadd	d0, d0, d1
    32f8:	cb000042 	sub	x2, x2, x0
    32fc:	f90a1022 	str	x2, [x1, #5152]
    3300:	fd0a2020 	str	d0, [x1, #5184]
    3304:	b40000b3 	cbz	x19, 3318 <fwp_mem_free+0x168>
    3308:	39400260 	ldrb	w0, [x19]
    330c:	7103fc1f 	cmp	w0, #0xff
    3310:	54000380 	b.eq	3380 <fwp_mem_free+0x1d0>  // b.none
    3314:	3900027f 	strb	wzr, [x19]
    3318:	b9400ee2 	ldr	w2, [x23, #12]
    331c:	b4000142 	cbz	x2, 3344 <fwp_mem_free+0x194>
    3320:	9114c2a1 	add	x1, x21, #0x530
    3324:	8b160040 	add	x0, x2, x22
    3328:	8b000800 	add	x0, x0, x0, lsl #2
    332c:	f949fc21 	ldr	x1, [x1, #5112]
    3330:	8b140034 	add	x20, x1, x20
    3334:	8b000c20 	add	x0, x1, x0, lsl #3
    3338:	3802869f 	strb	wzr, [x20], #40
    333c:	eb00029f 	cmp	x20, x0
    3340:	54ffffc1 	b.ne	3338 <fwp_mem_free+0x188>  // b.any
    3344:	9114c2a0 	add	x0, x21, #0x530
    3348:	f94a1801 	ldr	x1, [x0, #5168]
    334c:	f949f803 	ldr	x3, [x0, #5104]
    3350:	8b020021 	add	x1, x1, x2
    3354:	f90a1801 	str	x1, [x0, #5168]
    3358:	eb16007f 	cmp	x3, x22
    335c:	54000049 	b.ls	3364 <fwp_mem_free+0x1b4>  // b.plast
    3360:	f909f816 	str	x22, [x0, #5104]
    3364:	9114c2b5 	add	x21, x21, #0x530
    3368:	f949f6a0 	ldr	x0, [x21, #5096]
    336c:	eb16001f 	cmp	x0, x22
    3370:	54fff529 	b.ls	3214 <fwp_mem_free+0x64>  // b.plast
    3374:	a94363f7 	ldp	x23, x24, [sp, #48]
    3378:	f909f6b6 	str	x22, [x21, #5096]
    337c:	17ffffa7 	b	3218 <fwp_mem_free+0x68>
    3380:	aa1303e0 	mov	x0, x19
    3384:	97fffeeb 	bl	2f30 <fwp_rc_forget_slot>
    3388:	17ffffe3 	b	3314 <fwp_mem_free+0x164>
    338c:	97fffee9 	bl	2f30 <fwp_rc_forget_slot>
    3390:	17ffffb4 	b	3260 <fwp_mem_free+0xb0>

0000000000003394 <fwp_heap_alloc_big>:
    3394:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    3398:	910003fd 	mov	x29, sp
    339c:	a90153f3 	stp	x19, x20, [sp, #16]
    33a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    33a4:	a90363f7 	stp	x23, x24, [sp, #48]
    33a8:	aa0003f7 	mov	x23, x0
    33ac:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    33b0:	a9046bf9 	stp	x25, x26, [sp, #64]
    33b4:	eb0002ff 	cmp	x23, x0
    33b8:	54000888 	b.hi	34c8 <fwp_heap_alloc_big+0x134>  // b.pmore
    33bc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    33c0:	8b0002f4 	add	x20, x23, x0
    33c4:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xcb0>
    33c8:	9114c359 	add	x25, x26, #0x530
    33cc:	d350fe94 	lsr	x20, x20, #16
    33d0:	2a0103f5 	mov	w21, w1
    33d4:	aa1403e0 	mov	x0, x20
    33d8:	97fffa6e 	bl	1d90 <fwp_heap_chunks>
    33dc:	f949ff22 	ldr	x2, [x25, #5112]
    33e0:	8b000813 	add	x19, x0, x0, lsl #2
    33e4:	aa0003f8 	mov	x24, x0
    33e8:	52800043 	mov	w3, #0x2                   	// #2
    33ec:	d37df273 	lsl	x19, x19, #3
    33f0:	d2800021 	mov	x1, #0x1                   	// #1
    33f4:	8b130040 	add	x0, x2, x19
    33f8:	38336843 	strb	w3, [x2, x19]
    33fc:	39000415 	strb	w21, [x0, #1]
    3400:	b9000c14 	str	w20, [x0, #12]
    3404:	f9000817 	str	x23, [x0, #16]
    3408:	97fffef2 	bl	2fd0 <fwp_rc_prepare_chunk>
    340c:	f100069f 	cmp	x20, #0x1
    3410:	54000269 	b.ls	345c <fwp_heap_alloc_big+0xc8>  // b.plast
    3414:	8b180294 	add	x20, x20, x24
    3418:	9100a273 	add	x19, x19, #0x28
    341c:	a90573fb 	stp	x27, x28, [sp, #80]
    3420:	5280007b 	mov	w27, #0x3                   	// #3
    3424:	8b140a94 	add	x20, x20, x20, lsl #2
    3428:	2a1803fc 	mov	w28, w24
    342c:	9adb2296 	lsl	x22, x20, x27
    3430:	f949ff35 	ldr	x21, [x25, #5112]
    3434:	d2800001 	mov	x1, #0x0                   	// #0
    3438:	8b1302b4 	add	x20, x21, x19
    343c:	aa1403e0 	mov	x0, x20
    3440:	97fffee4 	bl	2fd0 <fwp_rc_prepare_chunk>
    3444:	38336abb 	strb	w27, [x21, x19]
    3448:	9100a273 	add	x19, x19, #0x28
    344c:	b9000e9c 	str	w28, [x20, #12]
    3450:	eb1302df 	cmp	x22, x19
    3454:	54fffee1 	b.ne	3430 <fwp_heap_alloc_big+0x9c>  // b.any
    3458:	a94573fb 	ldp	x27, x28, [sp, #80]
    345c:	9114c353 	add	x19, x26, #0x530
    3460:	aa1703e2 	mov	x2, x23
    3464:	52800001 	mov	w1, #0x0                   	// #0
    3468:	f949da60 	ldr	x0, [x19, #5040]
    346c:	8b184018 	add	x24, x0, x24, lsl #16
    3470:	aa1803e0 	mov	x0, x24
    3474:	97fff82b 	bl	1520 <memset@plt>
    3478:	f94a1260 	ldr	x0, [x19, #5152]
    347c:	ab170000 	adds	x0, x0, x23
    3480:	54000242 	b.cs	34c8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    3484:	f94a1661 	ldr	x1, [x19, #5160]
    3488:	f90a1260 	str	x0, [x19, #5152]
    348c:	eb01001f 	cmp	x0, x1
    3490:	54000049 	b.ls	3498 <fwp_heap_alloc_big+0x104>  // b.plast
    3494:	f90a1660 	str	x0, [x19, #5160]
    3498:	9114c35a 	add	x26, x26, #0x530
    349c:	9e6202e0 	scvtf	d0, x23
    34a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a4:	aa1803e0 	mov	x0, x24
    34a8:	fd4a1f41 	ldr	d1, [x26, #5176]
    34ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34b0:	1e602820 	fadd	d0, d1, d0
    34b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    34b8:	fd0a1f40 	str	d0, [x26, #5176]
    34bc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    34c0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    34c4:	d65f03c0 	ret
    34c8:	a90573fb 	stp	x27, x28, [sp, #80]
    34cc:	97fffa21 	bl	1d50 <fwp_heap_oom>

00000000000034d0 <fwp_heap_alloc_slow>:
    34d0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    34d4:	910003fd 	mov	x29, sp
    34d8:	a90153f3 	stp	x19, x20, [sp, #16]
    34dc:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    34e0:	9114c262 	add	x2, x19, #0x530
    34e4:	a9025bf5 	stp	x21, x22, [sp, #32]
    34e8:	aa0003f5 	mov	x21, x0
    34ec:	2a0103f4 	mov	w20, w1
    34f0:	b953a440 	ldr	w0, [x2, #5028]
    34f4:	34000600 	cbz	w0, 35b4 <fwp_heap_alloc_slow+0xe4>
    34f8:	f14012bf 	cmp	x21, #0x4, lsl #12
    34fc:	54000628 	b.hi	35c0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3500:	91003ea0 	add	x0, x21, #0xf
    3504:	9114c262 	add	x2, x19, #0x530
    3508:	f9001bf7 	str	x23, [sp, #48]
    350c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3510:	8b401040 	add	x0, x2, x0, lsr #4
    3514:	cb34c084 	sub	x4, x4, w20, sxtw
    3518:	d37ae484 	lsl	x4, x4, #6
    351c:	397e8003 	ldrb	w3, [x0, #4000]
    3520:	910f0060 	add	x0, x3, #0x3c0
    3524:	aa0303e1 	mov	x1, x3
    3528:	8b030463 	add	x3, x3, x3, lsl #1
    352c:	8b030c83 	add	x3, x4, x3, lsl #3
    3530:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3534:	2a1703f6 	mov	w22, w23
    3538:	f8636844 	ldr	x4, [x2, x3]
    353c:	b40004e4 	cbz	x4, 35d8 <fwp_heap_alloc_slow+0x108>
    3540:	f9400080 	ldr	x0, [x4]
    3544:	aa2003e0 	mvn	x0, x0
    3548:	f8236840 	str	x0, [x2, x3]
    354c:	7100069f 	cmp	w20, #0x1
    3550:	aa0403e0 	mov	x0, x4
    3554:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    3558:	52800001 	mov	w1, #0x0                   	// #0
    355c:	97fff7f1 	bl	1520 <memset@plt>
    3560:	aa0003e4 	mov	x4, x0
    3564:	9114c260 	add	x0, x19, #0x530
    3568:	f94a1001 	ldr	x1, [x0, #5152]
    356c:	ab160021 	adds	x1, x1, x22
    3570:	540005c2 	b.cs	3628 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    3574:	f94a1402 	ldr	x2, [x0, #5160]
    3578:	f90a1001 	str	x1, [x0, #5152]
    357c:	eb02003f 	cmp	x1, x2
    3580:	54000049 	b.ls	3588 <fwp_heap_alloc_slow+0xb8>  // b.plast
    3584:	f90a1401 	str	x1, [x0, #5160]
    3588:	9114c273 	add	x19, x19, #0x530
    358c:	1e6302e1 	ucvtf	d1, w23
    3590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3594:	aa0403e0 	mov	x0, x4
    3598:	fd4a1e60 	ldr	d0, [x19, #5176]
    359c:	f9401bf7 	ldr	x23, [sp, #48]
    35a0:	1e612800 	fadd	d0, d0, d1
    35a4:	fd0a1e60 	str	d0, [x19, #5176]
    35a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35ac:	a8c47bfd 	ldp	x29, x30, [sp], #64
    35b0:	d65f03c0 	ret
    35b4:	97fffce8 	bl	2954 <fwp_heap_init>
    35b8:	f14012bf 	cmp	x21, #0x4, lsl #12
    35bc:	54fffa29 	b.ls	3500 <fwp_heap_alloc_slow+0x30>  // b.plast
    35c0:	2a1403e1 	mov	w1, w20
    35c4:	aa1503e0 	mov	x0, x21
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35d0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    35d4:	17ffff70 	b	3394 <fwp_heap_alloc_big>
    35d8:	8b030042 	add	x2, x2, x3
    35dc:	f9400444 	ldr	x4, [x2, #8]
    35e0:	b4000104 	cbz	x4, 3600 <fwp_heap_alloc_slow+0x130>
    35e4:	f9400840 	ldr	x0, [x2, #16]
    35e8:	cb040000 	sub	x0, x0, x4
    35ec:	eb16001f 	cmp	x0, x22
    35f0:	54000083 	b.cc	3600 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    35f4:	8b160080 	add	x0, x4, x22
    35f8:	f9000440 	str	x0, [x2, #8]
    35fc:	17ffffd4 	b	354c <fwp_heap_alloc_slow+0x7c>
    3600:	52800302 	mov	w2, #0x18                  	// #24
    3604:	52807804 	mov	w4, #0x3c0                 	// #960
    3608:	9114c260 	add	x0, x19, #0x530
    360c:	9ba27c23 	umull	x3, w1, w2
    3610:	2a1403e2 	mov	w2, w20
    3614:	9b240e84 	smaddl	x4, w20, w4, x3
    3618:	8b040000 	add	x0, x0, x4
    361c:	97fffeb5 	bl	30f0 <fwp_heap_refill>
    3620:	aa0003e4 	mov	x4, x0
    3624:	17ffffca 	b	354c <fwp_heap_alloc_slow+0x7c>
    3628:	97fff9ca 	bl	1d50 <fwp_heap_oom>
    362c:	d503201f 	nop

0000000000003630 <fwp_rc_share>:
    3630:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    3634:	9114c042 	add	x2, x2, #0x530
    3638:	f949d843 	ldr	x3, [x2, #5040]
    363c:	f949ec41 	ldr	x1, [x2, #5080]
    3640:	cb030000 	sub	x0, x0, x3
    3644:	eb01401f 	cmp	x0, x1, lsl #16
    3648:	540002c2 	b.cs	36a0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    364c:	d350fc01 	lsr	x1, x0, #16
    3650:	f949fc44 	ldr	x4, [x2, #5112]
    3654:	8b010821 	add	x1, x1, x1, lsl #2
    3658:	d37df021 	lsl	x1, x1, #3
    365c:	8b010083 	add	x3, x4, x1
    3660:	f9401062 	ldr	x2, [x3, #32]
    3664:	b40001e2 	cbz	x2, 36a0 <fwp_rc_share+0x70>
    3668:	38616881 	ldrb	w1, [x4, x1]
    366c:	7100083f 	cmp	w1, #0x2
    3670:	540001a0 	b.eq	36a4 <fwp_rc_share+0x74>  // b.none
    3674:	7100043f 	cmp	w1, #0x1
    3678:	54000141 	b.ne	36a0 <fwp_rc_share+0x70>  // b.any
    367c:	29430464 	ldp	w4, w1, [x3, #24]
    3680:	92403c00 	and	x0, x0, #0xffff
    3684:	9b047c00 	mul	x0, x0, x4
    3688:	d360fc00 	lsr	x0, x0, #32
    368c:	eb01001f 	cmp	x0, x1
    3690:	54000082 	b.cs	36a0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    3694:	8b000042 	add	x2, x2, x0
    3698:	39400040 	ldrb	w0, [x2]
    369c:	350000a0 	cbnz	w0, 36b0 <fwp_rc_share+0x80>
    36a0:	d65f03c0 	ret
    36a4:	72003c1f 	tst	w0, #0xffff
    36a8:	54ffff80 	b.eq	3698 <fwp_rc_share+0x68>  // b.none
    36ac:	d65f03c0 	ret
    36b0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    36b4:	b0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    36b8:	9101e000 	add	x0, x0, #0x78
    36bc:	910003fd 	mov	x29, sp
    36c0:	97fffb10 	bl	2300 <fwp_trap>

00000000000036c4 <e69>:
    36c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36c8:	b0000021 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    36cc:	910003fd 	mov	x29, sp
    36d0:	fd400001 	ldr	d1, [x0]
    36d4:	f9000bf3 	str	x19, [sp, #16]
    36d8:	fd422820 	ldr	d0, [x1, #1104]
    36dc:	1e610800 	fmul	d0, d0, d1
    36e0:	9e660013 	fmov	x19, d0
    36e4:	aa1303e0 	mov	x0, x19
    36e8:	97ffffd2 	bl	3630 <fwp_rc_share>
    36ec:	aa1303e0 	mov	x0, x19
    36f0:	f9400bf3 	ldr	x19, [sp, #16]
    36f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36f8:	d65f03c0 	ret
    36fc:	d503201f 	nop

0000000000003700 <e45>:
    3700:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3704:	910003fd 	mov	x29, sp
    3708:	6d400001 	ldp	d1, d0, [x0]
    370c:	f9000bf3 	str	x19, [sp, #16]
    3710:	1e612800 	fadd	d0, d0, d1
    3714:	9e660013 	fmov	x19, d0
    3718:	aa1303e0 	mov	x0, x19
    371c:	97ffffc5 	bl	3630 <fwp_rc_share>
    3720:	aa1303e0 	mov	x0, x19
    3724:	f9400bf3 	ldr	x19, [sp, #16]
    3728:	a8c27bfd 	ldp	x29, x30, [sp], #32
    372c:	d65f03c0 	ret

0000000000003730 <e32>:
    3730:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3734:	910003fd 	mov	x29, sp
    3738:	6d400001 	ldp	d1, d0, [x0]
    373c:	f9000bf3 	str	x19, [sp, #16]
    3740:	1e613800 	fsub	d0, d0, d1
    3744:	9e660013 	fmov	x19, d0
    3748:	aa1303e0 	mov	x0, x19
    374c:	97ffffb9 	bl	3630 <fwp_rc_share>
    3750:	aa1303e0 	mov	x0, x19
    3754:	f9400bf3 	ldr	x19, [sp, #16]
    3758:	a8c27bfd 	ldp	x29, x30, [sp], #32
    375c:	d65f03c0 	ret

0000000000003760 <fwp_rc_dup>:
    3760:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    3764:	9114c042 	add	x2, x2, #0x530
    3768:	f949d841 	ldr	x1, [x2, #5040]
    376c:	f949ec43 	ldr	x3, [x2, #5080]
    3770:	cb010001 	sub	x1, x0, x1
    3774:	eb03403f 	cmp	x1, x3, lsl #16
    3778:	540003c2 	b.cs	37f0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    377c:	d350fc20 	lsr	x0, x1, #16
    3780:	f949fc44 	ldr	x4, [x2, #5112]
    3784:	8b000800 	add	x0, x0, x0, lsl #2
    3788:	d37df002 	lsl	x2, x0, #3
    378c:	8b020083 	add	x3, x4, x2
    3790:	f9401060 	ldr	x0, [x3, #32]
    3794:	b40002e0 	cbz	x0, 37f0 <fwp_rc_dup+0x90>
    3798:	38626882 	ldrb	w2, [x4, x2]
    379c:	7100085f 	cmp	w2, #0x2
    37a0:	540002a0 	b.eq	37f4 <fwp_rc_dup+0x94>  // b.none
    37a4:	7100045f 	cmp	w2, #0x1
    37a8:	54000241 	b.ne	37f0 <fwp_rc_dup+0x90>  // b.any
    37ac:	29430864 	ldp	w4, w2, [x3, #24]
    37b0:	92403c21 	and	x1, x1, #0xffff
    37b4:	9b047c21 	mul	x1, x1, x4
    37b8:	d360fc21 	lsr	x1, x1, #32
    37bc:	eb02003f 	cmp	x1, x2
    37c0:	54000182 	b.cs	37f0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    37c4:	8b010000 	add	x0, x0, x1
    37c8:	39400001 	ldrb	w1, [x0]
    37cc:	34000121 	cbz	w1, 37f0 <fwp_rc_dup+0x90>
    37d0:	b00000e2 	adrp	x2, 20000 <__data_start>
    37d4:	91014042 	add	x2, x2, #0x50
    37d8:	b9404043 	ldr	w3, [x2, #64]
    37dc:	35000123 	cbnz	w3, 3800 <fwp_rc_dup+0xa0>
    37e0:	7103f43f 	cmp	w1, #0xfd
    37e4:	54000168 	b.hi	3810 <fwp_rc_dup+0xb0>  // b.pmore
    37e8:	11000421 	add	w1, w1, #0x1
    37ec:	39000001 	strb	w1, [x0]
    37f0:	d65f03c0 	ret
    37f4:	72003c3f 	tst	w1, #0xffff
    37f8:	54fffe80 	b.eq	37c8 <fwp_rc_dup+0x68>  // b.none
    37fc:	d65f03c0 	ret
    3800:	f9402443 	ldr	x3, [x2, #72]
    3804:	91000463 	add	x3, x3, #0x1
    3808:	f9002443 	str	x3, [x2, #72]
    380c:	17fffff5 	b	37e0 <fwp_rc_dup+0x80>
    3810:	17fffd81 	b	2e14 <fwp_rc_wide_dup>

0000000000003814 <fwp_task_dispose>:
    3814:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3818:	910003fd 	mov	x29, sp
    381c:	f9000bf3 	str	x19, [sp, #16]
    3820:	aa0003f3 	mov	x19, x0
    3824:	39414000 	ldrb	w0, [x0, #80]
    3828:	36000720 	tbz	w0, #0, 390c <fwp_task_dispose+0xf8>
    382c:	f9400a60 	ldr	x0, [x19, #16]
    3830:	b50006e0 	cbnz	x0, 390c <fwp_task_dispose+0xf8>
    3834:	a9478660 	ldp	x0, x1, [x19, #120]
    3838:	39014e7f 	strb	wzr, [x19, #83]
    383c:	f9003e7f 	str	xzr, [x19, #120]
    3840:	f100003f 	cmp	x1, #0x0
    3844:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3848:	54000040 	b.eq	3850 <fwp_task_dispose+0x3c>  // b.none
    384c:	d63f0020 	blr	x1
    3850:	f9405660 	ldr	x0, [x19, #168]
    3854:	97fffe57 	bl	31b0 <fwp_mem_free>
    3858:	f900567f 	str	xzr, [x19, #168]
    385c:	b9405e60 	ldr	w0, [x19, #92]
    3860:	7100041f 	cmp	w0, #0x1
    3864:	54000420 	b.eq	38e8 <fwp_task_dispose+0xd4>  // b.none
    3868:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    386c:	9114c042 	add	x2, x2, #0x530
    3870:	f949d840 	ldr	x0, [x2, #5040]
    3874:	f949ec41 	ldr	x1, [x2, #5080]
    3878:	cb000260 	sub	x0, x19, x0
    387c:	eb01401f 	cmp	x0, x1, lsl #16
    3880:	540002e2 	b.cs	38dc <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3884:	d350fc01 	lsr	x1, x0, #16
    3888:	f949fc44 	ldr	x4, [x2, #5112]
    388c:	8b010821 	add	x1, x1, x1, lsl #2
    3890:	d37df021 	lsl	x1, x1, #3
    3894:	8b010083 	add	x3, x4, x1
    3898:	f9401062 	ldr	x2, [x3, #32]
    389c:	b4000202 	cbz	x2, 38dc <fwp_task_dispose+0xc8>
    38a0:	38616881 	ldrb	w1, [x4, x1]
    38a4:	7100083f 	cmp	w1, #0x2
    38a8:	54000280 	b.eq	38f8 <fwp_task_dispose+0xe4>  // b.none
    38ac:	7100043f 	cmp	w1, #0x1
    38b0:	54000161 	b.ne	38dc <fwp_task_dispose+0xc8>  // b.any
    38b4:	29430464 	ldp	w4, w1, [x3, #24]
    38b8:	92403c00 	and	x0, x0, #0xffff
    38bc:	9b047c00 	mul	x0, x0, x4
    38c0:	d360fc00 	lsr	x0, x0, #32
    38c4:	eb01001f 	cmp	x0, x1
    38c8:	540000a2 	b.cs	38dc <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    38cc:	8b000042 	add	x2, x2, x0
    38d0:	39400040 	ldrb	w0, [x2]
    38d4:	7100041f 	cmp	w0, #0x1
    38d8:	54000080 	b.eq	38e8 <fwp_task_dispose+0xd4>  // b.none
    38dc:	f9400bf3 	ldr	x19, [sp, #16]
    38e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    38e4:	d65f03c0 	ret
    38e8:	aa1303e0 	mov	x0, x19
    38ec:	f9400bf3 	ldr	x19, [sp, #16]
    38f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    38f4:	17fffe2f 	b	31b0 <fwp_mem_free>
    38f8:	72003c1f 	tst	w0, #0xffff
    38fc:	54fffea0 	b.eq	38d0 <fwp_task_dispose+0xbc>  // b.none
    3900:	f9400bf3 	ldr	x19, [sp, #16]
    3904:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3908:	d65f03c0 	ret
    390c:	97fff725 	bl	15a0 <abort@plt>

0000000000003910 <fwp_free_zombie>:
    3910:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3914:	910003fd 	mov	x29, sp
    3918:	a90153f3 	stp	x19, x20, [sp, #16]
    391c:	b00000f4 	adrp	x20, 20000 <__data_start>
    3920:	91014281 	add	x1, x20, #0x50
    3924:	f9402833 	ldr	x19, [x1, #80]
    3928:	b4000333 	cbz	x19, 398c <fwp_free_zombie+0x7c>
    392c:	f9400420 	ldr	x0, [x1, #8]
    3930:	eb00027f 	cmp	x19, x0
    3934:	540002c0 	b.eq	398c <fwp_free_zombie+0x7c>  // b.none
    3938:	b9405822 	ldr	w2, [x1, #88]
    393c:	f9400a60 	ldr	x0, [x19, #16]
    3940:	7100fc5f 	cmp	w2, #0x3f
    3944:	5400078c 	b.gt	3a34 <fwp_free_zombie+0x124>
    3948:	91018023 	add	x3, x1, #0x60
    394c:	11000444 	add	w4, w2, #0x1
    3950:	b9005824 	str	w4, [x1, #88]
    3954:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3958:	f822d860 	str	x0, [x3, w2, sxtw #3]
    395c:	a9530261 	ldp	x1, x0, [x19, #304]
    3960:	b4000741 	cbz	x1, 3a48 <fwp_free_zombie+0x138>
    3964:	f9009c20 	str	x0, [x1, #312]
    3968:	b4000040 	cbz	x0, 3970 <fwp_free_zombie+0x60>
    396c:	f9009801 	str	x1, [x0, #304]
    3970:	91014294 	add	x20, x20, #0x50
    3974:	b9405e60 	ldr	w0, [x19, #92]
    3978:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    397c:	f9002a9f 	str	xzr, [x20, #80]
    3980:	34000140 	cbz	w0, 39a8 <fwp_free_zombie+0x98>
    3984:	7100041f 	cmp	w0, #0x1
    3988:	54000080 	b.eq	3998 <fwp_free_zombie+0x88>  // b.none
    398c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3990:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3994:	d65f03c0 	ret
    3998:	aa1303e0 	mov	x0, x19
    399c:	a94153f3 	ldp	x19, x20, [sp, #16]
    39a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39a4:	17ffff9c 	b	3814 <fwp_task_dispose>
    39a8:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xcb0>
    39ac:	9114c082 	add	x2, x4, #0x530
    39b0:	f949d841 	ldr	x1, [x2, #5040]
    39b4:	f949ec40 	ldr	x0, [x2, #5080]
    39b8:	cb010261 	sub	x1, x19, x1
    39bc:	eb00403f 	cmp	x1, x0, lsl #16
    39c0:	54fffe62 	b.cs	398c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    39c4:	d350fc20 	lsr	x0, x1, #16
    39c8:	f949fc43 	ldr	x3, [x2, #5112]
    39cc:	8b000800 	add	x0, x0, x0, lsl #2
    39d0:	d37df000 	lsl	x0, x0, #3
    39d4:	8b000062 	add	x2, x3, x0
    39d8:	f9401054 	ldr	x20, [x2, #32]
    39dc:	b4fffd94 	cbz	x20, 398c <fwp_free_zombie+0x7c>
    39e0:	38606860 	ldrb	w0, [x3, x0]
    39e4:	7100081f 	cmp	w0, #0x2
    39e8:	54000360 	b.eq	3a54 <fwp_free_zombie+0x144>  // b.none
    39ec:	7100041f 	cmp	w0, #0x1
    39f0:	54fffce1 	b.ne	398c <fwp_free_zombie+0x7c>  // b.any
    39f4:	29430043 	ldp	w3, w0, [x2, #24]
    39f8:	92403c21 	and	x1, x1, #0xffff
    39fc:	9b037c21 	mul	x1, x1, x3
    3a00:	d360fc21 	lsr	x1, x1, #32
    3a04:	eb00003f 	cmp	x1, x0
    3a08:	54fffc22 	b.cs	398c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3a0c:	8b010294 	add	x20, x20, x1
    3a10:	39400280 	ldrb	w0, [x20]
    3a14:	34fffbc0 	cbz	w0, 398c <fwp_free_zombie+0x7c>
    3a18:	7100041f 	cmp	w0, #0x1
    3a1c:	54fffbe0 	b.eq	3998 <fwp_free_zombie+0x88>  // b.none
    3a20:	7103fc1f 	cmp	w0, #0xff
    3a24:	540001e0 	b.eq	3a60 <fwp_free_zombie+0x150>  // b.none
    3a28:	51000400 	sub	w0, w0, #0x1
    3a2c:	39000280 	strb	w0, [x20]
    3a30:	17ffffd7 	b	398c <fwp_free_zombie+0x7c>
    3a34:	f9400e61 	ldr	x1, [x19, #24]
    3a38:	97fff70e 	bl	1670 <munmap@plt>
    3a3c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3a40:	a9530261 	ldp	x1, x0, [x19, #304]
    3a44:	b5fff901 	cbnz	x1, 3964 <fwp_free_zombie+0x54>
    3a48:	91014282 	add	x2, x20, #0x50
    3a4c:	f9013040 	str	x0, [x2, #608]
    3a50:	17ffffc6 	b	3968 <fwp_free_zombie+0x58>
    3a54:	72003c3f 	tst	w1, #0xffff
    3a58:	54fff9a1 	b.ne	398c <fwp_free_zombie+0x7c>  // b.any
    3a5c:	17ffffed 	b	3a10 <fwp_free_zombie+0x100>
    3a60:	ca544680 	eor	x0, x20, x20, lsr #17
    3a64:	9114c084 	add	x4, x4, #0x530
    3a68:	ca402400 	eor	x0, x0, x0, lsr #9
    3a6c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3a70:	f94a2400 	ldr	x0, [x0, #5192]
    3a74:	b5000080 	cbnz	x0, 3a84 <fwp_free_zombie+0x174>
    3a78:	14000010 	b	3ab8 <fwp_free_zombie+0x1a8>
    3a7c:	f9400800 	ldr	x0, [x0, #16]
    3a80:	b40001c0 	cbz	x0, 3ab8 <fwp_free_zombie+0x1a8>
    3a84:	f9400001 	ldr	x1, [x0]
    3a88:	eb14003f 	cmp	x1, x20
    3a8c:	54ffff81 	b.ne	3a7c <fwp_free_zombie+0x16c>  // b.any
    3a90:	f9400401 	ldr	x1, [x0, #8]
    3a94:	d1000421 	sub	x1, x1, #0x1
    3a98:	f9000401 	str	x1, [x0, #8]
    3a9c:	f103f83f 	cmp	x1, #0xfe
    3aa0:	54fff761 	b.ne	398c <fwp_free_zombie+0x7c>  // b.any
    3aa4:	aa1403e0 	mov	x0, x20
    3aa8:	97fffd22 	bl	2f30 <fwp_rc_forget_slot>
    3aac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3ab0:	39000280 	strb	w0, [x20]
    3ab4:	17ffffb6 	b	398c <fwp_free_zombie+0x7c>
    3ab8:	b0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    3abc:	9100c000 	add	x0, x0, #0x30
    3ac0:	97fffa10 	bl	2300 <fwp_trap>

0000000000003ac4 <fwp_block>:
    3ac4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3ac8:	910003fd 	mov	x29, sp
    3acc:	a90153f3 	stp	x19, x20, [sp, #16]
    3ad0:	b00000f3 	adrp	x19, 20000 <__data_start>
    3ad4:	91014274 	add	x20, x19, #0x50
    3ad8:	f9401a82 	ldr	x2, [x20, #48]
    3adc:	b4000622 	cbz	x2, 3ba0 <fwp_block+0xdc>
    3ae0:	91014261 	add	x1, x19, #0x50
    3ae4:	f9408040 	ldr	x0, [x2, #256]
    3ae8:	f9001820 	str	x0, [x1, #48]
    3aec:	b4000680 	cbz	x0, 3bbc <fwp_block+0xf8>
    3af0:	91014263 	add	x3, x19, #0x50
    3af4:	3901505f 	strb	wzr, [x2, #84]
    3af8:	f9400464 	ldr	x4, [x3, #8]
    3afc:	eb02009f 	cmp	x4, x2
    3b00:	54000440 	b.eq	3b88 <fwp_block+0xc4>  // b.none
    3b04:	f9413465 	ldr	x5, [x3, #616]
    3b08:	f9000462 	str	x2, [x3, #8]
    3b0c:	f9400441 	ldr	x1, [x2, #8]
    3b10:	f9004885 	str	x5, [x4, #144]
    3b14:	f9413865 	ldr	x5, [x3, #624]
    3b18:	f9004c85 	str	x5, [x4, #152]
    3b1c:	f9413c65 	ldr	x5, [x3, #632]
    3b20:	f9005085 	str	x5, [x4, #160]
    3b24:	f9414065 	ldr	x5, [x3, #640]
    3b28:	f9005485 	str	x5, [x4, #168]
    3b2c:	f9414465 	ldr	x5, [x3, #648]
    3b30:	f9005885 	str	x5, [x4, #176]
    3b34:	f9414865 	ldr	x5, [x3, #656]
    3b38:	f9005c85 	str	x5, [x4, #184]
    3b3c:	f9414c65 	ldr	x5, [x3, #664]
    3b40:	f9006085 	str	x5, [x4, #192]
    3b44:	f9400480 	ldr	x0, [x4, #8]
    3b48:	f9404844 	ldr	x4, [x2, #144]
    3b4c:	f9013464 	str	x4, [x3, #616]
    3b50:	f9404c44 	ldr	x4, [x2, #152]
    3b54:	f9013864 	str	x4, [x3, #624]
    3b58:	f9405044 	ldr	x4, [x2, #160]
    3b5c:	f9013c64 	str	x4, [x3, #632]
    3b60:	f9405444 	ldr	x4, [x2, #168]
    3b64:	f9014064 	str	x4, [x3, #640]
    3b68:	f9405844 	ldr	x4, [x2, #176]
    3b6c:	f9014464 	str	x4, [x3, #648]
    3b70:	a94b8844 	ldp	x4, x2, [x2, #184]
    3b74:	f9014864 	str	x4, [x3, #656]
    3b78:	f9014c62 	str	x2, [x3, #664]
    3b7c:	97fff68d 	bl	15b0 <swapcontext@plt>
    3b80:	97ffff64 	bl	3910 <fwp_free_zombie>
    3b84:	d503201f 	nop
    3b88:	91014260 	add	x0, x19, #0x50
    3b8c:	b942a000 	ldr	w0, [x0, #672]
    3b90:	340001a0 	cbz	w0, 3bc4 <fwp_block+0x100>
    3b94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b98:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3b9c:	d65f03c0 	ret
    3ba0:	97fffc10 	bl	2be0 <fwp_poll_events>
    3ba4:	f9401a82 	ldr	x2, [x20, #48]
    3ba8:	b4ffffc2 	cbz	x2, 3ba0 <fwp_block+0xdc>
    3bac:	91014261 	add	x1, x19, #0x50
    3bb0:	f9408040 	ldr	x0, [x2, #256]
    3bb4:	f9001820 	str	x0, [x1, #48]
    3bb8:	b5fff9c0 	cbnz	x0, 3af0 <fwp_block+0x2c>
    3bbc:	f900143f 	str	xzr, [x1, #40]
    3bc0:	17ffffcc 	b	3af0 <fwp_block+0x2c>
    3bc4:	b0000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    3bc8:	9102a000 	add	x0, x0, #0xa8
    3bcc:	97fff6c5 	bl	16e0 <getenv@plt>
    3bd0:	5284e202 	mov	w2, #0x2710                	// #10000
    3bd4:	b4000060 	cbz	x0, 3be0 <fwp_block+0x11c>
    3bd8:	39400001 	ldrb	w1, [x0]
    3bdc:	350000c1 	cbnz	w1, 3bf4 <fwp_block+0x130>
    3be0:	91014273 	add	x19, x19, #0x50
    3be4:	b902a262 	str	w2, [x19, #672]
    3be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3bec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3bf0:	d65f03c0 	ret
    3bf4:	52800142 	mov	w2, #0xa                   	// #10
    3bf8:	d2800001 	mov	x1, #0x0                   	// #0
    3bfc:	97fff609 	bl	1420 <strtoll@plt>
    3c00:	d1000403 	sub	x3, x0, #0x1
    3c04:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3c08:	eb02007f 	cmp	x3, x2
    3c0c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3c10:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3c14:	17fffff3 	b	3be0 <fwp_block+0x11c>
    3c18:	d503201f 	nop
    3c1c:	d503201f 	nop

0000000000003c20 <fwp_caps69>:
    3c20:	34000041 	cbz	w1, 3c28 <fwp_caps69+0x8>
    3c24:	d65f03c0 	ret
    3c28:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3c2c:	9114c063 	add	x3, x3, #0x530
    3c30:	f949d861 	ldr	x1, [x3, #5040]
    3c34:	f949ec62 	ldr	x2, [x3, #5080]
    3c38:	cb010001 	sub	x1, x0, x1
    3c3c:	eb02403f 	cmp	x1, x2, lsl #16
    3c40:	54ffff22 	b.cs	3c24 <fwp_caps69+0x4>  // b.hs, b.nlast
    3c44:	d350fc22 	lsr	x2, x1, #16
    3c48:	f949fc65 	ldr	x5, [x3, #5112]
    3c4c:	8b020842 	add	x2, x2, x2, lsl #2
    3c50:	d37df042 	lsl	x2, x2, #3
    3c54:	8b0200a4 	add	x4, x5, x2
    3c58:	f9401083 	ldr	x3, [x4, #32]
    3c5c:	b4fffe43 	cbz	x3, 3c24 <fwp_caps69+0x4>
    3c60:	386268a2 	ldrb	w2, [x5, x2]
    3c64:	7100085f 	cmp	w2, #0x2
    3c68:	540001c0 	b.eq	3ca0 <fwp_caps69+0x80>  // b.none
    3c6c:	7100045f 	cmp	w2, #0x1
    3c70:	54fffda1 	b.ne	3c24 <fwp_caps69+0x4>  // b.any
    3c74:	29430885 	ldp	w5, w2, [x4, #24]
    3c78:	92403c21 	and	x1, x1, #0xffff
    3c7c:	9b057c21 	mul	x1, x1, x5
    3c80:	d360fc21 	lsr	x1, x1, #32
    3c84:	eb02003f 	cmp	x1, x2
    3c88:	54fffce2 	b.cs	3c24 <fwp_caps69+0x4>  // b.hs, b.nlast
    3c8c:	8b010063 	add	x3, x3, x1
    3c90:	39400061 	ldrb	w1, [x3]
    3c94:	7100043f 	cmp	w1, #0x1
    3c98:	54fffc61 	b.ne	3c24 <fwp_caps69+0x4>  // b.any
    3c9c:	17fffd45 	b	31b0 <fwp_mem_free>
    3ca0:	72003c3f 	tst	w1, #0xffff
    3ca4:	54ffff60 	b.eq	3c90 <fwp_caps69+0x70>  // b.none
    3ca8:	d65f03c0 	ret
    3cac:	d503201f 	nop

0000000000003cb0 <fwp_caps45>:
    3cb0:	34000041 	cbz	w1, 3cb8 <fwp_caps45+0x8>
    3cb4:	d65f03c0 	ret
    3cb8:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3cbc:	9114c063 	add	x3, x3, #0x530
    3cc0:	f949d861 	ldr	x1, [x3, #5040]
    3cc4:	f949ec62 	ldr	x2, [x3, #5080]
    3cc8:	cb010001 	sub	x1, x0, x1
    3ccc:	eb02403f 	cmp	x1, x2, lsl #16
    3cd0:	54ffff22 	b.cs	3cb4 <fwp_caps45+0x4>  // b.hs, b.nlast
    3cd4:	d350fc22 	lsr	x2, x1, #16
    3cd8:	f949fc65 	ldr	x5, [x3, #5112]
    3cdc:	8b020842 	add	x2, x2, x2, lsl #2
    3ce0:	d37df042 	lsl	x2, x2, #3
    3ce4:	8b0200a4 	add	x4, x5, x2
    3ce8:	f9401083 	ldr	x3, [x4, #32]
    3cec:	b4fffe43 	cbz	x3, 3cb4 <fwp_caps45+0x4>
    3cf0:	386268a2 	ldrb	w2, [x5, x2]
    3cf4:	7100085f 	cmp	w2, #0x2
    3cf8:	540001c0 	b.eq	3d30 <fwp_caps45+0x80>  // b.none
    3cfc:	7100045f 	cmp	w2, #0x1
    3d00:	54fffda1 	b.ne	3cb4 <fwp_caps45+0x4>  // b.any
    3d04:	29430885 	ldp	w5, w2, [x4, #24]
    3d08:	92403c21 	and	x1, x1, #0xffff
    3d0c:	9b057c21 	mul	x1, x1, x5
    3d10:	d360fc21 	lsr	x1, x1, #32
    3d14:	eb02003f 	cmp	x1, x2
    3d18:	54fffce2 	b.cs	3cb4 <fwp_caps45+0x4>  // b.hs, b.nlast
    3d1c:	8b010063 	add	x3, x3, x1
    3d20:	39400061 	ldrb	w1, [x3]
    3d24:	7100043f 	cmp	w1, #0x1
    3d28:	54fffc61 	b.ne	3cb4 <fwp_caps45+0x4>  // b.any
    3d2c:	17fffd21 	b	31b0 <fwp_mem_free>
    3d30:	72003c3f 	tst	w1, #0xffff
    3d34:	54ffff60 	b.eq	3d20 <fwp_caps45+0x70>  // b.none
    3d38:	d65f03c0 	ret
    3d3c:	d503201f 	nop

0000000000003d40 <fwp_caps74>:
    3d40:	34000041 	cbz	w1, 3d48 <fwp_caps74+0x8>
    3d44:	d65f03c0 	ret
    3d48:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3d4c:	9114c063 	add	x3, x3, #0x530
    3d50:	f949d861 	ldr	x1, [x3, #5040]
    3d54:	f949ec62 	ldr	x2, [x3, #5080]
    3d58:	cb010001 	sub	x1, x0, x1
    3d5c:	eb02403f 	cmp	x1, x2, lsl #16
    3d60:	54ffff22 	b.cs	3d44 <fwp_caps74+0x4>  // b.hs, b.nlast
    3d64:	d350fc22 	lsr	x2, x1, #16
    3d68:	f949fc65 	ldr	x5, [x3, #5112]
    3d6c:	8b020842 	add	x2, x2, x2, lsl #2
    3d70:	d37df042 	lsl	x2, x2, #3
    3d74:	8b0200a4 	add	x4, x5, x2
    3d78:	f9401083 	ldr	x3, [x4, #32]
    3d7c:	b4fffe43 	cbz	x3, 3d44 <fwp_caps74+0x4>
    3d80:	386268a2 	ldrb	w2, [x5, x2]
    3d84:	7100085f 	cmp	w2, #0x2
    3d88:	540001c0 	b.eq	3dc0 <fwp_caps74+0x80>  // b.none
    3d8c:	7100045f 	cmp	w2, #0x1
    3d90:	54fffda1 	b.ne	3d44 <fwp_caps74+0x4>  // b.any
    3d94:	29430885 	ldp	w5, w2, [x4, #24]
    3d98:	92403c21 	and	x1, x1, #0xffff
    3d9c:	9b057c21 	mul	x1, x1, x5
    3da0:	d360fc21 	lsr	x1, x1, #32
    3da4:	eb02003f 	cmp	x1, x2
    3da8:	54fffce2 	b.cs	3d44 <fwp_caps74+0x4>  // b.hs, b.nlast
    3dac:	8b010063 	add	x3, x3, x1
    3db0:	39400061 	ldrb	w1, [x3]
    3db4:	7100043f 	cmp	w1, #0x1
    3db8:	54fffc61 	b.ne	3d44 <fwp_caps74+0x4>  // b.any
    3dbc:	17fffcfd 	b	31b0 <fwp_mem_free>
    3dc0:	72003c3f 	tst	w1, #0xffff
    3dc4:	54ffff60 	b.eq	3db0 <fwp_caps74+0x70>  // b.none
    3dc8:	d65f03c0 	ret
    3dcc:	d503201f 	nop

0000000000003dd0 <fwp_caps32>:
    3dd0:	34000041 	cbz	w1, 3dd8 <fwp_caps32+0x8>
    3dd4:	d65f03c0 	ret
    3dd8:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    3ddc:	9114c063 	add	x3, x3, #0x530
    3de0:	f949d861 	ldr	x1, [x3, #5040]
    3de4:	f949ec62 	ldr	x2, [x3, #5080]
    3de8:	cb010001 	sub	x1, x0, x1
    3dec:	eb02403f 	cmp	x1, x2, lsl #16
    3df0:	54ffff22 	b.cs	3dd4 <fwp_caps32+0x4>  // b.hs, b.nlast
    3df4:	d350fc22 	lsr	x2, x1, #16
    3df8:	f949fc65 	ldr	x5, [x3, #5112]
    3dfc:	8b020842 	add	x2, x2, x2, lsl #2
    3e00:	d37df042 	lsl	x2, x2, #3
    3e04:	8b0200a4 	add	x4, x5, x2
    3e08:	f9401083 	ldr	x3, [x4, #32]
    3e0c:	b4fffe43 	cbz	x3, 3dd4 <fwp_caps32+0x4>
    3e10:	386268a2 	ldrb	w2, [x5, x2]
    3e14:	7100085f 	cmp	w2, #0x2
    3e18:	540001c0 	b.eq	3e50 <fwp_caps32+0x80>  // b.none
    3e1c:	7100045f 	cmp	w2, #0x1
    3e20:	54fffda1 	b.ne	3dd4 <fwp_caps32+0x4>  // b.any
    3e24:	29430885 	ldp	w5, w2, [x4, #24]
    3e28:	92403c21 	and	x1, x1, #0xffff
    3e2c:	9b057c21 	mul	x1, x1, x5
    3e30:	d360fc21 	lsr	x1, x1, #32
    3e34:	eb02003f 	cmp	x1, x2
    3e38:	54fffce2 	b.cs	3dd4 <fwp_caps32+0x4>  // b.hs, b.nlast
    3e3c:	8b010063 	add	x3, x3, x1
    3e40:	39400061 	ldrb	w1, [x3]
    3e44:	7100043f 	cmp	w1, #0x1
    3e48:	54fffc61 	b.ne	3dd4 <fwp_caps32+0x4>  // b.any
    3e4c:	17fffcd9 	b	31b0 <fwp_mem_free>
    3e50:	72003c3f 	tst	w1, #0xffff
    3e54:	54ffff60 	b.eq	3e40 <fwp_caps32+0x70>  // b.none
    3e58:	d65f03c0 	ret
    3e5c:	d503201f 	nop

0000000000003e60 <fwp_data.part.0.constprop.0>:
    3e60:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3e64:	910003fd 	mov	x29, sp
    3e68:	a90363f7 	stp	x23, x24, [sp, #48]
    3e6c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3e70:	91014302 	add	x2, x24, #0x50
    3e74:	a9046bf9 	stp	x25, x26, [sp, #64]
    3e78:	b9404059 	ldr	w25, [x2, #64]
    3e7c:	a90153f3 	stp	x19, x20, [sp, #16]
    3e80:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    3e84:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e88:	2a0003f6 	mov	w22, w0
    3e8c:	aa0103f5 	mov	x21, x1
    3e90:	350005f9 	cbnz	w25, 3f4c <fwp_data.part.0.constprop.0+0xec>
    3e94:	9114c280 	add	x0, x20, #0x530
    3e98:	b953a400 	ldr	w0, [x0, #5028]
    3e9c:	34000c80 	cbz	w0, 402c <fwp_data.part.0.constprop.0+0x1cc>
    3ea0:	9114c283 	add	x3, x20, #0x530
    3ea4:	397e8862 	ldrb	w2, [x3, #4002]
    3ea8:	910f0040 	add	x0, x2, #0x3c0
    3eac:	8b020442 	add	x2, x2, x2, lsl #1
    3eb0:	d37df042 	lsl	x2, x2, #3
    3eb4:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    3eb8:	2a1a03f7 	mov	w23, w26
    3ebc:	f8626873 	ldr	x19, [x3, x2]
    3ec0:	b4000753 	cbz	x19, 3fa8 <fwp_data.part.0.constprop.0+0x148>
    3ec4:	f9400260 	ldr	x0, [x19]
    3ec8:	aa2003e0 	mvn	x0, x0
    3ecc:	f8226860 	str	x0, [x3, x2]
    3ed0:	f10062ff 	cmp	x23, #0x18
    3ed4:	540000e9 	b.ls	3ef0 <fwp_data.part.0.constprop.0+0x90>  // b.plast
    3ed8:	d10066e2 	sub	x2, x23, #0x19
    3edc:	91006260 	add	x0, x19, #0x18
    3ee0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    3ee4:	52800001 	mov	w1, #0x0                   	// #0
    3ee8:	91002042 	add	x2, x2, #0x8
    3eec:	97fff58d 	bl	1520 <memset@plt>
    3ef0:	9114c280 	add	x0, x20, #0x530
    3ef4:	f94a1002 	ldr	x2, [x0, #5152]
    3ef8:	ab170042 	adds	x2, x2, x23
    3efc:	54000a22 	b.cs	4040 <fwp_data.part.0.constprop.0+0x1e0>  // b.hs, b.nlast
    3f00:	f94a1401 	ldr	x1, [x0, #5160]
    3f04:	f90a1002 	str	x2, [x0, #5152]
    3f08:	eb01005f 	cmp	x2, x1
    3f0c:	54000049 	b.ls	3f14 <fwp_data.part.0.constprop.0+0xb4>  // b.plast
    3f10:	f90a1402 	str	x2, [x0, #5160]
    3f14:	9114c294 	add	x20, x20, #0x530
    3f18:	1e630341 	ucvtf	d1, w26
    3f1c:	fd4a1e80 	ldr	d0, [x20, #5176]
    3f20:	1e612800 	fadd	d0, d0, d1
    3f24:	fd0a1e80 	str	d0, [x20, #5176]
    3f28:	34000599 	cbz	w25, 3fd8 <fwp_data.part.0.constprop.0+0x178>
    3f2c:	91014300 	add	x0, x24, #0x50
    3f30:	9e630040 	ucvtf	d0, x2
    3f34:	fd415c02 	ldr	d2, [x0, #696]
    3f38:	fd416001 	ldr	d1, [x0, #704]
    3f3c:	1e623800 	fsub	d0, d0, d2
    3f40:	1e602030 	fcmpe	d1, d0
    3f44:	54000464 	b.mi	3fd0 <fwp_data.part.0.constprop.0+0x170>  // b.first
    3f48:	14000024 	b	3fd8 <fwp_data.part.0.constprop.0+0x178>
    3f4c:	9114c283 	add	x3, x20, #0x530
    3f50:	f9415441 	ldr	x1, [x2, #680]
    3f54:	f9415840 	ldr	x0, [x2, #688]
    3f58:	91000421 	add	x1, x1, #0x1
    3f5c:	b953a463 	ldr	w3, [x3, #5028]
    3f60:	91006000 	add	x0, x0, #0x18
    3f64:	f9015441 	str	x1, [x2, #680]
    3f68:	f9015840 	str	x0, [x2, #688]
    3f6c:	35fff9a3 	cbnz	w3, 3ea0 <fwp_data.part.0.constprop.0+0x40>
    3f70:	52800001 	mov	w1, #0x0                   	// #0
    3f74:	d2800300 	mov	x0, #0x18                  	// #24
    3f78:	97fffd56 	bl	34d0 <fwp_heap_alloc_slow>
    3f7c:	aa0003f3 	mov	x19, x0
    3f80:	9114c294 	add	x20, x20, #0x530
    3f84:	91014300 	add	x0, x24, #0x50
    3f88:	fd4a1280 	ldr	d0, [x20, #5152]
    3f8c:	fd415c02 	ldr	d2, [x0, #696]
    3f90:	fd416001 	ldr	d1, [x0, #704]
    3f94:	7e61d800 	ucvtf	d0, d0
    3f98:	1e623800 	fsub	d0, d0, d2
    3f9c:	1e612010 	fcmpe	d0, d1
    3fa0:	5400042c 	b.gt	4024 <fwp_data.part.0.constprop.0+0x1c4>
    3fa4:	17ffffe7 	b	3f40 <fwp_data.part.0.constprop.0+0xe0>
    3fa8:	8b020063 	add	x3, x3, x2
    3fac:	f9400473 	ldr	x19, [x3, #8]
    3fb0:	b40002f3 	cbz	x19, 400c <fwp_data.part.0.constprop.0+0x1ac>
    3fb4:	f9400860 	ldr	x0, [x3, #16]
    3fb8:	cb130000 	sub	x0, x0, x19
    3fbc:	eb17001f 	cmp	x0, x23
    3fc0:	54000263 	b.cc	400c <fwp_data.part.0.constprop.0+0x1ac>  // b.lo, b.ul, b.last
    3fc4:	8b170260 	add	x0, x19, x23
    3fc8:	f9000460 	str	x0, [x3, #8]
    3fcc:	17ffffc1 	b	3ed0 <fwp_data.part.0.constprop.0+0x70>
    3fd0:	91014318 	add	x24, x24, #0x50
    3fd4:	fd016300 	str	d0, [x24, #704]
    3fd8:	52800040 	mov	w0, #0x2                   	// #2
    3fdc:	29000276 	stp	w22, w0, [x19]
    3fe0:	aa1303e0 	mov	x0, x19
    3fe4:	f94002a1 	ldr	x1, [x21]
    3fe8:	f9000661 	str	x1, [x19, #8]
    3fec:	f94006a1 	ldr	x1, [x21, #8]
    3ff0:	f9000a61 	str	x1, [x19, #16]
    3ff4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3ff8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3ffc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4000:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4004:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4008:	d65f03c0 	ret
    400c:	52800001 	mov	w1, #0x0                   	// #0
    4010:	d2800300 	mov	x0, #0x18                  	// #24
    4014:	97fffd2f 	bl	34d0 <fwp_heap_alloc_slow>
    4018:	aa0003f3 	mov	x19, x0
    401c:	34fffdf9 	cbz	w25, 3fd8 <fwp_data.part.0.constprop.0+0x178>
    4020:	17ffffd8 	b	3f80 <fwp_data.part.0.constprop.0+0x120>
    4024:	fd016000 	str	d0, [x0, #704]
    4028:	17ffffec 	b	3fd8 <fwp_data.part.0.constprop.0+0x178>
    402c:	52800001 	mov	w1, #0x0                   	// #0
    4030:	d2800300 	mov	x0, #0x18                  	// #24
    4034:	97fffd27 	bl	34d0 <fwp_heap_alloc_slow>
    4038:	aa0003f3 	mov	x19, x0
    403c:	17ffffe7 	b	3fd8 <fwp_data.part.0.constprop.0+0x178>
    4040:	97fff744 	bl	1d50 <fwp_heap_oom>

0000000000004044 <f74>:
    4044:	9e670003 	fmov	d3, x0
    4048:	9e670021 	fmov	d1, x1
    404c:	d2f80f20 	mov	x0, #0xc079000000000000    	// #-4577627546245398528
    4050:	1e6e1002 	fmov	d2, #1.000000000000000000e+00
    4054:	1e630865 	fmul	d5, d3, d3
    4058:	9e670000 	fmov	d0, x0
    405c:	1e633842 	fsub	d2, d2, d3
    4060:	d10103ff 	sub	sp, sp, #0x40
    4064:	1e600860 	fmul	d0, d3, d0
    4068:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    406c:	f00000c2 	adrp	x2, 1f000 <__FRAME_END__+0x15a68>
    4070:	f947f442 	ldr	x2, [x2, #4072]
    4074:	1e653821 	fsub	d1, d1, d5
    4078:	1e622842 	fadd	d2, d2, d2
    407c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4080:	9e670004 	fmov	d4, x0
    4084:	910083fd 	add	x29, sp, #0x20
    4088:	1e610800 	fmul	d0, d0, d1
    408c:	a90353f3 	stp	x19, x20, [sp, #48]
    4090:	1e640821 	fmul	d1, d1, d4
    4094:	f9400043 	ldr	x3, [x2]
    4098:	f9000fe3 	str	x3, [sp, #24]
    409c:	d2800003 	mov	x3, #0x0                   	// #0
    40a0:	910023e1 	add	x1, sp, #0x8
    40a4:	52800000 	mov	w0, #0x0                   	// #0
    40a8:	1e623800 	fsub	d0, d0, d2
    40ac:	6d0087e0 	stp	d0, d1, [sp, #8]
    40b0:	97ffff6c 	bl	3e60 <fwp_data.part.0.constprop.0>
    40b4:	b0000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    40b8:	9114c063 	add	x3, x3, #0x530
    40bc:	aa0003f3 	mov	x19, x0
    40c0:	f949d861 	ldr	x1, [x3, #5040]
    40c4:	f949ec60 	ldr	x0, [x3, #5080]
    40c8:	cb010261 	sub	x1, x19, x1
    40cc:	eb00403f 	cmp	x1, x0, lsl #16
    40d0:	54000322 	b.cs	4134 <f74+0xf0>  // b.hs, b.nlast
    40d4:	d350fc22 	lsr	x2, x1, #16
    40d8:	f949fc63 	ldr	x3, [x3, #5112]
    40dc:	8b020842 	add	x2, x2, x2, lsl #2
    40e0:	d37df042 	lsl	x2, x2, #3
    40e4:	8b020060 	add	x0, x3, x2
    40e8:	f9401014 	ldr	x20, [x0, #32]
    40ec:	b4000254 	cbz	x20, 4134 <f74+0xf0>
    40f0:	38626862 	ldrb	w2, [x3, x2]
    40f4:	7100085f 	cmp	w2, #0x2
    40f8:	54000360 	b.eq	4164 <f74+0x120>  // b.none
    40fc:	7100045f 	cmp	w2, #0x1
    4100:	540001a1 	b.ne	4134 <f74+0xf0>  // b.any
    4104:	29430002 	ldp	w2, w0, [x0, #24]
    4108:	92403c21 	and	x1, x1, #0xffff
    410c:	9b027c21 	mul	x1, x1, x2
    4110:	d360fc21 	lsr	x1, x1, #32
    4114:	eb00003f 	cmp	x1, x0
    4118:	540000e2 	b.cs	4134 <f74+0xf0>  // b.hs, b.nlast
    411c:	8b010294 	add	x20, x20, x1
    4120:	39400280 	ldrb	w0, [x20]
    4124:	7103fc1f 	cmp	w0, #0xff
    4128:	54000240 	b.eq	4170 <f74+0x12c>  // b.none
    412c:	52800020 	mov	w0, #0x1                   	// #1
    4130:	39000280 	strb	w0, [x20]
    4134:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    4138:	f947f400 	ldr	x0, [x0, #4072]
    413c:	f9400fe2 	ldr	x2, [sp, #24]
    4140:	f9400001 	ldr	x1, [x0]
    4144:	eb010042 	subs	x2, x2, x1
    4148:	d2800001 	mov	x1, #0x0                   	// #0
    414c:	54000181 	b.ne	417c <f74+0x138>  // b.any
    4150:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4154:	aa1303e0 	mov	x0, x19
    4158:	a94353f3 	ldp	x19, x20, [sp, #48]
    415c:	910103ff 	add	sp, sp, #0x40
    4160:	d65f03c0 	ret
    4164:	72003c3f 	tst	w1, #0xffff
    4168:	54fffe61 	b.ne	4134 <f74+0xf0>  // b.any
    416c:	17ffffed 	b	4120 <f74+0xdc>
    4170:	aa1403e0 	mov	x0, x20
    4174:	97fffb6f 	bl	2f30 <fwp_rc_forget_slot>
    4178:	17ffffed 	b	412c <f74+0xe8>
    417c:	97fff4f5 	bl	1550 <__stack_chk_fail@plt>

0000000000004180 <fwp_owned_entry74>:
    4180:	a9400400 	ldp	x0, x1, [x0]
    4184:	17ffffb0 	b	4044 <f74>
    4188:	d503201f 	nop
    418c:	d503201f 	nop

0000000000004190 <e74>:
    4190:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4194:	910003fd 	mov	x29, sp
    4198:	a9400400 	ldp	x0, x1, [x0]
    419c:	f9000bf3 	str	x19, [sp, #16]
    41a0:	97ffffa9 	bl	4044 <f74>
    41a4:	aa0003f3 	mov	x19, x0
    41a8:	97fffd22 	bl	3630 <fwp_rc_share>
    41ac:	aa1303e0 	mov	x0, x19
    41b0:	f9400bf3 	ldr	x19, [sp, #16]
    41b4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    41b8:	d65f03c0 	ret
    41bc:	d503201f 	nop

00000000000041c0 <fwp_map_finish_protected.isra.0>:
    41c0:	d10183ff 	sub	sp, sp, #0x60
    41c4:	a9027bfd 	stp	x29, x30, [sp, #32]
    41c8:	910083fd 	add	x29, sp, #0x20
    41cc:	a90563f7 	stp	x23, x24, [sp, #80]
    41d0:	aa0003f7 	mov	x23, x0
    41d4:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    41d8:	f947f400 	ldr	x0, [x0, #4072]
    41dc:	a9045bf5 	stp	x21, x22, [sp, #64]
    41e0:	a940d6e2 	ldp	x2, x21, [x23, #8]
    41e4:	f9400001 	ldr	x1, [x0]
    41e8:	f9000fe1 	str	x1, [sp, #24]
    41ec:	d2800001 	mov	x1, #0x0                   	// #0
    41f0:	b40005e2 	cbz	x2, 42ac <fwp_map_finish_protected.isra.0+0xec>
    41f4:	b0000178 	adrp	x24, 31000 <fwp_root_context+0xcb0>
    41f8:	9114c318 	add	x24, x24, #0x530
    41fc:	a90353f3 	stp	x19, x20, [sp, #48]
    4200:	910023f3 	add	x19, sp, #0x8
    4204:	52800034 	mov	w20, #0x1                   	// #1
    4208:	f94002e3 	ldr	x3, [x23]
    420c:	aa1303e1 	mov	x1, x19
    4210:	52800020 	mov	w0, #0x1                   	// #1
    4214:	8b020c62 	add	x2, x3, x2, lsl #3
    4218:	f85f8042 	ldur	x2, [x2, #-8]
    421c:	a900d7e2 	stp	x2, x21, [sp, #8]
    4220:	97ffff10 	bl	3e60 <fwp_data.part.0.constprop.0>
    4224:	aa0003f5 	mov	x21, x0
    4228:	f949db01 	ldr	x1, [x24, #5040]
    422c:	f949ef02 	ldr	x2, [x24, #5080]
    4230:	cb010001 	sub	x1, x0, x1
    4234:	eb02403f 	cmp	x1, x2, lsl #16
    4238:	54000302 	b.cs	4298 <fwp_map_finish_protected.isra.0+0xd8>  // b.hs, b.nlast
    423c:	d350fc22 	lsr	x2, x1, #16
    4240:	f949ff04 	ldr	x4, [x24, #5112]
    4244:	8b020842 	add	x2, x2, x2, lsl #2
    4248:	d37df042 	lsl	x2, x2, #3
    424c:	8b020083 	add	x3, x4, x2
    4250:	f9401076 	ldr	x22, [x3, #32]
    4254:	b4000236 	cbz	x22, 4298 <fwp_map_finish_protected.isra.0+0xd8>
    4258:	38626882 	ldrb	w2, [x4, x2]
    425c:	7100085f 	cmp	w2, #0x2
    4260:	540004a0 	b.eq	42f4 <fwp_map_finish_protected.isra.0+0x134>  // b.none
    4264:	7100045f 	cmp	w2, #0x1
    4268:	54000181 	b.ne	4298 <fwp_map_finish_protected.isra.0+0xd8>  // b.any
    426c:	29430062 	ldp	w2, w0, [x3, #24]
    4270:	92403c21 	and	x1, x1, #0xffff
    4274:	9b027c21 	mul	x1, x1, x2
    4278:	d360fc21 	lsr	x1, x1, #32
    427c:	eb00003f 	cmp	x1, x0
    4280:	540000c2 	b.cs	4298 <fwp_map_finish_protected.isra.0+0xd8>  // b.hs, b.nlast
    4284:	8b0102d6 	add	x22, x22, x1
    4288:	394002c0 	ldrb	w0, [x22]
    428c:	7103fc1f 	cmp	w0, #0xff
    4290:	540002c0 	b.eq	42e8 <fwp_map_finish_protected.isra.0+0x128>  // b.none
    4294:	390002d4 	strb	w20, [x22]
    4298:	f94006e2 	ldr	x2, [x23, #8]
    429c:	d1000442 	sub	x2, x2, #0x1
    42a0:	a900d6e2 	stp	x2, x21, [x23, #8]
    42a4:	b5fffb22 	cbnz	x2, 4208 <fwp_map_finish_protected.isra.0+0x48>
    42a8:	a94353f3 	ldp	x19, x20, [sp, #48]
    42ac:	f94002e0 	ldr	x0, [x23]
    42b0:	97fffbc0 	bl	31b0 <fwp_mem_free>
    42b4:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    42b8:	f947f400 	ldr	x0, [x0, #4072]
    42bc:	f9400fe2 	ldr	x2, [sp, #24]
    42c0:	f9400001 	ldr	x1, [x0]
    42c4:	eb010042 	subs	x2, x2, x1
    42c8:	d2800001 	mov	x1, #0x0                   	// #0
    42cc:	540001a1 	b.ne	4300 <fwp_map_finish_protected.isra.0+0x140>  // b.any
    42d0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    42d4:	aa1503e0 	mov	x0, x21
    42d8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    42dc:	a94563f7 	ldp	x23, x24, [sp, #80]
    42e0:	910183ff 	add	sp, sp, #0x60
    42e4:	d65f03c0 	ret
    42e8:	aa1603e0 	mov	x0, x22
    42ec:	97fffb11 	bl	2f30 <fwp_rc_forget_slot>
    42f0:	17ffffe9 	b	4294 <fwp_map_finish_protected.isra.0+0xd4>
    42f4:	72003c3f 	tst	w1, #0xffff
    42f8:	54fffd01 	b.ne	4298 <fwp_map_finish_protected.isra.0+0xd8>  // b.any
    42fc:	17ffffe3 	b	4288 <fwp_map_finish_protected.isra.0+0xc8>
    4300:	a90353f3 	stp	x19, x20, [sp, #48]
    4304:	97fff493 	bl	1550 <__stack_chk_fail@plt>
    4308:	d503201f 	nop
    430c:	d503201f 	nop

0000000000004310 <fwp_heap_alloc>:
    4310:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4314:	910003fd 	mov	x29, sp
    4318:	a9025bf5 	stp	x21, x22, [sp, #32]
    431c:	900000f6 	adrp	x22, 20000 <__data_start>
    4320:	910142c2 	add	x2, x22, #0x50
    4324:	a90363f7 	stp	x23, x24, [sp, #48]
    4328:	b9404058 	ldr	w24, [x2, #64]
    432c:	a90153f3 	stp	x19, x20, [sp, #16]
    4330:	7100031f 	cmp	w24, #0x0
    4334:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    4338:	54000881 	b.ne	4448 <fwp_heap_alloc+0x138>  // b.any
    433c:	b0000177 	adrp	x23, 31000 <fwp_root_context+0xcb0>
    4340:	9114c2f3 	add	x19, x23, #0x530
    4344:	f140101f 	cmp	x0, #0x4, lsl #12
    4348:	b953a662 	ldr	w2, [x19, #5028]
    434c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4350:	54000760 	b.eq	443c <fwp_heap_alloc+0x12c>  // b.none
    4354:	91003c03 	add	x3, x0, #0xf
    4358:	937c7c22 	sbfiz	x2, x1, #4, #32
    435c:	cb21c042 	sub	x2, x2, w1, sxtw
    4360:	8b431263 	add	x3, x19, x3, lsr #4
    4364:	d37ae442 	lsl	x2, x2, #6
    4368:	397e8063 	ldrb	w3, [x3, #4000]
    436c:	910f0064 	add	x4, x3, #0x3c0
    4370:	8b030463 	add	x3, x3, x3, lsl #1
    4374:	8b030c43 	add	x3, x2, x3, lsl #3
    4378:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    437c:	2a1503f4 	mov	w20, w21
    4380:	f8636a64 	ldr	x4, [x19, x3]
    4384:	b40004e4 	cbz	x4, 4420 <fwp_heap_alloc+0x110>
    4388:	f9400085 	ldr	x5, [x4]
    438c:	7100043f 	cmp	w1, #0x1
    4390:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    4394:	aa0403e0 	mov	x0, x4
    4398:	aa2503e5 	mvn	x5, x5
    439c:	52800001 	mov	w1, #0x0                   	// #0
    43a0:	f8236a65 	str	x5, [x19, x3]
    43a4:	97fff45f 	bl	1520 <memset@plt>
    43a8:	aa0003e4 	mov	x4, x0
    43ac:	f94a1260 	ldr	x0, [x19, #5152]
    43b0:	ab140000 	adds	x0, x0, x20
    43b4:	54000742 	b.cs	449c <fwp_heap_alloc+0x18c>  // b.hs, b.nlast
    43b8:	f94a1661 	ldr	x1, [x19, #5160]
    43bc:	f90a1260 	str	x0, [x19, #5152]
    43c0:	eb01001f 	cmp	x0, x1
    43c4:	54000049 	b.ls	43cc <fwp_heap_alloc+0xbc>  // b.plast
    43c8:	f90a1660 	str	x0, [x19, #5160]
    43cc:	9114c2e0 	add	x0, x23, #0x530
    43d0:	1e6302a1 	ucvtf	d1, w21
    43d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    43d8:	1e612800 	fadd	d0, d0, d1
    43dc:	fd0a1c00 	str	d0, [x0, #5176]
    43e0:	34000158 	cbz	w24, 4408 <fwp_heap_alloc+0xf8>
    43e4:	9114c2e1 	add	x1, x23, #0x530
    43e8:	910142c0 	add	x0, x22, #0x50
    43ec:	fd4a1020 	ldr	d0, [x1, #5152]
    43f0:	fd415c02 	ldr	d2, [x0, #696]
    43f4:	fd416001 	ldr	d1, [x0, #704]
    43f8:	7e61d800 	ucvtf	d0, d0
    43fc:	1e623800 	fsub	d0, d0, d2
    4400:	1e612010 	fcmpe	d0, d1
    4404:	5400030c 	b.gt	4464 <fwp_heap_alloc+0x154>
    4408:	a94153f3 	ldp	x19, x20, [sp, #16]
    440c:	aa0403e0 	mov	x0, x4
    4410:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4414:	a94363f7 	ldp	x23, x24, [sp, #48]
    4418:	a8c47bfd 	ldp	x29, x30, [sp], #64
    441c:	d65f03c0 	ret
    4420:	8b030263 	add	x3, x19, x3
    4424:	f9400464 	ldr	x4, [x3, #8]
    4428:	b40000a4 	cbz	x4, 443c <fwp_heap_alloc+0x12c>
    442c:	f9400862 	ldr	x2, [x3, #16]
    4430:	cb040042 	sub	x2, x2, x4
    4434:	eb02029f 	cmp	x20, x2
    4438:	54000249 	b.ls	4480 <fwp_heap_alloc+0x170>  // b.plast
    443c:	97fffc25 	bl	34d0 <fwp_heap_alloc_slow>
    4440:	aa0003e4 	mov	x4, x0
    4444:	17ffffe7 	b	43e0 <fwp_heap_alloc+0xd0>
    4448:	f9415444 	ldr	x4, [x2, #680]
    444c:	f9415843 	ldr	x3, [x2, #688]
    4450:	91000484 	add	x4, x4, #0x1
    4454:	f9015444 	str	x4, [x2, #680]
    4458:	8b000063 	add	x3, x3, x0
    445c:	f9015843 	str	x3, [x2, #688]
    4460:	17ffffb7 	b	433c <fwp_heap_alloc+0x2c>
    4464:	a94153f3 	ldp	x19, x20, [sp, #16]
    4468:	fd016000 	str	d0, [x0, #704]
    446c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4470:	aa0403e0 	mov	x0, x4
    4474:	a94363f7 	ldp	x23, x24, [sp, #48]
    4478:	a8c47bfd 	ldp	x29, x30, [sp], #64
    447c:	d65f03c0 	ret
    4480:	7100043f 	cmp	w1, #0x1
    4484:	8b140085 	add	x5, x4, x20
    4488:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    448c:	52800001 	mov	w1, #0x0                   	// #0
    4490:	aa0403e0 	mov	x0, x4
    4494:	f9000465 	str	x5, [x3, #8]
    4498:	17ffffc3 	b	43a4 <fwp_heap_alloc+0x94>
    449c:	97fff62d 	bl	1d50 <fwp_heap_oom>

00000000000044a0 <fwp_map_items>:
    44a0:	b40003a0 	cbz	x0, 4514 <fwp_map_items+0x74>
    44a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    44a8:	aa0003e3 	mov	x3, x0
    44ac:	d2800002 	mov	x2, #0x0                   	// #0
    44b0:	910003fd 	mov	x29, sp
    44b4:	f9000bf3 	str	x19, [sp, #16]
    44b8:	aa0003f3 	mov	x19, x0
    44bc:	d503201f 	nop
    44c0:	f9400863 	ldr	x3, [x3, #16]
    44c4:	aa0203e0 	mov	x0, x2
    44c8:	91000442 	add	x2, x2, #0x1
    44cc:	b5ffffa3 	cbnz	x3, 44c0 <fwp_map_items+0x20>
    44d0:	f9000022 	str	x2, [x1]
    44d4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    44d8:	eb01005f 	cmp	x2, x1
    44dc:	54000248 	b.hi	4524 <fwp_map_items+0x84>  // b.pmore
    44e0:	91000800 	add	x0, x0, #0x2
    44e4:	52800041 	mov	w1, #0x2                   	// #2
    44e8:	d37df000 	lsl	x0, x0, #3
    44ec:	97ffff89 	bl	4310 <fwp_heap_alloc>
    44f0:	aa0003e1 	mov	x1, x0
    44f4:	d503201f 	nop
    44f8:	f9400662 	ldr	x2, [x19, #8]
    44fc:	f8008422 	str	x2, [x1], #8
    4500:	f9400a73 	ldr	x19, [x19, #16]
    4504:	b5ffffb3 	cbnz	x19, 44f8 <fwp_map_items+0x58>
    4508:	f9400bf3 	ldr	x19, [sp, #16]
    450c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4510:	d65f03c0 	ret
    4514:	f900003f 	str	xzr, [x1]
    4518:	d2800100 	mov	x0, #0x8                   	// #8
    451c:	52800041 	mov	w1, #0x2                   	// #2
    4520:	17ffff7c 	b	4310 <fwp_heap_alloc>
    4524:	90000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    4528:	9102e000 	add	x0, x0, #0xb8
    452c:	97fff775 	bl	2300 <fwp_trap>

0000000000004530 <fwp_drop4>:
    4530:	b0000165 	adrp	x5, 31000 <fwp_root_context+0xcb0>
    4534:	9114c0a3 	add	x3, x5, #0x530
    4538:	f949d861 	ldr	x1, [x3, #5040]
    453c:	f949ec62 	ldr	x2, [x3, #5080]
    4540:	cb010001 	sub	x1, x0, x1
    4544:	eb02403f 	cmp	x1, x2, lsl #16
    4548:	54000542 	b.cs	45f0 <fwp_drop4+0xc0>  // b.hs, b.nlast
    454c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4550:	d350fc22 	lsr	x2, x1, #16
    4554:	910003fd 	mov	x29, sp
    4558:	8b020842 	add	x2, x2, x2, lsl #2
    455c:	f949fc64 	ldr	x4, [x3, #5112]
    4560:	d37df042 	lsl	x2, x2, #3
    4564:	f9000bf3 	str	x19, [sp, #16]
    4568:	8b020083 	add	x3, x4, x2
    456c:	f9401073 	ldr	x19, [x3, #32]
    4570:	b40002b3 	cbz	x19, 45c4 <fwp_drop4+0x94>
    4574:	38626882 	ldrb	w2, [x4, x2]
    4578:	7100085f 	cmp	w2, #0x2
    457c:	540002a0 	b.eq	45d0 <fwp_drop4+0xa0>  // b.none
    4580:	7100045f 	cmp	w2, #0x1
    4584:	54000201 	b.ne	45c4 <fwp_drop4+0x94>  // b.any
    4588:	29430864 	ldp	w4, w2, [x3, #24]
    458c:	92403c21 	and	x1, x1, #0xffff
    4590:	9b047c21 	mul	x1, x1, x4
    4594:	d360fc21 	lsr	x1, x1, #32
    4598:	eb02003f 	cmp	x1, x2
    459c:	54000142 	b.cs	45c4 <fwp_drop4+0x94>  // b.hs, b.nlast
    45a0:	8b010273 	add	x19, x19, x1
    45a4:	39400261 	ldrb	w1, [x19]
    45a8:	340000e1 	cbz	w1, 45c4 <fwp_drop4+0x94>
    45ac:	7100043f 	cmp	w1, #0x1
    45b0:	540001a0 	b.eq	45e4 <fwp_drop4+0xb4>  // b.none
    45b4:	7103fc3f 	cmp	w1, #0xff
    45b8:	540001e0 	b.eq	45f4 <fwp_drop4+0xc4>  // b.none
    45bc:	51000421 	sub	w1, w1, #0x1
    45c0:	39000261 	strb	w1, [x19]
    45c4:	f9400bf3 	ldr	x19, [sp, #16]
    45c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45cc:	d65f03c0 	ret
    45d0:	72003c3f 	tst	w1, #0xffff
    45d4:	54fffe80 	b.eq	45a4 <fwp_drop4+0x74>  // b.none
    45d8:	f9400bf3 	ldr	x19, [sp, #16]
    45dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45e0:	d65f03c0 	ret
    45e4:	f9400bf3 	ldr	x19, [sp, #16]
    45e8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    45ec:	17fffaf1 	b	31b0 <fwp_mem_free>
    45f0:	d65f03c0 	ret
    45f4:	ca534660 	eor	x0, x19, x19, lsr #17
    45f8:	9114c0a5 	add	x5, x5, #0x530
    45fc:	ca402400 	eor	x0, x0, x0, lsr #9
    4600:	8b200ca0 	add	x0, x5, w0, uxtb #3
    4604:	f94a2400 	ldr	x0, [x0, #5192]
    4608:	b5000080 	cbnz	x0, 4618 <fwp_drop4+0xe8>
    460c:	14000010 	b	464c <fwp_drop4+0x11c>
    4610:	f9400800 	ldr	x0, [x0, #16]
    4614:	b40001c0 	cbz	x0, 464c <fwp_drop4+0x11c>
    4618:	f9400001 	ldr	x1, [x0]
    461c:	eb13003f 	cmp	x1, x19
    4620:	54ffff81 	b.ne	4610 <fwp_drop4+0xe0>  // b.any
    4624:	f9400401 	ldr	x1, [x0, #8]
    4628:	d1000421 	sub	x1, x1, #0x1
    462c:	f9000401 	str	x1, [x0, #8]
    4630:	f103f83f 	cmp	x1, #0xfe
    4634:	54fffc81 	b.ne	45c4 <fwp_drop4+0x94>  // b.any
    4638:	aa1303e0 	mov	x0, x19
    463c:	97fffa3d 	bl	2f30 <fwp_rc_forget_slot>
    4640:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4644:	39000260 	strb	w0, [x19]
    4648:	17ffffdf 	b	45c4 <fwp_drop4+0x94>
    464c:	90000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    4650:	9100c000 	add	x0, x0, #0x30
    4654:	97fff72b 	bl	2300 <fwp_trap>
    4658:	d503201f 	nop
    465c:	d503201f 	nop

0000000000004660 <fwp_owned_entry50>:
    4660:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4664:	910003fd 	mov	x29, sp
    4668:	f9400000 	ldr	x0, [x0]
    466c:	f9000bf3 	str	x19, [sp, #16]
    4670:	f9400813 	ldr	x19, [x0, #16]
    4674:	97ffffaf 	bl	4530 <fwp_drop4>
    4678:	aa1303e0 	mov	x0, x19
    467c:	f9400bf3 	ldr	x19, [sp, #16]
    4680:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4684:	d65f03c0 	ret
    4688:	d503201f 	nop
    468c:	d503201f 	nop

0000000000004690 <fwp_owned_entry47>:
    4690:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4694:	910003fd 	mov	x29, sp
    4698:	f9400000 	ldr	x0, [x0]
    469c:	f9000bf3 	str	x19, [sp, #16]
    46a0:	f9400413 	ldr	x19, [x0, #8]
    46a4:	97ffffa3 	bl	4530 <fwp_drop4>
    46a8:	aa1303e0 	mov	x0, x19
    46ac:	f9400bf3 	ldr	x19, [sp, #16]
    46b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    46b4:	d65f03c0 	ret
    46b8:	d503201f 	nop
    46bc:	d503201f 	nop

00000000000046c0 <fwp_arg_drop47>:
    46c0:	7100003f 	cmp	w1, #0x0
    46c4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    46c8:	54000041 	b.ne	46d0 <fwp_arg_drop47+0x10>  // b.any
    46cc:	d65f03c0 	ret
    46d0:	f9400000 	ldr	x0, [x0]
    46d4:	17ffff97 	b	4530 <fwp_drop4>
    46d8:	d503201f 	nop
    46dc:	d503201f 	nop

00000000000046e0 <e50>:
    46e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    46e4:	910003fd 	mov	x29, sp
    46e8:	a90153f3 	stp	x19, x20, [sp, #16]
    46ec:	f9400013 	ldr	x19, [x0]
    46f0:	aa1303e0 	mov	x0, x19
    46f4:	97fffbcf 	bl	3630 <fwp_rc_share>
    46f8:	f9400a74 	ldr	x20, [x19, #16]
    46fc:	aa1303e0 	mov	x0, x19
    4700:	97ffff8c 	bl	4530 <fwp_drop4>
    4704:	aa1403e0 	mov	x0, x20
    4708:	97fffbca 	bl	3630 <fwp_rc_share>
    470c:	aa1403e0 	mov	x0, x20
    4710:	a94153f3 	ldp	x19, x20, [sp, #16]
    4714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4718:	d65f03c0 	ret
    471c:	d503201f 	nop

0000000000004720 <e47>:
    4720:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4724:	910003fd 	mov	x29, sp
    4728:	a90153f3 	stp	x19, x20, [sp, #16]
    472c:	f9400013 	ldr	x19, [x0]
    4730:	aa1303e0 	mov	x0, x19
    4734:	97fffbbf 	bl	3630 <fwp_rc_share>
    4738:	f9400674 	ldr	x20, [x19, #8]
    473c:	aa1303e0 	mov	x0, x19
    4740:	97ffff7c 	bl	4530 <fwp_drop4>
    4744:	aa1403e0 	mov	x0, x20
    4748:	97fffbba 	bl	3630 <fwp_rc_share>
    474c:	aa1403e0 	mov	x0, x20
    4750:	a94153f3 	ldp	x19, x20, [sp, #16]
    4754:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4758:	d65f03c0 	ret
    475c:	d503201f 	nop

0000000000004760 <fwp_arg_drop50>:
    4760:	7100003f 	cmp	w1, #0x0
    4764:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4768:	54000041 	b.ne	4770 <fwp_arg_drop50+0x10>  // b.any
    476c:	d65f03c0 	ret
    4770:	f9400000 	ldr	x0, [x0]
    4774:	17ffff6f 	b	4530 <fwp_drop4>
    4778:	d503201f 	nop
    477c:	d503201f 	nop

0000000000004780 <fwp_drop0>:
    4780:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4784:	910003fd 	mov	x29, sp
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	f90013f5 	str	x21, [sp, #32]
    4790:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4794:	9114c2b4 	add	x20, x21, #0x530
    4798:	f949da81 	ldr	x1, [x20, #5040]
    479c:	f949ee82 	ldr	x2, [x20, #5080]
    47a0:	cb010001 	sub	x1, x0, x1
    47a4:	eb02403f 	cmp	x1, x2, lsl #16
    47a8:	54000382 	b.cs	4818 <fwp_drop0+0x98>  // b.hs, b.nlast
    47ac:	d350fc22 	lsr	x2, x1, #16
    47b0:	f949fe83 	ldr	x3, [x20, #5112]
    47b4:	8b020842 	add	x2, x2, x2, lsl #2
    47b8:	d37df042 	lsl	x2, x2, #3
    47bc:	8b020064 	add	x4, x3, x2
    47c0:	f9401093 	ldr	x19, [x4, #32]
    47c4:	b40002b3 	cbz	x19, 4818 <fwp_drop0+0x98>
    47c8:	38626862 	ldrb	w2, [x3, x2]
    47cc:	7100085f 	cmp	w2, #0x2
    47d0:	540002c0 	b.eq	4828 <fwp_drop0+0xa8>  // b.none
    47d4:	7100045f 	cmp	w2, #0x1
    47d8:	54000201 	b.ne	4818 <fwp_drop0+0x98>  // b.any
    47dc:	29430885 	ldp	w5, w2, [x4, #24]
    47e0:	92403c21 	and	x1, x1, #0xffff
    47e4:	9b057c21 	mul	x1, x1, x5
    47e8:	d360fc21 	lsr	x1, x1, #32
    47ec:	eb02003f 	cmp	x1, x2
    47f0:	54000142 	b.cs	4818 <fwp_drop0+0x98>  // b.hs, b.nlast
    47f4:	8b010273 	add	x19, x19, x1
    47f8:	39400261 	ldrb	w1, [x19]
    47fc:	340000e1 	cbz	w1, 4818 <fwp_drop0+0x98>
    4800:	7100043f 	cmp	w1, #0x1
    4804:	540001e0 	b.eq	4840 <fwp_drop0+0xc0>  // b.none
    4808:	7103fc3f 	cmp	w1, #0xff
    480c:	540006e0 	b.eq	48e8 <fwp_drop0+0x168>  // b.none
    4810:	51000421 	sub	w1, w1, #0x1
    4814:	39000261 	strb	w1, [x19]
    4818:	a94153f3 	ldp	x19, x20, [sp, #16]
    481c:	f94013f5 	ldr	x21, [sp, #32]
    4820:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4824:	d65f03c0 	ret
    4828:	72003c3f 	tst	w1, #0xffff
    482c:	54fffe60 	b.eq	47f8 <fwp_drop0+0x78>  // b.none
    4830:	a94153f3 	ldp	x19, x20, [sp, #16]
    4834:	f94013f5 	ldr	x21, [sp, #32]
    4838:	a8c37bfd 	ldp	x29, x30, [sp], #48
    483c:	d65f03c0 	ret
    4840:	9114c2a1 	add	x1, x21, #0x530
    4844:	f9400813 	ldr	x19, [x0, #16]
    4848:	f949ec25 	ldr	x5, [x1, #5080]
    484c:	f949d821 	ldr	x1, [x1, #5040]
    4850:	d370bca5 	lsl	x5, x5, #16
    4854:	cb010002 	sub	x2, x0, x1
    4858:	eb05005f 	cmp	x2, x5
    485c:	54000362 	b.cs	48c8 <fwp_drop0+0x148>  // b.hs, b.nlast
    4860:	d350fc44 	lsr	x4, x2, #16
    4864:	8b040884 	add	x4, x4, x4, lsl #2
    4868:	d37df084 	lsl	x4, x4, #3
    486c:	8b040067 	add	x7, x3, x4
    4870:	f94010e6 	ldr	x6, [x7, #32]
    4874:	b40002a6 	cbz	x6, 48c8 <fwp_drop0+0x148>
    4878:	38646863 	ldrb	w3, [x3, x4]
    487c:	7100087f 	cmp	w3, #0x2
    4880:	540002e0 	b.eq	48dc <fwp_drop0+0x15c>  // b.none
    4884:	7100047f 	cmp	w3, #0x1
    4888:	54000201 	b.ne	48c8 <fwp_drop0+0x148>  // b.any
    488c:	29430ce4 	ldp	w4, w3, [x7, #24]
    4890:	92403c42 	and	x2, x2, #0xffff
    4894:	9b047c42 	mul	x2, x2, x4
    4898:	d360fc42 	lsr	x2, x2, #32
    489c:	eb03005f 	cmp	x2, x3
    48a0:	54000142 	b.cs	48c8 <fwp_drop0+0x148>  // b.hs, b.nlast
    48a4:	8b0200c6 	add	x6, x6, x2
    48a8:	394000c2 	ldrb	w2, [x6]
    48ac:	7100045f 	cmp	w2, #0x1
    48b0:	540000c1 	b.ne	48c8 <fwp_drop0+0x148>  // b.any
    48b4:	97fffa3f 	bl	31b0 <fwp_mem_free>
    48b8:	9114c2a0 	add	x0, x21, #0x530
    48bc:	f949ec05 	ldr	x5, [x0, #5080]
    48c0:	f949d801 	ldr	x1, [x0, #5040]
    48c4:	d370bca5 	lsl	x5, x5, #16
    48c8:	cb010261 	sub	x1, x19, x1
    48cc:	eb05003f 	cmp	x1, x5
    48d0:	54fffa42 	b.cs	4818 <fwp_drop0+0x98>  // b.hs, b.nlast
    48d4:	aa1303e0 	mov	x0, x19
    48d8:	17ffffb5 	b	47ac <fwp_drop0+0x2c>
    48dc:	72003c5f 	tst	w2, #0xffff
    48e0:	54ffff41 	b.ne	48c8 <fwp_drop0+0x148>  // b.any
    48e4:	17fffff1 	b	48a8 <fwp_drop0+0x128>
    48e8:	ca534661 	eor	x1, x19, x19, lsr #17
    48ec:	9114c2a0 	add	x0, x21, #0x530
    48f0:	ca412421 	eor	x1, x1, x1, lsr #9
    48f4:	8b210c01 	add	x1, x0, w1, uxtb #3
    48f8:	f94a2420 	ldr	x0, [x1, #5192]
    48fc:	b5000080 	cbnz	x0, 490c <fwp_drop0+0x18c>
    4900:	14000010 	b	4940 <fwp_drop0+0x1c0>
    4904:	f9400800 	ldr	x0, [x0, #16]
    4908:	b40001c0 	cbz	x0, 4940 <fwp_drop0+0x1c0>
    490c:	f9400001 	ldr	x1, [x0]
    4910:	eb13003f 	cmp	x1, x19
    4914:	54ffff81 	b.ne	4904 <fwp_drop0+0x184>  // b.any
    4918:	f9400401 	ldr	x1, [x0, #8]
    491c:	d1000421 	sub	x1, x1, #0x1
    4920:	f9000401 	str	x1, [x0, #8]
    4924:	f103f83f 	cmp	x1, #0xfe
    4928:	54fff781 	b.ne	4818 <fwp_drop0+0x98>  // b.any
    492c:	aa1303e0 	mov	x0, x19
    4930:	97fff980 	bl	2f30 <fwp_rc_forget_slot>
    4934:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4938:	39000260 	strb	w0, [x19]
    493c:	17ffffb7 	b	4818 <fwp_drop0+0x98>
    4940:	90000020 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    4944:	9100c000 	add	x0, x0, #0x30
    4948:	97fff66e 	bl	2300 <fwp_trap>
    494c:	d503201f 	nop

0000000000004950 <fwp_drop1>:
    4950:	17ffff8c 	b	4780 <fwp_drop0>

0000000000004954 <fwp_loop_fields68.constprop.0>:
    4954:	d10483ff 	sub	sp, sp, #0x120
    4958:	aa0003e2 	mov	x2, x0
    495c:	f00000c1 	adrp	x1, 1f000 <__FRAME_END__+0x15a68>
    4960:	f947f421 	ldr	x1, [x1, #4072]
    4964:	a90a7bfd 	stp	x29, x30, [sp, #160]
    4968:	910283fd 	add	x29, sp, #0xa0
    496c:	f9000be0 	str	x0, [sp, #16]
    4970:	a90b53f3 	stp	x19, x20, [sp, #176]
    4974:	a90c5bf5 	stp	x21, x22, [sp, #192]
    4978:	a90d63f7 	stp	x23, x24, [sp, #208]
    497c:	a90e6bf9 	stp	x25, x26, [sp, #224]
    4980:	a90f73fb 	stp	x27, x28, [sp, #240]
    4984:	6d1027e8 	stp	d8, d9, [sp, #256]
    4988:	fd008bea 	str	d10, [sp, #272]
    498c:	f9400020 	ldr	x0, [x1]
    4990:	f9004fe0 	str	x0, [sp, #152]
    4994:	d2800000 	mov	x0, #0x0                   	// #0
    4998:	b40057e2 	cbz	x2, 5494 <fwp_loop_fields68.constprop.0+0xb40>
    499c:	f9400840 	ldr	x0, [x2, #16]
    49a0:	f90007e0 	str	x0, [sp, #8]
    49a4:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    49a8:	9114c2a2 	add	x2, x21, #0x530
    49ac:	f94007e3 	ldr	x3, [sp, #8]
    49b0:	f949d841 	ldr	x1, [x2, #5040]
    49b4:	f949ec40 	ldr	x0, [x2, #5080]
    49b8:	cb010061 	sub	x1, x3, x1
    49bc:	eb00403f 	cmp	x1, x0, lsl #16
    49c0:	54000422 	b.cs	4a44 <fwp_loop_fields68.constprop.0+0xf0>  // b.hs, b.nlast
    49c4:	d350fc20 	lsr	x0, x1, #16
    49c8:	f949fc44 	ldr	x4, [x2, #5112]
    49cc:	8b000800 	add	x0, x0, x0, lsl #2
    49d0:	d37df002 	lsl	x2, x0, #3
    49d4:	8b020083 	add	x3, x4, x2
    49d8:	f9401060 	ldr	x0, [x3, #32]
    49dc:	b4000340 	cbz	x0, 4a44 <fwp_loop_fields68.constprop.0+0xf0>
    49e0:	38626882 	ldrb	w2, [x4, x2]
    49e4:	7100085f 	cmp	w2, #0x2
    49e8:	54004a20 	b.eq	532c <fwp_loop_fields68.constprop.0+0x9d8>  // b.none
    49ec:	7100045f 	cmp	w2, #0x1
    49f0:	540002a1 	b.ne	4a44 <fwp_loop_fields68.constprop.0+0xf0>  // b.any
    49f4:	29430864 	ldp	w4, w2, [x3, #24]
    49f8:	92403c21 	and	x1, x1, #0xffff
    49fc:	9b047c21 	mul	x1, x1, x4
    4a00:	d360fc21 	lsr	x1, x1, #32
    4a04:	eb02003f 	cmp	x1, x2
    4a08:	540001e2 	b.cs	4a44 <fwp_loop_fields68.constprop.0+0xf0>  // b.hs, b.nlast
    4a0c:	8b010000 	add	x0, x0, x1
    4a10:	39400001 	ldrb	w1, [x0]
    4a14:	34000181 	cbz	w1, 4a44 <fwp_loop_fields68.constprop.0+0xf0>
    4a18:	900000e2 	adrp	x2, 20000 <__data_start>
    4a1c:	91014042 	add	x2, x2, #0x50
    4a20:	b9404043 	ldr	w3, [x2, #64]
    4a24:	34000083 	cbz	w3, 4a34 <fwp_loop_fields68.constprop.0+0xe0>
    4a28:	f9402443 	ldr	x3, [x2, #72]
    4a2c:	91000463 	add	x3, x3, #0x1
    4a30:	f9002443 	str	x3, [x2, #72]
    4a34:	7103f43f 	cmp	w1, #0xfd
    4a38:	540052a8 	b.hi	548c <fwp_loop_fields68.constprop.0+0xb38>  // b.pmore
    4a3c:	11000421 	add	w1, w1, #0x1
    4a40:	39000001 	strb	w1, [x0]
    4a44:	9100c3e0 	add	x0, sp, #0x30
    4a48:	910223f4 	add	x20, sp, #0x88
    4a4c:	aa0003e1 	mov	x1, x0
    4a50:	f9000fe1 	str	x1, [sp, #24]
    4a54:	f94007e0 	ldr	x0, [sp, #8]
    4a58:	d2800018 	mov	x24, #0x0                   	// #0
    4a5c:	97fffe91 	bl	44a0 <fwp_map_items>
    4a60:	aa0003f6 	mov	x22, x0
    4a64:	f9400be0 	ldr	x0, [sp, #16]
    4a68:	90000003 	adrp	x3, 4000 <fwp_data.part.0.constprop.0+0x1a0>
    4a6c:	b0000002 	adrp	x2, 5000 <fwp_loop_fields68.constprop.0+0x6ac>
    4a70:	9114c063 	add	x3, x3, #0x530
    4a74:	9112c042 	add	x2, x2, #0x4b0
    4a78:	9100e3e1 	add	x1, sp, #0x38
    4a7c:	f90003e1 	str	x1, [sp]
    4a80:	f90023f6 	str	x22, [sp, #64]
    4a84:	a904ffff 	stp	xzr, xzr, [sp, #72]
    4a88:	a9058be3 	stp	x3, x2, [sp, #88]
    4a8c:	97fffe85 	bl	44a0 <fwp_map_items>
    4a90:	aa0003fa 	mov	x26, x0
    4a94:	a9434fe1 	ldp	x1, x19, [sp, #48]
    4a98:	eb01027f 	cmp	x19, x1
    4a9c:	9a819273 	csel	x19, x19, x1, ls	// ls = plast
    4aa0:	b4004253 	cbz	x19, 52e8 <fwp_loop_fields68.constprop.0+0x994>
    4aa4:	9114c2bc 	add	x28, x21, #0x530
    4aa8:	d2f80f21 	mov	x1, #0xc079000000000000    	// #-4577627546245398528
    4aac:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    4ab0:	9e670029 	fmov	d9, x1
    4ab4:	9e670008 	fmov	d8, x0
    4ab8:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    4abc:	52800037 	mov	w23, #0x1                   	// #1
    4ac0:	fc787b40 	ldr	d0, [x26, x24, lsl #3]
    4ac4:	aa1403e1 	mov	x1, x20
    4ac8:	fc787ac1 	ldr	d1, [x22, x24, lsl #3]
    4acc:	52800000 	mov	w0, #0x0                   	// #0
    4ad0:	1e600803 	fmul	d3, d0, d0
    4ad4:	1e690802 	fmul	d2, d0, d9
    4ad8:	1e603940 	fsub	d0, d10, d0
    4adc:	1e633821 	fsub	d1, d1, d3
    4ae0:	1e602800 	fadd	d0, d0, d0
    4ae4:	1e610842 	fmul	d2, d2, d1
    4ae8:	1e680821 	fmul	d1, d1, d8
    4aec:	1e603840 	fsub	d0, d2, d0
    4af0:	6d0887e0 	stp	d0, d1, [sp, #136]
    4af4:	97fffcdb 	bl	3e60 <fwp_data.part.0.constprop.0>
    4af8:	aa0003f9 	mov	x25, x0
    4afc:	f949db81 	ldr	x1, [x28, #5040]
    4b00:	f949ef80 	ldr	x0, [x28, #5080]
    4b04:	cb010321 	sub	x1, x25, x1
    4b08:	eb00403f 	cmp	x1, x0, lsl #16
    4b0c:	54000302 	b.cs	4b6c <fwp_loop_fields68.constprop.0+0x218>  // b.hs, b.nlast
    4b10:	d350fc22 	lsr	x2, x1, #16
    4b14:	f949ff85 	ldr	x5, [x28, #5112]
    4b18:	8b020842 	add	x2, x2, x2, lsl #2
    4b1c:	d37df042 	lsl	x2, x2, #3
    4b20:	8b0200a3 	add	x3, x5, x2
    4b24:	f940107b 	ldr	x27, [x3, #32]
    4b28:	b400023b 	cbz	x27, 4b6c <fwp_loop_fields68.constprop.0+0x218>
    4b2c:	386268a0 	ldrb	w0, [x5, x2]
    4b30:	7100081f 	cmp	w0, #0x2
    4b34:	54003c80 	b.eq	52c4 <fwp_loop_fields68.constprop.0+0x970>  // b.none
    4b38:	7100041f 	cmp	w0, #0x1
    4b3c:	54000181 	b.ne	4b6c <fwp_loop_fields68.constprop.0+0x218>  // b.any
    4b40:	29430062 	ldp	w2, w0, [x3, #24]
    4b44:	92403c21 	and	x1, x1, #0xffff
    4b48:	9b027c21 	mul	x1, x1, x2
    4b4c:	d360fc21 	lsr	x1, x1, #32
    4b50:	eb00003f 	cmp	x1, x0
    4b54:	540000c2 	b.cs	4b6c <fwp_loop_fields68.constprop.0+0x218>  // b.hs, b.nlast
    4b58:	8b01037b 	add	x27, x27, x1
    4b5c:	39400360 	ldrb	w0, [x27]
    4b60:	7103fc1f 	cmp	w0, #0xff
    4b64:	54003aa0 	b.eq	52b8 <fwp_loop_fields68.constprop.0+0x964>  // b.none
    4b68:	39000377 	strb	w23, [x27]
    4b6c:	f8387ad9 	str	x25, [x22, x24, lsl #3]
    4b70:	91000718 	add	x24, x24, #0x1
    4b74:	f90027f8 	str	x24, [sp, #72]
    4b78:	eb18027f 	cmp	x19, x24
    4b7c:	54fffa21 	b.ne	4ac0 <fwp_loop_fields68.constprop.0+0x16c>  // b.any
    4b80:	aa1a03e0 	mov	x0, x26
    4b84:	97fff98b 	bl	31b0 <fwp_mem_free>
    4b88:	910103f7 	add	x23, sp, #0x40
    4b8c:	aa1703e0 	mov	x0, x23
    4b90:	97fffd8c 	bl	41c0 <fwp_map_finish_protected.isra.0>
    4b94:	aa0003f9 	mov	x25, x0
    4b98:	f94007e0 	ldr	x0, [sp, #8]
    4b9c:	f90007f9 	str	x25, [sp, #8]
    4ba0:	97fffef8 	bl	4780 <fwp_drop0>
    4ba4:	a9077fff 	stp	xzr, xzr, [sp, #112]
    4ba8:	9101c3e1 	add	x1, sp, #0x70
    4bac:	52800020 	mov	w0, #0x1                   	// #1
    4bb0:	97fffcac 	bl	3e60 <fwp_data.part.0.constprop.0>
    4bb4:	9114c2a2 	add	x2, x21, #0x530
    4bb8:	aa0003fb 	mov	x27, x0
    4bbc:	f949d841 	ldr	x1, [x2, #5040]
    4bc0:	f949ec40 	ldr	x0, [x2, #5080]
    4bc4:	cb010361 	sub	x1, x27, x1
    4bc8:	eb00403f 	cmp	x1, x0, lsl #16
    4bcc:	54000322 	b.cs	4c30 <fwp_loop_fields68.constprop.0+0x2dc>  // b.hs, b.nlast
    4bd0:	d350fc20 	lsr	x0, x1, #16
    4bd4:	f949fc43 	ldr	x3, [x2, #5112]
    4bd8:	8b000800 	add	x0, x0, x0, lsl #2
    4bdc:	d37df002 	lsl	x2, x0, #3
    4be0:	8b020060 	add	x0, x3, x2
    4be4:	f9401013 	ldr	x19, [x0, #32]
    4be8:	b4000253 	cbz	x19, 4c30 <fwp_loop_fields68.constprop.0+0x2dc>
    4bec:	38626862 	ldrb	w2, [x3, x2]
    4bf0:	7100085f 	cmp	w2, #0x2
    4bf4:	540038c0 	b.eq	530c <fwp_loop_fields68.constprop.0+0x9b8>  // b.none
    4bf8:	7100045f 	cmp	w2, #0x1
    4bfc:	540001a1 	b.ne	4c30 <fwp_loop_fields68.constprop.0+0x2dc>  // b.any
    4c00:	29430002 	ldp	w2, w0, [x0, #24]
    4c04:	92403c21 	and	x1, x1, #0xffff
    4c08:	9b027c21 	mul	x1, x1, x2
    4c0c:	d360fc21 	lsr	x1, x1, #32
    4c10:	eb00003f 	cmp	x1, x0
    4c14:	540000e2 	b.cs	4c30 <fwp_loop_fields68.constprop.0+0x2dc>  // b.hs, b.nlast
    4c18:	8b010273 	add	x19, x19, x1
    4c1c:	39400260 	ldrb	w0, [x19]
    4c20:	7103fc1f 	cmp	w0, #0xff
    4c24:	540037e0 	b.eq	5320 <fwp_loop_fields68.constprop.0+0x9cc>  // b.none
    4c28:	52800020 	mov	w0, #0x1                   	// #1
    4c2c:	39000260 	strb	w0, [x19]
    4c30:	a94003e1 	ldp	x1, x0, [sp]
    4c34:	900000f4 	adrp	x20, 20000 <__data_start>
    4c38:	9114c2b9 	add	x25, x21, #0x530
    4c3c:	91014294 	add	x20, x20, #0x50
    4c40:	d2800016 	mov	x22, #0x0                   	// #0
    4c44:	97fffe17 	bl	44a0 <fwp_map_items>
    4c48:	aa0003fa 	mov	x26, x0
    4c4c:	f9401ff3 	ldr	x19, [sp, #56]
    4c50:	90000000 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x1a0>
    4c54:	911e0000 	add	x0, x0, #0x780
    4c58:	f90023fa 	str	x26, [sp, #64]
    4c5c:	a904ffff 	stp	xzr, xzr, [sp, #72]
    4c60:	a90583ff 	stp	xzr, x0, [sp, #88]
    4c64:	b50003d3 	cbnz	x19, 4cdc <fwp_loop_fields68.constprop.0+0x388>
    4c68:	14000038 	b	4d48 <fwp_loop_fields68.constprop.0+0x3f4>
    4c6c:	7100045f 	cmp	w2, #0x1
    4c70:	54000261 	b.ne	4cbc <fwp_loop_fields68.constprop.0+0x368>  // b.any
    4c74:	294308a6 	ldp	w6, w2, [x5, #24]
    4c78:	92403c21 	and	x1, x1, #0xffff
    4c7c:	9b067c21 	mul	x1, x1, x6
    4c80:	d360fc21 	lsr	x1, x1, #32
    4c84:	eb02003f 	cmp	x1, x2
    4c88:	540001a2 	b.cs	4cbc <fwp_loop_fields68.constprop.0+0x368>  // b.hs, b.nlast
    4c8c:	8b010000 	add	x0, x0, x1
    4c90:	39400001 	ldrb	w1, [x0]
    4c94:	34000141 	cbz	w1, 4cbc <fwp_loop_fields68.constprop.0+0x368>
    4c98:	b9404282 	ldr	w2, [x20, #64]
    4c9c:	34000082 	cbz	w2, 4cac <fwp_loop_fields68.constprop.0+0x358>
    4ca0:	f9402682 	ldr	x2, [x20, #72]
    4ca4:	91000442 	add	x2, x2, #0x1
    4ca8:	f9002682 	str	x2, [x20, #72]
    4cac:	7103f43f 	cmp	w1, #0xfd
    4cb0:	540032a8 	b.hi	5304 <fwp_loop_fields68.constprop.0+0x9b0>  // b.pmore
    4cb4:	11000421 	add	w1, w1, #0x1
    4cb8:	39000001 	strb	w1, [x0]
    4cbc:	f9400798 	ldr	x24, [x28, #8]
    4cc0:	aa1c03e0 	mov	x0, x28
    4cc4:	97fffe1b 	bl	4530 <fwp_drop4>
    4cc8:	f8367b58 	str	x24, [x26, x22, lsl #3]
    4ccc:	910006d6 	add	x22, x22, #0x1
    4cd0:	f90027f6 	str	x22, [sp, #72]
    4cd4:	eb1302df 	cmp	x22, x19
    4cd8:	54000380 	b.eq	4d48 <fwp_loop_fields68.constprop.0+0x3f4>  // b.none
    4cdc:	f8767b5c 	ldr	x28, [x26, x22, lsl #3]
    4ce0:	f949db21 	ldr	x1, [x25, #5040]
    4ce4:	f949ef20 	ldr	x0, [x25, #5080]
    4ce8:	cb010381 	sub	x1, x28, x1
    4cec:	eb00403f 	cmp	x1, x0, lsl #16
    4cf0:	54fffe62 	b.cs	4cbc <fwp_loop_fields68.constprop.0+0x368>  // b.hs, b.nlast
    4cf4:	d350fc22 	lsr	x2, x1, #16
    4cf8:	f949ff26 	ldr	x6, [x25, #5112]
    4cfc:	8b020842 	add	x2, x2, x2, lsl #2
    4d00:	d37df042 	lsl	x2, x2, #3
    4d04:	8b0200c5 	add	x5, x6, x2
    4d08:	f94010a0 	ldr	x0, [x5, #32]
    4d0c:	b4fffd80 	cbz	x0, 4cbc <fwp_loop_fields68.constprop.0+0x368>
    4d10:	386268c2 	ldrb	w2, [x6, x2]
    4d14:	7100085f 	cmp	w2, #0x2
    4d18:	54fffaa1 	b.ne	4c6c <fwp_loop_fields68.constprop.0+0x318>  // b.any
    4d1c:	72003c3f 	tst	w1, #0xffff
    4d20:	54fffb80 	b.eq	4c90 <fwp_loop_fields68.constprop.0+0x33c>  // b.none
    4d24:	f9400798 	ldr	x24, [x28, #8]
    4d28:	aa1c03e0 	mov	x0, x28
    4d2c:	97fffe01 	bl	4530 <fwp_drop4>
    4d30:	f8367b58 	str	x24, [x26, x22, lsl #3]
    4d34:	910006d6 	add	x22, x22, #0x1
    4d38:	f90027f6 	str	x22, [sp, #72]
    4d3c:	eb1302df 	cmp	x22, x19
    4d40:	54fffce1 	b.ne	4cdc <fwp_loop_fields68.constprop.0+0x388>  // b.any
    4d44:	d503201f 	nop
    4d48:	aa1703e0 	mov	x0, x23
    4d4c:	97fffd1d 	bl	41c0 <fwp_map_finish_protected.isra.0>
    4d50:	aa1703e1 	mov	x1, x23
    4d54:	f90017e0 	str	x0, [sp, #40]
    4d58:	97fffdd2 	bl	44a0 <fwp_map_items>
    4d5c:	f90013e0 	str	x0, [sp, #32]
    4d60:	9114c2a2 	add	x2, x21, #0x530
    4d64:	f949d841 	ldr	x1, [x2, #5040]
    4d68:	f949ec40 	ldr	x0, [x2, #5080]
    4d6c:	cb010361 	sub	x1, x27, x1
    4d70:	eb00403f 	cmp	x1, x0, lsl #16
    4d74:	54000422 	b.cs	4df8 <fwp_loop_fields68.constprop.0+0x4a4>  // b.hs, b.nlast
    4d78:	d350fc20 	lsr	x0, x1, #16
    4d7c:	f949fc44 	ldr	x4, [x2, #5112]
    4d80:	8b000800 	add	x0, x0, x0, lsl #2
    4d84:	d37df002 	lsl	x2, x0, #3
    4d88:	8b020083 	add	x3, x4, x2
    4d8c:	f9401060 	ldr	x0, [x3, #32]
    4d90:	b4000340 	cbz	x0, 4df8 <fwp_loop_fields68.constprop.0+0x4a4>
    4d94:	38626882 	ldrb	w2, [x4, x2]
    4d98:	7100085f 	cmp	w2, #0x2
    4d9c:	54002ce0 	b.eq	5338 <fwp_loop_fields68.constprop.0+0x9e4>  // b.none
    4da0:	7100045f 	cmp	w2, #0x1
    4da4:	540002a1 	b.ne	4df8 <fwp_loop_fields68.constprop.0+0x4a4>  // b.any
    4da8:	29430864 	ldp	w4, w2, [x3, #24]
    4dac:	92403c21 	and	x1, x1, #0xffff
    4db0:	9b047c21 	mul	x1, x1, x4
    4db4:	d360fc21 	lsr	x1, x1, #32
    4db8:	eb02003f 	cmp	x1, x2
    4dbc:	540001e2 	b.cs	4df8 <fwp_loop_fields68.constprop.0+0x4a4>  // b.hs, b.nlast
    4dc0:	8b010000 	add	x0, x0, x1
    4dc4:	39400001 	ldrb	w1, [x0]
    4dc8:	34000181 	cbz	w1, 4df8 <fwp_loop_fields68.constprop.0+0x4a4>
    4dcc:	900000e2 	adrp	x2, 20000 <__data_start>
    4dd0:	91014042 	add	x2, x2, #0x50
    4dd4:	b9404043 	ldr	w3, [x2, #64]
    4dd8:	34000083 	cbz	w3, 4de8 <fwp_loop_fields68.constprop.0+0x494>
    4ddc:	f9402443 	ldr	x3, [x2, #72]
    4de0:	91000463 	add	x3, x3, #0x1
    4de4:	f9002443 	str	x3, [x2, #72]
    4de8:	7103f43f 	cmp	w1, #0xfd
    4dec:	540034c8 	b.hi	5484 <fwp_loop_fields68.constprop.0+0xb30>  // b.pmore
    4df0:	11000421 	add	w1, w1, #0x1
    4df4:	39000001 	strb	w1, [x0]
    4df8:	f94023fa 	ldr	x26, [sp, #64]
    4dfc:	aa1b03f3 	mov	x19, x27
    4e00:	b400055a 	cbz	x26, 4ea8 <fwp_loop_fields68.constprop.0+0x554>
    4e04:	f94013e0 	ldr	x0, [sp, #32]
    4e08:	910223f4 	add	x20, sp, #0x88
    4e0c:	9114c2b9 	add	x25, x21, #0x530
    4e10:	5280003c 	mov	w28, #0x1                   	// #1
    4e14:	d1002016 	sub	x22, x0, #0x8
    4e18:	f87a7ac2 	ldr	x2, [x22, x26, lsl #3]
    4e1c:	aa1403e1 	mov	x1, x20
    4e20:	52800020 	mov	w0, #0x1                   	// #1
    4e24:	a908cfe2 	stp	x2, x19, [sp, #136]
    4e28:	97fffc0e 	bl	3e60 <fwp_data.part.0.constprop.0>
    4e2c:	aa0003f3 	mov	x19, x0
    4e30:	f949db21 	ldr	x1, [x25, #5040]
    4e34:	f949ef20 	ldr	x0, [x25, #5080]
    4e38:	cb010261 	sub	x1, x19, x1
    4e3c:	eb00403f 	cmp	x1, x0, lsl #16
    4e40:	54000302 	b.cs	4ea0 <fwp_loop_fields68.constprop.0+0x54c>  // b.hs, b.nlast
    4e44:	d350fc20 	lsr	x0, x1, #16
    4e48:	f949ff26 	ldr	x6, [x25, #5112]
    4e4c:	8b000800 	add	x0, x0, x0, lsl #2
    4e50:	d37df002 	lsl	x2, x0, #3
    4e54:	8b0200c5 	add	x5, x6, x2
    4e58:	f94010b8 	ldr	x24, [x5, #32]
    4e5c:	b4000238 	cbz	x24, 4ea0 <fwp_loop_fields68.constprop.0+0x54c>
    4e60:	386268c2 	ldrb	w2, [x6, x2]
    4e64:	7100085f 	cmp	w2, #0x2
    4e68:	540023a0 	b.eq	52dc <fwp_loop_fields68.constprop.0+0x988>  // b.none
    4e6c:	7100045f 	cmp	w2, #0x1
    4e70:	54000181 	b.ne	4ea0 <fwp_loop_fields68.constprop.0+0x54c>  // b.any
    4e74:	294308a6 	ldp	w6, w2, [x5, #24]
    4e78:	92403c21 	and	x1, x1, #0xffff
    4e7c:	9b067c21 	mul	x1, x1, x6
    4e80:	d360fc21 	lsr	x1, x1, #32
    4e84:	eb02003f 	cmp	x1, x2
    4e88:	540000c2 	b.cs	4ea0 <fwp_loop_fields68.constprop.0+0x54c>  // b.hs, b.nlast
    4e8c:	8b010318 	add	x24, x24, x1
    4e90:	39400301 	ldrb	w1, [x24]
    4e94:	7103fc3f 	cmp	w1, #0xff
    4e98:	540021c0 	b.eq	52d0 <fwp_loop_fields68.constprop.0+0x97c>  // b.none
    4e9c:	3900031c 	strb	w28, [x24]
    4ea0:	f100075a 	subs	x26, x26, #0x1
    4ea4:	54fffba1 	b.ne	4e18 <fwp_loop_fields68.constprop.0+0x4c4>  // b.any
    4ea8:	f94013e0 	ldr	x0, [sp, #32]
    4eac:	b4000040 	cbz	x0, 4eb4 <fwp_loop_fields68.constprop.0+0x560>
    4eb0:	97fff8c0 	bl	31b0 <fwp_mem_free>
    4eb4:	aa1b03e0 	mov	x0, x27
    4eb8:	97fffe32 	bl	4780 <fwp_drop0>
    4ebc:	f94017e0 	ldr	x0, [sp, #40]
    4ec0:	900000f6 	adrp	x22, 20000 <__data_start>
    4ec4:	9114c2b9 	add	x25, x21, #0x530
    4ec8:	910142d6 	add	x22, x22, #0x50
    4ecc:	d280001b 	mov	x27, #0x0                   	// #0
    4ed0:	97fffe2c 	bl	4780 <fwp_drop0>
    4ed4:	a94003e1 	ldp	x1, x0, [sp]
    4ed8:	97fffd72 	bl	44a0 <fwp_map_items>
    4edc:	aa0003fa 	mov	x26, x0
    4ee0:	f9401ff4 	ldr	x20, [sp, #56]
    4ee4:	90000000 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x1a0>
    4ee8:	911e0000 	add	x0, x0, #0x780
    4eec:	f90023fa 	str	x26, [sp, #64]
    4ef0:	a904ffff 	stp	xzr, xzr, [sp, #72]
    4ef4:	a90583ff 	stp	xzr, x0, [sp, #88]
    4ef8:	b50003d4 	cbnz	x20, 4f70 <fwp_loop_fields68.constprop.0+0x61c>
    4efc:	14000037 	b	4fd8 <fwp_loop_fields68.constprop.0+0x684>
    4f00:	7100045f 	cmp	w2, #0x1
    4f04:	54000261 	b.ne	4f50 <fwp_loop_fields68.constprop.0+0x5fc>  // b.any
    4f08:	294308a6 	ldp	w6, w2, [x5, #24]
    4f0c:	92403c21 	and	x1, x1, #0xffff
    4f10:	9b067c21 	mul	x1, x1, x6
    4f14:	d360fc21 	lsr	x1, x1, #32
    4f18:	eb02003f 	cmp	x1, x2
    4f1c:	540001a2 	b.cs	4f50 <fwp_loop_fields68.constprop.0+0x5fc>  // b.hs, b.nlast
    4f20:	8b010000 	add	x0, x0, x1
    4f24:	39400001 	ldrb	w1, [x0]
    4f28:	34000141 	cbz	w1, 4f50 <fwp_loop_fields68.constprop.0+0x5fc>
    4f2c:	b94042c2 	ldr	w2, [x22, #64]
    4f30:	34000082 	cbz	w2, 4f40 <fwp_loop_fields68.constprop.0+0x5ec>
    4f34:	f94026c2 	ldr	x2, [x22, #72]
    4f38:	91000442 	add	x2, x2, #0x1
    4f3c:	f90026c2 	str	x2, [x22, #72]
    4f40:	7103f43f 	cmp	w1, #0xfd
    4f44:	54001dc8 	b.hi	52fc <fwp_loop_fields68.constprop.0+0x9a8>  // b.pmore
    4f48:	11000421 	add	w1, w1, #0x1
    4f4c:	39000001 	strb	w1, [x0]
    4f50:	f9400b98 	ldr	x24, [x28, #16]
    4f54:	aa1c03e0 	mov	x0, x28
    4f58:	97fffd76 	bl	4530 <fwp_drop4>
    4f5c:	f83b7b58 	str	x24, [x26, x27, lsl #3]
    4f60:	9100077b 	add	x27, x27, #0x1
    4f64:	f90027fb 	str	x27, [sp, #72]
    4f68:	eb14037f 	cmp	x27, x20
    4f6c:	54000360 	b.eq	4fd8 <fwp_loop_fields68.constprop.0+0x684>  // b.none
    4f70:	f87b7b5c 	ldr	x28, [x26, x27, lsl #3]
    4f74:	f949db21 	ldr	x1, [x25, #5040]
    4f78:	f949ef20 	ldr	x0, [x25, #5080]
    4f7c:	cb010381 	sub	x1, x28, x1
    4f80:	eb00403f 	cmp	x1, x0, lsl #16
    4f84:	54fffe62 	b.cs	4f50 <fwp_loop_fields68.constprop.0+0x5fc>  // b.hs, b.nlast
    4f88:	d350fc22 	lsr	x2, x1, #16
    4f8c:	f949ff26 	ldr	x6, [x25, #5112]
    4f90:	8b020842 	add	x2, x2, x2, lsl #2
    4f94:	d37df042 	lsl	x2, x2, #3
    4f98:	8b0200c5 	add	x5, x6, x2
    4f9c:	f94010a0 	ldr	x0, [x5, #32]
    4fa0:	b4fffd80 	cbz	x0, 4f50 <fwp_loop_fields68.constprop.0+0x5fc>
    4fa4:	386268c2 	ldrb	w2, [x6, x2]
    4fa8:	7100085f 	cmp	w2, #0x2
    4fac:	54fffaa1 	b.ne	4f00 <fwp_loop_fields68.constprop.0+0x5ac>  // b.any
    4fb0:	72003c3f 	tst	w1, #0xffff
    4fb4:	54fffb80 	b.eq	4f24 <fwp_loop_fields68.constprop.0+0x5d0>  // b.none
    4fb8:	f9400b98 	ldr	x24, [x28, #16]
    4fbc:	aa1c03e0 	mov	x0, x28
    4fc0:	97fffd5c 	bl	4530 <fwp_drop4>
    4fc4:	f83b7b58 	str	x24, [x26, x27, lsl #3]
    4fc8:	9100077b 	add	x27, x27, #0x1
    4fcc:	f90027fb 	str	x27, [sp, #72]
    4fd0:	eb14037f 	cmp	x27, x20
    4fd4:	54fffce1 	b.ne	4f70 <fwp_loop_fields68.constprop.0+0x61c>  // b.any
    4fd8:	9114c2b6 	add	x22, x21, #0x530
    4fdc:	aa1703e0 	mov	x0, x23
    4fe0:	97fffc78 	bl	41c0 <fwp_map_finish_protected.isra.0>
    4fe4:	aa0003fb 	mov	x27, x0
    4fe8:	f94007e2 	ldr	x2, [sp, #8]
    4fec:	f949dac1 	ldr	x1, [x22, #5040]
    4ff0:	f949eec0 	ldr	x0, [x22, #5080]
    4ff4:	cb010041 	sub	x1, x2, x1
    4ff8:	eb00403f 	cmp	x1, x0, lsl #16
    4ffc:	540003a2 	b.cs	5070 <fwp_loop_fields68.constprop.0+0x71c>  // b.hs, b.nlast
    5000:	d350fc22 	lsr	x2, x1, #16
    5004:	f949fec3 	ldr	x3, [x22, #5112]
    5008:	8b020842 	add	x2, x2, x2, lsl #2
    500c:	d37df042 	lsl	x2, x2, #3
    5010:	8b020060 	add	x0, x3, x2
    5014:	f9401014 	ldr	x20, [x0, #32]
    5018:	b40002d4 	cbz	x20, 5070 <fwp_loop_fields68.constprop.0+0x71c>
    501c:	38626862 	ldrb	w2, [x3, x2]
    5020:	7100085f 	cmp	w2, #0x2
    5024:	54001660 	b.eq	52f0 <fwp_loop_fields68.constprop.0+0x99c>  // b.none
    5028:	7100045f 	cmp	w2, #0x1
    502c:	54000221 	b.ne	5070 <fwp_loop_fields68.constprop.0+0x71c>  // b.any
    5030:	29430002 	ldp	w2, w0, [x0, #24]
    5034:	92403c21 	and	x1, x1, #0xffff
    5038:	9b027c21 	mul	x1, x1, x2
    503c:	d360fc21 	lsr	x1, x1, #32
    5040:	eb00003f 	cmp	x1, x0
    5044:	54000162 	b.cs	5070 <fwp_loop_fields68.constprop.0+0x71c>  // b.hs, b.nlast
    5048:	8b010294 	add	x20, x20, x1
    504c:	39400280 	ldrb	w0, [x20]
    5050:	34000100 	cbz	w0, 5070 <fwp_loop_fields68.constprop.0+0x71c>
    5054:	7100041f 	cmp	w0, #0x1
    5058:	540017c0 	b.eq	5350 <fwp_loop_fields68.constprop.0+0x9fc>  // b.none
    505c:	7103fc1f 	cmp	w0, #0xff
    5060:	54001e60 	b.eq	542c <fwp_loop_fields68.constprop.0+0xad8>  // b.none
    5064:	51000400 	sub	w0, w0, #0x1
    5068:	39000280 	strb	w0, [x20]
    506c:	d503201f 	nop
    5070:	9114c2b5 	add	x21, x21, #0x530
    5074:	910223e1 	add	x1, sp, #0x88
    5078:	52800020 	mov	w0, #0x1                   	// #1
    507c:	a908efff 	stp	xzr, x27, [sp, #136]
    5080:	97fffb78 	bl	3e60 <fwp_data.part.0.constprop.0>
    5084:	f949daa1 	ldr	x1, [x21, #5040]
    5088:	aa0003f6 	mov	x22, x0
    508c:	f949eea0 	ldr	x0, [x21, #5080]
    5090:	cb0102c1 	sub	x1, x22, x1
    5094:	eb00403f 	cmp	x1, x0, lsl #16
    5098:	54000322 	b.cs	50fc <fwp_loop_fields68.constprop.0+0x7a8>  // b.hs, b.nlast
    509c:	d350fc20 	lsr	x0, x1, #16
    50a0:	f949fea3 	ldr	x3, [x21, #5112]
    50a4:	8b000800 	add	x0, x0, x0, lsl #2
    50a8:	d37df002 	lsl	x2, x0, #3
    50ac:	8b020060 	add	x0, x3, x2
    50b0:	f9401014 	ldr	x20, [x0, #32]
    50b4:	b4000254 	cbz	x20, 50fc <fwp_loop_fields68.constprop.0+0x7a8>
    50b8:	38626862 	ldrb	w2, [x3, x2]
    50bc:	7100085f 	cmp	w2, #0x2
    50c0:	54001420 	b.eq	5344 <fwp_loop_fields68.constprop.0+0x9f0>  // b.none
    50c4:	7100045f 	cmp	w2, #0x1
    50c8:	540001a1 	b.ne	50fc <fwp_loop_fields68.constprop.0+0x7a8>  // b.any
    50cc:	29430002 	ldp	w2, w0, [x0, #24]
    50d0:	92403c21 	and	x1, x1, #0xffff
    50d4:	9b027c21 	mul	x1, x1, x2
    50d8:	d360fc21 	lsr	x1, x1, #32
    50dc:	eb00003f 	cmp	x1, x0
    50e0:	540000e2 	b.cs	50fc <fwp_loop_fields68.constprop.0+0x7a8>  // b.hs, b.nlast
    50e4:	8b010294 	add	x20, x20, x1
    50e8:	39400280 	ldrb	w0, [x20]
    50ec:	7103fc1f 	cmp	w0, #0xff
    50f0:	54001920 	b.eq	5414 <fwp_loop_fields68.constprop.0+0xac0>  // b.none
    50f4:	52800020 	mov	w0, #0x1                   	// #1
    50f8:	39000280 	strb	w0, [x20]
    50fc:	f9400fe1 	ldr	x1, [sp, #24]
    5100:	aa1603e0 	mov	x0, x22
    5104:	97fffce7 	bl	44a0 <fwp_map_items>
    5108:	aa0003f4 	mov	x20, x0
    510c:	f94003e1 	ldr	x1, [sp]
    5110:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x1a0>
    5114:	911e0002 	add	x2, x0, #0x780
    5118:	aa1303e0 	mov	x0, x19
    511c:	f90023f4 	str	x20, [sp, #64]
    5120:	a904ffff 	stp	xzr, xzr, [sp, #72]
    5124:	a9058bff 	stp	xzr, x2, [sp, #88]
    5128:	97fffcde 	bl	44a0 <fwp_map_items>
    512c:	a9430be1 	ldp	x1, x2, [sp, #48]
    5130:	eb01005f 	cmp	x2, x1
    5134:	9a819042 	csel	x2, x2, x1, ls	// ls = plast
    5138:	b4001662 	cbz	x2, 5404 <fwp_loop_fields68.constprop.0+0xab0>
    513c:	d2800001 	mov	x1, #0x0                   	// #0
    5140:	fc617800 	ldr	d0, [x0, x1, lsl #3]
    5144:	fc617a81 	ldr	d1, [x20, x1, lsl #3]
    5148:	1e612800 	fadd	d0, d0, d1
    514c:	fc217a80 	str	d0, [x20, x1, lsl #3]
    5150:	91000421 	add	x1, x1, #0x1
    5154:	eb01005f 	cmp	x2, x1
    5158:	54ffff41 	b.ne	5140 <fwp_loop_fields68.constprop.0+0x7ec>  // b.any
    515c:	f90027e2 	str	x2, [sp, #72]
    5160:	97fff814 	bl	31b0 <fwp_mem_free>
    5164:	aa1703e0 	mov	x0, x23
    5168:	97fffc16 	bl	41c0 <fwp_map_finish_protected.isra.0>
    516c:	aa0003e1 	mov	x1, x0
    5170:	aa1303e0 	mov	x0, x19
    5174:	aa0103f3 	mov	x19, x1
    5178:	97fffd82 	bl	4780 <fwp_drop0>
    517c:	aa1603e0 	mov	x0, x22
    5180:	97fffd80 	bl	4780 <fwp_drop0>
    5184:	f94003e1 	ldr	x1, [sp]
    5188:	aa1303e0 	mov	x0, x19
    518c:	97fffcc5 	bl	44a0 <fwp_map_items>
    5190:	aa0003e1 	mov	x1, x0
    5194:	f9401fe2 	ldr	x2, [sp, #56]
    5198:	f0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x1a0>
    519c:	911e0000 	add	x0, x0, #0x780
    51a0:	f90023e1 	str	x1, [sp, #64]
    51a4:	a904ffff 	stp	xzr, xzr, [sp, #72]
    51a8:	a90583ff 	stp	xzr, x0, [sp, #88]
    51ac:	b4000162 	cbz	x2, 51d8 <fwp_loop_fields68.constprop.0+0x884>
    51b0:	f0000000 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    51b4:	fd422801 	ldr	d1, [x0, #1104]
    51b8:	8b020c20 	add	x0, x1, x2, lsl #3
    51bc:	d503201f 	nop
    51c0:	fd400020 	ldr	d0, [x1]
    51c4:	1e600820 	fmul	d0, d1, d0
    51c8:	fc008420 	str	d0, [x1], #8
    51cc:	eb00003f 	cmp	x1, x0
    51d0:	54ffff81 	b.ne	51c0 <fwp_loop_fields68.constprop.0+0x86c>  // b.any
    51d4:	f90027e2 	str	x2, [sp, #72]
    51d8:	aa1703e0 	mov	x0, x23
    51dc:	97fffbf9 	bl	41c0 <fwp_map_finish_protected.isra.0>
    51e0:	aa0003f4 	mov	x20, x0
    51e4:	aa1303e0 	mov	x0, x19
    51e8:	97fffd66 	bl	4780 <fwp_drop0>
    51ec:	a94107e0 	ldp	x0, x1, [sp, #16]
    51f0:	97fffcac 	bl	44a0 <fwp_map_items>
    51f4:	aa0003f3 	mov	x19, x0
    51f8:	f0ffffe1 	adrp	x1, 4000 <fwp_data.part.0.constprop.0+0x1a0>
    51fc:	911e0038 	add	x24, x1, #0x780
    5200:	f94003e1 	ldr	x1, [sp]
    5204:	aa1403e0 	mov	x0, x20
    5208:	f90023f3 	str	x19, [sp, #64]
    520c:	a904ffff 	stp	xzr, xzr, [sp, #72]
    5210:	a905e3ff 	stp	xzr, x24, [sp, #88]
    5214:	97fffca3 	bl	44a0 <fwp_map_items>
    5218:	a9430be1 	ldp	x1, x2, [sp, #48]
    521c:	eb01005f 	cmp	x2, x1
    5220:	9a819042 	csel	x2, x2, x1, ls	// ls = plast
    5224:	b4000f42 	cbz	x2, 540c <fwp_loop_fields68.constprop.0+0xab8>
    5228:	d2800001 	mov	x1, #0x0                   	// #0
    522c:	d503201f 	nop
    5230:	fc617a60 	ldr	d0, [x19, x1, lsl #3]
    5234:	fc617801 	ldr	d1, [x0, x1, lsl #3]
    5238:	1e613800 	fsub	d0, d0, d1
    523c:	fc217a60 	str	d0, [x19, x1, lsl #3]
    5240:	91000421 	add	x1, x1, #0x1
    5244:	eb01005f 	cmp	x2, x1
    5248:	54ffff41 	b.ne	5230 <fwp_loop_fields68.constprop.0+0x8dc>  // b.any
    524c:	f90027e2 	str	x2, [sp, #72]
    5250:	97fff7d8 	bl	31b0 <fwp_mem_free>
    5254:	aa1703e0 	mov	x0, x23
    5258:	97fffbda 	bl	41c0 <fwp_map_finish_protected.isra.0>
    525c:	aa0003f3 	mov	x19, x0
    5260:	aa1403e0 	mov	x0, x20
    5264:	97fffd47 	bl	4780 <fwp_drop0>
    5268:	f9400be0 	ldr	x0, [sp, #16]
    526c:	97fffd45 	bl	4780 <fwp_drop0>
    5270:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    5274:	f947f400 	ldr	x0, [x0, #4072]
    5278:	f9404fe2 	ldr	x2, [sp, #152]
    527c:	f9400001 	ldr	x1, [x0]
    5280:	eb010042 	subs	x2, x2, x1
    5284:	d2800001 	mov	x1, #0x0                   	// #0
    5288:	54001101 	b.ne	54a8 <fwp_loop_fields68.constprop.0+0xb54>  // b.any
    528c:	a94a7bfd 	ldp	x29, x30, [sp, #160]
    5290:	aa1303e0 	mov	x0, x19
    5294:	a94b53f3 	ldp	x19, x20, [sp, #176]
    5298:	a94c5bf5 	ldp	x21, x22, [sp, #192]
    529c:	a94d63f7 	ldp	x23, x24, [sp, #208]
    52a0:	a94e6bf9 	ldp	x25, x26, [sp, #224]
    52a4:	a94f73fb 	ldp	x27, x28, [sp, #240]
    52a8:	6d5027e8 	ldp	d8, d9, [sp, #256]
    52ac:	fd408bea 	ldr	d10, [sp, #272]
    52b0:	910483ff 	add	sp, sp, #0x120
    52b4:	d65f03c0 	ret
    52b8:	aa1b03e0 	mov	x0, x27
    52bc:	97fff71d 	bl	2f30 <fwp_rc_forget_slot>
    52c0:	17fffe2a 	b	4b68 <fwp_loop_fields68.constprop.0+0x214>
    52c4:	72003c3f 	tst	w1, #0xffff
    52c8:	54ffc521 	b.ne	4b6c <fwp_loop_fields68.constprop.0+0x218>  // b.any
    52cc:	17fffe24 	b	4b5c <fwp_loop_fields68.constprop.0+0x208>
    52d0:	aa1803e0 	mov	x0, x24
    52d4:	97fff717 	bl	2f30 <fwp_rc_forget_slot>
    52d8:	17fffef1 	b	4e9c <fwp_loop_fields68.constprop.0+0x548>
    52dc:	72003c3f 	tst	w1, #0xffff
    52e0:	54ffde01 	b.ne	4ea0 <fwp_loop_fields68.constprop.0+0x54c>  // b.any
    52e4:	17fffeeb 	b	4e90 <fwp_loop_fields68.constprop.0+0x53c>
    52e8:	b4ffc500 	cbz	x0, 4b88 <fwp_loop_fields68.constprop.0+0x234>
    52ec:	17fffe25 	b	4b80 <fwp_loop_fields68.constprop.0+0x22c>
    52f0:	72003c3f 	tst	w1, #0xffff
    52f4:	54ffebe1 	b.ne	5070 <fwp_loop_fields68.constprop.0+0x71c>  // b.any
    52f8:	17ffff55 	b	504c <fwp_loop_fields68.constprop.0+0x6f8>
    52fc:	97fff6c6 	bl	2e14 <fwp_rc_wide_dup>
    5300:	17ffff14 	b	4f50 <fwp_loop_fields68.constprop.0+0x5fc>
    5304:	97fff6c4 	bl	2e14 <fwp_rc_wide_dup>
    5308:	17fffe6d 	b	4cbc <fwp_loop_fields68.constprop.0+0x368>
    530c:	72003c3f 	tst	w1, #0xffff
    5310:	54ffc901 	b.ne	4c30 <fwp_loop_fields68.constprop.0+0x2dc>  // b.any
    5314:	39400260 	ldrb	w0, [x19]
    5318:	7103fc1f 	cmp	w0, #0xff
    531c:	54ffc861 	b.ne	4c28 <fwp_loop_fields68.constprop.0+0x2d4>  // b.any
    5320:	aa1303e0 	mov	x0, x19
    5324:	97fff703 	bl	2f30 <fwp_rc_forget_slot>
    5328:	17fffe40 	b	4c28 <fwp_loop_fields68.constprop.0+0x2d4>
    532c:	72003c3f 	tst	w1, #0xffff
    5330:	54ffb8a1 	b.ne	4a44 <fwp_loop_fields68.constprop.0+0xf0>  // b.any
    5334:	17fffdb7 	b	4a10 <fwp_loop_fields68.constprop.0+0xbc>
    5338:	72003c3f 	tst	w1, #0xffff
    533c:	54ffd5e1 	b.ne	4df8 <fwp_loop_fields68.constprop.0+0x4a4>  // b.any
    5340:	17fffea1 	b	4dc4 <fwp_loop_fields68.constprop.0+0x470>
    5344:	72003c3f 	tst	w1, #0xffff
    5348:	54ffeda1 	b.ne	50fc <fwp_loop_fields68.constprop.0+0x7a8>  // b.any
    534c:	17ffff67 	b	50e8 <fwp_loop_fields68.constprop.0+0x794>
    5350:	f94007f4 	ldr	x20, [sp, #8]
    5354:	f9400680 	ldr	x0, [x20, #8]
    5358:	97fffc76 	bl	4530 <fwp_drop4>
    535c:	9114c2a4 	add	x4, x21, #0x530
    5360:	aa1403e0 	mov	x0, x20
    5364:	f9400a94 	ldr	x20, [x20, #16]
    5368:	f949ec83 	ldr	x3, [x4, #5080]
    536c:	f949d881 	ldr	x1, [x4, #5040]
    5370:	d370bc63 	lsl	x3, x3, #16
    5374:	cb010002 	sub	x2, x0, x1
    5378:	eb03005f 	cmp	x2, x3
    537c:	540003a2 	b.cs	53f0 <fwp_loop_fields68.constprop.0+0xa9c>  // b.hs, b.nlast
    5380:	d350fc40 	lsr	x0, x2, #16
    5384:	f949fc86 	ldr	x6, [x4, #5112]
    5388:	8b000800 	add	x0, x0, x0, lsl #2
    538c:	d37df000 	lsl	x0, x0, #3
    5390:	8b0000c5 	add	x5, x6, x0
    5394:	f94010a4 	ldr	x4, [x5, #32]
    5398:	b40002c4 	cbz	x4, 53f0 <fwp_loop_fields68.constprop.0+0xa9c>
    539c:	386068c0 	ldrb	w0, [x6, x0]
    53a0:	7100081f 	cmp	w0, #0x2
    53a4:	540003e0 	b.eq	5420 <fwp_loop_fields68.constprop.0+0xacc>  // b.none
    53a8:	7100041f 	cmp	w0, #0x1
    53ac:	54000221 	b.ne	53f0 <fwp_loop_fields68.constprop.0+0xa9c>  // b.any
    53b0:	92403c40 	and	x0, x2, #0xffff
    53b4:	294308a6 	ldp	w6, w2, [x5, #24]
    53b8:	9b067c00 	mul	x0, x0, x6
    53bc:	d360fc00 	lsr	x0, x0, #32
    53c0:	eb02001f 	cmp	x0, x2
    53c4:	54000162 	b.cs	53f0 <fwp_loop_fields68.constprop.0+0xa9c>  // b.hs, b.nlast
    53c8:	8b000084 	add	x4, x4, x0
    53cc:	39400080 	ldrb	w0, [x4]
    53d0:	7100041f 	cmp	w0, #0x1
    53d4:	540000e1 	b.ne	53f0 <fwp_loop_fields68.constprop.0+0xa9c>  // b.any
    53d8:	f94007e0 	ldr	x0, [sp, #8]
    53dc:	97fff775 	bl	31b0 <fwp_mem_free>
    53e0:	9114c2a0 	add	x0, x21, #0x530
    53e4:	f949ec03 	ldr	x3, [x0, #5080]
    53e8:	f949d801 	ldr	x1, [x0, #5040]
    53ec:	d370bc63 	lsl	x3, x3, #16
    53f0:	cb010281 	sub	x1, x20, x1
    53f4:	eb01007f 	cmp	x3, x1
    53f8:	54ffe3c9 	b.ls	5070 <fwp_loop_fields68.constprop.0+0x71c>  // b.plast
    53fc:	f90007f4 	str	x20, [sp, #8]
    5400:	17ffff00 	b	5000 <fwp_loop_fields68.constprop.0+0x6ac>
    5404:	b4ffeb00 	cbz	x0, 5164 <fwp_loop_fields68.constprop.0+0x810>
    5408:	17ffff56 	b	5160 <fwp_loop_fields68.constprop.0+0x80c>
    540c:	b4fff240 	cbz	x0, 5254 <fwp_loop_fields68.constprop.0+0x900>
    5410:	17ffff90 	b	5250 <fwp_loop_fields68.constprop.0+0x8fc>
    5414:	aa1403e0 	mov	x0, x20
    5418:	97fff6c6 	bl	2f30 <fwp_rc_forget_slot>
    541c:	17ffff36 	b	50f4 <fwp_loop_fields68.constprop.0+0x7a0>
    5420:	72003c5f 	tst	w2, #0xffff
    5424:	54fffe61 	b.ne	53f0 <fwp_loop_fields68.constprop.0+0xa9c>  // b.any
    5428:	17ffffe9 	b	53cc <fwp_loop_fields68.constprop.0+0xa78>
    542c:	ca544680 	eor	x0, x20, x20, lsr #17
    5430:	9114c2a1 	add	x1, x21, #0x530
    5434:	ca402400 	eor	x0, x0, x0, lsr #9
    5438:	8b200c20 	add	x0, x1, w0, uxtb #3
    543c:	f94a2400 	ldr	x0, [x0, #5192]
    5440:	b5000080 	cbnz	x0, 5450 <fwp_loop_fields68.constprop.0+0xafc>
    5444:	14000016 	b	549c <fwp_loop_fields68.constprop.0+0xb48>
    5448:	f9400800 	ldr	x0, [x0, #16]
    544c:	b4000280 	cbz	x0, 549c <fwp_loop_fields68.constprop.0+0xb48>
    5450:	f9400001 	ldr	x1, [x0]
    5454:	eb01029f 	cmp	x20, x1
    5458:	54ffff81 	b.ne	5448 <fwp_loop_fields68.constprop.0+0xaf4>  // b.any
    545c:	f9400401 	ldr	x1, [x0, #8]
    5460:	d1000421 	sub	x1, x1, #0x1
    5464:	f9000401 	str	x1, [x0, #8]
    5468:	f103f83f 	cmp	x1, #0xfe
    546c:	54ffe021 	b.ne	5070 <fwp_loop_fields68.constprop.0+0x71c>  // b.any
    5470:	aa1403e0 	mov	x0, x20
    5474:	97fff6af 	bl	2f30 <fwp_rc_forget_slot>
    5478:	12800020 	mov	w0, #0xfffffffe            	// #-2
    547c:	39000280 	strb	w0, [x20]
    5480:	17fffefc 	b	5070 <fwp_loop_fields68.constprop.0+0x71c>
    5484:	97fff664 	bl	2e14 <fwp_rc_wide_dup>
    5488:	17fffe5c 	b	4df8 <fwp_loop_fields68.constprop.0+0x4a4>
    548c:	97fff662 	bl	2e14 <fwp_rc_wide_dup>
    5490:	17fffd6d 	b	4a44 <fwp_loop_fields68.constprop.0+0xf0>
    5494:	f90007ff 	str	xzr, [sp, #8]
    5498:	17fffd43 	b	49a4 <fwp_loop_fields68.constprop.0+0x50>
    549c:	f0000000 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    54a0:	9100c000 	add	x0, x0, #0x30
    54a4:	97fff397 	bl	2300 <fwp_trap>
    54a8:	97fff02a 	bl	1550 <__stack_chk_fail@plt>
    54ac:	d503201f 	nop

00000000000054b0 <fwp_drop6>:
    54b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    54b4:	910003fd 	mov	x29, sp
    54b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    54bc:	90000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    54c0:	9114c2d5 	add	x21, x22, #0x530
    54c4:	a90153f3 	stp	x19, x20, [sp, #16]
    54c8:	aa0003f3 	mov	x19, x0
    54cc:	f949daa1 	ldr	x1, [x21, #5040]
    54d0:	f949eea0 	ldr	x0, [x21, #5080]
    54d4:	cb010261 	sub	x1, x19, x1
    54d8:	eb00403f 	cmp	x1, x0, lsl #16
    54dc:	54000382 	b.cs	554c <fwp_drop6+0x9c>  // b.hs, b.nlast
    54e0:	d350fc22 	lsr	x2, x1, #16
    54e4:	f949fea3 	ldr	x3, [x21, #5112]
    54e8:	8b020842 	add	x2, x2, x2, lsl #2
    54ec:	d37df042 	lsl	x2, x2, #3
    54f0:	8b020060 	add	x0, x3, x2
    54f4:	f9401014 	ldr	x20, [x0, #32]
    54f8:	b40002b4 	cbz	x20, 554c <fwp_drop6+0x9c>
    54fc:	38626862 	ldrb	w2, [x3, x2]
    5500:	7100085f 	cmp	w2, #0x2
    5504:	540002c0 	b.eq	555c <fwp_drop6+0xac>  // b.none
    5508:	7100045f 	cmp	w2, #0x1
    550c:	54000201 	b.ne	554c <fwp_drop6+0x9c>  // b.any
    5510:	29430002 	ldp	w2, w0, [x0, #24]
    5514:	92403c21 	and	x1, x1, #0xffff
    5518:	9b027c21 	mul	x1, x1, x2
    551c:	d360fc21 	lsr	x1, x1, #32
    5520:	eb00003f 	cmp	x1, x0
    5524:	54000142 	b.cs	554c <fwp_drop6+0x9c>  // b.hs, b.nlast
    5528:	8b010294 	add	x20, x20, x1
    552c:	39400280 	ldrb	w0, [x20]
    5530:	340000e0 	cbz	w0, 554c <fwp_drop6+0x9c>
    5534:	7100041f 	cmp	w0, #0x1
    5538:	540001e0 	b.eq	5574 <fwp_drop6+0xc4>  // b.none
    553c:	7103fc1f 	cmp	w0, #0xff
    5540:	54000760 	b.eq	562c <fwp_drop6+0x17c>  // b.none
    5544:	51000400 	sub	w0, w0, #0x1
    5548:	39000280 	strb	w0, [x20]
    554c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5550:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5554:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5558:	d65f03c0 	ret
    555c:	72003c3f 	tst	w1, #0xffff
    5560:	54fffe60 	b.eq	552c <fwp_drop6+0x7c>  // b.none
    5564:	a94153f3 	ldp	x19, x20, [sp, #16]
    5568:	a9425bf5 	ldp	x21, x22, [sp, #32]
    556c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5570:	d65f03c0 	ret
    5574:	f9400660 	ldr	x0, [x19, #8]
    5578:	97fffbee 	bl	4530 <fwp_drop4>
    557c:	9114c2c4 	add	x4, x22, #0x530
    5580:	f9400a74 	ldr	x20, [x19, #16]
    5584:	f949ec83 	ldr	x3, [x4, #5080]
    5588:	f949d881 	ldr	x1, [x4, #5040]
    558c:	d370bc63 	lsl	x3, x3, #16
    5590:	cb010262 	sub	x2, x19, x1
    5594:	eb03005f 	cmp	x2, x3
    5598:	540003a2 	b.cs	560c <fwp_drop6+0x15c>  // b.hs, b.nlast
    559c:	d350fc40 	lsr	x0, x2, #16
    55a0:	f949fc86 	ldr	x6, [x4, #5112]
    55a4:	8b000800 	add	x0, x0, x0, lsl #2
    55a8:	d37df000 	lsl	x0, x0, #3
    55ac:	8b0000c5 	add	x5, x6, x0
    55b0:	f94010a4 	ldr	x4, [x5, #32]
    55b4:	b40002c4 	cbz	x4, 560c <fwp_drop6+0x15c>
    55b8:	386068c0 	ldrb	w0, [x6, x0]
    55bc:	7100081f 	cmp	w0, #0x2
    55c0:	54000300 	b.eq	5620 <fwp_drop6+0x170>  // b.none
    55c4:	7100041f 	cmp	w0, #0x1
    55c8:	54000221 	b.ne	560c <fwp_drop6+0x15c>  // b.any
    55cc:	92403c40 	and	x0, x2, #0xffff
    55d0:	294308a6 	ldp	w6, w2, [x5, #24]
    55d4:	9b067c00 	mul	x0, x0, x6
    55d8:	d360fc00 	lsr	x0, x0, #32
    55dc:	eb02001f 	cmp	x0, x2
    55e0:	54000162 	b.cs	560c <fwp_drop6+0x15c>  // b.hs, b.nlast
    55e4:	8b000084 	add	x4, x4, x0
    55e8:	39400080 	ldrb	w0, [x4]
    55ec:	7100041f 	cmp	w0, #0x1
    55f0:	540000e1 	b.ne	560c <fwp_drop6+0x15c>  // b.any
    55f4:	aa1303e0 	mov	x0, x19
    55f8:	97fff6ee 	bl	31b0 <fwp_mem_free>
    55fc:	9114c2c0 	add	x0, x22, #0x530
    5600:	f949ec03 	ldr	x3, [x0, #5080]
    5604:	f949d801 	ldr	x1, [x0, #5040]
    5608:	d370bc63 	lsl	x3, x3, #16
    560c:	cb010281 	sub	x1, x20, x1
    5610:	eb01007f 	cmp	x3, x1
    5614:	54fff9c9 	b.ls	554c <fwp_drop6+0x9c>  // b.plast
    5618:	aa1403f3 	mov	x19, x20
    561c:	17ffffb1 	b	54e0 <fwp_drop6+0x30>
    5620:	72003c5f 	tst	w2, #0xffff
    5624:	54ffff41 	b.ne	560c <fwp_drop6+0x15c>  // b.any
    5628:	17fffff0 	b	55e8 <fwp_drop6+0x138>
    562c:	ca544681 	eor	x1, x20, x20, lsr #17
    5630:	9114c2c0 	add	x0, x22, #0x530
    5634:	ca412421 	eor	x1, x1, x1, lsr #9
    5638:	8b210c01 	add	x1, x0, w1, uxtb #3
    563c:	f94a2420 	ldr	x0, [x1, #5192]
    5640:	b5000080 	cbnz	x0, 5650 <fwp_drop6+0x1a0>
    5644:	14000010 	b	5684 <fwp_drop6+0x1d4>
    5648:	f9400800 	ldr	x0, [x0, #16]
    564c:	b40001c0 	cbz	x0, 5684 <fwp_drop6+0x1d4>
    5650:	f9400001 	ldr	x1, [x0]
    5654:	eb14003f 	cmp	x1, x20
    5658:	54ffff81 	b.ne	5648 <fwp_drop6+0x198>  // b.any
    565c:	f9400401 	ldr	x1, [x0, #8]
    5660:	d1000421 	sub	x1, x1, #0x1
    5664:	f9000401 	str	x1, [x0, #8]
    5668:	f103f83f 	cmp	x1, #0xfe
    566c:	54fff701 	b.ne	554c <fwp_drop6+0x9c>  // b.any
    5670:	aa1403e0 	mov	x0, x20
    5674:	97fff62f 	bl	2f30 <fwp_rc_forget_slot>
    5678:	12800020 	mov	w0, #0xfffffffe            	// #-2
    567c:	39000280 	strb	w0, [x20]
    5680:	17ffffb3 	b	554c <fwp_drop6+0x9c>
    5684:	f0000000 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    5688:	9100c000 	add	x0, x0, #0x30
    568c:	97fff31d 	bl	2300 <fwp_trap>

0000000000005690 <fwp_args47>:
    5690:	7100003f 	cmp	w1, #0x0
    5694:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5698:	54000041 	b.ne	56a0 <fwp_args47+0x10>  // b.any
    569c:	d65f03c0 	ret
    56a0:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    56a4:	9114c042 	add	x2, x2, #0x530
    56a8:	f9400001 	ldr	x1, [x0]
    56ac:	f949d843 	ldr	x3, [x2, #5040]
    56b0:	f949ec40 	ldr	x0, [x2, #5080]
    56b4:	cb030021 	sub	x1, x1, x3
    56b8:	eb00403f 	cmp	x1, x0, lsl #16
    56bc:	54ffff02 	b.cs	569c <fwp_args47+0xc>  // b.hs, b.nlast
    56c0:	d350fc20 	lsr	x0, x1, #16
    56c4:	f949fc44 	ldr	x4, [x2, #5112]
    56c8:	8b000800 	add	x0, x0, x0, lsl #2
    56cc:	d37df002 	lsl	x2, x0, #3
    56d0:	8b020083 	add	x3, x4, x2
    56d4:	f9401060 	ldr	x0, [x3, #32]
    56d8:	b4fffe20 	cbz	x0, 569c <fwp_args47+0xc>
    56dc:	38626882 	ldrb	w2, [x4, x2]
    56e0:	7100085f 	cmp	w2, #0x2
    56e4:	54000320 	b.eq	5748 <fwp_args47+0xb8>  // b.none
    56e8:	7100045f 	cmp	w2, #0x1
    56ec:	54fffd81 	b.ne	569c <fwp_args47+0xc>  // b.any
    56f0:	29430864 	ldp	w4, w2, [x3, #24]
    56f4:	92403c21 	and	x1, x1, #0xffff
    56f8:	9b047c21 	mul	x1, x1, x4
    56fc:	d360fc21 	lsr	x1, x1, #32
    5700:	eb02003f 	cmp	x1, x2
    5704:	54fffcc2 	b.cs	569c <fwp_args47+0xc>  // b.hs, b.nlast
    5708:	8b010000 	add	x0, x0, x1
    570c:	39400001 	ldrb	w1, [x0]
    5710:	34fffc61 	cbz	w1, 569c <fwp_args47+0xc>
    5714:	f00000c2 	adrp	x2, 20000 <__data_start>
    5718:	91014042 	add	x2, x2, #0x50
    571c:	b9404043 	ldr	w3, [x2, #64]
    5720:	350000c3 	cbnz	w3, 5738 <fwp_args47+0xa8>
    5724:	7103f43f 	cmp	w1, #0xfd
    5728:	54000168 	b.hi	5754 <fwp_args47+0xc4>  // b.pmore
    572c:	11000421 	add	w1, w1, #0x1
    5730:	39000001 	strb	w1, [x0]
    5734:	d65f03c0 	ret
    5738:	f9402443 	ldr	x3, [x2, #72]
    573c:	91000463 	add	x3, x3, #0x1
    5740:	f9002443 	str	x3, [x2, #72]
    5744:	17fffff8 	b	5724 <fwp_args47+0x94>
    5748:	72003c3f 	tst	w1, #0xffff
    574c:	54fffe00 	b.eq	570c <fwp_args47+0x7c>  // b.none
    5750:	d65f03c0 	ret
    5754:	17fff5b0 	b	2e14 <fwp_rc_wide_dup>
    5758:	d503201f 	nop
    575c:	d503201f 	nop

0000000000005760 <fwp_args50>:
    5760:	7100003f 	cmp	w1, #0x0
    5764:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5768:	54000041 	b.ne	5770 <fwp_args50+0x10>  // b.any
    576c:	d65f03c0 	ret
    5770:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5774:	9114c042 	add	x2, x2, #0x530
    5778:	f9400001 	ldr	x1, [x0]
    577c:	f949d843 	ldr	x3, [x2, #5040]
    5780:	f949ec40 	ldr	x0, [x2, #5080]
    5784:	cb030021 	sub	x1, x1, x3
    5788:	eb00403f 	cmp	x1, x0, lsl #16
    578c:	54ffff02 	b.cs	576c <fwp_args50+0xc>  // b.hs, b.nlast
    5790:	d350fc20 	lsr	x0, x1, #16
    5794:	f949fc44 	ldr	x4, [x2, #5112]
    5798:	8b000800 	add	x0, x0, x0, lsl #2
    579c:	d37df002 	lsl	x2, x0, #3
    57a0:	8b020083 	add	x3, x4, x2
    57a4:	f9401060 	ldr	x0, [x3, #32]
    57a8:	b4fffe20 	cbz	x0, 576c <fwp_args50+0xc>
    57ac:	38626882 	ldrb	w2, [x4, x2]
    57b0:	7100085f 	cmp	w2, #0x2
    57b4:	54000320 	b.eq	5818 <fwp_args50+0xb8>  // b.none
    57b8:	7100045f 	cmp	w2, #0x1
    57bc:	54fffd81 	b.ne	576c <fwp_args50+0xc>  // b.any
    57c0:	29430864 	ldp	w4, w2, [x3, #24]
    57c4:	92403c21 	and	x1, x1, #0xffff
    57c8:	9b047c21 	mul	x1, x1, x4
    57cc:	d360fc21 	lsr	x1, x1, #32
    57d0:	eb02003f 	cmp	x1, x2
    57d4:	54fffcc2 	b.cs	576c <fwp_args50+0xc>  // b.hs, b.nlast
    57d8:	8b010000 	add	x0, x0, x1
    57dc:	39400001 	ldrb	w1, [x0]
    57e0:	34fffc61 	cbz	w1, 576c <fwp_args50+0xc>
    57e4:	f00000c2 	adrp	x2, 20000 <__data_start>
    57e8:	91014042 	add	x2, x2, #0x50
    57ec:	b9404043 	ldr	w3, [x2, #64]
    57f0:	350000c3 	cbnz	w3, 5808 <fwp_args50+0xa8>
    57f4:	7103f43f 	cmp	w1, #0xfd
    57f8:	54000168 	b.hi	5824 <fwp_args50+0xc4>  // b.pmore
    57fc:	11000421 	add	w1, w1, #0x1
    5800:	39000001 	strb	w1, [x0]
    5804:	d65f03c0 	ret
    5808:	f9402443 	ldr	x3, [x2, #72]
    580c:	91000463 	add	x3, x3, #0x1
    5810:	f9002443 	str	x3, [x2, #72]
    5814:	17fffff8 	b	57f4 <fwp_args50+0x94>
    5818:	72003c3f 	tst	w1, #0xffff
    581c:	54fffe00 	b.eq	57dc <fwp_args50+0x7c>  // b.none
    5820:	d65f03c0 	ret
    5824:	17fff57c 	b	2e14 <fwp_rc_wide_dup>
    5828:	d503201f 	nop
    582c:	d503201f 	nop

0000000000005830 <fwp_caps50>:
    5830:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5834:	910003fd 	mov	x29, sp
    5838:	f9000bf3 	str	x19, [sp, #16]
    583c:	aa0003f3 	mov	x19, x0
    5840:	b9400400 	ldr	w0, [x0, #4]
    5844:	340004a0 	cbz	w0, 58d8 <fwp_caps50+0xa8>
    5848:	f9400660 	ldr	x0, [x19, #8]
    584c:	350004e1 	cbnz	w1, 58e8 <fwp_caps50+0xb8>
    5850:	97fffb38 	bl	4530 <fwp_drop4>
    5854:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5858:	9114c042 	add	x2, x2, #0x530
    585c:	f949d840 	ldr	x0, [x2, #5040]
    5860:	f949ec41 	ldr	x1, [x2, #5080]
    5864:	cb000260 	sub	x0, x19, x0
    5868:	eb01401f 	cmp	x0, x1, lsl #16
    586c:	54000382 	b.cs	58dc <fwp_caps50+0xac>  // b.hs, b.nlast
    5870:	d350fc01 	lsr	x1, x0, #16
    5874:	f949fc44 	ldr	x4, [x2, #5112]
    5878:	8b010821 	add	x1, x1, x1, lsl #2
    587c:	d37df021 	lsl	x1, x1, #3
    5880:	8b010083 	add	x3, x4, x1
    5884:	f9401062 	ldr	x2, [x3, #32]
    5888:	b40002a2 	cbz	x2, 58dc <fwp_caps50+0xac>
    588c:	38616881 	ldrb	w1, [x4, x1]
    5890:	7100083f 	cmp	w1, #0x2
    5894:	54000740 	b.eq	597c <fwp_caps50+0x14c>  // b.none
    5898:	7100043f 	cmp	w1, #0x1
    589c:	54000201 	b.ne	58dc <fwp_caps50+0xac>  // b.any
    58a0:	29430464 	ldp	w4, w1, [x3, #24]
    58a4:	92403c00 	and	x0, x0, #0xffff
    58a8:	9b047c00 	mul	x0, x0, x4
    58ac:	d360fc00 	lsr	x0, x0, #32
    58b0:	eb01001f 	cmp	x0, x1
    58b4:	54000142 	b.cs	58dc <fwp_caps50+0xac>  // b.hs, b.nlast
    58b8:	8b000042 	add	x2, x2, x0
    58bc:	39400040 	ldrb	w0, [x2]
    58c0:	7100041f 	cmp	w0, #0x1
    58c4:	540000c1 	b.ne	58dc <fwp_caps50+0xac>  // b.any
    58c8:	aa1303e0 	mov	x0, x19
    58cc:	f9400bf3 	ldr	x19, [sp, #16]
    58d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    58d4:	17fff637 	b	31b0 <fwp_mem_free>
    58d8:	34fffbe1 	cbz	w1, 5854 <fwp_caps50+0x24>
    58dc:	f9400bf3 	ldr	x19, [sp, #16]
    58e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    58e4:	d65f03c0 	ret
    58e8:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    58ec:	9114c042 	add	x2, x2, #0x530
    58f0:	f949d843 	ldr	x3, [x2, #5040]
    58f4:	f949ec41 	ldr	x1, [x2, #5080]
    58f8:	cb030000 	sub	x0, x0, x3
    58fc:	eb01401f 	cmp	x0, x1, lsl #16
    5900:	54fffee2 	b.cs	58dc <fwp_caps50+0xac>  // b.hs, b.nlast
    5904:	d350fc01 	lsr	x1, x0, #16
    5908:	f949fc44 	ldr	x4, [x2, #5112]
    590c:	8b010821 	add	x1, x1, x1, lsl #2
    5910:	d37df021 	lsl	x1, x1, #3
    5914:	8b010083 	add	x3, x4, x1
    5918:	f9401062 	ldr	x2, [x3, #32]
    591c:	b4fffe02 	cbz	x2, 58dc <fwp_caps50+0xac>
    5920:	38616881 	ldrb	w1, [x4, x1]
    5924:	7100083f 	cmp	w1, #0x2
    5928:	54000300 	b.eq	5988 <fwp_caps50+0x158>  // b.none
    592c:	7100043f 	cmp	w1, #0x1
    5930:	54fffd61 	b.ne	58dc <fwp_caps50+0xac>  // b.any
    5934:	92403c01 	and	x1, x0, #0xffff
    5938:	29430064 	ldp	w4, w0, [x3, #24]
    593c:	9b047c21 	mul	x1, x1, x4
    5940:	d360fc21 	lsr	x1, x1, #32
    5944:	eb00003f 	cmp	x1, x0
    5948:	54fffca2 	b.cs	58dc <fwp_caps50+0xac>  // b.hs, b.nlast
    594c:	8b010042 	add	x2, x2, x1
    5950:	39400040 	ldrb	w0, [x2]
    5954:	34fffc40 	cbz	w0, 58dc <fwp_caps50+0xac>
    5958:	f00000c1 	adrp	x1, 20000 <__data_start>
    595c:	91014021 	add	x1, x1, #0x50
    5960:	b9404023 	ldr	w3, [x1, #64]
    5964:	35000183 	cbnz	w3, 5994 <fwp_caps50+0x164>
    5968:	7103f41f 	cmp	w0, #0xfd
    596c:	540001c8 	b.hi	59a4 <fwp_caps50+0x174>  // b.pmore
    5970:	11000400 	add	w0, w0, #0x1
    5974:	39000040 	strb	w0, [x2]
    5978:	17ffffd9 	b	58dc <fwp_caps50+0xac>
    597c:	72003c1f 	tst	w0, #0xffff
    5980:	54fffae1 	b.ne	58dc <fwp_caps50+0xac>  // b.any
    5984:	17ffffce 	b	58bc <fwp_caps50+0x8c>
    5988:	72003c1f 	tst	w0, #0xffff
    598c:	54fffa81 	b.ne	58dc <fwp_caps50+0xac>  // b.any
    5990:	17fffff0 	b	5950 <fwp_caps50+0x120>
    5994:	f9402423 	ldr	x3, [x1, #72]
    5998:	91000463 	add	x3, x3, #0x1
    599c:	f9002423 	str	x3, [x1, #72]
    59a0:	17fffff2 	b	5968 <fwp_caps50+0x138>
    59a4:	f9400bf3 	ldr	x19, [sp, #16]
    59a8:	aa0203e0 	mov	x0, x2
    59ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    59b0:	17fff519 	b	2e14 <fwp_rc_wide_dup>

00000000000059b4 <fwp_caps47>:
    59b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    59b8:	910003fd 	mov	x29, sp
    59bc:	f9000bf3 	str	x19, [sp, #16]
    59c0:	aa0003f3 	mov	x19, x0
    59c4:	b9400400 	ldr	w0, [x0, #4]
    59c8:	340004a0 	cbz	w0, 5a5c <fwp_caps47+0xa8>
    59cc:	f9400660 	ldr	x0, [x19, #8]
    59d0:	350004e1 	cbnz	w1, 5a6c <fwp_caps47+0xb8>
    59d4:	97fffad7 	bl	4530 <fwp_drop4>
    59d8:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    59dc:	9114c042 	add	x2, x2, #0x530
    59e0:	f949d840 	ldr	x0, [x2, #5040]
    59e4:	f949ec41 	ldr	x1, [x2, #5080]
    59e8:	cb000260 	sub	x0, x19, x0
    59ec:	eb01401f 	cmp	x0, x1, lsl #16
    59f0:	54000382 	b.cs	5a60 <fwp_caps47+0xac>  // b.hs, b.nlast
    59f4:	d350fc01 	lsr	x1, x0, #16
    59f8:	f949fc44 	ldr	x4, [x2, #5112]
    59fc:	8b010821 	add	x1, x1, x1, lsl #2
    5a00:	d37df021 	lsl	x1, x1, #3
    5a04:	8b010083 	add	x3, x4, x1
    5a08:	f9401062 	ldr	x2, [x3, #32]
    5a0c:	b40002a2 	cbz	x2, 5a60 <fwp_caps47+0xac>
    5a10:	38616881 	ldrb	w1, [x4, x1]
    5a14:	7100083f 	cmp	w1, #0x2
    5a18:	54000740 	b.eq	5b00 <fwp_caps47+0x14c>  // b.none
    5a1c:	7100043f 	cmp	w1, #0x1
    5a20:	54000201 	b.ne	5a60 <fwp_caps47+0xac>  // b.any
    5a24:	29430464 	ldp	w4, w1, [x3, #24]
    5a28:	92403c00 	and	x0, x0, #0xffff
    5a2c:	9b047c00 	mul	x0, x0, x4
    5a30:	d360fc00 	lsr	x0, x0, #32
    5a34:	eb01001f 	cmp	x0, x1
    5a38:	54000142 	b.cs	5a60 <fwp_caps47+0xac>  // b.hs, b.nlast
    5a3c:	8b000042 	add	x2, x2, x0
    5a40:	39400040 	ldrb	w0, [x2]
    5a44:	7100041f 	cmp	w0, #0x1
    5a48:	540000c1 	b.ne	5a60 <fwp_caps47+0xac>  // b.any
    5a4c:	aa1303e0 	mov	x0, x19
    5a50:	f9400bf3 	ldr	x19, [sp, #16]
    5a54:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a58:	17fff5d6 	b	31b0 <fwp_mem_free>
    5a5c:	34fffbe1 	cbz	w1, 59d8 <fwp_caps47+0x24>
    5a60:	f9400bf3 	ldr	x19, [sp, #16]
    5a64:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a68:	d65f03c0 	ret
    5a6c:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5a70:	9114c042 	add	x2, x2, #0x530
    5a74:	f949d843 	ldr	x3, [x2, #5040]
    5a78:	f949ec41 	ldr	x1, [x2, #5080]
    5a7c:	cb030000 	sub	x0, x0, x3
    5a80:	eb01401f 	cmp	x0, x1, lsl #16
    5a84:	54fffee2 	b.cs	5a60 <fwp_caps47+0xac>  // b.hs, b.nlast
    5a88:	d350fc01 	lsr	x1, x0, #16
    5a8c:	f949fc44 	ldr	x4, [x2, #5112]
    5a90:	8b010821 	add	x1, x1, x1, lsl #2
    5a94:	d37df021 	lsl	x1, x1, #3
    5a98:	8b010083 	add	x3, x4, x1
    5a9c:	f9401062 	ldr	x2, [x3, #32]
    5aa0:	b4fffe02 	cbz	x2, 5a60 <fwp_caps47+0xac>
    5aa4:	38616881 	ldrb	w1, [x4, x1]
    5aa8:	7100083f 	cmp	w1, #0x2
    5aac:	54000300 	b.eq	5b0c <fwp_caps47+0x158>  // b.none
    5ab0:	7100043f 	cmp	w1, #0x1
    5ab4:	54fffd61 	b.ne	5a60 <fwp_caps47+0xac>  // b.any
    5ab8:	92403c01 	and	x1, x0, #0xffff
    5abc:	29430064 	ldp	w4, w0, [x3, #24]
    5ac0:	9b047c21 	mul	x1, x1, x4
    5ac4:	d360fc21 	lsr	x1, x1, #32
    5ac8:	eb00003f 	cmp	x1, x0
    5acc:	54fffca2 	b.cs	5a60 <fwp_caps47+0xac>  // b.hs, b.nlast
    5ad0:	8b010042 	add	x2, x2, x1
    5ad4:	39400040 	ldrb	w0, [x2]
    5ad8:	34fffc40 	cbz	w0, 5a60 <fwp_caps47+0xac>
    5adc:	f00000c1 	adrp	x1, 20000 <__data_start>
    5ae0:	91014021 	add	x1, x1, #0x50
    5ae4:	b9404023 	ldr	w3, [x1, #64]
    5ae8:	35000183 	cbnz	w3, 5b18 <fwp_caps47+0x164>
    5aec:	7103f41f 	cmp	w0, #0xfd
    5af0:	540001c8 	b.hi	5b28 <fwp_caps47+0x174>  // b.pmore
    5af4:	11000400 	add	w0, w0, #0x1
    5af8:	39000040 	strb	w0, [x2]
    5afc:	17ffffd9 	b	5a60 <fwp_caps47+0xac>
    5b00:	72003c1f 	tst	w0, #0xffff
    5b04:	54fffae1 	b.ne	5a60 <fwp_caps47+0xac>  // b.any
    5b08:	17ffffce 	b	5a40 <fwp_caps47+0x8c>
    5b0c:	72003c1f 	tst	w0, #0xffff
    5b10:	54fffa81 	b.ne	5a60 <fwp_caps47+0xac>  // b.any
    5b14:	17fffff0 	b	5ad4 <fwp_caps47+0x120>
    5b18:	f9402423 	ldr	x3, [x1, #72]
    5b1c:	91000463 	add	x3, x3, #0x1
    5b20:	f9002423 	str	x3, [x1, #72]
    5b24:	17fffff2 	b	5aec <fwp_caps47+0x138>
    5b28:	f9400bf3 	ldr	x19, [sp, #16]
    5b2c:	aa0203e0 	mov	x0, x2
    5b30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b34:	17fff4b8 	b	2e14 <fwp_rc_wide_dup>
    5b38:	d503201f 	nop
    5b3c:	d503201f 	nop

0000000000005b40 <fwp_write>:
    5b40:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5b44:	910003fd 	mov	x29, sp
    5b48:	d00000c4 	adrp	x4, 1f000 <__FRAME_END__+0x15a68>
    5b4c:	f947f484 	ldr	x4, [x4, #4072]
    5b50:	a90153f3 	stp	x19, x20, [sp, #16]
    5b54:	d10943ff 	sub	sp, sp, #0x250
    5b58:	b9400045 	ldr	w5, [x2]
    5b5c:	aa0003f4 	mov	x20, x0
    5b60:	f9400080 	ldr	x0, [x4]
    5b64:	f90127e0 	str	x0, [sp, #584]
    5b68:	d2800000 	mov	x0, #0x0                   	// #0
    5b6c:	710064bf 	cmp	w5, #0x19
    5b70:	54000408 	b.hi	5bf0 <fwp_write+0xb0>  // b.pmore
    5b74:	f0000000 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    5b78:	aa0103f3 	mov	x19, x1
    5b7c:	910f0000 	add	x0, x0, #0x3c0
    5b80:	f9013bf5 	str	x21, [sp, #624]
    5b84:	f9013ff6 	str	x22, [sp, #632]
    5b88:	f90153fb 	str	x27, [sp, #672]
    5b8c:	f90157fc 	str	x28, [sp, #680]
    5b90:	aa0203fc 	mov	x28, x2
    5b94:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    5b98:	10000061 	adr	x1, 5ba4 <fwp_write+0x64>
    5b9c:	8b20a820 	add	x0, x1, w0, sxth #2
    5ba0:	d61f0000 	br	x0
    5ba4:	910123e0 	add	x0, sp, #0x48
    5ba8:	aa1303e5 	mov	x5, x19
    5bac:	f0000004 	adrp	x4, 8000 <_IO_stdin_used+0x2b0>
    5bb0:	aa0003f3 	mov	x19, x0
    5bb4:	91040084 	add	x4, x4, #0x100
    5bb8:	d2804003 	mov	x3, #0x200                 	// #512
    5bbc:	aa0303e1 	mov	x1, x3
    5bc0:	52800042 	mov	w2, #0x2                   	// #2
    5bc4:	97ffee3f 	bl	14c0 <__snprintf_chk@plt>
    5bc8:	aa1303e0 	mov	x0, x19
    5bcc:	97ffee05 	bl	13e0 <strlen@plt>
    5bd0:	aa1303e1 	mov	x1, x19
    5bd4:	aa0003e2 	mov	x2, x0
    5bd8:	aa1403e0 	mov	x0, x20
    5bdc:	97fff16d 	bl	2190 <buf_put>
    5be0:	f9413bf5 	ldr	x21, [sp, #624]
    5be4:	f9413ff6 	ldr	x22, [sp, #632]
    5be8:	f94153fb 	ldr	x27, [sp, #672]
    5bec:	f94157fc 	ldr	x28, [sp, #680]
    5bf0:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    5bf4:	f947f400 	ldr	x0, [x0, #4072]
    5bf8:	f94127e2 	ldr	x2, [sp, #584]
    5bfc:	f9400001 	ldr	x1, [x0]
    5c00:	eb010042 	subs	x2, x2, x1
    5c04:	d2800001 	mov	x1, #0x0                   	// #0
    5c08:	540077c1 	b.ne	6b00 <fwp_write+0xfc0>  // b.any
    5c0c:	910943ff 	add	sp, sp, #0x250
    5c10:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c14:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5c18:	d65f03c0 	ret
    5c1c:	910123e0 	add	x0, sp, #0x48
    5c20:	aa1303e5 	mov	x5, x19
    5c24:	f0000004 	adrp	x4, 8000 <_IO_stdin_used+0x2b0>
    5c28:	aa0003f3 	mov	x19, x0
    5c2c:	9103e084 	add	x4, x4, #0xf8
    5c30:	d2804003 	mov	x3, #0x200                 	// #512
    5c34:	17ffffe2 	b	5bbc <fwp_write+0x7c>
    5c38:	71004cbf 	cmp	w5, #0x13
    5c3c:	f0000000 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    5c40:	f0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    5c44:	9103a000 	add	x0, x0, #0xe8
    5c48:	9103c021 	add	x1, x1, #0xf0
    5c4c:	d2800082 	mov	x2, #0x4                   	// #4
    5c50:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    5c54:	aa1403e0 	mov	x0, x20
    5c58:	f90143f7 	str	x23, [sp, #640]
    5c5c:	d2800016 	mov	x22, #0x0                   	// #0
    5c60:	f90147f8 	str	x24, [sp, #648]
    5c64:	97fff14b 	bl	2190 <buf_put>
    5c68:	f9400260 	ldr	x0, [x19]
    5c6c:	f0000017 	adrp	x23, 8000 <_IO_stdin_used+0x2b0>
    5c70:	d2800015 	mov	x21, #0x0                   	// #0
    5c74:	9105c2f7 	add	x23, x23, #0x170
    5c78:	b40047a0 	cbz	x0, 656c <fwp_write+0xa2c>
    5c7c:	b9400380 	ldr	w0, [x28]
    5c80:	52800003 	mov	w3, #0x0                   	// #0
    5c84:	f9401f82 	ldr	x2, [x28, #56]
    5c88:	71004c1f 	cmp	w0, #0x13
    5c8c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    5c90:	aa1403e0 	mov	x0, x20
    5c94:	8b010e61 	add	x1, x19, x1, lsl #3
    5c98:	f9400421 	ldr	x1, [x1, #8]
    5c9c:	97ffffa9 	bl	5b40 <fwp_write>
    5ca0:	b9400380 	ldr	w0, [x28]
    5ca4:	7100481f 	cmp	w0, #0x12
    5ca8:	54004b40 	b.eq	6610 <fwp_write+0xad0>  // b.none
    5cac:	f9400260 	ldr	x0, [x19]
    5cb0:	910006b5 	add	x21, x21, #0x1
    5cb4:	91000ad6 	add	x22, x22, #0x2
    5cb8:	eb15001f 	cmp	x0, x21
    5cbc:	54004589 	b.ls	656c <fwp_write+0xa2c>  // b.plast
    5cc0:	aa1703e1 	mov	x1, x23
    5cc4:	aa1403e0 	mov	x0, x20
    5cc8:	d2800042 	mov	x2, #0x2                   	// #2
    5ccc:	97fff131 	bl	2190 <buf_put>
    5cd0:	17ffffeb 	b	5c7c <fwp_write+0x13c>
    5cd4:	f0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    5cd8:	9104a021 	add	x1, x1, #0x128
    5cdc:	d28000c2 	mov	x2, #0x6                   	// #6
    5ce0:	aa1403e0 	mov	x0, x20
    5ce4:	91004273 	add	x19, x19, #0x10
    5ce8:	97fff12a 	bl	2190 <buf_put>
    5cec:	aa1303e0 	mov	x0, x19
    5cf0:	97ffedbc 	bl	13e0 <strlen@plt>
    5cf4:	aa1303e1 	mov	x1, x19
    5cf8:	aa0003e2 	mov	x2, x0
    5cfc:	aa1403e0 	mov	x0, x20
    5d00:	97fff124 	bl	2190 <buf_put>
    5d04:	528007c3 	mov	w3, #0x3e                  	// #62
    5d08:	aa1403e0 	mov	x0, x20
    5d0c:	91001fe1 	add	x1, sp, #0x7
    5d10:	d2800022 	mov	x2, #0x1                   	// #1
    5d14:	39001fe3 	strb	w3, [sp, #7]
    5d18:	17ffffb1 	b	5bdc <fwp_write+0x9c>
    5d1c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    5d20:	f947f400 	ldr	x0, [x0, #4072]
    5d24:	f94127e2 	ldr	x2, [sp, #584]
    5d28:	f9400001 	ldr	x1, [x0]
    5d2c:	eb010042 	subs	x2, x2, x1
    5d30:	d2800001 	mov	x1, #0x0                   	// #0
    5d34:	540034e1 	b.ne	63d0 <fwp_write+0x890>  // b.any
    5d38:	f9413bf5 	ldr	x21, [sp, #624]
    5d3c:	f0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    5d40:	f9413ff6 	ldr	x22, [sp, #632]
    5d44:	aa1403e0 	mov	x0, x20
    5d48:	91042021 	add	x1, x1, #0x108
    5d4c:	d2800142 	mov	x2, #0xa                   	// #10
    5d50:	f94153fb 	ldr	x27, [sp, #672]
    5d54:	f94157fc 	ldr	x28, [sp, #680]
    5d58:	910943ff 	add	sp, sp, #0x250
    5d5c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d60:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5d64:	17fff10b 	b	2190 <buf_put>
    5d68:	f9400456 	ldr	x22, [x2, #8]
    5d6c:	f90143f7 	str	x23, [sp, #640]
    5d70:	f90147f8 	str	x24, [sp, #648]
    5d74:	b4005b16 	cbz	x22, 68d4 <fwp_write+0xd94>
    5d78:	aa1603e0 	mov	x0, x22
    5d7c:	f0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    5d80:	91062021 	add	x1, x1, #0x188
    5d84:	97ffee13 	bl	15d0 <strcmp@plt>
    5d88:	2a0003f5 	mov	w21, w0
    5d8c:	34005fe0 	cbz	w0, 6988 <fwp_write+0xe48>
    5d90:	aa1603e0 	mov	x0, x22
    5d94:	97ffed93 	bl	13e0 <strlen@plt>
    5d98:	aa1603e1 	mov	x1, x22
    5d9c:	aa0003e2 	mov	x2, x0
    5da0:	aa1403e0 	mov	x0, x20
    5da4:	97fff0fb 	bl	2190 <buf_put>
    5da8:	52800403 	mov	w3, #0x20                  	// #32
    5dac:	91001ff5 	add	x21, sp, #0x7
    5db0:	aa1503e1 	mov	x1, x21
    5db4:	aa1403e0 	mov	x0, x20
    5db8:	d2800022 	mov	x2, #0x1                   	// #1
    5dbc:	39001fe3 	strb	w3, [sp, #7]
    5dc0:	97fff0f4 	bl	2190 <buf_put>
    5dc4:	52800f63 	mov	w3, #0x7b                  	// #123
    5dc8:	aa1403e0 	mov	x0, x20
    5dcc:	aa1503e1 	mov	x1, x21
    5dd0:	d2800022 	mov	x2, #0x1                   	// #1
    5dd4:	39001fe3 	strb	w3, [sp, #7]
    5dd8:	97fff0ee 	bl	2190 <buf_put>
    5ddc:	b9401380 	ldr	w0, [x28, #16]
    5de0:	52800018 	mov	w24, #0x0                   	// #0
    5de4:	7100001f 	cmp	w0, #0x0
    5de8:	54003aad 	b.le	653c <fwp_write+0x9fc>
    5dec:	f9014bf9 	str	x25, [sp, #656]
    5df0:	f0000019 	adrp	x25, 8000 <_IO_stdin_used+0x2b0>
    5df4:	9106c339 	add	x25, x25, #0x1b0
    5df8:	f9014ffa 	str	x26, [sp, #664]
    5dfc:	f000001a 	adrp	x26, 8000 <_IO_stdin_used+0x2b0>
    5e00:	9105c35a 	add	x26, x26, #0x170
    5e04:	91002276 	add	x22, x19, #0x8
    5e08:	d2800013 	mov	x19, #0x0                   	// #0
    5e0c:	b5003e93 	cbnz	x19, 65dc <fwp_write+0xa9c>
    5e10:	d37df277 	lsl	x23, x19, #3
    5e14:	34003cb8 	cbz	w24, 65a8 <fwp_write+0xa68>
    5e18:	f9401382 	ldr	x2, [x28, #32]
    5e1c:	aa1403e0 	mov	x0, x20
    5e20:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    5e24:	52800003 	mov	w3, #0x0                   	// #0
    5e28:	f8776842 	ldr	x2, [x2, x23]
    5e2c:	91000673 	add	x19, x19, #0x1
    5e30:	97ffff44 	bl	5b40 <fwp_write>
    5e34:	b9401380 	ldr	w0, [x28, #16]
    5e38:	6b13001f 	cmp	w0, w19
    5e3c:	54fffe8c 	b.gt	5e0c <fwp_write+0x2cc>
    5e40:	f9414bf9 	ldr	x25, [sp, #656]
    5e44:	f9414ffa 	ldr	x26, [sp, #664]
    5e48:	340037b8 	cbz	w24, 653c <fwp_write+0x9fc>
    5e4c:	52800523 	mov	w3, #0x29                  	// #41
    5e50:	aa1503e1 	mov	x1, x21
    5e54:	aa1403e0 	mov	x0, x20
    5e58:	d2800022 	mov	x2, #0x1                   	// #1
    5e5c:	39001fe3 	strb	w3, [sp, #7]
    5e60:	97fff0cc 	bl	2190 <buf_put>
    5e64:	f9413bf5 	ldr	x21, [sp, #624]
    5e68:	f9413ff6 	ldr	x22, [sp, #632]
    5e6c:	f94143f7 	ldr	x23, [sp, #640]
    5e70:	f94147f8 	ldr	x24, [sp, #648]
    5e74:	f94153fb 	ldr	x27, [sp, #672]
    5e78:	f94157fc 	ldr	x28, [sp, #680]
    5e7c:	17ffff5d 	b	5bf0 <fwp_write+0xb0>
    5e80:	b9404855 	ldr	w21, [x2, #72]
    5e84:	aa1403e0 	mov	x0, x20
    5e88:	93407eb6 	sxtw	x22, w21
    5e8c:	91000ac1 	add	x1, x22, #0x2
    5e90:	97fff08c 	bl	20c0 <buf_grow>
    5e94:	a9400281 	ldp	x1, x0, [x20]
    5e98:	528e8603 	mov	w3, #0x7430                	// #29744
    5e9c:	78206823 	strh	w3, [x1, x0]
    5ea0:	8b000022 	add	x2, x1, x0
    5ea4:	710002bf 	cmp	w21, #0x0
    5ea8:	540036cd 	b.le	6580 <fwp_write+0xa40>
    5eac:	110006a3 	add	w3, w21, #0x1
    5eb0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    5eb4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    5eb8:	91000449 	add	x9, x2, #0x1
    5ebc:	8b23c043 	add	x3, x2, w3, sxtw
    5ec0:	f28aaac6 	movk	x6, #0x5556
    5ec4:	f2955568 	movk	x8, #0xaaab
    5ec8:	1400000d 	b	5efc <fwp_write+0x3bc>
    5ecc:	d2800021 	mov	x1, #0x1                   	// #1
    5ed0:	528005a5 	mov	w5, #0x2d                  	// #45
    5ed4:	f100001f 	cmp	x0, #0x0
    5ed8:	9b467e60 	smulh	x0, x19, x6
    5edc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    5ee0:	381ff465 	strb	w5, [x3], #-1
    5ee4:	cb040000 	sub	x0, x0, x4
    5ee8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    5eec:	cb020000 	sub	x0, x0, x2
    5ef0:	8b010013 	add	x19, x0, x1
    5ef4:	eb03013f 	cmp	x9, x3
    5ef8:	54003440 	b.eq	6580 <fwp_write+0xa40>  // b.none
    5efc:	9b467e60 	smulh	x0, x19, x6
    5f00:	937ffe64 	asr	x4, x19, #63
    5f04:	52800605 	mov	w5, #0x30                  	// #48
    5f08:	cb040000 	sub	x0, x0, x4
    5f0c:	8b000400 	add	x0, x0, x0, lsl #1
    5f10:	cb000260 	sub	x0, x19, x0
    5f14:	91000c01 	add	x1, x0, #0x3
    5f18:	9bc87c22 	umulh	x2, x1, x8
    5f1c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    5f20:	8b4204e2 	add	x2, x7, x2, lsr #1
    5f24:	eb020021 	subs	x1, x1, x2
    5f28:	54fffd60 	b.eq	5ed4 <fwp_write+0x394>  // b.none
    5f2c:	f100043f 	cmp	x1, #0x1
    5f30:	54fffce1 	b.ne	5ecc <fwp_write+0x38c>  // b.any
    5f34:	d2800001 	mov	x1, #0x0                   	// #0
    5f38:	52800565 	mov	w5, #0x2b                  	// #43
    5f3c:	17ffffe6 	b	5ed4 <fwp_write+0x394>
    5f40:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    5f44:	f947f400 	ldr	x0, [x0, #4072]
    5f48:	f94127e2 	ldr	x2, [sp, #584]
    5f4c:	f9400001 	ldr	x1, [x0]
    5f50:	eb010042 	subs	x2, x2, x1
    5f54:	d2800001 	mov	x1, #0x0                   	// #0
    5f58:	540023c1 	b.ne	63d0 <fwp_write+0x890>  // b.any
    5f5c:	f9413bf5 	ldr	x21, [sp, #624]
    5f60:	f0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    5f64:	f9413ff6 	ldr	x22, [sp, #632]
    5f68:	aa1403e0 	mov	x0, x20
    5f6c:	91046021 	add	x1, x1, #0x118
    5f70:	d2800102 	mov	x2, #0x8                   	// #8
    5f74:	17ffff77 	b	5d50 <fwp_write+0x210>
    5f78:	aa1403e0 	mov	x0, x20
    5f7c:	f0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    5f80:	d28000c2 	mov	x2, #0x6                   	// #6
    5f84:	9105e021 	add	x1, x1, #0x178
    5f88:	97fff082 	bl	2190 <buf_put>
    5f8c:	d2800015 	mov	x21, #0x0                   	// #0
    5f90:	f9400263 	ldr	x3, [x19]
    5f94:	f240f87f 	tst	x3, #0x7fffffffffffffff
    5f98:	54002c60 	b.eq	6524 <fwp_write+0x9e4>  // b.none
    5f9c:	f9401f82 	ldr	x2, [x28, #56]
    5fa0:	f90143f7 	str	x23, [sp, #640]
    5fa4:	f90147f8 	str	x24, [sp, #648]
    5fa8:	d2800857 	mov	x23, #0x42                  	// #66
    5fac:	f9014bf9 	str	x25, [sp, #656]
    5fb0:	f0000016 	adrp	x22, 8000 <_IO_stdin_used+0x2b0>
    5fb4:	f9014ffa 	str	x26, [sp, #664]
    5fb8:	9105c2d6 	add	x22, x22, #0x170
    5fbc:	d2800038 	mov	x24, #0x1                   	// #1
    5fc0:	f2a18017 	movk	x23, #0xc00, lsl #16
    5fc4:	d2809099 	mov	x25, #0x484                 	// #1156
    5fc8:	b40004a2 	cbz	x2, 605c <fwp_write+0x51c>
    5fcc:	b9400040 	ldr	w0, [x2]
    5fd0:	7100701f 	cmp	w0, #0x1c
    5fd4:	540042c0 	b.eq	682c <fwp_write+0xcec>  // b.none
    5fd8:	71006c1f 	cmp	w0, #0x1b
    5fdc:	54000408 	b.hi	605c <fwp_write+0x51c>  // b.pmore
    5fe0:	9ac02301 	lsl	x1, x24, x0
    5fe4:	ea17003f 	tst	x1, x23
    5fe8:	540036a1 	b.ne	66bc <fwp_write+0xb7c>  // b.any
    5fec:	ea19003f 	tst	x1, x25
    5ff0:	54003521 	b.ne	6694 <fwp_write+0xb54>  // b.any
    5ff4:	d2800424 	mov	x4, #0x21                  	// #33
    5ff8:	ea04003f 	tst	x1, x4
    5ffc:	54000300 	b.eq	605c <fwp_write+0x51c>  // b.none
    6000:	b7f849c3 	tbnz	x3, #63, 6938 <fwp_write+0xdf8>
    6004:	91002261 	add	x1, x19, #0x8
    6008:	8b150021 	add	x1, x1, x21
    600c:	39400021 	ldrb	w1, [x1]
    6010:	7100001f 	cmp	w0, #0x0
    6014:	93401c23 	sxtb	x3, w1
    6018:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    601c:	d503201f 	nop
    6020:	aa1403e0 	mov	x0, x20
    6024:	52800003 	mov	w3, #0x0                   	// #0
    6028:	97fffec6 	bl	5b40 <fwp_write>
    602c:	910006b5 	add	x21, x21, #0x1
    6030:	f9400260 	ldr	x0, [x19]
    6034:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    6038:	eb0002bf 	cmp	x21, x0
    603c:	540026c2 	b.cs	6514 <fwp_write+0x9d4>  // b.hs, b.nlast
    6040:	d2800042 	mov	x2, #0x2                   	// #2
    6044:	aa1603e1 	mov	x1, x22
    6048:	aa1403e0 	mov	x0, x20
    604c:	97fff051 	bl	2190 <buf_put>
    6050:	f9401f82 	ldr	x2, [x28, #56]
    6054:	f9400263 	ldr	x3, [x19]
    6058:	b5fffba2 	cbnz	x2, 5fcc <fwp_write+0x48c>
    605c:	d37df2a0 	lsl	x0, x21, #3
    6060:	b7f83f03 	tbnz	x3, #63, 6840 <fwp_write+0xd00>
    6064:	91002261 	add	x1, x19, #0x8
    6068:	8b000020 	add	x0, x1, x0
    606c:	f9400001 	ldr	x1, [x0]
    6070:	17ffffec 	b	6020 <fwp_write+0x4e0>
    6074:	a9400e62 	ldp	x2, x3, [x19]
    6078:	b7f83ca3 	tbnz	x3, #63, 680c <fwp_write+0xccc>
    607c:	910123f5 	add	x21, sp, #0x48
    6080:	aa1503e0 	mov	x0, x21
    6084:	97ffee87 	bl	1aa0 <fwp_fmt_u128>
    6088:	aa1503e0 	mov	x0, x21
    608c:	97ffecd5 	bl	13e0 <strlen@plt>
    6090:	aa1503e1 	mov	x1, x21
    6094:	aa0003e2 	mov	x2, x0
    6098:	17fffed0 	b	5bd8 <fwp_write+0x98>
    609c:	fd015be8 	str	d8, [sp, #688]
    60a0:	1e270268 	fmov	s8, w19
    60a4:	fd015fe9 	str	d9, [sp, #696]
    60a8:	1e282100 	fcmp	s8, s8
    60ac:	54004d26 	b.vs	6a50 <fwp_write+0xf10>
    60b0:	1e20c101 	fabs	s1, s8
    60b4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    60b8:	1e270000 	fmov	s0, w0
    60bc:	1e202020 	fcmp	s1, s0
    60c0:	54002c0d 	b.le	6640 <fwp_write+0xb00>
    60c4:	1e202118 	fcmpe	s8, #0.0
    60c8:	b0000002 	adrp	x2, 7000 <fwp_main_thread+0x4d0>
    60cc:	91398042 	add	x2, x2, #0xe60
    60d0:	910123f5 	add	x21, sp, #0x48
    60d4:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    60d8:	91032021 	add	x1, x1, #0xc8
    60dc:	aa1503e0 	mov	x0, x21
    60e0:	9a81c041 	csel	x1, x2, x1, gt
    60e4:	97ffed6b 	bl	1690 <strcpy@plt>
    60e8:	aa1503e0 	mov	x0, x21
    60ec:	97ffecbd 	bl	13e0 <strlen@plt>
    60f0:	aa1503e1 	mov	x1, x21
    60f4:	aa0003e2 	mov	x2, x0
    60f8:	aa1403e0 	mov	x0, x20
    60fc:	97fff025 	bl	2190 <buf_put>
    6100:	f9413bf5 	ldr	x21, [sp, #624]
    6104:	f9413ff6 	ldr	x22, [sp, #632]
    6108:	f94153fb 	ldr	x27, [sp, #672]
    610c:	f94157fc 	ldr	x28, [sp, #680]
    6110:	fd415be8 	ldr	d8, [sp, #688]
    6114:	fd415fe9 	ldr	d9, [sp, #696]
    6118:	17fffeb6 	b	5bf0 <fwp_write+0xb0>
    611c:	f9400276 	ldr	x22, [x19]
    6120:	34002e03 	cbz	w3, 66e0 <fwp_write+0xba0>
    6124:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    6128:	f947f400 	ldr	x0, [x0, #4072]
    612c:	f94127e2 	ldr	x2, [sp, #584]
    6130:	f9400001 	ldr	x1, [x0]
    6134:	eb010042 	subs	x2, x2, x1
    6138:	d2800001 	mov	x1, #0x0                   	// #0
    613c:	540014a1 	b.ne	63d0 <fwp_write+0x890>  // b.any
    6140:	aa1603e2 	mov	x2, x22
    6144:	91002261 	add	x1, x19, #0x8
    6148:	f9413bf5 	ldr	x21, [sp, #624]
    614c:	aa1403e0 	mov	x0, x20
    6150:	f9413ff6 	ldr	x22, [sp, #632]
    6154:	17fffeff 	b	5d50 <fwp_write+0x210>
    6158:	fd015be8 	str	d8, [sp, #688]
    615c:	9e670268 	fmov	d8, x19
    6160:	fd015fe9 	str	d9, [sp, #696]
    6164:	1e682100 	fcmp	d8, d8
    6168:	54004746 	b.vs	6a50 <fwp_write+0xf10>
    616c:	1e60c101 	fabs	d1, d8
    6170:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    6174:	9e670000 	fmov	d0, x0
    6178:	910123f5 	add	x21, sp, #0x48
    617c:	52800033 	mov	w19, #0x1                   	// #1
    6180:	1e602020 	fcmp	d1, d0
    6184:	540001ad 	b.le	61b8 <fwp_write+0x678>
    6188:	1e602118 	fcmpe	d8, #0.0
    618c:	b0000002 	adrp	x2, 7000 <fwp_main_thread+0x4d0>
    6190:	91398042 	add	x2, x2, #0xe60
    6194:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    6198:	91032021 	add	x1, x1, #0xc8
    619c:	aa1503e0 	mov	x0, x21
    61a0:	9a81c041 	csel	x1, x2, x1, gt
    61a4:	97ffed3b 	bl	1690 <strcpy@plt>
    61a8:	17ffffd0 	b	60e8 <fwp_write+0x5a8>
    61ac:	11000673 	add	w19, w19, #0x1
    61b0:	71004a7f 	cmp	w19, #0x12
    61b4:	54003860 	b.eq	68c0 <fwp_write+0xd80>  // b.none
    61b8:	1e604100 	fmov	d0, d8
    61bc:	2a1303e1 	mov	w1, w19
    61c0:	aa1503e0 	mov	x0, x21
    61c4:	97fff088 	bl	23e4 <fwp_format_g.constprop.0>
    61c8:	aa1503e0 	mov	x0, x21
    61cc:	d2800001 	mov	x1, #0x0                   	// #0
    61d0:	97ffec98 	bl	1430 <strtod@plt>
    61d4:	1e602100 	fcmp	d8, d0
    61d8:	54fffea1 	b.ne	61ac <fwp_write+0x66c>  // b.any
    61dc:	aa1503e0 	mov	x0, x21
    61e0:	97fff025 	bl	2274 <fwp_finish_float>
    61e4:	17ffffc1 	b	60e8 <fwp_write+0x5a8>
    61e8:	a9400e62 	ldp	x2, x3, [x19]
    61ec:	910123f3 	add	x19, sp, #0x48
    61f0:	aa1303e0 	mov	x0, x19
    61f4:	97ffee2b 	bl	1aa0 <fwp_fmt_u128>
    61f8:	17fffe74 	b	5bc8 <fwp_write+0x88>
    61fc:	f90143f7 	str	x23, [sp, #640]
    6200:	f90147f8 	str	x24, [sp, #648]
    6204:	2a1303f8 	mov	w24, w19
    6208:	f9014bf9 	str	x25, [sp, #656]
    620c:	f9014ffa 	str	x26, [sp, #664]
    6210:	f13ffe7f 	cmp	x19, #0xfff
    6214:	54000049 	b.ls	621c <fwp_write+0x6dc>  // b.plast
    6218:	b9400278 	ldr	w24, [x19]
    621c:	f9400f80 	ldr	x0, [x28, #24]
    6220:	2a1803f5 	mov	w21, w24
    6224:	d37d7f18 	ubfiz	x24, x24, #3, #32
    6228:	d37ef6b9 	lsl	x25, x21, #2
    622c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    6230:	aa1603e0 	mov	x0, x22
    6234:	97ffec6b 	bl	13e0 <strlen@plt>
    6238:	aa1603e1 	mov	x1, x22
    623c:	aa0003e2 	mov	x2, x0
    6240:	aa1403e0 	mov	x0, x20
    6244:	97ffefd3 	bl	2190 <buf_put>
    6248:	f9401780 	ldr	x0, [x28, #40]
    624c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    6250:	7100001f 	cmp	w0, #0x0
    6254:	5400068d 	b.le	6324 <fwp_write+0x7e4>
    6258:	91002276 	add	x22, x19, #0x8
    625c:	91001ff5 	add	x21, sp, #0x7
    6260:	d280001b 	mov	x27, #0x0                   	// #0
    6264:	5280041a 	mov	w26, #0x20                  	// #32
    6268:	f9401b80 	ldr	x0, [x28, #48]
    626c:	aa1503e1 	mov	x1, x21
    6270:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    6274:	d2800022 	mov	x2, #0x1                   	// #1
    6278:	f8786803 	ldr	x3, [x0, x24]
    627c:	aa1403e0 	mov	x0, x20
    6280:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    6284:	39001ffa 	strb	w26, [sp, #7]
    6288:	97ffefc2 	bl	2190 <buf_put>
    628c:	f13ffeff 	cmp	x23, #0xfff
    6290:	b9400261 	ldr	w1, [x19]
    6294:	1a9f97e0 	cset	w0, hi	// hi = pmore
    6298:	7100383f 	cmp	w1, #0xe
    629c:	54000160 	b.eq	62c8 <fwp_write+0x788>  // b.none
    62a0:	7100403f 	cmp	w1, #0x10
    62a4:	54001a60 	b.eq	65f0 <fwp_write+0xab0>  // b.none
    62a8:	7100283f 	cmp	w1, #0xa
    62ac:	54002aa0 	b.eq	6800 <fwp_write+0xcc0>  // b.none
    62b0:	540014ac 	b.gt	6544 <fwp_write+0xa04>
    62b4:	71000c3f 	cmp	w1, #0x3
    62b8:	540029ac 	b.gt	67ec <fwp_write+0xcac>
    62bc:	d37ffee0 	lsr	x0, x23, #63
    62c0:	37f814a1 	tbnz	w1, #31, 6554 <fwp_write+0xa14>
    62c4:	d503201f 	nop
    62c8:	34001460 	cbz	w0, 6554 <fwp_write+0xa14>
    62cc:	52800503 	mov	w3, #0x28                  	// #40
    62d0:	aa1503e1 	mov	x1, x21
    62d4:	aa1403e0 	mov	x0, x20
    62d8:	d2800022 	mov	x2, #0x1                   	// #1
    62dc:	39001fe3 	strb	w3, [sp, #7]
    62e0:	97ffefac 	bl	2190 <buf_put>
    62e4:	aa1303e2 	mov	x2, x19
    62e8:	aa1703e1 	mov	x1, x23
    62ec:	aa1403e0 	mov	x0, x20
    62f0:	52800003 	mov	w3, #0x0                   	// #0
    62f4:	97fffe13 	bl	5b40 <fwp_write>
    62f8:	52800523 	mov	w3, #0x29                  	// #41
    62fc:	aa1503e1 	mov	x1, x21
    6300:	aa1403e0 	mov	x0, x20
    6304:	d2800022 	mov	x2, #0x1                   	// #1
    6308:	39001fe3 	strb	w3, [sp, #7]
    630c:	97ffefa1 	bl	2190 <buf_put>
    6310:	f9401780 	ldr	x0, [x28, #40]
    6314:	9100077b 	add	x27, x27, #0x1
    6318:	b8796800 	ldr	w0, [x0, x25]
    631c:	6b1b001f 	cmp	w0, w27
    6320:	54fffa4c 	b.gt	6268 <fwp_write+0x728>
    6324:	f9413bf5 	ldr	x21, [sp, #624]
    6328:	f9413ff6 	ldr	x22, [sp, #632]
    632c:	f94143f7 	ldr	x23, [sp, #640]
    6330:	f94147f8 	ldr	x24, [sp, #648]
    6334:	f9414bf9 	ldr	x25, [sp, #656]
    6338:	f9414ffa 	ldr	x26, [sp, #664]
    633c:	f94153fb 	ldr	x27, [sp, #672]
    6340:	f94157fc 	ldr	x28, [sp, #680]
    6344:	17fffe2b 	b	5bf0 <fwp_write+0xb0>
    6348:	52800783 	mov	w3, #0x3c                  	// #60
    634c:	91001ff3 	add	x19, sp, #0x7
    6350:	aa1303e1 	mov	x1, x19
    6354:	d2800022 	mov	x2, #0x1                   	// #1
    6358:	aa1403e0 	mov	x0, x20
    635c:	39001fe3 	strb	w3, [sp, #7]
    6360:	97ffef8c 	bl	2190 <buf_put>
    6364:	f9400795 	ldr	x21, [x28, #8]
    6368:	aa1503e0 	mov	x0, x21
    636c:	97ffec1d 	bl	13e0 <strlen@plt>
    6370:	aa1503e1 	mov	x1, x21
    6374:	aa0003e2 	mov	x2, x0
    6378:	aa1403e0 	mov	x0, x20
    637c:	97ffef85 	bl	2190 <buf_put>
    6380:	528007c3 	mov	w3, #0x3e                  	// #62
    6384:	aa1303e1 	mov	x1, x19
    6388:	aa1403e0 	mov	x0, x20
    638c:	d2800022 	mov	x2, #0x1                   	// #1
    6390:	39001fe3 	strb	w3, [sp, #7]
    6394:	17fffe12 	b	5bdc <fwp_write+0x9c>
    6398:	f100067f 	cmp	x19, #0x1
    639c:	540025a0 	b.eq	6850 <fwp_write+0xd10>  // b.none
    63a0:	b100067f 	cmn	x19, #0x1
    63a4:	54002bc0 	b.eq	691c <fwp_write+0xddc>  // b.none
    63a8:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    63ac:	91034021 	add	x1, x1, #0xd0
    63b0:	d2800022 	mov	x2, #0x1                   	// #1
    63b4:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    63b8:	f947f400 	ldr	x0, [x0, #4072]
    63bc:	f94127e4 	ldr	x4, [sp, #584]
    63c0:	f9400003 	ldr	x3, [x0]
    63c4:	eb030084 	subs	x4, x4, x3
    63c8:	d2800003 	mov	x3, #0x0                   	// #0
    63cc:	54ffebe0 	b.eq	6148 <fwp_write+0x608>  // b.none
    63d0:	f90143f7 	str	x23, [sp, #640]
    63d4:	f90147f8 	str	x24, [sp, #648]
    63d8:	f9014bf9 	str	x25, [sp, #656]
    63dc:	f9014ffa 	str	x26, [sp, #664]
    63e0:	fd015be8 	str	d8, [sp, #688]
    63e4:	fd015fe9 	str	d9, [sp, #696]
    63e8:	97ffec5a 	bl	1550 <__stack_chk_fail@plt>
    63ec:	52800b63 	mov	w3, #0x5b                  	// #91
    63f0:	91001ff5 	add	x21, sp, #0x7
    63f4:	aa1503e1 	mov	x1, x21
    63f8:	aa1403e0 	mov	x0, x20
    63fc:	d2800022 	mov	x2, #0x1                   	// #1
    6400:	d0000016 	adrp	x22, 8000 <_IO_stdin_used+0x2b0>
    6404:	9105c2d6 	add	x22, x22, #0x170
    6408:	39001fe3 	strb	w3, [sp, #7]
    640c:	97ffef61 	bl	2190 <buf_put>
    6410:	b4000273 	cbz	x19, 645c <fwp_write+0x91c>
    6414:	f9400661 	ldr	x1, [x19, #8]
    6418:	aa1403e0 	mov	x0, x20
    641c:	f9401f82 	ldr	x2, [x28, #56]
    6420:	52800003 	mov	w3, #0x0                   	// #0
    6424:	97fffdc7 	bl	5b40 <fwp_write>
    6428:	f9400a73 	ldr	x19, [x19, #16]
    642c:	b4000193 	cbz	x19, 645c <fwp_write+0x91c>
    6430:	aa1603e1 	mov	x1, x22
    6434:	aa1403e0 	mov	x0, x20
    6438:	d2800042 	mov	x2, #0x2                   	// #2
    643c:	97ffef55 	bl	2190 <buf_put>
    6440:	f9400661 	ldr	x1, [x19, #8]
    6444:	aa1403e0 	mov	x0, x20
    6448:	f9401f82 	ldr	x2, [x28, #56]
    644c:	52800003 	mov	w3, #0x0                   	// #0
    6450:	97fffdbc 	bl	5b40 <fwp_write>
    6454:	f9400a73 	ldr	x19, [x19, #16]
    6458:	b5fffed3 	cbnz	x19, 6430 <fwp_write+0x8f0>
    645c:	52800ba3 	mov	w3, #0x5d                  	// #93
    6460:	aa1503e1 	mov	x1, x21
    6464:	aa1403e0 	mov	x0, x20
    6468:	d2800022 	mov	x2, #0x1                   	// #1
    646c:	39001fe3 	strb	w3, [sp, #7]
    6470:	17fffddb 	b	5bdc <fwp_write+0x9c>
    6474:	aa1403e0 	mov	x0, x20
    6478:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    647c:	d28000c2 	mov	x2, #0x6                   	// #6
    6480:	91058021 	add	x1, x1, #0x160
    6484:	97ffef43 	bl	2190 <buf_put>
    6488:	f9400260 	ldr	x0, [x19]
    648c:	b40004c0 	cbz	x0, 6524 <fwp_write+0x9e4>
    6490:	910123f5 	add	x21, sp, #0x48
    6494:	91002276 	add	x22, x19, #0x8
    6498:	f90143f7 	str	x23, [sp, #640]
    649c:	d2800017 	mov	x23, #0x0                   	// #0
    64a0:	f90147f8 	str	x24, [sp, #648]
    64a4:	d0000018 	adrp	x24, 8000 <_IO_stdin_used+0x2b0>
    64a8:	9105a318 	add	x24, x24, #0x168
    64ac:	f9014bf9 	str	x25, [sp, #656]
    64b0:	d0000019 	adrp	x25, 8000 <_IO_stdin_used+0x2b0>
    64b4:	9105c339 	add	x25, x25, #0x170
    64b8:	f9014ffa 	str	x26, [sp, #664]
    64bc:	14000005 	b	64d0 <fwp_write+0x990>
    64c0:	aa1903e1 	mov	x1, x25
    64c4:	aa1403e0 	mov	x0, x20
    64c8:	d2800042 	mov	x2, #0x2                   	// #2
    64cc:	97ffef31 	bl	2190 <buf_put>
    64d0:	38776ac5 	ldrb	w5, [x22, x23]
    64d4:	d2804003 	mov	x3, #0x200                 	// #512
    64d8:	aa1803e4 	mov	x4, x24
    64dc:	aa0303e1 	mov	x1, x3
    64e0:	52800042 	mov	w2, #0x2                   	// #2
    64e4:	aa1503e0 	mov	x0, x21
    64e8:	910006f7 	add	x23, x23, #0x1
    64ec:	97ffebf5 	bl	14c0 <__snprintf_chk@plt>
    64f0:	aa1503e0 	mov	x0, x21
    64f4:	97ffebbb 	bl	13e0 <strlen@plt>
    64f8:	aa1503e1 	mov	x1, x21
    64fc:	aa0003e2 	mov	x2, x0
    6500:	aa1403e0 	mov	x0, x20
    6504:	97ffef23 	bl	2190 <buf_put>
    6508:	f9400260 	ldr	x0, [x19]
    650c:	eb17001f 	cmp	x0, x23
    6510:	54fffd88 	b.hi	64c0 <fwp_write+0x980>  // b.pmore
    6514:	f94143f7 	ldr	x23, [sp, #640]
    6518:	f94147f8 	ldr	x24, [sp, #648]
    651c:	f9414bf9 	ldr	x25, [sp, #656]
    6520:	f9414ffa 	ldr	x26, [sp, #664]
    6524:	52800ba3 	mov	w3, #0x5d                  	// #93
    6528:	aa1403e0 	mov	x0, x20
    652c:	91001fe1 	add	x1, sp, #0x7
    6530:	d2800022 	mov	x2, #0x1                   	// #1
    6534:	39001fe3 	strb	w3, [sp, #7]
    6538:	17fffda9 	b	5bdc <fwp_write+0x9c>
    653c:	52800fa3 	mov	w3, #0x7d                  	// #125
    6540:	17fffe44 	b	5e50 <fwp_write+0x310>
    6544:	f10002ff 	cmp	x23, #0x0
    6548:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    654c:	71002c3f 	cmp	w1, #0xb
    6550:	54ffebc0 	b.eq	62c8 <fwp_write+0x788>  // b.none
    6554:	aa1303e2 	mov	x2, x19
    6558:	aa1703e1 	mov	x1, x23
    655c:	aa1403e0 	mov	x0, x20
    6560:	52800003 	mov	w3, #0x0                   	// #0
    6564:	97fffd77 	bl	5b40 <fwp_write>
    6568:	17ffff6a 	b	6310 <fwp_write+0x7d0>
    656c:	aa1403e0 	mov	x0, x20
    6570:	91001fe1 	add	x1, sp, #0x7
    6574:	52800fa3 	mov	w3, #0x7d                  	// #125
    6578:	d2800022 	mov	x2, #0x1                   	// #1
    657c:	17fffe38 	b	5e5c <fwp_write+0x31c>
    6580:	a9400281 	ldp	x1, x0, [x20]
    6584:	91000800 	add	x0, x0, #0x2
    6588:	8b160000 	add	x0, x0, x22
    658c:	f9000680 	str	x0, [x20, #8]
    6590:	3820683f 	strb	wzr, [x1, x0]
    6594:	f9413bf5 	ldr	x21, [sp, #624]
    6598:	f9413ff6 	ldr	x22, [sp, #632]
    659c:	f94153fb 	ldr	x27, [sp, #672]
    65a0:	f94157fc 	ldr	x28, [sp, #680]
    65a4:	17fffd93 	b	5bf0 <fwp_write+0xb0>
    65a8:	f9400f80 	ldr	x0, [x28, #24]
    65ac:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    65b0:	aa1b03e0 	mov	x0, x27
    65b4:	97ffeb8b 	bl	13e0 <strlen@plt>
    65b8:	aa1b03e1 	mov	x1, x27
    65bc:	aa0003e2 	mov	x2, x0
    65c0:	aa1403e0 	mov	x0, x20
    65c4:	97ffeef3 	bl	2190 <buf_put>
    65c8:	aa1903e1 	mov	x1, x25
    65cc:	aa1403e0 	mov	x0, x20
    65d0:	d2800062 	mov	x2, #0x3                   	// #3
    65d4:	97ffeeef 	bl	2190 <buf_put>
    65d8:	17fffe10 	b	5e18 <fwp_write+0x2d8>
    65dc:	aa1a03e1 	mov	x1, x26
    65e0:	aa1403e0 	mov	x0, x20
    65e4:	d2800042 	mov	x2, #0x2                   	// #2
    65e8:	97ffeeea 	bl	2190 <buf_put>
    65ec:	17fffe09 	b	5e10 <fwp_write+0x2d0>
    65f0:	f9400660 	ldr	x0, [x19, #8]
    65f4:	b4fffb00 	cbz	x0, 6554 <fwp_write+0xa14>
    65f8:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    65fc:	91062021 	add	x1, x1, #0x188
    6600:	97ffebf4 	bl	15d0 <strcmp@plt>
    6604:	7100001f 	cmp	w0, #0x0
    6608:	1a9f07e0 	cset	w0, ne	// ne = any
    660c:	17ffff2f 	b	62c8 <fwp_write+0x788>
    6610:	aa1403e0 	mov	x0, x20
    6614:	d2800042 	mov	x2, #0x2                   	// #2
    6618:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    661c:	91060021 	add	x1, x1, #0x180
    6620:	97ffeedc 	bl	2190 <buf_put>
    6624:	91004261 	add	x1, x19, #0x10
    6628:	aa1403e0 	mov	x0, x20
    662c:	f9402382 	ldr	x2, [x28, #64]
    6630:	52800003 	mov	w3, #0x0                   	// #0
    6634:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    6638:	97fffd42 	bl	5b40 <fwp_write>
    663c:	17fffd9c 	b	5cac <fwp_write+0x16c>
    6640:	1e22c109 	fcvt	d9, s8
    6644:	910123f5 	add	x21, sp, #0x48
    6648:	52800033 	mov	w19, #0x1                   	// #1
    664c:	d503201f 	nop
    6650:	1e604120 	fmov	d0, d9
    6654:	2a1303e1 	mov	w1, w19
    6658:	aa1503e0 	mov	x0, x21
    665c:	97ffef62 	bl	23e4 <fwp_format_g.constprop.0>
    6660:	aa1503e0 	mov	x0, x21
    6664:	d2800001 	mov	x1, #0x0                   	// #0
    6668:	97ffebe6 	bl	1600 <strtof@plt>
    666c:	1e202100 	fcmp	s8, s0
    6670:	54ffdb60 	b.eq	61dc <fwp_write+0x69c>  // b.none
    6674:	11000673 	add	w19, w19, #0x1
    6678:	71002a7f 	cmp	w19, #0xa
    667c:	54fffea1 	b.ne	6650 <fwp_write+0xb10>  // b.any
    6680:	1e604120 	fmov	d0, d9
    6684:	aa1503e0 	mov	x0, x21
    6688:	52800121 	mov	w1, #0x9                   	// #9
    668c:	97ffef56 	bl	23e4 <fwp_format_g.constprop.0>
    6690:	17fffed3 	b	61dc <fwp_write+0x69c>
    6694:	d37ef6a1 	lsl	x1, x21, #2
    6698:	b7f81563 	tbnz	x3, #63, 6944 <fwp_write+0xe04>
    669c:	91002263 	add	x3, x19, #0x8
    66a0:	8b010061 	add	x1, x3, x1
    66a4:	b9400023 	ldr	w3, [x1]
    66a8:	7100081f 	cmp	w0, #0x2
    66ac:	2a0303e1 	mov	w1, w3
    66b0:	93407c63 	sxtw	x3, w3
    66b4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    66b8:	17fffe5a 	b	6020 <fwp_write+0x4e0>
    66bc:	d37ffaa1 	lsl	x1, x21, #1
    66c0:	b7f81363 	tbnz	x3, #63, 692c <fwp_write+0xdec>
    66c4:	91002263 	add	x3, x19, #0x8
    66c8:	8b010061 	add	x1, x3, x1
    66cc:	79400021 	ldrh	w1, [x1]
    66d0:	7100041f 	cmp	w0, #0x1
    66d4:	93403c23 	sxth	x3, w1
    66d8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    66dc:	17fffe51 	b	6020 <fwp_write+0x4e0>
    66e0:	52800443 	mov	w3, #0x22                  	// #34
    66e4:	91001ff5 	add	x21, sp, #0x7
    66e8:	91002273 	add	x19, x19, #0x8
    66ec:	aa1503e1 	mov	x1, x21
    66f0:	aa1403e0 	mov	x0, x20
    66f4:	d2800022 	mov	x2, #0x1                   	// #1
    66f8:	39001fe3 	strb	w3, [sp, #7]
    66fc:	f90143f7 	str	x23, [sp, #640]
    6700:	8b160277 	add	x23, x19, x22
    6704:	f90147f8 	str	x24, [sp, #648]
    6708:	97ffeea2 	bl	2190 <buf_put>
    670c:	b4000696 	cbz	x22, 67dc <fwp_write+0xc9c>
    6710:	d0000018 	adrp	x24, 8000 <_IO_stdin_used+0x2b0>
    6714:	9104c318 	add	x24, x24, #0x130
    6718:	f9014bf9 	str	x25, [sp, #656]
    671c:	d0000019 	adrp	x25, 8000 <_IO_stdin_used+0x2b0>
    6720:	91054339 	add	x25, x25, #0x150
    6724:	f9014ffa 	str	x26, [sp, #664]
    6728:	1400000d 	b	675c <fwp_write+0xc1c>
    672c:	710024bf 	cmp	w5, #0x9
    6730:	54000460 	b.eq	67bc <fwp_write+0xc7c>  // b.none
    6734:	710028bf 	cmp	w5, #0xa
    6738:	54000a61 	b.ne	6884 <fwp_write+0xd44>  // b.any
    673c:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    6740:	aa1403e0 	mov	x0, x20
    6744:	91050021 	add	x1, x1, #0x140
    6748:	d2800042 	mov	x2, #0x2                   	// #2
    674c:	97ffee91 	bl	2190 <buf_put>
    6750:	91000673 	add	x19, x19, #0x1
    6754:	eb17027f 	cmp	x19, x23
    6758:	540003e0 	b.eq	67d4 <fwp_write+0xc94>  // b.none
    675c:	39400265 	ldrb	w5, [x19]
    6760:	710034bf 	cmp	w5, #0xd
    6764:	54000180 	b.eq	6794 <fwp_write+0xc54>  // b.none
    6768:	54fffe29 	b.ls	672c <fwp_write+0xbec>  // b.plast
    676c:	710088bf 	cmp	w5, #0x22
    6770:	540001c0 	b.eq	67a8 <fwp_write+0xc68>  // b.none
    6774:	710170bf 	cmp	w5, #0x5c
    6778:	54000741 	b.ne	6860 <fwp_write+0xd20>  // b.any
    677c:	aa1403e0 	mov	x0, x20
    6780:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    6784:	d2800042 	mov	x2, #0x2                   	// #2
    6788:	9104e021 	add	x1, x1, #0x138
    678c:	97ffee81 	bl	2190 <buf_put>
    6790:	17fffff0 	b	6750 <fwp_write+0xc10>
    6794:	aa1903e1 	mov	x1, x25
    6798:	aa1403e0 	mov	x0, x20
    679c:	d2800042 	mov	x2, #0x2                   	// #2
    67a0:	97ffee7c 	bl	2190 <buf_put>
    67a4:	17ffffeb 	b	6750 <fwp_write+0xc10>
    67a8:	aa1803e1 	mov	x1, x24
    67ac:	aa1403e0 	mov	x0, x20
    67b0:	d2800042 	mov	x2, #0x2                   	// #2
    67b4:	97ffee77 	bl	2190 <buf_put>
    67b8:	17ffffe6 	b	6750 <fwp_write+0xc10>
    67bc:	aa1403e0 	mov	x0, x20
    67c0:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    67c4:	d2800042 	mov	x2, #0x2                   	// #2
    67c8:	91052021 	add	x1, x1, #0x148
    67cc:	97ffee71 	bl	2190 <buf_put>
    67d0:	17ffffe0 	b	6750 <fwp_write+0xc10>
    67d4:	f9414bf9 	ldr	x25, [sp, #656]
    67d8:	f9414ffa 	ldr	x26, [sp, #664]
    67dc:	aa1503e1 	mov	x1, x21
    67e0:	aa1403e0 	mov	x0, x20
    67e4:	52800443 	mov	w3, #0x22                  	// #34
    67e8:	17fffd9c 	b	5e58 <fwp_write+0x318>
    67ec:	7100103f 	cmp	w1, #0x4
    67f0:	54ffeb21 	b.ne	6554 <fwp_write+0xa14>  // b.any
    67f4:	f94006e0 	ldr	x0, [x23, #8]
    67f8:	d37ffc00 	lsr	x0, x0, #63
    67fc:	17fffeb3 	b	62c8 <fwp_write+0x788>
    6800:	710002ff 	cmp	w23, #0x0
    6804:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    6808:	17fffeb0 	b	62c8 <fwp_write+0x788>
    680c:	528005a1 	mov	w1, #0x2d                  	// #45
    6810:	eb0203e2 	negs	x2, x2
    6814:	da0303e3 	ngc	x3, x3
    6818:	910127e0 	add	x0, sp, #0x49
    681c:	910123f5 	add	x21, sp, #0x48
    6820:	390123e1 	strb	w1, [sp, #72]
    6824:	97ffec9f 	bl	1aa0 <fwp_fmt_u128>
    6828:	17fffe18 	b	6088 <fwp_write+0x548>
    682c:	d37ceea1 	lsl	x1, x21, #4
    6830:	b7f810a3 	tbnz	x3, #63, 6a44 <fwp_write+0xf04>
    6834:	91002260 	add	x0, x19, #0x8
    6838:	8b010001 	add	x1, x0, x1
    683c:	17fffdf9 	b	6020 <fwp_write+0x4e0>
    6840:	f9400a61 	ldr	x1, [x19, #16]
    6844:	8b010000 	add	x0, x0, x1
    6848:	f9400001 	ldr	x1, [x0]
    684c:	17fffdf5 	b	6020 <fwp_write+0x4e0>
    6850:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    6854:	d2800042 	mov	x2, #0x2                   	// #2
    6858:	91036021 	add	x1, x1, #0xd8
    685c:	17fffed6 	b	63b4 <fwp_write+0x874>
    6860:	7101fcbf 	cmp	w5, #0x7f
    6864:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    6868:	540000e9 	b.ls	6884 <fwp_write+0xd44>  // b.plast
    686c:	aa1503e1 	mov	x1, x21
    6870:	aa1403e0 	mov	x0, x20
    6874:	d2800022 	mov	x2, #0x1                   	// #1
    6878:	39001fe5 	strb	w5, [sp, #7]
    687c:	97ffee45 	bl	2190 <buf_put>
    6880:	17ffffb4 	b	6750 <fwp_write+0xc10>
    6884:	d2800203 	mov	x3, #0x10                  	// #16
    6888:	d0000004 	adrp	x4, 8000 <_IO_stdin_used+0x2b0>
    688c:	aa0303e1 	mov	x1, x3
    6890:	91056084 	add	x4, x4, #0x158
    6894:	910123f6 	add	x22, sp, #0x48
    6898:	52800042 	mov	w2, #0x2                   	// #2
    689c:	aa1603e0 	mov	x0, x22
    68a0:	97ffeb08 	bl	14c0 <__snprintf_chk@plt>
    68a4:	aa1603e0 	mov	x0, x22
    68a8:	97ffeace 	bl	13e0 <strlen@plt>
    68ac:	aa1603e1 	mov	x1, x22
    68b0:	aa0003e2 	mov	x2, x0
    68b4:	aa1403e0 	mov	x0, x20
    68b8:	97ffee36 	bl	2190 <buf_put>
    68bc:	17ffffa5 	b	6750 <fwp_write+0xc10>
    68c0:	1e604100 	fmov	d0, d8
    68c4:	aa1503e0 	mov	x0, x21
    68c8:	52800221 	mov	w1, #0x11                  	// #17
    68cc:	97ffeec6 	bl	23e4 <fwp_format_g.constprop.0>
    68d0:	17fffe43 	b	61dc <fwp_write+0x69c>
    68d4:	b9401040 	ldr	w0, [x2, #16]
    68d8:	350003c0 	cbnz	w0, 6950 <fwp_write+0xe10>
    68dc:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    68e0:	f947f400 	ldr	x0, [x0, #4072]
    68e4:	f94127e2 	ldr	x2, [sp, #584]
    68e8:	f9400001 	ldr	x1, [x0]
    68ec:	eb010042 	subs	x2, x2, x1
    68f0:	d2800001 	mov	x1, #0x0                   	// #0
    68f4:	54ffd721 	b.ne	63d8 <fwp_write+0x898>  // b.any
    68f8:	f9413bf5 	ldr	x21, [sp, #624]
    68fc:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    6900:	f9413ff6 	ldr	x22, [sp, #632]
    6904:	aa1403e0 	mov	x0, x20
    6908:	f94143f7 	ldr	x23, [sp, #640]
    690c:	9106a021 	add	x1, x1, #0x1a8
    6910:	f94147f8 	ldr	x24, [sp, #648]
    6914:	d2800042 	mov	x2, #0x2                   	// #2
    6918:	17fffd0e 	b	5d50 <fwp_write+0x210>
    691c:	d0000001 	adrp	x1, 8000 <_IO_stdin_used+0x2b0>
    6920:	d2800042 	mov	x2, #0x2                   	// #2
    6924:	91038021 	add	x1, x1, #0xe0
    6928:	17fffea3 	b	63b4 <fwp_write+0x874>
    692c:	f9400a63 	ldr	x3, [x19, #16]
    6930:	8b030021 	add	x1, x1, x3
    6934:	17ffff66 	b	66cc <fwp_write+0xb8c>
    6938:	f9400a61 	ldr	x1, [x19, #16]
    693c:	8b0102a1 	add	x1, x21, x1
    6940:	17fffdb3 	b	600c <fwp_write+0x4cc>
    6944:	f9400a63 	ldr	x3, [x19, #16]
    6948:	8b030021 	add	x1, x1, x3
    694c:	17ffff56 	b	66a4 <fwp_write+0xb64>
    6950:	b9404840 	ldr	w0, [x2, #72]
    6954:	91001ff5 	add	x21, sp, #0x7
    6958:	34ffa360 	cbz	w0, 5dc4 <fwp_write+0x284>
    695c:	52800503 	mov	w3, #0x28                  	// #40
    6960:	aa1403e0 	mov	x0, x20
    6964:	aa1503e1 	mov	x1, x21
    6968:	d2800022 	mov	x2, #0x1                   	// #1
    696c:	39001fe3 	strb	w3, [sp, #7]
    6970:	97ffee08 	bl	2190 <buf_put>
    6974:	b9401380 	ldr	w0, [x28, #16]
    6978:	52800038 	mov	w24, #0x1                   	// #1
    697c:	7100001f 	cmp	w0, #0x0
    6980:	54ffa36c 	b.gt	5dec <fwp_write+0x2ac>
    6984:	17fffd32 	b	5e4c <fwp_write+0x30c>
    6988:	f9014bf9 	str	x25, [sp, #656]
    698c:	b00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x15a68>
    6990:	f9014ffa 	str	x26, [sp, #664]
    6994:	f9400676 	ldr	x22, [x19, #8]
    6998:	912ae333 	add	x19, x25, #0xab8
    699c:	91002273 	add	x19, x19, #0x8
    69a0:	937ffed8 	asr	x24, x22, #63
    69a4:	aa1802c0 	orr	x0, x22, x24
    69a8:	b5000320 	cbnz	x0, 6a0c <fwp_write+0xecc>
    69ac:	110006b5 	add	w21, w21, #0x1
    69b0:	710016bf 	cmp	w21, #0x5
    69b4:	54ffffc1 	b.ne	69ac <fwp_write+0xe6c>  // b.any
    69b8:	b7f80578 	tbnz	x24, #63, 6a64 <fwp_write+0xf24>
    69bc:	910023f3 	add	x19, sp, #0x8
    69c0:	aa1603e2 	mov	x2, x22
    69c4:	aa1303e0 	mov	x0, x19
    69c8:	d2800003 	mov	x3, #0x0                   	// #0
    69cc:	97ffec35 	bl	1aa0 <fwp_fmt_u128>
    69d0:	910123f5 	add	x21, sp, #0x48
    69d4:	d0000003 	adrp	x3, 8000 <_IO_stdin_used+0x2b0>
    69d8:	aa1303e4 	mov	x4, x19
    69dc:	aa1503e0 	mov	x0, x21
    69e0:	91068063 	add	x3, x3, #0x1a0
    69e4:	d2804002 	mov	x2, #0x200                 	// #512
    69e8:	52800041 	mov	w1, #0x2                   	// #2
    69ec:	97ffea81 	bl	13f0 <__sprintf_chk@plt>
    69f0:	aa1503e0 	mov	x0, x21
    69f4:	97ffea7b 	bl	13e0 <strlen@plt>
    69f8:	aa1503e1 	mov	x1, x21
    69fc:	aa0003e2 	mov	x2, x0
    6a00:	aa1403e0 	mov	x0, x20
    6a04:	97ffede3 	bl	2190 <buf_put>
    6a08:	17fffe47 	b	6324 <fwp_write+0x7e4>
    6a0c:	f9400277 	ldr	x23, [x19]
    6a10:	aa1603e0 	mov	x0, x22
    6a14:	aa1803e1 	mov	x1, x24
    6a18:	aa1703e2 	mov	x2, x23
    6a1c:	937ffefa 	asr	x26, x23, #63
    6a20:	aa1a03e3 	mov	x3, x26
    6a24:	940003e3 	bl	79b0 <__modti3>
    6a28:	aa010000 	orr	x0, x0, x1
    6a2c:	b40002c0 	cbz	x0, 6a84 <fwp_write+0xf44>
    6a30:	110006b5 	add	w21, w21, #0x1
    6a34:	91004273 	add	x19, x19, #0x10
    6a38:	710016bf 	cmp	w21, #0x5
    6a3c:	54fffe81 	b.ne	6a0c <fwp_write+0xecc>  // b.any
    6a40:	17ffffde 	b	69b8 <fwp_write+0xe78>
    6a44:	f9400a60 	ldr	x0, [x19, #16]
    6a48:	8b000021 	add	x1, x1, x0
    6a4c:	17fffd75 	b	6020 <fwp_write+0x4e0>
    6a50:	528c29c0 	mov	w0, #0x614e                	// #24910
    6a54:	910123f5 	add	x21, sp, #0x48
    6a58:	72a009c0 	movk	w0, #0x4e, lsl #16
    6a5c:	b9004be0 	str	w0, [sp, #72]
    6a60:	17fffda2 	b	60e8 <fwp_write+0x5a8>
    6a64:	528005a1 	mov	w1, #0x2d                  	// #45
    6a68:	eb1603e2 	negs	x2, x22
    6a6c:	da1803e3 	ngc	x3, x24
    6a70:	910027e0 	add	x0, sp, #0x9
    6a74:	910023f3 	add	x19, sp, #0x8
    6a78:	390023e1 	strb	w1, [sp, #8]
    6a7c:	97ffec09 	bl	1aa0 <fwp_fmt_u128>
    6a80:	17ffffd4 	b	69d0 <fwp_write+0xe90>
    6a84:	aa1703e2 	mov	x2, x23
    6a88:	aa1a03e3 	mov	x3, x26
    6a8c:	aa1603e0 	mov	x0, x22
    6a90:	aa1803e1 	mov	x1, x24
    6a94:	940002e7 	bl	7630 <__divti3>
    6a98:	aa0003e2 	mov	x2, x0
    6a9c:	aa0103e3 	mov	x3, x1
    6aa0:	b7f80201 	tbnz	x1, #63, 6ae0 <fwp_write+0xfa0>
    6aa4:	910023f3 	add	x19, sp, #0x8
    6aa8:	aa1303e0 	mov	x0, x19
    6aac:	97ffebfd 	bl	1aa0 <fwp_fmt_u128>
    6ab0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    6ab4:	912ae339 	add	x25, x25, #0xab8
    6ab8:	910123f5 	add	x21, sp, #0x48
    6abc:	aa1303e4 	mov	x4, x19
    6ac0:	aa1503e0 	mov	x0, x21
    6ac4:	d0000003 	adrp	x3, 8000 <_IO_stdin_used+0x2b0>
    6ac8:	f8616b25 	ldr	x5, [x25, x1]
    6acc:	91066063 	add	x3, x3, #0x198
    6ad0:	d2804002 	mov	x2, #0x200                 	// #512
    6ad4:	52800041 	mov	w1, #0x2                   	// #2
    6ad8:	97ffea46 	bl	13f0 <__sprintf_chk@plt>
    6adc:	17ffffc5 	b	69f0 <fwp_write+0xeb0>
    6ae0:	528005a4 	mov	w4, #0x2d                  	// #45
    6ae4:	eb0003e2 	negs	x2, x0
    6ae8:	da0103e3 	ngc	x3, x1
    6aec:	910027e0 	add	x0, sp, #0x9
    6af0:	910023f3 	add	x19, sp, #0x8
    6af4:	390023e4 	strb	w4, [sp, #8]
    6af8:	97ffebea 	bl	1aa0 <fwp_fmt_u128>
    6afc:	17ffffed 	b	6ab0 <fwp_write+0xf70>
    6b00:	f9013bf5 	str	x21, [sp, #624]
    6b04:	f9013ff6 	str	x22, [sp, #632]
    6b08:	f90143f7 	str	x23, [sp, #640]
    6b0c:	f90147f8 	str	x24, [sp, #648]
    6b10:	f9014bf9 	str	x25, [sp, #656]
    6b14:	f9014ffa 	str	x26, [sp, #664]
    6b18:	f90153fb 	str	x27, [sp, #672]
    6b1c:	f90157fc 	str	x28, [sp, #680]
    6b20:	fd015be8 	str	d8, [sp, #688]
    6b24:	fd015fe9 	str	d9, [sp, #696]
    6b28:	97ffea8a 	bl	1550 <__stack_chk_fail@plt>
    6b2c:	d503201f 	nop

0000000000006b30 <fwp_main_thread>:
    6b30:	d10643ff 	sub	sp, sp, #0x190
    6b34:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    6b38:	f947f400 	ldr	x0, [x0, #4072]
    6b3c:	a9137bfd 	stp	x29, x30, [sp, #304]
    6b40:	9104c3fd 	add	x29, sp, #0x130
    6b44:	a91663f7 	stp	x23, x24, [sp, #352]
    6b48:	f0000158 	adrp	x24, 31000 <fwp_root_context+0xcb0>
    6b4c:	9114c301 	add	x1, x24, #0x530
    6b50:	a91453f3 	stp	x19, x20, [sp, #320]
    6b54:	a9155bf5 	stp	x21, x22, [sp, #336]
    6b58:	b953a421 	ldr	w1, [x1, #5028]
    6b5c:	a9176bf9 	stp	x25, x26, [sp, #368]
    6b60:	a91873fb 	stp	x27, x28, [sp, #384]
    6b64:	f9400002 	ldr	x2, [x0]
    6b68:	f90097e2 	str	x2, [sp, #296]
    6b6c:	d2800002 	mov	x2, #0x0                   	// #0
    6b70:	34002941 	cbz	w1, 7098 <fwp_main_thread+0x568>
    6b74:	9114c300 	add	x0, x24, #0x530
    6b78:	b953a800 	ldr	w0, [x0, #5032]
    6b7c:	35002860 	cbnz	w0, 7088 <fwp_main_thread+0x558>
    6b80:	d00000d4 	adrp	x20, 20000 <__data_start>
    6b84:	d00000c2 	adrp	x2, 20000 <__data_start>
    6b88:	9101429a 	add	x26, x20, #0x50
    6b8c:	910d4042 	add	x2, x2, #0x350
    6b90:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    6b94:	d2a00024 	mov	x4, #0x10000               	// #65536
    6b98:	910143e0 	add	x0, sp, #0x50
    6b9c:	9100e3fc 	add	x28, sp, #0x38
    6ba0:	d2800001 	mov	x1, #0x0                   	// #0
    6ba4:	a9010f5c 	stp	x28, x3, [x26, #16]
    6ba8:	f9000be0 	str	x0, [sp, #16]
    6bac:	f9002be2 	str	x2, [sp, #80]
    6bb0:	b9005bff 	str	wzr, [sp, #88]
    6bb4:	f90033e4 	str	x4, [sp, #96]
    6bb8:	97ffea02 	bl	13c0 <sigaltstack@plt>
    6bbc:	35005260 	cbnz	w0, 7608 <fwp_main_thread+0xad8>
    6bc0:	4f000400 	movi	v0.4s, #0x0
    6bc4:	910263e0 	add	x0, sp, #0x98
    6bc8:	f0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    6bcc:	91324021 	add	x1, x1, #0xc90
    6bd0:	f9004be1 	str	x1, [sp, #144]
    6bd4:	52800082 	mov	w2, #0x4                   	// #4
    6bd8:	72a10002 	movk	w2, #0x800, lsl #16
    6bdc:	910243f3 	add	x19, sp, #0x90
    6be0:	3d802000 	str	q0, [x0, #128]
    6be4:	b9011be2 	str	w2, [sp, #280]
    6be8:	ad000000 	stp	q0, q0, [x0]
    6bec:	ad010000 	stp	q0, q0, [x0, #32]
    6bf0:	ad020000 	stp	q0, q0, [x0, #64]
    6bf4:	ad030000 	stp	q0, q0, [x0, #96]
    6bf8:	97ffea46 	bl	1510 <sigemptyset@plt>
    6bfc:	35005060 	cbnz	w0, 7608 <fwp_main_thread+0xad8>
    6c00:	aa1303e1 	mov	x1, x19
    6c04:	d2800002 	mov	x2, #0x0                   	// #0
    6c08:	52800160 	mov	w0, #0xb                   	// #11
    6c0c:	97ffea59 	bl	1570 <sigaction@plt>
    6c10:	35004fc0 	cbnz	w0, 7608 <fwp_main_thread+0xad8>
    6c14:	aa1303e1 	mov	x1, x19
    6c18:	d2800002 	mov	x2, #0x0                   	// #0
    6c1c:	528000e0 	mov	w0, #0x7                   	// #7
    6c20:	97ffea54 	bl	1570 <sigaction@plt>
    6c24:	35004f20 	cbnz	w0, 7608 <fwp_main_thread+0xad8>
    6c28:	9114c31b 	add	x27, x24, #0x530
    6c2c:	52800037 	mov	w23, #0x1                   	// #1
    6c30:	f0ffffc0 	adrp	x0, 1000 <__abi_tag+0xd88>
    6c34:	913e4000 	add	x0, x0, #0xf90
    6c38:	b9004357 	str	w23, [x26, #64]
    6c3c:	fd4a1360 	ldr	d0, [x27, #5152]
    6c40:	7e61d800 	ucvtf	d0, d0
    6c44:	fd015f40 	str	d0, [x26, #696]
    6c48:	94000436 	bl	7d20 <atexit>
    6c4c:	35004ec0 	cbnz	w0, 7624 <fwp_main_thread+0xaf4>
    6c50:	b942cb40 	ldr	w0, [x26, #712]
    6c54:	34002260 	cbz	w0, 70a0 <fwp_main_thread+0x570>
    6c58:	9101429a 	add	x26, x20, #0x50
    6c5c:	f9400755 	ldr	x21, [x26, #8]
    6c60:	b40010b5 	cbz	x21, 6e74 <fwp_main_thread+0x344>
    6c64:	aa1503f3 	mov	x19, x21
    6c68:	910102b6 	add	x22, x21, #0x40
    6c6c:	39414ab9 	ldrb	w25, [x21, #82]
    6c70:	52800037 	mov	w23, #0x1                   	// #1
    6c74:	39014ab7 	strb	w23, [x21, #82]
    6c78:	f94016a0 	ldr	x0, [x21, #40]
    6c7c:	b4000620 	cbz	x0, 6d40 <fwp_main_thread+0x210>
    6c80:	f94032a1 	ldr	x1, [x21, #96]
    6c84:	394146a0 	ldrb	w0, [x21, #81]
    6c88:	b4000b41 	cbz	x1, 6df0 <fwp_main_thread+0x2c0>
    6c8c:	36000a80 	tbz	w0, #0, 6ddc <fwp_main_thread+0x2ac>
    6c90:	39414a62 	ldrb	w2, [x19, #82]
    6c94:	f94022a0 	ldr	x0, [x21, #64]
    6c98:	37000d62 	tbnz	w2, #0, 6e44 <fwp_main_thread+0x314>
    6c9c:	f9403261 	ldr	x1, [x19, #96]
    6ca0:	a911fe76 	stp	x22, xzr, [x19, #280]
    6ca4:	f9009660 	str	x0, [x19, #296]
    6ca8:	b4000040 	cbz	x0, 6cb0 <fwp_main_thread+0x180>
    6cac:	f9009013 	str	x19, [x0, #288]
    6cb0:	f90022b3 	str	x19, [x21, #64]
    6cb4:	b4000101 	cbz	x1, 6cd4 <fwp_main_thread+0x1a4>
    6cb8:	f9401f40 	ldr	x0, [x26, #56]
    6cbc:	39015677 	strb	w23, [x19, #85]
    6cc0:	f9003661 	str	x1, [x19, #104]
    6cc4:	a910827f 	stp	xzr, x0, [x19, #264]
    6cc8:	b4000040 	cbz	x0, 6cd0 <fwp_main_thread+0x1a0>
    6ccc:	f9008413 	str	x19, [x0, #264]
    6cd0:	f9001f53 	str	x19, [x26, #56]
    6cd4:	39015a7f 	strb	wzr, [x19, #86]
    6cd8:	97fff37b 	bl	3ac4 <fwp_block>
    6cdc:	f9408e62 	ldr	x2, [x19, #280]
    6ce0:	b4000142 	cbz	x2, 6d08 <fwp_main_thread+0x1d8>
    6ce4:	a9520261 	ldp	x1, x0, [x19, #288]
    6ce8:	b4000ba1 	cbz	x1, 6e5c <fwp_main_thread+0x32c>
    6cec:	f9009420 	str	x0, [x1, #296]
    6cf0:	f9409660 	ldr	x0, [x19, #296]
    6cf4:	b4000040 	cbz	x0, 6cfc <fwp_main_thread+0x1cc>
    6cf8:	f9009001 	str	x1, [x0, #288]
    6cfc:	91080260 	add	x0, x19, #0x200
    6d00:	f900967f 	str	xzr, [x19, #296]
    6d04:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    6d08:	39415660 	ldrb	w0, [x19, #85]
    6d0c:	f9400742 	ldr	x2, [x26, #8]
    6d10:	36000960 	tbz	w0, #0, 6e3c <fwp_main_thread+0x30c>
    6d14:	a9508261 	ldp	x1, x0, [x19, #264]
    6d18:	b4000a61 	cbz	x1, 6e64 <fwp_main_thread+0x334>
    6d1c:	f9008820 	str	x0, [x1, #272]
    6d20:	b4000040 	cbz	x0, 6d28 <fwp_main_thread+0x1f8>
    6d24:	f9008401 	str	x1, [x0, #264]
    6d28:	91080260 	add	x0, x19, #0x200
    6d2c:	3901567f 	strb	wzr, [x19, #85]
    6d30:	aa0203f3 	mov	x19, x2
    6d34:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    6d38:	f94016a0 	ldr	x0, [x21, #40]
    6d3c:	b5fffa20 	cbnz	x0, 6c80 <fwp_main_thread+0x150>
    6d40:	91014280 	add	x0, x20, #0x50
    6d44:	39014ab9 	strb	w25, [x21, #82]
    6d48:	f9414400 	ldr	x0, [x0, #648]
    6d4c:	b4001800 	cbz	x0, 704c <fwp_main_thread+0x51c>
    6d50:	91014280 	add	x0, x20, #0x50
    6d54:	f9417001 	ldr	x1, [x0, #736]
    6d58:	b902d81f 	str	wzr, [x0, #728]
    6d5c:	eb13003f 	cmp	x1, x19
    6d60:	54001921 	b.ne	7084 <fwp_main_thread+0x554>  // b.any
    6d64:	b4000933 	cbz	x19, 6e88 <fwp_main_thread+0x358>
    6d68:	91014280 	add	x0, x20, #0x50
    6d6c:	52800021 	mov	w1, #0x1                   	// #1
    6d70:	39014a61 	strb	w1, [x19, #82]
    6d74:	f9413005 	ldr	x5, [x0, #608]
    6d78:	b4000885 	cbz	x5, 6e88 <fwp_main_thread+0x358>
    6d7c:	d503201f 	nop
    6d80:	394140a0 	ldrb	w0, [x5, #80]
    6d84:	37000060 	tbnz	w0, #0, 6d90 <fwp_main_thread+0x260>
    6d88:	aa0503e0 	mov	x0, x5
    6d8c:	97ffed19 	bl	21f0 <fwp_cancel_tree.part.0>
    6d90:	f9409ca5 	ldr	x5, [x5, #312]
    6d94:	b5ffff65 	cbnz	x5, 6d80 <fwp_main_thread+0x250>
    6d98:	91014295 	add	x21, x20, #0x50
    6d9c:	52800036 	mov	w22, #0x1                   	// #1
    6da0:	f9402a60 	ldr	x0, [x19, #80]
    6da4:	f2001c1f 	tst	x0, #0xff000000ff
    6da8:	540000e1 	b.ne	6dc4 <fwp_main_thread+0x294>  // b.any
    6dac:	f94016a0 	ldr	x0, [x21, #40]
    6db0:	39015276 	strb	w22, [x19, #84]
    6db4:	f900827f 	str	xzr, [x19, #256]
    6db8:	b40005a0 	cbz	x0, 6e6c <fwp_main_thread+0x33c>
    6dbc:	f9008013 	str	x19, [x0, #256]
    6dc0:	f90016b3 	str	x19, [x21, #40]
    6dc4:	97fff340 	bl	3ac4 <fwp_block>
    6dc8:	97fff2d2 	bl	3910 <fwp_free_zombie>
    6dcc:	f94132a0 	ldr	x0, [x21, #608]
    6dd0:	b40005c0 	cbz	x0, 6e88 <fwp_main_thread+0x358>
    6dd4:	f94172b3 	ldr	x19, [x21, #736]
    6dd8:	17fffff2 	b	6da0 <fwp_main_thread+0x270>
    6ddc:	97ffed59 	bl	2340 <fwp_now_ns>
    6de0:	f94032a1 	ldr	x1, [x21, #96]
    6de4:	eb01001f 	cmp	x0, x1
    6de8:	5400124a 	b.ge	7030 <fwp_main_thread+0x500>  // b.tcont
    6dec:	394146a0 	ldrb	w0, [x21, #81]
    6df0:	39414a62 	ldrb	w2, [x19, #82]
    6df4:	3707f500 	tbnz	w0, #0, 6c94 <fwp_main_thread+0x164>
    6df8:	f94032a1 	ldr	x1, [x21, #96]
    6dfc:	370001c2 	tbnz	w2, #0, 6e34 <fwp_main_thread+0x304>
    6e00:	f9403260 	ldr	x0, [x19, #96]
    6e04:	b4000180 	cbz	x0, 6e34 <fwp_main_thread+0x304>
    6e08:	b4000061 	cbz	x1, 6e14 <fwp_main_thread+0x2e4>
    6e0c:	eb01001f 	cmp	x0, x1
    6e10:	9a81d000 	csel	x0, x0, x1, le
    6e14:	f94022a1 	ldr	x1, [x21, #64]
    6e18:	a911fe76 	stp	x22, xzr, [x19, #280]
    6e1c:	f9009661 	str	x1, [x19, #296]
    6e20:	b4003b21 	cbz	x1, 7584 <fwp_main_thread+0xa54>
    6e24:	f9009033 	str	x19, [x1, #288]
    6e28:	aa0003e1 	mov	x1, x0
    6e2c:	f90022b3 	str	x19, [x21, #64]
    6e30:	17ffffa2 	b	6cb8 <fwp_main_thread+0x188>
    6e34:	f94022a0 	ldr	x0, [x21, #64]
    6e38:	17ffff9a 	b	6ca0 <fwp_main_thread+0x170>
    6e3c:	aa0203f3 	mov	x19, x2
    6e40:	17ffff8e 	b	6c78 <fwp_main_thread+0x148>
    6e44:	a911fe76 	stp	x22, xzr, [x19, #280]
    6e48:	f9009660 	str	x0, [x19, #296]
    6e4c:	b4000040 	cbz	x0, 6e54 <fwp_main_thread+0x324>
    6e50:	f9009013 	str	x19, [x0, #288]
    6e54:	f90022b3 	str	x19, [x21, #64]
    6e58:	17ffff9f 	b	6cd4 <fwp_main_thread+0x1a4>
    6e5c:	f9000040 	str	x0, [x2]
    6e60:	17ffffa5 	b	6cf4 <fwp_main_thread+0x1c4>
    6e64:	f9001f40 	str	x0, [x26, #56]
    6e68:	17ffffae 	b	6d20 <fwp_main_thread+0x1f0>
    6e6c:	f9001ab3 	str	x19, [x21, #48]
    6e70:	17ffffd4 	b	6dc0 <fwp_main_thread+0x290>
    6e74:	f9414740 	ldr	x0, [x26, #648]
    6e78:	b4000e80 	cbz	x0, 7048 <fwp_main_thread+0x518>
    6e7c:	f9417340 	ldr	x0, [x26, #736]
    6e80:	b902db5f 	str	wzr, [x26, #728]
    6e84:	b5001000 	cbnz	x0, 7084 <fwp_main_thread+0x554>
    6e88:	91014295 	add	x21, x20, #0x50
    6e8c:	97fff2a1 	bl	3910 <fwp_free_zombie>
    6e90:	f9401aa0 	ldr	x0, [x21, #48]
    6e94:	b5000f80 	cbnz	x0, 7084 <fwp_main_thread+0x554>
    6e98:	f9401ea0 	ldr	x0, [x21, #56]
    6e9c:	b5000f40 	cbnz	x0, 7084 <fwp_main_thread+0x554>
    6ea0:	b9405ab3 	ldr	w19, [x21, #88]
    6ea4:	340001d3 	cbz	w19, 6edc <fwp_main_thread+0x3ac>
    6ea8:	93407e76 	sxtw	x22, w19
    6eac:	51000673 	sub	w19, w19, #0x1
    6eb0:	d1000ad6 	sub	x22, x22, #0x2
    6eb4:	910182b7 	add	x23, x21, #0x60
    6eb8:	cb3342d6 	sub	x22, x22, w19, uxtw
    6ebc:	93407e73 	sxtw	x19, w19
    6ec0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    6ec4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    6ec8:	b9005ab3 	str	w19, [x21, #88]
    6ecc:	d1000673 	sub	x19, x19, #0x1
    6ed0:	97ffe9e8 	bl	1670 <munmap@plt>
    6ed4:	eb1302df 	cmp	x22, x19
    6ed8:	54ffff41 	b.ne	6ec0 <fwp_main_thread+0x390>  // b.any
    6edc:	d00000d3 	adrp	x19, 20000 <__data_start>
    6ee0:	91004260 	add	x0, x19, #0x10
    6ee4:	b9402000 	ldr	w0, [x0, #32]
    6ee8:	37f80040 	tbnz	w0, #31, 6ef0 <fwp_main_thread+0x3c0>
    6eec:	97ffe99d 	bl	1560 <close@plt>
    6ef0:	91014280 	add	x0, x20, #0x50
    6ef4:	91004261 	add	x1, x19, #0x10
    6ef8:	12800002 	mov	w2, #0xffffffff            	// #-1
    6efc:	d2800013 	mov	x19, #0x0                   	// #0
    6f00:	f9417416 	ldr	x22, [x0, #744]
    6f04:	b9002022 	str	w2, [x1, #32]
    6f08:	f9417815 	ldr	x21, [x0, #752]
    6f0c:	b4000176 	cbz	x22, 6f38 <fwp_main_thread+0x408>
    6f10:	f8737aa0 	ldr	x0, [x21, x19, lsl #3]
    6f14:	b40000c0 	cbz	x0, 6f2c <fwp_main_thread+0x3fc>
    6f18:	f9400001 	ldr	x1, [x0]
    6f1c:	b5000b41 	cbnz	x1, 7084 <fwp_main_thread+0x554>
    6f20:	f9400401 	ldr	x1, [x0, #8]
    6f24:	b5000b01 	cbnz	x1, 7084 <fwp_main_thread+0x554>
    6f28:	97fff0a2 	bl	31b0 <fwp_mem_free>
    6f2c:	91000673 	add	x19, x19, #0x1
    6f30:	eb16027f 	cmp	x19, x22
    6f34:	54fffee1 	b.ne	6f10 <fwp_main_thread+0x3e0>  // b.any
    6f38:	aa1503e0 	mov	x0, x21
    6f3c:	97fff09d 	bl	31b0 <fwp_mem_free>
    6f40:	91014280 	add	x0, x20, #0x50
    6f44:	f9417013 	ldr	x19, [x0, #736]
    6f48:	f901741f 	str	xzr, [x0, #744]
    6f4c:	f901781f 	str	xzr, [x0, #752]
    6f50:	b40001f3 	cbz	x19, 6f8c <fwp_main_thread+0x45c>
    6f54:	f9401661 	ldr	x1, [x19, #40]
    6f58:	b5000961 	cbnz	x1, 7084 <fwp_main_thread+0x554>
    6f5c:	f9405661 	ldr	x1, [x19, #168]
    6f60:	b5000921 	cbnz	x1, 7084 <fwp_main_thread+0x554>
    6f64:	f9414401 	ldr	x1, [x0, #648]
    6f68:	b50008e1 	cbnz	x1, 7084 <fwp_main_thread+0x554>
    6f6c:	f9414c00 	ldr	x0, [x0, #664]
    6f70:	b50008a0 	cbnz	x0, 7084 <fwp_main_thread+0x554>
    6f74:	d2823a02 	mov	x2, #0x11d0                	// #4560
    6f78:	d0000140 	adrp	x0, 30000 <alt.4+0xfcb0>
    6f7c:	910d4000 	add	x0, x0, #0x350
    6f80:	97ffe968 	bl	1520 <memset@plt>
    6f84:	aa1303e0 	mov	x0, x19
    6f88:	97fff08a 	bl	31b0 <fwp_mem_free>
    6f8c:	9114c318 	add	x24, x24, #0x530
    6f90:	91014294 	add	x20, x20, #0x50
    6f94:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    6f98:	f947e800 	ldr	x0, [x0, #4048]
    6f9c:	52800041 	mov	w1, #0x2                   	// #2
    6fa0:	fd4a1300 	ldr	d0, [x24, #5152]
    6fa4:	d0000002 	adrp	x2, 8000 <_IO_stdin_used+0x2b0>
    6fa8:	fd415e81 	ldr	d1, [x20, #696]
    6fac:	91086042 	add	x2, x2, #0x218
    6fb0:	f9400000 	ldr	x0, [x0]
    6fb4:	7e61d800 	ucvtf	d0, d0
    6fb8:	f9402685 	ldr	x5, [x20, #72]
    6fbc:	f900069f 	str	xzr, [x20, #8]
    6fc0:	f9415683 	ldr	x3, [x20, #680]
    6fc4:	1e613801 	fsub	d1, d0, d1
    6fc8:	f9415a84 	ldr	x4, [x20, #688]
    6fcc:	f900129f 	str	xzr, [x20, #32]
    6fd0:	fd416280 	ldr	d0, [x20, #704]
    6fd4:	b900429f 	str	wzr, [x20, #64]
    6fd8:	f901729f 	str	xzr, [x20, #736]
    6fdc:	97ffe979 	bl	15c0 <__fprintf_chk@plt>
    6fe0:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    6fe4:	f947ec00 	ldr	x0, [x0, #4056]
    6fe8:	f9400000 	ldr	x0, [x0]
    6fec:	97ffe9a5 	bl	1680 <fflush@plt>
    6ff0:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    6ff4:	f947f400 	ldr	x0, [x0, #4072]
    6ff8:	f94097e2 	ldr	x2, [sp, #296]
    6ffc:	f9400001 	ldr	x1, [x0]
    7000:	eb010042 	subs	x2, x2, x1
    7004:	d2800001 	mov	x1, #0x0                   	// #0
    7008:	540030c1 	b.ne	7620 <fwp_main_thread+0xaf0>  // b.any
    700c:	a9537bfd 	ldp	x29, x30, [sp, #304]
    7010:	d2800000 	mov	x0, #0x0                   	// #0
    7014:	a95453f3 	ldp	x19, x20, [sp, #320]
    7018:	a9555bf5 	ldp	x21, x22, [sp, #336]
    701c:	a95663f7 	ldp	x23, x24, [sp, #352]
    7020:	a9576bf9 	ldp	x25, x26, [sp, #368]
    7024:	a95873fb 	ldp	x27, x28, [sp, #384]
    7028:	910643ff 	add	sp, sp, #0x190
    702c:	d65f03c0 	ret
    7030:	394142a0 	ldrb	w0, [x21, #80]
    7034:	3707edc0 	tbnz	w0, #0, 6dec <fwp_main_thread+0x2bc>
    7038:	aa1503e0 	mov	x0, x21
    703c:	97ffec6d 	bl	21f0 <fwp_cancel_tree.part.0>
    7040:	394146a0 	ldrb	w0, [x21, #81]
    7044:	17ffff6b 	b	6df0 <fwp_main_thread+0x2c0>
    7048:	d2800013 	mov	x19, #0x0                   	// #0
    704c:	91014295 	add	x21, x20, #0x50
    7050:	f9414ea0 	ldr	x0, [x21, #664]
    7054:	b5ffe7e0 	cbnz	x0, 6d50 <fwp_main_thread+0x220>
    7058:	f94142a0 	ldr	x0, [x21, #640]
    705c:	97fff055 	bl	31b0 <fwp_mem_free>
    7060:	f90142bf 	str	xzr, [x21, #640]
    7064:	f9014abf 	str	xzr, [x21, #656]
    7068:	f94172a0 	ldr	x0, [x21, #736]
    706c:	b4002b73 	cbz	x19, 75d8 <fwp_main_thread+0xaa8>
    7070:	f900567f 	str	xzr, [x19, #168]
    7074:	f9005e7f 	str	xzr, [x19, #184]
    7078:	b902dabf 	str	wzr, [x21, #728]
    707c:	eb00027f 	cmp	x19, x0
    7080:	54ffe740 	b.eq	6d68 <fwp_main_thread+0x238>  // b.none
    7084:	97ffe947 	bl	15a0 <abort@plt>
    7088:	f0ffffc0 	adrp	x0, 2000 <ad_raw_report+0x70>
    708c:	911fc000 	add	x0, x0, #0x7f0
    7090:	94000324 	bl	7d20 <atexit>
    7094:	17fffebb 	b	6b80 <fwp_main_thread+0x50>
    7098:	97ffee2f 	bl	2954 <fwp_heap_init>
    709c:	17fffeb6 	b	6b74 <fwp_main_thread+0x44>
    70a0:	f9413b42 	ldr	x2, [x26, #624]
    70a4:	d0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    70a8:	912f4021 	add	x1, x1, #0xbd0
    70ac:	a90387e2 	stp	x2, x1, [sp, #56]
    70b0:	b0ffffe0 	adrp	x0, 4000 <fwp_data.part.0.constprop.0+0x1a0>
    70b4:	f9400be1 	ldr	x1, [sp, #16]
    70b8:	91254000 	add	x0, x0, #0x950
    70bc:	d2800015 	mov	x21, #0x0                   	// #0
    70c0:	d2804019 	mov	x25, #0x200                 	// #512
    70c4:	d2800016 	mov	x22, #0x0                   	// #0
    70c8:	390023f7 	strb	w23, [sp, #8]
    70cc:	f90027e1 	str	x1, [sp, #72]
    70d0:	f9002bff 	str	xzr, [sp, #80]
    70d4:	a90603ff 	stp	xzr, x0, [sp, #96]
    70d8:	f9013b5c 	str	x28, [x26, #624]
    70dc:	14000012 	b	7124 <fwp_main_thread+0x5f4>
    70e0:	7100045f 	cmp	w2, #0x1
    70e4:	540001a1 	b.ne	7118 <fwp_main_thread+0x5e8>  // b.any
    70e8:	29430002 	ldp	w2, w0, [x0, #24]
    70ec:	92403c21 	and	x1, x1, #0xffff
    70f0:	9b027c21 	mul	x1, x1, x2
    70f4:	d360fc21 	lsr	x1, x1, #32
    70f8:	eb00003f 	cmp	x1, x0
    70fc:	540000e2 	b.cs	7118 <fwp_main_thread+0x5e8>  // b.hs, b.nlast
    7100:	8b01039c 	add	x28, x28, x1
    7104:	39400380 	ldrb	w0, [x28]
    7108:	7103fc1f 	cmp	w0, #0xff
    710c:	54002540 	b.eq	75b4 <fwp_main_thread+0xa84>  // b.none
    7110:	394023e0 	ldrb	w0, [sp, #8]
    7114:	39000380 	strb	w0, [x28]
    7118:	f9002bf5 	str	x21, [sp, #80]
    711c:	aa17035a 	orr	x26, x26, x23
    7120:	b400041a 	cbz	x26, 71a0 <fwp_main_thread+0x670>
    7124:	f100073a 	subs	x26, x25, #0x1
    7128:	aa1303e1 	mov	x1, x19
    712c:	da1f02d7 	sbc	x23, x22, xzr
    7130:	52800020 	mov	w0, #0x1                   	// #1
    7134:	f9002ffa 	str	x26, [sp, #88]
    7138:	aa1a03f9 	mov	x25, x26
    713c:	a90957fa 	stp	x26, x21, [sp, #144]
    7140:	97fff348 	bl	3e60 <fwp_data.part.0.constprop.0>
    7144:	aa0003f5 	mov	x21, x0
    7148:	f949db61 	ldr	x1, [x27, #5040]
    714c:	aa1703f6 	mov	x22, x23
    7150:	f949ef60 	ldr	x0, [x27, #5080]
    7154:	cb0102a1 	sub	x1, x21, x1
    7158:	eb00403f 	cmp	x1, x0, lsl #16
    715c:	54fffde2 	b.cs	7118 <fwp_main_thread+0x5e8>  // b.hs, b.nlast
    7160:	d350fc20 	lsr	x0, x1, #16
    7164:	f949ff65 	ldr	x5, [x27, #5112]
    7168:	8b000800 	add	x0, x0, x0, lsl #2
    716c:	d37df002 	lsl	x2, x0, #3
    7170:	8b0200a0 	add	x0, x5, x2
    7174:	f940101c 	ldr	x28, [x0, #32]
    7178:	b4fffd1c 	cbz	x28, 7118 <fwp_main_thread+0x5e8>
    717c:	386268a2 	ldrb	w2, [x5, x2]
    7180:	7100085f 	cmp	w2, #0x2
    7184:	54fffae1 	b.ne	70e0 <fwp_main_thread+0x5b0>  // b.any
    7188:	72003c3f 	tst	w1, #0xffff
    718c:	54fffbc0 	b.eq	7104 <fwp_main_thread+0x5d4>  // b.none
    7190:	f9002bf5 	str	x21, [sp, #80]
    7194:	aa17035a 	orr	x26, x26, x23
    7198:	b5fffc7a 	cbnz	x26, 7124 <fwp_main_thread+0x5f4>
    719c:	d503201f 	nop
    71a0:	b0000000 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    71a4:	91014282 	add	x2, x20, #0x50
    71a8:	f9401fe3 	ldr	x3, [sp, #56]
    71ac:	9101c3e1 	add	x1, sp, #0x70
    71b0:	3dc11000 	ldr	q0, [x0, #1088]
    71b4:	52800020 	mov	w0, #0x1                   	// #1
    71b8:	f9013843 	str	x3, [x2, #624]
    71bc:	3d801fe0 	str	q0, [sp, #112]
    71c0:	97fff328 	bl	3e60 <fwp_data.part.0.constprop.0>
    71c4:	9114c303 	add	x3, x24, #0x530
    71c8:	aa0003f6 	mov	x22, x0
    71cc:	f949d861 	ldr	x1, [x3, #5040]
    71d0:	f949ec60 	ldr	x0, [x3, #5080]
    71d4:	cb0102c1 	sub	x1, x22, x1
    71d8:	eb00403f 	cmp	x1, x0, lsl #16
    71dc:	54000322 	b.cs	7240 <fwp_main_thread+0x710>  // b.hs, b.nlast
    71e0:	d350fc22 	lsr	x2, x1, #16
    71e4:	f949fc63 	ldr	x3, [x3, #5112]
    71e8:	8b020842 	add	x2, x2, x2, lsl #2
    71ec:	d37df042 	lsl	x2, x2, #3
    71f0:	8b020060 	add	x0, x3, x2
    71f4:	f9401017 	ldr	x23, [x0, #32]
    71f8:	b4000257 	cbz	x23, 7240 <fwp_main_thread+0x710>
    71fc:	38626862 	ldrb	w2, [x3, x2]
    7200:	7100085f 	cmp	w2, #0x2
    7204:	54001cc0 	b.eq	759c <fwp_main_thread+0xa6c>  // b.none
    7208:	7100045f 	cmp	w2, #0x1
    720c:	540001a1 	b.ne	7240 <fwp_main_thread+0x710>  // b.any
    7210:	29430002 	ldp	w2, w0, [x0, #24]
    7214:	92403c21 	and	x1, x1, #0xffff
    7218:	9b027c21 	mul	x1, x1, x2
    721c:	d360fc21 	lsr	x1, x1, #32
    7220:	eb00003f 	cmp	x1, x0
    7224:	540000e2 	b.cs	7240 <fwp_main_thread+0x710>  // b.hs, b.nlast
    7228:	8b0102f7 	add	x23, x23, x1
    722c:	394002e0 	ldrb	w0, [x23]
    7230:	7103fc1f 	cmp	w0, #0xff
    7234:	54001de0 	b.eq	75f0 <fwp_main_thread+0xac0>  // b.none
    7238:	52800020 	mov	w0, #0x1                   	// #1
    723c:	390002e0 	strb	w0, [x23]
    7240:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    7244:	aa1303e1 	mov	x1, x19
    7248:	52800020 	mov	w0, #0x1                   	// #1
    724c:	a9095be2 	stp	x2, x22, [sp, #144]
    7250:	97fff304 	bl	3e60 <fwp_data.part.0.constprop.0>
    7254:	9114c303 	add	x3, x24, #0x530
    7258:	aa0003f3 	mov	x19, x0
    725c:	f949d861 	ldr	x1, [x3, #5040]
    7260:	f949ec60 	ldr	x0, [x3, #5080]
    7264:	cb010261 	sub	x1, x19, x1
    7268:	eb00403f 	cmp	x1, x0, lsl #16
    726c:	54000322 	b.cs	72d0 <fwp_main_thread+0x7a0>  // b.hs, b.nlast
    7270:	d350fc22 	lsr	x2, x1, #16
    7274:	f949fc63 	ldr	x3, [x3, #5112]
    7278:	8b020842 	add	x2, x2, x2, lsl #2
    727c:	d37df042 	lsl	x2, x2, #3
    7280:	8b020060 	add	x0, x3, x2
    7284:	f9401016 	ldr	x22, [x0, #32]
    7288:	b4000256 	cbz	x22, 72d0 <fwp_main_thread+0x7a0>
    728c:	38626862 	ldrb	w2, [x3, x2]
    7290:	7100085f 	cmp	w2, #0x2
    7294:	540018a0 	b.eq	75a8 <fwp_main_thread+0xa78>  // b.none
    7298:	7100045f 	cmp	w2, #0x1
    729c:	540001a1 	b.ne	72d0 <fwp_main_thread+0x7a0>  // b.any
    72a0:	29430002 	ldp	w2, w0, [x0, #24]
    72a4:	92403c21 	and	x1, x1, #0xffff
    72a8:	9b027c21 	mul	x1, x1, x2
    72ac:	d360fc21 	lsr	x1, x1, #32
    72b0:	eb00003f 	cmp	x1, x0
    72b4:	540000e2 	b.cs	72d0 <fwp_main_thread+0x7a0>  // b.hs, b.nlast
    72b8:	8b0102d6 	add	x22, x22, x1
    72bc:	394002c0 	ldrb	w0, [x22]
    72c0:	7103fc1f 	cmp	w0, #0xff
    72c4:	540019c0 	b.eq	75fc <fwp_main_thread+0xacc>  // b.none
    72c8:	52800020 	mov	w0, #0x1                   	// #1
    72cc:	390002c0 	strb	w0, [x22]
    72d0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    72d4:	910203e1 	add	x1, sp, #0x80
    72d8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    72dc:	52800020 	mov	w0, #0x1                   	// #1
    72e0:	a9084fe2 	stp	x2, x19, [sp, #128]
    72e4:	97fff2df 	bl	3e60 <fwp_data.part.0.constprop.0>
    72e8:	9114c302 	add	x2, x24, #0x530
    72ec:	aa0003e3 	mov	x3, x0
    72f0:	f90007e3 	str	x3, [sp, #8]
    72f4:	f949d841 	ldr	x1, [x2, #5040]
    72f8:	f949ec40 	ldr	x0, [x2, #5080]
    72fc:	cb010061 	sub	x1, x3, x1
    7300:	eb00403f 	cmp	x1, x0, lsl #16
    7304:	54000322 	b.cs	7368 <fwp_main_thread+0x838>  // b.hs, b.nlast
    7308:	d350fc20 	lsr	x0, x1, #16
    730c:	f949fc43 	ldr	x3, [x2, #5112]
    7310:	8b000800 	add	x0, x0, x0, lsl #2
    7314:	d37df002 	lsl	x2, x0, #3
    7318:	8b020060 	add	x0, x3, x2
    731c:	f9401013 	ldr	x19, [x0, #32]
    7320:	b4000253 	cbz	x19, 7368 <fwp_main_thread+0x838>
    7324:	38626862 	ldrb	w2, [x3, x2]
    7328:	7100085f 	cmp	w2, #0x2
    732c:	54001320 	b.eq	7590 <fwp_main_thread+0xa60>  // b.none
    7330:	7100045f 	cmp	w2, #0x1
    7334:	540001a1 	b.ne	7368 <fwp_main_thread+0x838>  // b.any
    7338:	29430002 	ldp	w2, w0, [x0, #24]
    733c:	92403c21 	and	x1, x1, #0xffff
    7340:	9b027c21 	mul	x1, x1, x2
    7344:	d360fc21 	lsr	x1, x1, #32
    7348:	eb00003f 	cmp	x1, x0
    734c:	540000e2 	b.cs	7368 <fwp_main_thread+0x838>  // b.hs, b.nlast
    7350:	8b010273 	add	x19, x19, x1
    7354:	39400260 	ldrb	w0, [x19]
    7358:	7103fc1f 	cmp	w0, #0xff
    735c:	54001440 	b.eq	75e4 <fwp_main_thread+0xab4>  // b.none
    7360:	52800020 	mov	w0, #0x1                   	// #1
    7364:	39000260 	strb	w0, [x19]
    7368:	aa1503f7 	mov	x23, x21
    736c:	900000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15a68>
    7370:	b4000f95 	cbz	x21, 7560 <fwp_main_thread+0xa30>
    7374:	912ae000 	add	x0, x0, #0xab8
    7378:	9000001c 	adrp	x28, 7000 <fwp_main_thread+0x4d0>
    737c:	91014000 	add	x0, x0, #0x50
    7380:	91014299 	add	x25, x20, #0x50
    7384:	f9000fe0 	str	x0, [sp, #24]
    7388:	91364380 	add	x0, x28, #0xd90
    738c:	9114c31c 	add	x28, x24, #0x530
    7390:	f90013e0 	str	x0, [sp, #32]
    7394:	1400005d 	b	7508 <fwp_main_thread+0x9d8>
    7398:	7100045f 	cmp	w2, #0x1
    739c:	54000261 	b.ne	73e8 <fwp_main_thread+0x8b8>  // b.any
    73a0:	29430865 	ldp	w5, w2, [x3, #24]
    73a4:	92403c21 	and	x1, x1, #0xffff
    73a8:	9b057c21 	mul	x1, x1, x5
    73ac:	d360fc21 	lsr	x1, x1, #32
    73b0:	eb02003f 	cmp	x1, x2
    73b4:	540001a2 	b.cs	73e8 <fwp_main_thread+0x8b8>  // b.hs, b.nlast
    73b8:	8b010000 	add	x0, x0, x1
    73bc:	39400001 	ldrb	w1, [x0]
    73c0:	34000141 	cbz	w1, 73e8 <fwp_main_thread+0x8b8>
    73c4:	b9404322 	ldr	w2, [x25, #64]
    73c8:	34000082 	cbz	w2, 73d8 <fwp_main_thread+0x8a8>
    73cc:	f9402722 	ldr	x2, [x25, #72]
    73d0:	91000442 	add	x2, x2, #0x1
    73d4:	f9002722 	str	x2, [x25, #72]
    73d8:	7103f43f 	cmp	w1, #0xfd
    73dc:	54000fa8 	b.hi	75d0 <fwp_main_thread+0xaa0>  // b.pmore
    73e0:	11000421 	add	w1, w1, #0x1
    73e4:	39000001 	strb	w1, [x0]
    73e8:	f94007e0 	ldr	x0, [sp, #8]
    73ec:	97fff55a 	bl	4954 <fwp_loop_fields68.constprop.0>
    73f0:	aa0003e1 	mov	x1, x0
    73f4:	aa0003f6 	mov	x22, x0
    73f8:	52800023 	mov	w3, #0x1                   	// #1
    73fc:	a9410be0 	ldp	x0, x2, [sp, #16]
    7400:	a9057fff 	stp	xzr, xzr, [sp, #80]
    7404:	f90033ff 	str	xzr, [sp, #96]
    7408:	97fff9ce 	bl	5b40 <fwp_write>
    740c:	a9456bfb 	ldp	x27, x26, [sp, #80]
    7410:	f94013e0 	ldr	x0, [sp, #32]
    7414:	f100037f 	cmp	x27, #0x0
    7418:	9a9b001b 	csel	x27, x0, x27, eq	// eq = none
    741c:	b1002b5f 	cmn	x26, #0xa
    7420:	54000fa8 	b.hi	7614 <fwp_main_thread+0xae4>  // b.pmore
    7424:	52800021 	mov	w1, #0x1                   	// #1
    7428:	91002740 	add	x0, x26, #0x9
    742c:	97fff3b9 	bl	4310 <fwp_heap_alloc>
    7430:	aa0003f3 	mov	x19, x0
    7434:	aa1b03e1 	mov	x1, x27
    7438:	aa0003fb 	mov	x27, x0
    743c:	aa1a03e2 	mov	x2, x26
    7440:	f800877a 	str	x26, [x27], #8
    7444:	aa1b03e0 	mov	x0, x27
    7448:	97ffe7da 	bl	13b0 <memcpy@plt>
    744c:	8b1a0262 	add	x2, x19, x26
    7450:	3900205f 	strb	wzr, [x2, #8]
    7454:	f9402be0 	ldr	x0, [sp, #80]
    7458:	97ffe86e 	bl	1610 <free@plt>
    745c:	f949db81 	ldr	x1, [x28, #5040]
    7460:	f949ef80 	ldr	x0, [x28, #5080]
    7464:	cb010261 	sub	x1, x19, x1
    7468:	eb00403f 	cmp	x1, x0, lsl #16
    746c:	54000322 	b.cs	74d0 <fwp_main_thread+0x9a0>  // b.hs, b.nlast
    7470:	d350fc20 	lsr	x0, x1, #16
    7474:	f949ff86 	ldr	x6, [x28, #5112]
    7478:	8b000800 	add	x0, x0, x0, lsl #2
    747c:	d37df002 	lsl	x2, x0, #3
    7480:	8b0200c3 	add	x3, x6, x2
    7484:	f9401060 	ldr	x0, [x3, #32]
    7488:	b4000240 	cbz	x0, 74d0 <fwp_main_thread+0x9a0>
    748c:	386268c2 	ldrb	w2, [x6, x2]
    7490:	7100085f 	cmp	w2, #0x2
    7494:	54000600 	b.eq	7554 <fwp_main_thread+0xa24>  // b.none
    7498:	7100045f 	cmp	w2, #0x1
    749c:	540001a1 	b.ne	74d0 <fwp_main_thread+0x9a0>  // b.any
    74a0:	29430866 	ldp	w6, w2, [x3, #24]
    74a4:	92403c21 	and	x1, x1, #0xffff
    74a8:	9b067c21 	mul	x1, x1, x6
    74ac:	d360fc21 	lsr	x1, x1, #32
    74b0:	eb02003f 	cmp	x1, x2
    74b4:	540000e2 	b.cs	74d0 <fwp_main_thread+0x9a0>  // b.hs, b.nlast
    74b8:	8b010000 	add	x0, x0, x1
    74bc:	39400001 	ldrb	w1, [x0]
    74c0:	7103fc3f 	cmp	w1, #0xff
    74c4:	540007e0 	b.eq	75c0 <fwp_main_thread+0xa90>  // b.none
    74c8:	52800021 	mov	w1, #0x1                   	// #1
    74cc:	39000001 	strb	w1, [x0]
    74d0:	aa1603e0 	mov	x0, x22
    74d4:	97fff4ab 	bl	4780 <fwp_drop0>
    74d8:	f9400262 	ldr	x2, [x19]
    74dc:	d2800021 	mov	x1, #0x1                   	// #1
    74e0:	f9400323 	ldr	x3, [x25]
    74e4:	aa1b03e0 	mov	x0, x27
    74e8:	97ffe85a 	bl	1650 <fwrite@plt>
    74ec:	f9400321 	ldr	x1, [x25]
    74f0:	52800140 	mov	w0, #0xa                   	// #10
    74f4:	97ffe7df 	bl	1470 <fputc@plt>
    74f8:	aa1303e0 	mov	x0, x19
    74fc:	97fff40d 	bl	4530 <fwp_drop4>
    7500:	f9400af7 	ldr	x23, [x23, #16]
    7504:	b40002f7 	cbz	x23, 7560 <fwp_main_thread+0xa30>
    7508:	f94007e2 	ldr	x2, [sp, #8]
    750c:	f949db81 	ldr	x1, [x28, #5040]
    7510:	f949ef80 	ldr	x0, [x28, #5080]
    7514:	cb010041 	sub	x1, x2, x1
    7518:	eb00403f 	cmp	x1, x0, lsl #16
    751c:	54fff662 	b.cs	73e8 <fwp_main_thread+0x8b8>  // b.hs, b.nlast
    7520:	d350fc20 	lsr	x0, x1, #16
    7524:	f949ff85 	ldr	x5, [x28, #5112]
    7528:	8b000800 	add	x0, x0, x0, lsl #2
    752c:	d37df002 	lsl	x2, x0, #3
    7530:	8b0200a3 	add	x3, x5, x2
    7534:	f9401060 	ldr	x0, [x3, #32]
    7538:	b4fff580 	cbz	x0, 73e8 <fwp_main_thread+0x8b8>
    753c:	386268a2 	ldrb	w2, [x5, x2]
    7540:	7100085f 	cmp	w2, #0x2
    7544:	54fff2a1 	b.ne	7398 <fwp_main_thread+0x868>  // b.any
    7548:	72003c3f 	tst	w1, #0xffff
    754c:	54fff4e1 	b.ne	73e8 <fwp_main_thread+0x8b8>  // b.any
    7550:	17ffff9b 	b	73bc <fwp_main_thread+0x88c>
    7554:	72003c3f 	tst	w1, #0xffff
    7558:	54fffbc1 	b.ne	74d0 <fwp_main_thread+0x9a0>  // b.any
    755c:	17ffffd8 	b	74bc <fwp_main_thread+0x98c>
    7560:	f94007e0 	ldr	x0, [sp, #8]
    7564:	97fff487 	bl	4780 <fwp_drop0>
    7568:	aa1503e0 	mov	x0, x21
    756c:	97fff485 	bl	4780 <fwp_drop0>
    7570:	91014280 	add	x0, x20, #0x50
    7574:	52800021 	mov	w1, #0x1                   	// #1
    7578:	b902c801 	str	w1, [x0, #712]
    757c:	f901681f 	str	xzr, [x0, #720]
    7580:	17fffdb6 	b	6c58 <fwp_main_thread+0x128>
    7584:	aa0003e1 	mov	x1, x0
    7588:	f90022b3 	str	x19, [x21, #64]
    758c:	17fffdcb 	b	6cb8 <fwp_main_thread+0x188>
    7590:	72003c3f 	tst	w1, #0xffff
    7594:	54ffeea1 	b.ne	7368 <fwp_main_thread+0x838>  // b.any
    7598:	17ffff6f 	b	7354 <fwp_main_thread+0x824>
    759c:	72003c3f 	tst	w1, #0xffff
    75a0:	54ffe501 	b.ne	7240 <fwp_main_thread+0x710>  // b.any
    75a4:	17ffff22 	b	722c <fwp_main_thread+0x6fc>
    75a8:	72003c3f 	tst	w1, #0xffff
    75ac:	54ffe921 	b.ne	72d0 <fwp_main_thread+0x7a0>  // b.any
    75b0:	17ffff43 	b	72bc <fwp_main_thread+0x78c>
    75b4:	aa1c03e0 	mov	x0, x28
    75b8:	97ffee5e 	bl	2f30 <fwp_rc_forget_slot>
    75bc:	17fffed5 	b	7110 <fwp_main_thread+0x5e0>
    75c0:	f90017e0 	str	x0, [sp, #40]
    75c4:	97ffee5b 	bl	2f30 <fwp_rc_forget_slot>
    75c8:	f94017e0 	ldr	x0, [sp, #40]
    75cc:	17ffffbf 	b	74c8 <fwp_main_thread+0x998>
    75d0:	97ffee11 	bl	2e14 <fwp_rc_wide_dup>
    75d4:	17ffff85 	b	73e8 <fwp_main_thread+0x8b8>
    75d8:	b902dabf 	str	wzr, [x21, #728]
    75dc:	b4ffc560 	cbz	x0, 6e88 <fwp_main_thread+0x358>
    75e0:	97ffe7f0 	bl	15a0 <abort@plt>
    75e4:	aa1303e0 	mov	x0, x19
    75e8:	97ffee52 	bl	2f30 <fwp_rc_forget_slot>
    75ec:	17ffff5d 	b	7360 <fwp_main_thread+0x830>
    75f0:	aa1703e0 	mov	x0, x23
    75f4:	97ffee4f 	bl	2f30 <fwp_rc_forget_slot>
    75f8:	17ffff10 	b	7238 <fwp_main_thread+0x708>
    75fc:	aa1603e0 	mov	x0, x22
    7600:	97ffee4c 	bl	2f30 <fwp_rc_forget_slot>
    7604:	17ffff31 	b	72c8 <fwp_main_thread+0x798>
    7608:	b0000000 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    760c:	9106e000 	add	x0, x0, #0x1b8
    7610:	97ffeb3c 	bl	2300 <fwp_trap>
    7614:	b0000000 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    7618:	91080000 	add	x0, x0, #0x200
    761c:	97ffeb39 	bl	2300 <fwp_trap>
    7620:	97ffe7cc 	bl	1550 <__stack_chk_fail@plt>
    7624:	b0000000 	adrp	x0, 8000 <_IO_stdin_used+0x2b0>
    7628:	91078000 	add	x0, x0, #0x1e0
    762c:	97ffea4d 	bl	1f60 <ad_raw_fail>

0000000000007630 <__divti3>:
    7630:	d503245f 	bti	c
    7634:	d2800004 	mov	x4, #0x0                   	// #0
    7638:	b7f80721 	tbnz	x1, #63, 771c <__divti3+0xec>
    763c:	b6f80083 	tbz	x3, #63, 764c <__divti3+0x1c>
    7640:	eb0203e2 	negs	x2, x2
    7644:	aa2403e4 	mvn	x4, x4
    7648:	da0303e3 	ngc	x3, x3
    764c:	aa0203e6 	mov	x6, x2
    7650:	aa0003e7 	mov	x7, x0
    7654:	aa0103e5 	mov	x5, x1
    7658:	b5000583 	cbnz	x3, 7708 <__divti3+0xd8>
    765c:	eb01005f 	cmp	x2, x1
    7660:	54000e69 	b.ls	782c <__divti3+0x1fc>  // b.plast
    7664:	dac01040 	clz	x0, x2
    7668:	b40000e0 	cbz	x0, 7684 <__divti3+0x54>
    766c:	4b0003e1 	neg	w1, w0
    7670:	9ac020a5 	lsl	x5, x5, x0
    7674:	9ac02046 	lsl	x6, x2, x0
    7678:	9ac124e1 	lsr	x1, x7, x1
    767c:	aa050025 	orr	x5, x1, x5
    7680:	9ac020e7 	lsl	x7, x7, x0
    7684:	d360fcc8 	lsr	x8, x6, #32
    7688:	92407cc2 	and	x2, x6, #0xffffffff
    768c:	9ac808a3 	udiv	x3, x5, x8
    7690:	9b089465 	msub	x5, x3, x8, x5
    7694:	aa0303e0 	mov	x0, x3
    7698:	9b037c41 	mul	x1, x2, x3
    769c:	93c780a5 	extr	x5, x5, x7, #32
    76a0:	eb05003f 	cmp	x1, x5
    76a4:	540000a9 	b.ls	76b8 <__divti3+0x88>  // b.plast
    76a8:	ab0500c5 	adds	x5, x6, x5
    76ac:	d1000460 	sub	x0, x3, #0x1
    76b0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    76b4:	540015a8 	b.hi	7968 <__divti3+0x338>  // b.pmore
    76b8:	cb0100a5 	sub	x5, x5, x1
    76bc:	9ac808a3 	udiv	x3, x5, x8
    76c0:	9b089465 	msub	x5, x3, x8, x5
    76c4:	aa0303e1 	mov	x1, x3
    76c8:	9b037c42 	mul	x2, x2, x3
    76cc:	aa0703e3 	mov	x3, x7
    76d0:	b3607ca3 	bfi	x3, x5, #32, #32
    76d4:	eb03005f 	cmp	x2, x3
    76d8:	540000c9 	b.ls	76f0 <__divti3+0xc0>  // b.plast
    76dc:	ab0300c3 	adds	x3, x6, x3
    76e0:	d1000425 	sub	x5, x1, #0x1
    76e4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    76e8:	d1000821 	sub	x1, x1, #0x2
    76ec:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    76f0:	aa008020 	orr	x0, x1, x0, lsl #32
    76f4:	d2800001 	mov	x1, #0x0                   	// #0
    76f8:	b4000064 	cbz	x4, 7704 <__divti3+0xd4>
    76fc:	eb0003e0 	negs	x0, x0
    7700:	da0103e1 	ngc	x1, x1
    7704:	d65f03c0 	ret
    7708:	eb01007f 	cmp	x3, x1
    770c:	54000109 	b.ls	772c <__divti3+0xfc>  // b.plast
    7710:	d2800001 	mov	x1, #0x0                   	// #0
    7714:	d2800000 	mov	x0, #0x0                   	// #0
    7718:	17fffff8 	b	76f8 <__divti3+0xc8>
    771c:	eb0003e0 	negs	x0, x0
    7720:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    7724:	da0103e1 	ngc	x1, x1
    7728:	17ffffc5 	b	763c <__divti3+0xc>
    772c:	dac01067 	clz	x7, x3
    7730:	b40010e7 	cbz	x7, 794c <__divti3+0x31c>
    7734:	d2800805 	mov	x5, #0x40                  	// #64
    7738:	cb0700a5 	sub	x5, x5, x7
    773c:	9ac72063 	lsl	x3, x3, x7
    7740:	9ac52448 	lsr	x8, x2, x5
    7744:	aa030108 	orr	x8, x8, x3
    7748:	9ac52426 	lsr	x6, x1, x5
    774c:	92407d0a 	and	x10, x8, #0xffffffff
    7750:	d360fd09 	lsr	x9, x8, #32
    7754:	9ac52403 	lsr	x3, x0, x5
    7758:	9ac72021 	lsl	x1, x1, x7
    775c:	aa010063 	orr	x3, x3, x1
    7760:	9ac72042 	lsl	x2, x2, x7
    7764:	9ac908cb 	udiv	x11, x6, x9
    7768:	9b099965 	msub	x5, x11, x9, x6
    776c:	aa0b03e1 	mov	x1, x11
    7770:	9b0b7d46 	mul	x6, x10, x11
    7774:	93c380a5 	extr	x5, x5, x3, #32
    7778:	eb0500df 	cmp	x6, x5
    777c:	540000a9 	b.ls	7790 <__divti3+0x160>  // b.plast
    7780:	ab050105 	adds	x5, x8, x5
    7784:	d1000561 	sub	x1, x11, #0x1
    7788:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    778c:	54000f48 	b.hi	7974 <__divti3+0x344>  // b.pmore
    7790:	cb0600a6 	sub	x6, x5, x6
    7794:	9ac908cb 	udiv	x11, x6, x9
    7798:	9b099969 	msub	x9, x11, x9, x6
    779c:	aa0b03e5 	mov	x5, x11
    77a0:	9b0b7d4a 	mul	x10, x10, x11
    77a4:	b3607d23 	bfi	x3, x9, #32, #32
    77a8:	eb03015f 	cmp	x10, x3
    77ac:	540000a9 	b.ls	77c0 <__divti3+0x190>  // b.plast
    77b0:	ab030103 	adds	x3, x8, x3
    77b4:	d1000565 	sub	x5, x11, #0x1
    77b8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    77bc:	54000e28 	b.hi	7980 <__divti3+0x350>  // b.pmore
    77c0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    77c4:	92407c48 	and	x8, x2, #0xffffffff
    77c8:	2a0503e5 	mov	w5, w5
    77cc:	d360fc42 	lsr	x2, x2, #32
    77d0:	d360fc26 	lsr	x6, x1, #32
    77d4:	cb0a0063 	sub	x3, x3, x10
    77d8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    77dc:	9b087caa 	mul	x10, x5, x8
    77e0:	9b087cc8 	mul	x8, x6, x8
    77e4:	9b0220a5 	madd	x5, x5, x2, x8
    77e8:	9b027cc6 	mul	x6, x6, x2
    77ec:	8b4a80a2 	add	x2, x5, x10, lsr #32
    77f0:	8b0900c5 	add	x5, x6, x9
    77f4:	eb02011f 	cmp	x8, x2
    77f8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    77fc:	8b4280c6 	add	x6, x6, x2, lsr #32
    7800:	eb06007f 	cmp	x3, x6
    7804:	540000e3 	b.cc	7820 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    7808:	92407d4a 	and	x10, x10, #0xffffffff
    780c:	9ac72000 	lsl	x0, x0, x7
    7810:	8b028142 	add	x2, x10, x2, lsl #32
    7814:	eb02001f 	cmp	x0, x2
    7818:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    781c:	54000a01 	b.ne	795c <__divti3+0x32c>  // b.any
    7820:	d1000420 	sub	x0, x1, #0x1
    7824:	d2800001 	mov	x1, #0x0                   	// #0
    7828:	17ffffb4 	b	76f8 <__divti3+0xc8>
    782c:	b5000062 	cbnz	x2, 7838 <__divti3+0x208>
    7830:	d2800022 	mov	x2, #0x1                   	// #1
    7834:	9ac30846 	udiv	x6, x2, x3
    7838:	dac010c8 	clz	x8, x6
    783c:	b5000408 	cbnz	x8, 78bc <__divti3+0x28c>
    7840:	d360fcc9 	lsr	x9, x6, #32
    7844:	92407cc5 	and	x5, x6, #0xffffffff
    7848:	cb060023 	sub	x3, x1, x6
    784c:	d2800021 	mov	x1, #0x1                   	// #1
    7850:	9ac90868 	udiv	x8, x3, x9
    7854:	9b098d03 	msub	x3, x8, x9, x3
    7858:	aa0803e0 	mov	x0, x8
    785c:	9b057d02 	mul	x2, x8, x5
    7860:	93c78063 	extr	x3, x3, x7, #32
    7864:	eb03005f 	cmp	x2, x3
    7868:	540000a9 	b.ls	787c <__divti3+0x24c>  // b.plast
    786c:	ab0300c3 	adds	x3, x6, x3
    7870:	d1000500 	sub	x0, x8, #0x1
    7874:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    7878:	54000968 	b.hi	79a4 <__divti3+0x374>  // b.pmore
    787c:	cb020063 	sub	x3, x3, x2
    7880:	9ac90862 	udiv	x2, x3, x9
    7884:	aa0203e8 	mov	x8, x2
    7888:	9b098c42 	msub	x2, x2, x9, x3
    788c:	aa0703e3 	mov	x3, x7
    7890:	9b057d05 	mul	x5, x8, x5
    7894:	b3607c43 	bfi	x3, x2, #32, #32
    7898:	eb0300bf 	cmp	x5, x3
    789c:	540000c9 	b.ls	78b4 <__divti3+0x284>  // b.plast
    78a0:	ab0300c2 	adds	x2, x6, x3
    78a4:	d1000503 	sub	x3, x8, #0x1
    78a8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    78ac:	d1000908 	sub	x8, x8, #0x2
    78b0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    78b4:	aa008100 	orr	x0, x8, x0, lsl #32
    78b8:	17ffff90 	b	76f8 <__divti3+0xc8>
    78bc:	9ac820c6 	lsl	x6, x6, x8
    78c0:	d2800803 	mov	x3, #0x40                  	// #64
    78c4:	cb080063 	sub	x3, x3, x8
    78c8:	d360fcc9 	lsr	x9, x6, #32
    78cc:	9ac82027 	lsl	x7, x1, x8
    78d0:	92407cc5 	and	x5, x6, #0xffffffff
    78d4:	9ac32422 	lsr	x2, x1, x3
    78d8:	9ac32403 	lsr	x3, x0, x3
    78dc:	aa070063 	orr	x3, x3, x7
    78e0:	9ac9084a 	udiv	x10, x2, x9
    78e4:	9ac82007 	lsl	x7, x0, x8
    78e8:	9b098940 	msub	x0, x10, x9, x2
    78ec:	aa0a03e1 	mov	x1, x10
    78f0:	9b0a7ca2 	mul	x2, x5, x10
    78f4:	93c38000 	extr	x0, x0, x3, #32
    78f8:	eb00005f 	cmp	x2, x0
    78fc:	540000a9 	b.ls	7910 <__divti3+0x2e0>  // b.plast
    7900:	ab0000c0 	adds	x0, x6, x0
    7904:	d1000541 	sub	x1, x10, #0x1
    7908:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    790c:	54000468 	b.hi	7998 <__divti3+0x368>  // b.pmore
    7910:	cb020000 	sub	x0, x0, x2
    7914:	9ac9080a 	udiv	x10, x0, x9
    7918:	9b098140 	msub	x0, x10, x9, x0
    791c:	aa0a03e2 	mov	x2, x10
    7920:	9b0a7ca8 	mul	x8, x5, x10
    7924:	b3607c03 	bfi	x3, x0, #32, #32
    7928:	eb03011f 	cmp	x8, x3
    792c:	540000a9 	b.ls	7940 <__divti3+0x310>  // b.plast
    7930:	ab0300c3 	adds	x3, x6, x3
    7934:	d1000542 	sub	x2, x10, #0x1
    7938:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    793c:	54000288 	b.hi	798c <__divti3+0x35c>  // b.pmore
    7940:	cb080063 	sub	x3, x3, x8
    7944:	aa018041 	orr	x1, x2, x1, lsl #32
    7948:	17ffffc2 	b	7850 <__divti3+0x220>
    794c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    7950:	d2800001 	mov	x1, #0x0                   	// #0
    7954:	9a9f87e0 	cset	x0, ls	// ls = plast
    7958:	17ffff68 	b	76f8 <__divti3+0xc8>
    795c:	aa0103e0 	mov	x0, x1
    7960:	d2800001 	mov	x1, #0x0                   	// #0
    7964:	17ffff65 	b	76f8 <__divti3+0xc8>
    7968:	d1000860 	sub	x0, x3, #0x2
    796c:	8b0600a5 	add	x5, x5, x6
    7970:	17ffff52 	b	76b8 <__divti3+0x88>
    7974:	d1000961 	sub	x1, x11, #0x2
    7978:	8b0800a5 	add	x5, x5, x8
    797c:	17ffff85 	b	7790 <__divti3+0x160>
    7980:	d1000965 	sub	x5, x11, #0x2
    7984:	8b080063 	add	x3, x3, x8
    7988:	17ffff8e 	b	77c0 <__divti3+0x190>
    798c:	d1000942 	sub	x2, x10, #0x2
    7990:	8b060063 	add	x3, x3, x6
    7994:	17ffffeb 	b	7940 <__divti3+0x310>
    7998:	d1000941 	sub	x1, x10, #0x2
    799c:	8b060000 	add	x0, x0, x6
    79a0:	17ffffdc 	b	7910 <__divti3+0x2e0>
    79a4:	d1000900 	sub	x0, x8, #0x2
    79a8:	8b060063 	add	x3, x3, x6
    79ac:	17ffffb4 	b	787c <__divti3+0x24c>

00000000000079b0 <__modti3>:
    79b0:	d503245f 	bti	c
    79b4:	d2800004 	mov	x4, #0x0                   	// #0
    79b8:	b6f80081 	tbz	x1, #63, 79c8 <__modti3+0x18>
    79bc:	eb0003e0 	negs	x0, x0
    79c0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    79c4:	da0103e1 	ngc	x1, x1
    79c8:	f100007f 	cmp	x3, #0x0
    79cc:	5400128b 	b.lt	7c1c <__modti3+0x26c>  // b.tstop
    79d0:	aa0003e7 	mov	x7, x0
    79d4:	aa0103e6 	mov	x6, x1
    79d8:	540004e1 	b.ne	7a74 <__modti3+0xc4>  // b.any
    79dc:	eb02003f 	cmp	x1, x2
    79e0:	54000dc2 	b.cs	7b98 <__modti3+0x1e8>  // b.hs, b.nlast
    79e4:	dac01043 	clz	x3, x2
    79e8:	aa0303e5 	mov	x5, x3
    79ec:	b40000e3 	cbz	x3, 7a08 <__modti3+0x58>
    79f0:	4b0303e6 	neg	w6, w3
    79f4:	9ac32021 	lsl	x1, x1, x3
    79f8:	9ac32042 	lsl	x2, x2, x3
    79fc:	9ac62406 	lsr	x6, x0, x6
    7a00:	aa0100c6 	orr	x6, x6, x1
    7a04:	9ac32007 	lsl	x7, x0, x3
    7a08:	d360fc40 	lsr	x0, x2, #32
    7a0c:	92407c43 	and	x3, x2, #0xffffffff
    7a10:	9ac008c1 	udiv	x1, x6, x0
    7a14:	9b009826 	msub	x6, x1, x0, x6
    7a18:	9b017c61 	mul	x1, x3, x1
    7a1c:	93c780c6 	extr	x6, x6, x7, #32
    7a20:	eb06003f 	cmp	x1, x6
    7a24:	540000a9 	b.ls	7a38 <__modti3+0x88>  // b.plast
    7a28:	ab060046 	adds	x6, x2, x6
    7a2c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    7a30:	8b0200c8 	add	x8, x6, x2
    7a34:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    7a38:	cb0100c6 	sub	x6, x6, x1
    7a3c:	9ac008c8 	udiv	x8, x6, x0
    7a40:	9b009901 	msub	x1, x8, x0, x6
    7a44:	aa0703e0 	mov	x0, x7
    7a48:	9b087c63 	mul	x3, x3, x8
    7a4c:	b3607c20 	bfi	x0, x1, #32, #32
    7a50:	eb00007f 	cmp	x3, x0
    7a54:	54001088 	b.hi	7c64 <__modti3+0x2b4>  // b.pmore
    7a58:	cb030000 	sub	x0, x0, x3
    7a5c:	9ac52400 	lsr	x0, x0, x5
    7a60:	d2800001 	mov	x1, #0x0                   	// #0
    7a64:	b4000064 	cbz	x4, 7a70 <__modti3+0xc0>
    7a68:	eb0003e0 	negs	x0, x0
    7a6c:	da0103e1 	ngc	x1, x1
    7a70:	d65f03c0 	ret
    7a74:	dac01066 	clz	x6, x3
    7a78:	eb03003f 	cmp	x1, x3
    7a7c:	54ffff43 	b.cc	7a64 <__modti3+0xb4>  // b.lo, b.ul, b.last
    7a80:	93407cc5 	sxtw	x5, w6
    7a84:	d2800808 	mov	x8, #0x40                  	// #64
    7a88:	cb050108 	sub	x8, x8, x5
    7a8c:	9ac62063 	lsl	x3, x3, x6
    7a90:	9ac62025 	lsl	x5, x1, x6
    7a94:	9ac82447 	lsr	x7, x2, x8
    7a98:	aa0300e7 	orr	x7, x7, x3
    7a9c:	9ac82423 	lsr	x3, x1, x8
    7aa0:	92407cec 	and	x12, x7, #0xffffffff
    7aa4:	d360fcea 	lsr	x10, x7, #32
    7aa8:	9ac82401 	lsr	x1, x0, x8
    7aac:	aa050021 	orr	x1, x1, x5
    7ab0:	9ac62042 	lsl	x2, x2, x6
    7ab4:	9ac62000 	lsl	x0, x0, x6
    7ab8:	9aca086b 	udiv	x11, x3, x10
    7abc:	9b0a8d63 	msub	x3, x11, x10, x3
    7ac0:	aa0b03e5 	mov	x5, x11
    7ac4:	9b0b7d89 	mul	x9, x12, x11
    7ac8:	93c18063 	extr	x3, x3, x1, #32
    7acc:	eb03013f 	cmp	x9, x3
    7ad0:	540000a9 	b.ls	7ae4 <__modti3+0x134>  // b.plast
    7ad4:	ab0300e3 	adds	x3, x7, x3
    7ad8:	d1000565 	sub	x5, x11, #0x1
    7adc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    7ae0:	54001168 	b.hi	7d0c <__modti3+0x35c>  // b.pmore
    7ae4:	cb090063 	sub	x3, x3, x9
    7ae8:	9aca086b 	udiv	x11, x3, x10
    7aec:	9b0a8d6a 	msub	x10, x11, x10, x3
    7af0:	aa0b03e9 	mov	x9, x11
    7af4:	9b0b7d8c 	mul	x12, x12, x11
    7af8:	b3607d41 	bfi	x1, x10, #32, #32
    7afc:	eb01019f 	cmp	x12, x1
    7b00:	540000a9 	b.ls	7b14 <__modti3+0x164>  // b.plast
    7b04:	ab0100e1 	adds	x1, x7, x1
    7b08:	d1000569 	sub	x9, x11, #0x1
    7b0c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    7b10:	54000f88 	b.hi	7d00 <__modti3+0x350>  // b.pmore
    7b14:	aa058123 	orr	x3, x9, x5, lsl #32
    7b18:	92407c4b 	and	x11, x2, #0xffffffff
    7b1c:	2a0903e9 	mov	w9, w9
    7b20:	d360fc4a 	lsr	x10, x2, #32
    7b24:	d360fc63 	lsr	x3, x3, #32
    7b28:	cb0c0021 	sub	x1, x1, x12
    7b2c:	aa0a03ec 	mov	x12, x10
    7b30:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    7b34:	9b0b7d25 	mul	x5, x9, x11
    7b38:	9b0b7c6b 	mul	x11, x3, x11
    7b3c:	9b0a2d29 	madd	x9, x9, x10, x11
    7b40:	92407caa 	and	x10, x5, #0xffffffff
    7b44:	9b0c7c63 	mul	x3, x3, x12
    7b48:	8b458125 	add	x5, x9, x5, lsr #32
    7b4c:	8b0d0069 	add	x9, x3, x13
    7b50:	eb05017f 	cmp	x11, x5
    7b54:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    7b58:	8b058149 	add	x9, x10, x5, lsl #32
    7b5c:	8b458063 	add	x3, x3, x5, lsr #32
    7b60:	eb03003f 	cmp	x1, x3
    7b64:	54000063 	b.cc	7b70 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    7b68:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    7b6c:	54000082 	b.cs	7b7c <__modti3+0x1cc>  // b.hs, b.nlast
    7b70:	eb020129 	subs	x9, x9, x2
    7b74:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    7b78:	cb070063 	sub	x3, x3, x7
    7b7c:	eb090000 	subs	x0, x0, x9
    7b80:	da030021 	sbc	x1, x1, x3
    7b84:	9ac62400 	lsr	x0, x0, x6
    7b88:	9ac82028 	lsl	x8, x1, x8
    7b8c:	aa000100 	orr	x0, x8, x0
    7b90:	9ac62421 	lsr	x1, x1, x6
    7b94:	17ffffb4 	b	7a64 <__modti3+0xb4>
    7b98:	b5000062 	cbnz	x2, 7ba4 <__modti3+0x1f4>
    7b9c:	d2800023 	mov	x3, #0x1                   	// #1
    7ba0:	9ac20862 	udiv	x2, x3, x2
    7ba4:	dac01048 	clz	x8, x2
    7ba8:	aa0803e5 	mov	x5, x8
    7bac:	b5000668 	cbnz	x8, 7c78 <__modti3+0x2c8>
    7bb0:	cb020020 	sub	x0, x1, x2
    7bb4:	d360fc49 	lsr	x9, x2, #32
    7bb8:	92407c4a 	and	x10, x2, #0xffffffff
    7bbc:	9ac90801 	udiv	x1, x0, x9
    7bc0:	9b098020 	msub	x0, x1, x9, x0
    7bc4:	9b0a7c21 	mul	x1, x1, x10
    7bc8:	93c78000 	extr	x0, x0, x7, #32
    7bcc:	eb00003f 	cmp	x1, x0
    7bd0:	540000a9 	b.ls	7be4 <__modti3+0x234>  // b.plast
    7bd4:	ab000040 	adds	x0, x2, x0
    7bd8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    7bdc:	8b020003 	add	x3, x0, x2
    7be0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    7be4:	cb010001 	sub	x1, x0, x1
    7be8:	9ac90820 	udiv	x0, x1, x9
    7bec:	9b098403 	msub	x3, x0, x9, x1
    7bf0:	aa0703e1 	mov	x1, x7
    7bf4:	9b0a7c00 	mul	x0, x0, x10
    7bf8:	b3607c61 	bfi	x1, x3, #32, #32
    7bfc:	eb01001f 	cmp	x0, x1
    7c00:	540000a9 	b.ls	7c14 <__modti3+0x264>  // b.plast
    7c04:	ab010041 	adds	x1, x2, x1
    7c08:	8b020022 	add	x2, x1, x2
    7c0c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    7c10:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    7c14:	cb000020 	sub	x0, x1, x0
    7c18:	17ffff91 	b	7a5c <__modti3+0xac>
    7c1c:	eb0203e5 	negs	x5, x2
    7c20:	aa0003e7 	mov	x7, x0
    7c24:	da0303e8 	ngc	x8, x3
    7c28:	aa0503e2 	mov	x2, x5
    7c2c:	aa0803e3 	mov	x3, x8
    7c30:	aa0103e6 	mov	x6, x1
    7c34:	b4ffed48 	cbz	x8, 79dc <__modti3+0x2c>
    7c38:	eb01011f 	cmp	x8, x1
    7c3c:	54fff148 	b.hi	7a64 <__modti3+0xb4>  // b.pmore
    7c40:	dac01109 	clz	x9, x8
    7c44:	2a0903e6 	mov	w6, w9
    7c48:	b5fff1c9 	cbnz	x9, 7a80 <__modti3+0xd0>
    7c4c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    7c50:	54000068 	b.hi	7c5c <__modti3+0x2ac>  // b.pmore
    7c54:	eb050007 	subs	x7, x0, x5
    7c58:	da080021 	sbc	x1, x1, x8
    7c5c:	aa0703e0 	mov	x0, x7
    7c60:	17ffff81 	b	7a64 <__modti3+0xb4>
    7c64:	ab000040 	adds	x0, x2, x0
    7c68:	8b020002 	add	x2, x0, x2
    7c6c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    7c70:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    7c74:	17ffff79 	b	7a58 <__modti3+0xa8>
    7c78:	9ac82042 	lsl	x2, x2, x8
    7c7c:	d2800803 	mov	x3, #0x40                  	// #64
    7c80:	cb080063 	sub	x3, x3, x8
    7c84:	d360fc49 	lsr	x9, x2, #32
    7c88:	9ac82027 	lsl	x7, x1, x8
    7c8c:	92407c4a 	and	x10, x2, #0xffffffff
    7c90:	9ac32426 	lsr	x6, x1, x3
    7c94:	9ac32403 	lsr	x3, x0, x3
    7c98:	aa070063 	orr	x3, x3, x7
    7c9c:	9ac908c1 	udiv	x1, x6, x9
    7ca0:	9ac82007 	lsl	x7, x0, x8
    7ca4:	9b099820 	msub	x0, x1, x9, x6
    7ca8:	9b017d41 	mul	x1, x10, x1
    7cac:	93c38000 	extr	x0, x0, x3, #32
    7cb0:	eb00003f 	cmp	x1, x0
    7cb4:	540000a9 	b.ls	7cc8 <__modti3+0x318>  // b.plast
    7cb8:	ab000040 	adds	x0, x2, x0
    7cbc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    7cc0:	8b020006 	add	x6, x0, x2
    7cc4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    7cc8:	cb010000 	sub	x0, x0, x1
    7ccc:	9ac90801 	udiv	x1, x0, x9
    7cd0:	9b098026 	msub	x6, x1, x9, x0
    7cd4:	aa0303e0 	mov	x0, x3
    7cd8:	9b017d41 	mul	x1, x10, x1
    7cdc:	b3607cc0 	bfi	x0, x6, #32, #32
    7ce0:	eb00003f 	cmp	x1, x0
    7ce4:	540000a9 	b.ls	7cf8 <__modti3+0x348>  // b.plast
    7ce8:	ab000040 	adds	x0, x2, x0
    7cec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    7cf0:	8b020003 	add	x3, x0, x2
    7cf4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    7cf8:	cb010000 	sub	x0, x0, x1
    7cfc:	17ffffb0 	b	7bbc <__modti3+0x20c>
    7d00:	d1000969 	sub	x9, x11, #0x2
    7d04:	8b070021 	add	x1, x1, x7
    7d08:	17ffff83 	b	7b14 <__modti3+0x164>
    7d0c:	d1000965 	sub	x5, x11, #0x2
    7d10:	8b070063 	add	x3, x3, x7
    7d14:	17ffff74 	b	7ae4 <__modti3+0x134>
    7d18:	d503201f 	nop
    7d1c:	d503201f 	nop

0000000000007d20 <atexit>:
    7d20:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    7d24:	b00000c2 	adrp	x2, 20000 <__data_start>
    7d28:	d2800001 	mov	x1, #0x0                   	// #0
    7d2c:	910003fd 	mov	x29, sp
    7d30:	a8c17bfd 	ldp	x29, x30, [sp], #16
    7d34:	f9400442 	ldr	x2, [x2, #8]
    7d38:	17ffe5c6 	b	1450 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000007d3c <_fini>:
    7d3c:	d503201f 	nop
    7d40:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    7d44:	910003fd 	mov	x29, sp
    7d48:	a8c17bfd 	ldp	x29, x30, [sp], #16
    7d4c:	d65f03c0 	ret
