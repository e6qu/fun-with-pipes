
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1/fwp-local:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000012c8 <_init>:
    12c8:	d503201f 	nop
    12cc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    12d0:	910003fd 	mov	x29, sp
    12d4:	94000188 	bl	18f4 <call_weak_fn>
    12d8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    12dc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000012e0 <.plt>:
    12e0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    12e4:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    12e8:	f946fe11 	ldr	x17, [x16, #3576]
    12ec:	9137e210 	add	x16, x16, #0xdf8
    12f0:	d61f0220 	br	x17
    12f4:	d503201f 	nop
    12f8:	d503201f 	nop
    12fc:	d503201f 	nop

0000000000001300 <memcpy@plt>:
    1300:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1304:	f9470211 	ldr	x17, [x16, #3584]
    1308:	91380210 	add	x16, x16, #0xe00
    130c:	d61f0220 	br	x17

0000000000001310 <sigaltstack@plt>:
    1310:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1314:	f9470611 	ldr	x17, [x16, #3592]
    1318:	91382210 	add	x16, x16, #0xe08
    131c:	d61f0220 	br	x17

0000000000001320 <_exit@plt>:
    1320:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1324:	f9470a11 	ldr	x17, [x16, #3600]
    1328:	91384210 	add	x16, x16, #0xe10
    132c:	d61f0220 	br	x17

0000000000001330 <strlen@plt>:
    1330:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1334:	f9470e11 	ldr	x17, [x16, #3608]
    1338:	91386210 	add	x16, x16, #0xe18
    133c:	d61f0220 	br	x17

0000000000001340 <__sprintf_chk@plt>:
    1340:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1344:	f9471211 	ldr	x17, [x16, #3616]
    1348:	91388210 	add	x16, x16, #0xe20
    134c:	d61f0220 	br	x17

0000000000001350 <exit@plt>:
    1350:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1354:	f9471611 	ldr	x17, [x16, #3624]
    1358:	9138a210 	add	x16, x16, #0xe28
    135c:	d61f0220 	br	x17

0000000000001360 <__libc_start_main@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1364:	f9471a11 	ldr	x17, [x16, #3632]
    1368:	9138c210 	add	x16, x16, #0xe30
    136c:	d61f0220 	br	x17

0000000000001370 <strtoll@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1374:	f9471e11 	ldr	x17, [x16, #3640]
    1378:	9138e210 	add	x16, x16, #0xe38
    137c:	d61f0220 	br	x17

0000000000001380 <strtod@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1384:	f9472211 	ldr	x17, [x16, #3648]
    1388:	91390210 	add	x16, x16, #0xe40
    138c:	d61f0220 	br	x17

0000000000001390 <__cxa_finalize@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1394:	f9472611 	ldr	x17, [x16, #3656]
    1398:	91392210 	add	x16, x16, #0xe48
    139c:	d61f0220 	br	x17

00000000000013a0 <__cxa_atexit@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    13a4:	f9472a11 	ldr	x17, [x16, #3664]
    13a8:	91394210 	add	x16, x16, #0xe50
    13ac:	d61f0220 	br	x17

00000000000013b0 <pthread_attr_init@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    13b4:	f9472e11 	ldr	x17, [x16, #3672]
    13b8:	91396210 	add	x16, x16, #0xe58
    13bc:	d61f0220 	br	x17

00000000000013c0 <fputc@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    13c4:	f9473211 	ldr	x17, [x16, #3680]
    13c8:	91398210 	add	x16, x16, #0xe60
    13cc:	d61f0220 	br	x17

00000000000013d0 <clock_gettime@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    13d4:	f9473611 	ldr	x17, [x16, #3688]
    13d8:	9139a210 	add	x16, x16, #0xe68
    13dc:	d61f0220 	br	x17

00000000000013e0 <setvbuf@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    13e4:	f9473a11 	ldr	x17, [x16, #3696]
    13e8:	9139c210 	add	x16, x16, #0xe70
    13ec:	d61f0220 	br	x17

00000000000013f0 <__memcpy_chk@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    13f4:	f9473e11 	ldr	x17, [x16, #3704]
    13f8:	9139e210 	add	x16, x16, #0xe78
    13fc:	d61f0220 	br	x17

0000000000001400 <signal@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1404:	f9474211 	ldr	x17, [x16, #3712]
    1408:	913a0210 	add	x16, x16, #0xe80
    140c:	d61f0220 	br	x17

0000000000001410 <__snprintf_chk@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1414:	f9474611 	ldr	x17, [x16, #3720]
    1418:	913a2210 	add	x16, x16, #0xe88
    141c:	d61f0220 	br	x17

0000000000001420 <fclose@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1424:	f9474a11 	ldr	x17, [x16, #3728]
    1428:	913a4210 	add	x16, x16, #0xe90
    142c:	d61f0220 	br	x17

0000000000001430 <fopen@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1434:	f9474e11 	ldr	x17, [x16, #3736]
    1438:	913a6210 	add	x16, x16, #0xe98
    143c:	d61f0220 	br	x17

0000000000001440 <malloc@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1444:	f9475211 	ldr	x17, [x16, #3744]
    1448:	913a8210 	add	x16, x16, #0xea0
    144c:	d61f0220 	br	x17

0000000000001450 <pthread_attr_destroy@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1454:	f9475611 	ldr	x17, [x16, #3752]
    1458:	913aa210 	add	x16, x16, #0xea8
    145c:	d61f0220 	br	x17

0000000000001460 <sigemptyset@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1464:	f9475a11 	ldr	x17, [x16, #3760]
    1468:	913ac210 	add	x16, x16, #0xeb0
    146c:	d61f0220 	br	x17

0000000000001470 <memset@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1474:	f9475e11 	ldr	x17, [x16, #3768]
    1478:	913ae210 	add	x16, x16, #0xeb8
    147c:	d61f0220 	br	x17

0000000000001480 <calloc@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1484:	f9476211 	ldr	x17, [x16, #3776]
    1488:	913b0210 	add	x16, x16, #0xec0
    148c:	d61f0220 	br	x17

0000000000001490 <realloc@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1494:	f9476611 	ldr	x17, [x16, #3784]
    1498:	913b2210 	add	x16, x16, #0xec8
    149c:	d61f0220 	br	x17

00000000000014a0 <__stack_chk_fail@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    14a4:	f9476a11 	ldr	x17, [x16, #3792]
    14a8:	913b4210 	add	x16, x16, #0xed0
    14ac:	d61f0220 	br	x17

00000000000014b0 <close@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    14b4:	f9476e11 	ldr	x17, [x16, #3800]
    14b8:	913b6210 	add	x16, x16, #0xed8
    14bc:	d61f0220 	br	x17

00000000000014c0 <sigaction@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    14c4:	f9477211 	ldr	x17, [x16, #3808]
    14c8:	913b8210 	add	x16, x16, #0xee0
    14cc:	d61f0220 	br	x17

00000000000014d0 <__gmon_start__@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    14d4:	f9477611 	ldr	x17, [x16, #3816]
    14d8:	913ba210 	add	x16, x16, #0xee8
    14dc:	d61f0220 	br	x17

00000000000014e0 <write@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    14e4:	f9477a11 	ldr	x17, [x16, #3824]
    14e8:	913bc210 	add	x16, x16, #0xef0
    14ec:	d61f0220 	br	x17

00000000000014f0 <abort@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    14f4:	f9477e11 	ldr	x17, [x16, #3832]
    14f8:	913be210 	add	x16, x16, #0xef8
    14fc:	d61f0220 	br	x17

0000000000001500 <swapcontext@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1504:	f9478211 	ldr	x17, [x16, #3840]
    1508:	913c0210 	add	x16, x16, #0xf00
    150c:	d61f0220 	br	x17

0000000000001510 <__fprintf_chk@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1514:	f9478611 	ldr	x17, [x16, #3848]
    1518:	913c2210 	add	x16, x16, #0xf08
    151c:	d61f0220 	br	x17

0000000000001520 <strcmp@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1524:	f9478a11 	ldr	x17, [x16, #3856]
    1528:	913c4210 	add	x16, x16, #0xf10
    152c:	d61f0220 	br	x17

0000000000001530 <mmap@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1534:	f9478e11 	ldr	x17, [x16, #3864]
    1538:	913c6210 	add	x16, x16, #0xf18
    153c:	d61f0220 	br	x17

0000000000001540 <strtol@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1544:	f9479211 	ldr	x17, [x16, #3872]
    1548:	913c8210 	add	x16, x16, #0xf20
    154c:	d61f0220 	br	x17

0000000000001550 <strtof@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1554:	f9479611 	ldr	x17, [x16, #3880]
    1558:	913ca210 	add	x16, x16, #0xf28
    155c:	d61f0220 	br	x17

0000000000001560 <free@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1564:	f9479a11 	ldr	x17, [x16, #3888]
    1568:	913cc210 	add	x16, x16, #0xf30
    156c:	d61f0220 	br	x17

0000000000001570 <nanosleep@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1574:	f9479e11 	ldr	x17, [x16, #3896]
    1578:	913ce210 	add	x16, x16, #0xf38
    157c:	d61f0220 	br	x17

0000000000001580 <strchr@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1584:	f947a211 	ldr	x17, [x16, #3904]
    1588:	913d0210 	add	x16, x16, #0xf40
    158c:	d61f0220 	br	x17

0000000000001590 <strtoull@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1594:	f947a611 	ldr	x17, [x16, #3912]
    1598:	913d2210 	add	x16, x16, #0xf48
    159c:	d61f0220 	br	x17

00000000000015a0 <fwrite@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    15a4:	f947aa11 	ldr	x17, [x16, #3920]
    15a8:	913d4210 	add	x16, x16, #0xf50
    15ac:	d61f0220 	br	x17

00000000000015b0 <pthread_create@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    15b4:	f947ae11 	ldr	x17, [x16, #3928]
    15b8:	913d6210 	add	x16, x16, #0xf58
    15bc:	d61f0220 	br	x17

00000000000015c0 <munmap@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    15c4:	f947b211 	ldr	x17, [x16, #3936]
    15c8:	913d8210 	add	x16, x16, #0xf60
    15cc:	d61f0220 	br	x17

00000000000015d0 <fflush@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    15d4:	f947b611 	ldr	x17, [x16, #3944]
    15d8:	913da210 	add	x16, x16, #0xf68
    15dc:	d61f0220 	br	x17

00000000000015e0 <strcpy@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    15e4:	f947ba11 	ldr	x17, [x16, #3952]
    15e8:	913dc210 	add	x16, x16, #0xf70
    15ec:	d61f0220 	br	x17

00000000000015f0 <sysconf@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    15f4:	f947be11 	ldr	x17, [x16, #3960]
    15f8:	913de210 	add	x16, x16, #0xf78
    15fc:	d61f0220 	br	x17

0000000000001600 <strstr@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1604:	f947c211 	ldr	x17, [x16, #3968]
    1608:	913e0210 	add	x16, x16, #0xf80
    160c:	d61f0220 	br	x17

0000000000001610 <_Exit@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1614:	f947c611 	ldr	x17, [x16, #3976]
    1618:	913e2210 	add	x16, x16, #0xf88
    161c:	d61f0220 	br	x17

0000000000001620 <pthread_join@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1624:	f947ca11 	ldr	x17, [x16, #3984]
    1628:	913e4210 	add	x16, x16, #0xf90
    162c:	d61f0220 	br	x17

0000000000001630 <getenv@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1634:	f947ce11 	ldr	x17, [x16, #3992]
    1638:	913e6210 	add	x16, x16, #0xf98
    163c:	d61f0220 	br	x17

0000000000001640 <mprotect@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1644:	f947d211 	ldr	x17, [x16, #4000]
    1648:	913e8210 	add	x16, x16, #0xfa0
    164c:	d61f0220 	br	x17

0000000000001650 <fgets@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1654:	f947d611 	ldr	x17, [x16, #4008]
    1658:	913ea210 	add	x16, x16, #0xfa8
    165c:	d61f0220 	br	x17

0000000000001660 <pthread_attr_setstacksize@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x17668>
    1664:	f947da11 	ldr	x17, [x16, #4016]
    1668:	913ec210 	add	x16, x16, #0xfb0
    166c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001680 <fwp_trap_overflow.constprop.0>:
    1680:	d10243ff 	sub	sp, sp, #0x90
    1684:	d2800c03 	mov	x3, #0x60                  	// #96
    1688:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x17668>
    168c:	f947f421 	ldr	x1, [x1, #4072]
    1690:	b0000025 	adrp	x5, 6000 <fwp_main_thread+0x13fc>
    1694:	a9077bfd 	stp	x29, x30, [sp, #112]
    1698:	9101c3fd 	add	x29, sp, #0x70
    169c:	9125c0a5 	add	x5, x5, #0x970
    16a0:	b0000024 	adrp	x4, 6000 <fwp_main_thread+0x13fc>
    16a4:	f90043f3 	str	x19, [sp, #128]
    16a8:	9125e084 	add	x4, x4, #0x978
    16ac:	910023f3 	add	x19, sp, #0x8
    16b0:	f9400022 	ldr	x2, [x1]
    16b4:	f90037e2 	str	x2, [sp, #104]
    16b8:	d2800002 	mov	x2, #0x0                   	// #0
    16bc:	aa0303e1 	mov	x1, x3
    16c0:	52800042 	mov	w2, #0x2                   	// #2
    16c4:	aa1303e0 	mov	x0, x19
    16c8:	97ffff52 	bl	1410 <__snprintf_chk@plt>
    16cc:	aa1303e0 	mov	x0, x19
    16d0:	94000274 	bl	20a0 <fwp_trap>
    16d4:	d503201f 	nop
    16d8:	d503201f 	nop
    16dc:	d503201f 	nop

00000000000016e0 <main>:
    16e0:	d10243ff 	sub	sp, sp, #0x90
    16e4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    16e8:	f947f400 	ldr	x0, [x0, #4072]
    16ec:	a9067bfd 	stp	x29, x30, [sp, #96]
    16f0:	910183fd 	add	x29, sp, #0x60
    16f4:	a90753f3 	stp	x19, x20, [sp, #112]
    16f8:	f00000f3 	adrp	x19, 20000 <__data_start>
    16fc:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x17668>
    1700:	f947ee94 	ldr	x20, [x20, #4056]
    1704:	f9400281 	ldr	x1, [x20]
    1708:	f90043f5 	str	x21, [sp, #128]
    170c:	f9400002 	ldr	x2, [x0]
    1710:	f9002fe2 	str	x2, [sp, #88]
    1714:	d2800002 	mov	x2, #0x0                   	// #0
    1718:	f9003a61 	str	x1, [x19, #112]
    171c:	94000271 	bl	20e0 <fwp_now_ns>
    1720:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    1724:	912f0000 	add	x0, x0, #0xbc0
    1728:	97ffffc2 	bl	1630 <getenv@plt>
    172c:	b4000080 	cbz	x0, 173c <main+0x5c>
    1730:	39400001 	ldrb	w1, [x0]
    1734:	aa0003f5 	mov	x21, x0
    1738:	35000801 	cbnz	w1, 1838 <main+0x158>
    173c:	910023e1 	add	x1, sp, #0x8
    1740:	52800000 	mov	w0, #0x0                   	// #0
    1744:	97ffff23 	bl	13d0 <clock_gettime@plt>
    1748:	35000900 	cbnz	w0, 1868 <main+0x188>
    174c:	a9408be0 	ldp	x0, x2, [sp, #8]
    1750:	d2994003 	mov	x3, #0xca00                	// #51712
    1754:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    1758:	9b037c01 	mul	x1, x0, x3
    175c:	9b437c00 	smulh	x0, x0, x3
    1760:	ab020021 	adds	x1, x1, x2
    1764:	937ffc42 	asr	x2, x2, #63
    1768:	9a020000 	adc	x0, x0, x2
    176c:	f100003f 	cmp	x1, #0x0
    1770:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    1774:	b50009a0 	cbnz	x0, 18a8 <main+0x1c8>
    1778:	f9400280 	ldr	x0, [x20]
    177c:	d2a00023 	mov	x3, #0x10000               	// #65536
    1780:	52800002 	mov	w2, #0x0                   	// #0
    1784:	d2800001 	mov	x1, #0x0                   	// #0
    1788:	910063f5 	add	x21, sp, #0x18
    178c:	97ffff15 	bl	13e0 <setvbuf@plt>
    1790:	d2800021 	mov	x1, #0x1                   	// #1
    1794:	528001a0 	mov	w0, #0xd                   	// #13
    1798:	97ffff1a 	bl	1400 <signal@plt>
    179c:	aa1503e0 	mov	x0, x21
    17a0:	97ffff04 	bl	13b0 <pthread_attr_init@plt>
    17a4:	350007c0 	cbnz	w0, 189c <main+0x1bc>
    17a8:	aa1503e0 	mov	x0, x21
    17ac:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    17b0:	97ffffac 	bl	1660 <pthread_attr_setstacksize@plt>
    17b4:	35000680 	cbnz	w0, 1884 <main+0x1a4>
    17b8:	aa1503e1 	mov	x1, x21
    17bc:	910023e0 	add	x0, sp, #0x8
    17c0:	f0000002 	adrp	x2, 4000 <fwp_write.constprop.0+0x3a0>
    17c4:	d2800003 	mov	x3, #0x0                   	// #0
    17c8:	91301042 	add	x2, x2, #0xc04
    17cc:	97ffff79 	bl	15b0 <pthread_create@plt>
    17d0:	2a0003e1 	mov	w1, w0
    17d4:	aa1503e0 	mov	x0, x21
    17d8:	2a0103f5 	mov	w21, w1
    17dc:	97ffff1d 	bl	1450 <pthread_attr_destroy@plt>
    17e0:	350006a0 	cbnz	w0, 18b4 <main+0x1d4>
    17e4:	350004b5 	cbnz	w21, 1878 <main+0x198>
    17e8:	f94007e0 	ldr	x0, [sp, #8]
    17ec:	d2800001 	mov	x1, #0x0                   	// #0
    17f0:	97ffff8c 	bl	1620 <pthread_join@plt>
    17f4:	35000600 	cbnz	w0, 18b4 <main+0x1d4>
    17f8:	f9400280 	ldr	x0, [x20]
    17fc:	9101c273 	add	x19, x19, #0x70
    1800:	97ffff74 	bl	15d0 <fflush@plt>
    1804:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x17668>
    1808:	f947f421 	ldr	x1, [x1, #4072]
    180c:	b942a260 	ldr	w0, [x19, #672]
    1810:	f9402fe3 	ldr	x3, [sp, #88]
    1814:	f9400022 	ldr	x2, [x1]
    1818:	eb020063 	subs	x3, x3, x2
    181c:	d2800002 	mov	x2, #0x0                   	// #0
    1820:	540002a1 	b.ne	1874 <main+0x194>  // b.any
    1824:	a9467bfd 	ldp	x29, x30, [sp, #96]
    1828:	a94753f3 	ldp	x19, x20, [sp, #112]
    182c:	f94043f5 	ldr	x21, [sp, #128]
    1830:	910243ff 	add	sp, sp, #0x90
    1834:	d65f03c0 	ret
    1838:	910003e1 	mov	x1, sp
    183c:	52800142 	mov	w2, #0xa                   	// #10
    1840:	97ffff54 	bl	1590 <strtoull@plt>
    1844:	f94003e0 	ldr	x0, [sp]
    1848:	39400000 	ldrb	w0, [x0]
    184c:	35fff780 	cbnz	w0, 173c <main+0x5c>
    1850:	394002a0 	ldrb	w0, [x21]
    1854:	52801fa1 	mov	w1, #0xfd                  	// #253
    1858:	5100ac00 	sub	w0, w0, #0x2b
    185c:	6a01001f 	tst	w0, w1
    1860:	54fff6e0 	b.eq	173c <main+0x5c>  // b.none
    1864:	17ffffc5 	b	1778 <main+0x98>
    1868:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    186c:	912f4000 	add	x0, x0, #0xbd0
    1870:	9400020c 	bl	20a0 <fwp_trap>
    1874:	97ffff0b 	bl	14a0 <__stack_chk_fail@plt>
    1878:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    187c:	9131c000 	add	x0, x0, #0xc70
    1880:	94000208 	bl	20a0 <fwp_trap>
    1884:	aa1503e0 	mov	x0, x21
    1888:	97fffef2 	bl	1450 <pthread_attr_destroy@plt>
    188c:	35000140 	cbnz	w0, 18b4 <main+0x1d4>
    1890:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    1894:	91312000 	add	x0, x0, #0xc48
    1898:	94000202 	bl	20a0 <fwp_trap>
    189c:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    18a0:	91306000 	add	x0, x0, #0xc18
    18a4:	940001ff 	bl	20a0 <fwp_trap>
    18a8:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    18ac:	912fc000 	add	x0, x0, #0xbf0
    18b0:	940001fc 	bl	20a0 <fwp_trap>
    18b4:	97ffff0f 	bl	14f0 <abort@plt>
    18b8:	d503201f 	nop
    18bc:	d503201f 	nop

00000000000018c0 <_start>:
    18c0:	d503201f 	nop
    18c4:	d280001d 	mov	x29, #0x0                   	// #0
    18c8:	d280001e 	mov	x30, #0x0                   	// #0
    18cc:	aa0003e5 	mov	x5, x0
    18d0:	f94003e1 	ldr	x1, [sp]
    18d4:	910023e2 	add	x2, sp, #0x8
    18d8:	910003e6 	mov	x6, sp
    18dc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    18e0:	f947f800 	ldr	x0, [x0, #4080]
    18e4:	d2800003 	mov	x3, #0x0                   	// #0
    18e8:	d2800004 	mov	x4, #0x0                   	// #0
    18ec:	97fffe9d 	bl	1360 <__libc_start_main@plt>
    18f0:	97ffff00 	bl	14f0 <abort@plt>

00000000000018f4 <call_weak_fn>:
    18f4:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    18f8:	f947f000 	ldr	x0, [x0, #4064]
    18fc:	b4000040 	cbz	x0, 1904 <call_weak_fn+0x10>
    1900:	17fffef4 	b	14d0 <__gmon_start__@plt>
    1904:	d65f03c0 	ret
    1908:	d503201f 	nop
    190c:	d503201f 	nop

0000000000001910 <deregister_tm_clones>:
    1910:	f00000e0 	adrp	x0, 20000 <__data_start>
    1914:	91016000 	add	x0, x0, #0x58
    1918:	f00000e1 	adrp	x1, 20000 <__data_start>
    191c:	91016021 	add	x1, x1, #0x58
    1920:	eb00003f 	cmp	x1, x0
    1924:	540000c0 	b.eq	193c <deregister_tm_clones+0x2c>  // b.none
    1928:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x17668>
    192c:	f947e021 	ldr	x1, [x1, #4032]
    1930:	b4000061 	cbz	x1, 193c <deregister_tm_clones+0x2c>
    1934:	aa0103f0 	mov	x16, x1
    1938:	d61f0200 	br	x16
    193c:	d65f03c0 	ret

0000000000001940 <register_tm_clones>:
    1940:	f00000e0 	adrp	x0, 20000 <__data_start>
    1944:	91016000 	add	x0, x0, #0x58
    1948:	f00000e1 	adrp	x1, 20000 <__data_start>
    194c:	91016021 	add	x1, x1, #0x58
    1950:	cb000021 	sub	x1, x1, x0
    1954:	d37ffc22 	lsr	x2, x1, #63
    1958:	8b810c41 	add	x1, x2, x1, asr #3
    195c:	9341fc21 	asr	x1, x1, #1
    1960:	b40000c1 	cbz	x1, 1978 <register_tm_clones+0x38>
    1964:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x17668>
    1968:	f947fc42 	ldr	x2, [x2, #4088]
    196c:	b4000062 	cbz	x2, 1978 <register_tm_clones+0x38>
    1970:	aa0203f0 	mov	x16, x2
    1974:	d61f0200 	br	x16
    1978:	d65f03c0 	ret
    197c:	d503201f 	nop

0000000000001980 <__do_global_dtors_aux>:
    1980:	d503233f 	paciasp
    1984:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1988:	910003fd 	mov	x29, sp
    198c:	f9000bf3 	str	x19, [sp, #16]
    1990:	f00000f3 	adrp	x19, 20000 <__data_start>
    1994:	39418260 	ldrb	w0, [x19, #96]
    1998:	37000140 	tbnz	w0, #0, 19c0 <__do_global_dtors_aux+0x40>
    199c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    19a0:	f947e400 	ldr	x0, [x0, #4040]
    19a4:	b4000080 	cbz	x0, 19b4 <__do_global_dtors_aux+0x34>
    19a8:	f00000e0 	adrp	x0, 20000 <__data_start>
    19ac:	f9400400 	ldr	x0, [x0, #8]
    19b0:	97fffe78 	bl	1390 <__cxa_finalize@plt>
    19b4:	97ffffd7 	bl	1910 <deregister_tm_clones>
    19b8:	52800020 	mov	w0, #0x1                   	// #1
    19bc:	39018260 	strb	w0, [x19, #96]
    19c0:	f9400bf3 	ldr	x19, [sp, #16]
    19c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    19c8:	d50323bf 	autiasp
    19cc:	d65f03c0 	ret

00000000000019d0 <frame_dummy>:
    19d0:	d503245f 	bti	c
    19d4:	17ffffdb 	b	1940 <register_tm_clones>
    19d8:	d503201f 	nop
    19dc:	d503201f 	nop

00000000000019e0 <fwp_fmt_u128>:
    19e0:	d10183ff 	sub	sp, sp, #0x60
    19e4:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x17668>
    19e8:	f947f421 	ldr	x1, [x1, #4072]
    19ec:	a9057bfd 	stp	x29, x30, [sp, #80]
    19f0:	910143fd 	add	x29, sp, #0x50
    19f4:	f9400024 	ldr	x4, [x1]
    19f8:	f90027e4 	str	x4, [sp, #72]
    19fc:	d2800004 	mov	x4, #0x0                   	// #0
    1a00:	aa030041 	orr	x1, x2, x3
    1a04:	b5000361 	cbnz	x1, 1a70 <fwp_fmt_u128+0x90>
    1a08:	910023e9 	add	x9, sp, #0x8
    1a0c:	52800601 	mov	w1, #0x30                  	// #48
    1a10:	5280002d 	mov	w13, #0x1                   	// #1
    1a14:	390023e1 	strb	w1, [sp, #8]
    1a18:	93407dad 	sxtw	x13, w13
    1a1c:	aa0d03e1 	mov	x1, x13
    1a20:	8b0d0004 	add	x4, x0, x13
    1a24:	d503201f 	nop
    1a28:	8b010123 	add	x3, x9, x1
    1a2c:	cb0103e2 	neg	x2, x1
    1a30:	d1000421 	sub	x1, x1, #0x1
    1a34:	385ff063 	ldurb	w3, [x3, #-1]
    1a38:	38226883 	strb	w3, [x4, x2]
    1a3c:	35ffff61 	cbnz	w1, 1a28 <fwp_fmt_u128+0x48>
    1a40:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x17668>
    1a44:	f947f421 	ldr	x1, [x1, #4072]
    1a48:	382d681f 	strb	wzr, [x0, x13]
    1a4c:	aa0103e0 	mov	x0, x1
    1a50:	f94027e2 	ldr	x2, [sp, #72]
    1a54:	f9400001 	ldr	x1, [x0]
    1a58:	eb010042 	subs	x2, x2, x1
    1a5c:	d2800001 	mov	x1, #0x0                   	// #0
    1a60:	54000561 	b.ne	1b0c <fwp_fmt_u128+0x12c>  // b.any
    1a64:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1a68:	910183ff 	add	sp, sp, #0x60
    1a6c:	d65f03c0 	ret
    1a70:	b0000021 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    1a74:	91348021 	add	x1, x1, #0xd20
    1a78:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1a7c:	910023e9 	add	x9, sp, #0x8
    1a80:	d2800027 	mov	x7, #0x1                   	// #1
    1a84:	f29999af 	movk	x15, #0xcccd
    1a88:	a9402826 	ldp	x6, x10, [x1]
    1a8c:	d503201f 	nop
    1a90:	ab030041 	adds	x1, x2, x3
    1a94:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1a98:	aa0303eb 	mov	x11, x3
    1a9c:	8b070128 	add	x8, x9, x7
    1aa0:	aa0203ee 	mov	x14, x2
    1aa4:	aa0703ed 	mov	x13, x7
    1aa8:	910004e7 	add	x7, x7, #0x1
    1aac:	9bcf7c24 	umulh	x4, x1, x15
    1ab0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1ab4:	8b4408a4 	add	x4, x5, x4, lsr #2
    1ab8:	cb040021 	sub	x1, x1, x4
    1abc:	eb010041 	subs	x1, x2, x1
    1ac0:	da1f0063 	sbc	x3, x3, xzr
    1ac4:	9bc67c24 	umulh	x4, x1, x6
    1ac8:	9b061064 	madd	x4, x3, x6, x4
    1acc:	9b067c2c 	mul	x12, x1, x6
    1ad0:	9b0a1024 	madd	x4, x1, x10, x4
    1ad4:	9bc67c25 	umulh	x5, x1, x6
    1ad8:	9b061465 	madd	x5, x3, x6, x5
    1adc:	9b0a1425 	madd	x5, x1, x10, x5
    1ae0:	93cc0484 	extr	x4, x4, x12, #1
    1ae4:	8b040884 	add	x4, x4, x4, lsl #2
    1ae8:	d341fca3 	lsr	x3, x5, #1
    1aec:	cb040444 	sub	x4, x2, x4, lsl #1
    1af0:	93cc04a2 	extr	x2, x5, x12, #1
    1af4:	1100c084 	add	w4, w4, #0x30
    1af8:	381ff104 	sturb	w4, [x8, #-1]
    1afc:	b5fffcab 	cbnz	x11, 1a90 <fwp_fmt_u128+0xb0>
    1b00:	f10025df 	cmp	x14, #0x9
    1b04:	54fffc68 	b.hi	1a90 <fwp_fmt_u128+0xb0>  // b.pmore
    1b08:	17ffffc4 	b	1a18 <fwp_fmt_u128+0x38>
    1b0c:	97fffe65 	bl	14a0 <__stack_chk_fail@plt>

0000000000001b10 <fwp_range_release>:
    1b10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b14:	910003fd 	mov	x29, sp
    1b18:	f9400801 	ldr	x1, [x0, #16]
    1b1c:	f9000bf3 	str	x19, [sp, #16]
    1b20:	aa0003f3 	mov	x19, x0
    1b24:	b4000061 	cbz	x1, 1b30 <fwp_range_release+0x20>
    1b28:	f9400400 	ldr	x0, [x0, #8]
    1b2c:	d63f0020 	blr	x1
    1b30:	f9400260 	ldr	x0, [x19]
    1b34:	f9400e61 	ldr	x1, [x19, #24]
    1b38:	f9400bf3 	ldr	x19, [sp, #16]
    1b3c:	aa0103f0 	mov	x16, x1
    1b40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1b44:	d61f0200 	br	x16
    1b48:	d503201f 	nop
    1b4c:	d503201f 	nop

0000000000001b50 <fwp_flush>:
    1b50:	f00000e0 	adrp	x0, 20000 <__data_start>
    1b54:	f9403800 	ldr	x0, [x0, #112]
    1b58:	b4000120 	cbz	x0, 1b7c <fwp_flush+0x2c>
    1b5c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1b60:	910003fd 	mov	x29, sp
    1b64:	97fffe9b 	bl	15d0 <fflush@plt>
    1b68:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    1b6c:	f947ec00 	ldr	x0, [x0, #4056]
    1b70:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1b74:	f9400000 	ldr	x0, [x0]
    1b78:	17fffe96 	b	15d0 <fflush@plt>
    1b7c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    1b80:	f947ec00 	ldr	x0, [x0, #4056]
    1b84:	f9400000 	ldr	x0, [x0]
    1b88:	17fffe92 	b	15d0 <fflush@plt>
    1b8c:	d503201f 	nop

0000000000001b90 <fwp_heap_oom>:
    1b90:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x17668>
    1b94:	f947e863 	ldr	x3, [x3, #4048]
    1b98:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1b9c:	d2800262 	mov	x2, #0x13                  	// #19
    1ba0:	910003fd 	mov	x29, sp
    1ba4:	f9400063 	ldr	x3, [x3]
    1ba8:	d2800021 	mov	x1, #0x1                   	// #1
    1bac:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    1bb0:	91206000 	add	x0, x0, #0x818
    1bb4:	97fffe7b 	bl	15a0 <fwrite@plt>
    1bb8:	d2800000 	mov	x0, #0x0                   	// #0
    1bbc:	97fffe85 	bl	15d0 <fflush@plt>
    1bc0:	52800cc0 	mov	w0, #0x66                  	// #102
    1bc4:	97fffe93 	bl	1610 <_Exit@plt>
    1bc8:	d503201f 	nop
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_segv>:
    1bd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1bd4:	f00000e2 	adrp	x2, 20000 <__data_start>
    1bd8:	9101c043 	add	x3, x2, #0x70
    1bdc:	910003fd 	mov	x29, sp
    1be0:	a90153f3 	stp	x19, x20, [sp, #16]
    1be4:	2a0003f3 	mov	w19, w0
    1be8:	f9400460 	ldr	x0, [x3, #8]
    1bec:	f90013f5 	str	x21, [sp, #32]
    1bf0:	f9400835 	ldr	x21, [x1, #16]
    1bf4:	b4000280 	cbz	x0, 1c44 <fwp_segv+0x74>
    1bf8:	f9400814 	ldr	x20, [x0, #16]
    1bfc:	b4000254 	cbz	x20, 1c44 <fwp_segv+0x74>
    1c00:	528003c0 	mov	w0, #0x1e                  	// #30
    1c04:	97fffe7b 	bl	15f0 <sysconf@plt>
    1c08:	f144029f 	cmp	x20, #0x100, lsl #12
    1c0c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c10:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c14:	8b000294 	add	x20, x20, x0
    1c18:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c1c:	eb0102bf 	cmp	x21, x1
    1c20:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1c24:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c28:	35000240 	cbnz	w0, 1c70 <fwp_segv+0xa0>
    1c2c:	f94013f5 	ldr	x21, [sp, #32]
    1c30:	2a1303e0 	mov	w0, w19
    1c34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c38:	d2800001 	mov	x1, #0x0                   	// #0
    1c3c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c40:	17fffdf0 	b	1400 <signal@plt>
    1c44:	9101c042 	add	x2, x2, #0x70
    1c48:	f9400840 	ldr	x0, [x2, #16]
    1c4c:	b4ffff00 	cbz	x0, 1c2c <fwp_segv+0x5c>
    1c50:	f9400c41 	ldr	x1, [x2, #24]
    1c54:	cb010000 	sub	x0, x0, x1
    1c58:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1c5c:	91440000 	add	x0, x0, #0x100, lsl #12
    1c60:	eb15003f 	cmp	x1, x21
    1c64:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1c68:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c6c:	34fffe00 	cbz	w0, 1c2c <fwp_segv+0x5c>
    1c70:	97ffffb8 	bl	1b50 <fwp_flush>
    1c74:	b0000021 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    1c78:	91340021 	add	x1, x1, #0xd00
    1c7c:	d2800342 	mov	x2, #0x1a                  	// #26
    1c80:	52800040 	mov	w0, #0x2                   	// #2
    1c84:	97fffe17 	bl	14e0 <write@plt>
    1c88:	52800ca0 	mov	w0, #0x65                  	// #101
    1c8c:	97fffda5 	bl	1320 <_exit@plt>

0000000000001c90 <fwp_heap_chunks>:
    1c90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1c94:	910003fd 	mov	x29, sp
    1c98:	a90153f3 	stp	x19, x20, [sp, #16]
    1c9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1ca0:	90000195 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    1ca4:	911442a1 	add	x1, x21, #0x510
    1ca8:	f100041f 	cmp	x0, #0x1
    1cac:	54000ca0 	b.eq	1e40 <fwp_heap_chunks+0x1b0>  // b.none
    1cb0:	f949f822 	ldr	x2, [x1, #5104]
    1cb4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaf0>
    1cb8:	912400a5 	add	x5, x5, #0x900
    1cbc:	911442a1 	add	x1, x21, #0x510
    1cc0:	f949ec34 	ldr	x20, [x1, #5080]
    1cc4:	eb14005f 	cmp	x2, x20
    1cc8:	54000c42 	b.cs	1e50 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1ccc:	f949fc23 	ldr	x3, [x1, #5112]
    1cd0:	8b020841 	add	x1, x2, x2, lsl #2
    1cd4:	d2800004 	mov	x4, #0x0                   	// #0
    1cd8:	8b010c61 	add	x1, x3, x1, lsl #3
    1cdc:	14000009 	b	1d00 <fwp_heap_chunks+0x70>
    1ce0:	91000483 	add	x3, x4, #0x1
    1ce4:	eb03001f 	cmp	x0, x3
    1ce8:	54000940 	b.eq	1e10 <fwp_heap_chunks+0x180>  // b.none
    1cec:	91000442 	add	x2, x2, #0x1
    1cf0:	aa0303e4 	mov	x4, x3
    1cf4:	9100a021 	add	x1, x1, #0x28
    1cf8:	eb02029f 	cmp	x20, x2
    1cfc:	54000100 	b.eq	1d1c <fwp_heap_chunks+0x8c>  // b.none
    1d00:	39400023 	ldrb	w3, [x1]
    1d04:	34fffee3 	cbz	w3, 1ce0 <fwp_heap_chunks+0x50>
    1d08:	91000442 	add	x2, x2, #0x1
    1d0c:	9100a021 	add	x1, x1, #0x28
    1d10:	d2800004 	mov	x4, #0x0                   	// #0
    1d14:	eb02029f 	cmp	x20, x2
    1d18:	54ffff41 	b.ne	1d00 <fwp_heap_chunks+0x70>  // b.any
    1d1c:	cb040294 	sub	x20, x20, x4
    1d20:	f9001bf7 	str	x23, [sp, #48]
    1d24:	911442b7 	add	x23, x21, #0x510
    1d28:	8b140013 	add	x19, x0, x20
    1d2c:	f94a1ae1 	ldr	x1, [x23, #5168]
    1d30:	f949f2e0 	ldr	x0, [x23, #5088]
    1d34:	cb040021 	sub	x1, x1, x4
    1d38:	f90a1ae1 	str	x1, [x23, #5168]
    1d3c:	eb00027f 	cmp	x19, x0
    1d40:	54000429 	b.ls	1dc4 <fwp_heap_chunks+0x134>  // b.plast
    1d44:	f949eae1 	ldr	x1, [x23, #5072]
    1d48:	eb01027f 	cmp	x19, x1
    1d4c:	54000888 	b.hi	1e5c <fwp_heap_chunks+0x1cc>  // b.pmore
    1d50:	91010276 	add	x22, x19, #0x40
    1d54:	52800062 	mov	w2, #0x3                   	// #3
    1d58:	f949dae3 	ldr	x3, [x23, #5040]
    1d5c:	eb0102df 	cmp	x22, x1
    1d60:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1d64:	cb0002c1 	sub	x1, x22, x0
    1d68:	8b004060 	add	x0, x3, x0, lsl #16
    1d6c:	d370bc21 	lsl	x1, x1, #16
    1d70:	97fffe34 	bl	1640 <mprotect@plt>
    1d74:	35000740 	cbnz	w0, 1e5c <fwp_heap_chunks+0x1cc>
    1d78:	528003c0 	mov	w0, #0x1e                  	// #30
    1d7c:	97fffe1d 	bl	15f0 <sysconf@plt>
    1d80:	f949f2e2 	ldr	x2, [x23, #5088]
    1d84:	cb0003e5 	neg	x5, x0
    1d88:	aa0003e4 	mov	x4, x0
    1d8c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1d90:	f949fee0 	ldr	x0, [x23, #5112]
    1d94:	8b020843 	add	x3, x2, x2, lsl #2
    1d98:	52800062 	mov	w2, #0x3                   	// #3
    1d9c:	8b010c01 	add	x1, x0, x1, lsl #3
    1da0:	8b030c03 	add	x3, x0, x3, lsl #3
    1da4:	d1000421 	sub	x1, x1, #0x1
    1da8:	8a050060 	and	x0, x3, x5
    1dac:	8b040021 	add	x1, x1, x4
    1db0:	8a050021 	and	x1, x1, x5
    1db4:	cb000021 	sub	x1, x1, x0
    1db8:	97fffe22 	bl	1640 <mprotect@plt>
    1dbc:	35000500 	cbnz	w0, 1e5c <fwp_heap_chunks+0x1cc>
    1dc0:	f909f2f6 	str	x22, [x23, #5088]
    1dc4:	911442b5 	add	x21, x21, #0x510
    1dc8:	d370be60 	lsl	x0, x19, #16
    1dcc:	f949e6a1 	ldr	x1, [x21, #5064]
    1dd0:	f909eeb3 	str	x19, [x21, #5080]
    1dd4:	eb01001f 	cmp	x0, x1
    1dd8:	540000e8 	b.hi	1df4 <fwp_heap_chunks+0x164>  // b.pmore
    1ddc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1de0:	aa1403e0 	mov	x0, x20
    1de4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1de8:	f9401bf7 	ldr	x23, [sp, #48]
    1dec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1df0:	d65f03c0 	ret
    1df4:	f9401bf7 	ldr	x23, [sp, #48]
    1df8:	f909e6a0 	str	x0, [x21, #5064]
    1dfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e00:	aa1403e0 	mov	x0, x20
    1e04:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e08:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e0c:	d65f03c0 	ret
    1e10:	911442b5 	add	x21, x21, #0x510
    1e14:	91000441 	add	x1, x2, #0x1
    1e18:	f90000a1 	str	x1, [x5]
    1e1c:	cb040054 	sub	x20, x2, x4
    1e20:	f94a1aa1 	ldr	x1, [x21, #5168]
    1e24:	cb000020 	sub	x0, x1, x0
    1e28:	f90a1aa0 	str	x0, [x21, #5168]
    1e2c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e30:	aa1403e0 	mov	x0, x20
    1e34:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e38:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e3c:	d65f03c0 	ret
    1e40:	f949f422 	ldr	x2, [x1, #5096]
    1e44:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaf0>
    1e48:	9123e0a5 	add	x5, x5, #0x8f8
    1e4c:	17ffff9c 	b	1cbc <fwp_heap_chunks+0x2c>
    1e50:	d2800004 	mov	x4, #0x0                   	// #0
    1e54:	f9001bf7 	str	x23, [sp, #48]
    1e58:	17ffffb3 	b	1d24 <fwp_heap_chunks+0x94>
    1e5c:	97ffff4d 	bl	1b90 <fwp_heap_oom>

0000000000001e60 <buf_grow>:
    1e60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1e64:	910003fd 	mov	x29, sp
    1e68:	a90153f3 	stp	x19, x20, [sp, #16]
    1e6c:	aa0003f4 	mov	x20, x0
    1e70:	f9400400 	ldr	x0, [x0, #8]
    1e74:	b100041f 	cmn	x0, #0x1
    1e78:	54000400 	b.eq	1ef8 <buf_grow+0x98>  // b.none
    1e7c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    1e80:	cb000042 	sub	x2, x2, x0
    1e84:	eb01005f 	cmp	x2, x1
    1e88:	54000383 	b.cc	1ef8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    1e8c:	f9400a82 	ldr	x2, [x20, #16]
    1e90:	91000421 	add	x1, x1, #0x1
    1e94:	8b000033 	add	x19, x1, x0
    1e98:	eb13005f 	cmp	x2, x19
    1e9c:	54000242 	b.cs	1ee4 <buf_grow+0x84>  // b.hs, b.nlast
    1ea0:	f100005f 	cmp	x2, #0x0
    1ea4:	b5000262 	cbnz	x2, 1ef0 <buf_grow+0x90>
    1ea8:	d2800802 	mov	x2, #0x40                  	// #64
    1eac:	eb02027f 	cmp	x19, x2
    1eb0:	54000068 	b.hi	1ebc <buf_grow+0x5c>  // b.pmore
    1eb4:	14000005 	b	1ec8 <buf_grow+0x68>
    1eb8:	b7f800a2 	tbnz	x2, #63, 1ecc <buf_grow+0x6c>
    1ebc:	d37ff842 	lsl	x2, x2, #1
    1ec0:	eb02027f 	cmp	x19, x2
    1ec4:	54ffffa8 	b.hi	1eb8 <buf_grow+0x58>  // b.pmore
    1ec8:	aa0203f3 	mov	x19, x2
    1ecc:	f9400280 	ldr	x0, [x20]
    1ed0:	aa1303e1 	mov	x1, x19
    1ed4:	97fffd6f 	bl	1490 <realloc@plt>
    1ed8:	b4000100 	cbz	x0, 1ef8 <buf_grow+0x98>
    1edc:	f9000280 	str	x0, [x20]
    1ee0:	f9000a93 	str	x19, [x20, #16]
    1ee4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ee8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1eec:	d65f03c0 	ret
    1ef0:	54fffe6a 	b.ge	1ebc <buf_grow+0x5c>  // b.tcont
    1ef4:	17fffff6 	b	1ecc <buf_grow+0x6c>
    1ef8:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x17668>
    1efc:	f947e863 	ldr	x3, [x3, #4048]
    1f00:	d2800262 	mov	x2, #0x13                  	// #19
    1f04:	d2800021 	mov	x1, #0x1                   	// #1
    1f08:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    1f0c:	91206000 	add	x0, x0, #0x818
    1f10:	f9400063 	ldr	x3, [x3]
    1f14:	97fffda3 	bl	15a0 <fwrite@plt>
    1f18:	d2800000 	mov	x0, #0x0                   	// #0
    1f1c:	97fffdad 	bl	15d0 <fflush@plt>
    1f20:	52800cc0 	mov	w0, #0x66                  	// #102
    1f24:	97fffdbb 	bl	1610 <_Exit@plt>
    1f28:	d503201f 	nop
    1f2c:	d503201f 	nop

0000000000001f30 <buf_put>:
    1f30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1f34:	910003fd 	mov	x29, sp
    1f38:	a90153f3 	stp	x19, x20, [sp, #16]
    1f3c:	aa0003f4 	mov	x20, x0
    1f40:	aa0203f3 	mov	x19, x2
    1f44:	f90013f5 	str	x21, [sp, #32]
    1f48:	aa0103f5 	mov	x21, x1
    1f4c:	aa0203e1 	mov	x1, x2
    1f50:	97ffffc4 	bl	1e60 <buf_grow>
    1f54:	a9400283 	ldp	x3, x0, [x20]
    1f58:	aa1503e1 	mov	x1, x21
    1f5c:	aa1303e2 	mov	x2, x19
    1f60:	8b000060 	add	x0, x3, x0
    1f64:	97fffce7 	bl	1300 <memcpy@plt>
    1f68:	a9400680 	ldp	x0, x1, [x20]
    1f6c:	8b010273 	add	x19, x19, x1
    1f70:	f9000693 	str	x19, [x20, #8]
    1f74:	3833681f 	strb	wzr, [x0, x19]
    1f78:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f7c:	f94013f5 	ldr	x21, [sp, #32]
    1f80:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1f84:	d65f03c0 	ret
    1f88:	d503201f 	nop
    1f8c:	d503201f 	nop

0000000000001f90 <fwp_cancel_tree.part.0>:
    1f90:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f94:	9101c022 	add	x2, x1, #0x70
    1f98:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1f9c:	52800023 	mov	w3, #0x1                   	// #1
    1fa0:	910003fd 	mov	x29, sp
    1fa4:	f9400444 	ldr	x4, [x2, #8]
    1fa8:	f9000bf3 	str	x19, [sp, #16]
    1fac:	39014403 	strb	w3, [x0, #81]
    1fb0:	eb04001f 	cmp	x0, x4
    1fb4:	54000160 	b.eq	1fe0 <fwp_cancel_tree.part.0+0x50>  // b.none
    1fb8:	f9402804 	ldr	x4, [x0, #80]
    1fbc:	f2001c9f 	tst	x4, #0xff000000ff
    1fc0:	54000101 	b.ne	1fe0 <fwp_cancel_tree.part.0+0x50>  // b.any
    1fc4:	f9401044 	ldr	x4, [x2, #32]
    1fc8:	39015003 	strb	w3, [x0, #84]
    1fcc:	f900801f 	str	xzr, [x0, #256]
    1fd0:	b40001e4 	cbz	x4, 200c <fwp_cancel_tree.part.0+0x7c>
    1fd4:	f9008080 	str	x0, [x4, #256]
    1fd8:	9101c021 	add	x1, x1, #0x70
    1fdc:	f9001020 	str	x0, [x1, #32]
    1fe0:	f9401413 	ldr	x19, [x0, #40]
    1fe4:	b40000f3 	cbz	x19, 2000 <fwp_cancel_tree.part.0+0x70>
    1fe8:	39414261 	ldrb	w1, [x19, #80]
    1fec:	aa1303e0 	mov	x0, x19
    1ff0:	37000041 	tbnz	w1, #0, 1ff8 <fwp_cancel_tree.part.0+0x68>
    1ff4:	97ffffe7 	bl	1f90 <fwp_cancel_tree.part.0>
    1ff8:	f9401a73 	ldr	x19, [x19, #48]
    1ffc:	b5ffff73 	cbnz	x19, 1fe8 <fwp_cancel_tree.part.0+0x58>
    2000:	f9400bf3 	ldr	x19, [sp, #16]
    2004:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2008:	d65f03c0 	ret
    200c:	f9001440 	str	x0, [x2, #40]
    2010:	17fffff2 	b	1fd8 <fwp_cancel_tree.part.0+0x48>

0000000000002014 <fwp_finish_float>:
    2014:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2018:	528005c1 	mov	w1, #0x2e                  	// #46
    201c:	910003fd 	mov	x29, sp
    2020:	f9000bf3 	str	x19, [sp, #16]
    2024:	aa0003f3 	mov	x19, x0
    2028:	97fffd56 	bl	1580 <strchr@plt>
    202c:	b4000080 	cbz	x0, 203c <fwp_finish_float+0x28>
    2030:	f9400bf3 	ldr	x19, [sp, #16]
    2034:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2038:	d65f03c0 	ret
    203c:	aa1303e0 	mov	x0, x19
    2040:	52800ca1 	mov	w1, #0x65                  	// #101
    2044:	97fffd4f 	bl	1580 <strchr@plt>
    2048:	b5ffff40 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    204c:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    2050:	aa1303e0 	mov	x0, x19
    2054:	9120c021 	add	x1, x1, #0x830
    2058:	97fffd6a 	bl	1600 <strstr@plt>
    205c:	b5fffea0 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    2060:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    2064:	aa1303e0 	mov	x0, x19
    2068:	9120e021 	add	x1, x1, #0x838
    206c:	97fffd65 	bl	1600 <strstr@plt>
    2070:	b5fffe00 	cbnz	x0, 2030 <fwp_finish_float+0x1c>
    2074:	aa1303e0 	mov	x0, x19
    2078:	97fffcae 	bl	1330 <strlen@plt>
    207c:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    2080:	91210021 	add	x1, x1, #0x840
    2084:	8b000262 	add	x2, x19, x0
    2088:	79400023 	ldrh	w3, [x1]
    208c:	39400821 	ldrb	w1, [x1, #2]
    2090:	78206a63 	strh	w3, [x19, x0]
    2094:	39000841 	strb	w1, [x2, #2]
    2098:	17ffffe6 	b	2030 <fwp_finish_float+0x1c>
    209c:	d503201f 	nop

00000000000020a0 <fwp_trap>:
    20a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    20a4:	910003fd 	mov	x29, sp
    20a8:	f9000bf3 	str	x19, [sp, #16]
    20ac:	aa0003f3 	mov	x19, x0
    20b0:	97fffea8 	bl	1b50 <fwp_flush>
    20b4:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x17668>
    20b8:	f947e884 	ldr	x4, [x4, #4048]
    20bc:	aa1303e3 	mov	x3, x19
    20c0:	90000022 	adrp	x2, 6000 <fwp_main_thread+0x13fc>
    20c4:	91212042 	add	x2, x2, #0x848
    20c8:	52800041 	mov	w1, #0x2                   	// #2
    20cc:	f9400080 	ldr	x0, [x4]
    20d0:	97fffd10 	bl	1510 <__fprintf_chk@plt>
    20d4:	52800ca0 	mov	w0, #0x65                  	// #101
    20d8:	97fffc9e 	bl	1350 <exit@plt>
    20dc:	d503201f 	nop

00000000000020e0 <fwp_now_ns>:
    20e0:	d100c3ff 	sub	sp, sp, #0x30
    20e4:	52800020 	mov	w0, #0x1                   	// #1
    20e8:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x17668>
    20ec:	f947f442 	ldr	x2, [x2, #4072]
    20f0:	910023e1 	add	x1, sp, #0x8
    20f4:	a9027bfd 	stp	x29, x30, [sp, #32]
    20f8:	910083fd 	add	x29, sp, #0x20
    20fc:	f9400043 	ldr	x3, [x2]
    2100:	f9000fe3 	str	x3, [sp, #24]
    2104:	d2800003 	mov	x3, #0x0                   	// #0
    2108:	97fffcb2 	bl	13d0 <clock_gettime@plt>
    210c:	350002c0 	cbnz	w0, 2164 <fwp_now_ns+0x84>
    2110:	a9408be1 	ldp	x1, x2, [sp, #8]
    2114:	d2994003 	mov	x3, #0xca00                	// #51712
    2118:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    211c:	9b037c20 	mul	x0, x1, x3
    2120:	9b437c21 	smulh	x1, x1, x3
    2124:	ab020000 	adds	x0, x0, x2
    2128:	937ffc42 	asr	x2, x2, #63
    212c:	9a020021 	adc	x1, x1, x2
    2130:	f100001f 	cmp	x0, #0x0
    2134:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2138:	b50001e1 	cbnz	x1, 2174 <fwp_now_ns+0x94>
    213c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x17668>
    2140:	f947f421 	ldr	x1, [x1, #4072]
    2144:	f9400fe3 	ldr	x3, [sp, #24]
    2148:	f9400022 	ldr	x2, [x1]
    214c:	eb020063 	subs	x3, x3, x2
    2150:	d2800002 	mov	x2, #0x0                   	// #0
    2154:	540000e1 	b.ne	2170 <fwp_now_ns+0x90>  // b.any
    2158:	a9427bfd 	ldp	x29, x30, [sp, #32]
    215c:	9100c3ff 	add	sp, sp, #0x30
    2160:	d65f03c0 	ret
    2164:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    2168:	91216000 	add	x0, x0, #0x858
    216c:	97ffffcd 	bl	20a0 <fwp_trap>
    2170:	97fffccc 	bl	14a0 <__stack_chk_fail@plt>
    2174:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    2178:	9121e000 	add	x0, x0, #0x878
    217c:	97ffffc9 	bl	20a0 <fwp_trap>

0000000000002180 <fwp_format_g.constprop.0>:
    2180:	d10483ff 	sub	sp, sp, #0x120
    2184:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x13fc>
    2188:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x17668>
    218c:	f947f442 	ldr	x2, [x2, #4072]
    2190:	91228084 	add	x4, x4, #0x8a0
    2194:	a90b7bfd 	stp	x29, x30, [sp, #176]
    2198:	9102c3fd 	add	x29, sp, #0xb0
    219c:	d2800803 	mov	x3, #0x40                  	// #64
    21a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    21a4:	93407c38 	sxtw	x24, w1
    21a8:	aa0303e1 	mov	x1, x3
    21ac:	fd008be8 	str	d8, [sp, #272]
    21b0:	1e604008 	fmov	d8, d0
    21b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    21b8:	910083f4 	add	x20, sp, #0x20
    21bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    21c0:	aa0003f5 	mov	x21, x0
    21c4:	a91073fb 	stp	x27, x28, [sp, #256]
    21c8:	5100071c 	sub	w28, w24, #0x1
    21cc:	2a1c03e5 	mov	w5, w28
    21d0:	f9400040 	ldr	x0, [x2]
    21d4:	f90057e0 	str	x0, [sp, #168]
    21d8:	d2800000 	mov	x0, #0x0                   	// #0
    21dc:	52800042 	mov	w2, #0x2                   	// #2
    21e0:	aa1403e0 	mov	x0, x20
    21e4:	97fffc8b 	bl	1410 <__snprintf_chk@plt>
    21e8:	52800ca1 	mov	w1, #0x65                  	// #101
    21ec:	aa1403e0 	mov	x0, x20
    21f0:	97fffce4 	bl	1580 <strchr@plt>
    21f4:	aa0003f3 	mov	x19, x0
    21f8:	52800142 	mov	w2, #0xa                   	// #10
    21fc:	91000400 	add	x0, x0, #0x1
    2200:	d2800001 	mov	x1, #0x0                   	// #0
    2204:	97fffccf 	bl	1540 <strtol@plt>
    2208:	aa0003f7 	mov	x23, x0
    220c:	11001400 	add	w0, w0, #0x5
    2210:	7100541f 	cmp	w0, #0x15
    2214:	54000d68 	b.hi	23c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    2218:	4b170385 	sub	w5, w28, w23
    221c:	710000bf 	cmp	w5, #0x0
    2220:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2224:	54000b80 	b.eq	2394 <fwp_format_g.constprop.0+0x214>  // b.none
    2228:	394083e0 	ldrb	w0, [sp, #32]
    222c:	cb180273 	sub	x19, x19, x24
    2230:	91000673 	add	x19, x19, #0x1
    2234:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2238:	7100b41f 	cmp	w0, #0x2d
    223c:	9a941681 	cinc	x1, x20, eq	// eq = none
    2240:	1a9f17e4 	cset	w4, eq	// eq = none
    2244:	cb010266 	sub	x6, x19, x1
    2248:	d10004da 	sub	x26, x6, #0x1
    224c:	540018a0 	b.eq	2560 <fwp_format_g.constprop.0+0x3e0>  // b.none
    2250:	910183f9 	add	x25, sp, #0x60
    2254:	d280091b 	mov	x27, #0x48                  	// #72
    2258:	aa1903e7 	mov	x7, x25
    225c:	91000423 	add	x3, x1, #0x1
    2260:	91011cc6 	add	x6, x6, #0x47
    2264:	910004f6 	add	x22, x7, #0x1
    2268:	37f80ff7 	tbnz	w23, #31, 2464 <fwp_format_g.constprop.0+0x2e4>
    226c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    2270:	93407ef7 	sxtw	x23, w23
    2274:	390000e4 	strb	w4, [x7]
    2278:	aa1303e1 	mov	x1, x19
    227c:	aa1703e2 	mov	x2, x23
    2280:	aa1603e0 	mov	x0, x22
    2284:	b9000be5 	str	w5, [sp, #8]
    2288:	cb170374 	sub	x20, x27, x23
    228c:	a9011be3 	stp	x3, x6, [sp, #16]
    2290:	97fffc1c 	bl	1300 <memcpy@plt>
    2294:	d1000694 	sub	x20, x20, #0x1
    2298:	f9400be3 	ldr	x3, [sp, #16]
    229c:	8b1702d6 	add	x22, x22, x23
    22a0:	aa1603e0 	mov	x0, x22
    22a4:	aa1a03e2 	mov	x2, x26
    22a8:	aa0303e1 	mov	x1, x3
    22ac:	aa1403e3 	mov	x3, x20
    22b0:	97fffc50 	bl	13f0 <__memcpy_chk@plt>
    22b4:	8b1a02d6 	add	x22, x22, x26
    22b8:	f9400fe6 	ldr	x6, [sp, #24]
    22bc:	d2800900 	mov	x0, #0x48                  	// #72
    22c0:	b9400be5 	ldr	w5, [sp, #8]
    22c4:	8b170261 	add	x1, x19, x23
    22c8:	cb1400c3 	sub	x3, x6, x20
    22cc:	cb060294 	sub	x20, x20, x6
    22d0:	f101207f 	cmp	x3, #0x48
    22d4:	93407cb8 	sxtw	x24, w5
    22d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    22dc:	aa1803e2 	mov	x2, x24
    22e0:	8b1802d3 	add	x19, x22, x24
    22e4:	8b140063 	add	x3, x3, x20
    22e8:	aa1603e0 	mov	x0, x22
    22ec:	97fffc41 	bl	13f0 <__memcpy_chk@plt>
    22f0:	cb190273 	sub	x19, x19, x25
    22f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    22f8:	eb00027f 	cmp	x19, x0
    22fc:	aa1903e1 	mov	x1, x25
    2300:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    2304:	aa1503e0 	mov	x0, x21
    2308:	aa1303e2 	mov	x2, x19
    230c:	97fffbfd 	bl	1300 <memcpy@plt>
    2310:	38336abf 	strb	wzr, [x21, x19]
    2314:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2318:	aa1503e0 	mov	x0, x21
    231c:	97fffc05 	bl	1330 <strlen@plt>
    2320:	aa0003f3 	mov	x19, x0
    2324:	528005c1 	mov	w1, #0x2e                  	// #46
    2328:	aa1503e0 	mov	x0, x21
    232c:	97fffc95 	bl	1580 <strchr@plt>
    2330:	b4000140 	cbz	x0, 2358 <fwp_format_g.constprop.0+0x1d8>
    2334:	b4000133 	cbz	x19, 2358 <fwp_format_g.constprop.0+0x1d8>
    2338:	aa1303e1 	mov	x1, x19
    233c:	d1000673 	sub	x19, x19, #0x1
    2340:	38736aa0 	ldrb	w0, [x21, x19]
    2344:	7100c01f 	cmp	w0, #0x30
    2348:	54001001 	b.ne	2548 <fwp_format_g.constprop.0+0x3c8>  // b.any
    234c:	38336abf 	strb	wzr, [x21, x19]
    2350:	b5ffff53 	cbnz	x19, 2338 <fwp_format_g.constprop.0+0x1b8>
    2354:	d503201f 	nop
    2358:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    235c:	f947f400 	ldr	x0, [x0, #4072]
    2360:	f94057e2 	ldr	x2, [sp, #168]
    2364:	f9400001 	ldr	x1, [x0]
    2368:	eb010042 	subs	x2, x2, x1
    236c:	d2800001 	mov	x1, #0x0                   	// #0
    2370:	54001061 	b.ne	257c <fwp_format_g.constprop.0+0x3fc>  // b.any
    2374:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2378:	a94c53f3 	ldp	x19, x20, [sp, #192]
    237c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2380:	a94e63f7 	ldp	x23, x24, [sp, #224]
    2384:	a95073fb 	ldp	x27, x28, [sp, #256]
    2388:	fd408be8 	ldr	d8, [sp, #272]
    238c:	910483ff 	add	sp, sp, #0x120
    2390:	d65f03c0 	ret
    2394:	1e604100 	fmov	d0, d8
    2398:	710000bf 	cmp	w5, #0x0
    239c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    23a0:	aa1503e0 	mov	x0, x21
    23a4:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x13fc>
    23a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    23ac:	9122e084 	add	x4, x4, #0x8b8
    23b0:	52800042 	mov	w2, #0x2                   	// #2
    23b4:	d2803201 	mov	x1, #0x190                 	// #400
    23b8:	97fffc16 	bl	1410 <__snprintf_chk@plt>
    23bc:	17ffffd7 	b	2318 <fwp_format_g.constprop.0+0x198>
    23c0:	cb140273 	sub	x19, x19, x20
    23c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    23c8:	910183f9 	add	x25, sp, #0x60
    23cc:	aa1303e2 	mov	x2, x19
    23d0:	aa1403e1 	mov	x1, x20
    23d4:	aa1903e0 	mov	x0, x25
    23d8:	d2800803 	mov	x3, #0x40                  	// #64
    23dc:	97fffc05 	bl	13f0 <__memcpy_chk@plt>
    23e0:	38336b3f 	strb	wzr, [x25, x19]
    23e4:	aa1903e0 	mov	x0, x25
    23e8:	528005c1 	mov	w1, #0x2e                  	// #46
    23ec:	97fffc65 	bl	1580 <strchr@plt>
    23f0:	b40001c0 	cbz	x0, 2428 <fwp_format_g.constprop.0+0x2a8>
    23f4:	b50000b3 	cbnz	x19, 2408 <fwp_format_g.constprop.0+0x288>
    23f8:	1400000c 	b	2428 <fwp_format_g.constprop.0+0x2a8>
    23fc:	381ff01f 	sturb	wzr, [x0, #-1]
    2400:	f1000673 	subs	x19, x19, #0x1
    2404:	54000120 	b.eq	2428 <fwp_format_g.constprop.0+0x2a8>  // b.none
    2408:	8b130320 	add	x0, x25, x19
    240c:	385ff001 	ldurb	w1, [x0, #-1]
    2410:	7100c03f 	cmp	w1, #0x30
    2414:	54ffff40 	b.eq	23fc <fwp_format_g.constprop.0+0x27c>  // b.none
    2418:	d1000673 	sub	x19, x19, #0x1
    241c:	38736b20 	ldrb	w0, [x25, x19]
    2420:	7100b81f 	cmp	w0, #0x2e
    2424:	54000a80 	b.eq	2574 <fwp_format_g.constprop.0+0x3f4>  // b.none
    2428:	710002ff 	cmp	w23, #0x0
    242c:	528005a1 	mov	w1, #0x2d                  	// #45
    2430:	aa1903e5 	mov	x5, x25
    2434:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    2438:	aa1503e0 	mov	x0, x21
    243c:	52800566 	mov	w6, #0x2b                  	// #43
    2440:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x13fc>
    2444:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    2448:	9122a084 	add	x4, x4, #0x8a8
    244c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2450:	52800042 	mov	w2, #0x2                   	// #2
    2454:	d2803201 	mov	x1, #0x190                 	// #400
    2458:	97fffbee 	bl	1410 <__snprintf_chk@plt>
    245c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2460:	17ffffbe 	b	2358 <fwp_format_g.constprop.0+0x1d8>
    2464:	52800605 	mov	w5, #0x30                  	// #48
    2468:	390000e5 	strb	w5, [x7]
    246c:	d100077b 	sub	x27, x27, #0x1
    2470:	aa0303e1 	mov	x1, x3
    2474:	aa1603e0 	mov	x0, x22
    2478:	aa1b03e3 	mov	x3, x27
    247c:	aa1a03e2 	mov	x2, x26
    2480:	f90007e6 	str	x6, [sp, #8]
    2484:	b90013e4 	str	w4, [sp, #16]
    2488:	8b1a02d6 	add	x22, x22, x26
    248c:	b9001be5 	str	w5, [sp, #24]
    2490:	97fffbd8 	bl	13f0 <__memcpy_chk@plt>
    2494:	f94007e6 	ldr	x6, [sp, #8]
    2498:	2a3703e7 	mvn	w7, w23
    249c:	b94013e4 	ldr	w4, [sp, #16]
    24a0:	cb1b00c1 	sub	x1, x6, x27
    24a4:	cb06037b 	sub	x27, x27, x6
    24a8:	f101203f 	cmp	x1, #0x48
    24ac:	d2800906 	mov	x6, #0x48                  	// #72
    24b0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    24b4:	8b1b0023 	add	x3, x1, x27
    24b8:	310006ff 	cmn	w23, #0x1
    24bc:	54000220 	b.eq	2500 <fwp_format_g.constprop.0+0x380>  // b.none
    24c0:	b9401be5 	ldr	w5, [sp, #24]
    24c4:	d2800001 	mov	x1, #0x0                   	// #0
    24c8:	f101207f 	cmp	x3, #0x48
    24cc:	d1000462 	sub	x2, x3, #0x1
    24d0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    24d4:	38216ac5 	strb	w5, [x22, x1]
    24d8:	cb030003 	sub	x3, x0, x3
    24dc:	91000421 	add	x1, x1, #0x1
    24e0:	91000463 	add	x3, x3, #0x1
    24e4:	eb00007f 	cmp	x3, x0
    24e8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    24ec:	cb000063 	sub	x3, x3, x0
    24f0:	8b020063 	add	x3, x3, x2
    24f4:	6b0100ff 	cmp	w7, w1
    24f8:	54fffe8c 	b.gt	24c8 <fwp_format_g.constprop.0+0x348>
    24fc:	8b2742d6 	add	x22, x22, w7, uxtw
    2500:	f101207f 	cmp	x3, #0x48
    2504:	d2800905 	mov	x5, #0x48                  	// #72
    2508:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    250c:	aa1603e0 	mov	x0, x22
    2510:	cb0300a1 	sub	x1, x5, x3
    2514:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    2518:	91000421 	add	x1, x1, #0x1
    251c:	d1000463 	sub	x3, x3, #0x1
    2520:	eb05003f 	cmp	x1, x5
    2524:	38001402 	strb	w2, [x0], #1
    2528:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    252c:	93407f82 	sxtw	x2, w28
    2530:	cb050025 	sub	x5, x1, x5
    2534:	aa1303e1 	mov	x1, x19
    2538:	8b0300a3 	add	x3, x5, x3
    253c:	8b1802d3 	add	x19, x22, x24
    2540:	97fffbac 	bl	13f0 <__memcpy_chk@plt>
    2544:	17ffff6b 	b	22f0 <fwp_format_g.constprop.0+0x170>
    2548:	d1000421 	sub	x1, x1, #0x1
    254c:	38616aa0 	ldrb	w0, [x21, x1]
    2550:	7100b81f 	cmp	w0, #0x2e
    2554:	54fff021 	b.ne	2358 <fwp_format_g.constprop.0+0x1d8>  // b.any
    2558:	38216abf 	strb	wzr, [x21, x1]
    255c:	17ffff7f 	b	2358 <fwp_format_g.constprop.0+0x1d8>
    2560:	910187e7 	add	x7, sp, #0x61
    2564:	910183f9 	add	x25, sp, #0x60
    2568:	d28008fb 	mov	x27, #0x47                  	// #71
    256c:	390183e0 	strb	w0, [sp, #96]
    2570:	17ffff3b 	b	225c <fwp_format_g.constprop.0+0xdc>
    2574:	38336b3f 	strb	wzr, [x25, x19]
    2578:	17ffffac 	b	2428 <fwp_format_g.constprop.0+0x2a8>
    257c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2580:	97fffbc8 	bl	14a0 <__stack_chk_fail@plt>

0000000000002584 <fwp_heap_report>:
    2584:	d105c3ff 	sub	sp, sp, #0x170
    2588:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xcd0>
    258c:	91144042 	add	x2, x2, #0x510
    2590:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x17668>
    2594:	f947e821 	ldr	x1, [x1, #4048]
    2598:	a9117bfd 	stp	x29, x30, [sp, #272]
    259c:	910443fd 	add	x29, sp, #0x110
    25a0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    25a4:	f947f400 	ldr	x0, [x0, #4072]
    25a8:	a9135bf5 	stp	x21, x22, [sp, #304]
    25ac:	a91463f7 	stp	x23, x24, [sp, #320]
    25b0:	a9156bf9 	stp	x25, x26, [sp, #336]
    25b4:	6d1627e8 	stp	d8, d9, [sp, #352]
    25b8:	fd4a1c48 	ldr	d8, [x2, #5176]
    25bc:	fd4a2049 	ldr	d9, [x2, #5184]
    25c0:	f9400036 	ldr	x22, [x1]
    25c4:	f9400001 	ldr	x1, [x0]
    25c8:	f90087e1 	str	x1, [sp, #264]
    25cc:	d2800001 	mov	x1, #0x0                   	// #0
    25d0:	f949e459 	ldr	x25, [x2, #5064]
    25d4:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    25d8:	f94a1057 	ldr	x23, [x2, #5152]
    25dc:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    25e0:	f94a1458 	ldr	x24, [x2, #5160]
    25e4:	91230021 	add	x1, x1, #0x8c0
    25e8:	91232000 	add	x0, x0, #0x8c8
    25ec:	97fffb91 	bl	1430 <fopen@plt>
    25f0:	b4000760 	cbz	x0, 26dc <fwp_heap_report+0x158>
    25f4:	528daad5 	mov	w21, #0x6d56                	// #27990
    25f8:	a91253f3 	stp	x19, x20, [sp, #288]
    25fc:	aa0003f4 	mov	x20, x0
    2600:	910023f3 	add	x19, sp, #0x8
    2604:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2608:	72aae915 	movk	w21, #0x5748, lsl #16
    260c:	d503201f 	nop
    2610:	aa1403e2 	mov	x2, x20
    2614:	aa1303e0 	mov	x0, x19
    2618:	52802001 	mov	w1, #0x100                 	// #256
    261c:	97fffc0d 	bl	1650 <fgets@plt>
    2620:	b4000280 	cbz	x0, 2670 <fwp_heap_report+0xec>
    2624:	b9400261 	ldr	w1, [x19]
    2628:	6b15003f 	cmp	w1, w21
    262c:	54ffff21 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    2630:	39401260 	ldrb	w0, [x19, #4]
    2634:	7101341f 	cmp	w0, #0x4d
    2638:	54fffec1 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    263c:	394037e0 	ldrb	w0, [sp, #13]
    2640:	7100e81f 	cmp	w0, #0x3a
    2644:	54fffe61 	b.ne	2610 <fwp_heap_report+0x8c>  // b.any
    2648:	52800142 	mov	w2, #0xa                   	// #10
    264c:	d2800001 	mov	x1, #0x0                   	// #0
    2650:	91003be0 	add	x0, sp, #0xe
    2654:	97fffbbb 	bl	1540 <strtol@plt>
    2658:	aa1403e2 	mov	x2, x20
    265c:	aa0003fa 	mov	x26, x0
    2660:	52802001 	mov	w1, #0x100                 	// #256
    2664:	aa1303e0 	mov	x0, x19
    2668:	97fffbfa 	bl	1650 <fgets@plt>
    266c:	b5fffdc0 	cbnz	x0, 2624 <fwp_heap_report+0xa0>
    2670:	aa1403e0 	mov	x0, x20
    2674:	97fffb6b 	bl	1420 <fclose@plt>
    2678:	a95253f3 	ldp	x19, x20, [sp, #288]
    267c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    2680:	f947f400 	ldr	x0, [x0, #4072]
    2684:	f94087e2 	ldr	x2, [sp, #264]
    2688:	f9400001 	ldr	x1, [x0]
    268c:	eb010042 	subs	x2, x2, x1
    2690:	d2800001 	mov	x1, #0x0                   	// #0
    2694:	54000281 	b.ne	26e4 <fwp_heap_report+0x160>  // b.any
    2698:	a9517bfd 	ldp	x29, x30, [sp, #272]
    269c:	aa1a03e6 	mov	x6, x26
    26a0:	aa1903e5 	mov	x5, x25
    26a4:	aa1803e4 	mov	x4, x24
    26a8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    26ac:	aa1703e3 	mov	x3, x23
    26b0:	a95463f7 	ldp	x23, x24, [sp, #320]
    26b4:	aa1603e0 	mov	x0, x22
    26b8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    26bc:	1e604121 	fmov	d1, d9
    26c0:	1e604100 	fmov	d0, d8
    26c4:	90000022 	adrp	x2, 6000 <fwp_main_thread+0x13fc>
    26c8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    26cc:	9123a042 	add	x2, x2, #0x8e8
    26d0:	9105c3ff 	add	sp, sp, #0x170
    26d4:	52800041 	mov	w1, #0x2                   	// #2
    26d8:	17fffb8e 	b	1510 <__fprintf_chk@plt>
    26dc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    26e0:	17ffffe7 	b	267c <fwp_heap_report+0xf8>
    26e4:	a91253f3 	stp	x19, x20, [sp, #288]
    26e8:	97fffb6e 	bl	14a0 <__stack_chk_fail@plt>
    26ec:	d503201f 	nop

00000000000026f0 <fwp_heap_init>:
    26f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    26f4:	90000183 	adrp	x3, 32000 <fwp_heap+0xaf0>
    26f8:	91104061 	add	x1, x3, #0x410
    26fc:	910003fd 	mov	x29, sp
    2700:	a90153f3 	stp	x19, x20, [sp, #16]
    2704:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    2708:	91144262 	add	x2, x19, #0x510
    270c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2710:	52800024 	mov	w4, #0x1                   	// #1
    2714:	52800200 	mov	w0, #0x10                  	// #16
    2718:	b913a444 	str	w4, [x2, #5028]
    271c:	d503201f 	nop
    2720:	b8004420 	str	w0, [x1], #4
    2724:	11004000 	add	w0, w0, #0x10
    2728:	7104401f 	cmp	w0, #0x110
    272c:	54ffffa1 	b.ne	2720 <fwp_heap_init+0x30>  // b.any
    2730:	90000022 	adrp	x2, 6000 <fwp_main_thread+0x13fc>
    2734:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2738:	90000181 	adrp	x1, 32000 <fwp_heap+0xaf0>
    273c:	91114021 	add	x1, x1, #0x450
    2740:	3dc34c43 	ldr	q3, [x2, #3376]
    2744:	d2800000 	mov	x0, #0x0                   	// #0
    2748:	4e040401 	dup	v1.4s, v0.s[0]
    274c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    2750:	0f215400 	shl	v0.2s, v0.2s, #1
    2754:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    2758:	3ca06821 	str	q1, [x1, x0]
    275c:	91004000 	add	x0, x0, #0x10
    2760:	f101801f 	cmp	x0, #0x60
    2764:	54ffff21 	b.ne	2748 <fwp_heap_init+0x58>  // b.any
    2768:	90000184 	adrp	x4, 32000 <fwp_heap+0xaf0>
    276c:	91104063 	add	x3, x3, #0x410
    2770:	9112c084 	add	x4, x4, #0x4b0
    2774:	91144266 	add	x6, x19, #0x510
    2778:	d2800002 	mov	x2, #0x0                   	// #0
    277c:	d2800000 	mov	x0, #0x0                   	// #0
    2780:	d2880205 	mov	x5, #0x4010                	// #16400
    2784:	d503201f 	nop
    2788:	910f0001 	add	x1, x0, #0x3c0
    278c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2790:	eb02003f 	cmp	x1, x2
    2794:	540000a2 	b.cs	27a8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    2798:	91000400 	add	x0, x0, #0x1
    279c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    27a0:	eb02003f 	cmp	x1, x2
    27a4:	54ffffa3 	b.cc	2798 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    27a8:	91004042 	add	x2, x2, #0x10
    27ac:	38001480 	strb	w0, [x4], #1
    27b0:	eb05005f 	cmp	x2, x5
    27b4:	54fffea1 	b.ne	2788 <fwp_heap_init+0x98>  // b.any
    27b8:	528000b5 	mov	w21, #0x5                   	// #5
    27bc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    27c0:	14000004 	b	27d0 <fwp_heap_init+0xe0>
    27c4:	d342fe94 	lsr	x20, x20, #2
    27c8:	710006b5 	subs	w21, w21, #0x1
    27cc:	54000720 	b.eq	28b0 <fwp_heap_init+0x1c0>  // b.none
    27d0:	91404296 	add	x22, x20, #0x10, lsl #12
    27d4:	d2800005 	mov	x5, #0x0                   	// #0
    27d8:	aa1603e1 	mov	x1, x22
    27dc:	12800004 	mov	w4, #0xffffffff            	// #-1
    27e0:	52880443 	mov	w3, #0x4022                	// #16418
    27e4:	52800002 	mov	w2, #0x0                   	// #0
    27e8:	d2800000 	mov	x0, #0x0                   	// #0
    27ec:	97fffb51 	bl	1530 <mmap@plt>
    27f0:	aa0003e6 	mov	x6, x0
    27f4:	b100041f 	cmn	x0, #0x1
    27f8:	54fffe60 	b.eq	27c4 <fwp_heap_init+0xd4>  // b.none
    27fc:	b40005a0 	cbz	x0, 28b0 <fwp_heap_init+0x1c0>
    2800:	d350fe94 	lsr	x20, x20, #16
    2804:	d29fffe0 	mov	x0, #0xffff                	// #65535
    2808:	8b0000c7 	add	x7, x6, x0
    280c:	91144275 	add	x21, x19, #0x510
    2810:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    2814:	8b140a81 	add	x1, x20, x20, lsl #2
    2818:	d2800005 	mov	x5, #0x0                   	// #0
    281c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2820:	d37df021 	lsl	x1, x1, #3
    2824:	52880443 	mov	w3, #0x4022                	// #16418
    2828:	52800002 	mov	w2, #0x0                   	// #0
    282c:	d2800000 	mov	x0, #0x0                   	// #0
    2830:	f909daa7 	str	x7, [x21, #5040]
    2834:	f909dea6 	str	x6, [x21, #5048]
    2838:	f909e2b6 	str	x22, [x21, #5056]
    283c:	f909eab4 	str	x20, [x21, #5072]
    2840:	f90a02a1 	str	x1, [x21, #5120]
    2844:	97fffb3b 	bl	1530 <mmap@plt>
    2848:	aa0003e1 	mov	x1, x0
    284c:	b100041f 	cmn	x0, #0x1
    2850:	54000300 	b.eq	28b0 <fwp_heap_init+0x1c0>  // b.none
    2854:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    2858:	91266000 	add	x0, x0, #0x998
    285c:	f909fea1 	str	x1, [x21, #5112]
    2860:	97fffb74 	bl	1630 <getenv@plt>
    2864:	52800002 	mov	w2, #0x0                   	// #0
    2868:	aa0003e1 	mov	x1, x0
    286c:	b40000e0 	cbz	x0, 2888 <fwp_heap_init+0x198>
    2870:	39400000 	ldrb	w0, [x0]
    2874:	340000a0 	cbz	w0, 2888 <fwp_heap_init+0x198>
    2878:	7100c000 	subs	w0, w0, #0x30
    287c:	54000120 	b.eq	28a0 <fwp_heap_init+0x1b0>  // b.none
    2880:	7100001f 	cmp	w0, #0x0
    2884:	1a9f07e2 	cset	w2, ne	// ne = any
    2888:	91144273 	add	x19, x19, #0x510
    288c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2890:	b913aa62 	str	w2, [x19, #5032]
    2894:	a94153f3 	ldp	x19, x20, [sp, #16]
    2898:	a8c37bfd 	ldp	x29, x30, [sp], #48
    289c:	d65f03c0 	ret
    28a0:	39400420 	ldrb	w0, [x1, #1]
    28a4:	7100001f 	cmp	w0, #0x0
    28a8:	1a9f07e2 	cset	w2, ne	// ne = any
    28ac:	17fffff7 	b	2888 <fwp_heap_init+0x198>
    28b0:	97fffcb8 	bl	1b90 <fwp_heap_oom>

00000000000028b4 <fwp_wake_io>:
    28b4:	d00000e9 	adrp	x9, 20000 <__data_start>
    28b8:	9101c122 	add	x2, x9, #0x70
    28bc:	f9400001 	ldr	x1, [x0]
    28c0:	5280000a 	mov	w10, #0x0                   	// #0
    28c4:	f9401046 	ldr	x6, [x2, #32]
    28c8:	52800008 	mov	w8, #0x0                   	// #0
    28cc:	4f000400 	movi	v0.4s, #0x0
    28d0:	52800027 	mov	w7, #0x1                   	// #1
    28d4:	aa0103e2 	mov	x2, x1
    28d8:	b4000321 	cbz	x1, 293c <fwp_wake_io+0x88>
    28dc:	f9408c25 	ldr	x5, [x1, #280]
    28e0:	39015c27 	strb	w7, [x1, #87]
    28e4:	b4000165 	cbz	x5, 2910 <fwp_wake_io+0x5c>
    28e8:	a9520c24 	ldp	x4, x3, [x1, #288]
    28ec:	b4000364 	cbz	x4, 2958 <fwp_wake_io+0xa4>
    28f0:	f9009483 	str	x3, [x4, #296]
    28f4:	f9409423 	ldr	x3, [x1, #296]
    28f8:	b4000043 	cbz	x3, 2900 <fwp_wake_io+0x4c>
    28fc:	f9009064 	str	x4, [x3, #288]
    2900:	91080023 	add	x3, x1, #0x200
    2904:	f900943f 	str	xzr, [x1, #296]
    2908:	3c918060 	stur	q0, [x3, #-232]
    290c:	f9400001 	ldr	x1, [x0]
    2910:	f9402843 	ldr	x3, [x2, #80]
    2914:	f2001c7f 	tst	x3, #0xff000000ff
    2918:	54fffde1 	b.ne	28d4 <fwp_wake_io+0x20>  // b.any
    291c:	39015047 	strb	w7, [x2, #84]
    2920:	f900805f 	str	xzr, [x2, #256]
    2924:	b40001e6 	cbz	x6, 2960 <fwp_wake_io+0xac>
    2928:	f90080c2 	str	x2, [x6, #256]
    292c:	aa0203e6 	mov	x6, x2
    2930:	52800028 	mov	w8, #0x1                   	// #1
    2934:	aa0103e2 	mov	x2, x1
    2938:	b5fffd21 	cbnz	x1, 28dc <fwp_wake_io+0x28>
    293c:	3400006a 	cbz	w10, 2948 <fwp_wake_io+0x94>
    2940:	9101c120 	add	x0, x9, #0x70
    2944:	f900140b 	str	x11, [x0, #40]
    2948:	34000068 	cbz	w8, 2954 <fwp_wake_io+0xa0>
    294c:	9101c129 	add	x9, x9, #0x70
    2950:	f9001126 	str	x6, [x9, #32]
    2954:	d65f03c0 	ret
    2958:	f90000a3 	str	x3, [x5]
    295c:	17ffffe7 	b	28f8 <fwp_wake_io+0x44>
    2960:	aa0203eb 	mov	x11, x2
    2964:	5280002a 	mov	w10, #0x1                   	// #1
    2968:	17fffff1 	b	292c <fwp_wake_io+0x78>
    296c:	d503201f 	nop

0000000000002970 <fwp_poll_events>:
    2970:	d10103ff 	sub	sp, sp, #0x40
    2974:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    2978:	f947f400 	ldr	x0, [x0, #4072]
    297c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2980:	910083fd 	add	x29, sp, #0x20
    2984:	a90353f3 	stp	x19, x20, [sp, #48]
    2988:	d00000f4 	adrp	x20, 20000 <__data_start>
    298c:	f9400001 	ldr	x1, [x0]
    2990:	f9000fe1 	str	x1, [sp, #24]
    2994:	d2800001 	mov	x1, #0x0                   	// #0
    2998:	97fffdd2 	bl	20e0 <fwp_now_ns>
    299c:	9101c281 	add	x1, x20, #0x70
    29a0:	f9401833 	ldr	x19, [x1, #48]
    29a4:	b4000e93 	cbz	x19, 2b74 <fwp_poll_events+0x204>
    29a8:	aa1303e1 	mov	x1, x19
    29ac:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    29b0:	14000005 	b	29c4 <fwp_poll_events+0x54>
    29b4:	f9408821 	ldr	x1, [x1, #272]
    29b8:	eb03005f 	cmp	x2, x3
    29bc:	9a83d042 	csel	x2, x2, x3, le
    29c0:	b40000c1 	cbz	x1, 29d8 <fwp_poll_events+0x68>
    29c4:	f9403423 	ldr	x3, [x1, #104]
    29c8:	b6ffff62 	tbz	x2, #63, 29b4 <fwp_poll_events+0x44>
    29cc:	f9408821 	ldr	x1, [x1, #272]
    29d0:	aa0303e2 	mov	x2, x3
    29d4:	b5ffff81 	cbnz	x1, 29c4 <fwp_poll_events+0x54>
    29d8:	b7f80ce2 	tbnz	x2, #63, 2b74 <fwp_poll_events+0x204>
    29dc:	cb000042 	sub	x2, x2, x0
    29e0:	f100005f 	cmp	x2, #0x0
    29e4:	540005cd 	b.le	2a9c <fwp_poll_events+0x12c>
    29e8:	d2869b60 	mov	x0, #0x34db                	// #13531
    29ec:	d2884801 	mov	x1, #0x4240                	// #16960
    29f0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    29f4:	f2a001e1 	movk	x1, #0xf, lsl #16
    29f8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    29fc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2a00:	f2e86360 	movk	x0, #0x431b, lsl #48
    2a04:	9b407c40 	smulh	x0, x2, x0
    2a08:	9352fc00 	asr	x0, x0, #18
    2a0c:	cb82fc00 	sub	x0, x0, x2, asr #63
    2a10:	9b018802 	msub	x2, x0, x1, x2
    2a14:	f100005f 	cmp	x2, #0x0
    2a18:	9a800400 	cinc	x0, x0, ne	// ne = any
    2a1c:	eb03001f 	cmp	x0, x3
    2a20:	54000a0c 	b.gt	2b60 <fwp_poll_events+0x1f0>
    2a24:	340003c0 	cbz	w0, 2a9c <fwp_poll_events+0x12c>
    2a28:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2a2c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2a30:	72a20c42 	movk	w2, #0x1062, lsl #16
    2a34:	9ba27c02 	umull	x2, w0, w2
    2a38:	d366fc43 	lsr	x3, x2, #38
    2a3c:	aa0303e2 	mov	x2, x3
    2a40:	1b048063 	msub	w3, w3, w4, w0
    2a44:	9b217c63 	smull	x3, w3, w1
    2a48:	d2800001 	mov	x1, #0x0                   	// #0
    2a4c:	910023e0 	add	x0, sp, #0x8
    2a50:	a9008fe2 	stp	x2, x3, [sp, #8]
    2a54:	97fffac7 	bl	1570 <nanosleep@plt>
    2a58:	9101c280 	add	x0, x20, #0x70
    2a5c:	f9401813 	ldr	x19, [x0, #48]
    2a60:	97fffda0 	bl	20e0 <fwp_now_ns>
    2a64:	aa0003e6 	mov	x6, x0
    2a68:	b50001f3 	cbnz	x19, 2aa4 <fwp_poll_events+0x134>
    2a6c:	d503201f 	nop
    2a70:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    2a74:	f947f400 	ldr	x0, [x0, #4072]
    2a78:	f9400fe2 	ldr	x2, [sp, #24]
    2a7c:	f9400001 	ldr	x1, [x0]
    2a80:	eb010042 	subs	x2, x2, x1
    2a84:	d2800001 	mov	x1, #0x0                   	// #0
    2a88:	540008c1 	b.ne	2ba0 <fwp_poll_events+0x230>  // b.any
    2a8c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2a90:	a94353f3 	ldp	x19, x20, [sp, #48]
    2a94:	910103ff 	add	sp, sp, #0x40
    2a98:	d65f03c0 	ret
    2a9c:	97fffd91 	bl	20e0 <fwp_now_ns>
    2aa0:	aa0003e6 	mov	x6, x0
    2aa4:	4f000400 	movi	v0.4s, #0x0
    2aa8:	9101c288 	add	x8, x20, #0x70
    2aac:	52800027 	mov	w7, #0x1                   	// #1
    2ab0:	f9403661 	ldr	x1, [x19, #104]
    2ab4:	aa1303e5 	mov	x5, x19
    2ab8:	f9408a73 	ldr	x19, [x19, #272]
    2abc:	eb06003f 	cmp	x1, x6
    2ac0:	5400032c 	b.gt	2b24 <fwp_poll_events+0x1b4>
    2ac4:	394154a0 	ldrb	w0, [x5, #85]
    2ac8:	36000120 	tbz	w0, #0, 2aec <fwp_poll_events+0x17c>
    2acc:	f94084a0 	ldr	x0, [x5, #264]
    2ad0:	b40003c0 	cbz	x0, 2b48 <fwp_poll_events+0x1d8>
    2ad4:	f9008813 	str	x19, [x0, #272]
    2ad8:	b4000053 	cbz	x19, 2ae0 <fwp_poll_events+0x170>
    2adc:	f9008660 	str	x0, [x19, #264]
    2ae0:	910800a0 	add	x0, x5, #0x200
    2ae4:	390154bf 	strb	wzr, [x5, #85]
    2ae8:	3c908000 	stur	q0, [x0, #-248]
    2aec:	f94030a0 	ldr	x0, [x5, #96]
    2af0:	390158a7 	strb	w7, [x5, #86]
    2af4:	f100001f 	cmp	x0, #0x0
    2af8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2afc:	5400018d 	b.le	2b2c <fwp_poll_events+0x1bc>
    2b00:	f94028a0 	ldr	x0, [x5, #80]
    2b04:	f2001c1f 	tst	x0, #0xff000000ff
    2b08:	540000e1 	b.ne	2b24 <fwp_poll_events+0x1b4>  // b.any
    2b0c:	f9401100 	ldr	x0, [x8, #32]
    2b10:	390150a7 	strb	w7, [x5, #84]
    2b14:	f90080bf 	str	xzr, [x5, #256]
    2b18:	b40001e0 	cbz	x0, 2b54 <fwp_poll_events+0x1e4>
    2b1c:	f9001105 	str	x5, [x8, #32]
    2b20:	f9008005 	str	x5, [x0, #256]
    2b24:	b5fffc73 	cbnz	x19, 2ab0 <fwp_poll_events+0x140>
    2b28:	17ffffd2 	b	2a70 <fwp_poll_events+0x100>
    2b2c:	394144a0 	ldrb	w0, [x5, #81]
    2b30:	3707fe80 	tbnz	w0, #0, 2b00 <fwp_poll_events+0x190>
    2b34:	394140a0 	ldrb	w0, [x5, #80]
    2b38:	3707fe40 	tbnz	w0, #0, 2b00 <fwp_poll_events+0x190>
    2b3c:	aa0503e0 	mov	x0, x5
    2b40:	97fffd14 	bl	1f90 <fwp_cancel_tree.part.0>
    2b44:	17ffffef 	b	2b00 <fwp_poll_events+0x190>
    2b48:	9101c281 	add	x1, x20, #0x70
    2b4c:	f9001833 	str	x19, [x1, #48]
    2b50:	17ffffe2 	b	2ad8 <fwp_poll_events+0x168>
    2b54:	f9001105 	str	x5, [x8, #32]
    2b58:	f9001505 	str	x5, [x8, #40]
    2b5c:	17fffff2 	b	2b24 <fwp_poll_events+0x1b4>
    2b60:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2b64:	d2989362 	mov	x2, #0xc49b                	// #50331
    2b68:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2b6c:	f2a00402 	movk	x2, #0x20, lsl #16
    2b70:	17ffffb6 	b	2a48 <fwp_poll_events+0xd8>
    2b74:	97fffbf7 	bl	1b50 <fwp_flush>
    2b78:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x17668>
    2b7c:	f947e863 	ldr	x3, [x3, #4048]
    2b80:	d2800562 	mov	x2, #0x2b                  	// #43
    2b84:	d2800021 	mov	x1, #0x1                   	// #1
    2b88:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    2b8c:	9126a000 	add	x0, x0, #0x9a8
    2b90:	f9400063 	ldr	x3, [x3]
    2b94:	97fffa83 	bl	15a0 <fwrite@plt>
    2b98:	52800ca0 	mov	w0, #0x65                  	// #101
    2b9c:	97fff9ed 	bl	1350 <exit@plt>
    2ba0:	97fffa40 	bl	14a0 <__stack_chk_fail@plt>

0000000000002ba4 <fwp_rc_forget_slot>:
    2ba4:	aa0003e1 	mov	x1, x0
    2ba8:	39400000 	ldrb	w0, [x0]
    2bac:	7103fc1f 	cmp	w0, #0xff
    2bb0:	54000040 	b.eq	2bb8 <fwp_rc_forget_slot+0x14>  // b.none
    2bb4:	d65f03c0 	ret
    2bb8:	ca414420 	eor	x0, x1, x1, lsr #17
    2bbc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2bc0:	ca402400 	eor	x0, x0, x0, lsr #9
    2bc4:	910003fd 	mov	x29, sp
    2bc8:	92401c00 	and	x0, x0, #0xff
    2bcc:	f9000bf3 	str	x19, [sp, #16]
    2bd0:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    2bd4:	91144262 	add	x2, x19, #0x510
    2bd8:	910a2403 	add	x3, x0, #0x289
    2bdc:	8b000c40 	add	x0, x2, x0, lsl #3
    2be0:	8b030c43 	add	x3, x2, x3, lsl #3
    2be4:	f94a2400 	ldr	x0, [x0, #5192]
    2be8:	b50000a0 	cbnz	x0, 2bfc <fwp_rc_forget_slot+0x58>
    2bec:	14000011 	b	2c30 <fwp_rc_forget_slot+0x8c>
    2bf0:	91004003 	add	x3, x0, #0x10
    2bf4:	f9400800 	ldr	x0, [x0, #16]
    2bf8:	b40001c0 	cbz	x0, 2c30 <fwp_rc_forget_slot+0x8c>
    2bfc:	f9400002 	ldr	x2, [x0]
    2c00:	eb02003f 	cmp	x1, x2
    2c04:	54ffff61 	b.ne	2bf0 <fwp_rc_forget_slot+0x4c>  // b.any
    2c08:	f9400801 	ldr	x1, [x0, #16]
    2c0c:	91144273 	add	x19, x19, #0x510
    2c10:	f9000061 	str	x1, [x3]
    2c14:	97fffa53 	bl	1560 <free@plt>
    2c18:	f94e2660 	ldr	x0, [x19, #7240]
    2c1c:	d1000400 	sub	x0, x0, #0x1
    2c20:	f90e2660 	str	x0, [x19, #7240]
    2c24:	f9400bf3 	ldr	x19, [sp, #16]
    2c28:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2c2c:	d65f03c0 	ret
    2c30:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    2c34:	91276000 	add	x0, x0, #0x9d8
    2c38:	97fffd1a 	bl	20a0 <fwp_trap>
    2c3c:	d503201f 	nop

0000000000002c40 <fwp_rc_prepare_chunk>:
    2c40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2c44:	910003fd 	mov	x29, sp
    2c48:	a9025bf5 	stp	x21, x22, [sp, #32]
    2c4c:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xcd0>
    2c50:	911442c2 	add	x2, x22, #0x510
    2c54:	b9401c03 	ldr	w3, [x0, #28]
    2c58:	aa0103f5 	mov	x21, x1
    2c5c:	a90153f3 	stp	x19, x20, [sp, #16]
    2c60:	aa0003f4 	mov	x20, x0
    2c64:	f94e2440 	ldr	x0, [x2, #7240]
    2c68:	b4000440 	cbz	x0, 2cf0 <fwp_rc_prepare_chunk+0xb0>
    2c6c:	d2800013 	mov	x19, #0x0                   	// #0
    2c70:	35000203 	cbnz	w3, 2cb0 <fwp_rc_prepare_chunk+0x70>
    2c74:	b4000361 	cbz	x1, 2ce0 <fwp_rc_prepare_chunk+0xa0>
    2c78:	f9401280 	ldr	x0, [x20, #32]
    2c7c:	97fffa39 	bl	1560 <free@plt>
    2c80:	aa1503e0 	mov	x0, x21
    2c84:	d2800021 	mov	x1, #0x1                   	// #1
    2c88:	97fff9fe 	bl	1480 <calloc@plt>
    2c8c:	f9001280 	str	x0, [x20, #32]
    2c90:	b5000460 	cbnz	x0, 2d1c <fwp_rc_prepare_chunk+0xdc>
    2c94:	97fffbbf 	bl	1b90 <fwp_heap_oom>
    2c98:	97ffffc3 	bl	2ba4 <fwp_rc_forget_slot>
    2c9c:	91000673 	add	x19, x19, #0x1
    2ca0:	b9401e83 	ldr	w3, [x20, #28]
    2ca4:	eb13007f 	cmp	x3, x19
    2ca8:	54000169 	b.ls	2cd4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2cac:	d503201f 	nop
    2cb0:	f9401283 	ldr	x3, [x20, #32]
    2cb4:	8b130060 	add	x0, x3, x19
    2cb8:	38736863 	ldrb	w3, [x3, x19]
    2cbc:	7103fc7f 	cmp	w3, #0xff
    2cc0:	54fffec0 	b.eq	2c98 <fwp_rc_prepare_chunk+0x58>  // b.none
    2cc4:	b9401e83 	ldr	w3, [x20, #28]
    2cc8:	91000673 	add	x19, x19, #0x1
    2ccc:	eb13007f 	cmp	x3, x19
    2cd0:	54ffff08 	b.hi	2cb0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2cd4:	eb0302bf 	cmp	x21, x3
    2cd8:	54000121 	b.ne	2cfc <fwp_rc_prepare_chunk+0xbc>  // b.any
    2cdc:	b5000335 	cbnz	x21, 2d40 <fwp_rc_prepare_chunk+0x100>
    2ce0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ce4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ce8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2cec:	d65f03c0 	ret
    2cf0:	2a0303e3 	mov	w3, w3
    2cf4:	eb0302bf 	cmp	x21, x3
    2cf8:	54ffff20 	b.eq	2cdc <fwp_rc_prepare_chunk+0x9c>  // b.none
    2cfc:	911442c2 	add	x2, x22, #0x510
    2d00:	f9401280 	ldr	x0, [x20, #32]
    2d04:	f94e2841 	ldr	x1, [x2, #7248]
    2d08:	cb030021 	sub	x1, x1, x3
    2d0c:	f90e2841 	str	x1, [x2, #7248]
    2d10:	97fffa14 	bl	1560 <free@plt>
    2d14:	b5fffb75 	cbnz	x21, 2c80 <fwp_rc_prepare_chunk+0x40>
    2d18:	f900129f 	str	xzr, [x20, #32]
    2d1c:	911442d6 	add	x22, x22, #0x510
    2d20:	f94e2ac0 	ldr	x0, [x22, #7248]
    2d24:	b9001e95 	str	w21, [x20, #28]
    2d28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d2c:	8b150000 	add	x0, x0, x21
    2d30:	f90e2ac0 	str	x0, [x22, #7248]
    2d34:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2d38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d3c:	d65f03c0 	ret
    2d40:	f9401280 	ldr	x0, [x20, #32]
    2d44:	aa1503e2 	mov	x2, x21
    2d48:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d4c:	52800001 	mov	w1, #0x0                   	// #0
    2d50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2d54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d58:	17fff9c6 	b	1470 <memset@plt>
    2d5c:	d503201f 	nop

0000000000002d60 <fwp_heap_refill>:
    2d60:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2d64:	910003fd 	mov	x29, sp
    2d68:	a9025bf5 	stp	x21, x22, [sp, #32]
    2d6c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    2d70:	911442b5 	add	x21, x21, #0x510
    2d74:	aa0003f6 	mov	x22, x0
    2d78:	d2800020 	mov	x0, #0x1                   	// #1
    2d7c:	a90153f3 	stp	x19, x20, [sp, #16]
    2d80:	a90363f7 	stp	x23, x24, [sp, #48]
    2d84:	2a0103f7 	mov	w23, w1
    2d88:	2a0203f8 	mov	w24, w2
    2d8c:	97fffbc1 	bl	1c90 <fwp_heap_chunks>
    2d90:	aa0003f3 	mov	x19, x0
    2d94:	f949fea2 	ldr	x2, [x21, #5112]
    2d98:	8b000800 	add	x0, x0, x0, lsl #2
    2d9c:	2a1703e1 	mov	w1, w23
    2da0:	52800025 	mov	w5, #0x1                   	// #1
    2da4:	d37df000 	lsl	x0, x0, #3
    2da8:	910f0021 	add	x1, x1, #0x3c0
    2dac:	8b000054 	add	x20, x2, x0
    2db0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2db4:	52a00024 	mov	w4, #0x10000               	// #65536
    2db8:	38206845 	strb	w5, [x2, x0]
    2dbc:	aa1403e0 	mov	x0, x20
    2dc0:	39000698 	strb	w24, [x20, #1]
    2dc4:	39000a97 	strb	w23, [x20, #2]
    2dc8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2dcc:	b9000681 	str	w1, [x20, #4]
    2dd0:	2a0103e5 	mov	w5, w1
    2dd4:	8b0300a2 	add	x2, x5, x3
    2dd8:	1ac10881 	udiv	w1, w4, w1
    2ddc:	9ac50842 	udiv	x2, x2, x5
    2de0:	b9000a81 	str	w1, [x20, #8]
    2de4:	92404021 	and	x1, x1, #0x1ffff
    2de8:	b9001a82 	str	w2, [x20, #24]
    2dec:	97ffff95 	bl	2c40 <fwp_rc_prepare_chunk>
    2df0:	f949daa0 	ldr	x0, [x21, #5040]
    2df4:	29408a81 	ldp	w1, w2, [x20, #4]
    2df8:	8b134000 	add	x0, x0, x19, lsl #16
    2dfc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e00:	8b214003 	add	x3, x0, w1, uxtw
    2e04:	9ba20021 	umaddl	x1, w1, w2, x0
    2e08:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e0c:	a90086c3 	stp	x3, x1, [x22, #8]
    2e10:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e14:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2e18:	d65f03c0 	ret
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_mem_free>:
    2e20:	b40003c0 	cbz	x0, 2e98 <fwp_mem_free+0x78>
    2e24:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2e28:	910003fd 	mov	x29, sp
    2e2c:	a9025bf5 	stp	x21, x22, [sp, #32]
    2e30:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    2e34:	911442a1 	add	x1, x21, #0x510
    2e38:	a90153f3 	stp	x19, x20, [sp, #16]
    2e3c:	aa0003f3 	mov	x19, x0
    2e40:	f949d823 	ldr	x3, [x1, #5040]
    2e44:	f949ec22 	ldr	x2, [x1, #5080]
    2e48:	cb030000 	sub	x0, x0, x3
    2e4c:	eb02401f 	cmp	x0, x2, lsl #16
    2e50:	540001c2 	b.cs	2e88 <fwp_mem_free+0x68>  // b.hs, b.nlast
    2e54:	d350fc16 	lsr	x22, x0, #16
    2e58:	a90363f7 	stp	x23, x24, [sp, #48]
    2e5c:	f949fc22 	ldr	x2, [x1, #5112]
    2e60:	8b160ad4 	add	x20, x22, x22, lsl #2
    2e64:	d37df294 	lsl	x20, x20, #3
    2e68:	ab140057 	adds	x23, x2, x20
    2e6c:	540000c0 	b.eq	2e84 <fwp_mem_free+0x64>  // b.none
    2e70:	38746842 	ldrb	w2, [x2, x20]
    2e74:	7100045f 	cmp	w2, #0x1
    2e78:	54000120 	b.eq	2e9c <fwp_mem_free+0x7c>  // b.none
    2e7c:	7100085f 	cmp	w2, #0x2
    2e80:	540005e0 	b.eq	2f3c <fwp_mem_free+0x11c>  // b.none
    2e84:	a94363f7 	ldp	x23, x24, [sp, #48]
    2e88:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e90:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2e94:	d65f03c0 	ret
    2e98:	d65f03c0 	ret
    2e9c:	f94012f8 	ldr	x24, [x23, #32]
    2ea0:	b94006e1 	ldr	w1, [x23, #4]
    2ea4:	f90023f9 	str	x25, [sp, #64]
    2ea8:	2a0103e2 	mov	w2, w1
    2eac:	394006f9 	ldrb	w25, [x23, #1]
    2eb0:	39400af4 	ldrb	w20, [x23, #2]
    2eb4:	b4000158 	cbz	x24, 2edc <fwp_mem_free+0xbc>
    2eb8:	92403e76 	and	x22, x19, #0xffff
    2ebc:	9ac20ad6 	udiv	x22, x22, x2
    2ec0:	38766b01 	ldrb	w1, [x24, x22]
    2ec4:	8b160300 	add	x0, x24, x22
    2ec8:	7103fc3f 	cmp	w1, #0xff
    2ecc:	54000980 	b.eq	2ffc <fwp_mem_free+0x1dc>  // b.none
    2ed0:	38366b1f 	strb	wzr, [x24, x22]
    2ed4:	b94006e1 	ldr	w1, [x23, #4]
    2ed8:	2a0103e2 	mov	w2, w1
    2edc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    2ee0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    2ee4:	cb390000 	sub	x0, x0, w25, uxtb
    2ee8:	8b340074 	add	x20, x3, w20, uxtb
    2eec:	911442b5 	add	x21, x21, #0x510
    2ef0:	1e630021 	ucvtf	d1, w1
    2ef4:	d37ae400 	lsl	x0, x0, #6
    2ef8:	8b140c14 	add	x20, x0, x20, lsl #3
    2efc:	a94363f7 	ldp	x23, x24, [sp, #48]
    2f00:	f8746aa0 	ldr	x0, [x21, x20]
    2f04:	f94023f9 	ldr	x25, [sp, #64]
    2f08:	aa2003e0 	mvn	x0, x0
    2f0c:	fd4a22a0 	ldr	d0, [x21, #5184]
    2f10:	f9000260 	str	x0, [x19]
    2f14:	f8346ab3 	str	x19, [x21, x20]
    2f18:	f94a12a0 	ldr	x0, [x21, #5152]
    2f1c:	1e612800 	fadd	d0, d0, d1
    2f20:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f24:	cb020000 	sub	x0, x0, x2
    2f28:	f90a12a0 	str	x0, [x21, #5152]
    2f2c:	fd0a22a0 	str	d0, [x21, #5184]
    2f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f34:	a8c57bfd 	ldp	x29, x30, [sp], #80
    2f38:	d65f03c0 	ret
    2f3c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    2f40:	8b000063 	add	x3, x3, x0
    2f44:	eb03027f 	cmp	x19, x3
    2f48:	54fff9e1 	b.ne	2e84 <fwp_mem_free+0x64>  // b.any
    2f4c:	fd400ae1 	ldr	d1, [x23, #16]
    2f50:	fd4a2020 	ldr	d0, [x1, #5184]
    2f54:	f9400ae0 	ldr	x0, [x23, #16]
    2f58:	7e61d821 	ucvtf	d1, d1
    2f5c:	f94a1022 	ldr	x2, [x1, #5152]
    2f60:	f94012f3 	ldr	x19, [x23, #32]
    2f64:	1e612800 	fadd	d0, d0, d1
    2f68:	cb000042 	sub	x2, x2, x0
    2f6c:	f90a1022 	str	x2, [x1, #5152]
    2f70:	fd0a2020 	str	d0, [x1, #5184]
    2f74:	b40000b3 	cbz	x19, 2f88 <fwp_mem_free+0x168>
    2f78:	39400260 	ldrb	w0, [x19]
    2f7c:	7103fc1f 	cmp	w0, #0xff
    2f80:	54000380 	b.eq	2ff0 <fwp_mem_free+0x1d0>  // b.none
    2f84:	3900027f 	strb	wzr, [x19]
    2f88:	b9400ee2 	ldr	w2, [x23, #12]
    2f8c:	b4000142 	cbz	x2, 2fb4 <fwp_mem_free+0x194>
    2f90:	911442a1 	add	x1, x21, #0x510
    2f94:	8b160040 	add	x0, x2, x22
    2f98:	8b000800 	add	x0, x0, x0, lsl #2
    2f9c:	f949fc21 	ldr	x1, [x1, #5112]
    2fa0:	8b140034 	add	x20, x1, x20
    2fa4:	8b000c20 	add	x0, x1, x0, lsl #3
    2fa8:	3802869f 	strb	wzr, [x20], #40
    2fac:	eb00029f 	cmp	x20, x0
    2fb0:	54ffffc1 	b.ne	2fa8 <fwp_mem_free+0x188>  // b.any
    2fb4:	911442a0 	add	x0, x21, #0x510
    2fb8:	f94a1801 	ldr	x1, [x0, #5168]
    2fbc:	f949f803 	ldr	x3, [x0, #5104]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f90a1801 	str	x1, [x0, #5168]
    2fc8:	eb16007f 	cmp	x3, x22
    2fcc:	54000049 	b.ls	2fd4 <fwp_mem_free+0x1b4>  // b.plast
    2fd0:	f909f816 	str	x22, [x0, #5104]
    2fd4:	911442b5 	add	x21, x21, #0x510
    2fd8:	f949f6a0 	ldr	x0, [x21, #5096]
    2fdc:	eb16001f 	cmp	x0, x22
    2fe0:	54fff529 	b.ls	2e84 <fwp_mem_free+0x64>  // b.plast
    2fe4:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fe8:	f909f6b6 	str	x22, [x21, #5096]
    2fec:	17ffffa7 	b	2e88 <fwp_mem_free+0x68>
    2ff0:	aa1303e0 	mov	x0, x19
    2ff4:	97fffeec 	bl	2ba4 <fwp_rc_forget_slot>
    2ff8:	17ffffe3 	b	2f84 <fwp_mem_free+0x164>
    2ffc:	97fffeea 	bl	2ba4 <fwp_rc_forget_slot>
    3000:	17ffffb4 	b	2ed0 <fwp_mem_free+0xb0>

0000000000003004 <fwp_heap_alloc_big>:
    3004:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    3008:	910003fd 	mov	x29, sp
    300c:	a90153f3 	stp	x19, x20, [sp, #16]
    3010:	a9025bf5 	stp	x21, x22, [sp, #32]
    3014:	a90363f7 	stp	x23, x24, [sp, #48]
    3018:	aa0003f7 	mov	x23, x0
    301c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    3020:	a9046bf9 	stp	x25, x26, [sp, #64]
    3024:	eb0002ff 	cmp	x23, x0
    3028:	54000888 	b.hi	3138 <fwp_heap_alloc_big+0x134>  // b.pmore
    302c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3030:	8b0002f4 	add	x20, x23, x0
    3034:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xcd0>
    3038:	91144359 	add	x25, x26, #0x510
    303c:	d350fe94 	lsr	x20, x20, #16
    3040:	2a0103f5 	mov	w21, w1
    3044:	aa1403e0 	mov	x0, x20
    3048:	97fffb12 	bl	1c90 <fwp_heap_chunks>
    304c:	f949ff22 	ldr	x2, [x25, #5112]
    3050:	8b000813 	add	x19, x0, x0, lsl #2
    3054:	aa0003f8 	mov	x24, x0
    3058:	52800043 	mov	w3, #0x2                   	// #2
    305c:	d37df273 	lsl	x19, x19, #3
    3060:	d2800021 	mov	x1, #0x1                   	// #1
    3064:	8b130040 	add	x0, x2, x19
    3068:	38336843 	strb	w3, [x2, x19]
    306c:	39000415 	strb	w21, [x0, #1]
    3070:	b9000c14 	str	w20, [x0, #12]
    3074:	f9000817 	str	x23, [x0, #16]
    3078:	97fffef2 	bl	2c40 <fwp_rc_prepare_chunk>
    307c:	f100069f 	cmp	x20, #0x1
    3080:	54000269 	b.ls	30cc <fwp_heap_alloc_big+0xc8>  // b.plast
    3084:	8b180294 	add	x20, x20, x24
    3088:	9100a273 	add	x19, x19, #0x28
    308c:	a90573fb 	stp	x27, x28, [sp, #80]
    3090:	5280007b 	mov	w27, #0x3                   	// #3
    3094:	8b140a94 	add	x20, x20, x20, lsl #2
    3098:	2a1803fc 	mov	w28, w24
    309c:	9adb2296 	lsl	x22, x20, x27
    30a0:	f949ff35 	ldr	x21, [x25, #5112]
    30a4:	d2800001 	mov	x1, #0x0                   	// #0
    30a8:	8b1302b4 	add	x20, x21, x19
    30ac:	aa1403e0 	mov	x0, x20
    30b0:	97fffee4 	bl	2c40 <fwp_rc_prepare_chunk>
    30b4:	38336abb 	strb	w27, [x21, x19]
    30b8:	9100a273 	add	x19, x19, #0x28
    30bc:	b9000e9c 	str	w28, [x20, #12]
    30c0:	eb1302df 	cmp	x22, x19
    30c4:	54fffee1 	b.ne	30a0 <fwp_heap_alloc_big+0x9c>  // b.any
    30c8:	a94573fb 	ldp	x27, x28, [sp, #80]
    30cc:	91144353 	add	x19, x26, #0x510
    30d0:	aa1703e2 	mov	x2, x23
    30d4:	52800001 	mov	w1, #0x0                   	// #0
    30d8:	f949da60 	ldr	x0, [x19, #5040]
    30dc:	8b184018 	add	x24, x0, x24, lsl #16
    30e0:	aa1803e0 	mov	x0, x24
    30e4:	97fff8e3 	bl	1470 <memset@plt>
    30e8:	f94a1260 	ldr	x0, [x19, #5152]
    30ec:	ab170000 	adds	x0, x0, x23
    30f0:	54000242 	b.cs	3138 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    30f4:	f94a1661 	ldr	x1, [x19, #5160]
    30f8:	f90a1260 	str	x0, [x19, #5152]
    30fc:	eb01001f 	cmp	x0, x1
    3100:	54000049 	b.ls	3108 <fwp_heap_alloc_big+0x104>  // b.plast
    3104:	f90a1660 	str	x0, [x19, #5160]
    3108:	9114435a 	add	x26, x26, #0x510
    310c:	9e6202e0 	scvtf	d0, x23
    3110:	a94153f3 	ldp	x19, x20, [sp, #16]
    3114:	aa1803e0 	mov	x0, x24
    3118:	fd4a1f41 	ldr	d1, [x26, #5176]
    311c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3120:	1e602820 	fadd	d0, d1, d0
    3124:	a94363f7 	ldp	x23, x24, [sp, #48]
    3128:	fd0a1f40 	str	d0, [x26, #5176]
    312c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3130:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3134:	d65f03c0 	ret
    3138:	a90573fb 	stp	x27, x28, [sp, #80]
    313c:	97fffa95 	bl	1b90 <fwp_heap_oom>

0000000000003140 <fwp_heap_alloc_slow>:
    3140:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3144:	910003fd 	mov	x29, sp
    3148:	a90153f3 	stp	x19, x20, [sp, #16]
    314c:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcd0>
    3150:	91144262 	add	x2, x19, #0x510
    3154:	a9025bf5 	stp	x21, x22, [sp, #32]
    3158:	aa0003f5 	mov	x21, x0
    315c:	2a0103f4 	mov	w20, w1
    3160:	b953a440 	ldr	w0, [x2, #5028]
    3164:	34000600 	cbz	w0, 3224 <fwp_heap_alloc_slow+0xe4>
    3168:	f14012bf 	cmp	x21, #0x4, lsl #12
    316c:	54000628 	b.hi	3230 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3170:	91003ea0 	add	x0, x21, #0xf
    3174:	91144262 	add	x2, x19, #0x510
    3178:	f9001bf7 	str	x23, [sp, #48]
    317c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3180:	8b401040 	add	x0, x2, x0, lsr #4
    3184:	cb34c084 	sub	x4, x4, w20, sxtw
    3188:	d37ae484 	lsl	x4, x4, #6
    318c:	397e8003 	ldrb	w3, [x0, #4000]
    3190:	910f0060 	add	x0, x3, #0x3c0
    3194:	aa0303e1 	mov	x1, x3
    3198:	8b030463 	add	x3, x3, x3, lsl #1
    319c:	8b030c83 	add	x3, x4, x3, lsl #3
    31a0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    31a4:	2a1703f6 	mov	w22, w23
    31a8:	f8636844 	ldr	x4, [x2, x3]
    31ac:	b40004e4 	cbz	x4, 3248 <fwp_heap_alloc_slow+0x108>
    31b0:	f9400080 	ldr	x0, [x4]
    31b4:	aa2003e0 	mvn	x0, x0
    31b8:	f8236840 	str	x0, [x2, x3]
    31bc:	7100069f 	cmp	w20, #0x1
    31c0:	aa0403e0 	mov	x0, x4
    31c4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    31c8:	52800001 	mov	w1, #0x0                   	// #0
    31cc:	97fff8a9 	bl	1470 <memset@plt>
    31d0:	aa0003e4 	mov	x4, x0
    31d4:	91144260 	add	x0, x19, #0x510
    31d8:	f94a1001 	ldr	x1, [x0, #5152]
    31dc:	ab160021 	adds	x1, x1, x22
    31e0:	540005c2 	b.cs	3298 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    31e4:	f94a1402 	ldr	x2, [x0, #5160]
    31e8:	f90a1001 	str	x1, [x0, #5152]
    31ec:	eb02003f 	cmp	x1, x2
    31f0:	54000049 	b.ls	31f8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    31f4:	f90a1401 	str	x1, [x0, #5160]
    31f8:	91144273 	add	x19, x19, #0x510
    31fc:	1e6302e1 	ucvtf	d1, w23
    3200:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3204:	aa0403e0 	mov	x0, x4
    3208:	fd4a1e60 	ldr	d0, [x19, #5176]
    320c:	f9401bf7 	ldr	x23, [sp, #48]
    3210:	1e612800 	fadd	d0, d0, d1
    3214:	fd0a1e60 	str	d0, [x19, #5176]
    3218:	a94153f3 	ldp	x19, x20, [sp, #16]
    321c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3220:	d65f03c0 	ret
    3224:	97fffd33 	bl	26f0 <fwp_heap_init>
    3228:	f14012bf 	cmp	x21, #0x4, lsl #12
    322c:	54fffa29 	b.ls	3170 <fwp_heap_alloc_slow+0x30>  // b.plast
    3230:	2a1403e1 	mov	w1, w20
    3234:	aa1503e0 	mov	x0, x21
    3238:	a94153f3 	ldp	x19, x20, [sp, #16]
    323c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3240:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3244:	17ffff70 	b	3004 <fwp_heap_alloc_big>
    3248:	8b030042 	add	x2, x2, x3
    324c:	f9400444 	ldr	x4, [x2, #8]
    3250:	b4000104 	cbz	x4, 3270 <fwp_heap_alloc_slow+0x130>
    3254:	f9400840 	ldr	x0, [x2, #16]
    3258:	cb040000 	sub	x0, x0, x4
    325c:	eb16001f 	cmp	x0, x22
    3260:	54000083 	b.cc	3270 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3264:	8b160080 	add	x0, x4, x22
    3268:	f9000440 	str	x0, [x2, #8]
    326c:	17ffffd4 	b	31bc <fwp_heap_alloc_slow+0x7c>
    3270:	52800302 	mov	w2, #0x18                  	// #24
    3274:	52807804 	mov	w4, #0x3c0                 	// #960
    3278:	91144260 	add	x0, x19, #0x510
    327c:	9ba27c23 	umull	x3, w1, w2
    3280:	2a1403e2 	mov	w2, w20
    3284:	9b240e84 	smaddl	x4, w20, w4, x3
    3288:	8b040000 	add	x0, x0, x4
    328c:	97fffeb5 	bl	2d60 <fwp_heap_refill>
    3290:	aa0003e4 	mov	x4, x0
    3294:	17ffffca 	b	31bc <fwp_heap_alloc_slow+0x7c>
    3298:	97fffa3e 	bl	1b90 <fwp_heap_oom>
    329c:	d503201f 	nop

00000000000032a0 <fwp_rc_free_arr>:
    32a0:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xcd0>
    32a4:	91144063 	add	x3, x3, #0x510
    32a8:	f949d861 	ldr	x1, [x3, #5040]
    32ac:	f949ec62 	ldr	x2, [x3, #5080]
    32b0:	cb010001 	sub	x1, x0, x1
    32b4:	eb02403f 	cmp	x1, x2, lsl #16
    32b8:	54000342 	b.cs	3320 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    32bc:	d350fc22 	lsr	x2, x1, #16
    32c0:	f949fc65 	ldr	x5, [x3, #5112]
    32c4:	8b020842 	add	x2, x2, x2, lsl #2
    32c8:	d37df042 	lsl	x2, x2, #3
    32cc:	8b0200a4 	add	x4, x5, x2
    32d0:	f9401083 	ldr	x3, [x4, #32]
    32d4:	b4000263 	cbz	x3, 3320 <fwp_rc_free_arr+0x80>
    32d8:	386268a2 	ldrb	w2, [x5, x2]
    32dc:	7100085f 	cmp	w2, #0x2
    32e0:	540001c0 	b.eq	3318 <fwp_rc_free_arr+0x78>  // b.none
    32e4:	7100045f 	cmp	w2, #0x1
    32e8:	540001c1 	b.ne	3320 <fwp_rc_free_arr+0x80>  // b.any
    32ec:	29430885 	ldp	w5, w2, [x4, #24]
    32f0:	92403c21 	and	x1, x1, #0xffff
    32f4:	9b057c21 	mul	x1, x1, x5
    32f8:	d360fc21 	lsr	x1, x1, #32
    32fc:	eb02003f 	cmp	x1, x2
    3300:	54000102 	b.cs	3320 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    3304:	8b010063 	add	x3, x3, x1
    3308:	39400061 	ldrb	w1, [x3]
    330c:	7100043f 	cmp	w1, #0x1
    3310:	54000081 	b.ne	3320 <fwp_rc_free_arr+0x80>  // b.any
    3314:	17fffec3 	b	2e20 <fwp_mem_free>
    3318:	72003c3f 	tst	w1, #0xffff
    331c:	54ffff60 	b.eq	3308 <fwp_rc_free_arr+0x68>  // b.none
    3320:	d65f03c0 	ret

0000000000003324 <fwp_heap_alloc>:
    3324:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3328:	f140101f 	cmp	x0, #0x4, lsl #12
    332c:	910003fd 	mov	x29, sp
    3330:	a90153f3 	stp	x19, x20, [sp, #16]
    3334:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xcd0>
    3338:	91144293 	add	x19, x20, #0x510
    333c:	b953a662 	ldr	w2, [x19, #5028]
    3340:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3344:	54000640 	b.eq	340c <fwp_heap_alloc+0xe8>  // b.none
    3348:	91003c03 	add	x3, x0, #0xf
    334c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3350:	937c7c22 	sbfiz	x2, x1, #4, #32
    3354:	8b431263 	add	x3, x19, x3, lsr #4
    3358:	cb21c042 	sub	x2, x2, w1, sxtw
    335c:	d37ae442 	lsl	x2, x2, #6
    3360:	397e8063 	ldrb	w3, [x3, #4000]
    3364:	910f0064 	add	x4, x3, #0x3c0
    3368:	8b030463 	add	x3, x3, x3, lsl #1
    336c:	8b030c43 	add	x3, x2, x3, lsl #3
    3370:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    3374:	2a1603f5 	mov	w21, w22
    3378:	f8636a64 	ldr	x4, [x19, x3]
    337c:	b4000384 	cbz	x4, 33ec <fwp_heap_alloc+0xc8>
    3380:	f9400085 	ldr	x5, [x4]
    3384:	7100043f 	cmp	w1, #0x1
    3388:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    338c:	aa0403e0 	mov	x0, x4
    3390:	aa2503e5 	mvn	x5, x5
    3394:	52800001 	mov	w1, #0x0                   	// #0
    3398:	f8236a65 	str	x5, [x19, x3]
    339c:	97fff835 	bl	1470 <memset@plt>
    33a0:	aa0003e4 	mov	x4, x0
    33a4:	f94a1260 	ldr	x0, [x19, #5152]
    33a8:	ab150000 	adds	x0, x0, x21
    33ac:	54000442 	b.cs	3434 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    33b0:	f94a1661 	ldr	x1, [x19, #5160]
    33b4:	f90a1260 	str	x0, [x19, #5152]
    33b8:	eb01001f 	cmp	x0, x1
    33bc:	54000049 	b.ls	33c4 <fwp_heap_alloc+0xa0>  // b.plast
    33c0:	f90a1660 	str	x0, [x19, #5160]
    33c4:	91144294 	add	x20, x20, #0x510
    33c8:	1e6302c1 	ucvtf	d1, w22
    33cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33d0:	aa0403e0 	mov	x0, x4
    33d4:	fd4a1e80 	ldr	d0, [x20, #5176]
    33d8:	1e612800 	fadd	d0, d0, d1
    33dc:	fd0a1e80 	str	d0, [x20, #5176]
    33e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    33e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e8:	d65f03c0 	ret
    33ec:	8b030263 	add	x3, x19, x3
    33f0:	f9400464 	ldr	x4, [x3, #8]
    33f4:	b40000a4 	cbz	x4, 3408 <fwp_heap_alloc+0xe4>
    33f8:	f9400862 	ldr	x2, [x3, #16]
    33fc:	cb040042 	sub	x2, x2, x4
    3400:	eb15005f 	cmp	x2, x21
    3404:	540000a2 	b.cs	3418 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    3408:	a9425bf5 	ldp	x21, x22, [sp, #32]
    340c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3410:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3414:	17ffff4b 	b	3140 <fwp_heap_alloc_slow>
    3418:	7100043f 	cmp	w1, #0x1
    341c:	8b150085 	add	x5, x4, x21
    3420:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    3424:	52800001 	mov	w1, #0x0                   	// #0
    3428:	aa0403e0 	mov	x0, x4
    342c:	f9000465 	str	x5, [x3, #8]
    3430:	17ffffdb 	b	339c <fwp_heap_alloc+0x78>
    3434:	97fff9d7 	bl	1b90 <fwp_heap_oom>
    3438:	d503201f 	nop
    343c:	d503201f 	nop

0000000000003440 <fwp_data.part.0.constprop.0>:
    3440:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3444:	910003fd 	mov	x29, sp
    3448:	a90153f3 	stp	x19, x20, [sp, #16]
    344c:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xcd0>
    3450:	91144282 	add	x2, x20, #0x510
    3454:	a9025bf5 	stp	x21, x22, [sp, #32]
    3458:	aa0003f5 	mov	x21, x0
    345c:	b953a440 	ldr	w0, [x2, #5028]
    3460:	34000700 	cbz	w0, 3540 <fwp_data.part.0.constprop.0+0x100>
    3464:	f9001bf7 	str	x23, [sp, #48]
    3468:	397e8841 	ldrb	w1, [x2, #4002]
    346c:	910f0020 	add	x0, x1, #0x3c0
    3470:	8b010421 	add	x1, x1, x1, lsl #1
    3474:	d37df021 	lsl	x1, x1, #3
    3478:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    347c:	2a1703f6 	mov	w22, w23
    3480:	f8616853 	ldr	x19, [x2, x1]
    3484:	b40004f3 	cbz	x19, 3520 <fwp_data.part.0.constprop.0+0xe0>
    3488:	f9400260 	ldr	x0, [x19]
    348c:	aa2003e0 	mvn	x0, x0
    3490:	f8216840 	str	x0, [x2, x1]
    3494:	f10062df 	cmp	x22, #0x18
    3498:	540000e9 	b.ls	34b4 <fwp_data.part.0.constprop.0+0x74>  // b.plast
    349c:	d10066c2 	sub	x2, x22, #0x19
    34a0:	91006260 	add	x0, x19, #0x18
    34a4:	927df042 	and	x2, x2, #0xfffffffffffffff8
    34a8:	52800001 	mov	w1, #0x0                   	// #0
    34ac:	91002042 	add	x2, x2, #0x8
    34b0:	97fff7f0 	bl	1470 <memset@plt>
    34b4:	91144281 	add	x1, x20, #0x510
    34b8:	f94a1020 	ldr	x0, [x1, #5152]
    34bc:	ab160000 	adds	x0, x0, x22
    34c0:	54000502 	b.cs	3560 <fwp_data.part.0.constprop.0+0x120>  // b.hs, b.nlast
    34c4:	f94a1422 	ldr	x2, [x1, #5160]
    34c8:	f90a1020 	str	x0, [x1, #5152]
    34cc:	eb02001f 	cmp	x0, x2
    34d0:	54000049 	b.ls	34d8 <fwp_data.part.0.constprop.0+0x98>  // b.plast
    34d4:	f90a1420 	str	x0, [x1, #5160]
    34d8:	91144294 	add	x20, x20, #0x510
    34dc:	1e6302e1 	ucvtf	d1, w23
    34e0:	f9401bf7 	ldr	x23, [sp, #48]
    34e4:	fd4a1e80 	ldr	d0, [x20, #5176]
    34e8:	1e612800 	fadd	d0, d0, d1
    34ec:	fd0a1e80 	str	d0, [x20, #5176]
    34f0:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    34f4:	fd469800 	ldr	d0, [x0, #3376]
    34f8:	aa1303e0 	mov	x0, x19
    34fc:	fd000260 	str	d0, [x19]
    3500:	f94002a1 	ldr	x1, [x21]
    3504:	f9000661 	str	x1, [x19, #8]
    3508:	f94006a1 	ldr	x1, [x21, #8]
    350c:	f9000a61 	str	x1, [x19, #16]
    3510:	a94153f3 	ldp	x19, x20, [sp, #16]
    3514:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3518:	a8c47bfd 	ldp	x29, x30, [sp], #64
    351c:	d65f03c0 	ret
    3520:	8b010042 	add	x2, x2, x1
    3524:	f9400453 	ldr	x19, [x2, #8]
    3528:	b40000b3 	cbz	x19, 353c <fwp_data.part.0.constprop.0+0xfc>
    352c:	f9400840 	ldr	x0, [x2, #16]
    3530:	cb130000 	sub	x0, x0, x19
    3534:	eb0002df 	cmp	x22, x0
    3538:	540000e9 	b.ls	3554 <fwp_data.part.0.constprop.0+0x114>  // b.plast
    353c:	f9401bf7 	ldr	x23, [sp, #48]
    3540:	52800001 	mov	w1, #0x0                   	// #0
    3544:	d2800300 	mov	x0, #0x18                  	// #24
    3548:	97ffff77 	bl	3324 <fwp_heap_alloc>
    354c:	aa0003f3 	mov	x19, x0
    3550:	17ffffe8 	b	34f0 <fwp_data.part.0.constprop.0+0xb0>
    3554:	8b160260 	add	x0, x19, x22
    3558:	f9000440 	str	x0, [x2, #8]
    355c:	17ffffce 	b	3494 <fwp_data.part.0.constprop.0+0x54>
    3560:	97fff98c 	bl	1b90 <fwp_heap_oom>

0000000000003564 <fwp_array_new_packed.constprop.0>:
    3564:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3568:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    356c:	910003fd 	mov	x29, sp
    3570:	f9000bf3 	str	x19, [sp, #16]
    3574:	eb01001f 	cmp	x0, x1
    3578:	54000148 	b.hi	35a0 <fwp_array_new_packed.constprop.0+0x3c>  // b.pmore
    357c:	aa0003f3 	mov	x19, x0
    3580:	91000400 	add	x0, x0, #0x1
    3584:	52800021 	mov	w1, #0x1                   	// #1
    3588:	d37df000 	lsl	x0, x0, #3
    358c:	97ffff66 	bl	3324 <fwp_heap_alloc>
    3590:	f9000013 	str	x19, [x0]
    3594:	f9400bf3 	ldr	x19, [sp, #16]
    3598:	a8c27bfd 	ldp	x29, x30, [sp], #32
    359c:	d65f03c0 	ret
    35a0:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    35a4:	91280000 	add	x0, x0, #0xa00
    35a8:	97fffabe 	bl	20a0 <fwp_trap>
    35ac:	d503201f 	nop

00000000000035b0 <fwp_drop1>:
    35b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    35b4:	910003fd 	mov	x29, sp
    35b8:	a90153f3 	stp	x19, x20, [sp, #16]
    35bc:	f90013f5 	str	x21, [sp, #32]
    35c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    35c4:	911442b4 	add	x20, x21, #0x510
    35c8:	f949da81 	ldr	x1, [x20, #5040]
    35cc:	f949ee82 	ldr	x2, [x20, #5080]
    35d0:	cb010001 	sub	x1, x0, x1
    35d4:	eb02403f 	cmp	x1, x2, lsl #16
    35d8:	54000382 	b.cs	3648 <fwp_drop1+0x98>  // b.hs, b.nlast
    35dc:	d350fc22 	lsr	x2, x1, #16
    35e0:	f949fe84 	ldr	x4, [x20, #5112]
    35e4:	8b020842 	add	x2, x2, x2, lsl #2
    35e8:	d37df042 	lsl	x2, x2, #3
    35ec:	8b020083 	add	x3, x4, x2
    35f0:	f9401073 	ldr	x19, [x3, #32]
    35f4:	b40002b3 	cbz	x19, 3648 <fwp_drop1+0x98>
    35f8:	38626882 	ldrb	w2, [x4, x2]
    35fc:	7100085f 	cmp	w2, #0x2
    3600:	540002c0 	b.eq	3658 <fwp_drop1+0xa8>  // b.none
    3604:	7100045f 	cmp	w2, #0x1
    3608:	54000201 	b.ne	3648 <fwp_drop1+0x98>  // b.any
    360c:	29430864 	ldp	w4, w2, [x3, #24]
    3610:	92403c21 	and	x1, x1, #0xffff
    3614:	9b047c21 	mul	x1, x1, x4
    3618:	d360fc21 	lsr	x1, x1, #32
    361c:	eb02003f 	cmp	x1, x2
    3620:	54000142 	b.cs	3648 <fwp_drop1+0x98>  // b.hs, b.nlast
    3624:	8b010273 	add	x19, x19, x1
    3628:	39400261 	ldrb	w1, [x19]
    362c:	340000e1 	cbz	w1, 3648 <fwp_drop1+0x98>
    3630:	7100043f 	cmp	w1, #0x1
    3634:	540001e0 	b.eq	3670 <fwp_drop1+0xc0>  // b.none
    3638:	7103fc3f 	cmp	w1, #0xff
    363c:	540002e0 	b.eq	3698 <fwp_drop1+0xe8>  // b.none
    3640:	51000421 	sub	w1, w1, #0x1
    3644:	39000261 	strb	w1, [x19]
    3648:	a94153f3 	ldp	x19, x20, [sp, #16]
    364c:	f94013f5 	ldr	x21, [sp, #32]
    3650:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3654:	d65f03c0 	ret
    3658:	72003c3f 	tst	w1, #0xffff
    365c:	54fffe60 	b.eq	3628 <fwp_drop1+0x78>  // b.none
    3660:	a94153f3 	ldp	x19, x20, [sp, #16]
    3664:	f94013f5 	ldr	x21, [sp, #32]
    3668:	a8c37bfd 	ldp	x29, x30, [sp], #48
    366c:	d65f03c0 	ret
    3670:	f9400813 	ldr	x19, [x0, #16]
    3674:	97ffff0b 	bl	32a0 <fwp_rc_free_arr>
    3678:	911442a0 	add	x0, x21, #0x510
    367c:	f949d801 	ldr	x1, [x0, #5040]
    3680:	f949ec00 	ldr	x0, [x0, #5080]
    3684:	cb010261 	sub	x1, x19, x1
    3688:	eb00403f 	cmp	x1, x0, lsl #16
    368c:	54fffde2 	b.cs	3648 <fwp_drop1+0x98>  // b.hs, b.nlast
    3690:	aa1303e0 	mov	x0, x19
    3694:	17ffffd2 	b	35dc <fwp_drop1+0x2c>
    3698:	ca534660 	eor	x0, x19, x19, lsr #17
    369c:	911442b5 	add	x21, x21, #0x510
    36a0:	ca402400 	eor	x0, x0, x0, lsr #9
    36a4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    36a8:	f94a2400 	ldr	x0, [x0, #5192]
    36ac:	b5000080 	cbnz	x0, 36bc <fwp_drop1+0x10c>
    36b0:	14000010 	b	36f0 <fwp_drop1+0x140>
    36b4:	f9400800 	ldr	x0, [x0, #16]
    36b8:	b40001c0 	cbz	x0, 36f0 <fwp_drop1+0x140>
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb13003f 	cmp	x1, x19
    36c4:	54ffff81 	b.ne	36b4 <fwp_drop1+0x104>  // b.any
    36c8:	f9400401 	ldr	x1, [x0, #8]
    36cc:	d1000421 	sub	x1, x1, #0x1
    36d0:	f9000401 	str	x1, [x0, #8]
    36d4:	f103f83f 	cmp	x1, #0xfe
    36d8:	54fffb81 	b.ne	3648 <fwp_drop1+0x98>  // b.any
    36dc:	aa1303e0 	mov	x0, x19
    36e0:	97fffd31 	bl	2ba4 <fwp_rc_forget_slot>
    36e4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    36e8:	39000260 	strb	w0, [x19]
    36ec:	17ffffd7 	b	3648 <fwp_drop1+0x98>
    36f0:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    36f4:	91276000 	add	x0, x0, #0x9d8
    36f8:	97fffa6a 	bl	20a0 <fwp_trap>
    36fc:	d503201f 	nop

0000000000003700 <fwp_drop0>:
    3700:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3704:	910003fd 	mov	x29, sp
    3708:	a90153f3 	stp	x19, x20, [sp, #16]
    370c:	f90013f5 	str	x21, [sp, #32]
    3710:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcd0>
    3714:	911442b4 	add	x20, x21, #0x510
    3718:	f949da81 	ldr	x1, [x20, #5040]
    371c:	f949ee82 	ldr	x2, [x20, #5080]
    3720:	cb010001 	sub	x1, x0, x1
    3724:	eb02403f 	cmp	x1, x2, lsl #16
    3728:	54000382 	b.cs	3798 <fwp_drop0+0x98>  // b.hs, b.nlast
    372c:	d350fc22 	lsr	x2, x1, #16
    3730:	f949fe84 	ldr	x4, [x20, #5112]
    3734:	8b020842 	add	x2, x2, x2, lsl #2
    3738:	d37df042 	lsl	x2, x2, #3
    373c:	8b020083 	add	x3, x4, x2
    3740:	f9401073 	ldr	x19, [x3, #32]
    3744:	b40002b3 	cbz	x19, 3798 <fwp_drop0+0x98>
    3748:	38626882 	ldrb	w2, [x4, x2]
    374c:	7100085f 	cmp	w2, #0x2
    3750:	540002c0 	b.eq	37a8 <fwp_drop0+0xa8>  // b.none
    3754:	7100045f 	cmp	w2, #0x1
    3758:	54000201 	b.ne	3798 <fwp_drop0+0x98>  // b.any
    375c:	29430864 	ldp	w4, w2, [x3, #24]
    3760:	92403c21 	and	x1, x1, #0xffff
    3764:	9b047c21 	mul	x1, x1, x4
    3768:	d360fc21 	lsr	x1, x1, #32
    376c:	eb02003f 	cmp	x1, x2
    3770:	54000142 	b.cs	3798 <fwp_drop0+0x98>  // b.hs, b.nlast
    3774:	8b010273 	add	x19, x19, x1
    3778:	39400261 	ldrb	w1, [x19]
    377c:	340000e1 	cbz	w1, 3798 <fwp_drop0+0x98>
    3780:	7100043f 	cmp	w1, #0x1
    3784:	540001e0 	b.eq	37c0 <fwp_drop0+0xc0>  // b.none
    3788:	7103fc3f 	cmp	w1, #0xff
    378c:	540002e0 	b.eq	37e8 <fwp_drop0+0xe8>  // b.none
    3790:	51000421 	sub	w1, w1, #0x1
    3794:	39000261 	strb	w1, [x19]
    3798:	a94153f3 	ldp	x19, x20, [sp, #16]
    379c:	f94013f5 	ldr	x21, [sp, #32]
    37a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    37a4:	d65f03c0 	ret
    37a8:	72003c3f 	tst	w1, #0xffff
    37ac:	54fffe60 	b.eq	3778 <fwp_drop0+0x78>  // b.none
    37b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    37b4:	f94013f5 	ldr	x21, [sp, #32]
    37b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    37bc:	d65f03c0 	ret
    37c0:	f9400813 	ldr	x19, [x0, #16]
    37c4:	97fffeb7 	bl	32a0 <fwp_rc_free_arr>
    37c8:	911442a0 	add	x0, x21, #0x510
    37cc:	f949d801 	ldr	x1, [x0, #5040]
    37d0:	f949ec00 	ldr	x0, [x0, #5080]
    37d4:	cb010261 	sub	x1, x19, x1
    37d8:	eb00403f 	cmp	x1, x0, lsl #16
    37dc:	54fffde2 	b.cs	3798 <fwp_drop0+0x98>  // b.hs, b.nlast
    37e0:	aa1303e0 	mov	x0, x19
    37e4:	17ffffd2 	b	372c <fwp_drop0+0x2c>
    37e8:	ca534660 	eor	x0, x19, x19, lsr #17
    37ec:	911442b5 	add	x21, x21, #0x510
    37f0:	ca402400 	eor	x0, x0, x0, lsr #9
    37f4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    37f8:	f94a2400 	ldr	x0, [x0, #5192]
    37fc:	b5000080 	cbnz	x0, 380c <fwp_drop0+0x10c>
    3800:	14000010 	b	3840 <fwp_drop0+0x140>
    3804:	f9400800 	ldr	x0, [x0, #16]
    3808:	b40001c0 	cbz	x0, 3840 <fwp_drop0+0x140>
    380c:	f9400001 	ldr	x1, [x0]
    3810:	eb13003f 	cmp	x1, x19
    3814:	54ffff81 	b.ne	3804 <fwp_drop0+0x104>  // b.any
    3818:	f9400401 	ldr	x1, [x0, #8]
    381c:	d1000421 	sub	x1, x1, #0x1
    3820:	f9000401 	str	x1, [x0, #8]
    3824:	f103f83f 	cmp	x1, #0xfe
    3828:	54fffb81 	b.ne	3798 <fwp_drop0+0x98>  // b.any
    382c:	aa1303e0 	mov	x0, x19
    3830:	97fffcdd 	bl	2ba4 <fwp_rc_forget_slot>
    3834:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3838:	39000260 	strb	w0, [x19]
    383c:	17ffffd7 	b	3798 <fwp_drop0+0x98>
    3840:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    3844:	91276000 	add	x0, x0, #0x9d8
    3848:	97fffa16 	bl	20a0 <fwp_trap>
    384c:	d503201f 	nop

0000000000003850 <fwp_task_dispose>:
    3850:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3854:	910003fd 	mov	x29, sp
    3858:	f9000bf3 	str	x19, [sp, #16]
    385c:	aa0003f3 	mov	x19, x0
    3860:	39414000 	ldrb	w0, [x0, #80]
    3864:	36000720 	tbz	w0, #0, 3948 <fwp_task_dispose+0xf8>
    3868:	f9400a60 	ldr	x0, [x19, #16]
    386c:	b50006e0 	cbnz	x0, 3948 <fwp_task_dispose+0xf8>
    3870:	a9478660 	ldp	x0, x1, [x19, #120]
    3874:	39014e7f 	strb	wzr, [x19, #83]
    3878:	f9003e7f 	str	xzr, [x19, #120]
    387c:	f100003f 	cmp	x1, #0x0
    3880:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3884:	54000040 	b.eq	388c <fwp_task_dispose+0x3c>  // b.none
    3888:	d63f0020 	blr	x1
    388c:	f9405660 	ldr	x0, [x19, #168]
    3890:	97fffd64 	bl	2e20 <fwp_mem_free>
    3894:	f900567f 	str	xzr, [x19, #168]
    3898:	b9405e60 	ldr	w0, [x19, #92]
    389c:	7100041f 	cmp	w0, #0x1
    38a0:	54000420 	b.eq	3924 <fwp_task_dispose+0xd4>  // b.none
    38a4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcd0>
    38a8:	91144042 	add	x2, x2, #0x510
    38ac:	f949d840 	ldr	x0, [x2, #5040]
    38b0:	f949ec41 	ldr	x1, [x2, #5080]
    38b4:	cb000260 	sub	x0, x19, x0
    38b8:	eb01401f 	cmp	x0, x1, lsl #16
    38bc:	540002e2 	b.cs	3918 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    38c0:	d350fc01 	lsr	x1, x0, #16
    38c4:	f949fc44 	ldr	x4, [x2, #5112]
    38c8:	8b010821 	add	x1, x1, x1, lsl #2
    38cc:	d37df021 	lsl	x1, x1, #3
    38d0:	8b010083 	add	x3, x4, x1
    38d4:	f9401062 	ldr	x2, [x3, #32]
    38d8:	b4000202 	cbz	x2, 3918 <fwp_task_dispose+0xc8>
    38dc:	38616881 	ldrb	w1, [x4, x1]
    38e0:	7100083f 	cmp	w1, #0x2
    38e4:	54000280 	b.eq	3934 <fwp_task_dispose+0xe4>  // b.none
    38e8:	7100043f 	cmp	w1, #0x1
    38ec:	54000161 	b.ne	3918 <fwp_task_dispose+0xc8>  // b.any
    38f0:	29430464 	ldp	w4, w1, [x3, #24]
    38f4:	92403c00 	and	x0, x0, #0xffff
    38f8:	9b047c00 	mul	x0, x0, x4
    38fc:	d360fc00 	lsr	x0, x0, #32
    3900:	eb01001f 	cmp	x0, x1
    3904:	540000a2 	b.cs	3918 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3908:	8b000042 	add	x2, x2, x0
    390c:	39400040 	ldrb	w0, [x2]
    3910:	7100041f 	cmp	w0, #0x1
    3914:	54000080 	b.eq	3924 <fwp_task_dispose+0xd4>  // b.none
    3918:	f9400bf3 	ldr	x19, [sp, #16]
    391c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3920:	d65f03c0 	ret
    3924:	aa1303e0 	mov	x0, x19
    3928:	f9400bf3 	ldr	x19, [sp, #16]
    392c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3930:	17fffd3c 	b	2e20 <fwp_mem_free>
    3934:	72003c1f 	tst	w0, #0xffff
    3938:	54fffea0 	b.eq	390c <fwp_task_dispose+0xbc>  // b.none
    393c:	f9400bf3 	ldr	x19, [sp, #16]
    3940:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3944:	d65f03c0 	ret
    3948:	97fff6ea 	bl	14f0 <abort@plt>
    394c:	d503201f 	nop

0000000000003950 <fwp_free_zombie>:
    3950:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3954:	910003fd 	mov	x29, sp
    3958:	a90153f3 	stp	x19, x20, [sp, #16]
    395c:	b00000f4 	adrp	x20, 20000 <__data_start>
    3960:	9101c281 	add	x1, x20, #0x70
    3964:	f9401c33 	ldr	x19, [x1, #56]
    3968:	b4000333 	cbz	x19, 39cc <fwp_free_zombie+0x7c>
    396c:	f9400420 	ldr	x0, [x1, #8]
    3970:	eb00027f 	cmp	x19, x0
    3974:	540002c0 	b.eq	39cc <fwp_free_zombie+0x7c>  // b.none
    3978:	b9404022 	ldr	w2, [x1, #64]
    397c:	f9400a60 	ldr	x0, [x19, #16]
    3980:	7100fc5f 	cmp	w2, #0x3f
    3984:	5400078c 	b.gt	3a74 <fwp_free_zombie+0x124>
    3988:	91014023 	add	x3, x1, #0x50
    398c:	11000444 	add	w4, w2, #0x1
    3990:	b9004024 	str	w4, [x1, #64]
    3994:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3998:	f822d860 	str	x0, [x3, w2, sxtw #3]
    399c:	a9530261 	ldp	x1, x0, [x19, #304]
    39a0:	b4000741 	cbz	x1, 3a88 <fwp_free_zombie+0x138>
    39a4:	f9009c20 	str	x0, [x1, #312]
    39a8:	b4000040 	cbz	x0, 39b0 <fwp_free_zombie+0x60>
    39ac:	f9009801 	str	x1, [x0, #304]
    39b0:	9101c294 	add	x20, x20, #0x70
    39b4:	b9405e60 	ldr	w0, [x19, #92]
    39b8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    39bc:	f9001e9f 	str	xzr, [x20, #56]
    39c0:	34000140 	cbz	w0, 39e8 <fwp_free_zombie+0x98>
    39c4:	7100041f 	cmp	w0, #0x1
    39c8:	54000080 	b.eq	39d8 <fwp_free_zombie+0x88>  // b.none
    39cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    39d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39d4:	d65f03c0 	ret
    39d8:	aa1303e0 	mov	x0, x19
    39dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    39e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39e4:	17ffff9b 	b	3850 <fwp_task_dispose>
    39e8:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xcd0>
    39ec:	91144082 	add	x2, x4, #0x510
    39f0:	f949d841 	ldr	x1, [x2, #5040]
    39f4:	f949ec40 	ldr	x0, [x2, #5080]
    39f8:	cb010261 	sub	x1, x19, x1
    39fc:	eb00403f 	cmp	x1, x0, lsl #16
    3a00:	54fffe62 	b.cs	39cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3a04:	d350fc20 	lsr	x0, x1, #16
    3a08:	f949fc43 	ldr	x3, [x2, #5112]
    3a0c:	8b000800 	add	x0, x0, x0, lsl #2
    3a10:	d37df000 	lsl	x0, x0, #3
    3a14:	8b000062 	add	x2, x3, x0
    3a18:	f9401054 	ldr	x20, [x2, #32]
    3a1c:	b4fffd94 	cbz	x20, 39cc <fwp_free_zombie+0x7c>
    3a20:	38606860 	ldrb	w0, [x3, x0]
    3a24:	7100081f 	cmp	w0, #0x2
    3a28:	54000360 	b.eq	3a94 <fwp_free_zombie+0x144>  // b.none
    3a2c:	7100041f 	cmp	w0, #0x1
    3a30:	54fffce1 	b.ne	39cc <fwp_free_zombie+0x7c>  // b.any
    3a34:	29430043 	ldp	w3, w0, [x2, #24]
    3a38:	92403c21 	and	x1, x1, #0xffff
    3a3c:	9b037c21 	mul	x1, x1, x3
    3a40:	d360fc21 	lsr	x1, x1, #32
    3a44:	eb00003f 	cmp	x1, x0
    3a48:	54fffc22 	b.cs	39cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3a4c:	8b010294 	add	x20, x20, x1
    3a50:	39400280 	ldrb	w0, [x20]
    3a54:	34fffbc0 	cbz	w0, 39cc <fwp_free_zombie+0x7c>
    3a58:	7100041f 	cmp	w0, #0x1
    3a5c:	54fffbe0 	b.eq	39d8 <fwp_free_zombie+0x88>  // b.none
    3a60:	7103fc1f 	cmp	w0, #0xff
    3a64:	540001e0 	b.eq	3aa0 <fwp_free_zombie+0x150>  // b.none
    3a68:	51000400 	sub	w0, w0, #0x1
    3a6c:	39000280 	strb	w0, [x20]
    3a70:	17ffffd7 	b	39cc <fwp_free_zombie+0x7c>
    3a74:	f9400e61 	ldr	x1, [x19, #24]
    3a78:	97fff6d2 	bl	15c0 <munmap@plt>
    3a7c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3a80:	a9530261 	ldp	x1, x0, [x19, #304]
    3a84:	b5fff901 	cbnz	x1, 39a4 <fwp_free_zombie+0x54>
    3a88:	9101c282 	add	x2, x20, #0x70
    3a8c:	f9012840 	str	x0, [x2, #592]
    3a90:	17ffffc6 	b	39a8 <fwp_free_zombie+0x58>
    3a94:	72003c3f 	tst	w1, #0xffff
    3a98:	54fff9a1 	b.ne	39cc <fwp_free_zombie+0x7c>  // b.any
    3a9c:	17ffffed 	b	3a50 <fwp_free_zombie+0x100>
    3aa0:	ca544680 	eor	x0, x20, x20, lsr #17
    3aa4:	91144084 	add	x4, x4, #0x510
    3aa8:	ca402400 	eor	x0, x0, x0, lsr #9
    3aac:	8b200c80 	add	x0, x4, w0, uxtb #3
    3ab0:	f94a2400 	ldr	x0, [x0, #5192]
    3ab4:	b5000080 	cbnz	x0, 3ac4 <fwp_free_zombie+0x174>
    3ab8:	14000010 	b	3af8 <fwp_free_zombie+0x1a8>
    3abc:	f9400800 	ldr	x0, [x0, #16]
    3ac0:	b40001c0 	cbz	x0, 3af8 <fwp_free_zombie+0x1a8>
    3ac4:	f9400001 	ldr	x1, [x0]
    3ac8:	eb14003f 	cmp	x1, x20
    3acc:	54ffff81 	b.ne	3abc <fwp_free_zombie+0x16c>  // b.any
    3ad0:	f9400401 	ldr	x1, [x0, #8]
    3ad4:	d1000421 	sub	x1, x1, #0x1
    3ad8:	f9000401 	str	x1, [x0, #8]
    3adc:	f103f83f 	cmp	x1, #0xfe
    3ae0:	54fff761 	b.ne	39cc <fwp_free_zombie+0x7c>  // b.any
    3ae4:	aa1403e0 	mov	x0, x20
    3ae8:	97fffc2f 	bl	2ba4 <fwp_rc_forget_slot>
    3aec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3af0:	39000280 	strb	w0, [x20]
    3af4:	17ffffb6 	b	39cc <fwp_free_zombie+0x7c>
    3af8:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    3afc:	91276000 	add	x0, x0, #0x9d8
    3b00:	97fff968 	bl	20a0 <fwp_trap>

0000000000003b04 <fwp_block>:
    3b04:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3b08:	910003fd 	mov	x29, sp
    3b0c:	a90153f3 	stp	x19, x20, [sp, #16]
    3b10:	b00000f3 	adrp	x19, 20000 <__data_start>
    3b14:	9101c274 	add	x20, x19, #0x70
    3b18:	f9401682 	ldr	x2, [x20, #40]
    3b1c:	b4000622 	cbz	x2, 3be0 <fwp_block+0xdc>
    3b20:	9101c261 	add	x1, x19, #0x70
    3b24:	f9408040 	ldr	x0, [x2, #256]
    3b28:	f9001420 	str	x0, [x1, #40]
    3b2c:	b4000680 	cbz	x0, 3bfc <fwp_block+0xf8>
    3b30:	9101c263 	add	x3, x19, #0x70
    3b34:	3901505f 	strb	wzr, [x2, #84]
    3b38:	f9400464 	ldr	x4, [x3, #8]
    3b3c:	eb02009f 	cmp	x4, x2
    3b40:	54000440 	b.eq	3bc8 <fwp_block+0xc4>  // b.none
    3b44:	f9412c65 	ldr	x5, [x3, #600]
    3b48:	f9000462 	str	x2, [x3, #8]
    3b4c:	f9400441 	ldr	x1, [x2, #8]
    3b50:	f9004885 	str	x5, [x4, #144]
    3b54:	f9413065 	ldr	x5, [x3, #608]
    3b58:	f9004c85 	str	x5, [x4, #152]
    3b5c:	f9413465 	ldr	x5, [x3, #616]
    3b60:	f9005085 	str	x5, [x4, #160]
    3b64:	f9413865 	ldr	x5, [x3, #624]
    3b68:	f9005485 	str	x5, [x4, #168]
    3b6c:	f9413c65 	ldr	x5, [x3, #632]
    3b70:	f9005885 	str	x5, [x4, #176]
    3b74:	f9414065 	ldr	x5, [x3, #640]
    3b78:	f9005c85 	str	x5, [x4, #184]
    3b7c:	f9414465 	ldr	x5, [x3, #648]
    3b80:	f9006085 	str	x5, [x4, #192]
    3b84:	f9400480 	ldr	x0, [x4, #8]
    3b88:	f9404844 	ldr	x4, [x2, #144]
    3b8c:	f9012c64 	str	x4, [x3, #600]
    3b90:	f9404c44 	ldr	x4, [x2, #152]
    3b94:	f9013064 	str	x4, [x3, #608]
    3b98:	f9405044 	ldr	x4, [x2, #160]
    3b9c:	f9013464 	str	x4, [x3, #616]
    3ba0:	f9405444 	ldr	x4, [x2, #168]
    3ba4:	f9013864 	str	x4, [x3, #624]
    3ba8:	f9405844 	ldr	x4, [x2, #176]
    3bac:	f9013c64 	str	x4, [x3, #632]
    3bb0:	a94b8844 	ldp	x4, x2, [x2, #184]
    3bb4:	f9014064 	str	x4, [x3, #640]
    3bb8:	f9014462 	str	x2, [x3, #648]
    3bbc:	97fff651 	bl	1500 <swapcontext@plt>
    3bc0:	97ffff64 	bl	3950 <fwp_free_zombie>
    3bc4:	d503201f 	nop
    3bc8:	9101c260 	add	x0, x19, #0x70
    3bcc:	b9429000 	ldr	w0, [x0, #656]
    3bd0:	340001a0 	cbz	w0, 3c04 <fwp_block+0x100>
    3bd4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3bd8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3bdc:	d65f03c0 	ret
    3be0:	97fffb64 	bl	2970 <fwp_poll_events>
    3be4:	f9401682 	ldr	x2, [x20, #40]
    3be8:	b4ffffc2 	cbz	x2, 3be0 <fwp_block+0xdc>
    3bec:	9101c261 	add	x1, x19, #0x70
    3bf0:	f9408040 	ldr	x0, [x2, #256]
    3bf4:	f9001420 	str	x0, [x1, #40]
    3bf8:	b5fff9c0 	cbnz	x0, 3b30 <fwp_block+0x2c>
    3bfc:	f900103f 	str	xzr, [x1, #32]
    3c00:	17ffffcc 	b	3b30 <fwp_block+0x2c>
    3c04:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    3c08:	91284000 	add	x0, x0, #0xa10
    3c0c:	97fff689 	bl	1630 <getenv@plt>
    3c10:	5284e202 	mov	w2, #0x2710                	// #10000
    3c14:	b4000060 	cbz	x0, 3c20 <fwp_block+0x11c>
    3c18:	39400001 	ldrb	w1, [x0]
    3c1c:	350000c1 	cbnz	w1, 3c34 <fwp_block+0x130>
    3c20:	9101c273 	add	x19, x19, #0x70
    3c24:	b9029262 	str	w2, [x19, #656]
    3c28:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c30:	d65f03c0 	ret
    3c34:	52800142 	mov	w2, #0xa                   	// #10
    3c38:	d2800001 	mov	x1, #0x0                   	// #0
    3c3c:	97fff5cd 	bl	1370 <strtoll@plt>
    3c40:	d1000403 	sub	x3, x0, #0x1
    3c44:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3c48:	eb02007f 	cmp	x3, x2
    3c4c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3c50:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3c54:	17fffff3 	b	3c20 <fwp_block+0x11c>
    3c58:	d503201f 	nop
    3c5c:	d503201f 	nop

0000000000003c60 <fwp_write.constprop.0>:
    3c60:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3c64:	910003fd 	mov	x29, sp
    3c68:	900000e3 	adrp	x3, 1f000 <__FRAME_END__+0x17668>
    3c6c:	f947f463 	ldr	x3, [x3, #4072]
    3c70:	a90153f3 	stp	x19, x20, [sp, #16]
    3c74:	d10943ff 	sub	sp, sp, #0x250
    3c78:	aa0003f4 	mov	x20, x0
    3c7c:	b9400040 	ldr	w0, [x2]
    3c80:	aa0103f3 	mov	x19, x1
    3c84:	f9400061 	ldr	x1, [x3]
    3c88:	f90127e1 	str	x1, [sp, #584]
    3c8c:	d2800001 	mov	x1, #0x0                   	// #0
    3c90:	7100641f 	cmp	w0, #0x19
    3c94:	540003e8 	b.hi	3d10 <fwp_write.constprop.0+0xb0>  // b.pmore
    3c98:	f0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    3c9c:	91330021 	add	x1, x1, #0xcc0
    3ca0:	f9013bf5 	str	x21, [sp, #624]
    3ca4:	f9013ff6 	str	x22, [sp, #632]
    3ca8:	f90153fb 	str	x27, [sp, #672]
    3cac:	f90157fc 	str	x28, [sp, #680]
    3cb0:	aa0203fc 	mov	x28, x2
    3cb4:	78605821 	ldrh	w1, [x1, w0, uxtw #1]
    3cb8:	10000062 	adr	x2, 3cc4 <fwp_write.constprop.0+0x64>
    3cbc:	8b21a841 	add	x1, x2, w1, sxth #2
    3cc0:	d61f0020 	br	x1
    3cc4:	910123e0 	add	x0, sp, #0x48
    3cc8:	aa1303e5 	mov	x5, x19
    3ccc:	f0000004 	adrp	x4, 6000 <fwp_main_thread+0x13fc>
    3cd0:	aa0003f3 	mov	x19, x0
    3cd4:	91296084 	add	x4, x4, #0xa58
    3cd8:	d2804003 	mov	x3, #0x200                 	// #512
    3cdc:	aa0303e1 	mov	x1, x3
    3ce0:	52800042 	mov	w2, #0x2                   	// #2
    3ce4:	97fff5cb 	bl	1410 <__snprintf_chk@plt>
    3ce8:	aa1303e0 	mov	x0, x19
    3cec:	97fff591 	bl	1330 <strlen@plt>
    3cf0:	aa1303e1 	mov	x1, x19
    3cf4:	aa0003e2 	mov	x2, x0
    3cf8:	aa1403e0 	mov	x0, x20
    3cfc:	97fff88d 	bl	1f30 <buf_put>
    3d00:	f9413bf5 	ldr	x21, [sp, #624]
    3d04:	f9413ff6 	ldr	x22, [sp, #632]
    3d08:	f94153fb 	ldr	x27, [sp, #672]
    3d0c:	f94157fc 	ldr	x28, [sp, #680]
    3d10:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    3d14:	f947f400 	ldr	x0, [x0, #4072]
    3d18:	f94127e2 	ldr	x2, [sp, #584]
    3d1c:	f9400001 	ldr	x1, [x0]
    3d20:	eb010042 	subs	x2, x2, x1
    3d24:	d2800001 	mov	x1, #0x0                   	// #0
    3d28:	540074a1 	b.ne	4bbc <fwp_write.constprop.0+0xf5c>  // b.any
    3d2c:	910943ff 	add	sp, sp, #0x250
    3d30:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d34:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3d38:	d65f03c0 	ret
    3d3c:	910123e0 	add	x0, sp, #0x48
    3d40:	aa1303e5 	mov	x5, x19
    3d44:	f0000004 	adrp	x4, 6000 <fwp_main_thread+0x13fc>
    3d48:	aa0003f3 	mov	x19, x0
    3d4c:	91294084 	add	x4, x4, #0xa50
    3d50:	d2804003 	mov	x3, #0x200                 	// #512
    3d54:	17ffffe2 	b	3cdc <fwp_write.constprop.0+0x7c>
    3d58:	71004c1f 	cmp	w0, #0x13
    3d5c:	f0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    3d60:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    3d64:	91292021 	add	x1, x1, #0xa48
    3d68:	91290000 	add	x0, x0, #0xa40
    3d6c:	d2800082 	mov	x2, #0x4                   	// #4
    3d70:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    3d74:	aa1403e0 	mov	x0, x20
    3d78:	f90143f7 	str	x23, [sp, #640]
    3d7c:	d2800016 	mov	x22, #0x0                   	// #0
    3d80:	f90147f8 	str	x24, [sp, #648]
    3d84:	97fff86b 	bl	1f30 <buf_put>
    3d88:	f9400260 	ldr	x0, [x19]
    3d8c:	f0000017 	adrp	x23, 6000 <fwp_main_thread+0x13fc>
    3d90:	d2800015 	mov	x21, #0x0                   	// #0
    3d94:	912b22f7 	add	x23, x23, #0xac8
    3d98:	b4004e40 	cbz	x0, 4760 <fwp_write.constprop.0+0xb00>
    3d9c:	b9400381 	ldr	w1, [x28]
    3da0:	aa1403e0 	mov	x0, x20
    3da4:	f9401f82 	ldr	x2, [x28, #56]
    3da8:	71004c3f 	cmp	w1, #0x13
    3dac:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    3db0:	8b010e61 	add	x1, x19, x1, lsl #3
    3db4:	f9400421 	ldr	x1, [x1, #8]
    3db8:	97ffffaa 	bl	3c60 <fwp_write.constprop.0>
    3dbc:	b9400380 	ldr	w0, [x28]
    3dc0:	7100481f 	cmp	w0, #0x12
    3dc4:	540050c0 	b.eq	47dc <fwp_write.constprop.0+0xb7c>  // b.none
    3dc8:	f9400260 	ldr	x0, [x19]
    3dcc:	910006b5 	add	x21, x21, #0x1
    3dd0:	91000ad6 	add	x22, x22, #0x2
    3dd4:	eb0002bf 	cmp	x21, x0
    3dd8:	54004c42 	b.cs	4760 <fwp_write.constprop.0+0xb00>  // b.hs, b.nlast
    3ddc:	aa1703e1 	mov	x1, x23
    3de0:	aa1403e0 	mov	x0, x20
    3de4:	d2800042 	mov	x2, #0x2                   	// #2
    3de8:	97fff852 	bl	1f30 <buf_put>
    3dec:	17ffffec 	b	3d9c <fwp_write.constprop.0+0x13c>
    3df0:	f0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    3df4:	912a0021 	add	x1, x1, #0xa80
    3df8:	d28000c2 	mov	x2, #0x6                   	// #6
    3dfc:	aa1403e0 	mov	x0, x20
    3e00:	91004273 	add	x19, x19, #0x10
    3e04:	97fff84b 	bl	1f30 <buf_put>
    3e08:	aa1303e0 	mov	x0, x19
    3e0c:	97fff549 	bl	1330 <strlen@plt>
    3e10:	aa1303e1 	mov	x1, x19
    3e14:	aa0003e2 	mov	x2, x0
    3e18:	aa1403e0 	mov	x0, x20
    3e1c:	97fff845 	bl	1f30 <buf_put>
    3e20:	528007c3 	mov	w3, #0x3e                  	// #62
    3e24:	aa1403e0 	mov	x0, x20
    3e28:	91001fe1 	add	x1, sp, #0x7
    3e2c:	d2800022 	mov	x2, #0x1                   	// #1
    3e30:	39001fe3 	strb	w3, [sp, #7]
    3e34:	17ffffb2 	b	3cfc <fwp_write.constprop.0+0x9c>
    3e38:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    3e3c:	f947f400 	ldr	x0, [x0, #4072]
    3e40:	f94127e2 	ldr	x2, [sp, #584]
    3e44:	f9400001 	ldr	x1, [x0]
    3e48:	eb010042 	subs	x2, x2, x1
    3e4c:	d2800001 	mov	x1, #0x0                   	// #0
    3e50:	54006cc1 	b.ne	4be8 <fwp_write.constprop.0+0xf88>  // b.any
    3e54:	f9413bf5 	ldr	x21, [sp, #624]
    3e58:	f0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    3e5c:	f9413ff6 	ldr	x22, [sp, #632]
    3e60:	aa1403e0 	mov	x0, x20
    3e64:	91298021 	add	x1, x1, #0xa60
    3e68:	d2800142 	mov	x2, #0xa                   	// #10
    3e6c:	f94153fb 	ldr	x27, [sp, #672]
    3e70:	f94157fc 	ldr	x28, [sp, #680]
    3e74:	910943ff 	add	sp, sp, #0x250
    3e78:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e7c:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3e80:	17fff82c 	b	1f30 <buf_put>
    3e84:	f9400796 	ldr	x22, [x28, #8]
    3e88:	f90143f7 	str	x23, [sp, #640]
    3e8c:	f90147f8 	str	x24, [sp, #648]
    3e90:	b4005816 	cbz	x22, 4990 <fwp_write.constprop.0+0xd30>
    3e94:	aa1603e0 	mov	x0, x22
    3e98:	f0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    3e9c:	912b8021 	add	x1, x1, #0xae0
    3ea0:	97fff5a0 	bl	1520 <strcmp@plt>
    3ea4:	2a0003f5 	mov	w21, w0
    3ea8:	34005ce0 	cbz	w0, 4a44 <fwp_write.constprop.0+0xde4>
    3eac:	aa1603e0 	mov	x0, x22
    3eb0:	97fff520 	bl	1330 <strlen@plt>
    3eb4:	aa1603e1 	mov	x1, x22
    3eb8:	aa0003e2 	mov	x2, x0
    3ebc:	aa1403e0 	mov	x0, x20
    3ec0:	97fff81c 	bl	1f30 <buf_put>
    3ec4:	52800403 	mov	w3, #0x20                  	// #32
    3ec8:	91001ff5 	add	x21, sp, #0x7
    3ecc:	aa1503e1 	mov	x1, x21
    3ed0:	aa1403e0 	mov	x0, x20
    3ed4:	d2800022 	mov	x2, #0x1                   	// #1
    3ed8:	39001fe3 	strb	w3, [sp, #7]
    3edc:	97fff815 	bl	1f30 <buf_put>
    3ee0:	52800f63 	mov	w3, #0x7b                  	// #123
    3ee4:	aa1403e0 	mov	x0, x20
    3ee8:	aa1503e1 	mov	x1, x21
    3eec:	d2800022 	mov	x2, #0x1                   	// #1
    3ef0:	39001fe3 	strb	w3, [sp, #7]
    3ef4:	97fff80f 	bl	1f30 <buf_put>
    3ef8:	b9401380 	ldr	w0, [x28, #16]
    3efc:	52800018 	mov	w24, #0x0                   	// #0
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	54003d8d 	b.le	46b4 <fwp_write.constprop.0+0xa54>
    3f08:	f9014bf9 	str	x25, [sp, #656]
    3f0c:	f0000019 	adrp	x25, 6000 <fwp_main_thread+0x13fc>
    3f10:	912c2339 	add	x25, x25, #0xb08
    3f14:	f9014ffa 	str	x26, [sp, #664]
    3f18:	f000001a 	adrp	x26, 6000 <fwp_main_thread+0x13fc>
    3f1c:	912b235a 	add	x26, x26, #0xac8
    3f20:	91002276 	add	x22, x19, #0x8
    3f24:	d2800013 	mov	x19, #0x0                   	// #0
    3f28:	b5004413 	cbnz	x19, 47a8 <fwp_write.constprop.0+0xb48>
    3f2c:	d37df277 	lsl	x23, x19, #3
    3f30:	34004238 	cbz	w24, 4774 <fwp_write.constprop.0+0xb14>
    3f34:	f9401382 	ldr	x2, [x28, #32]
    3f38:	aa1403e0 	mov	x0, x20
    3f3c:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    3f40:	91000673 	add	x19, x19, #0x1
    3f44:	f8776842 	ldr	x2, [x2, x23]
    3f48:	97ffff46 	bl	3c60 <fwp_write.constprop.0>
    3f4c:	b9401380 	ldr	w0, [x28, #16]
    3f50:	6b13001f 	cmp	w0, w19
    3f54:	54fffeac 	b.gt	3f28 <fwp_write.constprop.0+0x2c8>
    3f58:	f9414bf9 	ldr	x25, [sp, #656]
    3f5c:	f9414ffa 	ldr	x26, [sp, #664]
    3f60:	34003ab8 	cbz	w24, 46b4 <fwp_write.constprop.0+0xa54>
    3f64:	52800523 	mov	w3, #0x29                  	// #41
    3f68:	aa1503e1 	mov	x1, x21
    3f6c:	aa1403e0 	mov	x0, x20
    3f70:	d2800022 	mov	x2, #0x1                   	// #1
    3f74:	39001fe3 	strb	w3, [sp, #7]
    3f78:	97fff7ee 	bl	1f30 <buf_put>
    3f7c:	f9413bf5 	ldr	x21, [sp, #624]
    3f80:	f9413ff6 	ldr	x22, [sp, #632]
    3f84:	f94143f7 	ldr	x23, [sp, #640]
    3f88:	f94147f8 	ldr	x24, [sp, #648]
    3f8c:	f94153fb 	ldr	x27, [sp, #672]
    3f90:	f94157fc 	ldr	x28, [sp, #680]
    3f94:	17ffff5f 	b	3d10 <fwp_write.constprop.0+0xb0>
    3f98:	b9404b95 	ldr	w21, [x28, #72]
    3f9c:	aa1403e0 	mov	x0, x20
    3fa0:	93407eb6 	sxtw	x22, w21
    3fa4:	91000ac1 	add	x1, x22, #0x2
    3fa8:	97fff7ae 	bl	1e60 <buf_grow>
    3fac:	a9400281 	ldp	x1, x0, [x20]
    3fb0:	528e8603 	mov	w3, #0x7430                	// #29744
    3fb4:	78206823 	strh	w3, [x1, x0]
    3fb8:	8b000022 	add	x2, x1, x0
    3fbc:	710002bf 	cmp	w21, #0x0
    3fc0:	54003bcd 	b.le	4738 <fwp_write.constprop.0+0xad8>
    3fc4:	110006a3 	add	w3, w21, #0x1
    3fc8:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    3fcc:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    3fd0:	91000449 	add	x9, x2, #0x1
    3fd4:	8b23c043 	add	x3, x2, w3, sxtw
    3fd8:	f28aaac6 	movk	x6, #0x5556
    3fdc:	f2955568 	movk	x8, #0xaaab
    3fe0:	1400000d 	b	4014 <fwp_write.constprop.0+0x3b4>
    3fe4:	d2800021 	mov	x1, #0x1                   	// #1
    3fe8:	528005a5 	mov	w5, #0x2d                  	// #45
    3fec:	f100001f 	cmp	x0, #0x0
    3ff0:	9b467e60 	smulh	x0, x19, x6
    3ff4:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    3ff8:	381ff465 	strb	w5, [x3], #-1
    3ffc:	cb040000 	sub	x0, x0, x4
    4000:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    4004:	cb020000 	sub	x0, x0, x2
    4008:	8b010013 	add	x19, x0, x1
    400c:	eb03013f 	cmp	x9, x3
    4010:	54003940 	b.eq	4738 <fwp_write.constprop.0+0xad8>  // b.none
    4014:	9b467e60 	smulh	x0, x19, x6
    4018:	937ffe64 	asr	x4, x19, #63
    401c:	52800605 	mov	w5, #0x30                  	// #48
    4020:	cb040000 	sub	x0, x0, x4
    4024:	8b000400 	add	x0, x0, x0, lsl #1
    4028:	cb000260 	sub	x0, x19, x0
    402c:	91000c01 	add	x1, x0, #0x3
    4030:	9bc87c22 	umulh	x2, x1, x8
    4034:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    4038:	8b4204e2 	add	x2, x7, x2, lsr #1
    403c:	eb020021 	subs	x1, x1, x2
    4040:	54fffd60 	b.eq	3fec <fwp_write.constprop.0+0x38c>  // b.none
    4044:	f100043f 	cmp	x1, #0x1
    4048:	54fffce1 	b.ne	3fe4 <fwp_write.constprop.0+0x384>  // b.any
    404c:	d2800001 	mov	x1, #0x0                   	// #0
    4050:	52800565 	mov	w5, #0x2b                  	// #43
    4054:	17ffffe6 	b	3fec <fwp_write.constprop.0+0x38c>
    4058:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    405c:	f947f400 	ldr	x0, [x0, #4072]
    4060:	f94127e2 	ldr	x2, [sp, #584]
    4064:	f9400001 	ldr	x1, [x0]
    4068:	eb010042 	subs	x2, x2, x1
    406c:	d2800001 	mov	x1, #0x0                   	// #0
    4070:	54005bc1 	b.ne	4be8 <fwp_write.constprop.0+0xf88>  // b.any
    4074:	f9413bf5 	ldr	x21, [sp, #624]
    4078:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    407c:	f9413ff6 	ldr	x22, [sp, #632]
    4080:	aa1403e0 	mov	x0, x20
    4084:	9129c021 	add	x1, x1, #0xa70
    4088:	d2800102 	mov	x2, #0x8                   	// #8
    408c:	17ffff78 	b	3e6c <fwp_write.constprop.0+0x20c>
    4090:	aa1403e0 	mov	x0, x20
    4094:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    4098:	d28000c2 	mov	x2, #0x6                   	// #6
    409c:	912b4021 	add	x1, x1, #0xad0
    40a0:	97fff7a4 	bl	1f30 <buf_put>
    40a4:	d2800015 	mov	x21, #0x0                   	// #0
    40a8:	f9400263 	ldr	x3, [x19]
    40ac:	f240f87f 	tst	x3, #0x7fffffffffffffff
    40b0:	540026a0 	b.eq	4584 <fwp_write.constprop.0+0x924>  // b.none
    40b4:	f9401f82 	ldr	x2, [x28, #56]
    40b8:	f90143f7 	str	x23, [sp, #640]
    40bc:	f90147f8 	str	x24, [sp, #648]
    40c0:	d2800857 	mov	x23, #0x42                  	// #66
    40c4:	f9014bf9 	str	x25, [sp, #656]
    40c8:	d0000016 	adrp	x22, 6000 <fwp_main_thread+0x13fc>
    40cc:	f9014ffa 	str	x26, [sp, #664]
    40d0:	912b22d6 	add	x22, x22, #0xac8
    40d4:	d2800038 	mov	x24, #0x1                   	// #1
    40d8:	f2a18017 	movk	x23, #0xc00, lsl #16
    40dc:	d2809099 	mov	x25, #0x484                 	// #1156
    40e0:	b4000482 	cbz	x2, 4170 <fwp_write.constprop.0+0x510>
    40e4:	b9400040 	ldr	w0, [x2]
    40e8:	7100701f 	cmp	w0, #0x1c
    40ec:	540042e0 	b.eq	4948 <fwp_write.constprop.0+0xce8>  // b.none
    40f0:	71006c1f 	cmp	w0, #0x1b
    40f4:	540003e8 	b.hi	4170 <fwp_write.constprop.0+0x510>  // b.pmore
    40f8:	9ac02301 	lsl	x1, x24, x0
    40fc:	ea17003f 	tst	x1, x23
    4100:	54003f21 	b.ne	48e4 <fwp_write.constprop.0+0xc84>  // b.any
    4104:	ea19003f 	tst	x1, x25
    4108:	54003da1 	b.ne	48bc <fwp_write.constprop.0+0xc5c>  // b.any
    410c:	d2800425 	mov	x5, #0x21                  	// #33
    4110:	ea05003f 	tst	x1, x5
    4114:	540002e0 	b.eq	4170 <fwp_write.constprop.0+0x510>  // b.none
    4118:	b7f84743 	tbnz	x3, #63, 4a00 <fwp_write.constprop.0+0xda0>
    411c:	91002261 	add	x1, x19, #0x8
    4120:	8b150021 	add	x1, x1, x21
    4124:	39400021 	ldrb	w1, [x1]
    4128:	7100001f 	cmp	w0, #0x0
    412c:	93401c23 	sxtb	x3, w1
    4130:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4134:	d503201f 	nop
    4138:	aa1403e0 	mov	x0, x20
    413c:	97fffec9 	bl	3c60 <fwp_write.constprop.0>
    4140:	f9400260 	ldr	x0, [x19]
    4144:	910006b5 	add	x21, x21, #0x1
    4148:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    414c:	eb0002bf 	cmp	x21, x0
    4150:	54002122 	b.cs	4574 <fwp_write.constprop.0+0x914>  // b.hs, b.nlast
    4154:	d2800042 	mov	x2, #0x2                   	// #2
    4158:	aa1603e1 	mov	x1, x22
    415c:	aa1403e0 	mov	x0, x20
    4160:	97fff774 	bl	1f30 <buf_put>
    4164:	f9401f82 	ldr	x2, [x28, #56]
    4168:	f9400263 	ldr	x3, [x19]
    416c:	b5fffbc2 	cbnz	x2, 40e4 <fwp_write.constprop.0+0x484>
    4170:	d37df2a0 	lsl	x0, x21, #3
    4174:	b7f83f43 	tbnz	x3, #63, 495c <fwp_write.constprop.0+0xcfc>
    4178:	91002261 	add	x1, x19, #0x8
    417c:	8b000020 	add	x0, x1, x0
    4180:	f9400001 	ldr	x1, [x0]
    4184:	17ffffed 	b	4138 <fwp_write.constprop.0+0x4d8>
    4188:	a9400e62 	ldp	x2, x3, [x19]
    418c:	b7f83ce3 	tbnz	x3, #63, 4928 <fwp_write.constprop.0+0xcc8>
    4190:	910123f5 	add	x21, sp, #0x48
    4194:	aa1503e0 	mov	x0, x21
    4198:	97fff612 	bl	19e0 <fwp_fmt_u128>
    419c:	aa1503e0 	mov	x0, x21
    41a0:	97fff464 	bl	1330 <strlen@plt>
    41a4:	aa1503e1 	mov	x1, x21
    41a8:	aa0003e2 	mov	x2, x0
    41ac:	17fffed3 	b	3cf8 <fwp_write.constprop.0+0x98>
    41b0:	fd015be8 	str	d8, [sp, #688]
    41b4:	1e270268 	fmov	s8, w19
    41b8:	fd015fe9 	str	d9, [sp, #696]
    41bc:	1e282100 	fcmp	s8, s8
    41c0:	54004a66 	b.vs	4b0c <fwp_write.constprop.0+0xeac>
    41c4:	1e20c101 	fabs	s1, s8
    41c8:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    41cc:	1e270000 	fmov	s0, w0
    41d0:	1e202020 	fcmp	s1, s0
    41d4:	540034ad 	b.le	4868 <fwp_write.constprop.0+0xc08>
    41d8:	1e202118 	fcmpe	s8, #0.0
    41dc:	d0000002 	adrp	x2, 6000 <fwp_main_thread+0x13fc>
    41e0:	9120c042 	add	x2, x2, #0x830
    41e4:	910123f5 	add	x21, sp, #0x48
    41e8:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    41ec:	91288021 	add	x1, x1, #0xa20
    41f0:	aa1503e0 	mov	x0, x21
    41f4:	9a81c041 	csel	x1, x2, x1, gt
    41f8:	97fff4fa 	bl	15e0 <strcpy@plt>
    41fc:	d503201f 	nop
    4200:	aa1503e0 	mov	x0, x21
    4204:	97fff44b 	bl	1330 <strlen@plt>
    4208:	aa1503e1 	mov	x1, x21
    420c:	aa0003e2 	mov	x2, x0
    4210:	aa1403e0 	mov	x0, x20
    4214:	97fff747 	bl	1f30 <buf_put>
    4218:	f9413bf5 	ldr	x21, [sp, #624]
    421c:	f9413ff6 	ldr	x22, [sp, #632]
    4220:	f94153fb 	ldr	x27, [sp, #672]
    4224:	f94157fc 	ldr	x28, [sp, #680]
    4228:	fd415be8 	ldr	d8, [sp, #688]
    422c:	fd415fe9 	ldr	d9, [sp, #696]
    4230:	17fffeb8 	b	3d10 <fwp_write.constprop.0+0xb0>
    4234:	f90143f7 	str	x23, [sp, #640]
    4238:	52800443 	mov	w3, #0x22                  	// #34
    423c:	f90147f8 	str	x24, [sp, #648]
    4240:	91001ff5 	add	x21, sp, #0x7
    4244:	aa1503e1 	mov	x1, x21
    4248:	aa1403e0 	mov	x0, x20
    424c:	f8408677 	ldr	x23, [x19], #8
    4250:	d2800022 	mov	x2, #0x1                   	// #1
    4254:	39001fe3 	strb	w3, [sp, #7]
    4258:	97fff736 	bl	1f30 <buf_put>
    425c:	8b1302f6 	add	x22, x23, x19
    4260:	b4002657 	cbz	x23, 4728 <fwp_write.constprop.0+0xac8>
    4264:	d0000018 	adrp	x24, 6000 <fwp_main_thread+0x13fc>
    4268:	912a2318 	add	x24, x24, #0xa88
    426c:	f9014bf9 	str	x25, [sp, #656]
    4270:	d0000019 	adrp	x25, 6000 <fwp_main_thread+0x13fc>
    4274:	912aa339 	add	x25, x25, #0xaa8
    4278:	f9014ffa 	str	x26, [sp, #664]
    427c:	1400000e 	b	42b4 <fwp_write.constprop.0+0x654>
    4280:	710024bf 	cmp	w5, #0x9
    4284:	54002380 	b.eq	46f4 <fwp_write.constprop.0+0xa94>  // b.none
    4288:	710028bf 	cmp	w5, #0xa
    428c:	54002be1 	b.ne	4808 <fwp_write.constprop.0+0xba8>  // b.any
    4290:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    4294:	aa1403e0 	mov	x0, x20
    4298:	912a6021 	add	x1, x1, #0xa98
    429c:	d2800042 	mov	x2, #0x2                   	// #2
    42a0:	97fff724 	bl	1f30 <buf_put>
    42a4:	d503201f 	nop
    42a8:	91000673 	add	x19, x19, #0x1
    42ac:	eb16027f 	cmp	x19, x22
    42b0:	54002380 	b.eq	4720 <fwp_write.constprop.0+0xac0>  // b.none
    42b4:	39400265 	ldrb	w5, [x19]
    42b8:	710034bf 	cmp	w5, #0xd
    42bc:	54002120 	b.eq	46e0 <fwp_write.constprop.0+0xa80>  // b.none
    42c0:	54fffe09 	b.ls	4280 <fwp_write.constprop.0+0x620>  // b.plast
    42c4:	710088bf 	cmp	w5, #0x22
    42c8:	54002220 	b.eq	470c <fwp_write.constprop.0+0xaac>  // b.none
    42cc:	710170bf 	cmp	w5, #0x5c
    42d0:	54002ba1 	b.ne	4844 <fwp_write.constprop.0+0xbe4>  // b.any
    42d4:	aa1403e0 	mov	x0, x20
    42d8:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    42dc:	d2800042 	mov	x2, #0x2                   	// #2
    42e0:	912a4021 	add	x1, x1, #0xa90
    42e4:	97fff713 	bl	1f30 <buf_put>
    42e8:	17fffff0 	b	42a8 <fwp_write.constprop.0+0x648>
    42ec:	fd015be8 	str	d8, [sp, #688]
    42f0:	9e670268 	fmov	d8, x19
    42f4:	fd015fe9 	str	d9, [sp, #696]
    42f8:	1e682100 	fcmp	d8, d8
    42fc:	54004086 	b.vs	4b0c <fwp_write.constprop.0+0xeac>
    4300:	1e60c101 	fabs	d1, d8
    4304:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    4308:	9e670000 	fmov	d0, x0
    430c:	910123f5 	add	x21, sp, #0x48
    4310:	52800033 	mov	w19, #0x1                   	// #1
    4314:	1e602020 	fcmp	d1, d0
    4318:	540001ad 	b.le	434c <fwp_write.constprop.0+0x6ec>
    431c:	1e602118 	fcmpe	d8, #0.0
    4320:	d0000002 	adrp	x2, 6000 <fwp_main_thread+0x13fc>
    4324:	9120c042 	add	x2, x2, #0x830
    4328:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    432c:	91288021 	add	x1, x1, #0xa20
    4330:	aa1503e0 	mov	x0, x21
    4334:	9a81c041 	csel	x1, x2, x1, gt
    4338:	97fff4aa 	bl	15e0 <strcpy@plt>
    433c:	17ffffb1 	b	4200 <fwp_write.constprop.0+0x5a0>
    4340:	11000673 	add	w19, w19, #0x1
    4344:	71004a7f 	cmp	w19, #0x12
    4348:	540031a0 	b.eq	497c <fwp_write.constprop.0+0xd1c>  // b.none
    434c:	1e604100 	fmov	d0, d8
    4350:	2a1303e1 	mov	w1, w19
    4354:	aa1503e0 	mov	x0, x21
    4358:	97fff78a 	bl	2180 <fwp_format_g.constprop.0>
    435c:	aa1503e0 	mov	x0, x21
    4360:	d2800001 	mov	x1, #0x0                   	// #0
    4364:	97fff407 	bl	1380 <strtod@plt>
    4368:	1e602100 	fcmp	d8, d0
    436c:	54fffea1 	b.ne	4340 <fwp_write.constprop.0+0x6e0>  // b.any
    4370:	aa1503e0 	mov	x0, x21
    4374:	97fff728 	bl	2014 <fwp_finish_float>
    4378:	17ffffa2 	b	4200 <fwp_write.constprop.0+0x5a0>
    437c:	a9400e62 	ldp	x2, x3, [x19]
    4380:	910123f3 	add	x19, sp, #0x48
    4384:	aa1303e0 	mov	x0, x19
    4388:	97fff596 	bl	19e0 <fwp_fmt_u128>
    438c:	17fffe57 	b	3ce8 <fwp_write.constprop.0+0x88>
    4390:	f90143f7 	str	x23, [sp, #640]
    4394:	f90147f8 	str	x24, [sp, #648]
    4398:	2a1303f8 	mov	w24, w19
    439c:	f9014bf9 	str	x25, [sp, #656]
    43a0:	f9014ffa 	str	x26, [sp, #664]
    43a4:	f13ffe7f 	cmp	x19, #0xfff
    43a8:	54000049 	b.ls	43b0 <fwp_write.constprop.0+0x750>  // b.plast
    43ac:	b9400278 	ldr	w24, [x19]
    43b0:	f9400f80 	ldr	x0, [x28, #24]
    43b4:	2a1803f5 	mov	w21, w24
    43b8:	d37d7f18 	ubfiz	x24, x24, #3, #32
    43bc:	d37ef6b9 	lsl	x25, x21, #2
    43c0:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    43c4:	aa1603e0 	mov	x0, x22
    43c8:	97fff3da 	bl	1330 <strlen@plt>
    43cc:	aa1603e1 	mov	x1, x22
    43d0:	aa0003e2 	mov	x2, x0
    43d4:	aa1403e0 	mov	x0, x20
    43d8:	97fff6d6 	bl	1f30 <buf_put>
    43dc:	f9401780 	ldr	x0, [x28, #40]
    43e0:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    43e4:	7100001f 	cmp	w0, #0x0
    43e8:	5400064d 	b.le	44b0 <fwp_write.constprop.0+0x850>
    43ec:	91002276 	add	x22, x19, #0x8
    43f0:	91001ff5 	add	x21, sp, #0x7
    43f4:	d280001b 	mov	x27, #0x0                   	// #0
    43f8:	5280041a 	mov	w26, #0x20                  	// #32
    43fc:	f9401b80 	ldr	x0, [x28, #48]
    4400:	aa1503e1 	mov	x1, x21
    4404:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    4408:	d2800022 	mov	x2, #0x1                   	// #1
    440c:	f8786805 	ldr	x5, [x0, x24]
    4410:	aa1403e0 	mov	x0, x20
    4414:	f87b78b3 	ldr	x19, [x5, x27, lsl #3]
    4418:	39001ffa 	strb	w26, [sp, #7]
    441c:	97fff6c5 	bl	1f30 <buf_put>
    4420:	f13ffeff 	cmp	x23, #0xfff
    4424:	b9400261 	ldr	w1, [x19]
    4428:	1a9f97e0 	cset	w0, hi	// hi = pmore
    442c:	7100383f 	cmp	w1, #0xe
    4430:	54000140 	b.eq	4458 <fwp_write.constprop.0+0x7f8>  // b.none
    4434:	7100403f 	cmp	w1, #0x10
    4438:	54001c20 	b.eq	47bc <fwp_write.constprop.0+0xb5c>  // b.none
    443c:	7100283f 	cmp	w1, #0xa
    4440:	540026e0 	b.eq	491c <fwp_write.constprop.0+0xcbc>  // b.none
    4444:	540013cc 	b.gt	46bc <fwp_write.constprop.0+0xa5c>
    4448:	71000c3f 	cmp	w1, #0x3
    444c:	540025ec 	b.gt	4908 <fwp_write.constprop.0+0xca8>
    4450:	d37ffee0 	lsr	x0, x23, #63
    4454:	37f813c1 	tbnz	w1, #31, 46cc <fwp_write.constprop.0+0xa6c>
    4458:	340013a0 	cbz	w0, 46cc <fwp_write.constprop.0+0xa6c>
    445c:	52800503 	mov	w3, #0x28                  	// #40
    4460:	aa1503e1 	mov	x1, x21
    4464:	aa1403e0 	mov	x0, x20
    4468:	d2800022 	mov	x2, #0x1                   	// #1
    446c:	39001fe3 	strb	w3, [sp, #7]
    4470:	97fff6b0 	bl	1f30 <buf_put>
    4474:	aa1303e2 	mov	x2, x19
    4478:	aa1703e1 	mov	x1, x23
    447c:	aa1403e0 	mov	x0, x20
    4480:	97fffdf8 	bl	3c60 <fwp_write.constprop.0>
    4484:	52800523 	mov	w3, #0x29                  	// #41
    4488:	aa1503e1 	mov	x1, x21
    448c:	aa1403e0 	mov	x0, x20
    4490:	d2800022 	mov	x2, #0x1                   	// #1
    4494:	39001fe3 	strb	w3, [sp, #7]
    4498:	97fff6a6 	bl	1f30 <buf_put>
    449c:	f9401780 	ldr	x0, [x28, #40]
    44a0:	9100077b 	add	x27, x27, #0x1
    44a4:	b8796800 	ldr	w0, [x0, x25]
    44a8:	6b1b001f 	cmp	w0, w27
    44ac:	54fffa8c 	b.gt	43fc <fwp_write.constprop.0+0x79c>
    44b0:	f9413bf5 	ldr	x21, [sp, #624]
    44b4:	f9413ff6 	ldr	x22, [sp, #632]
    44b8:	f94143f7 	ldr	x23, [sp, #640]
    44bc:	f94147f8 	ldr	x24, [sp, #648]
    44c0:	f9414bf9 	ldr	x25, [sp, #656]
    44c4:	f9414ffa 	ldr	x26, [sp, #664]
    44c8:	f94153fb 	ldr	x27, [sp, #672]
    44cc:	f94157fc 	ldr	x28, [sp, #680]
    44d0:	17fffe10 	b	3d10 <fwp_write.constprop.0+0xb0>
    44d4:	aa1403e0 	mov	x0, x20
    44d8:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    44dc:	d28000c2 	mov	x2, #0x6                   	// #6
    44e0:	912ae021 	add	x1, x1, #0xab8
    44e4:	97fff693 	bl	1f30 <buf_put>
    44e8:	f9400260 	ldr	x0, [x19]
    44ec:	b40004c0 	cbz	x0, 4584 <fwp_write.constprop.0+0x924>
    44f0:	910123f5 	add	x21, sp, #0x48
    44f4:	91002276 	add	x22, x19, #0x8
    44f8:	f90143f7 	str	x23, [sp, #640]
    44fc:	d2800017 	mov	x23, #0x0                   	// #0
    4500:	f90147f8 	str	x24, [sp, #648]
    4504:	d0000018 	adrp	x24, 6000 <fwp_main_thread+0x13fc>
    4508:	912b0318 	add	x24, x24, #0xac0
    450c:	f9014bf9 	str	x25, [sp, #656]
    4510:	d0000019 	adrp	x25, 6000 <fwp_main_thread+0x13fc>
    4514:	912b2339 	add	x25, x25, #0xac8
    4518:	f9014ffa 	str	x26, [sp, #664]
    451c:	14000005 	b	4530 <fwp_write.constprop.0+0x8d0>
    4520:	aa1903e1 	mov	x1, x25
    4524:	aa1403e0 	mov	x0, x20
    4528:	d2800042 	mov	x2, #0x2                   	// #2
    452c:	97fff681 	bl	1f30 <buf_put>
    4530:	38776ac5 	ldrb	w5, [x22, x23]
    4534:	d2804003 	mov	x3, #0x200                 	// #512
    4538:	aa1803e4 	mov	x4, x24
    453c:	aa0303e1 	mov	x1, x3
    4540:	52800042 	mov	w2, #0x2                   	// #2
    4544:	aa1503e0 	mov	x0, x21
    4548:	910006f7 	add	x23, x23, #0x1
    454c:	97fff3b1 	bl	1410 <__snprintf_chk@plt>
    4550:	aa1503e0 	mov	x0, x21
    4554:	97fff377 	bl	1330 <strlen@plt>
    4558:	aa1503e1 	mov	x1, x21
    455c:	aa0003e2 	mov	x2, x0
    4560:	aa1403e0 	mov	x0, x20
    4564:	97fff673 	bl	1f30 <buf_put>
    4568:	f9400260 	ldr	x0, [x19]
    456c:	eb0002ff 	cmp	x23, x0
    4570:	54fffd83 	b.cc	4520 <fwp_write.constprop.0+0x8c0>  // b.lo, b.ul, b.last
    4574:	f94143f7 	ldr	x23, [sp, #640]
    4578:	f94147f8 	ldr	x24, [sp, #648]
    457c:	f9414bf9 	ldr	x25, [sp, #656]
    4580:	f9414ffa 	ldr	x26, [sp, #664]
    4584:	52800ba3 	mov	w3, #0x5d                  	// #93
    4588:	aa1403e0 	mov	x0, x20
    458c:	91001fe1 	add	x1, sp, #0x7
    4590:	d2800022 	mov	x2, #0x1                   	// #1
    4594:	39001fe3 	strb	w3, [sp, #7]
    4598:	17fffdd9 	b	3cfc <fwp_write.constprop.0+0x9c>
    459c:	52800b63 	mov	w3, #0x5b                  	// #91
    45a0:	91001ff5 	add	x21, sp, #0x7
    45a4:	aa1503e1 	mov	x1, x21
    45a8:	aa1403e0 	mov	x0, x20
    45ac:	d2800022 	mov	x2, #0x1                   	// #1
    45b0:	d0000016 	adrp	x22, 6000 <fwp_main_thread+0x13fc>
    45b4:	912b22d6 	add	x22, x22, #0xac8
    45b8:	39001fe3 	strb	w3, [sp, #7]
    45bc:	97fff65d 	bl	1f30 <buf_put>
    45c0:	b4000233 	cbz	x19, 4604 <fwp_write.constprop.0+0x9a4>
    45c4:	f9400661 	ldr	x1, [x19, #8]
    45c8:	aa1403e0 	mov	x0, x20
    45cc:	f9401f82 	ldr	x2, [x28, #56]
    45d0:	97fffda4 	bl	3c60 <fwp_write.constprop.0>
    45d4:	f9400a73 	ldr	x19, [x19, #16]
    45d8:	b4000173 	cbz	x19, 4604 <fwp_write.constprop.0+0x9a4>
    45dc:	aa1603e1 	mov	x1, x22
    45e0:	aa1403e0 	mov	x0, x20
    45e4:	d2800042 	mov	x2, #0x2                   	// #2
    45e8:	97fff652 	bl	1f30 <buf_put>
    45ec:	f9400661 	ldr	x1, [x19, #8]
    45f0:	aa1403e0 	mov	x0, x20
    45f4:	f9401f82 	ldr	x2, [x28, #56]
    45f8:	97fffd9a 	bl	3c60 <fwp_write.constprop.0>
    45fc:	f9400a73 	ldr	x19, [x19, #16]
    4600:	b5fffef3 	cbnz	x19, 45dc <fwp_write.constprop.0+0x97c>
    4604:	52800ba3 	mov	w3, #0x5d                  	// #93
    4608:	aa1503e1 	mov	x1, x21
    460c:	aa1403e0 	mov	x0, x20
    4610:	d2800022 	mov	x2, #0x1                   	// #1
    4614:	39001fe3 	strb	w3, [sp, #7]
    4618:	17fffdb9 	b	3cfc <fwp_write.constprop.0+0x9c>
    461c:	52800783 	mov	w3, #0x3c                  	// #60
    4620:	91001ff3 	add	x19, sp, #0x7
    4624:	aa1303e1 	mov	x1, x19
    4628:	d2800022 	mov	x2, #0x1                   	// #1
    462c:	aa1403e0 	mov	x0, x20
    4630:	39001fe3 	strb	w3, [sp, #7]
    4634:	97fff63f 	bl	1f30 <buf_put>
    4638:	f9400795 	ldr	x21, [x28, #8]
    463c:	aa1503e0 	mov	x0, x21
    4640:	97fff33c 	bl	1330 <strlen@plt>
    4644:	aa1503e1 	mov	x1, x21
    4648:	aa0003e2 	mov	x2, x0
    464c:	aa1403e0 	mov	x0, x20
    4650:	97fff638 	bl	1f30 <buf_put>
    4654:	528007c3 	mov	w3, #0x3e                  	// #62
    4658:	aa1303e1 	mov	x1, x19
    465c:	aa1403e0 	mov	x0, x20
    4660:	d2800022 	mov	x2, #0x1                   	// #1
    4664:	39001fe3 	strb	w3, [sp, #7]
    4668:	17fffda5 	b	3cfc <fwp_write.constprop.0+0x9c>
    466c:	f100067f 	cmp	x19, #0x1
    4670:	540017e0 	b.eq	496c <fwp_write.constprop.0+0xd0c>  // b.none
    4674:	b100067f 	cmn	x19, #0x1
    4678:	54001b00 	b.eq	49d8 <fwp_write.constprop.0+0xd78>  // b.none
    467c:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    4680:	9128e021 	add	x1, x1, #0xa38
    4684:	d2800022 	mov	x2, #0x1                   	// #1
    4688:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    468c:	f947f400 	ldr	x0, [x0, #4072]
    4690:	f94127e4 	ldr	x4, [sp, #584]
    4694:	f9400003 	ldr	x3, [x0]
    4698:	eb030084 	subs	x4, x4, x3
    469c:	d2800003 	mov	x3, #0x0                   	// #0
    46a0:	54002a41 	b.ne	4be8 <fwp_write.constprop.0+0xf88>  // b.any
    46a4:	f9413bf5 	ldr	x21, [sp, #624]
    46a8:	aa1403e0 	mov	x0, x20
    46ac:	f9413ff6 	ldr	x22, [sp, #632]
    46b0:	17fffdef 	b	3e6c <fwp_write.constprop.0+0x20c>
    46b4:	52800fa3 	mov	w3, #0x7d                  	// #125
    46b8:	17fffe2c 	b	3f68 <fwp_write.constprop.0+0x308>
    46bc:	f10002ff 	cmp	x23, #0x0
    46c0:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    46c4:	71002c3f 	cmp	w1, #0xb
    46c8:	54ffec80 	b.eq	4458 <fwp_write.constprop.0+0x7f8>  // b.none
    46cc:	aa1303e2 	mov	x2, x19
    46d0:	aa1703e1 	mov	x1, x23
    46d4:	aa1403e0 	mov	x0, x20
    46d8:	97fffd62 	bl	3c60 <fwp_write.constprop.0>
    46dc:	17ffff70 	b	449c <fwp_write.constprop.0+0x83c>
    46e0:	aa1903e1 	mov	x1, x25
    46e4:	aa1403e0 	mov	x0, x20
    46e8:	d2800042 	mov	x2, #0x2                   	// #2
    46ec:	97fff611 	bl	1f30 <buf_put>
    46f0:	17fffeee 	b	42a8 <fwp_write.constprop.0+0x648>
    46f4:	aa1403e0 	mov	x0, x20
    46f8:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    46fc:	d2800042 	mov	x2, #0x2                   	// #2
    4700:	912a8021 	add	x1, x1, #0xaa0
    4704:	97fff60b 	bl	1f30 <buf_put>
    4708:	17fffee8 	b	42a8 <fwp_write.constprop.0+0x648>
    470c:	aa1803e1 	mov	x1, x24
    4710:	aa1403e0 	mov	x0, x20
    4714:	d2800042 	mov	x2, #0x2                   	// #2
    4718:	97fff606 	bl	1f30 <buf_put>
    471c:	17fffee3 	b	42a8 <fwp_write.constprop.0+0x648>
    4720:	f9414bf9 	ldr	x25, [sp, #656]
    4724:	f9414ffa 	ldr	x26, [sp, #664]
    4728:	aa1503e1 	mov	x1, x21
    472c:	aa1403e0 	mov	x0, x20
    4730:	52800443 	mov	w3, #0x22                  	// #34
    4734:	17fffe0f 	b	3f70 <fwp_write.constprop.0+0x310>
    4738:	a9400281 	ldp	x1, x0, [x20]
    473c:	91000800 	add	x0, x0, #0x2
    4740:	8b160000 	add	x0, x0, x22
    4744:	f9000680 	str	x0, [x20, #8]
    4748:	3820683f 	strb	wzr, [x1, x0]
    474c:	f9413bf5 	ldr	x21, [sp, #624]
    4750:	f9413ff6 	ldr	x22, [sp, #632]
    4754:	f94153fb 	ldr	x27, [sp, #672]
    4758:	f94157fc 	ldr	x28, [sp, #680]
    475c:	17fffd6d 	b	3d10 <fwp_write.constprop.0+0xb0>
    4760:	aa1403e0 	mov	x0, x20
    4764:	91001fe1 	add	x1, sp, #0x7
    4768:	52800fa3 	mov	w3, #0x7d                  	// #125
    476c:	d2800022 	mov	x2, #0x1                   	// #1
    4770:	17fffe01 	b	3f74 <fwp_write.constprop.0+0x314>
    4774:	f9400f80 	ldr	x0, [x28, #24]
    4778:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    477c:	aa1b03e0 	mov	x0, x27
    4780:	97fff2ec 	bl	1330 <strlen@plt>
    4784:	aa1b03e1 	mov	x1, x27
    4788:	aa0003e2 	mov	x2, x0
    478c:	aa1403e0 	mov	x0, x20
    4790:	97fff5e8 	bl	1f30 <buf_put>
    4794:	aa1903e1 	mov	x1, x25
    4798:	aa1403e0 	mov	x0, x20
    479c:	d2800062 	mov	x2, #0x3                   	// #3
    47a0:	97fff5e4 	bl	1f30 <buf_put>
    47a4:	17fffde4 	b	3f34 <fwp_write.constprop.0+0x2d4>
    47a8:	aa1a03e1 	mov	x1, x26
    47ac:	aa1403e0 	mov	x0, x20
    47b0:	d2800042 	mov	x2, #0x2                   	// #2
    47b4:	97fff5df 	bl	1f30 <buf_put>
    47b8:	17fffddd 	b	3f2c <fwp_write.constprop.0+0x2cc>
    47bc:	f9400660 	ldr	x0, [x19, #8]
    47c0:	b4fff860 	cbz	x0, 46cc <fwp_write.constprop.0+0xa6c>
    47c4:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    47c8:	912b8021 	add	x1, x1, #0xae0
    47cc:	97fff355 	bl	1520 <strcmp@plt>
    47d0:	7100001f 	cmp	w0, #0x0
    47d4:	1a9f07e0 	cset	w0, ne	// ne = any
    47d8:	17ffff20 	b	4458 <fwp_write.constprop.0+0x7f8>
    47dc:	aa1403e0 	mov	x0, x20
    47e0:	d2800042 	mov	x2, #0x2                   	// #2
    47e4:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    47e8:	912b6021 	add	x1, x1, #0xad8
    47ec:	97fff5d1 	bl	1f30 <buf_put>
    47f0:	91004261 	add	x1, x19, #0x10
    47f4:	aa1403e0 	mov	x0, x20
    47f8:	f9402382 	ldr	x2, [x28, #64]
    47fc:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    4800:	97fffd18 	bl	3c60 <fwp_write.constprop.0>
    4804:	17fffd71 	b	3dc8 <fwp_write.constprop.0+0x168>
    4808:	d2800203 	mov	x3, #0x10                  	// #16
    480c:	d0000004 	adrp	x4, 6000 <fwp_main_thread+0x13fc>
    4810:	aa0303e1 	mov	x1, x3
    4814:	912ac084 	add	x4, x4, #0xab0
    4818:	910123f7 	add	x23, sp, #0x48
    481c:	52800042 	mov	w2, #0x2                   	// #2
    4820:	aa1703e0 	mov	x0, x23
    4824:	97fff2fb 	bl	1410 <__snprintf_chk@plt>
    4828:	aa1703e0 	mov	x0, x23
    482c:	97fff2c1 	bl	1330 <strlen@plt>
    4830:	aa1703e1 	mov	x1, x23
    4834:	aa0003e2 	mov	x2, x0
    4838:	aa1403e0 	mov	x0, x20
    483c:	97fff5bd 	bl	1f30 <buf_put>
    4840:	17fffe9a 	b	42a8 <fwp_write.constprop.0+0x648>
    4844:	7101fcbf 	cmp	w5, #0x7f
    4848:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    484c:	54fffde9 	b.ls	4808 <fwp_write.constprop.0+0xba8>  // b.plast
    4850:	aa1503e1 	mov	x1, x21
    4854:	aa1403e0 	mov	x0, x20
    4858:	d2800022 	mov	x2, #0x1                   	// #1
    485c:	39001fe5 	strb	w5, [sp, #7]
    4860:	97fff5b4 	bl	1f30 <buf_put>
    4864:	17fffe91 	b	42a8 <fwp_write.constprop.0+0x648>
    4868:	1e22c109 	fcvt	d9, s8
    486c:	910123f5 	add	x21, sp, #0x48
    4870:	52800033 	mov	w19, #0x1                   	// #1
    4874:	d503201f 	nop
    4878:	1e604120 	fmov	d0, d9
    487c:	2a1303e1 	mov	w1, w19
    4880:	aa1503e0 	mov	x0, x21
    4884:	97fff63f 	bl	2180 <fwp_format_g.constprop.0>
    4888:	aa1503e0 	mov	x0, x21
    488c:	d2800001 	mov	x1, #0x0                   	// #0
    4890:	97fff330 	bl	1550 <strtof@plt>
    4894:	1e202100 	fcmp	s8, s0
    4898:	54ffd6c0 	b.eq	4370 <fwp_write.constprop.0+0x710>  // b.none
    489c:	11000673 	add	w19, w19, #0x1
    48a0:	71002a7f 	cmp	w19, #0xa
    48a4:	54fffea1 	b.ne	4878 <fwp_write.constprop.0+0xc18>  // b.any
    48a8:	1e604120 	fmov	d0, d9
    48ac:	aa1503e0 	mov	x0, x21
    48b0:	52800121 	mov	w1, #0x9                   	// #9
    48b4:	97fff633 	bl	2180 <fwp_format_g.constprop.0>
    48b8:	17fffeae 	b	4370 <fwp_write.constprop.0+0x710>
    48bc:	d37ef6a1 	lsl	x1, x21, #2
    48c0:	b7f809a3 	tbnz	x3, #63, 49f4 <fwp_write.constprop.0+0xd94>
    48c4:	91002263 	add	x3, x19, #0x8
    48c8:	8b010061 	add	x1, x3, x1
    48cc:	b9400023 	ldr	w3, [x1]
    48d0:	7100081f 	cmp	w0, #0x2
    48d4:	2a0303e1 	mov	w1, w3
    48d8:	93407c63 	sxtw	x3, w3
    48dc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    48e0:	17fffe16 	b	4138 <fwp_write.constprop.0+0x4d8>
    48e4:	d37ffaa1 	lsl	x1, x21, #1
    48e8:	b7f80803 	tbnz	x3, #63, 49e8 <fwp_write.constprop.0+0xd88>
    48ec:	91002263 	add	x3, x19, #0x8
    48f0:	8b010061 	add	x1, x3, x1
    48f4:	79400021 	ldrh	w1, [x1]
    48f8:	7100041f 	cmp	w0, #0x1
    48fc:	93403c23 	sxth	x3, w1
    4900:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4904:	17fffe0d 	b	4138 <fwp_write.constprop.0+0x4d8>
    4908:	7100103f 	cmp	w1, #0x4
    490c:	54ffee01 	b.ne	46cc <fwp_write.constprop.0+0xa6c>  // b.any
    4910:	f94006e0 	ldr	x0, [x23, #8]
    4914:	d37ffc00 	lsr	x0, x0, #63
    4918:	17fffed0 	b	4458 <fwp_write.constprop.0+0x7f8>
    491c:	710002ff 	cmp	w23, #0x0
    4920:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4924:	17fffecd 	b	4458 <fwp_write.constprop.0+0x7f8>
    4928:	528005a1 	mov	w1, #0x2d                  	// #45
    492c:	eb0203e2 	negs	x2, x2
    4930:	da0303e3 	ngc	x3, x3
    4934:	910127e0 	add	x0, sp, #0x49
    4938:	910123f5 	add	x21, sp, #0x48
    493c:	390123e1 	strb	w1, [sp, #72]
    4940:	97fff428 	bl	19e0 <fwp_fmt_u128>
    4944:	17fffe16 	b	419c <fwp_write.constprop.0+0x53c>
    4948:	d37ceea1 	lsl	x1, x21, #4
    494c:	b7f80da3 	tbnz	x3, #63, 4b00 <fwp_write.constprop.0+0xea0>
    4950:	91002260 	add	x0, x19, #0x8
    4954:	8b010001 	add	x1, x0, x1
    4958:	17fffdf8 	b	4138 <fwp_write.constprop.0+0x4d8>
    495c:	f9400a61 	ldr	x1, [x19, #16]
    4960:	8b010000 	add	x0, x0, x1
    4964:	f9400001 	ldr	x1, [x0]
    4968:	17fffdf4 	b	4138 <fwp_write.constprop.0+0x4d8>
    496c:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    4970:	d2800042 	mov	x2, #0x2                   	// #2
    4974:	9128a021 	add	x1, x1, #0xa28
    4978:	17ffff44 	b	4688 <fwp_write.constprop.0+0xa28>
    497c:	1e604100 	fmov	d0, d8
    4980:	aa1503e0 	mov	x0, x21
    4984:	52800221 	mov	w1, #0x11                  	// #17
    4988:	97fff5fe 	bl	2180 <fwp_format_g.constprop.0>
    498c:	17fffe79 	b	4370 <fwp_write.constprop.0+0x710>
    4990:	b9401380 	ldr	w0, [x28, #16]
    4994:	350003c0 	cbnz	w0, 4a0c <fwp_write.constprop.0+0xdac>
    4998:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    499c:	f947f400 	ldr	x0, [x0, #4072]
    49a0:	f94127e2 	ldr	x2, [sp, #584]
    49a4:	f9400001 	ldr	x1, [x0]
    49a8:	eb010042 	subs	x2, x2, x1
    49ac:	d2800001 	mov	x1, #0x0                   	// #0
    49b0:	54001201 	b.ne	4bf0 <fwp_write.constprop.0+0xf90>  // b.any
    49b4:	f9413bf5 	ldr	x21, [sp, #624]
    49b8:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    49bc:	f9413ff6 	ldr	x22, [sp, #632]
    49c0:	aa1403e0 	mov	x0, x20
    49c4:	f94143f7 	ldr	x23, [sp, #640]
    49c8:	912c0021 	add	x1, x1, #0xb00
    49cc:	f94147f8 	ldr	x24, [sp, #648]
    49d0:	d2800042 	mov	x2, #0x2                   	// #2
    49d4:	17fffd26 	b	3e6c <fwp_write.constprop.0+0x20c>
    49d8:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    49dc:	d2800042 	mov	x2, #0x2                   	// #2
    49e0:	9128c021 	add	x1, x1, #0xa30
    49e4:	17ffff29 	b	4688 <fwp_write.constprop.0+0xa28>
    49e8:	f9400a63 	ldr	x3, [x19, #16]
    49ec:	8b030021 	add	x1, x1, x3
    49f0:	17ffffc1 	b	48f4 <fwp_write.constprop.0+0xc94>
    49f4:	f9400a63 	ldr	x3, [x19, #16]
    49f8:	8b030021 	add	x1, x1, x3
    49fc:	17ffffb4 	b	48cc <fwp_write.constprop.0+0xc6c>
    4a00:	f9400a61 	ldr	x1, [x19, #16]
    4a04:	8b0102a1 	add	x1, x21, x1
    4a08:	17fffdc7 	b	4124 <fwp_write.constprop.0+0x4c4>
    4a0c:	b9404b80 	ldr	w0, [x28, #72]
    4a10:	91001ff5 	add	x21, sp, #0x7
    4a14:	34ffa660 	cbz	w0, 3ee0 <fwp_write.constprop.0+0x280>
    4a18:	52800503 	mov	w3, #0x28                  	// #40
    4a1c:	aa1403e0 	mov	x0, x20
    4a20:	aa1503e1 	mov	x1, x21
    4a24:	d2800022 	mov	x2, #0x1                   	// #1
    4a28:	39001fe3 	strb	w3, [sp, #7]
    4a2c:	97fff541 	bl	1f30 <buf_put>
    4a30:	b9401380 	ldr	w0, [x28, #16]
    4a34:	52800038 	mov	w24, #0x1                   	// #1
    4a38:	7100001f 	cmp	w0, #0x0
    4a3c:	54ffa66c 	b.gt	3f08 <fwp_write.constprop.0+0x2a8>
    4a40:	17fffd49 	b	3f64 <fwp_write.constprop.0+0x304>
    4a44:	f9014bf9 	str	x25, [sp, #656]
    4a48:	f00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x17668>
    4a4c:	f9014ffa 	str	x26, [sp, #664]
    4a50:	f9400676 	ldr	x22, [x19, #8]
    4a54:	912ca333 	add	x19, x25, #0xb28
    4a58:	91002273 	add	x19, x19, #0x8
    4a5c:	937ffed8 	asr	x24, x22, #63
    4a60:	aa1802c0 	orr	x0, x22, x24
    4a64:	b5000320 	cbnz	x0, 4ac8 <fwp_write.constprop.0+0xe68>
    4a68:	110006b5 	add	w21, w21, #0x1
    4a6c:	710016bf 	cmp	w21, #0x5
    4a70:	54ffffc1 	b.ne	4a68 <fwp_write.constprop.0+0xe08>  // b.any
    4a74:	b7f80578 	tbnz	x24, #63, 4b20 <fwp_write.constprop.0+0xec0>
    4a78:	910023f3 	add	x19, sp, #0x8
    4a7c:	aa1603e2 	mov	x2, x22
    4a80:	aa1303e0 	mov	x0, x19
    4a84:	d2800003 	mov	x3, #0x0                   	// #0
    4a88:	97fff3d6 	bl	19e0 <fwp_fmt_u128>
    4a8c:	910123f5 	add	x21, sp, #0x48
    4a90:	d0000003 	adrp	x3, 6000 <fwp_main_thread+0x13fc>
    4a94:	aa1303e4 	mov	x4, x19
    4a98:	aa1503e0 	mov	x0, x21
    4a9c:	912be063 	add	x3, x3, #0xaf8
    4aa0:	d2804002 	mov	x2, #0x200                 	// #512
    4aa4:	52800041 	mov	w1, #0x2                   	// #2
    4aa8:	97fff226 	bl	1340 <__sprintf_chk@plt>
    4aac:	aa1503e0 	mov	x0, x21
    4ab0:	97fff220 	bl	1330 <strlen@plt>
    4ab4:	aa1503e1 	mov	x1, x21
    4ab8:	aa0003e2 	mov	x2, x0
    4abc:	aa1403e0 	mov	x0, x20
    4ac0:	97fff51c 	bl	1f30 <buf_put>
    4ac4:	17fffe7b 	b	44b0 <fwp_write.constprop.0+0x850>
    4ac8:	f9400277 	ldr	x23, [x19]
    4acc:	aa1603e0 	mov	x0, x22
    4ad0:	aa1803e1 	mov	x1, x24
    4ad4:	aa1703e2 	mov	x2, x23
    4ad8:	937ffefa 	asr	x26, x23, #63
    4adc:	aa1a03e3 	mov	x3, x26
    4ae0:	94000664 	bl	6470 <__modti3>
    4ae4:	aa010000 	orr	x0, x0, x1
    4ae8:	b40002c0 	cbz	x0, 4b40 <fwp_write.constprop.0+0xee0>
    4aec:	110006b5 	add	w21, w21, #0x1
    4af0:	91004273 	add	x19, x19, #0x10
    4af4:	710016bf 	cmp	w21, #0x5
    4af8:	54fffe81 	b.ne	4ac8 <fwp_write.constprop.0+0xe68>  // b.any
    4afc:	17ffffde 	b	4a74 <fwp_write.constprop.0+0xe14>
    4b00:	f9400a60 	ldr	x0, [x19, #16]
    4b04:	8b000021 	add	x1, x1, x0
    4b08:	17fffd8c 	b	4138 <fwp_write.constprop.0+0x4d8>
    4b0c:	528c29c0 	mov	w0, #0x614e                	// #24910
    4b10:	910123f5 	add	x21, sp, #0x48
    4b14:	72a009c0 	movk	w0, #0x4e, lsl #16
    4b18:	b9004be0 	str	w0, [sp, #72]
    4b1c:	17fffdb9 	b	4200 <fwp_write.constprop.0+0x5a0>
    4b20:	528005a1 	mov	w1, #0x2d                  	// #45
    4b24:	eb1603e2 	negs	x2, x22
    4b28:	da1803e3 	ngc	x3, x24
    4b2c:	910027e0 	add	x0, sp, #0x9
    4b30:	910023f3 	add	x19, sp, #0x8
    4b34:	390023e1 	strb	w1, [sp, #8]
    4b38:	97fff3aa 	bl	19e0 <fwp_fmt_u128>
    4b3c:	17ffffd4 	b	4a8c <fwp_write.constprop.0+0xe2c>
    4b40:	aa1703e2 	mov	x2, x23
    4b44:	aa1a03e3 	mov	x3, x26
    4b48:	aa1603e0 	mov	x0, x22
    4b4c:	aa1803e1 	mov	x1, x24
    4b50:	94000568 	bl	60f0 <__divti3>
    4b54:	aa0003e2 	mov	x2, x0
    4b58:	aa0103e3 	mov	x3, x1
    4b5c:	b7f80201 	tbnz	x1, #63, 4b9c <fwp_write.constprop.0+0xf3c>
    4b60:	910023f3 	add	x19, sp, #0x8
    4b64:	aa1303e0 	mov	x0, x19
    4b68:	97fff39e 	bl	19e0 <fwp_fmt_u128>
    4b6c:	937c7ea1 	sbfiz	x1, x21, #4, #32
    4b70:	912ca339 	add	x25, x25, #0xb28
    4b74:	910123f5 	add	x21, sp, #0x48
    4b78:	aa1303e4 	mov	x4, x19
    4b7c:	aa1503e0 	mov	x0, x21
    4b80:	d0000003 	adrp	x3, 6000 <fwp_main_thread+0x13fc>
    4b84:	f8616b25 	ldr	x5, [x25, x1]
    4b88:	912bc063 	add	x3, x3, #0xaf0
    4b8c:	d2804002 	mov	x2, #0x200                 	// #512
    4b90:	52800041 	mov	w1, #0x2                   	// #2
    4b94:	97fff1eb 	bl	1340 <__sprintf_chk@plt>
    4b98:	17ffffc5 	b	4aac <fwp_write.constprop.0+0xe4c>
    4b9c:	528005a4 	mov	w4, #0x2d                  	// #45
    4ba0:	eb0003e2 	negs	x2, x0
    4ba4:	da0103e3 	ngc	x3, x1
    4ba8:	910027e0 	add	x0, sp, #0x9
    4bac:	910023f3 	add	x19, sp, #0x8
    4bb0:	390023e4 	strb	w4, [sp, #8]
    4bb4:	97fff38b 	bl	19e0 <fwp_fmt_u128>
    4bb8:	17ffffed 	b	4b6c <fwp_write.constprop.0+0xf0c>
    4bbc:	f9013bf5 	str	x21, [sp, #624]
    4bc0:	f9013ff6 	str	x22, [sp, #632]
    4bc4:	f90143f7 	str	x23, [sp, #640]
    4bc8:	f90147f8 	str	x24, [sp, #648]
    4bcc:	f9014bf9 	str	x25, [sp, #656]
    4bd0:	f9014ffa 	str	x26, [sp, #664]
    4bd4:	f90153fb 	str	x27, [sp, #672]
    4bd8:	f90157fc 	str	x28, [sp, #680]
    4bdc:	fd015be8 	str	d8, [sp, #688]
    4be0:	fd015fe9 	str	d9, [sp, #696]
    4be4:	97fff22f 	bl	14a0 <__stack_chk_fail@plt>
    4be8:	f90143f7 	str	x23, [sp, #640]
    4bec:	f90147f8 	str	x24, [sp, #648]
    4bf0:	f9014bf9 	str	x25, [sp, #656]
    4bf4:	f9014ffa 	str	x26, [sp, #664]
    4bf8:	fd015be8 	str	d8, [sp, #688]
    4bfc:	fd015fe9 	str	d9, [sp, #696]
    4c00:	97fff228 	bl	14a0 <__stack_chk_fail@plt>

0000000000004c04 <fwp_main_thread>:
    4c04:	d10603ff 	sub	sp, sp, #0x180
    4c08:	b0000160 	adrp	x0, 31000 <fwp_root_context+0xcd0>
    4c0c:	91144001 	add	x1, x0, #0x510
    4c10:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    4c14:	f947f400 	ldr	x0, [x0, #4072]
    4c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    4c1c:	910443fd 	add	x29, sp, #0x110
    4c20:	b953a421 	ldr	w1, [x1, #5028]
    4c24:	a91253f3 	stp	x19, x20, [sp, #288]
    4c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    4c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    4c30:	a91673fb 	stp	x27, x28, [sp, #352]
    4c34:	f9400002 	ldr	x2, [x0]
    4c38:	f90087e2 	str	x2, [sp, #264]
    4c3c:	d2800002 	mov	x2, #0x0                   	// #0
    4c40:	340023a1 	cbz	w1, 50b4 <fwp_main_thread+0x4b0>
    4c44:	b0000160 	adrp	x0, 31000 <fwp_root_context+0xcd0>
    4c48:	91144000 	add	x0, x0, #0x510
    4c4c:	b953a800 	ldr	w0, [x0, #5032]
    4c50:	350023c0 	cbnz	w0, 50c8 <fwp_main_thread+0x4c4>
    4c54:	900000f7 	adrp	x23, 20000 <__data_start>
    4c58:	900000e2 	adrp	x2, 20000 <__data_start>
    4c5c:	9101c2fb 	add	x27, x23, #0x70
    4c60:	910cc042 	add	x2, x2, #0x330
    4c64:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    4c68:	d2a00024 	mov	x4, #0x10000               	// #65536
    4c6c:	9100c3f4 	add	x20, sp, #0x30
    4c70:	910063f5 	add	x21, sp, #0x18
    4c74:	aa1403e0 	mov	x0, x20
    4c78:	d2800001 	mov	x1, #0x0                   	// #0
    4c7c:	a9010f75 	stp	x21, x3, [x27, #16]
    4c80:	f9001be2 	str	x2, [sp, #48]
    4c84:	b9003bff 	str	wzr, [sp, #56]
    4c88:	f90023e4 	str	x4, [sp, #64]
    4c8c:	97fff1a1 	bl	1310 <sigaltstack@plt>
    4c90:	3500a140 	cbnz	w0, 60b8 <fwp_main_thread+0x14b4>
    4c94:	4f000400 	movi	v0.4s, #0x0
    4c98:	9101e3e0 	add	x0, sp, #0x78
    4c9c:	b0ffffe1 	adrp	x1, 1000 <__abi_tag+0xd88>
    4ca0:	912f4021 	add	x1, x1, #0xbd0
    4ca4:	f9003be1 	str	x1, [sp, #112]
    4ca8:	52800082 	mov	w2, #0x4                   	// #4
    4cac:	72a10002 	movk	w2, #0x800, lsl #16
    4cb0:	9101c3f3 	add	x19, sp, #0x70
    4cb4:	3d802000 	str	q0, [x0, #128]
    4cb8:	b900fbe2 	str	w2, [sp, #248]
    4cbc:	f90003f3 	str	x19, [sp]
    4cc0:	ad000000 	stp	q0, q0, [x0]
    4cc4:	ad010000 	stp	q0, q0, [x0, #32]
    4cc8:	ad020000 	stp	q0, q0, [x0, #64]
    4ccc:	ad030000 	stp	q0, q0, [x0, #96]
    4cd0:	97fff1e4 	bl	1460 <sigemptyset@plt>
    4cd4:	35009f20 	cbnz	w0, 60b8 <fwp_main_thread+0x14b4>
    4cd8:	aa1303e1 	mov	x1, x19
    4cdc:	d2800002 	mov	x2, #0x0                   	// #0
    4ce0:	52800160 	mov	w0, #0xb                   	// #11
    4ce4:	97fff1f7 	bl	14c0 <sigaction@plt>
    4ce8:	35009e80 	cbnz	w0, 60b8 <fwp_main_thread+0x14b4>
    4cec:	aa1303e1 	mov	x1, x19
    4cf0:	d2800002 	mov	x2, #0x0                   	// #0
    4cf4:	528000e0 	mov	w0, #0x7                   	// #7
    4cf8:	97fff1f2 	bl	14c0 <sigaction@plt>
    4cfc:	35009de0 	cbnz	w0, 60b8 <fwp_main_thread+0x14b4>
    4d00:	b9429760 	ldr	w0, [x27, #660]
    4d04:	34001ea0 	cbz	w0, 50d8 <fwp_main_thread+0x4d4>
    4d08:	9101c2f5 	add	x21, x23, #0x70
    4d0c:	f94006b4 	ldr	x20, [x21, #8]
    4d10:	b4000c74 	cbz	x20, 4e9c <fwp_main_thread+0x298>
    4d14:	aa1403f3 	mov	x19, x20
    4d18:	91010296 	add	x22, x20, #0x40
    4d1c:	a9156bf9 	stp	x25, x26, [sp, #336]
    4d20:	52800038 	mov	w24, #0x1                   	// #1
    4d24:	39414a99 	ldrb	w25, [x20, #82]
    4d28:	39014a98 	strb	w24, [x20, #82]
    4d2c:	f9401680 	ldr	x0, [x20, #40]
    4d30:	b4000620 	cbz	x0, 4df4 <fwp_main_thread+0x1f0>
    4d34:	f9403281 	ldr	x1, [x20, #96]
    4d38:	39414680 	ldrb	w0, [x20, #81]
    4d3c:	b40017a1 	cbz	x1, 5030 <fwp_main_thread+0x42c>
    4d40:	36001660 	tbz	w0, #0, 500c <fwp_main_thread+0x408>
    4d44:	39414a62 	ldrb	w2, [x19, #82]
    4d48:	f9402280 	ldr	x0, [x20, #64]
    4d4c:	370019c2 	tbnz	w2, #0, 5084 <fwp_main_thread+0x480>
    4d50:	f9403261 	ldr	x1, [x19, #96]
    4d54:	a911fe76 	stp	x22, xzr, [x19, #280]
    4d58:	f9009660 	str	x0, [x19, #296]
    4d5c:	b4000040 	cbz	x0, 4d64 <fwp_main_thread+0x160>
    4d60:	f9009013 	str	x19, [x0, #288]
    4d64:	f9002293 	str	x19, [x20, #64]
    4d68:	b4000101 	cbz	x1, 4d88 <fwp_main_thread+0x184>
    4d6c:	f9401aa0 	ldr	x0, [x21, #48]
    4d70:	39015678 	strb	w24, [x19, #85]
    4d74:	f9003661 	str	x1, [x19, #104]
    4d78:	a910827f 	stp	xzr, x0, [x19, #264]
    4d7c:	b4000040 	cbz	x0, 4d84 <fwp_main_thread+0x180>
    4d80:	f9008413 	str	x19, [x0, #264]
    4d84:	f9001ab3 	str	x19, [x21, #48]
    4d88:	39015a7f 	strb	wzr, [x19, #86]
    4d8c:	97fffb5e 	bl	3b04 <fwp_block>
    4d90:	f9408e62 	ldr	x2, [x19, #280]
    4d94:	b4000142 	cbz	x2, 4dbc <fwp_main_thread+0x1b8>
    4d98:	a9520261 	ldp	x1, x0, [x19, #288]
    4d9c:	b4001801 	cbz	x1, 509c <fwp_main_thread+0x498>
    4da0:	f9009420 	str	x0, [x1, #296]
    4da4:	f9409660 	ldr	x0, [x19, #296]
    4da8:	b4000040 	cbz	x0, 4db0 <fwp_main_thread+0x1ac>
    4dac:	f9009001 	str	x1, [x0, #288]
    4db0:	91080260 	add	x0, x19, #0x200
    4db4:	f900967f 	str	xzr, [x19, #296]
    4db8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    4dbc:	39415660 	ldrb	w0, [x19, #85]
    4dc0:	f94006a2 	ldr	x2, [x21, #8]
    4dc4:	360015c0 	tbz	w0, #0, 507c <fwp_main_thread+0x478>
    4dc8:	a9508261 	ldp	x1, x0, [x19, #264]
    4dcc:	b40016c1 	cbz	x1, 50a4 <fwp_main_thread+0x4a0>
    4dd0:	f9008820 	str	x0, [x1, #272]
    4dd4:	b4000040 	cbz	x0, 4ddc <fwp_main_thread+0x1d8>
    4dd8:	f9008401 	str	x1, [x0, #264]
    4ddc:	91080260 	add	x0, x19, #0x200
    4de0:	3901567f 	strb	wzr, [x19, #85]
    4de4:	aa0203f3 	mov	x19, x2
    4de8:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    4dec:	f9401680 	ldr	x0, [x20, #40]
    4df0:	b5fffa20 	cbnz	x0, 4d34 <fwp_main_thread+0x130>
    4df4:	9101c2e0 	add	x0, x23, #0x70
    4df8:	39014a99 	strb	w25, [x20, #82]
    4dfc:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4e00:	f9413c00 	ldr	x0, [x0, #632]
    4e04:	b5000080 	cbnz	x0, 4e14 <fwp_main_thread+0x210>
    4e08:	9101c2f4 	add	x20, x23, #0x70
    4e0c:	f9414680 	ldr	x0, [x20, #648]
    4e10:	b4008740 	cbz	x0, 5ef8 <fwp_main_thread+0x12f4>
    4e14:	9101c2e0 	add	x0, x23, #0x70
    4e18:	f9415401 	ldr	x1, [x0, #680]
    4e1c:	b902a01f 	str	wzr, [x0, #672]
    4e20:	eb13003f 	cmp	x1, x19
    4e24:	54008801 	b.ne	5f24 <fwp_main_thread+0x1320>  // b.any
    4e28:	b4000453 	cbz	x19, 4eb0 <fwp_main_thread+0x2ac>
    4e2c:	9101c2e0 	add	x0, x23, #0x70
    4e30:	52800021 	mov	w1, #0x1                   	// #1
    4e34:	39014a61 	strb	w1, [x19, #82]
    4e38:	f9412805 	ldr	x5, [x0, #592]
    4e3c:	b40003a5 	cbz	x5, 4eb0 <fwp_main_thread+0x2ac>
    4e40:	394140a0 	ldrb	w0, [x5, #80]
    4e44:	37000060 	tbnz	w0, #0, 4e50 <fwp_main_thread+0x24c>
    4e48:	aa0503e0 	mov	x0, x5
    4e4c:	97fff451 	bl	1f90 <fwp_cancel_tree.part.0>
    4e50:	f9409ca5 	ldr	x5, [x5, #312]
    4e54:	b5ffff65 	cbnz	x5, 4e40 <fwp_main_thread+0x23c>
    4e58:	9101c2f4 	add	x20, x23, #0x70
    4e5c:	52800035 	mov	w21, #0x1                   	// #1
    4e60:	f9402a60 	ldr	x0, [x19, #80]
    4e64:	f2001c1f 	tst	x0, #0xff000000ff
    4e68:	540000e1 	b.ne	4e84 <fwp_main_thread+0x280>  // b.any
    4e6c:	f9401280 	ldr	x0, [x20, #32]
    4e70:	39015275 	strb	w21, [x19, #84]
    4e74:	f900827f 	str	xzr, [x19, #256]
    4e78:	b40011a0 	cbz	x0, 50ac <fwp_main_thread+0x4a8>
    4e7c:	f9008013 	str	x19, [x0, #256]
    4e80:	f9001293 	str	x19, [x20, #32]
    4e84:	97fffb20 	bl	3b04 <fwp_block>
    4e88:	97fffab2 	bl	3950 <fwp_free_zombie>
    4e8c:	f9412a80 	ldr	x0, [x20, #592]
    4e90:	b4000100 	cbz	x0, 4eb0 <fwp_main_thread+0x2ac>
    4e94:	f9415693 	ldr	x19, [x20, #680]
    4e98:	17fffff2 	b	4e60 <fwp_main_thread+0x25c>
    4e9c:	f9413ea0 	ldr	x0, [x21, #632]
    4ea0:	b4007dc0 	cbz	x0, 5e58 <fwp_main_thread+0x1254>
    4ea4:	f94156a0 	ldr	x0, [x21, #680]
    4ea8:	b902a2bf 	str	wzr, [x21, #672]
    4eac:	b50083c0 	cbnz	x0, 5f24 <fwp_main_thread+0x1320>
    4eb0:	9101c2f4 	add	x20, x23, #0x70
    4eb4:	97fffaa7 	bl	3950 <fwp_free_zombie>
    4eb8:	f9401680 	ldr	x0, [x20, #40]
    4ebc:	b5008340 	cbnz	x0, 5f24 <fwp_main_thread+0x1320>
    4ec0:	f9401a80 	ldr	x0, [x20, #48]
    4ec4:	b5008300 	cbnz	x0, 5f24 <fwp_main_thread+0x1320>
    4ec8:	b9404280 	ldr	w0, [x20, #64]
    4ecc:	340001c0 	cbz	w0, 4f04 <fwp_main_thread+0x300>
    4ed0:	93407c15 	sxtw	x21, w0
    4ed4:	51000400 	sub	w0, w0, #0x1
    4ed8:	d1000ab5 	sub	x21, x21, #0x2
    4edc:	91014296 	add	x22, x20, #0x50
    4ee0:	cb2042b5 	sub	x21, x21, w0, uxtw
    4ee4:	93407c13 	sxtw	x19, w0
    4ee8:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    4eec:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    4ef0:	b9004293 	str	w19, [x20, #64]
    4ef4:	d1000673 	sub	x19, x19, #0x1
    4ef8:	97fff1b2 	bl	15c0 <munmap@plt>
    4efc:	eb15027f 	cmp	x19, x21
    4f00:	54ffff41 	b.ne	4ee8 <fwp_main_thread+0x2e4>  // b.any
    4f04:	900000f3 	adrp	x19, 20000 <__data_start>
    4f08:	91004260 	add	x0, x19, #0x10
    4f0c:	b9404000 	ldr	w0, [x0, #64]
    4f10:	37f80040 	tbnz	w0, #31, 4f18 <fwp_main_thread+0x314>
    4f14:	97fff167 	bl	14b0 <close@plt>
    4f18:	9101c2e0 	add	x0, x23, #0x70
    4f1c:	91004261 	add	x1, x19, #0x10
    4f20:	12800002 	mov	w2, #0xffffffff            	// #-1
    4f24:	d2800013 	mov	x19, #0x0                   	// #0
    4f28:	f9415815 	ldr	x21, [x0, #688]
    4f2c:	b9004022 	str	w2, [x1, #64]
    4f30:	f9415c14 	ldr	x20, [x0, #696]
    4f34:	b4000175 	cbz	x21, 4f60 <fwp_main_thread+0x35c>
    4f38:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    4f3c:	b40000c0 	cbz	x0, 4f54 <fwp_main_thread+0x350>
    4f40:	f9400001 	ldr	x1, [x0]
    4f44:	b5007f01 	cbnz	x1, 5f24 <fwp_main_thread+0x1320>
    4f48:	f9400401 	ldr	x1, [x0, #8]
    4f4c:	b5007ec1 	cbnz	x1, 5f24 <fwp_main_thread+0x1320>
    4f50:	97fff7b4 	bl	2e20 <fwp_mem_free>
    4f54:	91000673 	add	x19, x19, #0x1
    4f58:	eb1302bf 	cmp	x21, x19
    4f5c:	54fffee1 	b.ne	4f38 <fwp_main_thread+0x334>  // b.any
    4f60:	aa1403e0 	mov	x0, x20
    4f64:	97fff7af 	bl	2e20 <fwp_mem_free>
    4f68:	9101c2e0 	add	x0, x23, #0x70
    4f6c:	f9415413 	ldr	x19, [x0, #680]
    4f70:	f901581f 	str	xzr, [x0, #688]
    4f74:	f9015c1f 	str	xzr, [x0, #696]
    4f78:	b40001f3 	cbz	x19, 4fb4 <fwp_main_thread+0x3b0>
    4f7c:	f9401661 	ldr	x1, [x19, #40]
    4f80:	b5007d21 	cbnz	x1, 5f24 <fwp_main_thread+0x1320>
    4f84:	f9405661 	ldr	x1, [x19, #168]
    4f88:	b5007ce1 	cbnz	x1, 5f24 <fwp_main_thread+0x1320>
    4f8c:	f9413c01 	ldr	x1, [x0, #632]
    4f90:	b5007ca1 	cbnz	x1, 5f24 <fwp_main_thread+0x1320>
    4f94:	f9414400 	ldr	x0, [x0, #648]
    4f98:	b5007c60 	cbnz	x0, 5f24 <fwp_main_thread+0x1320>
    4f9c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    4fa0:	90000160 	adrp	x0, 30000 <alt.4+0xfcd0>
    4fa4:	910cc000 	add	x0, x0, #0x330
    4fa8:	97fff132 	bl	1470 <memset@plt>
    4fac:	aa1303e0 	mov	x0, x19
    4fb0:	97fff79c 	bl	2e20 <fwp_mem_free>
    4fb4:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    4fb8:	f947ec00 	ldr	x0, [x0, #4056]
    4fbc:	9101c2f7 	add	x23, x23, #0x70
    4fc0:	f9400000 	ldr	x0, [x0]
    4fc4:	f90006ff 	str	xzr, [x23, #8]
    4fc8:	f90156ff 	str	xzr, [x23, #680]
    4fcc:	97fff181 	bl	15d0 <fflush@plt>
    4fd0:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x17668>
    4fd4:	f947f400 	ldr	x0, [x0, #4072]
    4fd8:	f94087e2 	ldr	x2, [sp, #264]
    4fdc:	f9400001 	ldr	x1, [x0]
    4fe0:	eb010042 	subs	x2, x2, x1
    4fe4:	d2800001 	mov	x1, #0x0                   	// #0
    4fe8:	54008621 	b.ne	60ac <fwp_main_thread+0x14a8>  // b.any
    4fec:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4ff0:	d2800000 	mov	x0, #0x0                   	// #0
    4ff4:	a95253f3 	ldp	x19, x20, [sp, #288]
    4ff8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4ffc:	a95463f7 	ldp	x23, x24, [sp, #320]
    5000:	a95673fb 	ldp	x27, x28, [sp, #352]
    5004:	910603ff 	add	sp, sp, #0x180
    5008:	d65f03c0 	ret
    500c:	97fff435 	bl	20e0 <fwp_now_ns>
    5010:	f9403281 	ldr	x1, [x20, #96]
    5014:	eb01001f 	cmp	x0, x1
    5018:	540000ab 	b.lt	502c <fwp_main_thread+0x428>  // b.tstop
    501c:	39414280 	ldrb	w0, [x20, #80]
    5020:	37000060 	tbnz	w0, #0, 502c <fwp_main_thread+0x428>
    5024:	aa1403e0 	mov	x0, x20
    5028:	97fff3da 	bl	1f90 <fwp_cancel_tree.part.0>
    502c:	39414680 	ldrb	w0, [x20, #81]
    5030:	39414a62 	ldrb	w2, [x19, #82]
    5034:	3707e8a0 	tbnz	w0, #0, 4d48 <fwp_main_thread+0x144>
    5038:	f9403281 	ldr	x1, [x20, #96]
    503c:	370001c2 	tbnz	w2, #0, 5074 <fwp_main_thread+0x470>
    5040:	f9403260 	ldr	x0, [x19, #96]
    5044:	b4000180 	cbz	x0, 5074 <fwp_main_thread+0x470>
    5048:	b4000061 	cbz	x1, 5054 <fwp_main_thread+0x450>
    504c:	eb01001f 	cmp	x0, x1
    5050:	9a81d000 	csel	x0, x0, x1, le
    5054:	f9402281 	ldr	x1, [x20, #64]
    5058:	a911fe76 	stp	x22, xzr, [x19, #280]
    505c:	f9009661 	str	x1, [x19, #296]
    5060:	b4007181 	cbz	x1, 5e90 <fwp_main_thread+0x128c>
    5064:	f9009033 	str	x19, [x1, #288]
    5068:	aa0003e1 	mov	x1, x0
    506c:	f9002293 	str	x19, [x20, #64]
    5070:	17ffff3f 	b	4d6c <fwp_main_thread+0x168>
    5074:	f9402280 	ldr	x0, [x20, #64]
    5078:	17ffff37 	b	4d54 <fwp_main_thread+0x150>
    507c:	aa0203f3 	mov	x19, x2
    5080:	17ffff2b 	b	4d2c <fwp_main_thread+0x128>
    5084:	a911fe76 	stp	x22, xzr, [x19, #280]
    5088:	f9009660 	str	x0, [x19, #296]
    508c:	b4000040 	cbz	x0, 5094 <fwp_main_thread+0x490>
    5090:	f9009013 	str	x19, [x0, #288]
    5094:	f9002293 	str	x19, [x20, #64]
    5098:	17ffff3c 	b	4d88 <fwp_main_thread+0x184>
    509c:	f9000040 	str	x0, [x2]
    50a0:	17ffff42 	b	4da8 <fwp_main_thread+0x1a4>
    50a4:	f9001aa0 	str	x0, [x21, #48]
    50a8:	17ffff4b 	b	4dd4 <fwp_main_thread+0x1d0>
    50ac:	f9001693 	str	x19, [x20, #40]
    50b0:	17ffff74 	b	4e80 <fwp_main_thread+0x27c>
    50b4:	97fff58f 	bl	26f0 <fwp_heap_init>
    50b8:	90000160 	adrp	x0, 31000 <fwp_root_context+0xcd0>
    50bc:	91144000 	add	x0, x0, #0x510
    50c0:	b953a800 	ldr	w0, [x0, #5032]
    50c4:	34ffdc80 	cbz	w0, 4c54 <fwp_main_thread+0x50>
    50c8:	b0ffffe0 	adrp	x0, 2000 <fwp_cancel_tree.part.0+0x70>
    50cc:	91161000 	add	x0, x0, #0x584
    50d0:	940005c4 	bl	67e0 <atexit>
    50d4:	17fffee0 	b	4c54 <fwp_main_thread+0x50>
    50d8:	f9413362 	ldr	x2, [x27, #608]
    50dc:	90000160 	adrp	x0, 31000 <fwp_root_context+0xcd0>
    50e0:	a9156bf9 	stp	x25, x26, [sp, #336]
    50e4:	91144013 	add	x19, x0, #0x510
    50e8:	90ffffe1 	adrp	x1, 1000 <__abi_tag+0xd88>
    50ec:	6d1727e8 	stp	d8, d9, [sp, #368]
    50f0:	912c4021 	add	x1, x1, #0xb10
    50f4:	d0ffffe0 	adrp	x0, 3000 <fwp_mem_free+0x1e0>
    50f8:	d2800016 	mov	x22, #0x0                   	// #0
    50fc:	9116c000 	add	x0, x0, #0x5b0
    5100:	d280401a 	mov	x26, #0x200                 	// #512
    5104:	d2800018 	mov	x24, #0x0                   	// #0
    5108:	a90187e2 	stp	x2, x1, [sp, #24]
    510c:	a902fff4 	stp	x20, xzr, [sp, #40]
    5110:	a90403ff 	stp	xzr, x0, [sp, #64]
    5114:	f9013375 	str	x21, [x27, #608]
    5118:	14000012 	b	5160 <fwp_main_thread+0x55c>
    511c:	7100045f 	cmp	w2, #0x1
    5120:	540001a1 	b.ne	5154 <fwp_main_thread+0x550>  // b.any
    5124:	29430002 	ldp	w2, w0, [x0, #24]
    5128:	92403c21 	and	x1, x1, #0xffff
    512c:	9b027c21 	mul	x1, x1, x2
    5130:	d360fc21 	lsr	x1, x1, #32
    5134:	eb00003f 	cmp	x1, x0
    5138:	540000e2 	b.cs	5154 <fwp_main_thread+0x550>  // b.hs, b.nlast
    513c:	8b01039c 	add	x28, x28, x1
    5140:	39400380 	ldrb	w0, [x28]
    5144:	7103fc1f 	cmp	w0, #0xff
    5148:	540069e0 	b.eq	5e84 <fwp_main_thread+0x1280>  // b.none
    514c:	52800020 	mov	w0, #0x1                   	// #1
    5150:	39000380 	strb	w0, [x28]
    5154:	f9001bf6 	str	x22, [sp, #48]
    5158:	aa19037b 	orr	x27, x27, x25
    515c:	b40003db 	cbz	x27, 51d4 <fwp_main_thread+0x5d0>
    5160:	f94003e0 	ldr	x0, [sp]
    5164:	f100075b 	subs	x27, x26, #0x1
    5168:	da1f0319 	sbc	x25, x24, xzr
    516c:	f9001ffb 	str	x27, [sp, #56]
    5170:	a9075bfb 	stp	x27, x22, [sp, #112]
    5174:	aa1b03fa 	mov	x26, x27
    5178:	97fff8b2 	bl	3440 <fwp_data.part.0.constprop.0>
    517c:	f949da61 	ldr	x1, [x19, #5040]
    5180:	aa0003f6 	mov	x22, x0
    5184:	f949ee60 	ldr	x0, [x19, #5080]
    5188:	cb0102c1 	sub	x1, x22, x1
    518c:	aa1903f8 	mov	x24, x25
    5190:	eb00403f 	cmp	x1, x0, lsl #16
    5194:	54fffe02 	b.cs	5154 <fwp_main_thread+0x550>  // b.hs, b.nlast
    5198:	d350fc20 	lsr	x0, x1, #16
    519c:	f949fe65 	ldr	x5, [x19, #5112]
    51a0:	8b000800 	add	x0, x0, x0, lsl #2
    51a4:	d37df002 	lsl	x2, x0, #3
    51a8:	8b0200a0 	add	x0, x5, x2
    51ac:	f940101c 	ldr	x28, [x0, #32]
    51b0:	b4fffd3c 	cbz	x28, 5154 <fwp_main_thread+0x550>
    51b4:	386268a2 	ldrb	w2, [x5, x2]
    51b8:	7100085f 	cmp	w2, #0x2
    51bc:	54fffb01 	b.ne	511c <fwp_main_thread+0x518>  // b.any
    51c0:	72003c3f 	tst	w1, #0xffff
    51c4:	54fffbe0 	b.eq	5140 <fwp_main_thread+0x53c>  // b.none
    51c8:	f9001bf6 	str	x22, [sp, #48]
    51cc:	aa19037b 	orr	x27, x27, x25
    51d0:	b5fffc9b 	cbnz	x27, 5160 <fwp_main_thread+0x55c>
    51d4:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    51d8:	9101c2e1 	add	x1, x23, #0x70
    51dc:	f9400fe2 	ldr	x2, [sp, #24]
    51e0:	3dc35000 	ldr	q0, [x0, #3392]
    51e4:	910143e0 	add	x0, sp, #0x50
    51e8:	f9013022 	str	x2, [x1, #608]
    51ec:	3d8017e0 	str	q0, [sp, #80]
    51f0:	97fff894 	bl	3440 <fwp_data.part.0.constprop.0>
    51f4:	90000161 	adrp	x1, 31000 <fwp_root_context+0xcd0>
    51f8:	91144023 	add	x3, x1, #0x510
    51fc:	aa0003f8 	mov	x24, x0
    5200:	f949d861 	ldr	x1, [x3, #5040]
    5204:	f949ec60 	ldr	x0, [x3, #5080]
    5208:	cb010301 	sub	x1, x24, x1
    520c:	eb00403f 	cmp	x1, x0, lsl #16
    5210:	54000322 	b.cs	5274 <fwp_main_thread+0x670>  // b.hs, b.nlast
    5214:	d350fc22 	lsr	x2, x1, #16
    5218:	f949fc63 	ldr	x3, [x3, #5112]
    521c:	8b020842 	add	x2, x2, x2, lsl #2
    5220:	d37df042 	lsl	x2, x2, #3
    5224:	8b020060 	add	x0, x3, x2
    5228:	f940101a 	ldr	x26, [x0, #32]
    522c:	b400025a 	cbz	x26, 5274 <fwp_main_thread+0x670>
    5230:	38626862 	ldrb	w2, [x3, x2]
    5234:	7100085f 	cmp	w2, #0x2
    5238:	540061a0 	b.eq	5e6c <fwp_main_thread+0x1268>  // b.none
    523c:	7100045f 	cmp	w2, #0x1
    5240:	540001a1 	b.ne	5274 <fwp_main_thread+0x670>  // b.any
    5244:	29430002 	ldp	w2, w0, [x0, #24]
    5248:	92403c21 	and	x1, x1, #0xffff
    524c:	9b027c21 	mul	x1, x1, x2
    5250:	d360fc21 	lsr	x1, x1, #32
    5254:	eb00003f 	cmp	x1, x0
    5258:	540000e2 	b.cs	5274 <fwp_main_thread+0x670>  // b.hs, b.nlast
    525c:	8b01035a 	add	x26, x26, x1
    5260:	39400340 	ldrb	w0, [x26]
    5264:	7103fc1f 	cmp	w0, #0xff
    5268:	54006de0 	b.eq	6024 <fwp_main_thread+0x1420>  // b.none
    526c:	52800020 	mov	w0, #0x1                   	// #1
    5270:	39000340 	strb	w0, [x26]
    5274:	f94003e0 	ldr	x0, [sp]
    5278:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    527c:	a90763e1 	stp	x1, x24, [sp, #112]
    5280:	97fff870 	bl	3440 <fwp_data.part.0.constprop.0>
    5284:	aa0003f3 	mov	x19, x0
    5288:	90000161 	adrp	x1, 31000 <fwp_root_context+0xcd0>
    528c:	91144023 	add	x3, x1, #0x510
    5290:	f949d861 	ldr	x1, [x3, #5040]
    5294:	f949ec60 	ldr	x0, [x3, #5080]
    5298:	cb010261 	sub	x1, x19, x1
    529c:	eb00403f 	cmp	x1, x0, lsl #16
    52a0:	54000322 	b.cs	5304 <fwp_main_thread+0x700>  // b.hs, b.nlast
    52a4:	d350fc22 	lsr	x2, x1, #16
    52a8:	f949fc63 	ldr	x3, [x3, #5112]
    52ac:	8b020842 	add	x2, x2, x2, lsl #2
    52b0:	d37df042 	lsl	x2, x2, #3
    52b4:	8b020060 	add	x0, x3, x2
    52b8:	f9401018 	ldr	x24, [x0, #32]
    52bc:	b4000258 	cbz	x24, 5304 <fwp_main_thread+0x700>
    52c0:	38626862 	ldrb	w2, [x3, x2]
    52c4:	7100085f 	cmp	w2, #0x2
    52c8:	54005cc0 	b.eq	5e60 <fwp_main_thread+0x125c>  // b.none
    52cc:	7100045f 	cmp	w2, #0x1
    52d0:	540001a1 	b.ne	5304 <fwp_main_thread+0x700>  // b.any
    52d4:	29430002 	ldp	w2, w0, [x0, #24]
    52d8:	92403c21 	and	x1, x1, #0xffff
    52dc:	9b027c21 	mul	x1, x1, x2
    52e0:	d360fc21 	lsr	x1, x1, #32
    52e4:	eb00003f 	cmp	x1, x0
    52e8:	540000e2 	b.cs	5304 <fwp_main_thread+0x700>  // b.hs, b.nlast
    52ec:	8b010318 	add	x24, x24, x1
    52f0:	39400300 	ldrb	w0, [x24]
    52f4:	7103fc1f 	cmp	w0, #0xff
    52f8:	540069c0 	b.eq	6030 <fwp_main_thread+0x142c>  // b.none
    52fc:	52800020 	mov	w0, #0x1                   	// #1
    5300:	39000300 	strb	w0, [x24]
    5304:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    5308:	910183e0 	add	x0, sp, #0x60
    530c:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    5310:	a9064fe1 	stp	x1, x19, [sp, #96]
    5314:	97fff84b 	bl	3440 <fwp_data.part.0.constprop.0>
    5318:	aa0003e3 	mov	x3, x0
    531c:	90000161 	adrp	x1, 31000 <fwp_root_context+0xcd0>
    5320:	91144022 	add	x2, x1, #0x510
    5324:	f90003e3 	str	x3, [sp]
    5328:	f949d841 	ldr	x1, [x2, #5040]
    532c:	f949ec40 	ldr	x0, [x2, #5080]
    5330:	cb010061 	sub	x1, x3, x1
    5334:	eb00403f 	cmp	x1, x0, lsl #16
    5338:	54000322 	b.cs	539c <fwp_main_thread+0x798>  // b.hs, b.nlast
    533c:	d350fc20 	lsr	x0, x1, #16
    5340:	f949fc43 	ldr	x3, [x2, #5112]
    5344:	8b000800 	add	x0, x0, x0, lsl #2
    5348:	d37df002 	lsl	x2, x0, #3
    534c:	8b020060 	add	x0, x3, x2
    5350:	f9401013 	ldr	x19, [x0, #32]
    5354:	b4000253 	cbz	x19, 539c <fwp_main_thread+0x798>
    5358:	38626862 	ldrb	w2, [x3, x2]
    535c:	7100085f 	cmp	w2, #0x2
    5360:	540058c0 	b.eq	5e78 <fwp_main_thread+0x1274>  // b.none
    5364:	7100045f 	cmp	w2, #0x1
    5368:	540001a1 	b.ne	539c <fwp_main_thread+0x798>  // b.any
    536c:	29430002 	ldp	w2, w0, [x0, #24]
    5370:	92403c21 	and	x1, x1, #0xffff
    5374:	9b027c21 	mul	x1, x1, x2
    5378:	d360fc21 	lsr	x1, x1, #32
    537c:	eb00003f 	cmp	x1, x0
    5380:	540000e2 	b.cs	539c <fwp_main_thread+0x798>  // b.hs, b.nlast
    5384:	8b010273 	add	x19, x19, x1
    5388:	39400260 	ldrb	w0, [x19]
    538c:	7103fc1f 	cmp	w0, #0xff
    5390:	54006560 	b.eq	603c <fwp_main_thread+0x1438>  // b.none
    5394:	52800020 	mov	w0, #0x1                   	// #1
    5398:	39000260 	strb	w0, [x19]
    539c:	f90007f6 	str	x22, [sp, #8]
    53a0:	b4003bd6 	cbz	x22, 5b18 <fwp_main_thread+0xf14>
    53a4:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    53a8:	9e670008 	fmov	d8, x0
    53ac:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    53b0:	90000161 	adrp	x1, 31000 <fwp_root_context+0xcd0>
    53b4:	9114403a 	add	x26, x1, #0x510
    53b8:	fd46a809 	ldr	d9, [x0, #3408]
    53bc:	f94003e2 	ldr	x2, [sp]
    53c0:	f949db40 	ldr	x0, [x26, #5040]
    53c4:	f949ef41 	ldr	x1, [x26, #5080]
    53c8:	cb000040 	sub	x0, x2, x0
    53cc:	eb01401f 	cmp	x0, x1, lsl #16
    53d0:	54000342 	b.cs	5438 <fwp_main_thread+0x834>  // b.hs, b.nlast
    53d4:	d350fc01 	lsr	x1, x0, #16
    53d8:	f949ff43 	ldr	x3, [x26, #5112]
    53dc:	8b010821 	add	x1, x1, x1, lsl #2
    53e0:	d37df021 	lsl	x1, x1, #3
    53e4:	8b010062 	add	x2, x3, x1
    53e8:	f9401053 	ldr	x19, [x2, #32]
    53ec:	b4000273 	cbz	x19, 5438 <fwp_main_thread+0x834>
    53f0:	38616861 	ldrb	w1, [x3, x1]
    53f4:	7100083f 	cmp	w1, #0x2
    53f8:	54004b80 	b.eq	5d68 <fwp_main_thread+0x1164>  // b.none
    53fc:	7100043f 	cmp	w1, #0x1
    5400:	540001c1 	b.ne	5438 <fwp_main_thread+0x834>  // b.any
    5404:	29430443 	ldp	w3, w1, [x2, #24]
    5408:	92403c00 	and	x0, x0, #0xffff
    540c:	9b037c00 	mul	x0, x0, x3
    5410:	d360fc00 	lsr	x0, x0, #32
    5414:	eb01001f 	cmp	x0, x1
    5418:	54000102 	b.cs	5438 <fwp_main_thread+0x834>  // b.hs, b.nlast
    541c:	8b000273 	add	x19, x19, x0
    5420:	39400260 	ldrb	w0, [x19]
    5424:	340000a0 	cbz	w0, 5438 <fwp_main_thread+0x834>
    5428:	7103f41f 	cmp	w0, #0xfd
    542c:	54005828 	b.hi	5f30 <fwp_main_thread+0x132c>  // b.pmore
    5430:	11000400 	add	w0, w0, #0x1
    5434:	39000260 	strb	w0, [x19]
    5438:	f94003e0 	ldr	x0, [sp]
    543c:	b40049e0 	cbz	x0, 5d78 <fwp_main_thread+0x1174>
    5440:	aa0003e1 	mov	x1, x0
    5444:	d2800000 	mov	x0, #0x0                   	// #0
    5448:	f9400821 	ldr	x1, [x1, #16]
    544c:	91000400 	add	x0, x0, #0x1
    5450:	b5ffffc1 	cbnz	x1, 5448 <fwp_main_thread+0x844>
    5454:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    5458:	eb01001f 	cmp	x0, x1
    545c:	54006148 	b.hi	6084 <fwp_main_thread+0x1480>  // b.pmore
    5460:	97fff841 	bl	3564 <fwp_array_new_packed.constprop.0>
    5464:	aa0003f3 	mov	x19, x0
    5468:	f949db41 	ldr	x1, [x26, #5040]
    546c:	f949ef40 	ldr	x0, [x26, #5080]
    5470:	cb010261 	sub	x1, x19, x1
    5474:	eb00403f 	cmp	x1, x0, lsl #16
    5478:	54000362 	b.cs	54e4 <fwp_main_thread+0x8e0>  // b.hs, b.nlast
    547c:	d350fc20 	lsr	x0, x1, #16
    5480:	f949ff43 	ldr	x3, [x26, #5112]
    5484:	8b000800 	add	x0, x0, x0, lsl #2
    5488:	d37df002 	lsl	x2, x0, #3
    548c:	8b020060 	add	x0, x3, x2
    5490:	f940101b 	ldr	x27, [x0, #32]
    5494:	b400025b 	cbz	x27, 54dc <fwp_main_thread+0x8d8>
    5498:	38626862 	ldrb	w2, [x3, x2]
    549c:	7100085f 	cmp	w2, #0x2
    54a0:	54004860 	b.eq	5dac <fwp_main_thread+0x11a8>  // b.none
    54a4:	7100045f 	cmp	w2, #0x1
    54a8:	540001a1 	b.ne	54dc <fwp_main_thread+0x8d8>  // b.any
    54ac:	29430002 	ldp	w2, w0, [x0, #24]
    54b0:	92403c21 	and	x1, x1, #0xffff
    54b4:	9b027c21 	mul	x1, x1, x2
    54b8:	d360fc21 	lsr	x1, x1, #32
    54bc:	eb00003f 	cmp	x1, x0
    54c0:	540000e2 	b.cs	54dc <fwp_main_thread+0x8d8>  // b.hs, b.nlast
    54c4:	8b01037b 	add	x27, x27, x1
    54c8:	39400360 	ldrb	w0, [x27]
    54cc:	7103fc1f 	cmp	w0, #0xff
    54d0:	54004780 	b.eq	5dc0 <fwp_main_thread+0x11bc>  // b.none
    54d4:	52800020 	mov	w0, #0x1                   	// #1
    54d8:	39000360 	strb	w0, [x27]
    54dc:	f94003e0 	ldr	x0, [sp]
    54e0:	b4004620 	cbz	x0, 5da4 <fwp_main_thread+0x11a0>
    54e4:	f94003fb 	ldr	x27, [sp]
    54e8:	9100227c 	add	x28, x19, #0x8
    54ec:	52800038 	mov	w24, #0x1                   	// #1
    54f0:	aa1b03e0 	mov	x0, x27
    54f4:	14000013 	b	5540 <fwp_main_thread+0x93c>
    54f8:	7100045f 	cmp	w2, #0x1
    54fc:	54000161 	b.ne	5528 <fwp_main_thread+0x924>  // b.any
    5500:	2943092a 	ldp	w10, w2, [x9, #24]
    5504:	92403c21 	and	x1, x1, #0xffff
    5508:	9b0a7c21 	mul	x1, x1, x10
    550c:	d360fc21 	lsr	x1, x1, #32
    5510:	eb02003f 	cmp	x1, x2
    5514:	540000a2 	b.cs	5528 <fwp_main_thread+0x924>  // b.hs, b.nlast
    5518:	8b0100c6 	add	x6, x6, x1
    551c:	394000c1 	ldrb	w1, [x6]
    5520:	7100043f 	cmp	w1, #0x1
    5524:	540003e0 	b.eq	55a0 <fwp_main_thread+0x99c>  // b.none
    5528:	f9400261 	ldr	x1, [x19]
    552c:	b7f85661 	tbnz	x1, #63, 5ff8 <fwp_main_thread+0x13f4>
    5530:	f9000385 	str	x5, [x28]
    5534:	52800018 	mov	w24, #0x0                   	// #0
    5538:	9100239c 	add	x28, x28, #0x8
    553c:	b400077b 	cbz	x27, 5628 <fwp_main_thread+0xa24>
    5540:	aa1b03e8 	mov	x8, x27
    5544:	aa1b03e3 	mov	x3, x27
    5548:	a940ef65 	ldp	x5, x27, [x27, #8]
    554c:	34fffef8 	cbz	w24, 5528 <fwp_main_thread+0x924>
    5550:	f949db41 	ldr	x1, [x26, #5040]
    5554:	f949ef42 	ldr	x2, [x26, #5080]
    5558:	cb010101 	sub	x1, x8, x1
    555c:	eb02403f 	cmp	x1, x2, lsl #16
    5560:	54fffe42 	b.cs	5528 <fwp_main_thread+0x924>  // b.hs, b.nlast
    5564:	d350fc22 	lsr	x2, x1, #16
    5568:	f949ff4a 	ldr	x10, [x26, #5112]
    556c:	8b020842 	add	x2, x2, x2, lsl #2
    5570:	d37df042 	lsl	x2, x2, #3
    5574:	8b020149 	add	x9, x10, x2
    5578:	f9401126 	ldr	x6, [x9, #32]
    557c:	b4fffd66 	cbz	x6, 5528 <fwp_main_thread+0x924>
    5580:	38626942 	ldrb	w2, [x10, x2]
    5584:	7100085f 	cmp	w2, #0x2
    5588:	54fffb81 	b.ne	54f8 <fwp_main_thread+0x8f4>  // b.any
    558c:	72003c3f 	tst	w1, #0xffff
    5590:	54fffcc1 	b.ne	5528 <fwp_main_thread+0x924>  // b.any
    5594:	394000c1 	ldrb	w1, [x6]
    5598:	7100043f 	cmp	w1, #0x1
    559c:	54fffc61 	b.ne	5528 <fwp_main_thread+0x924>  // b.any
    55a0:	f9400260 	ldr	x0, [x19]
    55a4:	b7f852a0 	tbnz	x0, #63, 5ff8 <fwp_main_thread+0x13f4>
    55a8:	f9000385 	str	x5, [x28]
    55ac:	f949db41 	ldr	x1, [x26, #5040]
    55b0:	f949ef40 	ldr	x0, [x26, #5080]
    55b4:	cb010063 	sub	x3, x3, x1
    55b8:	eb00407f 	cmp	x3, x0, lsl #16
    55bc:	540002e2 	b.cs	5618 <fwp_main_thread+0xa14>  // b.hs, b.nlast
    55c0:	d350fc60 	lsr	x0, x3, #16
    55c4:	f949ff41 	ldr	x1, [x26, #5112]
    55c8:	8b000800 	add	x0, x0, x0, lsl #2
    55cc:	d37df000 	lsl	x0, x0, #3
    55d0:	8b000025 	add	x5, x1, x0
    55d4:	f94010a2 	ldr	x2, [x5, #32]
    55d8:	b4000202 	cbz	x2, 5618 <fwp_main_thread+0xa14>
    55dc:	38606820 	ldrb	w0, [x1, x0]
    55e0:	7100081f 	cmp	w0, #0x2
    55e4:	54003a00 	b.eq	5d24 <fwp_main_thread+0x1120>  // b.none
    55e8:	7100041f 	cmp	w0, #0x1
    55ec:	54000161 	b.ne	5618 <fwp_main_thread+0xa14>  // b.any
    55f0:	294300a6 	ldp	w6, w0, [x5, #24]
    55f4:	92403c61 	and	x1, x3, #0xffff
    55f8:	9b067c21 	mul	x1, x1, x6
    55fc:	d360fc21 	lsr	x1, x1, #32
    5600:	eb00003f 	cmp	x1, x0
    5604:	540000a2 	b.cs	5618 <fwp_main_thread+0xa14>  // b.hs, b.nlast
    5608:	8b010042 	add	x2, x2, x1
    560c:	39400040 	ldrb	w0, [x2]
    5610:	7100041f 	cmp	w0, #0x1
    5614:	54000a80 	b.eq	5764 <fwp_main_thread+0xb60>  // b.none
    5618:	aa1b03e0 	mov	x0, x27
    561c:	d503201f 	nop
    5620:	9100239c 	add	x28, x28, #0x8
    5624:	b5fff8fb 	cbnz	x27, 5540 <fwp_main_thread+0x93c>
    5628:	97fff836 	bl	3700 <fwp_drop0>
    562c:	f940027b 	ldr	x27, [x19]
    5630:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    5634:	9240fb7b 	and	x27, x27, #0x7fffffffffffffff
    5638:	eb00037f 	cmp	x27, x0
    563c:	54005248 	b.hi	6084 <fwp_main_thread+0x1480>  // b.pmore
    5640:	aa1b03e0 	mov	x0, x27
    5644:	97fff7c8 	bl	3564 <fwp_array_new_packed.constprop.0>
    5648:	f949db41 	ldr	x1, [x26, #5040]
    564c:	aa0003f9 	mov	x25, x0
    5650:	f949ef40 	ldr	x0, [x26, #5080]
    5654:	cb010321 	sub	x1, x25, x1
    5658:	eb00403f 	cmp	x1, x0, lsl #16
    565c:	54000322 	b.cs	56c0 <fwp_main_thread+0xabc>  // b.hs, b.nlast
    5660:	d350fc20 	lsr	x0, x1, #16
    5664:	f949ff44 	ldr	x4, [x26, #5112]
    5668:	8b000800 	add	x0, x0, x0, lsl #2
    566c:	d37df002 	lsl	x2, x0, #3
    5670:	8b020080 	add	x0, x4, x2
    5674:	f940101c 	ldr	x28, [x0, #32]
    5678:	b400025c 	cbz	x28, 56c0 <fwp_main_thread+0xabc>
    567c:	38626882 	ldrb	w2, [x4, x2]
    5680:	7100085f 	cmp	w2, #0x2
    5684:	54002f00 	b.eq	5c64 <fwp_main_thread+0x1060>  // b.none
    5688:	7100045f 	cmp	w2, #0x1
    568c:	540001a1 	b.ne	56c0 <fwp_main_thread+0xabc>  // b.any
    5690:	29430002 	ldp	w2, w0, [x0, #24]
    5694:	92403c21 	and	x1, x1, #0xffff
    5698:	9b027c21 	mul	x1, x1, x2
    569c:	d360fc21 	lsr	x1, x1, #32
    56a0:	eb00003f 	cmp	x1, x0
    56a4:	540000e2 	b.cs	56c0 <fwp_main_thread+0xabc>  // b.hs, b.nlast
    56a8:	8b01039c 	add	x28, x28, x1
    56ac:	39400380 	ldrb	w0, [x28]
    56b0:	7103fc1f 	cmp	w0, #0xff
    56b4:	54002e20 	b.eq	5c78 <fwp_main_thread+0x1074>  // b.none
    56b8:	52800020 	mov	w0, #0x1                   	// #1
    56bc:	39000380 	strb	w0, [x28]
    56c0:	d2800102 	mov	x2, #0x8                   	// #8
    56c4:	2f00e405 	movi	d5, #0x0
    56c8:	8b020268 	add	x8, x19, x2
    56cc:	d2800024 	mov	x4, #0x1                   	// #1
    56d0:	d2800001 	mov	x1, #0x0                   	// #0
    56d4:	1e6e1006 	fmov	d6, #1.000000000000000000e+00
    56d8:	b400083b 	cbz	x27, 57dc <fwp_main_thread+0xbd8>
    56dc:	d503201f 	nop
    56e0:	f9400260 	ldr	x0, [x19]
    56e4:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    56e8:	eb0100bf 	cmp	x5, x1
    56ec:	54000349 	b.ls	5754 <fwp_main_thread+0xb50>  // b.plast
    56f0:	aa0803e6 	mov	x6, x8
    56f4:	b7f826e0 	tbnz	x0, #63, 5bd0 <fwp_main_thread+0xfcc>
    56f8:	fc6178c3 	ldr	d3, [x6, x1, lsl #3]
    56fc:	9e6703e1 	fmov	d1, xzr
    5700:	b4000241 	cbz	x1, 5748 <fwp_main_thread+0xb44>
    5704:	8b0200c0 	add	x0, x6, x2
    5708:	fc5f0000 	ldur	d0, [x0, #-16]
    570c:	1e650801 	fmul	d1, d0, d5
    5710:	1e600802 	fmul	d2, d0, d0
    5714:	1e6038c0 	fsub	d0, d6, d0
    5718:	1e612821 	fadd	d1, d1, d1
    571c:	1e623862 	fsub	d2, d3, d2
    5720:	1e650800 	fmul	d0, d0, d5
    5724:	1e6138c1 	fsub	d1, d6, d1
    5728:	1e620844 	fmul	d4, d2, d2
    572c:	1e602800 	fadd	d0, d0, d0
    5730:	1e620821 	fmul	d1, d1, d2
    5734:	1e650882 	fmul	d2, d4, d5
    5738:	1e612821 	fadd	d1, d1, d1
    573c:	1e680821 	fmul	d1, d1, d8
    5740:	1e622821 	fadd	d1, d1, d2
    5744:	1e602821 	fadd	d1, d1, d0
    5748:	eb0400bf 	cmp	x5, x4
    574c:	54001fc0 	b.eq	5b44 <fwp_main_thread+0xf40>  // b.none
    5750:	54000128 	b.hi	5774 <fwp_main_thread+0xb70>  // b.pmore
    5754:	f00000c0 	adrp	x0, 20000 <__data_start>
    5758:	91004000 	add	x0, x0, #0x10
    575c:	91002000 	add	x0, x0, #0x8
    5760:	97fff250 	bl	20a0 <fwp_trap>
    5764:	aa0803e0 	mov	x0, x8
    5768:	97fff5ae 	bl	2e20 <fwp_mem_free>
    576c:	aa1b03e0 	mov	x0, x27
    5770:	17ffffac 	b	5620 <fwp_main_thread+0xa1c>
    5774:	fc6268c4 	ldr	d4, [x6, x2]
    5778:	1e630867 	fmul	d7, d3, d3
    577c:	1e632860 	fadd	d0, d3, d3
    5780:	1e6338c2 	fsub	d2, d6, d3
    5784:	1e673884 	fsub	d4, d4, d7
    5788:	1e6038a0 	fsub	d0, d5, d0
    578c:	1e614042 	fneg	d2, d2
    5790:	1e640887 	fmul	d7, d4, d4
    5794:	1e640800 	fmul	d0, d0, d4
    5798:	1e622842 	fadd	d2, d2, d2
    579c:	1e6508e4 	fmul	d4, d7, d5
    57a0:	1e602800 	fadd	d0, d0, d0
    57a4:	1e680800 	fmul	d0, d0, d8
    57a8:	1e642800 	fadd	d0, d0, d4
    57ac:	1e622800 	fadd	d0, d0, d2
    57b0:	1e612800 	fadd	d0, d0, d1
    57b4:	f9400320 	ldr	x0, [x25]
    57b8:	1e690800 	fmul	d0, d0, d9
    57bc:	1e603863 	fsub	d3, d3, d0
    57c0:	b7f841c0 	tbnz	x0, #63, 5ff8 <fwp_main_thread+0x13f4>
    57c4:	91000421 	add	x1, x1, #0x1
    57c8:	fc226b23 	str	d3, [x25, x2]
    57cc:	91000484 	add	x4, x4, #0x1
    57d0:	91002042 	add	x2, x2, #0x8
    57d4:	eb01037f 	cmp	x27, x1
    57d8:	54fff841 	b.ne	56e0 <fwp_main_thread+0xadc>  // b.any
    57dc:	f949db41 	ldr	x1, [x26, #5040]
    57e0:	f949ef40 	ldr	x0, [x26, #5080]
    57e4:	cb010261 	sub	x1, x19, x1
    57e8:	eb00403f 	cmp	x1, x0, lsl #16
    57ec:	540003a2 	b.cs	5860 <fwp_main_thread+0xc5c>  // b.hs, b.nlast
    57f0:	d350fc20 	lsr	x0, x1, #16
    57f4:	f949ff45 	ldr	x5, [x26, #5112]
    57f8:	8b000800 	add	x0, x0, x0, lsl #2
    57fc:	d37df000 	lsl	x0, x0, #3
    5800:	8b0000a2 	add	x2, x5, x0
    5804:	f940105b 	ldr	x27, [x2, #32]
    5808:	b40002db 	cbz	x27, 5860 <fwp_main_thread+0xc5c>
    580c:	386068a0 	ldrb	w0, [x5, x0]
    5810:	7100081f 	cmp	w0, #0x2
    5814:	54001e20 	b.eq	5bd8 <fwp_main_thread+0xfd4>  // b.none
    5818:	7100041f 	cmp	w0, #0x1
    581c:	54000221 	b.ne	5860 <fwp_main_thread+0xc5c>  // b.any
    5820:	29430044 	ldp	w4, w0, [x2, #24]
    5824:	92403c21 	and	x1, x1, #0xffff
    5828:	9b047c21 	mul	x1, x1, x4
    582c:	d360fc21 	lsr	x1, x1, #32
    5830:	eb00003f 	cmp	x1, x0
    5834:	54000162 	b.cs	5860 <fwp_main_thread+0xc5c>  // b.hs, b.nlast
    5838:	8b01037b 	add	x27, x27, x1
    583c:	39400360 	ldrb	w0, [x27]
    5840:	34000100 	cbz	w0, 5860 <fwp_main_thread+0xc5c>
    5844:	7100041f 	cmp	w0, #0x1
    5848:	54001820 	b.eq	5b4c <fwp_main_thread+0xf48>  // b.none
    584c:	7103fc1f 	cmp	w0, #0xff
    5850:	54002be0 	b.eq	5dcc <fwp_main_thread+0x11c8>  // b.none
    5854:	51000400 	sub	w0, w0, #0x1
    5858:	39000360 	strb	w0, [x27]
    585c:	d503201f 	nop
    5860:	52800b64 	mov	w4, #0x5b                  	// #91
    5864:	aa1403e0 	mov	x0, x20
    5868:	aa1503e1 	mov	x1, x21
    586c:	d2800022 	mov	x2, #0x1                   	// #1
    5870:	390063e4 	strb	w4, [sp, #24]
    5874:	d00000d3 	adrp	x19, 1f000 <__FRAME_END__+0x17668>
    5878:	a9037fff 	stp	xzr, xzr, [sp, #48]
    587c:	912ca273 	add	x19, x19, #0xb28
    5880:	9100233c 	add	x28, x25, #0x8
    5884:	f90023ff 	str	xzr, [sp, #64]
    5888:	97fff1aa 	bl	1f30 <buf_put>
    588c:	f9400320 	ldr	x0, [x25]
    5890:	91014273 	add	x19, x19, #0x50
    5894:	d2800018 	mov	x24, #0x0                   	// #0
    5898:	f240f81b 	ands	x27, x0, #0x7fffffffffffffff
    589c:	540001e1 	b.ne	58d8 <fwp_main_thread+0xcd4>  // b.any
    58a0:	14000018 	b	5900 <fwp_main_thread+0xcfc>
    58a4:	f8787821 	ldr	x1, [x1, x24, lsl #3]
    58a8:	aa1303e2 	mov	x2, x19
    58ac:	aa1403e0 	mov	x0, x20
    58b0:	91000718 	add	x24, x24, #0x1
    58b4:	97fff8eb 	bl	3c60 <fwp_write.constprop.0>
    58b8:	eb18037f 	cmp	x27, x24
    58bc:	54000220 	b.eq	5900 <fwp_main_thread+0xcfc>  // b.none
    58c0:	aa1403e0 	mov	x0, x20
    58c4:	b0000001 	adrp	x1, 6000 <fwp_main_thread+0x13fc>
    58c8:	d2800042 	mov	x2, #0x2                   	// #2
    58cc:	912b2021 	add	x1, x1, #0xac8
    58d0:	97fff198 	bl	1f30 <buf_put>
    58d4:	f9400320 	ldr	x0, [x25]
    58d8:	aa1c03e1 	mov	x1, x28
    58dc:	b6fffe40 	tbz	x0, #63, 58a4 <fwp_main_thread+0xca0>
    58e0:	f9400b21 	ldr	x1, [x25, #16]
    58e4:	aa1303e2 	mov	x2, x19
    58e8:	aa1403e0 	mov	x0, x20
    58ec:	f8787821 	ldr	x1, [x1, x24, lsl #3]
    58f0:	91000718 	add	x24, x24, #0x1
    58f4:	97fff8db 	bl	3c60 <fwp_write.constprop.0>
    58f8:	eb18037f 	cmp	x27, x24
    58fc:	54fffe21 	b.ne	58c0 <fwp_main_thread+0xcbc>  // b.any
    5900:	52800ba4 	mov	w4, #0x5d                  	// #93
    5904:	aa1403e0 	mov	x0, x20
    5908:	aa1503e1 	mov	x1, x21
    590c:	d2800022 	mov	x2, #0x1                   	// #1
    5910:	390063e4 	strb	w4, [sp, #24]
    5914:	97fff187 	bl	1f30 <buf_put>
    5918:	a94373fb 	ldp	x27, x28, [sp, #48]
    591c:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    5920:	9129e000 	add	x0, x0, #0xa78
    5924:	f100037f 	cmp	x27, #0x0
    5928:	9a9b001b 	csel	x27, x0, x27, eq	// eq = none
    592c:	b1002b9f 	cmn	x28, #0xa
    5930:	54003b88 	b.hi	60a0 <fwp_main_thread+0x149c>  // b.pmore
    5934:	91002780 	add	x0, x28, #0x9
    5938:	52800021 	mov	w1, #0x1                   	// #1
    593c:	97fff67a 	bl	3324 <fwp_heap_alloc>
    5940:	aa0003f3 	mov	x19, x0
    5944:	aa1b03e1 	mov	x1, x27
    5948:	aa0003fb 	mov	x27, x0
    594c:	aa1c03e2 	mov	x2, x28
    5950:	f800877c 	str	x28, [x27], #8
    5954:	8b1c027c 	add	x28, x19, x28
    5958:	aa1b03e0 	mov	x0, x27
    595c:	97ffee69 	bl	1300 <memcpy@plt>
    5960:	3900239f 	strb	wzr, [x28, #8]
    5964:	f9401be0 	ldr	x0, [sp, #48]
    5968:	97ffeefe 	bl	1560 <free@plt>
    596c:	f949ef44 	ldr	x4, [x26, #5080]
    5970:	f949db41 	ldr	x1, [x26, #5040]
    5974:	d370bc84 	lsl	x4, x4, #16
    5978:	cb010265 	sub	x5, x19, x1
    597c:	eb0400bf 	cmp	x5, x4
    5980:	54000382 	b.cs	59f0 <fwp_main_thread+0xdec>  // b.hs, b.nlast
    5984:	d350fca0 	lsr	x0, x5, #16
    5988:	f949ff46 	ldr	x6, [x26, #5112]
    598c:	8b000800 	add	x0, x0, x0, lsl #2
    5990:	d37df002 	lsl	x2, x0, #3
    5994:	8b0200c0 	add	x0, x6, x2
    5998:	f940101c 	ldr	x28, [x0, #32]
    599c:	b40002bc 	cbz	x28, 59f0 <fwp_main_thread+0xdec>
    59a0:	386268c2 	ldrb	w2, [x6, x2]
    59a4:	7100085f 	cmp	w2, #0x2
    59a8:	54002420 	b.eq	5e2c <fwp_main_thread+0x1228>  // b.none
    59ac:	7100045f 	cmp	w2, #0x1
    59b0:	54000201 	b.ne	59f0 <fwp_main_thread+0xdec>  // b.any
    59b4:	29430006 	ldp	w6, w0, [x0, #24]
    59b8:	92403ca2 	and	x2, x5, #0xffff
    59bc:	9b067c42 	mul	x2, x2, x6
    59c0:	d360fc42 	lsr	x2, x2, #32
    59c4:	eb00005f 	cmp	x2, x0
    59c8:	54000142 	b.cs	59f0 <fwp_main_thread+0xdec>  // b.hs, b.nlast
    59cc:	8b02039c 	add	x28, x28, x2
    59d0:	39400380 	ldrb	w0, [x28]
    59d4:	7103fc1f 	cmp	w0, #0xff
    59d8:	54002340 	b.eq	5e40 <fwp_main_thread+0x123c>  // b.none
    59dc:	52800020 	mov	w0, #0x1                   	// #1
    59e0:	39000380 	strb	w0, [x28]
    59e4:	f949ef44 	ldr	x4, [x26, #5080]
    59e8:	f949db41 	ldr	x1, [x26, #5040]
    59ec:	d370bc84 	lsl	x4, x4, #16
    59f0:	cb010321 	sub	x1, x25, x1
    59f4:	eb04003f 	cmp	x1, x4
    59f8:	54000382 	b.cs	5a68 <fwp_main_thread+0xe64>  // b.hs, b.nlast
    59fc:	d350fc20 	lsr	x0, x1, #16
    5a00:	f949ff44 	ldr	x4, [x26, #5112]
    5a04:	8b000800 	add	x0, x0, x0, lsl #2
    5a08:	d37df002 	lsl	x2, x0, #3
    5a0c:	8b020080 	add	x0, x4, x2
    5a10:	f940101c 	ldr	x28, [x0, #32]
    5a14:	b40002bc 	cbz	x28, 5a68 <fwp_main_thread+0xe64>
    5a18:	38626882 	ldrb	w2, [x4, x2]
    5a1c:	7100085f 	cmp	w2, #0x2
    5a20:	540018a0 	b.eq	5d34 <fwp_main_thread+0x1130>  // b.none
    5a24:	7100045f 	cmp	w2, #0x1
    5a28:	54000201 	b.ne	5a68 <fwp_main_thread+0xe64>  // b.any
    5a2c:	29430002 	ldp	w2, w0, [x0, #24]
    5a30:	92403c21 	and	x1, x1, #0xffff
    5a34:	9b027c21 	mul	x1, x1, x2
    5a38:	d360fc21 	lsr	x1, x1, #32
    5a3c:	eb00003f 	cmp	x1, x0
    5a40:	54000142 	b.cs	5a68 <fwp_main_thread+0xe64>  // b.hs, b.nlast
    5a44:	8b01039c 	add	x28, x28, x1
    5a48:	39400380 	ldrb	w0, [x28]
    5a4c:	340000e0 	cbz	w0, 5a68 <fwp_main_thread+0xe64>
    5a50:	7100041f 	cmp	w0, #0x1
    5a54:	540011e0 	b.eq	5c90 <fwp_main_thread+0x108c>  // b.none
    5a58:	7103fc1f 	cmp	w0, #0xff
    5a5c:	54002200 	b.eq	5e9c <fwp_main_thread+0x1298>  // b.none
    5a60:	51000400 	sub	w0, w0, #0x1
    5a64:	39000380 	strb	w0, [x28]
    5a68:	f9400262 	ldr	x2, [x19]
    5a6c:	d2800021 	mov	x1, #0x1                   	// #1
    5a70:	f9403ae3 	ldr	x3, [x23, #112]
    5a74:	aa1b03e0 	mov	x0, x27
    5a78:	97ffeeca 	bl	15a0 <fwrite@plt>
    5a7c:	f9403ae1 	ldr	x1, [x23, #112]
    5a80:	52800140 	mov	w0, #0xa                   	// #10
    5a84:	97ffee4f 	bl	13c0 <fputc@plt>
    5a88:	f949db41 	ldr	x1, [x26, #5040]
    5a8c:	f949ef40 	ldr	x0, [x26, #5080]
    5a90:	cb010261 	sub	x1, x19, x1
    5a94:	eb00403f 	cmp	x1, x0, lsl #16
    5a98:	54000382 	b.cs	5b08 <fwp_main_thread+0xf04>  // b.hs, b.nlast
    5a9c:	d350fc20 	lsr	x0, x1, #16
    5aa0:	f949ff43 	ldr	x3, [x26, #5112]
    5aa4:	8b000800 	add	x0, x0, x0, lsl #2
    5aa8:	d37df002 	lsl	x2, x0, #3
    5aac:	8b020060 	add	x0, x3, x2
    5ab0:	f940101b 	ldr	x27, [x0, #32]
    5ab4:	b40002bb 	cbz	x27, 5b08 <fwp_main_thread+0xf04>
    5ab8:	38626862 	ldrb	w2, [x3, x2]
    5abc:	7100085f 	cmp	w2, #0x2
    5ac0:	54001b00 	b.eq	5e20 <fwp_main_thread+0x121c>  // b.none
    5ac4:	7100045f 	cmp	w2, #0x1
    5ac8:	54000201 	b.ne	5b08 <fwp_main_thread+0xf04>  // b.any
    5acc:	29430002 	ldp	w2, w0, [x0, #24]
    5ad0:	92403c21 	and	x1, x1, #0xffff
    5ad4:	9b027c21 	mul	x1, x1, x2
    5ad8:	d360fc21 	lsr	x1, x1, #32
    5adc:	eb00003f 	cmp	x1, x0
    5ae0:	54000142 	b.cs	5b08 <fwp_main_thread+0xf04>  // b.hs, b.nlast
    5ae4:	8b01037b 	add	x27, x27, x1
    5ae8:	39400360 	ldrb	w0, [x27]
    5aec:	340000e0 	cbz	w0, 5b08 <fwp_main_thread+0xf04>
    5af0:	7100041f 	cmp	w0, #0x1
    5af4:	540010c0 	b.eq	5d0c <fwp_main_thread+0x1108>  // b.none
    5af8:	7103fc1f 	cmp	w0, #0xff
    5afc:	54002500 	b.eq	5f9c <fwp_main_thread+0x1398>  // b.none
    5b00:	51000400 	sub	w0, w0, #0x1
    5b04:	39000360 	strb	w0, [x27]
    5b08:	f94007e0 	ldr	x0, [sp, #8]
    5b0c:	f9400800 	ldr	x0, [x0, #16]
    5b10:	f90007e0 	str	x0, [sp, #8]
    5b14:	b5ffc540 	cbnz	x0, 53bc <fwp_main_thread+0x7b8>
    5b18:	f94003e0 	ldr	x0, [sp]
    5b1c:	97fff6f9 	bl	3700 <fwp_drop0>
    5b20:	aa1603e0 	mov	x0, x22
    5b24:	97fff6f7 	bl	3700 <fwp_drop0>
    5b28:	9101c2e0 	add	x0, x23, #0x70
    5b2c:	52800021 	mov	w1, #0x1                   	// #1
    5b30:	a9556bf9 	ldp	x25, x26, [sp, #336]
    5b34:	6d5727e8 	ldp	d8, d9, [sp, #368]
    5b38:	b9029401 	str	w1, [x0, #660]
    5b3c:	f9014c1f 	str	xzr, [x0, #664]
    5b40:	17fffc72 	b	4d08 <fwp_main_thread+0x104>
    5b44:	2f00e400 	movi	d0, #0x0
    5b48:	17ffff1a 	b	57b0 <fwp_main_thread+0xbac>
    5b4c:	f9400266 	ldr	x6, [x19]
    5b50:	aa1303e0 	mov	x0, x19
    5b54:	f949ef44 	ldr	x4, [x26, #5080]
    5b58:	f949db41 	ldr	x1, [x26, #5040]
    5b5c:	d370bc84 	lsl	x4, x4, #16
    5b60:	cb010262 	sub	x2, x19, x1
    5b64:	b7f80406 	tbnz	x6, #63, 5be4 <fwp_main_thread+0xfe0>
    5b68:	eb04005f 	cmp	x2, x4
    5b6c:	54ffe7a2 	b.cs	5860 <fwp_main_thread+0xc5c>  // b.hs, b.nlast
    5b70:	d350fc40 	lsr	x0, x2, #16
    5b74:	8b000800 	add	x0, x0, x0, lsl #2
    5b78:	d37df000 	lsl	x0, x0, #3
    5b7c:	8b0000a4 	add	x4, x5, x0
    5b80:	f9401081 	ldr	x1, [x4, #32]
    5b84:	b4ffe6e1 	cbz	x1, 5860 <fwp_main_thread+0xc5c>
    5b88:	386068a0 	ldrb	w0, [x5, x0]
    5b8c:	7100081f 	cmp	w0, #0x2
    5b90:	540007a0 	b.eq	5c84 <fwp_main_thread+0x1080>  // b.none
    5b94:	7100041f 	cmp	w0, #0x1
    5b98:	54ffe641 	b.ne	5860 <fwp_main_thread+0xc5c>  // b.any
    5b9c:	92403c40 	and	x0, x2, #0xffff
    5ba0:	29430885 	ldp	w5, w2, [x4, #24]
    5ba4:	9b057c00 	mul	x0, x0, x5
    5ba8:	d360fc00 	lsr	x0, x0, #32
    5bac:	eb02001f 	cmp	x0, x2
    5bb0:	54ffe582 	b.cs	5860 <fwp_main_thread+0xc5c>  // b.hs, b.nlast
    5bb4:	8b000021 	add	x1, x1, x0
    5bb8:	39400020 	ldrb	w0, [x1]
    5bbc:	7100041f 	cmp	w0, #0x1
    5bc0:	54ffe501 	b.ne	5860 <fwp_main_thread+0xc5c>  // b.any
    5bc4:	aa1303e0 	mov	x0, x19
    5bc8:	97fff496 	bl	2e20 <fwp_mem_free>
    5bcc:	17ffff25 	b	5860 <fwp_main_thread+0xc5c>
    5bd0:	f9400a66 	ldr	x6, [x19, #16]
    5bd4:	17fffec9 	b	56f8 <fwp_main_thread+0xaf4>
    5bd8:	72003c3f 	tst	w1, #0xffff
    5bdc:	54ffe421 	b.ne	5860 <fwp_main_thread+0xc5c>  // b.any
    5be0:	17ffff17 	b	583c <fwp_main_thread+0xc38>
    5be4:	f9400673 	ldr	x19, [x19, #8]
    5be8:	eb04005f 	cmp	x2, x4
    5bec:	54000342 	b.cs	5c54 <fwp_main_thread+0x1050>  // b.hs, b.nlast
    5bf0:	d350fc46 	lsr	x6, x2, #16
    5bf4:	8b0608c6 	add	x6, x6, x6, lsl #2
    5bf8:	d37df0c6 	lsl	x6, x6, #3
    5bfc:	8b0600a9 	add	x9, x5, x6
    5c00:	f9401128 	ldr	x8, [x9, #32]
    5c04:	b4000288 	cbz	x8, 5c54 <fwp_main_thread+0x1050>
    5c08:	386668a5 	ldrb	w5, [x5, x6]
    5c0c:	710008bf 	cmp	w5, #0x2
    5c10:	54000840 	b.eq	5d18 <fwp_main_thread+0x1114>  // b.none
    5c14:	710004bf 	cmp	w5, #0x1
    5c18:	540001e1 	b.ne	5c54 <fwp_main_thread+0x1050>  // b.any
    5c1c:	29431526 	ldp	w6, w5, [x9, #24]
    5c20:	92403c42 	and	x2, x2, #0xffff
    5c24:	9b067c42 	mul	x2, x2, x6
    5c28:	d360fc42 	lsr	x2, x2, #32
    5c2c:	eb05005f 	cmp	x2, x5
    5c30:	54000122 	b.cs	5c54 <fwp_main_thread+0x1050>  // b.hs, b.nlast
    5c34:	8b020108 	add	x8, x8, x2
    5c38:	39400102 	ldrb	w2, [x8]
    5c3c:	7100045f 	cmp	w2, #0x1
    5c40:	540000a1 	b.ne	5c54 <fwp_main_thread+0x1050>  // b.any
    5c44:	97fff477 	bl	2e20 <fwp_mem_free>
    5c48:	f949ef44 	ldr	x4, [x26, #5080]
    5c4c:	f949db41 	ldr	x1, [x26, #5040]
    5c50:	d370bc84 	lsl	x4, x4, #16
    5c54:	cb010261 	sub	x1, x19, x1
    5c58:	eb04003f 	cmp	x1, x4
    5c5c:	54ffdca3 	b.cc	57f0 <fwp_main_thread+0xbec>  // b.lo, b.ul, b.last
    5c60:	17ffff00 	b	5860 <fwp_main_thread+0xc5c>
    5c64:	72003c3f 	tst	w1, #0xffff
    5c68:	54ffd2c1 	b.ne	56c0 <fwp_main_thread+0xabc>  // b.any
    5c6c:	39400380 	ldrb	w0, [x28]
    5c70:	7103fc1f 	cmp	w0, #0xff
    5c74:	54ffd221 	b.ne	56b8 <fwp_main_thread+0xab4>  // b.any
    5c78:	aa1c03e0 	mov	x0, x28
    5c7c:	97fff3ca 	bl	2ba4 <fwp_rc_forget_slot>
    5c80:	17fffe8e 	b	56b8 <fwp_main_thread+0xab4>
    5c84:	72003c5f 	tst	w2, #0xffff
    5c88:	54ffdec1 	b.ne	5860 <fwp_main_thread+0xc5c>  // b.any
    5c8c:	17ffffcb 	b	5bb8 <fwp_main_thread+0xfb4>
    5c90:	f9400320 	ldr	x0, [x25]
    5c94:	b7f80560 	tbnz	x0, #63, 5d40 <fwp_main_thread+0x113c>
    5c98:	f949db40 	ldr	x0, [x26, #5040]
    5c9c:	f949ef41 	ldr	x1, [x26, #5080]
    5ca0:	cb000320 	sub	x0, x25, x0
    5ca4:	eb01401f 	cmp	x0, x1, lsl #16
    5ca8:	54ffee02 	b.cs	5a68 <fwp_main_thread+0xe64>  // b.hs, b.nlast
    5cac:	d350fc01 	lsr	x1, x0, #16
    5cb0:	8b010821 	add	x1, x1, x1, lsl #2
    5cb4:	d37df021 	lsl	x1, x1, #3
    5cb8:	8b010085 	add	x5, x4, x1
    5cbc:	f94010a2 	ldr	x2, [x5, #32]
    5cc0:	b4ffed42 	cbz	x2, 5a68 <fwp_main_thread+0xe64>
    5cc4:	38616881 	ldrb	w1, [x4, x1]
    5cc8:	7100083f 	cmp	w1, #0x2
    5ccc:	54000c00 	b.eq	5e4c <fwp_main_thread+0x1248>  // b.none
    5cd0:	7100043f 	cmp	w1, #0x1
    5cd4:	54ffeca1 	b.ne	5a68 <fwp_main_thread+0xe64>  // b.any
    5cd8:	294304a4 	ldp	w4, w1, [x5, #24]
    5cdc:	92403c00 	and	x0, x0, #0xffff
    5ce0:	9b047c00 	mul	x0, x0, x4
    5ce4:	d360fc00 	lsr	x0, x0, #32
    5ce8:	eb01001f 	cmp	x0, x1
    5cec:	54ffebe2 	b.cs	5a68 <fwp_main_thread+0xe64>  // b.hs, b.nlast
    5cf0:	8b000042 	add	x2, x2, x0
    5cf4:	39400040 	ldrb	w0, [x2]
    5cf8:	7100041f 	cmp	w0, #0x1
    5cfc:	54ffeb61 	b.ne	5a68 <fwp_main_thread+0xe64>  // b.any
    5d00:	aa1903e0 	mov	x0, x25
    5d04:	97fff447 	bl	2e20 <fwp_mem_free>
    5d08:	17ffff58 	b	5a68 <fwp_main_thread+0xe64>
    5d0c:	aa1303e0 	mov	x0, x19
    5d10:	97fff564 	bl	32a0 <fwp_rc_free_arr>
    5d14:	17ffff7d 	b	5b08 <fwp_main_thread+0xf04>
    5d18:	72003c5f 	tst	w2, #0xffff
    5d1c:	54fff9c1 	b.ne	5c54 <fwp_main_thread+0x1050>  // b.any
    5d20:	17ffffc6 	b	5c38 <fwp_main_thread+0x1034>
    5d24:	72003c7f 	tst	w3, #0xffff
    5d28:	54ffc720 	b.eq	560c <fwp_main_thread+0xa08>  // b.none
    5d2c:	aa1b03e0 	mov	x0, x27
    5d30:	17fffe3c 	b	5620 <fwp_main_thread+0xa1c>
    5d34:	72003c3f 	tst	w1, #0xffff
    5d38:	54ffe981 	b.ne	5a68 <fwp_main_thread+0xe64>  // b.any
    5d3c:	17ffff43 	b	5a48 <fwp_main_thread+0xe44>
    5d40:	f940073c 	ldr	x28, [x25, #8]
    5d44:	aa1903e0 	mov	x0, x25
    5d48:	97fff556 	bl	32a0 <fwp_rc_free_arr>
    5d4c:	f949db41 	ldr	x1, [x26, #5040]
    5d50:	f949ef40 	ldr	x0, [x26, #5080]
    5d54:	cb010381 	sub	x1, x28, x1
    5d58:	eb00403f 	cmp	x1, x0, lsl #16
    5d5c:	54ffe862 	b.cs	5a68 <fwp_main_thread+0xe64>  // b.hs, b.nlast
    5d60:	aa1c03f9 	mov	x25, x28
    5d64:	17ffff26 	b	59fc <fwp_main_thread+0xdf8>
    5d68:	72003c1f 	tst	w0, #0xffff
    5d6c:	54ffb5a0 	b.eq	5420 <fwp_main_thread+0x81c>  // b.none
    5d70:	f94003e0 	ldr	x0, [sp]
    5d74:	b5ffb660 	cbnz	x0, 5440 <fwp_main_thread+0x83c>
    5d78:	d2800000 	mov	x0, #0x0                   	// #0
    5d7c:	97fff5fa 	bl	3564 <fwp_array_new_packed.constprop.0>
    5d80:	90000161 	adrp	x1, 31000 <fwp_root_context+0xcd0>
    5d84:	91144021 	add	x1, x1, #0x510
    5d88:	aa0003f3 	mov	x19, x0
    5d8c:	aa0103e0 	mov	x0, x1
    5d90:	f949d821 	ldr	x1, [x1, #5040]
    5d94:	f949ec00 	ldr	x0, [x0, #5080]
    5d98:	cb010261 	sub	x1, x19, x1
    5d9c:	eb00403f 	cmp	x1, x0, lsl #16
    5da0:	54ffb6e3 	b.cc	547c <fwp_main_thread+0x878>  // b.lo, b.ul, b.last
    5da4:	d2800000 	mov	x0, #0x0                   	// #0
    5da8:	17fffe20 	b	5628 <fwp_main_thread+0xa24>
    5dac:	72003c3f 	tst	w1, #0xffff
    5db0:	54ffb961 	b.ne	54dc <fwp_main_thread+0x8d8>  // b.any
    5db4:	39400360 	ldrb	w0, [x27]
    5db8:	7103fc1f 	cmp	w0, #0xff
    5dbc:	54ffb8c1 	b.ne	54d4 <fwp_main_thread+0x8d0>  // b.any
    5dc0:	aa1b03e0 	mov	x0, x27
    5dc4:	97fff378 	bl	2ba4 <fwp_rc_forget_slot>
    5dc8:	17fffdc3 	b	54d4 <fwp_main_thread+0x8d0>
    5dcc:	ca5b4760 	eor	x0, x27, x27, lsr #17
    5dd0:	ca402400 	eor	x0, x0, x0, lsr #9
    5dd4:	8b200f40 	add	x0, x26, w0, uxtb #3
    5dd8:	f94a2400 	ldr	x0, [x0, #5192]
    5ddc:	b5000080 	cbnz	x0, 5dec <fwp_main_thread+0x11e8>
    5de0:	1400008b 	b	600c <fwp_main_thread+0x1408>
    5de4:	f9400800 	ldr	x0, [x0, #16]
    5de8:	b4001120 	cbz	x0, 600c <fwp_main_thread+0x1408>
    5dec:	f9400001 	ldr	x1, [x0]
    5df0:	eb1b003f 	cmp	x1, x27
    5df4:	54ffff81 	b.ne	5de4 <fwp_main_thread+0x11e0>  // b.any
    5df8:	f9400401 	ldr	x1, [x0, #8]
    5dfc:	d1000421 	sub	x1, x1, #0x1
    5e00:	f9000401 	str	x1, [x0, #8]
    5e04:	f103f83f 	cmp	x1, #0xfe
    5e08:	54ffd2c1 	b.ne	5860 <fwp_main_thread+0xc5c>  // b.any
    5e0c:	aa1b03e0 	mov	x0, x27
    5e10:	97fff365 	bl	2ba4 <fwp_rc_forget_slot>
    5e14:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e18:	39000360 	strb	w0, [x27]
    5e1c:	17fffe91 	b	5860 <fwp_main_thread+0xc5c>
    5e20:	72003c3f 	tst	w1, #0xffff
    5e24:	54ffe721 	b.ne	5b08 <fwp_main_thread+0xf04>  // b.any
    5e28:	17ffff30 	b	5ae8 <fwp_main_thread+0xee4>
    5e2c:	72003cbf 	tst	w5, #0xffff
    5e30:	54ffde01 	b.ne	59f0 <fwp_main_thread+0xdec>  // b.any
    5e34:	39400380 	ldrb	w0, [x28]
    5e38:	7103fc1f 	cmp	w0, #0xff
    5e3c:	54ffdd01 	b.ne	59dc <fwp_main_thread+0xdd8>  // b.any
    5e40:	aa1c03e0 	mov	x0, x28
    5e44:	97fff358 	bl	2ba4 <fwp_rc_forget_slot>
    5e48:	17fffee5 	b	59dc <fwp_main_thread+0xdd8>
    5e4c:	72003c1f 	tst	w0, #0xffff
    5e50:	54ffe0c1 	b.ne	5a68 <fwp_main_thread+0xe64>  // b.any
    5e54:	17ffffa8 	b	5cf4 <fwp_main_thread+0x10f0>
    5e58:	d2800013 	mov	x19, #0x0                   	// #0
    5e5c:	17fffbeb 	b	4e08 <fwp_main_thread+0x204>
    5e60:	72003c3f 	tst	w1, #0xffff
    5e64:	54ffa501 	b.ne	5304 <fwp_main_thread+0x700>  // b.any
    5e68:	17fffd22 	b	52f0 <fwp_main_thread+0x6ec>
    5e6c:	72003c3f 	tst	w1, #0xffff
    5e70:	54ffa021 	b.ne	5274 <fwp_main_thread+0x670>  // b.any
    5e74:	17fffcfb 	b	5260 <fwp_main_thread+0x65c>
    5e78:	72003c3f 	tst	w1, #0xffff
    5e7c:	54ffa901 	b.ne	539c <fwp_main_thread+0x798>  // b.any
    5e80:	17fffd42 	b	5388 <fwp_main_thread+0x784>
    5e84:	aa1c03e0 	mov	x0, x28
    5e88:	97fff347 	bl	2ba4 <fwp_rc_forget_slot>
    5e8c:	17fffcb0 	b	514c <fwp_main_thread+0x548>
    5e90:	aa0003e1 	mov	x1, x0
    5e94:	f9002293 	str	x19, [x20, #64]
    5e98:	17fffbb5 	b	4d6c <fwp_main_thread+0x168>
    5e9c:	ca5c4780 	eor	x0, x28, x28, lsr #17
    5ea0:	90000161 	adrp	x1, 31000 <fwp_root_context+0xcd0>
    5ea4:	91144021 	add	x1, x1, #0x510
    5ea8:	ca402400 	eor	x0, x0, x0, lsr #9
    5eac:	8b200c20 	add	x0, x1, w0, uxtb #3
    5eb0:	f94a2400 	ldr	x0, [x0, #5192]
    5eb4:	b5000080 	cbnz	x0, 5ec4 <fwp_main_thread+0x12c0>
    5eb8:	14000055 	b	600c <fwp_main_thread+0x1408>
    5ebc:	f9400800 	ldr	x0, [x0, #16]
    5ec0:	b4000a60 	cbz	x0, 600c <fwp_main_thread+0x1408>
    5ec4:	f9400001 	ldr	x1, [x0]
    5ec8:	eb01039f 	cmp	x28, x1
    5ecc:	54ffff81 	b.ne	5ebc <fwp_main_thread+0x12b8>  // b.any
    5ed0:	f9400401 	ldr	x1, [x0, #8]
    5ed4:	d1000421 	sub	x1, x1, #0x1
    5ed8:	f9000401 	str	x1, [x0, #8]
    5edc:	f103f83f 	cmp	x1, #0xfe
    5ee0:	54ffdc41 	b.ne	5a68 <fwp_main_thread+0xe64>  // b.any
    5ee4:	aa1c03e0 	mov	x0, x28
    5ee8:	97fff32f 	bl	2ba4 <fwp_rc_forget_slot>
    5eec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ef0:	39000380 	strb	w0, [x28]
    5ef4:	17fffedd 	b	5a68 <fwp_main_thread+0xe64>
    5ef8:	f9413a80 	ldr	x0, [x20, #624]
    5efc:	97fff3c9 	bl	2e20 <fwp_mem_free>
    5f00:	f9013a9f 	str	xzr, [x20, #624]
    5f04:	f901429f 	str	xzr, [x20, #640]
    5f08:	f9415680 	ldr	x0, [x20, #680]
    5f0c:	b4000873 	cbz	x19, 6018 <fwp_main_thread+0x1414>
    5f10:	f900567f 	str	xzr, [x19, #168]
    5f14:	f9005e7f 	str	xzr, [x19, #184]
    5f18:	b902a29f 	str	wzr, [x20, #672]
    5f1c:	eb00027f 	cmp	x19, x0
    5f20:	54ff7860 	b.eq	4e2c <fwp_main_thread+0x228>  // b.none
    5f24:	a9156bf9 	stp	x25, x26, [sp, #336]
    5f28:	6d1727e8 	stp	d8, d9, [sp, #368]
    5f2c:	97ffed71 	bl	14f0 <abort@plt>
    5f30:	ca534661 	eor	x1, x19, x19, lsr #17
    5f34:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcd0>
    5f38:	91144042 	add	x2, x2, #0x510
    5f3c:	ca412421 	eor	x1, x1, x1, lsr #9
    5f40:	92401c21 	and	x1, x1, #0xff
    5f44:	910a2423 	add	x3, x1, #0x289
    5f48:	8b010c41 	add	x1, x2, x1, lsl #3
    5f4c:	8b030c5b 	add	x27, x2, x3, lsl #3
    5f50:	f94a2421 	ldr	x1, [x1, #5192]
    5f54:	b50000a1 	cbnz	x1, 5f68 <fwp_main_thread+0x1364>
    5f58:	14000061 	b	60dc <fwp_main_thread+0x14d8>
    5f5c:	9100403b 	add	x27, x1, #0x10
    5f60:	f9400821 	ldr	x1, [x1, #16]
    5f64:	b4000501 	cbz	x1, 6004 <fwp_main_thread+0x1400>
    5f68:	f9400022 	ldr	x2, [x1]
    5f6c:	eb13005f 	cmp	x2, x19
    5f70:	54ffff61 	b.ne	5f5c <fwp_main_thread+0x1358>  // b.any
    5f74:	f9400361 	ldr	x1, [x27]
    5f78:	7103f81f 	cmp	w0, #0xfe
    5f7c:	540008a0 	b.eq	6090 <fwp_main_thread+0x148c>  // b.none
    5f80:	b4000461 	cbz	x1, 600c <fwp_main_thread+0x1408>
    5f84:	f9400420 	ldr	x0, [x1, #8]
    5f88:	b100041f 	cmn	x0, #0x1
    5f8c:	54000a20 	b.eq	60d0 <fwp_main_thread+0x14cc>  // b.none
    5f90:	91000400 	add	x0, x0, #0x1
    5f94:	f9000420 	str	x0, [x1, #8]
    5f98:	17fffd28 	b	5438 <fwp_main_thread+0x834>
    5f9c:	ca5b4760 	eor	x0, x27, x27, lsr #17
    5fa0:	90000161 	adrp	x1, 31000 <fwp_root_context+0xcd0>
    5fa4:	91144021 	add	x1, x1, #0x510
    5fa8:	ca402400 	eor	x0, x0, x0, lsr #9
    5fac:	8b200c20 	add	x0, x1, w0, uxtb #3
    5fb0:	f94a2400 	ldr	x0, [x0, #5192]
    5fb4:	b5000080 	cbnz	x0, 5fc4 <fwp_main_thread+0x13c0>
    5fb8:	14000015 	b	600c <fwp_main_thread+0x1408>
    5fbc:	f9400800 	ldr	x0, [x0, #16]
    5fc0:	b4000260 	cbz	x0, 600c <fwp_main_thread+0x1408>
    5fc4:	f9400001 	ldr	x1, [x0]
    5fc8:	eb01037f 	cmp	x27, x1
    5fcc:	54ffff81 	b.ne	5fbc <fwp_main_thread+0x13b8>  // b.any
    5fd0:	f9400401 	ldr	x1, [x0, #8]
    5fd4:	d1000421 	sub	x1, x1, #0x1
    5fd8:	f9000401 	str	x1, [x0, #8]
    5fdc:	f103f83f 	cmp	x1, #0xfe
    5fe0:	54ffd941 	b.ne	5b08 <fwp_main_thread+0xf04>  // b.any
    5fe4:	aa1b03e0 	mov	x0, x27
    5fe8:	97fff2ef 	bl	2ba4 <fwp_rc_forget_slot>
    5fec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ff0:	39000360 	strb	w0, [x27]
    5ff4:	17fffec5 	b	5b08 <fwp_main_thread+0xf04>
    5ff8:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    5ffc:	912e0000 	add	x0, x0, #0xb80
    6000:	97fff028 	bl	20a0 <fwp_trap>
    6004:	7103f81f 	cmp	w0, #0xfe
    6008:	54000200 	b.eq	6048 <fwp_main_thread+0x1444>  // b.none
    600c:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    6010:	91276000 	add	x0, x0, #0x9d8
    6014:	97fff023 	bl	20a0 <fwp_trap>
    6018:	b902a29f 	str	wzr, [x20, #672]
    601c:	b4ff74a0 	cbz	x0, 4eb0 <fwp_main_thread+0x2ac>
    6020:	17ffffc1 	b	5f24 <fwp_main_thread+0x1320>
    6024:	aa1a03e0 	mov	x0, x26
    6028:	97fff2df 	bl	2ba4 <fwp_rc_forget_slot>
    602c:	17fffc90 	b	526c <fwp_main_thread+0x668>
    6030:	aa1803e0 	mov	x0, x24
    6034:	97fff2dc 	bl	2ba4 <fwp_rc_forget_slot>
    6038:	17fffcb1 	b	52fc <fwp_main_thread+0x6f8>
    603c:	aa1303e0 	mov	x0, x19
    6040:	97fff2d9 	bl	2ba4 <fwp_rc_forget_slot>
    6044:	17fffcd4 	b	5394 <fwp_main_thread+0x790>
    6048:	d2800300 	mov	x0, #0x18                  	// #24
    604c:	97ffecfd 	bl	1440 <malloc@plt>
    6050:	b40003e0 	cbz	x0, 60cc <fwp_main_thread+0x14c8>
    6054:	d2801fe1 	mov	x1, #0xff                  	// #255
    6058:	a9000413 	stp	x19, x1, [x0]
    605c:	f0000141 	adrp	x1, 31000 <fwp_root_context+0xcd0>
    6060:	f900081f 	str	xzr, [x0, #16]
    6064:	91144021 	add	x1, x1, #0x510
    6068:	f9000360 	str	x0, [x27]
    606c:	12800002 	mov	w2, #0xffffffff            	// #-1
    6070:	39000262 	strb	w2, [x19]
    6074:	f94e2420 	ldr	x0, [x1, #7240]
    6078:	91000400 	add	x0, x0, #0x1
    607c:	f90e2420 	str	x0, [x1, #7240]
    6080:	17fffcee 	b	5438 <fwp_main_thread+0x834>
    6084:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    6088:	91280000 	add	x0, x0, #0xa00
    608c:	97fff005 	bl	20a0 <fwp_trap>
    6090:	b4fffdc1 	cbz	x1, 6048 <fwp_main_thread+0x1444>
    6094:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    6098:	912ce000 	add	x0, x0, #0xb38
    609c:	97fff001 	bl	20a0 <fwp_trap>
    60a0:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    60a4:	912ea000 	add	x0, x0, #0xba8
    60a8:	97ffeffe 	bl	20a0 <fwp_trap>
    60ac:	a9156bf9 	stp	x25, x26, [sp, #336]
    60b0:	6d1727e8 	stp	d8, d9, [sp, #368]
    60b4:	97ffecfb 	bl	14a0 <__stack_chk_fail@plt>
    60b8:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    60bc:	912c4000 	add	x0, x0, #0xb10
    60c0:	a9156bf9 	stp	x25, x26, [sp, #336]
    60c4:	6d1727e8 	stp	d8, d9, [sp, #368]
    60c8:	97ffeff6 	bl	20a0 <fwp_trap>
    60cc:	97ffeeb1 	bl	1b90 <fwp_heap_oom>
    60d0:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x13fc>
    60d4:	912d8000 	add	x0, x0, #0xb60
    60d8:	97ffeff2 	bl	20a0 <fwp_trap>
    60dc:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    60e0:	17ffffa6 	b	5f78 <fwp_main_thread+0x1374>
    60e4:	d503201f 	nop
    60e8:	d503201f 	nop
    60ec:	d503201f 	nop

00000000000060f0 <__divti3>:
    60f0:	d503245f 	bti	c
    60f4:	d2800004 	mov	x4, #0x0                   	// #0
    60f8:	b7f80721 	tbnz	x1, #63, 61dc <__divti3+0xec>
    60fc:	b6f80083 	tbz	x3, #63, 610c <__divti3+0x1c>
    6100:	eb0203e2 	negs	x2, x2
    6104:	aa2403e4 	mvn	x4, x4
    6108:	da0303e3 	ngc	x3, x3
    610c:	aa0203e6 	mov	x6, x2
    6110:	aa0003e7 	mov	x7, x0
    6114:	aa0103e5 	mov	x5, x1
    6118:	b5000583 	cbnz	x3, 61c8 <__divti3+0xd8>
    611c:	eb01005f 	cmp	x2, x1
    6120:	54000e69 	b.ls	62ec <__divti3+0x1fc>  // b.plast
    6124:	dac01040 	clz	x0, x2
    6128:	b40000e0 	cbz	x0, 6144 <__divti3+0x54>
    612c:	4b0003e1 	neg	w1, w0
    6130:	9ac020a5 	lsl	x5, x5, x0
    6134:	9ac02046 	lsl	x6, x2, x0
    6138:	9ac124e1 	lsr	x1, x7, x1
    613c:	aa050025 	orr	x5, x1, x5
    6140:	9ac020e7 	lsl	x7, x7, x0
    6144:	d360fcc8 	lsr	x8, x6, #32
    6148:	92407cc2 	and	x2, x6, #0xffffffff
    614c:	9ac808a3 	udiv	x3, x5, x8
    6150:	9b089465 	msub	x5, x3, x8, x5
    6154:	aa0303e0 	mov	x0, x3
    6158:	9b037c41 	mul	x1, x2, x3
    615c:	93c780a5 	extr	x5, x5, x7, #32
    6160:	eb05003f 	cmp	x1, x5
    6164:	540000a9 	b.ls	6178 <__divti3+0x88>  // b.plast
    6168:	ab0500c5 	adds	x5, x6, x5
    616c:	d1000460 	sub	x0, x3, #0x1
    6170:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    6174:	540015a8 	b.hi	6428 <__divti3+0x338>  // b.pmore
    6178:	cb0100a5 	sub	x5, x5, x1
    617c:	9ac808a3 	udiv	x3, x5, x8
    6180:	9b089465 	msub	x5, x3, x8, x5
    6184:	aa0303e1 	mov	x1, x3
    6188:	9b037c42 	mul	x2, x2, x3
    618c:	aa0703e3 	mov	x3, x7
    6190:	b3607ca3 	bfi	x3, x5, #32, #32
    6194:	eb03005f 	cmp	x2, x3
    6198:	540000c9 	b.ls	61b0 <__divti3+0xc0>  // b.plast
    619c:	ab0300c3 	adds	x3, x6, x3
    61a0:	d1000425 	sub	x5, x1, #0x1
    61a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    61a8:	d1000821 	sub	x1, x1, #0x2
    61ac:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    61b0:	aa008020 	orr	x0, x1, x0, lsl #32
    61b4:	d2800001 	mov	x1, #0x0                   	// #0
    61b8:	b4000064 	cbz	x4, 61c4 <__divti3+0xd4>
    61bc:	eb0003e0 	negs	x0, x0
    61c0:	da0103e1 	ngc	x1, x1
    61c4:	d65f03c0 	ret
    61c8:	eb01007f 	cmp	x3, x1
    61cc:	54000109 	b.ls	61ec <__divti3+0xfc>  // b.plast
    61d0:	d2800001 	mov	x1, #0x0                   	// #0
    61d4:	d2800000 	mov	x0, #0x0                   	// #0
    61d8:	17fffff8 	b	61b8 <__divti3+0xc8>
    61dc:	eb0003e0 	negs	x0, x0
    61e0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    61e4:	da0103e1 	ngc	x1, x1
    61e8:	17ffffc5 	b	60fc <__divti3+0xc>
    61ec:	dac01067 	clz	x7, x3
    61f0:	b40010e7 	cbz	x7, 640c <__divti3+0x31c>
    61f4:	d2800805 	mov	x5, #0x40                  	// #64
    61f8:	cb0700a5 	sub	x5, x5, x7
    61fc:	9ac72063 	lsl	x3, x3, x7
    6200:	9ac52448 	lsr	x8, x2, x5
    6204:	aa030108 	orr	x8, x8, x3
    6208:	9ac52426 	lsr	x6, x1, x5
    620c:	92407d0a 	and	x10, x8, #0xffffffff
    6210:	d360fd09 	lsr	x9, x8, #32
    6214:	9ac52403 	lsr	x3, x0, x5
    6218:	9ac72021 	lsl	x1, x1, x7
    621c:	aa010063 	orr	x3, x3, x1
    6220:	9ac72042 	lsl	x2, x2, x7
    6224:	9ac908cb 	udiv	x11, x6, x9
    6228:	9b099965 	msub	x5, x11, x9, x6
    622c:	aa0b03e1 	mov	x1, x11
    6230:	9b0b7d46 	mul	x6, x10, x11
    6234:	93c380a5 	extr	x5, x5, x3, #32
    6238:	eb0500df 	cmp	x6, x5
    623c:	540000a9 	b.ls	6250 <__divti3+0x160>  // b.plast
    6240:	ab050105 	adds	x5, x8, x5
    6244:	d1000561 	sub	x1, x11, #0x1
    6248:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    624c:	54000f48 	b.hi	6434 <__divti3+0x344>  // b.pmore
    6250:	cb0600a6 	sub	x6, x5, x6
    6254:	9ac908cb 	udiv	x11, x6, x9
    6258:	9b099969 	msub	x9, x11, x9, x6
    625c:	aa0b03e5 	mov	x5, x11
    6260:	9b0b7d4a 	mul	x10, x10, x11
    6264:	b3607d23 	bfi	x3, x9, #32, #32
    6268:	eb03015f 	cmp	x10, x3
    626c:	540000a9 	b.ls	6280 <__divti3+0x190>  // b.plast
    6270:	ab030103 	adds	x3, x8, x3
    6274:	d1000565 	sub	x5, x11, #0x1
    6278:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    627c:	54000e28 	b.hi	6440 <__divti3+0x350>  // b.pmore
    6280:	aa0180a1 	orr	x1, x5, x1, lsl #32
    6284:	92407c48 	and	x8, x2, #0xffffffff
    6288:	2a0503e5 	mov	w5, w5
    628c:	d360fc42 	lsr	x2, x2, #32
    6290:	d360fc26 	lsr	x6, x1, #32
    6294:	cb0a0063 	sub	x3, x3, x10
    6298:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    629c:	9b087caa 	mul	x10, x5, x8
    62a0:	9b087cc8 	mul	x8, x6, x8
    62a4:	9b0220a5 	madd	x5, x5, x2, x8
    62a8:	9b027cc6 	mul	x6, x6, x2
    62ac:	8b4a80a2 	add	x2, x5, x10, lsr #32
    62b0:	8b0900c5 	add	x5, x6, x9
    62b4:	eb02011f 	cmp	x8, x2
    62b8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    62bc:	8b4280c6 	add	x6, x6, x2, lsr #32
    62c0:	eb06007f 	cmp	x3, x6
    62c4:	540000e3 	b.cc	62e0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    62c8:	92407d4a 	and	x10, x10, #0xffffffff
    62cc:	9ac72000 	lsl	x0, x0, x7
    62d0:	8b028142 	add	x2, x10, x2, lsl #32
    62d4:	eb02001f 	cmp	x0, x2
    62d8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    62dc:	54000a01 	b.ne	641c <__divti3+0x32c>  // b.any
    62e0:	d1000420 	sub	x0, x1, #0x1
    62e4:	d2800001 	mov	x1, #0x0                   	// #0
    62e8:	17ffffb4 	b	61b8 <__divti3+0xc8>
    62ec:	b5000062 	cbnz	x2, 62f8 <__divti3+0x208>
    62f0:	d2800022 	mov	x2, #0x1                   	// #1
    62f4:	9ac30846 	udiv	x6, x2, x3
    62f8:	dac010c8 	clz	x8, x6
    62fc:	b5000408 	cbnz	x8, 637c <__divti3+0x28c>
    6300:	d360fcc9 	lsr	x9, x6, #32
    6304:	92407cc5 	and	x5, x6, #0xffffffff
    6308:	cb060023 	sub	x3, x1, x6
    630c:	d2800021 	mov	x1, #0x1                   	// #1
    6310:	9ac90868 	udiv	x8, x3, x9
    6314:	9b098d03 	msub	x3, x8, x9, x3
    6318:	aa0803e0 	mov	x0, x8
    631c:	9b057d02 	mul	x2, x8, x5
    6320:	93c78063 	extr	x3, x3, x7, #32
    6324:	eb03005f 	cmp	x2, x3
    6328:	540000a9 	b.ls	633c <__divti3+0x24c>  // b.plast
    632c:	ab0300c3 	adds	x3, x6, x3
    6330:	d1000500 	sub	x0, x8, #0x1
    6334:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    6338:	54000968 	b.hi	6464 <__divti3+0x374>  // b.pmore
    633c:	cb020063 	sub	x3, x3, x2
    6340:	9ac90862 	udiv	x2, x3, x9
    6344:	aa0203e8 	mov	x8, x2
    6348:	9b098c42 	msub	x2, x2, x9, x3
    634c:	aa0703e3 	mov	x3, x7
    6350:	9b057d05 	mul	x5, x8, x5
    6354:	b3607c43 	bfi	x3, x2, #32, #32
    6358:	eb0300bf 	cmp	x5, x3
    635c:	540000c9 	b.ls	6374 <__divti3+0x284>  // b.plast
    6360:	ab0300c2 	adds	x2, x6, x3
    6364:	d1000503 	sub	x3, x8, #0x1
    6368:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    636c:	d1000908 	sub	x8, x8, #0x2
    6370:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    6374:	aa008100 	orr	x0, x8, x0, lsl #32
    6378:	17ffff90 	b	61b8 <__divti3+0xc8>
    637c:	9ac820c6 	lsl	x6, x6, x8
    6380:	d2800803 	mov	x3, #0x40                  	// #64
    6384:	cb080063 	sub	x3, x3, x8
    6388:	d360fcc9 	lsr	x9, x6, #32
    638c:	9ac82027 	lsl	x7, x1, x8
    6390:	92407cc5 	and	x5, x6, #0xffffffff
    6394:	9ac32422 	lsr	x2, x1, x3
    6398:	9ac32403 	lsr	x3, x0, x3
    639c:	aa070063 	orr	x3, x3, x7
    63a0:	9ac9084a 	udiv	x10, x2, x9
    63a4:	9ac82007 	lsl	x7, x0, x8
    63a8:	9b098940 	msub	x0, x10, x9, x2
    63ac:	aa0a03e1 	mov	x1, x10
    63b0:	9b0a7ca2 	mul	x2, x5, x10
    63b4:	93c38000 	extr	x0, x0, x3, #32
    63b8:	eb00005f 	cmp	x2, x0
    63bc:	540000a9 	b.ls	63d0 <__divti3+0x2e0>  // b.plast
    63c0:	ab0000c0 	adds	x0, x6, x0
    63c4:	d1000541 	sub	x1, x10, #0x1
    63c8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    63cc:	54000468 	b.hi	6458 <__divti3+0x368>  // b.pmore
    63d0:	cb020000 	sub	x0, x0, x2
    63d4:	9ac9080a 	udiv	x10, x0, x9
    63d8:	9b098140 	msub	x0, x10, x9, x0
    63dc:	aa0a03e2 	mov	x2, x10
    63e0:	9b0a7ca8 	mul	x8, x5, x10
    63e4:	b3607c03 	bfi	x3, x0, #32, #32
    63e8:	eb03011f 	cmp	x8, x3
    63ec:	540000a9 	b.ls	6400 <__divti3+0x310>  // b.plast
    63f0:	ab0300c3 	adds	x3, x6, x3
    63f4:	d1000542 	sub	x2, x10, #0x1
    63f8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    63fc:	54000288 	b.hi	644c <__divti3+0x35c>  // b.pmore
    6400:	cb080063 	sub	x3, x3, x8
    6404:	aa018041 	orr	x1, x2, x1, lsl #32
    6408:	17ffffc2 	b	6310 <__divti3+0x220>
    640c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    6410:	d2800001 	mov	x1, #0x0                   	// #0
    6414:	9a9f87e0 	cset	x0, ls	// ls = plast
    6418:	17ffff68 	b	61b8 <__divti3+0xc8>
    641c:	aa0103e0 	mov	x0, x1
    6420:	d2800001 	mov	x1, #0x0                   	// #0
    6424:	17ffff65 	b	61b8 <__divti3+0xc8>
    6428:	d1000860 	sub	x0, x3, #0x2
    642c:	8b0600a5 	add	x5, x5, x6
    6430:	17ffff52 	b	6178 <__divti3+0x88>
    6434:	d1000961 	sub	x1, x11, #0x2
    6438:	8b0800a5 	add	x5, x5, x8
    643c:	17ffff85 	b	6250 <__divti3+0x160>
    6440:	d1000965 	sub	x5, x11, #0x2
    6444:	8b080063 	add	x3, x3, x8
    6448:	17ffff8e 	b	6280 <__divti3+0x190>
    644c:	d1000942 	sub	x2, x10, #0x2
    6450:	8b060063 	add	x3, x3, x6
    6454:	17ffffeb 	b	6400 <__divti3+0x310>
    6458:	d1000941 	sub	x1, x10, #0x2
    645c:	8b060000 	add	x0, x0, x6
    6460:	17ffffdc 	b	63d0 <__divti3+0x2e0>
    6464:	d1000900 	sub	x0, x8, #0x2
    6468:	8b060063 	add	x3, x3, x6
    646c:	17ffffb4 	b	633c <__divti3+0x24c>

0000000000006470 <__modti3>:
    6470:	d503245f 	bti	c
    6474:	d2800004 	mov	x4, #0x0                   	// #0
    6478:	b6f80081 	tbz	x1, #63, 6488 <__modti3+0x18>
    647c:	eb0003e0 	negs	x0, x0
    6480:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    6484:	da0103e1 	ngc	x1, x1
    6488:	f100007f 	cmp	x3, #0x0
    648c:	5400128b 	b.lt	66dc <__modti3+0x26c>  // b.tstop
    6490:	aa0003e7 	mov	x7, x0
    6494:	aa0103e6 	mov	x6, x1
    6498:	540004e1 	b.ne	6534 <__modti3+0xc4>  // b.any
    649c:	eb02003f 	cmp	x1, x2
    64a0:	54000dc2 	b.cs	6658 <__modti3+0x1e8>  // b.hs, b.nlast
    64a4:	dac01043 	clz	x3, x2
    64a8:	aa0303e5 	mov	x5, x3
    64ac:	b40000e3 	cbz	x3, 64c8 <__modti3+0x58>
    64b0:	4b0303e6 	neg	w6, w3
    64b4:	9ac32021 	lsl	x1, x1, x3
    64b8:	9ac32042 	lsl	x2, x2, x3
    64bc:	9ac62406 	lsr	x6, x0, x6
    64c0:	aa0100c6 	orr	x6, x6, x1
    64c4:	9ac32007 	lsl	x7, x0, x3
    64c8:	d360fc40 	lsr	x0, x2, #32
    64cc:	92407c43 	and	x3, x2, #0xffffffff
    64d0:	9ac008c1 	udiv	x1, x6, x0
    64d4:	9b009826 	msub	x6, x1, x0, x6
    64d8:	9b017c61 	mul	x1, x3, x1
    64dc:	93c780c6 	extr	x6, x6, x7, #32
    64e0:	eb06003f 	cmp	x1, x6
    64e4:	540000a9 	b.ls	64f8 <__modti3+0x88>  // b.plast
    64e8:	ab060046 	adds	x6, x2, x6
    64ec:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    64f0:	8b0200c8 	add	x8, x6, x2
    64f4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    64f8:	cb0100c6 	sub	x6, x6, x1
    64fc:	9ac008c8 	udiv	x8, x6, x0
    6500:	9b009901 	msub	x1, x8, x0, x6
    6504:	aa0703e0 	mov	x0, x7
    6508:	9b087c63 	mul	x3, x3, x8
    650c:	b3607c20 	bfi	x0, x1, #32, #32
    6510:	eb00007f 	cmp	x3, x0
    6514:	54001088 	b.hi	6724 <__modti3+0x2b4>  // b.pmore
    6518:	cb030000 	sub	x0, x0, x3
    651c:	9ac52400 	lsr	x0, x0, x5
    6520:	d2800001 	mov	x1, #0x0                   	// #0
    6524:	b4000064 	cbz	x4, 6530 <__modti3+0xc0>
    6528:	eb0003e0 	negs	x0, x0
    652c:	da0103e1 	ngc	x1, x1
    6530:	d65f03c0 	ret
    6534:	dac01066 	clz	x6, x3
    6538:	eb03003f 	cmp	x1, x3
    653c:	54ffff43 	b.cc	6524 <__modti3+0xb4>  // b.lo, b.ul, b.last
    6540:	93407cc5 	sxtw	x5, w6
    6544:	d2800808 	mov	x8, #0x40                  	// #64
    6548:	cb050108 	sub	x8, x8, x5
    654c:	9ac62063 	lsl	x3, x3, x6
    6550:	9ac62025 	lsl	x5, x1, x6
    6554:	9ac82447 	lsr	x7, x2, x8
    6558:	aa0300e7 	orr	x7, x7, x3
    655c:	9ac82423 	lsr	x3, x1, x8
    6560:	92407cec 	and	x12, x7, #0xffffffff
    6564:	d360fcea 	lsr	x10, x7, #32
    6568:	9ac82401 	lsr	x1, x0, x8
    656c:	aa050021 	orr	x1, x1, x5
    6570:	9ac62042 	lsl	x2, x2, x6
    6574:	9ac62000 	lsl	x0, x0, x6
    6578:	9aca086b 	udiv	x11, x3, x10
    657c:	9b0a8d63 	msub	x3, x11, x10, x3
    6580:	aa0b03e5 	mov	x5, x11
    6584:	9b0b7d89 	mul	x9, x12, x11
    6588:	93c18063 	extr	x3, x3, x1, #32
    658c:	eb03013f 	cmp	x9, x3
    6590:	540000a9 	b.ls	65a4 <__modti3+0x134>  // b.plast
    6594:	ab0300e3 	adds	x3, x7, x3
    6598:	d1000565 	sub	x5, x11, #0x1
    659c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    65a0:	54001168 	b.hi	67cc <__modti3+0x35c>  // b.pmore
    65a4:	cb090063 	sub	x3, x3, x9
    65a8:	9aca086b 	udiv	x11, x3, x10
    65ac:	9b0a8d6a 	msub	x10, x11, x10, x3
    65b0:	aa0b03e9 	mov	x9, x11
    65b4:	9b0b7d8c 	mul	x12, x12, x11
    65b8:	b3607d41 	bfi	x1, x10, #32, #32
    65bc:	eb01019f 	cmp	x12, x1
    65c0:	540000a9 	b.ls	65d4 <__modti3+0x164>  // b.plast
    65c4:	ab0100e1 	adds	x1, x7, x1
    65c8:	d1000569 	sub	x9, x11, #0x1
    65cc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    65d0:	54000f88 	b.hi	67c0 <__modti3+0x350>  // b.pmore
    65d4:	aa058123 	orr	x3, x9, x5, lsl #32
    65d8:	92407c4b 	and	x11, x2, #0xffffffff
    65dc:	2a0903e9 	mov	w9, w9
    65e0:	d360fc4a 	lsr	x10, x2, #32
    65e4:	d360fc63 	lsr	x3, x3, #32
    65e8:	cb0c0021 	sub	x1, x1, x12
    65ec:	aa0a03ec 	mov	x12, x10
    65f0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    65f4:	9b0b7d25 	mul	x5, x9, x11
    65f8:	9b0b7c6b 	mul	x11, x3, x11
    65fc:	9b0a2d29 	madd	x9, x9, x10, x11
    6600:	92407caa 	and	x10, x5, #0xffffffff
    6604:	9b0c7c63 	mul	x3, x3, x12
    6608:	8b458125 	add	x5, x9, x5, lsr #32
    660c:	8b0d0069 	add	x9, x3, x13
    6610:	eb05017f 	cmp	x11, x5
    6614:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    6618:	8b058149 	add	x9, x10, x5, lsl #32
    661c:	8b458063 	add	x3, x3, x5, lsr #32
    6620:	eb03003f 	cmp	x1, x3
    6624:	54000063 	b.cc	6630 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    6628:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    662c:	54000082 	b.cs	663c <__modti3+0x1cc>  // b.hs, b.nlast
    6630:	eb020129 	subs	x9, x9, x2
    6634:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    6638:	cb070063 	sub	x3, x3, x7
    663c:	eb090000 	subs	x0, x0, x9
    6640:	da030021 	sbc	x1, x1, x3
    6644:	9ac62400 	lsr	x0, x0, x6
    6648:	9ac82028 	lsl	x8, x1, x8
    664c:	aa000100 	orr	x0, x8, x0
    6650:	9ac62421 	lsr	x1, x1, x6
    6654:	17ffffb4 	b	6524 <__modti3+0xb4>
    6658:	b5000062 	cbnz	x2, 6664 <__modti3+0x1f4>
    665c:	d2800023 	mov	x3, #0x1                   	// #1
    6660:	9ac20862 	udiv	x2, x3, x2
    6664:	dac01048 	clz	x8, x2
    6668:	aa0803e5 	mov	x5, x8
    666c:	b5000668 	cbnz	x8, 6738 <__modti3+0x2c8>
    6670:	cb020020 	sub	x0, x1, x2
    6674:	d360fc49 	lsr	x9, x2, #32
    6678:	92407c4a 	and	x10, x2, #0xffffffff
    667c:	9ac90801 	udiv	x1, x0, x9
    6680:	9b098020 	msub	x0, x1, x9, x0
    6684:	9b0a7c21 	mul	x1, x1, x10
    6688:	93c78000 	extr	x0, x0, x7, #32
    668c:	eb00003f 	cmp	x1, x0
    6690:	540000a9 	b.ls	66a4 <__modti3+0x234>  // b.plast
    6694:	ab000040 	adds	x0, x2, x0
    6698:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    669c:	8b020003 	add	x3, x0, x2
    66a0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    66a4:	cb010001 	sub	x1, x0, x1
    66a8:	9ac90820 	udiv	x0, x1, x9
    66ac:	9b098403 	msub	x3, x0, x9, x1
    66b0:	aa0703e1 	mov	x1, x7
    66b4:	9b0a7c00 	mul	x0, x0, x10
    66b8:	b3607c61 	bfi	x1, x3, #32, #32
    66bc:	eb01001f 	cmp	x0, x1
    66c0:	540000a9 	b.ls	66d4 <__modti3+0x264>  // b.plast
    66c4:	ab010041 	adds	x1, x2, x1
    66c8:	8b020022 	add	x2, x1, x2
    66cc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    66d0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    66d4:	cb000020 	sub	x0, x1, x0
    66d8:	17ffff91 	b	651c <__modti3+0xac>
    66dc:	eb0203e5 	negs	x5, x2
    66e0:	aa0003e7 	mov	x7, x0
    66e4:	da0303e8 	ngc	x8, x3
    66e8:	aa0503e2 	mov	x2, x5
    66ec:	aa0803e3 	mov	x3, x8
    66f0:	aa0103e6 	mov	x6, x1
    66f4:	b4ffed48 	cbz	x8, 649c <__modti3+0x2c>
    66f8:	eb01011f 	cmp	x8, x1
    66fc:	54fff148 	b.hi	6524 <__modti3+0xb4>  // b.pmore
    6700:	dac01109 	clz	x9, x8
    6704:	2a0903e6 	mov	w6, w9
    6708:	b5fff1c9 	cbnz	x9, 6540 <__modti3+0xd0>
    670c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    6710:	54000068 	b.hi	671c <__modti3+0x2ac>  // b.pmore
    6714:	eb050007 	subs	x7, x0, x5
    6718:	da080021 	sbc	x1, x1, x8
    671c:	aa0703e0 	mov	x0, x7
    6720:	17ffff81 	b	6524 <__modti3+0xb4>
    6724:	ab000040 	adds	x0, x2, x0
    6728:	8b020002 	add	x2, x0, x2
    672c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    6730:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    6734:	17ffff79 	b	6518 <__modti3+0xa8>
    6738:	9ac82042 	lsl	x2, x2, x8
    673c:	d2800803 	mov	x3, #0x40                  	// #64
    6740:	cb080063 	sub	x3, x3, x8
    6744:	d360fc49 	lsr	x9, x2, #32
    6748:	9ac82027 	lsl	x7, x1, x8
    674c:	92407c4a 	and	x10, x2, #0xffffffff
    6750:	9ac32426 	lsr	x6, x1, x3
    6754:	9ac32403 	lsr	x3, x0, x3
    6758:	aa070063 	orr	x3, x3, x7
    675c:	9ac908c1 	udiv	x1, x6, x9
    6760:	9ac82007 	lsl	x7, x0, x8
    6764:	9b099820 	msub	x0, x1, x9, x6
    6768:	9b017d41 	mul	x1, x10, x1
    676c:	93c38000 	extr	x0, x0, x3, #32
    6770:	eb00003f 	cmp	x1, x0
    6774:	540000a9 	b.ls	6788 <__modti3+0x318>  // b.plast
    6778:	ab000040 	adds	x0, x2, x0
    677c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    6780:	8b020006 	add	x6, x0, x2
    6784:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    6788:	cb010000 	sub	x0, x0, x1
    678c:	9ac90801 	udiv	x1, x0, x9
    6790:	9b098026 	msub	x6, x1, x9, x0
    6794:	aa0303e0 	mov	x0, x3
    6798:	9b017d41 	mul	x1, x10, x1
    679c:	b3607cc0 	bfi	x0, x6, #32, #32
    67a0:	eb00003f 	cmp	x1, x0
    67a4:	540000a9 	b.ls	67b8 <__modti3+0x348>  // b.plast
    67a8:	ab000040 	adds	x0, x2, x0
    67ac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    67b0:	8b020003 	add	x3, x0, x2
    67b4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    67b8:	cb010000 	sub	x0, x0, x1
    67bc:	17ffffb0 	b	667c <__modti3+0x20c>
    67c0:	d1000969 	sub	x9, x11, #0x2
    67c4:	8b070021 	add	x1, x1, x7
    67c8:	17ffff83 	b	65d4 <__modti3+0x164>
    67cc:	d1000965 	sub	x5, x11, #0x2
    67d0:	8b070063 	add	x3, x3, x7
    67d4:	17ffff74 	b	65a4 <__modti3+0x134>
    67d8:	d503201f 	nop
    67dc:	d503201f 	nop

00000000000067e0 <atexit>:
    67e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    67e4:	d00000c2 	adrp	x2, 20000 <__data_start>
    67e8:	d2800001 	mov	x1, #0x0                   	// #0
    67ec:	910003fd 	mov	x29, sp
    67f0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    67f4:	f9400442 	ldr	x2, [x2, #8]
    67f8:	17ffeaea 	b	13a0 <__cxa_atexit@plt>

Disassembly of section .fini:

00000000000067fc <_fini>:
    67fc:	d503201f 	nop
    6800:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    6804:	910003fd 	mov	x29, sp
    6808:	a8c17bfd 	ldp	x29, x30, [sp], #16
    680c:	d65f03c0 	ret
