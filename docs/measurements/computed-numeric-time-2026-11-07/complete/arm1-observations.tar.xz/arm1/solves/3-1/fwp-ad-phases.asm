
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1/fwp-ad-phases:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b0 <_init>:
    26b0:	d503201f 	nop
    26b4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26b8:	910003fd 	mov	x29, sp
    26bc:	9400019e 	bl	2d34 <call_weak_fn>
    26c0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26c4:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26d8:	f946fe11 	ldr	x17, [x16, #3576]
    26dc:	9137e210 	add	x16, x16, #0xdf8
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <_exit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <strlen@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <__sprintf_chk@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <exit@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <__libc_start_main@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtoll@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <strtod@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_finalize@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_atexit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_init@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <fputc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <clock_gettime@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <setvbuf@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <__memcpy_chk@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <signal@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <__snprintf_chk@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fclose@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <fopen@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <malloc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <pthread_attr_destroy@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <sigemptyset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <memset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <calloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <realloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <__stack_chk_fail@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <close@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <sigaction@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <__gmon_start__@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <write@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <abort@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <swapcontext@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <__fprintf_chk@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <strcmp@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <mmap@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtol@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <strtof@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <free@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <nanosleep@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strchr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <strtoull@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <fwrite@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <pthread_create@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <munmap@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <fflush@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <strcpy@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <sysconf@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <strstr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <_Exit@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <pthread_join@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <getenv@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	b0000045 	adrp	x5, b000 <_IO_stdin_used+0x100>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	910a00a5 	add	x5, x5, #0x280
    2aa0:	b0000044 	adrp	x4, b000 <_IO_stdin_used+0x100>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	910a2084 	add	x4, x4, #0x288
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4e 	bl	2800 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400058c 	bl	4100 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc88>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	9101c2a1 	add	x1, x21, #0x70
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10f68>
    2b20:	910de000 	add	x0, x0, #0x378
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9005c20 	str	x0, [x1, #184]
    2b2c:	94000795 	bl	4980 <fwp_now_ns>
    2b30:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x100>
    2b34:	91166000 	add	x0, x0, #0x598
    2b38:	97ffffba 	bl	2a20 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1b 	bl	27c0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff0d 	bl	27d0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff12 	bl	27f0 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97fffefc 	bl	27a0 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000022 	adrp	x2, 8000 <fwp_write+0xa4c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91168042 	add	x2, x2, #0x5a0
    2bdc:	97ffff71 	bl	29a0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff15 	bl	2840 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff84 	bl	2a10 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9101c2b5 	add	x21, x21, #0x70
    2c10:	97ffff6c 	bl	29c0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9434aa0 	ldr	w0, [x21, #840]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x100>
    2c4c:	91172000 	add	x0, x0, #0x5c8
    2c50:	9400052c 	bl	4100 <fwp_trap>
    2c54:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x100>
    2c58:	9116a000 	add	x0, x0, #0x5a8
    2c5c:	94000529 	bl	4100 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff46 	bl	2980 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffeeb 	bl	2840 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x100>
    2ca0:	91188000 	add	x0, x0, #0x620
    2ca4:	94000517 	bl	4100 <fwp_trap>
    2ca8:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x100>
    2cac:	9117c000 	add	x0, x0, #0x5f0
    2cb0:	94000514 	bl	4100 <fwp_trap>
    2cb4:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x100>
    2cb8:	91192000 	add	x0, x0, #0x648
    2cbc:	94000511 	bl	4100 <fwp_trap>
    2cc0:	97fffef4 	bl	2890 <__stack_chk_fail@plt>
    2cc4:	97ffff07 	bl	28e0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe89 	bl	2750 <__libc_start_main@plt>
    2d30:	97fffeec 	bl	28e0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee0 	b	28c0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91016000 	add	x0, x0, #0x58
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91016021 	add	x1, x1, #0x58
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91016000 	add	x0, x0, #0x58
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91016021 	add	x1, x1, #0x58
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39418260 	ldrb	w0, [x19, #96]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe64 	bl	2780 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39018260 	strb	w0, [x19, #96]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x100>
    2eb4:	91334021 	add	x1, x1, #0xcd0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe51 	bl	2890 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402003 	ldr	x3, [x0, #64]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	29490402 	ldp	w2, w1, [x0, #72]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800b03 	mov	w3, #0x58                  	// #88
    2fa8:	f9403884 	ldr	x4, [x4, #112]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9004c61 	str	w1, [x3, #76]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800b04 	mov	w4, #0x58                  	// #88
    2fc0:	f9403863 	ldr	x3, [x3, #112]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9004822 	str	w2, [x1, #72]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900201f 	str	xzr, [x0, #64]
    2fd4:	fd002400 	str	d0, [x0, #72]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9403c00 	ldr	x0, [x0, #120]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6f 	bl	29c0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe6a 	b	29c0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe66 	b	29c0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1a60>
    3050:	913c2000 	add	x0, x0, #0xf08
    3054:	97fffe4f 	bl	2990 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe59 	bl	29c0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe67 	bl	2a00 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9101c043 	add	x3, x2, #0x70
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4f 	bl	29e0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc4 	b	27f0 <signal@plt>
    30e4:	9101c042 	add	x2, x2, #0x70
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x100>
    3118:	9132c021 	add	x1, x1, #0xcb0
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffdeb 	bl	28d0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd79 	bl	2710 <_exit@plt>

0000000000003130 <descent_phase_fail>:
    3130:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    3134:	f947e863 	ldr	x3, [x3, #4048]
    3138:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    313c:	d2800822 	mov	x2, #0x41                  	// #65
    3140:	910003fd 	mov	x29, sp
    3144:	f9400063 	ldr	x3, [x3]
    3148:	d2800021 	mov	x1, #0x1                   	// #1
    314c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1a60>
    3150:	913c8000 	add	x0, x0, #0xf20
    3154:	97fffe0f 	bl	2990 <fwrite@plt>
    3158:	52801d20 	mov	w0, #0xe9                  	// #233
    315c:	97fffe29 	bl	2a00 <_Exit@plt>

0000000000003160 <descent_phase_report>:
    3160:	d10243ff 	sub	sp, sp, #0x90
    3164:	b00000e1 	adrp	x1, 20000 <__data_start>
    3168:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    316c:	f947f400 	ldr	x0, [x0, #4072]
    3170:	91004023 	add	x3, x1, #0x10
    3174:	a9047bfd 	stp	x29, x30, [sp, #64]
    3178:	910103fd 	add	x29, sp, #0x40
    317c:	b9401021 	ldr	w1, [x1, #16]
    3180:	a90553f3 	stp	x19, x20, [sp, #80]
    3184:	a9065bf5 	stp	x21, x22, [sp, #96]
    3188:	a90763f7 	stp	x23, x24, [sp, #112]
    318c:	f90043f9 	str	x25, [sp, #128]
    3190:	f9400002 	ldr	x2, [x0]
    3194:	f9001fe2 	str	x2, [sp, #56]
    3198:	d2800002 	mov	x2, #0x0                   	// #0
    319c:	3100043f 	cmn	w1, #0x1
    31a0:	54000841 	b.ne	32a8 <descent_phase_report+0x148>  // b.any
    31a4:	b00000f4 	adrp	x20, 20000 <__data_start>
    31a8:	9101c294 	add	x20, x20, #0x70
    31ac:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc88>
    31b0:	f947eab5 	ldr	x21, [x21, #4048]
    31b4:	91002063 	add	x3, x3, #0x8
    31b8:	a9429285 	ldp	x5, x4, [x20, #40]
    31bc:	910023f7 	add	x23, sp, #0x8
    31c0:	ad400861 	ldp	q1, q2, [x3]
    31c4:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1a60>
    31c8:	f94002a0 	ldr	x0, [x21]
    31cc:	f0000036 	adrp	x22, a000 <fwp_main_thread+0x1a60>
    31d0:	3dc00860 	ldr	q0, [x3, #32]
    31d4:	90000058 	adrp	x24, b000 <_IO_stdin_used+0x100>
    31d8:	f9401e83 	ldr	x3, [x20, #56]
    31dc:	913da042 	add	x2, x2, #0xf68
    31e0:	913f02d6 	add	x22, x22, #0xfc0
    31e4:	91294318 	add	x24, x24, #0xa50
    31e8:	52800041 	mov	w1, #0x2                   	// #2
    31ec:	d2800033 	mov	x19, #0x1                   	// #1
    31f0:	f0000039 	adrp	x25, a000 <fwp_main_thread+0x1a60>
    31f4:	ad000ae1 	stp	q1, q2, [x23]
    31f8:	3d800ae0 	str	q0, [x23, #32]
    31fc:	97fffdc1 	bl	2900 <__fprintf_chk@plt>
    3200:	f94002a0 	ldr	x0, [x21]
    3204:	7100067f 	cmp	w19, #0x1
    3208:	54000400 	b.eq	3288 <descent_phase_report+0x128>  // b.none
    320c:	d37df261 	lsl	x1, x19, #3
    3210:	913ee323 	add	x3, x25, #0xfb8
    3214:	8b010285 	add	x5, x20, x1
    3218:	8b0102e4 	add	x4, x23, x1
    321c:	91000673 	add	x19, x19, #0x1
    3220:	aa1603e2 	mov	x2, x22
    3224:	52800041 	mov	w1, #0x2                   	// #2
    3228:	f85f8084 	ldur	x4, [x4, #-8]
    322c:	f9401ca5 	ldr	x5, [x5, #56]
    3230:	97fffdb4 	bl	2900 <__fprintf_chk@plt>
    3234:	f1001e7f 	cmp	x19, #0x7
    3238:	54fffe41 	b.ne	3200 <descent_phase_report+0xa0>  // b.any
    323c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3240:	f947f400 	ldr	x0, [x0, #4072]
    3244:	f9401fe2 	ldr	x2, [sp, #56]
    3248:	f9400001 	ldr	x1, [x0]
    324c:	eb010042 	subs	x2, x2, x1
    3250:	d2800001 	mov	x1, #0x0                   	// #0
    3254:	540002c1 	b.ne	32ac <descent_phase_report+0x14c>  // b.any
    3258:	f94002a3 	ldr	x3, [x21]
    325c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1a60>
    3260:	a9447bfd 	ldp	x29, x30, [sp, #64]
    3264:	913f4000 	add	x0, x0, #0xfd0
    3268:	a94553f3 	ldp	x19, x20, [sp, #80]
    326c:	d2800082 	mov	x2, #0x4                   	// #4
    3270:	a9465bf5 	ldp	x21, x22, [sp, #96]
    3274:	d2800021 	mov	x1, #0x1                   	// #1
    3278:	a94763f7 	ldp	x23, x24, [sp, #112]
    327c:	f94043f9 	ldr	x25, [sp, #128]
    3280:	910243ff 	add	sp, sp, #0x90
    3284:	17fffdc3 	b	2990 <fwrite@plt>
    3288:	f94007e4 	ldr	x4, [sp, #8]
    328c:	aa1803e3 	mov	x3, x24
    3290:	f9402285 	ldr	x5, [x20, #64]
    3294:	aa1603e2 	mov	x2, x22
    3298:	52800041 	mov	w1, #0x2                   	// #2
    329c:	d2800053 	mov	x19, #0x2                   	// #2
    32a0:	97fffd98 	bl	2900 <__fprintf_chk@plt>
    32a4:	17ffffd7 	b	3200 <descent_phase_report+0xa0>
    32a8:	97ffffa2 	bl	3130 <descent_phase_fail>
    32ac:	97fffd79 	bl	2890 <__stack_chk_fail@plt>

00000000000032b0 <fwp_heap_chunks>:
    32b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32b4:	910003fd 	mov	x29, sp
    32b8:	a90153f3 	stp	x19, x20, [sp, #16]
    32bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    32c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    32c4:	911702a1 	add	x1, x21, #0x5c0
    32c8:	f100041f 	cmp	x0, #0x1
    32cc:	54000ca0 	b.eq	3460 <fwp_heap_chunks+0x1b0>  // b.none
    32d0:	f949f822 	ldr	x2, [x1, #5104]
    32d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa40>
    32d8:	9126c0a5 	add	x5, x5, #0x9b0
    32dc:	911702a1 	add	x1, x21, #0x5c0
    32e0:	f949ec34 	ldr	x20, [x1, #5080]
    32e4:	eb14005f 	cmp	x2, x20
    32e8:	54000c42 	b.cs	3470 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    32ec:	f949fc23 	ldr	x3, [x1, #5112]
    32f0:	8b020841 	add	x1, x2, x2, lsl #2
    32f4:	d2800004 	mov	x4, #0x0                   	// #0
    32f8:	8b010c61 	add	x1, x3, x1, lsl #3
    32fc:	14000009 	b	3320 <fwp_heap_chunks+0x70>
    3300:	91000483 	add	x3, x4, #0x1
    3304:	eb03001f 	cmp	x0, x3
    3308:	54000940 	b.eq	3430 <fwp_heap_chunks+0x180>  // b.none
    330c:	91000442 	add	x2, x2, #0x1
    3310:	aa0303e4 	mov	x4, x3
    3314:	9100a021 	add	x1, x1, #0x28
    3318:	eb02029f 	cmp	x20, x2
    331c:	54000100 	b.eq	333c <fwp_heap_chunks+0x8c>  // b.none
    3320:	39400023 	ldrb	w3, [x1]
    3324:	34fffee3 	cbz	w3, 3300 <fwp_heap_chunks+0x50>
    3328:	91000442 	add	x2, x2, #0x1
    332c:	9100a021 	add	x1, x1, #0x28
    3330:	d2800004 	mov	x4, #0x0                   	// #0
    3334:	eb02029f 	cmp	x20, x2
    3338:	54ffff41 	b.ne	3320 <fwp_heap_chunks+0x70>  // b.any
    333c:	cb040294 	sub	x20, x20, x4
    3340:	f9001bf7 	str	x23, [sp, #48]
    3344:	911702b7 	add	x23, x21, #0x5c0
    3348:	8b140013 	add	x19, x0, x20
    334c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3350:	f949f2e0 	ldr	x0, [x23, #5088]
    3354:	cb040021 	sub	x1, x1, x4
    3358:	f90a1ae1 	str	x1, [x23, #5168]
    335c:	eb00027f 	cmp	x19, x0
    3360:	54000429 	b.ls	33e4 <fwp_heap_chunks+0x134>  // b.plast
    3364:	f949eae1 	ldr	x1, [x23, #5072]
    3368:	eb01027f 	cmp	x19, x1
    336c:	54000888 	b.hi	347c <fwp_heap_chunks+0x1cc>  // b.pmore
    3370:	91010276 	add	x22, x19, #0x40
    3374:	52800062 	mov	w2, #0x3                   	// #3
    3378:	f949dae3 	ldr	x3, [x23, #5040]
    337c:	eb0102df 	cmp	x22, x1
    3380:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3384:	cb0002c1 	sub	x1, x22, x0
    3388:	8b004060 	add	x0, x3, x0, lsl #16
    338c:	d370bc21 	lsl	x1, x1, #16
    3390:	97fffda8 	bl	2a30 <mprotect@plt>
    3394:	35000740 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    3398:	528003c0 	mov	w0, #0x1e                  	// #30
    339c:	97fffd91 	bl	29e0 <sysconf@plt>
    33a0:	f949f2e2 	ldr	x2, [x23, #5088]
    33a4:	cb0003e5 	neg	x5, x0
    33a8:	aa0003e4 	mov	x4, x0
    33ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    33b0:	f949fee0 	ldr	x0, [x23, #5112]
    33b4:	8b020843 	add	x3, x2, x2, lsl #2
    33b8:	52800062 	mov	w2, #0x3                   	// #3
    33bc:	8b010c01 	add	x1, x0, x1, lsl #3
    33c0:	8b030c03 	add	x3, x0, x3, lsl #3
    33c4:	d1000421 	sub	x1, x1, #0x1
    33c8:	8a050060 	and	x0, x3, x5
    33cc:	8b040021 	add	x1, x1, x4
    33d0:	8a050021 	and	x1, x1, x5
    33d4:	cb000021 	sub	x1, x1, x0
    33d8:	97fffd96 	bl	2a30 <mprotect@plt>
    33dc:	35000500 	cbnz	w0, 347c <fwp_heap_chunks+0x1cc>
    33e0:	f909f2f6 	str	x22, [x23, #5088]
    33e4:	911702b5 	add	x21, x21, #0x5c0
    33e8:	d370be60 	lsl	x0, x19, #16
    33ec:	f949e6a1 	ldr	x1, [x21, #5064]
    33f0:	f909eeb3 	str	x19, [x21, #5080]
    33f4:	eb01001f 	cmp	x0, x1
    33f8:	540000e8 	b.hi	3414 <fwp_heap_chunks+0x164>  // b.pmore
    33fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3400:	aa1403e0 	mov	x0, x20
    3404:	a94153f3 	ldp	x19, x20, [sp, #16]
    3408:	f9401bf7 	ldr	x23, [sp, #48]
    340c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3410:	d65f03c0 	ret
    3414:	f9401bf7 	ldr	x23, [sp, #48]
    3418:	f909e6a0 	str	x0, [x21, #5064]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	aa1403e0 	mov	x0, x20
    3424:	a94153f3 	ldp	x19, x20, [sp, #16]
    3428:	a8c47bfd 	ldp	x29, x30, [sp], #64
    342c:	d65f03c0 	ret
    3430:	911702b5 	add	x21, x21, #0x5c0
    3434:	91000441 	add	x1, x2, #0x1
    3438:	f90000a1 	str	x1, [x5]
    343c:	cb040054 	sub	x20, x2, x4
    3440:	f94a1aa1 	ldr	x1, [x21, #5168]
    3444:	cb000020 	sub	x0, x1, x0
    3448:	f90a1aa0 	str	x0, [x21, #5168]
    344c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3450:	aa1403e0 	mov	x0, x20
    3454:	a94153f3 	ldp	x19, x20, [sp, #16]
    3458:	a8c47bfd 	ldp	x29, x30, [sp], #64
    345c:	d65f03c0 	ret
    3460:	f949f422 	ldr	x2, [x1, #5096]
    3464:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa40>
    3468:	9126a0a5 	add	x5, x5, #0x9a8
    346c:	17ffff9c 	b	32dc <fwp_heap_chunks+0x2c>
    3470:	d2800004 	mov	x4, #0x0                   	// #0
    3474:	f9001bf7 	str	x23, [sp, #48]
    3478:	17ffffb3 	b	3344 <fwp_heap_chunks+0x94>
    347c:	97fffeed 	bl	3030 <fwp_heap_oom>

0000000000003480 <fwp_tape_buffers_dispose>:
    3480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3484:	910003fd 	mov	x29, sp
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	aa0003f3 	mov	x19, x0
    3490:	f9400000 	ldr	x0, [x0]
    3494:	97fffd2f 	bl	2950 <free@plt>
    3498:	f9400660 	ldr	x0, [x19, #8]
    349c:	97fffd2d 	bl	2950 <free@plt>
    34a0:	f9400a60 	ldr	x0, [x19, #16]
    34a4:	97fffd2b 	bl	2950 <free@plt>
    34a8:	a9007e7f 	stp	xzr, xzr, [x19]
    34ac:	a9017e7f 	stp	xzr, xzr, [x19, #16]
    34b0:	f900127f 	str	xzr, [x19, #32]
    34b4:	f9400bf3 	ldr	x19, [sp, #16]
    34b8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34bc:	d65f03c0 	ret

00000000000034c0 <buf_grow>:
    34c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34c4:	910003fd 	mov	x29, sp
    34c8:	a90153f3 	stp	x19, x20, [sp, #16]
    34cc:	aa0003f4 	mov	x20, x0
    34d0:	f9400400 	ldr	x0, [x0, #8]
    34d4:	b100041f 	cmn	x0, #0x1
    34d8:	54000400 	b.eq	3558 <buf_grow+0x98>  // b.none
    34dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    34e0:	cb000042 	sub	x2, x2, x0
    34e4:	eb01005f 	cmp	x2, x1
    34e8:	54000383 	b.cc	3558 <buf_grow+0x98>  // b.lo, b.ul, b.last
    34ec:	f9400a82 	ldr	x2, [x20, #16]
    34f0:	91000421 	add	x1, x1, #0x1
    34f4:	8b000033 	add	x19, x1, x0
    34f8:	eb13005f 	cmp	x2, x19
    34fc:	54000242 	b.cs	3544 <buf_grow+0x84>  // b.hs, b.nlast
    3500:	f100005f 	cmp	x2, #0x0
    3504:	b5000262 	cbnz	x2, 3550 <buf_grow+0x90>
    3508:	d2800802 	mov	x2, #0x40                  	// #64
    350c:	eb02027f 	cmp	x19, x2
    3510:	54000068 	b.hi	351c <buf_grow+0x5c>  // b.pmore
    3514:	14000005 	b	3528 <buf_grow+0x68>
    3518:	b7f800a2 	tbnz	x2, #63, 352c <buf_grow+0x6c>
    351c:	d37ff842 	lsl	x2, x2, #1
    3520:	eb02027f 	cmp	x19, x2
    3524:	54ffffa8 	b.hi	3518 <buf_grow+0x58>  // b.pmore
    3528:	aa0203f3 	mov	x19, x2
    352c:	f9400280 	ldr	x0, [x20]
    3530:	aa1303e1 	mov	x1, x19
    3534:	97fffcd3 	bl	2880 <realloc@plt>
    3538:	b4000100 	cbz	x0, 3558 <buf_grow+0x98>
    353c:	f9000280 	str	x0, [x20]
    3540:	f9000a93 	str	x19, [x20, #16]
    3544:	a94153f3 	ldp	x19, x20, [sp, #16]
    3548:	a8c27bfd 	ldp	x29, x30, [sp], #32
    354c:	d65f03c0 	ret
    3550:	54fffe6a 	b.ge	351c <buf_grow+0x5c>  // b.tcont
    3554:	17fffff6 	b	352c <buf_grow+0x6c>
    3558:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    355c:	f947e863 	ldr	x3, [x3, #4048]
    3560:	d2800262 	mov	x2, #0x13                  	// #19
    3564:	d2800021 	mov	x1, #0x1                   	// #1
    3568:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1a60>
    356c:	913c2000 	add	x0, x0, #0xf08
    3570:	f9400063 	ldr	x3, [x3]
    3574:	97fffd07 	bl	2990 <fwrite@plt>
    3578:	d2800000 	mov	x0, #0x0                   	// #0
    357c:	97fffd11 	bl	29c0 <fflush@plt>
    3580:	52800cc0 	mov	w0, #0x66                  	// #102
    3584:	97fffd1f 	bl	2a00 <_Exit@plt>
    3588:	d503201f 	nop
    358c:	d503201f 	nop

0000000000003590 <buf_put>:
    3590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3594:	910003fd 	mov	x29, sp
    3598:	a90153f3 	stp	x19, x20, [sp, #16]
    359c:	aa0003f4 	mov	x20, x0
    35a0:	aa0203f3 	mov	x19, x2
    35a4:	f90013f5 	str	x21, [sp, #32]
    35a8:	aa0103f5 	mov	x21, x1
    35ac:	aa0203e1 	mov	x1, x2
    35b0:	97ffffc4 	bl	34c0 <buf_grow>
    35b4:	a9400283 	ldp	x3, x0, [x20]
    35b8:	aa1503e1 	mov	x1, x21
    35bc:	aa1303e2 	mov	x2, x19
    35c0:	8b000060 	add	x0, x3, x0
    35c4:	97fffc4b 	bl	26f0 <memcpy@plt>
    35c8:	a9400680 	ldp	x0, x1, [x20]
    35cc:	8b010273 	add	x19, x19, x1
    35d0:	f9000693 	str	x19, [x20, #8]
    35d4:	3833681f 	strb	wzr, [x0, x19]
    35d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35dc:	f94013f5 	ldr	x21, [sp, #32]
    35e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    35e4:	d65f03c0 	ret
    35e8:	d503201f 	nop
    35ec:	d503201f 	nop

00000000000035f0 <descent_phase_step>:
    35f0:	d10143ff 	sub	sp, sp, #0x50
    35f4:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    35f8:	f947f421 	ldr	x1, [x1, #4072]
    35fc:	a9027bfd 	stp	x29, x30, [sp, #32]
    3600:	910083fd 	add	x29, sp, #0x20
    3604:	f90023f5 	str	x21, [sp, #64]
    3608:	b00000f5 	adrp	x21, 20000 <__data_start>
    360c:	a90353f3 	stp	x19, x20, [sp, #48]
    3610:	2a0003f3 	mov	w19, w0
    3614:	b94012b4 	ldr	w20, [x21, #16]
    3618:	f9400020 	ldr	x0, [x1]
    361c:	f9000fe0 	str	x0, [sp, #24]
    3620:	d2800000 	mov	x0, #0x0                   	// #0
    3624:	11000680 	add	w0, w20, #0x1
    3628:	6b13001f 	cmp	w0, w19
    362c:	540005a1 	b.ne	36e0 <descent_phase_step+0xf0>  // b.any
    3630:	910023e1 	add	x1, sp, #0x8
    3634:	52800020 	mov	w0, #0x1                   	// #1
    3638:	97fffc62 	bl	27c0 <clock_gettime@plt>
    363c:	35000520 	cbnz	w0, 36e0 <descent_phase_step+0xf0>
    3640:	a94087e0 	ldp	x0, x1, [sp, #8]
    3644:	d2994002 	mov	x2, #0xca00                	// #51712
    3648:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    364c:	9b020400 	madd	x0, x0, x2, x1
    3650:	b00000e1 	adrp	x1, 20000 <__data_start>
    3654:	3100069f 	cmn	w20, #0x1
    3658:	54000160 	b.eq	3684 <descent_phase_step+0x94>  // b.none
    365c:	9101c022 	add	x2, x1, #0x70
    3660:	f9403844 	ldr	x4, [x2, #112]
    3664:	eb00009f 	cmp	x4, x0
    3668:	540003c8 	b.hi	36e0 <descent_phase_step+0xf0>  // b.pmore
    366c:	91010042 	add	x2, x2, #0x40
    3670:	93407e94 	sxtw	x20, w20
    3674:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    3678:	cb040063 	sub	x3, x3, x4
    367c:	8b000063 	add	x3, x3, x0
    3680:	f8347843 	str	x3, [x2, x20, lsl #3]
    3684:	71001a7f 	cmp	w19, #0x6
    3688:	540000c1 	b.ne	36a0 <descent_phase_step+0xb0>  // b.any
    368c:	9101c023 	add	x3, x1, #0x70
    3690:	12800013 	mov	w19, #0xffffffff            	// #-1
    3694:	f9401c62 	ldr	x2, [x3, #56]
    3698:	91000442 	add	x2, x2, #0x1
    369c:	f9001c62 	str	x2, [x3, #56]
    36a0:	9101c021 	add	x1, x1, #0x70
    36a4:	b90012b3 	str	w19, [x21, #16]
    36a8:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    36ac:	f947f442 	ldr	x2, [x2, #4072]
    36b0:	f9003820 	str	x0, [x1, #112]
    36b4:	aa0203e0 	mov	x0, x2
    36b8:	f9400fe2 	ldr	x2, [sp, #24]
    36bc:	f9400001 	ldr	x1, [x0]
    36c0:	eb010042 	subs	x2, x2, x1
    36c4:	d2800001 	mov	x1, #0x0                   	// #0
    36c8:	540000e1 	b.ne	36e4 <descent_phase_step+0xf4>  // b.any
    36cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36d0:	a94353f3 	ldp	x19, x20, [sp, #48]
    36d4:	f94023f5 	ldr	x21, [sp, #64]
    36d8:	910143ff 	add	sp, sp, #0x50
    36dc:	d65f03c0 	ret
    36e0:	97fffe94 	bl	3130 <descent_phase_fail>
    36e4:	97fffc6b 	bl	2890 <__stack_chk_fail@plt>
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	9101c022 	add	x2, x1, #0x70
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9400844 	ldr	x4, [x2, #16]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9403c44 	ldr	x4, [x2, #120]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	9101c021 	add	x1, x1, #0x70
    373c:	f9003c20 	str	x0, [x1, #120]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9004040 	str	x0, [x2, #128]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7a 	bl	2970 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc73 	bl	2970 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1a60>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	913f6021 	add	x1, x1, #0xfd8
    37b8:	97fffc8e 	bl	29f0 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1a60>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	913f8021 	add	x1, x1, #0xfe0
    37cc:	97fffc89 	bl	29f0 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd2 	bl	2720 <strlen@plt>
    37dc:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1a60>
    37e0:	913fa021 	add	x1, x1, #0xfe8
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_format_g.constprop.0>:
    3800:	d10483ff 	sub	sp, sp, #0x120
    3804:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1a60>
    3808:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    380c:	f947f442 	ldr	x2, [x2, #4072]
    3810:	913fc084 	add	x4, x4, #0xff0
    3814:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3818:	9102c3fd 	add	x29, sp, #0xb0
    381c:	d2800803 	mov	x3, #0x40                  	// #64
    3820:	a90e63f7 	stp	x23, x24, [sp, #224]
    3824:	93407c38 	sxtw	x24, w1
    3828:	aa0303e1 	mov	x1, x3
    382c:	fd008be8 	str	d8, [sp, #272]
    3830:	1e604008 	fmov	d8, d0
    3834:	a90c53f3 	stp	x19, x20, [sp, #192]
    3838:	910083f4 	add	x20, sp, #0x20
    383c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3840:	aa0003f5 	mov	x21, x0
    3844:	a91073fb 	stp	x27, x28, [sp, #256]
    3848:	5100071c 	sub	w28, w24, #0x1
    384c:	2a1c03e5 	mov	w5, w28
    3850:	f9400040 	ldr	x0, [x2]
    3854:	f90057e0 	str	x0, [sp, #168]
    3858:	d2800000 	mov	x0, #0x0                   	// #0
    385c:	52800042 	mov	w2, #0x2                   	// #2
    3860:	aa1403e0 	mov	x0, x20
    3864:	97fffbe7 	bl	2800 <__snprintf_chk@plt>
    3868:	52800ca1 	mov	w1, #0x65                  	// #101
    386c:	aa1403e0 	mov	x0, x20
    3870:	97fffc40 	bl	2970 <strchr@plt>
    3874:	aa0003f3 	mov	x19, x0
    3878:	52800142 	mov	w2, #0xa                   	// #10
    387c:	91000400 	add	x0, x0, #0x1
    3880:	d2800001 	mov	x1, #0x0                   	// #0
    3884:	97fffc2b 	bl	2930 <strtol@plt>
    3888:	aa0003f7 	mov	x23, x0
    388c:	11001400 	add	w0, w0, #0x5
    3890:	7100541f 	cmp	w0, #0x15
    3894:	54000d68 	b.hi	3a40 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3898:	4b170385 	sub	w5, w28, w23
    389c:	710000bf 	cmp	w5, #0x0
    38a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    38a4:	54000b80 	b.eq	3a14 <fwp_format_g.constprop.0+0x214>  // b.none
    38a8:	394083e0 	ldrb	w0, [sp, #32]
    38ac:	cb180273 	sub	x19, x19, x24
    38b0:	91000673 	add	x19, x19, #0x1
    38b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    38b8:	7100b41f 	cmp	w0, #0x2d
    38bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    38c0:	1a9f17e4 	cset	w4, eq	// eq = none
    38c4:	cb010266 	sub	x6, x19, x1
    38c8:	d10004da 	sub	x26, x6, #0x1
    38cc:	540018a0 	b.eq	3be0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    38d0:	910183f9 	add	x25, sp, #0x60
    38d4:	d280091b 	mov	x27, #0x48                  	// #72
    38d8:	aa1903e7 	mov	x7, x25
    38dc:	91000423 	add	x3, x1, #0x1
    38e0:	91011cc6 	add	x6, x6, #0x47
    38e4:	910004f6 	add	x22, x7, #0x1
    38e8:	37f80ff7 	tbnz	w23, #31, 3ae4 <fwp_format_g.constprop.0+0x2e4>
    38ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38f0:	93407ef7 	sxtw	x23, w23
    38f4:	390000e4 	strb	w4, [x7]
    38f8:	aa1303e1 	mov	x1, x19
    38fc:	aa1703e2 	mov	x2, x23
    3900:	aa1603e0 	mov	x0, x22
    3904:	b9000be5 	str	w5, [sp, #8]
    3908:	cb170374 	sub	x20, x27, x23
    390c:	a9011be3 	stp	x3, x6, [sp, #16]
    3910:	97fffb78 	bl	26f0 <memcpy@plt>
    3914:	d1000694 	sub	x20, x20, #0x1
    3918:	f9400be3 	ldr	x3, [sp, #16]
    391c:	8b1702d6 	add	x22, x22, x23
    3920:	aa1603e0 	mov	x0, x22
    3924:	aa1a03e2 	mov	x2, x26
    3928:	aa0303e1 	mov	x1, x3
    392c:	aa1403e3 	mov	x3, x20
    3930:	97fffbac 	bl	27e0 <__memcpy_chk@plt>
    3934:	8b1a02d6 	add	x22, x22, x26
    3938:	f9400fe6 	ldr	x6, [sp, #24]
    393c:	d2800900 	mov	x0, #0x48                  	// #72
    3940:	b9400be5 	ldr	w5, [sp, #8]
    3944:	8b170261 	add	x1, x19, x23
    3948:	cb1400c3 	sub	x3, x6, x20
    394c:	cb060294 	sub	x20, x20, x6
    3950:	f101207f 	cmp	x3, #0x48
    3954:	93407cb8 	sxtw	x24, w5
    3958:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    395c:	aa1803e2 	mov	x2, x24
    3960:	8b1802d3 	add	x19, x22, x24
    3964:	8b140063 	add	x3, x3, x20
    3968:	aa1603e0 	mov	x0, x22
    396c:	97fffb9d 	bl	27e0 <__memcpy_chk@plt>
    3970:	cb190273 	sub	x19, x19, x25
    3974:	d28031e0 	mov	x0, #0x18f                 	// #399
    3978:	eb00027f 	cmp	x19, x0
    397c:	aa1903e1 	mov	x1, x25
    3980:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3984:	aa1503e0 	mov	x0, x21
    3988:	aa1303e2 	mov	x2, x19
    398c:	97fffb59 	bl	26f0 <memcpy@plt>
    3990:	38336abf 	strb	wzr, [x21, x19]
    3994:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3998:	aa1503e0 	mov	x0, x21
    399c:	97fffb61 	bl	2720 <strlen@plt>
    39a0:	aa0003f3 	mov	x19, x0
    39a4:	528005c1 	mov	w1, #0x2e                  	// #46
    39a8:	aa1503e0 	mov	x0, x21
    39ac:	97fffbf1 	bl	2970 <strchr@plt>
    39b0:	b4000140 	cbz	x0, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b4:	b4000133 	cbz	x19, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b8:	aa1303e1 	mov	x1, x19
    39bc:	d1000673 	sub	x19, x19, #0x1
    39c0:	38736aa0 	ldrb	w0, [x21, x19]
    39c4:	7100c01f 	cmp	w0, #0x30
    39c8:	54001001 	b.ne	3bc8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    39cc:	38336abf 	strb	wzr, [x21, x19]
    39d0:	b5ffff53 	cbnz	x19, 39b8 <fwp_format_g.constprop.0+0x1b8>
    39d4:	d503201f 	nop
    39d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    39dc:	f947f400 	ldr	x0, [x0, #4072]
    39e0:	f94057e2 	ldr	x2, [sp, #168]
    39e4:	f9400001 	ldr	x1, [x0]
    39e8:	eb010042 	subs	x2, x2, x1
    39ec:	d2800001 	mov	x1, #0x0                   	// #0
    39f0:	54001061 	b.ne	3bfc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a00:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a04:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a08:	fd408be8 	ldr	d8, [sp, #272]
    3a0c:	910483ff 	add	sp, sp, #0x120
    3a10:	d65f03c0 	ret
    3a14:	1e604100 	fmov	d0, d8
    3a18:	710000bf 	cmp	w5, #0x0
    3a1c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3a20:	aa1503e0 	mov	x0, x21
    3a24:	90000044 	adrp	x4, b000 <_IO_stdin_used+0x100>
    3a28:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a2c:	91002084 	add	x4, x4, #0x8
    3a30:	52800042 	mov	w2, #0x2                   	// #2
    3a34:	d2803201 	mov	x1, #0x190                 	// #400
    3a38:	97fffb72 	bl	2800 <__snprintf_chk@plt>
    3a3c:	17ffffd7 	b	3998 <fwp_format_g.constprop.0+0x198>
    3a40:	cb140273 	sub	x19, x19, x20
    3a44:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a48:	910183f9 	add	x25, sp, #0x60
    3a4c:	aa1303e2 	mov	x2, x19
    3a50:	aa1403e1 	mov	x1, x20
    3a54:	aa1903e0 	mov	x0, x25
    3a58:	d2800803 	mov	x3, #0x40                  	// #64
    3a5c:	97fffb61 	bl	27e0 <__memcpy_chk@plt>
    3a60:	38336b3f 	strb	wzr, [x25, x19]
    3a64:	aa1903e0 	mov	x0, x25
    3a68:	528005c1 	mov	w1, #0x2e                  	// #46
    3a6c:	97fffbc1 	bl	2970 <strchr@plt>
    3a70:	b40001c0 	cbz	x0, 3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a74:	b50000b3 	cbnz	x19, 3a88 <fwp_format_g.constprop.0+0x288>
    3a78:	1400000c 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a7c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a80:	f1000673 	subs	x19, x19, #0x1
    3a84:	54000120 	b.eq	3aa8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a88:	8b130320 	add	x0, x25, x19
    3a8c:	385ff001 	ldurb	w1, [x0, #-1]
    3a90:	7100c03f 	cmp	w1, #0x30
    3a94:	54ffff40 	b.eq	3a7c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a98:	d1000673 	sub	x19, x19, #0x1
    3a9c:	38736b20 	ldrb	w0, [x25, x19]
    3aa0:	7100b81f 	cmp	w0, #0x2e
    3aa4:	54000a80 	b.eq	3bf4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3aa8:	710002ff 	cmp	w23, #0x0
    3aac:	528005a1 	mov	w1, #0x2d                  	// #45
    3ab0:	aa1903e5 	mov	x5, x25
    3ab4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	52800566 	mov	w6, #0x2b                  	// #43
    3ac0:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1a60>
    3ac4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ac8:	913fe084 	add	x4, x4, #0xff8
    3acc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ad0:	52800042 	mov	w2, #0x2                   	// #2
    3ad4:	d2803201 	mov	x1, #0x190                 	// #400
    3ad8:	97fffb4a 	bl	2800 <__snprintf_chk@plt>
    3adc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ae0:	17ffffbe 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3ae4:	52800605 	mov	w5, #0x30                  	// #48
    3ae8:	390000e5 	strb	w5, [x7]
    3aec:	d100077b 	sub	x27, x27, #0x1
    3af0:	aa0303e1 	mov	x1, x3
    3af4:	aa1603e0 	mov	x0, x22
    3af8:	aa1b03e3 	mov	x3, x27
    3afc:	aa1a03e2 	mov	x2, x26
    3b00:	f90007e6 	str	x6, [sp, #8]
    3b04:	b90013e4 	str	w4, [sp, #16]
    3b08:	8b1a02d6 	add	x22, x22, x26
    3b0c:	b9001be5 	str	w5, [sp, #24]
    3b10:	97fffb34 	bl	27e0 <__memcpy_chk@plt>
    3b14:	f94007e6 	ldr	x6, [sp, #8]
    3b18:	2a3703e7 	mvn	w7, w23
    3b1c:	b94013e4 	ldr	w4, [sp, #16]
    3b20:	cb1b00c1 	sub	x1, x6, x27
    3b24:	cb06037b 	sub	x27, x27, x6
    3b28:	f101203f 	cmp	x1, #0x48
    3b2c:	d2800906 	mov	x6, #0x48                  	// #72
    3b30:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3b34:	8b1b0023 	add	x3, x1, x27
    3b38:	310006ff 	cmn	w23, #0x1
    3b3c:	54000220 	b.eq	3b80 <fwp_format_g.constprop.0+0x380>  // b.none
    3b40:	b9401be5 	ldr	w5, [sp, #24]
    3b44:	d2800001 	mov	x1, #0x0                   	// #0
    3b48:	f101207f 	cmp	x3, #0x48
    3b4c:	d1000462 	sub	x2, x3, #0x1
    3b50:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b54:	38216ac5 	strb	w5, [x22, x1]
    3b58:	cb030003 	sub	x3, x0, x3
    3b5c:	91000421 	add	x1, x1, #0x1
    3b60:	91000463 	add	x3, x3, #0x1
    3b64:	eb00007f 	cmp	x3, x0
    3b68:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b6c:	cb000063 	sub	x3, x3, x0
    3b70:	8b020063 	add	x3, x3, x2
    3b74:	6b0100ff 	cmp	w7, w1
    3b78:	54fffe8c 	b.gt	3b48 <fwp_format_g.constprop.0+0x348>
    3b7c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b80:	f101207f 	cmp	x3, #0x48
    3b84:	d2800905 	mov	x5, #0x48                  	// #72
    3b88:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	cb0300a1 	sub	x1, x5, x3
    3b94:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b98:	91000421 	add	x1, x1, #0x1
    3b9c:	d1000463 	sub	x3, x3, #0x1
    3ba0:	eb05003f 	cmp	x1, x5
    3ba4:	38001402 	strb	w2, [x0], #1
    3ba8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3bac:	93407f82 	sxtw	x2, w28
    3bb0:	cb050025 	sub	x5, x1, x5
    3bb4:	aa1303e1 	mov	x1, x19
    3bb8:	8b0300a3 	add	x3, x5, x3
    3bbc:	8b1802d3 	add	x19, x22, x24
    3bc0:	97fffb08 	bl	27e0 <__memcpy_chk@plt>
    3bc4:	17ffff6b 	b	3970 <fwp_format_g.constprop.0+0x170>
    3bc8:	d1000421 	sub	x1, x1, #0x1
    3bcc:	38616aa0 	ldrb	w0, [x21, x1]
    3bd0:	7100b81f 	cmp	w0, #0x2e
    3bd4:	54fff021 	b.ne	39d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3bd8:	38216abf 	strb	wzr, [x21, x1]
    3bdc:	17ffff7f 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3be0:	910187e7 	add	x7, sp, #0x61
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bec:	390183e0 	strb	w0, [sp, #96]
    3bf0:	17ffff3b 	b	38dc <fwp_format_g.constprop.0+0xdc>
    3bf4:	38336b3f 	strb	wzr, [x25, x19]
    3bf8:	17ffffac 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3bfc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c00:	97fffb24 	bl	2890 <__stack_chk_fail@plt>

0000000000003c04 <fwp_heap_report>:
    3c04:	d105c3ff 	sub	sp, sp, #0x170
    3c08:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    3c0c:	91170042 	add	x2, x2, #0x5c0
    3c10:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    3c14:	f947e821 	ldr	x1, [x1, #4048]
    3c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c1c:	910443fd 	add	x29, sp, #0x110
    3c20:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3c24:	f947f400 	ldr	x0, [x0, #4072]
    3c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    3c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    3c30:	a9156bf9 	stp	x25, x26, [sp, #336]
    3c34:	6d1627e8 	stp	d8, d9, [sp, #352]
    3c38:	fd4a1c48 	ldr	d8, [x2, #5176]
    3c3c:	fd4a2049 	ldr	d9, [x2, #5184]
    3c40:	f9400036 	ldr	x22, [x1]
    3c44:	f9400001 	ldr	x1, [x0]
    3c48:	f90087e1 	str	x1, [sp, #264]
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	f949e459 	ldr	x25, [x2, #5064]
    3c54:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x100>
    3c58:	f94a1057 	ldr	x23, [x2, #5152]
    3c5c:	90000040 	adrp	x0, b000 <_IO_stdin_used+0x100>
    3c60:	f94a1458 	ldr	x24, [x2, #5160]
    3c64:	91004021 	add	x1, x1, #0x10
    3c68:	91006000 	add	x0, x0, #0x18
    3c6c:	97fffaed 	bl	2820 <fopen@plt>
    3c70:	b4000760 	cbz	x0, 3d5c <fwp_heap_report+0x158>
    3c74:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c78:	a91253f3 	stp	x19, x20, [sp, #288]
    3c7c:	aa0003f4 	mov	x20, x0
    3c80:	910023f3 	add	x19, sp, #0x8
    3c84:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c88:	72aae915 	movk	w21, #0x5748, lsl #16
    3c8c:	d503201f 	nop
    3c90:	aa1403e2 	mov	x2, x20
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	52802001 	mov	w1, #0x100                 	// #256
    3c9c:	97fffb69 	bl	2a40 <fgets@plt>
    3ca0:	b4000280 	cbz	x0, 3cf0 <fwp_heap_report+0xec>
    3ca4:	b9400261 	ldr	w1, [x19]
    3ca8:	6b15003f 	cmp	w1, w21
    3cac:	54ffff21 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cb0:	39401260 	ldrb	w0, [x19, #4]
    3cb4:	7101341f 	cmp	w0, #0x4d
    3cb8:	54fffec1 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cbc:	394037e0 	ldrb	w0, [sp, #13]
    3cc0:	7100e81f 	cmp	w0, #0x3a
    3cc4:	54fffe61 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cc8:	52800142 	mov	w2, #0xa                   	// #10
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	91003be0 	add	x0, sp, #0xe
    3cd4:	97fffb17 	bl	2930 <strtol@plt>
    3cd8:	aa1403e2 	mov	x2, x20
    3cdc:	aa0003fa 	mov	x26, x0
    3ce0:	52802001 	mov	w1, #0x100                 	// #256
    3ce4:	aa1303e0 	mov	x0, x19
    3ce8:	97fffb56 	bl	2a40 <fgets@plt>
    3cec:	b5fffdc0 	cbnz	x0, 3ca4 <fwp_heap_report+0xa0>
    3cf0:	aa1403e0 	mov	x0, x20
    3cf4:	97fffac7 	bl	2810 <fclose@plt>
    3cf8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cfc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3d00:	f947f400 	ldr	x0, [x0, #4072]
    3d04:	f94087e2 	ldr	x2, [sp, #264]
    3d08:	f9400001 	ldr	x1, [x0]
    3d0c:	eb010042 	subs	x2, x2, x1
    3d10:	d2800001 	mov	x1, #0x0                   	// #0
    3d14:	54000281 	b.ne	3d64 <fwp_heap_report+0x160>  // b.any
    3d18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d1c:	aa1a03e6 	mov	x6, x26
    3d20:	aa1903e5 	mov	x5, x25
    3d24:	aa1803e4 	mov	x4, x24
    3d28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3d2c:	aa1703e3 	mov	x3, x23
    3d30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3d3c:	1e604121 	fmov	d1, d9
    3d40:	1e604100 	fmov	d0, d8
    3d44:	90000042 	adrp	x2, b000 <_IO_stdin_used+0x100>
    3d48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d4c:	9100e042 	add	x2, x2, #0x38
    3d50:	9105c3ff 	add	sp, sp, #0x170
    3d54:	52800041 	mov	w1, #0x2                   	// #2
    3d58:	17fffaea 	b	2900 <__fprintf_chk@plt>
    3d5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d60:	17ffffe7 	b	3cfc <fwp_heap_report+0xf8>
    3d64:	a91253f3 	stp	x19, x20, [sp, #288]
    3d68:	97fffaca 	bl	2890 <__stack_chk_fail@plt>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_heap_init>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa40>
    3d78:	91130061 	add	x1, x3, #0x4c0
    3d7c:	910003fd 	mov	x29, sp
    3d80:	a90153f3 	stp	x19, x20, [sp, #16]
    3d84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    3d88:	91170262 	add	x2, x19, #0x5c0
    3d8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d90:	52800024 	mov	w4, #0x1                   	// #1
    3d94:	52800200 	mov	w0, #0x10                  	// #16
    3d98:	b913a444 	str	w4, [x2, #5028]
    3d9c:	d503201f 	nop
    3da0:	b8004420 	str	w0, [x1], #4
    3da4:	11004000 	add	w0, w0, #0x10
    3da8:	7104401f 	cmp	w0, #0x110
    3dac:	54ffffa1 	b.ne	3da0 <fwp_heap_init+0x30>  // b.any
    3db0:	90000042 	adrp	x2, b000 <_IO_stdin_used+0x100>
    3db4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3db8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa40>
    3dbc:	91140021 	add	x1, x1, #0x500
    3dc0:	3dc33843 	ldr	q3, [x2, #3296]
    3dc4:	d2800000 	mov	x0, #0x0                   	// #0
    3dc8:	4e040401 	dup	v1.4s, v0.s[0]
    3dcc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3dd0:	0f215400 	shl	v0.2s, v0.2s, #1
    3dd4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3dd8:	3ca06821 	str	q1, [x1, x0]
    3ddc:	91004000 	add	x0, x0, #0x10
    3de0:	f101801f 	cmp	x0, #0x60
    3de4:	54ffff21 	b.ne	3dc8 <fwp_heap_init+0x58>  // b.any
    3de8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa40>
    3dec:	91130063 	add	x3, x3, #0x4c0
    3df0:	91158084 	add	x4, x4, #0x560
    3df4:	91170266 	add	x6, x19, #0x5c0
    3df8:	d2800002 	mov	x2, #0x0                   	// #0
    3dfc:	d2800000 	mov	x0, #0x0                   	// #0
    3e00:	d2880205 	mov	x5, #0x4010                	// #16400
    3e04:	d503201f 	nop
    3e08:	910f0001 	add	x1, x0, #0x3c0
    3e0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e10:	eb02003f 	cmp	x1, x2
    3e14:	540000a2 	b.cs	3e28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e18:	91000400 	add	x0, x0, #0x1
    3e1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3e20:	eb02003f 	cmp	x1, x2
    3e24:	54ffffa3 	b.cc	3e18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3e28:	91004042 	add	x2, x2, #0x10
    3e2c:	38001480 	strb	w0, [x4], #1
    3e30:	eb05005f 	cmp	x2, x5
    3e34:	54fffea1 	b.ne	3e08 <fwp_heap_init+0x98>  // b.any
    3e38:	528000b5 	mov	w21, #0x5                   	// #5
    3e3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e40:	14000004 	b	3e50 <fwp_heap_init+0xe0>
    3e44:	d342fe94 	lsr	x20, x20, #2
    3e48:	710006b5 	subs	w21, w21, #0x1
    3e4c:	54000720 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3e50:	91404296 	add	x22, x20, #0x10, lsl #12
    3e54:	d2800005 	mov	x5, #0x0                   	// #0
    3e58:	aa1603e1 	mov	x1, x22
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	52880443 	mov	w3, #0x4022                	// #16418
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	d2800000 	mov	x0, #0x0                   	// #0
    3e6c:	97fffaad 	bl	2920 <mmap@plt>
    3e70:	aa0003e6 	mov	x6, x0
    3e74:	b100041f 	cmn	x0, #0x1
    3e78:	54fffe60 	b.eq	3e44 <fwp_heap_init+0xd4>  // b.none
    3e7c:	b40005a0 	cbz	x0, 3f30 <fwp_heap_init+0x1c0>
    3e80:	d350fe94 	lsr	x20, x20, #16
    3e84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e88:	8b0000c7 	add	x7, x6, x0
    3e8c:	91170275 	add	x21, x19, #0x5c0
    3e90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e94:	8b140a81 	add	x1, x20, x20, lsl #2
    3e98:	d2800005 	mov	x5, #0x0                   	// #0
    3e9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ea0:	d37df021 	lsl	x1, x1, #3
    3ea4:	52880443 	mov	w3, #0x4022                	// #16418
    3ea8:	52800002 	mov	w2, #0x0                   	// #0
    3eac:	d2800000 	mov	x0, #0x0                   	// #0
    3eb0:	f909daa7 	str	x7, [x21, #5040]
    3eb4:	f909dea6 	str	x6, [x21, #5048]
    3eb8:	f909e2b6 	str	x22, [x21, #5056]
    3ebc:	f909eab4 	str	x20, [x21, #5072]
    3ec0:	f90a02a1 	str	x1, [x21, #5120]
    3ec4:	97fffa97 	bl	2920 <mmap@plt>
    3ec8:	aa0003e1 	mov	x1, x0
    3ecc:	b100041f 	cmn	x0, #0x1
    3ed0:	54000300 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3ed4:	90000040 	adrp	x0, b000 <_IO_stdin_used+0x100>
    3ed8:	91030000 	add	x0, x0, #0xc0
    3edc:	f909fea1 	str	x1, [x21, #5112]
    3ee0:	97fffad0 	bl	2a20 <getenv@plt>
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	aa0003e1 	mov	x1, x0
    3eec:	b40000e0 	cbz	x0, 3f08 <fwp_heap_init+0x198>
    3ef0:	39400000 	ldrb	w0, [x0]
    3ef4:	340000a0 	cbz	w0, 3f08 <fwp_heap_init+0x198>
    3ef8:	7100c000 	subs	w0, w0, #0x30
    3efc:	54000120 	b.eq	3f20 <fwp_heap_init+0x1b0>  // b.none
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	1a9f07e2 	cset	w2, ne	// ne = any
    3f08:	91170273 	add	x19, x19, #0x5c0
    3f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f10:	b913aa62 	str	w2, [x19, #5032]
    3f14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f1c:	d65f03c0 	ret
    3f20:	39400420 	ldrb	w0, [x1, #1]
    3f24:	7100001f 	cmp	w0, #0x0
    3f28:	1a9f07e2 	cset	w2, ne	// ne = any
    3f2c:	17fffff7 	b	3f08 <fwp_heap_init+0x198>
    3f30:	97fffc40 	bl	3030 <fwp_heap_oom>

0000000000003f34 <fwp_wake_io>:
    3f34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3f38:	9101c122 	add	x2, x9, #0x70
    3f3c:	f9400001 	ldr	x1, [x0]
    3f40:	5280000a 	mov	w10, #0x0                   	// #0
    3f44:	f9403c46 	ldr	x6, [x2, #120]
    3f48:	52800008 	mov	w8, #0x0                   	// #0
    3f4c:	4f000400 	movi	v0.4s, #0x0
    3f50:	52800027 	mov	w7, #0x1                   	// #1
    3f54:	aa0103e2 	mov	x2, x1
    3f58:	b4000321 	cbz	x1, 3fbc <fwp_wake_io+0x88>
    3f5c:	f9408c25 	ldr	x5, [x1, #280]
    3f60:	39015c27 	strb	w7, [x1, #87]
    3f64:	b4000165 	cbz	x5, 3f90 <fwp_wake_io+0x5c>
    3f68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f6c:	b4000364 	cbz	x4, 3fd8 <fwp_wake_io+0xa4>
    3f70:	f9009483 	str	x3, [x4, #296]
    3f74:	f9409423 	ldr	x3, [x1, #296]
    3f78:	b4000043 	cbz	x3, 3f80 <fwp_wake_io+0x4c>
    3f7c:	f9009064 	str	x4, [x3, #288]
    3f80:	91080023 	add	x3, x1, #0x200
    3f84:	f900943f 	str	xzr, [x1, #296]
    3f88:	3c918060 	stur	q0, [x3, #-232]
    3f8c:	f9400001 	ldr	x1, [x0]
    3f90:	f9402843 	ldr	x3, [x2, #80]
    3f94:	f2001c7f 	tst	x3, #0xff000000ff
    3f98:	54fffde1 	b.ne	3f54 <fwp_wake_io+0x20>  // b.any
    3f9c:	39015047 	strb	w7, [x2, #84]
    3fa0:	f900805f 	str	xzr, [x2, #256]
    3fa4:	b40001e6 	cbz	x6, 3fe0 <fwp_wake_io+0xac>
    3fa8:	f90080c2 	str	x2, [x6, #256]
    3fac:	aa0203e6 	mov	x6, x2
    3fb0:	52800028 	mov	w8, #0x1                   	// #1
    3fb4:	aa0103e2 	mov	x2, x1
    3fb8:	b5fffd21 	cbnz	x1, 3f5c <fwp_wake_io+0x28>
    3fbc:	3400006a 	cbz	w10, 3fc8 <fwp_wake_io+0x94>
    3fc0:	9101c120 	add	x0, x9, #0x70
    3fc4:	f900400b 	str	x11, [x0, #128]
    3fc8:	34000068 	cbz	w8, 3fd4 <fwp_wake_io+0xa0>
    3fcc:	9101c129 	add	x9, x9, #0x70
    3fd0:	f9003d26 	str	x6, [x9, #120]
    3fd4:	d65f03c0 	ret
    3fd8:	f90000a3 	str	x3, [x5]
    3fdc:	17ffffe7 	b	3f78 <fwp_wake_io+0x44>
    3fe0:	aa0203eb 	mov	x11, x2
    3fe4:	5280002a 	mov	w10, #0x1                   	// #1
    3fe8:	17fffff1 	b	3fac <fwp_wake_io+0x78>
    3fec:	d503201f 	nop

0000000000003ff0 <fwp_tape_buffers_release>:
    3ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3ff4:	910003fd 	mov	x29, sp
    3ff8:	a90153f3 	stp	x19, x20, [sp, #16]
    3ffc:	aa0003f3 	mov	x19, x0
    4000:	f9400c00 	ldr	x0, [x0, #24]
    4004:	b7f80700 	tbnz	x0, #63, 40e4 <fwp_tape_buffers_release+0xf4>
    4008:	f9401261 	ldr	x1, [x19, #32]
    400c:	b7f80301 	tbnz	x1, #63, 406c <fwp_tape_buffers_release+0x7c>
    4010:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4014:	eb02001f 	cmp	x0, x2
    4018:	540002a8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    401c:	8b000400 	add	x0, x0, x0, lsl #1
    4020:	d2a00102 	mov	x2, #0x80000               	// #524288
    4024:	d37df000 	lsl	x0, x0, #3
    4028:	cb000042 	sub	x2, x2, x0
    402c:	eb420c3f 	cmp	x1, x2, lsr #3
    4030:	540001e8 	b.hi	406c <fwp_tape_buffers_release+0x7c>  // b.pmore
    4034:	8b010c14 	add	x20, x0, x1, lsl #3
    4038:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    403c:	91034000 	add	x0, x0, #0xd0
    4040:	97fffa78 	bl	2a20 <getenv@plt>
    4044:	b4000240 	cbz	x0, 408c <fwp_tape_buffers_release+0x9c>
    4048:	39400001 	ldrb	w1, [x0]
    404c:	7100c03f 	cmp	w1, #0x30
    4050:	540001e1 	b.ne	408c <fwp_tape_buffers_release+0x9c>  // b.any
    4054:	39400400 	ldrb	w0, [x0, #1]
    4058:	350001a0 	cbnz	w0, 408c <fwp_tape_buffers_release+0x9c>
    405c:	aa1303e0 	mov	x0, x19
    4060:	a94153f3 	ldp	x19, x20, [sp, #16]
    4064:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4068:	17fffd06 	b	3480 <fwp_tape_buffers_dispose>
    406c:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    4070:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4074:	91034000 	add	x0, x0, #0xd0
    4078:	97fffa6a 	bl	2a20 <getenv@plt>
    407c:	b4ffff00 	cbz	x0, 405c <fwp_tape_buffers_release+0x6c>
    4080:	39400001 	ldrb	w1, [x0]
    4084:	7100c03f 	cmp	w1, #0x30
    4088:	54fffe60 	b.eq	4054 <fwp_tape_buffers_release+0x64>  // b.none
    408c:	d1000681 	sub	x1, x20, #0x1
    4090:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4094:	eb00003f 	cmp	x1, x0
    4098:	54fffe28 	b.hi	405c <fwp_tape_buffers_release+0x6c>  // b.pmore
    409c:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a0:	900000f6 	adrp	x22, 20000 <__data_start>
    40a4:	9101c2d6 	add	x22, x22, #0x70
    40a8:	910222d5 	add	x21, x22, #0x88
    40ac:	aa1503e0 	mov	x0, x21
    40b0:	97fffcf4 	bl	3480 <fwp_tape_buffers_dispose>
    40b4:	ad400660 	ldp	q0, q1, [x19]
    40b8:	f9005ad4 	str	x20, [x22, #176]
    40bc:	ad0006a0 	stp	q0, q1, [x21]
    40c0:	f9401260 	ldr	x0, [x19, #32]
    40c4:	f90012a0 	str	x0, [x21, #32]
    40c8:	a9007e7f 	stp	xzr, xzr, [x19]
    40cc:	a9017e7f 	stp	xzr, xzr, [x19, #16]
    40d0:	f900127f 	str	xzr, [x19, #32]
    40d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    40d8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40e0:	d65f03c0 	ret
    40e4:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    40e8:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    40ec:	91034000 	add	x0, x0, #0xd0
    40f0:	97fffa4c 	bl	2a20 <getenv@plt>
    40f4:	b5fffaa0 	cbnz	x0, 4048 <fwp_tape_buffers_release+0x58>
    40f8:	17ffffd9 	b	405c <fwp_tape_buffers_release+0x6c>
    40fc:	d503201f 	nop

0000000000004100 <fwp_trap>:
    4100:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4104:	900000e2 	adrp	x2, 20000 <__data_start>
    4108:	d53bd041 	mrs	x1, tpidr_el0
    410c:	910003fd 	mov	x29, sp
    4110:	f9403c42 	ldr	x2, [x2, #120]
    4114:	91400021 	add	x1, x1, #0x0, lsl #12
    4118:	91004021 	add	x1, x1, #0x10
    411c:	a90153f3 	stp	x19, x20, [sp, #16]
    4120:	aa0003f3 	mov	x19, x0
    4124:	f9400034 	ldr	x20, [x1]
    4128:	b4000062 	cbz	x2, 4134 <fwp_trap+0x34>
    412c:	aa0203e0 	mov	x0, x2
    4130:	97fffa24 	bl	29c0 <fflush@plt>
    4134:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4138:	f947ec00 	ldr	x0, [x0, #4056]
    413c:	f9400000 	ldr	x0, [x0]
    4140:	97fffa20 	bl	29c0 <fflush@plt>
    4144:	aa1303e3 	mov	x3, x19
    4148:	f0000022 	adrp	x2, b000 <_IO_stdin_used+0x100>
    414c:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc88>
    4150:	f947ea73 	ldr	x19, [x19, #4048]
    4154:	9103a042 	add	x2, x2, #0xe8
    4158:	52800041 	mov	w1, #0x2                   	// #2
    415c:	f9400260 	ldr	x0, [x19]
    4160:	97fff9e8 	bl	2900 <__fprintf_chk@plt>
    4164:	b40000b4 	cbz	x20, 4178 <fwp_trap+0x78>
    4168:	f9400260 	ldr	x0, [x19]
    416c:	97fffa15 	bl	29c0 <fflush@plt>
    4170:	52800ca0 	mov	w0, #0x65                  	// #101
    4174:	97fffa23 	bl	2a00 <_Exit@plt>
    4178:	52800ca0 	mov	w0, #0x65                  	// #101
    417c:	97fff971 	bl	2740 <exit@plt>

0000000000004180 <fwp_rc_forget_slot.part.0>:
    4180:	ca404401 	eor	x1, x0, x0, lsr #17
    4184:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4188:	ca412421 	eor	x1, x1, x1, lsr #9
    418c:	910003fd 	mov	x29, sp
    4190:	92401c21 	and	x1, x1, #0xff
    4194:	f9000bf3 	str	x19, [sp, #16]
    4198:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    419c:	91170262 	add	x2, x19, #0x5c0
    41a0:	910a2423 	add	x3, x1, #0x289
    41a4:	8b010c41 	add	x1, x2, x1, lsl #3
    41a8:	8b030c43 	add	x3, x2, x3, lsl #3
    41ac:	f94a2421 	ldr	x1, [x1, #5192]
    41b0:	b50000a1 	cbnz	x1, 41c4 <fwp_rc_forget_slot.part.0+0x44>
    41b4:	14000012 	b	41fc <fwp_rc_forget_slot.part.0+0x7c>
    41b8:	91004023 	add	x3, x1, #0x10
    41bc:	f9400821 	ldr	x1, [x1, #16]
    41c0:	b40001e1 	cbz	x1, 41fc <fwp_rc_forget_slot.part.0+0x7c>
    41c4:	f9400022 	ldr	x2, [x1]
    41c8:	eb02001f 	cmp	x0, x2
    41cc:	54ffff61 	b.ne	41b8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    41d0:	f9400060 	ldr	x0, [x3]
    41d4:	91170273 	add	x19, x19, #0x5c0
    41d8:	f9400801 	ldr	x1, [x0, #16]
    41dc:	f9000061 	str	x1, [x3]
    41e0:	97fff9dc 	bl	2950 <free@plt>
    41e4:	f94e2660 	ldr	x0, [x19, #7240]
    41e8:	d1000400 	sub	x0, x0, #0x1
    41ec:	f90e2660 	str	x0, [x19, #7240]
    41f0:	f9400bf3 	ldr	x19, [sp, #16]
    41f4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    41f8:	d65f03c0 	ret
    41fc:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    4200:	9103e000 	add	x0, x0, #0xf8
    4204:	97ffffbf 	bl	4100 <fwp_trap>
    4208:	d503201f 	nop
    420c:	d503201f 	nop

0000000000004210 <fwp_rc_prepare_chunk>:
    4210:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4214:	910003fd 	mov	x29, sp
    4218:	a9025bf5 	stp	x21, x22, [sp, #32]
    421c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc20>
    4220:	911702c2 	add	x2, x22, #0x5c0
    4224:	b9401c03 	ldr	w3, [x0, #28]
    4228:	aa0103f5 	mov	x21, x1
    422c:	a90153f3 	stp	x19, x20, [sp, #16]
    4230:	aa0003f4 	mov	x20, x0
    4234:	f94e2440 	ldr	x0, [x2, #7240]
    4238:	b4000440 	cbz	x0, 42c0 <fwp_rc_prepare_chunk+0xb0>
    423c:	d2800013 	mov	x19, #0x0                   	// #0
    4240:	35000203 	cbnz	w3, 4280 <fwp_rc_prepare_chunk+0x70>
    4244:	b4000361 	cbz	x1, 42b0 <fwp_rc_prepare_chunk+0xa0>
    4248:	f9401280 	ldr	x0, [x20, #32]
    424c:	97fff9c1 	bl	2950 <free@plt>
    4250:	aa1503e0 	mov	x0, x21
    4254:	d2800021 	mov	x1, #0x1                   	// #1
    4258:	97fff986 	bl	2870 <calloc@plt>
    425c:	f9001280 	str	x0, [x20, #32]
    4260:	b5000460 	cbnz	x0, 42ec <fwp_rc_prepare_chunk+0xdc>
    4264:	97fffb73 	bl	3030 <fwp_heap_oom>
    4268:	97ffffc6 	bl	4180 <fwp_rc_forget_slot.part.0>
    426c:	91000673 	add	x19, x19, #0x1
    4270:	b9401e83 	ldr	w3, [x20, #28]
    4274:	eb13007f 	cmp	x3, x19
    4278:	54000169 	b.ls	42a4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    427c:	d503201f 	nop
    4280:	f9401283 	ldr	x3, [x20, #32]
    4284:	8b130060 	add	x0, x3, x19
    4288:	38736863 	ldrb	w3, [x3, x19]
    428c:	7103fc7f 	cmp	w3, #0xff
    4290:	54fffec0 	b.eq	4268 <fwp_rc_prepare_chunk+0x58>  // b.none
    4294:	b9401e83 	ldr	w3, [x20, #28]
    4298:	91000673 	add	x19, x19, #0x1
    429c:	eb13007f 	cmp	x3, x19
    42a0:	54ffff08 	b.hi	4280 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    42a4:	eb0302bf 	cmp	x21, x3
    42a8:	54000121 	b.ne	42cc <fwp_rc_prepare_chunk+0xbc>  // b.any
    42ac:	b5000335 	cbnz	x21, 4310 <fwp_rc_prepare_chunk+0x100>
    42b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    42b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42bc:	d65f03c0 	ret
    42c0:	2a0303e3 	mov	w3, w3
    42c4:	eb0302bf 	cmp	x21, x3
    42c8:	54ffff20 	b.eq	42ac <fwp_rc_prepare_chunk+0x9c>  // b.none
    42cc:	911702c2 	add	x2, x22, #0x5c0
    42d0:	f9401280 	ldr	x0, [x20, #32]
    42d4:	f94e2841 	ldr	x1, [x2, #7248]
    42d8:	cb030021 	sub	x1, x1, x3
    42dc:	f90e2841 	str	x1, [x2, #7248]
    42e0:	97fff99c 	bl	2950 <free@plt>
    42e4:	b5fffb75 	cbnz	x21, 4250 <fwp_rc_prepare_chunk+0x40>
    42e8:	f900129f 	str	xzr, [x20, #32]
    42ec:	911702d6 	add	x22, x22, #0x5c0
    42f0:	f94e2ac0 	ldr	x0, [x22, #7248]
    42f4:	b9001e95 	str	w21, [x20, #28]
    42f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    42fc:	8b150000 	add	x0, x0, x21
    4300:	f90e2ac0 	str	x0, [x22, #7248]
    4304:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4308:	a8c37bfd 	ldp	x29, x30, [sp], #48
    430c:	d65f03c0 	ret
    4310:	f9401280 	ldr	x0, [x20, #32]
    4314:	aa1503e2 	mov	x2, x21
    4318:	a94153f3 	ldp	x19, x20, [sp, #16]
    431c:	52800001 	mov	w1, #0x0                   	// #0
    4320:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4324:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4328:	17fff94e 	b	2860 <memset@plt>
    432c:	d503201f 	nop

0000000000004330 <fwp_heap_refill>:
    4330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4334:	910003fd 	mov	x29, sp
    4338:	a9025bf5 	stp	x21, x22, [sp, #32]
    433c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    4340:	911702b5 	add	x21, x21, #0x5c0
    4344:	aa0003f6 	mov	x22, x0
    4348:	d2800020 	mov	x0, #0x1                   	// #1
    434c:	a90153f3 	stp	x19, x20, [sp, #16]
    4350:	a90363f7 	stp	x23, x24, [sp, #48]
    4354:	2a0103f7 	mov	w23, w1
    4358:	2a0203f8 	mov	w24, w2
    435c:	97fffbd5 	bl	32b0 <fwp_heap_chunks>
    4360:	aa0003f3 	mov	x19, x0
    4364:	f949fea2 	ldr	x2, [x21, #5112]
    4368:	8b000800 	add	x0, x0, x0, lsl #2
    436c:	2a1703e1 	mov	w1, w23
    4370:	52800025 	mov	w5, #0x1                   	// #1
    4374:	d37df000 	lsl	x0, x0, #3
    4378:	910f0021 	add	x1, x1, #0x3c0
    437c:	8b000054 	add	x20, x2, x0
    4380:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4384:	52a00024 	mov	w4, #0x10000               	// #65536
    4388:	38206845 	strb	w5, [x2, x0]
    438c:	aa1403e0 	mov	x0, x20
    4390:	39000698 	strb	w24, [x20, #1]
    4394:	39000a97 	strb	w23, [x20, #2]
    4398:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    439c:	b9000681 	str	w1, [x20, #4]
    43a0:	2a0103e5 	mov	w5, w1
    43a4:	8b0300a2 	add	x2, x5, x3
    43a8:	1ac10881 	udiv	w1, w4, w1
    43ac:	9ac50842 	udiv	x2, x2, x5
    43b0:	b9000a81 	str	w1, [x20, #8]
    43b4:	92404021 	and	x1, x1, #0x1ffff
    43b8:	b9001a82 	str	w2, [x20, #24]
    43bc:	97ffff95 	bl	4210 <fwp_rc_prepare_chunk>
    43c0:	f949daa0 	ldr	x0, [x21, #5040]
    43c4:	29408a81 	ldp	w1, w2, [x20, #4]
    43c8:	8b134000 	add	x0, x0, x19, lsl #16
    43cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    43d0:	8b214003 	add	x3, x0, w1, uxtw
    43d4:	9ba20021 	umaddl	x1, w1, w2, x0
    43d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    43dc:	a90086c3 	stp	x3, x1, [x22, #8]
    43e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    43e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    43e8:	d65f03c0 	ret
    43ec:	d503201f 	nop

00000000000043f0 <fwp_mem_free>:
    43f0:	b40003c0 	cbz	x0, 4468 <fwp_mem_free+0x78>
    43f4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    43f8:	910003fd 	mov	x29, sp
    43fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4400:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    4404:	911702a1 	add	x1, x21, #0x5c0
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	f949d823 	ldr	x3, [x1, #5040]
    4414:	f949ec22 	ldr	x2, [x1, #5080]
    4418:	cb030000 	sub	x0, x0, x3
    441c:	eb02401f 	cmp	x0, x2, lsl #16
    4420:	540001c2 	b.cs	4458 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4424:	d350fc16 	lsr	x22, x0, #16
    4428:	a90363f7 	stp	x23, x24, [sp, #48]
    442c:	f949fc22 	ldr	x2, [x1, #5112]
    4430:	8b160ad4 	add	x20, x22, x22, lsl #2
    4434:	d37df294 	lsl	x20, x20, #3
    4438:	ab140057 	adds	x23, x2, x20
    443c:	540000c0 	b.eq	4454 <fwp_mem_free+0x64>  // b.none
    4440:	38746842 	ldrb	w2, [x2, x20]
    4444:	7100045f 	cmp	w2, #0x1
    4448:	54000120 	b.eq	446c <fwp_mem_free+0x7c>  // b.none
    444c:	7100085f 	cmp	w2, #0x2
    4450:	540005e0 	b.eq	450c <fwp_mem_free+0x11c>  // b.none
    4454:	a94363f7 	ldp	x23, x24, [sp, #48]
    4458:	a94153f3 	ldp	x19, x20, [sp, #16]
    445c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4460:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4464:	d65f03c0 	ret
    4468:	d65f03c0 	ret
    446c:	f94012f8 	ldr	x24, [x23, #32]
    4470:	b94006e1 	ldr	w1, [x23, #4]
    4474:	f90023f9 	str	x25, [sp, #64]
    4478:	2a0103e2 	mov	w2, w1
    447c:	394006f9 	ldrb	w25, [x23, #1]
    4480:	39400af4 	ldrb	w20, [x23, #2]
    4484:	b4000158 	cbz	x24, 44ac <fwp_mem_free+0xbc>
    4488:	92403e76 	and	x22, x19, #0xffff
    448c:	9ac20ad6 	udiv	x22, x22, x2
    4490:	38766b01 	ldrb	w1, [x24, x22]
    4494:	8b160300 	add	x0, x24, x22
    4498:	7103fc3f 	cmp	w1, #0xff
    449c:	54000980 	b.eq	45cc <fwp_mem_free+0x1dc>  // b.none
    44a0:	38366b1f 	strb	wzr, [x24, x22]
    44a4:	b94006e1 	ldr	w1, [x23, #4]
    44a8:	2a0103e2 	mov	w2, w1
    44ac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    44b0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    44b4:	cb390000 	sub	x0, x0, w25, uxtb
    44b8:	8b340074 	add	x20, x3, w20, uxtb
    44bc:	911702b5 	add	x21, x21, #0x5c0
    44c0:	1e630021 	ucvtf	d1, w1
    44c4:	d37ae400 	lsl	x0, x0, #6
    44c8:	8b140c14 	add	x20, x0, x20, lsl #3
    44cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44d0:	f8746aa0 	ldr	x0, [x21, x20]
    44d4:	f94023f9 	ldr	x25, [sp, #64]
    44d8:	aa2003e0 	mvn	x0, x0
    44dc:	fd4a22a0 	ldr	d0, [x21, #5184]
    44e0:	f9000260 	str	x0, [x19]
    44e4:	f8346ab3 	str	x19, [x21, x20]
    44e8:	f94a12a0 	ldr	x0, [x21, #5152]
    44ec:	1e612800 	fadd	d0, d0, d1
    44f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44f4:	cb020000 	sub	x0, x0, x2
    44f8:	f90a12a0 	str	x0, [x21, #5152]
    44fc:	fd0a22a0 	str	d0, [x21, #5184]
    4500:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4504:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4508:	d65f03c0 	ret
    450c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4510:	8b000063 	add	x3, x3, x0
    4514:	eb03027f 	cmp	x19, x3
    4518:	54fff9e1 	b.ne	4454 <fwp_mem_free+0x64>  // b.any
    451c:	fd400ae1 	ldr	d1, [x23, #16]
    4520:	fd4a2020 	ldr	d0, [x1, #5184]
    4524:	f9400ae0 	ldr	x0, [x23, #16]
    4528:	7e61d821 	ucvtf	d1, d1
    452c:	f94a1022 	ldr	x2, [x1, #5152]
    4530:	f94012f3 	ldr	x19, [x23, #32]
    4534:	1e612800 	fadd	d0, d0, d1
    4538:	cb000042 	sub	x2, x2, x0
    453c:	f90a1022 	str	x2, [x1, #5152]
    4540:	fd0a2020 	str	d0, [x1, #5184]
    4544:	b40000b3 	cbz	x19, 4558 <fwp_mem_free+0x168>
    4548:	39400260 	ldrb	w0, [x19]
    454c:	7103fc1f 	cmp	w0, #0xff
    4550:	54000380 	b.eq	45c0 <fwp_mem_free+0x1d0>  // b.none
    4554:	3900027f 	strb	wzr, [x19]
    4558:	b9400ee2 	ldr	w2, [x23, #12]
    455c:	b4000142 	cbz	x2, 4584 <fwp_mem_free+0x194>
    4560:	911702a1 	add	x1, x21, #0x5c0
    4564:	8b160040 	add	x0, x2, x22
    4568:	8b000800 	add	x0, x0, x0, lsl #2
    456c:	f949fc21 	ldr	x1, [x1, #5112]
    4570:	8b140034 	add	x20, x1, x20
    4574:	8b000c20 	add	x0, x1, x0, lsl #3
    4578:	3802869f 	strb	wzr, [x20], #40
    457c:	eb00029f 	cmp	x20, x0
    4580:	54ffffc1 	b.ne	4578 <fwp_mem_free+0x188>  // b.any
    4584:	911702a0 	add	x0, x21, #0x5c0
    4588:	f94a1801 	ldr	x1, [x0, #5168]
    458c:	f949f803 	ldr	x3, [x0, #5104]
    4590:	8b020021 	add	x1, x1, x2
    4594:	f90a1801 	str	x1, [x0, #5168]
    4598:	eb16007f 	cmp	x3, x22
    459c:	54000049 	b.ls	45a4 <fwp_mem_free+0x1b4>  // b.plast
    45a0:	f909f816 	str	x22, [x0, #5104]
    45a4:	911702b5 	add	x21, x21, #0x5c0
    45a8:	f949f6a0 	ldr	x0, [x21, #5096]
    45ac:	eb16001f 	cmp	x0, x22
    45b0:	54fff529 	b.ls	4454 <fwp_mem_free+0x64>  // b.plast
    45b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    45b8:	f909f6b6 	str	x22, [x21, #5096]
    45bc:	17ffffa7 	b	4458 <fwp_mem_free+0x68>
    45c0:	aa1303e0 	mov	x0, x19
    45c4:	97fffeef 	bl	4180 <fwp_rc_forget_slot.part.0>
    45c8:	17ffffe3 	b	4554 <fwp_mem_free+0x164>
    45cc:	97fffeed 	bl	4180 <fwp_rc_forget_slot.part.0>
    45d0:	17ffffb4 	b	44a0 <fwp_mem_free+0xb0>

00000000000045d4 <fwp_rc_wide_dup>:
    45d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    45d8:	910003fd 	mov	x29, sp
    45dc:	a90153f3 	stp	x19, x20, [sp, #16]
    45e0:	aa0003f3 	mov	x19, x0
    45e4:	ca404400 	eor	x0, x0, x0, lsr #17
    45e8:	f90013f5 	str	x21, [sp, #32]
    45ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    45f0:	ca402400 	eor	x0, x0, x0, lsr #9
    45f4:	911702a2 	add	x2, x21, #0x5c0
    45f8:	92401c00 	and	x0, x0, #0xff
    45fc:	910a2403 	add	x3, x0, #0x289
    4600:	8b000c40 	add	x0, x2, x0, lsl #3
    4604:	8b030c54 	add	x20, x2, x3, lsl #3
    4608:	f94a2401 	ldr	x1, [x0, #5192]
    460c:	b50000a1 	cbnz	x1, 4620 <fwp_rc_wide_dup+0x4c>
    4610:	14000033 	b	46dc <fwp_rc_wide_dup+0x108>
    4614:	91004034 	add	x20, x1, #0x10
    4618:	f9400821 	ldr	x1, [x1, #16]
    461c:	b4000241 	cbz	x1, 4664 <fwp_rc_wide_dup+0x90>
    4620:	f9400022 	ldr	x2, [x1]
    4624:	eb02027f 	cmp	x19, x2
    4628:	54ffff61 	b.ne	4614 <fwp_rc_wide_dup+0x40>  // b.any
    462c:	f9400281 	ldr	x1, [x20]
    4630:	39400260 	ldrb	w0, [x19]
    4634:	7103f81f 	cmp	w0, #0xfe
    4638:	54000220 	b.eq	467c <fwp_rc_wide_dup+0xa8>  // b.none
    463c:	b40001a1 	cbz	x1, 4670 <fwp_rc_wide_dup+0x9c>
    4640:	f9400420 	ldr	x0, [x1, #8]
    4644:	b100041f 	cmn	x0, #0x1
    4648:	54000440 	b.eq	46d0 <fwp_rc_wide_dup+0xfc>  // b.none
    464c:	91000400 	add	x0, x0, #0x1
    4650:	f9000420 	str	x0, [x1, #8]
    4654:	a94153f3 	ldp	x19, x20, [sp, #16]
    4658:	f94013f5 	ldr	x21, [sp, #32]
    465c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4660:	d65f03c0 	ret
    4664:	39400260 	ldrb	w0, [x19]
    4668:	7103f81f 	cmp	w0, #0xfe
    466c:	54000100 	b.eq	468c <fwp_rc_wide_dup+0xb8>  // b.none
    4670:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    4674:	9103e000 	add	x0, x0, #0xf8
    4678:	97fffea2 	bl	4100 <fwp_trap>
    467c:	b4000081 	cbz	x1, 468c <fwp_rc_wide_dup+0xb8>
    4680:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    4684:	91048000 	add	x0, x0, #0x120
    4688:	97fffe9e 	bl	4100 <fwp_trap>
    468c:	d2800300 	mov	x0, #0x18                  	// #24
    4690:	97fff868 	bl	2830 <malloc@plt>
    4694:	b4000280 	cbz	x0, 46e4 <fwp_rc_wide_dup+0x110>
    4698:	d2801fe1 	mov	x1, #0xff                  	// #255
    469c:	a9000413 	stp	x19, x1, [x0]
    46a0:	911702b5 	add	x21, x21, #0x5c0
    46a4:	f900081f 	str	xzr, [x0, #16]
    46a8:	12800001 	mov	w1, #0xffffffff            	// #-1
    46ac:	f9000280 	str	x0, [x20]
    46b0:	39000261 	strb	w1, [x19]
    46b4:	f94e26a0 	ldr	x0, [x21, #7240]
    46b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    46bc:	91000400 	add	x0, x0, #0x1
    46c0:	f90e26a0 	str	x0, [x21, #7240]
    46c4:	f94013f5 	ldr	x21, [sp, #32]
    46c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46cc:	d65f03c0 	ret
    46d0:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    46d4:	91052000 	add	x0, x0, #0x148
    46d8:	97fffe8a 	bl	4100 <fwp_trap>
    46dc:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    46e0:	17ffffd4 	b	4630 <fwp_rc_wide_dup+0x5c>
    46e4:	97fffa53 	bl	3030 <fwp_heap_oom>
    46e8:	d503201f 	nop
    46ec:	d503201f 	nop

00000000000046f0 <fwp_closure_drop_push>:
    46f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    46f4:	910003fd 	mov	x29, sp
    46f8:	a90153f3 	stp	x19, x20, [sp, #16]
    46fc:	aa0003f3 	mov	x19, x0
    4700:	a9408014 	ldp	x20, x0, [x0, #8]
    4704:	a9025bf5 	stp	x21, x22, [sp, #32]
    4708:	aa0103f5 	mov	x21, x1
    470c:	a90363f7 	stp	x23, x24, [sp, #48]
    4710:	eb00029f 	cmp	x20, x0
    4714:	54000160 	b.eq	4740 <fwp_closure_drop_push+0x50>  // b.none
    4718:	f9400276 	ldr	x22, [x19]
    471c:	d37df297 	lsl	x23, x20, #3
    4720:	91000694 	add	x20, x20, #0x1
    4724:	f9000674 	str	x20, [x19, #8]
    4728:	a94153f3 	ldp	x19, x20, [sp, #16]
    472c:	f8376ad5 	str	x21, [x22, x23]
    4730:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4734:	a94363f7 	ldp	x23, x24, [sp, #48]
    4738:	a8c57bfd 	ldp	x29, x30, [sp], #80
    473c:	d65f03c0 	ret
    4740:	a9046bf9 	stp	x25, x26, [sp, #64]
    4744:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4748:	eb00029f 	cmp	x20, x0
    474c:	540003e8 	b.hi	47c8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4750:	d37cee99 	lsl	x25, x20, #4
    4754:	d37ffa9a 	lsl	x26, x20, #1
    4758:	aa1903e0 	mov	x0, x25
    475c:	97fff835 	bl	2830 <malloc@plt>
    4760:	aa0003f6 	mov	x22, x0
    4764:	b4000380 	cbz	x0, 47d4 <fwp_closure_drop_push+0xe4>
    4768:	aa1303f8 	mov	x24, x19
    476c:	aa1903e3 	mov	x3, x25
    4770:	d37df297 	lsl	x23, x20, #3
    4774:	aa1703e2 	mov	x2, x23
    4778:	f8418719 	ldr	x25, [x24], #24
    477c:	aa1903e1 	mov	x1, x25
    4780:	97fff818 	bl	27e0 <__memcpy_chk@plt>
    4784:	eb18033f 	cmp	x25, x24
    4788:	540000a0 	b.eq	479c <fwp_closure_drop_push+0xac>  // b.none
    478c:	aa1903e0 	mov	x0, x25
    4790:	97fff870 	bl	2950 <free@plt>
    4794:	f9400674 	ldr	x20, [x19, #8]
    4798:	d37df297 	lsl	x23, x20, #3
    479c:	91000694 	add	x20, x20, #0x1
    47a0:	f9000276 	str	x22, [x19]
    47a4:	f9000a7a 	str	x26, [x19, #16]
    47a8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    47ac:	f9000674 	str	x20, [x19, #8]
    47b0:	f8376ad5 	str	x21, [x22, x23]
    47b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    47b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    47c0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47c4:	d65f03c0 	ret
    47c8:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    47cc:	9105a000 	add	x0, x0, #0x168
    47d0:	97fffe4c 	bl	4100 <fwp_trap>
    47d4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    47d8:	f947e863 	ldr	x3, [x3, #4048]
    47dc:	d2800262 	mov	x2, #0x13                  	// #19
    47e0:	d2800021 	mov	x1, #0x1                   	// #1
    47e4:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1a60>
    47e8:	913c2000 	add	x0, x0, #0xf08
    47ec:	f9400063 	ldr	x3, [x3]
    47f0:	97fff868 	bl	2990 <fwrite@plt>
    47f4:	d2800000 	mov	x0, #0x0                   	// #0
    47f8:	97fff872 	bl	29c0 <fflush@plt>
    47fc:	52800cc0 	mov	w0, #0x66                  	// #102
    4800:	97fff880 	bl	2a00 <_Exit@plt>

0000000000004804 <fwp_closure_drop.part.0>:
    4804:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4808:	f0000021 	adrp	x1, b000 <_IO_stdin_used+0x100>
    480c:	910003fd 	mov	x29, sp
    4810:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    4814:	f947f463 	ldr	x3, [x3, #4072]
    4818:	a90153f3 	stp	x19, x20, [sp, #16]
    481c:	d10883ff 	sub	sp, sp, #0x220
    4820:	910003e2 	mov	x2, sp
    4824:	d53bd053 	mrs	x19, tpidr_el0
    4828:	910063f4 	add	x20, sp, #0x18
    482c:	3dc33c20 	ldr	q0, [x1, #3312]
    4830:	91400264 	add	x4, x19, #0x0, lsl #12
    4834:	91004084 	add	x4, x4, #0x10
    4838:	aa0003e1 	mov	x1, x0
    483c:	aa0203e0 	mov	x0, x2
    4840:	f9400062 	ldr	x2, [x3]
    4844:	f9010fe2 	str	x2, [sp, #536]
    4848:	d2800002 	mov	x2, #0x0                   	// #0
    484c:	f90003f4 	str	x20, [sp]
    4850:	f9000080 	str	x0, [x4]
    4854:	3c8083e0 	stur	q0, [sp, #8]
    4858:	97ffffa6 	bl	46f0 <fwp_closure_drop_push>
    485c:	f94007e0 	ldr	x0, [sp, #8]
    4860:	b40002e0 	cbz	x0, 48bc <fwp_closure_drop.part.0+0xb8>
    4864:	f90123f5 	str	x21, [sp, #576]
    4868:	900000f5 	adrp	x21, 20000 <__data_start>
    486c:	9101c2b5 	add	x21, x21, #0x70
    4870:	14000006 	b	4888 <fwp_closure_drop.part.0+0x84>
    4874:	f9400422 	ldr	x2, [x1, #8]
    4878:	52800001 	mov	w1, #0x0                   	// #0
    487c:	d63f0040 	blr	x2
    4880:	f94007e0 	ldr	x0, [sp, #8]
    4884:	b40001a0 	cbz	x0, 48b8 <fwp_closure_drop.part.0+0xb4>
    4888:	f94003e1 	ldr	x1, [sp]
    488c:	d1000400 	sub	x0, x0, #0x1
    4890:	f90007e0 	str	x0, [sp, #8]
    4894:	f9405ea2 	ldr	x2, [x21, #184]
    4898:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    489c:	b9400001 	ldr	w1, [x0]
    48a0:	8b011441 	add	x1, x2, x1, lsl #5
    48a4:	f9400c21 	ldr	x1, [x1, #24]
    48a8:	b5fffe61 	cbnz	x1, 4874 <fwp_closure_drop.part.0+0x70>
    48ac:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    48b0:	91062000 	add	x0, x0, #0x188
    48b4:	97fffe13 	bl	4100 <fwp_trap>
    48b8:	f94123f5 	ldr	x21, [sp, #576]
    48bc:	91400273 	add	x19, x19, #0x0, lsl #12
    48c0:	91004273 	add	x19, x19, #0x10
    48c4:	f94003e0 	ldr	x0, [sp]
    48c8:	f900027f 	str	xzr, [x19]
    48cc:	eb14001f 	cmp	x0, x20
    48d0:	54000040 	b.eq	48d8 <fwp_closure_drop.part.0+0xd4>  // b.none
    48d4:	97fff81f 	bl	2950 <free@plt>
    48d8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    48dc:	f947f400 	ldr	x0, [x0, #4072]
    48e0:	f9410fe2 	ldr	x2, [sp, #536]
    48e4:	f9400001 	ldr	x1, [x0]
    48e8:	eb010042 	subs	x2, x2, x1
    48ec:	d2800001 	mov	x1, #0x0                   	// #0
    48f0:	540000a1 	b.ne	4904 <fwp_closure_drop.part.0+0x100>  // b.any
    48f4:	910883ff 	add	sp, sp, #0x220
    48f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4900:	d65f03c0 	ret
    4904:	f90123f5 	str	x21, [sp, #576]
    4908:	97fff7e2 	bl	2890 <__stack_chk_fail@plt>
    490c:	d503201f 	nop

0000000000004910 <fwp_tape_of>:
    4910:	aa0003e1 	mov	x1, x0
    4914:	92403c00 	and	x0, x0, #0xffff
    4918:	b40000e0 	cbz	x0, 4934 <fwp_tape_of+0x24>
    491c:	d1000403 	sub	x3, x0, #0x1
    4920:	900000e0 	adrp	x0, 20000 <__data_start>
    4924:	9101c002 	add	x2, x0, #0x70
    4928:	f9406042 	ldr	x2, [x2, #192]
    492c:	eb03005f 	cmp	x2, x3
    4930:	540000cc 	b.gt	4948 <fwp_tape_of+0x38>
    4934:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4938:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    493c:	9106e000 	add	x0, x0, #0x1b8
    4940:	910003fd 	mov	x29, sp
    4944:	97fffdef 	bl	4100 <fwp_trap>
    4948:	8b030462 	add	x2, x3, x3, lsl #1
    494c:	f9403804 	ldr	x4, [x0, #112]
    4950:	d37ef442 	lsl	x2, x2, #2
    4954:	cb030042 	sub	x2, x2, x3
    4958:	d37df042 	lsl	x2, x2, #3
    495c:	8b020080 	add	x0, x4, x2
    4960:	b9400403 	ldr	w3, [x0, #4]
    4964:	34fffe83 	cbz	w3, 4934 <fwp_tape_of+0x24>
    4968:	b8626882 	ldr	w2, [x4, x2]
    496c:	9350fc21 	asr	x1, x1, #16
    4970:	6b01005f 	cmp	w2, w1
    4974:	54fffe01 	b.ne	4934 <fwp_tape_of+0x24>  // b.any
    4978:	d65f03c0 	ret
    497c:	d503201f 	nop

0000000000004980 <fwp_now_ns>:
    4980:	d100c3ff 	sub	sp, sp, #0x30
    4984:	52800020 	mov	w0, #0x1                   	// #1
    4988:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    498c:	f947f442 	ldr	x2, [x2, #4072]
    4990:	910023e1 	add	x1, sp, #0x8
    4994:	a9027bfd 	stp	x29, x30, [sp, #32]
    4998:	910083fd 	add	x29, sp, #0x20
    499c:	f9400043 	ldr	x3, [x2]
    49a0:	f9000fe3 	str	x3, [sp, #24]
    49a4:	d2800003 	mov	x3, #0x0                   	// #0
    49a8:	97fff786 	bl	27c0 <clock_gettime@plt>
    49ac:	350002c0 	cbnz	w0, 4a04 <fwp_now_ns+0x84>
    49b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    49b4:	d2994003 	mov	x3, #0xca00                	// #51712
    49b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    49bc:	9b037c20 	mul	x0, x1, x3
    49c0:	9b437c21 	smulh	x1, x1, x3
    49c4:	ab020000 	adds	x0, x0, x2
    49c8:	937ffc42 	asr	x2, x2, #63
    49cc:	9a020021 	adc	x1, x1, x2
    49d0:	f100001f 	cmp	x0, #0x0
    49d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    49d8:	b50001c1 	cbnz	x1, 4a10 <fwp_now_ns+0x90>
    49dc:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    49e0:	f947f421 	ldr	x1, [x1, #4072]
    49e4:	f9400fe3 	ldr	x3, [sp, #24]
    49e8:	f9400022 	ldr	x2, [x1]
    49ec:	eb020063 	subs	x3, x3, x2
    49f0:	d2800002 	mov	x2, #0x0                   	// #0
    49f4:	54000141 	b.ne	4a1c <fwp_now_ns+0x9c>  // b.any
    49f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    49fc:	9100c3ff 	add	sp, sp, #0x30
    4a00:	d65f03c0 	ret
    4a04:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    4a08:	91082000 	add	x0, x0, #0x208
    4a0c:	97fffdbd 	bl	4100 <fwp_trap>
    4a10:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    4a14:	9108a000 	add	x0, x0, #0x228
    4a18:	97fffdba 	bl	4100 <fwp_trap>
    4a1c:	97fff79d 	bl	2890 <__stack_chk_fail@plt>

0000000000004a20 <fwp_poll_events>:
    4a20:	d10103ff 	sub	sp, sp, #0x40
    4a24:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4a28:	f947f400 	ldr	x0, [x0, #4072]
    4a2c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4a30:	910083fd 	add	x29, sp, #0x20
    4a34:	f9001bf3 	str	x19, [sp, #48]
    4a38:	900000f3 	adrp	x19, 20000 <__data_start>
    4a3c:	f9400001 	ldr	x1, [x0]
    4a40:	f9000fe1 	str	x1, [sp, #24]
    4a44:	d2800001 	mov	x1, #0x0                   	// #0
    4a48:	97ffffce 	bl	4980 <fwp_now_ns>
    4a4c:	9101c261 	add	x1, x19, #0x70
    4a50:	f9406421 	ldr	x1, [x1, #200]
    4a54:	b4000e01 	cbz	x1, 4c14 <fwp_poll_events+0x1f4>
    4a58:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4a5c:	14000005 	b	4a70 <fwp_poll_events+0x50>
    4a60:	f9408821 	ldr	x1, [x1, #272]
    4a64:	eb03005f 	cmp	x2, x3
    4a68:	9a83d042 	csel	x2, x2, x3, le
    4a6c:	b40000c1 	cbz	x1, 4a84 <fwp_poll_events+0x64>
    4a70:	f9403423 	ldr	x3, [x1, #104]
    4a74:	b6ffff62 	tbz	x2, #63, 4a60 <fwp_poll_events+0x40>
    4a78:	f9408821 	ldr	x1, [x1, #272]
    4a7c:	aa0303e2 	mov	x2, x3
    4a80:	b5ffff81 	cbnz	x1, 4a70 <fwp_poll_events+0x50>
    4a84:	b7f80c82 	tbnz	x2, #63, 4c14 <fwp_poll_events+0x1f4>
    4a88:	cb000042 	sub	x2, x2, x0
    4a8c:	f100005f 	cmp	x2, #0x0
    4a90:	540003ad 	b.le	4b04 <fwp_poll_events+0xe4>
    4a94:	d2869b60 	mov	x0, #0x34db                	// #13531
    4a98:	d2884804 	mov	x4, #0x4240                	// #16960
    4a9c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4aa0:	f2a001e4 	movk	x4, #0xf, lsl #16
    4aa4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4aa8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4aac:	f2e86360 	movk	x0, #0x431b, lsl #48
    4ab0:	9b407c40 	smulh	x0, x2, x0
    4ab4:	9352fc00 	asr	x0, x0, #18
    4ab8:	cb82fc00 	sub	x0, x0, x2, asr #63
    4abc:	9b048802 	msub	x2, x0, x4, x2
    4ac0:	f100005f 	cmp	x2, #0x0
    4ac4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4ac8:	eb01001f 	cmp	x0, x1
    4acc:	5400098c 	b.gt	4bfc <fwp_poll_events+0x1dc>
    4ad0:	340001a0 	cbz	w0, 4b04 <fwp_poll_events+0xe4>
    4ad4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4ad8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4adc:	72a20c41 	movk	w1, #0x1062, lsl #16
    4ae0:	9ba17c01 	umull	x1, w0, w1
    4ae4:	d366fc23 	lsr	x3, x1, #38
    4ae8:	aa0303e2 	mov	x2, x3
    4aec:	1b058063 	msub	w3, w3, w5, w0
    4af0:	9b247c63 	smull	x3, w3, w4
    4af4:	910023e0 	add	x0, sp, #0x8
    4af8:	d2800001 	mov	x1, #0x0                   	// #0
    4afc:	a9008fe2 	stp	x2, x3, [sp, #8]
    4b00:	97fff798 	bl	2960 <nanosleep@plt>
    4b04:	97ffff9f 	bl	4980 <fwp_now_ns>
    4b08:	9101c268 	add	x8, x19, #0x70
    4b0c:	aa0003e7 	mov	x7, x0
    4b10:	4f000400 	movi	v0.4s, #0x0
    4b14:	52800029 	mov	w9, #0x1                   	// #1
    4b18:	f9406506 	ldr	x6, [x8, #200]
    4b1c:	d503201f 	nop
    4b20:	b40003e6 	cbz	x6, 4b9c <fwp_poll_events+0x17c>
    4b24:	f94034c1 	ldr	x1, [x6, #104]
    4b28:	aa0603e5 	mov	x5, x6
    4b2c:	f94088c6 	ldr	x6, [x6, #272]
    4b30:	eb07003f 	cmp	x1, x7
    4b34:	54ffff6c 	b.gt	4b20 <fwp_poll_events+0x100>
    4b38:	394154a0 	ldrb	w0, [x5, #85]
    4b3c:	36000120 	tbz	w0, #0, 4b60 <fwp_poll_events+0x140>
    4b40:	f94084a0 	ldr	x0, [x5, #264]
    4b44:	b4000560 	cbz	x0, 4bf0 <fwp_poll_events+0x1d0>
    4b48:	f9008806 	str	x6, [x0, #272]
    4b4c:	b4000046 	cbz	x6, 4b54 <fwp_poll_events+0x134>
    4b50:	f90084c0 	str	x0, [x6, #264]
    4b54:	910800a0 	add	x0, x5, #0x200
    4b58:	390154bf 	strb	wzr, [x5, #85]
    4b5c:	3c908000 	stur	q0, [x0, #-248]
    4b60:	f94030a0 	ldr	x0, [x5, #96]
    4b64:	390158a9 	strb	w9, [x5, #86]
    4b68:	f100001f 	cmp	x0, #0x0
    4b6c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4b70:	540002cd 	b.le	4bc8 <fwp_poll_events+0x1a8>
    4b74:	f94028a0 	ldr	x0, [x5, #80]
    4b78:	f2001c1f 	tst	x0, #0xff000000ff
    4b7c:	54fffd21 	b.ne	4b20 <fwp_poll_events+0x100>  // b.any
    4b80:	f9403d00 	ldr	x0, [x8, #120]
    4b84:	390150a9 	strb	w9, [x5, #84]
    4b88:	f90080bf 	str	xzr, [x5, #256]
    4b8c:	b40002c0 	cbz	x0, 4be4 <fwp_poll_events+0x1c4>
    4b90:	f9003d05 	str	x5, [x8, #120]
    4b94:	f9008005 	str	x5, [x0, #256]
    4b98:	b5fffc66 	cbnz	x6, 4b24 <fwp_poll_events+0x104>
    4b9c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4ba0:	f947f400 	ldr	x0, [x0, #4072]
    4ba4:	f9400fe2 	ldr	x2, [sp, #24]
    4ba8:	f9400001 	ldr	x1, [x0]
    4bac:	eb010042 	subs	x2, x2, x1
    4bb0:	d2800001 	mov	x1, #0x0                   	// #0
    4bb4:	540002e1 	b.ne	4c10 <fwp_poll_events+0x1f0>  // b.any
    4bb8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bbc:	f9401bf3 	ldr	x19, [sp, #48]
    4bc0:	910103ff 	add	sp, sp, #0x40
    4bc4:	d65f03c0 	ret
    4bc8:	394144a0 	ldrb	w0, [x5, #81]
    4bcc:	3707fd40 	tbnz	w0, #0, 4b74 <fwp_poll_events+0x154>
    4bd0:	394140a0 	ldrb	w0, [x5, #80]
    4bd4:	3707fd00 	tbnz	w0, #0, 4b74 <fwp_poll_events+0x154>
    4bd8:	aa0503e0 	mov	x0, x5
    4bdc:	97fffac5 	bl	36f0 <fwp_cancel_tree.part.0>
    4be0:	17ffffe5 	b	4b74 <fwp_poll_events+0x154>
    4be4:	f9003d05 	str	x5, [x8, #120]
    4be8:	f9004105 	str	x5, [x8, #128]
    4bec:	17ffffeb 	b	4b98 <fwp_poll_events+0x178>
    4bf0:	9101c261 	add	x1, x19, #0x70
    4bf4:	f9006426 	str	x6, [x1, #200]
    4bf8:	17ffffd5 	b	4b4c <fwp_poll_events+0x12c>
    4bfc:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4c00:	d2989362 	mov	x2, #0xc49b                	// #50331
    4c04:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4c08:	f2a00402 	movk	x2, #0x20, lsl #16
    4c0c:	17ffffba 	b	4af4 <fwp_poll_events+0xd4>
    4c10:	97fff720 	bl	2890 <__stack_chk_fail@plt>
    4c14:	97fff8f7 	bl	2ff0 <fwp_flush>
    4c18:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    4c1c:	f947e863 	ldr	x3, [x3, #4048]
    4c20:	d2800562 	mov	x2, #0x2b                  	// #43
    4c24:	d2800021 	mov	x1, #0x1                   	// #1
    4c28:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    4c2c:	91094000 	add	x0, x0, #0x250
    4c30:	f9400063 	ldr	x3, [x3]
    4c34:	97fff757 	bl	2990 <fwrite@plt>
    4c38:	52800ca0 	mov	w0, #0x65                  	// #101
    4c3c:	97fff6c1 	bl	2740 <exit@plt>

0000000000004c40 <fwp_heap_alloc_big>:
    4c40:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4c44:	910003fd 	mov	x29, sp
    4c48:	a90153f3 	stp	x19, x20, [sp, #16]
    4c4c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c50:	a90363f7 	stp	x23, x24, [sp, #48]
    4c54:	aa0003f7 	mov	x23, x0
    4c58:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4c5c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4c60:	eb0002ff 	cmp	x23, x0
    4c64:	540008a8 	b.hi	4d78 <fwp_heap_alloc_big+0x138>  // b.pmore
    4c68:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4c6c:	8b0002f4 	add	x20, x23, x0
    4c70:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc20>
    4c74:	91170359 	add	x25, x26, #0x5c0
    4c78:	d350fe94 	lsr	x20, x20, #16
    4c7c:	2a0103f5 	mov	w21, w1
    4c80:	aa1403e0 	mov	x0, x20
    4c84:	97fff98b 	bl	32b0 <fwp_heap_chunks>
    4c88:	f949ff22 	ldr	x2, [x25, #5112]
    4c8c:	8b000813 	add	x19, x0, x0, lsl #2
    4c90:	aa0003f8 	mov	x24, x0
    4c94:	52800043 	mov	w3, #0x2                   	// #2
    4c98:	d37df273 	lsl	x19, x19, #3
    4c9c:	d2800021 	mov	x1, #0x1                   	// #1
    4ca0:	8b130040 	add	x0, x2, x19
    4ca4:	38336843 	strb	w3, [x2, x19]
    4ca8:	39000415 	strb	w21, [x0, #1]
    4cac:	b9000c14 	str	w20, [x0, #12]
    4cb0:	f9000817 	str	x23, [x0, #16]
    4cb4:	97fffd57 	bl	4210 <fwp_rc_prepare_chunk>
    4cb8:	f100069f 	cmp	x20, #0x1
    4cbc:	54000289 	b.ls	4d0c <fwp_heap_alloc_big+0xcc>  // b.plast
    4cc0:	8b180294 	add	x20, x20, x24
    4cc4:	9100a273 	add	x19, x19, #0x28
    4cc8:	a90573fb 	stp	x27, x28, [sp, #80]
    4ccc:	5280007b 	mov	w27, #0x3                   	// #3
    4cd0:	8b140a94 	add	x20, x20, x20, lsl #2
    4cd4:	2a1803fc 	mov	w28, w24
    4cd8:	9adb2296 	lsl	x22, x20, x27
    4cdc:	d503201f 	nop
    4ce0:	f949ff35 	ldr	x21, [x25, #5112]
    4ce4:	d2800001 	mov	x1, #0x0                   	// #0
    4ce8:	8b1302b4 	add	x20, x21, x19
    4cec:	aa1403e0 	mov	x0, x20
    4cf0:	97fffd48 	bl	4210 <fwp_rc_prepare_chunk>
    4cf4:	38336abb 	strb	w27, [x21, x19]
    4cf8:	9100a273 	add	x19, x19, #0x28
    4cfc:	b9000e9c 	str	w28, [x20, #12]
    4d00:	eb1302df 	cmp	x22, x19
    4d04:	54fffee1 	b.ne	4ce0 <fwp_heap_alloc_big+0xa0>  // b.any
    4d08:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d0c:	91170353 	add	x19, x26, #0x5c0
    4d10:	aa1703e2 	mov	x2, x23
    4d14:	52800001 	mov	w1, #0x0                   	// #0
    4d18:	f949da60 	ldr	x0, [x19, #5040]
    4d1c:	8b184018 	add	x24, x0, x24, lsl #16
    4d20:	aa1803e0 	mov	x0, x24
    4d24:	97fff6cf 	bl	2860 <memset@plt>
    4d28:	f94a1260 	ldr	x0, [x19, #5152]
    4d2c:	ab170000 	adds	x0, x0, x23
    4d30:	54000242 	b.cs	4d78 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4d34:	f94a1661 	ldr	x1, [x19, #5160]
    4d38:	f90a1260 	str	x0, [x19, #5152]
    4d3c:	eb01001f 	cmp	x0, x1
    4d40:	54000049 	b.ls	4d48 <fwp_heap_alloc_big+0x108>  // b.plast
    4d44:	f90a1660 	str	x0, [x19, #5160]
    4d48:	9117035a 	add	x26, x26, #0x5c0
    4d4c:	9e6202e0 	scvtf	d0, x23
    4d50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d54:	aa1803e0 	mov	x0, x24
    4d58:	fd4a1f41 	ldr	d1, [x26, #5176]
    4d5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d60:	1e602820 	fadd	d0, d1, d0
    4d64:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d68:	fd0a1f40 	str	d0, [x26, #5176]
    4d6c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4d70:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4d74:	d65f03c0 	ret
    4d78:	a90573fb 	stp	x27, x28, [sp, #80]
    4d7c:	97fff8ad 	bl	3030 <fwp_heap_oom>

0000000000004d80 <fwp_heap_alloc_slow>:
    4d80:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d84:	910003fd 	mov	x29, sp
    4d88:	a90153f3 	stp	x19, x20, [sp, #16]
    4d8c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc20>
    4d90:	91170262 	add	x2, x19, #0x5c0
    4d94:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d98:	aa0003f5 	mov	x21, x0
    4d9c:	2a0103f4 	mov	w20, w1
    4da0:	b953a440 	ldr	w0, [x2, #5028]
    4da4:	34000600 	cbz	w0, 4e64 <fwp_heap_alloc_slow+0xe4>
    4da8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4dac:	54000628 	b.hi	4e70 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4db0:	91003ea0 	add	x0, x21, #0xf
    4db4:	91170262 	add	x2, x19, #0x5c0
    4db8:	f9001bf7 	str	x23, [sp, #48]
    4dbc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4dc0:	8b401040 	add	x0, x2, x0, lsr #4
    4dc4:	cb34c084 	sub	x4, x4, w20, sxtw
    4dc8:	d37ae484 	lsl	x4, x4, #6
    4dcc:	397e8003 	ldrb	w3, [x0, #4000]
    4dd0:	910f0060 	add	x0, x3, #0x3c0
    4dd4:	aa0303e1 	mov	x1, x3
    4dd8:	8b030463 	add	x3, x3, x3, lsl #1
    4ddc:	8b030c83 	add	x3, x4, x3, lsl #3
    4de0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4de4:	2a1703f6 	mov	w22, w23
    4de8:	f8636844 	ldr	x4, [x2, x3]
    4dec:	b40004e4 	cbz	x4, 4e88 <fwp_heap_alloc_slow+0x108>
    4df0:	f9400080 	ldr	x0, [x4]
    4df4:	aa2003e0 	mvn	x0, x0
    4df8:	f8236840 	str	x0, [x2, x3]
    4dfc:	7100069f 	cmp	w20, #0x1
    4e00:	aa0403e0 	mov	x0, x4
    4e04:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e08:	52800001 	mov	w1, #0x0                   	// #0
    4e0c:	97fff695 	bl	2860 <memset@plt>
    4e10:	aa0003e4 	mov	x4, x0
    4e14:	91170260 	add	x0, x19, #0x5c0
    4e18:	f94a1001 	ldr	x1, [x0, #5152]
    4e1c:	ab160021 	adds	x1, x1, x22
    4e20:	540005c2 	b.cs	4ed8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4e24:	f94a1402 	ldr	x2, [x0, #5160]
    4e28:	f90a1001 	str	x1, [x0, #5152]
    4e2c:	eb02003f 	cmp	x1, x2
    4e30:	54000049 	b.ls	4e38 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4e34:	f90a1401 	str	x1, [x0, #5160]
    4e38:	91170273 	add	x19, x19, #0x5c0
    4e3c:	1e6302e1 	ucvtf	d1, w23
    4e40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e44:	aa0403e0 	mov	x0, x4
    4e48:	fd4a1e60 	ldr	d0, [x19, #5176]
    4e4c:	f9401bf7 	ldr	x23, [sp, #48]
    4e50:	1e612800 	fadd	d0, d0, d1
    4e54:	fd0a1e60 	str	d0, [x19, #5176]
    4e58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	97fffbc3 	bl	3d70 <fwp_heap_init>
    4e68:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e6c:	54fffa29 	b.ls	4db0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4e70:	2a1403e1 	mov	w1, w20
    4e74:	aa1503e0 	mov	x0, x21
    4e78:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e80:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e84:	17ffff6f 	b	4c40 <fwp_heap_alloc_big>
    4e88:	8b030042 	add	x2, x2, x3
    4e8c:	f9400444 	ldr	x4, [x2, #8]
    4e90:	b4000104 	cbz	x4, 4eb0 <fwp_heap_alloc_slow+0x130>
    4e94:	f9400840 	ldr	x0, [x2, #16]
    4e98:	cb040000 	sub	x0, x0, x4
    4e9c:	eb16001f 	cmp	x0, x22
    4ea0:	54000083 	b.cc	4eb0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4ea4:	8b160080 	add	x0, x4, x22
    4ea8:	f9000440 	str	x0, [x2, #8]
    4eac:	17ffffd4 	b	4dfc <fwp_heap_alloc_slow+0x7c>
    4eb0:	52800302 	mov	w2, #0x18                  	// #24
    4eb4:	52807804 	mov	w4, #0x3c0                 	// #960
    4eb8:	91170260 	add	x0, x19, #0x5c0
    4ebc:	9ba27c23 	umull	x3, w1, w2
    4ec0:	2a1403e2 	mov	w2, w20
    4ec4:	9b240e84 	smaddl	x4, w20, w4, x3
    4ec8:	8b040000 	add	x0, x0, x4
    4ecc:	97fffd19 	bl	4330 <fwp_heap_refill>
    4ed0:	aa0003e4 	mov	x4, x0
    4ed4:	17ffffca 	b	4dfc <fwp_heap_alloc_slow+0x7c>
    4ed8:	97fff856 	bl	3030 <fwp_heap_oom>
    4edc:	d503201f 	nop

0000000000004ee0 <fwp_heap_alloc>:
    4ee0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ee4:	f140101f 	cmp	x0, #0x4, lsl #12
    4ee8:	910003fd 	mov	x29, sp
    4eec:	a90153f3 	stp	x19, x20, [sp, #16]
    4ef0:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc20>
    4ef4:	91170293 	add	x19, x20, #0x5c0
    4ef8:	b953a662 	ldr	w2, [x19, #5028]
    4efc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f00:	54000640 	b.eq	4fc8 <fwp_heap_alloc+0xe8>  // b.none
    4f04:	91003c03 	add	x3, x0, #0xf
    4f08:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f0c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4f10:	8b431263 	add	x3, x19, x3, lsr #4
    4f14:	cb21c042 	sub	x2, x2, w1, sxtw
    4f18:	d37ae442 	lsl	x2, x2, #6
    4f1c:	397e8063 	ldrb	w3, [x3, #4000]
    4f20:	910f0064 	add	x4, x3, #0x3c0
    4f24:	8b030463 	add	x3, x3, x3, lsl #1
    4f28:	8b030c43 	add	x3, x2, x3, lsl #3
    4f2c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4f30:	2a1603f5 	mov	w21, w22
    4f34:	f8636a64 	ldr	x4, [x19, x3]
    4f38:	b4000384 	cbz	x4, 4fa8 <fwp_heap_alloc+0xc8>
    4f3c:	f9400085 	ldr	x5, [x4]
    4f40:	7100043f 	cmp	w1, #0x1
    4f44:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4f48:	aa0403e0 	mov	x0, x4
    4f4c:	aa2503e5 	mvn	x5, x5
    4f50:	52800001 	mov	w1, #0x0                   	// #0
    4f54:	f8236a65 	str	x5, [x19, x3]
    4f58:	97fff642 	bl	2860 <memset@plt>
    4f5c:	aa0003e4 	mov	x4, x0
    4f60:	f94a1260 	ldr	x0, [x19, #5152]
    4f64:	ab150000 	adds	x0, x0, x21
    4f68:	54000442 	b.cs	4ff0 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4f6c:	f94a1661 	ldr	x1, [x19, #5160]
    4f70:	f90a1260 	str	x0, [x19, #5152]
    4f74:	eb01001f 	cmp	x0, x1
    4f78:	54000049 	b.ls	4f80 <fwp_heap_alloc+0xa0>  // b.plast
    4f7c:	f90a1660 	str	x0, [x19, #5160]
    4f80:	91170294 	add	x20, x20, #0x5c0
    4f84:	1e6302c1 	ucvtf	d1, w22
    4f88:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f8c:	aa0403e0 	mov	x0, x4
    4f90:	fd4a1e80 	ldr	d0, [x20, #5176]
    4f94:	1e612800 	fadd	d0, d0, d1
    4f98:	fd0a1e80 	str	d0, [x20, #5176]
    4f9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fa0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fa4:	d65f03c0 	ret
    4fa8:	8b030263 	add	x3, x19, x3
    4fac:	f9400464 	ldr	x4, [x3, #8]
    4fb0:	b40000a4 	cbz	x4, 4fc4 <fwp_heap_alloc+0xe4>
    4fb4:	f9400862 	ldr	x2, [x3, #16]
    4fb8:	cb040042 	sub	x2, x2, x4
    4fbc:	eb15005f 	cmp	x2, x21
    4fc0:	540000a2 	b.cs	4fd4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4fc4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fcc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4fd0:	17ffff6c 	b	4d80 <fwp_heap_alloc_slow>
    4fd4:	7100043f 	cmp	w1, #0x1
    4fd8:	8b150085 	add	x5, x4, x21
    4fdc:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	aa0403e0 	mov	x0, x4
    4fe8:	f9000465 	str	x5, [x3, #8]
    4fec:	17ffffdb 	b	4f58 <fwp_heap_alloc+0x78>
    4ff0:	97fff810 	bl	3030 <fwp_heap_oom>

0000000000004ff4 <fwp_data.part.0.constprop.0>:
    4ff4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4ff8:	910003fd 	mov	x29, sp
    4ffc:	a90153f3 	stp	x19, x20, [sp, #16]
    5000:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc20>
    5004:	91170283 	add	x3, x20, #0x5c0
    5008:	a9025bf5 	stp	x21, x22, [sp, #32]
    500c:	aa0103f5 	mov	x21, x1
    5010:	b953a461 	ldr	w1, [x3, #5028]
    5014:	a90363f7 	stp	x23, x24, [sp, #48]
    5018:	2a0003f8 	mov	w24, w0
    501c:	34000701 	cbz	w1, 50fc <fwp_data.part.0.constprop.0+0x108>
    5020:	397e8862 	ldrb	w2, [x3, #4002]
    5024:	910f0040 	add	x0, x2, #0x3c0
    5028:	8b020442 	add	x2, x2, x2, lsl #1
    502c:	d37df042 	lsl	x2, x2, #3
    5030:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5034:	2a1703f6 	mov	w22, w23
    5038:	f8626873 	ldr	x19, [x3, x2]
    503c:	b40004d3 	cbz	x19, 50d4 <fwp_data.part.0.constprop.0+0xe0>
    5040:	f9400260 	ldr	x0, [x19]
    5044:	aa2003e0 	mvn	x0, x0
    5048:	f8226860 	str	x0, [x3, x2]
    504c:	f10062df 	cmp	x22, #0x18
    5050:	540000e9 	b.ls	506c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5054:	d10066c2 	sub	x2, x22, #0x19
    5058:	91006260 	add	x0, x19, #0x18
    505c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5060:	52800001 	mov	w1, #0x0                   	// #0
    5064:	91002042 	add	x2, x2, #0x8
    5068:	97fff5fe 	bl	2860 <memset@plt>
    506c:	91170282 	add	x2, x20, #0x5c0
    5070:	f94a1041 	ldr	x1, [x2, #5152]
    5074:	ab160021 	adds	x1, x1, x22
    5078:	540004c2 	b.cs	5110 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    507c:	f94a1440 	ldr	x0, [x2, #5160]
    5080:	f90a1041 	str	x1, [x2, #5152]
    5084:	eb00003f 	cmp	x1, x0
    5088:	54000049 	b.ls	5090 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    508c:	f90a1441 	str	x1, [x2, #5160]
    5090:	91170294 	add	x20, x20, #0x5c0
    5094:	1e6302e1 	ucvtf	d1, w23
    5098:	fd4a1e80 	ldr	d0, [x20, #5176]
    509c:	1e612800 	fadd	d0, d0, d1
    50a0:	fd0a1e80 	str	d0, [x20, #5176]
    50a4:	52800041 	mov	w1, #0x2                   	// #2
    50a8:	29000678 	stp	w24, w1, [x19]
    50ac:	aa1303e0 	mov	x0, x19
    50b0:	f94002a1 	ldr	x1, [x21]
    50b4:	f9000661 	str	x1, [x19, #8]
    50b8:	f94006a1 	ldr	x1, [x21, #8]
    50bc:	f9000a61 	str	x1, [x19, #16]
    50c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    50c4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50c8:	a94363f7 	ldp	x23, x24, [sp, #48]
    50cc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50d0:	d65f03c0 	ret
    50d4:	8b020063 	add	x3, x3, x2
    50d8:	f9400473 	ldr	x19, [x3, #8]
    50dc:	b4000113 	cbz	x19, 50fc <fwp_data.part.0.constprop.0+0x108>
    50e0:	f9400860 	ldr	x0, [x3, #16]
    50e4:	cb130000 	sub	x0, x0, x19
    50e8:	eb0002df 	cmp	x22, x0
    50ec:	54000088 	b.hi	50fc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    50f0:	8b160260 	add	x0, x19, x22
    50f4:	f9000460 	str	x0, [x3, #8]
    50f8:	17ffffd5 	b	504c <fwp_data.part.0.constprop.0+0x58>
    50fc:	52800001 	mov	w1, #0x0                   	// #0
    5100:	d2800300 	mov	x0, #0x18                  	// #24
    5104:	97ffff77 	bl	4ee0 <fwp_heap_alloc>
    5108:	aa0003f3 	mov	x19, x0
    510c:	17ffffe6 	b	50a4 <fwp_data.part.0.constprop.0+0xb0>
    5110:	97fff7c8 	bl	3030 <fwp_heap_oom>

0000000000005114 <fwp_tape_grow.constprop.0>:
    5114:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5118:	d2800802 	mov	x2, #0x40                  	// #64
    511c:	910003fd 	mov	x29, sp
    5120:	a90153f3 	stp	x19, x20, [sp, #16]
    5124:	aa0003f4 	mov	x20, x0
    5128:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    512c:	f9400e93 	ldr	x19, [x20, #24]
    5130:	f100027f 	cmp	x19, #0x0
    5134:	9a821273 	csel	x19, x19, x2, ne	// ne = any
    5138:	eb13003f 	cmp	x1, x19
    513c:	540000ed 	b.le	5158 <fwp_tape_grow.constprop.0+0x44>
    5140:	eb00027f 	cmp	x19, x0
    5144:	5400064d 	b.le	520c <fwp_tape_grow.constprop.0+0xf8>
    5148:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    514c:	eb13003f 	cmp	x1, x19
    5150:	5400004d 	b.le	5158 <fwp_tape_grow.constprop.0+0x44>
    5154:	14000000 	b	5154 <fwp_tape_grow.constprop.0+0x40>
    5158:	a9025bf5 	stp	x21, x22, [sp, #32]
    515c:	f9402a95 	ldr	x21, [x20, #80]
    5160:	b40005b5 	cbz	x21, 5214 <fwp_tape_grow.constprop.0+0x100>
    5164:	f9401680 	ldr	x0, [x20, #40]
    5168:	d37df261 	lsl	x1, x19, #3
    516c:	97fff5c5 	bl	2880 <realloc@plt>
    5170:	b40006e0 	cbz	x0, 524c <fwp_tape_grow.constprop.0+0x138>
    5174:	f94032b6 	ldr	x22, [x21, #96]
    5178:	f9001680 	str	x0, [x20, #40]
    517c:	eb1302df 	cmp	x22, x19
    5180:	540003ca 	b.ge	51f8 <fwp_tape_grow.constprop.0+0xe4>  // b.tcont
    5184:	a90363f7 	stp	x23, x24, [sp, #48]
    5188:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    518c:	f90023f9 	str	x25, [sp, #64]
    5190:	eb00027f 	cmp	x19, x0
    5194:	54000568 	b.hi	5240 <fwp_tape_grow.constprop.0+0x12c>  // b.pmore
    5198:	f94022b8 	ldr	x24, [x21, #64]
    519c:	d37cee79 	lsl	x25, x19, #4
    51a0:	aa1903e0 	mov	x0, x25
    51a4:	52800041 	mov	w1, #0x2                   	// #2
    51a8:	97ffff4e 	bl	4ee0 <fwp_heap_alloc>
    51ac:	aa0003f7 	mov	x23, x0
    51b0:	b4000118 	cbz	x24, 51d0 <fwp_tape_grow.constprop.0+0xbc>
    51b4:	d37ceed6 	lsl	x22, x22, #4
    51b8:	aa1803e1 	mov	x1, x24
    51bc:	eb1902df 	cmp	x22, x25
    51c0:	9a9992c2 	csel	x2, x22, x25, ls	// ls = plast
    51c4:	97fff54b 	bl	26f0 <memcpy@plt>
    51c8:	aa1803e0 	mov	x0, x24
    51cc:	97fffc89 	bl	43f0 <fwp_mem_free>
    51d0:	f94032a0 	ldr	x0, [x21, #96]
    51d4:	52800001 	mov	w1, #0x0                   	// #0
    51d8:	cb000262 	sub	x2, x19, x0
    51dc:	8b0012e0 	add	x0, x23, x0, lsl #4
    51e0:	d37cec42 	lsl	x2, x2, #4
    51e4:	97fff59f 	bl	2860 <memset@plt>
    51e8:	f94023f9 	ldr	x25, [sp, #64]
    51ec:	f90022b7 	str	x23, [x21, #64]
    51f0:	a94363f7 	ldp	x23, x24, [sp, #48]
    51f4:	f90032b3 	str	x19, [x21, #96]
    51f8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51fc:	f9000e93 	str	x19, [x20, #24]
    5200:	a94153f3 	ldp	x19, x20, [sp, #16]
    5204:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5208:	d65f03c0 	ret
    520c:	d37ffa73 	lsl	x19, x19, #1
    5210:	17ffffca 	b	5138 <fwp_tape_grow.constprop.0+0x24>
    5214:	f9401280 	ldr	x0, [x20, #32]
    5218:	8b130661 	add	x1, x19, x19, lsl #1
    521c:	d37df021 	lsl	x1, x1, #3
    5220:	97fff598 	bl	2880 <realloc@plt>
    5224:	b4000140 	cbz	x0, 524c <fwp_tape_grow.constprop.0+0x138>
    5228:	a9425bf5 	ldp	x21, x22, [sp, #32]
    522c:	f9000e93 	str	x19, [x20, #24]
    5230:	f9001280 	str	x0, [x20, #32]
    5234:	a94153f3 	ldp	x19, x20, [sp, #16]
    5238:	a8c57bfd 	ldp	x29, x30, [sp], #80
    523c:	d65f03c0 	ret
    5240:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    5244:	910aa000 	add	x0, x0, #0x2a8
    5248:	97fffbae 	bl	4100 <fwp_trap>
    524c:	aa1403e0 	mov	x0, x20
    5250:	a90363f7 	stp	x23, x24, [sp, #48]
    5254:	f90023f9 	str	x25, [sp, #64]
    5258:	97fff74e 	bl	2f90 <fwp_tape_unlink_scope>
    525c:	f9401280 	ldr	x0, [x20, #32]
    5260:	97fff5bc 	bl	2950 <free@plt>
    5264:	f9401680 	ldr	x0, [x20, #40]
    5268:	97fff5ba 	bl	2950 <free@plt>
    526c:	f9401a80 	ldr	x0, [x20, #48]
    5270:	97fff5b8 	bl	2950 <free@plt>
    5274:	f9000e9f 	str	xzr, [x20, #24]
    5278:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    527c:	f947e821 	ldr	x1, [x1, #4048]
    5280:	a9037e9f 	stp	xzr, xzr, [x20, #48]
    5284:	d2800262 	mov	x2, #0x13                  	// #19
    5288:	4f000400 	movi	v0.4s, #0x0
    528c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1a60>
    5290:	f9400023 	ldr	x3, [x1]
    5294:	b900069f 	str	wzr, [x20, #4]
    5298:	d2800021 	mov	x1, #0x1                   	// #1
    529c:	913c2000 	add	x0, x0, #0xf08
    52a0:	3c808280 	stur	q0, [x20, #8]
    52a4:	3d800a80 	str	q0, [x20, #32]
    52a8:	97fff5ba 	bl	2990 <fwrite@plt>
    52ac:	d2800000 	mov	x0, #0x0                   	// #0
    52b0:	97fff5c4 	bl	29c0 <fflush@plt>
    52b4:	52800cc0 	mov	w0, #0x66                  	// #102
    52b8:	97fff5d2 	bl	2a00 <_Exit@plt>
    52bc:	d503201f 	nop

00000000000052c0 <w123>:
    52c0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    52c4:	910003fd 	mov	x29, sp
    52c8:	6d0427e8 	stp	d8, d9, [sp, #64]
    52cc:	1e612808 	fadd	d8, d0, d1
    52d0:	ea01001f 	tst	x0, x1
    52d4:	54000b44 	b.mi	543c <w123+0x17c>  // b.first
    52d8:	a90153f3 	stp	x19, x20, [sp, #16]
    52dc:	aa0003f4 	mov	x20, x0
    52e0:	aa0103f3 	mov	x19, x1
    52e4:	a9025bf5 	stp	x21, x22, [sp, #32]
    52e8:	aa010000 	orr	x0, x0, x1
    52ec:	aa0203f5 	mov	x21, x2
    52f0:	f9001bf7 	str	x23, [sp, #48]
    52f4:	b7f80200 	tbnz	x0, #63, 5334 <w123+0x74>
    52f8:	9360fc37 	asr	x23, x1, #32
    52fc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5300:	eb9482ff 	cmp	x23, x20, asr #32
    5304:	54000a61 	b.ne	5450 <w123+0x190>  // b.any
    5308:	f94002a0 	ldr	x0, [x21]
    530c:	eb17001f 	cmp	x0, x23
    5310:	54000220 	b.eq	5354 <w123+0x94>  // b.none
    5314:	aa1703e0 	mov	x0, x23
    5318:	97fffd7e 	bl	4910 <fwp_tape_of>
    531c:	aa0003f6 	mov	x22, x0
    5320:	f9402800 	ldr	x0, [x0, #80]
    5324:	b40002e0 	cbz	x0, 5380 <w123+0xc0>
    5328:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    532c:	910c4000 	add	x0, x0, #0x310
    5330:	97fffb74 	bl	4100 <fwp_trap>
    5334:	b6f80214 	tbz	x20, #63, 5374 <w123+0xb4>
    5338:	f94002a0 	ldr	x0, [x21]
    533c:	9360fc37 	asr	x23, x1, #32
    5340:	2f00e409 	movi	d9, #0x0
    5344:	aa0103f4 	mov	x20, x1
    5348:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    534c:	eb17001f 	cmp	x0, x23
    5350:	54fffe21 	b.ne	5314 <w123+0x54>  // b.any
    5354:	f94006b6 	ldr	x22, [x21, #8]
    5358:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    535c:	f9400ad7 	ldr	x23, [x22, #16]
    5360:	eb0002ff 	cmp	x23, x0
    5364:	5400018d 	b.le	5394 <w123+0xd4>
    5368:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    536c:	910aa000 	add	x0, x0, #0x2a8
    5370:	97fffb64 	bl	4100 <fwp_trap>
    5374:	9360fe97 	asr	x23, x20, #32
    5378:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    537c:	17ffffe3 	b	5308 <w123+0x48>
    5380:	a9005ab7 	stp	x23, x22, [x21]
    5384:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5388:	f9400ad7 	ldr	x23, [x22, #16]
    538c:	eb0002ff 	cmp	x23, x0
    5390:	54fffecc 	b.gt	5368 <w123+0xa8>
    5394:	eb3442ff 	cmp	x23, w20, uxtw
    5398:	540004cd 	b.le	5430 <w123+0x170>
    539c:	b7f80073 	tbnz	x19, #63, 53a8 <w123+0xe8>
    53a0:	eb3342ff 	cmp	x23, w19, uxtw
    53a4:	5400046d 	b.le	5430 <w123+0x170>
    53a8:	f94006d5 	ldr	x21, [x22, #8]
    53ac:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    53b0:	cb1502f5 	sub	x21, x23, x21
    53b4:	910006a1 	add	x1, x21, #0x1
    53b8:	eb00003f 	cmp	x1, x0
    53bc:	54fffd68 	b.hi	5368 <w123+0xa8>  // b.pmore
    53c0:	f9400ec0 	ldr	x0, [x22, #24]
    53c4:	eb00003f 	cmp	x1, x0
    53c8:	5400006d 	b.le	53d4 <w123+0x114>
    53cc:	aa1603e0 	mov	x0, x22
    53d0:	97ffff51 	bl	5114 <fwp_tape_grow.constprop.0>
    53d4:	f100027f 	cmp	x19, #0x0
    53d8:	9e670282 	fmov	d2, x20
    53dc:	da9fa273 	csinv	x19, x19, xzr, ge	// ge = tcont
    53e0:	8b1506b5 	add	x21, x21, x21, lsl #1
    53e4:	f94012c2 	ldr	x2, [x22, #32]
    53e8:	4e181e62 	mov	v2.d[1], x19
    53ec:	d37df2b5 	lsl	x21, x21, #3
    53f0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    53f4:	8b150040 	add	x0, x2, x21
    53f8:	92607e81 	and	x1, x20, #0xffffffff00000000
    53fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5400:	aa170021 	orr	x1, x1, x23
    5404:	0ea12842 	xtn	v2.2s, v2.2d
    5408:	910006f7 	add	x23, x23, #0x1
    540c:	fc356842 	str	d2, [x2, x21]
    5410:	6d00a400 	stp	d0, d9, [x0, #8]
    5414:	9e660100 	fmov	x0, d8
    5418:	f9000ad7 	str	x23, [x22, #16]
    541c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5420:	f9401bf7 	ldr	x23, [sp, #48]
    5424:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5428:	a8c57bfd 	ldp	x29, x30, [sp], #80
    542c:	d65f03c0 	ret
    5430:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    5434:	910d0000 	add	x0, x0, #0x340
    5438:	97fffb32 	bl	4100 <fwp_trap>
    543c:	9e660100 	fmov	x0, d8
    5440:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    5444:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5448:	a8c57bfd 	ldp	x29, x30, [sp], #80
    544c:	d65f03c0 	ret
    5450:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    5454:	910b2000 	add	x0, x0, #0x2c8
    5458:	97fffb2a 	bl	4100 <fwp_trap>
    545c:	d503201f 	nop

0000000000005460 <w120>:
    5460:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5464:	910003fd 	mov	x29, sp
    5468:	a90153f3 	stp	x19, x20, [sp, #16]
    546c:	aa0203f3 	mov	x19, x2
    5470:	a9025bf5 	stp	x21, x22, [sp, #32]
    5474:	aa0003f6 	mov	x22, x0
    5478:	aa0103f5 	mov	x21, x1
    547c:	a90363f7 	stp	x23, x24, [sp, #48]
    5480:	f90023f9 	str	x25, [sp, #64]
    5484:	fd0027ea 	str	d10, [sp, #72]
    5488:	1e60080a 	fmul	d10, d0, d0
    548c:	6d0527e8 	stp	d8, d9, [sp, #80]
    5490:	1e604008 	fmov	d8, d0
    5494:	1e604029 	fmov	d9, d1
    5498:	b7f82500 	tbnz	x0, #63, 5938 <w120+0x4d8>
    549c:	9360fc14 	asr	x20, x0, #32
    54a0:	f9400040 	ldr	x0, [x2]
    54a4:	eb14001f 	cmp	x0, x20
    54a8:	54002340 	b.eq	5910 <w120+0x4b0>  // b.none
    54ac:	aa1403e0 	mov	x0, x20
    54b0:	97fffd18 	bl	4910 <fwp_tape_of>
    54b4:	aa0003f7 	mov	x23, x0
    54b8:	f9402800 	ldr	x0, [x0, #80]
    54bc:	b4000080 	cbz	x0, 54cc <w120+0x6c>
    54c0:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    54c4:	910c4000 	add	x0, x0, #0x310
    54c8:	97fffb0e 	bl	4100 <fwp_trap>
    54cc:	a9005e74 	stp	x20, x23, [x19]
    54d0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54d4:	f9400af8 	ldr	x24, [x23, #16]
    54d8:	eb00031f 	cmp	x24, x0
    54dc:	5400210c 	b.gt	58fc <w120+0x49c>
    54e0:	eb36431f 	cmp	x24, w22, uxtw
    54e4:	5400206d 	b.le	58f0 <w120+0x490>
    54e8:	f94006f4 	ldr	x20, [x23, #8]
    54ec:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54f0:	cb140314 	sub	x20, x24, x20
    54f4:	91000681 	add	x1, x20, #0x1
    54f8:	eb00003f 	cmp	x1, x0
    54fc:	54002008 	b.hi	58fc <w120+0x49c>  // b.pmore
    5500:	f9400ee0 	ldr	x0, [x23, #24]
    5504:	eb00003f 	cmp	x1, x0
    5508:	5400006d 	b.le	5514 <w120+0xb4>
    550c:	aa1703e0 	mov	x0, x23
    5510:	97ffff01 	bl	5114 <fwp_tape_grow.constprop.0>
    5514:	8b140681 	add	x1, x20, x20, lsl #1
    5518:	92607ed4 	and	x20, x22, #0xffffffff00000000
    551c:	f94012e2 	ldr	x2, [x23, #32]
    5520:	d37df021 	lsl	x1, x1, #3
    5524:	aa180294 	orr	x20, x20, x24
    5528:	91000718 	add	x24, x24, #0x1
    552c:	8b010040 	add	x0, x2, x1
    5530:	b8216856 	str	w22, [x2, x1]
    5534:	9360fe99 	asr	x25, x20, #32
    5538:	b9000416 	str	w22, [x0, #4]
    553c:	6d00a008 	stp	d8, d8, [x0, #8]
    5540:	f9000af8 	str	x24, [x23, #16]
    5544:	b7f80075 	tbnz	x21, #63, 5550 <w120+0xf0>
    5548:	eb95833f 	cmp	x25, x21, asr #32
    554c:	540021c1 	b.ne	5984 <w120+0x524>  // b.any
    5550:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    5554:	1e6a3929 	fsub	d9, d9, d10
    5558:	3dc34400 	ldr	q0, [x0, #3344]
    555c:	3d801be0 	str	q0, [sp, #96]
    5560:	f9400260 	ldr	x0, [x19]
    5564:	eb19001f 	cmp	x0, x25
    5568:	54001d00 	b.eq	5908 <w120+0x4a8>  // b.none
    556c:	aa1903e0 	mov	x0, x25
    5570:	97fffce8 	bl	4910 <fwp_tape_of>
    5574:	aa0003f8 	mov	x24, x0
    5578:	f9402800 	ldr	x0, [x0, #80]
    557c:	b5fffa20 	cbnz	x0, 54c0 <w120+0x60>
    5580:	a9006279 	stp	x25, x24, [x19]
    5584:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5588:	f9400b19 	ldr	x25, [x24, #16]
    558c:	eb00033f 	cmp	x25, x0
    5590:	54001b6c 	b.gt	58fc <w120+0x49c>
    5594:	eb34433f 	cmp	x25, w20, uxtw
    5598:	54001acd 	b.le	58f0 <w120+0x490>
    559c:	b7f80075 	tbnz	x21, #63, 55a8 <w120+0x148>
    55a0:	eb35433f 	cmp	x25, w21, uxtw
    55a4:	54001a6d 	b.le	58f0 <w120+0x490>
    55a8:	f9400717 	ldr	x23, [x24, #8]
    55ac:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    55b0:	cb170337 	sub	x23, x25, x23
    55b4:	910006e1 	add	x1, x23, #0x1
    55b8:	eb00003f 	cmp	x1, x0
    55bc:	54001a08 	b.hi	58fc <w120+0x49c>  // b.pmore
    55c0:	f9400f00 	ldr	x0, [x24, #24]
    55c4:	eb00003f 	cmp	x1, x0
    55c8:	5400006d 	b.le	55d4 <w120+0x174>
    55cc:	aa1803e0 	mov	x0, x24
    55d0:	97fffed1 	bl	5114 <fwp_tape_grow.constprop.0>
    55d4:	f10002bf 	cmp	x21, #0x0
    55d8:	9e670282 	fmov	d2, x20
    55dc:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    55e0:	9a81a2b5 	csel	x21, x21, x1, ge	// ge = tcont
    55e4:	f9401300 	ldr	x0, [x24, #32]
    55e8:	4e181ea2 	mov	v2.d[1], x21
    55ec:	8b1706f7 	add	x23, x23, x23, lsl #1
    55f0:	91000722 	add	x2, x25, #0x1
    55f4:	3dc01be0 	ldr	q0, [sp, #96]
    55f8:	d37df2f7 	lsl	x23, x23, #3
    55fc:	0ea12842 	xtn	v2.2s, v2.2d
    5600:	8b170003 	add	x3, x0, x23
    5604:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5608:	92607e94 	and	x20, x20, #0xffffffff00000000
    560c:	aa190294 	orr	x20, x20, x25
    5610:	1e68394a 	fsub	d10, d10, d8
    5614:	fc376802 	str	d2, [x0, x23]
    5618:	3c808060 	stur	q0, [x3, #8]
    561c:	f9000b02 	str	x2, [x24, #16]
    5620:	b7f81b96 	tbnz	x22, #63, 5990 <w120+0x530>
    5624:	f9400260 	ldr	x0, [x19]
    5628:	9360fed5 	asr	x21, x22, #32
    562c:	eb15001f 	cmp	x0, x21
    5630:	54001800 	b.eq	5930 <w120+0x4d0>  // b.none
    5634:	aa1503e0 	mov	x0, x21
    5638:	97fffcb6 	bl	4910 <fwp_tape_of>
    563c:	aa0003f7 	mov	x23, x0
    5640:	f9402800 	ldr	x0, [x0, #80]
    5644:	b5fff3e0 	cbnz	x0, 54c0 <w120+0x60>
    5648:	a9005e75 	stp	x21, x23, [x19]
    564c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5650:	f9400af8 	ldr	x24, [x23, #16]
    5654:	eb00031f 	cmp	x24, x0
    5658:	5400152c 	b.gt	58fc <w120+0x49c>
    565c:	eb36431f 	cmp	x24, w22, uxtw
    5660:	5400148d 	b.le	58f0 <w120+0x490>
    5664:	f94006f5 	ldr	x21, [x23, #8]
    5668:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    566c:	cb150315 	sub	x21, x24, x21
    5670:	910006a1 	add	x1, x21, #0x1
    5674:	eb00003f 	cmp	x1, x0
    5678:	54001428 	b.hi	58fc <w120+0x49c>  // b.pmore
    567c:	f9400ee0 	ldr	x0, [x23, #24]
    5680:	eb00003f 	cmp	x1, x0
    5684:	5400006d 	b.le	5690 <w120+0x230>
    5688:	aa1703e0 	mov	x0, x23
    568c:	97fffea2 	bl	5114 <fwp_tape_grow.constprop.0>
    5690:	8b1506b5 	add	x21, x21, x21, lsl #1
    5694:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    5698:	f94012e2 	ldr	x2, [x23, #32]
    569c:	d37df2a1 	lsl	x1, x21, #3
    56a0:	3dc34400 	ldr	q0, [x0, #3344]
    56a4:	8b010040 	add	x0, x2, x1
    56a8:	b8216856 	str	w22, [x2, x1]
    56ac:	92607ec3 	and	x3, x22, #0xffffffff00000000
    56b0:	12800001 	mov	w1, #0xffffffff            	// #-1
    56b4:	aa180075 	orr	x21, x3, x24
    56b8:	b9000401 	str	w1, [x0, #4]
    56bc:	91000718 	add	x24, x24, #0x1
    56c0:	3c808000 	stur	q0, [x0, #8]
    56c4:	f9000af8 	str	x24, [x23, #16]
    56c8:	f9400260 	ldr	x0, [x19]
    56cc:	9360fe96 	asr	x22, x20, #32
    56d0:	1e690928 	fmul	d8, d9, d9
    56d4:	eb16001f 	cmp	x0, x22
    56d8:	54001280 	b.eq	5928 <w120+0x4c8>  // b.none
    56dc:	aa1603e0 	mov	x0, x22
    56e0:	97fffc8c 	bl	4910 <fwp_tape_of>
    56e4:	aa0003f7 	mov	x23, x0
    56e8:	f9402800 	ldr	x0, [x0, #80]
    56ec:	b5ffeea0 	cbnz	x0, 54c0 <w120+0x60>
    56f0:	a9005e76 	stp	x22, x23, [x19]
    56f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    56f8:	f9400af9 	ldr	x25, [x23, #16]
    56fc:	eb00033f 	cmp	x25, x0
    5700:	54000fec 	b.gt	58fc <w120+0x49c>
    5704:	eb34433f 	cmp	x25, w20, uxtw
    5708:	54000f4d 	b.le	58f0 <w120+0x490>
    570c:	f94006f6 	ldr	x22, [x23, #8]
    5710:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5714:	cb160336 	sub	x22, x25, x22
    5718:	910006c1 	add	x1, x22, #0x1
    571c:	eb00003f 	cmp	x1, x0
    5720:	54000ee8 	b.hi	58fc <w120+0x49c>  // b.pmore
    5724:	f9400ee0 	ldr	x0, [x23, #24]
    5728:	eb00003f 	cmp	x1, x0
    572c:	5400006d 	b.le	5738 <w120+0x2d8>
    5730:	aa1703e0 	mov	x0, x23
    5734:	97fffe78 	bl	5114 <fwp_tape_grow.constprop.0>
    5738:	8b1606d6 	add	x22, x22, x22, lsl #1
    573c:	92607e98 	and	x24, x20, #0xffffffff00000000
    5740:	f94012e0 	ldr	x0, [x23, #32]
    5744:	d37df2d6 	lsl	x22, x22, #3
    5748:	f9400262 	ldr	x2, [x19]
    574c:	8b160001 	add	x1, x0, x22
    5750:	b8366814 	str	w20, [x0, x22]
    5754:	aa190318 	orr	x24, x24, x25
    5758:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    575c:	9e670000 	fmov	d0, x0
    5760:	b9000434 	str	w20, [x1, #4]
    5764:	91000739 	add	x25, x25, #0x1
    5768:	6d00a429 	stp	d9, d9, [x1, #8]
    576c:	9360ff14 	asr	x20, x24, #32
    5770:	1e600908 	fmul	d8, d8, d0
    5774:	f9000af9 	str	x25, [x23, #16]
    5778:	eb14005f 	cmp	x2, x20
    577c:	54000d20 	b.eq	5920 <w120+0x4c0>  // b.none
    5780:	aa1403e0 	mov	x0, x20
    5784:	97fffc63 	bl	4910 <fwp_tape_of>
    5788:	aa0003f6 	mov	x22, x0
    578c:	f9402800 	ldr	x0, [x0, #80]
    5790:	b5ffe980 	cbnz	x0, 54c0 <w120+0x60>
    5794:	a9005a74 	stp	x20, x22, [x19]
    5798:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    579c:	f9400ad7 	ldr	x23, [x22, #16]
    57a0:	eb0002ff 	cmp	x23, x0
    57a4:	54000acc 	b.gt	58fc <w120+0x49c>
    57a8:	eb3842ff 	cmp	x23, w24, uxtw
    57ac:	54000a2d 	b.le	58f0 <w120+0x490>
    57b0:	f94006d4 	ldr	x20, [x22, #8]
    57b4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    57b8:	cb1402f4 	sub	x20, x23, x20
    57bc:	91000681 	add	x1, x20, #0x1
    57c0:	eb00003f 	cmp	x1, x0
    57c4:	540009c8 	b.hi	58fc <w120+0x49c>  // b.pmore
    57c8:	f9400ec0 	ldr	x0, [x22, #24]
    57cc:	eb00003f 	cmp	x1, x0
    57d0:	5400006d 	b.le	57dc <w120+0x37c>
    57d4:	aa1603e0 	mov	x0, x22
    57d8:	97fffe4f 	bl	5114 <fwp_tape_grow.constprop.0>
    57dc:	8b140694 	add	x20, x20, x20, lsl #1
    57e0:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    57e4:	f94012c1 	ldr	x1, [x22, #32]
    57e8:	d37df294 	lsl	x20, x20, #3
    57ec:	3dc34800 	ldr	q0, [x0, #3360]
    57f0:	8b140020 	add	x0, x1, x20
    57f4:	b8346838 	str	w24, [x1, x20]
    57f8:	12800002 	mov	w2, #0xffffffff            	// #-1
    57fc:	92607f18 	and	x24, x24, #0xffffffff00000000
    5800:	910006e1 	add	x1, x23, #0x1
    5804:	b9000402 	str	w2, [x0, #4]
    5808:	1e6a0949 	fmul	d9, d10, d10
    580c:	3c808000 	stur	q0, [x0, #8]
    5810:	aa170318 	orr	x24, x24, x23
    5814:	aa1503e0 	mov	x0, x21
    5818:	f9000ac1 	str	x1, [x22, #16]
    581c:	b10006bf 	cmn	x21, #0x1
    5820:	540004e0 	b.eq	58bc <w120+0x45c>  // b.none
    5824:	f9400260 	ldr	x0, [x19]
    5828:	9360feb4 	asr	x20, x21, #32
    582c:	eb14001f 	cmp	x0, x20
    5830:	54000740 	b.eq	5918 <w120+0x4b8>  // b.none
    5834:	aa1403e0 	mov	x0, x20
    5838:	97fffc36 	bl	4910 <fwp_tape_of>
    583c:	aa0003f6 	mov	x22, x0
    5840:	f9402800 	ldr	x0, [x0, #80]
    5844:	b5ffe3e0 	cbnz	x0, 54c0 <w120+0x60>
    5848:	a9005a74 	stp	x20, x22, [x19]
    584c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5850:	f9400ad7 	ldr	x23, [x22, #16]
    5854:	eb0002ff 	cmp	x23, x0
    5858:	5400052c 	b.gt	58fc <w120+0x49c>
    585c:	eb3542ff 	cmp	x23, w21, uxtw
    5860:	5400048d 	b.le	58f0 <w120+0x490>
    5864:	f94006d4 	ldr	x20, [x22, #8]
    5868:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    586c:	cb1402f4 	sub	x20, x23, x20
    5870:	91000681 	add	x1, x20, #0x1
    5874:	eb00003f 	cmp	x1, x0
    5878:	54000428 	b.hi	58fc <w120+0x49c>  // b.pmore
    587c:	f9400ec0 	ldr	x0, [x22, #24]
    5880:	eb00003f 	cmp	x1, x0
    5884:	5400006d 	b.le	5890 <w120+0x430>
    5888:	aa1603e0 	mov	x0, x22
    588c:	97fffe22 	bl	5114 <fwp_tape_grow.constprop.0>
    5890:	8b140694 	add	x20, x20, x20, lsl #1
    5894:	92607ea0 	and	x0, x21, #0xffffffff00000000
    5898:	f94012c2 	ldr	x2, [x22, #32]
    589c:	d37df294 	lsl	x20, x20, #3
    58a0:	aa170000 	orr	x0, x0, x23
    58a4:	910006f7 	add	x23, x23, #0x1
    58a8:	8b140041 	add	x1, x2, x20
    58ac:	b8346855 	str	w21, [x2, x20]
    58b0:	b9000435 	str	w21, [x1, #4]
    58b4:	6d00a82a 	stp	d10, d10, [x1, #8]
    58b8:	f9000ad7 	str	x23, [x22, #16]
    58bc:	1e604101 	fmov	d1, d8
    58c0:	1e604120 	fmov	d0, d9
    58c4:	aa1303e2 	mov	x2, x19
    58c8:	aa1803e1 	mov	x1, x24
    58cc:	97fffe7d 	bl	52c0 <w123>
    58d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    58d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    58d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    58dc:	f94023f9 	ldr	x25, [sp, #64]
    58e0:	fd4027ea 	ldr	d10, [sp, #72]
    58e4:	6d4527e8 	ldp	d8, d9, [sp, #80]
    58e8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    58ec:	d65f03c0 	ret
    58f0:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    58f4:	910d0000 	add	x0, x0, #0x340
    58f8:	97fffa02 	bl	4100 <fwp_trap>
    58fc:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    5900:	910aa000 	add	x0, x0, #0x2a8
    5904:	97fff9ff 	bl	4100 <fwp_trap>
    5908:	f9400678 	ldr	x24, [x19, #8]
    590c:	17ffff1e 	b	5584 <w120+0x124>
    5910:	f9400457 	ldr	x23, [x2, #8]
    5914:	17fffeef 	b	54d0 <w120+0x70>
    5918:	f9400676 	ldr	x22, [x19, #8]
    591c:	17ffffcc 	b	584c <w120+0x3ec>
    5920:	f9400676 	ldr	x22, [x19, #8]
    5924:	17ffff9d 	b	5798 <w120+0x338>
    5928:	f9400677 	ldr	x23, [x19, #8]
    592c:	17ffff72 	b	56f4 <w120+0x294>
    5930:	f9400677 	ldr	x23, [x19, #8]
    5934:	17ffff46 	b	564c <w120+0x1ec>
    5938:	1e6a3829 	fsub	d9, d1, d10
    593c:	b6f80161 	tbz	x1, #63, 5968 <w120+0x508>
    5940:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5944:	1e690921 	fmul	d1, d9, d9
    5948:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    594c:	9e670002 	fmov	d2, x0
    5950:	1e683809 	fsub	d9, d0, d8
    5954:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5958:	aa1803e0 	mov	x0, x24
    595c:	1e620828 	fmul	d8, d1, d2
    5960:	1e690929 	fmul	d9, d9, d9
    5964:	17ffffd6 	b	58bc <w120+0x45c>
    5968:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    596c:	9360fc39 	asr	x25, x1, #32
    5970:	aa0103f4 	mov	x20, x1
    5974:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5978:	3dc34000 	ldr	q0, [x0, #3328]
    597c:	3d801be0 	str	q0, [sp, #96]
    5980:	17fffef8 	b	5560 <w120+0x100>
    5984:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    5988:	910b2000 	add	x0, x0, #0x2c8
    598c:	97fff9dd 	bl	4100 <fwp_trap>
    5990:	aa0103f5 	mov	x21, x1
    5994:	17ffff4d 	b	56c8 <w120+0x268>
    5998:	d503201f 	nop
    599c:	d503201f 	nop

00000000000059a0 <w176.constprop.0>:
    59a0:	d10183ff 	sub	sp, sp, #0x60
    59a4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    59a8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    59ac:	f947f421 	ldr	x1, [x1, #4072]
    59b0:	a9027bfd 	stp	x29, x30, [sp, #32]
    59b4:	910083fd 	add	x29, sp, #0x20
    59b8:	a9045bf5 	stp	x21, x22, [sp, #64]
    59bc:	f9400015 	ldr	x21, [x0]
    59c0:	f9400023 	ldr	x3, [x1]
    59c4:	f9000fe3 	str	x3, [sp, #24]
    59c8:	d2800003 	mov	x3, #0x0                   	// #0
    59cc:	a900ffe2 	stp	x2, xzr, [sp, #8]
    59d0:	b4000435 	cbz	x21, 5a54 <w176.constprop.0+0xb4>
    59d4:	2f00e400 	movi	d0, #0x0
    59d8:	91004016 	add	x22, x0, #0x10
    59dc:	a90353f3 	stp	x19, x20, [sp, #48]
    59e0:	91002014 	add	x20, x0, #0x8
    59e4:	d2800013 	mov	x19, #0x0                   	// #0
    59e8:	f9002bf7 	str	x23, [sp, #80]
    59ec:	910023f7 	add	x23, sp, #0x8
    59f0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    59f4:	aa0203e0 	mov	x0, x2
    59f8:	fc737a81 	ldr	d1, [x20, x19, lsl #3]
    59fc:	aa1703e2 	mov	x2, x23
    5a00:	91000a73 	add	x19, x19, #0x2
    5a04:	97fffe2f 	bl	52c0 <w123>
    5a08:	aa0103e2 	mov	x2, x1
    5a0c:	9e670000 	fmov	d0, x0
    5a10:	eb1302bf 	cmp	x21, x19
    5a14:	54fffee8 	b.hi	59f0 <w176.constprop.0+0x50>  // b.pmore
    5a18:	a94353f3 	ldp	x19, x20, [sp, #48]
    5a1c:	f9402bf7 	ldr	x23, [sp, #80]
    5a20:	9e660000 	fmov	x0, d0
    5a24:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    5a28:	f947f421 	ldr	x1, [x1, #4072]
    5a2c:	f9400fe4 	ldr	x4, [sp, #24]
    5a30:	f9400023 	ldr	x3, [x1]
    5a34:	eb030084 	subs	x4, x4, x3
    5a38:	d2800003 	mov	x3, #0x0                   	// #0
    5a3c:	54000101 	b.ne	5a5c <w176.constprop.0+0xbc>  // b.any
    5a40:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a44:	aa0203e1 	mov	x1, x2
    5a48:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5a4c:	910183ff 	add	sp, sp, #0x60
    5a50:	d65f03c0 	ret
    5a54:	2f00e400 	movi	d0, #0x0
    5a58:	17fffff2 	b	5a20 <w176.constprop.0+0x80>
    5a5c:	a90353f3 	stp	x19, x20, [sp, #48]
    5a60:	f9002bf7 	str	x23, [sp, #80]
    5a64:	97fff38b 	bl	2890 <__stack_chk_fail@plt>
    5a68:	d503201f 	nop
    5a6c:	d503201f 	nop

0000000000005a70 <fwp_rc_share>:
    5a70:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    5a74:	91170042 	add	x2, x2, #0x5c0
    5a78:	f949d843 	ldr	x3, [x2, #5040]
    5a7c:	f949ec41 	ldr	x1, [x2, #5080]
    5a80:	cb030000 	sub	x0, x0, x3
    5a84:	eb01401f 	cmp	x0, x1, lsl #16
    5a88:	540003a2 	b.cs	5afc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5a8c:	d350fc01 	lsr	x1, x0, #16
    5a90:	f949fc44 	ldr	x4, [x2, #5112]
    5a94:	8b010821 	add	x1, x1, x1, lsl #2
    5a98:	d37df021 	lsl	x1, x1, #3
    5a9c:	8b010083 	add	x3, x4, x1
    5aa0:	f9401062 	ldr	x2, [x3, #32]
    5aa4:	b40002c2 	cbz	x2, 5afc <fwp_rc_share+0x8c>
    5aa8:	38616881 	ldrb	w1, [x4, x1]
    5aac:	7100083f 	cmp	w1, #0x2
    5ab0:	54000220 	b.eq	5af4 <fwp_rc_share+0x84>  // b.none
    5ab4:	7100043f 	cmp	w1, #0x1
    5ab8:	54000221 	b.ne	5afc <fwp_rc_share+0x8c>  // b.any
    5abc:	29430464 	ldp	w4, w1, [x3, #24]
    5ac0:	92403c00 	and	x0, x0, #0xffff
    5ac4:	9b047c00 	mul	x0, x0, x4
    5ac8:	d360fc00 	lsr	x0, x0, #32
    5acc:	eb01001f 	cmp	x0, x1
    5ad0:	54000162 	b.cs	5afc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5ad4:	8b000042 	add	x2, x2, x0
    5ad8:	39400040 	ldrb	w0, [x2]
    5adc:	34000100 	cbz	w0, 5afc <fwp_rc_share+0x8c>
    5ae0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5ae4:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    5ae8:	910d8000 	add	x0, x0, #0x360
    5aec:	910003fd 	mov	x29, sp
    5af0:	97fff984 	bl	4100 <fwp_trap>
    5af4:	72003c1f 	tst	w0, #0xffff
    5af8:	54ffff00 	b.eq	5ad8 <fwp_rc_share+0x68>  // b.none
    5afc:	d65f03c0 	ret

0000000000005b00 <fwp_rc_free_arr>:
    5b00:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5b04:	91170063 	add	x3, x3, #0x5c0
    5b08:	f949d861 	ldr	x1, [x3, #5040]
    5b0c:	f949ec62 	ldr	x2, [x3, #5080]
    5b10:	cb010001 	sub	x1, x0, x1
    5b14:	eb02403f 	cmp	x1, x2, lsl #16
    5b18:	54000342 	b.cs	5b80 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5b1c:	d350fc22 	lsr	x2, x1, #16
    5b20:	f949fc65 	ldr	x5, [x3, #5112]
    5b24:	8b020842 	add	x2, x2, x2, lsl #2
    5b28:	d37df042 	lsl	x2, x2, #3
    5b2c:	8b0200a4 	add	x4, x5, x2
    5b30:	f9401083 	ldr	x3, [x4, #32]
    5b34:	b4000263 	cbz	x3, 5b80 <fwp_rc_free_arr+0x80>
    5b38:	386268a2 	ldrb	w2, [x5, x2]
    5b3c:	7100085f 	cmp	w2, #0x2
    5b40:	540001c0 	b.eq	5b78 <fwp_rc_free_arr+0x78>  // b.none
    5b44:	7100045f 	cmp	w2, #0x1
    5b48:	540001c1 	b.ne	5b80 <fwp_rc_free_arr+0x80>  // b.any
    5b4c:	29430885 	ldp	w5, w2, [x4, #24]
    5b50:	92403c21 	and	x1, x1, #0xffff
    5b54:	9b057c21 	mul	x1, x1, x5
    5b58:	d360fc21 	lsr	x1, x1, #32
    5b5c:	eb02003f 	cmp	x1, x2
    5b60:	54000102 	b.cs	5b80 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5b64:	8b010063 	add	x3, x3, x1
    5b68:	39400061 	ldrb	w1, [x3]
    5b6c:	7100043f 	cmp	w1, #0x1
    5b70:	54000081 	b.ne	5b80 <fwp_rc_free_arr+0x80>  // b.any
    5b74:	17fffa1f 	b	43f0 <fwp_mem_free>
    5b78:	72003c3f 	tst	w1, #0xffff
    5b7c:	54ffff60 	b.eq	5b68 <fwp_rc_free_arr+0x68>  // b.none
    5b80:	d65f03c0 	ret

0000000000005b84 <fwp_rc_dup>:
    5b84:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc20>
    5b88:	91170042 	add	x2, x2, #0x5c0
    5b8c:	f949d841 	ldr	x1, [x2, #5040]
    5b90:	f949ec43 	ldr	x3, [x2, #5080]
    5b94:	cb010001 	sub	x1, x0, x1
    5b98:	eb03403f 	cmp	x1, x3, lsl #16
    5b9c:	54000342 	b.cs	5c04 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5ba0:	d350fc20 	lsr	x0, x1, #16
    5ba4:	f949fc44 	ldr	x4, [x2, #5112]
    5ba8:	8b000800 	add	x0, x0, x0, lsl #2
    5bac:	d37df002 	lsl	x2, x0, #3
    5bb0:	8b020083 	add	x3, x4, x2
    5bb4:	f9401060 	ldr	x0, [x3, #32]
    5bb8:	b4000260 	cbz	x0, 5c04 <fwp_rc_dup+0x80>
    5bbc:	38626882 	ldrb	w2, [x4, x2]
    5bc0:	7100085f 	cmp	w2, #0x2
    5bc4:	54000220 	b.eq	5c08 <fwp_rc_dup+0x84>  // b.none
    5bc8:	7100045f 	cmp	w2, #0x1
    5bcc:	540001c1 	b.ne	5c04 <fwp_rc_dup+0x80>  // b.any
    5bd0:	29430864 	ldp	w4, w2, [x3, #24]
    5bd4:	92403c21 	and	x1, x1, #0xffff
    5bd8:	9b047c21 	mul	x1, x1, x4
    5bdc:	d360fc21 	lsr	x1, x1, #32
    5be0:	eb02003f 	cmp	x1, x2
    5be4:	54000102 	b.cs	5c04 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5be8:	8b010000 	add	x0, x0, x1
    5bec:	39400001 	ldrb	w1, [x0]
    5bf0:	340000a1 	cbz	w1, 5c04 <fwp_rc_dup+0x80>
    5bf4:	7103f43f 	cmp	w1, #0xfd
    5bf8:	540000e8 	b.hi	5c14 <fwp_rc_dup+0x90>  // b.pmore
    5bfc:	11000421 	add	w1, w1, #0x1
    5c00:	39000001 	strb	w1, [x0]
    5c04:	d65f03c0 	ret
    5c08:	72003c3f 	tst	w1, #0xffff
    5c0c:	54ffff00 	b.eq	5bec <fwp_rc_dup+0x68>  // b.none
    5c10:	d65f03c0 	ret
    5c14:	17fffa70 	b	45d4 <fwp_rc_wide_dup>
    5c18:	d503201f 	nop
    5c1c:	d503201f 	nop

0000000000005c20 <fwp_owned_entry173>:
    5c20:	d10103ff 	sub	sp, sp, #0x40
    5c24:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    5c28:	f947f442 	ldr	x2, [x2, #4072]
    5c2c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c30:	910083fd 	add	x29, sp, #0x20
    5c34:	a90353f3 	stp	x19, x20, [sp, #48]
    5c38:	f9400043 	ldr	x3, [x2]
    5c3c:	f9000fe3 	str	x3, [sp, #24]
    5c40:	d2800003 	mov	x3, #0x0                   	// #0
    5c44:	a9400c01 	ldp	x1, x3, [x0]
    5c48:	f9400802 	ldr	x2, [x0, #16]
    5c4c:	ab020022 	adds	x2, x1, x2
    5c50:	540006e6 	b.vs	5d2c <fwp_owned_entry173+0x10c>
    5c54:	910023e1 	add	x1, sp, #0x8
    5c58:	52800000 	mov	w0, #0x0                   	// #0
    5c5c:	a9008be3 	stp	x3, x2, [sp, #8]
    5c60:	97fffce5 	bl	4ff4 <fwp_data.part.0.constprop.0>
    5c64:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5c68:	91170063 	add	x3, x3, #0x5c0
    5c6c:	aa0003f3 	mov	x19, x0
    5c70:	f949d861 	ldr	x1, [x3, #5040]
    5c74:	f949ec60 	ldr	x0, [x3, #5080]
    5c78:	cb010261 	sub	x1, x19, x1
    5c7c:	eb00403f 	cmp	x1, x0, lsl #16
    5c80:	54000322 	b.cs	5ce4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5c84:	d350fc22 	lsr	x2, x1, #16
    5c88:	f949fc63 	ldr	x3, [x3, #5112]
    5c8c:	8b020842 	add	x2, x2, x2, lsl #2
    5c90:	d37df042 	lsl	x2, x2, #3
    5c94:	8b020060 	add	x0, x3, x2
    5c98:	f9401014 	ldr	x20, [x0, #32]
    5c9c:	b4000254 	cbz	x20, 5ce4 <fwp_owned_entry173+0xc4>
    5ca0:	38626862 	ldrb	w2, [x3, x2]
    5ca4:	7100085f 	cmp	w2, #0x2
    5ca8:	54000360 	b.eq	5d14 <fwp_owned_entry173+0xf4>  // b.none
    5cac:	7100045f 	cmp	w2, #0x1
    5cb0:	540001a1 	b.ne	5ce4 <fwp_owned_entry173+0xc4>  // b.any
    5cb4:	29430002 	ldp	w2, w0, [x0, #24]
    5cb8:	92403c21 	and	x1, x1, #0xffff
    5cbc:	9b027c21 	mul	x1, x1, x2
    5cc0:	d360fc21 	lsr	x1, x1, #32
    5cc4:	eb00003f 	cmp	x1, x0
    5cc8:	540000e2 	b.cs	5ce4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5ccc:	8b010294 	add	x20, x20, x1
    5cd0:	39400280 	ldrb	w0, [x20]
    5cd4:	7103fc1f 	cmp	w0, #0xff
    5cd8:	54000240 	b.eq	5d20 <fwp_owned_entry173+0x100>  // b.none
    5cdc:	52800020 	mov	w0, #0x1                   	// #1
    5ce0:	39000280 	strb	w0, [x20]
    5ce4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    5ce8:	f947f400 	ldr	x0, [x0, #4072]
    5cec:	f9400fe2 	ldr	x2, [sp, #24]
    5cf0:	f9400001 	ldr	x1, [x0]
    5cf4:	eb010042 	subs	x2, x2, x1
    5cf8:	d2800001 	mov	x1, #0x0                   	// #0
    5cfc:	540001a1 	b.ne	5d30 <fwp_owned_entry173+0x110>  // b.any
    5d00:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d04:	aa1303e0 	mov	x0, x19
    5d08:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d0c:	910103ff 	add	sp, sp, #0x40
    5d10:	d65f03c0 	ret
    5d14:	72003c3f 	tst	w1, #0xffff
    5d18:	54fffe61 	b.ne	5ce4 <fwp_owned_entry173+0xc4>  // b.any
    5d1c:	17ffffed 	b	5cd0 <fwp_owned_entry173+0xb0>
    5d20:	aa1403e0 	mov	x0, x20
    5d24:	97fff917 	bl	4180 <fwp_rc_forget_slot.part.0>
    5d28:	17ffffed 	b	5cdc <fwp_owned_entry173+0xbc>
    5d2c:	97fff355 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5d30:	97fff2d8 	bl	2890 <__stack_chk_fail@plt>

0000000000005d34 <e173>:
    5d34:	d10103ff 	sub	sp, sp, #0x40
    5d38:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    5d3c:	f947f442 	ldr	x2, [x2, #4072]
    5d40:	a9027bfd 	stp	x29, x30, [sp, #32]
    5d44:	910083fd 	add	x29, sp, #0x20
    5d48:	a90353f3 	stp	x19, x20, [sp, #48]
    5d4c:	f9400043 	ldr	x3, [x2]
    5d50:	f9000fe3 	str	x3, [sp, #24]
    5d54:	d2800003 	mov	x3, #0x0                   	// #0
    5d58:	a9400c01 	ldp	x1, x3, [x0]
    5d5c:	f9400802 	ldr	x2, [x0, #16]
    5d60:	ab020022 	adds	x2, x1, x2
    5d64:	54000726 	b.vs	5e48 <e173+0x114>
    5d68:	910023e1 	add	x1, sp, #0x8
    5d6c:	52800000 	mov	w0, #0x0                   	// #0
    5d70:	a9008be3 	stp	x3, x2, [sp, #8]
    5d74:	97fffca0 	bl	4ff4 <fwp_data.part.0.constprop.0>
    5d78:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc20>
    5d7c:	91170063 	add	x3, x3, #0x5c0
    5d80:	aa0003f3 	mov	x19, x0
    5d84:	f949d861 	ldr	x1, [x3, #5040]
    5d88:	f949ec60 	ldr	x0, [x3, #5080]
    5d8c:	cb010261 	sub	x1, x19, x1
    5d90:	eb00403f 	cmp	x1, x0, lsl #16
    5d94:	54000322 	b.cs	5df8 <e173+0xc4>  // b.hs, b.nlast
    5d98:	d350fc22 	lsr	x2, x1, #16
    5d9c:	f949fc63 	ldr	x3, [x3, #5112]
    5da0:	8b020842 	add	x2, x2, x2, lsl #2
    5da4:	d37df042 	lsl	x2, x2, #3
    5da8:	8b020060 	add	x0, x3, x2
    5dac:	f9401014 	ldr	x20, [x0, #32]
    5db0:	b4000254 	cbz	x20, 5df8 <e173+0xc4>
    5db4:	38626862 	ldrb	w2, [x3, x2]
    5db8:	7100085f 	cmp	w2, #0x2
    5dbc:	540003a0 	b.eq	5e30 <e173+0xfc>  // b.none
    5dc0:	7100045f 	cmp	w2, #0x1
    5dc4:	540001a1 	b.ne	5df8 <e173+0xc4>  // b.any
    5dc8:	29430002 	ldp	w2, w0, [x0, #24]
    5dcc:	92403c21 	and	x1, x1, #0xffff
    5dd0:	9b027c21 	mul	x1, x1, x2
    5dd4:	d360fc21 	lsr	x1, x1, #32
    5dd8:	eb00003f 	cmp	x1, x0
    5ddc:	540000e2 	b.cs	5df8 <e173+0xc4>  // b.hs, b.nlast
    5de0:	8b010294 	add	x20, x20, x1
    5de4:	39400280 	ldrb	w0, [x20]
    5de8:	7103fc1f 	cmp	w0, #0xff
    5dec:	54000280 	b.eq	5e3c <e173+0x108>  // b.none
    5df0:	52800020 	mov	w0, #0x1                   	// #1
    5df4:	39000280 	strb	w0, [x20]
    5df8:	aa1303e0 	mov	x0, x19
    5dfc:	97ffff1d 	bl	5a70 <fwp_rc_share>
    5e00:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    5e04:	f947f400 	ldr	x0, [x0, #4072]
    5e08:	f9400fe2 	ldr	x2, [sp, #24]
    5e0c:	f9400001 	ldr	x1, [x0]
    5e10:	eb010042 	subs	x2, x2, x1
    5e14:	d2800001 	mov	x1, #0x0                   	// #0
    5e18:	540001a1 	b.ne	5e4c <e173+0x118>  // b.any
    5e1c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5e20:	aa1303e0 	mov	x0, x19
    5e24:	a94353f3 	ldp	x19, x20, [sp, #48]
    5e28:	910103ff 	add	sp, sp, #0x40
    5e2c:	d65f03c0 	ret
    5e30:	72003c3f 	tst	w1, #0xffff
    5e34:	54fffe21 	b.ne	5df8 <e173+0xc4>  // b.any
    5e38:	17ffffeb 	b	5de4 <e173+0xb0>
    5e3c:	aa1403e0 	mov	x0, x20
    5e40:	97fff8d0 	bl	4180 <fwp_rc_forget_slot.part.0>
    5e44:	17ffffeb 	b	5df0 <e173+0xbc>
    5e48:	97fff30e 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5e4c:	97fff291 	bl	2890 <__stack_chk_fail@plt>

0000000000005e50 <fwp_drop0>:
    5e50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e54:	910003fd 	mov	x29, sp
    5e58:	a90153f3 	stp	x19, x20, [sp, #16]
    5e5c:	f90013f5 	str	x21, [sp, #32]
    5e60:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    5e64:	911702b4 	add	x20, x21, #0x5c0
    5e68:	f949da81 	ldr	x1, [x20, #5040]
    5e6c:	f949ee82 	ldr	x2, [x20, #5080]
    5e70:	cb010001 	sub	x1, x0, x1
    5e74:	eb02403f 	cmp	x1, x2, lsl #16
    5e78:	54000382 	b.cs	5ee8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e7c:	d350fc22 	lsr	x2, x1, #16
    5e80:	f949fe84 	ldr	x4, [x20, #5112]
    5e84:	8b020842 	add	x2, x2, x2, lsl #2
    5e88:	d37df042 	lsl	x2, x2, #3
    5e8c:	8b020083 	add	x3, x4, x2
    5e90:	f9401073 	ldr	x19, [x3, #32]
    5e94:	b40002b3 	cbz	x19, 5ee8 <fwp_drop0+0x98>
    5e98:	38626882 	ldrb	w2, [x4, x2]
    5e9c:	7100085f 	cmp	w2, #0x2
    5ea0:	540002c0 	b.eq	5ef8 <fwp_drop0+0xa8>  // b.none
    5ea4:	7100045f 	cmp	w2, #0x1
    5ea8:	54000201 	b.ne	5ee8 <fwp_drop0+0x98>  // b.any
    5eac:	29430864 	ldp	w4, w2, [x3, #24]
    5eb0:	92403c21 	and	x1, x1, #0xffff
    5eb4:	9b047c21 	mul	x1, x1, x4
    5eb8:	d360fc21 	lsr	x1, x1, #32
    5ebc:	eb02003f 	cmp	x1, x2
    5ec0:	54000142 	b.cs	5ee8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ec4:	8b010273 	add	x19, x19, x1
    5ec8:	39400261 	ldrb	w1, [x19]
    5ecc:	340000e1 	cbz	w1, 5ee8 <fwp_drop0+0x98>
    5ed0:	7100043f 	cmp	w1, #0x1
    5ed4:	540001e0 	b.eq	5f10 <fwp_drop0+0xc0>  // b.none
    5ed8:	7103fc3f 	cmp	w1, #0xff
    5edc:	540002e0 	b.eq	5f38 <fwp_drop0+0xe8>  // b.none
    5ee0:	51000421 	sub	w1, w1, #0x1
    5ee4:	39000261 	strb	w1, [x19]
    5ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5eec:	f94013f5 	ldr	x21, [sp, #32]
    5ef0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ef4:	d65f03c0 	ret
    5ef8:	72003c3f 	tst	w1, #0xffff
    5efc:	54fffe60 	b.eq	5ec8 <fwp_drop0+0x78>  // b.none
    5f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f04:	f94013f5 	ldr	x21, [sp, #32]
    5f08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f0c:	d65f03c0 	ret
    5f10:	f9400813 	ldr	x19, [x0, #16]
    5f14:	97fffefb 	bl	5b00 <fwp_rc_free_arr>
    5f18:	911702a0 	add	x0, x21, #0x5c0
    5f1c:	f949d801 	ldr	x1, [x0, #5040]
    5f20:	f949ec00 	ldr	x0, [x0, #5080]
    5f24:	cb010261 	sub	x1, x19, x1
    5f28:	eb00403f 	cmp	x1, x0, lsl #16
    5f2c:	54fffde2 	b.cs	5ee8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f30:	aa1303e0 	mov	x0, x19
    5f34:	17ffffd2 	b	5e7c <fwp_drop0+0x2c>
    5f38:	ca534660 	eor	x0, x19, x19, lsr #17
    5f3c:	911702b5 	add	x21, x21, #0x5c0
    5f40:	ca402400 	eor	x0, x0, x0, lsr #9
    5f44:	92401c00 	and	x0, x0, #0xff
    5f48:	910a2402 	add	x2, x0, #0x289
    5f4c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5f50:	8b020ea2 	add	x2, x21, x2, lsl #3
    5f54:	f94a2400 	ldr	x0, [x0, #5192]
    5f58:	b50000a0 	cbnz	x0, 5f6c <fwp_drop0+0x11c>
    5f5c:	14000013 	b	5fa8 <fwp_drop0+0x158>
    5f60:	91004002 	add	x2, x0, #0x10
    5f64:	f9400800 	ldr	x0, [x0, #16]
    5f68:	b4000200 	cbz	x0, 5fa8 <fwp_drop0+0x158>
    5f6c:	f9400001 	ldr	x1, [x0]
    5f70:	eb13003f 	cmp	x1, x19
    5f74:	54ffff61 	b.ne	5f60 <fwp_drop0+0x110>  // b.any
    5f78:	f9400041 	ldr	x1, [x2]
    5f7c:	f9400420 	ldr	x0, [x1, #8]
    5f80:	d1000400 	sub	x0, x0, #0x1
    5f84:	f9000420 	str	x0, [x1, #8]
    5f88:	f103f81f 	cmp	x0, #0xfe
    5f8c:	54fffae1 	b.ne	5ee8 <fwp_drop0+0x98>  // b.any
    5f90:	39400260 	ldrb	w0, [x19]
    5f94:	7103fc1f 	cmp	w0, #0xff
    5f98:	540000e0 	b.eq	5fb4 <fwp_drop0+0x164>  // b.none
    5f9c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5fa0:	39000260 	strb	w0, [x19]
    5fa4:	17ffffd1 	b	5ee8 <fwp_drop0+0x98>
    5fa8:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    5fac:	9103e000 	add	x0, x0, #0xf8
    5fb0:	97fff854 	bl	4100 <fwp_trap>
    5fb4:	aa1303e0 	mov	x0, x19
    5fb8:	97fff872 	bl	4180 <fwp_rc_forget_slot.part.0>
    5fbc:	17fffff8 	b	5f9c <fwp_drop0+0x14c>

0000000000005fc0 <fwp_drop1>:
    5fc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5fc4:	910003fd 	mov	x29, sp
    5fc8:	a90153f3 	stp	x19, x20, [sp, #16]
    5fcc:	f90013f5 	str	x21, [sp, #32]
    5fd0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc20>
    5fd4:	911702b4 	add	x20, x21, #0x5c0
    5fd8:	f949da81 	ldr	x1, [x20, #5040]
    5fdc:	f949ee82 	ldr	x2, [x20, #5080]
    5fe0:	cb010001 	sub	x1, x0, x1
    5fe4:	eb02403f 	cmp	x1, x2, lsl #16
    5fe8:	54000382 	b.cs	6058 <fwp_drop1+0x98>  // b.hs, b.nlast
    5fec:	d350fc22 	lsr	x2, x1, #16
    5ff0:	f949fe84 	ldr	x4, [x20, #5112]
    5ff4:	8b020842 	add	x2, x2, x2, lsl #2
    5ff8:	d37df042 	lsl	x2, x2, #3
    5ffc:	8b020083 	add	x3, x4, x2
    6000:	f9401073 	ldr	x19, [x3, #32]
    6004:	b40002b3 	cbz	x19, 6058 <fwp_drop1+0x98>
    6008:	38626882 	ldrb	w2, [x4, x2]
    600c:	7100085f 	cmp	w2, #0x2
    6010:	540002c0 	b.eq	6068 <fwp_drop1+0xa8>  // b.none
    6014:	7100045f 	cmp	w2, #0x1
    6018:	54000201 	b.ne	6058 <fwp_drop1+0x98>  // b.any
    601c:	29430864 	ldp	w4, w2, [x3, #24]
    6020:	92403c21 	and	x1, x1, #0xffff
    6024:	9b047c21 	mul	x1, x1, x4
    6028:	d360fc21 	lsr	x1, x1, #32
    602c:	eb02003f 	cmp	x1, x2
    6030:	54000142 	b.cs	6058 <fwp_drop1+0x98>  // b.hs, b.nlast
    6034:	8b010273 	add	x19, x19, x1
    6038:	39400261 	ldrb	w1, [x19]
    603c:	340000e1 	cbz	w1, 6058 <fwp_drop1+0x98>
    6040:	7100043f 	cmp	w1, #0x1
    6044:	540001e0 	b.eq	6080 <fwp_drop1+0xc0>  // b.none
    6048:	7103fc3f 	cmp	w1, #0xff
    604c:	540002e0 	b.eq	60a8 <fwp_drop1+0xe8>  // b.none
    6050:	51000421 	sub	w1, w1, #0x1
    6054:	39000261 	strb	w1, [x19]
    6058:	a94153f3 	ldp	x19, x20, [sp, #16]
    605c:	f94013f5 	ldr	x21, [sp, #32]
    6060:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6064:	d65f03c0 	ret
    6068:	72003c3f 	tst	w1, #0xffff
    606c:	54fffe60 	b.eq	6038 <fwp_drop1+0x78>  // b.none
    6070:	a94153f3 	ldp	x19, x20, [sp, #16]
    6074:	f94013f5 	ldr	x21, [sp, #32]
    6078:	a8c37bfd 	ldp	x29, x30, [sp], #48
    607c:	d65f03c0 	ret
    6080:	f9400813 	ldr	x19, [x0, #16]
    6084:	97fffe9f 	bl	5b00 <fwp_rc_free_arr>
    6088:	911702a0 	add	x0, x21, #0x5c0
    608c:	f949d801 	ldr	x1, [x0, #5040]
    6090:	f949ec00 	ldr	x0, [x0, #5080]
    6094:	cb010261 	sub	x1, x19, x1
    6098:	eb00403f 	cmp	x1, x0, lsl #16
    609c:	54fffde2 	b.cs	6058 <fwp_drop1+0x98>  // b.hs, b.nlast
    60a0:	aa1303e0 	mov	x0, x19
    60a4:	17ffffd2 	b	5fec <fwp_drop1+0x2c>
    60a8:	ca534660 	eor	x0, x19, x19, lsr #17
    60ac:	911702b5 	add	x21, x21, #0x5c0
    60b0:	ca402400 	eor	x0, x0, x0, lsr #9
    60b4:	92401c00 	and	x0, x0, #0xff
    60b8:	910a2402 	add	x2, x0, #0x289
    60bc:	8b000ea0 	add	x0, x21, x0, lsl #3
    60c0:	8b020ea2 	add	x2, x21, x2, lsl #3
    60c4:	f94a2400 	ldr	x0, [x0, #5192]
    60c8:	b50000a0 	cbnz	x0, 60dc <fwp_drop1+0x11c>
    60cc:	14000013 	b	6118 <fwp_drop1+0x158>
    60d0:	91004002 	add	x2, x0, #0x10
    60d4:	f9400800 	ldr	x0, [x0, #16]
    60d8:	b4000200 	cbz	x0, 6118 <fwp_drop1+0x158>
    60dc:	f9400001 	ldr	x1, [x0]
    60e0:	eb13003f 	cmp	x1, x19
    60e4:	54ffff61 	b.ne	60d0 <fwp_drop1+0x110>  // b.any
    60e8:	f9400041 	ldr	x1, [x2]
    60ec:	f9400420 	ldr	x0, [x1, #8]
    60f0:	d1000400 	sub	x0, x0, #0x1
    60f4:	f9000420 	str	x0, [x1, #8]
    60f8:	f103f81f 	cmp	x0, #0xfe
    60fc:	54fffae1 	b.ne	6058 <fwp_drop1+0x98>  // b.any
    6100:	39400260 	ldrb	w0, [x19]
    6104:	7103fc1f 	cmp	w0, #0xff
    6108:	540000e0 	b.eq	6124 <fwp_drop1+0x164>  // b.none
    610c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6110:	39000260 	strb	w0, [x19]
    6114:	17ffffd1 	b	6058 <fwp_drop1+0x98>
    6118:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    611c:	9103e000 	add	x0, x0, #0xf8
    6120:	97fff7f8 	bl	4100 <fwp_trap>
    6124:	aa1303e0 	mov	x0, x19
    6128:	97fff816 	bl	4180 <fwp_rc_forget_slot.part.0>
    612c:	17fffff8 	b	610c <fwp_drop1+0x14c>

0000000000006130 <fwp_closure_drop>:
    6130:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc20>
    6134:	911700a4 	add	x4, x5, #0x5c0
    6138:	aa0003e1 	mov	x1, x0
    613c:	f949d882 	ldr	x2, [x4, #5040]
    6140:	f949ec80 	ldr	x0, [x4, #5080]
    6144:	cb020022 	sub	x2, x1, x2
    6148:	eb00405f 	cmp	x2, x0, lsl #16
    614c:	54000662 	b.cs	6218 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6150:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6154:	d350fc43 	lsr	x3, x2, #16
    6158:	910003fd 	mov	x29, sp
    615c:	8b030863 	add	x3, x3, x3, lsl #2
    6160:	f949fc84 	ldr	x4, [x4, #5112]
    6164:	d37df063 	lsl	x3, x3, #3
    6168:	f9000bf3 	str	x19, [sp, #16]
    616c:	8b030080 	add	x0, x4, x3
    6170:	f9401013 	ldr	x19, [x0, #32]
    6174:	b40002b3 	cbz	x19, 61c8 <fwp_closure_drop+0x98>
    6178:	38636883 	ldrb	w3, [x4, x3]
    617c:	7100087f 	cmp	w3, #0x2
    6180:	54000420 	b.eq	6204 <fwp_closure_drop+0xd4>  // b.none
    6184:	7100047f 	cmp	w3, #0x1
    6188:	54000201 	b.ne	61c8 <fwp_closure_drop+0x98>  // b.any
    618c:	29430003 	ldp	w3, w0, [x0, #24]
    6190:	92403c42 	and	x2, x2, #0xffff
    6194:	9b037c42 	mul	x2, x2, x3
    6198:	d360fc42 	lsr	x2, x2, #32
    619c:	eb00005f 	cmp	x2, x0
    61a0:	54000142 	b.cs	61c8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    61a4:	8b020273 	add	x19, x19, x2
    61a8:	39400260 	ldrb	w0, [x19]
    61ac:	340000e0 	cbz	w0, 61c8 <fwp_closure_drop+0x98>
    61b0:	7100041f 	cmp	w0, #0x1
    61b4:	54000100 	b.eq	61d4 <fwp_closure_drop+0xa4>  // b.none
    61b8:	7103fc1f 	cmp	w0, #0xff
    61bc:	54000300 	b.eq	621c <fwp_closure_drop+0xec>  // b.none
    61c0:	51000400 	sub	w0, w0, #0x1
    61c4:	39000260 	strb	w0, [x19]
    61c8:	f9400bf3 	ldr	x19, [sp, #16]
    61cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61d0:	d65f03c0 	ret
    61d4:	d53bd040 	mrs	x0, tpidr_el0
    61d8:	91400000 	add	x0, x0, #0x0, lsl #12
    61dc:	91004000 	add	x0, x0, #0x10
    61e0:	f9400000 	ldr	x0, [x0]
    61e4:	b4000080 	cbz	x0, 61f4 <fwp_closure_drop+0xc4>
    61e8:	f9400bf3 	ldr	x19, [sp, #16]
    61ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61f0:	17fff940 	b	46f0 <fwp_closure_drop_push>
    61f4:	f9400bf3 	ldr	x19, [sp, #16]
    61f8:	aa0103e0 	mov	x0, x1
    61fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6200:	17fff981 	b	4804 <fwp_closure_drop.part.0>
    6204:	72003c5f 	tst	w2, #0xffff
    6208:	54fffd00 	b.eq	61a8 <fwp_closure_drop+0x78>  // b.none
    620c:	f9400bf3 	ldr	x19, [sp, #16]
    6210:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6214:	d65f03c0 	ret
    6218:	d65f03c0 	ret
    621c:	ca534660 	eor	x0, x19, x19, lsr #17
    6220:	911700a5 	add	x5, x5, #0x5c0
    6224:	ca402400 	eor	x0, x0, x0, lsr #9
    6228:	92401c00 	and	x0, x0, #0xff
    622c:	910a2402 	add	x2, x0, #0x289
    6230:	8b000ca0 	add	x0, x5, x0, lsl #3
    6234:	8b020ca2 	add	x2, x5, x2, lsl #3
    6238:	f94a2400 	ldr	x0, [x0, #5192]
    623c:	b50000a0 	cbnz	x0, 6250 <fwp_closure_drop+0x120>
    6240:	14000013 	b	628c <fwp_closure_drop+0x15c>
    6244:	91004002 	add	x2, x0, #0x10
    6248:	f9400800 	ldr	x0, [x0, #16]
    624c:	b4000200 	cbz	x0, 628c <fwp_closure_drop+0x15c>
    6250:	f9400001 	ldr	x1, [x0]
    6254:	eb13003f 	cmp	x1, x19
    6258:	54ffff61 	b.ne	6244 <fwp_closure_drop+0x114>  // b.any
    625c:	f9400041 	ldr	x1, [x2]
    6260:	f9400420 	ldr	x0, [x1, #8]
    6264:	d1000400 	sub	x0, x0, #0x1
    6268:	f9000420 	str	x0, [x1, #8]
    626c:	f103f81f 	cmp	x0, #0xfe
    6270:	54fffac1 	b.ne	61c8 <fwp_closure_drop+0x98>  // b.any
    6274:	39400260 	ldrb	w0, [x19]
    6278:	7103fc1f 	cmp	w0, #0xff
    627c:	540000e0 	b.eq	6298 <fwp_closure_drop+0x168>  // b.none
    6280:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6284:	39000260 	strb	w0, [x19]
    6288:	17ffffd0 	b	61c8 <fwp_closure_drop+0x98>
    628c:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    6290:	9103e000 	add	x0, x0, #0xf8
    6294:	97fff79b 	bl	4100 <fwp_trap>
    6298:	aa1303e0 	mov	x0, x19
    629c:	97fff7b9 	bl	4180 <fwp_rc_forget_slot.part.0>
    62a0:	17fffff8 	b	6280 <fwp_closure_drop+0x150>

00000000000062a4 <fwp_owned_tape_release>:
    62a4:	b4000920 	cbz	x0, 63c8 <fwp_owned_tape_release+0x124>
    62a8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    62ac:	910003fd 	mov	x29, sp
    62b0:	a90153f3 	stp	x19, x20, [sp, #16]
    62b4:	aa0003f3 	mov	x19, x0
    62b8:	f9400000 	ldr	x0, [x0]
    62bc:	b4000060 	cbz	x0, 62c8 <fwp_owned_tape_release+0x24>
    62c0:	f9400661 	ldr	x1, [x19, #8]
    62c4:	f9000401 	str	x1, [x0, #8]
    62c8:	f9400661 	ldr	x1, [x19, #8]
    62cc:	b4000041 	cbz	x1, 62d4 <fwp_owned_tape_release+0x30>
    62d0:	f9000020 	str	x0, [x1]
    62d4:	f9400a60 	ldr	x0, [x19, #16]
    62d8:	f9403401 	ldr	x1, [x0, #104]
    62dc:	b40005a1 	cbz	x1, 6390 <fwp_owned_tape_release+0xec>
    62e0:	a9450a60 	ldp	x0, x2, [x19, #80]
    62e4:	eb00005f 	cmp	x2, x0
    62e8:	540002cd 	b.le	6340 <fwp_owned_tape_release+0x9c>
    62ec:	d2800014 	mov	x20, #0x0                   	// #0
    62f0:	f90013f5 	str	x21, [sp, #32]
    62f4:	d2800015 	mov	x21, #0x0                   	// #0
    62f8:	f9402260 	ldr	x0, [x19, #64]
    62fc:	910006b5 	add	x21, x21, #0x1
    6300:	f8746800 	ldr	x0, [x0, x20]
    6304:	d63f0020 	blr	x1
    6308:	f9402260 	ldr	x0, [x19, #64]
    630c:	f9400a61 	ldr	x1, [x19, #16]
    6310:	8b140000 	add	x0, x0, x20
    6314:	91004294 	add	x20, x20, #0x10
    6318:	f9400400 	ldr	x0, [x0, #8]
    631c:	f9403421 	ldr	x1, [x1, #104]
    6320:	d63f0020 	blr	x1
    6324:	a9450261 	ldp	x1, x0, [x19, #80]
    6328:	cb010000 	sub	x0, x0, x1
    632c:	eb15001f 	cmp	x0, x21
    6330:	f9400a60 	ldr	x0, [x19, #16]
    6334:	f9403401 	ldr	x1, [x0, #104]
    6338:	54fffe0c 	b.gt	62f8 <fwp_owned_tape_release+0x54>
    633c:	f94013f5 	ldr	x21, [sp, #32]
    6340:	f9403663 	ldr	x3, [x19, #104]
    6344:	f9401262 	ldr	x2, [x19, #32]
    6348:	f100007f 	cmp	x3, #0x0
    634c:	540001ed 	b.le	6388 <fwp_owned_tape_release+0xe4>
    6350:	d2800014 	mov	x20, #0x0                   	// #0
    6354:	d503201f 	nop
    6358:	f9402660 	ldr	x0, [x19, #72]
    635c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6360:	eb02001f 	cmp	x0, x2
    6364:	540000c0 	b.eq	637c <fwp_owned_tape_release+0xd8>  // b.none
    6368:	d63f0020 	blr	x1
    636c:	f9400a60 	ldr	x0, [x19, #16]
    6370:	f9401262 	ldr	x2, [x19, #32]
    6374:	f9403663 	ldr	x3, [x19, #104]
    6378:	f9403401 	ldr	x1, [x0, #104]
    637c:	91000694 	add	x20, x20, #0x1
    6380:	eb14007f 	cmp	x3, x20
    6384:	54fffeac 	b.gt	6358 <fwp_owned_tape_release+0xb4>
    6388:	aa0203e0 	mov	x0, x2
    638c:	d63f0020 	blr	x1
    6390:	f9401660 	ldr	x0, [x19, #40]
    6394:	97ffff67 	bl	6130 <fwp_closure_drop>
    6398:	f9401a60 	ldr	x0, [x19, #48]
    639c:	97ffff65 	bl	6130 <fwp_closure_drop>
    63a0:	f9401e60 	ldr	x0, [x19, #56]
    63a4:	97ffff63 	bl	6130 <fwp_closure_drop>
    63a8:	f9402260 	ldr	x0, [x19, #64]
    63ac:	97fff811 	bl	43f0 <fwp_mem_free>
    63b0:	f9402660 	ldr	x0, [x19, #72]
    63b4:	97fff80f 	bl	43f0 <fwp_mem_free>
    63b8:	aa1303e0 	mov	x0, x19
    63bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    63c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63c4:	17fff80b 	b	43f0 <fwp_mem_free>
    63c8:	d65f03c0 	ret
    63cc:	d503201f 	nop

00000000000063d0 <fwp_tape_finish>:
    63d0:	d101c3ff 	sub	sp, sp, #0x70
    63d4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    63d8:	f947f421 	ldr	x1, [x1, #4072]
    63dc:	a9037bfd 	stp	x29, x30, [sp, #48]
    63e0:	9100c3fd 	add	x29, sp, #0x30
    63e4:	a90453f3 	stp	x19, x20, [sp, #64]
    63e8:	a9055bf5 	stp	x21, x22, [sp, #80]
    63ec:	a90663f7 	stp	x23, x24, [sp, #96]
    63f0:	d00000d8 	adrp	x24, 20000 <__data_start>
    63f4:	9101c316 	add	x22, x24, #0x70
    63f8:	f9400022 	ldr	x2, [x1]
    63fc:	f90017e2 	str	x2, [sp, #40]
    6400:	d2800002 	mov	x2, #0x0                   	// #0
    6404:	910222c0 	add	x0, x22, #0x88
    6408:	97fff41e 	bl	3480 <fwp_tape_buffers_dispose>
    640c:	f9005adf 	str	xzr, [x22, #176]
    6410:	f94062c0 	ldr	x0, [x22, #192]
    6414:	f100001f 	cmp	x0, #0x0
    6418:	540002cd 	b.le	6470 <fwp_tape_finish+0xa0>
    641c:	910003f7 	mov	x23, sp
    6420:	d2800015 	mov	x21, #0x0                   	// #0
    6424:	d2800014 	mov	x20, #0x0                   	// #0
    6428:	f94002d3 	ldr	x19, [x22]
    642c:	91000694 	add	x20, x20, #0x1
    6430:	8b150273 	add	x19, x19, x21
    6434:	910162b5 	add	x21, x21, #0x58
    6438:	aa1303e0 	mov	x0, x19
    643c:	97fff2d5 	bl	2f90 <fwp_tape_unlink_scope>
    6440:	aa1703e0 	mov	x0, x23
    6444:	3dc00a60 	ldr	q0, [x19, #32]
    6448:	f9401a61 	ldr	x1, [x19, #48]
    644c:	f9000be1 	str	x1, [sp, #16]
    6450:	3d8003e0 	str	q0, [sp]
    6454:	97fff40b 	bl	3480 <fwp_tape_buffers_dispose>
    6458:	f9402a60 	ldr	x0, [x19, #80]
    645c:	97ffff92 	bl	62a4 <fwp_owned_tape_release>
    6460:	f9002a7f 	str	xzr, [x19, #80]
    6464:	f94062c0 	ldr	x0, [x22, #192]
    6468:	eb14001f 	cmp	x0, x20
    646c:	54fffdec 	b.gt	6428 <fwp_tape_finish+0x58>
    6470:	f9403b00 	ldr	x0, [x24, #112]
    6474:	9101c313 	add	x19, x24, #0x70
    6478:	97fff136 	bl	2950 <free@plt>
    647c:	f9003b1f 	str	xzr, [x24, #112]
    6480:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    6484:	f947f400 	ldr	x0, [x0, #4072]
    6488:	f900627f 	str	xzr, [x19, #192]
    648c:	a90d7e7f 	stp	xzr, xzr, [x19, #208]
    6490:	f94017e2 	ldr	x2, [sp, #40]
    6494:	f9400001 	ldr	x1, [x0]
    6498:	eb010042 	subs	x2, x2, x1
    649c:	d2800001 	mov	x1, #0x0                   	// #0
    64a0:	540000e1 	b.ne	64bc <fwp_tape_finish+0xec>  // b.any
    64a4:	a9437bfd 	ldp	x29, x30, [sp, #48]
    64a8:	a94453f3 	ldp	x19, x20, [sp, #64]
    64ac:	a9455bf5 	ldp	x21, x22, [sp, #80]
    64b0:	a94663f7 	ldp	x23, x24, [sp, #96]
    64b4:	9101c3ff 	add	sp, sp, #0x70
    64b8:	d65f03c0 	ret
    64bc:	97fff0f5 	bl	2890 <__stack_chk_fail@plt>

00000000000064c0 <fwp_tape_scope_release>:
    64c0:	d10203ff 	sub	sp, sp, #0x80
    64c4:	a9037bfd 	stp	x29, x30, [sp, #48]
    64c8:	9100c3fd 	add	x29, sp, #0x30
    64cc:	a90453f3 	stp	x19, x20, [sp, #64]
    64d0:	aa0003f4 	mov	x20, x0
    64d4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    64d8:	f947f400 	ldr	x0, [x0, #4072]
    64dc:	b9400285 	ldr	w5, [x20]
    64e0:	f9400001 	ldr	x1, [x0]
    64e4:	f90017e1 	str	x1, [sp, #40]
    64e8:	d2800001 	mov	x1, #0x0                   	// #0
    64ec:	37f806e5 	tbnz	w5, #31, 65c8 <fwp_tape_scope_release+0x108>
    64f0:	a90663f7 	stp	x23, x24, [sp, #96]
    64f4:	d2917478 	mov	x24, #0x8ba3                	// #35747
    64f8:	f2b745d8 	movk	x24, #0xba2e, lsl #16
    64fc:	f2d45d18 	movk	x24, #0xa2e8, lsl #32
    6500:	d00000d3 	adrp	x19, 20000 <__data_start>
    6504:	910003f7 	mov	x23, sp
    6508:	9101c273 	add	x19, x19, #0x70
    650c:	f2e5d178 	movk	x24, #0x2e8b, lsl #48
    6510:	a9055bf5 	stp	x21, x22, [sp, #80]
    6514:	52800b16 	mov	w22, #0x58                  	// #88
    6518:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    651c:	f9003bf9 	str	x25, [sp, #112]
    6520:	14000006 	b	6538 <fwp_tape_scope_release+0x78>
    6524:	97fff3d7 	bl	3480 <fwp_tape_buffers_dispose>
    6528:	aa1903e0 	mov	x0, x25
    652c:	97ffff5e 	bl	62a4 <fwp_owned_tape_release>
    6530:	b9400285 	ldr	w5, [x20]
    6534:	37f80445 	tbnz	w5, #31, 65bc <fwp_tape_scope_release+0xfc>
    6538:	f9400266 	ldr	x6, [x19]
    653c:	9b367ca5 	smull	x5, w5, w22
    6540:	8b0500c0 	add	x0, x6, x5
    6544:	97fff293 	bl	2f90 <fwp_tape_unlink_scope>
    6548:	3dc00800 	ldr	q0, [x0, #32]
    654c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6550:	f9400c03 	ldr	x3, [x0, #24]
    6554:	3d8003e0 	str	q0, [sp]
    6558:	b86568c1 	ldr	w1, [x6, x5]
    655c:	f9401802 	ldr	x2, [x0, #48]
    6560:	a9010fe2 	stp	x2, x3, [sp, #16]
    6564:	f9401c02 	ldr	x2, [x0, #56]
    6568:	b900041f 	str	wzr, [x0, #4]
    656c:	f9402819 	ldr	x25, [x0, #80]
    6570:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6574:	f9000c1f 	str	xzr, [x0, #24]
    6578:	f90013e2 	str	x2, [sp, #32]
    657c:	f900181f 	str	xzr, [x0, #48]
    6580:	f9001c1f 	str	xzr, [x0, #56]
    6584:	f900281f 	str	xzr, [x0, #80]
    6588:	6b15003f 	cmp	w1, w21
    658c:	540000e8 	b.hi	65a8 <fwp_tape_scope_release+0xe8>  // b.pmore
    6590:	9343fca5 	asr	x5, x5, #3
    6594:	f9406e60 	ldr	x0, [x19, #216]
    6598:	9b187ca5 	mul	x5, x5, x24
    659c:	eb0000bf 	cmp	x5, x0
    65a0:	5400004a 	b.ge	65a8 <fwp_tape_scope_release+0xe8>  // b.tcont
    65a4:	f9006e65 	str	x5, [x19, #216]
    65a8:	aa1703e0 	mov	x0, x23
    65ac:	b5fffbd9 	cbnz	x25, 6524 <fwp_tape_scope_release+0x64>
    65b0:	97fff690 	bl	3ff0 <fwp_tape_buffers_release>
    65b4:	b9400285 	ldr	w5, [x20]
    65b8:	36fffc05 	tbz	w5, #31, 6538 <fwp_tape_scope_release+0x78>
    65bc:	a9455bf5 	ldp	x21, x22, [sp, #80]
    65c0:	a94663f7 	ldp	x23, x24, [sp, #96]
    65c4:	f9403bf9 	ldr	x25, [sp, #112]
    65c8:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    65cc:	f947f400 	ldr	x0, [x0, #4072]
    65d0:	f94017e2 	ldr	x2, [sp, #40]
    65d4:	f9400001 	ldr	x1, [x0]
    65d8:	eb010042 	subs	x2, x2, x1
    65dc:	d2800001 	mov	x1, #0x0                   	// #0
    65e0:	540000a1 	b.ne	65f4 <fwp_tape_scope_release+0x134>  // b.any
    65e4:	a9437bfd 	ldp	x29, x30, [sp, #48]
    65e8:	a94453f3 	ldp	x19, x20, [sp, #64]
    65ec:	910203ff 	add	sp, sp, #0x80
    65f0:	d65f03c0 	ret
    65f4:	a9055bf5 	stp	x21, x22, [sp, #80]
    65f8:	a90663f7 	stp	x23, x24, [sp, #96]
    65fc:	f9003bf9 	str	x25, [sp, #112]
    6600:	97fff0a4 	bl	2890 <__stack_chk_fail@plt>

0000000000006604 <fwp_drop4>:
    6604:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6608:	910003fd 	mov	x29, sp
    660c:	a9025bf5 	stp	x21, x22, [sp, #32]
    6610:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc20>
    6614:	911702d5 	add	x21, x22, #0x5c0
    6618:	a90153f3 	stp	x19, x20, [sp, #16]
    661c:	aa0003f3 	mov	x19, x0
    6620:	f949daa1 	ldr	x1, [x21, #5040]
    6624:	f949eea0 	ldr	x0, [x21, #5080]
    6628:	cb010261 	sub	x1, x19, x1
    662c:	eb00403f 	cmp	x1, x0, lsl #16
    6630:	54000382 	b.cs	66a0 <fwp_drop4+0x9c>  // b.hs, b.nlast
    6634:	d350fc22 	lsr	x2, x1, #16
    6638:	f949fea3 	ldr	x3, [x21, #5112]
    663c:	8b020842 	add	x2, x2, x2, lsl #2
    6640:	d37df042 	lsl	x2, x2, #3
    6644:	8b020060 	add	x0, x3, x2
    6648:	f9401014 	ldr	x20, [x0, #32]
    664c:	b40002b4 	cbz	x20, 66a0 <fwp_drop4+0x9c>
    6650:	38626862 	ldrb	w2, [x3, x2]
    6654:	7100085f 	cmp	w2, #0x2
    6658:	540002c0 	b.eq	66b0 <fwp_drop4+0xac>  // b.none
    665c:	7100045f 	cmp	w2, #0x1
    6660:	54000201 	b.ne	66a0 <fwp_drop4+0x9c>  // b.any
    6664:	29430002 	ldp	w2, w0, [x0, #24]
    6668:	92403c21 	and	x1, x1, #0xffff
    666c:	9b027c21 	mul	x1, x1, x2
    6670:	d360fc21 	lsr	x1, x1, #32
    6674:	eb00003f 	cmp	x1, x0
    6678:	54000142 	b.cs	66a0 <fwp_drop4+0x9c>  // b.hs, b.nlast
    667c:	8b010294 	add	x20, x20, x1
    6680:	39400280 	ldrb	w0, [x20]
    6684:	340000e0 	cbz	w0, 66a0 <fwp_drop4+0x9c>
    6688:	7100041f 	cmp	w0, #0x1
    668c:	540001e0 	b.eq	66c8 <fwp_drop4+0xc4>  // b.none
    6690:	7103fc1f 	cmp	w0, #0xff
    6694:	540007e0 	b.eq	6790 <fwp_drop4+0x18c>  // b.none
    6698:	51000400 	sub	w0, w0, #0x1
    669c:	39000280 	strb	w0, [x20]
    66a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    66a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    66a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66ac:	d65f03c0 	ret
    66b0:	72003c3f 	tst	w1, #0xffff
    66b4:	54fffe60 	b.eq	6680 <fwp_drop4+0x7c>  // b.none
    66b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    66bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    66c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66c4:	d65f03c0 	ret
    66c8:	911702c2 	add	x2, x22, #0x5c0
    66cc:	f9400660 	ldr	x0, [x19, #8]
    66d0:	f949d841 	ldr	x1, [x2, #5040]
    66d4:	f949ec42 	ldr	x2, [x2, #5080]
    66d8:	cb010001 	sub	x1, x0, x1
    66dc:	eb02403f 	cmp	x1, x2, lsl #16
    66e0:	54000382 	b.cs	6750 <fwp_drop4+0x14c>  // b.hs, b.nlast
    66e4:	d350fc22 	lsr	x2, x1, #16
    66e8:	8b020842 	add	x2, x2, x2, lsl #2
    66ec:	d37df042 	lsl	x2, x2, #3
    66f0:	8b020064 	add	x4, x3, x2
    66f4:	f9401094 	ldr	x20, [x4, #32]
    66f8:	b40002d4 	cbz	x20, 6750 <fwp_drop4+0x14c>
    66fc:	38626862 	ldrb	w2, [x3, x2]
    6700:	7100085f 	cmp	w2, #0x2
    6704:	54000400 	b.eq	6784 <fwp_drop4+0x180>  // b.none
    6708:	7100045f 	cmp	w2, #0x1
    670c:	54000221 	b.ne	6750 <fwp_drop4+0x14c>  // b.any
    6710:	29430883 	ldp	w3, w2, [x4, #24]
    6714:	92403c21 	and	x1, x1, #0xffff
    6718:	9b037c21 	mul	x1, x1, x3
    671c:	d360fc21 	lsr	x1, x1, #32
    6720:	eb02003f 	cmp	x1, x2
    6724:	54000162 	b.cs	6750 <fwp_drop4+0x14c>  // b.hs, b.nlast
    6728:	8b010294 	add	x20, x20, x1
    672c:	39400281 	ldrb	w1, [x20]
    6730:	34000101 	cbz	w1, 6750 <fwp_drop4+0x14c>
    6734:	7100043f 	cmp	w1, #0x1
    6738:	54000220 	b.eq	677c <fwp_drop4+0x178>  // b.none
    673c:	7103fc3f 	cmp	w1, #0xff
    6740:	54000660 	b.eq	680c <fwp_drop4+0x208>  // b.none
    6744:	51000421 	sub	w1, w1, #0x1
    6748:	39000281 	strb	w1, [x20]
    674c:	d503201f 	nop
    6750:	f9400a74 	ldr	x20, [x19, #16]
    6754:	aa1303e0 	mov	x0, x19
    6758:	97fffcea 	bl	5b00 <fwp_rc_free_arr>
    675c:	911702c0 	add	x0, x22, #0x5c0
    6760:	f949d801 	ldr	x1, [x0, #5040]
    6764:	f949ec00 	ldr	x0, [x0, #5080]
    6768:	cb010281 	sub	x1, x20, x1
    676c:	eb00403f 	cmp	x1, x0, lsl #16
    6770:	54fff982 	b.cs	66a0 <fwp_drop4+0x9c>  // b.hs, b.nlast
    6774:	aa1403f3 	mov	x19, x20
    6778:	17ffffaf 	b	6634 <fwp_drop4+0x30>
    677c:	97fffce1 	bl	5b00 <fwp_rc_free_arr>
    6780:	17fffff4 	b	6750 <fwp_drop4+0x14c>
    6784:	72003c3f 	tst	w1, #0xffff
    6788:	54fffe41 	b.ne	6750 <fwp_drop4+0x14c>  // b.any
    678c:	17ffffe8 	b	672c <fwp_drop4+0x128>
    6790:	ca544681 	eor	x1, x20, x20, lsr #17
    6794:	911702c0 	add	x0, x22, #0x5c0
    6798:	ca412421 	eor	x1, x1, x1, lsr #9
    679c:	92401c21 	and	x1, x1, #0xff
    67a0:	910a2422 	add	x2, x1, #0x289
    67a4:	8b010c01 	add	x1, x0, x1, lsl #3
    67a8:	8b020c02 	add	x2, x0, x2, lsl #3
    67ac:	f94a2420 	ldr	x0, [x1, #5192]
    67b0:	b50000a0 	cbnz	x0, 67c4 <fwp_drop4+0x1c0>
    67b4:	14000013 	b	6800 <fwp_drop4+0x1fc>
    67b8:	91004002 	add	x2, x0, #0x10
    67bc:	f9400800 	ldr	x0, [x0, #16]
    67c0:	b4000200 	cbz	x0, 6800 <fwp_drop4+0x1fc>
    67c4:	f9400001 	ldr	x1, [x0]
    67c8:	eb14003f 	cmp	x1, x20
    67cc:	54ffff61 	b.ne	67b8 <fwp_drop4+0x1b4>  // b.any
    67d0:	f9400041 	ldr	x1, [x2]
    67d4:	f9400420 	ldr	x0, [x1, #8]
    67d8:	d1000400 	sub	x0, x0, #0x1
    67dc:	f9000420 	str	x0, [x1, #8]
    67e0:	f103f81f 	cmp	x0, #0xfe
    67e4:	54fff5e1 	b.ne	66a0 <fwp_drop4+0x9c>  // b.any
    67e8:	39400280 	ldrb	w0, [x20]
    67ec:	7103fc1f 	cmp	w0, #0xff
    67f0:	54000460 	b.eq	687c <fwp_drop4+0x278>  // b.none
    67f4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    67f8:	39000280 	strb	w0, [x20]
    67fc:	17ffffa9 	b	66a0 <fwp_drop4+0x9c>
    6800:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    6804:	9103e000 	add	x0, x0, #0xf8
    6808:	97fff63e 	bl	4100 <fwp_trap>
    680c:	ca544680 	eor	x0, x20, x20, lsr #17
    6810:	911702c1 	add	x1, x22, #0x5c0
    6814:	ca402400 	eor	x0, x0, x0, lsr #9
    6818:	92401c00 	and	x0, x0, #0xff
    681c:	910a2402 	add	x2, x0, #0x289
    6820:	8b000c20 	add	x0, x1, x0, lsl #3
    6824:	8b020c22 	add	x2, x1, x2, lsl #3
    6828:	f94a2400 	ldr	x0, [x0, #5192]
    682c:	b50000a0 	cbnz	x0, 6840 <fwp_drop4+0x23c>
    6830:	17fffff4 	b	6800 <fwp_drop4+0x1fc>
    6834:	91004002 	add	x2, x0, #0x10
    6838:	f9400800 	ldr	x0, [x0, #16]
    683c:	b4fffe20 	cbz	x0, 6800 <fwp_drop4+0x1fc>
    6840:	f9400001 	ldr	x1, [x0]
    6844:	eb14003f 	cmp	x1, x20
    6848:	54ffff61 	b.ne	6834 <fwp_drop4+0x230>  // b.any
    684c:	f9400041 	ldr	x1, [x2]
    6850:	f9400420 	ldr	x0, [x1, #8]
    6854:	d1000400 	sub	x0, x0, #0x1
    6858:	f9000420 	str	x0, [x1, #8]
    685c:	f103f81f 	cmp	x0, #0xfe
    6860:	54fff781 	b.ne	6750 <fwp_drop4+0x14c>  // b.any
    6864:	39400280 	ldrb	w0, [x20]
    6868:	7103fc1f 	cmp	w0, #0xff
    686c:	540000e0 	b.eq	6888 <fwp_drop4+0x284>  // b.none
    6870:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6874:	39000280 	strb	w0, [x20]
    6878:	17ffffb6 	b	6750 <fwp_drop4+0x14c>
    687c:	aa1403e0 	mov	x0, x20
    6880:	97fff640 	bl	4180 <fwp_rc_forget_slot.part.0>
    6884:	17ffffdc 	b	67f4 <fwp_drop4+0x1f0>
    6888:	aa1403e0 	mov	x0, x20
    688c:	97fff63d 	bl	4180 <fwp_rc_forget_slot.part.0>
    6890:	17fffff8 	b	6870 <fwp_drop4+0x26c>

0000000000006894 <fwp_arg_drop37>:
    6894:	7100003f 	cmp	w1, #0x0
    6898:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    689c:	54000041 	b.ne	68a4 <fwp_arg_drop37+0x10>  // b.any
    68a0:	d65f03c0 	ret
    68a4:	f9400000 	ldr	x0, [x0]
    68a8:	17ffff57 	b	6604 <fwp_drop4>
    68ac:	d503201f 	nop

00000000000068b0 <fwp_task_dispose>:
    68b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    68b4:	910003fd 	mov	x29, sp
    68b8:	f9000bf3 	str	x19, [sp, #16]
    68bc:	aa0003f3 	mov	x19, x0
    68c0:	39414000 	ldrb	w0, [x0, #80]
    68c4:	36000720 	tbz	w0, #0, 69a8 <fwp_task_dispose+0xf8>
    68c8:	f9400a60 	ldr	x0, [x19, #16]
    68cc:	b50006e0 	cbnz	x0, 69a8 <fwp_task_dispose+0xf8>
    68d0:	a9478660 	ldp	x0, x1, [x19, #120]
    68d4:	39014e7f 	strb	wzr, [x19, #83]
    68d8:	f9003e7f 	str	xzr, [x19, #120]
    68dc:	f100003f 	cmp	x1, #0x0
    68e0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    68e4:	54000040 	b.eq	68ec <fwp_task_dispose+0x3c>  // b.none
    68e8:	d63f0020 	blr	x1
    68ec:	f9405660 	ldr	x0, [x19, #168]
    68f0:	97fff6c0 	bl	43f0 <fwp_mem_free>
    68f4:	f900567f 	str	xzr, [x19, #168]
    68f8:	b9405e60 	ldr	w0, [x19, #92]
    68fc:	7100041f 	cmp	w0, #0x1
    6900:	54000420 	b.eq	6984 <fwp_task_dispose+0xd4>  // b.none
    6904:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    6908:	91170042 	add	x2, x2, #0x5c0
    690c:	f949d840 	ldr	x0, [x2, #5040]
    6910:	f949ec41 	ldr	x1, [x2, #5080]
    6914:	cb000260 	sub	x0, x19, x0
    6918:	eb01401f 	cmp	x0, x1, lsl #16
    691c:	540002e2 	b.cs	6978 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6920:	d350fc01 	lsr	x1, x0, #16
    6924:	f949fc44 	ldr	x4, [x2, #5112]
    6928:	8b010821 	add	x1, x1, x1, lsl #2
    692c:	d37df021 	lsl	x1, x1, #3
    6930:	8b010083 	add	x3, x4, x1
    6934:	f9401062 	ldr	x2, [x3, #32]
    6938:	b4000202 	cbz	x2, 6978 <fwp_task_dispose+0xc8>
    693c:	38616881 	ldrb	w1, [x4, x1]
    6940:	7100083f 	cmp	w1, #0x2
    6944:	54000280 	b.eq	6994 <fwp_task_dispose+0xe4>  // b.none
    6948:	7100043f 	cmp	w1, #0x1
    694c:	54000161 	b.ne	6978 <fwp_task_dispose+0xc8>  // b.any
    6950:	29430464 	ldp	w4, w1, [x3, #24]
    6954:	92403c00 	and	x0, x0, #0xffff
    6958:	9b047c00 	mul	x0, x0, x4
    695c:	d360fc00 	lsr	x0, x0, #32
    6960:	eb01001f 	cmp	x0, x1
    6964:	540000a2 	b.cs	6978 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6968:	8b000042 	add	x2, x2, x0
    696c:	39400040 	ldrb	w0, [x2]
    6970:	7100041f 	cmp	w0, #0x1
    6974:	54000080 	b.eq	6984 <fwp_task_dispose+0xd4>  // b.none
    6978:	f9400bf3 	ldr	x19, [sp, #16]
    697c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6980:	d65f03c0 	ret
    6984:	aa1303e0 	mov	x0, x19
    6988:	f9400bf3 	ldr	x19, [sp, #16]
    698c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6990:	17fff698 	b	43f0 <fwp_mem_free>
    6994:	72003c1f 	tst	w0, #0xffff
    6998:	54fffea0 	b.eq	696c <fwp_task_dispose+0xbc>  // b.none
    699c:	f9400bf3 	ldr	x19, [sp, #16]
    69a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69a4:	d65f03c0 	ret
    69a8:	97ffefce 	bl	28e0 <abort@plt>
    69ac:	d503201f 	nop

00000000000069b0 <fwp_free_zombie>:
    69b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    69b4:	910003fd 	mov	x29, sp
    69b8:	a90153f3 	stp	x19, x20, [sp, #16]
    69bc:	d00000d4 	adrp	x20, 20000 <__data_start>
    69c0:	9101c281 	add	x1, x20, #0x70
    69c4:	f9407033 	ldr	x19, [x1, #224]
    69c8:	b4000333 	cbz	x19, 6a2c <fwp_free_zombie+0x7c>
    69cc:	f9400820 	ldr	x0, [x1, #16]
    69d0:	eb00027f 	cmp	x19, x0
    69d4:	540002c0 	b.eq	6a2c <fwp_free_zombie+0x7c>  // b.none
    69d8:	b940e822 	ldr	w2, [x1, #232]
    69dc:	f9400a60 	ldr	x0, [x19, #16]
    69e0:	7100fc5f 	cmp	w2, #0x3f
    69e4:	5400078c 	b.gt	6ad4 <fwp_free_zombie+0x124>
    69e8:	9103c023 	add	x3, x1, #0xf0
    69ec:	11000444 	add	w4, w2, #0x1
    69f0:	b900e824 	str	w4, [x1, #232]
    69f4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    69f8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    69fc:	a9530261 	ldp	x1, x0, [x19, #304]
    6a00:	b4000741 	cbz	x1, 6ae8 <fwp_free_zombie+0x138>
    6a04:	f9009c20 	str	x0, [x1, #312]
    6a08:	b4000040 	cbz	x0, 6a10 <fwp_free_zombie+0x60>
    6a0c:	f9009801 	str	x1, [x0, #304]
    6a10:	9101c294 	add	x20, x20, #0x70
    6a14:	b9405e60 	ldr	w0, [x19, #92]
    6a18:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6a1c:	f900729f 	str	xzr, [x20, #224]
    6a20:	34000140 	cbz	w0, 6a48 <fwp_free_zombie+0x98>
    6a24:	7100041f 	cmp	w0, #0x1
    6a28:	54000080 	b.eq	6a38 <fwp_free_zombie+0x88>  // b.none
    6a2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a34:	d65f03c0 	ret
    6a38:	aa1303e0 	mov	x0, x19
    6a3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a44:	17ffff9b 	b	68b0 <fwp_task_dispose>
    6a48:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc20>
    6a4c:	91170082 	add	x2, x4, #0x5c0
    6a50:	f949d841 	ldr	x1, [x2, #5040]
    6a54:	f949ec40 	ldr	x0, [x2, #5080]
    6a58:	cb010261 	sub	x1, x19, x1
    6a5c:	eb00403f 	cmp	x1, x0, lsl #16
    6a60:	54fffe62 	b.cs	6a2c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6a64:	d350fc20 	lsr	x0, x1, #16
    6a68:	f949fc43 	ldr	x3, [x2, #5112]
    6a6c:	8b000800 	add	x0, x0, x0, lsl #2
    6a70:	d37df000 	lsl	x0, x0, #3
    6a74:	8b000062 	add	x2, x3, x0
    6a78:	f9401054 	ldr	x20, [x2, #32]
    6a7c:	b4fffd94 	cbz	x20, 6a2c <fwp_free_zombie+0x7c>
    6a80:	38606860 	ldrb	w0, [x3, x0]
    6a84:	7100081f 	cmp	w0, #0x2
    6a88:	54000360 	b.eq	6af4 <fwp_free_zombie+0x144>  // b.none
    6a8c:	7100041f 	cmp	w0, #0x1
    6a90:	54fffce1 	b.ne	6a2c <fwp_free_zombie+0x7c>  // b.any
    6a94:	29430043 	ldp	w3, w0, [x2, #24]
    6a98:	92403c21 	and	x1, x1, #0xffff
    6a9c:	9b037c21 	mul	x1, x1, x3
    6aa0:	d360fc21 	lsr	x1, x1, #32
    6aa4:	eb00003f 	cmp	x1, x0
    6aa8:	54fffc22 	b.cs	6a2c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6aac:	8b010294 	add	x20, x20, x1
    6ab0:	39400280 	ldrb	w0, [x20]
    6ab4:	34fffbc0 	cbz	w0, 6a2c <fwp_free_zombie+0x7c>
    6ab8:	7100041f 	cmp	w0, #0x1
    6abc:	54fffbe0 	b.eq	6a38 <fwp_free_zombie+0x88>  // b.none
    6ac0:	7103fc1f 	cmp	w0, #0xff
    6ac4:	540001e0 	b.eq	6b00 <fwp_free_zombie+0x150>  // b.none
    6ac8:	51000400 	sub	w0, w0, #0x1
    6acc:	39000280 	strb	w0, [x20]
    6ad0:	17ffffd7 	b	6a2c <fwp_free_zombie+0x7c>
    6ad4:	f9400e61 	ldr	x1, [x19, #24]
    6ad8:	97ffefb6 	bl	29b0 <munmap@plt>
    6adc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6ae0:	a9530261 	ldp	x1, x0, [x19, #304]
    6ae4:	b5fff901 	cbnz	x1, 6a04 <fwp_free_zombie+0x54>
    6ae8:	9101c282 	add	x2, x20, #0x70
    6aec:	f9017840 	str	x0, [x2, #752]
    6af0:	17ffffc6 	b	6a08 <fwp_free_zombie+0x58>
    6af4:	72003c3f 	tst	w1, #0xffff
    6af8:	54fff9a1 	b.ne	6a2c <fwp_free_zombie+0x7c>  // b.any
    6afc:	17ffffed 	b	6ab0 <fwp_free_zombie+0x100>
    6b00:	ca544680 	eor	x0, x20, x20, lsr #17
    6b04:	91170084 	add	x4, x4, #0x5c0
    6b08:	ca402400 	eor	x0, x0, x0, lsr #9
    6b0c:	92401c00 	and	x0, x0, #0xff
    6b10:	910a2402 	add	x2, x0, #0x289
    6b14:	8b000c80 	add	x0, x4, x0, lsl #3
    6b18:	8b020c82 	add	x2, x4, x2, lsl #3
    6b1c:	f94a2400 	ldr	x0, [x0, #5192]
    6b20:	b50000a0 	cbnz	x0, 6b34 <fwp_free_zombie+0x184>
    6b24:	14000013 	b	6b70 <fwp_free_zombie+0x1c0>
    6b28:	91004002 	add	x2, x0, #0x10
    6b2c:	f9400800 	ldr	x0, [x0, #16]
    6b30:	b4000200 	cbz	x0, 6b70 <fwp_free_zombie+0x1c0>
    6b34:	f9400001 	ldr	x1, [x0]
    6b38:	eb14003f 	cmp	x1, x20
    6b3c:	54ffff61 	b.ne	6b28 <fwp_free_zombie+0x178>  // b.any
    6b40:	f9400041 	ldr	x1, [x2]
    6b44:	f9400420 	ldr	x0, [x1, #8]
    6b48:	d1000400 	sub	x0, x0, #0x1
    6b4c:	f9000420 	str	x0, [x1, #8]
    6b50:	f103f81f 	cmp	x0, #0xfe
    6b54:	54fff6c1 	b.ne	6a2c <fwp_free_zombie+0x7c>  // b.any
    6b58:	39400280 	ldrb	w0, [x20]
    6b5c:	7103fc1f 	cmp	w0, #0xff
    6b60:	540000e0 	b.eq	6b7c <fwp_free_zombie+0x1cc>  // b.none
    6b64:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b68:	39000280 	strb	w0, [x20]
    6b6c:	17ffffb0 	b	6a2c <fwp_free_zombie+0x7c>
    6b70:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    6b74:	9103e000 	add	x0, x0, #0xf8
    6b78:	97fff562 	bl	4100 <fwp_trap>
    6b7c:	aa1403e0 	mov	x0, x20
    6b80:	97fff580 	bl	4180 <fwp_rc_forget_slot.part.0>
    6b84:	17fffff8 	b	6b64 <fwp_free_zombie+0x1b4>
    6b88:	d503201f 	nop
    6b8c:	d503201f 	nop

0000000000006b90 <fwp_block>:
    6b90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b94:	910003fd 	mov	x29, sp
    6b98:	a90153f3 	stp	x19, x20, [sp, #16]
    6b9c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6ba0:	9101c274 	add	x20, x19, #0x70
    6ba4:	f9404282 	ldr	x2, [x20, #128]
    6ba8:	b4000642 	cbz	x2, 6c70 <fwp_block+0xe0>
    6bac:	9101c261 	add	x1, x19, #0x70
    6bb0:	f9408040 	ldr	x0, [x2, #256]
    6bb4:	f9004020 	str	x0, [x1, #128]
    6bb8:	b40006a0 	cbz	x0, 6c8c <fwp_block+0xfc>
    6bbc:	d503201f 	nop
    6bc0:	9101c263 	add	x3, x19, #0x70
    6bc4:	3901505f 	strb	wzr, [x2, #84]
    6bc8:	f9400864 	ldr	x4, [x3, #16]
    6bcc:	eb02009f 	cmp	x4, x2
    6bd0:	54000440 	b.eq	6c58 <fwp_block+0xc8>  // b.none
    6bd4:	f9417c65 	ldr	x5, [x3, #760]
    6bd8:	f9000862 	str	x2, [x3, #16]
    6bdc:	f9400441 	ldr	x1, [x2, #8]
    6be0:	f9004885 	str	x5, [x4, #144]
    6be4:	f9418065 	ldr	x5, [x3, #768]
    6be8:	f9004c85 	str	x5, [x4, #152]
    6bec:	f9418465 	ldr	x5, [x3, #776]
    6bf0:	f9005085 	str	x5, [x4, #160]
    6bf4:	f9418865 	ldr	x5, [x3, #784]
    6bf8:	f9005485 	str	x5, [x4, #168]
    6bfc:	f9418c65 	ldr	x5, [x3, #792]
    6c00:	f9005885 	str	x5, [x4, #176]
    6c04:	f9419065 	ldr	x5, [x3, #800]
    6c08:	f9005c85 	str	x5, [x4, #184]
    6c0c:	f9419465 	ldr	x5, [x3, #808]
    6c10:	f9006085 	str	x5, [x4, #192]
    6c14:	f9400480 	ldr	x0, [x4, #8]
    6c18:	f9404844 	ldr	x4, [x2, #144]
    6c1c:	f9017c64 	str	x4, [x3, #760]
    6c20:	f9404c44 	ldr	x4, [x2, #152]
    6c24:	f9018064 	str	x4, [x3, #768]
    6c28:	f9405044 	ldr	x4, [x2, #160]
    6c2c:	f9018464 	str	x4, [x3, #776]
    6c30:	f9405444 	ldr	x4, [x2, #168]
    6c34:	f9018864 	str	x4, [x3, #784]
    6c38:	f9405844 	ldr	x4, [x2, #176]
    6c3c:	f9018c64 	str	x4, [x3, #792]
    6c40:	a94b8844 	ldp	x4, x2, [x2, #184]
    6c44:	f9019064 	str	x4, [x3, #800]
    6c48:	f9019462 	str	x2, [x3, #808]
    6c4c:	97ffef29 	bl	28f0 <swapcontext@plt>
    6c50:	97ffff58 	bl	69b0 <fwp_free_zombie>
    6c54:	d503201f 	nop
    6c58:	9101c260 	add	x0, x19, #0x70
    6c5c:	b9433000 	ldr	w0, [x0, #816]
    6c60:	340001a0 	cbz	w0, 6c94 <fwp_block+0x104>
    6c64:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c68:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c6c:	d65f03c0 	ret
    6c70:	97fff76c 	bl	4a20 <fwp_poll_events>
    6c74:	f9404282 	ldr	x2, [x20, #128]
    6c78:	b4ffffc2 	cbz	x2, 6c70 <fwp_block+0xe0>
    6c7c:	9101c261 	add	x1, x19, #0x70
    6c80:	f9408040 	ldr	x0, [x2, #256]
    6c84:	f9004020 	str	x0, [x1, #128]
    6c88:	b5fff9c0 	cbnz	x0, 6bc0 <fwp_block+0x30>
    6c8c:	f9003c3f 	str	xzr, [x1, #120]
    6c90:	17ffffcc 	b	6bc0 <fwp_block+0x30>
    6c94:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    6c98:	910e4000 	add	x0, x0, #0x390
    6c9c:	97ffef61 	bl	2a20 <getenv@plt>
    6ca0:	5284e202 	mov	w2, #0x2710                	// #10000
    6ca4:	b4000060 	cbz	x0, 6cb0 <fwp_block+0x120>
    6ca8:	39400001 	ldrb	w1, [x0]
    6cac:	350000c1 	cbnz	w1, 6cc4 <fwp_block+0x134>
    6cb0:	9101c273 	add	x19, x19, #0x70
    6cb4:	b9033262 	str	w2, [x19, #816]
    6cb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cbc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6cc0:	d65f03c0 	ret
    6cc4:	52800142 	mov	w2, #0xa                   	// #10
    6cc8:	d2800001 	mov	x1, #0x0                   	// #0
    6ccc:	97ffeea5 	bl	2760 <strtoll@plt>
    6cd0:	d1000403 	sub	x3, x0, #0x1
    6cd4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6cd8:	eb02007f 	cmp	x3, x2
    6cdc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6ce0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6ce4:	17fffff3 	b	6cb0 <fwp_block+0x120>
    6ce8:	d503201f 	nop
    6cec:	d503201f 	nop

0000000000006cf0 <fwp_drop10>:
    6cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6cf4:	910003fd 	mov	x29, sp
    6cf8:	a90153f3 	stp	x19, x20, [sp, #16]
    6cfc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc20>
    6d00:	f90013f5 	str	x21, [sp, #32]
    6d04:	91170275 	add	x21, x19, #0x5c0
    6d08:	f949daa1 	ldr	x1, [x21, #5040]
    6d0c:	f949eea2 	ldr	x2, [x21, #5080]
    6d10:	cb010001 	sub	x1, x0, x1
    6d14:	eb02403f 	cmp	x1, x2, lsl #16
    6d18:	54000382 	b.cs	6d88 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d1c:	d350fc22 	lsr	x2, x1, #16
    6d20:	f949fea3 	ldr	x3, [x21, #5112]
    6d24:	8b020842 	add	x2, x2, x2, lsl #2
    6d28:	d37df042 	lsl	x2, x2, #3
    6d2c:	8b020064 	add	x4, x3, x2
    6d30:	f9401094 	ldr	x20, [x4, #32]
    6d34:	b40002b4 	cbz	x20, 6d88 <fwp_drop10+0x98>
    6d38:	38626862 	ldrb	w2, [x3, x2]
    6d3c:	7100085f 	cmp	w2, #0x2
    6d40:	540007a0 	b.eq	6e34 <fwp_drop10+0x144>  // b.none
    6d44:	7100045f 	cmp	w2, #0x1
    6d48:	54000201 	b.ne	6d88 <fwp_drop10+0x98>  // b.any
    6d4c:	29430885 	ldp	w5, w2, [x4, #24]
    6d50:	92403c21 	and	x1, x1, #0xffff
    6d54:	9b057c21 	mul	x1, x1, x5
    6d58:	d360fc21 	lsr	x1, x1, #32
    6d5c:	eb02003f 	cmp	x1, x2
    6d60:	54000142 	b.cs	6d88 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d64:	8b010294 	add	x20, x20, x1
    6d68:	39400281 	ldrb	w1, [x20]
    6d6c:	340000e1 	cbz	w1, 6d88 <fwp_drop10+0x98>
    6d70:	7100043f 	cmp	w1, #0x1
    6d74:	54000120 	b.eq	6d98 <fwp_drop10+0xa8>  // b.none
    6d78:	7103fc3f 	cmp	w1, #0xff
    6d7c:	540007c0 	b.eq	6e74 <fwp_drop10+0x184>  // b.none
    6d80:	51000421 	sub	w1, w1, #0x1
    6d84:	39000281 	strb	w1, [x20]
    6d88:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d8c:	f94013f5 	ldr	x21, [sp, #32]
    6d90:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d94:	d65f03c0 	ret
    6d98:	f9400001 	ldr	x1, [x0]
    6d9c:	b7f80581 	tbnz	x1, #63, 6e4c <fwp_drop10+0x15c>
    6da0:	91170273 	add	x19, x19, #0x5c0
    6da4:	f949da61 	ldr	x1, [x19, #5040]
    6da8:	f949ee62 	ldr	x2, [x19, #5080]
    6dac:	cb010001 	sub	x1, x0, x1
    6db0:	eb02403f 	cmp	x1, x2, lsl #16
    6db4:	54fffea2 	b.cs	6d88 <fwp_drop10+0x98>  // b.hs, b.nlast
    6db8:	d350fc22 	lsr	x2, x1, #16
    6dbc:	8b020842 	add	x2, x2, x2, lsl #2
    6dc0:	d37df042 	lsl	x2, x2, #3
    6dc4:	8b020065 	add	x5, x3, x2
    6dc8:	f94010a4 	ldr	x4, [x5, #32]
    6dcc:	b4fffde4 	cbz	x4, 6d88 <fwp_drop10+0x98>
    6dd0:	38626862 	ldrb	w2, [x3, x2]
    6dd4:	7100085f 	cmp	w2, #0x2
    6dd8:	54000220 	b.eq	6e1c <fwp_drop10+0x12c>  // b.none
    6ddc:	7100045f 	cmp	w2, #0x1
    6de0:	54fffd41 	b.ne	6d88 <fwp_drop10+0x98>  // b.any
    6de4:	294308a3 	ldp	w3, w2, [x5, #24]
    6de8:	92403c21 	and	x1, x1, #0xffff
    6dec:	9b037c21 	mul	x1, x1, x3
    6df0:	d360fc21 	lsr	x1, x1, #32
    6df4:	eb02003f 	cmp	x1, x2
    6df8:	54fffc82 	b.cs	6d88 <fwp_drop10+0x98>  // b.hs, b.nlast
    6dfc:	8b010084 	add	x4, x4, x1
    6e00:	39400081 	ldrb	w1, [x4]
    6e04:	7100043f 	cmp	w1, #0x1
    6e08:	54fffc01 	b.ne	6d88 <fwp_drop10+0x98>  // b.any
    6e0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e10:	f94013f5 	ldr	x21, [sp, #32]
    6e14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e18:	17fff576 	b	43f0 <fwp_mem_free>
    6e1c:	72003c3f 	tst	w1, #0xffff
    6e20:	54ffff00 	b.eq	6e00 <fwp_drop10+0x110>  // b.none
    6e24:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e28:	f94013f5 	ldr	x21, [sp, #32]
    6e2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e30:	d65f03c0 	ret
    6e34:	72003c3f 	tst	w1, #0xffff
    6e38:	54fff980 	b.eq	6d68 <fwp_drop10+0x78>  // b.none
    6e3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e40:	f94013f5 	ldr	x21, [sp, #32]
    6e44:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e48:	d65f03c0 	ret
    6e4c:	f9400414 	ldr	x20, [x0, #8]
    6e50:	97fffb2c 	bl	5b00 <fwp_rc_free_arr>
    6e54:	91170260 	add	x0, x19, #0x5c0
    6e58:	f949d801 	ldr	x1, [x0, #5040]
    6e5c:	f949ec00 	ldr	x0, [x0, #5080]
    6e60:	cb010281 	sub	x1, x20, x1
    6e64:	eb00403f 	cmp	x1, x0, lsl #16
    6e68:	54fff902 	b.cs	6d88 <fwp_drop10+0x98>  // b.hs, b.nlast
    6e6c:	aa1403e0 	mov	x0, x20
    6e70:	17ffffab 	b	6d1c <fwp_drop10+0x2c>
    6e74:	ca544680 	eor	x0, x20, x20, lsr #17
    6e78:	91170273 	add	x19, x19, #0x5c0
    6e7c:	ca402400 	eor	x0, x0, x0, lsr #9
    6e80:	92401c00 	and	x0, x0, #0xff
    6e84:	910a2402 	add	x2, x0, #0x289
    6e88:	8b000e60 	add	x0, x19, x0, lsl #3
    6e8c:	8b020e62 	add	x2, x19, x2, lsl #3
    6e90:	f94a2400 	ldr	x0, [x0, #5192]
    6e94:	b50000a0 	cbnz	x0, 6ea8 <fwp_drop10+0x1b8>
    6e98:	14000013 	b	6ee4 <fwp_drop10+0x1f4>
    6e9c:	91004002 	add	x2, x0, #0x10
    6ea0:	f9400800 	ldr	x0, [x0, #16]
    6ea4:	b4000200 	cbz	x0, 6ee4 <fwp_drop10+0x1f4>
    6ea8:	f9400001 	ldr	x1, [x0]
    6eac:	eb14003f 	cmp	x1, x20
    6eb0:	54ffff61 	b.ne	6e9c <fwp_drop10+0x1ac>  // b.any
    6eb4:	f9400041 	ldr	x1, [x2]
    6eb8:	f9400420 	ldr	x0, [x1, #8]
    6ebc:	d1000400 	sub	x0, x0, #0x1
    6ec0:	f9000420 	str	x0, [x1, #8]
    6ec4:	f103f81f 	cmp	x0, #0xfe
    6ec8:	54fff601 	b.ne	6d88 <fwp_drop10+0x98>  // b.any
    6ecc:	39400280 	ldrb	w0, [x20]
    6ed0:	7103fc1f 	cmp	w0, #0xff
    6ed4:	540000e0 	b.eq	6ef0 <fwp_drop10+0x200>  // b.none
    6ed8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6edc:	39000280 	strb	w0, [x20]
    6ee0:	17ffffaa 	b	6d88 <fwp_drop10+0x98>
    6ee4:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    6ee8:	9103e000 	add	x0, x0, #0xf8
    6eec:	97fff485 	bl	4100 <fwp_trap>
    6ef0:	aa1403e0 	mov	x0, x20
    6ef4:	97fff4a3 	bl	4180 <fwp_rc_forget_slot.part.0>
    6ef8:	17fffff8 	b	6ed8 <fwp_drop10+0x1e8>
    6efc:	d503201f 	nop

0000000000006f00 <fwp_caps173>:
    6f00:	34000041 	cbz	w1, 6f08 <fwp_caps173+0x8>
    6f04:	d65f03c0 	ret
    6f08:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc20>
    6f0c:	91170063 	add	x3, x3, #0x5c0
    6f10:	f949d861 	ldr	x1, [x3, #5040]
    6f14:	f949ec62 	ldr	x2, [x3, #5080]
    6f18:	cb010001 	sub	x1, x0, x1
    6f1c:	eb02403f 	cmp	x1, x2, lsl #16
    6f20:	54ffff22 	b.cs	6f04 <fwp_caps173+0x4>  // b.hs, b.nlast
    6f24:	d350fc22 	lsr	x2, x1, #16
    6f28:	f949fc65 	ldr	x5, [x3, #5112]
    6f2c:	8b020842 	add	x2, x2, x2, lsl #2
    6f30:	d37df042 	lsl	x2, x2, #3
    6f34:	8b0200a4 	add	x4, x5, x2
    6f38:	f9401083 	ldr	x3, [x4, #32]
    6f3c:	b4fffe43 	cbz	x3, 6f04 <fwp_caps173+0x4>
    6f40:	386268a2 	ldrb	w2, [x5, x2]
    6f44:	7100085f 	cmp	w2, #0x2
    6f48:	540001c0 	b.eq	6f80 <fwp_caps173+0x80>  // b.none
    6f4c:	7100045f 	cmp	w2, #0x1
    6f50:	54fffda1 	b.ne	6f04 <fwp_caps173+0x4>  // b.any
    6f54:	29430885 	ldp	w5, w2, [x4, #24]
    6f58:	92403c21 	and	x1, x1, #0xffff
    6f5c:	9b057c21 	mul	x1, x1, x5
    6f60:	d360fc21 	lsr	x1, x1, #32
    6f64:	eb02003f 	cmp	x1, x2
    6f68:	54fffce2 	b.cs	6f04 <fwp_caps173+0x4>  // b.hs, b.nlast
    6f6c:	8b010063 	add	x3, x3, x1
    6f70:	39400061 	ldrb	w1, [x3]
    6f74:	7100043f 	cmp	w1, #0x1
    6f78:	54fffc61 	b.ne	6f04 <fwp_caps173+0x4>  // b.any
    6f7c:	17fff51d 	b	43f0 <fwp_mem_free>
    6f80:	72003c3f 	tst	w1, #0xffff
    6f84:	54ffff60 	b.eq	6f70 <fwp_caps173+0x70>  // b.none
    6f88:	d65f03c0 	ret
    6f8c:	d503201f 	nop

0000000000006f90 <f37>:
    6f90:	d10243ff 	sub	sp, sp, #0x90
    6f94:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    6f98:	f947f421 	ldr	x1, [x1, #4072]
    6f9c:	a9037bfd 	stp	x29, x30, [sp, #48]
    6fa0:	9100c3fd 	add	x29, sp, #0x30
    6fa4:	a9055bf5 	stp	x21, x22, [sp, #80]
    6fa8:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc20>
    6fac:	911702c3 	add	x3, x22, #0x5c0
    6fb0:	a90453f3 	stp	x19, x20, [sp, #64]
    6fb4:	aa0003f5 	mov	x21, x0
    6fb8:	a90663f7 	stp	x23, x24, [sp, #96]
    6fbc:	a90873fb 	stp	x27, x28, [sp, #128]
    6fc0:	f949ec62 	ldr	x2, [x3, #5080]
    6fc4:	f9400024 	ldr	x4, [x1]
    6fc8:	f90017e4 	str	x4, [sp, #40]
    6fcc:	d2800004 	mov	x4, #0x0                   	// #0
    6fd0:	f949d861 	ldr	x1, [x3, #5040]
    6fd4:	d370bc42 	lsl	x2, x2, #16
    6fd8:	b4001720 	cbz	x0, 72bc <f37+0x32c>
    6fdc:	f9400817 	ldr	x23, [x0, #16]
    6fe0:	cb0102e1 	sub	x1, x23, x1
    6fe4:	eb02003f 	cmp	x1, x2
    6fe8:	54000362 	b.cs	7054 <f37+0xc4>  // b.hs, b.nlast
    6fec:	f949fc60 	ldr	x0, [x3, #5112]
    6ff0:	d350fc22 	lsr	x2, x1, #16
    6ff4:	8b020842 	add	x2, x2, x2, lsl #2
    6ff8:	8b020c02 	add	x2, x0, x2, lsl #3
    6ffc:	f9401040 	ldr	x0, [x2, #32]
    7000:	b40002a0 	cbz	x0, 7054 <f37+0xc4>
    7004:	39400043 	ldrb	w3, [x2]
    7008:	7100087f 	cmp	w3, #0x2
    700c:	54001460 	b.eq	7298 <f37+0x308>  // b.none
    7010:	7100047f 	cmp	w3, #0x1
    7014:	540001c1 	b.ne	704c <f37+0xbc>  // b.any
    7018:	29430843 	ldp	w3, w2, [x2, #24]
    701c:	92403c21 	and	x1, x1, #0xffff
    7020:	9b037c21 	mul	x1, x1, x3
    7024:	d360fc21 	lsr	x1, x1, #32
    7028:	eb02003f 	cmp	x1, x2
    702c:	54000102 	b.cs	704c <f37+0xbc>  // b.hs, b.nlast
    7030:	8b010000 	add	x0, x0, x1
    7034:	39400001 	ldrb	w1, [x0]
    7038:	340000a1 	cbz	w1, 704c <f37+0xbc>
    703c:	7103f43f 	cmp	w1, #0xfd
    7040:	54001728 	b.hi	7324 <f37+0x394>  // b.pmore
    7044:	11000421 	add	w1, w1, #0x1
    7048:	39000001 	strb	w1, [x0]
    704c:	d2800002 	mov	x2, #0x0                   	// #0
    7050:	b40000f5 	cbz	x21, 706c <f37+0xdc>
    7054:	aa1503e1 	mov	x1, x21
    7058:	d2800002 	mov	x2, #0x0                   	// #0
    705c:	d503201f 	nop
    7060:	f9400821 	ldr	x1, [x1, #16]
    7064:	91000442 	add	x2, x2, #0x1
    7068:	b5ffffc1 	cbnz	x1, 7060 <f37+0xd0>
    706c:	b40012f7 	cbz	x23, 72c8 <f37+0x338>
    7070:	aa1703e1 	mov	x1, x23
    7074:	d2800003 	mov	x3, #0x0                   	// #0
    7078:	f9400821 	ldr	x1, [x1, #16]
    707c:	91000463 	add	x3, x3, #0x1
    7080:	b5ffffc1 	cbnz	x1, 7078 <f37+0xe8>
    7084:	eb02007f 	cmp	x3, x2
    7088:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    708c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7090:	eb00027f 	cmp	x19, x0
    7094:	54000fa8 	b.hi	7288 <f37+0x2f8>  // b.pmore
    7098:	d37ffa74 	lsl	x20, x19, #1
    709c:	52800041 	mov	w1, #0x2                   	// #2
    70a0:	91000680 	add	x0, x20, #0x1
    70a4:	d37df000 	lsl	x0, x0, #3
    70a8:	97fff78e 	bl	4ee0 <fwp_heap_alloc>
    70ac:	911702c1 	add	x1, x22, #0x5c0
    70b0:	aa0003fb 	mov	x27, x0
    70b4:	f9000014 	str	x20, [x0]
    70b8:	aa0103e0 	mov	x0, x1
    70bc:	f949d821 	ldr	x1, [x1, #5040]
    70c0:	f949ec00 	ldr	x0, [x0, #5080]
    70c4:	cb010361 	sub	x1, x27, x1
    70c8:	eb00403f 	cmp	x1, x0, lsl #16
    70cc:	54000342 	b.cs	7134 <f37+0x1a4>  // b.hs, b.nlast
    70d0:	911702c2 	add	x2, x22, #0x5c0
    70d4:	d350fc20 	lsr	x0, x1, #16
    70d8:	8b000800 	add	x0, x0, x0, lsl #2
    70dc:	f949fc43 	ldr	x3, [x2, #5112]
    70e0:	d37df002 	lsl	x2, x0, #3
    70e4:	8b020060 	add	x0, x3, x2
    70e8:	f9401014 	ldr	x20, [x0, #32]
    70ec:	b4000254 	cbz	x20, 7134 <f37+0x1a4>
    70f0:	38626862 	ldrb	w2, [x3, x2]
    70f4:	7100085f 	cmp	w2, #0x2
    70f8:	54000dc0 	b.eq	72b0 <f37+0x320>  // b.none
    70fc:	7100045f 	cmp	w2, #0x1
    7100:	540001a1 	b.ne	7134 <f37+0x1a4>  // b.any
    7104:	29430002 	ldp	w2, w0, [x0, #24]
    7108:	92403c21 	and	x1, x1, #0xffff
    710c:	9b027c21 	mul	x1, x1, x2
    7110:	d360fc21 	lsr	x1, x1, #32
    7114:	eb00003f 	cmp	x1, x0
    7118:	540000e2 	b.cs	7134 <f37+0x1a4>  // b.hs, b.nlast
    711c:	8b010294 	add	x20, x20, x1
    7120:	39400280 	ldrb	w0, [x20]
    7124:	7103fc1f 	cmp	w0, #0xff
    7128:	54001020 	b.eq	732c <f37+0x39c>  // b.none
    712c:	52800020 	mov	w0, #0x1                   	// #1
    7130:	39000280 	strb	w0, [x20]
    7134:	b4000333 	cbz	x19, 7198 <f37+0x208>
    7138:	8b131373 	add	x19, x27, x19, lsl #4
    713c:	aa1b03f4 	mov	x20, x27
    7140:	aa1703f8 	mov	x24, x23
    7144:	910023fc 	add	x28, sp, #0x8
    7148:	a9076bf9 	stp	x25, x26, [sp, #112]
    714c:	aa1503f9 	mov	x25, x21
    7150:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    7154:	d503201f 	nop
    7158:	f9400704 	ldr	x4, [x24, #8]
    715c:	aa1c03e2 	mov	x2, x28
    7160:	f9400723 	ldr	x3, [x25, #8]
    7164:	a900fffa 	stp	x26, xzr, [sp, #8]
    7168:	fd400481 	ldr	d1, [x4, #8]
    716c:	f9400881 	ldr	x1, [x4, #16]
    7170:	f9400860 	ldr	x0, [x3, #16]
    7174:	fd400460 	ldr	d0, [x3, #8]
    7178:	97fff8ba 	bl	5460 <w120>
    717c:	f9000680 	str	x0, [x20, #8]
    7180:	f8010e81 	str	x1, [x20, #16]!
    7184:	f9400b18 	ldr	x24, [x24, #16]
    7188:	f9400b39 	ldr	x25, [x25, #16]
    718c:	eb14027f 	cmp	x19, x20
    7190:	54fffe41 	b.ne	7158 <f37+0x1c8>  // b.any
    7194:	a9476bf9 	ldp	x25, x26, [sp, #112]
    7198:	aa1703e0 	mov	x0, x23
    719c:	97fffd1a 	bl	6604 <fwp_drop4>
    71a0:	911702d6 	add	x22, x22, #0x5c0
    71a4:	aa1503e0 	mov	x0, x21
    71a8:	97fffd17 	bl	6604 <fwp_drop4>
    71ac:	aa1b03e0 	mov	x0, x27
    71b0:	97fff9fc 	bl	59a0 <w176.constprop.0>
    71b4:	aa0103f3 	mov	x19, x1
    71b8:	aa0003f4 	mov	x20, x0
    71bc:	aa1b03e0 	mov	x0, x27
    71c0:	97fffecc 	bl	6cf0 <fwp_drop10>
    71c4:	910063e1 	add	x1, sp, #0x18
    71c8:	52800000 	mov	w0, #0x0                   	// #0
    71cc:	a901cff4 	stp	x20, x19, [sp, #24]
    71d0:	97fff789 	bl	4ff4 <fwp_data.part.0.constprop.0>
    71d4:	aa0003f3 	mov	x19, x0
    71d8:	f949dac1 	ldr	x1, [x22, #5040]
    71dc:	f949eec0 	ldr	x0, [x22, #5080]
    71e0:	cb010261 	sub	x1, x19, x1
    71e4:	eb00403f 	cmp	x1, x0, lsl #16
    71e8:	54000322 	b.cs	724c <f37+0x2bc>  // b.hs, b.nlast
    71ec:	d350fc22 	lsr	x2, x1, #16
    71f0:	f949fec3 	ldr	x3, [x22, #5112]
    71f4:	8b020842 	add	x2, x2, x2, lsl #2
    71f8:	d37df042 	lsl	x2, x2, #3
    71fc:	8b020060 	add	x0, x3, x2
    7200:	f9401014 	ldr	x20, [x0, #32]
    7204:	b4000254 	cbz	x20, 724c <f37+0x2bc>
    7208:	38626862 	ldrb	w2, [x3, x2]
    720c:	7100085f 	cmp	w2, #0x2
    7210:	540004a0 	b.eq	72a4 <f37+0x314>  // b.none
    7214:	7100045f 	cmp	w2, #0x1
    7218:	540001a1 	b.ne	724c <f37+0x2bc>  // b.any
    721c:	29430002 	ldp	w2, w0, [x0, #24]
    7220:	92403c21 	and	x1, x1, #0xffff
    7224:	9b027c21 	mul	x1, x1, x2
    7228:	d360fc21 	lsr	x1, x1, #32
    722c:	eb00003f 	cmp	x1, x0
    7230:	540000e2 	b.cs	724c <f37+0x2bc>  // b.hs, b.nlast
    7234:	8b010294 	add	x20, x20, x1
    7238:	39400280 	ldrb	w0, [x20]
    723c:	7103fc1f 	cmp	w0, #0xff
    7240:	540007c0 	b.eq	7338 <f37+0x3a8>  // b.none
    7244:	52800020 	mov	w0, #0x1                   	// #1
    7248:	39000280 	strb	w0, [x20]
    724c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7250:	f947f400 	ldr	x0, [x0, #4072]
    7254:	f94017e2 	ldr	x2, [sp, #40]
    7258:	f9400001 	ldr	x1, [x0]
    725c:	eb010042 	subs	x2, x2, x1
    7260:	d2800001 	mov	x1, #0x0                   	// #0
    7264:	54000701 	b.ne	7344 <f37+0x3b4>  // b.any
    7268:	a9437bfd 	ldp	x29, x30, [sp, #48]
    726c:	aa1303e0 	mov	x0, x19
    7270:	a94453f3 	ldp	x19, x20, [sp, #64]
    7274:	a9455bf5 	ldp	x21, x22, [sp, #80]
    7278:	a94663f7 	ldp	x23, x24, [sp, #96]
    727c:	a94873fb 	ldp	x27, x28, [sp, #128]
    7280:	910243ff 	add	sp, sp, #0x90
    7284:	d65f03c0 	ret
    7288:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    728c:	910e8000 	add	x0, x0, #0x3a0
    7290:	a9076bf9 	stp	x25, x26, [sp, #112]
    7294:	97fff39b 	bl	4100 <fwp_trap>
    7298:	72003c3f 	tst	w1, #0xffff
    729c:	54ffed81 	b.ne	704c <f37+0xbc>  // b.any
    72a0:	17ffff65 	b	7034 <f37+0xa4>
    72a4:	72003c3f 	tst	w1, #0xffff
    72a8:	54fffd21 	b.ne	724c <f37+0x2bc>  // b.any
    72ac:	17ffffe3 	b	7238 <f37+0x2a8>
    72b0:	72003c3f 	tst	w1, #0xffff
    72b4:	54fff401 	b.ne	7134 <f37+0x1a4>  // b.any
    72b8:	17ffff9a 	b	7120 <f37+0x190>
    72bc:	cb0103e1 	neg	x1, x1
    72c0:	eb02003f 	cmp	x1, x2
    72c4:	54000203 	b.cc	7304 <f37+0x374>  // b.lo, b.ul, b.last
    72c8:	52800041 	mov	w1, #0x2                   	// #2
    72cc:	d2800100 	mov	x0, #0x8                   	// #8
    72d0:	97fff704 	bl	4ee0 <fwp_heap_alloc>
    72d4:	aa0003e1 	mov	x1, x0
    72d8:	911702c0 	add	x0, x22, #0x5c0
    72dc:	aa0103fb 	mov	x27, x1
    72e0:	d2800017 	mov	x23, #0x0                   	// #0
    72e4:	f900003f 	str	xzr, [x1]
    72e8:	f949d801 	ldr	x1, [x0, #5040]
    72ec:	f949ec00 	ldr	x0, [x0, #5080]
    72f0:	cb010361 	sub	x1, x27, x1
    72f4:	eb00403f 	cmp	x1, x0, lsl #16
    72f8:	54fff502 	b.cs	7198 <f37+0x208>  // b.hs, b.nlast
    72fc:	d2800013 	mov	x19, #0x0                   	// #0
    7300:	17ffff74 	b	70d0 <f37+0x140>
    7304:	f949fc62 	ldr	x2, [x3, #5112]
    7308:	d350fc20 	lsr	x0, x1, #16
    730c:	8b000800 	add	x0, x0, x0, lsl #2
    7310:	8b000c42 	add	x2, x2, x0, lsl #3
    7314:	f9401040 	ldr	x0, [x2, #32]
    7318:	b4fffd80 	cbz	x0, 72c8 <f37+0x338>
    731c:	d2800017 	mov	x23, #0x0                   	// #0
    7320:	17ffff39 	b	7004 <f37+0x74>
    7324:	97fff4ac 	bl	45d4 <fwp_rc_wide_dup>
    7328:	17ffff49 	b	704c <f37+0xbc>
    732c:	aa1403e0 	mov	x0, x20
    7330:	97fff394 	bl	4180 <fwp_rc_forget_slot.part.0>
    7334:	17ffff7e 	b	712c <f37+0x19c>
    7338:	aa1403e0 	mov	x0, x20
    733c:	97fff391 	bl	4180 <fwp_rc_forget_slot.part.0>
    7340:	17ffffc1 	b	7244 <f37+0x2b4>
    7344:	a9076bf9 	stp	x25, x26, [sp, #112]
    7348:	97ffed52 	bl	2890 <__stack_chk_fail@plt>
    734c:	d503201f 	nop

0000000000007350 <fwp_owned_entry37>:
    7350:	f9400000 	ldr	x0, [x0]
    7354:	17ffff0f 	b	6f90 <f37>
    7358:	d503201f 	nop
    735c:	d503201f 	nop

0000000000007360 <e37>:
    7360:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7364:	910003fd 	mov	x29, sp
    7368:	f9000bf3 	str	x19, [sp, #16]
    736c:	f9400013 	ldr	x19, [x0]
    7370:	aa1303e0 	mov	x0, x19
    7374:	97fff9bf 	bl	5a70 <fwp_rc_share>
    7378:	aa1303e0 	mov	x0, x19
    737c:	97ffff05 	bl	6f90 <f37>
    7380:	aa0003f3 	mov	x19, x0
    7384:	97fff9bb 	bl	5a70 <fwp_rc_share>
    7388:	aa1303e0 	mov	x0, x19
    738c:	f9400bf3 	ldr	x19, [sp, #16]
    7390:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7394:	d65f03c0 	ret
    7398:	d503201f 	nop
    739c:	d503201f 	nop

00000000000073a0 <fwp_args37>:
    73a0:	7100003f 	cmp	w1, #0x0
    73a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    73a8:	54000041 	b.ne	73b0 <fwp_args37+0x10>  // b.any
    73ac:	d65f03c0 	ret
    73b0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    73b4:	91170042 	add	x2, x2, #0x5c0
    73b8:	f9400001 	ldr	x1, [x0]
    73bc:	f949d843 	ldr	x3, [x2, #5040]
    73c0:	f949ec40 	ldr	x0, [x2, #5080]
    73c4:	cb030021 	sub	x1, x1, x3
    73c8:	eb00403f 	cmp	x1, x0, lsl #16
    73cc:	54ffff02 	b.cs	73ac <fwp_args37+0xc>  // b.hs, b.nlast
    73d0:	d350fc20 	lsr	x0, x1, #16
    73d4:	f949fc44 	ldr	x4, [x2, #5112]
    73d8:	8b000800 	add	x0, x0, x0, lsl #2
    73dc:	d37df002 	lsl	x2, x0, #3
    73e0:	8b020083 	add	x3, x4, x2
    73e4:	f9401060 	ldr	x0, [x3, #32]
    73e8:	b4fffe20 	cbz	x0, 73ac <fwp_args37+0xc>
    73ec:	38626882 	ldrb	w2, [x4, x2]
    73f0:	7100085f 	cmp	w2, #0x2
    73f4:	54000220 	b.eq	7438 <fwp_args37+0x98>  // b.none
    73f8:	7100045f 	cmp	w2, #0x1
    73fc:	54fffd81 	b.ne	73ac <fwp_args37+0xc>  // b.any
    7400:	29430864 	ldp	w4, w2, [x3, #24]
    7404:	92403c21 	and	x1, x1, #0xffff
    7408:	9b047c21 	mul	x1, x1, x4
    740c:	d360fc21 	lsr	x1, x1, #32
    7410:	eb02003f 	cmp	x1, x2
    7414:	54fffcc2 	b.cs	73ac <fwp_args37+0xc>  // b.hs, b.nlast
    7418:	8b010000 	add	x0, x0, x1
    741c:	39400001 	ldrb	w1, [x0]
    7420:	34fffc61 	cbz	w1, 73ac <fwp_args37+0xc>
    7424:	7103f43f 	cmp	w1, #0xfd
    7428:	540000e8 	b.hi	7444 <fwp_args37+0xa4>  // b.pmore
    742c:	11000421 	add	w1, w1, #0x1
    7430:	39000001 	strb	w1, [x0]
    7434:	d65f03c0 	ret
    7438:	72003c3f 	tst	w1, #0xffff
    743c:	54ffff00 	b.eq	741c <fwp_args37+0x7c>  // b.none
    7440:	d65f03c0 	ret
    7444:	17fff464 	b	45d4 <fwp_rc_wide_dup>
    7448:	d503201f 	nop
    744c:	d503201f 	nop

0000000000007450 <fwp_caps37>:
    7450:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7454:	910003fd 	mov	x29, sp
    7458:	f9000bf3 	str	x19, [sp, #16]
    745c:	aa0003f3 	mov	x19, x0
    7460:	b9400400 	ldr	w0, [x0, #4]
    7464:	340004a0 	cbz	w0, 74f8 <fwp_caps37+0xa8>
    7468:	f9400660 	ldr	x0, [x19, #8]
    746c:	350004e1 	cbnz	w1, 7508 <fwp_caps37+0xb8>
    7470:	97fffc65 	bl	6604 <fwp_drop4>
    7474:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    7478:	91170042 	add	x2, x2, #0x5c0
    747c:	f949d840 	ldr	x0, [x2, #5040]
    7480:	f949ec41 	ldr	x1, [x2, #5080]
    7484:	cb000260 	sub	x0, x19, x0
    7488:	eb01401f 	cmp	x0, x1, lsl #16
    748c:	54000382 	b.cs	74fc <fwp_caps37+0xac>  // b.hs, b.nlast
    7490:	d350fc01 	lsr	x1, x0, #16
    7494:	f949fc44 	ldr	x4, [x2, #5112]
    7498:	8b010821 	add	x1, x1, x1, lsl #2
    749c:	d37df021 	lsl	x1, x1, #3
    74a0:	8b010083 	add	x3, x4, x1
    74a4:	f9401062 	ldr	x2, [x3, #32]
    74a8:	b40002a2 	cbz	x2, 74fc <fwp_caps37+0xac>
    74ac:	38616881 	ldrb	w1, [x4, x1]
    74b0:	7100083f 	cmp	w1, #0x2
    74b4:	540006c0 	b.eq	758c <fwp_caps37+0x13c>  // b.none
    74b8:	7100043f 	cmp	w1, #0x1
    74bc:	54000201 	b.ne	74fc <fwp_caps37+0xac>  // b.any
    74c0:	29430464 	ldp	w4, w1, [x3, #24]
    74c4:	92403c00 	and	x0, x0, #0xffff
    74c8:	9b047c00 	mul	x0, x0, x4
    74cc:	d360fc00 	lsr	x0, x0, #32
    74d0:	eb01001f 	cmp	x0, x1
    74d4:	54000142 	b.cs	74fc <fwp_caps37+0xac>  // b.hs, b.nlast
    74d8:	8b000042 	add	x2, x2, x0
    74dc:	39400040 	ldrb	w0, [x2]
    74e0:	7100041f 	cmp	w0, #0x1
    74e4:	540000c1 	b.ne	74fc <fwp_caps37+0xac>  // b.any
    74e8:	aa1303e0 	mov	x0, x19
    74ec:	f9400bf3 	ldr	x19, [sp, #16]
    74f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    74f4:	17fff3bf 	b	43f0 <fwp_mem_free>
    74f8:	34fffbe1 	cbz	w1, 7474 <fwp_caps37+0x24>
    74fc:	f9400bf3 	ldr	x19, [sp, #16]
    7500:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7504:	d65f03c0 	ret
    7508:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc20>
    750c:	91170042 	add	x2, x2, #0x5c0
    7510:	f949d843 	ldr	x3, [x2, #5040]
    7514:	f949ec41 	ldr	x1, [x2, #5080]
    7518:	cb030000 	sub	x0, x0, x3
    751c:	eb01401f 	cmp	x0, x1, lsl #16
    7520:	54fffee2 	b.cs	74fc <fwp_caps37+0xac>  // b.hs, b.nlast
    7524:	d350fc01 	lsr	x1, x0, #16
    7528:	f949fc44 	ldr	x4, [x2, #5112]
    752c:	8b010821 	add	x1, x1, x1, lsl #2
    7530:	d37df021 	lsl	x1, x1, #3
    7534:	8b010083 	add	x3, x4, x1
    7538:	f9401062 	ldr	x2, [x3, #32]
    753c:	b4fffe02 	cbz	x2, 74fc <fwp_caps37+0xac>
    7540:	38616881 	ldrb	w1, [x4, x1]
    7544:	7100083f 	cmp	w1, #0x2
    7548:	54000280 	b.eq	7598 <fwp_caps37+0x148>  // b.none
    754c:	7100043f 	cmp	w1, #0x1
    7550:	54fffd61 	b.ne	74fc <fwp_caps37+0xac>  // b.any
    7554:	92403c01 	and	x1, x0, #0xffff
    7558:	29430064 	ldp	w4, w0, [x3, #24]
    755c:	9b047c21 	mul	x1, x1, x4
    7560:	d360fc21 	lsr	x1, x1, #32
    7564:	eb00003f 	cmp	x1, x0
    7568:	54fffca2 	b.cs	74fc <fwp_caps37+0xac>  // b.hs, b.nlast
    756c:	8b010042 	add	x2, x2, x1
    7570:	39400040 	ldrb	w0, [x2]
    7574:	34fffc40 	cbz	w0, 74fc <fwp_caps37+0xac>
    7578:	7103f41f 	cmp	w0, #0xfd
    757c:	54000148 	b.hi	75a4 <fwp_caps37+0x154>  // b.pmore
    7580:	11000400 	add	w0, w0, #0x1
    7584:	39000040 	strb	w0, [x2]
    7588:	17ffffdd 	b	74fc <fwp_caps37+0xac>
    758c:	72003c1f 	tst	w0, #0xffff
    7590:	54fffb61 	b.ne	74fc <fwp_caps37+0xac>  // b.any
    7594:	17ffffd2 	b	74dc <fwp_caps37+0x8c>
    7598:	72003c1f 	tst	w0, #0xffff
    759c:	54fffb01 	b.ne	74fc <fwp_caps37+0xac>  // b.any
    75a0:	17fffff4 	b	7570 <fwp_caps37+0x120>
    75a4:	f9400bf3 	ldr	x19, [sp, #16]
    75a8:	aa0203e0 	mov	x0, x2
    75ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    75b0:	17fff409 	b	45d4 <fwp_rc_wide_dup>

00000000000075b4 <fwp_write>:
    75b4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    75b8:	910003fd 	mov	x29, sp
    75bc:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc88>
    75c0:	f947f484 	ldr	x4, [x4, #4072]
    75c4:	a90153f3 	stp	x19, x20, [sp, #16]
    75c8:	d10943ff 	sub	sp, sp, #0x250
    75cc:	b9400045 	ldr	w5, [x2]
    75d0:	aa0003f4 	mov	x20, x0
    75d4:	f9400080 	ldr	x0, [x4]
    75d8:	f90127e0 	str	x0, [sp, #584]
    75dc:	d2800000 	mov	x0, #0x0                   	// #0
    75e0:	710064bf 	cmp	w5, #0x19
    75e4:	54000408 	b.hi	7664 <fwp_write+0xb0>  // b.pmore
    75e8:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    75ec:	aa0103f3 	mov	x19, x1
    75f0:	9131c000 	add	x0, x0, #0xc70
    75f4:	f9013bf5 	str	x21, [sp, #624]
    75f8:	f9013ff6 	str	x22, [sp, #632]
    75fc:	f90153fb 	str	x27, [sp, #672]
    7600:	f90157fc 	str	x28, [sp, #680]
    7604:	aa0203fc 	mov	x28, x2
    7608:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    760c:	10000061 	adr	x1, 7618 <fwp_write+0x64>
    7610:	8b20a820 	add	x0, x1, w0, sxth #2
    7614:	d61f0000 	br	x0
    7618:	910123e0 	add	x0, sp, #0x48
    761c:	aa1303e5 	mov	x5, x19
    7620:	90000024 	adrp	x4, b000 <_IO_stdin_used+0x100>
    7624:	aa0003f3 	mov	x19, x0
    7628:	910fa084 	add	x4, x4, #0x3e8
    762c:	d2804003 	mov	x3, #0x200                 	// #512
    7630:	aa0303e1 	mov	x1, x3
    7634:	52800042 	mov	w2, #0x2                   	// #2
    7638:	97ffec72 	bl	2800 <__snprintf_chk@plt>
    763c:	aa1303e0 	mov	x0, x19
    7640:	97ffec38 	bl	2720 <strlen@plt>
    7644:	aa1303e1 	mov	x1, x19
    7648:	aa0003e2 	mov	x2, x0
    764c:	aa1403e0 	mov	x0, x20
    7650:	97ffefd0 	bl	3590 <buf_put>
    7654:	f9413bf5 	ldr	x21, [sp, #624]
    7658:	f9413ff6 	ldr	x22, [sp, #632]
    765c:	f94153fb 	ldr	x27, [sp, #672]
    7660:	f94157fc 	ldr	x28, [sp, #680]
    7664:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7668:	f947f400 	ldr	x0, [x0, #4072]
    766c:	f94127e2 	ldr	x2, [sp, #584]
    7670:	f9400001 	ldr	x1, [x0]
    7674:	eb010042 	subs	x2, x2, x1
    7678:	d2800001 	mov	x1, #0x0                   	// #0
    767c:	540077a1 	b.ne	8570 <fwp_write+0xfbc>  // b.any
    7680:	910943ff 	add	sp, sp, #0x250
    7684:	a94153f3 	ldp	x19, x20, [sp, #16]
    7688:	a8c77bfd 	ldp	x29, x30, [sp], #112
    768c:	d65f03c0 	ret
    7690:	910123e0 	add	x0, sp, #0x48
    7694:	aa1303e5 	mov	x5, x19
    7698:	90000024 	adrp	x4, b000 <_IO_stdin_used+0x100>
    769c:	aa0003f3 	mov	x19, x0
    76a0:	910f8084 	add	x4, x4, #0x3e0
    76a4:	d2804003 	mov	x3, #0x200                 	// #512
    76a8:	17ffffe2 	b	7630 <fwp_write+0x7c>
    76ac:	71004cbf 	cmp	w5, #0x13
    76b0:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x100>
    76b4:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x100>
    76b8:	910f4000 	add	x0, x0, #0x3d0
    76bc:	910f6021 	add	x1, x1, #0x3d8
    76c0:	d2800082 	mov	x2, #0x4                   	// #4
    76c4:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    76c8:	aa1403e0 	mov	x0, x20
    76cc:	f90143f7 	str	x23, [sp, #640]
    76d0:	d2800016 	mov	x22, #0x0                   	// #0
    76d4:	f90147f8 	str	x24, [sp, #648]
    76d8:	97ffefae 	bl	3590 <buf_put>
    76dc:	f9400260 	ldr	x0, [x19]
    76e0:	90000037 	adrp	x23, b000 <_IO_stdin_used+0x100>
    76e4:	d2800015 	mov	x21, #0x0                   	// #0
    76e8:	911162f7 	add	x23, x23, #0x458
    76ec:	b4004780 	cbz	x0, 7fdc <fwp_write+0xa28>
    76f0:	b9400380 	ldr	w0, [x28]
    76f4:	52800003 	mov	w3, #0x0                   	// #0
    76f8:	f9401f82 	ldr	x2, [x28, #56]
    76fc:	71004c1f 	cmp	w0, #0x13
    7700:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7704:	aa1403e0 	mov	x0, x20
    7708:	8b010e61 	add	x1, x19, x1, lsl #3
    770c:	f9400421 	ldr	x1, [x1, #8]
    7710:	97ffffa9 	bl	75b4 <fwp_write>
    7714:	b9400380 	ldr	w0, [x28]
    7718:	7100481f 	cmp	w0, #0x12
    771c:	54004b20 	b.eq	8080 <fwp_write+0xacc>  // b.none
    7720:	f9400260 	ldr	x0, [x19]
    7724:	910006b5 	add	x21, x21, #0x1
    7728:	91000ad6 	add	x22, x22, #0x2
    772c:	eb15001f 	cmp	x0, x21
    7730:	54004569 	b.ls	7fdc <fwp_write+0xa28>  // b.plast
    7734:	aa1703e1 	mov	x1, x23
    7738:	aa1403e0 	mov	x0, x20
    773c:	d2800042 	mov	x2, #0x2                   	// #2
    7740:	97ffef94 	bl	3590 <buf_put>
    7744:	17ffffeb 	b	76f0 <fwp_write+0x13c>
    7748:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x100>
    774c:	91104021 	add	x1, x1, #0x410
    7750:	d28000c2 	mov	x2, #0x6                   	// #6
    7754:	aa1403e0 	mov	x0, x20
    7758:	91004273 	add	x19, x19, #0x10
    775c:	97ffef8d 	bl	3590 <buf_put>
    7760:	aa1303e0 	mov	x0, x19
    7764:	97ffebef 	bl	2720 <strlen@plt>
    7768:	aa1303e1 	mov	x1, x19
    776c:	aa0003e2 	mov	x2, x0
    7770:	aa1403e0 	mov	x0, x20
    7774:	97ffef87 	bl	3590 <buf_put>
    7778:	528007c3 	mov	w3, #0x3e                  	// #62
    777c:	aa1403e0 	mov	x0, x20
    7780:	91001fe1 	add	x1, sp, #0x7
    7784:	d2800022 	mov	x2, #0x1                   	// #1
    7788:	39001fe3 	strb	w3, [sp, #7]
    778c:	17ffffb1 	b	7650 <fwp_write+0x9c>
    7790:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7794:	f947f400 	ldr	x0, [x0, #4072]
    7798:	f94127e2 	ldr	x2, [sp, #584]
    779c:	f9400001 	ldr	x1, [x0]
    77a0:	eb010042 	subs	x2, x2, x1
    77a4:	d2800001 	mov	x1, #0x0                   	// #0
    77a8:	540034c1 	b.ne	7e40 <fwp_write+0x88c>  // b.any
    77ac:	f9413bf5 	ldr	x21, [sp, #624]
    77b0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x100>
    77b4:	f9413ff6 	ldr	x22, [sp, #632]
    77b8:	aa1403e0 	mov	x0, x20
    77bc:	910fc021 	add	x1, x1, #0x3f0
    77c0:	d2800142 	mov	x2, #0xa                   	// #10
    77c4:	f94153fb 	ldr	x27, [sp, #672]
    77c8:	f94157fc 	ldr	x28, [sp, #680]
    77cc:	910943ff 	add	sp, sp, #0x250
    77d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    77d4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    77d8:	17ffef6e 	b	3590 <buf_put>
    77dc:	f9400456 	ldr	x22, [x2, #8]
    77e0:	f90143f7 	str	x23, [sp, #640]
    77e4:	f90147f8 	str	x24, [sp, #648]
    77e8:	b4005af6 	cbz	x22, 8344 <fwp_write+0xd90>
    77ec:	aa1603e0 	mov	x0, x22
    77f0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x100>
    77f4:	9111c021 	add	x1, x1, #0x470
    77f8:	97ffec46 	bl	2910 <strcmp@plt>
    77fc:	2a0003f5 	mov	w21, w0
    7800:	34005fc0 	cbz	w0, 83f8 <fwp_write+0xe44>
    7804:	aa1603e0 	mov	x0, x22
    7808:	97ffebc6 	bl	2720 <strlen@plt>
    780c:	aa1603e1 	mov	x1, x22
    7810:	aa0003e2 	mov	x2, x0
    7814:	aa1403e0 	mov	x0, x20
    7818:	97ffef5e 	bl	3590 <buf_put>
    781c:	52800403 	mov	w3, #0x20                  	// #32
    7820:	91001ff5 	add	x21, sp, #0x7
    7824:	aa1503e1 	mov	x1, x21
    7828:	aa1403e0 	mov	x0, x20
    782c:	d2800022 	mov	x2, #0x1                   	// #1
    7830:	39001fe3 	strb	w3, [sp, #7]
    7834:	97ffef57 	bl	3590 <buf_put>
    7838:	52800f63 	mov	w3, #0x7b                  	// #123
    783c:	aa1403e0 	mov	x0, x20
    7840:	aa1503e1 	mov	x1, x21
    7844:	d2800022 	mov	x2, #0x1                   	// #1
    7848:	39001fe3 	strb	w3, [sp, #7]
    784c:	97ffef51 	bl	3590 <buf_put>
    7850:	b9401380 	ldr	w0, [x28, #16]
    7854:	52800018 	mov	w24, #0x0                   	// #0
    7858:	7100001f 	cmp	w0, #0x0
    785c:	54003a8d 	b.le	7fac <fwp_write+0x9f8>
    7860:	f9014bf9 	str	x25, [sp, #656]
    7864:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x100>
    7868:	91126339 	add	x25, x25, #0x498
    786c:	f9014ffa 	str	x26, [sp, #664]
    7870:	9000003a 	adrp	x26, b000 <_IO_stdin_used+0x100>
    7874:	9111635a 	add	x26, x26, #0x458
    7878:	91002276 	add	x22, x19, #0x8
    787c:	d2800013 	mov	x19, #0x0                   	// #0
    7880:	b5003e73 	cbnz	x19, 804c <fwp_write+0xa98>
    7884:	d37df277 	lsl	x23, x19, #3
    7888:	34003c98 	cbz	w24, 8018 <fwp_write+0xa64>
    788c:	f9401382 	ldr	x2, [x28, #32]
    7890:	aa1403e0 	mov	x0, x20
    7894:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7898:	52800003 	mov	w3, #0x0                   	// #0
    789c:	f8776842 	ldr	x2, [x2, x23]
    78a0:	91000673 	add	x19, x19, #0x1
    78a4:	97ffff44 	bl	75b4 <fwp_write>
    78a8:	b9401380 	ldr	w0, [x28, #16]
    78ac:	6b13001f 	cmp	w0, w19
    78b0:	54fffe8c 	b.gt	7880 <fwp_write+0x2cc>
    78b4:	f9414bf9 	ldr	x25, [sp, #656]
    78b8:	f9414ffa 	ldr	x26, [sp, #664]
    78bc:	34003798 	cbz	w24, 7fac <fwp_write+0x9f8>
    78c0:	52800523 	mov	w3, #0x29                  	// #41
    78c4:	aa1503e1 	mov	x1, x21
    78c8:	aa1403e0 	mov	x0, x20
    78cc:	d2800022 	mov	x2, #0x1                   	// #1
    78d0:	39001fe3 	strb	w3, [sp, #7]
    78d4:	97ffef2f 	bl	3590 <buf_put>
    78d8:	f9413bf5 	ldr	x21, [sp, #624]
    78dc:	f9413ff6 	ldr	x22, [sp, #632]
    78e0:	f94143f7 	ldr	x23, [sp, #640]
    78e4:	f94147f8 	ldr	x24, [sp, #648]
    78e8:	f94153fb 	ldr	x27, [sp, #672]
    78ec:	f94157fc 	ldr	x28, [sp, #680]
    78f0:	17ffff5d 	b	7664 <fwp_write+0xb0>
    78f4:	b9404855 	ldr	w21, [x2, #72]
    78f8:	aa1403e0 	mov	x0, x20
    78fc:	93407eb6 	sxtw	x22, w21
    7900:	91000ac1 	add	x1, x22, #0x2
    7904:	97ffeeef 	bl	34c0 <buf_grow>
    7908:	a9400281 	ldp	x1, x0, [x20]
    790c:	528e8603 	mov	w3, #0x7430                	// #29744
    7910:	78206823 	strh	w3, [x1, x0]
    7914:	8b000022 	add	x2, x1, x0
    7918:	710002bf 	cmp	w21, #0x0
    791c:	540036ad 	b.le	7ff0 <fwp_write+0xa3c>
    7920:	110006a3 	add	w3, w21, #0x1
    7924:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7928:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    792c:	91000449 	add	x9, x2, #0x1
    7930:	8b23c043 	add	x3, x2, w3, sxtw
    7934:	f28aaac6 	movk	x6, #0x5556
    7938:	f2955568 	movk	x8, #0xaaab
    793c:	1400000d 	b	7970 <fwp_write+0x3bc>
    7940:	d2800021 	mov	x1, #0x1                   	// #1
    7944:	528005a5 	mov	w5, #0x2d                  	// #45
    7948:	f100001f 	cmp	x0, #0x0
    794c:	9b467e60 	smulh	x0, x19, x6
    7950:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7954:	381ff465 	strb	w5, [x3], #-1
    7958:	cb040000 	sub	x0, x0, x4
    795c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7960:	cb020000 	sub	x0, x0, x2
    7964:	8b010013 	add	x19, x0, x1
    7968:	eb03013f 	cmp	x9, x3
    796c:	54003420 	b.eq	7ff0 <fwp_write+0xa3c>  // b.none
    7970:	9b467e60 	smulh	x0, x19, x6
    7974:	937ffe64 	asr	x4, x19, #63
    7978:	52800605 	mov	w5, #0x30                  	// #48
    797c:	cb040000 	sub	x0, x0, x4
    7980:	8b000400 	add	x0, x0, x0, lsl #1
    7984:	cb000260 	sub	x0, x19, x0
    7988:	91000c01 	add	x1, x0, #0x3
    798c:	9bc87c22 	umulh	x2, x1, x8
    7990:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7994:	8b4204e2 	add	x2, x7, x2, lsr #1
    7998:	eb020021 	subs	x1, x1, x2
    799c:	54fffd60 	b.eq	7948 <fwp_write+0x394>  // b.none
    79a0:	f100043f 	cmp	x1, #0x1
    79a4:	54fffce1 	b.ne	7940 <fwp_write+0x38c>  // b.any
    79a8:	d2800001 	mov	x1, #0x0                   	// #0
    79ac:	52800565 	mov	w5, #0x2b                  	// #43
    79b0:	17ffffe6 	b	7948 <fwp_write+0x394>
    79b4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    79b8:	f947f400 	ldr	x0, [x0, #4072]
    79bc:	f94127e2 	ldr	x2, [sp, #584]
    79c0:	f9400001 	ldr	x1, [x0]
    79c4:	eb010042 	subs	x2, x2, x1
    79c8:	d2800001 	mov	x1, #0x0                   	// #0
    79cc:	540023a1 	b.ne	7e40 <fwp_write+0x88c>  // b.any
    79d0:	f9413bf5 	ldr	x21, [sp, #624]
    79d4:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x100>
    79d8:	f9413ff6 	ldr	x22, [sp, #632]
    79dc:	aa1403e0 	mov	x0, x20
    79e0:	91100021 	add	x1, x1, #0x400
    79e4:	d2800102 	mov	x2, #0x8                   	// #8
    79e8:	17ffff77 	b	77c4 <fwp_write+0x210>
    79ec:	aa1403e0 	mov	x0, x20
    79f0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x100>
    79f4:	d28000c2 	mov	x2, #0x6                   	// #6
    79f8:	91118021 	add	x1, x1, #0x460
    79fc:	97ffeee5 	bl	3590 <buf_put>
    7a00:	d2800015 	mov	x21, #0x0                   	// #0
    7a04:	f9400263 	ldr	x3, [x19]
    7a08:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7a0c:	54002c40 	b.eq	7f94 <fwp_write+0x9e0>  // b.none
    7a10:	f9401f82 	ldr	x2, [x28, #56]
    7a14:	f90143f7 	str	x23, [sp, #640]
    7a18:	f90147f8 	str	x24, [sp, #648]
    7a1c:	d2800857 	mov	x23, #0x42                  	// #66
    7a20:	f9014bf9 	str	x25, [sp, #656]
    7a24:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x100>
    7a28:	f9014ffa 	str	x26, [sp, #664]
    7a2c:	911162d6 	add	x22, x22, #0x458
    7a30:	d2800038 	mov	x24, #0x1                   	// #1
    7a34:	f2a18017 	movk	x23, #0xc00, lsl #16
    7a38:	d2809099 	mov	x25, #0x484                 	// #1156
    7a3c:	b4000482 	cbz	x2, 7acc <fwp_write+0x518>
    7a40:	b9400040 	ldr	w0, [x2]
    7a44:	7100701f 	cmp	w0, #0x1c
    7a48:	540042a0 	b.eq	829c <fwp_write+0xce8>  // b.none
    7a4c:	71006c1f 	cmp	w0, #0x1b
    7a50:	540003e8 	b.hi	7acc <fwp_write+0x518>  // b.pmore
    7a54:	9ac02301 	lsl	x1, x24, x0
    7a58:	ea17003f 	tst	x1, x23
    7a5c:	54003681 	b.ne	812c <fwp_write+0xb78>  // b.any
    7a60:	ea19003f 	tst	x1, x25
    7a64:	54003501 	b.ne	8104 <fwp_write+0xb50>  // b.any
    7a68:	d2800424 	mov	x4, #0x21                  	// #33
    7a6c:	ea04003f 	tst	x1, x4
    7a70:	540002e0 	b.eq	7acc <fwp_write+0x518>  // b.none
    7a74:	b7f849a3 	tbnz	x3, #63, 83a8 <fwp_write+0xdf4>
    7a78:	91002261 	add	x1, x19, #0x8
    7a7c:	8b150021 	add	x1, x1, x21
    7a80:	39400021 	ldrb	w1, [x1]
    7a84:	7100001f 	cmp	w0, #0x0
    7a88:	93401c23 	sxtb	x3, w1
    7a8c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7a90:	aa1403e0 	mov	x0, x20
    7a94:	52800003 	mov	w3, #0x0                   	// #0
    7a98:	97fffec7 	bl	75b4 <fwp_write>
    7a9c:	910006b5 	add	x21, x21, #0x1
    7aa0:	f9400260 	ldr	x0, [x19]
    7aa4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7aa8:	eb0002bf 	cmp	x21, x0
    7aac:	540026c2 	b.cs	7f84 <fwp_write+0x9d0>  // b.hs, b.nlast
    7ab0:	d2800042 	mov	x2, #0x2                   	// #2
    7ab4:	aa1603e1 	mov	x1, x22
    7ab8:	aa1403e0 	mov	x0, x20
    7abc:	97ffeeb5 	bl	3590 <buf_put>
    7ac0:	f9401f82 	ldr	x2, [x28, #56]
    7ac4:	f9400263 	ldr	x3, [x19]
    7ac8:	b5fffbc2 	cbnz	x2, 7a40 <fwp_write+0x48c>
    7acc:	d37df2a0 	lsl	x0, x21, #3
    7ad0:	b7f83f03 	tbnz	x3, #63, 82b0 <fwp_write+0xcfc>
    7ad4:	91002261 	add	x1, x19, #0x8
    7ad8:	8b000020 	add	x0, x1, x0
    7adc:	f9400001 	ldr	x1, [x0]
    7ae0:	17ffffec 	b	7a90 <fwp_write+0x4dc>
    7ae4:	a9400e62 	ldp	x2, x3, [x19]
    7ae8:	b7f83ca3 	tbnz	x3, #63, 827c <fwp_write+0xcc8>
    7aec:	910123f5 	add	x21, sp, #0x48
    7af0:	aa1503e0 	mov	x0, x21
    7af4:	97ffeccb 	bl	2e20 <fwp_fmt_u128>
    7af8:	aa1503e0 	mov	x0, x21
    7afc:	97ffeb09 	bl	2720 <strlen@plt>
    7b00:	aa1503e1 	mov	x1, x21
    7b04:	aa0003e2 	mov	x2, x0
    7b08:	17fffed1 	b	764c <fwp_write+0x98>
    7b0c:	fd015be8 	str	d8, [sp, #688]
    7b10:	1e270268 	fmov	s8, w19
    7b14:	fd015fe9 	str	d9, [sp, #696]
    7b18:	1e282100 	fcmp	s8, s8
    7b1c:	54004d26 	b.vs	84c0 <fwp_write+0xf0c>
    7b20:	1e20c101 	fabs	s1, s8
    7b24:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7b28:	1e270000 	fmov	s0, w0
    7b2c:	1e202020 	fcmp	s1, s0
    7b30:	54002c0d 	b.le	80b0 <fwp_write+0xafc>
    7b34:	1e202118 	fcmpe	s8, #0.0
    7b38:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1a60>
    7b3c:	913f6042 	add	x2, x2, #0xfd8
    7b40:	910123f5 	add	x21, sp, #0x48
    7b44:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x100>
    7b48:	910ec021 	add	x1, x1, #0x3b0
    7b4c:	aa1503e0 	mov	x0, x21
    7b50:	9a81c041 	csel	x1, x2, x1, gt
    7b54:	97ffeb9f 	bl	29d0 <strcpy@plt>
    7b58:	aa1503e0 	mov	x0, x21
    7b5c:	97ffeaf1 	bl	2720 <strlen@plt>
    7b60:	aa1503e1 	mov	x1, x21
    7b64:	aa0003e2 	mov	x2, x0
    7b68:	aa1403e0 	mov	x0, x20
    7b6c:	97ffee89 	bl	3590 <buf_put>
    7b70:	f9413bf5 	ldr	x21, [sp, #624]
    7b74:	f9413ff6 	ldr	x22, [sp, #632]
    7b78:	f94153fb 	ldr	x27, [sp, #672]
    7b7c:	f94157fc 	ldr	x28, [sp, #680]
    7b80:	fd415be8 	ldr	d8, [sp, #688]
    7b84:	fd415fe9 	ldr	d9, [sp, #696]
    7b88:	17fffeb7 	b	7664 <fwp_write+0xb0>
    7b8c:	f9400276 	ldr	x22, [x19]
    7b90:	34002e03 	cbz	w3, 8150 <fwp_write+0xb9c>
    7b94:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7b98:	f947f400 	ldr	x0, [x0, #4072]
    7b9c:	f94127e2 	ldr	x2, [sp, #584]
    7ba0:	f9400001 	ldr	x1, [x0]
    7ba4:	eb010042 	subs	x2, x2, x1
    7ba8:	d2800001 	mov	x1, #0x0                   	// #0
    7bac:	540014a1 	b.ne	7e40 <fwp_write+0x88c>  // b.any
    7bb0:	aa1603e2 	mov	x2, x22
    7bb4:	91002261 	add	x1, x19, #0x8
    7bb8:	f9413bf5 	ldr	x21, [sp, #624]
    7bbc:	aa1403e0 	mov	x0, x20
    7bc0:	f9413ff6 	ldr	x22, [sp, #632]
    7bc4:	17ffff00 	b	77c4 <fwp_write+0x210>
    7bc8:	fd015be8 	str	d8, [sp, #688]
    7bcc:	9e670268 	fmov	d8, x19
    7bd0:	fd015fe9 	str	d9, [sp, #696]
    7bd4:	1e682100 	fcmp	d8, d8
    7bd8:	54004746 	b.vs	84c0 <fwp_write+0xf0c>
    7bdc:	1e60c101 	fabs	d1, d8
    7be0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7be4:	9e670000 	fmov	d0, x0
    7be8:	910123f5 	add	x21, sp, #0x48
    7bec:	52800033 	mov	w19, #0x1                   	// #1
    7bf0:	1e602020 	fcmp	d1, d0
    7bf4:	540001ad 	b.le	7c28 <fwp_write+0x674>
    7bf8:	1e602118 	fcmpe	d8, #0.0
    7bfc:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1a60>
    7c00:	913f6042 	add	x2, x2, #0xfd8
    7c04:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x100>
    7c08:	910ec021 	add	x1, x1, #0x3b0
    7c0c:	aa1503e0 	mov	x0, x21
    7c10:	9a81c041 	csel	x1, x2, x1, gt
    7c14:	97ffeb6f 	bl	29d0 <strcpy@plt>
    7c18:	17ffffd0 	b	7b58 <fwp_write+0x5a4>
    7c1c:	11000673 	add	w19, w19, #0x1
    7c20:	71004a7f 	cmp	w19, #0x12
    7c24:	54003860 	b.eq	8330 <fwp_write+0xd7c>  // b.none
    7c28:	1e604100 	fmov	d0, d8
    7c2c:	2a1303e1 	mov	w1, w19
    7c30:	aa1503e0 	mov	x0, x21
    7c34:	97ffeef3 	bl	3800 <fwp_format_g.constprop.0>
    7c38:	aa1503e0 	mov	x0, x21
    7c3c:	d2800001 	mov	x1, #0x0                   	// #0
    7c40:	97ffeacc 	bl	2770 <strtod@plt>
    7c44:	1e602100 	fcmp	d8, d0
    7c48:	54fffea1 	b.ne	7c1c <fwp_write+0x668>  // b.any
    7c4c:	aa1503e0 	mov	x0, x21
    7c50:	97ffeec9 	bl	3774 <fwp_finish_float>
    7c54:	17ffffc1 	b	7b58 <fwp_write+0x5a4>
    7c58:	a9400e62 	ldp	x2, x3, [x19]
    7c5c:	910123f3 	add	x19, sp, #0x48
    7c60:	aa1303e0 	mov	x0, x19
    7c64:	97ffec6f 	bl	2e20 <fwp_fmt_u128>
    7c68:	17fffe75 	b	763c <fwp_write+0x88>
    7c6c:	f90143f7 	str	x23, [sp, #640]
    7c70:	f90147f8 	str	x24, [sp, #648]
    7c74:	2a1303f8 	mov	w24, w19
    7c78:	f9014bf9 	str	x25, [sp, #656]
    7c7c:	f9014ffa 	str	x26, [sp, #664]
    7c80:	f13ffe7f 	cmp	x19, #0xfff
    7c84:	54000049 	b.ls	7c8c <fwp_write+0x6d8>  // b.plast
    7c88:	b9400278 	ldr	w24, [x19]
    7c8c:	f9400f80 	ldr	x0, [x28, #24]
    7c90:	2a1803f5 	mov	w21, w24
    7c94:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7c98:	d37ef6b9 	lsl	x25, x21, #2
    7c9c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7ca0:	aa1603e0 	mov	x0, x22
    7ca4:	97ffea9f 	bl	2720 <strlen@plt>
    7ca8:	aa1603e1 	mov	x1, x22
    7cac:	aa0003e2 	mov	x2, x0
    7cb0:	aa1403e0 	mov	x0, x20
    7cb4:	97ffee37 	bl	3590 <buf_put>
    7cb8:	f9401780 	ldr	x0, [x28, #40]
    7cbc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7cc0:	7100001f 	cmp	w0, #0x0
    7cc4:	5400068d 	b.le	7d94 <fwp_write+0x7e0>
    7cc8:	91002276 	add	x22, x19, #0x8
    7ccc:	91001ff5 	add	x21, sp, #0x7
    7cd0:	d280001b 	mov	x27, #0x0                   	// #0
    7cd4:	5280041a 	mov	w26, #0x20                  	// #32
    7cd8:	f9401b80 	ldr	x0, [x28, #48]
    7cdc:	aa1503e1 	mov	x1, x21
    7ce0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7ce4:	d2800022 	mov	x2, #0x1                   	// #1
    7ce8:	f8786803 	ldr	x3, [x0, x24]
    7cec:	aa1403e0 	mov	x0, x20
    7cf0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7cf4:	39001ffa 	strb	w26, [sp, #7]
    7cf8:	97ffee26 	bl	3590 <buf_put>
    7cfc:	f13ffeff 	cmp	x23, #0xfff
    7d00:	b9400261 	ldr	w1, [x19]
    7d04:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7d08:	7100383f 	cmp	w1, #0xe
    7d0c:	54000160 	b.eq	7d38 <fwp_write+0x784>  // b.none
    7d10:	7100403f 	cmp	w1, #0x10
    7d14:	54001a60 	b.eq	8060 <fwp_write+0xaac>  // b.none
    7d18:	7100283f 	cmp	w1, #0xa
    7d1c:	54002aa0 	b.eq	8270 <fwp_write+0xcbc>  // b.none
    7d20:	540014ac 	b.gt	7fb4 <fwp_write+0xa00>
    7d24:	71000c3f 	cmp	w1, #0x3
    7d28:	540029ac 	b.gt	825c <fwp_write+0xca8>
    7d2c:	d37ffee0 	lsr	x0, x23, #63
    7d30:	37f814a1 	tbnz	w1, #31, 7fc4 <fwp_write+0xa10>
    7d34:	d503201f 	nop
    7d38:	34001460 	cbz	w0, 7fc4 <fwp_write+0xa10>
    7d3c:	52800503 	mov	w3, #0x28                  	// #40
    7d40:	aa1503e1 	mov	x1, x21
    7d44:	aa1403e0 	mov	x0, x20
    7d48:	d2800022 	mov	x2, #0x1                   	// #1
    7d4c:	39001fe3 	strb	w3, [sp, #7]
    7d50:	97ffee10 	bl	3590 <buf_put>
    7d54:	aa1303e2 	mov	x2, x19
    7d58:	aa1703e1 	mov	x1, x23
    7d5c:	aa1403e0 	mov	x0, x20
    7d60:	52800003 	mov	w3, #0x0                   	// #0
    7d64:	97fffe14 	bl	75b4 <fwp_write>
    7d68:	52800523 	mov	w3, #0x29                  	// #41
    7d6c:	aa1503e1 	mov	x1, x21
    7d70:	aa1403e0 	mov	x0, x20
    7d74:	d2800022 	mov	x2, #0x1                   	// #1
    7d78:	39001fe3 	strb	w3, [sp, #7]
    7d7c:	97ffee05 	bl	3590 <buf_put>
    7d80:	f9401780 	ldr	x0, [x28, #40]
    7d84:	9100077b 	add	x27, x27, #0x1
    7d88:	b8796800 	ldr	w0, [x0, x25]
    7d8c:	6b1b001f 	cmp	w0, w27
    7d90:	54fffa4c 	b.gt	7cd8 <fwp_write+0x724>
    7d94:	f9413bf5 	ldr	x21, [sp, #624]
    7d98:	f9413ff6 	ldr	x22, [sp, #632]
    7d9c:	f94143f7 	ldr	x23, [sp, #640]
    7da0:	f94147f8 	ldr	x24, [sp, #648]
    7da4:	f9414bf9 	ldr	x25, [sp, #656]
    7da8:	f9414ffa 	ldr	x26, [sp, #664]
    7dac:	f94153fb 	ldr	x27, [sp, #672]
    7db0:	f94157fc 	ldr	x28, [sp, #680]
    7db4:	17fffe2c 	b	7664 <fwp_write+0xb0>
    7db8:	52800783 	mov	w3, #0x3c                  	// #60
    7dbc:	91001ff3 	add	x19, sp, #0x7
    7dc0:	aa1303e1 	mov	x1, x19
    7dc4:	d2800022 	mov	x2, #0x1                   	// #1
    7dc8:	aa1403e0 	mov	x0, x20
    7dcc:	39001fe3 	strb	w3, [sp, #7]
    7dd0:	97ffedf0 	bl	3590 <buf_put>
    7dd4:	f9400795 	ldr	x21, [x28, #8]
    7dd8:	aa1503e0 	mov	x0, x21
    7ddc:	97ffea51 	bl	2720 <strlen@plt>
    7de0:	aa1503e1 	mov	x1, x21
    7de4:	aa0003e2 	mov	x2, x0
    7de8:	aa1403e0 	mov	x0, x20
    7dec:	97ffede9 	bl	3590 <buf_put>
    7df0:	528007c3 	mov	w3, #0x3e                  	// #62
    7df4:	aa1303e1 	mov	x1, x19
    7df8:	aa1403e0 	mov	x0, x20
    7dfc:	d2800022 	mov	x2, #0x1                   	// #1
    7e00:	39001fe3 	strb	w3, [sp, #7]
    7e04:	17fffe13 	b	7650 <fwp_write+0x9c>
    7e08:	f100067f 	cmp	x19, #0x1
    7e0c:	540025a0 	b.eq	82c0 <fwp_write+0xd0c>  // b.none
    7e10:	b100067f 	cmn	x19, #0x1
    7e14:	54002bc0 	b.eq	838c <fwp_write+0xdd8>  // b.none
    7e18:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x100>
    7e1c:	910ee021 	add	x1, x1, #0x3b8
    7e20:	d2800022 	mov	x2, #0x1                   	// #1
    7e24:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7e28:	f947f400 	ldr	x0, [x0, #4072]
    7e2c:	f94127e4 	ldr	x4, [sp, #584]
    7e30:	f9400003 	ldr	x3, [x0]
    7e34:	eb030084 	subs	x4, x4, x3
    7e38:	d2800003 	mov	x3, #0x0                   	// #0
    7e3c:	54ffebe0 	b.eq	7bb8 <fwp_write+0x604>  // b.none
    7e40:	f90143f7 	str	x23, [sp, #640]
    7e44:	f90147f8 	str	x24, [sp, #648]
    7e48:	f9014bf9 	str	x25, [sp, #656]
    7e4c:	f9014ffa 	str	x26, [sp, #664]
    7e50:	fd015be8 	str	d8, [sp, #688]
    7e54:	fd015fe9 	str	d9, [sp, #696]
    7e58:	97ffea8e 	bl	2890 <__stack_chk_fail@plt>
    7e5c:	52800b63 	mov	w3, #0x5b                  	// #91
    7e60:	91001ff5 	add	x21, sp, #0x7
    7e64:	aa1503e1 	mov	x1, x21
    7e68:	aa1403e0 	mov	x0, x20
    7e6c:	d2800022 	mov	x2, #0x1                   	// #1
    7e70:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x100>
    7e74:	911162d6 	add	x22, x22, #0x458
    7e78:	39001fe3 	strb	w3, [sp, #7]
    7e7c:	97ffedc5 	bl	3590 <buf_put>
    7e80:	b4000273 	cbz	x19, 7ecc <fwp_write+0x918>
    7e84:	f9400661 	ldr	x1, [x19, #8]
    7e88:	aa1403e0 	mov	x0, x20
    7e8c:	f9401f82 	ldr	x2, [x28, #56]
    7e90:	52800003 	mov	w3, #0x0                   	// #0
    7e94:	97fffdc8 	bl	75b4 <fwp_write>
    7e98:	f9400a73 	ldr	x19, [x19, #16]
    7e9c:	b4000193 	cbz	x19, 7ecc <fwp_write+0x918>
    7ea0:	aa1603e1 	mov	x1, x22
    7ea4:	aa1403e0 	mov	x0, x20
    7ea8:	d2800042 	mov	x2, #0x2                   	// #2
    7eac:	97ffedb9 	bl	3590 <buf_put>
    7eb0:	f9400661 	ldr	x1, [x19, #8]
    7eb4:	aa1403e0 	mov	x0, x20
    7eb8:	f9401f82 	ldr	x2, [x28, #56]
    7ebc:	52800003 	mov	w3, #0x0                   	// #0
    7ec0:	97fffdbd 	bl	75b4 <fwp_write>
    7ec4:	f9400a73 	ldr	x19, [x19, #16]
    7ec8:	b5fffed3 	cbnz	x19, 7ea0 <fwp_write+0x8ec>
    7ecc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ed0:	aa1503e1 	mov	x1, x21
    7ed4:	aa1403e0 	mov	x0, x20
    7ed8:	d2800022 	mov	x2, #0x1                   	// #1
    7edc:	39001fe3 	strb	w3, [sp, #7]
    7ee0:	17fffddc 	b	7650 <fwp_write+0x9c>
    7ee4:	aa1403e0 	mov	x0, x20
    7ee8:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x100>
    7eec:	d28000c2 	mov	x2, #0x6                   	// #6
    7ef0:	91112021 	add	x1, x1, #0x448
    7ef4:	97ffeda7 	bl	3590 <buf_put>
    7ef8:	f9400260 	ldr	x0, [x19]
    7efc:	b40004c0 	cbz	x0, 7f94 <fwp_write+0x9e0>
    7f00:	910123f5 	add	x21, sp, #0x48
    7f04:	91002276 	add	x22, x19, #0x8
    7f08:	f90143f7 	str	x23, [sp, #640]
    7f0c:	d2800017 	mov	x23, #0x0                   	// #0
    7f10:	f90147f8 	str	x24, [sp, #648]
    7f14:	90000038 	adrp	x24, b000 <_IO_stdin_used+0x100>
    7f18:	91114318 	add	x24, x24, #0x450
    7f1c:	f9014bf9 	str	x25, [sp, #656]
    7f20:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x100>
    7f24:	91116339 	add	x25, x25, #0x458
    7f28:	f9014ffa 	str	x26, [sp, #664]
    7f2c:	14000005 	b	7f40 <fwp_write+0x98c>
    7f30:	aa1903e1 	mov	x1, x25
    7f34:	aa1403e0 	mov	x0, x20
    7f38:	d2800042 	mov	x2, #0x2                   	// #2
    7f3c:	97ffed95 	bl	3590 <buf_put>
    7f40:	38776ac5 	ldrb	w5, [x22, x23]
    7f44:	d2804003 	mov	x3, #0x200                 	// #512
    7f48:	aa1803e4 	mov	x4, x24
    7f4c:	aa0303e1 	mov	x1, x3
    7f50:	52800042 	mov	w2, #0x2                   	// #2
    7f54:	aa1503e0 	mov	x0, x21
    7f58:	910006f7 	add	x23, x23, #0x1
    7f5c:	97ffea29 	bl	2800 <__snprintf_chk@plt>
    7f60:	aa1503e0 	mov	x0, x21
    7f64:	97ffe9ef 	bl	2720 <strlen@plt>
    7f68:	aa1503e1 	mov	x1, x21
    7f6c:	aa0003e2 	mov	x2, x0
    7f70:	aa1403e0 	mov	x0, x20
    7f74:	97ffed87 	bl	3590 <buf_put>
    7f78:	f9400260 	ldr	x0, [x19]
    7f7c:	eb17001f 	cmp	x0, x23
    7f80:	54fffd88 	b.hi	7f30 <fwp_write+0x97c>  // b.pmore
    7f84:	f94143f7 	ldr	x23, [sp, #640]
    7f88:	f94147f8 	ldr	x24, [sp, #648]
    7f8c:	f9414bf9 	ldr	x25, [sp, #656]
    7f90:	f9414ffa 	ldr	x26, [sp, #664]
    7f94:	52800ba3 	mov	w3, #0x5d                  	// #93
    7f98:	aa1403e0 	mov	x0, x20
    7f9c:	91001fe1 	add	x1, sp, #0x7
    7fa0:	d2800022 	mov	x2, #0x1                   	// #1
    7fa4:	39001fe3 	strb	w3, [sp, #7]
    7fa8:	17fffdaa 	b	7650 <fwp_write+0x9c>
    7fac:	52800fa3 	mov	w3, #0x7d                  	// #125
    7fb0:	17fffe45 	b	78c4 <fwp_write+0x310>
    7fb4:	f10002ff 	cmp	x23, #0x0
    7fb8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7fbc:	71002c3f 	cmp	w1, #0xb
    7fc0:	54ffebc0 	b.eq	7d38 <fwp_write+0x784>  // b.none
    7fc4:	aa1303e2 	mov	x2, x19
    7fc8:	aa1703e1 	mov	x1, x23
    7fcc:	aa1403e0 	mov	x0, x20
    7fd0:	52800003 	mov	w3, #0x0                   	// #0
    7fd4:	97fffd78 	bl	75b4 <fwp_write>
    7fd8:	17ffff6a 	b	7d80 <fwp_write+0x7cc>
    7fdc:	aa1403e0 	mov	x0, x20
    7fe0:	91001fe1 	add	x1, sp, #0x7
    7fe4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7fe8:	d2800022 	mov	x2, #0x1                   	// #1
    7fec:	17fffe39 	b	78d0 <fwp_write+0x31c>
    7ff0:	a9400281 	ldp	x1, x0, [x20]
    7ff4:	91000800 	add	x0, x0, #0x2
    7ff8:	8b160000 	add	x0, x0, x22
    7ffc:	f9000680 	str	x0, [x20, #8]
    8000:	3820683f 	strb	wzr, [x1, x0]
    8004:	f9413bf5 	ldr	x21, [sp, #624]
    8008:	f9413ff6 	ldr	x22, [sp, #632]
    800c:	f94153fb 	ldr	x27, [sp, #672]
    8010:	f94157fc 	ldr	x28, [sp, #680]
    8014:	17fffd94 	b	7664 <fwp_write+0xb0>
    8018:	f9400f80 	ldr	x0, [x28, #24]
    801c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8020:	aa1b03e0 	mov	x0, x27
    8024:	97ffe9bf 	bl	2720 <strlen@plt>
    8028:	aa1b03e1 	mov	x1, x27
    802c:	aa0003e2 	mov	x2, x0
    8030:	aa1403e0 	mov	x0, x20
    8034:	97ffed57 	bl	3590 <buf_put>
    8038:	aa1903e1 	mov	x1, x25
    803c:	aa1403e0 	mov	x0, x20
    8040:	d2800062 	mov	x2, #0x3                   	// #3
    8044:	97ffed53 	bl	3590 <buf_put>
    8048:	17fffe11 	b	788c <fwp_write+0x2d8>
    804c:	aa1a03e1 	mov	x1, x26
    8050:	aa1403e0 	mov	x0, x20
    8054:	d2800042 	mov	x2, #0x2                   	// #2
    8058:	97ffed4e 	bl	3590 <buf_put>
    805c:	17fffe0a 	b	7884 <fwp_write+0x2d0>
    8060:	f9400660 	ldr	x0, [x19, #8]
    8064:	b4fffb00 	cbz	x0, 7fc4 <fwp_write+0xa10>
    8068:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x100>
    806c:	9111c021 	add	x1, x1, #0x470
    8070:	97ffea28 	bl	2910 <strcmp@plt>
    8074:	7100001f 	cmp	w0, #0x0
    8078:	1a9f07e0 	cset	w0, ne	// ne = any
    807c:	17ffff2f 	b	7d38 <fwp_write+0x784>
    8080:	aa1403e0 	mov	x0, x20
    8084:	d2800042 	mov	x2, #0x2                   	// #2
    8088:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x100>
    808c:	9111a021 	add	x1, x1, #0x468
    8090:	97ffed40 	bl	3590 <buf_put>
    8094:	91004261 	add	x1, x19, #0x10
    8098:	aa1403e0 	mov	x0, x20
    809c:	f9402382 	ldr	x2, [x28, #64]
    80a0:	52800003 	mov	w3, #0x0                   	// #0
    80a4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    80a8:	97fffd43 	bl	75b4 <fwp_write>
    80ac:	17fffd9d 	b	7720 <fwp_write+0x16c>
    80b0:	1e22c109 	fcvt	d9, s8
    80b4:	910123f5 	add	x21, sp, #0x48
    80b8:	52800033 	mov	w19, #0x1                   	// #1
    80bc:	d503201f 	nop
    80c0:	1e604120 	fmov	d0, d9
    80c4:	2a1303e1 	mov	w1, w19
    80c8:	aa1503e0 	mov	x0, x21
    80cc:	97ffedcd 	bl	3800 <fwp_format_g.constprop.0>
    80d0:	aa1503e0 	mov	x0, x21
    80d4:	d2800001 	mov	x1, #0x0                   	// #0
    80d8:	97ffea1a 	bl	2940 <strtof@plt>
    80dc:	1e202100 	fcmp	s8, s0
    80e0:	54ffdb60 	b.eq	7c4c <fwp_write+0x698>  // b.none
    80e4:	11000673 	add	w19, w19, #0x1
    80e8:	71002a7f 	cmp	w19, #0xa
    80ec:	54fffea1 	b.ne	80c0 <fwp_write+0xb0c>  // b.any
    80f0:	1e604120 	fmov	d0, d9
    80f4:	aa1503e0 	mov	x0, x21
    80f8:	52800121 	mov	w1, #0x9                   	// #9
    80fc:	97ffedc1 	bl	3800 <fwp_format_g.constprop.0>
    8100:	17fffed3 	b	7c4c <fwp_write+0x698>
    8104:	d37ef6a1 	lsl	x1, x21, #2
    8108:	b7f81563 	tbnz	x3, #63, 83b4 <fwp_write+0xe00>
    810c:	91002263 	add	x3, x19, #0x8
    8110:	8b010061 	add	x1, x3, x1
    8114:	b9400023 	ldr	w3, [x1]
    8118:	7100081f 	cmp	w0, #0x2
    811c:	2a0303e1 	mov	w1, w3
    8120:	93407c63 	sxtw	x3, w3
    8124:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8128:	17fffe5a 	b	7a90 <fwp_write+0x4dc>
    812c:	d37ffaa1 	lsl	x1, x21, #1
    8130:	b7f81363 	tbnz	x3, #63, 839c <fwp_write+0xde8>
    8134:	91002263 	add	x3, x19, #0x8
    8138:	8b010061 	add	x1, x3, x1
    813c:	79400021 	ldrh	w1, [x1]
    8140:	7100041f 	cmp	w0, #0x1
    8144:	93403c23 	sxth	x3, w1
    8148:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    814c:	17fffe51 	b	7a90 <fwp_write+0x4dc>
    8150:	52800443 	mov	w3, #0x22                  	// #34
    8154:	91001ff5 	add	x21, sp, #0x7
    8158:	91002273 	add	x19, x19, #0x8
    815c:	aa1503e1 	mov	x1, x21
    8160:	aa1403e0 	mov	x0, x20
    8164:	d2800022 	mov	x2, #0x1                   	// #1
    8168:	39001fe3 	strb	w3, [sp, #7]
    816c:	f90143f7 	str	x23, [sp, #640]
    8170:	8b160277 	add	x23, x19, x22
    8174:	f90147f8 	str	x24, [sp, #648]
    8178:	97ffed06 	bl	3590 <buf_put>
    817c:	b4000696 	cbz	x22, 824c <fwp_write+0xc98>
    8180:	f0000018 	adrp	x24, b000 <_IO_stdin_used+0x100>
    8184:	91106318 	add	x24, x24, #0x418
    8188:	f9014bf9 	str	x25, [sp, #656]
    818c:	f0000019 	adrp	x25, b000 <_IO_stdin_used+0x100>
    8190:	9110e339 	add	x25, x25, #0x438
    8194:	f9014ffa 	str	x26, [sp, #664]
    8198:	1400000d 	b	81cc <fwp_write+0xc18>
    819c:	710024bf 	cmp	w5, #0x9
    81a0:	54000460 	b.eq	822c <fwp_write+0xc78>  // b.none
    81a4:	710028bf 	cmp	w5, #0xa
    81a8:	54000a61 	b.ne	82f4 <fwp_write+0xd40>  // b.any
    81ac:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x100>
    81b0:	aa1403e0 	mov	x0, x20
    81b4:	9110a021 	add	x1, x1, #0x428
    81b8:	d2800042 	mov	x2, #0x2                   	// #2
    81bc:	97ffecf5 	bl	3590 <buf_put>
    81c0:	91000673 	add	x19, x19, #0x1
    81c4:	eb17027f 	cmp	x19, x23
    81c8:	540003e0 	b.eq	8244 <fwp_write+0xc90>  // b.none
    81cc:	39400265 	ldrb	w5, [x19]
    81d0:	710034bf 	cmp	w5, #0xd
    81d4:	54000180 	b.eq	8204 <fwp_write+0xc50>  // b.none
    81d8:	54fffe29 	b.ls	819c <fwp_write+0xbe8>  // b.plast
    81dc:	710088bf 	cmp	w5, #0x22
    81e0:	540001c0 	b.eq	8218 <fwp_write+0xc64>  // b.none
    81e4:	710170bf 	cmp	w5, #0x5c
    81e8:	54000741 	b.ne	82d0 <fwp_write+0xd1c>  // b.any
    81ec:	aa1403e0 	mov	x0, x20
    81f0:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x100>
    81f4:	d2800042 	mov	x2, #0x2                   	// #2
    81f8:	91108021 	add	x1, x1, #0x420
    81fc:	97ffece5 	bl	3590 <buf_put>
    8200:	17fffff0 	b	81c0 <fwp_write+0xc0c>
    8204:	aa1903e1 	mov	x1, x25
    8208:	aa1403e0 	mov	x0, x20
    820c:	d2800042 	mov	x2, #0x2                   	// #2
    8210:	97ffece0 	bl	3590 <buf_put>
    8214:	17ffffeb 	b	81c0 <fwp_write+0xc0c>
    8218:	aa1803e1 	mov	x1, x24
    821c:	aa1403e0 	mov	x0, x20
    8220:	d2800042 	mov	x2, #0x2                   	// #2
    8224:	97ffecdb 	bl	3590 <buf_put>
    8228:	17ffffe6 	b	81c0 <fwp_write+0xc0c>
    822c:	aa1403e0 	mov	x0, x20
    8230:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x100>
    8234:	d2800042 	mov	x2, #0x2                   	// #2
    8238:	9110c021 	add	x1, x1, #0x430
    823c:	97ffecd5 	bl	3590 <buf_put>
    8240:	17ffffe0 	b	81c0 <fwp_write+0xc0c>
    8244:	f9414bf9 	ldr	x25, [sp, #656]
    8248:	f9414ffa 	ldr	x26, [sp, #664]
    824c:	aa1503e1 	mov	x1, x21
    8250:	aa1403e0 	mov	x0, x20
    8254:	52800443 	mov	w3, #0x22                  	// #34
    8258:	17fffd9d 	b	78cc <fwp_write+0x318>
    825c:	7100103f 	cmp	w1, #0x4
    8260:	54ffeb21 	b.ne	7fc4 <fwp_write+0xa10>  // b.any
    8264:	f94006e0 	ldr	x0, [x23, #8]
    8268:	d37ffc00 	lsr	x0, x0, #63
    826c:	17fffeb3 	b	7d38 <fwp_write+0x784>
    8270:	710002ff 	cmp	w23, #0x0
    8274:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8278:	17fffeb0 	b	7d38 <fwp_write+0x784>
    827c:	528005a1 	mov	w1, #0x2d                  	// #45
    8280:	eb0203e2 	negs	x2, x2
    8284:	da0303e3 	ngc	x3, x3
    8288:	910127e0 	add	x0, sp, #0x49
    828c:	910123f5 	add	x21, sp, #0x48
    8290:	390123e1 	strb	w1, [sp, #72]
    8294:	97ffeae3 	bl	2e20 <fwp_fmt_u128>
    8298:	17fffe18 	b	7af8 <fwp_write+0x544>
    829c:	d37ceea1 	lsl	x1, x21, #4
    82a0:	b7f810a3 	tbnz	x3, #63, 84b4 <fwp_write+0xf00>
    82a4:	91002260 	add	x0, x19, #0x8
    82a8:	8b010001 	add	x1, x0, x1
    82ac:	17fffdf9 	b	7a90 <fwp_write+0x4dc>
    82b0:	f9400a61 	ldr	x1, [x19, #16]
    82b4:	8b010000 	add	x0, x0, x1
    82b8:	f9400001 	ldr	x1, [x0]
    82bc:	17fffdf5 	b	7a90 <fwp_write+0x4dc>
    82c0:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x100>
    82c4:	d2800042 	mov	x2, #0x2                   	// #2
    82c8:	910f0021 	add	x1, x1, #0x3c0
    82cc:	17fffed6 	b	7e24 <fwp_write+0x870>
    82d0:	7101fcbf 	cmp	w5, #0x7f
    82d4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    82d8:	540000e9 	b.ls	82f4 <fwp_write+0xd40>  // b.plast
    82dc:	aa1503e1 	mov	x1, x21
    82e0:	aa1403e0 	mov	x0, x20
    82e4:	d2800022 	mov	x2, #0x1                   	// #1
    82e8:	39001fe5 	strb	w5, [sp, #7]
    82ec:	97ffeca9 	bl	3590 <buf_put>
    82f0:	17ffffb4 	b	81c0 <fwp_write+0xc0c>
    82f4:	d2800203 	mov	x3, #0x10                  	// #16
    82f8:	f0000004 	adrp	x4, b000 <_IO_stdin_used+0x100>
    82fc:	aa0303e1 	mov	x1, x3
    8300:	91110084 	add	x4, x4, #0x440
    8304:	910123f6 	add	x22, sp, #0x48
    8308:	52800042 	mov	w2, #0x2                   	// #2
    830c:	aa1603e0 	mov	x0, x22
    8310:	97ffe93c 	bl	2800 <__snprintf_chk@plt>
    8314:	aa1603e0 	mov	x0, x22
    8318:	97ffe902 	bl	2720 <strlen@plt>
    831c:	aa1603e1 	mov	x1, x22
    8320:	aa0003e2 	mov	x2, x0
    8324:	aa1403e0 	mov	x0, x20
    8328:	97ffec9a 	bl	3590 <buf_put>
    832c:	17ffffa5 	b	81c0 <fwp_write+0xc0c>
    8330:	1e604100 	fmov	d0, d8
    8334:	aa1503e0 	mov	x0, x21
    8338:	52800221 	mov	w1, #0x11                  	// #17
    833c:	97ffed31 	bl	3800 <fwp_format_g.constprop.0>
    8340:	17fffe43 	b	7c4c <fwp_write+0x698>
    8344:	b9401040 	ldr	w0, [x2, #16]
    8348:	350003c0 	cbnz	w0, 83c0 <fwp_write+0xe0c>
    834c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8350:	f947f400 	ldr	x0, [x0, #4072]
    8354:	f94127e2 	ldr	x2, [sp, #584]
    8358:	f9400001 	ldr	x1, [x0]
    835c:	eb010042 	subs	x2, x2, x1
    8360:	d2800001 	mov	x1, #0x0                   	// #0
    8364:	54ffd721 	b.ne	7e48 <fwp_write+0x894>  // b.any
    8368:	f9413bf5 	ldr	x21, [sp, #624]
    836c:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x100>
    8370:	f9413ff6 	ldr	x22, [sp, #632]
    8374:	aa1403e0 	mov	x0, x20
    8378:	f94143f7 	ldr	x23, [sp, #640]
    837c:	91124021 	add	x1, x1, #0x490
    8380:	f94147f8 	ldr	x24, [sp, #648]
    8384:	d2800042 	mov	x2, #0x2                   	// #2
    8388:	17fffd0f 	b	77c4 <fwp_write+0x210>
    838c:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x100>
    8390:	d2800042 	mov	x2, #0x2                   	// #2
    8394:	910f2021 	add	x1, x1, #0x3c8
    8398:	17fffea3 	b	7e24 <fwp_write+0x870>
    839c:	f9400a63 	ldr	x3, [x19, #16]
    83a0:	8b030021 	add	x1, x1, x3
    83a4:	17ffff66 	b	813c <fwp_write+0xb88>
    83a8:	f9400a61 	ldr	x1, [x19, #16]
    83ac:	8b0102a1 	add	x1, x21, x1
    83b0:	17fffdb4 	b	7a80 <fwp_write+0x4cc>
    83b4:	f9400a63 	ldr	x3, [x19, #16]
    83b8:	8b030021 	add	x1, x1, x3
    83bc:	17ffff56 	b	8114 <fwp_write+0xb60>
    83c0:	b9404840 	ldr	w0, [x2, #72]
    83c4:	91001ff5 	add	x21, sp, #0x7
    83c8:	34ffa380 	cbz	w0, 7838 <fwp_write+0x284>
    83cc:	52800503 	mov	w3, #0x28                  	// #40
    83d0:	aa1403e0 	mov	x0, x20
    83d4:	aa1503e1 	mov	x1, x21
    83d8:	d2800022 	mov	x2, #0x1                   	// #1
    83dc:	39001fe3 	strb	w3, [sp, #7]
    83e0:	97ffec6c 	bl	3590 <buf_put>
    83e4:	b9401380 	ldr	w0, [x28, #16]
    83e8:	52800038 	mov	w24, #0x1                   	// #1
    83ec:	7100001f 	cmp	w0, #0x0
    83f0:	54ffa38c 	b.gt	7860 <fwp_write+0x2ac>
    83f4:	17fffd33 	b	78c0 <fwp_write+0x30c>
    83f8:	f9014bf9 	str	x25, [sp, #656]
    83fc:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10f68>
    8400:	f9014ffa 	str	x26, [sp, #664]
    8404:	f9400676 	ldr	x22, [x19, #8]
    8408:	910ae333 	add	x19, x25, #0x2b8
    840c:	91002273 	add	x19, x19, #0x8
    8410:	937ffed8 	asr	x24, x22, #63
    8414:	aa1802c0 	orr	x0, x22, x24
    8418:	b5000320 	cbnz	x0, 847c <fwp_write+0xec8>
    841c:	110006b5 	add	w21, w21, #0x1
    8420:	710016bf 	cmp	w21, #0x5
    8424:	54ffffc1 	b.ne	841c <fwp_write+0xe68>  // b.any
    8428:	b7f80578 	tbnz	x24, #63, 84d4 <fwp_write+0xf20>
    842c:	910023f3 	add	x19, sp, #0x8
    8430:	aa1603e2 	mov	x2, x22
    8434:	aa1303e0 	mov	x0, x19
    8438:	d2800003 	mov	x3, #0x0                   	// #0
    843c:	97ffea79 	bl	2e20 <fwp_fmt_u128>
    8440:	910123f5 	add	x21, sp, #0x48
    8444:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x100>
    8448:	aa1303e4 	mov	x4, x19
    844c:	aa1503e0 	mov	x0, x21
    8450:	91122063 	add	x3, x3, #0x488
    8454:	d2804002 	mov	x2, #0x200                 	// #512
    8458:	52800041 	mov	w1, #0x2                   	// #2
    845c:	97ffe8b5 	bl	2730 <__sprintf_chk@plt>
    8460:	aa1503e0 	mov	x0, x21
    8464:	97ffe8af 	bl	2720 <strlen@plt>
    8468:	aa1503e1 	mov	x1, x21
    846c:	aa0003e2 	mov	x2, x0
    8470:	aa1403e0 	mov	x0, x20
    8474:	97ffec47 	bl	3590 <buf_put>
    8478:	17fffe47 	b	7d94 <fwp_write+0x7e0>
    847c:	f9400277 	ldr	x23, [x19]
    8480:	aa1603e0 	mov	x0, x22
    8484:	aa1803e1 	mov	x1, x24
    8488:	aa1703e2 	mov	x2, x23
    848c:	937ffefa 	asr	x26, x23, #63
    8490:	aa1a03e3 	mov	x3, x26
    8494:	940009b3 	bl	ab60 <__modti3>
    8498:	aa010000 	orr	x0, x0, x1
    849c:	b40002c0 	cbz	x0, 84f4 <fwp_write+0xf40>
    84a0:	110006b5 	add	w21, w21, #0x1
    84a4:	91004273 	add	x19, x19, #0x10
    84a8:	710016bf 	cmp	w21, #0x5
    84ac:	54fffe81 	b.ne	847c <fwp_write+0xec8>  // b.any
    84b0:	17ffffde 	b	8428 <fwp_write+0xe74>
    84b4:	f9400a60 	ldr	x0, [x19, #16]
    84b8:	8b000021 	add	x1, x1, x0
    84bc:	17fffd75 	b	7a90 <fwp_write+0x4dc>
    84c0:	528c29c0 	mov	w0, #0x614e                	// #24910
    84c4:	910123f5 	add	x21, sp, #0x48
    84c8:	72a009c0 	movk	w0, #0x4e, lsl #16
    84cc:	b9004be0 	str	w0, [sp, #72]
    84d0:	17fffda2 	b	7b58 <fwp_write+0x5a4>
    84d4:	528005a1 	mov	w1, #0x2d                  	// #45
    84d8:	eb1603e2 	negs	x2, x22
    84dc:	da1803e3 	ngc	x3, x24
    84e0:	910027e0 	add	x0, sp, #0x9
    84e4:	910023f3 	add	x19, sp, #0x8
    84e8:	390023e1 	strb	w1, [sp, #8]
    84ec:	97ffea4d 	bl	2e20 <fwp_fmt_u128>
    84f0:	17ffffd4 	b	8440 <fwp_write+0xe8c>
    84f4:	aa1703e2 	mov	x2, x23
    84f8:	aa1a03e3 	mov	x3, x26
    84fc:	aa1603e0 	mov	x0, x22
    8500:	aa1803e1 	mov	x1, x24
    8504:	940008b7 	bl	a7e0 <__divti3>
    8508:	aa0003e2 	mov	x2, x0
    850c:	aa0103e3 	mov	x3, x1
    8510:	b7f80201 	tbnz	x1, #63, 8550 <fwp_write+0xf9c>
    8514:	910023f3 	add	x19, sp, #0x8
    8518:	aa1303e0 	mov	x0, x19
    851c:	97ffea41 	bl	2e20 <fwp_fmt_u128>
    8520:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8524:	910ae339 	add	x25, x25, #0x2b8
    8528:	910123f5 	add	x21, sp, #0x48
    852c:	aa1303e4 	mov	x4, x19
    8530:	aa1503e0 	mov	x0, x21
    8534:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x100>
    8538:	f8616b25 	ldr	x5, [x25, x1]
    853c:	91120063 	add	x3, x3, #0x480
    8540:	d2804002 	mov	x2, #0x200                 	// #512
    8544:	52800041 	mov	w1, #0x2                   	// #2
    8548:	97ffe87a 	bl	2730 <__sprintf_chk@plt>
    854c:	17ffffc5 	b	8460 <fwp_write+0xeac>
    8550:	528005a4 	mov	w4, #0x2d                  	// #45
    8554:	eb0003e2 	negs	x2, x0
    8558:	da0103e3 	ngc	x3, x1
    855c:	910027e0 	add	x0, sp, #0x9
    8560:	910023f3 	add	x19, sp, #0x8
    8564:	390023e4 	strb	w4, [sp, #8]
    8568:	97ffea2e 	bl	2e20 <fwp_fmt_u128>
    856c:	17ffffed 	b	8520 <fwp_write+0xf6c>
    8570:	f9013bf5 	str	x21, [sp, #624]
    8574:	f9013ff6 	str	x22, [sp, #632]
    8578:	f90143f7 	str	x23, [sp, #640]
    857c:	f90147f8 	str	x24, [sp, #648]
    8580:	f9014bf9 	str	x25, [sp, #656]
    8584:	f9014ffa 	str	x26, [sp, #664]
    8588:	f90153fb 	str	x27, [sp, #672]
    858c:	f90157fc 	str	x28, [sp, #680]
    8590:	fd015be8 	str	d8, [sp, #688]
    8594:	fd015fe9 	str	d9, [sp, #696]
    8598:	97ffe8be 	bl	2890 <__stack_chk_fail@plt>
    859c:	d503201f 	nop

00000000000085a0 <fwp_main_thread>:
    85a0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    85a4:	910003fd 	mov	x29, sp
    85a8:	a90153f3 	stp	x19, x20, [sp, #16]
    85ac:	b0000153 	adrp	x19, 31000 <fwp_root_context+0xc20>
    85b0:	91170261 	add	x1, x19, #0x5c0
    85b4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    85b8:	f947f400 	ldr	x0, [x0, #4072]
    85bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    85c0:	a90363f7 	stp	x23, x24, [sp, #48]
    85c4:	d10743ff 	sub	sp, sp, #0x1d0
    85c8:	b953a421 	ldr	w1, [x1, #5028]
    85cc:	f9400002 	ldr	x2, [x0]
    85d0:	f900e7e2 	str	x2, [sp, #456]
    85d4:	d2800002 	mov	x2, #0x0                   	// #0
    85d8:	34000f01 	cbz	w1, 87b8 <fwp_main_thread+0x218>
    85dc:	91170260 	add	x0, x19, #0x5c0
    85e0:	b953a800 	ldr	w0, [x0, #5032]
    85e4:	35000e20 	cbnz	w0, 87a8 <fwp_main_thread+0x208>
    85e8:	900000d4 	adrp	x20, 20000 <__data_start>
    85ec:	900000c2 	adrp	x2, 20000 <__data_start>
    85f0:	9101c297 	add	x23, x20, #0x70
    85f4:	910f8042 	add	x2, x2, #0x3e0
    85f8:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    85fc:	d2a00024 	mov	x4, #0x10000               	// #65536
    8600:	910343f5 	add	x21, sp, #0xd0
    8604:	9102c3f8 	add	x24, sp, #0xb0
    8608:	aa1503e0 	mov	x0, x21
    860c:	d2800001 	mov	x1, #0x0                   	// #0
    8610:	a9018ef8 	stp	x24, x3, [x23, #24]
    8614:	f9006be2 	str	x2, [sp, #208]
    8618:	b900dbff 	str	wzr, [sp, #216]
    861c:	f90073e4 	str	x4, [sp, #224]
    8620:	97ffe838 	bl	2700 <sigaltstack@plt>
    8624:	35000220 	cbnz	w0, 8668 <fwp_main_thread+0xc8>
    8628:	4f000400 	movi	v0.4s, #0x0
    862c:	9104e3e0 	add	x0, sp, #0x138
    8630:	f0ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    8634:	9101c021 	add	x1, x1, #0x70
    8638:	f9009be1 	str	x1, [sp, #304]
    863c:	52800082 	mov	w2, #0x4                   	// #4
    8640:	72a10002 	movk	w2, #0x800, lsl #16
    8644:	9104c3f6 	add	x22, sp, #0x130
    8648:	3d802000 	str	q0, [x0, #128]
    864c:	b901bbe2 	str	w2, [sp, #440]
    8650:	ad000000 	stp	q0, q0, [x0]
    8654:	ad010000 	stp	q0, q0, [x0, #32]
    8658:	ad020000 	stp	q0, q0, [x0, #64]
    865c:	ad030000 	stp	q0, q0, [x0, #96]
    8660:	97ffe87c 	bl	2850 <sigemptyset@plt>
    8664:	34000100 	cbz	w0, 8684 <fwp_main_thread+0xe4>
    8668:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    866c:	91128000 	add	x0, x0, #0x4a0
    8670:	f9010bf9 	str	x25, [sp, #528]
    8674:	f9010ffa 	str	x26, [sp, #536]
    8678:	f90113fb 	str	x27, [sp, #544]
    867c:	f90117fc 	str	x28, [sp, #552]
    8680:	97ffeea0 	bl	4100 <fwp_trap>
    8684:	aa1603e1 	mov	x1, x22
    8688:	d2800002 	mov	x2, #0x0                   	// #0
    868c:	52800160 	mov	w0, #0xb                   	// #11
    8690:	97ffe888 	bl	28b0 <sigaction@plt>
    8694:	35fffea0 	cbnz	w0, 8668 <fwp_main_thread+0xc8>
    8698:	aa1603e1 	mov	x1, x22
    869c:	d2800002 	mov	x2, #0x0                   	// #0
    86a0:	528000e0 	mov	w0, #0x7                   	// #7
    86a4:	97ffe883 	bl	28b0 <sigaction@plt>
    86a8:	35fffe00 	cbnz	w0, 8668 <fwp_main_thread+0xc8>
    86ac:	b94336e0 	ldr	w0, [x23, #820]
    86b0:	34000880 	cbz	w0, 87c0 <fwp_main_thread+0x220>
    86b4:	9101c280 	add	x0, x20, #0x70
    86b8:	b9433801 	ldr	w1, [x0, #824]
    86bc:	34000901 	cbz	w1, 87dc <fwp_main_thread+0x23c>
    86c0:	9101c296 	add	x22, x20, #0x70
    86c4:	f9400ad5 	ldr	x21, [x22, #16]
    86c8:	b40015f5 	cbz	x21, 8984 <fwp_main_thread+0x3e4>
    86cc:	910102b7 	add	x23, x21, #0x40
    86d0:	f9010bf9 	str	x25, [sp, #528]
    86d4:	f9010ffa 	str	x26, [sp, #536]
    86d8:	52800038 	mov	w24, #0x1                   	// #1
    86dc:	39414ab9 	ldrb	w25, [x21, #82]
    86e0:	39014ab8 	strb	w24, [x21, #82]
    86e4:	d503201f 	nop
    86e8:	f94016a0 	ldr	x0, [x21, #40]
    86ec:	b4001460 	cbz	x0, 8978 <fwp_main_thread+0x3d8>
    86f0:	f94032a1 	ldr	x1, [x21, #96]
    86f4:	394146a0 	ldrb	w0, [x21, #81]
    86f8:	b4001081 	cbz	x1, 8908 <fwp_main_thread+0x368>
    86fc:	36000f40 	tbz	w0, #0, 88e4 <fwp_main_thread+0x344>
    8700:	f9400ad3 	ldr	x19, [x22, #16]
    8704:	f94022a0 	ldr	x0, [x21, #64]
    8708:	39414a61 	ldrb	w1, [x19, #82]
    870c:	37001261 	tbnz	w1, #0, 8958 <fwp_main_thread+0x3b8>
    8710:	f9403261 	ldr	x1, [x19, #96]
    8714:	a911fe77 	stp	x23, xzr, [x19, #280]
    8718:	f9009660 	str	x0, [x19, #296]
    871c:	b4000040 	cbz	x0, 8724 <fwp_main_thread+0x184>
    8720:	f9009013 	str	x19, [x0, #288]
    8724:	f90022b3 	str	x19, [x21, #64]
    8728:	b4000101 	cbz	x1, 8748 <fwp_main_thread+0x1a8>
    872c:	f94066c0 	ldr	x0, [x22, #200]
    8730:	39015678 	strb	w24, [x19, #85]
    8734:	f9003661 	str	x1, [x19, #104]
    8738:	a910827f 	stp	xzr, x0, [x19, #264]
    873c:	b4000040 	cbz	x0, 8744 <fwp_main_thread+0x1a4>
    8740:	f9008413 	str	x19, [x0, #264]
    8744:	f90066d3 	str	x19, [x22, #200]
    8748:	39015a7f 	strb	wzr, [x19, #86]
    874c:	97fff911 	bl	6b90 <fwp_block>
    8750:	f9408e62 	ldr	x2, [x19, #280]
    8754:	b4000142 	cbz	x2, 877c <fwp_main_thread+0x1dc>
    8758:	a9520261 	ldp	x1, x0, [x19, #288]
    875c:	b40010a1 	cbz	x1, 8970 <fwp_main_thread+0x3d0>
    8760:	f9009420 	str	x0, [x1, #296]
    8764:	f9409660 	ldr	x0, [x19, #296]
    8768:	b4000040 	cbz	x0, 8770 <fwp_main_thread+0x1d0>
    876c:	f9009001 	str	x1, [x0, #288]
    8770:	91080260 	add	x0, x19, #0x200
    8774:	f900967f 	str	xzr, [x19, #296]
    8778:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    877c:	39415660 	ldrb	w0, [x19, #85]
    8780:	3607fb40 	tbz	w0, #0, 86e8 <fwp_main_thread+0x148>
    8784:	a9508261 	ldp	x1, x0, [x19, #264]
    8788:	b4002041 	cbz	x1, 8b90 <fwp_main_thread+0x5f0>
    878c:	f9008820 	str	x0, [x1, #272]
    8790:	b4000040 	cbz	x0, 8798 <fwp_main_thread+0x1f8>
    8794:	f9008401 	str	x1, [x0, #264]
    8798:	91080260 	add	x0, x19, #0x200
    879c:	3901567f 	strb	wzr, [x19, #85]
    87a0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    87a4:	17ffffd1 	b	86e8 <fwp_main_thread+0x148>
    87a8:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    87ac:	91301000 	add	x0, x0, #0xc04
    87b0:	940009c8 	bl	aed0 <atexit>
    87b4:	17ffff8d 	b	85e8 <fwp_main_thread+0x48>
    87b8:	97ffed6e 	bl	3d70 <fwp_heap_init>
    87bc:	17ffff88 	b	85dc <fwp_main_thread+0x3c>
    87c0:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    87c4:	91058000 	add	x0, x0, #0x160
    87c8:	940009c2 	bl	aed0 <atexit>
    87cc:	3500fb60 	cbnz	w0, a738 <fwp_main_thread+0x2198>
    87d0:	52800020 	mov	w0, #0x1                   	// #1
    87d4:	b90336e0 	str	w0, [x23, #820]
    87d8:	17ffffb7 	b	86b4 <fwp_main_thread+0x114>
    87dc:	f9418003 	ldr	x3, [x0, #768]
    87e0:	f9010bf9 	str	x25, [sp, #528]
    87e4:	f9010ffa 	str	x26, [sp, #536]
    87e8:	9101a3e4 	add	x4, sp, #0x68
    87ec:	f90113fb 	str	x27, [sp, #544]
    87f0:	b0ffffe1 	adrp	x1, 5000 <fwp_data.part.0.constprop.0+0xc>
    87f4:	f90117fc 	str	x28, [sp, #552]
    87f8:	913f0021 	add	x1, x1, #0xfc0
    87fc:	d0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    8800:	91170279 	add	x25, x19, #0x5c0
    8804:	913d4042 	add	x2, x2, #0xf50
    8808:	d280001a 	mov	x26, #0x0                   	// #0
    880c:	d280401b 	mov	x27, #0x200                 	// #512
    8810:	a90093ff 	stp	xzr, x4, [sp, #8]
    8814:	a9068be3 	stp	x3, x2, [sp, #104]
    8818:	f9003ff8 	str	x24, [sp, #120]
    881c:	f9005bff 	str	xzr, [sp, #176]
    8820:	a90c07ff 	stp	xzr, x1, [sp, #192]
    8824:	f9018004 	str	x4, [x0, #768]
    8828:	14000012 	b	8870 <fwp_main_thread+0x2d0>
    882c:	7100045f 	cmp	w2, #0x1
    8830:	540001a1 	b.ne	8864 <fwp_main_thread+0x2c4>  // b.any
    8834:	29430002 	ldp	w2, w0, [x0, #24]
    8838:	92403c21 	and	x1, x1, #0xffff
    883c:	9b027c21 	mul	x1, x1, x2
    8840:	d360fc21 	lsr	x1, x1, #32
    8844:	eb00003f 	cmp	x1, x0
    8848:	540000e2 	b.cs	8864 <fwp_main_thread+0x2c4>  // b.hs, b.nlast
    884c:	8b01039c 	add	x28, x28, x1
    8850:	39400380 	ldrb	w0, [x28]
    8854:	7103fc1f 	cmp	w0, #0xff
    8858:	54003b20 	b.eq	8fbc <fwp_main_thread+0xa1c>  // b.none
    885c:	52800020 	mov	w0, #0x1                   	// #1
    8860:	39000380 	strb	w0, [x28]
    8864:	a90b7ffa 	stp	x26, xzr, [sp, #176]
    8868:	aa170318 	orr	x24, x24, x23
    886c:	b4001978 	cbz	x24, 8b98 <fwp_main_thread+0x5f8>
    8870:	f94007e0 	ldr	x0, [sp, #8]
    8874:	f1000778 	subs	x24, x27, #0x1
    8878:	aa1603e1 	mov	x1, x22
    887c:	f9005ff8 	str	x24, [sp, #184]
    8880:	da1f0017 	sbc	x23, x0, xzr
    8884:	52800020 	mov	w0, #0x1                   	// #1
    8888:	f90007f7 	str	x23, [sp, #8]
    888c:	aa1803fb 	mov	x27, x24
    8890:	a9136bf8 	stp	x24, x26, [sp, #304]
    8894:	97fff1d8 	bl	4ff4 <fwp_data.part.0.constprop.0>
    8898:	aa0003fa 	mov	x26, x0
    889c:	f949db21 	ldr	x1, [x25, #5040]
    88a0:	f949ef20 	ldr	x0, [x25, #5080]
    88a4:	cb010341 	sub	x1, x26, x1
    88a8:	eb00403f 	cmp	x1, x0, lsl #16
    88ac:	54fffdc2 	b.cs	8864 <fwp_main_thread+0x2c4>  // b.hs, b.nlast
    88b0:	d350fc22 	lsr	x2, x1, #16
    88b4:	f949ff26 	ldr	x6, [x25, #5112]
    88b8:	8b020842 	add	x2, x2, x2, lsl #2
    88bc:	d37df042 	lsl	x2, x2, #3
    88c0:	8b0200c0 	add	x0, x6, x2
    88c4:	f940101c 	ldr	x28, [x0, #32]
    88c8:	b4fffcfc 	cbz	x28, 8864 <fwp_main_thread+0x2c4>
    88cc:	386268c2 	ldrb	w2, [x6, x2]
    88d0:	7100085f 	cmp	w2, #0x2
    88d4:	54fffac1 	b.ne	882c <fwp_main_thread+0x28c>  // b.any
    88d8:	72003c3f 	tst	w1, #0xffff
    88dc:	54fffc41 	b.ne	8864 <fwp_main_thread+0x2c4>  // b.any
    88e0:	17ffffdc 	b	8850 <fwp_main_thread+0x2b0>
    88e4:	97fff027 	bl	4980 <fwp_now_ns>
    88e8:	f94032a1 	ldr	x1, [x21, #96]
    88ec:	eb01001f 	cmp	x0, x1
    88f0:	540000ab 	b.lt	8904 <fwp_main_thread+0x364>  // b.tstop
    88f4:	394142a0 	ldrb	w0, [x21, #80]
    88f8:	37000060 	tbnz	w0, #0, 8904 <fwp_main_thread+0x364>
    88fc:	aa1503e0 	mov	x0, x21
    8900:	97ffeb7c 	bl	36f0 <fwp_cancel_tree.part.0>
    8904:	394146a0 	ldrb	w0, [x21, #81]
    8908:	f9400ad3 	ldr	x19, [x22, #16]
    890c:	39414a62 	ldrb	w2, [x19, #82]
    8910:	3707ef80 	tbnz	w0, #0, 8700 <fwp_main_thread+0x160>
    8914:	f94032a1 	ldr	x1, [x21, #96]
    8918:	370001c2 	tbnz	w2, #0, 8950 <fwp_main_thread+0x3b0>
    891c:	f9403260 	ldr	x0, [x19, #96]
    8920:	b4000180 	cbz	x0, 8950 <fwp_main_thread+0x3b0>
    8924:	b4000061 	cbz	x1, 8930 <fwp_main_thread+0x390>
    8928:	eb01001f 	cmp	x0, x1
    892c:	9a81d000 	csel	x0, x0, x1, le
    8930:	f94022a1 	ldr	x1, [x21, #64]
    8934:	a911fe77 	stp	x23, xzr, [x19, #280]
    8938:	f9009661 	str	x1, [x19, #296]
    893c:	b4003461 	cbz	x1, 8fc8 <fwp_main_thread+0xa28>
    8940:	f9009033 	str	x19, [x1, #288]
    8944:	aa0003e1 	mov	x1, x0
    8948:	f90022b3 	str	x19, [x21, #64]
    894c:	17ffff78 	b	872c <fwp_main_thread+0x18c>
    8950:	f94022a0 	ldr	x0, [x21, #64]
    8954:	17ffff70 	b	8714 <fwp_main_thread+0x174>
    8958:	a911fe77 	stp	x23, xzr, [x19, #280]
    895c:	f9009660 	str	x0, [x19, #296]
    8960:	b4000040 	cbz	x0, 8968 <fwp_main_thread+0x3c8>
    8964:	f9009013 	str	x19, [x0, #288]
    8968:	f90022b3 	str	x19, [x21, #64]
    896c:	17ffff77 	b	8748 <fwp_main_thread+0x1a8>
    8970:	f9000040 	str	x0, [x2]
    8974:	17ffff7d 	b	8768 <fwp_main_thread+0x1c8>
    8978:	f9410ffa 	ldr	x26, [sp, #536]
    897c:	39014ab9 	strb	w25, [x21, #82]
    8980:	f9410bf9 	ldr	x25, [sp, #528]
    8984:	9101c293 	add	x19, x20, #0x70
    8988:	f9418e60 	ldr	x0, [x19, #792]
    898c:	b5000060 	cbnz	x0, 8998 <fwp_main_thread+0x3f8>
    8990:	f9419660 	ldr	x0, [x19, #808]
    8994:	b4004620 	cbz	x0, 9258 <fwp_main_thread+0xcb8>
    8998:	9101c280 	add	x0, x20, #0x70
    899c:	f9400800 	ldr	x0, [x0, #16]
    89a0:	9101c281 	add	x1, x20, #0x70
    89a4:	f941a826 	ldr	x6, [x1, #848]
    89a8:	b903483f 	str	wzr, [x1, #840]
    89ac:	eb0000df 	cmp	x6, x0
    89b0:	5400f0e1 	b.ne	a7cc <fwp_main_thread+0x222c>  // b.any
    89b4:	b40003c0 	cbz	x0, 8a2c <fwp_main_thread+0x48c>
    89b8:	f9417825 	ldr	x5, [x1, #752]
    89bc:	52800021 	mov	w1, #0x1                   	// #1
    89c0:	39014801 	strb	w1, [x0, #82]
    89c4:	b4000345 	cbz	x5, 8a2c <fwp_main_thread+0x48c>
    89c8:	394140a0 	ldrb	w0, [x5, #80]
    89cc:	37000060 	tbnz	w0, #0, 89d8 <fwp_main_thread+0x438>
    89d0:	aa0503e0 	mov	x0, x5
    89d4:	97ffeb47 	bl	36f0 <fwp_cancel_tree.part.0>
    89d8:	f9409ca5 	ldr	x5, [x5, #312]
    89dc:	b5ffff65 	cbnz	x5, 89c8 <fwp_main_thread+0x428>
    89e0:	9101c293 	add	x19, x20, #0x70
    89e4:	52800035 	mov	w21, #0x1                   	// #1
    89e8:	f94028c0 	ldr	x0, [x6, #80]
    89ec:	f2001c1f 	tst	x0, #0xff000000ff
    89f0:	540000e1 	b.ne	8a0c <fwp_main_thread+0x46c>  // b.any
    89f4:	f9403e60 	ldr	x0, [x19, #120]
    89f8:	390150d5 	strb	w21, [x6, #84]
    89fc:	f90080df 	str	xzr, [x6, #256]
    8a00:	b4000120 	cbz	x0, 8a24 <fwp_main_thread+0x484>
    8a04:	f9008006 	str	x6, [x0, #256]
    8a08:	f9003e66 	str	x6, [x19, #120]
    8a0c:	97fff861 	bl	6b90 <fwp_block>
    8a10:	97fff7e8 	bl	69b0 <fwp_free_zombie>
    8a14:	f9417a60 	ldr	x0, [x19, #752]
    8a18:	b40000a0 	cbz	x0, 8a2c <fwp_main_thread+0x48c>
    8a1c:	f941aa66 	ldr	x6, [x19, #848]
    8a20:	17fffff2 	b	89e8 <fwp_main_thread+0x448>
    8a24:	f9004266 	str	x6, [x19, #128]
    8a28:	17fffff8 	b	8a08 <fwp_main_thread+0x468>
    8a2c:	9101c295 	add	x21, x20, #0x70
    8a30:	97fff7e0 	bl	69b0 <fwp_free_zombie>
    8a34:	f94042a0 	ldr	x0, [x21, #128]
    8a38:	b500eca0 	cbnz	x0, a7cc <fwp_main_thread+0x222c>
    8a3c:	f94066a0 	ldr	x0, [x21, #200]
    8a40:	b500ec60 	cbnz	x0, a7cc <fwp_main_thread+0x222c>
    8a44:	b940eab3 	ldr	w19, [x21, #232]
    8a48:	340001f3 	cbz	w19, 8a84 <fwp_main_thread+0x4e4>
    8a4c:	93407e76 	sxtw	x22, w19
    8a50:	51000673 	sub	w19, w19, #0x1
    8a54:	d1000ad6 	sub	x22, x22, #0x2
    8a58:	9103c2b7 	add	x23, x21, #0xf0
    8a5c:	cb3342d6 	sub	x22, x22, w19, uxtw
    8a60:	93407e73 	sxtw	x19, w19
    8a64:	d503201f 	nop
    8a68:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    8a6c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8a70:	b900eab3 	str	w19, [x21, #232]
    8a74:	d1000673 	sub	x19, x19, #0x1
    8a78:	97ffe7ce 	bl	29b0 <munmap@plt>
    8a7c:	eb16027f 	cmp	x19, x22
    8a80:	54ffff41 	b.ne	8a68 <fwp_main_thread+0x4c8>  // b.any
    8a84:	900000d7 	adrp	x23, 20000 <__data_start>
    8a88:	910042e0 	add	x0, x23, #0x10
    8a8c:	b9404000 	ldr	w0, [x0, #64]
    8a90:	37f80040 	tbnz	w0, #31, 8a98 <fwp_main_thread+0x4f8>
    8a94:	97ffe783 	bl	28a0 <close@plt>
    8a98:	9101c295 	add	x21, x20, #0x70
    8a9c:	910042f7 	add	x23, x23, #0x10
    8aa0:	12800001 	mov	w1, #0xffffffff            	// #-1
    8aa4:	f941b2a0 	ldr	x0, [x21, #864]
    8aa8:	b90042e1 	str	w1, [x23, #64]
    8aac:	f941aea1 	ldr	x1, [x21, #856]
    8ab0:	b40001c0 	cbz	x0, 8ae8 <fwp_main_thread+0x548>
    8ab4:	d2800013 	mov	x19, #0x0                   	// #0
    8ab8:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    8abc:	b40000e0 	cbz	x0, 8ad8 <fwp_main_thread+0x538>
    8ac0:	f9400001 	ldr	x1, [x0]
    8ac4:	b500e841 	cbnz	x1, a7cc <fwp_main_thread+0x222c>
    8ac8:	f9400401 	ldr	x1, [x0, #8]
    8acc:	b500e801 	cbnz	x1, a7cc <fwp_main_thread+0x222c>
    8ad0:	97ffee48 	bl	43f0 <fwp_mem_free>
    8ad4:	f941aea1 	ldr	x1, [x21, #856]
    8ad8:	91000673 	add	x19, x19, #0x1
    8adc:	f941b2a0 	ldr	x0, [x21, #864]
    8ae0:	eb00027f 	cmp	x19, x0
    8ae4:	54fffea3 	b.cc	8ab8 <fwp_main_thread+0x518>  // b.lo, b.ul, b.last
    8ae8:	aa0103e0 	mov	x0, x1
    8aec:	97ffee41 	bl	43f0 <fwp_mem_free>
    8af0:	9101c280 	add	x0, x20, #0x70
    8af4:	f941a813 	ldr	x19, [x0, #848]
    8af8:	f901ac1f 	str	xzr, [x0, #856]
    8afc:	f901b01f 	str	xzr, [x0, #864]
    8b00:	b40001f3 	cbz	x19, 8b3c <fwp_main_thread+0x59c>
    8b04:	f9401661 	ldr	x1, [x19, #40]
    8b08:	b500e621 	cbnz	x1, a7cc <fwp_main_thread+0x222c>
    8b0c:	f9405661 	ldr	x1, [x19, #168]
    8b10:	b500e5e1 	cbnz	x1, a7cc <fwp_main_thread+0x222c>
    8b14:	f9418c01 	ldr	x1, [x0, #792]
    8b18:	b500e5a1 	cbnz	x1, a7cc <fwp_main_thread+0x222c>
    8b1c:	f9419400 	ldr	x0, [x0, #808]
    8b20:	b500e560 	cbnz	x0, a7cc <fwp_main_thread+0x222c>
    8b24:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8b28:	90000140 	adrp	x0, 30000 <alt.5+0xfc20>
    8b2c:	910f8000 	add	x0, x0, #0x3e0
    8b30:	97ffe74c 	bl	2860 <memset@plt>
    8b34:	aa1303e0 	mov	x0, x19
    8b38:	97ffee2e 	bl	43f0 <fwp_mem_free>
    8b3c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8b40:	f947ec00 	ldr	x0, [x0, #4056]
    8b44:	9101c294 	add	x20, x20, #0x70
    8b48:	f9400000 	ldr	x0, [x0]
    8b4c:	f9000a9f 	str	xzr, [x20, #16]
    8b50:	f901aa9f 	str	xzr, [x20, #848]
    8b54:	97ffe79b 	bl	29c0 <fflush@plt>
    8b58:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8b5c:	f947f400 	ldr	x0, [x0, #4072]
    8b60:	f940e7e2 	ldr	x2, [sp, #456]
    8b64:	f9400001 	ldr	x1, [x0]
    8b68:	eb010042 	subs	x2, x2, x1
    8b6c:	d2800001 	mov	x1, #0x0                   	// #0
    8b70:	5400dee1 	b.ne	a74c <fwp_main_thread+0x21ac>  // b.any
    8b74:	910743ff 	add	sp, sp, #0x1d0
    8b78:	d2800000 	mov	x0, #0x0                   	// #0
    8b7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8b80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8b84:	a94363f7 	ldp	x23, x24, [sp, #48]
    8b88:	a8c67bfd 	ldp	x29, x30, [sp], #96
    8b8c:	d65f03c0 	ret
    8b90:	f90066c0 	str	x0, [x22, #200]
    8b94:	17fffeff 	b	8790 <fwp_main_thread+0x1f0>
    8b98:	9101c282 	add	x2, x20, #0x70
    8b9c:	f9005bff 	str	xzr, [sp, #176]
    8ba0:	f9400be1 	ldr	x1, [sp, #16]
    8ba4:	f9418040 	ldr	x0, [x2, #768]
    8ba8:	eb01001f 	cmp	x0, x1
    8bac:	5400e181 	b.ne	a7dc <fwp_main_thread+0x223c>  // b.any
    8bb0:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    8bb4:	910403e1 	add	x1, sp, #0x100
    8bb8:	f94037e3 	ldr	x3, [sp, #104]
    8bbc:	f9018043 	str	x3, [x2, #768]
    8bc0:	3dc34c00 	ldr	q0, [x0, #3376]
    8bc4:	52800020 	mov	w0, #0x1                   	// #1
    8bc8:	3d8043e0 	str	q0, [sp, #256]
    8bcc:	97fff10a 	bl	4ff4 <fwp_data.part.0.constprop.0>
    8bd0:	91170263 	add	x3, x19, #0x5c0
    8bd4:	aa0003f7 	mov	x23, x0
    8bd8:	f949d861 	ldr	x1, [x3, #5040]
    8bdc:	f949ec60 	ldr	x0, [x3, #5080]
    8be0:	cb0102e1 	sub	x1, x23, x1
    8be4:	eb00403f 	cmp	x1, x0, lsl #16
    8be8:	54000322 	b.cs	8c4c <fwp_main_thread+0x6ac>  // b.hs, b.nlast
    8bec:	d350fc22 	lsr	x2, x1, #16
    8bf0:	f949fc63 	ldr	x3, [x3, #5112]
    8bf4:	8b020842 	add	x2, x2, x2, lsl #2
    8bf8:	d37df042 	lsl	x2, x2, #3
    8bfc:	8b020060 	add	x0, x3, x2
    8c00:	f9401018 	ldr	x24, [x0, #32]
    8c04:	b4000258 	cbz	x24, 8c4c <fwp_main_thread+0x6ac>
    8c08:	38626862 	ldrb	w2, [x3, x2]
    8c0c:	7100085f 	cmp	w2, #0x2
    8c10:	54001e80 	b.eq	8fe0 <fwp_main_thread+0xa40>  // b.none
    8c14:	7100045f 	cmp	w2, #0x1
    8c18:	540001a1 	b.ne	8c4c <fwp_main_thread+0x6ac>  // b.any
    8c1c:	29430002 	ldp	w2, w0, [x0, #24]
    8c20:	92403c21 	and	x1, x1, #0xffff
    8c24:	9b027c21 	mul	x1, x1, x2
    8c28:	d360fc21 	lsr	x1, x1, #32
    8c2c:	eb00003f 	cmp	x1, x0
    8c30:	540000e2 	b.cs	8c4c <fwp_main_thread+0x6ac>  // b.hs, b.nlast
    8c34:	8b010318 	add	x24, x24, x1
    8c38:	39400300 	ldrb	w0, [x24]
    8c3c:	7103fc1f 	cmp	w0, #0xff
    8c40:	540060a0 	b.eq	9854 <fwp_main_thread+0x12b4>  // b.none
    8c44:	52800020 	mov	w0, #0x1                   	// #1
    8c48:	39000300 	strb	w0, [x24]
    8c4c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8c50:	910483e1 	add	x1, sp, #0x120
    8c54:	52800020 	mov	w0, #0x1                   	// #1
    8c58:	a9125fe2 	stp	x2, x23, [sp, #288]
    8c5c:	97fff0e6 	bl	4ff4 <fwp_data.part.0.constprop.0>
    8c60:	91170263 	add	x3, x19, #0x5c0
    8c64:	aa0003f7 	mov	x23, x0
    8c68:	f949d861 	ldr	x1, [x3, #5040]
    8c6c:	f949ec60 	ldr	x0, [x3, #5080]
    8c70:	cb0102e1 	sub	x1, x23, x1
    8c74:	eb00403f 	cmp	x1, x0, lsl #16
    8c78:	54000322 	b.cs	8cdc <fwp_main_thread+0x73c>  // b.hs, b.nlast
    8c7c:	d350fc22 	lsr	x2, x1, #16
    8c80:	f949fc63 	ldr	x3, [x3, #5112]
    8c84:	8b020842 	add	x2, x2, x2, lsl #2
    8c88:	d37df042 	lsl	x2, x2, #3
    8c8c:	8b020060 	add	x0, x3, x2
    8c90:	f9401018 	ldr	x24, [x0, #32]
    8c94:	b4000258 	cbz	x24, 8cdc <fwp_main_thread+0x73c>
    8c98:	38626862 	ldrb	w2, [x3, x2]
    8c9c:	7100085f 	cmp	w2, #0x2
    8ca0:	54001a60 	b.eq	8fec <fwp_main_thread+0xa4c>  // b.none
    8ca4:	7100045f 	cmp	w2, #0x1
    8ca8:	540001a1 	b.ne	8cdc <fwp_main_thread+0x73c>  // b.any
    8cac:	29430002 	ldp	w2, w0, [x0, #24]
    8cb0:	92403c21 	and	x1, x1, #0xffff
    8cb4:	9b027c21 	mul	x1, x1, x2
    8cb8:	d360fc21 	lsr	x1, x1, #32
    8cbc:	eb00003f 	cmp	x1, x0
    8cc0:	540000e2 	b.cs	8cdc <fwp_main_thread+0x73c>  // b.hs, b.nlast
    8cc4:	8b010318 	add	x24, x24, x1
    8cc8:	39400300 	ldrb	w0, [x24]
    8ccc:	7103fc1f 	cmp	w0, #0xff
    8cd0:	54005c80 	b.eq	9860 <fwp_main_thread+0x12c0>  // b.none
    8cd4:	52800020 	mov	w0, #0x1                   	// #1
    8cd8:	39000300 	strb	w0, [x24]
    8cdc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8ce0:	910443e1 	add	x1, sp, #0x110
    8ce4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8ce8:	52800020 	mov	w0, #0x1                   	// #1
    8cec:	a9115fe2 	stp	x2, x23, [sp, #272]
    8cf0:	97fff0c1 	bl	4ff4 <fwp_data.part.0.constprop.0>
    8cf4:	91170262 	add	x2, x19, #0x5c0
    8cf8:	aa0003f8 	mov	x24, x0
    8cfc:	f949d841 	ldr	x1, [x2, #5040]
    8d00:	f949ec40 	ldr	x0, [x2, #5080]
    8d04:	cb010301 	sub	x1, x24, x1
    8d08:	eb00403f 	cmp	x1, x0, lsl #16
    8d0c:	54000322 	b.cs	8d70 <fwp_main_thread+0x7d0>  // b.hs, b.nlast
    8d10:	d350fc20 	lsr	x0, x1, #16
    8d14:	f949fc43 	ldr	x3, [x2, #5112]
    8d18:	8b000800 	add	x0, x0, x0, lsl #2
    8d1c:	d37df002 	lsl	x2, x0, #3
    8d20:	8b020060 	add	x0, x3, x2
    8d24:	f9401017 	ldr	x23, [x0, #32]
    8d28:	b4000257 	cbz	x23, 8d70 <fwp_main_thread+0x7d0>
    8d2c:	38626862 	ldrb	w2, [x3, x2]
    8d30:	7100085f 	cmp	w2, #0x2
    8d34:	54001620 	b.eq	8ff8 <fwp_main_thread+0xa58>  // b.none
    8d38:	7100045f 	cmp	w2, #0x1
    8d3c:	540001a1 	b.ne	8d70 <fwp_main_thread+0x7d0>  // b.any
    8d40:	29430002 	ldp	w2, w0, [x0, #24]
    8d44:	92403c21 	and	x1, x1, #0xffff
    8d48:	9b027c21 	mul	x1, x1, x2
    8d4c:	d360fc21 	lsr	x1, x1, #32
    8d50:	eb00003f 	cmp	x1, x0
    8d54:	540000e2 	b.cs	8d70 <fwp_main_thread+0x7d0>  // b.hs, b.nlast
    8d58:	8b0102f7 	add	x23, x23, x1
    8d5c:	394002e0 	ldrb	w0, [x23]
    8d60:	7103fc1f 	cmp	w0, #0xff
    8d64:	54005720 	b.eq	9848 <fwp_main_thread+0x12a8>  // b.none
    8d68:	52800020 	mov	w0, #0x1                   	// #1
    8d6c:	390002e0 	strb	w0, [x23]
    8d70:	b40041fa 	cbz	x26, 95ac <fwp_main_thread+0x100c>
    8d74:	900000d7 	adrp	x23, 20000 <__data_start>
    8d78:	910042f7 	add	x23, x23, #0x10
    8d7c:	9100e2e0 	add	x0, x23, #0x38
    8d80:	d0fffffb 	adrp	x27, 6000 <fwp_drop1+0x40>
    8d84:	f90007e0 	str	x0, [sp, #8]
    8d88:	91130360 	add	x0, x27, #0x4c0
    8d8c:	91170279 	add	x25, x19, #0x5c0
    8d90:	9101c297 	add	x23, x20, #0x70
    8d94:	f90013e0 	str	x0, [sp, #32]
    8d98:	910183e0 	add	x0, sp, #0x60
    8d9c:	f9000be0 	str	x0, [sp, #16]
    8da0:	910203e0 	add	x0, sp, #0x80
    8da4:	f9000fe0 	str	x0, [sp, #24]
    8da8:	f90017fa 	str	x26, [sp, #40]
    8dac:	f949ef25 	ldr	x5, [x25, #5080]
    8db0:	f949db21 	ldr	x1, [x25, #5040]
    8db4:	d370bca5 	lsl	x5, x5, #16
    8db8:	cb010303 	sub	x3, x24, x1
    8dbc:	eb05007f 	cmp	x3, x5
    8dc0:	540003e2 	b.cs	8e3c <fwp_main_thread+0x89c>  // b.hs, b.nlast
    8dc4:	d350fc60 	lsr	x0, x3, #16
    8dc8:	f949ff27 	ldr	x7, [x25, #5112]
    8dcc:	8b000800 	add	x0, x0, x0, lsl #2
    8dd0:	d37df002 	lsl	x2, x0, #3
    8dd4:	8b0200e6 	add	x6, x7, x2
    8dd8:	f94010c0 	ldr	x0, [x6, #32]
    8ddc:	b4000300 	cbz	x0, 8e3c <fwp_main_thread+0x89c>
    8de0:	386268e2 	ldrb	w2, [x7, x2]
    8de4:	7100085f 	cmp	w2, #0x2
    8de8:	540010e0 	b.eq	9004 <fwp_main_thread+0xa64>  // b.none
    8dec:	7100045f 	cmp	w2, #0x1
    8df0:	54000261 	b.ne	8e3c <fwp_main_thread+0x89c>  // b.any
    8df4:	92403c62 	and	x2, x3, #0xffff
    8df8:	29430cc7 	ldp	w7, w3, [x6, #24]
    8dfc:	9b077c42 	mul	x2, x2, x7
    8e00:	d360fc42 	lsr	x2, x2, #32
    8e04:	eb03005f 	cmp	x2, x3
    8e08:	540001a2 	b.cs	8e3c <fwp_main_thread+0x89c>  // b.hs, b.nlast
    8e0c:	8b020000 	add	x0, x0, x2
    8e10:	39400002 	ldrb	w2, [x0]
    8e14:	34000142 	cbz	w2, 8e3c <fwp_main_thread+0x89c>
    8e18:	7103f45f 	cmp	w2, #0xfd
    8e1c:	54005788 	b.hi	990c <fwp_main_thread+0x136c>  // b.pmore
    8e20:	91170261 	add	x1, x19, #0x5c0
    8e24:	11000442 	add	w2, w2, #0x1
    8e28:	39000002 	strb	w2, [x0]
    8e2c:	aa0103e0 	mov	x0, x1
    8e30:	f949d821 	ldr	x1, [x1, #5040]
    8e34:	f949ec05 	ldr	x5, [x0, #5080]
    8e38:	d370bca5 	lsl	x5, x5, #16
    8e3c:	f94182e0 	ldr	x0, [x23, #768]
    8e40:	f90043e0 	str	x0, [sp, #128]
    8e44:	f94007e2 	ldr	x2, [sp, #8]
    8e48:	f94013e0 	ldr	x0, [sp, #32]
    8e4c:	f90047e0 	str	x0, [sp, #136]
    8e50:	f9400be0 	ldr	x0, [sp, #16]
    8e54:	f9004be0 	str	x0, [sp, #144]
    8e58:	f9400fe0 	ldr	x0, [sp, #24]
    8e5c:	cb010041 	sub	x1, x2, x1
    8e60:	12800002 	mov	w2, #0xffffffff            	// #-1
    8e64:	b90063e2 	str	w2, [sp, #96]
    8e68:	f90182e0 	str	x0, [x23, #768]
    8e6c:	eb05003f 	cmp	x1, x5
    8e70:	54000782 	b.cs	8f60 <fwp_main_thread+0x9c0>  // b.hs, b.nlast
    8e74:	91170262 	add	x2, x19, #0x5c0
    8e78:	d350fc20 	lsr	x0, x1, #16
    8e7c:	8b000800 	add	x0, x0, x0, lsl #2
    8e80:	f949fc45 	ldr	x5, [x2, #5112]
    8e84:	d37df003 	lsl	x3, x0, #3
    8e88:	8b0300a2 	add	x2, x5, x3
    8e8c:	f940105c 	ldr	x28, [x2, #32]
    8e90:	b400069c 	cbz	x28, 8f60 <fwp_main_thread+0x9c0>
    8e94:	386368a0 	ldrb	w0, [x5, x3]
    8e98:	7100081f 	cmp	w0, #0x2
    8e9c:	54000c00 	b.eq	901c <fwp_main_thread+0xa7c>  // b.none
    8ea0:	7100041f 	cmp	w0, #0x1
    8ea4:	540005e1 	b.ne	8f60 <fwp_main_thread+0x9c0>  // b.any
    8ea8:	29430c45 	ldp	w5, w3, [x2, #24]
    8eac:	92403c20 	and	x0, x1, #0xffff
    8eb0:	9b057c00 	mul	x0, x0, x5
    8eb4:	d360fc00 	lsr	x0, x0, #32
    8eb8:	eb03001f 	cmp	x0, x3
    8ebc:	540002a2 	b.cs	8f10 <fwp_main_thread+0x970>  // b.hs, b.nlast
    8ec0:	8b000380 	add	x0, x28, x0
    8ec4:	39400003 	ldrb	w3, [x0]
    8ec8:	34000243 	cbz	w3, 8f10 <fwp_main_thread+0x970>
    8ecc:	7103f47f 	cmp	w3, #0xfd
    8ed0:	540052a8 	b.hi	9924 <fwp_main_thread+0x1384>  // b.pmore
    8ed4:	11000463 	add	w3, w3, #0x1
    8ed8:	39000003 	strb	w3, [x0]
    8edc:	91170260 	add	x0, x19, #0x5c0
    8ee0:	f94007e3 	ldr	x3, [sp, #8]
    8ee4:	f949d801 	ldr	x1, [x0, #5040]
    8ee8:	f949ec02 	ldr	x2, [x0, #5080]
    8eec:	cb010061 	sub	x1, x3, x1
    8ef0:	eb02403f 	cmp	x1, x2, lsl #16
    8ef4:	54000362 	b.cs	8f60 <fwp_main_thread+0x9c0>  // b.hs, b.nlast
    8ef8:	f949fc02 	ldr	x2, [x0, #5112]
    8efc:	d350fc20 	lsr	x0, x1, #16
    8f00:	8b000800 	add	x0, x0, x0, lsl #2
    8f04:	8b000c42 	add	x2, x2, x0, lsl #3
    8f08:	f940105c 	ldr	x28, [x2, #32]
    8f0c:	b40002bc 	cbz	x28, 8f60 <fwp_main_thread+0x9c0>
    8f10:	39400040 	ldrb	w0, [x2]
    8f14:	7100081f 	cmp	w0, #0x2
    8f18:	540007c0 	b.eq	9010 <fwp_main_thread+0xa70>  // b.none
    8f1c:	7100041f 	cmp	w0, #0x1
    8f20:	54000201 	b.ne	8f60 <fwp_main_thread+0x9c0>  // b.any
    8f24:	29430043 	ldp	w3, w0, [x2, #24]
    8f28:	92403c21 	and	x1, x1, #0xffff
    8f2c:	9b037c21 	mul	x1, x1, x3
    8f30:	d360fc21 	lsr	x1, x1, #32
    8f34:	eb00003f 	cmp	x1, x0
    8f38:	54000142 	b.cs	8f60 <fwp_main_thread+0x9c0>  // b.hs, b.nlast
    8f3c:	8b01039c 	add	x28, x28, x1
    8f40:	39400381 	ldrb	w1, [x28]
    8f44:	340000e1 	cbz	w1, 8f60 <fwp_main_thread+0x9c0>
    8f48:	7100043f 	cmp	w1, #0x1
    8f4c:	54000280 	b.eq	8f9c <fwp_main_thread+0x9fc>  // b.none
    8f50:	7103fc3f 	cmp	w1, #0xff
    8f54:	54004ec0 	b.eq	992c <fwp_main_thread+0x138c>  // b.none
    8f58:	51000421 	sub	w1, w1, #0x1
    8f5c:	39000381 	strb	w1, [x28]
    8f60:	b4003538 	cbz	x24, 9604 <fwp_main_thread+0x1064>
    8f64:	aa1803e0 	mov	x0, x24
    8f68:	d280001c 	mov	x28, #0x0                   	// #0
    8f6c:	d503201f 	nop
    8f70:	f9400800 	ldr	x0, [x0, #16]
    8f74:	9100079c 	add	x28, x28, #0x1
    8f78:	b5ffffc0 	cbnz	x0, 8f70 <fwp_main_thread+0x9d0>
    8f7c:	52800000 	mov	w0, #0x0                   	// #0
    8f80:	97ffe99c 	bl	35f0 <descent_phase_step>
    8f84:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8f88:	eb00039f 	cmp	x28, x0
    8f8c:	54000509 	b.ls	902c <fwp_main_thread+0xa8c>  // b.plast
    8f90:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    8f94:	91132000 	add	x0, x0, #0x4c8
    8f98:	97ffec5a 	bl	4100 <fwp_trap>
    8f9c:	d53bd040 	mrs	x0, tpidr_el0
    8fa0:	91400000 	add	x0, x0, #0x0, lsl #12
    8fa4:	91004000 	add	x0, x0, #0x10
    8fa8:	f9400000 	ldr	x0, [x0]
    8fac:	b4000140 	cbz	x0, 8fd4 <fwp_main_thread+0xa34>
    8fb0:	f94007e1 	ldr	x1, [sp, #8]
    8fb4:	97ffedcf 	bl	46f0 <fwp_closure_drop_push>
    8fb8:	17ffffea 	b	8f60 <fwp_main_thread+0x9c0>
    8fbc:	aa1c03e0 	mov	x0, x28
    8fc0:	97ffec70 	bl	4180 <fwp_rc_forget_slot.part.0>
    8fc4:	17fffe26 	b	885c <fwp_main_thread+0x2bc>
    8fc8:	aa0003e1 	mov	x1, x0
    8fcc:	f90022b3 	str	x19, [x21, #64]
    8fd0:	17fffdd7 	b	872c <fwp_main_thread+0x18c>
    8fd4:	f94007e0 	ldr	x0, [sp, #8]
    8fd8:	97ffee0b 	bl	4804 <fwp_closure_drop.part.0>
    8fdc:	17ffffe1 	b	8f60 <fwp_main_thread+0x9c0>
    8fe0:	72003c3f 	tst	w1, #0xffff
    8fe4:	54ffe341 	b.ne	8c4c <fwp_main_thread+0x6ac>  // b.any
    8fe8:	17ffff14 	b	8c38 <fwp_main_thread+0x698>
    8fec:	72003c3f 	tst	w1, #0xffff
    8ff0:	54ffe761 	b.ne	8cdc <fwp_main_thread+0x73c>  // b.any
    8ff4:	17ffff35 	b	8cc8 <fwp_main_thread+0x728>
    8ff8:	72003c3f 	tst	w1, #0xffff
    8ffc:	54ffeba1 	b.ne	8d70 <fwp_main_thread+0x7d0>  // b.any
    9000:	17ffff57 	b	8d5c <fwp_main_thread+0x7bc>
    9004:	72003c7f 	tst	w3, #0xffff
    9008:	54fff1a1 	b.ne	8e3c <fwp_main_thread+0x89c>  // b.any
    900c:	17ffff81 	b	8e10 <fwp_main_thread+0x870>
    9010:	72003c3f 	tst	w1, #0xffff
    9014:	54fffa61 	b.ne	8f60 <fwp_main_thread+0x9c0>  // b.any
    9018:	17ffffca 	b	8f40 <fwp_main_thread+0x9a0>
    901c:	72003c3f 	tst	w1, #0xffff
    9020:	54fff781 	b.ne	8f10 <fwp_main_thread+0x970>  // b.any
    9024:	aa1c03e0 	mov	x0, x28
    9028:	17ffffa7 	b	8ec4 <fwp_main_thread+0x924>
    902c:	aa1c03e2 	mov	x2, x28
    9030:	9101c29c 	add	x28, x20, #0x70
    9034:	b9433f80 	ldr	w0, [x28, #828]
    9038:	34002d40 	cbz	w0, 95e0 <fwp_main_thread+0x1040>
    903c:	9101c280 	add	x0, x20, #0x70
    9040:	f940601c 	ldr	x28, [x0, #192]
    9044:	f9406c01 	ldr	x1, [x0, #216]
    9048:	eb1c003f 	cmp	x1, x28
    904c:	5400138a 	b.ge	92bc <fwp_main_thread+0xd1c>  // b.tcont
    9050:	8b010420 	add	x0, x1, x1, lsl #1
    9054:	528fffc5 	mov	w5, #0x7ffe                	// #32766
    9058:	f9403a83 	ldr	x3, [x20, #112]
    905c:	d37ef400 	lsl	x0, x0, #2
    9060:	cb010000 	sub	x0, x0, x1
    9064:	8b000c60 	add	x0, x3, x0, lsl #3
    9068:	b9400403 	ldr	w3, [x0, #4]
    906c:	35000083 	cbnz	w3, 907c <fwp_main_thread+0xadc>
    9070:	b9400003 	ldr	w3, [x0]
    9074:	6b05007f 	cmp	w3, w5
    9078:	54001229 	b.ls	92bc <fwp_main_thread+0xd1c>  // b.plast
    907c:	91000421 	add	x1, x1, #0x1
    9080:	91016000 	add	x0, x0, #0x58
    9084:	eb1c003f 	cmp	x1, x28
    9088:	54ffff01 	b.ne	9068 <fwp_main_thread+0xac8>  // b.any
    908c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    9090:	eb00039f 	cmp	x28, x0
    9094:	5400430c 	b.gt	98f4 <fwp_main_thread+0x1354>
    9098:	9101c280 	add	x0, x20, #0x70
    909c:	f9403a86 	ldr	x6, [x20, #112]
    90a0:	f9406800 	ldr	x0, [x0, #208]
    90a4:	eb1c001f 	cmp	x0, x28
    90a8:	54000281 	b.ne	90f8 <fwp_main_thread+0xb58>  // b.any
    90ac:	d2800023 	mov	x3, #0x1                   	// #1
    90b0:	b40000bc 	cbz	x28, 90c4 <fwp_main_thread+0xb24>
    90b4:	d37ffb83 	lsl	x3, x28, #1
    90b8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    90bc:	eb00007f 	cmp	x3, x0
    90c0:	9a80d063 	csel	x3, x3, x0, le
    90c4:	8b030461 	add	x1, x3, x3, lsl #1
    90c8:	aa0603e0 	mov	x0, x6
    90cc:	a9030be3 	stp	x3, x2, [sp, #48]
    90d0:	d37ef421 	lsl	x1, x1, #2
    90d4:	cb030021 	sub	x1, x1, x3
    90d8:	d37df021 	lsl	x1, x1, #3
    90dc:	97ffe5e9 	bl	2880 <realloc@plt>
    90e0:	a9430be3 	ldp	x3, x2, [sp, #48]
    90e4:	aa0003e6 	mov	x6, x0
    90e8:	b4006260 	cbz	x0, 9d34 <fwp_main_thread+0x1794>
    90ec:	9101c280 	add	x0, x20, #0x70
    90f0:	f9003a86 	str	x6, [x20, #112]
    90f4:	f9006803 	str	x3, [x0, #208]
    90f8:	8b1c0780 	add	x0, x28, x28, lsl #1
    90fc:	9101c283 	add	x3, x20, #0x70
    9100:	4f000400 	movi	v0.4s, #0x0
    9104:	aa1c03e1 	mov	x1, x28
    9108:	d37ef400 	lsl	x0, x0, #2
    910c:	cb1c0000 	sub	x0, x0, x28
    9110:	9100079c 	add	x28, x28, #0x1
    9114:	f900607c 	str	x28, [x3, #192]
    9118:	8b000cc0 	add	x0, x6, x0, lsl #3
    911c:	f900281f 	str	xzr, [x0, #80]
    9120:	ad000000 	stp	q0, q0, [x0]
    9124:	ad010000 	stp	q0, q0, [x0, #32]
    9128:	3d801000 	str	q0, [x0, #64]
    912c:	8b010423 	add	x3, x1, x1, lsl #1
    9130:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    9134:	91034000 	add	x0, x0, #0xd0
    9138:	d37ef463 	lsl	x3, x3, #2
    913c:	a9040be1 	stp	x1, x2, [sp, #64]
    9140:	cb010063 	sub	x3, x3, x1
    9144:	8b030cc3 	add	x3, x6, x3, lsl #3
    9148:	a9031be3 	stp	x3, x6, [sp, #48]
    914c:	f900287f 	str	xzr, [x3, #80]
    9150:	97ffe634 	bl	2a20 <getenv@plt>
    9154:	a9431be3 	ldp	x3, x6, [sp, #48]
    9158:	a9440be1 	ldp	x1, x2, [sp, #64]
    915c:	b4000900 	cbz	x0, 927c <fwp_main_thread+0xcdc>
    9160:	39400005 	ldrb	w5, [x0]
    9164:	7100c0bf 	cmp	w5, #0x30
    9168:	540008a1 	b.ne	927c <fwp_main_thread+0xcdc>  // b.any
    916c:	39400400 	ldrb	w0, [x0, #1]
    9170:	35000860 	cbnz	w0, 927c <fwp_main_thread+0xcdc>
    9174:	9101c285 	add	x5, x20, #0x70
    9178:	2f000400 	mvni	v0.2s, #0x0
    917c:	b9400067 	ldr	w7, [x3]
    9180:	9100043c 	add	x28, x1, #0x1
    9184:	a9008862 	stp	x2, x2, [x3, #8]
    9188:	52800022 	mov	w2, #0x1                   	// #1
    918c:	110004e4 	add	w4, w7, #0x1
    9190:	f94180a0 	ldr	x0, [x5, #768]
    9194:	b9000064 	str	w4, [x3]
    9198:	b9000462 	str	w2, [x3, #4]
    919c:	f900207f 	str	xzr, [x3, #64]
    91a0:	b90043e4 	str	w4, [sp, #64]
    91a4:	f9006cbc 	str	x28, [x5, #216]
    91a8:	fd002460 	str	d0, [x3, #72]
    91ac:	b4003aa0 	cbz	x0, 9900 <fwp_main_thread+0x1360>
    91b0:	91130365 	add	x5, x27, #0x4c0
    91b4:	14000003 	b	91c0 <fwp_main_thread+0xc20>
    91b8:	f9400000 	ldr	x0, [x0]
    91bc:	b4003a20 	cbz	x0, 9900 <fwp_main_thread+0x1360>
    91c0:	f9400402 	ldr	x2, [x0, #8]
    91c4:	eb05005f 	cmp	x2, x5
    91c8:	54ffff81 	b.ne	91b8 <fwp_main_thread+0xc18>  // b.any
    91cc:	f9400800 	ldr	x0, [x0, #16]
    91d0:	2a0103e5 	mov	w5, w1
    91d4:	b9400002 	ldr	w2, [x0]
    91d8:	f9002060 	str	x0, [x3, #64]
    91dc:	b9004c62 	str	w2, [x3, #76]
    91e0:	37f80082 	tbnz	w2, #31, 91f0 <fwp_main_thread+0xc50>
    91e4:	52800b03 	mov	w3, #0x58                  	// #88
    91e8:	9b231842 	smaddl	x2, w2, w3, x6
    91ec:	b9004841 	str	w1, [x2, #72]
    91f0:	b9000005 	str	w5, [x0]
    91f4:	52800020 	mov	w0, #0x1                   	// #1
    91f8:	97ffe8fe 	bl	35f0 <descent_phase_step>
    91fc:	aa1803e0 	mov	x0, x24
    9200:	d2800002 	mov	x2, #0x0                   	// #0
    9204:	b4002098 	cbz	x24, 9614 <fwp_main_thread+0x1074>
    9208:	f9400800 	ldr	x0, [x0, #16]
    920c:	91000442 	add	x2, x2, #0x1
    9210:	b5ffffc0 	cbnz	x0, 9208 <fwp_main_thread+0xc68>
    9214:	aa1803e1 	mov	x1, x24
    9218:	f9400821 	ldr	x1, [x1, #16]
    921c:	91000400 	add	x0, x0, #0x1
    9220:	b5ffffc1 	cbnz	x1, 9218 <fwp_main_thread+0xc78>
    9224:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9228:	eb01001f 	cmp	x0, x1
    922c:	54000108 	b.hi	924c <fwp_main_thread+0xcac>  // b.pmore
    9230:	f100005f 	cmp	x2, #0x0
    9234:	54001f0d 	b.le	9614 <fwp_main_thread+0x1074>
    9238:	eb00005f 	cmp	x2, x0
    923c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    9240:	9a809042 	csel	x2, x2, x0, ls	// ls = plast
    9244:	eb01005f 	cmp	x2, x1
    9248:	54004589 	b.ls	9af8 <fwp_main_thread+0x1558>  // b.plast
    924c:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    9250:	910e8000 	add	x0, x0, #0x3a0
    9254:	97ffebab 	bl	4100 <fwp_trap>
    9258:	f9418a60 	ldr	x0, [x19, #784]
    925c:	97ffec65 	bl	43f0 <fwp_mem_free>
    9260:	f9018a7f 	str	xzr, [x19, #784]
    9264:	f9400a60 	ldr	x0, [x19, #16]
    9268:	f901927f 	str	xzr, [x19, #800]
    926c:	b4ffb9a0 	cbz	x0, 89a0 <fwp_main_thread+0x400>
    9270:	f900541f 	str	xzr, [x0, #168]
    9274:	f9005c1f 	str	xzr, [x0, #184]
    9278:	17fffdca 	b	89a0 <fwp_main_thread+0x400>
    927c:	9101c280 	add	x0, x20, #0x70
    9280:	f9405805 	ldr	x5, [x0, #176]
    9284:	b4fff785 	cbz	x5, 9174 <fwp_main_thread+0xbd4>
    9288:	3cc88000 	ldur	q0, [x0, #136]
    928c:	f900581f 	str	xzr, [x0, #176]
    9290:	3d800860 	str	q0, [x3, #32]
    9294:	f9405407 	ldr	x7, [x0, #168]
    9298:	f9001c67 	str	x7, [x3, #56]
    929c:	f9404c07 	ldr	x7, [x0, #152]
    92a0:	f9001867 	str	x7, [x3, #48]
    92a4:	f9405007 	ldr	x7, [x0, #160]
    92a8:	f9000c67 	str	x7, [x3, #24]
    92ac:	a908fc1f 	stp	xzr, xzr, [x0, #136]
    92b0:	a909fc1f 	stp	xzr, xzr, [x0, #152]
    92b4:	f900541f 	str	xzr, [x0, #168]
    92b8:	17ffffaf 	b	9174 <fwp_main_thread+0xbd4>
    92bc:	eb01039f 	cmp	x28, x1
    92c0:	54ffee60 	b.eq	908c <fwp_main_thread+0xaec>  // b.none
    92c4:	f9403a86 	ldr	x6, [x20, #112]
    92c8:	17ffff99 	b	912c <fwp_main_thread+0xb8c>
    92cc:	aa0303e0 	mov	x0, x3
    92d0:	f9001fe2 	str	x2, [sp, #56]
    92d4:	97ffec47 	bl	43f0 <fwp_mem_free>
    92d8:	f9401fe2 	ldr	x2, [sp, #56]
    92dc:	91170267 	add	x7, x19, #0x5c0
    92e0:	d2800508 	mov	x8, #0x28                  	// #40
    92e4:	f949d8e1 	ldr	x1, [x7, #5040]
    92e8:	f949ece0 	ldr	x0, [x7, #5080]
    92ec:	cb010041 	sub	x1, x2, x1
    92f0:	eb00403f 	cmp	x1, x0, lsl #16
    92f4:	54000362 	b.cs	9360 <fwp_main_thread+0xdc0>  // b.hs, b.nlast
    92f8:	d350fc25 	lsr	x5, x1, #16
    92fc:	f949fce6 	ldr	x6, [x7, #5112]
    9300:	9b087ca5 	mul	x5, x5, x8
    9304:	8b0500c3 	add	x3, x6, x5
    9308:	f9401060 	ldr	x0, [x3, #32]
    930c:	b40002a0 	cbz	x0, 9360 <fwp_main_thread+0xdc0>
    9310:	386568c6 	ldrb	w6, [x6, x5]
    9314:	710008df 	cmp	w6, #0x2
    9318:	54008c60 	b.eq	a4a4 <fwp_main_thread+0x1f04>  // b.none
    931c:	710004df 	cmp	w6, #0x1
    9320:	54000201 	b.ne	9360 <fwp_main_thread+0xdc0>  // b.any
    9324:	29432465 	ldp	w5, w9, [x3, #24]
    9328:	92403c21 	and	x1, x1, #0xffff
    932c:	9b057c25 	mul	x5, x1, x5
    9330:	d360fca5 	lsr	x5, x5, #32
    9334:	eb0900bf 	cmp	x5, x9
    9338:	54000142 	b.cs	9360 <fwp_main_thread+0xdc0>  // b.hs, b.nlast
    933c:	8b050000 	add	x0, x0, x5
    9340:	39400005 	ldrb	w5, [x0]
    9344:	340000e5 	cbz	w5, 9360 <fwp_main_thread+0xdc0>
    9348:	710004bf 	cmp	w5, #0x1
    934c:	54008940 	b.eq	a474 <fwp_main_thread+0x1ed4>  // b.none
    9350:	7103fcbf 	cmp	w5, #0xff
    9354:	54008e00 	b.eq	a514 <fwp_main_thread+0x1f74>  // b.none
    9358:	510004a5 	sub	w5, w5, #0x1
    935c:	39000005 	strb	w5, [x0]
    9360:	91170266 	add	x6, x19, #0x5c0
    9364:	d2800507 	mov	x7, #0x28                  	// #40
    9368:	f9401be2 	ldr	x2, [sp, #48]
    936c:	f949d8c1 	ldr	x1, [x6, #5040]
    9370:	f949ecc0 	ldr	x0, [x6, #5080]
    9374:	cb010041 	sub	x1, x2, x1
    9378:	eb00403f 	cmp	x1, x0, lsl #16
    937c:	54000362 	b.cs	93e8 <fwp_main_thread+0xe48>  // b.hs, b.nlast
    9380:	d350fc22 	lsr	x2, x1, #16
    9384:	f949fcc5 	ldr	x5, [x6, #5112]
    9388:	9b077c42 	mul	x2, x2, x7
    938c:	8b0200a3 	add	x3, x5, x2
    9390:	f9401060 	ldr	x0, [x3, #32]
    9394:	b40002a0 	cbz	x0, 93e8 <fwp_main_thread+0xe48>
    9398:	386268a5 	ldrb	w5, [x5, x2]
    939c:	710008bf 	cmp	w5, #0x2
    93a0:	540094a0 	b.eq	a634 <fwp_main_thread+0x2094>  // b.none
    93a4:	710004bf 	cmp	w5, #0x1
    93a8:	54000201 	b.ne	93e8 <fwp_main_thread+0xe48>  // b.any
    93ac:	29432062 	ldp	w2, w8, [x3, #24]
    93b0:	92403c21 	and	x1, x1, #0xffff
    93b4:	9b027c22 	mul	x2, x1, x2
    93b8:	d360fc42 	lsr	x2, x2, #32
    93bc:	eb08005f 	cmp	x2, x8
    93c0:	54000142 	b.cs	93e8 <fwp_main_thread+0xe48>  // b.hs, b.nlast
    93c4:	8b020000 	add	x0, x0, x2
    93c8:	39400002 	ldrb	w2, [x0]
    93cc:	340000e2 	cbz	w2, 93e8 <fwp_main_thread+0xe48>
    93d0:	7100045f 	cmp	w2, #0x1
    93d4:	54009120 	b.eq	a5f8 <fwp_main_thread+0x2058>  // b.none
    93d8:	7103fc5f 	cmp	w2, #0xff
    93dc:	54008ba0 	b.eq	a550 <fwp_main_thread+0x1fb0>  // b.none
    93e0:	51000442 	sub	w2, w2, #0x1
    93e4:	39000002 	strb	w2, [x0]
    93e8:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10f68>
    93ec:	910ae042 	add	x2, x2, #0x2b8
    93f0:	91014042 	add	x2, x2, #0x50
    93f4:	aa1503e0 	mov	x0, x21
    93f8:	52800023 	mov	w3, #0x1                   	// #1
    93fc:	aa1c03e1 	mov	x1, x28
    9400:	a90d7fff 	stp	xzr, xzr, [sp, #208]
    9404:	f90073ff 	str	xzr, [sp, #224]
    9408:	97fff86b 	bl	75b4 <fwp_write>
    940c:	a94d0be3 	ldp	x3, x2, [sp, #208]
    9410:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    9414:	91294000 	add	x0, x0, #0xa50
    9418:	f100007f 	cmp	x3, #0x0
    941c:	9a830003 	csel	x3, x0, x3, eq	// eq = none
    9420:	b100285f 	cmn	x2, #0xa
    9424:	54007d28 	b.hi	a3c8 <fwp_main_thread+0x1e28>  // b.pmore
    9428:	91002440 	add	x0, x2, #0x9
    942c:	52800021 	mov	w1, #0x1                   	// #1
    9430:	a9030be3 	stp	x3, x2, [sp, #48]
    9434:	97ffeeab 	bl	4ee0 <fwp_heap_alloc>
    9438:	a9430be3 	ldp	x3, x2, [sp, #48]
    943c:	f9001be0 	str	x0, [sp, #48]
    9440:	f8008402 	str	x2, [x0], #8
    9444:	f90023e2 	str	x2, [sp, #64]
    9448:	f9001fe0 	str	x0, [sp, #56]
    944c:	aa0303e1 	mov	x1, x3
    9450:	97ffe4a8 	bl	26f0 <memcpy@plt>
    9454:	f9401be0 	ldr	x0, [sp, #48]
    9458:	f94023e2 	ldr	x2, [sp, #64]
    945c:	8b020002 	add	x2, x0, x2
    9460:	3900205f 	strb	wzr, [x2, #8]
    9464:	f9406be0 	ldr	x0, [sp, #208]
    9468:	97ffe53a 	bl	2950 <free@plt>
    946c:	91170260 	add	x0, x19, #0x5c0
    9470:	f9401be3 	ldr	x3, [sp, #48]
    9474:	f949d801 	ldr	x1, [x0, #5040]
    9478:	f949ec02 	ldr	x2, [x0, #5080]
    947c:	cb010061 	sub	x1, x3, x1
    9480:	eb02403f 	cmp	x1, x2, lsl #16
    9484:	54000322 	b.cs	94e8 <fwp_main_thread+0xf48>  // b.hs, b.nlast
    9488:	d350fc22 	lsr	x2, x1, #16
    948c:	d2800503 	mov	x3, #0x28                  	// #40
    9490:	f949fc05 	ldr	x5, [x0, #5112]
    9494:	9b037c42 	mul	x2, x2, x3
    9498:	8b0200a3 	add	x3, x5, x2
    949c:	f9401060 	ldr	x0, [x3, #32]
    94a0:	b4000240 	cbz	x0, 94e8 <fwp_main_thread+0xf48>
    94a4:	386268a2 	ldrb	w2, [x5, x2]
    94a8:	7100085f 	cmp	w2, #0x2
    94ac:	54007a00 	b.eq	a3ec <fwp_main_thread+0x1e4c>  // b.none
    94b0:	7100045f 	cmp	w2, #0x1
    94b4:	540001a1 	b.ne	94e8 <fwp_main_thread+0xf48>  // b.any
    94b8:	29430865 	ldp	w5, w2, [x3, #24]
    94bc:	92403c21 	and	x1, x1, #0xffff
    94c0:	9b057c21 	mul	x1, x1, x5
    94c4:	d360fc21 	lsr	x1, x1, #32
    94c8:	eb02003f 	cmp	x1, x2
    94cc:	540000e2 	b.cs	94e8 <fwp_main_thread+0xf48>  // b.hs, b.nlast
    94d0:	8b010000 	add	x0, x0, x1
    94d4:	39400001 	ldrb	w1, [x0]
    94d8:	7103fc3f 	cmp	w1, #0xff
    94dc:	54007ac0 	b.eq	a434 <fwp_main_thread+0x1e94>  // b.none
    94e0:	52800021 	mov	w1, #0x1                   	// #1
    94e4:	39000001 	strb	w1, [x0]
    94e8:	aa1c03e0 	mov	x0, x28
    94ec:	97fff259 	bl	5e50 <fwp_drop0>
    94f0:	a94303e1 	ldp	x1, x0, [sp, #48]
    94f4:	9101c29c 	add	x28, x20, #0x70
    94f8:	f9400783 	ldr	x3, [x28, #8]
    94fc:	f9400022 	ldr	x2, [x1]
    9500:	d2800021 	mov	x1, #0x1                   	// #1
    9504:	97ffe523 	bl	2990 <fwrite@plt>
    9508:	f9400781 	ldr	x1, [x28, #8]
    950c:	52800140 	mov	w0, #0xa                   	// #10
    9510:	97ffe4a8 	bl	27b0 <fputc@plt>
    9514:	91170262 	add	x2, x19, #0x5c0
    9518:	f9401be3 	ldr	x3, [sp, #48]
    951c:	f949d841 	ldr	x1, [x2, #5040]
    9520:	f949ec40 	ldr	x0, [x2, #5080]
    9524:	cb010061 	sub	x1, x3, x1
    9528:	eb00403f 	cmp	x1, x0, lsl #16
    952c:	54000382 	b.cs	959c <fwp_main_thread+0xffc>  // b.hs, b.nlast
    9530:	d350fc20 	lsr	x0, x1, #16
    9534:	d2800505 	mov	x5, #0x28                  	// #40
    9538:	f949fc43 	ldr	x3, [x2, #5112]
    953c:	9b057c00 	mul	x0, x0, x5
    9540:	8b000062 	add	x2, x3, x0
    9544:	f940105c 	ldr	x28, [x2, #32]
    9548:	b40002bc 	cbz	x28, 959c <fwp_main_thread+0xffc>
    954c:	38606860 	ldrb	w0, [x3, x0]
    9550:	7100081f 	cmp	w0, #0x2
    9554:	54007460 	b.eq	a3e0 <fwp_main_thread+0x1e40>  // b.none
    9558:	7100041f 	cmp	w0, #0x1
    955c:	54000201 	b.ne	959c <fwp_main_thread+0xffc>  // b.any
    9560:	29430043 	ldp	w3, w0, [x2, #24]
    9564:	92403c21 	and	x1, x1, #0xffff
    9568:	9b037c21 	mul	x1, x1, x3
    956c:	d360fc21 	lsr	x1, x1, #32
    9570:	eb00003f 	cmp	x1, x0
    9574:	54000142 	b.cs	959c <fwp_main_thread+0xffc>  // b.hs, b.nlast
    9578:	8b01039c 	add	x28, x28, x1
    957c:	39400381 	ldrb	w1, [x28]
    9580:	340000e1 	cbz	w1, 959c <fwp_main_thread+0xffc>
    9584:	7100043f 	cmp	w1, #0x1
    9588:	54007260 	b.eq	a3d4 <fwp_main_thread+0x1e34>  // b.none
    958c:	7103fc3f 	cmp	w1, #0xff
    9590:	54007340 	b.eq	a3f8 <fwp_main_thread+0x1e58>  // b.none
    9594:	51000421 	sub	w1, w1, #0x1
    9598:	39000381 	strb	w1, [x28]
    959c:	f94017e0 	ldr	x0, [sp, #40]
    95a0:	f9400800 	ldr	x0, [x0, #16]
    95a4:	f90017e0 	str	x0, [sp, #40]
    95a8:	b5ffc020 	cbnz	x0, 8dac <fwp_main_thread+0x80c>
    95ac:	aa1803e0 	mov	x0, x24
    95b0:	97fff228 	bl	5e50 <fwp_drop0>
    95b4:	aa1a03e0 	mov	x0, x26
    95b8:	97fff226 	bl	5e50 <fwp_drop0>
    95bc:	9101c280 	add	x0, x20, #0x70
    95c0:	52800021 	mov	w1, #0x1                   	// #1
    95c4:	f9410bf9 	ldr	x25, [sp, #528]
    95c8:	f9410ffa 	ldr	x26, [sp, #536]
    95cc:	f94113fb 	ldr	x27, [sp, #544]
    95d0:	f94117fc 	ldr	x28, [sp, #552]
    95d4:	b9033801 	str	w1, [x0, #824]
    95d8:	f901a01f 	str	xzr, [x0, #832]
    95dc:	17fffc39 	b	86c0 <fwp_main_thread+0x120>
    95e0:	b0ffffe0 	adrp	x0, 6000 <fwp_drop1+0x40>
    95e4:	910f4000 	add	x0, x0, #0x3d0
    95e8:	f9001be2 	str	x2, [sp, #48]
    95ec:	94000639 	bl	aed0 <atexit>
    95f0:	f9401be2 	ldr	x2, [sp, #48]
    95f4:	35003a00 	cbnz	w0, 9d34 <fwp_main_thread+0x1794>
    95f8:	52800020 	mov	w0, #0x1                   	// #1
    95fc:	b9033f80 	str	w0, [x28, #828]
    9600:	17fffe8f 	b	903c <fwp_main_thread+0xa9c>
    9604:	52800000 	mov	w0, #0x0                   	// #0
    9608:	97ffe7fa 	bl	35f0 <descent_phase_step>
    960c:	d2800002 	mov	x2, #0x0                   	// #0
    9610:	17fffe88 	b	9030 <fwp_main_thread+0xa90>
    9614:	52800041 	mov	w1, #0x2                   	// #2
    9618:	d2800100 	mov	x0, #0x8                   	// #8
    961c:	97ffee31 	bl	4ee0 <fwp_heap_alloc>
    9620:	aa0003e2 	mov	x2, x0
    9624:	91170260 	add	x0, x19, #0x5c0
    9628:	a9030be2 	stp	x2, x2, [sp, #48]
    962c:	f900005f 	str	xzr, [x2]
    9630:	f949d801 	ldr	x1, [x0, #5040]
    9634:	f949ec00 	ldr	x0, [x0, #5080]
    9638:	cb010041 	sub	x1, x2, x1
    963c:	eb00403f 	cmp	x1, x0, lsl #16
    9640:	54002882 	b.cs	9b50 <fwp_main_thread+0x15b0>  // b.hs, b.nlast
    9644:	d2800002 	mov	x2, #0x0                   	// #0
    9648:	91170263 	add	x3, x19, #0x5c0
    964c:	d350fc20 	lsr	x0, x1, #16
    9650:	8b000800 	add	x0, x0, x0, lsl #2
    9654:	f949fc66 	ldr	x6, [x3, #5112]
    9658:	d37df003 	lsl	x3, x0, #3
    965c:	8b0300c5 	add	x5, x6, x3
    9660:	f94010a0 	ldr	x0, [x5, #32]
    9664:	b4000240 	cbz	x0, 96ac <fwp_main_thread+0x110c>
    9668:	386368c3 	ldrb	w3, [x6, x3]
    966c:	7100087f 	cmp	w3, #0x2
    9670:	54001f40 	b.eq	9a58 <fwp_main_thread+0x14b8>  // b.none
    9674:	7100047f 	cmp	w3, #0x1
    9678:	540001a1 	b.ne	96ac <fwp_main_thread+0x110c>  // b.any
    967c:	29430ca6 	ldp	w6, w3, [x5, #24]
    9680:	92403c21 	and	x1, x1, #0xffff
    9684:	9b067c21 	mul	x1, x1, x6
    9688:	d360fc21 	lsr	x1, x1, #32
    968c:	eb03003f 	cmp	x1, x3
    9690:	540000e2 	b.cs	96ac <fwp_main_thread+0x110c>  // b.hs, b.nlast
    9694:	8b010000 	add	x0, x0, x1
    9698:	39400001 	ldrb	w1, [x0]
    969c:	7103fc3f 	cmp	w1, #0xff
    96a0:	54003160 	b.eq	9ccc <fwp_main_thread+0x172c>  // b.none
    96a4:	52800021 	mov	w1, #0x1                   	// #1
    96a8:	39000001 	strb	w1, [x0]
    96ac:	f94023e0 	ldr	x0, [sp, #64]
    96b0:	d3707c00 	ubfiz	x0, x0, #16, #32
    96b4:	aa1c0000 	orr	x0, x0, x28
    96b8:	f9002be0 	str	x0, [sp, #80]
    96bc:	b4000242 	cbz	x2, 9704 <fwp_main_thread+0x1164>
    96c0:	d3607c06 	lsl	x6, x0, #32
    96c4:	aa1803e1 	mov	x1, x24
    96c8:	f9401be0 	ldr	x0, [sp, #48]
    96cc:	aa0603e5 	mov	x5, x6
    96d0:	f9400707 	ldr	x7, [x24, #8]
    96d4:	91002003 	add	x3, x0, #0x8
    96d8:	d2800000 	mov	x0, #0x0                   	// #0
    96dc:	14000005 	b	96f0 <fwp_main_thread+0x1150>
    96e0:	f9400427 	ldr	x7, [x1, #8]
    96e4:	ab060005 	adds	x5, x0, x6
    96e8:	91004063 	add	x3, x3, #0x10
    96ec:	540086e6 	b.vs	a7c8 <fwp_main_thread+0x2228>
    96f0:	a9001467 	stp	x7, x5, [x3]
    96f4:	91000400 	add	x0, x0, #0x1
    96f8:	f9400821 	ldr	x1, [x1, #16]
    96fc:	eb02001f 	cmp	x0, x2
    9700:	54ffff01 	b.ne	96e0 <fwp_main_thread+0x1140>  // b.any
    9704:	f9401be0 	ldr	x0, [sp, #48]
    9708:	f940001c 	ldr	x28, [x0]
    970c:	f100079f 	cmp	x28, #0x1
    9710:	54002e69 	b.ls	9cdc <fwp_main_thread+0x173c>  // b.plast
    9714:	d341ff81 	lsr	x1, x28, #1
    9718:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    971c:	d1000422 	sub	x2, x1, #0x1
    9720:	f90027e2 	str	x2, [sp, #72]
    9724:	eb00005f 	cmp	x2, x0
    9728:	54ffd928 	b.hi	924c <fwp_main_thread+0xcac>  // b.pmore
    972c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    9730:	a90d7fe0 	stp	x0, xzr, [sp, #208]
    9734:	b4002d42 	cbz	x2, 9cdc <fwp_main_thread+0x173c>
    9738:	f9401be2 	ldr	x2, [sp, #48]
    973c:	d1002040 	sub	x0, x2, #0x8
    9740:	9100205c 	add	x28, x2, #0x8
    9744:	8b011000 	add	x0, x0, x1, lsl #4
    9748:	f90023e0 	str	x0, [sp, #64]
    974c:	f9400780 	ldr	x0, [x28, #8]
    9750:	aa1503e2 	mov	x2, x21
    9754:	f9400f81 	ldr	x1, [x28, #24]
    9758:	fd400380 	ldr	d0, [x28]
    975c:	fd400b81 	ldr	d1, [x28, #16]
    9760:	97ffef40 	bl	5460 <w120>
    9764:	a9000780 	stp	x0, x1, [x28]
    9768:	9100439c 	add	x28, x28, #0x10
    976c:	f94023e0 	ldr	x0, [sp, #64]
    9770:	eb00039f 	cmp	x28, x0
    9774:	54fffec1 	b.ne	974c <fwp_main_thread+0x11ac>  // b.any
    9778:	f9401be1 	ldr	x1, [sp, #48]
    977c:	f94027e0 	ldr	x0, [sp, #72]
    9780:	d37ff800 	lsl	x0, x0, #1
    9784:	f9000020 	str	x0, [x1]
    9788:	aa0103e0 	mov	x0, x1
    978c:	97fff085 	bl	59a0 <w176.constprop.0>
    9790:	aa0103fc 	mov	x28, x1
    9794:	91170263 	add	x3, x19, #0x5c0
    9798:	f9401be2 	ldr	x2, [sp, #48]
    979c:	f949d861 	ldr	x1, [x3, #5040]
    97a0:	f949ec60 	ldr	x0, [x3, #5080]
    97a4:	cb010041 	sub	x1, x2, x1
    97a8:	eb00403f 	cmp	x1, x0, lsl #16
    97ac:	54000382 	b.cs	981c <fwp_main_thread+0x127c>  // b.hs, b.nlast
    97b0:	d2800506 	mov	x6, #0x28                  	// #40
    97b4:	d350fc25 	lsr	x5, x1, #16
    97b8:	f949fc62 	ldr	x2, [x3, #5112]
    97bc:	9b067ca5 	mul	x5, x5, x6
    97c0:	8b050047 	add	x7, x2, x5
    97c4:	f94010e0 	ldr	x0, [x7, #32]
    97c8:	b40002a0 	cbz	x0, 981c <fwp_main_thread+0x127c>
    97cc:	38656845 	ldrb	w5, [x2, x5]
    97d0:	710008bf 	cmp	w5, #0x2
    97d4:	540013c0 	b.eq	9a4c <fwp_main_thread+0x14ac>  // b.none
    97d8:	710004bf 	cmp	w5, #0x1
    97dc:	54000201 	b.ne	981c <fwp_main_thread+0x127c>  // b.any
    97e0:	294314e8 	ldp	w8, w5, [x7, #24]
    97e4:	92403c21 	and	x1, x1, #0xffff
    97e8:	9b087c21 	mul	x1, x1, x8
    97ec:	d360fc21 	lsr	x1, x1, #32
    97f0:	eb05003f 	cmp	x1, x5
    97f4:	54000142 	b.cs	981c <fwp_main_thread+0x127c>  // b.hs, b.nlast
    97f8:	8b010000 	add	x0, x0, x1
    97fc:	39400001 	ldrb	w1, [x0]
    9800:	340000e1 	cbz	w1, 981c <fwp_main_thread+0x127c>
    9804:	7100043f 	cmp	w1, #0x1
    9808:	54000320 	b.eq	986c <fwp_main_thread+0x12cc>  // b.none
    980c:	7103fc3f 	cmp	w1, #0xff
    9810:	540026a0 	b.eq	9ce4 <fwp_main_thread+0x1744>  // b.none
    9814:	51000421 	sub	w1, w1, #0x1
    9818:	39000001 	strb	w1, [x0]
    981c:	52800040 	mov	w0, #0x2                   	// #2
    9820:	97ffe774 	bl	35f0 <descent_phase_step>
    9824:	b98053e0 	ldrsw	x0, [sp, #80]
    9828:	f9001be0 	str	x0, [sp, #48]
    982c:	97ffec39 	bl	4910 <fwp_tape_of>
    9830:	aa0003e5 	mov	x5, x0
    9834:	f9402801 	ldr	x1, [x0, #80]
    9838:	b4000b21 	cbz	x1, 999c <fwp_main_thread+0x13fc>
    983c:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    9840:	910c4000 	add	x0, x0, #0x310
    9844:	97ffea2f 	bl	4100 <fwp_trap>
    9848:	aa1703e0 	mov	x0, x23
    984c:	97ffea4d 	bl	4180 <fwp_rc_forget_slot.part.0>
    9850:	17fffd46 	b	8d68 <fwp_main_thread+0x7c8>
    9854:	aa1803e0 	mov	x0, x24
    9858:	97ffea4a 	bl	4180 <fwp_rc_forget_slot.part.0>
    985c:	17fffcfa 	b	8c44 <fwp_main_thread+0x6a4>
    9860:	aa1803e0 	mov	x0, x24
    9864:	97ffea47 	bl	4180 <fwp_rc_forget_slot.part.0>
    9868:	17fffd1b 	b	8cd4 <fwp_main_thread+0x734>
    986c:	f9401fe4 	ldr	x4, [sp, #56]
    9870:	f949ec65 	ldr	x5, [x3, #5080]
    9874:	aa0403e0 	mov	x0, x4
    9878:	f9400087 	ldr	x7, [x4]
    987c:	f949d861 	ldr	x1, [x3, #5040]
    9880:	d370bca5 	lsl	x5, x5, #16
    9884:	cb010081 	sub	x1, x4, x1
    9888:	b7f80ee7 	tbnz	x7, #63, 9a64 <fwp_main_thread+0x14c4>
    988c:	eb05003f 	cmp	x1, x5
    9890:	54fffc62 	b.cs	981c <fwp_main_thread+0x127c>  // b.hs, b.nlast
    9894:	d350fc20 	lsr	x0, x1, #16
    9898:	d2800503 	mov	x3, #0x28                  	// #40
    989c:	9b037c00 	mul	x0, x0, x3
    98a0:	8b000045 	add	x5, x2, x0
    98a4:	f94010a3 	ldr	x3, [x5, #32]
    98a8:	b4fffba3 	cbz	x3, 981c <fwp_main_thread+0x127c>
    98ac:	38606840 	ldrb	w0, [x2, x0]
    98b0:	7100081f 	cmp	w0, #0x2
    98b4:	54001480 	b.eq	9b44 <fwp_main_thread+0x15a4>  // b.none
    98b8:	7100041f 	cmp	w0, #0x1
    98bc:	54fffb01 	b.ne	981c <fwp_main_thread+0x127c>  // b.any
    98c0:	92403c20 	and	x0, x1, #0xffff
    98c4:	294304a2 	ldp	w2, w1, [x5, #24]
    98c8:	9b027c00 	mul	x0, x0, x2
    98cc:	d360fc00 	lsr	x0, x0, #32
    98d0:	eb01001f 	cmp	x0, x1
    98d4:	54fffa42 	b.cs	981c <fwp_main_thread+0x127c>  // b.hs, b.nlast
    98d8:	8b000063 	add	x3, x3, x0
    98dc:	39400060 	ldrb	w0, [x3]
    98e0:	7100041f 	cmp	w0, #0x1
    98e4:	54fff9c1 	b.ne	981c <fwp_main_thread+0x127c>  // b.any
    98e8:	f9401fe0 	ldr	x0, [sp, #56]
    98ec:	97ffeac1 	bl	43f0 <fwp_mem_free>
    98f0:	17ffffcb 	b	981c <fwp_main_thread+0x127c>
    98f4:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    98f8:	9113a000 	add	x0, x0, #0x4e8
    98fc:	97ffea01 	bl	4100 <fwp_trap>
    9900:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    9904:	9115a000 	add	x0, x0, #0x568
    9908:	97ffe9fe 	bl	4100 <fwp_trap>
    990c:	97ffeb32 	bl	45d4 <fwp_rc_wide_dup>
    9910:	91170260 	add	x0, x19, #0x5c0
    9914:	f949ec05 	ldr	x5, [x0, #5080]
    9918:	f949d801 	ldr	x1, [x0, #5040]
    991c:	d370bca5 	lsl	x5, x5, #16
    9920:	17fffd47 	b	8e3c <fwp_main_thread+0x89c>
    9924:	97ffeb2c 	bl	45d4 <fwp_rc_wide_dup>
    9928:	17fffd6d 	b	8edc <fwp_main_thread+0x93c>
    992c:	ca5c4780 	eor	x0, x28, x28, lsr #17
    9930:	91170262 	add	x2, x19, #0x5c0
    9934:	ca402400 	eor	x0, x0, x0, lsr #9
    9938:	92401c00 	and	x0, x0, #0xff
    993c:	910a2401 	add	x1, x0, #0x289
    9940:	8b000c40 	add	x0, x2, x0, lsl #3
    9944:	8b010c41 	add	x1, x2, x1, lsl #3
    9948:	f94a2400 	ldr	x0, [x0, #5192]
    994c:	b50000a0 	cbnz	x0, 9960 <fwp_main_thread+0x13c0>
    9950:	140000dc 	b	9cc0 <fwp_main_thread+0x1720>
    9954:	91004001 	add	x1, x0, #0x10
    9958:	f9400800 	ldr	x0, [x0, #16]
    995c:	b4001b20 	cbz	x0, 9cc0 <fwp_main_thread+0x1720>
    9960:	f9400002 	ldr	x2, [x0]
    9964:	eb1c005f 	cmp	x2, x28
    9968:	54ffff61 	b.ne	9954 <fwp_main_thread+0x13b4>  // b.any
    996c:	f9400021 	ldr	x1, [x1]
    9970:	f9400420 	ldr	x0, [x1, #8]
    9974:	d1000400 	sub	x0, x0, #0x1
    9978:	f9000420 	str	x0, [x1, #8]
    997c:	f103f81f 	cmp	x0, #0xfe
    9980:	54ffaf01 	b.ne	8f60 <fwp_main_thread+0x9c0>  // b.any
    9984:	39400380 	ldrb	w0, [x28]
    9988:	7103fc1f 	cmp	w0, #0xff
    998c:	54001940 	b.eq	9cb4 <fwp_main_thread+0x1714>  // b.none
    9990:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9994:	39000380 	strb	w0, [x28]
    9998:	17fffd72 	b	8f60 <fwp_main_thread+0x9c0>
    999c:	97ffe57d 	bl	2f90 <fwp_tape_unlink_scope>
    99a0:	b90004bf 	str	wzr, [x5, #4]
    99a4:	3dc008a0 	ldr	q0, [x5, #32]
    99a8:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    99ac:	b94000a1 	ldr	w1, [x5]
    99b0:	a9409ca6 	ldp	x6, x7, [x5, #8]
    99b4:	fd001fe0 	str	d0, [sp, #56]
    99b8:	f9400ca8 	ldr	x8, [x5, #24]
    99bc:	a94308a3 	ldp	x3, x2, [x5, #48]
    99c0:	6b00003f 	cmp	w1, w0
    99c4:	54000128 	b.hi	99e8 <fwp_main_thread+0x1448>  // b.pmore
    99c8:	9101c281 	add	x1, x20, #0x70
    99cc:	f9401be0 	ldr	x0, [sp, #48]
    99d0:	f9406c29 	ldr	x9, [x1, #216]
    99d4:	92403c00 	and	x0, x0, #0xffff
    99d8:	d1000400 	sub	x0, x0, #0x1
    99dc:	eb09001f 	cmp	x0, x9
    99e0:	5400004a 	b.ge	99e8 <fwp_main_thread+0x1448>  // b.tcont
    99e4:	f9006c20 	str	x0, [x1, #216]
    99e8:	4f000401 	movi	v1.4s, #0x0
    99ec:	9101c281 	add	x1, x20, #0x70
    99f0:	f9000cbf 	str	xzr, [x5, #24]
    99f4:	910263e4 	add	x4, sp, #0x98
    99f8:	a9037cbf 	stp	xzr, xzr, [x5, #48]
    99fc:	f9418020 	ldr	x0, [x1, #768]
    9a00:	3c8080a1 	stur	q1, [x5, #8]
    9a04:	3d8008a1 	str	q1, [x5, #32]
    9a08:	f90023e4 	str	x4, [sp, #64]
    9a0c:	f9004fe0 	str	x0, [sp, #152]
    9a10:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    9a14:	913fc000 	add	x0, x0, #0xff0
    9a18:	f90053e0 	str	x0, [sp, #160]
    9a1c:	f90057f5 	str	x21, [sp, #168]
    9a20:	a90e23e3 	stp	x3, x8, [sp, #224]
    9a24:	f9007be2 	str	x2, [sp, #240]
    9a28:	f9018024 	str	x4, [x1, #768]
    9a2c:	3d8037e0 	str	q0, [sp, #208]
    9a30:	b7f8133c 	tbnz	x28, #63, 9c94 <fwp_main_thread+0x16f4>
    9a34:	f9401be0 	ldr	x0, [sp, #48]
    9a38:	eb9c801f 	cmp	x0, x28, asr #32
    9a3c:	54000940 	b.eq	9b64 <fwp_main_thread+0x15c4>  // b.none
    9a40:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    9a44:	910b2000 	add	x0, x0, #0x2c8
    9a48:	97ffe9ae 	bl	4100 <fwp_trap>
    9a4c:	72003c3f 	tst	w1, #0xffff
    9a50:	54ffee61 	b.ne	981c <fwp_main_thread+0x127c>  // b.any
    9a54:	17ffff6a 	b	97fc <fwp_main_thread+0x125c>
    9a58:	72003c3f 	tst	w1, #0xffff
    9a5c:	54ffe281 	b.ne	96ac <fwp_main_thread+0x110c>  // b.any
    9a60:	17ffff0e 	b	9698 <fwp_main_thread+0x10f8>
    9a64:	f9400484 	ldr	x4, [x4, #8]
    9a68:	f9001fe4 	str	x4, [sp, #56]
    9a6c:	eb05003f 	cmp	x1, x5
    9a70:	54000342 	b.cs	9ad8 <fwp_main_thread+0x1538>  // b.hs, b.nlast
    9a74:	d350fc27 	lsr	x7, x1, #16
    9a78:	d2800505 	mov	x5, #0x28                  	// #40
    9a7c:	9b057ce7 	mul	x7, x7, x5
    9a80:	8b070048 	add	x8, x2, x7
    9a84:	f9401105 	ldr	x5, [x8, #32]
    9a88:	b4000285 	cbz	x5, 9ad8 <fwp_main_thread+0x1538>
    9a8c:	38676842 	ldrb	w2, [x2, x7]
    9a90:	7100085f 	cmp	w2, #0x2
    9a94:	540010a0 	b.eq	9ca8 <fwp_main_thread+0x1708>  // b.none
    9a98:	7100045f 	cmp	w2, #0x1
    9a9c:	540001e1 	b.ne	9ad8 <fwp_main_thread+0x1538>  // b.any
    9aa0:	29430907 	ldp	w7, w2, [x8, #24]
    9aa4:	92403c21 	and	x1, x1, #0xffff
    9aa8:	9b077c21 	mul	x1, x1, x7
    9aac:	d360fc21 	lsr	x1, x1, #32
    9ab0:	eb02003f 	cmp	x1, x2
    9ab4:	54000122 	b.cs	9ad8 <fwp_main_thread+0x1538>  // b.hs, b.nlast
    9ab8:	8b0100a5 	add	x5, x5, x1
    9abc:	394000a1 	ldrb	w1, [x5]
    9ac0:	7100043f 	cmp	w1, #0x1
    9ac4:	540000a1 	b.ne	9ad8 <fwp_main_thread+0x1538>  // b.any
    9ac8:	f9001be3 	str	x3, [sp, #48]
    9acc:	97ffea49 	bl	43f0 <fwp_mem_free>
    9ad0:	f9401be3 	ldr	x3, [sp, #48]
    9ad4:	d2800506 	mov	x6, #0x28                  	// #40
    9ad8:	91170260 	add	x0, x19, #0x5c0
    9adc:	f9401fe2 	ldr	x2, [sp, #56]
    9ae0:	f949d801 	ldr	x1, [x0, #5040]
    9ae4:	f949ec00 	ldr	x0, [x0, #5080]
    9ae8:	cb010041 	sub	x1, x2, x1
    9aec:	eb00403f 	cmp	x1, x0, lsl #16
    9af0:	54ffe623 	b.cc	97b4 <fwp_main_thread+0x1214>  // b.lo, b.ul, b.last
    9af4:	17ffff4a 	b	981c <fwp_main_thread+0x127c>
    9af8:	d37ff843 	lsl	x3, x2, #1
    9afc:	52800041 	mov	w1, #0x2                   	// #2
    9b00:	91000460 	add	x0, x3, #0x1
    9b04:	a9048be3 	stp	x3, x2, [sp, #72]
    9b08:	d37df000 	lsl	x0, x0, #3
    9b0c:	97ffecf5 	bl	4ee0 <fwp_heap_alloc>
    9b10:	aa0003e2 	mov	x2, x0
    9b14:	91170261 	add	x1, x19, #0x5c0
    9b18:	f94027e3 	ldr	x3, [sp, #72]
    9b1c:	aa0103e0 	mov	x0, x1
    9b20:	f9000043 	str	x3, [x2]
    9b24:	a9030be2 	stp	x2, x2, [sp, #48]
    9b28:	f949d821 	ldr	x1, [x1, #5040]
    9b2c:	f949ec00 	ldr	x0, [x0, #5080]
    9b30:	cb010041 	sub	x1, x2, x1
    9b34:	f9402be2 	ldr	x2, [sp, #80]
    9b38:	eb00403f 	cmp	x1, x0, lsl #16
    9b3c:	54ffdb82 	b.cs	96ac <fwp_main_thread+0x110c>  // b.hs, b.nlast
    9b40:	17fffec2 	b	9648 <fwp_main_thread+0x10a8>
    9b44:	72003c3f 	tst	w1, #0xffff
    9b48:	54ffe6a1 	b.ne	981c <fwp_main_thread+0x127c>  // b.any
    9b4c:	17ffff64 	b	98dc <fwp_main_thread+0x133c>
    9b50:	f94023e0 	ldr	x0, [sp, #64]
    9b54:	d3707c00 	ubfiz	x0, x0, #16, #32
    9b58:	aa1c0000 	orr	x0, x0, x28
    9b5c:	f9002be0 	str	x0, [sp, #80]
    9b60:	17fffee9 	b	9704 <fwp_main_thread+0x1164>
    9b64:	92407f80 	and	x0, x28, #0xffffffff
    9b68:	eb3c40ff 	cmp	x7, w28, uxtw
    9b6c:	5400098d 	b.le	9c9c <fwp_main_thread+0x16fc>
    9b70:	eb06001f 	cmp	x0, x6
    9b74:	9a80b4c5 	csinc	x5, x6, x0, lt	// lt = tstop
    9b78:	eb05005f 	cmp	x2, x5
    9b7c:	54000f4a 	b.ge	9d64 <fwp_main_thread+0x17c4>  // b.tcont
    9b80:	f100005f 	cmp	x2, #0x0
    9b84:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    9b88:	9a851042 	csel	x2, x2, x5, ne	// ne = any
    9b8c:	14000004 	b	9b9c <fwp_main_thread+0x15fc>
    9b90:	eb00005f 	cmp	x2, x0
    9b94:	d37ff842 	lsl	x2, x2, #1
    9b98:	9a85d042 	csel	x2, x2, x5, le
    9b9c:	eb05005f 	cmp	x2, x5
    9ba0:	54ffff8b 	b.lt	9b90 <fwp_main_thread+0x15f0>  // b.tstop
    9ba4:	a90497e6 	stp	x6, x5, [sp, #72]
    9ba8:	b4005f43 	cbz	x3, a790 <fwp_main_thread+0x21f0>
    9bac:	aa0303e0 	mov	x0, x3
    9bb0:	d37df041 	lsl	x1, x2, #3
    9bb4:	f9001be2 	str	x2, [sp, #48]
    9bb8:	97ffe332 	bl	2880 <realloc@plt>
    9bbc:	a94497e6 	ldp	x6, x5, [sp, #72]
    9bc0:	aa0003e3 	mov	x3, x0
    9bc4:	f9401be2 	ldr	x2, [sp, #48]
    9bc8:	b4000ce3 	cbz	x3, 9d64 <fwp_main_thread+0x17c4>
    9bcc:	f90073e3 	str	x3, [sp, #224]
    9bd0:	f9007be2 	str	x2, [sp, #240]
    9bd4:	b5000d05 	cbnz	x5, 9d74 <fwp_main_thread+0x17d4>
    9bd8:	b7f800dc 	tbnz	x28, #63, 9bf0 <fwp_main_thread+0x1650>
    9bdc:	d37d7f9c 	ubfiz	x28, x28, #3, #32
    9be0:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    9be4:	fc7c6860 	ldr	d0, [x3, x28]
    9be8:	1e612800 	fadd	d0, d0, d1
    9bec:	fc3c6860 	str	d0, [x3, x28]
    9bf0:	9101c281 	add	x1, x20, #0x70
    9bf4:	cb0600a2 	sub	x2, x5, x6
    9bf8:	52800060 	mov	w0, #0x3                   	// #3
    9bfc:	f9001be6 	str	x6, [sp, #48]
    9c00:	a9048fe5 	stp	x5, x3, [sp, #72]
    9c04:	a9429c28 	ldp	x8, x7, [x1, #40]
    9c08:	8b0600e7 	add	x7, x7, x6
    9c0c:	8b080042 	add	x2, x2, x8
    9c10:	a9029c22 	stp	x2, x7, [x1, #40]
    9c14:	97ffe677 	bl	35f0 <descent_phase_step>
    9c18:	a9448fe5 	ldp	x5, x3, [sp, #72]
    9c1c:	f9401be6 	ldr	x6, [sp, #48]
    9c20:	d10004a0 	sub	x0, x5, #0x1
    9c24:	eb0000df 	cmp	x6, x0
    9c28:	54000bac 	b.gt	9d9c <fwp_main_thread+0x17fc>
    9c2c:	fc607860 	ldr	d0, [x3, x0, lsl #3]
    9c30:	1e602008 	fcmp	d0, #0.0
    9c34:	540002c0 	b.eq	9c8c <fwp_main_thread+0x16ec>  // b.none
    9c38:	f9401fe2 	ldr	x2, [sp, #56]
    9c3c:	d2800301 	mov	x1, #0x18                  	// #24
    9c40:	9b0188c5 	msub	x5, x6, x1, x2
    9c44:	9b017c01 	mul	x1, x0, x1
    9c48:	8b0100a2 	add	x2, x5, x1
    9c4c:	b86168a1 	ldr	w1, [x5, x1]
    9c50:	37f800e1 	tbnz	w1, #31, 9c6c <fwp_main_thread+0x16cc>
    9c54:	fd400442 	ldr	d2, [x2, #8]
    9c58:	937d7c21 	sbfiz	x1, x1, #3, #32
    9c5c:	1e620802 	fmul	d2, d0, d2
    9c60:	fc616861 	ldr	d1, [x3, x1]
    9c64:	1e622821 	fadd	d1, d1, d2
    9c68:	fc216861 	str	d1, [x3, x1]
    9c6c:	b9400441 	ldr	w1, [x2, #4]
    9c70:	37f800e1 	tbnz	w1, #31, 9c8c <fwp_main_thread+0x16ec>
    9c74:	fd400841 	ldr	d1, [x2, #16]
    9c78:	937d7c21 	sbfiz	x1, x1, #3, #32
    9c7c:	1e610800 	fmul	d0, d0, d1
    9c80:	fc616861 	ldr	d1, [x3, x1]
    9c84:	1e602820 	fadd	d0, d1, d0
    9c88:	fc216860 	str	d0, [x3, x1]
    9c8c:	d1000400 	sub	x0, x0, #0x1
    9c90:	17ffffe5 	b	9c24 <fwp_main_thread+0x1684>
    9c94:	aa0603e5 	mov	x5, x6
    9c98:	17ffffb8 	b	9b78 <fwp_main_thread+0x15d8>
    9c9c:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    9ca0:	910d0000 	add	x0, x0, #0x340
    9ca4:	97ffe917 	bl	4100 <fwp_trap>
    9ca8:	72003c3f 	tst	w1, #0xffff
    9cac:	54fff161 	b.ne	9ad8 <fwp_main_thread+0x1538>  // b.any
    9cb0:	17ffff83 	b	9abc <fwp_main_thread+0x151c>
    9cb4:	aa1c03e0 	mov	x0, x28
    9cb8:	97ffe932 	bl	4180 <fwp_rc_forget_slot.part.0>
    9cbc:	17ffff35 	b	9990 <fwp_main_thread+0x13f0>
    9cc0:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    9cc4:	9103e000 	add	x0, x0, #0xf8
    9cc8:	97ffe90e 	bl	4100 <fwp_trap>
    9ccc:	a9048be0 	stp	x0, x2, [sp, #72]
    9cd0:	97ffe92c 	bl	4180 <fwp_rc_forget_slot.part.0>
    9cd4:	a9448be0 	ldp	x0, x2, [sp, #72]
    9cd8:	17fffe73 	b	96a4 <fwp_main_thread+0x1104>
    9cdc:	f90027ff 	str	xzr, [sp, #72]
    9ce0:	17fffea6 	b	9778 <fwp_main_thread+0x11d8>
    9ce4:	ca404401 	eor	x1, x0, x0, lsr #17
    9ce8:	91170263 	add	x3, x19, #0x5c0
    9cec:	ca412421 	eor	x1, x1, x1, lsr #9
    9cf0:	92401c21 	and	x1, x1, #0xff
    9cf4:	910a2422 	add	x2, x1, #0x289
    9cf8:	8b010c61 	add	x1, x3, x1, lsl #3
    9cfc:	8b020c62 	add	x2, x3, x2, lsl #3
    9d00:	f94a2421 	ldr	x1, [x1, #5192]
    9d04:	b4fffde1 	cbz	x1, 9cc0 <fwp_main_thread+0x1720>
    9d08:	f9400023 	ldr	x3, [x1]
    9d0c:	eb00007f 	cmp	x3, x0
    9d10:	54005280 	b.eq	a760 <fwp_main_thread+0x21c0>  // b.none
    9d14:	91004022 	add	x2, x1, #0x10
    9d18:	f9400821 	ldr	x1, [x1, #16]
    9d1c:	17fffffa 	b	9d04 <fwp_main_thread+0x1764>
    9d20:	f9404fe1 	ldr	x1, [sp, #152]
    9d24:	9101c294 	add	x20, x20, #0x70
    9d28:	aa1503e0 	mov	x0, x21
    9d2c:	f9018281 	str	x1, [x20, #768]
    9d30:	97ffe8b0 	bl	3ff0 <fwp_tape_buffers_release>
    9d34:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    9d38:	f947e863 	ldr	x3, [x3, #4048]
    9d3c:	d2800262 	mov	x2, #0x13                  	// #19
    9d40:	d2800021 	mov	x1, #0x1                   	// #1
    9d44:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1a60>
    9d48:	913c2000 	add	x0, x0, #0xf08
    9d4c:	f9400063 	ldr	x3, [x3]
    9d50:	97ffe310 	bl	2990 <fwrite@plt>
    9d54:	d2800000 	mov	x0, #0x0                   	// #0
    9d58:	97ffe31a 	bl	29c0 <fflush@plt>
    9d5c:	52800cc0 	mov	w0, #0x66                  	// #102
    9d60:	97ffe328 	bl	2a00 <_Exit@plt>
    9d64:	f10000bf 	cmp	x5, #0x0
    9d68:	fa401860 	ccmp	x3, #0x0, #0x0, ne	// ne = any
    9d6c:	54fffda0 	b.eq	9d20 <fwp_main_thread+0x1780>  // b.none
    9d70:	b4fff345 	cbz	x5, 9bd8 <fwp_main_thread+0x1638>
    9d74:	d37df0a2 	lsl	x2, x5, #3
    9d78:	aa0303e0 	mov	x0, x3
    9d7c:	52800001 	mov	w1, #0x0                   	// #0
    9d80:	f9001be5 	str	x5, [sp, #48]
    9d84:	f90027e6 	str	x6, [sp, #72]
    9d88:	97ffe2b6 	bl	2860 <memset@plt>
    9d8c:	f9401be5 	ldr	x5, [sp, #48]
    9d90:	aa0003e3 	mov	x3, x0
    9d94:	f94027e6 	ldr	x6, [sp, #72]
    9d98:	17ffff90 	b	9bd8 <fwp_main_thread+0x1638>
    9d9c:	52800080 	mov	w0, #0x4                   	// #4
    9da0:	a9030fe6 	stp	x6, x3, [sp, #48]
    9da4:	97ffe613 	bl	35f0 <descent_phase_step>
    9da8:	a9430fe6 	ldp	x6, x3, [sp, #48]
    9dac:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9db0:	eb0000df 	cmp	x6, x0
    9db4:	54000ee8 	b.hi	9f90 <fwp_main_thread+0x19f0>  // b.pmore
    9db8:	910004c0 	add	x0, x6, #0x1
    9dbc:	52800041 	mov	w1, #0x2                   	// #2
    9dc0:	a9030fe6 	stp	x6, x3, [sp, #48]
    9dc4:	d37df000 	lsl	x0, x0, #3
    9dc8:	97ffec46 	bl	4ee0 <fwp_heap_alloc>
    9dcc:	aa0003fc 	mov	x28, x0
    9dd0:	a9430fe6 	ldp	x6, x3, [sp, #48]
    9dd4:	d2800001 	mov	x1, #0x0                   	// #0
    9dd8:	f8008406 	str	x6, [x0], #8
    9ddc:	14000004 	b	9dec <fwp_main_thread+0x184c>
    9de0:	f8617862 	ldr	x2, [x3, x1, lsl #3]
    9de4:	f8217802 	str	x2, [x0, x1, lsl #3]
    9de8:	91000421 	add	x1, x1, #0x1
    9dec:	eb0100df 	cmp	x6, x1
    9df0:	54ffff81 	b.ne	9de0 <fwp_main_thread+0x1840>  // b.any
    9df4:	528000a0 	mov	w0, #0x5                   	// #5
    9df8:	97ffe5fe 	bl	35f0 <descent_phase_step>
    9dfc:	9101c281 	add	x1, x20, #0x70
    9e00:	f94023e2 	ldr	x2, [sp, #64]
    9e04:	f9418020 	ldr	x0, [x1, #768]
    9e08:	eb02001f 	cmp	x0, x2
    9e0c:	54004e81 	b.ne	a7dc <fwp_main_thread+0x223c>  // b.any
    9e10:	f9404fe2 	ldr	x2, [sp, #152]
    9e14:	aa1503e0 	mov	x0, x21
    9e18:	f9018022 	str	x2, [x1, #768]
    9e1c:	97ffe875 	bl	3ff0 <fwp_tape_buffers_release>
    9e20:	528000c0 	mov	w0, #0x6                   	// #6
    9e24:	97ffe5f3 	bl	35f0 <descent_phase_step>
    9e28:	91170260 	add	x0, x19, #0x5c0
    9e2c:	f949d801 	ldr	x1, [x0, #5040]
    9e30:	f949ec02 	ldr	x2, [x0, #5080]
    9e34:	cb010381 	sub	x1, x28, x1
    9e38:	eb02403f 	cmp	x1, x2, lsl #16
    9e3c:	54000322 	b.cs	9ea0 <fwp_main_thread+0x1900>  // b.hs, b.nlast
    9e40:	d350fc22 	lsr	x2, x1, #16
    9e44:	d2800503 	mov	x3, #0x28                  	// #40
    9e48:	f949fc05 	ldr	x5, [x0, #5112]
    9e4c:	9b037c42 	mul	x2, x2, x3
    9e50:	8b0200a3 	add	x3, x5, x2
    9e54:	f9401060 	ldr	x0, [x3, #32]
    9e58:	b4000240 	cbz	x0, 9ea0 <fwp_main_thread+0x1900>
    9e5c:	386268a2 	ldrb	w2, [x5, x2]
    9e60:	7100085f 	cmp	w2, #0x2
    9e64:	54004640 	b.eq	a72c <fwp_main_thread+0x218c>  // b.none
    9e68:	7100045f 	cmp	w2, #0x1
    9e6c:	540001a1 	b.ne	9ea0 <fwp_main_thread+0x1900>  // b.any
    9e70:	29430865 	ldp	w5, w2, [x3, #24]
    9e74:	92403c21 	and	x1, x1, #0xffff
    9e78:	9b057c21 	mul	x1, x1, x5
    9e7c:	d360fc21 	lsr	x1, x1, #32
    9e80:	eb02003f 	cmp	x1, x2
    9e84:	540000e2 	b.cs	9ea0 <fwp_main_thread+0x1900>  // b.hs, b.nlast
    9e88:	8b010000 	add	x0, x0, x1
    9e8c:	39400001 	ldrb	w1, [x0]
    9e90:	7103fc3f 	cmp	w1, #0xff
    9e94:	54004440 	b.eq	a71c <fwp_main_thread+0x217c>  // b.none
    9e98:	52800021 	mov	w1, #0x1                   	// #1
    9e9c:	39000001 	strb	w1, [x0]
    9ea0:	9101c281 	add	x1, x20, #0x70
    9ea4:	f9400fe2 	ldr	x2, [sp, #24]
    9ea8:	f9418020 	ldr	x0, [x1, #768]
    9eac:	eb02001f 	cmp	x0, x2
    9eb0:	54004961 	b.ne	a7dc <fwp_main_thread+0x223c>  // b.any
    9eb4:	f9400be0 	ldr	x0, [sp, #16]
    9eb8:	f94043e2 	ldr	x2, [sp, #128]
    9ebc:	f9018022 	str	x2, [x1, #768]
    9ec0:	97fff180 	bl	64c0 <fwp_tape_scope_release>
    9ec4:	f9400380 	ldr	x0, [x28]
    9ec8:	9240f803 	and	x3, x0, #0x7fffffffffffffff
    9ecc:	b7f80880 	tbnz	x0, #63, 9fdc <fwp_main_thread+0x1a3c>
    9ed0:	91170261 	add	x1, x19, #0x5c0
    9ed4:	f949d820 	ldr	x0, [x1, #5040]
    9ed8:	f949ec22 	ldr	x2, [x1, #5080]
    9edc:	cb000380 	sub	x0, x28, x0
    9ee0:	eb02401f 	cmp	x0, x2, lsl #16
    9ee4:	540007c2 	b.cs	9fdc <fwp_main_thread+0x1a3c>  // b.hs, b.nlast
    9ee8:	d350fc02 	lsr	x2, x0, #16
    9eec:	d2800505 	mov	x5, #0x28                  	// #40
    9ef0:	f949fc26 	ldr	x6, [x1, #5112]
    9ef4:	9b057c42 	mul	x2, x2, x5
    9ef8:	8b0200c5 	add	x5, x6, x2
    9efc:	f94010a1 	ldr	x1, [x5, #32]
    9f00:	b40006e1 	cbz	x1, 9fdc <fwp_main_thread+0x1a3c>
    9f04:	386268c2 	ldrb	w2, [x6, x2]
    9f08:	7100085f 	cmp	w2, #0x2
    9f0c:	54000640 	b.eq	9fd4 <fwp_main_thread+0x1a34>  // b.none
    9f10:	7100045f 	cmp	w2, #0x1
    9f14:	54000641 	b.ne	9fdc <fwp_main_thread+0x1a3c>  // b.any
    9f18:	294308a6 	ldp	w6, w2, [x5, #24]
    9f1c:	92403c00 	and	x0, x0, #0xffff
    9f20:	9b067c00 	mul	x0, x0, x6
    9f24:	d360fc00 	lsr	x0, x0, #32
    9f28:	eb02001f 	cmp	x0, x2
    9f2c:	54000582 	b.cs	9fdc <fwp_main_thread+0x1a3c>  // b.hs, b.nlast
    9f30:	8b000021 	add	x1, x1, x0
    9f34:	39400020 	ldrb	w0, [x1]
    9f38:	7100041f 	cmp	w0, #0x1
    9f3c:	54000501 	b.ne	9fdc <fwp_main_thread+0x1a3c>  // b.any
    9f40:	aa1c03e2 	mov	x2, x28
    9f44:	d2800000 	mov	x0, #0x0                   	// #0
    9f48:	d0000004 	adrp	x4, b000 <_IO_stdin_used+0x100>
    9f4c:	91002387 	add	x7, x28, #0x8
    9f50:	d2800001 	mov	x1, #0x0                   	// #0
    9f54:	fd46a081 	ldr	d1, [x4, #3392]
    9f58:	eb01007f 	cmp	x3, x1
    9f5c:	540002a0 	b.eq	9fb0 <fwp_main_thread+0x1a10>  // b.none
    9f60:	f9400385 	ldr	x5, [x28]
    9f64:	b7f80225 	tbnz	x5, #63, 9fa8 <fwp_main_thread+0x1a08>
    9f68:	aa0703e6 	mov	x6, x7
    9f6c:	f9400048 	ldr	x8, [x2]
    9f70:	d37df025 	lsl	x5, x1, #3
    9f74:	fc6568c0 	ldr	d0, [x6, x5]
    9f78:	b7f80128 	tbnz	x8, #63, 9f9c <fwp_main_thread+0x19fc>
    9f7c:	1e600820 	fmul	d0, d1, d0
    9f80:	8b050045 	add	x5, x2, x5
    9f84:	91000421 	add	x1, x1, #0x1
    9f88:	fd0004a0 	str	d0, [x5, #8]
    9f8c:	17fffff3 	b	9f58 <fwp_main_thread+0x19b8>
    9f90:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    9f94:	91146000 	add	x0, x0, #0x518
    9f98:	97ffe85a 	bl	4100 <fwp_trap>
    9f9c:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    9fa0:	9114a000 	add	x0, x0, #0x528
    9fa4:	97ffe857 	bl	4100 <fwp_trap>
    9fa8:	f9400b86 	ldr	x6, [x28, #16]
    9fac:	17fffff0 	b	9f6c <fwp_main_thread+0x19cc>
    9fb0:	f9001be2 	str	x2, [sp, #48]
    9fb4:	97fff34f 	bl	6cf0 <fwp_drop10>
    9fb8:	f9401be2 	ldr	x2, [sp, #48]
    9fbc:	aa1803e0 	mov	x0, x24
    9fc0:	d2800006 	mov	x6, #0x0                   	// #0
    9fc4:	b4000620 	cbz	x0, a088 <fwp_main_thread+0x1ae8>
    9fc8:	f9400800 	ldr	x0, [x0, #16]
    9fcc:	910004c6 	add	x6, x6, #0x1
    9fd0:	17fffffd 	b	9fc4 <fwp_main_thread+0x1a24>
    9fd4:	72003c1f 	tst	w0, #0xffff
    9fd8:	54fffae0 	b.eq	9f34 <fwp_main_thread+0x1994>  // b.none
    9fdc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9fe0:	eb00007f 	cmp	x3, x0
    9fe4:	54fffd68 	b.hi	9f90 <fwp_main_thread+0x19f0>  // b.pmore
    9fe8:	91000460 	add	x0, x3, #0x1
    9fec:	52800021 	mov	w1, #0x1                   	// #1
    9ff0:	f9001be3 	str	x3, [sp, #48]
    9ff4:	d37df000 	lsl	x0, x0, #3
    9ff8:	97ffebba 	bl	4ee0 <fwp_heap_alloc>
    9ffc:	f9401be3 	ldr	x3, [sp, #48]
    a000:	91170266 	add	x6, x19, #0x5c0
    a004:	f9000003 	str	x3, [x0]
    a008:	aa0003e2 	mov	x2, x0
    a00c:	f949d8c1 	ldr	x1, [x6, #5040]
    a010:	f949ecc0 	ldr	x0, [x6, #5080]
    a014:	cb010041 	sub	x1, x2, x1
    a018:	eb00403f 	cmp	x1, x0, lsl #16
    a01c:	54000322 	b.cs	a080 <fwp_main_thread+0x1ae0>  // b.hs, b.nlast
    a020:	d350fc25 	lsr	x5, x1, #16
    a024:	d2800500 	mov	x0, #0x28                  	// #40
    a028:	f949fcc7 	ldr	x7, [x6, #5112]
    a02c:	9b007ca5 	mul	x5, x5, x0
    a030:	8b0500e6 	add	x6, x7, x5
    a034:	f94010c0 	ldr	x0, [x6, #32]
    a038:	b4000240 	cbz	x0, a080 <fwp_main_thread+0x1ae0>
    a03c:	386568e5 	ldrb	w5, [x7, x5]
    a040:	710008bf 	cmp	w5, #0x2
    a044:	540033e0 	b.eq	a6c0 <fwp_main_thread+0x2120>  // b.none
    a048:	710004bf 	cmp	w5, #0x1
    a04c:	540001a1 	b.ne	a080 <fwp_main_thread+0x1ae0>  // b.any
    a050:	294314c7 	ldp	w7, w5, [x6, #24]
    a054:	92403c21 	and	x1, x1, #0xffff
    a058:	9b077c21 	mul	x1, x1, x7
    a05c:	d360fc21 	lsr	x1, x1, #32
    a060:	eb05003f 	cmp	x1, x5
    a064:	540000e2 	b.cs	a080 <fwp_main_thread+0x1ae0>  // b.hs, b.nlast
    a068:	8b010000 	add	x0, x0, x1
    a06c:	39400001 	ldrb	w1, [x0]
    a070:	7103fc3f 	cmp	w1, #0xff
    a074:	54000720 	b.eq	a158 <fwp_main_thread+0x1bb8>  // b.none
    a078:	52800021 	mov	w1, #0x1                   	// #1
    a07c:	39000001 	strb	w1, [x0]
    a080:	aa1c03e0 	mov	x0, x28
    a084:	17ffffb1 	b	9f48 <fwp_main_thread+0x19a8>
    a088:	f9400040 	ldr	x0, [x2]
    a08c:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    a090:	b7f830c0 	tbnz	x0, #63, a6a8 <fwp_main_thread+0x2108>
    a094:	91170261 	add	x1, x19, #0x5c0
    a098:	f949d820 	ldr	x0, [x1, #5040]
    a09c:	f949ec23 	ldr	x3, [x1, #5080]
    a0a0:	cb000040 	sub	x0, x2, x0
    a0a4:	eb03401f 	cmp	x0, x3, lsl #16
    a0a8:	54003002 	b.cs	a6a8 <fwp_main_thread+0x2108>  // b.hs, b.nlast
    a0ac:	d350fc03 	lsr	x3, x0, #16
    a0b0:	d2800507 	mov	x7, #0x28                  	// #40
    a0b4:	f949fc28 	ldr	x8, [x1, #5112]
    a0b8:	9b077c63 	mul	x3, x3, x7
    a0bc:	8b030107 	add	x7, x8, x3
    a0c0:	f94010e1 	ldr	x1, [x7, #32]
    a0c4:	b4002f21 	cbz	x1, a6a8 <fwp_main_thread+0x2108>
    a0c8:	38636903 	ldrb	w3, [x8, x3]
    a0cc:	7100087f 	cmp	w3, #0x2
    a0d0:	54002e80 	b.eq	a6a0 <fwp_main_thread+0x2100>  // b.none
    a0d4:	7100047f 	cmp	w3, #0x1
    a0d8:	54002e81 	b.ne	a6a8 <fwp_main_thread+0x2108>  // b.any
    a0dc:	29430ce8 	ldp	w8, w3, [x7, #24]
    a0e0:	92403c00 	and	x0, x0, #0xffff
    a0e4:	9b087c00 	mul	x0, x0, x8
    a0e8:	d360fc00 	lsr	x0, x0, #32
    a0ec:	eb03001f 	cmp	x0, x3
    a0f0:	54002dc2 	b.cs	a6a8 <fwp_main_thread+0x2108>  // b.hs, b.nlast
    a0f4:	8b000021 	add	x1, x1, x0
    a0f8:	39400020 	ldrb	w0, [x1]
    a0fc:	7100041f 	cmp	w0, #0x1
    a100:	54002d41 	b.ne	a6a8 <fwp_main_thread+0x2108>  // b.any
    a104:	91002043 	add	x3, x2, #0x8
    a108:	b9003be0 	str	w0, [sp, #56]
    a10c:	eb0600bf 	cmp	x5, x6
    a110:	aa1803e1 	mov	x1, x24
    a114:	9a8690a5 	csel	x5, x5, x6, ls	// ls = plast
    a118:	91002047 	add	x7, x2, #0x8
    a11c:	d2800000 	mov	x0, #0x0                   	// #0
    a120:	14000008 	b	a140 <fwp_main_thread+0x1ba0>
    a124:	aa0703e6 	mov	x6, x7
    a128:	fc6078c1 	ldr	d1, [x6, x0, lsl #3]
    a12c:	fd400420 	ldr	d0, [x1, #8]
    a130:	1e613800 	fsub	d0, d0, d1
    a134:	fc207860 	str	d0, [x3, x0, lsl #3]
    a138:	91000400 	add	x0, x0, #0x1
    a13c:	f9400821 	ldr	x1, [x1, #16]
    a140:	eb05001f 	cmp	x0, x5
    a144:	54000160 	b.eq	a170 <fwp_main_thread+0x1bd0>  // b.none
    a148:	f9400046 	ldr	x6, [x2]
    a14c:	b6fffec6 	tbz	x6, #63, a124 <fwp_main_thread+0x1b84>
    a150:	f9400846 	ldr	x6, [x2, #16]
    a154:	17fffff5 	b	a128 <fwp_main_thread+0x1b88>
    a158:	a9030be0 	stp	x0, x2, [sp, #48]
    a15c:	f90023e3 	str	x3, [sp, #64]
    a160:	97ffe808 	bl	4180 <fwp_rc_forget_slot.part.0>
    a164:	a9430be0 	ldp	x0, x2, [sp, #48]
    a168:	f94023e3 	ldr	x3, [sp, #64]
    a16c:	17ffffc3 	b	a078 <fwp_main_thread+0x1ad8>
    a170:	91170260 	add	x0, x19, #0x5c0
    a174:	aa1803ea 	mov	x10, x24
    a178:	d2800006 	mov	x6, #0x0                   	// #0
    a17c:	d280050b 	mov	x11, #0x28                  	// #40
    a180:	f949ec08 	ldr	x8, [x0, #5080]
    a184:	f949d80c 	ldr	x12, [x0, #5040]
    a188:	f949fc0d 	ldr	x13, [x0, #5112]
    a18c:	d370bd08 	lsl	x8, x8, #16
    a190:	14000003 	b	a19c <fwp_main_thread+0x1bfc>
    a194:	f940094a 	ldr	x10, [x10, #16]
    a198:	910004c6 	add	x6, x6, #0x1
    a19c:	f100015f 	cmp	x10, #0x0
    a1a0:	fa4510c2 	ccmp	x6, x5, #0x2, ne	// ne = any
    a1a4:	54000302 	b.cs	a204 <fwp_main_thread+0x1c64>  // b.hs, b.nlast
    a1a8:	cb0c0140 	sub	x0, x10, x12
    a1ac:	eb08001f 	cmp	x0, x8
    a1b0:	540002a2 	b.cs	a204 <fwp_main_thread+0x1c64>  // b.hs, b.nlast
    a1b4:	d350fc07 	lsr	x7, x0, #16
    a1b8:	9b0b7ce7 	mul	x7, x7, x11
    a1bc:	8b0701a9 	add	x9, x13, x7
    a1c0:	f9401121 	ldr	x1, [x9, #32]
    a1c4:	b4000201 	cbz	x1, a204 <fwp_main_thread+0x1c64>
    a1c8:	386769a7 	ldrb	w7, [x13, x7]
    a1cc:	710008ff 	cmp	w7, #0x2
    a1d0:	54000f60 	b.eq	a3bc <fwp_main_thread+0x1e1c>  // b.none
    a1d4:	710004ff 	cmp	w7, #0x1
    a1d8:	54000161 	b.ne	a204 <fwp_main_thread+0x1c64>  // b.any
    a1dc:	29431d2e 	ldp	w14, w7, [x9, #24]
    a1e0:	92403c00 	and	x0, x0, #0xffff
    a1e4:	9b0e7c00 	mul	x0, x0, x14
    a1e8:	d360fc00 	lsr	x0, x0, #32
    a1ec:	eb07001f 	cmp	x0, x7
    a1f0:	540000a2 	b.cs	a204 <fwp_main_thread+0x1c64>  // b.hs, b.nlast
    a1f4:	8b000021 	add	x1, x1, x0
    a1f8:	39400020 	ldrb	w0, [x1]
    a1fc:	7100041f 	cmp	w0, #0x1
    a200:	54fffca0 	b.eq	a194 <fwp_main_thread+0x1bf4>  // b.none
    a204:	d280001c 	mov	x28, #0x0                   	// #0
    a208:	eb0500df 	cmp	x6, x5
    a20c:	540005c2 	b.cs	a2c4 <fwp_main_thread+0x1d24>  // b.hs, b.nlast
    a210:	d1002067 	sub	x7, x3, #0x8
    a214:	aa1603e1 	mov	x1, x22
    a218:	52800020 	mov	w0, #0x1                   	// #1
    a21c:	f9001be5 	str	x5, [sp, #48]
    a220:	a9040be3 	stp	x3, x2, [sp, #64]
    a224:	f86578e7 	ldr	x7, [x7, x5, lsl #3]
    a228:	f9002be6 	str	x6, [sp, #80]
    a22c:	a91373e7 	stp	x7, x28, [sp, #304]
    a230:	97ffeb71 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a234:	aa0003fc 	mov	x28, x0
    a238:	91170268 	add	x8, x19, #0x5c0
    a23c:	f9401be5 	ldr	x5, [sp, #48]
    a240:	f949d901 	ldr	x1, [x8, #5040]
    a244:	f949ed00 	ldr	x0, [x8, #5080]
    a248:	cb010381 	sub	x1, x28, x1
    a24c:	a9440be3 	ldp	x3, x2, [sp, #64]
    a250:	f9402be6 	ldr	x6, [sp, #80]
    a254:	eb00403f 	cmp	x1, x0, lsl #16
    a258:	54000322 	b.cs	a2bc <fwp_main_thread+0x1d1c>  // b.hs, b.nlast
    a25c:	d350fc27 	lsr	x7, x1, #16
    a260:	d2800500 	mov	x0, #0x28                  	// #40
    a264:	f949fd09 	ldr	x9, [x8, #5112]
    a268:	9b007ce7 	mul	x7, x7, x0
    a26c:	8b070128 	add	x8, x9, x7
    a270:	f9401100 	ldr	x0, [x8, #32]
    a274:	b4000240 	cbz	x0, a2bc <fwp_main_thread+0x1d1c>
    a278:	38676927 	ldrb	w7, [x9, x7]
    a27c:	710008ff 	cmp	w7, #0x2
    a280:	54002040 	b.eq	a688 <fwp_main_thread+0x20e8>  // b.none
    a284:	710004ff 	cmp	w7, #0x1
    a288:	540001a1 	b.ne	a2bc <fwp_main_thread+0x1d1c>  // b.any
    a28c:	29431d09 	ldp	w9, w7, [x8, #24]
    a290:	92403c21 	and	x1, x1, #0xffff
    a294:	9b097c21 	mul	x1, x1, x9
    a298:	d360fc21 	lsr	x1, x1, #32
    a29c:	eb07003f 	cmp	x1, x7
    a2a0:	540000e2 	b.cs	a2bc <fwp_main_thread+0x1d1c>  // b.hs, b.nlast
    a2a4:	8b010000 	add	x0, x0, x1
    a2a8:	39400001 	ldrb	w1, [x0]
    a2ac:	7103fc3f 	cmp	w1, #0xff
    a2b0:	54001220 	b.eq	a4f4 <fwp_main_thread+0x1f54>  // b.none
    a2b4:	52800021 	mov	w1, #0x1                   	// #1
    a2b8:	39000001 	strb	w1, [x0]
    a2bc:	d10004a5 	sub	x5, x5, #0x1
    a2c0:	17ffffd2 	b	a208 <fwp_main_thread+0x1c68>
    a2c4:	f9001bf8 	str	x24, [sp, #48]
    a2c8:	b40001a6 	cbz	x6, a2fc <fwp_main_thread+0x1d5c>
    a2cc:	d2800000 	mov	x0, #0x0                   	// #0
    a2d0:	f9401be4 	ldr	x4, [sp, #48]
    a2d4:	f8607861 	ldr	x1, [x3, x0, lsl #3]
    a2d8:	91000400 	add	x0, x0, #0x1
    a2dc:	f9000481 	str	x1, [x4, #8]
    a2e0:	aa0403e1 	mov	x1, x4
    a2e4:	f9400884 	ldr	x4, [x4, #16]
    a2e8:	f9001be4 	str	x4, [sp, #48]
    a2ec:	eb0000df 	cmp	x6, x0
    a2f0:	54ffff01 	b.ne	a2d0 <fwp_main_thread+0x1d30>  // b.any
    a2f4:	f900083c 	str	x28, [x1, #16]
    a2f8:	aa1803fc 	mov	x28, x24
    a2fc:	b9403be0 	ldr	w0, [sp, #56]
    a300:	91170268 	add	x8, x19, #0x5c0
    a304:	92800007 	mov	x7, #0xffffffffffffffff    	// #-1
    a308:	7100001f 	cmp	w0, #0x0
    a30c:	9a9f0063 	csel	x3, x3, xzr, eq	// eq = none
    a310:	b10004ff 	cmn	x7, #0x1
    a314:	54ff7dc0 	b.eq	92cc <fwp_main_thread+0xd2c>  // b.none
    a318:	f8677860 	ldr	x0, [x3, x7, lsl #3]
    a31c:	aa1603e1 	mov	x1, x22
    a320:	a9038fe7 	stp	x7, x3, [sp, #56]
    a324:	a904a3e2 	stp	x2, x8, [sp, #72]
    a328:	a91373e0 	stp	x0, x28, [sp, #304]
    a32c:	52800020 	mov	w0, #0x1                   	// #1
    a330:	97ffeb31 	bl	4ff4 <fwp_data.part.0.constprop.0>
    a334:	a944a3e2 	ldp	x2, x8, [sp, #72]
    a338:	aa0003fc 	mov	x28, x0
    a33c:	a9438fe7 	ldp	x7, x3, [sp, #56]
    a340:	f949d901 	ldr	x1, [x8, #5040]
    a344:	f949ed00 	ldr	x0, [x8, #5080]
    a348:	cb010381 	sub	x1, x28, x1
    a34c:	eb00403f 	cmp	x1, x0, lsl #16
    a350:	54000322 	b.cs	a3b4 <fwp_main_thread+0x1e14>  // b.hs, b.nlast
    a354:	d350fc25 	lsr	x5, x1, #16
    a358:	d2800500 	mov	x0, #0x28                  	// #40
    a35c:	f949fd09 	ldr	x9, [x8, #5112]
    a360:	9b007ca5 	mul	x5, x5, x0
    a364:	8b050126 	add	x6, x9, x5
    a368:	f94010c0 	ldr	x0, [x6, #32]
    a36c:	b4000240 	cbz	x0, a3b4 <fwp_main_thread+0x1e14>
    a370:	38656925 	ldrb	w5, [x9, x5]
    a374:	710008bf 	cmp	w5, #0x2
    a378:	54001800 	b.eq	a678 <fwp_main_thread+0x20d8>  // b.none
    a37c:	710004bf 	cmp	w5, #0x1
    a380:	540001a1 	b.ne	a3b4 <fwp_main_thread+0x1e14>  // b.any
    a384:	294314c9 	ldp	w9, w5, [x6, #24]
    a388:	92403c21 	and	x1, x1, #0xffff
    a38c:	9b097c21 	mul	x1, x1, x9
    a390:	d360fc21 	lsr	x1, x1, #32
    a394:	eb05003f 	cmp	x1, x5
    a398:	540000e2 	b.cs	a3b4 <fwp_main_thread+0x1e14>  // b.hs, b.nlast
    a39c:	8b010000 	add	x0, x0, x1
    a3a0:	39400001 	ldrb	w1, [x0]
    a3a4:	7103fc3f 	cmp	w1, #0xff
    a3a8:	54001580 	b.eq	a658 <fwp_main_thread+0x20b8>  // b.none
    a3ac:	52800021 	mov	w1, #0x1                   	// #1
    a3b0:	39000001 	strb	w1, [x0]
    a3b4:	d10004e7 	sub	x7, x7, #0x1
    a3b8:	17ffffd6 	b	a310 <fwp_main_thread+0x1d70>
    a3bc:	72003c1f 	tst	w0, #0xffff
    a3c0:	54fff221 	b.ne	a204 <fwp_main_thread+0x1c64>  // b.any
    a3c4:	17ffff8d 	b	a1f8 <fwp_main_thread+0x1c58>
    a3c8:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x100>
    a3cc:	91154000 	add	x0, x0, #0x550
    a3d0:	97ffe74c 	bl	4100 <fwp_trap>
    a3d4:	f9401be0 	ldr	x0, [sp, #48]
    a3d8:	97ffedca 	bl	5b00 <fwp_rc_free_arr>
    a3dc:	17fffc70 	b	959c <fwp_main_thread+0xffc>
    a3e0:	72003c3f 	tst	w1, #0xffff
    a3e4:	54ff8dc1 	b.ne	959c <fwp_main_thread+0xffc>  // b.any
    a3e8:	17fffc65 	b	957c <fwp_main_thread+0xfdc>
    a3ec:	72003c3f 	tst	w1, #0xffff
    a3f0:	54ff87c1 	b.ne	94e8 <fwp_main_thread+0xf48>  // b.any
    a3f4:	17fffc38 	b	94d4 <fwp_main_thread+0xf34>
    a3f8:	ca5c4781 	eor	x1, x28, x28, lsr #17
    a3fc:	91170260 	add	x0, x19, #0x5c0
    a400:	ca412421 	eor	x1, x1, x1, lsr #9
    a404:	92401c21 	and	x1, x1, #0xff
    a408:	910a2422 	add	x2, x1, #0x289
    a40c:	8b010c01 	add	x1, x0, x1, lsl #3
    a410:	8b020c02 	add	x2, x0, x2, lsl #3
    a414:	f94a2420 	ldr	x0, [x1, #5192]
    a418:	b4ffc540 	cbz	x0, 9cc0 <fwp_main_thread+0x1720>
    a41c:	f9400001 	ldr	x1, [x0]
    a420:	eb1c003f 	cmp	x1, x28
    a424:	54000100 	b.eq	a444 <fwp_main_thread+0x1ea4>  // b.none
    a428:	91004002 	add	x2, x0, #0x10
    a42c:	f9400800 	ldr	x0, [x0, #16]
    a430:	17fffffa 	b	a418 <fwp_main_thread+0x1e78>
    a434:	f90023e0 	str	x0, [sp, #64]
    a438:	97ffe752 	bl	4180 <fwp_rc_forget_slot.part.0>
    a43c:	f94023e0 	ldr	x0, [sp, #64]
    a440:	17fffc28 	b	94e0 <fwp_main_thread+0xf40>
    a444:	f9400041 	ldr	x1, [x2]
    a448:	f9400420 	ldr	x0, [x1, #8]
    a44c:	d1000400 	sub	x0, x0, #0x1
    a450:	f9000420 	str	x0, [x1, #8]
    a454:	f103f81f 	cmp	x0, #0xfe
    a458:	54ff8a21 	b.ne	959c <fwp_main_thread+0xffc>  // b.any
    a45c:	39400380 	ldrb	w0, [x28]
    a460:	7103fc1f 	cmp	w0, #0xff
    a464:	54000260 	b.eq	a4b0 <fwp_main_thread+0x1f10>  // b.none
    a468:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a46c:	39000380 	strb	w0, [x28]
    a470:	17fffc4b 	b	959c <fwp_main_thread+0xffc>
    a474:	f9400045 	ldr	x5, [x2]
    a478:	aa0203e0 	mov	x0, x2
    a47c:	b7f80245 	tbnz	x5, #63, a4c4 <fwp_main_thread+0x1f24>
    a480:	710008df 	cmp	w6, #0x2
    a484:	540001c0 	b.eq	a4bc <fwp_main_thread+0x1f1c>  // b.none
    a488:	29430065 	ldp	w5, w0, [x3, #24]
    a48c:	9b057c21 	mul	x1, x1, x5
    a490:	eb41801f 	cmp	x0, x1, lsr #32
    a494:	54ff7669 	b.ls	9360 <fwp_main_thread+0xdc0>  // b.plast
    a498:	aa0203e0 	mov	x0, x2
    a49c:	97ffe7d5 	bl	43f0 <fwp_mem_free>
    a4a0:	17fffbb0 	b	9360 <fwp_main_thread+0xdc0>
    a4a4:	f2403c21 	ands	x1, x1, #0xffff
    a4a8:	54ff75c1 	b.ne	9360 <fwp_main_thread+0xdc0>  // b.any
    a4ac:	17fffba5 	b	9340 <fwp_main_thread+0xda0>
    a4b0:	aa1c03e0 	mov	x0, x28
    a4b4:	97ffe733 	bl	4180 <fwp_rc_forget_slot.part.0>
    a4b8:	17ffffec 	b	a468 <fwp_main_thread+0x1ec8>
    a4bc:	b5ff7521 	cbnz	x1, 9360 <fwp_main_thread+0xdc0>
    a4c0:	17fffff6 	b	a498 <fwp_main_thread+0x1ef8>
    a4c4:	f9400442 	ldr	x2, [x2, #8]
    a4c8:	710008df 	cmp	w6, #0x2
    a4cc:	54000e60 	b.eq	a698 <fwp_main_thread+0x20f8>  // b.none
    a4d0:	29430c65 	ldp	w5, w3, [x3, #24]
    a4d4:	9b057c21 	mul	x1, x1, x5
    a4d8:	eb41807f 	cmp	x3, x1, lsr #32
    a4dc:	54ff7049 	b.ls	92e4 <fwp_main_thread+0xd44>  // b.plast
    a4e0:	a9039fe2 	stp	x2, x7, [sp, #56]
    a4e4:	97ffe7c3 	bl	43f0 <fwp_mem_free>
    a4e8:	d2800508 	mov	x8, #0x28                  	// #40
    a4ec:	a9439fe2 	ldp	x2, x7, [sp, #56]
    a4f0:	17fffb7d 	b	92e4 <fwp_main_thread+0xd44>
    a4f4:	f9001be0 	str	x0, [sp, #48]
    a4f8:	a9040be3 	stp	x3, x2, [sp, #64]
    a4fc:	a90517e6 	stp	x6, x5, [sp, #80]
    a500:	97ffe720 	bl	4180 <fwp_rc_forget_slot.part.0>
    a504:	f9401be0 	ldr	x0, [sp, #48]
    a508:	a9440be3 	ldp	x3, x2, [sp, #64]
    a50c:	a94517e6 	ldp	x6, x5, [sp, #80]
    a510:	17ffff69 	b	a2b4 <fwp_main_thread+0x1d14>
    a514:	ca404401 	eor	x1, x0, x0, lsr #17
    a518:	91170263 	add	x3, x19, #0x5c0
    a51c:	ca412421 	eor	x1, x1, x1, lsr #9
    a520:	92401c21 	and	x1, x1, #0xff
    a524:	910a2422 	add	x2, x1, #0x289
    a528:	8b010c61 	add	x1, x3, x1, lsl #3
    a52c:	8b020c62 	add	x2, x3, x2, lsl #3
    a530:	f94a2421 	ldr	x1, [x1, #5192]
    a534:	b4ffbc61 	cbz	x1, 9cc0 <fwp_main_thread+0x1720>
    a538:	f9400023 	ldr	x3, [x1]
    a53c:	eb00007f 	cmp	x3, x0
    a540:	54000260 	b.eq	a58c <fwp_main_thread+0x1fec>  // b.none
    a544:	91004022 	add	x2, x1, #0x10
    a548:	f9400821 	ldr	x1, [x1, #16]
    a54c:	17fffffa 	b	a534 <fwp_main_thread+0x1f94>
    a550:	ca404401 	eor	x1, x0, x0, lsr #17
    a554:	91170263 	add	x3, x19, #0x5c0
    a558:	ca412421 	eor	x1, x1, x1, lsr #9
    a55c:	92401c21 	and	x1, x1, #0xff
    a560:	910a2422 	add	x2, x1, #0x289
    a564:	8b010c61 	add	x1, x3, x1, lsl #3
    a568:	8b020c62 	add	x2, x3, x2, lsl #3
    a56c:	f94a2421 	ldr	x1, [x1, #5192]
    a570:	b4ffba81 	cbz	x1, 9cc0 <fwp_main_thread+0x1720>
    a574:	f9400023 	ldr	x3, [x1]
    a578:	eb00007f 	cmp	x3, x0
    a57c:	54000260 	b.eq	a5c8 <fwp_main_thread+0x2028>  // b.none
    a580:	91004022 	add	x2, x1, #0x10
    a584:	f9400821 	ldr	x1, [x1, #16]
    a588:	17fffffa 	b	a570 <fwp_main_thread+0x1fd0>
    a58c:	f9400042 	ldr	x2, [x2]
    a590:	f9400441 	ldr	x1, [x2, #8]
    a594:	d1000421 	sub	x1, x1, #0x1
    a598:	f9000441 	str	x1, [x2, #8]
    a59c:	f103f83f 	cmp	x1, #0xfe
    a5a0:	54ff6e01 	b.ne	9360 <fwp_main_thread+0xdc0>  // b.any
    a5a4:	39400001 	ldrb	w1, [x0]
    a5a8:	7103fc3f 	cmp	w1, #0xff
    a5ac:	54000081 	b.ne	a5bc <fwp_main_thread+0x201c>  // b.any
    a5b0:	f9001fe0 	str	x0, [sp, #56]
    a5b4:	97ffe6f3 	bl	4180 <fwp_rc_forget_slot.part.0>
    a5b8:	f9401fe0 	ldr	x0, [sp, #56]
    a5bc:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a5c0:	39000001 	strb	w1, [x0]
    a5c4:	17fffb67 	b	9360 <fwp_main_thread+0xdc0>
    a5c8:	f9400042 	ldr	x2, [x2]
    a5cc:	f9400441 	ldr	x1, [x2, #8]
    a5d0:	d1000421 	sub	x1, x1, #0x1
    a5d4:	f9000441 	str	x1, [x2, #8]
    a5d8:	f103f83f 	cmp	x1, #0xfe
    a5dc:	54ff7061 	b.ne	93e8 <fwp_main_thread+0xe48>  // b.any
    a5e0:	39400001 	ldrb	w1, [x0]
    a5e4:	7103fc3f 	cmp	w1, #0xff
    a5e8:	540002c0 	b.eq	a640 <fwp_main_thread+0x20a0>  // b.none
    a5ec:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a5f0:	39000001 	strb	w1, [x0]
    a5f4:	17fffb7d 	b	93e8 <fwp_main_thread+0xe48>
    a5f8:	f9401be2 	ldr	x2, [sp, #48]
    a5fc:	aa0203e0 	mov	x0, x2
    a600:	f9400842 	ldr	x2, [x2, #16]
    a604:	f9001be2 	str	x2, [sp, #48]
    a608:	710008bf 	cmp	w5, #0x2
    a60c:	54000220 	b.eq	a650 <fwp_main_thread+0x20b0>  // b.none
    a610:	29430865 	ldp	w5, w2, [x3, #24]
    a614:	9b057c21 	mul	x1, x1, x5
    a618:	eb41805f 	cmp	x2, x1, lsr #32
    a61c:	54ff6a69 	b.ls	9368 <fwp_main_thread+0xdc8>  // b.plast
    a620:	f9001fe6 	str	x6, [sp, #56]
    a624:	97ffe773 	bl	43f0 <fwp_mem_free>
    a628:	f9401fe6 	ldr	x6, [sp, #56]
    a62c:	d2800507 	mov	x7, #0x28                  	// #40
    a630:	17fffb4e 	b	9368 <fwp_main_thread+0xdc8>
    a634:	f2403c21 	ands	x1, x1, #0xffff
    a638:	54ff6d81 	b.ne	93e8 <fwp_main_thread+0xe48>  // b.any
    a63c:	17fffb63 	b	93c8 <fwp_main_thread+0xe28>
    a640:	f9001be0 	str	x0, [sp, #48]
    a644:	97ffe6cf 	bl	4180 <fwp_rc_forget_slot.part.0>
    a648:	f9401be0 	ldr	x0, [sp, #48]
    a64c:	17ffffe8 	b	a5ec <fwp_main_thread+0x204c>
    a650:	b5ff68c1 	cbnz	x1, 9368 <fwp_main_thread+0xdc8>
    a654:	17fffff3 	b	a620 <fwp_main_thread+0x2080>
    a658:	a9038fe0 	stp	x0, x3, [sp, #56]
    a65c:	a9049fe2 	stp	x2, x7, [sp, #72]
    a660:	f9002fe8 	str	x8, [sp, #88]
    a664:	97ffe6c7 	bl	4180 <fwp_rc_forget_slot.part.0>
    a668:	a9438fe0 	ldp	x0, x3, [sp, #56]
    a66c:	a9449fe2 	ldp	x2, x7, [sp, #72]
    a670:	f9402fe8 	ldr	x8, [sp, #88]
    a674:	17ffff4e 	b	a3ac <fwp_main_thread+0x1e0c>
    a678:	72003c3f 	tst	w1, #0xffff
    a67c:	54ffe920 	b.eq	a3a0 <fwp_main_thread+0x1e00>  // b.none
    a680:	d10004e7 	sub	x7, x7, #0x1
    a684:	17ffff23 	b	a310 <fwp_main_thread+0x1d70>
    a688:	72003c3f 	tst	w1, #0xffff
    a68c:	54ffe0e0 	b.eq	a2a8 <fwp_main_thread+0x1d08>  // b.none
    a690:	d10004a5 	sub	x5, x5, #0x1
    a694:	17fffedd 	b	a208 <fwp_main_thread+0x1c68>
    a698:	b5ff6261 	cbnz	x1, 92e4 <fwp_main_thread+0xd44>
    a69c:	17ffff91 	b	a4e0 <fwp_main_thread+0x1f40>
    a6a0:	72003c1f 	tst	w0, #0xffff
    a6a4:	54ffd2a0 	b.eq	a0f8 <fwp_main_thread+0x1b58>  // b.none
    a6a8:	aa1803fc 	mov	x28, x24
    a6ac:	d2800006 	mov	x6, #0x0                   	// #0
    a6b0:	b400011c 	cbz	x28, a6d0 <fwp_main_thread+0x2130>
    a6b4:	f9400b9c 	ldr	x28, [x28, #16]
    a6b8:	910004c6 	add	x6, x6, #0x1
    a6bc:	17fffffd 	b	a6b0 <fwp_main_thread+0x2110>
    a6c0:	72003c3f 	tst	w1, #0xffff
    a6c4:	54ffcd40 	b.eq	a06c <fwp_main_thread+0x1acc>  // b.none
    a6c8:	aa1c03e0 	mov	x0, x28
    a6cc:	17fffe1f 	b	9f48 <fwp_main_thread+0x19a8>
    a6d0:	a9038be5 	stp	x5, x2, [sp, #56]
    a6d4:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    a6d8:	eb0000df 	cmp	x6, x0
    a6dc:	54ff5b88 	b.hi	924c <fwp_main_thread+0xcac>  // b.pmore
    a6e0:	910004c0 	add	x0, x6, #0x1
    a6e4:	52800041 	mov	w1, #0x2                   	// #2
    a6e8:	f9001be6 	str	x6, [sp, #48]
    a6ec:	d37df000 	lsl	x0, x0, #3
    a6f0:	97ffe9fc 	bl	4ee0 <fwp_heap_alloc>
    a6f4:	a94317e6 	ldp	x6, x5, [sp, #48]
    a6f8:	aa1803e1 	mov	x1, x24
    a6fc:	f94023e2 	ldr	x2, [sp, #64]
    a700:	aa0003e3 	mov	x3, x0
    a704:	b4000561 	cbz	x1, a7b0 <fwp_main_thread+0x2210>
    a708:	f9400420 	ldr	x0, [x1, #8]
    a70c:	f83c7860 	str	x0, [x3, x28, lsl #3]
    a710:	9100079c 	add	x28, x28, #0x1
    a714:	f9400821 	ldr	x1, [x1, #16]
    a718:	17fffffb 	b	a704 <fwp_main_thread+0x2164>
    a71c:	f9001be0 	str	x0, [sp, #48]
    a720:	97ffe698 	bl	4180 <fwp_rc_forget_slot.part.0>
    a724:	f9401be0 	ldr	x0, [sp, #48]
    a728:	17fffddc 	b	9e98 <fwp_main_thread+0x18f8>
    a72c:	72003c3f 	tst	w1, #0xffff
    a730:	54ffbb81 	b.ne	9ea0 <fwp_main_thread+0x1900>  // b.any
    a734:	17fffdd6 	b	9e8c <fwp_main_thread+0x18ec>
    a738:	f9010bf9 	str	x25, [sp, #528]
    a73c:	f9010ffa 	str	x26, [sp, #536]
    a740:	f90113fb 	str	x27, [sp, #544]
    a744:	f90117fc 	str	x28, [sp, #552]
    a748:	97ffe27a 	bl	3130 <descent_phase_fail>
    a74c:	f9010bf9 	str	x25, [sp, #528]
    a750:	f9010ffa 	str	x26, [sp, #536]
    a754:	f90113fb 	str	x27, [sp, #544]
    a758:	f90117fc 	str	x28, [sp, #552]
    a75c:	97ffe04d 	bl	2890 <__stack_chk_fail@plt>
    a760:	f9400042 	ldr	x2, [x2]
    a764:	f9400441 	ldr	x1, [x2, #8]
    a768:	d1000421 	sub	x1, x1, #0x1
    a76c:	f9000441 	str	x1, [x2, #8]
    a770:	f103f83f 	cmp	x1, #0xfe
    a774:	54ff8541 	b.ne	981c <fwp_main_thread+0x127c>  // b.any
    a778:	39400001 	ldrb	w1, [x0]
    a77c:	7103fc3f 	cmp	w1, #0xff
    a780:	540001c0 	b.eq	a7b8 <fwp_main_thread+0x2218>  // b.none
    a784:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a788:	39000001 	strb	w1, [x0]
    a78c:	17fffc24 	b	981c <fwp_main_thread+0x127c>
    a790:	aa0203e0 	mov	x0, x2
    a794:	d2800101 	mov	x1, #0x8                   	// #8
    a798:	f9001be2 	str	x2, [sp, #48]
    a79c:	97ffe035 	bl	2870 <calloc@plt>
    a7a0:	f9401be2 	ldr	x2, [sp, #48]
    a7a4:	aa0003e3 	mov	x3, x0
    a7a8:	a94497e6 	ldp	x6, x5, [sp, #72]
    a7ac:	17fffd07 	b	9bc8 <fwp_main_thread+0x1628>
    a7b0:	b9003bff 	str	wzr, [sp, #56]
    a7b4:	17fffe56 	b	a10c <fwp_main_thread+0x1b6c>
    a7b8:	f9001be0 	str	x0, [sp, #48]
    a7bc:	97ffe671 	bl	4180 <fwp_rc_forget_slot.part.0>
    a7c0:	f9401be0 	ldr	x0, [sp, #48]
    a7c4:	17fffff0 	b	a784 <fwp_main_thread+0x21e4>
    a7c8:	97ffe0ae 	bl	2a80 <fwp_trap_overflow.constprop.0>
    a7cc:	f9010bf9 	str	x25, [sp, #528]
    a7d0:	f9010ffa 	str	x26, [sp, #536]
    a7d4:	f90113fb 	str	x27, [sp, #544]
    a7d8:	f90117fc 	str	x28, [sp, #552]
    a7dc:	97ffe041 	bl	28e0 <abort@plt>

000000000000a7e0 <__divti3>:
    a7e0:	d503245f 	bti	c
    a7e4:	d2800004 	mov	x4, #0x0                   	// #0
    a7e8:	b7f80721 	tbnz	x1, #63, a8cc <__divti3+0xec>
    a7ec:	b6f80083 	tbz	x3, #63, a7fc <__divti3+0x1c>
    a7f0:	eb0203e2 	negs	x2, x2
    a7f4:	aa2403e4 	mvn	x4, x4
    a7f8:	da0303e3 	ngc	x3, x3
    a7fc:	aa0203e6 	mov	x6, x2
    a800:	aa0003e7 	mov	x7, x0
    a804:	aa0103e5 	mov	x5, x1
    a808:	b5000583 	cbnz	x3, a8b8 <__divti3+0xd8>
    a80c:	eb01005f 	cmp	x2, x1
    a810:	54000e69 	b.ls	a9dc <__divti3+0x1fc>  // b.plast
    a814:	dac01040 	clz	x0, x2
    a818:	b40000e0 	cbz	x0, a834 <__divti3+0x54>
    a81c:	4b0003e1 	neg	w1, w0
    a820:	9ac020a5 	lsl	x5, x5, x0
    a824:	9ac02046 	lsl	x6, x2, x0
    a828:	9ac124e1 	lsr	x1, x7, x1
    a82c:	aa050025 	orr	x5, x1, x5
    a830:	9ac020e7 	lsl	x7, x7, x0
    a834:	d360fcc8 	lsr	x8, x6, #32
    a838:	92407cc2 	and	x2, x6, #0xffffffff
    a83c:	9ac808a3 	udiv	x3, x5, x8
    a840:	9b089465 	msub	x5, x3, x8, x5
    a844:	aa0303e0 	mov	x0, x3
    a848:	9b037c41 	mul	x1, x2, x3
    a84c:	93c780a5 	extr	x5, x5, x7, #32
    a850:	eb05003f 	cmp	x1, x5
    a854:	540000a9 	b.ls	a868 <__divti3+0x88>  // b.plast
    a858:	ab0500c5 	adds	x5, x6, x5
    a85c:	d1000460 	sub	x0, x3, #0x1
    a860:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a864:	540015a8 	b.hi	ab18 <__divti3+0x338>  // b.pmore
    a868:	cb0100a5 	sub	x5, x5, x1
    a86c:	9ac808a3 	udiv	x3, x5, x8
    a870:	9b089465 	msub	x5, x3, x8, x5
    a874:	aa0303e1 	mov	x1, x3
    a878:	9b037c42 	mul	x2, x2, x3
    a87c:	aa0703e3 	mov	x3, x7
    a880:	b3607ca3 	bfi	x3, x5, #32, #32
    a884:	eb03005f 	cmp	x2, x3
    a888:	540000c9 	b.ls	a8a0 <__divti3+0xc0>  // b.plast
    a88c:	ab0300c3 	adds	x3, x6, x3
    a890:	d1000425 	sub	x5, x1, #0x1
    a894:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a898:	d1000821 	sub	x1, x1, #0x2
    a89c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a8a0:	aa008020 	orr	x0, x1, x0, lsl #32
    a8a4:	d2800001 	mov	x1, #0x0                   	// #0
    a8a8:	b4000064 	cbz	x4, a8b4 <__divti3+0xd4>
    a8ac:	eb0003e0 	negs	x0, x0
    a8b0:	da0103e1 	ngc	x1, x1
    a8b4:	d65f03c0 	ret
    a8b8:	eb01007f 	cmp	x3, x1
    a8bc:	54000109 	b.ls	a8dc <__divti3+0xfc>  // b.plast
    a8c0:	d2800001 	mov	x1, #0x0                   	// #0
    a8c4:	d2800000 	mov	x0, #0x0                   	// #0
    a8c8:	17fffff8 	b	a8a8 <__divti3+0xc8>
    a8cc:	eb0003e0 	negs	x0, x0
    a8d0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a8d4:	da0103e1 	ngc	x1, x1
    a8d8:	17ffffc5 	b	a7ec <__divti3+0xc>
    a8dc:	dac01067 	clz	x7, x3
    a8e0:	b40010e7 	cbz	x7, aafc <__divti3+0x31c>
    a8e4:	d2800805 	mov	x5, #0x40                  	// #64
    a8e8:	cb0700a5 	sub	x5, x5, x7
    a8ec:	9ac72063 	lsl	x3, x3, x7
    a8f0:	9ac52448 	lsr	x8, x2, x5
    a8f4:	aa030108 	orr	x8, x8, x3
    a8f8:	9ac52426 	lsr	x6, x1, x5
    a8fc:	92407d0a 	and	x10, x8, #0xffffffff
    a900:	d360fd09 	lsr	x9, x8, #32
    a904:	9ac52403 	lsr	x3, x0, x5
    a908:	9ac72021 	lsl	x1, x1, x7
    a90c:	aa010063 	orr	x3, x3, x1
    a910:	9ac72042 	lsl	x2, x2, x7
    a914:	9ac908cb 	udiv	x11, x6, x9
    a918:	9b099965 	msub	x5, x11, x9, x6
    a91c:	aa0b03e1 	mov	x1, x11
    a920:	9b0b7d46 	mul	x6, x10, x11
    a924:	93c380a5 	extr	x5, x5, x3, #32
    a928:	eb0500df 	cmp	x6, x5
    a92c:	540000a9 	b.ls	a940 <__divti3+0x160>  // b.plast
    a930:	ab050105 	adds	x5, x8, x5
    a934:	d1000561 	sub	x1, x11, #0x1
    a938:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a93c:	54000f48 	b.hi	ab24 <__divti3+0x344>  // b.pmore
    a940:	cb0600a6 	sub	x6, x5, x6
    a944:	9ac908cb 	udiv	x11, x6, x9
    a948:	9b099969 	msub	x9, x11, x9, x6
    a94c:	aa0b03e5 	mov	x5, x11
    a950:	9b0b7d4a 	mul	x10, x10, x11
    a954:	b3607d23 	bfi	x3, x9, #32, #32
    a958:	eb03015f 	cmp	x10, x3
    a95c:	540000a9 	b.ls	a970 <__divti3+0x190>  // b.plast
    a960:	ab030103 	adds	x3, x8, x3
    a964:	d1000565 	sub	x5, x11, #0x1
    a968:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a96c:	54000e28 	b.hi	ab30 <__divti3+0x350>  // b.pmore
    a970:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a974:	92407c48 	and	x8, x2, #0xffffffff
    a978:	2a0503e5 	mov	w5, w5
    a97c:	d360fc42 	lsr	x2, x2, #32
    a980:	d360fc26 	lsr	x6, x1, #32
    a984:	cb0a0063 	sub	x3, x3, x10
    a988:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a98c:	9b087caa 	mul	x10, x5, x8
    a990:	9b087cc8 	mul	x8, x6, x8
    a994:	9b0220a5 	madd	x5, x5, x2, x8
    a998:	9b027cc6 	mul	x6, x6, x2
    a99c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a9a0:	8b0900c5 	add	x5, x6, x9
    a9a4:	eb02011f 	cmp	x8, x2
    a9a8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a9ac:	8b4280c6 	add	x6, x6, x2, lsr #32
    a9b0:	eb06007f 	cmp	x3, x6
    a9b4:	540000e3 	b.cc	a9d0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a9b8:	92407d4a 	and	x10, x10, #0xffffffff
    a9bc:	9ac72000 	lsl	x0, x0, x7
    a9c0:	8b028142 	add	x2, x10, x2, lsl #32
    a9c4:	eb02001f 	cmp	x0, x2
    a9c8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a9cc:	54000a01 	b.ne	ab0c <__divti3+0x32c>  // b.any
    a9d0:	d1000420 	sub	x0, x1, #0x1
    a9d4:	d2800001 	mov	x1, #0x0                   	// #0
    a9d8:	17ffffb4 	b	a8a8 <__divti3+0xc8>
    a9dc:	b5000062 	cbnz	x2, a9e8 <__divti3+0x208>
    a9e0:	d2800022 	mov	x2, #0x1                   	// #1
    a9e4:	9ac30846 	udiv	x6, x2, x3
    a9e8:	dac010c8 	clz	x8, x6
    a9ec:	b5000408 	cbnz	x8, aa6c <__divti3+0x28c>
    a9f0:	d360fcc9 	lsr	x9, x6, #32
    a9f4:	92407cc5 	and	x5, x6, #0xffffffff
    a9f8:	cb060023 	sub	x3, x1, x6
    a9fc:	d2800021 	mov	x1, #0x1                   	// #1
    aa00:	9ac90868 	udiv	x8, x3, x9
    aa04:	9b098d03 	msub	x3, x8, x9, x3
    aa08:	aa0803e0 	mov	x0, x8
    aa0c:	9b057d02 	mul	x2, x8, x5
    aa10:	93c78063 	extr	x3, x3, x7, #32
    aa14:	eb03005f 	cmp	x2, x3
    aa18:	540000a9 	b.ls	aa2c <__divti3+0x24c>  // b.plast
    aa1c:	ab0300c3 	adds	x3, x6, x3
    aa20:	d1000500 	sub	x0, x8, #0x1
    aa24:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    aa28:	54000968 	b.hi	ab54 <__divti3+0x374>  // b.pmore
    aa2c:	cb020063 	sub	x3, x3, x2
    aa30:	9ac90862 	udiv	x2, x3, x9
    aa34:	aa0203e8 	mov	x8, x2
    aa38:	9b098c42 	msub	x2, x2, x9, x3
    aa3c:	aa0703e3 	mov	x3, x7
    aa40:	9b057d05 	mul	x5, x8, x5
    aa44:	b3607c43 	bfi	x3, x2, #32, #32
    aa48:	eb0300bf 	cmp	x5, x3
    aa4c:	540000c9 	b.ls	aa64 <__divti3+0x284>  // b.plast
    aa50:	ab0300c2 	adds	x2, x6, x3
    aa54:	d1000503 	sub	x3, x8, #0x1
    aa58:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    aa5c:	d1000908 	sub	x8, x8, #0x2
    aa60:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    aa64:	aa008100 	orr	x0, x8, x0, lsl #32
    aa68:	17ffff90 	b	a8a8 <__divti3+0xc8>
    aa6c:	9ac820c6 	lsl	x6, x6, x8
    aa70:	d2800803 	mov	x3, #0x40                  	// #64
    aa74:	cb080063 	sub	x3, x3, x8
    aa78:	d360fcc9 	lsr	x9, x6, #32
    aa7c:	9ac82027 	lsl	x7, x1, x8
    aa80:	92407cc5 	and	x5, x6, #0xffffffff
    aa84:	9ac32422 	lsr	x2, x1, x3
    aa88:	9ac32403 	lsr	x3, x0, x3
    aa8c:	aa070063 	orr	x3, x3, x7
    aa90:	9ac9084a 	udiv	x10, x2, x9
    aa94:	9ac82007 	lsl	x7, x0, x8
    aa98:	9b098940 	msub	x0, x10, x9, x2
    aa9c:	aa0a03e1 	mov	x1, x10
    aaa0:	9b0a7ca2 	mul	x2, x5, x10
    aaa4:	93c38000 	extr	x0, x0, x3, #32
    aaa8:	eb00005f 	cmp	x2, x0
    aaac:	540000a9 	b.ls	aac0 <__divti3+0x2e0>  // b.plast
    aab0:	ab0000c0 	adds	x0, x6, x0
    aab4:	d1000541 	sub	x1, x10, #0x1
    aab8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    aabc:	54000468 	b.hi	ab48 <__divti3+0x368>  // b.pmore
    aac0:	cb020000 	sub	x0, x0, x2
    aac4:	9ac9080a 	udiv	x10, x0, x9
    aac8:	9b098140 	msub	x0, x10, x9, x0
    aacc:	aa0a03e2 	mov	x2, x10
    aad0:	9b0a7ca8 	mul	x8, x5, x10
    aad4:	b3607c03 	bfi	x3, x0, #32, #32
    aad8:	eb03011f 	cmp	x8, x3
    aadc:	540000a9 	b.ls	aaf0 <__divti3+0x310>  // b.plast
    aae0:	ab0300c3 	adds	x3, x6, x3
    aae4:	d1000542 	sub	x2, x10, #0x1
    aae8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    aaec:	54000288 	b.hi	ab3c <__divti3+0x35c>  // b.pmore
    aaf0:	cb080063 	sub	x3, x3, x8
    aaf4:	aa018041 	orr	x1, x2, x1, lsl #32
    aaf8:	17ffffc2 	b	aa00 <__divti3+0x220>
    aafc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    ab00:	d2800001 	mov	x1, #0x0                   	// #0
    ab04:	9a9f87e0 	cset	x0, ls	// ls = plast
    ab08:	17ffff68 	b	a8a8 <__divti3+0xc8>
    ab0c:	aa0103e0 	mov	x0, x1
    ab10:	d2800001 	mov	x1, #0x0                   	// #0
    ab14:	17ffff65 	b	a8a8 <__divti3+0xc8>
    ab18:	d1000860 	sub	x0, x3, #0x2
    ab1c:	8b0600a5 	add	x5, x5, x6
    ab20:	17ffff52 	b	a868 <__divti3+0x88>
    ab24:	d1000961 	sub	x1, x11, #0x2
    ab28:	8b0800a5 	add	x5, x5, x8
    ab2c:	17ffff85 	b	a940 <__divti3+0x160>
    ab30:	d1000965 	sub	x5, x11, #0x2
    ab34:	8b080063 	add	x3, x3, x8
    ab38:	17ffff8e 	b	a970 <__divti3+0x190>
    ab3c:	d1000942 	sub	x2, x10, #0x2
    ab40:	8b060063 	add	x3, x3, x6
    ab44:	17ffffeb 	b	aaf0 <__divti3+0x310>
    ab48:	d1000941 	sub	x1, x10, #0x2
    ab4c:	8b060000 	add	x0, x0, x6
    ab50:	17ffffdc 	b	aac0 <__divti3+0x2e0>
    ab54:	d1000900 	sub	x0, x8, #0x2
    ab58:	8b060063 	add	x3, x3, x6
    ab5c:	17ffffb4 	b	aa2c <__divti3+0x24c>

000000000000ab60 <__modti3>:
    ab60:	d503245f 	bti	c
    ab64:	d2800004 	mov	x4, #0x0                   	// #0
    ab68:	b6f80081 	tbz	x1, #63, ab78 <__modti3+0x18>
    ab6c:	eb0003e0 	negs	x0, x0
    ab70:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ab74:	da0103e1 	ngc	x1, x1
    ab78:	f100007f 	cmp	x3, #0x0
    ab7c:	5400128b 	b.lt	adcc <__modti3+0x26c>  // b.tstop
    ab80:	aa0003e7 	mov	x7, x0
    ab84:	aa0103e6 	mov	x6, x1
    ab88:	540004e1 	b.ne	ac24 <__modti3+0xc4>  // b.any
    ab8c:	eb02003f 	cmp	x1, x2
    ab90:	54000dc2 	b.cs	ad48 <__modti3+0x1e8>  // b.hs, b.nlast
    ab94:	dac01043 	clz	x3, x2
    ab98:	aa0303e5 	mov	x5, x3
    ab9c:	b40000e3 	cbz	x3, abb8 <__modti3+0x58>
    aba0:	4b0303e6 	neg	w6, w3
    aba4:	9ac32021 	lsl	x1, x1, x3
    aba8:	9ac32042 	lsl	x2, x2, x3
    abac:	9ac62406 	lsr	x6, x0, x6
    abb0:	aa0100c6 	orr	x6, x6, x1
    abb4:	9ac32007 	lsl	x7, x0, x3
    abb8:	d360fc40 	lsr	x0, x2, #32
    abbc:	92407c43 	and	x3, x2, #0xffffffff
    abc0:	9ac008c1 	udiv	x1, x6, x0
    abc4:	9b009826 	msub	x6, x1, x0, x6
    abc8:	9b017c61 	mul	x1, x3, x1
    abcc:	93c780c6 	extr	x6, x6, x7, #32
    abd0:	eb06003f 	cmp	x1, x6
    abd4:	540000a9 	b.ls	abe8 <__modti3+0x88>  // b.plast
    abd8:	ab060046 	adds	x6, x2, x6
    abdc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    abe0:	8b0200c8 	add	x8, x6, x2
    abe4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    abe8:	cb0100c6 	sub	x6, x6, x1
    abec:	9ac008c8 	udiv	x8, x6, x0
    abf0:	9b009901 	msub	x1, x8, x0, x6
    abf4:	aa0703e0 	mov	x0, x7
    abf8:	9b087c63 	mul	x3, x3, x8
    abfc:	b3607c20 	bfi	x0, x1, #32, #32
    ac00:	eb00007f 	cmp	x3, x0
    ac04:	54001088 	b.hi	ae14 <__modti3+0x2b4>  // b.pmore
    ac08:	cb030000 	sub	x0, x0, x3
    ac0c:	9ac52400 	lsr	x0, x0, x5
    ac10:	d2800001 	mov	x1, #0x0                   	// #0
    ac14:	b4000064 	cbz	x4, ac20 <__modti3+0xc0>
    ac18:	eb0003e0 	negs	x0, x0
    ac1c:	da0103e1 	ngc	x1, x1
    ac20:	d65f03c0 	ret
    ac24:	dac01066 	clz	x6, x3
    ac28:	eb03003f 	cmp	x1, x3
    ac2c:	54ffff43 	b.cc	ac14 <__modti3+0xb4>  // b.lo, b.ul, b.last
    ac30:	93407cc5 	sxtw	x5, w6
    ac34:	d2800808 	mov	x8, #0x40                  	// #64
    ac38:	cb050108 	sub	x8, x8, x5
    ac3c:	9ac62063 	lsl	x3, x3, x6
    ac40:	9ac62025 	lsl	x5, x1, x6
    ac44:	9ac82447 	lsr	x7, x2, x8
    ac48:	aa0300e7 	orr	x7, x7, x3
    ac4c:	9ac82423 	lsr	x3, x1, x8
    ac50:	92407cec 	and	x12, x7, #0xffffffff
    ac54:	d360fcea 	lsr	x10, x7, #32
    ac58:	9ac82401 	lsr	x1, x0, x8
    ac5c:	aa050021 	orr	x1, x1, x5
    ac60:	9ac62042 	lsl	x2, x2, x6
    ac64:	9ac62000 	lsl	x0, x0, x6
    ac68:	9aca086b 	udiv	x11, x3, x10
    ac6c:	9b0a8d63 	msub	x3, x11, x10, x3
    ac70:	aa0b03e5 	mov	x5, x11
    ac74:	9b0b7d89 	mul	x9, x12, x11
    ac78:	93c18063 	extr	x3, x3, x1, #32
    ac7c:	eb03013f 	cmp	x9, x3
    ac80:	540000a9 	b.ls	ac94 <__modti3+0x134>  // b.plast
    ac84:	ab0300e3 	adds	x3, x7, x3
    ac88:	d1000565 	sub	x5, x11, #0x1
    ac8c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ac90:	54001168 	b.hi	aebc <__modti3+0x35c>  // b.pmore
    ac94:	cb090063 	sub	x3, x3, x9
    ac98:	9aca086b 	udiv	x11, x3, x10
    ac9c:	9b0a8d6a 	msub	x10, x11, x10, x3
    aca0:	aa0b03e9 	mov	x9, x11
    aca4:	9b0b7d8c 	mul	x12, x12, x11
    aca8:	b3607d41 	bfi	x1, x10, #32, #32
    acac:	eb01019f 	cmp	x12, x1
    acb0:	540000a9 	b.ls	acc4 <__modti3+0x164>  // b.plast
    acb4:	ab0100e1 	adds	x1, x7, x1
    acb8:	d1000569 	sub	x9, x11, #0x1
    acbc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    acc0:	54000f88 	b.hi	aeb0 <__modti3+0x350>  // b.pmore
    acc4:	aa058123 	orr	x3, x9, x5, lsl #32
    acc8:	92407c4b 	and	x11, x2, #0xffffffff
    accc:	2a0903e9 	mov	w9, w9
    acd0:	d360fc4a 	lsr	x10, x2, #32
    acd4:	d360fc63 	lsr	x3, x3, #32
    acd8:	cb0c0021 	sub	x1, x1, x12
    acdc:	aa0a03ec 	mov	x12, x10
    ace0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    ace4:	9b0b7d25 	mul	x5, x9, x11
    ace8:	9b0b7c6b 	mul	x11, x3, x11
    acec:	9b0a2d29 	madd	x9, x9, x10, x11
    acf0:	92407caa 	and	x10, x5, #0xffffffff
    acf4:	9b0c7c63 	mul	x3, x3, x12
    acf8:	8b458125 	add	x5, x9, x5, lsr #32
    acfc:	8b0d0069 	add	x9, x3, x13
    ad00:	eb05017f 	cmp	x11, x5
    ad04:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    ad08:	8b058149 	add	x9, x10, x5, lsl #32
    ad0c:	8b458063 	add	x3, x3, x5, lsr #32
    ad10:	eb03003f 	cmp	x1, x3
    ad14:	54000063 	b.cc	ad20 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    ad18:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    ad1c:	54000082 	b.cs	ad2c <__modti3+0x1cc>  // b.hs, b.nlast
    ad20:	eb020129 	subs	x9, x9, x2
    ad24:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    ad28:	cb070063 	sub	x3, x3, x7
    ad2c:	eb090000 	subs	x0, x0, x9
    ad30:	da030021 	sbc	x1, x1, x3
    ad34:	9ac62400 	lsr	x0, x0, x6
    ad38:	9ac82028 	lsl	x8, x1, x8
    ad3c:	aa000100 	orr	x0, x8, x0
    ad40:	9ac62421 	lsr	x1, x1, x6
    ad44:	17ffffb4 	b	ac14 <__modti3+0xb4>
    ad48:	b5000062 	cbnz	x2, ad54 <__modti3+0x1f4>
    ad4c:	d2800023 	mov	x3, #0x1                   	// #1
    ad50:	9ac20862 	udiv	x2, x3, x2
    ad54:	dac01048 	clz	x8, x2
    ad58:	aa0803e5 	mov	x5, x8
    ad5c:	b5000668 	cbnz	x8, ae28 <__modti3+0x2c8>
    ad60:	cb020020 	sub	x0, x1, x2
    ad64:	d360fc49 	lsr	x9, x2, #32
    ad68:	92407c4a 	and	x10, x2, #0xffffffff
    ad6c:	9ac90801 	udiv	x1, x0, x9
    ad70:	9b098020 	msub	x0, x1, x9, x0
    ad74:	9b0a7c21 	mul	x1, x1, x10
    ad78:	93c78000 	extr	x0, x0, x7, #32
    ad7c:	eb00003f 	cmp	x1, x0
    ad80:	540000a9 	b.ls	ad94 <__modti3+0x234>  // b.plast
    ad84:	ab000040 	adds	x0, x2, x0
    ad88:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ad8c:	8b020003 	add	x3, x0, x2
    ad90:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ad94:	cb010001 	sub	x1, x0, x1
    ad98:	9ac90820 	udiv	x0, x1, x9
    ad9c:	9b098403 	msub	x3, x0, x9, x1
    ada0:	aa0703e1 	mov	x1, x7
    ada4:	9b0a7c00 	mul	x0, x0, x10
    ada8:	b3607c61 	bfi	x1, x3, #32, #32
    adac:	eb01001f 	cmp	x0, x1
    adb0:	540000a9 	b.ls	adc4 <__modti3+0x264>  // b.plast
    adb4:	ab010041 	adds	x1, x2, x1
    adb8:	8b020022 	add	x2, x1, x2
    adbc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    adc0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    adc4:	cb000020 	sub	x0, x1, x0
    adc8:	17ffff91 	b	ac0c <__modti3+0xac>
    adcc:	eb0203e5 	negs	x5, x2
    add0:	aa0003e7 	mov	x7, x0
    add4:	da0303e8 	ngc	x8, x3
    add8:	aa0503e2 	mov	x2, x5
    addc:	aa0803e3 	mov	x3, x8
    ade0:	aa0103e6 	mov	x6, x1
    ade4:	b4ffed48 	cbz	x8, ab8c <__modti3+0x2c>
    ade8:	eb01011f 	cmp	x8, x1
    adec:	54fff148 	b.hi	ac14 <__modti3+0xb4>  // b.pmore
    adf0:	dac01109 	clz	x9, x8
    adf4:	2a0903e6 	mov	w6, w9
    adf8:	b5fff1c9 	cbnz	x9, ac30 <__modti3+0xd0>
    adfc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    ae00:	54000068 	b.hi	ae0c <__modti3+0x2ac>  // b.pmore
    ae04:	eb050007 	subs	x7, x0, x5
    ae08:	da080021 	sbc	x1, x1, x8
    ae0c:	aa0703e0 	mov	x0, x7
    ae10:	17ffff81 	b	ac14 <__modti3+0xb4>
    ae14:	ab000040 	adds	x0, x2, x0
    ae18:	8b020002 	add	x2, x0, x2
    ae1c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    ae20:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    ae24:	17ffff79 	b	ac08 <__modti3+0xa8>
    ae28:	9ac82042 	lsl	x2, x2, x8
    ae2c:	d2800803 	mov	x3, #0x40                  	// #64
    ae30:	cb080063 	sub	x3, x3, x8
    ae34:	d360fc49 	lsr	x9, x2, #32
    ae38:	9ac82027 	lsl	x7, x1, x8
    ae3c:	92407c4a 	and	x10, x2, #0xffffffff
    ae40:	9ac32426 	lsr	x6, x1, x3
    ae44:	9ac32403 	lsr	x3, x0, x3
    ae48:	aa070063 	orr	x3, x3, x7
    ae4c:	9ac908c1 	udiv	x1, x6, x9
    ae50:	9ac82007 	lsl	x7, x0, x8
    ae54:	9b099820 	msub	x0, x1, x9, x6
    ae58:	9b017d41 	mul	x1, x10, x1
    ae5c:	93c38000 	extr	x0, x0, x3, #32
    ae60:	eb00003f 	cmp	x1, x0
    ae64:	540000a9 	b.ls	ae78 <__modti3+0x318>  // b.plast
    ae68:	ab000040 	adds	x0, x2, x0
    ae6c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ae70:	8b020006 	add	x6, x0, x2
    ae74:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    ae78:	cb010000 	sub	x0, x0, x1
    ae7c:	9ac90801 	udiv	x1, x0, x9
    ae80:	9b098026 	msub	x6, x1, x9, x0
    ae84:	aa0303e0 	mov	x0, x3
    ae88:	9b017d41 	mul	x1, x10, x1
    ae8c:	b3607cc0 	bfi	x0, x6, #32, #32
    ae90:	eb00003f 	cmp	x1, x0
    ae94:	540000a9 	b.ls	aea8 <__modti3+0x348>  // b.plast
    ae98:	ab000040 	adds	x0, x2, x0
    ae9c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    aea0:	8b020003 	add	x3, x0, x2
    aea4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    aea8:	cb010000 	sub	x0, x0, x1
    aeac:	17ffffb0 	b	ad6c <__modti3+0x20c>
    aeb0:	d1000969 	sub	x9, x11, #0x2
    aeb4:	8b070021 	add	x1, x1, x7
    aeb8:	17ffff83 	b	acc4 <__modti3+0x164>
    aebc:	d1000965 	sub	x5, x11, #0x2
    aec0:	8b070063 	add	x3, x3, x7
    aec4:	17ffff74 	b	ac94 <__modti3+0x134>
    aec8:	d503201f 	nop
    aecc:	d503201f 	nop

000000000000aed0 <atexit>:
    aed0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    aed4:	d00000a2 	adrp	x2, 20000 <__data_start>
    aed8:	d2800001 	mov	x1, #0x0                   	// #0
    aedc:	910003fd 	mov	x29, sp
    aee0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    aee4:	f9400442 	ldr	x2, [x2, #8]
    aee8:	17ffde2a 	b	2790 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000aeec <_fini>:
    aeec:	d503201f 	nop
    aef0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    aef4:	910003fd 	mov	x29, sp
    aef8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    aefc:	d65f03c0 	ret
