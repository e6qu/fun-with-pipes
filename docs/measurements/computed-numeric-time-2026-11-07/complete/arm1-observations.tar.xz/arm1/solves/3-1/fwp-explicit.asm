
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1/fwp-explicit:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001310 <_init>:
    1310:	d503201f 	nop
    1314:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1318:	910003fd 	mov	x29, sp
    131c:	94000186 	bl	1934 <call_weak_fn>
    1320:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1324:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001330 <.plt>:
    1330:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1334:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1338:	f946fe11 	ldr	x17, [x16, #3576]
    133c:	9137e210 	add	x16, x16, #0xdf8
    1340:	d61f0220 	br	x17
    1344:	d503201f 	nop
    1348:	d503201f 	nop
    134c:	d503201f 	nop

0000000000001350 <memcpy@plt>:
    1350:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1354:	f9470211 	ldr	x17, [x16, #3584]
    1358:	91380210 	add	x16, x16, #0xe00
    135c:	d61f0220 	br	x17

0000000000001360 <sigaltstack@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1364:	f9470611 	ldr	x17, [x16, #3592]
    1368:	91382210 	add	x16, x16, #0xe08
    136c:	d61f0220 	br	x17

0000000000001370 <_exit@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1374:	f9470a11 	ldr	x17, [x16, #3600]
    1378:	91384210 	add	x16, x16, #0xe10
    137c:	d61f0220 	br	x17

0000000000001380 <strlen@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1384:	f9470e11 	ldr	x17, [x16, #3608]
    1388:	91386210 	add	x16, x16, #0xe18
    138c:	d61f0220 	br	x17

0000000000001390 <__sprintf_chk@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1394:	f9471211 	ldr	x17, [x16, #3616]
    1398:	91388210 	add	x16, x16, #0xe20
    139c:	d61f0220 	br	x17

00000000000013a0 <exit@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    13a4:	f9471611 	ldr	x17, [x16, #3624]
    13a8:	9138a210 	add	x16, x16, #0xe28
    13ac:	d61f0220 	br	x17

00000000000013b0 <__libc_start_main@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    13b4:	f9471a11 	ldr	x17, [x16, #3632]
    13b8:	9138c210 	add	x16, x16, #0xe30
    13bc:	d61f0220 	br	x17

00000000000013c0 <strtoll@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    13c4:	f9471e11 	ldr	x17, [x16, #3640]
    13c8:	9138e210 	add	x16, x16, #0xe38
    13cc:	d61f0220 	br	x17

00000000000013d0 <strtod@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    13d4:	f9472211 	ldr	x17, [x16, #3648]
    13d8:	91390210 	add	x16, x16, #0xe40
    13dc:	d61f0220 	br	x17

00000000000013e0 <__cxa_finalize@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    13e4:	f9472611 	ldr	x17, [x16, #3656]
    13e8:	91392210 	add	x16, x16, #0xe48
    13ec:	d61f0220 	br	x17

00000000000013f0 <__cxa_atexit@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    13f4:	f9472a11 	ldr	x17, [x16, #3664]
    13f8:	91394210 	add	x16, x16, #0xe50
    13fc:	d61f0220 	br	x17

0000000000001400 <pthread_attr_init@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1404:	f9472e11 	ldr	x17, [x16, #3672]
    1408:	91396210 	add	x16, x16, #0xe58
    140c:	d61f0220 	br	x17

0000000000001410 <fputc@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1414:	f9473211 	ldr	x17, [x16, #3680]
    1418:	91398210 	add	x16, x16, #0xe60
    141c:	d61f0220 	br	x17

0000000000001420 <clock_gettime@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1424:	f9473611 	ldr	x17, [x16, #3688]
    1428:	9139a210 	add	x16, x16, #0xe68
    142c:	d61f0220 	br	x17

0000000000001430 <setvbuf@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1434:	f9473a11 	ldr	x17, [x16, #3696]
    1438:	9139c210 	add	x16, x16, #0xe70
    143c:	d61f0220 	br	x17

0000000000001440 <__memcpy_chk@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1444:	f9473e11 	ldr	x17, [x16, #3704]
    1448:	9139e210 	add	x16, x16, #0xe78
    144c:	d61f0220 	br	x17

0000000000001450 <signal@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1454:	f9474211 	ldr	x17, [x16, #3712]
    1458:	913a0210 	add	x16, x16, #0xe80
    145c:	d61f0220 	br	x17

0000000000001460 <__snprintf_chk@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1464:	f9474611 	ldr	x17, [x16, #3720]
    1468:	913a2210 	add	x16, x16, #0xe88
    146c:	d61f0220 	br	x17

0000000000001470 <fclose@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1474:	f9474a11 	ldr	x17, [x16, #3728]
    1478:	913a4210 	add	x16, x16, #0xe90
    147c:	d61f0220 	br	x17

0000000000001480 <fopen@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1484:	f9474e11 	ldr	x17, [x16, #3736]
    1488:	913a6210 	add	x16, x16, #0xe98
    148c:	d61f0220 	br	x17

0000000000001490 <malloc@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1494:	f9475211 	ldr	x17, [x16, #3744]
    1498:	913a8210 	add	x16, x16, #0xea0
    149c:	d61f0220 	br	x17

00000000000014a0 <pthread_attr_destroy@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    14a4:	f9475611 	ldr	x17, [x16, #3752]
    14a8:	913aa210 	add	x16, x16, #0xea8
    14ac:	d61f0220 	br	x17

00000000000014b0 <sigemptyset@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    14b4:	f9475a11 	ldr	x17, [x16, #3760]
    14b8:	913ac210 	add	x16, x16, #0xeb0
    14bc:	d61f0220 	br	x17

00000000000014c0 <memset@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    14c4:	f9475e11 	ldr	x17, [x16, #3768]
    14c8:	913ae210 	add	x16, x16, #0xeb8
    14cc:	d61f0220 	br	x17

00000000000014d0 <calloc@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    14d4:	f9476211 	ldr	x17, [x16, #3776]
    14d8:	913b0210 	add	x16, x16, #0xec0
    14dc:	d61f0220 	br	x17

00000000000014e0 <realloc@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    14e4:	f9476611 	ldr	x17, [x16, #3784]
    14e8:	913b2210 	add	x16, x16, #0xec8
    14ec:	d61f0220 	br	x17

00000000000014f0 <__stack_chk_fail@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    14f4:	f9476a11 	ldr	x17, [x16, #3792]
    14f8:	913b4210 	add	x16, x16, #0xed0
    14fc:	d61f0220 	br	x17

0000000000001500 <close@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1504:	f9476e11 	ldr	x17, [x16, #3800]
    1508:	913b6210 	add	x16, x16, #0xed8
    150c:	d61f0220 	br	x17

0000000000001510 <sigaction@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1514:	f9477211 	ldr	x17, [x16, #3808]
    1518:	913b8210 	add	x16, x16, #0xee0
    151c:	d61f0220 	br	x17

0000000000001520 <__gmon_start__@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1524:	f9477611 	ldr	x17, [x16, #3816]
    1528:	913ba210 	add	x16, x16, #0xee8
    152c:	d61f0220 	br	x17

0000000000001530 <write@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1534:	f9477a11 	ldr	x17, [x16, #3824]
    1538:	913bc210 	add	x16, x16, #0xef0
    153c:	d61f0220 	br	x17

0000000000001540 <abort@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1544:	f9477e11 	ldr	x17, [x16, #3832]
    1548:	913be210 	add	x16, x16, #0xef8
    154c:	d61f0220 	br	x17

0000000000001550 <swapcontext@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1554:	f9478211 	ldr	x17, [x16, #3840]
    1558:	913c0210 	add	x16, x16, #0xf00
    155c:	d61f0220 	br	x17

0000000000001560 <__fprintf_chk@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1564:	f9478611 	ldr	x17, [x16, #3848]
    1568:	913c2210 	add	x16, x16, #0xf08
    156c:	d61f0220 	br	x17

0000000000001570 <strcmp@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1574:	f9478a11 	ldr	x17, [x16, #3856]
    1578:	913c4210 	add	x16, x16, #0xf10
    157c:	d61f0220 	br	x17

0000000000001580 <mmap@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1584:	f9478e11 	ldr	x17, [x16, #3864]
    1588:	913c6210 	add	x16, x16, #0xf18
    158c:	d61f0220 	br	x17

0000000000001590 <strtol@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1594:	f9479211 	ldr	x17, [x16, #3872]
    1598:	913c8210 	add	x16, x16, #0xf20
    159c:	d61f0220 	br	x17

00000000000015a0 <strtof@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    15a4:	f9479611 	ldr	x17, [x16, #3880]
    15a8:	913ca210 	add	x16, x16, #0xf28
    15ac:	d61f0220 	br	x17

00000000000015b0 <free@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    15b4:	f9479a11 	ldr	x17, [x16, #3888]
    15b8:	913cc210 	add	x16, x16, #0xf30
    15bc:	d61f0220 	br	x17

00000000000015c0 <nanosleep@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    15c4:	f9479e11 	ldr	x17, [x16, #3896]
    15c8:	913ce210 	add	x16, x16, #0xf38
    15cc:	d61f0220 	br	x17

00000000000015d0 <strchr@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    15d4:	f947a211 	ldr	x17, [x16, #3904]
    15d8:	913d0210 	add	x16, x16, #0xf40
    15dc:	d61f0220 	br	x17

00000000000015e0 <strtoull@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    15e4:	f947a611 	ldr	x17, [x16, #3912]
    15e8:	913d2210 	add	x16, x16, #0xf48
    15ec:	d61f0220 	br	x17

00000000000015f0 <fwrite@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    15f4:	f947aa11 	ldr	x17, [x16, #3920]
    15f8:	913d4210 	add	x16, x16, #0xf50
    15fc:	d61f0220 	br	x17

0000000000001600 <pthread_create@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1604:	f947ae11 	ldr	x17, [x16, #3928]
    1608:	913d6210 	add	x16, x16, #0xf58
    160c:	d61f0220 	br	x17

0000000000001610 <munmap@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1614:	f947b211 	ldr	x17, [x16, #3936]
    1618:	913d8210 	add	x16, x16, #0xf60
    161c:	d61f0220 	br	x17

0000000000001620 <fflush@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1624:	f947b611 	ldr	x17, [x16, #3944]
    1628:	913da210 	add	x16, x16, #0xf68
    162c:	d61f0220 	br	x17

0000000000001630 <strcpy@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1634:	f947ba11 	ldr	x17, [x16, #3952]
    1638:	913dc210 	add	x16, x16, #0xf70
    163c:	d61f0220 	br	x17

0000000000001640 <sysconf@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1644:	f947be11 	ldr	x17, [x16, #3960]
    1648:	913de210 	add	x16, x16, #0xf78
    164c:	d61f0220 	br	x17

0000000000001650 <strstr@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1654:	f947c211 	ldr	x17, [x16, #3968]
    1658:	913e0210 	add	x16, x16, #0xf80
    165c:	d61f0220 	br	x17

0000000000001660 <_Exit@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1664:	f947c611 	ldr	x17, [x16, #3976]
    1668:	913e2210 	add	x16, x16, #0xf88
    166c:	d61f0220 	br	x17

0000000000001670 <pthread_join@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1674:	f947ca11 	ldr	x17, [x16, #3984]
    1678:	913e4210 	add	x16, x16, #0xf90
    167c:	d61f0220 	br	x17

0000000000001680 <getenv@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1684:	f947ce11 	ldr	x17, [x16, #3992]
    1688:	913e6210 	add	x16, x16, #0xf98
    168c:	d61f0220 	br	x17

0000000000001690 <mprotect@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    1694:	f947d211 	ldr	x17, [x16, #4000]
    1698:	913e8210 	add	x16, x16, #0xfa0
    169c:	d61f0220 	br	x17

00000000000016a0 <fgets@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    16a4:	f947d611 	ldr	x17, [x16, #4008]
    16a8:	913ea210 	add	x16, x16, #0xfa8
    16ac:	d61f0220 	br	x17

00000000000016b0 <pthread_attr_setstacksize@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x15ff0>
    16b4:	f947da11 	ldr	x17, [x16, #4016]
    16b8:	913ec210 	add	x16, x16, #0xfb0
    16bc:	d61f0220 	br	x17

Disassembly of section .text:

00000000000016c0 <fwp_trap_overflow.constprop.0>:
    16c0:	d10243ff 	sub	sp, sp, #0x90
    16c4:	d2800c03 	mov	x3, #0x60                  	// #96
    16c8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15ff0>
    16cc:	f947f421 	ldr	x1, [x1, #4072]
    16d0:	d0000025 	adrp	x5, 7000 <fwp_main_thread+0x920>
    16d4:	a9077bfd 	stp	x29, x30, [sp, #112]
    16d8:	9101c3fd 	add	x29, sp, #0x70
    16dc:	912bc0a5 	add	x5, x5, #0xaf0
    16e0:	d0000024 	adrp	x4, 7000 <fwp_main_thread+0x920>
    16e4:	f90043f3 	str	x19, [sp, #128]
    16e8:	912be084 	add	x4, x4, #0xaf8
    16ec:	910023f3 	add	x19, sp, #0x8
    16f0:	f9400022 	ldr	x2, [x1]
    16f4:	f90037e2 	str	x2, [sp, #104]
    16f8:	d2800002 	mov	x2, #0x0                   	// #0
    16fc:	aa0303e1 	mov	x1, x3
    1700:	52800042 	mov	w2, #0x2                   	// #2
    1704:	aa1303e0 	mov	x0, x19
    1708:	97ffff56 	bl	1460 <__snprintf_chk@plt>
    170c:	aa1303e0 	mov	x0, x19
    1710:	94000284 	bl	2120 <fwp_trap>
    1714:	d503201f 	nop
    1718:	d503201f 	nop
    171c:	d503201f 	nop

0000000000001720 <main>:
    1720:	d10243ff 	sub	sp, sp, #0x90
    1724:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    1728:	f947f400 	ldr	x0, [x0, #4072]
    172c:	a9067bfd 	stp	x29, x30, [sp, #96]
    1730:	910183fd 	add	x29, sp, #0x60
    1734:	a90753f3 	stp	x19, x20, [sp, #112]
    1738:	f00000f3 	adrp	x19, 20000 <__data_start>
    173c:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x15ff0>
    1740:	f947ee94 	ldr	x20, [x20, #4056]
    1744:	f9400281 	ldr	x1, [x20]
    1748:	f90043f5 	str	x21, [sp, #128]
    174c:	f9400002 	ldr	x2, [x0]
    1750:	f9002fe2 	str	x2, [sp, #88]
    1754:	d2800002 	mov	x2, #0x0                   	// #0
    1758:	f9001a61 	str	x1, [x19, #48]
    175c:	94000281 	bl	2160 <fwp_now_ns>
    1760:	d0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    1764:	91352000 	add	x0, x0, #0xd48
    1768:	97ffffc6 	bl	1680 <getenv@plt>
    176c:	b4000080 	cbz	x0, 177c <main+0x5c>
    1770:	39400001 	ldrb	w1, [x0]
    1774:	aa0003f5 	mov	x21, x0
    1778:	35000801 	cbnz	w1, 1878 <main+0x158>
    177c:	910023e1 	add	x1, sp, #0x8
    1780:	52800000 	mov	w0, #0x0                   	// #0
    1784:	97ffff27 	bl	1420 <clock_gettime@plt>
    1788:	35000900 	cbnz	w0, 18a8 <main+0x188>
    178c:	a9408be0 	ldp	x0, x2, [sp, #8]
    1790:	d2994003 	mov	x3, #0xca00                	// #51712
    1794:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    1798:	9b037c01 	mul	x1, x0, x3
    179c:	9b437c00 	smulh	x0, x0, x3
    17a0:	ab020021 	adds	x1, x1, x2
    17a4:	937ffc42 	asr	x2, x2, #63
    17a8:	9a020000 	adc	x0, x0, x2
    17ac:	f100003f 	cmp	x1, #0x0
    17b0:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    17b4:	b50009a0 	cbnz	x0, 18e8 <main+0x1c8>
    17b8:	f9400280 	ldr	x0, [x20]
    17bc:	d2a00023 	mov	x3, #0x10000               	// #65536
    17c0:	52800002 	mov	w2, #0x0                   	// #0
    17c4:	d2800001 	mov	x1, #0x0                   	// #0
    17c8:	910063f5 	add	x21, sp, #0x18
    17cc:	97ffff19 	bl	1430 <setvbuf@plt>
    17d0:	d2800021 	mov	x1, #0x1                   	// #1
    17d4:	528001a0 	mov	w0, #0xd                   	// #13
    17d8:	97ffff1e 	bl	1450 <signal@plt>
    17dc:	aa1503e0 	mov	x0, x21
    17e0:	97ffff08 	bl	1400 <pthread_attr_init@plt>
    17e4:	350007c0 	cbnz	w0, 18dc <main+0x1bc>
    17e8:	aa1503e0 	mov	x0, x21
    17ec:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    17f0:	97ffffb0 	bl	16b0 <pthread_attr_setstacksize@plt>
    17f4:	35000680 	cbnz	w0, 18c4 <main+0x1a4>
    17f8:	aa1503e1 	mov	x1, x21
    17fc:	910023e0 	add	x0, sp, #0x8
    1800:	b0000022 	adrp	x2, 6000 <fwp_write+0x90c>
    1804:	d2800003 	mov	x3, #0x0                   	// #0
    1808:	911b8042 	add	x2, x2, #0x6e0
    180c:	97ffff7d 	bl	1600 <pthread_create@plt>
    1810:	2a0003e1 	mov	w1, w0
    1814:	aa1503e0 	mov	x0, x21
    1818:	2a0103f5 	mov	w21, w1
    181c:	97ffff21 	bl	14a0 <pthread_attr_destroy@plt>
    1820:	350006a0 	cbnz	w0, 18f4 <main+0x1d4>
    1824:	350004b5 	cbnz	w21, 18b8 <main+0x198>
    1828:	f94007e0 	ldr	x0, [sp, #8]
    182c:	d2800001 	mov	x1, #0x0                   	// #0
    1830:	97ffff90 	bl	1670 <pthread_join@plt>
    1834:	35000600 	cbnz	w0, 18f4 <main+0x1d4>
    1838:	f9400280 	ldr	x0, [x20]
    183c:	9100c273 	add	x19, x19, #0x30
    1840:	97ffff78 	bl	1620 <fflush@plt>
    1844:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15ff0>
    1848:	f947f421 	ldr	x1, [x1, #4072]
    184c:	b942a260 	ldr	w0, [x19, #672]
    1850:	f9402fe3 	ldr	x3, [sp, #88]
    1854:	f9400022 	ldr	x2, [x1]
    1858:	eb020063 	subs	x3, x3, x2
    185c:	d2800002 	mov	x2, #0x0                   	// #0
    1860:	540002a1 	b.ne	18b4 <main+0x194>  // b.any
    1864:	a9467bfd 	ldp	x29, x30, [sp, #96]
    1868:	a94753f3 	ldp	x19, x20, [sp, #112]
    186c:	f94043f5 	ldr	x21, [sp, #128]
    1870:	910243ff 	add	sp, sp, #0x90
    1874:	d65f03c0 	ret
    1878:	910003e1 	mov	x1, sp
    187c:	52800142 	mov	w2, #0xa                   	// #10
    1880:	97ffff58 	bl	15e0 <strtoull@plt>
    1884:	f94003e0 	ldr	x0, [sp]
    1888:	39400000 	ldrb	w0, [x0]
    188c:	35fff780 	cbnz	w0, 177c <main+0x5c>
    1890:	394002a0 	ldrb	w0, [x21]
    1894:	52801fa1 	mov	w1, #0xfd                  	// #253
    1898:	5100ac00 	sub	w0, w0, #0x2b
    189c:	6a01001f 	tst	w0, w1
    18a0:	54fff6e0 	b.eq	177c <main+0x5c>  // b.none
    18a4:	17ffffc5 	b	17b8 <main+0x98>
    18a8:	d0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    18ac:	91356000 	add	x0, x0, #0xd58
    18b0:	9400021c 	bl	2120 <fwp_trap>
    18b4:	97ffff0f 	bl	14f0 <__stack_chk_fail@plt>
    18b8:	d0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    18bc:	9137e000 	add	x0, x0, #0xdf8
    18c0:	94000218 	bl	2120 <fwp_trap>
    18c4:	aa1503e0 	mov	x0, x21
    18c8:	97fffef6 	bl	14a0 <pthread_attr_destroy@plt>
    18cc:	35000140 	cbnz	w0, 18f4 <main+0x1d4>
    18d0:	d0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    18d4:	91374000 	add	x0, x0, #0xdd0
    18d8:	94000212 	bl	2120 <fwp_trap>
    18dc:	d0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    18e0:	91368000 	add	x0, x0, #0xda0
    18e4:	9400020f 	bl	2120 <fwp_trap>
    18e8:	d0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    18ec:	9135e000 	add	x0, x0, #0xd78
    18f0:	9400020c 	bl	2120 <fwp_trap>
    18f4:	97ffff13 	bl	1540 <abort@plt>
    18f8:	d503201f 	nop
    18fc:	d503201f 	nop

0000000000001900 <_start>:
    1900:	d503201f 	nop
    1904:	d280001d 	mov	x29, #0x0                   	// #0
    1908:	d280001e 	mov	x30, #0x0                   	// #0
    190c:	aa0003e5 	mov	x5, x0
    1910:	f94003e1 	ldr	x1, [sp]
    1914:	910023e2 	add	x2, sp, #0x8
    1918:	910003e6 	mov	x6, sp
    191c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    1920:	f947f800 	ldr	x0, [x0, #4080]
    1924:	d2800003 	mov	x3, #0x0                   	// #0
    1928:	d2800004 	mov	x4, #0x0                   	// #0
    192c:	97fffea1 	bl	13b0 <__libc_start_main@plt>
    1930:	97ffff04 	bl	1540 <abort@plt>

0000000000001934 <call_weak_fn>:
    1934:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    1938:	f947f000 	ldr	x0, [x0, #4064]
    193c:	b4000040 	cbz	x0, 1944 <call_weak_fn+0x10>
    1940:	17fffef8 	b	1520 <__gmon_start__@plt>
    1944:	d65f03c0 	ret
    1948:	d503201f 	nop
    194c:	d503201f 	nop

0000000000001950 <deregister_tm_clones>:
    1950:	f00000e0 	adrp	x0, 20000 <__data_start>
    1954:	91006000 	add	x0, x0, #0x18
    1958:	f00000e1 	adrp	x1, 20000 <__data_start>
    195c:	91006021 	add	x1, x1, #0x18
    1960:	eb00003f 	cmp	x1, x0
    1964:	540000c0 	b.eq	197c <deregister_tm_clones+0x2c>  // b.none
    1968:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15ff0>
    196c:	f947e021 	ldr	x1, [x1, #4032]
    1970:	b4000061 	cbz	x1, 197c <deregister_tm_clones+0x2c>
    1974:	aa0103f0 	mov	x16, x1
    1978:	d61f0200 	br	x16
    197c:	d65f03c0 	ret

0000000000001980 <register_tm_clones>:
    1980:	f00000e0 	adrp	x0, 20000 <__data_start>
    1984:	91006000 	add	x0, x0, #0x18
    1988:	f00000e1 	adrp	x1, 20000 <__data_start>
    198c:	91006021 	add	x1, x1, #0x18
    1990:	cb000021 	sub	x1, x1, x0
    1994:	d37ffc22 	lsr	x2, x1, #63
    1998:	8b810c41 	add	x1, x2, x1, asr #3
    199c:	9341fc21 	asr	x1, x1, #1
    19a0:	b40000c1 	cbz	x1, 19b8 <register_tm_clones+0x38>
    19a4:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x15ff0>
    19a8:	f947fc42 	ldr	x2, [x2, #4088]
    19ac:	b4000062 	cbz	x2, 19b8 <register_tm_clones+0x38>
    19b0:	aa0203f0 	mov	x16, x2
    19b4:	d61f0200 	br	x16
    19b8:	d65f03c0 	ret
    19bc:	d503201f 	nop

00000000000019c0 <__do_global_dtors_aux>:
    19c0:	d503233f 	paciasp
    19c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    19c8:	910003fd 	mov	x29, sp
    19cc:	f9000bf3 	str	x19, [sp, #16]
    19d0:	f00000f3 	adrp	x19, 20000 <__data_start>
    19d4:	39408260 	ldrb	w0, [x19, #32]
    19d8:	37000140 	tbnz	w0, #0, 1a00 <__do_global_dtors_aux+0x40>
    19dc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    19e0:	f947e400 	ldr	x0, [x0, #4040]
    19e4:	b4000080 	cbz	x0, 19f4 <__do_global_dtors_aux+0x34>
    19e8:	f00000e0 	adrp	x0, 20000 <__data_start>
    19ec:	f9400400 	ldr	x0, [x0, #8]
    19f0:	97fffe7c 	bl	13e0 <__cxa_finalize@plt>
    19f4:	97ffffd7 	bl	1950 <deregister_tm_clones>
    19f8:	52800020 	mov	w0, #0x1                   	// #1
    19fc:	39008260 	strb	w0, [x19, #32]
    1a00:	f9400bf3 	ldr	x19, [sp, #16]
    1a04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a08:	d50323bf 	autiasp
    1a0c:	d65f03c0 	ret

0000000000001a10 <frame_dummy>:
    1a10:	d503245f 	bti	c
    1a14:	17ffffdb 	b	1980 <register_tm_clones>
    1a18:	d503201f 	nop
    1a1c:	d503201f 	nop

0000000000001a20 <fwp_fmt_u128>:
    1a20:	d10183ff 	sub	sp, sp, #0x60
    1a24:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15ff0>
    1a28:	f947f421 	ldr	x1, [x1, #4072]
    1a2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    1a30:	910143fd 	add	x29, sp, #0x50
    1a34:	f9400024 	ldr	x4, [x1]
    1a38:	f90027e4 	str	x4, [sp, #72]
    1a3c:	d2800004 	mov	x4, #0x0                   	// #0
    1a40:	aa030041 	orr	x1, x2, x3
    1a44:	b5000361 	cbnz	x1, 1ab0 <fwp_fmt_u128+0x90>
    1a48:	910023e9 	add	x9, sp, #0x8
    1a4c:	52800601 	mov	w1, #0x30                  	// #48
    1a50:	5280002d 	mov	w13, #0x1                   	// #1
    1a54:	390023e1 	strb	w1, [sp, #8]
    1a58:	93407dad 	sxtw	x13, w13
    1a5c:	aa0d03e1 	mov	x1, x13
    1a60:	8b0d0004 	add	x4, x0, x13
    1a64:	d503201f 	nop
    1a68:	8b010123 	add	x3, x9, x1
    1a6c:	cb0103e2 	neg	x2, x1
    1a70:	d1000421 	sub	x1, x1, #0x1
    1a74:	385ff063 	ldurb	w3, [x3, #-1]
    1a78:	38226883 	strb	w3, [x4, x2]
    1a7c:	35ffff61 	cbnz	w1, 1a68 <fwp_fmt_u128+0x48>
    1a80:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15ff0>
    1a84:	f947f421 	ldr	x1, [x1, #4072]
    1a88:	382d681f 	strb	wzr, [x0, x13]
    1a8c:	aa0103e0 	mov	x0, x1
    1a90:	f94027e2 	ldr	x2, [sp, #72]
    1a94:	f9400001 	ldr	x1, [x0]
    1a98:	eb010042 	subs	x2, x2, x1
    1a9c:	d2800001 	mov	x1, #0x0                   	// #0
    1aa0:	54000561 	b.ne	1b4c <fwp_fmt_u128+0x12c>  // b.any
    1aa4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1aa8:	910183ff 	add	sp, sp, #0x60
    1aac:	d65f03c0 	ret
    1ab0:	d0000021 	adrp	x1, 7000 <fwp_main_thread+0x920>
    1ab4:	913ac021 	add	x1, x1, #0xeb0
    1ab8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1abc:	910023e9 	add	x9, sp, #0x8
    1ac0:	d2800027 	mov	x7, #0x1                   	// #1
    1ac4:	f29999af 	movk	x15, #0xcccd
    1ac8:	a9402826 	ldp	x6, x10, [x1]
    1acc:	d503201f 	nop
    1ad0:	ab030041 	adds	x1, x2, x3
    1ad4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1ad8:	aa0303eb 	mov	x11, x3
    1adc:	8b070128 	add	x8, x9, x7
    1ae0:	aa0203ee 	mov	x14, x2
    1ae4:	aa0703ed 	mov	x13, x7
    1ae8:	910004e7 	add	x7, x7, #0x1
    1aec:	9bcf7c24 	umulh	x4, x1, x15
    1af0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1af4:	8b4408a4 	add	x4, x5, x4, lsr #2
    1af8:	cb040021 	sub	x1, x1, x4
    1afc:	eb010041 	subs	x1, x2, x1
    1b00:	da1f0063 	sbc	x3, x3, xzr
    1b04:	9bc67c24 	umulh	x4, x1, x6
    1b08:	9b061064 	madd	x4, x3, x6, x4
    1b0c:	9b067c2c 	mul	x12, x1, x6
    1b10:	9b0a1024 	madd	x4, x1, x10, x4
    1b14:	9bc67c25 	umulh	x5, x1, x6
    1b18:	9b061465 	madd	x5, x3, x6, x5
    1b1c:	9b0a1425 	madd	x5, x1, x10, x5
    1b20:	93cc0484 	extr	x4, x4, x12, #1
    1b24:	8b040884 	add	x4, x4, x4, lsl #2
    1b28:	d341fca3 	lsr	x3, x5, #1
    1b2c:	cb040444 	sub	x4, x2, x4, lsl #1
    1b30:	93cc04a2 	extr	x2, x5, x12, #1
    1b34:	1100c084 	add	w4, w4, #0x30
    1b38:	381ff104 	sturb	w4, [x8, #-1]
    1b3c:	b5fffcab 	cbnz	x11, 1ad0 <fwp_fmt_u128+0xb0>
    1b40:	f10025df 	cmp	x14, #0x9
    1b44:	54fffc68 	b.hi	1ad0 <fwp_fmt_u128+0xb0>  // b.pmore
    1b48:	17ffffc4 	b	1a58 <fwp_fmt_u128+0x38>
    1b4c:	97fffe69 	bl	14f0 <__stack_chk_fail@plt>

0000000000001b50 <fwp_range_release>:
    1b50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b54:	910003fd 	mov	x29, sp
    1b58:	f9400801 	ldr	x1, [x0, #16]
    1b5c:	f9000bf3 	str	x19, [sp, #16]
    1b60:	aa0003f3 	mov	x19, x0
    1b64:	b4000061 	cbz	x1, 1b70 <fwp_range_release+0x20>
    1b68:	f9400400 	ldr	x0, [x0, #8]
    1b6c:	d63f0020 	blr	x1
    1b70:	f9400260 	ldr	x0, [x19]
    1b74:	f9400e61 	ldr	x1, [x19, #24]
    1b78:	f9400bf3 	ldr	x19, [sp, #16]
    1b7c:	aa0103f0 	mov	x16, x1
    1b80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1b84:	d61f0200 	br	x16
    1b88:	d503201f 	nop
    1b8c:	d503201f 	nop

0000000000001b90 <fwp_owned_entry32>:
    1b90:	6d400001 	ldp	d1, d0, [x0]
    1b94:	1e613800 	fsub	d0, d0, d1
    1b98:	9e660000 	fmov	x0, d0
    1b9c:	d65f03c0 	ret

0000000000001ba0 <fwp_args32>:
    1ba0:	d65f03c0 	ret

0000000000001ba4 <fwp_owned_entry45>:
    1ba4:	6d400400 	ldp	d0, d1, [x0]
    1ba8:	1e612800 	fadd	d0, d0, d1
    1bac:	9e660000 	fmov	x0, d0
    1bb0:	d65f03c0 	ret

0000000000001bb4 <fwp_owned_entry69>:
    1bb4:	d0000021 	adrp	x1, 7000 <fwp_main_thread+0x920>
    1bb8:	fd400001 	ldr	d1, [x0]
    1bbc:	fd477020 	ldr	d0, [x1, #3808]
    1bc0:	1e610800 	fmul	d0, d0, d1
    1bc4:	9e660000 	fmov	x0, d0
    1bc8:	d65f03c0 	ret
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_flush>:
    1bd0:	f00000e0 	adrp	x0, 20000 <__data_start>
    1bd4:	f9401800 	ldr	x0, [x0, #48]
    1bd8:	b4000120 	cbz	x0, 1bfc <fwp_flush+0x2c>
    1bdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1be0:	910003fd 	mov	x29, sp
    1be4:	97fffe8f 	bl	1620 <fflush@plt>
    1be8:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    1bec:	f947ec00 	ldr	x0, [x0, #4056]
    1bf0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1bf4:	f9400000 	ldr	x0, [x0]
    1bf8:	17fffe8a 	b	1620 <fflush@plt>
    1bfc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    1c00:	f947ec00 	ldr	x0, [x0, #4056]
    1c04:	f9400000 	ldr	x0, [x0]
    1c08:	17fffe86 	b	1620 <fflush@plt>
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_heap_oom>:
    1c10:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x15ff0>
    1c14:	f947e863 	ldr	x3, [x3, #4048]
    1c18:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1c1c:	d2800262 	mov	x2, #0x13                  	// #19
    1c20:	910003fd 	mov	x29, sp
    1c24:	f9400063 	ldr	x3, [x3]
    1c28:	d2800021 	mov	x1, #0x1                   	// #1
    1c2c:	d0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    1c30:	91266000 	add	x0, x0, #0x998
    1c34:	97fffe6f 	bl	15f0 <fwrite@plt>
    1c38:	d2800000 	mov	x0, #0x0                   	// #0
    1c3c:	97fffe79 	bl	1620 <fflush@plt>
    1c40:	52800cc0 	mov	w0, #0x66                  	// #102
    1c44:	97fffe87 	bl	1660 <_Exit@plt>
    1c48:	d503201f 	nop
    1c4c:	d503201f 	nop

0000000000001c50 <fwp_segv>:
    1c50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c54:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c58:	9100c043 	add	x3, x2, #0x30
    1c5c:	910003fd 	mov	x29, sp
    1c60:	a90153f3 	stp	x19, x20, [sp, #16]
    1c64:	2a0003f3 	mov	w19, w0
    1c68:	f9400460 	ldr	x0, [x3, #8]
    1c6c:	f90013f5 	str	x21, [sp, #32]
    1c70:	f9400835 	ldr	x21, [x1, #16]
    1c74:	b4000280 	cbz	x0, 1cc4 <fwp_segv+0x74>
    1c78:	f9400814 	ldr	x20, [x0, #16]
    1c7c:	b4000254 	cbz	x20, 1cc4 <fwp_segv+0x74>
    1c80:	528003c0 	mov	w0, #0x1e                  	// #30
    1c84:	97fffe6f 	bl	1640 <sysconf@plt>
    1c88:	f144029f 	cmp	x20, #0x100, lsl #12
    1c8c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c90:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c94:	8b000294 	add	x20, x20, x0
    1c98:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c9c:	eb0102bf 	cmp	x21, x1
    1ca0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1ca4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1ca8:	35000240 	cbnz	w0, 1cf0 <fwp_segv+0xa0>
    1cac:	f94013f5 	ldr	x21, [sp, #32]
    1cb0:	2a1303e0 	mov	w0, w19
    1cb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1cb8:	d2800001 	mov	x1, #0x0                   	// #0
    1cbc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1cc0:	17fffde4 	b	1450 <signal@plt>
    1cc4:	9100c042 	add	x2, x2, #0x30
    1cc8:	f9400840 	ldr	x0, [x2, #16]
    1ccc:	b4ffff00 	cbz	x0, 1cac <fwp_segv+0x5c>
    1cd0:	f9400c41 	ldr	x1, [x2, #24]
    1cd4:	cb010000 	sub	x0, x0, x1
    1cd8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1cdc:	91440000 	add	x0, x0, #0x100, lsl #12
    1ce0:	eb15003f 	cmp	x1, x21
    1ce4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1ce8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1cec:	34fffe00 	cbz	w0, 1cac <fwp_segv+0x5c>
    1cf0:	97ffffb8 	bl	1bd0 <fwp_flush>
    1cf4:	d0000021 	adrp	x1, 7000 <fwp_main_thread+0x920>
    1cf8:	913a4021 	add	x1, x1, #0xe90
    1cfc:	d2800342 	mov	x2, #0x1a                  	// #26
    1d00:	52800040 	mov	w0, #0x2                   	// #2
    1d04:	97fffe0b 	bl	1530 <write@plt>
    1d08:	52800ca0 	mov	w0, #0x65                  	// #101
    1d0c:	97fffd99 	bl	1370 <_exit@plt>

0000000000001d10 <fwp_heap_chunks>:
    1d10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d14:	910003fd 	mov	x29, sp
    1d18:	a90153f3 	stp	x19, x20, [sp, #16]
    1d1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1d20:	90000195 	adrp	x21, 31000 <fwp_root_context+0xd10>
    1d24:	911342a1 	add	x1, x21, #0x4d0
    1d28:	f100041f 	cmp	x0, #0x1
    1d2c:	54000ca0 	b.eq	1ec0 <fwp_heap_chunks+0x1b0>  // b.none
    1d30:	f949f822 	ldr	x2, [x1, #5104]
    1d34:	b0000185 	adrp	x5, 32000 <fwp_heap+0xb30>
    1d38:	912300a5 	add	x5, x5, #0x8c0
    1d3c:	911342a1 	add	x1, x21, #0x4d0
    1d40:	f949ec34 	ldr	x20, [x1, #5080]
    1d44:	eb14005f 	cmp	x2, x20
    1d48:	54000c42 	b.cs	1ed0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1d4c:	f949fc23 	ldr	x3, [x1, #5112]
    1d50:	8b020841 	add	x1, x2, x2, lsl #2
    1d54:	d2800004 	mov	x4, #0x0                   	// #0
    1d58:	8b010c61 	add	x1, x3, x1, lsl #3
    1d5c:	14000009 	b	1d80 <fwp_heap_chunks+0x70>
    1d60:	91000483 	add	x3, x4, #0x1
    1d64:	eb03001f 	cmp	x0, x3
    1d68:	54000940 	b.eq	1e90 <fwp_heap_chunks+0x180>  // b.none
    1d6c:	91000442 	add	x2, x2, #0x1
    1d70:	aa0303e4 	mov	x4, x3
    1d74:	9100a021 	add	x1, x1, #0x28
    1d78:	eb02029f 	cmp	x20, x2
    1d7c:	54000100 	b.eq	1d9c <fwp_heap_chunks+0x8c>  // b.none
    1d80:	39400023 	ldrb	w3, [x1]
    1d84:	34fffee3 	cbz	w3, 1d60 <fwp_heap_chunks+0x50>
    1d88:	91000442 	add	x2, x2, #0x1
    1d8c:	9100a021 	add	x1, x1, #0x28
    1d90:	d2800004 	mov	x4, #0x0                   	// #0
    1d94:	eb02029f 	cmp	x20, x2
    1d98:	54ffff41 	b.ne	1d80 <fwp_heap_chunks+0x70>  // b.any
    1d9c:	cb040294 	sub	x20, x20, x4
    1da0:	f9001bf7 	str	x23, [sp, #48]
    1da4:	911342b7 	add	x23, x21, #0x4d0
    1da8:	8b140013 	add	x19, x0, x20
    1dac:	f94a1ae1 	ldr	x1, [x23, #5168]
    1db0:	f949f2e0 	ldr	x0, [x23, #5088]
    1db4:	cb040021 	sub	x1, x1, x4
    1db8:	f90a1ae1 	str	x1, [x23, #5168]
    1dbc:	eb00027f 	cmp	x19, x0
    1dc0:	54000429 	b.ls	1e44 <fwp_heap_chunks+0x134>  // b.plast
    1dc4:	f949eae1 	ldr	x1, [x23, #5072]
    1dc8:	eb01027f 	cmp	x19, x1
    1dcc:	54000888 	b.hi	1edc <fwp_heap_chunks+0x1cc>  // b.pmore
    1dd0:	91010276 	add	x22, x19, #0x40
    1dd4:	52800062 	mov	w2, #0x3                   	// #3
    1dd8:	f949dae3 	ldr	x3, [x23, #5040]
    1ddc:	eb0102df 	cmp	x22, x1
    1de0:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1de4:	cb0002c1 	sub	x1, x22, x0
    1de8:	8b004060 	add	x0, x3, x0, lsl #16
    1dec:	d370bc21 	lsl	x1, x1, #16
    1df0:	97fffe28 	bl	1690 <mprotect@plt>
    1df4:	35000740 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1df8:	528003c0 	mov	w0, #0x1e                  	// #30
    1dfc:	97fffe11 	bl	1640 <sysconf@plt>
    1e00:	f949f2e2 	ldr	x2, [x23, #5088]
    1e04:	cb0003e5 	neg	x5, x0
    1e08:	aa0003e4 	mov	x4, x0
    1e0c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e10:	f949fee0 	ldr	x0, [x23, #5112]
    1e14:	8b020843 	add	x3, x2, x2, lsl #2
    1e18:	52800062 	mov	w2, #0x3                   	// #3
    1e1c:	8b010c01 	add	x1, x0, x1, lsl #3
    1e20:	8b030c03 	add	x3, x0, x3, lsl #3
    1e24:	d1000421 	sub	x1, x1, #0x1
    1e28:	8a050060 	and	x0, x3, x5
    1e2c:	8b040021 	add	x1, x1, x4
    1e30:	8a050021 	and	x1, x1, x5
    1e34:	cb000021 	sub	x1, x1, x0
    1e38:	97fffe16 	bl	1690 <mprotect@plt>
    1e3c:	35000500 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1e40:	f909f2f6 	str	x22, [x23, #5088]
    1e44:	911342b5 	add	x21, x21, #0x4d0
    1e48:	d370be60 	lsl	x0, x19, #16
    1e4c:	f949e6a1 	ldr	x1, [x21, #5064]
    1e50:	f909eeb3 	str	x19, [x21, #5080]
    1e54:	eb01001f 	cmp	x0, x1
    1e58:	540000e8 	b.hi	1e74 <fwp_heap_chunks+0x164>  // b.pmore
    1e5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e60:	aa1403e0 	mov	x0, x20
    1e64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e68:	f9401bf7 	ldr	x23, [sp, #48]
    1e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e70:	d65f03c0 	ret
    1e74:	f9401bf7 	ldr	x23, [sp, #48]
    1e78:	f909e6a0 	str	x0, [x21, #5064]
    1e7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e80:	aa1403e0 	mov	x0, x20
    1e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e88:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e8c:	d65f03c0 	ret
    1e90:	911342b5 	add	x21, x21, #0x4d0
    1e94:	91000441 	add	x1, x2, #0x1
    1e98:	f90000a1 	str	x1, [x5]
    1e9c:	cb040054 	sub	x20, x2, x4
    1ea0:	f94a1aa1 	ldr	x1, [x21, #5168]
    1ea4:	cb000020 	sub	x0, x1, x0
    1ea8:	f90a1aa0 	str	x0, [x21, #5168]
    1eac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1eb0:	aa1403e0 	mov	x0, x20
    1eb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1eb8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ebc:	d65f03c0 	ret
    1ec0:	f949f422 	ldr	x2, [x1, #5096]
    1ec4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xb30>
    1ec8:	9122e0a5 	add	x5, x5, #0x8b8
    1ecc:	17ffff9c 	b	1d3c <fwp_heap_chunks+0x2c>
    1ed0:	d2800004 	mov	x4, #0x0                   	// #0
    1ed4:	f9001bf7 	str	x23, [sp, #48]
    1ed8:	17ffffb3 	b	1da4 <fwp_heap_chunks+0x94>
    1edc:	97ffff4d 	bl	1c10 <fwp_heap_oom>

0000000000001ee0 <buf_grow>:
    1ee0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1ee4:	910003fd 	mov	x29, sp
    1ee8:	a90153f3 	stp	x19, x20, [sp, #16]
    1eec:	aa0003f4 	mov	x20, x0
    1ef0:	f9400400 	ldr	x0, [x0, #8]
    1ef4:	b100041f 	cmn	x0, #0x1
    1ef8:	54000400 	b.eq	1f78 <buf_grow+0x98>  // b.none
    1efc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    1f00:	cb000042 	sub	x2, x2, x0
    1f04:	eb01005f 	cmp	x2, x1
    1f08:	54000383 	b.cc	1f78 <buf_grow+0x98>  // b.lo, b.ul, b.last
    1f0c:	f9400a82 	ldr	x2, [x20, #16]
    1f10:	91000421 	add	x1, x1, #0x1
    1f14:	8b000033 	add	x19, x1, x0
    1f18:	eb13005f 	cmp	x2, x19
    1f1c:	54000242 	b.cs	1f64 <buf_grow+0x84>  // b.hs, b.nlast
    1f20:	f100005f 	cmp	x2, #0x0
    1f24:	b5000262 	cbnz	x2, 1f70 <buf_grow+0x90>
    1f28:	d2800802 	mov	x2, #0x40                  	// #64
    1f2c:	eb02027f 	cmp	x19, x2
    1f30:	54000068 	b.hi	1f3c <buf_grow+0x5c>  // b.pmore
    1f34:	14000005 	b	1f48 <buf_grow+0x68>
    1f38:	b7f800a2 	tbnz	x2, #63, 1f4c <buf_grow+0x6c>
    1f3c:	d37ff842 	lsl	x2, x2, #1
    1f40:	eb02027f 	cmp	x19, x2
    1f44:	54ffffa8 	b.hi	1f38 <buf_grow+0x58>  // b.pmore
    1f48:	aa0203f3 	mov	x19, x2
    1f4c:	f9400280 	ldr	x0, [x20]
    1f50:	aa1303e1 	mov	x1, x19
    1f54:	97fffd63 	bl	14e0 <realloc@plt>
    1f58:	b4000100 	cbz	x0, 1f78 <buf_grow+0x98>
    1f5c:	f9000280 	str	x0, [x20]
    1f60:	f9000a93 	str	x19, [x20, #16]
    1f64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1f68:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1f6c:	d65f03c0 	ret
    1f70:	54fffe6a 	b.ge	1f3c <buf_grow+0x5c>  // b.tcont
    1f74:	17fffff6 	b	1f4c <buf_grow+0x6c>
    1f78:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x15ff0>
    1f7c:	f947e863 	ldr	x3, [x3, #4048]
    1f80:	d2800262 	mov	x2, #0x13                  	// #19
    1f84:	d2800021 	mov	x1, #0x1                   	// #1
    1f88:	d0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    1f8c:	91266000 	add	x0, x0, #0x998
    1f90:	f9400063 	ldr	x3, [x3]
    1f94:	97fffd97 	bl	15f0 <fwrite@plt>
    1f98:	d2800000 	mov	x0, #0x0                   	// #0
    1f9c:	97fffda1 	bl	1620 <fflush@plt>
    1fa0:	52800cc0 	mov	w0, #0x66                  	// #102
    1fa4:	97fffdaf 	bl	1660 <_Exit@plt>
    1fa8:	d503201f 	nop
    1fac:	d503201f 	nop

0000000000001fb0 <buf_put>:
    1fb0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1fb4:	910003fd 	mov	x29, sp
    1fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    1fbc:	aa0003f4 	mov	x20, x0
    1fc0:	aa0203f3 	mov	x19, x2
    1fc4:	f90013f5 	str	x21, [sp, #32]
    1fc8:	aa0103f5 	mov	x21, x1
    1fcc:	aa0203e1 	mov	x1, x2
    1fd0:	97ffffc4 	bl	1ee0 <buf_grow>
    1fd4:	a9400283 	ldp	x3, x0, [x20]
    1fd8:	aa1503e1 	mov	x1, x21
    1fdc:	aa1303e2 	mov	x2, x19
    1fe0:	8b000060 	add	x0, x3, x0
    1fe4:	97fffcdb 	bl	1350 <memcpy@plt>
    1fe8:	a9400680 	ldp	x0, x1, [x20]
    1fec:	8b010273 	add	x19, x19, x1
    1ff0:	f9000693 	str	x19, [x20, #8]
    1ff4:	3833681f 	strb	wzr, [x0, x19]
    1ff8:	a94153f3 	ldp	x19, x20, [sp, #16]
    1ffc:	f94013f5 	ldr	x21, [sp, #32]
    2000:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2004:	d65f03c0 	ret
    2008:	d503201f 	nop
    200c:	d503201f 	nop

0000000000002010 <fwp_cancel_tree.part.0>:
    2010:	d00000e1 	adrp	x1, 20000 <__data_start>
    2014:	9100c022 	add	x2, x1, #0x30
    2018:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    201c:	52800023 	mov	w3, #0x1                   	// #1
    2020:	910003fd 	mov	x29, sp
    2024:	f9400444 	ldr	x4, [x2, #8]
    2028:	f9000bf3 	str	x19, [sp, #16]
    202c:	39014403 	strb	w3, [x0, #81]
    2030:	eb04001f 	cmp	x0, x4
    2034:	54000160 	b.eq	2060 <fwp_cancel_tree.part.0+0x50>  // b.none
    2038:	f9402804 	ldr	x4, [x0, #80]
    203c:	f2001c9f 	tst	x4, #0xff000000ff
    2040:	54000101 	b.ne	2060 <fwp_cancel_tree.part.0+0x50>  // b.any
    2044:	f9401044 	ldr	x4, [x2, #32]
    2048:	39015003 	strb	w3, [x0, #84]
    204c:	f900801f 	str	xzr, [x0, #256]
    2050:	b40001e4 	cbz	x4, 208c <fwp_cancel_tree.part.0+0x7c>
    2054:	f9008080 	str	x0, [x4, #256]
    2058:	9100c021 	add	x1, x1, #0x30
    205c:	f9001020 	str	x0, [x1, #32]
    2060:	f9401413 	ldr	x19, [x0, #40]
    2064:	b40000f3 	cbz	x19, 2080 <fwp_cancel_tree.part.0+0x70>
    2068:	39414261 	ldrb	w1, [x19, #80]
    206c:	aa1303e0 	mov	x0, x19
    2070:	37000041 	tbnz	w1, #0, 2078 <fwp_cancel_tree.part.0+0x68>
    2074:	97ffffe7 	bl	2010 <fwp_cancel_tree.part.0>
    2078:	f9401a73 	ldr	x19, [x19, #48]
    207c:	b5ffff73 	cbnz	x19, 2068 <fwp_cancel_tree.part.0+0x58>
    2080:	f9400bf3 	ldr	x19, [sp, #16]
    2084:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2088:	d65f03c0 	ret
    208c:	f9001440 	str	x0, [x2, #40]
    2090:	17fffff2 	b	2058 <fwp_cancel_tree.part.0+0x48>

0000000000002094 <fwp_finish_float>:
    2094:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2098:	528005c1 	mov	w1, #0x2e                  	// #46
    209c:	910003fd 	mov	x29, sp
    20a0:	f9000bf3 	str	x19, [sp, #16]
    20a4:	aa0003f3 	mov	x19, x0
    20a8:	97fffd4a 	bl	15d0 <strchr@plt>
    20ac:	b4000080 	cbz	x0, 20bc <fwp_finish_float+0x28>
    20b0:	f9400bf3 	ldr	x19, [sp, #16]
    20b4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    20b8:	d65f03c0 	ret
    20bc:	aa1303e0 	mov	x0, x19
    20c0:	52800ca1 	mov	w1, #0x65                  	// #101
    20c4:	97fffd43 	bl	15d0 <strchr@plt>
    20c8:	b5ffff40 	cbnz	x0, 20b0 <fwp_finish_float+0x1c>
    20cc:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x920>
    20d0:	aa1303e0 	mov	x0, x19
    20d4:	9126c021 	add	x1, x1, #0x9b0
    20d8:	97fffd5e 	bl	1650 <strstr@plt>
    20dc:	b5fffea0 	cbnz	x0, 20b0 <fwp_finish_float+0x1c>
    20e0:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x920>
    20e4:	aa1303e0 	mov	x0, x19
    20e8:	9126e021 	add	x1, x1, #0x9b8
    20ec:	97fffd59 	bl	1650 <strstr@plt>
    20f0:	b5fffe00 	cbnz	x0, 20b0 <fwp_finish_float+0x1c>
    20f4:	aa1303e0 	mov	x0, x19
    20f8:	97fffca2 	bl	1380 <strlen@plt>
    20fc:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x920>
    2100:	91270021 	add	x1, x1, #0x9c0
    2104:	8b000262 	add	x2, x19, x0
    2108:	79400023 	ldrh	w3, [x1]
    210c:	39400821 	ldrb	w1, [x1, #2]
    2110:	78206a63 	strh	w3, [x19, x0]
    2114:	39000841 	strb	w1, [x2, #2]
    2118:	17ffffe6 	b	20b0 <fwp_finish_float+0x1c>
    211c:	d503201f 	nop

0000000000002120 <fwp_trap>:
    2120:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2124:	910003fd 	mov	x29, sp
    2128:	f9000bf3 	str	x19, [sp, #16]
    212c:	aa0003f3 	mov	x19, x0
    2130:	97fffea8 	bl	1bd0 <fwp_flush>
    2134:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x15ff0>
    2138:	f947e884 	ldr	x4, [x4, #4048]
    213c:	aa1303e3 	mov	x3, x19
    2140:	b0000022 	adrp	x2, 7000 <fwp_main_thread+0x920>
    2144:	91272042 	add	x2, x2, #0x9c8
    2148:	52800041 	mov	w1, #0x2                   	// #2
    214c:	f9400080 	ldr	x0, [x4]
    2150:	97fffd04 	bl	1560 <__fprintf_chk@plt>
    2154:	52800ca0 	mov	w0, #0x65                  	// #101
    2158:	97fffc92 	bl	13a0 <exit@plt>
    215c:	d503201f 	nop

0000000000002160 <fwp_now_ns>:
    2160:	d100c3ff 	sub	sp, sp, #0x30
    2164:	52800020 	mov	w0, #0x1                   	// #1
    2168:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x15ff0>
    216c:	f947f442 	ldr	x2, [x2, #4072]
    2170:	910023e1 	add	x1, sp, #0x8
    2174:	a9027bfd 	stp	x29, x30, [sp, #32]
    2178:	910083fd 	add	x29, sp, #0x20
    217c:	f9400043 	ldr	x3, [x2]
    2180:	f9000fe3 	str	x3, [sp, #24]
    2184:	d2800003 	mov	x3, #0x0                   	// #0
    2188:	97fffca6 	bl	1420 <clock_gettime@plt>
    218c:	350002c0 	cbnz	w0, 21e4 <fwp_now_ns+0x84>
    2190:	a9408be1 	ldp	x1, x2, [sp, #8]
    2194:	d2994003 	mov	x3, #0xca00                	// #51712
    2198:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    219c:	9b037c20 	mul	x0, x1, x3
    21a0:	9b437c21 	smulh	x1, x1, x3
    21a4:	ab020000 	adds	x0, x0, x2
    21a8:	937ffc42 	asr	x2, x2, #63
    21ac:	9a020021 	adc	x1, x1, x2
    21b0:	f100001f 	cmp	x0, #0x0
    21b4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    21b8:	b50001e1 	cbnz	x1, 21f4 <fwp_now_ns+0x94>
    21bc:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15ff0>
    21c0:	f947f421 	ldr	x1, [x1, #4072]
    21c4:	f9400fe3 	ldr	x3, [sp, #24]
    21c8:	f9400022 	ldr	x2, [x1]
    21cc:	eb020063 	subs	x3, x3, x2
    21d0:	d2800002 	mov	x2, #0x0                   	// #0
    21d4:	540000e1 	b.ne	21f0 <fwp_now_ns+0x90>  // b.any
    21d8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    21dc:	9100c3ff 	add	sp, sp, #0x30
    21e0:	d65f03c0 	ret
    21e4:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    21e8:	91276000 	add	x0, x0, #0x9d8
    21ec:	97ffffcd 	bl	2120 <fwp_trap>
    21f0:	97fffcc0 	bl	14f0 <__stack_chk_fail@plt>
    21f4:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    21f8:	9127e000 	add	x0, x0, #0x9f8
    21fc:	97ffffc9 	bl	2120 <fwp_trap>

0000000000002200 <fwp_args74>:
    2200:	d65f03c0 	ret

0000000000002204 <fwp_format_g.constprop.0>:
    2204:	d10483ff 	sub	sp, sp, #0x120
    2208:	b0000024 	adrp	x4, 7000 <fwp_main_thread+0x920>
    220c:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x15ff0>
    2210:	f947f442 	ldr	x2, [x2, #4072]
    2214:	91288084 	add	x4, x4, #0xa20
    2218:	a90b7bfd 	stp	x29, x30, [sp, #176]
    221c:	9102c3fd 	add	x29, sp, #0xb0
    2220:	d2800803 	mov	x3, #0x40                  	// #64
    2224:	a90e63f7 	stp	x23, x24, [sp, #224]
    2228:	93407c38 	sxtw	x24, w1
    222c:	aa0303e1 	mov	x1, x3
    2230:	fd008be8 	str	d8, [sp, #272]
    2234:	1e604008 	fmov	d8, d0
    2238:	a90c53f3 	stp	x19, x20, [sp, #192]
    223c:	910083f4 	add	x20, sp, #0x20
    2240:	a90d5bf5 	stp	x21, x22, [sp, #208]
    2244:	aa0003f5 	mov	x21, x0
    2248:	a91073fb 	stp	x27, x28, [sp, #256]
    224c:	5100071c 	sub	w28, w24, #0x1
    2250:	2a1c03e5 	mov	w5, w28
    2254:	f9400040 	ldr	x0, [x2]
    2258:	f90057e0 	str	x0, [sp, #168]
    225c:	d2800000 	mov	x0, #0x0                   	// #0
    2260:	52800042 	mov	w2, #0x2                   	// #2
    2264:	aa1403e0 	mov	x0, x20
    2268:	97fffc7e 	bl	1460 <__snprintf_chk@plt>
    226c:	52800ca1 	mov	w1, #0x65                  	// #101
    2270:	aa1403e0 	mov	x0, x20
    2274:	97fffcd7 	bl	15d0 <strchr@plt>
    2278:	aa0003f3 	mov	x19, x0
    227c:	52800142 	mov	w2, #0xa                   	// #10
    2280:	91000400 	add	x0, x0, #0x1
    2284:	d2800001 	mov	x1, #0x0                   	// #0
    2288:	97fffcc2 	bl	1590 <strtol@plt>
    228c:	aa0003f7 	mov	x23, x0
    2290:	11001400 	add	w0, w0, #0x5
    2294:	7100541f 	cmp	w0, #0x15
    2298:	54000d88 	b.hi	2448 <fwp_format_g.constprop.0+0x244>  // b.pmore
    229c:	4b170385 	sub	w5, w28, w23
    22a0:	710000bf 	cmp	w5, #0x0
    22a4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    22a8:	54000ba0 	b.eq	241c <fwp_format_g.constprop.0+0x218>  // b.none
    22ac:	394083e0 	ldrb	w0, [sp, #32]
    22b0:	cb180273 	sub	x19, x19, x24
    22b4:	91000673 	add	x19, x19, #0x1
    22b8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    22bc:	7100b41f 	cmp	w0, #0x2d
    22c0:	9a941681 	cinc	x1, x20, eq	// eq = none
    22c4:	1a9f17e4 	cset	w4, eq	// eq = none
    22c8:	cb010266 	sub	x6, x19, x1
    22cc:	d10004da 	sub	x26, x6, #0x1
    22d0:	540018c0 	b.eq	25e8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    22d4:	910183f9 	add	x25, sp, #0x60
    22d8:	d280091b 	mov	x27, #0x48                  	// #72
    22dc:	aa1903e7 	mov	x7, x25
    22e0:	91000423 	add	x3, x1, #0x1
    22e4:	91011cc6 	add	x6, x6, #0x47
    22e8:	910004f6 	add	x22, x7, #0x1
    22ec:	37f81017 	tbnz	w23, #31, 24ec <fwp_format_g.constprop.0+0x2e8>
    22f0:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    22f4:	93407ef7 	sxtw	x23, w23
    22f8:	390000e4 	strb	w4, [x7]
    22fc:	aa1303e1 	mov	x1, x19
    2300:	aa1703e2 	mov	x2, x23
    2304:	aa1603e0 	mov	x0, x22
    2308:	b9000be5 	str	w5, [sp, #8]
    230c:	cb170374 	sub	x20, x27, x23
    2310:	a9011be3 	stp	x3, x6, [sp, #16]
    2314:	97fffc0f 	bl	1350 <memcpy@plt>
    2318:	d1000694 	sub	x20, x20, #0x1
    231c:	f9400be3 	ldr	x3, [sp, #16]
    2320:	8b1702d6 	add	x22, x22, x23
    2324:	aa1603e0 	mov	x0, x22
    2328:	aa1a03e2 	mov	x2, x26
    232c:	aa0303e1 	mov	x1, x3
    2330:	aa1403e3 	mov	x3, x20
    2334:	97fffc43 	bl	1440 <__memcpy_chk@plt>
    2338:	8b1a02d6 	add	x22, x22, x26
    233c:	f9400fe6 	ldr	x6, [sp, #24]
    2340:	d2800900 	mov	x0, #0x48                  	// #72
    2344:	b9400be5 	ldr	w5, [sp, #8]
    2348:	8b170261 	add	x1, x19, x23
    234c:	cb1400c3 	sub	x3, x6, x20
    2350:	cb060294 	sub	x20, x20, x6
    2354:	f101207f 	cmp	x3, #0x48
    2358:	93407cb8 	sxtw	x24, w5
    235c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2360:	aa1803e2 	mov	x2, x24
    2364:	8b1802d3 	add	x19, x22, x24
    2368:	8b140063 	add	x3, x3, x20
    236c:	aa1603e0 	mov	x0, x22
    2370:	97fffc34 	bl	1440 <__memcpy_chk@plt>
    2374:	cb190273 	sub	x19, x19, x25
    2378:	d28031e0 	mov	x0, #0x18f                 	// #399
    237c:	eb00027f 	cmp	x19, x0
    2380:	aa1903e1 	mov	x1, x25
    2384:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    2388:	aa1503e0 	mov	x0, x21
    238c:	aa1303e2 	mov	x2, x19
    2390:	97fffbf0 	bl	1350 <memcpy@plt>
    2394:	38336abf 	strb	wzr, [x21, x19]
    2398:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    239c:	aa1503e0 	mov	x0, x21
    23a0:	97fffbf8 	bl	1380 <strlen@plt>
    23a4:	aa0003f3 	mov	x19, x0
    23a8:	528005c1 	mov	w1, #0x2e                  	// #46
    23ac:	aa1503e0 	mov	x0, x21
    23b0:	97fffc88 	bl	15d0 <strchr@plt>
    23b4:	b4000160 	cbz	x0, 23e0 <fwp_format_g.constprop.0+0x1dc>
    23b8:	b4000153 	cbz	x19, 23e0 <fwp_format_g.constprop.0+0x1dc>
    23bc:	d503201f 	nop
    23c0:	aa1303e1 	mov	x1, x19
    23c4:	d1000673 	sub	x19, x19, #0x1
    23c8:	38736aa0 	ldrb	w0, [x21, x19]
    23cc:	7100c01f 	cmp	w0, #0x30
    23d0:	54001001 	b.ne	25d0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    23d4:	38336abf 	strb	wzr, [x21, x19]
    23d8:	b5ffff53 	cbnz	x19, 23c0 <fwp_format_g.constprop.0+0x1bc>
    23dc:	d503201f 	nop
    23e0:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    23e4:	f947f400 	ldr	x0, [x0, #4072]
    23e8:	f94057e2 	ldr	x2, [sp, #168]
    23ec:	f9400001 	ldr	x1, [x0]
    23f0:	eb010042 	subs	x2, x2, x1
    23f4:	d2800001 	mov	x1, #0x0                   	// #0
    23f8:	54001061 	b.ne	2604 <fwp_format_g.constprop.0+0x400>  // b.any
    23fc:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2400:	a94c53f3 	ldp	x19, x20, [sp, #192]
    2404:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2408:	a94e63f7 	ldp	x23, x24, [sp, #224]
    240c:	a95073fb 	ldp	x27, x28, [sp, #256]
    2410:	fd408be8 	ldr	d8, [sp, #272]
    2414:	910483ff 	add	sp, sp, #0x120
    2418:	d65f03c0 	ret
    241c:	1e604100 	fmov	d0, d8
    2420:	710000bf 	cmp	w5, #0x0
    2424:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2428:	aa1503e0 	mov	x0, x21
    242c:	b0000024 	adrp	x4, 7000 <fwp_main_thread+0x920>
    2430:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2434:	9128e084 	add	x4, x4, #0xa38
    2438:	52800042 	mov	w2, #0x2                   	// #2
    243c:	d2803201 	mov	x1, #0x190                 	// #400
    2440:	97fffc08 	bl	1460 <__snprintf_chk@plt>
    2444:	17ffffd6 	b	239c <fwp_format_g.constprop.0+0x198>
    2448:	cb140273 	sub	x19, x19, x20
    244c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2450:	910183f9 	add	x25, sp, #0x60
    2454:	aa1303e2 	mov	x2, x19
    2458:	aa1403e1 	mov	x1, x20
    245c:	aa1903e0 	mov	x0, x25
    2460:	d2800803 	mov	x3, #0x40                  	// #64
    2464:	97fffbf7 	bl	1440 <__memcpy_chk@plt>
    2468:	38336b3f 	strb	wzr, [x25, x19]
    246c:	aa1903e0 	mov	x0, x25
    2470:	528005c1 	mov	w1, #0x2e                  	// #46
    2474:	97fffc57 	bl	15d0 <strchr@plt>
    2478:	b40001c0 	cbz	x0, 24b0 <fwp_format_g.constprop.0+0x2ac>
    247c:	b50000b3 	cbnz	x19, 2490 <fwp_format_g.constprop.0+0x28c>
    2480:	1400000c 	b	24b0 <fwp_format_g.constprop.0+0x2ac>
    2484:	381ff01f 	sturb	wzr, [x0, #-1]
    2488:	f1000673 	subs	x19, x19, #0x1
    248c:	54000120 	b.eq	24b0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    2490:	8b130320 	add	x0, x25, x19
    2494:	385ff001 	ldurb	w1, [x0, #-1]
    2498:	7100c03f 	cmp	w1, #0x30
    249c:	54ffff40 	b.eq	2484 <fwp_format_g.constprop.0+0x280>  // b.none
    24a0:	d1000673 	sub	x19, x19, #0x1
    24a4:	38736b20 	ldrb	w0, [x25, x19]
    24a8:	7100b81f 	cmp	w0, #0x2e
    24ac:	54000a80 	b.eq	25fc <fwp_format_g.constprop.0+0x3f8>  // b.none
    24b0:	710002ff 	cmp	w23, #0x0
    24b4:	528005a1 	mov	w1, #0x2d                  	// #45
    24b8:	aa1903e5 	mov	x5, x25
    24bc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    24c0:	aa1503e0 	mov	x0, x21
    24c4:	52800566 	mov	w6, #0x2b                  	// #43
    24c8:	b0000024 	adrp	x4, 7000 <fwp_main_thread+0x920>
    24cc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    24d0:	9128a084 	add	x4, x4, #0xa28
    24d4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    24d8:	52800042 	mov	w2, #0x2                   	// #2
    24dc:	d2803201 	mov	x1, #0x190                 	// #400
    24e0:	97fffbe0 	bl	1460 <__snprintf_chk@plt>
    24e4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    24e8:	17ffffbe 	b	23e0 <fwp_format_g.constprop.0+0x1dc>
    24ec:	52800605 	mov	w5, #0x30                  	// #48
    24f0:	390000e5 	strb	w5, [x7]
    24f4:	d100077b 	sub	x27, x27, #0x1
    24f8:	aa0303e1 	mov	x1, x3
    24fc:	aa1603e0 	mov	x0, x22
    2500:	aa1b03e3 	mov	x3, x27
    2504:	aa1a03e2 	mov	x2, x26
    2508:	f90007e6 	str	x6, [sp, #8]
    250c:	b90013e4 	str	w4, [sp, #16]
    2510:	8b1a02d6 	add	x22, x22, x26
    2514:	b9001be5 	str	w5, [sp, #24]
    2518:	97fffbca 	bl	1440 <__memcpy_chk@plt>
    251c:	f94007e6 	ldr	x6, [sp, #8]
    2520:	2a3703e7 	mvn	w7, w23
    2524:	b94013e4 	ldr	w4, [sp, #16]
    2528:	cb1b00c1 	sub	x1, x6, x27
    252c:	cb06037b 	sub	x27, x27, x6
    2530:	f101203f 	cmp	x1, #0x48
    2534:	d2800906 	mov	x6, #0x48                  	// #72
    2538:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    253c:	8b1b0023 	add	x3, x1, x27
    2540:	310006ff 	cmn	w23, #0x1
    2544:	54000220 	b.eq	2588 <fwp_format_g.constprop.0+0x384>  // b.none
    2548:	b9401be5 	ldr	w5, [sp, #24]
    254c:	d2800001 	mov	x1, #0x0                   	// #0
    2550:	f101207f 	cmp	x3, #0x48
    2554:	d1000462 	sub	x2, x3, #0x1
    2558:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    255c:	38216ac5 	strb	w5, [x22, x1]
    2560:	cb030003 	sub	x3, x0, x3
    2564:	91000421 	add	x1, x1, #0x1
    2568:	91000463 	add	x3, x3, #0x1
    256c:	eb00007f 	cmp	x3, x0
    2570:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    2574:	cb000063 	sub	x3, x3, x0
    2578:	8b020063 	add	x3, x3, x2
    257c:	6b0100ff 	cmp	w7, w1
    2580:	54fffe8c 	b.gt	2550 <fwp_format_g.constprop.0+0x34c>
    2584:	8b2742d6 	add	x22, x22, w7, uxtw
    2588:	f101207f 	cmp	x3, #0x48
    258c:	d2800905 	mov	x5, #0x48                  	// #72
    2590:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    2594:	aa1603e0 	mov	x0, x22
    2598:	cb0300a1 	sub	x1, x5, x3
    259c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    25a0:	91000421 	add	x1, x1, #0x1
    25a4:	d1000463 	sub	x3, x3, #0x1
    25a8:	eb05003f 	cmp	x1, x5
    25ac:	38001402 	strb	w2, [x0], #1
    25b0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    25b4:	93407f82 	sxtw	x2, w28
    25b8:	cb050025 	sub	x5, x1, x5
    25bc:	aa1303e1 	mov	x1, x19
    25c0:	8b0300a3 	add	x3, x5, x3
    25c4:	8b1802d3 	add	x19, x22, x24
    25c8:	97fffb9e 	bl	1440 <__memcpy_chk@plt>
    25cc:	17ffff6a 	b	2374 <fwp_format_g.constprop.0+0x170>
    25d0:	d1000421 	sub	x1, x1, #0x1
    25d4:	38616aa0 	ldrb	w0, [x21, x1]
    25d8:	7100b81f 	cmp	w0, #0x2e
    25dc:	54fff021 	b.ne	23e0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    25e0:	38216abf 	strb	wzr, [x21, x1]
    25e4:	17ffff7f 	b	23e0 <fwp_format_g.constprop.0+0x1dc>
    25e8:	910187e7 	add	x7, sp, #0x61
    25ec:	910183f9 	add	x25, sp, #0x60
    25f0:	d28008fb 	mov	x27, #0x47                  	// #71
    25f4:	390183e0 	strb	w0, [sp, #96]
    25f8:	17ffff3a 	b	22e0 <fwp_format_g.constprop.0+0xdc>
    25fc:	38336b3f 	strb	wzr, [x25, x19]
    2600:	17ffffac 	b	24b0 <fwp_format_g.constprop.0+0x2ac>
    2604:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2608:	97fffbba 	bl	14f0 <__stack_chk_fail@plt>
    260c:	d503201f 	nop

0000000000002610 <fwp_heap_report>:
    2610:	d105c3ff 	sub	sp, sp, #0x170
    2614:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    2618:	91134042 	add	x2, x2, #0x4d0
    261c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x15ff0>
    2620:	f947e821 	ldr	x1, [x1, #4048]
    2624:	a9117bfd 	stp	x29, x30, [sp, #272]
    2628:	910443fd 	add	x29, sp, #0x110
    262c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    2630:	f947f400 	ldr	x0, [x0, #4072]
    2634:	a9135bf5 	stp	x21, x22, [sp, #304]
    2638:	a91463f7 	stp	x23, x24, [sp, #320]
    263c:	a9156bf9 	stp	x25, x26, [sp, #336]
    2640:	6d1627e8 	stp	d8, d9, [sp, #352]
    2644:	fd4a1c48 	ldr	d8, [x2, #5176]
    2648:	fd4a2049 	ldr	d9, [x2, #5184]
    264c:	f9400036 	ldr	x22, [x1]
    2650:	f9400001 	ldr	x1, [x0]
    2654:	f90087e1 	str	x1, [sp, #264]
    2658:	d2800001 	mov	x1, #0x0                   	// #0
    265c:	f949e459 	ldr	x25, [x2, #5064]
    2660:	b0000021 	adrp	x1, 7000 <fwp_main_thread+0x920>
    2664:	f94a1057 	ldr	x23, [x2, #5152]
    2668:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    266c:	f94a1458 	ldr	x24, [x2, #5160]
    2670:	91290021 	add	x1, x1, #0xa40
    2674:	91292000 	add	x0, x0, #0xa48
    2678:	97fffb82 	bl	1480 <fopen@plt>
    267c:	b4000740 	cbz	x0, 2764 <fwp_heap_report+0x154>
    2680:	528daad5 	mov	w21, #0x6d56                	// #27990
    2684:	a91253f3 	stp	x19, x20, [sp, #288]
    2688:	aa0003f4 	mov	x20, x0
    268c:	910023f3 	add	x19, sp, #0x8
    2690:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2694:	72aae915 	movk	w21, #0x5748, lsl #16
    2698:	aa1403e2 	mov	x2, x20
    269c:	aa1303e0 	mov	x0, x19
    26a0:	52802001 	mov	w1, #0x100                 	// #256
    26a4:	97fffbff 	bl	16a0 <fgets@plt>
    26a8:	b4000280 	cbz	x0, 26f8 <fwp_heap_report+0xe8>
    26ac:	b9400261 	ldr	w1, [x19]
    26b0:	6b15003f 	cmp	w1, w21
    26b4:	54ffff21 	b.ne	2698 <fwp_heap_report+0x88>  // b.any
    26b8:	39401260 	ldrb	w0, [x19, #4]
    26bc:	7101341f 	cmp	w0, #0x4d
    26c0:	54fffec1 	b.ne	2698 <fwp_heap_report+0x88>  // b.any
    26c4:	394037e0 	ldrb	w0, [sp, #13]
    26c8:	7100e81f 	cmp	w0, #0x3a
    26cc:	54fffe61 	b.ne	2698 <fwp_heap_report+0x88>  // b.any
    26d0:	52800142 	mov	w2, #0xa                   	// #10
    26d4:	d2800001 	mov	x1, #0x0                   	// #0
    26d8:	91003be0 	add	x0, sp, #0xe
    26dc:	97fffbad 	bl	1590 <strtol@plt>
    26e0:	aa1403e2 	mov	x2, x20
    26e4:	aa0003fa 	mov	x26, x0
    26e8:	52802001 	mov	w1, #0x100                 	// #256
    26ec:	aa1303e0 	mov	x0, x19
    26f0:	97fffbec 	bl	16a0 <fgets@plt>
    26f4:	b5fffdc0 	cbnz	x0, 26ac <fwp_heap_report+0x9c>
    26f8:	aa1403e0 	mov	x0, x20
    26fc:	97fffb5d 	bl	1470 <fclose@plt>
    2700:	a95253f3 	ldp	x19, x20, [sp, #288]
    2704:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    2708:	f947f400 	ldr	x0, [x0, #4072]
    270c:	f94087e2 	ldr	x2, [sp, #264]
    2710:	f9400001 	ldr	x1, [x0]
    2714:	eb010042 	subs	x2, x2, x1
    2718:	d2800001 	mov	x1, #0x0                   	// #0
    271c:	54000281 	b.ne	276c <fwp_heap_report+0x15c>  // b.any
    2720:	a9517bfd 	ldp	x29, x30, [sp, #272]
    2724:	aa1a03e6 	mov	x6, x26
    2728:	aa1903e5 	mov	x5, x25
    272c:	aa1803e4 	mov	x4, x24
    2730:	a9556bf9 	ldp	x25, x26, [sp, #336]
    2734:	aa1703e3 	mov	x3, x23
    2738:	a95463f7 	ldp	x23, x24, [sp, #320]
    273c:	aa1603e0 	mov	x0, x22
    2740:	a9535bf5 	ldp	x21, x22, [sp, #304]
    2744:	1e604121 	fmov	d1, d9
    2748:	1e604100 	fmov	d0, d8
    274c:	b0000022 	adrp	x2, 7000 <fwp_main_thread+0x920>
    2750:	6d5627e8 	ldp	d8, d9, [sp, #352]
    2754:	9129a042 	add	x2, x2, #0xa68
    2758:	9105c3ff 	add	sp, sp, #0x170
    275c:	52800041 	mov	w1, #0x2                   	// #2
    2760:	17fffb80 	b	1560 <__fprintf_chk@plt>
    2764:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    2768:	17ffffe7 	b	2704 <fwp_heap_report+0xf4>
    276c:	a91253f3 	stp	x19, x20, [sp, #288]
    2770:	97fffb60 	bl	14f0 <__stack_chk_fail@plt>

0000000000002774 <fwp_heap_init>:
    2774:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2778:	90000183 	adrp	x3, 32000 <fwp_heap+0xb30>
    277c:	910f4061 	add	x1, x3, #0x3d0
    2780:	910003fd 	mov	x29, sp
    2784:	a90153f3 	stp	x19, x20, [sp, #16]
    2788:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xd10>
    278c:	91134262 	add	x2, x19, #0x4d0
    2790:	a9025bf5 	stp	x21, x22, [sp, #32]
    2794:	52800024 	mov	w4, #0x1                   	// #1
    2798:	52800200 	mov	w0, #0x10                  	// #16
    279c:	b913a444 	str	w4, [x2, #5028]
    27a0:	b8004420 	str	w0, [x1], #4
    27a4:	11004000 	add	w0, w0, #0x10
    27a8:	7104401f 	cmp	w0, #0x110
    27ac:	54ffffa1 	b.ne	27a0 <fwp_heap_init+0x2c>  // b.any
    27b0:	b0000022 	adrp	x2, 7000 <fwp_main_thread+0x920>
    27b4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    27b8:	90000181 	adrp	x1, 32000 <fwp_heap+0xb30>
    27bc:	91104021 	add	x1, x1, #0x410
    27c0:	3dc3b043 	ldr	q3, [x2, #3776]
    27c4:	d2800000 	mov	x0, #0x0                   	// #0
    27c8:	4e040401 	dup	v1.4s, v0.s[0]
    27cc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    27d0:	0f215400 	shl	v0.2s, v0.2s, #1
    27d4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    27d8:	3ca06821 	str	q1, [x1, x0]
    27dc:	91004000 	add	x0, x0, #0x10
    27e0:	f101801f 	cmp	x0, #0x60
    27e4:	54ffff21 	b.ne	27c8 <fwp_heap_init+0x54>  // b.any
    27e8:	90000184 	adrp	x4, 32000 <fwp_heap+0xb30>
    27ec:	910f4063 	add	x3, x3, #0x3d0
    27f0:	9111c084 	add	x4, x4, #0x470
    27f4:	91134266 	add	x6, x19, #0x4d0
    27f8:	d2800002 	mov	x2, #0x0                   	// #0
    27fc:	d2800000 	mov	x0, #0x0                   	// #0
    2800:	d2880205 	mov	x5, #0x4010                	// #16400
    2804:	d503201f 	nop
    2808:	910f0001 	add	x1, x0, #0x3c0
    280c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2810:	eb02003f 	cmp	x1, x2
    2814:	540000a2 	b.cs	2828 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    2818:	91000400 	add	x0, x0, #0x1
    281c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2820:	eb02003f 	cmp	x1, x2
    2824:	54ffffa3 	b.cc	2818 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    2828:	91004042 	add	x2, x2, #0x10
    282c:	38001480 	strb	w0, [x4], #1
    2830:	eb05005f 	cmp	x2, x5
    2834:	54fffea1 	b.ne	2808 <fwp_heap_init+0x94>  // b.any
    2838:	528000b5 	mov	w21, #0x5                   	// #5
    283c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    2840:	14000004 	b	2850 <fwp_heap_init+0xdc>
    2844:	d342fe94 	lsr	x20, x20, #2
    2848:	710006b5 	subs	w21, w21, #0x1
    284c:	54000720 	b.eq	2930 <fwp_heap_init+0x1bc>  // b.none
    2850:	91404296 	add	x22, x20, #0x10, lsl #12
    2854:	d2800005 	mov	x5, #0x0                   	// #0
    2858:	aa1603e1 	mov	x1, x22
    285c:	12800004 	mov	w4, #0xffffffff            	// #-1
    2860:	52880443 	mov	w3, #0x4022                	// #16418
    2864:	52800002 	mov	w2, #0x0                   	// #0
    2868:	d2800000 	mov	x0, #0x0                   	// #0
    286c:	97fffb45 	bl	1580 <mmap@plt>
    2870:	aa0003e6 	mov	x6, x0
    2874:	b100041f 	cmn	x0, #0x1
    2878:	54fffe60 	b.eq	2844 <fwp_heap_init+0xd0>  // b.none
    287c:	b40005a0 	cbz	x0, 2930 <fwp_heap_init+0x1bc>
    2880:	d350fe94 	lsr	x20, x20, #16
    2884:	d29fffe0 	mov	x0, #0xffff                	// #65535
    2888:	8b0000c7 	add	x7, x6, x0
    288c:	91134275 	add	x21, x19, #0x4d0
    2890:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    2894:	8b140a81 	add	x1, x20, x20, lsl #2
    2898:	d2800005 	mov	x5, #0x0                   	// #0
    289c:	12800004 	mov	w4, #0xffffffff            	// #-1
    28a0:	d37df021 	lsl	x1, x1, #3
    28a4:	52880443 	mov	w3, #0x4022                	// #16418
    28a8:	52800002 	mov	w2, #0x0                   	// #0
    28ac:	d2800000 	mov	x0, #0x0                   	// #0
    28b0:	f909daa7 	str	x7, [x21, #5040]
    28b4:	f909dea6 	str	x6, [x21, #5048]
    28b8:	f909e2b6 	str	x22, [x21, #5056]
    28bc:	f909eab4 	str	x20, [x21, #5072]
    28c0:	f90a02a1 	str	x1, [x21, #5120]
    28c4:	97fffb2f 	bl	1580 <mmap@plt>
    28c8:	aa0003e1 	mov	x1, x0
    28cc:	b100041f 	cmn	x0, #0x1
    28d0:	54000300 	b.eq	2930 <fwp_heap_init+0x1bc>  // b.none
    28d4:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    28d8:	912c6000 	add	x0, x0, #0xb18
    28dc:	f909fea1 	str	x1, [x21, #5112]
    28e0:	97fffb68 	bl	1680 <getenv@plt>
    28e4:	52800002 	mov	w2, #0x0                   	// #0
    28e8:	aa0003e1 	mov	x1, x0
    28ec:	b40000e0 	cbz	x0, 2908 <fwp_heap_init+0x194>
    28f0:	39400000 	ldrb	w0, [x0]
    28f4:	340000a0 	cbz	w0, 2908 <fwp_heap_init+0x194>
    28f8:	7100c000 	subs	w0, w0, #0x30
    28fc:	54000120 	b.eq	2920 <fwp_heap_init+0x1ac>  // b.none
    2900:	7100001f 	cmp	w0, #0x0
    2904:	1a9f07e2 	cset	w2, ne	// ne = any
    2908:	91134273 	add	x19, x19, #0x4d0
    290c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2910:	b913aa62 	str	w2, [x19, #5032]
    2914:	a94153f3 	ldp	x19, x20, [sp, #16]
    2918:	a8c37bfd 	ldp	x29, x30, [sp], #48
    291c:	d65f03c0 	ret
    2920:	39400420 	ldrb	w0, [x1, #1]
    2924:	7100001f 	cmp	w0, #0x0
    2928:	1a9f07e2 	cset	w2, ne	// ne = any
    292c:	17fffff7 	b	2908 <fwp_heap_init+0x194>
    2930:	97fffcb8 	bl	1c10 <fwp_heap_oom>

0000000000002934 <fwp_args45>:
    2934:	d65f03c0 	ret
    2938:	d503201f 	nop
    293c:	d503201f 	nop

0000000000002940 <fwp_args69>:
    2940:	d65f03c0 	ret

0000000000002944 <fwp_wake_io>:
    2944:	d00000e9 	adrp	x9, 20000 <__data_start>
    2948:	9100c122 	add	x2, x9, #0x30
    294c:	f9400001 	ldr	x1, [x0]
    2950:	5280000a 	mov	w10, #0x0                   	// #0
    2954:	f9401046 	ldr	x6, [x2, #32]
    2958:	52800008 	mov	w8, #0x0                   	// #0
    295c:	4f000400 	movi	v0.4s, #0x0
    2960:	52800027 	mov	w7, #0x1                   	// #1
    2964:	aa0103e2 	mov	x2, x1
    2968:	b4000321 	cbz	x1, 29cc <fwp_wake_io+0x88>
    296c:	f9408c25 	ldr	x5, [x1, #280]
    2970:	39015c27 	strb	w7, [x1, #87]
    2974:	b4000165 	cbz	x5, 29a0 <fwp_wake_io+0x5c>
    2978:	a9520c24 	ldp	x4, x3, [x1, #288]
    297c:	b4000364 	cbz	x4, 29e8 <fwp_wake_io+0xa4>
    2980:	f9009483 	str	x3, [x4, #296]
    2984:	f9409423 	ldr	x3, [x1, #296]
    2988:	b4000043 	cbz	x3, 2990 <fwp_wake_io+0x4c>
    298c:	f9009064 	str	x4, [x3, #288]
    2990:	91080023 	add	x3, x1, #0x200
    2994:	f900943f 	str	xzr, [x1, #296]
    2998:	3c918060 	stur	q0, [x3, #-232]
    299c:	f9400001 	ldr	x1, [x0]
    29a0:	f9402843 	ldr	x3, [x2, #80]
    29a4:	f2001c7f 	tst	x3, #0xff000000ff
    29a8:	54fffde1 	b.ne	2964 <fwp_wake_io+0x20>  // b.any
    29ac:	39015047 	strb	w7, [x2, #84]
    29b0:	f900805f 	str	xzr, [x2, #256]
    29b4:	b40001e6 	cbz	x6, 29f0 <fwp_wake_io+0xac>
    29b8:	f90080c2 	str	x2, [x6, #256]
    29bc:	aa0203e6 	mov	x6, x2
    29c0:	52800028 	mov	w8, #0x1                   	// #1
    29c4:	aa0103e2 	mov	x2, x1
    29c8:	b5fffd21 	cbnz	x1, 296c <fwp_wake_io+0x28>
    29cc:	3400006a 	cbz	w10, 29d8 <fwp_wake_io+0x94>
    29d0:	9100c120 	add	x0, x9, #0x30
    29d4:	f900140b 	str	x11, [x0, #40]
    29d8:	34000068 	cbz	w8, 29e4 <fwp_wake_io+0xa0>
    29dc:	9100c129 	add	x9, x9, #0x30
    29e0:	f9001126 	str	x6, [x9, #32]
    29e4:	d65f03c0 	ret
    29e8:	f90000a3 	str	x3, [x5]
    29ec:	17ffffe7 	b	2988 <fwp_wake_io+0x44>
    29f0:	aa0203eb 	mov	x11, x2
    29f4:	5280002a 	mov	w10, #0x1                   	// #1
    29f8:	17fffff1 	b	29bc <fwp_wake_io+0x78>
    29fc:	d503201f 	nop

0000000000002a00 <fwp_poll_events>:
    2a00:	d10103ff 	sub	sp, sp, #0x40
    2a04:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    2a08:	f947f400 	ldr	x0, [x0, #4072]
    2a0c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2a10:	910083fd 	add	x29, sp, #0x20
    2a14:	a90353f3 	stp	x19, x20, [sp, #48]
    2a18:	d00000f4 	adrp	x20, 20000 <__data_start>
    2a1c:	f9400001 	ldr	x1, [x0]
    2a20:	f9000fe1 	str	x1, [sp, #24]
    2a24:	d2800001 	mov	x1, #0x0                   	// #0
    2a28:	97fffdce 	bl	2160 <fwp_now_ns>
    2a2c:	9100c281 	add	x1, x20, #0x30
    2a30:	f9401833 	ldr	x19, [x1, #48]
    2a34:	b4000e93 	cbz	x19, 2c04 <fwp_poll_events+0x204>
    2a38:	aa1303e1 	mov	x1, x19
    2a3c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2a40:	14000005 	b	2a54 <fwp_poll_events+0x54>
    2a44:	f9408821 	ldr	x1, [x1, #272]
    2a48:	eb03005f 	cmp	x2, x3
    2a4c:	9a83d042 	csel	x2, x2, x3, le
    2a50:	b40000c1 	cbz	x1, 2a68 <fwp_poll_events+0x68>
    2a54:	f9403423 	ldr	x3, [x1, #104]
    2a58:	b6ffff62 	tbz	x2, #63, 2a44 <fwp_poll_events+0x44>
    2a5c:	f9408821 	ldr	x1, [x1, #272]
    2a60:	aa0303e2 	mov	x2, x3
    2a64:	b5ffff81 	cbnz	x1, 2a54 <fwp_poll_events+0x54>
    2a68:	b7f80ce2 	tbnz	x2, #63, 2c04 <fwp_poll_events+0x204>
    2a6c:	cb000042 	sub	x2, x2, x0
    2a70:	f100005f 	cmp	x2, #0x0
    2a74:	540005cd 	b.le	2b2c <fwp_poll_events+0x12c>
    2a78:	d2869b60 	mov	x0, #0x34db                	// #13531
    2a7c:	d2884801 	mov	x1, #0x4240                	// #16960
    2a80:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2a84:	f2a001e1 	movk	x1, #0xf, lsl #16
    2a88:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2a8c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2a90:	f2e86360 	movk	x0, #0x431b, lsl #48
    2a94:	9b407c40 	smulh	x0, x2, x0
    2a98:	9352fc00 	asr	x0, x0, #18
    2a9c:	cb82fc00 	sub	x0, x0, x2, asr #63
    2aa0:	9b018802 	msub	x2, x0, x1, x2
    2aa4:	f100005f 	cmp	x2, #0x0
    2aa8:	9a800400 	cinc	x0, x0, ne	// ne = any
    2aac:	eb03001f 	cmp	x0, x3
    2ab0:	54000a0c 	b.gt	2bf0 <fwp_poll_events+0x1f0>
    2ab4:	340003c0 	cbz	w0, 2b2c <fwp_poll_events+0x12c>
    2ab8:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2abc:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2ac0:	72a20c42 	movk	w2, #0x1062, lsl #16
    2ac4:	9ba27c02 	umull	x2, w0, w2
    2ac8:	d366fc43 	lsr	x3, x2, #38
    2acc:	aa0303e2 	mov	x2, x3
    2ad0:	1b048063 	msub	w3, w3, w4, w0
    2ad4:	9b217c63 	smull	x3, w3, w1
    2ad8:	d2800001 	mov	x1, #0x0                   	// #0
    2adc:	910023e0 	add	x0, sp, #0x8
    2ae0:	a9008fe2 	stp	x2, x3, [sp, #8]
    2ae4:	97fffab7 	bl	15c0 <nanosleep@plt>
    2ae8:	9100c280 	add	x0, x20, #0x30
    2aec:	f9401813 	ldr	x19, [x0, #48]
    2af0:	97fffd9c 	bl	2160 <fwp_now_ns>
    2af4:	aa0003e6 	mov	x6, x0
    2af8:	b50001f3 	cbnz	x19, 2b34 <fwp_poll_events+0x134>
    2afc:	d503201f 	nop
    2b00:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    2b04:	f947f400 	ldr	x0, [x0, #4072]
    2b08:	f9400fe2 	ldr	x2, [sp, #24]
    2b0c:	f9400001 	ldr	x1, [x0]
    2b10:	eb010042 	subs	x2, x2, x1
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	540008c1 	b.ne	2c30 <fwp_poll_events+0x230>  // b.any
    2b1c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2b20:	a94353f3 	ldp	x19, x20, [sp, #48]
    2b24:	910103ff 	add	sp, sp, #0x40
    2b28:	d65f03c0 	ret
    2b2c:	97fffd8d 	bl	2160 <fwp_now_ns>
    2b30:	aa0003e6 	mov	x6, x0
    2b34:	4f000400 	movi	v0.4s, #0x0
    2b38:	9100c288 	add	x8, x20, #0x30
    2b3c:	52800027 	mov	w7, #0x1                   	// #1
    2b40:	f9403661 	ldr	x1, [x19, #104]
    2b44:	aa1303e5 	mov	x5, x19
    2b48:	f9408a73 	ldr	x19, [x19, #272]
    2b4c:	eb06003f 	cmp	x1, x6
    2b50:	5400032c 	b.gt	2bb4 <fwp_poll_events+0x1b4>
    2b54:	394154a0 	ldrb	w0, [x5, #85]
    2b58:	36000120 	tbz	w0, #0, 2b7c <fwp_poll_events+0x17c>
    2b5c:	f94084a0 	ldr	x0, [x5, #264]
    2b60:	b40003c0 	cbz	x0, 2bd8 <fwp_poll_events+0x1d8>
    2b64:	f9008813 	str	x19, [x0, #272]
    2b68:	b4000053 	cbz	x19, 2b70 <fwp_poll_events+0x170>
    2b6c:	f9008660 	str	x0, [x19, #264]
    2b70:	910800a0 	add	x0, x5, #0x200
    2b74:	390154bf 	strb	wzr, [x5, #85]
    2b78:	3c908000 	stur	q0, [x0, #-248]
    2b7c:	f94030a0 	ldr	x0, [x5, #96]
    2b80:	390158a7 	strb	w7, [x5, #86]
    2b84:	f100001f 	cmp	x0, #0x0
    2b88:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2b8c:	5400018d 	b.le	2bbc <fwp_poll_events+0x1bc>
    2b90:	f94028a0 	ldr	x0, [x5, #80]
    2b94:	f2001c1f 	tst	x0, #0xff000000ff
    2b98:	540000e1 	b.ne	2bb4 <fwp_poll_events+0x1b4>  // b.any
    2b9c:	f9401100 	ldr	x0, [x8, #32]
    2ba0:	390150a7 	strb	w7, [x5, #84]
    2ba4:	f90080bf 	str	xzr, [x5, #256]
    2ba8:	b40001e0 	cbz	x0, 2be4 <fwp_poll_events+0x1e4>
    2bac:	f9001105 	str	x5, [x8, #32]
    2bb0:	f9008005 	str	x5, [x0, #256]
    2bb4:	b5fffc73 	cbnz	x19, 2b40 <fwp_poll_events+0x140>
    2bb8:	17ffffd2 	b	2b00 <fwp_poll_events+0x100>
    2bbc:	394144a0 	ldrb	w0, [x5, #81]
    2bc0:	3707fe80 	tbnz	w0, #0, 2b90 <fwp_poll_events+0x190>
    2bc4:	394140a0 	ldrb	w0, [x5, #80]
    2bc8:	3707fe40 	tbnz	w0, #0, 2b90 <fwp_poll_events+0x190>
    2bcc:	aa0503e0 	mov	x0, x5
    2bd0:	97fffd10 	bl	2010 <fwp_cancel_tree.part.0>
    2bd4:	17ffffef 	b	2b90 <fwp_poll_events+0x190>
    2bd8:	9100c281 	add	x1, x20, #0x30
    2bdc:	f9001833 	str	x19, [x1, #48]
    2be0:	17ffffe2 	b	2b68 <fwp_poll_events+0x168>
    2be4:	f9001105 	str	x5, [x8, #32]
    2be8:	f9001505 	str	x5, [x8, #40]
    2bec:	17fffff2 	b	2bb4 <fwp_poll_events+0x1b4>
    2bf0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2bf4:	d2989362 	mov	x2, #0xc49b                	// #50331
    2bf8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2bfc:	f2a00402 	movk	x2, #0x20, lsl #16
    2c00:	17ffffb6 	b	2ad8 <fwp_poll_events+0xd8>
    2c04:	97fffbf3 	bl	1bd0 <fwp_flush>
    2c08:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x15ff0>
    2c0c:	f947e863 	ldr	x3, [x3, #4048]
    2c10:	d2800562 	mov	x2, #0x2b                  	// #43
    2c14:	d2800021 	mov	x1, #0x1                   	// #1
    2c18:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    2c1c:	912ca000 	add	x0, x0, #0xb28
    2c20:	f9400063 	ldr	x3, [x3]
    2c24:	97fffa73 	bl	15f0 <fwrite@plt>
    2c28:	52800ca0 	mov	w0, #0x65                  	// #101
    2c2c:	97fff9dd 	bl	13a0 <exit@plt>
    2c30:	97fffa30 	bl	14f0 <__stack_chk_fail@plt>

0000000000002c34 <fwp_rc_wide_dup>:
    2c34:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2c38:	910003fd 	mov	x29, sp
    2c3c:	a90153f3 	stp	x19, x20, [sp, #16]
    2c40:	aa0003f3 	mov	x19, x0
    2c44:	ca404400 	eor	x0, x0, x0, lsr #17
    2c48:	f90013f5 	str	x21, [sp, #32]
    2c4c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    2c50:	ca402400 	eor	x0, x0, x0, lsr #9
    2c54:	911342a2 	add	x2, x21, #0x4d0
    2c58:	92401c00 	and	x0, x0, #0xff
    2c5c:	910a2403 	add	x3, x0, #0x289
    2c60:	8b000c40 	add	x0, x2, x0, lsl #3
    2c64:	8b030c54 	add	x20, x2, x3, lsl #3
    2c68:	f94a2401 	ldr	x1, [x0, #5192]
    2c6c:	b50000a1 	cbnz	x1, 2c80 <fwp_rc_wide_dup+0x4c>
    2c70:	1400002d 	b	2d24 <fwp_rc_wide_dup+0xf0>
    2c74:	91004034 	add	x20, x1, #0x10
    2c78:	f9400821 	ldr	x1, [x1, #16]
    2c7c:	b4000241 	cbz	x1, 2cc4 <fwp_rc_wide_dup+0x90>
    2c80:	f9400022 	ldr	x2, [x1]
    2c84:	eb02027f 	cmp	x19, x2
    2c88:	54ffff61 	b.ne	2c74 <fwp_rc_wide_dup+0x40>  // b.any
    2c8c:	f9400281 	ldr	x1, [x20]
    2c90:	39400260 	ldrb	w0, [x19]
    2c94:	7103f81f 	cmp	w0, #0xfe
    2c98:	54000220 	b.eq	2cdc <fwp_rc_wide_dup+0xa8>  // b.none
    2c9c:	b40001a1 	cbz	x1, 2cd0 <fwp_rc_wide_dup+0x9c>
    2ca0:	f9400420 	ldr	x0, [x1, #8]
    2ca4:	b100041f 	cmn	x0, #0x1
    2ca8:	540004a0 	b.eq	2d3c <fwp_rc_wide_dup+0x108>  // b.none
    2cac:	91000400 	add	x0, x0, #0x1
    2cb0:	f9000420 	str	x0, [x1, #8]
    2cb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    2cb8:	f94013f5 	ldr	x21, [sp, #32]
    2cbc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2cc0:	d65f03c0 	ret
    2cc4:	39400260 	ldrb	w0, [x19]
    2cc8:	7103f81f 	cmp	w0, #0xfe
    2ccc:	540000a0 	b.eq	2ce0 <fwp_rc_wide_dup+0xac>  // b.none
    2cd0:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    2cd4:	912e0000 	add	x0, x0, #0xb80
    2cd8:	97fffd12 	bl	2120 <fwp_trap>
    2cdc:	b5000281 	cbnz	x1, 2d2c <fwp_rc_wide_dup+0xf8>
    2ce0:	d2800300 	mov	x0, #0x18                  	// #24
    2ce4:	97fff9eb 	bl	1490 <malloc@plt>
    2ce8:	b4000280 	cbz	x0, 2d38 <fwp_rc_wide_dup+0x104>
    2cec:	d2801fe1 	mov	x1, #0xff                  	// #255
    2cf0:	a9000413 	stp	x19, x1, [x0]
    2cf4:	911342b5 	add	x21, x21, #0x4d0
    2cf8:	f900081f 	str	xzr, [x0, #16]
    2cfc:	12800001 	mov	w1, #0xffffffff            	// #-1
    2d00:	f9000280 	str	x0, [x20]
    2d04:	39000261 	strb	w1, [x19]
    2d08:	f94e26a0 	ldr	x0, [x21, #7240]
    2d0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    2d10:	91000400 	add	x0, x0, #0x1
    2d14:	f90e26a0 	str	x0, [x21, #7240]
    2d18:	f94013f5 	ldr	x21, [sp, #32]
    2d1c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2d20:	d65f03c0 	ret
    2d24:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    2d28:	17ffffda 	b	2c90 <fwp_rc_wide_dup+0x5c>
    2d2c:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    2d30:	912d6000 	add	x0, x0, #0xb58
    2d34:	97fffcfb 	bl	2120 <fwp_trap>
    2d38:	97fffbb6 	bl	1c10 <fwp_heap_oom>
    2d3c:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    2d40:	912ea000 	add	x0, x0, #0xba8
    2d44:	97fffcf7 	bl	2120 <fwp_trap>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <fwp_rc_forget_slot>:
    2d50:	aa0003e1 	mov	x1, x0
    2d54:	39400000 	ldrb	w0, [x0]
    2d58:	7103fc1f 	cmp	w0, #0xff
    2d5c:	54000040 	b.eq	2d64 <fwp_rc_forget_slot+0x14>  // b.none
    2d60:	d65f03c0 	ret
    2d64:	ca414420 	eor	x0, x1, x1, lsr #17
    2d68:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d6c:	ca402400 	eor	x0, x0, x0, lsr #9
    2d70:	910003fd 	mov	x29, sp
    2d74:	92401c00 	and	x0, x0, #0xff
    2d78:	f9000bf3 	str	x19, [sp, #16]
    2d7c:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xd10>
    2d80:	91134262 	add	x2, x19, #0x4d0
    2d84:	910a2403 	add	x3, x0, #0x289
    2d88:	8b000c40 	add	x0, x2, x0, lsl #3
    2d8c:	8b030c43 	add	x3, x2, x3, lsl #3
    2d90:	f94a2400 	ldr	x0, [x0, #5192]
    2d94:	b50000a0 	cbnz	x0, 2da8 <fwp_rc_forget_slot+0x58>
    2d98:	14000011 	b	2ddc <fwp_rc_forget_slot+0x8c>
    2d9c:	91004003 	add	x3, x0, #0x10
    2da0:	f9400800 	ldr	x0, [x0, #16]
    2da4:	b40001c0 	cbz	x0, 2ddc <fwp_rc_forget_slot+0x8c>
    2da8:	f9400002 	ldr	x2, [x0]
    2dac:	eb02003f 	cmp	x1, x2
    2db0:	54ffff61 	b.ne	2d9c <fwp_rc_forget_slot+0x4c>  // b.any
    2db4:	f9400801 	ldr	x1, [x0, #16]
    2db8:	91134273 	add	x19, x19, #0x4d0
    2dbc:	f9000061 	str	x1, [x3]
    2dc0:	97fff9fc 	bl	15b0 <free@plt>
    2dc4:	f94e2660 	ldr	x0, [x19, #7240]
    2dc8:	d1000400 	sub	x0, x0, #0x1
    2dcc:	f90e2660 	str	x0, [x19, #7240]
    2dd0:	f9400bf3 	ldr	x19, [sp, #16]
    2dd4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2dd8:	d65f03c0 	ret
    2ddc:	b0000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    2de0:	912e0000 	add	x0, x0, #0xb80
    2de4:	97fffccf 	bl	2120 <fwp_trap>
    2de8:	d503201f 	nop
    2dec:	d503201f 	nop

0000000000002df0 <fwp_rc_prepare_chunk>:
    2df0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2df4:	910003fd 	mov	x29, sp
    2df8:	a9025bf5 	stp	x21, x22, [sp, #32]
    2dfc:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xd10>
    2e00:	911342c2 	add	x2, x22, #0x4d0
    2e04:	b9401c03 	ldr	w3, [x0, #28]
    2e08:	aa0103f5 	mov	x21, x1
    2e0c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e10:	aa0003f4 	mov	x20, x0
    2e14:	f94e2440 	ldr	x0, [x2, #7240]
    2e18:	b4000440 	cbz	x0, 2ea0 <fwp_rc_prepare_chunk+0xb0>
    2e1c:	d2800013 	mov	x19, #0x0                   	// #0
    2e20:	35000203 	cbnz	w3, 2e60 <fwp_rc_prepare_chunk+0x70>
    2e24:	b4000361 	cbz	x1, 2e90 <fwp_rc_prepare_chunk+0xa0>
    2e28:	f9401280 	ldr	x0, [x20, #32]
    2e2c:	97fff9e1 	bl	15b0 <free@plt>
    2e30:	aa1503e0 	mov	x0, x21
    2e34:	d2800021 	mov	x1, #0x1                   	// #1
    2e38:	97fff9a6 	bl	14d0 <calloc@plt>
    2e3c:	f9001280 	str	x0, [x20, #32]
    2e40:	b5000460 	cbnz	x0, 2ecc <fwp_rc_prepare_chunk+0xdc>
    2e44:	97fffb73 	bl	1c10 <fwp_heap_oom>
    2e48:	97ffffc2 	bl	2d50 <fwp_rc_forget_slot>
    2e4c:	91000673 	add	x19, x19, #0x1
    2e50:	b9401e83 	ldr	w3, [x20, #28]
    2e54:	eb13007f 	cmp	x3, x19
    2e58:	54000169 	b.ls	2e84 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2e5c:	d503201f 	nop
    2e60:	f9401283 	ldr	x3, [x20, #32]
    2e64:	8b130060 	add	x0, x3, x19
    2e68:	38736863 	ldrb	w3, [x3, x19]
    2e6c:	7103fc7f 	cmp	w3, #0xff
    2e70:	54fffec0 	b.eq	2e48 <fwp_rc_prepare_chunk+0x58>  // b.none
    2e74:	b9401e83 	ldr	w3, [x20, #28]
    2e78:	91000673 	add	x19, x19, #0x1
    2e7c:	eb13007f 	cmp	x3, x19
    2e80:	54ffff08 	b.hi	2e60 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2e84:	eb0302bf 	cmp	x21, x3
    2e88:	54000121 	b.ne	2eac <fwp_rc_prepare_chunk+0xbc>  // b.any
    2e8c:	b5000335 	cbnz	x21, 2ef0 <fwp_rc_prepare_chunk+0x100>
    2e90:	a94153f3 	ldp	x19, x20, [sp, #16]
    2e94:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2e98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2e9c:	d65f03c0 	ret
    2ea0:	2a0303e3 	mov	w3, w3
    2ea4:	eb0302bf 	cmp	x21, x3
    2ea8:	54ffff20 	b.eq	2e8c <fwp_rc_prepare_chunk+0x9c>  // b.none
    2eac:	911342c2 	add	x2, x22, #0x4d0
    2eb0:	f9401280 	ldr	x0, [x20, #32]
    2eb4:	f94e2841 	ldr	x1, [x2, #7248]
    2eb8:	cb030021 	sub	x1, x1, x3
    2ebc:	f90e2841 	str	x1, [x2, #7248]
    2ec0:	97fff9bc 	bl	15b0 <free@plt>
    2ec4:	b5fffb75 	cbnz	x21, 2e30 <fwp_rc_prepare_chunk+0x40>
    2ec8:	f900129f 	str	xzr, [x20, #32]
    2ecc:	911342d6 	add	x22, x22, #0x4d0
    2ed0:	f94e2ac0 	ldr	x0, [x22, #7248]
    2ed4:	b9001e95 	str	w21, [x20, #28]
    2ed8:	a94153f3 	ldp	x19, x20, [sp, #16]
    2edc:	8b150000 	add	x0, x0, x21
    2ee0:	f90e2ac0 	str	x0, [x22, #7248]
    2ee4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ee8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2eec:	d65f03c0 	ret
    2ef0:	f9401280 	ldr	x0, [x20, #32]
    2ef4:	aa1503e2 	mov	x2, x21
    2ef8:	a94153f3 	ldp	x19, x20, [sp, #16]
    2efc:	52800001 	mov	w1, #0x0                   	// #0
    2f00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f04:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f08:	17fff96e 	b	14c0 <memset@plt>
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_heap_refill>:
    2f10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2f14:	910003fd 	mov	x29, sp
    2f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    2f1c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    2f20:	911342b5 	add	x21, x21, #0x4d0
    2f24:	aa0003f6 	mov	x22, x0
    2f28:	d2800020 	mov	x0, #0x1                   	// #1
    2f2c:	a90153f3 	stp	x19, x20, [sp, #16]
    2f30:	a90363f7 	stp	x23, x24, [sp, #48]
    2f34:	2a0103f7 	mov	w23, w1
    2f38:	2a0203f8 	mov	w24, w2
    2f3c:	97fffb75 	bl	1d10 <fwp_heap_chunks>
    2f40:	aa0003f3 	mov	x19, x0
    2f44:	f949fea2 	ldr	x2, [x21, #5112]
    2f48:	8b000800 	add	x0, x0, x0, lsl #2
    2f4c:	2a1703e1 	mov	w1, w23
    2f50:	52800025 	mov	w5, #0x1                   	// #1
    2f54:	d37df000 	lsl	x0, x0, #3
    2f58:	910f0021 	add	x1, x1, #0x3c0
    2f5c:	8b000054 	add	x20, x2, x0
    2f60:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2f64:	52a00024 	mov	w4, #0x10000               	// #65536
    2f68:	38206845 	strb	w5, [x2, x0]
    2f6c:	aa1403e0 	mov	x0, x20
    2f70:	39000698 	strb	w24, [x20, #1]
    2f74:	39000a97 	strb	w23, [x20, #2]
    2f78:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2f7c:	b9000681 	str	w1, [x20, #4]
    2f80:	2a0103e5 	mov	w5, w1
    2f84:	8b0300a2 	add	x2, x5, x3
    2f88:	1ac10881 	udiv	w1, w4, w1
    2f8c:	9ac50842 	udiv	x2, x2, x5
    2f90:	b9000a81 	str	w1, [x20, #8]
    2f94:	92404021 	and	x1, x1, #0x1ffff
    2f98:	b9001a82 	str	w2, [x20, #24]
    2f9c:	97ffff95 	bl	2df0 <fwp_rc_prepare_chunk>
    2fa0:	f949daa0 	ldr	x0, [x21, #5040]
    2fa4:	29408a81 	ldp	w1, w2, [x20, #4]
    2fa8:	8b134000 	add	x0, x0, x19, lsl #16
    2fac:	a94153f3 	ldp	x19, x20, [sp, #16]
    2fb0:	8b214003 	add	x3, x0, w1, uxtw
    2fb4:	9ba20021 	umaddl	x1, w1, w2, x0
    2fb8:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fbc:	a90086c3 	stp	x3, x1, [x22, #8]
    2fc0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2fc4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2fc8:	d65f03c0 	ret
    2fcc:	d503201f 	nop

0000000000002fd0 <fwp_mem_free>:
    2fd0:	b40003c0 	cbz	x0, 3048 <fwp_mem_free+0x78>
    2fd4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    2fd8:	910003fd 	mov	x29, sp
    2fdc:	a9025bf5 	stp	x21, x22, [sp, #32]
    2fe0:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    2fe4:	911342a1 	add	x1, x21, #0x4d0
    2fe8:	a90153f3 	stp	x19, x20, [sp, #16]
    2fec:	aa0003f3 	mov	x19, x0
    2ff0:	f949d823 	ldr	x3, [x1, #5040]
    2ff4:	f949ec22 	ldr	x2, [x1, #5080]
    2ff8:	cb030000 	sub	x0, x0, x3
    2ffc:	eb02401f 	cmp	x0, x2, lsl #16
    3000:	540001c2 	b.cs	3038 <fwp_mem_free+0x68>  // b.hs, b.nlast
    3004:	d350fc16 	lsr	x22, x0, #16
    3008:	a90363f7 	stp	x23, x24, [sp, #48]
    300c:	f949fc22 	ldr	x2, [x1, #5112]
    3010:	8b160ad4 	add	x20, x22, x22, lsl #2
    3014:	d37df294 	lsl	x20, x20, #3
    3018:	ab140057 	adds	x23, x2, x20
    301c:	540000c0 	b.eq	3034 <fwp_mem_free+0x64>  // b.none
    3020:	38746842 	ldrb	w2, [x2, x20]
    3024:	7100045f 	cmp	w2, #0x1
    3028:	54000120 	b.eq	304c <fwp_mem_free+0x7c>  // b.none
    302c:	7100085f 	cmp	w2, #0x2
    3030:	540005e0 	b.eq	30ec <fwp_mem_free+0x11c>  // b.none
    3034:	a94363f7 	ldp	x23, x24, [sp, #48]
    3038:	a94153f3 	ldp	x19, x20, [sp, #16]
    303c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3040:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3044:	d65f03c0 	ret
    3048:	d65f03c0 	ret
    304c:	f94012f8 	ldr	x24, [x23, #32]
    3050:	b94006e1 	ldr	w1, [x23, #4]
    3054:	f90023f9 	str	x25, [sp, #64]
    3058:	2a0103e2 	mov	w2, w1
    305c:	394006f9 	ldrb	w25, [x23, #1]
    3060:	39400af4 	ldrb	w20, [x23, #2]
    3064:	b4000158 	cbz	x24, 308c <fwp_mem_free+0xbc>
    3068:	92403e76 	and	x22, x19, #0xffff
    306c:	9ac20ad6 	udiv	x22, x22, x2
    3070:	38766b01 	ldrb	w1, [x24, x22]
    3074:	8b160300 	add	x0, x24, x22
    3078:	7103fc3f 	cmp	w1, #0xff
    307c:	54000980 	b.eq	31ac <fwp_mem_free+0x1dc>  // b.none
    3080:	38366b1f 	strb	wzr, [x24, x22]
    3084:	b94006e1 	ldr	w1, [x23, #4]
    3088:	2a0103e2 	mov	w2, w1
    308c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    3090:	d37f1e83 	ubfiz	x3, x20, #1, #8
    3094:	cb390000 	sub	x0, x0, w25, uxtb
    3098:	8b340074 	add	x20, x3, w20, uxtb
    309c:	911342b5 	add	x21, x21, #0x4d0
    30a0:	1e630021 	ucvtf	d1, w1
    30a4:	d37ae400 	lsl	x0, x0, #6
    30a8:	8b140c14 	add	x20, x0, x20, lsl #3
    30ac:	a94363f7 	ldp	x23, x24, [sp, #48]
    30b0:	f8746aa0 	ldr	x0, [x21, x20]
    30b4:	f94023f9 	ldr	x25, [sp, #64]
    30b8:	aa2003e0 	mvn	x0, x0
    30bc:	fd4a22a0 	ldr	d0, [x21, #5184]
    30c0:	f9000260 	str	x0, [x19]
    30c4:	f8346ab3 	str	x19, [x21, x20]
    30c8:	f94a12a0 	ldr	x0, [x21, #5152]
    30cc:	1e612800 	fadd	d0, d0, d1
    30d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d4:	cb020000 	sub	x0, x0, x2
    30d8:	f90a12a0 	str	x0, [x21, #5152]
    30dc:	fd0a22a0 	str	d0, [x21, #5184]
    30e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    30e4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    30e8:	d65f03c0 	ret
    30ec:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    30f0:	8b000063 	add	x3, x3, x0
    30f4:	eb03027f 	cmp	x19, x3
    30f8:	54fff9e1 	b.ne	3034 <fwp_mem_free+0x64>  // b.any
    30fc:	fd400ae1 	ldr	d1, [x23, #16]
    3100:	fd4a2020 	ldr	d0, [x1, #5184]
    3104:	f9400ae0 	ldr	x0, [x23, #16]
    3108:	7e61d821 	ucvtf	d1, d1
    310c:	f94a1022 	ldr	x2, [x1, #5152]
    3110:	f94012f3 	ldr	x19, [x23, #32]
    3114:	1e612800 	fadd	d0, d0, d1
    3118:	cb000042 	sub	x2, x2, x0
    311c:	f90a1022 	str	x2, [x1, #5152]
    3120:	fd0a2020 	str	d0, [x1, #5184]
    3124:	b40000b3 	cbz	x19, 3138 <fwp_mem_free+0x168>
    3128:	39400260 	ldrb	w0, [x19]
    312c:	7103fc1f 	cmp	w0, #0xff
    3130:	54000380 	b.eq	31a0 <fwp_mem_free+0x1d0>  // b.none
    3134:	3900027f 	strb	wzr, [x19]
    3138:	b9400ee2 	ldr	w2, [x23, #12]
    313c:	b4000142 	cbz	x2, 3164 <fwp_mem_free+0x194>
    3140:	911342a1 	add	x1, x21, #0x4d0
    3144:	8b160040 	add	x0, x2, x22
    3148:	8b000800 	add	x0, x0, x0, lsl #2
    314c:	f949fc21 	ldr	x1, [x1, #5112]
    3150:	8b140034 	add	x20, x1, x20
    3154:	8b000c20 	add	x0, x1, x0, lsl #3
    3158:	3802869f 	strb	wzr, [x20], #40
    315c:	eb00029f 	cmp	x20, x0
    3160:	54ffffc1 	b.ne	3158 <fwp_mem_free+0x188>  // b.any
    3164:	911342a0 	add	x0, x21, #0x4d0
    3168:	f94a1801 	ldr	x1, [x0, #5168]
    316c:	f949f803 	ldr	x3, [x0, #5104]
    3170:	8b020021 	add	x1, x1, x2
    3174:	f90a1801 	str	x1, [x0, #5168]
    3178:	eb16007f 	cmp	x3, x22
    317c:	54000049 	b.ls	3184 <fwp_mem_free+0x1b4>  // b.plast
    3180:	f909f816 	str	x22, [x0, #5104]
    3184:	911342b5 	add	x21, x21, #0x4d0
    3188:	f949f6a0 	ldr	x0, [x21, #5096]
    318c:	eb16001f 	cmp	x0, x22
    3190:	54fff529 	b.ls	3034 <fwp_mem_free+0x64>  // b.plast
    3194:	a94363f7 	ldp	x23, x24, [sp, #48]
    3198:	f909f6b6 	str	x22, [x21, #5096]
    319c:	17ffffa7 	b	3038 <fwp_mem_free+0x68>
    31a0:	aa1303e0 	mov	x0, x19
    31a4:	97fffeeb 	bl	2d50 <fwp_rc_forget_slot>
    31a8:	17ffffe3 	b	3134 <fwp_mem_free+0x164>
    31ac:	97fffee9 	bl	2d50 <fwp_rc_forget_slot>
    31b0:	17ffffb4 	b	3080 <fwp_mem_free+0xb0>

00000000000031b4 <fwp_heap_alloc_big>:
    31b4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    31b8:	910003fd 	mov	x29, sp
    31bc:	a90153f3 	stp	x19, x20, [sp, #16]
    31c0:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c4:	a90363f7 	stp	x23, x24, [sp, #48]
    31c8:	aa0003f7 	mov	x23, x0
    31cc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    31d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    31d4:	eb0002ff 	cmp	x23, x0
    31d8:	54000888 	b.hi	32e8 <fwp_heap_alloc_big+0x134>  // b.pmore
    31dc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    31e0:	8b0002f4 	add	x20, x23, x0
    31e4:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xd10>
    31e8:	91134359 	add	x25, x26, #0x4d0
    31ec:	d350fe94 	lsr	x20, x20, #16
    31f0:	2a0103f5 	mov	w21, w1
    31f4:	aa1403e0 	mov	x0, x20
    31f8:	97fffac6 	bl	1d10 <fwp_heap_chunks>
    31fc:	f949ff22 	ldr	x2, [x25, #5112]
    3200:	8b000813 	add	x19, x0, x0, lsl #2
    3204:	aa0003f8 	mov	x24, x0
    3208:	52800043 	mov	w3, #0x2                   	// #2
    320c:	d37df273 	lsl	x19, x19, #3
    3210:	d2800021 	mov	x1, #0x1                   	// #1
    3214:	8b130040 	add	x0, x2, x19
    3218:	38336843 	strb	w3, [x2, x19]
    321c:	39000415 	strb	w21, [x0, #1]
    3220:	b9000c14 	str	w20, [x0, #12]
    3224:	f9000817 	str	x23, [x0, #16]
    3228:	97fffef2 	bl	2df0 <fwp_rc_prepare_chunk>
    322c:	f100069f 	cmp	x20, #0x1
    3230:	54000269 	b.ls	327c <fwp_heap_alloc_big+0xc8>  // b.plast
    3234:	8b180294 	add	x20, x20, x24
    3238:	9100a273 	add	x19, x19, #0x28
    323c:	a90573fb 	stp	x27, x28, [sp, #80]
    3240:	5280007b 	mov	w27, #0x3                   	// #3
    3244:	8b140a94 	add	x20, x20, x20, lsl #2
    3248:	2a1803fc 	mov	w28, w24
    324c:	9adb2296 	lsl	x22, x20, x27
    3250:	f949ff35 	ldr	x21, [x25, #5112]
    3254:	d2800001 	mov	x1, #0x0                   	// #0
    3258:	8b1302b4 	add	x20, x21, x19
    325c:	aa1403e0 	mov	x0, x20
    3260:	97fffee4 	bl	2df0 <fwp_rc_prepare_chunk>
    3264:	38336abb 	strb	w27, [x21, x19]
    3268:	9100a273 	add	x19, x19, #0x28
    326c:	b9000e9c 	str	w28, [x20, #12]
    3270:	eb1302df 	cmp	x22, x19
    3274:	54fffee1 	b.ne	3250 <fwp_heap_alloc_big+0x9c>  // b.any
    3278:	a94573fb 	ldp	x27, x28, [sp, #80]
    327c:	91134353 	add	x19, x26, #0x4d0
    3280:	aa1703e2 	mov	x2, x23
    3284:	52800001 	mov	w1, #0x0                   	// #0
    3288:	f949da60 	ldr	x0, [x19, #5040]
    328c:	8b184018 	add	x24, x0, x24, lsl #16
    3290:	aa1803e0 	mov	x0, x24
    3294:	97fff88b 	bl	14c0 <memset@plt>
    3298:	f94a1260 	ldr	x0, [x19, #5152]
    329c:	ab170000 	adds	x0, x0, x23
    32a0:	54000242 	b.cs	32e8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    32a4:	f94a1661 	ldr	x1, [x19, #5160]
    32a8:	f90a1260 	str	x0, [x19, #5152]
    32ac:	eb01001f 	cmp	x0, x1
    32b0:	54000049 	b.ls	32b8 <fwp_heap_alloc_big+0x104>  // b.plast
    32b4:	f90a1660 	str	x0, [x19, #5160]
    32b8:	9113435a 	add	x26, x26, #0x4d0
    32bc:	9e6202e0 	scvtf	d0, x23
    32c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32c4:	aa1803e0 	mov	x0, x24
    32c8:	fd4a1f41 	ldr	d1, [x26, #5176]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	1e602820 	fadd	d0, d1, d0
    32d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    32d8:	fd0a1f40 	str	d0, [x26, #5176]
    32dc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    32e0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    32e4:	d65f03c0 	ret
    32e8:	a90573fb 	stp	x27, x28, [sp, #80]
    32ec:	97fffa49 	bl	1c10 <fwp_heap_oom>

00000000000032f0 <fwp_heap_alloc_slow>:
    32f0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    32f4:	910003fd 	mov	x29, sp
    32f8:	a90153f3 	stp	x19, x20, [sp, #16]
    32fc:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xd10>
    3300:	91134262 	add	x2, x19, #0x4d0
    3304:	a9025bf5 	stp	x21, x22, [sp, #32]
    3308:	aa0003f5 	mov	x21, x0
    330c:	2a0103f4 	mov	w20, w1
    3310:	b953a440 	ldr	w0, [x2, #5028]
    3314:	34000600 	cbz	w0, 33d4 <fwp_heap_alloc_slow+0xe4>
    3318:	f14012bf 	cmp	x21, #0x4, lsl #12
    331c:	54000628 	b.hi	33e0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3320:	91003ea0 	add	x0, x21, #0xf
    3324:	91134262 	add	x2, x19, #0x4d0
    3328:	f9001bf7 	str	x23, [sp, #48]
    332c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3330:	8b401040 	add	x0, x2, x0, lsr #4
    3334:	cb34c084 	sub	x4, x4, w20, sxtw
    3338:	d37ae484 	lsl	x4, x4, #6
    333c:	397e8003 	ldrb	w3, [x0, #4000]
    3340:	910f0060 	add	x0, x3, #0x3c0
    3344:	aa0303e1 	mov	x1, x3
    3348:	8b030463 	add	x3, x3, x3, lsl #1
    334c:	8b030c83 	add	x3, x4, x3, lsl #3
    3350:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3354:	2a1703f6 	mov	w22, w23
    3358:	f8636844 	ldr	x4, [x2, x3]
    335c:	b40004e4 	cbz	x4, 33f8 <fwp_heap_alloc_slow+0x108>
    3360:	f9400080 	ldr	x0, [x4]
    3364:	aa2003e0 	mvn	x0, x0
    3368:	f8236840 	str	x0, [x2, x3]
    336c:	7100069f 	cmp	w20, #0x1
    3370:	aa0403e0 	mov	x0, x4
    3374:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    3378:	52800001 	mov	w1, #0x0                   	// #0
    337c:	97fff851 	bl	14c0 <memset@plt>
    3380:	aa0003e4 	mov	x4, x0
    3384:	91134260 	add	x0, x19, #0x4d0
    3388:	f94a1001 	ldr	x1, [x0, #5152]
    338c:	ab160021 	adds	x1, x1, x22
    3390:	540005c2 	b.cs	3448 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    3394:	f94a1402 	ldr	x2, [x0, #5160]
    3398:	f90a1001 	str	x1, [x0, #5152]
    339c:	eb02003f 	cmp	x1, x2
    33a0:	54000049 	b.ls	33a8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    33a4:	f90a1401 	str	x1, [x0, #5160]
    33a8:	91134273 	add	x19, x19, #0x4d0
    33ac:	1e6302e1 	ucvtf	d1, w23
    33b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33b4:	aa0403e0 	mov	x0, x4
    33b8:	fd4a1e60 	ldr	d0, [x19, #5176]
    33bc:	f9401bf7 	ldr	x23, [sp, #48]
    33c0:	1e612800 	fadd	d0, d0, d1
    33c4:	fd0a1e60 	str	d0, [x19, #5176]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    33d0:	d65f03c0 	ret
    33d4:	97fffce8 	bl	2774 <fwp_heap_init>
    33d8:	f14012bf 	cmp	x21, #0x4, lsl #12
    33dc:	54fffa29 	b.ls	3320 <fwp_heap_alloc_slow+0x30>  // b.plast
    33e0:	2a1403e1 	mov	w1, w20
    33e4:	aa1503e0 	mov	x0, x21
    33e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33f0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    33f4:	17ffff70 	b	31b4 <fwp_heap_alloc_big>
    33f8:	8b030042 	add	x2, x2, x3
    33fc:	f9400444 	ldr	x4, [x2, #8]
    3400:	b4000104 	cbz	x4, 3420 <fwp_heap_alloc_slow+0x130>
    3404:	f9400840 	ldr	x0, [x2, #16]
    3408:	cb040000 	sub	x0, x0, x4
    340c:	eb16001f 	cmp	x0, x22
    3410:	54000083 	b.cc	3420 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3414:	8b160080 	add	x0, x4, x22
    3418:	f9000440 	str	x0, [x2, #8]
    341c:	17ffffd4 	b	336c <fwp_heap_alloc_slow+0x7c>
    3420:	52800302 	mov	w2, #0x18                  	// #24
    3424:	52807804 	mov	w4, #0x3c0                 	// #960
    3428:	91134260 	add	x0, x19, #0x4d0
    342c:	9ba27c23 	umull	x3, w1, w2
    3430:	2a1403e2 	mov	w2, w20
    3434:	9b240e84 	smaddl	x4, w20, w4, x3
    3438:	8b040000 	add	x0, x0, x4
    343c:	97fffeb5 	bl	2f10 <fwp_heap_refill>
    3440:	aa0003e4 	mov	x4, x0
    3444:	17ffffca 	b	336c <fwp_heap_alloc_slow+0x7c>
    3448:	97fff9f2 	bl	1c10 <fwp_heap_oom>
    344c:	d503201f 	nop

0000000000003450 <fwp_rc_share>:
    3450:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    3454:	91134042 	add	x2, x2, #0x4d0
    3458:	f949d843 	ldr	x3, [x2, #5040]
    345c:	f949ec41 	ldr	x1, [x2, #5080]
    3460:	cb030000 	sub	x0, x0, x3
    3464:	eb01401f 	cmp	x0, x1, lsl #16
    3468:	540002c2 	b.cs	34c0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    346c:	d350fc01 	lsr	x1, x0, #16
    3470:	f949fc44 	ldr	x4, [x2, #5112]
    3474:	8b010821 	add	x1, x1, x1, lsl #2
    3478:	d37df021 	lsl	x1, x1, #3
    347c:	8b010083 	add	x3, x4, x1
    3480:	f9401062 	ldr	x2, [x3, #32]
    3484:	b40001e2 	cbz	x2, 34c0 <fwp_rc_share+0x70>
    3488:	38616881 	ldrb	w1, [x4, x1]
    348c:	7100083f 	cmp	w1, #0x2
    3490:	540001a0 	b.eq	34c4 <fwp_rc_share+0x74>  // b.none
    3494:	7100043f 	cmp	w1, #0x1
    3498:	54000141 	b.ne	34c0 <fwp_rc_share+0x70>  // b.any
    349c:	29430464 	ldp	w4, w1, [x3, #24]
    34a0:	92403c00 	and	x0, x0, #0xffff
    34a4:	9b047c00 	mul	x0, x0, x4
    34a8:	d360fc00 	lsr	x0, x0, #32
    34ac:	eb01001f 	cmp	x0, x1
    34b0:	54000082 	b.cs	34c0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    34b4:	8b000042 	add	x2, x2, x0
    34b8:	39400040 	ldrb	w0, [x2]
    34bc:	350000a0 	cbnz	w0, 34d0 <fwp_rc_share+0x80>
    34c0:	d65f03c0 	ret
    34c4:	72003c1f 	tst	w0, #0xffff
    34c8:	54ffff80 	b.eq	34b8 <fwp_rc_share+0x68>  // b.none
    34cc:	d65f03c0 	ret
    34d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    34d4:	90000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    34d8:	912f2000 	add	x0, x0, #0xbc8
    34dc:	910003fd 	mov	x29, sp
    34e0:	97fffb10 	bl	2120 <fwp_trap>

00000000000034e4 <e69>:
    34e4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34e8:	90000021 	adrp	x1, 7000 <fwp_main_thread+0x920>
    34ec:	910003fd 	mov	x29, sp
    34f0:	fd400001 	ldr	d1, [x0]
    34f4:	f9000bf3 	str	x19, [sp, #16]
    34f8:	fd477020 	ldr	d0, [x1, #3808]
    34fc:	1e610800 	fmul	d0, d0, d1
    3500:	9e660013 	fmov	x19, d0
    3504:	aa1303e0 	mov	x0, x19
    3508:	97ffffd2 	bl	3450 <fwp_rc_share>
    350c:	aa1303e0 	mov	x0, x19
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	d503201f 	nop

0000000000003520 <e45>:
    3520:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3524:	910003fd 	mov	x29, sp
    3528:	6d400001 	ldp	d1, d0, [x0]
    352c:	f9000bf3 	str	x19, [sp, #16]
    3530:	1e612800 	fadd	d0, d0, d1
    3534:	9e660013 	fmov	x19, d0
    3538:	aa1303e0 	mov	x0, x19
    353c:	97ffffc5 	bl	3450 <fwp_rc_share>
    3540:	aa1303e0 	mov	x0, x19
    3544:	f9400bf3 	ldr	x19, [sp, #16]
    3548:	a8c27bfd 	ldp	x29, x30, [sp], #32
    354c:	d65f03c0 	ret

0000000000003550 <e32>:
    3550:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3554:	910003fd 	mov	x29, sp
    3558:	6d400001 	ldp	d1, d0, [x0]
    355c:	f9000bf3 	str	x19, [sp, #16]
    3560:	1e613800 	fsub	d0, d0, d1
    3564:	9e660013 	fmov	x19, d0
    3568:	aa1303e0 	mov	x0, x19
    356c:	97ffffb9 	bl	3450 <fwp_rc_share>
    3570:	aa1303e0 	mov	x0, x19
    3574:	f9400bf3 	ldr	x19, [sp, #16]
    3578:	a8c27bfd 	ldp	x29, x30, [sp], #32
    357c:	d65f03c0 	ret

0000000000003580 <fwp_rc_dup>:
    3580:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    3584:	91134042 	add	x2, x2, #0x4d0
    3588:	f949d841 	ldr	x1, [x2, #5040]
    358c:	f949ec43 	ldr	x3, [x2, #5080]
    3590:	cb010001 	sub	x1, x0, x1
    3594:	eb03403f 	cmp	x1, x3, lsl #16
    3598:	54000342 	b.cs	3600 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    359c:	d350fc20 	lsr	x0, x1, #16
    35a0:	f949fc44 	ldr	x4, [x2, #5112]
    35a4:	8b000800 	add	x0, x0, x0, lsl #2
    35a8:	d37df002 	lsl	x2, x0, #3
    35ac:	8b020083 	add	x3, x4, x2
    35b0:	f9401060 	ldr	x0, [x3, #32]
    35b4:	b4000260 	cbz	x0, 3600 <fwp_rc_dup+0x80>
    35b8:	38626882 	ldrb	w2, [x4, x2]
    35bc:	7100085f 	cmp	w2, #0x2
    35c0:	54000220 	b.eq	3604 <fwp_rc_dup+0x84>  // b.none
    35c4:	7100045f 	cmp	w2, #0x1
    35c8:	540001c1 	b.ne	3600 <fwp_rc_dup+0x80>  // b.any
    35cc:	29430864 	ldp	w4, w2, [x3, #24]
    35d0:	92403c21 	and	x1, x1, #0xffff
    35d4:	9b047c21 	mul	x1, x1, x4
    35d8:	d360fc21 	lsr	x1, x1, #32
    35dc:	eb02003f 	cmp	x1, x2
    35e0:	54000102 	b.cs	3600 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    35e4:	8b010000 	add	x0, x0, x1
    35e8:	39400001 	ldrb	w1, [x0]
    35ec:	340000a1 	cbz	w1, 3600 <fwp_rc_dup+0x80>
    35f0:	7103f43f 	cmp	w1, #0xfd
    35f4:	540000e8 	b.hi	3610 <fwp_rc_dup+0x90>  // b.pmore
    35f8:	11000421 	add	w1, w1, #0x1
    35fc:	39000001 	strb	w1, [x0]
    3600:	d65f03c0 	ret
    3604:	72003c3f 	tst	w1, #0xffff
    3608:	54ffff00 	b.eq	35e8 <fwp_rc_dup+0x68>  // b.none
    360c:	d65f03c0 	ret
    3610:	17fffd89 	b	2c34 <fwp_rc_wide_dup>

0000000000003614 <fwp_task_dispose>:
    3614:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3618:	910003fd 	mov	x29, sp
    361c:	f9000bf3 	str	x19, [sp, #16]
    3620:	aa0003f3 	mov	x19, x0
    3624:	39414000 	ldrb	w0, [x0, #80]
    3628:	36000720 	tbz	w0, #0, 370c <fwp_task_dispose+0xf8>
    362c:	f9400a60 	ldr	x0, [x19, #16]
    3630:	b50006e0 	cbnz	x0, 370c <fwp_task_dispose+0xf8>
    3634:	a9478660 	ldp	x0, x1, [x19, #120]
    3638:	39014e7f 	strb	wzr, [x19, #83]
    363c:	f9003e7f 	str	xzr, [x19, #120]
    3640:	f100003f 	cmp	x1, #0x0
    3644:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3648:	54000040 	b.eq	3650 <fwp_task_dispose+0x3c>  // b.none
    364c:	d63f0020 	blr	x1
    3650:	f9405660 	ldr	x0, [x19, #168]
    3654:	97fffe5f 	bl	2fd0 <fwp_mem_free>
    3658:	f900567f 	str	xzr, [x19, #168]
    365c:	b9405e60 	ldr	w0, [x19, #92]
    3660:	7100041f 	cmp	w0, #0x1
    3664:	54000420 	b.eq	36e8 <fwp_task_dispose+0xd4>  // b.none
    3668:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    366c:	91134042 	add	x2, x2, #0x4d0
    3670:	f949d840 	ldr	x0, [x2, #5040]
    3674:	f949ec41 	ldr	x1, [x2, #5080]
    3678:	cb000260 	sub	x0, x19, x0
    367c:	eb01401f 	cmp	x0, x1, lsl #16
    3680:	540002e2 	b.cs	36dc <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3684:	d350fc01 	lsr	x1, x0, #16
    3688:	f949fc44 	ldr	x4, [x2, #5112]
    368c:	8b010821 	add	x1, x1, x1, lsl #2
    3690:	d37df021 	lsl	x1, x1, #3
    3694:	8b010083 	add	x3, x4, x1
    3698:	f9401062 	ldr	x2, [x3, #32]
    369c:	b4000202 	cbz	x2, 36dc <fwp_task_dispose+0xc8>
    36a0:	38616881 	ldrb	w1, [x4, x1]
    36a4:	7100083f 	cmp	w1, #0x2
    36a8:	54000280 	b.eq	36f8 <fwp_task_dispose+0xe4>  // b.none
    36ac:	7100043f 	cmp	w1, #0x1
    36b0:	54000161 	b.ne	36dc <fwp_task_dispose+0xc8>  // b.any
    36b4:	29430464 	ldp	w4, w1, [x3, #24]
    36b8:	92403c00 	and	x0, x0, #0xffff
    36bc:	9b047c00 	mul	x0, x0, x4
    36c0:	d360fc00 	lsr	x0, x0, #32
    36c4:	eb01001f 	cmp	x0, x1
    36c8:	540000a2 	b.cs	36dc <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    36cc:	8b000042 	add	x2, x2, x0
    36d0:	39400040 	ldrb	w0, [x2]
    36d4:	7100041f 	cmp	w0, #0x1
    36d8:	54000080 	b.eq	36e8 <fwp_task_dispose+0xd4>  // b.none
    36dc:	f9400bf3 	ldr	x19, [sp, #16]
    36e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e4:	d65f03c0 	ret
    36e8:	aa1303e0 	mov	x0, x19
    36ec:	f9400bf3 	ldr	x19, [sp, #16]
    36f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36f4:	17fffe37 	b	2fd0 <fwp_mem_free>
    36f8:	72003c1f 	tst	w0, #0xffff
    36fc:	54fffea0 	b.eq	36d0 <fwp_task_dispose+0xbc>  // b.none
    3700:	f9400bf3 	ldr	x19, [sp, #16]
    3704:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3708:	d65f03c0 	ret
    370c:	97fff78d 	bl	1540 <abort@plt>

0000000000003710 <fwp_free_zombie>:
    3710:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3714:	910003fd 	mov	x29, sp
    3718:	a90153f3 	stp	x19, x20, [sp, #16]
    371c:	b00000f4 	adrp	x20, 20000 <__data_start>
    3720:	9100c281 	add	x1, x20, #0x30
    3724:	f9401c33 	ldr	x19, [x1, #56]
    3728:	b4000333 	cbz	x19, 378c <fwp_free_zombie+0x7c>
    372c:	f9400420 	ldr	x0, [x1, #8]
    3730:	eb00027f 	cmp	x19, x0
    3734:	540002c0 	b.eq	378c <fwp_free_zombie+0x7c>  // b.none
    3738:	b9404022 	ldr	w2, [x1, #64]
    373c:	f9400a60 	ldr	x0, [x19, #16]
    3740:	7100fc5f 	cmp	w2, #0x3f
    3744:	5400078c 	b.gt	3834 <fwp_free_zombie+0x124>
    3748:	91014023 	add	x3, x1, #0x50
    374c:	11000444 	add	w4, w2, #0x1
    3750:	b9004024 	str	w4, [x1, #64]
    3754:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3758:	f822d860 	str	x0, [x3, w2, sxtw #3]
    375c:	a9530261 	ldp	x1, x0, [x19, #304]
    3760:	b4000741 	cbz	x1, 3848 <fwp_free_zombie+0x138>
    3764:	f9009c20 	str	x0, [x1, #312]
    3768:	b4000040 	cbz	x0, 3770 <fwp_free_zombie+0x60>
    376c:	f9009801 	str	x1, [x0, #304]
    3770:	9100c294 	add	x20, x20, #0x30
    3774:	b9405e60 	ldr	w0, [x19, #92]
    3778:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    377c:	f9001e9f 	str	xzr, [x20, #56]
    3780:	34000140 	cbz	w0, 37a8 <fwp_free_zombie+0x98>
    3784:	7100041f 	cmp	w0, #0x1
    3788:	54000080 	b.eq	3798 <fwp_free_zombie+0x88>  // b.none
    378c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3790:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3794:	d65f03c0 	ret
    3798:	aa1303e0 	mov	x0, x19
    379c:	a94153f3 	ldp	x19, x20, [sp, #16]
    37a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37a4:	17ffff9c 	b	3614 <fwp_task_dispose>
    37a8:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xd10>
    37ac:	91134082 	add	x2, x4, #0x4d0
    37b0:	f949d841 	ldr	x1, [x2, #5040]
    37b4:	f949ec40 	ldr	x0, [x2, #5080]
    37b8:	cb010261 	sub	x1, x19, x1
    37bc:	eb00403f 	cmp	x1, x0, lsl #16
    37c0:	54fffe62 	b.cs	378c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    37c4:	d350fc20 	lsr	x0, x1, #16
    37c8:	f949fc43 	ldr	x3, [x2, #5112]
    37cc:	8b000800 	add	x0, x0, x0, lsl #2
    37d0:	d37df000 	lsl	x0, x0, #3
    37d4:	8b000062 	add	x2, x3, x0
    37d8:	f9401054 	ldr	x20, [x2, #32]
    37dc:	b4fffd94 	cbz	x20, 378c <fwp_free_zombie+0x7c>
    37e0:	38606860 	ldrb	w0, [x3, x0]
    37e4:	7100081f 	cmp	w0, #0x2
    37e8:	54000360 	b.eq	3854 <fwp_free_zombie+0x144>  // b.none
    37ec:	7100041f 	cmp	w0, #0x1
    37f0:	54fffce1 	b.ne	378c <fwp_free_zombie+0x7c>  // b.any
    37f4:	29430043 	ldp	w3, w0, [x2, #24]
    37f8:	92403c21 	and	x1, x1, #0xffff
    37fc:	9b037c21 	mul	x1, x1, x3
    3800:	d360fc21 	lsr	x1, x1, #32
    3804:	eb00003f 	cmp	x1, x0
    3808:	54fffc22 	b.cs	378c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    380c:	8b010294 	add	x20, x20, x1
    3810:	39400280 	ldrb	w0, [x20]
    3814:	34fffbc0 	cbz	w0, 378c <fwp_free_zombie+0x7c>
    3818:	7100041f 	cmp	w0, #0x1
    381c:	54fffbe0 	b.eq	3798 <fwp_free_zombie+0x88>  // b.none
    3820:	7103fc1f 	cmp	w0, #0xff
    3824:	540001e0 	b.eq	3860 <fwp_free_zombie+0x150>  // b.none
    3828:	51000400 	sub	w0, w0, #0x1
    382c:	39000280 	strb	w0, [x20]
    3830:	17ffffd7 	b	378c <fwp_free_zombie+0x7c>
    3834:	f9400e61 	ldr	x1, [x19, #24]
    3838:	97fff776 	bl	1610 <munmap@plt>
    383c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3840:	a9530261 	ldp	x1, x0, [x19, #304]
    3844:	b5fff901 	cbnz	x1, 3764 <fwp_free_zombie+0x54>
    3848:	9100c282 	add	x2, x20, #0x30
    384c:	f9012840 	str	x0, [x2, #592]
    3850:	17ffffc6 	b	3768 <fwp_free_zombie+0x58>
    3854:	72003c3f 	tst	w1, #0xffff
    3858:	54fff9a1 	b.ne	378c <fwp_free_zombie+0x7c>  // b.any
    385c:	17ffffed 	b	3810 <fwp_free_zombie+0x100>
    3860:	ca544680 	eor	x0, x20, x20, lsr #17
    3864:	91134084 	add	x4, x4, #0x4d0
    3868:	ca402400 	eor	x0, x0, x0, lsr #9
    386c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3870:	f94a2400 	ldr	x0, [x0, #5192]
    3874:	b5000080 	cbnz	x0, 3884 <fwp_free_zombie+0x174>
    3878:	14000010 	b	38b8 <fwp_free_zombie+0x1a8>
    387c:	f9400800 	ldr	x0, [x0, #16]
    3880:	b40001c0 	cbz	x0, 38b8 <fwp_free_zombie+0x1a8>
    3884:	f9400001 	ldr	x1, [x0]
    3888:	eb14003f 	cmp	x1, x20
    388c:	54ffff81 	b.ne	387c <fwp_free_zombie+0x16c>  // b.any
    3890:	f9400401 	ldr	x1, [x0, #8]
    3894:	d1000421 	sub	x1, x1, #0x1
    3898:	f9000401 	str	x1, [x0, #8]
    389c:	f103f83f 	cmp	x1, #0xfe
    38a0:	54fff761 	b.ne	378c <fwp_free_zombie+0x7c>  // b.any
    38a4:	aa1403e0 	mov	x0, x20
    38a8:	97fffd2a 	bl	2d50 <fwp_rc_forget_slot>
    38ac:	12800020 	mov	w0, #0xfffffffe            	// #-2
    38b0:	39000280 	strb	w0, [x20]
    38b4:	17ffffb6 	b	378c <fwp_free_zombie+0x7c>
    38b8:	90000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    38bc:	912e0000 	add	x0, x0, #0xb80
    38c0:	97fffa18 	bl	2120 <fwp_trap>

00000000000038c4 <fwp_block>:
    38c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    38c8:	910003fd 	mov	x29, sp
    38cc:	a90153f3 	stp	x19, x20, [sp, #16]
    38d0:	b00000f3 	adrp	x19, 20000 <__data_start>
    38d4:	9100c274 	add	x20, x19, #0x30
    38d8:	f9401682 	ldr	x2, [x20, #40]
    38dc:	b4000622 	cbz	x2, 39a0 <fwp_block+0xdc>
    38e0:	9100c261 	add	x1, x19, #0x30
    38e4:	f9408040 	ldr	x0, [x2, #256]
    38e8:	f9001420 	str	x0, [x1, #40]
    38ec:	b4000680 	cbz	x0, 39bc <fwp_block+0xf8>
    38f0:	9100c263 	add	x3, x19, #0x30
    38f4:	3901505f 	strb	wzr, [x2, #84]
    38f8:	f9400464 	ldr	x4, [x3, #8]
    38fc:	eb02009f 	cmp	x4, x2
    3900:	54000440 	b.eq	3988 <fwp_block+0xc4>  // b.none
    3904:	f9412c65 	ldr	x5, [x3, #600]
    3908:	f9000462 	str	x2, [x3, #8]
    390c:	f9400441 	ldr	x1, [x2, #8]
    3910:	f9004885 	str	x5, [x4, #144]
    3914:	f9413065 	ldr	x5, [x3, #608]
    3918:	f9004c85 	str	x5, [x4, #152]
    391c:	f9413465 	ldr	x5, [x3, #616]
    3920:	f9005085 	str	x5, [x4, #160]
    3924:	f9413865 	ldr	x5, [x3, #624]
    3928:	f9005485 	str	x5, [x4, #168]
    392c:	f9413c65 	ldr	x5, [x3, #632]
    3930:	f9005885 	str	x5, [x4, #176]
    3934:	f9414065 	ldr	x5, [x3, #640]
    3938:	f9005c85 	str	x5, [x4, #184]
    393c:	f9414465 	ldr	x5, [x3, #648]
    3940:	f9006085 	str	x5, [x4, #192]
    3944:	f9400480 	ldr	x0, [x4, #8]
    3948:	f9404844 	ldr	x4, [x2, #144]
    394c:	f9012c64 	str	x4, [x3, #600]
    3950:	f9404c44 	ldr	x4, [x2, #152]
    3954:	f9013064 	str	x4, [x3, #608]
    3958:	f9405044 	ldr	x4, [x2, #160]
    395c:	f9013464 	str	x4, [x3, #616]
    3960:	f9405444 	ldr	x4, [x2, #168]
    3964:	f9013864 	str	x4, [x3, #624]
    3968:	f9405844 	ldr	x4, [x2, #176]
    396c:	f9013c64 	str	x4, [x3, #632]
    3970:	a94b8844 	ldp	x4, x2, [x2, #184]
    3974:	f9014064 	str	x4, [x3, #640]
    3978:	f9014462 	str	x2, [x3, #648]
    397c:	97fff6f5 	bl	1550 <swapcontext@plt>
    3980:	97ffff64 	bl	3710 <fwp_free_zombie>
    3984:	d503201f 	nop
    3988:	9100c260 	add	x0, x19, #0x30
    398c:	b9429000 	ldr	w0, [x0, #656]
    3990:	340001a0 	cbz	w0, 39c4 <fwp_block+0x100>
    3994:	a94153f3 	ldp	x19, x20, [sp, #16]
    3998:	a8c27bfd 	ldp	x29, x30, [sp], #32
    399c:	d65f03c0 	ret
    39a0:	97fffc18 	bl	2a00 <fwp_poll_events>
    39a4:	f9401682 	ldr	x2, [x20, #40]
    39a8:	b4ffffc2 	cbz	x2, 39a0 <fwp_block+0xdc>
    39ac:	9100c261 	add	x1, x19, #0x30
    39b0:	f9408040 	ldr	x0, [x2, #256]
    39b4:	f9001420 	str	x0, [x1, #40]
    39b8:	b5fff9c0 	cbnz	x0, 38f0 <fwp_block+0x2c>
    39bc:	f900103f 	str	xzr, [x1, #32]
    39c0:	17ffffcc 	b	38f0 <fwp_block+0x2c>
    39c4:	90000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    39c8:	912fe000 	add	x0, x0, #0xbf8
    39cc:	97fff72d 	bl	1680 <getenv@plt>
    39d0:	5284e202 	mov	w2, #0x2710                	// #10000
    39d4:	b4000060 	cbz	x0, 39e0 <fwp_block+0x11c>
    39d8:	39400001 	ldrb	w1, [x0]
    39dc:	350000c1 	cbnz	w1, 39f4 <fwp_block+0x130>
    39e0:	9100c273 	add	x19, x19, #0x30
    39e4:	b9029262 	str	w2, [x19, #656]
    39e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    39ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    39f0:	d65f03c0 	ret
    39f4:	52800142 	mov	w2, #0xa                   	// #10
    39f8:	d2800001 	mov	x1, #0x0                   	// #0
    39fc:	97fff671 	bl	13c0 <strtoll@plt>
    3a00:	d1000403 	sub	x3, x0, #0x1
    3a04:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3a08:	eb02007f 	cmp	x3, x2
    3a0c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3a10:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3a14:	17fffff3 	b	39e0 <fwp_block+0x11c>
    3a18:	d503201f 	nop
    3a1c:	d503201f 	nop

0000000000003a20 <fwp_map_items>:
    3a20:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3a24:	910003fd 	mov	x29, sp
    3a28:	a90153f3 	stp	x19, x20, [sp, #16]
    3a2c:	aa0003f3 	mov	x19, x0
    3a30:	b4000a80 	cbz	x0, 3b80 <fwp_map_items+0x160>
    3a34:	aa0003e2 	mov	x2, x0
    3a38:	d2800000 	mov	x0, #0x0                   	// #0
    3a3c:	d503201f 	nop
    3a40:	f9400842 	ldr	x2, [x2, #16]
    3a44:	aa0003e3 	mov	x3, x0
    3a48:	91000400 	add	x0, x0, #0x1
    3a4c:	b5ffffa2 	cbnz	x2, 3a40 <fwp_map_items+0x20>
    3a50:	f9000020 	str	x0, [x1]
    3a54:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    3a58:	a9025bf5 	stp	x21, x22, [sp, #32]
    3a5c:	eb01001f 	cmp	x0, x1
    3a60:	540009c8 	b.hi	3b98 <fwp_map_items+0x178>  // b.pmore
    3a64:	91000860 	add	x0, x3, #0x2
    3a68:	d37df000 	lsl	x0, x0, #3
    3a6c:	f140101f 	cmp	x0, #0x4, lsl #12
    3a70:	1a9f87e2 	cset	w2, ls	// ls = plast
    3a74:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    3a78:	911342b4 	add	x20, x21, #0x4d0
    3a7c:	b953a681 	ldr	w1, [x20, #5028]
    3a80:	7100003f 	cmp	w1, #0x0
    3a84:	7a401844 	ccmp	w2, #0x0, #0x4, ne	// ne = any
    3a88:	54000680 	b.eq	3b58 <fwp_map_items+0x138>  // b.none
    3a8c:	91003c01 	add	x1, x0, #0xf
    3a90:	f9001bf7 	str	x23, [sp, #48]
    3a94:	8b411281 	add	x1, x20, x1, lsr #4
    3a98:	397e8021 	ldrb	w1, [x1, #4000]
    3a9c:	910f0022 	add	x2, x1, #0x3c0
    3aa0:	8b010421 	add	x1, x1, x1, lsl #1
    3aa4:	8b010e83 	add	x3, x20, x1, lsl #3
    3aa8:	b8627a97 	ldr	w23, [x20, x2, lsl #2]
    3aac:	2a1703f6 	mov	w22, w23
    3ab0:	f943c064 	ldr	x4, [x3, #1920]
    3ab4:	b4000444 	cbz	x4, 3b3c <fwp_map_items+0x11c>
    3ab8:	f9400085 	ldr	x5, [x4]
    3abc:	aa1603e2 	mov	x2, x22
    3ac0:	aa0403e0 	mov	x0, x4
    3ac4:	52800001 	mov	w1, #0x0                   	// #0
    3ac8:	aa2503e5 	mvn	x5, x5
    3acc:	f903c065 	str	x5, [x3, #1920]
    3ad0:	97fff67c 	bl	14c0 <memset@plt>
    3ad4:	aa0003e4 	mov	x4, x0
    3ad8:	f94a1280 	ldr	x0, [x20, #5152]
    3adc:	ab160000 	adds	x0, x0, x22
    3ae0:	540005a2 	b.cs	3b94 <fwp_map_items+0x174>  // b.hs, b.nlast
    3ae4:	f94a1681 	ldr	x1, [x20, #5160]
    3ae8:	f90a1280 	str	x0, [x20, #5152]
    3aec:	eb01001f 	cmp	x0, x1
    3af0:	54000049 	b.ls	3af8 <fwp_map_items+0xd8>  // b.plast
    3af4:	f90a1680 	str	x0, [x20, #5160]
    3af8:	911342b5 	add	x21, x21, #0x4d0
    3afc:	1e6302e1 	ucvtf	d1, w23
    3b00:	f9401bf7 	ldr	x23, [sp, #48]
    3b04:	fd4a1ea0 	ldr	d0, [x21, #5176]
    3b08:	1e612800 	fadd	d0, d0, d1
    3b0c:	fd0a1ea0 	str	d0, [x21, #5176]
    3b10:	aa0403e1 	mov	x1, x4
    3b14:	b40000b3 	cbz	x19, 3b28 <fwp_map_items+0x108>
    3b18:	f9400662 	ldr	x2, [x19, #8]
    3b1c:	f8008422 	str	x2, [x1], #8
    3b20:	f9400a73 	ldr	x19, [x19, #16]
    3b24:	b5ffffb3 	cbnz	x19, 3b18 <fwp_map_items+0xf8>
    3b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b2c:	aa0403e0 	mov	x0, x4
    3b30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3b34:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3b38:	d65f03c0 	ret
    3b3c:	f943c464 	ldr	x4, [x3, #1928]
    3b40:	b40000a4 	cbz	x4, 3b54 <fwp_map_items+0x134>
    3b44:	f943c861 	ldr	x1, [x3, #1936]
    3b48:	cb040021 	sub	x1, x1, x4
    3b4c:	eb0102df 	cmp	x22, x1
    3b50:	540000c9 	b.ls	3b68 <fwp_map_items+0x148>  // b.plast
    3b54:	f9401bf7 	ldr	x23, [sp, #48]
    3b58:	52800041 	mov	w1, #0x2                   	// #2
    3b5c:	97fffde5 	bl	32f0 <fwp_heap_alloc_slow>
    3b60:	aa0003e4 	mov	x4, x0
    3b64:	17ffffeb 	b	3b10 <fwp_map_items+0xf0>
    3b68:	8b160085 	add	x5, x4, x22
    3b6c:	aa1603e2 	mov	x2, x22
    3b70:	aa0403e0 	mov	x0, x4
    3b74:	52800001 	mov	w1, #0x0                   	// #0
    3b78:	f903c465 	str	x5, [x3, #1928]
    3b7c:	17ffffd5 	b	3ad0 <fwp_map_items+0xb0>
    3b80:	a9025bf5 	stp	x21, x22, [sp, #32]
    3b84:	52800022 	mov	w2, #0x1                   	// #1
    3b88:	d2800100 	mov	x0, #0x8                   	// #8
    3b8c:	f900003f 	str	xzr, [x1]
    3b90:	17ffffb9 	b	3a74 <fwp_map_items+0x54>
    3b94:	97fff81f 	bl	1c10 <fwp_heap_oom>
    3b98:	90000020 	adrp	x0, 7000 <fwp_main_thread+0x920>
    3b9c:	91302000 	add	x0, x0, #0xc08
    3ba0:	f9001bf7 	str	x23, [sp, #48]
    3ba4:	97fff95f 	bl	2120 <fwp_trap>
    3ba8:	d503201f 	nop
    3bac:	d503201f 	nop

0000000000003bb0 <fwp_caps32>:
    3bb0:	34000041 	cbz	w1, 3bb8 <fwp_caps32+0x8>
    3bb4:	d65f03c0 	ret
    3bb8:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3bbc:	91134063 	add	x3, x3, #0x4d0
    3bc0:	f949d861 	ldr	x1, [x3, #5040]
    3bc4:	f949ec62 	ldr	x2, [x3, #5080]
    3bc8:	cb010001 	sub	x1, x0, x1
    3bcc:	eb02403f 	cmp	x1, x2, lsl #16
    3bd0:	54ffff22 	b.cs	3bb4 <fwp_caps32+0x4>  // b.hs, b.nlast
    3bd4:	d350fc22 	lsr	x2, x1, #16
    3bd8:	f949fc65 	ldr	x5, [x3, #5112]
    3bdc:	8b020842 	add	x2, x2, x2, lsl #2
    3be0:	d37df042 	lsl	x2, x2, #3
    3be4:	8b0200a4 	add	x4, x5, x2
    3be8:	f9401083 	ldr	x3, [x4, #32]
    3bec:	b4fffe43 	cbz	x3, 3bb4 <fwp_caps32+0x4>
    3bf0:	386268a2 	ldrb	w2, [x5, x2]
    3bf4:	7100085f 	cmp	w2, #0x2
    3bf8:	540001c0 	b.eq	3c30 <fwp_caps32+0x80>  // b.none
    3bfc:	7100045f 	cmp	w2, #0x1
    3c00:	54fffda1 	b.ne	3bb4 <fwp_caps32+0x4>  // b.any
    3c04:	29430885 	ldp	w5, w2, [x4, #24]
    3c08:	92403c21 	and	x1, x1, #0xffff
    3c0c:	9b057c21 	mul	x1, x1, x5
    3c10:	d360fc21 	lsr	x1, x1, #32
    3c14:	eb02003f 	cmp	x1, x2
    3c18:	54fffce2 	b.cs	3bb4 <fwp_caps32+0x4>  // b.hs, b.nlast
    3c1c:	8b010063 	add	x3, x3, x1
    3c20:	39400061 	ldrb	w1, [x3]
    3c24:	7100043f 	cmp	w1, #0x1
    3c28:	54fffc61 	b.ne	3bb4 <fwp_caps32+0x4>  // b.any
    3c2c:	17fffce9 	b	2fd0 <fwp_mem_free>
    3c30:	72003c3f 	tst	w1, #0xffff
    3c34:	54ffff60 	b.eq	3c20 <fwp_caps32+0x70>  // b.none
    3c38:	d65f03c0 	ret
    3c3c:	d503201f 	nop

0000000000003c40 <fwp_caps45>:
    3c40:	34000041 	cbz	w1, 3c48 <fwp_caps45+0x8>
    3c44:	d65f03c0 	ret
    3c48:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3c4c:	91134063 	add	x3, x3, #0x4d0
    3c50:	f949d861 	ldr	x1, [x3, #5040]
    3c54:	f949ec62 	ldr	x2, [x3, #5080]
    3c58:	cb010001 	sub	x1, x0, x1
    3c5c:	eb02403f 	cmp	x1, x2, lsl #16
    3c60:	54ffff22 	b.cs	3c44 <fwp_caps45+0x4>  // b.hs, b.nlast
    3c64:	d350fc22 	lsr	x2, x1, #16
    3c68:	f949fc65 	ldr	x5, [x3, #5112]
    3c6c:	8b020842 	add	x2, x2, x2, lsl #2
    3c70:	d37df042 	lsl	x2, x2, #3
    3c74:	8b0200a4 	add	x4, x5, x2
    3c78:	f9401083 	ldr	x3, [x4, #32]
    3c7c:	b4fffe43 	cbz	x3, 3c44 <fwp_caps45+0x4>
    3c80:	386268a2 	ldrb	w2, [x5, x2]
    3c84:	7100085f 	cmp	w2, #0x2
    3c88:	540001c0 	b.eq	3cc0 <fwp_caps45+0x80>  // b.none
    3c8c:	7100045f 	cmp	w2, #0x1
    3c90:	54fffda1 	b.ne	3c44 <fwp_caps45+0x4>  // b.any
    3c94:	29430885 	ldp	w5, w2, [x4, #24]
    3c98:	92403c21 	and	x1, x1, #0xffff
    3c9c:	9b057c21 	mul	x1, x1, x5
    3ca0:	d360fc21 	lsr	x1, x1, #32
    3ca4:	eb02003f 	cmp	x1, x2
    3ca8:	54fffce2 	b.cs	3c44 <fwp_caps45+0x4>  // b.hs, b.nlast
    3cac:	8b010063 	add	x3, x3, x1
    3cb0:	39400061 	ldrb	w1, [x3]
    3cb4:	7100043f 	cmp	w1, #0x1
    3cb8:	54fffc61 	b.ne	3c44 <fwp_caps45+0x4>  // b.any
    3cbc:	17fffcc5 	b	2fd0 <fwp_mem_free>
    3cc0:	72003c3f 	tst	w1, #0xffff
    3cc4:	54ffff60 	b.eq	3cb0 <fwp_caps45+0x70>  // b.none
    3cc8:	d65f03c0 	ret
    3ccc:	d503201f 	nop

0000000000003cd0 <fwp_caps69>:
    3cd0:	34000041 	cbz	w1, 3cd8 <fwp_caps69+0x8>
    3cd4:	d65f03c0 	ret
    3cd8:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3cdc:	91134063 	add	x3, x3, #0x4d0
    3ce0:	f949d861 	ldr	x1, [x3, #5040]
    3ce4:	f949ec62 	ldr	x2, [x3, #5080]
    3ce8:	cb010001 	sub	x1, x0, x1
    3cec:	eb02403f 	cmp	x1, x2, lsl #16
    3cf0:	54ffff22 	b.cs	3cd4 <fwp_caps69+0x4>  // b.hs, b.nlast
    3cf4:	d350fc22 	lsr	x2, x1, #16
    3cf8:	f949fc65 	ldr	x5, [x3, #5112]
    3cfc:	8b020842 	add	x2, x2, x2, lsl #2
    3d00:	d37df042 	lsl	x2, x2, #3
    3d04:	8b0200a4 	add	x4, x5, x2
    3d08:	f9401083 	ldr	x3, [x4, #32]
    3d0c:	b4fffe43 	cbz	x3, 3cd4 <fwp_caps69+0x4>
    3d10:	386268a2 	ldrb	w2, [x5, x2]
    3d14:	7100085f 	cmp	w2, #0x2
    3d18:	540001c0 	b.eq	3d50 <fwp_caps69+0x80>  // b.none
    3d1c:	7100045f 	cmp	w2, #0x1
    3d20:	54fffda1 	b.ne	3cd4 <fwp_caps69+0x4>  // b.any
    3d24:	29430885 	ldp	w5, w2, [x4, #24]
    3d28:	92403c21 	and	x1, x1, #0xffff
    3d2c:	9b057c21 	mul	x1, x1, x5
    3d30:	d360fc21 	lsr	x1, x1, #32
    3d34:	eb02003f 	cmp	x1, x2
    3d38:	54fffce2 	b.cs	3cd4 <fwp_caps69+0x4>  // b.hs, b.nlast
    3d3c:	8b010063 	add	x3, x3, x1
    3d40:	39400061 	ldrb	w1, [x3]
    3d44:	7100043f 	cmp	w1, #0x1
    3d48:	54fffc61 	b.ne	3cd4 <fwp_caps69+0x4>  // b.any
    3d4c:	17fffca1 	b	2fd0 <fwp_mem_free>
    3d50:	72003c3f 	tst	w1, #0xffff
    3d54:	54ffff60 	b.eq	3d40 <fwp_caps69+0x70>  // b.none
    3d58:	d65f03c0 	ret
    3d5c:	d503201f 	nop

0000000000003d60 <fwp_caps74>:
    3d60:	34000041 	cbz	w1, 3d68 <fwp_caps74+0x8>
    3d64:	d65f03c0 	ret
    3d68:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3d6c:	91134063 	add	x3, x3, #0x4d0
    3d70:	f949d861 	ldr	x1, [x3, #5040]
    3d74:	f949ec62 	ldr	x2, [x3, #5080]
    3d78:	cb010001 	sub	x1, x0, x1
    3d7c:	eb02403f 	cmp	x1, x2, lsl #16
    3d80:	54ffff22 	b.cs	3d64 <fwp_caps74+0x4>  // b.hs, b.nlast
    3d84:	d350fc22 	lsr	x2, x1, #16
    3d88:	f949fc65 	ldr	x5, [x3, #5112]
    3d8c:	8b020842 	add	x2, x2, x2, lsl #2
    3d90:	d37df042 	lsl	x2, x2, #3
    3d94:	8b0200a4 	add	x4, x5, x2
    3d98:	f9401083 	ldr	x3, [x4, #32]
    3d9c:	b4fffe43 	cbz	x3, 3d64 <fwp_caps74+0x4>
    3da0:	386268a2 	ldrb	w2, [x5, x2]
    3da4:	7100085f 	cmp	w2, #0x2
    3da8:	540001c0 	b.eq	3de0 <fwp_caps74+0x80>  // b.none
    3dac:	7100045f 	cmp	w2, #0x1
    3db0:	54fffda1 	b.ne	3d64 <fwp_caps74+0x4>  // b.any
    3db4:	29430885 	ldp	w5, w2, [x4, #24]
    3db8:	92403c21 	and	x1, x1, #0xffff
    3dbc:	9b057c21 	mul	x1, x1, x5
    3dc0:	d360fc21 	lsr	x1, x1, #32
    3dc4:	eb02003f 	cmp	x1, x2
    3dc8:	54fffce2 	b.cs	3d64 <fwp_caps74+0x4>  // b.hs, b.nlast
    3dcc:	8b010063 	add	x3, x3, x1
    3dd0:	39400061 	ldrb	w1, [x3]
    3dd4:	7100043f 	cmp	w1, #0x1
    3dd8:	54fffc61 	b.ne	3d64 <fwp_caps74+0x4>  // b.any
    3ddc:	17fffc7d 	b	2fd0 <fwp_mem_free>
    3de0:	72003c3f 	tst	w1, #0xffff
    3de4:	54ffff60 	b.eq	3dd0 <fwp_caps74+0x70>  // b.none
    3de8:	d65f03c0 	ret
    3dec:	d503201f 	nop

0000000000003df0 <fwp_data.part.0.constprop.0>:
    3df0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3df4:	910003fd 	mov	x29, sp
    3df8:	a90153f3 	stp	x19, x20, [sp, #16]
    3dfc:	d0000174 	adrp	x20, 31000 <fwp_root_context+0xd10>
    3e00:	91134283 	add	x3, x20, #0x4d0
    3e04:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e08:	aa0103f5 	mov	x21, x1
    3e0c:	b953a461 	ldr	w1, [x3, #5028]
    3e10:	a90363f7 	stp	x23, x24, [sp, #48]
    3e14:	2a0003f8 	mov	w24, w0
    3e18:	34000701 	cbz	w1, 3ef8 <fwp_data.part.0.constprop.0+0x108>
    3e1c:	397e8862 	ldrb	w2, [x3, #4002]
    3e20:	910f0040 	add	x0, x2, #0x3c0
    3e24:	8b020442 	add	x2, x2, x2, lsl #1
    3e28:	d37df042 	lsl	x2, x2, #3
    3e2c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    3e30:	2a1703f6 	mov	w22, w23
    3e34:	f8626873 	ldr	x19, [x3, x2]
    3e38:	b40004d3 	cbz	x19, 3ed0 <fwp_data.part.0.constprop.0+0xe0>
    3e3c:	f9400260 	ldr	x0, [x19]
    3e40:	aa2003e0 	mvn	x0, x0
    3e44:	f8226860 	str	x0, [x3, x2]
    3e48:	f10062df 	cmp	x22, #0x18
    3e4c:	540000e9 	b.ls	3e68 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    3e50:	d10066c2 	sub	x2, x22, #0x19
    3e54:	91006260 	add	x0, x19, #0x18
    3e58:	927df042 	and	x2, x2, #0xfffffffffffffff8
    3e5c:	52800001 	mov	w1, #0x0                   	// #0
    3e60:	91002042 	add	x2, x2, #0x8
    3e64:	97fff597 	bl	14c0 <memset@plt>
    3e68:	91134282 	add	x2, x20, #0x4d0
    3e6c:	f94a1041 	ldr	x1, [x2, #5152]
    3e70:	ab160021 	adds	x1, x1, x22
    3e74:	540004c2 	b.cs	3f0c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    3e78:	f94a1440 	ldr	x0, [x2, #5160]
    3e7c:	f90a1041 	str	x1, [x2, #5152]
    3e80:	eb00003f 	cmp	x1, x0
    3e84:	54000049 	b.ls	3e8c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    3e88:	f90a1441 	str	x1, [x2, #5160]
    3e8c:	91134294 	add	x20, x20, #0x4d0
    3e90:	1e6302e1 	ucvtf	d1, w23
    3e94:	fd4a1e80 	ldr	d0, [x20, #5176]
    3e98:	1e612800 	fadd	d0, d0, d1
    3e9c:	fd0a1e80 	str	d0, [x20, #5176]
    3ea0:	52800041 	mov	w1, #0x2                   	// #2
    3ea4:	29000678 	stp	w24, w1, [x19]
    3ea8:	aa1303e0 	mov	x0, x19
    3eac:	f94002a1 	ldr	x1, [x21]
    3eb0:	f9000661 	str	x1, [x19, #8]
    3eb4:	f94006a1 	ldr	x1, [x21, #8]
    3eb8:	f9000a61 	str	x1, [x19, #16]
    3ebc:	a94153f3 	ldp	x19, x20, [sp, #16]
    3ec0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3ec4:	a94363f7 	ldp	x23, x24, [sp, #48]
    3ec8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3ecc:	d65f03c0 	ret
    3ed0:	8b020063 	add	x3, x3, x2
    3ed4:	f9400473 	ldr	x19, [x3, #8]
    3ed8:	b4000113 	cbz	x19, 3ef8 <fwp_data.part.0.constprop.0+0x108>
    3edc:	f9400860 	ldr	x0, [x3, #16]
    3ee0:	cb130000 	sub	x0, x0, x19
    3ee4:	eb0002df 	cmp	x22, x0
    3ee8:	54000088 	b.hi	3ef8 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    3eec:	8b160260 	add	x0, x19, x22
    3ef0:	f9000460 	str	x0, [x3, #8]
    3ef4:	17ffffd5 	b	3e48 <fwp_data.part.0.constprop.0+0x58>
    3ef8:	52800001 	mov	w1, #0x0                   	// #0
    3efc:	d2800300 	mov	x0, #0x18                  	// #24
    3f00:	97fffcfc 	bl	32f0 <fwp_heap_alloc_slow>
    3f04:	aa0003f3 	mov	x19, x0
    3f08:	17ffffe6 	b	3ea0 <fwp_data.part.0.constprop.0+0xb0>
    3f0c:	97fff741 	bl	1c10 <fwp_heap_oom>

0000000000003f10 <f74>:
    3f10:	9e670003 	fmov	d3, x0
    3f14:	9e670021 	fmov	d1, x1
    3f18:	d2f80f20 	mov	x0, #0xc079000000000000    	// #-4577627546245398528
    3f1c:	1e6e1002 	fmov	d2, #1.000000000000000000e+00
    3f20:	1e630865 	fmul	d5, d3, d3
    3f24:	9e670000 	fmov	d0, x0
    3f28:	1e633842 	fsub	d2, d2, d3
    3f2c:	d10103ff 	sub	sp, sp, #0x40
    3f30:	1e600860 	fmul	d0, d3, d0
    3f34:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    3f38:	900000e2 	adrp	x2, 1f000 <__FRAME_END__+0x15ff0>
    3f3c:	f947f442 	ldr	x2, [x2, #4072]
    3f40:	1e653821 	fsub	d1, d1, d5
    3f44:	1e622842 	fadd	d2, d2, d2
    3f48:	a9027bfd 	stp	x29, x30, [sp, #32]
    3f4c:	9e670004 	fmov	d4, x0
    3f50:	910083fd 	add	x29, sp, #0x20
    3f54:	1e610800 	fmul	d0, d0, d1
    3f58:	a90353f3 	stp	x19, x20, [sp, #48]
    3f5c:	1e640821 	fmul	d1, d1, d4
    3f60:	f9400043 	ldr	x3, [x2]
    3f64:	f9000fe3 	str	x3, [sp, #24]
    3f68:	d2800003 	mov	x3, #0x0                   	// #0
    3f6c:	910023e1 	add	x1, sp, #0x8
    3f70:	52800000 	mov	w0, #0x0                   	// #0
    3f74:	1e623800 	fsub	d0, d0, d2
    3f78:	6d0087e0 	stp	d0, d1, [sp, #8]
    3f7c:	97ffff9d 	bl	3df0 <fwp_data.part.0.constprop.0>
    3f80:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xd10>
    3f84:	91134063 	add	x3, x3, #0x4d0
    3f88:	aa0003f3 	mov	x19, x0
    3f8c:	f949d861 	ldr	x1, [x3, #5040]
    3f90:	f949ec60 	ldr	x0, [x3, #5080]
    3f94:	cb010261 	sub	x1, x19, x1
    3f98:	eb00403f 	cmp	x1, x0, lsl #16
    3f9c:	54000322 	b.cs	4000 <f74+0xf0>  // b.hs, b.nlast
    3fa0:	d350fc22 	lsr	x2, x1, #16
    3fa4:	f949fc63 	ldr	x3, [x3, #5112]
    3fa8:	8b020842 	add	x2, x2, x2, lsl #2
    3fac:	d37df042 	lsl	x2, x2, #3
    3fb0:	8b020060 	add	x0, x3, x2
    3fb4:	f9401014 	ldr	x20, [x0, #32]
    3fb8:	b4000254 	cbz	x20, 4000 <f74+0xf0>
    3fbc:	38626862 	ldrb	w2, [x3, x2]
    3fc0:	7100085f 	cmp	w2, #0x2
    3fc4:	54000360 	b.eq	4030 <f74+0x120>  // b.none
    3fc8:	7100045f 	cmp	w2, #0x1
    3fcc:	540001a1 	b.ne	4000 <f74+0xf0>  // b.any
    3fd0:	29430002 	ldp	w2, w0, [x0, #24]
    3fd4:	92403c21 	and	x1, x1, #0xffff
    3fd8:	9b027c21 	mul	x1, x1, x2
    3fdc:	d360fc21 	lsr	x1, x1, #32
    3fe0:	eb00003f 	cmp	x1, x0
    3fe4:	540000e2 	b.cs	4000 <f74+0xf0>  // b.hs, b.nlast
    3fe8:	8b010294 	add	x20, x20, x1
    3fec:	39400280 	ldrb	w0, [x20]
    3ff0:	7103fc1f 	cmp	w0, #0xff
    3ff4:	54000240 	b.eq	403c <f74+0x12c>  // b.none
    3ff8:	52800020 	mov	w0, #0x1                   	// #1
    3ffc:	39000280 	strb	w0, [x20]
    4000:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    4004:	f947f400 	ldr	x0, [x0, #4072]
    4008:	f9400fe2 	ldr	x2, [sp, #24]
    400c:	f9400001 	ldr	x1, [x0]
    4010:	eb010042 	subs	x2, x2, x1
    4014:	d2800001 	mov	x1, #0x0                   	// #0
    4018:	54000181 	b.ne	4048 <f74+0x138>  // b.any
    401c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4020:	aa1303e0 	mov	x0, x19
    4024:	a94353f3 	ldp	x19, x20, [sp, #48]
    4028:	910103ff 	add	sp, sp, #0x40
    402c:	d65f03c0 	ret
    4030:	72003c3f 	tst	w1, #0xffff
    4034:	54fffe61 	b.ne	4000 <f74+0xf0>  // b.any
    4038:	17ffffed 	b	3fec <f74+0xdc>
    403c:	aa1403e0 	mov	x0, x20
    4040:	97fffb44 	bl	2d50 <fwp_rc_forget_slot>
    4044:	17ffffed 	b	3ff8 <f74+0xe8>
    4048:	97fff52a 	bl	14f0 <__stack_chk_fail@plt>
    404c:	d503201f 	nop

0000000000004050 <fwp_owned_entry74>:
    4050:	a9400400 	ldp	x0, x1, [x0]
    4054:	17ffffaf 	b	3f10 <f74>
    4058:	d503201f 	nop
    405c:	d503201f 	nop

0000000000004060 <e74>:
    4060:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4064:	910003fd 	mov	x29, sp
    4068:	a9400400 	ldp	x0, x1, [x0]
    406c:	f9000bf3 	str	x19, [sp, #16]
    4070:	97ffffa8 	bl	3f10 <f74>
    4074:	aa0003f3 	mov	x19, x0
    4078:	97fffcf6 	bl	3450 <fwp_rc_share>
    407c:	aa1303e0 	mov	x0, x19
    4080:	f9400bf3 	ldr	x19, [sp, #16]
    4084:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4088:	d65f03c0 	ret
    408c:	d503201f 	nop

0000000000004090 <fwp_map_finish_protected.isra.0>:
    4090:	d10183ff 	sub	sp, sp, #0x60
    4094:	a9027bfd 	stp	x29, x30, [sp, #32]
    4098:	910083fd 	add	x29, sp, #0x20
    409c:	a90563f7 	stp	x23, x24, [sp, #80]
    40a0:	aa0003f7 	mov	x23, x0
    40a4:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    40a8:	f947f400 	ldr	x0, [x0, #4072]
    40ac:	a9045bf5 	stp	x21, x22, [sp, #64]
    40b0:	a940d6e2 	ldp	x2, x21, [x23, #8]
    40b4:	f9400001 	ldr	x1, [x0]
    40b8:	f9000fe1 	str	x1, [sp, #24]
    40bc:	d2800001 	mov	x1, #0x0                   	// #0
    40c0:	b40005e2 	cbz	x2, 417c <fwp_map_finish_protected.isra.0+0xec>
    40c4:	b0000178 	adrp	x24, 31000 <fwp_root_context+0xd10>
    40c8:	91134318 	add	x24, x24, #0x4d0
    40cc:	a90353f3 	stp	x19, x20, [sp, #48]
    40d0:	910023f3 	add	x19, sp, #0x8
    40d4:	52800034 	mov	w20, #0x1                   	// #1
    40d8:	f94002e3 	ldr	x3, [x23]
    40dc:	aa1303e1 	mov	x1, x19
    40e0:	52800020 	mov	w0, #0x1                   	// #1
    40e4:	8b020c62 	add	x2, x3, x2, lsl #3
    40e8:	f85f8042 	ldur	x2, [x2, #-8]
    40ec:	a900d7e2 	stp	x2, x21, [sp, #8]
    40f0:	97ffff40 	bl	3df0 <fwp_data.part.0.constprop.0>
    40f4:	aa0003f5 	mov	x21, x0
    40f8:	f949db01 	ldr	x1, [x24, #5040]
    40fc:	f949ef02 	ldr	x2, [x24, #5080]
    4100:	cb010001 	sub	x1, x0, x1
    4104:	eb02403f 	cmp	x1, x2, lsl #16
    4108:	54000302 	b.cs	4168 <fwp_map_finish_protected.isra.0+0xd8>  // b.hs, b.nlast
    410c:	d350fc22 	lsr	x2, x1, #16
    4110:	f949ff04 	ldr	x4, [x24, #5112]
    4114:	8b020842 	add	x2, x2, x2, lsl #2
    4118:	d37df042 	lsl	x2, x2, #3
    411c:	8b020083 	add	x3, x4, x2
    4120:	f9401076 	ldr	x22, [x3, #32]
    4124:	b4000236 	cbz	x22, 4168 <fwp_map_finish_protected.isra.0+0xd8>
    4128:	38626882 	ldrb	w2, [x4, x2]
    412c:	7100085f 	cmp	w2, #0x2
    4130:	540004a0 	b.eq	41c4 <fwp_map_finish_protected.isra.0+0x134>  // b.none
    4134:	7100045f 	cmp	w2, #0x1
    4138:	54000181 	b.ne	4168 <fwp_map_finish_protected.isra.0+0xd8>  // b.any
    413c:	29430062 	ldp	w2, w0, [x3, #24]
    4140:	92403c21 	and	x1, x1, #0xffff
    4144:	9b027c21 	mul	x1, x1, x2
    4148:	d360fc21 	lsr	x1, x1, #32
    414c:	eb00003f 	cmp	x1, x0
    4150:	540000c2 	b.cs	4168 <fwp_map_finish_protected.isra.0+0xd8>  // b.hs, b.nlast
    4154:	8b0102d6 	add	x22, x22, x1
    4158:	394002c0 	ldrb	w0, [x22]
    415c:	7103fc1f 	cmp	w0, #0xff
    4160:	540002c0 	b.eq	41b8 <fwp_map_finish_protected.isra.0+0x128>  // b.none
    4164:	390002d4 	strb	w20, [x22]
    4168:	f94006e2 	ldr	x2, [x23, #8]
    416c:	d1000442 	sub	x2, x2, #0x1
    4170:	a900d6e2 	stp	x2, x21, [x23, #8]
    4174:	b5fffb22 	cbnz	x2, 40d8 <fwp_map_finish_protected.isra.0+0x48>
    4178:	a94353f3 	ldp	x19, x20, [sp, #48]
    417c:	f94002e0 	ldr	x0, [x23]
    4180:	97fffb94 	bl	2fd0 <fwp_mem_free>
    4184:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    4188:	f947f400 	ldr	x0, [x0, #4072]
    418c:	f9400fe2 	ldr	x2, [sp, #24]
    4190:	f9400001 	ldr	x1, [x0]
    4194:	eb010042 	subs	x2, x2, x1
    4198:	d2800001 	mov	x1, #0x0                   	// #0
    419c:	540001a1 	b.ne	41d0 <fwp_map_finish_protected.isra.0+0x140>  // b.any
    41a0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    41a4:	aa1503e0 	mov	x0, x21
    41a8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    41ac:	a94563f7 	ldp	x23, x24, [sp, #80]
    41b0:	910183ff 	add	sp, sp, #0x60
    41b4:	d65f03c0 	ret
    41b8:	aa1603e0 	mov	x0, x22
    41bc:	97fffae5 	bl	2d50 <fwp_rc_forget_slot>
    41c0:	17ffffe9 	b	4164 <fwp_map_finish_protected.isra.0+0xd4>
    41c4:	72003c3f 	tst	w1, #0xffff
    41c8:	54fffd01 	b.ne	4168 <fwp_map_finish_protected.isra.0+0xd8>  // b.any
    41cc:	17ffffe3 	b	4158 <fwp_map_finish_protected.isra.0+0xc8>
    41d0:	a90353f3 	stp	x19, x20, [sp, #48]
    41d4:	97fff4c7 	bl	14f0 <__stack_chk_fail@plt>
    41d8:	d503201f 	nop
    41dc:	d503201f 	nop

00000000000041e0 <fwp_drop4>:
    41e0:	b0000165 	adrp	x5, 31000 <fwp_root_context+0xd10>
    41e4:	911340a3 	add	x3, x5, #0x4d0
    41e8:	f949d861 	ldr	x1, [x3, #5040]
    41ec:	f949ec62 	ldr	x2, [x3, #5080]
    41f0:	cb010001 	sub	x1, x0, x1
    41f4:	eb02403f 	cmp	x1, x2, lsl #16
    41f8:	54000542 	b.cs	42a0 <fwp_drop4+0xc0>  // b.hs, b.nlast
    41fc:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4200:	d350fc22 	lsr	x2, x1, #16
    4204:	910003fd 	mov	x29, sp
    4208:	8b020842 	add	x2, x2, x2, lsl #2
    420c:	f949fc64 	ldr	x4, [x3, #5112]
    4210:	d37df042 	lsl	x2, x2, #3
    4214:	f9000bf3 	str	x19, [sp, #16]
    4218:	8b020083 	add	x3, x4, x2
    421c:	f9401073 	ldr	x19, [x3, #32]
    4220:	b40002b3 	cbz	x19, 4274 <fwp_drop4+0x94>
    4224:	38626882 	ldrb	w2, [x4, x2]
    4228:	7100085f 	cmp	w2, #0x2
    422c:	540002a0 	b.eq	4280 <fwp_drop4+0xa0>  // b.none
    4230:	7100045f 	cmp	w2, #0x1
    4234:	54000201 	b.ne	4274 <fwp_drop4+0x94>  // b.any
    4238:	29430864 	ldp	w4, w2, [x3, #24]
    423c:	92403c21 	and	x1, x1, #0xffff
    4240:	9b047c21 	mul	x1, x1, x4
    4244:	d360fc21 	lsr	x1, x1, #32
    4248:	eb02003f 	cmp	x1, x2
    424c:	54000142 	b.cs	4274 <fwp_drop4+0x94>  // b.hs, b.nlast
    4250:	8b010273 	add	x19, x19, x1
    4254:	39400261 	ldrb	w1, [x19]
    4258:	340000e1 	cbz	w1, 4274 <fwp_drop4+0x94>
    425c:	7100043f 	cmp	w1, #0x1
    4260:	540001a0 	b.eq	4294 <fwp_drop4+0xb4>  // b.none
    4264:	7103fc3f 	cmp	w1, #0xff
    4268:	540001e0 	b.eq	42a4 <fwp_drop4+0xc4>  // b.none
    426c:	51000421 	sub	w1, w1, #0x1
    4270:	39000261 	strb	w1, [x19]
    4274:	f9400bf3 	ldr	x19, [sp, #16]
    4278:	a8c27bfd 	ldp	x29, x30, [sp], #32
    427c:	d65f03c0 	ret
    4280:	72003c3f 	tst	w1, #0xffff
    4284:	54fffe80 	b.eq	4254 <fwp_drop4+0x74>  // b.none
    4288:	f9400bf3 	ldr	x19, [sp, #16]
    428c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4290:	d65f03c0 	ret
    4294:	f9400bf3 	ldr	x19, [sp, #16]
    4298:	a8c27bfd 	ldp	x29, x30, [sp], #32
    429c:	17fffb4d 	b	2fd0 <fwp_mem_free>
    42a0:	d65f03c0 	ret
    42a4:	ca534660 	eor	x0, x19, x19, lsr #17
    42a8:	911340a5 	add	x5, x5, #0x4d0
    42ac:	ca402400 	eor	x0, x0, x0, lsr #9
    42b0:	8b200ca0 	add	x0, x5, w0, uxtb #3
    42b4:	f94a2400 	ldr	x0, [x0, #5192]
    42b8:	b5000080 	cbnz	x0, 42c8 <fwp_drop4+0xe8>
    42bc:	14000010 	b	42fc <fwp_drop4+0x11c>
    42c0:	f9400800 	ldr	x0, [x0, #16]
    42c4:	b40001c0 	cbz	x0, 42fc <fwp_drop4+0x11c>
    42c8:	f9400001 	ldr	x1, [x0]
    42cc:	eb13003f 	cmp	x1, x19
    42d0:	54ffff81 	b.ne	42c0 <fwp_drop4+0xe0>  // b.any
    42d4:	f9400401 	ldr	x1, [x0, #8]
    42d8:	d1000421 	sub	x1, x1, #0x1
    42dc:	f9000401 	str	x1, [x0, #8]
    42e0:	f103f83f 	cmp	x1, #0xfe
    42e4:	54fffc81 	b.ne	4274 <fwp_drop4+0x94>  // b.any
    42e8:	aa1303e0 	mov	x0, x19
    42ec:	97fffa99 	bl	2d50 <fwp_rc_forget_slot>
    42f0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    42f4:	39000260 	strb	w0, [x19]
    42f8:	17ffffdf 	b	4274 <fwp_drop4+0x94>
    42fc:	f0000000 	adrp	x0, 7000 <fwp_main_thread+0x920>
    4300:	912e0000 	add	x0, x0, #0xb80
    4304:	97fff787 	bl	2120 <fwp_trap>
    4308:	d503201f 	nop
    430c:	d503201f 	nop

0000000000004310 <fwp_owned_entry50>:
    4310:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4314:	910003fd 	mov	x29, sp
    4318:	f9400000 	ldr	x0, [x0]
    431c:	f9000bf3 	str	x19, [sp, #16]
    4320:	f9400813 	ldr	x19, [x0, #16]
    4324:	97ffffaf 	bl	41e0 <fwp_drop4>
    4328:	aa1303e0 	mov	x0, x19
    432c:	f9400bf3 	ldr	x19, [sp, #16]
    4330:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4334:	d65f03c0 	ret
    4338:	d503201f 	nop
    433c:	d503201f 	nop

0000000000004340 <fwp_owned_entry47>:
    4340:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4344:	910003fd 	mov	x29, sp
    4348:	f9400000 	ldr	x0, [x0]
    434c:	f9000bf3 	str	x19, [sp, #16]
    4350:	f9400413 	ldr	x19, [x0, #8]
    4354:	97ffffa3 	bl	41e0 <fwp_drop4>
    4358:	aa1303e0 	mov	x0, x19
    435c:	f9400bf3 	ldr	x19, [sp, #16]
    4360:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4364:	d65f03c0 	ret
    4368:	d503201f 	nop
    436c:	d503201f 	nop

0000000000004370 <fwp_arg_drop47>:
    4370:	7100003f 	cmp	w1, #0x0
    4374:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4378:	54000041 	b.ne	4380 <fwp_arg_drop47+0x10>  // b.any
    437c:	d65f03c0 	ret
    4380:	f9400000 	ldr	x0, [x0]
    4384:	17ffff97 	b	41e0 <fwp_drop4>
    4388:	d503201f 	nop
    438c:	d503201f 	nop

0000000000004390 <e50>:
    4390:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4394:	910003fd 	mov	x29, sp
    4398:	a90153f3 	stp	x19, x20, [sp, #16]
    439c:	f9400013 	ldr	x19, [x0]
    43a0:	aa1303e0 	mov	x0, x19
    43a4:	97fffc2b 	bl	3450 <fwp_rc_share>
    43a8:	f9400a74 	ldr	x20, [x19, #16]
    43ac:	aa1303e0 	mov	x0, x19
    43b0:	97ffff8c 	bl	41e0 <fwp_drop4>
    43b4:	aa1403e0 	mov	x0, x20
    43b8:	97fffc26 	bl	3450 <fwp_rc_share>
    43bc:	aa1403e0 	mov	x0, x20
    43c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    43c4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43c8:	d65f03c0 	ret
    43cc:	d503201f 	nop

00000000000043d0 <e47>:
    43d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    43d4:	910003fd 	mov	x29, sp
    43d8:	a90153f3 	stp	x19, x20, [sp, #16]
    43dc:	f9400013 	ldr	x19, [x0]
    43e0:	aa1303e0 	mov	x0, x19
    43e4:	97fffc1b 	bl	3450 <fwp_rc_share>
    43e8:	f9400674 	ldr	x20, [x19, #8]
    43ec:	aa1303e0 	mov	x0, x19
    43f0:	97ffff7c 	bl	41e0 <fwp_drop4>
    43f4:	aa1403e0 	mov	x0, x20
    43f8:	97fffc16 	bl	3450 <fwp_rc_share>
    43fc:	aa1403e0 	mov	x0, x20
    4400:	a94153f3 	ldp	x19, x20, [sp, #16]
    4404:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4408:	d65f03c0 	ret
    440c:	d503201f 	nop

0000000000004410 <fwp_arg_drop50>:
    4410:	7100003f 	cmp	w1, #0x0
    4414:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4418:	54000041 	b.ne	4420 <fwp_arg_drop50+0x10>  // b.any
    441c:	d65f03c0 	ret
    4420:	f9400000 	ldr	x0, [x0]
    4424:	17ffff6f 	b	41e0 <fwp_drop4>
    4428:	d503201f 	nop
    442c:	d503201f 	nop

0000000000004430 <fwp_args47>:
    4430:	7100003f 	cmp	w1, #0x0
    4434:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    4438:	54000041 	b.ne	4440 <fwp_args47+0x10>  // b.any
    443c:	d65f03c0 	ret
    4440:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    4444:	91134042 	add	x2, x2, #0x4d0
    4448:	f9400001 	ldr	x1, [x0]
    444c:	f949d843 	ldr	x3, [x2, #5040]
    4450:	f949ec40 	ldr	x0, [x2, #5080]
    4454:	cb030021 	sub	x1, x1, x3
    4458:	eb00403f 	cmp	x1, x0, lsl #16
    445c:	54ffff02 	b.cs	443c <fwp_args47+0xc>  // b.hs, b.nlast
    4460:	d350fc20 	lsr	x0, x1, #16
    4464:	f949fc44 	ldr	x4, [x2, #5112]
    4468:	8b000800 	add	x0, x0, x0, lsl #2
    446c:	d37df002 	lsl	x2, x0, #3
    4470:	8b020083 	add	x3, x4, x2
    4474:	f9401060 	ldr	x0, [x3, #32]
    4478:	b4fffe20 	cbz	x0, 443c <fwp_args47+0xc>
    447c:	38626882 	ldrb	w2, [x4, x2]
    4480:	7100085f 	cmp	w2, #0x2
    4484:	54000220 	b.eq	44c8 <fwp_args47+0x98>  // b.none
    4488:	7100045f 	cmp	w2, #0x1
    448c:	54fffd81 	b.ne	443c <fwp_args47+0xc>  // b.any
    4490:	29430864 	ldp	w4, w2, [x3, #24]
    4494:	92403c21 	and	x1, x1, #0xffff
    4498:	9b047c21 	mul	x1, x1, x4
    449c:	d360fc21 	lsr	x1, x1, #32
    44a0:	eb02003f 	cmp	x1, x2
    44a4:	54fffcc2 	b.cs	443c <fwp_args47+0xc>  // b.hs, b.nlast
    44a8:	8b010000 	add	x0, x0, x1
    44ac:	39400001 	ldrb	w1, [x0]
    44b0:	34fffc61 	cbz	w1, 443c <fwp_args47+0xc>
    44b4:	7103f43f 	cmp	w1, #0xfd
    44b8:	540000e8 	b.hi	44d4 <fwp_args47+0xa4>  // b.pmore
    44bc:	11000421 	add	w1, w1, #0x1
    44c0:	39000001 	strb	w1, [x0]
    44c4:	d65f03c0 	ret
    44c8:	72003c3f 	tst	w1, #0xffff
    44cc:	54ffff00 	b.eq	44ac <fwp_args47+0x7c>  // b.none
    44d0:	d65f03c0 	ret
    44d4:	17fff9d8 	b	2c34 <fwp_rc_wide_dup>
    44d8:	d503201f 	nop
    44dc:	d503201f 	nop

00000000000044e0 <fwp_args50>:
    44e0:	7100003f 	cmp	w1, #0x0
    44e4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    44e8:	54000041 	b.ne	44f0 <fwp_args50+0x10>  // b.any
    44ec:	d65f03c0 	ret
    44f0:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    44f4:	91134042 	add	x2, x2, #0x4d0
    44f8:	f9400001 	ldr	x1, [x0]
    44fc:	f949d843 	ldr	x3, [x2, #5040]
    4500:	f949ec40 	ldr	x0, [x2, #5080]
    4504:	cb030021 	sub	x1, x1, x3
    4508:	eb00403f 	cmp	x1, x0, lsl #16
    450c:	54ffff02 	b.cs	44ec <fwp_args50+0xc>  // b.hs, b.nlast
    4510:	d350fc20 	lsr	x0, x1, #16
    4514:	f949fc44 	ldr	x4, [x2, #5112]
    4518:	8b000800 	add	x0, x0, x0, lsl #2
    451c:	d37df002 	lsl	x2, x0, #3
    4520:	8b020083 	add	x3, x4, x2
    4524:	f9401060 	ldr	x0, [x3, #32]
    4528:	b4fffe20 	cbz	x0, 44ec <fwp_args50+0xc>
    452c:	38626882 	ldrb	w2, [x4, x2]
    4530:	7100085f 	cmp	w2, #0x2
    4534:	54000220 	b.eq	4578 <fwp_args50+0x98>  // b.none
    4538:	7100045f 	cmp	w2, #0x1
    453c:	54fffd81 	b.ne	44ec <fwp_args50+0xc>  // b.any
    4540:	29430864 	ldp	w4, w2, [x3, #24]
    4544:	92403c21 	and	x1, x1, #0xffff
    4548:	9b047c21 	mul	x1, x1, x4
    454c:	d360fc21 	lsr	x1, x1, #32
    4550:	eb02003f 	cmp	x1, x2
    4554:	54fffcc2 	b.cs	44ec <fwp_args50+0xc>  // b.hs, b.nlast
    4558:	8b010000 	add	x0, x0, x1
    455c:	39400001 	ldrb	w1, [x0]
    4560:	34fffc61 	cbz	w1, 44ec <fwp_args50+0xc>
    4564:	7103f43f 	cmp	w1, #0xfd
    4568:	540000e8 	b.hi	4584 <fwp_args50+0xa4>  // b.pmore
    456c:	11000421 	add	w1, w1, #0x1
    4570:	39000001 	strb	w1, [x0]
    4574:	d65f03c0 	ret
    4578:	72003c3f 	tst	w1, #0xffff
    457c:	54ffff00 	b.eq	455c <fwp_args50+0x7c>  // b.none
    4580:	d65f03c0 	ret
    4584:	17fff9ac 	b	2c34 <fwp_rc_wide_dup>
    4588:	d503201f 	nop
    458c:	d503201f 	nop

0000000000004590 <fwp_caps47>:
    4590:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4594:	910003fd 	mov	x29, sp
    4598:	f9000bf3 	str	x19, [sp, #16]
    459c:	aa0003f3 	mov	x19, x0
    45a0:	b9400400 	ldr	w0, [x0, #4]
    45a4:	340004a0 	cbz	w0, 4638 <fwp_caps47+0xa8>
    45a8:	f9400660 	ldr	x0, [x19, #8]
    45ac:	350004e1 	cbnz	w1, 4648 <fwp_caps47+0xb8>
    45b0:	97ffff0c 	bl	41e0 <fwp_drop4>
    45b4:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    45b8:	91134042 	add	x2, x2, #0x4d0
    45bc:	f949d840 	ldr	x0, [x2, #5040]
    45c0:	f949ec41 	ldr	x1, [x2, #5080]
    45c4:	cb000260 	sub	x0, x19, x0
    45c8:	eb01401f 	cmp	x0, x1, lsl #16
    45cc:	54000382 	b.cs	463c <fwp_caps47+0xac>  // b.hs, b.nlast
    45d0:	d350fc01 	lsr	x1, x0, #16
    45d4:	f949fc44 	ldr	x4, [x2, #5112]
    45d8:	8b010821 	add	x1, x1, x1, lsl #2
    45dc:	d37df021 	lsl	x1, x1, #3
    45e0:	8b010083 	add	x3, x4, x1
    45e4:	f9401062 	ldr	x2, [x3, #32]
    45e8:	b40002a2 	cbz	x2, 463c <fwp_caps47+0xac>
    45ec:	38616881 	ldrb	w1, [x4, x1]
    45f0:	7100083f 	cmp	w1, #0x2
    45f4:	540006c0 	b.eq	46cc <fwp_caps47+0x13c>  // b.none
    45f8:	7100043f 	cmp	w1, #0x1
    45fc:	54000201 	b.ne	463c <fwp_caps47+0xac>  // b.any
    4600:	29430464 	ldp	w4, w1, [x3, #24]
    4604:	92403c00 	and	x0, x0, #0xffff
    4608:	9b047c00 	mul	x0, x0, x4
    460c:	d360fc00 	lsr	x0, x0, #32
    4610:	eb01001f 	cmp	x0, x1
    4614:	54000142 	b.cs	463c <fwp_caps47+0xac>  // b.hs, b.nlast
    4618:	8b000042 	add	x2, x2, x0
    461c:	39400040 	ldrb	w0, [x2]
    4620:	7100041f 	cmp	w0, #0x1
    4624:	540000c1 	b.ne	463c <fwp_caps47+0xac>  // b.any
    4628:	aa1303e0 	mov	x0, x19
    462c:	f9400bf3 	ldr	x19, [sp, #16]
    4630:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4634:	17fffa67 	b	2fd0 <fwp_mem_free>
    4638:	34fffbe1 	cbz	w1, 45b4 <fwp_caps47+0x24>
    463c:	f9400bf3 	ldr	x19, [sp, #16]
    4640:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4644:	d65f03c0 	ret
    4648:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    464c:	91134042 	add	x2, x2, #0x4d0
    4650:	f949d843 	ldr	x3, [x2, #5040]
    4654:	f949ec41 	ldr	x1, [x2, #5080]
    4658:	cb030000 	sub	x0, x0, x3
    465c:	eb01401f 	cmp	x0, x1, lsl #16
    4660:	54fffee2 	b.cs	463c <fwp_caps47+0xac>  // b.hs, b.nlast
    4664:	d350fc01 	lsr	x1, x0, #16
    4668:	f949fc44 	ldr	x4, [x2, #5112]
    466c:	8b010821 	add	x1, x1, x1, lsl #2
    4670:	d37df021 	lsl	x1, x1, #3
    4674:	8b010083 	add	x3, x4, x1
    4678:	f9401062 	ldr	x2, [x3, #32]
    467c:	b4fffe02 	cbz	x2, 463c <fwp_caps47+0xac>
    4680:	38616881 	ldrb	w1, [x4, x1]
    4684:	7100083f 	cmp	w1, #0x2
    4688:	54000280 	b.eq	46d8 <fwp_caps47+0x148>  // b.none
    468c:	7100043f 	cmp	w1, #0x1
    4690:	54fffd61 	b.ne	463c <fwp_caps47+0xac>  // b.any
    4694:	92403c01 	and	x1, x0, #0xffff
    4698:	29430064 	ldp	w4, w0, [x3, #24]
    469c:	9b047c21 	mul	x1, x1, x4
    46a0:	d360fc21 	lsr	x1, x1, #32
    46a4:	eb00003f 	cmp	x1, x0
    46a8:	54fffca2 	b.cs	463c <fwp_caps47+0xac>  // b.hs, b.nlast
    46ac:	8b010042 	add	x2, x2, x1
    46b0:	39400040 	ldrb	w0, [x2]
    46b4:	34fffc40 	cbz	w0, 463c <fwp_caps47+0xac>
    46b8:	7103f41f 	cmp	w0, #0xfd
    46bc:	54000148 	b.hi	46e4 <fwp_caps47+0x154>  // b.pmore
    46c0:	11000400 	add	w0, w0, #0x1
    46c4:	39000040 	strb	w0, [x2]
    46c8:	17ffffdd 	b	463c <fwp_caps47+0xac>
    46cc:	72003c1f 	tst	w0, #0xffff
    46d0:	54fffb61 	b.ne	463c <fwp_caps47+0xac>  // b.any
    46d4:	17ffffd2 	b	461c <fwp_caps47+0x8c>
    46d8:	72003c1f 	tst	w0, #0xffff
    46dc:	54fffb01 	b.ne	463c <fwp_caps47+0xac>  // b.any
    46e0:	17fffff4 	b	46b0 <fwp_caps47+0x120>
    46e4:	f9400bf3 	ldr	x19, [sp, #16]
    46e8:	aa0203e0 	mov	x0, x2
    46ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    46f0:	17fff951 	b	2c34 <fwp_rc_wide_dup>

00000000000046f4 <fwp_caps50>:
    46f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    46f8:	910003fd 	mov	x29, sp
    46fc:	f9000bf3 	str	x19, [sp, #16]
    4700:	aa0003f3 	mov	x19, x0
    4704:	b9400400 	ldr	w0, [x0, #4]
    4708:	340004a0 	cbz	w0, 479c <fwp_caps50+0xa8>
    470c:	f9400660 	ldr	x0, [x19, #8]
    4710:	350004e1 	cbnz	w1, 47ac <fwp_caps50+0xb8>
    4714:	97fffeb3 	bl	41e0 <fwp_drop4>
    4718:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    471c:	91134042 	add	x2, x2, #0x4d0
    4720:	f949d840 	ldr	x0, [x2, #5040]
    4724:	f949ec41 	ldr	x1, [x2, #5080]
    4728:	cb000260 	sub	x0, x19, x0
    472c:	eb01401f 	cmp	x0, x1, lsl #16
    4730:	54000382 	b.cs	47a0 <fwp_caps50+0xac>  // b.hs, b.nlast
    4734:	d350fc01 	lsr	x1, x0, #16
    4738:	f949fc44 	ldr	x4, [x2, #5112]
    473c:	8b010821 	add	x1, x1, x1, lsl #2
    4740:	d37df021 	lsl	x1, x1, #3
    4744:	8b010083 	add	x3, x4, x1
    4748:	f9401062 	ldr	x2, [x3, #32]
    474c:	b40002a2 	cbz	x2, 47a0 <fwp_caps50+0xac>
    4750:	38616881 	ldrb	w1, [x4, x1]
    4754:	7100083f 	cmp	w1, #0x2
    4758:	540006c0 	b.eq	4830 <fwp_caps50+0x13c>  // b.none
    475c:	7100043f 	cmp	w1, #0x1
    4760:	54000201 	b.ne	47a0 <fwp_caps50+0xac>  // b.any
    4764:	29430464 	ldp	w4, w1, [x3, #24]
    4768:	92403c00 	and	x0, x0, #0xffff
    476c:	9b047c00 	mul	x0, x0, x4
    4770:	d360fc00 	lsr	x0, x0, #32
    4774:	eb01001f 	cmp	x0, x1
    4778:	54000142 	b.cs	47a0 <fwp_caps50+0xac>  // b.hs, b.nlast
    477c:	8b000042 	add	x2, x2, x0
    4780:	39400040 	ldrb	w0, [x2]
    4784:	7100041f 	cmp	w0, #0x1
    4788:	540000c1 	b.ne	47a0 <fwp_caps50+0xac>  // b.any
    478c:	aa1303e0 	mov	x0, x19
    4790:	f9400bf3 	ldr	x19, [sp, #16]
    4794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4798:	17fffa0e 	b	2fd0 <fwp_mem_free>
    479c:	34fffbe1 	cbz	w1, 4718 <fwp_caps50+0x24>
    47a0:	f9400bf3 	ldr	x19, [sp, #16]
    47a4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    47a8:	d65f03c0 	ret
    47ac:	b0000162 	adrp	x2, 31000 <fwp_root_context+0xd10>
    47b0:	91134042 	add	x2, x2, #0x4d0
    47b4:	f949d843 	ldr	x3, [x2, #5040]
    47b8:	f949ec41 	ldr	x1, [x2, #5080]
    47bc:	cb030000 	sub	x0, x0, x3
    47c0:	eb01401f 	cmp	x0, x1, lsl #16
    47c4:	54fffee2 	b.cs	47a0 <fwp_caps50+0xac>  // b.hs, b.nlast
    47c8:	d350fc01 	lsr	x1, x0, #16
    47cc:	f949fc44 	ldr	x4, [x2, #5112]
    47d0:	8b010821 	add	x1, x1, x1, lsl #2
    47d4:	d37df021 	lsl	x1, x1, #3
    47d8:	8b010083 	add	x3, x4, x1
    47dc:	f9401062 	ldr	x2, [x3, #32]
    47e0:	b4fffe02 	cbz	x2, 47a0 <fwp_caps50+0xac>
    47e4:	38616881 	ldrb	w1, [x4, x1]
    47e8:	7100083f 	cmp	w1, #0x2
    47ec:	54000280 	b.eq	483c <fwp_caps50+0x148>  // b.none
    47f0:	7100043f 	cmp	w1, #0x1
    47f4:	54fffd61 	b.ne	47a0 <fwp_caps50+0xac>  // b.any
    47f8:	92403c01 	and	x1, x0, #0xffff
    47fc:	29430064 	ldp	w4, w0, [x3, #24]
    4800:	9b047c21 	mul	x1, x1, x4
    4804:	d360fc21 	lsr	x1, x1, #32
    4808:	eb00003f 	cmp	x1, x0
    480c:	54fffca2 	b.cs	47a0 <fwp_caps50+0xac>  // b.hs, b.nlast
    4810:	8b010042 	add	x2, x2, x1
    4814:	39400040 	ldrb	w0, [x2]
    4818:	34fffc40 	cbz	w0, 47a0 <fwp_caps50+0xac>
    481c:	7103f41f 	cmp	w0, #0xfd
    4820:	54000148 	b.hi	4848 <fwp_caps50+0x154>  // b.pmore
    4824:	11000400 	add	w0, w0, #0x1
    4828:	39000040 	strb	w0, [x2]
    482c:	17ffffdd 	b	47a0 <fwp_caps50+0xac>
    4830:	72003c1f 	tst	w0, #0xffff
    4834:	54fffb61 	b.ne	47a0 <fwp_caps50+0xac>  // b.any
    4838:	17ffffd2 	b	4780 <fwp_caps50+0x8c>
    483c:	72003c1f 	tst	w0, #0xffff
    4840:	54fffb01 	b.ne	47a0 <fwp_caps50+0xac>  // b.any
    4844:	17fffff4 	b	4814 <fwp_caps50+0x120>
    4848:	f9400bf3 	ldr	x19, [sp, #16]
    484c:	aa0203e0 	mov	x0, x2
    4850:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4854:	17fff8f8 	b	2c34 <fwp_rc_wide_dup>
    4858:	d503201f 	nop
    485c:	d503201f 	nop

0000000000004860 <fwp_drop0>:
    4860:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4864:	910003fd 	mov	x29, sp
    4868:	a90153f3 	stp	x19, x20, [sp, #16]
    486c:	f90013f5 	str	x21, [sp, #32]
    4870:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    4874:	911342b4 	add	x20, x21, #0x4d0
    4878:	f949da81 	ldr	x1, [x20, #5040]
    487c:	f949ee82 	ldr	x2, [x20, #5080]
    4880:	cb010001 	sub	x1, x0, x1
    4884:	eb02403f 	cmp	x1, x2, lsl #16
    4888:	54000382 	b.cs	48f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    488c:	d350fc22 	lsr	x2, x1, #16
    4890:	f949fe83 	ldr	x3, [x20, #5112]
    4894:	8b020842 	add	x2, x2, x2, lsl #2
    4898:	d37df042 	lsl	x2, x2, #3
    489c:	8b020064 	add	x4, x3, x2
    48a0:	f9401093 	ldr	x19, [x4, #32]
    48a4:	b40002b3 	cbz	x19, 48f8 <fwp_drop0+0x98>
    48a8:	38626862 	ldrb	w2, [x3, x2]
    48ac:	7100085f 	cmp	w2, #0x2
    48b0:	540002c0 	b.eq	4908 <fwp_drop0+0xa8>  // b.none
    48b4:	7100045f 	cmp	w2, #0x1
    48b8:	54000201 	b.ne	48f8 <fwp_drop0+0x98>  // b.any
    48bc:	29430885 	ldp	w5, w2, [x4, #24]
    48c0:	92403c21 	and	x1, x1, #0xffff
    48c4:	9b057c21 	mul	x1, x1, x5
    48c8:	d360fc21 	lsr	x1, x1, #32
    48cc:	eb02003f 	cmp	x1, x2
    48d0:	54000142 	b.cs	48f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    48d4:	8b010273 	add	x19, x19, x1
    48d8:	39400261 	ldrb	w1, [x19]
    48dc:	340000e1 	cbz	w1, 48f8 <fwp_drop0+0x98>
    48e0:	7100043f 	cmp	w1, #0x1
    48e4:	540001e0 	b.eq	4920 <fwp_drop0+0xc0>  // b.none
    48e8:	7103fc3f 	cmp	w1, #0xff
    48ec:	540006e0 	b.eq	49c8 <fwp_drop0+0x168>  // b.none
    48f0:	51000421 	sub	w1, w1, #0x1
    48f4:	39000261 	strb	w1, [x19]
    48f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48fc:	f94013f5 	ldr	x21, [sp, #32]
    4900:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4904:	d65f03c0 	ret
    4908:	72003c3f 	tst	w1, #0xffff
    490c:	54fffe60 	b.eq	48d8 <fwp_drop0+0x78>  // b.none
    4910:	a94153f3 	ldp	x19, x20, [sp, #16]
    4914:	f94013f5 	ldr	x21, [sp, #32]
    4918:	a8c37bfd 	ldp	x29, x30, [sp], #48
    491c:	d65f03c0 	ret
    4920:	911342a1 	add	x1, x21, #0x4d0
    4924:	f9400813 	ldr	x19, [x0, #16]
    4928:	f949ec25 	ldr	x5, [x1, #5080]
    492c:	f949d821 	ldr	x1, [x1, #5040]
    4930:	d370bca5 	lsl	x5, x5, #16
    4934:	cb010002 	sub	x2, x0, x1
    4938:	eb05005f 	cmp	x2, x5
    493c:	54000362 	b.cs	49a8 <fwp_drop0+0x148>  // b.hs, b.nlast
    4940:	d350fc44 	lsr	x4, x2, #16
    4944:	8b040884 	add	x4, x4, x4, lsl #2
    4948:	d37df084 	lsl	x4, x4, #3
    494c:	8b040067 	add	x7, x3, x4
    4950:	f94010e6 	ldr	x6, [x7, #32]
    4954:	b40002a6 	cbz	x6, 49a8 <fwp_drop0+0x148>
    4958:	38646863 	ldrb	w3, [x3, x4]
    495c:	7100087f 	cmp	w3, #0x2
    4960:	540002e0 	b.eq	49bc <fwp_drop0+0x15c>  // b.none
    4964:	7100047f 	cmp	w3, #0x1
    4968:	54000201 	b.ne	49a8 <fwp_drop0+0x148>  // b.any
    496c:	29430ce4 	ldp	w4, w3, [x7, #24]
    4970:	92403c42 	and	x2, x2, #0xffff
    4974:	9b047c42 	mul	x2, x2, x4
    4978:	d360fc42 	lsr	x2, x2, #32
    497c:	eb03005f 	cmp	x2, x3
    4980:	54000142 	b.cs	49a8 <fwp_drop0+0x148>  // b.hs, b.nlast
    4984:	8b0200c6 	add	x6, x6, x2
    4988:	394000c2 	ldrb	w2, [x6]
    498c:	7100045f 	cmp	w2, #0x1
    4990:	540000c1 	b.ne	49a8 <fwp_drop0+0x148>  // b.any
    4994:	97fff98f 	bl	2fd0 <fwp_mem_free>
    4998:	911342a0 	add	x0, x21, #0x4d0
    499c:	f949ec05 	ldr	x5, [x0, #5080]
    49a0:	f949d801 	ldr	x1, [x0, #5040]
    49a4:	d370bca5 	lsl	x5, x5, #16
    49a8:	cb010261 	sub	x1, x19, x1
    49ac:	eb05003f 	cmp	x1, x5
    49b0:	54fffa42 	b.cs	48f8 <fwp_drop0+0x98>  // b.hs, b.nlast
    49b4:	aa1303e0 	mov	x0, x19
    49b8:	17ffffb5 	b	488c <fwp_drop0+0x2c>
    49bc:	72003c5f 	tst	w2, #0xffff
    49c0:	54ffff41 	b.ne	49a8 <fwp_drop0+0x148>  // b.any
    49c4:	17fffff1 	b	4988 <fwp_drop0+0x128>
    49c8:	ca534661 	eor	x1, x19, x19, lsr #17
    49cc:	911342a0 	add	x0, x21, #0x4d0
    49d0:	ca412421 	eor	x1, x1, x1, lsr #9
    49d4:	8b210c01 	add	x1, x0, w1, uxtb #3
    49d8:	f94a2420 	ldr	x0, [x1, #5192]
    49dc:	b5000080 	cbnz	x0, 49ec <fwp_drop0+0x18c>
    49e0:	14000010 	b	4a20 <fwp_drop0+0x1c0>
    49e4:	f9400800 	ldr	x0, [x0, #16]
    49e8:	b40001c0 	cbz	x0, 4a20 <fwp_drop0+0x1c0>
    49ec:	f9400001 	ldr	x1, [x0]
    49f0:	eb13003f 	cmp	x1, x19
    49f4:	54ffff81 	b.ne	49e4 <fwp_drop0+0x184>  // b.any
    49f8:	f9400401 	ldr	x1, [x0, #8]
    49fc:	d1000421 	sub	x1, x1, #0x1
    4a00:	f9000401 	str	x1, [x0, #8]
    4a04:	f103f83f 	cmp	x1, #0xfe
    4a08:	54fff781 	b.ne	48f8 <fwp_drop0+0x98>  // b.any
    4a0c:	aa1303e0 	mov	x0, x19
    4a10:	97fff8d0 	bl	2d50 <fwp_rc_forget_slot>
    4a14:	12800020 	mov	w0, #0xfffffffe            	// #-2
    4a18:	39000260 	strb	w0, [x19]
    4a1c:	17ffffb7 	b	48f8 <fwp_drop0+0x98>
    4a20:	f0000000 	adrp	x0, 7000 <fwp_main_thread+0x920>
    4a24:	912e0000 	add	x0, x0, #0xb80
    4a28:	97fff5be 	bl	2120 <fwp_trap>
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_drop1>:
    4a30:	17ffff8c 	b	4860 <fwp_drop0>

0000000000004a34 <fwp_loop_fields68.constprop.0>:
    4a34:	d104c3ff 	sub	sp, sp, #0x130
    4a38:	aa0003e2 	mov	x2, x0
    4a3c:	f00000c1 	adrp	x1, 1f000 <__FRAME_END__+0x15ff0>
    4a40:	f947f421 	ldr	x1, [x1, #4072]
    4a44:	a90b7bfd 	stp	x29, x30, [sp, #176]
    4a48:	9102c3fd 	add	x29, sp, #0xb0
    4a4c:	f90013e0 	str	x0, [sp, #32]
    4a50:	a90c53f3 	stp	x19, x20, [sp, #192]
    4a54:	a90d5bf5 	stp	x21, x22, [sp, #208]
    4a58:	a90e63f7 	stp	x23, x24, [sp, #224]
    4a5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    4a60:	a91073fb 	stp	x27, x28, [sp, #256]
    4a64:	6d1127e8 	stp	d8, d9, [sp, #272]
    4a68:	fd0093ea 	str	d10, [sp, #288]
    4a6c:	f9400020 	ldr	x0, [x1]
    4a70:	f90057e0 	str	x0, [sp, #168]
    4a74:	d2800000 	mov	x0, #0x0                   	// #0
    4a78:	b4005422 	cbz	x2, 54fc <fwp_loop_fields68.constprop.0+0xac8>
    4a7c:	f9400840 	ldr	x0, [x2, #16]
    4a80:	f9000be0 	str	x0, [sp, #16]
    4a84:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xd10>
    4a88:	911342a2 	add	x2, x21, #0x4d0
    4a8c:	f9400be3 	ldr	x3, [sp, #16]
    4a90:	f949d841 	ldr	x1, [x2, #5040]
    4a94:	f949ec40 	ldr	x0, [x2, #5080]
    4a98:	cb010061 	sub	x1, x3, x1
    4a9c:	eb00403f 	cmp	x1, x0, lsl #16
    4aa0:	54000342 	b.cs	4b08 <fwp_loop_fields68.constprop.0+0xd4>  // b.hs, b.nlast
    4aa4:	d350fc20 	lsr	x0, x1, #16
    4aa8:	f949fc44 	ldr	x4, [x2, #5112]
    4aac:	8b000800 	add	x0, x0, x0, lsl #2
    4ab0:	d37df002 	lsl	x2, x0, #3
    4ab4:	8b020083 	add	x3, x4, x2
    4ab8:	f9401060 	ldr	x0, [x3, #32]
    4abc:	b4000260 	cbz	x0, 4b08 <fwp_loop_fields68.constprop.0+0xd4>
    4ac0:	38626882 	ldrb	w2, [x4, x2]
    4ac4:	7100085f 	cmp	w2, #0x2
    4ac8:	54004660 	b.eq	5394 <fwp_loop_fields68.constprop.0+0x960>  // b.none
    4acc:	7100045f 	cmp	w2, #0x1
    4ad0:	540001c1 	b.ne	4b08 <fwp_loop_fields68.constprop.0+0xd4>  // b.any
    4ad4:	29430864 	ldp	w4, w2, [x3, #24]
    4ad8:	92403c21 	and	x1, x1, #0xffff
    4adc:	9b047c21 	mul	x1, x1, x4
    4ae0:	d360fc21 	lsr	x1, x1, #32
    4ae4:	eb02003f 	cmp	x1, x2
    4ae8:	54000102 	b.cs	4b08 <fwp_loop_fields68.constprop.0+0xd4>  // b.hs, b.nlast
    4aec:	8b010000 	add	x0, x0, x1
    4af0:	39400001 	ldrb	w1, [x0]
    4af4:	340000a1 	cbz	w1, 4b08 <fwp_loop_fields68.constprop.0+0xd4>
    4af8:	7103f43f 	cmp	w1, #0xfd
    4afc:	54004fc8 	b.hi	54f4 <fwp_loop_fields68.constprop.0+0xac0>  // b.pmore
    4b00:	11000421 	add	w1, w1, #0x1
    4b04:	39000001 	strb	w1, [x0]
    4b08:	910103e0 	add	x0, sp, #0x40
    4b0c:	910263f4 	add	x20, sp, #0x98
    4b10:	aa0003e1 	mov	x1, x0
    4b14:	f90017e1 	str	x1, [sp, #40]
    4b18:	f9400be0 	ldr	x0, [sp, #16]
    4b1c:	d2800018 	mov	x24, #0x0                   	// #0
    4b20:	97fffbc0 	bl	3a20 <fwp_map_items>
    4b24:	aa0003fa 	mov	x26, x0
    4b28:	f94013e0 	ldr	x0, [sp, #32]
    4b2c:	90000003 	adrp	x3, 4000 <f74+0xf0>
    4b30:	b0000002 	adrp	x2, 5000 <fwp_loop_fields68.constprop.0+0x5cc>
    4b34:	91078063 	add	x3, x3, #0x1e0
    4b38:	91145042 	add	x2, x2, #0x514
    4b3c:	910123e1 	add	x1, sp, #0x48
    4b40:	f90007e1 	str	x1, [sp, #8]
    4b44:	f9002bfa 	str	x26, [sp, #80]
    4b48:	a905ffff 	stp	xzr, xzr, [sp, #88]
    4b4c:	a9068be3 	stp	x3, x2, [sp, #104]
    4b50:	97fffbb4 	bl	3a20 <fwp_map_items>
    4b54:	aa0003f6 	mov	x22, x0
    4b58:	a9444fe1 	ldp	x1, x19, [sp, #64]
    4b5c:	eb01027f 	cmp	x19, x1
    4b60:	9a819273 	csel	x19, x19, x1, ls	// ls = plast
    4b64:	b4003f73 	cbz	x19, 5350 <fwp_loop_fields68.constprop.0+0x91c>
    4b68:	911342bc 	add	x28, x21, #0x4d0
    4b6c:	d2f80f21 	mov	x1, #0xc079000000000000    	// #-4577627546245398528
    4b70:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    4b74:	9e670029 	fmov	d9, x1
    4b78:	9e670008 	fmov	d8, x0
    4b7c:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    4b80:	52800037 	mov	w23, #0x1                   	// #1
    4b84:	d503201f 	nop
    4b88:	fc787ac0 	ldr	d0, [x22, x24, lsl #3]
    4b8c:	aa1403e1 	mov	x1, x20
    4b90:	fc787b41 	ldr	d1, [x26, x24, lsl #3]
    4b94:	52800000 	mov	w0, #0x0                   	// #0
    4b98:	1e600803 	fmul	d3, d0, d0
    4b9c:	1e690802 	fmul	d2, d0, d9
    4ba0:	1e603940 	fsub	d0, d10, d0
    4ba4:	1e633821 	fsub	d1, d1, d3
    4ba8:	1e602800 	fadd	d0, d0, d0
    4bac:	1e610842 	fmul	d2, d2, d1
    4bb0:	1e680821 	fmul	d1, d1, d8
    4bb4:	1e603840 	fsub	d0, d2, d0
    4bb8:	6d0987e0 	stp	d0, d1, [sp, #152]
    4bbc:	97fffc8d 	bl	3df0 <fwp_data.part.0.constprop.0>
    4bc0:	aa0003f9 	mov	x25, x0
    4bc4:	f949db81 	ldr	x1, [x28, #5040]
    4bc8:	f949ef80 	ldr	x0, [x28, #5080]
    4bcc:	cb010321 	sub	x1, x25, x1
    4bd0:	eb00403f 	cmp	x1, x0, lsl #16
    4bd4:	54000302 	b.cs	4c34 <fwp_loop_fields68.constprop.0+0x200>  // b.hs, b.nlast
    4bd8:	d350fc22 	lsr	x2, x1, #16
    4bdc:	f949ff85 	ldr	x5, [x28, #5112]
    4be0:	8b020842 	add	x2, x2, x2, lsl #2
    4be4:	d37df042 	lsl	x2, x2, #3
    4be8:	8b0200a3 	add	x3, x5, x2
    4bec:	f940107b 	ldr	x27, [x3, #32]
    4bf0:	b400023b 	cbz	x27, 4c34 <fwp_loop_fields68.constprop.0+0x200>
    4bf4:	386268a0 	ldrb	w0, [x5, x2]
    4bf8:	7100081f 	cmp	w0, #0x2
    4bfc:	54003980 	b.eq	532c <fwp_loop_fields68.constprop.0+0x8f8>  // b.none
    4c00:	7100041f 	cmp	w0, #0x1
    4c04:	54000181 	b.ne	4c34 <fwp_loop_fields68.constprop.0+0x200>  // b.any
    4c08:	29430062 	ldp	w2, w0, [x3, #24]
    4c0c:	92403c21 	and	x1, x1, #0xffff
    4c10:	9b027c21 	mul	x1, x1, x2
    4c14:	d360fc21 	lsr	x1, x1, #32
    4c18:	eb00003f 	cmp	x1, x0
    4c1c:	540000c2 	b.cs	4c34 <fwp_loop_fields68.constprop.0+0x200>  // b.hs, b.nlast
    4c20:	8b01037b 	add	x27, x27, x1
    4c24:	39400360 	ldrb	w0, [x27]
    4c28:	7103fc1f 	cmp	w0, #0xff
    4c2c:	540037a0 	b.eq	5320 <fwp_loop_fields68.constprop.0+0x8ec>  // b.none
    4c30:	39000377 	strb	w23, [x27]
    4c34:	f8387b59 	str	x25, [x26, x24, lsl #3]
    4c38:	91000718 	add	x24, x24, #0x1
    4c3c:	f9002ff8 	str	x24, [sp, #88]
    4c40:	eb18027f 	cmp	x19, x24
    4c44:	54fffa21 	b.ne	4b88 <fwp_loop_fields68.constprop.0+0x154>  // b.any
    4c48:	aa1603e0 	mov	x0, x22
    4c4c:	97fff8e1 	bl	2fd0 <fwp_mem_free>
    4c50:	910143f7 	add	x23, sp, #0x50
    4c54:	aa1703e0 	mov	x0, x23
    4c58:	97fffd0e 	bl	4090 <fwp_map_finish_protected.isra.0>
    4c5c:	aa0003f9 	mov	x25, x0
    4c60:	f9400be0 	ldr	x0, [sp, #16]
    4c64:	f9000bf9 	str	x25, [sp, #16]
    4c68:	97fffefe 	bl	4860 <fwp_drop0>
    4c6c:	a9087fff 	stp	xzr, xzr, [sp, #128]
    4c70:	910203e1 	add	x1, sp, #0x80
    4c74:	52800020 	mov	w0, #0x1                   	// #1
    4c78:	97fffc5e 	bl	3df0 <fwp_data.part.0.constprop.0>
    4c7c:	911342a2 	add	x2, x21, #0x4d0
    4c80:	aa0003e3 	mov	x3, x0
    4c84:	f9000fe3 	str	x3, [sp, #24]
    4c88:	f949d841 	ldr	x1, [x2, #5040]
    4c8c:	f949ec40 	ldr	x0, [x2, #5080]
    4c90:	cb010061 	sub	x1, x3, x1
    4c94:	eb00403f 	cmp	x1, x0, lsl #16
    4c98:	54000322 	b.cs	4cfc <fwp_loop_fields68.constprop.0+0x2c8>  // b.hs, b.nlast
    4c9c:	d350fc20 	lsr	x0, x1, #16
    4ca0:	f949fc43 	ldr	x3, [x2, #5112]
    4ca4:	8b000800 	add	x0, x0, x0, lsl #2
    4ca8:	d37df002 	lsl	x2, x0, #3
    4cac:	8b020060 	add	x0, x3, x2
    4cb0:	f9401013 	ldr	x19, [x0, #32]
    4cb4:	b4000253 	cbz	x19, 4cfc <fwp_loop_fields68.constprop.0+0x2c8>
    4cb8:	38626862 	ldrb	w2, [x3, x2]
    4cbc:	7100085f 	cmp	w2, #0x2
    4cc0:	540035a0 	b.eq	5374 <fwp_loop_fields68.constprop.0+0x940>  // b.none
    4cc4:	7100045f 	cmp	w2, #0x1
    4cc8:	540001a1 	b.ne	4cfc <fwp_loop_fields68.constprop.0+0x2c8>  // b.any
    4ccc:	29430002 	ldp	w2, w0, [x0, #24]
    4cd0:	92403c21 	and	x1, x1, #0xffff
    4cd4:	9b027c21 	mul	x1, x1, x2
    4cd8:	d360fc21 	lsr	x1, x1, #32
    4cdc:	eb00003f 	cmp	x1, x0
    4ce0:	540000e2 	b.cs	4cfc <fwp_loop_fields68.constprop.0+0x2c8>  // b.hs, b.nlast
    4ce4:	8b010273 	add	x19, x19, x1
    4ce8:	39400260 	ldrb	w0, [x19]
    4cec:	7103fc1f 	cmp	w0, #0xff
    4cf0:	540034c0 	b.eq	5388 <fwp_loop_fields68.constprop.0+0x954>  // b.none
    4cf4:	52800020 	mov	w0, #0x1                   	// #1
    4cf8:	39000260 	strb	w0, [x19]
    4cfc:	a94083e1 	ldp	x1, x0, [sp, #8]
    4d00:	90000018 	adrp	x24, 4000 <f74+0xf0>
    4d04:	911342bc 	add	x28, x21, #0x4d0
    4d08:	d2800014 	mov	x20, #0x0                   	// #0
    4d0c:	97fffb45 	bl	3a20 <fwp_map_items>
    4d10:	aa0003f9 	mov	x25, x0
    4d14:	f94027f3 	ldr	x19, [sp, #72]
    4d18:	91218300 	add	x0, x24, #0x860
    4d1c:	f9002bf9 	str	x25, [sp, #80]
    4d20:	a905ffff 	stp	xzr, xzr, [sp, #88]
    4d24:	a90683ff 	stp	xzr, x0, [sp, #104]
    4d28:	b5000333 	cbnz	x19, 4d8c <fwp_loop_fields68.constprop.0+0x358>
    4d2c:	14000033 	b	4df8 <fwp_loop_fields68.constprop.0+0x3c4>
    4d30:	7100045f 	cmp	w2, #0x1
    4d34:	540001c1 	b.ne	4d6c <fwp_loop_fields68.constprop.0+0x338>  // b.any
    4d38:	29430865 	ldp	w5, w2, [x3, #24]
    4d3c:	92403c21 	and	x1, x1, #0xffff
    4d40:	9b057c21 	mul	x1, x1, x5
    4d44:	d360fc21 	lsr	x1, x1, #32
    4d48:	eb02003f 	cmp	x1, x2
    4d4c:	54000102 	b.cs	4d6c <fwp_loop_fields68.constprop.0+0x338>  // b.hs, b.nlast
    4d50:	8b010000 	add	x0, x0, x1
    4d54:	39400001 	ldrb	w1, [x0]
    4d58:	340000a1 	cbz	w1, 4d6c <fwp_loop_fields68.constprop.0+0x338>
    4d5c:	7103f43f 	cmp	w1, #0xfd
    4d60:	54003068 	b.hi	536c <fwp_loop_fields68.constprop.0+0x938>  // b.pmore
    4d64:	11000421 	add	w1, w1, #0x1
    4d68:	39000001 	strb	w1, [x0]
    4d6c:	f94006da 	ldr	x26, [x22, #8]
    4d70:	aa1603e0 	mov	x0, x22
    4d74:	97fffd1b 	bl	41e0 <fwp_drop4>
    4d78:	f8347b3a 	str	x26, [x25, x20, lsl #3]
    4d7c:	91000694 	add	x20, x20, #0x1
    4d80:	f9002ff4 	str	x20, [sp, #88]
    4d84:	eb13029f 	cmp	x20, x19
    4d88:	54000380 	b.eq	4df8 <fwp_loop_fields68.constprop.0+0x3c4>  // b.none
    4d8c:	f8747b36 	ldr	x22, [x25, x20, lsl #3]
    4d90:	f949db81 	ldr	x1, [x28, #5040]
    4d94:	f949ef80 	ldr	x0, [x28, #5080]
    4d98:	cb0102c1 	sub	x1, x22, x1
    4d9c:	eb00403f 	cmp	x1, x0, lsl #16
    4da0:	54fffe62 	b.cs	4d6c <fwp_loop_fields68.constprop.0+0x338>  // b.hs, b.nlast
    4da4:	d350fc22 	lsr	x2, x1, #16
    4da8:	f949ff85 	ldr	x5, [x28, #5112]
    4dac:	8b020842 	add	x2, x2, x2, lsl #2
    4db0:	d37df042 	lsl	x2, x2, #3
    4db4:	8b0200a3 	add	x3, x5, x2
    4db8:	f9401060 	ldr	x0, [x3, #32]
    4dbc:	b4fffd80 	cbz	x0, 4d6c <fwp_loop_fields68.constprop.0+0x338>
    4dc0:	386268a2 	ldrb	w2, [x5, x2]
    4dc4:	7100085f 	cmp	w2, #0x2
    4dc8:	54fffb41 	b.ne	4d30 <fwp_loop_fields68.constprop.0+0x2fc>  // b.any
    4dcc:	72003c3f 	tst	w1, #0xffff
    4dd0:	54fffc20 	b.eq	4d54 <fwp_loop_fields68.constprop.0+0x320>  // b.none
    4dd4:	f94006da 	ldr	x26, [x22, #8]
    4dd8:	aa1603e0 	mov	x0, x22
    4ddc:	97fffd01 	bl	41e0 <fwp_drop4>
    4de0:	f8347b3a 	str	x26, [x25, x20, lsl #3]
    4de4:	91000694 	add	x20, x20, #0x1
    4de8:	f9002ff4 	str	x20, [sp, #88]
    4dec:	eb13029f 	cmp	x20, x19
    4df0:	54fffce1 	b.ne	4d8c <fwp_loop_fields68.constprop.0+0x358>  // b.any
    4df4:	d503201f 	nop
    4df8:	aa1703e0 	mov	x0, x23
    4dfc:	97fffca5 	bl	4090 <fwp_map_finish_protected.isra.0>
    4e00:	aa1703e1 	mov	x1, x23
    4e04:	f9001fe0 	str	x0, [sp, #56]
    4e08:	97fffb06 	bl	3a20 <fwp_map_items>
    4e0c:	f9001be0 	str	x0, [sp, #48]
    4e10:	911342a2 	add	x2, x21, #0x4d0
    4e14:	f9400fe3 	ldr	x3, [sp, #24]
    4e18:	f949d841 	ldr	x1, [x2, #5040]
    4e1c:	f949ec40 	ldr	x0, [x2, #5080]
    4e20:	cb010061 	sub	x1, x3, x1
    4e24:	eb00403f 	cmp	x1, x0, lsl #16
    4e28:	54000342 	b.cs	4e90 <fwp_loop_fields68.constprop.0+0x45c>  // b.hs, b.nlast
    4e2c:	d350fc20 	lsr	x0, x1, #16
    4e30:	f949fc44 	ldr	x4, [x2, #5112]
    4e34:	8b000800 	add	x0, x0, x0, lsl #2
    4e38:	d37df002 	lsl	x2, x0, #3
    4e3c:	8b020083 	add	x3, x4, x2
    4e40:	f9401060 	ldr	x0, [x3, #32]
    4e44:	b4000260 	cbz	x0, 4e90 <fwp_loop_fields68.constprop.0+0x45c>
    4e48:	38626882 	ldrb	w2, [x4, x2]
    4e4c:	7100085f 	cmp	w2, #0x2
    4e50:	54002a80 	b.eq	53a0 <fwp_loop_fields68.constprop.0+0x96c>  // b.none
    4e54:	7100045f 	cmp	w2, #0x1
    4e58:	540001c1 	b.ne	4e90 <fwp_loop_fields68.constprop.0+0x45c>  // b.any
    4e5c:	29430864 	ldp	w4, w2, [x3, #24]
    4e60:	92403c21 	and	x1, x1, #0xffff
    4e64:	9b047c21 	mul	x1, x1, x4
    4e68:	d360fc21 	lsr	x1, x1, #32
    4e6c:	eb02003f 	cmp	x1, x2
    4e70:	54000102 	b.cs	4e90 <fwp_loop_fields68.constprop.0+0x45c>  // b.hs, b.nlast
    4e74:	8b010000 	add	x0, x0, x1
    4e78:	39400001 	ldrb	w1, [x0]
    4e7c:	340000a1 	cbz	w1, 4e90 <fwp_loop_fields68.constprop.0+0x45c>
    4e80:	7103f43f 	cmp	w1, #0xfd
    4e84:	54003348 	b.hi	54ec <fwp_loop_fields68.constprop.0+0xab8>  // b.pmore
    4e88:	11000421 	add	w1, w1, #0x1
    4e8c:	39000001 	strb	w1, [x0]
    4e90:	f9402bfb 	ldr	x27, [sp, #80]
    4e94:	f9400ff3 	ldr	x19, [sp, #24]
    4e98:	b400055b 	cbz	x27, 4f40 <fwp_loop_fields68.constprop.0+0x50c>
    4e9c:	f9401be0 	ldr	x0, [sp, #48]
    4ea0:	910263f4 	add	x20, sp, #0x98
    4ea4:	911342b9 	add	x25, x21, #0x4d0
    4ea8:	5280003c 	mov	w28, #0x1                   	// #1
    4eac:	d1002016 	sub	x22, x0, #0x8
    4eb0:	f87b7ac2 	ldr	x2, [x22, x27, lsl #3]
    4eb4:	aa1403e1 	mov	x1, x20
    4eb8:	52800020 	mov	w0, #0x1                   	// #1
    4ebc:	a909cfe2 	stp	x2, x19, [sp, #152]
    4ec0:	97fffbcc 	bl	3df0 <fwp_data.part.0.constprop.0>
    4ec4:	aa0003f3 	mov	x19, x0
    4ec8:	f949db21 	ldr	x1, [x25, #5040]
    4ecc:	f949ef20 	ldr	x0, [x25, #5080]
    4ed0:	cb010261 	sub	x1, x19, x1
    4ed4:	eb00403f 	cmp	x1, x0, lsl #16
    4ed8:	54000302 	b.cs	4f38 <fwp_loop_fields68.constprop.0+0x504>  // b.hs, b.nlast
    4edc:	d350fc20 	lsr	x0, x1, #16
    4ee0:	f949ff26 	ldr	x6, [x25, #5112]
    4ee4:	8b000800 	add	x0, x0, x0, lsl #2
    4ee8:	d37df002 	lsl	x2, x0, #3
    4eec:	8b0200c5 	add	x5, x6, x2
    4ef0:	f94010ba 	ldr	x26, [x5, #32]
    4ef4:	b400023a 	cbz	x26, 4f38 <fwp_loop_fields68.constprop.0+0x504>
    4ef8:	386268c2 	ldrb	w2, [x6, x2]
    4efc:	7100085f 	cmp	w2, #0x2
    4f00:	54002220 	b.eq	5344 <fwp_loop_fields68.constprop.0+0x910>  // b.none
    4f04:	7100045f 	cmp	w2, #0x1
    4f08:	54000181 	b.ne	4f38 <fwp_loop_fields68.constprop.0+0x504>  // b.any
    4f0c:	294308a6 	ldp	w6, w2, [x5, #24]
    4f10:	92403c21 	and	x1, x1, #0xffff
    4f14:	9b067c21 	mul	x1, x1, x6
    4f18:	d360fc21 	lsr	x1, x1, #32
    4f1c:	eb02003f 	cmp	x1, x2
    4f20:	540000c2 	b.cs	4f38 <fwp_loop_fields68.constprop.0+0x504>  // b.hs, b.nlast
    4f24:	8b01035a 	add	x26, x26, x1
    4f28:	39400341 	ldrb	w1, [x26]
    4f2c:	7103fc3f 	cmp	w1, #0xff
    4f30:	54002040 	b.eq	5338 <fwp_loop_fields68.constprop.0+0x904>  // b.none
    4f34:	3900035c 	strb	w28, [x26]
    4f38:	f100077b 	subs	x27, x27, #0x1
    4f3c:	54fffba1 	b.ne	4eb0 <fwp_loop_fields68.constprop.0+0x47c>  // b.any
    4f40:	f9401be0 	ldr	x0, [sp, #48]
    4f44:	b4000040 	cbz	x0, 4f4c <fwp_loop_fields68.constprop.0+0x518>
    4f48:	97fff822 	bl	2fd0 <fwp_mem_free>
    4f4c:	f9400fe0 	ldr	x0, [sp, #24]
    4f50:	911342bc 	add	x28, x21, #0x4d0
    4f54:	d2800016 	mov	x22, #0x0                   	// #0
    4f58:	97fffe42 	bl	4860 <fwp_drop0>
    4f5c:	f9401fe0 	ldr	x0, [sp, #56]
    4f60:	97fffe40 	bl	4860 <fwp_drop0>
    4f64:	a94083e1 	ldp	x1, x0, [sp, #8]
    4f68:	97fffaae 	bl	3a20 <fwp_map_items>
    4f6c:	aa0003f9 	mov	x25, x0
    4f70:	f94027f4 	ldr	x20, [sp, #72]
    4f74:	91218300 	add	x0, x24, #0x860
    4f78:	f9002bf9 	str	x25, [sp, #80]
    4f7c:	a905ffff 	stp	xzr, xzr, [sp, #88]
    4f80:	a90683ff 	stp	xzr, x0, [sp, #104]
    4f84:	b5000334 	cbnz	x20, 4fe8 <fwp_loop_fields68.constprop.0+0x5b4>
    4f88:	14000032 	b	5050 <fwp_loop_fields68.constprop.0+0x61c>
    4f8c:	7100045f 	cmp	w2, #0x1
    4f90:	540001c1 	b.ne	4fc8 <fwp_loop_fields68.constprop.0+0x594>  // b.any
    4f94:	29430865 	ldp	w5, w2, [x3, #24]
    4f98:	92403c21 	and	x1, x1, #0xffff
    4f9c:	9b057c21 	mul	x1, x1, x5
    4fa0:	d360fc21 	lsr	x1, x1, #32
    4fa4:	eb02003f 	cmp	x1, x2
    4fa8:	54000102 	b.cs	4fc8 <fwp_loop_fields68.constprop.0+0x594>  // b.hs, b.nlast
    4fac:	8b010000 	add	x0, x0, x1
    4fb0:	39400001 	ldrb	w1, [x0]
    4fb4:	340000a1 	cbz	w1, 4fc8 <fwp_loop_fields68.constprop.0+0x594>
    4fb8:	7103f43f 	cmp	w1, #0xfd
    4fbc:	54001d48 	b.hi	5364 <fwp_loop_fields68.constprop.0+0x930>  // b.pmore
    4fc0:	11000421 	add	w1, w1, #0x1
    4fc4:	39000001 	strb	w1, [x0]
    4fc8:	f9400b7a 	ldr	x26, [x27, #16]
    4fcc:	aa1b03e0 	mov	x0, x27
    4fd0:	97fffc84 	bl	41e0 <fwp_drop4>
    4fd4:	f8367b3a 	str	x26, [x25, x22, lsl #3]
    4fd8:	910006d6 	add	x22, x22, #0x1
    4fdc:	f9002ff6 	str	x22, [sp, #88]
    4fe0:	eb1402df 	cmp	x22, x20
    4fe4:	54000360 	b.eq	5050 <fwp_loop_fields68.constprop.0+0x61c>  // b.none
    4fe8:	f8767b3b 	ldr	x27, [x25, x22, lsl #3]
    4fec:	f949db81 	ldr	x1, [x28, #5040]
    4ff0:	f949ef80 	ldr	x0, [x28, #5080]
    4ff4:	cb010361 	sub	x1, x27, x1
    4ff8:	eb00403f 	cmp	x1, x0, lsl #16
    4ffc:	54fffe62 	b.cs	4fc8 <fwp_loop_fields68.constprop.0+0x594>  // b.hs, b.nlast
    5000:	d350fc22 	lsr	x2, x1, #16
    5004:	f949ff85 	ldr	x5, [x28, #5112]
    5008:	8b020842 	add	x2, x2, x2, lsl #2
    500c:	d37df042 	lsl	x2, x2, #3
    5010:	8b0200a3 	add	x3, x5, x2
    5014:	f9401060 	ldr	x0, [x3, #32]
    5018:	b4fffd80 	cbz	x0, 4fc8 <fwp_loop_fields68.constprop.0+0x594>
    501c:	386268a2 	ldrb	w2, [x5, x2]
    5020:	7100085f 	cmp	w2, #0x2
    5024:	54fffb41 	b.ne	4f8c <fwp_loop_fields68.constprop.0+0x558>  // b.any
    5028:	72003c3f 	tst	w1, #0xffff
    502c:	54fffc20 	b.eq	4fb0 <fwp_loop_fields68.constprop.0+0x57c>  // b.none
    5030:	f9400b7a 	ldr	x26, [x27, #16]
    5034:	aa1b03e0 	mov	x0, x27
    5038:	97fffc6a 	bl	41e0 <fwp_drop4>
    503c:	f8367b3a 	str	x26, [x25, x22, lsl #3]
    5040:	910006d6 	add	x22, x22, #0x1
    5044:	f9002ff6 	str	x22, [sp, #88]
    5048:	eb1402df 	cmp	x22, x20
    504c:	54fffce1 	b.ne	4fe8 <fwp_loop_fields68.constprop.0+0x5b4>  // b.any
    5050:	911342b6 	add	x22, x21, #0x4d0
    5054:	aa1703e0 	mov	x0, x23
    5058:	97fffc0e 	bl	4090 <fwp_map_finish_protected.isra.0>
    505c:	aa0003fb 	mov	x27, x0
    5060:	f9400be2 	ldr	x2, [sp, #16]
    5064:	f949dac1 	ldr	x1, [x22, #5040]
    5068:	f949eec0 	ldr	x0, [x22, #5080]
    506c:	cb010041 	sub	x1, x2, x1
    5070:	eb00403f 	cmp	x1, x0, lsl #16
    5074:	540003a2 	b.cs	50e8 <fwp_loop_fields68.constprop.0+0x6b4>  // b.hs, b.nlast
    5078:	d350fc22 	lsr	x2, x1, #16
    507c:	f949fec3 	ldr	x3, [x22, #5112]
    5080:	8b020842 	add	x2, x2, x2, lsl #2
    5084:	d37df042 	lsl	x2, x2, #3
    5088:	8b020060 	add	x0, x3, x2
    508c:	f9401014 	ldr	x20, [x0, #32]
    5090:	b40002d4 	cbz	x20, 50e8 <fwp_loop_fields68.constprop.0+0x6b4>
    5094:	38626862 	ldrb	w2, [x3, x2]
    5098:	7100085f 	cmp	w2, #0x2
    509c:	540015e0 	b.eq	5358 <fwp_loop_fields68.constprop.0+0x924>  // b.none
    50a0:	7100045f 	cmp	w2, #0x1
    50a4:	54000221 	b.ne	50e8 <fwp_loop_fields68.constprop.0+0x6b4>  // b.any
    50a8:	29430002 	ldp	w2, w0, [x0, #24]
    50ac:	92403c21 	and	x1, x1, #0xffff
    50b0:	9b027c21 	mul	x1, x1, x2
    50b4:	d360fc21 	lsr	x1, x1, #32
    50b8:	eb00003f 	cmp	x1, x0
    50bc:	54000162 	b.cs	50e8 <fwp_loop_fields68.constprop.0+0x6b4>  // b.hs, b.nlast
    50c0:	8b010294 	add	x20, x20, x1
    50c4:	39400280 	ldrb	w0, [x20]
    50c8:	34000100 	cbz	w0, 50e8 <fwp_loop_fields68.constprop.0+0x6b4>
    50cc:	7100041f 	cmp	w0, #0x1
    50d0:	54001740 	b.eq	53b8 <fwp_loop_fields68.constprop.0+0x984>  // b.none
    50d4:	7103fc1f 	cmp	w0, #0xff
    50d8:	54001de0 	b.eq	5494 <fwp_loop_fields68.constprop.0+0xa60>  // b.none
    50dc:	51000400 	sub	w0, w0, #0x1
    50e0:	39000280 	strb	w0, [x20]
    50e4:	d503201f 	nop
    50e8:	911342b5 	add	x21, x21, #0x4d0
    50ec:	910263e1 	add	x1, sp, #0x98
    50f0:	52800020 	mov	w0, #0x1                   	// #1
    50f4:	a909efff 	stp	xzr, x27, [sp, #152]
    50f8:	97fffb3e 	bl	3df0 <fwp_data.part.0.constprop.0>
    50fc:	f949daa1 	ldr	x1, [x21, #5040]
    5100:	aa0003f6 	mov	x22, x0
    5104:	f949eea0 	ldr	x0, [x21, #5080]
    5108:	cb0102c1 	sub	x1, x22, x1
    510c:	eb00403f 	cmp	x1, x0, lsl #16
    5110:	54000322 	b.cs	5174 <fwp_loop_fields68.constprop.0+0x740>  // b.hs, b.nlast
    5114:	d350fc20 	lsr	x0, x1, #16
    5118:	f949fea3 	ldr	x3, [x21, #5112]
    511c:	8b000800 	add	x0, x0, x0, lsl #2
    5120:	d37df002 	lsl	x2, x0, #3
    5124:	8b020060 	add	x0, x3, x2
    5128:	f9401014 	ldr	x20, [x0, #32]
    512c:	b4000254 	cbz	x20, 5174 <fwp_loop_fields68.constprop.0+0x740>
    5130:	38626862 	ldrb	w2, [x3, x2]
    5134:	7100085f 	cmp	w2, #0x2
    5138:	540013a0 	b.eq	53ac <fwp_loop_fields68.constprop.0+0x978>  // b.none
    513c:	7100045f 	cmp	w2, #0x1
    5140:	540001a1 	b.ne	5174 <fwp_loop_fields68.constprop.0+0x740>  // b.any
    5144:	29430002 	ldp	w2, w0, [x0, #24]
    5148:	92403c21 	and	x1, x1, #0xffff
    514c:	9b027c21 	mul	x1, x1, x2
    5150:	d360fc21 	lsr	x1, x1, #32
    5154:	eb00003f 	cmp	x1, x0
    5158:	540000e2 	b.cs	5174 <fwp_loop_fields68.constprop.0+0x740>  // b.hs, b.nlast
    515c:	8b010294 	add	x20, x20, x1
    5160:	39400280 	ldrb	w0, [x20]
    5164:	7103fc1f 	cmp	w0, #0xff
    5168:	540018a0 	b.eq	547c <fwp_loop_fields68.constprop.0+0xa48>  // b.none
    516c:	52800020 	mov	w0, #0x1                   	// #1
    5170:	39000280 	strb	w0, [x20]
    5174:	f94017e1 	ldr	x1, [sp, #40]
    5178:	aa1603e0 	mov	x0, x22
    517c:	97fffa29 	bl	3a20 <fwp_map_items>
    5180:	aa0003f4 	mov	x20, x0
    5184:	f94007e1 	ldr	x1, [sp, #8]
    5188:	91218302 	add	x2, x24, #0x860
    518c:	aa1303e0 	mov	x0, x19
    5190:	f9002bf4 	str	x20, [sp, #80]
    5194:	a905ffff 	stp	xzr, xzr, [sp, #88]
    5198:	a9068bff 	stp	xzr, x2, [sp, #104]
    519c:	97fffa21 	bl	3a20 <fwp_map_items>
    51a0:	a9440be1 	ldp	x1, x2, [sp, #64]
    51a4:	eb01005f 	cmp	x2, x1
    51a8:	9a819042 	csel	x2, x2, x1, ls	// ls = plast
    51ac:	b4001602 	cbz	x2, 546c <fwp_loop_fields68.constprop.0+0xa38>
    51b0:	d2800001 	mov	x1, #0x0                   	// #0
    51b4:	d503201f 	nop
    51b8:	fc617800 	ldr	d0, [x0, x1, lsl #3]
    51bc:	fc617a81 	ldr	d1, [x20, x1, lsl #3]
    51c0:	1e612800 	fadd	d0, d0, d1
    51c4:	fc217a80 	str	d0, [x20, x1, lsl #3]
    51c8:	91000421 	add	x1, x1, #0x1
    51cc:	eb01005f 	cmp	x2, x1
    51d0:	54ffff41 	b.ne	51b8 <fwp_loop_fields68.constprop.0+0x784>  // b.any
    51d4:	f9002fe2 	str	x2, [sp, #88]
    51d8:	97fff77e 	bl	2fd0 <fwp_mem_free>
    51dc:	aa1703e0 	mov	x0, x23
    51e0:	97fffbac 	bl	4090 <fwp_map_finish_protected.isra.0>
    51e4:	aa0003e1 	mov	x1, x0
    51e8:	aa1303e0 	mov	x0, x19
    51ec:	aa0103f3 	mov	x19, x1
    51f0:	97fffd9c 	bl	4860 <fwp_drop0>
    51f4:	aa1603e0 	mov	x0, x22
    51f8:	97fffd9a 	bl	4860 <fwp_drop0>
    51fc:	f94007e1 	ldr	x1, [sp, #8]
    5200:	aa1303e0 	mov	x0, x19
    5204:	97fffa07 	bl	3a20 <fwp_map_items>
    5208:	aa0003e1 	mov	x1, x0
    520c:	f94027e2 	ldr	x2, [sp, #72]
    5210:	91218300 	add	x0, x24, #0x860
    5214:	f9002be1 	str	x1, [sp, #80]
    5218:	a905ffff 	stp	xzr, xzr, [sp, #88]
    521c:	a90683ff 	stp	xzr, x0, [sp, #104]
    5220:	b4000142 	cbz	x2, 5248 <fwp_loop_fields68.constprop.0+0x814>
    5224:	d0000000 	adrp	x0, 7000 <fwp_main_thread+0x920>
    5228:	fd477001 	ldr	d1, [x0, #3808]
    522c:	8b020c20 	add	x0, x1, x2, lsl #3
    5230:	fd400020 	ldr	d0, [x1]
    5234:	1e600820 	fmul	d0, d1, d0
    5238:	fc008420 	str	d0, [x1], #8
    523c:	eb00003f 	cmp	x1, x0
    5240:	54ffff81 	b.ne	5230 <fwp_loop_fields68.constprop.0+0x7fc>  // b.any
    5244:	f9002fe2 	str	x2, [sp, #88]
    5248:	aa1703e0 	mov	x0, x23
    524c:	97fffb91 	bl	4090 <fwp_map_finish_protected.isra.0>
    5250:	aa0003f4 	mov	x20, x0
    5254:	aa1303e0 	mov	x0, x19
    5258:	97fffd82 	bl	4860 <fwp_drop0>
    525c:	91218318 	add	x24, x24, #0x860
    5260:	a94207e0 	ldp	x0, x1, [sp, #32]
    5264:	97fff9ef 	bl	3a20 <fwp_map_items>
    5268:	aa0003f3 	mov	x19, x0
    526c:	f94007e1 	ldr	x1, [sp, #8]
    5270:	aa1403e0 	mov	x0, x20
    5274:	f9002bf3 	str	x19, [sp, #80]
    5278:	a905ffff 	stp	xzr, xzr, [sp, #88]
    527c:	a906e3ff 	stp	xzr, x24, [sp, #104]
    5280:	97fff9e8 	bl	3a20 <fwp_map_items>
    5284:	a9440be1 	ldp	x1, x2, [sp, #64]
    5288:	eb01005f 	cmp	x2, x1
    528c:	9a819042 	csel	x2, x2, x1, ls	// ls = plast
    5290:	b4000f22 	cbz	x2, 5474 <fwp_loop_fields68.constprop.0+0xa40>
    5294:	d2800001 	mov	x1, #0x0                   	// #0
    5298:	fc617a60 	ldr	d0, [x19, x1, lsl #3]
    529c:	fc617801 	ldr	d1, [x0, x1, lsl #3]
    52a0:	1e613800 	fsub	d0, d0, d1
    52a4:	fc217a60 	str	d0, [x19, x1, lsl #3]
    52a8:	91000421 	add	x1, x1, #0x1
    52ac:	eb01005f 	cmp	x2, x1
    52b0:	54ffff41 	b.ne	5298 <fwp_loop_fields68.constprop.0+0x864>  // b.any
    52b4:	f9002fe2 	str	x2, [sp, #88]
    52b8:	97fff746 	bl	2fd0 <fwp_mem_free>
    52bc:	aa1703e0 	mov	x0, x23
    52c0:	97fffb74 	bl	4090 <fwp_map_finish_protected.isra.0>
    52c4:	aa0003f3 	mov	x19, x0
    52c8:	aa1403e0 	mov	x0, x20
    52cc:	97fffd65 	bl	4860 <fwp_drop0>
    52d0:	f94013e0 	ldr	x0, [sp, #32]
    52d4:	97fffd63 	bl	4860 <fwp_drop0>
    52d8:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    52dc:	f947f400 	ldr	x0, [x0, #4072]
    52e0:	f94057e2 	ldr	x2, [sp, #168]
    52e4:	f9400001 	ldr	x1, [x0]
    52e8:	eb010042 	subs	x2, x2, x1
    52ec:	d2800001 	mov	x1, #0x0                   	// #0
    52f0:	54001101 	b.ne	5510 <fwp_loop_fields68.constprop.0+0xadc>  // b.any
    52f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    52f8:	aa1303e0 	mov	x0, x19
    52fc:	a94c53f3 	ldp	x19, x20, [sp, #192]
    5300:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    5304:	a94e63f7 	ldp	x23, x24, [sp, #224]
    5308:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    530c:	a95073fb 	ldp	x27, x28, [sp, #256]
    5310:	6d5127e8 	ldp	d8, d9, [sp, #272]
    5314:	fd4093ea 	ldr	d10, [sp, #288]
    5318:	9104c3ff 	add	sp, sp, #0x130
    531c:	d65f03c0 	ret
    5320:	aa1b03e0 	mov	x0, x27
    5324:	97fff68b 	bl	2d50 <fwp_rc_forget_slot>
    5328:	17fffe42 	b	4c30 <fwp_loop_fields68.constprop.0+0x1fc>
    532c:	72003c3f 	tst	w1, #0xffff
    5330:	54ffc821 	b.ne	4c34 <fwp_loop_fields68.constprop.0+0x200>  // b.any
    5334:	17fffe3c 	b	4c24 <fwp_loop_fields68.constprop.0+0x1f0>
    5338:	aa1a03e0 	mov	x0, x26
    533c:	97fff685 	bl	2d50 <fwp_rc_forget_slot>
    5340:	17fffefd 	b	4f34 <fwp_loop_fields68.constprop.0+0x500>
    5344:	72003c3f 	tst	w1, #0xffff
    5348:	54ffdf81 	b.ne	4f38 <fwp_loop_fields68.constprop.0+0x504>  // b.any
    534c:	17fffef7 	b	4f28 <fwp_loop_fields68.constprop.0+0x4f4>
    5350:	b4ffc800 	cbz	x0, 4c50 <fwp_loop_fields68.constprop.0+0x21c>
    5354:	17fffe3d 	b	4c48 <fwp_loop_fields68.constprop.0+0x214>
    5358:	72003c3f 	tst	w1, #0xffff
    535c:	54ffec61 	b.ne	50e8 <fwp_loop_fields68.constprop.0+0x6b4>  // b.any
    5360:	17ffff59 	b	50c4 <fwp_loop_fields68.constprop.0+0x690>
    5364:	97fff634 	bl	2c34 <fwp_rc_wide_dup>
    5368:	17ffff18 	b	4fc8 <fwp_loop_fields68.constprop.0+0x594>
    536c:	97fff632 	bl	2c34 <fwp_rc_wide_dup>
    5370:	17fffe7f 	b	4d6c <fwp_loop_fields68.constprop.0+0x338>
    5374:	72003c3f 	tst	w1, #0xffff
    5378:	54ffcc21 	b.ne	4cfc <fwp_loop_fields68.constprop.0+0x2c8>  // b.any
    537c:	39400260 	ldrb	w0, [x19]
    5380:	7103fc1f 	cmp	w0, #0xff
    5384:	54ffcb81 	b.ne	4cf4 <fwp_loop_fields68.constprop.0+0x2c0>  // b.any
    5388:	aa1303e0 	mov	x0, x19
    538c:	97fff671 	bl	2d50 <fwp_rc_forget_slot>
    5390:	17fffe59 	b	4cf4 <fwp_loop_fields68.constprop.0+0x2c0>
    5394:	72003c3f 	tst	w1, #0xffff
    5398:	54ffbb81 	b.ne	4b08 <fwp_loop_fields68.constprop.0+0xd4>  // b.any
    539c:	17fffdd5 	b	4af0 <fwp_loop_fields68.constprop.0+0xbc>
    53a0:	72003c3f 	tst	w1, #0xffff
    53a4:	54ffd761 	b.ne	4e90 <fwp_loop_fields68.constprop.0+0x45c>  // b.any
    53a8:	17fffeb4 	b	4e78 <fwp_loop_fields68.constprop.0+0x444>
    53ac:	72003c3f 	tst	w1, #0xffff
    53b0:	54ffee21 	b.ne	5174 <fwp_loop_fields68.constprop.0+0x740>  // b.any
    53b4:	17ffff6b 	b	5160 <fwp_loop_fields68.constprop.0+0x72c>
    53b8:	f9400bf4 	ldr	x20, [sp, #16]
    53bc:	f9400680 	ldr	x0, [x20, #8]
    53c0:	97fffb88 	bl	41e0 <fwp_drop4>
    53c4:	911342a4 	add	x4, x21, #0x4d0
    53c8:	aa1403e0 	mov	x0, x20
    53cc:	f9400a94 	ldr	x20, [x20, #16]
    53d0:	f949ec83 	ldr	x3, [x4, #5080]
    53d4:	f949d881 	ldr	x1, [x4, #5040]
    53d8:	d370bc63 	lsl	x3, x3, #16
    53dc:	cb010002 	sub	x2, x0, x1
    53e0:	eb03005f 	cmp	x2, x3
    53e4:	540003a2 	b.cs	5458 <fwp_loop_fields68.constprop.0+0xa24>  // b.hs, b.nlast
    53e8:	d350fc40 	lsr	x0, x2, #16
    53ec:	f949fc86 	ldr	x6, [x4, #5112]
    53f0:	8b000800 	add	x0, x0, x0, lsl #2
    53f4:	d37df000 	lsl	x0, x0, #3
    53f8:	8b0000c5 	add	x5, x6, x0
    53fc:	f94010a4 	ldr	x4, [x5, #32]
    5400:	b40002c4 	cbz	x4, 5458 <fwp_loop_fields68.constprop.0+0xa24>
    5404:	386068c0 	ldrb	w0, [x6, x0]
    5408:	7100081f 	cmp	w0, #0x2
    540c:	540003e0 	b.eq	5488 <fwp_loop_fields68.constprop.0+0xa54>  // b.none
    5410:	7100041f 	cmp	w0, #0x1
    5414:	54000221 	b.ne	5458 <fwp_loop_fields68.constprop.0+0xa24>  // b.any
    5418:	92403c40 	and	x0, x2, #0xffff
    541c:	294308a6 	ldp	w6, w2, [x5, #24]
    5420:	9b067c00 	mul	x0, x0, x6
    5424:	d360fc00 	lsr	x0, x0, #32
    5428:	eb02001f 	cmp	x0, x2
    542c:	54000162 	b.cs	5458 <fwp_loop_fields68.constprop.0+0xa24>  // b.hs, b.nlast
    5430:	8b000084 	add	x4, x4, x0
    5434:	39400080 	ldrb	w0, [x4]
    5438:	7100041f 	cmp	w0, #0x1
    543c:	540000e1 	b.ne	5458 <fwp_loop_fields68.constprop.0+0xa24>  // b.any
    5440:	f9400be0 	ldr	x0, [sp, #16]
    5444:	97fff6e3 	bl	2fd0 <fwp_mem_free>
    5448:	911342a0 	add	x0, x21, #0x4d0
    544c:	f949ec03 	ldr	x3, [x0, #5080]
    5450:	f949d801 	ldr	x1, [x0, #5040]
    5454:	d370bc63 	lsl	x3, x3, #16
    5458:	cb010281 	sub	x1, x20, x1
    545c:	eb01007f 	cmp	x3, x1
    5460:	54ffe449 	b.ls	50e8 <fwp_loop_fields68.constprop.0+0x6b4>  // b.plast
    5464:	f9000bf4 	str	x20, [sp, #16]
    5468:	17ffff04 	b	5078 <fwp_loop_fields68.constprop.0+0x644>
    546c:	b4ffeb80 	cbz	x0, 51dc <fwp_loop_fields68.constprop.0+0x7a8>
    5470:	17ffff5a 	b	51d8 <fwp_loop_fields68.constprop.0+0x7a4>
    5474:	b4fff240 	cbz	x0, 52bc <fwp_loop_fields68.constprop.0+0x888>
    5478:	17ffff90 	b	52b8 <fwp_loop_fields68.constprop.0+0x884>
    547c:	aa1403e0 	mov	x0, x20
    5480:	97fff634 	bl	2d50 <fwp_rc_forget_slot>
    5484:	17ffff3a 	b	516c <fwp_loop_fields68.constprop.0+0x738>
    5488:	72003c5f 	tst	w2, #0xffff
    548c:	54fffe61 	b.ne	5458 <fwp_loop_fields68.constprop.0+0xa24>  // b.any
    5490:	17ffffe9 	b	5434 <fwp_loop_fields68.constprop.0+0xa00>
    5494:	ca544680 	eor	x0, x20, x20, lsr #17
    5498:	911342a1 	add	x1, x21, #0x4d0
    549c:	ca402400 	eor	x0, x0, x0, lsr #9
    54a0:	8b200c20 	add	x0, x1, w0, uxtb #3
    54a4:	f94a2400 	ldr	x0, [x0, #5192]
    54a8:	b5000080 	cbnz	x0, 54b8 <fwp_loop_fields68.constprop.0+0xa84>
    54ac:	14000016 	b	5504 <fwp_loop_fields68.constprop.0+0xad0>
    54b0:	f9400800 	ldr	x0, [x0, #16]
    54b4:	b4000280 	cbz	x0, 5504 <fwp_loop_fields68.constprop.0+0xad0>
    54b8:	f9400001 	ldr	x1, [x0]
    54bc:	eb01029f 	cmp	x20, x1
    54c0:	54ffff81 	b.ne	54b0 <fwp_loop_fields68.constprop.0+0xa7c>  // b.any
    54c4:	f9400401 	ldr	x1, [x0, #8]
    54c8:	d1000421 	sub	x1, x1, #0x1
    54cc:	f9000401 	str	x1, [x0, #8]
    54d0:	f103f83f 	cmp	x1, #0xfe
    54d4:	54ffe0a1 	b.ne	50e8 <fwp_loop_fields68.constprop.0+0x6b4>  // b.any
    54d8:	aa1403e0 	mov	x0, x20
    54dc:	97fff61d 	bl	2d50 <fwp_rc_forget_slot>
    54e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    54e4:	39000280 	strb	w0, [x20]
    54e8:	17ffff00 	b	50e8 <fwp_loop_fields68.constprop.0+0x6b4>
    54ec:	97fff5d2 	bl	2c34 <fwp_rc_wide_dup>
    54f0:	17fffe68 	b	4e90 <fwp_loop_fields68.constprop.0+0x45c>
    54f4:	97fff5d0 	bl	2c34 <fwp_rc_wide_dup>
    54f8:	17fffd84 	b	4b08 <fwp_loop_fields68.constprop.0+0xd4>
    54fc:	f9000bff 	str	xzr, [sp, #16]
    5500:	17fffd61 	b	4a84 <fwp_loop_fields68.constprop.0+0x50>
    5504:	d0000000 	adrp	x0, 7000 <fwp_main_thread+0x920>
    5508:	912e0000 	add	x0, x0, #0xb80
    550c:	97fff305 	bl	2120 <fwp_trap>
    5510:	97ffeff8 	bl	14f0 <__stack_chk_fail@plt>

0000000000005514 <fwp_drop6>:
    5514:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5518:	910003fd 	mov	x29, sp
    551c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5520:	90000176 	adrp	x22, 31000 <fwp_root_context+0xd10>
    5524:	911342d5 	add	x21, x22, #0x4d0
    5528:	a90153f3 	stp	x19, x20, [sp, #16]
    552c:	aa0003f3 	mov	x19, x0
    5530:	f949daa1 	ldr	x1, [x21, #5040]
    5534:	f949eea0 	ldr	x0, [x21, #5080]
    5538:	cb010261 	sub	x1, x19, x1
    553c:	eb00403f 	cmp	x1, x0, lsl #16
    5540:	54000382 	b.cs	55b0 <fwp_drop6+0x9c>  // b.hs, b.nlast
    5544:	d350fc22 	lsr	x2, x1, #16
    5548:	f949fea3 	ldr	x3, [x21, #5112]
    554c:	8b020842 	add	x2, x2, x2, lsl #2
    5550:	d37df042 	lsl	x2, x2, #3
    5554:	8b020060 	add	x0, x3, x2
    5558:	f9401014 	ldr	x20, [x0, #32]
    555c:	b40002b4 	cbz	x20, 55b0 <fwp_drop6+0x9c>
    5560:	38626862 	ldrb	w2, [x3, x2]
    5564:	7100085f 	cmp	w2, #0x2
    5568:	540002c0 	b.eq	55c0 <fwp_drop6+0xac>  // b.none
    556c:	7100045f 	cmp	w2, #0x1
    5570:	54000201 	b.ne	55b0 <fwp_drop6+0x9c>  // b.any
    5574:	29430002 	ldp	w2, w0, [x0, #24]
    5578:	92403c21 	and	x1, x1, #0xffff
    557c:	9b027c21 	mul	x1, x1, x2
    5580:	d360fc21 	lsr	x1, x1, #32
    5584:	eb00003f 	cmp	x1, x0
    5588:	54000142 	b.cs	55b0 <fwp_drop6+0x9c>  // b.hs, b.nlast
    558c:	8b010294 	add	x20, x20, x1
    5590:	39400280 	ldrb	w0, [x20]
    5594:	340000e0 	cbz	w0, 55b0 <fwp_drop6+0x9c>
    5598:	7100041f 	cmp	w0, #0x1
    559c:	540001e0 	b.eq	55d8 <fwp_drop6+0xc4>  // b.none
    55a0:	7103fc1f 	cmp	w0, #0xff
    55a4:	54000760 	b.eq	5690 <fwp_drop6+0x17c>  // b.none
    55a8:	51000400 	sub	w0, w0, #0x1
    55ac:	39000280 	strb	w0, [x20]
    55b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    55b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    55bc:	d65f03c0 	ret
    55c0:	72003c3f 	tst	w1, #0xffff
    55c4:	54fffe60 	b.eq	5590 <fwp_drop6+0x7c>  // b.none
    55c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    55cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    55d4:	d65f03c0 	ret
    55d8:	f9400660 	ldr	x0, [x19, #8]
    55dc:	97fffb01 	bl	41e0 <fwp_drop4>
    55e0:	911342c4 	add	x4, x22, #0x4d0
    55e4:	f9400a74 	ldr	x20, [x19, #16]
    55e8:	f949ec83 	ldr	x3, [x4, #5080]
    55ec:	f949d881 	ldr	x1, [x4, #5040]
    55f0:	d370bc63 	lsl	x3, x3, #16
    55f4:	cb010262 	sub	x2, x19, x1
    55f8:	eb03005f 	cmp	x2, x3
    55fc:	540003a2 	b.cs	5670 <fwp_drop6+0x15c>  // b.hs, b.nlast
    5600:	d350fc40 	lsr	x0, x2, #16
    5604:	f949fc86 	ldr	x6, [x4, #5112]
    5608:	8b000800 	add	x0, x0, x0, lsl #2
    560c:	d37df000 	lsl	x0, x0, #3
    5610:	8b0000c5 	add	x5, x6, x0
    5614:	f94010a4 	ldr	x4, [x5, #32]
    5618:	b40002c4 	cbz	x4, 5670 <fwp_drop6+0x15c>
    561c:	386068c0 	ldrb	w0, [x6, x0]
    5620:	7100081f 	cmp	w0, #0x2
    5624:	54000300 	b.eq	5684 <fwp_drop6+0x170>  // b.none
    5628:	7100041f 	cmp	w0, #0x1
    562c:	54000221 	b.ne	5670 <fwp_drop6+0x15c>  // b.any
    5630:	92403c40 	and	x0, x2, #0xffff
    5634:	294308a6 	ldp	w6, w2, [x5, #24]
    5638:	9b067c00 	mul	x0, x0, x6
    563c:	d360fc00 	lsr	x0, x0, #32
    5640:	eb02001f 	cmp	x0, x2
    5644:	54000162 	b.cs	5670 <fwp_drop6+0x15c>  // b.hs, b.nlast
    5648:	8b000084 	add	x4, x4, x0
    564c:	39400080 	ldrb	w0, [x4]
    5650:	7100041f 	cmp	w0, #0x1
    5654:	540000e1 	b.ne	5670 <fwp_drop6+0x15c>  // b.any
    5658:	aa1303e0 	mov	x0, x19
    565c:	97fff65d 	bl	2fd0 <fwp_mem_free>
    5660:	911342c0 	add	x0, x22, #0x4d0
    5664:	f949ec03 	ldr	x3, [x0, #5080]
    5668:	f949d801 	ldr	x1, [x0, #5040]
    566c:	d370bc63 	lsl	x3, x3, #16
    5670:	cb010281 	sub	x1, x20, x1
    5674:	eb01007f 	cmp	x3, x1
    5678:	54fff9c9 	b.ls	55b0 <fwp_drop6+0x9c>  // b.plast
    567c:	aa1403f3 	mov	x19, x20
    5680:	17ffffb1 	b	5544 <fwp_drop6+0x30>
    5684:	72003c5f 	tst	w2, #0xffff
    5688:	54ffff41 	b.ne	5670 <fwp_drop6+0x15c>  // b.any
    568c:	17fffff0 	b	564c <fwp_drop6+0x138>
    5690:	ca544681 	eor	x1, x20, x20, lsr #17
    5694:	911342c0 	add	x0, x22, #0x4d0
    5698:	ca412421 	eor	x1, x1, x1, lsr #9
    569c:	8b210c01 	add	x1, x0, w1, uxtb #3
    56a0:	f94a2420 	ldr	x0, [x1, #5192]
    56a4:	b5000080 	cbnz	x0, 56b4 <fwp_drop6+0x1a0>
    56a8:	14000010 	b	56e8 <fwp_drop6+0x1d4>
    56ac:	f9400800 	ldr	x0, [x0, #16]
    56b0:	b40001c0 	cbz	x0, 56e8 <fwp_drop6+0x1d4>
    56b4:	f9400001 	ldr	x1, [x0]
    56b8:	eb14003f 	cmp	x1, x20
    56bc:	54ffff81 	b.ne	56ac <fwp_drop6+0x198>  // b.any
    56c0:	f9400401 	ldr	x1, [x0, #8]
    56c4:	d1000421 	sub	x1, x1, #0x1
    56c8:	f9000401 	str	x1, [x0, #8]
    56cc:	f103f83f 	cmp	x1, #0xfe
    56d0:	54fff701 	b.ne	55b0 <fwp_drop6+0x9c>  // b.any
    56d4:	aa1403e0 	mov	x0, x20
    56d8:	97fff59e 	bl	2d50 <fwp_rc_forget_slot>
    56dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    56e0:	39000280 	strb	w0, [x20]
    56e4:	17ffffb3 	b	55b0 <fwp_drop6+0x9c>
    56e8:	d0000000 	adrp	x0, 7000 <fwp_main_thread+0x920>
    56ec:	912e0000 	add	x0, x0, #0xb80
    56f0:	97fff28c 	bl	2120 <fwp_trap>

00000000000056f4 <fwp_write>:
    56f4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    56f8:	910003fd 	mov	x29, sp
    56fc:	d00000c4 	adrp	x4, 1f000 <__FRAME_END__+0x15ff0>
    5700:	f947f484 	ldr	x4, [x4, #4072]
    5704:	a90153f3 	stp	x19, x20, [sp, #16]
    5708:	d10943ff 	sub	sp, sp, #0x250
    570c:	b9400045 	ldr	w5, [x2]
    5710:	aa0003f4 	mov	x20, x0
    5714:	f9400080 	ldr	x0, [x4]
    5718:	f90127e0 	str	x0, [sp, #584]
    571c:	d2800000 	mov	x0, #0x0                   	// #0
    5720:	710064bf 	cmp	w5, #0x19
    5724:	54000408 	b.hi	57a4 <fwp_write+0xb0>  // b.pmore
    5728:	d0000000 	adrp	x0, 7000 <fwp_main_thread+0x920>
    572c:	aa0103f3 	mov	x19, x1
    5730:	91394000 	add	x0, x0, #0xe50
    5734:	f9013bf5 	str	x21, [sp, #624]
    5738:	f9013ff6 	str	x22, [sp, #632]
    573c:	f90153fb 	str	x27, [sp, #672]
    5740:	f90157fc 	str	x28, [sp, #680]
    5744:	aa0203fc 	mov	x28, x2
    5748:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    574c:	10000061 	adr	x1, 5758 <fwp_write+0x64>
    5750:	8b20a820 	add	x0, x1, w0, sxth #2
    5754:	d61f0000 	br	x0
    5758:	910123e0 	add	x0, sp, #0x48
    575c:	aa1303e5 	mov	x5, x19
    5760:	d0000004 	adrp	x4, 7000 <fwp_main_thread+0x920>
    5764:	aa0003f3 	mov	x19, x0
    5768:	91314084 	add	x4, x4, #0xc50
    576c:	d2804003 	mov	x3, #0x200                 	// #512
    5770:	aa0303e1 	mov	x1, x3
    5774:	52800042 	mov	w2, #0x2                   	// #2
    5778:	97ffef3a 	bl	1460 <__snprintf_chk@plt>
    577c:	aa1303e0 	mov	x0, x19
    5780:	97ffef00 	bl	1380 <strlen@plt>
    5784:	aa1303e1 	mov	x1, x19
    5788:	aa0003e2 	mov	x2, x0
    578c:	aa1403e0 	mov	x0, x20
    5790:	97fff208 	bl	1fb0 <buf_put>
    5794:	f9413bf5 	ldr	x21, [sp, #624]
    5798:	f9413ff6 	ldr	x22, [sp, #632]
    579c:	f94153fb 	ldr	x27, [sp, #672]
    57a0:	f94157fc 	ldr	x28, [sp, #680]
    57a4:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    57a8:	f947f400 	ldr	x0, [x0, #4072]
    57ac:	f94127e2 	ldr	x2, [sp, #584]
    57b0:	f9400001 	ldr	x1, [x0]
    57b4:	eb010042 	subs	x2, x2, x1
    57b8:	d2800001 	mov	x1, #0x0                   	// #0
    57bc:	540077a1 	b.ne	66b0 <fwp_write+0xfbc>  // b.any
    57c0:	910943ff 	add	sp, sp, #0x250
    57c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    57c8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    57cc:	d65f03c0 	ret
    57d0:	910123e0 	add	x0, sp, #0x48
    57d4:	aa1303e5 	mov	x5, x19
    57d8:	d0000004 	adrp	x4, 7000 <fwp_main_thread+0x920>
    57dc:	aa0003f3 	mov	x19, x0
    57e0:	91312084 	add	x4, x4, #0xc48
    57e4:	d2804003 	mov	x3, #0x200                 	// #512
    57e8:	17ffffe2 	b	5770 <fwp_write+0x7c>
    57ec:	71004cbf 	cmp	w5, #0x13
    57f0:	d0000000 	adrp	x0, 7000 <fwp_main_thread+0x920>
    57f4:	d0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    57f8:	9130e000 	add	x0, x0, #0xc38
    57fc:	91310021 	add	x1, x1, #0xc40
    5800:	d2800082 	mov	x2, #0x4                   	// #4
    5804:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    5808:	aa1403e0 	mov	x0, x20
    580c:	f90143f7 	str	x23, [sp, #640]
    5810:	d2800016 	mov	x22, #0x0                   	// #0
    5814:	f90147f8 	str	x24, [sp, #648]
    5818:	97fff1e6 	bl	1fb0 <buf_put>
    581c:	f9400260 	ldr	x0, [x19]
    5820:	d0000017 	adrp	x23, 7000 <fwp_main_thread+0x920>
    5824:	d2800015 	mov	x21, #0x0                   	// #0
    5828:	913302f7 	add	x23, x23, #0xcc0
    582c:	b4004780 	cbz	x0, 611c <fwp_write+0xa28>
    5830:	b9400380 	ldr	w0, [x28]
    5834:	52800003 	mov	w3, #0x0                   	// #0
    5838:	f9401f82 	ldr	x2, [x28, #56]
    583c:	71004c1f 	cmp	w0, #0x13
    5840:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    5844:	aa1403e0 	mov	x0, x20
    5848:	8b010e61 	add	x1, x19, x1, lsl #3
    584c:	f9400421 	ldr	x1, [x1, #8]
    5850:	97ffffa9 	bl	56f4 <fwp_write>
    5854:	b9400380 	ldr	w0, [x28]
    5858:	7100481f 	cmp	w0, #0x12
    585c:	54004b20 	b.eq	61c0 <fwp_write+0xacc>  // b.none
    5860:	f9400260 	ldr	x0, [x19]
    5864:	910006b5 	add	x21, x21, #0x1
    5868:	91000ad6 	add	x22, x22, #0x2
    586c:	eb15001f 	cmp	x0, x21
    5870:	54004569 	b.ls	611c <fwp_write+0xa28>  // b.plast
    5874:	aa1703e1 	mov	x1, x23
    5878:	aa1403e0 	mov	x0, x20
    587c:	d2800042 	mov	x2, #0x2                   	// #2
    5880:	97fff1cc 	bl	1fb0 <buf_put>
    5884:	17ffffeb 	b	5830 <fwp_write+0x13c>
    5888:	d0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    588c:	9131e021 	add	x1, x1, #0xc78
    5890:	d28000c2 	mov	x2, #0x6                   	// #6
    5894:	aa1403e0 	mov	x0, x20
    5898:	91004273 	add	x19, x19, #0x10
    589c:	97fff1c5 	bl	1fb0 <buf_put>
    58a0:	aa1303e0 	mov	x0, x19
    58a4:	97ffeeb7 	bl	1380 <strlen@plt>
    58a8:	aa1303e1 	mov	x1, x19
    58ac:	aa0003e2 	mov	x2, x0
    58b0:	aa1403e0 	mov	x0, x20
    58b4:	97fff1bf 	bl	1fb0 <buf_put>
    58b8:	528007c3 	mov	w3, #0x3e                  	// #62
    58bc:	aa1403e0 	mov	x0, x20
    58c0:	91001fe1 	add	x1, sp, #0x7
    58c4:	d2800022 	mov	x2, #0x1                   	// #1
    58c8:	39001fe3 	strb	w3, [sp, #7]
    58cc:	17ffffb1 	b	5790 <fwp_write+0x9c>
    58d0:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    58d4:	f947f400 	ldr	x0, [x0, #4072]
    58d8:	f94127e2 	ldr	x2, [sp, #584]
    58dc:	f9400001 	ldr	x1, [x0]
    58e0:	eb010042 	subs	x2, x2, x1
    58e4:	d2800001 	mov	x1, #0x0                   	// #0
    58e8:	540034c1 	b.ne	5f80 <fwp_write+0x88c>  // b.any
    58ec:	f9413bf5 	ldr	x21, [sp, #624]
    58f0:	d0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    58f4:	f9413ff6 	ldr	x22, [sp, #632]
    58f8:	aa1403e0 	mov	x0, x20
    58fc:	91316021 	add	x1, x1, #0xc58
    5900:	d2800142 	mov	x2, #0xa                   	// #10
    5904:	f94153fb 	ldr	x27, [sp, #672]
    5908:	f94157fc 	ldr	x28, [sp, #680]
    590c:	910943ff 	add	sp, sp, #0x250
    5910:	a94153f3 	ldp	x19, x20, [sp, #16]
    5914:	a8c77bfd 	ldp	x29, x30, [sp], #112
    5918:	17fff1a6 	b	1fb0 <buf_put>
    591c:	f9400456 	ldr	x22, [x2, #8]
    5920:	f90143f7 	str	x23, [sp, #640]
    5924:	f90147f8 	str	x24, [sp, #648]
    5928:	b4005af6 	cbz	x22, 6484 <fwp_write+0xd90>
    592c:	aa1603e0 	mov	x0, x22
    5930:	d0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    5934:	91336021 	add	x1, x1, #0xcd8
    5938:	97ffef0e 	bl	1570 <strcmp@plt>
    593c:	2a0003f5 	mov	w21, w0
    5940:	34005fc0 	cbz	w0, 6538 <fwp_write+0xe44>
    5944:	aa1603e0 	mov	x0, x22
    5948:	97ffee8e 	bl	1380 <strlen@plt>
    594c:	aa1603e1 	mov	x1, x22
    5950:	aa0003e2 	mov	x2, x0
    5954:	aa1403e0 	mov	x0, x20
    5958:	97fff196 	bl	1fb0 <buf_put>
    595c:	52800403 	mov	w3, #0x20                  	// #32
    5960:	91001ff5 	add	x21, sp, #0x7
    5964:	aa1503e1 	mov	x1, x21
    5968:	aa1403e0 	mov	x0, x20
    596c:	d2800022 	mov	x2, #0x1                   	// #1
    5970:	39001fe3 	strb	w3, [sp, #7]
    5974:	97fff18f 	bl	1fb0 <buf_put>
    5978:	52800f63 	mov	w3, #0x7b                  	// #123
    597c:	aa1403e0 	mov	x0, x20
    5980:	aa1503e1 	mov	x1, x21
    5984:	d2800022 	mov	x2, #0x1                   	// #1
    5988:	39001fe3 	strb	w3, [sp, #7]
    598c:	97fff189 	bl	1fb0 <buf_put>
    5990:	b9401380 	ldr	w0, [x28, #16]
    5994:	52800018 	mov	w24, #0x0                   	// #0
    5998:	7100001f 	cmp	w0, #0x0
    599c:	54003a8d 	b.le	60ec <fwp_write+0x9f8>
    59a0:	f9014bf9 	str	x25, [sp, #656]
    59a4:	d0000019 	adrp	x25, 7000 <fwp_main_thread+0x920>
    59a8:	91340339 	add	x25, x25, #0xd00
    59ac:	f9014ffa 	str	x26, [sp, #664]
    59b0:	d000001a 	adrp	x26, 7000 <fwp_main_thread+0x920>
    59b4:	9133035a 	add	x26, x26, #0xcc0
    59b8:	91002276 	add	x22, x19, #0x8
    59bc:	d2800013 	mov	x19, #0x0                   	// #0
    59c0:	b5003e73 	cbnz	x19, 618c <fwp_write+0xa98>
    59c4:	d37df277 	lsl	x23, x19, #3
    59c8:	34003c98 	cbz	w24, 6158 <fwp_write+0xa64>
    59cc:	f9401382 	ldr	x2, [x28, #32]
    59d0:	aa1403e0 	mov	x0, x20
    59d4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    59d8:	52800003 	mov	w3, #0x0                   	// #0
    59dc:	f8776842 	ldr	x2, [x2, x23]
    59e0:	91000673 	add	x19, x19, #0x1
    59e4:	97ffff44 	bl	56f4 <fwp_write>
    59e8:	b9401380 	ldr	w0, [x28, #16]
    59ec:	6b13001f 	cmp	w0, w19
    59f0:	54fffe8c 	b.gt	59c0 <fwp_write+0x2cc>
    59f4:	f9414bf9 	ldr	x25, [sp, #656]
    59f8:	f9414ffa 	ldr	x26, [sp, #664]
    59fc:	34003798 	cbz	w24, 60ec <fwp_write+0x9f8>
    5a00:	52800523 	mov	w3, #0x29                  	// #41
    5a04:	aa1503e1 	mov	x1, x21
    5a08:	aa1403e0 	mov	x0, x20
    5a0c:	d2800022 	mov	x2, #0x1                   	// #1
    5a10:	39001fe3 	strb	w3, [sp, #7]
    5a14:	97fff167 	bl	1fb0 <buf_put>
    5a18:	f9413bf5 	ldr	x21, [sp, #624]
    5a1c:	f9413ff6 	ldr	x22, [sp, #632]
    5a20:	f94143f7 	ldr	x23, [sp, #640]
    5a24:	f94147f8 	ldr	x24, [sp, #648]
    5a28:	f94153fb 	ldr	x27, [sp, #672]
    5a2c:	f94157fc 	ldr	x28, [sp, #680]
    5a30:	17ffff5d 	b	57a4 <fwp_write+0xb0>
    5a34:	b9404855 	ldr	w21, [x2, #72]
    5a38:	aa1403e0 	mov	x0, x20
    5a3c:	93407eb6 	sxtw	x22, w21
    5a40:	91000ac1 	add	x1, x22, #0x2
    5a44:	97fff127 	bl	1ee0 <buf_grow>
    5a48:	a9400281 	ldp	x1, x0, [x20]
    5a4c:	528e8603 	mov	w3, #0x7430                	// #29744
    5a50:	78206823 	strh	w3, [x1, x0]
    5a54:	8b000022 	add	x2, x1, x0
    5a58:	710002bf 	cmp	w21, #0x0
    5a5c:	540036ad 	b.le	6130 <fwp_write+0xa3c>
    5a60:	110006a3 	add	w3, w21, #0x1
    5a64:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    5a68:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    5a6c:	91000449 	add	x9, x2, #0x1
    5a70:	8b23c043 	add	x3, x2, w3, sxtw
    5a74:	f28aaac6 	movk	x6, #0x5556
    5a78:	f2955568 	movk	x8, #0xaaab
    5a7c:	1400000d 	b	5ab0 <fwp_write+0x3bc>
    5a80:	d2800021 	mov	x1, #0x1                   	// #1
    5a84:	528005a5 	mov	w5, #0x2d                  	// #45
    5a88:	f100001f 	cmp	x0, #0x0
    5a8c:	9b467e60 	smulh	x0, x19, x6
    5a90:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    5a94:	381ff465 	strb	w5, [x3], #-1
    5a98:	cb040000 	sub	x0, x0, x4
    5a9c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    5aa0:	cb020000 	sub	x0, x0, x2
    5aa4:	8b010013 	add	x19, x0, x1
    5aa8:	eb03013f 	cmp	x9, x3
    5aac:	54003420 	b.eq	6130 <fwp_write+0xa3c>  // b.none
    5ab0:	9b467e60 	smulh	x0, x19, x6
    5ab4:	937ffe64 	asr	x4, x19, #63
    5ab8:	52800605 	mov	w5, #0x30                  	// #48
    5abc:	cb040000 	sub	x0, x0, x4
    5ac0:	8b000400 	add	x0, x0, x0, lsl #1
    5ac4:	cb000260 	sub	x0, x19, x0
    5ac8:	91000c01 	add	x1, x0, #0x3
    5acc:	9bc87c22 	umulh	x2, x1, x8
    5ad0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    5ad4:	8b4204e2 	add	x2, x7, x2, lsr #1
    5ad8:	eb020021 	subs	x1, x1, x2
    5adc:	54fffd60 	b.eq	5a88 <fwp_write+0x394>  // b.none
    5ae0:	f100043f 	cmp	x1, #0x1
    5ae4:	54fffce1 	b.ne	5a80 <fwp_write+0x38c>  // b.any
    5ae8:	d2800001 	mov	x1, #0x0                   	// #0
    5aec:	52800565 	mov	w5, #0x2b                  	// #43
    5af0:	17ffffe6 	b	5a88 <fwp_write+0x394>
    5af4:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    5af8:	f947f400 	ldr	x0, [x0, #4072]
    5afc:	f94127e2 	ldr	x2, [sp, #584]
    5b00:	f9400001 	ldr	x1, [x0]
    5b04:	eb010042 	subs	x2, x2, x1
    5b08:	d2800001 	mov	x1, #0x0                   	// #0
    5b0c:	540023a1 	b.ne	5f80 <fwp_write+0x88c>  // b.any
    5b10:	f9413bf5 	ldr	x21, [sp, #624]
    5b14:	d0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    5b18:	f9413ff6 	ldr	x22, [sp, #632]
    5b1c:	aa1403e0 	mov	x0, x20
    5b20:	9131a021 	add	x1, x1, #0xc68
    5b24:	d2800102 	mov	x2, #0x8                   	// #8
    5b28:	17ffff77 	b	5904 <fwp_write+0x210>
    5b2c:	aa1403e0 	mov	x0, x20
    5b30:	d0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    5b34:	d28000c2 	mov	x2, #0x6                   	// #6
    5b38:	91332021 	add	x1, x1, #0xcc8
    5b3c:	97fff11d 	bl	1fb0 <buf_put>
    5b40:	d2800015 	mov	x21, #0x0                   	// #0
    5b44:	f9400263 	ldr	x3, [x19]
    5b48:	f240f87f 	tst	x3, #0x7fffffffffffffff
    5b4c:	54002c40 	b.eq	60d4 <fwp_write+0x9e0>  // b.none
    5b50:	f9401f82 	ldr	x2, [x28, #56]
    5b54:	f90143f7 	str	x23, [sp, #640]
    5b58:	f90147f8 	str	x24, [sp, #648]
    5b5c:	d2800857 	mov	x23, #0x42                  	// #66
    5b60:	f9014bf9 	str	x25, [sp, #656]
    5b64:	d0000016 	adrp	x22, 7000 <fwp_main_thread+0x920>
    5b68:	f9014ffa 	str	x26, [sp, #664]
    5b6c:	913302d6 	add	x22, x22, #0xcc0
    5b70:	d2800038 	mov	x24, #0x1                   	// #1
    5b74:	f2a18017 	movk	x23, #0xc00, lsl #16
    5b78:	d2809099 	mov	x25, #0x484                 	// #1156
    5b7c:	b4000482 	cbz	x2, 5c0c <fwp_write+0x518>
    5b80:	b9400040 	ldr	w0, [x2]
    5b84:	7100701f 	cmp	w0, #0x1c
    5b88:	540042a0 	b.eq	63dc <fwp_write+0xce8>  // b.none
    5b8c:	71006c1f 	cmp	w0, #0x1b
    5b90:	540003e8 	b.hi	5c0c <fwp_write+0x518>  // b.pmore
    5b94:	9ac02301 	lsl	x1, x24, x0
    5b98:	ea17003f 	tst	x1, x23
    5b9c:	54003681 	b.ne	626c <fwp_write+0xb78>  // b.any
    5ba0:	ea19003f 	tst	x1, x25
    5ba4:	54003501 	b.ne	6244 <fwp_write+0xb50>  // b.any
    5ba8:	d2800424 	mov	x4, #0x21                  	// #33
    5bac:	ea04003f 	tst	x1, x4
    5bb0:	540002e0 	b.eq	5c0c <fwp_write+0x518>  // b.none
    5bb4:	b7f849a3 	tbnz	x3, #63, 64e8 <fwp_write+0xdf4>
    5bb8:	91002261 	add	x1, x19, #0x8
    5bbc:	8b150021 	add	x1, x1, x21
    5bc0:	39400021 	ldrb	w1, [x1]
    5bc4:	7100001f 	cmp	w0, #0x0
    5bc8:	93401c23 	sxtb	x3, w1
    5bcc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    5bd0:	aa1403e0 	mov	x0, x20
    5bd4:	52800003 	mov	w3, #0x0                   	// #0
    5bd8:	97fffec7 	bl	56f4 <fwp_write>
    5bdc:	910006b5 	add	x21, x21, #0x1
    5be0:	f9400260 	ldr	x0, [x19]
    5be4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    5be8:	eb0002bf 	cmp	x21, x0
    5bec:	540026c2 	b.cs	60c4 <fwp_write+0x9d0>  // b.hs, b.nlast
    5bf0:	d2800042 	mov	x2, #0x2                   	// #2
    5bf4:	aa1603e1 	mov	x1, x22
    5bf8:	aa1403e0 	mov	x0, x20
    5bfc:	97fff0ed 	bl	1fb0 <buf_put>
    5c00:	f9401f82 	ldr	x2, [x28, #56]
    5c04:	f9400263 	ldr	x3, [x19]
    5c08:	b5fffbc2 	cbnz	x2, 5b80 <fwp_write+0x48c>
    5c0c:	d37df2a0 	lsl	x0, x21, #3
    5c10:	b7f83f03 	tbnz	x3, #63, 63f0 <fwp_write+0xcfc>
    5c14:	91002261 	add	x1, x19, #0x8
    5c18:	8b000020 	add	x0, x1, x0
    5c1c:	f9400001 	ldr	x1, [x0]
    5c20:	17ffffec 	b	5bd0 <fwp_write+0x4dc>
    5c24:	a9400e62 	ldp	x2, x3, [x19]
    5c28:	b7f83ca3 	tbnz	x3, #63, 63bc <fwp_write+0xcc8>
    5c2c:	910123f5 	add	x21, sp, #0x48
    5c30:	aa1503e0 	mov	x0, x21
    5c34:	97ffef7b 	bl	1a20 <fwp_fmt_u128>
    5c38:	aa1503e0 	mov	x0, x21
    5c3c:	97ffedd1 	bl	1380 <strlen@plt>
    5c40:	aa1503e1 	mov	x1, x21
    5c44:	aa0003e2 	mov	x2, x0
    5c48:	17fffed1 	b	578c <fwp_write+0x98>
    5c4c:	fd015be8 	str	d8, [sp, #688]
    5c50:	1e270268 	fmov	s8, w19
    5c54:	fd015fe9 	str	d9, [sp, #696]
    5c58:	1e282100 	fcmp	s8, s8
    5c5c:	54004d26 	b.vs	6600 <fwp_write+0xf0c>
    5c60:	1e20c101 	fabs	s1, s8
    5c64:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    5c68:	1e270000 	fmov	s0, w0
    5c6c:	1e202020 	fcmp	s1, s0
    5c70:	54002c0d 	b.le	61f0 <fwp_write+0xafc>
    5c74:	1e202118 	fcmpe	s8, #0.0
    5c78:	d0000002 	adrp	x2, 7000 <fwp_main_thread+0x920>
    5c7c:	9126c042 	add	x2, x2, #0x9b0
    5c80:	910123f5 	add	x21, sp, #0x48
    5c84:	d0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    5c88:	91306021 	add	x1, x1, #0xc18
    5c8c:	aa1503e0 	mov	x0, x21
    5c90:	9a81c041 	csel	x1, x2, x1, gt
    5c94:	97ffee67 	bl	1630 <strcpy@plt>
    5c98:	aa1503e0 	mov	x0, x21
    5c9c:	97ffedb9 	bl	1380 <strlen@plt>
    5ca0:	aa1503e1 	mov	x1, x21
    5ca4:	aa0003e2 	mov	x2, x0
    5ca8:	aa1403e0 	mov	x0, x20
    5cac:	97fff0c1 	bl	1fb0 <buf_put>
    5cb0:	f9413bf5 	ldr	x21, [sp, #624]
    5cb4:	f9413ff6 	ldr	x22, [sp, #632]
    5cb8:	f94153fb 	ldr	x27, [sp, #672]
    5cbc:	f94157fc 	ldr	x28, [sp, #680]
    5cc0:	fd415be8 	ldr	d8, [sp, #688]
    5cc4:	fd415fe9 	ldr	d9, [sp, #696]
    5cc8:	17fffeb7 	b	57a4 <fwp_write+0xb0>
    5ccc:	f9400276 	ldr	x22, [x19]
    5cd0:	34002e03 	cbz	w3, 6290 <fwp_write+0xb9c>
    5cd4:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    5cd8:	f947f400 	ldr	x0, [x0, #4072]
    5cdc:	f94127e2 	ldr	x2, [sp, #584]
    5ce0:	f9400001 	ldr	x1, [x0]
    5ce4:	eb010042 	subs	x2, x2, x1
    5ce8:	d2800001 	mov	x1, #0x0                   	// #0
    5cec:	540014a1 	b.ne	5f80 <fwp_write+0x88c>  // b.any
    5cf0:	aa1603e2 	mov	x2, x22
    5cf4:	91002261 	add	x1, x19, #0x8
    5cf8:	f9413bf5 	ldr	x21, [sp, #624]
    5cfc:	aa1403e0 	mov	x0, x20
    5d00:	f9413ff6 	ldr	x22, [sp, #632]
    5d04:	17ffff00 	b	5904 <fwp_write+0x210>
    5d08:	fd015be8 	str	d8, [sp, #688]
    5d0c:	9e670268 	fmov	d8, x19
    5d10:	fd015fe9 	str	d9, [sp, #696]
    5d14:	1e682100 	fcmp	d8, d8
    5d18:	54004746 	b.vs	6600 <fwp_write+0xf0c>
    5d1c:	1e60c101 	fabs	d1, d8
    5d20:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    5d24:	9e670000 	fmov	d0, x0
    5d28:	910123f5 	add	x21, sp, #0x48
    5d2c:	52800033 	mov	w19, #0x1                   	// #1
    5d30:	1e602020 	fcmp	d1, d0
    5d34:	540001ad 	b.le	5d68 <fwp_write+0x674>
    5d38:	1e602118 	fcmpe	d8, #0.0
    5d3c:	d0000002 	adrp	x2, 7000 <fwp_main_thread+0x920>
    5d40:	9126c042 	add	x2, x2, #0x9b0
    5d44:	d0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    5d48:	91306021 	add	x1, x1, #0xc18
    5d4c:	aa1503e0 	mov	x0, x21
    5d50:	9a81c041 	csel	x1, x2, x1, gt
    5d54:	97ffee37 	bl	1630 <strcpy@plt>
    5d58:	17ffffd0 	b	5c98 <fwp_write+0x5a4>
    5d5c:	11000673 	add	w19, w19, #0x1
    5d60:	71004a7f 	cmp	w19, #0x12
    5d64:	54003860 	b.eq	6470 <fwp_write+0xd7c>  // b.none
    5d68:	1e604100 	fmov	d0, d8
    5d6c:	2a1303e1 	mov	w1, w19
    5d70:	aa1503e0 	mov	x0, x21
    5d74:	97fff124 	bl	2204 <fwp_format_g.constprop.0>
    5d78:	aa1503e0 	mov	x0, x21
    5d7c:	d2800001 	mov	x1, #0x0                   	// #0
    5d80:	97ffed94 	bl	13d0 <strtod@plt>
    5d84:	1e602100 	fcmp	d8, d0
    5d88:	54fffea1 	b.ne	5d5c <fwp_write+0x668>  // b.any
    5d8c:	aa1503e0 	mov	x0, x21
    5d90:	97fff0c1 	bl	2094 <fwp_finish_float>
    5d94:	17ffffc1 	b	5c98 <fwp_write+0x5a4>
    5d98:	a9400e62 	ldp	x2, x3, [x19]
    5d9c:	910123f3 	add	x19, sp, #0x48
    5da0:	aa1303e0 	mov	x0, x19
    5da4:	97ffef1f 	bl	1a20 <fwp_fmt_u128>
    5da8:	17fffe75 	b	577c <fwp_write+0x88>
    5dac:	f90143f7 	str	x23, [sp, #640]
    5db0:	f90147f8 	str	x24, [sp, #648]
    5db4:	2a1303f8 	mov	w24, w19
    5db8:	f9014bf9 	str	x25, [sp, #656]
    5dbc:	f9014ffa 	str	x26, [sp, #664]
    5dc0:	f13ffe7f 	cmp	x19, #0xfff
    5dc4:	54000049 	b.ls	5dcc <fwp_write+0x6d8>  // b.plast
    5dc8:	b9400278 	ldr	w24, [x19]
    5dcc:	f9400f80 	ldr	x0, [x28, #24]
    5dd0:	2a1803f5 	mov	w21, w24
    5dd4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    5dd8:	d37ef6b9 	lsl	x25, x21, #2
    5ddc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    5de0:	aa1603e0 	mov	x0, x22
    5de4:	97ffed67 	bl	1380 <strlen@plt>
    5de8:	aa1603e1 	mov	x1, x22
    5dec:	aa0003e2 	mov	x2, x0
    5df0:	aa1403e0 	mov	x0, x20
    5df4:	97fff06f 	bl	1fb0 <buf_put>
    5df8:	f9401780 	ldr	x0, [x28, #40]
    5dfc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    5e00:	7100001f 	cmp	w0, #0x0
    5e04:	5400068d 	b.le	5ed4 <fwp_write+0x7e0>
    5e08:	91002276 	add	x22, x19, #0x8
    5e0c:	91001ff5 	add	x21, sp, #0x7
    5e10:	d280001b 	mov	x27, #0x0                   	// #0
    5e14:	5280041a 	mov	w26, #0x20                  	// #32
    5e18:	f9401b80 	ldr	x0, [x28, #48]
    5e1c:	aa1503e1 	mov	x1, x21
    5e20:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    5e24:	d2800022 	mov	x2, #0x1                   	// #1
    5e28:	f8786803 	ldr	x3, [x0, x24]
    5e2c:	aa1403e0 	mov	x0, x20
    5e30:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    5e34:	39001ffa 	strb	w26, [sp, #7]
    5e38:	97fff05e 	bl	1fb0 <buf_put>
    5e3c:	f13ffeff 	cmp	x23, #0xfff
    5e40:	b9400261 	ldr	w1, [x19]
    5e44:	1a9f97e0 	cset	w0, hi	// hi = pmore
    5e48:	7100383f 	cmp	w1, #0xe
    5e4c:	54000160 	b.eq	5e78 <fwp_write+0x784>  // b.none
    5e50:	7100403f 	cmp	w1, #0x10
    5e54:	54001a60 	b.eq	61a0 <fwp_write+0xaac>  // b.none
    5e58:	7100283f 	cmp	w1, #0xa
    5e5c:	54002aa0 	b.eq	63b0 <fwp_write+0xcbc>  // b.none
    5e60:	540014ac 	b.gt	60f4 <fwp_write+0xa00>
    5e64:	71000c3f 	cmp	w1, #0x3
    5e68:	540029ac 	b.gt	639c <fwp_write+0xca8>
    5e6c:	d37ffee0 	lsr	x0, x23, #63
    5e70:	37f814a1 	tbnz	w1, #31, 6104 <fwp_write+0xa10>
    5e74:	d503201f 	nop
    5e78:	34001460 	cbz	w0, 6104 <fwp_write+0xa10>
    5e7c:	52800503 	mov	w3, #0x28                  	// #40
    5e80:	aa1503e1 	mov	x1, x21
    5e84:	aa1403e0 	mov	x0, x20
    5e88:	d2800022 	mov	x2, #0x1                   	// #1
    5e8c:	39001fe3 	strb	w3, [sp, #7]
    5e90:	97fff048 	bl	1fb0 <buf_put>
    5e94:	aa1303e2 	mov	x2, x19
    5e98:	aa1703e1 	mov	x1, x23
    5e9c:	aa1403e0 	mov	x0, x20
    5ea0:	52800003 	mov	w3, #0x0                   	// #0
    5ea4:	97fffe14 	bl	56f4 <fwp_write>
    5ea8:	52800523 	mov	w3, #0x29                  	// #41
    5eac:	aa1503e1 	mov	x1, x21
    5eb0:	aa1403e0 	mov	x0, x20
    5eb4:	d2800022 	mov	x2, #0x1                   	// #1
    5eb8:	39001fe3 	strb	w3, [sp, #7]
    5ebc:	97fff03d 	bl	1fb0 <buf_put>
    5ec0:	f9401780 	ldr	x0, [x28, #40]
    5ec4:	9100077b 	add	x27, x27, #0x1
    5ec8:	b8796800 	ldr	w0, [x0, x25]
    5ecc:	6b1b001f 	cmp	w0, w27
    5ed0:	54fffa4c 	b.gt	5e18 <fwp_write+0x724>
    5ed4:	f9413bf5 	ldr	x21, [sp, #624]
    5ed8:	f9413ff6 	ldr	x22, [sp, #632]
    5edc:	f94143f7 	ldr	x23, [sp, #640]
    5ee0:	f94147f8 	ldr	x24, [sp, #648]
    5ee4:	f9414bf9 	ldr	x25, [sp, #656]
    5ee8:	f9414ffa 	ldr	x26, [sp, #664]
    5eec:	f94153fb 	ldr	x27, [sp, #672]
    5ef0:	f94157fc 	ldr	x28, [sp, #680]
    5ef4:	17fffe2c 	b	57a4 <fwp_write+0xb0>
    5ef8:	52800783 	mov	w3, #0x3c                  	// #60
    5efc:	91001ff3 	add	x19, sp, #0x7
    5f00:	aa1303e1 	mov	x1, x19
    5f04:	d2800022 	mov	x2, #0x1                   	// #1
    5f08:	aa1403e0 	mov	x0, x20
    5f0c:	39001fe3 	strb	w3, [sp, #7]
    5f10:	97fff028 	bl	1fb0 <buf_put>
    5f14:	f9400795 	ldr	x21, [x28, #8]
    5f18:	aa1503e0 	mov	x0, x21
    5f1c:	97ffed19 	bl	1380 <strlen@plt>
    5f20:	aa1503e1 	mov	x1, x21
    5f24:	aa0003e2 	mov	x2, x0
    5f28:	aa1403e0 	mov	x0, x20
    5f2c:	97fff021 	bl	1fb0 <buf_put>
    5f30:	528007c3 	mov	w3, #0x3e                  	// #62
    5f34:	aa1303e1 	mov	x1, x19
    5f38:	aa1403e0 	mov	x0, x20
    5f3c:	d2800022 	mov	x2, #0x1                   	// #1
    5f40:	39001fe3 	strb	w3, [sp, #7]
    5f44:	17fffe13 	b	5790 <fwp_write+0x9c>
    5f48:	f100067f 	cmp	x19, #0x1
    5f4c:	540025a0 	b.eq	6400 <fwp_write+0xd0c>  // b.none
    5f50:	b100067f 	cmn	x19, #0x1
    5f54:	54002bc0 	b.eq	64cc <fwp_write+0xdd8>  // b.none
    5f58:	d0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    5f5c:	91308021 	add	x1, x1, #0xc20
    5f60:	d2800022 	mov	x2, #0x1                   	// #1
    5f64:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    5f68:	f947f400 	ldr	x0, [x0, #4072]
    5f6c:	f94127e4 	ldr	x4, [sp, #584]
    5f70:	f9400003 	ldr	x3, [x0]
    5f74:	eb030084 	subs	x4, x4, x3
    5f78:	d2800003 	mov	x3, #0x0                   	// #0
    5f7c:	54ffebe0 	b.eq	5cf8 <fwp_write+0x604>  // b.none
    5f80:	f90143f7 	str	x23, [sp, #640]
    5f84:	f90147f8 	str	x24, [sp, #648]
    5f88:	f9014bf9 	str	x25, [sp, #656]
    5f8c:	f9014ffa 	str	x26, [sp, #664]
    5f90:	fd015be8 	str	d8, [sp, #688]
    5f94:	fd015fe9 	str	d9, [sp, #696]
    5f98:	97ffed56 	bl	14f0 <__stack_chk_fail@plt>
    5f9c:	52800b63 	mov	w3, #0x5b                  	// #91
    5fa0:	91001ff5 	add	x21, sp, #0x7
    5fa4:	aa1503e1 	mov	x1, x21
    5fa8:	aa1403e0 	mov	x0, x20
    5fac:	d2800022 	mov	x2, #0x1                   	// #1
    5fb0:	d0000016 	adrp	x22, 7000 <fwp_main_thread+0x920>
    5fb4:	913302d6 	add	x22, x22, #0xcc0
    5fb8:	39001fe3 	strb	w3, [sp, #7]
    5fbc:	97ffeffd 	bl	1fb0 <buf_put>
    5fc0:	b4000273 	cbz	x19, 600c <fwp_write+0x918>
    5fc4:	f9400661 	ldr	x1, [x19, #8]
    5fc8:	aa1403e0 	mov	x0, x20
    5fcc:	f9401f82 	ldr	x2, [x28, #56]
    5fd0:	52800003 	mov	w3, #0x0                   	// #0
    5fd4:	97fffdc8 	bl	56f4 <fwp_write>
    5fd8:	f9400a73 	ldr	x19, [x19, #16]
    5fdc:	b4000193 	cbz	x19, 600c <fwp_write+0x918>
    5fe0:	aa1603e1 	mov	x1, x22
    5fe4:	aa1403e0 	mov	x0, x20
    5fe8:	d2800042 	mov	x2, #0x2                   	// #2
    5fec:	97ffeff1 	bl	1fb0 <buf_put>
    5ff0:	f9400661 	ldr	x1, [x19, #8]
    5ff4:	aa1403e0 	mov	x0, x20
    5ff8:	f9401f82 	ldr	x2, [x28, #56]
    5ffc:	52800003 	mov	w3, #0x0                   	// #0
    6000:	97fffdbd 	bl	56f4 <fwp_write>
    6004:	f9400a73 	ldr	x19, [x19, #16]
    6008:	b5fffed3 	cbnz	x19, 5fe0 <fwp_write+0x8ec>
    600c:	52800ba3 	mov	w3, #0x5d                  	// #93
    6010:	aa1503e1 	mov	x1, x21
    6014:	aa1403e0 	mov	x0, x20
    6018:	d2800022 	mov	x2, #0x1                   	// #1
    601c:	39001fe3 	strb	w3, [sp, #7]
    6020:	17fffddc 	b	5790 <fwp_write+0x9c>
    6024:	aa1403e0 	mov	x0, x20
    6028:	b0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    602c:	d28000c2 	mov	x2, #0x6                   	// #6
    6030:	9132c021 	add	x1, x1, #0xcb0
    6034:	97ffefdf 	bl	1fb0 <buf_put>
    6038:	f9400260 	ldr	x0, [x19]
    603c:	b40004c0 	cbz	x0, 60d4 <fwp_write+0x9e0>
    6040:	910123f5 	add	x21, sp, #0x48
    6044:	91002276 	add	x22, x19, #0x8
    6048:	f90143f7 	str	x23, [sp, #640]
    604c:	d2800017 	mov	x23, #0x0                   	// #0
    6050:	f90147f8 	str	x24, [sp, #648]
    6054:	b0000018 	adrp	x24, 7000 <fwp_main_thread+0x920>
    6058:	9132e318 	add	x24, x24, #0xcb8
    605c:	f9014bf9 	str	x25, [sp, #656]
    6060:	b0000019 	adrp	x25, 7000 <fwp_main_thread+0x920>
    6064:	91330339 	add	x25, x25, #0xcc0
    6068:	f9014ffa 	str	x26, [sp, #664]
    606c:	14000005 	b	6080 <fwp_write+0x98c>
    6070:	aa1903e1 	mov	x1, x25
    6074:	aa1403e0 	mov	x0, x20
    6078:	d2800042 	mov	x2, #0x2                   	// #2
    607c:	97ffefcd 	bl	1fb0 <buf_put>
    6080:	38776ac5 	ldrb	w5, [x22, x23]
    6084:	d2804003 	mov	x3, #0x200                 	// #512
    6088:	aa1803e4 	mov	x4, x24
    608c:	aa0303e1 	mov	x1, x3
    6090:	52800042 	mov	w2, #0x2                   	// #2
    6094:	aa1503e0 	mov	x0, x21
    6098:	910006f7 	add	x23, x23, #0x1
    609c:	97ffecf1 	bl	1460 <__snprintf_chk@plt>
    60a0:	aa1503e0 	mov	x0, x21
    60a4:	97ffecb7 	bl	1380 <strlen@plt>
    60a8:	aa1503e1 	mov	x1, x21
    60ac:	aa0003e2 	mov	x2, x0
    60b0:	aa1403e0 	mov	x0, x20
    60b4:	97ffefbf 	bl	1fb0 <buf_put>
    60b8:	f9400260 	ldr	x0, [x19]
    60bc:	eb17001f 	cmp	x0, x23
    60c0:	54fffd88 	b.hi	6070 <fwp_write+0x97c>  // b.pmore
    60c4:	f94143f7 	ldr	x23, [sp, #640]
    60c8:	f94147f8 	ldr	x24, [sp, #648]
    60cc:	f9414bf9 	ldr	x25, [sp, #656]
    60d0:	f9414ffa 	ldr	x26, [sp, #664]
    60d4:	52800ba3 	mov	w3, #0x5d                  	// #93
    60d8:	aa1403e0 	mov	x0, x20
    60dc:	91001fe1 	add	x1, sp, #0x7
    60e0:	d2800022 	mov	x2, #0x1                   	// #1
    60e4:	39001fe3 	strb	w3, [sp, #7]
    60e8:	17fffdaa 	b	5790 <fwp_write+0x9c>
    60ec:	52800fa3 	mov	w3, #0x7d                  	// #125
    60f0:	17fffe45 	b	5a04 <fwp_write+0x310>
    60f4:	f10002ff 	cmp	x23, #0x0
    60f8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    60fc:	71002c3f 	cmp	w1, #0xb
    6100:	54ffebc0 	b.eq	5e78 <fwp_write+0x784>  // b.none
    6104:	aa1303e2 	mov	x2, x19
    6108:	aa1703e1 	mov	x1, x23
    610c:	aa1403e0 	mov	x0, x20
    6110:	52800003 	mov	w3, #0x0                   	// #0
    6114:	97fffd78 	bl	56f4 <fwp_write>
    6118:	17ffff6a 	b	5ec0 <fwp_write+0x7cc>
    611c:	aa1403e0 	mov	x0, x20
    6120:	91001fe1 	add	x1, sp, #0x7
    6124:	52800fa3 	mov	w3, #0x7d                  	// #125
    6128:	d2800022 	mov	x2, #0x1                   	// #1
    612c:	17fffe39 	b	5a10 <fwp_write+0x31c>
    6130:	a9400281 	ldp	x1, x0, [x20]
    6134:	91000800 	add	x0, x0, #0x2
    6138:	8b160000 	add	x0, x0, x22
    613c:	f9000680 	str	x0, [x20, #8]
    6140:	3820683f 	strb	wzr, [x1, x0]
    6144:	f9413bf5 	ldr	x21, [sp, #624]
    6148:	f9413ff6 	ldr	x22, [sp, #632]
    614c:	f94153fb 	ldr	x27, [sp, #672]
    6150:	f94157fc 	ldr	x28, [sp, #680]
    6154:	17fffd94 	b	57a4 <fwp_write+0xb0>
    6158:	f9400f80 	ldr	x0, [x28, #24]
    615c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    6160:	aa1b03e0 	mov	x0, x27
    6164:	97ffec87 	bl	1380 <strlen@plt>
    6168:	aa1b03e1 	mov	x1, x27
    616c:	aa0003e2 	mov	x2, x0
    6170:	aa1403e0 	mov	x0, x20
    6174:	97ffef8f 	bl	1fb0 <buf_put>
    6178:	aa1903e1 	mov	x1, x25
    617c:	aa1403e0 	mov	x0, x20
    6180:	d2800062 	mov	x2, #0x3                   	// #3
    6184:	97ffef8b 	bl	1fb0 <buf_put>
    6188:	17fffe11 	b	59cc <fwp_write+0x2d8>
    618c:	aa1a03e1 	mov	x1, x26
    6190:	aa1403e0 	mov	x0, x20
    6194:	d2800042 	mov	x2, #0x2                   	// #2
    6198:	97ffef86 	bl	1fb0 <buf_put>
    619c:	17fffe0a 	b	59c4 <fwp_write+0x2d0>
    61a0:	f9400660 	ldr	x0, [x19, #8]
    61a4:	b4fffb00 	cbz	x0, 6104 <fwp_write+0xa10>
    61a8:	b0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    61ac:	91336021 	add	x1, x1, #0xcd8
    61b0:	97ffecf0 	bl	1570 <strcmp@plt>
    61b4:	7100001f 	cmp	w0, #0x0
    61b8:	1a9f07e0 	cset	w0, ne	// ne = any
    61bc:	17ffff2f 	b	5e78 <fwp_write+0x784>
    61c0:	aa1403e0 	mov	x0, x20
    61c4:	d2800042 	mov	x2, #0x2                   	// #2
    61c8:	b0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    61cc:	91334021 	add	x1, x1, #0xcd0
    61d0:	97ffef78 	bl	1fb0 <buf_put>
    61d4:	91004261 	add	x1, x19, #0x10
    61d8:	aa1403e0 	mov	x0, x20
    61dc:	f9402382 	ldr	x2, [x28, #64]
    61e0:	52800003 	mov	w3, #0x0                   	// #0
    61e4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    61e8:	97fffd43 	bl	56f4 <fwp_write>
    61ec:	17fffd9d 	b	5860 <fwp_write+0x16c>
    61f0:	1e22c109 	fcvt	d9, s8
    61f4:	910123f5 	add	x21, sp, #0x48
    61f8:	52800033 	mov	w19, #0x1                   	// #1
    61fc:	d503201f 	nop
    6200:	1e604120 	fmov	d0, d9
    6204:	2a1303e1 	mov	w1, w19
    6208:	aa1503e0 	mov	x0, x21
    620c:	97ffeffe 	bl	2204 <fwp_format_g.constprop.0>
    6210:	aa1503e0 	mov	x0, x21
    6214:	d2800001 	mov	x1, #0x0                   	// #0
    6218:	97ffece2 	bl	15a0 <strtof@plt>
    621c:	1e202100 	fcmp	s8, s0
    6220:	54ffdb60 	b.eq	5d8c <fwp_write+0x698>  // b.none
    6224:	11000673 	add	w19, w19, #0x1
    6228:	71002a7f 	cmp	w19, #0xa
    622c:	54fffea1 	b.ne	6200 <fwp_write+0xb0c>  // b.any
    6230:	1e604120 	fmov	d0, d9
    6234:	aa1503e0 	mov	x0, x21
    6238:	52800121 	mov	w1, #0x9                   	// #9
    623c:	97ffeff2 	bl	2204 <fwp_format_g.constprop.0>
    6240:	17fffed3 	b	5d8c <fwp_write+0x698>
    6244:	d37ef6a1 	lsl	x1, x21, #2
    6248:	b7f81563 	tbnz	x3, #63, 64f4 <fwp_write+0xe00>
    624c:	91002263 	add	x3, x19, #0x8
    6250:	8b010061 	add	x1, x3, x1
    6254:	b9400023 	ldr	w3, [x1]
    6258:	7100081f 	cmp	w0, #0x2
    625c:	2a0303e1 	mov	w1, w3
    6260:	93407c63 	sxtw	x3, w3
    6264:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    6268:	17fffe5a 	b	5bd0 <fwp_write+0x4dc>
    626c:	d37ffaa1 	lsl	x1, x21, #1
    6270:	b7f81363 	tbnz	x3, #63, 64dc <fwp_write+0xde8>
    6274:	91002263 	add	x3, x19, #0x8
    6278:	8b010061 	add	x1, x3, x1
    627c:	79400021 	ldrh	w1, [x1]
    6280:	7100041f 	cmp	w0, #0x1
    6284:	93403c23 	sxth	x3, w1
    6288:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    628c:	17fffe51 	b	5bd0 <fwp_write+0x4dc>
    6290:	52800443 	mov	w3, #0x22                  	// #34
    6294:	91001ff5 	add	x21, sp, #0x7
    6298:	91002273 	add	x19, x19, #0x8
    629c:	aa1503e1 	mov	x1, x21
    62a0:	aa1403e0 	mov	x0, x20
    62a4:	d2800022 	mov	x2, #0x1                   	// #1
    62a8:	39001fe3 	strb	w3, [sp, #7]
    62ac:	f90143f7 	str	x23, [sp, #640]
    62b0:	8b160277 	add	x23, x19, x22
    62b4:	f90147f8 	str	x24, [sp, #648]
    62b8:	97ffef3e 	bl	1fb0 <buf_put>
    62bc:	b4000696 	cbz	x22, 638c <fwp_write+0xc98>
    62c0:	b0000018 	adrp	x24, 7000 <fwp_main_thread+0x920>
    62c4:	91320318 	add	x24, x24, #0xc80
    62c8:	f9014bf9 	str	x25, [sp, #656]
    62cc:	b0000019 	adrp	x25, 7000 <fwp_main_thread+0x920>
    62d0:	91328339 	add	x25, x25, #0xca0
    62d4:	f9014ffa 	str	x26, [sp, #664]
    62d8:	1400000d 	b	630c <fwp_write+0xc18>
    62dc:	710024bf 	cmp	w5, #0x9
    62e0:	54000460 	b.eq	636c <fwp_write+0xc78>  // b.none
    62e4:	710028bf 	cmp	w5, #0xa
    62e8:	54000a61 	b.ne	6434 <fwp_write+0xd40>  // b.any
    62ec:	b0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    62f0:	aa1403e0 	mov	x0, x20
    62f4:	91324021 	add	x1, x1, #0xc90
    62f8:	d2800042 	mov	x2, #0x2                   	// #2
    62fc:	97ffef2d 	bl	1fb0 <buf_put>
    6300:	91000673 	add	x19, x19, #0x1
    6304:	eb17027f 	cmp	x19, x23
    6308:	540003e0 	b.eq	6384 <fwp_write+0xc90>  // b.none
    630c:	39400265 	ldrb	w5, [x19]
    6310:	710034bf 	cmp	w5, #0xd
    6314:	54000180 	b.eq	6344 <fwp_write+0xc50>  // b.none
    6318:	54fffe29 	b.ls	62dc <fwp_write+0xbe8>  // b.plast
    631c:	710088bf 	cmp	w5, #0x22
    6320:	540001c0 	b.eq	6358 <fwp_write+0xc64>  // b.none
    6324:	710170bf 	cmp	w5, #0x5c
    6328:	54000741 	b.ne	6410 <fwp_write+0xd1c>  // b.any
    632c:	aa1403e0 	mov	x0, x20
    6330:	b0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    6334:	d2800042 	mov	x2, #0x2                   	// #2
    6338:	91322021 	add	x1, x1, #0xc88
    633c:	97ffef1d 	bl	1fb0 <buf_put>
    6340:	17fffff0 	b	6300 <fwp_write+0xc0c>
    6344:	aa1903e1 	mov	x1, x25
    6348:	aa1403e0 	mov	x0, x20
    634c:	d2800042 	mov	x2, #0x2                   	// #2
    6350:	97ffef18 	bl	1fb0 <buf_put>
    6354:	17ffffeb 	b	6300 <fwp_write+0xc0c>
    6358:	aa1803e1 	mov	x1, x24
    635c:	aa1403e0 	mov	x0, x20
    6360:	d2800042 	mov	x2, #0x2                   	// #2
    6364:	97ffef13 	bl	1fb0 <buf_put>
    6368:	17ffffe6 	b	6300 <fwp_write+0xc0c>
    636c:	aa1403e0 	mov	x0, x20
    6370:	b0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    6374:	d2800042 	mov	x2, #0x2                   	// #2
    6378:	91326021 	add	x1, x1, #0xc98
    637c:	97ffef0d 	bl	1fb0 <buf_put>
    6380:	17ffffe0 	b	6300 <fwp_write+0xc0c>
    6384:	f9414bf9 	ldr	x25, [sp, #656]
    6388:	f9414ffa 	ldr	x26, [sp, #664]
    638c:	aa1503e1 	mov	x1, x21
    6390:	aa1403e0 	mov	x0, x20
    6394:	52800443 	mov	w3, #0x22                  	// #34
    6398:	17fffd9d 	b	5a0c <fwp_write+0x318>
    639c:	7100103f 	cmp	w1, #0x4
    63a0:	54ffeb21 	b.ne	6104 <fwp_write+0xa10>  // b.any
    63a4:	f94006e0 	ldr	x0, [x23, #8]
    63a8:	d37ffc00 	lsr	x0, x0, #63
    63ac:	17fffeb3 	b	5e78 <fwp_write+0x784>
    63b0:	710002ff 	cmp	w23, #0x0
    63b4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    63b8:	17fffeb0 	b	5e78 <fwp_write+0x784>
    63bc:	528005a1 	mov	w1, #0x2d                  	// #45
    63c0:	eb0203e2 	negs	x2, x2
    63c4:	da0303e3 	ngc	x3, x3
    63c8:	910127e0 	add	x0, sp, #0x49
    63cc:	910123f5 	add	x21, sp, #0x48
    63d0:	390123e1 	strb	w1, [sp, #72]
    63d4:	97ffed93 	bl	1a20 <fwp_fmt_u128>
    63d8:	17fffe18 	b	5c38 <fwp_write+0x544>
    63dc:	d37ceea1 	lsl	x1, x21, #4
    63e0:	b7f810a3 	tbnz	x3, #63, 65f4 <fwp_write+0xf00>
    63e4:	91002260 	add	x0, x19, #0x8
    63e8:	8b010001 	add	x1, x0, x1
    63ec:	17fffdf9 	b	5bd0 <fwp_write+0x4dc>
    63f0:	f9400a61 	ldr	x1, [x19, #16]
    63f4:	8b010000 	add	x0, x0, x1
    63f8:	f9400001 	ldr	x1, [x0]
    63fc:	17fffdf5 	b	5bd0 <fwp_write+0x4dc>
    6400:	b0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    6404:	d2800042 	mov	x2, #0x2                   	// #2
    6408:	9130a021 	add	x1, x1, #0xc28
    640c:	17fffed6 	b	5f64 <fwp_write+0x870>
    6410:	7101fcbf 	cmp	w5, #0x7f
    6414:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    6418:	540000e9 	b.ls	6434 <fwp_write+0xd40>  // b.plast
    641c:	aa1503e1 	mov	x1, x21
    6420:	aa1403e0 	mov	x0, x20
    6424:	d2800022 	mov	x2, #0x1                   	// #1
    6428:	39001fe5 	strb	w5, [sp, #7]
    642c:	97ffeee1 	bl	1fb0 <buf_put>
    6430:	17ffffb4 	b	6300 <fwp_write+0xc0c>
    6434:	d2800203 	mov	x3, #0x10                  	// #16
    6438:	b0000004 	adrp	x4, 7000 <fwp_main_thread+0x920>
    643c:	aa0303e1 	mov	x1, x3
    6440:	9132a084 	add	x4, x4, #0xca8
    6444:	910123f6 	add	x22, sp, #0x48
    6448:	52800042 	mov	w2, #0x2                   	// #2
    644c:	aa1603e0 	mov	x0, x22
    6450:	97ffec04 	bl	1460 <__snprintf_chk@plt>
    6454:	aa1603e0 	mov	x0, x22
    6458:	97ffebca 	bl	1380 <strlen@plt>
    645c:	aa1603e1 	mov	x1, x22
    6460:	aa0003e2 	mov	x2, x0
    6464:	aa1403e0 	mov	x0, x20
    6468:	97ffeed2 	bl	1fb0 <buf_put>
    646c:	17ffffa5 	b	6300 <fwp_write+0xc0c>
    6470:	1e604100 	fmov	d0, d8
    6474:	aa1503e0 	mov	x0, x21
    6478:	52800221 	mov	w1, #0x11                  	// #17
    647c:	97ffef62 	bl	2204 <fwp_format_g.constprop.0>
    6480:	17fffe43 	b	5d8c <fwp_write+0x698>
    6484:	b9401040 	ldr	w0, [x2, #16]
    6488:	350003c0 	cbnz	w0, 6500 <fwp_write+0xe0c>
    648c:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    6490:	f947f400 	ldr	x0, [x0, #4072]
    6494:	f94127e2 	ldr	x2, [sp, #584]
    6498:	f9400001 	ldr	x1, [x0]
    649c:	eb010042 	subs	x2, x2, x1
    64a0:	d2800001 	mov	x1, #0x0                   	// #0
    64a4:	54ffd721 	b.ne	5f88 <fwp_write+0x894>  // b.any
    64a8:	f9413bf5 	ldr	x21, [sp, #624]
    64ac:	b0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    64b0:	f9413ff6 	ldr	x22, [sp, #632]
    64b4:	aa1403e0 	mov	x0, x20
    64b8:	f94143f7 	ldr	x23, [sp, #640]
    64bc:	9133e021 	add	x1, x1, #0xcf8
    64c0:	f94147f8 	ldr	x24, [sp, #648]
    64c4:	d2800042 	mov	x2, #0x2                   	// #2
    64c8:	17fffd0f 	b	5904 <fwp_write+0x210>
    64cc:	b0000001 	adrp	x1, 7000 <fwp_main_thread+0x920>
    64d0:	d2800042 	mov	x2, #0x2                   	// #2
    64d4:	9130c021 	add	x1, x1, #0xc30
    64d8:	17fffea3 	b	5f64 <fwp_write+0x870>
    64dc:	f9400a63 	ldr	x3, [x19, #16]
    64e0:	8b030021 	add	x1, x1, x3
    64e4:	17ffff66 	b	627c <fwp_write+0xb88>
    64e8:	f9400a61 	ldr	x1, [x19, #16]
    64ec:	8b0102a1 	add	x1, x21, x1
    64f0:	17fffdb4 	b	5bc0 <fwp_write+0x4cc>
    64f4:	f9400a63 	ldr	x3, [x19, #16]
    64f8:	8b030021 	add	x1, x1, x3
    64fc:	17ffff56 	b	6254 <fwp_write+0xb60>
    6500:	b9404840 	ldr	w0, [x2, #72]
    6504:	91001ff5 	add	x21, sp, #0x7
    6508:	34ffa380 	cbz	w0, 5978 <fwp_write+0x284>
    650c:	52800503 	mov	w3, #0x28                  	// #40
    6510:	aa1403e0 	mov	x0, x20
    6514:	aa1503e1 	mov	x1, x21
    6518:	d2800022 	mov	x2, #0x1                   	// #1
    651c:	39001fe3 	strb	w3, [sp, #7]
    6520:	97ffeea4 	bl	1fb0 <buf_put>
    6524:	b9401380 	ldr	w0, [x28, #16]
    6528:	52800038 	mov	w24, #0x1                   	// #1
    652c:	7100001f 	cmp	w0, #0x0
    6530:	54ffa38c 	b.gt	59a0 <fwp_write+0x2ac>
    6534:	17fffd33 	b	5a00 <fwp_write+0x30c>
    6538:	f9014bf9 	str	x25, [sp, #656]
    653c:	b00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x15ff0>
    6540:	f9014ffa 	str	x26, [sp, #664]
    6544:	f9400676 	ldr	x22, [x19, #8]
    6548:	912ae333 	add	x19, x25, #0xab8
    654c:	91002273 	add	x19, x19, #0x8
    6550:	937ffed8 	asr	x24, x22, #63
    6554:	aa1802c0 	orr	x0, x22, x24
    6558:	b5000320 	cbnz	x0, 65bc <fwp_write+0xec8>
    655c:	110006b5 	add	w21, w21, #0x1
    6560:	710016bf 	cmp	w21, #0x5
    6564:	54ffffc1 	b.ne	655c <fwp_write+0xe68>  // b.any
    6568:	b7f80578 	tbnz	x24, #63, 6614 <fwp_write+0xf20>
    656c:	910023f3 	add	x19, sp, #0x8
    6570:	aa1603e2 	mov	x2, x22
    6574:	aa1303e0 	mov	x0, x19
    6578:	d2800003 	mov	x3, #0x0                   	// #0
    657c:	97ffed29 	bl	1a20 <fwp_fmt_u128>
    6580:	910123f5 	add	x21, sp, #0x48
    6584:	b0000003 	adrp	x3, 7000 <fwp_main_thread+0x920>
    6588:	aa1303e4 	mov	x4, x19
    658c:	aa1503e0 	mov	x0, x21
    6590:	9133c063 	add	x3, x3, #0xcf0
    6594:	d2804002 	mov	x2, #0x200                 	// #512
    6598:	52800041 	mov	w1, #0x2                   	// #2
    659c:	97ffeb7d 	bl	1390 <__sprintf_chk@plt>
    65a0:	aa1503e0 	mov	x0, x21
    65a4:	97ffeb77 	bl	1380 <strlen@plt>
    65a8:	aa1503e1 	mov	x1, x21
    65ac:	aa0003e2 	mov	x2, x0
    65b0:	aa1403e0 	mov	x0, x20
    65b4:	97ffee7f 	bl	1fb0 <buf_put>
    65b8:	17fffe47 	b	5ed4 <fwp_write+0x7e0>
    65bc:	f9400277 	ldr	x23, [x19]
    65c0:	aa1603e0 	mov	x0, x22
    65c4:	aa1803e1 	mov	x1, x24
    65c8:	aa1703e2 	mov	x2, x23
    65cc:	937ffefa 	asr	x26, x23, #63
    65d0:	aa1a03e3 	mov	x3, x26
    65d4:	94000407 	bl	75f0 <__modti3>
    65d8:	aa010000 	orr	x0, x0, x1
    65dc:	b40002c0 	cbz	x0, 6634 <fwp_write+0xf40>
    65e0:	110006b5 	add	w21, w21, #0x1
    65e4:	91004273 	add	x19, x19, #0x10
    65e8:	710016bf 	cmp	w21, #0x5
    65ec:	54fffe81 	b.ne	65bc <fwp_write+0xec8>  // b.any
    65f0:	17ffffde 	b	6568 <fwp_write+0xe74>
    65f4:	f9400a60 	ldr	x0, [x19, #16]
    65f8:	8b000021 	add	x1, x1, x0
    65fc:	17fffd75 	b	5bd0 <fwp_write+0x4dc>
    6600:	528c29c0 	mov	w0, #0x614e                	// #24910
    6604:	910123f5 	add	x21, sp, #0x48
    6608:	72a009c0 	movk	w0, #0x4e, lsl #16
    660c:	b9004be0 	str	w0, [sp, #72]
    6610:	17fffda2 	b	5c98 <fwp_write+0x5a4>
    6614:	528005a1 	mov	w1, #0x2d                  	// #45
    6618:	eb1603e2 	negs	x2, x22
    661c:	da1803e3 	ngc	x3, x24
    6620:	910027e0 	add	x0, sp, #0x9
    6624:	910023f3 	add	x19, sp, #0x8
    6628:	390023e1 	strb	w1, [sp, #8]
    662c:	97ffecfd 	bl	1a20 <fwp_fmt_u128>
    6630:	17ffffd4 	b	6580 <fwp_write+0xe8c>
    6634:	aa1703e2 	mov	x2, x23
    6638:	aa1a03e3 	mov	x3, x26
    663c:	aa1603e0 	mov	x0, x22
    6640:	aa1803e1 	mov	x1, x24
    6644:	9400030b 	bl	7270 <__divti3>
    6648:	aa0003e2 	mov	x2, x0
    664c:	aa0103e3 	mov	x3, x1
    6650:	b7f80201 	tbnz	x1, #63, 6690 <fwp_write+0xf9c>
    6654:	910023f3 	add	x19, sp, #0x8
    6658:	aa1303e0 	mov	x0, x19
    665c:	97ffecf1 	bl	1a20 <fwp_fmt_u128>
    6660:	937c7ea1 	sbfiz	x1, x21, #4, #32
    6664:	912ae339 	add	x25, x25, #0xab8
    6668:	910123f5 	add	x21, sp, #0x48
    666c:	aa1303e4 	mov	x4, x19
    6670:	aa1503e0 	mov	x0, x21
    6674:	b0000003 	adrp	x3, 7000 <fwp_main_thread+0x920>
    6678:	f8616b25 	ldr	x5, [x25, x1]
    667c:	9133a063 	add	x3, x3, #0xce8
    6680:	d2804002 	mov	x2, #0x200                 	// #512
    6684:	52800041 	mov	w1, #0x2                   	// #2
    6688:	97ffeb42 	bl	1390 <__sprintf_chk@plt>
    668c:	17ffffc5 	b	65a0 <fwp_write+0xeac>
    6690:	528005a4 	mov	w4, #0x2d                  	// #45
    6694:	eb0003e2 	negs	x2, x0
    6698:	da0103e3 	ngc	x3, x1
    669c:	910027e0 	add	x0, sp, #0x9
    66a0:	910023f3 	add	x19, sp, #0x8
    66a4:	390023e4 	strb	w4, [sp, #8]
    66a8:	97ffecde 	bl	1a20 <fwp_fmt_u128>
    66ac:	17ffffed 	b	6660 <fwp_write+0xf6c>
    66b0:	f9013bf5 	str	x21, [sp, #624]
    66b4:	f9013ff6 	str	x22, [sp, #632]
    66b8:	f90143f7 	str	x23, [sp, #640]
    66bc:	f90147f8 	str	x24, [sp, #648]
    66c0:	f9014bf9 	str	x25, [sp, #656]
    66c4:	f9014ffa 	str	x26, [sp, #664]
    66c8:	f90153fb 	str	x27, [sp, #672]
    66cc:	f90157fc 	str	x28, [sp, #680]
    66d0:	fd015be8 	str	d8, [sp, #688]
    66d4:	fd015fe9 	str	d9, [sp, #696]
    66d8:	97ffeb86 	bl	14f0 <__stack_chk_fail@plt>
    66dc:	d503201f 	nop

00000000000066e0 <fwp_main_thread>:
    66e0:	d10603ff 	sub	sp, sp, #0x180
    66e4:	f0000140 	adrp	x0, 31000 <fwp_root_context+0xd10>
    66e8:	91134001 	add	x1, x0, #0x4d0
    66ec:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    66f0:	f947f400 	ldr	x0, [x0, #4072]
    66f4:	a9127bfd 	stp	x29, x30, [sp, #288]
    66f8:	910483fd 	add	x29, sp, #0x120
    66fc:	b953a421 	ldr	w1, [x1, #5028]
    6700:	a91353f3 	stp	x19, x20, [sp, #304]
    6704:	a9145bf5 	stp	x21, x22, [sp, #320]
    6708:	a91773fb 	stp	x27, x28, [sp, #368]
    670c:	f9400002 	ldr	x2, [x0]
    6710:	f9008fe2 	str	x2, [sp, #280]
    6714:	d2800002 	mov	x2, #0x0                   	// #0
    6718:	34005061 	cbz	w1, 7124 <fwp_main_thread+0xa44>
    671c:	f0000140 	adrp	x0, 31000 <fwp_root_context+0xd10>
    6720:	91134000 	add	x0, x0, #0x4d0
    6724:	b953a800 	ldr	w0, [x0, #5032]
    6728:	35004f60 	cbnz	w0, 7114 <fwp_main_thread+0xa34>
    672c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6730:	d00000c2 	adrp	x2, 20000 <__data_start>
    6734:	9100c29b 	add	x27, x20, #0x30
    6738:	910bc042 	add	x2, x2, #0x2f0
    673c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    6740:	d2a00024 	mov	x4, #0x10000               	// #65536
    6744:	910103e0 	add	x0, sp, #0x40
    6748:	9100a3fc 	add	x28, sp, #0x28
    674c:	d2800001 	mov	x1, #0x0                   	// #0
    6750:	f90003e0 	str	x0, [sp]
    6754:	a9010f7c 	stp	x28, x3, [x27, #16]
    6758:	f90023e2 	str	x2, [sp, #64]
    675c:	b9004bff 	str	wzr, [sp, #72]
    6760:	f9002be4 	str	x4, [sp, #80]
    6764:	97ffeaff 	bl	1360 <sigaltstack@plt>
    6768:	350056e0 	cbnz	w0, 7244 <fwp_main_thread+0xb64>
    676c:	4f000400 	movi	v0.4s, #0x0
    6770:	910223e0 	add	x0, sp, #0x88
    6774:	f0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    6778:	91314021 	add	x1, x1, #0xc50
    677c:	f90043e1 	str	x1, [sp, #128]
    6780:	52800082 	mov	w2, #0x4                   	// #4
    6784:	72a10002 	movk	w2, #0x800, lsl #16
    6788:	910203f5 	add	x21, sp, #0x80
    678c:	3d802000 	str	q0, [x0, #128]
    6790:	b9010be2 	str	w2, [sp, #264]
    6794:	ad000000 	stp	q0, q0, [x0]
    6798:	ad010000 	stp	q0, q0, [x0, #32]
    679c:	ad020000 	stp	q0, q0, [x0, #64]
    67a0:	ad030000 	stp	q0, q0, [x0, #96]
    67a4:	97ffeb43 	bl	14b0 <sigemptyset@plt>
    67a8:	350054e0 	cbnz	w0, 7244 <fwp_main_thread+0xb64>
    67ac:	aa1503e1 	mov	x1, x21
    67b0:	d2800002 	mov	x2, #0x0                   	// #0
    67b4:	52800160 	mov	w0, #0xb                   	// #11
    67b8:	97ffeb56 	bl	1510 <sigaction@plt>
    67bc:	35005440 	cbnz	w0, 7244 <fwp_main_thread+0xb64>
    67c0:	aa1503e1 	mov	x1, x21
    67c4:	d2800002 	mov	x2, #0x0                   	// #0
    67c8:	528000e0 	mov	w0, #0x7                   	// #7
    67cc:	97ffeb51 	bl	1510 <sigaction@plt>
    67d0:	350053a0 	cbnz	w0, 7244 <fwp_main_thread+0xb64>
    67d4:	b9429760 	ldr	w0, [x27, #660]
    67d8:	a91563f7 	stp	x23, x24, [sp, #336]
    67dc:	34001f60 	cbz	w0, 6bc8 <fwp_main_thread+0x4e8>
    67e0:	9100c296 	add	x22, x20, #0x30
    67e4:	f94006d5 	ldr	x21, [x22, #8]
    67e8:	b40010f5 	cbz	x21, 6a04 <fwp_main_thread+0x324>
    67ec:	aa1503f3 	mov	x19, x21
    67f0:	910102b7 	add	x23, x21, #0x40
    67f4:	a9166bf9 	stp	x25, x26, [sp, #352]
    67f8:	52800038 	mov	w24, #0x1                   	// #1
    67fc:	39414ab9 	ldrb	w25, [x21, #82]
    6800:	39014ab8 	strb	w24, [x21, #82]
    6804:	f94016a0 	ldr	x0, [x21, #40]
    6808:	b4000620 	cbz	x0, 68cc <fwp_main_thread+0x1ec>
    680c:	f94032a1 	ldr	x1, [x21, #96]
    6810:	394146a0 	ldrb	w0, [x21, #81]
    6814:	b4000b61 	cbz	x1, 6980 <fwp_main_thread+0x2a0>
    6818:	36000aa0 	tbz	w0, #0, 696c <fwp_main_thread+0x28c>
    681c:	39414a62 	ldrb	w2, [x19, #82]
    6820:	f94022a0 	ldr	x0, [x21, #64]
    6824:	37000d82 	tbnz	w2, #0, 69d4 <fwp_main_thread+0x2f4>
    6828:	f9403261 	ldr	x1, [x19, #96]
    682c:	a911fe77 	stp	x23, xzr, [x19, #280]
    6830:	f9009660 	str	x0, [x19, #296]
    6834:	b4000040 	cbz	x0, 683c <fwp_main_thread+0x15c>
    6838:	f9009013 	str	x19, [x0, #288]
    683c:	f90022b3 	str	x19, [x21, #64]
    6840:	b4000101 	cbz	x1, 6860 <fwp_main_thread+0x180>
    6844:	f9401ac0 	ldr	x0, [x22, #48]
    6848:	39015678 	strb	w24, [x19, #85]
    684c:	f9003661 	str	x1, [x19, #104]
    6850:	a910827f 	stp	xzr, x0, [x19, #264]
    6854:	b4000040 	cbz	x0, 685c <fwp_main_thread+0x17c>
    6858:	f9008413 	str	x19, [x0, #264]
    685c:	f9001ad3 	str	x19, [x22, #48]
    6860:	39015a7f 	strb	wzr, [x19, #86]
    6864:	97fff418 	bl	38c4 <fwp_block>
    6868:	f9408e62 	ldr	x2, [x19, #280]
    686c:	b4000142 	cbz	x2, 6894 <fwp_main_thread+0x1b4>
    6870:	a9520261 	ldp	x1, x0, [x19, #288]
    6874:	b4000bc1 	cbz	x1, 69ec <fwp_main_thread+0x30c>
    6878:	f9009420 	str	x0, [x1, #296]
    687c:	f9409660 	ldr	x0, [x19, #296]
    6880:	b4000040 	cbz	x0, 6888 <fwp_main_thread+0x1a8>
    6884:	f9009001 	str	x1, [x0, #288]
    6888:	91080260 	add	x0, x19, #0x200
    688c:	f900967f 	str	xzr, [x19, #296]
    6890:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    6894:	39415660 	ldrb	w0, [x19, #85]
    6898:	f94006c2 	ldr	x2, [x22, #8]
    689c:	36000980 	tbz	w0, #0, 69cc <fwp_main_thread+0x2ec>
    68a0:	a9508261 	ldp	x1, x0, [x19, #264]
    68a4:	b4000a81 	cbz	x1, 69f4 <fwp_main_thread+0x314>
    68a8:	f9008820 	str	x0, [x1, #272]
    68ac:	b4000040 	cbz	x0, 68b4 <fwp_main_thread+0x1d4>
    68b0:	f9008401 	str	x1, [x0, #264]
    68b4:	91080260 	add	x0, x19, #0x200
    68b8:	3901567f 	strb	wzr, [x19, #85]
    68bc:	aa0203f3 	mov	x19, x2
    68c0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    68c4:	f94016a0 	ldr	x0, [x21, #40]
    68c8:	b5fffa20 	cbnz	x0, 680c <fwp_main_thread+0x12c>
    68cc:	9100c280 	add	x0, x20, #0x30
    68d0:	39014ab9 	strb	w25, [x21, #82]
    68d4:	a9566bf9 	ldp	x25, x26, [sp, #352]
    68d8:	f9413c00 	ldr	x0, [x0, #632]
    68dc:	b4001560 	cbz	x0, 6b88 <fwp_main_thread+0x4a8>
    68e0:	9100c280 	add	x0, x20, #0x30
    68e4:	f9415401 	ldr	x1, [x0, #680]
    68e8:	b902a01f 	str	wzr, [x0, #672]
    68ec:	eb13003f 	cmp	x1, x19
    68f0:	54001681 	b.ne	6bc0 <fwp_main_thread+0x4e0>  // b.any
    68f4:	b4000933 	cbz	x19, 6a18 <fwp_main_thread+0x338>
    68f8:	9100c280 	add	x0, x20, #0x30
    68fc:	52800021 	mov	w1, #0x1                   	// #1
    6900:	39014a61 	strb	w1, [x19, #82]
    6904:	f9412805 	ldr	x5, [x0, #592]
    6908:	b4000885 	cbz	x5, 6a18 <fwp_main_thread+0x338>
    690c:	d503201f 	nop
    6910:	394140a0 	ldrb	w0, [x5, #80]
    6914:	37000060 	tbnz	w0, #0, 6920 <fwp_main_thread+0x240>
    6918:	aa0503e0 	mov	x0, x5
    691c:	97ffedbd 	bl	2010 <fwp_cancel_tree.part.0>
    6920:	f9409ca5 	ldr	x5, [x5, #312]
    6924:	b5ffff65 	cbnz	x5, 6910 <fwp_main_thread+0x230>
    6928:	9100c295 	add	x21, x20, #0x30
    692c:	52800036 	mov	w22, #0x1                   	// #1
    6930:	f9402a60 	ldr	x0, [x19, #80]
    6934:	f2001c1f 	tst	x0, #0xff000000ff
    6938:	540000e1 	b.ne	6954 <fwp_main_thread+0x274>  // b.any
    693c:	f94012a0 	ldr	x0, [x21, #32]
    6940:	39015276 	strb	w22, [x19, #84]
    6944:	f900827f 	str	xzr, [x19, #256]
    6948:	b40005a0 	cbz	x0, 69fc <fwp_main_thread+0x31c>
    694c:	f9008013 	str	x19, [x0, #256]
    6950:	f90012b3 	str	x19, [x21, #32]
    6954:	97fff3dc 	bl	38c4 <fwp_block>
    6958:	97fff36e 	bl	3710 <fwp_free_zombie>
    695c:	f9412aa0 	ldr	x0, [x21, #592]
    6960:	b40005c0 	cbz	x0, 6a18 <fwp_main_thread+0x338>
    6964:	f94156b3 	ldr	x19, [x21, #680]
    6968:	17fffff2 	b	6930 <fwp_main_thread+0x250>
    696c:	97ffedfd 	bl	2160 <fwp_now_ns>
    6970:	f94032a1 	ldr	x1, [x21, #96]
    6974:	eb01001f 	cmp	x0, x1
    6978:	54000faa 	b.ge	6b6c <fwp_main_thread+0x48c>  // b.tcont
    697c:	394146a0 	ldrb	w0, [x21, #81]
    6980:	39414a62 	ldrb	w2, [x19, #82]
    6984:	3707f4e0 	tbnz	w0, #0, 6820 <fwp_main_thread+0x140>
    6988:	f94032a1 	ldr	x1, [x21, #96]
    698c:	370001c2 	tbnz	w2, #0, 69c4 <fwp_main_thread+0x2e4>
    6990:	f9403260 	ldr	x0, [x19, #96]
    6994:	b4000180 	cbz	x0, 69c4 <fwp_main_thread+0x2e4>
    6998:	b4000061 	cbz	x1, 69a4 <fwp_main_thread+0x2c4>
    699c:	eb01001f 	cmp	x0, x1
    69a0:	9a81d000 	csel	x0, x0, x1, le
    69a4:	f94022a1 	ldr	x1, [x21, #64]
    69a8:	a911fe77 	stp	x23, xzr, [x19, #280]
    69ac:	f9009661 	str	x1, [x19, #296]
    69b0:	b40040e1 	cbz	x1, 71cc <fwp_main_thread+0xaec>
    69b4:	f9009033 	str	x19, [x1, #288]
    69b8:	aa0003e1 	mov	x1, x0
    69bc:	f90022b3 	str	x19, [x21, #64]
    69c0:	17ffffa1 	b	6844 <fwp_main_thread+0x164>
    69c4:	f94022a0 	ldr	x0, [x21, #64]
    69c8:	17ffff99 	b	682c <fwp_main_thread+0x14c>
    69cc:	aa0203f3 	mov	x19, x2
    69d0:	17ffff8d 	b	6804 <fwp_main_thread+0x124>
    69d4:	a911fe77 	stp	x23, xzr, [x19, #280]
    69d8:	f9009660 	str	x0, [x19, #296]
    69dc:	b4000040 	cbz	x0, 69e4 <fwp_main_thread+0x304>
    69e0:	f9009013 	str	x19, [x0, #288]
    69e4:	f90022b3 	str	x19, [x21, #64]
    69e8:	17ffff9e 	b	6860 <fwp_main_thread+0x180>
    69ec:	f9000040 	str	x0, [x2]
    69f0:	17ffffa4 	b	6880 <fwp_main_thread+0x1a0>
    69f4:	f9001ac0 	str	x0, [x22, #48]
    69f8:	17ffffad 	b	68ac <fwp_main_thread+0x1cc>
    69fc:	f90016b3 	str	x19, [x21, #40]
    6a00:	17ffffd4 	b	6950 <fwp_main_thread+0x270>
    6a04:	f9413ec0 	ldr	x0, [x22, #632]
    6a08:	b4000be0 	cbz	x0, 6b84 <fwp_main_thread+0x4a4>
    6a0c:	f94156c0 	ldr	x0, [x22, #680]
    6a10:	b902a2df 	str	wzr, [x22, #672]
    6a14:	b5000d60 	cbnz	x0, 6bc0 <fwp_main_thread+0x4e0>
    6a18:	9100c295 	add	x21, x20, #0x30
    6a1c:	97fff33d 	bl	3710 <fwp_free_zombie>
    6a20:	f94016a0 	ldr	x0, [x21, #40]
    6a24:	b5000ce0 	cbnz	x0, 6bc0 <fwp_main_thread+0x4e0>
    6a28:	f9401aa0 	ldr	x0, [x21, #48]
    6a2c:	b5000ca0 	cbnz	x0, 6bc0 <fwp_main_thread+0x4e0>
    6a30:	b94042b3 	ldr	w19, [x21, #64]
    6a34:	340001d3 	cbz	w19, 6a6c <fwp_main_thread+0x38c>
    6a38:	93407e76 	sxtw	x22, w19
    6a3c:	51000673 	sub	w19, w19, #0x1
    6a40:	d1000ad6 	sub	x22, x22, #0x2
    6a44:	910142b7 	add	x23, x21, #0x50
    6a48:	cb3342d6 	sub	x22, x22, w19, uxtw
    6a4c:	93407e73 	sxtw	x19, w19
    6a50:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    6a54:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    6a58:	b90042b3 	str	w19, [x21, #64]
    6a5c:	d1000673 	sub	x19, x19, #0x1
    6a60:	97ffeaec 	bl	1610 <munmap@plt>
    6a64:	eb1302df 	cmp	x22, x19
    6a68:	54ffff41 	b.ne	6a50 <fwp_main_thread+0x370>  // b.any
    6a6c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6a70:	b9401260 	ldr	w0, [x19, #16]
    6a74:	37f80040 	tbnz	w0, #31, 6a7c <fwp_main_thread+0x39c>
    6a78:	97ffeaa2 	bl	1500 <close@plt>
    6a7c:	9100c280 	add	x0, x20, #0x30
    6a80:	12800001 	mov	w1, #0xffffffff            	// #-1
    6a84:	b9001261 	str	w1, [x19, #16]
    6a88:	d2800013 	mov	x19, #0x0                   	// #0
    6a8c:	f9415816 	ldr	x22, [x0, #688]
    6a90:	f9415c15 	ldr	x21, [x0, #696]
    6a94:	b4000176 	cbz	x22, 6ac0 <fwp_main_thread+0x3e0>
    6a98:	f8737aa0 	ldr	x0, [x21, x19, lsl #3]
    6a9c:	b40000c0 	cbz	x0, 6ab4 <fwp_main_thread+0x3d4>
    6aa0:	f9400001 	ldr	x1, [x0]
    6aa4:	b50008e1 	cbnz	x1, 6bc0 <fwp_main_thread+0x4e0>
    6aa8:	f9400401 	ldr	x1, [x0, #8]
    6aac:	b50008a1 	cbnz	x1, 6bc0 <fwp_main_thread+0x4e0>
    6ab0:	97fff148 	bl	2fd0 <fwp_mem_free>
    6ab4:	91000673 	add	x19, x19, #0x1
    6ab8:	eb16027f 	cmp	x19, x22
    6abc:	54fffee1 	b.ne	6a98 <fwp_main_thread+0x3b8>  // b.any
    6ac0:	aa1503e0 	mov	x0, x21
    6ac4:	97fff143 	bl	2fd0 <fwp_mem_free>
    6ac8:	9100c280 	add	x0, x20, #0x30
    6acc:	f9415413 	ldr	x19, [x0, #680]
    6ad0:	f901581f 	str	xzr, [x0, #688]
    6ad4:	f9015c1f 	str	xzr, [x0, #696]
    6ad8:	b40001f3 	cbz	x19, 6b14 <fwp_main_thread+0x434>
    6adc:	f9401661 	ldr	x1, [x19, #40]
    6ae0:	b5000701 	cbnz	x1, 6bc0 <fwp_main_thread+0x4e0>
    6ae4:	f9405661 	ldr	x1, [x19, #168]
    6ae8:	b50006c1 	cbnz	x1, 6bc0 <fwp_main_thread+0x4e0>
    6aec:	f9413c01 	ldr	x1, [x0, #632]
    6af0:	b5000681 	cbnz	x1, 6bc0 <fwp_main_thread+0x4e0>
    6af4:	f9414400 	ldr	x0, [x0, #648]
    6af8:	b5000640 	cbnz	x0, 6bc0 <fwp_main_thread+0x4e0>
    6afc:	d2823a02 	mov	x2, #0x11d0                	// #4560
    6b00:	d0000140 	adrp	x0, 30000 <alt.4+0xfd10>
    6b04:	910bc000 	add	x0, x0, #0x2f0
    6b08:	97ffea6e 	bl	14c0 <memset@plt>
    6b0c:	aa1303e0 	mov	x0, x19
    6b10:	97fff130 	bl	2fd0 <fwp_mem_free>
    6b14:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    6b18:	f947ec00 	ldr	x0, [x0, #4056]
    6b1c:	9100c294 	add	x20, x20, #0x30
    6b20:	f9400000 	ldr	x0, [x0]
    6b24:	f900069f 	str	xzr, [x20, #8]
    6b28:	f901569f 	str	xzr, [x20, #680]
    6b2c:	97ffeabd 	bl	1620 <fflush@plt>
    6b30:	b00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x15ff0>
    6b34:	f947f400 	ldr	x0, [x0, #4072]
    6b38:	f9408fe2 	ldr	x2, [sp, #280]
    6b3c:	f9400001 	ldr	x1, [x0]
    6b40:	eb010042 	subs	x2, x2, x1
    6b44:	d2800001 	mov	x1, #0x0                   	// #0
    6b48:	54003901 	b.ne	7268 <fwp_main_thread+0xb88>  // b.any
    6b4c:	a9527bfd 	ldp	x29, x30, [sp, #288]
    6b50:	d2800000 	mov	x0, #0x0                   	// #0
    6b54:	a95353f3 	ldp	x19, x20, [sp, #304]
    6b58:	a9545bf5 	ldp	x21, x22, [sp, #320]
    6b5c:	a95563f7 	ldp	x23, x24, [sp, #336]
    6b60:	a95773fb 	ldp	x27, x28, [sp, #368]
    6b64:	910603ff 	add	sp, sp, #0x180
    6b68:	d65f03c0 	ret
    6b6c:	394142a0 	ldrb	w0, [x21, #80]
    6b70:	3707f060 	tbnz	w0, #0, 697c <fwp_main_thread+0x29c>
    6b74:	aa1503e0 	mov	x0, x21
    6b78:	97ffed26 	bl	2010 <fwp_cancel_tree.part.0>
    6b7c:	394146a0 	ldrb	w0, [x21, #81]
    6b80:	17ffff80 	b	6980 <fwp_main_thread+0x2a0>
    6b84:	d2800013 	mov	x19, #0x0                   	// #0
    6b88:	9100c295 	add	x21, x20, #0x30
    6b8c:	f94146a0 	ldr	x0, [x21, #648]
    6b90:	b5ffea80 	cbnz	x0, 68e0 <fwp_main_thread+0x200>
    6b94:	f9413aa0 	ldr	x0, [x21, #624]
    6b98:	97fff10e 	bl	2fd0 <fwp_mem_free>
    6b9c:	f9013abf 	str	xzr, [x21, #624]
    6ba0:	f90142bf 	str	xzr, [x21, #640]
    6ba4:	f94156a0 	ldr	x0, [x21, #680]
    6ba8:	b4003373 	cbz	x19, 7214 <fwp_main_thread+0xb34>
    6bac:	f900567f 	str	xzr, [x19, #168]
    6bb0:	f9005e7f 	str	xzr, [x19, #184]
    6bb4:	b902a2bf 	str	wzr, [x21, #672]
    6bb8:	eb13001f 	cmp	x0, x19
    6bbc:	54ffe9e0 	b.eq	68f8 <fwp_main_thread+0x218>  // b.none
    6bc0:	a9166bf9 	stp	x25, x26, [sp, #352]
    6bc4:	97ffea5f 	bl	1540 <abort@plt>
    6bc8:	f9413362 	ldr	x2, [x27, #608]
    6bcc:	f0ffffc1 	adrp	x1, 1000 <__abi_tag+0xd88>
    6bd0:	912d4021 	add	x1, x1, #0xb50
    6bd4:	f0000140 	adrp	x0, 31000 <fwp_root_context+0xd10>
    6bd8:	a90287e2 	stp	x2, x1, [sp, #40]
    6bdc:	91134017 	add	x23, x0, #0x4d0
    6be0:	d2800013 	mov	x19, #0x0                   	// #0
    6be4:	f94003e1 	ldr	x1, [sp]
    6be8:	a9166bf9 	stp	x25, x26, [sp, #352]
    6bec:	d0ffffe0 	adrp	x0, 4000 <f74+0xf0>
    6bf0:	d280401a 	mov	x26, #0x200                 	// #512
    6bf4:	9128c000 	add	x0, x0, #0xa30
    6bf8:	d2800016 	mov	x22, #0x0                   	// #0
    6bfc:	52800039 	mov	w25, #0x1                   	// #1
    6c00:	f9001fe1 	str	x1, [sp, #56]
    6c04:	f90023ff 	str	xzr, [sp, #64]
    6c08:	a90503ff 	stp	xzr, x0, [sp, #80]
    6c0c:	f901337c 	str	x28, [x27, #608]
    6c10:	f100075b 	subs	x27, x26, #0x1
    6c14:	aa1503e1 	mov	x1, x21
    6c18:	da1f02d8 	sbc	x24, x22, xzr
    6c1c:	52800020 	mov	w0, #0x1                   	// #1
    6c20:	f90027fb 	str	x27, [sp, #72]
    6c24:	aa1b03fa 	mov	x26, x27
    6c28:	a9084ffb 	stp	x27, x19, [sp, #128]
    6c2c:	97fff471 	bl	3df0 <fwp_data.part.0.constprop.0>
    6c30:	aa0003f3 	mov	x19, x0
    6c34:	f949dae1 	ldr	x1, [x23, #5040]
    6c38:	aa1803f6 	mov	x22, x24
    6c3c:	f949eee0 	ldr	x0, [x23, #5080]
    6c40:	cb010261 	sub	x1, x19, x1
    6c44:	eb00403f 	cmp	x1, x0, lsl #16
    6c48:	54000302 	b.cs	6ca8 <fwp_main_thread+0x5c8>  // b.hs, b.nlast
    6c4c:	d350fc20 	lsr	x0, x1, #16
    6c50:	f949fee5 	ldr	x5, [x23, #5112]
    6c54:	8b000800 	add	x0, x0, x0, lsl #2
    6c58:	d37df002 	lsl	x2, x0, #3
    6c5c:	8b0200a0 	add	x0, x5, x2
    6c60:	f940101c 	ldr	x28, [x0, #32]
    6c64:	b400023c 	cbz	x28, 6ca8 <fwp_main_thread+0x5c8>
    6c68:	386268a2 	ldrb	w2, [x5, x2]
    6c6c:	7100085f 	cmp	w2, #0x2
    6c70:	54002420 	b.eq	70f4 <fwp_main_thread+0xa14>  // b.none
    6c74:	7100045f 	cmp	w2, #0x1
    6c78:	54000181 	b.ne	6ca8 <fwp_main_thread+0x5c8>  // b.any
    6c7c:	29430002 	ldp	w2, w0, [x0, #24]
    6c80:	92403c21 	and	x1, x1, #0xffff
    6c84:	9b027c21 	mul	x1, x1, x2
    6c88:	d360fc21 	lsr	x1, x1, #32
    6c8c:	eb00003f 	cmp	x1, x0
    6c90:	540000c2 	b.cs	6ca8 <fwp_main_thread+0x5c8>  // b.hs, b.nlast
    6c94:	8b01039c 	add	x28, x28, x1
    6c98:	39400380 	ldrb	w0, [x28]
    6c9c:	7103fc1f 	cmp	w0, #0xff
    6ca0:	54002340 	b.eq	7108 <fwp_main_thread+0xa28>  // b.none
    6ca4:	39000399 	strb	w25, [x28]
    6ca8:	f90023f3 	str	x19, [sp, #64]
    6cac:	aa18037b 	orr	x27, x27, x24
    6cb0:	b5fffb1b 	cbnz	x27, 6c10 <fwp_main_thread+0x530>
    6cb4:	b0000000 	adrp	x0, 7000 <fwp_main_thread+0x920>
    6cb8:	9100c282 	add	x2, x20, #0x30
    6cbc:	f94017e3 	ldr	x3, [sp, #40]
    6cc0:	910183e1 	add	x1, sp, #0x60
    6cc4:	3dc3b400 	ldr	q0, [x0, #3792]
    6cc8:	52800020 	mov	w0, #0x1                   	// #1
    6ccc:	f9013043 	str	x3, [x2, #608]
    6cd0:	3d801be0 	str	q0, [sp, #96]
    6cd4:	97fff447 	bl	3df0 <fwp_data.part.0.constprop.0>
    6cd8:	f0000141 	adrp	x1, 31000 <fwp_root_context+0xd10>
    6cdc:	91134023 	add	x3, x1, #0x4d0
    6ce0:	aa0003f6 	mov	x22, x0
    6ce4:	f949d861 	ldr	x1, [x3, #5040]
    6ce8:	f949ec60 	ldr	x0, [x3, #5080]
    6cec:	cb0102c1 	sub	x1, x22, x1
    6cf0:	eb00403f 	cmp	x1, x0, lsl #16
    6cf4:	54000322 	b.cs	6d58 <fwp_main_thread+0x678>  // b.hs, b.nlast
    6cf8:	d350fc22 	lsr	x2, x1, #16
    6cfc:	f949fc63 	ldr	x3, [x3, #5112]
    6d00:	8b020842 	add	x2, x2, x2, lsl #2
    6d04:	d37df042 	lsl	x2, x2, #3
    6d08:	8b020060 	add	x0, x3, x2
    6d0c:	f9401017 	ldr	x23, [x0, #32]
    6d10:	b4000257 	cbz	x23, 6d58 <fwp_main_thread+0x678>
    6d14:	38626862 	ldrb	w2, [x3, x2]
    6d18:	7100085f 	cmp	w2, #0x2
    6d1c:	540025e0 	b.eq	71d8 <fwp_main_thread+0xaf8>  // b.none
    6d20:	7100045f 	cmp	w2, #0x1
    6d24:	540001a1 	b.ne	6d58 <fwp_main_thread+0x678>  // b.any
    6d28:	29430002 	ldp	w2, w0, [x0, #24]
    6d2c:	92403c21 	and	x1, x1, #0xffff
    6d30:	9b027c21 	mul	x1, x1, x2
    6d34:	d360fc21 	lsr	x1, x1, #32
    6d38:	eb00003f 	cmp	x1, x0
    6d3c:	540000e2 	b.cs	6d58 <fwp_main_thread+0x678>  // b.hs, b.nlast
    6d40:	8b0102f7 	add	x23, x23, x1
    6d44:	394002e0 	ldrb	w0, [x23]
    6d48:	7103fc1f 	cmp	w0, #0xff
    6d4c:	54002700 	b.eq	722c <fwp_main_thread+0xb4c>  // b.none
    6d50:	52800020 	mov	w0, #0x1                   	// #1
    6d54:	390002e0 	strb	w0, [x23]
    6d58:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    6d5c:	aa1503e1 	mov	x1, x21
    6d60:	52800020 	mov	w0, #0x1                   	// #1
    6d64:	a9085be2 	stp	x2, x22, [sp, #128]
    6d68:	97fff422 	bl	3df0 <fwp_data.part.0.constprop.0>
    6d6c:	f0000141 	adrp	x1, 31000 <fwp_root_context+0xd10>
    6d70:	91134023 	add	x3, x1, #0x4d0
    6d74:	aa0003f5 	mov	x21, x0
    6d78:	f949d861 	ldr	x1, [x3, #5040]
    6d7c:	f949ec60 	ldr	x0, [x3, #5080]
    6d80:	cb0102a1 	sub	x1, x21, x1
    6d84:	eb00403f 	cmp	x1, x0, lsl #16
    6d88:	54000322 	b.cs	6dec <fwp_main_thread+0x70c>  // b.hs, b.nlast
    6d8c:	d350fc22 	lsr	x2, x1, #16
    6d90:	f949fc63 	ldr	x3, [x3, #5112]
    6d94:	8b020842 	add	x2, x2, x2, lsl #2
    6d98:	d37df042 	lsl	x2, x2, #3
    6d9c:	8b020060 	add	x0, x3, x2
    6da0:	f9401016 	ldr	x22, [x0, #32]
    6da4:	b4000256 	cbz	x22, 6dec <fwp_main_thread+0x70c>
    6da8:	38626862 	ldrb	w2, [x3, x2]
    6dac:	7100085f 	cmp	w2, #0x2
    6db0:	54002200 	b.eq	71f0 <fwp_main_thread+0xb10>  // b.none
    6db4:	7100045f 	cmp	w2, #0x1
    6db8:	540001a1 	b.ne	6dec <fwp_main_thread+0x70c>  // b.any
    6dbc:	29430002 	ldp	w2, w0, [x0, #24]
    6dc0:	92403c21 	and	x1, x1, #0xffff
    6dc4:	9b027c21 	mul	x1, x1, x2
    6dc8:	d360fc21 	lsr	x1, x1, #32
    6dcc:	eb00003f 	cmp	x1, x0
    6dd0:	540000e2 	b.cs	6dec <fwp_main_thread+0x70c>  // b.hs, b.nlast
    6dd4:	8b0102d6 	add	x22, x22, x1
    6dd8:	394002c0 	ldrb	w0, [x22]
    6ddc:	7103fc1f 	cmp	w0, #0xff
    6de0:	540022c0 	b.eq	7238 <fwp_main_thread+0xb58>  // b.none
    6de4:	52800020 	mov	w0, #0x1                   	// #1
    6de8:	390002c0 	strb	w0, [x22]
    6dec:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    6df0:	9101c3e1 	add	x1, sp, #0x70
    6df4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    6df8:	52800020 	mov	w0, #0x1                   	// #1
    6dfc:	a90757e2 	stp	x2, x21, [sp, #112]
    6e00:	97fff3fc 	bl	3df0 <fwp_data.part.0.constprop.0>
    6e04:	f0000141 	adrp	x1, 31000 <fwp_root_context+0xd10>
    6e08:	91134022 	add	x2, x1, #0x4d0
    6e0c:	aa0003f7 	mov	x23, x0
    6e10:	f949d841 	ldr	x1, [x2, #5040]
    6e14:	f949ec40 	ldr	x0, [x2, #5080]
    6e18:	cb0102e1 	sub	x1, x23, x1
    6e1c:	eb00403f 	cmp	x1, x0, lsl #16
    6e20:	54000322 	b.cs	6e84 <fwp_main_thread+0x7a4>  // b.hs, b.nlast
    6e24:	d350fc20 	lsr	x0, x1, #16
    6e28:	f949fc43 	ldr	x3, [x2, #5112]
    6e2c:	8b000800 	add	x0, x0, x0, lsl #2
    6e30:	d37df002 	lsl	x2, x0, #3
    6e34:	8b020060 	add	x0, x3, x2
    6e38:	f9401015 	ldr	x21, [x0, #32]
    6e3c:	b4000255 	cbz	x21, 6e84 <fwp_main_thread+0x7a4>
    6e40:	38626862 	ldrb	w2, [x3, x2]
    6e44:	7100085f 	cmp	w2, #0x2
    6e48:	54001ce0 	b.eq	71e4 <fwp_main_thread+0xb04>  // b.none
    6e4c:	7100045f 	cmp	w2, #0x1
    6e50:	540001a1 	b.ne	6e84 <fwp_main_thread+0x7a4>  // b.any
    6e54:	29430002 	ldp	w2, w0, [x0, #24]
    6e58:	92403c21 	and	x1, x1, #0xffff
    6e5c:	9b027c21 	mul	x1, x1, x2
    6e60:	d360fc21 	lsr	x1, x1, #32
    6e64:	eb00003f 	cmp	x1, x0
    6e68:	540000e2 	b.cs	6e84 <fwp_main_thread+0x7a4>  // b.hs, b.nlast
    6e6c:	8b0102b5 	add	x21, x21, x1
    6e70:	394002a0 	ldrb	w0, [x21]
    6e74:	7103fc1f 	cmp	w0, #0xff
    6e78:	54001d40 	b.eq	7220 <fwp_main_thread+0xb40>  // b.none
    6e7c:	52800020 	mov	w0, #0x1                   	// #1
    6e80:	390002a0 	strb	w0, [x21]
    6e84:	aa1303f6 	mov	x22, x19
    6e88:	b00000da 	adrp	x26, 1f000 <__FRAME_END__+0x15ff0>
    6e8c:	b40015d3 	cbz	x19, 7144 <fwp_main_thread+0xa64>
    6e90:	912ae35a 	add	x26, x26, #0xab8
    6e94:	b000001b 	adrp	x27, 7000 <fwp_main_thread+0x920>
    6e98:	91014340 	add	x0, x26, #0x50
    6e9c:	f90007e0 	str	x0, [sp, #8]
    6ea0:	9131c360 	add	x0, x27, #0xc70
    6ea4:	f9000be0 	str	x0, [sp, #16]
    6ea8:	f0000140 	adrp	x0, 31000 <fwp_root_context+0xd10>
    6eac:	9113401c 	add	x28, x0, #0x4d0
    6eb0:	1400004a 	b	6fd8 <fwp_main_thread+0x8f8>
    6eb4:	f940034a 	ldr	x10, [x26]
    6eb8:	aa1a03e0 	mov	x0, x26
    6ebc:	52800001 	mov	w1, #0x0                   	// #0
    6ec0:	f9000fe8 	str	x8, [sp, #24]
    6ec4:	aa2a03ea 	mvn	x10, x10
    6ec8:	f901e0ca 	str	x10, [x6, #960]
    6ecc:	97ffe97d 	bl	14c0 <memset@plt>
    6ed0:	f9400fe8 	ldr	x8, [sp, #24]
    6ed4:	f94a1380 	ldr	x0, [x28, #5152]
    6ed8:	ab080000 	adds	x0, x0, x8
    6edc:	54001be2 	b.cs	7258 <fwp_main_thread+0xb78>  // b.hs, b.nlast
    6ee0:	f94a1781 	ldr	x1, [x28, #5160]
    6ee4:	f90a1380 	str	x0, [x28, #5152]
    6ee8:	eb01001f 	cmp	x0, x1
    6eec:	54000049 	b.ls	6ef4 <fwp_main_thread+0x814>  // b.plast
    6ef0:	f90a1780 	str	x0, [x28, #5160]
    6ef4:	1e630361 	ucvtf	d1, w27
    6ef8:	fd4a1f80 	ldr	d0, [x28, #5176]
    6efc:	1e612800 	fadd	d0, d0, d1
    6f00:	fd0a1f80 	str	d0, [x28, #5176]
    6f04:	aa1a03fb 	mov	x27, x26
    6f08:	aa1803e1 	mov	x1, x24
    6f0c:	aa1903e2 	mov	x2, x25
    6f10:	f8008779 	str	x25, [x27], #8
    6f14:	aa1b03e0 	mov	x0, x27
    6f18:	97ffe90e 	bl	1350 <memcpy@plt>
    6f1c:	8b190343 	add	x3, x26, x25
    6f20:	3900207f 	strb	wzr, [x3, #8]
    6f24:	f94023e0 	ldr	x0, [sp, #64]
    6f28:	97ffe9a2 	bl	15b0 <free@plt>
    6f2c:	f949db81 	ldr	x1, [x28, #5040]
    6f30:	f949ef80 	ldr	x0, [x28, #5080]
    6f34:	cb010341 	sub	x1, x26, x1
    6f38:	eb00403f 	cmp	x1, x0, lsl #16
    6f3c:	54000322 	b.cs	6fa0 <fwp_main_thread+0x8c0>  // b.hs, b.nlast
    6f40:	d350fc20 	lsr	x0, x1, #16
    6f44:	f949ff87 	ldr	x7, [x28, #5112]
    6f48:	8b000800 	add	x0, x0, x0, lsl #2
    6f4c:	d37df002 	lsl	x2, x0, #3
    6f50:	8b0200e3 	add	x3, x7, x2
    6f54:	f9401060 	ldr	x0, [x3, #32]
    6f58:	b4000240 	cbz	x0, 6fa0 <fwp_main_thread+0x8c0>
    6f5c:	386268e2 	ldrb	w2, [x7, x2]
    6f60:	7100085f 	cmp	w2, #0x2
    6f64:	54000e40 	b.eq	712c <fwp_main_thread+0xa4c>  // b.none
    6f68:	7100045f 	cmp	w2, #0x1
    6f6c:	540001a1 	b.ne	6fa0 <fwp_main_thread+0x8c0>  // b.any
    6f70:	29430867 	ldp	w7, w2, [x3, #24]
    6f74:	92403c21 	and	x1, x1, #0xffff
    6f78:	9b077c21 	mul	x1, x1, x7
    6f7c:	d360fc21 	lsr	x1, x1, #32
    6f80:	eb02003f 	cmp	x1, x2
    6f84:	540000e2 	b.cs	6fa0 <fwp_main_thread+0x8c0>  // b.hs, b.nlast
    6f88:	8b010000 	add	x0, x0, x1
    6f8c:	39400001 	ldrb	w1, [x0]
    6f90:	7103fc3f 	cmp	w1, #0xff
    6f94:	54001340 	b.eq	71fc <fwp_main_thread+0xb1c>  // b.none
    6f98:	52800021 	mov	w1, #0x1                   	// #1
    6f9c:	39000001 	strb	w1, [x0]
    6fa0:	aa1503e0 	mov	x0, x21
    6fa4:	97fff62f 	bl	4860 <fwp_drop0>
    6fa8:	f9400342 	ldr	x2, [x26]
    6fac:	d2800021 	mov	x1, #0x1                   	// #1
    6fb0:	f9401a83 	ldr	x3, [x20, #48]
    6fb4:	aa1b03e0 	mov	x0, x27
    6fb8:	97ffe98e 	bl	15f0 <fwrite@plt>
    6fbc:	f9401a81 	ldr	x1, [x20, #48]
    6fc0:	52800140 	mov	w0, #0xa                   	// #10
    6fc4:	97ffe913 	bl	1410 <fputc@plt>
    6fc8:	aa1a03e0 	mov	x0, x26
    6fcc:	97fff485 	bl	41e0 <fwp_drop4>
    6fd0:	f9400ad6 	ldr	x22, [x22, #16]
    6fd4:	b4000b96 	cbz	x22, 7144 <fwp_main_thread+0xa64>
    6fd8:	f949db81 	ldr	x1, [x28, #5040]
    6fdc:	f949ef80 	ldr	x0, [x28, #5080]
    6fe0:	cb0102e1 	sub	x1, x23, x1
    6fe4:	eb00403f 	cmp	x1, x0, lsl #16
    6fe8:	54000342 	b.cs	7050 <fwp_main_thread+0x970>  // b.hs, b.nlast
    6fec:	d350fc20 	lsr	x0, x1, #16
    6ff0:	f949ff85 	ldr	x5, [x28, #5112]
    6ff4:	8b000800 	add	x0, x0, x0, lsl #2
    6ff8:	d37df002 	lsl	x2, x0, #3
    6ffc:	8b0200a3 	add	x3, x5, x2
    7000:	f9401060 	ldr	x0, [x3, #32]
    7004:	b4000260 	cbz	x0, 7050 <fwp_main_thread+0x970>
    7008:	386268a2 	ldrb	w2, [x5, x2]
    700c:	7100085f 	cmp	w2, #0x2
    7010:	54000940 	b.eq	7138 <fwp_main_thread+0xa58>  // b.none
    7014:	7100045f 	cmp	w2, #0x1
    7018:	540001c1 	b.ne	7050 <fwp_main_thread+0x970>  // b.any
    701c:	29430865 	ldp	w5, w2, [x3, #24]
    7020:	92403c21 	and	x1, x1, #0xffff
    7024:	9b057c21 	mul	x1, x1, x5
    7028:	d360fc21 	lsr	x1, x1, #32
    702c:	eb02003f 	cmp	x1, x2
    7030:	54000102 	b.cs	7050 <fwp_main_thread+0x970>  // b.hs, b.nlast
    7034:	8b010000 	add	x0, x0, x1
    7038:	39400001 	ldrb	w1, [x0]
    703c:	340000a1 	cbz	w1, 7050 <fwp_main_thread+0x970>
    7040:	7103f43f 	cmp	w1, #0xfd
    7044:	54000e48 	b.hi	720c <fwp_main_thread+0xb2c>  // b.pmore
    7048:	11000421 	add	w1, w1, #0x1
    704c:	39000001 	strb	w1, [x0]
    7050:	aa1703e0 	mov	x0, x23
    7054:	97fff678 	bl	4a34 <fwp_loop_fields68.constprop.0>
    7058:	aa0003e1 	mov	x1, x0
    705c:	aa0003f5 	mov	x21, x0
    7060:	a9400be0 	ldp	x0, x2, [sp]
    7064:	52800023 	mov	w3, #0x1                   	// #1
    7068:	a9047fff 	stp	xzr, xzr, [sp, #64]
    706c:	f9002bff 	str	xzr, [sp, #80]
    7070:	97fff9a1 	bl	56f4 <fwp_write>
    7074:	a94467f8 	ldp	x24, x25, [sp, #64]
    7078:	f9400be0 	ldr	x0, [sp, #16]
    707c:	f100031f 	cmp	x24, #0x0
    7080:	9a980018 	csel	x24, x0, x24, eq	// eq = none
    7084:	b1002b3f 	cmn	x25, #0xa
    7088:	54000ea8 	b.hi	725c <fwp_main_thread+0xb7c>  // b.pmore
    708c:	b953a780 	ldr	w0, [x28, #5028]
    7090:	91002722 	add	x2, x25, #0x9
    7094:	f140105f 	cmp	x2, #0x4, lsl #12
    7098:	7a409804 	ccmp	w0, #0x0, #0x4, ls	// ls = plast
    709c:	54000220 	b.eq	70e0 <fwp_main_thread+0xa00>  // b.none
    70a0:	91006321 	add	x1, x25, #0x18
    70a4:	8b411381 	add	x1, x28, x1, lsr #4
    70a8:	397e8021 	ldrb	w1, [x1, #4000]
    70ac:	910f0020 	add	x0, x1, #0x3c0
    70b0:	8b010421 	add	x1, x1, x1, lsl #1
    70b4:	8b010f86 	add	x6, x28, x1, lsl #3
    70b8:	b8607b9b 	ldr	w27, [x28, x0, lsl #2]
    70bc:	2a1b03e8 	mov	w8, w27
    70c0:	f941e0da 	ldr	x26, [x6, #960]
    70c4:	b5ffef9a 	cbnz	x26, 6eb4 <fwp_main_thread+0x7d4>
    70c8:	f941e4da 	ldr	x26, [x6, #968]
    70cc:	b40000ba 	cbz	x26, 70e0 <fwp_main_thread+0xa00>
    70d0:	f941e8c0 	ldr	x0, [x6, #976]
    70d4:	cb1a0000 	sub	x0, x0, x26
    70d8:	eb00011f 	cmp	x8, x0
    70dc:	54000489 	b.ls	716c <fwp_main_thread+0xa8c>  // b.plast
    70e0:	aa0203e0 	mov	x0, x2
    70e4:	52800021 	mov	w1, #0x1                   	// #1
    70e8:	97fff082 	bl	32f0 <fwp_heap_alloc_slow>
    70ec:	aa0003fa 	mov	x26, x0
    70f0:	17ffff85 	b	6f04 <fwp_main_thread+0x824>
    70f4:	72003c3f 	tst	w1, #0xffff
    70f8:	54ffdd81 	b.ne	6ca8 <fwp_main_thread+0x5c8>  // b.any
    70fc:	39400380 	ldrb	w0, [x28]
    7100:	7103fc1f 	cmp	w0, #0xff
    7104:	54ffdd01 	b.ne	6ca4 <fwp_main_thread+0x5c4>  // b.any
    7108:	aa1c03e0 	mov	x0, x28
    710c:	97ffef11 	bl	2d50 <fwp_rc_forget_slot>
    7110:	17fffee5 	b	6ca4 <fwp_main_thread+0x5c4>
    7114:	f0ffffc0 	adrp	x0, 2000 <buf_put+0x50>
    7118:	91184000 	add	x0, x0, #0x610
    711c:	94000211 	bl	7960 <atexit>
    7120:	17fffd83 	b	672c <fwp_main_thread+0x4c>
    7124:	97ffed94 	bl	2774 <fwp_heap_init>
    7128:	17fffd7d 	b	671c <fwp_main_thread+0x3c>
    712c:	72003c3f 	tst	w1, #0xffff
    7130:	54fff381 	b.ne	6fa0 <fwp_main_thread+0x8c0>  // b.any
    7134:	17ffff96 	b	6f8c <fwp_main_thread+0x8ac>
    7138:	72003c3f 	tst	w1, #0xffff
    713c:	54fff8a1 	b.ne	7050 <fwp_main_thread+0x970>  // b.any
    7140:	17ffffbe 	b	7038 <fwp_main_thread+0x958>
    7144:	aa1703e0 	mov	x0, x23
    7148:	97fff5c6 	bl	4860 <fwp_drop0>
    714c:	aa1303e0 	mov	x0, x19
    7150:	97fff5c4 	bl	4860 <fwp_drop0>
    7154:	9100c280 	add	x0, x20, #0x30
    7158:	52800021 	mov	w1, #0x1                   	// #1
    715c:	a9566bf9 	ldp	x25, x26, [sp, #352]
    7160:	b9029401 	str	w1, [x0, #660]
    7164:	f9014c1f 	str	xzr, [x0, #664]
    7168:	17fffd9e 	b	67e0 <fwp_main_thread+0x100>
    716c:	8b080340 	add	x0, x26, x8
    7170:	52800001 	mov	w1, #0x0                   	// #0
    7174:	f9000fe8 	str	x8, [sp, #24]
    7178:	f901e4c0 	str	x0, [x6, #968]
    717c:	aa1a03e0 	mov	x0, x26
    7180:	97ffe8d0 	bl	14c0 <memset@plt>
    7184:	f9400fe8 	ldr	x8, [sp, #24]
    7188:	f94a1380 	ldr	x0, [x28, #5152]
    718c:	ab080000 	adds	x0, x0, x8
    7190:	54000642 	b.cs	7258 <fwp_main_thread+0xb78>  // b.hs, b.nlast
    7194:	d0000141 	adrp	x1, 31000 <fwp_root_context+0xd10>
    7198:	91134021 	add	x1, x1, #0x4d0
    719c:	f94a1422 	ldr	x2, [x1, #5160]
    71a0:	f90a1020 	str	x0, [x1, #5152]
    71a4:	eb02001f 	cmp	x0, x2
    71a8:	54000049 	b.ls	71b0 <fwp_main_thread+0xad0>  // b.plast
    71ac:	f90a1420 	str	x0, [x1, #5160]
    71b0:	d0000140 	adrp	x0, 31000 <fwp_root_context+0xd10>
    71b4:	91134000 	add	x0, x0, #0x4d0
    71b8:	1e630361 	ucvtf	d1, w27
    71bc:	fd4a1c00 	ldr	d0, [x0, #5176]
    71c0:	1e612800 	fadd	d0, d0, d1
    71c4:	fd0a1c00 	str	d0, [x0, #5176]
    71c8:	17ffff4f 	b	6f04 <fwp_main_thread+0x824>
    71cc:	aa0003e1 	mov	x1, x0
    71d0:	f90022b3 	str	x19, [x21, #64]
    71d4:	17fffd9c 	b	6844 <fwp_main_thread+0x164>
    71d8:	72003c3f 	tst	w1, #0xffff
    71dc:	54ffdbe1 	b.ne	6d58 <fwp_main_thread+0x678>  // b.any
    71e0:	17fffed9 	b	6d44 <fwp_main_thread+0x664>
    71e4:	72003c3f 	tst	w1, #0xffff
    71e8:	54ffe4e1 	b.ne	6e84 <fwp_main_thread+0x7a4>  // b.any
    71ec:	17ffff21 	b	6e70 <fwp_main_thread+0x790>
    71f0:	72003c3f 	tst	w1, #0xffff
    71f4:	54ffdfc1 	b.ne	6dec <fwp_main_thread+0x70c>  // b.any
    71f8:	17fffef8 	b	6dd8 <fwp_main_thread+0x6f8>
    71fc:	f9000fe0 	str	x0, [sp, #24]
    7200:	97ffeed4 	bl	2d50 <fwp_rc_forget_slot>
    7204:	f9400fe0 	ldr	x0, [sp, #24]
    7208:	17ffff64 	b	6f98 <fwp_main_thread+0x8b8>
    720c:	97ffee8a 	bl	2c34 <fwp_rc_wide_dup>
    7210:	17ffff90 	b	7050 <fwp_main_thread+0x970>
    7214:	b902a2bf 	str	wzr, [x21, #672]
    7218:	b4ffc000 	cbz	x0, 6a18 <fwp_main_thread+0x338>
    721c:	17fffe69 	b	6bc0 <fwp_main_thread+0x4e0>
    7220:	aa1503e0 	mov	x0, x21
    7224:	97ffeecb 	bl	2d50 <fwp_rc_forget_slot>
    7228:	17ffff15 	b	6e7c <fwp_main_thread+0x79c>
    722c:	aa1703e0 	mov	x0, x23
    7230:	97ffeec8 	bl	2d50 <fwp_rc_forget_slot>
    7234:	17fffec7 	b	6d50 <fwp_main_thread+0x670>
    7238:	aa1603e0 	mov	x0, x22
    723c:	97ffeec5 	bl	2d50 <fwp_rc_forget_slot>
    7240:	17fffee9 	b	6de4 <fwp_main_thread+0x704>
    7244:	90000000 	adrp	x0, 7000 <fwp_main_thread+0x920>
    7248:	91342000 	add	x0, x0, #0xd08
    724c:	a91563f7 	stp	x23, x24, [sp, #336]
    7250:	a9166bf9 	stp	x25, x26, [sp, #352]
    7254:	97ffebb3 	bl	2120 <fwp_trap>
    7258:	97ffea6e 	bl	1c10 <fwp_heap_oom>
    725c:	90000000 	adrp	x0, 7000 <fwp_main_thread+0x920>
    7260:	9134c000 	add	x0, x0, #0xd30
    7264:	97ffebaf 	bl	2120 <fwp_trap>
    7268:	a9166bf9 	stp	x25, x26, [sp, #352]
    726c:	97ffe8a1 	bl	14f0 <__stack_chk_fail@plt>

0000000000007270 <__divti3>:
    7270:	d503245f 	bti	c
    7274:	d2800004 	mov	x4, #0x0                   	// #0
    7278:	b7f80721 	tbnz	x1, #63, 735c <__divti3+0xec>
    727c:	b6f80083 	tbz	x3, #63, 728c <__divti3+0x1c>
    7280:	eb0203e2 	negs	x2, x2
    7284:	aa2403e4 	mvn	x4, x4
    7288:	da0303e3 	ngc	x3, x3
    728c:	aa0203e6 	mov	x6, x2
    7290:	aa0003e7 	mov	x7, x0
    7294:	aa0103e5 	mov	x5, x1
    7298:	b5000583 	cbnz	x3, 7348 <__divti3+0xd8>
    729c:	eb01005f 	cmp	x2, x1
    72a0:	54000e69 	b.ls	746c <__divti3+0x1fc>  // b.plast
    72a4:	dac01040 	clz	x0, x2
    72a8:	b40000e0 	cbz	x0, 72c4 <__divti3+0x54>
    72ac:	4b0003e1 	neg	w1, w0
    72b0:	9ac020a5 	lsl	x5, x5, x0
    72b4:	9ac02046 	lsl	x6, x2, x0
    72b8:	9ac124e1 	lsr	x1, x7, x1
    72bc:	aa050025 	orr	x5, x1, x5
    72c0:	9ac020e7 	lsl	x7, x7, x0
    72c4:	d360fcc8 	lsr	x8, x6, #32
    72c8:	92407cc2 	and	x2, x6, #0xffffffff
    72cc:	9ac808a3 	udiv	x3, x5, x8
    72d0:	9b089465 	msub	x5, x3, x8, x5
    72d4:	aa0303e0 	mov	x0, x3
    72d8:	9b037c41 	mul	x1, x2, x3
    72dc:	93c780a5 	extr	x5, x5, x7, #32
    72e0:	eb05003f 	cmp	x1, x5
    72e4:	540000a9 	b.ls	72f8 <__divti3+0x88>  // b.plast
    72e8:	ab0500c5 	adds	x5, x6, x5
    72ec:	d1000460 	sub	x0, x3, #0x1
    72f0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    72f4:	540015a8 	b.hi	75a8 <__divti3+0x338>  // b.pmore
    72f8:	cb0100a5 	sub	x5, x5, x1
    72fc:	9ac808a3 	udiv	x3, x5, x8
    7300:	9b089465 	msub	x5, x3, x8, x5
    7304:	aa0303e1 	mov	x1, x3
    7308:	9b037c42 	mul	x2, x2, x3
    730c:	aa0703e3 	mov	x3, x7
    7310:	b3607ca3 	bfi	x3, x5, #32, #32
    7314:	eb03005f 	cmp	x2, x3
    7318:	540000c9 	b.ls	7330 <__divti3+0xc0>  // b.plast
    731c:	ab0300c3 	adds	x3, x6, x3
    7320:	d1000425 	sub	x5, x1, #0x1
    7324:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    7328:	d1000821 	sub	x1, x1, #0x2
    732c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    7330:	aa008020 	orr	x0, x1, x0, lsl #32
    7334:	d2800001 	mov	x1, #0x0                   	// #0
    7338:	b4000064 	cbz	x4, 7344 <__divti3+0xd4>
    733c:	eb0003e0 	negs	x0, x0
    7340:	da0103e1 	ngc	x1, x1
    7344:	d65f03c0 	ret
    7348:	eb01007f 	cmp	x3, x1
    734c:	54000109 	b.ls	736c <__divti3+0xfc>  // b.plast
    7350:	d2800001 	mov	x1, #0x0                   	// #0
    7354:	d2800000 	mov	x0, #0x0                   	// #0
    7358:	17fffff8 	b	7338 <__divti3+0xc8>
    735c:	eb0003e0 	negs	x0, x0
    7360:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    7364:	da0103e1 	ngc	x1, x1
    7368:	17ffffc5 	b	727c <__divti3+0xc>
    736c:	dac01067 	clz	x7, x3
    7370:	b40010e7 	cbz	x7, 758c <__divti3+0x31c>
    7374:	d2800805 	mov	x5, #0x40                  	// #64
    7378:	cb0700a5 	sub	x5, x5, x7
    737c:	9ac72063 	lsl	x3, x3, x7
    7380:	9ac52448 	lsr	x8, x2, x5
    7384:	aa030108 	orr	x8, x8, x3
    7388:	9ac52426 	lsr	x6, x1, x5
    738c:	92407d0a 	and	x10, x8, #0xffffffff
    7390:	d360fd09 	lsr	x9, x8, #32
    7394:	9ac52403 	lsr	x3, x0, x5
    7398:	9ac72021 	lsl	x1, x1, x7
    739c:	aa010063 	orr	x3, x3, x1
    73a0:	9ac72042 	lsl	x2, x2, x7
    73a4:	9ac908cb 	udiv	x11, x6, x9
    73a8:	9b099965 	msub	x5, x11, x9, x6
    73ac:	aa0b03e1 	mov	x1, x11
    73b0:	9b0b7d46 	mul	x6, x10, x11
    73b4:	93c380a5 	extr	x5, x5, x3, #32
    73b8:	eb0500df 	cmp	x6, x5
    73bc:	540000a9 	b.ls	73d0 <__divti3+0x160>  // b.plast
    73c0:	ab050105 	adds	x5, x8, x5
    73c4:	d1000561 	sub	x1, x11, #0x1
    73c8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    73cc:	54000f48 	b.hi	75b4 <__divti3+0x344>  // b.pmore
    73d0:	cb0600a6 	sub	x6, x5, x6
    73d4:	9ac908cb 	udiv	x11, x6, x9
    73d8:	9b099969 	msub	x9, x11, x9, x6
    73dc:	aa0b03e5 	mov	x5, x11
    73e0:	9b0b7d4a 	mul	x10, x10, x11
    73e4:	b3607d23 	bfi	x3, x9, #32, #32
    73e8:	eb03015f 	cmp	x10, x3
    73ec:	540000a9 	b.ls	7400 <__divti3+0x190>  // b.plast
    73f0:	ab030103 	adds	x3, x8, x3
    73f4:	d1000565 	sub	x5, x11, #0x1
    73f8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    73fc:	54000e28 	b.hi	75c0 <__divti3+0x350>  // b.pmore
    7400:	aa0180a1 	orr	x1, x5, x1, lsl #32
    7404:	92407c48 	and	x8, x2, #0xffffffff
    7408:	2a0503e5 	mov	w5, w5
    740c:	d360fc42 	lsr	x2, x2, #32
    7410:	d360fc26 	lsr	x6, x1, #32
    7414:	cb0a0063 	sub	x3, x3, x10
    7418:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    741c:	9b087caa 	mul	x10, x5, x8
    7420:	9b087cc8 	mul	x8, x6, x8
    7424:	9b0220a5 	madd	x5, x5, x2, x8
    7428:	9b027cc6 	mul	x6, x6, x2
    742c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    7430:	8b0900c5 	add	x5, x6, x9
    7434:	eb02011f 	cmp	x8, x2
    7438:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    743c:	8b4280c6 	add	x6, x6, x2, lsr #32
    7440:	eb06007f 	cmp	x3, x6
    7444:	540000e3 	b.cc	7460 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    7448:	92407d4a 	and	x10, x10, #0xffffffff
    744c:	9ac72000 	lsl	x0, x0, x7
    7450:	8b028142 	add	x2, x10, x2, lsl #32
    7454:	eb02001f 	cmp	x0, x2
    7458:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    745c:	54000a01 	b.ne	759c <__divti3+0x32c>  // b.any
    7460:	d1000420 	sub	x0, x1, #0x1
    7464:	d2800001 	mov	x1, #0x0                   	// #0
    7468:	17ffffb4 	b	7338 <__divti3+0xc8>
    746c:	b5000062 	cbnz	x2, 7478 <__divti3+0x208>
    7470:	d2800022 	mov	x2, #0x1                   	// #1
    7474:	9ac30846 	udiv	x6, x2, x3
    7478:	dac010c8 	clz	x8, x6
    747c:	b5000408 	cbnz	x8, 74fc <__divti3+0x28c>
    7480:	d360fcc9 	lsr	x9, x6, #32
    7484:	92407cc5 	and	x5, x6, #0xffffffff
    7488:	cb060023 	sub	x3, x1, x6
    748c:	d2800021 	mov	x1, #0x1                   	// #1
    7490:	9ac90868 	udiv	x8, x3, x9
    7494:	9b098d03 	msub	x3, x8, x9, x3
    7498:	aa0803e0 	mov	x0, x8
    749c:	9b057d02 	mul	x2, x8, x5
    74a0:	93c78063 	extr	x3, x3, x7, #32
    74a4:	eb03005f 	cmp	x2, x3
    74a8:	540000a9 	b.ls	74bc <__divti3+0x24c>  // b.plast
    74ac:	ab0300c3 	adds	x3, x6, x3
    74b0:	d1000500 	sub	x0, x8, #0x1
    74b4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    74b8:	54000968 	b.hi	75e4 <__divti3+0x374>  // b.pmore
    74bc:	cb020063 	sub	x3, x3, x2
    74c0:	9ac90862 	udiv	x2, x3, x9
    74c4:	aa0203e8 	mov	x8, x2
    74c8:	9b098c42 	msub	x2, x2, x9, x3
    74cc:	aa0703e3 	mov	x3, x7
    74d0:	9b057d05 	mul	x5, x8, x5
    74d4:	b3607c43 	bfi	x3, x2, #32, #32
    74d8:	eb0300bf 	cmp	x5, x3
    74dc:	540000c9 	b.ls	74f4 <__divti3+0x284>  // b.plast
    74e0:	ab0300c2 	adds	x2, x6, x3
    74e4:	d1000503 	sub	x3, x8, #0x1
    74e8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    74ec:	d1000908 	sub	x8, x8, #0x2
    74f0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    74f4:	aa008100 	orr	x0, x8, x0, lsl #32
    74f8:	17ffff90 	b	7338 <__divti3+0xc8>
    74fc:	9ac820c6 	lsl	x6, x6, x8
    7500:	d2800803 	mov	x3, #0x40                  	// #64
    7504:	cb080063 	sub	x3, x3, x8
    7508:	d360fcc9 	lsr	x9, x6, #32
    750c:	9ac82027 	lsl	x7, x1, x8
    7510:	92407cc5 	and	x5, x6, #0xffffffff
    7514:	9ac32422 	lsr	x2, x1, x3
    7518:	9ac32403 	lsr	x3, x0, x3
    751c:	aa070063 	orr	x3, x3, x7
    7520:	9ac9084a 	udiv	x10, x2, x9
    7524:	9ac82007 	lsl	x7, x0, x8
    7528:	9b098940 	msub	x0, x10, x9, x2
    752c:	aa0a03e1 	mov	x1, x10
    7530:	9b0a7ca2 	mul	x2, x5, x10
    7534:	93c38000 	extr	x0, x0, x3, #32
    7538:	eb00005f 	cmp	x2, x0
    753c:	540000a9 	b.ls	7550 <__divti3+0x2e0>  // b.plast
    7540:	ab0000c0 	adds	x0, x6, x0
    7544:	d1000541 	sub	x1, x10, #0x1
    7548:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    754c:	54000468 	b.hi	75d8 <__divti3+0x368>  // b.pmore
    7550:	cb020000 	sub	x0, x0, x2
    7554:	9ac9080a 	udiv	x10, x0, x9
    7558:	9b098140 	msub	x0, x10, x9, x0
    755c:	aa0a03e2 	mov	x2, x10
    7560:	9b0a7ca8 	mul	x8, x5, x10
    7564:	b3607c03 	bfi	x3, x0, #32, #32
    7568:	eb03011f 	cmp	x8, x3
    756c:	540000a9 	b.ls	7580 <__divti3+0x310>  // b.plast
    7570:	ab0300c3 	adds	x3, x6, x3
    7574:	d1000542 	sub	x2, x10, #0x1
    7578:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    757c:	54000288 	b.hi	75cc <__divti3+0x35c>  // b.pmore
    7580:	cb080063 	sub	x3, x3, x8
    7584:	aa018041 	orr	x1, x2, x1, lsl #32
    7588:	17ffffc2 	b	7490 <__divti3+0x220>
    758c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    7590:	d2800001 	mov	x1, #0x0                   	// #0
    7594:	9a9f87e0 	cset	x0, ls	// ls = plast
    7598:	17ffff68 	b	7338 <__divti3+0xc8>
    759c:	aa0103e0 	mov	x0, x1
    75a0:	d2800001 	mov	x1, #0x0                   	// #0
    75a4:	17ffff65 	b	7338 <__divti3+0xc8>
    75a8:	d1000860 	sub	x0, x3, #0x2
    75ac:	8b0600a5 	add	x5, x5, x6
    75b0:	17ffff52 	b	72f8 <__divti3+0x88>
    75b4:	d1000961 	sub	x1, x11, #0x2
    75b8:	8b0800a5 	add	x5, x5, x8
    75bc:	17ffff85 	b	73d0 <__divti3+0x160>
    75c0:	d1000965 	sub	x5, x11, #0x2
    75c4:	8b080063 	add	x3, x3, x8
    75c8:	17ffff8e 	b	7400 <__divti3+0x190>
    75cc:	d1000942 	sub	x2, x10, #0x2
    75d0:	8b060063 	add	x3, x3, x6
    75d4:	17ffffeb 	b	7580 <__divti3+0x310>
    75d8:	d1000941 	sub	x1, x10, #0x2
    75dc:	8b060000 	add	x0, x0, x6
    75e0:	17ffffdc 	b	7550 <__divti3+0x2e0>
    75e4:	d1000900 	sub	x0, x8, #0x2
    75e8:	8b060063 	add	x3, x3, x6
    75ec:	17ffffb4 	b	74bc <__divti3+0x24c>

00000000000075f0 <__modti3>:
    75f0:	d503245f 	bti	c
    75f4:	d2800004 	mov	x4, #0x0                   	// #0
    75f8:	b6f80081 	tbz	x1, #63, 7608 <__modti3+0x18>
    75fc:	eb0003e0 	negs	x0, x0
    7600:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    7604:	da0103e1 	ngc	x1, x1
    7608:	f100007f 	cmp	x3, #0x0
    760c:	5400128b 	b.lt	785c <__modti3+0x26c>  // b.tstop
    7610:	aa0003e7 	mov	x7, x0
    7614:	aa0103e6 	mov	x6, x1
    7618:	540004e1 	b.ne	76b4 <__modti3+0xc4>  // b.any
    761c:	eb02003f 	cmp	x1, x2
    7620:	54000dc2 	b.cs	77d8 <__modti3+0x1e8>  // b.hs, b.nlast
    7624:	dac01043 	clz	x3, x2
    7628:	aa0303e5 	mov	x5, x3
    762c:	b40000e3 	cbz	x3, 7648 <__modti3+0x58>
    7630:	4b0303e6 	neg	w6, w3
    7634:	9ac32021 	lsl	x1, x1, x3
    7638:	9ac32042 	lsl	x2, x2, x3
    763c:	9ac62406 	lsr	x6, x0, x6
    7640:	aa0100c6 	orr	x6, x6, x1
    7644:	9ac32007 	lsl	x7, x0, x3
    7648:	d360fc40 	lsr	x0, x2, #32
    764c:	92407c43 	and	x3, x2, #0xffffffff
    7650:	9ac008c1 	udiv	x1, x6, x0
    7654:	9b009826 	msub	x6, x1, x0, x6
    7658:	9b017c61 	mul	x1, x3, x1
    765c:	93c780c6 	extr	x6, x6, x7, #32
    7660:	eb06003f 	cmp	x1, x6
    7664:	540000a9 	b.ls	7678 <__modti3+0x88>  // b.plast
    7668:	ab060046 	adds	x6, x2, x6
    766c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    7670:	8b0200c8 	add	x8, x6, x2
    7674:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    7678:	cb0100c6 	sub	x6, x6, x1
    767c:	9ac008c8 	udiv	x8, x6, x0
    7680:	9b009901 	msub	x1, x8, x0, x6
    7684:	aa0703e0 	mov	x0, x7
    7688:	9b087c63 	mul	x3, x3, x8
    768c:	b3607c20 	bfi	x0, x1, #32, #32
    7690:	eb00007f 	cmp	x3, x0
    7694:	54001088 	b.hi	78a4 <__modti3+0x2b4>  // b.pmore
    7698:	cb030000 	sub	x0, x0, x3
    769c:	9ac52400 	lsr	x0, x0, x5
    76a0:	d2800001 	mov	x1, #0x0                   	// #0
    76a4:	b4000064 	cbz	x4, 76b0 <__modti3+0xc0>
    76a8:	eb0003e0 	negs	x0, x0
    76ac:	da0103e1 	ngc	x1, x1
    76b0:	d65f03c0 	ret
    76b4:	dac01066 	clz	x6, x3
    76b8:	eb03003f 	cmp	x1, x3
    76bc:	54ffff43 	b.cc	76a4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    76c0:	93407cc5 	sxtw	x5, w6
    76c4:	d2800808 	mov	x8, #0x40                  	// #64
    76c8:	cb050108 	sub	x8, x8, x5
    76cc:	9ac62063 	lsl	x3, x3, x6
    76d0:	9ac62025 	lsl	x5, x1, x6
    76d4:	9ac82447 	lsr	x7, x2, x8
    76d8:	aa0300e7 	orr	x7, x7, x3
    76dc:	9ac82423 	lsr	x3, x1, x8
    76e0:	92407cec 	and	x12, x7, #0xffffffff
    76e4:	d360fcea 	lsr	x10, x7, #32
    76e8:	9ac82401 	lsr	x1, x0, x8
    76ec:	aa050021 	orr	x1, x1, x5
    76f0:	9ac62042 	lsl	x2, x2, x6
    76f4:	9ac62000 	lsl	x0, x0, x6
    76f8:	9aca086b 	udiv	x11, x3, x10
    76fc:	9b0a8d63 	msub	x3, x11, x10, x3
    7700:	aa0b03e5 	mov	x5, x11
    7704:	9b0b7d89 	mul	x9, x12, x11
    7708:	93c18063 	extr	x3, x3, x1, #32
    770c:	eb03013f 	cmp	x9, x3
    7710:	540000a9 	b.ls	7724 <__modti3+0x134>  // b.plast
    7714:	ab0300e3 	adds	x3, x7, x3
    7718:	d1000565 	sub	x5, x11, #0x1
    771c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    7720:	54001168 	b.hi	794c <__modti3+0x35c>  // b.pmore
    7724:	cb090063 	sub	x3, x3, x9
    7728:	9aca086b 	udiv	x11, x3, x10
    772c:	9b0a8d6a 	msub	x10, x11, x10, x3
    7730:	aa0b03e9 	mov	x9, x11
    7734:	9b0b7d8c 	mul	x12, x12, x11
    7738:	b3607d41 	bfi	x1, x10, #32, #32
    773c:	eb01019f 	cmp	x12, x1
    7740:	540000a9 	b.ls	7754 <__modti3+0x164>  // b.plast
    7744:	ab0100e1 	adds	x1, x7, x1
    7748:	d1000569 	sub	x9, x11, #0x1
    774c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    7750:	54000f88 	b.hi	7940 <__modti3+0x350>  // b.pmore
    7754:	aa058123 	orr	x3, x9, x5, lsl #32
    7758:	92407c4b 	and	x11, x2, #0xffffffff
    775c:	2a0903e9 	mov	w9, w9
    7760:	d360fc4a 	lsr	x10, x2, #32
    7764:	d360fc63 	lsr	x3, x3, #32
    7768:	cb0c0021 	sub	x1, x1, x12
    776c:	aa0a03ec 	mov	x12, x10
    7770:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    7774:	9b0b7d25 	mul	x5, x9, x11
    7778:	9b0b7c6b 	mul	x11, x3, x11
    777c:	9b0a2d29 	madd	x9, x9, x10, x11
    7780:	92407caa 	and	x10, x5, #0xffffffff
    7784:	9b0c7c63 	mul	x3, x3, x12
    7788:	8b458125 	add	x5, x9, x5, lsr #32
    778c:	8b0d0069 	add	x9, x3, x13
    7790:	eb05017f 	cmp	x11, x5
    7794:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    7798:	8b058149 	add	x9, x10, x5, lsl #32
    779c:	8b458063 	add	x3, x3, x5, lsr #32
    77a0:	eb03003f 	cmp	x1, x3
    77a4:	54000063 	b.cc	77b0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    77a8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    77ac:	54000082 	b.cs	77bc <__modti3+0x1cc>  // b.hs, b.nlast
    77b0:	eb020129 	subs	x9, x9, x2
    77b4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    77b8:	cb070063 	sub	x3, x3, x7
    77bc:	eb090000 	subs	x0, x0, x9
    77c0:	da030021 	sbc	x1, x1, x3
    77c4:	9ac62400 	lsr	x0, x0, x6
    77c8:	9ac82028 	lsl	x8, x1, x8
    77cc:	aa000100 	orr	x0, x8, x0
    77d0:	9ac62421 	lsr	x1, x1, x6
    77d4:	17ffffb4 	b	76a4 <__modti3+0xb4>
    77d8:	b5000062 	cbnz	x2, 77e4 <__modti3+0x1f4>
    77dc:	d2800023 	mov	x3, #0x1                   	// #1
    77e0:	9ac20862 	udiv	x2, x3, x2
    77e4:	dac01048 	clz	x8, x2
    77e8:	aa0803e5 	mov	x5, x8
    77ec:	b5000668 	cbnz	x8, 78b8 <__modti3+0x2c8>
    77f0:	cb020020 	sub	x0, x1, x2
    77f4:	d360fc49 	lsr	x9, x2, #32
    77f8:	92407c4a 	and	x10, x2, #0xffffffff
    77fc:	9ac90801 	udiv	x1, x0, x9
    7800:	9b098020 	msub	x0, x1, x9, x0
    7804:	9b0a7c21 	mul	x1, x1, x10
    7808:	93c78000 	extr	x0, x0, x7, #32
    780c:	eb00003f 	cmp	x1, x0
    7810:	540000a9 	b.ls	7824 <__modti3+0x234>  // b.plast
    7814:	ab000040 	adds	x0, x2, x0
    7818:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    781c:	8b020003 	add	x3, x0, x2
    7820:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    7824:	cb010001 	sub	x1, x0, x1
    7828:	9ac90820 	udiv	x0, x1, x9
    782c:	9b098403 	msub	x3, x0, x9, x1
    7830:	aa0703e1 	mov	x1, x7
    7834:	9b0a7c00 	mul	x0, x0, x10
    7838:	b3607c61 	bfi	x1, x3, #32, #32
    783c:	eb01001f 	cmp	x0, x1
    7840:	540000a9 	b.ls	7854 <__modti3+0x264>  // b.plast
    7844:	ab010041 	adds	x1, x2, x1
    7848:	8b020022 	add	x2, x1, x2
    784c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    7850:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    7854:	cb000020 	sub	x0, x1, x0
    7858:	17ffff91 	b	769c <__modti3+0xac>
    785c:	eb0203e5 	negs	x5, x2
    7860:	aa0003e7 	mov	x7, x0
    7864:	da0303e8 	ngc	x8, x3
    7868:	aa0503e2 	mov	x2, x5
    786c:	aa0803e3 	mov	x3, x8
    7870:	aa0103e6 	mov	x6, x1
    7874:	b4ffed48 	cbz	x8, 761c <__modti3+0x2c>
    7878:	eb01011f 	cmp	x8, x1
    787c:	54fff148 	b.hi	76a4 <__modti3+0xb4>  // b.pmore
    7880:	dac01109 	clz	x9, x8
    7884:	2a0903e6 	mov	w6, w9
    7888:	b5fff1c9 	cbnz	x9, 76c0 <__modti3+0xd0>
    788c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    7890:	54000068 	b.hi	789c <__modti3+0x2ac>  // b.pmore
    7894:	eb050007 	subs	x7, x0, x5
    7898:	da080021 	sbc	x1, x1, x8
    789c:	aa0703e0 	mov	x0, x7
    78a0:	17ffff81 	b	76a4 <__modti3+0xb4>
    78a4:	ab000040 	adds	x0, x2, x0
    78a8:	8b020002 	add	x2, x0, x2
    78ac:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    78b0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    78b4:	17ffff79 	b	7698 <__modti3+0xa8>
    78b8:	9ac82042 	lsl	x2, x2, x8
    78bc:	d2800803 	mov	x3, #0x40                  	// #64
    78c0:	cb080063 	sub	x3, x3, x8
    78c4:	d360fc49 	lsr	x9, x2, #32
    78c8:	9ac82027 	lsl	x7, x1, x8
    78cc:	92407c4a 	and	x10, x2, #0xffffffff
    78d0:	9ac32426 	lsr	x6, x1, x3
    78d4:	9ac32403 	lsr	x3, x0, x3
    78d8:	aa070063 	orr	x3, x3, x7
    78dc:	9ac908c1 	udiv	x1, x6, x9
    78e0:	9ac82007 	lsl	x7, x0, x8
    78e4:	9b099820 	msub	x0, x1, x9, x6
    78e8:	9b017d41 	mul	x1, x10, x1
    78ec:	93c38000 	extr	x0, x0, x3, #32
    78f0:	eb00003f 	cmp	x1, x0
    78f4:	540000a9 	b.ls	7908 <__modti3+0x318>  // b.plast
    78f8:	ab000040 	adds	x0, x2, x0
    78fc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    7900:	8b020006 	add	x6, x0, x2
    7904:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    7908:	cb010000 	sub	x0, x0, x1
    790c:	9ac90801 	udiv	x1, x0, x9
    7910:	9b098026 	msub	x6, x1, x9, x0
    7914:	aa0303e0 	mov	x0, x3
    7918:	9b017d41 	mul	x1, x10, x1
    791c:	b3607cc0 	bfi	x0, x6, #32, #32
    7920:	eb00003f 	cmp	x1, x0
    7924:	540000a9 	b.ls	7938 <__modti3+0x348>  // b.plast
    7928:	ab000040 	adds	x0, x2, x0
    792c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    7930:	8b020003 	add	x3, x0, x2
    7934:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    7938:	cb010000 	sub	x0, x0, x1
    793c:	17ffffb0 	b	77fc <__modti3+0x20c>
    7940:	d1000969 	sub	x9, x11, #0x2
    7944:	8b070021 	add	x1, x1, x7
    7948:	17ffff83 	b	7754 <__modti3+0x164>
    794c:	d1000965 	sub	x5, x11, #0x2
    7950:	8b070063 	add	x3, x3, x7
    7954:	17ffff74 	b	7724 <__modti3+0x134>
    7958:	d503201f 	nop
    795c:	d503201f 	nop

0000000000007960 <atexit>:
    7960:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    7964:	b00000c2 	adrp	x2, 20000 <__data_start>
    7968:	d2800001 	mov	x1, #0x0                   	// #0
    796c:	910003fd 	mov	x29, sp
    7970:	a8c17bfd 	ldp	x29, x30, [sp], #16
    7974:	f9400442 	ldr	x2, [x2, #8]
    7978:	17ffe69e 	b	13f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000797c <_fini>:
    797c:	d503201f 	nop
    7980:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    7984:	910003fd 	mov	x29, sp
    7988:	a8c17bfd 	ldp	x29, x30, [sp], #16
    798c:	d65f03c0 	ret
