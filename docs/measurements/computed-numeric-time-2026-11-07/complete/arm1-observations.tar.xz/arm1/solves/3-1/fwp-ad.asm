
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1/fwp-ad:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002620 <_init>:
    2620:	d503201f 	nop
    2624:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2628:	910003fd 	mov	x29, sp
    262c:	940001a2 	bl	2cb4 <call_weak_fn>
    2630:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2634:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2648:	f946fe11 	ldr	x17, [x16, #3576]
    264c:	9137e210 	add	x16, x16, #0xdf8
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <_exit@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <strlen@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <__sprintf_chk@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <exit@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <__libc_start_main@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtoll@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtod@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_finalize@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_atexit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <pthread_attr_init@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <fputc@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <clock_gettime@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <setvbuf@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <__memcpy_chk@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <signal@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <__snprintf_chk@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fclose@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <fopen@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <malloc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_destroy@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <sigemptyset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <memset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <calloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <realloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <__stack_chk_fail@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <close@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <sigaction@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <__gmon_start__@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <write@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <abort@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <swapcontext@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <__fprintf_chk@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <strcmp@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <mmap@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtol@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtof@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <free@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <nanosleep@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strchr@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <strtoull@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <fwrite@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <pthread_create@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <munmap@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <fflush@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <strcpy@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <sysconf@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <strstr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <_Exit@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <pthread_join@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <getenv@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc88>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	90000045 	adrp	x5, a000 <fwp_main_thread+0x1d60>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	9138e0a5 	add	x5, x5, #0xe38
    2a20:	90000044 	adrp	x4, a000 <fwp_main_thread+0x1d60>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	91390084 	add	x4, x4, #0xe40
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4a 	bl	2770 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940004ec 	bl	3e00 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc88>
    2a7c:	f947ee94 	ldr	x20, [x20, #4056]
    2a80:	f9400282 	ldr	x2, [x20]
    2a84:	f90043f5 	str	x21, [sp, #128]
    2a88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2a8c:	9100c2a1 	add	x1, x21, #0x30
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x114b8>
    2aa0:	910de000 	add	x0, x0, #0x378
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9003420 	str	x0, [x1, #104]
    2aac:	940006f5 	bl	4680 <fwp_now_ns>
    2ab0:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x490>
    2ab4:	91054000 	add	x0, x0, #0x150
    2ab8:	97ffffb6 	bl	2990 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f3 	mov	x19, x0
    2ac8:	350008c1 	cbnz	w1, 2be0 <main+0x180>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff17 	bl	2730 <clock_gettime@plt>
    2ad8:	350007e0 	cbnz	w0, 2bd4 <main+0x174>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b5000620 	cbnz	x0, 2bc8 <main+0x168>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f3 	add	x19, sp, #0x18
    2b1c:	97ffff09 	bl	2740 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0e 	bl	2760 <signal@plt>
    2b2c:	aa1303e0 	mov	x0, x19
    2b30:	97fffef8 	bl	2710 <pthread_attr_init@plt>
    2b34:	350007a0 	cbnz	w0, 2c28 <main+0x1c8>
    2b38:	aa1303e0 	mov	x0, x19
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000660 	cbnz	w0, 2c10 <main+0x1b0>
    2b48:	aa1303e1 	mov	x1, x19
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000022 	adrp	x2, 8000 <fwp_write+0xd4c>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	910a8042 	add	x2, x2, #0x2a0
    2b5c:	97ffff6d 	bl	2910 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1303e0 	mov	x0, x19
    2b68:	2a0103f3 	mov	w19, w1
    2b6c:	97ffff11 	bl	27b0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	35000613 	cbnz	w19, 2c34 <main+0x1d4>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff80 	bl	2980 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	9100c2b5 	add	x21, x21, #0x30
    2b90:	97ffff68 	bl	2930 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b942faa0 	ldr	w0, [x21, #760]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	54000481 	b.ne	2c40 <main+0x1e0>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x490>
    2bcc:	91060000 	add	x0, x0, #0x180
    2bd0:	9400048c 	bl	3e00 <fwp_trap>
    2bd4:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x490>
    2bd8:	91058000 	add	x0, x0, #0x160
    2bdc:	94000489 	bl	3e00 <fwp_trap>
    2be0:	910003e1 	mov	x1, sp
    2be4:	52800142 	mov	w2, #0xa                   	// #10
    2be8:	97ffff42 	bl	28f0 <strtoull@plt>
    2bec:	f94003e0 	ldr	x0, [sp]
    2bf0:	39400000 	ldrb	w0, [x0]
    2bf4:	35fff6c0 	cbnz	w0, 2acc <main+0x6c>
    2bf8:	39400260 	ldrb	w0, [x19]
    2bfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c00:	5100ac00 	sub	w0, w0, #0x2b
    2c04:	6a01001f 	tst	w0, w1
    2c08:	54fff620 	b.eq	2acc <main+0x6c>  // b.none
    2c0c:	17ffffbf 	b	2b08 <main+0xa8>
    2c10:	aa1303e0 	mov	x0, x19
    2c14:	97fffee7 	bl	27b0 <pthread_attr_destroy@plt>
    2c18:	35000160 	cbnz	w0, 2c44 <main+0x1e4>
    2c1c:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x490>
    2c20:	91076000 	add	x0, x0, #0x1d8
    2c24:	94000477 	bl	3e00 <fwp_trap>
    2c28:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x490>
    2c2c:	9106a000 	add	x0, x0, #0x1a8
    2c30:	94000474 	bl	3e00 <fwp_trap>
    2c34:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x490>
    2c38:	91080000 	add	x0, x0, #0x200
    2c3c:	94000471 	bl	3e00 <fwp_trap>
    2c40:	97fffef0 	bl	2800 <__stack_chk_fail@plt>
    2c44:	97ffff03 	bl	2850 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe85 	bl	26c0 <__libc_start_main@plt>
    2cb0:	97fffee8 	bl	2850 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffedc 	b	2830 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91008000 	add	x0, x0, #0x20
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91008021 	add	x1, x1, #0x20
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91008000 	add	x0, x0, #0x20
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91008021 	add	x1, x1, #0x20
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39408260 	ldrb	w0, [x19, #32]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe60 	bl	26f0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39008260 	strb	w0, [x19, #32]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x490>
    2e34:	91208021 	add	x1, x1, #0x820
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe4d 	bl	2800 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402003 	ldr	x3, [x0, #64]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	29490402 	ldp	w2, w1, [x0, #72]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800b03 	mov	w3, #0x58                  	// #88
    2f28:	f9401884 	ldr	x4, [x4, #48]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9004c61 	str	w1, [x3, #76]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800b04 	mov	w4, #0x58                  	// #88
    2f40:	f9401863 	ldr	x3, [x3, #48]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9004822 	str	w2, [x1, #72]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900201f 	str	xzr, [x0, #64]
    2f54:	fd002400 	str	d0, [x0, #72]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args173>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9401c00 	ldr	x0, [x0, #56]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe6b 	bl	2930 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe66 	b	2930 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe62 	b	2930 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	90000040 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    2fd0:	912de000 	add	x0, x0, #0xb78
    2fd4:	97fffe4b 	bl	2900 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe55 	bl	2930 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe63 	bl	2970 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	9100c043 	add	x3, x2, #0x30
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe4b 	bl	2950 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdc0 	b	2760 <signal@plt>
    3064:	9100c042 	add	x2, x2, #0x30
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x490>
    3098:	91200021 	add	x1, x1, #0x800
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde7 	bl	2840 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd75 	bl	2680 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    30c4:	9114c2a1 	add	x1, x21, #0x530
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xad0>
    30d8:	912480a5 	add	x5, x5, #0x920
    30dc:	9114c2a1 	add	x1, x21, #0x530
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	9114c2b7 	add	x23, x21, #0x530
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffded 	bl	2950 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	9114c2b5 	add	x21, x21, #0x530
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	9114c2b5 	add	x21, x21, #0x530
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xad0>
    3268:	912460a5 	add	x5, x5, #0x918
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd8b 	bl	28c0 <free@plt>
    3298:	f9400660 	ldr	x0, [x19, #8]
    329c:	97fffd89 	bl	28c0 <free@plt>
    32a0:	f9400a60 	ldr	x0, [x19, #16]
    32a4:	97fffd87 	bl	28c0 <free@plt>
    32a8:	a9007e7f 	stp	xzr, xzr, [x19]
    32ac:	a9017e7f 	stp	xzr, xzr, [x19, #16]
    32b0:	f900127f 	str	xzr, [x19, #32]
    32b4:	f9400bf3 	ldr	x19, [sp, #16]
    32b8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32bc:	d65f03c0 	ret

00000000000032c0 <buf_grow>:
    32c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c4:	910003fd 	mov	x29, sp
    32c8:	a90153f3 	stp	x19, x20, [sp, #16]
    32cc:	aa0003f4 	mov	x20, x0
    32d0:	f9400400 	ldr	x0, [x0, #8]
    32d4:	b100041f 	cmn	x0, #0x1
    32d8:	54000400 	b.eq	3358 <buf_grow+0x98>  // b.none
    32dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e0:	cb000042 	sub	x2, x2, x0
    32e4:	eb01005f 	cmp	x2, x1
    32e8:	54000383 	b.cc	3358 <buf_grow+0x98>  // b.lo, b.ul, b.last
    32ec:	f9400a82 	ldr	x2, [x20, #16]
    32f0:	91000421 	add	x1, x1, #0x1
    32f4:	8b000033 	add	x19, x1, x0
    32f8:	eb13005f 	cmp	x2, x19
    32fc:	54000242 	b.cs	3344 <buf_grow+0x84>  // b.hs, b.nlast
    3300:	f100005f 	cmp	x2, #0x0
    3304:	b5000262 	cbnz	x2, 3350 <buf_grow+0x90>
    3308:	d2800802 	mov	x2, #0x40                  	// #64
    330c:	eb02027f 	cmp	x19, x2
    3310:	54000068 	b.hi	331c <buf_grow+0x5c>  // b.pmore
    3314:	14000005 	b	3328 <buf_grow+0x68>
    3318:	b7f800a2 	tbnz	x2, #63, 332c <buf_grow+0x6c>
    331c:	d37ff842 	lsl	x2, x2, #1
    3320:	eb02027f 	cmp	x19, x2
    3324:	54ffffa8 	b.hi	3318 <buf_grow+0x58>  // b.pmore
    3328:	aa0203f3 	mov	x19, x2
    332c:	f9400280 	ldr	x0, [x20]
    3330:	aa1303e1 	mov	x1, x19
    3334:	97fffd2f 	bl	27f0 <realloc@plt>
    3338:	b4000100 	cbz	x0, 3358 <buf_grow+0x98>
    333c:	f9000280 	str	x0, [x20]
    3340:	f9000a93 	str	x19, [x20, #16]
    3344:	a94153f3 	ldp	x19, x20, [sp, #16]
    3348:	a8c27bfd 	ldp	x29, x30, [sp], #32
    334c:	d65f03c0 	ret
    3350:	54fffe6a 	b.ge	331c <buf_grow+0x5c>  // b.tcont
    3354:	17fffff6 	b	332c <buf_grow+0x6c>
    3358:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    335c:	f947e863 	ldr	x3, [x3, #4048]
    3360:	d2800262 	mov	x2, #0x13                  	// #19
    3364:	d2800021 	mov	x1, #0x1                   	// #1
    3368:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    336c:	912de000 	add	x0, x0, #0xb78
    3370:	f9400063 	ldr	x3, [x3]
    3374:	97fffd63 	bl	2900 <fwrite@plt>
    3378:	d2800000 	mov	x0, #0x0                   	// #0
    337c:	97fffd6d 	bl	2930 <fflush@plt>
    3380:	52800cc0 	mov	w0, #0x66                  	// #102
    3384:	97fffd7b 	bl	2970 <_Exit@plt>
    3388:	d503201f 	nop
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc4 	bl	32c0 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffca7 	bl	2660 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	9100c022 	add	x2, x1, #0x30
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	9100c021 	add	x1, x1, #0x30
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd16 	bl	28e0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0f 	bl	28e0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	912e4021 	add	x1, x1, #0xb90
    34b8:	97fffd2a 	bl	2960 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	912e6021 	add	x1, x1, #0xb98
    34cc:	97fffd25 	bl	2960 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6e 	bl	2690 <strlen@plt>
    34dc:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    34e0:	912e8021 	add	x1, x1, #0xba0
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_format_g.constprop.0>:
    3500:	d10483ff 	sub	sp, sp, #0x120
    3504:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1d60>
    3508:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    350c:	f947f442 	ldr	x2, [x2, #4072]
    3510:	912ea084 	add	x4, x4, #0xba8
    3514:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3518:	9102c3fd 	add	x29, sp, #0xb0
    351c:	d2800803 	mov	x3, #0x40                  	// #64
    3520:	a90e63f7 	stp	x23, x24, [sp, #224]
    3524:	93407c38 	sxtw	x24, w1
    3528:	aa0303e1 	mov	x1, x3
    352c:	fd008be8 	str	d8, [sp, #272]
    3530:	1e604008 	fmov	d8, d0
    3534:	a90c53f3 	stp	x19, x20, [sp, #192]
    3538:	910083f4 	add	x20, sp, #0x20
    353c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3540:	aa0003f5 	mov	x21, x0
    3544:	a91073fb 	stp	x27, x28, [sp, #256]
    3548:	5100071c 	sub	w28, w24, #0x1
    354c:	2a1c03e5 	mov	w5, w28
    3550:	f9400040 	ldr	x0, [x2]
    3554:	f90057e0 	str	x0, [sp, #168]
    3558:	d2800000 	mov	x0, #0x0                   	// #0
    355c:	52800042 	mov	w2, #0x2                   	// #2
    3560:	aa1403e0 	mov	x0, x20
    3564:	97fffc83 	bl	2770 <__snprintf_chk@plt>
    3568:	52800ca1 	mov	w1, #0x65                  	// #101
    356c:	aa1403e0 	mov	x0, x20
    3570:	97fffcdc 	bl	28e0 <strchr@plt>
    3574:	aa0003f3 	mov	x19, x0
    3578:	52800142 	mov	w2, #0xa                   	// #10
    357c:	91000400 	add	x0, x0, #0x1
    3580:	d2800001 	mov	x1, #0x0                   	// #0
    3584:	97fffcc7 	bl	28a0 <strtol@plt>
    3588:	aa0003f7 	mov	x23, x0
    358c:	11001400 	add	w0, w0, #0x5
    3590:	7100541f 	cmp	w0, #0x15
    3594:	54000d68 	b.hi	3740 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3598:	4b170385 	sub	w5, w28, w23
    359c:	710000bf 	cmp	w5, #0x0
    35a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    35a4:	54000b80 	b.eq	3714 <fwp_format_g.constprop.0+0x214>  // b.none
    35a8:	394083e0 	ldrb	w0, [sp, #32]
    35ac:	cb180273 	sub	x19, x19, x24
    35b0:	91000673 	add	x19, x19, #0x1
    35b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    35b8:	7100b41f 	cmp	w0, #0x2d
    35bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    35c0:	1a9f17e4 	cset	w4, eq	// eq = none
    35c4:	cb010266 	sub	x6, x19, x1
    35c8:	d10004da 	sub	x26, x6, #0x1
    35cc:	540018a0 	b.eq	38e0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    35d0:	910183f9 	add	x25, sp, #0x60
    35d4:	d280091b 	mov	x27, #0x48                  	// #72
    35d8:	aa1903e7 	mov	x7, x25
    35dc:	91000423 	add	x3, x1, #0x1
    35e0:	91011cc6 	add	x6, x6, #0x47
    35e4:	910004f6 	add	x22, x7, #0x1
    35e8:	37f80ff7 	tbnz	w23, #31, 37e4 <fwp_format_g.constprop.0+0x2e4>
    35ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    35f0:	93407ef7 	sxtw	x23, w23
    35f4:	390000e4 	strb	w4, [x7]
    35f8:	aa1303e1 	mov	x1, x19
    35fc:	aa1703e2 	mov	x2, x23
    3600:	aa1603e0 	mov	x0, x22
    3604:	b9000be5 	str	w5, [sp, #8]
    3608:	cb170374 	sub	x20, x27, x23
    360c:	a9011be3 	stp	x3, x6, [sp, #16]
    3610:	97fffc14 	bl	2660 <memcpy@plt>
    3614:	d1000694 	sub	x20, x20, #0x1
    3618:	f9400be3 	ldr	x3, [sp, #16]
    361c:	8b1702d6 	add	x22, x22, x23
    3620:	aa1603e0 	mov	x0, x22
    3624:	aa1a03e2 	mov	x2, x26
    3628:	aa0303e1 	mov	x1, x3
    362c:	aa1403e3 	mov	x3, x20
    3630:	97fffc48 	bl	2750 <__memcpy_chk@plt>
    3634:	8b1a02d6 	add	x22, x22, x26
    3638:	f9400fe6 	ldr	x6, [sp, #24]
    363c:	d2800900 	mov	x0, #0x48                  	// #72
    3640:	b9400be5 	ldr	w5, [sp, #8]
    3644:	8b170261 	add	x1, x19, x23
    3648:	cb1400c3 	sub	x3, x6, x20
    364c:	cb060294 	sub	x20, x20, x6
    3650:	f101207f 	cmp	x3, #0x48
    3654:	93407cb8 	sxtw	x24, w5
    3658:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    365c:	aa1803e2 	mov	x2, x24
    3660:	8b1802d3 	add	x19, x22, x24
    3664:	8b140063 	add	x3, x3, x20
    3668:	aa1603e0 	mov	x0, x22
    366c:	97fffc39 	bl	2750 <__memcpy_chk@plt>
    3670:	cb190273 	sub	x19, x19, x25
    3674:	d28031e0 	mov	x0, #0x18f                 	// #399
    3678:	eb00027f 	cmp	x19, x0
    367c:	aa1903e1 	mov	x1, x25
    3680:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3684:	aa1503e0 	mov	x0, x21
    3688:	aa1303e2 	mov	x2, x19
    368c:	97fffbf5 	bl	2660 <memcpy@plt>
    3690:	38336abf 	strb	wzr, [x21, x19]
    3694:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3698:	aa1503e0 	mov	x0, x21
    369c:	97fffbfd 	bl	2690 <strlen@plt>
    36a0:	aa0003f3 	mov	x19, x0
    36a4:	528005c1 	mov	w1, #0x2e                  	// #46
    36a8:	aa1503e0 	mov	x0, x21
    36ac:	97fffc8d 	bl	28e0 <strchr@plt>
    36b0:	b4000140 	cbz	x0, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b4:	b4000133 	cbz	x19, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b8:	aa1303e1 	mov	x1, x19
    36bc:	d1000673 	sub	x19, x19, #0x1
    36c0:	38736aa0 	ldrb	w0, [x21, x19]
    36c4:	7100c01f 	cmp	w0, #0x30
    36c8:	54001001 	b.ne	38c8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    36cc:	38336abf 	strb	wzr, [x21, x19]
    36d0:	b5ffff53 	cbnz	x19, 36b8 <fwp_format_g.constprop.0+0x1b8>
    36d4:	d503201f 	nop
    36d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    36dc:	f947f400 	ldr	x0, [x0, #4072]
    36e0:	f94057e2 	ldr	x2, [sp, #168]
    36e4:	f9400001 	ldr	x1, [x0]
    36e8:	eb010042 	subs	x2, x2, x1
    36ec:	d2800001 	mov	x1, #0x0                   	// #0
    36f0:	54001061 	b.ne	38fc <fwp_format_g.constprop.0+0x3fc>  // b.any
    36f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    36f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    36fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3700:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3704:	a95073fb 	ldp	x27, x28, [sp, #256]
    3708:	fd408be8 	ldr	d8, [sp, #272]
    370c:	910483ff 	add	sp, sp, #0x120
    3710:	d65f03c0 	ret
    3714:	1e604100 	fmov	d0, d8
    3718:	710000bf 	cmp	w5, #0x0
    371c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3720:	aa1503e0 	mov	x0, x21
    3724:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1d60>
    3728:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    372c:	912f0084 	add	x4, x4, #0xbc0
    3730:	52800042 	mov	w2, #0x2                   	// #2
    3734:	d2803201 	mov	x1, #0x190                 	// #400
    3738:	97fffc0e 	bl	2770 <__snprintf_chk@plt>
    373c:	17ffffd7 	b	3698 <fwp_format_g.constprop.0+0x198>
    3740:	cb140273 	sub	x19, x19, x20
    3744:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3748:	910183f9 	add	x25, sp, #0x60
    374c:	aa1303e2 	mov	x2, x19
    3750:	aa1403e1 	mov	x1, x20
    3754:	aa1903e0 	mov	x0, x25
    3758:	d2800803 	mov	x3, #0x40                  	// #64
    375c:	97fffbfd 	bl	2750 <__memcpy_chk@plt>
    3760:	38336b3f 	strb	wzr, [x25, x19]
    3764:	aa1903e0 	mov	x0, x25
    3768:	528005c1 	mov	w1, #0x2e                  	// #46
    376c:	97fffc5d 	bl	28e0 <strchr@plt>
    3770:	b40001c0 	cbz	x0, 37a8 <fwp_format_g.constprop.0+0x2a8>
    3774:	b50000b3 	cbnz	x19, 3788 <fwp_format_g.constprop.0+0x288>
    3778:	1400000c 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    377c:	381ff01f 	sturb	wzr, [x0, #-1]
    3780:	f1000673 	subs	x19, x19, #0x1
    3784:	54000120 	b.eq	37a8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3788:	8b130320 	add	x0, x25, x19
    378c:	385ff001 	ldurb	w1, [x0, #-1]
    3790:	7100c03f 	cmp	w1, #0x30
    3794:	54ffff40 	b.eq	377c <fwp_format_g.constprop.0+0x27c>  // b.none
    3798:	d1000673 	sub	x19, x19, #0x1
    379c:	38736b20 	ldrb	w0, [x25, x19]
    37a0:	7100b81f 	cmp	w0, #0x2e
    37a4:	54000a80 	b.eq	38f4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    37a8:	710002ff 	cmp	w23, #0x0
    37ac:	528005a1 	mov	w1, #0x2d                  	// #45
    37b0:	aa1903e5 	mov	x5, x25
    37b4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    37b8:	aa1503e0 	mov	x0, x21
    37bc:	52800566 	mov	w6, #0x2b                  	// #43
    37c0:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x1d60>
    37c4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    37c8:	912ec084 	add	x4, x4, #0xbb0
    37cc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    37d0:	52800042 	mov	w2, #0x2                   	// #2
    37d4:	d2803201 	mov	x1, #0x190                 	// #400
    37d8:	97fffbe6 	bl	2770 <__snprintf_chk@plt>
    37dc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    37e0:	17ffffbe 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    37e4:	52800605 	mov	w5, #0x30                  	// #48
    37e8:	390000e5 	strb	w5, [x7]
    37ec:	d100077b 	sub	x27, x27, #0x1
    37f0:	aa0303e1 	mov	x1, x3
    37f4:	aa1603e0 	mov	x0, x22
    37f8:	aa1b03e3 	mov	x3, x27
    37fc:	aa1a03e2 	mov	x2, x26
    3800:	f90007e6 	str	x6, [sp, #8]
    3804:	b90013e4 	str	w4, [sp, #16]
    3808:	8b1a02d6 	add	x22, x22, x26
    380c:	b9001be5 	str	w5, [sp, #24]
    3810:	97fffbd0 	bl	2750 <__memcpy_chk@plt>
    3814:	f94007e6 	ldr	x6, [sp, #8]
    3818:	2a3703e7 	mvn	w7, w23
    381c:	b94013e4 	ldr	w4, [sp, #16]
    3820:	cb1b00c1 	sub	x1, x6, x27
    3824:	cb06037b 	sub	x27, x27, x6
    3828:	f101203f 	cmp	x1, #0x48
    382c:	d2800906 	mov	x6, #0x48                  	// #72
    3830:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3834:	8b1b0023 	add	x3, x1, x27
    3838:	310006ff 	cmn	w23, #0x1
    383c:	54000220 	b.eq	3880 <fwp_format_g.constprop.0+0x380>  // b.none
    3840:	b9401be5 	ldr	w5, [sp, #24]
    3844:	d2800001 	mov	x1, #0x0                   	// #0
    3848:	f101207f 	cmp	x3, #0x48
    384c:	d1000462 	sub	x2, x3, #0x1
    3850:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3854:	38216ac5 	strb	w5, [x22, x1]
    3858:	cb030003 	sub	x3, x0, x3
    385c:	91000421 	add	x1, x1, #0x1
    3860:	91000463 	add	x3, x3, #0x1
    3864:	eb00007f 	cmp	x3, x0
    3868:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    386c:	cb000063 	sub	x3, x3, x0
    3870:	8b020063 	add	x3, x3, x2
    3874:	6b0100ff 	cmp	w7, w1
    3878:	54fffe8c 	b.gt	3848 <fwp_format_g.constprop.0+0x348>
    387c:	8b2742d6 	add	x22, x22, w7, uxtw
    3880:	f101207f 	cmp	x3, #0x48
    3884:	d2800905 	mov	x5, #0x48                  	// #72
    3888:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    388c:	aa1603e0 	mov	x0, x22
    3890:	cb0300a1 	sub	x1, x5, x3
    3894:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3898:	91000421 	add	x1, x1, #0x1
    389c:	d1000463 	sub	x3, x3, #0x1
    38a0:	eb05003f 	cmp	x1, x5
    38a4:	38001402 	strb	w2, [x0], #1
    38a8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    38ac:	93407f82 	sxtw	x2, w28
    38b0:	cb050025 	sub	x5, x1, x5
    38b4:	aa1303e1 	mov	x1, x19
    38b8:	8b0300a3 	add	x3, x5, x3
    38bc:	8b1802d3 	add	x19, x22, x24
    38c0:	97fffba4 	bl	2750 <__memcpy_chk@plt>
    38c4:	17ffff6b 	b	3670 <fwp_format_g.constprop.0+0x170>
    38c8:	d1000421 	sub	x1, x1, #0x1
    38cc:	38616aa0 	ldrb	w0, [x21, x1]
    38d0:	7100b81f 	cmp	w0, #0x2e
    38d4:	54fff021 	b.ne	36d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    38d8:	38216abf 	strb	wzr, [x21, x1]
    38dc:	17ffff7f 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    38e0:	910187e7 	add	x7, sp, #0x61
    38e4:	910183f9 	add	x25, sp, #0x60
    38e8:	d28008fb 	mov	x27, #0x47                  	// #71
    38ec:	390183e0 	strb	w0, [sp, #96]
    38f0:	17ffff3b 	b	35dc <fwp_format_g.constprop.0+0xdc>
    38f4:	38336b3f 	strb	wzr, [x25, x19]
    38f8:	17ffffac 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    38fc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3900:	97fffbc0 	bl	2800 <__stack_chk_fail@plt>

0000000000003904 <fwp_heap_report>:
    3904:	d105c3ff 	sub	sp, sp, #0x170
    3908:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    390c:	9114c042 	add	x2, x2, #0x530
    3910:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    3914:	f947e821 	ldr	x1, [x1, #4048]
    3918:	a9117bfd 	stp	x29, x30, [sp, #272]
    391c:	910443fd 	add	x29, sp, #0x110
    3920:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3924:	f947f400 	ldr	x0, [x0, #4072]
    3928:	a9135bf5 	stp	x21, x22, [sp, #304]
    392c:	a91463f7 	stp	x23, x24, [sp, #320]
    3930:	a9156bf9 	stp	x25, x26, [sp, #336]
    3934:	6d1627e8 	stp	d8, d9, [sp, #352]
    3938:	fd4a1c48 	ldr	d8, [x2, #5176]
    393c:	fd4a2049 	ldr	d9, [x2, #5184]
    3940:	f9400036 	ldr	x22, [x1]
    3944:	f9400001 	ldr	x1, [x0]
    3948:	f90087e1 	str	x1, [sp, #264]
    394c:	d2800001 	mov	x1, #0x0                   	// #0
    3950:	f949e459 	ldr	x25, [x2, #5064]
    3954:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    3958:	f94a1057 	ldr	x23, [x2, #5152]
    395c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    3960:	f94a1458 	ldr	x24, [x2, #5160]
    3964:	912f2021 	add	x1, x1, #0xbc8
    3968:	912f4000 	add	x0, x0, #0xbd0
    396c:	97fffb89 	bl	2790 <fopen@plt>
    3970:	b4000760 	cbz	x0, 3a5c <fwp_heap_report+0x158>
    3974:	528daad5 	mov	w21, #0x6d56                	// #27990
    3978:	a91253f3 	stp	x19, x20, [sp, #288]
    397c:	aa0003f4 	mov	x20, x0
    3980:	910023f3 	add	x19, sp, #0x8
    3984:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3988:	72aae915 	movk	w21, #0x5748, lsl #16
    398c:	d503201f 	nop
    3990:	aa1403e2 	mov	x2, x20
    3994:	aa1303e0 	mov	x0, x19
    3998:	52802001 	mov	w1, #0x100                 	// #256
    399c:	97fffc05 	bl	29b0 <fgets@plt>
    39a0:	b4000280 	cbz	x0, 39f0 <fwp_heap_report+0xec>
    39a4:	b9400261 	ldr	w1, [x19]
    39a8:	6b15003f 	cmp	w1, w21
    39ac:	54ffff21 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39b0:	39401260 	ldrb	w0, [x19, #4]
    39b4:	7101341f 	cmp	w0, #0x4d
    39b8:	54fffec1 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39bc:	394037e0 	ldrb	w0, [sp, #13]
    39c0:	7100e81f 	cmp	w0, #0x3a
    39c4:	54fffe61 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39c8:	52800142 	mov	w2, #0xa                   	// #10
    39cc:	d2800001 	mov	x1, #0x0                   	// #0
    39d0:	91003be0 	add	x0, sp, #0xe
    39d4:	97fffbb3 	bl	28a0 <strtol@plt>
    39d8:	aa1403e2 	mov	x2, x20
    39dc:	aa0003fa 	mov	x26, x0
    39e0:	52802001 	mov	w1, #0x100                 	// #256
    39e4:	aa1303e0 	mov	x0, x19
    39e8:	97fffbf2 	bl	29b0 <fgets@plt>
    39ec:	b5fffdc0 	cbnz	x0, 39a4 <fwp_heap_report+0xa0>
    39f0:	aa1403e0 	mov	x0, x20
    39f4:	97fffb63 	bl	2780 <fclose@plt>
    39f8:	a95253f3 	ldp	x19, x20, [sp, #288]
    39fc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3a00:	f947f400 	ldr	x0, [x0, #4072]
    3a04:	f94087e2 	ldr	x2, [sp, #264]
    3a08:	f9400001 	ldr	x1, [x0]
    3a0c:	eb010042 	subs	x2, x2, x1
    3a10:	d2800001 	mov	x1, #0x0                   	// #0
    3a14:	54000281 	b.ne	3a64 <fwp_heap_report+0x160>  // b.any
    3a18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3a1c:	aa1a03e6 	mov	x6, x26
    3a20:	aa1903e5 	mov	x5, x25
    3a24:	aa1803e4 	mov	x4, x24
    3a28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3a2c:	aa1703e3 	mov	x3, x23
    3a30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3a3c:	1e604121 	fmov	d1, d9
    3a40:	1e604100 	fmov	d0, d8
    3a44:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1d60>
    3a48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3a4c:	912fc042 	add	x2, x2, #0xbf0
    3a50:	9105c3ff 	add	sp, sp, #0x170
    3a54:	52800041 	mov	w1, #0x2                   	// #2
    3a58:	17fffb86 	b	2870 <__fprintf_chk@plt>
    3a5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3a60:	17ffffe7 	b	39fc <fwp_heap_report+0xf8>
    3a64:	a91253f3 	stp	x19, x20, [sp, #288]
    3a68:	97fffb66 	bl	2800 <__stack_chk_fail@plt>
    3a6c:	d503201f 	nop

0000000000003a70 <fwp_heap_init>:
    3a70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xad0>
    3a78:	9110c061 	add	x1, x3, #0x430
    3a7c:	910003fd 	mov	x29, sp
    3a80:	a90153f3 	stp	x19, x20, [sp, #16]
    3a84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    3a88:	9114c262 	add	x2, x19, #0x530
    3a8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3a90:	52800024 	mov	w4, #0x1                   	// #1
    3a94:	52800200 	mov	w0, #0x10                  	// #16
    3a98:	b913a444 	str	w4, [x2, #5028]
    3a9c:	d503201f 	nop
    3aa0:	b8004420 	str	w0, [x1], #4
    3aa4:	11004000 	add	w0, w0, #0x10
    3aa8:	7104401f 	cmp	w0, #0x110
    3aac:	54ffffa1 	b.ne	3aa0 <fwp_heap_init+0x30>  // b.any
    3ab0:	90000042 	adrp	x2, b000 <_IO_stdin_used+0x490>
    3ab4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ab8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xad0>
    3abc:	9111c021 	add	x1, x1, #0x470
    3ac0:	3dc20c43 	ldr	q3, [x2, #2096]
    3ac4:	d2800000 	mov	x0, #0x0                   	// #0
    3ac8:	4e040401 	dup	v1.4s, v0.s[0]
    3acc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ad0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ad4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ad8:	3ca06821 	str	q1, [x1, x0]
    3adc:	91004000 	add	x0, x0, #0x10
    3ae0:	f101801f 	cmp	x0, #0x60
    3ae4:	54ffff21 	b.ne	3ac8 <fwp_heap_init+0x58>  // b.any
    3ae8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xad0>
    3aec:	9110c063 	add	x3, x3, #0x430
    3af0:	91134084 	add	x4, x4, #0x4d0
    3af4:	9114c266 	add	x6, x19, #0x530
    3af8:	d2800002 	mov	x2, #0x0                   	// #0
    3afc:	d2800000 	mov	x0, #0x0                   	// #0
    3b00:	d2880205 	mov	x5, #0x4010                	// #16400
    3b04:	d503201f 	nop
    3b08:	910f0001 	add	x1, x0, #0x3c0
    3b0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3b10:	eb02003f 	cmp	x1, x2
    3b14:	540000a2 	b.cs	3b28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3b18:	91000400 	add	x0, x0, #0x1
    3b1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3b20:	eb02003f 	cmp	x1, x2
    3b24:	54ffffa3 	b.cc	3b18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3b28:	91004042 	add	x2, x2, #0x10
    3b2c:	38001480 	strb	w0, [x4], #1
    3b30:	eb05005f 	cmp	x2, x5
    3b34:	54fffea1 	b.ne	3b08 <fwp_heap_init+0x98>  // b.any
    3b38:	528000b5 	mov	w21, #0x5                   	// #5
    3b3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3b40:	14000004 	b	3b50 <fwp_heap_init+0xe0>
    3b44:	d342fe94 	lsr	x20, x20, #2
    3b48:	710006b5 	subs	w21, w21, #0x1
    3b4c:	54000720 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3b50:	91404296 	add	x22, x20, #0x10, lsl #12
    3b54:	d2800005 	mov	x5, #0x0                   	// #0
    3b58:	aa1603e1 	mov	x1, x22
    3b5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3b60:	52880443 	mov	w3, #0x4022                	// #16418
    3b64:	52800002 	mov	w2, #0x0                   	// #0
    3b68:	d2800000 	mov	x0, #0x0                   	// #0
    3b6c:	97fffb49 	bl	2890 <mmap@plt>
    3b70:	aa0003e6 	mov	x6, x0
    3b74:	b100041f 	cmn	x0, #0x1
    3b78:	54fffe60 	b.eq	3b44 <fwp_heap_init+0xd4>  // b.none
    3b7c:	b40005a0 	cbz	x0, 3c30 <fwp_heap_init+0x1c0>
    3b80:	d350fe94 	lsr	x20, x20, #16
    3b84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3b88:	8b0000c7 	add	x7, x6, x0
    3b8c:	9114c275 	add	x21, x19, #0x530
    3b90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3b94:	8b140a81 	add	x1, x20, x20, lsl #2
    3b98:	d2800005 	mov	x5, #0x0                   	// #0
    3b9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ba0:	d37df021 	lsl	x1, x1, #3
    3ba4:	52880443 	mov	w3, #0x4022                	// #16418
    3ba8:	52800002 	mov	w2, #0x0                   	// #0
    3bac:	d2800000 	mov	x0, #0x0                   	// #0
    3bb0:	f909daa7 	str	x7, [x21, #5040]
    3bb4:	f909dea6 	str	x6, [x21, #5048]
    3bb8:	f909e2b6 	str	x22, [x21, #5056]
    3bbc:	f909eab4 	str	x20, [x21, #5072]
    3bc0:	f90a02a1 	str	x1, [x21, #5120]
    3bc4:	97fffb33 	bl	2890 <mmap@plt>
    3bc8:	aa0003e1 	mov	x1, x0
    3bcc:	b100041f 	cmn	x0, #0x1
    3bd0:	54000300 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3bd4:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    3bd8:	9131e000 	add	x0, x0, #0xc78
    3bdc:	f909fea1 	str	x1, [x21, #5112]
    3be0:	97fffb6c 	bl	2990 <getenv@plt>
    3be4:	52800002 	mov	w2, #0x0                   	// #0
    3be8:	aa0003e1 	mov	x1, x0
    3bec:	b40000e0 	cbz	x0, 3c08 <fwp_heap_init+0x198>
    3bf0:	39400000 	ldrb	w0, [x0]
    3bf4:	340000a0 	cbz	w0, 3c08 <fwp_heap_init+0x198>
    3bf8:	7100c000 	subs	w0, w0, #0x30
    3bfc:	54000120 	b.eq	3c20 <fwp_heap_init+0x1b0>  // b.none
    3c00:	7100001f 	cmp	w0, #0x0
    3c04:	1a9f07e2 	cset	w2, ne	// ne = any
    3c08:	9114c273 	add	x19, x19, #0x530
    3c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3c10:	b913aa62 	str	w2, [x19, #5032]
    3c14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3c1c:	d65f03c0 	ret
    3c20:	39400420 	ldrb	w0, [x1, #1]
    3c24:	7100001f 	cmp	w0, #0x0
    3c28:	1a9f07e2 	cset	w2, ne	// ne = any
    3c2c:	17fffff7 	b	3c08 <fwp_heap_init+0x198>
    3c30:	97fffce0 	bl	2fb0 <fwp_heap_oom>

0000000000003c34 <fwp_wake_io>:
    3c34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3c38:	9100c122 	add	x2, x9, #0x30
    3c3c:	f9400001 	ldr	x1, [x0]
    3c40:	5280000a 	mov	w10, #0x0                   	// #0
    3c44:	f9401446 	ldr	x6, [x2, #40]
    3c48:	52800008 	mov	w8, #0x0                   	// #0
    3c4c:	4f000400 	movi	v0.4s, #0x0
    3c50:	52800027 	mov	w7, #0x1                   	// #1
    3c54:	aa0103e2 	mov	x2, x1
    3c58:	b4000321 	cbz	x1, 3cbc <fwp_wake_io+0x88>
    3c5c:	f9408c25 	ldr	x5, [x1, #280]
    3c60:	39015c27 	strb	w7, [x1, #87]
    3c64:	b4000165 	cbz	x5, 3c90 <fwp_wake_io+0x5c>
    3c68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3c6c:	b4000364 	cbz	x4, 3cd8 <fwp_wake_io+0xa4>
    3c70:	f9009483 	str	x3, [x4, #296]
    3c74:	f9409423 	ldr	x3, [x1, #296]
    3c78:	b4000043 	cbz	x3, 3c80 <fwp_wake_io+0x4c>
    3c7c:	f9009064 	str	x4, [x3, #288]
    3c80:	91080023 	add	x3, x1, #0x200
    3c84:	f900943f 	str	xzr, [x1, #296]
    3c88:	3c918060 	stur	q0, [x3, #-232]
    3c8c:	f9400001 	ldr	x1, [x0]
    3c90:	f9402843 	ldr	x3, [x2, #80]
    3c94:	f2001c7f 	tst	x3, #0xff000000ff
    3c98:	54fffde1 	b.ne	3c54 <fwp_wake_io+0x20>  // b.any
    3c9c:	39015047 	strb	w7, [x2, #84]
    3ca0:	f900805f 	str	xzr, [x2, #256]
    3ca4:	b40001e6 	cbz	x6, 3ce0 <fwp_wake_io+0xac>
    3ca8:	f90080c2 	str	x2, [x6, #256]
    3cac:	aa0203e6 	mov	x6, x2
    3cb0:	52800028 	mov	w8, #0x1                   	// #1
    3cb4:	aa0103e2 	mov	x2, x1
    3cb8:	b5fffd21 	cbnz	x1, 3c5c <fwp_wake_io+0x28>
    3cbc:	3400006a 	cbz	w10, 3cc8 <fwp_wake_io+0x94>
    3cc0:	9100c120 	add	x0, x9, #0x30
    3cc4:	f900180b 	str	x11, [x0, #48]
    3cc8:	34000068 	cbz	w8, 3cd4 <fwp_wake_io+0xa0>
    3ccc:	9100c129 	add	x9, x9, #0x30
    3cd0:	f9001526 	str	x6, [x9, #40]
    3cd4:	d65f03c0 	ret
    3cd8:	f90000a3 	str	x3, [x5]
    3cdc:	17ffffe7 	b	3c78 <fwp_wake_io+0x44>
    3ce0:	aa0203eb 	mov	x11, x2
    3ce4:	5280002a 	mov	w10, #0x1                   	// #1
    3ce8:	17fffff1 	b	3cac <fwp_wake_io+0x78>
    3cec:	d503201f 	nop

0000000000003cf0 <fwp_tape_buffers_release>:
    3cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3cf4:	910003fd 	mov	x29, sp
    3cf8:	a90153f3 	stp	x19, x20, [sp, #16]
    3cfc:	aa0003f3 	mov	x19, x0
    3d00:	f9400c00 	ldr	x0, [x0, #24]
    3d04:	b7f80700 	tbnz	x0, #63, 3de4 <fwp_tape_buffers_release+0xf4>
    3d08:	f9401261 	ldr	x1, [x19, #32]
    3d0c:	b7f80301 	tbnz	x1, #63, 3d6c <fwp_tape_buffers_release+0x7c>
    3d10:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    3d14:	eb02001f 	cmp	x0, x2
    3d18:	540002a8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d1c:	8b000400 	add	x0, x0, x0, lsl #1
    3d20:	d2a00102 	mov	x2, #0x80000               	// #524288
    3d24:	d37df000 	lsl	x0, x0, #3
    3d28:	cb000042 	sub	x2, x2, x0
    3d2c:	eb420c3f 	cmp	x1, x2, lsr #3
    3d30:	540001e8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d34:	8b010c14 	add	x20, x0, x1, lsl #3
    3d38:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    3d3c:	91322000 	add	x0, x0, #0xc88
    3d40:	97fffb14 	bl	2990 <getenv@plt>
    3d44:	b4000240 	cbz	x0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d48:	39400001 	ldrb	w1, [x0]
    3d4c:	7100c03f 	cmp	w1, #0x30
    3d50:	540001e1 	b.ne	3d8c <fwp_tape_buffers_release+0x9c>  // b.any
    3d54:	39400400 	ldrb	w0, [x0, #1]
    3d58:	350001a0 	cbnz	w0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d5c:	aa1303e0 	mov	x0, x19
    3d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d64:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3d68:	17fffd46 	b	3280 <fwp_tape_buffers_dispose>
    3d6c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    3d70:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3d74:	91322000 	add	x0, x0, #0xc88
    3d78:	97fffb06 	bl	2990 <getenv@plt>
    3d7c:	b4ffff00 	cbz	x0, 3d5c <fwp_tape_buffers_release+0x6c>
    3d80:	39400001 	ldrb	w1, [x0]
    3d84:	7100c03f 	cmp	w1, #0x30
    3d88:	54fffe60 	b.eq	3d54 <fwp_tape_buffers_release+0x64>  // b.none
    3d8c:	d1000681 	sub	x1, x20, #0x1
    3d90:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    3d94:	eb00003f 	cmp	x1, x0
    3d98:	54fffe28 	b.hi	3d5c <fwp_tape_buffers_release+0x6c>  // b.pmore
    3d9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3da0:	b00000f6 	adrp	x22, 20000 <__data_start>
    3da4:	9100c2d6 	add	x22, x22, #0x30
    3da8:	9100e2d5 	add	x21, x22, #0x38
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffd34 	bl	3280 <fwp_tape_buffers_dispose>
    3db4:	ad400660 	ldp	q0, q1, [x19]
    3db8:	f90032d4 	str	x20, [x22, #96]
    3dbc:	ad0006a0 	stp	q0, q1, [x21]
    3dc0:	f9401260 	ldr	x0, [x19, #32]
    3dc4:	f90012a0 	str	x0, [x21, #32]
    3dc8:	a9007e7f 	stp	xzr, xzr, [x19]
    3dcc:	a9017e7f 	stp	xzr, xzr, [x19, #16]
    3dd0:	f900127f 	str	xzr, [x19, #32]
    3dd4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3dd8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3ddc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3de0:	d65f03c0 	ret
    3de4:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    3de8:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3dec:	91322000 	add	x0, x0, #0xc88
    3df0:	97fffae8 	bl	2990 <getenv@plt>
    3df4:	b5fffaa0 	cbnz	x0, 3d48 <fwp_tape_buffers_release+0x58>
    3df8:	17ffffd9 	b	3d5c <fwp_tape_buffers_release+0x6c>
    3dfc:	d503201f 	nop

0000000000003e00 <fwp_trap>:
    3e00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e04:	b00000e2 	adrp	x2, 20000 <__data_start>
    3e08:	d53bd041 	mrs	x1, tpidr_el0
    3e0c:	910003fd 	mov	x29, sp
    3e10:	f9401c42 	ldr	x2, [x2, #56]
    3e14:	91400021 	add	x1, x1, #0x0, lsl #12
    3e18:	91004021 	add	x1, x1, #0x10
    3e1c:	a90153f3 	stp	x19, x20, [sp, #16]
    3e20:	aa0003f3 	mov	x19, x0
    3e24:	f9400034 	ldr	x20, [x1]
    3e28:	b4000062 	cbz	x2, 3e34 <fwp_trap+0x34>
    3e2c:	aa0203e0 	mov	x0, x2
    3e30:	97fffac0 	bl	2930 <fflush@plt>
    3e34:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    3e38:	f947ec00 	ldr	x0, [x0, #4056]
    3e3c:	f9400000 	ldr	x0, [x0]
    3e40:	97fffabc 	bl	2930 <fflush@plt>
    3e44:	aa1303e3 	mov	x3, x19
    3e48:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1d60>
    3e4c:	900000f3 	adrp	x19, 1f000 <fwp_fn_table+0xc88>
    3e50:	f947ea73 	ldr	x19, [x19, #4048]
    3e54:	91328042 	add	x2, x2, #0xca0
    3e58:	52800041 	mov	w1, #0x2                   	// #2
    3e5c:	f9400260 	ldr	x0, [x19]
    3e60:	97fffa84 	bl	2870 <__fprintf_chk@plt>
    3e64:	b40000b4 	cbz	x20, 3e78 <fwp_trap+0x78>
    3e68:	f9400260 	ldr	x0, [x19]
    3e6c:	97fffab1 	bl	2930 <fflush@plt>
    3e70:	52800ca0 	mov	w0, #0x65                  	// #101
    3e74:	97fffabf 	bl	2970 <_Exit@plt>
    3e78:	52800ca0 	mov	w0, #0x65                  	// #101
    3e7c:	97fffa0d 	bl	26b0 <exit@plt>

0000000000003e80 <fwp_rc_forget_slot.part.0>:
    3e80:	ca404401 	eor	x1, x0, x0, lsr #17
    3e84:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e88:	ca412421 	eor	x1, x1, x1, lsr #9
    3e8c:	910003fd 	mov	x29, sp
    3e90:	92401c21 	and	x1, x1, #0xff
    3e94:	f9000bf3 	str	x19, [sp, #16]
    3e98:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    3e9c:	9114c262 	add	x2, x19, #0x530
    3ea0:	910a2423 	add	x3, x1, #0x289
    3ea4:	8b010c41 	add	x1, x2, x1, lsl #3
    3ea8:	8b030c43 	add	x3, x2, x3, lsl #3
    3eac:	f94a2421 	ldr	x1, [x1, #5192]
    3eb0:	b50000a1 	cbnz	x1, 3ec4 <fwp_rc_forget_slot.part.0+0x44>
    3eb4:	14000012 	b	3efc <fwp_rc_forget_slot.part.0+0x7c>
    3eb8:	91004023 	add	x3, x1, #0x10
    3ebc:	f9400821 	ldr	x1, [x1, #16]
    3ec0:	b40001e1 	cbz	x1, 3efc <fwp_rc_forget_slot.part.0+0x7c>
    3ec4:	f9400022 	ldr	x2, [x1]
    3ec8:	eb02001f 	cmp	x0, x2
    3ecc:	54ffff61 	b.ne	3eb8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    3ed0:	f9400060 	ldr	x0, [x3]
    3ed4:	9114c273 	add	x19, x19, #0x530
    3ed8:	f9400801 	ldr	x1, [x0, #16]
    3edc:	f9000061 	str	x1, [x3]
    3ee0:	97fffa78 	bl	28c0 <free@plt>
    3ee4:	f94e2660 	ldr	x0, [x19, #7240]
    3ee8:	d1000400 	sub	x0, x0, #0x1
    3eec:	f90e2660 	str	x0, [x19, #7240]
    3ef0:	f9400bf3 	ldr	x19, [sp, #16]
    3ef4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3ef8:	d65f03c0 	ret
    3efc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    3f00:	9132c000 	add	x0, x0, #0xcb0
    3f04:	97ffffbf 	bl	3e00 <fwp_trap>
    3f08:	d503201f 	nop
    3f0c:	d503201f 	nop

0000000000003f10 <fwp_rc_prepare_chunk>:
    3f10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3f14:	910003fd 	mov	x29, sp
    3f18:	a9025bf5 	stp	x21, x22, [sp, #32]
    3f1c:	d0000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    3f20:	9114c2c2 	add	x2, x22, #0x530
    3f24:	b9401c03 	ldr	w3, [x0, #28]
    3f28:	aa0103f5 	mov	x21, x1
    3f2c:	a90153f3 	stp	x19, x20, [sp, #16]
    3f30:	aa0003f4 	mov	x20, x0
    3f34:	f94e2440 	ldr	x0, [x2, #7240]
    3f38:	b4000440 	cbz	x0, 3fc0 <fwp_rc_prepare_chunk+0xb0>
    3f3c:	d2800013 	mov	x19, #0x0                   	// #0
    3f40:	35000203 	cbnz	w3, 3f80 <fwp_rc_prepare_chunk+0x70>
    3f44:	b4000361 	cbz	x1, 3fb0 <fwp_rc_prepare_chunk+0xa0>
    3f48:	f9401280 	ldr	x0, [x20, #32]
    3f4c:	97fffa5d 	bl	28c0 <free@plt>
    3f50:	aa1503e0 	mov	x0, x21
    3f54:	d2800021 	mov	x1, #0x1                   	// #1
    3f58:	97fffa22 	bl	27e0 <calloc@plt>
    3f5c:	f9001280 	str	x0, [x20, #32]
    3f60:	b5000460 	cbnz	x0, 3fec <fwp_rc_prepare_chunk+0xdc>
    3f64:	97fffc13 	bl	2fb0 <fwp_heap_oom>
    3f68:	97ffffc6 	bl	3e80 <fwp_rc_forget_slot.part.0>
    3f6c:	91000673 	add	x19, x19, #0x1
    3f70:	b9401e83 	ldr	w3, [x20, #28]
    3f74:	eb13007f 	cmp	x3, x19
    3f78:	54000169 	b.ls	3fa4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    3f7c:	d503201f 	nop
    3f80:	f9401283 	ldr	x3, [x20, #32]
    3f84:	8b130060 	add	x0, x3, x19
    3f88:	38736863 	ldrb	w3, [x3, x19]
    3f8c:	7103fc7f 	cmp	w3, #0xff
    3f90:	54fffec0 	b.eq	3f68 <fwp_rc_prepare_chunk+0x58>  // b.none
    3f94:	b9401e83 	ldr	w3, [x20, #28]
    3f98:	91000673 	add	x19, x19, #0x1
    3f9c:	eb13007f 	cmp	x3, x19
    3fa0:	54ffff08 	b.hi	3f80 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    3fa4:	eb0302bf 	cmp	x21, x3
    3fa8:	54000121 	b.ne	3fcc <fwp_rc_prepare_chunk+0xbc>  // b.any
    3fac:	b5000335 	cbnz	x21, 4010 <fwp_rc_prepare_chunk+0x100>
    3fb0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fb4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fb8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fbc:	d65f03c0 	ret
    3fc0:	2a0303e3 	mov	w3, w3
    3fc4:	eb0302bf 	cmp	x21, x3
    3fc8:	54ffff20 	b.eq	3fac <fwp_rc_prepare_chunk+0x9c>  // b.none
    3fcc:	9114c2c2 	add	x2, x22, #0x530
    3fd0:	f9401280 	ldr	x0, [x20, #32]
    3fd4:	f94e2841 	ldr	x1, [x2, #7248]
    3fd8:	cb030021 	sub	x1, x1, x3
    3fdc:	f90e2841 	str	x1, [x2, #7248]
    3fe0:	97fffa38 	bl	28c0 <free@plt>
    3fe4:	b5fffb75 	cbnz	x21, 3f50 <fwp_rc_prepare_chunk+0x40>
    3fe8:	f900129f 	str	xzr, [x20, #32]
    3fec:	9114c2d6 	add	x22, x22, #0x530
    3ff0:	f94e2ac0 	ldr	x0, [x22, #7248]
    3ff4:	b9001e95 	str	w21, [x20, #28]
    3ff8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3ffc:	8b150000 	add	x0, x0, x21
    4000:	f90e2ac0 	str	x0, [x22, #7248]
    4004:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4008:	a8c37bfd 	ldp	x29, x30, [sp], #48
    400c:	d65f03c0 	ret
    4010:	f9401280 	ldr	x0, [x20, #32]
    4014:	aa1503e2 	mov	x2, x21
    4018:	a94153f3 	ldp	x19, x20, [sp, #16]
    401c:	52800001 	mov	w1, #0x0                   	// #0
    4020:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4024:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4028:	17fff9ea 	b	27d0 <memset@plt>
    402c:	d503201f 	nop

0000000000004030 <fwp_heap_refill>:
    4030:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4034:	910003fd 	mov	x29, sp
    4038:	a9025bf5 	stp	x21, x22, [sp, #32]
    403c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4040:	9114c2b5 	add	x21, x21, #0x530
    4044:	aa0003f6 	mov	x22, x0
    4048:	d2800020 	mov	x0, #0x1                   	// #1
    404c:	a90153f3 	stp	x19, x20, [sp, #16]
    4050:	a90363f7 	stp	x23, x24, [sp, #48]
    4054:	2a0103f7 	mov	w23, w1
    4058:	2a0203f8 	mov	w24, w2
    405c:	97fffc15 	bl	30b0 <fwp_heap_chunks>
    4060:	aa0003f3 	mov	x19, x0
    4064:	f949fea2 	ldr	x2, [x21, #5112]
    4068:	8b000800 	add	x0, x0, x0, lsl #2
    406c:	2a1703e1 	mov	w1, w23
    4070:	52800025 	mov	w5, #0x1                   	// #1
    4074:	d37df000 	lsl	x0, x0, #3
    4078:	910f0021 	add	x1, x1, #0x3c0
    407c:	8b000054 	add	x20, x2, x0
    4080:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4084:	52a00024 	mov	w4, #0x10000               	// #65536
    4088:	38206845 	strb	w5, [x2, x0]
    408c:	aa1403e0 	mov	x0, x20
    4090:	39000698 	strb	w24, [x20, #1]
    4094:	39000a97 	strb	w23, [x20, #2]
    4098:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    409c:	b9000681 	str	w1, [x20, #4]
    40a0:	2a0103e5 	mov	w5, w1
    40a4:	8b0300a2 	add	x2, x5, x3
    40a8:	1ac10881 	udiv	w1, w4, w1
    40ac:	9ac50842 	udiv	x2, x2, x5
    40b0:	b9000a81 	str	w1, [x20, #8]
    40b4:	92404021 	and	x1, x1, #0x1ffff
    40b8:	b9001a82 	str	w2, [x20, #24]
    40bc:	97ffff95 	bl	3f10 <fwp_rc_prepare_chunk>
    40c0:	f949daa0 	ldr	x0, [x21, #5040]
    40c4:	29408a81 	ldp	w1, w2, [x20, #4]
    40c8:	8b134000 	add	x0, x0, x19, lsl #16
    40cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    40d0:	8b214003 	add	x3, x0, w1, uxtw
    40d4:	9ba20021 	umaddl	x1, w1, w2, x0
    40d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    40dc:	a90086c3 	stp	x3, x1, [x22, #8]
    40e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40e4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    40e8:	d65f03c0 	ret
    40ec:	d503201f 	nop

00000000000040f0 <fwp_mem_free>:
    40f0:	b40003c0 	cbz	x0, 4168 <fwp_mem_free+0x78>
    40f4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    40f8:	910003fd 	mov	x29, sp
    40fc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4100:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4104:	9114c2a1 	add	x1, x21, #0x530
    4108:	a90153f3 	stp	x19, x20, [sp, #16]
    410c:	aa0003f3 	mov	x19, x0
    4110:	f949d823 	ldr	x3, [x1, #5040]
    4114:	f949ec22 	ldr	x2, [x1, #5080]
    4118:	cb030000 	sub	x0, x0, x3
    411c:	eb02401f 	cmp	x0, x2, lsl #16
    4120:	540001c2 	b.cs	4158 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4124:	d350fc16 	lsr	x22, x0, #16
    4128:	a90363f7 	stp	x23, x24, [sp, #48]
    412c:	f949fc22 	ldr	x2, [x1, #5112]
    4130:	8b160ad4 	add	x20, x22, x22, lsl #2
    4134:	d37df294 	lsl	x20, x20, #3
    4138:	ab140057 	adds	x23, x2, x20
    413c:	540000c0 	b.eq	4154 <fwp_mem_free+0x64>  // b.none
    4140:	38746842 	ldrb	w2, [x2, x20]
    4144:	7100045f 	cmp	w2, #0x1
    4148:	54000120 	b.eq	416c <fwp_mem_free+0x7c>  // b.none
    414c:	7100085f 	cmp	w2, #0x2
    4150:	540005e0 	b.eq	420c <fwp_mem_free+0x11c>  // b.none
    4154:	a94363f7 	ldp	x23, x24, [sp, #48]
    4158:	a94153f3 	ldp	x19, x20, [sp, #16]
    415c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4160:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4164:	d65f03c0 	ret
    4168:	d65f03c0 	ret
    416c:	f94012f8 	ldr	x24, [x23, #32]
    4170:	b94006e1 	ldr	w1, [x23, #4]
    4174:	f90023f9 	str	x25, [sp, #64]
    4178:	2a0103e2 	mov	w2, w1
    417c:	394006f9 	ldrb	w25, [x23, #1]
    4180:	39400af4 	ldrb	w20, [x23, #2]
    4184:	b4000158 	cbz	x24, 41ac <fwp_mem_free+0xbc>
    4188:	92403e76 	and	x22, x19, #0xffff
    418c:	9ac20ad6 	udiv	x22, x22, x2
    4190:	38766b01 	ldrb	w1, [x24, x22]
    4194:	8b160300 	add	x0, x24, x22
    4198:	7103fc3f 	cmp	w1, #0xff
    419c:	54000980 	b.eq	42cc <fwp_mem_free+0x1dc>  // b.none
    41a0:	38366b1f 	strb	wzr, [x24, x22]
    41a4:	b94006e1 	ldr	w1, [x23, #4]
    41a8:	2a0103e2 	mov	w2, w1
    41ac:	d37c1f20 	ubfiz	x0, x25, #4, #8
    41b0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    41b4:	cb390000 	sub	x0, x0, w25, uxtb
    41b8:	8b340074 	add	x20, x3, w20, uxtb
    41bc:	9114c2b5 	add	x21, x21, #0x530
    41c0:	1e630021 	ucvtf	d1, w1
    41c4:	d37ae400 	lsl	x0, x0, #6
    41c8:	8b140c14 	add	x20, x0, x20, lsl #3
    41cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    41d0:	f8746aa0 	ldr	x0, [x21, x20]
    41d4:	f94023f9 	ldr	x25, [sp, #64]
    41d8:	aa2003e0 	mvn	x0, x0
    41dc:	fd4a22a0 	ldr	d0, [x21, #5184]
    41e0:	f9000260 	str	x0, [x19]
    41e4:	f8346ab3 	str	x19, [x21, x20]
    41e8:	f94a12a0 	ldr	x0, [x21, #5152]
    41ec:	1e612800 	fadd	d0, d0, d1
    41f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    41f4:	cb020000 	sub	x0, x0, x2
    41f8:	f90a12a0 	str	x0, [x21, #5152]
    41fc:	fd0a22a0 	str	d0, [x21, #5184]
    4200:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4204:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4208:	d65f03c0 	ret
    420c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4210:	8b000063 	add	x3, x3, x0
    4214:	eb03027f 	cmp	x19, x3
    4218:	54fff9e1 	b.ne	4154 <fwp_mem_free+0x64>  // b.any
    421c:	fd400ae1 	ldr	d1, [x23, #16]
    4220:	fd4a2020 	ldr	d0, [x1, #5184]
    4224:	f9400ae0 	ldr	x0, [x23, #16]
    4228:	7e61d821 	ucvtf	d1, d1
    422c:	f94a1022 	ldr	x2, [x1, #5152]
    4230:	f94012f3 	ldr	x19, [x23, #32]
    4234:	1e612800 	fadd	d0, d0, d1
    4238:	cb000042 	sub	x2, x2, x0
    423c:	f90a1022 	str	x2, [x1, #5152]
    4240:	fd0a2020 	str	d0, [x1, #5184]
    4244:	b40000b3 	cbz	x19, 4258 <fwp_mem_free+0x168>
    4248:	39400260 	ldrb	w0, [x19]
    424c:	7103fc1f 	cmp	w0, #0xff
    4250:	54000380 	b.eq	42c0 <fwp_mem_free+0x1d0>  // b.none
    4254:	3900027f 	strb	wzr, [x19]
    4258:	b9400ee2 	ldr	w2, [x23, #12]
    425c:	b4000142 	cbz	x2, 4284 <fwp_mem_free+0x194>
    4260:	9114c2a1 	add	x1, x21, #0x530
    4264:	8b160040 	add	x0, x2, x22
    4268:	8b000800 	add	x0, x0, x0, lsl #2
    426c:	f949fc21 	ldr	x1, [x1, #5112]
    4270:	8b140034 	add	x20, x1, x20
    4274:	8b000c20 	add	x0, x1, x0, lsl #3
    4278:	3802869f 	strb	wzr, [x20], #40
    427c:	eb00029f 	cmp	x20, x0
    4280:	54ffffc1 	b.ne	4278 <fwp_mem_free+0x188>  // b.any
    4284:	9114c2a0 	add	x0, x21, #0x530
    4288:	f94a1801 	ldr	x1, [x0, #5168]
    428c:	f949f803 	ldr	x3, [x0, #5104]
    4290:	8b020021 	add	x1, x1, x2
    4294:	f90a1801 	str	x1, [x0, #5168]
    4298:	eb16007f 	cmp	x3, x22
    429c:	54000049 	b.ls	42a4 <fwp_mem_free+0x1b4>  // b.plast
    42a0:	f909f816 	str	x22, [x0, #5104]
    42a4:	9114c2b5 	add	x21, x21, #0x530
    42a8:	f949f6a0 	ldr	x0, [x21, #5096]
    42ac:	eb16001f 	cmp	x0, x22
    42b0:	54fff529 	b.ls	4154 <fwp_mem_free+0x64>  // b.plast
    42b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    42b8:	f909f6b6 	str	x22, [x21, #5096]
    42bc:	17ffffa7 	b	4158 <fwp_mem_free+0x68>
    42c0:	aa1303e0 	mov	x0, x19
    42c4:	97fffeef 	bl	3e80 <fwp_rc_forget_slot.part.0>
    42c8:	17ffffe3 	b	4254 <fwp_mem_free+0x164>
    42cc:	97fffeed 	bl	3e80 <fwp_rc_forget_slot.part.0>
    42d0:	17ffffb4 	b	41a0 <fwp_mem_free+0xb0>

00000000000042d4 <fwp_rc_wide_dup>:
    42d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    42d8:	910003fd 	mov	x29, sp
    42dc:	a90153f3 	stp	x19, x20, [sp, #16]
    42e0:	aa0003f3 	mov	x19, x0
    42e4:	ca404400 	eor	x0, x0, x0, lsr #17
    42e8:	f90013f5 	str	x21, [sp, #32]
    42ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    42f0:	ca402400 	eor	x0, x0, x0, lsr #9
    42f4:	9114c2a2 	add	x2, x21, #0x530
    42f8:	92401c00 	and	x0, x0, #0xff
    42fc:	910a2403 	add	x3, x0, #0x289
    4300:	8b000c40 	add	x0, x2, x0, lsl #3
    4304:	8b030c54 	add	x20, x2, x3, lsl #3
    4308:	f94a2401 	ldr	x1, [x0, #5192]
    430c:	b50000a1 	cbnz	x1, 4320 <fwp_rc_wide_dup+0x4c>
    4310:	14000033 	b	43dc <fwp_rc_wide_dup+0x108>
    4314:	91004034 	add	x20, x1, #0x10
    4318:	f9400821 	ldr	x1, [x1, #16]
    431c:	b4000241 	cbz	x1, 4364 <fwp_rc_wide_dup+0x90>
    4320:	f9400022 	ldr	x2, [x1]
    4324:	eb02027f 	cmp	x19, x2
    4328:	54ffff61 	b.ne	4314 <fwp_rc_wide_dup+0x40>  // b.any
    432c:	f9400281 	ldr	x1, [x20]
    4330:	39400260 	ldrb	w0, [x19]
    4334:	7103f81f 	cmp	w0, #0xfe
    4338:	54000220 	b.eq	437c <fwp_rc_wide_dup+0xa8>  // b.none
    433c:	b40001a1 	cbz	x1, 4370 <fwp_rc_wide_dup+0x9c>
    4340:	f9400420 	ldr	x0, [x1, #8]
    4344:	b100041f 	cmn	x0, #0x1
    4348:	54000440 	b.eq	43d0 <fwp_rc_wide_dup+0xfc>  // b.none
    434c:	91000400 	add	x0, x0, #0x1
    4350:	f9000420 	str	x0, [x1, #8]
    4354:	a94153f3 	ldp	x19, x20, [sp, #16]
    4358:	f94013f5 	ldr	x21, [sp, #32]
    435c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4360:	d65f03c0 	ret
    4364:	39400260 	ldrb	w0, [x19]
    4368:	7103f81f 	cmp	w0, #0xfe
    436c:	54000100 	b.eq	438c <fwp_rc_wide_dup+0xb8>  // b.none
    4370:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    4374:	9132c000 	add	x0, x0, #0xcb0
    4378:	97fffea2 	bl	3e00 <fwp_trap>
    437c:	b4000081 	cbz	x1, 438c <fwp_rc_wide_dup+0xb8>
    4380:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    4384:	91336000 	add	x0, x0, #0xcd8
    4388:	97fffe9e 	bl	3e00 <fwp_trap>
    438c:	d2800300 	mov	x0, #0x18                  	// #24
    4390:	97fff904 	bl	27a0 <malloc@plt>
    4394:	b4000280 	cbz	x0, 43e4 <fwp_rc_wide_dup+0x110>
    4398:	d2801fe1 	mov	x1, #0xff                  	// #255
    439c:	a9000413 	stp	x19, x1, [x0]
    43a0:	9114c2b5 	add	x21, x21, #0x530
    43a4:	f900081f 	str	xzr, [x0, #16]
    43a8:	12800001 	mov	w1, #0xffffffff            	// #-1
    43ac:	f9000280 	str	x0, [x20]
    43b0:	39000261 	strb	w1, [x19]
    43b4:	f94e26a0 	ldr	x0, [x21, #7240]
    43b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    43bc:	91000400 	add	x0, x0, #0x1
    43c0:	f90e26a0 	str	x0, [x21, #7240]
    43c4:	f94013f5 	ldr	x21, [sp, #32]
    43c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43cc:	d65f03c0 	ret
    43d0:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    43d4:	91340000 	add	x0, x0, #0xd00
    43d8:	97fffe8a 	bl	3e00 <fwp_trap>
    43dc:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    43e0:	17ffffd4 	b	4330 <fwp_rc_wide_dup+0x5c>
    43e4:	97fffaf3 	bl	2fb0 <fwp_heap_oom>
    43e8:	d503201f 	nop
    43ec:	d503201f 	nop

00000000000043f0 <fwp_closure_drop_push>:
    43f0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    43f4:	910003fd 	mov	x29, sp
    43f8:	a90153f3 	stp	x19, x20, [sp, #16]
    43fc:	aa0003f3 	mov	x19, x0
    4400:	a9408014 	ldp	x20, x0, [x0, #8]
    4404:	a9025bf5 	stp	x21, x22, [sp, #32]
    4408:	aa0103f5 	mov	x21, x1
    440c:	a90363f7 	stp	x23, x24, [sp, #48]
    4410:	eb00029f 	cmp	x20, x0
    4414:	54000160 	b.eq	4440 <fwp_closure_drop_push+0x50>  // b.none
    4418:	f9400276 	ldr	x22, [x19]
    441c:	d37df297 	lsl	x23, x20, #3
    4420:	91000694 	add	x20, x20, #0x1
    4424:	f9000674 	str	x20, [x19, #8]
    4428:	a94153f3 	ldp	x19, x20, [sp, #16]
    442c:	f8376ad5 	str	x21, [x22, x23]
    4430:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4434:	a94363f7 	ldp	x23, x24, [sp, #48]
    4438:	a8c57bfd 	ldp	x29, x30, [sp], #80
    443c:	d65f03c0 	ret
    4440:	a9046bf9 	stp	x25, x26, [sp, #64]
    4444:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4448:	eb00029f 	cmp	x20, x0
    444c:	540003e8 	b.hi	44c8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4450:	d37cee99 	lsl	x25, x20, #4
    4454:	d37ffa9a 	lsl	x26, x20, #1
    4458:	aa1903e0 	mov	x0, x25
    445c:	97fff8d1 	bl	27a0 <malloc@plt>
    4460:	aa0003f6 	mov	x22, x0
    4464:	b4000380 	cbz	x0, 44d4 <fwp_closure_drop_push+0xe4>
    4468:	aa1303f8 	mov	x24, x19
    446c:	aa1903e3 	mov	x3, x25
    4470:	d37df297 	lsl	x23, x20, #3
    4474:	aa1703e2 	mov	x2, x23
    4478:	f8418719 	ldr	x25, [x24], #24
    447c:	aa1903e1 	mov	x1, x25
    4480:	97fff8b4 	bl	2750 <__memcpy_chk@plt>
    4484:	eb18033f 	cmp	x25, x24
    4488:	540000a0 	b.eq	449c <fwp_closure_drop_push+0xac>  // b.none
    448c:	aa1903e0 	mov	x0, x25
    4490:	97fff90c 	bl	28c0 <free@plt>
    4494:	f9400674 	ldr	x20, [x19, #8]
    4498:	d37df297 	lsl	x23, x20, #3
    449c:	91000694 	add	x20, x20, #0x1
    44a0:	f9000276 	str	x22, [x19]
    44a4:	f9000a7a 	str	x26, [x19, #16]
    44a8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    44ac:	f9000674 	str	x20, [x19, #8]
    44b0:	f8376ad5 	str	x21, [x22, x23]
    44b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44c0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44c4:	d65f03c0 	ret
    44c8:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    44cc:	91348000 	add	x0, x0, #0xd20
    44d0:	97fffe4c 	bl	3e00 <fwp_trap>
    44d4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    44d8:	f947e863 	ldr	x3, [x3, #4048]
    44dc:	d2800262 	mov	x2, #0x13                  	// #19
    44e0:	d2800021 	mov	x1, #0x1                   	// #1
    44e4:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    44e8:	912de000 	add	x0, x0, #0xb78
    44ec:	f9400063 	ldr	x3, [x3]
    44f0:	97fff904 	bl	2900 <fwrite@plt>
    44f4:	d2800000 	mov	x0, #0x0                   	// #0
    44f8:	97fff90e 	bl	2930 <fflush@plt>
    44fc:	52800cc0 	mov	w0, #0x66                  	// #102
    4500:	97fff91c 	bl	2970 <_Exit@plt>

0000000000004504 <fwp_closure_drop.part.0>:
    4504:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4508:	f0000021 	adrp	x1, b000 <_IO_stdin_used+0x490>
    450c:	910003fd 	mov	x29, sp
    4510:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    4514:	f947f463 	ldr	x3, [x3, #4072]
    4518:	a90153f3 	stp	x19, x20, [sp, #16]
    451c:	d10883ff 	sub	sp, sp, #0x220
    4520:	910003e2 	mov	x2, sp
    4524:	d53bd053 	mrs	x19, tpidr_el0
    4528:	910063f4 	add	x20, sp, #0x18
    452c:	3dc21020 	ldr	q0, [x1, #2112]
    4530:	91400264 	add	x4, x19, #0x0, lsl #12
    4534:	91004084 	add	x4, x4, #0x10
    4538:	aa0003e1 	mov	x1, x0
    453c:	aa0203e0 	mov	x0, x2
    4540:	f9400062 	ldr	x2, [x3]
    4544:	f9010fe2 	str	x2, [sp, #536]
    4548:	d2800002 	mov	x2, #0x0                   	// #0
    454c:	f90003f4 	str	x20, [sp]
    4550:	f9000080 	str	x0, [x4]
    4554:	3c8083e0 	stur	q0, [sp, #8]
    4558:	97ffffa6 	bl	43f0 <fwp_closure_drop_push>
    455c:	f94007e0 	ldr	x0, [sp, #8]
    4560:	b40002e0 	cbz	x0, 45bc <fwp_closure_drop.part.0+0xb8>
    4564:	f90123f5 	str	x21, [sp, #576]
    4568:	900000f5 	adrp	x21, 20000 <__data_start>
    456c:	9100c2b5 	add	x21, x21, #0x30
    4570:	14000006 	b	4588 <fwp_closure_drop.part.0+0x84>
    4574:	f9400422 	ldr	x2, [x1, #8]
    4578:	52800001 	mov	w1, #0x0                   	// #0
    457c:	d63f0040 	blr	x2
    4580:	f94007e0 	ldr	x0, [sp, #8]
    4584:	b40001a0 	cbz	x0, 45b8 <fwp_closure_drop.part.0+0xb4>
    4588:	f94003e1 	ldr	x1, [sp]
    458c:	d1000400 	sub	x0, x0, #0x1
    4590:	f90007e0 	str	x0, [sp, #8]
    4594:	f94036a2 	ldr	x2, [x21, #104]
    4598:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    459c:	b9400001 	ldr	w1, [x0]
    45a0:	8b011441 	add	x1, x2, x1, lsl #5
    45a4:	f9400c21 	ldr	x1, [x1, #24]
    45a8:	b5fffe61 	cbnz	x1, 4574 <fwp_closure_drop.part.0+0x70>
    45ac:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    45b0:	91350000 	add	x0, x0, #0xd40
    45b4:	97fffe13 	bl	3e00 <fwp_trap>
    45b8:	f94123f5 	ldr	x21, [sp, #576]
    45bc:	91400273 	add	x19, x19, #0x0, lsl #12
    45c0:	91004273 	add	x19, x19, #0x10
    45c4:	f94003e0 	ldr	x0, [sp]
    45c8:	f900027f 	str	xzr, [x19]
    45cc:	eb14001f 	cmp	x0, x20
    45d0:	54000040 	b.eq	45d8 <fwp_closure_drop.part.0+0xd4>  // b.none
    45d4:	97fff8bb 	bl	28c0 <free@plt>
    45d8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    45dc:	f947f400 	ldr	x0, [x0, #4072]
    45e0:	f9410fe2 	ldr	x2, [sp, #536]
    45e4:	f9400001 	ldr	x1, [x0]
    45e8:	eb010042 	subs	x2, x2, x1
    45ec:	d2800001 	mov	x1, #0x0                   	// #0
    45f0:	540000a1 	b.ne	4604 <fwp_closure_drop.part.0+0x100>  // b.any
    45f4:	910883ff 	add	sp, sp, #0x220
    45f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    45fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4600:	d65f03c0 	ret
    4604:	f90123f5 	str	x21, [sp, #576]
    4608:	97fff87e 	bl	2800 <__stack_chk_fail@plt>
    460c:	d503201f 	nop

0000000000004610 <fwp_tape_of>:
    4610:	aa0003e1 	mov	x1, x0
    4614:	92403c00 	and	x0, x0, #0xffff
    4618:	b40000e0 	cbz	x0, 4634 <fwp_tape_of+0x24>
    461c:	d1000403 	sub	x3, x0, #0x1
    4620:	900000e0 	adrp	x0, 20000 <__data_start>
    4624:	9100c002 	add	x2, x0, #0x30
    4628:	f9403842 	ldr	x2, [x2, #112]
    462c:	eb03005f 	cmp	x2, x3
    4630:	540000cc 	b.gt	4648 <fwp_tape_of+0x38>
    4634:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4638:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    463c:	9135c000 	add	x0, x0, #0xd70
    4640:	910003fd 	mov	x29, sp
    4644:	97fffdef 	bl	3e00 <fwp_trap>
    4648:	8b030462 	add	x2, x3, x3, lsl #1
    464c:	f9401804 	ldr	x4, [x0, #48]
    4650:	d37ef442 	lsl	x2, x2, #2
    4654:	cb030042 	sub	x2, x2, x3
    4658:	d37df042 	lsl	x2, x2, #3
    465c:	8b020080 	add	x0, x4, x2
    4660:	b9400403 	ldr	w3, [x0, #4]
    4664:	34fffe83 	cbz	w3, 4634 <fwp_tape_of+0x24>
    4668:	b8626882 	ldr	w2, [x4, x2]
    466c:	9350fc21 	asr	x1, x1, #16
    4670:	6b01005f 	cmp	w2, w1
    4674:	54fffe01 	b.ne	4634 <fwp_tape_of+0x24>  // b.any
    4678:	d65f03c0 	ret
    467c:	d503201f 	nop

0000000000004680 <fwp_now_ns>:
    4680:	d100c3ff 	sub	sp, sp, #0x30
    4684:	52800020 	mov	w0, #0x1                   	// #1
    4688:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    468c:	f947f442 	ldr	x2, [x2, #4072]
    4690:	910023e1 	add	x1, sp, #0x8
    4694:	a9027bfd 	stp	x29, x30, [sp, #32]
    4698:	910083fd 	add	x29, sp, #0x20
    469c:	f9400043 	ldr	x3, [x2]
    46a0:	f9000fe3 	str	x3, [sp, #24]
    46a4:	d2800003 	mov	x3, #0x0                   	// #0
    46a8:	97fff822 	bl	2730 <clock_gettime@plt>
    46ac:	350002c0 	cbnz	w0, 4704 <fwp_now_ns+0x84>
    46b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    46b4:	d2994003 	mov	x3, #0xca00                	// #51712
    46b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    46bc:	9b037c20 	mul	x0, x1, x3
    46c0:	9b437c21 	smulh	x1, x1, x3
    46c4:	ab020000 	adds	x0, x0, x2
    46c8:	937ffc42 	asr	x2, x2, #63
    46cc:	9a020021 	adc	x1, x1, x2
    46d0:	f100001f 	cmp	x0, #0x0
    46d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    46d8:	b50001c1 	cbnz	x1, 4710 <fwp_now_ns+0x90>
    46dc:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    46e0:	f947f421 	ldr	x1, [x1, #4072]
    46e4:	f9400fe3 	ldr	x3, [sp, #24]
    46e8:	f9400022 	ldr	x2, [x1]
    46ec:	eb020063 	subs	x3, x3, x2
    46f0:	d2800002 	mov	x2, #0x0                   	// #0
    46f4:	54000141 	b.ne	471c <fwp_now_ns+0x9c>  // b.any
    46f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    46fc:	9100c3ff 	add	sp, sp, #0x30
    4700:	d65f03c0 	ret
    4704:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    4708:	91370000 	add	x0, x0, #0xdc0
    470c:	97fffdbd 	bl	3e00 <fwp_trap>
    4710:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    4714:	91378000 	add	x0, x0, #0xde0
    4718:	97fffdba 	bl	3e00 <fwp_trap>
    471c:	97fff839 	bl	2800 <__stack_chk_fail@plt>

0000000000004720 <fwp_poll_events>:
    4720:	d10103ff 	sub	sp, sp, #0x40
    4724:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    4728:	f947f400 	ldr	x0, [x0, #4072]
    472c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4730:	910083fd 	add	x29, sp, #0x20
    4734:	f9001bf3 	str	x19, [sp, #48]
    4738:	900000f3 	adrp	x19, 20000 <__data_start>
    473c:	f9400001 	ldr	x1, [x0]
    4740:	f9000fe1 	str	x1, [sp, #24]
    4744:	d2800001 	mov	x1, #0x0                   	// #0
    4748:	97ffffce 	bl	4680 <fwp_now_ns>
    474c:	9100c261 	add	x1, x19, #0x30
    4750:	f9403c21 	ldr	x1, [x1, #120]
    4754:	b4000e01 	cbz	x1, 4914 <fwp_poll_events+0x1f4>
    4758:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    475c:	14000005 	b	4770 <fwp_poll_events+0x50>
    4760:	f9408821 	ldr	x1, [x1, #272]
    4764:	eb03005f 	cmp	x2, x3
    4768:	9a83d042 	csel	x2, x2, x3, le
    476c:	b40000c1 	cbz	x1, 4784 <fwp_poll_events+0x64>
    4770:	f9403423 	ldr	x3, [x1, #104]
    4774:	b6ffff62 	tbz	x2, #63, 4760 <fwp_poll_events+0x40>
    4778:	f9408821 	ldr	x1, [x1, #272]
    477c:	aa0303e2 	mov	x2, x3
    4780:	b5ffff81 	cbnz	x1, 4770 <fwp_poll_events+0x50>
    4784:	b7f80c82 	tbnz	x2, #63, 4914 <fwp_poll_events+0x1f4>
    4788:	cb000042 	sub	x2, x2, x0
    478c:	f100005f 	cmp	x2, #0x0
    4790:	540003ad 	b.le	4804 <fwp_poll_events+0xe4>
    4794:	d2869b60 	mov	x0, #0x34db                	// #13531
    4798:	d2884804 	mov	x4, #0x4240                	// #16960
    479c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    47a0:	f2a001e4 	movk	x4, #0xf, lsl #16
    47a4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    47a8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    47ac:	f2e86360 	movk	x0, #0x431b, lsl #48
    47b0:	9b407c40 	smulh	x0, x2, x0
    47b4:	9352fc00 	asr	x0, x0, #18
    47b8:	cb82fc00 	sub	x0, x0, x2, asr #63
    47bc:	9b048802 	msub	x2, x0, x4, x2
    47c0:	f100005f 	cmp	x2, #0x0
    47c4:	9a800400 	cinc	x0, x0, ne	// ne = any
    47c8:	eb01001f 	cmp	x0, x1
    47cc:	5400098c 	b.gt	48fc <fwp_poll_events+0x1dc>
    47d0:	340001a0 	cbz	w0, 4804 <fwp_poll_events+0xe4>
    47d4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    47d8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    47dc:	72a20c41 	movk	w1, #0x1062, lsl #16
    47e0:	9ba17c01 	umull	x1, w0, w1
    47e4:	d366fc23 	lsr	x3, x1, #38
    47e8:	aa0303e2 	mov	x2, x3
    47ec:	1b058063 	msub	w3, w3, w5, w0
    47f0:	9b247c63 	smull	x3, w3, w4
    47f4:	910023e0 	add	x0, sp, #0x8
    47f8:	d2800001 	mov	x1, #0x0                   	// #0
    47fc:	a9008fe2 	stp	x2, x3, [sp, #8]
    4800:	97fff834 	bl	28d0 <nanosleep@plt>
    4804:	97ffff9f 	bl	4680 <fwp_now_ns>
    4808:	9100c268 	add	x8, x19, #0x30
    480c:	aa0003e7 	mov	x7, x0
    4810:	4f000400 	movi	v0.4s, #0x0
    4814:	52800029 	mov	w9, #0x1                   	// #1
    4818:	f9403d06 	ldr	x6, [x8, #120]
    481c:	d503201f 	nop
    4820:	b40003e6 	cbz	x6, 489c <fwp_poll_events+0x17c>
    4824:	f94034c1 	ldr	x1, [x6, #104]
    4828:	aa0603e5 	mov	x5, x6
    482c:	f94088c6 	ldr	x6, [x6, #272]
    4830:	eb07003f 	cmp	x1, x7
    4834:	54ffff6c 	b.gt	4820 <fwp_poll_events+0x100>
    4838:	394154a0 	ldrb	w0, [x5, #85]
    483c:	36000120 	tbz	w0, #0, 4860 <fwp_poll_events+0x140>
    4840:	f94084a0 	ldr	x0, [x5, #264]
    4844:	b4000560 	cbz	x0, 48f0 <fwp_poll_events+0x1d0>
    4848:	f9008806 	str	x6, [x0, #272]
    484c:	b4000046 	cbz	x6, 4854 <fwp_poll_events+0x134>
    4850:	f90084c0 	str	x0, [x6, #264]
    4854:	910800a0 	add	x0, x5, #0x200
    4858:	390154bf 	strb	wzr, [x5, #85]
    485c:	3c908000 	stur	q0, [x0, #-248]
    4860:	f94030a0 	ldr	x0, [x5, #96]
    4864:	390158a9 	strb	w9, [x5, #86]
    4868:	f100001f 	cmp	x0, #0x0
    486c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4870:	540002cd 	b.le	48c8 <fwp_poll_events+0x1a8>
    4874:	f94028a0 	ldr	x0, [x5, #80]
    4878:	f2001c1f 	tst	x0, #0xff000000ff
    487c:	54fffd21 	b.ne	4820 <fwp_poll_events+0x100>  // b.any
    4880:	f9401500 	ldr	x0, [x8, #40]
    4884:	390150a9 	strb	w9, [x5, #84]
    4888:	f90080bf 	str	xzr, [x5, #256]
    488c:	b40002c0 	cbz	x0, 48e4 <fwp_poll_events+0x1c4>
    4890:	f9001505 	str	x5, [x8, #40]
    4894:	f9008005 	str	x5, [x0, #256]
    4898:	b5fffc66 	cbnz	x6, 4824 <fwp_poll_events+0x104>
    489c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    48a0:	f947f400 	ldr	x0, [x0, #4072]
    48a4:	f9400fe2 	ldr	x2, [sp, #24]
    48a8:	f9400001 	ldr	x1, [x0]
    48ac:	eb010042 	subs	x2, x2, x1
    48b0:	d2800001 	mov	x1, #0x0                   	// #0
    48b4:	540002e1 	b.ne	4910 <fwp_poll_events+0x1f0>  // b.any
    48b8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    48bc:	f9401bf3 	ldr	x19, [sp, #48]
    48c0:	910103ff 	add	sp, sp, #0x40
    48c4:	d65f03c0 	ret
    48c8:	394144a0 	ldrb	w0, [x5, #81]
    48cc:	3707fd40 	tbnz	w0, #0, 4874 <fwp_poll_events+0x154>
    48d0:	394140a0 	ldrb	w0, [x5, #80]
    48d4:	3707fd00 	tbnz	w0, #0, 4874 <fwp_poll_events+0x154>
    48d8:	aa0503e0 	mov	x0, x5
    48dc:	97fffac5 	bl	33f0 <fwp_cancel_tree.part.0>
    48e0:	17ffffe5 	b	4874 <fwp_poll_events+0x154>
    48e4:	f9001505 	str	x5, [x8, #40]
    48e8:	f9001905 	str	x5, [x8, #48]
    48ec:	17ffffeb 	b	4898 <fwp_poll_events+0x178>
    48f0:	9100c261 	add	x1, x19, #0x30
    48f4:	f9003c26 	str	x6, [x1, #120]
    48f8:	17ffffd5 	b	484c <fwp_poll_events+0x12c>
    48fc:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4900:	d2989362 	mov	x2, #0xc49b                	// #50331
    4904:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4908:	f2a00402 	movk	x2, #0x20, lsl #16
    490c:	17ffffba 	b	47f4 <fwp_poll_events+0xd4>
    4910:	97fff7bc 	bl	2800 <__stack_chk_fail@plt>
    4914:	97fff997 	bl	2f70 <fwp_flush>
    4918:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    491c:	f947e863 	ldr	x3, [x3, #4048]
    4920:	d2800562 	mov	x2, #0x2b                  	// #43
    4924:	d2800021 	mov	x1, #0x1                   	// #1
    4928:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    492c:	91382000 	add	x0, x0, #0xe08
    4930:	f9400063 	ldr	x3, [x3]
    4934:	97fff7f3 	bl	2900 <fwrite@plt>
    4938:	52800ca0 	mov	w0, #0x65                  	// #101
    493c:	97fff75d 	bl	26b0 <exit@plt>

0000000000004940 <fwp_heap_alloc_big>:
    4940:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4944:	910003fd 	mov	x29, sp
    4948:	a90153f3 	stp	x19, x20, [sp, #16]
    494c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4950:	a90363f7 	stp	x23, x24, [sp, #48]
    4954:	aa0003f7 	mov	x23, x0
    4958:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    495c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4960:	eb0002ff 	cmp	x23, x0
    4964:	540008a8 	b.hi	4a78 <fwp_heap_alloc_big+0x138>  // b.pmore
    4968:	d29fffe0 	mov	x0, #0xffff                	// #65535
    496c:	8b0002f4 	add	x20, x23, x0
    4970:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xcb0>
    4974:	9114c359 	add	x25, x26, #0x530
    4978:	d350fe94 	lsr	x20, x20, #16
    497c:	2a0103f5 	mov	w21, w1
    4980:	aa1403e0 	mov	x0, x20
    4984:	97fff9cb 	bl	30b0 <fwp_heap_chunks>
    4988:	f949ff22 	ldr	x2, [x25, #5112]
    498c:	8b000813 	add	x19, x0, x0, lsl #2
    4990:	aa0003f8 	mov	x24, x0
    4994:	52800043 	mov	w3, #0x2                   	// #2
    4998:	d37df273 	lsl	x19, x19, #3
    499c:	d2800021 	mov	x1, #0x1                   	// #1
    49a0:	8b130040 	add	x0, x2, x19
    49a4:	38336843 	strb	w3, [x2, x19]
    49a8:	39000415 	strb	w21, [x0, #1]
    49ac:	b9000c14 	str	w20, [x0, #12]
    49b0:	f9000817 	str	x23, [x0, #16]
    49b4:	97fffd57 	bl	3f10 <fwp_rc_prepare_chunk>
    49b8:	f100069f 	cmp	x20, #0x1
    49bc:	54000289 	b.ls	4a0c <fwp_heap_alloc_big+0xcc>  // b.plast
    49c0:	8b180294 	add	x20, x20, x24
    49c4:	9100a273 	add	x19, x19, #0x28
    49c8:	a90573fb 	stp	x27, x28, [sp, #80]
    49cc:	5280007b 	mov	w27, #0x3                   	// #3
    49d0:	8b140a94 	add	x20, x20, x20, lsl #2
    49d4:	2a1803fc 	mov	w28, w24
    49d8:	9adb2296 	lsl	x22, x20, x27
    49dc:	d503201f 	nop
    49e0:	f949ff35 	ldr	x21, [x25, #5112]
    49e4:	d2800001 	mov	x1, #0x0                   	// #0
    49e8:	8b1302b4 	add	x20, x21, x19
    49ec:	aa1403e0 	mov	x0, x20
    49f0:	97fffd48 	bl	3f10 <fwp_rc_prepare_chunk>
    49f4:	38336abb 	strb	w27, [x21, x19]
    49f8:	9100a273 	add	x19, x19, #0x28
    49fc:	b9000e9c 	str	w28, [x20, #12]
    4a00:	eb1302df 	cmp	x22, x19
    4a04:	54fffee1 	b.ne	49e0 <fwp_heap_alloc_big+0xa0>  // b.any
    4a08:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a0c:	9114c353 	add	x19, x26, #0x530
    4a10:	aa1703e2 	mov	x2, x23
    4a14:	52800001 	mov	w1, #0x0                   	// #0
    4a18:	f949da60 	ldr	x0, [x19, #5040]
    4a1c:	8b184018 	add	x24, x0, x24, lsl #16
    4a20:	aa1803e0 	mov	x0, x24
    4a24:	97fff76b 	bl	27d0 <memset@plt>
    4a28:	f94a1260 	ldr	x0, [x19, #5152]
    4a2c:	ab170000 	adds	x0, x0, x23
    4a30:	54000242 	b.cs	4a78 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4a34:	f94a1661 	ldr	x1, [x19, #5160]
    4a38:	f90a1260 	str	x0, [x19, #5152]
    4a3c:	eb01001f 	cmp	x0, x1
    4a40:	54000049 	b.ls	4a48 <fwp_heap_alloc_big+0x108>  // b.plast
    4a44:	f90a1660 	str	x0, [x19, #5160]
    4a48:	9114c35a 	add	x26, x26, #0x530
    4a4c:	9e6202e0 	scvtf	d0, x23
    4a50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a54:	aa1803e0 	mov	x0, x24
    4a58:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a60:	1e602820 	fadd	d0, d1, d0
    4a64:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a68:	fd0a1f40 	str	d0, [x26, #5176]
    4a6c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a70:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a74:	d65f03c0 	ret
    4a78:	a90573fb 	stp	x27, x28, [sp, #80]
    4a7c:	97fff94d 	bl	2fb0 <fwp_heap_oom>

0000000000004a80 <fwp_heap_alloc_slow>:
    4a80:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a84:	910003fd 	mov	x29, sp
    4a88:	a90153f3 	stp	x19, x20, [sp, #16]
    4a8c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    4a90:	9114c262 	add	x2, x19, #0x530
    4a94:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a98:	aa0003f5 	mov	x21, x0
    4a9c:	2a0103f4 	mov	w20, w1
    4aa0:	b953a440 	ldr	w0, [x2, #5028]
    4aa4:	34000600 	cbz	w0, 4b64 <fwp_heap_alloc_slow+0xe4>
    4aa8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4aac:	54000628 	b.hi	4b70 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ab0:	91003ea0 	add	x0, x21, #0xf
    4ab4:	9114c262 	add	x2, x19, #0x530
    4ab8:	f9001bf7 	str	x23, [sp, #48]
    4abc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ac0:	8b401040 	add	x0, x2, x0, lsr #4
    4ac4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ac8:	d37ae484 	lsl	x4, x4, #6
    4acc:	397e8003 	ldrb	w3, [x0, #4000]
    4ad0:	910f0060 	add	x0, x3, #0x3c0
    4ad4:	aa0303e1 	mov	x1, x3
    4ad8:	8b030463 	add	x3, x3, x3, lsl #1
    4adc:	8b030c83 	add	x3, x4, x3, lsl #3
    4ae0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4ae4:	2a1703f6 	mov	w22, w23
    4ae8:	f8636844 	ldr	x4, [x2, x3]
    4aec:	b40004e4 	cbz	x4, 4b88 <fwp_heap_alloc_slow+0x108>
    4af0:	f9400080 	ldr	x0, [x4]
    4af4:	aa2003e0 	mvn	x0, x0
    4af8:	f8236840 	str	x0, [x2, x3]
    4afc:	7100069f 	cmp	w20, #0x1
    4b00:	aa0403e0 	mov	x0, x4
    4b04:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b08:	52800001 	mov	w1, #0x0                   	// #0
    4b0c:	97fff731 	bl	27d0 <memset@plt>
    4b10:	aa0003e4 	mov	x4, x0
    4b14:	9114c260 	add	x0, x19, #0x530
    4b18:	f94a1001 	ldr	x1, [x0, #5152]
    4b1c:	ab160021 	adds	x1, x1, x22
    4b20:	540005c2 	b.cs	4bd8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b24:	f94a1402 	ldr	x2, [x0, #5160]
    4b28:	f90a1001 	str	x1, [x0, #5152]
    4b2c:	eb02003f 	cmp	x1, x2
    4b30:	54000049 	b.ls	4b38 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b34:	f90a1401 	str	x1, [x0, #5160]
    4b38:	9114c273 	add	x19, x19, #0x530
    4b3c:	1e6302e1 	ucvtf	d1, w23
    4b40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b44:	aa0403e0 	mov	x0, x4
    4b48:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b4c:	f9401bf7 	ldr	x23, [sp, #48]
    4b50:	1e612800 	fadd	d0, d0, d1
    4b54:	fd0a1e60 	str	d0, [x19, #5176]
    4b58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b60:	d65f03c0 	ret
    4b64:	97fffbc3 	bl	3a70 <fwp_heap_init>
    4b68:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b6c:	54fffa29 	b.ls	4ab0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b70:	2a1403e1 	mov	w1, w20
    4b74:	aa1503e0 	mov	x0, x21
    4b78:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b80:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b84:	17ffff6f 	b	4940 <fwp_heap_alloc_big>
    4b88:	8b030042 	add	x2, x2, x3
    4b8c:	f9400444 	ldr	x4, [x2, #8]
    4b90:	b4000104 	cbz	x4, 4bb0 <fwp_heap_alloc_slow+0x130>
    4b94:	f9400840 	ldr	x0, [x2, #16]
    4b98:	cb040000 	sub	x0, x0, x4
    4b9c:	eb16001f 	cmp	x0, x22
    4ba0:	54000083 	b.cc	4bb0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4ba4:	8b160080 	add	x0, x4, x22
    4ba8:	f9000440 	str	x0, [x2, #8]
    4bac:	17ffffd4 	b	4afc <fwp_heap_alloc_slow+0x7c>
    4bb0:	52800302 	mov	w2, #0x18                  	// #24
    4bb4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bb8:	9114c260 	add	x0, x19, #0x530
    4bbc:	9ba27c23 	umull	x3, w1, w2
    4bc0:	2a1403e2 	mov	w2, w20
    4bc4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bc8:	8b040000 	add	x0, x0, x4
    4bcc:	97fffd19 	bl	4030 <fwp_heap_refill>
    4bd0:	aa0003e4 	mov	x4, x0
    4bd4:	17ffffca 	b	4afc <fwp_heap_alloc_slow+0x7c>
    4bd8:	97fff8f6 	bl	2fb0 <fwp_heap_oom>
    4bdc:	d503201f 	nop

0000000000004be0 <fwp_heap_alloc>:
    4be0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4be4:	f140101f 	cmp	x0, #0x4, lsl #12
    4be8:	910003fd 	mov	x29, sp
    4bec:	a90153f3 	stp	x19, x20, [sp, #16]
    4bf0:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    4bf4:	9114c293 	add	x19, x20, #0x530
    4bf8:	b953a662 	ldr	w2, [x19, #5028]
    4bfc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c00:	54000640 	b.eq	4cc8 <fwp_heap_alloc+0xe8>  // b.none
    4c04:	91003c03 	add	x3, x0, #0xf
    4c08:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c0c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c10:	8b431263 	add	x3, x19, x3, lsr #4
    4c14:	cb21c042 	sub	x2, x2, w1, sxtw
    4c18:	d37ae442 	lsl	x2, x2, #6
    4c1c:	397e8063 	ldrb	w3, [x3, #4000]
    4c20:	910f0064 	add	x4, x3, #0x3c0
    4c24:	8b030463 	add	x3, x3, x3, lsl #1
    4c28:	8b030c43 	add	x3, x2, x3, lsl #3
    4c2c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c30:	2a1603f5 	mov	w21, w22
    4c34:	f8636a64 	ldr	x4, [x19, x3]
    4c38:	b4000384 	cbz	x4, 4ca8 <fwp_heap_alloc+0xc8>
    4c3c:	f9400085 	ldr	x5, [x4]
    4c40:	7100043f 	cmp	w1, #0x1
    4c44:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c48:	aa0403e0 	mov	x0, x4
    4c4c:	aa2503e5 	mvn	x5, x5
    4c50:	52800001 	mov	w1, #0x0                   	// #0
    4c54:	f8236a65 	str	x5, [x19, x3]
    4c58:	97fff6de 	bl	27d0 <memset@plt>
    4c5c:	aa0003e4 	mov	x4, x0
    4c60:	f94a1260 	ldr	x0, [x19, #5152]
    4c64:	ab150000 	adds	x0, x0, x21
    4c68:	54000442 	b.cs	4cf0 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c6c:	f94a1661 	ldr	x1, [x19, #5160]
    4c70:	f90a1260 	str	x0, [x19, #5152]
    4c74:	eb01001f 	cmp	x0, x1
    4c78:	54000049 	b.ls	4c80 <fwp_heap_alloc+0xa0>  // b.plast
    4c7c:	f90a1660 	str	x0, [x19, #5160]
    4c80:	9114c294 	add	x20, x20, #0x530
    4c84:	1e6302c1 	ucvtf	d1, w22
    4c88:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c8c:	aa0403e0 	mov	x0, x4
    4c90:	fd4a1e80 	ldr	d0, [x20, #5176]
    4c94:	1e612800 	fadd	d0, d0, d1
    4c98:	fd0a1e80 	str	d0, [x20, #5176]
    4c9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ca0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ca4:	d65f03c0 	ret
    4ca8:	8b030263 	add	x3, x19, x3
    4cac:	f9400464 	ldr	x4, [x3, #8]
    4cb0:	b40000a4 	cbz	x4, 4cc4 <fwp_heap_alloc+0xe4>
    4cb4:	f9400862 	ldr	x2, [x3, #16]
    4cb8:	cb040042 	sub	x2, x2, x4
    4cbc:	eb15005f 	cmp	x2, x21
    4cc0:	540000a2 	b.cs	4cd4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cc4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ccc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cd0:	17ffff6c 	b	4a80 <fwp_heap_alloc_slow>
    4cd4:	7100043f 	cmp	w1, #0x1
    4cd8:	8b150085 	add	x5, x4, x21
    4cdc:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	aa0403e0 	mov	x0, x4
    4ce8:	f9000465 	str	x5, [x3, #8]
    4cec:	17ffffdb 	b	4c58 <fwp_heap_alloc+0x78>
    4cf0:	97fff8b0 	bl	2fb0 <fwp_heap_oom>

0000000000004cf4 <fwp_data.part.0.constprop.0>:
    4cf4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4cf8:	910003fd 	mov	x29, sp
    4cfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4d00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    4d04:	9114c283 	add	x3, x20, #0x530
    4d08:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d0c:	aa0103f5 	mov	x21, x1
    4d10:	b953a461 	ldr	w1, [x3, #5028]
    4d14:	a90363f7 	stp	x23, x24, [sp, #48]
    4d18:	2a0003f8 	mov	w24, w0
    4d1c:	34000701 	cbz	w1, 4dfc <fwp_data.part.0.constprop.0+0x108>
    4d20:	397e8862 	ldrb	w2, [x3, #4002]
    4d24:	910f0040 	add	x0, x2, #0x3c0
    4d28:	8b020442 	add	x2, x2, x2, lsl #1
    4d2c:	d37df042 	lsl	x2, x2, #3
    4d30:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4d34:	2a1703f6 	mov	w22, w23
    4d38:	f8626873 	ldr	x19, [x3, x2]
    4d3c:	b40004d3 	cbz	x19, 4dd4 <fwp_data.part.0.constprop.0+0xe0>
    4d40:	f9400260 	ldr	x0, [x19]
    4d44:	aa2003e0 	mvn	x0, x0
    4d48:	f8226860 	str	x0, [x3, x2]
    4d4c:	f10062df 	cmp	x22, #0x18
    4d50:	540000e9 	b.ls	4d6c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4d54:	d10066c2 	sub	x2, x22, #0x19
    4d58:	91006260 	add	x0, x19, #0x18
    4d5c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4d60:	52800001 	mov	w1, #0x0                   	// #0
    4d64:	91002042 	add	x2, x2, #0x8
    4d68:	97fff69a 	bl	27d0 <memset@plt>
    4d6c:	9114c282 	add	x2, x20, #0x530
    4d70:	f94a1041 	ldr	x1, [x2, #5152]
    4d74:	ab160021 	adds	x1, x1, x22
    4d78:	540004c2 	b.cs	4e10 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4d7c:	f94a1440 	ldr	x0, [x2, #5160]
    4d80:	f90a1041 	str	x1, [x2, #5152]
    4d84:	eb00003f 	cmp	x1, x0
    4d88:	54000049 	b.ls	4d90 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4d8c:	f90a1441 	str	x1, [x2, #5160]
    4d90:	9114c294 	add	x20, x20, #0x530
    4d94:	1e6302e1 	ucvtf	d1, w23
    4d98:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d9c:	1e612800 	fadd	d0, d0, d1
    4da0:	fd0a1e80 	str	d0, [x20, #5176]
    4da4:	52800041 	mov	w1, #0x2                   	// #2
    4da8:	29000678 	stp	w24, w1, [x19]
    4dac:	aa1303e0 	mov	x0, x19
    4db0:	f94002a1 	ldr	x1, [x21]
    4db4:	f9000661 	str	x1, [x19, #8]
    4db8:	f94006a1 	ldr	x1, [x21, #8]
    4dbc:	f9000a61 	str	x1, [x19, #16]
    4dc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4dc4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4dc8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dcc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4dd0:	d65f03c0 	ret
    4dd4:	8b020063 	add	x3, x3, x2
    4dd8:	f9400473 	ldr	x19, [x3, #8]
    4ddc:	b4000113 	cbz	x19, 4dfc <fwp_data.part.0.constprop.0+0x108>
    4de0:	f9400860 	ldr	x0, [x3, #16]
    4de4:	cb130000 	sub	x0, x0, x19
    4de8:	eb0002df 	cmp	x22, x0
    4dec:	54000088 	b.hi	4dfc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4df0:	8b160260 	add	x0, x19, x22
    4df4:	f9000460 	str	x0, [x3, #8]
    4df8:	17ffffd5 	b	4d4c <fwp_data.part.0.constprop.0+0x58>
    4dfc:	52800001 	mov	w1, #0x0                   	// #0
    4e00:	d2800300 	mov	x0, #0x18                  	// #24
    4e04:	97ffff77 	bl	4be0 <fwp_heap_alloc>
    4e08:	aa0003f3 	mov	x19, x0
    4e0c:	17ffffe6 	b	4da4 <fwp_data.part.0.constprop.0+0xb0>
    4e10:	97fff868 	bl	2fb0 <fwp_heap_oom>

0000000000004e14 <fwp_tape_grow.constprop.0>:
    4e14:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4e18:	d2800802 	mov	x2, #0x40                  	// #64
    4e1c:	910003fd 	mov	x29, sp
    4e20:	a90153f3 	stp	x19, x20, [sp, #16]
    4e24:	aa0003f4 	mov	x20, x0
    4e28:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    4e2c:	f9400e93 	ldr	x19, [x20, #24]
    4e30:	f100027f 	cmp	x19, #0x0
    4e34:	9a821273 	csel	x19, x19, x2, ne	// ne = any
    4e38:	eb13003f 	cmp	x1, x19
    4e3c:	540000ed 	b.le	4e58 <fwp_tape_grow.constprop.0+0x44>
    4e40:	eb00027f 	cmp	x19, x0
    4e44:	5400064d 	b.le	4f0c <fwp_tape_grow.constprop.0+0xf8>
    4e48:	b2407bf3 	mov	x19, #0x7fffffff            	// #2147483647
    4e4c:	eb13003f 	cmp	x1, x19
    4e50:	5400004d 	b.le	4e58 <fwp_tape_grow.constprop.0+0x44>
    4e54:	14000000 	b	4e54 <fwp_tape_grow.constprop.0+0x40>
    4e58:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e5c:	f9402a95 	ldr	x21, [x20, #80]
    4e60:	b40005b5 	cbz	x21, 4f14 <fwp_tape_grow.constprop.0+0x100>
    4e64:	f9401680 	ldr	x0, [x20, #40]
    4e68:	d37df261 	lsl	x1, x19, #3
    4e6c:	97fff661 	bl	27f0 <realloc@plt>
    4e70:	b40006e0 	cbz	x0, 4f4c <fwp_tape_grow.constprop.0+0x138>
    4e74:	f94032b6 	ldr	x22, [x21, #96]
    4e78:	f9001680 	str	x0, [x20, #40]
    4e7c:	eb1302df 	cmp	x22, x19
    4e80:	540003ca 	b.ge	4ef8 <fwp_tape_grow.constprop.0+0xe4>  // b.tcont
    4e84:	a90363f7 	stp	x23, x24, [sp, #48]
    4e88:	92ff0000 	mov	x0, #0x7ffffffffffffff     	// #576460752303423487
    4e8c:	f90023f9 	str	x25, [sp, #64]
    4e90:	eb00027f 	cmp	x19, x0
    4e94:	54000568 	b.hi	4f40 <fwp_tape_grow.constprop.0+0x12c>  // b.pmore
    4e98:	f94022b8 	ldr	x24, [x21, #64]
    4e9c:	d37cee79 	lsl	x25, x19, #4
    4ea0:	aa1903e0 	mov	x0, x25
    4ea4:	52800041 	mov	w1, #0x2                   	// #2
    4ea8:	97ffff4e 	bl	4be0 <fwp_heap_alloc>
    4eac:	aa0003f7 	mov	x23, x0
    4eb0:	b4000118 	cbz	x24, 4ed0 <fwp_tape_grow.constprop.0+0xbc>
    4eb4:	d37ceed6 	lsl	x22, x22, #4
    4eb8:	aa1803e1 	mov	x1, x24
    4ebc:	eb1902df 	cmp	x22, x25
    4ec0:	9a9992c2 	csel	x2, x22, x25, ls	// ls = plast
    4ec4:	97fff5e7 	bl	2660 <memcpy@plt>
    4ec8:	aa1803e0 	mov	x0, x24
    4ecc:	97fffc89 	bl	40f0 <fwp_mem_free>
    4ed0:	f94032a0 	ldr	x0, [x21, #96]
    4ed4:	52800001 	mov	w1, #0x0                   	// #0
    4ed8:	cb000262 	sub	x2, x19, x0
    4edc:	8b0012e0 	add	x0, x23, x0, lsl #4
    4ee0:	d37cec42 	lsl	x2, x2, #4
    4ee4:	97fff63b 	bl	27d0 <memset@plt>
    4ee8:	f94023f9 	ldr	x25, [sp, #64]
    4eec:	f90022b7 	str	x23, [x21, #64]
    4ef0:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ef4:	f90032b3 	str	x19, [x21, #96]
    4ef8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4efc:	f9000e93 	str	x19, [x20, #24]
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4f08:	d65f03c0 	ret
    4f0c:	d37ffa73 	lsl	x19, x19, #1
    4f10:	17ffffca 	b	4e38 <fwp_tape_grow.constprop.0+0x24>
    4f14:	f9401280 	ldr	x0, [x20, #32]
    4f18:	8b130661 	add	x1, x19, x19, lsl #1
    4f1c:	d37df021 	lsl	x1, x1, #3
    4f20:	97fff634 	bl	27f0 <realloc@plt>
    4f24:	b4000140 	cbz	x0, 4f4c <fwp_tape_grow.constprop.0+0x138>
    4f28:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f2c:	f9000e93 	str	x19, [x20, #24]
    4f30:	f9001280 	str	x0, [x20, #32]
    4f34:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f38:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4f3c:	d65f03c0 	ret
    4f40:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    4f44:	91398000 	add	x0, x0, #0xe60
    4f48:	97fffbae 	bl	3e00 <fwp_trap>
    4f4c:	aa1403e0 	mov	x0, x20
    4f50:	a90363f7 	stp	x23, x24, [sp, #48]
    4f54:	f90023f9 	str	x25, [sp, #64]
    4f58:	97fff7ee 	bl	2f10 <fwp_tape_unlink_scope>
    4f5c:	f9401280 	ldr	x0, [x20, #32]
    4f60:	97fff658 	bl	28c0 <free@plt>
    4f64:	f9401680 	ldr	x0, [x20, #40]
    4f68:	97fff656 	bl	28c0 <free@plt>
    4f6c:	f9401a80 	ldr	x0, [x20, #48]
    4f70:	97fff654 	bl	28c0 <free@plt>
    4f74:	f9000e9f 	str	xzr, [x20, #24]
    4f78:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    4f7c:	f947e821 	ldr	x1, [x1, #4048]
    4f80:	a9037e9f 	stp	xzr, xzr, [x20, #48]
    4f84:	d2800262 	mov	x2, #0x13                  	// #19
    4f88:	4f000400 	movi	v0.4s, #0x0
    4f8c:	d0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    4f90:	f9400023 	ldr	x3, [x1]
    4f94:	b900069f 	str	wzr, [x20, #4]
    4f98:	d2800021 	mov	x1, #0x1                   	// #1
    4f9c:	912de000 	add	x0, x0, #0xb78
    4fa0:	3c808280 	stur	q0, [x20, #8]
    4fa4:	3d800a80 	str	q0, [x20, #32]
    4fa8:	97fff656 	bl	2900 <fwrite@plt>
    4fac:	d2800000 	mov	x0, #0x0                   	// #0
    4fb0:	97fff660 	bl	2930 <fflush@plt>
    4fb4:	52800cc0 	mov	w0, #0x66                  	// #102
    4fb8:	97fff66e 	bl	2970 <_Exit@plt>
    4fbc:	d503201f 	nop

0000000000004fc0 <w123>:
    4fc0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4fc4:	910003fd 	mov	x29, sp
    4fc8:	6d0427e8 	stp	d8, d9, [sp, #64]
    4fcc:	1e612808 	fadd	d8, d0, d1
    4fd0:	ea01001f 	tst	x0, x1
    4fd4:	54000b44 	b.mi	513c <w123+0x17c>  // b.first
    4fd8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fdc:	aa0003f4 	mov	x20, x0
    4fe0:	aa0103f3 	mov	x19, x1
    4fe4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fe8:	aa010000 	orr	x0, x0, x1
    4fec:	aa0203f5 	mov	x21, x2
    4ff0:	f9001bf7 	str	x23, [sp, #48]
    4ff4:	b7f80200 	tbnz	x0, #63, 5034 <w123+0x74>
    4ff8:	9360fc37 	asr	x23, x1, #32
    4ffc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5000:	eb9482ff 	cmp	x23, x20, asr #32
    5004:	54000a61 	b.ne	5150 <w123+0x190>  // b.any
    5008:	f94002a0 	ldr	x0, [x21]
    500c:	eb17001f 	cmp	x0, x23
    5010:	54000220 	b.eq	5054 <w123+0x94>  // b.none
    5014:	aa1703e0 	mov	x0, x23
    5018:	97fffd7e 	bl	4610 <fwp_tape_of>
    501c:	aa0003f6 	mov	x22, x0
    5020:	f9402800 	ldr	x0, [x0, #80]
    5024:	b40002e0 	cbz	x0, 5080 <w123+0xc0>
    5028:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    502c:	913b2000 	add	x0, x0, #0xec8
    5030:	97fffb74 	bl	3e00 <fwp_trap>
    5034:	b6f80214 	tbz	x20, #63, 5074 <w123+0xb4>
    5038:	f94002a0 	ldr	x0, [x21]
    503c:	9360fc37 	asr	x23, x1, #32
    5040:	2f00e409 	movi	d9, #0x0
    5044:	aa0103f4 	mov	x20, x1
    5048:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    504c:	eb17001f 	cmp	x0, x23
    5050:	54fffe21 	b.ne	5014 <w123+0x54>  // b.any
    5054:	f94006b6 	ldr	x22, [x21, #8]
    5058:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    505c:	f9400ad7 	ldr	x23, [x22, #16]
    5060:	eb0002ff 	cmp	x23, x0
    5064:	5400018d 	b.le	5094 <w123+0xd4>
    5068:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    506c:	91398000 	add	x0, x0, #0xe60
    5070:	97fffb64 	bl	3e00 <fwp_trap>
    5074:	9360fe97 	asr	x23, x20, #32
    5078:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    507c:	17ffffe3 	b	5008 <w123+0x48>
    5080:	a9005ab7 	stp	x23, x22, [x21]
    5084:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5088:	f9400ad7 	ldr	x23, [x22, #16]
    508c:	eb0002ff 	cmp	x23, x0
    5090:	54fffecc 	b.gt	5068 <w123+0xa8>
    5094:	eb3442ff 	cmp	x23, w20, uxtw
    5098:	540004cd 	b.le	5130 <w123+0x170>
    509c:	b7f80073 	tbnz	x19, #63, 50a8 <w123+0xe8>
    50a0:	eb3342ff 	cmp	x23, w19, uxtw
    50a4:	5400046d 	b.le	5130 <w123+0x170>
    50a8:	f94006d5 	ldr	x21, [x22, #8]
    50ac:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    50b0:	cb1502f5 	sub	x21, x23, x21
    50b4:	910006a1 	add	x1, x21, #0x1
    50b8:	eb00003f 	cmp	x1, x0
    50bc:	54fffd68 	b.hi	5068 <w123+0xa8>  // b.pmore
    50c0:	f9400ec0 	ldr	x0, [x22, #24]
    50c4:	eb00003f 	cmp	x1, x0
    50c8:	5400006d 	b.le	50d4 <w123+0x114>
    50cc:	aa1603e0 	mov	x0, x22
    50d0:	97ffff51 	bl	4e14 <fwp_tape_grow.constprop.0>
    50d4:	f100027f 	cmp	x19, #0x0
    50d8:	9e670282 	fmov	d2, x20
    50dc:	da9fa273 	csinv	x19, x19, xzr, ge	// ge = tcont
    50e0:	8b1506b5 	add	x21, x21, x21, lsl #1
    50e4:	f94012c2 	ldr	x2, [x22, #32]
    50e8:	4e181e62 	mov	v2.d[1], x19
    50ec:	d37df2b5 	lsl	x21, x21, #3
    50f0:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    50f4:	8b150040 	add	x0, x2, x21
    50f8:	92607e81 	and	x1, x20, #0xffffffff00000000
    50fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5100:	aa170021 	orr	x1, x1, x23
    5104:	0ea12842 	xtn	v2.2s, v2.2d
    5108:	910006f7 	add	x23, x23, #0x1
    510c:	fc356842 	str	d2, [x2, x21]
    5110:	6d00a400 	stp	d0, d9, [x0, #8]
    5114:	9e660100 	fmov	x0, d8
    5118:	f9000ad7 	str	x23, [x22, #16]
    511c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5120:	f9401bf7 	ldr	x23, [sp, #48]
    5124:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5128:	a8c57bfd 	ldp	x29, x30, [sp], #80
    512c:	d65f03c0 	ret
    5130:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    5134:	913be000 	add	x0, x0, #0xef8
    5138:	97fffb32 	bl	3e00 <fwp_trap>
    513c:	9e660100 	fmov	x0, d8
    5140:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    5144:	6d4427e8 	ldp	d8, d9, [sp, #64]
    5148:	a8c57bfd 	ldp	x29, x30, [sp], #80
    514c:	d65f03c0 	ret
    5150:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    5154:	913a0000 	add	x0, x0, #0xe80
    5158:	97fffb2a 	bl	3e00 <fwp_trap>
    515c:	d503201f 	nop

0000000000005160 <w120>:
    5160:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    5164:	910003fd 	mov	x29, sp
    5168:	a90153f3 	stp	x19, x20, [sp, #16]
    516c:	aa0203f3 	mov	x19, x2
    5170:	a9025bf5 	stp	x21, x22, [sp, #32]
    5174:	aa0003f6 	mov	x22, x0
    5178:	aa0103f5 	mov	x21, x1
    517c:	a90363f7 	stp	x23, x24, [sp, #48]
    5180:	f90023f9 	str	x25, [sp, #64]
    5184:	fd0027ea 	str	d10, [sp, #72]
    5188:	1e60080a 	fmul	d10, d0, d0
    518c:	6d0527e8 	stp	d8, d9, [sp, #80]
    5190:	1e604008 	fmov	d8, d0
    5194:	1e604029 	fmov	d9, d1
    5198:	b7f82500 	tbnz	x0, #63, 5638 <w120+0x4d8>
    519c:	9360fc14 	asr	x20, x0, #32
    51a0:	f9400040 	ldr	x0, [x2]
    51a4:	eb14001f 	cmp	x0, x20
    51a8:	54002340 	b.eq	5610 <w120+0x4b0>  // b.none
    51ac:	aa1403e0 	mov	x0, x20
    51b0:	97fffd18 	bl	4610 <fwp_tape_of>
    51b4:	aa0003f7 	mov	x23, x0
    51b8:	f9402800 	ldr	x0, [x0, #80]
    51bc:	b4000080 	cbz	x0, 51cc <w120+0x6c>
    51c0:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    51c4:	913b2000 	add	x0, x0, #0xec8
    51c8:	97fffb0e 	bl	3e00 <fwp_trap>
    51cc:	a9005e74 	stp	x20, x23, [x19]
    51d0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    51d4:	f9400af8 	ldr	x24, [x23, #16]
    51d8:	eb00031f 	cmp	x24, x0
    51dc:	5400210c 	b.gt	55fc <w120+0x49c>
    51e0:	eb36431f 	cmp	x24, w22, uxtw
    51e4:	5400206d 	b.le	55f0 <w120+0x490>
    51e8:	f94006f4 	ldr	x20, [x23, #8]
    51ec:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    51f0:	cb140314 	sub	x20, x24, x20
    51f4:	91000681 	add	x1, x20, #0x1
    51f8:	eb00003f 	cmp	x1, x0
    51fc:	54002008 	b.hi	55fc <w120+0x49c>  // b.pmore
    5200:	f9400ee0 	ldr	x0, [x23, #24]
    5204:	eb00003f 	cmp	x1, x0
    5208:	5400006d 	b.le	5214 <w120+0xb4>
    520c:	aa1703e0 	mov	x0, x23
    5210:	97ffff01 	bl	4e14 <fwp_tape_grow.constprop.0>
    5214:	8b140681 	add	x1, x20, x20, lsl #1
    5218:	92607ed4 	and	x20, x22, #0xffffffff00000000
    521c:	f94012e2 	ldr	x2, [x23, #32]
    5220:	d37df021 	lsl	x1, x1, #3
    5224:	aa180294 	orr	x20, x20, x24
    5228:	91000718 	add	x24, x24, #0x1
    522c:	8b010040 	add	x0, x2, x1
    5230:	b8216856 	str	w22, [x2, x1]
    5234:	9360fe99 	asr	x25, x20, #32
    5238:	b9000416 	str	w22, [x0, #4]
    523c:	6d00a008 	stp	d8, d8, [x0, #8]
    5240:	f9000af8 	str	x24, [x23, #16]
    5244:	b7f80075 	tbnz	x21, #63, 5250 <w120+0xf0>
    5248:	eb95833f 	cmp	x25, x21, asr #32
    524c:	540021c1 	b.ne	5684 <w120+0x524>  // b.any
    5250:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x490>
    5254:	1e6a3929 	fsub	d9, d9, d10
    5258:	3dc21800 	ldr	q0, [x0, #2144]
    525c:	3d801be0 	str	q0, [sp, #96]
    5260:	f9400260 	ldr	x0, [x19]
    5264:	eb19001f 	cmp	x0, x25
    5268:	54001d00 	b.eq	5608 <w120+0x4a8>  // b.none
    526c:	aa1903e0 	mov	x0, x25
    5270:	97fffce8 	bl	4610 <fwp_tape_of>
    5274:	aa0003f8 	mov	x24, x0
    5278:	f9402800 	ldr	x0, [x0, #80]
    527c:	b5fffa20 	cbnz	x0, 51c0 <w120+0x60>
    5280:	a9006279 	stp	x25, x24, [x19]
    5284:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5288:	f9400b19 	ldr	x25, [x24, #16]
    528c:	eb00033f 	cmp	x25, x0
    5290:	54001b6c 	b.gt	55fc <w120+0x49c>
    5294:	eb34433f 	cmp	x25, w20, uxtw
    5298:	54001acd 	b.le	55f0 <w120+0x490>
    529c:	b7f80075 	tbnz	x21, #63, 52a8 <w120+0x148>
    52a0:	eb35433f 	cmp	x25, w21, uxtw
    52a4:	54001a6d 	b.le	55f0 <w120+0x490>
    52a8:	f9400717 	ldr	x23, [x24, #8]
    52ac:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    52b0:	cb170337 	sub	x23, x25, x23
    52b4:	910006e1 	add	x1, x23, #0x1
    52b8:	eb00003f 	cmp	x1, x0
    52bc:	54001a08 	b.hi	55fc <w120+0x49c>  // b.pmore
    52c0:	f9400f00 	ldr	x0, [x24, #24]
    52c4:	eb00003f 	cmp	x1, x0
    52c8:	5400006d 	b.le	52d4 <w120+0x174>
    52cc:	aa1803e0 	mov	x0, x24
    52d0:	97fffed1 	bl	4e14 <fwp_tape_grow.constprop.0>
    52d4:	f10002bf 	cmp	x21, #0x0
    52d8:	9e670282 	fmov	d2, x20
    52dc:	92800001 	mov	x1, #0xffffffffffffffff    	// #-1
    52e0:	9a81a2b5 	csel	x21, x21, x1, ge	// ge = tcont
    52e4:	f9401300 	ldr	x0, [x24, #32]
    52e8:	4e181ea2 	mov	v2.d[1], x21
    52ec:	8b1706f7 	add	x23, x23, x23, lsl #1
    52f0:	91000722 	add	x2, x25, #0x1
    52f4:	3dc01be0 	ldr	q0, [sp, #96]
    52f8:	d37df2f7 	lsl	x23, x23, #3
    52fc:	0ea12842 	xtn	v2.2s, v2.2d
    5300:	8b170003 	add	x3, x0, x23
    5304:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5308:	92607e94 	and	x20, x20, #0xffffffff00000000
    530c:	aa190294 	orr	x20, x20, x25
    5310:	1e68394a 	fsub	d10, d10, d8
    5314:	fc376802 	str	d2, [x0, x23]
    5318:	3c808060 	stur	q0, [x3, #8]
    531c:	f9000b02 	str	x2, [x24, #16]
    5320:	b7f81b96 	tbnz	x22, #63, 5690 <w120+0x530>
    5324:	f9400260 	ldr	x0, [x19]
    5328:	9360fed5 	asr	x21, x22, #32
    532c:	eb15001f 	cmp	x0, x21
    5330:	54001800 	b.eq	5630 <w120+0x4d0>  // b.none
    5334:	aa1503e0 	mov	x0, x21
    5338:	97fffcb6 	bl	4610 <fwp_tape_of>
    533c:	aa0003f7 	mov	x23, x0
    5340:	f9402800 	ldr	x0, [x0, #80]
    5344:	b5fff3e0 	cbnz	x0, 51c0 <w120+0x60>
    5348:	a9005e75 	stp	x21, x23, [x19]
    534c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5350:	f9400af8 	ldr	x24, [x23, #16]
    5354:	eb00031f 	cmp	x24, x0
    5358:	5400152c 	b.gt	55fc <w120+0x49c>
    535c:	eb36431f 	cmp	x24, w22, uxtw
    5360:	5400148d 	b.le	55f0 <w120+0x490>
    5364:	f94006f5 	ldr	x21, [x23, #8]
    5368:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    536c:	cb150315 	sub	x21, x24, x21
    5370:	910006a1 	add	x1, x21, #0x1
    5374:	eb00003f 	cmp	x1, x0
    5378:	54001428 	b.hi	55fc <w120+0x49c>  // b.pmore
    537c:	f9400ee0 	ldr	x0, [x23, #24]
    5380:	eb00003f 	cmp	x1, x0
    5384:	5400006d 	b.le	5390 <w120+0x230>
    5388:	aa1703e0 	mov	x0, x23
    538c:	97fffea2 	bl	4e14 <fwp_tape_grow.constprop.0>
    5390:	8b1506b5 	add	x21, x21, x21, lsl #1
    5394:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x490>
    5398:	f94012e2 	ldr	x2, [x23, #32]
    539c:	d37df2a1 	lsl	x1, x21, #3
    53a0:	3dc21800 	ldr	q0, [x0, #2144]
    53a4:	8b010040 	add	x0, x2, x1
    53a8:	b8216856 	str	w22, [x2, x1]
    53ac:	92607ec3 	and	x3, x22, #0xffffffff00000000
    53b0:	12800001 	mov	w1, #0xffffffff            	// #-1
    53b4:	aa180075 	orr	x21, x3, x24
    53b8:	b9000401 	str	w1, [x0, #4]
    53bc:	91000718 	add	x24, x24, #0x1
    53c0:	3c808000 	stur	q0, [x0, #8]
    53c4:	f9000af8 	str	x24, [x23, #16]
    53c8:	f9400260 	ldr	x0, [x19]
    53cc:	9360fe96 	asr	x22, x20, #32
    53d0:	1e690928 	fmul	d8, d9, d9
    53d4:	eb16001f 	cmp	x0, x22
    53d8:	54001280 	b.eq	5628 <w120+0x4c8>  // b.none
    53dc:	aa1603e0 	mov	x0, x22
    53e0:	97fffc8c 	bl	4610 <fwp_tape_of>
    53e4:	aa0003f7 	mov	x23, x0
    53e8:	f9402800 	ldr	x0, [x0, #80]
    53ec:	b5ffeea0 	cbnz	x0, 51c0 <w120+0x60>
    53f0:	a9005e76 	stp	x22, x23, [x19]
    53f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    53f8:	f9400af9 	ldr	x25, [x23, #16]
    53fc:	eb00033f 	cmp	x25, x0
    5400:	54000fec 	b.gt	55fc <w120+0x49c>
    5404:	eb34433f 	cmp	x25, w20, uxtw
    5408:	54000f4d 	b.le	55f0 <w120+0x490>
    540c:	f94006f6 	ldr	x22, [x23, #8]
    5410:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5414:	cb160336 	sub	x22, x25, x22
    5418:	910006c1 	add	x1, x22, #0x1
    541c:	eb00003f 	cmp	x1, x0
    5420:	54000ee8 	b.hi	55fc <w120+0x49c>  // b.pmore
    5424:	f9400ee0 	ldr	x0, [x23, #24]
    5428:	eb00003f 	cmp	x1, x0
    542c:	5400006d 	b.le	5438 <w120+0x2d8>
    5430:	aa1703e0 	mov	x0, x23
    5434:	97fffe78 	bl	4e14 <fwp_tape_grow.constprop.0>
    5438:	8b1606d6 	add	x22, x22, x22, lsl #1
    543c:	92607e98 	and	x24, x20, #0xffffffff00000000
    5440:	f94012e0 	ldr	x0, [x23, #32]
    5444:	d37df2d6 	lsl	x22, x22, #3
    5448:	f9400262 	ldr	x2, [x19]
    544c:	8b160001 	add	x1, x0, x22
    5450:	b8366814 	str	w20, [x0, x22]
    5454:	aa190318 	orr	x24, x24, x25
    5458:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    545c:	9e670000 	fmov	d0, x0
    5460:	b9000434 	str	w20, [x1, #4]
    5464:	91000739 	add	x25, x25, #0x1
    5468:	6d00a429 	stp	d9, d9, [x1, #8]
    546c:	9360ff14 	asr	x20, x24, #32
    5470:	1e600908 	fmul	d8, d8, d0
    5474:	f9000af9 	str	x25, [x23, #16]
    5478:	eb14005f 	cmp	x2, x20
    547c:	54000d20 	b.eq	5620 <w120+0x4c0>  // b.none
    5480:	aa1403e0 	mov	x0, x20
    5484:	97fffc63 	bl	4610 <fwp_tape_of>
    5488:	aa0003f6 	mov	x22, x0
    548c:	f9402800 	ldr	x0, [x0, #80]
    5490:	b5ffe980 	cbnz	x0, 51c0 <w120+0x60>
    5494:	a9005a74 	stp	x20, x22, [x19]
    5498:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    549c:	f9400ad7 	ldr	x23, [x22, #16]
    54a0:	eb0002ff 	cmp	x23, x0
    54a4:	54000acc 	b.gt	55fc <w120+0x49c>
    54a8:	eb3842ff 	cmp	x23, w24, uxtw
    54ac:	54000a2d 	b.le	55f0 <w120+0x490>
    54b0:	f94006d4 	ldr	x20, [x22, #8]
    54b4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54b8:	cb1402f4 	sub	x20, x23, x20
    54bc:	91000681 	add	x1, x20, #0x1
    54c0:	eb00003f 	cmp	x1, x0
    54c4:	540009c8 	b.hi	55fc <w120+0x49c>  // b.pmore
    54c8:	f9400ec0 	ldr	x0, [x22, #24]
    54cc:	eb00003f 	cmp	x1, x0
    54d0:	5400006d 	b.le	54dc <w120+0x37c>
    54d4:	aa1603e0 	mov	x0, x22
    54d8:	97fffe4f 	bl	4e14 <fwp_tape_grow.constprop.0>
    54dc:	8b140694 	add	x20, x20, x20, lsl #1
    54e0:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x490>
    54e4:	f94012c1 	ldr	x1, [x22, #32]
    54e8:	d37df294 	lsl	x20, x20, #3
    54ec:	3dc21c00 	ldr	q0, [x0, #2160]
    54f0:	8b140020 	add	x0, x1, x20
    54f4:	b8346838 	str	w24, [x1, x20]
    54f8:	12800002 	mov	w2, #0xffffffff            	// #-1
    54fc:	92607f18 	and	x24, x24, #0xffffffff00000000
    5500:	910006e1 	add	x1, x23, #0x1
    5504:	b9000402 	str	w2, [x0, #4]
    5508:	1e6a0949 	fmul	d9, d10, d10
    550c:	3c808000 	stur	q0, [x0, #8]
    5510:	aa170318 	orr	x24, x24, x23
    5514:	aa1503e0 	mov	x0, x21
    5518:	f9000ac1 	str	x1, [x22, #16]
    551c:	b10006bf 	cmn	x21, #0x1
    5520:	540004e0 	b.eq	55bc <w120+0x45c>  // b.none
    5524:	f9400260 	ldr	x0, [x19]
    5528:	9360feb4 	asr	x20, x21, #32
    552c:	eb14001f 	cmp	x0, x20
    5530:	54000740 	b.eq	5618 <w120+0x4b8>  // b.none
    5534:	aa1403e0 	mov	x0, x20
    5538:	97fffc36 	bl	4610 <fwp_tape_of>
    553c:	aa0003f6 	mov	x22, x0
    5540:	f9402800 	ldr	x0, [x0, #80]
    5544:	b5ffe3e0 	cbnz	x0, 51c0 <w120+0x60>
    5548:	a9005a74 	stp	x20, x22, [x19]
    554c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5550:	f9400ad7 	ldr	x23, [x22, #16]
    5554:	eb0002ff 	cmp	x23, x0
    5558:	5400052c 	b.gt	55fc <w120+0x49c>
    555c:	eb3542ff 	cmp	x23, w21, uxtw
    5560:	5400048d 	b.le	55f0 <w120+0x490>
    5564:	f94006d4 	ldr	x20, [x22, #8]
    5568:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    556c:	cb1402f4 	sub	x20, x23, x20
    5570:	91000681 	add	x1, x20, #0x1
    5574:	eb00003f 	cmp	x1, x0
    5578:	54000428 	b.hi	55fc <w120+0x49c>  // b.pmore
    557c:	f9400ec0 	ldr	x0, [x22, #24]
    5580:	eb00003f 	cmp	x1, x0
    5584:	5400006d 	b.le	5590 <w120+0x430>
    5588:	aa1603e0 	mov	x0, x22
    558c:	97fffe22 	bl	4e14 <fwp_tape_grow.constprop.0>
    5590:	8b140694 	add	x20, x20, x20, lsl #1
    5594:	92607ea0 	and	x0, x21, #0xffffffff00000000
    5598:	f94012c2 	ldr	x2, [x22, #32]
    559c:	d37df294 	lsl	x20, x20, #3
    55a0:	aa170000 	orr	x0, x0, x23
    55a4:	910006f7 	add	x23, x23, #0x1
    55a8:	8b140041 	add	x1, x2, x20
    55ac:	b8346855 	str	w21, [x2, x20]
    55b0:	b9000435 	str	w21, [x1, #4]
    55b4:	6d00a82a 	stp	d10, d10, [x1, #8]
    55b8:	f9000ad7 	str	x23, [x22, #16]
    55bc:	1e604101 	fmov	d1, d8
    55c0:	1e604120 	fmov	d0, d9
    55c4:	aa1303e2 	mov	x2, x19
    55c8:	aa1803e1 	mov	x1, x24
    55cc:	97fffe7d 	bl	4fc0 <w123>
    55d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    55d4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    55dc:	f94023f9 	ldr	x25, [sp, #64]
    55e0:	fd4027ea 	ldr	d10, [sp, #72]
    55e4:	6d4527e8 	ldp	d8, d9, [sp, #80]
    55e8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    55ec:	d65f03c0 	ret
    55f0:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    55f4:	913be000 	add	x0, x0, #0xef8
    55f8:	97fffa02 	bl	3e00 <fwp_trap>
    55fc:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    5600:	91398000 	add	x0, x0, #0xe60
    5604:	97fff9ff 	bl	3e00 <fwp_trap>
    5608:	f9400678 	ldr	x24, [x19, #8]
    560c:	17ffff1e 	b	5284 <w120+0x124>
    5610:	f9400457 	ldr	x23, [x2, #8]
    5614:	17fffeef 	b	51d0 <w120+0x70>
    5618:	f9400676 	ldr	x22, [x19, #8]
    561c:	17ffffcc 	b	554c <w120+0x3ec>
    5620:	f9400676 	ldr	x22, [x19, #8]
    5624:	17ffff9d 	b	5498 <w120+0x338>
    5628:	f9400677 	ldr	x23, [x19, #8]
    562c:	17ffff72 	b	53f4 <w120+0x294>
    5630:	f9400677 	ldr	x23, [x19, #8]
    5634:	17ffff46 	b	534c <w120+0x1ec>
    5638:	1e6a3829 	fsub	d9, d1, d10
    563c:	b6f80161 	tbz	x1, #63, 5668 <w120+0x508>
    5640:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5644:	1e690921 	fmul	d1, d9, d9
    5648:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    564c:	9e670002 	fmov	d2, x0
    5650:	1e683809 	fsub	d9, d0, d8
    5654:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5658:	aa1803e0 	mov	x0, x24
    565c:	1e620828 	fmul	d8, d1, d2
    5660:	1e690929 	fmul	d9, d9, d9
    5664:	17ffffd6 	b	55bc <w120+0x45c>
    5668:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x490>
    566c:	9360fc39 	asr	x25, x1, #32
    5670:	aa0103f4 	mov	x20, x1
    5674:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5678:	3dc21400 	ldr	q0, [x0, #2128]
    567c:	3d801be0 	str	q0, [sp, #96]
    5680:	17fffef8 	b	5260 <w120+0x100>
    5684:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    5688:	913a0000 	add	x0, x0, #0xe80
    568c:	97fff9dd 	bl	3e00 <fwp_trap>
    5690:	aa0103f5 	mov	x21, x1
    5694:	17ffff4d 	b	53c8 <w120+0x268>
    5698:	d503201f 	nop
    569c:	d503201f 	nop

00000000000056a0 <w176.constprop.0>:
    56a0:	d10183ff 	sub	sp, sp, #0x60
    56a4:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    56a8:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    56ac:	f947f421 	ldr	x1, [x1, #4072]
    56b0:	a9027bfd 	stp	x29, x30, [sp, #32]
    56b4:	910083fd 	add	x29, sp, #0x20
    56b8:	a9045bf5 	stp	x21, x22, [sp, #64]
    56bc:	f9400015 	ldr	x21, [x0]
    56c0:	f9400023 	ldr	x3, [x1]
    56c4:	f9000fe3 	str	x3, [sp, #24]
    56c8:	d2800003 	mov	x3, #0x0                   	// #0
    56cc:	a900ffe2 	stp	x2, xzr, [sp, #8]
    56d0:	b4000435 	cbz	x21, 5754 <w176.constprop.0+0xb4>
    56d4:	2f00e400 	movi	d0, #0x0
    56d8:	91004016 	add	x22, x0, #0x10
    56dc:	a90353f3 	stp	x19, x20, [sp, #48]
    56e0:	91002014 	add	x20, x0, #0x8
    56e4:	d2800013 	mov	x19, #0x0                   	// #0
    56e8:	f9002bf7 	str	x23, [sp, #80]
    56ec:	910023f7 	add	x23, sp, #0x8
    56f0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    56f4:	aa0203e0 	mov	x0, x2
    56f8:	fc737a81 	ldr	d1, [x20, x19, lsl #3]
    56fc:	aa1703e2 	mov	x2, x23
    5700:	91000a73 	add	x19, x19, #0x2
    5704:	97fffe2f 	bl	4fc0 <w123>
    5708:	aa0103e2 	mov	x2, x1
    570c:	9e670000 	fmov	d0, x0
    5710:	eb1302bf 	cmp	x21, x19
    5714:	54fffee8 	b.hi	56f0 <w176.constprop.0+0x50>  // b.pmore
    5718:	a94353f3 	ldp	x19, x20, [sp, #48]
    571c:	f9402bf7 	ldr	x23, [sp, #80]
    5720:	9e660000 	fmov	x0, d0
    5724:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    5728:	f947f421 	ldr	x1, [x1, #4072]
    572c:	f9400fe4 	ldr	x4, [sp, #24]
    5730:	f9400023 	ldr	x3, [x1]
    5734:	eb030084 	subs	x4, x4, x3
    5738:	d2800003 	mov	x3, #0x0                   	// #0
    573c:	54000101 	b.ne	575c <w176.constprop.0+0xbc>  // b.any
    5740:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5744:	aa0203e1 	mov	x1, x2
    5748:	a9445bf5 	ldp	x21, x22, [sp, #64]
    574c:	910183ff 	add	sp, sp, #0x60
    5750:	d65f03c0 	ret
    5754:	2f00e400 	movi	d0, #0x0
    5758:	17fffff2 	b	5720 <w176.constprop.0+0x80>
    575c:	a90353f3 	stp	x19, x20, [sp, #48]
    5760:	f9002bf7 	str	x23, [sp, #80]
    5764:	97fff427 	bl	2800 <__stack_chk_fail@plt>
    5768:	d503201f 	nop
    576c:	d503201f 	nop

0000000000005770 <fwp_rc_share>:
    5770:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5774:	9114c042 	add	x2, x2, #0x530
    5778:	f949d843 	ldr	x3, [x2, #5040]
    577c:	f949ec41 	ldr	x1, [x2, #5080]
    5780:	cb030000 	sub	x0, x0, x3
    5784:	eb01401f 	cmp	x0, x1, lsl #16
    5788:	540003a2 	b.cs	57fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    578c:	d350fc01 	lsr	x1, x0, #16
    5790:	f949fc44 	ldr	x4, [x2, #5112]
    5794:	8b010821 	add	x1, x1, x1, lsl #2
    5798:	d37df021 	lsl	x1, x1, #3
    579c:	8b010083 	add	x3, x4, x1
    57a0:	f9401062 	ldr	x2, [x3, #32]
    57a4:	b40002c2 	cbz	x2, 57fc <fwp_rc_share+0x8c>
    57a8:	38616881 	ldrb	w1, [x4, x1]
    57ac:	7100083f 	cmp	w1, #0x2
    57b0:	54000220 	b.eq	57f4 <fwp_rc_share+0x84>  // b.none
    57b4:	7100043f 	cmp	w1, #0x1
    57b8:	54000221 	b.ne	57fc <fwp_rc_share+0x8c>  // b.any
    57bc:	29430464 	ldp	w4, w1, [x3, #24]
    57c0:	92403c00 	and	x0, x0, #0xffff
    57c4:	9b047c00 	mul	x0, x0, x4
    57c8:	d360fc00 	lsr	x0, x0, #32
    57cc:	eb01001f 	cmp	x0, x1
    57d0:	54000162 	b.cs	57fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    57d4:	8b000042 	add	x2, x2, x0
    57d8:	39400040 	ldrb	w0, [x2]
    57dc:	34000100 	cbz	w0, 57fc <fwp_rc_share+0x8c>
    57e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    57e4:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    57e8:	913c6000 	add	x0, x0, #0xf18
    57ec:	910003fd 	mov	x29, sp
    57f0:	97fff984 	bl	3e00 <fwp_trap>
    57f4:	72003c1f 	tst	w0, #0xffff
    57f8:	54ffff00 	b.eq	57d8 <fwp_rc_share+0x68>  // b.none
    57fc:	d65f03c0 	ret

0000000000005800 <fwp_rc_free_arr>:
    5800:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    5804:	9114c063 	add	x3, x3, #0x530
    5808:	f949d861 	ldr	x1, [x3, #5040]
    580c:	f949ec62 	ldr	x2, [x3, #5080]
    5810:	cb010001 	sub	x1, x0, x1
    5814:	eb02403f 	cmp	x1, x2, lsl #16
    5818:	54000342 	b.cs	5880 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    581c:	d350fc22 	lsr	x2, x1, #16
    5820:	f949fc65 	ldr	x5, [x3, #5112]
    5824:	8b020842 	add	x2, x2, x2, lsl #2
    5828:	d37df042 	lsl	x2, x2, #3
    582c:	8b0200a4 	add	x4, x5, x2
    5830:	f9401083 	ldr	x3, [x4, #32]
    5834:	b4000263 	cbz	x3, 5880 <fwp_rc_free_arr+0x80>
    5838:	386268a2 	ldrb	w2, [x5, x2]
    583c:	7100085f 	cmp	w2, #0x2
    5840:	540001c0 	b.eq	5878 <fwp_rc_free_arr+0x78>  // b.none
    5844:	7100045f 	cmp	w2, #0x1
    5848:	540001c1 	b.ne	5880 <fwp_rc_free_arr+0x80>  // b.any
    584c:	29430885 	ldp	w5, w2, [x4, #24]
    5850:	92403c21 	and	x1, x1, #0xffff
    5854:	9b057c21 	mul	x1, x1, x5
    5858:	d360fc21 	lsr	x1, x1, #32
    585c:	eb02003f 	cmp	x1, x2
    5860:	54000102 	b.cs	5880 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5864:	8b010063 	add	x3, x3, x1
    5868:	39400061 	ldrb	w1, [x3]
    586c:	7100043f 	cmp	w1, #0x1
    5870:	54000081 	b.ne	5880 <fwp_rc_free_arr+0x80>  // b.any
    5874:	17fffa1f 	b	40f0 <fwp_mem_free>
    5878:	72003c3f 	tst	w1, #0xffff
    587c:	54ffff60 	b.eq	5868 <fwp_rc_free_arr+0x68>  // b.none
    5880:	d65f03c0 	ret

0000000000005884 <fwp_rc_dup>:
    5884:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5888:	9114c042 	add	x2, x2, #0x530
    588c:	f949d841 	ldr	x1, [x2, #5040]
    5890:	f949ec43 	ldr	x3, [x2, #5080]
    5894:	cb010001 	sub	x1, x0, x1
    5898:	eb03403f 	cmp	x1, x3, lsl #16
    589c:	54000342 	b.cs	5904 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    58a0:	d350fc20 	lsr	x0, x1, #16
    58a4:	f949fc44 	ldr	x4, [x2, #5112]
    58a8:	8b000800 	add	x0, x0, x0, lsl #2
    58ac:	d37df002 	lsl	x2, x0, #3
    58b0:	8b020083 	add	x3, x4, x2
    58b4:	f9401060 	ldr	x0, [x3, #32]
    58b8:	b4000260 	cbz	x0, 5904 <fwp_rc_dup+0x80>
    58bc:	38626882 	ldrb	w2, [x4, x2]
    58c0:	7100085f 	cmp	w2, #0x2
    58c4:	54000220 	b.eq	5908 <fwp_rc_dup+0x84>  // b.none
    58c8:	7100045f 	cmp	w2, #0x1
    58cc:	540001c1 	b.ne	5904 <fwp_rc_dup+0x80>  // b.any
    58d0:	29430864 	ldp	w4, w2, [x3, #24]
    58d4:	92403c21 	and	x1, x1, #0xffff
    58d8:	9b047c21 	mul	x1, x1, x4
    58dc:	d360fc21 	lsr	x1, x1, #32
    58e0:	eb02003f 	cmp	x1, x2
    58e4:	54000102 	b.cs	5904 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    58e8:	8b010000 	add	x0, x0, x1
    58ec:	39400001 	ldrb	w1, [x0]
    58f0:	340000a1 	cbz	w1, 5904 <fwp_rc_dup+0x80>
    58f4:	7103f43f 	cmp	w1, #0xfd
    58f8:	540000e8 	b.hi	5914 <fwp_rc_dup+0x90>  // b.pmore
    58fc:	11000421 	add	w1, w1, #0x1
    5900:	39000001 	strb	w1, [x0]
    5904:	d65f03c0 	ret
    5908:	72003c3f 	tst	w1, #0xffff
    590c:	54ffff00 	b.eq	58ec <fwp_rc_dup+0x68>  // b.none
    5910:	d65f03c0 	ret
    5914:	17fffa70 	b	42d4 <fwp_rc_wide_dup>
    5918:	d503201f 	nop
    591c:	d503201f 	nop

0000000000005920 <fwp_owned_entry173>:
    5920:	d10103ff 	sub	sp, sp, #0x40
    5924:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    5928:	f947f442 	ldr	x2, [x2, #4072]
    592c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5930:	910083fd 	add	x29, sp, #0x20
    5934:	a90353f3 	stp	x19, x20, [sp, #48]
    5938:	f9400043 	ldr	x3, [x2]
    593c:	f9000fe3 	str	x3, [sp, #24]
    5940:	d2800003 	mov	x3, #0x0                   	// #0
    5944:	a9400c01 	ldp	x1, x3, [x0]
    5948:	f9400802 	ldr	x2, [x0, #16]
    594c:	ab020022 	adds	x2, x1, x2
    5950:	540006e6 	b.vs	5a2c <fwp_owned_entry173+0x10c>
    5954:	910023e1 	add	x1, sp, #0x8
    5958:	52800000 	mov	w0, #0x0                   	// #0
    595c:	a9008be3 	stp	x3, x2, [sp, #8]
    5960:	97fffce5 	bl	4cf4 <fwp_data.part.0.constprop.0>
    5964:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    5968:	9114c063 	add	x3, x3, #0x530
    596c:	aa0003f3 	mov	x19, x0
    5970:	f949d861 	ldr	x1, [x3, #5040]
    5974:	f949ec60 	ldr	x0, [x3, #5080]
    5978:	cb010261 	sub	x1, x19, x1
    597c:	eb00403f 	cmp	x1, x0, lsl #16
    5980:	54000322 	b.cs	59e4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5984:	d350fc22 	lsr	x2, x1, #16
    5988:	f949fc63 	ldr	x3, [x3, #5112]
    598c:	8b020842 	add	x2, x2, x2, lsl #2
    5990:	d37df042 	lsl	x2, x2, #3
    5994:	8b020060 	add	x0, x3, x2
    5998:	f9401014 	ldr	x20, [x0, #32]
    599c:	b4000254 	cbz	x20, 59e4 <fwp_owned_entry173+0xc4>
    59a0:	38626862 	ldrb	w2, [x3, x2]
    59a4:	7100085f 	cmp	w2, #0x2
    59a8:	54000360 	b.eq	5a14 <fwp_owned_entry173+0xf4>  // b.none
    59ac:	7100045f 	cmp	w2, #0x1
    59b0:	540001a1 	b.ne	59e4 <fwp_owned_entry173+0xc4>  // b.any
    59b4:	29430002 	ldp	w2, w0, [x0, #24]
    59b8:	92403c21 	and	x1, x1, #0xffff
    59bc:	9b027c21 	mul	x1, x1, x2
    59c0:	d360fc21 	lsr	x1, x1, #32
    59c4:	eb00003f 	cmp	x1, x0
    59c8:	540000e2 	b.cs	59e4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    59cc:	8b010294 	add	x20, x20, x1
    59d0:	39400280 	ldrb	w0, [x20]
    59d4:	7103fc1f 	cmp	w0, #0xff
    59d8:	54000240 	b.eq	5a20 <fwp_owned_entry173+0x100>  // b.none
    59dc:	52800020 	mov	w0, #0x1                   	// #1
    59e0:	39000280 	strb	w0, [x20]
    59e4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    59e8:	f947f400 	ldr	x0, [x0, #4072]
    59ec:	f9400fe2 	ldr	x2, [sp, #24]
    59f0:	f9400001 	ldr	x1, [x0]
    59f4:	eb010042 	subs	x2, x2, x1
    59f8:	d2800001 	mov	x1, #0x0                   	// #0
    59fc:	540001a1 	b.ne	5a30 <fwp_owned_entry173+0x110>  // b.any
    5a00:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a04:	aa1303e0 	mov	x0, x19
    5a08:	a94353f3 	ldp	x19, x20, [sp, #48]
    5a0c:	910103ff 	add	sp, sp, #0x40
    5a10:	d65f03c0 	ret
    5a14:	72003c3f 	tst	w1, #0xffff
    5a18:	54fffe61 	b.ne	59e4 <fwp_owned_entry173+0xc4>  // b.any
    5a1c:	17ffffed 	b	59d0 <fwp_owned_entry173+0xb0>
    5a20:	aa1403e0 	mov	x0, x20
    5a24:	97fff917 	bl	3e80 <fwp_rc_forget_slot.part.0>
    5a28:	17ffffed 	b	59dc <fwp_owned_entry173+0xbc>
    5a2c:	97fff3f5 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5a30:	97fff374 	bl	2800 <__stack_chk_fail@plt>

0000000000005a34 <e173>:
    5a34:	d10103ff 	sub	sp, sp, #0x40
    5a38:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc88>
    5a3c:	f947f442 	ldr	x2, [x2, #4072]
    5a40:	a9027bfd 	stp	x29, x30, [sp, #32]
    5a44:	910083fd 	add	x29, sp, #0x20
    5a48:	a90353f3 	stp	x19, x20, [sp, #48]
    5a4c:	f9400043 	ldr	x3, [x2]
    5a50:	f9000fe3 	str	x3, [sp, #24]
    5a54:	d2800003 	mov	x3, #0x0                   	// #0
    5a58:	a9400c01 	ldp	x1, x3, [x0]
    5a5c:	f9400802 	ldr	x2, [x0, #16]
    5a60:	ab020022 	adds	x2, x1, x2
    5a64:	54000726 	b.vs	5b48 <e173+0x114>
    5a68:	910023e1 	add	x1, sp, #0x8
    5a6c:	52800000 	mov	w0, #0x0                   	// #0
    5a70:	a9008be3 	stp	x3, x2, [sp, #8]
    5a74:	97fffca0 	bl	4cf4 <fwp_data.part.0.constprop.0>
    5a78:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    5a7c:	9114c063 	add	x3, x3, #0x530
    5a80:	aa0003f3 	mov	x19, x0
    5a84:	f949d861 	ldr	x1, [x3, #5040]
    5a88:	f949ec60 	ldr	x0, [x3, #5080]
    5a8c:	cb010261 	sub	x1, x19, x1
    5a90:	eb00403f 	cmp	x1, x0, lsl #16
    5a94:	54000322 	b.cs	5af8 <e173+0xc4>  // b.hs, b.nlast
    5a98:	d350fc22 	lsr	x2, x1, #16
    5a9c:	f949fc63 	ldr	x3, [x3, #5112]
    5aa0:	8b020842 	add	x2, x2, x2, lsl #2
    5aa4:	d37df042 	lsl	x2, x2, #3
    5aa8:	8b020060 	add	x0, x3, x2
    5aac:	f9401014 	ldr	x20, [x0, #32]
    5ab0:	b4000254 	cbz	x20, 5af8 <e173+0xc4>
    5ab4:	38626862 	ldrb	w2, [x3, x2]
    5ab8:	7100085f 	cmp	w2, #0x2
    5abc:	540003a0 	b.eq	5b30 <e173+0xfc>  // b.none
    5ac0:	7100045f 	cmp	w2, #0x1
    5ac4:	540001a1 	b.ne	5af8 <e173+0xc4>  // b.any
    5ac8:	29430002 	ldp	w2, w0, [x0, #24]
    5acc:	92403c21 	and	x1, x1, #0xffff
    5ad0:	9b027c21 	mul	x1, x1, x2
    5ad4:	d360fc21 	lsr	x1, x1, #32
    5ad8:	eb00003f 	cmp	x1, x0
    5adc:	540000e2 	b.cs	5af8 <e173+0xc4>  // b.hs, b.nlast
    5ae0:	8b010294 	add	x20, x20, x1
    5ae4:	39400280 	ldrb	w0, [x20]
    5ae8:	7103fc1f 	cmp	w0, #0xff
    5aec:	54000280 	b.eq	5b3c <e173+0x108>  // b.none
    5af0:	52800020 	mov	w0, #0x1                   	// #1
    5af4:	39000280 	strb	w0, [x20]
    5af8:	aa1303e0 	mov	x0, x19
    5afc:	97ffff1d 	bl	5770 <fwp_rc_share>
    5b00:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    5b04:	f947f400 	ldr	x0, [x0, #4072]
    5b08:	f9400fe2 	ldr	x2, [sp, #24]
    5b0c:	f9400001 	ldr	x1, [x0]
    5b10:	eb010042 	subs	x2, x2, x1
    5b14:	d2800001 	mov	x1, #0x0                   	// #0
    5b18:	540001a1 	b.ne	5b4c <e173+0x118>  // b.any
    5b1c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5b20:	aa1303e0 	mov	x0, x19
    5b24:	a94353f3 	ldp	x19, x20, [sp, #48]
    5b28:	910103ff 	add	sp, sp, #0x40
    5b2c:	d65f03c0 	ret
    5b30:	72003c3f 	tst	w1, #0xffff
    5b34:	54fffe21 	b.ne	5af8 <e173+0xc4>  // b.any
    5b38:	17ffffeb 	b	5ae4 <e173+0xb0>
    5b3c:	aa1403e0 	mov	x0, x20
    5b40:	97fff8d0 	bl	3e80 <fwp_rc_forget_slot.part.0>
    5b44:	17ffffeb 	b	5af0 <e173+0xbc>
    5b48:	97fff3ae 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5b4c:	97fff32d 	bl	2800 <__stack_chk_fail@plt>

0000000000005b50 <fwp_drop0>:
    5b50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b54:	910003fd 	mov	x29, sp
    5b58:	a90153f3 	stp	x19, x20, [sp, #16]
    5b5c:	f90013f5 	str	x21, [sp, #32]
    5b60:	90000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    5b64:	9114c2b4 	add	x20, x21, #0x530
    5b68:	f949da81 	ldr	x1, [x20, #5040]
    5b6c:	f949ee82 	ldr	x2, [x20, #5080]
    5b70:	cb010001 	sub	x1, x0, x1
    5b74:	eb02403f 	cmp	x1, x2, lsl #16
    5b78:	54000382 	b.cs	5be8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b7c:	d350fc22 	lsr	x2, x1, #16
    5b80:	f949fe84 	ldr	x4, [x20, #5112]
    5b84:	8b020842 	add	x2, x2, x2, lsl #2
    5b88:	d37df042 	lsl	x2, x2, #3
    5b8c:	8b020083 	add	x3, x4, x2
    5b90:	f9401073 	ldr	x19, [x3, #32]
    5b94:	b40002b3 	cbz	x19, 5be8 <fwp_drop0+0x98>
    5b98:	38626882 	ldrb	w2, [x4, x2]
    5b9c:	7100085f 	cmp	w2, #0x2
    5ba0:	540002c0 	b.eq	5bf8 <fwp_drop0+0xa8>  // b.none
    5ba4:	7100045f 	cmp	w2, #0x1
    5ba8:	54000201 	b.ne	5be8 <fwp_drop0+0x98>  // b.any
    5bac:	29430864 	ldp	w4, w2, [x3, #24]
    5bb0:	92403c21 	and	x1, x1, #0xffff
    5bb4:	9b047c21 	mul	x1, x1, x4
    5bb8:	d360fc21 	lsr	x1, x1, #32
    5bbc:	eb02003f 	cmp	x1, x2
    5bc0:	54000142 	b.cs	5be8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5bc4:	8b010273 	add	x19, x19, x1
    5bc8:	39400261 	ldrb	w1, [x19]
    5bcc:	340000e1 	cbz	w1, 5be8 <fwp_drop0+0x98>
    5bd0:	7100043f 	cmp	w1, #0x1
    5bd4:	540001e0 	b.eq	5c10 <fwp_drop0+0xc0>  // b.none
    5bd8:	7103fc3f 	cmp	w1, #0xff
    5bdc:	540002e0 	b.eq	5c38 <fwp_drop0+0xe8>  // b.none
    5be0:	51000421 	sub	w1, w1, #0x1
    5be4:	39000261 	strb	w1, [x19]
    5be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bec:	f94013f5 	ldr	x21, [sp, #32]
    5bf0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5bf4:	d65f03c0 	ret
    5bf8:	72003c3f 	tst	w1, #0xffff
    5bfc:	54fffe60 	b.eq	5bc8 <fwp_drop0+0x78>  // b.none
    5c00:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c04:	f94013f5 	ldr	x21, [sp, #32]
    5c08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c0c:	d65f03c0 	ret
    5c10:	f9400813 	ldr	x19, [x0, #16]
    5c14:	97fffefb 	bl	5800 <fwp_rc_free_arr>
    5c18:	9114c2a0 	add	x0, x21, #0x530
    5c1c:	f949d801 	ldr	x1, [x0, #5040]
    5c20:	f949ec00 	ldr	x0, [x0, #5080]
    5c24:	cb010261 	sub	x1, x19, x1
    5c28:	eb00403f 	cmp	x1, x0, lsl #16
    5c2c:	54fffde2 	b.cs	5be8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c30:	aa1303e0 	mov	x0, x19
    5c34:	17ffffd2 	b	5b7c <fwp_drop0+0x2c>
    5c38:	ca534660 	eor	x0, x19, x19, lsr #17
    5c3c:	9114c2b5 	add	x21, x21, #0x530
    5c40:	ca402400 	eor	x0, x0, x0, lsr #9
    5c44:	92401c00 	and	x0, x0, #0xff
    5c48:	910a2402 	add	x2, x0, #0x289
    5c4c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5c50:	8b020ea2 	add	x2, x21, x2, lsl #3
    5c54:	f94a2400 	ldr	x0, [x0, #5192]
    5c58:	b50000a0 	cbnz	x0, 5c6c <fwp_drop0+0x11c>
    5c5c:	14000013 	b	5ca8 <fwp_drop0+0x158>
    5c60:	91004002 	add	x2, x0, #0x10
    5c64:	f9400800 	ldr	x0, [x0, #16]
    5c68:	b4000200 	cbz	x0, 5ca8 <fwp_drop0+0x158>
    5c6c:	f9400001 	ldr	x1, [x0]
    5c70:	eb13003f 	cmp	x1, x19
    5c74:	54ffff61 	b.ne	5c60 <fwp_drop0+0x110>  // b.any
    5c78:	f9400041 	ldr	x1, [x2]
    5c7c:	f9400420 	ldr	x0, [x1, #8]
    5c80:	d1000400 	sub	x0, x0, #0x1
    5c84:	f9000420 	str	x0, [x1, #8]
    5c88:	f103f81f 	cmp	x0, #0xfe
    5c8c:	54fffae1 	b.ne	5be8 <fwp_drop0+0x98>  // b.any
    5c90:	39400260 	ldrb	w0, [x19]
    5c94:	7103fc1f 	cmp	w0, #0xff
    5c98:	540000e0 	b.eq	5cb4 <fwp_drop0+0x164>  // b.none
    5c9c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ca0:	39000260 	strb	w0, [x19]
    5ca4:	17ffffd1 	b	5be8 <fwp_drop0+0x98>
    5ca8:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    5cac:	9132c000 	add	x0, x0, #0xcb0
    5cb0:	97fff854 	bl	3e00 <fwp_trap>
    5cb4:	aa1303e0 	mov	x0, x19
    5cb8:	97fff872 	bl	3e80 <fwp_rc_forget_slot.part.0>
    5cbc:	17fffff8 	b	5c9c <fwp_drop0+0x14c>

0000000000005cc0 <fwp_drop1>:
    5cc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5cc4:	910003fd 	mov	x29, sp
    5cc8:	a90153f3 	stp	x19, x20, [sp, #16]
    5ccc:	f90013f5 	str	x21, [sp, #32]
    5cd0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    5cd4:	9114c2b4 	add	x20, x21, #0x530
    5cd8:	f949da81 	ldr	x1, [x20, #5040]
    5cdc:	f949ee82 	ldr	x2, [x20, #5080]
    5ce0:	cb010001 	sub	x1, x0, x1
    5ce4:	eb02403f 	cmp	x1, x2, lsl #16
    5ce8:	54000382 	b.cs	5d58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5cec:	d350fc22 	lsr	x2, x1, #16
    5cf0:	f949fe84 	ldr	x4, [x20, #5112]
    5cf4:	8b020842 	add	x2, x2, x2, lsl #2
    5cf8:	d37df042 	lsl	x2, x2, #3
    5cfc:	8b020083 	add	x3, x4, x2
    5d00:	f9401073 	ldr	x19, [x3, #32]
    5d04:	b40002b3 	cbz	x19, 5d58 <fwp_drop1+0x98>
    5d08:	38626882 	ldrb	w2, [x4, x2]
    5d0c:	7100085f 	cmp	w2, #0x2
    5d10:	540002c0 	b.eq	5d68 <fwp_drop1+0xa8>  // b.none
    5d14:	7100045f 	cmp	w2, #0x1
    5d18:	54000201 	b.ne	5d58 <fwp_drop1+0x98>  // b.any
    5d1c:	29430864 	ldp	w4, w2, [x3, #24]
    5d20:	92403c21 	and	x1, x1, #0xffff
    5d24:	9b047c21 	mul	x1, x1, x4
    5d28:	d360fc21 	lsr	x1, x1, #32
    5d2c:	eb02003f 	cmp	x1, x2
    5d30:	54000142 	b.cs	5d58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d34:	8b010273 	add	x19, x19, x1
    5d38:	39400261 	ldrb	w1, [x19]
    5d3c:	340000e1 	cbz	w1, 5d58 <fwp_drop1+0x98>
    5d40:	7100043f 	cmp	w1, #0x1
    5d44:	540001e0 	b.eq	5d80 <fwp_drop1+0xc0>  // b.none
    5d48:	7103fc3f 	cmp	w1, #0xff
    5d4c:	540002e0 	b.eq	5da8 <fwp_drop1+0xe8>  // b.none
    5d50:	51000421 	sub	w1, w1, #0x1
    5d54:	39000261 	strb	w1, [x19]
    5d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d5c:	f94013f5 	ldr	x21, [sp, #32]
    5d60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d64:	d65f03c0 	ret
    5d68:	72003c3f 	tst	w1, #0xffff
    5d6c:	54fffe60 	b.eq	5d38 <fwp_drop1+0x78>  // b.none
    5d70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d74:	f94013f5 	ldr	x21, [sp, #32]
    5d78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d7c:	d65f03c0 	ret
    5d80:	f9400813 	ldr	x19, [x0, #16]
    5d84:	97fffe9f 	bl	5800 <fwp_rc_free_arr>
    5d88:	9114c2a0 	add	x0, x21, #0x530
    5d8c:	f949d801 	ldr	x1, [x0, #5040]
    5d90:	f949ec00 	ldr	x0, [x0, #5080]
    5d94:	cb010261 	sub	x1, x19, x1
    5d98:	eb00403f 	cmp	x1, x0, lsl #16
    5d9c:	54fffde2 	b.cs	5d58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5da0:	aa1303e0 	mov	x0, x19
    5da4:	17ffffd2 	b	5cec <fwp_drop1+0x2c>
    5da8:	ca534660 	eor	x0, x19, x19, lsr #17
    5dac:	9114c2b5 	add	x21, x21, #0x530
    5db0:	ca402400 	eor	x0, x0, x0, lsr #9
    5db4:	92401c00 	and	x0, x0, #0xff
    5db8:	910a2402 	add	x2, x0, #0x289
    5dbc:	8b000ea0 	add	x0, x21, x0, lsl #3
    5dc0:	8b020ea2 	add	x2, x21, x2, lsl #3
    5dc4:	f94a2400 	ldr	x0, [x0, #5192]
    5dc8:	b50000a0 	cbnz	x0, 5ddc <fwp_drop1+0x11c>
    5dcc:	14000013 	b	5e18 <fwp_drop1+0x158>
    5dd0:	91004002 	add	x2, x0, #0x10
    5dd4:	f9400800 	ldr	x0, [x0, #16]
    5dd8:	b4000200 	cbz	x0, 5e18 <fwp_drop1+0x158>
    5ddc:	f9400001 	ldr	x1, [x0]
    5de0:	eb13003f 	cmp	x1, x19
    5de4:	54ffff61 	b.ne	5dd0 <fwp_drop1+0x110>  // b.any
    5de8:	f9400041 	ldr	x1, [x2]
    5dec:	f9400420 	ldr	x0, [x1, #8]
    5df0:	d1000400 	sub	x0, x0, #0x1
    5df4:	f9000420 	str	x0, [x1, #8]
    5df8:	f103f81f 	cmp	x0, #0xfe
    5dfc:	54fffae1 	b.ne	5d58 <fwp_drop1+0x98>  // b.any
    5e00:	39400260 	ldrb	w0, [x19]
    5e04:	7103fc1f 	cmp	w0, #0xff
    5e08:	540000e0 	b.eq	5e24 <fwp_drop1+0x164>  // b.none
    5e0c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e10:	39000260 	strb	w0, [x19]
    5e14:	17ffffd1 	b	5d58 <fwp_drop1+0x98>
    5e18:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    5e1c:	9132c000 	add	x0, x0, #0xcb0
    5e20:	97fff7f8 	bl	3e00 <fwp_trap>
    5e24:	aa1303e0 	mov	x0, x19
    5e28:	97fff816 	bl	3e80 <fwp_rc_forget_slot.part.0>
    5e2c:	17fffff8 	b	5e0c <fwp_drop1+0x14c>

0000000000005e30 <fwp_closure_drop>:
    5e30:	90000165 	adrp	x5, 31000 <fwp_root_context+0xcb0>
    5e34:	9114c0a4 	add	x4, x5, #0x530
    5e38:	aa0003e1 	mov	x1, x0
    5e3c:	f949d882 	ldr	x2, [x4, #5040]
    5e40:	f949ec80 	ldr	x0, [x4, #5080]
    5e44:	cb020022 	sub	x2, x1, x2
    5e48:	eb00405f 	cmp	x2, x0, lsl #16
    5e4c:	54000662 	b.cs	5f18 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5e50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5e54:	d350fc43 	lsr	x3, x2, #16
    5e58:	910003fd 	mov	x29, sp
    5e5c:	8b030863 	add	x3, x3, x3, lsl #2
    5e60:	f949fc84 	ldr	x4, [x4, #5112]
    5e64:	d37df063 	lsl	x3, x3, #3
    5e68:	f9000bf3 	str	x19, [sp, #16]
    5e6c:	8b030080 	add	x0, x4, x3
    5e70:	f9401013 	ldr	x19, [x0, #32]
    5e74:	b40002b3 	cbz	x19, 5ec8 <fwp_closure_drop+0x98>
    5e78:	38636883 	ldrb	w3, [x4, x3]
    5e7c:	7100087f 	cmp	w3, #0x2
    5e80:	54000420 	b.eq	5f04 <fwp_closure_drop+0xd4>  // b.none
    5e84:	7100047f 	cmp	w3, #0x1
    5e88:	54000201 	b.ne	5ec8 <fwp_closure_drop+0x98>  // b.any
    5e8c:	29430003 	ldp	w3, w0, [x0, #24]
    5e90:	92403c42 	and	x2, x2, #0xffff
    5e94:	9b037c42 	mul	x2, x2, x3
    5e98:	d360fc42 	lsr	x2, x2, #32
    5e9c:	eb00005f 	cmp	x2, x0
    5ea0:	54000142 	b.cs	5ec8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5ea4:	8b020273 	add	x19, x19, x2
    5ea8:	39400260 	ldrb	w0, [x19]
    5eac:	340000e0 	cbz	w0, 5ec8 <fwp_closure_drop+0x98>
    5eb0:	7100041f 	cmp	w0, #0x1
    5eb4:	54000100 	b.eq	5ed4 <fwp_closure_drop+0xa4>  // b.none
    5eb8:	7103fc1f 	cmp	w0, #0xff
    5ebc:	54000300 	b.eq	5f1c <fwp_closure_drop+0xec>  // b.none
    5ec0:	51000400 	sub	w0, w0, #0x1
    5ec4:	39000260 	strb	w0, [x19]
    5ec8:	f9400bf3 	ldr	x19, [sp, #16]
    5ecc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ed0:	d65f03c0 	ret
    5ed4:	d53bd040 	mrs	x0, tpidr_el0
    5ed8:	91400000 	add	x0, x0, #0x0, lsl #12
    5edc:	91004000 	add	x0, x0, #0x10
    5ee0:	f9400000 	ldr	x0, [x0]
    5ee4:	b4000080 	cbz	x0, 5ef4 <fwp_closure_drop+0xc4>
    5ee8:	f9400bf3 	ldr	x19, [sp, #16]
    5eec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ef0:	17fff940 	b	43f0 <fwp_closure_drop_push>
    5ef4:	f9400bf3 	ldr	x19, [sp, #16]
    5ef8:	aa0103e0 	mov	x0, x1
    5efc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f00:	17fff981 	b	4504 <fwp_closure_drop.part.0>
    5f04:	72003c5f 	tst	w2, #0xffff
    5f08:	54fffd00 	b.eq	5ea8 <fwp_closure_drop+0x78>  // b.none
    5f0c:	f9400bf3 	ldr	x19, [sp, #16]
    5f10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5f14:	d65f03c0 	ret
    5f18:	d65f03c0 	ret
    5f1c:	ca534660 	eor	x0, x19, x19, lsr #17
    5f20:	9114c0a5 	add	x5, x5, #0x530
    5f24:	ca402400 	eor	x0, x0, x0, lsr #9
    5f28:	92401c00 	and	x0, x0, #0xff
    5f2c:	910a2402 	add	x2, x0, #0x289
    5f30:	8b000ca0 	add	x0, x5, x0, lsl #3
    5f34:	8b020ca2 	add	x2, x5, x2, lsl #3
    5f38:	f94a2400 	ldr	x0, [x0, #5192]
    5f3c:	b50000a0 	cbnz	x0, 5f50 <fwp_closure_drop+0x120>
    5f40:	14000013 	b	5f8c <fwp_closure_drop+0x15c>
    5f44:	91004002 	add	x2, x0, #0x10
    5f48:	f9400800 	ldr	x0, [x0, #16]
    5f4c:	b4000200 	cbz	x0, 5f8c <fwp_closure_drop+0x15c>
    5f50:	f9400001 	ldr	x1, [x0]
    5f54:	eb13003f 	cmp	x1, x19
    5f58:	54ffff61 	b.ne	5f44 <fwp_closure_drop+0x114>  // b.any
    5f5c:	f9400041 	ldr	x1, [x2]
    5f60:	f9400420 	ldr	x0, [x1, #8]
    5f64:	d1000400 	sub	x0, x0, #0x1
    5f68:	f9000420 	str	x0, [x1, #8]
    5f6c:	f103f81f 	cmp	x0, #0xfe
    5f70:	54fffac1 	b.ne	5ec8 <fwp_closure_drop+0x98>  // b.any
    5f74:	39400260 	ldrb	w0, [x19]
    5f78:	7103fc1f 	cmp	w0, #0xff
    5f7c:	540000e0 	b.eq	5f98 <fwp_closure_drop+0x168>  // b.none
    5f80:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f84:	39000260 	strb	w0, [x19]
    5f88:	17ffffd0 	b	5ec8 <fwp_closure_drop+0x98>
    5f8c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    5f90:	9132c000 	add	x0, x0, #0xcb0
    5f94:	97fff79b 	bl	3e00 <fwp_trap>
    5f98:	aa1303e0 	mov	x0, x19
    5f9c:	97fff7b9 	bl	3e80 <fwp_rc_forget_slot.part.0>
    5fa0:	17fffff8 	b	5f80 <fwp_closure_drop+0x150>

0000000000005fa4 <fwp_owned_tape_release>:
    5fa4:	b4000920 	cbz	x0, 60c8 <fwp_owned_tape_release+0x124>
    5fa8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5fac:	910003fd 	mov	x29, sp
    5fb0:	a90153f3 	stp	x19, x20, [sp, #16]
    5fb4:	aa0003f3 	mov	x19, x0
    5fb8:	f9400000 	ldr	x0, [x0]
    5fbc:	b4000060 	cbz	x0, 5fc8 <fwp_owned_tape_release+0x24>
    5fc0:	f9400661 	ldr	x1, [x19, #8]
    5fc4:	f9000401 	str	x1, [x0, #8]
    5fc8:	f9400661 	ldr	x1, [x19, #8]
    5fcc:	b4000041 	cbz	x1, 5fd4 <fwp_owned_tape_release+0x30>
    5fd0:	f9000020 	str	x0, [x1]
    5fd4:	f9400a60 	ldr	x0, [x19, #16]
    5fd8:	f9403401 	ldr	x1, [x0, #104]
    5fdc:	b40005a1 	cbz	x1, 6090 <fwp_owned_tape_release+0xec>
    5fe0:	a9450a60 	ldp	x0, x2, [x19, #80]
    5fe4:	eb00005f 	cmp	x2, x0
    5fe8:	540002cd 	b.le	6040 <fwp_owned_tape_release+0x9c>
    5fec:	d2800014 	mov	x20, #0x0                   	// #0
    5ff0:	f90013f5 	str	x21, [sp, #32]
    5ff4:	d2800015 	mov	x21, #0x0                   	// #0
    5ff8:	f9402260 	ldr	x0, [x19, #64]
    5ffc:	910006b5 	add	x21, x21, #0x1
    6000:	f8746800 	ldr	x0, [x0, x20]
    6004:	d63f0020 	blr	x1
    6008:	f9402260 	ldr	x0, [x19, #64]
    600c:	f9400a61 	ldr	x1, [x19, #16]
    6010:	8b140000 	add	x0, x0, x20
    6014:	91004294 	add	x20, x20, #0x10
    6018:	f9400400 	ldr	x0, [x0, #8]
    601c:	f9403421 	ldr	x1, [x1, #104]
    6020:	d63f0020 	blr	x1
    6024:	a9450261 	ldp	x1, x0, [x19, #80]
    6028:	cb010000 	sub	x0, x0, x1
    602c:	eb15001f 	cmp	x0, x21
    6030:	f9400a60 	ldr	x0, [x19, #16]
    6034:	f9403401 	ldr	x1, [x0, #104]
    6038:	54fffe0c 	b.gt	5ff8 <fwp_owned_tape_release+0x54>
    603c:	f94013f5 	ldr	x21, [sp, #32]
    6040:	f9403663 	ldr	x3, [x19, #104]
    6044:	f9401262 	ldr	x2, [x19, #32]
    6048:	f100007f 	cmp	x3, #0x0
    604c:	540001ed 	b.le	6088 <fwp_owned_tape_release+0xe4>
    6050:	d2800014 	mov	x20, #0x0                   	// #0
    6054:	d503201f 	nop
    6058:	f9402660 	ldr	x0, [x19, #72]
    605c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6060:	eb02001f 	cmp	x0, x2
    6064:	540000c0 	b.eq	607c <fwp_owned_tape_release+0xd8>  // b.none
    6068:	d63f0020 	blr	x1
    606c:	f9400a60 	ldr	x0, [x19, #16]
    6070:	f9401262 	ldr	x2, [x19, #32]
    6074:	f9403663 	ldr	x3, [x19, #104]
    6078:	f9403401 	ldr	x1, [x0, #104]
    607c:	91000694 	add	x20, x20, #0x1
    6080:	eb14007f 	cmp	x3, x20
    6084:	54fffeac 	b.gt	6058 <fwp_owned_tape_release+0xb4>
    6088:	aa0203e0 	mov	x0, x2
    608c:	d63f0020 	blr	x1
    6090:	f9401660 	ldr	x0, [x19, #40]
    6094:	97ffff67 	bl	5e30 <fwp_closure_drop>
    6098:	f9401a60 	ldr	x0, [x19, #48]
    609c:	97ffff65 	bl	5e30 <fwp_closure_drop>
    60a0:	f9401e60 	ldr	x0, [x19, #56]
    60a4:	97ffff63 	bl	5e30 <fwp_closure_drop>
    60a8:	f9402260 	ldr	x0, [x19, #64]
    60ac:	97fff811 	bl	40f0 <fwp_mem_free>
    60b0:	f9402660 	ldr	x0, [x19, #72]
    60b4:	97fff80f 	bl	40f0 <fwp_mem_free>
    60b8:	aa1303e0 	mov	x0, x19
    60bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    60c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60c4:	17fff80b 	b	40f0 <fwp_mem_free>
    60c8:	d65f03c0 	ret
    60cc:	d503201f 	nop

00000000000060d0 <fwp_tape_finish>:
    60d0:	d101c3ff 	sub	sp, sp, #0x70
    60d4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    60d8:	f947f421 	ldr	x1, [x1, #4072]
    60dc:	a9037bfd 	stp	x29, x30, [sp, #48]
    60e0:	9100c3fd 	add	x29, sp, #0x30
    60e4:	a90453f3 	stp	x19, x20, [sp, #64]
    60e8:	a9055bf5 	stp	x21, x22, [sp, #80]
    60ec:	a90663f7 	stp	x23, x24, [sp, #96]
    60f0:	d00000d8 	adrp	x24, 20000 <__data_start>
    60f4:	9100c316 	add	x22, x24, #0x30
    60f8:	f9400022 	ldr	x2, [x1]
    60fc:	f90017e2 	str	x2, [sp, #40]
    6100:	d2800002 	mov	x2, #0x0                   	// #0
    6104:	9100e2c0 	add	x0, x22, #0x38
    6108:	97fff45e 	bl	3280 <fwp_tape_buffers_dispose>
    610c:	f90032df 	str	xzr, [x22, #96]
    6110:	f9403ac0 	ldr	x0, [x22, #112]
    6114:	f100001f 	cmp	x0, #0x0
    6118:	540002cd 	b.le	6170 <fwp_tape_finish+0xa0>
    611c:	910003f7 	mov	x23, sp
    6120:	d2800015 	mov	x21, #0x0                   	// #0
    6124:	d2800014 	mov	x20, #0x0                   	// #0
    6128:	f94002d3 	ldr	x19, [x22]
    612c:	91000694 	add	x20, x20, #0x1
    6130:	8b150273 	add	x19, x19, x21
    6134:	910162b5 	add	x21, x21, #0x58
    6138:	aa1303e0 	mov	x0, x19
    613c:	97fff375 	bl	2f10 <fwp_tape_unlink_scope>
    6140:	aa1703e0 	mov	x0, x23
    6144:	3dc00a60 	ldr	q0, [x19, #32]
    6148:	f9401a61 	ldr	x1, [x19, #48]
    614c:	f9000be1 	str	x1, [sp, #16]
    6150:	3d8003e0 	str	q0, [sp]
    6154:	97fff44b 	bl	3280 <fwp_tape_buffers_dispose>
    6158:	f9402a60 	ldr	x0, [x19, #80]
    615c:	97ffff92 	bl	5fa4 <fwp_owned_tape_release>
    6160:	f9002a7f 	str	xzr, [x19, #80]
    6164:	f9403ac0 	ldr	x0, [x22, #112]
    6168:	eb14001f 	cmp	x0, x20
    616c:	54fffdec 	b.gt	6128 <fwp_tape_finish+0x58>
    6170:	f9401b00 	ldr	x0, [x24, #48]
    6174:	9100c313 	add	x19, x24, #0x30
    6178:	97fff1d2 	bl	28c0 <free@plt>
    617c:	f9001b1f 	str	xzr, [x24, #48]
    6180:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    6184:	f947f400 	ldr	x0, [x0, #4072]
    6188:	f9003a7f 	str	xzr, [x19, #112]
    618c:	a9087e7f 	stp	xzr, xzr, [x19, #128]
    6190:	f94017e2 	ldr	x2, [sp, #40]
    6194:	f9400001 	ldr	x1, [x0]
    6198:	eb010042 	subs	x2, x2, x1
    619c:	d2800001 	mov	x1, #0x0                   	// #0
    61a0:	540000e1 	b.ne	61bc <fwp_tape_finish+0xec>  // b.any
    61a4:	a9437bfd 	ldp	x29, x30, [sp, #48]
    61a8:	a94453f3 	ldp	x19, x20, [sp, #64]
    61ac:	a9455bf5 	ldp	x21, x22, [sp, #80]
    61b0:	a94663f7 	ldp	x23, x24, [sp, #96]
    61b4:	9101c3ff 	add	sp, sp, #0x70
    61b8:	d65f03c0 	ret
    61bc:	97fff191 	bl	2800 <__stack_chk_fail@plt>

00000000000061c0 <fwp_tape_scope_release>:
    61c0:	d10203ff 	sub	sp, sp, #0x80
    61c4:	a9037bfd 	stp	x29, x30, [sp, #48]
    61c8:	9100c3fd 	add	x29, sp, #0x30
    61cc:	a90453f3 	stp	x19, x20, [sp, #64]
    61d0:	aa0003f4 	mov	x20, x0
    61d4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    61d8:	f947f400 	ldr	x0, [x0, #4072]
    61dc:	b9400285 	ldr	w5, [x20]
    61e0:	f9400001 	ldr	x1, [x0]
    61e4:	f90017e1 	str	x1, [sp, #40]
    61e8:	d2800001 	mov	x1, #0x0                   	// #0
    61ec:	37f806e5 	tbnz	w5, #31, 62c8 <fwp_tape_scope_release+0x108>
    61f0:	a90663f7 	stp	x23, x24, [sp, #96]
    61f4:	d2917478 	mov	x24, #0x8ba3                	// #35747
    61f8:	f2b745d8 	movk	x24, #0xba2e, lsl #16
    61fc:	f2d45d18 	movk	x24, #0xa2e8, lsl #32
    6200:	d00000d3 	adrp	x19, 20000 <__data_start>
    6204:	910003f7 	mov	x23, sp
    6208:	9100c273 	add	x19, x19, #0x30
    620c:	f2e5d178 	movk	x24, #0x2e8b, lsl #48
    6210:	a9055bf5 	stp	x21, x22, [sp, #80]
    6214:	52800b16 	mov	w22, #0x58                  	// #88
    6218:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    621c:	f9003bf9 	str	x25, [sp, #112]
    6220:	14000006 	b	6238 <fwp_tape_scope_release+0x78>
    6224:	97fff417 	bl	3280 <fwp_tape_buffers_dispose>
    6228:	aa1903e0 	mov	x0, x25
    622c:	97ffff5e 	bl	5fa4 <fwp_owned_tape_release>
    6230:	b9400285 	ldr	w5, [x20]
    6234:	37f80445 	tbnz	w5, #31, 62bc <fwp_tape_scope_release+0xfc>
    6238:	f9400266 	ldr	x6, [x19]
    623c:	9b367ca5 	smull	x5, w5, w22
    6240:	8b0500c0 	add	x0, x6, x5
    6244:	97fff333 	bl	2f10 <fwp_tape_unlink_scope>
    6248:	3dc00800 	ldr	q0, [x0, #32]
    624c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6250:	f9400c03 	ldr	x3, [x0, #24]
    6254:	3d8003e0 	str	q0, [sp]
    6258:	b86568c1 	ldr	w1, [x6, x5]
    625c:	f9401802 	ldr	x2, [x0, #48]
    6260:	a9010fe2 	stp	x2, x3, [sp, #16]
    6264:	f9401c02 	ldr	x2, [x0, #56]
    6268:	b900041f 	str	wzr, [x0, #4]
    626c:	f9402819 	ldr	x25, [x0, #80]
    6270:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6274:	f9000c1f 	str	xzr, [x0, #24]
    6278:	f90013e2 	str	x2, [sp, #32]
    627c:	f900181f 	str	xzr, [x0, #48]
    6280:	f9001c1f 	str	xzr, [x0, #56]
    6284:	f900281f 	str	xzr, [x0, #80]
    6288:	6b15003f 	cmp	w1, w21
    628c:	540000e8 	b.hi	62a8 <fwp_tape_scope_release+0xe8>  // b.pmore
    6290:	9343fca5 	asr	x5, x5, #3
    6294:	f9404660 	ldr	x0, [x19, #136]
    6298:	9b187ca5 	mul	x5, x5, x24
    629c:	eb0000bf 	cmp	x5, x0
    62a0:	5400004a 	b.ge	62a8 <fwp_tape_scope_release+0xe8>  // b.tcont
    62a4:	f9004665 	str	x5, [x19, #136]
    62a8:	aa1703e0 	mov	x0, x23
    62ac:	b5fffbd9 	cbnz	x25, 6224 <fwp_tape_scope_release+0x64>
    62b0:	97fff690 	bl	3cf0 <fwp_tape_buffers_release>
    62b4:	b9400285 	ldr	w5, [x20]
    62b8:	36fffc05 	tbz	w5, #31, 6238 <fwp_tape_scope_release+0x78>
    62bc:	a9455bf5 	ldp	x21, x22, [sp, #80]
    62c0:	a94663f7 	ldp	x23, x24, [sp, #96]
    62c4:	f9403bf9 	ldr	x25, [sp, #112]
    62c8:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    62cc:	f947f400 	ldr	x0, [x0, #4072]
    62d0:	f94017e2 	ldr	x2, [sp, #40]
    62d4:	f9400001 	ldr	x1, [x0]
    62d8:	eb010042 	subs	x2, x2, x1
    62dc:	d2800001 	mov	x1, #0x0                   	// #0
    62e0:	540000a1 	b.ne	62f4 <fwp_tape_scope_release+0x134>  // b.any
    62e4:	a9437bfd 	ldp	x29, x30, [sp, #48]
    62e8:	a94453f3 	ldp	x19, x20, [sp, #64]
    62ec:	910203ff 	add	sp, sp, #0x80
    62f0:	d65f03c0 	ret
    62f4:	a9055bf5 	stp	x21, x22, [sp, #80]
    62f8:	a90663f7 	stp	x23, x24, [sp, #96]
    62fc:	f9003bf9 	str	x25, [sp, #112]
    6300:	97fff140 	bl	2800 <__stack_chk_fail@plt>

0000000000006304 <fwp_drop4>:
    6304:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6308:	910003fd 	mov	x29, sp
    630c:	a9025bf5 	stp	x21, x22, [sp, #32]
    6310:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    6314:	9114c2d5 	add	x21, x22, #0x530
    6318:	a90153f3 	stp	x19, x20, [sp, #16]
    631c:	aa0003f3 	mov	x19, x0
    6320:	f949daa1 	ldr	x1, [x21, #5040]
    6324:	f949eea0 	ldr	x0, [x21, #5080]
    6328:	cb010261 	sub	x1, x19, x1
    632c:	eb00403f 	cmp	x1, x0, lsl #16
    6330:	54000382 	b.cs	63a0 <fwp_drop4+0x9c>  // b.hs, b.nlast
    6334:	d350fc22 	lsr	x2, x1, #16
    6338:	f949fea3 	ldr	x3, [x21, #5112]
    633c:	8b020842 	add	x2, x2, x2, lsl #2
    6340:	d37df042 	lsl	x2, x2, #3
    6344:	8b020060 	add	x0, x3, x2
    6348:	f9401014 	ldr	x20, [x0, #32]
    634c:	b40002b4 	cbz	x20, 63a0 <fwp_drop4+0x9c>
    6350:	38626862 	ldrb	w2, [x3, x2]
    6354:	7100085f 	cmp	w2, #0x2
    6358:	540002c0 	b.eq	63b0 <fwp_drop4+0xac>  // b.none
    635c:	7100045f 	cmp	w2, #0x1
    6360:	54000201 	b.ne	63a0 <fwp_drop4+0x9c>  // b.any
    6364:	29430002 	ldp	w2, w0, [x0, #24]
    6368:	92403c21 	and	x1, x1, #0xffff
    636c:	9b027c21 	mul	x1, x1, x2
    6370:	d360fc21 	lsr	x1, x1, #32
    6374:	eb00003f 	cmp	x1, x0
    6378:	54000142 	b.cs	63a0 <fwp_drop4+0x9c>  // b.hs, b.nlast
    637c:	8b010294 	add	x20, x20, x1
    6380:	39400280 	ldrb	w0, [x20]
    6384:	340000e0 	cbz	w0, 63a0 <fwp_drop4+0x9c>
    6388:	7100041f 	cmp	w0, #0x1
    638c:	540001e0 	b.eq	63c8 <fwp_drop4+0xc4>  // b.none
    6390:	7103fc1f 	cmp	w0, #0xff
    6394:	540007e0 	b.eq	6490 <fwp_drop4+0x18c>  // b.none
    6398:	51000400 	sub	w0, w0, #0x1
    639c:	39000280 	strb	w0, [x20]
    63a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    63a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    63a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63ac:	d65f03c0 	ret
    63b0:	72003c3f 	tst	w1, #0xffff
    63b4:	54fffe60 	b.eq	6380 <fwp_drop4+0x7c>  // b.none
    63b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    63bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    63c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63c4:	d65f03c0 	ret
    63c8:	9114c2c2 	add	x2, x22, #0x530
    63cc:	f9400660 	ldr	x0, [x19, #8]
    63d0:	f949d841 	ldr	x1, [x2, #5040]
    63d4:	f949ec42 	ldr	x2, [x2, #5080]
    63d8:	cb010001 	sub	x1, x0, x1
    63dc:	eb02403f 	cmp	x1, x2, lsl #16
    63e0:	54000382 	b.cs	6450 <fwp_drop4+0x14c>  // b.hs, b.nlast
    63e4:	d350fc22 	lsr	x2, x1, #16
    63e8:	8b020842 	add	x2, x2, x2, lsl #2
    63ec:	d37df042 	lsl	x2, x2, #3
    63f0:	8b020064 	add	x4, x3, x2
    63f4:	f9401094 	ldr	x20, [x4, #32]
    63f8:	b40002d4 	cbz	x20, 6450 <fwp_drop4+0x14c>
    63fc:	38626862 	ldrb	w2, [x3, x2]
    6400:	7100085f 	cmp	w2, #0x2
    6404:	54000400 	b.eq	6484 <fwp_drop4+0x180>  // b.none
    6408:	7100045f 	cmp	w2, #0x1
    640c:	54000221 	b.ne	6450 <fwp_drop4+0x14c>  // b.any
    6410:	29430883 	ldp	w3, w2, [x4, #24]
    6414:	92403c21 	and	x1, x1, #0xffff
    6418:	9b037c21 	mul	x1, x1, x3
    641c:	d360fc21 	lsr	x1, x1, #32
    6420:	eb02003f 	cmp	x1, x2
    6424:	54000162 	b.cs	6450 <fwp_drop4+0x14c>  // b.hs, b.nlast
    6428:	8b010294 	add	x20, x20, x1
    642c:	39400281 	ldrb	w1, [x20]
    6430:	34000101 	cbz	w1, 6450 <fwp_drop4+0x14c>
    6434:	7100043f 	cmp	w1, #0x1
    6438:	54000220 	b.eq	647c <fwp_drop4+0x178>  // b.none
    643c:	7103fc3f 	cmp	w1, #0xff
    6440:	54000660 	b.eq	650c <fwp_drop4+0x208>  // b.none
    6444:	51000421 	sub	w1, w1, #0x1
    6448:	39000281 	strb	w1, [x20]
    644c:	d503201f 	nop
    6450:	f9400a74 	ldr	x20, [x19, #16]
    6454:	aa1303e0 	mov	x0, x19
    6458:	97fffcea 	bl	5800 <fwp_rc_free_arr>
    645c:	9114c2c0 	add	x0, x22, #0x530
    6460:	f949d801 	ldr	x1, [x0, #5040]
    6464:	f949ec00 	ldr	x0, [x0, #5080]
    6468:	cb010281 	sub	x1, x20, x1
    646c:	eb00403f 	cmp	x1, x0, lsl #16
    6470:	54fff982 	b.cs	63a0 <fwp_drop4+0x9c>  // b.hs, b.nlast
    6474:	aa1403f3 	mov	x19, x20
    6478:	17ffffaf 	b	6334 <fwp_drop4+0x30>
    647c:	97fffce1 	bl	5800 <fwp_rc_free_arr>
    6480:	17fffff4 	b	6450 <fwp_drop4+0x14c>
    6484:	72003c3f 	tst	w1, #0xffff
    6488:	54fffe41 	b.ne	6450 <fwp_drop4+0x14c>  // b.any
    648c:	17ffffe8 	b	642c <fwp_drop4+0x128>
    6490:	ca544681 	eor	x1, x20, x20, lsr #17
    6494:	9114c2c0 	add	x0, x22, #0x530
    6498:	ca412421 	eor	x1, x1, x1, lsr #9
    649c:	92401c21 	and	x1, x1, #0xff
    64a0:	910a2422 	add	x2, x1, #0x289
    64a4:	8b010c01 	add	x1, x0, x1, lsl #3
    64a8:	8b020c02 	add	x2, x0, x2, lsl #3
    64ac:	f94a2420 	ldr	x0, [x1, #5192]
    64b0:	b50000a0 	cbnz	x0, 64c4 <fwp_drop4+0x1c0>
    64b4:	14000013 	b	6500 <fwp_drop4+0x1fc>
    64b8:	91004002 	add	x2, x0, #0x10
    64bc:	f9400800 	ldr	x0, [x0, #16]
    64c0:	b4000200 	cbz	x0, 6500 <fwp_drop4+0x1fc>
    64c4:	f9400001 	ldr	x1, [x0]
    64c8:	eb14003f 	cmp	x1, x20
    64cc:	54ffff61 	b.ne	64b8 <fwp_drop4+0x1b4>  // b.any
    64d0:	f9400041 	ldr	x1, [x2]
    64d4:	f9400420 	ldr	x0, [x1, #8]
    64d8:	d1000400 	sub	x0, x0, #0x1
    64dc:	f9000420 	str	x0, [x1, #8]
    64e0:	f103f81f 	cmp	x0, #0xfe
    64e4:	54fff5e1 	b.ne	63a0 <fwp_drop4+0x9c>  // b.any
    64e8:	39400280 	ldrb	w0, [x20]
    64ec:	7103fc1f 	cmp	w0, #0xff
    64f0:	54000460 	b.eq	657c <fwp_drop4+0x278>  // b.none
    64f4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64f8:	39000280 	strb	w0, [x20]
    64fc:	17ffffa9 	b	63a0 <fwp_drop4+0x9c>
    6500:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    6504:	9132c000 	add	x0, x0, #0xcb0
    6508:	97fff63e 	bl	3e00 <fwp_trap>
    650c:	ca544680 	eor	x0, x20, x20, lsr #17
    6510:	9114c2c1 	add	x1, x22, #0x530
    6514:	ca402400 	eor	x0, x0, x0, lsr #9
    6518:	92401c00 	and	x0, x0, #0xff
    651c:	910a2402 	add	x2, x0, #0x289
    6520:	8b000c20 	add	x0, x1, x0, lsl #3
    6524:	8b020c22 	add	x2, x1, x2, lsl #3
    6528:	f94a2400 	ldr	x0, [x0, #5192]
    652c:	b50000a0 	cbnz	x0, 6540 <fwp_drop4+0x23c>
    6530:	17fffff4 	b	6500 <fwp_drop4+0x1fc>
    6534:	91004002 	add	x2, x0, #0x10
    6538:	f9400800 	ldr	x0, [x0, #16]
    653c:	b4fffe20 	cbz	x0, 6500 <fwp_drop4+0x1fc>
    6540:	f9400001 	ldr	x1, [x0]
    6544:	eb14003f 	cmp	x1, x20
    6548:	54ffff61 	b.ne	6534 <fwp_drop4+0x230>  // b.any
    654c:	f9400041 	ldr	x1, [x2]
    6550:	f9400420 	ldr	x0, [x1, #8]
    6554:	d1000400 	sub	x0, x0, #0x1
    6558:	f9000420 	str	x0, [x1, #8]
    655c:	f103f81f 	cmp	x0, #0xfe
    6560:	54fff781 	b.ne	6450 <fwp_drop4+0x14c>  // b.any
    6564:	39400280 	ldrb	w0, [x20]
    6568:	7103fc1f 	cmp	w0, #0xff
    656c:	540000e0 	b.eq	6588 <fwp_drop4+0x284>  // b.none
    6570:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6574:	39000280 	strb	w0, [x20]
    6578:	17ffffb6 	b	6450 <fwp_drop4+0x14c>
    657c:	aa1403e0 	mov	x0, x20
    6580:	97fff640 	bl	3e80 <fwp_rc_forget_slot.part.0>
    6584:	17ffffdc 	b	64f4 <fwp_drop4+0x1f0>
    6588:	aa1403e0 	mov	x0, x20
    658c:	97fff63d 	bl	3e80 <fwp_rc_forget_slot.part.0>
    6590:	17fffff8 	b	6570 <fwp_drop4+0x26c>

0000000000006594 <fwp_arg_drop37>:
    6594:	7100003f 	cmp	w1, #0x0
    6598:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    659c:	54000041 	b.ne	65a4 <fwp_arg_drop37+0x10>  // b.any
    65a0:	d65f03c0 	ret
    65a4:	f9400000 	ldr	x0, [x0]
    65a8:	17ffff57 	b	6304 <fwp_drop4>
    65ac:	d503201f 	nop

00000000000065b0 <fwp_task_dispose>:
    65b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65b4:	910003fd 	mov	x29, sp
    65b8:	f9000bf3 	str	x19, [sp, #16]
    65bc:	aa0003f3 	mov	x19, x0
    65c0:	39414000 	ldrb	w0, [x0, #80]
    65c4:	36000720 	tbz	w0, #0, 66a8 <fwp_task_dispose+0xf8>
    65c8:	f9400a60 	ldr	x0, [x19, #16]
    65cc:	b50006e0 	cbnz	x0, 66a8 <fwp_task_dispose+0xf8>
    65d0:	a9478660 	ldp	x0, x1, [x19, #120]
    65d4:	39014e7f 	strb	wzr, [x19, #83]
    65d8:	f9003e7f 	str	xzr, [x19, #120]
    65dc:	f100003f 	cmp	x1, #0x0
    65e0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    65e4:	54000040 	b.eq	65ec <fwp_task_dispose+0x3c>  // b.none
    65e8:	d63f0020 	blr	x1
    65ec:	f9405660 	ldr	x0, [x19, #168]
    65f0:	97fff6c0 	bl	40f0 <fwp_mem_free>
    65f4:	f900567f 	str	xzr, [x19, #168]
    65f8:	b9405e60 	ldr	w0, [x19, #92]
    65fc:	7100041f 	cmp	w0, #0x1
    6600:	54000420 	b.eq	6684 <fwp_task_dispose+0xd4>  // b.none
    6604:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    6608:	9114c042 	add	x2, x2, #0x530
    660c:	f949d840 	ldr	x0, [x2, #5040]
    6610:	f949ec41 	ldr	x1, [x2, #5080]
    6614:	cb000260 	sub	x0, x19, x0
    6618:	eb01401f 	cmp	x0, x1, lsl #16
    661c:	540002e2 	b.cs	6678 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6620:	d350fc01 	lsr	x1, x0, #16
    6624:	f949fc44 	ldr	x4, [x2, #5112]
    6628:	8b010821 	add	x1, x1, x1, lsl #2
    662c:	d37df021 	lsl	x1, x1, #3
    6630:	8b010083 	add	x3, x4, x1
    6634:	f9401062 	ldr	x2, [x3, #32]
    6638:	b4000202 	cbz	x2, 6678 <fwp_task_dispose+0xc8>
    663c:	38616881 	ldrb	w1, [x4, x1]
    6640:	7100083f 	cmp	w1, #0x2
    6644:	54000280 	b.eq	6694 <fwp_task_dispose+0xe4>  // b.none
    6648:	7100043f 	cmp	w1, #0x1
    664c:	54000161 	b.ne	6678 <fwp_task_dispose+0xc8>  // b.any
    6650:	29430464 	ldp	w4, w1, [x3, #24]
    6654:	92403c00 	and	x0, x0, #0xffff
    6658:	9b047c00 	mul	x0, x0, x4
    665c:	d360fc00 	lsr	x0, x0, #32
    6660:	eb01001f 	cmp	x0, x1
    6664:	540000a2 	b.cs	6678 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6668:	8b000042 	add	x2, x2, x0
    666c:	39400040 	ldrb	w0, [x2]
    6670:	7100041f 	cmp	w0, #0x1
    6674:	54000080 	b.eq	6684 <fwp_task_dispose+0xd4>  // b.none
    6678:	f9400bf3 	ldr	x19, [sp, #16]
    667c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6680:	d65f03c0 	ret
    6684:	aa1303e0 	mov	x0, x19
    6688:	f9400bf3 	ldr	x19, [sp, #16]
    668c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6690:	17fff698 	b	40f0 <fwp_mem_free>
    6694:	72003c1f 	tst	w0, #0xffff
    6698:	54fffea0 	b.eq	666c <fwp_task_dispose+0xbc>  // b.none
    669c:	f9400bf3 	ldr	x19, [sp, #16]
    66a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    66a4:	d65f03c0 	ret
    66a8:	97fff06a 	bl	2850 <abort@plt>
    66ac:	d503201f 	nop

00000000000066b0 <fwp_free_zombie>:
    66b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    66b4:	910003fd 	mov	x29, sp
    66b8:	a90153f3 	stp	x19, x20, [sp, #16]
    66bc:	d00000d4 	adrp	x20, 20000 <__data_start>
    66c0:	9100c281 	add	x1, x20, #0x30
    66c4:	f9404833 	ldr	x19, [x1, #144]
    66c8:	b4000333 	cbz	x19, 672c <fwp_free_zombie+0x7c>
    66cc:	f9400820 	ldr	x0, [x1, #16]
    66d0:	eb00027f 	cmp	x19, x0
    66d4:	540002c0 	b.eq	672c <fwp_free_zombie+0x7c>  // b.none
    66d8:	b9409822 	ldr	w2, [x1, #152]
    66dc:	f9400a60 	ldr	x0, [x19, #16]
    66e0:	7100fc5f 	cmp	w2, #0x3f
    66e4:	5400078c 	b.gt	67d4 <fwp_free_zombie+0x124>
    66e8:	91028023 	add	x3, x1, #0xa0
    66ec:	11000444 	add	w4, w2, #0x1
    66f0:	b9009824 	str	w4, [x1, #152]
    66f4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66f8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    66fc:	a9530261 	ldp	x1, x0, [x19, #304]
    6700:	b4000741 	cbz	x1, 67e8 <fwp_free_zombie+0x138>
    6704:	f9009c20 	str	x0, [x1, #312]
    6708:	b4000040 	cbz	x0, 6710 <fwp_free_zombie+0x60>
    670c:	f9009801 	str	x1, [x0, #304]
    6710:	9100c294 	add	x20, x20, #0x30
    6714:	b9405e60 	ldr	w0, [x19, #92]
    6718:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    671c:	f9004a9f 	str	xzr, [x20, #144]
    6720:	34000140 	cbz	w0, 6748 <fwp_free_zombie+0x98>
    6724:	7100041f 	cmp	w0, #0x1
    6728:	54000080 	b.eq	6738 <fwp_free_zombie+0x88>  // b.none
    672c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6730:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6734:	d65f03c0 	ret
    6738:	aa1303e0 	mov	x0, x19
    673c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6740:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6744:	17ffff9b 	b	65b0 <fwp_task_dispose>
    6748:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xcb0>
    674c:	9114c082 	add	x2, x4, #0x530
    6750:	f949d841 	ldr	x1, [x2, #5040]
    6754:	f949ec40 	ldr	x0, [x2, #5080]
    6758:	cb010261 	sub	x1, x19, x1
    675c:	eb00403f 	cmp	x1, x0, lsl #16
    6760:	54fffe62 	b.cs	672c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6764:	d350fc20 	lsr	x0, x1, #16
    6768:	f949fc43 	ldr	x3, [x2, #5112]
    676c:	8b000800 	add	x0, x0, x0, lsl #2
    6770:	d37df000 	lsl	x0, x0, #3
    6774:	8b000062 	add	x2, x3, x0
    6778:	f9401054 	ldr	x20, [x2, #32]
    677c:	b4fffd94 	cbz	x20, 672c <fwp_free_zombie+0x7c>
    6780:	38606860 	ldrb	w0, [x3, x0]
    6784:	7100081f 	cmp	w0, #0x2
    6788:	54000360 	b.eq	67f4 <fwp_free_zombie+0x144>  // b.none
    678c:	7100041f 	cmp	w0, #0x1
    6790:	54fffce1 	b.ne	672c <fwp_free_zombie+0x7c>  // b.any
    6794:	29430043 	ldp	w3, w0, [x2, #24]
    6798:	92403c21 	and	x1, x1, #0xffff
    679c:	9b037c21 	mul	x1, x1, x3
    67a0:	d360fc21 	lsr	x1, x1, #32
    67a4:	eb00003f 	cmp	x1, x0
    67a8:	54fffc22 	b.cs	672c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    67ac:	8b010294 	add	x20, x20, x1
    67b0:	39400280 	ldrb	w0, [x20]
    67b4:	34fffbc0 	cbz	w0, 672c <fwp_free_zombie+0x7c>
    67b8:	7100041f 	cmp	w0, #0x1
    67bc:	54fffbe0 	b.eq	6738 <fwp_free_zombie+0x88>  // b.none
    67c0:	7103fc1f 	cmp	w0, #0xff
    67c4:	540001e0 	b.eq	6800 <fwp_free_zombie+0x150>  // b.none
    67c8:	51000400 	sub	w0, w0, #0x1
    67cc:	39000280 	strb	w0, [x20]
    67d0:	17ffffd7 	b	672c <fwp_free_zombie+0x7c>
    67d4:	f9400e61 	ldr	x1, [x19, #24]
    67d8:	97fff052 	bl	2920 <munmap@plt>
    67dc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67e0:	a9530261 	ldp	x1, x0, [x19, #304]
    67e4:	b5fff901 	cbnz	x1, 6704 <fwp_free_zombie+0x54>
    67e8:	9100c282 	add	x2, x20, #0x30
    67ec:	f9015040 	str	x0, [x2, #672]
    67f0:	17ffffc6 	b	6708 <fwp_free_zombie+0x58>
    67f4:	72003c3f 	tst	w1, #0xffff
    67f8:	54fff9a1 	b.ne	672c <fwp_free_zombie+0x7c>  // b.any
    67fc:	17ffffed 	b	67b0 <fwp_free_zombie+0x100>
    6800:	ca544680 	eor	x0, x20, x20, lsr #17
    6804:	9114c084 	add	x4, x4, #0x530
    6808:	ca402400 	eor	x0, x0, x0, lsr #9
    680c:	92401c00 	and	x0, x0, #0xff
    6810:	910a2402 	add	x2, x0, #0x289
    6814:	8b000c80 	add	x0, x4, x0, lsl #3
    6818:	8b020c82 	add	x2, x4, x2, lsl #3
    681c:	f94a2400 	ldr	x0, [x0, #5192]
    6820:	b50000a0 	cbnz	x0, 6834 <fwp_free_zombie+0x184>
    6824:	14000013 	b	6870 <fwp_free_zombie+0x1c0>
    6828:	91004002 	add	x2, x0, #0x10
    682c:	f9400800 	ldr	x0, [x0, #16]
    6830:	b4000200 	cbz	x0, 6870 <fwp_free_zombie+0x1c0>
    6834:	f9400001 	ldr	x1, [x0]
    6838:	eb14003f 	cmp	x1, x20
    683c:	54ffff61 	b.ne	6828 <fwp_free_zombie+0x178>  // b.any
    6840:	f9400041 	ldr	x1, [x2]
    6844:	f9400420 	ldr	x0, [x1, #8]
    6848:	d1000400 	sub	x0, x0, #0x1
    684c:	f9000420 	str	x0, [x1, #8]
    6850:	f103f81f 	cmp	x0, #0xfe
    6854:	54fff6c1 	b.ne	672c <fwp_free_zombie+0x7c>  // b.any
    6858:	39400280 	ldrb	w0, [x20]
    685c:	7103fc1f 	cmp	w0, #0xff
    6860:	540000e0 	b.eq	687c <fwp_free_zombie+0x1cc>  // b.none
    6864:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6868:	39000280 	strb	w0, [x20]
    686c:	17ffffb0 	b	672c <fwp_free_zombie+0x7c>
    6870:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    6874:	9132c000 	add	x0, x0, #0xcb0
    6878:	97fff562 	bl	3e00 <fwp_trap>
    687c:	aa1403e0 	mov	x0, x20
    6880:	97fff580 	bl	3e80 <fwp_rc_forget_slot.part.0>
    6884:	17fffff8 	b	6864 <fwp_free_zombie+0x1b4>
    6888:	d503201f 	nop
    688c:	d503201f 	nop

0000000000006890 <fwp_block>:
    6890:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6894:	910003fd 	mov	x29, sp
    6898:	a90153f3 	stp	x19, x20, [sp, #16]
    689c:	d00000d3 	adrp	x19, 20000 <__data_start>
    68a0:	9100c274 	add	x20, x19, #0x30
    68a4:	f9401a82 	ldr	x2, [x20, #48]
    68a8:	b4000642 	cbz	x2, 6970 <fwp_block+0xe0>
    68ac:	9100c261 	add	x1, x19, #0x30
    68b0:	f9408040 	ldr	x0, [x2, #256]
    68b4:	f9001820 	str	x0, [x1, #48]
    68b8:	b40006a0 	cbz	x0, 698c <fwp_block+0xfc>
    68bc:	d503201f 	nop
    68c0:	9100c263 	add	x3, x19, #0x30
    68c4:	3901505f 	strb	wzr, [x2, #84]
    68c8:	f9400864 	ldr	x4, [x3, #16]
    68cc:	eb02009f 	cmp	x4, x2
    68d0:	54000440 	b.eq	6958 <fwp_block+0xc8>  // b.none
    68d4:	f9415465 	ldr	x5, [x3, #680]
    68d8:	f9000862 	str	x2, [x3, #16]
    68dc:	f9400441 	ldr	x1, [x2, #8]
    68e0:	f9004885 	str	x5, [x4, #144]
    68e4:	f9415865 	ldr	x5, [x3, #688]
    68e8:	f9004c85 	str	x5, [x4, #152]
    68ec:	f9415c65 	ldr	x5, [x3, #696]
    68f0:	f9005085 	str	x5, [x4, #160]
    68f4:	f9416065 	ldr	x5, [x3, #704]
    68f8:	f9005485 	str	x5, [x4, #168]
    68fc:	f9416465 	ldr	x5, [x3, #712]
    6900:	f9005885 	str	x5, [x4, #176]
    6904:	f9416865 	ldr	x5, [x3, #720]
    6908:	f9005c85 	str	x5, [x4, #184]
    690c:	f9416c65 	ldr	x5, [x3, #728]
    6910:	f9006085 	str	x5, [x4, #192]
    6914:	f9400480 	ldr	x0, [x4, #8]
    6918:	f9404844 	ldr	x4, [x2, #144]
    691c:	f9015464 	str	x4, [x3, #680]
    6920:	f9404c44 	ldr	x4, [x2, #152]
    6924:	f9015864 	str	x4, [x3, #688]
    6928:	f9405044 	ldr	x4, [x2, #160]
    692c:	f9015c64 	str	x4, [x3, #696]
    6930:	f9405444 	ldr	x4, [x2, #168]
    6934:	f9016064 	str	x4, [x3, #704]
    6938:	f9405844 	ldr	x4, [x2, #176]
    693c:	f9016464 	str	x4, [x3, #712]
    6940:	a94b8844 	ldp	x4, x2, [x2, #184]
    6944:	f9016864 	str	x4, [x3, #720]
    6948:	f9016c62 	str	x2, [x3, #728]
    694c:	97ffefc5 	bl	2860 <swapcontext@plt>
    6950:	97ffff58 	bl	66b0 <fwp_free_zombie>
    6954:	d503201f 	nop
    6958:	9100c260 	add	x0, x19, #0x30
    695c:	b942e000 	ldr	w0, [x0, #736]
    6960:	340001a0 	cbz	w0, 6994 <fwp_block+0x104>
    6964:	a94153f3 	ldp	x19, x20, [sp, #16]
    6968:	a8c27bfd 	ldp	x29, x30, [sp], #32
    696c:	d65f03c0 	ret
    6970:	97fff76c 	bl	4720 <fwp_poll_events>
    6974:	f9401a82 	ldr	x2, [x20, #48]
    6978:	b4ffffc2 	cbz	x2, 6970 <fwp_block+0xe0>
    697c:	9100c261 	add	x1, x19, #0x30
    6980:	f9408040 	ldr	x0, [x2, #256]
    6984:	f9001820 	str	x0, [x1, #48]
    6988:	b5fff9c0 	cbnz	x0, 68c0 <fwp_block+0x30>
    698c:	f900143f 	str	xzr, [x1, #40]
    6990:	17ffffcc 	b	68c0 <fwp_block+0x30>
    6994:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    6998:	913d2000 	add	x0, x0, #0xf48
    699c:	97ffeffd 	bl	2990 <getenv@plt>
    69a0:	5284e202 	mov	w2, #0x2710                	// #10000
    69a4:	b4000060 	cbz	x0, 69b0 <fwp_block+0x120>
    69a8:	39400001 	ldrb	w1, [x0]
    69ac:	350000c1 	cbnz	w1, 69c4 <fwp_block+0x134>
    69b0:	9100c273 	add	x19, x19, #0x30
    69b4:	b902e262 	str	w2, [x19, #736]
    69b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    69bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69c0:	d65f03c0 	ret
    69c4:	52800142 	mov	w2, #0xa                   	// #10
    69c8:	d2800001 	mov	x1, #0x0                   	// #0
    69cc:	97ffef41 	bl	26d0 <strtoll@plt>
    69d0:	d1000403 	sub	x3, x0, #0x1
    69d4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    69d8:	eb02007f 	cmp	x3, x2
    69dc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    69e0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    69e4:	17fffff3 	b	69b0 <fwp_block+0x120>
    69e8:	d503201f 	nop
    69ec:	d503201f 	nop

00000000000069f0 <fwp_drop10>:
    69f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69f4:	910003fd 	mov	x29, sp
    69f8:	a90153f3 	stp	x19, x20, [sp, #16]
    69fc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    6a00:	f90013f5 	str	x21, [sp, #32]
    6a04:	9114c275 	add	x21, x19, #0x530
    6a08:	f949daa1 	ldr	x1, [x21, #5040]
    6a0c:	f949eea2 	ldr	x2, [x21, #5080]
    6a10:	cb010001 	sub	x1, x0, x1
    6a14:	eb02403f 	cmp	x1, x2, lsl #16
    6a18:	54000382 	b.cs	6a88 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a1c:	d350fc22 	lsr	x2, x1, #16
    6a20:	f949fea3 	ldr	x3, [x21, #5112]
    6a24:	8b020842 	add	x2, x2, x2, lsl #2
    6a28:	d37df042 	lsl	x2, x2, #3
    6a2c:	8b020064 	add	x4, x3, x2
    6a30:	f9401094 	ldr	x20, [x4, #32]
    6a34:	b40002b4 	cbz	x20, 6a88 <fwp_drop10+0x98>
    6a38:	38626862 	ldrb	w2, [x3, x2]
    6a3c:	7100085f 	cmp	w2, #0x2
    6a40:	540007a0 	b.eq	6b34 <fwp_drop10+0x144>  // b.none
    6a44:	7100045f 	cmp	w2, #0x1
    6a48:	54000201 	b.ne	6a88 <fwp_drop10+0x98>  // b.any
    6a4c:	29430885 	ldp	w5, w2, [x4, #24]
    6a50:	92403c21 	and	x1, x1, #0xffff
    6a54:	9b057c21 	mul	x1, x1, x5
    6a58:	d360fc21 	lsr	x1, x1, #32
    6a5c:	eb02003f 	cmp	x1, x2
    6a60:	54000142 	b.cs	6a88 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a64:	8b010294 	add	x20, x20, x1
    6a68:	39400281 	ldrb	w1, [x20]
    6a6c:	340000e1 	cbz	w1, 6a88 <fwp_drop10+0x98>
    6a70:	7100043f 	cmp	w1, #0x1
    6a74:	54000120 	b.eq	6a98 <fwp_drop10+0xa8>  // b.none
    6a78:	7103fc3f 	cmp	w1, #0xff
    6a7c:	540007c0 	b.eq	6b74 <fwp_drop10+0x184>  // b.none
    6a80:	51000421 	sub	w1, w1, #0x1
    6a84:	39000281 	strb	w1, [x20]
    6a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a8c:	f94013f5 	ldr	x21, [sp, #32]
    6a90:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a94:	d65f03c0 	ret
    6a98:	f9400001 	ldr	x1, [x0]
    6a9c:	b7f80581 	tbnz	x1, #63, 6b4c <fwp_drop10+0x15c>
    6aa0:	9114c273 	add	x19, x19, #0x530
    6aa4:	f949da61 	ldr	x1, [x19, #5040]
    6aa8:	f949ee62 	ldr	x2, [x19, #5080]
    6aac:	cb010001 	sub	x1, x0, x1
    6ab0:	eb02403f 	cmp	x1, x2, lsl #16
    6ab4:	54fffea2 	b.cs	6a88 <fwp_drop10+0x98>  // b.hs, b.nlast
    6ab8:	d350fc22 	lsr	x2, x1, #16
    6abc:	8b020842 	add	x2, x2, x2, lsl #2
    6ac0:	d37df042 	lsl	x2, x2, #3
    6ac4:	8b020065 	add	x5, x3, x2
    6ac8:	f94010a4 	ldr	x4, [x5, #32]
    6acc:	b4fffde4 	cbz	x4, 6a88 <fwp_drop10+0x98>
    6ad0:	38626862 	ldrb	w2, [x3, x2]
    6ad4:	7100085f 	cmp	w2, #0x2
    6ad8:	54000220 	b.eq	6b1c <fwp_drop10+0x12c>  // b.none
    6adc:	7100045f 	cmp	w2, #0x1
    6ae0:	54fffd41 	b.ne	6a88 <fwp_drop10+0x98>  // b.any
    6ae4:	294308a3 	ldp	w3, w2, [x5, #24]
    6ae8:	92403c21 	and	x1, x1, #0xffff
    6aec:	9b037c21 	mul	x1, x1, x3
    6af0:	d360fc21 	lsr	x1, x1, #32
    6af4:	eb02003f 	cmp	x1, x2
    6af8:	54fffc82 	b.cs	6a88 <fwp_drop10+0x98>  // b.hs, b.nlast
    6afc:	8b010084 	add	x4, x4, x1
    6b00:	39400081 	ldrb	w1, [x4]
    6b04:	7100043f 	cmp	w1, #0x1
    6b08:	54fffc01 	b.ne	6a88 <fwp_drop10+0x98>  // b.any
    6b0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b10:	f94013f5 	ldr	x21, [sp, #32]
    6b14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b18:	17fff576 	b	40f0 <fwp_mem_free>
    6b1c:	72003c3f 	tst	w1, #0xffff
    6b20:	54ffff00 	b.eq	6b00 <fwp_drop10+0x110>  // b.none
    6b24:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b28:	f94013f5 	ldr	x21, [sp, #32]
    6b2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b30:	d65f03c0 	ret
    6b34:	72003c3f 	tst	w1, #0xffff
    6b38:	54fff980 	b.eq	6a68 <fwp_drop10+0x78>  // b.none
    6b3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b40:	f94013f5 	ldr	x21, [sp, #32]
    6b44:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b48:	d65f03c0 	ret
    6b4c:	f9400414 	ldr	x20, [x0, #8]
    6b50:	97fffb2c 	bl	5800 <fwp_rc_free_arr>
    6b54:	9114c260 	add	x0, x19, #0x530
    6b58:	f949d801 	ldr	x1, [x0, #5040]
    6b5c:	f949ec00 	ldr	x0, [x0, #5080]
    6b60:	cb010281 	sub	x1, x20, x1
    6b64:	eb00403f 	cmp	x1, x0, lsl #16
    6b68:	54fff902 	b.cs	6a88 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b6c:	aa1403e0 	mov	x0, x20
    6b70:	17ffffab 	b	6a1c <fwp_drop10+0x2c>
    6b74:	ca544680 	eor	x0, x20, x20, lsr #17
    6b78:	9114c273 	add	x19, x19, #0x530
    6b7c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b80:	92401c00 	and	x0, x0, #0xff
    6b84:	910a2402 	add	x2, x0, #0x289
    6b88:	8b000e60 	add	x0, x19, x0, lsl #3
    6b8c:	8b020e62 	add	x2, x19, x2, lsl #3
    6b90:	f94a2400 	ldr	x0, [x0, #5192]
    6b94:	b50000a0 	cbnz	x0, 6ba8 <fwp_drop10+0x1b8>
    6b98:	14000013 	b	6be4 <fwp_drop10+0x1f4>
    6b9c:	91004002 	add	x2, x0, #0x10
    6ba0:	f9400800 	ldr	x0, [x0, #16]
    6ba4:	b4000200 	cbz	x0, 6be4 <fwp_drop10+0x1f4>
    6ba8:	f9400001 	ldr	x1, [x0]
    6bac:	eb14003f 	cmp	x1, x20
    6bb0:	54ffff61 	b.ne	6b9c <fwp_drop10+0x1ac>  // b.any
    6bb4:	f9400041 	ldr	x1, [x2]
    6bb8:	f9400420 	ldr	x0, [x1, #8]
    6bbc:	d1000400 	sub	x0, x0, #0x1
    6bc0:	f9000420 	str	x0, [x1, #8]
    6bc4:	f103f81f 	cmp	x0, #0xfe
    6bc8:	54fff601 	b.ne	6a88 <fwp_drop10+0x98>  // b.any
    6bcc:	39400280 	ldrb	w0, [x20]
    6bd0:	7103fc1f 	cmp	w0, #0xff
    6bd4:	540000e0 	b.eq	6bf0 <fwp_drop10+0x200>  // b.none
    6bd8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6bdc:	39000280 	strb	w0, [x20]
    6be0:	17ffffaa 	b	6a88 <fwp_drop10+0x98>
    6be4:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    6be8:	9132c000 	add	x0, x0, #0xcb0
    6bec:	97fff485 	bl	3e00 <fwp_trap>
    6bf0:	aa1403e0 	mov	x0, x20
    6bf4:	97fff4a3 	bl	3e80 <fwp_rc_forget_slot.part.0>
    6bf8:	17fffff8 	b	6bd8 <fwp_drop10+0x1e8>
    6bfc:	d503201f 	nop

0000000000006c00 <fwp_caps173>:
    6c00:	34000041 	cbz	w1, 6c08 <fwp_caps173+0x8>
    6c04:	d65f03c0 	ret
    6c08:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    6c0c:	9114c063 	add	x3, x3, #0x530
    6c10:	f949d861 	ldr	x1, [x3, #5040]
    6c14:	f949ec62 	ldr	x2, [x3, #5080]
    6c18:	cb010001 	sub	x1, x0, x1
    6c1c:	eb02403f 	cmp	x1, x2, lsl #16
    6c20:	54ffff22 	b.cs	6c04 <fwp_caps173+0x4>  // b.hs, b.nlast
    6c24:	d350fc22 	lsr	x2, x1, #16
    6c28:	f949fc65 	ldr	x5, [x3, #5112]
    6c2c:	8b020842 	add	x2, x2, x2, lsl #2
    6c30:	d37df042 	lsl	x2, x2, #3
    6c34:	8b0200a4 	add	x4, x5, x2
    6c38:	f9401083 	ldr	x3, [x4, #32]
    6c3c:	b4fffe43 	cbz	x3, 6c04 <fwp_caps173+0x4>
    6c40:	386268a2 	ldrb	w2, [x5, x2]
    6c44:	7100085f 	cmp	w2, #0x2
    6c48:	540001c0 	b.eq	6c80 <fwp_caps173+0x80>  // b.none
    6c4c:	7100045f 	cmp	w2, #0x1
    6c50:	54fffda1 	b.ne	6c04 <fwp_caps173+0x4>  // b.any
    6c54:	29430885 	ldp	w5, w2, [x4, #24]
    6c58:	92403c21 	and	x1, x1, #0xffff
    6c5c:	9b057c21 	mul	x1, x1, x5
    6c60:	d360fc21 	lsr	x1, x1, #32
    6c64:	eb02003f 	cmp	x1, x2
    6c68:	54fffce2 	b.cs	6c04 <fwp_caps173+0x4>  // b.hs, b.nlast
    6c6c:	8b010063 	add	x3, x3, x1
    6c70:	39400061 	ldrb	w1, [x3]
    6c74:	7100043f 	cmp	w1, #0x1
    6c78:	54fffc61 	b.ne	6c04 <fwp_caps173+0x4>  // b.any
    6c7c:	17fff51d 	b	40f0 <fwp_mem_free>
    6c80:	72003c3f 	tst	w1, #0xffff
    6c84:	54ffff60 	b.eq	6c70 <fwp_caps173+0x70>  // b.none
    6c88:	d65f03c0 	ret
    6c8c:	d503201f 	nop

0000000000006c90 <f37>:
    6c90:	d10243ff 	sub	sp, sp, #0x90
    6c94:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc88>
    6c98:	f947f421 	ldr	x1, [x1, #4072]
    6c9c:	a9037bfd 	stp	x29, x30, [sp, #48]
    6ca0:	9100c3fd 	add	x29, sp, #0x30
    6ca4:	a9055bf5 	stp	x21, x22, [sp, #80]
    6ca8:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    6cac:	9114c2c3 	add	x3, x22, #0x530
    6cb0:	a90453f3 	stp	x19, x20, [sp, #64]
    6cb4:	aa0003f5 	mov	x21, x0
    6cb8:	a90663f7 	stp	x23, x24, [sp, #96]
    6cbc:	a90873fb 	stp	x27, x28, [sp, #128]
    6cc0:	f949ec62 	ldr	x2, [x3, #5080]
    6cc4:	f9400024 	ldr	x4, [x1]
    6cc8:	f90017e4 	str	x4, [sp, #40]
    6ccc:	d2800004 	mov	x4, #0x0                   	// #0
    6cd0:	f949d861 	ldr	x1, [x3, #5040]
    6cd4:	d370bc42 	lsl	x2, x2, #16
    6cd8:	b4001720 	cbz	x0, 6fbc <f37+0x32c>
    6cdc:	f9400817 	ldr	x23, [x0, #16]
    6ce0:	cb0102e1 	sub	x1, x23, x1
    6ce4:	eb02003f 	cmp	x1, x2
    6ce8:	54000362 	b.cs	6d54 <f37+0xc4>  // b.hs, b.nlast
    6cec:	f949fc60 	ldr	x0, [x3, #5112]
    6cf0:	d350fc22 	lsr	x2, x1, #16
    6cf4:	8b020842 	add	x2, x2, x2, lsl #2
    6cf8:	8b020c02 	add	x2, x0, x2, lsl #3
    6cfc:	f9401040 	ldr	x0, [x2, #32]
    6d00:	b40002a0 	cbz	x0, 6d54 <f37+0xc4>
    6d04:	39400043 	ldrb	w3, [x2]
    6d08:	7100087f 	cmp	w3, #0x2
    6d0c:	54001460 	b.eq	6f98 <f37+0x308>  // b.none
    6d10:	7100047f 	cmp	w3, #0x1
    6d14:	540001c1 	b.ne	6d4c <f37+0xbc>  // b.any
    6d18:	29430843 	ldp	w3, w2, [x2, #24]
    6d1c:	92403c21 	and	x1, x1, #0xffff
    6d20:	9b037c21 	mul	x1, x1, x3
    6d24:	d360fc21 	lsr	x1, x1, #32
    6d28:	eb02003f 	cmp	x1, x2
    6d2c:	54000102 	b.cs	6d4c <f37+0xbc>  // b.hs, b.nlast
    6d30:	8b010000 	add	x0, x0, x1
    6d34:	39400001 	ldrb	w1, [x0]
    6d38:	340000a1 	cbz	w1, 6d4c <f37+0xbc>
    6d3c:	7103f43f 	cmp	w1, #0xfd
    6d40:	54001728 	b.hi	7024 <f37+0x394>  // b.pmore
    6d44:	11000421 	add	w1, w1, #0x1
    6d48:	39000001 	strb	w1, [x0]
    6d4c:	d2800002 	mov	x2, #0x0                   	// #0
    6d50:	b40000f5 	cbz	x21, 6d6c <f37+0xdc>
    6d54:	aa1503e1 	mov	x1, x21
    6d58:	d2800002 	mov	x2, #0x0                   	// #0
    6d5c:	d503201f 	nop
    6d60:	f9400821 	ldr	x1, [x1, #16]
    6d64:	91000442 	add	x2, x2, #0x1
    6d68:	b5ffffc1 	cbnz	x1, 6d60 <f37+0xd0>
    6d6c:	b40012f7 	cbz	x23, 6fc8 <f37+0x338>
    6d70:	aa1703e1 	mov	x1, x23
    6d74:	d2800003 	mov	x3, #0x0                   	// #0
    6d78:	f9400821 	ldr	x1, [x1, #16]
    6d7c:	91000463 	add	x3, x3, #0x1
    6d80:	b5ffffc1 	cbnz	x1, 6d78 <f37+0xe8>
    6d84:	eb02007f 	cmp	x3, x2
    6d88:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    6d8c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    6d90:	eb00027f 	cmp	x19, x0
    6d94:	54000fa8 	b.hi	6f88 <f37+0x2f8>  // b.pmore
    6d98:	d37ffa74 	lsl	x20, x19, #1
    6d9c:	52800041 	mov	w1, #0x2                   	// #2
    6da0:	91000680 	add	x0, x20, #0x1
    6da4:	d37df000 	lsl	x0, x0, #3
    6da8:	97fff78e 	bl	4be0 <fwp_heap_alloc>
    6dac:	9114c2c1 	add	x1, x22, #0x530
    6db0:	aa0003fb 	mov	x27, x0
    6db4:	f9000014 	str	x20, [x0]
    6db8:	aa0103e0 	mov	x0, x1
    6dbc:	f949d821 	ldr	x1, [x1, #5040]
    6dc0:	f949ec00 	ldr	x0, [x0, #5080]
    6dc4:	cb010361 	sub	x1, x27, x1
    6dc8:	eb00403f 	cmp	x1, x0, lsl #16
    6dcc:	54000342 	b.cs	6e34 <f37+0x1a4>  // b.hs, b.nlast
    6dd0:	9114c2c2 	add	x2, x22, #0x530
    6dd4:	d350fc20 	lsr	x0, x1, #16
    6dd8:	8b000800 	add	x0, x0, x0, lsl #2
    6ddc:	f949fc43 	ldr	x3, [x2, #5112]
    6de0:	d37df002 	lsl	x2, x0, #3
    6de4:	8b020060 	add	x0, x3, x2
    6de8:	f9401014 	ldr	x20, [x0, #32]
    6dec:	b4000254 	cbz	x20, 6e34 <f37+0x1a4>
    6df0:	38626862 	ldrb	w2, [x3, x2]
    6df4:	7100085f 	cmp	w2, #0x2
    6df8:	54000dc0 	b.eq	6fb0 <f37+0x320>  // b.none
    6dfc:	7100045f 	cmp	w2, #0x1
    6e00:	540001a1 	b.ne	6e34 <f37+0x1a4>  // b.any
    6e04:	29430002 	ldp	w2, w0, [x0, #24]
    6e08:	92403c21 	and	x1, x1, #0xffff
    6e0c:	9b027c21 	mul	x1, x1, x2
    6e10:	d360fc21 	lsr	x1, x1, #32
    6e14:	eb00003f 	cmp	x1, x0
    6e18:	540000e2 	b.cs	6e34 <f37+0x1a4>  // b.hs, b.nlast
    6e1c:	8b010294 	add	x20, x20, x1
    6e20:	39400280 	ldrb	w0, [x20]
    6e24:	7103fc1f 	cmp	w0, #0xff
    6e28:	54001020 	b.eq	702c <f37+0x39c>  // b.none
    6e2c:	52800020 	mov	w0, #0x1                   	// #1
    6e30:	39000280 	strb	w0, [x20]
    6e34:	b4000333 	cbz	x19, 6e98 <f37+0x208>
    6e38:	8b131373 	add	x19, x27, x19, lsl #4
    6e3c:	aa1b03f4 	mov	x20, x27
    6e40:	aa1703f8 	mov	x24, x23
    6e44:	910023fc 	add	x28, sp, #0x8
    6e48:	a9076bf9 	stp	x25, x26, [sp, #112]
    6e4c:	aa1503f9 	mov	x25, x21
    6e50:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    6e54:	d503201f 	nop
    6e58:	f9400704 	ldr	x4, [x24, #8]
    6e5c:	aa1c03e2 	mov	x2, x28
    6e60:	f9400723 	ldr	x3, [x25, #8]
    6e64:	a900fffa 	stp	x26, xzr, [sp, #8]
    6e68:	fd400481 	ldr	d1, [x4, #8]
    6e6c:	f9400881 	ldr	x1, [x4, #16]
    6e70:	f9400860 	ldr	x0, [x3, #16]
    6e74:	fd400460 	ldr	d0, [x3, #8]
    6e78:	97fff8ba 	bl	5160 <w120>
    6e7c:	f9000680 	str	x0, [x20, #8]
    6e80:	f8010e81 	str	x1, [x20, #16]!
    6e84:	f9400b18 	ldr	x24, [x24, #16]
    6e88:	f9400b39 	ldr	x25, [x25, #16]
    6e8c:	eb14027f 	cmp	x19, x20
    6e90:	54fffe41 	b.ne	6e58 <f37+0x1c8>  // b.any
    6e94:	a9476bf9 	ldp	x25, x26, [sp, #112]
    6e98:	aa1703e0 	mov	x0, x23
    6e9c:	97fffd1a 	bl	6304 <fwp_drop4>
    6ea0:	9114c2d6 	add	x22, x22, #0x530
    6ea4:	aa1503e0 	mov	x0, x21
    6ea8:	97fffd17 	bl	6304 <fwp_drop4>
    6eac:	aa1b03e0 	mov	x0, x27
    6eb0:	97fff9fc 	bl	56a0 <w176.constprop.0>
    6eb4:	aa0103f3 	mov	x19, x1
    6eb8:	aa0003f4 	mov	x20, x0
    6ebc:	aa1b03e0 	mov	x0, x27
    6ec0:	97fffecc 	bl	69f0 <fwp_drop10>
    6ec4:	910063e1 	add	x1, sp, #0x18
    6ec8:	52800000 	mov	w0, #0x0                   	// #0
    6ecc:	a901cff4 	stp	x20, x19, [sp, #24]
    6ed0:	97fff789 	bl	4cf4 <fwp_data.part.0.constprop.0>
    6ed4:	aa0003f3 	mov	x19, x0
    6ed8:	f949dac1 	ldr	x1, [x22, #5040]
    6edc:	f949eec0 	ldr	x0, [x22, #5080]
    6ee0:	cb010261 	sub	x1, x19, x1
    6ee4:	eb00403f 	cmp	x1, x0, lsl #16
    6ee8:	54000322 	b.cs	6f4c <f37+0x2bc>  // b.hs, b.nlast
    6eec:	d350fc22 	lsr	x2, x1, #16
    6ef0:	f949fec3 	ldr	x3, [x22, #5112]
    6ef4:	8b020842 	add	x2, x2, x2, lsl #2
    6ef8:	d37df042 	lsl	x2, x2, #3
    6efc:	8b020060 	add	x0, x3, x2
    6f00:	f9401014 	ldr	x20, [x0, #32]
    6f04:	b4000254 	cbz	x20, 6f4c <f37+0x2bc>
    6f08:	38626862 	ldrb	w2, [x3, x2]
    6f0c:	7100085f 	cmp	w2, #0x2
    6f10:	540004a0 	b.eq	6fa4 <f37+0x314>  // b.none
    6f14:	7100045f 	cmp	w2, #0x1
    6f18:	540001a1 	b.ne	6f4c <f37+0x2bc>  // b.any
    6f1c:	29430002 	ldp	w2, w0, [x0, #24]
    6f20:	92403c21 	and	x1, x1, #0xffff
    6f24:	9b027c21 	mul	x1, x1, x2
    6f28:	d360fc21 	lsr	x1, x1, #32
    6f2c:	eb00003f 	cmp	x1, x0
    6f30:	540000e2 	b.cs	6f4c <f37+0x2bc>  // b.hs, b.nlast
    6f34:	8b010294 	add	x20, x20, x1
    6f38:	39400280 	ldrb	w0, [x20]
    6f3c:	7103fc1f 	cmp	w0, #0xff
    6f40:	540007c0 	b.eq	7038 <f37+0x3a8>  // b.none
    6f44:	52800020 	mov	w0, #0x1                   	// #1
    6f48:	39000280 	strb	w0, [x20]
    6f4c:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    6f50:	f947f400 	ldr	x0, [x0, #4072]
    6f54:	f94017e2 	ldr	x2, [sp, #40]
    6f58:	f9400001 	ldr	x1, [x0]
    6f5c:	eb010042 	subs	x2, x2, x1
    6f60:	d2800001 	mov	x1, #0x0                   	// #0
    6f64:	54000701 	b.ne	7044 <f37+0x3b4>  // b.any
    6f68:	a9437bfd 	ldp	x29, x30, [sp, #48]
    6f6c:	aa1303e0 	mov	x0, x19
    6f70:	a94453f3 	ldp	x19, x20, [sp, #64]
    6f74:	a9455bf5 	ldp	x21, x22, [sp, #80]
    6f78:	a94663f7 	ldp	x23, x24, [sp, #96]
    6f7c:	a94873fb 	ldp	x27, x28, [sp, #128]
    6f80:	910243ff 	add	sp, sp, #0x90
    6f84:	d65f03c0 	ret
    6f88:	90000020 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    6f8c:	913d6000 	add	x0, x0, #0xf58
    6f90:	a9076bf9 	stp	x25, x26, [sp, #112]
    6f94:	97fff39b 	bl	3e00 <fwp_trap>
    6f98:	72003c3f 	tst	w1, #0xffff
    6f9c:	54ffed81 	b.ne	6d4c <f37+0xbc>  // b.any
    6fa0:	17ffff65 	b	6d34 <f37+0xa4>
    6fa4:	72003c3f 	tst	w1, #0xffff
    6fa8:	54fffd21 	b.ne	6f4c <f37+0x2bc>  // b.any
    6fac:	17ffffe3 	b	6f38 <f37+0x2a8>
    6fb0:	72003c3f 	tst	w1, #0xffff
    6fb4:	54fff401 	b.ne	6e34 <f37+0x1a4>  // b.any
    6fb8:	17ffff9a 	b	6e20 <f37+0x190>
    6fbc:	cb0103e1 	neg	x1, x1
    6fc0:	eb02003f 	cmp	x1, x2
    6fc4:	54000203 	b.cc	7004 <f37+0x374>  // b.lo, b.ul, b.last
    6fc8:	52800041 	mov	w1, #0x2                   	// #2
    6fcc:	d2800100 	mov	x0, #0x8                   	// #8
    6fd0:	97fff704 	bl	4be0 <fwp_heap_alloc>
    6fd4:	aa0003e1 	mov	x1, x0
    6fd8:	9114c2c0 	add	x0, x22, #0x530
    6fdc:	aa0103fb 	mov	x27, x1
    6fe0:	d2800017 	mov	x23, #0x0                   	// #0
    6fe4:	f900003f 	str	xzr, [x1]
    6fe8:	f949d801 	ldr	x1, [x0, #5040]
    6fec:	f949ec00 	ldr	x0, [x0, #5080]
    6ff0:	cb010361 	sub	x1, x27, x1
    6ff4:	eb00403f 	cmp	x1, x0, lsl #16
    6ff8:	54fff502 	b.cs	6e98 <f37+0x208>  // b.hs, b.nlast
    6ffc:	d2800013 	mov	x19, #0x0                   	// #0
    7000:	17ffff74 	b	6dd0 <f37+0x140>
    7004:	f949fc62 	ldr	x2, [x3, #5112]
    7008:	d350fc20 	lsr	x0, x1, #16
    700c:	8b000800 	add	x0, x0, x0, lsl #2
    7010:	8b000c42 	add	x2, x2, x0, lsl #3
    7014:	f9401040 	ldr	x0, [x2, #32]
    7018:	b4fffd80 	cbz	x0, 6fc8 <f37+0x338>
    701c:	d2800017 	mov	x23, #0x0                   	// #0
    7020:	17ffff39 	b	6d04 <f37+0x74>
    7024:	97fff4ac 	bl	42d4 <fwp_rc_wide_dup>
    7028:	17ffff49 	b	6d4c <f37+0xbc>
    702c:	aa1403e0 	mov	x0, x20
    7030:	97fff394 	bl	3e80 <fwp_rc_forget_slot.part.0>
    7034:	17ffff7e 	b	6e2c <f37+0x19c>
    7038:	aa1403e0 	mov	x0, x20
    703c:	97fff391 	bl	3e80 <fwp_rc_forget_slot.part.0>
    7040:	17ffffc1 	b	6f44 <f37+0x2b4>
    7044:	a9076bf9 	stp	x25, x26, [sp, #112]
    7048:	97ffedee 	bl	2800 <__stack_chk_fail@plt>
    704c:	d503201f 	nop

0000000000007050 <fwp_owned_entry37>:
    7050:	f9400000 	ldr	x0, [x0]
    7054:	17ffff0f 	b	6c90 <f37>
    7058:	d503201f 	nop
    705c:	d503201f 	nop

0000000000007060 <e37>:
    7060:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7064:	910003fd 	mov	x29, sp
    7068:	f9000bf3 	str	x19, [sp, #16]
    706c:	f9400013 	ldr	x19, [x0]
    7070:	aa1303e0 	mov	x0, x19
    7074:	97fff9bf 	bl	5770 <fwp_rc_share>
    7078:	aa1303e0 	mov	x0, x19
    707c:	97ffff05 	bl	6c90 <f37>
    7080:	aa0003f3 	mov	x19, x0
    7084:	97fff9bb 	bl	5770 <fwp_rc_share>
    7088:	aa1303e0 	mov	x0, x19
    708c:	f9400bf3 	ldr	x19, [sp, #16]
    7090:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7094:	d65f03c0 	ret
    7098:	d503201f 	nop
    709c:	d503201f 	nop

00000000000070a0 <fwp_args37>:
    70a0:	7100003f 	cmp	w1, #0x0
    70a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    70a8:	54000041 	b.ne	70b0 <fwp_args37+0x10>  // b.any
    70ac:	d65f03c0 	ret
    70b0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    70b4:	9114c042 	add	x2, x2, #0x530
    70b8:	f9400001 	ldr	x1, [x0]
    70bc:	f949d843 	ldr	x3, [x2, #5040]
    70c0:	f949ec40 	ldr	x0, [x2, #5080]
    70c4:	cb030021 	sub	x1, x1, x3
    70c8:	eb00403f 	cmp	x1, x0, lsl #16
    70cc:	54ffff02 	b.cs	70ac <fwp_args37+0xc>  // b.hs, b.nlast
    70d0:	d350fc20 	lsr	x0, x1, #16
    70d4:	f949fc44 	ldr	x4, [x2, #5112]
    70d8:	8b000800 	add	x0, x0, x0, lsl #2
    70dc:	d37df002 	lsl	x2, x0, #3
    70e0:	8b020083 	add	x3, x4, x2
    70e4:	f9401060 	ldr	x0, [x3, #32]
    70e8:	b4fffe20 	cbz	x0, 70ac <fwp_args37+0xc>
    70ec:	38626882 	ldrb	w2, [x4, x2]
    70f0:	7100085f 	cmp	w2, #0x2
    70f4:	54000220 	b.eq	7138 <fwp_args37+0x98>  // b.none
    70f8:	7100045f 	cmp	w2, #0x1
    70fc:	54fffd81 	b.ne	70ac <fwp_args37+0xc>  // b.any
    7100:	29430864 	ldp	w4, w2, [x3, #24]
    7104:	92403c21 	and	x1, x1, #0xffff
    7108:	9b047c21 	mul	x1, x1, x4
    710c:	d360fc21 	lsr	x1, x1, #32
    7110:	eb02003f 	cmp	x1, x2
    7114:	54fffcc2 	b.cs	70ac <fwp_args37+0xc>  // b.hs, b.nlast
    7118:	8b010000 	add	x0, x0, x1
    711c:	39400001 	ldrb	w1, [x0]
    7120:	34fffc61 	cbz	w1, 70ac <fwp_args37+0xc>
    7124:	7103f43f 	cmp	w1, #0xfd
    7128:	540000e8 	b.hi	7144 <fwp_args37+0xa4>  // b.pmore
    712c:	11000421 	add	w1, w1, #0x1
    7130:	39000001 	strb	w1, [x0]
    7134:	d65f03c0 	ret
    7138:	72003c3f 	tst	w1, #0xffff
    713c:	54ffff00 	b.eq	711c <fwp_args37+0x7c>  // b.none
    7140:	d65f03c0 	ret
    7144:	17fff464 	b	42d4 <fwp_rc_wide_dup>
    7148:	d503201f 	nop
    714c:	d503201f 	nop

0000000000007150 <fwp_caps37>:
    7150:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7154:	910003fd 	mov	x29, sp
    7158:	f9000bf3 	str	x19, [sp, #16]
    715c:	aa0003f3 	mov	x19, x0
    7160:	b9400400 	ldr	w0, [x0, #4]
    7164:	340004a0 	cbz	w0, 71f8 <fwp_caps37+0xa8>
    7168:	f9400660 	ldr	x0, [x19, #8]
    716c:	350004e1 	cbnz	w1, 7208 <fwp_caps37+0xb8>
    7170:	97fffc65 	bl	6304 <fwp_drop4>
    7174:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    7178:	9114c042 	add	x2, x2, #0x530
    717c:	f949d840 	ldr	x0, [x2, #5040]
    7180:	f949ec41 	ldr	x1, [x2, #5080]
    7184:	cb000260 	sub	x0, x19, x0
    7188:	eb01401f 	cmp	x0, x1, lsl #16
    718c:	54000382 	b.cs	71fc <fwp_caps37+0xac>  // b.hs, b.nlast
    7190:	d350fc01 	lsr	x1, x0, #16
    7194:	f949fc44 	ldr	x4, [x2, #5112]
    7198:	8b010821 	add	x1, x1, x1, lsl #2
    719c:	d37df021 	lsl	x1, x1, #3
    71a0:	8b010083 	add	x3, x4, x1
    71a4:	f9401062 	ldr	x2, [x3, #32]
    71a8:	b40002a2 	cbz	x2, 71fc <fwp_caps37+0xac>
    71ac:	38616881 	ldrb	w1, [x4, x1]
    71b0:	7100083f 	cmp	w1, #0x2
    71b4:	540006c0 	b.eq	728c <fwp_caps37+0x13c>  // b.none
    71b8:	7100043f 	cmp	w1, #0x1
    71bc:	54000201 	b.ne	71fc <fwp_caps37+0xac>  // b.any
    71c0:	29430464 	ldp	w4, w1, [x3, #24]
    71c4:	92403c00 	and	x0, x0, #0xffff
    71c8:	9b047c00 	mul	x0, x0, x4
    71cc:	d360fc00 	lsr	x0, x0, #32
    71d0:	eb01001f 	cmp	x0, x1
    71d4:	54000142 	b.cs	71fc <fwp_caps37+0xac>  // b.hs, b.nlast
    71d8:	8b000042 	add	x2, x2, x0
    71dc:	39400040 	ldrb	w0, [x2]
    71e0:	7100041f 	cmp	w0, #0x1
    71e4:	540000c1 	b.ne	71fc <fwp_caps37+0xac>  // b.any
    71e8:	aa1303e0 	mov	x0, x19
    71ec:	f9400bf3 	ldr	x19, [sp, #16]
    71f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71f4:	17fff3bf 	b	40f0 <fwp_mem_free>
    71f8:	34fffbe1 	cbz	w1, 7174 <fwp_caps37+0x24>
    71fc:	f9400bf3 	ldr	x19, [sp, #16]
    7200:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7204:	d65f03c0 	ret
    7208:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    720c:	9114c042 	add	x2, x2, #0x530
    7210:	f949d843 	ldr	x3, [x2, #5040]
    7214:	f949ec41 	ldr	x1, [x2, #5080]
    7218:	cb030000 	sub	x0, x0, x3
    721c:	eb01401f 	cmp	x0, x1, lsl #16
    7220:	54fffee2 	b.cs	71fc <fwp_caps37+0xac>  // b.hs, b.nlast
    7224:	d350fc01 	lsr	x1, x0, #16
    7228:	f949fc44 	ldr	x4, [x2, #5112]
    722c:	8b010821 	add	x1, x1, x1, lsl #2
    7230:	d37df021 	lsl	x1, x1, #3
    7234:	8b010083 	add	x3, x4, x1
    7238:	f9401062 	ldr	x2, [x3, #32]
    723c:	b4fffe02 	cbz	x2, 71fc <fwp_caps37+0xac>
    7240:	38616881 	ldrb	w1, [x4, x1]
    7244:	7100083f 	cmp	w1, #0x2
    7248:	54000280 	b.eq	7298 <fwp_caps37+0x148>  // b.none
    724c:	7100043f 	cmp	w1, #0x1
    7250:	54fffd61 	b.ne	71fc <fwp_caps37+0xac>  // b.any
    7254:	92403c01 	and	x1, x0, #0xffff
    7258:	29430064 	ldp	w4, w0, [x3, #24]
    725c:	9b047c21 	mul	x1, x1, x4
    7260:	d360fc21 	lsr	x1, x1, #32
    7264:	eb00003f 	cmp	x1, x0
    7268:	54fffca2 	b.cs	71fc <fwp_caps37+0xac>  // b.hs, b.nlast
    726c:	8b010042 	add	x2, x2, x1
    7270:	39400040 	ldrb	w0, [x2]
    7274:	34fffc40 	cbz	w0, 71fc <fwp_caps37+0xac>
    7278:	7103f41f 	cmp	w0, #0xfd
    727c:	54000148 	b.hi	72a4 <fwp_caps37+0x154>  // b.pmore
    7280:	11000400 	add	w0, w0, #0x1
    7284:	39000040 	strb	w0, [x2]
    7288:	17ffffdd 	b	71fc <fwp_caps37+0xac>
    728c:	72003c1f 	tst	w0, #0xffff
    7290:	54fffb61 	b.ne	71fc <fwp_caps37+0xac>  // b.any
    7294:	17ffffd2 	b	71dc <fwp_caps37+0x8c>
    7298:	72003c1f 	tst	w0, #0xffff
    729c:	54fffb01 	b.ne	71fc <fwp_caps37+0xac>  // b.any
    72a0:	17fffff4 	b	7270 <fwp_caps37+0x120>
    72a4:	f9400bf3 	ldr	x19, [sp, #16]
    72a8:	aa0203e0 	mov	x0, x2
    72ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    72b0:	17fff409 	b	42d4 <fwp_rc_wide_dup>

00000000000072b4 <fwp_write>:
    72b4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    72b8:	910003fd 	mov	x29, sp
    72bc:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc88>
    72c0:	f947f484 	ldr	x4, [x4, #4072]
    72c4:	a90153f3 	stp	x19, x20, [sp, #16]
    72c8:	d10943ff 	sub	sp, sp, #0x250
    72cc:	b9400045 	ldr	w5, [x2]
    72d0:	aa0003f4 	mov	x20, x0
    72d4:	f9400080 	ldr	x0, [x4]
    72d8:	f90127e0 	str	x0, [sp, #584]
    72dc:	d2800000 	mov	x0, #0x0                   	// #0
    72e0:	710064bf 	cmp	w5, #0x19
    72e4:	54000408 	b.hi	7364 <fwp_write+0xb0>  // b.pmore
    72e8:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x490>
    72ec:	aa0103f3 	mov	x19, x1
    72f0:	911f0000 	add	x0, x0, #0x7c0
    72f4:	f9013bf5 	str	x21, [sp, #624]
    72f8:	f9013ff6 	str	x22, [sp, #632]
    72fc:	f90153fb 	str	x27, [sp, #672]
    7300:	f90157fc 	str	x28, [sp, #680]
    7304:	aa0203fc 	mov	x28, x2
    7308:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    730c:	10000061 	adr	x1, 7318 <fwp_write+0x64>
    7310:	8b20a820 	add	x0, x1, w0, sxth #2
    7314:	d61f0000 	br	x0
    7318:	910123e0 	add	x0, sp, #0x48
    731c:	aa1303e5 	mov	x5, x19
    7320:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x1d60>
    7324:	aa0003f3 	mov	x19, x0
    7328:	913e8084 	add	x4, x4, #0xfa0
    732c:	d2804003 	mov	x3, #0x200                 	// #512
    7330:	aa0303e1 	mov	x1, x3
    7334:	52800042 	mov	w2, #0x2                   	// #2
    7338:	97ffed0e 	bl	2770 <__snprintf_chk@plt>
    733c:	aa1303e0 	mov	x0, x19
    7340:	97ffecd4 	bl	2690 <strlen@plt>
    7344:	aa1303e1 	mov	x1, x19
    7348:	aa0003e2 	mov	x2, x0
    734c:	aa1403e0 	mov	x0, x20
    7350:	97fff010 	bl	3390 <buf_put>
    7354:	f9413bf5 	ldr	x21, [sp, #624]
    7358:	f9413ff6 	ldr	x22, [sp, #632]
    735c:	f94153fb 	ldr	x27, [sp, #672]
    7360:	f94157fc 	ldr	x28, [sp, #680]
    7364:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7368:	f947f400 	ldr	x0, [x0, #4072]
    736c:	f94127e2 	ldr	x2, [sp, #584]
    7370:	f9400001 	ldr	x1, [x0]
    7374:	eb010042 	subs	x2, x2, x1
    7378:	d2800001 	mov	x1, #0x0                   	// #0
    737c:	540077a1 	b.ne	8270 <fwp_write+0xfbc>  // b.any
    7380:	910943ff 	add	sp, sp, #0x250
    7384:	a94153f3 	ldp	x19, x20, [sp, #16]
    7388:	a8c77bfd 	ldp	x29, x30, [sp], #112
    738c:	d65f03c0 	ret
    7390:	910123e0 	add	x0, sp, #0x48
    7394:	aa1303e5 	mov	x5, x19
    7398:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x1d60>
    739c:	aa0003f3 	mov	x19, x0
    73a0:	913e6084 	add	x4, x4, #0xf98
    73a4:	d2804003 	mov	x3, #0x200                 	// #512
    73a8:	17ffffe2 	b	7330 <fwp_write+0x7c>
    73ac:	71004cbf 	cmp	w5, #0x13
    73b0:	f0000000 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    73b4:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    73b8:	913e2000 	add	x0, x0, #0xf88
    73bc:	913e4021 	add	x1, x1, #0xf90
    73c0:	d2800082 	mov	x2, #0x4                   	// #4
    73c4:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    73c8:	aa1403e0 	mov	x0, x20
    73cc:	f90143f7 	str	x23, [sp, #640]
    73d0:	d2800016 	mov	x22, #0x0                   	// #0
    73d4:	f90147f8 	str	x24, [sp, #648]
    73d8:	97ffefee 	bl	3390 <buf_put>
    73dc:	f9400260 	ldr	x0, [x19]
    73e0:	90000037 	adrp	x23, b000 <_IO_stdin_used+0x490>
    73e4:	d2800015 	mov	x21, #0x0                   	// #0
    73e8:	910042f7 	add	x23, x23, #0x10
    73ec:	b4004780 	cbz	x0, 7cdc <fwp_write+0xa28>
    73f0:	b9400380 	ldr	w0, [x28]
    73f4:	52800003 	mov	w3, #0x0                   	// #0
    73f8:	f9401f82 	ldr	x2, [x28, #56]
    73fc:	71004c1f 	cmp	w0, #0x13
    7400:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7404:	aa1403e0 	mov	x0, x20
    7408:	8b010e61 	add	x1, x19, x1, lsl #3
    740c:	f9400421 	ldr	x1, [x1, #8]
    7410:	97ffffa9 	bl	72b4 <fwp_write>
    7414:	b9400380 	ldr	w0, [x28]
    7418:	7100481f 	cmp	w0, #0x12
    741c:	54004b20 	b.eq	7d80 <fwp_write+0xacc>  // b.none
    7420:	f9400260 	ldr	x0, [x19]
    7424:	910006b5 	add	x21, x21, #0x1
    7428:	91000ad6 	add	x22, x22, #0x2
    742c:	eb15001f 	cmp	x0, x21
    7430:	54004569 	b.ls	7cdc <fwp_write+0xa28>  // b.plast
    7434:	aa1703e1 	mov	x1, x23
    7438:	aa1403e0 	mov	x0, x20
    743c:	d2800042 	mov	x2, #0x2                   	// #2
    7440:	97ffefd4 	bl	3390 <buf_put>
    7444:	17ffffeb 	b	73f0 <fwp_write+0x13c>
    7448:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    744c:	913f2021 	add	x1, x1, #0xfc8
    7450:	d28000c2 	mov	x2, #0x6                   	// #6
    7454:	aa1403e0 	mov	x0, x20
    7458:	91004273 	add	x19, x19, #0x10
    745c:	97ffefcd 	bl	3390 <buf_put>
    7460:	aa1303e0 	mov	x0, x19
    7464:	97ffec8b 	bl	2690 <strlen@plt>
    7468:	aa1303e1 	mov	x1, x19
    746c:	aa0003e2 	mov	x2, x0
    7470:	aa1403e0 	mov	x0, x20
    7474:	97ffefc7 	bl	3390 <buf_put>
    7478:	528007c3 	mov	w3, #0x3e                  	// #62
    747c:	aa1403e0 	mov	x0, x20
    7480:	91001fe1 	add	x1, sp, #0x7
    7484:	d2800022 	mov	x2, #0x1                   	// #1
    7488:	39001fe3 	strb	w3, [sp, #7]
    748c:	17ffffb1 	b	7350 <fwp_write+0x9c>
    7490:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7494:	f947f400 	ldr	x0, [x0, #4072]
    7498:	f94127e2 	ldr	x2, [sp, #584]
    749c:	f9400001 	ldr	x1, [x0]
    74a0:	eb010042 	subs	x2, x2, x1
    74a4:	d2800001 	mov	x1, #0x0                   	// #0
    74a8:	540034c1 	b.ne	7b40 <fwp_write+0x88c>  // b.any
    74ac:	f9413bf5 	ldr	x21, [sp, #624]
    74b0:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    74b4:	f9413ff6 	ldr	x22, [sp, #632]
    74b8:	aa1403e0 	mov	x0, x20
    74bc:	913ea021 	add	x1, x1, #0xfa8
    74c0:	d2800142 	mov	x2, #0xa                   	// #10
    74c4:	f94153fb 	ldr	x27, [sp, #672]
    74c8:	f94157fc 	ldr	x28, [sp, #680]
    74cc:	910943ff 	add	sp, sp, #0x250
    74d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    74d4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    74d8:	17ffefae 	b	3390 <buf_put>
    74dc:	f9400456 	ldr	x22, [x2, #8]
    74e0:	f90143f7 	str	x23, [sp, #640]
    74e4:	f90147f8 	str	x24, [sp, #648]
    74e8:	b4005af6 	cbz	x22, 8044 <fwp_write+0xd90>
    74ec:	aa1603e0 	mov	x0, x22
    74f0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x490>
    74f4:	9100a021 	add	x1, x1, #0x28
    74f8:	97ffece2 	bl	2880 <strcmp@plt>
    74fc:	2a0003f5 	mov	w21, w0
    7500:	34005fc0 	cbz	w0, 80f8 <fwp_write+0xe44>
    7504:	aa1603e0 	mov	x0, x22
    7508:	97ffec62 	bl	2690 <strlen@plt>
    750c:	aa1603e1 	mov	x1, x22
    7510:	aa0003e2 	mov	x2, x0
    7514:	aa1403e0 	mov	x0, x20
    7518:	97ffef9e 	bl	3390 <buf_put>
    751c:	52800403 	mov	w3, #0x20                  	// #32
    7520:	91001ff5 	add	x21, sp, #0x7
    7524:	aa1503e1 	mov	x1, x21
    7528:	aa1403e0 	mov	x0, x20
    752c:	d2800022 	mov	x2, #0x1                   	// #1
    7530:	39001fe3 	strb	w3, [sp, #7]
    7534:	97ffef97 	bl	3390 <buf_put>
    7538:	52800f63 	mov	w3, #0x7b                  	// #123
    753c:	aa1403e0 	mov	x0, x20
    7540:	aa1503e1 	mov	x1, x21
    7544:	d2800022 	mov	x2, #0x1                   	// #1
    7548:	39001fe3 	strb	w3, [sp, #7]
    754c:	97ffef91 	bl	3390 <buf_put>
    7550:	b9401380 	ldr	w0, [x28, #16]
    7554:	52800018 	mov	w24, #0x0                   	// #0
    7558:	7100001f 	cmp	w0, #0x0
    755c:	54003a8d 	b.le	7cac <fwp_write+0x9f8>
    7560:	f9014bf9 	str	x25, [sp, #656]
    7564:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x490>
    7568:	91014339 	add	x25, x25, #0x50
    756c:	f9014ffa 	str	x26, [sp, #664]
    7570:	9000003a 	adrp	x26, b000 <_IO_stdin_used+0x490>
    7574:	9100435a 	add	x26, x26, #0x10
    7578:	91002276 	add	x22, x19, #0x8
    757c:	d2800013 	mov	x19, #0x0                   	// #0
    7580:	b5003e73 	cbnz	x19, 7d4c <fwp_write+0xa98>
    7584:	d37df277 	lsl	x23, x19, #3
    7588:	34003c98 	cbz	w24, 7d18 <fwp_write+0xa64>
    758c:	f9401382 	ldr	x2, [x28, #32]
    7590:	aa1403e0 	mov	x0, x20
    7594:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7598:	52800003 	mov	w3, #0x0                   	// #0
    759c:	f8776842 	ldr	x2, [x2, x23]
    75a0:	91000673 	add	x19, x19, #0x1
    75a4:	97ffff44 	bl	72b4 <fwp_write>
    75a8:	b9401380 	ldr	w0, [x28, #16]
    75ac:	6b13001f 	cmp	w0, w19
    75b0:	54fffe8c 	b.gt	7580 <fwp_write+0x2cc>
    75b4:	f9414bf9 	ldr	x25, [sp, #656]
    75b8:	f9414ffa 	ldr	x26, [sp, #664]
    75bc:	34003798 	cbz	w24, 7cac <fwp_write+0x9f8>
    75c0:	52800523 	mov	w3, #0x29                  	// #41
    75c4:	aa1503e1 	mov	x1, x21
    75c8:	aa1403e0 	mov	x0, x20
    75cc:	d2800022 	mov	x2, #0x1                   	// #1
    75d0:	39001fe3 	strb	w3, [sp, #7]
    75d4:	97ffef6f 	bl	3390 <buf_put>
    75d8:	f9413bf5 	ldr	x21, [sp, #624]
    75dc:	f9413ff6 	ldr	x22, [sp, #632]
    75e0:	f94143f7 	ldr	x23, [sp, #640]
    75e4:	f94147f8 	ldr	x24, [sp, #648]
    75e8:	f94153fb 	ldr	x27, [sp, #672]
    75ec:	f94157fc 	ldr	x28, [sp, #680]
    75f0:	17ffff5d 	b	7364 <fwp_write+0xb0>
    75f4:	b9404855 	ldr	w21, [x2, #72]
    75f8:	aa1403e0 	mov	x0, x20
    75fc:	93407eb6 	sxtw	x22, w21
    7600:	91000ac1 	add	x1, x22, #0x2
    7604:	97ffef2f 	bl	32c0 <buf_grow>
    7608:	a9400281 	ldp	x1, x0, [x20]
    760c:	528e8603 	mov	w3, #0x7430                	// #29744
    7610:	78206823 	strh	w3, [x1, x0]
    7614:	8b000022 	add	x2, x1, x0
    7618:	710002bf 	cmp	w21, #0x0
    761c:	540036ad 	b.le	7cf0 <fwp_write+0xa3c>
    7620:	110006a3 	add	w3, w21, #0x1
    7624:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7628:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    762c:	91000449 	add	x9, x2, #0x1
    7630:	8b23c043 	add	x3, x2, w3, sxtw
    7634:	f28aaac6 	movk	x6, #0x5556
    7638:	f2955568 	movk	x8, #0xaaab
    763c:	1400000d 	b	7670 <fwp_write+0x3bc>
    7640:	d2800021 	mov	x1, #0x1                   	// #1
    7644:	528005a5 	mov	w5, #0x2d                  	// #45
    7648:	f100001f 	cmp	x0, #0x0
    764c:	9b467e60 	smulh	x0, x19, x6
    7650:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7654:	381ff465 	strb	w5, [x3], #-1
    7658:	cb040000 	sub	x0, x0, x4
    765c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7660:	cb020000 	sub	x0, x0, x2
    7664:	8b010013 	add	x19, x0, x1
    7668:	eb03013f 	cmp	x9, x3
    766c:	54003420 	b.eq	7cf0 <fwp_write+0xa3c>  // b.none
    7670:	9b467e60 	smulh	x0, x19, x6
    7674:	937ffe64 	asr	x4, x19, #63
    7678:	52800605 	mov	w5, #0x30                  	// #48
    767c:	cb040000 	sub	x0, x0, x4
    7680:	8b000400 	add	x0, x0, x0, lsl #1
    7684:	cb000260 	sub	x0, x19, x0
    7688:	91000c01 	add	x1, x0, #0x3
    768c:	9bc87c22 	umulh	x2, x1, x8
    7690:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7694:	8b4204e2 	add	x2, x7, x2, lsr #1
    7698:	eb020021 	subs	x1, x1, x2
    769c:	54fffd60 	b.eq	7648 <fwp_write+0x394>  // b.none
    76a0:	f100043f 	cmp	x1, #0x1
    76a4:	54fffce1 	b.ne	7640 <fwp_write+0x38c>  // b.any
    76a8:	d2800001 	mov	x1, #0x0                   	// #0
    76ac:	52800565 	mov	w5, #0x2b                  	// #43
    76b0:	17ffffe6 	b	7648 <fwp_write+0x394>
    76b4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    76b8:	f947f400 	ldr	x0, [x0, #4072]
    76bc:	f94127e2 	ldr	x2, [sp, #584]
    76c0:	f9400001 	ldr	x1, [x0]
    76c4:	eb010042 	subs	x2, x2, x1
    76c8:	d2800001 	mov	x1, #0x0                   	// #0
    76cc:	540023a1 	b.ne	7b40 <fwp_write+0x88c>  // b.any
    76d0:	f9413bf5 	ldr	x21, [sp, #624]
    76d4:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    76d8:	f9413ff6 	ldr	x22, [sp, #632]
    76dc:	aa1403e0 	mov	x0, x20
    76e0:	913ee021 	add	x1, x1, #0xfb8
    76e4:	d2800102 	mov	x2, #0x8                   	// #8
    76e8:	17ffff77 	b	74c4 <fwp_write+0x210>
    76ec:	aa1403e0 	mov	x0, x20
    76f0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x490>
    76f4:	d28000c2 	mov	x2, #0x6                   	// #6
    76f8:	91006021 	add	x1, x1, #0x18
    76fc:	97ffef25 	bl	3390 <buf_put>
    7700:	d2800015 	mov	x21, #0x0                   	// #0
    7704:	f9400263 	ldr	x3, [x19]
    7708:	f240f87f 	tst	x3, #0x7fffffffffffffff
    770c:	54002c40 	b.eq	7c94 <fwp_write+0x9e0>  // b.none
    7710:	f9401f82 	ldr	x2, [x28, #56]
    7714:	f90143f7 	str	x23, [sp, #640]
    7718:	f90147f8 	str	x24, [sp, #648]
    771c:	d2800857 	mov	x23, #0x42                  	// #66
    7720:	f9014bf9 	str	x25, [sp, #656]
    7724:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x490>
    7728:	f9014ffa 	str	x26, [sp, #664]
    772c:	910042d6 	add	x22, x22, #0x10
    7730:	d2800038 	mov	x24, #0x1                   	// #1
    7734:	f2a18017 	movk	x23, #0xc00, lsl #16
    7738:	d2809099 	mov	x25, #0x484                 	// #1156
    773c:	b4000482 	cbz	x2, 77cc <fwp_write+0x518>
    7740:	b9400040 	ldr	w0, [x2]
    7744:	7100701f 	cmp	w0, #0x1c
    7748:	540042a0 	b.eq	7f9c <fwp_write+0xce8>  // b.none
    774c:	71006c1f 	cmp	w0, #0x1b
    7750:	540003e8 	b.hi	77cc <fwp_write+0x518>  // b.pmore
    7754:	9ac02301 	lsl	x1, x24, x0
    7758:	ea17003f 	tst	x1, x23
    775c:	54003681 	b.ne	7e2c <fwp_write+0xb78>  // b.any
    7760:	ea19003f 	tst	x1, x25
    7764:	54003501 	b.ne	7e04 <fwp_write+0xb50>  // b.any
    7768:	d2800424 	mov	x4, #0x21                  	// #33
    776c:	ea04003f 	tst	x1, x4
    7770:	540002e0 	b.eq	77cc <fwp_write+0x518>  // b.none
    7774:	b7f849a3 	tbnz	x3, #63, 80a8 <fwp_write+0xdf4>
    7778:	91002261 	add	x1, x19, #0x8
    777c:	8b150021 	add	x1, x1, x21
    7780:	39400021 	ldrb	w1, [x1]
    7784:	7100001f 	cmp	w0, #0x0
    7788:	93401c23 	sxtb	x3, w1
    778c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7790:	aa1403e0 	mov	x0, x20
    7794:	52800003 	mov	w3, #0x0                   	// #0
    7798:	97fffec7 	bl	72b4 <fwp_write>
    779c:	910006b5 	add	x21, x21, #0x1
    77a0:	f9400260 	ldr	x0, [x19]
    77a4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    77a8:	eb0002bf 	cmp	x21, x0
    77ac:	540026c2 	b.cs	7c84 <fwp_write+0x9d0>  // b.hs, b.nlast
    77b0:	d2800042 	mov	x2, #0x2                   	// #2
    77b4:	aa1603e1 	mov	x1, x22
    77b8:	aa1403e0 	mov	x0, x20
    77bc:	97ffeef5 	bl	3390 <buf_put>
    77c0:	f9401f82 	ldr	x2, [x28, #56]
    77c4:	f9400263 	ldr	x3, [x19]
    77c8:	b5fffbc2 	cbnz	x2, 7740 <fwp_write+0x48c>
    77cc:	d37df2a0 	lsl	x0, x21, #3
    77d0:	b7f83f03 	tbnz	x3, #63, 7fb0 <fwp_write+0xcfc>
    77d4:	91002261 	add	x1, x19, #0x8
    77d8:	8b000020 	add	x0, x1, x0
    77dc:	f9400001 	ldr	x1, [x0]
    77e0:	17ffffec 	b	7790 <fwp_write+0x4dc>
    77e4:	a9400e62 	ldp	x2, x3, [x19]
    77e8:	b7f83ca3 	tbnz	x3, #63, 7f7c <fwp_write+0xcc8>
    77ec:	910123f5 	add	x21, sp, #0x48
    77f0:	aa1503e0 	mov	x0, x21
    77f4:	97ffed6b 	bl	2da0 <fwp_fmt_u128>
    77f8:	aa1503e0 	mov	x0, x21
    77fc:	97ffeba5 	bl	2690 <strlen@plt>
    7800:	aa1503e1 	mov	x1, x21
    7804:	aa0003e2 	mov	x2, x0
    7808:	17fffed1 	b	734c <fwp_write+0x98>
    780c:	fd015be8 	str	d8, [sp, #688]
    7810:	1e270268 	fmov	s8, w19
    7814:	fd015fe9 	str	d9, [sp, #696]
    7818:	1e282100 	fcmp	s8, s8
    781c:	54004d26 	b.vs	81c0 <fwp_write+0xf0c>
    7820:	1e20c101 	fabs	s1, s8
    7824:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7828:	1e270000 	fmov	s0, w0
    782c:	1e202020 	fcmp	s1, s0
    7830:	54002c0d 	b.le	7db0 <fwp_write+0xafc>
    7834:	1e202118 	fcmpe	s8, #0.0
    7838:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1d60>
    783c:	912e4042 	add	x2, x2, #0xb90
    7840:	910123f5 	add	x21, sp, #0x48
    7844:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    7848:	913da021 	add	x1, x1, #0xf68
    784c:	aa1503e0 	mov	x0, x21
    7850:	9a81c041 	csel	x1, x2, x1, gt
    7854:	97ffec3b 	bl	2940 <strcpy@plt>
    7858:	aa1503e0 	mov	x0, x21
    785c:	97ffeb8d 	bl	2690 <strlen@plt>
    7860:	aa1503e1 	mov	x1, x21
    7864:	aa0003e2 	mov	x2, x0
    7868:	aa1403e0 	mov	x0, x20
    786c:	97ffeec9 	bl	3390 <buf_put>
    7870:	f9413bf5 	ldr	x21, [sp, #624]
    7874:	f9413ff6 	ldr	x22, [sp, #632]
    7878:	f94153fb 	ldr	x27, [sp, #672]
    787c:	f94157fc 	ldr	x28, [sp, #680]
    7880:	fd415be8 	ldr	d8, [sp, #688]
    7884:	fd415fe9 	ldr	d9, [sp, #696]
    7888:	17fffeb7 	b	7364 <fwp_write+0xb0>
    788c:	f9400276 	ldr	x22, [x19]
    7890:	34002e03 	cbz	w3, 7e50 <fwp_write+0xb9c>
    7894:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7898:	f947f400 	ldr	x0, [x0, #4072]
    789c:	f94127e2 	ldr	x2, [sp, #584]
    78a0:	f9400001 	ldr	x1, [x0]
    78a4:	eb010042 	subs	x2, x2, x1
    78a8:	d2800001 	mov	x1, #0x0                   	// #0
    78ac:	540014a1 	b.ne	7b40 <fwp_write+0x88c>  // b.any
    78b0:	aa1603e2 	mov	x2, x22
    78b4:	91002261 	add	x1, x19, #0x8
    78b8:	f9413bf5 	ldr	x21, [sp, #624]
    78bc:	aa1403e0 	mov	x0, x20
    78c0:	f9413ff6 	ldr	x22, [sp, #632]
    78c4:	17ffff00 	b	74c4 <fwp_write+0x210>
    78c8:	fd015be8 	str	d8, [sp, #688]
    78cc:	9e670268 	fmov	d8, x19
    78d0:	fd015fe9 	str	d9, [sp, #696]
    78d4:	1e682100 	fcmp	d8, d8
    78d8:	54004746 	b.vs	81c0 <fwp_write+0xf0c>
    78dc:	1e60c101 	fabs	d1, d8
    78e0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    78e4:	9e670000 	fmov	d0, x0
    78e8:	910123f5 	add	x21, sp, #0x48
    78ec:	52800033 	mov	w19, #0x1                   	// #1
    78f0:	1e602020 	fcmp	d1, d0
    78f4:	540001ad 	b.le	7928 <fwp_write+0x674>
    78f8:	1e602118 	fcmpe	d8, #0.0
    78fc:	f0000002 	adrp	x2, a000 <fwp_main_thread+0x1d60>
    7900:	912e4042 	add	x2, x2, #0xb90
    7904:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    7908:	913da021 	add	x1, x1, #0xf68
    790c:	aa1503e0 	mov	x0, x21
    7910:	9a81c041 	csel	x1, x2, x1, gt
    7914:	97ffec0b 	bl	2940 <strcpy@plt>
    7918:	17ffffd0 	b	7858 <fwp_write+0x5a4>
    791c:	11000673 	add	w19, w19, #0x1
    7920:	71004a7f 	cmp	w19, #0x12
    7924:	54003860 	b.eq	8030 <fwp_write+0xd7c>  // b.none
    7928:	1e604100 	fmov	d0, d8
    792c:	2a1303e1 	mov	w1, w19
    7930:	aa1503e0 	mov	x0, x21
    7934:	97ffeef3 	bl	3500 <fwp_format_g.constprop.0>
    7938:	aa1503e0 	mov	x0, x21
    793c:	d2800001 	mov	x1, #0x0                   	// #0
    7940:	97ffeb68 	bl	26e0 <strtod@plt>
    7944:	1e602100 	fcmp	d8, d0
    7948:	54fffea1 	b.ne	791c <fwp_write+0x668>  // b.any
    794c:	aa1503e0 	mov	x0, x21
    7950:	97ffeec9 	bl	3474 <fwp_finish_float>
    7954:	17ffffc1 	b	7858 <fwp_write+0x5a4>
    7958:	a9400e62 	ldp	x2, x3, [x19]
    795c:	910123f3 	add	x19, sp, #0x48
    7960:	aa1303e0 	mov	x0, x19
    7964:	97ffed0f 	bl	2da0 <fwp_fmt_u128>
    7968:	17fffe75 	b	733c <fwp_write+0x88>
    796c:	f90143f7 	str	x23, [sp, #640]
    7970:	f90147f8 	str	x24, [sp, #648]
    7974:	2a1303f8 	mov	w24, w19
    7978:	f9014bf9 	str	x25, [sp, #656]
    797c:	f9014ffa 	str	x26, [sp, #664]
    7980:	f13ffe7f 	cmp	x19, #0xfff
    7984:	54000049 	b.ls	798c <fwp_write+0x6d8>  // b.plast
    7988:	b9400278 	ldr	w24, [x19]
    798c:	f9400f80 	ldr	x0, [x28, #24]
    7990:	2a1803f5 	mov	w21, w24
    7994:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7998:	d37ef6b9 	lsl	x25, x21, #2
    799c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    79a0:	aa1603e0 	mov	x0, x22
    79a4:	97ffeb3b 	bl	2690 <strlen@plt>
    79a8:	aa1603e1 	mov	x1, x22
    79ac:	aa0003e2 	mov	x2, x0
    79b0:	aa1403e0 	mov	x0, x20
    79b4:	97ffee77 	bl	3390 <buf_put>
    79b8:	f9401780 	ldr	x0, [x28, #40]
    79bc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    79c0:	7100001f 	cmp	w0, #0x0
    79c4:	5400068d 	b.le	7a94 <fwp_write+0x7e0>
    79c8:	91002276 	add	x22, x19, #0x8
    79cc:	91001ff5 	add	x21, sp, #0x7
    79d0:	d280001b 	mov	x27, #0x0                   	// #0
    79d4:	5280041a 	mov	w26, #0x20                  	// #32
    79d8:	f9401b80 	ldr	x0, [x28, #48]
    79dc:	aa1503e1 	mov	x1, x21
    79e0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    79e4:	d2800022 	mov	x2, #0x1                   	// #1
    79e8:	f8786803 	ldr	x3, [x0, x24]
    79ec:	aa1403e0 	mov	x0, x20
    79f0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    79f4:	39001ffa 	strb	w26, [sp, #7]
    79f8:	97ffee66 	bl	3390 <buf_put>
    79fc:	f13ffeff 	cmp	x23, #0xfff
    7a00:	b9400261 	ldr	w1, [x19]
    7a04:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7a08:	7100383f 	cmp	w1, #0xe
    7a0c:	54000160 	b.eq	7a38 <fwp_write+0x784>  // b.none
    7a10:	7100403f 	cmp	w1, #0x10
    7a14:	54001a60 	b.eq	7d60 <fwp_write+0xaac>  // b.none
    7a18:	7100283f 	cmp	w1, #0xa
    7a1c:	54002aa0 	b.eq	7f70 <fwp_write+0xcbc>  // b.none
    7a20:	540014ac 	b.gt	7cb4 <fwp_write+0xa00>
    7a24:	71000c3f 	cmp	w1, #0x3
    7a28:	540029ac 	b.gt	7f5c <fwp_write+0xca8>
    7a2c:	d37ffee0 	lsr	x0, x23, #63
    7a30:	37f814a1 	tbnz	w1, #31, 7cc4 <fwp_write+0xa10>
    7a34:	d503201f 	nop
    7a38:	34001460 	cbz	w0, 7cc4 <fwp_write+0xa10>
    7a3c:	52800503 	mov	w3, #0x28                  	// #40
    7a40:	aa1503e1 	mov	x1, x21
    7a44:	aa1403e0 	mov	x0, x20
    7a48:	d2800022 	mov	x2, #0x1                   	// #1
    7a4c:	39001fe3 	strb	w3, [sp, #7]
    7a50:	97ffee50 	bl	3390 <buf_put>
    7a54:	aa1303e2 	mov	x2, x19
    7a58:	aa1703e1 	mov	x1, x23
    7a5c:	aa1403e0 	mov	x0, x20
    7a60:	52800003 	mov	w3, #0x0                   	// #0
    7a64:	97fffe14 	bl	72b4 <fwp_write>
    7a68:	52800523 	mov	w3, #0x29                  	// #41
    7a6c:	aa1503e1 	mov	x1, x21
    7a70:	aa1403e0 	mov	x0, x20
    7a74:	d2800022 	mov	x2, #0x1                   	// #1
    7a78:	39001fe3 	strb	w3, [sp, #7]
    7a7c:	97ffee45 	bl	3390 <buf_put>
    7a80:	f9401780 	ldr	x0, [x28, #40]
    7a84:	9100077b 	add	x27, x27, #0x1
    7a88:	b8796800 	ldr	w0, [x0, x25]
    7a8c:	6b1b001f 	cmp	w0, w27
    7a90:	54fffa4c 	b.gt	79d8 <fwp_write+0x724>
    7a94:	f9413bf5 	ldr	x21, [sp, #624]
    7a98:	f9413ff6 	ldr	x22, [sp, #632]
    7a9c:	f94143f7 	ldr	x23, [sp, #640]
    7aa0:	f94147f8 	ldr	x24, [sp, #648]
    7aa4:	f9414bf9 	ldr	x25, [sp, #656]
    7aa8:	f9414ffa 	ldr	x26, [sp, #664]
    7aac:	f94153fb 	ldr	x27, [sp, #672]
    7ab0:	f94157fc 	ldr	x28, [sp, #680]
    7ab4:	17fffe2c 	b	7364 <fwp_write+0xb0>
    7ab8:	52800783 	mov	w3, #0x3c                  	// #60
    7abc:	91001ff3 	add	x19, sp, #0x7
    7ac0:	aa1303e1 	mov	x1, x19
    7ac4:	d2800022 	mov	x2, #0x1                   	// #1
    7ac8:	aa1403e0 	mov	x0, x20
    7acc:	39001fe3 	strb	w3, [sp, #7]
    7ad0:	97ffee30 	bl	3390 <buf_put>
    7ad4:	f9400795 	ldr	x21, [x28, #8]
    7ad8:	aa1503e0 	mov	x0, x21
    7adc:	97ffeaed 	bl	2690 <strlen@plt>
    7ae0:	aa1503e1 	mov	x1, x21
    7ae4:	aa0003e2 	mov	x2, x0
    7ae8:	aa1403e0 	mov	x0, x20
    7aec:	97ffee29 	bl	3390 <buf_put>
    7af0:	528007c3 	mov	w3, #0x3e                  	// #62
    7af4:	aa1303e1 	mov	x1, x19
    7af8:	aa1403e0 	mov	x0, x20
    7afc:	d2800022 	mov	x2, #0x1                   	// #1
    7b00:	39001fe3 	strb	w3, [sp, #7]
    7b04:	17fffe13 	b	7350 <fwp_write+0x9c>
    7b08:	f100067f 	cmp	x19, #0x1
    7b0c:	540025a0 	b.eq	7fc0 <fwp_write+0xd0c>  // b.none
    7b10:	b100067f 	cmn	x19, #0x1
    7b14:	54002bc0 	b.eq	808c <fwp_write+0xdd8>  // b.none
    7b18:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    7b1c:	913dc021 	add	x1, x1, #0xf70
    7b20:	d2800022 	mov	x2, #0x1                   	// #1
    7b24:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    7b28:	f947f400 	ldr	x0, [x0, #4072]
    7b2c:	f94127e4 	ldr	x4, [sp, #584]
    7b30:	f9400003 	ldr	x3, [x0]
    7b34:	eb030084 	subs	x4, x4, x3
    7b38:	d2800003 	mov	x3, #0x0                   	// #0
    7b3c:	54ffebe0 	b.eq	78b8 <fwp_write+0x604>  // b.none
    7b40:	f90143f7 	str	x23, [sp, #640]
    7b44:	f90147f8 	str	x24, [sp, #648]
    7b48:	f9014bf9 	str	x25, [sp, #656]
    7b4c:	f9014ffa 	str	x26, [sp, #664]
    7b50:	fd015be8 	str	d8, [sp, #688]
    7b54:	fd015fe9 	str	d9, [sp, #696]
    7b58:	97ffeb2a 	bl	2800 <__stack_chk_fail@plt>
    7b5c:	52800b63 	mov	w3, #0x5b                  	// #91
    7b60:	91001ff5 	add	x21, sp, #0x7
    7b64:	aa1503e1 	mov	x1, x21
    7b68:	aa1403e0 	mov	x0, x20
    7b6c:	d2800022 	mov	x2, #0x1                   	// #1
    7b70:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x490>
    7b74:	910042d6 	add	x22, x22, #0x10
    7b78:	39001fe3 	strb	w3, [sp, #7]
    7b7c:	97ffee05 	bl	3390 <buf_put>
    7b80:	b4000273 	cbz	x19, 7bcc <fwp_write+0x918>
    7b84:	f9400661 	ldr	x1, [x19, #8]
    7b88:	aa1403e0 	mov	x0, x20
    7b8c:	f9401f82 	ldr	x2, [x28, #56]
    7b90:	52800003 	mov	w3, #0x0                   	// #0
    7b94:	97fffdc8 	bl	72b4 <fwp_write>
    7b98:	f9400a73 	ldr	x19, [x19, #16]
    7b9c:	b4000193 	cbz	x19, 7bcc <fwp_write+0x918>
    7ba0:	aa1603e1 	mov	x1, x22
    7ba4:	aa1403e0 	mov	x0, x20
    7ba8:	d2800042 	mov	x2, #0x2                   	// #2
    7bac:	97ffedf9 	bl	3390 <buf_put>
    7bb0:	f9400661 	ldr	x1, [x19, #8]
    7bb4:	aa1403e0 	mov	x0, x20
    7bb8:	f9401f82 	ldr	x2, [x28, #56]
    7bbc:	52800003 	mov	w3, #0x0                   	// #0
    7bc0:	97fffdbd 	bl	72b4 <fwp_write>
    7bc4:	f9400a73 	ldr	x19, [x19, #16]
    7bc8:	b5fffed3 	cbnz	x19, 7ba0 <fwp_write+0x8ec>
    7bcc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7bd0:	aa1503e1 	mov	x1, x21
    7bd4:	aa1403e0 	mov	x0, x20
    7bd8:	d2800022 	mov	x2, #0x1                   	// #1
    7bdc:	39001fe3 	strb	w3, [sp, #7]
    7be0:	17fffddc 	b	7350 <fwp_write+0x9c>
    7be4:	aa1403e0 	mov	x0, x20
    7be8:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x490>
    7bec:	d28000c2 	mov	x2, #0x6                   	// #6
    7bf0:	91000021 	add	x1, x1, #0x0
    7bf4:	97ffede7 	bl	3390 <buf_put>
    7bf8:	f9400260 	ldr	x0, [x19]
    7bfc:	b40004c0 	cbz	x0, 7c94 <fwp_write+0x9e0>
    7c00:	910123f5 	add	x21, sp, #0x48
    7c04:	91002276 	add	x22, x19, #0x8
    7c08:	f90143f7 	str	x23, [sp, #640]
    7c0c:	d2800017 	mov	x23, #0x0                   	// #0
    7c10:	f90147f8 	str	x24, [sp, #648]
    7c14:	90000038 	adrp	x24, b000 <_IO_stdin_used+0x490>
    7c18:	91002318 	add	x24, x24, #0x8
    7c1c:	f9014bf9 	str	x25, [sp, #656]
    7c20:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x490>
    7c24:	91004339 	add	x25, x25, #0x10
    7c28:	f9014ffa 	str	x26, [sp, #664]
    7c2c:	14000005 	b	7c40 <fwp_write+0x98c>
    7c30:	aa1903e1 	mov	x1, x25
    7c34:	aa1403e0 	mov	x0, x20
    7c38:	d2800042 	mov	x2, #0x2                   	// #2
    7c3c:	97ffedd5 	bl	3390 <buf_put>
    7c40:	38776ac5 	ldrb	w5, [x22, x23]
    7c44:	d2804003 	mov	x3, #0x200                 	// #512
    7c48:	aa1803e4 	mov	x4, x24
    7c4c:	aa0303e1 	mov	x1, x3
    7c50:	52800042 	mov	w2, #0x2                   	// #2
    7c54:	aa1503e0 	mov	x0, x21
    7c58:	910006f7 	add	x23, x23, #0x1
    7c5c:	97ffeac5 	bl	2770 <__snprintf_chk@plt>
    7c60:	aa1503e0 	mov	x0, x21
    7c64:	97ffea8b 	bl	2690 <strlen@plt>
    7c68:	aa1503e1 	mov	x1, x21
    7c6c:	aa0003e2 	mov	x2, x0
    7c70:	aa1403e0 	mov	x0, x20
    7c74:	97ffedc7 	bl	3390 <buf_put>
    7c78:	f9400260 	ldr	x0, [x19]
    7c7c:	eb17001f 	cmp	x0, x23
    7c80:	54fffd88 	b.hi	7c30 <fwp_write+0x97c>  // b.pmore
    7c84:	f94143f7 	ldr	x23, [sp, #640]
    7c88:	f94147f8 	ldr	x24, [sp, #648]
    7c8c:	f9414bf9 	ldr	x25, [sp, #656]
    7c90:	f9414ffa 	ldr	x26, [sp, #664]
    7c94:	52800ba3 	mov	w3, #0x5d                  	// #93
    7c98:	aa1403e0 	mov	x0, x20
    7c9c:	91001fe1 	add	x1, sp, #0x7
    7ca0:	d2800022 	mov	x2, #0x1                   	// #1
    7ca4:	39001fe3 	strb	w3, [sp, #7]
    7ca8:	17fffdaa 	b	7350 <fwp_write+0x9c>
    7cac:	52800fa3 	mov	w3, #0x7d                  	// #125
    7cb0:	17fffe45 	b	75c4 <fwp_write+0x310>
    7cb4:	f10002ff 	cmp	x23, #0x0
    7cb8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7cbc:	71002c3f 	cmp	w1, #0xb
    7cc0:	54ffebc0 	b.eq	7a38 <fwp_write+0x784>  // b.none
    7cc4:	aa1303e2 	mov	x2, x19
    7cc8:	aa1703e1 	mov	x1, x23
    7ccc:	aa1403e0 	mov	x0, x20
    7cd0:	52800003 	mov	w3, #0x0                   	// #0
    7cd4:	97fffd78 	bl	72b4 <fwp_write>
    7cd8:	17ffff6a 	b	7a80 <fwp_write+0x7cc>
    7cdc:	aa1403e0 	mov	x0, x20
    7ce0:	91001fe1 	add	x1, sp, #0x7
    7ce4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7ce8:	d2800022 	mov	x2, #0x1                   	// #1
    7cec:	17fffe39 	b	75d0 <fwp_write+0x31c>
    7cf0:	a9400281 	ldp	x1, x0, [x20]
    7cf4:	91000800 	add	x0, x0, #0x2
    7cf8:	8b160000 	add	x0, x0, x22
    7cfc:	f9000680 	str	x0, [x20, #8]
    7d00:	3820683f 	strb	wzr, [x1, x0]
    7d04:	f9413bf5 	ldr	x21, [sp, #624]
    7d08:	f9413ff6 	ldr	x22, [sp, #632]
    7d0c:	f94153fb 	ldr	x27, [sp, #672]
    7d10:	f94157fc 	ldr	x28, [sp, #680]
    7d14:	17fffd94 	b	7364 <fwp_write+0xb0>
    7d18:	f9400f80 	ldr	x0, [x28, #24]
    7d1c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7d20:	aa1b03e0 	mov	x0, x27
    7d24:	97ffea5b 	bl	2690 <strlen@plt>
    7d28:	aa1b03e1 	mov	x1, x27
    7d2c:	aa0003e2 	mov	x2, x0
    7d30:	aa1403e0 	mov	x0, x20
    7d34:	97ffed97 	bl	3390 <buf_put>
    7d38:	aa1903e1 	mov	x1, x25
    7d3c:	aa1403e0 	mov	x0, x20
    7d40:	d2800062 	mov	x2, #0x3                   	// #3
    7d44:	97ffed93 	bl	3390 <buf_put>
    7d48:	17fffe11 	b	758c <fwp_write+0x2d8>
    7d4c:	aa1a03e1 	mov	x1, x26
    7d50:	aa1403e0 	mov	x0, x20
    7d54:	d2800042 	mov	x2, #0x2                   	// #2
    7d58:	97ffed8e 	bl	3390 <buf_put>
    7d5c:	17fffe0a 	b	7584 <fwp_write+0x2d0>
    7d60:	f9400660 	ldr	x0, [x19, #8]
    7d64:	b4fffb00 	cbz	x0, 7cc4 <fwp_write+0xa10>
    7d68:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x490>
    7d6c:	9100a021 	add	x1, x1, #0x28
    7d70:	97ffeac4 	bl	2880 <strcmp@plt>
    7d74:	7100001f 	cmp	w0, #0x0
    7d78:	1a9f07e0 	cset	w0, ne	// ne = any
    7d7c:	17ffff2f 	b	7a38 <fwp_write+0x784>
    7d80:	aa1403e0 	mov	x0, x20
    7d84:	d2800042 	mov	x2, #0x2                   	// #2
    7d88:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x490>
    7d8c:	91008021 	add	x1, x1, #0x20
    7d90:	97ffed80 	bl	3390 <buf_put>
    7d94:	91004261 	add	x1, x19, #0x10
    7d98:	aa1403e0 	mov	x0, x20
    7d9c:	f9402382 	ldr	x2, [x28, #64]
    7da0:	52800003 	mov	w3, #0x0                   	// #0
    7da4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7da8:	97fffd43 	bl	72b4 <fwp_write>
    7dac:	17fffd9d 	b	7420 <fwp_write+0x16c>
    7db0:	1e22c109 	fcvt	d9, s8
    7db4:	910123f5 	add	x21, sp, #0x48
    7db8:	52800033 	mov	w19, #0x1                   	// #1
    7dbc:	d503201f 	nop
    7dc0:	1e604120 	fmov	d0, d9
    7dc4:	2a1303e1 	mov	w1, w19
    7dc8:	aa1503e0 	mov	x0, x21
    7dcc:	97ffedcd 	bl	3500 <fwp_format_g.constprop.0>
    7dd0:	aa1503e0 	mov	x0, x21
    7dd4:	d2800001 	mov	x1, #0x0                   	// #0
    7dd8:	97ffeab6 	bl	28b0 <strtof@plt>
    7ddc:	1e202100 	fcmp	s8, s0
    7de0:	54ffdb60 	b.eq	794c <fwp_write+0x698>  // b.none
    7de4:	11000673 	add	w19, w19, #0x1
    7de8:	71002a7f 	cmp	w19, #0xa
    7dec:	54fffea1 	b.ne	7dc0 <fwp_write+0xb0c>  // b.any
    7df0:	1e604120 	fmov	d0, d9
    7df4:	aa1503e0 	mov	x0, x21
    7df8:	52800121 	mov	w1, #0x9                   	// #9
    7dfc:	97ffedc1 	bl	3500 <fwp_format_g.constprop.0>
    7e00:	17fffed3 	b	794c <fwp_write+0x698>
    7e04:	d37ef6a1 	lsl	x1, x21, #2
    7e08:	b7f81563 	tbnz	x3, #63, 80b4 <fwp_write+0xe00>
    7e0c:	91002263 	add	x3, x19, #0x8
    7e10:	8b010061 	add	x1, x3, x1
    7e14:	b9400023 	ldr	w3, [x1]
    7e18:	7100081f 	cmp	w0, #0x2
    7e1c:	2a0303e1 	mov	w1, w3
    7e20:	93407c63 	sxtw	x3, w3
    7e24:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e28:	17fffe5a 	b	7790 <fwp_write+0x4dc>
    7e2c:	d37ffaa1 	lsl	x1, x21, #1
    7e30:	b7f81363 	tbnz	x3, #63, 809c <fwp_write+0xde8>
    7e34:	91002263 	add	x3, x19, #0x8
    7e38:	8b010061 	add	x1, x3, x1
    7e3c:	79400021 	ldrh	w1, [x1]
    7e40:	7100041f 	cmp	w0, #0x1
    7e44:	93403c23 	sxth	x3, w1
    7e48:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e4c:	17fffe51 	b	7790 <fwp_write+0x4dc>
    7e50:	52800443 	mov	w3, #0x22                  	// #34
    7e54:	91001ff5 	add	x21, sp, #0x7
    7e58:	91002273 	add	x19, x19, #0x8
    7e5c:	aa1503e1 	mov	x1, x21
    7e60:	aa1403e0 	mov	x0, x20
    7e64:	d2800022 	mov	x2, #0x1                   	// #1
    7e68:	39001fe3 	strb	w3, [sp, #7]
    7e6c:	f90143f7 	str	x23, [sp, #640]
    7e70:	8b160277 	add	x23, x19, x22
    7e74:	f90147f8 	str	x24, [sp, #648]
    7e78:	97ffed46 	bl	3390 <buf_put>
    7e7c:	b4000696 	cbz	x22, 7f4c <fwp_write+0xc98>
    7e80:	f0000018 	adrp	x24, a000 <fwp_main_thread+0x1d60>
    7e84:	913f4318 	add	x24, x24, #0xfd0
    7e88:	f9014bf9 	str	x25, [sp, #656]
    7e8c:	f0000019 	adrp	x25, a000 <fwp_main_thread+0x1d60>
    7e90:	913fc339 	add	x25, x25, #0xff0
    7e94:	f9014ffa 	str	x26, [sp, #664]
    7e98:	1400000d 	b	7ecc <fwp_write+0xc18>
    7e9c:	710024bf 	cmp	w5, #0x9
    7ea0:	54000460 	b.eq	7f2c <fwp_write+0xc78>  // b.none
    7ea4:	710028bf 	cmp	w5, #0xa
    7ea8:	54000a61 	b.ne	7ff4 <fwp_write+0xd40>  // b.any
    7eac:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    7eb0:	aa1403e0 	mov	x0, x20
    7eb4:	913f8021 	add	x1, x1, #0xfe0
    7eb8:	d2800042 	mov	x2, #0x2                   	// #2
    7ebc:	97ffed35 	bl	3390 <buf_put>
    7ec0:	91000673 	add	x19, x19, #0x1
    7ec4:	eb17027f 	cmp	x19, x23
    7ec8:	540003e0 	b.eq	7f44 <fwp_write+0xc90>  // b.none
    7ecc:	39400265 	ldrb	w5, [x19]
    7ed0:	710034bf 	cmp	w5, #0xd
    7ed4:	54000180 	b.eq	7f04 <fwp_write+0xc50>  // b.none
    7ed8:	54fffe29 	b.ls	7e9c <fwp_write+0xbe8>  // b.plast
    7edc:	710088bf 	cmp	w5, #0x22
    7ee0:	540001c0 	b.eq	7f18 <fwp_write+0xc64>  // b.none
    7ee4:	710170bf 	cmp	w5, #0x5c
    7ee8:	54000741 	b.ne	7fd0 <fwp_write+0xd1c>  // b.any
    7eec:	aa1403e0 	mov	x0, x20
    7ef0:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    7ef4:	d2800042 	mov	x2, #0x2                   	// #2
    7ef8:	913f6021 	add	x1, x1, #0xfd8
    7efc:	97ffed25 	bl	3390 <buf_put>
    7f00:	17fffff0 	b	7ec0 <fwp_write+0xc0c>
    7f04:	aa1903e1 	mov	x1, x25
    7f08:	aa1403e0 	mov	x0, x20
    7f0c:	d2800042 	mov	x2, #0x2                   	// #2
    7f10:	97ffed20 	bl	3390 <buf_put>
    7f14:	17ffffeb 	b	7ec0 <fwp_write+0xc0c>
    7f18:	aa1803e1 	mov	x1, x24
    7f1c:	aa1403e0 	mov	x0, x20
    7f20:	d2800042 	mov	x2, #0x2                   	// #2
    7f24:	97ffed1b 	bl	3390 <buf_put>
    7f28:	17ffffe6 	b	7ec0 <fwp_write+0xc0c>
    7f2c:	aa1403e0 	mov	x0, x20
    7f30:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    7f34:	d2800042 	mov	x2, #0x2                   	// #2
    7f38:	913fa021 	add	x1, x1, #0xfe8
    7f3c:	97ffed15 	bl	3390 <buf_put>
    7f40:	17ffffe0 	b	7ec0 <fwp_write+0xc0c>
    7f44:	f9414bf9 	ldr	x25, [sp, #656]
    7f48:	f9414ffa 	ldr	x26, [sp, #664]
    7f4c:	aa1503e1 	mov	x1, x21
    7f50:	aa1403e0 	mov	x0, x20
    7f54:	52800443 	mov	w3, #0x22                  	// #34
    7f58:	17fffd9d 	b	75cc <fwp_write+0x318>
    7f5c:	7100103f 	cmp	w1, #0x4
    7f60:	54ffeb21 	b.ne	7cc4 <fwp_write+0xa10>  // b.any
    7f64:	f94006e0 	ldr	x0, [x23, #8]
    7f68:	d37ffc00 	lsr	x0, x0, #63
    7f6c:	17fffeb3 	b	7a38 <fwp_write+0x784>
    7f70:	710002ff 	cmp	w23, #0x0
    7f74:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7f78:	17fffeb0 	b	7a38 <fwp_write+0x784>
    7f7c:	528005a1 	mov	w1, #0x2d                  	// #45
    7f80:	eb0203e2 	negs	x2, x2
    7f84:	da0303e3 	ngc	x3, x3
    7f88:	910127e0 	add	x0, sp, #0x49
    7f8c:	910123f5 	add	x21, sp, #0x48
    7f90:	390123e1 	strb	w1, [sp, #72]
    7f94:	97ffeb83 	bl	2da0 <fwp_fmt_u128>
    7f98:	17fffe18 	b	77f8 <fwp_write+0x544>
    7f9c:	d37ceea1 	lsl	x1, x21, #4
    7fa0:	b7f810a3 	tbnz	x3, #63, 81b4 <fwp_write+0xf00>
    7fa4:	91002260 	add	x0, x19, #0x8
    7fa8:	8b010001 	add	x1, x0, x1
    7fac:	17fffdf9 	b	7790 <fwp_write+0x4dc>
    7fb0:	f9400a61 	ldr	x1, [x19, #16]
    7fb4:	8b010000 	add	x0, x0, x1
    7fb8:	f9400001 	ldr	x1, [x0]
    7fbc:	17fffdf5 	b	7790 <fwp_write+0x4dc>
    7fc0:	f0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    7fc4:	d2800042 	mov	x2, #0x2                   	// #2
    7fc8:	913de021 	add	x1, x1, #0xf78
    7fcc:	17fffed6 	b	7b24 <fwp_write+0x870>
    7fd0:	7101fcbf 	cmp	w5, #0x7f
    7fd4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7fd8:	540000e9 	b.ls	7ff4 <fwp_write+0xd40>  // b.plast
    7fdc:	aa1503e1 	mov	x1, x21
    7fe0:	aa1403e0 	mov	x0, x20
    7fe4:	d2800022 	mov	x2, #0x1                   	// #1
    7fe8:	39001fe5 	strb	w5, [sp, #7]
    7fec:	97ffece9 	bl	3390 <buf_put>
    7ff0:	17ffffb4 	b	7ec0 <fwp_write+0xc0c>
    7ff4:	d2800203 	mov	x3, #0x10                  	// #16
    7ff8:	f0000004 	adrp	x4, a000 <fwp_main_thread+0x1d60>
    7ffc:	aa0303e1 	mov	x1, x3
    8000:	913fe084 	add	x4, x4, #0xff8
    8004:	910123f6 	add	x22, sp, #0x48
    8008:	52800042 	mov	w2, #0x2                   	// #2
    800c:	aa1603e0 	mov	x0, x22
    8010:	97ffe9d8 	bl	2770 <__snprintf_chk@plt>
    8014:	aa1603e0 	mov	x0, x22
    8018:	97ffe99e 	bl	2690 <strlen@plt>
    801c:	aa1603e1 	mov	x1, x22
    8020:	aa0003e2 	mov	x2, x0
    8024:	aa1403e0 	mov	x0, x20
    8028:	97ffecda 	bl	3390 <buf_put>
    802c:	17ffffa5 	b	7ec0 <fwp_write+0xc0c>
    8030:	1e604100 	fmov	d0, d8
    8034:	aa1503e0 	mov	x0, x21
    8038:	52800221 	mov	w1, #0x11                  	// #17
    803c:	97ffed31 	bl	3500 <fwp_format_g.constprop.0>
    8040:	17fffe43 	b	794c <fwp_write+0x698>
    8044:	b9401040 	ldr	w0, [x2, #16]
    8048:	350003c0 	cbnz	w0, 80c0 <fwp_write+0xe0c>
    804c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8050:	f947f400 	ldr	x0, [x0, #4072]
    8054:	f94127e2 	ldr	x2, [sp, #584]
    8058:	f9400001 	ldr	x1, [x0]
    805c:	eb010042 	subs	x2, x2, x1
    8060:	d2800001 	mov	x1, #0x0                   	// #0
    8064:	54ffd721 	b.ne	7b48 <fwp_write+0x894>  // b.any
    8068:	f9413bf5 	ldr	x21, [sp, #624]
    806c:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x490>
    8070:	f9413ff6 	ldr	x22, [sp, #632]
    8074:	aa1403e0 	mov	x0, x20
    8078:	f94143f7 	ldr	x23, [sp, #640]
    807c:	91012021 	add	x1, x1, #0x48
    8080:	f94147f8 	ldr	x24, [sp, #648]
    8084:	d2800042 	mov	x2, #0x2                   	// #2
    8088:	17fffd0f 	b	74c4 <fwp_write+0x210>
    808c:	d0000001 	adrp	x1, a000 <fwp_main_thread+0x1d60>
    8090:	d2800042 	mov	x2, #0x2                   	// #2
    8094:	913e0021 	add	x1, x1, #0xf80
    8098:	17fffea3 	b	7b24 <fwp_write+0x870>
    809c:	f9400a63 	ldr	x3, [x19, #16]
    80a0:	8b030021 	add	x1, x1, x3
    80a4:	17ffff66 	b	7e3c <fwp_write+0xb88>
    80a8:	f9400a61 	ldr	x1, [x19, #16]
    80ac:	8b0102a1 	add	x1, x21, x1
    80b0:	17fffdb4 	b	7780 <fwp_write+0x4cc>
    80b4:	f9400a63 	ldr	x3, [x19, #16]
    80b8:	8b030021 	add	x1, x1, x3
    80bc:	17ffff56 	b	7e14 <fwp_write+0xb60>
    80c0:	b9404840 	ldr	w0, [x2, #72]
    80c4:	91001ff5 	add	x21, sp, #0x7
    80c8:	34ffa380 	cbz	w0, 7538 <fwp_write+0x284>
    80cc:	52800503 	mov	w3, #0x28                  	// #40
    80d0:	aa1403e0 	mov	x0, x20
    80d4:	aa1503e1 	mov	x1, x21
    80d8:	d2800022 	mov	x2, #0x1                   	// #1
    80dc:	39001fe3 	strb	w3, [sp, #7]
    80e0:	97ffecac 	bl	3390 <buf_put>
    80e4:	b9401380 	ldr	w0, [x28, #16]
    80e8:	52800038 	mov	w24, #0x1                   	// #1
    80ec:	7100001f 	cmp	w0, #0x0
    80f0:	54ffa38c 	b.gt	7560 <fwp_write+0x2ac>
    80f4:	17fffd33 	b	75c0 <fwp_write+0x30c>
    80f8:	f9014bf9 	str	x25, [sp, #656]
    80fc:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x114b8>
    8100:	f9014ffa 	str	x26, [sp, #664]
    8104:	f9400676 	ldr	x22, [x19, #8]
    8108:	910ae333 	add	x19, x25, #0x2b8
    810c:	91002273 	add	x19, x19, #0x8
    8110:	937ffed8 	asr	x24, x22, #63
    8114:	aa1802c0 	orr	x0, x22, x24
    8118:	b5000320 	cbnz	x0, 817c <fwp_write+0xec8>
    811c:	110006b5 	add	w21, w21, #0x1
    8120:	710016bf 	cmp	w21, #0x5
    8124:	54ffffc1 	b.ne	811c <fwp_write+0xe68>  // b.any
    8128:	b7f80578 	tbnz	x24, #63, 81d4 <fwp_write+0xf20>
    812c:	910023f3 	add	x19, sp, #0x8
    8130:	aa1603e2 	mov	x2, x22
    8134:	aa1303e0 	mov	x0, x19
    8138:	d2800003 	mov	x3, #0x0                   	// #0
    813c:	97ffeb19 	bl	2da0 <fwp_fmt_u128>
    8140:	910123f5 	add	x21, sp, #0x48
    8144:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x490>
    8148:	aa1303e4 	mov	x4, x19
    814c:	aa1503e0 	mov	x0, x21
    8150:	91010063 	add	x3, x3, #0x40
    8154:	d2804002 	mov	x2, #0x200                 	// #512
    8158:	52800041 	mov	w1, #0x2                   	// #2
    815c:	97ffe951 	bl	26a0 <__sprintf_chk@plt>
    8160:	aa1503e0 	mov	x0, x21
    8164:	97ffe94b 	bl	2690 <strlen@plt>
    8168:	aa1503e1 	mov	x1, x21
    816c:	aa0003e2 	mov	x2, x0
    8170:	aa1403e0 	mov	x0, x20
    8174:	97ffec87 	bl	3390 <buf_put>
    8178:	17fffe47 	b	7a94 <fwp_write+0x7e0>
    817c:	f9400277 	ldr	x23, [x19]
    8180:	aa1603e0 	mov	x0, x22
    8184:	aa1803e1 	mov	x1, x24
    8188:	aa1703e2 	mov	x2, x23
    818c:	937ffefa 	asr	x26, x23, #63
    8190:	aa1a03e3 	mov	x3, x26
    8194:	9400098f 	bl	a7d0 <__modti3>
    8198:	aa010000 	orr	x0, x0, x1
    819c:	b40002c0 	cbz	x0, 81f4 <fwp_write+0xf40>
    81a0:	110006b5 	add	w21, w21, #0x1
    81a4:	91004273 	add	x19, x19, #0x10
    81a8:	710016bf 	cmp	w21, #0x5
    81ac:	54fffe81 	b.ne	817c <fwp_write+0xec8>  // b.any
    81b0:	17ffffde 	b	8128 <fwp_write+0xe74>
    81b4:	f9400a60 	ldr	x0, [x19, #16]
    81b8:	8b000021 	add	x1, x1, x0
    81bc:	17fffd75 	b	7790 <fwp_write+0x4dc>
    81c0:	528c29c0 	mov	w0, #0x614e                	// #24910
    81c4:	910123f5 	add	x21, sp, #0x48
    81c8:	72a009c0 	movk	w0, #0x4e, lsl #16
    81cc:	b9004be0 	str	w0, [sp, #72]
    81d0:	17fffda2 	b	7858 <fwp_write+0x5a4>
    81d4:	528005a1 	mov	w1, #0x2d                  	// #45
    81d8:	eb1603e2 	negs	x2, x22
    81dc:	da1803e3 	ngc	x3, x24
    81e0:	910027e0 	add	x0, sp, #0x9
    81e4:	910023f3 	add	x19, sp, #0x8
    81e8:	390023e1 	strb	w1, [sp, #8]
    81ec:	97ffeaed 	bl	2da0 <fwp_fmt_u128>
    81f0:	17ffffd4 	b	8140 <fwp_write+0xe8c>
    81f4:	aa1703e2 	mov	x2, x23
    81f8:	aa1a03e3 	mov	x3, x26
    81fc:	aa1603e0 	mov	x0, x22
    8200:	aa1803e1 	mov	x1, x24
    8204:	94000893 	bl	a450 <__divti3>
    8208:	aa0003e2 	mov	x2, x0
    820c:	aa0103e3 	mov	x3, x1
    8210:	b7f80201 	tbnz	x1, #63, 8250 <fwp_write+0xf9c>
    8214:	910023f3 	add	x19, sp, #0x8
    8218:	aa1303e0 	mov	x0, x19
    821c:	97ffeae1 	bl	2da0 <fwp_fmt_u128>
    8220:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8224:	910ae339 	add	x25, x25, #0x2b8
    8228:	910123f5 	add	x21, sp, #0x48
    822c:	aa1303e4 	mov	x4, x19
    8230:	aa1503e0 	mov	x0, x21
    8234:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x490>
    8238:	f8616b25 	ldr	x5, [x25, x1]
    823c:	9100e063 	add	x3, x3, #0x38
    8240:	d2804002 	mov	x2, #0x200                 	// #512
    8244:	52800041 	mov	w1, #0x2                   	// #2
    8248:	97ffe916 	bl	26a0 <__sprintf_chk@plt>
    824c:	17ffffc5 	b	8160 <fwp_write+0xeac>
    8250:	528005a4 	mov	w4, #0x2d                  	// #45
    8254:	eb0003e2 	negs	x2, x0
    8258:	da0103e3 	ngc	x3, x1
    825c:	910027e0 	add	x0, sp, #0x9
    8260:	910023f3 	add	x19, sp, #0x8
    8264:	390023e4 	strb	w4, [sp, #8]
    8268:	97ffeace 	bl	2da0 <fwp_fmt_u128>
    826c:	17ffffed 	b	8220 <fwp_write+0xf6c>
    8270:	f9013bf5 	str	x21, [sp, #624]
    8274:	f9013ff6 	str	x22, [sp, #632]
    8278:	f90143f7 	str	x23, [sp, #640]
    827c:	f90147f8 	str	x24, [sp, #648]
    8280:	f9014bf9 	str	x25, [sp, #656]
    8284:	f9014ffa 	str	x26, [sp, #664]
    8288:	f90153fb 	str	x27, [sp, #672]
    828c:	f90157fc 	str	x28, [sp, #680]
    8290:	fd015be8 	str	d8, [sp, #688]
    8294:	fd015fe9 	str	d9, [sp, #696]
    8298:	97ffe95a 	bl	2800 <__stack_chk_fail@plt>
    829c:	d503201f 	nop

00000000000082a0 <fwp_main_thread>:
    82a0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    82a4:	910003fd 	mov	x29, sp
    82a8:	a90153f3 	stp	x19, x20, [sp, #16]
    82ac:	b0000153 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    82b0:	9114c261 	add	x1, x19, #0x530
    82b4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    82b8:	f947f400 	ldr	x0, [x0, #4072]
    82bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    82c0:	a90363f7 	stp	x23, x24, [sp, #48]
    82c4:	d10703ff 	sub	sp, sp, #0x1c0
    82c8:	b953a421 	ldr	w1, [x1, #5028]
    82cc:	f9400002 	ldr	x2, [x0]
    82d0:	f900dfe2 	str	x2, [sp, #440]
    82d4:	d2800002 	mov	x2, #0x0                   	// #0
    82d8:	34000e81 	cbz	w1, 84a8 <fwp_main_thread+0x208>
    82dc:	9114c260 	add	x0, x19, #0x530
    82e0:	b953a800 	ldr	w0, [x0, #5032]
    82e4:	35000da0 	cbnz	w0, 8498 <fwp_main_thread+0x1f8>
    82e8:	900000d4 	adrp	x20, 20000 <__data_start>
    82ec:	900000c2 	adrp	x2, 20000 <__data_start>
    82f0:	9100c297 	add	x23, x20, #0x30
    82f4:	910d4042 	add	x2, x2, #0x350
    82f8:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    82fc:	d2a00024 	mov	x4, #0x10000               	// #65536
    8300:	910303f5 	add	x21, sp, #0xc0
    8304:	910283f8 	add	x24, sp, #0xa0
    8308:	aa1503e0 	mov	x0, x21
    830c:	d2800001 	mov	x1, #0x0                   	// #0
    8310:	a9018ef8 	stp	x24, x3, [x23, #24]
    8314:	f90063e2 	str	x2, [sp, #192]
    8318:	b900cbff 	str	wzr, [sp, #200]
    831c:	f9006be4 	str	x4, [sp, #208]
    8320:	97ffe8d4 	bl	2670 <sigaltstack@plt>
    8324:	35000220 	cbnz	w0, 8368 <fwp_main_thread+0xc8>
    8328:	4f000400 	movi	v0.4s, #0x0
    832c:	9104a3e0 	add	x0, sp, #0x128
    8330:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    8334:	913fc021 	add	x1, x1, #0xff0
    8338:	f90093e1 	str	x1, [sp, #288]
    833c:	52800082 	mov	w2, #0x4                   	// #4
    8340:	72a10002 	movk	w2, #0x800, lsl #16
    8344:	910483f6 	add	x22, sp, #0x120
    8348:	3d802000 	str	q0, [x0, #128]
    834c:	b901abe2 	str	w2, [sp, #424]
    8350:	ad000000 	stp	q0, q0, [x0]
    8354:	ad010000 	stp	q0, q0, [x0, #32]
    8358:	ad020000 	stp	q0, q0, [x0, #64]
    835c:	ad030000 	stp	q0, q0, [x0, #96]
    8360:	97ffe918 	bl	27c0 <sigemptyset@plt>
    8364:	34000100 	cbz	w0, 8384 <fwp_main_thread+0xe4>
    8368:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x490>
    836c:	91016000 	add	x0, x0, #0x58
    8370:	f90103f9 	str	x25, [sp, #512]
    8374:	f90107fa 	str	x26, [sp, #520]
    8378:	f9010bfb 	str	x27, [sp, #528]
    837c:	f9010ffc 	str	x28, [sp, #536]
    8380:	97ffeea0 	bl	3e00 <fwp_trap>
    8384:	aa1603e1 	mov	x1, x22
    8388:	d2800002 	mov	x2, #0x0                   	// #0
    838c:	52800160 	mov	w0, #0xb                   	// #11
    8390:	97ffe924 	bl	2820 <sigaction@plt>
    8394:	35fffea0 	cbnz	w0, 8368 <fwp_main_thread+0xc8>
    8398:	aa1603e1 	mov	x1, x22
    839c:	d2800002 	mov	x2, #0x0                   	// #0
    83a0:	528000e0 	mov	w0, #0x7                   	// #7
    83a4:	97ffe91f 	bl	2820 <sigaction@plt>
    83a8:	35fffe00 	cbnz	w0, 8368 <fwp_main_thread+0xc8>
    83ac:	b942e6e0 	ldr	w0, [x23, #740]
    83b0:	34000800 	cbz	w0, 84b0 <fwp_main_thread+0x210>
    83b4:	9100c296 	add	x22, x20, #0x30
    83b8:	f9400ad5 	ldr	x21, [x22, #16]
    83bc:	b40014f5 	cbz	x21, 8658 <fwp_main_thread+0x3b8>
    83c0:	910102b7 	add	x23, x21, #0x40
    83c4:	f90103f9 	str	x25, [sp, #512]
    83c8:	f90107fa 	str	x26, [sp, #520]
    83cc:	52800038 	mov	w24, #0x1                   	// #1
    83d0:	39414ab9 	ldrb	w25, [x21, #82]
    83d4:	39014ab8 	strb	w24, [x21, #82]
    83d8:	f94016a0 	ldr	x0, [x21, #40]
    83dc:	b4001380 	cbz	x0, 864c <fwp_main_thread+0x3ac>
    83e0:	f94032a1 	ldr	x1, [x21, #96]
    83e4:	394146a0 	ldrb	w0, [x21, #81]
    83e8:	b4000fa1 	cbz	x1, 85dc <fwp_main_thread+0x33c>
    83ec:	36000e60 	tbz	w0, #0, 85b8 <fwp_main_thread+0x318>
    83f0:	f9400ad3 	ldr	x19, [x22, #16]
    83f4:	f94022a0 	ldr	x0, [x21, #64]
    83f8:	39414a61 	ldrb	w1, [x19, #82]
    83fc:	37001181 	tbnz	w1, #0, 862c <fwp_main_thread+0x38c>
    8400:	f9403261 	ldr	x1, [x19, #96]
    8404:	a911fe77 	stp	x23, xzr, [x19, #280]
    8408:	f9009660 	str	x0, [x19, #296]
    840c:	b4000040 	cbz	x0, 8414 <fwp_main_thread+0x174>
    8410:	f9009013 	str	x19, [x0, #288]
    8414:	f90022b3 	str	x19, [x21, #64]
    8418:	b4000101 	cbz	x1, 8438 <fwp_main_thread+0x198>
    841c:	f9403ec0 	ldr	x0, [x22, #120]
    8420:	39015678 	strb	w24, [x19, #85]
    8424:	f9003661 	str	x1, [x19, #104]
    8428:	a910827f 	stp	xzr, x0, [x19, #264]
    842c:	b4000040 	cbz	x0, 8434 <fwp_main_thread+0x194>
    8430:	f9008413 	str	x19, [x0, #264]
    8434:	f9003ed3 	str	x19, [x22, #120]
    8438:	39015a7f 	strb	wzr, [x19, #86]
    843c:	97fff915 	bl	6890 <fwp_block>
    8440:	f9408e62 	ldr	x2, [x19, #280]
    8444:	b4000142 	cbz	x2, 846c <fwp_main_thread+0x1cc>
    8448:	a9520261 	ldp	x1, x0, [x19, #288]
    844c:	b4000fc1 	cbz	x1, 8644 <fwp_main_thread+0x3a4>
    8450:	f9009420 	str	x0, [x1, #296]
    8454:	f9409660 	ldr	x0, [x19, #296]
    8458:	b4000040 	cbz	x0, 8460 <fwp_main_thread+0x1c0>
    845c:	f9009001 	str	x1, [x0, #288]
    8460:	91080260 	add	x0, x19, #0x200
    8464:	f900967f 	str	xzr, [x19, #296]
    8468:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    846c:	39415660 	ldrb	w0, [x19, #85]
    8470:	3607fb40 	tbz	w0, #0, 83d8 <fwp_main_thread+0x138>
    8474:	a9508261 	ldp	x1, x0, [x19, #264]
    8478:	b4001f81 	cbz	x1, 8868 <fwp_main_thread+0x5c8>
    847c:	f9008820 	str	x0, [x1, #272]
    8480:	b4000040 	cbz	x0, 8488 <fwp_main_thread+0x1e8>
    8484:	f9008401 	str	x1, [x0, #264]
    8488:	91080260 	add	x0, x19, #0x200
    848c:	3901567f 	strb	wzr, [x19, #85]
    8490:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8494:	17ffffd1 	b	83d8 <fwp_main_thread+0x138>
    8498:	f0ffffc0 	adrp	x0, 3000 <fwp_segv+0x10>
    849c:	91241000 	add	x0, x0, #0x904
    84a0:	940009a8 	bl	ab40 <atexit>
    84a4:	17ffff91 	b	82e8 <fwp_main_thread+0x48>
    84a8:	97ffed72 	bl	3a70 <fwp_heap_init>
    84ac:	17ffff8c 	b	82dc <fwp_main_thread+0x3c>
    84b0:	f9415ae2 	ldr	x2, [x23, #688]
    84b4:	f90103f9 	str	x25, [sp, #512]
    84b8:	f90107fa 	str	x26, [sp, #520]
    84bc:	910163e3 	add	x3, sp, #0x58
    84c0:	f9010bfb 	str	x27, [sp, #528]
    84c4:	b0ffffe0 	adrp	x0, 5000 <w123+0x40>
    84c8:	f9010ffc 	str	x28, [sp, #536]
    84cc:	91330000 	add	x0, x0, #0xcc0
    84d0:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    84d4:	9114c27a 	add	x26, x19, #0x530
    84d8:	913b4021 	add	x1, x1, #0xed0
    84dc:	d280001b 	mov	x27, #0x0                   	// #0
    84e0:	d280401c 	mov	x28, #0x200                 	// #512
    84e4:	a9000fff 	stp	xzr, x3, [sp]
    84e8:	a90587e2 	stp	x2, x1, [sp, #88]
    84ec:	f90037f8 	str	x24, [sp, #104]
    84f0:	f90053ff 	str	xzr, [sp, #160]
    84f4:	a90b03ff 	stp	xzr, x0, [sp, #176]
    84f8:	f9015ae3 	str	x3, [x23, #688]
    84fc:	14000012 	b	8544 <fwp_main_thread+0x2a4>
    8500:	7100045f 	cmp	w2, #0x1
    8504:	540001a1 	b.ne	8538 <fwp_main_thread+0x298>  // b.any
    8508:	29430002 	ldp	w2, w0, [x0, #24]
    850c:	92403c21 	and	x1, x1, #0xffff
    8510:	9b027c21 	mul	x1, x1, x2
    8514:	d360fc21 	lsr	x1, x1, #32
    8518:	eb00003f 	cmp	x1, x0
    851c:	540000e2 	b.cs	8538 <fwp_main_thread+0x298>  // b.hs, b.nlast
    8520:	8b010318 	add	x24, x24, x1
    8524:	39400300 	ldrb	w0, [x24]
    8528:	7103fc1f 	cmp	w0, #0xff
    852c:	54003a80 	b.eq	8c7c <fwp_main_thread+0x9dc>  // b.none
    8530:	52800020 	mov	w0, #0x1                   	// #1
    8534:	39000300 	strb	w0, [x24]
    8538:	a90a7ffb 	stp	x27, xzr, [sp, #160]
    853c:	aa1902f7 	orr	x23, x23, x25
    8540:	b4001997 	cbz	x23, 8870 <fwp_main_thread+0x5d0>
    8544:	f94003e0 	ldr	x0, [sp]
    8548:	f1000797 	subs	x23, x28, #0x1
    854c:	aa1603e1 	mov	x1, x22
    8550:	f90057f7 	str	x23, [sp, #168]
    8554:	da1f0019 	sbc	x25, x0, xzr
    8558:	52800020 	mov	w0, #0x1                   	// #1
    855c:	f90003f9 	str	x25, [sp]
    8560:	aa1703fc 	mov	x28, x23
    8564:	a9126ff7 	stp	x23, x27, [sp, #288]
    8568:	97fff1e3 	bl	4cf4 <fwp_data.part.0.constprop.0>
    856c:	aa0003fb 	mov	x27, x0
    8570:	f949db41 	ldr	x1, [x26, #5040]
    8574:	f949ef40 	ldr	x0, [x26, #5080]
    8578:	cb010361 	sub	x1, x27, x1
    857c:	eb00403f 	cmp	x1, x0, lsl #16
    8580:	54fffdc2 	b.cs	8538 <fwp_main_thread+0x298>  // b.hs, b.nlast
    8584:	d350fc22 	lsr	x2, x1, #16
    8588:	f949ff46 	ldr	x6, [x26, #5112]
    858c:	8b020842 	add	x2, x2, x2, lsl #2
    8590:	d37df042 	lsl	x2, x2, #3
    8594:	8b0200c0 	add	x0, x6, x2
    8598:	f9401018 	ldr	x24, [x0, #32]
    859c:	b4fffcf8 	cbz	x24, 8538 <fwp_main_thread+0x298>
    85a0:	386268c2 	ldrb	w2, [x6, x2]
    85a4:	7100085f 	cmp	w2, #0x2
    85a8:	54fffac1 	b.ne	8500 <fwp_main_thread+0x260>  // b.any
    85ac:	72003c3f 	tst	w1, #0xffff
    85b0:	54fffc41 	b.ne	8538 <fwp_main_thread+0x298>  // b.any
    85b4:	17ffffdc 	b	8524 <fwp_main_thread+0x284>
    85b8:	97fff032 	bl	4680 <fwp_now_ns>
    85bc:	f94032a1 	ldr	x1, [x21, #96]
    85c0:	eb01001f 	cmp	x0, x1
    85c4:	540000ab 	b.lt	85d8 <fwp_main_thread+0x338>  // b.tstop
    85c8:	394142a0 	ldrb	w0, [x21, #80]
    85cc:	37000060 	tbnz	w0, #0, 85d8 <fwp_main_thread+0x338>
    85d0:	aa1503e0 	mov	x0, x21
    85d4:	97ffeb87 	bl	33f0 <fwp_cancel_tree.part.0>
    85d8:	394146a0 	ldrb	w0, [x21, #81]
    85dc:	f9400ad3 	ldr	x19, [x22, #16]
    85e0:	39414a62 	ldrb	w2, [x19, #82]
    85e4:	3707f060 	tbnz	w0, #0, 83f0 <fwp_main_thread+0x150>
    85e8:	f94032a1 	ldr	x1, [x21, #96]
    85ec:	370001c2 	tbnz	w2, #0, 8624 <fwp_main_thread+0x384>
    85f0:	f9403260 	ldr	x0, [x19, #96]
    85f4:	b4000180 	cbz	x0, 8624 <fwp_main_thread+0x384>
    85f8:	b4000061 	cbz	x1, 8604 <fwp_main_thread+0x364>
    85fc:	eb01001f 	cmp	x0, x1
    8600:	9a81d000 	csel	x0, x0, x1, le
    8604:	f94022a1 	ldr	x1, [x21, #64]
    8608:	a911fe77 	stp	x23, xzr, [x19, #280]
    860c:	f9009661 	str	x1, [x19, #296]
    8610:	b40033c1 	cbz	x1, 8c88 <fwp_main_thread+0x9e8>
    8614:	f9009033 	str	x19, [x1, #288]
    8618:	aa0003e1 	mov	x1, x0
    861c:	f90022b3 	str	x19, [x21, #64]
    8620:	17ffff7f 	b	841c <fwp_main_thread+0x17c>
    8624:	f94022a0 	ldr	x0, [x21, #64]
    8628:	17ffff77 	b	8404 <fwp_main_thread+0x164>
    862c:	a911fe77 	stp	x23, xzr, [x19, #280]
    8630:	f9009660 	str	x0, [x19, #296]
    8634:	b4000040 	cbz	x0, 863c <fwp_main_thread+0x39c>
    8638:	f9009013 	str	x19, [x0, #288]
    863c:	f90022b3 	str	x19, [x21, #64]
    8640:	17ffff7e 	b	8438 <fwp_main_thread+0x198>
    8644:	f9000040 	str	x0, [x2]
    8648:	17ffff84 	b	8458 <fwp_main_thread+0x1b8>
    864c:	f94107fa 	ldr	x26, [sp, #520]
    8650:	39014ab9 	strb	w25, [x21, #82]
    8654:	f94103f9 	ldr	x25, [sp, #512]
    8658:	9100c293 	add	x19, x20, #0x30
    865c:	f9416660 	ldr	x0, [x19, #712]
    8660:	b5000060 	cbnz	x0, 866c <fwp_main_thread+0x3cc>
    8664:	f9416e60 	ldr	x0, [x19, #728]
    8668:	b4004780 	cbz	x0, 8f58 <fwp_main_thread+0xcb8>
    866c:	9100c280 	add	x0, x20, #0x30
    8670:	f9400800 	ldr	x0, [x0, #16]
    8674:	9100c281 	add	x1, x20, #0x30
    8678:	f9418026 	ldr	x6, [x1, #768]
    867c:	b902f83f 	str	wzr, [x1, #760]
    8680:	eb0000df 	cmp	x6, x0
    8684:	5400ed61 	b.ne	a430 <fwp_main_thread+0x2190>  // b.any
    8688:	b40003e0 	cbz	x0, 8704 <fwp_main_thread+0x464>
    868c:	f9415025 	ldr	x5, [x1, #672]
    8690:	52800021 	mov	w1, #0x1                   	// #1
    8694:	39014801 	strb	w1, [x0, #82]
    8698:	b4000365 	cbz	x5, 8704 <fwp_main_thread+0x464>
    869c:	d503201f 	nop
    86a0:	394140a0 	ldrb	w0, [x5, #80]
    86a4:	37000060 	tbnz	w0, #0, 86b0 <fwp_main_thread+0x410>
    86a8:	aa0503e0 	mov	x0, x5
    86ac:	97ffeb51 	bl	33f0 <fwp_cancel_tree.part.0>
    86b0:	f9409ca5 	ldr	x5, [x5, #312]
    86b4:	b5ffff65 	cbnz	x5, 86a0 <fwp_main_thread+0x400>
    86b8:	9100c293 	add	x19, x20, #0x30
    86bc:	52800035 	mov	w21, #0x1                   	// #1
    86c0:	f94028c0 	ldr	x0, [x6, #80]
    86c4:	f2001c1f 	tst	x0, #0xff000000ff
    86c8:	540000e1 	b.ne	86e4 <fwp_main_thread+0x444>  // b.any
    86cc:	f9401660 	ldr	x0, [x19, #40]
    86d0:	390150d5 	strb	w21, [x6, #84]
    86d4:	f90080df 	str	xzr, [x6, #256]
    86d8:	b4000120 	cbz	x0, 86fc <fwp_main_thread+0x45c>
    86dc:	f9008006 	str	x6, [x0, #256]
    86e0:	f9001666 	str	x6, [x19, #40]
    86e4:	97fff86b 	bl	6890 <fwp_block>
    86e8:	97fff7f2 	bl	66b0 <fwp_free_zombie>
    86ec:	f9415260 	ldr	x0, [x19, #672]
    86f0:	b40000a0 	cbz	x0, 8704 <fwp_main_thread+0x464>
    86f4:	f9418266 	ldr	x6, [x19, #768]
    86f8:	17fffff2 	b	86c0 <fwp_main_thread+0x420>
    86fc:	f9001a66 	str	x6, [x19, #48]
    8700:	17fffff8 	b	86e0 <fwp_main_thread+0x440>
    8704:	9100c295 	add	x21, x20, #0x30
    8708:	97fff7ea 	bl	66b0 <fwp_free_zombie>
    870c:	f9401aa0 	ldr	x0, [x21, #48]
    8710:	b500e900 	cbnz	x0, a430 <fwp_main_thread+0x2190>
    8714:	f9403ea0 	ldr	x0, [x21, #120]
    8718:	b500e8c0 	cbnz	x0, a430 <fwp_main_thread+0x2190>
    871c:	b9409ab3 	ldr	w19, [x21, #152]
    8720:	340001f3 	cbz	w19, 875c <fwp_main_thread+0x4bc>
    8724:	93407e76 	sxtw	x22, w19
    8728:	51000673 	sub	w19, w19, #0x1
    872c:	d1000ad6 	sub	x22, x22, #0x2
    8730:	910282b7 	add	x23, x21, #0xa0
    8734:	cb3342d6 	sub	x22, x22, w19, uxtw
    8738:	93407e73 	sxtw	x19, w19
    873c:	d503201f 	nop
    8740:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    8744:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8748:	b9009ab3 	str	w19, [x21, #152]
    874c:	d1000673 	sub	x19, x19, #0x1
    8750:	97ffe874 	bl	2920 <munmap@plt>
    8754:	eb16027f 	cmp	x19, x22
    8758:	54ffff41 	b.ne	8740 <fwp_main_thread+0x4a0>  // b.any
    875c:	900000d7 	adrp	x23, 20000 <__data_start>
    8760:	910042e0 	add	x0, x23, #0x10
    8764:	b9400800 	ldr	w0, [x0, #8]
    8768:	37f80040 	tbnz	w0, #31, 8770 <fwp_main_thread+0x4d0>
    876c:	97ffe829 	bl	2810 <close@plt>
    8770:	9100c295 	add	x21, x20, #0x30
    8774:	910042f7 	add	x23, x23, #0x10
    8778:	12800001 	mov	w1, #0xffffffff            	// #-1
    877c:	f9418aa0 	ldr	x0, [x21, #784]
    8780:	b9000ae1 	str	w1, [x23, #8]
    8784:	f94186a1 	ldr	x1, [x21, #776]
    8788:	b40001c0 	cbz	x0, 87c0 <fwp_main_thread+0x520>
    878c:	d2800013 	mov	x19, #0x0                   	// #0
    8790:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    8794:	b40000e0 	cbz	x0, 87b0 <fwp_main_thread+0x510>
    8798:	f9400001 	ldr	x1, [x0]
    879c:	b500e4a1 	cbnz	x1, a430 <fwp_main_thread+0x2190>
    87a0:	f9400401 	ldr	x1, [x0, #8]
    87a4:	b500e461 	cbnz	x1, a430 <fwp_main_thread+0x2190>
    87a8:	97ffee52 	bl	40f0 <fwp_mem_free>
    87ac:	f94186a1 	ldr	x1, [x21, #776]
    87b0:	91000673 	add	x19, x19, #0x1
    87b4:	f9418aa0 	ldr	x0, [x21, #784]
    87b8:	eb00027f 	cmp	x19, x0
    87bc:	54fffea3 	b.cc	8790 <fwp_main_thread+0x4f0>  // b.lo, b.ul, b.last
    87c0:	aa0103e0 	mov	x0, x1
    87c4:	97ffee4b 	bl	40f0 <fwp_mem_free>
    87c8:	9100c280 	add	x0, x20, #0x30
    87cc:	f9418013 	ldr	x19, [x0, #768]
    87d0:	f901841f 	str	xzr, [x0, #776]
    87d4:	f901881f 	str	xzr, [x0, #784]
    87d8:	b40001f3 	cbz	x19, 8814 <fwp_main_thread+0x574>
    87dc:	f9401661 	ldr	x1, [x19, #40]
    87e0:	b500e281 	cbnz	x1, a430 <fwp_main_thread+0x2190>
    87e4:	f9405661 	ldr	x1, [x19, #168]
    87e8:	b500e241 	cbnz	x1, a430 <fwp_main_thread+0x2190>
    87ec:	f9416401 	ldr	x1, [x0, #712]
    87f0:	b500e201 	cbnz	x1, a430 <fwp_main_thread+0x2190>
    87f4:	f9416c00 	ldr	x0, [x0, #728]
    87f8:	b500e1c0 	cbnz	x0, a430 <fwp_main_thread+0x2190>
    87fc:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8800:	90000140 	adrp	x0, 30000 <alt.5+0xfcb0>
    8804:	910d4000 	add	x0, x0, #0x350
    8808:	97ffe7f2 	bl	27d0 <memset@plt>
    880c:	aa1303e0 	mov	x0, x19
    8810:	97ffee38 	bl	40f0 <fwp_mem_free>
    8814:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8818:	f947ec00 	ldr	x0, [x0, #4056]
    881c:	9100c294 	add	x20, x20, #0x30
    8820:	f9400000 	ldr	x0, [x0]
    8824:	f9000a9f 	str	xzr, [x20, #16]
    8828:	f901829f 	str	xzr, [x20, #768]
    882c:	97ffe841 	bl	2930 <fflush@plt>
    8830:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc88>
    8834:	f947f400 	ldr	x0, [x0, #4072]
    8838:	f940dfe2 	ldr	x2, [sp, #440]
    883c:	f9400001 	ldr	x1, [x0]
    8840:	eb010042 	subs	x2, x2, x1
    8844:	d2800001 	mov	x1, #0x0                   	// #0
    8848:	5400d421 	b.ne	a2cc <fwp_main_thread+0x202c>  // b.any
    884c:	910703ff 	add	sp, sp, #0x1c0
    8850:	d2800000 	mov	x0, #0x0                   	// #0
    8854:	a94153f3 	ldp	x19, x20, [sp, #16]
    8858:	a9425bf5 	ldp	x21, x22, [sp, #32]
    885c:	a94363f7 	ldp	x23, x24, [sp, #48]
    8860:	a8c67bfd 	ldp	x29, x30, [sp], #96
    8864:	d65f03c0 	ret
    8868:	f9003ec0 	str	x0, [x22, #120]
    886c:	17ffff05 	b	8480 <fwp_main_thread+0x1e0>
    8870:	9100c282 	add	x2, x20, #0x30
    8874:	f90053ff 	str	xzr, [sp, #160]
    8878:	f94007e1 	ldr	x1, [sp, #8]
    887c:	f9415840 	ldr	x0, [x2, #688]
    8880:	eb01001f 	cmp	x0, x1
    8884:	5400dde1 	b.ne	a440 <fwp_main_thread+0x21a0>  // b.any
    8888:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x490>
    888c:	9103c3e1 	add	x1, sp, #0xf0
    8890:	f9402fe3 	ldr	x3, [sp, #88]
    8894:	f9015843 	str	x3, [x2, #688]
    8898:	3dc22000 	ldr	q0, [x0, #2176]
    889c:	52800020 	mov	w0, #0x1                   	// #1
    88a0:	3d803fe0 	str	q0, [sp, #240]
    88a4:	97fff114 	bl	4cf4 <fwp_data.part.0.constprop.0>
    88a8:	9114c263 	add	x3, x19, #0x530
    88ac:	aa0003f8 	mov	x24, x0
    88b0:	f949d861 	ldr	x1, [x3, #5040]
    88b4:	f949ec60 	ldr	x0, [x3, #5080]
    88b8:	cb010301 	sub	x1, x24, x1
    88bc:	eb00403f 	cmp	x1, x0, lsl #16
    88c0:	54000322 	b.cs	8924 <fwp_main_thread+0x684>  // b.hs, b.nlast
    88c4:	d350fc22 	lsr	x2, x1, #16
    88c8:	f949fc65 	ldr	x5, [x3, #5112]
    88cc:	8b020842 	add	x2, x2, x2, lsl #2
    88d0:	d37df042 	lsl	x2, x2, #3
    88d4:	8b0200a3 	add	x3, x5, x2
    88d8:	f9401077 	ldr	x23, [x3, #32]
    88dc:	b4000257 	cbz	x23, 8924 <fwp_main_thread+0x684>
    88e0:	386268a0 	ldrb	w0, [x5, x2]
    88e4:	7100081f 	cmp	w0, #0x2
    88e8:	54001d60 	b.eq	8c94 <fwp_main_thread+0x9f4>  // b.none
    88ec:	7100041f 	cmp	w0, #0x1
    88f0:	540001a1 	b.ne	8924 <fwp_main_thread+0x684>  // b.any
    88f4:	29430062 	ldp	w2, w0, [x3, #24]
    88f8:	92403c21 	and	x1, x1, #0xffff
    88fc:	9b027c21 	mul	x1, x1, x2
    8900:	d360fc21 	lsr	x1, x1, #32
    8904:	eb00003f 	cmp	x1, x0
    8908:	540000e2 	b.cs	8924 <fwp_main_thread+0x684>  // b.hs, b.nlast
    890c:	8b0102f7 	add	x23, x23, x1
    8910:	394002e0 	ldrb	w0, [x23]
    8914:	7103fc1f 	cmp	w0, #0xff
    8918:	54005ee0 	b.eq	94f4 <fwp_main_thread+0x1254>  // b.none
    891c:	52800020 	mov	w0, #0x1                   	// #1
    8920:	390002e0 	strb	w0, [x23]
    8924:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8928:	910443e1 	add	x1, sp, #0x110
    892c:	52800020 	mov	w0, #0x1                   	// #1
    8930:	a91163e2 	stp	x2, x24, [sp, #272]
    8934:	97fff0f0 	bl	4cf4 <fwp_data.part.0.constprop.0>
    8938:	9114c263 	add	x3, x19, #0x530
    893c:	aa0003f8 	mov	x24, x0
    8940:	f949d861 	ldr	x1, [x3, #5040]
    8944:	f949ec60 	ldr	x0, [x3, #5080]
    8948:	cb010301 	sub	x1, x24, x1
    894c:	eb00403f 	cmp	x1, x0, lsl #16
    8950:	54000322 	b.cs	89b4 <fwp_main_thread+0x714>  // b.hs, b.nlast
    8954:	d350fc22 	lsr	x2, x1, #16
    8958:	f949fc65 	ldr	x5, [x3, #5112]
    895c:	8b020842 	add	x2, x2, x2, lsl #2
    8960:	d37df042 	lsl	x2, x2, #3
    8964:	8b0200a3 	add	x3, x5, x2
    8968:	f9401077 	ldr	x23, [x3, #32]
    896c:	b4000257 	cbz	x23, 89b4 <fwp_main_thread+0x714>
    8970:	386268a0 	ldrb	w0, [x5, x2]
    8974:	7100081f 	cmp	w0, #0x2
    8978:	540019a0 	b.eq	8cac <fwp_main_thread+0xa0c>  // b.none
    897c:	7100041f 	cmp	w0, #0x1
    8980:	540001a1 	b.ne	89b4 <fwp_main_thread+0x714>  // b.any
    8984:	29430062 	ldp	w2, w0, [x3, #24]
    8988:	92403c21 	and	x1, x1, #0xffff
    898c:	9b027c21 	mul	x1, x1, x2
    8990:	d360fc21 	lsr	x1, x1, #32
    8994:	eb00003f 	cmp	x1, x0
    8998:	540000e2 	b.cs	89b4 <fwp_main_thread+0x714>  // b.hs, b.nlast
    899c:	8b0102f7 	add	x23, x23, x1
    89a0:	394002e0 	ldrb	w0, [x23]
    89a4:	7103fc1f 	cmp	w0, #0xff
    89a8:	54005ac0 	b.eq	9500 <fwp_main_thread+0x1260>  // b.none
    89ac:	52800020 	mov	w0, #0x1                   	// #1
    89b0:	390002e0 	strb	w0, [x23]
    89b4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    89b8:	910403e1 	add	x1, sp, #0x100
    89bc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    89c0:	52800020 	mov	w0, #0x1                   	// #1
    89c4:	a91063e2 	stp	x2, x24, [sp, #256]
    89c8:	97fff0cb 	bl	4cf4 <fwp_data.part.0.constprop.0>
    89cc:	9114c262 	add	x2, x19, #0x530
    89d0:	aa0003f8 	mov	x24, x0
    89d4:	f949d841 	ldr	x1, [x2, #5040]
    89d8:	f949ec40 	ldr	x0, [x2, #5080]
    89dc:	cb010301 	sub	x1, x24, x1
    89e0:	eb00403f 	cmp	x1, x0, lsl #16
    89e4:	54000322 	b.cs	8a48 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    89e8:	d350fc20 	lsr	x0, x1, #16
    89ec:	f949fc43 	ldr	x3, [x2, #5112]
    89f0:	8b000800 	add	x0, x0, x0, lsl #2
    89f4:	d37df002 	lsl	x2, x0, #3
    89f8:	8b020060 	add	x0, x3, x2
    89fc:	f9401017 	ldr	x23, [x0, #32]
    8a00:	b4000257 	cbz	x23, 8a48 <fwp_main_thread+0x7a8>
    8a04:	38626862 	ldrb	w2, [x3, x2]
    8a08:	7100085f 	cmp	w2, #0x2
    8a0c:	54001560 	b.eq	8cb8 <fwp_main_thread+0xa18>  // b.none
    8a10:	7100045f 	cmp	w2, #0x1
    8a14:	540001a1 	b.ne	8a48 <fwp_main_thread+0x7a8>  // b.any
    8a18:	29430002 	ldp	w2, w0, [x0, #24]
    8a1c:	92403c21 	and	x1, x1, #0xffff
    8a20:	9b027c21 	mul	x1, x1, x2
    8a24:	d360fc21 	lsr	x1, x1, #32
    8a28:	eb00003f 	cmp	x1, x0
    8a2c:	540000e2 	b.cs	8a48 <fwp_main_thread+0x7a8>  // b.hs, b.nlast
    8a30:	8b0102f7 	add	x23, x23, x1
    8a34:	394002e0 	ldrb	w0, [x23]
    8a38:	7103fc1f 	cmp	w0, #0xff
    8a3c:	54005680 	b.eq	950c <fwp_main_thread+0x126c>  // b.none
    8a40:	52800020 	mov	w0, #0x1                   	// #1
    8a44:	390002e0 	strb	w0, [x23]
    8a48:	b40040bb 	cbz	x27, 925c <fwp_main_thread+0xfbc>
    8a4c:	d0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0x5c>
    8a50:	91070000 	add	x0, x0, #0x1c0
    8a54:	900000d7 	adrp	x23, 20000 <__data_start>
    8a58:	9114c279 	add	x25, x19, #0x530
    8a5c:	910042f7 	add	x23, x23, #0x10
    8a60:	9100c29a 	add	x26, x20, #0x30
    8a64:	a9016fe0 	stp	x0, x27, [sp, #16]
    8a68:	910143e0 	add	x0, sp, #0x50
    8a6c:	f90003e0 	str	x0, [sp]
    8a70:	9101c3e0 	add	x0, sp, #0x70
    8a74:	f90007e0 	str	x0, [sp, #8]
    8a78:	f949ef25 	ldr	x5, [x25, #5080]
    8a7c:	f949db21 	ldr	x1, [x25, #5040]
    8a80:	d370bca5 	lsl	x5, x5, #16
    8a84:	cb010303 	sub	x3, x24, x1
    8a88:	eb05007f 	cmp	x3, x5
    8a8c:	540003e2 	b.cs	8b08 <fwp_main_thread+0x868>  // b.hs, b.nlast
    8a90:	d350fc60 	lsr	x0, x3, #16
    8a94:	f949ff27 	ldr	x7, [x25, #5112]
    8a98:	8b000800 	add	x0, x0, x0, lsl #2
    8a9c:	d37df002 	lsl	x2, x0, #3
    8aa0:	8b0200e6 	add	x6, x7, x2
    8aa4:	f94010c0 	ldr	x0, [x6, #32]
    8aa8:	b4000300 	cbz	x0, 8b08 <fwp_main_thread+0x868>
    8aac:	386268e2 	ldrb	w2, [x7, x2]
    8ab0:	7100085f 	cmp	w2, #0x2
    8ab4:	54001080 	b.eq	8cc4 <fwp_main_thread+0xa24>  // b.none
    8ab8:	7100045f 	cmp	w2, #0x1
    8abc:	54000261 	b.ne	8b08 <fwp_main_thread+0x868>  // b.any
    8ac0:	92403c62 	and	x2, x3, #0xffff
    8ac4:	29430cc7 	ldp	w7, w3, [x6, #24]
    8ac8:	9b077c42 	mul	x2, x2, x7
    8acc:	d360fc42 	lsr	x2, x2, #32
    8ad0:	eb03005f 	cmp	x2, x3
    8ad4:	540001a2 	b.cs	8b08 <fwp_main_thread+0x868>  // b.hs, b.nlast
    8ad8:	8b020000 	add	x0, x0, x2
    8adc:	39400002 	ldrb	w2, [x0]
    8ae0:	34000142 	cbz	w2, 8b08 <fwp_main_thread+0x868>
    8ae4:	7103f45f 	cmp	w2, #0xfd
    8ae8:	54005688 	b.hi	95b8 <fwp_main_thread+0x1318>  // b.pmore
    8aec:	9114c261 	add	x1, x19, #0x530
    8af0:	11000442 	add	w2, w2, #0x1
    8af4:	39000002 	strb	w2, [x0]
    8af8:	aa0103e0 	mov	x0, x1
    8afc:	f949d821 	ldr	x1, [x1, #5040]
    8b00:	f949ec05 	ldr	x5, [x0, #5080]
    8b04:	d370bca5 	lsl	x5, x5, #16
    8b08:	f9415b40 	ldr	x0, [x26, #688]
    8b0c:	f9003be0 	str	x0, [sp, #112]
    8b10:	f9400be0 	ldr	x0, [sp, #16]
    8b14:	f9003fe0 	str	x0, [sp, #120]
    8b18:	f94003e0 	ldr	x0, [sp]
    8b1c:	f90043e0 	str	x0, [sp, #128]
    8b20:	f94007e0 	ldr	x0, [sp, #8]
    8b24:	12800002 	mov	w2, #0xffffffff            	// #-1
    8b28:	cb0102e1 	sub	x1, x23, x1
    8b2c:	b90053e2 	str	w2, [sp, #80]
    8b30:	f9015b40 	str	x0, [x26, #688]
    8b34:	eb05003f 	cmp	x1, x5
    8b38:	54000782 	b.cs	8c28 <fwp_main_thread+0x988>  // b.hs, b.nlast
    8b3c:	9114c262 	add	x2, x19, #0x530
    8b40:	d350fc20 	lsr	x0, x1, #16
    8b44:	8b000800 	add	x0, x0, x0, lsl #2
    8b48:	f949fc45 	ldr	x5, [x2, #5112]
    8b4c:	d37df003 	lsl	x3, x0, #3
    8b50:	8b0300a2 	add	x2, x5, x3
    8b54:	f940105c 	ldr	x28, [x2, #32]
    8b58:	b400069c 	cbz	x28, 8c28 <fwp_main_thread+0x988>
    8b5c:	386368a0 	ldrb	w0, [x5, x3]
    8b60:	7100081f 	cmp	w0, #0x2
    8b64:	54000b60 	b.eq	8cd0 <fwp_main_thread+0xa30>  // b.none
    8b68:	7100041f 	cmp	w0, #0x1
    8b6c:	540005e1 	b.ne	8c28 <fwp_main_thread+0x988>  // b.any
    8b70:	29430c45 	ldp	w5, w3, [x2, #24]
    8b74:	92403c20 	and	x0, x1, #0xffff
    8b78:	9b057c00 	mul	x0, x0, x5
    8b7c:	d360fc00 	lsr	x0, x0, #32
    8b80:	eb03001f 	cmp	x0, x3
    8b84:	54000282 	b.cs	8bd4 <fwp_main_thread+0x934>  // b.hs, b.nlast
    8b88:	8b000380 	add	x0, x28, x0
    8b8c:	39400003 	ldrb	w3, [x0]
    8b90:	34000223 	cbz	w3, 8bd4 <fwp_main_thread+0x934>
    8b94:	7103f47f 	cmp	w3, #0xfd
    8b98:	54005548 	b.hi	9640 <fwp_main_thread+0x13a0>  // b.pmore
    8b9c:	11000463 	add	w3, w3, #0x1
    8ba0:	39000003 	strb	w3, [x0]
    8ba4:	9114c260 	add	x0, x19, #0x530
    8ba8:	f949d801 	ldr	x1, [x0, #5040]
    8bac:	f949ec02 	ldr	x2, [x0, #5080]
    8bb0:	cb0102e1 	sub	x1, x23, x1
    8bb4:	eb02403f 	cmp	x1, x2, lsl #16
    8bb8:	54000382 	b.cs	8c28 <fwp_main_thread+0x988>  // b.hs, b.nlast
    8bbc:	f949fc02 	ldr	x2, [x0, #5112]
    8bc0:	d350fc20 	lsr	x0, x1, #16
    8bc4:	8b000800 	add	x0, x0, x0, lsl #2
    8bc8:	8b000c42 	add	x2, x2, x0, lsl #3
    8bcc:	f940105c 	ldr	x28, [x2, #32]
    8bd0:	b40002dc 	cbz	x28, 8c28 <fwp_main_thread+0x988>
    8bd4:	39400040 	ldrb	w0, [x2]
    8bd8:	7100081f 	cmp	w0, #0x2
    8bdc:	54000820 	b.eq	8ce0 <fwp_main_thread+0xa40>  // b.none
    8be0:	7100041f 	cmp	w0, #0x1
    8be4:	54000221 	b.ne	8c28 <fwp_main_thread+0x988>  // b.any
    8be8:	29430043 	ldp	w3, w0, [x2, #24]
    8bec:	92403c21 	and	x1, x1, #0xffff
    8bf0:	9b037c21 	mul	x1, x1, x3
    8bf4:	d360fc21 	lsr	x1, x1, #32
    8bf8:	eb00003f 	cmp	x1, x0
    8bfc:	54000162 	b.cs	8c28 <fwp_main_thread+0x988>  // b.hs, b.nlast
    8c00:	8b01039c 	add	x28, x28, x1
    8c04:	39400381 	ldrb	w1, [x28]
    8c08:	34000101 	cbz	w1, 8c28 <fwp_main_thread+0x988>
    8c0c:	7100043f 	cmp	w1, #0x1
    8c10:	54000260 	b.eq	8c5c <fwp_main_thread+0x9bc>  // b.none
    8c14:	7103fc3f 	cmp	w1, #0xff
    8c18:	54004dc0 	b.eq	95d0 <fwp_main_thread+0x1330>  // b.none
    8c1c:	51000421 	sub	w1, w1, #0x1
    8c20:	39000381 	strb	w1, [x28]
    8c24:	d503201f 	nop
    8c28:	b4004638 	cbz	x24, 94ec <fwp_main_thread+0x124c>
    8c2c:	aa1803e0 	mov	x0, x24
    8c30:	d2800001 	mov	x1, #0x0                   	// #0
    8c34:	d503201f 	nop
    8c38:	f9400800 	ldr	x0, [x0, #16]
    8c3c:	91000421 	add	x1, x1, #0x1
    8c40:	b5ffffc0 	cbnz	x0, 8c38 <fwp_main_thread+0x998>
    8c44:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8c48:	eb00003f 	cmp	x1, x0
    8c4c:	54000509 	b.ls	8cec <fwp_main_thread+0xa4c>  // b.plast
    8c50:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x490>
    8c54:	91020000 	add	x0, x0, #0x80
    8c58:	97ffec6a 	bl	3e00 <fwp_trap>
    8c5c:	d53bd040 	mrs	x0, tpidr_el0
    8c60:	91400000 	add	x0, x0, #0x0, lsl #12
    8c64:	91004000 	add	x0, x0, #0x10
    8c68:	f9400000 	ldr	x0, [x0]
    8c6c:	b40001a0 	cbz	x0, 8ca0 <fwp_main_thread+0xa00>
    8c70:	aa1703e1 	mov	x1, x23
    8c74:	97ffeddf 	bl	43f0 <fwp_closure_drop_push>
    8c78:	17ffffec 	b	8c28 <fwp_main_thread+0x988>
    8c7c:	aa1803e0 	mov	x0, x24
    8c80:	97ffec80 	bl	3e80 <fwp_rc_forget_slot.part.0>
    8c84:	17fffe2b 	b	8530 <fwp_main_thread+0x290>
    8c88:	aa0003e1 	mov	x1, x0
    8c8c:	f90022b3 	str	x19, [x21, #64]
    8c90:	17fffde3 	b	841c <fwp_main_thread+0x17c>
    8c94:	72003c3f 	tst	w1, #0xffff
    8c98:	54ffe461 	b.ne	8924 <fwp_main_thread+0x684>  // b.any
    8c9c:	17ffff1d 	b	8910 <fwp_main_thread+0x670>
    8ca0:	aa1703e0 	mov	x0, x23
    8ca4:	97ffee18 	bl	4504 <fwp_closure_drop.part.0>
    8ca8:	17ffffe0 	b	8c28 <fwp_main_thread+0x988>
    8cac:	72003c3f 	tst	w1, #0xffff
    8cb0:	54ffe821 	b.ne	89b4 <fwp_main_thread+0x714>  // b.any
    8cb4:	17ffff3b 	b	89a0 <fwp_main_thread+0x700>
    8cb8:	72003c3f 	tst	w1, #0xffff
    8cbc:	54ffec61 	b.ne	8a48 <fwp_main_thread+0x7a8>  // b.any
    8cc0:	17ffff5d 	b	8a34 <fwp_main_thread+0x794>
    8cc4:	72003c7f 	tst	w3, #0xffff
    8cc8:	54fff201 	b.ne	8b08 <fwp_main_thread+0x868>  // b.any
    8ccc:	17ffff84 	b	8adc <fwp_main_thread+0x83c>
    8cd0:	72003c3f 	tst	w1, #0xffff
    8cd4:	54fff801 	b.ne	8bd4 <fwp_main_thread+0x934>  // b.any
    8cd8:	aa1c03e0 	mov	x0, x28
    8cdc:	17ffffac 	b	8b8c <fwp_main_thread+0x8ec>
    8ce0:	72003c3f 	tst	w1, #0xffff
    8ce4:	54fffa21 	b.ne	8c28 <fwp_main_thread+0x988>  // b.any
    8ce8:	17ffffc7 	b	8c04 <fwp_main_thread+0x964>
    8cec:	aa0103fc 	mov	x28, x1
    8cf0:	9100c281 	add	x1, x20, #0x30
    8cf4:	b942e820 	ldr	w0, [x1, #744]
    8cf8:	34002cc0 	cbz	w0, 9290 <fwp_main_thread+0xff0>
    8cfc:	9100c280 	add	x0, x20, #0x30
    8d00:	f9403803 	ldr	x3, [x0, #112]
    8d04:	f9404401 	ldr	x1, [x0, #136]
    8d08:	eb03003f 	cmp	x1, x3
    8d0c:	54000fea 	b.ge	8f08 <fwp_main_thread+0xc68>  // b.tcont
    8d10:	8b010420 	add	x0, x1, x1, lsl #1
    8d14:	528fffc5 	mov	w5, #0x7ffe                	// #32766
    8d18:	f9401a82 	ldr	x2, [x20, #48]
    8d1c:	d37ef400 	lsl	x0, x0, #2
    8d20:	cb010000 	sub	x0, x0, x1
    8d24:	8b000c40 	add	x0, x2, x0, lsl #3
    8d28:	b9400402 	ldr	w2, [x0, #4]
    8d2c:	35000082 	cbnz	w2, 8d3c <fwp_main_thread+0xa9c>
    8d30:	b9400002 	ldr	w2, [x0]
    8d34:	6b05005f 	cmp	w2, w5
    8d38:	54000e89 	b.ls	8f08 <fwp_main_thread+0xc68>  // b.plast
    8d3c:	91000421 	add	x1, x1, #0x1
    8d40:	91016000 	add	x0, x0, #0x58
    8d44:	eb03003f 	cmp	x1, x3
    8d48:	54ffff01 	b.ne	8d28 <fwp_main_thread+0xa88>  // b.any
    8d4c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8d50:	eb00007f 	cmp	x3, x0
    8d54:	540042cc 	b.gt	95ac <fwp_main_thread+0x130c>
    8d58:	9100c280 	add	x0, x20, #0x30
    8d5c:	f9404000 	ldr	x0, [x0, #128]
    8d60:	eb03001f 	cmp	x0, x3
    8d64:	54000241 	b.ne	8dac <fwp_main_thread+0xb0c>  // b.any
    8d68:	b4005183 	cbz	x3, 9798 <fwp_main_thread+0x14f8>
    8d6c:	d37ff862 	lsl	x2, x3, #1
    8d70:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8d74:	eb00005f 	cmp	x2, x0
    8d78:	9a80d042 	csel	x2, x2, x0, le
    8d7c:	d2800b01 	mov	x1, #0x58                  	// #88
    8d80:	9100c285 	add	x5, x20, #0x30
    8d84:	f9401a80 	ldr	x0, [x20, #48]
    8d88:	9b017c41 	mul	x1, x2, x1
    8d8c:	a90217e2 	stp	x2, x5, [sp, #32]
    8d90:	f9001be3 	str	x3, [sp, #48]
    8d94:	97ffe697 	bl	27f0 <realloc@plt>
    8d98:	a94217e2 	ldp	x2, x5, [sp, #32]
    8d9c:	f9401be3 	ldr	x3, [sp, #48]
    8da0:	b4005f40 	cbz	x0, 9988 <fwp_main_thread+0x16e8>
    8da4:	f9001a80 	str	x0, [x20, #48]
    8da8:	f90040a2 	str	x2, [x5, #128]
    8dac:	8b030462 	add	x2, x3, x3, lsl #1
    8db0:	9100c285 	add	x5, x20, #0x30
    8db4:	f9401a87 	ldr	x7, [x20, #48]
    8db8:	d37ef442 	lsl	x2, x2, #2
    8dbc:	cb030042 	sub	x2, x2, x3
    8dc0:	aa0303e1 	mov	x1, x3
    8dc4:	4f000400 	movi	v0.4s, #0x0
    8dc8:	91000460 	add	x0, x3, #0x1
    8dcc:	8b020ce2 	add	x2, x7, x2, lsl #3
    8dd0:	f90038a0 	str	x0, [x5, #112]
    8dd4:	f900285f 	str	xzr, [x2, #80]
    8dd8:	ad000040 	stp	q0, q0, [x2]
    8ddc:	ad010040 	stp	q0, q0, [x2, #32]
    8de0:	3d801040 	str	q0, [x2, #64]
    8de4:	8b010422 	add	x2, x1, x1, lsl #1
    8de8:	d0000000 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    8dec:	91322000 	add	x0, x0, #0xc88
    8df0:	d37ef442 	lsl	x2, x2, #2
    8df4:	f9001be1 	str	x1, [sp, #48]
    8df8:	cb010042 	sub	x2, x2, x1
    8dfc:	8b020ce2 	add	x2, x7, x2, lsl #3
    8e00:	a9021fe2 	stp	x2, x7, [sp, #32]
    8e04:	f900285f 	str	xzr, [x2, #80]
    8e08:	97ffe6e2 	bl	2990 <getenv@plt>
    8e0c:	a9421fe2 	ldp	x2, x7, [sp, #32]
    8e10:	f9401be1 	ldr	x1, [sp, #48]
    8e14:	b4000820 	cbz	x0, 8f18 <fwp_main_thread+0xc78>
    8e18:	39400003 	ldrb	w3, [x0]
    8e1c:	7100c07f 	cmp	w3, #0x30
    8e20:	540007c1 	b.ne	8f18 <fwp_main_thread+0xc78>  // b.any
    8e24:	39400400 	ldrb	w0, [x0, #1]
    8e28:	35000780 	cbnz	w0, 8f18 <fwp_main_thread+0xc78>
    8e2c:	9100c283 	add	x3, x20, #0x30
    8e30:	2f000400 	mvni	v0.2s, #0x0
    8e34:	b9400046 	ldr	w6, [x2]
    8e38:	91000428 	add	x8, x1, #0x1
    8e3c:	52800025 	mov	w5, #0x1                   	// #1
    8e40:	a900f05c 	stp	x28, x28, [x2, #8]
    8e44:	110004c6 	add	w6, w6, #0x1
    8e48:	f9415860 	ldr	x0, [x3, #688]
    8e4c:	29001446 	stp	w6, w5, [x2]
    8e50:	f900205f 	str	xzr, [x2, #64]
    8e54:	f9004468 	str	x8, [x3, #136]
    8e58:	fd002440 	str	d0, [x2, #72]
    8e5c:	b4003a20 	cbz	x0, 95a0 <fwp_main_thread+0x1300>
    8e60:	d0ffffe3 	adrp	x3, 6000 <fwp_owned_tape_release+0x5c>
    8e64:	91070065 	add	x5, x3, #0x1c0
    8e68:	14000003 	b	8e74 <fwp_main_thread+0xbd4>
    8e6c:	f9400000 	ldr	x0, [x0]
    8e70:	b4003980 	cbz	x0, 95a0 <fwp_main_thread+0x1300>
    8e74:	f9400403 	ldr	x3, [x0, #8]
    8e78:	eb05007f 	cmp	x3, x5
    8e7c:	54ffff81 	b.ne	8e6c <fwp_main_thread+0xbcc>  // b.any
    8e80:	f9400800 	ldr	x0, [x0, #16]
    8e84:	2a0103e5 	mov	w5, w1
    8e88:	b9400003 	ldr	w3, [x0]
    8e8c:	f9002040 	str	x0, [x2, #64]
    8e90:	b9004c43 	str	w3, [x2, #76]
    8e94:	37f80083 	tbnz	w3, #31, 8ea4 <fwp_main_thread+0xc04>
    8e98:	52800b02 	mov	w2, #0x58                  	// #88
    8e9c:	9b221c63 	smaddl	x3, w3, w2, x7
    8ea0:	b9004861 	str	w1, [x3, #72]
    8ea4:	b9000005 	str	w5, [x0]
    8ea8:	d2800002 	mov	x2, #0x0                   	// #0
    8eac:	aa1803e0 	mov	x0, x24
    8eb0:	b4002038 	cbz	x24, 92b4 <fwp_main_thread+0x1014>
    8eb4:	d503201f 	nop
    8eb8:	f9400800 	ldr	x0, [x0, #16]
    8ebc:	91000442 	add	x2, x2, #0x1
    8ec0:	b5ffffc0 	cbnz	x0, 8eb8 <fwp_main_thread+0xc18>
    8ec4:	aa1803e1 	mov	x1, x24
    8ec8:	f9400821 	ldr	x1, [x1, #16]
    8ecc:	91000400 	add	x0, x0, #0x1
    8ed0:	b5ffffc1 	cbnz	x1, 8ec8 <fwp_main_thread+0xc28>
    8ed4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8ed8:	eb01001f 	cmp	x0, x1
    8edc:	54000108 	b.hi	8efc <fwp_main_thread+0xc5c>  // b.pmore
    8ee0:	f100005f 	cmp	x2, #0x0
    8ee4:	54001e8d 	b.le	92b4 <fwp_main_thread+0x1014>
    8ee8:	eb00005f 	cmp	x2, x0
    8eec:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8ef0:	9a80905c 	csel	x28, x2, x0, ls	// ls = plast
    8ef4:	eb01039f 	cmp	x28, x1
    8ef8:	54004549 	b.ls	97a0 <fwp_main_thread+0x1500>  // b.plast
    8efc:	d0000000 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    8f00:	913d6000 	add	x0, x0, #0xf58
    8f04:	97ffebbf 	bl	3e00 <fwp_trap>
    8f08:	eb01007f 	cmp	x3, x1
    8f0c:	54fff200 	b.eq	8d4c <fwp_main_thread+0xaac>  // b.none
    8f10:	f9401a87 	ldr	x7, [x20, #48]
    8f14:	17ffffb4 	b	8de4 <fwp_main_thread+0xb44>
    8f18:	9100c280 	add	x0, x20, #0x30
    8f1c:	f9403003 	ldr	x3, [x0, #96]
    8f20:	b4fff863 	cbz	x3, 8e2c <fwp_main_thread+0xb8c>
    8f24:	3cc38000 	ldur	q0, [x0, #56]
    8f28:	f900301f 	str	xzr, [x0, #96]
    8f2c:	3d800840 	str	q0, [x2, #32]
    8f30:	f9402c05 	ldr	x5, [x0, #88]
    8f34:	f9001c45 	str	x5, [x2, #56]
    8f38:	f9402405 	ldr	x5, [x0, #72]
    8f3c:	f9001845 	str	x5, [x2, #48]
    8f40:	f9402805 	ldr	x5, [x0, #80]
    8f44:	f9000c45 	str	x5, [x2, #24]
    8f48:	a903fc1f 	stp	xzr, xzr, [x0, #56]
    8f4c:	a904fc1f 	stp	xzr, xzr, [x0, #72]
    8f50:	f9002c1f 	str	xzr, [x0, #88]
    8f54:	17ffffb6 	b	8e2c <fwp_main_thread+0xb8c>
    8f58:	f9416260 	ldr	x0, [x19, #704]
    8f5c:	97ffec65 	bl	40f0 <fwp_mem_free>
    8f60:	f901627f 	str	xzr, [x19, #704]
    8f64:	f9400a60 	ldr	x0, [x19, #16]
    8f68:	f9016a7f 	str	xzr, [x19, #720]
    8f6c:	b4ffb840 	cbz	x0, 8674 <fwp_main_thread+0x3d4>
    8f70:	f900541f 	str	xzr, [x0, #168]
    8f74:	f9005c1f 	str	xzr, [x0, #184]
    8f78:	17fffdbf 	b	8674 <fwp_main_thread+0x3d4>
    8f7c:	aa0303e0 	mov	x0, x3
    8f80:	f90017e2 	str	x2, [sp, #40]
    8f84:	97ffec5b 	bl	40f0 <fwp_mem_free>
    8f88:	f94017e2 	ldr	x2, [sp, #40]
    8f8c:	9114c267 	add	x7, x19, #0x530
    8f90:	d2800508 	mov	x8, #0x28                  	// #40
    8f94:	f949d8e1 	ldr	x1, [x7, #5040]
    8f98:	f949ece0 	ldr	x0, [x7, #5080]
    8f9c:	cb010041 	sub	x1, x2, x1
    8fa0:	eb00403f 	cmp	x1, x0, lsl #16
    8fa4:	54000362 	b.cs	9010 <fwp_main_thread+0xd70>  // b.hs, b.nlast
    8fa8:	d350fc25 	lsr	x5, x1, #16
    8fac:	f949fce6 	ldr	x6, [x7, #5112]
    8fb0:	9b087ca5 	mul	x5, x5, x8
    8fb4:	8b0500c3 	add	x3, x6, x5
    8fb8:	f9401060 	ldr	x0, [x3, #32]
    8fbc:	b40002a0 	cbz	x0, 9010 <fwp_main_thread+0xd70>
    8fc0:	386568c6 	ldrb	w6, [x6, x5]
    8fc4:	710008df 	cmp	w6, #0x2
    8fc8:	54008960 	b.eq	a0f4 <fwp_main_thread+0x1e54>  // b.none
    8fcc:	710004df 	cmp	w6, #0x1
    8fd0:	54000201 	b.ne	9010 <fwp_main_thread+0xd70>  // b.any
    8fd4:	29432465 	ldp	w5, w9, [x3, #24]
    8fd8:	92403c21 	and	x1, x1, #0xffff
    8fdc:	9b057c25 	mul	x5, x1, x5
    8fe0:	d360fca5 	lsr	x5, x5, #32
    8fe4:	eb0900bf 	cmp	x5, x9
    8fe8:	54000142 	b.cs	9010 <fwp_main_thread+0xd70>  // b.hs, b.nlast
    8fec:	8b050000 	add	x0, x0, x5
    8ff0:	39400005 	ldrb	w5, [x0]
    8ff4:	340000e5 	cbz	w5, 9010 <fwp_main_thread+0xd70>
    8ff8:	710004bf 	cmp	w5, #0x1
    8ffc:	54008640 	b.eq	a0c4 <fwp_main_thread+0x1e24>  // b.none
    9000:	7103fcbf 	cmp	w5, #0xff
    9004:	54008a00 	b.eq	a144 <fwp_main_thread+0x1ea4>  // b.none
    9008:	510004a5 	sub	w5, w5, #0x1
    900c:	39000005 	strb	w5, [x0]
    9010:	9114c265 	add	x5, x19, #0x530
    9014:	d2800507 	mov	x7, #0x28                  	// #40
    9018:	f94013e2 	ldr	x2, [sp, #32]
    901c:	f949d8a1 	ldr	x1, [x5, #5040]
    9020:	f949eca0 	ldr	x0, [x5, #5080]
    9024:	cb010041 	sub	x1, x2, x1
    9028:	eb00403f 	cmp	x1, x0, lsl #16
    902c:	54000362 	b.cs	9098 <fwp_main_thread+0xdf8>  // b.hs, b.nlast
    9030:	d350fc22 	lsr	x2, x1, #16
    9034:	f949fca6 	ldr	x6, [x5, #5112]
    9038:	9b077c42 	mul	x2, x2, x7
    903c:	8b0200c3 	add	x3, x6, x2
    9040:	f9401060 	ldr	x0, [x3, #32]
    9044:	b40002a0 	cbz	x0, 9098 <fwp_main_thread+0xdf8>
    9048:	386268c6 	ldrb	w6, [x6, x2]
    904c:	710008df 	cmp	w6, #0x2
    9050:	54008d40 	b.eq	a1f8 <fwp_main_thread+0x1f58>  // b.none
    9054:	710004df 	cmp	w6, #0x1
    9058:	54000201 	b.ne	9098 <fwp_main_thread+0xdf8>  // b.any
    905c:	29432062 	ldp	w2, w8, [x3, #24]
    9060:	92403c21 	and	x1, x1, #0xffff
    9064:	9b027c22 	mul	x2, x1, x2
    9068:	d360fc42 	lsr	x2, x2, #32
    906c:	eb08005f 	cmp	x2, x8
    9070:	54000142 	b.cs	9098 <fwp_main_thread+0xdf8>  // b.hs, b.nlast
    9074:	8b020000 	add	x0, x0, x2
    9078:	39400002 	ldrb	w2, [x0]
    907c:	340000e2 	cbz	w2, 9098 <fwp_main_thread+0xdf8>
    9080:	7100045f 	cmp	w2, #0x1
    9084:	540087e0 	b.eq	a180 <fwp_main_thread+0x1ee0>  // b.none
    9088:	7103fc5f 	cmp	w2, #0xff
    908c:	54008980 	b.eq	a1bc <fwp_main_thread+0x1f1c>  // b.none
    9090:	51000442 	sub	w2, w2, #0x1
    9094:	39000002 	strb	w2, [x0]
    9098:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x114b8>
    909c:	910ae042 	add	x2, x2, #0x2b8
    90a0:	91014042 	add	x2, x2, #0x50
    90a4:	aa1503e0 	mov	x0, x21
    90a8:	52800023 	mov	w3, #0x1                   	// #1
    90ac:	aa1c03e1 	mov	x1, x28
    90b0:	a90c7fff 	stp	xzr, xzr, [sp, #192]
    90b4:	f9006bff 	str	xzr, [sp, #208]
    90b8:	97fff87f 	bl	72b4 <fwp_write>
    90bc:	a94c0be3 	ldp	x3, x2, [sp, #192]
    90c0:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x490>
    90c4:	91168000 	add	x0, x0, #0x5a0
    90c8:	f100007f 	cmp	x3, #0x0
    90cc:	9a830003 	csel	x3, x0, x3, eq	// eq = none
    90d0:	b100285f 	cmn	x2, #0xa
    90d4:	54007a28 	b.hi	a018 <fwp_main_thread+0x1d78>  // b.pmore
    90d8:	91002440 	add	x0, x2, #0x9
    90dc:	52800021 	mov	w1, #0x1                   	// #1
    90e0:	a9020be3 	stp	x3, x2, [sp, #32]
    90e4:	97ffeebf 	bl	4be0 <fwp_heap_alloc>
    90e8:	a9420be3 	ldp	x3, x2, [sp, #32]
    90ec:	f90013e0 	str	x0, [sp, #32]
    90f0:	f8008402 	str	x2, [x0], #8
    90f4:	f9001be2 	str	x2, [sp, #48]
    90f8:	f90017e0 	str	x0, [sp, #40]
    90fc:	aa0303e1 	mov	x1, x3
    9100:	97ffe558 	bl	2660 <memcpy@plt>
    9104:	f94013e0 	ldr	x0, [sp, #32]
    9108:	f9401be2 	ldr	x2, [sp, #48]
    910c:	8b020002 	add	x2, x0, x2
    9110:	3900205f 	strb	wzr, [x2, #8]
    9114:	f94063e0 	ldr	x0, [sp, #192]
    9118:	97ffe5ea 	bl	28c0 <free@plt>
    911c:	9114c260 	add	x0, x19, #0x530
    9120:	f94013e3 	ldr	x3, [sp, #32]
    9124:	f949d801 	ldr	x1, [x0, #5040]
    9128:	f949ec02 	ldr	x2, [x0, #5080]
    912c:	cb010061 	sub	x1, x3, x1
    9130:	eb02403f 	cmp	x1, x2, lsl #16
    9134:	54000322 	b.cs	9198 <fwp_main_thread+0xef8>  // b.hs, b.nlast
    9138:	d350fc22 	lsr	x2, x1, #16
    913c:	d2800503 	mov	x3, #0x28                  	// #40
    9140:	f949fc05 	ldr	x5, [x0, #5112]
    9144:	9b037c42 	mul	x2, x2, x3
    9148:	8b0200a3 	add	x3, x5, x2
    914c:	f9401060 	ldr	x0, [x3, #32]
    9150:	b4000240 	cbz	x0, 9198 <fwp_main_thread+0xef8>
    9154:	386268a2 	ldrb	w2, [x5, x2]
    9158:	7100085f 	cmp	w2, #0x2
    915c:	54007700 	b.eq	a03c <fwp_main_thread+0x1d9c>  // b.none
    9160:	7100045f 	cmp	w2, #0x1
    9164:	540001a1 	b.ne	9198 <fwp_main_thread+0xef8>  // b.any
    9168:	29430865 	ldp	w5, w2, [x3, #24]
    916c:	92403c21 	and	x1, x1, #0xffff
    9170:	9b057c21 	mul	x1, x1, x5
    9174:	d360fc21 	lsr	x1, x1, #32
    9178:	eb02003f 	cmp	x1, x2
    917c:	540000e2 	b.cs	9198 <fwp_main_thread+0xef8>  // b.hs, b.nlast
    9180:	8b010000 	add	x0, x0, x1
    9184:	39400001 	ldrb	w1, [x0]
    9188:	7103fc3f 	cmp	w1, #0xff
    918c:	540077c0 	b.eq	a084 <fwp_main_thread+0x1de4>  // b.none
    9190:	52800021 	mov	w1, #0x1                   	// #1
    9194:	39000001 	strb	w1, [x0]
    9198:	aa1c03e0 	mov	x0, x28
    919c:	97fff26d 	bl	5b50 <fwp_drop0>
    91a0:	a94203e1 	ldp	x1, x0, [sp, #32]
    91a4:	9100c29c 	add	x28, x20, #0x30
    91a8:	f9400783 	ldr	x3, [x28, #8]
    91ac:	f9400022 	ldr	x2, [x1]
    91b0:	d2800021 	mov	x1, #0x1                   	// #1
    91b4:	97ffe5d3 	bl	2900 <fwrite@plt>
    91b8:	f9400781 	ldr	x1, [x28, #8]
    91bc:	52800140 	mov	w0, #0xa                   	// #10
    91c0:	97ffe558 	bl	2720 <fputc@plt>
    91c4:	9114c262 	add	x2, x19, #0x530
    91c8:	f94013e3 	ldr	x3, [sp, #32]
    91cc:	f949d841 	ldr	x1, [x2, #5040]
    91d0:	f949ec40 	ldr	x0, [x2, #5080]
    91d4:	cb010061 	sub	x1, x3, x1
    91d8:	eb00403f 	cmp	x1, x0, lsl #16
    91dc:	54000382 	b.cs	924c <fwp_main_thread+0xfac>  // b.hs, b.nlast
    91e0:	d350fc20 	lsr	x0, x1, #16
    91e4:	d2800505 	mov	x5, #0x28                  	// #40
    91e8:	f949fc43 	ldr	x3, [x2, #5112]
    91ec:	9b057c00 	mul	x0, x0, x5
    91f0:	8b000062 	add	x2, x3, x0
    91f4:	f940105c 	ldr	x28, [x2, #32]
    91f8:	b40002bc 	cbz	x28, 924c <fwp_main_thread+0xfac>
    91fc:	38606860 	ldrb	w0, [x3, x0]
    9200:	7100081f 	cmp	w0, #0x2
    9204:	54007160 	b.eq	a030 <fwp_main_thread+0x1d90>  // b.none
    9208:	7100041f 	cmp	w0, #0x1
    920c:	54000201 	b.ne	924c <fwp_main_thread+0xfac>  // b.any
    9210:	29430043 	ldp	w3, w0, [x2, #24]
    9214:	92403c21 	and	x1, x1, #0xffff
    9218:	9b037c21 	mul	x1, x1, x3
    921c:	d360fc21 	lsr	x1, x1, #32
    9220:	eb00003f 	cmp	x1, x0
    9224:	54000142 	b.cs	924c <fwp_main_thread+0xfac>  // b.hs, b.nlast
    9228:	8b01039c 	add	x28, x28, x1
    922c:	39400381 	ldrb	w1, [x28]
    9230:	340000e1 	cbz	w1, 924c <fwp_main_thread+0xfac>
    9234:	7100043f 	cmp	w1, #0x1
    9238:	54006f60 	b.eq	a024 <fwp_main_thread+0x1d84>  // b.none
    923c:	7103fc3f 	cmp	w1, #0xff
    9240:	54007040 	b.eq	a048 <fwp_main_thread+0x1da8>  // b.none
    9244:	51000421 	sub	w1, w1, #0x1
    9248:	39000381 	strb	w1, [x28]
    924c:	f9400fe0 	ldr	x0, [sp, #24]
    9250:	f9400800 	ldr	x0, [x0, #16]
    9254:	f9000fe0 	str	x0, [sp, #24]
    9258:	b5ffc100 	cbnz	x0, 8a78 <fwp_main_thread+0x7d8>
    925c:	aa1803e0 	mov	x0, x24
    9260:	97fff23c 	bl	5b50 <fwp_drop0>
    9264:	aa1b03e0 	mov	x0, x27
    9268:	97fff23a 	bl	5b50 <fwp_drop0>
    926c:	9100c280 	add	x0, x20, #0x30
    9270:	52800021 	mov	w1, #0x1                   	// #1
    9274:	f94103f9 	ldr	x25, [sp, #512]
    9278:	f94107fa 	ldr	x26, [sp, #520]
    927c:	f9410bfb 	ldr	x27, [sp, #528]
    9280:	f9410ffc 	ldr	x28, [sp, #536]
    9284:	b902e401 	str	w1, [x0, #740]
    9288:	f901781f 	str	xzr, [x0, #752]
    928c:	17fffc4a 	b	83b4 <fwp_main_thread+0x114>
    9290:	b0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0x5c>
    9294:	91034000 	add	x0, x0, #0xd0
    9298:	f90013e1 	str	x1, [sp, #32]
    929c:	94000629 	bl	ab40 <atexit>
    92a0:	f94013e1 	ldr	x1, [sp, #32]
    92a4:	35003720 	cbnz	w0, 9988 <fwp_main_thread+0x16e8>
    92a8:	52800020 	mov	w0, #0x1                   	// #1
    92ac:	b902e820 	str	w0, [x1, #744]
    92b0:	17fffe93 	b	8cfc <fwp_main_thread+0xa5c>
    92b4:	52800041 	mov	w1, #0x2                   	// #2
    92b8:	d2800100 	mov	x0, #0x8                   	// #8
    92bc:	b90023e6 	str	w6, [sp, #32]
    92c0:	f9001fe8 	str	x8, [sp, #56]
    92c4:	97ffee47 	bl	4be0 <fwp_heap_alloc>
    92c8:	aa0003e2 	mov	x2, x0
    92cc:	9114c260 	add	x0, x19, #0x530
    92d0:	a9028be2 	stp	x2, x2, [sp, #40]
    92d4:	b94023e6 	ldr	w6, [sp, #32]
    92d8:	f900005f 	str	xzr, [x2]
    92dc:	f9401fe8 	ldr	x8, [sp, #56]
    92e0:	f949d801 	ldr	x1, [x0, #5040]
    92e4:	f949ec00 	ldr	x0, [x0, #5080]
    92e8:	cb010041 	sub	x1, x2, x1
    92ec:	eb00403f 	cmp	x1, x0, lsl #16
    92f0:	540030e2 	b.cs	990c <fwp_main_thread+0x166c>  // b.hs, b.nlast
    92f4:	d280001c 	mov	x28, #0x0                   	// #0
    92f8:	9114c262 	add	x2, x19, #0x530
    92fc:	d350fc20 	lsr	x0, x1, #16
    9300:	8b000800 	add	x0, x0, x0, lsl #2
    9304:	f949fc45 	ldr	x5, [x2, #5112]
    9308:	d37df002 	lsl	x2, x0, #3
    930c:	8b0200a3 	add	x3, x5, x2
    9310:	f9401060 	ldr	x0, [x3, #32]
    9314:	b4000240 	cbz	x0, 935c <fwp_main_thread+0x10bc>
    9318:	386268a2 	ldrb	w2, [x5, x2]
    931c:	7100085f 	cmp	w2, #0x2
    9320:	540026c0 	b.eq	97f8 <fwp_main_thread+0x1558>  // b.none
    9324:	7100045f 	cmp	w2, #0x1
    9328:	540001a1 	b.ne	935c <fwp_main_thread+0x10bc>  // b.any
    932c:	29430865 	ldp	w5, w2, [x3, #24]
    9330:	92403c21 	and	x1, x1, #0xffff
    9334:	9b057c21 	mul	x1, x1, x5
    9338:	d360fc21 	lsr	x1, x1, #32
    933c:	eb02003f 	cmp	x1, x2
    9340:	540000e2 	b.cs	935c <fwp_main_thread+0x10bc>  // b.hs, b.nlast
    9344:	8b010000 	add	x0, x0, x1
    9348:	39400001 	ldrb	w1, [x0]
    934c:	7103fc3f 	cmp	w1, #0xff
    9350:	54002f20 	b.eq	9934 <fwp_main_thread+0x1694>  // b.none
    9354:	52800021 	mov	w1, #0x1                   	// #1
    9358:	39000001 	strb	w1, [x0]
    935c:	d3707cc6 	ubfiz	x6, x6, #16, #32
    9360:	aa0800c0 	orr	x0, x6, x8
    9364:	f90023e0 	str	x0, [sp, #64]
    9368:	b400025c 	cbz	x28, 93b0 <fwp_main_thread+0x1110>
    936c:	d3607c05 	lsl	x5, x0, #32
    9370:	aa1803e1 	mov	x1, x24
    9374:	f94017e0 	ldr	x0, [sp, #40]
    9378:	aa0503e3 	mov	x3, x5
    937c:	f9400706 	ldr	x6, [x24, #8]
    9380:	91002002 	add	x2, x0, #0x8
    9384:	d2800000 	mov	x0, #0x0                   	// #0
    9388:	14000005 	b	939c <fwp_main_thread+0x10fc>
    938c:	f9400426 	ldr	x6, [x1, #8]
    9390:	ab050003 	adds	x3, x0, x5
    9394:	91004042 	add	x2, x2, #0x10
    9398:	540084a6 	b.vs	a42c <fwp_main_thread+0x218c>
    939c:	a9000c46 	stp	x6, x3, [x2]
    93a0:	91000400 	add	x0, x0, #0x1
    93a4:	f9400821 	ldr	x1, [x1, #16]
    93a8:	eb1c001f 	cmp	x0, x28
    93ac:	54ffff01 	b.ne	938c <fwp_main_thread+0x10ec>  // b.any
    93b0:	f94017e0 	ldr	x0, [sp, #40]
    93b4:	f940001c 	ldr	x28, [x0]
    93b8:	f100079f 	cmp	x28, #0x1
    93bc:	54007aa9 	b.ls	a310 <fwp_main_thread+0x2070>  // b.plast
    93c0:	d341ff81 	lsr	x1, x28, #1
    93c4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    93c8:	d1000422 	sub	x2, x1, #0x1
    93cc:	f9001fe2 	str	x2, [sp, #56]
    93d0:	eb00005f 	cmp	x2, x0
    93d4:	54ffd948 	b.hi	8efc <fwp_main_thread+0xc5c>  // b.pmore
    93d8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    93dc:	a90c7fe0 	stp	x0, xzr, [sp, #192]
    93e0:	b4007982 	cbz	x2, a310 <fwp_main_thread+0x2070>
    93e4:	f94017e2 	ldr	x2, [sp, #40]
    93e8:	d1002040 	sub	x0, x2, #0x8
    93ec:	9100205c 	add	x28, x2, #0x8
    93f0:	8b011000 	add	x0, x0, x1, lsl #4
    93f4:	f90013e0 	str	x0, [sp, #32]
    93f8:	f9400780 	ldr	x0, [x28, #8]
    93fc:	aa1503e2 	mov	x2, x21
    9400:	f9400f81 	ldr	x1, [x28, #24]
    9404:	fd400380 	ldr	d0, [x28]
    9408:	fd400b81 	ldr	d1, [x28, #16]
    940c:	97ffef55 	bl	5160 <w120>
    9410:	a9000780 	stp	x0, x1, [x28]
    9414:	9100439c 	add	x28, x28, #0x10
    9418:	f94013e0 	ldr	x0, [sp, #32]
    941c:	eb00039f 	cmp	x28, x0
    9420:	54fffec1 	b.ne	93f8 <fwp_main_thread+0x1158>  // b.any
    9424:	f94017e1 	ldr	x1, [sp, #40]
    9428:	f9401fe0 	ldr	x0, [sp, #56]
    942c:	d37ff800 	lsl	x0, x0, #1
    9430:	f9000020 	str	x0, [x1]
    9434:	aa0103e0 	mov	x0, x1
    9438:	97fff09a 	bl	56a0 <w176.constprop.0>
    943c:	aa0103fc 	mov	x28, x1
    9440:	9114c263 	add	x3, x19, #0x530
    9444:	f94017e2 	ldr	x2, [sp, #40]
    9448:	f949d861 	ldr	x1, [x3, #5040]
    944c:	f949ec60 	ldr	x0, [x3, #5080]
    9450:	cb010041 	sub	x1, x2, x1
    9454:	eb00403f 	cmp	x1, x0, lsl #16
    9458:	54000382 	b.cs	94c8 <fwp_main_thread+0x1228>  // b.hs, b.nlast
    945c:	d2800506 	mov	x6, #0x28                  	// #40
    9460:	d350fc25 	lsr	x5, x1, #16
    9464:	f949fc62 	ldr	x2, [x3, #5112]
    9468:	9b067ca5 	mul	x5, x5, x6
    946c:	8b050047 	add	x7, x2, x5
    9470:	f94010e0 	ldr	x0, [x7, #32]
    9474:	b40002a0 	cbz	x0, 94c8 <fwp_main_thread+0x1228>
    9478:	38656845 	ldrb	w5, [x2, x5]
    947c:	710008bf 	cmp	w5, #0x2
    9480:	540013c0 	b.eq	96f8 <fwp_main_thread+0x1458>  // b.none
    9484:	710004bf 	cmp	w5, #0x1
    9488:	54000201 	b.ne	94c8 <fwp_main_thread+0x1228>  // b.any
    948c:	294314e8 	ldp	w8, w5, [x7, #24]
    9490:	92403c21 	and	x1, x1, #0xffff
    9494:	9b087c21 	mul	x1, x1, x8
    9498:	d360fc21 	lsr	x1, x1, #32
    949c:	eb05003f 	cmp	x1, x5
    94a0:	54000142 	b.cs	94c8 <fwp_main_thread+0x1228>  // b.hs, b.nlast
    94a4:	8b010000 	add	x0, x0, x1
    94a8:	39400001 	ldrb	w1, [x0]
    94ac:	340000e1 	cbz	w1, 94c8 <fwp_main_thread+0x1228>
    94b0:	7100043f 	cmp	w1, #0x1
    94b4:	54000320 	b.eq	9518 <fwp_main_thread+0x1278>  // b.none
    94b8:	7103fc3f 	cmp	w1, #0xff
    94bc:	54006ea0 	b.eq	a290 <fwp_main_thread+0x1ff0>  // b.none
    94c0:	51000421 	sub	w1, w1, #0x1
    94c4:	39000001 	strb	w1, [x0]
    94c8:	b98043e0 	ldrsw	x0, [sp, #64]
    94cc:	f90013e0 	str	x0, [sp, #32]
    94d0:	97ffec50 	bl	4610 <fwp_tape_of>
    94d4:	aa0003e5 	mov	x5, x0
    94d8:	f9402801 	ldr	x1, [x0, #80]
    94dc:	b4000b61 	cbz	x1, 9648 <fwp_main_thread+0x13a8>
    94e0:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    94e4:	913b2000 	add	x0, x0, #0xec8
    94e8:	97ffea46 	bl	3e00 <fwp_trap>
    94ec:	d280001c 	mov	x28, #0x0                   	// #0
    94f0:	17fffe00 	b	8cf0 <fwp_main_thread+0xa50>
    94f4:	aa1703e0 	mov	x0, x23
    94f8:	97ffea62 	bl	3e80 <fwp_rc_forget_slot.part.0>
    94fc:	17fffd08 	b	891c <fwp_main_thread+0x67c>
    9500:	aa1703e0 	mov	x0, x23
    9504:	97ffea5f 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9508:	17fffd29 	b	89ac <fwp_main_thread+0x70c>
    950c:	aa1703e0 	mov	x0, x23
    9510:	97ffea5c 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9514:	17fffd4b 	b	8a40 <fwp_main_thread+0x7a0>
    9518:	f9401be4 	ldr	x4, [sp, #48]
    951c:	f949ec65 	ldr	x5, [x3, #5080]
    9520:	aa0403e0 	mov	x0, x4
    9524:	f9400087 	ldr	x7, [x4]
    9528:	f949d861 	ldr	x1, [x3, #5040]
    952c:	d370bca5 	lsl	x5, x5, #16
    9530:	cb010081 	sub	x1, x4, x1
    9534:	b7f80e87 	tbnz	x7, #63, 9704 <fwp_main_thread+0x1464>
    9538:	eb0100bf 	cmp	x5, x1
    953c:	54fffc69 	b.ls	94c8 <fwp_main_thread+0x1228>  // b.plast
    9540:	d350fc20 	lsr	x0, x1, #16
    9544:	d2800503 	mov	x3, #0x28                  	// #40
    9548:	9b037c00 	mul	x0, x0, x3
    954c:	8b000045 	add	x5, x2, x0
    9550:	f94010a3 	ldr	x3, [x5, #32]
    9554:	b4fffba3 	cbz	x3, 94c8 <fwp_main_thread+0x1228>
    9558:	38606840 	ldrb	w0, [x2, x0]
    955c:	7100081f 	cmp	w0, #0x2
    9560:	54001d00 	b.eq	9900 <fwp_main_thread+0x1660>  // b.none
    9564:	7100041f 	cmp	w0, #0x1
    9568:	54fffb01 	b.ne	94c8 <fwp_main_thread+0x1228>  // b.any
    956c:	92403c20 	and	x0, x1, #0xffff
    9570:	294304a2 	ldp	w2, w1, [x5, #24]
    9574:	9b027c00 	mul	x0, x0, x2
    9578:	d360fc00 	lsr	x0, x0, #32
    957c:	eb01001f 	cmp	x0, x1
    9580:	54fffa42 	b.cs	94c8 <fwp_main_thread+0x1228>  // b.hs, b.nlast
    9584:	8b000063 	add	x3, x3, x0
    9588:	39400060 	ldrb	w0, [x3]
    958c:	7100041f 	cmp	w0, #0x1
    9590:	54fff9c1 	b.ne	94c8 <fwp_main_thread+0x1228>  // b.any
    9594:	f9401be0 	ldr	x0, [sp, #48]
    9598:	97ffead6 	bl	40f0 <fwp_mem_free>
    959c:	17ffffcb 	b	94c8 <fwp_main_thread+0x1228>
    95a0:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x490>
    95a4:	91048000 	add	x0, x0, #0x120
    95a8:	97ffea16 	bl	3e00 <fwp_trap>
    95ac:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x490>
    95b0:	91028000 	add	x0, x0, #0xa0
    95b4:	97ffea13 	bl	3e00 <fwp_trap>
    95b8:	97ffeb47 	bl	42d4 <fwp_rc_wide_dup>
    95bc:	9114c260 	add	x0, x19, #0x530
    95c0:	f949ec05 	ldr	x5, [x0, #5080]
    95c4:	f949d801 	ldr	x1, [x0, #5040]
    95c8:	d370bca5 	lsl	x5, x5, #16
    95cc:	17fffd4f 	b	8b08 <fwp_main_thread+0x868>
    95d0:	ca5c4780 	eor	x0, x28, x28, lsr #17
    95d4:	9114c262 	add	x2, x19, #0x530
    95d8:	ca402400 	eor	x0, x0, x0, lsr #9
    95dc:	92401c00 	and	x0, x0, #0xff
    95e0:	910a2401 	add	x1, x0, #0x289
    95e4:	8b000c40 	add	x0, x2, x0, lsl #3
    95e8:	8b010c41 	add	x1, x2, x1, lsl #3
    95ec:	f94a2400 	ldr	x0, [x0, #5192]
    95f0:	b50000a0 	cbnz	x0, 9604 <fwp_main_thread+0x1364>
    95f4:	140000da 	b	995c <fwp_main_thread+0x16bc>
    95f8:	91004001 	add	x1, x0, #0x10
    95fc:	f9400800 	ldr	x0, [x0, #16]
    9600:	b4001ae0 	cbz	x0, 995c <fwp_main_thread+0x16bc>
    9604:	f9400002 	ldr	x2, [x0]
    9608:	eb1c005f 	cmp	x2, x28
    960c:	54ffff61 	b.ne	95f8 <fwp_main_thread+0x1358>  // b.any
    9610:	f9400021 	ldr	x1, [x1]
    9614:	f9400420 	ldr	x0, [x1, #8]
    9618:	d1000400 	sub	x0, x0, #0x1
    961c:	f9000420 	str	x0, [x1, #8]
    9620:	f103f81f 	cmp	x0, #0xfe
    9624:	54ffb021 	b.ne	8c28 <fwp_main_thread+0x988>  // b.any
    9628:	39400380 	ldrb	w0, [x28]
    962c:	7103fc1f 	cmp	w0, #0xff
    9630:	540019c0 	b.eq	9968 <fwp_main_thread+0x16c8>  // b.none
    9634:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9638:	39000380 	strb	w0, [x28]
    963c:	17fffd7b 	b	8c28 <fwp_main_thread+0x988>
    9640:	97ffeb25 	bl	42d4 <fwp_rc_wide_dup>
    9644:	17fffd58 	b	8ba4 <fwp_main_thread+0x904>
    9648:	97ffe632 	bl	2f10 <fwp_tape_unlink_scope>
    964c:	b90004bf 	str	wzr, [x5, #4]
    9650:	3dc008a0 	ldr	q0, [x5, #32]
    9654:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    9658:	b94000a1 	ldr	w1, [x5]
    965c:	a940a0a7 	ldp	x7, x8, [x5, #8]
    9660:	fd0017e0 	str	d0, [sp, #40]
    9664:	f9400ca3 	ldr	x3, [x5, #24]
    9668:	a94308a6 	ldp	x6, x2, [x5, #48]
    966c:	6b00003f 	cmp	w1, w0
    9670:	54000128 	b.hi	9694 <fwp_main_thread+0x13f4>  // b.pmore
    9674:	9100c281 	add	x1, x20, #0x30
    9678:	f94013e0 	ldr	x0, [sp, #32]
    967c:	f9404429 	ldr	x9, [x1, #136]
    9680:	92403c00 	and	x0, x0, #0xffff
    9684:	d1000400 	sub	x0, x0, #0x1
    9688:	eb09001f 	cmp	x0, x9
    968c:	5400004a 	b.ge	9694 <fwp_main_thread+0x13f4>  // b.tcont
    9690:	f9004420 	str	x0, [x1, #136]
    9694:	4f000401 	movi	v1.4s, #0x0
    9698:	9100c281 	add	x1, x20, #0x30
    969c:	f9000cbf 	str	xzr, [x5, #24]
    96a0:	910223e4 	add	x4, sp, #0x88
    96a4:	a9037cbf 	stp	xzr, xzr, [x5, #48]
    96a8:	f9415820 	ldr	x0, [x1, #688]
    96ac:	3c8080a1 	stur	q1, [x5, #8]
    96b0:	3d8008a1 	str	q1, [x5, #32]
    96b4:	f9001be4 	str	x4, [sp, #48]
    96b8:	f90047e0 	str	x0, [sp, #136]
    96bc:	d0ffffc0 	adrp	x0, 3000 <fwp_segv+0x10>
    96c0:	9133c000 	add	x0, x0, #0xcf0
    96c4:	f9004be0 	str	x0, [sp, #144]
    96c8:	f9004ff5 	str	x21, [sp, #152]
    96cc:	a90d0fe6 	stp	x6, x3, [sp, #208]
    96d0:	f90073e2 	str	x2, [sp, #224]
    96d4:	f9015824 	str	x4, [x1, #688]
    96d8:	3d8033e0 	str	q0, [sp, #192]
    96dc:	b7f813dc 	tbnz	x28, #63, 9954 <fwp_main_thread+0x16b4>
    96e0:	f94013e0 	ldr	x0, [sp, #32]
    96e4:	eb9c801f 	cmp	x0, x28, asr #32
    96e8:	540008e0 	b.eq	9804 <fwp_main_thread+0x1564>  // b.none
    96ec:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    96f0:	913a0000 	add	x0, x0, #0xe80
    96f4:	97ffe9c3 	bl	3e00 <fwp_trap>
    96f8:	72003c3f 	tst	w1, #0xffff
    96fc:	54ffee61 	b.ne	94c8 <fwp_main_thread+0x1228>  // b.any
    9700:	17ffff6a 	b	94a8 <fwp_main_thread+0x1208>
    9704:	f9400484 	ldr	x4, [x4, #8]
    9708:	f9001be4 	str	x4, [sp, #48]
    970c:	eb0100bf 	cmp	x5, x1
    9710:	54000349 	b.ls	9778 <fwp_main_thread+0x14d8>  // b.plast
    9714:	d350fc27 	lsr	x7, x1, #16
    9718:	d2800505 	mov	x5, #0x28                  	// #40
    971c:	9b057ce7 	mul	x7, x7, x5
    9720:	8b070048 	add	x8, x2, x7
    9724:	f9401105 	ldr	x5, [x8, #32]
    9728:	b4000285 	cbz	x5, 9778 <fwp_main_thread+0x14d8>
    972c:	38676842 	ldrb	w2, [x2, x7]
    9730:	7100085f 	cmp	w2, #0x2
    9734:	54000f40 	b.eq	991c <fwp_main_thread+0x167c>  // b.none
    9738:	7100045f 	cmp	w2, #0x1
    973c:	540001e1 	b.ne	9778 <fwp_main_thread+0x14d8>  // b.any
    9740:	29430907 	ldp	w7, w2, [x8, #24]
    9744:	92403c21 	and	x1, x1, #0xffff
    9748:	9b077c21 	mul	x1, x1, x7
    974c:	d360fc21 	lsr	x1, x1, #32
    9750:	eb02003f 	cmp	x1, x2
    9754:	54000122 	b.cs	9778 <fwp_main_thread+0x14d8>  // b.hs, b.nlast
    9758:	8b0100a5 	add	x5, x5, x1
    975c:	394000a1 	ldrb	w1, [x5]
    9760:	7100043f 	cmp	w1, #0x1
    9764:	540000a1 	b.ne	9778 <fwp_main_thread+0x14d8>  // b.any
    9768:	f90013e3 	str	x3, [sp, #32]
    976c:	97ffea61 	bl	40f0 <fwp_mem_free>
    9770:	f94013e3 	ldr	x3, [sp, #32]
    9774:	d2800506 	mov	x6, #0x28                  	// #40
    9778:	9114c260 	add	x0, x19, #0x530
    977c:	f9401be2 	ldr	x2, [sp, #48]
    9780:	f949d801 	ldr	x1, [x0, #5040]
    9784:	f949ec00 	ldr	x0, [x0, #5080]
    9788:	cb010041 	sub	x1, x2, x1
    978c:	eb00403f 	cmp	x1, x0, lsl #16
    9790:	54ffe683 	b.cc	9460 <fwp_main_thread+0x11c0>  // b.lo, b.ul, b.last
    9794:	17ffff4d 	b	94c8 <fwp_main_thread+0x1228>
    9798:	d2800022 	mov	x2, #0x1                   	// #1
    979c:	17fffd78 	b	8d7c <fwp_main_thread+0xadc>
    97a0:	d37ffb82 	lsl	x2, x28, #1
    97a4:	52800041 	mov	w1, #0x2                   	// #2
    97a8:	91000440 	add	x0, x2, #0x1
    97ac:	f90013e2 	str	x2, [sp, #32]
    97b0:	b9003be6 	str	w6, [sp, #56]
    97b4:	d37df000 	lsl	x0, x0, #3
    97b8:	f90023e8 	str	x8, [sp, #64]
    97bc:	97ffed09 	bl	4be0 <fwp_heap_alloc>
    97c0:	aa0003e3 	mov	x3, x0
    97c4:	9114c261 	add	x1, x19, #0x530
    97c8:	a9028fe3 	stp	x3, x3, [sp, #40]
    97cc:	aa0103e0 	mov	x0, x1
    97d0:	f94013e2 	ldr	x2, [sp, #32]
    97d4:	f9000062 	str	x2, [x3]
    97d8:	f94023e8 	ldr	x8, [sp, #64]
    97dc:	f949d821 	ldr	x1, [x1, #5040]
    97e0:	f949ec00 	ldr	x0, [x0, #5080]
    97e4:	cb010061 	sub	x1, x3, x1
    97e8:	b9403be6 	ldr	w6, [sp, #56]
    97ec:	eb00403f 	cmp	x1, x0, lsl #16
    97f0:	54ffdb62 	b.cs	935c <fwp_main_thread+0x10bc>  // b.hs, b.nlast
    97f4:	17fffec1 	b	92f8 <fwp_main_thread+0x1058>
    97f8:	72003c3f 	tst	w1, #0xffff
    97fc:	54ffdb01 	b.ne	935c <fwp_main_thread+0x10bc>  // b.any
    9800:	17fffed2 	b	9348 <fwp_main_thread+0x10a8>
    9804:	92407f83 	and	x3, x28, #0xffffffff
    9808:	eb3c411f 	cmp	x8, w28, uxtw
    980c:	540008ed 	b.le	9928 <fwp_main_thread+0x1688>
    9810:	eb0300ff 	cmp	x7, x3
    9814:	9a83c4e3 	csinc	x3, x7, x3, gt
    9818:	eb03005f 	cmp	x2, x3
    981c:	54000cea 	b.ge	99b8 <fwp_main_thread+0x1718>  // b.tcont
    9820:	f100005f 	cmp	x2, #0x0
    9824:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    9828:	9a831042 	csel	x2, x2, x3, ne	// ne = any
    982c:	14000004 	b	983c <fwp_main_thread+0x159c>
    9830:	eb00005f 	cmp	x2, x0
    9834:	d37ff842 	lsl	x2, x2, #1
    9838:	9a83d042 	csel	x2, x2, x3, le
    983c:	eb03005f 	cmp	x2, x3
    9840:	54ffff8b 	b.lt	9830 <fwp_main_thread+0x1590>  // b.tstop
    9844:	a9038fe7 	stp	x7, x3, [sp, #56]
    9848:	b4005706 	cbz	x6, a328 <fwp_main_thread+0x2088>
    984c:	aa0603e0 	mov	x0, x6
    9850:	d37df041 	lsl	x1, x2, #3
    9854:	f90013e2 	str	x2, [sp, #32]
    9858:	97ffe3e6 	bl	27f0 <realloc@plt>
    985c:	a9438fe7 	ldp	x7, x3, [sp, #56]
    9860:	aa0003e6 	mov	x6, x0
    9864:	f94013e2 	ldr	x2, [sp, #32]
    9868:	b4000a86 	cbz	x6, 99b8 <fwp_main_thread+0x1718>
    986c:	f9006be6 	str	x6, [sp, #208]
    9870:	f90073e2 	str	x2, [sp, #224]
    9874:	b5000aa3 	cbnz	x3, 99c8 <fwp_main_thread+0x1728>
    9878:	b7f800dc 	tbnz	x28, #63, 9890 <fwp_main_thread+0x15f0>
    987c:	d37d7f9c 	ubfiz	x28, x28, #3, #32
    9880:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    9884:	fc7c68c0 	ldr	d0, [x6, x28]
    9888:	1e612800 	fadd	d0, d0, d1
    988c:	fc3c68c0 	str	d0, [x6, x28]
    9890:	d1000463 	sub	x3, x3, #0x1
    9894:	eb0300ff 	cmp	x7, x3
    9898:	54000acc 	b.gt	99f0 <fwp_main_thread+0x1750>
    989c:	fc6378c0 	ldr	d0, [x6, x3, lsl #3]
    98a0:	1e602008 	fcmp	d0, #0.0
    98a4:	54ffff60 	b.eq	9890 <fwp_main_thread+0x15f0>  // b.none
    98a8:	f94017e1 	ldr	x1, [sp, #40]
    98ac:	d2800300 	mov	x0, #0x18                  	// #24
    98b0:	9b0084e2 	msub	x2, x7, x0, x1
    98b4:	9b007c60 	mul	x0, x3, x0
    98b8:	8b000041 	add	x1, x2, x0
    98bc:	b8606840 	ldr	w0, [x2, x0]
    98c0:	37f800e0 	tbnz	w0, #31, 98dc <fwp_main_thread+0x163c>
    98c4:	fd400422 	ldr	d2, [x1, #8]
    98c8:	937d7c00 	sbfiz	x0, x0, #3, #32
    98cc:	1e620802 	fmul	d2, d0, d2
    98d0:	fc6068c1 	ldr	d1, [x6, x0]
    98d4:	1e622821 	fadd	d1, d1, d2
    98d8:	fc2068c1 	str	d1, [x6, x0]
    98dc:	b9400420 	ldr	w0, [x1, #4]
    98e0:	37fffd80 	tbnz	w0, #31, 9890 <fwp_main_thread+0x15f0>
    98e4:	fd400821 	ldr	d1, [x1, #16]
    98e8:	937d7c00 	sbfiz	x0, x0, #3, #32
    98ec:	1e610800 	fmul	d0, d0, d1
    98f0:	fc6068c1 	ldr	d1, [x6, x0]
    98f4:	1e602820 	fadd	d0, d1, d0
    98f8:	fc2068c0 	str	d0, [x6, x0]
    98fc:	17ffffe5 	b	9890 <fwp_main_thread+0x15f0>
    9900:	72003c3f 	tst	w1, #0xffff
    9904:	54ffde21 	b.ne	94c8 <fwp_main_thread+0x1228>  // b.any
    9908:	17ffff20 	b	9588 <fwp_main_thread+0x12e8>
    990c:	d3707cc6 	ubfiz	x6, x6, #16, #32
    9910:	aa0800c0 	orr	x0, x6, x8
    9914:	f90023e0 	str	x0, [sp, #64]
    9918:	17fffea6 	b	93b0 <fwp_main_thread+0x1110>
    991c:	72003c3f 	tst	w1, #0xffff
    9920:	54fff2c1 	b.ne	9778 <fwp_main_thread+0x14d8>  // b.any
    9924:	17ffff8e 	b	975c <fwp_main_thread+0x14bc>
    9928:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    992c:	913be000 	add	x0, x0, #0xef8
    9930:	97ffe934 	bl	3e00 <fwp_trap>
    9934:	f90013e0 	str	x0, [sp, #32]
    9938:	b9003be6 	str	w6, [sp, #56]
    993c:	f90023e8 	str	x8, [sp, #64]
    9940:	97ffe950 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9944:	f94013e0 	ldr	x0, [sp, #32]
    9948:	f94023e8 	ldr	x8, [sp, #64]
    994c:	b9403be6 	ldr	w6, [sp, #56]
    9950:	17fffe81 	b	9354 <fwp_main_thread+0x10b4>
    9954:	aa0703e3 	mov	x3, x7
    9958:	17ffffb0 	b	9818 <fwp_main_thread+0x1578>
    995c:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    9960:	9132c000 	add	x0, x0, #0xcb0
    9964:	97ffe927 	bl	3e00 <fwp_trap>
    9968:	aa1c03e0 	mov	x0, x28
    996c:	97ffe945 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9970:	17ffff31 	b	9634 <fwp_main_thread+0x1394>
    9974:	f94047e1 	ldr	x1, [sp, #136]
    9978:	9100c294 	add	x20, x20, #0x30
    997c:	aa1503e0 	mov	x0, x21
    9980:	f9015a81 	str	x1, [x20, #688]
    9984:	97ffe8db 	bl	3cf0 <fwp_tape_buffers_release>
    9988:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc88>
    998c:	f947e863 	ldr	x3, [x3, #4048]
    9990:	d2800262 	mov	x2, #0x13                  	// #19
    9994:	d2800021 	mov	x1, #0x1                   	// #1
    9998:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1d60>
    999c:	912de000 	add	x0, x0, #0xb78
    99a0:	f9400063 	ldr	x3, [x3]
    99a4:	97ffe3d7 	bl	2900 <fwrite@plt>
    99a8:	d2800000 	mov	x0, #0x0                   	// #0
    99ac:	97ffe3e1 	bl	2930 <fflush@plt>
    99b0:	52800cc0 	mov	w0, #0x66                  	// #102
    99b4:	97ffe3ef 	bl	2970 <_Exit@plt>
    99b8:	f100007f 	cmp	x3, #0x0
    99bc:	fa4018c0 	ccmp	x6, #0x0, #0x0, ne	// ne = any
    99c0:	54fffda0 	b.eq	9974 <fwp_main_thread+0x16d4>  // b.none
    99c4:	b4fff5a3 	cbz	x3, 9878 <fwp_main_thread+0x15d8>
    99c8:	d37df062 	lsl	x2, x3, #3
    99cc:	aa0603e0 	mov	x0, x6
    99d0:	52800001 	mov	w1, #0x0                   	// #0
    99d4:	f90013e3 	str	x3, [sp, #32]
    99d8:	f9001fe7 	str	x7, [sp, #56]
    99dc:	97ffe37d 	bl	27d0 <memset@plt>
    99e0:	f94013e3 	ldr	x3, [sp, #32]
    99e4:	aa0003e6 	mov	x6, x0
    99e8:	f9401fe7 	ldr	x7, [sp, #56]
    99ec:	17ffffa3 	b	9878 <fwp_main_thread+0x15d8>
    99f0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    99f4:	eb0000ff 	cmp	x7, x0
    99f8:	54000e68 	b.hi	9bc4 <fwp_main_thread+0x1924>  // b.pmore
    99fc:	910004e0 	add	x0, x7, #0x1
    9a00:	52800041 	mov	w1, #0x2                   	// #2
    9a04:	a9021be7 	stp	x7, x6, [sp, #32]
    9a08:	d37df000 	lsl	x0, x0, #3
    9a0c:	97ffec75 	bl	4be0 <fwp_heap_alloc>
    9a10:	aa0003fc 	mov	x28, x0
    9a14:	a9421be7 	ldp	x7, x6, [sp, #32]
    9a18:	d2800001 	mov	x1, #0x0                   	// #0
    9a1c:	f8008407 	str	x7, [x0], #8
    9a20:	14000004 	b	9a30 <fwp_main_thread+0x1790>
    9a24:	f86178c2 	ldr	x2, [x6, x1, lsl #3]
    9a28:	f8217802 	str	x2, [x0, x1, lsl #3]
    9a2c:	91000421 	add	x1, x1, #0x1
    9a30:	eb0100ff 	cmp	x7, x1
    9a34:	54ffff81 	b.ne	9a24 <fwp_main_thread+0x1784>  // b.any
    9a38:	9100c281 	add	x1, x20, #0x30
    9a3c:	f9401be2 	ldr	x2, [sp, #48]
    9a40:	f9415820 	ldr	x0, [x1, #688]
    9a44:	eb02001f 	cmp	x0, x2
    9a48:	54004fc1 	b.ne	a440 <fwp_main_thread+0x21a0>  // b.any
    9a4c:	f94047e2 	ldr	x2, [sp, #136]
    9a50:	aa1503e0 	mov	x0, x21
    9a54:	f9015822 	str	x2, [x1, #688]
    9a58:	97ffe8a6 	bl	3cf0 <fwp_tape_buffers_release>
    9a5c:	9114c260 	add	x0, x19, #0x530
    9a60:	f949d801 	ldr	x1, [x0, #5040]
    9a64:	f949ec02 	ldr	x2, [x0, #5080]
    9a68:	cb010381 	sub	x1, x28, x1
    9a6c:	eb02403f 	cmp	x1, x2, lsl #16
    9a70:	54000322 	b.cs	9ad4 <fwp_main_thread+0x1834>  // b.hs, b.nlast
    9a74:	d350fc22 	lsr	x2, x1, #16
    9a78:	d2800503 	mov	x3, #0x28                  	// #40
    9a7c:	f949fc05 	ldr	x5, [x0, #5112]
    9a80:	9b037c42 	mul	x2, x2, x3
    9a84:	8b0200a3 	add	x3, x5, x2
    9a88:	f9401060 	ldr	x0, [x3, #32]
    9a8c:	b4000240 	cbz	x0, 9ad4 <fwp_main_thread+0x1834>
    9a90:	386268a2 	ldrb	w2, [x5, x2]
    9a94:	7100085f 	cmp	w2, #0x2
    9a98:	54000a40 	b.eq	9be0 <fwp_main_thread+0x1940>  // b.none
    9a9c:	7100045f 	cmp	w2, #0x1
    9aa0:	540001a1 	b.ne	9ad4 <fwp_main_thread+0x1834>  // b.any
    9aa4:	29430865 	ldp	w5, w2, [x3, #24]
    9aa8:	92403c21 	and	x1, x1, #0xffff
    9aac:	9b057c21 	mul	x1, x1, x5
    9ab0:	d360fc21 	lsr	x1, x1, #32
    9ab4:	eb02003f 	cmp	x1, x2
    9ab8:	540000e2 	b.cs	9ad4 <fwp_main_thread+0x1834>  // b.hs, b.nlast
    9abc:	8b010000 	add	x0, x0, x1
    9ac0:	39400001 	ldrb	w1, [x0]
    9ac4:	7103fc3f 	cmp	w1, #0xff
    9ac8:	54000840 	b.eq	9bd0 <fwp_main_thread+0x1930>  // b.none
    9acc:	52800021 	mov	w1, #0x1                   	// #1
    9ad0:	39000001 	strb	w1, [x0]
    9ad4:	9100c281 	add	x1, x20, #0x30
    9ad8:	f94007e2 	ldr	x2, [sp, #8]
    9adc:	f9415820 	ldr	x0, [x1, #688]
    9ae0:	eb02001f 	cmp	x0, x2
    9ae4:	54004ae1 	b.ne	a440 <fwp_main_thread+0x21a0>  // b.any
    9ae8:	f94003e0 	ldr	x0, [sp]
    9aec:	f9403be2 	ldr	x2, [sp, #112]
    9af0:	f9015822 	str	x2, [x1, #688]
    9af4:	97fff1b3 	bl	61c0 <fwp_tape_scope_release>
    9af8:	f9400380 	ldr	x0, [x28]
    9afc:	9240f803 	and	x3, x0, #0x7fffffffffffffff
    9b00:	b7f80960 	tbnz	x0, #63, 9c2c <fwp_main_thread+0x198c>
    9b04:	9114c261 	add	x1, x19, #0x530
    9b08:	f949d820 	ldr	x0, [x1, #5040]
    9b0c:	f949ec22 	ldr	x2, [x1, #5080]
    9b10:	cb000380 	sub	x0, x28, x0
    9b14:	eb02401f 	cmp	x0, x2, lsl #16
    9b18:	540008a2 	b.cs	9c2c <fwp_main_thread+0x198c>  // b.hs, b.nlast
    9b1c:	d350fc02 	lsr	x2, x0, #16
    9b20:	d2800505 	mov	x5, #0x28                  	// #40
    9b24:	f949fc26 	ldr	x6, [x1, #5112]
    9b28:	9b057c42 	mul	x2, x2, x5
    9b2c:	8b0200c5 	add	x5, x6, x2
    9b30:	f94010a1 	ldr	x1, [x5, #32]
    9b34:	b40007c1 	cbz	x1, 9c2c <fwp_main_thread+0x198c>
    9b38:	386268c2 	ldrb	w2, [x6, x2]
    9b3c:	7100085f 	cmp	w2, #0x2
    9b40:	54000720 	b.eq	9c24 <fwp_main_thread+0x1984>  // b.none
    9b44:	7100045f 	cmp	w2, #0x1
    9b48:	54000721 	b.ne	9c2c <fwp_main_thread+0x198c>  // b.any
    9b4c:	294308a6 	ldp	w6, w2, [x5, #24]
    9b50:	92403c00 	and	x0, x0, #0xffff
    9b54:	9b067c00 	mul	x0, x0, x6
    9b58:	d360fc00 	lsr	x0, x0, #32
    9b5c:	eb02001f 	cmp	x0, x2
    9b60:	54000662 	b.cs	9c2c <fwp_main_thread+0x198c>  // b.hs, b.nlast
    9b64:	8b000021 	add	x1, x1, x0
    9b68:	39400020 	ldrb	w0, [x1]
    9b6c:	7100041f 	cmp	w0, #0x1
    9b70:	540005e1 	b.ne	9c2c <fwp_main_thread+0x198c>  // b.any
    9b74:	aa1c03e2 	mov	x2, x28
    9b78:	d2800000 	mov	x0, #0x0                   	// #0
    9b7c:	d0000004 	adrp	x4, b000 <_IO_stdin_used+0x490>
    9b80:	91002387 	add	x7, x28, #0x8
    9b84:	d2800001 	mov	x1, #0x0                   	// #0
    9b88:	fd444881 	ldr	d1, [x4, #2192]
    9b8c:	eb01007f 	cmp	x3, x1
    9b90:	54000380 	b.eq	9c00 <fwp_main_thread+0x1960>  // b.none
    9b94:	f9400385 	ldr	x5, [x28]
    9b98:	b7f80305 	tbnz	x5, #63, 9bf8 <fwp_main_thread+0x1958>
    9b9c:	aa0703e6 	mov	x6, x7
    9ba0:	f9400048 	ldr	x8, [x2]
    9ba4:	d37df025 	lsl	x5, x1, #3
    9ba8:	fc6568c0 	ldr	d0, [x6, x5]
    9bac:	b7f80208 	tbnz	x8, #63, 9bec <fwp_main_thread+0x194c>
    9bb0:	1e600820 	fmul	d0, d1, d0
    9bb4:	8b050045 	add	x5, x2, x5
    9bb8:	91000421 	add	x1, x1, #0x1
    9bbc:	fd0004a0 	str	d0, [x5, #8]
    9bc0:	17fffff3 	b	9b8c <fwp_main_thread+0x18ec>
    9bc4:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x490>
    9bc8:	91034000 	add	x0, x0, #0xd0
    9bcc:	97ffe88d 	bl	3e00 <fwp_trap>
    9bd0:	f90013e0 	str	x0, [sp, #32]
    9bd4:	97ffe8ab 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9bd8:	f94013e0 	ldr	x0, [sp, #32]
    9bdc:	17ffffbc 	b	9acc <fwp_main_thread+0x182c>
    9be0:	72003c3f 	tst	w1, #0xffff
    9be4:	54fff781 	b.ne	9ad4 <fwp_main_thread+0x1834>  // b.any
    9be8:	17ffffb6 	b	9ac0 <fwp_main_thread+0x1820>
    9bec:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x490>
    9bf0:	91038000 	add	x0, x0, #0xe0
    9bf4:	97ffe883 	bl	3e00 <fwp_trap>
    9bf8:	f9400b86 	ldr	x6, [x28, #16]
    9bfc:	17ffffe9 	b	9ba0 <fwp_main_thread+0x1900>
    9c00:	f90013e2 	str	x2, [sp, #32]
    9c04:	97fff37b 	bl	69f0 <fwp_drop10>
    9c08:	f94013e2 	ldr	x2, [sp, #32]
    9c0c:	aa1803e0 	mov	x0, x24
    9c10:	d2800006 	mov	x6, #0x0                   	// #0
    9c14:	b4000620 	cbz	x0, 9cd8 <fwp_main_thread+0x1a38>
    9c18:	f9400800 	ldr	x0, [x0, #16]
    9c1c:	910004c6 	add	x6, x6, #0x1
    9c20:	17fffffd 	b	9c14 <fwp_main_thread+0x1974>
    9c24:	72003c1f 	tst	w0, #0xffff
    9c28:	54fffa00 	b.eq	9b68 <fwp_main_thread+0x18c8>  // b.none
    9c2c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9c30:	eb00007f 	cmp	x3, x0
    9c34:	54fffc88 	b.hi	9bc4 <fwp_main_thread+0x1924>  // b.pmore
    9c38:	91000460 	add	x0, x3, #0x1
    9c3c:	52800021 	mov	w1, #0x1                   	// #1
    9c40:	f90013e3 	str	x3, [sp, #32]
    9c44:	d37df000 	lsl	x0, x0, #3
    9c48:	97ffebe6 	bl	4be0 <fwp_heap_alloc>
    9c4c:	f94013e3 	ldr	x3, [sp, #32]
    9c50:	9114c266 	add	x6, x19, #0x530
    9c54:	f9000003 	str	x3, [x0]
    9c58:	aa0003e2 	mov	x2, x0
    9c5c:	f949d8c1 	ldr	x1, [x6, #5040]
    9c60:	f949ecc0 	ldr	x0, [x6, #5080]
    9c64:	cb010041 	sub	x1, x2, x1
    9c68:	eb00403f 	cmp	x1, x0, lsl #16
    9c6c:	54000322 	b.cs	9cd0 <fwp_main_thread+0x1a30>  // b.hs, b.nlast
    9c70:	d350fc25 	lsr	x5, x1, #16
    9c74:	d2800500 	mov	x0, #0x28                  	// #40
    9c78:	f949fcc7 	ldr	x7, [x6, #5112]
    9c7c:	9b007ca5 	mul	x5, x5, x0
    9c80:	8b0500e6 	add	x6, x7, x5
    9c84:	f94010c0 	ldr	x0, [x6, #32]
    9c88:	b4000240 	cbz	x0, 9cd0 <fwp_main_thread+0x1a30>
    9c8c:	386568e5 	ldrb	w5, [x7, x5]
    9c90:	710008bf 	cmp	w5, #0x2
    9c94:	540036a0 	b.eq	a368 <fwp_main_thread+0x20c8>  // b.none
    9c98:	710004bf 	cmp	w5, #0x1
    9c9c:	540001a1 	b.ne	9cd0 <fwp_main_thread+0x1a30>  // b.any
    9ca0:	294314c7 	ldp	w7, w5, [x6, #24]
    9ca4:	92403c21 	and	x1, x1, #0xffff
    9ca8:	9b077c21 	mul	x1, x1, x7
    9cac:	d360fc21 	lsr	x1, x1, #32
    9cb0:	eb05003f 	cmp	x1, x5
    9cb4:	540000e2 	b.cs	9cd0 <fwp_main_thread+0x1a30>  // b.hs, b.nlast
    9cb8:	8b010000 	add	x0, x0, x1
    9cbc:	39400001 	ldrb	w1, [x0]
    9cc0:	7103fc3f 	cmp	w1, #0xff
    9cc4:	54000720 	b.eq	9da8 <fwp_main_thread+0x1b08>  // b.none
    9cc8:	52800021 	mov	w1, #0x1                   	// #1
    9ccc:	39000001 	strb	w1, [x0]
    9cd0:	aa1c03e0 	mov	x0, x28
    9cd4:	17ffffaa 	b	9b7c <fwp_main_thread+0x18dc>
    9cd8:	f9400040 	ldr	x0, [x2]
    9cdc:	9240f805 	and	x5, x0, #0x7fffffffffffffff
    9ce0:	b7f83380 	tbnz	x0, #63, a350 <fwp_main_thread+0x20b0>
    9ce4:	9114c261 	add	x1, x19, #0x530
    9ce8:	f949d820 	ldr	x0, [x1, #5040]
    9cec:	f949ec23 	ldr	x3, [x1, #5080]
    9cf0:	cb000040 	sub	x0, x2, x0
    9cf4:	eb03401f 	cmp	x0, x3, lsl #16
    9cf8:	540032c2 	b.cs	a350 <fwp_main_thread+0x20b0>  // b.hs, b.nlast
    9cfc:	d350fc03 	lsr	x3, x0, #16
    9d00:	d2800507 	mov	x7, #0x28                  	// #40
    9d04:	f949fc28 	ldr	x8, [x1, #5112]
    9d08:	9b077c63 	mul	x3, x3, x7
    9d0c:	8b030107 	add	x7, x8, x3
    9d10:	f94010e1 	ldr	x1, [x7, #32]
    9d14:	b40031e1 	cbz	x1, a350 <fwp_main_thread+0x20b0>
    9d18:	38636903 	ldrb	w3, [x8, x3]
    9d1c:	7100087f 	cmp	w3, #0x2
    9d20:	54003140 	b.eq	a348 <fwp_main_thread+0x20a8>  // b.none
    9d24:	7100047f 	cmp	w3, #0x1
    9d28:	54003141 	b.ne	a350 <fwp_main_thread+0x20b0>  // b.any
    9d2c:	29430ce8 	ldp	w8, w3, [x7, #24]
    9d30:	92403c00 	and	x0, x0, #0xffff
    9d34:	9b087c00 	mul	x0, x0, x8
    9d38:	d360fc00 	lsr	x0, x0, #32
    9d3c:	eb03001f 	cmp	x0, x3
    9d40:	54003082 	b.cs	a350 <fwp_main_thread+0x20b0>  // b.hs, b.nlast
    9d44:	8b000021 	add	x1, x1, x0
    9d48:	39400020 	ldrb	w0, [x1]
    9d4c:	7100041f 	cmp	w0, #0x1
    9d50:	54003001 	b.ne	a350 <fwp_main_thread+0x20b0>  // b.any
    9d54:	91002043 	add	x3, x2, #0x8
    9d58:	b9002be0 	str	w0, [sp, #40]
    9d5c:	eb0600bf 	cmp	x5, x6
    9d60:	aa1803e1 	mov	x1, x24
    9d64:	9a8690a5 	csel	x5, x5, x6, ls	// ls = plast
    9d68:	91002047 	add	x7, x2, #0x8
    9d6c:	d2800000 	mov	x0, #0x0                   	// #0
    9d70:	14000008 	b	9d90 <fwp_main_thread+0x1af0>
    9d74:	aa0703e6 	mov	x6, x7
    9d78:	fc6078c1 	ldr	d1, [x6, x0, lsl #3]
    9d7c:	fd400420 	ldr	d0, [x1, #8]
    9d80:	1e613800 	fsub	d0, d0, d1
    9d84:	fc207860 	str	d0, [x3, x0, lsl #3]
    9d88:	91000400 	add	x0, x0, #0x1
    9d8c:	f9400821 	ldr	x1, [x1, #16]
    9d90:	eb05001f 	cmp	x0, x5
    9d94:	54000160 	b.eq	9dc0 <fwp_main_thread+0x1b20>  // b.none
    9d98:	f9400046 	ldr	x6, [x2]
    9d9c:	b6fffec6 	tbz	x6, #63, 9d74 <fwp_main_thread+0x1ad4>
    9da0:	f9400846 	ldr	x6, [x2, #16]
    9da4:	17fffff5 	b	9d78 <fwp_main_thread+0x1ad8>
    9da8:	a9020be0 	stp	x0, x2, [sp, #32]
    9dac:	f9001be3 	str	x3, [sp, #48]
    9db0:	97ffe834 	bl	3e80 <fwp_rc_forget_slot.part.0>
    9db4:	a9420be0 	ldp	x0, x2, [sp, #32]
    9db8:	f9401be3 	ldr	x3, [sp, #48]
    9dbc:	17ffffc3 	b	9cc8 <fwp_main_thread+0x1a28>
    9dc0:	9114c260 	add	x0, x19, #0x530
    9dc4:	aa1803e1 	mov	x1, x24
    9dc8:	d2800006 	mov	x6, #0x0                   	// #0
    9dcc:	d280050b 	mov	x11, #0x28                  	// #40
    9dd0:	f949ec09 	ldr	x9, [x0, #5080]
    9dd4:	f949d80c 	ldr	x12, [x0, #5040]
    9dd8:	f949fc0d 	ldr	x13, [x0, #5112]
    9ddc:	d370bd29 	lsl	x9, x9, #16
    9de0:	14000003 	b	9dec <fwp_main_thread+0x1b4c>
    9de4:	f9400821 	ldr	x1, [x1, #16]
    9de8:	910004c6 	add	x6, x6, #0x1
    9dec:	f100003f 	cmp	x1, #0x0
    9df0:	fa4510c2 	ccmp	x6, x5, #0x2, ne	// ne = any
    9df4:	54000302 	b.cs	9e54 <fwp_main_thread+0x1bb4>  // b.hs, b.nlast
    9df8:	cb0c0020 	sub	x0, x1, x12
    9dfc:	eb09001f 	cmp	x0, x9
    9e00:	540002a2 	b.cs	9e54 <fwp_main_thread+0x1bb4>  // b.hs, b.nlast
    9e04:	d350fc08 	lsr	x8, x0, #16
    9e08:	9b0b7d08 	mul	x8, x8, x11
    9e0c:	8b0801aa 	add	x10, x13, x8
    9e10:	f9401147 	ldr	x7, [x10, #32]
    9e14:	b4000207 	cbz	x7, 9e54 <fwp_main_thread+0x1bb4>
    9e18:	386869a8 	ldrb	w8, [x13, x8]
    9e1c:	7100091f 	cmp	w8, #0x2
    9e20:	54000f60 	b.eq	a00c <fwp_main_thread+0x1d6c>  // b.none
    9e24:	7100051f 	cmp	w8, #0x1
    9e28:	54000161 	b.ne	9e54 <fwp_main_thread+0x1bb4>  // b.any
    9e2c:	2943214e 	ldp	w14, w8, [x10, #24]
    9e30:	92403c00 	and	x0, x0, #0xffff
    9e34:	9b0e7c00 	mul	x0, x0, x14
    9e38:	d360fc00 	lsr	x0, x0, #32
    9e3c:	eb08001f 	cmp	x0, x8
    9e40:	540000a2 	b.cs	9e54 <fwp_main_thread+0x1bb4>  // b.hs, b.nlast
    9e44:	8b0000e7 	add	x7, x7, x0
    9e48:	394000e0 	ldrb	w0, [x7]
    9e4c:	7100041f 	cmp	w0, #0x1
    9e50:	54fffca0 	b.eq	9de4 <fwp_main_thread+0x1b44>  // b.none
    9e54:	d280001c 	mov	x28, #0x0                   	// #0
    9e58:	eb0500df 	cmp	x6, x5
    9e5c:	540005c2 	b.cs	9f14 <fwp_main_thread+0x1c74>  // b.hs, b.nlast
    9e60:	d1002067 	sub	x7, x3, #0x8
    9e64:	aa1603e1 	mov	x1, x22
    9e68:	52800020 	mov	w0, #0x1                   	// #1
    9e6c:	f90013e5 	str	x5, [sp, #32]
    9e70:	a9030be3 	stp	x3, x2, [sp, #48]
    9e74:	f86578e7 	ldr	x7, [x7, x5, lsl #3]
    9e78:	f90023e6 	str	x6, [sp, #64]
    9e7c:	a91273e7 	stp	x7, x28, [sp, #288]
    9e80:	97ffeb9d 	bl	4cf4 <fwp_data.part.0.constprop.0>
    9e84:	aa0003fc 	mov	x28, x0
    9e88:	9114c268 	add	x8, x19, #0x530
    9e8c:	f94013e5 	ldr	x5, [sp, #32]
    9e90:	f949d901 	ldr	x1, [x8, #5040]
    9e94:	f949ed00 	ldr	x0, [x8, #5080]
    9e98:	cb010381 	sub	x1, x28, x1
    9e9c:	a9430be3 	ldp	x3, x2, [sp, #48]
    9ea0:	f94023e6 	ldr	x6, [sp, #64]
    9ea4:	eb00403f 	cmp	x1, x0, lsl #16
    9ea8:	54000322 	b.cs	9f0c <fwp_main_thread+0x1c6c>  // b.hs, b.nlast
    9eac:	d350fc27 	lsr	x7, x1, #16
    9eb0:	d2800500 	mov	x0, #0x28                  	// #40
    9eb4:	f949fd09 	ldr	x9, [x8, #5112]
    9eb8:	9b007ce7 	mul	x7, x7, x0
    9ebc:	8b070128 	add	x8, x9, x7
    9ec0:	f9401100 	ldr	x0, [x8, #32]
    9ec4:	b4000240 	cbz	x0, 9f0c <fwp_main_thread+0x1c6c>
    9ec8:	38676927 	ldrb	w7, [x9, x7]
    9ecc:	710008ff 	cmp	w7, #0x2
    9ed0:	54002640 	b.eq	a398 <fwp_main_thread+0x20f8>  // b.none
    9ed4:	710004ff 	cmp	w7, #0x1
    9ed8:	540001a1 	b.ne	9f0c <fwp_main_thread+0x1c6c>  // b.any
    9edc:	29431d09 	ldp	w9, w7, [x8, #24]
    9ee0:	92403c21 	and	x1, x1, #0xffff
    9ee4:	9b097c21 	mul	x1, x1, x9
    9ee8:	d360fc21 	lsr	x1, x1, #32
    9eec:	eb07003f 	cmp	x1, x7
    9ef0:	540000e2 	b.cs	9f0c <fwp_main_thread+0x1c6c>  // b.hs, b.nlast
    9ef4:	8b010000 	add	x0, x0, x1
    9ef8:	39400001 	ldrb	w1, [x0]
    9efc:	7103fc3f 	cmp	w1, #0xff
    9f00:	540023c0 	b.eq	a378 <fwp_main_thread+0x20d8>  // b.none
    9f04:	52800021 	mov	w1, #0x1                   	// #1
    9f08:	39000001 	strb	w1, [x0]
    9f0c:	d10004a5 	sub	x5, x5, #0x1
    9f10:	17ffffd2 	b	9e58 <fwp_main_thread+0x1bb8>
    9f14:	f90013f8 	str	x24, [sp, #32]
    9f18:	b40001a6 	cbz	x6, 9f4c <fwp_main_thread+0x1cac>
    9f1c:	d2800000 	mov	x0, #0x0                   	// #0
    9f20:	f94013e4 	ldr	x4, [sp, #32]
    9f24:	f8607861 	ldr	x1, [x3, x0, lsl #3]
    9f28:	91000400 	add	x0, x0, #0x1
    9f2c:	f9000481 	str	x1, [x4, #8]
    9f30:	aa0403e1 	mov	x1, x4
    9f34:	f9400884 	ldr	x4, [x4, #16]
    9f38:	f90013e4 	str	x4, [sp, #32]
    9f3c:	eb0000df 	cmp	x6, x0
    9f40:	54ffff01 	b.ne	9f20 <fwp_main_thread+0x1c80>  // b.any
    9f44:	f900083c 	str	x28, [x1, #16]
    9f48:	aa1803fc 	mov	x28, x24
    9f4c:	b9402be0 	ldr	w0, [sp, #40]
    9f50:	9114c267 	add	x7, x19, #0x530
    9f54:	92800005 	mov	x5, #0xffffffffffffffff    	// #-1
    9f58:	7100001f 	cmp	w0, #0x0
    9f5c:	9a9f0063 	csel	x3, x3, xzr, eq	// eq = none
    9f60:	b10004bf 	cmn	x5, #0x1
    9f64:	54ff80c0 	b.eq	8f7c <fwp_main_thread+0xcdc>  // b.none
    9f68:	f8657860 	ldr	x0, [x3, x5, lsl #3]
    9f6c:	aa1603e1 	mov	x1, x22
    9f70:	a9028fe5 	stp	x5, x3, [sp, #40]
    9f74:	a9039fe2 	stp	x2, x7, [sp, #56]
    9f78:	a91273e0 	stp	x0, x28, [sp, #288]
    9f7c:	52800020 	mov	w0, #0x1                   	// #1
    9f80:	97ffeb5d 	bl	4cf4 <fwp_data.part.0.constprop.0>
    9f84:	a9439fe2 	ldp	x2, x7, [sp, #56]
    9f88:	aa0003fc 	mov	x28, x0
    9f8c:	a9428fe5 	ldp	x5, x3, [sp, #40]
    9f90:	f949d8e1 	ldr	x1, [x7, #5040]
    9f94:	f949ece0 	ldr	x0, [x7, #5080]
    9f98:	cb010381 	sub	x1, x28, x1
    9f9c:	eb00403f 	cmp	x1, x0, lsl #16
    9fa0:	54000322 	b.cs	a004 <fwp_main_thread+0x1d64>  // b.hs, b.nlast
    9fa4:	d350fc26 	lsr	x6, x1, #16
    9fa8:	d2800500 	mov	x0, #0x28                  	// #40
    9fac:	f949fce9 	ldr	x9, [x7, #5112]
    9fb0:	9b007cc6 	mul	x6, x6, x0
    9fb4:	8b060128 	add	x8, x9, x6
    9fb8:	f9401100 	ldr	x0, [x8, #32]
    9fbc:	b4000240 	cbz	x0, a004 <fwp_main_thread+0x1d64>
    9fc0:	38666926 	ldrb	w6, [x9, x6]
    9fc4:	710008df 	cmp	w6, #0x2
    9fc8:	54002000 	b.eq	a3c8 <fwp_main_thread+0x2128>  // b.none
    9fcc:	710004df 	cmp	w6, #0x1
    9fd0:	540001a1 	b.ne	a004 <fwp_main_thread+0x1d64>  // b.any
    9fd4:	29431909 	ldp	w9, w6, [x8, #24]
    9fd8:	92403c21 	and	x1, x1, #0xffff
    9fdc:	9b097c21 	mul	x1, x1, x9
    9fe0:	d360fc21 	lsr	x1, x1, #32
    9fe4:	eb06003f 	cmp	x1, x6
    9fe8:	540000e2 	b.cs	a004 <fwp_main_thread+0x1d64>  // b.hs, b.nlast
    9fec:	8b010000 	add	x0, x0, x1
    9ff0:	39400001 	ldrb	w1, [x0]
    9ff4:	7103fc3f 	cmp	w1, #0xff
    9ff8:	54001d80 	b.eq	a3a8 <fwp_main_thread+0x2108>  // b.none
    9ffc:	52800021 	mov	w1, #0x1                   	// #1
    a000:	39000001 	strb	w1, [x0]
    a004:	d10004a5 	sub	x5, x5, #0x1
    a008:	17ffffd6 	b	9f60 <fwp_main_thread+0x1cc0>
    a00c:	72003c1f 	tst	w0, #0xffff
    a010:	54fff221 	b.ne	9e54 <fwp_main_thread+0x1bb4>  // b.any
    a014:	17ffff8d 	b	9e48 <fwp_main_thread+0x1ba8>
    a018:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x490>
    a01c:	91042000 	add	x0, x0, #0x108
    a020:	97ffe778 	bl	3e00 <fwp_trap>
    a024:	f94013e0 	ldr	x0, [sp, #32]
    a028:	97ffedf6 	bl	5800 <fwp_rc_free_arr>
    a02c:	17fffc88 	b	924c <fwp_main_thread+0xfac>
    a030:	72003c3f 	tst	w1, #0xffff
    a034:	54ff90c1 	b.ne	924c <fwp_main_thread+0xfac>  // b.any
    a038:	17fffc7d 	b	922c <fwp_main_thread+0xf8c>
    a03c:	72003c3f 	tst	w1, #0xffff
    a040:	54ff8ac1 	b.ne	9198 <fwp_main_thread+0xef8>  // b.any
    a044:	17fffc50 	b	9184 <fwp_main_thread+0xee4>
    a048:	ca5c4781 	eor	x1, x28, x28, lsr #17
    a04c:	9114c260 	add	x0, x19, #0x530
    a050:	ca412421 	eor	x1, x1, x1, lsr #9
    a054:	92401c21 	and	x1, x1, #0xff
    a058:	910a2422 	add	x2, x1, #0x289
    a05c:	8b010c01 	add	x1, x0, x1, lsl #3
    a060:	8b020c02 	add	x2, x0, x2, lsl #3
    a064:	f94a2420 	ldr	x0, [x1, #5192]
    a068:	b4ffc7a0 	cbz	x0, 995c <fwp_main_thread+0x16bc>
    a06c:	f9400001 	ldr	x1, [x0]
    a070:	eb1c003f 	cmp	x1, x28
    a074:	54000100 	b.eq	a094 <fwp_main_thread+0x1df4>  // b.none
    a078:	91004002 	add	x2, x0, #0x10
    a07c:	f9400800 	ldr	x0, [x0, #16]
    a080:	17fffffa 	b	a068 <fwp_main_thread+0x1dc8>
    a084:	f9001be0 	str	x0, [sp, #48]
    a088:	97ffe77e 	bl	3e80 <fwp_rc_forget_slot.part.0>
    a08c:	f9401be0 	ldr	x0, [sp, #48]
    a090:	17fffc40 	b	9190 <fwp_main_thread+0xef0>
    a094:	f9400041 	ldr	x1, [x2]
    a098:	f9400420 	ldr	x0, [x1, #8]
    a09c:	d1000400 	sub	x0, x0, #0x1
    a0a0:	f9000420 	str	x0, [x1, #8]
    a0a4:	f103f81f 	cmp	x0, #0xfe
    a0a8:	54ff8d21 	b.ne	924c <fwp_main_thread+0xfac>  // b.any
    a0ac:	39400380 	ldrb	w0, [x28]
    a0b0:	7103fc1f 	cmp	w0, #0xff
    a0b4:	54000260 	b.eq	a100 <fwp_main_thread+0x1e60>  // b.none
    a0b8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a0bc:	39000380 	strb	w0, [x28]
    a0c0:	17fffc63 	b	924c <fwp_main_thread+0xfac>
    a0c4:	f9400045 	ldr	x5, [x2]
    a0c8:	aa0203e0 	mov	x0, x2
    a0cc:	b7f80245 	tbnz	x5, #63, a114 <fwp_main_thread+0x1e74>
    a0d0:	710008df 	cmp	w6, #0x2
    a0d4:	540001c0 	b.eq	a10c <fwp_main_thread+0x1e6c>  // b.none
    a0d8:	29430065 	ldp	w5, w0, [x3, #24]
    a0dc:	9b057c21 	mul	x1, x1, x5
    a0e0:	eb41801f 	cmp	x0, x1, lsr #32
    a0e4:	54ff7969 	b.ls	9010 <fwp_main_thread+0xd70>  // b.plast
    a0e8:	aa0203e0 	mov	x0, x2
    a0ec:	97ffe801 	bl	40f0 <fwp_mem_free>
    a0f0:	17fffbc8 	b	9010 <fwp_main_thread+0xd70>
    a0f4:	f2403c21 	ands	x1, x1, #0xffff
    a0f8:	54ff78c1 	b.ne	9010 <fwp_main_thread+0xd70>  // b.any
    a0fc:	17fffbbd 	b	8ff0 <fwp_main_thread+0xd50>
    a100:	aa1c03e0 	mov	x0, x28
    a104:	97ffe75f 	bl	3e80 <fwp_rc_forget_slot.part.0>
    a108:	17ffffec 	b	a0b8 <fwp_main_thread+0x1e18>
    a10c:	b5ff7821 	cbnz	x1, 9010 <fwp_main_thread+0xd70>
    a110:	17fffff6 	b	a0e8 <fwp_main_thread+0x1e48>
    a114:	f9400442 	ldr	x2, [x2, #8]
    a118:	710008df 	cmp	w6, #0x2
    a11c:	54000740 	b.eq	a204 <fwp_main_thread+0x1f64>  // b.none
    a120:	29430c65 	ldp	w5, w3, [x3, #24]
    a124:	9b057c21 	mul	x1, x1, x5
    a128:	eb41807f 	cmp	x3, x1, lsr #32
    a12c:	54ff7349 	b.ls	8f94 <fwp_main_thread+0xcf4>  // b.plast
    a130:	a9029fe2 	stp	x2, x7, [sp, #40]
    a134:	97ffe7ef 	bl	40f0 <fwp_mem_free>
    a138:	d2800508 	mov	x8, #0x28                  	// #40
    a13c:	a9429fe2 	ldp	x2, x7, [sp, #40]
    a140:	17fffb95 	b	8f94 <fwp_main_thread+0xcf4>
    a144:	ca404401 	eor	x1, x0, x0, lsr #17
    a148:	9114c263 	add	x3, x19, #0x530
    a14c:	ca412421 	eor	x1, x1, x1, lsr #9
    a150:	92401c21 	and	x1, x1, #0xff
    a154:	910a2422 	add	x2, x1, #0x289
    a158:	8b010c61 	add	x1, x3, x1, lsl #3
    a15c:	8b020c62 	add	x2, x3, x2, lsl #3
    a160:	f94a2421 	ldr	x1, [x1, #5192]
    a164:	b4ffbfc1 	cbz	x1, 995c <fwp_main_thread+0x16bc>
    a168:	f9400023 	ldr	x3, [x1]
    a16c:	eb00007f 	cmp	x3, x0
    a170:	54000520 	b.eq	a214 <fwp_main_thread+0x1f74>  // b.none
    a174:	91004022 	add	x2, x1, #0x10
    a178:	f9400821 	ldr	x1, [x1, #16]
    a17c:	17fffffa 	b	a164 <fwp_main_thread+0x1ec4>
    a180:	f94013e2 	ldr	x2, [sp, #32]
    a184:	aa0203e0 	mov	x0, x2
    a188:	f9400842 	ldr	x2, [x2, #16]
    a18c:	f90013e2 	str	x2, [sp, #32]
    a190:	710008df 	cmp	w6, #0x2
    a194:	540003c0 	b.eq	a20c <fwp_main_thread+0x1f6c>  // b.none
    a198:	29430866 	ldp	w6, w2, [x3, #24]
    a19c:	9b067c21 	mul	x1, x1, x6
    a1a0:	eb41805f 	cmp	x2, x1, lsr #32
    a1a4:	54ff73a9 	b.ls	9018 <fwp_main_thread+0xd78>  // b.plast
    a1a8:	f90017e5 	str	x5, [sp, #40]
    a1ac:	97ffe7d1 	bl	40f0 <fwp_mem_free>
    a1b0:	f94017e5 	ldr	x5, [sp, #40]
    a1b4:	d2800507 	mov	x7, #0x28                  	// #40
    a1b8:	17fffb98 	b	9018 <fwp_main_thread+0xd78>
    a1bc:	ca404401 	eor	x1, x0, x0, lsr #17
    a1c0:	9114c263 	add	x3, x19, #0x530
    a1c4:	ca412421 	eor	x1, x1, x1, lsr #9
    a1c8:	92401c21 	and	x1, x1, #0xff
    a1cc:	910a2422 	add	x2, x1, #0x289
    a1d0:	8b010c61 	add	x1, x3, x1, lsl #3
    a1d4:	8b020c62 	add	x2, x3, x2, lsl #3
    a1d8:	f94a2421 	ldr	x1, [x1, #5192]
    a1dc:	b4ffbc01 	cbz	x1, 995c <fwp_main_thread+0x16bc>
    a1e0:	f9400023 	ldr	x3, [x1]
    a1e4:	eb00007f 	cmp	x3, x0
    a1e8:	540002e0 	b.eq	a244 <fwp_main_thread+0x1fa4>  // b.none
    a1ec:	91004022 	add	x2, x1, #0x10
    a1f0:	f9400821 	ldr	x1, [x1, #16]
    a1f4:	17fffffa 	b	a1dc <fwp_main_thread+0x1f3c>
    a1f8:	f2403c21 	ands	x1, x1, #0xffff
    a1fc:	54ff74e1 	b.ne	9098 <fwp_main_thread+0xdf8>  // b.any
    a200:	17fffb9e 	b	9078 <fwp_main_thread+0xdd8>
    a204:	b5ff6c81 	cbnz	x1, 8f94 <fwp_main_thread+0xcf4>
    a208:	17ffffca 	b	a130 <fwp_main_thread+0x1e90>
    a20c:	b5ff7061 	cbnz	x1, 9018 <fwp_main_thread+0xd78>
    a210:	17ffffe6 	b	a1a8 <fwp_main_thread+0x1f08>
    a214:	f9400042 	ldr	x2, [x2]
    a218:	f9400441 	ldr	x1, [x2, #8]
    a21c:	d1000421 	sub	x1, x1, #0x1
    a220:	f9000441 	str	x1, [x2, #8]
    a224:	f103f83f 	cmp	x1, #0xfe
    a228:	54ff6f41 	b.ne	9010 <fwp_main_thread+0xd70>  // b.any
    a22c:	39400001 	ldrb	w1, [x0]
    a230:	7103fc3f 	cmp	w1, #0xff
    a234:	54000260 	b.eq	a280 <fwp_main_thread+0x1fe0>  // b.none
    a238:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a23c:	39000001 	strb	w1, [x0]
    a240:	17fffb74 	b	9010 <fwp_main_thread+0xd70>
    a244:	f9400042 	ldr	x2, [x2]
    a248:	f9400441 	ldr	x1, [x2, #8]
    a24c:	d1000421 	sub	x1, x1, #0x1
    a250:	f9000441 	str	x1, [x2, #8]
    a254:	f103f83f 	cmp	x1, #0xfe
    a258:	54ff7201 	b.ne	9098 <fwp_main_thread+0xdf8>  // b.any
    a25c:	39400001 	ldrb	w1, [x0]
    a260:	7103fc3f 	cmp	w1, #0xff
    a264:	54000081 	b.ne	a274 <fwp_main_thread+0x1fd4>  // b.any
    a268:	f90013e0 	str	x0, [sp, #32]
    a26c:	97ffe705 	bl	3e80 <fwp_rc_forget_slot.part.0>
    a270:	f94013e0 	ldr	x0, [sp, #32]
    a274:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a278:	39000001 	strb	w1, [x0]
    a27c:	17fffb87 	b	9098 <fwp_main_thread+0xdf8>
    a280:	f90017e0 	str	x0, [sp, #40]
    a284:	97ffe6ff 	bl	3e80 <fwp_rc_forget_slot.part.0>
    a288:	f94017e0 	ldr	x0, [sp, #40]
    a28c:	17ffffeb 	b	a238 <fwp_main_thread+0x1f98>
    a290:	ca404401 	eor	x1, x0, x0, lsr #17
    a294:	9114c263 	add	x3, x19, #0x530
    a298:	ca412421 	eor	x1, x1, x1, lsr #9
    a29c:	92401c21 	and	x1, x1, #0xff
    a2a0:	910a2422 	add	x2, x1, #0x289
    a2a4:	8b010c61 	add	x1, x3, x1, lsl #3
    a2a8:	8b020c62 	add	x2, x3, x2, lsl #3
    a2ac:	f94a2421 	ldr	x1, [x1, #5192]
    a2b0:	b4ffb561 	cbz	x1, 995c <fwp_main_thread+0x16bc>
    a2b4:	f9400023 	ldr	x3, [x1]
    a2b8:	eb00007f 	cmp	x3, x0
    a2bc:	54000120 	b.eq	a2e0 <fwp_main_thread+0x2040>  // b.none
    a2c0:	91004022 	add	x2, x1, #0x10
    a2c4:	f9400821 	ldr	x1, [x1, #16]
    a2c8:	17fffffa 	b	a2b0 <fwp_main_thread+0x2010>
    a2cc:	f90103f9 	str	x25, [sp, #512]
    a2d0:	f90107fa 	str	x26, [sp, #520]
    a2d4:	f9010bfb 	str	x27, [sp, #528]
    a2d8:	f9010ffc 	str	x28, [sp, #536]
    a2dc:	97ffe149 	bl	2800 <__stack_chk_fail@plt>
    a2e0:	f9400042 	ldr	x2, [x2]
    a2e4:	f9400441 	ldr	x1, [x2, #8]
    a2e8:	d1000421 	sub	x1, x1, #0x1
    a2ec:	f9000441 	str	x1, [x2, #8]
    a2f0:	f103f83f 	cmp	x1, #0xfe
    a2f4:	54ff8ea1 	b.ne	94c8 <fwp_main_thread+0x1228>  // b.any
    a2f8:	39400001 	ldrb	w1, [x0]
    a2fc:	7103fc3f 	cmp	w1, #0xff
    a300:	540000c0 	b.eq	a318 <fwp_main_thread+0x2078>  // b.none
    a304:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a308:	39000001 	strb	w1, [x0]
    a30c:	17fffc6f 	b	94c8 <fwp_main_thread+0x1228>
    a310:	f9001fff 	str	xzr, [sp, #56]
    a314:	17fffc44 	b	9424 <fwp_main_thread+0x1184>
    a318:	f90013e0 	str	x0, [sp, #32]
    a31c:	97ffe6d9 	bl	3e80 <fwp_rc_forget_slot.part.0>
    a320:	f94013e0 	ldr	x0, [sp, #32]
    a324:	17fffff8 	b	a304 <fwp_main_thread+0x2064>
    a328:	aa0203e0 	mov	x0, x2
    a32c:	d2800101 	mov	x1, #0x8                   	// #8
    a330:	f90013e2 	str	x2, [sp, #32]
    a334:	97ffe12b 	bl	27e0 <calloc@plt>
    a338:	f94013e2 	ldr	x2, [sp, #32]
    a33c:	aa0003e6 	mov	x6, x0
    a340:	a9438fe7 	ldp	x7, x3, [sp, #56]
    a344:	17fffd49 	b	9868 <fwp_main_thread+0x15c8>
    a348:	72003c1f 	tst	w0, #0xffff
    a34c:	54ffcfe0 	b.eq	9d48 <fwp_main_thread+0x1aa8>  // b.none
    a350:	aa1803fc 	mov	x28, x24
    a354:	d2800006 	mov	x6, #0x0                   	// #0
    a358:	b400041c 	cbz	x28, a3d8 <fwp_main_thread+0x2138>
    a35c:	f9400b9c 	ldr	x28, [x28, #16]
    a360:	910004c6 	add	x6, x6, #0x1
    a364:	17fffffd 	b	a358 <fwp_main_thread+0x20b8>
    a368:	72003c3f 	tst	w1, #0xffff
    a36c:	54ffca80 	b.eq	9cbc <fwp_main_thread+0x1a1c>  // b.none
    a370:	aa1c03e0 	mov	x0, x28
    a374:	17fffe02 	b	9b7c <fwp_main_thread+0x18dc>
    a378:	f90013e0 	str	x0, [sp, #32]
    a37c:	a9030be3 	stp	x3, x2, [sp, #48]
    a380:	a90417e6 	stp	x6, x5, [sp, #64]
    a384:	97ffe6bf 	bl	3e80 <fwp_rc_forget_slot.part.0>
    a388:	f94013e0 	ldr	x0, [sp, #32]
    a38c:	a9430be3 	ldp	x3, x2, [sp, #48]
    a390:	a94417e6 	ldp	x6, x5, [sp, #64]
    a394:	17fffedc 	b	9f04 <fwp_main_thread+0x1c64>
    a398:	72003c3f 	tst	w1, #0xffff
    a39c:	54ffdae0 	b.eq	9ef8 <fwp_main_thread+0x1c58>  // b.none
    a3a0:	d10004a5 	sub	x5, x5, #0x1
    a3a4:	17fffead 	b	9e58 <fwp_main_thread+0x1bb8>
    a3a8:	a9028fe0 	stp	x0, x3, [sp, #40]
    a3ac:	a90397e2 	stp	x2, x5, [sp, #56]
    a3b0:	f90027e7 	str	x7, [sp, #72]
    a3b4:	97ffe6b3 	bl	3e80 <fwp_rc_forget_slot.part.0>
    a3b8:	a9428fe0 	ldp	x0, x3, [sp, #40]
    a3bc:	a94397e2 	ldp	x2, x5, [sp, #56]
    a3c0:	f94027e7 	ldr	x7, [sp, #72]
    a3c4:	17ffff0e 	b	9ffc <fwp_main_thread+0x1d5c>
    a3c8:	72003c3f 	tst	w1, #0xffff
    a3cc:	54ffe120 	b.eq	9ff0 <fwp_main_thread+0x1d50>  // b.none
    a3d0:	d10004a5 	sub	x5, x5, #0x1
    a3d4:	17fffee3 	b	9f60 <fwp_main_thread+0x1cc0>
    a3d8:	a9028be5 	stp	x5, x2, [sp, #40]
    a3dc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    a3e0:	eb0000df 	cmp	x6, x0
    a3e4:	54ff58c8 	b.hi	8efc <fwp_main_thread+0xc5c>  // b.pmore
    a3e8:	910004c0 	add	x0, x6, #0x1
    a3ec:	52800041 	mov	w1, #0x2                   	// #2
    a3f0:	f90013e6 	str	x6, [sp, #32]
    a3f4:	d37df000 	lsl	x0, x0, #3
    a3f8:	97ffe9fa 	bl	4be0 <fwp_heap_alloc>
    a3fc:	a94217e6 	ldp	x6, x5, [sp, #32]
    a400:	aa1803e1 	mov	x1, x24
    a404:	f9401be2 	ldr	x2, [sp, #48]
    a408:	aa0003e3 	mov	x3, x0
    a40c:	b40000c1 	cbz	x1, a424 <fwp_main_thread+0x2184>
    a410:	f9400420 	ldr	x0, [x1, #8]
    a414:	f83c7860 	str	x0, [x3, x28, lsl #3]
    a418:	9100079c 	add	x28, x28, #0x1
    a41c:	f9400821 	ldr	x1, [x1, #16]
    a420:	17fffffb 	b	a40c <fwp_main_thread+0x216c>
    a424:	b9002bff 	str	wzr, [sp, #40]
    a428:	17fffe4d 	b	9d5c <fwp_main_thread+0x1abc>
    a42c:	97ffe175 	bl	2a00 <fwp_trap_overflow.constprop.0>
    a430:	f90103f9 	str	x25, [sp, #512]
    a434:	f90107fa 	str	x26, [sp, #520]
    a438:	f9010bfb 	str	x27, [sp, #528]
    a43c:	f9010ffc 	str	x28, [sp, #536]
    a440:	97ffe104 	bl	2850 <abort@plt>
    a444:	d503201f 	nop
    a448:	d503201f 	nop
    a44c:	d503201f 	nop

000000000000a450 <__divti3>:
    a450:	d503245f 	bti	c
    a454:	d2800004 	mov	x4, #0x0                   	// #0
    a458:	b7f80721 	tbnz	x1, #63, a53c <__divti3+0xec>
    a45c:	b6f80083 	tbz	x3, #63, a46c <__divti3+0x1c>
    a460:	eb0203e2 	negs	x2, x2
    a464:	aa2403e4 	mvn	x4, x4
    a468:	da0303e3 	ngc	x3, x3
    a46c:	aa0203e6 	mov	x6, x2
    a470:	aa0003e7 	mov	x7, x0
    a474:	aa0103e5 	mov	x5, x1
    a478:	b5000583 	cbnz	x3, a528 <__divti3+0xd8>
    a47c:	eb01005f 	cmp	x2, x1
    a480:	54000e69 	b.ls	a64c <__divti3+0x1fc>  // b.plast
    a484:	dac01040 	clz	x0, x2
    a488:	b40000e0 	cbz	x0, a4a4 <__divti3+0x54>
    a48c:	4b0003e1 	neg	w1, w0
    a490:	9ac020a5 	lsl	x5, x5, x0
    a494:	9ac02046 	lsl	x6, x2, x0
    a498:	9ac124e1 	lsr	x1, x7, x1
    a49c:	aa050025 	orr	x5, x1, x5
    a4a0:	9ac020e7 	lsl	x7, x7, x0
    a4a4:	d360fcc8 	lsr	x8, x6, #32
    a4a8:	92407cc2 	and	x2, x6, #0xffffffff
    a4ac:	9ac808a3 	udiv	x3, x5, x8
    a4b0:	9b089465 	msub	x5, x3, x8, x5
    a4b4:	aa0303e0 	mov	x0, x3
    a4b8:	9b037c41 	mul	x1, x2, x3
    a4bc:	93c780a5 	extr	x5, x5, x7, #32
    a4c0:	eb05003f 	cmp	x1, x5
    a4c4:	540000a9 	b.ls	a4d8 <__divti3+0x88>  // b.plast
    a4c8:	ab0500c5 	adds	x5, x6, x5
    a4cc:	d1000460 	sub	x0, x3, #0x1
    a4d0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a4d4:	540015a8 	b.hi	a788 <__divti3+0x338>  // b.pmore
    a4d8:	cb0100a5 	sub	x5, x5, x1
    a4dc:	9ac808a3 	udiv	x3, x5, x8
    a4e0:	9b089465 	msub	x5, x3, x8, x5
    a4e4:	aa0303e1 	mov	x1, x3
    a4e8:	9b037c42 	mul	x2, x2, x3
    a4ec:	aa0703e3 	mov	x3, x7
    a4f0:	b3607ca3 	bfi	x3, x5, #32, #32
    a4f4:	eb03005f 	cmp	x2, x3
    a4f8:	540000c9 	b.ls	a510 <__divti3+0xc0>  // b.plast
    a4fc:	ab0300c3 	adds	x3, x6, x3
    a500:	d1000425 	sub	x5, x1, #0x1
    a504:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a508:	d1000821 	sub	x1, x1, #0x2
    a50c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a510:	aa008020 	orr	x0, x1, x0, lsl #32
    a514:	d2800001 	mov	x1, #0x0                   	// #0
    a518:	b4000064 	cbz	x4, a524 <__divti3+0xd4>
    a51c:	eb0003e0 	negs	x0, x0
    a520:	da0103e1 	ngc	x1, x1
    a524:	d65f03c0 	ret
    a528:	eb01007f 	cmp	x3, x1
    a52c:	54000109 	b.ls	a54c <__divti3+0xfc>  // b.plast
    a530:	d2800001 	mov	x1, #0x0                   	// #0
    a534:	d2800000 	mov	x0, #0x0                   	// #0
    a538:	17fffff8 	b	a518 <__divti3+0xc8>
    a53c:	eb0003e0 	negs	x0, x0
    a540:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a544:	da0103e1 	ngc	x1, x1
    a548:	17ffffc5 	b	a45c <__divti3+0xc>
    a54c:	dac01067 	clz	x7, x3
    a550:	b40010e7 	cbz	x7, a76c <__divti3+0x31c>
    a554:	d2800805 	mov	x5, #0x40                  	// #64
    a558:	cb0700a5 	sub	x5, x5, x7
    a55c:	9ac72063 	lsl	x3, x3, x7
    a560:	9ac52448 	lsr	x8, x2, x5
    a564:	aa030108 	orr	x8, x8, x3
    a568:	9ac52426 	lsr	x6, x1, x5
    a56c:	92407d0a 	and	x10, x8, #0xffffffff
    a570:	d360fd09 	lsr	x9, x8, #32
    a574:	9ac52403 	lsr	x3, x0, x5
    a578:	9ac72021 	lsl	x1, x1, x7
    a57c:	aa010063 	orr	x3, x3, x1
    a580:	9ac72042 	lsl	x2, x2, x7
    a584:	9ac908cb 	udiv	x11, x6, x9
    a588:	9b099965 	msub	x5, x11, x9, x6
    a58c:	aa0b03e1 	mov	x1, x11
    a590:	9b0b7d46 	mul	x6, x10, x11
    a594:	93c380a5 	extr	x5, x5, x3, #32
    a598:	eb0500df 	cmp	x6, x5
    a59c:	540000a9 	b.ls	a5b0 <__divti3+0x160>  // b.plast
    a5a0:	ab050105 	adds	x5, x8, x5
    a5a4:	d1000561 	sub	x1, x11, #0x1
    a5a8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a5ac:	54000f48 	b.hi	a794 <__divti3+0x344>  // b.pmore
    a5b0:	cb0600a6 	sub	x6, x5, x6
    a5b4:	9ac908cb 	udiv	x11, x6, x9
    a5b8:	9b099969 	msub	x9, x11, x9, x6
    a5bc:	aa0b03e5 	mov	x5, x11
    a5c0:	9b0b7d4a 	mul	x10, x10, x11
    a5c4:	b3607d23 	bfi	x3, x9, #32, #32
    a5c8:	eb03015f 	cmp	x10, x3
    a5cc:	540000a9 	b.ls	a5e0 <__divti3+0x190>  // b.plast
    a5d0:	ab030103 	adds	x3, x8, x3
    a5d4:	d1000565 	sub	x5, x11, #0x1
    a5d8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a5dc:	54000e28 	b.hi	a7a0 <__divti3+0x350>  // b.pmore
    a5e0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a5e4:	92407c48 	and	x8, x2, #0xffffffff
    a5e8:	2a0503e5 	mov	w5, w5
    a5ec:	d360fc42 	lsr	x2, x2, #32
    a5f0:	d360fc26 	lsr	x6, x1, #32
    a5f4:	cb0a0063 	sub	x3, x3, x10
    a5f8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a5fc:	9b087caa 	mul	x10, x5, x8
    a600:	9b087cc8 	mul	x8, x6, x8
    a604:	9b0220a5 	madd	x5, x5, x2, x8
    a608:	9b027cc6 	mul	x6, x6, x2
    a60c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a610:	8b0900c5 	add	x5, x6, x9
    a614:	eb02011f 	cmp	x8, x2
    a618:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a61c:	8b4280c6 	add	x6, x6, x2, lsr #32
    a620:	eb06007f 	cmp	x3, x6
    a624:	540000e3 	b.cc	a640 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a628:	92407d4a 	and	x10, x10, #0xffffffff
    a62c:	9ac72000 	lsl	x0, x0, x7
    a630:	8b028142 	add	x2, x10, x2, lsl #32
    a634:	eb02001f 	cmp	x0, x2
    a638:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a63c:	54000a01 	b.ne	a77c <__divti3+0x32c>  // b.any
    a640:	d1000420 	sub	x0, x1, #0x1
    a644:	d2800001 	mov	x1, #0x0                   	// #0
    a648:	17ffffb4 	b	a518 <__divti3+0xc8>
    a64c:	b5000062 	cbnz	x2, a658 <__divti3+0x208>
    a650:	d2800022 	mov	x2, #0x1                   	// #1
    a654:	9ac30846 	udiv	x6, x2, x3
    a658:	dac010c8 	clz	x8, x6
    a65c:	b5000408 	cbnz	x8, a6dc <__divti3+0x28c>
    a660:	d360fcc9 	lsr	x9, x6, #32
    a664:	92407cc5 	and	x5, x6, #0xffffffff
    a668:	cb060023 	sub	x3, x1, x6
    a66c:	d2800021 	mov	x1, #0x1                   	// #1
    a670:	9ac90868 	udiv	x8, x3, x9
    a674:	9b098d03 	msub	x3, x8, x9, x3
    a678:	aa0803e0 	mov	x0, x8
    a67c:	9b057d02 	mul	x2, x8, x5
    a680:	93c78063 	extr	x3, x3, x7, #32
    a684:	eb03005f 	cmp	x2, x3
    a688:	540000a9 	b.ls	a69c <__divti3+0x24c>  // b.plast
    a68c:	ab0300c3 	adds	x3, x6, x3
    a690:	d1000500 	sub	x0, x8, #0x1
    a694:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a698:	54000968 	b.hi	a7c4 <__divti3+0x374>  // b.pmore
    a69c:	cb020063 	sub	x3, x3, x2
    a6a0:	9ac90862 	udiv	x2, x3, x9
    a6a4:	aa0203e8 	mov	x8, x2
    a6a8:	9b098c42 	msub	x2, x2, x9, x3
    a6ac:	aa0703e3 	mov	x3, x7
    a6b0:	9b057d05 	mul	x5, x8, x5
    a6b4:	b3607c43 	bfi	x3, x2, #32, #32
    a6b8:	eb0300bf 	cmp	x5, x3
    a6bc:	540000c9 	b.ls	a6d4 <__divti3+0x284>  // b.plast
    a6c0:	ab0300c2 	adds	x2, x6, x3
    a6c4:	d1000503 	sub	x3, x8, #0x1
    a6c8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    a6cc:	d1000908 	sub	x8, x8, #0x2
    a6d0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    a6d4:	aa008100 	orr	x0, x8, x0, lsl #32
    a6d8:	17ffff90 	b	a518 <__divti3+0xc8>
    a6dc:	9ac820c6 	lsl	x6, x6, x8
    a6e0:	d2800803 	mov	x3, #0x40                  	// #64
    a6e4:	cb080063 	sub	x3, x3, x8
    a6e8:	d360fcc9 	lsr	x9, x6, #32
    a6ec:	9ac82027 	lsl	x7, x1, x8
    a6f0:	92407cc5 	and	x5, x6, #0xffffffff
    a6f4:	9ac32422 	lsr	x2, x1, x3
    a6f8:	9ac32403 	lsr	x3, x0, x3
    a6fc:	aa070063 	orr	x3, x3, x7
    a700:	9ac9084a 	udiv	x10, x2, x9
    a704:	9ac82007 	lsl	x7, x0, x8
    a708:	9b098940 	msub	x0, x10, x9, x2
    a70c:	aa0a03e1 	mov	x1, x10
    a710:	9b0a7ca2 	mul	x2, x5, x10
    a714:	93c38000 	extr	x0, x0, x3, #32
    a718:	eb00005f 	cmp	x2, x0
    a71c:	540000a9 	b.ls	a730 <__divti3+0x2e0>  // b.plast
    a720:	ab0000c0 	adds	x0, x6, x0
    a724:	d1000541 	sub	x1, x10, #0x1
    a728:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    a72c:	54000468 	b.hi	a7b8 <__divti3+0x368>  // b.pmore
    a730:	cb020000 	sub	x0, x0, x2
    a734:	9ac9080a 	udiv	x10, x0, x9
    a738:	9b098140 	msub	x0, x10, x9, x0
    a73c:	aa0a03e2 	mov	x2, x10
    a740:	9b0a7ca8 	mul	x8, x5, x10
    a744:	b3607c03 	bfi	x3, x0, #32, #32
    a748:	eb03011f 	cmp	x8, x3
    a74c:	540000a9 	b.ls	a760 <__divti3+0x310>  // b.plast
    a750:	ab0300c3 	adds	x3, x6, x3
    a754:	d1000542 	sub	x2, x10, #0x1
    a758:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    a75c:	54000288 	b.hi	a7ac <__divti3+0x35c>  // b.pmore
    a760:	cb080063 	sub	x3, x3, x8
    a764:	aa018041 	orr	x1, x2, x1, lsl #32
    a768:	17ffffc2 	b	a670 <__divti3+0x220>
    a76c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    a770:	d2800001 	mov	x1, #0x0                   	// #0
    a774:	9a9f87e0 	cset	x0, ls	// ls = plast
    a778:	17ffff68 	b	a518 <__divti3+0xc8>
    a77c:	aa0103e0 	mov	x0, x1
    a780:	d2800001 	mov	x1, #0x0                   	// #0
    a784:	17ffff65 	b	a518 <__divti3+0xc8>
    a788:	d1000860 	sub	x0, x3, #0x2
    a78c:	8b0600a5 	add	x5, x5, x6
    a790:	17ffff52 	b	a4d8 <__divti3+0x88>
    a794:	d1000961 	sub	x1, x11, #0x2
    a798:	8b0800a5 	add	x5, x5, x8
    a79c:	17ffff85 	b	a5b0 <__divti3+0x160>
    a7a0:	d1000965 	sub	x5, x11, #0x2
    a7a4:	8b080063 	add	x3, x3, x8
    a7a8:	17ffff8e 	b	a5e0 <__divti3+0x190>
    a7ac:	d1000942 	sub	x2, x10, #0x2
    a7b0:	8b060063 	add	x3, x3, x6
    a7b4:	17ffffeb 	b	a760 <__divti3+0x310>
    a7b8:	d1000941 	sub	x1, x10, #0x2
    a7bc:	8b060000 	add	x0, x0, x6
    a7c0:	17ffffdc 	b	a730 <__divti3+0x2e0>
    a7c4:	d1000900 	sub	x0, x8, #0x2
    a7c8:	8b060063 	add	x3, x3, x6
    a7cc:	17ffffb4 	b	a69c <__divti3+0x24c>

000000000000a7d0 <__modti3>:
    a7d0:	d503245f 	bti	c
    a7d4:	d2800004 	mov	x4, #0x0                   	// #0
    a7d8:	b6f80081 	tbz	x1, #63, a7e8 <__modti3+0x18>
    a7dc:	eb0003e0 	negs	x0, x0
    a7e0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a7e4:	da0103e1 	ngc	x1, x1
    a7e8:	f100007f 	cmp	x3, #0x0
    a7ec:	5400128b 	b.lt	aa3c <__modti3+0x26c>  // b.tstop
    a7f0:	aa0003e7 	mov	x7, x0
    a7f4:	aa0103e6 	mov	x6, x1
    a7f8:	540004e1 	b.ne	a894 <__modti3+0xc4>  // b.any
    a7fc:	eb02003f 	cmp	x1, x2
    a800:	54000dc2 	b.cs	a9b8 <__modti3+0x1e8>  // b.hs, b.nlast
    a804:	dac01043 	clz	x3, x2
    a808:	aa0303e5 	mov	x5, x3
    a80c:	b40000e3 	cbz	x3, a828 <__modti3+0x58>
    a810:	4b0303e6 	neg	w6, w3
    a814:	9ac32021 	lsl	x1, x1, x3
    a818:	9ac32042 	lsl	x2, x2, x3
    a81c:	9ac62406 	lsr	x6, x0, x6
    a820:	aa0100c6 	orr	x6, x6, x1
    a824:	9ac32007 	lsl	x7, x0, x3
    a828:	d360fc40 	lsr	x0, x2, #32
    a82c:	92407c43 	and	x3, x2, #0xffffffff
    a830:	9ac008c1 	udiv	x1, x6, x0
    a834:	9b009826 	msub	x6, x1, x0, x6
    a838:	9b017c61 	mul	x1, x3, x1
    a83c:	93c780c6 	extr	x6, x6, x7, #32
    a840:	eb06003f 	cmp	x1, x6
    a844:	540000a9 	b.ls	a858 <__modti3+0x88>  // b.plast
    a848:	ab060046 	adds	x6, x2, x6
    a84c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    a850:	8b0200c8 	add	x8, x6, x2
    a854:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    a858:	cb0100c6 	sub	x6, x6, x1
    a85c:	9ac008c8 	udiv	x8, x6, x0
    a860:	9b009901 	msub	x1, x8, x0, x6
    a864:	aa0703e0 	mov	x0, x7
    a868:	9b087c63 	mul	x3, x3, x8
    a86c:	b3607c20 	bfi	x0, x1, #32, #32
    a870:	eb00007f 	cmp	x3, x0
    a874:	54001088 	b.hi	aa84 <__modti3+0x2b4>  // b.pmore
    a878:	cb030000 	sub	x0, x0, x3
    a87c:	9ac52400 	lsr	x0, x0, x5
    a880:	d2800001 	mov	x1, #0x0                   	// #0
    a884:	b4000064 	cbz	x4, a890 <__modti3+0xc0>
    a888:	eb0003e0 	negs	x0, x0
    a88c:	da0103e1 	ngc	x1, x1
    a890:	d65f03c0 	ret
    a894:	dac01066 	clz	x6, x3
    a898:	eb03003f 	cmp	x1, x3
    a89c:	54ffff43 	b.cc	a884 <__modti3+0xb4>  // b.lo, b.ul, b.last
    a8a0:	93407cc5 	sxtw	x5, w6
    a8a4:	d2800808 	mov	x8, #0x40                  	// #64
    a8a8:	cb050108 	sub	x8, x8, x5
    a8ac:	9ac62063 	lsl	x3, x3, x6
    a8b0:	9ac62025 	lsl	x5, x1, x6
    a8b4:	9ac82447 	lsr	x7, x2, x8
    a8b8:	aa0300e7 	orr	x7, x7, x3
    a8bc:	9ac82423 	lsr	x3, x1, x8
    a8c0:	92407cec 	and	x12, x7, #0xffffffff
    a8c4:	d360fcea 	lsr	x10, x7, #32
    a8c8:	9ac82401 	lsr	x1, x0, x8
    a8cc:	aa050021 	orr	x1, x1, x5
    a8d0:	9ac62042 	lsl	x2, x2, x6
    a8d4:	9ac62000 	lsl	x0, x0, x6
    a8d8:	9aca086b 	udiv	x11, x3, x10
    a8dc:	9b0a8d63 	msub	x3, x11, x10, x3
    a8e0:	aa0b03e5 	mov	x5, x11
    a8e4:	9b0b7d89 	mul	x9, x12, x11
    a8e8:	93c18063 	extr	x3, x3, x1, #32
    a8ec:	eb03013f 	cmp	x9, x3
    a8f0:	540000a9 	b.ls	a904 <__modti3+0x134>  // b.plast
    a8f4:	ab0300e3 	adds	x3, x7, x3
    a8f8:	d1000565 	sub	x5, x11, #0x1
    a8fc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    a900:	54001168 	b.hi	ab2c <__modti3+0x35c>  // b.pmore
    a904:	cb090063 	sub	x3, x3, x9
    a908:	9aca086b 	udiv	x11, x3, x10
    a90c:	9b0a8d6a 	msub	x10, x11, x10, x3
    a910:	aa0b03e9 	mov	x9, x11
    a914:	9b0b7d8c 	mul	x12, x12, x11
    a918:	b3607d41 	bfi	x1, x10, #32, #32
    a91c:	eb01019f 	cmp	x12, x1
    a920:	540000a9 	b.ls	a934 <__modti3+0x164>  // b.plast
    a924:	ab0100e1 	adds	x1, x7, x1
    a928:	d1000569 	sub	x9, x11, #0x1
    a92c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    a930:	54000f88 	b.hi	ab20 <__modti3+0x350>  // b.pmore
    a934:	aa058123 	orr	x3, x9, x5, lsl #32
    a938:	92407c4b 	and	x11, x2, #0xffffffff
    a93c:	2a0903e9 	mov	w9, w9
    a940:	d360fc4a 	lsr	x10, x2, #32
    a944:	d360fc63 	lsr	x3, x3, #32
    a948:	cb0c0021 	sub	x1, x1, x12
    a94c:	aa0a03ec 	mov	x12, x10
    a950:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    a954:	9b0b7d25 	mul	x5, x9, x11
    a958:	9b0b7c6b 	mul	x11, x3, x11
    a95c:	9b0a2d29 	madd	x9, x9, x10, x11
    a960:	92407caa 	and	x10, x5, #0xffffffff
    a964:	9b0c7c63 	mul	x3, x3, x12
    a968:	8b458125 	add	x5, x9, x5, lsr #32
    a96c:	8b0d0069 	add	x9, x3, x13
    a970:	eb05017f 	cmp	x11, x5
    a974:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    a978:	8b058149 	add	x9, x10, x5, lsl #32
    a97c:	8b458063 	add	x3, x3, x5, lsr #32
    a980:	eb03003f 	cmp	x1, x3
    a984:	54000063 	b.cc	a990 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    a988:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    a98c:	54000082 	b.cs	a99c <__modti3+0x1cc>  // b.hs, b.nlast
    a990:	eb020129 	subs	x9, x9, x2
    a994:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    a998:	cb070063 	sub	x3, x3, x7
    a99c:	eb090000 	subs	x0, x0, x9
    a9a0:	da030021 	sbc	x1, x1, x3
    a9a4:	9ac62400 	lsr	x0, x0, x6
    a9a8:	9ac82028 	lsl	x8, x1, x8
    a9ac:	aa000100 	orr	x0, x8, x0
    a9b0:	9ac62421 	lsr	x1, x1, x6
    a9b4:	17ffffb4 	b	a884 <__modti3+0xb4>
    a9b8:	b5000062 	cbnz	x2, a9c4 <__modti3+0x1f4>
    a9bc:	d2800023 	mov	x3, #0x1                   	// #1
    a9c0:	9ac20862 	udiv	x2, x3, x2
    a9c4:	dac01048 	clz	x8, x2
    a9c8:	aa0803e5 	mov	x5, x8
    a9cc:	b5000668 	cbnz	x8, aa98 <__modti3+0x2c8>
    a9d0:	cb020020 	sub	x0, x1, x2
    a9d4:	d360fc49 	lsr	x9, x2, #32
    a9d8:	92407c4a 	and	x10, x2, #0xffffffff
    a9dc:	9ac90801 	udiv	x1, x0, x9
    a9e0:	9b098020 	msub	x0, x1, x9, x0
    a9e4:	9b0a7c21 	mul	x1, x1, x10
    a9e8:	93c78000 	extr	x0, x0, x7, #32
    a9ec:	eb00003f 	cmp	x1, x0
    a9f0:	540000a9 	b.ls	aa04 <__modti3+0x234>  // b.plast
    a9f4:	ab000040 	adds	x0, x2, x0
    a9f8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    a9fc:	8b020003 	add	x3, x0, x2
    aa00:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    aa04:	cb010001 	sub	x1, x0, x1
    aa08:	9ac90820 	udiv	x0, x1, x9
    aa0c:	9b098403 	msub	x3, x0, x9, x1
    aa10:	aa0703e1 	mov	x1, x7
    aa14:	9b0a7c00 	mul	x0, x0, x10
    aa18:	b3607c61 	bfi	x1, x3, #32, #32
    aa1c:	eb01001f 	cmp	x0, x1
    aa20:	540000a9 	b.ls	aa34 <__modti3+0x264>  // b.plast
    aa24:	ab010041 	adds	x1, x2, x1
    aa28:	8b020022 	add	x2, x1, x2
    aa2c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    aa30:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    aa34:	cb000020 	sub	x0, x1, x0
    aa38:	17ffff91 	b	a87c <__modti3+0xac>
    aa3c:	eb0203e5 	negs	x5, x2
    aa40:	aa0003e7 	mov	x7, x0
    aa44:	da0303e8 	ngc	x8, x3
    aa48:	aa0503e2 	mov	x2, x5
    aa4c:	aa0803e3 	mov	x3, x8
    aa50:	aa0103e6 	mov	x6, x1
    aa54:	b4ffed48 	cbz	x8, a7fc <__modti3+0x2c>
    aa58:	eb01011f 	cmp	x8, x1
    aa5c:	54fff148 	b.hi	a884 <__modti3+0xb4>  // b.pmore
    aa60:	dac01109 	clz	x9, x8
    aa64:	2a0903e6 	mov	w6, w9
    aa68:	b5fff1c9 	cbnz	x9, a8a0 <__modti3+0xd0>
    aa6c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    aa70:	54000068 	b.hi	aa7c <__modti3+0x2ac>  // b.pmore
    aa74:	eb050007 	subs	x7, x0, x5
    aa78:	da080021 	sbc	x1, x1, x8
    aa7c:	aa0703e0 	mov	x0, x7
    aa80:	17ffff81 	b	a884 <__modti3+0xb4>
    aa84:	ab000040 	adds	x0, x2, x0
    aa88:	8b020002 	add	x2, x0, x2
    aa8c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    aa90:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    aa94:	17ffff79 	b	a878 <__modti3+0xa8>
    aa98:	9ac82042 	lsl	x2, x2, x8
    aa9c:	d2800803 	mov	x3, #0x40                  	// #64
    aaa0:	cb080063 	sub	x3, x3, x8
    aaa4:	d360fc49 	lsr	x9, x2, #32
    aaa8:	9ac82027 	lsl	x7, x1, x8
    aaac:	92407c4a 	and	x10, x2, #0xffffffff
    aab0:	9ac32426 	lsr	x6, x1, x3
    aab4:	9ac32403 	lsr	x3, x0, x3
    aab8:	aa070063 	orr	x3, x3, x7
    aabc:	9ac908c1 	udiv	x1, x6, x9
    aac0:	9ac82007 	lsl	x7, x0, x8
    aac4:	9b099820 	msub	x0, x1, x9, x6
    aac8:	9b017d41 	mul	x1, x10, x1
    aacc:	93c38000 	extr	x0, x0, x3, #32
    aad0:	eb00003f 	cmp	x1, x0
    aad4:	540000a9 	b.ls	aae8 <__modti3+0x318>  // b.plast
    aad8:	ab000040 	adds	x0, x2, x0
    aadc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    aae0:	8b020006 	add	x6, x0, x2
    aae4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    aae8:	cb010000 	sub	x0, x0, x1
    aaec:	9ac90801 	udiv	x1, x0, x9
    aaf0:	9b098026 	msub	x6, x1, x9, x0
    aaf4:	aa0303e0 	mov	x0, x3
    aaf8:	9b017d41 	mul	x1, x10, x1
    aafc:	b3607cc0 	bfi	x0, x6, #32, #32
    ab00:	eb00003f 	cmp	x1, x0
    ab04:	540000a9 	b.ls	ab18 <__modti3+0x348>  // b.plast
    ab08:	ab000040 	adds	x0, x2, x0
    ab0c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ab10:	8b020003 	add	x3, x0, x2
    ab14:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ab18:	cb010000 	sub	x0, x0, x1
    ab1c:	17ffffb0 	b	a9dc <__modti3+0x20c>
    ab20:	d1000969 	sub	x9, x11, #0x2
    ab24:	8b070021 	add	x1, x1, x7
    ab28:	17ffff83 	b	a934 <__modti3+0x164>
    ab2c:	d1000965 	sub	x5, x11, #0x2
    ab30:	8b070063 	add	x3, x3, x7
    ab34:	17ffff74 	b	a904 <__modti3+0x134>
    ab38:	d503201f 	nop
    ab3c:	d503201f 	nop

000000000000ab40 <atexit>:
    ab40:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    ab44:	d00000a2 	adrp	x2, 20000 <__data_start>
    ab48:	d2800001 	mov	x1, #0x0                   	// #0
    ab4c:	910003fd 	mov	x29, sp
    ab50:	a8c17bfd 	ldp	x29, x30, [sp], #16
    ab54:	f9400442 	ldr	x2, [x2, #8]
    ab58:	17ffdeea 	b	2700 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ab5c <_fini>:
    ab5c:	d503201f 	nop
    ab60:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    ab64:	910003fd 	mov	x29, sp
    ab68:	a8c17bfd 	ldp	x29, x30, [sp], #16
    ab6c:	d65f03c0 	ret
