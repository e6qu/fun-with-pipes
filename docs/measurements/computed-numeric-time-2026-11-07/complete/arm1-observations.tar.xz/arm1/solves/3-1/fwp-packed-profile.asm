
/home/runner/work/fun-with-pipes/fun-with-pipes/local-evidence/solves/3-1/fwp-packed-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000001328 <_init>:
    1328:	d503201f 	nop
    132c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1330:	910003fd 	mov	x29, sp
    1334:	94000190 	bl	1974 <call_weak_fn>
    1338:	a8c17bfd 	ldp	x29, x30, [sp], #16
    133c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000001340 <.plt>:
    1340:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    1344:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1348:	f946fe11 	ldr	x17, [x16, #3576]
    134c:	9137e210 	add	x16, x16, #0xdf8
    1350:	d61f0220 	br	x17
    1354:	d503201f 	nop
    1358:	d503201f 	nop
    135c:	d503201f 	nop

0000000000001360 <memcpy@plt>:
    1360:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1364:	f9470211 	ldr	x17, [x16, #3584]
    1368:	91380210 	add	x16, x16, #0xe00
    136c:	d61f0220 	br	x17

0000000000001370 <sigaltstack@plt>:
    1370:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1374:	f9470611 	ldr	x17, [x16, #3592]
    1378:	91382210 	add	x16, x16, #0xe08
    137c:	d61f0220 	br	x17

0000000000001380 <_exit@plt>:
    1380:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1384:	f9470a11 	ldr	x17, [x16, #3600]
    1388:	91384210 	add	x16, x16, #0xe10
    138c:	d61f0220 	br	x17

0000000000001390 <strlen@plt>:
    1390:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1394:	f9470e11 	ldr	x17, [x16, #3608]
    1398:	91386210 	add	x16, x16, #0xe18
    139c:	d61f0220 	br	x17

00000000000013a0 <__sprintf_chk@plt>:
    13a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    13a4:	f9471211 	ldr	x17, [x16, #3616]
    13a8:	91388210 	add	x16, x16, #0xe20
    13ac:	d61f0220 	br	x17

00000000000013b0 <exit@plt>:
    13b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    13b4:	f9471611 	ldr	x17, [x16, #3624]
    13b8:	9138a210 	add	x16, x16, #0xe28
    13bc:	d61f0220 	br	x17

00000000000013c0 <__libc_start_main@plt>:
    13c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    13c4:	f9471a11 	ldr	x17, [x16, #3632]
    13c8:	9138c210 	add	x16, x16, #0xe30
    13cc:	d61f0220 	br	x17

00000000000013d0 <strtoll@plt>:
    13d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    13d4:	f9471e11 	ldr	x17, [x16, #3640]
    13d8:	9138e210 	add	x16, x16, #0xe38
    13dc:	d61f0220 	br	x17

00000000000013e0 <strtod@plt>:
    13e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    13e4:	f9472211 	ldr	x17, [x16, #3648]
    13e8:	91390210 	add	x16, x16, #0xe40
    13ec:	d61f0220 	br	x17

00000000000013f0 <__cxa_finalize@plt>:
    13f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    13f4:	f9472611 	ldr	x17, [x16, #3656]
    13f8:	91392210 	add	x16, x16, #0xe48
    13fc:	d61f0220 	br	x17

0000000000001400 <__cxa_atexit@plt>:
    1400:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1404:	f9472a11 	ldr	x17, [x16, #3664]
    1408:	91394210 	add	x16, x16, #0xe50
    140c:	d61f0220 	br	x17

0000000000001410 <pthread_attr_init@plt>:
    1410:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1414:	f9472e11 	ldr	x17, [x16, #3672]
    1418:	91396210 	add	x16, x16, #0xe58
    141c:	d61f0220 	br	x17

0000000000001420 <fputc@plt>:
    1420:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1424:	f9473211 	ldr	x17, [x16, #3680]
    1428:	91398210 	add	x16, x16, #0xe60
    142c:	d61f0220 	br	x17

0000000000001430 <clock_gettime@plt>:
    1430:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1434:	f9473611 	ldr	x17, [x16, #3688]
    1438:	9139a210 	add	x16, x16, #0xe68
    143c:	d61f0220 	br	x17

0000000000001440 <setvbuf@plt>:
    1440:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1444:	f9473a11 	ldr	x17, [x16, #3696]
    1448:	9139c210 	add	x16, x16, #0xe70
    144c:	d61f0220 	br	x17

0000000000001450 <__memcpy_chk@plt>:
    1450:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1454:	f9473e11 	ldr	x17, [x16, #3704]
    1458:	9139e210 	add	x16, x16, #0xe78
    145c:	d61f0220 	br	x17

0000000000001460 <signal@plt>:
    1460:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1464:	f9474211 	ldr	x17, [x16, #3712]
    1468:	913a0210 	add	x16, x16, #0xe80
    146c:	d61f0220 	br	x17

0000000000001470 <__snprintf_chk@plt>:
    1470:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1474:	f9474611 	ldr	x17, [x16, #3720]
    1478:	913a2210 	add	x16, x16, #0xe88
    147c:	d61f0220 	br	x17

0000000000001480 <fclose@plt>:
    1480:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1484:	f9474a11 	ldr	x17, [x16, #3728]
    1488:	913a4210 	add	x16, x16, #0xe90
    148c:	d61f0220 	br	x17

0000000000001490 <fopen@plt>:
    1490:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1494:	f9474e11 	ldr	x17, [x16, #3736]
    1498:	913a6210 	add	x16, x16, #0xe98
    149c:	d61f0220 	br	x17

00000000000014a0 <malloc@plt>:
    14a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    14a4:	f9475211 	ldr	x17, [x16, #3744]
    14a8:	913a8210 	add	x16, x16, #0xea0
    14ac:	d61f0220 	br	x17

00000000000014b0 <pthread_attr_destroy@plt>:
    14b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    14b4:	f9475611 	ldr	x17, [x16, #3752]
    14b8:	913aa210 	add	x16, x16, #0xea8
    14bc:	d61f0220 	br	x17

00000000000014c0 <sigemptyset@plt>:
    14c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    14c4:	f9475a11 	ldr	x17, [x16, #3760]
    14c8:	913ac210 	add	x16, x16, #0xeb0
    14cc:	d61f0220 	br	x17

00000000000014d0 <memset@plt>:
    14d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    14d4:	f9475e11 	ldr	x17, [x16, #3768]
    14d8:	913ae210 	add	x16, x16, #0xeb8
    14dc:	d61f0220 	br	x17

00000000000014e0 <calloc@plt>:
    14e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    14e4:	f9476211 	ldr	x17, [x16, #3776]
    14e8:	913b0210 	add	x16, x16, #0xec0
    14ec:	d61f0220 	br	x17

00000000000014f0 <realloc@plt>:
    14f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    14f4:	f9476611 	ldr	x17, [x16, #3784]
    14f8:	913b2210 	add	x16, x16, #0xec8
    14fc:	d61f0220 	br	x17

0000000000001500 <__stack_chk_fail@plt>:
    1500:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1504:	f9476a11 	ldr	x17, [x16, #3792]
    1508:	913b4210 	add	x16, x16, #0xed0
    150c:	d61f0220 	br	x17

0000000000001510 <close@plt>:
    1510:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1514:	f9476e11 	ldr	x17, [x16, #3800]
    1518:	913b6210 	add	x16, x16, #0xed8
    151c:	d61f0220 	br	x17

0000000000001520 <sigaction@plt>:
    1520:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1524:	f9477211 	ldr	x17, [x16, #3808]
    1528:	913b8210 	add	x16, x16, #0xee0
    152c:	d61f0220 	br	x17

0000000000001530 <__gmon_start__@plt>:
    1530:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1534:	f9477611 	ldr	x17, [x16, #3816]
    1538:	913ba210 	add	x16, x16, #0xee8
    153c:	d61f0220 	br	x17

0000000000001540 <write@plt>:
    1540:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1544:	f9477a11 	ldr	x17, [x16, #3824]
    1548:	913bc210 	add	x16, x16, #0xef0
    154c:	d61f0220 	br	x17

0000000000001550 <abort@plt>:
    1550:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1554:	f9477e11 	ldr	x17, [x16, #3832]
    1558:	913be210 	add	x16, x16, #0xef8
    155c:	d61f0220 	br	x17

0000000000001560 <swapcontext@plt>:
    1560:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1564:	f9478211 	ldr	x17, [x16, #3840]
    1568:	913c0210 	add	x16, x16, #0xf00
    156c:	d61f0220 	br	x17

0000000000001570 <__fprintf_chk@plt>:
    1570:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1574:	f9478611 	ldr	x17, [x16, #3848]
    1578:	913c2210 	add	x16, x16, #0xf08
    157c:	d61f0220 	br	x17

0000000000001580 <strcmp@plt>:
    1580:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1584:	f9478a11 	ldr	x17, [x16, #3856]
    1588:	913c4210 	add	x16, x16, #0xf10
    158c:	d61f0220 	br	x17

0000000000001590 <mmap@plt>:
    1590:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1594:	f9478e11 	ldr	x17, [x16, #3864]
    1598:	913c6210 	add	x16, x16, #0xf18
    159c:	d61f0220 	br	x17

00000000000015a0 <strtol@plt>:
    15a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    15a4:	f9479211 	ldr	x17, [x16, #3872]
    15a8:	913c8210 	add	x16, x16, #0xf20
    15ac:	d61f0220 	br	x17

00000000000015b0 <strtof@plt>:
    15b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    15b4:	f9479611 	ldr	x17, [x16, #3880]
    15b8:	913ca210 	add	x16, x16, #0xf28
    15bc:	d61f0220 	br	x17

00000000000015c0 <free@plt>:
    15c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    15c4:	f9479a11 	ldr	x17, [x16, #3888]
    15c8:	913cc210 	add	x16, x16, #0xf30
    15cc:	d61f0220 	br	x17

00000000000015d0 <nanosleep@plt>:
    15d0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    15d4:	f9479e11 	ldr	x17, [x16, #3896]
    15d8:	913ce210 	add	x16, x16, #0xf38
    15dc:	d61f0220 	br	x17

00000000000015e0 <strchr@plt>:
    15e0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    15e4:	f947a211 	ldr	x17, [x16, #3904]
    15e8:	913d0210 	add	x16, x16, #0xf40
    15ec:	d61f0220 	br	x17

00000000000015f0 <strtoull@plt>:
    15f0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    15f4:	f947a611 	ldr	x17, [x16, #3912]
    15f8:	913d2210 	add	x16, x16, #0xf48
    15fc:	d61f0220 	br	x17

0000000000001600 <fwrite@plt>:
    1600:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1604:	f947aa11 	ldr	x17, [x16, #3920]
    1608:	913d4210 	add	x16, x16, #0xf50
    160c:	d61f0220 	br	x17

0000000000001610 <pthread_create@plt>:
    1610:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1614:	f947ae11 	ldr	x17, [x16, #3928]
    1618:	913d6210 	add	x16, x16, #0xf58
    161c:	d61f0220 	br	x17

0000000000001620 <munmap@plt>:
    1620:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1624:	f947b211 	ldr	x17, [x16, #3936]
    1628:	913d8210 	add	x16, x16, #0xf60
    162c:	d61f0220 	br	x17

0000000000001630 <fflush@plt>:
    1630:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1634:	f947b611 	ldr	x17, [x16, #3944]
    1638:	913da210 	add	x16, x16, #0xf68
    163c:	d61f0220 	br	x17

0000000000001640 <strcpy@plt>:
    1640:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1644:	f947ba11 	ldr	x17, [x16, #3952]
    1648:	913dc210 	add	x16, x16, #0xf70
    164c:	d61f0220 	br	x17

0000000000001650 <sysconf@plt>:
    1650:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1654:	f947be11 	ldr	x17, [x16, #3960]
    1658:	913de210 	add	x16, x16, #0xf78
    165c:	d61f0220 	br	x17

0000000000001660 <strstr@plt>:
    1660:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1664:	f947c211 	ldr	x17, [x16, #3968]
    1668:	913e0210 	add	x16, x16, #0xf80
    166c:	d61f0220 	br	x17

0000000000001670 <_Exit@plt>:
    1670:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1674:	f947c611 	ldr	x17, [x16, #3976]
    1678:	913e2210 	add	x16, x16, #0xf88
    167c:	d61f0220 	br	x17

0000000000001680 <pthread_join@plt>:
    1680:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1684:	f947ca11 	ldr	x17, [x16, #3984]
    1688:	913e4210 	add	x16, x16, #0xf90
    168c:	d61f0220 	br	x17

0000000000001690 <getenv@plt>:
    1690:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    1694:	f947ce11 	ldr	x17, [x16, #3992]
    1698:	913e6210 	add	x16, x16, #0xf98
    169c:	d61f0220 	br	x17

00000000000016a0 <mprotect@plt>:
    16a0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    16a4:	f947d211 	ldr	x17, [x16, #4000]
    16a8:	913e8210 	add	x16, x16, #0xfa0
    16ac:	d61f0220 	br	x17

00000000000016b0 <fgets@plt>:
    16b0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    16b4:	f947d611 	ldr	x17, [x16, #4008]
    16b8:	913ea210 	add	x16, x16, #0xfa8
    16bc:	d61f0220 	br	x17

00000000000016c0 <pthread_attr_setstacksize@plt>:
    16c0:	d00000f0 	adrp	x16, 1f000 <__FRAME_END__+0x170f8>
    16c4:	f947da11 	ldr	x17, [x16, #4016]
    16c8:	913ec210 	add	x16, x16, #0xfb0
    16cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000001700 <fwp_trap_overflow.constprop.0>:
    1700:	d10243ff 	sub	sp, sp, #0x90
    1704:	d2800c03 	mov	x3, #0x60                  	// #96
    1708:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x170f8>
    170c:	f947f421 	ldr	x1, [x1, #4072]
    1710:	b0000025 	adrp	x5, 6000 <fwp_main_thread+0x114c>
    1714:	a9077bfd 	stp	x29, x30, [sp, #112]
    1718:	9101c3fd 	add	x29, sp, #0x70
    171c:	913680a5 	add	x5, x5, #0xda0
    1720:	b0000024 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    1724:	f90043f3 	str	x19, [sp, #128]
    1728:	9136a084 	add	x4, x4, #0xda8
    172c:	910023f3 	add	x19, sp, #0x8
    1730:	f9400022 	ldr	x2, [x1]
    1734:	f90037e2 	str	x2, [sp, #104]
    1738:	d2800002 	mov	x2, #0x0                   	// #0
    173c:	aa0303e1 	mov	x1, x3
    1740:	52800042 	mov	w2, #0x2                   	// #2
    1744:	aa1303e0 	mov	x0, x19
    1748:	97ffff4a 	bl	1470 <__snprintf_chk@plt>
    174c:	aa1303e0 	mov	x0, x19
    1750:	940002cc 	bl	2280 <fwp_trap>
    1754:	d503201f 	nop
    1758:	d503201f 	nop
    175c:	d503201f 	nop

0000000000001760 <main>:
    1760:	d10243ff 	sub	sp, sp, #0x90
    1764:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    1768:	f947f400 	ldr	x0, [x0, #4072]
    176c:	a9067bfd 	stp	x29, x30, [sp, #96]
    1770:	910183fd 	add	x29, sp, #0x60
    1774:	a90753f3 	stp	x19, x20, [sp, #112]
    1778:	f00000f3 	adrp	x19, 20000 <__data_start>
    177c:	d00000f4 	adrp	x20, 1f000 <__FRAME_END__+0x170f8>
    1780:	f947ee94 	ldr	x20, [x20, #4056]
    1784:	f9400281 	ldr	x1, [x20]
    1788:	f90043f5 	str	x21, [sp, #128]
    178c:	f9400002 	ldr	x2, [x0]
    1790:	f9002fe2 	str	x2, [sp, #88]
    1794:	d2800002 	mov	x2, #0x0                   	// #0
    1798:	f9004261 	str	x1, [x19, #128]
    179c:	940002c9 	bl	22c0 <fwp_now_ns>
    17a0:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x4b0>
    17a4:	91020000 	add	x0, x0, #0x80
    17a8:	97ffffba 	bl	1690 <getenv@plt>
    17ac:	b4000080 	cbz	x0, 17bc <main+0x5c>
    17b0:	39400001 	ldrb	w1, [x0]
    17b4:	aa0003f5 	mov	x21, x0
    17b8:	35000801 	cbnz	w1, 18b8 <main+0x158>
    17bc:	910023e1 	add	x1, sp, #0x8
    17c0:	52800000 	mov	w0, #0x0                   	// #0
    17c4:	97ffff1b 	bl	1430 <clock_gettime@plt>
    17c8:	35000900 	cbnz	w0, 18e8 <main+0x188>
    17cc:	a9408be0 	ldp	x0, x2, [sp, #8]
    17d0:	d2994003 	mov	x3, #0xca00                	// #51712
    17d4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    17d8:	9b037c01 	mul	x1, x0, x3
    17dc:	9b437c00 	smulh	x0, x0, x3
    17e0:	ab020021 	adds	x1, x1, x2
    17e4:	937ffc42 	asr	x2, x2, #63
    17e8:	9a020000 	adc	x0, x0, x2
    17ec:	f100003f 	cmp	x1, #0x0
    17f0:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    17f4:	b50009a0 	cbnz	x0, 1928 <main+0x1c8>
    17f8:	f9400280 	ldr	x0, [x20]
    17fc:	d2a00023 	mov	x3, #0x10000               	// #65536
    1800:	52800002 	mov	w2, #0x0                   	// #0
    1804:	d2800001 	mov	x1, #0x0                   	// #0
    1808:	910063f5 	add	x21, sp, #0x18
    180c:	97ffff0d 	bl	1440 <setvbuf@plt>
    1810:	d2800021 	mov	x1, #0x1                   	// #1
    1814:	528001a0 	mov	w0, #0xd                   	// #13
    1818:	97ffff12 	bl	1460 <signal@plt>
    181c:	aa1503e0 	mov	x0, x21
    1820:	97fffefc 	bl	1410 <pthread_attr_init@plt>
    1824:	350007c0 	cbnz	w0, 191c <main+0x1bc>
    1828:	aa1503e0 	mov	x0, x21
    182c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    1830:	97ffffa4 	bl	16c0 <pthread_attr_setstacksize@plt>
    1834:	35000680 	cbnz	w0, 1904 <main+0x1a4>
    1838:	aa1503e1 	mov	x1, x21
    183c:	910023e0 	add	x0, sp, #0x8
    1840:	f0000002 	adrp	x2, 4000 <fwp_write.constprop.0+0xf0>
    1844:	d2800003 	mov	x3, #0x0                   	// #0
    1848:	913ad042 	add	x2, x2, #0xeb4
    184c:	97ffff71 	bl	1610 <pthread_create@plt>
    1850:	2a0003e1 	mov	w1, w0
    1854:	aa1503e0 	mov	x0, x21
    1858:	2a0103f5 	mov	w21, w1
    185c:	97ffff15 	bl	14b0 <pthread_attr_destroy@plt>
    1860:	350006a0 	cbnz	w0, 1934 <main+0x1d4>
    1864:	350004b5 	cbnz	w21, 18f8 <main+0x198>
    1868:	f94007e0 	ldr	x0, [sp, #8]
    186c:	d2800001 	mov	x1, #0x0                   	// #0
    1870:	97ffff84 	bl	1680 <pthread_join@plt>
    1874:	35000600 	cbnz	w0, 1934 <main+0x1d4>
    1878:	f9400280 	ldr	x0, [x20]
    187c:	91020273 	add	x19, x19, #0x80
    1880:	97ffff6c 	bl	1630 <fflush@plt>
    1884:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x170f8>
    1888:	f947f421 	ldr	x1, [x1, #4072]
    188c:	b942da60 	ldr	w0, [x19, #728]
    1890:	f9402fe3 	ldr	x3, [sp, #88]
    1894:	f9400022 	ldr	x2, [x1]
    1898:	eb020063 	subs	x3, x3, x2
    189c:	d2800002 	mov	x2, #0x0                   	// #0
    18a0:	540002a1 	b.ne	18f4 <main+0x194>  // b.any
    18a4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    18a8:	a94753f3 	ldp	x19, x20, [sp, #112]
    18ac:	f94043f5 	ldr	x21, [sp, #128]
    18b0:	910243ff 	add	sp, sp, #0x90
    18b4:	d65f03c0 	ret
    18b8:	910003e1 	mov	x1, sp
    18bc:	52800142 	mov	w2, #0xa                   	// #10
    18c0:	97ffff4c 	bl	15f0 <strtoull@plt>
    18c4:	f94003e0 	ldr	x0, [sp]
    18c8:	39400000 	ldrb	w0, [x0]
    18cc:	35fff780 	cbnz	w0, 17bc <main+0x5c>
    18d0:	394002a0 	ldrb	w0, [x21]
    18d4:	52801fa1 	mov	w1, #0xfd                  	// #253
    18d8:	5100ac00 	sub	w0, w0, #0x2b
    18dc:	6a01001f 	tst	w0, w1
    18e0:	54fff6e0 	b.eq	17bc <main+0x5c>  // b.none
    18e4:	17ffffc5 	b	17f8 <main+0x98>
    18e8:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x4b0>
    18ec:	91024000 	add	x0, x0, #0x90
    18f0:	94000264 	bl	2280 <fwp_trap>
    18f4:	97ffff03 	bl	1500 <__stack_chk_fail@plt>
    18f8:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x4b0>
    18fc:	9104c000 	add	x0, x0, #0x130
    1900:	94000260 	bl	2280 <fwp_trap>
    1904:	aa1503e0 	mov	x0, x21
    1908:	97fffeea 	bl	14b0 <pthread_attr_destroy@plt>
    190c:	35000140 	cbnz	w0, 1934 <main+0x1d4>
    1910:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x4b0>
    1914:	91042000 	add	x0, x0, #0x108
    1918:	9400025a 	bl	2280 <fwp_trap>
    191c:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x4b0>
    1920:	91036000 	add	x0, x0, #0xd8
    1924:	94000257 	bl	2280 <fwp_trap>
    1928:	d0000020 	adrp	x0, 7000 <_IO_stdin_used+0x4b0>
    192c:	9102c000 	add	x0, x0, #0xb0
    1930:	94000254 	bl	2280 <fwp_trap>
    1934:	97ffff07 	bl	1550 <abort@plt>
    1938:	d503201f 	nop
    193c:	d503201f 	nop

0000000000001940 <_start>:
    1940:	d503201f 	nop
    1944:	d280001d 	mov	x29, #0x0                   	// #0
    1948:	d280001e 	mov	x30, #0x0                   	// #0
    194c:	aa0003e5 	mov	x5, x0
    1950:	f94003e1 	ldr	x1, [sp]
    1954:	910023e2 	add	x2, sp, #0x8
    1958:	910003e6 	mov	x6, sp
    195c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    1960:	f947f800 	ldr	x0, [x0, #4080]
    1964:	d2800003 	mov	x3, #0x0                   	// #0
    1968:	d2800004 	mov	x4, #0x0                   	// #0
    196c:	97fffe95 	bl	13c0 <__libc_start_main@plt>
    1970:	97fffef8 	bl	1550 <abort@plt>

0000000000001974 <call_weak_fn>:
    1974:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    1978:	f947f000 	ldr	x0, [x0, #4064]
    197c:	b4000040 	cbz	x0, 1984 <call_weak_fn+0x10>
    1980:	17fffeec 	b	1530 <__gmon_start__@plt>
    1984:	d65f03c0 	ret
    1988:	d503201f 	nop
    198c:	d503201f 	nop

0000000000001990 <deregister_tm_clones>:
    1990:	f00000e0 	adrp	x0, 20000 <__data_start>
    1994:	9101a000 	add	x0, x0, #0x68
    1998:	f00000e1 	adrp	x1, 20000 <__data_start>
    199c:	9101a021 	add	x1, x1, #0x68
    19a0:	eb00003f 	cmp	x1, x0
    19a4:	540000c0 	b.eq	19bc <deregister_tm_clones+0x2c>  // b.none
    19a8:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x170f8>
    19ac:	f947e021 	ldr	x1, [x1, #4032]
    19b0:	b4000061 	cbz	x1, 19bc <deregister_tm_clones+0x2c>
    19b4:	aa0103f0 	mov	x16, x1
    19b8:	d61f0200 	br	x16
    19bc:	d65f03c0 	ret

00000000000019c0 <register_tm_clones>:
    19c0:	f00000e0 	adrp	x0, 20000 <__data_start>
    19c4:	9101a000 	add	x0, x0, #0x68
    19c8:	f00000e1 	adrp	x1, 20000 <__data_start>
    19cc:	9101a021 	add	x1, x1, #0x68
    19d0:	cb000021 	sub	x1, x1, x0
    19d4:	d37ffc22 	lsr	x2, x1, #63
    19d8:	8b810c41 	add	x1, x2, x1, asr #3
    19dc:	9341fc21 	asr	x1, x1, #1
    19e0:	b40000c1 	cbz	x1, 19f8 <register_tm_clones+0x38>
    19e4:	d00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x170f8>
    19e8:	f947fc42 	ldr	x2, [x2, #4088]
    19ec:	b4000062 	cbz	x2, 19f8 <register_tm_clones+0x38>
    19f0:	aa0203f0 	mov	x16, x2
    19f4:	d61f0200 	br	x16
    19f8:	d65f03c0 	ret
    19fc:	d503201f 	nop

0000000000001a00 <__do_global_dtors_aux>:
    1a00:	d503233f 	paciasp
    1a04:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1a08:	910003fd 	mov	x29, sp
    1a0c:	f9000bf3 	str	x19, [sp, #16]
    1a10:	f00000f3 	adrp	x19, 20000 <__data_start>
    1a14:	3941c260 	ldrb	w0, [x19, #112]
    1a18:	37000140 	tbnz	w0, #0, 1a40 <__do_global_dtors_aux+0x40>
    1a1c:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    1a20:	f947e400 	ldr	x0, [x0, #4040]
    1a24:	b4000080 	cbz	x0, 1a34 <__do_global_dtors_aux+0x34>
    1a28:	f00000e0 	adrp	x0, 20000 <__data_start>
    1a2c:	f9400400 	ldr	x0, [x0, #8]
    1a30:	97fffe70 	bl	13f0 <__cxa_finalize@plt>
    1a34:	97ffffd7 	bl	1990 <deregister_tm_clones>
    1a38:	52800020 	mov	w0, #0x1                   	// #1
    1a3c:	3901c260 	strb	w0, [x19, #112]
    1a40:	f9400bf3 	ldr	x19, [sp, #16]
    1a44:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1a48:	d50323bf 	autiasp
    1a4c:	d65f03c0 	ret

0000000000001a50 <frame_dummy>:
    1a50:	d503245f 	bti	c
    1a54:	17ffffdb 	b	19c0 <register_tm_clones>
    1a58:	d503201f 	nop
    1a5c:	d503201f 	nop

0000000000001a60 <fwp_fmt_u128>:
    1a60:	d10183ff 	sub	sp, sp, #0x60
    1a64:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x170f8>
    1a68:	f947f421 	ldr	x1, [x1, #4072]
    1a6c:	a9057bfd 	stp	x29, x30, [sp, #80]
    1a70:	910143fd 	add	x29, sp, #0x50
    1a74:	f9400024 	ldr	x4, [x1]
    1a78:	f90027e4 	str	x4, [sp, #72]
    1a7c:	d2800004 	mov	x4, #0x0                   	// #0
    1a80:	aa030041 	orr	x1, x2, x3
    1a84:	b5000361 	cbnz	x1, 1af0 <fwp_fmt_u128+0x90>
    1a88:	910023e9 	add	x9, sp, #0x8
    1a8c:	52800601 	mov	w1, #0x30                  	// #48
    1a90:	5280002d 	mov	w13, #0x1                   	// #1
    1a94:	390023e1 	strb	w1, [sp, #8]
    1a98:	93407dad 	sxtw	x13, w13
    1a9c:	aa0d03e1 	mov	x1, x13
    1aa0:	8b0d0004 	add	x4, x0, x13
    1aa4:	d503201f 	nop
    1aa8:	8b010123 	add	x3, x9, x1
    1aac:	cb0103e2 	neg	x2, x1
    1ab0:	d1000421 	sub	x1, x1, #0x1
    1ab4:	385ff063 	ldurb	w3, [x3, #-1]
    1ab8:	38226883 	strb	w3, [x4, x2]
    1abc:	35ffff61 	cbnz	w1, 1aa8 <fwp_fmt_u128+0x48>
    1ac0:	d00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x170f8>
    1ac4:	f947f421 	ldr	x1, [x1, #4072]
    1ac8:	382d681f 	strb	wzr, [x0, x13]
    1acc:	aa0103e0 	mov	x0, x1
    1ad0:	f94027e2 	ldr	x2, [sp, #72]
    1ad4:	f9400001 	ldr	x1, [x0]
    1ad8:	eb010042 	subs	x2, x2, x1
    1adc:	d2800001 	mov	x1, #0x0                   	// #0
    1ae0:	54000561 	b.ne	1b8c <fwp_fmt_u128+0x12c>  // b.any
    1ae4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    1ae8:	910183ff 	add	sp, sp, #0x60
    1aec:	d65f03c0 	ret
    1af0:	d0000021 	adrp	x1, 7000 <_IO_stdin_used+0x4b0>
    1af4:	91088021 	add	x1, x1, #0x220
    1af8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    1afc:	910023e9 	add	x9, sp, #0x8
    1b00:	d2800027 	mov	x7, #0x1                   	// #1
    1b04:	f29999af 	movk	x15, #0xcccd
    1b08:	a9402826 	ldp	x6, x10, [x1]
    1b0c:	d503201f 	nop
    1b10:	ab030041 	adds	x1, x2, x3
    1b14:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    1b18:	aa0303eb 	mov	x11, x3
    1b1c:	8b070128 	add	x8, x9, x7
    1b20:	aa0203ee 	mov	x14, x2
    1b24:	aa0703ed 	mov	x13, x7
    1b28:	910004e7 	add	x7, x7, #0x1
    1b2c:	9bcf7c24 	umulh	x4, x1, x15
    1b30:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    1b34:	8b4408a4 	add	x4, x5, x4, lsr #2
    1b38:	cb040021 	sub	x1, x1, x4
    1b3c:	eb010041 	subs	x1, x2, x1
    1b40:	da1f0063 	sbc	x3, x3, xzr
    1b44:	9bc67c24 	umulh	x4, x1, x6
    1b48:	9b061064 	madd	x4, x3, x6, x4
    1b4c:	9b067c2c 	mul	x12, x1, x6
    1b50:	9b0a1024 	madd	x4, x1, x10, x4
    1b54:	9bc67c25 	umulh	x5, x1, x6
    1b58:	9b061465 	madd	x5, x3, x6, x5
    1b5c:	9b0a1425 	madd	x5, x1, x10, x5
    1b60:	93cc0484 	extr	x4, x4, x12, #1
    1b64:	8b040884 	add	x4, x4, x4, lsl #2
    1b68:	d341fca3 	lsr	x3, x5, #1
    1b6c:	cb040444 	sub	x4, x2, x4, lsl #1
    1b70:	93cc04a2 	extr	x2, x5, x12, #1
    1b74:	1100c084 	add	w4, w4, #0x30
    1b78:	381ff104 	sturb	w4, [x8, #-1]
    1b7c:	b5fffcab 	cbnz	x11, 1b10 <fwp_fmt_u128+0xb0>
    1b80:	f10025df 	cmp	x14, #0x9
    1b84:	54fffc68 	b.hi	1b10 <fwp_fmt_u128+0xb0>  // b.pmore
    1b88:	17ffffc4 	b	1a98 <fwp_fmt_u128+0x38>
    1b8c:	97fffe5d 	bl	1500 <__stack_chk_fail@plt>

0000000000001b90 <fwp_range_release>:
    1b90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    1b94:	910003fd 	mov	x29, sp
    1b98:	f9400801 	ldr	x1, [x0, #16]
    1b9c:	f9000bf3 	str	x19, [sp, #16]
    1ba0:	aa0003f3 	mov	x19, x0
    1ba4:	b4000061 	cbz	x1, 1bb0 <fwp_range_release+0x20>
    1ba8:	f9400400 	ldr	x0, [x0, #8]
    1bac:	d63f0020 	blr	x1
    1bb0:	f9400260 	ldr	x0, [x19]
    1bb4:	f9400e61 	ldr	x1, [x19, #24]
    1bb8:	f9400bf3 	ldr	x19, [sp, #16]
    1bbc:	aa0103f0 	mov	x16, x1
    1bc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    1bc4:	d61f0200 	br	x16
    1bc8:	d503201f 	nop
    1bcc:	d503201f 	nop

0000000000001bd0 <fwp_flush>:
    1bd0:	f00000e0 	adrp	x0, 20000 <__data_start>
    1bd4:	f9404000 	ldr	x0, [x0, #128]
    1bd8:	b4000120 	cbz	x0, 1bfc <fwp_flush+0x2c>
    1bdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1be0:	910003fd 	mov	x29, sp
    1be4:	97fffe93 	bl	1630 <fflush@plt>
    1be8:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    1bec:	f947ec00 	ldr	x0, [x0, #4056]
    1bf0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    1bf4:	f9400000 	ldr	x0, [x0]
    1bf8:	17fffe8e 	b	1630 <fflush@plt>
    1bfc:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    1c00:	f947ec00 	ldr	x0, [x0, #4056]
    1c04:	f9400000 	ldr	x0, [x0]
    1c08:	17fffe8a 	b	1630 <fflush@plt>
    1c0c:	d503201f 	nop

0000000000001c10 <fwp_segv>:
    1c10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    1c14:	f00000e2 	adrp	x2, 20000 <__data_start>
    1c18:	91020043 	add	x3, x2, #0x80
    1c1c:	910003fd 	mov	x29, sp
    1c20:	a90153f3 	stp	x19, x20, [sp, #16]
    1c24:	2a0003f3 	mov	w19, w0
    1c28:	f9400460 	ldr	x0, [x3, #8]
    1c2c:	f90013f5 	str	x21, [sp, #32]
    1c30:	f9400835 	ldr	x21, [x1, #16]
    1c34:	b4000280 	cbz	x0, 1c84 <fwp_segv+0x74>
    1c38:	f9400814 	ldr	x20, [x0, #16]
    1c3c:	b4000254 	cbz	x20, 1c84 <fwp_segv+0x74>
    1c40:	528003c0 	mov	w0, #0x1e                  	// #30
    1c44:	97fffe83 	bl	1650 <sysconf@plt>
    1c48:	f144029f 	cmp	x20, #0x100, lsl #12
    1c4c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    1c50:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    1c54:	8b000294 	add	x20, x20, x0
    1c58:	d1440021 	sub	x1, x1, #0x100, lsl #12
    1c5c:	eb0102bf 	cmp	x21, x1
    1c60:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    1c64:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1c68:	35000240 	cbnz	w0, 1cb0 <fwp_segv+0xa0>
    1c6c:	f94013f5 	ldr	x21, [sp, #32]
    1c70:	2a1303e0 	mov	w0, w19
    1c74:	a94153f3 	ldp	x19, x20, [sp, #16]
    1c78:	d2800001 	mov	x1, #0x0                   	// #0
    1c7c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    1c80:	17fffdf8 	b	1460 <signal@plt>
    1c84:	91020042 	add	x2, x2, #0x80
    1c88:	f9400840 	ldr	x0, [x2, #16]
    1c8c:	b4ffff00 	cbz	x0, 1c6c <fwp_segv+0x5c>
    1c90:	f9400c41 	ldr	x1, [x2, #24]
    1c94:	cb010000 	sub	x0, x0, x1
    1c98:	d1440001 	sub	x1, x0, #0x100, lsl #12
    1c9c:	91440000 	add	x0, x0, #0x100, lsl #12
    1ca0:	eb15003f 	cmp	x1, x21
    1ca4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    1ca8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    1cac:	34fffe00 	cbz	w0, 1c6c <fwp_segv+0x5c>
    1cb0:	97ffffc8 	bl	1bd0 <fwp_flush>
    1cb4:	d0000021 	adrp	x1, 7000 <_IO_stdin_used+0x4b0>
    1cb8:	91080021 	add	x1, x1, #0x200
    1cbc:	d2800342 	mov	x2, #0x1a                  	// #26
    1cc0:	52800040 	mov	w0, #0x2                   	// #2
    1cc4:	97fffe1f 	bl	1540 <write@plt>
    1cc8:	52800ca0 	mov	w0, #0x65                  	// #101
    1ccc:	97fffdad 	bl	1380 <_exit@plt>

0000000000001cd0 <fwp_heap_oom>:
    1cd0:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x170f8>
    1cd4:	f947e863 	ldr	x3, [x3, #4048]
    1cd8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1cdc:	d2800262 	mov	x2, #0x13                  	// #19
    1ce0:	910003fd 	mov	x29, sp
    1ce4:	f9400063 	ldr	x3, [x3]
    1ce8:	d2800021 	mov	x1, #0x1                   	// #1
    1cec:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    1cf0:	912d6000 	add	x0, x0, #0xb58
    1cf4:	97fffe43 	bl	1600 <fwrite@plt>
    1cf8:	d2800000 	mov	x0, #0x0                   	// #0
    1cfc:	97fffe4d 	bl	1630 <fflush@plt>
    1d00:	52800cc0 	mov	w0, #0x66                  	// #102
    1d04:	97fffe5b 	bl	1670 <_Exit@plt>
    1d08:	d503201f 	nop
    1d0c:	d503201f 	nop

0000000000001d10 <fwp_heap_chunks>:
    1d10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    1d14:	910003fd 	mov	x29, sp
    1d18:	a90153f3 	stp	x19, x20, [sp, #16]
    1d1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    1d20:	90000195 	adrp	x21, 31000 <fwp_root_context+0xc80>
    1d24:	911582a1 	add	x1, x21, #0x560
    1d28:	f100041f 	cmp	x0, #0x1
    1d2c:	54000ca0 	b.eq	1ec0 <fwp_heap_chunks+0x1b0>  // b.none
    1d30:	f949f822 	ldr	x2, [x1, #5104]
    1d34:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaa0>
    1d38:	912540a5 	add	x5, x5, #0x950
    1d3c:	911582a1 	add	x1, x21, #0x560
    1d40:	f949ec34 	ldr	x20, [x1, #5080]
    1d44:	eb14005f 	cmp	x2, x20
    1d48:	54000c42 	b.cs	1ed0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    1d4c:	f949fc23 	ldr	x3, [x1, #5112]
    1d50:	8b020841 	add	x1, x2, x2, lsl #2
    1d54:	d2800004 	mov	x4, #0x0                   	// #0
    1d58:	8b010c61 	add	x1, x3, x1, lsl #3
    1d5c:	14000009 	b	1d80 <fwp_heap_chunks+0x70>
    1d60:	91000483 	add	x3, x4, #0x1
    1d64:	eb03001f 	cmp	x0, x3
    1d68:	54000940 	b.eq	1e90 <fwp_heap_chunks+0x180>  // b.none
    1d6c:	91000442 	add	x2, x2, #0x1
    1d70:	aa0303e4 	mov	x4, x3
    1d74:	9100a021 	add	x1, x1, #0x28
    1d78:	eb02029f 	cmp	x20, x2
    1d7c:	54000100 	b.eq	1d9c <fwp_heap_chunks+0x8c>  // b.none
    1d80:	39400023 	ldrb	w3, [x1]
    1d84:	34fffee3 	cbz	w3, 1d60 <fwp_heap_chunks+0x50>
    1d88:	91000442 	add	x2, x2, #0x1
    1d8c:	9100a021 	add	x1, x1, #0x28
    1d90:	d2800004 	mov	x4, #0x0                   	// #0
    1d94:	eb02029f 	cmp	x20, x2
    1d98:	54ffff41 	b.ne	1d80 <fwp_heap_chunks+0x70>  // b.any
    1d9c:	cb040294 	sub	x20, x20, x4
    1da0:	f9001bf7 	str	x23, [sp, #48]
    1da4:	911582b7 	add	x23, x21, #0x560
    1da8:	8b140013 	add	x19, x0, x20
    1dac:	f94a1ae1 	ldr	x1, [x23, #5168]
    1db0:	f949f2e0 	ldr	x0, [x23, #5088]
    1db4:	cb040021 	sub	x1, x1, x4
    1db8:	f90a1ae1 	str	x1, [x23, #5168]
    1dbc:	eb00027f 	cmp	x19, x0
    1dc0:	54000429 	b.ls	1e44 <fwp_heap_chunks+0x134>  // b.plast
    1dc4:	f949eae1 	ldr	x1, [x23, #5072]
    1dc8:	eb01027f 	cmp	x19, x1
    1dcc:	54000888 	b.hi	1edc <fwp_heap_chunks+0x1cc>  // b.pmore
    1dd0:	91010276 	add	x22, x19, #0x40
    1dd4:	52800062 	mov	w2, #0x3                   	// #3
    1dd8:	f949dae3 	ldr	x3, [x23, #5040]
    1ddc:	eb0102df 	cmp	x22, x1
    1de0:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    1de4:	cb0002c1 	sub	x1, x22, x0
    1de8:	8b004060 	add	x0, x3, x0, lsl #16
    1dec:	d370bc21 	lsl	x1, x1, #16
    1df0:	97fffe2c 	bl	16a0 <mprotect@plt>
    1df4:	35000740 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1df8:	528003c0 	mov	w0, #0x1e                  	// #30
    1dfc:	97fffe15 	bl	1650 <sysconf@plt>
    1e00:	f949f2e2 	ldr	x2, [x23, #5088]
    1e04:	cb0003e5 	neg	x5, x0
    1e08:	aa0003e4 	mov	x4, x0
    1e0c:	8b160ac1 	add	x1, x22, x22, lsl #2
    1e10:	f949fee0 	ldr	x0, [x23, #5112]
    1e14:	8b020843 	add	x3, x2, x2, lsl #2
    1e18:	52800062 	mov	w2, #0x3                   	// #3
    1e1c:	8b010c01 	add	x1, x0, x1, lsl #3
    1e20:	8b030c03 	add	x3, x0, x3, lsl #3
    1e24:	d1000421 	sub	x1, x1, #0x1
    1e28:	8a050060 	and	x0, x3, x5
    1e2c:	8b040021 	add	x1, x1, x4
    1e30:	8a050021 	and	x1, x1, x5
    1e34:	cb000021 	sub	x1, x1, x0
    1e38:	97fffe1a 	bl	16a0 <mprotect@plt>
    1e3c:	35000500 	cbnz	w0, 1edc <fwp_heap_chunks+0x1cc>
    1e40:	f909f2f6 	str	x22, [x23, #5088]
    1e44:	911582b5 	add	x21, x21, #0x560
    1e48:	d370be60 	lsl	x0, x19, #16
    1e4c:	f949e6a1 	ldr	x1, [x21, #5064]
    1e50:	f909eeb3 	str	x19, [x21, #5080]
    1e54:	eb01001f 	cmp	x0, x1
    1e58:	540000e8 	b.hi	1e74 <fwp_heap_chunks+0x164>  // b.pmore
    1e5c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e60:	aa1403e0 	mov	x0, x20
    1e64:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e68:	f9401bf7 	ldr	x23, [sp, #48]
    1e6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e70:	d65f03c0 	ret
    1e74:	f9401bf7 	ldr	x23, [sp, #48]
    1e78:	f909e6a0 	str	x0, [x21, #5064]
    1e7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1e80:	aa1403e0 	mov	x0, x20
    1e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    1e88:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1e8c:	d65f03c0 	ret
    1e90:	911582b5 	add	x21, x21, #0x560
    1e94:	91000441 	add	x1, x2, #0x1
    1e98:	f90000a1 	str	x1, [x5]
    1e9c:	cb040054 	sub	x20, x2, x4
    1ea0:	f94a1aa1 	ldr	x1, [x21, #5168]
    1ea4:	cb000020 	sub	x0, x1, x0
    1ea8:	f90a1aa0 	str	x0, [x21, #5168]
    1eac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    1eb0:	aa1403e0 	mov	x0, x20
    1eb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    1eb8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    1ebc:	d65f03c0 	ret
    1ec0:	f949f422 	ldr	x2, [x1, #5096]
    1ec4:	b0000185 	adrp	x5, 32000 <fwp_heap+0xaa0>
    1ec8:	912520a5 	add	x5, x5, #0x948
    1ecc:	17ffff9c 	b	1d3c <fwp_heap_chunks+0x2c>
    1ed0:	d2800004 	mov	x4, #0x0                   	// #0
    1ed4:	f9001bf7 	str	x23, [sp, #48]
    1ed8:	17ffffb3 	b	1da4 <fwp_heap_chunks+0x94>
    1edc:	97ffff7d 	bl	1cd0 <fwp_heap_oom>

0000000000001ee0 <ad_raw_fail>:
    1ee0:	d00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x170f8>
    1ee4:	f947e884 	ldr	x4, [x4, #4048]
    1ee8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    1eec:	aa0003e3 	mov	x3, x0
    1ef0:	910003fd 	mov	x29, sp
    1ef4:	f9400080 	ldr	x0, [x4]
    1ef8:	b0000022 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    1efc:	912dc042 	add	x2, x2, #0xb70
    1f00:	52800041 	mov	w1, #0x2                   	// #2
    1f04:	97fffd9b 	bl	1570 <__fprintf_chk@plt>
    1f08:	52801d00 	mov	w0, #0xe8                  	// #232
    1f0c:	97fffd29 	bl	13b0 <exit@plt>

0000000000001f10 <ad_raw_report>:
    1f10:	d101c3ff 	sub	sp, sp, #0x70
    1f14:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f18:	d00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x170f8>
    1f1c:	f947f463 	ldr	x3, [x3, #4072]
    1f20:	b0000022 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    1f24:	a9037bfd 	stp	x29, x30, [sp, #48]
    1f28:	9100c3fd 	add	x29, sp, #0x30
    1f2c:	912e8042 	add	x2, x2, #0xba0
    1f30:	d2800005 	mov	x5, #0x0                   	// #0
    1f34:	a9055bf5 	stp	x21, x22, [sp, #80]
    1f38:	b0000036 	adrp	x22, 6000 <fwp_main_thread+0x114c>
    1f3c:	913002d6 	add	x22, x22, #0xc00
    1f40:	d00000f5 	adrp	x21, 1f000 <__FRAME_END__+0x170f8>
    1f44:	f947eab5 	ldr	x21, [x21, #4048]
    1f48:	a90453f3 	stp	x19, x20, [sp, #64]
    1f4c:	52800013 	mov	w19, #0x0                   	// #0
    1f50:	f94002a0 	ldr	x0, [x21]
    1f54:	f90033f7 	str	x23, [sp, #96]
    1f58:	b0000037 	adrp	x23, 6000 <fwp_main_thread+0x114c>
    1f5c:	912e62f7 	add	x23, x23, #0xb98
    1f60:	f9400064 	ldr	x4, [x3]
    1f64:	f90017e4 	str	x4, [sp, #40]
    1f68:	d2800004 	mov	x4, #0x0                   	// #0
    1f6c:	d2800003 	mov	x3, #0x0                   	// #0
    1f70:	f9405024 	ldr	x4, [x1, #160]
    1f74:	52800041 	mov	w1, #0x2                   	// #2
    1f78:	97fffd7e 	bl	1570 <__fprintf_chk@plt>
    1f7c:	f00000e1 	adrp	x1, 20000 <__data_start>
    1f80:	91004021 	add	x1, x1, #0x10
    1f84:	f94002a0 	ldr	x0, [x21]
    1f88:	910023e2 	add	x2, sp, #0x8
    1f8c:	4c40a020 	ld1	{v0.16b-v1.16b}, [x1]
    1f90:	b0000023 	adrp	x3, 6000 <fwp_main_thread+0x114c>
    1f94:	aa0203f4 	mov	x20, x2
    1f98:	912e4063 	add	x3, x3, #0xb90
    1f9c:	4c00a040 	st1	{v0.16b-v1.16b}, [x2]
    1fa0:	aa1603e2 	mov	x2, x22
    1fa4:	f8408684 	ldr	x4, [x20], #8
    1fa8:	d2800007 	mov	x7, #0x0                   	// #0
    1fac:	d2800006 	mov	x6, #0x0                   	// #0
    1fb0:	d2800005 	mov	x5, #0x0                   	// #0
    1fb4:	52800041 	mov	w1, #0x2                   	// #2
    1fb8:	11000673 	add	w19, w19, #0x1
    1fbc:	97fffd6d 	bl	1570 <__fprintf_chk@plt>
    1fc0:	7100127f 	cmp	w19, #0x4
    1fc4:	54000080 	b.eq	1fd4 <ad_raw_report+0xc4>  // b.none
    1fc8:	f94002a0 	ldr	x0, [x21]
    1fcc:	aa1703e3 	mov	x3, x23
    1fd0:	17fffff4 	b	1fa0 <ad_raw_report+0x90>
    1fd4:	f94002a3 	ldr	x3, [x21]
    1fd8:	d2800262 	mov	x2, #0x13                  	// #19
    1fdc:	d2800021 	mov	x1, #0x1                   	// #1
    1fe0:	b0000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    1fe4:	91310000 	add	x0, x0, #0xc40
    1fe8:	97fffd86 	bl	1600 <fwrite@plt>
    1fec:	d00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    1ff0:	f947f400 	ldr	x0, [x0, #4072]
    1ff4:	f94017e2 	ldr	x2, [sp, #40]
    1ff8:	f9400001 	ldr	x1, [x0]
    1ffc:	eb010042 	subs	x2, x2, x1
    2000:	d2800001 	mov	x1, #0x0                   	// #0
    2004:	54000181 	b.ne	2034 <ad_raw_report+0x124>  // b.any
    2008:	f94002a3 	ldr	x3, [x21]
    200c:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2010:	a9437bfd 	ldp	x29, x30, [sp, #48]
    2014:	91316000 	add	x0, x0, #0xc58
    2018:	a94453f3 	ldp	x19, x20, [sp, #64]
    201c:	d2800082 	mov	x2, #0x4                   	// #4
    2020:	a9455bf5 	ldp	x21, x22, [sp, #80]
    2024:	d2800021 	mov	x1, #0x1                   	// #1
    2028:	f94033f7 	ldr	x23, [sp, #96]
    202c:	9101c3ff 	add	sp, sp, #0x70
    2030:	17fffd74 	b	1600 <fwrite@plt>
    2034:	97fffd33 	bl	1500 <__stack_chk_fail@plt>
    2038:	d503201f 	nop
    203c:	d503201f 	nop

0000000000002040 <buf_grow>:
    2040:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2044:	910003fd 	mov	x29, sp
    2048:	a90153f3 	stp	x19, x20, [sp, #16]
    204c:	aa0003f4 	mov	x20, x0
    2050:	f9400400 	ldr	x0, [x0, #8]
    2054:	b100041f 	cmn	x0, #0x1
    2058:	54000400 	b.eq	20d8 <buf_grow+0x98>  // b.none
    205c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    2060:	cb000042 	sub	x2, x2, x0
    2064:	eb01005f 	cmp	x2, x1
    2068:	54000383 	b.cc	20d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    206c:	f9400a82 	ldr	x2, [x20, #16]
    2070:	91000421 	add	x1, x1, #0x1
    2074:	8b000033 	add	x19, x1, x0
    2078:	eb13005f 	cmp	x2, x19
    207c:	54000242 	b.cs	20c4 <buf_grow+0x84>  // b.hs, b.nlast
    2080:	f100005f 	cmp	x2, #0x0
    2084:	b5000262 	cbnz	x2, 20d0 <buf_grow+0x90>
    2088:	d2800802 	mov	x2, #0x40                  	// #64
    208c:	eb02027f 	cmp	x19, x2
    2090:	54000068 	b.hi	209c <buf_grow+0x5c>  // b.pmore
    2094:	14000005 	b	20a8 <buf_grow+0x68>
    2098:	b7f800a2 	tbnz	x2, #63, 20ac <buf_grow+0x6c>
    209c:	d37ff842 	lsl	x2, x2, #1
    20a0:	eb02027f 	cmp	x19, x2
    20a4:	54ffffa8 	b.hi	2098 <buf_grow+0x58>  // b.pmore
    20a8:	aa0203f3 	mov	x19, x2
    20ac:	f9400280 	ldr	x0, [x20]
    20b0:	aa1303e1 	mov	x1, x19
    20b4:	97fffd0f 	bl	14f0 <realloc@plt>
    20b8:	b4000100 	cbz	x0, 20d8 <buf_grow+0x98>
    20bc:	f9000280 	str	x0, [x20]
    20c0:	f9000a93 	str	x19, [x20, #16]
    20c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    20c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    20cc:	d65f03c0 	ret
    20d0:	54fffe6a 	b.ge	209c <buf_grow+0x5c>  // b.tcont
    20d4:	17fffff6 	b	20ac <buf_grow+0x6c>
    20d8:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x170f8>
    20dc:	f947e863 	ldr	x3, [x3, #4048]
    20e0:	d2800262 	mov	x2, #0x13                  	// #19
    20e4:	d2800021 	mov	x1, #0x1                   	// #1
    20e8:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    20ec:	912d6000 	add	x0, x0, #0xb58
    20f0:	f9400063 	ldr	x3, [x3]
    20f4:	97fffd43 	bl	1600 <fwrite@plt>
    20f8:	d2800000 	mov	x0, #0x0                   	// #0
    20fc:	97fffd4d 	bl	1630 <fflush@plt>
    2100:	52800cc0 	mov	w0, #0x66                  	// #102
    2104:	97fffd5b 	bl	1670 <_Exit@plt>
    2108:	d503201f 	nop
    210c:	d503201f 	nop

0000000000002110 <buf_put>:
    2110:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2114:	910003fd 	mov	x29, sp
    2118:	a90153f3 	stp	x19, x20, [sp, #16]
    211c:	aa0003f4 	mov	x20, x0
    2120:	aa0203f3 	mov	x19, x2
    2124:	f90013f5 	str	x21, [sp, #32]
    2128:	aa0103f5 	mov	x21, x1
    212c:	aa0203e1 	mov	x1, x2
    2130:	97ffffc4 	bl	2040 <buf_grow>
    2134:	a9400283 	ldp	x3, x0, [x20]
    2138:	aa1503e1 	mov	x1, x21
    213c:	aa1303e2 	mov	x2, x19
    2140:	8b000060 	add	x0, x3, x0
    2144:	97fffc87 	bl	1360 <memcpy@plt>
    2148:	a9400680 	ldp	x0, x1, [x20]
    214c:	8b010273 	add	x19, x19, x1
    2150:	f9000693 	str	x19, [x20, #8]
    2154:	3833681f 	strb	wzr, [x0, x19]
    2158:	a94153f3 	ldp	x19, x20, [sp, #16]
    215c:	f94013f5 	ldr	x21, [sp, #32]
    2160:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2164:	d65f03c0 	ret
    2168:	d503201f 	nop
    216c:	d503201f 	nop

0000000000002170 <fwp_cancel_tree.part.0>:
    2170:	d00000e1 	adrp	x1, 20000 <__data_start>
    2174:	91020022 	add	x2, x1, #0x80
    2178:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    217c:	52800023 	mov	w3, #0x1                   	// #1
    2180:	910003fd 	mov	x29, sp
    2184:	f9400444 	ldr	x4, [x2, #8]
    2188:	f9000bf3 	str	x19, [sp, #16]
    218c:	39014403 	strb	w3, [x0, #81]
    2190:	eb04001f 	cmp	x0, x4
    2194:	54000160 	b.eq	21c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    2198:	f9402804 	ldr	x4, [x0, #80]
    219c:	f2001c9f 	tst	x4, #0xff000000ff
    21a0:	54000101 	b.ne	21c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    21a4:	f9401444 	ldr	x4, [x2, #40]
    21a8:	39015003 	strb	w3, [x0, #84]
    21ac:	f900801f 	str	xzr, [x0, #256]
    21b0:	b40001e4 	cbz	x4, 21ec <fwp_cancel_tree.part.0+0x7c>
    21b4:	f9008080 	str	x0, [x4, #256]
    21b8:	91020021 	add	x1, x1, #0x80
    21bc:	f9001420 	str	x0, [x1, #40]
    21c0:	f9401413 	ldr	x19, [x0, #40]
    21c4:	b40000f3 	cbz	x19, 21e0 <fwp_cancel_tree.part.0+0x70>
    21c8:	39414261 	ldrb	w1, [x19, #80]
    21cc:	aa1303e0 	mov	x0, x19
    21d0:	37000041 	tbnz	w1, #0, 21d8 <fwp_cancel_tree.part.0+0x68>
    21d4:	97ffffe7 	bl	2170 <fwp_cancel_tree.part.0>
    21d8:	f9401a73 	ldr	x19, [x19, #48]
    21dc:	b5ffff73 	cbnz	x19, 21c8 <fwp_cancel_tree.part.0+0x58>
    21e0:	f9400bf3 	ldr	x19, [sp, #16]
    21e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    21e8:	d65f03c0 	ret
    21ec:	f9001840 	str	x0, [x2, #48]
    21f0:	17fffff2 	b	21b8 <fwp_cancel_tree.part.0+0x48>

00000000000021f4 <fwp_finish_float>:
    21f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    21f8:	528005c1 	mov	w1, #0x2e                  	// #46
    21fc:	910003fd 	mov	x29, sp
    2200:	f9000bf3 	str	x19, [sp, #16]
    2204:	aa0003f3 	mov	x19, x0
    2208:	97fffcf6 	bl	15e0 <strchr@plt>
    220c:	b4000080 	cbz	x0, 221c <fwp_finish_float+0x28>
    2210:	f9400bf3 	ldr	x19, [sp, #16]
    2214:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2218:	d65f03c0 	ret
    221c:	aa1303e0 	mov	x0, x19
    2220:	52800ca1 	mov	w1, #0x65                  	// #101
    2224:	97fffcef 	bl	15e0 <strchr@plt>
    2228:	b5ffff40 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    222c:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    2230:	aa1303e0 	mov	x0, x19
    2234:	91318021 	add	x1, x1, #0xc60
    2238:	97fffd0a 	bl	1660 <strstr@plt>
    223c:	b5fffea0 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2240:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    2244:	aa1303e0 	mov	x0, x19
    2248:	9131a021 	add	x1, x1, #0xc68
    224c:	97fffd05 	bl	1660 <strstr@plt>
    2250:	b5fffe00 	cbnz	x0, 2210 <fwp_finish_float+0x1c>
    2254:	aa1303e0 	mov	x0, x19
    2258:	97fffc4e 	bl	1390 <strlen@plt>
    225c:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    2260:	9131c021 	add	x1, x1, #0xc70
    2264:	8b000262 	add	x2, x19, x0
    2268:	79400023 	ldrh	w3, [x1]
    226c:	39400821 	ldrb	w1, [x1, #2]
    2270:	78206a63 	strh	w3, [x19, x0]
    2274:	39000841 	strb	w1, [x2, #2]
    2278:	17ffffe6 	b	2210 <fwp_finish_float+0x1c>
    227c:	d503201f 	nop

0000000000002280 <fwp_trap>:
    2280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2284:	910003fd 	mov	x29, sp
    2288:	f9000bf3 	str	x19, [sp, #16]
    228c:	aa0003f3 	mov	x19, x0
    2290:	97fffe50 	bl	1bd0 <fwp_flush>
    2294:	b00000e4 	adrp	x4, 1f000 <__FRAME_END__+0x170f8>
    2298:	f947e884 	ldr	x4, [x4, #4048]
    229c:	aa1303e3 	mov	x3, x19
    22a0:	90000022 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    22a4:	9131e042 	add	x2, x2, #0xc78
    22a8:	52800041 	mov	w1, #0x2                   	// #2
    22ac:	f9400080 	ldr	x0, [x4]
    22b0:	97fffcb0 	bl	1570 <__fprintf_chk@plt>
    22b4:	52800ca0 	mov	w0, #0x65                  	// #101
    22b8:	97fffc3e 	bl	13b0 <exit@plt>
    22bc:	d503201f 	nop

00000000000022c0 <fwp_now_ns>:
    22c0:	d100c3ff 	sub	sp, sp, #0x30
    22c4:	52800020 	mov	w0, #0x1                   	// #1
    22c8:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x170f8>
    22cc:	f947f442 	ldr	x2, [x2, #4072]
    22d0:	910023e1 	add	x1, sp, #0x8
    22d4:	a9027bfd 	stp	x29, x30, [sp, #32]
    22d8:	910083fd 	add	x29, sp, #0x20
    22dc:	f9400043 	ldr	x3, [x2]
    22e0:	f9000fe3 	str	x3, [sp, #24]
    22e4:	d2800003 	mov	x3, #0x0                   	// #0
    22e8:	97fffc52 	bl	1430 <clock_gettime@plt>
    22ec:	350002c0 	cbnz	w0, 2344 <fwp_now_ns+0x84>
    22f0:	a9408be1 	ldp	x1, x2, [sp, #8]
    22f4:	d2994003 	mov	x3, #0xca00                	// #51712
    22f8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    22fc:	9b037c20 	mul	x0, x1, x3
    2300:	9b437c21 	smulh	x1, x1, x3
    2304:	ab020000 	adds	x0, x0, x2
    2308:	937ffc42 	asr	x2, x2, #63
    230c:	9a020021 	adc	x1, x1, x2
    2310:	f100001f 	cmp	x0, #0x0
    2314:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    2318:	b50001e1 	cbnz	x1, 2354 <fwp_now_ns+0x94>
    231c:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x170f8>
    2320:	f947f421 	ldr	x1, [x1, #4072]
    2324:	f9400fe3 	ldr	x3, [sp, #24]
    2328:	f9400022 	ldr	x2, [x1]
    232c:	eb020063 	subs	x3, x3, x2
    2330:	d2800002 	mov	x2, #0x0                   	// #0
    2334:	540000e1 	b.ne	2350 <fwp_now_ns+0x90>  // b.any
    2338:	a9427bfd 	ldp	x29, x30, [sp, #32]
    233c:	9100c3ff 	add	sp, sp, #0x30
    2340:	d65f03c0 	ret
    2344:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2348:	91322000 	add	x0, x0, #0xc88
    234c:	97ffffcd 	bl	2280 <fwp_trap>
    2350:	97fffc6c 	bl	1500 <__stack_chk_fail@plt>
    2354:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2358:	9132a000 	add	x0, x0, #0xca8
    235c:	97ffffc9 	bl	2280 <fwp_trap>

0000000000002360 <fwp_format_g.constprop.0>:
    2360:	d10483ff 	sub	sp, sp, #0x120
    2364:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    2368:	b00000e2 	adrp	x2, 1f000 <__FRAME_END__+0x170f8>
    236c:	f947f442 	ldr	x2, [x2, #4072]
    2370:	91334084 	add	x4, x4, #0xcd0
    2374:	a90b7bfd 	stp	x29, x30, [sp, #176]
    2378:	9102c3fd 	add	x29, sp, #0xb0
    237c:	d2800803 	mov	x3, #0x40                  	// #64
    2380:	a90e63f7 	stp	x23, x24, [sp, #224]
    2384:	93407c38 	sxtw	x24, w1
    2388:	aa0303e1 	mov	x1, x3
    238c:	fd008be8 	str	d8, [sp, #272]
    2390:	1e604008 	fmov	d8, d0
    2394:	a90c53f3 	stp	x19, x20, [sp, #192]
    2398:	910083f4 	add	x20, sp, #0x20
    239c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    23a0:	aa0003f5 	mov	x21, x0
    23a4:	a91073fb 	stp	x27, x28, [sp, #256]
    23a8:	5100071c 	sub	w28, w24, #0x1
    23ac:	2a1c03e5 	mov	w5, w28
    23b0:	f9400040 	ldr	x0, [x2]
    23b4:	f90057e0 	str	x0, [sp, #168]
    23b8:	d2800000 	mov	x0, #0x0                   	// #0
    23bc:	52800042 	mov	w2, #0x2                   	// #2
    23c0:	aa1403e0 	mov	x0, x20
    23c4:	97fffc2b 	bl	1470 <__snprintf_chk@plt>
    23c8:	52800ca1 	mov	w1, #0x65                  	// #101
    23cc:	aa1403e0 	mov	x0, x20
    23d0:	97fffc84 	bl	15e0 <strchr@plt>
    23d4:	aa0003f3 	mov	x19, x0
    23d8:	52800142 	mov	w2, #0xa                   	// #10
    23dc:	91000400 	add	x0, x0, #0x1
    23e0:	d2800001 	mov	x1, #0x0                   	// #0
    23e4:	97fffc6f 	bl	15a0 <strtol@plt>
    23e8:	aa0003f7 	mov	x23, x0
    23ec:	11001400 	add	w0, w0, #0x5
    23f0:	7100541f 	cmp	w0, #0x15
    23f4:	54000d68 	b.hi	25a0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    23f8:	4b170385 	sub	w5, w28, w23
    23fc:	710000bf 	cmp	w5, #0x0
    2400:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    2404:	54000b80 	b.eq	2574 <fwp_format_g.constprop.0+0x214>  // b.none
    2408:	394083e0 	ldrb	w0, [sp, #32]
    240c:	cb180273 	sub	x19, x19, x24
    2410:	91000673 	add	x19, x19, #0x1
    2414:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2418:	7100b41f 	cmp	w0, #0x2d
    241c:	9a941681 	cinc	x1, x20, eq	// eq = none
    2420:	1a9f17e4 	cset	w4, eq	// eq = none
    2424:	cb010266 	sub	x6, x19, x1
    2428:	d10004da 	sub	x26, x6, #0x1
    242c:	540018a0 	b.eq	2740 <fwp_format_g.constprop.0+0x3e0>  // b.none
    2430:	910183f9 	add	x25, sp, #0x60
    2434:	d280091b 	mov	x27, #0x48                  	// #72
    2438:	aa1903e7 	mov	x7, x25
    243c:	91000423 	add	x3, x1, #0x1
    2440:	91011cc6 	add	x6, x6, #0x47
    2444:	910004f6 	add	x22, x7, #0x1
    2448:	37f80ff7 	tbnz	w23, #31, 2644 <fwp_format_g.constprop.0+0x2e4>
    244c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    2450:	93407ef7 	sxtw	x23, w23
    2454:	390000e4 	strb	w4, [x7]
    2458:	aa1303e1 	mov	x1, x19
    245c:	aa1703e2 	mov	x2, x23
    2460:	aa1603e0 	mov	x0, x22
    2464:	b9000be5 	str	w5, [sp, #8]
    2468:	cb170374 	sub	x20, x27, x23
    246c:	a9011be3 	stp	x3, x6, [sp, #16]
    2470:	97fffbbc 	bl	1360 <memcpy@plt>
    2474:	d1000694 	sub	x20, x20, #0x1
    2478:	f9400be3 	ldr	x3, [sp, #16]
    247c:	8b1702d6 	add	x22, x22, x23
    2480:	aa1603e0 	mov	x0, x22
    2484:	aa1a03e2 	mov	x2, x26
    2488:	aa0303e1 	mov	x1, x3
    248c:	aa1403e3 	mov	x3, x20
    2490:	97fffbf0 	bl	1450 <__memcpy_chk@plt>
    2494:	8b1a02d6 	add	x22, x22, x26
    2498:	f9400fe6 	ldr	x6, [sp, #24]
    249c:	d2800900 	mov	x0, #0x48                  	// #72
    24a0:	b9400be5 	ldr	w5, [sp, #8]
    24a4:	8b170261 	add	x1, x19, x23
    24a8:	cb1400c3 	sub	x3, x6, x20
    24ac:	cb060294 	sub	x20, x20, x6
    24b0:	f101207f 	cmp	x3, #0x48
    24b4:	93407cb8 	sxtw	x24, w5
    24b8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    24bc:	aa1803e2 	mov	x2, x24
    24c0:	8b1802d3 	add	x19, x22, x24
    24c4:	8b140063 	add	x3, x3, x20
    24c8:	aa1603e0 	mov	x0, x22
    24cc:	97fffbe1 	bl	1450 <__memcpy_chk@plt>
    24d0:	cb190273 	sub	x19, x19, x25
    24d4:	d28031e0 	mov	x0, #0x18f                 	// #399
    24d8:	eb00027f 	cmp	x19, x0
    24dc:	aa1903e1 	mov	x1, x25
    24e0:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    24e4:	aa1503e0 	mov	x0, x21
    24e8:	aa1303e2 	mov	x2, x19
    24ec:	97fffb9d 	bl	1360 <memcpy@plt>
    24f0:	38336abf 	strb	wzr, [x21, x19]
    24f4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    24f8:	aa1503e0 	mov	x0, x21
    24fc:	97fffba5 	bl	1390 <strlen@plt>
    2500:	aa0003f3 	mov	x19, x0
    2504:	528005c1 	mov	w1, #0x2e                  	// #46
    2508:	aa1503e0 	mov	x0, x21
    250c:	97fffc35 	bl	15e0 <strchr@plt>
    2510:	b4000140 	cbz	x0, 2538 <fwp_format_g.constprop.0+0x1d8>
    2514:	b4000133 	cbz	x19, 2538 <fwp_format_g.constprop.0+0x1d8>
    2518:	aa1303e1 	mov	x1, x19
    251c:	d1000673 	sub	x19, x19, #0x1
    2520:	38736aa0 	ldrb	w0, [x21, x19]
    2524:	7100c01f 	cmp	w0, #0x30
    2528:	54001001 	b.ne	2728 <fwp_format_g.constprop.0+0x3c8>  // b.any
    252c:	38336abf 	strb	wzr, [x21, x19]
    2530:	b5ffff53 	cbnz	x19, 2518 <fwp_format_g.constprop.0+0x1b8>
    2534:	d503201f 	nop
    2538:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    253c:	f947f400 	ldr	x0, [x0, #4072]
    2540:	f94057e2 	ldr	x2, [sp, #168]
    2544:	f9400001 	ldr	x1, [x0]
    2548:	eb010042 	subs	x2, x2, x1
    254c:	d2800001 	mov	x1, #0x0                   	// #0
    2550:	54001061 	b.ne	275c <fwp_format_g.constprop.0+0x3fc>  // b.any
    2554:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    2558:	a94c53f3 	ldp	x19, x20, [sp, #192]
    255c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    2560:	a94e63f7 	ldp	x23, x24, [sp, #224]
    2564:	a95073fb 	ldp	x27, x28, [sp, #256]
    2568:	fd408be8 	ldr	d8, [sp, #272]
    256c:	910483ff 	add	sp, sp, #0x120
    2570:	d65f03c0 	ret
    2574:	1e604100 	fmov	d0, d8
    2578:	710000bf 	cmp	w5, #0x0
    257c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    2580:	aa1503e0 	mov	x0, x21
    2584:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    2588:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    258c:	9133a084 	add	x4, x4, #0xce8
    2590:	52800042 	mov	w2, #0x2                   	// #2
    2594:	d2803201 	mov	x1, #0x190                 	// #400
    2598:	97fffbb6 	bl	1470 <__snprintf_chk@plt>
    259c:	17ffffd7 	b	24f8 <fwp_format_g.constprop.0+0x198>
    25a0:	cb140273 	sub	x19, x19, x20
    25a4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    25a8:	910183f9 	add	x25, sp, #0x60
    25ac:	aa1303e2 	mov	x2, x19
    25b0:	aa1403e1 	mov	x1, x20
    25b4:	aa1903e0 	mov	x0, x25
    25b8:	d2800803 	mov	x3, #0x40                  	// #64
    25bc:	97fffba5 	bl	1450 <__memcpy_chk@plt>
    25c0:	38336b3f 	strb	wzr, [x25, x19]
    25c4:	aa1903e0 	mov	x0, x25
    25c8:	528005c1 	mov	w1, #0x2e                  	// #46
    25cc:	97fffc05 	bl	15e0 <strchr@plt>
    25d0:	b40001c0 	cbz	x0, 2608 <fwp_format_g.constprop.0+0x2a8>
    25d4:	b50000b3 	cbnz	x19, 25e8 <fwp_format_g.constprop.0+0x288>
    25d8:	1400000c 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    25dc:	381ff01f 	sturb	wzr, [x0, #-1]
    25e0:	f1000673 	subs	x19, x19, #0x1
    25e4:	54000120 	b.eq	2608 <fwp_format_g.constprop.0+0x2a8>  // b.none
    25e8:	8b130320 	add	x0, x25, x19
    25ec:	385ff001 	ldurb	w1, [x0, #-1]
    25f0:	7100c03f 	cmp	w1, #0x30
    25f4:	54ffff40 	b.eq	25dc <fwp_format_g.constprop.0+0x27c>  // b.none
    25f8:	d1000673 	sub	x19, x19, #0x1
    25fc:	38736b20 	ldrb	w0, [x25, x19]
    2600:	7100b81f 	cmp	w0, #0x2e
    2604:	54000a80 	b.eq	2754 <fwp_format_g.constprop.0+0x3f4>  // b.none
    2608:	710002ff 	cmp	w23, #0x0
    260c:	528005a1 	mov	w1, #0x2d                  	// #45
    2610:	aa1903e5 	mov	x5, x25
    2614:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    2618:	aa1503e0 	mov	x0, x21
    261c:	52800566 	mov	w6, #0x2b                  	// #43
    2620:	90000024 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    2624:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    2628:	91336084 	add	x4, x4, #0xcd8
    262c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    2630:	52800042 	mov	w2, #0x2                   	// #2
    2634:	d2803201 	mov	x1, #0x190                 	// #400
    2638:	97fffb8e 	bl	1470 <__snprintf_chk@plt>
    263c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    2640:	17ffffbe 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2644:	52800605 	mov	w5, #0x30                  	// #48
    2648:	390000e5 	strb	w5, [x7]
    264c:	d100077b 	sub	x27, x27, #0x1
    2650:	aa0303e1 	mov	x1, x3
    2654:	aa1603e0 	mov	x0, x22
    2658:	aa1b03e3 	mov	x3, x27
    265c:	aa1a03e2 	mov	x2, x26
    2660:	f90007e6 	str	x6, [sp, #8]
    2664:	b90013e4 	str	w4, [sp, #16]
    2668:	8b1a02d6 	add	x22, x22, x26
    266c:	b9001be5 	str	w5, [sp, #24]
    2670:	97fffb78 	bl	1450 <__memcpy_chk@plt>
    2674:	f94007e6 	ldr	x6, [sp, #8]
    2678:	2a3703e7 	mvn	w7, w23
    267c:	b94013e4 	ldr	w4, [sp, #16]
    2680:	cb1b00c1 	sub	x1, x6, x27
    2684:	cb06037b 	sub	x27, x27, x6
    2688:	f101203f 	cmp	x1, #0x48
    268c:	d2800906 	mov	x6, #0x48                  	// #72
    2690:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    2694:	8b1b0023 	add	x3, x1, x27
    2698:	310006ff 	cmn	w23, #0x1
    269c:	54000220 	b.eq	26e0 <fwp_format_g.constprop.0+0x380>  // b.none
    26a0:	b9401be5 	ldr	w5, [sp, #24]
    26a4:	d2800001 	mov	x1, #0x0                   	// #0
    26a8:	f101207f 	cmp	x3, #0x48
    26ac:	d1000462 	sub	x2, x3, #0x1
    26b0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    26b4:	38216ac5 	strb	w5, [x22, x1]
    26b8:	cb030003 	sub	x3, x0, x3
    26bc:	91000421 	add	x1, x1, #0x1
    26c0:	91000463 	add	x3, x3, #0x1
    26c4:	eb00007f 	cmp	x3, x0
    26c8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    26cc:	cb000063 	sub	x3, x3, x0
    26d0:	8b020063 	add	x3, x3, x2
    26d4:	6b0100ff 	cmp	w7, w1
    26d8:	54fffe8c 	b.gt	26a8 <fwp_format_g.constprop.0+0x348>
    26dc:	8b2742d6 	add	x22, x22, w7, uxtw
    26e0:	f101207f 	cmp	x3, #0x48
    26e4:	d2800905 	mov	x5, #0x48                  	// #72
    26e8:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    26ec:	aa1603e0 	mov	x0, x22
    26f0:	cb0300a1 	sub	x1, x5, x3
    26f4:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    26f8:	91000421 	add	x1, x1, #0x1
    26fc:	d1000463 	sub	x3, x3, #0x1
    2700:	eb05003f 	cmp	x1, x5
    2704:	38001402 	strb	w2, [x0], #1
    2708:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    270c:	93407f82 	sxtw	x2, w28
    2710:	cb050025 	sub	x5, x1, x5
    2714:	aa1303e1 	mov	x1, x19
    2718:	8b0300a3 	add	x3, x5, x3
    271c:	8b1802d3 	add	x19, x22, x24
    2720:	97fffb4c 	bl	1450 <__memcpy_chk@plt>
    2724:	17ffff6b 	b	24d0 <fwp_format_g.constprop.0+0x170>
    2728:	d1000421 	sub	x1, x1, #0x1
    272c:	38616aa0 	ldrb	w0, [x21, x1]
    2730:	7100b81f 	cmp	w0, #0x2e
    2734:	54fff021 	b.ne	2538 <fwp_format_g.constprop.0+0x1d8>  // b.any
    2738:	38216abf 	strb	wzr, [x21, x1]
    273c:	17ffff7f 	b	2538 <fwp_format_g.constprop.0+0x1d8>
    2740:	910187e7 	add	x7, sp, #0x61
    2744:	910183f9 	add	x25, sp, #0x60
    2748:	d28008fb 	mov	x27, #0x47                  	// #71
    274c:	390183e0 	strb	w0, [sp, #96]
    2750:	17ffff3b 	b	243c <fwp_format_g.constprop.0+0xdc>
    2754:	38336b3f 	strb	wzr, [x25, x19]
    2758:	17ffffac 	b	2608 <fwp_format_g.constprop.0+0x2a8>
    275c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    2760:	97fffb68 	bl	1500 <__stack_chk_fail@plt>

0000000000002764 <fwp_heap_report>:
    2764:	d105c3ff 	sub	sp, sp, #0x170
    2768:	f0000162 	adrp	x2, 31000 <fwp_root_context+0xc80>
    276c:	91158042 	add	x2, x2, #0x560
    2770:	b00000e1 	adrp	x1, 1f000 <__FRAME_END__+0x170f8>
    2774:	f947e821 	ldr	x1, [x1, #4048]
    2778:	a9117bfd 	stp	x29, x30, [sp, #272]
    277c:	910443fd 	add	x29, sp, #0x110
    2780:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    2784:	f947f400 	ldr	x0, [x0, #4072]
    2788:	a9135bf5 	stp	x21, x22, [sp, #304]
    278c:	a91463f7 	stp	x23, x24, [sp, #320]
    2790:	a9156bf9 	stp	x25, x26, [sp, #336]
    2794:	6d1627e8 	stp	d8, d9, [sp, #352]
    2798:	fd4a1c48 	ldr	d8, [x2, #5176]
    279c:	fd4a2049 	ldr	d9, [x2, #5184]
    27a0:	f9400036 	ldr	x22, [x1]
    27a4:	f9400001 	ldr	x1, [x0]
    27a8:	f90087e1 	str	x1, [sp, #264]
    27ac:	d2800001 	mov	x1, #0x0                   	// #0
    27b0:	f949e459 	ldr	x25, [x2, #5064]
    27b4:	90000021 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    27b8:	f94a1057 	ldr	x23, [x2, #5152]
    27bc:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    27c0:	f94a1458 	ldr	x24, [x2, #5160]
    27c4:	9133c021 	add	x1, x1, #0xcf0
    27c8:	9133e000 	add	x0, x0, #0xcf8
    27cc:	97fffb31 	bl	1490 <fopen@plt>
    27d0:	b4000760 	cbz	x0, 28bc <fwp_heap_report+0x158>
    27d4:	528daad5 	mov	w21, #0x6d56                	// #27990
    27d8:	a91253f3 	stp	x19, x20, [sp, #288]
    27dc:	aa0003f4 	mov	x20, x0
    27e0:	910023f3 	add	x19, sp, #0x8
    27e4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    27e8:	72aae915 	movk	w21, #0x5748, lsl #16
    27ec:	d503201f 	nop
    27f0:	aa1403e2 	mov	x2, x20
    27f4:	aa1303e0 	mov	x0, x19
    27f8:	52802001 	mov	w1, #0x100                 	// #256
    27fc:	97fffbad 	bl	16b0 <fgets@plt>
    2800:	b4000280 	cbz	x0, 2850 <fwp_heap_report+0xec>
    2804:	b9400261 	ldr	w1, [x19]
    2808:	6b15003f 	cmp	w1, w21
    280c:	54ffff21 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2810:	39401260 	ldrb	w0, [x19, #4]
    2814:	7101341f 	cmp	w0, #0x4d
    2818:	54fffec1 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    281c:	394037e0 	ldrb	w0, [sp, #13]
    2820:	7100e81f 	cmp	w0, #0x3a
    2824:	54fffe61 	b.ne	27f0 <fwp_heap_report+0x8c>  // b.any
    2828:	52800142 	mov	w2, #0xa                   	// #10
    282c:	d2800001 	mov	x1, #0x0                   	// #0
    2830:	91003be0 	add	x0, sp, #0xe
    2834:	97fffb5b 	bl	15a0 <strtol@plt>
    2838:	aa1403e2 	mov	x2, x20
    283c:	aa0003fa 	mov	x26, x0
    2840:	52802001 	mov	w1, #0x100                 	// #256
    2844:	aa1303e0 	mov	x0, x19
    2848:	97fffb9a 	bl	16b0 <fgets@plt>
    284c:	b5fffdc0 	cbnz	x0, 2804 <fwp_heap_report+0xa0>
    2850:	aa1403e0 	mov	x0, x20
    2854:	97fffb0b 	bl	1480 <fclose@plt>
    2858:	a95253f3 	ldp	x19, x20, [sp, #288]
    285c:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    2860:	f947f400 	ldr	x0, [x0, #4072]
    2864:	f94087e2 	ldr	x2, [sp, #264]
    2868:	f9400001 	ldr	x1, [x0]
    286c:	eb010042 	subs	x2, x2, x1
    2870:	d2800001 	mov	x1, #0x0                   	// #0
    2874:	54000281 	b.ne	28c4 <fwp_heap_report+0x160>  // b.any
    2878:	a9517bfd 	ldp	x29, x30, [sp, #272]
    287c:	aa1a03e6 	mov	x6, x26
    2880:	aa1903e5 	mov	x5, x25
    2884:	aa1803e4 	mov	x4, x24
    2888:	a9556bf9 	ldp	x25, x26, [sp, #336]
    288c:	aa1703e3 	mov	x3, x23
    2890:	a95463f7 	ldp	x23, x24, [sp, #320]
    2894:	aa1603e0 	mov	x0, x22
    2898:	a9535bf5 	ldp	x21, x22, [sp, #304]
    289c:	1e604121 	fmov	d1, d9
    28a0:	1e604100 	fmov	d0, d8
    28a4:	90000022 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    28a8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    28ac:	91346042 	add	x2, x2, #0xd18
    28b0:	9105c3ff 	add	sp, sp, #0x170
    28b4:	52800041 	mov	w1, #0x2                   	// #2
    28b8:	17fffb2e 	b	1570 <__fprintf_chk@plt>
    28bc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    28c0:	17ffffe7 	b	285c <fwp_heap_report+0xf8>
    28c4:	a91253f3 	stp	x19, x20, [sp, #288]
    28c8:	97fffb0e 	bl	1500 <__stack_chk_fail@plt>
    28cc:	d503201f 	nop

00000000000028d0 <fwp_heap_init>:
    28d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    28d4:	90000183 	adrp	x3, 32000 <fwp_heap+0xaa0>
    28d8:	91118061 	add	x1, x3, #0x460
    28dc:	910003fd 	mov	x29, sp
    28e0:	a90153f3 	stp	x19, x20, [sp, #16]
    28e4:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xc80>
    28e8:	91158262 	add	x2, x19, #0x560
    28ec:	a9025bf5 	stp	x21, x22, [sp, #32]
    28f0:	52800024 	mov	w4, #0x1                   	// #1
    28f4:	52800200 	mov	w0, #0x10                  	// #16
    28f8:	b913a444 	str	w4, [x2, #5028]
    28fc:	d503201f 	nop
    2900:	b8004420 	str	w0, [x1], #4
    2904:	11004000 	add	w0, w0, #0x10
    2908:	7104401f 	cmp	w0, #0x110
    290c:	54ffffa1 	b.ne	2900 <fwp_heap_init+0x30>  // b.any
    2910:	b0000022 	adrp	x2, 7000 <_IO_stdin_used+0x4b0>
    2914:	0f002420 	movi	v0.2s, #0x1, lsl #8
    2918:	90000181 	adrp	x1, 32000 <fwp_heap+0xaa0>
    291c:	91128021 	add	x1, x1, #0x4a0
    2920:	3dc08c43 	ldr	q3, [x2, #560]
    2924:	d2800000 	mov	x0, #0x0                   	// #0
    2928:	4e040401 	dup	v1.4s, v0.s[0]
    292c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    2930:	0f215400 	shl	v0.2s, v0.2s, #1
    2934:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    2938:	3ca06821 	str	q1, [x1, x0]
    293c:	91004000 	add	x0, x0, #0x10
    2940:	f101801f 	cmp	x0, #0x60
    2944:	54ffff21 	b.ne	2928 <fwp_heap_init+0x58>  // b.any
    2948:	90000184 	adrp	x4, 32000 <fwp_heap+0xaa0>
    294c:	91118063 	add	x3, x3, #0x460
    2950:	91140084 	add	x4, x4, #0x500
    2954:	91158266 	add	x6, x19, #0x560
    2958:	d2800002 	mov	x2, #0x0                   	// #0
    295c:	d2800000 	mov	x0, #0x0                   	// #0
    2960:	d2880205 	mov	x5, #0x4010                	// #16400
    2964:	d503201f 	nop
    2968:	910f0001 	add	x1, x0, #0x3c0
    296c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    2970:	eb02003f 	cmp	x1, x2
    2974:	540000a2 	b.cs	2988 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    2978:	91000400 	add	x0, x0, #0x1
    297c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    2980:	eb02003f 	cmp	x1, x2
    2984:	54ffffa3 	b.cc	2978 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    2988:	91004042 	add	x2, x2, #0x10
    298c:	38001480 	strb	w0, [x4], #1
    2990:	eb05005f 	cmp	x2, x5
    2994:	54fffea1 	b.ne	2968 <fwp_heap_init+0x98>  // b.any
    2998:	528000b5 	mov	w21, #0x5                   	// #5
    299c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    29a0:	14000004 	b	29b0 <fwp_heap_init+0xe0>
    29a4:	d342fe94 	lsr	x20, x20, #2
    29a8:	710006b5 	subs	w21, w21, #0x1
    29ac:	54000720 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    29b0:	91404296 	add	x22, x20, #0x10, lsl #12
    29b4:	d2800005 	mov	x5, #0x0                   	// #0
    29b8:	aa1603e1 	mov	x1, x22
    29bc:	12800004 	mov	w4, #0xffffffff            	// #-1
    29c0:	52880443 	mov	w3, #0x4022                	// #16418
    29c4:	52800002 	mov	w2, #0x0                   	// #0
    29c8:	d2800000 	mov	x0, #0x0                   	// #0
    29cc:	97fffaf1 	bl	1590 <mmap@plt>
    29d0:	aa0003e6 	mov	x6, x0
    29d4:	b100041f 	cmn	x0, #0x1
    29d8:	54fffe60 	b.eq	29a4 <fwp_heap_init+0xd4>  // b.none
    29dc:	b40005a0 	cbz	x0, 2a90 <fwp_heap_init+0x1c0>
    29e0:	d350fe94 	lsr	x20, x20, #16
    29e4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    29e8:	8b0000c7 	add	x7, x6, x0
    29ec:	91158275 	add	x21, x19, #0x560
    29f0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    29f4:	8b140a81 	add	x1, x20, x20, lsl #2
    29f8:	d2800005 	mov	x5, #0x0                   	// #0
    29fc:	12800004 	mov	w4, #0xffffffff            	// #-1
    2a00:	d37df021 	lsl	x1, x1, #3
    2a04:	52880443 	mov	w3, #0x4022                	// #16418
    2a08:	52800002 	mov	w2, #0x0                   	// #0
    2a0c:	d2800000 	mov	x0, #0x0                   	// #0
    2a10:	f909daa7 	str	x7, [x21, #5040]
    2a14:	f909dea6 	str	x6, [x21, #5048]
    2a18:	f909e2b6 	str	x22, [x21, #5056]
    2a1c:	f909eab4 	str	x20, [x21, #5072]
    2a20:	f90a02a1 	str	x1, [x21, #5120]
    2a24:	97fffadb 	bl	1590 <mmap@plt>
    2a28:	aa0003e1 	mov	x1, x0
    2a2c:	b100041f 	cmn	x0, #0x1
    2a30:	54000300 	b.eq	2a90 <fwp_heap_init+0x1c0>  // b.none
    2a34:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2a38:	91372000 	add	x0, x0, #0xdc8
    2a3c:	f909fea1 	str	x1, [x21, #5112]
    2a40:	97fffb14 	bl	1690 <getenv@plt>
    2a44:	52800002 	mov	w2, #0x0                   	// #0
    2a48:	aa0003e1 	mov	x1, x0
    2a4c:	b40000e0 	cbz	x0, 2a68 <fwp_heap_init+0x198>
    2a50:	39400000 	ldrb	w0, [x0]
    2a54:	340000a0 	cbz	w0, 2a68 <fwp_heap_init+0x198>
    2a58:	7100c000 	subs	w0, w0, #0x30
    2a5c:	54000120 	b.eq	2a80 <fwp_heap_init+0x1b0>  // b.none
    2a60:	7100001f 	cmp	w0, #0x0
    2a64:	1a9f07e2 	cset	w2, ne	// ne = any
    2a68:	91158273 	add	x19, x19, #0x560
    2a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2a70:	b913aa62 	str	w2, [x19, #5032]
    2a74:	a94153f3 	ldp	x19, x20, [sp, #16]
    2a78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2a7c:	d65f03c0 	ret
    2a80:	39400420 	ldrb	w0, [x1, #1]
    2a84:	7100001f 	cmp	w0, #0x0
    2a88:	1a9f07e2 	cset	w2, ne	// ne = any
    2a8c:	17fffff7 	b	2a68 <fwp_heap_init+0x198>
    2a90:	97fffc90 	bl	1cd0 <fwp_heap_oom>

0000000000002a94 <fwp_wake_io>:
    2a94:	d00000e9 	adrp	x9, 20000 <__data_start>
    2a98:	91020122 	add	x2, x9, #0x80
    2a9c:	f9400001 	ldr	x1, [x0]
    2aa0:	5280000a 	mov	w10, #0x0                   	// #0
    2aa4:	f9401446 	ldr	x6, [x2, #40]
    2aa8:	52800008 	mov	w8, #0x0                   	// #0
    2aac:	4f000400 	movi	v0.4s, #0x0
    2ab0:	52800027 	mov	w7, #0x1                   	// #1
    2ab4:	aa0103e2 	mov	x2, x1
    2ab8:	b4000321 	cbz	x1, 2b1c <fwp_wake_io+0x88>
    2abc:	f9408c25 	ldr	x5, [x1, #280]
    2ac0:	39015c27 	strb	w7, [x1, #87]
    2ac4:	b4000165 	cbz	x5, 2af0 <fwp_wake_io+0x5c>
    2ac8:	a9520c24 	ldp	x4, x3, [x1, #288]
    2acc:	b4000364 	cbz	x4, 2b38 <fwp_wake_io+0xa4>
    2ad0:	f9009483 	str	x3, [x4, #296]
    2ad4:	f9409423 	ldr	x3, [x1, #296]
    2ad8:	b4000043 	cbz	x3, 2ae0 <fwp_wake_io+0x4c>
    2adc:	f9009064 	str	x4, [x3, #288]
    2ae0:	91080023 	add	x3, x1, #0x200
    2ae4:	f900943f 	str	xzr, [x1, #296]
    2ae8:	3c918060 	stur	q0, [x3, #-232]
    2aec:	f9400001 	ldr	x1, [x0]
    2af0:	f9402843 	ldr	x3, [x2, #80]
    2af4:	f2001c7f 	tst	x3, #0xff000000ff
    2af8:	54fffde1 	b.ne	2ab4 <fwp_wake_io+0x20>  // b.any
    2afc:	39015047 	strb	w7, [x2, #84]
    2b00:	f900805f 	str	xzr, [x2, #256]
    2b04:	b40001e6 	cbz	x6, 2b40 <fwp_wake_io+0xac>
    2b08:	f90080c2 	str	x2, [x6, #256]
    2b0c:	aa0203e6 	mov	x6, x2
    2b10:	52800028 	mov	w8, #0x1                   	// #1
    2b14:	aa0103e2 	mov	x2, x1
    2b18:	b5fffd21 	cbnz	x1, 2abc <fwp_wake_io+0x28>
    2b1c:	3400006a 	cbz	w10, 2b28 <fwp_wake_io+0x94>
    2b20:	91020120 	add	x0, x9, #0x80
    2b24:	f900180b 	str	x11, [x0, #48]
    2b28:	34000068 	cbz	w8, 2b34 <fwp_wake_io+0xa0>
    2b2c:	91020129 	add	x9, x9, #0x80
    2b30:	f9001526 	str	x6, [x9, #40]
    2b34:	d65f03c0 	ret
    2b38:	f90000a3 	str	x3, [x5]
    2b3c:	17ffffe7 	b	2ad8 <fwp_wake_io+0x44>
    2b40:	aa0203eb 	mov	x11, x2
    2b44:	5280002a 	mov	w10, #0x1                   	// #1
    2b48:	17fffff1 	b	2b0c <fwp_wake_io+0x78>
    2b4c:	d503201f 	nop

0000000000002b50 <fwp_poll_events>:
    2b50:	d10103ff 	sub	sp, sp, #0x40
    2b54:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    2b58:	f947f400 	ldr	x0, [x0, #4072]
    2b5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    2b60:	910083fd 	add	x29, sp, #0x20
    2b64:	a90353f3 	stp	x19, x20, [sp, #48]
    2b68:	d00000f4 	adrp	x20, 20000 <__data_start>
    2b6c:	f9400001 	ldr	x1, [x0]
    2b70:	f9000fe1 	str	x1, [sp, #24]
    2b74:	d2800001 	mov	x1, #0x0                   	// #0
    2b78:	97fffdd2 	bl	22c0 <fwp_now_ns>
    2b7c:	91020281 	add	x1, x20, #0x80
    2b80:	f9401c33 	ldr	x19, [x1, #56]
    2b84:	b4000e93 	cbz	x19, 2d54 <fwp_poll_events+0x204>
    2b88:	aa1303e1 	mov	x1, x19
    2b8c:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    2b90:	14000005 	b	2ba4 <fwp_poll_events+0x54>
    2b94:	f9408821 	ldr	x1, [x1, #272]
    2b98:	eb03005f 	cmp	x2, x3
    2b9c:	9a83d042 	csel	x2, x2, x3, le
    2ba0:	b40000c1 	cbz	x1, 2bb8 <fwp_poll_events+0x68>
    2ba4:	f9403423 	ldr	x3, [x1, #104]
    2ba8:	b6ffff62 	tbz	x2, #63, 2b94 <fwp_poll_events+0x44>
    2bac:	f9408821 	ldr	x1, [x1, #272]
    2bb0:	aa0303e2 	mov	x2, x3
    2bb4:	b5ffff81 	cbnz	x1, 2ba4 <fwp_poll_events+0x54>
    2bb8:	b7f80ce2 	tbnz	x2, #63, 2d54 <fwp_poll_events+0x204>
    2bbc:	cb000042 	sub	x2, x2, x0
    2bc0:	f100005f 	cmp	x2, #0x0
    2bc4:	540005cd 	b.le	2c7c <fwp_poll_events+0x12c>
    2bc8:	d2869b60 	mov	x0, #0x34db                	// #13531
    2bcc:	d2884801 	mov	x1, #0x4240                	// #16960
    2bd0:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    2bd4:	f2a001e1 	movk	x1, #0xf, lsl #16
    2bd8:	f2dbd040 	movk	x0, #0xde82, lsl #32
    2bdc:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    2be0:	f2e86360 	movk	x0, #0x431b, lsl #48
    2be4:	9b407c40 	smulh	x0, x2, x0
    2be8:	9352fc00 	asr	x0, x0, #18
    2bec:	cb82fc00 	sub	x0, x0, x2, asr #63
    2bf0:	9b018802 	msub	x2, x0, x1, x2
    2bf4:	f100005f 	cmp	x2, #0x0
    2bf8:	9a800400 	cinc	x0, x0, ne	// ne = any
    2bfc:	eb03001f 	cmp	x0, x3
    2c00:	54000a0c 	b.gt	2d40 <fwp_poll_events+0x1f0>
    2c04:	340003c0 	cbz	w0, 2c7c <fwp_poll_events+0x12c>
    2c08:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    2c0c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    2c10:	72a20c42 	movk	w2, #0x1062, lsl #16
    2c14:	9ba27c02 	umull	x2, w0, w2
    2c18:	d366fc43 	lsr	x3, x2, #38
    2c1c:	aa0303e2 	mov	x2, x3
    2c20:	1b048063 	msub	w3, w3, w4, w0
    2c24:	9b217c63 	smull	x3, w3, w1
    2c28:	d2800001 	mov	x1, #0x0                   	// #0
    2c2c:	910023e0 	add	x0, sp, #0x8
    2c30:	a9008fe2 	stp	x2, x3, [sp, #8]
    2c34:	97fffa67 	bl	15d0 <nanosleep@plt>
    2c38:	91020280 	add	x0, x20, #0x80
    2c3c:	f9401c13 	ldr	x19, [x0, #56]
    2c40:	97fffda0 	bl	22c0 <fwp_now_ns>
    2c44:	aa0003e6 	mov	x6, x0
    2c48:	b50001f3 	cbnz	x19, 2c84 <fwp_poll_events+0x134>
    2c4c:	d503201f 	nop
    2c50:	b00000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    2c54:	f947f400 	ldr	x0, [x0, #4072]
    2c58:	f9400fe2 	ldr	x2, [sp, #24]
    2c5c:	f9400001 	ldr	x1, [x0]
    2c60:	eb010042 	subs	x2, x2, x1
    2c64:	d2800001 	mov	x1, #0x0                   	// #0
    2c68:	540008c1 	b.ne	2d80 <fwp_poll_events+0x230>  // b.any
    2c6c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    2c70:	a94353f3 	ldp	x19, x20, [sp, #48]
    2c74:	910103ff 	add	sp, sp, #0x40
    2c78:	d65f03c0 	ret
    2c7c:	97fffd91 	bl	22c0 <fwp_now_ns>
    2c80:	aa0003e6 	mov	x6, x0
    2c84:	4f000400 	movi	v0.4s, #0x0
    2c88:	91020288 	add	x8, x20, #0x80
    2c8c:	52800027 	mov	w7, #0x1                   	// #1
    2c90:	f9403661 	ldr	x1, [x19, #104]
    2c94:	aa1303e5 	mov	x5, x19
    2c98:	f9408a73 	ldr	x19, [x19, #272]
    2c9c:	eb06003f 	cmp	x1, x6
    2ca0:	5400032c 	b.gt	2d04 <fwp_poll_events+0x1b4>
    2ca4:	394154a0 	ldrb	w0, [x5, #85]
    2ca8:	36000120 	tbz	w0, #0, 2ccc <fwp_poll_events+0x17c>
    2cac:	f94084a0 	ldr	x0, [x5, #264]
    2cb0:	b40003c0 	cbz	x0, 2d28 <fwp_poll_events+0x1d8>
    2cb4:	f9008813 	str	x19, [x0, #272]
    2cb8:	b4000053 	cbz	x19, 2cc0 <fwp_poll_events+0x170>
    2cbc:	f9008660 	str	x0, [x19, #264]
    2cc0:	910800a0 	add	x0, x5, #0x200
    2cc4:	390154bf 	strb	wzr, [x5, #85]
    2cc8:	3c908000 	stur	q0, [x0, #-248]
    2ccc:	f94030a0 	ldr	x0, [x5, #96]
    2cd0:	390158a7 	strb	w7, [x5, #86]
    2cd4:	f100001f 	cmp	x0, #0x0
    2cd8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    2cdc:	5400018d 	b.le	2d0c <fwp_poll_events+0x1bc>
    2ce0:	f94028a0 	ldr	x0, [x5, #80]
    2ce4:	f2001c1f 	tst	x0, #0xff000000ff
    2ce8:	540000e1 	b.ne	2d04 <fwp_poll_events+0x1b4>  // b.any
    2cec:	f9401500 	ldr	x0, [x8, #40]
    2cf0:	390150a7 	strb	w7, [x5, #84]
    2cf4:	f90080bf 	str	xzr, [x5, #256]
    2cf8:	b40001e0 	cbz	x0, 2d34 <fwp_poll_events+0x1e4>
    2cfc:	f9001505 	str	x5, [x8, #40]
    2d00:	f9008005 	str	x5, [x0, #256]
    2d04:	b5fffc73 	cbnz	x19, 2c90 <fwp_poll_events+0x140>
    2d08:	17ffffd2 	b	2c50 <fwp_poll_events+0x100>
    2d0c:	394144a0 	ldrb	w0, [x5, #81]
    2d10:	3707fe80 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d14:	394140a0 	ldrb	w0, [x5, #80]
    2d18:	3707fe40 	tbnz	w0, #0, 2ce0 <fwp_poll_events+0x190>
    2d1c:	aa0503e0 	mov	x0, x5
    2d20:	97fffd14 	bl	2170 <fwp_cancel_tree.part.0>
    2d24:	17ffffef 	b	2ce0 <fwp_poll_events+0x190>
    2d28:	91020281 	add	x1, x20, #0x80
    2d2c:	f9001c33 	str	x19, [x1, #56]
    2d30:	17ffffe2 	b	2cb8 <fwp_poll_events+0x168>
    2d34:	f9001505 	str	x5, [x8, #40]
    2d38:	f9001905 	str	x5, [x8, #48]
    2d3c:	17fffff2 	b	2d04 <fwp_poll_events+0x1b4>
    2d40:	d28df803 	mov	x3, #0x6fc0                	// #28608
    2d44:	d2989362 	mov	x2, #0xc49b                	// #50331
    2d48:	f2a4d203 	movk	x3, #0x2690, lsl #16
    2d4c:	f2a00402 	movk	x2, #0x20, lsl #16
    2d50:	17ffffb6 	b	2c28 <fwp_poll_events+0xd8>
    2d54:	97fffb9f 	bl	1bd0 <fwp_flush>
    2d58:	b00000e3 	adrp	x3, 1f000 <__FRAME_END__+0x170f8>
    2d5c:	f947e863 	ldr	x3, [x3, #4048]
    2d60:	d2800562 	mov	x2, #0x2b                  	// #43
    2d64:	d2800021 	mov	x1, #0x1                   	// #1
    2d68:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2d6c:	91376000 	add	x0, x0, #0xdd8
    2d70:	f9400063 	ldr	x3, [x3]
    2d74:	97fffa23 	bl	1600 <fwrite@plt>
    2d78:	52800ca0 	mov	w0, #0x65                  	// #101
    2d7c:	97fff98d 	bl	13b0 <exit@plt>
    2d80:	97fff9e0 	bl	1500 <__stack_chk_fail@plt>

0000000000002d84 <fwp_rc_forget_slot>:
    2d84:	aa0003e1 	mov	x1, x0
    2d88:	39400000 	ldrb	w0, [x0]
    2d8c:	7103fc1f 	cmp	w0, #0xff
    2d90:	54000040 	b.eq	2d98 <fwp_rc_forget_slot+0x14>  // b.none
    2d94:	d65f03c0 	ret
    2d98:	ca414420 	eor	x0, x1, x1, lsr #17
    2d9c:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2da0:	ca402400 	eor	x0, x0, x0, lsr #9
    2da4:	910003fd 	mov	x29, sp
    2da8:	92401c00 	and	x0, x0, #0xff
    2dac:	f9000bf3 	str	x19, [sp, #16]
    2db0:	f0000173 	adrp	x19, 31000 <fwp_root_context+0xc80>
    2db4:	91158262 	add	x2, x19, #0x560
    2db8:	910a2403 	add	x3, x0, #0x289
    2dbc:	8b000c40 	add	x0, x2, x0, lsl #3
    2dc0:	8b030c43 	add	x3, x2, x3, lsl #3
    2dc4:	f94a2400 	ldr	x0, [x0, #5192]
    2dc8:	b50000a0 	cbnz	x0, 2ddc <fwp_rc_forget_slot+0x58>
    2dcc:	14000011 	b	2e10 <fwp_rc_forget_slot+0x8c>
    2dd0:	91004003 	add	x3, x0, #0x10
    2dd4:	f9400800 	ldr	x0, [x0, #16]
    2dd8:	b40001c0 	cbz	x0, 2e10 <fwp_rc_forget_slot+0x8c>
    2ddc:	f9400002 	ldr	x2, [x0]
    2de0:	eb02003f 	cmp	x1, x2
    2de4:	54ffff61 	b.ne	2dd0 <fwp_rc_forget_slot+0x4c>  // b.any
    2de8:	f9400801 	ldr	x1, [x0, #16]
    2dec:	91158273 	add	x19, x19, #0x560
    2df0:	f9000061 	str	x1, [x3]
    2df4:	97fff9f3 	bl	15c0 <free@plt>
    2df8:	f94e2660 	ldr	x0, [x19, #7240]
    2dfc:	d1000400 	sub	x0, x0, #0x1
    2e00:	f90e2660 	str	x0, [x19, #7240]
    2e04:	f9400bf3 	ldr	x19, [sp, #16]
    2e08:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e0c:	d65f03c0 	ret
    2e10:	90000020 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    2e14:	91382000 	add	x0, x0, #0xe08
    2e18:	97fffd1a 	bl	2280 <fwp_trap>
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_rc_prepare_chunk>:
    2e20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2e24:	910003fd 	mov	x29, sp
    2e28:	a9025bf5 	stp	x21, x22, [sp, #32]
    2e2c:	f0000176 	adrp	x22, 31000 <fwp_root_context+0xc80>
    2e30:	911582c2 	add	x2, x22, #0x560
    2e34:	b9401c03 	ldr	w3, [x0, #28]
    2e38:	aa0103f5 	mov	x21, x1
    2e3c:	a90153f3 	stp	x19, x20, [sp, #16]
    2e40:	aa0003f4 	mov	x20, x0
    2e44:	f94e2440 	ldr	x0, [x2, #7240]
    2e48:	b4000440 	cbz	x0, 2ed0 <fwp_rc_prepare_chunk+0xb0>
    2e4c:	d2800013 	mov	x19, #0x0                   	// #0
    2e50:	35000203 	cbnz	w3, 2e90 <fwp_rc_prepare_chunk+0x70>
    2e54:	b4000361 	cbz	x1, 2ec0 <fwp_rc_prepare_chunk+0xa0>
    2e58:	f9401280 	ldr	x0, [x20, #32]
    2e5c:	97fff9d9 	bl	15c0 <free@plt>
    2e60:	aa1503e0 	mov	x0, x21
    2e64:	d2800021 	mov	x1, #0x1                   	// #1
    2e68:	97fff99e 	bl	14e0 <calloc@plt>
    2e6c:	f9001280 	str	x0, [x20, #32]
    2e70:	b5000460 	cbnz	x0, 2efc <fwp_rc_prepare_chunk+0xdc>
    2e74:	97fffb97 	bl	1cd0 <fwp_heap_oom>
    2e78:	97ffffc3 	bl	2d84 <fwp_rc_forget_slot>
    2e7c:	91000673 	add	x19, x19, #0x1
    2e80:	b9401e83 	ldr	w3, [x20, #28]
    2e84:	eb13007f 	cmp	x3, x19
    2e88:	54000169 	b.ls	2eb4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    2e8c:	d503201f 	nop
    2e90:	f9401283 	ldr	x3, [x20, #32]
    2e94:	8b130060 	add	x0, x3, x19
    2e98:	38736863 	ldrb	w3, [x3, x19]
    2e9c:	7103fc7f 	cmp	w3, #0xff
    2ea0:	54fffec0 	b.eq	2e78 <fwp_rc_prepare_chunk+0x58>  // b.none
    2ea4:	b9401e83 	ldr	w3, [x20, #28]
    2ea8:	91000673 	add	x19, x19, #0x1
    2eac:	eb13007f 	cmp	x3, x19
    2eb0:	54ffff08 	b.hi	2e90 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    2eb4:	eb0302bf 	cmp	x21, x3
    2eb8:	54000121 	b.ne	2edc <fwp_rc_prepare_chunk+0xbc>  // b.any
    2ebc:	b5000335 	cbnz	x21, 2f20 <fwp_rc_prepare_chunk+0x100>
    2ec0:	a94153f3 	ldp	x19, x20, [sp, #16]
    2ec4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ec8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2ecc:	d65f03c0 	ret
    2ed0:	2a0303e3 	mov	w3, w3
    2ed4:	eb0302bf 	cmp	x21, x3
    2ed8:	54ffff20 	b.eq	2ebc <fwp_rc_prepare_chunk+0x9c>  // b.none
    2edc:	911582c2 	add	x2, x22, #0x560
    2ee0:	f9401280 	ldr	x0, [x20, #32]
    2ee4:	f94e2841 	ldr	x1, [x2, #7248]
    2ee8:	cb030021 	sub	x1, x1, x3
    2eec:	f90e2841 	str	x1, [x2, #7248]
    2ef0:	97fff9b4 	bl	15c0 <free@plt>
    2ef4:	b5fffb75 	cbnz	x21, 2e60 <fwp_rc_prepare_chunk+0x40>
    2ef8:	f900129f 	str	xzr, [x20, #32]
    2efc:	911582d6 	add	x22, x22, #0x560
    2f00:	f94e2ac0 	ldr	x0, [x22, #7248]
    2f04:	b9001e95 	str	w21, [x20, #28]
    2f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f0c:	8b150000 	add	x0, x0, x21
    2f10:	f90e2ac0 	str	x0, [x22, #7248]
    2f14:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f1c:	d65f03c0 	ret
    2f20:	f9401280 	ldr	x0, [x20, #32]
    2f24:	aa1503e2 	mov	x2, x21
    2f28:	a94153f3 	ldp	x19, x20, [sp, #16]
    2f2c:	52800001 	mov	w1, #0x0                   	// #0
    2f30:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2f34:	a8c37bfd 	ldp	x29, x30, [sp], #48
    2f38:	17fff966 	b	14d0 <memset@plt>
    2f3c:	d503201f 	nop

0000000000002f40 <fwp_heap_refill>:
    2f40:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    2f44:	910003fd 	mov	x29, sp
    2f48:	a9025bf5 	stp	x21, x22, [sp, #32]
    2f4c:	f0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    2f50:	911582b5 	add	x21, x21, #0x560
    2f54:	aa0003f6 	mov	x22, x0
    2f58:	d2800020 	mov	x0, #0x1                   	// #1
    2f5c:	a90153f3 	stp	x19, x20, [sp, #16]
    2f60:	a90363f7 	stp	x23, x24, [sp, #48]
    2f64:	2a0103f7 	mov	w23, w1
    2f68:	2a0203f8 	mov	w24, w2
    2f6c:	97fffb69 	bl	1d10 <fwp_heap_chunks>
    2f70:	aa0003f3 	mov	x19, x0
    2f74:	f949fea2 	ldr	x2, [x21, #5112]
    2f78:	8b000800 	add	x0, x0, x0, lsl #2
    2f7c:	2a1703e1 	mov	w1, w23
    2f80:	52800025 	mov	w5, #0x1                   	// #1
    2f84:	d37df000 	lsl	x0, x0, #3
    2f88:	910f0021 	add	x1, x1, #0x3c0
    2f8c:	8b000054 	add	x20, x2, x0
    2f90:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    2f94:	52a00024 	mov	w4, #0x10000               	// #65536
    2f98:	38206845 	strb	w5, [x2, x0]
    2f9c:	aa1403e0 	mov	x0, x20
    2fa0:	39000698 	strb	w24, [x20, #1]
    2fa4:	39000a97 	strb	w23, [x20, #2]
    2fa8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    2fac:	b9000681 	str	w1, [x20, #4]
    2fb0:	2a0103e5 	mov	w5, w1
    2fb4:	8b0300a2 	add	x2, x5, x3
    2fb8:	1ac10881 	udiv	w1, w4, w1
    2fbc:	9ac50842 	udiv	x2, x2, x5
    2fc0:	b9000a81 	str	w1, [x20, #8]
    2fc4:	92404021 	and	x1, x1, #0x1ffff
    2fc8:	b9001a82 	str	w2, [x20, #24]
    2fcc:	97ffff95 	bl	2e20 <fwp_rc_prepare_chunk>
    2fd0:	f949daa0 	ldr	x0, [x21, #5040]
    2fd4:	29408a81 	ldp	w1, w2, [x20, #4]
    2fd8:	8b134000 	add	x0, x0, x19, lsl #16
    2fdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    2fe0:	8b214003 	add	x3, x0, w1, uxtw
    2fe4:	9ba20021 	umaddl	x1, w1, w2, x0
    2fe8:	a94363f7 	ldp	x23, x24, [sp, #48]
    2fec:	a90086c3 	stp	x3, x1, [x22, #8]
    2ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    2ff4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    2ff8:	d65f03c0 	ret
    2ffc:	d503201f 	nop

0000000000003000 <fwp_mem_free>:
    3000:	b40003c0 	cbz	x0, 3078 <fwp_mem_free+0x78>
    3004:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3008:	910003fd 	mov	x29, sp
    300c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3010:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    3014:	911582a1 	add	x1, x21, #0x560
    3018:	a90153f3 	stp	x19, x20, [sp, #16]
    301c:	aa0003f3 	mov	x19, x0
    3020:	f949d823 	ldr	x3, [x1, #5040]
    3024:	f949ec22 	ldr	x2, [x1, #5080]
    3028:	cb030000 	sub	x0, x0, x3
    302c:	eb02401f 	cmp	x0, x2, lsl #16
    3030:	540001c2 	b.cs	3068 <fwp_mem_free+0x68>  // b.hs, b.nlast
    3034:	d350fc16 	lsr	x22, x0, #16
    3038:	a90363f7 	stp	x23, x24, [sp, #48]
    303c:	f949fc22 	ldr	x2, [x1, #5112]
    3040:	8b160ad4 	add	x20, x22, x22, lsl #2
    3044:	d37df294 	lsl	x20, x20, #3
    3048:	ab140057 	adds	x23, x2, x20
    304c:	540000c0 	b.eq	3064 <fwp_mem_free+0x64>  // b.none
    3050:	38746842 	ldrb	w2, [x2, x20]
    3054:	7100045f 	cmp	w2, #0x1
    3058:	54000120 	b.eq	307c <fwp_mem_free+0x7c>  // b.none
    305c:	7100085f 	cmp	w2, #0x2
    3060:	540005e0 	b.eq	311c <fwp_mem_free+0x11c>  // b.none
    3064:	a94363f7 	ldp	x23, x24, [sp, #48]
    3068:	a94153f3 	ldp	x19, x20, [sp, #16]
    306c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3070:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3074:	d65f03c0 	ret
    3078:	d65f03c0 	ret
    307c:	f94012f8 	ldr	x24, [x23, #32]
    3080:	b94006e1 	ldr	w1, [x23, #4]
    3084:	f90023f9 	str	x25, [sp, #64]
    3088:	2a0103e2 	mov	w2, w1
    308c:	394006f9 	ldrb	w25, [x23, #1]
    3090:	39400af4 	ldrb	w20, [x23, #2]
    3094:	b4000158 	cbz	x24, 30bc <fwp_mem_free+0xbc>
    3098:	92403e76 	and	x22, x19, #0xffff
    309c:	9ac20ad6 	udiv	x22, x22, x2
    30a0:	38766b01 	ldrb	w1, [x24, x22]
    30a4:	8b160300 	add	x0, x24, x22
    30a8:	7103fc3f 	cmp	w1, #0xff
    30ac:	54000980 	b.eq	31dc <fwp_mem_free+0x1dc>  // b.none
    30b0:	38366b1f 	strb	wzr, [x24, x22]
    30b4:	b94006e1 	ldr	w1, [x23, #4]
    30b8:	2a0103e2 	mov	w2, w1
    30bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    30c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    30c4:	cb390000 	sub	x0, x0, w25, uxtb
    30c8:	8b340074 	add	x20, x3, w20, uxtb
    30cc:	911582b5 	add	x21, x21, #0x560
    30d0:	1e630021 	ucvtf	d1, w1
    30d4:	d37ae400 	lsl	x0, x0, #6
    30d8:	8b140c14 	add	x20, x0, x20, lsl #3
    30dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    30e0:	f8746aa0 	ldr	x0, [x21, x20]
    30e4:	f94023f9 	ldr	x25, [sp, #64]
    30e8:	aa2003e0 	mvn	x0, x0
    30ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    30f0:	f9000260 	str	x0, [x19]
    30f4:	f8346ab3 	str	x19, [x21, x20]
    30f8:	f94a12a0 	ldr	x0, [x21, #5152]
    30fc:	1e612800 	fadd	d0, d0, d1
    3100:	a94153f3 	ldp	x19, x20, [sp, #16]
    3104:	cb020000 	sub	x0, x0, x2
    3108:	f90a12a0 	str	x0, [x21, #5152]
    310c:	fd0a22a0 	str	d0, [x21, #5184]
    3110:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3114:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3118:	d65f03c0 	ret
    311c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    3120:	8b000063 	add	x3, x3, x0
    3124:	eb03027f 	cmp	x19, x3
    3128:	54fff9e1 	b.ne	3064 <fwp_mem_free+0x64>  // b.any
    312c:	fd400ae1 	ldr	d1, [x23, #16]
    3130:	fd4a2020 	ldr	d0, [x1, #5184]
    3134:	f9400ae0 	ldr	x0, [x23, #16]
    3138:	7e61d821 	ucvtf	d1, d1
    313c:	f94a1022 	ldr	x2, [x1, #5152]
    3140:	f94012f3 	ldr	x19, [x23, #32]
    3144:	1e612800 	fadd	d0, d0, d1
    3148:	cb000042 	sub	x2, x2, x0
    314c:	f90a1022 	str	x2, [x1, #5152]
    3150:	fd0a2020 	str	d0, [x1, #5184]
    3154:	b40000b3 	cbz	x19, 3168 <fwp_mem_free+0x168>
    3158:	39400260 	ldrb	w0, [x19]
    315c:	7103fc1f 	cmp	w0, #0xff
    3160:	54000380 	b.eq	31d0 <fwp_mem_free+0x1d0>  // b.none
    3164:	3900027f 	strb	wzr, [x19]
    3168:	b9400ee2 	ldr	w2, [x23, #12]
    316c:	b4000142 	cbz	x2, 3194 <fwp_mem_free+0x194>
    3170:	911582a1 	add	x1, x21, #0x560
    3174:	8b160040 	add	x0, x2, x22
    3178:	8b000800 	add	x0, x0, x0, lsl #2
    317c:	f949fc21 	ldr	x1, [x1, #5112]
    3180:	8b140034 	add	x20, x1, x20
    3184:	8b000c20 	add	x0, x1, x0, lsl #3
    3188:	3802869f 	strb	wzr, [x20], #40
    318c:	eb00029f 	cmp	x20, x0
    3190:	54ffffc1 	b.ne	3188 <fwp_mem_free+0x188>  // b.any
    3194:	911582a0 	add	x0, x21, #0x560
    3198:	f94a1801 	ldr	x1, [x0, #5168]
    319c:	f949f803 	ldr	x3, [x0, #5104]
    31a0:	8b020021 	add	x1, x1, x2
    31a4:	f90a1801 	str	x1, [x0, #5168]
    31a8:	eb16007f 	cmp	x3, x22
    31ac:	54000049 	b.ls	31b4 <fwp_mem_free+0x1b4>  // b.plast
    31b0:	f909f816 	str	x22, [x0, #5104]
    31b4:	911582b5 	add	x21, x21, #0x560
    31b8:	f949f6a0 	ldr	x0, [x21, #5096]
    31bc:	eb16001f 	cmp	x0, x22
    31c0:	54fff529 	b.ls	3064 <fwp_mem_free+0x64>  // b.plast
    31c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    31c8:	f909f6b6 	str	x22, [x21, #5096]
    31cc:	17ffffa7 	b	3068 <fwp_mem_free+0x68>
    31d0:	aa1303e0 	mov	x0, x19
    31d4:	97fffeec 	bl	2d84 <fwp_rc_forget_slot>
    31d8:	17ffffe3 	b	3164 <fwp_mem_free+0x164>
    31dc:	97fffeea 	bl	2d84 <fwp_rc_forget_slot>
    31e0:	17ffffb4 	b	30b0 <fwp_mem_free+0xb0>

00000000000031e4 <fwp_heap_alloc_big>:
    31e4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    31e8:	910003fd 	mov	x29, sp
    31ec:	a90153f3 	stp	x19, x20, [sp, #16]
    31f0:	a9025bf5 	stp	x21, x22, [sp, #32]
    31f4:	a90363f7 	stp	x23, x24, [sp, #48]
    31f8:	aa0003f7 	mov	x23, x0
    31fc:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    3200:	a9046bf9 	stp	x25, x26, [sp, #64]
    3204:	eb0002ff 	cmp	x23, x0
    3208:	54000888 	b.hi	3318 <fwp_heap_alloc_big+0x134>  // b.pmore
    320c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3210:	8b0002f4 	add	x20, x23, x0
    3214:	d000017a 	adrp	x26, 31000 <fwp_root_context+0xc80>
    3218:	91158359 	add	x25, x26, #0x560
    321c:	d350fe94 	lsr	x20, x20, #16
    3220:	2a0103f5 	mov	w21, w1
    3224:	aa1403e0 	mov	x0, x20
    3228:	97fffaba 	bl	1d10 <fwp_heap_chunks>
    322c:	f949ff22 	ldr	x2, [x25, #5112]
    3230:	8b000813 	add	x19, x0, x0, lsl #2
    3234:	aa0003f8 	mov	x24, x0
    3238:	52800043 	mov	w3, #0x2                   	// #2
    323c:	d37df273 	lsl	x19, x19, #3
    3240:	d2800021 	mov	x1, #0x1                   	// #1
    3244:	8b130040 	add	x0, x2, x19
    3248:	38336843 	strb	w3, [x2, x19]
    324c:	39000415 	strb	w21, [x0, #1]
    3250:	b9000c14 	str	w20, [x0, #12]
    3254:	f9000817 	str	x23, [x0, #16]
    3258:	97fffef2 	bl	2e20 <fwp_rc_prepare_chunk>
    325c:	f100069f 	cmp	x20, #0x1
    3260:	54000269 	b.ls	32ac <fwp_heap_alloc_big+0xc8>  // b.plast
    3264:	8b180294 	add	x20, x20, x24
    3268:	9100a273 	add	x19, x19, #0x28
    326c:	a90573fb 	stp	x27, x28, [sp, #80]
    3270:	5280007b 	mov	w27, #0x3                   	// #3
    3274:	8b140a94 	add	x20, x20, x20, lsl #2
    3278:	2a1803fc 	mov	w28, w24
    327c:	9adb2296 	lsl	x22, x20, x27
    3280:	f949ff35 	ldr	x21, [x25, #5112]
    3284:	d2800001 	mov	x1, #0x0                   	// #0
    3288:	8b1302b4 	add	x20, x21, x19
    328c:	aa1403e0 	mov	x0, x20
    3290:	97fffee4 	bl	2e20 <fwp_rc_prepare_chunk>
    3294:	38336abb 	strb	w27, [x21, x19]
    3298:	9100a273 	add	x19, x19, #0x28
    329c:	b9000e9c 	str	w28, [x20, #12]
    32a0:	eb1302df 	cmp	x22, x19
    32a4:	54fffee1 	b.ne	3280 <fwp_heap_alloc_big+0x9c>  // b.any
    32a8:	a94573fb 	ldp	x27, x28, [sp, #80]
    32ac:	91158353 	add	x19, x26, #0x560
    32b0:	aa1703e2 	mov	x2, x23
    32b4:	52800001 	mov	w1, #0x0                   	// #0
    32b8:	f949da60 	ldr	x0, [x19, #5040]
    32bc:	8b184018 	add	x24, x0, x24, lsl #16
    32c0:	aa1803e0 	mov	x0, x24
    32c4:	97fff883 	bl	14d0 <memset@plt>
    32c8:	f94a1260 	ldr	x0, [x19, #5152]
    32cc:	ab170000 	adds	x0, x0, x23
    32d0:	54000242 	b.cs	3318 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    32d4:	f94a1661 	ldr	x1, [x19, #5160]
    32d8:	f90a1260 	str	x0, [x19, #5152]
    32dc:	eb01001f 	cmp	x0, x1
    32e0:	54000049 	b.ls	32e8 <fwp_heap_alloc_big+0x104>  // b.plast
    32e4:	f90a1660 	str	x0, [x19, #5160]
    32e8:	9115835a 	add	x26, x26, #0x560
    32ec:	9e6202e0 	scvtf	d0, x23
    32f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    32f4:	aa1803e0 	mov	x0, x24
    32f8:	fd4a1f41 	ldr	d1, [x26, #5176]
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	1e602820 	fadd	d0, d1, d0
    3304:	a94363f7 	ldp	x23, x24, [sp, #48]
    3308:	fd0a1f40 	str	d0, [x26, #5176]
    330c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3310:	a8c67bfd 	ldp	x29, x30, [sp], #96
    3314:	d65f03c0 	ret
    3318:	a90573fb 	stp	x27, x28, [sp, #80]
    331c:	97fffa6d 	bl	1cd0 <fwp_heap_oom>

0000000000003320 <fwp_heap_alloc_slow>:
    3320:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3324:	910003fd 	mov	x29, sp
    3328:	a90153f3 	stp	x19, x20, [sp, #16]
    332c:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc80>
    3330:	91158262 	add	x2, x19, #0x560
    3334:	a9025bf5 	stp	x21, x22, [sp, #32]
    3338:	aa0003f5 	mov	x21, x0
    333c:	2a0103f4 	mov	w20, w1
    3340:	b953a440 	ldr	w0, [x2, #5028]
    3344:	34000600 	cbz	w0, 3404 <fwp_heap_alloc_slow+0xe4>
    3348:	f14012bf 	cmp	x21, #0x4, lsl #12
    334c:	54000628 	b.hi	3410 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    3350:	91003ea0 	add	x0, x21, #0xf
    3354:	91158262 	add	x2, x19, #0x560
    3358:	f9001bf7 	str	x23, [sp, #48]
    335c:	937c7e84 	sbfiz	x4, x20, #4, #32
    3360:	8b401040 	add	x0, x2, x0, lsr #4
    3364:	cb34c084 	sub	x4, x4, w20, sxtw
    3368:	d37ae484 	lsl	x4, x4, #6
    336c:	397e8003 	ldrb	w3, [x0, #4000]
    3370:	910f0060 	add	x0, x3, #0x3c0
    3374:	aa0303e1 	mov	x1, x3
    3378:	8b030463 	add	x3, x3, x3, lsl #1
    337c:	8b030c83 	add	x3, x4, x3, lsl #3
    3380:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    3384:	2a1703f6 	mov	w22, w23
    3388:	f8636844 	ldr	x4, [x2, x3]
    338c:	b40004e4 	cbz	x4, 3428 <fwp_heap_alloc_slow+0x108>
    3390:	f9400080 	ldr	x0, [x4]
    3394:	aa2003e0 	mvn	x0, x0
    3398:	f8236840 	str	x0, [x2, x3]
    339c:	7100069f 	cmp	w20, #0x1
    33a0:	aa0403e0 	mov	x0, x4
    33a4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    33a8:	52800001 	mov	w1, #0x0                   	// #0
    33ac:	97fff849 	bl	14d0 <memset@plt>
    33b0:	aa0003e4 	mov	x4, x0
    33b4:	91158260 	add	x0, x19, #0x560
    33b8:	f94a1001 	ldr	x1, [x0, #5152]
    33bc:	ab160021 	adds	x1, x1, x22
    33c0:	540005c2 	b.cs	3478 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    33c4:	f94a1402 	ldr	x2, [x0, #5160]
    33c8:	f90a1001 	str	x1, [x0, #5152]
    33cc:	eb02003f 	cmp	x1, x2
    33d0:	54000049 	b.ls	33d8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    33d4:	f90a1401 	str	x1, [x0, #5160]
    33d8:	91158273 	add	x19, x19, #0x560
    33dc:	1e6302e1 	ucvtf	d1, w23
    33e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    33e4:	aa0403e0 	mov	x0, x4
    33e8:	fd4a1e60 	ldr	d0, [x19, #5176]
    33ec:	f9401bf7 	ldr	x23, [sp, #48]
    33f0:	1e612800 	fadd	d0, d0, d1
    33f4:	fd0a1e60 	str	d0, [x19, #5176]
    33f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3400:	d65f03c0 	ret
    3404:	97fffd33 	bl	28d0 <fwp_heap_init>
    3408:	f14012bf 	cmp	x21, #0x4, lsl #12
    340c:	54fffa29 	b.ls	3350 <fwp_heap_alloc_slow+0x30>  // b.plast
    3410:	2a1403e1 	mov	w1, w20
    3414:	aa1503e0 	mov	x0, x21
    3418:	a94153f3 	ldp	x19, x20, [sp, #16]
    341c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3420:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3424:	17ffff70 	b	31e4 <fwp_heap_alloc_big>
    3428:	8b030042 	add	x2, x2, x3
    342c:	f9400444 	ldr	x4, [x2, #8]
    3430:	b4000104 	cbz	x4, 3450 <fwp_heap_alloc_slow+0x130>
    3434:	f9400840 	ldr	x0, [x2, #16]
    3438:	cb040000 	sub	x0, x0, x4
    343c:	eb16001f 	cmp	x0, x22
    3440:	54000083 	b.cc	3450 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    3444:	8b160080 	add	x0, x4, x22
    3448:	f9000440 	str	x0, [x2, #8]
    344c:	17ffffd4 	b	339c <fwp_heap_alloc_slow+0x7c>
    3450:	52800302 	mov	w2, #0x18                  	// #24
    3454:	52807804 	mov	w4, #0x3c0                 	// #960
    3458:	91158260 	add	x0, x19, #0x560
    345c:	9ba27c23 	umull	x3, w1, w2
    3460:	2a1403e2 	mov	w2, w20
    3464:	9b240e84 	smaddl	x4, w20, w4, x3
    3468:	8b040000 	add	x0, x0, x4
    346c:	97fffeb5 	bl	2f40 <fwp_heap_refill>
    3470:	aa0003e4 	mov	x4, x0
    3474:	17ffffca 	b	339c <fwp_heap_alloc_slow+0x7c>
    3478:	97fffa16 	bl	1cd0 <fwp_heap_oom>
    347c:	d503201f 	nop

0000000000003480 <fwp_rc_free_arr>:
    3480:	d0000163 	adrp	x3, 31000 <fwp_root_context+0xc80>
    3484:	91158063 	add	x3, x3, #0x560
    3488:	f949d861 	ldr	x1, [x3, #5040]
    348c:	f949ec62 	ldr	x2, [x3, #5080]
    3490:	cb010001 	sub	x1, x0, x1
    3494:	eb02403f 	cmp	x1, x2, lsl #16
    3498:	54000342 	b.cs	3500 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    349c:	d350fc22 	lsr	x2, x1, #16
    34a0:	f949fc65 	ldr	x5, [x3, #5112]
    34a4:	8b020842 	add	x2, x2, x2, lsl #2
    34a8:	d37df042 	lsl	x2, x2, #3
    34ac:	8b0200a4 	add	x4, x5, x2
    34b0:	f9401083 	ldr	x3, [x4, #32]
    34b4:	b4000263 	cbz	x3, 3500 <fwp_rc_free_arr+0x80>
    34b8:	386268a2 	ldrb	w2, [x5, x2]
    34bc:	7100085f 	cmp	w2, #0x2
    34c0:	540001c0 	b.eq	34f8 <fwp_rc_free_arr+0x78>  // b.none
    34c4:	7100045f 	cmp	w2, #0x1
    34c8:	540001c1 	b.ne	3500 <fwp_rc_free_arr+0x80>  // b.any
    34cc:	29430885 	ldp	w5, w2, [x4, #24]
    34d0:	92403c21 	and	x1, x1, #0xffff
    34d4:	9b057c21 	mul	x1, x1, x5
    34d8:	d360fc21 	lsr	x1, x1, #32
    34dc:	eb02003f 	cmp	x1, x2
    34e0:	54000102 	b.cs	3500 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    34e4:	8b010063 	add	x3, x3, x1
    34e8:	39400061 	ldrb	w1, [x3]
    34ec:	7100043f 	cmp	w1, #0x1
    34f0:	54000081 	b.ne	3500 <fwp_rc_free_arr+0x80>  // b.any
    34f4:	17fffec3 	b	3000 <fwp_mem_free>
    34f8:	72003c3f 	tst	w1, #0xffff
    34fc:	54ffff60 	b.eq	34e8 <fwp_rc_free_arr+0x68>  // b.none
    3500:	d65f03c0 	ret

0000000000003504 <fwp_heap_alloc>:
    3504:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3508:	910003fd 	mov	x29, sp
    350c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3510:	b00000f6 	adrp	x22, 20000 <__data_start>
    3514:	910202c2 	add	x2, x22, #0x80
    3518:	a90363f7 	stp	x23, x24, [sp, #48]
    351c:	b9404058 	ldr	w24, [x2, #64]
    3520:	a90153f3 	stp	x19, x20, [sp, #16]
    3524:	7100031f 	cmp	w24, #0x0
    3528:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    352c:	54000861 	b.ne	3638 <fwp_heap_alloc+0x134>  // b.any
    3530:	d0000177 	adrp	x23, 31000 <fwp_root_context+0xc80>
    3534:	911582f3 	add	x19, x23, #0x560
    3538:	f140101f 	cmp	x0, #0x4, lsl #12
    353c:	b953a662 	ldr	w2, [x19, #5028]
    3540:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    3544:	54000740 	b.eq	362c <fwp_heap_alloc+0x128>  // b.none
    3548:	91003c03 	add	x3, x0, #0xf
    354c:	937c7c22 	sbfiz	x2, x1, #4, #32
    3550:	cb21c042 	sub	x2, x2, w1, sxtw
    3554:	8b431263 	add	x3, x19, x3, lsr #4
    3558:	d37ae442 	lsl	x2, x2, #6
    355c:	397e8063 	ldrb	w3, [x3, #4000]
    3560:	910f0064 	add	x4, x3, #0x3c0
    3564:	8b030463 	add	x3, x3, x3, lsl #1
    3568:	8b030c43 	add	x3, x2, x3, lsl #3
    356c:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    3570:	2a1503f4 	mov	w20, w21
    3574:	f8636a64 	ldr	x4, [x19, x3]
    3578:	b40004c4 	cbz	x4, 3610 <fwp_heap_alloc+0x10c>
    357c:	f9400085 	ldr	x5, [x4]
    3580:	7100043f 	cmp	w1, #0x1
    3584:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3588:	aa0403e0 	mov	x0, x4
    358c:	aa2503e5 	mvn	x5, x5
    3590:	52800001 	mov	w1, #0x0                   	// #0
    3594:	f8236a65 	str	x5, [x19, x3]
    3598:	97fff7ce 	bl	14d0 <memset@plt>
    359c:	aa0003e4 	mov	x4, x0
    35a0:	f94a1260 	ldr	x0, [x19, #5152]
    35a4:	ab140000 	adds	x0, x0, x20
    35a8:	540006e2 	b.cs	3684 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    35ac:	f94a1661 	ldr	x1, [x19, #5160]
    35b0:	f90a1260 	str	x0, [x19, #5152]
    35b4:	eb01001f 	cmp	x0, x1
    35b8:	54000049 	b.ls	35c0 <fwp_heap_alloc+0xbc>  // b.plast
    35bc:	f90a1660 	str	x0, [x19, #5160]
    35c0:	911582e0 	add	x0, x23, #0x560
    35c4:	1e6302a1 	ucvtf	d1, w21
    35c8:	fd4a1c00 	ldr	d0, [x0, #5176]
    35cc:	1e612800 	fadd	d0, d0, d1
    35d0:	fd0a1c00 	str	d0, [x0, #5176]
    35d4:	34000138 	cbz	w24, 35f8 <fwp_heap_alloc+0xf4>
    35d8:	911582e1 	add	x1, x23, #0x560
    35dc:	910202c0 	add	x0, x22, #0x80
    35e0:	fd4a1020 	ldr	d0, [x1, #5152]
    35e4:	6d458402 	ldp	d2, d1, [x0, #88]
    35e8:	7e61d800 	ucvtf	d0, d0
    35ec:	1e623800 	fsub	d0, d0, d2
    35f0:	1e612010 	fcmpe	d0, d1
    35f4:	540002cc 	b.gt	364c <fwp_heap_alloc+0x148>
    35f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35fc:	aa0403e0 	mov	x0, x4
    3600:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3604:	a94363f7 	ldp	x23, x24, [sp, #48]
    3608:	a8c47bfd 	ldp	x29, x30, [sp], #64
    360c:	d65f03c0 	ret
    3610:	8b030263 	add	x3, x19, x3
    3614:	f9400464 	ldr	x4, [x3, #8]
    3618:	b40000a4 	cbz	x4, 362c <fwp_heap_alloc+0x128>
    361c:	f9400862 	ldr	x2, [x3, #16]
    3620:	cb040042 	sub	x2, x2, x4
    3624:	eb02029f 	cmp	x20, x2
    3628:	54000209 	b.ls	3668 <fwp_heap_alloc+0x164>  // b.plast
    362c:	97ffff3d 	bl	3320 <fwp_heap_alloc_slow>
    3630:	aa0003e4 	mov	x4, x0
    3634:	17ffffe8 	b	35d4 <fwp_heap_alloc+0xd0>
    3638:	a9448c44 	ldp	x4, x3, [x2, #72]
    363c:	91000484 	add	x4, x4, #0x1
    3640:	8b000063 	add	x3, x3, x0
    3644:	a9048c44 	stp	x4, x3, [x2, #72]
    3648:	17ffffba 	b	3530 <fwp_heap_alloc+0x2c>
    364c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3650:	fd003000 	str	d0, [x0, #96]
    3654:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3658:	aa0403e0 	mov	x0, x4
    365c:	a94363f7 	ldp	x23, x24, [sp, #48]
    3660:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3664:	d65f03c0 	ret
    3668:	7100043f 	cmp	w1, #0x1
    366c:	8b140085 	add	x5, x4, x20
    3670:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    3674:	52800001 	mov	w1, #0x0                   	// #0
    3678:	aa0403e0 	mov	x0, x4
    367c:	f9000465 	str	x5, [x3, #8]
    3680:	17ffffc6 	b	3598 <fwp_heap_alloc+0x94>
    3684:	97fff993 	bl	1cd0 <fwp_heap_oom>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <fwp_data.part.0.constprop.0>:
    3690:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3694:	910003fd 	mov	x29, sp
    3698:	a9025bf5 	stp	x21, x22, [sp, #32]
    369c:	b00000f6 	adrp	x22, 20000 <__data_start>
    36a0:	910202c1 	add	x1, x22, #0x80
    36a4:	a90363f7 	stp	x23, x24, [sp, #48]
    36a8:	b9404038 	ldr	w24, [x1, #64]
    36ac:	a90153f3 	stp	x19, x20, [sp, #16]
    36b0:	aa0003f4 	mov	x20, x0
    36b4:	340000b8 	cbz	w24, 36c8 <fwp_data.part.0.constprop.0+0x38>
    36b8:	a9448022 	ldp	x2, x0, [x1, #72]
    36bc:	91000442 	add	x2, x2, #0x1
    36c0:	91006000 	add	x0, x0, #0x18
    36c4:	a9048022 	stp	x2, x0, [x1, #72]
    36c8:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    36cc:	911582a2 	add	x2, x21, #0x560
    36d0:	b953a440 	ldr	w0, [x2, #5028]
    36d4:	34000840 	cbz	w0, 37dc <fwp_data.part.0.constprop.0+0x14c>
    36d8:	f90023f9 	str	x25, [sp, #64]
    36dc:	397e8841 	ldrb	w1, [x2, #4002]
    36e0:	910f0020 	add	x0, x1, #0x3c0
    36e4:	8b010421 	add	x1, x1, x1, lsl #1
    36e8:	d37df021 	lsl	x1, x1, #3
    36ec:	b8607859 	ldr	w25, [x2, x0, lsl #2]
    36f0:	2a1903f7 	mov	w23, w25
    36f4:	f8616853 	ldr	x19, [x2, x1]
    36f8:	b4000633 	cbz	x19, 37bc <fwp_data.part.0.constprop.0+0x12c>
    36fc:	f9400260 	ldr	x0, [x19]
    3700:	aa2003e0 	mvn	x0, x0
    3704:	f8216840 	str	x0, [x2, x1]
    3708:	f10062ff 	cmp	x23, #0x18
    370c:	540000e9 	b.ls	3728 <fwp_data.part.0.constprop.0+0x98>  // b.plast
    3710:	d10066e2 	sub	x2, x23, #0x19
    3714:	91006260 	add	x0, x19, #0x18
    3718:	927df042 	and	x2, x2, #0xfffffffffffffff8
    371c:	52800001 	mov	w1, #0x0                   	// #0
    3720:	91002042 	add	x2, x2, #0x8
    3724:	97fff76b 	bl	14d0 <memset@plt>
    3728:	911582a1 	add	x1, x21, #0x560
    372c:	f94a1020 	ldr	x0, [x1, #5152]
    3730:	ab170000 	adds	x0, x0, x23
    3734:	54000682 	b.cs	3804 <fwp_data.part.0.constprop.0+0x174>  // b.hs, b.nlast
    3738:	f94a1422 	ldr	x2, [x1, #5160]
    373c:	f90a1020 	str	x0, [x1, #5152]
    3740:	eb02001f 	cmp	x0, x2
    3744:	54000049 	b.ls	374c <fwp_data.part.0.constprop.0+0xbc>  // b.plast
    3748:	f90a1420 	str	x0, [x1, #5160]
    374c:	911582a0 	add	x0, x21, #0x560
    3750:	1e630321 	ucvtf	d1, w25
    3754:	f94023f9 	ldr	x25, [sp, #64]
    3758:	fd4a1c00 	ldr	d0, [x0, #5176]
    375c:	1e612800 	fadd	d0, d0, d1
    3760:	fd0a1c00 	str	d0, [x0, #5176]
    3764:	34000138 	cbz	w24, 3788 <fwp_data.part.0.constprop.0+0xf8>
    3768:	911582b5 	add	x21, x21, #0x560
    376c:	910202d6 	add	x22, x22, #0x80
    3770:	fd4a12a0 	ldr	d0, [x21, #5152]
    3774:	6d4586c2 	ldp	d2, d1, [x22, #88]
    3778:	7e61d800 	ucvtf	d0, d0
    377c:	1e623800 	fsub	d0, d0, d2
    3780:	1e612010 	fcmpe	d0, d1
    3784:	5400036c 	b.gt	37f0 <fwp_data.part.0.constprop.0+0x160>
    3788:	90000020 	adrp	x0, 7000 <_IO_stdin_used+0x4b0>
    378c:	fd411800 	ldr	d0, [x0, #560]
    3790:	aa1303e0 	mov	x0, x19
    3794:	fd000260 	str	d0, [x19]
    3798:	f9400281 	ldr	x1, [x20]
    379c:	f9000661 	str	x1, [x19, #8]
    37a0:	f9400681 	ldr	x1, [x20, #8]
    37a4:	f9000a61 	str	x1, [x19, #16]
    37a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    37ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    37b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    37b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    37b8:	d65f03c0 	ret
    37bc:	8b010042 	add	x2, x2, x1
    37c0:	f9400453 	ldr	x19, [x2, #8]
    37c4:	b40000b3 	cbz	x19, 37d8 <fwp_data.part.0.constprop.0+0x148>
    37c8:	f9400840 	ldr	x0, [x2, #16]
    37cc:	cb130000 	sub	x0, x0, x19
    37d0:	eb0002ff 	cmp	x23, x0
    37d4:	54000129 	b.ls	37f8 <fwp_data.part.0.constprop.0+0x168>  // b.plast
    37d8:	f94023f9 	ldr	x25, [sp, #64]
    37dc:	52800001 	mov	w1, #0x0                   	// #0
    37e0:	d2800300 	mov	x0, #0x18                  	// #24
    37e4:	97ffff48 	bl	3504 <fwp_heap_alloc>
    37e8:	aa0003f3 	mov	x19, x0
    37ec:	17ffffde 	b	3764 <fwp_data.part.0.constprop.0+0xd4>
    37f0:	fd0032c0 	str	d0, [x22, #96]
    37f4:	17ffffe5 	b	3788 <fwp_data.part.0.constprop.0+0xf8>
    37f8:	8b170260 	add	x0, x19, x23
    37fc:	f9000440 	str	x0, [x2, #8]
    3800:	17ffffc2 	b	3708 <fwp_data.part.0.constprop.0+0x78>
    3804:	97fff933 	bl	1cd0 <fwp_heap_oom>
    3808:	d503201f 	nop
    380c:	d503201f 	nop

0000000000003810 <fwp_array_new_packed.constprop.0>:
    3810:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3814:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    3818:	910003fd 	mov	x29, sp
    381c:	f9000bf3 	str	x19, [sp, #16]
    3820:	eb01001f 	cmp	x0, x1
    3824:	54000148 	b.hi	384c <fwp_array_new_packed.constprop.0+0x3c>  // b.pmore
    3828:	aa0003f3 	mov	x19, x0
    382c:	91000400 	add	x0, x0, #0x1
    3830:	52800021 	mov	w1, #0x1                   	// #1
    3834:	d37df000 	lsl	x0, x0, #3
    3838:	97ffff33 	bl	3504 <fwp_heap_alloc>
    383c:	f9000013 	str	x19, [x0]
    3840:	f9400bf3 	ldr	x19, [sp, #16]
    3844:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3848:	d65f03c0 	ret
    384c:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    3850:	9138c000 	add	x0, x0, #0xe30
    3854:	97fffa8b 	bl	2280 <fwp_trap>
    3858:	d503201f 	nop
    385c:	d503201f 	nop

0000000000003860 <fwp_drop1>:
    3860:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3864:	910003fd 	mov	x29, sp
    3868:	a90153f3 	stp	x19, x20, [sp, #16]
    386c:	f90013f5 	str	x21, [sp, #32]
    3870:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    3874:	911582b4 	add	x20, x21, #0x560
    3878:	f949da81 	ldr	x1, [x20, #5040]
    387c:	f949ee82 	ldr	x2, [x20, #5080]
    3880:	cb010001 	sub	x1, x0, x1
    3884:	eb02403f 	cmp	x1, x2, lsl #16
    3888:	54000382 	b.cs	38f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    388c:	d350fc22 	lsr	x2, x1, #16
    3890:	f949fe84 	ldr	x4, [x20, #5112]
    3894:	8b020842 	add	x2, x2, x2, lsl #2
    3898:	d37df042 	lsl	x2, x2, #3
    389c:	8b020083 	add	x3, x4, x2
    38a0:	f9401073 	ldr	x19, [x3, #32]
    38a4:	b40002b3 	cbz	x19, 38f8 <fwp_drop1+0x98>
    38a8:	38626882 	ldrb	w2, [x4, x2]
    38ac:	7100085f 	cmp	w2, #0x2
    38b0:	540002c0 	b.eq	3908 <fwp_drop1+0xa8>  // b.none
    38b4:	7100045f 	cmp	w2, #0x1
    38b8:	54000201 	b.ne	38f8 <fwp_drop1+0x98>  // b.any
    38bc:	29430864 	ldp	w4, w2, [x3, #24]
    38c0:	92403c21 	and	x1, x1, #0xffff
    38c4:	9b047c21 	mul	x1, x1, x4
    38c8:	d360fc21 	lsr	x1, x1, #32
    38cc:	eb02003f 	cmp	x1, x2
    38d0:	54000142 	b.cs	38f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    38d4:	8b010273 	add	x19, x19, x1
    38d8:	39400261 	ldrb	w1, [x19]
    38dc:	340000e1 	cbz	w1, 38f8 <fwp_drop1+0x98>
    38e0:	7100043f 	cmp	w1, #0x1
    38e4:	540001e0 	b.eq	3920 <fwp_drop1+0xc0>  // b.none
    38e8:	7103fc3f 	cmp	w1, #0xff
    38ec:	540002e0 	b.eq	3948 <fwp_drop1+0xe8>  // b.none
    38f0:	51000421 	sub	w1, w1, #0x1
    38f4:	39000261 	strb	w1, [x19]
    38f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    38fc:	f94013f5 	ldr	x21, [sp, #32]
    3900:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3904:	d65f03c0 	ret
    3908:	72003c3f 	tst	w1, #0xffff
    390c:	54fffe60 	b.eq	38d8 <fwp_drop1+0x78>  // b.none
    3910:	a94153f3 	ldp	x19, x20, [sp, #16]
    3914:	f94013f5 	ldr	x21, [sp, #32]
    3918:	a8c37bfd 	ldp	x29, x30, [sp], #48
    391c:	d65f03c0 	ret
    3920:	f9400813 	ldr	x19, [x0, #16]
    3924:	97fffed7 	bl	3480 <fwp_rc_free_arr>
    3928:	911582a0 	add	x0, x21, #0x560
    392c:	f949d801 	ldr	x1, [x0, #5040]
    3930:	f949ec00 	ldr	x0, [x0, #5080]
    3934:	cb010261 	sub	x1, x19, x1
    3938:	eb00403f 	cmp	x1, x0, lsl #16
    393c:	54fffde2 	b.cs	38f8 <fwp_drop1+0x98>  // b.hs, b.nlast
    3940:	aa1303e0 	mov	x0, x19
    3944:	17ffffd2 	b	388c <fwp_drop1+0x2c>
    3948:	ca534660 	eor	x0, x19, x19, lsr #17
    394c:	911582b5 	add	x21, x21, #0x560
    3950:	ca402400 	eor	x0, x0, x0, lsr #9
    3954:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3958:	f94a2400 	ldr	x0, [x0, #5192]
    395c:	b5000080 	cbnz	x0, 396c <fwp_drop1+0x10c>
    3960:	14000010 	b	39a0 <fwp_drop1+0x140>
    3964:	f9400800 	ldr	x0, [x0, #16]
    3968:	b40001c0 	cbz	x0, 39a0 <fwp_drop1+0x140>
    396c:	f9400001 	ldr	x1, [x0]
    3970:	eb13003f 	cmp	x1, x19
    3974:	54ffff81 	b.ne	3964 <fwp_drop1+0x104>  // b.any
    3978:	f9400401 	ldr	x1, [x0, #8]
    397c:	d1000421 	sub	x1, x1, #0x1
    3980:	f9000401 	str	x1, [x0, #8]
    3984:	f103f83f 	cmp	x1, #0xfe
    3988:	54fffb81 	b.ne	38f8 <fwp_drop1+0x98>  // b.any
    398c:	aa1303e0 	mov	x0, x19
    3990:	97fffcfd 	bl	2d84 <fwp_rc_forget_slot>
    3994:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3998:	39000260 	strb	w0, [x19]
    399c:	17ffffd7 	b	38f8 <fwp_drop1+0x98>
    39a0:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    39a4:	91382000 	add	x0, x0, #0xe08
    39a8:	97fffa36 	bl	2280 <fwp_trap>
    39ac:	d503201f 	nop

00000000000039b0 <fwp_drop0>:
    39b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39b4:	910003fd 	mov	x29, sp
    39b8:	a90153f3 	stp	x19, x20, [sp, #16]
    39bc:	f90013f5 	str	x21, [sp, #32]
    39c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc80>
    39c4:	911582b4 	add	x20, x21, #0x560
    39c8:	f949da81 	ldr	x1, [x20, #5040]
    39cc:	f949ee82 	ldr	x2, [x20, #5080]
    39d0:	cb010001 	sub	x1, x0, x1
    39d4:	eb02403f 	cmp	x1, x2, lsl #16
    39d8:	54000382 	b.cs	3a48 <fwp_drop0+0x98>  // b.hs, b.nlast
    39dc:	d350fc22 	lsr	x2, x1, #16
    39e0:	f949fe84 	ldr	x4, [x20, #5112]
    39e4:	8b020842 	add	x2, x2, x2, lsl #2
    39e8:	d37df042 	lsl	x2, x2, #3
    39ec:	8b020083 	add	x3, x4, x2
    39f0:	f9401073 	ldr	x19, [x3, #32]
    39f4:	b40002b3 	cbz	x19, 3a48 <fwp_drop0+0x98>
    39f8:	38626882 	ldrb	w2, [x4, x2]
    39fc:	7100085f 	cmp	w2, #0x2
    3a00:	540002c0 	b.eq	3a58 <fwp_drop0+0xa8>  // b.none
    3a04:	7100045f 	cmp	w2, #0x1
    3a08:	54000201 	b.ne	3a48 <fwp_drop0+0x98>  // b.any
    3a0c:	29430864 	ldp	w4, w2, [x3, #24]
    3a10:	92403c21 	and	x1, x1, #0xffff
    3a14:	9b047c21 	mul	x1, x1, x4
    3a18:	d360fc21 	lsr	x1, x1, #32
    3a1c:	eb02003f 	cmp	x1, x2
    3a20:	54000142 	b.cs	3a48 <fwp_drop0+0x98>  // b.hs, b.nlast
    3a24:	8b010273 	add	x19, x19, x1
    3a28:	39400261 	ldrb	w1, [x19]
    3a2c:	340000e1 	cbz	w1, 3a48 <fwp_drop0+0x98>
    3a30:	7100043f 	cmp	w1, #0x1
    3a34:	540001e0 	b.eq	3a70 <fwp_drop0+0xc0>  // b.none
    3a38:	7103fc3f 	cmp	w1, #0xff
    3a3c:	540002e0 	b.eq	3a98 <fwp_drop0+0xe8>  // b.none
    3a40:	51000421 	sub	w1, w1, #0x1
    3a44:	39000261 	strb	w1, [x19]
    3a48:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a4c:	f94013f5 	ldr	x21, [sp, #32]
    3a50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a54:	d65f03c0 	ret
    3a58:	72003c3f 	tst	w1, #0xffff
    3a5c:	54fffe60 	b.eq	3a28 <fwp_drop0+0x78>  // b.none
    3a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a64:	f94013f5 	ldr	x21, [sp, #32]
    3a68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a6c:	d65f03c0 	ret
    3a70:	f9400813 	ldr	x19, [x0, #16]
    3a74:	97fffe83 	bl	3480 <fwp_rc_free_arr>
    3a78:	911582a0 	add	x0, x21, #0x560
    3a7c:	f949d801 	ldr	x1, [x0, #5040]
    3a80:	f949ec00 	ldr	x0, [x0, #5080]
    3a84:	cb010261 	sub	x1, x19, x1
    3a88:	eb00403f 	cmp	x1, x0, lsl #16
    3a8c:	54fffde2 	b.cs	3a48 <fwp_drop0+0x98>  // b.hs, b.nlast
    3a90:	aa1303e0 	mov	x0, x19
    3a94:	17ffffd2 	b	39dc <fwp_drop0+0x2c>
    3a98:	ca534660 	eor	x0, x19, x19, lsr #17
    3a9c:	911582b5 	add	x21, x21, #0x560
    3aa0:	ca402400 	eor	x0, x0, x0, lsr #9
    3aa4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    3aa8:	f94a2400 	ldr	x0, [x0, #5192]
    3aac:	b5000080 	cbnz	x0, 3abc <fwp_drop0+0x10c>
    3ab0:	14000010 	b	3af0 <fwp_drop0+0x140>
    3ab4:	f9400800 	ldr	x0, [x0, #16]
    3ab8:	b40001c0 	cbz	x0, 3af0 <fwp_drop0+0x140>
    3abc:	f9400001 	ldr	x1, [x0]
    3ac0:	eb13003f 	cmp	x1, x19
    3ac4:	54ffff81 	b.ne	3ab4 <fwp_drop0+0x104>  // b.any
    3ac8:	f9400401 	ldr	x1, [x0, #8]
    3acc:	d1000421 	sub	x1, x1, #0x1
    3ad0:	f9000401 	str	x1, [x0, #8]
    3ad4:	f103f83f 	cmp	x1, #0xfe
    3ad8:	54fffb81 	b.ne	3a48 <fwp_drop0+0x98>  // b.any
    3adc:	aa1303e0 	mov	x0, x19
    3ae0:	97fffca9 	bl	2d84 <fwp_rc_forget_slot>
    3ae4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3ae8:	39000260 	strb	w0, [x19]
    3aec:	17ffffd7 	b	3a48 <fwp_drop0+0x98>
    3af0:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    3af4:	91382000 	add	x0, x0, #0xe08
    3af8:	97fff9e2 	bl	2280 <fwp_trap>
    3afc:	d503201f 	nop

0000000000003b00 <fwp_task_dispose>:
    3b00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3b04:	910003fd 	mov	x29, sp
    3b08:	f9000bf3 	str	x19, [sp, #16]
    3b0c:	aa0003f3 	mov	x19, x0
    3b10:	39414000 	ldrb	w0, [x0, #80]
    3b14:	36000720 	tbz	w0, #0, 3bf8 <fwp_task_dispose+0xf8>
    3b18:	f9400a60 	ldr	x0, [x19, #16]
    3b1c:	b50006e0 	cbnz	x0, 3bf8 <fwp_task_dispose+0xf8>
    3b20:	a9478660 	ldp	x0, x1, [x19, #120]
    3b24:	39014e7f 	strb	wzr, [x19, #83]
    3b28:	f9003e7f 	str	xzr, [x19, #120]
    3b2c:	f100003f 	cmp	x1, #0x0
    3b30:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    3b34:	54000040 	b.eq	3b3c <fwp_task_dispose+0x3c>  // b.none
    3b38:	d63f0020 	blr	x1
    3b3c:	f9405660 	ldr	x0, [x19, #168]
    3b40:	97fffd30 	bl	3000 <fwp_mem_free>
    3b44:	f900567f 	str	xzr, [x19, #168]
    3b48:	b9405e60 	ldr	w0, [x19, #92]
    3b4c:	7100041f 	cmp	w0, #0x1
    3b50:	54000420 	b.eq	3bd4 <fwp_task_dispose+0xd4>  // b.none
    3b54:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc80>
    3b58:	91158042 	add	x2, x2, #0x560
    3b5c:	f949d840 	ldr	x0, [x2, #5040]
    3b60:	f949ec41 	ldr	x1, [x2, #5080]
    3b64:	cb000260 	sub	x0, x19, x0
    3b68:	eb01401f 	cmp	x0, x1, lsl #16
    3b6c:	540002e2 	b.cs	3bc8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3b70:	d350fc01 	lsr	x1, x0, #16
    3b74:	f949fc44 	ldr	x4, [x2, #5112]
    3b78:	8b010821 	add	x1, x1, x1, lsl #2
    3b7c:	d37df021 	lsl	x1, x1, #3
    3b80:	8b010083 	add	x3, x4, x1
    3b84:	f9401062 	ldr	x2, [x3, #32]
    3b88:	b4000202 	cbz	x2, 3bc8 <fwp_task_dispose+0xc8>
    3b8c:	38616881 	ldrb	w1, [x4, x1]
    3b90:	7100083f 	cmp	w1, #0x2
    3b94:	54000280 	b.eq	3be4 <fwp_task_dispose+0xe4>  // b.none
    3b98:	7100043f 	cmp	w1, #0x1
    3b9c:	54000161 	b.ne	3bc8 <fwp_task_dispose+0xc8>  // b.any
    3ba0:	29430464 	ldp	w4, w1, [x3, #24]
    3ba4:	92403c00 	and	x0, x0, #0xffff
    3ba8:	9b047c00 	mul	x0, x0, x4
    3bac:	d360fc00 	lsr	x0, x0, #32
    3bb0:	eb01001f 	cmp	x0, x1
    3bb4:	540000a2 	b.cs	3bc8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    3bb8:	8b000042 	add	x2, x2, x0
    3bbc:	39400040 	ldrb	w0, [x2]
    3bc0:	7100041f 	cmp	w0, #0x1
    3bc4:	54000080 	b.eq	3bd4 <fwp_task_dispose+0xd4>  // b.none
    3bc8:	f9400bf3 	ldr	x19, [sp, #16]
    3bcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3bd0:	d65f03c0 	ret
    3bd4:	aa1303e0 	mov	x0, x19
    3bd8:	f9400bf3 	ldr	x19, [sp, #16]
    3bdc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3be0:	17fffd08 	b	3000 <fwp_mem_free>
    3be4:	72003c1f 	tst	w0, #0xffff
    3be8:	54fffea0 	b.eq	3bbc <fwp_task_dispose+0xbc>  // b.none
    3bec:	f9400bf3 	ldr	x19, [sp, #16]
    3bf0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3bf4:	d65f03c0 	ret
    3bf8:	97fff656 	bl	1550 <abort@plt>
    3bfc:	d503201f 	nop

0000000000003c00 <fwp_free_zombie>:
    3c00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3c04:	910003fd 	mov	x29, sp
    3c08:	a90153f3 	stp	x19, x20, [sp, #16]
    3c0c:	b00000f4 	adrp	x20, 20000 <__data_start>
    3c10:	91020281 	add	x1, x20, #0x80
    3c14:	f9403433 	ldr	x19, [x1, #104]
    3c18:	b4000333 	cbz	x19, 3c7c <fwp_free_zombie+0x7c>
    3c1c:	f9400420 	ldr	x0, [x1, #8]
    3c20:	eb00027f 	cmp	x19, x0
    3c24:	540002c0 	b.eq	3c7c <fwp_free_zombie+0x7c>  // b.none
    3c28:	b9407022 	ldr	w2, [x1, #112]
    3c2c:	f9400a60 	ldr	x0, [x19, #16]
    3c30:	7100fc5f 	cmp	w2, #0x3f
    3c34:	5400078c 	b.gt	3d24 <fwp_free_zombie+0x124>
    3c38:	91020023 	add	x3, x1, #0x80
    3c3c:	11000444 	add	w4, w2, #0x1
    3c40:	b9007024 	str	w4, [x1, #112]
    3c44:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3c48:	f822d860 	str	x0, [x3, w2, sxtw #3]
    3c4c:	a9530261 	ldp	x1, x0, [x19, #304]
    3c50:	b4000741 	cbz	x1, 3d38 <fwp_free_zombie+0x138>
    3c54:	f9009c20 	str	x0, [x1, #312]
    3c58:	b4000040 	cbz	x0, 3c60 <fwp_free_zombie+0x60>
    3c5c:	f9009801 	str	x1, [x0, #304]
    3c60:	91020294 	add	x20, x20, #0x80
    3c64:	b9405e60 	ldr	w0, [x19, #92]
    3c68:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    3c6c:	f900369f 	str	xzr, [x20, #104]
    3c70:	34000140 	cbz	w0, 3c98 <fwp_free_zombie+0x98>
    3c74:	7100041f 	cmp	w0, #0x1
    3c78:	54000080 	b.eq	3c88 <fwp_free_zombie+0x88>  // b.none
    3c7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c84:	d65f03c0 	ret
    3c88:	aa1303e0 	mov	x0, x19
    3c8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3c94:	17ffff9b 	b	3b00 <fwp_task_dispose>
    3c98:	d0000164 	adrp	x4, 31000 <fwp_root_context+0xc80>
    3c9c:	91158082 	add	x2, x4, #0x560
    3ca0:	f949d841 	ldr	x1, [x2, #5040]
    3ca4:	f949ec40 	ldr	x0, [x2, #5080]
    3ca8:	cb010261 	sub	x1, x19, x1
    3cac:	eb00403f 	cmp	x1, x0, lsl #16
    3cb0:	54fffe62 	b.cs	3c7c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3cb4:	d350fc20 	lsr	x0, x1, #16
    3cb8:	f949fc43 	ldr	x3, [x2, #5112]
    3cbc:	8b000800 	add	x0, x0, x0, lsl #2
    3cc0:	d37df000 	lsl	x0, x0, #3
    3cc4:	8b000062 	add	x2, x3, x0
    3cc8:	f9401054 	ldr	x20, [x2, #32]
    3ccc:	b4fffd94 	cbz	x20, 3c7c <fwp_free_zombie+0x7c>
    3cd0:	38606860 	ldrb	w0, [x3, x0]
    3cd4:	7100081f 	cmp	w0, #0x2
    3cd8:	54000360 	b.eq	3d44 <fwp_free_zombie+0x144>  // b.none
    3cdc:	7100041f 	cmp	w0, #0x1
    3ce0:	54fffce1 	b.ne	3c7c <fwp_free_zombie+0x7c>  // b.any
    3ce4:	29430043 	ldp	w3, w0, [x2, #24]
    3ce8:	92403c21 	and	x1, x1, #0xffff
    3cec:	9b037c21 	mul	x1, x1, x3
    3cf0:	d360fc21 	lsr	x1, x1, #32
    3cf4:	eb00003f 	cmp	x1, x0
    3cf8:	54fffc22 	b.cs	3c7c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    3cfc:	8b010294 	add	x20, x20, x1
    3d00:	39400280 	ldrb	w0, [x20]
    3d04:	34fffbc0 	cbz	w0, 3c7c <fwp_free_zombie+0x7c>
    3d08:	7100041f 	cmp	w0, #0x1
    3d0c:	54fffbe0 	b.eq	3c88 <fwp_free_zombie+0x88>  // b.none
    3d10:	7103fc1f 	cmp	w0, #0xff
    3d14:	540001e0 	b.eq	3d50 <fwp_free_zombie+0x150>  // b.none
    3d18:	51000400 	sub	w0, w0, #0x1
    3d1c:	39000280 	strb	w0, [x20]
    3d20:	17ffffd7 	b	3c7c <fwp_free_zombie+0x7c>
    3d24:	f9400e61 	ldr	x1, [x19, #24]
    3d28:	97fff63e 	bl	1620 <munmap@plt>
    3d2c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    3d30:	a9530261 	ldp	x1, x0, [x19, #304]
    3d34:	b5fff901 	cbnz	x1, 3c54 <fwp_free_zombie+0x54>
    3d38:	91020282 	add	x2, x20, #0x80
    3d3c:	f9014040 	str	x0, [x2, #640]
    3d40:	17ffffc6 	b	3c58 <fwp_free_zombie+0x58>
    3d44:	72003c3f 	tst	w1, #0xffff
    3d48:	54fff9a1 	b.ne	3c7c <fwp_free_zombie+0x7c>  // b.any
    3d4c:	17ffffed 	b	3d00 <fwp_free_zombie+0x100>
    3d50:	ca544680 	eor	x0, x20, x20, lsr #17
    3d54:	91158084 	add	x4, x4, #0x560
    3d58:	ca402400 	eor	x0, x0, x0, lsr #9
    3d5c:	8b200c80 	add	x0, x4, w0, uxtb #3
    3d60:	f94a2400 	ldr	x0, [x0, #5192]
    3d64:	b5000080 	cbnz	x0, 3d74 <fwp_free_zombie+0x174>
    3d68:	14000010 	b	3da8 <fwp_free_zombie+0x1a8>
    3d6c:	f9400800 	ldr	x0, [x0, #16]
    3d70:	b40001c0 	cbz	x0, 3da8 <fwp_free_zombie+0x1a8>
    3d74:	f9400001 	ldr	x1, [x0]
    3d78:	eb14003f 	cmp	x1, x20
    3d7c:	54ffff81 	b.ne	3d6c <fwp_free_zombie+0x16c>  // b.any
    3d80:	f9400401 	ldr	x1, [x0, #8]
    3d84:	d1000421 	sub	x1, x1, #0x1
    3d88:	f9000401 	str	x1, [x0, #8]
    3d8c:	f103f83f 	cmp	x1, #0xfe
    3d90:	54fff761 	b.ne	3c7c <fwp_free_zombie+0x7c>  // b.any
    3d94:	aa1403e0 	mov	x0, x20
    3d98:	97fffbfb 	bl	2d84 <fwp_rc_forget_slot>
    3d9c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    3da0:	39000280 	strb	w0, [x20]
    3da4:	17ffffb6 	b	3c7c <fwp_free_zombie+0x7c>
    3da8:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    3dac:	91382000 	add	x0, x0, #0xe08
    3db0:	97fff934 	bl	2280 <fwp_trap>

0000000000003db4 <fwp_block>:
    3db4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3db8:	910003fd 	mov	x29, sp
    3dbc:	a90153f3 	stp	x19, x20, [sp, #16]
    3dc0:	b00000f3 	adrp	x19, 20000 <__data_start>
    3dc4:	91020274 	add	x20, x19, #0x80
    3dc8:	f9401a82 	ldr	x2, [x20, #48]
    3dcc:	b4000622 	cbz	x2, 3e90 <fwp_block+0xdc>
    3dd0:	91020261 	add	x1, x19, #0x80
    3dd4:	f9408040 	ldr	x0, [x2, #256]
    3dd8:	f9001820 	str	x0, [x1, #48]
    3ddc:	b4000680 	cbz	x0, 3eac <fwp_block+0xf8>
    3de0:	91020263 	add	x3, x19, #0x80
    3de4:	3901505f 	strb	wzr, [x2, #84]
    3de8:	f9400464 	ldr	x4, [x3, #8]
    3dec:	eb02009f 	cmp	x4, x2
    3df0:	54000440 	b.eq	3e78 <fwp_block+0xc4>  // b.none
    3df4:	f9414465 	ldr	x5, [x3, #648]
    3df8:	f9000462 	str	x2, [x3, #8]
    3dfc:	f9400441 	ldr	x1, [x2, #8]
    3e00:	f9004885 	str	x5, [x4, #144]
    3e04:	f9414865 	ldr	x5, [x3, #656]
    3e08:	f9004c85 	str	x5, [x4, #152]
    3e0c:	f9414c65 	ldr	x5, [x3, #664]
    3e10:	f9005085 	str	x5, [x4, #160]
    3e14:	f9415065 	ldr	x5, [x3, #672]
    3e18:	f9005485 	str	x5, [x4, #168]
    3e1c:	f9415465 	ldr	x5, [x3, #680]
    3e20:	f9005885 	str	x5, [x4, #176]
    3e24:	f9415865 	ldr	x5, [x3, #688]
    3e28:	f9005c85 	str	x5, [x4, #184]
    3e2c:	f9415c65 	ldr	x5, [x3, #696]
    3e30:	f9006085 	str	x5, [x4, #192]
    3e34:	f9400480 	ldr	x0, [x4, #8]
    3e38:	f9404844 	ldr	x4, [x2, #144]
    3e3c:	f9014464 	str	x4, [x3, #648]
    3e40:	f9404c44 	ldr	x4, [x2, #152]
    3e44:	f9014864 	str	x4, [x3, #656]
    3e48:	f9405044 	ldr	x4, [x2, #160]
    3e4c:	f9014c64 	str	x4, [x3, #664]
    3e50:	f9405444 	ldr	x4, [x2, #168]
    3e54:	f9015064 	str	x4, [x3, #672]
    3e58:	f9405844 	ldr	x4, [x2, #176]
    3e5c:	f9015464 	str	x4, [x3, #680]
    3e60:	a94b8844 	ldp	x4, x2, [x2, #184]
    3e64:	f9015864 	str	x4, [x3, #688]
    3e68:	f9015c62 	str	x2, [x3, #696]
    3e6c:	97fff5bd 	bl	1560 <swapcontext@plt>
    3e70:	97ffff64 	bl	3c00 <fwp_free_zombie>
    3e74:	d503201f 	nop
    3e78:	91020260 	add	x0, x19, #0x80
    3e7c:	b942c000 	ldr	w0, [x0, #704]
    3e80:	340001a0 	cbz	w0, 3eb4 <fwp_block+0x100>
    3e84:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e88:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3e8c:	d65f03c0 	ret
    3e90:	97fffb30 	bl	2b50 <fwp_poll_events>
    3e94:	f9401a82 	ldr	x2, [x20, #48]
    3e98:	b4ffffc2 	cbz	x2, 3e90 <fwp_block+0xdc>
    3e9c:	91020261 	add	x1, x19, #0x80
    3ea0:	f9408040 	ldr	x0, [x2, #256]
    3ea4:	f9001820 	str	x0, [x1, #48]
    3ea8:	b5fff9c0 	cbnz	x0, 3de0 <fwp_block+0x2c>
    3eac:	f900143f 	str	xzr, [x1, #40]
    3eb0:	17ffffcc 	b	3de0 <fwp_block+0x2c>
    3eb4:	f0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    3eb8:	91390000 	add	x0, x0, #0xe40
    3ebc:	97fff5f5 	bl	1690 <getenv@plt>
    3ec0:	5284e202 	mov	w2, #0x2710                	// #10000
    3ec4:	b4000060 	cbz	x0, 3ed0 <fwp_block+0x11c>
    3ec8:	39400001 	ldrb	w1, [x0]
    3ecc:	350000c1 	cbnz	w1, 3ee4 <fwp_block+0x130>
    3ed0:	91020273 	add	x19, x19, #0x80
    3ed4:	b902c262 	str	w2, [x19, #704]
    3ed8:	a94153f3 	ldp	x19, x20, [sp, #16]
    3edc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3ee0:	d65f03c0 	ret
    3ee4:	52800142 	mov	w2, #0xa                   	// #10
    3ee8:	d2800001 	mov	x1, #0x0                   	// #0
    3eec:	97fff539 	bl	13d0 <strtoll@plt>
    3ef0:	d1000403 	sub	x3, x0, #0x1
    3ef4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    3ef8:	eb02007f 	cmp	x3, x2
    3efc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    3f00:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    3f04:	17fffff3 	b	3ed0 <fwp_block+0x11c>
    3f08:	d503201f 	nop
    3f0c:	d503201f 	nop

0000000000003f10 <fwp_write.constprop.0>:
    3f10:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    3f14:	910003fd 	mov	x29, sp
    3f18:	900000e3 	adrp	x3, 1f000 <__FRAME_END__+0x170f8>
    3f1c:	f947f463 	ldr	x3, [x3, #4072]
    3f20:	a90153f3 	stp	x19, x20, [sp, #16]
    3f24:	d10943ff 	sub	sp, sp, #0x250
    3f28:	aa0003f4 	mov	x20, x0
    3f2c:	b9400040 	ldr	w0, [x2]
    3f30:	aa0103f3 	mov	x19, x1
    3f34:	f9400061 	ldr	x1, [x3]
    3f38:	f90127e1 	str	x1, [sp, #584]
    3f3c:	d2800001 	mov	x1, #0x0                   	// #0
    3f40:	7100641f 	cmp	w0, #0x19
    3f44:	540003e8 	b.hi	3fc0 <fwp_write.constprop.0+0xb0>  // b.pmore
    3f48:	90000021 	adrp	x1, 7000 <_IO_stdin_used+0x4b0>
    3f4c:	91070021 	add	x1, x1, #0x1c0
    3f50:	f9013bf5 	str	x21, [sp, #624]
    3f54:	f9013ff6 	str	x22, [sp, #632]
    3f58:	f90153fb 	str	x27, [sp, #672]
    3f5c:	f90157fc 	str	x28, [sp, #680]
    3f60:	aa0203fc 	mov	x28, x2
    3f64:	78605821 	ldrh	w1, [x1, w0, uxtw #1]
    3f68:	10000062 	adr	x2, 3f74 <fwp_write.constprop.0+0x64>
    3f6c:	8b21a841 	add	x1, x2, w1, sxth #2
    3f70:	d61f0020 	br	x1
    3f74:	910123e0 	add	x0, sp, #0x48
    3f78:	aa1303e5 	mov	x5, x19
    3f7c:	f0000004 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    3f80:	aa0003f3 	mov	x19, x0
    3f84:	913a2084 	add	x4, x4, #0xe88
    3f88:	d2804003 	mov	x3, #0x200                 	// #512
    3f8c:	aa0303e1 	mov	x1, x3
    3f90:	52800042 	mov	w2, #0x2                   	// #2
    3f94:	97fff537 	bl	1470 <__snprintf_chk@plt>
    3f98:	aa1303e0 	mov	x0, x19
    3f9c:	97fff4fd 	bl	1390 <strlen@plt>
    3fa0:	aa1303e1 	mov	x1, x19
    3fa4:	aa0003e2 	mov	x2, x0
    3fa8:	aa1403e0 	mov	x0, x20
    3fac:	97fff859 	bl	2110 <buf_put>
    3fb0:	f9413bf5 	ldr	x21, [sp, #624]
    3fb4:	f9413ff6 	ldr	x22, [sp, #632]
    3fb8:	f94153fb 	ldr	x27, [sp, #672]
    3fbc:	f94157fc 	ldr	x28, [sp, #680]
    3fc0:	900000e0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    3fc4:	f947f400 	ldr	x0, [x0, #4072]
    3fc8:	f94127e2 	ldr	x2, [sp, #584]
    3fcc:	f9400001 	ldr	x1, [x0]
    3fd0:	eb010042 	subs	x2, x2, x1
    3fd4:	d2800001 	mov	x1, #0x0                   	// #0
    3fd8:	540074a1 	b.ne	4e6c <fwp_write.constprop.0+0xf5c>  // b.any
    3fdc:	910943ff 	add	sp, sp, #0x250
    3fe0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fe4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    3fe8:	d65f03c0 	ret
    3fec:	910123e0 	add	x0, sp, #0x48
    3ff0:	aa1303e5 	mov	x5, x19
    3ff4:	f0000004 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    3ff8:	aa0003f3 	mov	x19, x0
    3ffc:	913a0084 	add	x4, x4, #0xe80
    4000:	d2804003 	mov	x3, #0x200                 	// #512
    4004:	17ffffe2 	b	3f8c <fwp_write.constprop.0+0x7c>
    4008:	71004c1f 	cmp	w0, #0x13
    400c:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4010:	d0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    4014:	9139e021 	add	x1, x1, #0xe78
    4018:	9139c000 	add	x0, x0, #0xe70
    401c:	d2800082 	mov	x2, #0x4                   	// #4
    4020:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    4024:	aa1403e0 	mov	x0, x20
    4028:	f90143f7 	str	x23, [sp, #640]
    402c:	d2800016 	mov	x22, #0x0                   	// #0
    4030:	f90147f8 	str	x24, [sp, #648]
    4034:	97fff837 	bl	2110 <buf_put>
    4038:	f9400260 	ldr	x0, [x19]
    403c:	d0000017 	adrp	x23, 6000 <fwp_main_thread+0x114c>
    4040:	d2800015 	mov	x21, #0x0                   	// #0
    4044:	913be2f7 	add	x23, x23, #0xef8
    4048:	b4004e40 	cbz	x0, 4a10 <fwp_write.constprop.0+0xb00>
    404c:	b9400381 	ldr	w1, [x28]
    4050:	aa1403e0 	mov	x0, x20
    4054:	f9401f82 	ldr	x2, [x28, #56]
    4058:	71004c3f 	cmp	w1, #0x13
    405c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    4060:	8b010e61 	add	x1, x19, x1, lsl #3
    4064:	f9400421 	ldr	x1, [x1, #8]
    4068:	97ffffaa 	bl	3f10 <fwp_write.constprop.0>
    406c:	b9400380 	ldr	w0, [x28]
    4070:	7100481f 	cmp	w0, #0x12
    4074:	540050c0 	b.eq	4a8c <fwp_write.constprop.0+0xb7c>  // b.none
    4078:	f9400260 	ldr	x0, [x19]
    407c:	910006b5 	add	x21, x21, #0x1
    4080:	91000ad6 	add	x22, x22, #0x2
    4084:	eb0002bf 	cmp	x21, x0
    4088:	54004c42 	b.cs	4a10 <fwp_write.constprop.0+0xb00>  // b.hs, b.nlast
    408c:	aa1703e1 	mov	x1, x23
    4090:	aa1403e0 	mov	x0, x20
    4094:	d2800042 	mov	x2, #0x2                   	// #2
    4098:	97fff81e 	bl	2110 <buf_put>
    409c:	17ffffec 	b	404c <fwp_write.constprop.0+0x13c>
    40a0:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    40a4:	913ac021 	add	x1, x1, #0xeb0
    40a8:	d28000c2 	mov	x2, #0x6                   	// #6
    40ac:	aa1403e0 	mov	x0, x20
    40b0:	91004273 	add	x19, x19, #0x10
    40b4:	97fff817 	bl	2110 <buf_put>
    40b8:	aa1303e0 	mov	x0, x19
    40bc:	97fff4b5 	bl	1390 <strlen@plt>
    40c0:	aa1303e1 	mov	x1, x19
    40c4:	aa0003e2 	mov	x2, x0
    40c8:	aa1403e0 	mov	x0, x20
    40cc:	97fff811 	bl	2110 <buf_put>
    40d0:	528007c3 	mov	w3, #0x3e                  	// #62
    40d4:	aa1403e0 	mov	x0, x20
    40d8:	91001fe1 	add	x1, sp, #0x7
    40dc:	d2800022 	mov	x2, #0x1                   	// #1
    40e0:	39001fe3 	strb	w3, [sp, #7]
    40e4:	17ffffb2 	b	3fac <fwp_write.constprop.0+0x9c>
    40e8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    40ec:	f947f400 	ldr	x0, [x0, #4072]
    40f0:	f94127e2 	ldr	x2, [sp, #584]
    40f4:	f9400001 	ldr	x1, [x0]
    40f8:	eb010042 	subs	x2, x2, x1
    40fc:	d2800001 	mov	x1, #0x0                   	// #0
    4100:	54006cc1 	b.ne	4e98 <fwp_write.constprop.0+0xf88>  // b.any
    4104:	f9413bf5 	ldr	x21, [sp, #624]
    4108:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    410c:	f9413ff6 	ldr	x22, [sp, #632]
    4110:	aa1403e0 	mov	x0, x20
    4114:	913a4021 	add	x1, x1, #0xe90
    4118:	d2800142 	mov	x2, #0xa                   	// #10
    411c:	f94153fb 	ldr	x27, [sp, #672]
    4120:	f94157fc 	ldr	x28, [sp, #680]
    4124:	910943ff 	add	sp, sp, #0x250
    4128:	a94153f3 	ldp	x19, x20, [sp, #16]
    412c:	a8c77bfd 	ldp	x29, x30, [sp], #112
    4130:	17fff7f8 	b	2110 <buf_put>
    4134:	f9400796 	ldr	x22, [x28, #8]
    4138:	f90143f7 	str	x23, [sp, #640]
    413c:	f90147f8 	str	x24, [sp, #648]
    4140:	b4005816 	cbz	x22, 4c40 <fwp_write.constprop.0+0xd30>
    4144:	aa1603e0 	mov	x0, x22
    4148:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    414c:	913c4021 	add	x1, x1, #0xf10
    4150:	97fff50c 	bl	1580 <strcmp@plt>
    4154:	2a0003f5 	mov	w21, w0
    4158:	34005ce0 	cbz	w0, 4cf4 <fwp_write.constprop.0+0xde4>
    415c:	aa1603e0 	mov	x0, x22
    4160:	97fff48c 	bl	1390 <strlen@plt>
    4164:	aa1603e1 	mov	x1, x22
    4168:	aa0003e2 	mov	x2, x0
    416c:	aa1403e0 	mov	x0, x20
    4170:	97fff7e8 	bl	2110 <buf_put>
    4174:	52800403 	mov	w3, #0x20                  	// #32
    4178:	91001ff5 	add	x21, sp, #0x7
    417c:	aa1503e1 	mov	x1, x21
    4180:	aa1403e0 	mov	x0, x20
    4184:	d2800022 	mov	x2, #0x1                   	// #1
    4188:	39001fe3 	strb	w3, [sp, #7]
    418c:	97fff7e1 	bl	2110 <buf_put>
    4190:	52800f63 	mov	w3, #0x7b                  	// #123
    4194:	aa1403e0 	mov	x0, x20
    4198:	aa1503e1 	mov	x1, x21
    419c:	d2800022 	mov	x2, #0x1                   	// #1
    41a0:	39001fe3 	strb	w3, [sp, #7]
    41a4:	97fff7db 	bl	2110 <buf_put>
    41a8:	b9401380 	ldr	w0, [x28, #16]
    41ac:	52800018 	mov	w24, #0x0                   	// #0
    41b0:	7100001f 	cmp	w0, #0x0
    41b4:	54003d8d 	b.le	4964 <fwp_write.constprop.0+0xa54>
    41b8:	f9014bf9 	str	x25, [sp, #656]
    41bc:	d0000019 	adrp	x25, 6000 <fwp_main_thread+0x114c>
    41c0:	913ce339 	add	x25, x25, #0xf38
    41c4:	f9014ffa 	str	x26, [sp, #664]
    41c8:	d000001a 	adrp	x26, 6000 <fwp_main_thread+0x114c>
    41cc:	913be35a 	add	x26, x26, #0xef8
    41d0:	91002276 	add	x22, x19, #0x8
    41d4:	d2800013 	mov	x19, #0x0                   	// #0
    41d8:	b5004413 	cbnz	x19, 4a58 <fwp_write.constprop.0+0xb48>
    41dc:	d37df277 	lsl	x23, x19, #3
    41e0:	34004238 	cbz	w24, 4a24 <fwp_write.constprop.0+0xb14>
    41e4:	f9401382 	ldr	x2, [x28, #32]
    41e8:	aa1403e0 	mov	x0, x20
    41ec:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    41f0:	91000673 	add	x19, x19, #0x1
    41f4:	f8776842 	ldr	x2, [x2, x23]
    41f8:	97ffff46 	bl	3f10 <fwp_write.constprop.0>
    41fc:	b9401380 	ldr	w0, [x28, #16]
    4200:	6b13001f 	cmp	w0, w19
    4204:	54fffeac 	b.gt	41d8 <fwp_write.constprop.0+0x2c8>
    4208:	f9414bf9 	ldr	x25, [sp, #656]
    420c:	f9414ffa 	ldr	x26, [sp, #664]
    4210:	34003ab8 	cbz	w24, 4964 <fwp_write.constprop.0+0xa54>
    4214:	52800523 	mov	w3, #0x29                  	// #41
    4218:	aa1503e1 	mov	x1, x21
    421c:	aa1403e0 	mov	x0, x20
    4220:	d2800022 	mov	x2, #0x1                   	// #1
    4224:	39001fe3 	strb	w3, [sp, #7]
    4228:	97fff7ba 	bl	2110 <buf_put>
    422c:	f9413bf5 	ldr	x21, [sp, #624]
    4230:	f9413ff6 	ldr	x22, [sp, #632]
    4234:	f94143f7 	ldr	x23, [sp, #640]
    4238:	f94147f8 	ldr	x24, [sp, #648]
    423c:	f94153fb 	ldr	x27, [sp, #672]
    4240:	f94157fc 	ldr	x28, [sp, #680]
    4244:	17ffff5f 	b	3fc0 <fwp_write.constprop.0+0xb0>
    4248:	b9404b95 	ldr	w21, [x28, #72]
    424c:	aa1403e0 	mov	x0, x20
    4250:	93407eb6 	sxtw	x22, w21
    4254:	91000ac1 	add	x1, x22, #0x2
    4258:	97fff77a 	bl	2040 <buf_grow>
    425c:	a9400281 	ldp	x1, x0, [x20]
    4260:	528e8603 	mov	w3, #0x7430                	// #29744
    4264:	78206823 	strh	w3, [x1, x0]
    4268:	8b000022 	add	x2, x1, x0
    426c:	710002bf 	cmp	w21, #0x0
    4270:	54003bcd 	b.le	49e8 <fwp_write.constprop.0+0xad8>
    4274:	110006a3 	add	w3, w21, #0x1
    4278:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    427c:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    4280:	91000449 	add	x9, x2, #0x1
    4284:	8b23c043 	add	x3, x2, w3, sxtw
    4288:	f28aaac6 	movk	x6, #0x5556
    428c:	f2955568 	movk	x8, #0xaaab
    4290:	1400000d 	b	42c4 <fwp_write.constprop.0+0x3b4>
    4294:	d2800021 	mov	x1, #0x1                   	// #1
    4298:	528005a5 	mov	w5, #0x2d                  	// #45
    429c:	f100001f 	cmp	x0, #0x0
    42a0:	9b467e60 	smulh	x0, x19, x6
    42a4:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    42a8:	381ff465 	strb	w5, [x3], #-1
    42ac:	cb040000 	sub	x0, x0, x4
    42b0:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    42b4:	cb020000 	sub	x0, x0, x2
    42b8:	8b010013 	add	x19, x0, x1
    42bc:	eb03013f 	cmp	x9, x3
    42c0:	54003940 	b.eq	49e8 <fwp_write.constprop.0+0xad8>  // b.none
    42c4:	9b467e60 	smulh	x0, x19, x6
    42c8:	937ffe64 	asr	x4, x19, #63
    42cc:	52800605 	mov	w5, #0x30                  	// #48
    42d0:	cb040000 	sub	x0, x0, x4
    42d4:	8b000400 	add	x0, x0, x0, lsl #1
    42d8:	cb000260 	sub	x0, x19, x0
    42dc:	91000c01 	add	x1, x0, #0x3
    42e0:	9bc87c22 	umulh	x2, x1, x8
    42e4:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    42e8:	8b4204e2 	add	x2, x7, x2, lsr #1
    42ec:	eb020021 	subs	x1, x1, x2
    42f0:	54fffd60 	b.eq	429c <fwp_write.constprop.0+0x38c>  // b.none
    42f4:	f100043f 	cmp	x1, #0x1
    42f8:	54fffce1 	b.ne	4294 <fwp_write.constprop.0+0x384>  // b.any
    42fc:	d2800001 	mov	x1, #0x0                   	// #0
    4300:	52800565 	mov	w5, #0x2b                  	// #43
    4304:	17ffffe6 	b	429c <fwp_write.constprop.0+0x38c>
    4308:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    430c:	f947f400 	ldr	x0, [x0, #4072]
    4310:	f94127e2 	ldr	x2, [sp, #584]
    4314:	f9400001 	ldr	x1, [x0]
    4318:	eb010042 	subs	x2, x2, x1
    431c:	d2800001 	mov	x1, #0x0                   	// #0
    4320:	54005bc1 	b.ne	4e98 <fwp_write.constprop.0+0xf88>  // b.any
    4324:	f9413bf5 	ldr	x21, [sp, #624]
    4328:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    432c:	f9413ff6 	ldr	x22, [sp, #632]
    4330:	aa1403e0 	mov	x0, x20
    4334:	913a8021 	add	x1, x1, #0xea0
    4338:	d2800102 	mov	x2, #0x8                   	// #8
    433c:	17ffff78 	b	411c <fwp_write.constprop.0+0x20c>
    4340:	aa1403e0 	mov	x0, x20
    4344:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4348:	d28000c2 	mov	x2, #0x6                   	// #6
    434c:	913c0021 	add	x1, x1, #0xf00
    4350:	97fff770 	bl	2110 <buf_put>
    4354:	d2800015 	mov	x21, #0x0                   	// #0
    4358:	f9400263 	ldr	x3, [x19]
    435c:	f240f87f 	tst	x3, #0x7fffffffffffffff
    4360:	540026a0 	b.eq	4834 <fwp_write.constprop.0+0x924>  // b.none
    4364:	f9401f82 	ldr	x2, [x28, #56]
    4368:	f90143f7 	str	x23, [sp, #640]
    436c:	f90147f8 	str	x24, [sp, #648]
    4370:	d2800857 	mov	x23, #0x42                  	// #66
    4374:	f9014bf9 	str	x25, [sp, #656]
    4378:	d0000016 	adrp	x22, 6000 <fwp_main_thread+0x114c>
    437c:	f9014ffa 	str	x26, [sp, #664]
    4380:	913be2d6 	add	x22, x22, #0xef8
    4384:	d2800038 	mov	x24, #0x1                   	// #1
    4388:	f2a18017 	movk	x23, #0xc00, lsl #16
    438c:	d2809099 	mov	x25, #0x484                 	// #1156
    4390:	b4000482 	cbz	x2, 4420 <fwp_write.constprop.0+0x510>
    4394:	b9400040 	ldr	w0, [x2]
    4398:	7100701f 	cmp	w0, #0x1c
    439c:	540042e0 	b.eq	4bf8 <fwp_write.constprop.0+0xce8>  // b.none
    43a0:	71006c1f 	cmp	w0, #0x1b
    43a4:	540003e8 	b.hi	4420 <fwp_write.constprop.0+0x510>  // b.pmore
    43a8:	9ac02301 	lsl	x1, x24, x0
    43ac:	ea17003f 	tst	x1, x23
    43b0:	54003f21 	b.ne	4b94 <fwp_write.constprop.0+0xc84>  // b.any
    43b4:	ea19003f 	tst	x1, x25
    43b8:	54003da1 	b.ne	4b6c <fwp_write.constprop.0+0xc5c>  // b.any
    43bc:	d2800425 	mov	x5, #0x21                  	// #33
    43c0:	ea05003f 	tst	x1, x5
    43c4:	540002e0 	b.eq	4420 <fwp_write.constprop.0+0x510>  // b.none
    43c8:	b7f84743 	tbnz	x3, #63, 4cb0 <fwp_write.constprop.0+0xda0>
    43cc:	91002261 	add	x1, x19, #0x8
    43d0:	8b150021 	add	x1, x1, x21
    43d4:	39400021 	ldrb	w1, [x1]
    43d8:	7100001f 	cmp	w0, #0x0
    43dc:	93401c23 	sxtb	x3, w1
    43e0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    43e4:	d503201f 	nop
    43e8:	aa1403e0 	mov	x0, x20
    43ec:	97fffec9 	bl	3f10 <fwp_write.constprop.0>
    43f0:	f9400260 	ldr	x0, [x19]
    43f4:	910006b5 	add	x21, x21, #0x1
    43f8:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    43fc:	eb0002bf 	cmp	x21, x0
    4400:	54002122 	b.cs	4824 <fwp_write.constprop.0+0x914>  // b.hs, b.nlast
    4404:	d2800042 	mov	x2, #0x2                   	// #2
    4408:	aa1603e1 	mov	x1, x22
    440c:	aa1403e0 	mov	x0, x20
    4410:	97fff740 	bl	2110 <buf_put>
    4414:	f9401f82 	ldr	x2, [x28, #56]
    4418:	f9400263 	ldr	x3, [x19]
    441c:	b5fffbc2 	cbnz	x2, 4394 <fwp_write.constprop.0+0x484>
    4420:	d37df2a0 	lsl	x0, x21, #3
    4424:	b7f83f43 	tbnz	x3, #63, 4c0c <fwp_write.constprop.0+0xcfc>
    4428:	91002261 	add	x1, x19, #0x8
    442c:	8b000020 	add	x0, x1, x0
    4430:	f9400001 	ldr	x1, [x0]
    4434:	17ffffed 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4438:	a9400e62 	ldp	x2, x3, [x19]
    443c:	b7f83ce3 	tbnz	x3, #63, 4bd8 <fwp_write.constprop.0+0xcc8>
    4440:	910123f5 	add	x21, sp, #0x48
    4444:	aa1503e0 	mov	x0, x21
    4448:	97fff586 	bl	1a60 <fwp_fmt_u128>
    444c:	aa1503e0 	mov	x0, x21
    4450:	97fff3d0 	bl	1390 <strlen@plt>
    4454:	aa1503e1 	mov	x1, x21
    4458:	aa0003e2 	mov	x2, x0
    445c:	17fffed3 	b	3fa8 <fwp_write.constprop.0+0x98>
    4460:	fd015be8 	str	d8, [sp, #688]
    4464:	1e270268 	fmov	s8, w19
    4468:	fd015fe9 	str	d9, [sp, #696]
    446c:	1e282100 	fcmp	s8, s8
    4470:	54004a66 	b.vs	4dbc <fwp_write.constprop.0+0xeac>
    4474:	1e20c101 	fabs	s1, s8
    4478:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    447c:	1e270000 	fmov	s0, w0
    4480:	1e202020 	fcmp	s1, s0
    4484:	540034ad 	b.le	4b18 <fwp_write.constprop.0+0xc08>
    4488:	1e202118 	fcmpe	s8, #0.0
    448c:	d0000002 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    4490:	91318042 	add	x2, x2, #0xc60
    4494:	910123f5 	add	x21, sp, #0x48
    4498:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    449c:	91394021 	add	x1, x1, #0xe50
    44a0:	aa1503e0 	mov	x0, x21
    44a4:	9a81c041 	csel	x1, x2, x1, gt
    44a8:	97fff466 	bl	1640 <strcpy@plt>
    44ac:	d503201f 	nop
    44b0:	aa1503e0 	mov	x0, x21
    44b4:	97fff3b7 	bl	1390 <strlen@plt>
    44b8:	aa1503e1 	mov	x1, x21
    44bc:	aa0003e2 	mov	x2, x0
    44c0:	aa1403e0 	mov	x0, x20
    44c4:	97fff713 	bl	2110 <buf_put>
    44c8:	f9413bf5 	ldr	x21, [sp, #624]
    44cc:	f9413ff6 	ldr	x22, [sp, #632]
    44d0:	f94153fb 	ldr	x27, [sp, #672]
    44d4:	f94157fc 	ldr	x28, [sp, #680]
    44d8:	fd415be8 	ldr	d8, [sp, #688]
    44dc:	fd415fe9 	ldr	d9, [sp, #696]
    44e0:	17fffeb8 	b	3fc0 <fwp_write.constprop.0+0xb0>
    44e4:	f90143f7 	str	x23, [sp, #640]
    44e8:	52800443 	mov	w3, #0x22                  	// #34
    44ec:	f90147f8 	str	x24, [sp, #648]
    44f0:	91001ff5 	add	x21, sp, #0x7
    44f4:	aa1503e1 	mov	x1, x21
    44f8:	aa1403e0 	mov	x0, x20
    44fc:	f8408677 	ldr	x23, [x19], #8
    4500:	d2800022 	mov	x2, #0x1                   	// #1
    4504:	39001fe3 	strb	w3, [sp, #7]
    4508:	97fff702 	bl	2110 <buf_put>
    450c:	8b1302f6 	add	x22, x23, x19
    4510:	b4002657 	cbz	x23, 49d8 <fwp_write.constprop.0+0xac8>
    4514:	d0000018 	adrp	x24, 6000 <fwp_main_thread+0x114c>
    4518:	913ae318 	add	x24, x24, #0xeb8
    451c:	f9014bf9 	str	x25, [sp, #656]
    4520:	d0000019 	adrp	x25, 6000 <fwp_main_thread+0x114c>
    4524:	913b6339 	add	x25, x25, #0xed8
    4528:	f9014ffa 	str	x26, [sp, #664]
    452c:	1400000e 	b	4564 <fwp_write.constprop.0+0x654>
    4530:	710024bf 	cmp	w5, #0x9
    4534:	54002380 	b.eq	49a4 <fwp_write.constprop.0+0xa94>  // b.none
    4538:	710028bf 	cmp	w5, #0xa
    453c:	54002be1 	b.ne	4ab8 <fwp_write.constprop.0+0xba8>  // b.any
    4540:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4544:	aa1403e0 	mov	x0, x20
    4548:	913b2021 	add	x1, x1, #0xec8
    454c:	d2800042 	mov	x2, #0x2                   	// #2
    4550:	97fff6f0 	bl	2110 <buf_put>
    4554:	d503201f 	nop
    4558:	91000673 	add	x19, x19, #0x1
    455c:	eb16027f 	cmp	x19, x22
    4560:	54002380 	b.eq	49d0 <fwp_write.constprop.0+0xac0>  // b.none
    4564:	39400265 	ldrb	w5, [x19]
    4568:	710034bf 	cmp	w5, #0xd
    456c:	54002120 	b.eq	4990 <fwp_write.constprop.0+0xa80>  // b.none
    4570:	54fffe09 	b.ls	4530 <fwp_write.constprop.0+0x620>  // b.plast
    4574:	710088bf 	cmp	w5, #0x22
    4578:	54002220 	b.eq	49bc <fwp_write.constprop.0+0xaac>  // b.none
    457c:	710170bf 	cmp	w5, #0x5c
    4580:	54002ba1 	b.ne	4af4 <fwp_write.constprop.0+0xbe4>  // b.any
    4584:	aa1403e0 	mov	x0, x20
    4588:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    458c:	d2800042 	mov	x2, #0x2                   	// #2
    4590:	913b0021 	add	x1, x1, #0xec0
    4594:	97fff6df 	bl	2110 <buf_put>
    4598:	17fffff0 	b	4558 <fwp_write.constprop.0+0x648>
    459c:	fd015be8 	str	d8, [sp, #688]
    45a0:	9e670268 	fmov	d8, x19
    45a4:	fd015fe9 	str	d9, [sp, #696]
    45a8:	1e682100 	fcmp	d8, d8
    45ac:	54004086 	b.vs	4dbc <fwp_write.constprop.0+0xeac>
    45b0:	1e60c101 	fabs	d1, d8
    45b4:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    45b8:	9e670000 	fmov	d0, x0
    45bc:	910123f5 	add	x21, sp, #0x48
    45c0:	52800033 	mov	w19, #0x1                   	// #1
    45c4:	1e602020 	fcmp	d1, d0
    45c8:	540001ad 	b.le	45fc <fwp_write.constprop.0+0x6ec>
    45cc:	1e602118 	fcmpe	d8, #0.0
    45d0:	d0000002 	adrp	x2, 6000 <fwp_main_thread+0x114c>
    45d4:	91318042 	add	x2, x2, #0xc60
    45d8:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    45dc:	91394021 	add	x1, x1, #0xe50
    45e0:	aa1503e0 	mov	x0, x21
    45e4:	9a81c041 	csel	x1, x2, x1, gt
    45e8:	97fff416 	bl	1640 <strcpy@plt>
    45ec:	17ffffb1 	b	44b0 <fwp_write.constprop.0+0x5a0>
    45f0:	11000673 	add	w19, w19, #0x1
    45f4:	71004a7f 	cmp	w19, #0x12
    45f8:	540031a0 	b.eq	4c2c <fwp_write.constprop.0+0xd1c>  // b.none
    45fc:	1e604100 	fmov	d0, d8
    4600:	2a1303e1 	mov	w1, w19
    4604:	aa1503e0 	mov	x0, x21
    4608:	97fff756 	bl	2360 <fwp_format_g.constprop.0>
    460c:	aa1503e0 	mov	x0, x21
    4610:	d2800001 	mov	x1, #0x0                   	// #0
    4614:	97fff373 	bl	13e0 <strtod@plt>
    4618:	1e602100 	fcmp	d8, d0
    461c:	54fffea1 	b.ne	45f0 <fwp_write.constprop.0+0x6e0>  // b.any
    4620:	aa1503e0 	mov	x0, x21
    4624:	97fff6f4 	bl	21f4 <fwp_finish_float>
    4628:	17ffffa2 	b	44b0 <fwp_write.constprop.0+0x5a0>
    462c:	a9400e62 	ldp	x2, x3, [x19]
    4630:	910123f3 	add	x19, sp, #0x48
    4634:	aa1303e0 	mov	x0, x19
    4638:	97fff50a 	bl	1a60 <fwp_fmt_u128>
    463c:	17fffe57 	b	3f98 <fwp_write.constprop.0+0x88>
    4640:	f90143f7 	str	x23, [sp, #640]
    4644:	f90147f8 	str	x24, [sp, #648]
    4648:	2a1303f8 	mov	w24, w19
    464c:	f9014bf9 	str	x25, [sp, #656]
    4650:	f9014ffa 	str	x26, [sp, #664]
    4654:	f13ffe7f 	cmp	x19, #0xfff
    4658:	54000049 	b.ls	4660 <fwp_write.constprop.0+0x750>  // b.plast
    465c:	b9400278 	ldr	w24, [x19]
    4660:	f9400f80 	ldr	x0, [x28, #24]
    4664:	2a1803f5 	mov	w21, w24
    4668:	d37d7f18 	ubfiz	x24, x24, #3, #32
    466c:	d37ef6b9 	lsl	x25, x21, #2
    4670:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    4674:	aa1603e0 	mov	x0, x22
    4678:	97fff346 	bl	1390 <strlen@plt>
    467c:	aa1603e1 	mov	x1, x22
    4680:	aa0003e2 	mov	x2, x0
    4684:	aa1403e0 	mov	x0, x20
    4688:	97fff6a2 	bl	2110 <buf_put>
    468c:	f9401780 	ldr	x0, [x28, #40]
    4690:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    4694:	7100001f 	cmp	w0, #0x0
    4698:	5400064d 	b.le	4760 <fwp_write.constprop.0+0x850>
    469c:	91002276 	add	x22, x19, #0x8
    46a0:	91001ff5 	add	x21, sp, #0x7
    46a4:	d280001b 	mov	x27, #0x0                   	// #0
    46a8:	5280041a 	mov	w26, #0x20                  	// #32
    46ac:	f9401b80 	ldr	x0, [x28, #48]
    46b0:	aa1503e1 	mov	x1, x21
    46b4:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    46b8:	d2800022 	mov	x2, #0x1                   	// #1
    46bc:	f8786805 	ldr	x5, [x0, x24]
    46c0:	aa1403e0 	mov	x0, x20
    46c4:	f87b78b3 	ldr	x19, [x5, x27, lsl #3]
    46c8:	39001ffa 	strb	w26, [sp, #7]
    46cc:	97fff691 	bl	2110 <buf_put>
    46d0:	f13ffeff 	cmp	x23, #0xfff
    46d4:	b9400261 	ldr	w1, [x19]
    46d8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    46dc:	7100383f 	cmp	w1, #0xe
    46e0:	54000140 	b.eq	4708 <fwp_write.constprop.0+0x7f8>  // b.none
    46e4:	7100403f 	cmp	w1, #0x10
    46e8:	54001c20 	b.eq	4a6c <fwp_write.constprop.0+0xb5c>  // b.none
    46ec:	7100283f 	cmp	w1, #0xa
    46f0:	540026e0 	b.eq	4bcc <fwp_write.constprop.0+0xcbc>  // b.none
    46f4:	540013cc 	b.gt	496c <fwp_write.constprop.0+0xa5c>
    46f8:	71000c3f 	cmp	w1, #0x3
    46fc:	540025ec 	b.gt	4bb8 <fwp_write.constprop.0+0xca8>
    4700:	d37ffee0 	lsr	x0, x23, #63
    4704:	37f813c1 	tbnz	w1, #31, 497c <fwp_write.constprop.0+0xa6c>
    4708:	340013a0 	cbz	w0, 497c <fwp_write.constprop.0+0xa6c>
    470c:	52800503 	mov	w3, #0x28                  	// #40
    4710:	aa1503e1 	mov	x1, x21
    4714:	aa1403e0 	mov	x0, x20
    4718:	d2800022 	mov	x2, #0x1                   	// #1
    471c:	39001fe3 	strb	w3, [sp, #7]
    4720:	97fff67c 	bl	2110 <buf_put>
    4724:	aa1303e2 	mov	x2, x19
    4728:	aa1703e1 	mov	x1, x23
    472c:	aa1403e0 	mov	x0, x20
    4730:	97fffdf8 	bl	3f10 <fwp_write.constprop.0>
    4734:	52800523 	mov	w3, #0x29                  	// #41
    4738:	aa1503e1 	mov	x1, x21
    473c:	aa1403e0 	mov	x0, x20
    4740:	d2800022 	mov	x2, #0x1                   	// #1
    4744:	39001fe3 	strb	w3, [sp, #7]
    4748:	97fff672 	bl	2110 <buf_put>
    474c:	f9401780 	ldr	x0, [x28, #40]
    4750:	9100077b 	add	x27, x27, #0x1
    4754:	b8796800 	ldr	w0, [x0, x25]
    4758:	6b1b001f 	cmp	w0, w27
    475c:	54fffa8c 	b.gt	46ac <fwp_write.constprop.0+0x79c>
    4760:	f9413bf5 	ldr	x21, [sp, #624]
    4764:	f9413ff6 	ldr	x22, [sp, #632]
    4768:	f94143f7 	ldr	x23, [sp, #640]
    476c:	f94147f8 	ldr	x24, [sp, #648]
    4770:	f9414bf9 	ldr	x25, [sp, #656]
    4774:	f9414ffa 	ldr	x26, [sp, #664]
    4778:	f94153fb 	ldr	x27, [sp, #672]
    477c:	f94157fc 	ldr	x28, [sp, #680]
    4780:	17fffe10 	b	3fc0 <fwp_write.constprop.0+0xb0>
    4784:	aa1403e0 	mov	x0, x20
    4788:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    478c:	d28000c2 	mov	x2, #0x6                   	// #6
    4790:	913ba021 	add	x1, x1, #0xee8
    4794:	97fff65f 	bl	2110 <buf_put>
    4798:	f9400260 	ldr	x0, [x19]
    479c:	b40004c0 	cbz	x0, 4834 <fwp_write.constprop.0+0x924>
    47a0:	910123f5 	add	x21, sp, #0x48
    47a4:	91002276 	add	x22, x19, #0x8
    47a8:	f90143f7 	str	x23, [sp, #640]
    47ac:	d2800017 	mov	x23, #0x0                   	// #0
    47b0:	f90147f8 	str	x24, [sp, #648]
    47b4:	d0000018 	adrp	x24, 6000 <fwp_main_thread+0x114c>
    47b8:	913bc318 	add	x24, x24, #0xef0
    47bc:	f9014bf9 	str	x25, [sp, #656]
    47c0:	d0000019 	adrp	x25, 6000 <fwp_main_thread+0x114c>
    47c4:	913be339 	add	x25, x25, #0xef8
    47c8:	f9014ffa 	str	x26, [sp, #664]
    47cc:	14000005 	b	47e0 <fwp_write.constprop.0+0x8d0>
    47d0:	aa1903e1 	mov	x1, x25
    47d4:	aa1403e0 	mov	x0, x20
    47d8:	d2800042 	mov	x2, #0x2                   	// #2
    47dc:	97fff64d 	bl	2110 <buf_put>
    47e0:	38776ac5 	ldrb	w5, [x22, x23]
    47e4:	d2804003 	mov	x3, #0x200                 	// #512
    47e8:	aa1803e4 	mov	x4, x24
    47ec:	aa0303e1 	mov	x1, x3
    47f0:	52800042 	mov	w2, #0x2                   	// #2
    47f4:	aa1503e0 	mov	x0, x21
    47f8:	910006f7 	add	x23, x23, #0x1
    47fc:	97fff31d 	bl	1470 <__snprintf_chk@plt>
    4800:	aa1503e0 	mov	x0, x21
    4804:	97fff2e3 	bl	1390 <strlen@plt>
    4808:	aa1503e1 	mov	x1, x21
    480c:	aa0003e2 	mov	x2, x0
    4810:	aa1403e0 	mov	x0, x20
    4814:	97fff63f 	bl	2110 <buf_put>
    4818:	f9400260 	ldr	x0, [x19]
    481c:	eb0002ff 	cmp	x23, x0
    4820:	54fffd83 	b.cc	47d0 <fwp_write.constprop.0+0x8c0>  // b.lo, b.ul, b.last
    4824:	f94143f7 	ldr	x23, [sp, #640]
    4828:	f94147f8 	ldr	x24, [sp, #648]
    482c:	f9414bf9 	ldr	x25, [sp, #656]
    4830:	f9414ffa 	ldr	x26, [sp, #664]
    4834:	52800ba3 	mov	w3, #0x5d                  	// #93
    4838:	aa1403e0 	mov	x0, x20
    483c:	91001fe1 	add	x1, sp, #0x7
    4840:	d2800022 	mov	x2, #0x1                   	// #1
    4844:	39001fe3 	strb	w3, [sp, #7]
    4848:	17fffdd9 	b	3fac <fwp_write.constprop.0+0x9c>
    484c:	52800b63 	mov	w3, #0x5b                  	// #91
    4850:	91001ff5 	add	x21, sp, #0x7
    4854:	aa1503e1 	mov	x1, x21
    4858:	aa1403e0 	mov	x0, x20
    485c:	d2800022 	mov	x2, #0x1                   	// #1
    4860:	d0000016 	adrp	x22, 6000 <fwp_main_thread+0x114c>
    4864:	913be2d6 	add	x22, x22, #0xef8
    4868:	39001fe3 	strb	w3, [sp, #7]
    486c:	97fff629 	bl	2110 <buf_put>
    4870:	b4000233 	cbz	x19, 48b4 <fwp_write.constprop.0+0x9a4>
    4874:	f9400661 	ldr	x1, [x19, #8]
    4878:	aa1403e0 	mov	x0, x20
    487c:	f9401f82 	ldr	x2, [x28, #56]
    4880:	97fffda4 	bl	3f10 <fwp_write.constprop.0>
    4884:	f9400a73 	ldr	x19, [x19, #16]
    4888:	b4000173 	cbz	x19, 48b4 <fwp_write.constprop.0+0x9a4>
    488c:	aa1603e1 	mov	x1, x22
    4890:	aa1403e0 	mov	x0, x20
    4894:	d2800042 	mov	x2, #0x2                   	// #2
    4898:	97fff61e 	bl	2110 <buf_put>
    489c:	f9400661 	ldr	x1, [x19, #8]
    48a0:	aa1403e0 	mov	x0, x20
    48a4:	f9401f82 	ldr	x2, [x28, #56]
    48a8:	97fffd9a 	bl	3f10 <fwp_write.constprop.0>
    48ac:	f9400a73 	ldr	x19, [x19, #16]
    48b0:	b5fffef3 	cbnz	x19, 488c <fwp_write.constprop.0+0x97c>
    48b4:	52800ba3 	mov	w3, #0x5d                  	// #93
    48b8:	aa1503e1 	mov	x1, x21
    48bc:	aa1403e0 	mov	x0, x20
    48c0:	d2800022 	mov	x2, #0x1                   	// #1
    48c4:	39001fe3 	strb	w3, [sp, #7]
    48c8:	17fffdb9 	b	3fac <fwp_write.constprop.0+0x9c>
    48cc:	52800783 	mov	w3, #0x3c                  	// #60
    48d0:	91001ff3 	add	x19, sp, #0x7
    48d4:	aa1303e1 	mov	x1, x19
    48d8:	d2800022 	mov	x2, #0x1                   	// #1
    48dc:	aa1403e0 	mov	x0, x20
    48e0:	39001fe3 	strb	w3, [sp, #7]
    48e4:	97fff60b 	bl	2110 <buf_put>
    48e8:	f9400795 	ldr	x21, [x28, #8]
    48ec:	aa1503e0 	mov	x0, x21
    48f0:	97fff2a8 	bl	1390 <strlen@plt>
    48f4:	aa1503e1 	mov	x1, x21
    48f8:	aa0003e2 	mov	x2, x0
    48fc:	aa1403e0 	mov	x0, x20
    4900:	97fff604 	bl	2110 <buf_put>
    4904:	528007c3 	mov	w3, #0x3e                  	// #62
    4908:	aa1303e1 	mov	x1, x19
    490c:	aa1403e0 	mov	x0, x20
    4910:	d2800022 	mov	x2, #0x1                   	// #1
    4914:	39001fe3 	strb	w3, [sp, #7]
    4918:	17fffda5 	b	3fac <fwp_write.constprop.0+0x9c>
    491c:	f100067f 	cmp	x19, #0x1
    4920:	540017e0 	b.eq	4c1c <fwp_write.constprop.0+0xd0c>  // b.none
    4924:	b100067f 	cmn	x19, #0x1
    4928:	54001b00 	b.eq	4c88 <fwp_write.constprop.0+0xd78>  // b.none
    492c:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4930:	9139a021 	add	x1, x1, #0xe68
    4934:	d2800022 	mov	x2, #0x1                   	// #1
    4938:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    493c:	f947f400 	ldr	x0, [x0, #4072]
    4940:	f94127e4 	ldr	x4, [sp, #584]
    4944:	f9400003 	ldr	x3, [x0]
    4948:	eb030084 	subs	x4, x4, x3
    494c:	d2800003 	mov	x3, #0x0                   	// #0
    4950:	54002a41 	b.ne	4e98 <fwp_write.constprop.0+0xf88>  // b.any
    4954:	f9413bf5 	ldr	x21, [sp, #624]
    4958:	aa1403e0 	mov	x0, x20
    495c:	f9413ff6 	ldr	x22, [sp, #632]
    4960:	17fffdef 	b	411c <fwp_write.constprop.0+0x20c>
    4964:	52800fa3 	mov	w3, #0x7d                  	// #125
    4968:	17fffe2c 	b	4218 <fwp_write.constprop.0+0x308>
    496c:	f10002ff 	cmp	x23, #0x0
    4970:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4974:	71002c3f 	cmp	w1, #0xb
    4978:	54ffec80 	b.eq	4708 <fwp_write.constprop.0+0x7f8>  // b.none
    497c:	aa1303e2 	mov	x2, x19
    4980:	aa1703e1 	mov	x1, x23
    4984:	aa1403e0 	mov	x0, x20
    4988:	97fffd62 	bl	3f10 <fwp_write.constprop.0>
    498c:	17ffff70 	b	474c <fwp_write.constprop.0+0x83c>
    4990:	aa1903e1 	mov	x1, x25
    4994:	aa1403e0 	mov	x0, x20
    4998:	d2800042 	mov	x2, #0x2                   	// #2
    499c:	97fff5dd 	bl	2110 <buf_put>
    49a0:	17fffeee 	b	4558 <fwp_write.constprop.0+0x648>
    49a4:	aa1403e0 	mov	x0, x20
    49a8:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    49ac:	d2800042 	mov	x2, #0x2                   	// #2
    49b0:	913b4021 	add	x1, x1, #0xed0
    49b4:	97fff5d7 	bl	2110 <buf_put>
    49b8:	17fffee8 	b	4558 <fwp_write.constprop.0+0x648>
    49bc:	aa1803e1 	mov	x1, x24
    49c0:	aa1403e0 	mov	x0, x20
    49c4:	d2800042 	mov	x2, #0x2                   	// #2
    49c8:	97fff5d2 	bl	2110 <buf_put>
    49cc:	17fffee3 	b	4558 <fwp_write.constprop.0+0x648>
    49d0:	f9414bf9 	ldr	x25, [sp, #656]
    49d4:	f9414ffa 	ldr	x26, [sp, #664]
    49d8:	aa1503e1 	mov	x1, x21
    49dc:	aa1403e0 	mov	x0, x20
    49e0:	52800443 	mov	w3, #0x22                  	// #34
    49e4:	17fffe0f 	b	4220 <fwp_write.constprop.0+0x310>
    49e8:	a9400281 	ldp	x1, x0, [x20]
    49ec:	91000800 	add	x0, x0, #0x2
    49f0:	8b160000 	add	x0, x0, x22
    49f4:	f9000680 	str	x0, [x20, #8]
    49f8:	3820683f 	strb	wzr, [x1, x0]
    49fc:	f9413bf5 	ldr	x21, [sp, #624]
    4a00:	f9413ff6 	ldr	x22, [sp, #632]
    4a04:	f94153fb 	ldr	x27, [sp, #672]
    4a08:	f94157fc 	ldr	x28, [sp, #680]
    4a0c:	17fffd6d 	b	3fc0 <fwp_write.constprop.0+0xb0>
    4a10:	aa1403e0 	mov	x0, x20
    4a14:	91001fe1 	add	x1, sp, #0x7
    4a18:	52800fa3 	mov	w3, #0x7d                  	// #125
    4a1c:	d2800022 	mov	x2, #0x1                   	// #1
    4a20:	17fffe01 	b	4224 <fwp_write.constprop.0+0x314>
    4a24:	f9400f80 	ldr	x0, [x28, #24]
    4a28:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    4a2c:	aa1b03e0 	mov	x0, x27
    4a30:	97fff258 	bl	1390 <strlen@plt>
    4a34:	aa1b03e1 	mov	x1, x27
    4a38:	aa0003e2 	mov	x2, x0
    4a3c:	aa1403e0 	mov	x0, x20
    4a40:	97fff5b4 	bl	2110 <buf_put>
    4a44:	aa1903e1 	mov	x1, x25
    4a48:	aa1403e0 	mov	x0, x20
    4a4c:	d2800062 	mov	x2, #0x3                   	// #3
    4a50:	97fff5b0 	bl	2110 <buf_put>
    4a54:	17fffde4 	b	41e4 <fwp_write.constprop.0+0x2d4>
    4a58:	aa1a03e1 	mov	x1, x26
    4a5c:	aa1403e0 	mov	x0, x20
    4a60:	d2800042 	mov	x2, #0x2                   	// #2
    4a64:	97fff5ab 	bl	2110 <buf_put>
    4a68:	17fffddd 	b	41dc <fwp_write.constprop.0+0x2cc>
    4a6c:	f9400660 	ldr	x0, [x19, #8]
    4a70:	b4fff860 	cbz	x0, 497c <fwp_write.constprop.0+0xa6c>
    4a74:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4a78:	913c4021 	add	x1, x1, #0xf10
    4a7c:	97fff2c1 	bl	1580 <strcmp@plt>
    4a80:	7100001f 	cmp	w0, #0x0
    4a84:	1a9f07e0 	cset	w0, ne	// ne = any
    4a88:	17ffff20 	b	4708 <fwp_write.constprop.0+0x7f8>
    4a8c:	aa1403e0 	mov	x0, x20
    4a90:	d2800042 	mov	x2, #0x2                   	// #2
    4a94:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4a98:	913c2021 	add	x1, x1, #0xf08
    4a9c:	97fff59d 	bl	2110 <buf_put>
    4aa0:	91004261 	add	x1, x19, #0x10
    4aa4:	aa1403e0 	mov	x0, x20
    4aa8:	f9402382 	ldr	x2, [x28, #64]
    4aac:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    4ab0:	97fffd18 	bl	3f10 <fwp_write.constprop.0>
    4ab4:	17fffd71 	b	4078 <fwp_write.constprop.0+0x168>
    4ab8:	d2800203 	mov	x3, #0x10                  	// #16
    4abc:	d0000004 	adrp	x4, 6000 <fwp_main_thread+0x114c>
    4ac0:	aa0303e1 	mov	x1, x3
    4ac4:	913b8084 	add	x4, x4, #0xee0
    4ac8:	910123f7 	add	x23, sp, #0x48
    4acc:	52800042 	mov	w2, #0x2                   	// #2
    4ad0:	aa1703e0 	mov	x0, x23
    4ad4:	97fff267 	bl	1470 <__snprintf_chk@plt>
    4ad8:	aa1703e0 	mov	x0, x23
    4adc:	97fff22d 	bl	1390 <strlen@plt>
    4ae0:	aa1703e1 	mov	x1, x23
    4ae4:	aa0003e2 	mov	x2, x0
    4ae8:	aa1403e0 	mov	x0, x20
    4aec:	97fff589 	bl	2110 <buf_put>
    4af0:	17fffe9a 	b	4558 <fwp_write.constprop.0+0x648>
    4af4:	7101fcbf 	cmp	w5, #0x7f
    4af8:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    4afc:	54fffde9 	b.ls	4ab8 <fwp_write.constprop.0+0xba8>  // b.plast
    4b00:	aa1503e1 	mov	x1, x21
    4b04:	aa1403e0 	mov	x0, x20
    4b08:	d2800022 	mov	x2, #0x1                   	// #1
    4b0c:	39001fe5 	strb	w5, [sp, #7]
    4b10:	97fff580 	bl	2110 <buf_put>
    4b14:	17fffe91 	b	4558 <fwp_write.constprop.0+0x648>
    4b18:	1e22c109 	fcvt	d9, s8
    4b1c:	910123f5 	add	x21, sp, #0x48
    4b20:	52800033 	mov	w19, #0x1                   	// #1
    4b24:	d503201f 	nop
    4b28:	1e604120 	fmov	d0, d9
    4b2c:	2a1303e1 	mov	w1, w19
    4b30:	aa1503e0 	mov	x0, x21
    4b34:	97fff60b 	bl	2360 <fwp_format_g.constprop.0>
    4b38:	aa1503e0 	mov	x0, x21
    4b3c:	d2800001 	mov	x1, #0x0                   	// #0
    4b40:	97fff29c 	bl	15b0 <strtof@plt>
    4b44:	1e202100 	fcmp	s8, s0
    4b48:	54ffd6c0 	b.eq	4620 <fwp_write.constprop.0+0x710>  // b.none
    4b4c:	11000673 	add	w19, w19, #0x1
    4b50:	71002a7f 	cmp	w19, #0xa
    4b54:	54fffea1 	b.ne	4b28 <fwp_write.constprop.0+0xc18>  // b.any
    4b58:	1e604120 	fmov	d0, d9
    4b5c:	aa1503e0 	mov	x0, x21
    4b60:	52800121 	mov	w1, #0x9                   	// #9
    4b64:	97fff5ff 	bl	2360 <fwp_format_g.constprop.0>
    4b68:	17fffeae 	b	4620 <fwp_write.constprop.0+0x710>
    4b6c:	d37ef6a1 	lsl	x1, x21, #2
    4b70:	b7f809a3 	tbnz	x3, #63, 4ca4 <fwp_write.constprop.0+0xd94>
    4b74:	91002263 	add	x3, x19, #0x8
    4b78:	8b010061 	add	x1, x3, x1
    4b7c:	b9400023 	ldr	w3, [x1]
    4b80:	7100081f 	cmp	w0, #0x2
    4b84:	2a0303e1 	mov	w1, w3
    4b88:	93407c63 	sxtw	x3, w3
    4b8c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4b90:	17fffe16 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4b94:	d37ffaa1 	lsl	x1, x21, #1
    4b98:	b7f80803 	tbnz	x3, #63, 4c98 <fwp_write.constprop.0+0xd88>
    4b9c:	91002263 	add	x3, x19, #0x8
    4ba0:	8b010061 	add	x1, x3, x1
    4ba4:	79400021 	ldrh	w1, [x1]
    4ba8:	7100041f 	cmp	w0, #0x1
    4bac:	93403c23 	sxth	x3, w1
    4bb0:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    4bb4:	17fffe0d 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4bb8:	7100103f 	cmp	w1, #0x4
    4bbc:	54ffee01 	b.ne	497c <fwp_write.constprop.0+0xa6c>  // b.any
    4bc0:	f94006e0 	ldr	x0, [x23, #8]
    4bc4:	d37ffc00 	lsr	x0, x0, #63
    4bc8:	17fffed0 	b	4708 <fwp_write.constprop.0+0x7f8>
    4bcc:	710002ff 	cmp	w23, #0x0
    4bd0:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    4bd4:	17fffecd 	b	4708 <fwp_write.constprop.0+0x7f8>
    4bd8:	528005a1 	mov	w1, #0x2d                  	// #45
    4bdc:	eb0203e2 	negs	x2, x2
    4be0:	da0303e3 	ngc	x3, x3
    4be4:	910127e0 	add	x0, sp, #0x49
    4be8:	910123f5 	add	x21, sp, #0x48
    4bec:	390123e1 	strb	w1, [sp, #72]
    4bf0:	97fff39c 	bl	1a60 <fwp_fmt_u128>
    4bf4:	17fffe16 	b	444c <fwp_write.constprop.0+0x53c>
    4bf8:	d37ceea1 	lsl	x1, x21, #4
    4bfc:	b7f80da3 	tbnz	x3, #63, 4db0 <fwp_write.constprop.0+0xea0>
    4c00:	91002260 	add	x0, x19, #0x8
    4c04:	8b010001 	add	x1, x0, x1
    4c08:	17fffdf8 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4c0c:	f9400a61 	ldr	x1, [x19, #16]
    4c10:	8b010000 	add	x0, x0, x1
    4c14:	f9400001 	ldr	x1, [x0]
    4c18:	17fffdf4 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4c1c:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4c20:	d2800042 	mov	x2, #0x2                   	// #2
    4c24:	91396021 	add	x1, x1, #0xe58
    4c28:	17ffff44 	b	4938 <fwp_write.constprop.0+0xa28>
    4c2c:	1e604100 	fmov	d0, d8
    4c30:	aa1503e0 	mov	x0, x21
    4c34:	52800221 	mov	w1, #0x11                  	// #17
    4c38:	97fff5ca 	bl	2360 <fwp_format_g.constprop.0>
    4c3c:	17fffe79 	b	4620 <fwp_write.constprop.0+0x710>
    4c40:	b9401380 	ldr	w0, [x28, #16]
    4c44:	350003c0 	cbnz	w0, 4cbc <fwp_write.constprop.0+0xdac>
    4c48:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    4c4c:	f947f400 	ldr	x0, [x0, #4072]
    4c50:	f94127e2 	ldr	x2, [sp, #584]
    4c54:	f9400001 	ldr	x1, [x0]
    4c58:	eb010042 	subs	x2, x2, x1
    4c5c:	d2800001 	mov	x1, #0x0                   	// #0
    4c60:	54001201 	b.ne	4ea0 <fwp_write.constprop.0+0xf90>  // b.any
    4c64:	f9413bf5 	ldr	x21, [sp, #624]
    4c68:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4c6c:	f9413ff6 	ldr	x22, [sp, #632]
    4c70:	aa1403e0 	mov	x0, x20
    4c74:	f94143f7 	ldr	x23, [sp, #640]
    4c78:	913cc021 	add	x1, x1, #0xf30
    4c7c:	f94147f8 	ldr	x24, [sp, #648]
    4c80:	d2800042 	mov	x2, #0x2                   	// #2
    4c84:	17fffd26 	b	411c <fwp_write.constprop.0+0x20c>
    4c88:	d0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    4c8c:	d2800042 	mov	x2, #0x2                   	// #2
    4c90:	91398021 	add	x1, x1, #0xe60
    4c94:	17ffff29 	b	4938 <fwp_write.constprop.0+0xa28>
    4c98:	f9400a63 	ldr	x3, [x19, #16]
    4c9c:	8b030021 	add	x1, x1, x3
    4ca0:	17ffffc1 	b	4ba4 <fwp_write.constprop.0+0xc94>
    4ca4:	f9400a63 	ldr	x3, [x19, #16]
    4ca8:	8b030021 	add	x1, x1, x3
    4cac:	17ffffb4 	b	4b7c <fwp_write.constprop.0+0xc6c>
    4cb0:	f9400a61 	ldr	x1, [x19, #16]
    4cb4:	8b0102a1 	add	x1, x21, x1
    4cb8:	17fffdc7 	b	43d4 <fwp_write.constprop.0+0x4c4>
    4cbc:	b9404b80 	ldr	w0, [x28, #72]
    4cc0:	91001ff5 	add	x21, sp, #0x7
    4cc4:	34ffa660 	cbz	w0, 4190 <fwp_write.constprop.0+0x280>
    4cc8:	52800503 	mov	w3, #0x28                  	// #40
    4ccc:	aa1403e0 	mov	x0, x20
    4cd0:	aa1503e1 	mov	x1, x21
    4cd4:	d2800022 	mov	x2, #0x1                   	// #1
    4cd8:	39001fe3 	strb	w3, [sp, #7]
    4cdc:	97fff50d 	bl	2110 <buf_put>
    4ce0:	b9401380 	ldr	w0, [x28, #16]
    4ce4:	52800038 	mov	w24, #0x1                   	// #1
    4ce8:	7100001f 	cmp	w0, #0x0
    4cec:	54ffa66c 	b.gt	41b8 <fwp_write.constprop.0+0x2a8>
    4cf0:	17fffd49 	b	4214 <fwp_write.constprop.0+0x304>
    4cf4:	f9014bf9 	str	x25, [sp, #656]
    4cf8:	f00000d9 	adrp	x25, 1f000 <__FRAME_END__+0x170f8>
    4cfc:	f9014ffa 	str	x26, [sp, #664]
    4d00:	f9400676 	ldr	x22, [x19, #8]
    4d04:	912ca333 	add	x19, x25, #0xb28
    4d08:	91002273 	add	x19, x19, #0x8
    4d0c:	937ffed8 	asr	x24, x22, #63
    4d10:	aa1802c0 	orr	x0, x22, x24
    4d14:	b5000320 	cbnz	x0, 4d78 <fwp_write.constprop.0+0xe68>
    4d18:	110006b5 	add	w21, w21, #0x1
    4d1c:	710016bf 	cmp	w21, #0x5
    4d20:	54ffffc1 	b.ne	4d18 <fwp_write.constprop.0+0xe08>  // b.any
    4d24:	b7f80578 	tbnz	x24, #63, 4dd0 <fwp_write.constprop.0+0xec0>
    4d28:	910023f3 	add	x19, sp, #0x8
    4d2c:	aa1603e2 	mov	x2, x22
    4d30:	aa1303e0 	mov	x0, x19
    4d34:	d2800003 	mov	x3, #0x0                   	// #0
    4d38:	97fff34a 	bl	1a60 <fwp_fmt_u128>
    4d3c:	910123f5 	add	x21, sp, #0x48
    4d40:	d0000003 	adrp	x3, 6000 <fwp_main_thread+0x114c>
    4d44:	aa1303e4 	mov	x4, x19
    4d48:	aa1503e0 	mov	x0, x21
    4d4c:	913ca063 	add	x3, x3, #0xf28
    4d50:	d2804002 	mov	x2, #0x200                 	// #512
    4d54:	52800041 	mov	w1, #0x2                   	// #2
    4d58:	97fff192 	bl	13a0 <__sprintf_chk@plt>
    4d5c:	aa1503e0 	mov	x0, x21
    4d60:	97fff18c 	bl	1390 <strlen@plt>
    4d64:	aa1503e1 	mov	x1, x21
    4d68:	aa0003e2 	mov	x2, x0
    4d6c:	aa1403e0 	mov	x0, x20
    4d70:	97fff4e8 	bl	2110 <buf_put>
    4d74:	17fffe7b 	b	4760 <fwp_write.constprop.0+0x850>
    4d78:	f9400277 	ldr	x23, [x19]
    4d7c:	aa1603e0 	mov	x0, x22
    4d80:	aa1803e1 	mov	x1, x24
    4d84:	aa1703e2 	mov	x2, x23
    4d88:	937ffefa 	asr	x26, x23, #63
    4d8c:	aa1a03e3 	mov	x3, x26
    4d90:	94000688 	bl	67b0 <__modti3>
    4d94:	aa010000 	orr	x0, x0, x1
    4d98:	b40002c0 	cbz	x0, 4df0 <fwp_write.constprop.0+0xee0>
    4d9c:	110006b5 	add	w21, w21, #0x1
    4da0:	91004273 	add	x19, x19, #0x10
    4da4:	710016bf 	cmp	w21, #0x5
    4da8:	54fffe81 	b.ne	4d78 <fwp_write.constprop.0+0xe68>  // b.any
    4dac:	17ffffde 	b	4d24 <fwp_write.constprop.0+0xe14>
    4db0:	f9400a60 	ldr	x0, [x19, #16]
    4db4:	8b000021 	add	x1, x1, x0
    4db8:	17fffd8c 	b	43e8 <fwp_write.constprop.0+0x4d8>
    4dbc:	528c29c0 	mov	w0, #0x614e                	// #24910
    4dc0:	910123f5 	add	x21, sp, #0x48
    4dc4:	72a009c0 	movk	w0, #0x4e, lsl #16
    4dc8:	b9004be0 	str	w0, [sp, #72]
    4dcc:	17fffdb9 	b	44b0 <fwp_write.constprop.0+0x5a0>
    4dd0:	528005a1 	mov	w1, #0x2d                  	// #45
    4dd4:	eb1603e2 	negs	x2, x22
    4dd8:	da1803e3 	ngc	x3, x24
    4ddc:	910027e0 	add	x0, sp, #0x9
    4de0:	910023f3 	add	x19, sp, #0x8
    4de4:	390023e1 	strb	w1, [sp, #8]
    4de8:	97fff31e 	bl	1a60 <fwp_fmt_u128>
    4dec:	17ffffd4 	b	4d3c <fwp_write.constprop.0+0xe2c>
    4df0:	aa1703e2 	mov	x2, x23
    4df4:	aa1a03e3 	mov	x3, x26
    4df8:	aa1603e0 	mov	x0, x22
    4dfc:	aa1803e1 	mov	x1, x24
    4e00:	9400058c 	bl	6430 <__divti3>
    4e04:	aa0003e2 	mov	x2, x0
    4e08:	aa0103e3 	mov	x3, x1
    4e0c:	b7f80201 	tbnz	x1, #63, 4e4c <fwp_write.constprop.0+0xf3c>
    4e10:	910023f3 	add	x19, sp, #0x8
    4e14:	aa1303e0 	mov	x0, x19
    4e18:	97fff312 	bl	1a60 <fwp_fmt_u128>
    4e1c:	937c7ea1 	sbfiz	x1, x21, #4, #32
    4e20:	912ca339 	add	x25, x25, #0xb28
    4e24:	910123f5 	add	x21, sp, #0x48
    4e28:	aa1303e4 	mov	x4, x19
    4e2c:	aa1503e0 	mov	x0, x21
    4e30:	d0000003 	adrp	x3, 6000 <fwp_main_thread+0x114c>
    4e34:	f8616b25 	ldr	x5, [x25, x1]
    4e38:	913c8063 	add	x3, x3, #0xf20
    4e3c:	d2804002 	mov	x2, #0x200                 	// #512
    4e40:	52800041 	mov	w1, #0x2                   	// #2
    4e44:	97fff157 	bl	13a0 <__sprintf_chk@plt>
    4e48:	17ffffc5 	b	4d5c <fwp_write.constprop.0+0xe4c>
    4e4c:	528005a4 	mov	w4, #0x2d                  	// #45
    4e50:	eb0003e2 	negs	x2, x0
    4e54:	da0103e3 	ngc	x3, x1
    4e58:	910027e0 	add	x0, sp, #0x9
    4e5c:	910023f3 	add	x19, sp, #0x8
    4e60:	390023e4 	strb	w4, [sp, #8]
    4e64:	97fff2ff 	bl	1a60 <fwp_fmt_u128>
    4e68:	17ffffed 	b	4e1c <fwp_write.constprop.0+0xf0c>
    4e6c:	f9013bf5 	str	x21, [sp, #624]
    4e70:	f9013ff6 	str	x22, [sp, #632]
    4e74:	f90143f7 	str	x23, [sp, #640]
    4e78:	f90147f8 	str	x24, [sp, #648]
    4e7c:	f9014bf9 	str	x25, [sp, #656]
    4e80:	f9014ffa 	str	x26, [sp, #664]
    4e84:	f90153fb 	str	x27, [sp, #672]
    4e88:	f90157fc 	str	x28, [sp, #680]
    4e8c:	fd015be8 	str	d8, [sp, #688]
    4e90:	fd015fe9 	str	d9, [sp, #696]
    4e94:	97fff19b 	bl	1500 <__stack_chk_fail@plt>
    4e98:	f90143f7 	str	x23, [sp, #640]
    4e9c:	f90147f8 	str	x24, [sp, #648]
    4ea0:	f9014bf9 	str	x25, [sp, #656]
    4ea4:	f9014ffa 	str	x26, [sp, #664]
    4ea8:	fd015be8 	str	d8, [sp, #688]
    4eac:	fd015fe9 	str	d9, [sp, #696]
    4eb0:	97fff194 	bl	1500 <__stack_chk_fail@plt>

0000000000004eb4 <fwp_main_thread>:
    4eb4:	d10683ff 	sub	sp, sp, #0x1a0
    4eb8:	f00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    4ebc:	f947f400 	ldr	x0, [x0, #4072]
    4ec0:	a9127bfd 	stp	x29, x30, [sp, #288]
    4ec4:	910483fd 	add	x29, sp, #0x120
    4ec8:	a91353f3 	stp	x19, x20, [sp, #304]
    4ecc:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc80>
    4ed0:	91158281 	add	x1, x20, #0x560
    4ed4:	a9145bf5 	stp	x21, x22, [sp, #320]
    4ed8:	a91773fb 	stp	x27, x28, [sp, #368]
    4edc:	b953a421 	ldr	w1, [x1, #5028]
    4ee0:	f9400002 	ldr	x2, [x0]
    4ee4:	f9008fe2 	str	x2, [sp, #280]
    4ee8:	d2800002 	mov	x2, #0x0                   	// #0
    4eec:	34002741 	cbz	w1, 53d4 <fwp_main_thread+0x520>
    4ef0:	91158280 	add	x0, x20, #0x560
    4ef4:	b953a800 	ldr	w0, [x0, #5032]
    4ef8:	35002760 	cbnz	w0, 53e4 <fwp_main_thread+0x530>
    4efc:	900000f6 	adrp	x22, 20000 <__data_start>
    4f00:	900000e2 	adrp	x2, 20000 <__data_start>
    4f04:	910202db 	add	x27, x22, #0x80
    4f08:	910e0042 	add	x2, x2, #0x380
    4f0c:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    4f10:	d2a00024 	mov	x4, #0x10000               	// #65536
    4f14:	910103f3 	add	x19, sp, #0x40
    4f18:	9100a3f5 	add	x21, sp, #0x28
    4f1c:	aa1303e0 	mov	x0, x19
    4f20:	d2800001 	mov	x1, #0x0                   	// #0
    4f24:	a9010f75 	stp	x21, x3, [x27, #16]
    4f28:	f90023e2 	str	x2, [sp, #64]
    4f2c:	b9004bff 	str	wzr, [sp, #72]
    4f30:	f9002be4 	str	x4, [sp, #80]
    4f34:	97fff10f 	bl	1370 <sigaltstack@plt>
    4f38:	a91563f7 	stp	x23, x24, [sp, #336]
    4f3c:	3500a5c0 	cbnz	w0, 63f4 <fwp_main_thread+0x1540>
    4f40:	4f000400 	movi	v0.4s, #0x0
    4f44:	910223e0 	add	x0, sp, #0x88
    4f48:	b0ffffe1 	adrp	x1, 1000 <__abi_tag+0xd88>
    4f4c:	91304021 	add	x1, x1, #0xc10
    4f50:	f90043e1 	str	x1, [sp, #128]
    4f54:	52800082 	mov	w2, #0x4                   	// #4
    4f58:	72a10002 	movk	w2, #0x800, lsl #16
    4f5c:	910203f7 	add	x23, sp, #0x80
    4f60:	3d802000 	str	q0, [x0, #128]
    4f64:	b9010be2 	str	w2, [sp, #264]
    4f68:	f9000bf7 	str	x23, [sp, #16]
    4f6c:	ad000000 	stp	q0, q0, [x0]
    4f70:	ad010000 	stp	q0, q0, [x0, #32]
    4f74:	ad020000 	stp	q0, q0, [x0, #64]
    4f78:	ad030000 	stp	q0, q0, [x0, #96]
    4f7c:	97fff151 	bl	14c0 <sigemptyset@plt>
    4f80:	3500a3a0 	cbnz	w0, 63f4 <fwp_main_thread+0x1540>
    4f84:	aa1703e1 	mov	x1, x23
    4f88:	d2800002 	mov	x2, #0x0                   	// #0
    4f8c:	52800160 	mov	w0, #0xb                   	// #11
    4f90:	97fff164 	bl	1520 <sigaction@plt>
    4f94:	3500a300 	cbnz	w0, 63f4 <fwp_main_thread+0x1540>
    4f98:	aa1703e1 	mov	x1, x23
    4f9c:	d2800002 	mov	x2, #0x0                   	// #0
    4fa0:	528000e0 	mov	w0, #0x7                   	// #7
    4fa4:	97fff15f 	bl	1520 <sigaction@plt>
    4fa8:	3500a260 	cbnz	w0, 63f4 <fwp_main_thread+0x1540>
    4fac:	91158298 	add	x24, x20, #0x560
    4fb0:	a9166bf9 	stp	x25, x26, [sp, #352]
    4fb4:	b0ffffe0 	adrp	x0, 1000 <__abi_tag+0xd88>
    4fb8:	52800039 	mov	w25, #0x1                   	// #1
    4fbc:	913c4000 	add	x0, x0, #0xf10
    4fc0:	fd4a1300 	ldr	d0, [x24, #5152]
    4fc4:	b9004379 	str	w25, [x27, #64]
    4fc8:	7e61d800 	ucvtf	d0, d0
    4fcc:	fd002f60 	str	d0, [x27, #88]
    4fd0:	940006d4 	bl	6b20 <atexit>
    4fd4:	3500a220 	cbnz	w0, 6418 <fwp_main_thread+0x1564>
    4fd8:	b942c760 	ldr	w0, [x27, #708]
    4fdc:	340020c0 	cbz	w0, 53f4 <fwp_main_thread+0x540>
    4fe0:	910202da 	add	x26, x22, #0x80
    4fe4:	f9400755 	ldr	x21, [x26, #8]
    4fe8:	b4000c35 	cbz	x21, 516c <fwp_main_thread+0x2b8>
    4fec:	aa1503f3 	mov	x19, x21
    4ff0:	910102b7 	add	x23, x21, #0x40
    4ff4:	39414ab9 	ldrb	w25, [x21, #82]
    4ff8:	52800038 	mov	w24, #0x1                   	// #1
    4ffc:	39014ab8 	strb	w24, [x21, #82]
    5000:	f94016a0 	ldr	x0, [x21, #40]
    5004:	b4000620 	cbz	x0, 50c8 <fwp_main_thread+0x214>
    5008:	f94032a1 	ldr	x1, [x21, #96]
    500c:	394146a0 	ldrb	w0, [x21, #81]
    5010:	b4000c81 	cbz	x1, 51a0 <fwp_main_thread+0x2ec>
    5014:	36000b40 	tbz	w0, #0, 517c <fwp_main_thread+0x2c8>
    5018:	39414a62 	ldrb	w2, [x19, #82]
    501c:	f94022a0 	ldr	x0, [x21, #64]
    5020:	37000ea2 	tbnz	w2, #0, 51f4 <fwp_main_thread+0x340>
    5024:	f9403261 	ldr	x1, [x19, #96]
    5028:	a911fe77 	stp	x23, xzr, [x19, #280]
    502c:	f9009660 	str	x0, [x19, #296]
    5030:	b4000040 	cbz	x0, 5038 <fwp_main_thread+0x184>
    5034:	f9009013 	str	x19, [x0, #288]
    5038:	f90022b3 	str	x19, [x21, #64]
    503c:	b4000101 	cbz	x1, 505c <fwp_main_thread+0x1a8>
    5040:	f9401f40 	ldr	x0, [x26, #56]
    5044:	39015678 	strb	w24, [x19, #85]
    5048:	f9003661 	str	x1, [x19, #104]
    504c:	a910827f 	stp	xzr, x0, [x19, #264]
    5050:	b4000040 	cbz	x0, 5058 <fwp_main_thread+0x1a4>
    5054:	f9008413 	str	x19, [x0, #264]
    5058:	f9001f53 	str	x19, [x26, #56]
    505c:	39015a7f 	strb	wzr, [x19, #86]
    5060:	97fffb55 	bl	3db4 <fwp_block>
    5064:	f9408e62 	ldr	x2, [x19, #280]
    5068:	b4000142 	cbz	x2, 5090 <fwp_main_thread+0x1dc>
    506c:	a9520261 	ldp	x1, x0, [x19, #288]
    5070:	b4000ce1 	cbz	x1, 520c <fwp_main_thread+0x358>
    5074:	f9009420 	str	x0, [x1, #296]
    5078:	f9409660 	ldr	x0, [x19, #296]
    507c:	b4000040 	cbz	x0, 5084 <fwp_main_thread+0x1d0>
    5080:	f9009001 	str	x1, [x0, #288]
    5084:	91080260 	add	x0, x19, #0x200
    5088:	f900967f 	str	xzr, [x19, #296]
    508c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    5090:	39415660 	ldrb	w0, [x19, #85]
    5094:	f9400742 	ldr	x2, [x26, #8]
    5098:	36000aa0 	tbz	w0, #0, 51ec <fwp_main_thread+0x338>
    509c:	a9508261 	ldp	x1, x0, [x19, #264]
    50a0:	b4000ba1 	cbz	x1, 5214 <fwp_main_thread+0x360>
    50a4:	f9008820 	str	x0, [x1, #272]
    50a8:	b4000040 	cbz	x0, 50b0 <fwp_main_thread+0x1fc>
    50ac:	f9008401 	str	x1, [x0, #264]
    50b0:	91080260 	add	x0, x19, #0x200
    50b4:	3901567f 	strb	wzr, [x19, #85]
    50b8:	aa0203f3 	mov	x19, x2
    50bc:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    50c0:	f94016a0 	ldr	x0, [x21, #40]
    50c4:	b5fffa20 	cbnz	x0, 5008 <fwp_main_thread+0x154>
    50c8:	910202c0 	add	x0, x22, #0x80
    50cc:	39014ab9 	strb	w25, [x21, #82]
    50d0:	f9415400 	ldr	x0, [x0, #680]
    50d4:	b5000080 	cbnz	x0, 50e4 <fwp_main_thread+0x230>
    50d8:	910202d5 	add	x21, x22, #0x80
    50dc:	f9415ea0 	ldr	x0, [x21, #696]
    50e0:	b4008720 	cbz	x0, 61c4 <fwp_main_thread+0x1310>
    50e4:	910202c0 	add	x0, x22, #0x80
    50e8:	f9417001 	ldr	x1, [x0, #736]
    50ec:	b902d81f 	str	wzr, [x0, #728]
    50f0:	eb13003f 	cmp	x1, x19
    50f4:	540087e1 	b.ne	61f0 <fwp_main_thread+0x133c>  // b.any
    50f8:	b40009d3 	cbz	x19, 5230 <fwp_main_thread+0x37c>
    50fc:	910202c0 	add	x0, x22, #0x80
    5100:	52800021 	mov	w1, #0x1                   	// #1
    5104:	39014a61 	strb	w1, [x19, #82]
    5108:	f9414005 	ldr	x5, [x0, #640]
    510c:	b4000925 	cbz	x5, 5230 <fwp_main_thread+0x37c>
    5110:	394140a0 	ldrb	w0, [x5, #80]
    5114:	37000060 	tbnz	w0, #0, 5120 <fwp_main_thread+0x26c>
    5118:	aa0503e0 	mov	x0, x5
    511c:	97fff415 	bl	2170 <fwp_cancel_tree.part.0>
    5120:	f9409ca5 	ldr	x5, [x5, #312]
    5124:	b5ffff65 	cbnz	x5, 5110 <fwp_main_thread+0x25c>
    5128:	910202d5 	add	x21, x22, #0x80
    512c:	52800037 	mov	w23, #0x1                   	// #1
    5130:	f9402a60 	ldr	x0, [x19, #80]
    5134:	f2001c1f 	tst	x0, #0xff000000ff
    5138:	540000e1 	b.ne	5154 <fwp_main_thread+0x2a0>  // b.any
    513c:	f94016a0 	ldr	x0, [x21, #40]
    5140:	39015277 	strb	w23, [x19, #84]
    5144:	f900827f 	str	xzr, [x19, #256]
    5148:	b40006a0 	cbz	x0, 521c <fwp_main_thread+0x368>
    514c:	f9008013 	str	x19, [x0, #256]
    5150:	f90016b3 	str	x19, [x21, #40]
    5154:	97fffb18 	bl	3db4 <fwp_block>
    5158:	97fffaaa 	bl	3c00 <fwp_free_zombie>
    515c:	f94142a0 	ldr	x0, [x21, #640]
    5160:	b4000680 	cbz	x0, 5230 <fwp_main_thread+0x37c>
    5164:	f94172b3 	ldr	x19, [x21, #736]
    5168:	17fffff2 	b	5130 <fwp_main_thread+0x27c>
    516c:	f9415740 	ldr	x0, [x26, #680]
    5170:	b50005a0 	cbnz	x0, 5224 <fwp_main_thread+0x370>
    5174:	d2800013 	mov	x19, #0x0                   	// #0
    5178:	17ffffd8 	b	50d8 <fwp_main_thread+0x224>
    517c:	97fff451 	bl	22c0 <fwp_now_ns>
    5180:	f94032a1 	ldr	x1, [x21, #96]
    5184:	eb01001f 	cmp	x0, x1
    5188:	540000ab 	b.lt	519c <fwp_main_thread+0x2e8>  // b.tstop
    518c:	394142a0 	ldrb	w0, [x21, #80]
    5190:	37000060 	tbnz	w0, #0, 519c <fwp_main_thread+0x2e8>
    5194:	aa1503e0 	mov	x0, x21
    5198:	97fff3f6 	bl	2170 <fwp_cancel_tree.part.0>
    519c:	394146a0 	ldrb	w0, [x21, #81]
    51a0:	39414a62 	ldrb	w2, [x19, #82]
    51a4:	3707f3c0 	tbnz	w0, #0, 501c <fwp_main_thread+0x168>
    51a8:	f94032a1 	ldr	x1, [x21, #96]
    51ac:	370001c2 	tbnz	w2, #0, 51e4 <fwp_main_thread+0x330>
    51b0:	f9403260 	ldr	x0, [x19, #96]
    51b4:	b4000180 	cbz	x0, 51e4 <fwp_main_thread+0x330>
    51b8:	b4000061 	cbz	x1, 51c4 <fwp_main_thread+0x310>
    51bc:	eb01001f 	cmp	x0, x1
    51c0:	9a81d000 	csel	x0, x0, x1, le
    51c4:	f94022a1 	ldr	x1, [x21, #64]
    51c8:	a911fe77 	stp	x23, xzr, [x19, #280]
    51cc:	f9009661 	str	x1, [x19, #296]
    51d0:	b4007e81 	cbz	x1, 61a0 <fwp_main_thread+0x12ec>
    51d4:	f9009033 	str	x19, [x1, #288]
    51d8:	aa0003e1 	mov	x1, x0
    51dc:	f90022b3 	str	x19, [x21, #64]
    51e0:	17ffff98 	b	5040 <fwp_main_thread+0x18c>
    51e4:	f94022a0 	ldr	x0, [x21, #64]
    51e8:	17ffff90 	b	5028 <fwp_main_thread+0x174>
    51ec:	aa0203f3 	mov	x19, x2
    51f0:	17ffff84 	b	5000 <fwp_main_thread+0x14c>
    51f4:	a911fe77 	stp	x23, xzr, [x19, #280]
    51f8:	f9009660 	str	x0, [x19, #296]
    51fc:	b4000040 	cbz	x0, 5204 <fwp_main_thread+0x350>
    5200:	f9009013 	str	x19, [x0, #288]
    5204:	f90022b3 	str	x19, [x21, #64]
    5208:	17ffff95 	b	505c <fwp_main_thread+0x1a8>
    520c:	f9000040 	str	x0, [x2]
    5210:	17ffff9b 	b	507c <fwp_main_thread+0x1c8>
    5214:	f9001f40 	str	x0, [x26, #56]
    5218:	17ffffa4 	b	50a8 <fwp_main_thread+0x1f4>
    521c:	f9001ab3 	str	x19, [x21, #48]
    5220:	17ffffcc 	b	5150 <fwp_main_thread+0x29c>
    5224:	f9417340 	ldr	x0, [x26, #736]
    5228:	b902db5f 	str	wzr, [x26, #728]
    522c:	b5007e20 	cbnz	x0, 61f0 <fwp_main_thread+0x133c>
    5230:	910202d5 	add	x21, x22, #0x80
    5234:	97fffa73 	bl	3c00 <fwp_free_zombie>
    5238:	f9401aa0 	ldr	x0, [x21, #48]
    523c:	b5007da0 	cbnz	x0, 61f0 <fwp_main_thread+0x133c>
    5240:	f9401ea0 	ldr	x0, [x21, #56]
    5244:	b5007d60 	cbnz	x0, 61f0 <fwp_main_thread+0x133c>
    5248:	b94072a0 	ldr	w0, [x21, #112]
    524c:	340001c0 	cbz	w0, 5284 <fwp_main_thread+0x3d0>
    5250:	93407c17 	sxtw	x23, w0
    5254:	51000400 	sub	w0, w0, #0x1
    5258:	d1000af7 	sub	x23, x23, #0x2
    525c:	910202b8 	add	x24, x21, #0x80
    5260:	cb2042f7 	sub	x23, x23, w0, uxtw
    5264:	93407c13 	sxtw	x19, w0
    5268:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    526c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    5270:	b90072b3 	str	w19, [x21, #112]
    5274:	d1000673 	sub	x19, x19, #0x1
    5278:	97fff0ea 	bl	1620 <munmap@plt>
    527c:	eb1302ff 	cmp	x23, x19
    5280:	54ffff41 	b.ne	5268 <fwp_main_thread+0x3b4>  // b.any
    5284:	f00000d3 	adrp	x19, 20000 <__data_start>
    5288:	91004260 	add	x0, x19, #0x10
    528c:	b9405000 	ldr	w0, [x0, #80]
    5290:	37f80040 	tbnz	w0, #31, 5298 <fwp_main_thread+0x3e4>
    5294:	97fff09f 	bl	1510 <close@plt>
    5298:	910202c0 	add	x0, x22, #0x80
    529c:	91004261 	add	x1, x19, #0x10
    52a0:	12800002 	mov	w2, #0xffffffff            	// #-1
    52a4:	d2800013 	mov	x19, #0x0                   	// #0
    52a8:	f9417417 	ldr	x23, [x0, #744]
    52ac:	b9005022 	str	w2, [x1, #80]
    52b0:	f9417815 	ldr	x21, [x0, #752]
    52b4:	b4000177 	cbz	x23, 52e0 <fwp_main_thread+0x42c>
    52b8:	f8737aa0 	ldr	x0, [x21, x19, lsl #3]
    52bc:	b40000c0 	cbz	x0, 52d4 <fwp_main_thread+0x420>
    52c0:	f9400001 	ldr	x1, [x0]
    52c4:	b5007961 	cbnz	x1, 61f0 <fwp_main_thread+0x133c>
    52c8:	f9400401 	ldr	x1, [x0, #8]
    52cc:	b5007921 	cbnz	x1, 61f0 <fwp_main_thread+0x133c>
    52d0:	97fff74c 	bl	3000 <fwp_mem_free>
    52d4:	91000673 	add	x19, x19, #0x1
    52d8:	eb1302ff 	cmp	x23, x19
    52dc:	54fffee1 	b.ne	52b8 <fwp_main_thread+0x404>  // b.any
    52e0:	aa1503e0 	mov	x0, x21
    52e4:	97fff747 	bl	3000 <fwp_mem_free>
    52e8:	910202c0 	add	x0, x22, #0x80
    52ec:	f9417013 	ldr	x19, [x0, #736]
    52f0:	f901741f 	str	xzr, [x0, #744]
    52f4:	f901781f 	str	xzr, [x0, #752]
    52f8:	b40001f3 	cbz	x19, 5334 <fwp_main_thread+0x480>
    52fc:	f9401661 	ldr	x1, [x19, #40]
    5300:	b5007781 	cbnz	x1, 61f0 <fwp_main_thread+0x133c>
    5304:	f9405661 	ldr	x1, [x19, #168]
    5308:	b5007741 	cbnz	x1, 61f0 <fwp_main_thread+0x133c>
    530c:	f9415401 	ldr	x1, [x0, #680]
    5310:	b5007701 	cbnz	x1, 61f0 <fwp_main_thread+0x133c>
    5314:	f9415c00 	ldr	x0, [x0, #696]
    5318:	b50076c0 	cbnz	x0, 61f0 <fwp_main_thread+0x133c>
    531c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    5320:	f0000140 	adrp	x0, 30000 <alt.4+0xfc80>
    5324:	910e0000 	add	x0, x0, #0x380
    5328:	97fff06a 	bl	14d0 <memset@plt>
    532c:	aa1303e0 	mov	x0, x19
    5330:	97fff734 	bl	3000 <fwp_mem_free>
    5334:	91158294 	add	x20, x20, #0x560
    5338:	910202d6 	add	x22, x22, #0x80
    533c:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    5340:	f947e800 	ldr	x0, [x0, #4048]
    5344:	52800041 	mov	w1, #0x2                   	// #2
    5348:	fd4a1280 	ldr	d0, [x20, #5152]
    534c:	d0000002 	adrp	x2, 7000 <_IO_stdin_used+0x4b0>
    5350:	fd402ec1 	ldr	d1, [x22, #88]
    5354:	91004042 	add	x2, x2, #0x10
    5358:	a94492c3 	ldp	x3, x4, [x22, #72]
    535c:	7e61d800 	ucvtf	d0, d0
    5360:	f9400000 	ldr	x0, [x0]
    5364:	f90006df 	str	xzr, [x22, #8]
    5368:	f94166c5 	ldr	x5, [x22, #712]
    536c:	1e613801 	fsub	d1, d0, d1
    5370:	fd4032c0 	ldr	d0, [x22, #96]
    5374:	f90012df 	str	xzr, [x22, #32]
    5378:	b90042df 	str	wzr, [x22, #64]
    537c:	f90172df 	str	xzr, [x22, #736]
    5380:	97fff07c 	bl	1570 <__fprintf_chk@plt>
    5384:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    5388:	f947ec00 	ldr	x0, [x0, #4056]
    538c:	f9400000 	ldr	x0, [x0]
    5390:	97fff0a8 	bl	1630 <fflush@plt>
    5394:	d00000c0 	adrp	x0, 1f000 <__FRAME_END__+0x170f8>
    5398:	f947f400 	ldr	x0, [x0, #4072]
    539c:	f9408fe2 	ldr	x2, [sp, #280]
    53a0:	f9400001 	ldr	x1, [x0]
    53a4:	eb010042 	subs	x2, x2, x1
    53a8:	d2800001 	mov	x1, #0x0                   	// #0
    53ac:	54008301 	b.ne	640c <fwp_main_thread+0x1558>  // b.any
    53b0:	a9527bfd 	ldp	x29, x30, [sp, #288]
    53b4:	d2800000 	mov	x0, #0x0                   	// #0
    53b8:	a95353f3 	ldp	x19, x20, [sp, #304]
    53bc:	a9545bf5 	ldp	x21, x22, [sp, #320]
    53c0:	a95563f7 	ldp	x23, x24, [sp, #336]
    53c4:	a9566bf9 	ldp	x25, x26, [sp, #352]
    53c8:	a95773fb 	ldp	x27, x28, [sp, #368]
    53cc:	910683ff 	add	sp, sp, #0x1a0
    53d0:	d65f03c0 	ret
    53d4:	97fff53f 	bl	28d0 <fwp_heap_init>
    53d8:	91158280 	add	x0, x20, #0x560
    53dc:	b953a800 	ldr	w0, [x0, #5032]
    53e0:	34ffd8e0 	cbz	w0, 4efc <fwp_main_thread+0x48>
    53e4:	b0ffffe0 	adrp	x0, 2000 <ad_raw_report+0xf0>
    53e8:	911d9000 	add	x0, x0, #0x764
    53ec:	940005cd 	bl	6b20 <atexit>
    53f0:	17fffec3 	b	4efc <fwp_main_thread+0x48>
    53f4:	f9414b62 	ldr	x2, [x27, #656]
    53f8:	6d1827e8 	stp	d8, d9, [sp, #384]
    53fc:	d0ffffe0 	adrp	x0, 3000 <fwp_mem_free>
    5400:	fd00cbea 	str	d10, [sp, #400]
    5404:	91218000 	add	x0, x0, #0x860
    5408:	90ffffe1 	adrp	x1, 1000 <__abi_tag+0xd88>
    540c:	d2800017 	mov	x23, #0x0                   	// #0
    5410:	912e4021 	add	x1, x1, #0xb90
    5414:	d280401a 	mov	x26, #0x200                 	// #512
    5418:	390063f9 	strb	w25, [sp, #24]
    541c:	d2800019 	mov	x25, #0x0                   	// #0
    5420:	a90287e2 	stp	x2, x1, [sp, #40]
    5424:	a903fff3 	stp	x19, xzr, [sp, #56]
    5428:	a90503ff 	stp	xzr, x0, [sp, #80]
    542c:	f9014b75 	str	x21, [x27, #656]
    5430:	14000012 	b	5478 <fwp_main_thread+0x5c4>
    5434:	7100045f 	cmp	w2, #0x1
    5438:	540001a1 	b.ne	546c <fwp_main_thread+0x5b8>  // b.any
    543c:	29430002 	ldp	w2, w0, [x0, #24]
    5440:	92403c21 	and	x1, x1, #0xffff
    5444:	9b027c21 	mul	x1, x1, x2
    5448:	d360fc21 	lsr	x1, x1, #32
    544c:	eb00003f 	cmp	x1, x0
    5450:	540000e2 	b.cs	546c <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    5454:	8b01039c 	add	x28, x28, x1
    5458:	39400380 	ldrb	w0, [x28]
    545c:	7103fc1f 	cmp	w0, #0xff
    5460:	54006960 	b.eq	618c <fwp_main_thread+0x12d8>  // b.none
    5464:	394063e0 	ldrb	w0, [sp, #24]
    5468:	39000380 	strb	w0, [x28]
    546c:	f90023f7 	str	x23, [sp, #64]
    5470:	aa04037b 	orr	x27, x27, x4
    5474:	b400041b 	cbz	x27, 54f4 <fwp_main_thread+0x640>
    5478:	f9400be0 	ldr	x0, [sp, #16]
    547c:	f100075b 	subs	x27, x26, #0x1
    5480:	da1f0324 	sbc	x4, x25, xzr
    5484:	f90007e4 	str	x4, [sp, #8]
    5488:	aa0403f9 	mov	x25, x4
    548c:	f90027fb 	str	x27, [sp, #72]
    5490:	a9085ffb 	stp	x27, x23, [sp, #128]
    5494:	aa1b03fa 	mov	x26, x27
    5498:	97fff87e 	bl	3690 <fwp_data.part.0.constprop.0>
    549c:	f949db01 	ldr	x1, [x24, #5040]
    54a0:	aa0003f7 	mov	x23, x0
    54a4:	f949ef00 	ldr	x0, [x24, #5080]
    54a8:	cb0102e1 	sub	x1, x23, x1
    54ac:	f94007e4 	ldr	x4, [sp, #8]
    54b0:	eb00403f 	cmp	x1, x0, lsl #16
    54b4:	54fffdc2 	b.cs	546c <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    54b8:	d350fc20 	lsr	x0, x1, #16
    54bc:	f949ff05 	ldr	x5, [x24, #5112]
    54c0:	8b000800 	add	x0, x0, x0, lsl #2
    54c4:	d37df002 	lsl	x2, x0, #3
    54c8:	8b0200a0 	add	x0, x5, x2
    54cc:	f940101c 	ldr	x28, [x0, #32]
    54d0:	b4fffcfc 	cbz	x28, 546c <fwp_main_thread+0x5b8>
    54d4:	386268a2 	ldrb	w2, [x5, x2]
    54d8:	7100085f 	cmp	w2, #0x2
    54dc:	54fffac1 	b.ne	5434 <fwp_main_thread+0x580>  // b.any
    54e0:	72003c3f 	tst	w1, #0xffff
    54e4:	54fffba0 	b.eq	5458 <fwp_main_thread+0x5a4>  // b.none
    54e8:	f90023f7 	str	x23, [sp, #64]
    54ec:	aa04037b 	orr	x27, x27, x4
    54f0:	b5fffc5b 	cbnz	x27, 5478 <fwp_main_thread+0x5c4>
    54f4:	d0000000 	adrp	x0, 7000 <_IO_stdin_used+0x4b0>
    54f8:	910202c1 	add	x1, x22, #0x80
    54fc:	f94017e2 	ldr	x2, [sp, #40]
    5500:	3dc09000 	ldr	q0, [x0, #576]
    5504:	910183e0 	add	x0, sp, #0x60
    5508:	f9014822 	str	x2, [x1, #656]
    550c:	3d801be0 	str	q0, [sp, #96]
    5510:	97fff860 	bl	3690 <fwp_data.part.0.constprop.0>
    5514:	91158283 	add	x3, x20, #0x560
    5518:	aa0003f9 	mov	x25, x0
    551c:	f949d862 	ldr	x2, [x3, #5040]
    5520:	f949ec60 	ldr	x0, [x3, #5080]
    5524:	cb020322 	sub	x2, x25, x2
    5528:	eb00405f 	cmp	x2, x0, lsl #16
    552c:	54000322 	b.cs	5590 <fwp_main_thread+0x6dc>  // b.hs, b.nlast
    5530:	d350fc41 	lsr	x1, x2, #16
    5534:	f949fc63 	ldr	x3, [x3, #5112]
    5538:	8b010821 	add	x1, x1, x1, lsl #2
    553c:	d37df021 	lsl	x1, x1, #3
    5540:	8b010060 	add	x0, x3, x1
    5544:	f940101a 	ldr	x26, [x0, #32]
    5548:	b400025a 	cbz	x26, 5590 <fwp_main_thread+0x6dc>
    554c:	38616861 	ldrb	w1, [x3, x1]
    5550:	7100083f 	cmp	w1, #0x2
    5554:	54006160 	b.eq	6180 <fwp_main_thread+0x12cc>  // b.none
    5558:	7100043f 	cmp	w1, #0x1
    555c:	540001a1 	b.ne	5590 <fwp_main_thread+0x6dc>  // b.any
    5560:	29430003 	ldp	w3, w0, [x0, #24]
    5564:	92403c41 	and	x1, x2, #0xffff
    5568:	9b037c21 	mul	x1, x1, x3
    556c:	d360fc21 	lsr	x1, x1, #32
    5570:	eb00003f 	cmp	x1, x0
    5574:	540000e2 	b.cs	5590 <fwp_main_thread+0x6dc>  // b.hs, b.nlast
    5578:	8b01035a 	add	x26, x26, x1
    557c:	39400340 	ldrb	w0, [x26]
    5580:	7103fc1f 	cmp	w0, #0xff
    5584:	54006ea0 	b.eq	6358 <fwp_main_thread+0x14a4>  // b.none
    5588:	52800020 	mov	w0, #0x1                   	// #1
    558c:	39000340 	strb	w0, [x26]
    5590:	f9400be0 	ldr	x0, [sp, #16]
    5594:	d2e7fe01 	mov	x1, #0x3ff0000000000000    	// #4607182418800017408
    5598:	a90867e1 	stp	x1, x25, [sp, #128]
    559c:	97fff83d 	bl	3690 <fwp_data.part.0.constprop.0>
    55a0:	aa0003f8 	mov	x24, x0
    55a4:	91158283 	add	x3, x20, #0x560
    55a8:	f949d862 	ldr	x2, [x3, #5040]
    55ac:	f949ec60 	ldr	x0, [x3, #5080]
    55b0:	cb020302 	sub	x2, x24, x2
    55b4:	eb00405f 	cmp	x2, x0, lsl #16
    55b8:	54000322 	b.cs	561c <fwp_main_thread+0x768>  // b.hs, b.nlast
    55bc:	d350fc41 	lsr	x1, x2, #16
    55c0:	f949fc63 	ldr	x3, [x3, #5112]
    55c4:	8b010821 	add	x1, x1, x1, lsl #2
    55c8:	d37df021 	lsl	x1, x1, #3
    55cc:	8b010060 	add	x0, x3, x1
    55d0:	f9401019 	ldr	x25, [x0, #32]
    55d4:	b4000259 	cbz	x25, 561c <fwp_main_thread+0x768>
    55d8:	38616861 	ldrb	w1, [x3, x1]
    55dc:	7100083f 	cmp	w1, #0x2
    55e0:	54005ca0 	b.eq	6174 <fwp_main_thread+0x12c0>  // b.none
    55e4:	7100043f 	cmp	w1, #0x1
    55e8:	540001a1 	b.ne	561c <fwp_main_thread+0x768>  // b.any
    55ec:	29430003 	ldp	w3, w0, [x0, #24]
    55f0:	92403c41 	and	x1, x2, #0xffff
    55f4:	9b037c21 	mul	x1, x1, x3
    55f8:	d360fc21 	lsr	x1, x1, #32
    55fc:	eb00003f 	cmp	x1, x0
    5600:	540000e2 	b.cs	561c <fwp_main_thread+0x768>  // b.hs, b.nlast
    5604:	8b010339 	add	x25, x25, x1
    5608:	39400320 	ldrb	w0, [x25]
    560c:	7103fc1f 	cmp	w0, #0xff
    5610:	54006980 	b.eq	6340 <fwp_main_thread+0x148c>  // b.none
    5614:	52800020 	mov	w0, #0x1                   	// #1
    5618:	39000320 	strb	w0, [x25]
    561c:	b200e7e1 	mov	x1, #0x3333333333333333    	// #3689348814741910323
    5620:	9101c3e0 	add	x0, sp, #0x70
    5624:	f2f7fe61 	movk	x1, #0xbff3, lsl #48
    5628:	a90763e1 	stp	x1, x24, [sp, #112]
    562c:	97fff819 	bl	3690 <fwp_data.part.0.constprop.0>
    5630:	aa0003e3 	mov	x3, x0
    5634:	91158281 	add	x1, x20, #0x560
    5638:	f90007e3 	str	x3, [sp, #8]
    563c:	f949d822 	ldr	x2, [x1, #5040]
    5640:	f949ec20 	ldr	x0, [x1, #5080]
    5644:	cb020062 	sub	x2, x3, x2
    5648:	eb00405f 	cmp	x2, x0, lsl #16
    564c:	54000322 	b.cs	56b0 <fwp_main_thread+0x7fc>  // b.hs, b.nlast
    5650:	d350fc40 	lsr	x0, x2, #16
    5654:	f949fc23 	ldr	x3, [x1, #5112]
    5658:	8b000800 	add	x0, x0, x0, lsl #2
    565c:	d37df001 	lsl	x1, x0, #3
    5660:	8b010060 	add	x0, x3, x1
    5664:	f9401019 	ldr	x25, [x0, #32]
    5668:	b4000259 	cbz	x25, 56b0 <fwp_main_thread+0x7fc>
    566c:	38616861 	ldrb	w1, [x3, x1]
    5670:	7100083f 	cmp	w1, #0x2
    5674:	540057a0 	b.eq	6168 <fwp_main_thread+0x12b4>  // b.none
    5678:	7100043f 	cmp	w1, #0x1
    567c:	540001a1 	b.ne	56b0 <fwp_main_thread+0x7fc>  // b.any
    5680:	29430003 	ldp	w3, w0, [x0, #24]
    5684:	92403c41 	and	x1, x2, #0xffff
    5688:	9b037c21 	mul	x1, x1, x3
    568c:	d360fc21 	lsr	x1, x1, #32
    5690:	eb00003f 	cmp	x1, x0
    5694:	540000e2 	b.cs	56b0 <fwp_main_thread+0x7fc>  // b.hs, b.nlast
    5698:	8b010339 	add	x25, x25, x1
    569c:	39400320 	ldrb	w0, [x25]
    56a0:	7103fc1f 	cmp	w0, #0xff
    56a4:	54006540 	b.eq	634c <fwp_main_thread+0x1498>  // b.none
    56a8:	52800020 	mov	w0, #0x1                   	// #1
    56ac:	39000320 	strb	w0, [x25]
    56b0:	f9000bf7 	str	x23, [sp, #16]
    56b4:	b4003e37 	cbz	x23, 5e78 <fwp_main_thread+0xfc4>
    56b8:	d2e80d20 	mov	x0, #0x4069000000000000    	// #4641240890982006784
    56bc:	9e670008 	fmov	d8, x0
    56c0:	d0000000 	adrp	x0, 7000 <_IO_stdin_used+0x4b0>
    56c4:	d2f80f21 	mov	x1, #0xc079000000000000    	// #-4577627546245398528
    56c8:	9e67002a 	fmov	d10, x1
    56cc:	fd412809 	ldr	d9, [x0, #592]
    56d0:	91158282 	add	x2, x20, #0x560
    56d4:	f94007e3 	ldr	x3, [sp, #8]
    56d8:	f949d840 	ldr	x0, [x2, #5040]
    56dc:	f949ec41 	ldr	x1, [x2, #5080]
    56e0:	cb000060 	sub	x0, x3, x0
    56e4:	eb01401f 	cmp	x0, x1, lsl #16
    56e8:	54000402 	b.cs	5768 <fwp_main_thread+0x8b4>  // b.hs, b.nlast
    56ec:	d350fc01 	lsr	x1, x0, #16
    56f0:	f949fc43 	ldr	x3, [x2, #5112]
    56f4:	8b010821 	add	x1, x1, x1, lsl #2
    56f8:	d37df021 	lsl	x1, x1, #3
    56fc:	8b010062 	add	x2, x3, x1
    5700:	f940105a 	ldr	x26, [x2, #32]
    5704:	b400033a 	cbz	x26, 5768 <fwp_main_thread+0x8b4>
    5708:	38616861 	ldrb	w1, [x3, x1]
    570c:	7100083f 	cmp	w1, #0x2
    5710:	54004be0 	b.eq	608c <fwp_main_thread+0x11d8>  // b.none
    5714:	7100043f 	cmp	w1, #0x1
    5718:	54000281 	b.ne	5768 <fwp_main_thread+0x8b4>  // b.any
    571c:	29430443 	ldp	w3, w1, [x2, #24]
    5720:	92403c00 	and	x0, x0, #0xffff
    5724:	9b037c00 	mul	x0, x0, x3
    5728:	d360fc00 	lsr	x0, x0, #32
    572c:	eb01001f 	cmp	x0, x1
    5730:	540001c2 	b.cs	5768 <fwp_main_thread+0x8b4>  // b.hs, b.nlast
    5734:	8b00035a 	add	x26, x26, x0
    5738:	39400340 	ldrb	w0, [x26]
    573c:	34000160 	cbz	w0, 5768 <fwp_main_thread+0x8b4>
    5740:	910202c1 	add	x1, x22, #0x80
    5744:	b9404022 	ldr	w2, [x1, #64]
    5748:	34000082 	cbz	w2, 5758 <fwp_main_thread+0x8a4>
    574c:	f9416422 	ldr	x2, [x1, #712]
    5750:	91000442 	add	x2, x2, #0x1
    5754:	f9016422 	str	x2, [x1, #712]
    5758:	7103f41f 	cmp	w0, #0xfd
    575c:	540057c8 	b.hi	6254 <fwp_main_thread+0x13a0>  // b.pmore
    5760:	11000400 	add	w0, w0, #0x1
    5764:	39000340 	strb	w0, [x26]
    5768:	f94007e0 	ldr	x0, [sp, #8]
    576c:	b4004980 	cbz	x0, 609c <fwp_main_thread+0x11e8>
    5770:	aa0003e1 	mov	x1, x0
    5774:	d2800000 	mov	x0, #0x0                   	// #0
    5778:	f9400821 	ldr	x1, [x1, #16]
    577c:	91000400 	add	x0, x0, #0x1
    5780:	b5ffffc1 	cbnz	x1, 5778 <fwp_main_thread+0x8c4>
    5784:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    5788:	eb01001f 	cmp	x0, x1
    578c:	54006108 	b.hi	63ac <fwp_main_thread+0x14f8>  // b.pmore
    5790:	97fff820 	bl	3810 <fwp_array_new_packed.constprop.0>
    5794:	aa0003fa 	mov	x26, x0
    5798:	91158281 	add	x1, x20, #0x560
    579c:	aa0103e0 	mov	x0, x1
    57a0:	f949d821 	ldr	x1, [x1, #5040]
    57a4:	f949ec00 	ldr	x0, [x0, #5080]
    57a8:	cb010341 	sub	x1, x26, x1
    57ac:	eb00403f 	cmp	x1, x0, lsl #16
    57b0:	54000382 	b.cs	5820 <fwp_main_thread+0x96c>  // b.hs, b.nlast
    57b4:	91158282 	add	x2, x20, #0x560
    57b8:	d350fc20 	lsr	x0, x1, #16
    57bc:	8b000800 	add	x0, x0, x0, lsl #2
    57c0:	f949fc43 	ldr	x3, [x2, #5112]
    57c4:	d37df002 	lsl	x2, x0, #3
    57c8:	8b020060 	add	x0, x3, x2
    57cc:	f940101b 	ldr	x27, [x0, #32]
    57d0:	b400025b 	cbz	x27, 5818 <fwp_main_thread+0x964>
    57d4:	38626862 	ldrb	w2, [x3, x2]
    57d8:	7100085f 	cmp	w2, #0x2
    57dc:	54004780 	b.eq	60cc <fwp_main_thread+0x1218>  // b.none
    57e0:	7100045f 	cmp	w2, #0x1
    57e4:	540001a1 	b.ne	5818 <fwp_main_thread+0x964>  // b.any
    57e8:	29430002 	ldp	w2, w0, [x0, #24]
    57ec:	92403c21 	and	x1, x1, #0xffff
    57f0:	9b027c21 	mul	x1, x1, x2
    57f4:	d360fc21 	lsr	x1, x1, #32
    57f8:	eb00003f 	cmp	x1, x0
    57fc:	540000e2 	b.cs	5818 <fwp_main_thread+0x964>  // b.hs, b.nlast
    5800:	8b01037b 	add	x27, x27, x1
    5804:	39400360 	ldrb	w0, [x27]
    5808:	7103fc1f 	cmp	w0, #0xff
    580c:	54004d00 	b.eq	61ac <fwp_main_thread+0x12f8>  // b.none
    5810:	52800020 	mov	w0, #0x1                   	// #1
    5814:	39000360 	strb	w0, [x27]
    5818:	f94007e0 	ldr	x0, [sp, #8]
    581c:	b4004540 	cbz	x0, 60c4 <fwp_main_thread+0x1210>
    5820:	f94007fb 	ldr	x27, [sp, #8]
    5824:	9100235c 	add	x28, x26, #0x8
    5828:	91158299 	add	x25, x20, #0x560
    582c:	52800038 	mov	w24, #0x1                   	// #1
    5830:	aa1b03e0 	mov	x0, x27
    5834:	14000013 	b	5880 <fwp_main_thread+0x9cc>
    5838:	7100045f 	cmp	w2, #0x1
    583c:	54000161 	b.ne	5868 <fwp_main_thread+0x9b4>  // b.any
    5840:	2943092a 	ldp	w10, w2, [x9, #24]
    5844:	92403c21 	and	x1, x1, #0xffff
    5848:	9b0a7c21 	mul	x1, x1, x10
    584c:	d360fc21 	lsr	x1, x1, #32
    5850:	eb02003f 	cmp	x1, x2
    5854:	540000a2 	b.cs	5868 <fwp_main_thread+0x9b4>  // b.hs, b.nlast
    5858:	8b010108 	add	x8, x8, x1
    585c:	39400101 	ldrb	w1, [x8]
    5860:	7100043f 	cmp	w1, #0x1
    5864:	540003e0 	b.eq	58e0 <fwp_main_thread+0xa2c>  // b.none
    5868:	f9400341 	ldr	x1, [x26]
    586c:	b7f85541 	tbnz	x1, #63, 6314 <fwp_main_thread+0x1460>
    5870:	f9000386 	str	x6, [x28]
    5874:	52800018 	mov	w24, #0x0                   	// #0
    5878:	9100239c 	add	x28, x28, #0x8
    587c:	b400077b 	cbz	x27, 5968 <fwp_main_thread+0xab4>
    5880:	aa1b03e7 	mov	x7, x27
    5884:	aa1b03e3 	mov	x3, x27
    5888:	a940ef66 	ldp	x6, x27, [x27, #8]
    588c:	34fffef8 	cbz	w24, 5868 <fwp_main_thread+0x9b4>
    5890:	f949db21 	ldr	x1, [x25, #5040]
    5894:	f949ef22 	ldr	x2, [x25, #5080]
    5898:	cb0100e1 	sub	x1, x7, x1
    589c:	eb02403f 	cmp	x1, x2, lsl #16
    58a0:	54fffe42 	b.cs	5868 <fwp_main_thread+0x9b4>  // b.hs, b.nlast
    58a4:	d350fc22 	lsr	x2, x1, #16
    58a8:	f949ff2a 	ldr	x10, [x25, #5112]
    58ac:	8b020842 	add	x2, x2, x2, lsl #2
    58b0:	d37df042 	lsl	x2, x2, #3
    58b4:	8b020149 	add	x9, x10, x2
    58b8:	f9401128 	ldr	x8, [x9, #32]
    58bc:	b4fffd68 	cbz	x8, 5868 <fwp_main_thread+0x9b4>
    58c0:	38626942 	ldrb	w2, [x10, x2]
    58c4:	7100085f 	cmp	w2, #0x2
    58c8:	54fffb81 	b.ne	5838 <fwp_main_thread+0x984>  // b.any
    58cc:	72003c3f 	tst	w1, #0xffff
    58d0:	54fffcc1 	b.ne	5868 <fwp_main_thread+0x9b4>  // b.any
    58d4:	39400101 	ldrb	w1, [x8]
    58d8:	7100043f 	cmp	w1, #0x1
    58dc:	54fffc61 	b.ne	5868 <fwp_main_thread+0x9b4>  // b.any
    58e0:	f9400340 	ldr	x0, [x26]
    58e4:	b7f85180 	tbnz	x0, #63, 6314 <fwp_main_thread+0x1460>
    58e8:	f9000386 	str	x6, [x28]
    58ec:	f949db21 	ldr	x1, [x25, #5040]
    58f0:	f949ef20 	ldr	x0, [x25, #5080]
    58f4:	cb010063 	sub	x3, x3, x1
    58f8:	eb00407f 	cmp	x3, x0, lsl #16
    58fc:	540002e2 	b.cs	5958 <fwp_main_thread+0xaa4>  // b.hs, b.nlast
    5900:	d350fc60 	lsr	x0, x3, #16
    5904:	f949ff21 	ldr	x1, [x25, #5112]
    5908:	8b000800 	add	x0, x0, x0, lsl #2
    590c:	d37df000 	lsl	x0, x0, #3
    5910:	8b000026 	add	x6, x1, x0
    5914:	f94010c2 	ldr	x2, [x6, #32]
    5918:	b4000202 	cbz	x2, 5958 <fwp_main_thread+0xaa4>
    591c:	38606820 	ldrb	w0, [x1, x0]
    5920:	7100081f 	cmp	w0, #0x2
    5924:	540038c0 	b.eq	603c <fwp_main_thread+0x1188>  // b.none
    5928:	7100041f 	cmp	w0, #0x1
    592c:	54000161 	b.ne	5958 <fwp_main_thread+0xaa4>  // b.any
    5930:	294300c8 	ldp	w8, w0, [x6, #24]
    5934:	92403c61 	and	x1, x3, #0xffff
    5938:	9b087c21 	mul	x1, x1, x8
    593c:	d360fc21 	lsr	x1, x1, #32
    5940:	eb00003f 	cmp	x1, x0
    5944:	540000a2 	b.cs	5958 <fwp_main_thread+0xaa4>  // b.hs, b.nlast
    5948:	8b010042 	add	x2, x2, x1
    594c:	39400040 	ldrb	w0, [x2]
    5950:	7100041f 	cmp	w0, #0x1
    5954:	54000e00 	b.eq	5b14 <fwp_main_thread+0xc60>  // b.none
    5958:	aa1b03e0 	mov	x0, x27
    595c:	d503201f 	nop
    5960:	9100239c 	add	x28, x28, #0x8
    5964:	b5fff8fb 	cbnz	x27, 5880 <fwp_main_thread+0x9cc>
    5968:	97fff812 	bl	39b0 <fwp_drop0>
    596c:	f940035b 	ldr	x27, [x26]
    5970:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    5974:	9240fb7b 	and	x27, x27, #0x7fffffffffffffff
    5978:	eb00037f 	cmp	x27, x0
    597c:	54005188 	b.hi	63ac <fwp_main_thread+0x14f8>  // b.pmore
    5980:	aa1b03e0 	mov	x0, x27
    5984:	97fff7a3 	bl	3810 <fwp_array_new_packed.constprop.0>
    5988:	91158282 	add	x2, x20, #0x560
    598c:	aa0003f9 	mov	x25, x0
    5990:	f949d841 	ldr	x1, [x2, #5040]
    5994:	f949ec40 	ldr	x0, [x2, #5080]
    5998:	cb010321 	sub	x1, x25, x1
    599c:	eb00403f 	cmp	x1, x0, lsl #16
    59a0:	54000322 	b.cs	5a04 <fwp_main_thread+0xb50>  // b.hs, b.nlast
    59a4:	d350fc20 	lsr	x0, x1, #16
    59a8:	f949fc44 	ldr	x4, [x2, #5112]
    59ac:	8b000800 	add	x0, x0, x0, lsl #2
    59b0:	d37df002 	lsl	x2, x0, #3
    59b4:	8b020080 	add	x0, x4, x2
    59b8:	f940101c 	ldr	x28, [x0, #32]
    59bc:	b400025c 	cbz	x28, 5a04 <fwp_main_thread+0xb50>
    59c0:	38626882 	ldrb	w2, [x4, x2]
    59c4:	7100085f 	cmp	w2, #0x2
    59c8:	54002e40 	b.eq	5f90 <fwp_main_thread+0x10dc>  // b.none
    59cc:	7100045f 	cmp	w2, #0x1
    59d0:	540001a1 	b.ne	5a04 <fwp_main_thread+0xb50>  // b.any
    59d4:	29430002 	ldp	w2, w0, [x0, #24]
    59d8:	92403c21 	and	x1, x1, #0xffff
    59dc:	9b027c21 	mul	x1, x1, x2
    59e0:	d360fc21 	lsr	x1, x1, #32
    59e4:	eb00003f 	cmp	x1, x0
    59e8:	540000e2 	b.cs	5a04 <fwp_main_thread+0xb50>  // b.hs, b.nlast
    59ec:	8b01039c 	add	x28, x28, x1
    59f0:	39400380 	ldrb	w0, [x28]
    59f4:	7103fc1f 	cmp	w0, #0xff
    59f8:	54002d60 	b.eq	5fa4 <fwp_main_thread+0x10f0>  // b.none
    59fc:	52800020 	mov	w0, #0x1                   	// #1
    5a00:	39000380 	strb	w0, [x28]
    5a04:	b400091b 	cbz	x27, 5b24 <fwp_main_thread+0xc70>
    5a08:	aa1a03e9 	mov	x9, x26
    5a0c:	d2800004 	mov	x4, #0x0                   	// #0
    5a10:	d2800002 	mov	x2, #0x0                   	// #0
    5a14:	d2800025 	mov	x5, #0x1                   	// #1
    5a18:	9e6703e1 	fmov	d1, xzr
    5a1c:	1e6e1005 	fmov	d5, #1.000000000000000000e+00
    5a20:	f8408527 	ldr	x7, [x9], #8
    5a24:	9240f8e1 	and	x1, x7, #0x7fffffffffffffff
    5a28:	aa0903e8 	mov	x8, x9
    5a2c:	eb0100bf 	cmp	x5, x1
    5a30:	54000660 	b.eq	5afc <fwp_main_thread+0xc48>  // b.none
    5a34:	d503201f 	nop
    5a38:	eb01009f 	cmp	x4, x1
    5a3c:	54000642 	b.cs	5b04 <fwp_main_thread+0xc50>  // b.hs, b.nlast
    5a40:	b7f82767 	tbnz	x7, #63, 5f2c <fwp_main_thread+0x1078>
    5a44:	fd400102 	ldr	d2, [x8]
    5a48:	aa0903e6 	mov	x6, x9
    5a4c:	1e6238a3 	fsub	d3, d5, d2
    5a50:	1e6a0844 	fmul	d4, d2, d10
    5a54:	1e632863 	fadd	d3, d3, d3
    5a58:	1e620842 	fmul	d2, d2, d2
    5a5c:	eb0100bf 	cmp	x5, x1
    5a60:	54000522 	b.cs	5b04 <fwp_main_thread+0xc50>  // b.hs, b.nlast
    5a64:	8b0200c1 	add	x1, x6, x2
    5a68:	fd400420 	ldr	d0, [x1, #8]
    5a6c:	1e623800 	fsub	d0, d0, d2
    5a70:	1e640800 	fmul	d0, d0, d4
    5a74:	1e633800 	fsub	d0, d0, d3
    5a78:	1e612800 	fadd	d0, d0, d1
    5a7c:	1e690800 	fmul	d0, d0, d9
    5a80:	aa0903e0 	mov	x0, x9
    5a84:	b7f82507 	tbnz	x7, #63, 5f24 <fwp_main_thread+0x1070>
    5a88:	fc626801 	ldr	d1, [x0, x2]
    5a8c:	f9400320 	ldr	x0, [x25]
    5a90:	1e603821 	fsub	d1, d1, d0
    5a94:	b7f84400 	tbnz	x0, #63, 6314 <fwp_main_thread+0x1460>
    5a98:	8b190041 	add	x1, x2, x25
    5a9c:	91000486 	add	x6, x4, #0x1
    5aa0:	fd000421 	str	d1, [x1, #8]
    5aa4:	eb06037f 	cmp	x27, x6
    5aa8:	540003e0 	b.eq	5b24 <fwp_main_thread+0xc70>  // b.none
    5aac:	f9400347 	ldr	x7, [x26]
    5ab0:	9240f8e1 	and	x1, x7, #0x7fffffffffffffff
    5ab4:	eb04003f 	cmp	x1, x4
    5ab8:	54000269 	b.ls	5b04 <fwp_main_thread+0xc50>  // b.plast
    5abc:	91002040 	add	x0, x2, #0x8
    5ac0:	b7f82407 	tbnz	x7, #63, 5f40 <fwp_main_thread+0x108c>
    5ac4:	fc606b40 	ldr	d0, [x26, x0]
    5ac8:	aa0903e4 	mov	x4, x9
    5acc:	1e600800 	fmul	d0, d0, d0
    5ad0:	eb0100df 	cmp	x6, x1
    5ad4:	54000182 	b.cs	5b04 <fwp_main_thread+0xc50>  // b.hs, b.nlast
    5ad8:	fc606881 	ldr	d1, [x4, x0]
    5adc:	910004a5 	add	x5, x5, #0x1
    5ae0:	91002108 	add	x8, x8, #0x8
    5ae4:	aa0603e4 	mov	x4, x6
    5ae8:	aa0003e2 	mov	x2, x0
    5aec:	1e603821 	fsub	d1, d1, d0
    5af0:	1e680821 	fmul	d1, d1, d8
    5af4:	eb0100bf 	cmp	x5, x1
    5af8:	54fffa01 	b.ne	5a38 <fwp_main_thread+0xb84>  // b.any
    5afc:	eb05009f 	cmp	x4, x5
    5b00:	540045c3 	b.cc	63b8 <fwp_main_thread+0x1504>  // b.lo, b.ul, b.last
    5b04:	f00000c0 	adrp	x0, 20000 <__data_start>
    5b08:	91004000 	add	x0, x0, #0x10
    5b0c:	9100a000 	add	x0, x0, #0x28
    5b10:	97fff1dc 	bl	2280 <fwp_trap>
    5b14:	aa0703e0 	mov	x0, x7
    5b18:	97fff53a 	bl	3000 <fwp_mem_free>
    5b1c:	aa1b03e0 	mov	x0, x27
    5b20:	17ffff90 	b	5960 <fwp_main_thread+0xaac>
    5b24:	9115829c 	add	x28, x20, #0x560
    5b28:	f949db81 	ldr	x1, [x28, #5040]
    5b2c:	f949ef80 	ldr	x0, [x28, #5080]
    5b30:	cb010341 	sub	x1, x26, x1
    5b34:	eb00403f 	cmp	x1, x0, lsl #16
    5b38:	54000382 	b.cs	5ba8 <fwp_main_thread+0xcf4>  // b.hs, b.nlast
    5b3c:	d350fc20 	lsr	x0, x1, #16
    5b40:	f949ff82 	ldr	x2, [x28, #5112]
    5b44:	8b000800 	add	x0, x0, x0, lsl #2
    5b48:	d37df000 	lsl	x0, x0, #3
    5b4c:	8b000044 	add	x4, x2, x0
    5b50:	f940109b 	ldr	x27, [x4, #32]
    5b54:	b40002bb 	cbz	x27, 5ba8 <fwp_main_thread+0xcf4>
    5b58:	38606840 	ldrb	w0, [x2, x0]
    5b5c:	7100081f 	cmp	w0, #0x2
    5b60:	54001fc0 	b.eq	5f58 <fwp_main_thread+0x10a4>  // b.none
    5b64:	7100041f 	cmp	w0, #0x1
    5b68:	54000201 	b.ne	5ba8 <fwp_main_thread+0xcf4>  // b.any
    5b6c:	29430085 	ldp	w5, w0, [x4, #24]
    5b70:	92403c21 	and	x1, x1, #0xffff
    5b74:	9b057c21 	mul	x1, x1, x5
    5b78:	d360fc21 	lsr	x1, x1, #32
    5b7c:	eb00003f 	cmp	x1, x0
    5b80:	54000142 	b.cs	5ba8 <fwp_main_thread+0xcf4>  // b.hs, b.nlast
    5b84:	8b01037b 	add	x27, x27, x1
    5b88:	39400360 	ldrb	w0, [x27]
    5b8c:	340000e0 	cbz	w0, 5ba8 <fwp_main_thread+0xcf4>
    5b90:	7100041f 	cmp	w0, #0x1
    5b94:	54001880 	b.eq	5ea4 <fwp_main_thread+0xff0>  // b.none
    5b98:	7103fc1f 	cmp	w0, #0xff
    5b9c:	540029e0 	b.eq	60d8 <fwp_main_thread+0x1224>  // b.none
    5ba0:	51000400 	sub	w0, w0, #0x1
    5ba4:	39000360 	strb	w0, [x27]
    5ba8:	52800b64 	mov	w4, #0x5b                  	// #91
    5bac:	aa1303e0 	mov	x0, x19
    5bb0:	aa1503e1 	mov	x1, x21
    5bb4:	d2800022 	mov	x2, #0x1                   	// #1
    5bb8:	3900a3e4 	strb	w4, [sp, #40]
    5bbc:	d00000da 	adrp	x26, 1f000 <__FRAME_END__+0x170f8>
    5bc0:	a9047fff 	stp	xzr, xzr, [sp, #64]
    5bc4:	912ca35a 	add	x26, x26, #0xb28
    5bc8:	9100233c 	add	x28, x25, #0x8
    5bcc:	f9002bff 	str	xzr, [sp, #80]
    5bd0:	97fff150 	bl	2110 <buf_put>
    5bd4:	f9400320 	ldr	x0, [x25]
    5bd8:	9101435a 	add	x26, x26, #0x50
    5bdc:	d2800018 	mov	x24, #0x0                   	// #0
    5be0:	f240f81b 	ands	x27, x0, #0x7fffffffffffffff
    5be4:	540001e1 	b.ne	5c20 <fwp_main_thread+0xd6c>  // b.any
    5be8:	14000018 	b	5c48 <fwp_main_thread+0xd94>
    5bec:	f8787821 	ldr	x1, [x1, x24, lsl #3]
    5bf0:	aa1a03e2 	mov	x2, x26
    5bf4:	aa1303e0 	mov	x0, x19
    5bf8:	91000718 	add	x24, x24, #0x1
    5bfc:	97fff8c5 	bl	3f10 <fwp_write.constprop.0>
    5c00:	eb18037f 	cmp	x27, x24
    5c04:	54000220 	b.eq	5c48 <fwp_main_thread+0xd94>  // b.none
    5c08:	aa1303e0 	mov	x0, x19
    5c0c:	b0000001 	adrp	x1, 6000 <fwp_main_thread+0x114c>
    5c10:	d2800042 	mov	x2, #0x2                   	// #2
    5c14:	913be021 	add	x1, x1, #0xef8
    5c18:	97fff13e 	bl	2110 <buf_put>
    5c1c:	f9400320 	ldr	x0, [x25]
    5c20:	aa1c03e1 	mov	x1, x28
    5c24:	b6fffe40 	tbz	x0, #63, 5bec <fwp_main_thread+0xd38>
    5c28:	f9400b21 	ldr	x1, [x25, #16]
    5c2c:	aa1a03e2 	mov	x2, x26
    5c30:	aa1303e0 	mov	x0, x19
    5c34:	f8787821 	ldr	x1, [x1, x24, lsl #3]
    5c38:	91000718 	add	x24, x24, #0x1
    5c3c:	97fff8b5 	bl	3f10 <fwp_write.constprop.0>
    5c40:	eb18037f 	cmp	x27, x24
    5c44:	54fffe21 	b.ne	5c08 <fwp_main_thread+0xd54>  // b.any
    5c48:	52800ba4 	mov	w4, #0x5d                  	// #93
    5c4c:	aa1303e0 	mov	x0, x19
    5c50:	aa1503e1 	mov	x1, x21
    5c54:	d2800022 	mov	x2, #0x1                   	// #1
    5c58:	3900a3e4 	strb	w4, [sp, #40]
    5c5c:	97fff12d 	bl	2110 <buf_put>
    5c60:	a94473fb 	ldp	x27, x28, [sp, #64]
    5c64:	b0000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    5c68:	912e4000 	add	x0, x0, #0xb90
    5c6c:	f100037f 	cmp	x27, #0x0
    5c70:	9a9b001b 	csel	x27, x0, x27, eq	// eq = none
    5c74:	b1002b9f 	cmn	x28, #0xa
    5c78:	54003ac8 	b.hi	63d0 <fwp_main_thread+0x151c>  // b.pmore
    5c7c:	91002780 	add	x0, x28, #0x9
    5c80:	52800021 	mov	w1, #0x1                   	// #1
    5c84:	97fff620 	bl	3504 <fwp_heap_alloc>
    5c88:	aa0003fa 	mov	x26, x0
    5c8c:	aa1b03e1 	mov	x1, x27
    5c90:	aa0003fb 	mov	x27, x0
    5c94:	aa1c03e2 	mov	x2, x28
    5c98:	f800877c 	str	x28, [x27], #8
    5c9c:	8b1c035c 	add	x28, x26, x28
    5ca0:	aa1b03e0 	mov	x0, x27
    5ca4:	97ffedaf 	bl	1360 <memcpy@plt>
    5ca8:	3900239f 	strb	wzr, [x28, #8]
    5cac:	f94023e0 	ldr	x0, [sp, #64]
    5cb0:	97ffee44 	bl	15c0 <free@plt>
    5cb4:	91158282 	add	x2, x20, #0x560
    5cb8:	f949ec44 	ldr	x4, [x2, #5080]
    5cbc:	f949d841 	ldr	x1, [x2, #5040]
    5cc0:	d370bc84 	lsl	x4, x4, #16
    5cc4:	cb010345 	sub	x5, x26, x1
    5cc8:	eb0400bf 	cmp	x5, x4
    5ccc:	540003a2 	b.cs	5d40 <fwp_main_thread+0xe8c>  // b.hs, b.nlast
    5cd0:	d350fca0 	lsr	x0, x5, #16
    5cd4:	f949fc46 	ldr	x6, [x2, #5112]
    5cd8:	8b000800 	add	x0, x0, x0, lsl #2
    5cdc:	d37df002 	lsl	x2, x0, #3
    5ce0:	8b0200c0 	add	x0, x6, x2
    5ce4:	f940101c 	ldr	x28, [x0, #32]
    5ce8:	b40002dc 	cbz	x28, 5d40 <fwp_main_thread+0xe8c>
    5cec:	386268c2 	ldrb	w2, [x6, x2]
    5cf0:	7100085f 	cmp	w2, #0x2
    5cf4:	540021e0 	b.eq	6130 <fwp_main_thread+0x127c>  // b.none
    5cf8:	7100045f 	cmp	w2, #0x1
    5cfc:	54000221 	b.ne	5d40 <fwp_main_thread+0xe8c>  // b.any
    5d00:	29430006 	ldp	w6, w0, [x0, #24]
    5d04:	92403ca2 	and	x2, x5, #0xffff
    5d08:	9b067c42 	mul	x2, x2, x6
    5d0c:	d360fc42 	lsr	x2, x2, #32
    5d10:	eb00005f 	cmp	x2, x0
    5d14:	54000162 	b.cs	5d40 <fwp_main_thread+0xe8c>  // b.hs, b.nlast
    5d18:	8b02039c 	add	x28, x28, x2
    5d1c:	39400380 	ldrb	w0, [x28]
    5d20:	7103fc1f 	cmp	w0, #0xff
    5d24:	540024a0 	b.eq	61b8 <fwp_main_thread+0x1304>  // b.none
    5d28:	91158280 	add	x0, x20, #0x560
    5d2c:	52800021 	mov	w1, #0x1                   	// #1
    5d30:	39000381 	strb	w1, [x28]
    5d34:	f949ec04 	ldr	x4, [x0, #5080]
    5d38:	f949d801 	ldr	x1, [x0, #5040]
    5d3c:	d370bc84 	lsl	x4, x4, #16
    5d40:	cb010321 	sub	x1, x25, x1
    5d44:	91158285 	add	x5, x20, #0x560
    5d48:	eb01009f 	cmp	x4, x1
    5d4c:	540003a9 	b.ls	5dc0 <fwp_main_thread+0xf0c>  // b.plast
    5d50:	d350fc20 	lsr	x0, x1, #16
    5d54:	f949fca4 	ldr	x4, [x5, #5112]
    5d58:	8b000800 	add	x0, x0, x0, lsl #2
    5d5c:	d37df002 	lsl	x2, x0, #3
    5d60:	8b020080 	add	x0, x4, x2
    5d64:	f940101c 	ldr	x28, [x0, #32]
    5d68:	b40002dc 	cbz	x28, 5dc0 <fwp_main_thread+0xf0c>
    5d6c:	38626882 	ldrb	w2, [x4, x2]
    5d70:	7100085f 	cmp	w2, #0x2
    5d74:	540016c0 	b.eq	604c <fwp_main_thread+0x1198>  // b.none
    5d78:	7100045f 	cmp	w2, #0x1
    5d7c:	54000221 	b.ne	5dc0 <fwp_main_thread+0xf0c>  // b.any
    5d80:	29430002 	ldp	w2, w0, [x0, #24]
    5d84:	92403c21 	and	x1, x1, #0xffff
    5d88:	9b027c21 	mul	x1, x1, x2
    5d8c:	d360fc21 	lsr	x1, x1, #32
    5d90:	eb00003f 	cmp	x1, x0
    5d94:	54000162 	b.cs	5dc0 <fwp_main_thread+0xf0c>  // b.hs, b.nlast
    5d98:	8b01039c 	add	x28, x28, x1
    5d9c:	39400380 	ldrb	w0, [x28]
    5da0:	34000100 	cbz	w0, 5dc0 <fwp_main_thread+0xf0c>
    5da4:	7100041f 	cmp	w0, #0x1
    5da8:	540010a0 	b.eq	5fbc <fwp_main_thread+0x1108>  // b.none
    5dac:	7103fc1f 	cmp	w0, #0xff
    5db0:	54002260 	b.eq	61fc <fwp_main_thread+0x1348>  // b.none
    5db4:	51000400 	sub	w0, w0, #0x1
    5db8:	39000380 	strb	w0, [x28]
    5dbc:	d503201f 	nop
    5dc0:	f9400342 	ldr	x2, [x26]
    5dc4:	d2800021 	mov	x1, #0x1                   	// #1
    5dc8:	f94042c3 	ldr	x3, [x22, #128]
    5dcc:	aa1b03e0 	mov	x0, x27
    5dd0:	97ffee0c 	bl	1600 <fwrite@plt>
    5dd4:	f94042c1 	ldr	x1, [x22, #128]
    5dd8:	52800140 	mov	w0, #0xa                   	// #10
    5ddc:	97ffed91 	bl	1420 <fputc@plt>
    5de0:	91158282 	add	x2, x20, #0x560
    5de4:	f949d841 	ldr	x1, [x2, #5040]
    5de8:	f949ec40 	ldr	x0, [x2, #5080]
    5dec:	cb010341 	sub	x1, x26, x1
    5df0:	eb00403f 	cmp	x1, x0, lsl #16
    5df4:	540003a2 	b.cs	5e68 <fwp_main_thread+0xfb4>  // b.hs, b.nlast
    5df8:	d350fc20 	lsr	x0, x1, #16
    5dfc:	f949fc43 	ldr	x3, [x2, #5112]
    5e00:	8b000800 	add	x0, x0, x0, lsl #2
    5e04:	d37df002 	lsl	x2, x0, #3
    5e08:	8b020060 	add	x0, x3, x2
    5e0c:	f940101b 	ldr	x27, [x0, #32]
    5e10:	b40002db 	cbz	x27, 5e68 <fwp_main_thread+0xfb4>
    5e14:	38626862 	ldrb	w2, [x3, x2]
    5e18:	7100085f 	cmp	w2, #0x2
    5e1c:	54001900 	b.eq	613c <fwp_main_thread+0x1288>  // b.none
    5e20:	7100045f 	cmp	w2, #0x1
    5e24:	54000221 	b.ne	5e68 <fwp_main_thread+0xfb4>  // b.any
    5e28:	29430002 	ldp	w2, w0, [x0, #24]
    5e2c:	92403c21 	and	x1, x1, #0xffff
    5e30:	9b027c21 	mul	x1, x1, x2
    5e34:	d360fc21 	lsr	x1, x1, #32
    5e38:	eb00003f 	cmp	x1, x0
    5e3c:	54000162 	b.cs	5e68 <fwp_main_thread+0xfb4>  // b.hs, b.nlast
    5e40:	8b01037b 	add	x27, x27, x1
    5e44:	39400360 	ldrb	w0, [x27]
    5e48:	34000100 	cbz	w0, 5e68 <fwp_main_thread+0xfb4>
    5e4c:	7100041f 	cmp	w0, #0x1
    5e50:	54001860 	b.eq	615c <fwp_main_thread+0x12a8>  // b.none
    5e54:	7103fc1f 	cmp	w0, #0xff
    5e58:	54002320 	b.eq	62bc <fwp_main_thread+0x1408>  // b.none
    5e5c:	51000400 	sub	w0, w0, #0x1
    5e60:	39000360 	strb	w0, [x27]
    5e64:	d503201f 	nop
    5e68:	f9400be0 	ldr	x0, [sp, #16]
    5e6c:	f9400800 	ldr	x0, [x0, #16]
    5e70:	f9000be0 	str	x0, [sp, #16]
    5e74:	b5ffc2e0 	cbnz	x0, 56d0 <fwp_main_thread+0x81c>
    5e78:	f94007e0 	ldr	x0, [sp, #8]
    5e7c:	97fff6cd 	bl	39b0 <fwp_drop0>
    5e80:	aa1703e0 	mov	x0, x23
    5e84:	97fff6cb 	bl	39b0 <fwp_drop0>
    5e88:	910202c0 	add	x0, x22, #0x80
    5e8c:	fd40cbea 	ldr	d10, [sp, #400]
    5e90:	6d5827e8 	ldp	d8, d9, [sp, #384]
    5e94:	52800021 	mov	w1, #0x1                   	// #1
    5e98:	b902c401 	str	w1, [x0, #708]
    5e9c:	f901681f 	str	xzr, [x0, #720]
    5ea0:	17fffc50 	b	4fe0 <fwp_main_thread+0x12c>
    5ea4:	f9400340 	ldr	x0, [x26]
    5ea8:	b7f805e0 	tbnz	x0, #63, 5f64 <fwp_main_thread+0x10b0>
    5eac:	91158281 	add	x1, x20, #0x560
    5eb0:	f949d820 	ldr	x0, [x1, #5040]
    5eb4:	f949ec21 	ldr	x1, [x1, #5080]
    5eb8:	cb000340 	sub	x0, x26, x0
    5ebc:	eb01401f 	cmp	x0, x1, lsl #16
    5ec0:	54ffe742 	b.cs	5ba8 <fwp_main_thread+0xcf4>  // b.hs, b.nlast
    5ec4:	d350fc01 	lsr	x1, x0, #16
    5ec8:	8b010821 	add	x1, x1, x1, lsl #2
    5ecc:	d37df021 	lsl	x1, x1, #3
    5ed0:	8b010045 	add	x5, x2, x1
    5ed4:	f94010a4 	ldr	x4, [x5, #32]
    5ed8:	b4ffe684 	cbz	x4, 5ba8 <fwp_main_thread+0xcf4>
    5edc:	38616841 	ldrb	w1, [x2, x1]
    5ee0:	7100083f 	cmp	w1, #0x2
    5ee4:	54000660 	b.eq	5fb0 <fwp_main_thread+0x10fc>  // b.none
    5ee8:	7100043f 	cmp	w1, #0x1
    5eec:	54ffe5e1 	b.ne	5ba8 <fwp_main_thread+0xcf4>  // b.any
    5ef0:	294304a2 	ldp	w2, w1, [x5, #24]
    5ef4:	92403c00 	and	x0, x0, #0xffff
    5ef8:	9b027c00 	mul	x0, x0, x2
    5efc:	d360fc00 	lsr	x0, x0, #32
    5f00:	eb01001f 	cmp	x0, x1
    5f04:	54ffe522 	b.cs	5ba8 <fwp_main_thread+0xcf4>  // b.hs, b.nlast
    5f08:	8b000084 	add	x4, x4, x0
    5f0c:	39400080 	ldrb	w0, [x4]
    5f10:	7100041f 	cmp	w0, #0x1
    5f14:	54ffe4a1 	b.ne	5ba8 <fwp_main_thread+0xcf4>  // b.any
    5f18:	aa1a03e0 	mov	x0, x26
    5f1c:	97fff439 	bl	3000 <fwp_mem_free>
    5f20:	17ffff22 	b	5ba8 <fwp_main_thread+0xcf4>
    5f24:	f9400b40 	ldr	x0, [x26, #16]
    5f28:	17fffed8 	b	5a88 <fwp_main_thread+0xbd4>
    5f2c:	f9400b46 	ldr	x6, [x26, #16]
    5f30:	1e6e1003 	fmov	d3, #1.000000000000000000e+00
    5f34:	fc6268c2 	ldr	d2, [x6, x2]
    5f38:	1e623863 	fsub	d3, d3, d2
    5f3c:	17fffec5 	b	5a50 <fwp_main_thread+0xb9c>
    5f40:	f9400b44 	ldr	x4, [x26, #16]
    5f44:	fc626880 	ldr	d0, [x4, x2]
    5f48:	1e600800 	fmul	d0, d0, d0
    5f4c:	eb0100df 	cmp	x6, x1
    5f50:	54ffdc43 	b.cc	5ad8 <fwp_main_thread+0xc24>  // b.lo, b.ul, b.last
    5f54:	17fffeec 	b	5b04 <fwp_main_thread+0xc50>
    5f58:	72003c3f 	tst	w1, #0xffff
    5f5c:	54ffe261 	b.ne	5ba8 <fwp_main_thread+0xcf4>  // b.any
    5f60:	17ffff0a 	b	5b88 <fwp_main_thread+0xcd4>
    5f64:	f940075b 	ldr	x27, [x26, #8]
    5f68:	aa1a03e0 	mov	x0, x26
    5f6c:	97fff545 	bl	3480 <fwp_rc_free_arr>
    5f70:	91158280 	add	x0, x20, #0x560
    5f74:	f949d801 	ldr	x1, [x0, #5040]
    5f78:	f949ec00 	ldr	x0, [x0, #5080]
    5f7c:	cb010361 	sub	x1, x27, x1
    5f80:	eb00403f 	cmp	x1, x0, lsl #16
    5f84:	54ffe122 	b.cs	5ba8 <fwp_main_thread+0xcf4>  // b.hs, b.nlast
    5f88:	aa1b03fa 	mov	x26, x27
    5f8c:	17fffeec 	b	5b3c <fwp_main_thread+0xc88>
    5f90:	72003c3f 	tst	w1, #0xffff
    5f94:	54ffd381 	b.ne	5a04 <fwp_main_thread+0xb50>  // b.any
    5f98:	39400380 	ldrb	w0, [x28]
    5f9c:	7103fc1f 	cmp	w0, #0xff
    5fa0:	54ffd2e1 	b.ne	59fc <fwp_main_thread+0xb48>  // b.any
    5fa4:	aa1c03e0 	mov	x0, x28
    5fa8:	97fff377 	bl	2d84 <fwp_rc_forget_slot>
    5fac:	17fffe94 	b	59fc <fwp_main_thread+0xb48>
    5fb0:	72003c1f 	tst	w0, #0xffff
    5fb4:	54ffdfa1 	b.ne	5ba8 <fwp_main_thread+0xcf4>  // b.any
    5fb8:	17ffffd5 	b	5f0c <fwp_main_thread+0x1058>
    5fbc:	f9400320 	ldr	x0, [x25]
    5fc0:	b7f804c0 	tbnz	x0, #63, 6058 <fwp_main_thread+0x11a4>
    5fc4:	91158281 	add	x1, x20, #0x560
    5fc8:	f949d820 	ldr	x0, [x1, #5040]
    5fcc:	f949ec21 	ldr	x1, [x1, #5080]
    5fd0:	cb000320 	sub	x0, x25, x0
    5fd4:	eb01401f 	cmp	x0, x1, lsl #16
    5fd8:	54ffef42 	b.cs	5dc0 <fwp_main_thread+0xf0c>  // b.hs, b.nlast
    5fdc:	d350fc01 	lsr	x1, x0, #16
    5fe0:	8b010821 	add	x1, x1, x1, lsl #2
    5fe4:	d37df021 	lsl	x1, x1, #3
    5fe8:	8b010085 	add	x5, x4, x1
    5fec:	f94010a2 	ldr	x2, [x5, #32]
    5ff0:	b4ffee82 	cbz	x2, 5dc0 <fwp_main_thread+0xf0c>
    5ff4:	38616881 	ldrb	w1, [x4, x1]
    5ff8:	7100083f 	cmp	w1, #0x2
    5ffc:	54000aa0 	b.eq	6150 <fwp_main_thread+0x129c>  // b.none
    6000:	7100043f 	cmp	w1, #0x1
    6004:	54ffede1 	b.ne	5dc0 <fwp_main_thread+0xf0c>  // b.any
    6008:	294304a4 	ldp	w4, w1, [x5, #24]
    600c:	92403c00 	and	x0, x0, #0xffff
    6010:	9b047c00 	mul	x0, x0, x4
    6014:	d360fc00 	lsr	x0, x0, #32
    6018:	eb01001f 	cmp	x0, x1
    601c:	54ffed22 	b.cs	5dc0 <fwp_main_thread+0xf0c>  // b.hs, b.nlast
    6020:	8b000042 	add	x2, x2, x0
    6024:	39400040 	ldrb	w0, [x2]
    6028:	7100041f 	cmp	w0, #0x1
    602c:	54ffeca1 	b.ne	5dc0 <fwp_main_thread+0xf0c>  // b.any
    6030:	aa1903e0 	mov	x0, x25
    6034:	97fff3f3 	bl	3000 <fwp_mem_free>
    6038:	17ffff62 	b	5dc0 <fwp_main_thread+0xf0c>
    603c:	72003c7f 	tst	w3, #0xffff
    6040:	54ffc860 	b.eq	594c <fwp_main_thread+0xa98>  // b.none
    6044:	aa1b03e0 	mov	x0, x27
    6048:	17fffe46 	b	5960 <fwp_main_thread+0xaac>
    604c:	72003c3f 	tst	w1, #0xffff
    6050:	54ffeb81 	b.ne	5dc0 <fwp_main_thread+0xf0c>  // b.any
    6054:	17ffff52 	b	5d9c <fwp_main_thread+0xee8>
    6058:	f940073c 	ldr	x28, [x25, #8]
    605c:	aa1903e0 	mov	x0, x25
    6060:	f9000fe5 	str	x5, [sp, #24]
    6064:	97fff507 	bl	3480 <fwp_rc_free_arr>
    6068:	91158280 	add	x0, x20, #0x560
    606c:	f949d801 	ldr	x1, [x0, #5040]
    6070:	f949ec00 	ldr	x0, [x0, #5080]
    6074:	cb010381 	sub	x1, x28, x1
    6078:	eb00403f 	cmp	x1, x0, lsl #16
    607c:	54ffea22 	b.cs	5dc0 <fwp_main_thread+0xf0c>  // b.hs, b.nlast
    6080:	f9400fe5 	ldr	x5, [sp, #24]
    6084:	aa1c03f9 	mov	x25, x28
    6088:	17ffff32 	b	5d50 <fwp_main_thread+0xe9c>
    608c:	72003c1f 	tst	w0, #0xffff
    6090:	54ffb540 	b.eq	5738 <fwp_main_thread+0x884>  // b.none
    6094:	f94007e0 	ldr	x0, [sp, #8]
    6098:	b5ffb6c0 	cbnz	x0, 5770 <fwp_main_thread+0x8bc>
    609c:	d2800000 	mov	x0, #0x0                   	// #0
    60a0:	97fff5dc 	bl	3810 <fwp_array_new_packed.constprop.0>
    60a4:	91158281 	add	x1, x20, #0x560
    60a8:	aa0003fa 	mov	x26, x0
    60ac:	aa0103e0 	mov	x0, x1
    60b0:	f949d821 	ldr	x1, [x1, #5040]
    60b4:	f949ec00 	ldr	x0, [x0, #5080]
    60b8:	cb010341 	sub	x1, x26, x1
    60bc:	eb00403f 	cmp	x1, x0, lsl #16
    60c0:	54ffb7a3 	b.cc	57b4 <fwp_main_thread+0x900>  // b.lo, b.ul, b.last
    60c4:	d2800000 	mov	x0, #0x0                   	// #0
    60c8:	17fffe28 	b	5968 <fwp_main_thread+0xab4>
    60cc:	72003c3f 	tst	w1, #0xffff
    60d0:	54ffba41 	b.ne	5818 <fwp_main_thread+0x964>  // b.any
    60d4:	17fffdcc 	b	5804 <fwp_main_thread+0x950>
    60d8:	ca5b4760 	eor	x0, x27, x27, lsr #17
    60dc:	91158281 	add	x1, x20, #0x560
    60e0:	ca402400 	eor	x0, x0, x0, lsr #9
    60e4:	8b200c20 	add	x0, x1, w0, uxtb #3
    60e8:	f94a2400 	ldr	x0, [x0, #5192]
    60ec:	b5000080 	cbnz	x0, 60fc <fwp_main_thread+0x1248>
    60f0:	14000091 	b	6334 <fwp_main_thread+0x1480>
    60f4:	f9400800 	ldr	x0, [x0, #16]
    60f8:	b40011e0 	cbz	x0, 6334 <fwp_main_thread+0x1480>
    60fc:	f9400001 	ldr	x1, [x0]
    6100:	eb01037f 	cmp	x27, x1
    6104:	54ffff81 	b.ne	60f4 <fwp_main_thread+0x1240>  // b.any
    6108:	f9400401 	ldr	x1, [x0, #8]
    610c:	d1000421 	sub	x1, x1, #0x1
    6110:	f9000401 	str	x1, [x0, #8]
    6114:	f103f83f 	cmp	x1, #0xfe
    6118:	54ffd481 	b.ne	5ba8 <fwp_main_thread+0xcf4>  // b.any
    611c:	aa1b03e0 	mov	x0, x27
    6120:	97fff319 	bl	2d84 <fwp_rc_forget_slot>
    6124:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6128:	39000360 	strb	w0, [x27]
    612c:	17fffe9f 	b	5ba8 <fwp_main_thread+0xcf4>
    6130:	72003cbf 	tst	w5, #0xffff
    6134:	54ffe061 	b.ne	5d40 <fwp_main_thread+0xe8c>  // b.any
    6138:	17fffef9 	b	5d1c <fwp_main_thread+0xe68>
    613c:	72003c3f 	tst	w1, #0xffff
    6140:	54ffe941 	b.ne	5e68 <fwp_main_thread+0xfb4>  // b.any
    6144:	39400360 	ldrb	w0, [x27]
    6148:	35ffe820 	cbnz	w0, 5e4c <fwp_main_thread+0xf98>
    614c:	17ffff47 	b	5e68 <fwp_main_thread+0xfb4>
    6150:	72003c1f 	tst	w0, #0xffff
    6154:	54ffe361 	b.ne	5dc0 <fwp_main_thread+0xf0c>  // b.any
    6158:	17ffffb3 	b	6024 <fwp_main_thread+0x1170>
    615c:	aa1a03e0 	mov	x0, x26
    6160:	97fff3a8 	bl	3000 <fwp_mem_free>
    6164:	17ffff41 	b	5e68 <fwp_main_thread+0xfb4>
    6168:	72003c5f 	tst	w2, #0xffff
    616c:	54ffaa21 	b.ne	56b0 <fwp_main_thread+0x7fc>  // b.any
    6170:	17fffd4b 	b	569c <fwp_main_thread+0x7e8>
    6174:	72003c5f 	tst	w2, #0xffff
    6178:	54ffa521 	b.ne	561c <fwp_main_thread+0x768>  // b.any
    617c:	17fffd23 	b	5608 <fwp_main_thread+0x754>
    6180:	72003c5f 	tst	w2, #0xffff
    6184:	54ffa061 	b.ne	5590 <fwp_main_thread+0x6dc>  // b.any
    6188:	17fffcfd 	b	557c <fwp_main_thread+0x6c8>
    618c:	aa1c03e0 	mov	x0, x28
    6190:	f90007e4 	str	x4, [sp, #8]
    6194:	97fff2fc 	bl	2d84 <fwp_rc_forget_slot>
    6198:	f94007e4 	ldr	x4, [sp, #8]
    619c:	17fffcb2 	b	5464 <fwp_main_thread+0x5b0>
    61a0:	aa0003e1 	mov	x1, x0
    61a4:	f90022b3 	str	x19, [x21, #64]
    61a8:	17fffba6 	b	5040 <fwp_main_thread+0x18c>
    61ac:	aa1b03e0 	mov	x0, x27
    61b0:	97fff2f5 	bl	2d84 <fwp_rc_forget_slot>
    61b4:	17fffd97 	b	5810 <fwp_main_thread+0x95c>
    61b8:	aa1c03e0 	mov	x0, x28
    61bc:	97fff2f2 	bl	2d84 <fwp_rc_forget_slot>
    61c0:	17fffeda 	b	5d28 <fwp_main_thread+0xe74>
    61c4:	f94152a0 	ldr	x0, [x21, #672]
    61c8:	97fff38e 	bl	3000 <fwp_mem_free>
    61cc:	f90152bf 	str	xzr, [x21, #672]
    61d0:	f9015abf 	str	xzr, [x21, #688]
    61d4:	f94172a0 	ldr	x0, [x21, #736]
    61d8:	b4000a53 	cbz	x19, 6320 <fwp_main_thread+0x146c>
    61dc:	f900567f 	str	xzr, [x19, #168]
    61e0:	f9005e7f 	str	xzr, [x19, #184]
    61e4:	b902dabf 	str	wzr, [x21, #728]
    61e8:	eb13001f 	cmp	x0, x19
    61ec:	54ff7880 	b.eq	50fc <fwp_main_thread+0x248>  // b.none
    61f0:	6d1827e8 	stp	d8, d9, [sp, #384]
    61f4:	fd00cbea 	str	d10, [sp, #400]
    61f8:	97ffecd6 	bl	1550 <abort@plt>
    61fc:	ca5c4780 	eor	x0, x28, x28, lsr #17
    6200:	91158281 	add	x1, x20, #0x560
    6204:	ca402400 	eor	x0, x0, x0, lsr #9
    6208:	8b200c20 	add	x0, x1, w0, uxtb #3
    620c:	f94a2400 	ldr	x0, [x0, #5192]
    6210:	b5000080 	cbnz	x0, 6220 <fwp_main_thread+0x136c>
    6214:	14000048 	b	6334 <fwp_main_thread+0x1480>
    6218:	f9400800 	ldr	x0, [x0, #16]
    621c:	b40008c0 	cbz	x0, 6334 <fwp_main_thread+0x1480>
    6220:	f9400001 	ldr	x1, [x0]
    6224:	eb01039f 	cmp	x28, x1
    6228:	54ffff81 	b.ne	6218 <fwp_main_thread+0x1364>  // b.any
    622c:	f9400401 	ldr	x1, [x0, #8]
    6230:	d1000421 	sub	x1, x1, #0x1
    6234:	f9000401 	str	x1, [x0, #8]
    6238:	f103f83f 	cmp	x1, #0xfe
    623c:	54ffdc21 	b.ne	5dc0 <fwp_main_thread+0xf0c>  // b.any
    6240:	aa1c03e0 	mov	x0, x28
    6244:	97fff2d0 	bl	2d84 <fwp_rc_forget_slot>
    6248:	12800020 	mov	w0, #0xfffffffe            	// #-2
    624c:	39000380 	strb	w0, [x28]
    6250:	17fffedc 	b	5dc0 <fwp_main_thread+0xf0c>
    6254:	ca5a4741 	eor	x1, x26, x26, lsr #17
    6258:	91158282 	add	x2, x20, #0x560
    625c:	ca412421 	eor	x1, x1, x1, lsr #9
    6260:	92401c21 	and	x1, x1, #0xff
    6264:	910a2423 	add	x3, x1, #0x289
    6268:	8b010c41 	add	x1, x2, x1, lsl #3
    626c:	8b030c5b 	add	x27, x2, x3, lsl #3
    6270:	f94a2421 	ldr	x1, [x1, #5192]
    6274:	b50000a1 	cbnz	x1, 6288 <fwp_main_thread+0x13d4>
    6278:	14000059 	b	63dc <fwp_main_thread+0x1528>
    627c:	9100403b 	add	x27, x1, #0x10
    6280:	f9400821 	ldr	x1, [x1, #16]
    6284:	b4000541 	cbz	x1, 632c <fwp_main_thread+0x1478>
    6288:	f9400022 	ldr	x2, [x1]
    628c:	eb1a005f 	cmp	x2, x26
    6290:	54ffff61 	b.ne	627c <fwp_main_thread+0x13c8>  // b.any
    6294:	f9400361 	ldr	x1, [x27]
    6298:	7103f81f 	cmp	w0, #0xfe
    629c:	54000800 	b.eq	639c <fwp_main_thread+0x14e8>  // b.none
    62a0:	b40004a1 	cbz	x1, 6334 <fwp_main_thread+0x1480>
    62a4:	f9400420 	ldr	x0, [x1, #8]
    62a8:	b100041f 	cmn	x0, #0x1
    62ac:	540009c0 	b.eq	63e4 <fwp_main_thread+0x1530>  // b.none
    62b0:	91000400 	add	x0, x0, #0x1
    62b4:	f9000420 	str	x0, [x1, #8]
    62b8:	17fffd2c 	b	5768 <fwp_main_thread+0x8b4>
    62bc:	ca5b4760 	eor	x0, x27, x27, lsr #17
    62c0:	91158281 	add	x1, x20, #0x560
    62c4:	ca402400 	eor	x0, x0, x0, lsr #9
    62c8:	8b200c20 	add	x0, x1, w0, uxtb #3
    62cc:	f94a2400 	ldr	x0, [x0, #5192]
    62d0:	b5000080 	cbnz	x0, 62e0 <fwp_main_thread+0x142c>
    62d4:	14000018 	b	6334 <fwp_main_thread+0x1480>
    62d8:	f9400800 	ldr	x0, [x0, #16]
    62dc:	b40002c0 	cbz	x0, 6334 <fwp_main_thread+0x1480>
    62e0:	f9400001 	ldr	x1, [x0]
    62e4:	eb01037f 	cmp	x27, x1
    62e8:	54ffff81 	b.ne	62d8 <fwp_main_thread+0x1424>  // b.any
    62ec:	f9400401 	ldr	x1, [x0, #8]
    62f0:	d1000421 	sub	x1, x1, #0x1
    62f4:	f9000401 	str	x1, [x0, #8]
    62f8:	f103f83f 	cmp	x1, #0xfe
    62fc:	54ffdb61 	b.ne	5e68 <fwp_main_thread+0xfb4>  // b.any
    6300:	aa1b03e0 	mov	x0, x27
    6304:	97fff2a0 	bl	2d84 <fwp_rc_forget_slot>
    6308:	12800020 	mov	w0, #0xfffffffe            	// #-2
    630c:	39000360 	strb	w0, [x27]
    6310:	17fffed6 	b	5e68 <fwp_main_thread+0xfb4>
    6314:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    6318:	913f4000 	add	x0, x0, #0xfd0
    631c:	97ffefd9 	bl	2280 <fwp_trap>
    6320:	b902dabf 	str	wzr, [x21, #728]
    6324:	b4ff7860 	cbz	x0, 5230 <fwp_main_thread+0x37c>
    6328:	17ffffb2 	b	61f0 <fwp_main_thread+0x133c>
    632c:	7103f81f 	cmp	w0, #0xfe
    6330:	540001a0 	b.eq	6364 <fwp_main_thread+0x14b0>  // b.none
    6334:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    6338:	91382000 	add	x0, x0, #0xe08
    633c:	97ffefd1 	bl	2280 <fwp_trap>
    6340:	aa1903e0 	mov	x0, x25
    6344:	97fff290 	bl	2d84 <fwp_rc_forget_slot>
    6348:	17fffcb3 	b	5614 <fwp_main_thread+0x760>
    634c:	aa1903e0 	mov	x0, x25
    6350:	97fff28d 	bl	2d84 <fwp_rc_forget_slot>
    6354:	17fffcd5 	b	56a8 <fwp_main_thread+0x7f4>
    6358:	aa1a03e0 	mov	x0, x26
    635c:	97fff28a 	bl	2d84 <fwp_rc_forget_slot>
    6360:	17fffc8a 	b	5588 <fwp_main_thread+0x6d4>
    6364:	d2800300 	mov	x0, #0x18                  	// #24
    6368:	97ffec4e 	bl	14a0 <malloc@plt>
    636c:	b4000420 	cbz	x0, 63f0 <fwp_main_thread+0x153c>
    6370:	d2801fe1 	mov	x1, #0xff                  	// #255
    6374:	a900041a 	stp	x26, x1, [x0]
    6378:	91158281 	add	x1, x20, #0x560
    637c:	f900081f 	str	xzr, [x0, #16]
    6380:	12800002 	mov	w2, #0xffffffff            	// #-1
    6384:	f9000360 	str	x0, [x27]
    6388:	39000342 	strb	w2, [x26]
    638c:	f94e2420 	ldr	x0, [x1, #7240]
    6390:	91000400 	add	x0, x0, #0x1
    6394:	f90e2420 	str	x0, [x1, #7240]
    6398:	17fffcf4 	b	5768 <fwp_main_thread+0x8b4>
    639c:	b4fffe41 	cbz	x1, 6364 <fwp_main_thread+0x14b0>
    63a0:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    63a4:	913e2000 	add	x0, x0, #0xf88
    63a8:	97ffefb6 	bl	2280 <fwp_trap>
    63ac:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    63b0:	9138c000 	add	x0, x0, #0xe30
    63b4:	97ffefb3 	bl	2280 <fwp_trap>
    63b8:	2f00e402 	movi	d2, #0x0
    63bc:	b0000000 	adrp	x0, 7000 <_IO_stdin_used+0x4b0>
    63c0:	fd412800 	ldr	d0, [x0, #592]
    63c4:	1e622821 	fadd	d1, d1, d2
    63c8:	1e600820 	fmul	d0, d1, d0
    63cc:	17fffdad 	b	5a80 <fwp_main_thread+0xbcc>
    63d0:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    63d4:	913fe000 	add	x0, x0, #0xff8
    63d8:	97ffefaa 	bl	2280 <fwp_trap>
    63dc:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    63e0:	17ffffae 	b	6298 <fwp_main_thread+0x13e4>
    63e4:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    63e8:	913ec000 	add	x0, x0, #0xfb0
    63ec:	97ffefa5 	bl	2280 <fwp_trap>
    63f0:	97ffee38 	bl	1cd0 <fwp_heap_oom>
    63f4:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    63f8:	913d0000 	add	x0, x0, #0xf40
    63fc:	a9166bf9 	stp	x25, x26, [sp, #352]
    6400:	6d1827e8 	stp	d8, d9, [sp, #384]
    6404:	fd00cbea 	str	d10, [sp, #400]
    6408:	97ffef9e 	bl	2280 <fwp_trap>
    640c:	6d1827e8 	stp	d8, d9, [sp, #384]
    6410:	fd00cbea 	str	d10, [sp, #400]
    6414:	97ffec3b 	bl	1500 <__stack_chk_fail@plt>
    6418:	90000000 	adrp	x0, 6000 <fwp_main_thread+0x114c>
    641c:	913da000 	add	x0, x0, #0xf68
    6420:	6d1827e8 	stp	d8, d9, [sp, #384]
    6424:	fd00cbea 	str	d10, [sp, #400]
    6428:	97ffeeae 	bl	1ee0 <ad_raw_fail>
    642c:	d503201f 	nop

0000000000006430 <__divti3>:
    6430:	d503245f 	bti	c
    6434:	d2800004 	mov	x4, #0x0                   	// #0
    6438:	b7f80721 	tbnz	x1, #63, 651c <__divti3+0xec>
    643c:	b6f80083 	tbz	x3, #63, 644c <__divti3+0x1c>
    6440:	eb0203e2 	negs	x2, x2
    6444:	aa2403e4 	mvn	x4, x4
    6448:	da0303e3 	ngc	x3, x3
    644c:	aa0203e6 	mov	x6, x2
    6450:	aa0003e7 	mov	x7, x0
    6454:	aa0103e5 	mov	x5, x1
    6458:	b5000583 	cbnz	x3, 6508 <__divti3+0xd8>
    645c:	eb01005f 	cmp	x2, x1
    6460:	54000e69 	b.ls	662c <__divti3+0x1fc>  // b.plast
    6464:	dac01040 	clz	x0, x2
    6468:	b40000e0 	cbz	x0, 6484 <__divti3+0x54>
    646c:	4b0003e1 	neg	w1, w0
    6470:	9ac020a5 	lsl	x5, x5, x0
    6474:	9ac02046 	lsl	x6, x2, x0
    6478:	9ac124e1 	lsr	x1, x7, x1
    647c:	aa050025 	orr	x5, x1, x5
    6480:	9ac020e7 	lsl	x7, x7, x0
    6484:	d360fcc8 	lsr	x8, x6, #32
    6488:	92407cc2 	and	x2, x6, #0xffffffff
    648c:	9ac808a3 	udiv	x3, x5, x8
    6490:	9b089465 	msub	x5, x3, x8, x5
    6494:	aa0303e0 	mov	x0, x3
    6498:	9b037c41 	mul	x1, x2, x3
    649c:	93c780a5 	extr	x5, x5, x7, #32
    64a0:	eb05003f 	cmp	x1, x5
    64a4:	540000a9 	b.ls	64b8 <__divti3+0x88>  // b.plast
    64a8:	ab0500c5 	adds	x5, x6, x5
    64ac:	d1000460 	sub	x0, x3, #0x1
    64b0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    64b4:	540015a8 	b.hi	6768 <__divti3+0x338>  // b.pmore
    64b8:	cb0100a5 	sub	x5, x5, x1
    64bc:	9ac808a3 	udiv	x3, x5, x8
    64c0:	9b089465 	msub	x5, x3, x8, x5
    64c4:	aa0303e1 	mov	x1, x3
    64c8:	9b037c42 	mul	x2, x2, x3
    64cc:	aa0703e3 	mov	x3, x7
    64d0:	b3607ca3 	bfi	x3, x5, #32, #32
    64d4:	eb03005f 	cmp	x2, x3
    64d8:	540000c9 	b.ls	64f0 <__divti3+0xc0>  // b.plast
    64dc:	ab0300c3 	adds	x3, x6, x3
    64e0:	d1000425 	sub	x5, x1, #0x1
    64e4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    64e8:	d1000821 	sub	x1, x1, #0x2
    64ec:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    64f0:	aa008020 	orr	x0, x1, x0, lsl #32
    64f4:	d2800001 	mov	x1, #0x0                   	// #0
    64f8:	b4000064 	cbz	x4, 6504 <__divti3+0xd4>
    64fc:	eb0003e0 	negs	x0, x0
    6500:	da0103e1 	ngc	x1, x1
    6504:	d65f03c0 	ret
    6508:	eb01007f 	cmp	x3, x1
    650c:	54000109 	b.ls	652c <__divti3+0xfc>  // b.plast
    6510:	d2800001 	mov	x1, #0x0                   	// #0
    6514:	d2800000 	mov	x0, #0x0                   	// #0
    6518:	17fffff8 	b	64f8 <__divti3+0xc8>
    651c:	eb0003e0 	negs	x0, x0
    6520:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    6524:	da0103e1 	ngc	x1, x1
    6528:	17ffffc5 	b	643c <__divti3+0xc>
    652c:	dac01067 	clz	x7, x3
    6530:	b40010e7 	cbz	x7, 674c <__divti3+0x31c>
    6534:	d2800805 	mov	x5, #0x40                  	// #64
    6538:	cb0700a5 	sub	x5, x5, x7
    653c:	9ac72063 	lsl	x3, x3, x7
    6540:	9ac52448 	lsr	x8, x2, x5
    6544:	aa030108 	orr	x8, x8, x3
    6548:	9ac52426 	lsr	x6, x1, x5
    654c:	92407d0a 	and	x10, x8, #0xffffffff
    6550:	d360fd09 	lsr	x9, x8, #32
    6554:	9ac52403 	lsr	x3, x0, x5
    6558:	9ac72021 	lsl	x1, x1, x7
    655c:	aa010063 	orr	x3, x3, x1
    6560:	9ac72042 	lsl	x2, x2, x7
    6564:	9ac908cb 	udiv	x11, x6, x9
    6568:	9b099965 	msub	x5, x11, x9, x6
    656c:	aa0b03e1 	mov	x1, x11
    6570:	9b0b7d46 	mul	x6, x10, x11
    6574:	93c380a5 	extr	x5, x5, x3, #32
    6578:	eb0500df 	cmp	x6, x5
    657c:	540000a9 	b.ls	6590 <__divti3+0x160>  // b.plast
    6580:	ab050105 	adds	x5, x8, x5
    6584:	d1000561 	sub	x1, x11, #0x1
    6588:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    658c:	54000f48 	b.hi	6774 <__divti3+0x344>  // b.pmore
    6590:	cb0600a6 	sub	x6, x5, x6
    6594:	9ac908cb 	udiv	x11, x6, x9
    6598:	9b099969 	msub	x9, x11, x9, x6
    659c:	aa0b03e5 	mov	x5, x11
    65a0:	9b0b7d4a 	mul	x10, x10, x11
    65a4:	b3607d23 	bfi	x3, x9, #32, #32
    65a8:	eb03015f 	cmp	x10, x3
    65ac:	540000a9 	b.ls	65c0 <__divti3+0x190>  // b.plast
    65b0:	ab030103 	adds	x3, x8, x3
    65b4:	d1000565 	sub	x5, x11, #0x1
    65b8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    65bc:	54000e28 	b.hi	6780 <__divti3+0x350>  // b.pmore
    65c0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    65c4:	92407c48 	and	x8, x2, #0xffffffff
    65c8:	2a0503e5 	mov	w5, w5
    65cc:	d360fc42 	lsr	x2, x2, #32
    65d0:	d360fc26 	lsr	x6, x1, #32
    65d4:	cb0a0063 	sub	x3, x3, x10
    65d8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    65dc:	9b087caa 	mul	x10, x5, x8
    65e0:	9b087cc8 	mul	x8, x6, x8
    65e4:	9b0220a5 	madd	x5, x5, x2, x8
    65e8:	9b027cc6 	mul	x6, x6, x2
    65ec:	8b4a80a2 	add	x2, x5, x10, lsr #32
    65f0:	8b0900c5 	add	x5, x6, x9
    65f4:	eb02011f 	cmp	x8, x2
    65f8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    65fc:	8b4280c6 	add	x6, x6, x2, lsr #32
    6600:	eb06007f 	cmp	x3, x6
    6604:	540000e3 	b.cc	6620 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    6608:	92407d4a 	and	x10, x10, #0xffffffff
    660c:	9ac72000 	lsl	x0, x0, x7
    6610:	8b028142 	add	x2, x10, x2, lsl #32
    6614:	eb02001f 	cmp	x0, x2
    6618:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    661c:	54000a01 	b.ne	675c <__divti3+0x32c>  // b.any
    6620:	d1000420 	sub	x0, x1, #0x1
    6624:	d2800001 	mov	x1, #0x0                   	// #0
    6628:	17ffffb4 	b	64f8 <__divti3+0xc8>
    662c:	b5000062 	cbnz	x2, 6638 <__divti3+0x208>
    6630:	d2800022 	mov	x2, #0x1                   	// #1
    6634:	9ac30846 	udiv	x6, x2, x3
    6638:	dac010c8 	clz	x8, x6
    663c:	b5000408 	cbnz	x8, 66bc <__divti3+0x28c>
    6640:	d360fcc9 	lsr	x9, x6, #32
    6644:	92407cc5 	and	x5, x6, #0xffffffff
    6648:	cb060023 	sub	x3, x1, x6
    664c:	d2800021 	mov	x1, #0x1                   	// #1
    6650:	9ac90868 	udiv	x8, x3, x9
    6654:	9b098d03 	msub	x3, x8, x9, x3
    6658:	aa0803e0 	mov	x0, x8
    665c:	9b057d02 	mul	x2, x8, x5
    6660:	93c78063 	extr	x3, x3, x7, #32
    6664:	eb03005f 	cmp	x2, x3
    6668:	540000a9 	b.ls	667c <__divti3+0x24c>  // b.plast
    666c:	ab0300c3 	adds	x3, x6, x3
    6670:	d1000500 	sub	x0, x8, #0x1
    6674:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    6678:	54000968 	b.hi	67a4 <__divti3+0x374>  // b.pmore
    667c:	cb020063 	sub	x3, x3, x2
    6680:	9ac90862 	udiv	x2, x3, x9
    6684:	aa0203e8 	mov	x8, x2
    6688:	9b098c42 	msub	x2, x2, x9, x3
    668c:	aa0703e3 	mov	x3, x7
    6690:	9b057d05 	mul	x5, x8, x5
    6694:	b3607c43 	bfi	x3, x2, #32, #32
    6698:	eb0300bf 	cmp	x5, x3
    669c:	540000c9 	b.ls	66b4 <__divti3+0x284>  // b.plast
    66a0:	ab0300c2 	adds	x2, x6, x3
    66a4:	d1000503 	sub	x3, x8, #0x1
    66a8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    66ac:	d1000908 	sub	x8, x8, #0x2
    66b0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    66b4:	aa008100 	orr	x0, x8, x0, lsl #32
    66b8:	17ffff90 	b	64f8 <__divti3+0xc8>
    66bc:	9ac820c6 	lsl	x6, x6, x8
    66c0:	d2800803 	mov	x3, #0x40                  	// #64
    66c4:	cb080063 	sub	x3, x3, x8
    66c8:	d360fcc9 	lsr	x9, x6, #32
    66cc:	9ac82027 	lsl	x7, x1, x8
    66d0:	92407cc5 	and	x5, x6, #0xffffffff
    66d4:	9ac32422 	lsr	x2, x1, x3
    66d8:	9ac32403 	lsr	x3, x0, x3
    66dc:	aa070063 	orr	x3, x3, x7
    66e0:	9ac9084a 	udiv	x10, x2, x9
    66e4:	9ac82007 	lsl	x7, x0, x8
    66e8:	9b098940 	msub	x0, x10, x9, x2
    66ec:	aa0a03e1 	mov	x1, x10
    66f0:	9b0a7ca2 	mul	x2, x5, x10
    66f4:	93c38000 	extr	x0, x0, x3, #32
    66f8:	eb00005f 	cmp	x2, x0
    66fc:	540000a9 	b.ls	6710 <__divti3+0x2e0>  // b.plast
    6700:	ab0000c0 	adds	x0, x6, x0
    6704:	d1000541 	sub	x1, x10, #0x1
    6708:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    670c:	54000468 	b.hi	6798 <__divti3+0x368>  // b.pmore
    6710:	cb020000 	sub	x0, x0, x2
    6714:	9ac9080a 	udiv	x10, x0, x9
    6718:	9b098140 	msub	x0, x10, x9, x0
    671c:	aa0a03e2 	mov	x2, x10
    6720:	9b0a7ca8 	mul	x8, x5, x10
    6724:	b3607c03 	bfi	x3, x0, #32, #32
    6728:	eb03011f 	cmp	x8, x3
    672c:	540000a9 	b.ls	6740 <__divti3+0x310>  // b.plast
    6730:	ab0300c3 	adds	x3, x6, x3
    6734:	d1000542 	sub	x2, x10, #0x1
    6738:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    673c:	54000288 	b.hi	678c <__divti3+0x35c>  // b.pmore
    6740:	cb080063 	sub	x3, x3, x8
    6744:	aa018041 	orr	x1, x2, x1, lsl #32
    6748:	17ffffc2 	b	6650 <__divti3+0x220>
    674c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    6750:	d2800001 	mov	x1, #0x0                   	// #0
    6754:	9a9f87e0 	cset	x0, ls	// ls = plast
    6758:	17ffff68 	b	64f8 <__divti3+0xc8>
    675c:	aa0103e0 	mov	x0, x1
    6760:	d2800001 	mov	x1, #0x0                   	// #0
    6764:	17ffff65 	b	64f8 <__divti3+0xc8>
    6768:	d1000860 	sub	x0, x3, #0x2
    676c:	8b0600a5 	add	x5, x5, x6
    6770:	17ffff52 	b	64b8 <__divti3+0x88>
    6774:	d1000961 	sub	x1, x11, #0x2
    6778:	8b0800a5 	add	x5, x5, x8
    677c:	17ffff85 	b	6590 <__divti3+0x160>
    6780:	d1000965 	sub	x5, x11, #0x2
    6784:	8b080063 	add	x3, x3, x8
    6788:	17ffff8e 	b	65c0 <__divti3+0x190>
    678c:	d1000942 	sub	x2, x10, #0x2
    6790:	8b060063 	add	x3, x3, x6
    6794:	17ffffeb 	b	6740 <__divti3+0x310>
    6798:	d1000941 	sub	x1, x10, #0x2
    679c:	8b060000 	add	x0, x0, x6
    67a0:	17ffffdc 	b	6710 <__divti3+0x2e0>
    67a4:	d1000900 	sub	x0, x8, #0x2
    67a8:	8b060063 	add	x3, x3, x6
    67ac:	17ffffb4 	b	667c <__divti3+0x24c>

00000000000067b0 <__modti3>:
    67b0:	d503245f 	bti	c
    67b4:	d2800004 	mov	x4, #0x0                   	// #0
    67b8:	b6f80081 	tbz	x1, #63, 67c8 <__modti3+0x18>
    67bc:	eb0003e0 	negs	x0, x0
    67c0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    67c4:	da0103e1 	ngc	x1, x1
    67c8:	f100007f 	cmp	x3, #0x0
    67cc:	5400128b 	b.lt	6a1c <__modti3+0x26c>  // b.tstop
    67d0:	aa0003e7 	mov	x7, x0
    67d4:	aa0103e6 	mov	x6, x1
    67d8:	540004e1 	b.ne	6874 <__modti3+0xc4>  // b.any
    67dc:	eb02003f 	cmp	x1, x2
    67e0:	54000dc2 	b.cs	6998 <__modti3+0x1e8>  // b.hs, b.nlast
    67e4:	dac01043 	clz	x3, x2
    67e8:	aa0303e5 	mov	x5, x3
    67ec:	b40000e3 	cbz	x3, 6808 <__modti3+0x58>
    67f0:	4b0303e6 	neg	w6, w3
    67f4:	9ac32021 	lsl	x1, x1, x3
    67f8:	9ac32042 	lsl	x2, x2, x3
    67fc:	9ac62406 	lsr	x6, x0, x6
    6800:	aa0100c6 	orr	x6, x6, x1
    6804:	9ac32007 	lsl	x7, x0, x3
    6808:	d360fc40 	lsr	x0, x2, #32
    680c:	92407c43 	and	x3, x2, #0xffffffff
    6810:	9ac008c1 	udiv	x1, x6, x0
    6814:	9b009826 	msub	x6, x1, x0, x6
    6818:	9b017c61 	mul	x1, x3, x1
    681c:	93c780c6 	extr	x6, x6, x7, #32
    6820:	eb06003f 	cmp	x1, x6
    6824:	540000a9 	b.ls	6838 <__modti3+0x88>  // b.plast
    6828:	ab060046 	adds	x6, x2, x6
    682c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    6830:	8b0200c8 	add	x8, x6, x2
    6834:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    6838:	cb0100c6 	sub	x6, x6, x1
    683c:	9ac008c8 	udiv	x8, x6, x0
    6840:	9b009901 	msub	x1, x8, x0, x6
    6844:	aa0703e0 	mov	x0, x7
    6848:	9b087c63 	mul	x3, x3, x8
    684c:	b3607c20 	bfi	x0, x1, #32, #32
    6850:	eb00007f 	cmp	x3, x0
    6854:	54001088 	b.hi	6a64 <__modti3+0x2b4>  // b.pmore
    6858:	cb030000 	sub	x0, x0, x3
    685c:	9ac52400 	lsr	x0, x0, x5
    6860:	d2800001 	mov	x1, #0x0                   	// #0
    6864:	b4000064 	cbz	x4, 6870 <__modti3+0xc0>
    6868:	eb0003e0 	negs	x0, x0
    686c:	da0103e1 	ngc	x1, x1
    6870:	d65f03c0 	ret
    6874:	dac01066 	clz	x6, x3
    6878:	eb03003f 	cmp	x1, x3
    687c:	54ffff43 	b.cc	6864 <__modti3+0xb4>  // b.lo, b.ul, b.last
    6880:	93407cc5 	sxtw	x5, w6
    6884:	d2800808 	mov	x8, #0x40                  	// #64
    6888:	cb050108 	sub	x8, x8, x5
    688c:	9ac62063 	lsl	x3, x3, x6
    6890:	9ac62025 	lsl	x5, x1, x6
    6894:	9ac82447 	lsr	x7, x2, x8
    6898:	aa0300e7 	orr	x7, x7, x3
    689c:	9ac82423 	lsr	x3, x1, x8
    68a0:	92407cec 	and	x12, x7, #0xffffffff
    68a4:	d360fcea 	lsr	x10, x7, #32
    68a8:	9ac82401 	lsr	x1, x0, x8
    68ac:	aa050021 	orr	x1, x1, x5
    68b0:	9ac62042 	lsl	x2, x2, x6
    68b4:	9ac62000 	lsl	x0, x0, x6
    68b8:	9aca086b 	udiv	x11, x3, x10
    68bc:	9b0a8d63 	msub	x3, x11, x10, x3
    68c0:	aa0b03e5 	mov	x5, x11
    68c4:	9b0b7d89 	mul	x9, x12, x11
    68c8:	93c18063 	extr	x3, x3, x1, #32
    68cc:	eb03013f 	cmp	x9, x3
    68d0:	540000a9 	b.ls	68e4 <__modti3+0x134>  // b.plast
    68d4:	ab0300e3 	adds	x3, x7, x3
    68d8:	d1000565 	sub	x5, x11, #0x1
    68dc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    68e0:	54001168 	b.hi	6b0c <__modti3+0x35c>  // b.pmore
    68e4:	cb090063 	sub	x3, x3, x9
    68e8:	9aca086b 	udiv	x11, x3, x10
    68ec:	9b0a8d6a 	msub	x10, x11, x10, x3
    68f0:	aa0b03e9 	mov	x9, x11
    68f4:	9b0b7d8c 	mul	x12, x12, x11
    68f8:	b3607d41 	bfi	x1, x10, #32, #32
    68fc:	eb01019f 	cmp	x12, x1
    6900:	540000a9 	b.ls	6914 <__modti3+0x164>  // b.plast
    6904:	ab0100e1 	adds	x1, x7, x1
    6908:	d1000569 	sub	x9, x11, #0x1
    690c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    6910:	54000f88 	b.hi	6b00 <__modti3+0x350>  // b.pmore
    6914:	aa058123 	orr	x3, x9, x5, lsl #32
    6918:	92407c4b 	and	x11, x2, #0xffffffff
    691c:	2a0903e9 	mov	w9, w9
    6920:	d360fc4a 	lsr	x10, x2, #32
    6924:	d360fc63 	lsr	x3, x3, #32
    6928:	cb0c0021 	sub	x1, x1, x12
    692c:	aa0a03ec 	mov	x12, x10
    6930:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    6934:	9b0b7d25 	mul	x5, x9, x11
    6938:	9b0b7c6b 	mul	x11, x3, x11
    693c:	9b0a2d29 	madd	x9, x9, x10, x11
    6940:	92407caa 	and	x10, x5, #0xffffffff
    6944:	9b0c7c63 	mul	x3, x3, x12
    6948:	8b458125 	add	x5, x9, x5, lsr #32
    694c:	8b0d0069 	add	x9, x3, x13
    6950:	eb05017f 	cmp	x11, x5
    6954:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    6958:	8b058149 	add	x9, x10, x5, lsl #32
    695c:	8b458063 	add	x3, x3, x5, lsr #32
    6960:	eb03003f 	cmp	x1, x3
    6964:	54000063 	b.cc	6970 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    6968:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    696c:	54000082 	b.cs	697c <__modti3+0x1cc>  // b.hs, b.nlast
    6970:	eb020129 	subs	x9, x9, x2
    6974:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    6978:	cb070063 	sub	x3, x3, x7
    697c:	eb090000 	subs	x0, x0, x9
    6980:	da030021 	sbc	x1, x1, x3
    6984:	9ac62400 	lsr	x0, x0, x6
    6988:	9ac82028 	lsl	x8, x1, x8
    698c:	aa000100 	orr	x0, x8, x0
    6990:	9ac62421 	lsr	x1, x1, x6
    6994:	17ffffb4 	b	6864 <__modti3+0xb4>
    6998:	b5000062 	cbnz	x2, 69a4 <__modti3+0x1f4>
    699c:	d2800023 	mov	x3, #0x1                   	// #1
    69a0:	9ac20862 	udiv	x2, x3, x2
    69a4:	dac01048 	clz	x8, x2
    69a8:	aa0803e5 	mov	x5, x8
    69ac:	b5000668 	cbnz	x8, 6a78 <__modti3+0x2c8>
    69b0:	cb020020 	sub	x0, x1, x2
    69b4:	d360fc49 	lsr	x9, x2, #32
    69b8:	92407c4a 	and	x10, x2, #0xffffffff
    69bc:	9ac90801 	udiv	x1, x0, x9
    69c0:	9b098020 	msub	x0, x1, x9, x0
    69c4:	9b0a7c21 	mul	x1, x1, x10
    69c8:	93c78000 	extr	x0, x0, x7, #32
    69cc:	eb00003f 	cmp	x1, x0
    69d0:	540000a9 	b.ls	69e4 <__modti3+0x234>  // b.plast
    69d4:	ab000040 	adds	x0, x2, x0
    69d8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    69dc:	8b020003 	add	x3, x0, x2
    69e0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    69e4:	cb010001 	sub	x1, x0, x1
    69e8:	9ac90820 	udiv	x0, x1, x9
    69ec:	9b098403 	msub	x3, x0, x9, x1
    69f0:	aa0703e1 	mov	x1, x7
    69f4:	9b0a7c00 	mul	x0, x0, x10
    69f8:	b3607c61 	bfi	x1, x3, #32, #32
    69fc:	eb01001f 	cmp	x0, x1
    6a00:	540000a9 	b.ls	6a14 <__modti3+0x264>  // b.plast
    6a04:	ab010041 	adds	x1, x2, x1
    6a08:	8b020022 	add	x2, x1, x2
    6a0c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    6a10:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    6a14:	cb000020 	sub	x0, x1, x0
    6a18:	17ffff91 	b	685c <__modti3+0xac>
    6a1c:	eb0203e5 	negs	x5, x2
    6a20:	aa0003e7 	mov	x7, x0
    6a24:	da0303e8 	ngc	x8, x3
    6a28:	aa0503e2 	mov	x2, x5
    6a2c:	aa0803e3 	mov	x3, x8
    6a30:	aa0103e6 	mov	x6, x1
    6a34:	b4ffed48 	cbz	x8, 67dc <__modti3+0x2c>
    6a38:	eb01011f 	cmp	x8, x1
    6a3c:	54fff148 	b.hi	6864 <__modti3+0xb4>  // b.pmore
    6a40:	dac01109 	clz	x9, x8
    6a44:	2a0903e6 	mov	w6, w9
    6a48:	b5fff1c9 	cbnz	x9, 6880 <__modti3+0xd0>
    6a4c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    6a50:	54000068 	b.hi	6a5c <__modti3+0x2ac>  // b.pmore
    6a54:	eb050007 	subs	x7, x0, x5
    6a58:	da080021 	sbc	x1, x1, x8
    6a5c:	aa0703e0 	mov	x0, x7
    6a60:	17ffff81 	b	6864 <__modti3+0xb4>
    6a64:	ab000040 	adds	x0, x2, x0
    6a68:	8b020002 	add	x2, x0, x2
    6a6c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    6a70:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    6a74:	17ffff79 	b	6858 <__modti3+0xa8>
    6a78:	9ac82042 	lsl	x2, x2, x8
    6a7c:	d2800803 	mov	x3, #0x40                  	// #64
    6a80:	cb080063 	sub	x3, x3, x8
    6a84:	d360fc49 	lsr	x9, x2, #32
    6a88:	9ac82027 	lsl	x7, x1, x8
    6a8c:	92407c4a 	and	x10, x2, #0xffffffff
    6a90:	9ac32426 	lsr	x6, x1, x3
    6a94:	9ac32403 	lsr	x3, x0, x3
    6a98:	aa070063 	orr	x3, x3, x7
    6a9c:	9ac908c1 	udiv	x1, x6, x9
    6aa0:	9ac82007 	lsl	x7, x0, x8
    6aa4:	9b099820 	msub	x0, x1, x9, x6
    6aa8:	9b017d41 	mul	x1, x10, x1
    6aac:	93c38000 	extr	x0, x0, x3, #32
    6ab0:	eb00003f 	cmp	x1, x0
    6ab4:	540000a9 	b.ls	6ac8 <__modti3+0x318>  // b.plast
    6ab8:	ab000040 	adds	x0, x2, x0
    6abc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    6ac0:	8b020006 	add	x6, x0, x2
    6ac4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    6ac8:	cb010000 	sub	x0, x0, x1
    6acc:	9ac90801 	udiv	x1, x0, x9
    6ad0:	9b098026 	msub	x6, x1, x9, x0
    6ad4:	aa0303e0 	mov	x0, x3
    6ad8:	9b017d41 	mul	x1, x10, x1
    6adc:	b3607cc0 	bfi	x0, x6, #32, #32
    6ae0:	eb00003f 	cmp	x1, x0
    6ae4:	540000a9 	b.ls	6af8 <__modti3+0x348>  // b.plast
    6ae8:	ab000040 	adds	x0, x2, x0
    6aec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    6af0:	8b020003 	add	x3, x0, x2
    6af4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    6af8:	cb010000 	sub	x0, x0, x1
    6afc:	17ffffb0 	b	69bc <__modti3+0x20c>
    6b00:	d1000969 	sub	x9, x11, #0x2
    6b04:	8b070021 	add	x1, x1, x7
    6b08:	17ffff83 	b	6914 <__modti3+0x164>
    6b0c:	d1000965 	sub	x5, x11, #0x2
    6b10:	8b070063 	add	x3, x3, x7
    6b14:	17ffff74 	b	68e4 <__modti3+0x134>
    6b18:	d503201f 	nop
    6b1c:	d503201f 	nop

0000000000006b20 <atexit>:
    6b20:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    6b24:	d00000c2 	adrp	x2, 20000 <__data_start>
    6b28:	d2800001 	mov	x1, #0x0                   	// #0
    6b2c:	910003fd 	mov	x29, sp
    6b30:	a8c17bfd 	ldp	x29, x30, [sp], #16
    6b34:	f9400442 	ldr	x2, [x2, #8]
    6b38:	17ffea32 	b	1400 <__cxa_atexit@plt>

Disassembly of section .fini:

0000000000006b3c <_fini>:
    6b3c:	d503201f 	nop
    6b40:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    6b44:	910003fd 	mov	x29, sp
    6b48:	a8c17bfd 	ldp	x29, x30, [sp], #16
    6b4c:	d65f03c0 	ret
