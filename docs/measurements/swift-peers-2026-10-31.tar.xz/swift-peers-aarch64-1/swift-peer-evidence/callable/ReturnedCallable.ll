; ModuleID = '/__w/fun-with-pipes/fun-with-pipes/swift-peer-evidence/callable/ReturnedCallable.ll'
source_filename = "/__w/fun-with-pipes/fun-with-pipes/swift-peer-evidence/callable/ReturnedCallable.ll"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-gnu"

%swift.type_descriptor = type opaque
%swift.full_boxmetadata = type { ptr, ptr, %swift.type, i32, ptr }
%swift.type = type { i64 }

@".str.45.ReturnedCallable/returned_callable_peer.swift" = private unnamed_addr constant [46 x i8] c"ReturnedCallable/returned_callable_peer.swift\00"
@".str.11.Fatal error" = private unnamed_addr constant [12 x i8] c"Fatal error\00"
@".str.21.invalid callable kind" = private unnamed_addr constant [22 x i8] c"invalid callable kind\00"
@"$ss5Int64VMn" = external global %swift.type_descriptor, align 4
@"got.$ss5Int64VMn" = private unnamed_addr constant ptr @"$ss5Int64VMn"
@"symbolic _____ s5Int64V" = linkonce_odr hidden constant <{ i8, i32, i8 }> <{ i8 2, i32 trunc (i64 sub (i64 ptrtoint (ptr @"got.$ss5Int64VMn" to i64), i64 ptrtoint (ptr getelementptr inbounds (<{ i8, i32, i8 }>, ptr @"symbolic _____ s5Int64V", i32 0, i32 1) to i64)) to i32), i8 0 }>, section "swift5_typeref", no_sanitize_address, align 2
@"\01l__swift5_reflection_descriptor" = private constant { i32, i32, i32, i32 } { i32 1, i32 0, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ s5Int64V" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32 }, ptr @"\01l__swift5_reflection_descriptor", i32 0, i32 3) to i64)) to i32) }, section "swift5_capture", no_sanitize_address, align 4
@metadata = private constant %swift.full_boxmetadata { ptr @__swift_closure_destructor, ptr null, %swift.type { i64 1024 }, i32 16, ptr @"\01l__swift5_reflection_descriptor" }, align 8
@"\01l__swift5_reflection_descriptor.1" = private constant { i32, i32, i32, i32 } { i32 1, i32 0, i32 0, i32 trunc (i64 sub (i64 ptrtoint (ptr @"symbolic _____ s5Int64V" to i64), i64 ptrtoint (ptr getelementptr inbounds ({ i32, i32, i32, i32 }, ptr @"\01l__swift5_reflection_descriptor.1", i32 0, i32 3) to i64)) to i32) }, section "swift5_capture", no_sanitize_address, align 4
@metadata.3 = private constant %swift.full_boxmetadata { ptr @__swift_closure_destructor.2, ptr null, %swift.type { i64 1024 }, i32 16, ptr @"\01l__swift5_reflection_descriptor.1" }, align 8
@__swift_reflection_version = linkonce_odr hidden constant i16 3
@_swift1_autolink_entries = private constant [77 x i8] c"-lswift_Concurrency\00-lswiftCore\00-lswift_StringProcessing\00-lswift_RegexParser\00", section ".swift1_autolink_entries", no_sanitize_address, align 8
@llvm.used = appending global [6 x ptr] [ptr @"\01l__swift5_reflection_descriptor", ptr @"\01l__swift5_reflection_descriptor.1", ptr @"$s16ReturnedCallable12returnedMakeys5Int64VADcs5Int32V_ADtF", ptr @"$s16ReturnedCallable14returnedDirectys5Int64Vs5Int32V_A2DtF", ptr @__swift_reflection_version, ptr @_swift1_autolink_entries], section "llvm.metadata"

define protected swiftcc { ptr, ptr } @"$s16ReturnedCallable12returnedMakeys5Int64VADcs5Int32V_ADtF"(i32 %0, i64 %1) #0 {
entry:
  switch i32 %0, label %3 [
    i32 0, label %6
    i32 1, label %2
  ]

2:                                                ; preds = %entry
  br label %6

3:                                                ; preds = %entry
  %4 = or i64 sub (i64 ptrtoint (ptr @".str.21.invalid callable kind" to i64), i64 32), -9223372036854775808
  %5 = inttoptr i64 %4 to ptr
  tail call swiftcc void @"$ss17_assertionFailure__4file4line5flagss5NeverOs12StaticStringV_SSAHSus6UInt32VtF"(i64 ptrtoint (ptr @".str.11.Fatal error" to i64), i64 11, i8 2, i64 -3458764513820540907, ptr nonnull %5, i64 ptrtoint (ptr @".str.45.ReturnedCallable/returned_callable_peer.swift" to i64), i64 45, i8 2, i64 7, i32 0)
  unreachable

6:                                                ; preds = %entry, %2
  %.sink = phi ptr [ getelementptr inbounds nuw (i8, ptr @metadata, i64 16), %2 ], [ getelementptr inbounds nuw (i8, ptr @metadata.3, i64 16), %entry ]
  %7 = phi ptr [ @"$s16ReturnedCallable12returnedMakeys5Int64VADcs5Int32V_ADtFA2DcfU0_TA", %2 ], [ @"$s16ReturnedCallable12returnedMakeys5Int64VADcs5Int32V_ADtFA2DcfU_TA", %entry ]
  %8 = tail call noalias ptr @swift_allocObject(ptr nonnull %.sink, i64 24, i64 7) #3
  %9 = getelementptr inbounds nuw i8, ptr %8, i64 16
  store i64 %1, ptr %9, align 8
  %10 = insertvalue { ptr, ptr } undef, ptr %7, 0
  %11 = insertvalue { ptr, ptr } %10, ptr %8, 1
  ret { ptr, ptr } %11
}

; Function Attrs: noinline
declare swiftcc void @"$ss17_assertionFailure__4file4line5flagss5NeverOs12StaticStringV_SSAHSus6UInt32VtF"(i64, i64, i8, i64, ptr, i64, i64, i8, i64, i32) local_unnamed_addr #1

; Function Attrs: nounwind
define internal swiftcc void @__swift_closure_destructor(ptr swiftself %0) #2 {
entry:
  tail call void @swift_deallocObject(ptr %0, i64 24, i64 7) #3
  ret void
}

; Function Attrs: nounwind
declare void @swift_deallocObject(ptr, i64, i64) local_unnamed_addr #3

; Function Attrs: nounwind
declare ptr @swift_allocObject(ptr, i64, i64) local_unnamed_addr #3

; Function Attrs: nounwind memory(argmem: read, inaccessiblemem: write)
define internal swiftcc range(i64 -9223372036854775808, 9223372036854775807) i64 @"$s16ReturnedCallable12returnedMakeys5Int64VADcs5Int32V_ADtFA2DcfU0_TA"(i64 %0, ptr readonly swiftself captures(none) %1) #4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %3 = load i64, ptr %2, align 8
  %4 = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %3, i64 %0)
  %5 = extractvalue { i64, i1 } %4, 1
  br i1 %5, label %10, label %6, !prof !7

6:                                                ; preds = %entry
  %7 = extractvalue { i64, i1 } %4, 0
  %8 = add i64 %7, 4611686018427387904
  %9 = icmp slt i64 %8, 0
  br i1 %9, label %11, label %"$s16ReturnedCallable12returnedMakeys5Int64VADcs5Int32V_ADtFA2DcfU0_.exit", !prof !7

10:                                               ; preds = %entry
  tail call void @llvm.trap() #7
  unreachable

11:                                               ; preds = %6
  tail call void @llvm.trap() #7
  unreachable

"$s16ReturnedCallable12returnedMakeys5Int64VADcs5Int32V_ADtFA2DcfU0_.exit": ; preds = %6
  %12 = shl nsw i64 %7, 1
  ret i64 %12
}

; Function Attrs: nounwind memory(argmem: read, inaccessiblemem: write)
define internal swiftcc i64 @"$s16ReturnedCallable12returnedMakeys5Int64VADcs5Int32V_ADtFA2DcfU_TA"(i64 %0, ptr readonly swiftself captures(none) %1) #4 {
entry:
  %2 = getelementptr inbounds nuw i8, ptr %1, i64 16
  %3 = load i64, ptr %2, align 8
  %4 = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %3, i64 %0)
  %5 = extractvalue { i64, i1 } %4, 1
  br i1 %5, label %6, label %"$s16ReturnedCallable12returnedMakeys5Int64VADcs5Int32V_ADtFA2DcfU_.exit", !prof !7

6:                                                ; preds = %entry
  tail call void @llvm.trap() #7
  unreachable

"$s16ReturnedCallable12returnedMakeys5Int64VADcs5Int32V_ADtFA2DcfU_.exit": ; preds = %entry
  %7 = extractvalue { i64, i1 } %4, 0
  ret i64 %7
}

define protected swiftcc i64 @"$s16ReturnedCallable14returnedDirectys5Int64Vs5Int32V_A2DtF"(i32 %0, i64 %1, i64 %2) #0 {
entry:
  switch i32 %0, label %15 [
    i32 0, label %3
    i32 1, label %7
  ]

3:                                                ; preds = %entry
  %4 = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %1, i64 %2)
  %5 = extractvalue { i64, i1 } %4, 0
  %6 = extractvalue { i64, i1 } %4, 1
  br i1 %6, label %22, label %18, !prof !7

7:                                                ; preds = %entry
  %8 = tail call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %1, i64 %2)
  %9 = extractvalue { i64, i1 } %8, 1
  br i1 %9, label %20, label %10, !prof !7

10:                                               ; preds = %7
  %11 = extractvalue { i64, i1 } %8, 0
  %12 = shl nsw i64 %11, 1
  %13 = add i64 %11, 4611686018427387904
  %14 = icmp slt i64 %13, 0
  br i1 %14, label %21, label %18, !prof !7

15:                                               ; preds = %entry
  %16 = or i64 sub (i64 ptrtoint (ptr @".str.21.invalid callable kind" to i64), i64 32), -9223372036854775808
  %17 = inttoptr i64 %16 to ptr
  tail call swiftcc void @"$ss17_assertionFailure__4file4line5flagss5NeverOs12StaticStringV_SSAHSus6UInt32VtF"(i64 ptrtoint (ptr @".str.11.Fatal error" to i64), i64 11, i8 2, i64 -3458764513820540907, ptr nonnull %17, i64 ptrtoint (ptr @".str.45.ReturnedCallable/returned_callable_peer.swift" to i64), i64 45, i8 2, i64 15, i32 0)
  unreachable

18:                                               ; preds = %10, %3
  %19 = phi i64 [ %5, %3 ], [ %12, %10 ]
  ret i64 %19

20:                                               ; preds = %7
  tail call void @llvm.trap() #7
  unreachable

21:                                               ; preds = %10
  tail call void @llvm.trap() #7
  unreachable

22:                                               ; preds = %3
  tail call void @llvm.trap() #7
  unreachable
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64) #5

; Function Attrs: cold noreturn nounwind memory(inaccessiblemem: write)
declare void @llvm.trap() #6

; Function Attrs: nounwind
define internal swiftcc void @__swift_closure_destructor.2(ptr swiftself %0) #2 {
  tail call swiftcc void @__swift_closure_destructor(ptr swiftself %0) #2
  ret void
}

attributes #0 = { "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { noinline "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #2 = { nounwind "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #3 = { nounwind }
attributes #4 = { nounwind memory(argmem: read, inaccessiblemem: write) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { cold noreturn nounwind memory(inaccessiblemem: write) }
attributes #7 = { nomerge }

!swift.module.flags = !{!0}
!llvm.module.flags = !{!1, !2, !3, !4, !5, !6}
!llvm.linker.options = !{}

!0 = !{!"standard-library", i1 false}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 7, !"frame-pointer", i32 1}
!5 = !{i32 4, !"Objective-C Garbage Collection", i32 100927232}
!6 = !{i32 1, !"Swift Version", i32 7}
!7 = !{!"branch_weights", !"expected", i32 1, i32 2000}
