let i = Int64(CommandLine.arguments[1])!
print(i &- 1)
