var i = Int64(CommandLine.arguments[1])!
var sum = Int64(CommandLine.arguments[2])!
if i != 0 {
    let next = i - 1
    let product = i * 3
    sum = sum + product % 7
    i = next
}
print("\(i) \(sum)")
