
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	b0000045 	adrp	x5, b000 <_IO_stdin_used+0x70>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	910ba0a5 	add	x5, x5, #0x2e8
    2aa0:	b0000044 	adrp	x4, b000 <_IO_stdin_used+0x70>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	910bc084 	add	x4, x4, #0x2f0
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	91014261 	add	x1, x19, #0x50
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10d18>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9006820 	str	x0, [x1, #208]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    2b34:	9120e000 	add	x0, x0, #0x838
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000022 	adrp	x2, 8000 <fwp_write+0xb7c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	9111c042 	add	x2, x2, #0x470
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	91014273 	add	x19, x19, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943da60 	ldr	w0, [x19, #984]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff50 	bl	2990 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    2c7c:	91212000 	add	x0, x0, #0x848
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97ffff07 	bl	28a0 <__stack_chk_fail@plt>
    2c88:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    2c8c:	9123a000 	add	x0, x0, #0x8e8
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffeee 	bl	2850 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    2ca4:	91230000 	add	x0, x0, #0x8c0
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    2cb0:	91224000 	add	x0, x0, #0x890
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    2cbc:	9121a000 	add	x0, x0, #0x868
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91010000 	add	x0, x0, #0x40
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91010021 	add	x1, x1, #0x40
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91010000 	add	x0, x0, #0x40
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91010021 	add	x1, x1, #0x40
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x70>
    2eb4:	913d0021 	add	x1, x1, #0xf40
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x70>
    3158:	913c8021 	add	x1, x1, #0xf20
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1b90>
    3190:	913e6000 	add	x0, x0, #0xf98
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    31c4:	9118c2a1 	add	x1, x21, #0x630
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    31d8:	912880a5 	add	x5, x5, #0xa20
    31dc:	9118c2a1 	add	x1, x21, #0x630
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	9118c2b7 	add	x23, x21, #0x630
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	9118c2b5 	add	x21, x21, #0x630
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	9118c2b5 	add	x21, x21, #0x630
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    3368:	912860a5 	add	x5, x5, #0xa18
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x1b90>
    339c:	913ec042 	add	x2, x2, #0xfb0
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	90000042 	adrp	x2, b000 <_IO_stdin_used+0x70>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	91002042 	add	x2, x2, #0x8
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	90000059 	adrp	x25, b000 <_IO_stdin_used+0x70>
    3428:	f000003a 	adrp	x26, a000 <fwp_main_thread+0x1b90>
    342c:	9101a339 	add	x25, x25, #0x68
    3430:	913f435a 	add	x26, x26, #0xfd0
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	f000003b 	adrp	x27, a000 <fwp_main_thread+0x1b90>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	913f6377 	add	x23, x27, #0xfd8
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	90000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	9102a000 	add	x0, x0, #0xa8
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbb0>
    34f4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    34f8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbb0>
    34fc:	f0000023 	adrp	x3, a000 <fwp_main_thread+0x1b90>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	90000055 	adrp	x21, b000 <_IO_stdin_used+0x70>
    3508:	f9422824 	ldr	x4, [x1, #1104]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f9422ca5 	ldr	x5, [x5, #1112]
    3514:	91114033 	add	x19, x1, #0x450
    3518:	f9423046 	ldr	x6, [x2, #1120]
    351c:	913f4063 	add	x3, x3, #0xfd0
    3520:	910302b5 	add	x21, x21, #0xc0
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	90000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	91040000 	add	x0, x0, #0x100
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1b90>
    35ac:	913f8000 	add	x0, x0, #0xfe0
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1b90>
    366c:	913e6000 	add	x0, x0, #0xf98
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x70>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	91042021 	add	x1, x1, #0x108
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x70>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91044021 	add	x1, x1, #0x110
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x70>
    37e0:	91046021 	add	x1, x1, #0x118
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffe12 	bl	3074 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	90000042 	adrp	x2, b000 <_IO_stdin_used+0x70>
    3838:	aa1303e3 	mov	x3, x19
    383c:	91048042 	add	x2, x2, #0x120
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc33 	bl	2910 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc60 	bl	29d0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc6e 	bl	2a10 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbbc 	bl	2750 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbdc 	bl	2840 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbbf 	bl	27f0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc17 	bl	2960 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x1b90>
    3950:	913e6000 	add	x0, x0, #0xf98
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc12 	bl	29a0 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc1c 	bl	29d0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc2a 	bl	2a10 <_Exit@plt>
    396c:	90000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    3970:	9104c000 	add	x0, x0, #0x130
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb8a 	bl	27d0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	90000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    3a08:	91054000 	add	x0, x0, #0x150
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffba4 	bl	28a0 <__stack_chk_fail@plt>
    3a14:	90000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    3a18:	9105c000 	add	x0, x0, #0x170
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x70>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc3d420 	ldr	q0, [x1, #3920]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	910142b5 	add	x21, x21, #0x50
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f9406aa2 	ldr	x2, [x21, #208]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb9f 	bl	2960 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	90000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    3b18:	91066000 	add	x0, x0, #0x198
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb5f 	bl	28a0 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b3c:	91014063 	add	x3, x3, #0x50
    3b40:	9350fc01 	asr	x1, x0, #16
    3b44:	d1000440 	sub	x0, x2, #0x1
    3b48:	f9406c62 	ldr	x2, [x3, #216]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9404463 	ldr	x3, [x3, #136]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	90000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    3b88:	91072000 	add	x0, x0, #0x1c8
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	90000044 	adrp	x4, b000 <_IO_stdin_used+0x70>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	91086084 	add	x4, x4, #0x218
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffb06 	bl	2810 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb5f 	bl	2980 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb4a 	bl	2940 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa93 	bl	26f0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffacb 	bl	27f0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffabc 	bl	27f0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa74 	bl	26f0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa80 	bl	2730 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb10 	bl	2980 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	90000044 	adrp	x4, b000 <_IO_stdin_used+0x70>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	9108c084 	add	x4, x4, #0x230
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa90 	bl	2810 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa7f 	bl	27f0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffadf 	bl	2980 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	90000044 	adrp	x4, b000 <_IO_stdin_used+0x70>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	91088084 	add	x4, x4, #0x220
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa68 	bl	2810 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa52 	bl	27f0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa26 	bl	27f0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa42 	bl	28a0 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    3fa8:	9118c042 	add	x2, x2, #0x630
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x70>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	90000040 	adrp	x0, b000 <_IO_stdin_used+0x70>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	9108e021 	add	x1, x1, #0x238
    4004:	91090000 	add	x0, x0, #0x240
    4008:	97fffa0a 	bl	2830 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa87 	bl	2a50 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa35 	bl	2940 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa74 	bl	2a50 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9e5 	bl	2820 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	f0000022 	adrp	x2, b000 <_IO_stdin_used+0x70>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	91098042 	add	x2, x2, #0x260
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa08 	b	2910 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e8 	bl	28a0 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9d0>
    410c:	9114c061 	add	x1, x3, #0x530
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    411c:	9118c262 	add	x2, x19, #0x630
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	f0000022 	adrp	x2, b000 <_IO_stdin_used+0x70>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9d0>
    414c:	9115c021 	add	x1, x1, #0x570
    4150:	3dc3d843 	ldr	q3, [x2, #3936]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9d0>
    417c:	9114c063 	add	x3, x3, #0x530
    4180:	91174084 	add	x4, x4, #0x5d0
    4184:	9118c266 	add	x6, x19, #0x630
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9cd 	bl	2930 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	9118c275 	add	x21, x19, #0x630
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9b7 	bl	2930 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    4268:	910c4000 	add	x0, x0, #0x310
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9f0 	bl	2a30 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	9118c273 	add	x19, x19, #0x630
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffbac 	bl	3170 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	91014122 	add	x2, x9, #0x50
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9406046 	ldr	x6, [x2, #192]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	91014120 	add	x0, x9, #0x50
    4354:	f900640b 	str	x11, [x0, #200]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	91014129 	add	x9, x9, #0x50
    4360:	f9006126 	str	x6, [x9, #192]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <ad_raw_free.part.0>:
    4380:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbb0>
    4384:	d2800001 	mov	x1, #0x0                   	// #0
    4388:	91114082 	add	x2, x4, #0x450
    438c:	14000005 	b	43a0 <ad_raw_free.part.0+0x20>
    4390:	91000421 	add	x1, x1, #0x1
    4394:	91006042 	add	x2, x2, #0x18
    4398:	f140043f 	cmp	x1, #0x1, lsl #12
    439c:	54000220 	b.eq	43e0 <ad_raw_free.part.0+0x60>  // b.none
    43a0:	f9400043 	ldr	x3, [x2]
    43a4:	eb03001f 	cmp	x0, x3
    43a8:	54ffff41 	b.ne	4390 <ad_raw_free.part.0+0x10>  // b.any
    43ac:	8b010421 	add	x1, x1, x1, lsl #1
    43b0:	91114084 	add	x4, x4, #0x450
    43b4:	900000e2 	adrp	x2, 20000 <__data_start>
    43b8:	91014042 	add	x2, x2, #0x50
    43bc:	8b010c81 	add	x1, x4, x1, lsl #3
    43c0:	b9401024 	ldr	w4, [x1, #16]
    43c4:	f9400425 	ldr	x5, [x1, #8]
    43c8:	a9007c3f 	stp	xzr, xzr, [x1]
    43cc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    43d0:	f900083f 	str	xzr, [x1, #16]
    43d4:	cb050061 	sub	x1, x3, x5
    43d8:	f8247841 	str	x1, [x2, x4, lsl #3]
    43dc:	17fff961 	b	2960 <free@plt>
    43e0:	f100001f 	cmp	x0, #0x0
    43e4:	f0000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    43e8:	910ce021 	add	x1, x1, #0x338
    43ec:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    43f0:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    43f4:	910c8000 	add	x0, x0, #0x320
    43f8:	910003fd 	mov	x29, sp
    43fc:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4400:	97fffbe0 	bl	3380 <ad_raw_fail>

0000000000004404 <fwp_tape_buffers_dispose>:
    4404:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4408:	910003fd 	mov	x29, sp
    440c:	f9000bf3 	str	x19, [sp, #16]
    4410:	aa0003f3 	mov	x19, x0
    4414:	f9400000 	ldr	x0, [x0]
    4418:	b4000040 	cbz	x0, 4420 <fwp_tape_buffers_dispose+0x1c>
    441c:	97ffffd9 	bl	4380 <ad_raw_free.part.0>
    4420:	f9400a60 	ldr	x0, [x19, #16]
    4424:	b4000040 	cbz	x0, 442c <fwp_tape_buffers_dispose+0x28>
    4428:	97ffffd6 	bl	4380 <ad_raw_free.part.0>
    442c:	f9401260 	ldr	x0, [x19, #32]
    4430:	b4000040 	cbz	x0, 4438 <fwp_tape_buffers_dispose+0x34>
    4434:	97ffffd3 	bl	4380 <ad_raw_free.part.0>
    4438:	4f000400 	movi	v0.4s, #0x0
    443c:	f9001a7f 	str	xzr, [x19, #48]
    4440:	ad000260 	stp	q0, q0, [x19]
    4444:	3d800a60 	str	q0, [x19, #32]
    4448:	f9400bf3 	ldr	x19, [sp, #16]
    444c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4450:	d65f03c0 	ret

0000000000004454 <ad_raw_realloc>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	f90013f5 	str	x21, [sp, #32]
    4464:	b40005a1 	cbz	x1, 4518 <ad_raw_realloc+0xc4>
    4468:	aa0103f4 	mov	x20, x1
    446c:	2a0203f5 	mov	w21, w2
    4470:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbb0>
    4474:	d2800004 	mov	x4, #0x0                   	// #0
    4478:	91114025 	add	x5, x1, #0x450
    447c:	14000005 	b	4490 <ad_raw_realloc+0x3c>
    4480:	91000484 	add	x4, x4, #0x1
    4484:	910060a5 	add	x5, x5, #0x18
    4488:	f140049f 	cmp	x4, #0x1, lsl #12
    448c:	54000320 	b.eq	44f0 <ad_raw_realloc+0x9c>  // b.none
    4490:	f94000a6 	ldr	x6, [x5]
    4494:	eb06001f 	cmp	x0, x6
    4498:	54ffff41 	b.ne	4480 <ad_raw_realloc+0x2c>  // b.any
    449c:	8b040484 	add	x4, x4, x4, lsl #1
    44a0:	91114021 	add	x1, x1, #0x450
    44a4:	8b040c33 	add	x19, x1, x4, lsl #3
    44a8:	b4000080 	cbz	x0, 44b8 <ad_raw_realloc+0x64>
    44ac:	b9401261 	ldr	w1, [x19, #16]
    44b0:	6b15003f 	cmp	w1, w21
    44b4:	540002c1 	b.ne	450c <ad_raw_realloc+0xb8>  // b.any
    44b8:	aa1403e1 	mov	x1, x20
    44bc:	97fff8f5 	bl	2890 <realloc@plt>
    44c0:	aa0003ed 	mov	x13, x0
    44c4:	b40000c0 	cbz	x0, 44dc <ad_raw_realloc+0x88>
    44c8:	2a1503e3 	mov	w3, w21
    44cc:	aa1403e2 	mov	x2, x20
    44d0:	aa1303e0 	mov	x0, x19
    44d4:	aa0d03e1 	mov	x1, x13
    44d8:	97fffaae 	bl	2f90 <ad_raw_record>
    44dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    44e0:	aa0d03e0 	mov	x0, x13
    44e4:	f94013f5 	ldr	x21, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	f100001f 	cmp	x0, #0x0
    44f4:	f0000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    44f8:	910ce021 	add	x1, x1, #0x338
    44fc:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    4500:	910c8000 	add	x0, x0, #0x320
    4504:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4508:	97fffb9e 	bl	3380 <ad_raw_fail>
    450c:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    4510:	910de000 	add	x0, x0, #0x378
    4514:	97fffb9b 	bl	3380 <ad_raw_fail>
    4518:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    451c:	910d6000 	add	x0, x0, #0x358
    4520:	97fffb98 	bl	3380 <ad_raw_fail>

0000000000004524 <fwp_tape_buffers_release>:
    4524:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4528:	910003fd 	mov	x29, sp
    452c:	a90153f3 	stp	x19, x20, [sp, #16]
    4530:	aa0003f4 	mov	x20, x0
    4534:	f9401400 	ldr	x0, [x0, #40]
    4538:	a9025bf5 	stp	x21, x22, [sp, #32]
    453c:	b7f80560 	tbnz	x0, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4540:	f9401a93 	ldr	x19, [x20, #48]
    4544:	b7f80533 	tbnz	x19, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4548:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    454c:	eb01001f 	cmp	x0, x1
    4550:	540004c8 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4554:	8b000400 	add	x0, x0, x0, lsl #1
    4558:	d2a00101 	mov	x1, #0x80000               	// #524288
    455c:	d37df000 	lsl	x0, x0, #3
    4560:	cb000021 	sub	x1, x1, x0
    4564:	eb410e7f 	cmp	x19, x1, lsr #3
    4568:	54000408 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    456c:	8b130c13 	add	x19, x0, x19, lsl #3
    4570:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    4574:	910e4000 	add	x0, x0, #0x390
    4578:	97fff92e 	bl	2a30 <getenv@plt>
    457c:	b4000080 	cbz	x0, 458c <fwp_tape_buffers_release+0x68>
    4580:	39400001 	ldrb	w1, [x0]
    4584:	7100c03f 	cmp	w1, #0x30
    4588:	54000880 	b.eq	4698 <fwp_tape_buffers_release+0x174>  // b.none
    458c:	d1000661 	sub	x1, x19, #0x1
    4590:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4594:	eb00003f 	cmp	x1, x0
    4598:	54000328 	b.hi	45fc <fwp_tape_buffers_release+0xd8>  // b.pmore
    459c:	900000f5 	adrp	x21, 20000 <__data_start>
    45a0:	f9001bf7 	str	x23, [sp, #48]
    45a4:	910142b7 	add	x23, x21, #0x50
    45a8:	910382f6 	add	x22, x23, #0xe0
    45ac:	aa1603e0 	mov	x0, x22
    45b0:	97ffff95 	bl	4404 <fwp_tape_buffers_dispose>
    45b4:	ad400a81 	ldp	q1, q2, [x20]
    45b8:	f9008ef3 	str	x19, [x23, #280]
    45bc:	4f000400 	movi	v0.4s, #0x0
    45c0:	ad000ac1 	stp	q1, q2, [x22]
    45c4:	3dc00a81 	ldr	q1, [x20, #32]
    45c8:	3d800ac1 	str	q1, [x22, #32]
    45cc:	f9401a80 	ldr	x0, [x20, #48]
    45d0:	f9001ac0 	str	x0, [x22, #48]
    45d4:	f9001a9f 	str	xzr, [x20, #48]
    45d8:	ad000280 	stp	q0, q0, [x20]
    45dc:	3d800a80 	str	q0, [x20, #32]
    45e0:	f9401bf7 	ldr	x23, [sp, #48]
    45e4:	1400000b 	b	4610 <fwp_tape_buffers_release+0xec>
    45e8:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    45ec:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    45f0:	910e4000 	add	x0, x0, #0x390
    45f4:	97fff90f 	bl	2a30 <getenv@plt>
    45f8:	b5fffc40 	cbnz	x0, 4580 <fwp_tape_buffers_release+0x5c>
    45fc:	aa1403e0 	mov	x0, x20
    4600:	97ffff81 	bl	4404 <fwp_tape_buffers_dispose>
    4604:	900000f5 	adrp	x21, 20000 <__data_start>
    4608:	910142a0 	add	x0, x21, #0x50
    460c:	f9408c13 	ldr	x19, [x0, #280]
    4610:	910142a2 	add	x2, x21, #0x50
    4614:	f9409044 	ldr	x4, [x2, #288]
    4618:	a9400c45 	ldp	x5, x3, [x2]
    461c:	8b040481 	add	x1, x4, x4, lsl #1
    4620:	f9400840 	ldr	x0, [x2, #16]
    4624:	8b010881 	add	x1, x4, x1, lsl #2
    4628:	f9400c44 	ldr	x4, [x2, #24]
    462c:	8b0300a3 	add	x3, x5, x3
    4630:	d37df021 	lsl	x1, x1, #3
    4634:	8b040000 	add	x0, x0, x4
    4638:	8b030000 	add	x0, x0, x3
    463c:	eb05003f 	cmp	x1, x5
    4640:	54000321 	b.ne	46a4 <fwp_tape_buffers_release+0x180>  // b.any
    4644:	8b130023 	add	x3, x1, x19
    4648:	eb00007f 	cmp	x3, x0
    464c:	540002c8 	b.hi	46a4 <fwp_tape_buffers_release+0x180>  // b.pmore
    4650:	f9405c43 	ldr	x3, [x2, #184]
    4654:	f140087f 	cmp	x3, #0x2, lsl #12
    4658:	540002e0 	b.eq	46b4 <fwp_tape_buffers_release+0x190>  // b.none
    465c:	8b030464 	add	x4, x3, x3, lsl #1
    4660:	90000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    4664:	911140a5 	add	x5, x5, #0x450
    4668:	cb010000 	sub	x0, x0, x1
    466c:	d37df084 	lsl	x4, x4, #3
    4670:	cb130000 	sub	x0, x0, x19
    4674:	8b0400a6 	add	x6, x5, x4
    4678:	91000463 	add	x3, x3, #0x1
    467c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4680:	f82468a1 	str	x1, [x5, x4]
    4684:	a90080d3 	stp	x19, x0, [x6, #8]
    4688:	f9005c43 	str	x3, [x2, #184]
    468c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4690:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4694:	d65f03c0 	ret
    4698:	39400400 	ldrb	w0, [x0, #1]
    469c:	34fffb00 	cbz	w0, 45fc <fwp_tape_buffers_release+0xd8>
    46a0:	17ffffbb 	b	458c <fwp_tape_buffers_release+0x68>
    46a4:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    46a8:	910ea000 	add	x0, x0, #0x3a8
    46ac:	f9001bf7 	str	x23, [sp, #48]
    46b0:	97fffb34 	bl	3380 <ad_raw_fail>
    46b4:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    46b8:	910f6000 	add	x0, x0, #0x3d8
    46bc:	f9001bf7 	str	x23, [sp, #48]
    46c0:	97fffb30 	bl	3380 <ad_raw_fail>

00000000000046c4 <fwp_poll_events>:
    46c4:	d10103ff 	sub	sp, sp, #0x40
    46c8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    46cc:	f947f400 	ldr	x0, [x0, #4072]
    46d0:	a9027bfd 	stp	x29, x30, [sp, #32]
    46d4:	910083fd 	add	x29, sp, #0x20
    46d8:	a90353f3 	stp	x19, x20, [sp, #48]
    46dc:	900000f4 	adrp	x20, 20000 <__data_start>
    46e0:	f9400001 	ldr	x1, [x0]
    46e4:	f9000fe1 	str	x1, [sp, #24]
    46e8:	d2800001 	mov	x1, #0x0                   	// #0
    46ec:	97fffca5 	bl	3980 <fwp_now_ns>
    46f0:	91014281 	add	x1, x20, #0x50
    46f4:	f9409433 	ldr	x19, [x1, #296]
    46f8:	b4000e73 	cbz	x19, 48c4 <fwp_poll_events+0x200>
    46fc:	aa1303e1 	mov	x1, x19
    4700:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4704:	14000005 	b	4718 <fwp_poll_events+0x54>
    4708:	f9408821 	ldr	x1, [x1, #272]
    470c:	eb03005f 	cmp	x2, x3
    4710:	9a83d042 	csel	x2, x2, x3, le
    4714:	b40000c1 	cbz	x1, 472c <fwp_poll_events+0x68>
    4718:	f9403423 	ldr	x3, [x1, #104]
    471c:	b6ffff62 	tbz	x2, #63, 4708 <fwp_poll_events+0x44>
    4720:	f9408821 	ldr	x1, [x1, #272]
    4724:	aa0303e2 	mov	x2, x3
    4728:	b5ffff81 	cbnz	x1, 4718 <fwp_poll_events+0x54>
    472c:	b7f80cc2 	tbnz	x2, #63, 48c4 <fwp_poll_events+0x200>
    4730:	cb000042 	sub	x2, x2, x0
    4734:	f100005f 	cmp	x2, #0x0
    4738:	540005ad 	b.le	47ec <fwp_poll_events+0x128>
    473c:	d2869b60 	mov	x0, #0x34db                	// #13531
    4740:	d2884801 	mov	x1, #0x4240                	// #16960
    4744:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4748:	f2a001e1 	movk	x1, #0xf, lsl #16
    474c:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4750:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4754:	f2e86360 	movk	x0, #0x431b, lsl #48
    4758:	9b407c40 	smulh	x0, x2, x0
    475c:	9352fc00 	asr	x0, x0, #18
    4760:	cb82fc00 	sub	x0, x0, x2, asr #63
    4764:	9b018802 	msub	x2, x0, x1, x2
    4768:	f100005f 	cmp	x2, #0x0
    476c:	9a800400 	cinc	x0, x0, ne	// ne = any
    4770:	eb03001f 	cmp	x0, x3
    4774:	540009ec 	b.gt	48b0 <fwp_poll_events+0x1ec>
    4778:	340003a0 	cbz	w0, 47ec <fwp_poll_events+0x128>
    477c:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4780:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4784:	72a20c42 	movk	w2, #0x1062, lsl #16
    4788:	9ba27c02 	umull	x2, w0, w2
    478c:	d366fc43 	lsr	x3, x2, #38
    4790:	aa0303e2 	mov	x2, x3
    4794:	1b048063 	msub	w3, w3, w4, w0
    4798:	9b217c63 	smull	x3, w3, w1
    479c:	d2800001 	mov	x1, #0x0                   	// #0
    47a0:	910023e0 	add	x0, sp, #0x8
    47a4:	a9008fe2 	stp	x2, x3, [sp, #8]
    47a8:	97fff872 	bl	2970 <nanosleep@plt>
    47ac:	91014280 	add	x0, x20, #0x50
    47b0:	f9409413 	ldr	x19, [x0, #296]
    47b4:	97fffc73 	bl	3980 <fwp_now_ns>
    47b8:	aa0003e6 	mov	x6, x0
    47bc:	b50001d3 	cbnz	x19, 47f4 <fwp_poll_events+0x130>
    47c0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    47c4:	f947f400 	ldr	x0, [x0, #4072]
    47c8:	f9400fe2 	ldr	x2, [sp, #24]
    47cc:	f9400001 	ldr	x1, [x0]
    47d0:	eb010042 	subs	x2, x2, x1
    47d4:	d2800001 	mov	x1, #0x0                   	// #0
    47d8:	540008c1 	b.ne	48f0 <fwp_poll_events+0x22c>  // b.any
    47dc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    47e0:	a94353f3 	ldp	x19, x20, [sp, #48]
    47e4:	910103ff 	add	sp, sp, #0x40
    47e8:	d65f03c0 	ret
    47ec:	97fffc65 	bl	3980 <fwp_now_ns>
    47f0:	aa0003e6 	mov	x6, x0
    47f4:	4f000400 	movi	v0.4s, #0x0
    47f8:	91014288 	add	x8, x20, #0x50
    47fc:	52800027 	mov	w7, #0x1                   	// #1
    4800:	f9403661 	ldr	x1, [x19, #104]
    4804:	aa1303e5 	mov	x5, x19
    4808:	f9408a73 	ldr	x19, [x19, #272]
    480c:	eb06003f 	cmp	x1, x6
    4810:	5400032c 	b.gt	4874 <fwp_poll_events+0x1b0>
    4814:	394154a0 	ldrb	w0, [x5, #85]
    4818:	36000120 	tbz	w0, #0, 483c <fwp_poll_events+0x178>
    481c:	f94084a0 	ldr	x0, [x5, #264]
    4820:	b40003c0 	cbz	x0, 4898 <fwp_poll_events+0x1d4>
    4824:	f9008813 	str	x19, [x0, #272]
    4828:	b4000053 	cbz	x19, 4830 <fwp_poll_events+0x16c>
    482c:	f9008660 	str	x0, [x19, #264]
    4830:	910800a0 	add	x0, x5, #0x200
    4834:	390154bf 	strb	wzr, [x5, #85]
    4838:	3c908000 	stur	q0, [x0, #-248]
    483c:	f94030a0 	ldr	x0, [x5, #96]
    4840:	390158a7 	strb	w7, [x5, #86]
    4844:	f100001f 	cmp	x0, #0x0
    4848:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    484c:	5400018d 	b.le	487c <fwp_poll_events+0x1b8>
    4850:	f94028a0 	ldr	x0, [x5, #80]
    4854:	f2001c1f 	tst	x0, #0xff000000ff
    4858:	540000e1 	b.ne	4874 <fwp_poll_events+0x1b0>  // b.any
    485c:	f9406100 	ldr	x0, [x8, #192]
    4860:	390150a7 	strb	w7, [x5, #84]
    4864:	f90080bf 	str	xzr, [x5, #256]
    4868:	b40001e0 	cbz	x0, 48a4 <fwp_poll_events+0x1e0>
    486c:	f9006105 	str	x5, [x8, #192]
    4870:	f9008005 	str	x5, [x0, #256]
    4874:	b5fffc73 	cbnz	x19, 4800 <fwp_poll_events+0x13c>
    4878:	17ffffd2 	b	47c0 <fwp_poll_events+0xfc>
    487c:	394144a0 	ldrb	w0, [x5, #81]
    4880:	3707fe80 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    4884:	394140a0 	ldrb	w0, [x5, #80]
    4888:	3707fe40 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    488c:	aa0503e0 	mov	x0, x5
    4890:	97fffb98 	bl	36f0 <fwp_cancel_tree.part.0>
    4894:	17ffffef 	b	4850 <fwp_poll_events+0x18c>
    4898:	91014281 	add	x1, x20, #0x50
    489c:	f9009433 	str	x19, [x1, #296]
    48a0:	17ffffe2 	b	4828 <fwp_poll_events+0x164>
    48a4:	f9006105 	str	x5, [x8, #192]
    48a8:	f9006505 	str	x5, [x8, #200]
    48ac:	17fffff2 	b	4874 <fwp_poll_events+0x1b0>
    48b0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    48b4:	d2989362 	mov	x2, #0xc49b                	// #50331
    48b8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    48bc:	f2a00402 	movk	x2, #0x20, lsl #16
    48c0:	17ffffb7 	b	479c <fwp_poll_events+0xd8>
    48c4:	97fff9ec 	bl	3074 <fwp_flush>
    48c8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    48cc:	f947e863 	ldr	x3, [x3, #4048]
    48d0:	d2800562 	mov	x2, #0x2b                  	// #43
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    48dc:	910fe000 	add	x0, x0, #0x3f8
    48e0:	f9400063 	ldr	x3, [x3]
    48e4:	97fff82f 	bl	29a0 <fwrite@plt>
    48e8:	52800ca0 	mov	w0, #0x65                  	// #101
    48ec:	97fff799 	bl	2750 <exit@plt>
    48f0:	97fff7ec 	bl	28a0 <__stack_chk_fail@plt>

00000000000048f4 <fwp_rc_wide_dup>:
    48f4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    48f8:	910003fd 	mov	x29, sp
    48fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4900:	aa0003f3 	mov	x19, x0
    4904:	ca404400 	eor	x0, x0, x0, lsr #17
    4908:	f90013f5 	str	x21, [sp, #32]
    490c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4910:	ca402400 	eor	x0, x0, x0, lsr #9
    4914:	9118c2a2 	add	x2, x21, #0x630
    4918:	92401c00 	and	x0, x0, #0xff
    491c:	910a2403 	add	x3, x0, #0x289
    4920:	8b000c40 	add	x0, x2, x0, lsl #3
    4924:	8b030c54 	add	x20, x2, x3, lsl #3
    4928:	f94a2401 	ldr	x1, [x0, #5192]
    492c:	b50000a1 	cbnz	x1, 4940 <fwp_rc_wide_dup+0x4c>
    4930:	1400002d 	b	49e4 <fwp_rc_wide_dup+0xf0>
    4934:	91004034 	add	x20, x1, #0x10
    4938:	f9400821 	ldr	x1, [x1, #16]
    493c:	b4000241 	cbz	x1, 4984 <fwp_rc_wide_dup+0x90>
    4940:	f9400022 	ldr	x2, [x1]
    4944:	eb02027f 	cmp	x19, x2
    4948:	54ffff61 	b.ne	4934 <fwp_rc_wide_dup+0x40>  // b.any
    494c:	f9400281 	ldr	x1, [x20]
    4950:	39400260 	ldrb	w0, [x19]
    4954:	7103f81f 	cmp	w0, #0xfe
    4958:	54000220 	b.eq	499c <fwp_rc_wide_dup+0xa8>  // b.none
    495c:	b40001a1 	cbz	x1, 4990 <fwp_rc_wide_dup+0x9c>
    4960:	f9400420 	ldr	x0, [x1, #8]
    4964:	b100041f 	cmn	x0, #0x1
    4968:	540004a0 	b.eq	49fc <fwp_rc_wide_dup+0x108>  // b.none
    496c:	91000400 	add	x0, x0, #0x1
    4970:	f9000420 	str	x0, [x1, #8]
    4974:	a94153f3 	ldp	x19, x20, [sp, #16]
    4978:	f94013f5 	ldr	x21, [sp, #32]
    497c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4980:	d65f03c0 	ret
    4984:	39400260 	ldrb	w0, [x19]
    4988:	7103f81f 	cmp	w0, #0xfe
    498c:	540000a0 	b.eq	49a0 <fwp_rc_wide_dup+0xac>  // b.none
    4990:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    4994:	91114000 	add	x0, x0, #0x450
    4998:	97fffb9a 	bl	3800 <fwp_trap>
    499c:	b5000281 	cbnz	x1, 49ec <fwp_rc_wide_dup+0xf8>
    49a0:	d2800300 	mov	x0, #0x18                  	// #24
    49a4:	97fff7a7 	bl	2840 <malloc@plt>
    49a8:	b4000280 	cbz	x0, 49f8 <fwp_rc_wide_dup+0x104>
    49ac:	d2801fe1 	mov	x1, #0xff                  	// #255
    49b0:	a9000413 	stp	x19, x1, [x0]
    49b4:	9118c2b5 	add	x21, x21, #0x630
    49b8:	f900081f 	str	xzr, [x0, #16]
    49bc:	12800001 	mov	w1, #0xffffffff            	// #-1
    49c0:	f9000280 	str	x0, [x20]
    49c4:	39000261 	strb	w1, [x19]
    49c8:	f94e26a0 	ldr	x0, [x21, #7240]
    49cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    49d0:	91000400 	add	x0, x0, #0x1
    49d4:	f90e26a0 	str	x0, [x21, #7240]
    49d8:	f94013f5 	ldr	x21, [sp, #32]
    49dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49e0:	d65f03c0 	ret
    49e4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    49e8:	17ffffda 	b	4950 <fwp_rc_wide_dup+0x5c>
    49ec:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    49f0:	9110a000 	add	x0, x0, #0x428
    49f4:	97fffb83 	bl	3800 <fwp_trap>
    49f8:	97fff9de 	bl	3170 <fwp_heap_oom>
    49fc:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    4a00:	9111e000 	add	x0, x0, #0x478
    4a04:	97fffb7f 	bl	3800 <fwp_trap>
    4a08:	d503201f 	nop
    4a0c:	d503201f 	nop

0000000000004a10 <fwp_rc_forget_slot>:
    4a10:	aa0003e1 	mov	x1, x0
    4a14:	39400000 	ldrb	w0, [x0]
    4a18:	7103fc1f 	cmp	w0, #0xff
    4a1c:	54000040 	b.eq	4a24 <fwp_rc_forget_slot+0x14>  // b.none
    4a20:	d65f03c0 	ret
    4a24:	ca414420 	eor	x0, x1, x1, lsr #17
    4a28:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4a2c:	ca402400 	eor	x0, x0, x0, lsr #9
    4a30:	910003fd 	mov	x29, sp
    4a34:	92401c00 	and	x0, x0, #0xff
    4a38:	f9000bf3 	str	x19, [sp, #16]
    4a3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4a40:	9118c262 	add	x2, x19, #0x630
    4a44:	910a2403 	add	x3, x0, #0x289
    4a48:	8b000c40 	add	x0, x2, x0, lsl #3
    4a4c:	8b030c43 	add	x3, x2, x3, lsl #3
    4a50:	f94a2400 	ldr	x0, [x0, #5192]
    4a54:	b50000a0 	cbnz	x0, 4a68 <fwp_rc_forget_slot+0x58>
    4a58:	14000011 	b	4a9c <fwp_rc_forget_slot+0x8c>
    4a5c:	91004003 	add	x3, x0, #0x10
    4a60:	f9400800 	ldr	x0, [x0, #16]
    4a64:	b40001c0 	cbz	x0, 4a9c <fwp_rc_forget_slot+0x8c>
    4a68:	f9400002 	ldr	x2, [x0]
    4a6c:	eb02003f 	cmp	x1, x2
    4a70:	54ffff61 	b.ne	4a5c <fwp_rc_forget_slot+0x4c>  // b.any
    4a74:	f9400801 	ldr	x1, [x0, #16]
    4a78:	9118c273 	add	x19, x19, #0x630
    4a7c:	f9000061 	str	x1, [x3]
    4a80:	97fff7b8 	bl	2960 <free@plt>
    4a84:	f94e2660 	ldr	x0, [x19, #7240]
    4a88:	d1000400 	sub	x0, x0, #0x1
    4a8c:	f90e2660 	str	x0, [x19, #7240]
    4a90:	f9400bf3 	ldr	x19, [sp, #16]
    4a94:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a98:	d65f03c0 	ret
    4a9c:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    4aa0:	91114000 	add	x0, x0, #0x450
    4aa4:	97fffb57 	bl	3800 <fwp_trap>
    4aa8:	d503201f 	nop
    4aac:	d503201f 	nop

0000000000004ab0 <fwp_rc_prepare_chunk>:
    4ab0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ab4:	910003fd 	mov	x29, sp
    4ab8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4abc:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    4ac0:	9118c2c2 	add	x2, x22, #0x630
    4ac4:	b9401c03 	ldr	w3, [x0, #28]
    4ac8:	aa0103f5 	mov	x21, x1
    4acc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ad0:	aa0003f4 	mov	x20, x0
    4ad4:	f94e2440 	ldr	x0, [x2, #7240]
    4ad8:	b4000440 	cbz	x0, 4b60 <fwp_rc_prepare_chunk+0xb0>
    4adc:	d2800013 	mov	x19, #0x0                   	// #0
    4ae0:	35000203 	cbnz	w3, 4b20 <fwp_rc_prepare_chunk+0x70>
    4ae4:	b4000361 	cbz	x1, 4b50 <fwp_rc_prepare_chunk+0xa0>
    4ae8:	f9401280 	ldr	x0, [x20, #32]
    4aec:	97fff79d 	bl	2960 <free@plt>
    4af0:	aa1503e0 	mov	x0, x21
    4af4:	d2800021 	mov	x1, #0x1                   	// #1
    4af8:	97fff762 	bl	2880 <calloc@plt>
    4afc:	f9001280 	str	x0, [x20, #32]
    4b00:	b5000460 	cbnz	x0, 4b8c <fwp_rc_prepare_chunk+0xdc>
    4b04:	97fff99b 	bl	3170 <fwp_heap_oom>
    4b08:	97ffffc2 	bl	4a10 <fwp_rc_forget_slot>
    4b0c:	91000673 	add	x19, x19, #0x1
    4b10:	b9401e83 	ldr	w3, [x20, #28]
    4b14:	eb13007f 	cmp	x3, x19
    4b18:	54000169 	b.ls	4b44 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4b1c:	d503201f 	nop
    4b20:	f9401283 	ldr	x3, [x20, #32]
    4b24:	8b130060 	add	x0, x3, x19
    4b28:	38736863 	ldrb	w3, [x3, x19]
    4b2c:	7103fc7f 	cmp	w3, #0xff
    4b30:	54fffec0 	b.eq	4b08 <fwp_rc_prepare_chunk+0x58>  // b.none
    4b34:	b9401e83 	ldr	w3, [x20, #28]
    4b38:	91000673 	add	x19, x19, #0x1
    4b3c:	eb13007f 	cmp	x3, x19
    4b40:	54ffff08 	b.hi	4b20 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4b44:	eb0302bf 	cmp	x21, x3
    4b48:	54000121 	b.ne	4b6c <fwp_rc_prepare_chunk+0xbc>  // b.any
    4b4c:	b5000335 	cbnz	x21, 4bb0 <fwp_rc_prepare_chunk+0x100>
    4b50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b5c:	d65f03c0 	ret
    4b60:	2a0303e3 	mov	w3, w3
    4b64:	eb0302bf 	cmp	x21, x3
    4b68:	54ffff20 	b.eq	4b4c <fwp_rc_prepare_chunk+0x9c>  // b.none
    4b6c:	9118c2c2 	add	x2, x22, #0x630
    4b70:	f9401280 	ldr	x0, [x20, #32]
    4b74:	f94e2841 	ldr	x1, [x2, #7248]
    4b78:	cb030021 	sub	x1, x1, x3
    4b7c:	f90e2841 	str	x1, [x2, #7248]
    4b80:	97fff778 	bl	2960 <free@plt>
    4b84:	b5fffb75 	cbnz	x21, 4af0 <fwp_rc_prepare_chunk+0x40>
    4b88:	f900129f 	str	xzr, [x20, #32]
    4b8c:	9118c2d6 	add	x22, x22, #0x630
    4b90:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b94:	b9001e95 	str	w21, [x20, #28]
    4b98:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b9c:	8b150000 	add	x0, x0, x21
    4ba0:	f90e2ac0 	str	x0, [x22, #7248]
    4ba4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ba8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bac:	d65f03c0 	ret
    4bb0:	f9401280 	ldr	x0, [x20, #32]
    4bb4:	aa1503e2 	mov	x2, x21
    4bb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bbc:	52800001 	mov	w1, #0x0                   	// #0
    4bc0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bc4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bc8:	17fff72a 	b	2870 <memset@plt>
    4bcc:	d503201f 	nop

0000000000004bd0 <fwp_heap_refill>:
    4bd0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4bd4:	910003fd 	mov	x29, sp
    4bd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4bdc:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4be0:	9118c2b5 	add	x21, x21, #0x630
    4be4:	aa0003f6 	mov	x22, x0
    4be8:	d2800020 	mov	x0, #0x1                   	// #1
    4bec:	a90153f3 	stp	x19, x20, [sp, #16]
    4bf0:	a90363f7 	stp	x23, x24, [sp, #48]
    4bf4:	2a0103f7 	mov	w23, w1
    4bf8:	2a0203f8 	mov	w24, w2
    4bfc:	97fff96d 	bl	31b0 <fwp_heap_chunks>
    4c00:	aa0003f3 	mov	x19, x0
    4c04:	f949fea2 	ldr	x2, [x21, #5112]
    4c08:	8b000800 	add	x0, x0, x0, lsl #2
    4c0c:	2a1703e1 	mov	w1, w23
    4c10:	52800025 	mov	w5, #0x1                   	// #1
    4c14:	d37df000 	lsl	x0, x0, #3
    4c18:	910f0021 	add	x1, x1, #0x3c0
    4c1c:	8b000054 	add	x20, x2, x0
    4c20:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4c24:	52a00024 	mov	w4, #0x10000               	// #65536
    4c28:	38206845 	strb	w5, [x2, x0]
    4c2c:	aa1403e0 	mov	x0, x20
    4c30:	39000698 	strb	w24, [x20, #1]
    4c34:	39000a97 	strb	w23, [x20, #2]
    4c38:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4c3c:	b9000681 	str	w1, [x20, #4]
    4c40:	2a0103e5 	mov	w5, w1
    4c44:	8b0300a2 	add	x2, x5, x3
    4c48:	1ac10881 	udiv	w1, w4, w1
    4c4c:	9ac50842 	udiv	x2, x2, x5
    4c50:	b9000a81 	str	w1, [x20, #8]
    4c54:	92404021 	and	x1, x1, #0x1ffff
    4c58:	b9001a82 	str	w2, [x20, #24]
    4c5c:	97ffff95 	bl	4ab0 <fwp_rc_prepare_chunk>
    4c60:	f949daa0 	ldr	x0, [x21, #5040]
    4c64:	29408a81 	ldp	w1, w2, [x20, #4]
    4c68:	8b134000 	add	x0, x0, x19, lsl #16
    4c6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c70:	8b214003 	add	x3, x0, w1, uxtw
    4c74:	9ba20021 	umaddl	x1, w1, w2, x0
    4c78:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c7c:	a90086c3 	stp	x3, x1, [x22, #8]
    4c80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c84:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c88:	d65f03c0 	ret
    4c8c:	d503201f 	nop

0000000000004c90 <fwp_mem_free>:
    4c90:	b40003c0 	cbz	x0, 4d08 <fwp_mem_free+0x78>
    4c94:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c98:	910003fd 	mov	x29, sp
    4c9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ca0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4ca4:	9118c2a1 	add	x1, x21, #0x630
    4ca8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cac:	aa0003f3 	mov	x19, x0
    4cb0:	f949d823 	ldr	x3, [x1, #5040]
    4cb4:	f949ec22 	ldr	x2, [x1, #5080]
    4cb8:	cb030000 	sub	x0, x0, x3
    4cbc:	eb02401f 	cmp	x0, x2, lsl #16
    4cc0:	540001c2 	b.cs	4cf8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4cc4:	d350fc16 	lsr	x22, x0, #16
    4cc8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ccc:	f949fc22 	ldr	x2, [x1, #5112]
    4cd0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4cd4:	d37df294 	lsl	x20, x20, #3
    4cd8:	ab140057 	adds	x23, x2, x20
    4cdc:	540000c0 	b.eq	4cf4 <fwp_mem_free+0x64>  // b.none
    4ce0:	38746842 	ldrb	w2, [x2, x20]
    4ce4:	7100045f 	cmp	w2, #0x1
    4ce8:	54000120 	b.eq	4d0c <fwp_mem_free+0x7c>  // b.none
    4cec:	7100085f 	cmp	w2, #0x2
    4cf0:	540005e0 	b.eq	4dac <fwp_mem_free+0x11c>  // b.none
    4cf4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d00:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d04:	d65f03c0 	ret
    4d08:	d65f03c0 	ret
    4d0c:	f94012f8 	ldr	x24, [x23, #32]
    4d10:	b94006e1 	ldr	w1, [x23, #4]
    4d14:	f90023f9 	str	x25, [sp, #64]
    4d18:	2a0103e2 	mov	w2, w1
    4d1c:	394006f9 	ldrb	w25, [x23, #1]
    4d20:	39400af4 	ldrb	w20, [x23, #2]
    4d24:	b4000158 	cbz	x24, 4d4c <fwp_mem_free+0xbc>
    4d28:	92403e76 	and	x22, x19, #0xffff
    4d2c:	9ac20ad6 	udiv	x22, x22, x2
    4d30:	38766b01 	ldrb	w1, [x24, x22]
    4d34:	8b160300 	add	x0, x24, x22
    4d38:	7103fc3f 	cmp	w1, #0xff
    4d3c:	54000980 	b.eq	4e6c <fwp_mem_free+0x1dc>  // b.none
    4d40:	38366b1f 	strb	wzr, [x24, x22]
    4d44:	b94006e1 	ldr	w1, [x23, #4]
    4d48:	2a0103e2 	mov	w2, w1
    4d4c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4d50:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4d54:	cb390000 	sub	x0, x0, w25, uxtb
    4d58:	8b340074 	add	x20, x3, w20, uxtb
    4d5c:	9118c2b5 	add	x21, x21, #0x630
    4d60:	1e630021 	ucvtf	d1, w1
    4d64:	d37ae400 	lsl	x0, x0, #6
    4d68:	8b140c14 	add	x20, x0, x20, lsl #3
    4d6c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d70:	f8746aa0 	ldr	x0, [x21, x20]
    4d74:	f94023f9 	ldr	x25, [sp, #64]
    4d78:	aa2003e0 	mvn	x0, x0
    4d7c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d80:	f9000260 	str	x0, [x19]
    4d84:	f8346ab3 	str	x19, [x21, x20]
    4d88:	f94a12a0 	ldr	x0, [x21, #5152]
    4d8c:	1e612800 	fadd	d0, d0, d1
    4d90:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d94:	cb020000 	sub	x0, x0, x2
    4d98:	f90a12a0 	str	x0, [x21, #5152]
    4d9c:	fd0a22a0 	str	d0, [x21, #5184]
    4da0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4da4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4da8:	d65f03c0 	ret
    4dac:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4db0:	8b000063 	add	x3, x3, x0
    4db4:	eb03027f 	cmp	x19, x3
    4db8:	54fff9e1 	b.ne	4cf4 <fwp_mem_free+0x64>  // b.any
    4dbc:	fd400ae1 	ldr	d1, [x23, #16]
    4dc0:	fd4a2020 	ldr	d0, [x1, #5184]
    4dc4:	f9400ae0 	ldr	x0, [x23, #16]
    4dc8:	7e61d821 	ucvtf	d1, d1
    4dcc:	f94a1022 	ldr	x2, [x1, #5152]
    4dd0:	f94012f3 	ldr	x19, [x23, #32]
    4dd4:	1e612800 	fadd	d0, d0, d1
    4dd8:	cb000042 	sub	x2, x2, x0
    4ddc:	f90a1022 	str	x2, [x1, #5152]
    4de0:	fd0a2020 	str	d0, [x1, #5184]
    4de4:	b40000b3 	cbz	x19, 4df8 <fwp_mem_free+0x168>
    4de8:	39400260 	ldrb	w0, [x19]
    4dec:	7103fc1f 	cmp	w0, #0xff
    4df0:	54000380 	b.eq	4e60 <fwp_mem_free+0x1d0>  // b.none
    4df4:	3900027f 	strb	wzr, [x19]
    4df8:	b9400ee2 	ldr	w2, [x23, #12]
    4dfc:	b4000142 	cbz	x2, 4e24 <fwp_mem_free+0x194>
    4e00:	9118c2a1 	add	x1, x21, #0x630
    4e04:	8b160040 	add	x0, x2, x22
    4e08:	8b000800 	add	x0, x0, x0, lsl #2
    4e0c:	f949fc21 	ldr	x1, [x1, #5112]
    4e10:	8b140034 	add	x20, x1, x20
    4e14:	8b000c20 	add	x0, x1, x0, lsl #3
    4e18:	3802869f 	strb	wzr, [x20], #40
    4e1c:	eb00029f 	cmp	x20, x0
    4e20:	54ffffc1 	b.ne	4e18 <fwp_mem_free+0x188>  // b.any
    4e24:	9118c2a0 	add	x0, x21, #0x630
    4e28:	f94a1801 	ldr	x1, [x0, #5168]
    4e2c:	f949f803 	ldr	x3, [x0, #5104]
    4e30:	8b020021 	add	x1, x1, x2
    4e34:	f90a1801 	str	x1, [x0, #5168]
    4e38:	eb16007f 	cmp	x3, x22
    4e3c:	54000049 	b.ls	4e44 <fwp_mem_free+0x1b4>  // b.plast
    4e40:	f909f816 	str	x22, [x0, #5104]
    4e44:	9118c2b5 	add	x21, x21, #0x630
    4e48:	f949f6a0 	ldr	x0, [x21, #5096]
    4e4c:	eb16001f 	cmp	x0, x22
    4e50:	54fff529 	b.ls	4cf4 <fwp_mem_free+0x64>  // b.plast
    4e54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e58:	f909f6b6 	str	x22, [x21, #5096]
    4e5c:	17ffffa7 	b	4cf8 <fwp_mem_free+0x68>
    4e60:	aa1303e0 	mov	x0, x19
    4e64:	97fffeeb 	bl	4a10 <fwp_rc_forget_slot>
    4e68:	17ffffe3 	b	4df4 <fwp_mem_free+0x164>
    4e6c:	97fffee9 	bl	4a10 <fwp_rc_forget_slot>
    4e70:	17ffffb4 	b	4d40 <fwp_mem_free+0xb0>

0000000000004e74 <fwp_heap_alloc_big>:
    4e74:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e78:	910003fd 	mov	x29, sp
    4e7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4e80:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e84:	a90363f7 	stp	x23, x24, [sp, #48]
    4e88:	aa0003f7 	mov	x23, x0
    4e8c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e90:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e94:	eb0002ff 	cmp	x23, x0
    4e98:	54000888 	b.hi	4fa8 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e9c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4ea0:	8b0002f4 	add	x20, x23, x0
    4ea4:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbb0>
    4ea8:	9118c359 	add	x25, x26, #0x630
    4eac:	d350fe94 	lsr	x20, x20, #16
    4eb0:	2a0103f5 	mov	w21, w1
    4eb4:	aa1403e0 	mov	x0, x20
    4eb8:	97fff8be 	bl	31b0 <fwp_heap_chunks>
    4ebc:	f949ff22 	ldr	x2, [x25, #5112]
    4ec0:	8b000813 	add	x19, x0, x0, lsl #2
    4ec4:	aa0003f8 	mov	x24, x0
    4ec8:	52800043 	mov	w3, #0x2                   	// #2
    4ecc:	d37df273 	lsl	x19, x19, #3
    4ed0:	d2800021 	mov	x1, #0x1                   	// #1
    4ed4:	8b130040 	add	x0, x2, x19
    4ed8:	38336843 	strb	w3, [x2, x19]
    4edc:	39000415 	strb	w21, [x0, #1]
    4ee0:	b9000c14 	str	w20, [x0, #12]
    4ee4:	f9000817 	str	x23, [x0, #16]
    4ee8:	97fffef2 	bl	4ab0 <fwp_rc_prepare_chunk>
    4eec:	f100069f 	cmp	x20, #0x1
    4ef0:	54000269 	b.ls	4f3c <fwp_heap_alloc_big+0xc8>  // b.plast
    4ef4:	8b180294 	add	x20, x20, x24
    4ef8:	9100a273 	add	x19, x19, #0x28
    4efc:	a90573fb 	stp	x27, x28, [sp, #80]
    4f00:	5280007b 	mov	w27, #0x3                   	// #3
    4f04:	8b140a94 	add	x20, x20, x20, lsl #2
    4f08:	2a1803fc 	mov	w28, w24
    4f0c:	9adb2296 	lsl	x22, x20, x27
    4f10:	f949ff35 	ldr	x21, [x25, #5112]
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	8b1302b4 	add	x20, x21, x19
    4f1c:	aa1403e0 	mov	x0, x20
    4f20:	97fffee4 	bl	4ab0 <fwp_rc_prepare_chunk>
    4f24:	38336abb 	strb	w27, [x21, x19]
    4f28:	9100a273 	add	x19, x19, #0x28
    4f2c:	b9000e9c 	str	w28, [x20, #12]
    4f30:	eb1302df 	cmp	x22, x19
    4f34:	54fffee1 	b.ne	4f10 <fwp_heap_alloc_big+0x9c>  // b.any
    4f38:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f3c:	9118c353 	add	x19, x26, #0x630
    4f40:	aa1703e2 	mov	x2, x23
    4f44:	52800001 	mov	w1, #0x0                   	// #0
    4f48:	f949da60 	ldr	x0, [x19, #5040]
    4f4c:	8b184018 	add	x24, x0, x24, lsl #16
    4f50:	aa1803e0 	mov	x0, x24
    4f54:	97fff647 	bl	2870 <memset@plt>
    4f58:	f94a1260 	ldr	x0, [x19, #5152]
    4f5c:	ab170000 	adds	x0, x0, x23
    4f60:	54000242 	b.cs	4fa8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4f64:	f94a1661 	ldr	x1, [x19, #5160]
    4f68:	f90a1260 	str	x0, [x19, #5152]
    4f6c:	eb01001f 	cmp	x0, x1
    4f70:	54000049 	b.ls	4f78 <fwp_heap_alloc_big+0x104>  // b.plast
    4f74:	f90a1660 	str	x0, [x19, #5160]
    4f78:	9118c35a 	add	x26, x26, #0x630
    4f7c:	9e6202e0 	scvtf	d0, x23
    4f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f84:	aa1803e0 	mov	x0, x24
    4f88:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f90:	1e602820 	fadd	d0, d1, d0
    4f94:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f98:	fd0a1f40 	str	d0, [x26, #5176]
    4f9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4fa4:	d65f03c0 	ret
    4fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    4fac:	97fff871 	bl	3170 <fwp_heap_oom>

0000000000004fb0 <fwp_heap_alloc_slow>:
    4fb0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fb4:	910003fd 	mov	x29, sp
    4fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fbc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4fc0:	9118c262 	add	x2, x19, #0x630
    4fc4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fc8:	aa0003f5 	mov	x21, x0
    4fcc:	2a0103f4 	mov	w20, w1
    4fd0:	b953a440 	ldr	w0, [x2, #5028]
    4fd4:	34000600 	cbz	w0, 5094 <fwp_heap_alloc_slow+0xe4>
    4fd8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fdc:	54000628 	b.hi	50a0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fe0:	91003ea0 	add	x0, x21, #0xf
    4fe4:	9118c262 	add	x2, x19, #0x630
    4fe8:	f9001bf7 	str	x23, [sp, #48]
    4fec:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ff0:	8b401040 	add	x0, x2, x0, lsr #4
    4ff4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ff8:	d37ae484 	lsl	x4, x4, #6
    4ffc:	397e8003 	ldrb	w3, [x0, #4000]
    5000:	910f0060 	add	x0, x3, #0x3c0
    5004:	aa0303e1 	mov	x1, x3
    5008:	8b030463 	add	x3, x3, x3, lsl #1
    500c:	8b030c83 	add	x3, x4, x3, lsl #3
    5010:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5014:	2a1703f6 	mov	w22, w23
    5018:	f8636844 	ldr	x4, [x2, x3]
    501c:	b40004e4 	cbz	x4, 50b8 <fwp_heap_alloc_slow+0x108>
    5020:	f9400080 	ldr	x0, [x4]
    5024:	aa2003e0 	mvn	x0, x0
    5028:	f8236840 	str	x0, [x2, x3]
    502c:	7100069f 	cmp	w20, #0x1
    5030:	aa0403e0 	mov	x0, x4
    5034:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5038:	52800001 	mov	w1, #0x0                   	// #0
    503c:	97fff60d 	bl	2870 <memset@plt>
    5040:	aa0003e4 	mov	x4, x0
    5044:	9118c260 	add	x0, x19, #0x630
    5048:	f94a1001 	ldr	x1, [x0, #5152]
    504c:	ab160021 	adds	x1, x1, x22
    5050:	540005c2 	b.cs	5108 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5054:	f94a1402 	ldr	x2, [x0, #5160]
    5058:	f90a1001 	str	x1, [x0, #5152]
    505c:	eb02003f 	cmp	x1, x2
    5060:	54000049 	b.ls	5068 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5064:	f90a1401 	str	x1, [x0, #5160]
    5068:	9118c273 	add	x19, x19, #0x630
    506c:	1e6302e1 	ucvtf	d1, w23
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	aa0403e0 	mov	x0, x4
    5078:	fd4a1e60 	ldr	d0, [x19, #5176]
    507c:	f9401bf7 	ldr	x23, [sp, #48]
    5080:	1e612800 	fadd	d0, d0, d1
    5084:	fd0a1e60 	str	d0, [x19, #5176]
    5088:	a94153f3 	ldp	x19, x20, [sp, #16]
    508c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5090:	d65f03c0 	ret
    5094:	97fffc1c 	bl	4104 <fwp_heap_init>
    5098:	f14012bf 	cmp	x21, #0x4, lsl #12
    509c:	54fffa29 	b.ls	4fe0 <fwp_heap_alloc_slow+0x30>  // b.plast
    50a0:	2a1403e1 	mov	w1, w20
    50a4:	aa1503e0 	mov	x0, x21
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50b4:	17ffff70 	b	4e74 <fwp_heap_alloc_big>
    50b8:	8b030042 	add	x2, x2, x3
    50bc:	f9400444 	ldr	x4, [x2, #8]
    50c0:	b4000104 	cbz	x4, 50e0 <fwp_heap_alloc_slow+0x130>
    50c4:	f9400840 	ldr	x0, [x2, #16]
    50c8:	cb040000 	sub	x0, x0, x4
    50cc:	eb16001f 	cmp	x0, x22
    50d0:	54000083 	b.cc	50e0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50d4:	8b160080 	add	x0, x4, x22
    50d8:	f9000440 	str	x0, [x2, #8]
    50dc:	17ffffd4 	b	502c <fwp_heap_alloc_slow+0x7c>
    50e0:	52800302 	mov	w2, #0x18                  	// #24
    50e4:	52807804 	mov	w4, #0x3c0                 	// #960
    50e8:	9118c260 	add	x0, x19, #0x630
    50ec:	9ba27c23 	umull	x3, w1, w2
    50f0:	2a1403e2 	mov	w2, w20
    50f4:	9b240e84 	smaddl	x4, w20, w4, x3
    50f8:	8b040000 	add	x0, x0, x4
    50fc:	97fffeb5 	bl	4bd0 <fwp_heap_refill>
    5100:	aa0003e4 	mov	x4, x0
    5104:	17ffffca 	b	502c <fwp_heap_alloc_slow+0x7c>
    5108:	97fff81a 	bl	3170 <fwp_heap_oom>
    510c:	d503201f 	nop

0000000000005110 <fwp_heap_alloc>:
    5110:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5114:	910003fd 	mov	x29, sp
    5118:	a9025bf5 	stp	x21, x22, [sp, #32]
    511c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5120:	910142c2 	add	x2, x22, #0x50
    5124:	a90363f7 	stp	x23, x24, [sp, #48]
    5128:	b9413058 	ldr	w24, [x2, #304]
    512c:	a90153f3 	stp	x19, x20, [sp, #16]
    5130:	7100031f 	cmp	w24, #0x0
    5134:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5138:	54000861 	b.ne	5244 <fwp_heap_alloc+0x134>  // b.any
    513c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    5140:	9118c2f3 	add	x19, x23, #0x630
    5144:	f140101f 	cmp	x0, #0x4, lsl #12
    5148:	b953a662 	ldr	w2, [x19, #5028]
    514c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5150:	54000740 	b.eq	5238 <fwp_heap_alloc+0x128>  // b.none
    5154:	91003c03 	add	x3, x0, #0xf
    5158:	937c7c22 	sbfiz	x2, x1, #4, #32
    515c:	cb21c042 	sub	x2, x2, w1, sxtw
    5160:	8b431263 	add	x3, x19, x3, lsr #4
    5164:	d37ae442 	lsl	x2, x2, #6
    5168:	397e8063 	ldrb	w3, [x3, #4000]
    516c:	910f0064 	add	x4, x3, #0x3c0
    5170:	8b030463 	add	x3, x3, x3, lsl #1
    5174:	8b030c43 	add	x3, x2, x3, lsl #3
    5178:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    517c:	2a1503f4 	mov	w20, w21
    5180:	f8636a64 	ldr	x4, [x19, x3]
    5184:	b40004c4 	cbz	x4, 521c <fwp_heap_alloc+0x10c>
    5188:	f9400085 	ldr	x5, [x4]
    518c:	7100043f 	cmp	w1, #0x1
    5190:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5194:	aa0403e0 	mov	x0, x4
    5198:	aa2503e5 	mvn	x5, x5
    519c:	52800001 	mov	w1, #0x0                   	// #0
    51a0:	f8236a65 	str	x5, [x19, x3]
    51a4:	97fff5b3 	bl	2870 <memset@plt>
    51a8:	aa0003e4 	mov	x4, x0
    51ac:	f94a1260 	ldr	x0, [x19, #5152]
    51b0:	ab140000 	adds	x0, x0, x20
    51b4:	540006e2 	b.cs	5290 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    51b8:	f94a1661 	ldr	x1, [x19, #5160]
    51bc:	f90a1260 	str	x0, [x19, #5152]
    51c0:	eb01001f 	cmp	x0, x1
    51c4:	54000049 	b.ls	51cc <fwp_heap_alloc+0xbc>  // b.plast
    51c8:	f90a1660 	str	x0, [x19, #5160]
    51cc:	9118c2e0 	add	x0, x23, #0x630
    51d0:	1e6302a1 	ucvtf	d1, w21
    51d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51d8:	1e612800 	fadd	d0, d0, d1
    51dc:	fd0a1c00 	str	d0, [x0, #5176]
    51e0:	34000138 	cbz	w24, 5204 <fwp_heap_alloc+0xf4>
    51e4:	9118c2e1 	add	x1, x23, #0x630
    51e8:	910142c0 	add	x0, x22, #0x50
    51ec:	fd4a1020 	ldr	d0, [x1, #5152]
    51f0:	6d548402 	ldp	d2, d1, [x0, #328]
    51f4:	7e61d800 	ucvtf	d0, d0
    51f8:	1e623800 	fsub	d0, d0, d2
    51fc:	1e612010 	fcmpe	d0, d1
    5200:	540002cc 	b.gt	5258 <fwp_heap_alloc+0x148>
    5204:	a94153f3 	ldp	x19, x20, [sp, #16]
    5208:	aa0403e0 	mov	x0, x4
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	a94363f7 	ldp	x23, x24, [sp, #48]
    5214:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5218:	d65f03c0 	ret
    521c:	8b030263 	add	x3, x19, x3
    5220:	f9400464 	ldr	x4, [x3, #8]
    5224:	b40000a4 	cbz	x4, 5238 <fwp_heap_alloc+0x128>
    5228:	f9400862 	ldr	x2, [x3, #16]
    522c:	cb040042 	sub	x2, x2, x4
    5230:	eb02029f 	cmp	x20, x2
    5234:	54000209 	b.ls	5274 <fwp_heap_alloc+0x164>  // b.plast
    5238:	97ffff5e 	bl	4fb0 <fwp_heap_alloc_slow>
    523c:	aa0003e4 	mov	x4, x0
    5240:	17ffffe8 	b	51e0 <fwp_heap_alloc+0xd0>
    5244:	a9538c44 	ldp	x4, x3, [x2, #312]
    5248:	91000484 	add	x4, x4, #0x1
    524c:	8b000063 	add	x3, x3, x0
    5250:	a9138c44 	stp	x4, x3, [x2, #312]
    5254:	17ffffba 	b	513c <fwp_heap_alloc+0x2c>
    5258:	a94153f3 	ldp	x19, x20, [sp, #16]
    525c:	fd00a800 	str	d0, [x0, #336]
    5260:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5264:	aa0403e0 	mov	x0, x4
    5268:	a94363f7 	ldp	x23, x24, [sp, #48]
    526c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5270:	d65f03c0 	ret
    5274:	7100043f 	cmp	w1, #0x1
    5278:	8b140085 	add	x5, x4, x20
    527c:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5280:	52800001 	mov	w1, #0x0                   	// #0
    5284:	aa0403e0 	mov	x0, x4
    5288:	f9000465 	str	x5, [x3, #8]
    528c:	17ffffc6 	b	51a4 <fwp_heap_alloc+0x94>
    5290:	97fff7b8 	bl	3170 <fwp_heap_oom>

0000000000005294 <fwp_data.part.0.constprop.0>:
    5294:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5298:	910003fd 	mov	x29, sp
    529c:	a9025bf5 	stp	x21, x22, [sp, #32]
    52a0:	f00000d6 	adrp	x22, 20000 <__data_start>
    52a4:	910142c2 	add	x2, x22, #0x50
    52a8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52ac:	b9413059 	ldr	w25, [x2, #304]
    52b0:	a90153f3 	stp	x19, x20, [sp, #16]
    52b4:	aa0103f4 	mov	x20, x1
    52b8:	a90363f7 	stp	x23, x24, [sp, #48]
    52bc:	2a0003f7 	mov	w23, w0
    52c0:	340000b9 	cbz	w25, 52d4 <fwp_data.part.0.constprop.0+0x40>
    52c4:	a9538041 	ldp	x1, x0, [x2, #312]
    52c8:	91000421 	add	x1, x1, #0x1
    52cc:	91006000 	add	x0, x0, #0x18
    52d0:	a9138041 	stp	x1, x0, [x2, #312]
    52d4:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    52d8:	9118c2a3 	add	x3, x21, #0x630
    52dc:	b953a460 	ldr	w0, [x3, #5028]
    52e0:	34000840 	cbz	w0, 53e8 <fwp_data.part.0.constprop.0+0x154>
    52e4:	397e8862 	ldrb	w2, [x3, #4002]
    52e8:	910f0040 	add	x0, x2, #0x3c0
    52ec:	8b020442 	add	x2, x2, x2, lsl #1
    52f0:	d37df042 	lsl	x2, x2, #3
    52f4:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    52f8:	2a1a03f8 	mov	w24, w26
    52fc:	f8626873 	ldr	x19, [x3, x2]
    5300:	b4000613 	cbz	x19, 53c0 <fwp_data.part.0.constprop.0+0x12c>
    5304:	f9400260 	ldr	x0, [x19]
    5308:	aa2003e0 	mvn	x0, x0
    530c:	f8226860 	str	x0, [x3, x2]
    5310:	f100631f 	cmp	x24, #0x18
    5314:	540000e9 	b.ls	5330 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5318:	d1006702 	sub	x2, x24, #0x19
    531c:	91006260 	add	x0, x19, #0x18
    5320:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5324:	52800001 	mov	w1, #0x0                   	// #0
    5328:	91002042 	add	x2, x2, #0x8
    532c:	97fff551 	bl	2870 <memset@plt>
    5330:	9118c2a0 	add	x0, x21, #0x630
    5334:	f94a1001 	ldr	x1, [x0, #5152]
    5338:	ab180021 	adds	x1, x1, x24
    533c:	54000642 	b.cs	5404 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    5340:	f94a1402 	ldr	x2, [x0, #5160]
    5344:	f90a1001 	str	x1, [x0, #5152]
    5348:	eb02003f 	cmp	x1, x2
    534c:	54000049 	b.ls	5354 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5350:	f90a1401 	str	x1, [x0, #5160]
    5354:	9118c2a0 	add	x0, x21, #0x630
    5358:	1e630341 	ucvtf	d1, w26
    535c:	fd4a1c00 	ldr	d0, [x0, #5176]
    5360:	1e612800 	fadd	d0, d0, d1
    5364:	fd0a1c00 	str	d0, [x0, #5176]
    5368:	34000139 	cbz	w25, 538c <fwp_data.part.0.constprop.0+0xf8>
    536c:	9118c2b5 	add	x21, x21, #0x630
    5370:	910142d6 	add	x22, x22, #0x50
    5374:	fd4a12a0 	ldr	d0, [x21, #5152]
    5378:	6d5486c2 	ldp	d2, d1, [x22, #328]
    537c:	7e61d800 	ucvtf	d0, d0
    5380:	1e623800 	fsub	d0, d0, d2
    5384:	1e612010 	fcmpe	d0, d1
    5388:	540003ac 	b.gt	53fc <fwp_data.part.0.constprop.0+0x168>
    538c:	52800040 	mov	w0, #0x2                   	// #2
    5390:	29000277 	stp	w23, w0, [x19]
    5394:	aa1303e0 	mov	x0, x19
    5398:	f9400281 	ldr	x1, [x20]
    539c:	f9000661 	str	x1, [x19, #8]
    53a0:	f9400681 	ldr	x1, [x20, #8]
    53a4:	f9000a61 	str	x1, [x19, #16]
    53a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    53ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    53b4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53b8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53bc:	d65f03c0 	ret
    53c0:	8b020063 	add	x3, x3, x2
    53c4:	f9400473 	ldr	x19, [x3, #8]
    53c8:	b4000113 	cbz	x19, 53e8 <fwp_data.part.0.constprop.0+0x154>
    53cc:	f9400860 	ldr	x0, [x3, #16]
    53d0:	cb130000 	sub	x0, x0, x19
    53d4:	eb00031f 	cmp	x24, x0
    53d8:	54000088 	b.hi	53e8 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    53dc:	8b180260 	add	x0, x19, x24
    53e0:	f9000460 	str	x0, [x3, #8]
    53e4:	17ffffcb 	b	5310 <fwp_data.part.0.constprop.0+0x7c>
    53e8:	52800001 	mov	w1, #0x0                   	// #0
    53ec:	d2800300 	mov	x0, #0x18                  	// #24
    53f0:	97ffff48 	bl	5110 <fwp_heap_alloc>
    53f4:	aa0003f3 	mov	x19, x0
    53f8:	17ffffdc 	b	5368 <fwp_data.part.0.constprop.0+0xd4>
    53fc:	fd00aac0 	str	d0, [x22, #336]
    5400:	17ffffe3 	b	538c <fwp_data.part.0.constprop.0+0xf8>
    5404:	97fff75b 	bl	3170 <fwp_heap_oom>
    5408:	d503201f 	nop
    540c:	d503201f 	nop

0000000000005410 <fwp_p_ad_push>:
    5410:	f100001f 	cmp	x0, #0x0
    5414:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    5418:	540011ab 	b.lt	564c <fwp_p_ad_push+0x23c>  // b.tstop
    541c:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5420:	910003fd 	mov	x29, sp
    5424:	a90153f3 	stp	x19, x20, [sp, #16]
    5428:	a9025bf5 	stp	x21, x22, [sp, #32]
    542c:	aa0403f6 	mov	x22, x4
    5430:	aa0003f5 	mov	x21, x0
    5434:	a90363f7 	stp	x23, x24, [sp, #48]
    5438:	aa0203f8 	mov	x24, x2
    543c:	6d0627e8 	stp	d8, d9, [sp, #96]
    5440:	9e670029 	fmov	d9, x1
    5444:	9e670068 	fmov	d8, x3
    5448:	aa020001 	orr	x1, x0, x2
    544c:	b6f80de1 	tbz	x1, #63, 5608 <fwp_p_ad_push+0x1f8>
    5450:	9360fc14 	asr	x20, x0, #32
    5454:	b6f800c0 	tbz	x0, #63, 546c <fwp_p_ad_push+0x5c>
    5458:	1e604109 	fmov	d9, d8
    545c:	2f00e408 	movi	d8, #0x0
    5460:	9360fc54 	asr	x20, x2, #32
    5464:	aa0203f5 	mov	x21, x2
    5468:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    546c:	b4001156 	cbz	x22, 5694 <fwp_p_ad_push+0x284>
    5470:	f94002c0 	ldr	x0, [x22]
    5474:	eb14001f 	cmp	x0, x20
    5478:	54000e60 	b.eq	5644 <fwp_p_ad_push+0x234>  // b.none
    547c:	aa1403e0 	mov	x0, x20
    5480:	97fff9ac 	bl	3b30 <fwp_tape_of>
    5484:	aa0003f3 	mov	x19, x0
    5488:	f9403000 	ldr	x0, [x0, #96]
    548c:	b50010e0 	cbnz	x0, 56a8 <fwp_p_ad_push+0x298>
    5490:	a9004ed4 	stp	x20, x19, [x22]
    5494:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5498:	f9400a77 	ldr	x23, [x19, #16]
    549c:	a9046bf9 	stp	x25, x26, [sp, #64]
    54a0:	eb0002ff 	cmp	x23, x0
    54a4:	540013ac 	b.gt	5718 <fwp_p_ad_push+0x308>
    54a8:	eb3542ff 	cmp	x23, w21, uxtw
    54ac:	540012ed 	b.le	5708 <fwp_p_ad_push+0x2f8>
    54b0:	b7f80078 	tbnz	x24, #63, 54bc <fwp_p_ad_push+0xac>
    54b4:	eb3842ff 	cmp	x23, w24, uxtw
    54b8:	5400128d 	b.le	5708 <fwp_p_ad_push+0x2f8>
    54bc:	f9400676 	ldr	x22, [x19, #8]
    54c0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54c4:	cb1602f6 	sub	x22, x23, x22
    54c8:	910006c1 	add	x1, x22, #0x1
    54cc:	aa1603f9 	mov	x25, x22
    54d0:	eb00003f 	cmp	x1, x0
    54d4:	54001228 	b.hi	5718 <fwp_p_ad_push+0x308>  // b.pmore
    54d8:	a9418274 	ldp	x20, x0, [x19, #24]
    54dc:	eb14003f 	cmp	x1, x20
    54e0:	54000a8d 	b.le	5630 <fwp_p_ad_push+0x220>
    54e4:	f100029f 	cmp	x20, #0x0
    54e8:	d2800803 	mov	x3, #0x40                  	// #64
    54ec:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    54f0:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    54f4:	a90573fb 	stp	x27, x28, [sp, #80]
    54f8:	eb14003f 	cmp	x1, x20
    54fc:	5400008d 	b.le	550c <fwp_p_ad_push+0xfc>
    5500:	eb02029f 	cmp	x20, x2
    5504:	5400092d 	b.le	5628 <fwp_p_ad_push+0x218>
    5508:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    550c:	d37df29a 	lsl	x26, x20, #3
    5510:	52800022 	mov	w2, #0x1                   	// #1
    5514:	f940327b 	ldr	x27, [x19, #96]
    5518:	aa1a03e1 	mov	x1, x26
    551c:	97fffbce 	bl	4454 <ad_raw_realloc>
    5520:	b4001040 	cbz	x0, 5728 <fwp_p_ad_push+0x318>
    5524:	f9400e61 	ldr	x1, [x19, #24]
    5528:	8b010801 	add	x1, x0, x1, lsl #2
    552c:	a9020660 	stp	x0, x1, [x19, #32]
    5530:	b400093b 	cbz	x27, 5654 <fwp_p_ad_push+0x244>
    5534:	f9403363 	ldr	x3, [x27, #96]
    5538:	f9003be3 	str	x3, [sp, #112]
    553c:	eb03029f 	cmp	x20, x3
    5540:	5400034d 	b.le	55a8 <fwp_p_ad_push+0x198>
    5544:	f940237c 	ldr	x28, [x27, #64]
    5548:	d37cee82 	lsl	x2, x20, #4
    554c:	aa0203e0 	mov	x0, x2
    5550:	52800041 	mov	w1, #0x2                   	// #2
    5554:	f9003fe2 	str	x2, [sp, #120]
    5558:	97fffeee 	bl	5110 <fwp_heap_alloc>
    555c:	aa0003fa 	mov	x26, x0
    5560:	b400013c 	cbz	x28, 5584 <fwp_p_ad_push+0x174>
    5564:	a9470be3 	ldp	x3, x2, [sp, #112]
    5568:	aa1c03e1 	mov	x1, x28
    556c:	d37cec63 	lsl	x3, x3, #4
    5570:	eb02007f 	cmp	x3, x2
    5574:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    5578:	97fff45e 	bl	26f0 <memcpy@plt>
    557c:	aa1c03e0 	mov	x0, x28
    5580:	97fffdc4 	bl	4c90 <fwp_mem_free>
    5584:	f9403360 	ldr	x0, [x27, #96]
    5588:	52800001 	mov	w1, #0x0                   	// #0
    558c:	cb000282 	sub	x2, x20, x0
    5590:	8b001340 	add	x0, x26, x0, lsl #4
    5594:	d37cec42 	lsl	x2, x2, #4
    5598:	97fff4b6 	bl	2870 <memset@plt>
    559c:	f9401260 	ldr	x0, [x19, #32]
    55a0:	f900237a 	str	x26, [x27, #64]
    55a4:	f9003374 	str	x20, [x27, #96]
    55a8:	b50008b6 	cbnz	x22, 56bc <fwp_p_ad_push+0x2ac>
    55ac:	a9431263 	ldp	x3, x4, [x19, #48]
    55b0:	d37ef69a 	lsl	x26, x20, #2
    55b4:	a94573fb 	ldp	x27, x28, [sp, #80]
    55b8:	8b1a0002 	add	x2, x0, x26
    55bc:	f9000e74 	str	x20, [x19, #24]
    55c0:	f9001662 	str	x2, [x19, #40]
    55c4:	b8366815 	str	w21, [x0, x22]
    55c8:	f100031f 	cmp	x24, #0x0
    55cc:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    55d0:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55d4:	fc396869 	str	d9, [x3, x25]
    55d8:	aa1702a0 	orr	x0, x21, x23
    55dc:	b8366841 	str	w1, [x2, x22]
    55e0:	910006e1 	add	x1, x23, #0x1
    55e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e8:	fc396888 	str	d8, [x4, x25]
    55ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    55f0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    55f4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55f8:	f9000a61 	str	x1, [x19, #16]
    55fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5600:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5604:	d65f03c0 	ret
    5608:	9360fc54 	asr	x20, x2, #32
    560c:	eb80829f 	cmp	x20, x0, asr #32
    5610:	54fff2e0 	b.eq	546c <fwp_p_ad_push+0x5c>  // b.none
    5614:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    5618:	91126000 	add	x0, x0, #0x498
    561c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5620:	a90573fb 	stp	x27, x28, [sp, #80]
    5624:	97fff877 	bl	3800 <fwp_trap>
    5628:	d37ffa94 	lsl	x20, x20, #1
    562c:	17ffffb3 	b	54f8 <fwp_p_ad_push+0xe8>
    5630:	a9428e62 	ldp	x2, x3, [x19, #40]
    5634:	d37ef6d6 	lsl	x22, x22, #2
    5638:	f9401e64 	ldr	x4, [x19, #56]
    563c:	d37df339 	lsl	x25, x25, #3
    5640:	17ffffe1 	b	55c4 <fwp_p_ad_push+0x1b4>
    5644:	f94006d3 	ldr	x19, [x22, #8]
    5648:	17ffff93 	b	5494 <fwp_p_ad_push+0x84>
    564c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5650:	d65f03c0 	ret
    5654:	f9401a60 	ldr	x0, [x19, #48]
    5658:	d37cee81 	lsl	x1, x20, #4
    565c:	52800042 	mov	w2, #0x2                   	// #2
    5660:	97fffb7d 	bl	4454 <ad_raw_realloc>
    5664:	aa0003e3 	mov	x3, x0
    5668:	b4000600 	cbz	x0, 5728 <fwp_p_ad_push+0x318>
    566c:	f9400e61 	ldr	x1, [x19, #24]
    5670:	8b1a0004 	add	x4, x0, x26
    5674:	8b010c01 	add	x1, x0, x1, lsl #3
    5678:	a9030660 	stp	x0, x1, [x19, #48]
    567c:	b5000356 	cbnz	x22, 56e4 <fwp_p_ad_push+0x2d4>
    5680:	f9401260 	ldr	x0, [x19, #32]
    5684:	d37ef69a 	lsl	x26, x20, #2
    5688:	d2800016 	mov	x22, #0x0                   	// #0
    568c:	f9001e64 	str	x4, [x19, #56]
    5690:	17ffffc9 	b	55b4 <fwp_p_ad_push+0x1a4>
    5694:	aa1403e0 	mov	x0, x20
    5698:	97fff926 	bl	3b30 <fwp_tape_of>
    569c:	aa0003f3 	mov	x19, x0
    56a0:	f9403000 	ldr	x0, [x0, #96]
    56a4:	b4ffef80 	cbz	x0, 5494 <fwp_p_ad_push+0x84>
    56a8:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    56ac:	91138000 	add	x0, x0, #0x4e0
    56b0:	a9046bf9 	stp	x25, x26, [sp, #64]
    56b4:	a90573fb 	stp	x27, x28, [sp, #80]
    56b8:	97fff852 	bl	3800 <fwp_trap>
    56bc:	d37df2d9 	lsl	x25, x22, #3
    56c0:	f9401661 	ldr	x1, [x19, #40]
    56c4:	d37ef6d6 	lsl	x22, x22, #2
    56c8:	d37ef69a 	lsl	x26, x20, #2
    56cc:	aa1603e2 	mov	x2, x22
    56d0:	8b1a0000 	add	x0, x0, x26
    56d4:	97fff40f 	bl	2710 <memmove@plt>
    56d8:	f9401260 	ldr	x0, [x19, #32]
    56dc:	a9431263 	ldp	x3, x4, [x19, #48]
    56e0:	17ffffb5 	b	55b4 <fwp_p_ad_push+0x1a4>
    56e4:	d37df2d9 	lsl	x25, x22, #3
    56e8:	aa0403e0 	mov	x0, x4
    56ec:	aa1903e2 	mov	x2, x25
    56f0:	97fff408 	bl	2710 <memmove@plt>
    56f4:	f9401a61 	ldr	x1, [x19, #48]
    56f8:	f9401260 	ldr	x0, [x19, #32]
    56fc:	8b1a0021 	add	x1, x1, x26
    5700:	f9001e61 	str	x1, [x19, #56]
    5704:	17ffffef 	b	56c0 <fwp_p_ad_push+0x2b0>
    5708:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    570c:	9114c000 	add	x0, x0, #0x530
    5710:	a90573fb 	stp	x27, x28, [sp, #80]
    5714:	97fff83b 	bl	3800 <fwp_trap>
    5718:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    571c:	91144000 	add	x0, x0, #0x510
    5720:	a90573fb 	stp	x27, x28, [sp, #80]
    5724:	97fff837 	bl	3800 <fwp_trap>
    5728:	aa1303e0 	mov	x0, x19
    572c:	97fff63a 	bl	3014 <fwp_tape_unlink_scope>
    5730:	f9401260 	ldr	x0, [x19, #32]
    5734:	b4000040 	cbz	x0, 573c <fwp_p_ad_push+0x32c>
    5738:	97fffb12 	bl	4380 <ad_raw_free.part.0>
    573c:	f9401a60 	ldr	x0, [x19, #48]
    5740:	b4000040 	cbz	x0, 5748 <fwp_p_ad_push+0x338>
    5744:	97fffb0f 	bl	4380 <ad_raw_free.part.0>
    5748:	f9402260 	ldr	x0, [x19, #64]
    574c:	b4000040 	cbz	x0, 5754 <fwp_p_ad_push+0x344>
    5750:	97fffb0c 	bl	4380 <ad_raw_free.part.0>
    5754:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    5758:	f947e821 	ldr	x1, [x1, #4048]
    575c:	f9000e7f 	str	xzr, [x19, #24]
    5760:	4f000400 	movi	v0.4s, #0x0
    5764:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5768:	d2800262 	mov	x2, #0x13                  	// #19
    576c:	f9400023 	ldr	x3, [x1]
    5770:	b900067f 	str	wzr, [x19, #4]
    5774:	d2800021 	mov	x1, #0x1                   	// #1
    5778:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x1b90>
    577c:	913e6000 	add	x0, x0, #0xf98
    5780:	3c808260 	stur	q0, [x19, #8]
    5784:	ad010260 	stp	q0, q0, [x19, #32]
    5788:	97fff486 	bl	29a0 <fwrite@plt>
    578c:	d2800000 	mov	x0, #0x0                   	// #0
    5790:	97fff490 	bl	29d0 <fflush@plt>
    5794:	52800cc0 	mov	w0, #0x66                  	// #102
    5798:	97fff49e 	bl	2a10 <_Exit@plt>
    579c:	d503201f 	nop

00000000000057a0 <w120>:
    57a0:	d10203ff 	sub	sp, sp, #0x80
    57a4:	9e660003 	fmov	x3, d0
    57a8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    57ac:	f947f442 	ldr	x2, [x2, #4072]
    57b0:	a9027bfd 	stp	x29, x30, [sp, #32]
    57b4:	910083fd 	add	x29, sp, #0x20
    57b8:	6d0627e8 	stp	d8, d9, [sp, #96]
    57bc:	1e604009 	fmov	d9, d0
    57c0:	1e604028 	fmov	d8, d1
    57c4:	fd003bea 	str	d10, [sp, #112]
    57c8:	1e60080a 	fmul	d10, d0, d0
    57cc:	a90353f3 	stp	x19, x20, [sp, #48]
    57d0:	910023f3 	add	x19, sp, #0x8
    57d4:	aa0003f4 	mov	x20, x0
    57d8:	a9045bf5 	stp	x21, x22, [sp, #64]
    57dc:	aa0103f6 	mov	x22, x1
    57e0:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    57e4:	a90563f7 	stp	x23, x24, [sp, #80]
    57e8:	aa0303e1 	mov	x1, x3
    57ec:	f9400044 	ldr	x4, [x2]
    57f0:	f9000fe4 	str	x4, [sp, #24]
    57f4:	d2800004 	mov	x4, #0x0                   	// #0
    57f8:	aa0003e2 	mov	x2, x0
    57fc:	aa1303e4 	mov	x4, x19
    5800:	a900fff5 	stp	x21, xzr, [sp, #8]
    5804:	97ffff03 	bl	5410 <fwp_p_ad_push>
    5808:	1e6a3908 	fsub	d8, d8, d10
    580c:	aa1603e2 	mov	x2, x22
    5810:	aa1303e4 	mov	x4, x19
    5814:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5818:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    581c:	9e660118 	fmov	x24, d8
    5820:	97fffefc 	bl	5410 <fwp_p_ad_push>
    5824:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5828:	aa0003f6 	mov	x22, x0
    582c:	aa1303e4 	mov	x4, x19
    5830:	aa1403e0 	mov	x0, x20
    5834:	1e69394a 	fsub	d10, d10, d9
    5838:	aa1503e2 	mov	x2, x21
    583c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5840:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5844:	9e660157 	fmov	x23, d10
    5848:	97fffef2 	bl	5410 <fwp_p_ad_push>
    584c:	1e680908 	fmul	d8, d8, d8
    5850:	aa0003f4 	mov	x20, x0
    5854:	aa1303e4 	mov	x4, x19
    5858:	aa1803e3 	mov	x3, x24
    585c:	aa1803e1 	mov	x1, x24
    5860:	aa1603e2 	mov	x2, x22
    5864:	aa1603e0 	mov	x0, x22
    5868:	97fffeea 	bl	5410 <fwp_p_ad_push>
    586c:	aa0003e2 	mov	x2, x0
    5870:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5874:	9e670029 	fmov	d9, x1
    5878:	9e660101 	fmov	x1, d8
    587c:	aa1303e4 	mov	x4, x19
    5880:	1e690909 	fmul	d9, d8, d9
    5884:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5888:	aa1503e0 	mov	x0, x21
    588c:	97fffee1 	bl	5410 <fwp_p_ad_push>
    5890:	1e6a094a 	fmul	d10, d10, d10
    5894:	aa1303e4 	mov	x4, x19
    5898:	aa1703e3 	mov	x3, x23
    589c:	aa0003f3 	mov	x19, x0
    58a0:	aa1703e1 	mov	x1, x23
    58a4:	aa1403e2 	mov	x2, x20
    58a8:	aa1403e0 	mov	x0, x20
    58ac:	97fffed9 	bl	5410 <fwp_p_ad_push>
    58b0:	1e6a2929 	fadd	d9, d9, d10
    58b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    58b8:	d2800004 	mov	x4, #0x0                   	// #0
    58bc:	aa0303e1 	mov	x1, x3
    58c0:	aa1303e2 	mov	x2, x19
    58c4:	97fffed3 	bl	5410 <fwp_p_ad_push>
    58c8:	aa0003e1 	mov	x1, x0
    58cc:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    58d0:	f947f463 	ldr	x3, [x3, #4072]
    58d4:	f9400fe0 	ldr	x0, [sp, #24]
    58d8:	f9400064 	ldr	x4, [x3]
    58dc:	eb040000 	subs	x0, x0, x4
    58e0:	d2800004 	mov	x4, #0x0                   	// #0
    58e4:	54000161 	b.ne	5910 <w120+0x170>  // b.any
    58e8:	9e660122 	fmov	x2, d9
    58ec:	fd403bea 	ldr	d10, [sp, #112]
    58f0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    58f4:	a94353f3 	ldp	x19, x20, [sp, #48]
    58f8:	aa0203e0 	mov	x0, x2
    58fc:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5900:	a94563f7 	ldp	x23, x24, [sp, #80]
    5904:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5908:	910203ff 	add	sp, sp, #0x80
    590c:	d65f03c0 	ret
    5910:	97fff3e4 	bl	28a0 <__stack_chk_fail@plt>

0000000000005914 <w176.constprop.0>:
    5914:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5918:	910003fd 	mov	x29, sp
    591c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5920:	fd001be8 	str	d8, [sp, #48]
    5924:	f9400015 	ldr	x21, [x0]
    5928:	b4000355 	cbz	x21, 5990 <w176.constprop.0+0x7c>
    592c:	2f00e408 	movi	d8, #0x0
    5930:	91002016 	add	x22, x0, #0x8
    5934:	a90153f3 	stp	x19, x20, [sp, #16]
    5938:	91004014 	add	x20, x0, #0x10
    593c:	d2800013 	mov	x19, #0x0                   	// #0
    5940:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5944:	d503201f 	nop
    5948:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    594c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5950:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    5954:	aa0303e1 	mov	x1, x3
    5958:	1e602908 	fadd	d8, d8, d0
    595c:	d2800004 	mov	x4, #0x0                   	// #0
    5960:	91000a73 	add	x19, x19, #0x2
    5964:	97fffeab 	bl	5410 <fwp_p_ad_push>
    5968:	eb1302bf 	cmp	x21, x19
    596c:	54fffee8 	b.hi	5948 <w176.constprop.0+0x34>  // b.pmore
    5970:	9e660102 	fmov	x2, d8
    5974:	fd401be8 	ldr	d8, [sp, #48]
    5978:	a94153f3 	ldp	x19, x20, [sp, #16]
    597c:	aa0003e1 	mov	x1, x0
    5980:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5984:	aa0203e0 	mov	x0, x2
    5988:	a8c47bfd 	ldp	x29, x30, [sp], #64
    598c:	d65f03c0 	ret
    5990:	2f00e408 	movi	d8, #0x0
    5994:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5998:	a9425bf5 	ldp	x21, x22, [sp, #32]
    599c:	aa0003e1 	mov	x1, x0
    59a0:	9e660102 	fmov	x2, d8
    59a4:	fd401be8 	ldr	d8, [sp, #48]
    59a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    59ac:	aa0203e0 	mov	x0, x2
    59b0:	d65f03c0 	ret

00000000000059b4 <fwp_rc_share>:
    59b4:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    59b8:	9118c042 	add	x2, x2, #0x630
    59bc:	f949d843 	ldr	x3, [x2, #5040]
    59c0:	f949ec41 	ldr	x1, [x2, #5080]
    59c4:	cb030000 	sub	x0, x0, x3
    59c8:	eb01401f 	cmp	x0, x1, lsl #16
    59cc:	540002c2 	b.cs	5a24 <fwp_rc_share+0x70>  // b.hs, b.nlast
    59d0:	d350fc01 	lsr	x1, x0, #16
    59d4:	f949fc44 	ldr	x4, [x2, #5112]
    59d8:	8b010821 	add	x1, x1, x1, lsl #2
    59dc:	d37df021 	lsl	x1, x1, #3
    59e0:	8b010083 	add	x3, x4, x1
    59e4:	f9401062 	ldr	x2, [x3, #32]
    59e8:	b40001e2 	cbz	x2, 5a24 <fwp_rc_share+0x70>
    59ec:	38616881 	ldrb	w1, [x4, x1]
    59f0:	7100083f 	cmp	w1, #0x2
    59f4:	540001a0 	b.eq	5a28 <fwp_rc_share+0x74>  // b.none
    59f8:	7100043f 	cmp	w1, #0x1
    59fc:	54000141 	b.ne	5a24 <fwp_rc_share+0x70>  // b.any
    5a00:	29430464 	ldp	w4, w1, [x3, #24]
    5a04:	92403c00 	and	x0, x0, #0xffff
    5a08:	9b047c00 	mul	x0, x0, x4
    5a0c:	d360fc00 	lsr	x0, x0, #32
    5a10:	eb01001f 	cmp	x0, x1
    5a14:	54000082 	b.cs	5a24 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5a18:	8b000042 	add	x2, x2, x0
    5a1c:	39400040 	ldrb	w0, [x2]
    5a20:	350000a0 	cbnz	w0, 5a34 <fwp_rc_share+0x80>
    5a24:	d65f03c0 	ret
    5a28:	72003c1f 	tst	w0, #0xffff
    5a2c:	54ffff80 	b.eq	5a1c <fwp_rc_share+0x68>  // b.none
    5a30:	d65f03c0 	ret
    5a34:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5a38:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    5a3c:	91154000 	add	x0, x0, #0x550
    5a40:	910003fd 	mov	x29, sp
    5a44:	97fff76f 	bl	3800 <fwp_trap>
    5a48:	d503201f 	nop
    5a4c:	d503201f 	nop

0000000000005a50 <fwp_rc_free_arr>:
    5a50:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5a54:	9118c063 	add	x3, x3, #0x630
    5a58:	f949d861 	ldr	x1, [x3, #5040]
    5a5c:	f949ec62 	ldr	x2, [x3, #5080]
    5a60:	cb010001 	sub	x1, x0, x1
    5a64:	eb02403f 	cmp	x1, x2, lsl #16
    5a68:	54000342 	b.cs	5ad0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5a6c:	d350fc22 	lsr	x2, x1, #16
    5a70:	f949fc65 	ldr	x5, [x3, #5112]
    5a74:	8b020842 	add	x2, x2, x2, lsl #2
    5a78:	d37df042 	lsl	x2, x2, #3
    5a7c:	8b0200a4 	add	x4, x5, x2
    5a80:	f9401083 	ldr	x3, [x4, #32]
    5a84:	b4000263 	cbz	x3, 5ad0 <fwp_rc_free_arr+0x80>
    5a88:	386268a2 	ldrb	w2, [x5, x2]
    5a8c:	7100085f 	cmp	w2, #0x2
    5a90:	540001c0 	b.eq	5ac8 <fwp_rc_free_arr+0x78>  // b.none
    5a94:	7100045f 	cmp	w2, #0x1
    5a98:	540001c1 	b.ne	5ad0 <fwp_rc_free_arr+0x80>  // b.any
    5a9c:	29430885 	ldp	w5, w2, [x4, #24]
    5aa0:	92403c21 	and	x1, x1, #0xffff
    5aa4:	9b057c21 	mul	x1, x1, x5
    5aa8:	d360fc21 	lsr	x1, x1, #32
    5aac:	eb02003f 	cmp	x1, x2
    5ab0:	54000102 	b.cs	5ad0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5ab4:	8b010063 	add	x3, x3, x1
    5ab8:	39400061 	ldrb	w1, [x3]
    5abc:	7100043f 	cmp	w1, #0x1
    5ac0:	54000081 	b.ne	5ad0 <fwp_rc_free_arr+0x80>  // b.any
    5ac4:	17fffc73 	b	4c90 <fwp_mem_free>
    5ac8:	72003c3f 	tst	w1, #0xffff
    5acc:	54ffff60 	b.eq	5ab8 <fwp_rc_free_arr+0x68>  // b.none
    5ad0:	d65f03c0 	ret

0000000000005ad4 <fwp_rc_dup>:
    5ad4:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5ad8:	9118c042 	add	x2, x2, #0x630
    5adc:	f949d841 	ldr	x1, [x2, #5040]
    5ae0:	f949ec43 	ldr	x3, [x2, #5080]
    5ae4:	cb010001 	sub	x1, x0, x1
    5ae8:	eb03403f 	cmp	x1, x3, lsl #16
    5aec:	540003c2 	b.cs	5b64 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5af0:	d350fc20 	lsr	x0, x1, #16
    5af4:	f949fc44 	ldr	x4, [x2, #5112]
    5af8:	8b000800 	add	x0, x0, x0, lsl #2
    5afc:	d37df002 	lsl	x2, x0, #3
    5b00:	8b020083 	add	x3, x4, x2
    5b04:	f9401060 	ldr	x0, [x3, #32]
    5b08:	b40002e0 	cbz	x0, 5b64 <fwp_rc_dup+0x90>
    5b0c:	38626882 	ldrb	w2, [x4, x2]
    5b10:	7100085f 	cmp	w2, #0x2
    5b14:	540002a0 	b.eq	5b68 <fwp_rc_dup+0x94>  // b.none
    5b18:	7100045f 	cmp	w2, #0x1
    5b1c:	54000241 	b.ne	5b64 <fwp_rc_dup+0x90>  // b.any
    5b20:	29430864 	ldp	w4, w2, [x3, #24]
    5b24:	92403c21 	and	x1, x1, #0xffff
    5b28:	9b047c21 	mul	x1, x1, x4
    5b2c:	d360fc21 	lsr	x1, x1, #32
    5b30:	eb02003f 	cmp	x1, x2
    5b34:	54000182 	b.cs	5b64 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5b38:	8b010000 	add	x0, x0, x1
    5b3c:	39400001 	ldrb	w1, [x0]
    5b40:	34000121 	cbz	w1, 5b64 <fwp_rc_dup+0x90>
    5b44:	f00000c2 	adrp	x2, 20000 <__data_start>
    5b48:	91014042 	add	x2, x2, #0x50
    5b4c:	b9413043 	ldr	w3, [x2, #304]
    5b50:	35000123 	cbnz	w3, 5b74 <fwp_rc_dup+0xa0>
    5b54:	7103f43f 	cmp	w1, #0xfd
    5b58:	54000168 	b.hi	5b84 <fwp_rc_dup+0xb0>  // b.pmore
    5b5c:	11000421 	add	w1, w1, #0x1
    5b60:	39000001 	strb	w1, [x0]
    5b64:	d65f03c0 	ret
    5b68:	72003c3f 	tst	w1, #0xffff
    5b6c:	54fffe80 	b.eq	5b3c <fwp_rc_dup+0x68>  // b.none
    5b70:	d65f03c0 	ret
    5b74:	f940ac43 	ldr	x3, [x2, #344]
    5b78:	91000463 	add	x3, x3, #0x1
    5b7c:	f900ac43 	str	x3, [x2, #344]
    5b80:	17fffff5 	b	5b54 <fwp_rc_dup+0x80>
    5b84:	17fffb5c 	b	48f4 <fwp_rc_wide_dup>
    5b88:	d503201f 	nop
    5b8c:	d503201f 	nop

0000000000005b90 <fwp_owned_entry173>:
    5b90:	d10103ff 	sub	sp, sp, #0x40
    5b94:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5b98:	f947f442 	ldr	x2, [x2, #4072]
    5b9c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5ba0:	910083fd 	add	x29, sp, #0x20
    5ba4:	a90353f3 	stp	x19, x20, [sp, #48]
    5ba8:	f9400043 	ldr	x3, [x2]
    5bac:	f9000fe3 	str	x3, [sp, #24]
    5bb0:	d2800003 	mov	x3, #0x0                   	// #0
    5bb4:	a9400c01 	ldp	x1, x3, [x0]
    5bb8:	f9400802 	ldr	x2, [x0, #16]
    5bbc:	ab020022 	adds	x2, x1, x2
    5bc0:	540006e6 	b.vs	5c9c <fwp_owned_entry173+0x10c>
    5bc4:	910023e1 	add	x1, sp, #0x8
    5bc8:	52800000 	mov	w0, #0x0                   	// #0
    5bcc:	a9008be3 	stp	x3, x2, [sp, #8]
    5bd0:	97fffdb1 	bl	5294 <fwp_data.part.0.constprop.0>
    5bd4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5bd8:	9118c063 	add	x3, x3, #0x630
    5bdc:	aa0003f3 	mov	x19, x0
    5be0:	f949d861 	ldr	x1, [x3, #5040]
    5be4:	f949ec60 	ldr	x0, [x3, #5080]
    5be8:	cb010261 	sub	x1, x19, x1
    5bec:	eb00403f 	cmp	x1, x0, lsl #16
    5bf0:	54000322 	b.cs	5c54 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5bf4:	d350fc22 	lsr	x2, x1, #16
    5bf8:	f949fc63 	ldr	x3, [x3, #5112]
    5bfc:	8b020842 	add	x2, x2, x2, lsl #2
    5c00:	d37df042 	lsl	x2, x2, #3
    5c04:	8b020060 	add	x0, x3, x2
    5c08:	f9401014 	ldr	x20, [x0, #32]
    5c0c:	b4000254 	cbz	x20, 5c54 <fwp_owned_entry173+0xc4>
    5c10:	38626862 	ldrb	w2, [x3, x2]
    5c14:	7100085f 	cmp	w2, #0x2
    5c18:	54000360 	b.eq	5c84 <fwp_owned_entry173+0xf4>  // b.none
    5c1c:	7100045f 	cmp	w2, #0x1
    5c20:	540001a1 	b.ne	5c54 <fwp_owned_entry173+0xc4>  // b.any
    5c24:	29430002 	ldp	w2, w0, [x0, #24]
    5c28:	92403c21 	and	x1, x1, #0xffff
    5c2c:	9b027c21 	mul	x1, x1, x2
    5c30:	d360fc21 	lsr	x1, x1, #32
    5c34:	eb00003f 	cmp	x1, x0
    5c38:	540000e2 	b.cs	5c54 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5c3c:	8b010294 	add	x20, x20, x1
    5c40:	39400280 	ldrb	w0, [x20]
    5c44:	7103fc1f 	cmp	w0, #0xff
    5c48:	54000240 	b.eq	5c90 <fwp_owned_entry173+0x100>  // b.none
    5c4c:	52800020 	mov	w0, #0x1                   	// #1
    5c50:	39000280 	strb	w0, [x20]
    5c54:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5c58:	f947f400 	ldr	x0, [x0, #4072]
    5c5c:	f9400fe2 	ldr	x2, [sp, #24]
    5c60:	f9400001 	ldr	x1, [x0]
    5c64:	eb010042 	subs	x2, x2, x1
    5c68:	d2800001 	mov	x1, #0x0                   	// #0
    5c6c:	540001a1 	b.ne	5ca0 <fwp_owned_entry173+0x110>  // b.any
    5c70:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5c74:	aa1303e0 	mov	x0, x19
    5c78:	a94353f3 	ldp	x19, x20, [sp, #48]
    5c7c:	910103ff 	add	sp, sp, #0x40
    5c80:	d65f03c0 	ret
    5c84:	72003c3f 	tst	w1, #0xffff
    5c88:	54fffe61 	b.ne	5c54 <fwp_owned_entry173+0xc4>  // b.any
    5c8c:	17ffffed 	b	5c40 <fwp_owned_entry173+0xb0>
    5c90:	aa1403e0 	mov	x0, x20
    5c94:	97fffb5f 	bl	4a10 <fwp_rc_forget_slot>
    5c98:	17ffffed 	b	5c4c <fwp_owned_entry173+0xbc>
    5c9c:	97fff379 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5ca0:	97fff300 	bl	28a0 <__stack_chk_fail@plt>

0000000000005ca4 <e173>:
    5ca4:	d10103ff 	sub	sp, sp, #0x40
    5ca8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5cac:	f947f442 	ldr	x2, [x2, #4072]
    5cb0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5cb4:	910083fd 	add	x29, sp, #0x20
    5cb8:	a90353f3 	stp	x19, x20, [sp, #48]
    5cbc:	f9400043 	ldr	x3, [x2]
    5cc0:	f9000fe3 	str	x3, [sp, #24]
    5cc4:	d2800003 	mov	x3, #0x0                   	// #0
    5cc8:	a9400c01 	ldp	x1, x3, [x0]
    5ccc:	f9400802 	ldr	x2, [x0, #16]
    5cd0:	ab020022 	adds	x2, x1, x2
    5cd4:	54000726 	b.vs	5db8 <e173+0x114>
    5cd8:	910023e1 	add	x1, sp, #0x8
    5cdc:	52800000 	mov	w0, #0x0                   	// #0
    5ce0:	a9008be3 	stp	x3, x2, [sp, #8]
    5ce4:	97fffd6c 	bl	5294 <fwp_data.part.0.constprop.0>
    5ce8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5cec:	9118c063 	add	x3, x3, #0x630
    5cf0:	aa0003f3 	mov	x19, x0
    5cf4:	f949d861 	ldr	x1, [x3, #5040]
    5cf8:	f949ec60 	ldr	x0, [x3, #5080]
    5cfc:	cb010261 	sub	x1, x19, x1
    5d00:	eb00403f 	cmp	x1, x0, lsl #16
    5d04:	54000322 	b.cs	5d68 <e173+0xc4>  // b.hs, b.nlast
    5d08:	d350fc22 	lsr	x2, x1, #16
    5d0c:	f949fc63 	ldr	x3, [x3, #5112]
    5d10:	8b020842 	add	x2, x2, x2, lsl #2
    5d14:	d37df042 	lsl	x2, x2, #3
    5d18:	8b020060 	add	x0, x3, x2
    5d1c:	f9401014 	ldr	x20, [x0, #32]
    5d20:	b4000254 	cbz	x20, 5d68 <e173+0xc4>
    5d24:	38626862 	ldrb	w2, [x3, x2]
    5d28:	7100085f 	cmp	w2, #0x2
    5d2c:	540003a0 	b.eq	5da0 <e173+0xfc>  // b.none
    5d30:	7100045f 	cmp	w2, #0x1
    5d34:	540001a1 	b.ne	5d68 <e173+0xc4>  // b.any
    5d38:	29430002 	ldp	w2, w0, [x0, #24]
    5d3c:	92403c21 	and	x1, x1, #0xffff
    5d40:	9b027c21 	mul	x1, x1, x2
    5d44:	d360fc21 	lsr	x1, x1, #32
    5d48:	eb00003f 	cmp	x1, x0
    5d4c:	540000e2 	b.cs	5d68 <e173+0xc4>  // b.hs, b.nlast
    5d50:	8b010294 	add	x20, x20, x1
    5d54:	39400280 	ldrb	w0, [x20]
    5d58:	7103fc1f 	cmp	w0, #0xff
    5d5c:	54000280 	b.eq	5dac <e173+0x108>  // b.none
    5d60:	52800020 	mov	w0, #0x1                   	// #1
    5d64:	39000280 	strb	w0, [x20]
    5d68:	aa1303e0 	mov	x0, x19
    5d6c:	97ffff12 	bl	59b4 <fwp_rc_share>
    5d70:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5d74:	f947f400 	ldr	x0, [x0, #4072]
    5d78:	f9400fe2 	ldr	x2, [sp, #24]
    5d7c:	f9400001 	ldr	x1, [x0]
    5d80:	eb010042 	subs	x2, x2, x1
    5d84:	d2800001 	mov	x1, #0x0                   	// #0
    5d88:	540001a1 	b.ne	5dbc <e173+0x118>  // b.any
    5d8c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d90:	aa1303e0 	mov	x0, x19
    5d94:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d98:	910103ff 	add	sp, sp, #0x40
    5d9c:	d65f03c0 	ret
    5da0:	72003c3f 	tst	w1, #0xffff
    5da4:	54fffe21 	b.ne	5d68 <e173+0xc4>  // b.any
    5da8:	17ffffeb 	b	5d54 <e173+0xb0>
    5dac:	aa1403e0 	mov	x0, x20
    5db0:	97fffb18 	bl	4a10 <fwp_rc_forget_slot>
    5db4:	17ffffeb 	b	5d60 <e173+0xbc>
    5db8:	97fff332 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5dbc:	97fff2b9 	bl	28a0 <__stack_chk_fail@plt>

0000000000005dc0 <fwp_drop0>:
    5dc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5dc4:	910003fd 	mov	x29, sp
    5dc8:	a90153f3 	stp	x19, x20, [sp, #16]
    5dcc:	f90013f5 	str	x21, [sp, #32]
    5dd0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    5dd4:	9118c2b4 	add	x20, x21, #0x630
    5dd8:	f949da81 	ldr	x1, [x20, #5040]
    5ddc:	f949ee82 	ldr	x2, [x20, #5080]
    5de0:	cb010001 	sub	x1, x0, x1
    5de4:	eb02403f 	cmp	x1, x2, lsl #16
    5de8:	54000382 	b.cs	5e58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5dec:	d350fc22 	lsr	x2, x1, #16
    5df0:	f949fe84 	ldr	x4, [x20, #5112]
    5df4:	8b020842 	add	x2, x2, x2, lsl #2
    5df8:	d37df042 	lsl	x2, x2, #3
    5dfc:	8b020083 	add	x3, x4, x2
    5e00:	f9401073 	ldr	x19, [x3, #32]
    5e04:	b40002b3 	cbz	x19, 5e58 <fwp_drop0+0x98>
    5e08:	38626882 	ldrb	w2, [x4, x2]
    5e0c:	7100085f 	cmp	w2, #0x2
    5e10:	540002c0 	b.eq	5e68 <fwp_drop0+0xa8>  // b.none
    5e14:	7100045f 	cmp	w2, #0x1
    5e18:	54000201 	b.ne	5e58 <fwp_drop0+0x98>  // b.any
    5e1c:	29430864 	ldp	w4, w2, [x3, #24]
    5e20:	92403c21 	and	x1, x1, #0xffff
    5e24:	9b047c21 	mul	x1, x1, x4
    5e28:	d360fc21 	lsr	x1, x1, #32
    5e2c:	eb02003f 	cmp	x1, x2
    5e30:	54000142 	b.cs	5e58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e34:	8b010273 	add	x19, x19, x1
    5e38:	39400261 	ldrb	w1, [x19]
    5e3c:	340000e1 	cbz	w1, 5e58 <fwp_drop0+0x98>
    5e40:	7100043f 	cmp	w1, #0x1
    5e44:	540001e0 	b.eq	5e80 <fwp_drop0+0xc0>  // b.none
    5e48:	7103fc3f 	cmp	w1, #0xff
    5e4c:	540002e0 	b.eq	5ea8 <fwp_drop0+0xe8>  // b.none
    5e50:	51000421 	sub	w1, w1, #0x1
    5e54:	39000261 	strb	w1, [x19]
    5e58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e5c:	f94013f5 	ldr	x21, [sp, #32]
    5e60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e64:	d65f03c0 	ret
    5e68:	72003c3f 	tst	w1, #0xffff
    5e6c:	54fffe60 	b.eq	5e38 <fwp_drop0+0x78>  // b.none
    5e70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5e74:	f94013f5 	ldr	x21, [sp, #32]
    5e78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5e7c:	d65f03c0 	ret
    5e80:	f9400813 	ldr	x19, [x0, #16]
    5e84:	97fffef3 	bl	5a50 <fwp_rc_free_arr>
    5e88:	9118c2a0 	add	x0, x21, #0x630
    5e8c:	f949d801 	ldr	x1, [x0, #5040]
    5e90:	f949ec00 	ldr	x0, [x0, #5080]
    5e94:	cb010261 	sub	x1, x19, x1
    5e98:	eb00403f 	cmp	x1, x0, lsl #16
    5e9c:	54fffde2 	b.cs	5e58 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ea0:	aa1303e0 	mov	x0, x19
    5ea4:	17ffffd2 	b	5dec <fwp_drop0+0x2c>
    5ea8:	ca534660 	eor	x0, x19, x19, lsr #17
    5eac:	9118c2b5 	add	x21, x21, #0x630
    5eb0:	ca402400 	eor	x0, x0, x0, lsr #9
    5eb4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5eb8:	f94a2400 	ldr	x0, [x0, #5192]
    5ebc:	b5000080 	cbnz	x0, 5ecc <fwp_drop0+0x10c>
    5ec0:	14000010 	b	5f00 <fwp_drop0+0x140>
    5ec4:	f9400800 	ldr	x0, [x0, #16]
    5ec8:	b40001c0 	cbz	x0, 5f00 <fwp_drop0+0x140>
    5ecc:	f9400001 	ldr	x1, [x0]
    5ed0:	eb13003f 	cmp	x1, x19
    5ed4:	54ffff81 	b.ne	5ec4 <fwp_drop0+0x104>  // b.any
    5ed8:	f9400401 	ldr	x1, [x0, #8]
    5edc:	d1000421 	sub	x1, x1, #0x1
    5ee0:	f9000401 	str	x1, [x0, #8]
    5ee4:	f103f83f 	cmp	x1, #0xfe
    5ee8:	54fffb81 	b.ne	5e58 <fwp_drop0+0x98>  // b.any
    5eec:	aa1303e0 	mov	x0, x19
    5ef0:	97fffac8 	bl	4a10 <fwp_rc_forget_slot>
    5ef4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ef8:	39000260 	strb	w0, [x19]
    5efc:	17ffffd7 	b	5e58 <fwp_drop0+0x98>
    5f00:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    5f04:	91114000 	add	x0, x0, #0x450
    5f08:	97fff63e 	bl	3800 <fwp_trap>
    5f0c:	d503201f 	nop

0000000000005f10 <fwp_drop1>:
    5f10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f14:	910003fd 	mov	x29, sp
    5f18:	a90153f3 	stp	x19, x20, [sp, #16]
    5f1c:	f90013f5 	str	x21, [sp, #32]
    5f20:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    5f24:	9118c2b4 	add	x20, x21, #0x630
    5f28:	f949da81 	ldr	x1, [x20, #5040]
    5f2c:	f949ee82 	ldr	x2, [x20, #5080]
    5f30:	cb010001 	sub	x1, x0, x1
    5f34:	eb02403f 	cmp	x1, x2, lsl #16
    5f38:	54000382 	b.cs	5fa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f3c:	d350fc22 	lsr	x2, x1, #16
    5f40:	f949fe84 	ldr	x4, [x20, #5112]
    5f44:	8b020842 	add	x2, x2, x2, lsl #2
    5f48:	d37df042 	lsl	x2, x2, #3
    5f4c:	8b020083 	add	x3, x4, x2
    5f50:	f9401073 	ldr	x19, [x3, #32]
    5f54:	b40002b3 	cbz	x19, 5fa8 <fwp_drop1+0x98>
    5f58:	38626882 	ldrb	w2, [x4, x2]
    5f5c:	7100085f 	cmp	w2, #0x2
    5f60:	540002c0 	b.eq	5fb8 <fwp_drop1+0xa8>  // b.none
    5f64:	7100045f 	cmp	w2, #0x1
    5f68:	54000201 	b.ne	5fa8 <fwp_drop1+0x98>  // b.any
    5f6c:	29430864 	ldp	w4, w2, [x3, #24]
    5f70:	92403c21 	and	x1, x1, #0xffff
    5f74:	9b047c21 	mul	x1, x1, x4
    5f78:	d360fc21 	lsr	x1, x1, #32
    5f7c:	eb02003f 	cmp	x1, x2
    5f80:	54000142 	b.cs	5fa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f84:	8b010273 	add	x19, x19, x1
    5f88:	39400261 	ldrb	w1, [x19]
    5f8c:	340000e1 	cbz	w1, 5fa8 <fwp_drop1+0x98>
    5f90:	7100043f 	cmp	w1, #0x1
    5f94:	540001e0 	b.eq	5fd0 <fwp_drop1+0xc0>  // b.none
    5f98:	7103fc3f 	cmp	w1, #0xff
    5f9c:	540002e0 	b.eq	5ff8 <fwp_drop1+0xe8>  // b.none
    5fa0:	51000421 	sub	w1, w1, #0x1
    5fa4:	39000261 	strb	w1, [x19]
    5fa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fac:	f94013f5 	ldr	x21, [sp, #32]
    5fb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fb4:	d65f03c0 	ret
    5fb8:	72003c3f 	tst	w1, #0xffff
    5fbc:	54fffe60 	b.eq	5f88 <fwp_drop1+0x78>  // b.none
    5fc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fc4:	f94013f5 	ldr	x21, [sp, #32]
    5fc8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fcc:	d65f03c0 	ret
    5fd0:	f9400813 	ldr	x19, [x0, #16]
    5fd4:	97fffe9f 	bl	5a50 <fwp_rc_free_arr>
    5fd8:	9118c2a0 	add	x0, x21, #0x630
    5fdc:	f949d801 	ldr	x1, [x0, #5040]
    5fe0:	f949ec00 	ldr	x0, [x0, #5080]
    5fe4:	cb010261 	sub	x1, x19, x1
    5fe8:	eb00403f 	cmp	x1, x0, lsl #16
    5fec:	54fffde2 	b.cs	5fa8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ff0:	aa1303e0 	mov	x0, x19
    5ff4:	17ffffd2 	b	5f3c <fwp_drop1+0x2c>
    5ff8:	ca534660 	eor	x0, x19, x19, lsr #17
    5ffc:	9118c2b5 	add	x21, x21, #0x630
    6000:	ca402400 	eor	x0, x0, x0, lsr #9
    6004:	8b200ea0 	add	x0, x21, w0, uxtb #3
    6008:	f94a2400 	ldr	x0, [x0, #5192]
    600c:	b5000080 	cbnz	x0, 601c <fwp_drop1+0x10c>
    6010:	14000010 	b	6050 <fwp_drop1+0x140>
    6014:	f9400800 	ldr	x0, [x0, #16]
    6018:	b40001c0 	cbz	x0, 6050 <fwp_drop1+0x140>
    601c:	f9400001 	ldr	x1, [x0]
    6020:	eb13003f 	cmp	x1, x19
    6024:	54ffff81 	b.ne	6014 <fwp_drop1+0x104>  // b.any
    6028:	f9400401 	ldr	x1, [x0, #8]
    602c:	d1000421 	sub	x1, x1, #0x1
    6030:	f9000401 	str	x1, [x0, #8]
    6034:	f103f83f 	cmp	x1, #0xfe
    6038:	54fffb81 	b.ne	5fa8 <fwp_drop1+0x98>  // b.any
    603c:	aa1303e0 	mov	x0, x19
    6040:	97fffa74 	bl	4a10 <fwp_rc_forget_slot>
    6044:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6048:	39000260 	strb	w0, [x19]
    604c:	17ffffd7 	b	5fa8 <fwp_drop1+0x98>
    6050:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    6054:	91114000 	add	x0, x0, #0x450
    6058:	97fff5ea 	bl	3800 <fwp_trap>
    605c:	d503201f 	nop

0000000000006060 <fwp_closure_drop>:
    6060:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xbb0>
    6064:	9118c0a4 	add	x4, x5, #0x630
    6068:	aa0003e1 	mov	x1, x0
    606c:	f949d882 	ldr	x2, [x4, #5040]
    6070:	f949ec80 	ldr	x0, [x4, #5080]
    6074:	cb020022 	sub	x2, x1, x2
    6078:	eb00405f 	cmp	x2, x0, lsl #16
    607c:	54000662 	b.cs	6148 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6080:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6084:	d350fc43 	lsr	x3, x2, #16
    6088:	910003fd 	mov	x29, sp
    608c:	8b030863 	add	x3, x3, x3, lsl #2
    6090:	f949fc84 	ldr	x4, [x4, #5112]
    6094:	d37df063 	lsl	x3, x3, #3
    6098:	f9000bf3 	str	x19, [sp, #16]
    609c:	8b030080 	add	x0, x4, x3
    60a0:	f9401013 	ldr	x19, [x0, #32]
    60a4:	b40002b3 	cbz	x19, 60f8 <fwp_closure_drop+0x98>
    60a8:	38636883 	ldrb	w3, [x4, x3]
    60ac:	7100087f 	cmp	w3, #0x2
    60b0:	54000420 	b.eq	6134 <fwp_closure_drop+0xd4>  // b.none
    60b4:	7100047f 	cmp	w3, #0x1
    60b8:	54000201 	b.ne	60f8 <fwp_closure_drop+0x98>  // b.any
    60bc:	29430003 	ldp	w3, w0, [x0, #24]
    60c0:	92403c42 	and	x2, x2, #0xffff
    60c4:	9b037c42 	mul	x2, x2, x3
    60c8:	d360fc42 	lsr	x2, x2, #32
    60cc:	eb00005f 	cmp	x2, x0
    60d0:	54000142 	b.cs	60f8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    60d4:	8b020273 	add	x19, x19, x2
    60d8:	39400260 	ldrb	w0, [x19]
    60dc:	340000e0 	cbz	w0, 60f8 <fwp_closure_drop+0x98>
    60e0:	7100041f 	cmp	w0, #0x1
    60e4:	54000100 	b.eq	6104 <fwp_closure_drop+0xa4>  // b.none
    60e8:	7103fc1f 	cmp	w0, #0xff
    60ec:	54000300 	b.eq	614c <fwp_closure_drop+0xec>  // b.none
    60f0:	51000400 	sub	w0, w0, #0x1
    60f4:	39000260 	strb	w0, [x19]
    60f8:	f9400bf3 	ldr	x19, [sp, #16]
    60fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6100:	d65f03c0 	ret
    6104:	d53bd040 	mrs	x0, tpidr_el0
    6108:	91400000 	add	x0, x0, #0x0, lsl #12
    610c:	91004000 	add	x0, x0, #0x10
    6110:	f9400000 	ldr	x0, [x0]
    6114:	b4000080 	cbz	x0, 6124 <fwp_closure_drop+0xc4>
    6118:	f9400bf3 	ldr	x19, [sp, #16]
    611c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6120:	17fff5d1 	b	3864 <fwp_closure_drop_push>
    6124:	f9400bf3 	ldr	x19, [sp, #16]
    6128:	aa0103e0 	mov	x0, x1
    612c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6130:	17fff63c 	b	3a20 <fwp_closure_drop.part.0>
    6134:	72003c5f 	tst	w2, #0xffff
    6138:	54fffd00 	b.eq	60d8 <fwp_closure_drop+0x78>  // b.none
    613c:	f9400bf3 	ldr	x19, [sp, #16]
    6140:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6144:	d65f03c0 	ret
    6148:	d65f03c0 	ret
    614c:	ca534660 	eor	x0, x19, x19, lsr #17
    6150:	9118c0a5 	add	x5, x5, #0x630
    6154:	ca402400 	eor	x0, x0, x0, lsr #9
    6158:	8b200ca0 	add	x0, x5, w0, uxtb #3
    615c:	f94a2400 	ldr	x0, [x0, #5192]
    6160:	b5000080 	cbnz	x0, 6170 <fwp_closure_drop+0x110>
    6164:	14000010 	b	61a4 <fwp_closure_drop+0x144>
    6168:	f9400800 	ldr	x0, [x0, #16]
    616c:	b40001c0 	cbz	x0, 61a4 <fwp_closure_drop+0x144>
    6170:	f9400001 	ldr	x1, [x0]
    6174:	eb13003f 	cmp	x1, x19
    6178:	54ffff81 	b.ne	6168 <fwp_closure_drop+0x108>  // b.any
    617c:	f9400401 	ldr	x1, [x0, #8]
    6180:	d1000421 	sub	x1, x1, #0x1
    6184:	f9000401 	str	x1, [x0, #8]
    6188:	f103f83f 	cmp	x1, #0xfe
    618c:	54fffb61 	b.ne	60f8 <fwp_closure_drop+0x98>  // b.any
    6190:	aa1303e0 	mov	x0, x19
    6194:	97fffa1f 	bl	4a10 <fwp_rc_forget_slot>
    6198:	12800020 	mov	w0, #0xfffffffe            	// #-2
    619c:	39000260 	strb	w0, [x19]
    61a0:	17ffffd6 	b	60f8 <fwp_closure_drop+0x98>
    61a4:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    61a8:	91114000 	add	x0, x0, #0x450
    61ac:	97fff595 	bl	3800 <fwp_trap>

00000000000061b0 <fwp_owned_tape_release>:
    61b0:	b4000940 	cbz	x0, 62d8 <fwp_owned_tape_release+0x128>
    61b4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    61b8:	910003fd 	mov	x29, sp
    61bc:	a90153f3 	stp	x19, x20, [sp, #16]
    61c0:	aa0003f3 	mov	x19, x0
    61c4:	f9400000 	ldr	x0, [x0]
    61c8:	b4000060 	cbz	x0, 61d4 <fwp_owned_tape_release+0x24>
    61cc:	f9400661 	ldr	x1, [x19, #8]
    61d0:	f9000401 	str	x1, [x0, #8]
    61d4:	f9400661 	ldr	x1, [x19, #8]
    61d8:	b4000041 	cbz	x1, 61e0 <fwp_owned_tape_release+0x30>
    61dc:	f9000020 	str	x0, [x1]
    61e0:	f9400a60 	ldr	x0, [x19, #16]
    61e4:	f9403401 	ldr	x1, [x0, #104]
    61e8:	b40005c1 	cbz	x1, 62a0 <fwp_owned_tape_release+0xf0>
    61ec:	a9450a60 	ldp	x0, x2, [x19, #80]
    61f0:	eb00005f 	cmp	x2, x0
    61f4:	540002ed 	b.le	6250 <fwp_owned_tape_release+0xa0>
    61f8:	d2800014 	mov	x20, #0x0                   	// #0
    61fc:	f90013f5 	str	x21, [sp, #32]
    6200:	d2800015 	mov	x21, #0x0                   	// #0
    6204:	d503201f 	nop
    6208:	f9402260 	ldr	x0, [x19, #64]
    620c:	910006b5 	add	x21, x21, #0x1
    6210:	f8746800 	ldr	x0, [x0, x20]
    6214:	d63f0020 	blr	x1
    6218:	f9402260 	ldr	x0, [x19, #64]
    621c:	f9400a61 	ldr	x1, [x19, #16]
    6220:	8b140000 	add	x0, x0, x20
    6224:	91004294 	add	x20, x20, #0x10
    6228:	f9400400 	ldr	x0, [x0, #8]
    622c:	f9403421 	ldr	x1, [x1, #104]
    6230:	d63f0020 	blr	x1
    6234:	a9450261 	ldp	x1, x0, [x19, #80]
    6238:	cb010000 	sub	x0, x0, x1
    623c:	eb15001f 	cmp	x0, x21
    6240:	f9400a60 	ldr	x0, [x19, #16]
    6244:	f9403401 	ldr	x1, [x0, #104]
    6248:	54fffe0c 	b.gt	6208 <fwp_owned_tape_release+0x58>
    624c:	f94013f5 	ldr	x21, [sp, #32]
    6250:	f9403663 	ldr	x3, [x19, #104]
    6254:	f9401262 	ldr	x2, [x19, #32]
    6258:	f100007f 	cmp	x3, #0x0
    625c:	540001ed 	b.le	6298 <fwp_owned_tape_release+0xe8>
    6260:	d2800014 	mov	x20, #0x0                   	// #0
    6264:	d503201f 	nop
    6268:	f9402660 	ldr	x0, [x19, #72]
    626c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6270:	eb02001f 	cmp	x0, x2
    6274:	540000c0 	b.eq	628c <fwp_owned_tape_release+0xdc>  // b.none
    6278:	d63f0020 	blr	x1
    627c:	f9400a60 	ldr	x0, [x19, #16]
    6280:	f9401262 	ldr	x2, [x19, #32]
    6284:	f9403663 	ldr	x3, [x19, #104]
    6288:	f9403401 	ldr	x1, [x0, #104]
    628c:	91000694 	add	x20, x20, #0x1
    6290:	eb14007f 	cmp	x3, x20
    6294:	54fffeac 	b.gt	6268 <fwp_owned_tape_release+0xb8>
    6298:	aa0203e0 	mov	x0, x2
    629c:	d63f0020 	blr	x1
    62a0:	f9401660 	ldr	x0, [x19, #40]
    62a4:	97ffff6f 	bl	6060 <fwp_closure_drop>
    62a8:	f9401a60 	ldr	x0, [x19, #48]
    62ac:	97ffff6d 	bl	6060 <fwp_closure_drop>
    62b0:	f9401e60 	ldr	x0, [x19, #56]
    62b4:	97ffff6b 	bl	6060 <fwp_closure_drop>
    62b8:	f9402260 	ldr	x0, [x19, #64]
    62bc:	97fffa75 	bl	4c90 <fwp_mem_free>
    62c0:	f9402660 	ldr	x0, [x19, #72]
    62c4:	97fffa73 	bl	4c90 <fwp_mem_free>
    62c8:	aa1303e0 	mov	x0, x19
    62cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    62d0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62d4:	17fffa6f 	b	4c90 <fwp_mem_free>
    62d8:	d65f03c0 	ret
    62dc:	d503201f 	nop

00000000000062e0 <fwp_tape_finish>:
    62e0:	d10203ff 	sub	sp, sp, #0x80
    62e4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    62e8:	f947f421 	ldr	x1, [x1, #4072]
    62ec:	a9047bfd 	stp	x29, x30, [sp, #64]
    62f0:	910103fd 	add	x29, sp, #0x40
    62f4:	a9065bf5 	stp	x21, x22, [sp, #96]
    62f8:	a90763f7 	stp	x23, x24, [sp, #112]
    62fc:	d00000d7 	adrp	x23, 20000 <__data_start>
    6300:	910142f6 	add	x22, x23, #0x50
    6304:	f9400022 	ldr	x2, [x1]
    6308:	f9001fe2 	str	x2, [sp, #56]
    630c:	d2800002 	mov	x2, #0x0                   	// #0
    6310:	910382c0 	add	x0, x22, #0xe0
    6314:	97fff83c 	bl	4404 <fwp_tape_buffers_dispose>
    6318:	f9008edf 	str	xzr, [x22, #280]
    631c:	f9406ec0 	ldr	x0, [x22, #216]
    6320:	f100001f 	cmp	x0, #0x0
    6324:	5400034d 	b.le	638c <fwp_tape_finish+0xac>
    6328:	910003f8 	mov	x24, sp
    632c:	d2800015 	mov	x21, #0x0                   	// #0
    6330:	a90553f3 	stp	x19, x20, [sp, #80]
    6334:	d2800014 	mov	x20, #0x0                   	// #0
    6338:	91000694 	add	x20, x20, #0x1
    633c:	f94046d3 	ldr	x19, [x22, #136]
    6340:	8b150273 	add	x19, x19, x21
    6344:	9101a2b5 	add	x21, x21, #0x68
    6348:	aa1303e0 	mov	x0, x19
    634c:	97fff332 	bl	3014 <fwp_tape_unlink_scope>
    6350:	aa1803e0 	mov	x0, x24
    6354:	a9440663 	ldp	x3, x1, [x19, #64]
    6358:	f9001be1 	str	x1, [sp, #48]
    635c:	f9400e62 	ldr	x2, [x19, #24]
    6360:	a9020be3 	stp	x3, x2, [sp, #32]
    6364:	ad410261 	ldp	q1, q0, [x19, #32]
    6368:	ad0003e1 	stp	q1, q0, [sp]
    636c:	97fff826 	bl	4404 <fwp_tape_buffers_dispose>
    6370:	f9403260 	ldr	x0, [x19, #96]
    6374:	97ffff8f 	bl	61b0 <fwp_owned_tape_release>
    6378:	f900327f 	str	xzr, [x19, #96]
    637c:	f9406ec0 	ldr	x0, [x22, #216]
    6380:	eb14001f 	cmp	x0, x20
    6384:	54fffdac 	b.gt	6338 <fwp_tape_finish+0x58>
    6388:	a94553f3 	ldp	x19, x20, [sp, #80]
    638c:	910142e0 	add	x0, x23, #0x50
    6390:	f9404400 	ldr	x0, [x0, #136]
    6394:	b4000040 	cbz	x0, 639c <fwp_tape_finish+0xbc>
    6398:	97fff7fa 	bl	4380 <ad_raw_free.part.0>
    639c:	910142f7 	add	x23, x23, #0x50
    63a0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    63a4:	f947f400 	ldr	x0, [x0, #4072]
    63a8:	f90046ff 	str	xzr, [x23, #136]
    63ac:	f9006eff 	str	xzr, [x23, #216]
    63b0:	f90092ff 	str	xzr, [x23, #288]
    63b4:	f900b2ff 	str	xzr, [x23, #352]
    63b8:	f9401fe2 	ldr	x2, [sp, #56]
    63bc:	f9400001 	ldr	x1, [x0]
    63c0:	eb010042 	subs	x2, x2, x1
    63c4:	d2800001 	mov	x1, #0x0                   	// #0
    63c8:	540000c1 	b.ne	63e0 <fwp_tape_finish+0x100>  // b.any
    63cc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    63d0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    63d4:	a94763f7 	ldp	x23, x24, [sp, #112]
    63d8:	910203ff 	add	sp, sp, #0x80
    63dc:	d65f03c0 	ret
    63e0:	a90553f3 	stp	x19, x20, [sp, #80]
    63e4:	97fff12f 	bl	28a0 <__stack_chk_fail@plt>
    63e8:	d503201f 	nop
    63ec:	d503201f 	nop

00000000000063f0 <fwp_tape_scope_release>:
    63f0:	d10243ff 	sub	sp, sp, #0x90
    63f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    63f8:	910103fd 	add	x29, sp, #0x40
    63fc:	a90553f3 	stp	x19, x20, [sp, #80]
    6400:	aa0003f4 	mov	x20, x0
    6404:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6408:	f947f400 	ldr	x0, [x0, #4072]
    640c:	b9400285 	ldr	w5, [x20]
    6410:	f9400001 	ldr	x1, [x0]
    6414:	f9001fe1 	str	x1, [sp, #56]
    6418:	d2800001 	mov	x1, #0x0                   	// #0
    641c:	37f806c5 	tbnz	w5, #31, 64f4 <fwp_tape_scope_release+0x104>
    6420:	a90763f7 	stp	x23, x24, [sp, #112]
    6424:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6428:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    642c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6430:	d00000d3 	adrp	x19, 20000 <__data_start>
    6434:	910003f7 	mov	x23, sp
    6438:	91014273 	add	x19, x19, #0x50
    643c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6440:	a9065bf5 	stp	x21, x22, [sp, #96]
    6444:	52800d16 	mov	w22, #0x68                  	// #104
    6448:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    644c:	f90043f9 	str	x25, [sp, #128]
    6450:	14000006 	b	6468 <fwp_tape_scope_release+0x78>
    6454:	97fff7ec 	bl	4404 <fwp_tape_buffers_dispose>
    6458:	aa1903e0 	mov	x0, x25
    645c:	97ffff55 	bl	61b0 <fwp_owned_tape_release>
    6460:	b9400285 	ldr	w5, [x20]
    6464:	37f80425 	tbnz	w5, #31, 64e8 <fwp_tape_scope_release+0xf8>
    6468:	f9404666 	ldr	x6, [x19, #136]
    646c:	9b367ca5 	smull	x5, w5, w22
    6470:	8b0500c0 	add	x0, x6, x5
    6474:	97fff2e8 	bl	3014 <fwp_tape_unlink_scope>
    6478:	ad410001 	ldp	q1, q0, [x0, #32]
    647c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6480:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6484:	f9400c03 	ldr	x3, [x0, #24]
    6488:	ad0003e1 	stp	q1, q0, [sp]
    648c:	b86568c1 	ldr	w1, [x6, x5]
    6490:	a9440804 	ldp	x4, x2, [x0, #64]
    6494:	b900041f 	str	wzr, [x0, #4]
    6498:	f9403019 	ldr	x25, [x0, #96]
    649c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    64a0:	f9000c1f 	str	xzr, [x0, #24]
    64a4:	a9020fe4 	stp	x4, x3, [sp, #32]
    64a8:	f9001be2 	str	x2, [sp, #48]
    64ac:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    64b0:	f900301f 	str	xzr, [x0, #96]
    64b4:	6b15003f 	cmp	w1, w21
    64b8:	540000e8 	b.hi	64d4 <fwp_tape_scope_release+0xe4>  // b.pmore
    64bc:	9343fca5 	asr	x5, x5, #3
    64c0:	f940b260 	ldr	x0, [x19, #352]
    64c4:	9b187ca5 	mul	x5, x5, x24
    64c8:	eb0000bf 	cmp	x5, x0
    64cc:	5400004a 	b.ge	64d4 <fwp_tape_scope_release+0xe4>  // b.tcont
    64d0:	f900b265 	str	x5, [x19, #352]
    64d4:	aa1703e0 	mov	x0, x23
    64d8:	b5fffbf9 	cbnz	x25, 6454 <fwp_tape_scope_release+0x64>
    64dc:	97fff812 	bl	4524 <fwp_tape_buffers_release>
    64e0:	b9400285 	ldr	w5, [x20]
    64e4:	36fffc25 	tbz	w5, #31, 6468 <fwp_tape_scope_release+0x78>
    64e8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    64ec:	a94763f7 	ldp	x23, x24, [sp, #112]
    64f0:	f94043f9 	ldr	x25, [sp, #128]
    64f4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    64f8:	f947f400 	ldr	x0, [x0, #4072]
    64fc:	f9401fe2 	ldr	x2, [sp, #56]
    6500:	f9400001 	ldr	x1, [x0]
    6504:	eb010042 	subs	x2, x2, x1
    6508:	d2800001 	mov	x1, #0x0                   	// #0
    650c:	540000a1 	b.ne	6520 <fwp_tape_scope_release+0x130>  // b.any
    6510:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6514:	a94553f3 	ldp	x19, x20, [sp, #80]
    6518:	910243ff 	add	sp, sp, #0x90
    651c:	d65f03c0 	ret
    6520:	a9065bf5 	stp	x21, x22, [sp, #96]
    6524:	a90763f7 	stp	x23, x24, [sp, #112]
    6528:	f90043f9 	str	x25, [sp, #128]
    652c:	97fff0dd 	bl	28a0 <__stack_chk_fail@plt>

0000000000006530 <fwp_drop4>:
    6530:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6534:	910003fd 	mov	x29, sp
    6538:	a9025bf5 	stp	x21, x22, [sp, #32]
    653c:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    6540:	9118c2d5 	add	x21, x22, #0x630
    6544:	a90153f3 	stp	x19, x20, [sp, #16]
    6548:	aa0003f3 	mov	x19, x0
    654c:	f949daa1 	ldr	x1, [x21, #5040]
    6550:	f949eea0 	ldr	x0, [x21, #5080]
    6554:	cb010261 	sub	x1, x19, x1
    6558:	eb00403f 	cmp	x1, x0, lsl #16
    655c:	54000382 	b.cs	65cc <fwp_drop4+0x9c>  // b.hs, b.nlast
    6560:	d350fc22 	lsr	x2, x1, #16
    6564:	f949fea3 	ldr	x3, [x21, #5112]
    6568:	8b020842 	add	x2, x2, x2, lsl #2
    656c:	d37df042 	lsl	x2, x2, #3
    6570:	8b020060 	add	x0, x3, x2
    6574:	f9401014 	ldr	x20, [x0, #32]
    6578:	b40002b4 	cbz	x20, 65cc <fwp_drop4+0x9c>
    657c:	38626862 	ldrb	w2, [x3, x2]
    6580:	7100085f 	cmp	w2, #0x2
    6584:	540002c0 	b.eq	65dc <fwp_drop4+0xac>  // b.none
    6588:	7100045f 	cmp	w2, #0x1
    658c:	54000201 	b.ne	65cc <fwp_drop4+0x9c>  // b.any
    6590:	29430002 	ldp	w2, w0, [x0, #24]
    6594:	92403c21 	and	x1, x1, #0xffff
    6598:	9b027c21 	mul	x1, x1, x2
    659c:	d360fc21 	lsr	x1, x1, #32
    65a0:	eb00003f 	cmp	x1, x0
    65a4:	54000142 	b.cs	65cc <fwp_drop4+0x9c>  // b.hs, b.nlast
    65a8:	8b010294 	add	x20, x20, x1
    65ac:	39400280 	ldrb	w0, [x20]
    65b0:	340000e0 	cbz	w0, 65cc <fwp_drop4+0x9c>
    65b4:	7100041f 	cmp	w0, #0x1
    65b8:	540001e0 	b.eq	65f4 <fwp_drop4+0xc4>  // b.none
    65bc:	7103fc1f 	cmp	w0, #0xff
    65c0:	540007c0 	b.eq	66b8 <fwp_drop4+0x188>  // b.none
    65c4:	51000400 	sub	w0, w0, #0x1
    65c8:	39000280 	strb	w0, [x20]
    65cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    65d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    65d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    65d8:	d65f03c0 	ret
    65dc:	72003c3f 	tst	w1, #0xffff
    65e0:	54fffe60 	b.eq	65ac <fwp_drop4+0x7c>  // b.none
    65e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    65e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    65ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    65f0:	d65f03c0 	ret
    65f4:	9118c2c2 	add	x2, x22, #0x630
    65f8:	f9400660 	ldr	x0, [x19, #8]
    65fc:	f949d841 	ldr	x1, [x2, #5040]
    6600:	f949ec42 	ldr	x2, [x2, #5080]
    6604:	cb010001 	sub	x1, x0, x1
    6608:	eb02403f 	cmp	x1, x2, lsl #16
    660c:	54000362 	b.cs	6678 <fwp_drop4+0x148>  // b.hs, b.nlast
    6610:	d350fc22 	lsr	x2, x1, #16
    6614:	8b020842 	add	x2, x2, x2, lsl #2
    6618:	d37df042 	lsl	x2, x2, #3
    661c:	8b020064 	add	x4, x3, x2
    6620:	f9401094 	ldr	x20, [x4, #32]
    6624:	b40002b4 	cbz	x20, 6678 <fwp_drop4+0x148>
    6628:	38626862 	ldrb	w2, [x3, x2]
    662c:	7100085f 	cmp	w2, #0x2
    6630:	540003e0 	b.eq	66ac <fwp_drop4+0x17c>  // b.none
    6634:	7100045f 	cmp	w2, #0x1
    6638:	54000201 	b.ne	6678 <fwp_drop4+0x148>  // b.any
    663c:	29430883 	ldp	w3, w2, [x4, #24]
    6640:	92403c21 	and	x1, x1, #0xffff
    6644:	9b037c21 	mul	x1, x1, x3
    6648:	d360fc21 	lsr	x1, x1, #32
    664c:	eb02003f 	cmp	x1, x2
    6650:	54000142 	b.cs	6678 <fwp_drop4+0x148>  // b.hs, b.nlast
    6654:	8b010294 	add	x20, x20, x1
    6658:	39400281 	ldrb	w1, [x20]
    665c:	340000e1 	cbz	w1, 6678 <fwp_drop4+0x148>
    6660:	7100043f 	cmp	w1, #0x1
    6664:	54000200 	b.eq	66a4 <fwp_drop4+0x174>  // b.none
    6668:	7103fc3f 	cmp	w1, #0xff
    666c:	54000580 	b.eq	671c <fwp_drop4+0x1ec>  // b.none
    6670:	51000421 	sub	w1, w1, #0x1
    6674:	39000281 	strb	w1, [x20]
    6678:	f9400a74 	ldr	x20, [x19, #16]
    667c:	aa1303e0 	mov	x0, x19
    6680:	97fffcf4 	bl	5a50 <fwp_rc_free_arr>
    6684:	9118c2c0 	add	x0, x22, #0x630
    6688:	f949d801 	ldr	x1, [x0, #5040]
    668c:	f949ec00 	ldr	x0, [x0, #5080]
    6690:	cb010281 	sub	x1, x20, x1
    6694:	eb00403f 	cmp	x1, x0, lsl #16
    6698:	54fff9a2 	b.cs	65cc <fwp_drop4+0x9c>  // b.hs, b.nlast
    669c:	aa1403f3 	mov	x19, x20
    66a0:	17ffffb0 	b	6560 <fwp_drop4+0x30>
    66a4:	97fffceb 	bl	5a50 <fwp_rc_free_arr>
    66a8:	17fffff4 	b	6678 <fwp_drop4+0x148>
    66ac:	72003c3f 	tst	w1, #0xffff
    66b0:	54fffe41 	b.ne	6678 <fwp_drop4+0x148>  // b.any
    66b4:	17ffffe9 	b	6658 <fwp_drop4+0x128>
    66b8:	ca544681 	eor	x1, x20, x20, lsr #17
    66bc:	9118c2c0 	add	x0, x22, #0x630
    66c0:	ca412421 	eor	x1, x1, x1, lsr #9
    66c4:	8b210c01 	add	x1, x0, w1, uxtb #3
    66c8:	f94a2420 	ldr	x0, [x1, #5192]
    66cc:	b5000080 	cbnz	x0, 66dc <fwp_drop4+0x1ac>
    66d0:	14000010 	b	6710 <fwp_drop4+0x1e0>
    66d4:	f9400800 	ldr	x0, [x0, #16]
    66d8:	b40001c0 	cbz	x0, 6710 <fwp_drop4+0x1e0>
    66dc:	f9400001 	ldr	x1, [x0]
    66e0:	eb14003f 	cmp	x1, x20
    66e4:	54ffff81 	b.ne	66d4 <fwp_drop4+0x1a4>  // b.any
    66e8:	f9400401 	ldr	x1, [x0, #8]
    66ec:	d1000421 	sub	x1, x1, #0x1
    66f0:	f9000401 	str	x1, [x0, #8]
    66f4:	f103f83f 	cmp	x1, #0xfe
    66f8:	54fff6a1 	b.ne	65cc <fwp_drop4+0x9c>  // b.any
    66fc:	aa1403e0 	mov	x0, x20
    6700:	97fff8c4 	bl	4a10 <fwp_rc_forget_slot>
    6704:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6708:	39000280 	strb	w0, [x20]
    670c:	17ffffb0 	b	65cc <fwp_drop4+0x9c>
    6710:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    6714:	91114000 	add	x0, x0, #0x450
    6718:	97fff43a 	bl	3800 <fwp_trap>
    671c:	ca544680 	eor	x0, x20, x20, lsr #17
    6720:	9118c2c1 	add	x1, x22, #0x630
    6724:	ca402400 	eor	x0, x0, x0, lsr #9
    6728:	8b200c20 	add	x0, x1, w0, uxtb #3
    672c:	f94a2400 	ldr	x0, [x0, #5192]
    6730:	b5000080 	cbnz	x0, 6740 <fwp_drop4+0x210>
    6734:	17fffff7 	b	6710 <fwp_drop4+0x1e0>
    6738:	f9400800 	ldr	x0, [x0, #16]
    673c:	b4fffea0 	cbz	x0, 6710 <fwp_drop4+0x1e0>
    6740:	f9400001 	ldr	x1, [x0]
    6744:	eb14003f 	cmp	x1, x20
    6748:	54ffff81 	b.ne	6738 <fwp_drop4+0x208>  // b.any
    674c:	f9400401 	ldr	x1, [x0, #8]
    6750:	d1000421 	sub	x1, x1, #0x1
    6754:	f9000401 	str	x1, [x0, #8]
    6758:	f103f83f 	cmp	x1, #0xfe
    675c:	54fff8e1 	b.ne	6678 <fwp_drop4+0x148>  // b.any
    6760:	aa1403e0 	mov	x0, x20
    6764:	97fff8ab 	bl	4a10 <fwp_rc_forget_slot>
    6768:	12800020 	mov	w0, #0xfffffffe            	// #-2
    676c:	39000280 	strb	w0, [x20]
    6770:	17ffffc2 	b	6678 <fwp_drop4+0x148>

0000000000006774 <fwp_arg_drop37>:
    6774:	7100003f 	cmp	w1, #0x0
    6778:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    677c:	54000041 	b.ne	6784 <fwp_arg_drop37+0x10>  // b.any
    6780:	d65f03c0 	ret
    6784:	f9400000 	ldr	x0, [x0]
    6788:	17ffff6a 	b	6530 <fwp_drop4>
    678c:	d503201f 	nop

0000000000006790 <fwp_task_dispose>:
    6790:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6794:	910003fd 	mov	x29, sp
    6798:	f9000bf3 	str	x19, [sp, #16]
    679c:	aa0003f3 	mov	x19, x0
    67a0:	39414000 	ldrb	w0, [x0, #80]
    67a4:	36000720 	tbz	w0, #0, 6888 <fwp_task_dispose+0xf8>
    67a8:	f9400a60 	ldr	x0, [x19, #16]
    67ac:	b50006e0 	cbnz	x0, 6888 <fwp_task_dispose+0xf8>
    67b0:	a9478660 	ldp	x0, x1, [x19, #120]
    67b4:	39014e7f 	strb	wzr, [x19, #83]
    67b8:	f9003e7f 	str	xzr, [x19, #120]
    67bc:	f100003f 	cmp	x1, #0x0
    67c0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    67c4:	54000040 	b.eq	67cc <fwp_task_dispose+0x3c>  // b.none
    67c8:	d63f0020 	blr	x1
    67cc:	f9405660 	ldr	x0, [x19, #168]
    67d0:	97fff930 	bl	4c90 <fwp_mem_free>
    67d4:	f900567f 	str	xzr, [x19, #168]
    67d8:	b9405e60 	ldr	w0, [x19, #92]
    67dc:	7100041f 	cmp	w0, #0x1
    67e0:	54000420 	b.eq	6864 <fwp_task_dispose+0xd4>  // b.none
    67e4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    67e8:	9118c042 	add	x2, x2, #0x630
    67ec:	f949d840 	ldr	x0, [x2, #5040]
    67f0:	f949ec41 	ldr	x1, [x2, #5080]
    67f4:	cb000260 	sub	x0, x19, x0
    67f8:	eb01401f 	cmp	x0, x1, lsl #16
    67fc:	540002e2 	b.cs	6858 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6800:	d350fc01 	lsr	x1, x0, #16
    6804:	f949fc44 	ldr	x4, [x2, #5112]
    6808:	8b010821 	add	x1, x1, x1, lsl #2
    680c:	d37df021 	lsl	x1, x1, #3
    6810:	8b010083 	add	x3, x4, x1
    6814:	f9401062 	ldr	x2, [x3, #32]
    6818:	b4000202 	cbz	x2, 6858 <fwp_task_dispose+0xc8>
    681c:	38616881 	ldrb	w1, [x4, x1]
    6820:	7100083f 	cmp	w1, #0x2
    6824:	54000280 	b.eq	6874 <fwp_task_dispose+0xe4>  // b.none
    6828:	7100043f 	cmp	w1, #0x1
    682c:	54000161 	b.ne	6858 <fwp_task_dispose+0xc8>  // b.any
    6830:	29430464 	ldp	w4, w1, [x3, #24]
    6834:	92403c00 	and	x0, x0, #0xffff
    6838:	9b047c00 	mul	x0, x0, x4
    683c:	d360fc00 	lsr	x0, x0, #32
    6840:	eb01001f 	cmp	x0, x1
    6844:	540000a2 	b.cs	6858 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6848:	8b000042 	add	x2, x2, x0
    684c:	39400040 	ldrb	w0, [x2]
    6850:	7100041f 	cmp	w0, #0x1
    6854:	54000080 	b.eq	6864 <fwp_task_dispose+0xd4>  // b.none
    6858:	f9400bf3 	ldr	x19, [sp, #16]
    685c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6860:	d65f03c0 	ret
    6864:	aa1303e0 	mov	x0, x19
    6868:	f9400bf3 	ldr	x19, [sp, #16]
    686c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6870:	17fff908 	b	4c90 <fwp_mem_free>
    6874:	72003c1f 	tst	w0, #0xffff
    6878:	54fffea0 	b.eq	684c <fwp_task_dispose+0xbc>  // b.none
    687c:	f9400bf3 	ldr	x19, [sp, #16]
    6880:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6884:	d65f03c0 	ret
    6888:	97fff01a 	bl	28f0 <abort@plt>
    688c:	d503201f 	nop

0000000000006890 <fwp_free_zombie>:
    6890:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6894:	910003fd 	mov	x29, sp
    6898:	a90153f3 	stp	x19, x20, [sp, #16]
    689c:	d00000d4 	adrp	x20, 20000 <__data_start>
    68a0:	91014281 	add	x1, x20, #0x50
    68a4:	f940b433 	ldr	x19, [x1, #360]
    68a8:	b4000333 	cbz	x19, 690c <fwp_free_zombie+0x7c>
    68ac:	f9404c20 	ldr	x0, [x1, #152]
    68b0:	eb00027f 	cmp	x19, x0
    68b4:	540002c0 	b.eq	690c <fwp_free_zombie+0x7c>  // b.none
    68b8:	b9417022 	ldr	w2, [x1, #368]
    68bc:	f9400a60 	ldr	x0, [x19, #16]
    68c0:	7100fc5f 	cmp	w2, #0x3f
    68c4:	5400078c 	b.gt	69b4 <fwp_free_zombie+0x124>
    68c8:	91060023 	add	x3, x1, #0x180
    68cc:	11000444 	add	w4, w2, #0x1
    68d0:	b9017024 	str	w4, [x1, #368]
    68d4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    68d8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    68dc:	a9530261 	ldp	x1, x0, [x19, #304]
    68e0:	b4000741 	cbz	x1, 69c8 <fwp_free_zombie+0x138>
    68e4:	f9009c20 	str	x0, [x1, #312]
    68e8:	b4000040 	cbz	x0, 68f0 <fwp_free_zombie+0x60>
    68ec:	f9009801 	str	x1, [x0, #304]
    68f0:	91014294 	add	x20, x20, #0x50
    68f4:	b9405e60 	ldr	w0, [x19, #92]
    68f8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    68fc:	f900b69f 	str	xzr, [x20, #360]
    6900:	34000140 	cbz	w0, 6928 <fwp_free_zombie+0x98>
    6904:	7100041f 	cmp	w0, #0x1
    6908:	54000080 	b.eq	6918 <fwp_free_zombie+0x88>  // b.none
    690c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6910:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6914:	d65f03c0 	ret
    6918:	aa1303e0 	mov	x0, x19
    691c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6920:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6924:	17ffff9b 	b	6790 <fwp_task_dispose>
    6928:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbb0>
    692c:	9118c082 	add	x2, x4, #0x630
    6930:	f949d841 	ldr	x1, [x2, #5040]
    6934:	f949ec40 	ldr	x0, [x2, #5080]
    6938:	cb010261 	sub	x1, x19, x1
    693c:	eb00403f 	cmp	x1, x0, lsl #16
    6940:	54fffe62 	b.cs	690c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6944:	d350fc20 	lsr	x0, x1, #16
    6948:	f949fc43 	ldr	x3, [x2, #5112]
    694c:	8b000800 	add	x0, x0, x0, lsl #2
    6950:	d37df000 	lsl	x0, x0, #3
    6954:	8b000062 	add	x2, x3, x0
    6958:	f9401054 	ldr	x20, [x2, #32]
    695c:	b4fffd94 	cbz	x20, 690c <fwp_free_zombie+0x7c>
    6960:	38606860 	ldrb	w0, [x3, x0]
    6964:	7100081f 	cmp	w0, #0x2
    6968:	54000360 	b.eq	69d4 <fwp_free_zombie+0x144>  // b.none
    696c:	7100041f 	cmp	w0, #0x1
    6970:	54fffce1 	b.ne	690c <fwp_free_zombie+0x7c>  // b.any
    6974:	29430043 	ldp	w3, w0, [x2, #24]
    6978:	92403c21 	and	x1, x1, #0xffff
    697c:	9b037c21 	mul	x1, x1, x3
    6980:	d360fc21 	lsr	x1, x1, #32
    6984:	eb00003f 	cmp	x1, x0
    6988:	54fffc22 	b.cs	690c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    698c:	8b010294 	add	x20, x20, x1
    6990:	39400280 	ldrb	w0, [x20]
    6994:	34fffbc0 	cbz	w0, 690c <fwp_free_zombie+0x7c>
    6998:	7100041f 	cmp	w0, #0x1
    699c:	54fffbe0 	b.eq	6918 <fwp_free_zombie+0x88>  // b.none
    69a0:	7103fc1f 	cmp	w0, #0xff
    69a4:	540001e0 	b.eq	69e0 <fwp_free_zombie+0x150>  // b.none
    69a8:	51000400 	sub	w0, w0, #0x1
    69ac:	39000280 	strb	w0, [x20]
    69b0:	17ffffd7 	b	690c <fwp_free_zombie+0x7c>
    69b4:	f9400e61 	ldr	x1, [x19, #24]
    69b8:	97fff002 	bl	29c0 <munmap@plt>
    69bc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    69c0:	a9530261 	ldp	x1, x0, [x19, #304]
    69c4:	b5fff901 	cbnz	x1, 68e4 <fwp_free_zombie+0x54>
    69c8:	91014282 	add	x2, x20, #0x50
    69cc:	f901c040 	str	x0, [x2, #896]
    69d0:	17ffffc6 	b	68e8 <fwp_free_zombie+0x58>
    69d4:	72003c3f 	tst	w1, #0xffff
    69d8:	54fff9a1 	b.ne	690c <fwp_free_zombie+0x7c>  // b.any
    69dc:	17ffffed 	b	6990 <fwp_free_zombie+0x100>
    69e0:	ca544680 	eor	x0, x20, x20, lsr #17
    69e4:	9118c084 	add	x4, x4, #0x630
    69e8:	ca402400 	eor	x0, x0, x0, lsr #9
    69ec:	8b200c80 	add	x0, x4, w0, uxtb #3
    69f0:	f94a2400 	ldr	x0, [x0, #5192]
    69f4:	b5000080 	cbnz	x0, 6a04 <fwp_free_zombie+0x174>
    69f8:	14000010 	b	6a38 <fwp_free_zombie+0x1a8>
    69fc:	f9400800 	ldr	x0, [x0, #16]
    6a00:	b40001c0 	cbz	x0, 6a38 <fwp_free_zombie+0x1a8>
    6a04:	f9400001 	ldr	x1, [x0]
    6a08:	eb14003f 	cmp	x1, x20
    6a0c:	54ffff81 	b.ne	69fc <fwp_free_zombie+0x16c>  // b.any
    6a10:	f9400401 	ldr	x1, [x0, #8]
    6a14:	d1000421 	sub	x1, x1, #0x1
    6a18:	f9000401 	str	x1, [x0, #8]
    6a1c:	f103f83f 	cmp	x1, #0xfe
    6a20:	54fff761 	b.ne	690c <fwp_free_zombie+0x7c>  // b.any
    6a24:	aa1403e0 	mov	x0, x20
    6a28:	97fff7fa 	bl	4a10 <fwp_rc_forget_slot>
    6a2c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a30:	39000280 	strb	w0, [x20]
    6a34:	17ffffb6 	b	690c <fwp_free_zombie+0x7c>
    6a38:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    6a3c:	91114000 	add	x0, x0, #0x450
    6a40:	97fff370 	bl	3800 <fwp_trap>

0000000000006a44 <fwp_block>:
    6a44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a48:	910003fd 	mov	x29, sp
    6a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    6a50:	d00000d3 	adrp	x19, 20000 <__data_start>
    6a54:	91014274 	add	x20, x19, #0x50
    6a58:	f9406682 	ldr	x2, [x20, #200]
    6a5c:	b4000622 	cbz	x2, 6b20 <fwp_block+0xdc>
    6a60:	91014261 	add	x1, x19, #0x50
    6a64:	f9408040 	ldr	x0, [x2, #256]
    6a68:	f9006420 	str	x0, [x1, #200]
    6a6c:	b4000680 	cbz	x0, 6b3c <fwp_block+0xf8>
    6a70:	91014263 	add	x3, x19, #0x50
    6a74:	3901505f 	strb	wzr, [x2, #84]
    6a78:	f9404c64 	ldr	x4, [x3, #152]
    6a7c:	eb02009f 	cmp	x4, x2
    6a80:	54000440 	b.eq	6b08 <fwp_block+0xc4>  // b.none
    6a84:	f941c465 	ldr	x5, [x3, #904]
    6a88:	f9004c62 	str	x2, [x3, #152]
    6a8c:	f9400441 	ldr	x1, [x2, #8]
    6a90:	f9004885 	str	x5, [x4, #144]
    6a94:	f941c865 	ldr	x5, [x3, #912]
    6a98:	f9004c85 	str	x5, [x4, #152]
    6a9c:	f941cc65 	ldr	x5, [x3, #920]
    6aa0:	f9005085 	str	x5, [x4, #160]
    6aa4:	f941d065 	ldr	x5, [x3, #928]
    6aa8:	f9005485 	str	x5, [x4, #168]
    6aac:	f941d465 	ldr	x5, [x3, #936]
    6ab0:	f9005885 	str	x5, [x4, #176]
    6ab4:	f941d865 	ldr	x5, [x3, #944]
    6ab8:	f9005c85 	str	x5, [x4, #184]
    6abc:	f941dc65 	ldr	x5, [x3, #952]
    6ac0:	f9006085 	str	x5, [x4, #192]
    6ac4:	f9400480 	ldr	x0, [x4, #8]
    6ac8:	f9404844 	ldr	x4, [x2, #144]
    6acc:	f901c464 	str	x4, [x3, #904]
    6ad0:	f9404c44 	ldr	x4, [x2, #152]
    6ad4:	f901c864 	str	x4, [x3, #912]
    6ad8:	f9405044 	ldr	x4, [x2, #160]
    6adc:	f901cc64 	str	x4, [x3, #920]
    6ae0:	f9405444 	ldr	x4, [x2, #168]
    6ae4:	f901d064 	str	x4, [x3, #928]
    6ae8:	f9405844 	ldr	x4, [x2, #176]
    6aec:	f901d464 	str	x4, [x3, #936]
    6af0:	a94b8844 	ldp	x4, x2, [x2, #184]
    6af4:	f901d864 	str	x4, [x3, #944]
    6af8:	f901dc62 	str	x2, [x3, #952]
    6afc:	97ffef81 	bl	2900 <swapcontext@plt>
    6b00:	97ffff64 	bl	6890 <fwp_free_zombie>
    6b04:	d503201f 	nop
    6b08:	91014260 	add	x0, x19, #0x50
    6b0c:	b943c000 	ldr	w0, [x0, #960]
    6b10:	340001a0 	cbz	w0, 6b44 <fwp_block+0x100>
    6b14:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b18:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b1c:	d65f03c0 	ret
    6b20:	97fff6e9 	bl	46c4 <fwp_poll_events>
    6b24:	f9406682 	ldr	x2, [x20, #200]
    6b28:	b4ffffc2 	cbz	x2, 6b20 <fwp_block+0xdc>
    6b2c:	91014261 	add	x1, x19, #0x50
    6b30:	f9408040 	ldr	x0, [x2, #256]
    6b34:	f9006420 	str	x0, [x1, #200]
    6b38:	b5fff9c0 	cbnz	x0, 6a70 <fwp_block+0x2c>
    6b3c:	f900603f 	str	xzr, [x1, #192]
    6b40:	17ffffcc 	b	6a70 <fwp_block+0x2c>
    6b44:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    6b48:	91160000 	add	x0, x0, #0x580
    6b4c:	97ffefb9 	bl	2a30 <getenv@plt>
    6b50:	5284e202 	mov	w2, #0x2710                	// #10000
    6b54:	b4000060 	cbz	x0, 6b60 <fwp_block+0x11c>
    6b58:	39400001 	ldrb	w1, [x0]
    6b5c:	350000c1 	cbnz	w1, 6b74 <fwp_block+0x130>
    6b60:	91014273 	add	x19, x19, #0x50
    6b64:	b903c262 	str	w2, [x19, #960]
    6b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b70:	d65f03c0 	ret
    6b74:	52800142 	mov	w2, #0xa                   	// #10
    6b78:	d2800001 	mov	x1, #0x0                   	// #0
    6b7c:	97ffeefd 	bl	2770 <strtoll@plt>
    6b80:	d1000403 	sub	x3, x0, #0x1
    6b84:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6b88:	eb02007f 	cmp	x3, x2
    6b8c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6b90:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6b94:	17fffff3 	b	6b60 <fwp_block+0x11c>
    6b98:	d503201f 	nop
    6b9c:	d503201f 	nop

0000000000006ba0 <fwp_drop10>:
    6ba0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6ba4:	910003fd 	mov	x29, sp
    6ba8:	a90153f3 	stp	x19, x20, [sp, #16]
    6bac:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    6bb0:	f90013f5 	str	x21, [sp, #32]
    6bb4:	9118c275 	add	x21, x19, #0x630
    6bb8:	f949daa1 	ldr	x1, [x21, #5040]
    6bbc:	f949eea2 	ldr	x2, [x21, #5080]
    6bc0:	cb010001 	sub	x1, x0, x1
    6bc4:	eb02403f 	cmp	x1, x2, lsl #16
    6bc8:	54000382 	b.cs	6c38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6bcc:	d350fc22 	lsr	x2, x1, #16
    6bd0:	f949fea3 	ldr	x3, [x21, #5112]
    6bd4:	8b020842 	add	x2, x2, x2, lsl #2
    6bd8:	d37df042 	lsl	x2, x2, #3
    6bdc:	8b020064 	add	x4, x3, x2
    6be0:	f9401094 	ldr	x20, [x4, #32]
    6be4:	b40002b4 	cbz	x20, 6c38 <fwp_drop10+0x98>
    6be8:	38626862 	ldrb	w2, [x3, x2]
    6bec:	7100085f 	cmp	w2, #0x2
    6bf0:	540007a0 	b.eq	6ce4 <fwp_drop10+0x144>  // b.none
    6bf4:	7100045f 	cmp	w2, #0x1
    6bf8:	54000201 	b.ne	6c38 <fwp_drop10+0x98>  // b.any
    6bfc:	29430885 	ldp	w5, w2, [x4, #24]
    6c00:	92403c21 	and	x1, x1, #0xffff
    6c04:	9b057c21 	mul	x1, x1, x5
    6c08:	d360fc21 	lsr	x1, x1, #32
    6c0c:	eb02003f 	cmp	x1, x2
    6c10:	54000142 	b.cs	6c38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c14:	8b010294 	add	x20, x20, x1
    6c18:	39400281 	ldrb	w1, [x20]
    6c1c:	340000e1 	cbz	w1, 6c38 <fwp_drop10+0x98>
    6c20:	7100043f 	cmp	w1, #0x1
    6c24:	54000120 	b.eq	6c48 <fwp_drop10+0xa8>  // b.none
    6c28:	7103fc3f 	cmp	w1, #0xff
    6c2c:	540007c0 	b.eq	6d24 <fwp_drop10+0x184>  // b.none
    6c30:	51000421 	sub	w1, w1, #0x1
    6c34:	39000281 	strb	w1, [x20]
    6c38:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c3c:	f94013f5 	ldr	x21, [sp, #32]
    6c40:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c44:	d65f03c0 	ret
    6c48:	f9400001 	ldr	x1, [x0]
    6c4c:	b7f80581 	tbnz	x1, #63, 6cfc <fwp_drop10+0x15c>
    6c50:	9118c273 	add	x19, x19, #0x630
    6c54:	f949da61 	ldr	x1, [x19, #5040]
    6c58:	f949ee62 	ldr	x2, [x19, #5080]
    6c5c:	cb010001 	sub	x1, x0, x1
    6c60:	eb02403f 	cmp	x1, x2, lsl #16
    6c64:	54fffea2 	b.cs	6c38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c68:	d350fc22 	lsr	x2, x1, #16
    6c6c:	8b020842 	add	x2, x2, x2, lsl #2
    6c70:	d37df042 	lsl	x2, x2, #3
    6c74:	8b020065 	add	x5, x3, x2
    6c78:	f94010a4 	ldr	x4, [x5, #32]
    6c7c:	b4fffde4 	cbz	x4, 6c38 <fwp_drop10+0x98>
    6c80:	38626862 	ldrb	w2, [x3, x2]
    6c84:	7100085f 	cmp	w2, #0x2
    6c88:	54000220 	b.eq	6ccc <fwp_drop10+0x12c>  // b.none
    6c8c:	7100045f 	cmp	w2, #0x1
    6c90:	54fffd41 	b.ne	6c38 <fwp_drop10+0x98>  // b.any
    6c94:	294308a3 	ldp	w3, w2, [x5, #24]
    6c98:	92403c21 	and	x1, x1, #0xffff
    6c9c:	9b037c21 	mul	x1, x1, x3
    6ca0:	d360fc21 	lsr	x1, x1, #32
    6ca4:	eb02003f 	cmp	x1, x2
    6ca8:	54fffc82 	b.cs	6c38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6cac:	8b010084 	add	x4, x4, x1
    6cb0:	39400081 	ldrb	w1, [x4]
    6cb4:	7100043f 	cmp	w1, #0x1
    6cb8:	54fffc01 	b.ne	6c38 <fwp_drop10+0x98>  // b.any
    6cbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cc0:	f94013f5 	ldr	x21, [sp, #32]
    6cc4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6cc8:	17fff7f2 	b	4c90 <fwp_mem_free>
    6ccc:	72003c3f 	tst	w1, #0xffff
    6cd0:	54ffff00 	b.eq	6cb0 <fwp_drop10+0x110>  // b.none
    6cd4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cd8:	f94013f5 	ldr	x21, [sp, #32]
    6cdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ce0:	d65f03c0 	ret
    6ce4:	72003c3f 	tst	w1, #0xffff
    6ce8:	54fff980 	b.eq	6c18 <fwp_drop10+0x78>  // b.none
    6cec:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cf0:	f94013f5 	ldr	x21, [sp, #32]
    6cf4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6cf8:	d65f03c0 	ret
    6cfc:	f9400414 	ldr	x20, [x0, #8]
    6d00:	97fffb54 	bl	5a50 <fwp_rc_free_arr>
    6d04:	9118c260 	add	x0, x19, #0x630
    6d08:	f949d801 	ldr	x1, [x0, #5040]
    6d0c:	f949ec00 	ldr	x0, [x0, #5080]
    6d10:	cb010281 	sub	x1, x20, x1
    6d14:	eb00403f 	cmp	x1, x0, lsl #16
    6d18:	54fff902 	b.cs	6c38 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d1c:	aa1403e0 	mov	x0, x20
    6d20:	17ffffab 	b	6bcc <fwp_drop10+0x2c>
    6d24:	ca544680 	eor	x0, x20, x20, lsr #17
    6d28:	9118c273 	add	x19, x19, #0x630
    6d2c:	ca402400 	eor	x0, x0, x0, lsr #9
    6d30:	8b200e60 	add	x0, x19, w0, uxtb #3
    6d34:	f94a2400 	ldr	x0, [x0, #5192]
    6d38:	b5000080 	cbnz	x0, 6d48 <fwp_drop10+0x1a8>
    6d3c:	14000010 	b	6d7c <fwp_drop10+0x1dc>
    6d40:	f9400800 	ldr	x0, [x0, #16]
    6d44:	b40001c0 	cbz	x0, 6d7c <fwp_drop10+0x1dc>
    6d48:	f9400001 	ldr	x1, [x0]
    6d4c:	eb14003f 	cmp	x1, x20
    6d50:	54ffff81 	b.ne	6d40 <fwp_drop10+0x1a0>  // b.any
    6d54:	f9400401 	ldr	x1, [x0, #8]
    6d58:	d1000421 	sub	x1, x1, #0x1
    6d5c:	f9000401 	str	x1, [x0, #8]
    6d60:	f103f83f 	cmp	x1, #0xfe
    6d64:	54fff6a1 	b.ne	6c38 <fwp_drop10+0x98>  // b.any
    6d68:	aa1403e0 	mov	x0, x20
    6d6c:	97fff729 	bl	4a10 <fwp_rc_forget_slot>
    6d70:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6d74:	39000280 	strb	w0, [x20]
    6d78:	17ffffb0 	b	6c38 <fwp_drop10+0x98>
    6d7c:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    6d80:	91114000 	add	x0, x0, #0x450
    6d84:	97fff29f 	bl	3800 <fwp_trap>
    6d88:	d503201f 	nop
    6d8c:	d503201f 	nop

0000000000006d90 <fwp_caps173>:
    6d90:	34000041 	cbz	w1, 6d98 <fwp_caps173+0x8>
    6d94:	d65f03c0 	ret
    6d98:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    6d9c:	9118c063 	add	x3, x3, #0x630
    6da0:	f949d861 	ldr	x1, [x3, #5040]
    6da4:	f949ec62 	ldr	x2, [x3, #5080]
    6da8:	cb010001 	sub	x1, x0, x1
    6dac:	eb02403f 	cmp	x1, x2, lsl #16
    6db0:	54ffff22 	b.cs	6d94 <fwp_caps173+0x4>  // b.hs, b.nlast
    6db4:	d350fc22 	lsr	x2, x1, #16
    6db8:	f949fc65 	ldr	x5, [x3, #5112]
    6dbc:	8b020842 	add	x2, x2, x2, lsl #2
    6dc0:	d37df042 	lsl	x2, x2, #3
    6dc4:	8b0200a4 	add	x4, x5, x2
    6dc8:	f9401083 	ldr	x3, [x4, #32]
    6dcc:	b4fffe43 	cbz	x3, 6d94 <fwp_caps173+0x4>
    6dd0:	386268a2 	ldrb	w2, [x5, x2]
    6dd4:	7100085f 	cmp	w2, #0x2
    6dd8:	540001c0 	b.eq	6e10 <fwp_caps173+0x80>  // b.none
    6ddc:	7100045f 	cmp	w2, #0x1
    6de0:	54fffda1 	b.ne	6d94 <fwp_caps173+0x4>  // b.any
    6de4:	29430885 	ldp	w5, w2, [x4, #24]
    6de8:	92403c21 	and	x1, x1, #0xffff
    6dec:	9b057c21 	mul	x1, x1, x5
    6df0:	d360fc21 	lsr	x1, x1, #32
    6df4:	eb02003f 	cmp	x1, x2
    6df8:	54fffce2 	b.cs	6d94 <fwp_caps173+0x4>  // b.hs, b.nlast
    6dfc:	8b010063 	add	x3, x3, x1
    6e00:	39400061 	ldrb	w1, [x3]
    6e04:	7100043f 	cmp	w1, #0x1
    6e08:	54fffc61 	b.ne	6d94 <fwp_caps173+0x4>  // b.any
    6e0c:	17fff7a1 	b	4c90 <fwp_mem_free>
    6e10:	72003c3f 	tst	w1, #0xffff
    6e14:	54ffff60 	b.eq	6e00 <fwp_caps173+0x70>  // b.none
    6e18:	d65f03c0 	ret
    6e1c:	d503201f 	nop

0000000000006e20 <f37>:
    6e20:	d101c3ff 	sub	sp, sp, #0x70
    6e24:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6e28:	f947f421 	ldr	x1, [x1, #4072]
    6e2c:	a9027bfd 	stp	x29, x30, [sp, #32]
    6e30:	910083fd 	add	x29, sp, #0x20
    6e34:	a90563f7 	stp	x23, x24, [sp, #80]
    6e38:	f0000397 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    6e3c:	9118c2e3 	add	x3, x23, #0x630
    6e40:	a90353f3 	stp	x19, x20, [sp, #48]
    6e44:	a9045bf5 	stp	x21, x22, [sp, #64]
    6e48:	aa0003f6 	mov	x22, x0
    6e4c:	a9066bf9 	stp	x25, x26, [sp, #96]
    6e50:	f949ec62 	ldr	x2, [x3, #5080]
    6e54:	f9400024 	ldr	x4, [x1]
    6e58:	f9000fe4 	str	x4, [sp, #24]
    6e5c:	d2800004 	mov	x4, #0x0                   	// #0
    6e60:	f949d861 	ldr	x1, [x3, #5040]
    6e64:	d370bc42 	lsl	x2, x2, #16
    6e68:	b40016c0 	cbz	x0, 7140 <f37+0x320>
    6e6c:	f9400818 	ldr	x24, [x0, #16]
    6e70:	cb010301 	sub	x1, x24, x1
    6e74:	eb02003f 	cmp	x1, x2
    6e78:	540003e2 	b.cs	6ef4 <f37+0xd4>  // b.hs, b.nlast
    6e7c:	f949fc60 	ldr	x0, [x3, #5112]
    6e80:	d350fc22 	lsr	x2, x1, #16
    6e84:	8b020842 	add	x2, x2, x2, lsl #2
    6e88:	8b020c02 	add	x2, x0, x2, lsl #3
    6e8c:	f9401040 	ldr	x0, [x2, #32]
    6e90:	b4000320 	cbz	x0, 6ef4 <f37+0xd4>
    6e94:	39400043 	ldrb	w3, [x2]
    6e98:	7100087f 	cmp	w3, #0x2
    6e9c:	54001440 	b.eq	7124 <f37+0x304>  // b.none
    6ea0:	7100047f 	cmp	w3, #0x1
    6ea4:	54000241 	b.ne	6eec <f37+0xcc>  // b.any
    6ea8:	29430843 	ldp	w3, w2, [x2, #24]
    6eac:	92403c21 	and	x1, x1, #0xffff
    6eb0:	9b037c21 	mul	x1, x1, x3
    6eb4:	d360fc21 	lsr	x1, x1, #32
    6eb8:	eb02003f 	cmp	x1, x2
    6ebc:	54000182 	b.cs	6eec <f37+0xcc>  // b.hs, b.nlast
    6ec0:	8b010000 	add	x0, x0, x1
    6ec4:	39400001 	ldrb	w1, [x0]
    6ec8:	34000121 	cbz	w1, 6eec <f37+0xcc>
    6ecc:	d00000c2 	adrp	x2, 20000 <__data_start>
    6ed0:	91014042 	add	x2, x2, #0x50
    6ed4:	b9413043 	ldr	w3, [x2, #304]
    6ed8:	350012c3 	cbnz	w3, 7130 <f37+0x310>
    6edc:	7103f43f 	cmp	w1, #0xfd
    6ee0:	54001728 	b.hi	71c4 <f37+0x3a4>  // b.pmore
    6ee4:	11000421 	add	w1, w1, #0x1
    6ee8:	39000001 	strb	w1, [x0]
    6eec:	d2800000 	mov	x0, #0x0                   	// #0
    6ef0:	b40000f6 	cbz	x22, 6f0c <f37+0xec>
    6ef4:	aa1603e1 	mov	x1, x22
    6ef8:	d2800000 	mov	x0, #0x0                   	// #0
    6efc:	d503201f 	nop
    6f00:	f9400821 	ldr	x1, [x1, #16]
    6f04:	91000400 	add	x0, x0, #0x1
    6f08:	b5ffffc1 	cbnz	x1, 6f00 <f37+0xe0>
    6f0c:	b4001238 	cbz	x24, 7150 <f37+0x330>
    6f10:	aa1803e1 	mov	x1, x24
    6f14:	d2800002 	mov	x2, #0x0                   	// #0
    6f18:	f9400821 	ldr	x1, [x1, #16]
    6f1c:	91000442 	add	x2, x2, #0x1
    6f20:	b5ffffc1 	cbnz	x1, 6f18 <f37+0xf8>
    6f24:	eb00005f 	cmp	x2, x0
    6f28:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6f2c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    6f30:	eb01033f 	cmp	x25, x1
    6f34:	540014e8 	b.hi	71d0 <f37+0x3b0>  // b.pmore
    6f38:	d37ffb33 	lsl	x19, x25, #1
    6f3c:	52800041 	mov	w1, #0x2                   	// #2
    6f40:	91000660 	add	x0, x19, #0x1
    6f44:	d37df000 	lsl	x0, x0, #3
    6f48:	97fff872 	bl	5110 <fwp_heap_alloc>
    6f4c:	9118c2e1 	add	x1, x23, #0x630
    6f50:	aa0003fa 	mov	x26, x0
    6f54:	f9000013 	str	x19, [x0]
    6f58:	aa0103e0 	mov	x0, x1
    6f5c:	f949d821 	ldr	x1, [x1, #5040]
    6f60:	f949ec00 	ldr	x0, [x0, #5080]
    6f64:	cb010341 	sub	x1, x26, x1
    6f68:	eb00403f 	cmp	x1, x0, lsl #16
    6f6c:	54000342 	b.cs	6fd4 <f37+0x1b4>  // b.hs, b.nlast
    6f70:	9118c2e2 	add	x2, x23, #0x630
    6f74:	d350fc20 	lsr	x0, x1, #16
    6f78:	8b000800 	add	x0, x0, x0, lsl #2
    6f7c:	f949fc43 	ldr	x3, [x2, #5112]
    6f80:	d37df002 	lsl	x2, x0, #3
    6f84:	8b020060 	add	x0, x3, x2
    6f88:	f9401013 	ldr	x19, [x0, #32]
    6f8c:	b4000253 	cbz	x19, 6fd4 <f37+0x1b4>
    6f90:	38626862 	ldrb	w2, [x3, x2]
    6f94:	7100085f 	cmp	w2, #0x2
    6f98:	54000c00 	b.eq	7118 <f37+0x2f8>  // b.none
    6f9c:	7100045f 	cmp	w2, #0x1
    6fa0:	540001a1 	b.ne	6fd4 <f37+0x1b4>  // b.any
    6fa4:	29430002 	ldp	w2, w0, [x0, #24]
    6fa8:	92403c21 	and	x1, x1, #0xffff
    6fac:	9b027c21 	mul	x1, x1, x2
    6fb0:	d360fc21 	lsr	x1, x1, #32
    6fb4:	eb00003f 	cmp	x1, x0
    6fb8:	540000e2 	b.cs	6fd4 <f37+0x1b4>  // b.hs, b.nlast
    6fbc:	8b010273 	add	x19, x19, x1
    6fc0:	39400260 	ldrb	w0, [x19]
    6fc4:	7103fc1f 	cmp	w0, #0xff
    6fc8:	54000e80 	b.eq	7198 <f37+0x378>  // b.none
    6fcc:	52800020 	mov	w0, #0x1                   	// #1
    6fd0:	39000260 	strb	w0, [x19]
    6fd4:	b4000259 	cbz	x25, 701c <f37+0x1fc>
    6fd8:	8b191359 	add	x25, x26, x25, lsl #4
    6fdc:	aa1a03f3 	mov	x19, x26
    6fe0:	aa1603f5 	mov	x21, x22
    6fe4:	aa1803f4 	mov	x20, x24
    6fe8:	f9400683 	ldr	x3, [x20, #8]
    6fec:	f94006a2 	ldr	x2, [x21, #8]
    6ff0:	f9400861 	ldr	x1, [x3, #16]
    6ff4:	f9400840 	ldr	x0, [x2, #16]
    6ff8:	fd400461 	ldr	d1, [x3, #8]
    6ffc:	fd400440 	ldr	d0, [x2, #8]
    7000:	97fff9e8 	bl	57a0 <w120>
    7004:	f9000660 	str	x0, [x19, #8]
    7008:	f8010e61 	str	x1, [x19, #16]!
    700c:	f9400a94 	ldr	x20, [x20, #16]
    7010:	f9400ab5 	ldr	x21, [x21, #16]
    7014:	eb13033f 	cmp	x25, x19
    7018:	54fffe81 	b.ne	6fe8 <f37+0x1c8>  // b.any
    701c:	aa1803e0 	mov	x0, x24
    7020:	97fffd44 	bl	6530 <fwp_drop4>
    7024:	aa1603e0 	mov	x0, x22
    7028:	97fffd42 	bl	6530 <fwp_drop4>
    702c:	9118c2f7 	add	x23, x23, #0x630
    7030:	aa1a03e0 	mov	x0, x26
    7034:	97fffa38 	bl	5914 <w176.constprop.0>
    7038:	aa0103f3 	mov	x19, x1
    703c:	aa0003f4 	mov	x20, x0
    7040:	aa1a03e0 	mov	x0, x26
    7044:	97fffed7 	bl	6ba0 <fwp_drop10>
    7048:	a900cff4 	stp	x20, x19, [sp, #8]
    704c:	910023e1 	add	x1, sp, #0x8
    7050:	52800000 	mov	w0, #0x0                   	// #0
    7054:	97fff890 	bl	5294 <fwp_data.part.0.constprop.0>
    7058:	f949dae1 	ldr	x1, [x23, #5040]
    705c:	aa0003f3 	mov	x19, x0
    7060:	f949eee0 	ldr	x0, [x23, #5080]
    7064:	cb010261 	sub	x1, x19, x1
    7068:	eb00403f 	cmp	x1, x0, lsl #16
    706c:	54000322 	b.cs	70d0 <f37+0x2b0>  // b.hs, b.nlast
    7070:	d350fc22 	lsr	x2, x1, #16
    7074:	f949fee3 	ldr	x3, [x23, #5112]
    7078:	8b020842 	add	x2, x2, x2, lsl #2
    707c:	d37df042 	lsl	x2, x2, #3
    7080:	8b020060 	add	x0, x3, x2
    7084:	f9401014 	ldr	x20, [x0, #32]
    7088:	b4000254 	cbz	x20, 70d0 <f37+0x2b0>
    708c:	38626862 	ldrb	w2, [x3, x2]
    7090:	7100085f 	cmp	w2, #0x2
    7094:	540003c0 	b.eq	710c <f37+0x2ec>  // b.none
    7098:	7100045f 	cmp	w2, #0x1
    709c:	540001a1 	b.ne	70d0 <f37+0x2b0>  // b.any
    70a0:	29430002 	ldp	w2, w0, [x0, #24]
    70a4:	92403c21 	and	x1, x1, #0xffff
    70a8:	9b027c21 	mul	x1, x1, x2
    70ac:	d360fc21 	lsr	x1, x1, #32
    70b0:	eb00003f 	cmp	x1, x0
    70b4:	540000e2 	b.cs	70d0 <f37+0x2b0>  // b.hs, b.nlast
    70b8:	8b010294 	add	x20, x20, x1
    70bc:	39400280 	ldrb	w0, [x20]
    70c0:	7103fc1f 	cmp	w0, #0xff
    70c4:	54000640 	b.eq	718c <f37+0x36c>  // b.none
    70c8:	52800020 	mov	w0, #0x1                   	// #1
    70cc:	39000280 	strb	w0, [x20]
    70d0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    70d4:	f947f400 	ldr	x0, [x0, #4072]
    70d8:	f9400fe2 	ldr	x2, [sp, #24]
    70dc:	f9400001 	ldr	x1, [x0]
    70e0:	eb010042 	subs	x2, x2, x1
    70e4:	d2800001 	mov	x1, #0x0                   	// #0
    70e8:	54000721 	b.ne	71cc <f37+0x3ac>  // b.any
    70ec:	a9427bfd 	ldp	x29, x30, [sp, #32]
    70f0:	aa1303e0 	mov	x0, x19
    70f4:	a94353f3 	ldp	x19, x20, [sp, #48]
    70f8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    70fc:	a94563f7 	ldp	x23, x24, [sp, #80]
    7100:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7104:	9101c3ff 	add	sp, sp, #0x70
    7108:	d65f03c0 	ret
    710c:	72003c3f 	tst	w1, #0xffff
    7110:	54fffe01 	b.ne	70d0 <f37+0x2b0>  // b.any
    7114:	17ffffea 	b	70bc <f37+0x29c>
    7118:	72003c3f 	tst	w1, #0xffff
    711c:	54fff5c1 	b.ne	6fd4 <f37+0x1b4>  // b.any
    7120:	17ffffa8 	b	6fc0 <f37+0x1a0>
    7124:	72003c3f 	tst	w1, #0xffff
    7128:	54ffee21 	b.ne	6eec <f37+0xcc>  // b.any
    712c:	17ffff66 	b	6ec4 <f37+0xa4>
    7130:	f940ac43 	ldr	x3, [x2, #344]
    7134:	91000463 	add	x3, x3, #0x1
    7138:	f900ac43 	str	x3, [x2, #344]
    713c:	17ffff68 	b	6edc <f37+0xbc>
    7140:	cb0103e1 	neg	x1, x1
    7144:	eb02003f 	cmp	x1, x2
    7148:	540002e3 	b.cc	71a4 <f37+0x384>  // b.lo, b.ul, b.last
    714c:	d503201f 	nop
    7150:	52800041 	mov	w1, #0x2                   	// #2
    7154:	d2800100 	mov	x0, #0x8                   	// #8
    7158:	97fff7ee 	bl	5110 <fwp_heap_alloc>
    715c:	aa0003e1 	mov	x1, x0
    7160:	9118c2e0 	add	x0, x23, #0x630
    7164:	aa0103fa 	mov	x26, x1
    7168:	d2800018 	mov	x24, #0x0                   	// #0
    716c:	f900003f 	str	xzr, [x1]
    7170:	f949d801 	ldr	x1, [x0, #5040]
    7174:	f949ec00 	ldr	x0, [x0, #5080]
    7178:	cb010341 	sub	x1, x26, x1
    717c:	eb00403f 	cmp	x1, x0, lsl #16
    7180:	54fff4e2 	b.cs	701c <f37+0x1fc>  // b.hs, b.nlast
    7184:	d2800019 	mov	x25, #0x0                   	// #0
    7188:	17ffff7a 	b	6f70 <f37+0x150>
    718c:	aa1403e0 	mov	x0, x20
    7190:	97fff620 	bl	4a10 <fwp_rc_forget_slot>
    7194:	17ffffcd 	b	70c8 <f37+0x2a8>
    7198:	aa1303e0 	mov	x0, x19
    719c:	97fff61d 	bl	4a10 <fwp_rc_forget_slot>
    71a0:	17ffff8b 	b	6fcc <f37+0x1ac>
    71a4:	f949fc62 	ldr	x2, [x3, #5112]
    71a8:	d350fc20 	lsr	x0, x1, #16
    71ac:	8b000800 	add	x0, x0, x0, lsl #2
    71b0:	8b000c42 	add	x2, x2, x0, lsl #3
    71b4:	f9401040 	ldr	x0, [x2, #32]
    71b8:	b4fffcc0 	cbz	x0, 7150 <f37+0x330>
    71bc:	d2800018 	mov	x24, #0x0                   	// #0
    71c0:	17ffff35 	b	6e94 <f37+0x74>
    71c4:	97fff5cc 	bl	48f4 <fwp_rc_wide_dup>
    71c8:	17ffff49 	b	6eec <f37+0xcc>
    71cc:	97ffedb5 	bl	28a0 <__stack_chk_fail@plt>
    71d0:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    71d4:	91164000 	add	x0, x0, #0x590
    71d8:	97fff18a 	bl	3800 <fwp_trap>
    71dc:	d503201f 	nop

00000000000071e0 <fwp_owned_entry37>:
    71e0:	f9400000 	ldr	x0, [x0]
    71e4:	17ffff0f 	b	6e20 <f37>
    71e8:	d503201f 	nop
    71ec:	d503201f 	nop

00000000000071f0 <e37>:
    71f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    71f4:	910003fd 	mov	x29, sp
    71f8:	f9000bf3 	str	x19, [sp, #16]
    71fc:	f9400013 	ldr	x19, [x0]
    7200:	aa1303e0 	mov	x0, x19
    7204:	97fff9ec 	bl	59b4 <fwp_rc_share>
    7208:	aa1303e0 	mov	x0, x19
    720c:	97ffff05 	bl	6e20 <f37>
    7210:	aa0003f3 	mov	x19, x0
    7214:	97fff9e8 	bl	59b4 <fwp_rc_share>
    7218:	aa1303e0 	mov	x0, x19
    721c:	f9400bf3 	ldr	x19, [sp, #16]
    7220:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7224:	d65f03c0 	ret
    7228:	d503201f 	nop
    722c:	d503201f 	nop

0000000000007230 <fwp_args37>:
    7230:	7100003f 	cmp	w1, #0x0
    7234:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7238:	54000041 	b.ne	7240 <fwp_args37+0x10>  // b.any
    723c:	d65f03c0 	ret
    7240:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    7244:	9118c042 	add	x2, x2, #0x630
    7248:	f9400001 	ldr	x1, [x0]
    724c:	f949d843 	ldr	x3, [x2, #5040]
    7250:	f949ec40 	ldr	x0, [x2, #5080]
    7254:	cb030021 	sub	x1, x1, x3
    7258:	eb00403f 	cmp	x1, x0, lsl #16
    725c:	54ffff02 	b.cs	723c <fwp_args37+0xc>  // b.hs, b.nlast
    7260:	d350fc20 	lsr	x0, x1, #16
    7264:	f949fc44 	ldr	x4, [x2, #5112]
    7268:	8b000800 	add	x0, x0, x0, lsl #2
    726c:	d37df002 	lsl	x2, x0, #3
    7270:	8b020083 	add	x3, x4, x2
    7274:	f9401060 	ldr	x0, [x3, #32]
    7278:	b4fffe20 	cbz	x0, 723c <fwp_args37+0xc>
    727c:	38626882 	ldrb	w2, [x4, x2]
    7280:	7100085f 	cmp	w2, #0x2
    7284:	54000320 	b.eq	72e8 <fwp_args37+0xb8>  // b.none
    7288:	7100045f 	cmp	w2, #0x1
    728c:	54fffd81 	b.ne	723c <fwp_args37+0xc>  // b.any
    7290:	29430864 	ldp	w4, w2, [x3, #24]
    7294:	92403c21 	and	x1, x1, #0xffff
    7298:	9b047c21 	mul	x1, x1, x4
    729c:	d360fc21 	lsr	x1, x1, #32
    72a0:	eb02003f 	cmp	x1, x2
    72a4:	54fffcc2 	b.cs	723c <fwp_args37+0xc>  // b.hs, b.nlast
    72a8:	8b010000 	add	x0, x0, x1
    72ac:	39400001 	ldrb	w1, [x0]
    72b0:	34fffc61 	cbz	w1, 723c <fwp_args37+0xc>
    72b4:	b00000c2 	adrp	x2, 20000 <__data_start>
    72b8:	91014042 	add	x2, x2, #0x50
    72bc:	b9413043 	ldr	w3, [x2, #304]
    72c0:	350000c3 	cbnz	w3, 72d8 <fwp_args37+0xa8>
    72c4:	7103f43f 	cmp	w1, #0xfd
    72c8:	54000168 	b.hi	72f4 <fwp_args37+0xc4>  // b.pmore
    72cc:	11000421 	add	w1, w1, #0x1
    72d0:	39000001 	strb	w1, [x0]
    72d4:	d65f03c0 	ret
    72d8:	f940ac43 	ldr	x3, [x2, #344]
    72dc:	91000463 	add	x3, x3, #0x1
    72e0:	f900ac43 	str	x3, [x2, #344]
    72e4:	17fffff8 	b	72c4 <fwp_args37+0x94>
    72e8:	72003c3f 	tst	w1, #0xffff
    72ec:	54fffe00 	b.eq	72ac <fwp_args37+0x7c>  // b.none
    72f0:	d65f03c0 	ret
    72f4:	17fff580 	b	48f4 <fwp_rc_wide_dup>
    72f8:	d503201f 	nop
    72fc:	d503201f 	nop

0000000000007300 <fwp_caps37>:
    7300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7304:	910003fd 	mov	x29, sp
    7308:	f9000bf3 	str	x19, [sp, #16]
    730c:	aa0003f3 	mov	x19, x0
    7310:	b9400400 	ldr	w0, [x0, #4]
    7314:	340004a0 	cbz	w0, 73a8 <fwp_caps37+0xa8>
    7318:	f9400660 	ldr	x0, [x19, #8]
    731c:	350004e1 	cbnz	w1, 73b8 <fwp_caps37+0xb8>
    7320:	97fffc84 	bl	6530 <fwp_drop4>
    7324:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    7328:	9118c042 	add	x2, x2, #0x630
    732c:	f949d840 	ldr	x0, [x2, #5040]
    7330:	f949ec41 	ldr	x1, [x2, #5080]
    7334:	cb000260 	sub	x0, x19, x0
    7338:	eb01401f 	cmp	x0, x1, lsl #16
    733c:	54000382 	b.cs	73ac <fwp_caps37+0xac>  // b.hs, b.nlast
    7340:	d350fc01 	lsr	x1, x0, #16
    7344:	f949fc44 	ldr	x4, [x2, #5112]
    7348:	8b010821 	add	x1, x1, x1, lsl #2
    734c:	d37df021 	lsl	x1, x1, #3
    7350:	8b010083 	add	x3, x4, x1
    7354:	f9401062 	ldr	x2, [x3, #32]
    7358:	b40002a2 	cbz	x2, 73ac <fwp_caps37+0xac>
    735c:	38616881 	ldrb	w1, [x4, x1]
    7360:	7100083f 	cmp	w1, #0x2
    7364:	54000740 	b.eq	744c <fwp_caps37+0x14c>  // b.none
    7368:	7100043f 	cmp	w1, #0x1
    736c:	54000201 	b.ne	73ac <fwp_caps37+0xac>  // b.any
    7370:	29430464 	ldp	w4, w1, [x3, #24]
    7374:	92403c00 	and	x0, x0, #0xffff
    7378:	9b047c00 	mul	x0, x0, x4
    737c:	d360fc00 	lsr	x0, x0, #32
    7380:	eb01001f 	cmp	x0, x1
    7384:	54000142 	b.cs	73ac <fwp_caps37+0xac>  // b.hs, b.nlast
    7388:	8b000042 	add	x2, x2, x0
    738c:	39400040 	ldrb	w0, [x2]
    7390:	7100041f 	cmp	w0, #0x1
    7394:	540000c1 	b.ne	73ac <fwp_caps37+0xac>  // b.any
    7398:	aa1303e0 	mov	x0, x19
    739c:	f9400bf3 	ldr	x19, [sp, #16]
    73a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    73a4:	17fff63b 	b	4c90 <fwp_mem_free>
    73a8:	34fffbe1 	cbz	w1, 7324 <fwp_caps37+0x24>
    73ac:	f9400bf3 	ldr	x19, [sp, #16]
    73b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    73b4:	d65f03c0 	ret
    73b8:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    73bc:	9118c042 	add	x2, x2, #0x630
    73c0:	f949d843 	ldr	x3, [x2, #5040]
    73c4:	f949ec41 	ldr	x1, [x2, #5080]
    73c8:	cb030000 	sub	x0, x0, x3
    73cc:	eb01401f 	cmp	x0, x1, lsl #16
    73d0:	54fffee2 	b.cs	73ac <fwp_caps37+0xac>  // b.hs, b.nlast
    73d4:	d350fc01 	lsr	x1, x0, #16
    73d8:	f949fc44 	ldr	x4, [x2, #5112]
    73dc:	8b010821 	add	x1, x1, x1, lsl #2
    73e0:	d37df021 	lsl	x1, x1, #3
    73e4:	8b010083 	add	x3, x4, x1
    73e8:	f9401062 	ldr	x2, [x3, #32]
    73ec:	b4fffe02 	cbz	x2, 73ac <fwp_caps37+0xac>
    73f0:	38616881 	ldrb	w1, [x4, x1]
    73f4:	7100083f 	cmp	w1, #0x2
    73f8:	54000300 	b.eq	7458 <fwp_caps37+0x158>  // b.none
    73fc:	7100043f 	cmp	w1, #0x1
    7400:	54fffd61 	b.ne	73ac <fwp_caps37+0xac>  // b.any
    7404:	92403c01 	and	x1, x0, #0xffff
    7408:	29430064 	ldp	w4, w0, [x3, #24]
    740c:	9b047c21 	mul	x1, x1, x4
    7410:	d360fc21 	lsr	x1, x1, #32
    7414:	eb00003f 	cmp	x1, x0
    7418:	54fffca2 	b.cs	73ac <fwp_caps37+0xac>  // b.hs, b.nlast
    741c:	8b010042 	add	x2, x2, x1
    7420:	39400040 	ldrb	w0, [x2]
    7424:	34fffc40 	cbz	w0, 73ac <fwp_caps37+0xac>
    7428:	b00000c1 	adrp	x1, 20000 <__data_start>
    742c:	91014021 	add	x1, x1, #0x50
    7430:	b9413023 	ldr	w3, [x1, #304]
    7434:	35000183 	cbnz	w3, 7464 <fwp_caps37+0x164>
    7438:	7103f41f 	cmp	w0, #0xfd
    743c:	540001c8 	b.hi	7474 <fwp_caps37+0x174>  // b.pmore
    7440:	11000400 	add	w0, w0, #0x1
    7444:	39000040 	strb	w0, [x2]
    7448:	17ffffd9 	b	73ac <fwp_caps37+0xac>
    744c:	72003c1f 	tst	w0, #0xffff
    7450:	54fffae1 	b.ne	73ac <fwp_caps37+0xac>  // b.any
    7454:	17ffffce 	b	738c <fwp_caps37+0x8c>
    7458:	72003c1f 	tst	w0, #0xffff
    745c:	54fffa81 	b.ne	73ac <fwp_caps37+0xac>  // b.any
    7460:	17fffff0 	b	7420 <fwp_caps37+0x120>
    7464:	f940ac23 	ldr	x3, [x1, #344]
    7468:	91000463 	add	x3, x3, #0x1
    746c:	f900ac23 	str	x3, [x1, #344]
    7470:	17fffff2 	b	7438 <fwp_caps37+0x138>
    7474:	f9400bf3 	ldr	x19, [sp, #16]
    7478:	aa0203e0 	mov	x0, x2
    747c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7480:	17fff51d 	b	48f4 <fwp_rc_wide_dup>

0000000000007484 <fwp_write>:
    7484:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7488:	910003fd 	mov	x29, sp
    748c:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    7490:	f947f484 	ldr	x4, [x4, #4072]
    7494:	a90153f3 	stp	x19, x20, [sp, #16]
    7498:	d10943ff 	sub	sp, sp, #0x250
    749c:	b9400045 	ldr	w5, [x2]
    74a0:	aa0003f4 	mov	x20, x0
    74a4:	f9400080 	ldr	x0, [x4]
    74a8:	f90127e0 	str	x0, [sp, #584]
    74ac:	d2800000 	mov	x0, #0x0                   	// #0
    74b0:	710064bf 	cmp	w5, #0x19
    74b4:	54000408 	b.hi	7534 <fwp_write+0xb0>  // b.pmore
    74b8:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    74bc:	aa0103f3 	mov	x19, x1
    74c0:	913b8000 	add	x0, x0, #0xee0
    74c4:	f9013bf5 	str	x21, [sp, #624]
    74c8:	f9013ff6 	str	x22, [sp, #632]
    74cc:	f90153fb 	str	x27, [sp, #672]
    74d0:	f90157fc 	str	x28, [sp, #680]
    74d4:	aa0203fc 	mov	x28, x2
    74d8:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    74dc:	10000061 	adr	x1, 74e8 <fwp_write+0x64>
    74e0:	8b20a820 	add	x0, x1, w0, sxth #2
    74e4:	d61f0000 	br	x0
    74e8:	910123e0 	add	x0, sp, #0x48
    74ec:	aa1303e5 	mov	x5, x19
    74f0:	90000024 	adrp	x4, b000 <_IO_stdin_used+0x70>
    74f4:	aa0003f3 	mov	x19, x0
    74f8:	91176084 	add	x4, x4, #0x5d8
    74fc:	d2804003 	mov	x3, #0x200                 	// #512
    7500:	aa0303e1 	mov	x1, x3
    7504:	52800042 	mov	w2, #0x2                   	// #2
    7508:	97ffecc2 	bl	2810 <__snprintf_chk@plt>
    750c:	aa1303e0 	mov	x0, x19
    7510:	97ffec88 	bl	2730 <strlen@plt>
    7514:	aa1303e1 	mov	x1, x19
    7518:	aa0003e2 	mov	x2, x0
    751c:	aa1403e0 	mov	x0, x20
    7520:	97fff05c 	bl	3690 <buf_put>
    7524:	f9413bf5 	ldr	x21, [sp, #624]
    7528:	f9413ff6 	ldr	x22, [sp, #632]
    752c:	f94153fb 	ldr	x27, [sp, #672]
    7530:	f94157fc 	ldr	x28, [sp, #680]
    7534:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7538:	f947f400 	ldr	x0, [x0, #4072]
    753c:	f94127e2 	ldr	x2, [sp, #584]
    7540:	f9400001 	ldr	x1, [x0]
    7544:	eb010042 	subs	x2, x2, x1
    7548:	d2800001 	mov	x1, #0x0                   	// #0
    754c:	540077a1 	b.ne	8440 <fwp_write+0xfbc>  // b.any
    7550:	910943ff 	add	sp, sp, #0x250
    7554:	a94153f3 	ldp	x19, x20, [sp, #16]
    7558:	a8c77bfd 	ldp	x29, x30, [sp], #112
    755c:	d65f03c0 	ret
    7560:	910123e0 	add	x0, sp, #0x48
    7564:	aa1303e5 	mov	x5, x19
    7568:	90000024 	adrp	x4, b000 <_IO_stdin_used+0x70>
    756c:	aa0003f3 	mov	x19, x0
    7570:	91174084 	add	x4, x4, #0x5d0
    7574:	d2804003 	mov	x3, #0x200                 	// #512
    7578:	17ffffe2 	b	7500 <fwp_write+0x7c>
    757c:	71004cbf 	cmp	w5, #0x13
    7580:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x70>
    7584:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    7588:	91170000 	add	x0, x0, #0x5c0
    758c:	91172021 	add	x1, x1, #0x5c8
    7590:	d2800082 	mov	x2, #0x4                   	// #4
    7594:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7598:	aa1403e0 	mov	x0, x20
    759c:	f90143f7 	str	x23, [sp, #640]
    75a0:	d2800016 	mov	x22, #0x0                   	// #0
    75a4:	f90147f8 	str	x24, [sp, #648]
    75a8:	97fff03a 	bl	3690 <buf_put>
    75ac:	f9400260 	ldr	x0, [x19]
    75b0:	90000037 	adrp	x23, b000 <_IO_stdin_used+0x70>
    75b4:	d2800015 	mov	x21, #0x0                   	// #0
    75b8:	911922f7 	add	x23, x23, #0x648
    75bc:	b4004780 	cbz	x0, 7eac <fwp_write+0xa28>
    75c0:	b9400380 	ldr	w0, [x28]
    75c4:	52800003 	mov	w3, #0x0                   	// #0
    75c8:	f9401f82 	ldr	x2, [x28, #56]
    75cc:	71004c1f 	cmp	w0, #0x13
    75d0:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    75d4:	aa1403e0 	mov	x0, x20
    75d8:	8b010e61 	add	x1, x19, x1, lsl #3
    75dc:	f9400421 	ldr	x1, [x1, #8]
    75e0:	97ffffa9 	bl	7484 <fwp_write>
    75e4:	b9400380 	ldr	w0, [x28]
    75e8:	7100481f 	cmp	w0, #0x12
    75ec:	54004b20 	b.eq	7f50 <fwp_write+0xacc>  // b.none
    75f0:	f9400260 	ldr	x0, [x19]
    75f4:	910006b5 	add	x21, x21, #0x1
    75f8:	91000ad6 	add	x22, x22, #0x2
    75fc:	eb15001f 	cmp	x0, x21
    7600:	54004569 	b.ls	7eac <fwp_write+0xa28>  // b.plast
    7604:	aa1703e1 	mov	x1, x23
    7608:	aa1403e0 	mov	x0, x20
    760c:	d2800042 	mov	x2, #0x2                   	// #2
    7610:	97fff020 	bl	3690 <buf_put>
    7614:	17ffffeb 	b	75c0 <fwp_write+0x13c>
    7618:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    761c:	91180021 	add	x1, x1, #0x600
    7620:	d28000c2 	mov	x2, #0x6                   	// #6
    7624:	aa1403e0 	mov	x0, x20
    7628:	91004273 	add	x19, x19, #0x10
    762c:	97fff019 	bl	3690 <buf_put>
    7630:	aa1303e0 	mov	x0, x19
    7634:	97ffec3f 	bl	2730 <strlen@plt>
    7638:	aa1303e1 	mov	x1, x19
    763c:	aa0003e2 	mov	x2, x0
    7640:	aa1403e0 	mov	x0, x20
    7644:	97fff013 	bl	3690 <buf_put>
    7648:	528007c3 	mov	w3, #0x3e                  	// #62
    764c:	aa1403e0 	mov	x0, x20
    7650:	91001fe1 	add	x1, sp, #0x7
    7654:	d2800022 	mov	x2, #0x1                   	// #1
    7658:	39001fe3 	strb	w3, [sp, #7]
    765c:	17ffffb1 	b	7520 <fwp_write+0x9c>
    7660:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7664:	f947f400 	ldr	x0, [x0, #4072]
    7668:	f94127e2 	ldr	x2, [sp, #584]
    766c:	f9400001 	ldr	x1, [x0]
    7670:	eb010042 	subs	x2, x2, x1
    7674:	d2800001 	mov	x1, #0x0                   	// #0
    7678:	540034c1 	b.ne	7d10 <fwp_write+0x88c>  // b.any
    767c:	f9413bf5 	ldr	x21, [sp, #624]
    7680:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    7684:	f9413ff6 	ldr	x22, [sp, #632]
    7688:	aa1403e0 	mov	x0, x20
    768c:	91178021 	add	x1, x1, #0x5e0
    7690:	d2800142 	mov	x2, #0xa                   	// #10
    7694:	f94153fb 	ldr	x27, [sp, #672]
    7698:	f94157fc 	ldr	x28, [sp, #680]
    769c:	910943ff 	add	sp, sp, #0x250
    76a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    76a4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    76a8:	17ffeffa 	b	3690 <buf_put>
    76ac:	f9400456 	ldr	x22, [x2, #8]
    76b0:	f90143f7 	str	x23, [sp, #640]
    76b4:	f90147f8 	str	x24, [sp, #648]
    76b8:	b4005af6 	cbz	x22, 8214 <fwp_write+0xd90>
    76bc:	aa1603e0 	mov	x0, x22
    76c0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    76c4:	91198021 	add	x1, x1, #0x660
    76c8:	97ffec96 	bl	2920 <strcmp@plt>
    76cc:	2a0003f5 	mov	w21, w0
    76d0:	34005fc0 	cbz	w0, 82c8 <fwp_write+0xe44>
    76d4:	aa1603e0 	mov	x0, x22
    76d8:	97ffec16 	bl	2730 <strlen@plt>
    76dc:	aa1603e1 	mov	x1, x22
    76e0:	aa0003e2 	mov	x2, x0
    76e4:	aa1403e0 	mov	x0, x20
    76e8:	97ffefea 	bl	3690 <buf_put>
    76ec:	52800403 	mov	w3, #0x20                  	// #32
    76f0:	91001ff5 	add	x21, sp, #0x7
    76f4:	aa1503e1 	mov	x1, x21
    76f8:	aa1403e0 	mov	x0, x20
    76fc:	d2800022 	mov	x2, #0x1                   	// #1
    7700:	39001fe3 	strb	w3, [sp, #7]
    7704:	97ffefe3 	bl	3690 <buf_put>
    7708:	52800f63 	mov	w3, #0x7b                  	// #123
    770c:	aa1403e0 	mov	x0, x20
    7710:	aa1503e1 	mov	x1, x21
    7714:	d2800022 	mov	x2, #0x1                   	// #1
    7718:	39001fe3 	strb	w3, [sp, #7]
    771c:	97ffefdd 	bl	3690 <buf_put>
    7720:	b9401380 	ldr	w0, [x28, #16]
    7724:	52800018 	mov	w24, #0x0                   	// #0
    7728:	7100001f 	cmp	w0, #0x0
    772c:	54003a8d 	b.le	7e7c <fwp_write+0x9f8>
    7730:	f9014bf9 	str	x25, [sp, #656]
    7734:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x70>
    7738:	911a2339 	add	x25, x25, #0x688
    773c:	f9014ffa 	str	x26, [sp, #664]
    7740:	9000003a 	adrp	x26, b000 <_IO_stdin_used+0x70>
    7744:	9119235a 	add	x26, x26, #0x648
    7748:	91002276 	add	x22, x19, #0x8
    774c:	d2800013 	mov	x19, #0x0                   	// #0
    7750:	b5003e73 	cbnz	x19, 7f1c <fwp_write+0xa98>
    7754:	d37df277 	lsl	x23, x19, #3
    7758:	34003c98 	cbz	w24, 7ee8 <fwp_write+0xa64>
    775c:	f9401382 	ldr	x2, [x28, #32]
    7760:	aa1403e0 	mov	x0, x20
    7764:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7768:	52800003 	mov	w3, #0x0                   	// #0
    776c:	f8776842 	ldr	x2, [x2, x23]
    7770:	91000673 	add	x19, x19, #0x1
    7774:	97ffff44 	bl	7484 <fwp_write>
    7778:	b9401380 	ldr	w0, [x28, #16]
    777c:	6b13001f 	cmp	w0, w19
    7780:	54fffe8c 	b.gt	7750 <fwp_write+0x2cc>
    7784:	f9414bf9 	ldr	x25, [sp, #656]
    7788:	f9414ffa 	ldr	x26, [sp, #664]
    778c:	34003798 	cbz	w24, 7e7c <fwp_write+0x9f8>
    7790:	52800523 	mov	w3, #0x29                  	// #41
    7794:	aa1503e1 	mov	x1, x21
    7798:	aa1403e0 	mov	x0, x20
    779c:	d2800022 	mov	x2, #0x1                   	// #1
    77a0:	39001fe3 	strb	w3, [sp, #7]
    77a4:	97ffefbb 	bl	3690 <buf_put>
    77a8:	f9413bf5 	ldr	x21, [sp, #624]
    77ac:	f9413ff6 	ldr	x22, [sp, #632]
    77b0:	f94143f7 	ldr	x23, [sp, #640]
    77b4:	f94147f8 	ldr	x24, [sp, #648]
    77b8:	f94153fb 	ldr	x27, [sp, #672]
    77bc:	f94157fc 	ldr	x28, [sp, #680]
    77c0:	17ffff5d 	b	7534 <fwp_write+0xb0>
    77c4:	b9404855 	ldr	w21, [x2, #72]
    77c8:	aa1403e0 	mov	x0, x20
    77cc:	93407eb6 	sxtw	x22, w21
    77d0:	91000ac1 	add	x1, x22, #0x2
    77d4:	97ffef7b 	bl	35c0 <buf_grow>
    77d8:	a9400281 	ldp	x1, x0, [x20]
    77dc:	528e8603 	mov	w3, #0x7430                	// #29744
    77e0:	78206823 	strh	w3, [x1, x0]
    77e4:	8b000022 	add	x2, x1, x0
    77e8:	710002bf 	cmp	w21, #0x0
    77ec:	540036ad 	b.le	7ec0 <fwp_write+0xa3c>
    77f0:	110006a3 	add	w3, w21, #0x1
    77f4:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    77f8:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    77fc:	91000449 	add	x9, x2, #0x1
    7800:	8b23c043 	add	x3, x2, w3, sxtw
    7804:	f28aaac6 	movk	x6, #0x5556
    7808:	f2955568 	movk	x8, #0xaaab
    780c:	1400000d 	b	7840 <fwp_write+0x3bc>
    7810:	d2800021 	mov	x1, #0x1                   	// #1
    7814:	528005a5 	mov	w5, #0x2d                  	// #45
    7818:	f100001f 	cmp	x0, #0x0
    781c:	9b467e60 	smulh	x0, x19, x6
    7820:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7824:	381ff465 	strb	w5, [x3], #-1
    7828:	cb040000 	sub	x0, x0, x4
    782c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7830:	cb020000 	sub	x0, x0, x2
    7834:	8b010013 	add	x19, x0, x1
    7838:	eb03013f 	cmp	x9, x3
    783c:	54003420 	b.eq	7ec0 <fwp_write+0xa3c>  // b.none
    7840:	9b467e60 	smulh	x0, x19, x6
    7844:	937ffe64 	asr	x4, x19, #63
    7848:	52800605 	mov	w5, #0x30                  	// #48
    784c:	cb040000 	sub	x0, x0, x4
    7850:	8b000400 	add	x0, x0, x0, lsl #1
    7854:	cb000260 	sub	x0, x19, x0
    7858:	91000c01 	add	x1, x0, #0x3
    785c:	9bc87c22 	umulh	x2, x1, x8
    7860:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7864:	8b4204e2 	add	x2, x7, x2, lsr #1
    7868:	eb020021 	subs	x1, x1, x2
    786c:	54fffd60 	b.eq	7818 <fwp_write+0x394>  // b.none
    7870:	f100043f 	cmp	x1, #0x1
    7874:	54fffce1 	b.ne	7810 <fwp_write+0x38c>  // b.any
    7878:	d2800001 	mov	x1, #0x0                   	// #0
    787c:	52800565 	mov	w5, #0x2b                  	// #43
    7880:	17ffffe6 	b	7818 <fwp_write+0x394>
    7884:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7888:	f947f400 	ldr	x0, [x0, #4072]
    788c:	f94127e2 	ldr	x2, [sp, #584]
    7890:	f9400001 	ldr	x1, [x0]
    7894:	eb010042 	subs	x2, x2, x1
    7898:	d2800001 	mov	x1, #0x0                   	// #0
    789c:	540023a1 	b.ne	7d10 <fwp_write+0x88c>  // b.any
    78a0:	f9413bf5 	ldr	x21, [sp, #624]
    78a4:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    78a8:	f9413ff6 	ldr	x22, [sp, #632]
    78ac:	aa1403e0 	mov	x0, x20
    78b0:	9117c021 	add	x1, x1, #0x5f0
    78b4:	d2800102 	mov	x2, #0x8                   	// #8
    78b8:	17ffff77 	b	7694 <fwp_write+0x210>
    78bc:	aa1403e0 	mov	x0, x20
    78c0:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    78c4:	d28000c2 	mov	x2, #0x6                   	// #6
    78c8:	91194021 	add	x1, x1, #0x650
    78cc:	97ffef71 	bl	3690 <buf_put>
    78d0:	d2800015 	mov	x21, #0x0                   	// #0
    78d4:	f9400263 	ldr	x3, [x19]
    78d8:	f240f87f 	tst	x3, #0x7fffffffffffffff
    78dc:	54002c40 	b.eq	7e64 <fwp_write+0x9e0>  // b.none
    78e0:	f9401f82 	ldr	x2, [x28, #56]
    78e4:	f90143f7 	str	x23, [sp, #640]
    78e8:	f90147f8 	str	x24, [sp, #648]
    78ec:	d2800857 	mov	x23, #0x42                  	// #66
    78f0:	f9014bf9 	str	x25, [sp, #656]
    78f4:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x70>
    78f8:	f9014ffa 	str	x26, [sp, #664]
    78fc:	911922d6 	add	x22, x22, #0x648
    7900:	d2800038 	mov	x24, #0x1                   	// #1
    7904:	f2a18017 	movk	x23, #0xc00, lsl #16
    7908:	d2809099 	mov	x25, #0x484                 	// #1156
    790c:	b4000482 	cbz	x2, 799c <fwp_write+0x518>
    7910:	b9400040 	ldr	w0, [x2]
    7914:	7100701f 	cmp	w0, #0x1c
    7918:	540042a0 	b.eq	816c <fwp_write+0xce8>  // b.none
    791c:	71006c1f 	cmp	w0, #0x1b
    7920:	540003e8 	b.hi	799c <fwp_write+0x518>  // b.pmore
    7924:	9ac02301 	lsl	x1, x24, x0
    7928:	ea17003f 	tst	x1, x23
    792c:	54003681 	b.ne	7ffc <fwp_write+0xb78>  // b.any
    7930:	ea19003f 	tst	x1, x25
    7934:	54003501 	b.ne	7fd4 <fwp_write+0xb50>  // b.any
    7938:	d2800424 	mov	x4, #0x21                  	// #33
    793c:	ea04003f 	tst	x1, x4
    7940:	540002e0 	b.eq	799c <fwp_write+0x518>  // b.none
    7944:	b7f849a3 	tbnz	x3, #63, 8278 <fwp_write+0xdf4>
    7948:	91002261 	add	x1, x19, #0x8
    794c:	8b150021 	add	x1, x1, x21
    7950:	39400021 	ldrb	w1, [x1]
    7954:	7100001f 	cmp	w0, #0x0
    7958:	93401c23 	sxtb	x3, w1
    795c:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7960:	aa1403e0 	mov	x0, x20
    7964:	52800003 	mov	w3, #0x0                   	// #0
    7968:	97fffec7 	bl	7484 <fwp_write>
    796c:	910006b5 	add	x21, x21, #0x1
    7970:	f9400260 	ldr	x0, [x19]
    7974:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7978:	eb0002bf 	cmp	x21, x0
    797c:	540026c2 	b.cs	7e54 <fwp_write+0x9d0>  // b.hs, b.nlast
    7980:	d2800042 	mov	x2, #0x2                   	// #2
    7984:	aa1603e1 	mov	x1, x22
    7988:	aa1403e0 	mov	x0, x20
    798c:	97ffef41 	bl	3690 <buf_put>
    7990:	f9401f82 	ldr	x2, [x28, #56]
    7994:	f9400263 	ldr	x3, [x19]
    7998:	b5fffbc2 	cbnz	x2, 7910 <fwp_write+0x48c>
    799c:	d37df2a0 	lsl	x0, x21, #3
    79a0:	b7f83f03 	tbnz	x3, #63, 8180 <fwp_write+0xcfc>
    79a4:	91002261 	add	x1, x19, #0x8
    79a8:	8b000020 	add	x0, x1, x0
    79ac:	f9400001 	ldr	x1, [x0]
    79b0:	17ffffec 	b	7960 <fwp_write+0x4dc>
    79b4:	a9400e62 	ldp	x2, x3, [x19]
    79b8:	b7f83ca3 	tbnz	x3, #63, 814c <fwp_write+0xcc8>
    79bc:	910123f5 	add	x21, sp, #0x48
    79c0:	aa1503e0 	mov	x0, x21
    79c4:	97ffed17 	bl	2e20 <fwp_fmt_u128>
    79c8:	aa1503e0 	mov	x0, x21
    79cc:	97ffeb59 	bl	2730 <strlen@plt>
    79d0:	aa1503e1 	mov	x1, x21
    79d4:	aa0003e2 	mov	x2, x0
    79d8:	17fffed1 	b	751c <fwp_write+0x98>
    79dc:	fd015be8 	str	d8, [sp, #688]
    79e0:	1e270268 	fmov	s8, w19
    79e4:	fd015fe9 	str	d9, [sp, #696]
    79e8:	1e282100 	fcmp	s8, s8
    79ec:	54004d26 	b.vs	8390 <fwp_write+0xf0c>
    79f0:	1e20c101 	fabs	s1, s8
    79f4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    79f8:	1e270000 	fmov	s0, w0
    79fc:	1e202020 	fcmp	s1, s0
    7a00:	54002c0d 	b.le	7f80 <fwp_write+0xafc>
    7a04:	1e202118 	fcmpe	s8, #0.0
    7a08:	90000022 	adrp	x2, b000 <_IO_stdin_used+0x70>
    7a0c:	91042042 	add	x2, x2, #0x108
    7a10:	910123f5 	add	x21, sp, #0x48
    7a14:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    7a18:	91168021 	add	x1, x1, #0x5a0
    7a1c:	aa1503e0 	mov	x0, x21
    7a20:	9a81c041 	csel	x1, x2, x1, gt
    7a24:	97ffebef 	bl	29e0 <strcpy@plt>
    7a28:	aa1503e0 	mov	x0, x21
    7a2c:	97ffeb41 	bl	2730 <strlen@plt>
    7a30:	aa1503e1 	mov	x1, x21
    7a34:	aa0003e2 	mov	x2, x0
    7a38:	aa1403e0 	mov	x0, x20
    7a3c:	97ffef15 	bl	3690 <buf_put>
    7a40:	f9413bf5 	ldr	x21, [sp, #624]
    7a44:	f9413ff6 	ldr	x22, [sp, #632]
    7a48:	f94153fb 	ldr	x27, [sp, #672]
    7a4c:	f94157fc 	ldr	x28, [sp, #680]
    7a50:	fd415be8 	ldr	d8, [sp, #688]
    7a54:	fd415fe9 	ldr	d9, [sp, #696]
    7a58:	17fffeb7 	b	7534 <fwp_write+0xb0>
    7a5c:	f9400276 	ldr	x22, [x19]
    7a60:	34002e03 	cbz	w3, 8020 <fwp_write+0xb9c>
    7a64:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7a68:	f947f400 	ldr	x0, [x0, #4072]
    7a6c:	f94127e2 	ldr	x2, [sp, #584]
    7a70:	f9400001 	ldr	x1, [x0]
    7a74:	eb010042 	subs	x2, x2, x1
    7a78:	d2800001 	mov	x1, #0x0                   	// #0
    7a7c:	540014a1 	b.ne	7d10 <fwp_write+0x88c>  // b.any
    7a80:	aa1603e2 	mov	x2, x22
    7a84:	91002261 	add	x1, x19, #0x8
    7a88:	f9413bf5 	ldr	x21, [sp, #624]
    7a8c:	aa1403e0 	mov	x0, x20
    7a90:	f9413ff6 	ldr	x22, [sp, #632]
    7a94:	17ffff00 	b	7694 <fwp_write+0x210>
    7a98:	fd015be8 	str	d8, [sp, #688]
    7a9c:	9e670268 	fmov	d8, x19
    7aa0:	fd015fe9 	str	d9, [sp, #696]
    7aa4:	1e682100 	fcmp	d8, d8
    7aa8:	54004746 	b.vs	8390 <fwp_write+0xf0c>
    7aac:	1e60c101 	fabs	d1, d8
    7ab0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7ab4:	9e670000 	fmov	d0, x0
    7ab8:	910123f5 	add	x21, sp, #0x48
    7abc:	52800033 	mov	w19, #0x1                   	// #1
    7ac0:	1e602020 	fcmp	d1, d0
    7ac4:	540001ad 	b.le	7af8 <fwp_write+0x674>
    7ac8:	1e602118 	fcmpe	d8, #0.0
    7acc:	90000022 	adrp	x2, b000 <_IO_stdin_used+0x70>
    7ad0:	91042042 	add	x2, x2, #0x108
    7ad4:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    7ad8:	91168021 	add	x1, x1, #0x5a0
    7adc:	aa1503e0 	mov	x0, x21
    7ae0:	9a81c041 	csel	x1, x2, x1, gt
    7ae4:	97ffebbf 	bl	29e0 <strcpy@plt>
    7ae8:	17ffffd0 	b	7a28 <fwp_write+0x5a4>
    7aec:	11000673 	add	w19, w19, #0x1
    7af0:	71004a7f 	cmp	w19, #0x12
    7af4:	54003860 	b.eq	8200 <fwp_write+0xd7c>  // b.none
    7af8:	1e604100 	fmov	d0, d8
    7afc:	2a1303e1 	mov	w1, w19
    7b00:	aa1503e0 	mov	x0, x21
    7b04:	97fff024 	bl	3b94 <fwp_format_g.constprop.0>
    7b08:	aa1503e0 	mov	x0, x21
    7b0c:	d2800001 	mov	x1, #0x0                   	// #0
    7b10:	97ffeb1c 	bl	2780 <strtod@plt>
    7b14:	1e602100 	fcmp	d8, d0
    7b18:	54fffea1 	b.ne	7aec <fwp_write+0x668>  // b.any
    7b1c:	aa1503e0 	mov	x0, x21
    7b20:	97ffef15 	bl	3774 <fwp_finish_float>
    7b24:	17ffffc1 	b	7a28 <fwp_write+0x5a4>
    7b28:	a9400e62 	ldp	x2, x3, [x19]
    7b2c:	910123f3 	add	x19, sp, #0x48
    7b30:	aa1303e0 	mov	x0, x19
    7b34:	97ffecbb 	bl	2e20 <fwp_fmt_u128>
    7b38:	17fffe75 	b	750c <fwp_write+0x88>
    7b3c:	f90143f7 	str	x23, [sp, #640]
    7b40:	f90147f8 	str	x24, [sp, #648]
    7b44:	2a1303f8 	mov	w24, w19
    7b48:	f9014bf9 	str	x25, [sp, #656]
    7b4c:	f9014ffa 	str	x26, [sp, #664]
    7b50:	f13ffe7f 	cmp	x19, #0xfff
    7b54:	54000049 	b.ls	7b5c <fwp_write+0x6d8>  // b.plast
    7b58:	b9400278 	ldr	w24, [x19]
    7b5c:	f9400f80 	ldr	x0, [x28, #24]
    7b60:	2a1803f5 	mov	w21, w24
    7b64:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7b68:	d37ef6b9 	lsl	x25, x21, #2
    7b6c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7b70:	aa1603e0 	mov	x0, x22
    7b74:	97ffeaef 	bl	2730 <strlen@plt>
    7b78:	aa1603e1 	mov	x1, x22
    7b7c:	aa0003e2 	mov	x2, x0
    7b80:	aa1403e0 	mov	x0, x20
    7b84:	97ffeec3 	bl	3690 <buf_put>
    7b88:	f9401780 	ldr	x0, [x28, #40]
    7b8c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7b90:	7100001f 	cmp	w0, #0x0
    7b94:	5400068d 	b.le	7c64 <fwp_write+0x7e0>
    7b98:	91002276 	add	x22, x19, #0x8
    7b9c:	91001ff5 	add	x21, sp, #0x7
    7ba0:	d280001b 	mov	x27, #0x0                   	// #0
    7ba4:	5280041a 	mov	w26, #0x20                  	// #32
    7ba8:	f9401b80 	ldr	x0, [x28, #48]
    7bac:	aa1503e1 	mov	x1, x21
    7bb0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7bb4:	d2800022 	mov	x2, #0x1                   	// #1
    7bb8:	f8786803 	ldr	x3, [x0, x24]
    7bbc:	aa1403e0 	mov	x0, x20
    7bc0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7bc4:	39001ffa 	strb	w26, [sp, #7]
    7bc8:	97ffeeb2 	bl	3690 <buf_put>
    7bcc:	f13ffeff 	cmp	x23, #0xfff
    7bd0:	b9400261 	ldr	w1, [x19]
    7bd4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7bd8:	7100383f 	cmp	w1, #0xe
    7bdc:	54000160 	b.eq	7c08 <fwp_write+0x784>  // b.none
    7be0:	7100403f 	cmp	w1, #0x10
    7be4:	54001a60 	b.eq	7f30 <fwp_write+0xaac>  // b.none
    7be8:	7100283f 	cmp	w1, #0xa
    7bec:	54002aa0 	b.eq	8140 <fwp_write+0xcbc>  // b.none
    7bf0:	540014ac 	b.gt	7e84 <fwp_write+0xa00>
    7bf4:	71000c3f 	cmp	w1, #0x3
    7bf8:	540029ac 	b.gt	812c <fwp_write+0xca8>
    7bfc:	d37ffee0 	lsr	x0, x23, #63
    7c00:	37f814a1 	tbnz	w1, #31, 7e94 <fwp_write+0xa10>
    7c04:	d503201f 	nop
    7c08:	34001460 	cbz	w0, 7e94 <fwp_write+0xa10>
    7c0c:	52800503 	mov	w3, #0x28                  	// #40
    7c10:	aa1503e1 	mov	x1, x21
    7c14:	aa1403e0 	mov	x0, x20
    7c18:	d2800022 	mov	x2, #0x1                   	// #1
    7c1c:	39001fe3 	strb	w3, [sp, #7]
    7c20:	97ffee9c 	bl	3690 <buf_put>
    7c24:	aa1303e2 	mov	x2, x19
    7c28:	aa1703e1 	mov	x1, x23
    7c2c:	aa1403e0 	mov	x0, x20
    7c30:	52800003 	mov	w3, #0x0                   	// #0
    7c34:	97fffe14 	bl	7484 <fwp_write>
    7c38:	52800523 	mov	w3, #0x29                  	// #41
    7c3c:	aa1503e1 	mov	x1, x21
    7c40:	aa1403e0 	mov	x0, x20
    7c44:	d2800022 	mov	x2, #0x1                   	// #1
    7c48:	39001fe3 	strb	w3, [sp, #7]
    7c4c:	97ffee91 	bl	3690 <buf_put>
    7c50:	f9401780 	ldr	x0, [x28, #40]
    7c54:	9100077b 	add	x27, x27, #0x1
    7c58:	b8796800 	ldr	w0, [x0, x25]
    7c5c:	6b1b001f 	cmp	w0, w27
    7c60:	54fffa4c 	b.gt	7ba8 <fwp_write+0x724>
    7c64:	f9413bf5 	ldr	x21, [sp, #624]
    7c68:	f9413ff6 	ldr	x22, [sp, #632]
    7c6c:	f94143f7 	ldr	x23, [sp, #640]
    7c70:	f94147f8 	ldr	x24, [sp, #648]
    7c74:	f9414bf9 	ldr	x25, [sp, #656]
    7c78:	f9414ffa 	ldr	x26, [sp, #664]
    7c7c:	f94153fb 	ldr	x27, [sp, #672]
    7c80:	f94157fc 	ldr	x28, [sp, #680]
    7c84:	17fffe2c 	b	7534 <fwp_write+0xb0>
    7c88:	52800783 	mov	w3, #0x3c                  	// #60
    7c8c:	91001ff3 	add	x19, sp, #0x7
    7c90:	aa1303e1 	mov	x1, x19
    7c94:	d2800022 	mov	x2, #0x1                   	// #1
    7c98:	aa1403e0 	mov	x0, x20
    7c9c:	39001fe3 	strb	w3, [sp, #7]
    7ca0:	97ffee7c 	bl	3690 <buf_put>
    7ca4:	f9400795 	ldr	x21, [x28, #8]
    7ca8:	aa1503e0 	mov	x0, x21
    7cac:	97ffeaa1 	bl	2730 <strlen@plt>
    7cb0:	aa1503e1 	mov	x1, x21
    7cb4:	aa0003e2 	mov	x2, x0
    7cb8:	aa1403e0 	mov	x0, x20
    7cbc:	97ffee75 	bl	3690 <buf_put>
    7cc0:	528007c3 	mov	w3, #0x3e                  	// #62
    7cc4:	aa1303e1 	mov	x1, x19
    7cc8:	aa1403e0 	mov	x0, x20
    7ccc:	d2800022 	mov	x2, #0x1                   	// #1
    7cd0:	39001fe3 	strb	w3, [sp, #7]
    7cd4:	17fffe13 	b	7520 <fwp_write+0x9c>
    7cd8:	f100067f 	cmp	x19, #0x1
    7cdc:	540025a0 	b.eq	8190 <fwp_write+0xd0c>  // b.none
    7ce0:	b100067f 	cmn	x19, #0x1
    7ce4:	54002bc0 	b.eq	825c <fwp_write+0xdd8>  // b.none
    7ce8:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    7cec:	9116a021 	add	x1, x1, #0x5a8
    7cf0:	d2800022 	mov	x2, #0x1                   	// #1
    7cf4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7cf8:	f947f400 	ldr	x0, [x0, #4072]
    7cfc:	f94127e4 	ldr	x4, [sp, #584]
    7d00:	f9400003 	ldr	x3, [x0]
    7d04:	eb030084 	subs	x4, x4, x3
    7d08:	d2800003 	mov	x3, #0x0                   	// #0
    7d0c:	54ffebe0 	b.eq	7a88 <fwp_write+0x604>  // b.none
    7d10:	f90143f7 	str	x23, [sp, #640]
    7d14:	f90147f8 	str	x24, [sp, #648]
    7d18:	f9014bf9 	str	x25, [sp, #656]
    7d1c:	f9014ffa 	str	x26, [sp, #664]
    7d20:	fd015be8 	str	d8, [sp, #688]
    7d24:	fd015fe9 	str	d9, [sp, #696]
    7d28:	97ffeade 	bl	28a0 <__stack_chk_fail@plt>
    7d2c:	52800b63 	mov	w3, #0x5b                  	// #91
    7d30:	91001ff5 	add	x21, sp, #0x7
    7d34:	aa1503e1 	mov	x1, x21
    7d38:	aa1403e0 	mov	x0, x20
    7d3c:	d2800022 	mov	x2, #0x1                   	// #1
    7d40:	90000036 	adrp	x22, b000 <_IO_stdin_used+0x70>
    7d44:	911922d6 	add	x22, x22, #0x648
    7d48:	39001fe3 	strb	w3, [sp, #7]
    7d4c:	97ffee51 	bl	3690 <buf_put>
    7d50:	b4000273 	cbz	x19, 7d9c <fwp_write+0x918>
    7d54:	f9400661 	ldr	x1, [x19, #8]
    7d58:	aa1403e0 	mov	x0, x20
    7d5c:	f9401f82 	ldr	x2, [x28, #56]
    7d60:	52800003 	mov	w3, #0x0                   	// #0
    7d64:	97fffdc8 	bl	7484 <fwp_write>
    7d68:	f9400a73 	ldr	x19, [x19, #16]
    7d6c:	b4000193 	cbz	x19, 7d9c <fwp_write+0x918>
    7d70:	aa1603e1 	mov	x1, x22
    7d74:	aa1403e0 	mov	x0, x20
    7d78:	d2800042 	mov	x2, #0x2                   	// #2
    7d7c:	97ffee45 	bl	3690 <buf_put>
    7d80:	f9400661 	ldr	x1, [x19, #8]
    7d84:	aa1403e0 	mov	x0, x20
    7d88:	f9401f82 	ldr	x2, [x28, #56]
    7d8c:	52800003 	mov	w3, #0x0                   	// #0
    7d90:	97fffdbd 	bl	7484 <fwp_write>
    7d94:	f9400a73 	ldr	x19, [x19, #16]
    7d98:	b5fffed3 	cbnz	x19, 7d70 <fwp_write+0x8ec>
    7d9c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7da0:	aa1503e1 	mov	x1, x21
    7da4:	aa1403e0 	mov	x0, x20
    7da8:	d2800022 	mov	x2, #0x1                   	// #1
    7dac:	39001fe3 	strb	w3, [sp, #7]
    7db0:	17fffddc 	b	7520 <fwp_write+0x9c>
    7db4:	aa1403e0 	mov	x0, x20
    7db8:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    7dbc:	d28000c2 	mov	x2, #0x6                   	// #6
    7dc0:	9118e021 	add	x1, x1, #0x638
    7dc4:	97ffee33 	bl	3690 <buf_put>
    7dc8:	f9400260 	ldr	x0, [x19]
    7dcc:	b40004c0 	cbz	x0, 7e64 <fwp_write+0x9e0>
    7dd0:	910123f5 	add	x21, sp, #0x48
    7dd4:	91002276 	add	x22, x19, #0x8
    7dd8:	f90143f7 	str	x23, [sp, #640]
    7ddc:	d2800017 	mov	x23, #0x0                   	// #0
    7de0:	f90147f8 	str	x24, [sp, #648]
    7de4:	90000038 	adrp	x24, b000 <_IO_stdin_used+0x70>
    7de8:	91190318 	add	x24, x24, #0x640
    7dec:	f9014bf9 	str	x25, [sp, #656]
    7df0:	90000039 	adrp	x25, b000 <_IO_stdin_used+0x70>
    7df4:	91192339 	add	x25, x25, #0x648
    7df8:	f9014ffa 	str	x26, [sp, #664]
    7dfc:	14000005 	b	7e10 <fwp_write+0x98c>
    7e00:	aa1903e1 	mov	x1, x25
    7e04:	aa1403e0 	mov	x0, x20
    7e08:	d2800042 	mov	x2, #0x2                   	// #2
    7e0c:	97ffee21 	bl	3690 <buf_put>
    7e10:	38776ac5 	ldrb	w5, [x22, x23]
    7e14:	d2804003 	mov	x3, #0x200                 	// #512
    7e18:	aa1803e4 	mov	x4, x24
    7e1c:	aa0303e1 	mov	x1, x3
    7e20:	52800042 	mov	w2, #0x2                   	// #2
    7e24:	aa1503e0 	mov	x0, x21
    7e28:	910006f7 	add	x23, x23, #0x1
    7e2c:	97ffea79 	bl	2810 <__snprintf_chk@plt>
    7e30:	aa1503e0 	mov	x0, x21
    7e34:	97ffea3f 	bl	2730 <strlen@plt>
    7e38:	aa1503e1 	mov	x1, x21
    7e3c:	aa0003e2 	mov	x2, x0
    7e40:	aa1403e0 	mov	x0, x20
    7e44:	97ffee13 	bl	3690 <buf_put>
    7e48:	f9400260 	ldr	x0, [x19]
    7e4c:	eb17001f 	cmp	x0, x23
    7e50:	54fffd88 	b.hi	7e00 <fwp_write+0x97c>  // b.pmore
    7e54:	f94143f7 	ldr	x23, [sp, #640]
    7e58:	f94147f8 	ldr	x24, [sp, #648]
    7e5c:	f9414bf9 	ldr	x25, [sp, #656]
    7e60:	f9414ffa 	ldr	x26, [sp, #664]
    7e64:	52800ba3 	mov	w3, #0x5d                  	// #93
    7e68:	aa1403e0 	mov	x0, x20
    7e6c:	91001fe1 	add	x1, sp, #0x7
    7e70:	d2800022 	mov	x2, #0x1                   	// #1
    7e74:	39001fe3 	strb	w3, [sp, #7]
    7e78:	17fffdaa 	b	7520 <fwp_write+0x9c>
    7e7c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7e80:	17fffe45 	b	7794 <fwp_write+0x310>
    7e84:	f10002ff 	cmp	x23, #0x0
    7e88:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7e8c:	71002c3f 	cmp	w1, #0xb
    7e90:	54ffebc0 	b.eq	7c08 <fwp_write+0x784>  // b.none
    7e94:	aa1303e2 	mov	x2, x19
    7e98:	aa1703e1 	mov	x1, x23
    7e9c:	aa1403e0 	mov	x0, x20
    7ea0:	52800003 	mov	w3, #0x0                   	// #0
    7ea4:	97fffd78 	bl	7484 <fwp_write>
    7ea8:	17ffff6a 	b	7c50 <fwp_write+0x7cc>
    7eac:	aa1403e0 	mov	x0, x20
    7eb0:	91001fe1 	add	x1, sp, #0x7
    7eb4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7eb8:	d2800022 	mov	x2, #0x1                   	// #1
    7ebc:	17fffe39 	b	77a0 <fwp_write+0x31c>
    7ec0:	a9400281 	ldp	x1, x0, [x20]
    7ec4:	91000800 	add	x0, x0, #0x2
    7ec8:	8b160000 	add	x0, x0, x22
    7ecc:	f9000680 	str	x0, [x20, #8]
    7ed0:	3820683f 	strb	wzr, [x1, x0]
    7ed4:	f9413bf5 	ldr	x21, [sp, #624]
    7ed8:	f9413ff6 	ldr	x22, [sp, #632]
    7edc:	f94153fb 	ldr	x27, [sp, #672]
    7ee0:	f94157fc 	ldr	x28, [sp, #680]
    7ee4:	17fffd94 	b	7534 <fwp_write+0xb0>
    7ee8:	f9400f80 	ldr	x0, [x28, #24]
    7eec:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7ef0:	aa1b03e0 	mov	x0, x27
    7ef4:	97ffea0f 	bl	2730 <strlen@plt>
    7ef8:	aa1b03e1 	mov	x1, x27
    7efc:	aa0003e2 	mov	x2, x0
    7f00:	aa1403e0 	mov	x0, x20
    7f04:	97ffede3 	bl	3690 <buf_put>
    7f08:	aa1903e1 	mov	x1, x25
    7f0c:	aa1403e0 	mov	x0, x20
    7f10:	d2800062 	mov	x2, #0x3                   	// #3
    7f14:	97ffeddf 	bl	3690 <buf_put>
    7f18:	17fffe11 	b	775c <fwp_write+0x2d8>
    7f1c:	aa1a03e1 	mov	x1, x26
    7f20:	aa1403e0 	mov	x0, x20
    7f24:	d2800042 	mov	x2, #0x2                   	// #2
    7f28:	97ffedda 	bl	3690 <buf_put>
    7f2c:	17fffe0a 	b	7754 <fwp_write+0x2d0>
    7f30:	f9400660 	ldr	x0, [x19, #8]
    7f34:	b4fffb00 	cbz	x0, 7e94 <fwp_write+0xa10>
    7f38:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    7f3c:	91198021 	add	x1, x1, #0x660
    7f40:	97ffea78 	bl	2920 <strcmp@plt>
    7f44:	7100001f 	cmp	w0, #0x0
    7f48:	1a9f07e0 	cset	w0, ne	// ne = any
    7f4c:	17ffff2f 	b	7c08 <fwp_write+0x784>
    7f50:	aa1403e0 	mov	x0, x20
    7f54:	d2800042 	mov	x2, #0x2                   	// #2
    7f58:	90000021 	adrp	x1, b000 <_IO_stdin_used+0x70>
    7f5c:	91196021 	add	x1, x1, #0x658
    7f60:	97ffedcc 	bl	3690 <buf_put>
    7f64:	91004261 	add	x1, x19, #0x10
    7f68:	aa1403e0 	mov	x0, x20
    7f6c:	f9402382 	ldr	x2, [x28, #64]
    7f70:	52800003 	mov	w3, #0x0                   	// #0
    7f74:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7f78:	97fffd43 	bl	7484 <fwp_write>
    7f7c:	17fffd9d 	b	75f0 <fwp_write+0x16c>
    7f80:	1e22c109 	fcvt	d9, s8
    7f84:	910123f5 	add	x21, sp, #0x48
    7f88:	52800033 	mov	w19, #0x1                   	// #1
    7f8c:	d503201f 	nop
    7f90:	1e604120 	fmov	d0, d9
    7f94:	2a1303e1 	mov	w1, w19
    7f98:	aa1503e0 	mov	x0, x21
    7f9c:	97ffeefe 	bl	3b94 <fwp_format_g.constprop.0>
    7fa0:	aa1503e0 	mov	x0, x21
    7fa4:	d2800001 	mov	x1, #0x0                   	// #0
    7fa8:	97ffea6a 	bl	2950 <strtof@plt>
    7fac:	1e202100 	fcmp	s8, s0
    7fb0:	54ffdb60 	b.eq	7b1c <fwp_write+0x698>  // b.none
    7fb4:	11000673 	add	w19, w19, #0x1
    7fb8:	71002a7f 	cmp	w19, #0xa
    7fbc:	54fffea1 	b.ne	7f90 <fwp_write+0xb0c>  // b.any
    7fc0:	1e604120 	fmov	d0, d9
    7fc4:	aa1503e0 	mov	x0, x21
    7fc8:	52800121 	mov	w1, #0x9                   	// #9
    7fcc:	97ffeef2 	bl	3b94 <fwp_format_g.constprop.0>
    7fd0:	17fffed3 	b	7b1c <fwp_write+0x698>
    7fd4:	d37ef6a1 	lsl	x1, x21, #2
    7fd8:	b7f81563 	tbnz	x3, #63, 8284 <fwp_write+0xe00>
    7fdc:	91002263 	add	x3, x19, #0x8
    7fe0:	8b010061 	add	x1, x3, x1
    7fe4:	b9400023 	ldr	w3, [x1]
    7fe8:	7100081f 	cmp	w0, #0x2
    7fec:	2a0303e1 	mov	w1, w3
    7ff0:	93407c63 	sxtw	x3, w3
    7ff4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7ff8:	17fffe5a 	b	7960 <fwp_write+0x4dc>
    7ffc:	d37ffaa1 	lsl	x1, x21, #1
    8000:	b7f81363 	tbnz	x3, #63, 826c <fwp_write+0xde8>
    8004:	91002263 	add	x3, x19, #0x8
    8008:	8b010061 	add	x1, x3, x1
    800c:	79400021 	ldrh	w1, [x1]
    8010:	7100041f 	cmp	w0, #0x1
    8014:	93403c23 	sxth	x3, w1
    8018:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    801c:	17fffe51 	b	7960 <fwp_write+0x4dc>
    8020:	52800443 	mov	w3, #0x22                  	// #34
    8024:	91001ff5 	add	x21, sp, #0x7
    8028:	91002273 	add	x19, x19, #0x8
    802c:	aa1503e1 	mov	x1, x21
    8030:	aa1403e0 	mov	x0, x20
    8034:	d2800022 	mov	x2, #0x1                   	// #1
    8038:	39001fe3 	strb	w3, [sp, #7]
    803c:	f90143f7 	str	x23, [sp, #640]
    8040:	8b160277 	add	x23, x19, x22
    8044:	f90147f8 	str	x24, [sp, #648]
    8048:	97ffed92 	bl	3690 <buf_put>
    804c:	b4000696 	cbz	x22, 811c <fwp_write+0xc98>
    8050:	f0000018 	adrp	x24, b000 <_IO_stdin_used+0x70>
    8054:	91182318 	add	x24, x24, #0x608
    8058:	f9014bf9 	str	x25, [sp, #656]
    805c:	f0000019 	adrp	x25, b000 <_IO_stdin_used+0x70>
    8060:	9118a339 	add	x25, x25, #0x628
    8064:	f9014ffa 	str	x26, [sp, #664]
    8068:	1400000d 	b	809c <fwp_write+0xc18>
    806c:	710024bf 	cmp	w5, #0x9
    8070:	54000460 	b.eq	80fc <fwp_write+0xc78>  // b.none
    8074:	710028bf 	cmp	w5, #0xa
    8078:	54000a61 	b.ne	81c4 <fwp_write+0xd40>  // b.any
    807c:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x70>
    8080:	aa1403e0 	mov	x0, x20
    8084:	91186021 	add	x1, x1, #0x618
    8088:	d2800042 	mov	x2, #0x2                   	// #2
    808c:	97ffed81 	bl	3690 <buf_put>
    8090:	91000673 	add	x19, x19, #0x1
    8094:	eb17027f 	cmp	x19, x23
    8098:	540003e0 	b.eq	8114 <fwp_write+0xc90>  // b.none
    809c:	39400265 	ldrb	w5, [x19]
    80a0:	710034bf 	cmp	w5, #0xd
    80a4:	54000180 	b.eq	80d4 <fwp_write+0xc50>  // b.none
    80a8:	54fffe29 	b.ls	806c <fwp_write+0xbe8>  // b.plast
    80ac:	710088bf 	cmp	w5, #0x22
    80b0:	540001c0 	b.eq	80e8 <fwp_write+0xc64>  // b.none
    80b4:	710170bf 	cmp	w5, #0x5c
    80b8:	54000741 	b.ne	81a0 <fwp_write+0xd1c>  // b.any
    80bc:	aa1403e0 	mov	x0, x20
    80c0:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x70>
    80c4:	d2800042 	mov	x2, #0x2                   	// #2
    80c8:	91184021 	add	x1, x1, #0x610
    80cc:	97ffed71 	bl	3690 <buf_put>
    80d0:	17fffff0 	b	8090 <fwp_write+0xc0c>
    80d4:	aa1903e1 	mov	x1, x25
    80d8:	aa1403e0 	mov	x0, x20
    80dc:	d2800042 	mov	x2, #0x2                   	// #2
    80e0:	97ffed6c 	bl	3690 <buf_put>
    80e4:	17ffffeb 	b	8090 <fwp_write+0xc0c>
    80e8:	aa1803e1 	mov	x1, x24
    80ec:	aa1403e0 	mov	x0, x20
    80f0:	d2800042 	mov	x2, #0x2                   	// #2
    80f4:	97ffed67 	bl	3690 <buf_put>
    80f8:	17ffffe6 	b	8090 <fwp_write+0xc0c>
    80fc:	aa1403e0 	mov	x0, x20
    8100:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x70>
    8104:	d2800042 	mov	x2, #0x2                   	// #2
    8108:	91188021 	add	x1, x1, #0x620
    810c:	97ffed61 	bl	3690 <buf_put>
    8110:	17ffffe0 	b	8090 <fwp_write+0xc0c>
    8114:	f9414bf9 	ldr	x25, [sp, #656]
    8118:	f9414ffa 	ldr	x26, [sp, #664]
    811c:	aa1503e1 	mov	x1, x21
    8120:	aa1403e0 	mov	x0, x20
    8124:	52800443 	mov	w3, #0x22                  	// #34
    8128:	17fffd9d 	b	779c <fwp_write+0x318>
    812c:	7100103f 	cmp	w1, #0x4
    8130:	54ffeb21 	b.ne	7e94 <fwp_write+0xa10>  // b.any
    8134:	f94006e0 	ldr	x0, [x23, #8]
    8138:	d37ffc00 	lsr	x0, x0, #63
    813c:	17fffeb3 	b	7c08 <fwp_write+0x784>
    8140:	710002ff 	cmp	w23, #0x0
    8144:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8148:	17fffeb0 	b	7c08 <fwp_write+0x784>
    814c:	528005a1 	mov	w1, #0x2d                  	// #45
    8150:	eb0203e2 	negs	x2, x2
    8154:	da0303e3 	ngc	x3, x3
    8158:	910127e0 	add	x0, sp, #0x49
    815c:	910123f5 	add	x21, sp, #0x48
    8160:	390123e1 	strb	w1, [sp, #72]
    8164:	97ffeb2f 	bl	2e20 <fwp_fmt_u128>
    8168:	17fffe18 	b	79c8 <fwp_write+0x544>
    816c:	d37ceea1 	lsl	x1, x21, #4
    8170:	b7f810a3 	tbnz	x3, #63, 8384 <fwp_write+0xf00>
    8174:	91002260 	add	x0, x19, #0x8
    8178:	8b010001 	add	x1, x0, x1
    817c:	17fffdf9 	b	7960 <fwp_write+0x4dc>
    8180:	f9400a61 	ldr	x1, [x19, #16]
    8184:	8b010000 	add	x0, x0, x1
    8188:	f9400001 	ldr	x1, [x0]
    818c:	17fffdf5 	b	7960 <fwp_write+0x4dc>
    8190:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x70>
    8194:	d2800042 	mov	x2, #0x2                   	// #2
    8198:	9116c021 	add	x1, x1, #0x5b0
    819c:	17fffed6 	b	7cf4 <fwp_write+0x870>
    81a0:	7101fcbf 	cmp	w5, #0x7f
    81a4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    81a8:	540000e9 	b.ls	81c4 <fwp_write+0xd40>  // b.plast
    81ac:	aa1503e1 	mov	x1, x21
    81b0:	aa1403e0 	mov	x0, x20
    81b4:	d2800022 	mov	x2, #0x1                   	// #1
    81b8:	39001fe5 	strb	w5, [sp, #7]
    81bc:	97ffed35 	bl	3690 <buf_put>
    81c0:	17ffffb4 	b	8090 <fwp_write+0xc0c>
    81c4:	d2800203 	mov	x3, #0x10                  	// #16
    81c8:	f0000004 	adrp	x4, b000 <_IO_stdin_used+0x70>
    81cc:	aa0303e1 	mov	x1, x3
    81d0:	9118c084 	add	x4, x4, #0x630
    81d4:	910123f6 	add	x22, sp, #0x48
    81d8:	52800042 	mov	w2, #0x2                   	// #2
    81dc:	aa1603e0 	mov	x0, x22
    81e0:	97ffe98c 	bl	2810 <__snprintf_chk@plt>
    81e4:	aa1603e0 	mov	x0, x22
    81e8:	97ffe952 	bl	2730 <strlen@plt>
    81ec:	aa1603e1 	mov	x1, x22
    81f0:	aa0003e2 	mov	x2, x0
    81f4:	aa1403e0 	mov	x0, x20
    81f8:	97ffed26 	bl	3690 <buf_put>
    81fc:	17ffffa5 	b	8090 <fwp_write+0xc0c>
    8200:	1e604100 	fmov	d0, d8
    8204:	aa1503e0 	mov	x0, x21
    8208:	52800221 	mov	w1, #0x11                  	// #17
    820c:	97ffee62 	bl	3b94 <fwp_format_g.constprop.0>
    8210:	17fffe43 	b	7b1c <fwp_write+0x698>
    8214:	b9401040 	ldr	w0, [x2, #16]
    8218:	350003c0 	cbnz	w0, 8290 <fwp_write+0xe0c>
    821c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8220:	f947f400 	ldr	x0, [x0, #4072]
    8224:	f94127e2 	ldr	x2, [sp, #584]
    8228:	f9400001 	ldr	x1, [x0]
    822c:	eb010042 	subs	x2, x2, x1
    8230:	d2800001 	mov	x1, #0x0                   	// #0
    8234:	54ffd721 	b.ne	7d18 <fwp_write+0x894>  // b.any
    8238:	f9413bf5 	ldr	x21, [sp, #624]
    823c:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x70>
    8240:	f9413ff6 	ldr	x22, [sp, #632]
    8244:	aa1403e0 	mov	x0, x20
    8248:	f94143f7 	ldr	x23, [sp, #640]
    824c:	911a0021 	add	x1, x1, #0x680
    8250:	f94147f8 	ldr	x24, [sp, #648]
    8254:	d2800042 	mov	x2, #0x2                   	// #2
    8258:	17fffd0f 	b	7694 <fwp_write+0x210>
    825c:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x70>
    8260:	d2800042 	mov	x2, #0x2                   	// #2
    8264:	9116e021 	add	x1, x1, #0x5b8
    8268:	17fffea3 	b	7cf4 <fwp_write+0x870>
    826c:	f9400a63 	ldr	x3, [x19, #16]
    8270:	8b030021 	add	x1, x1, x3
    8274:	17ffff66 	b	800c <fwp_write+0xb88>
    8278:	f9400a61 	ldr	x1, [x19, #16]
    827c:	8b0102a1 	add	x1, x21, x1
    8280:	17fffdb4 	b	7950 <fwp_write+0x4cc>
    8284:	f9400a63 	ldr	x3, [x19, #16]
    8288:	8b030021 	add	x1, x1, x3
    828c:	17ffff56 	b	7fe4 <fwp_write+0xb60>
    8290:	b9404840 	ldr	w0, [x2, #72]
    8294:	91001ff5 	add	x21, sp, #0x7
    8298:	34ffa380 	cbz	w0, 7708 <fwp_write+0x284>
    829c:	52800503 	mov	w3, #0x28                  	// #40
    82a0:	aa1403e0 	mov	x0, x20
    82a4:	aa1503e1 	mov	x1, x21
    82a8:	d2800022 	mov	x2, #0x1                   	// #1
    82ac:	39001fe3 	strb	w3, [sp, #7]
    82b0:	97ffecf8 	bl	3690 <buf_put>
    82b4:	b9401380 	ldr	w0, [x28, #16]
    82b8:	52800038 	mov	w24, #0x1                   	// #1
    82bc:	7100001f 	cmp	w0, #0x0
    82c0:	54ffa38c 	b.gt	7730 <fwp_write+0x2ac>
    82c4:	17fffd33 	b	7790 <fwp_write+0x30c>
    82c8:	f9014bf9 	str	x25, [sp, #656]
    82cc:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10d18>
    82d0:	f9014ffa 	str	x26, [sp, #664]
    82d4:	f9400676 	ldr	x22, [x19, #8]
    82d8:	910ac333 	add	x19, x25, #0x2b0
    82dc:	91002273 	add	x19, x19, #0x8
    82e0:	937ffed8 	asr	x24, x22, #63
    82e4:	aa1802c0 	orr	x0, x22, x24
    82e8:	b5000320 	cbnz	x0, 834c <fwp_write+0xec8>
    82ec:	110006b5 	add	w21, w21, #0x1
    82f0:	710016bf 	cmp	w21, #0x5
    82f4:	54ffffc1 	b.ne	82ec <fwp_write+0xe68>  // b.any
    82f8:	b7f80578 	tbnz	x24, #63, 83a4 <fwp_write+0xf20>
    82fc:	910023f3 	add	x19, sp, #0x8
    8300:	aa1603e2 	mov	x2, x22
    8304:	aa1303e0 	mov	x0, x19
    8308:	d2800003 	mov	x3, #0x0                   	// #0
    830c:	97ffeac5 	bl	2e20 <fwp_fmt_u128>
    8310:	910123f5 	add	x21, sp, #0x48
    8314:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x70>
    8318:	aa1303e4 	mov	x4, x19
    831c:	aa1503e0 	mov	x0, x21
    8320:	9119e063 	add	x3, x3, #0x678
    8324:	d2804002 	mov	x2, #0x200                 	// #512
    8328:	52800041 	mov	w1, #0x2                   	// #2
    832c:	97ffe905 	bl	2740 <__sprintf_chk@plt>
    8330:	aa1503e0 	mov	x0, x21
    8334:	97ffe8ff 	bl	2730 <strlen@plt>
    8338:	aa1503e1 	mov	x1, x21
    833c:	aa0003e2 	mov	x2, x0
    8340:	aa1403e0 	mov	x0, x20
    8344:	97ffecd3 	bl	3690 <buf_put>
    8348:	17fffe47 	b	7c64 <fwp_write+0x7e0>
    834c:	f9400277 	ldr	x23, [x19]
    8350:	aa1603e0 	mov	x0, x22
    8354:	aa1803e1 	mov	x1, x24
    8358:	aa1703e2 	mov	x2, x23
    835c:	937ffefa 	asr	x26, x23, #63
    8360:	aa1a03e3 	mov	x3, x26
    8364:	94000a23 	bl	abf0 <__modti3>
    8368:	aa010000 	orr	x0, x0, x1
    836c:	b40002c0 	cbz	x0, 83c4 <fwp_write+0xf40>
    8370:	110006b5 	add	w21, w21, #0x1
    8374:	91004273 	add	x19, x19, #0x10
    8378:	710016bf 	cmp	w21, #0x5
    837c:	54fffe81 	b.ne	834c <fwp_write+0xec8>  // b.any
    8380:	17ffffde 	b	82f8 <fwp_write+0xe74>
    8384:	f9400a60 	ldr	x0, [x19, #16]
    8388:	8b000021 	add	x1, x1, x0
    838c:	17fffd75 	b	7960 <fwp_write+0x4dc>
    8390:	528c29c0 	mov	w0, #0x614e                	// #24910
    8394:	910123f5 	add	x21, sp, #0x48
    8398:	72a009c0 	movk	w0, #0x4e, lsl #16
    839c:	b9004be0 	str	w0, [sp, #72]
    83a0:	17fffda2 	b	7a28 <fwp_write+0x5a4>
    83a4:	528005a1 	mov	w1, #0x2d                  	// #45
    83a8:	eb1603e2 	negs	x2, x22
    83ac:	da1803e3 	ngc	x3, x24
    83b0:	910027e0 	add	x0, sp, #0x9
    83b4:	910023f3 	add	x19, sp, #0x8
    83b8:	390023e1 	strb	w1, [sp, #8]
    83bc:	97ffea99 	bl	2e20 <fwp_fmt_u128>
    83c0:	17ffffd4 	b	8310 <fwp_write+0xe8c>
    83c4:	aa1703e2 	mov	x2, x23
    83c8:	aa1a03e3 	mov	x3, x26
    83cc:	aa1603e0 	mov	x0, x22
    83d0:	aa1803e1 	mov	x1, x24
    83d4:	94000927 	bl	a870 <__divti3>
    83d8:	aa0003e2 	mov	x2, x0
    83dc:	aa0103e3 	mov	x3, x1
    83e0:	b7f80201 	tbnz	x1, #63, 8420 <fwp_write+0xf9c>
    83e4:	910023f3 	add	x19, sp, #0x8
    83e8:	aa1303e0 	mov	x0, x19
    83ec:	97ffea8d 	bl	2e20 <fwp_fmt_u128>
    83f0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    83f4:	910ac339 	add	x25, x25, #0x2b0
    83f8:	910123f5 	add	x21, sp, #0x48
    83fc:	aa1303e4 	mov	x4, x19
    8400:	aa1503e0 	mov	x0, x21
    8404:	f0000003 	adrp	x3, b000 <_IO_stdin_used+0x70>
    8408:	f8616b25 	ldr	x5, [x25, x1]
    840c:	9119c063 	add	x3, x3, #0x670
    8410:	d2804002 	mov	x2, #0x200                 	// #512
    8414:	52800041 	mov	w1, #0x2                   	// #2
    8418:	97ffe8ca 	bl	2740 <__sprintf_chk@plt>
    841c:	17ffffc5 	b	8330 <fwp_write+0xeac>
    8420:	528005a4 	mov	w4, #0x2d                  	// #45
    8424:	eb0003e2 	negs	x2, x0
    8428:	da0103e3 	ngc	x3, x1
    842c:	910027e0 	add	x0, sp, #0x9
    8430:	910023f3 	add	x19, sp, #0x8
    8434:	390023e4 	strb	w4, [sp, #8]
    8438:	97ffea7a 	bl	2e20 <fwp_fmt_u128>
    843c:	17ffffed 	b	83f0 <fwp_write+0xf6c>
    8440:	f9013bf5 	str	x21, [sp, #624]
    8444:	f9013ff6 	str	x22, [sp, #632]
    8448:	f90143f7 	str	x23, [sp, #640]
    844c:	f90147f8 	str	x24, [sp, #648]
    8450:	f9014bf9 	str	x25, [sp, #656]
    8454:	f9014ffa 	str	x26, [sp, #664]
    8458:	f90153fb 	str	x27, [sp, #672]
    845c:	f90157fc 	str	x28, [sp, #680]
    8460:	fd015be8 	str	d8, [sp, #688]
    8464:	fd015fe9 	str	d9, [sp, #696]
    8468:	97ffe90e 	bl	28a0 <__stack_chk_fail@plt>
    846c:	d503201f 	nop

0000000000008470 <fwp_main_thread>:
    8470:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8474:	b0000380 	adrp	x0, 79000 <fwp_root_context+0xbb0>
    8478:	9118c001 	add	x1, x0, #0x630
    847c:	910003fd 	mov	x29, sp
    8480:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8484:	f947f400 	ldr	x0, [x0, #4072]
    8488:	a9025bf5 	stp	x21, x22, [sp, #32]
    848c:	a90363f7 	stp	x23, x24, [sp, #48]
    8490:	d10683ff 	sub	sp, sp, #0x1a0
    8494:	b953a421 	ldr	w1, [x1, #5028]
    8498:	f9400002 	ldr	x2, [x0]
    849c:	f900cfe2 	str	x2, [sp, #408]
    84a0:	d2800002 	mov	x2, #0x0                   	// #0
    84a4:	34002801 	cbz	w1, 89a4 <fwp_main_thread+0x534>
    84a8:	b0000380 	adrp	x0, 79000 <fwp_root_context+0xbb0>
    84ac:	9118c000 	add	x0, x0, #0x630
    84b0:	b953a800 	ldr	w0, [x0, #5032]
    84b4:	35002820 	cbnz	w0, 89b8 <fwp_main_thread+0x548>
    84b8:	910203e5 	add	x5, sp, #0x80
    84bc:	900000d8 	adrp	x24, 20000 <__data_start>
    84c0:	900000c2 	adrp	x2, 20000 <__data_start>
    84c4:	91014316 	add	x22, x24, #0x50
    84c8:	91114042 	add	x2, x2, #0x450
    84cc:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    84d0:	d2a00024 	mov	x4, #0x10000               	// #65536
    84d4:	910263e0 	add	x0, sp, #0x98
    84d8:	d2800001 	mov	x1, #0x0                   	// #0
    84dc:	f90007e0 	str	x0, [sp, #8]
    84e0:	f90013e5 	str	x5, [sp, #32]
    84e4:	f9004fe2 	str	x2, [sp, #152]
    84e8:	a90a0ec5 	stp	x5, x3, [x22, #160]
    84ec:	b900a3ff 	str	wzr, [sp, #160]
    84f0:	f90057e4 	str	x4, [sp, #168]
    84f4:	97ffe883 	bl	2700 <sigaltstack@plt>
    84f8:	a91b53f3 	stp	x19, x20, [sp, #432]
    84fc:	35011980 	cbnz	w0, a82c <fwp_main_thread+0x23bc>
    8500:	4f000400 	movi	v0.4s, #0x0
    8504:	910423e0 	add	x0, sp, #0x108
    8508:	f0ffffc1 	adrp	x1, 3000 <ad_raw_record+0x70>
    850c:	9102c021 	add	x1, x1, #0xb0
    8510:	f90083e1 	str	x1, [sp, #256]
    8514:	52800082 	mov	w2, #0x4                   	// #4
    8518:	72a10002 	movk	w2, #0x800, lsl #16
    851c:	910403f4 	add	x20, sp, #0x100
    8520:	3d802000 	str	q0, [x0, #128]
    8524:	b9018be2 	str	w2, [sp, #392]
    8528:	ad000000 	stp	q0, q0, [x0]
    852c:	ad010000 	stp	q0, q0, [x0, #32]
    8530:	ad020000 	stp	q0, q0, [x0, #64]
    8534:	ad030000 	stp	q0, q0, [x0, #96]
    8538:	97ffe8ca 	bl	2860 <sigemptyset@plt>
    853c:	35011780 	cbnz	w0, a82c <fwp_main_thread+0x23bc>
    8540:	aa1403e1 	mov	x1, x20
    8544:	d2800002 	mov	x2, #0x0                   	// #0
    8548:	52800160 	mov	w0, #0xb                   	// #11
    854c:	97ffe8dd 	bl	28c0 <sigaction@plt>
    8550:	350116e0 	cbnz	w0, a82c <fwp_main_thread+0x23bc>
    8554:	aa1403e1 	mov	x1, x20
    8558:	d2800002 	mov	x2, #0x0                   	// #0
    855c:	528000e0 	mov	w0, #0x7                   	// #7
    8560:	97ffe8d8 	bl	28c0 <sigaction@plt>
    8564:	35011640 	cbnz	w0, a82c <fwp_main_thread+0x23bc>
    8568:	b0000380 	adrp	x0, 79000 <fwp_root_context+0xbb0>
    856c:	a91e6bf9 	stp	x25, x26, [sp, #480]
    8570:	9118c019 	add	x25, x0, #0x630
    8574:	52800033 	mov	w19, #0x1                   	// #1
    8578:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    857c:	910ec000 	add	x0, x0, #0x3b0
    8580:	b90132d3 	str	w19, [x22, #304]
    8584:	fd4a1320 	ldr	d0, [x25, #5152]
    8588:	7e61d800 	ucvtf	d0, d0
    858c:	fd00a6c0 	str	d0, [x22, #328]
    8590:	94000a74 	bl	af60 <atexit>
    8594:	35011300 	cbnz	w0, a7f4 <fwp_main_thread+0x2384>
    8598:	b943c6c0 	ldr	w0, [x22, #964]
    859c:	34002160 	cbz	w0, 89c8 <fwp_main_thread+0x558>
    85a0:	91014319 	add	x25, x24, #0x50
    85a4:	f9404f34 	ldr	x20, [x25, #152]
    85a8:	b4000c34 	cbz	x20, 872c <fwp_main_thread+0x2bc>
    85ac:	aa1403f3 	mov	x19, x20
    85b0:	91010295 	add	x21, x20, #0x40
    85b4:	39414a97 	ldrb	w23, [x20, #82]
    85b8:	52800036 	mov	w22, #0x1                   	// #1
    85bc:	39014a96 	strb	w22, [x20, #82]
    85c0:	f9401680 	ldr	x0, [x20, #40]
    85c4:	b4000620 	cbz	x0, 8688 <fwp_main_thread+0x218>
    85c8:	f9403281 	ldr	x1, [x20, #96]
    85cc:	39414680 	ldrb	w0, [x20, #81]
    85d0:	b4000c81 	cbz	x1, 8760 <fwp_main_thread+0x2f0>
    85d4:	36000b40 	tbz	w0, #0, 873c <fwp_main_thread+0x2cc>
    85d8:	39414a62 	ldrb	w2, [x19, #82]
    85dc:	f9402280 	ldr	x0, [x20, #64]
    85e0:	37000ea2 	tbnz	w2, #0, 87b4 <fwp_main_thread+0x344>
    85e4:	f9403261 	ldr	x1, [x19, #96]
    85e8:	a911fe75 	stp	x21, xzr, [x19, #280]
    85ec:	f9009660 	str	x0, [x19, #296]
    85f0:	b4000040 	cbz	x0, 85f8 <fwp_main_thread+0x188>
    85f4:	f9009013 	str	x19, [x0, #288]
    85f8:	f9002293 	str	x19, [x20, #64]
    85fc:	b4000101 	cbz	x1, 861c <fwp_main_thread+0x1ac>
    8600:	f9409720 	ldr	x0, [x25, #296]
    8604:	39015676 	strb	w22, [x19, #85]
    8608:	f9003661 	str	x1, [x19, #104]
    860c:	a910827f 	stp	xzr, x0, [x19, #264]
    8610:	b4000040 	cbz	x0, 8618 <fwp_main_thread+0x1a8>
    8614:	f9008413 	str	x19, [x0, #264]
    8618:	f9009733 	str	x19, [x25, #296]
    861c:	39015a7f 	strb	wzr, [x19, #86]
    8620:	97fff909 	bl	6a44 <fwp_block>
    8624:	f9408e62 	ldr	x2, [x19, #280]
    8628:	b4000142 	cbz	x2, 8650 <fwp_main_thread+0x1e0>
    862c:	a9520261 	ldp	x1, x0, [x19, #288]
    8630:	b4000ce1 	cbz	x1, 87cc <fwp_main_thread+0x35c>
    8634:	f9009420 	str	x0, [x1, #296]
    8638:	f9409660 	ldr	x0, [x19, #296]
    863c:	b4000040 	cbz	x0, 8644 <fwp_main_thread+0x1d4>
    8640:	f9009001 	str	x1, [x0, #288]
    8644:	91080260 	add	x0, x19, #0x200
    8648:	f900967f 	str	xzr, [x19, #296]
    864c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8650:	39415660 	ldrb	w0, [x19, #85]
    8654:	f9404f22 	ldr	x2, [x25, #152]
    8658:	36000aa0 	tbz	w0, #0, 87ac <fwp_main_thread+0x33c>
    865c:	a9508261 	ldp	x1, x0, [x19, #264]
    8660:	b4000ba1 	cbz	x1, 87d4 <fwp_main_thread+0x364>
    8664:	f9008820 	str	x0, [x1, #272]
    8668:	b4000040 	cbz	x0, 8670 <fwp_main_thread+0x200>
    866c:	f9008401 	str	x1, [x0, #264]
    8670:	91080260 	add	x0, x19, #0x200
    8674:	3901567f 	strb	wzr, [x19, #85]
    8678:	aa0203f3 	mov	x19, x2
    867c:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    8680:	f9401680 	ldr	x0, [x20, #40]
    8684:	b5fffa20 	cbnz	x0, 85c8 <fwp_main_thread+0x158>
    8688:	91014300 	add	x0, x24, #0x50
    868c:	39014a97 	strb	w23, [x20, #82]
    8690:	f941d400 	ldr	x0, [x0, #936]
    8694:	b5000080 	cbnz	x0, 86a4 <fwp_main_thread+0x234>
    8698:	91014314 	add	x20, x24, #0x50
    869c:	f941de80 	ldr	x0, [x20, #952]
    86a0:	b400ff40 	cbz	x0, a688 <fwp_main_thread+0x2218>
    86a4:	91014300 	add	x0, x24, #0x50
    86a8:	f941f001 	ldr	x1, [x0, #992]
    86ac:	b903d81f 	str	wzr, [x0, #984]
    86b0:	eb13003f 	cmp	x1, x19
    86b4:	54010001 	b.ne	a6b4 <fwp_main_thread+0x2244>  // b.any
    86b8:	b40009d3 	cbz	x19, 87f0 <fwp_main_thread+0x380>
    86bc:	91014300 	add	x0, x24, #0x50
    86c0:	52800021 	mov	w1, #0x1                   	// #1
    86c4:	39014a61 	strb	w1, [x19, #82]
    86c8:	f941c005 	ldr	x5, [x0, #896]
    86cc:	b4000925 	cbz	x5, 87f0 <fwp_main_thread+0x380>
    86d0:	394140a0 	ldrb	w0, [x5, #80]
    86d4:	37000060 	tbnz	w0, #0, 86e0 <fwp_main_thread+0x270>
    86d8:	aa0503e0 	mov	x0, x5
    86dc:	97ffec05 	bl	36f0 <fwp_cancel_tree.part.0>
    86e0:	f9409ca5 	ldr	x5, [x5, #312]
    86e4:	b5ffff65 	cbnz	x5, 86d0 <fwp_main_thread+0x260>
    86e8:	91014314 	add	x20, x24, #0x50
    86ec:	52800035 	mov	w21, #0x1                   	// #1
    86f0:	f9402a60 	ldr	x0, [x19, #80]
    86f4:	f2001c1f 	tst	x0, #0xff000000ff
    86f8:	540000e1 	b.ne	8714 <fwp_main_thread+0x2a4>  // b.any
    86fc:	f9406280 	ldr	x0, [x20, #192]
    8700:	39015275 	strb	w21, [x19, #84]
    8704:	f900827f 	str	xzr, [x19, #256]
    8708:	b40006a0 	cbz	x0, 87dc <fwp_main_thread+0x36c>
    870c:	f9008013 	str	x19, [x0, #256]
    8710:	f9006293 	str	x19, [x20, #192]
    8714:	97fff8cc 	bl	6a44 <fwp_block>
    8718:	97fff85e 	bl	6890 <fwp_free_zombie>
    871c:	f941c280 	ldr	x0, [x20, #896]
    8720:	b4000680 	cbz	x0, 87f0 <fwp_main_thread+0x380>
    8724:	f941f293 	ldr	x19, [x20, #992]
    8728:	17fffff2 	b	86f0 <fwp_main_thread+0x280>
    872c:	f941d720 	ldr	x0, [x25, #936]
    8730:	b50005a0 	cbnz	x0, 87e4 <fwp_main_thread+0x374>
    8734:	d2800013 	mov	x19, #0x0                   	// #0
    8738:	17ffffd8 	b	8698 <fwp_main_thread+0x228>
    873c:	97ffec91 	bl	3980 <fwp_now_ns>
    8740:	f9403281 	ldr	x1, [x20, #96]
    8744:	eb01001f 	cmp	x0, x1
    8748:	540000ab 	b.lt	875c <fwp_main_thread+0x2ec>  // b.tstop
    874c:	39414280 	ldrb	w0, [x20, #80]
    8750:	37000060 	tbnz	w0, #0, 875c <fwp_main_thread+0x2ec>
    8754:	aa1403e0 	mov	x0, x20
    8758:	97ffebe6 	bl	36f0 <fwp_cancel_tree.part.0>
    875c:	39414680 	ldrb	w0, [x20, #81]
    8760:	39414a62 	ldrb	w2, [x19, #82]
    8764:	3707f3c0 	tbnz	w0, #0, 85dc <fwp_main_thread+0x16c>
    8768:	f9403281 	ldr	x1, [x20, #96]
    876c:	370001c2 	tbnz	w2, #0, 87a4 <fwp_main_thread+0x334>
    8770:	f9403260 	ldr	x0, [x19, #96]
    8774:	b4000180 	cbz	x0, 87a4 <fwp_main_thread+0x334>
    8778:	b4000061 	cbz	x1, 8784 <fwp_main_thread+0x314>
    877c:	eb01001f 	cmp	x0, x1
    8780:	9a81d000 	csel	x0, x0, x1, le
    8784:	f9402281 	ldr	x1, [x20, #64]
    8788:	a911fe75 	stp	x21, xzr, [x19, #280]
    878c:	f9009661 	str	x1, [x19, #296]
    8790:	b400f5a1 	cbz	x1, a644 <fwp_main_thread+0x21d4>
    8794:	f9009033 	str	x19, [x1, #288]
    8798:	aa0003e1 	mov	x1, x0
    879c:	f9002293 	str	x19, [x20, #64]
    87a0:	17ffff98 	b	8600 <fwp_main_thread+0x190>
    87a4:	f9402280 	ldr	x0, [x20, #64]
    87a8:	17ffff90 	b	85e8 <fwp_main_thread+0x178>
    87ac:	aa0203f3 	mov	x19, x2
    87b0:	17ffff84 	b	85c0 <fwp_main_thread+0x150>
    87b4:	a911fe75 	stp	x21, xzr, [x19, #280]
    87b8:	f9009660 	str	x0, [x19, #296]
    87bc:	b4000040 	cbz	x0, 87c4 <fwp_main_thread+0x354>
    87c0:	f9009013 	str	x19, [x0, #288]
    87c4:	f9002293 	str	x19, [x20, #64]
    87c8:	17ffff95 	b	861c <fwp_main_thread+0x1ac>
    87cc:	f9000040 	str	x0, [x2]
    87d0:	17ffff9b 	b	863c <fwp_main_thread+0x1cc>
    87d4:	f9009720 	str	x0, [x25, #296]
    87d8:	17ffffa4 	b	8668 <fwp_main_thread+0x1f8>
    87dc:	f9006693 	str	x19, [x20, #200]
    87e0:	17ffffcc 	b	8710 <fwp_main_thread+0x2a0>
    87e4:	f941f320 	ldr	x0, [x25, #992]
    87e8:	b903db3f 	str	wzr, [x25, #984]
    87ec:	b500f640 	cbnz	x0, a6b4 <fwp_main_thread+0x2244>
    87f0:	91014314 	add	x20, x24, #0x50
    87f4:	97fff827 	bl	6890 <fwp_free_zombie>
    87f8:	f9406680 	ldr	x0, [x20, #200]
    87fc:	b500f5c0 	cbnz	x0, a6b4 <fwp_main_thread+0x2244>
    8800:	f9409680 	ldr	x0, [x20, #296]
    8804:	b500f580 	cbnz	x0, a6b4 <fwp_main_thread+0x2244>
    8808:	b9417280 	ldr	w0, [x20, #368]
    880c:	340001c0 	cbz	w0, 8844 <fwp_main_thread+0x3d4>
    8810:	93407c15 	sxtw	x21, w0
    8814:	51000400 	sub	w0, w0, #0x1
    8818:	d1000ab5 	sub	x21, x21, #0x2
    881c:	91060296 	add	x22, x20, #0x180
    8820:	cb2042b5 	sub	x21, x21, w0, uxtw
    8824:	93407c13 	sxtw	x19, w0
    8828:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    882c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8830:	b9017293 	str	w19, [x20, #368]
    8834:	d1000673 	sub	x19, x19, #0x1
    8838:	97ffe862 	bl	29c0 <munmap@plt>
    883c:	eb15027f 	cmp	x19, x21
    8840:	54ffff41 	b.ne	8828 <fwp_main_thread+0x3b8>  // b.any
    8844:	900000d3 	adrp	x19, 20000 <__data_start>
    8848:	91004260 	add	x0, x19, #0x10
    884c:	b9402800 	ldr	w0, [x0, #40]
    8850:	37f80040 	tbnz	w0, #31, 8858 <fwp_main_thread+0x3e8>
    8854:	97ffe817 	bl	28b0 <close@plt>
    8858:	91014300 	add	x0, x24, #0x50
    885c:	91004261 	add	x1, x19, #0x10
    8860:	12800002 	mov	w2, #0xffffffff            	// #-1
    8864:	d2800013 	mov	x19, #0x0                   	// #0
    8868:	f941f415 	ldr	x21, [x0, #1000]
    886c:	b9002822 	str	w2, [x1, #40]
    8870:	f941f814 	ldr	x20, [x0, #1008]
    8874:	b4000175 	cbz	x21, 88a0 <fwp_main_thread+0x430>
    8878:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    887c:	b40000c0 	cbz	x0, 8894 <fwp_main_thread+0x424>
    8880:	f9400001 	ldr	x1, [x0]
    8884:	b500f181 	cbnz	x1, a6b4 <fwp_main_thread+0x2244>
    8888:	f9400401 	ldr	x1, [x0, #8]
    888c:	b500f141 	cbnz	x1, a6b4 <fwp_main_thread+0x2244>
    8890:	97fff100 	bl	4c90 <fwp_mem_free>
    8894:	91000673 	add	x19, x19, #0x1
    8898:	eb1302bf 	cmp	x21, x19
    889c:	54fffee1 	b.ne	8878 <fwp_main_thread+0x408>  // b.any
    88a0:	aa1403e0 	mov	x0, x20
    88a4:	97fff0fb 	bl	4c90 <fwp_mem_free>
    88a8:	91014300 	add	x0, x24, #0x50
    88ac:	f941f013 	ldr	x19, [x0, #992]
    88b0:	f901f41f 	str	xzr, [x0, #1000]
    88b4:	f901f81f 	str	xzr, [x0, #1008]
    88b8:	b40001f3 	cbz	x19, 88f4 <fwp_main_thread+0x484>
    88bc:	f9401661 	ldr	x1, [x19, #40]
    88c0:	b500efa1 	cbnz	x1, a6b4 <fwp_main_thread+0x2244>
    88c4:	f9405661 	ldr	x1, [x19, #168]
    88c8:	b500ef61 	cbnz	x1, a6b4 <fwp_main_thread+0x2244>
    88cc:	f941d401 	ldr	x1, [x0, #936]
    88d0:	b500ef21 	cbnz	x1, a6b4 <fwp_main_thread+0x2244>
    88d4:	f941dc00 	ldr	x0, [x0, #952]
    88d8:	b500eee0 	cbnz	x0, a6b4 <fwp_main_thread+0x2244>
    88dc:	d2823a02 	mov	x2, #0x11d0                	// #4560
    88e0:	90000380 	adrp	x0, 78000 <ad_raw_blocks+0x17bb0>
    88e4:	91114000 	add	x0, x0, #0x450
    88e8:	97ffe7e2 	bl	2870 <memset@plt>
    88ec:	aa1303e0 	mov	x0, x19
    88f0:	97fff0e8 	bl	4c90 <fwp_mem_free>
    88f4:	91014306 	add	x6, x24, #0x50
    88f8:	b0000380 	adrp	x0, 79000 <fwp_root_context+0xbb0>
    88fc:	9118c000 	add	x0, x0, #0x630
    8900:	52800041 	mov	w1, #0x2                   	// #2
    8904:	3dc01701 	ldr	q1, [x24, #80]
    8908:	f0000002 	adrp	x2, b000 <_IO_stdin_used+0x70>
    890c:	3dc004c2 	ldr	q2, [x6, #16]
    8910:	911e6042 	add	x2, x2, #0x798
    8914:	fd4a1000 	ldr	d0, [x0, #5152]
    8918:	f9004cdf 	str	xzr, [x6, #152]
    891c:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    8920:	fd40a4c1 	ldr	d1, [x6, #328]
    8924:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8928:	f947e800 	ldr	x0, [x0, #4048]
    892c:	7e61d800 	ucvtf	d0, d0
    8930:	a95390c3 	ldp	x3, x4, [x6, #312]
    8934:	b90130df 	str	wzr, [x6, #304]
    8938:	f9400000 	ldr	x0, [x0]
    893c:	1e613801 	fsub	d1, d0, d1
    8940:	f940acc5 	ldr	x5, [x6, #344]
    8944:	f901f0df 	str	xzr, [x6, #992]
    8948:	5ef1b842 	addp	d2, v2.2d
    894c:	fd40a8c0 	ldr	d0, [x6, #336]
    8950:	fd0058c2 	str	d2, [x6, #176]
    8954:	97ffe7ef 	bl	2910 <__fprintf_chk@plt>
    8958:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    895c:	f947ec00 	ldr	x0, [x0, #4056]
    8960:	f9400000 	ldr	x0, [x0]
    8964:	97ffe81b 	bl	29d0 <fflush@plt>
    8968:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    896c:	f947f400 	ldr	x0, [x0, #4072]
    8970:	f940cfe2 	ldr	x2, [sp, #408]
    8974:	f9400001 	ldr	x1, [x0]
    8978:	eb010042 	subs	x2, x2, x1
    897c:	d2800001 	mov	x1, #0x0                   	// #0
    8980:	5400f341 	b.ne	a7e8 <fwp_main_thread+0x2378>  // b.any
    8984:	a95b53f3 	ldp	x19, x20, [sp, #432]
    8988:	d2800000 	mov	x0, #0x0                   	// #0
    898c:	a95e6bf9 	ldp	x25, x26, [sp, #480]
    8990:	910683ff 	add	sp, sp, #0x1a0
    8994:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8998:	a94363f7 	ldp	x23, x24, [sp, #48]
    899c:	a8c77bfd 	ldp	x29, x30, [sp], #112
    89a0:	d65f03c0 	ret
    89a4:	97ffedd8 	bl	4104 <fwp_heap_init>
    89a8:	b0000380 	adrp	x0, 79000 <fwp_root_context+0xbb0>
    89ac:	9118c000 	add	x0, x0, #0x630
    89b0:	b953a800 	ldr	w0, [x0, #5032]
    89b4:	34ffd820 	cbz	w0, 84b8 <fwp_main_thread+0x48>
    89b8:	f0ffffc0 	adrp	x0, 3000 <ad_raw_record+0x70>
    89bc:	913e8000 	add	x0, x0, #0xfa0
    89c0:	94000968 	bl	af60 <atexit>
    89c4:	17fffebd 	b	84b8 <fwp_main_thread+0x48>
    89c8:	f941cac2 	ldr	x2, [x22, #912]
    89cc:	b0ffffe0 	adrp	x0, 5000 <fwp_heap_alloc_slow+0x50>
    89d0:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    89d4:	913c4000 	add	x0, x0, #0xf10
    89d8:	913d4021 	add	x1, x1, #0xf50
    89dc:	a90807e2 	stp	x2, x1, [sp, #128]
    89e0:	d2804015 	mov	x21, #0x200                 	// #512
    89e4:	f94007e1 	ldr	x1, [sp, #8]
    89e8:	a90a83ff 	stp	xzr, x0, [sp, #168]
    89ec:	f94013e0 	ldr	x0, [sp, #32]
    89f0:	a91f73fb 	stp	x27, x28, [sp, #496]
    89f4:	d280001c 	mov	x28, #0x0                   	// #0
    89f8:	fd0103e8 	str	d8, [sp, #512]
    89fc:	f9000fff 	str	xzr, [sp, #24]
    8a00:	f9004be1 	str	x1, [sp, #144]
    8a04:	f9004fff 	str	xzr, [sp, #152]
    8a08:	f901cac0 	str	x0, [x22, #912]
    8a0c:	d503201f 	nop
    8a10:	f9400fe2 	ldr	x2, [sp, #24]
    8a14:	f10006b6 	subs	x22, x21, #0x1
    8a18:	aa1403e1 	mov	x1, x20
    8a1c:	da1f039a 	sbc	x26, x28, xzr
    8a20:	52800020 	mov	w0, #0x1                   	// #1
    8a24:	f90053f6 	str	x22, [sp, #160]
    8a28:	a9100bf6 	stp	x22, x2, [sp, #256]
    8a2c:	97fff21a 	bl	5294 <fwp_data.part.0.constprop.0>
    8a30:	aa0003e2 	mov	x2, x0
    8a34:	f949db21 	ldr	x1, [x25, #5040]
    8a38:	f9000fe2 	str	x2, [sp, #24]
    8a3c:	f949ef20 	ldr	x0, [x25, #5080]
    8a40:	cb010041 	sub	x1, x2, x1
    8a44:	aa1603f5 	mov	x21, x22
    8a48:	aa1a03fc 	mov	x28, x26
    8a4c:	eb00403f 	cmp	x1, x0, lsl #16
    8a50:	54000302 	b.cs	8ab0 <fwp_main_thread+0x640>  // b.hs, b.nlast
    8a54:	d350fc20 	lsr	x0, x1, #16
    8a58:	f949ff24 	ldr	x4, [x25, #5112]
    8a5c:	8b000800 	add	x0, x0, x0, lsl #2
    8a60:	d37df002 	lsl	x2, x0, #3
    8a64:	8b020080 	add	x0, x4, x2
    8a68:	f9401017 	ldr	x23, [x0, #32]
    8a6c:	b4000237 	cbz	x23, 8ab0 <fwp_main_thread+0x640>
    8a70:	38626882 	ldrb	w2, [x4, x2]
    8a74:	7100085f 	cmp	w2, #0x2
    8a78:	54005d00 	b.eq	9618 <fwp_main_thread+0x11a8>  // b.none
    8a7c:	7100045f 	cmp	w2, #0x1
    8a80:	54000181 	b.ne	8ab0 <fwp_main_thread+0x640>  // b.any
    8a84:	29430002 	ldp	w2, w0, [x0, #24]
    8a88:	92403c21 	and	x1, x1, #0xffff
    8a8c:	9b027c21 	mul	x1, x1, x2
    8a90:	d360fc21 	lsr	x1, x1, #32
    8a94:	eb00003f 	cmp	x1, x0
    8a98:	540000c2 	b.cs	8ab0 <fwp_main_thread+0x640>  // b.hs, b.nlast
    8a9c:	8b0102f7 	add	x23, x23, x1
    8aa0:	394002e0 	ldrb	w0, [x23]
    8aa4:	7103fc1f 	cmp	w0, #0xff
    8aa8:	54005c20 	b.eq	962c <fwp_main_thread+0x11bc>  // b.none
    8aac:	390002f3 	strb	w19, [x23]
    8ab0:	f9400fe0 	ldr	x0, [sp, #24]
    8ab4:	f9004fe0 	str	x0, [sp, #152]
    8ab8:	aa1a02c0 	orr	x0, x22, x26
    8abc:	b5fffaa0 	cbnz	x0, 8a10 <fwp_main_thread+0x5a0>
    8ac0:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    8ac4:	91014302 	add	x2, x24, #0x50
    8ac8:	f94043f3 	ldr	x19, [sp, #128]
    8acc:	910343e1 	add	x1, sp, #0xd0
    8ad0:	3dc3dc00 	ldr	q0, [x0, #3952]
    8ad4:	52800020 	mov	w0, #0x1                   	// #1
    8ad8:	f901c853 	str	x19, [x2, #912]
    8adc:	3d8037e0 	str	q0, [sp, #208]
    8ae0:	97fff1ed 	bl	5294 <fwp_data.part.0.constprop.0>
    8ae4:	b0000381 	adrp	x1, 79000 <fwp_root_context+0xbb0>
    8ae8:	9118c021 	add	x1, x1, #0x630
    8aec:	aa0003f5 	mov	x21, x0
    8af0:	f949d822 	ldr	x2, [x1, #5040]
    8af4:	f949ec20 	ldr	x0, [x1, #5080]
    8af8:	cb0202a2 	sub	x2, x21, x2
    8afc:	eb00405f 	cmp	x2, x0, lsl #16
    8b00:	54000322 	b.cs	8b64 <fwp_main_thread+0x6f4>  // b.hs, b.nlast
    8b04:	d350fc40 	lsr	x0, x2, #16
    8b08:	f949fc23 	ldr	x3, [x1, #5112]
    8b0c:	8b000800 	add	x0, x0, x0, lsl #2
    8b10:	d37df001 	lsl	x1, x0, #3
    8b14:	8b010060 	add	x0, x3, x1
    8b18:	f9401016 	ldr	x22, [x0, #32]
    8b1c:	b4000256 	cbz	x22, 8b64 <fwp_main_thread+0x6f4>
    8b20:	38616861 	ldrb	w1, [x3, x1]
    8b24:	7100083f 	cmp	w1, #0x2
    8b28:	5400d0e0 	b.eq	a544 <fwp_main_thread+0x20d4>  // b.none
    8b2c:	7100043f 	cmp	w1, #0x1
    8b30:	540001a1 	b.ne	8b64 <fwp_main_thread+0x6f4>  // b.any
    8b34:	29430003 	ldp	w3, w0, [x0, #24]
    8b38:	92403c41 	and	x1, x2, #0xffff
    8b3c:	9b037c21 	mul	x1, x1, x3
    8b40:	d360fc21 	lsr	x1, x1, #32
    8b44:	eb00003f 	cmp	x1, x0
    8b48:	540000e2 	b.cs	8b64 <fwp_main_thread+0x6f4>  // b.hs, b.nlast
    8b4c:	8b0102d6 	add	x22, x22, x1
    8b50:	394002c0 	ldrb	w0, [x22]
    8b54:	7103fc1f 	cmp	w0, #0xff
    8b58:	5400df60 	b.eq	a744 <fwp_main_thread+0x22d4>  // b.none
    8b5c:	52800020 	mov	w0, #0x1                   	// #1
    8b60:	390002c0 	strb	w0, [x22]
    8b64:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    8b68:	9103c3e1 	add	x1, sp, #0xf0
    8b6c:	52800020 	mov	w0, #0x1                   	// #1
    8b70:	a90f57e2 	stp	x2, x21, [sp, #240]
    8b74:	97fff1c8 	bl	5294 <fwp_data.part.0.constprop.0>
    8b78:	b0000381 	adrp	x1, 79000 <fwp_root_context+0xbb0>
    8b7c:	9118c021 	add	x1, x1, #0x630
    8b80:	aa0003f5 	mov	x21, x0
    8b84:	f949d822 	ldr	x2, [x1, #5040]
    8b88:	f949ec20 	ldr	x0, [x1, #5080]
    8b8c:	cb0202a2 	sub	x2, x21, x2
    8b90:	eb00405f 	cmp	x2, x0, lsl #16
    8b94:	54000322 	b.cs	8bf8 <fwp_main_thread+0x788>  // b.hs, b.nlast
    8b98:	d350fc40 	lsr	x0, x2, #16
    8b9c:	f949fc23 	ldr	x3, [x1, #5112]
    8ba0:	8b000800 	add	x0, x0, x0, lsl #2
    8ba4:	d37df001 	lsl	x1, x0, #3
    8ba8:	8b010060 	add	x0, x3, x1
    8bac:	f9401016 	ldr	x22, [x0, #32]
    8bb0:	b4000256 	cbz	x22, 8bf8 <fwp_main_thread+0x788>
    8bb4:	38616861 	ldrb	w1, [x3, x1]
    8bb8:	7100083f 	cmp	w1, #0x2
    8bbc:	5400cbe0 	b.eq	a538 <fwp_main_thread+0x20c8>  // b.none
    8bc0:	7100043f 	cmp	w1, #0x1
    8bc4:	540001a1 	b.ne	8bf8 <fwp_main_thread+0x788>  // b.any
    8bc8:	29430003 	ldp	w3, w0, [x0, #24]
    8bcc:	92403c41 	and	x1, x2, #0xffff
    8bd0:	9b037c21 	mul	x1, x1, x3
    8bd4:	d360fc21 	lsr	x1, x1, #32
    8bd8:	eb00003f 	cmp	x1, x0
    8bdc:	540000e2 	b.cs	8bf8 <fwp_main_thread+0x788>  // b.hs, b.nlast
    8be0:	8b0102d6 	add	x22, x22, x1
    8be4:	394002c0 	ldrb	w0, [x22]
    8be8:	7103fc1f 	cmp	w0, #0xff
    8bec:	5400de00 	b.eq	a7ac <fwp_main_thread+0x233c>  // b.none
    8bf0:	52800020 	mov	w0, #0x1                   	// #1
    8bf4:	390002c0 	strb	w0, [x22]
    8bf8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    8bfc:	910383e1 	add	x1, sp, #0xe0
    8c00:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    8c04:	52800020 	mov	w0, #0x1                   	// #1
    8c08:	a90e57e2 	stp	x2, x21, [sp, #224]
    8c0c:	97fff1a2 	bl	5294 <fwp_data.part.0.constprop.0>
    8c10:	b0000381 	adrp	x1, 79000 <fwp_root_context+0xbb0>
    8c14:	9118c021 	add	x1, x1, #0x630
    8c18:	aa0003f5 	mov	x21, x0
    8c1c:	f949d822 	ldr	x2, [x1, #5040]
    8c20:	f949ec20 	ldr	x0, [x1, #5080]
    8c24:	cb0202a2 	sub	x2, x21, x2
    8c28:	eb00405f 	cmp	x2, x0, lsl #16
    8c2c:	54000322 	b.cs	8c90 <fwp_main_thread+0x820>  // b.hs, b.nlast
    8c30:	d350fc40 	lsr	x0, x2, #16
    8c34:	f949fc23 	ldr	x3, [x1, #5112]
    8c38:	8b000800 	add	x0, x0, x0, lsl #2
    8c3c:	d37df001 	lsl	x1, x0, #3
    8c40:	8b010060 	add	x0, x3, x1
    8c44:	f9401016 	ldr	x22, [x0, #32]
    8c48:	b4000256 	cbz	x22, 8c90 <fwp_main_thread+0x820>
    8c4c:	38616861 	ldrb	w1, [x3, x1]
    8c50:	7100083f 	cmp	w1, #0x2
    8c54:	5400c7e0 	b.eq	a550 <fwp_main_thread+0x20e0>  // b.none
    8c58:	7100043f 	cmp	w1, #0x1
    8c5c:	540001a1 	b.ne	8c90 <fwp_main_thread+0x820>  // b.any
    8c60:	29430003 	ldp	w3, w0, [x0, #24]
    8c64:	92403c41 	and	x1, x2, #0xffff
    8c68:	9b037c21 	mul	x1, x1, x3
    8c6c:	d360fc21 	lsr	x1, x1, #32
    8c70:	eb00003f 	cmp	x1, x0
    8c74:	540000e2 	b.cs	8c90 <fwp_main_thread+0x820>  // b.hs, b.nlast
    8c78:	8b0102d6 	add	x22, x22, x1
    8c7c:	394002c0 	ldrb	w0, [x22]
    8c80:	7103fc1f 	cmp	w0, #0xff
    8c84:	5400d9a0 	b.eq	a7b8 <fwp_main_thread+0x2348>  // b.none
    8c88:	52800020 	mov	w0, #0x1                   	// #1
    8c8c:	390002c0 	strb	w0, [x22]
    8c90:	f9400fe0 	ldr	x0, [sp, #24]
    8c94:	b400cde0 	cbz	x0, a650 <fwp_main_thread+0x21e0>
    8c98:	900000c0 	adrp	x0, 20000 <__data_start>
    8c9c:	91004000 	add	x0, x0, #0x10
    8ca0:	91008000 	add	x0, x0, #0x20
    8ca4:	f90023e0 	str	x0, [sp, #64]
    8ca8:	f9400fe0 	ldr	x0, [sp, #24]
    8cac:	f9002fe0 	str	x0, [sp, #88]
    8cb0:	910183e0 	add	x0, sp, #0x60
    8cb4:	f90017e0 	str	x0, [sp, #40]
    8cb8:	9101a3e0 	add	x0, sp, #0x68
    8cbc:	f9001be0 	str	x0, [sp, #48]
    8cc0:	b0000380 	adrp	x0, 79000 <fwp_root_context+0xbb0>
    8cc4:	9118c01c 	add	x28, x0, #0x630
    8cc8:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    8ccc:	fd47c008 	ldr	d8, [x0, #3968]
    8cd0:	f949ef87 	ldr	x7, [x28, #5080]
    8cd4:	f949db83 	ldr	x3, [x28, #5040]
    8cd8:	d370bce7 	lsl	x7, x7, #16
    8cdc:	cb0302a2 	sub	x2, x21, x3
    8ce0:	eb07005f 	cmp	x2, x7
    8ce4:	54000442 	b.cs	8d6c <fwp_main_thread+0x8fc>  // b.hs, b.nlast
    8ce8:	d350fc40 	lsr	x0, x2, #16
    8cec:	f949ff86 	ldr	x6, [x28, #5112]
    8cf0:	8b000800 	add	x0, x0, x0, lsl #2
    8cf4:	d37df001 	lsl	x1, x0, #3
    8cf8:	8b0100c5 	add	x5, x6, x1
    8cfc:	f94010a0 	ldr	x0, [x5, #32]
    8d00:	b4000360 	cbz	x0, 8d6c <fwp_main_thread+0x8fc>
    8d04:	386168c1 	ldrb	w1, [x6, x1]
    8d08:	7100083f 	cmp	w1, #0x2
    8d0c:	5400b9c0 	b.eq	a444 <fwp_main_thread+0x1fd4>  // b.none
    8d10:	7100043f 	cmp	w1, #0x1
    8d14:	540002c1 	b.ne	8d6c <fwp_main_thread+0x8fc>  // b.any
    8d18:	92403c41 	and	x1, x2, #0xffff
    8d1c:	294308a6 	ldp	w6, w2, [x5, #24]
    8d20:	9b067c21 	mul	x1, x1, x6
    8d24:	d360fc21 	lsr	x1, x1, #32
    8d28:	eb02003f 	cmp	x1, x2
    8d2c:	54000202 	b.cs	8d6c <fwp_main_thread+0x8fc>  // b.hs, b.nlast
    8d30:	8b010000 	add	x0, x0, x1
    8d34:	39400001 	ldrb	w1, [x0]
    8d38:	340001a1 	cbz	w1, 8d6c <fwp_main_thread+0x8fc>
    8d3c:	91014302 	add	x2, x24, #0x50
    8d40:	b9413043 	ldr	w3, [x2, #304]
    8d44:	3500bf23 	cbnz	w3, a528 <fwp_main_thread+0x20b8>
    8d48:	7103f43f 	cmp	w1, #0xfd
    8d4c:	5400ce28 	b.hi	a710 <fwp_main_thread+0x22a0>  // b.pmore
    8d50:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    8d54:	9118c042 	add	x2, x2, #0x630
    8d58:	11000421 	add	w1, w1, #0x1
    8d5c:	39000001 	strb	w1, [x0]
    8d60:	f949ec47 	ldr	x7, [x2, #5080]
    8d64:	f949d843 	ldr	x3, [x2, #5040]
    8d68:	d370bce7 	lsl	x7, x7, #16
    8d6c:	f94023e1 	ldr	x1, [sp, #64]
    8d70:	91014300 	add	x0, x24, #0x50
    8d74:	12800002 	mov	w2, #0xffffffff            	// #-1
    8d78:	b90063e2 	str	w2, [sp, #96]
    8d7c:	cb030023 	sub	x3, x1, x3
    8d80:	d0ffffe1 	adrp	x1, 6000 <fwp_drop1+0xf0>
    8d84:	910fc021 	add	x1, x1, #0x3f0
    8d88:	a90687f3 	stp	x19, x1, [sp, #104]
    8d8c:	f94017e1 	ldr	x1, [sp, #40]
    8d90:	f9003fe1 	str	x1, [sp, #120]
    8d94:	f9401be1 	ldr	x1, [sp, #48]
    8d98:	f901c801 	str	x1, [x0, #912]
    8d9c:	eb0300ff 	cmp	x7, x3
    8da0:	54000809 	b.ls	8ea0 <fwp_main_thread+0xa30>  // b.plast
    8da4:	d350fc60 	lsr	x0, x3, #16
    8da8:	f949ff85 	ldr	x5, [x28, #5112]
    8dac:	8b000800 	add	x0, x0, x0, lsl #2
    8db0:	d37df002 	lsl	x2, x0, #3
    8db4:	8b0200a1 	add	x1, x5, x2
    8db8:	f9401033 	ldr	x19, [x1, #32]
    8dbc:	b4000733 	cbz	x19, 8ea0 <fwp_main_thread+0xa30>
    8dc0:	386268a0 	ldrb	w0, [x5, x2]
    8dc4:	7100081f 	cmp	w0, #0x2
    8dc8:	5400a2e0 	b.eq	a224 <fwp_main_thread+0x1db4>  // b.none
    8dcc:	7100041f 	cmp	w0, #0x1
    8dd0:	54000681 	b.ne	8ea0 <fwp_main_thread+0xa30>  // b.any
    8dd4:	29430825 	ldp	w5, w2, [x1, #24]
    8dd8:	92403c60 	and	x0, x3, #0xffff
    8ddc:	9b057c00 	mul	x0, x0, x5
    8de0:	d360fc00 	lsr	x0, x0, #32
    8de4:	eb02001f 	cmp	x0, x2
    8de8:	54000342 	b.cs	8e50 <fwp_main_thread+0x9e0>  // b.hs, b.nlast
    8dec:	8b000260 	add	x0, x19, x0
    8df0:	39400002 	ldrb	w2, [x0]
    8df4:	340002e2 	cbz	w2, 8e50 <fwp_main_thread+0x9e0>
    8df8:	91014301 	add	x1, x24, #0x50
    8dfc:	b9413023 	ldr	w3, [x1, #304]
    8e00:	34000083 	cbz	w3, 8e10 <fwp_main_thread+0x9a0>
    8e04:	f940ac23 	ldr	x3, [x1, #344]
    8e08:	91000463 	add	x3, x3, #0x1
    8e0c:	f900ac23 	str	x3, [x1, #344]
    8e10:	7103f45f 	cmp	w2, #0xfd
    8e14:	5400c148 	b.hi	a63c <fwp_main_thread+0x21cc>  // b.pmore
    8e18:	11000442 	add	w2, w2, #0x1
    8e1c:	39000002 	strb	w2, [x0]
    8e20:	f94023e1 	ldr	x1, [sp, #64]
    8e24:	f949db83 	ldr	x3, [x28, #5040]
    8e28:	f949ef80 	ldr	x0, [x28, #5080]
    8e2c:	cb030023 	sub	x3, x1, x3
    8e30:	eb00407f 	cmp	x3, x0, lsl #16
    8e34:	54000362 	b.cs	8ea0 <fwp_main_thread+0xa30>  // b.hs, b.nlast
    8e38:	f949ff80 	ldr	x0, [x28, #5112]
    8e3c:	d350fc61 	lsr	x1, x3, #16
    8e40:	8b010821 	add	x1, x1, x1, lsl #2
    8e44:	8b010c01 	add	x1, x0, x1, lsl #3
    8e48:	f9401033 	ldr	x19, [x1, #32]
    8e4c:	b40002b3 	cbz	x19, 8ea0 <fwp_main_thread+0xa30>
    8e50:	39400020 	ldrb	w0, [x1]
    8e54:	7100081f 	cmp	w0, #0x2
    8e58:	54009d00 	b.eq	a1f8 <fwp_main_thread+0x1d88>  // b.none
    8e5c:	7100041f 	cmp	w0, #0x1
    8e60:	54000201 	b.ne	8ea0 <fwp_main_thread+0xa30>  // b.any
    8e64:	29430022 	ldp	w2, w0, [x1, #24]
    8e68:	92403c63 	and	x3, x3, #0xffff
    8e6c:	9b027c61 	mul	x1, x3, x2
    8e70:	d360fc21 	lsr	x1, x1, #32
    8e74:	eb00003f 	cmp	x1, x0
    8e78:	54000142 	b.cs	8ea0 <fwp_main_thread+0xa30>  // b.hs, b.nlast
    8e7c:	8b010273 	add	x19, x19, x1
    8e80:	39400261 	ldrb	w1, [x19]
    8e84:	340000e1 	cbz	w1, 8ea0 <fwp_main_thread+0xa30>
    8e88:	7100043f 	cmp	w1, #0x1
    8e8c:	54008580 	b.eq	9f3c <fwp_main_thread+0x1acc>  // b.none
    8e90:	7103fc3f 	cmp	w1, #0xff
    8e94:	5400ba60 	b.eq	a5e0 <fwp_main_thread+0x2170>  // b.none
    8e98:	51000421 	sub	w1, w1, #0x1
    8e9c:	39000261 	strb	w1, [x19]
    8ea0:	b40085f5 	cbz	x21, 9f5c <fwp_main_thread+0x1aec>
    8ea4:	aa1503e0 	mov	x0, x21
    8ea8:	d2800001 	mov	x1, #0x0                   	// #0
    8eac:	d503201f 	nop
    8eb0:	f9400800 	ldr	x0, [x0, #16]
    8eb4:	91000421 	add	x1, x1, #0x1
    8eb8:	b5ffffc0 	cbnz	x0, 8eb0 <fwp_main_thread+0xa40>
    8ebc:	aa0103f7 	mov	x23, x1
    8ec0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    8ec4:	eb00003f 	cmp	x1, x0
    8ec8:	5400cbe8 	b.hi	a844 <fwp_main_thread+0x23d4>  // b.pmore
    8ecc:	91014313 	add	x19, x24, #0x50
    8ed0:	b943ca60 	ldr	w0, [x19, #968]
    8ed4:	340084e0 	cbz	w0, 9f70 <fwp_main_thread+0x1b00>
    8ed8:	91014300 	add	x0, x24, #0x50
    8edc:	f9406c13 	ldr	x19, [x0, #216]
    8ee0:	f940b016 	ldr	x22, [x0, #352]
    8ee4:	eb1302df 	cmp	x22, x19
    8ee8:	54007eea 	b.ge	9ec4 <fwp_main_thread+0x1a54>  // b.tcont
    8eec:	f9404401 	ldr	x1, [x0, #136]
    8ef0:	8b1606c0 	add	x0, x22, x22, lsl #1
    8ef4:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8ef8:	8b000ac0 	add	x0, x22, x0, lsl #2
    8efc:	8b000c20 	add	x0, x1, x0, lsl #3
    8f00:	b9400401 	ldr	w1, [x0, #4]
    8f04:	35000081 	cbnz	w1, 8f14 <fwp_main_thread+0xaa4>
    8f08:	b9400001 	ldr	w1, [x0]
    8f0c:	6b02003f 	cmp	w1, w2
    8f10:	54007da9 	b.ls	9ec4 <fwp_main_thread+0x1a54>  // b.plast
    8f14:	910006d6 	add	x22, x22, #0x1
    8f18:	9101a000 	add	x0, x0, #0x68
    8f1c:	eb1302df 	cmp	x22, x19
    8f20:	54ffff01 	b.ne	8f00 <fwp_main_thread+0xa90>  // b.any
    8f24:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8f28:	eb00027f 	cmp	x19, x0
    8f2c:	5400c7ac 	b.gt	a820 <fwp_main_thread+0x23b0>
    8f30:	91014300 	add	x0, x24, #0x50
    8f34:	f9409001 	ldr	x1, [x0, #288]
    8f38:	f9404419 	ldr	x25, [x0, #136]
    8f3c:	eb13003f 	cmp	x1, x19
    8f40:	54000221 	b.ne	8f84 <fwp_main_thread+0xb14>  // b.any
    8f44:	b400a633 	cbz	x19, a408 <fwp_main_thread+0x1f98>
    8f48:	d37ffa76 	lsl	x22, x19, #1
    8f4c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8f50:	eb0002df 	cmp	x22, x0
    8f54:	9a80d2d6 	csel	x22, x22, x0, le
    8f58:	8b1606c1 	add	x1, x22, x22, lsl #1
    8f5c:	8b010ac1 	add	x1, x22, x1, lsl #2
    8f60:	d37df021 	lsl	x1, x1, #3
    8f64:	aa1903e0 	mov	x0, x25
    8f68:	52800002 	mov	w2, #0x0                   	// #0
    8f6c:	97ffed3a 	bl	4454 <ad_raw_realloc>
    8f70:	aa0003f9 	mov	x25, x0
    8f74:	b40038c0 	cbz	x0, 968c <fwp_main_thread+0x121c>
    8f78:	91014300 	add	x0, x24, #0x50
    8f7c:	f9004419 	str	x25, [x0, #136]
    8f80:	f9009016 	str	x22, [x0, #288]
    8f84:	aa1303f6 	mov	x22, x19
    8f88:	8b130660 	add	x0, x19, x19, lsl #1
    8f8c:	4f000400 	movi	v0.4s, #0x0
    8f90:	91014301 	add	x1, x24, #0x50
    8f94:	8b1606da 	add	x26, x22, x22, lsl #1
    8f98:	8b000a60 	add	x0, x19, x0, lsl #2
    8f9c:	91000673 	add	x19, x19, #0x1
    8fa0:	8b1a0ada 	add	x26, x22, x26, lsl #2
    8fa4:	8b000f20 	add	x0, x25, x0, lsl #3
    8fa8:	f9006c33 	str	x19, [x1, #216]
    8fac:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    8fb0:	ad000000 	stp	q0, q0, [x0]
    8fb4:	ad010000 	stp	q0, q0, [x0, #32]
    8fb8:	ad020000 	stp	q0, q0, [x0, #64]
    8fbc:	f900301f 	str	xzr, [x0, #96]
    8fc0:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    8fc4:	f900335f 	str	xzr, [x26, #96]
    8fc8:	910e4000 	add	x0, x0, #0x390
    8fcc:	97ffe699 	bl	2a30 <getenv@plt>
    8fd0:	b4007920 	cbz	x0, 9ef4 <fwp_main_thread+0x1a84>
    8fd4:	39400001 	ldrb	w1, [x0]
    8fd8:	7100c03f 	cmp	w1, #0x30
    8fdc:	540078c1 	b.ne	9ef4 <fwp_main_thread+0x1a84>  // b.any
    8fe0:	39400400 	ldrb	w0, [x0, #1]
    8fe4:	35007880 	cbnz	w0, 9ef4 <fwp_main_thread+0x1a84>
    8fe8:	91014300 	add	x0, x24, #0x50
    8fec:	2f000400 	mvni	v0.2s, #0x0
    8ff0:	b9400353 	ldr	w19, [x26]
    8ff4:	52800022 	mov	w2, #0x1                   	// #1
    8ff8:	910006c6 	add	x6, x22, #0x1
    8ffc:	a900df57 	stp	x23, x23, [x26, #8]
    9000:	0b020273 	add	w19, w19, w2
    9004:	f941c801 	ldr	x1, [x0, #912]
    9008:	29000b53 	stp	w19, w2, [x26]
    900c:	f9002b5f 	str	xzr, [x26, #80]
    9010:	f900b006 	str	x6, [x0, #352]
    9014:	fd002f40 	str	d0, [x26, #88]
    9018:	b400c1c1 	cbz	x1, a850 <fwp_main_thread+0x23e0>
    901c:	b0ffffe0 	adrp	x0, 6000 <fwp_drop1+0xf0>
    9020:	910fc003 	add	x3, x0, #0x3f0
    9024:	14000003 	b	9030 <fwp_main_thread+0xbc0>
    9028:	f9400021 	ldr	x1, [x1]
    902c:	b400c121 	cbz	x1, a850 <fwp_main_thread+0x23e0>
    9030:	f9400422 	ldr	x2, [x1, #8]
    9034:	eb03005f 	cmp	x2, x3
    9038:	54ffff81 	b.ne	9028 <fwp_main_thread+0xbb8>  // b.any
    903c:	f9400820 	ldr	x0, [x1, #16]
    9040:	2a1603e2 	mov	w2, w22
    9044:	b9400001 	ldr	w1, [x0]
    9048:	f9002b40 	str	x0, [x26, #80]
    904c:	b9005f41 	str	w1, [x26, #92]
    9050:	37f80081 	tbnz	w1, #31, 9060 <fwp_main_thread+0xbf0>
    9054:	52800d03 	mov	w3, #0x68                  	// #104
    9058:	9b236421 	smaddl	x1, w1, w3, x25
    905c:	b9005836 	str	w22, [x1, #88]
    9060:	b9000002 	str	w2, [x0]
    9064:	d3707e73 	ubfiz	x19, x19, #16, #32
    9068:	aa060273 	orr	x19, x19, x6
    906c:	aa1503e0 	mov	x0, x21
    9070:	d2800002 	mov	x2, #0x0                   	// #0
    9074:	b4007eb5 	cbz	x21, a048 <fwp_main_thread+0x1bd8>
    9078:	f9400800 	ldr	x0, [x0, #16]
    907c:	91000442 	add	x2, x2, #0x1
    9080:	b5ffffc0 	cbnz	x0, 9078 <fwp_main_thread+0xc08>
    9084:	aa1503e1 	mov	x1, x21
    9088:	f9400821 	ldr	x1, [x1, #16]
    908c:	91000400 	add	x0, x0, #0x1
    9090:	b5ffffc1 	cbnz	x1, 9088 <fwp_main_thread+0xc18>
    9094:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9098:	eb01001f 	cmp	x0, x1
    909c:	5400b9a8 	b.hi	a7d0 <fwp_main_thread+0x2360>  // b.pmore
    90a0:	f100005f 	cmp	x2, #0x0
    90a4:	54007d2d 	b.le	a048 <fwp_main_thread+0x1bd8>
    90a8:	eb00005f 	cmp	x2, x0
    90ac:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    90b0:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    90b4:	eb0102df 	cmp	x22, x1
    90b8:	5400b8c8 	b.hi	a7d0 <fwp_main_thread+0x2360>  // b.pmore
    90bc:	d37ffac2 	lsl	x2, x22, #1
    90c0:	52800041 	mov	w1, #0x2                   	// #2
    90c4:	91000440 	add	x0, x2, #0x1
    90c8:	aa0203f9 	mov	x25, x2
    90cc:	d37df000 	lsl	x0, x0, #3
    90d0:	97fff010 	bl	5110 <fwp_heap_alloc>
    90d4:	f9000019 	str	x25, [x0]
    90d8:	aa0003f7 	mov	x23, x0
    90dc:	aa0003fa 	mov	x26, x0
    90e0:	f949db81 	ldr	x1, [x28, #5040]
    90e4:	f949ef80 	ldr	x0, [x28, #5080]
    90e8:	cb0102e1 	sub	x1, x23, x1
    90ec:	eb00403f 	cmp	x1, x0, lsl #16
    90f0:	54007dc2 	b.cs	a0a8 <fwp_main_thread+0x1c38>  // b.hs, b.nlast
    90f4:	d350fc20 	lsr	x0, x1, #16
    90f8:	f949ff85 	ldr	x5, [x28, #5112]
    90fc:	8b000800 	add	x0, x0, x0, lsl #2
    9100:	d37df002 	lsl	x2, x0, #3
    9104:	8b0200a3 	add	x3, x5, x2
    9108:	f9401079 	ldr	x25, [x3, #32]
    910c:	b4000259 	cbz	x25, 9154 <fwp_main_thread+0xce4>
    9110:	386268a2 	ldrb	w2, [x5, x2]
    9114:	7100085f 	cmp	w2, #0x2
    9118:	54008760 	b.eq	a204 <fwp_main_thread+0x1d94>  // b.none
    911c:	7100045f 	cmp	w2, #0x1
    9120:	540001a1 	b.ne	9154 <fwp_main_thread+0xce4>  // b.any
    9124:	29430865 	ldp	w5, w2, [x3, #24]
    9128:	92403c21 	and	x1, x1, #0xffff
    912c:	9b057c21 	mul	x1, x1, x5
    9130:	d360fc21 	lsr	x1, x1, #32
    9134:	eb02003f 	cmp	x1, x2
    9138:	540000e2 	b.cs	9154 <fwp_main_thread+0xce4>  // b.hs, b.nlast
    913c:	8b010339 	add	x25, x25, x1
    9140:	39400321 	ldrb	w1, [x25]
    9144:	7103fc3f 	cmp	w1, #0xff
    9148:	54008680 	b.eq	a218 <fwp_main_thread+0x1da8>  // b.none
    914c:	52800021 	mov	w1, #0x1                   	// #1
    9150:	39000321 	strb	w1, [x25]
    9154:	b4000236 	cbz	x22, 9198 <fwp_main_thread+0xd28>
    9158:	d3607e65 	lsl	x5, x19, #32
    915c:	aa1503e1 	mov	x1, x21
    9160:	f94006a6 	ldr	x6, [x21, #8]
    9164:	aa0503e3 	mov	x3, x5
    9168:	910022e2 	add	x2, x23, #0x8
    916c:	d2800000 	mov	x0, #0x0                   	// #0
    9170:	14000005 	b	9184 <fwp_main_thread+0xd14>
    9174:	f9400426 	ldr	x6, [x1, #8]
    9178:	ab050003 	adds	x3, x0, x5
    917c:	91004042 	add	x2, x2, #0x10
    9180:	5400b746 	b.vs	a868 <fwp_main_thread+0x23f8>
    9184:	a9000c46 	stp	x6, x3, [x2]
    9188:	91000400 	add	x0, x0, #0x1
    918c:	f9400821 	ldr	x1, [x1, #16]
    9190:	eb16001f 	cmp	x0, x22
    9194:	54ffff03 	b.cc	9174 <fwp_main_thread+0xd04>  // b.lo, b.ul, b.last
    9198:	f94002e0 	ldr	x0, [x23]
    919c:	f100041f 	cmp	x0, #0x1
    91a0:	54007889 	b.ls	a0b0 <fwp_main_thread+0x1c40>  // b.plast
    91a4:	d341fc00 	lsr	x0, x0, #1
    91a8:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    91ac:	d1000401 	sub	x1, x0, #0x1
    91b0:	eb02003f 	cmp	x1, x2
    91b4:	5400b0e8 	b.hi	a7d0 <fwp_main_thread+0x2360>  // b.pmore
    91b8:	d37ff839 	lsl	x25, x1, #1
    91bc:	b40077a1 	cbz	x1, a0b0 <fwp_main_thread+0x1c40>
    91c0:	d10022e1 	sub	x1, x23, #0x8
    91c4:	910022fb 	add	x27, x23, #0x8
    91c8:	8b001036 	add	x22, x1, x0, lsl #4
    91cc:	d503201f 	nop
    91d0:	f9400760 	ldr	x0, [x27, #8]
    91d4:	f9400f61 	ldr	x1, [x27, #24]
    91d8:	fd400360 	ldr	d0, [x27]
    91dc:	fd400b61 	ldr	d1, [x27, #16]
    91e0:	97fff170 	bl	57a0 <w120>
    91e4:	a9000760 	stp	x0, x1, [x27]
    91e8:	9100437b 	add	x27, x27, #0x10
    91ec:	eb16037f 	cmp	x27, x22
    91f0:	54ffff01 	b.ne	91d0 <fwp_main_thread+0xd60>  // b.any
    91f4:	f90002f9 	str	x25, [x23]
    91f8:	aa1703e0 	mov	x0, x23
    91fc:	97fff1c6 	bl	5914 <w176.constprop.0>
    9200:	aa0103e5 	mov	x5, x1
    9204:	f949db80 	ldr	x0, [x28, #5040]
    9208:	f949ef82 	ldr	x2, [x28, #5080]
    920c:	cb0002e1 	sub	x1, x23, x0
    9210:	eb02403f 	cmp	x1, x2, lsl #16
    9214:	540003a2 	b.cs	9288 <fwp_main_thread+0xe18>  // b.hs, b.nlast
    9218:	d350fc20 	lsr	x0, x1, #16
    921c:	f949ff86 	ldr	x6, [x28, #5112]
    9220:	8b000800 	add	x0, x0, x0, lsl #2
    9224:	d37df000 	lsl	x0, x0, #3
    9228:	8b0000c2 	add	x2, x6, x0
    922c:	f9401056 	ldr	x22, [x2, #32]
    9230:	b40002d6 	cbz	x22, 9288 <fwp_main_thread+0xe18>
    9234:	386068c0 	ldrb	w0, [x6, x0]
    9238:	7100081f 	cmp	w0, #0x2
    923c:	540073e0 	b.eq	a0b8 <fwp_main_thread+0x1c48>  // b.none
    9240:	7100041f 	cmp	w0, #0x1
    9244:	54000221 	b.ne	9288 <fwp_main_thread+0xe18>  // b.any
    9248:	29430043 	ldp	w3, w0, [x2, #24]
    924c:	92403c21 	and	x1, x1, #0xffff
    9250:	9b037c21 	mul	x1, x1, x3
    9254:	d360fc21 	lsr	x1, x1, #32
    9258:	eb00003f 	cmp	x1, x0
    925c:	54000162 	b.cs	9288 <fwp_main_thread+0xe18>  // b.hs, b.nlast
    9260:	8b0102d6 	add	x22, x22, x1
    9264:	394002c0 	ldrb	w0, [x22]
    9268:	34000100 	cbz	w0, 9288 <fwp_main_thread+0xe18>
    926c:	7100041f 	cmp	w0, #0x1
    9270:	54002260 	b.eq	96bc <fwp_main_thread+0x124c>  // b.none
    9274:	7103fc1f 	cmp	w0, #0xff
    9278:	54008ec0 	b.eq	a450 <fwp_main_thread+0x1fe0>  // b.none
    927c:	51000400 	sub	w0, w0, #0x1
    9280:	390002c0 	strb	w0, [x22]
    9284:	d503201f 	nop
    9288:	93407e73 	sxtw	x19, w19
    928c:	f9000be5 	str	x5, [sp, #16]
    9290:	aa1303e0 	mov	x0, x19
    9294:	97ffea27 	bl	3b30 <fwp_tape_of>
    9298:	f9403001 	ldr	x1, [x0, #96]
    929c:	aa0003eb 	mov	x11, x0
    92a0:	f9400be5 	ldr	x5, [sp, #16]
    92a4:	b500adc1 	cbnz	x1, a85c <fwp_main_thread+0x23ec>
    92a8:	97ffe75b 	bl	3014 <fwp_tape_unlink_scope>
    92ac:	b9400002 	ldr	w2, [x0]
    92b0:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    92b4:	a940801a 	ldp	x26, x0, [x0, #8]
    92b8:	b900057f 	str	wzr, [x11, #4]
    92bc:	a941ed63 	ldp	x3, x27, [x11, #24]
    92c0:	a942a568 	ldp	x8, x9, [x11, #40]
    92c4:	a943e56a 	ldp	x10, x25, [x11, #56]
    92c8:	f9402577 	ldr	x23, [x11, #72]
    92cc:	6b01005f 	cmp	w2, w1
    92d0:	54000108 	b.hi	92f0 <fwp_main_thread+0xe80>  // b.pmore
    92d4:	91014302 	add	x2, x24, #0x50
    92d8:	92403e61 	and	x1, x19, #0xffff
    92dc:	d1000421 	sub	x1, x1, #0x1
    92e0:	f940b04c 	ldr	x12, [x2, #352]
    92e4:	eb0c003f 	cmp	x1, x12
    92e8:	5400004a 	b.ge	92f0 <fwp_main_thread+0xe80>  // b.tcont
    92ec:	f900b041 	str	x1, [x2, #352]
    92f0:	4f000400 	movi	v0.4s, #0x0
    92f4:	91014302 	add	x2, x24, #0x50
    92f8:	f0ffffc1 	adrp	x1, 4000 <fwp_heap_report+0x60>
    92fc:	91149021 	add	x1, x1, #0x524
    9300:	f9000d7f 	str	xzr, [x11, #24]
    9304:	a9047d7f 	stp	xzr, xzr, [x11, #64]
    9308:	3c808160 	stur	q0, [x11, #8]
    930c:	ad010160 	stp	q0, q0, [x11, #32]
    9310:	f941c84b 	ldr	x11, [x2, #912]
    9314:	a90807eb 	stp	x11, x1, [sp, #128]
    9318:	f94007e1 	ldr	x1, [sp, #8]
    931c:	f9004be1 	str	x1, [sp, #144]
    9320:	f94013e1 	ldr	x1, [sp, #32]
    9324:	a909a3fb 	stp	x27, x8, [sp, #152]
    9328:	a90aabe9 	stp	x9, x10, [sp, #168]
    932c:	a90b8ff9 	stp	x25, x3, [sp, #184]
    9330:	f90067f7 	str	x23, [sp, #200]
    9334:	f901c841 	str	x1, [x2, #912]
    9338:	b7f877e5 	tbnz	x5, #63, a234 <fwp_main_thread+0x1dc4>
    933c:	eb85827f 	cmp	x19, x5, asr #32
    9340:	54009f61 	b.ne	a72c <fwp_main_thread+0x22bc>  // b.any
    9344:	92407cb6 	and	x22, x5, #0xffffffff
    9348:	eb25401f 	cmp	x0, w5, uxtw
    934c:	54009f6d 	b.le	a738 <fwp_main_thread+0x22c8>
    9350:	eb1a02df 	cmp	x22, x26
    9354:	9a96b756 	csinc	x22, x26, x22, lt	// lt = tstop
    9358:	eb1602ff 	cmp	x23, x22
    935c:	5400184a 	b.ge	9664 <fwp_main_thread+0x11f4>  // b.tcont
    9360:	f10002ff 	cmp	x23, #0x0
    9364:	9a9612f7 	csel	x23, x23, x22, ne	// ne = any
    9368:	14000005 	b	937c <fwp_main_thread+0xf0c>
    936c:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    9370:	eb0002ff 	cmp	x23, x0
    9374:	d37ffaf7 	lsl	x23, x23, #1
    9378:	9a96d2f7 	csel	x23, x23, x22, le
    937c:	eb1602ff 	cmp	x23, x22
    9380:	54ffff6b 	b.lt	936c <fwp_main_thread+0xefc>  // b.tstop
    9384:	b4007dd9 	cbz	x25, a33c <fwp_main_thread+0x1ecc>
    9388:	aa1903e0 	mov	x0, x25
    938c:	d37df2e1 	lsl	x1, x23, #3
    9390:	52800062 	mov	w2, #0x3                   	// #3
    9394:	f9000be5 	str	x5, [sp, #16]
    9398:	f9001fe8 	str	x8, [sp, #56]
    939c:	a904abe9 	stp	x9, x10, [sp, #72]
    93a0:	97ffec2d 	bl	4454 <ad_raw_realloc>
    93a4:	aa0003f9 	mov	x25, x0
    93a8:	f9400be5 	ldr	x5, [sp, #16]
    93ac:	f9401fe8 	ldr	x8, [sp, #56]
    93b0:	a944abe9 	ldp	x9, x10, [sp, #72]
    93b4:	b4007b00 	cbz	x0, a314 <fwp_main_thread+0x1ea4>
    93b8:	f9005ff9 	str	x25, [sp, #184]
    93bc:	f90067f7 	str	x23, [sp, #200]
    93c0:	b50013d6 	cbnz	x22, 9638 <fwp_main_thread+0x11c8>
    93c4:	b7f800c5 	tbnz	x5, #63, 93dc <fwp_main_thread+0xf6c>
    93c8:	92407ca1 	and	x1, x5, #0xffffffff
    93cc:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    93d0:	fc617b20 	ldr	d0, [x25, x1, lsl #3]
    93d4:	1e612800 	fadd	d0, d0, d1
    93d8:	fc217b20 	str	d0, [x25, x1, lsl #3]
    93dc:	d10006d6 	sub	x22, x22, #0x1
    93e0:	d1000743 	sub	x3, x26, #0x1
    93e4:	eb16035f 	cmp	x26, x22
    93e8:	540003ac 	b.gt	945c <fwp_main_thread+0xfec>
    93ec:	fc767b20 	ldr	d0, [x25, x22, lsl #3]
    93f0:	1e602008 	fcmp	d0, #0.0
    93f4:	540002e0 	b.eq	9450 <fwp_main_thread+0xfe0>  // b.none
    93f8:	cb1a0be0 	neg	x0, x26, lsl #2
    93fc:	cb1a03e2 	neg	x2, x26
    9400:	8b000361 	add	x1, x27, x0
    9404:	b8767821 	ldr	w1, [x1, x22, lsl #2]
    9408:	37f80101 	tbnz	w1, #31, 9428 <fwp_main_thread+0xfb8>
    940c:	8b020d25 	add	x5, x9, x2, lsl #3
    9410:	93407c21 	sxtw	x1, w1
    9414:	fc7678a2 	ldr	d2, [x5, x22, lsl #3]
    9418:	fc617b21 	ldr	d1, [x25, x1, lsl #3]
    941c:	1e620802 	fmul	d2, d0, d2
    9420:	1e622821 	fadd	d1, d1, d2
    9424:	fc217b21 	str	d1, [x25, x1, lsl #3]
    9428:	8b000100 	add	x0, x8, x0
    942c:	b8767800 	ldr	w0, [x0, x22, lsl #2]
    9430:	37f80100 	tbnz	w0, #31, 9450 <fwp_main_thread+0xfe0>
    9434:	8b020d42 	add	x2, x10, x2, lsl #3
    9438:	93407c00 	sxtw	x0, w0
    943c:	fc767842 	ldr	d2, [x2, x22, lsl #3]
    9440:	fc607b21 	ldr	d1, [x25, x0, lsl #3]
    9444:	1e620800 	fmul	d0, d0, d2
    9448:	1e602820 	fadd	d0, d1, d0
    944c:	fc207b20 	str	d0, [x25, x0, lsl #3]
    9450:	d10006d6 	sub	x22, x22, #0x1
    9454:	eb16007f 	cmp	x3, x22
    9458:	54fffca1 	b.ne	93ec <fwp_main_thread+0xf7c>  // b.any
    945c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9460:	eb00035f 	cmp	x26, x0
    9464:	54009bc8 	b.hi	a7dc <fwp_main_thread+0x236c>  // b.pmore
    9468:	91000740 	add	x0, x26, #0x1
    946c:	52800041 	mov	w1, #0x2                   	// #2
    9470:	d37df000 	lsl	x0, x0, #3
    9474:	97ffef27 	bl	5110 <fwp_heap_alloc>
    9478:	aa0003e2 	mov	x2, x0
    947c:	aa0003f6 	mov	x22, x0
    9480:	d2800001 	mov	x1, #0x0                   	// #0
    9484:	f800845a 	str	x26, [x2], #8
    9488:	b40000fa 	cbz	x26, 94a4 <fwp_main_thread+0x1034>
    948c:	d503201f 	nop
    9490:	f8617b20 	ldr	x0, [x25, x1, lsl #3]
    9494:	f8217840 	str	x0, [x2, x1, lsl #3]
    9498:	91000421 	add	x1, x1, #0x1
    949c:	eb01035f 	cmp	x26, x1
    94a0:	54ffff81 	b.ne	9490 <fwp_main_thread+0x1020>  // b.any
    94a4:	f94007e0 	ldr	x0, [sp, #8]
    94a8:	91014301 	add	x1, x24, #0x50
    94ac:	f94043f7 	ldr	x23, [sp, #128]
    94b0:	f901c837 	str	x23, [x1, #912]
    94b4:	97ffec1c 	bl	4524 <fwp_tape_buffers_release>
    94b8:	f949db81 	ldr	x1, [x28, #5040]
    94bc:	f949ef80 	ldr	x0, [x28, #5080]
    94c0:	cb0102c1 	sub	x1, x22, x1
    94c4:	eb00403f 	cmp	x1, x0, lsl #16
    94c8:	54000322 	b.cs	952c <fwp_main_thread+0x10bc>  // b.hs, b.nlast
    94cc:	d350fc20 	lsr	x0, x1, #16
    94d0:	f949ff83 	ldr	x3, [x28, #5112]
    94d4:	8b000800 	add	x0, x0, x0, lsl #2
    94d8:	d37df002 	lsl	x2, x0, #3
    94dc:	8b020060 	add	x0, x3, x2
    94e0:	f9401013 	ldr	x19, [x0, #32]
    94e4:	b4000253 	cbz	x19, 952c <fwp_main_thread+0x10bc>
    94e8:	38626862 	ldrb	w2, [x3, x2]
    94ec:	7100085f 	cmp	w2, #0x2
    94f0:	54006a60 	b.eq	a23c <fwp_main_thread+0x1dcc>  // b.none
    94f4:	7100045f 	cmp	w2, #0x1
    94f8:	540001a1 	b.ne	952c <fwp_main_thread+0x10bc>  // b.any
    94fc:	29430002 	ldp	w2, w0, [x0, #24]
    9500:	92403c21 	and	x1, x1, #0xffff
    9504:	9b027c21 	mul	x1, x1, x2
    9508:	d360fc21 	lsr	x1, x1, #32
    950c:	eb00003f 	cmp	x1, x0
    9510:	540000e2 	b.cs	952c <fwp_main_thread+0x10bc>  // b.hs, b.nlast
    9514:	8b010273 	add	x19, x19, x1
    9518:	39400260 	ldrb	w0, [x19]
    951c:	7103fc1f 	cmp	w0, #0xff
    9520:	54006980 	b.eq	a250 <fwp_main_thread+0x1de0>  // b.none
    9524:	52800020 	mov	w0, #0x1                   	// #1
    9528:	39000260 	strb	w0, [x19]
    952c:	f9401be0 	ldr	x0, [sp, #48]
    9530:	eb0002ff 	cmp	x23, x0
    9534:	54008c41 	b.ne	a6bc <fwp_main_thread+0x224c>  // b.any
    9538:	f94017e0 	ldr	x0, [sp, #40]
    953c:	91014301 	add	x1, x24, #0x50
    9540:	f94037e2 	ldr	x2, [sp, #104]
    9544:	f901c822 	str	x2, [x1, #912]
    9548:	97fff3aa 	bl	63f0 <fwp_tape_scope_release>
    954c:	f94002c0 	ldr	x0, [x22]
    9550:	9240f81a 	and	x26, x0, #0x7fffffffffffffff
    9554:	b7f85220 	tbnz	x0, #63, 9f98 <fwp_main_thread+0x1b28>
    9558:	f949db80 	ldr	x0, [x28, #5040]
    955c:	f949ef81 	ldr	x1, [x28, #5080]
    9560:	cb0002c0 	sub	x0, x22, x0
    9564:	eb01401f 	cmp	x0, x1, lsl #16
    9568:	54005182 	b.cs	9f98 <fwp_main_thread+0x1b28>  // b.hs, b.nlast
    956c:	d350fc01 	lsr	x1, x0, #16
    9570:	f949ff85 	ldr	x5, [x28, #5112]
    9574:	8b010821 	add	x1, x1, x1, lsl #2
    9578:	d37df021 	lsl	x1, x1, #3
    957c:	8b0100a3 	add	x3, x5, x1
    9580:	f9401062 	ldr	x2, [x3, #32]
    9584:	b40050a2 	cbz	x2, 9f98 <fwp_main_thread+0x1b28>
    9588:	386168a1 	ldrb	w1, [x5, x1]
    958c:	7100083f 	cmp	w1, #0x2
    9590:	54004fe0 	b.eq	9f8c <fwp_main_thread+0x1b1c>  // b.none
    9594:	7100043f 	cmp	w1, #0x1
    9598:	54005001 	b.ne	9f98 <fwp_main_thread+0x1b28>  // b.any
    959c:	29430465 	ldp	w5, w1, [x3, #24]
    95a0:	92403c00 	and	x0, x0, #0xffff
    95a4:	9b057c00 	mul	x0, x0, x5
    95a8:	d360fc00 	lsr	x0, x0, #32
    95ac:	eb01001f 	cmp	x0, x1
    95b0:	54004f42 	b.cs	9f98 <fwp_main_thread+0x1b28>  // b.hs, b.nlast
    95b4:	8b000042 	add	x2, x2, x0
    95b8:	39400040 	ldrb	w0, [x2]
    95bc:	7100041f 	cmp	w0, #0x1
    95c0:	54004ec1 	b.ne	9f98 <fwp_main_thread+0x1b28>  // b.any
    95c4:	aa1603f7 	mov	x23, x22
    95c8:	aa1603f3 	mov	x19, x22
    95cc:	d2800000 	mov	x0, #0x0                   	// #0
    95d0:	91002263 	add	x3, x19, #0x8
    95d4:	910022c6 	add	x6, x22, #0x8
    95d8:	d2800001 	mov	x1, #0x0                   	// #0
    95dc:	b500015a 	cbnz	x26, 9604 <fwp_main_thread+0x1194>
    95e0:	1400005a 	b	9748 <fwp_main_thread+0x12d8>
    95e4:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    95e8:	f94002e2 	ldr	x2, [x23]
    95ec:	1e600900 	fmul	d0, d8, d0
    95f0:	b7f88ea2 	tbnz	x2, #63, a7c4 <fwp_main_thread+0x2354>
    95f4:	91000421 	add	x1, x1, #0x1
    95f8:	fc008460 	str	d0, [x3], #8
    95fc:	eb01035f 	cmp	x26, x1
    9600:	54000a40 	b.eq	9748 <fwp_main_thread+0x12d8>  // b.none
    9604:	f94002c5 	ldr	x5, [x22]
    9608:	aa0603e2 	mov	x2, x6
    960c:	b6fffec5 	tbz	x5, #63, 95e4 <fwp_main_thread+0x1174>
    9610:	f9400ac2 	ldr	x2, [x22, #16]
    9614:	17fffff4 	b	95e4 <fwp_main_thread+0x1174>
    9618:	72003c3f 	tst	w1, #0xffff
    961c:	54ffa4a1 	b.ne	8ab0 <fwp_main_thread+0x640>  // b.any
    9620:	394002e0 	ldrb	w0, [x23]
    9624:	7103fc1f 	cmp	w0, #0xff
    9628:	54ffa421 	b.ne	8aac <fwp_main_thread+0x63c>  // b.any
    962c:	aa1703e0 	mov	x0, x23
    9630:	97ffecf8 	bl	4a10 <fwp_rc_forget_slot>
    9634:	17fffd1e 	b	8aac <fwp_main_thread+0x63c>
    9638:	d37df2c2 	lsl	x2, x22, #3
    963c:	aa1903e0 	mov	x0, x25
    9640:	52800001 	mov	w1, #0x0                   	// #0
    9644:	f9000be5 	str	x5, [sp, #16]
    9648:	f9001fe8 	str	x8, [sp, #56]
    964c:	a904abe9 	stp	x9, x10, [sp, #72]
    9650:	97ffe488 	bl	2870 <memset@plt>
    9654:	f9400be5 	ldr	x5, [sp, #16]
    9658:	f9401fe8 	ldr	x8, [sp, #56]
    965c:	a944abe9 	ldp	x9, x10, [sp, #72]
    9660:	17ffff59 	b	93c4 <fwp_main_thread+0xf54>
    9664:	f100033f 	cmp	x25, #0x0
    9668:	1a9f17e0 	cset	w0, eq	// eq = none
    966c:	f10002df 	cmp	x22, #0x0
    9670:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    9674:	54ffea60 	b.eq	93c0 <fwp_main_thread+0xf50>  // b.none
    9678:	f94007e0 	ldr	x0, [sp, #8]
    967c:	91014318 	add	x24, x24, #0x50
    9680:	f94043e1 	ldr	x1, [sp, #128]
    9684:	f901cb01 	str	x1, [x24, #912]
    9688:	97ffeba7 	bl	4524 <fwp_tape_buffers_release>
    968c:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    9690:	f947e863 	ldr	x3, [x3, #4048]
    9694:	d2800262 	mov	x2, #0x13                  	// #19
    9698:	d2800021 	mov	x1, #0x1                   	// #1
    969c:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1b90>
    96a0:	913e6000 	add	x0, x0, #0xf98
    96a4:	f9400063 	ldr	x3, [x3]
    96a8:	97ffe4be 	bl	29a0 <fwrite@plt>
    96ac:	d2800000 	mov	x0, #0x0                   	// #0
    96b0:	97ffe4c8 	bl	29d0 <fflush@plt>
    96b4:	52800cc0 	mov	w0, #0x66                  	// #102
    96b8:	97ffe4d6 	bl	2a10 <_Exit@plt>
    96bc:	f9400347 	ldr	x7, [x26]
    96c0:	aa1a03e0 	mov	x0, x26
    96c4:	f949ef83 	ldr	x3, [x28, #5080]
    96c8:	f949db81 	ldr	x1, [x28, #5040]
    96cc:	d370bc63 	lsl	x3, x3, #16
    96d0:	cb010342 	sub	x2, x26, x1
    96d4:	b7f84fe7 	tbnz	x7, #63, a0d0 <fwp_main_thread+0x1c60>
    96d8:	eb03005f 	cmp	x2, x3
    96dc:	54ffdd62 	b.cs	9288 <fwp_main_thread+0xe18>  // b.hs, b.nlast
    96e0:	d350fc40 	lsr	x0, x2, #16
    96e4:	8b000800 	add	x0, x0, x0, lsl #2
    96e8:	d37df000 	lsl	x0, x0, #3
    96ec:	8b0000c3 	add	x3, x6, x0
    96f0:	f9401061 	ldr	x1, [x3, #32]
    96f4:	b4ffdca1 	cbz	x1, 9288 <fwp_main_thread+0xe18>
    96f8:	386068c0 	ldrb	w0, [x6, x0]
    96fc:	7100081f 	cmp	w0, #0x2
    9700:	54005ae0 	b.eq	a25c <fwp_main_thread+0x1dec>  // b.none
    9704:	7100041f 	cmp	w0, #0x1
    9708:	54ffdc01 	b.ne	9288 <fwp_main_thread+0xe18>  // b.any
    970c:	92403c40 	and	x0, x2, #0xffff
    9710:	29430866 	ldp	w6, w2, [x3, #24]
    9714:	9b067c00 	mul	x0, x0, x6
    9718:	d360fc00 	lsr	x0, x0, #32
    971c:	eb02001f 	cmp	x0, x2
    9720:	54ffdb42 	b.cs	9288 <fwp_main_thread+0xe18>  // b.hs, b.nlast
    9724:	8b000021 	add	x1, x1, x0
    9728:	39400020 	ldrb	w0, [x1]
    972c:	7100041f 	cmp	w0, #0x1
    9730:	54ffdac1 	b.ne	9288 <fwp_main_thread+0xe18>  // b.any
    9734:	aa1a03e0 	mov	x0, x26
    9738:	f9000be5 	str	x5, [sp, #16]
    973c:	97ffed55 	bl	4c90 <fwp_mem_free>
    9740:	f9400be5 	ldr	x5, [sp, #16]
    9744:	17fffed1 	b	9288 <fwp_main_thread+0xe18>
    9748:	97fff516 	bl	6ba0 <fwp_drop10>
    974c:	aa1503e1 	mov	x1, x21
    9750:	d2800002 	mov	x2, #0x0                   	// #0
    9754:	b4006455 	cbz	x21, a3dc <fwp_main_thread+0x1f6c>
    9758:	f9400821 	ldr	x1, [x1, #16]
    975c:	91000442 	add	x2, x2, #0x1
    9760:	b5ffffc1 	cbnz	x1, 9758 <fwp_main_thread+0x12e8>
    9764:	f94002e0 	ldr	x0, [x23]
    9768:	9240f803 	and	x3, x0, #0x7fffffffffffffff
    976c:	b7f83700 	tbnz	x0, #63, 9e4c <fwp_main_thread+0x19dc>
    9770:	f949db81 	ldr	x1, [x28, #5040]
    9774:	f949ef85 	ldr	x5, [x28, #5080]
    9778:	cb010261 	sub	x1, x19, x1
    977c:	eb05403f 	cmp	x1, x5, lsl #16
    9780:	54003662 	b.cs	9e4c <fwp_main_thread+0x19dc>  // b.hs, b.nlast
    9784:	d350fc25 	lsr	x5, x1, #16
    9788:	f949ff88 	ldr	x8, [x28, #5112]
    978c:	8b0508a5 	add	x5, x5, x5, lsl #2
    9790:	d37df0a5 	lsl	x5, x5, #3
    9794:	8b050107 	add	x7, x8, x5
    9798:	f94010e6 	ldr	x6, [x7, #32]
    979c:	b4003566 	cbz	x6, 9e48 <fwp_main_thread+0x19d8>
    97a0:	38656905 	ldrb	w5, [x8, x5]
    97a4:	710008bf 	cmp	w5, #0x2
    97a8:	540034c0 	b.eq	9e40 <fwp_main_thread+0x19d0>  // b.none
    97ac:	710004bf 	cmp	w5, #0x1
    97b0:	540034c1 	b.ne	9e48 <fwp_main_thread+0x19d8>  // b.any
    97b4:	294314e8 	ldp	w8, w5, [x7, #24]
    97b8:	92403c21 	and	x1, x1, #0xffff
    97bc:	9b087c21 	mul	x1, x1, x8
    97c0:	d360fc21 	lsr	x1, x1, #32
    97c4:	eb05003f 	cmp	x1, x5
    97c8:	54003402 	b.cs	9e48 <fwp_main_thread+0x19d8>  // b.hs, b.nlast
    97cc:	8b0100c6 	add	x6, x6, x1
    97d0:	394000d6 	ldrb	w22, [x6]
    97d4:	710006df 	cmp	w22, #0x1
    97d8:	54003381 	b.ne	9e48 <fwp_main_thread+0x19d8>  // b.any
    97dc:	b90013f6 	str	w22, [sp, #16]
    97e0:	eb03005f 	cmp	x2, x3
    97e4:	9a839043 	csel	x3, x2, x3, ls	// ls = plast
    97e8:	910022fa 	add	x26, x23, #0x8
    97ec:	b4006f23 	cbz	x3, a5d0 <fwp_main_thread+0x2160>
    97f0:	d37df067 	lsl	x7, x3, #3
    97f4:	aa1503e2 	mov	x2, x21
    97f8:	91002266 	add	x6, x19, #0x8
    97fc:	d2800001 	mov	x1, #0x0                   	// #0
    9800:	1400000a 	b	9828 <fwp_main_thread+0x13b8>
    9804:	fc6168a1 	ldr	d1, [x5, x1]
    9808:	fd400440 	ldr	d0, [x2, #8]
    980c:	1e613800 	fsub	d0, d0, d1
    9810:	fc216b40 	str	d0, [x26, x1]
    9814:	91002021 	add	x1, x1, #0x8
    9818:	f9400842 	ldr	x2, [x2, #16]
    981c:	eb07003f 	cmp	x1, x7
    9820:	540001a0 	b.eq	9854 <fwp_main_thread+0x13e4>  // b.none
    9824:	f94002e0 	ldr	x0, [x23]
    9828:	aa0603e5 	mov	x5, x6
    982c:	b6fffec0 	tbz	x0, #63, 9804 <fwp_main_thread+0x1394>
    9830:	f9400a65 	ldr	x5, [x19, #16]
    9834:	fd400440 	ldr	d0, [x2, #8]
    9838:	fc6168a1 	ldr	d1, [x5, x1]
    983c:	1e613800 	fsub	d0, d0, d1
    9840:	fc216b40 	str	d0, [x26, x1]
    9844:	91002021 	add	x1, x1, #0x8
    9848:	f9400842 	ldr	x2, [x2, #16]
    984c:	eb07003f 	cmp	x1, x7
    9850:	54fffea1 	b.ne	9824 <fwp_main_thread+0x13b4>  // b.any
    9854:	b4007375 	cbz	x21, a6c0 <fwp_main_thread+0x2250>
    9858:	f949ef89 	ldr	x9, [x28, #5080]
    985c:	aa1503e2 	mov	x2, x21
    9860:	f949db8a 	ldr	x10, [x28, #5040]
    9864:	d2800016 	mov	x22, #0x0                   	// #0
    9868:	f949ff88 	ldr	x8, [x28, #5112]
    986c:	d370bd29 	lsl	x9, x9, #16
    9870:	14000006 	b	9888 <fwp_main_thread+0x1418>
    9874:	f9400842 	ldr	x2, [x2, #16]
    9878:	910006d6 	add	x22, x22, #0x1
    987c:	f100005f 	cmp	x2, #0x0
    9880:	fa561060 	ccmp	x3, x22, #0x0, ne	// ne = any
    9884:	54003dc9 	b.ls	a03c <fwp_main_thread+0x1bcc>  // b.plast
    9888:	cb0a0040 	sub	x0, x2, x10
    988c:	eb09001f 	cmp	x0, x9
    9890:	540002c2 	b.cs	98e8 <fwp_main_thread+0x1478>  // b.hs, b.nlast
    9894:	d350fc01 	lsr	x1, x0, #16
    9898:	8b010821 	add	x1, x1, x1, lsl #2
    989c:	d37df021 	lsl	x1, x1, #3
    98a0:	8b010107 	add	x7, x8, x1
    98a4:	f94010e6 	ldr	x6, [x7, #32]
    98a8:	b4000206 	cbz	x6, 98e8 <fwp_main_thread+0x1478>
    98ac:	38616901 	ldrb	w1, [x8, x1]
    98b0:	7100083f 	cmp	w1, #0x2
    98b4:	54000dc0 	b.eq	9a6c <fwp_main_thread+0x15fc>  // b.none
    98b8:	7100043f 	cmp	w1, #0x1
    98bc:	54000161 	b.ne	98e8 <fwp_main_thread+0x1478>  // b.any
    98c0:	294304eb 	ldp	w11, w1, [x7, #24]
    98c4:	92403c00 	and	x0, x0, #0xffff
    98c8:	9b0b7c00 	mul	x0, x0, x11
    98cc:	d360fc00 	lsr	x0, x0, #32
    98d0:	eb01001f 	cmp	x0, x1
    98d4:	540000a2 	b.cs	98e8 <fwp_main_thread+0x1478>  // b.hs, b.nlast
    98d8:	8b0000c6 	add	x6, x6, x0
    98dc:	394000c0 	ldrb	w0, [x6]
    98e0:	7100041f 	cmp	w0, #0x1
    98e4:	54fffc80 	b.eq	9874 <fwp_main_thread+0x1404>  // b.none
    98e8:	eb0302df 	cmp	x22, x3
    98ec:	54000ca2 	b.cs	9a80 <fwp_main_thread+0x1610>  // b.hs, b.nlast
    98f0:	aa0303f9 	mov	x25, x3
    98f4:	d100235b 	sub	x27, x26, #0x8
    98f8:	d2800017 	mov	x23, #0x0                   	// #0
    98fc:	14000012 	b	9944 <fwp_main_thread+0x14d4>
    9900:	7100045f 	cmp	w2, #0x1
    9904:	540001a1 	b.ne	9938 <fwp_main_thread+0x14c8>  // b.any
    9908:	294308e8 	ldp	w8, w2, [x7, #24]
    990c:	92403c21 	and	x1, x1, #0xffff
    9910:	9b087c21 	mul	x1, x1, x8
    9914:	d360fc21 	lsr	x1, x1, #32
    9918:	eb02003f 	cmp	x1, x2
    991c:	540000e2 	b.cs	9938 <fwp_main_thread+0x14c8>  // b.hs, b.nlast
    9920:	8b010000 	add	x0, x0, x1
    9924:	39400001 	ldrb	w1, [x0]
    9928:	7103fc3f 	cmp	w1, #0xff
    992c:	54003b60 	b.eq	a098 <fwp_main_thread+0x1c28>  // b.none
    9930:	52800021 	mov	w1, #0x1                   	// #1
    9934:	39000001 	strb	w1, [x0]
    9938:	d1000739 	sub	x25, x25, #0x1
    993c:	eb1902df 	cmp	x22, x25
    9940:	54000382 	b.cs	99b0 <fwp_main_thread+0x1540>  // b.hs, b.nlast
    9944:	f8797b62 	ldr	x2, [x27, x25, lsl #3]
    9948:	aa1403e1 	mov	x1, x20
    994c:	52800020 	mov	w0, #0x1                   	// #1
    9950:	a9105fe2 	stp	x2, x23, [sp, #256]
    9954:	97ffee50 	bl	5294 <fwp_data.part.0.constprop.0>
    9958:	aa0003f7 	mov	x23, x0
    995c:	f949db81 	ldr	x1, [x28, #5040]
    9960:	f949ef80 	ldr	x0, [x28, #5080]
    9964:	cb0102e1 	sub	x1, x23, x1
    9968:	eb00403f 	cmp	x1, x0, lsl #16
    996c:	54fffe62 	b.cs	9938 <fwp_main_thread+0x14c8>  // b.hs, b.nlast
    9970:	d350fc20 	lsr	x0, x1, #16
    9974:	f949ff88 	ldr	x8, [x28, #5112]
    9978:	8b000800 	add	x0, x0, x0, lsl #2
    997c:	d37df002 	lsl	x2, x0, #3
    9980:	8b020107 	add	x7, x8, x2
    9984:	f94010e0 	ldr	x0, [x7, #32]
    9988:	b4fffd80 	cbz	x0, 9938 <fwp_main_thread+0x14c8>
    998c:	38626902 	ldrb	w2, [x8, x2]
    9990:	7100085f 	cmp	w2, #0x2
    9994:	54fffb61 	b.ne	9900 <fwp_main_thread+0x1490>  // b.any
    9998:	72003c3f 	tst	w1, #0xffff
    999c:	54fffc40 	b.eq	9924 <fwp_main_thread+0x14b4>  // b.none
    99a0:	d1000739 	sub	x25, x25, #0x1
    99a4:	eb1902df 	cmp	x22, x25
    99a8:	54fffce3 	b.cc	9944 <fwp_main_thread+0x14d4>  // b.lo, b.ul, b.last
    99ac:	d503201f 	nop
    99b0:	b50006b6 	cbnz	x22, 9a84 <fwp_main_thread+0x1614>
    99b4:	b94013e0 	ldr	w0, [sp, #16]
    99b8:	d2800036 	mov	x22, #0x1                   	// #1
    99bc:	d2800003 	mov	x3, #0x0                   	// #0
    99c0:	7100001f 	cmp	w0, #0x0
    99c4:	9a9f035a 	csel	x26, x26, xzr, eq	// eq = none
    99c8:	b40004e3 	cbz	x3, 9a64 <fwp_main_thread+0x15f4>
    99cc:	d100047b 	sub	x27, x3, #0x1
    99d0:	f87b7b42 	ldr	x2, [x26, x27, lsl #3]
    99d4:	aa1403e1 	mov	x1, x20
    99d8:	52800020 	mov	w0, #0x1                   	// #1
    99dc:	a9105fe2 	stp	x2, x23, [sp, #256]
    99e0:	97ffee2d 	bl	5294 <fwp_data.part.0.constprop.0>
    99e4:	aa0003f7 	mov	x23, x0
    99e8:	f949db81 	ldr	x1, [x28, #5040]
    99ec:	f949ef80 	ldr	x0, [x28, #5080]
    99f0:	cb0102e1 	sub	x1, x23, x1
    99f4:	eb00403f 	cmp	x1, x0, lsl #16
    99f8:	54000302 	b.cs	9a58 <fwp_main_thread+0x15e8>  // b.hs, b.nlast
    99fc:	d350fc22 	lsr	x2, x1, #16
    9a00:	f949ff86 	ldr	x6, [x28, #5112]
    9a04:	8b020842 	add	x2, x2, x2, lsl #2
    9a08:	d37df042 	lsl	x2, x2, #3
    9a0c:	8b0200c5 	add	x5, x6, x2
    9a10:	f94010b9 	ldr	x25, [x5, #32]
    9a14:	b4000239 	cbz	x25, 9a58 <fwp_main_thread+0x15e8>
    9a18:	386268c2 	ldrb	w2, [x6, x2]
    9a1c:	7100085f 	cmp	w2, #0x2
    9a20:	540020a0 	b.eq	9e34 <fwp_main_thread+0x19c4>  // b.none
    9a24:	7100045f 	cmp	w2, #0x1
    9a28:	54000181 	b.ne	9a58 <fwp_main_thread+0x15e8>  // b.any
    9a2c:	294308a6 	ldp	w6, w2, [x5, #24]
    9a30:	92403c21 	and	x1, x1, #0xffff
    9a34:	9b067c21 	mul	x1, x1, x6
    9a38:	d360fc21 	lsr	x1, x1, #32
    9a3c:	eb02003f 	cmp	x1, x2
    9a40:	540000c2 	b.cs	9a58 <fwp_main_thread+0x15e8>  // b.hs, b.nlast
    9a44:	8b010339 	add	x25, x25, x1
    9a48:	39400321 	ldrb	w1, [x25]
    9a4c:	7103fc3f 	cmp	w1, #0xff
    9a50:	54001ec0 	b.eq	9e28 <fwp_main_thread+0x19b8>  // b.none
    9a54:	39000336 	strb	w22, [x25]
    9a58:	d100077b 	sub	x27, x27, #0x1
    9a5c:	b100077f 	cmn	x27, #0x1
    9a60:	54fffb81 	b.ne	99d0 <fwp_main_thread+0x1560>  // b.any
    9a64:	aa1503e1 	mov	x1, x21
    9a68:	14000015 	b	9abc <fwp_main_thread+0x164c>
    9a6c:	72003c1f 	tst	w0, #0xffff
    9a70:	54fff360 	b.eq	98dc <fwp_main_thread+0x146c>  // b.none
    9a74:	eb0302df 	cmp	x22, x3
    9a78:	54fff3c3 	b.cc	98f0 <fwp_main_thread+0x1480>  // b.lo, b.ul, b.last
    9a7c:	d503201f 	nop
    9a80:	d2800017 	mov	x23, #0x0                   	// #0
    9a84:	8b160f45 	add	x5, x26, x22, lsl #3
    9a88:	aa1a03e0 	mov	x0, x26
    9a8c:	aa1503e1 	mov	x1, x21
    9a90:	f8408402 	ldr	x2, [x0], #8
    9a94:	f9000422 	str	x2, [x1, #8]
    9a98:	aa0103e2 	mov	x2, x1
    9a9c:	f9400821 	ldr	x1, [x1, #16]
    9aa0:	eb05001f 	cmp	x0, x5
    9aa4:	54ffff61 	b.ne	9a90 <fwp_main_thread+0x1620>  // b.any
    9aa8:	b94013e0 	ldr	w0, [sp, #16]
    9aac:	f9000857 	str	x23, [x2, #16]
    9ab0:	aa1503f7 	mov	x23, x21
    9ab4:	7100001f 	cmp	w0, #0x0
    9ab8:	9a9f035a 	csel	x26, x26, xzr, eq	// eq = none
    9abc:	aa1a03e0 	mov	x0, x26
    9ac0:	f9000be1 	str	x1, [sp, #16]
    9ac4:	97ffec73 	bl	4c90 <fwp_mem_free>
    9ac8:	f949ef83 	ldr	x3, [x28, #5080]
    9acc:	f949db82 	ldr	x2, [x28, #5040]
    9ad0:	d370bc63 	lsl	x3, x3, #16
    9ad4:	cb020265 	sub	x5, x19, x2
    9ad8:	f9400be1 	ldr	x1, [sp, #16]
    9adc:	eb0300bf 	cmp	x5, x3
    9ae0:	540003e2 	b.cs	9b5c <fwp_main_thread+0x16ec>  // b.hs, b.nlast
    9ae4:	d350fca0 	lsr	x0, x5, #16
    9ae8:	f949ff86 	ldr	x6, [x28, #5112]
    9aec:	8b000800 	add	x0, x0, x0, lsl #2
    9af0:	d37df000 	lsl	x0, x0, #3
    9af4:	8b0000c3 	add	x3, x6, x0
    9af8:	f9401076 	ldr	x22, [x3, #32]
    9afc:	b40002b6 	cbz	x22, 9b50 <fwp_main_thread+0x16e0>
    9b00:	386068c2 	ldrb	w2, [x6, x0]
    9b04:	7100085f 	cmp	w2, #0x2
    9b08:	54002de0 	b.eq	a0c4 <fwp_main_thread+0x1c54>  // b.none
    9b0c:	7100045f 	cmp	w2, #0x1
    9b10:	54000201 	b.ne	9b50 <fwp_main_thread+0x16e0>  // b.any
    9b14:	29430c67 	ldp	w7, w3, [x3, #24]
    9b18:	92403ca2 	and	x2, x5, #0xffff
    9b1c:	9b077c42 	mul	x2, x2, x7
    9b20:	d360fc42 	lsr	x2, x2, #32
    9b24:	eb03005f 	cmp	x2, x3
    9b28:	54000142 	b.cs	9b50 <fwp_main_thread+0x16e0>  // b.hs, b.nlast
    9b2c:	8b0202d6 	add	x22, x22, x2
    9b30:	394002c2 	ldrb	w2, [x22]
    9b34:	340000e2 	cbz	w2, 9b50 <fwp_main_thread+0x16e0>
    9b38:	7100045f 	cmp	w2, #0x1
    9b3c:	540012a0 	b.eq	9d90 <fwp_main_thread+0x1920>  // b.none
    9b40:	7103fc5f 	cmp	w2, #0xff
    9b44:	54004bc0 	b.eq	a4bc <fwp_main_thread+0x204c>  // b.none
    9b48:	51000442 	sub	w2, w2, #0x1
    9b4c:	390002c2 	strb	w2, [x22]
    9b50:	f949ef83 	ldr	x3, [x28, #5080]
    9b54:	f949db82 	ldr	x2, [x28, #5040]
    9b58:	d370bc63 	lsl	x3, x3, #16
    9b5c:	cb020022 	sub	x2, x1, x2
    9b60:	eb03005f 	cmp	x2, x3
    9b64:	540003a2 	b.cs	9bd8 <fwp_main_thread+0x1768>  // b.hs, b.nlast
    9b68:	d350fc40 	lsr	x0, x2, #16
    9b6c:	f949ff85 	ldr	x5, [x28, #5112]
    9b70:	8b000800 	add	x0, x0, x0, lsl #2
    9b74:	d37df000 	lsl	x0, x0, #3
    9b78:	8b0000a3 	add	x3, x5, x0
    9b7c:	f9401073 	ldr	x19, [x3, #32]
    9b80:	b40002d3 	cbz	x19, 9bd8 <fwp_main_thread+0x1768>
    9b84:	386068a6 	ldrb	w6, [x5, x0]
    9b88:	710008df 	cmp	w6, #0x2
    9b8c:	54002e60 	b.eq	a158 <fwp_main_thread+0x1ce8>  // b.none
    9b90:	710004df 	cmp	w6, #0x1
    9b94:	54000221 	b.ne	9bd8 <fwp_main_thread+0x1768>  // b.any
    9b98:	29430c66 	ldp	w6, w3, [x3, #24]
    9b9c:	92403c42 	and	x2, x2, #0xffff
    9ba0:	9b067c42 	mul	x2, x2, x6
    9ba4:	d360fc42 	lsr	x2, x2, #32
    9ba8:	eb03005f 	cmp	x2, x3
    9bac:	54000162 	b.cs	9bd8 <fwp_main_thread+0x1768>  // b.hs, b.nlast
    9bb0:	8b020273 	add	x19, x19, x2
    9bb4:	39400262 	ldrb	w2, [x19]
    9bb8:	34000102 	cbz	w2, 9bd8 <fwp_main_thread+0x1768>
    9bbc:	7100045f 	cmp	w2, #0x1
    9bc0:	54003540 	b.eq	a268 <fwp_main_thread+0x1df8>  // b.none
    9bc4:	7103fc5f 	cmp	w2, #0xff
    9bc8:	54004d60 	b.eq	a574 <fwp_main_thread+0x2104>  // b.none
    9bcc:	51000442 	sub	w2, w2, #0x1
    9bd0:	39000262 	strb	w2, [x19]
    9bd4:	d503201f 	nop
    9bd8:	f94007e0 	ldr	x0, [sp, #8]
    9bdc:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10d18>
    9be0:	910ac042 	add	x2, x2, #0x2b0
    9be4:	aa1703e1 	mov	x1, x23
    9be8:	91014042 	add	x2, x2, #0x50
    9bec:	52800023 	mov	w3, #0x1                   	// #1
    9bf0:	a909ffff 	stp	xzr, xzr, [sp, #152]
    9bf4:	f90057ff 	str	xzr, [sp, #168]
    9bf8:	97fff623 	bl	7484 <fwp_write>
    9bfc:	a949ebf6 	ldp	x22, x26, [sp, #152]
    9c00:	b0000000 	adrp	x0, a000 <fwp_main_thread+0x1b90>
    9c04:	913f4000 	add	x0, x0, #0xfd0
    9c08:	f10002df 	cmp	x22, #0x0
    9c0c:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9c10:	b1002b5f 	cmn	x26, #0xa
    9c14:	54005fa8 	b.hi	a808 <fwp_main_thread+0x2398>  // b.pmore
    9c18:	91002740 	add	x0, x26, #0x9
    9c1c:	52800021 	mov	w1, #0x1                   	// #1
    9c20:	97ffed3c 	bl	5110 <fwp_heap_alloc>
    9c24:	aa0003f3 	mov	x19, x0
    9c28:	aa1603e1 	mov	x1, x22
    9c2c:	aa0003f6 	mov	x22, x0
    9c30:	aa1a03e2 	mov	x2, x26
    9c34:	f80086da 	str	x26, [x22], #8
    9c38:	8b1a027a 	add	x26, x19, x26
    9c3c:	aa1603e0 	mov	x0, x22
    9c40:	97ffe2ac 	bl	26f0 <memcpy@plt>
    9c44:	3900235f 	strb	wzr, [x26, #8]
    9c48:	f9404fe0 	ldr	x0, [sp, #152]
    9c4c:	97ffe345 	bl	2960 <free@plt>
    9c50:	f949db82 	ldr	x2, [x28, #5040]
    9c54:	f949ef80 	ldr	x0, [x28, #5080]
    9c58:	cb020262 	sub	x2, x19, x2
    9c5c:	eb00405f 	cmp	x2, x0, lsl #16
    9c60:	54000322 	b.cs	9cc4 <fwp_main_thread+0x1854>  // b.hs, b.nlast
    9c64:	d350fc40 	lsr	x0, x2, #16
    9c68:	f949ff83 	ldr	x3, [x28, #5112]
    9c6c:	8b000800 	add	x0, x0, x0, lsl #2
    9c70:	d37df001 	lsl	x1, x0, #3
    9c74:	8b010060 	add	x0, x3, x1
    9c78:	f940101a 	ldr	x26, [x0, #32]
    9c7c:	b400025a 	cbz	x26, 9cc4 <fwp_main_thread+0x1854>
    9c80:	38616861 	ldrb	w1, [x3, x1]
    9c84:	7100083f 	cmp	w1, #0x2
    9c88:	54004700 	b.eq	a568 <fwp_main_thread+0x20f8>  // b.none
    9c8c:	7100043f 	cmp	w1, #0x1
    9c90:	540001a1 	b.ne	9cc4 <fwp_main_thread+0x1854>  // b.any
    9c94:	29430003 	ldp	w3, w0, [x0, #24]
    9c98:	92403c41 	and	x1, x2, #0xffff
    9c9c:	9b037c21 	mul	x1, x1, x3
    9ca0:	d360fc21 	lsr	x1, x1, #32
    9ca4:	eb00003f 	cmp	x1, x0
    9ca8:	540000e2 	b.cs	9cc4 <fwp_main_thread+0x1854>  // b.hs, b.nlast
    9cac:	8b01035a 	add	x26, x26, x1
    9cb0:	39400340 	ldrb	w0, [x26]
    9cb4:	7103fc1f 	cmp	w0, #0xff
    9cb8:	54005080 	b.eq	a6c8 <fwp_main_thread+0x2258>  // b.none
    9cbc:	52800020 	mov	w0, #0x1                   	// #1
    9cc0:	39000340 	strb	w0, [x26]
    9cc4:	aa1703e0 	mov	x0, x23
    9cc8:	97fff03e 	bl	5dc0 <fwp_drop0>
    9ccc:	91014303 	add	x3, x24, #0x50
    9cd0:	aa1603e0 	mov	x0, x22
    9cd4:	f9400262 	ldr	x2, [x19]
    9cd8:	aa0303f6 	mov	x22, x3
    9cdc:	f9404863 	ldr	x3, [x3, #144]
    9ce0:	d2800021 	mov	x1, #0x1                   	// #1
    9ce4:	97ffe32f 	bl	29a0 <fwrite@plt>
    9ce8:	f9404ac1 	ldr	x1, [x22, #144]
    9cec:	52800140 	mov	w0, #0xa                   	// #10
    9cf0:	97ffe2b4 	bl	27c0 <fputc@plt>
    9cf4:	f949db82 	ldr	x2, [x28, #5040]
    9cf8:	f949ef80 	ldr	x0, [x28, #5080]
    9cfc:	cb020262 	sub	x2, x19, x2
    9d00:	eb00405f 	cmp	x2, x0, lsl #16
    9d04:	54000382 	b.cs	9d74 <fwp_main_thread+0x1904>  // b.hs, b.nlast
    9d08:	d350fc40 	lsr	x0, x2, #16
    9d0c:	f949ff83 	ldr	x3, [x28, #5112]
    9d10:	8b000800 	add	x0, x0, x0, lsl #2
    9d14:	d37df001 	lsl	x1, x0, #3
    9d18:	8b010060 	add	x0, x3, x1
    9d1c:	f9401016 	ldr	x22, [x0, #32]
    9d20:	b40002b6 	cbz	x22, 9d74 <fwp_main_thread+0x1904>
    9d24:	38616861 	ldrb	w1, [x3, x1]
    9d28:	7100083f 	cmp	w1, #0x2
    9d2c:	54004180 	b.eq	a55c <fwp_main_thread+0x20ec>  // b.none
    9d30:	7100043f 	cmp	w1, #0x1
    9d34:	54000201 	b.ne	9d74 <fwp_main_thread+0x1904>  // b.any
    9d38:	29430003 	ldp	w3, w0, [x0, #24]
    9d3c:	92403c41 	and	x1, x2, #0xffff
    9d40:	9b037c21 	mul	x1, x1, x3
    9d44:	d360fc21 	lsr	x1, x1, #32
    9d48:	eb00003f 	cmp	x1, x0
    9d4c:	54000142 	b.cs	9d74 <fwp_main_thread+0x1904>  // b.hs, b.nlast
    9d50:	8b0102d6 	add	x22, x22, x1
    9d54:	394002c0 	ldrb	w0, [x22]
    9d58:	340000e0 	cbz	w0, 9d74 <fwp_main_thread+0x1904>
    9d5c:	7100041f 	cmp	w0, #0x1
    9d60:	54003600 	b.eq	a420 <fwp_main_thread+0x1fb0>  // b.none
    9d64:	7103fc1f 	cmp	w0, #0xff
    9d68:	54004f40 	b.eq	a750 <fwp_main_thread+0x22e0>  // b.none
    9d6c:	51000400 	sub	w0, w0, #0x1
    9d70:	390002c0 	strb	w0, [x22]
    9d74:	f9402fe0 	ldr	x0, [sp, #88]
    9d78:	f9400800 	ldr	x0, [x0, #16]
    9d7c:	f9002fe0 	str	x0, [sp, #88]
    9d80:	b4004680 	cbz	x0, a650 <fwp_main_thread+0x21e0>
    9d84:	91014300 	add	x0, x24, #0x50
    9d88:	f941c813 	ldr	x19, [x0, #912]
    9d8c:	17fffbd1 	b	8cd0 <fwp_main_thread+0x860>
    9d90:	f9400265 	ldr	x5, [x19]
    9d94:	aa1303e0 	mov	x0, x19
    9d98:	f949ef83 	ldr	x3, [x28, #5080]
    9d9c:	f949db82 	ldr	x2, [x28, #5040]
    9da0:	d370bc63 	lsl	x3, x3, #16
    9da4:	cb020269 	sub	x9, x19, x2
    9da8:	b7f81de5 	tbnz	x5, #63, a164 <fwp_main_thread+0x1cf4>
    9dac:	eb03013f 	cmp	x9, x3
    9db0:	54ffed62 	b.cs	9b5c <fwp_main_thread+0x16ec>  // b.hs, b.nlast
    9db4:	d350fd25 	lsr	x5, x9, #16
    9db8:	8b0508a5 	add	x5, x5, x5, lsl #2
    9dbc:	d37df0a5 	lsl	x5, x5, #3
    9dc0:	8b0500c8 	add	x8, x6, x5
    9dc4:	f9401107 	ldr	x7, [x8, #32]
    9dc8:	b4ffeca7 	cbz	x7, 9b5c <fwp_main_thread+0x16ec>
    9dcc:	386568c5 	ldrb	w5, [x6, x5]
    9dd0:	710008bf 	cmp	w5, #0x2
    9dd4:	540029a0 	b.eq	a308 <fwp_main_thread+0x1e98>  // b.none
    9dd8:	710004bf 	cmp	w5, #0x1
    9ddc:	54ffec01 	b.ne	9b5c <fwp_main_thread+0x16ec>  // b.any
    9de0:	29431506 	ldp	w6, w5, [x8, #24]
    9de4:	92403d20 	and	x0, x9, #0xffff
    9de8:	9b067c00 	mul	x0, x0, x6
    9dec:	d360fc00 	lsr	x0, x0, #32
    9df0:	eb05001f 	cmp	x0, x5
    9df4:	54ffeb42 	b.cs	9b5c <fwp_main_thread+0x16ec>  // b.hs, b.nlast
    9df8:	8b0000e7 	add	x7, x7, x0
    9dfc:	394000e0 	ldrb	w0, [x7]
    9e00:	7100041f 	cmp	w0, #0x1
    9e04:	54ffeac1 	b.ne	9b5c <fwp_main_thread+0x16ec>  // b.any
    9e08:	aa1303e0 	mov	x0, x19
    9e0c:	f9000be1 	str	x1, [sp, #16]
    9e10:	97ffeba0 	bl	4c90 <fwp_mem_free>
    9e14:	f949ef83 	ldr	x3, [x28, #5080]
    9e18:	f9400be1 	ldr	x1, [sp, #16]
    9e1c:	f949db82 	ldr	x2, [x28, #5040]
    9e20:	d370bc63 	lsl	x3, x3, #16
    9e24:	17ffff4e 	b	9b5c <fwp_main_thread+0x16ec>
    9e28:	aa1903e0 	mov	x0, x25
    9e2c:	97ffeaf9 	bl	4a10 <fwp_rc_forget_slot>
    9e30:	17ffff09 	b	9a54 <fwp_main_thread+0x15e4>
    9e34:	72003c3f 	tst	w1, #0xffff
    9e38:	54ffe101 	b.ne	9a58 <fwp_main_thread+0x15e8>  // b.any
    9e3c:	17ffff03 	b	9a48 <fwp_main_thread+0x15d8>
    9e40:	72003c3f 	tst	w1, #0xffff
    9e44:	54ffcc60 	b.eq	97d0 <fwp_main_thread+0x1360>  // b.none
    9e48:	b40011b5 	cbz	x21, a07c <fwp_main_thread+0x1c0c>
    9e4c:	aa1503f6 	mov	x22, x21
    9e50:	d280001a 	mov	x26, #0x0                   	// #0
    9e54:	d503201f 	nop
    9e58:	f9400ad6 	ldr	x22, [x22, #16]
    9e5c:	aa1a03e0 	mov	x0, x26
    9e60:	9100075a 	add	x26, x26, #0x1
    9e64:	b5ffffb6 	cbnz	x22, 9e58 <fwp_main_thread+0x19e8>
    9e68:	f9000be3 	str	x3, [sp, #16]
    9e6c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9e70:	eb01035f 	cmp	x26, x1
    9e74:	54004ae8 	b.hi	a7d0 <fwp_main_thread+0x2360>  // b.pmore
    9e78:	91000800 	add	x0, x0, #0x2
    9e7c:	52800041 	mov	w1, #0x2                   	// #2
    9e80:	d37df000 	lsl	x0, x0, #3
    9e84:	97ffeca3 	bl	5110 <fwp_heap_alloc>
    9e88:	f9400be3 	ldr	x3, [sp, #16]
    9e8c:	aa1503e1 	mov	x1, x21
    9e90:	eb1a007f 	cmp	x3, x26
    9e94:	9a9a9063 	csel	x3, x3, x26, ls	// ls = plast
    9e98:	aa0003fa 	mov	x26, x0
    9e9c:	d503201f 	nop
    9ea0:	f9400420 	ldr	x0, [x1, #8]
    9ea4:	f8367b40 	str	x0, [x26, x22, lsl #3]
    9ea8:	910006d6 	add	x22, x22, #0x1
    9eac:	f9400821 	ldr	x1, [x1, #16]
    9eb0:	b5ffff81 	cbnz	x1, 9ea0 <fwp_main_thread+0x1a30>
    9eb4:	b4000ec3 	cbz	x3, a08c <fwp_main_thread+0x1c1c>
    9eb8:	f94002e0 	ldr	x0, [x23]
    9ebc:	b90013ff 	str	wzr, [sp, #16]
    9ec0:	17fffe4c 	b	97f0 <fwp_main_thread+0x1380>
    9ec4:	eb16027f 	cmp	x19, x22
    9ec8:	54ff82e0 	b.eq	8f24 <fwp_main_thread+0xab4>  // b.none
    9ecc:	91014300 	add	x0, x24, #0x50
    9ed0:	8b1606da 	add	x26, x22, x22, lsl #1
    9ed4:	8b1a0ada 	add	x26, x22, x26, lsl #2
    9ed8:	f9404419 	ldr	x25, [x0, #136]
    9edc:	d0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    9ee0:	910e4000 	add	x0, x0, #0x390
    9ee4:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    9ee8:	f900335f 	str	xzr, [x26, #96]
    9eec:	97ffe2d1 	bl	2a30 <getenv@plt>
    9ef0:	b5ff8720 	cbnz	x0, 8fd4 <fwp_main_thread+0xb64>
    9ef4:	91014300 	add	x0, x24, #0x50
    9ef8:	f9408c01 	ldr	x1, [x0, #280]
    9efc:	b4ff8761 	cbz	x1, 8fe8 <fwp_main_thread+0xb78>
    9f00:	ad470402 	ldp	q2, q1, [x0, #224]
    9f04:	91038001 	add	x1, x0, #0xe0
    9f08:	4f000400 	movi	v0.4s, #0x0
    9f0c:	f9008c1f 	str	xzr, [x0, #280]
    9f10:	ad010742 	stp	q2, q1, [x26, #32]
    9f14:	f9408800 	ldr	x0, [x0, #272]
    9f18:	f9002740 	str	x0, [x26, #72]
    9f1c:	f9401020 	ldr	x0, [x1, #32]
    9f20:	f9002340 	str	x0, [x26, #64]
    9f24:	f9401420 	ldr	x0, [x1, #40]
    9f28:	f9000f40 	str	x0, [x26, #24]
    9f2c:	f900183f 	str	xzr, [x1, #48]
    9f30:	ad000020 	stp	q0, q0, [x1]
    9f34:	3d800820 	str	q0, [x1, #32]
    9f38:	17fffc2c 	b	8fe8 <fwp_main_thread+0xb78>
    9f3c:	d53bd040 	mrs	x0, tpidr_el0
    9f40:	91400000 	add	x0, x0, #0x0, lsl #12
    9f44:	91004000 	add	x0, x0, #0x10
    9f48:	f9400000 	ldr	x0, [x0]
    9f4c:	b4001500 	cbz	x0, a1ec <fwp_main_thread+0x1d7c>
    9f50:	f94023e1 	ldr	x1, [sp, #64]
    9f54:	97ffe644 	bl	3864 <fwp_closure_drop_push>
    9f58:	b5ff7a75 	cbnz	x21, 8ea4 <fwp_main_thread+0xa34>
    9f5c:	91014313 	add	x19, x24, #0x50
    9f60:	d2800017 	mov	x23, #0x0                   	// #0
    9f64:	b943ca60 	ldr	w0, [x19, #968]
    9f68:	35ff7b80 	cbnz	w0, 8ed8 <fwp_main_thread+0xa68>
    9f6c:	d503201f 	nop
    9f70:	b0ffffe0 	adrp	x0, 6000 <fwp_drop1+0xf0>
    9f74:	910b8000 	add	x0, x0, #0x2e0
    9f78:	940003fa 	bl	af60 <atexit>
    9f7c:	35ffb880 	cbnz	w0, 968c <fwp_main_thread+0x121c>
    9f80:	52800020 	mov	w0, #0x1                   	// #1
    9f84:	b903ca60 	str	w0, [x19, #968]
    9f88:	17fffbd4 	b	8ed8 <fwp_main_thread+0xa68>
    9f8c:	72003c1f 	tst	w0, #0xffff
    9f90:	54ffb140 	b.eq	95b8 <fwp_main_thread+0x1148>  // b.none
    9f94:	d503201f 	nop
    9f98:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9f9c:	eb00035f 	cmp	x26, x0
    9fa0:	540041e8 	b.hi	a7dc <fwp_main_thread+0x236c>  // b.pmore
    9fa4:	91000740 	add	x0, x26, #0x1
    9fa8:	52800021 	mov	w1, #0x1                   	// #1
    9fac:	d37df000 	lsl	x0, x0, #3
    9fb0:	97ffec58 	bl	5110 <fwp_heap_alloc>
    9fb4:	f900001a 	str	x26, [x0]
    9fb8:	aa0003f7 	mov	x23, x0
    9fbc:	aa0003f3 	mov	x19, x0
    9fc0:	f949db81 	ldr	x1, [x28, #5040]
    9fc4:	f949ef80 	ldr	x0, [x28, #5080]
    9fc8:	cb0102e1 	sub	x1, x23, x1
    9fcc:	eb00403f 	cmp	x1, x0, lsl #16
    9fd0:	54000322 	b.cs	a034 <fwp_main_thread+0x1bc4>  // b.hs, b.nlast
    9fd4:	d350fc20 	lsr	x0, x1, #16
    9fd8:	f949ff85 	ldr	x5, [x28, #5112]
    9fdc:	8b000800 	add	x0, x0, x0, lsl #2
    9fe0:	d37df002 	lsl	x2, x0, #3
    9fe4:	8b0200a3 	add	x3, x5, x2
    9fe8:	f9401079 	ldr	x25, [x3, #32]
    9fec:	b4000259 	cbz	x25, a034 <fwp_main_thread+0x1bc4>
    9ff0:	386268a2 	ldrb	w2, [x5, x2]
    9ff4:	7100085f 	cmp	w2, #0x2
    9ff8:	54001940 	b.eq	a320 <fwp_main_thread+0x1eb0>  // b.none
    9ffc:	7100045f 	cmp	w2, #0x1
    a000:	540001a1 	b.ne	a034 <fwp_main_thread+0x1bc4>  // b.any
    a004:	29430865 	ldp	w5, w2, [x3, #24]
    a008:	92403c21 	and	x1, x1, #0xffff
    a00c:	9b057c21 	mul	x1, x1, x5
    a010:	d360fc21 	lsr	x1, x1, #32
    a014:	eb02003f 	cmp	x1, x2
    a018:	540000e2 	b.cs	a034 <fwp_main_thread+0x1bc4>  // b.hs, b.nlast
    a01c:	8b010339 	add	x25, x25, x1
    a020:	39400321 	ldrb	w1, [x25]
    a024:	7103fc3f 	cmp	w1, #0xff
    a028:	54001840 	b.eq	a330 <fwp_main_thread+0x1ec0>  // b.none
    a02c:	52800021 	mov	w1, #0x1                   	// #1
    a030:	39000321 	strb	w1, [x25]
    a034:	aa1603e0 	mov	x0, x22
    a038:	17fffd66 	b	95d0 <fwp_main_thread+0x1160>
    a03c:	eb16007f 	cmp	x3, x22
    a040:	54ffc588 	b.hi	98f0 <fwp_main_thread+0x1480>  // b.pmore
    a044:	17fffe8f 	b	9a80 <fwp_main_thread+0x1610>
    a048:	52800041 	mov	w1, #0x2                   	// #2
    a04c:	d2800100 	mov	x0, #0x8                   	// #8
    a050:	97ffec30 	bl	5110 <fwp_heap_alloc>
    a054:	f900001f 	str	xzr, [x0]
    a058:	aa0003f7 	mov	x23, x0
    a05c:	aa0003fa 	mov	x26, x0
    a060:	f949db81 	ldr	x1, [x28, #5040]
    a064:	f949ef80 	ldr	x0, [x28, #5080]
    a068:	cb0102e1 	sub	x1, x23, x1
    a06c:	eb00403f 	cmp	x1, x0, lsl #16
    a070:	54000202 	b.cs	a0b0 <fwp_main_thread+0x1c40>  // b.hs, b.nlast
    a074:	d2800016 	mov	x22, #0x0                   	// #0
    a078:	17fffc1f 	b	90f4 <fwp_main_thread+0xc84>
    a07c:	52800041 	mov	w1, #0x2                   	// #2
    a080:	d2800100 	mov	x0, #0x8                   	// #8
    a084:	97ffec23 	bl	5110 <fwp_heap_alloc>
    a088:	aa0003fa 	mov	x26, x0
    a08c:	aa1503e1 	mov	x1, x21
    a090:	d2800017 	mov	x23, #0x0                   	// #0
    a094:	17fffe8a 	b	9abc <fwp_main_thread+0x164c>
    a098:	f9001fe0 	str	x0, [sp, #56]
    a09c:	97ffea5d 	bl	4a10 <fwp_rc_forget_slot>
    a0a0:	f9401fe0 	ldr	x0, [sp, #56]
    a0a4:	17fffe23 	b	9930 <fwp_main_thread+0x14c0>
    a0a8:	b5ff8596 	cbnz	x22, 9158 <fwp_main_thread+0xce8>
    a0ac:	d503201f 	nop
    a0b0:	d2800019 	mov	x25, #0x0                   	// #0
    a0b4:	17fffc50 	b	91f4 <fwp_main_thread+0xd84>
    a0b8:	72003c3f 	tst	w1, #0xffff
    a0bc:	54ff8e61 	b.ne	9288 <fwp_main_thread+0xe18>  // b.any
    a0c0:	17fffc69 	b	9264 <fwp_main_thread+0xdf4>
    a0c4:	72003cbf 	tst	w5, #0xffff
    a0c8:	54ffd441 	b.ne	9b50 <fwp_main_thread+0x16e0>  // b.any
    a0cc:	17fffe99 	b	9b30 <fwp_main_thread+0x16c0>
    a0d0:	f940075a 	ldr	x26, [x26, #8]
    a0d4:	eb03005f 	cmp	x2, x3
    a0d8:	54000382 	b.cs	a148 <fwp_main_thread+0x1cd8>  // b.hs, b.nlast
    a0dc:	d350fc47 	lsr	x7, x2, #16
    a0e0:	8b0708e7 	add	x7, x7, x7, lsl #2
    a0e4:	d37df0e7 	lsl	x7, x7, #3
    a0e8:	8b0700c9 	add	x9, x6, x7
    a0ec:	f9401128 	ldr	x8, [x9, #32]
    a0f0:	b40002c8 	cbz	x8, a148 <fwp_main_thread+0x1cd8>
    a0f4:	386768c6 	ldrb	w6, [x6, x7]
    a0f8:	710008df 	cmp	w6, #0x2
    a0fc:	540018c0 	b.eq	a414 <fwp_main_thread+0x1fa4>  // b.none
    a100:	710004df 	cmp	w6, #0x1
    a104:	54000221 	b.ne	a148 <fwp_main_thread+0x1cd8>  // b.any
    a108:	29431927 	ldp	w7, w6, [x9, #24]
    a10c:	92403c42 	and	x2, x2, #0xffff
    a110:	9b077c42 	mul	x2, x2, x7
    a114:	d360fc42 	lsr	x2, x2, #32
    a118:	eb06005f 	cmp	x2, x6
    a11c:	54000162 	b.cs	a148 <fwp_main_thread+0x1cd8>  // b.hs, b.nlast
    a120:	8b020108 	add	x8, x8, x2
    a124:	39400102 	ldrb	w2, [x8]
    a128:	7100045f 	cmp	w2, #0x1
    a12c:	540000e1 	b.ne	a148 <fwp_main_thread+0x1cd8>  // b.any
    a130:	f9000be5 	str	x5, [sp, #16]
    a134:	97ffead7 	bl	4c90 <fwp_mem_free>
    a138:	f949ef83 	ldr	x3, [x28, #5080]
    a13c:	f9400be5 	ldr	x5, [sp, #16]
    a140:	f949db81 	ldr	x1, [x28, #5040]
    a144:	d370bc63 	lsl	x3, x3, #16
    a148:	cb010341 	sub	x1, x26, x1
    a14c:	eb01007f 	cmp	x3, x1
    a150:	54ff8648 	b.hi	9218 <fwp_main_thread+0xda8>  // b.pmore
    a154:	17fffc4d 	b	9288 <fwp_main_thread+0xe18>
    a158:	72003c5f 	tst	w2, #0xffff
    a15c:	54ffd3e1 	b.ne	9bd8 <fwp_main_thread+0x1768>  // b.any
    a160:	17fffe95 	b	9bb4 <fwp_main_thread+0x1744>
    a164:	f9400673 	ldr	x19, [x19, #8]
    a168:	eb03013f 	cmp	x9, x3
    a16c:	54000382 	b.cs	a1dc <fwp_main_thread+0x1d6c>  // b.hs, b.nlast
    a170:	d350fd25 	lsr	x5, x9, #16
    a174:	8b0508a5 	add	x5, x5, x5, lsl #2
    a178:	d37df0a5 	lsl	x5, x5, #3
    a17c:	8b0500c8 	add	x8, x6, x5
    a180:	f9401107 	ldr	x7, [x8, #32]
    a184:	b40002c7 	cbz	x7, a1dc <fwp_main_thread+0x1d6c>
    a188:	386568c5 	ldrb	w5, [x6, x5]
    a18c:	710008bf 	cmp	w5, #0x2
    a190:	540014e0 	b.eq	a42c <fwp_main_thread+0x1fbc>  // b.none
    a194:	710004bf 	cmp	w5, #0x1
    a198:	54000221 	b.ne	a1dc <fwp_main_thread+0x1d6c>  // b.any
    a19c:	2943190a 	ldp	w10, w6, [x8, #24]
    a1a0:	92403d25 	and	x5, x9, #0xffff
    a1a4:	9b0a7ca5 	mul	x5, x5, x10
    a1a8:	d360fca5 	lsr	x5, x5, #32
    a1ac:	eb0600bf 	cmp	x5, x6
    a1b0:	54000162 	b.cs	a1dc <fwp_main_thread+0x1d6c>  // b.hs, b.nlast
    a1b4:	8b0500e7 	add	x7, x7, x5
    a1b8:	394000e5 	ldrb	w5, [x7]
    a1bc:	710004bf 	cmp	w5, #0x1
    a1c0:	540000e1 	b.ne	a1dc <fwp_main_thread+0x1d6c>  // b.any
    a1c4:	f9000be1 	str	x1, [sp, #16]
    a1c8:	97ffeab2 	bl	4c90 <fwp_mem_free>
    a1cc:	f949ef83 	ldr	x3, [x28, #5080]
    a1d0:	f9400be1 	ldr	x1, [sp, #16]
    a1d4:	f949db82 	ldr	x2, [x28, #5040]
    a1d8:	d370bc63 	lsl	x3, x3, #16
    a1dc:	cb020265 	sub	x5, x19, x2
    a1e0:	eb05007f 	cmp	x3, x5
    a1e4:	54ffc808 	b.hi	9ae4 <fwp_main_thread+0x1674>  // b.pmore
    a1e8:	17fffe5d 	b	9b5c <fwp_main_thread+0x16ec>
    a1ec:	f94023e0 	ldr	x0, [sp, #64]
    a1f0:	97ffe60c 	bl	3a20 <fwp_closure_drop.part.0>
    a1f4:	17fffb2b 	b	8ea0 <fwp_main_thread+0xa30>
    a1f8:	72003c7f 	tst	w3, #0xffff
    a1fc:	54ff6521 	b.ne	8ea0 <fwp_main_thread+0xa30>  // b.any
    a200:	17fffb20 	b	8e80 <fwp_main_thread+0xa10>
    a204:	72003c3f 	tst	w1, #0xffff
    a208:	54ff7a61 	b.ne	9154 <fwp_main_thread+0xce4>  // b.any
    a20c:	39400321 	ldrb	w1, [x25]
    a210:	7103fc3f 	cmp	w1, #0xff
    a214:	54ff79c1 	b.ne	914c <fwp_main_thread+0xcdc>  // b.any
    a218:	aa1903e0 	mov	x0, x25
    a21c:	97ffe9fd 	bl	4a10 <fwp_rc_forget_slot>
    a220:	17fffbcb 	b	914c <fwp_main_thread+0xcdc>
    a224:	72003c7f 	tst	w3, #0xffff
    a228:	54ff6141 	b.ne	8e50 <fwp_main_thread+0x9e0>  // b.any
    a22c:	aa1303e0 	mov	x0, x19
    a230:	17fffaf0 	b	8df0 <fwp_main_thread+0x980>
    a234:	aa1a03f6 	mov	x22, x26
    a238:	17fffc48 	b	9358 <fwp_main_thread+0xee8>
    a23c:	72003c3f 	tst	w1, #0xffff
    a240:	54ff9761 	b.ne	952c <fwp_main_thread+0x10bc>  // b.any
    a244:	39400260 	ldrb	w0, [x19]
    a248:	7103fc1f 	cmp	w0, #0xff
    a24c:	54ff96c1 	b.ne	9524 <fwp_main_thread+0x10b4>  // b.any
    a250:	aa1303e0 	mov	x0, x19
    a254:	97ffe9ef 	bl	4a10 <fwp_rc_forget_slot>
    a258:	17fffcb3 	b	9524 <fwp_main_thread+0x10b4>
    a25c:	72003c5f 	tst	w2, #0xffff
    a260:	54ff8141 	b.ne	9288 <fwp_main_thread+0xe18>  // b.any
    a264:	17fffd31 	b	9728 <fwp_main_thread+0x12b8>
    a268:	f949ef86 	ldr	x6, [x28, #5080]
    a26c:	f949db82 	ldr	x2, [x28, #5040]
    a270:	d370bcc6 	lsl	x6, x6, #16
    a274:	cb020020 	sub	x0, x1, x2
    a278:	f9400833 	ldr	x19, [x1, #16]
    a27c:	eb06001f 	cmp	x0, x6
    a280:	540003a2 	b.cs	a2f4 <fwp_main_thread+0x1e84>  // b.hs, b.nlast
    a284:	d350fc03 	lsr	x3, x0, #16
    a288:	8b030863 	add	x3, x3, x3, lsl #2
    a28c:	d37df063 	lsl	x3, x3, #3
    a290:	8b0300a8 	add	x8, x5, x3
    a294:	f9401107 	ldr	x7, [x8, #32]
    a298:	b40002e7 	cbz	x7, a2f4 <fwp_main_thread+0x1e84>
    a29c:	386368a3 	ldrb	w3, [x5, x3]
    a2a0:	7100087f 	cmp	w3, #0x2
    a2a4:	54000ca0 	b.eq	a438 <fwp_main_thread+0x1fc8>  // b.none
    a2a8:	7100047f 	cmp	w3, #0x1
    a2ac:	54000241 	b.ne	a2f4 <fwp_main_thread+0x1e84>  // b.any
    a2b0:	29430d05 	ldp	w5, w3, [x8, #24]
    a2b4:	92403c00 	and	x0, x0, #0xffff
    a2b8:	9b057c00 	mul	x0, x0, x5
    a2bc:	d360fc00 	lsr	x0, x0, #32
    a2c0:	eb03001f 	cmp	x0, x3
    a2c4:	54000182 	b.cs	a2f4 <fwp_main_thread+0x1e84>  // b.hs, b.nlast
    a2c8:	8b0000e7 	add	x7, x7, x0
    a2cc:	394000e0 	ldrb	w0, [x7]
    a2d0:	7100041f 	cmp	w0, #0x1
    a2d4:	54000101 	b.ne	a2f4 <fwp_main_thread+0x1e84>  // b.any
    a2d8:	aa0103e0 	mov	x0, x1
    a2dc:	97ffea6d 	bl	4c90 <fwp_mem_free>
    a2e0:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xbb0>
    a2e4:	9118c000 	add	x0, x0, #0x630
    a2e8:	f949ec06 	ldr	x6, [x0, #5080]
    a2ec:	f949d802 	ldr	x2, [x0, #5040]
    a2f0:	d370bcc6 	lsl	x6, x6, #16
    a2f4:	cb020262 	sub	x2, x19, x2
    a2f8:	eb0200df 	cmp	x6, x2
    a2fc:	54ffc6e9 	b.ls	9bd8 <fwp_main_thread+0x1768>  // b.plast
    a300:	aa1303e1 	mov	x1, x19
    a304:	17fffe19 	b	9b68 <fwp_main_thread+0x16f8>
    a308:	72003d3f 	tst	w9, #0xffff
    a30c:	54ffc281 	b.ne	9b5c <fwp_main_thread+0x16ec>  // b.any
    a310:	17fffebb 	b	9dfc <fwp_main_thread+0x198c>
    a314:	d2800019 	mov	x25, #0x0                   	// #0
    a318:	52800020 	mov	w0, #0x1                   	// #1
    a31c:	17fffcd4 	b	966c <fwp_main_thread+0x11fc>
    a320:	72003c3f 	tst	w1, #0xffff
    a324:	54ffe7e0 	b.eq	a020 <fwp_main_thread+0x1bb0>  // b.none
    a328:	aa1603e0 	mov	x0, x22
    a32c:	17fffca9 	b	95d0 <fwp_main_thread+0x1160>
    a330:	aa1903e0 	mov	x0, x25
    a334:	97ffe9b7 	bl	4a10 <fwp_rc_forget_slot>
    a338:	17ffff3d 	b	a02c <fwp_main_thread+0x1bbc>
    a33c:	d10006e1 	sub	x1, x23, #0x1
    a340:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    a344:	eb00003f 	cmp	x1, x0
    a348:	54002668 	b.hi	a814 <fwp_main_thread+0x23a4>  // b.pmore
    a34c:	d00002a3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fbb0>
    a350:	d2800000 	mov	x0, #0x0                   	// #0
    a354:	91114061 	add	x1, x3, #0x450
    a358:	14000005 	b	a36c <fwp_main_thread+0x1efc>
    a35c:	91000400 	add	x0, x0, #0x1
    a360:	91006021 	add	x1, x1, #0x18
    a364:	f140041f 	cmp	x0, #0x1, lsl #12
    a368:	540018a0 	b.eq	a67c <fwp_main_thread+0x220c>  // b.none
    a36c:	f9400022 	ldr	x2, [x1]
    a370:	b5ffff62 	cbnz	x2, a35c <fwp_main_thread+0x1eec>
    a374:	8b000402 	add	x2, x0, x0, lsl #1
    a378:	91114063 	add	x3, x3, #0x450
    a37c:	aa1703e0 	mov	x0, x23
    a380:	d2800101 	mov	x1, #0x8                   	// #8
    a384:	8b020c73 	add	x19, x3, x2, lsl #3
    a388:	f9000be5 	str	x5, [sp, #16]
    a38c:	f9001fe8 	str	x8, [sp, #56]
    a390:	a904abe9 	stp	x9, x10, [sp, #72]
    a394:	97ffe13b 	bl	2880 <calloc@plt>
    a398:	aa0003f9 	mov	x25, x0
    a39c:	f9400be5 	ldr	x5, [sp, #16]
    a3a0:	f9401fe8 	ldr	x8, [sp, #56]
    a3a4:	a944abe9 	ldp	x9, x10, [sp, #72]
    a3a8:	b4fffb60 	cbz	x0, a314 <fwp_main_thread+0x1ea4>
    a3ac:	aa1303e0 	mov	x0, x19
    a3b0:	d37df2e2 	lsl	x2, x23, #3
    a3b4:	aa1903e1 	mov	x1, x25
    a3b8:	52800063 	mov	w3, #0x3                   	// #3
    a3bc:	f9000be5 	str	x5, [sp, #16]
    a3c0:	f9001fe8 	str	x8, [sp, #56]
    a3c4:	a904abe9 	stp	x9, x10, [sp, #72]
    a3c8:	97ffe2f2 	bl	2f90 <ad_raw_record>
    a3cc:	f9400be5 	ldr	x5, [sp, #16]
    a3d0:	f9401fe8 	ldr	x8, [sp, #56]
    a3d4:	a944abe9 	ldp	x9, x10, [sp, #72]
    a3d8:	17fffbf8 	b	93b8 <fwp_main_thread+0xf48>
    a3dc:	f94002e0 	ldr	x0, [x23]
    a3e0:	b7ffe4e0 	tbnz	x0, #63, a07c <fwp_main_thread+0x1c0c>
    a3e4:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xbb0>
    a3e8:	9118c023 	add	x3, x1, #0x630
    a3ec:	f949d861 	ldr	x1, [x3, #5040]
    a3f0:	f949ec63 	ldr	x3, [x3, #5080]
    a3f4:	cb010261 	sub	x1, x19, x1
    a3f8:	eb03403f 	cmp	x1, x3, lsl #16
    a3fc:	54ffe402 	b.cs	a07c <fwp_main_thread+0x1c0c>  // b.hs, b.nlast
    a400:	9240f803 	and	x3, x0, #0x7fffffffffffffff
    a404:	17fffce0 	b	9784 <fwp_main_thread+0x1314>
    a408:	d2800d01 	mov	x1, #0x68                  	// #104
    a40c:	d2800036 	mov	x22, #0x1                   	// #1
    a410:	17fffad5 	b	8f64 <fwp_main_thread+0xaf4>
    a414:	72003c5f 	tst	w2, #0xffff
    a418:	54ffe981 	b.ne	a148 <fwp_main_thread+0x1cd8>  // b.any
    a41c:	17ffff42 	b	a124 <fwp_main_thread+0x1cb4>
    a420:	aa1303e0 	mov	x0, x19
    a424:	97ffed8b 	bl	5a50 <fwp_rc_free_arr>
    a428:	17fffe53 	b	9d74 <fwp_main_thread+0x1904>
    a42c:	72003d3f 	tst	w9, #0xffff
    a430:	54ffed61 	b.ne	a1dc <fwp_main_thread+0x1d6c>  // b.any
    a434:	17ffff61 	b	a1b8 <fwp_main_thread+0x1d48>
    a438:	72003c1f 	tst	w0, #0xffff
    a43c:	54fff5c1 	b.ne	a2f4 <fwp_main_thread+0x1e84>  // b.any
    a440:	17ffffa3 	b	a2cc <fwp_main_thread+0x1e5c>
    a444:	72003c5f 	tst	w2, #0xffff
    a448:	54ff4921 	b.ne	8d6c <fwp_main_thread+0x8fc>  // b.any
    a44c:	17fffa3a 	b	8d34 <fwp_main_thread+0x8c4>
    a450:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a454:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xbb0>
    a458:	9118c021 	add	x1, x1, #0x630
    a45c:	ca402400 	eor	x0, x0, x0, lsr #9
    a460:	8b200c20 	add	x0, x1, w0, uxtb #3
    a464:	f94a2400 	ldr	x0, [x0, #5192]
    a468:	b50000c0 	cbnz	x0, a480 <fwp_main_thread+0x2010>
    a46c:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a470:	91114000 	add	x0, x0, #0x450
    a474:	97ffe4e3 	bl	3800 <fwp_trap>
    a478:	f9400800 	ldr	x0, [x0, #16]
    a47c:	b4ffff80 	cbz	x0, a46c <fwp_main_thread+0x1ffc>
    a480:	f9400001 	ldr	x1, [x0]
    a484:	eb16003f 	cmp	x1, x22
    a488:	54ffff81 	b.ne	a478 <fwp_main_thread+0x2008>  // b.any
    a48c:	f9400401 	ldr	x1, [x0, #8]
    a490:	d1000421 	sub	x1, x1, #0x1
    a494:	f9000401 	str	x1, [x0, #8]
    a498:	f103f83f 	cmp	x1, #0xfe
    a49c:	54ff6f61 	b.ne	9288 <fwp_main_thread+0xe18>  // b.any
    a4a0:	aa1603e0 	mov	x0, x22
    a4a4:	f9000be5 	str	x5, [sp, #16]
    a4a8:	97ffe95a 	bl	4a10 <fwp_rc_forget_slot>
    a4ac:	f9400be5 	ldr	x5, [sp, #16]
    a4b0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a4b4:	390002c0 	strb	w0, [x22]
    a4b8:	17fffb74 	b	9288 <fwp_main_thread+0xe18>
    a4bc:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a4c0:	f0000362 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    a4c4:	9118c042 	add	x2, x2, #0x630
    a4c8:	ca402400 	eor	x0, x0, x0, lsr #9
    a4cc:	8b200c40 	add	x0, x2, w0, uxtb #3
    a4d0:	f94a2402 	ldr	x2, [x0, #5192]
    a4d4:	b4fffcc2 	cbz	x2, a46c <fwp_main_thread+0x1ffc>
    a4d8:	f9400040 	ldr	x0, [x2]
    a4dc:	eb16001f 	cmp	x0, x22
    a4e0:	540000e0 	b.eq	a4fc <fwp_main_thread+0x208c>  // b.none
    a4e4:	d503201f 	nop
    a4e8:	f9400842 	ldr	x2, [x2, #16]
    a4ec:	b4fffc02 	cbz	x2, a46c <fwp_main_thread+0x1ffc>
    a4f0:	f9400040 	ldr	x0, [x2]
    a4f4:	eb16001f 	cmp	x0, x22
    a4f8:	54ffff81 	b.ne	a4e8 <fwp_main_thread+0x2078>  // b.any
    a4fc:	f9400440 	ldr	x0, [x2, #8]
    a500:	d1000400 	sub	x0, x0, #0x1
    a504:	f9000440 	str	x0, [x2, #8]
    a508:	f103f81f 	cmp	x0, #0xfe
    a50c:	54000e40 	b.eq	a6d4 <fwp_main_thread+0x2264>  // b.none
    a510:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xbb0>
    a514:	9118c000 	add	x0, x0, #0x630
    a518:	f949ec03 	ldr	x3, [x0, #5080]
    a51c:	f949d802 	ldr	x2, [x0, #5040]
    a520:	d370bc63 	lsl	x3, x3, #16
    a524:	17fffd8e 	b	9b5c <fwp_main_thread+0x16ec>
    a528:	f940ac43 	ldr	x3, [x2, #344]
    a52c:	91000463 	add	x3, x3, #0x1
    a530:	f900ac43 	str	x3, [x2, #344]
    a534:	17fffa05 	b	8d48 <fwp_main_thread+0x8d8>
    a538:	72003c5f 	tst	w2, #0xffff
    a53c:	54ff35e1 	b.ne	8bf8 <fwp_main_thread+0x788>  // b.any
    a540:	17fff9a9 	b	8be4 <fwp_main_thread+0x774>
    a544:	72003c5f 	tst	w2, #0xffff
    a548:	54ff30e1 	b.ne	8b64 <fwp_main_thread+0x6f4>  // b.any
    a54c:	17fff981 	b	8b50 <fwp_main_thread+0x6e0>
    a550:	72003c5f 	tst	w2, #0xffff
    a554:	54ff39e1 	b.ne	8c90 <fwp_main_thread+0x820>  // b.any
    a558:	17fff9c9 	b	8c7c <fwp_main_thread+0x80c>
    a55c:	72003c5f 	tst	w2, #0xffff
    a560:	54ffc0a1 	b.ne	9d74 <fwp_main_thread+0x1904>  // b.any
    a564:	17fffdfc 	b	9d54 <fwp_main_thread+0x18e4>
    a568:	72003c5f 	tst	w2, #0xffff
    a56c:	54ffbac1 	b.ne	9cc4 <fwp_main_thread+0x1854>  // b.any
    a570:	17fffdd0 	b	9cb0 <fwp_main_thread+0x1840>
    a574:	ca534660 	eor	x0, x19, x19, lsr #17
    a578:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xbb0>
    a57c:	9118c021 	add	x1, x1, #0x630
    a580:	ca402400 	eor	x0, x0, x0, lsr #9
    a584:	8b200c20 	add	x0, x1, w0, uxtb #3
    a588:	f94a2401 	ldr	x1, [x0, #5192]
    a58c:	b5000081 	cbnz	x1, a59c <fwp_main_thread+0x212c>
    a590:	17ffffb7 	b	a46c <fwp_main_thread+0x1ffc>
    a594:	f9400821 	ldr	x1, [x1, #16]
    a598:	b4fff6a1 	cbz	x1, a46c <fwp_main_thread+0x1ffc>
    a59c:	f9400020 	ldr	x0, [x1]
    a5a0:	eb00027f 	cmp	x19, x0
    a5a4:	54ffff81 	b.ne	a594 <fwp_main_thread+0x2124>  // b.any
    a5a8:	f9400420 	ldr	x0, [x1, #8]
    a5ac:	d1000400 	sub	x0, x0, #0x1
    a5b0:	f9000420 	str	x0, [x1, #8]
    a5b4:	f103f81f 	cmp	x0, #0xfe
    a5b8:	54ffb101 	b.ne	9bd8 <fwp_main_thread+0x1768>  // b.any
    a5bc:	aa1303e0 	mov	x0, x19
    a5c0:	97ffe914 	bl	4a10 <fwp_rc_forget_slot>
    a5c4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a5c8:	39000260 	strb	w0, [x19]
    a5cc:	17fffd83 	b	9bd8 <fwp_main_thread+0x1768>
    a5d0:	aa1503e1 	mov	x1, x21
    a5d4:	d280001a 	mov	x26, #0x0                   	// #0
    a5d8:	d2800017 	mov	x23, #0x0                   	// #0
    a5dc:	17fffd38 	b	9abc <fwp_main_thread+0x164c>
    a5e0:	ca534660 	eor	x0, x19, x19, lsr #17
    a5e4:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xbb0>
    a5e8:	9118c021 	add	x1, x1, #0x630
    a5ec:	ca402400 	eor	x0, x0, x0, lsr #9
    a5f0:	8b200c20 	add	x0, x1, w0, uxtb #3
    a5f4:	f94a2400 	ldr	x0, [x0, #5192]
    a5f8:	b5000080 	cbnz	x0, a608 <fwp_main_thread+0x2198>
    a5fc:	17ffff9c 	b	a46c <fwp_main_thread+0x1ffc>
    a600:	f9400800 	ldr	x0, [x0, #16]
    a604:	b4fff340 	cbz	x0, a46c <fwp_main_thread+0x1ffc>
    a608:	f9400001 	ldr	x1, [x0]
    a60c:	eb13003f 	cmp	x1, x19
    a610:	54ffff81 	b.ne	a600 <fwp_main_thread+0x2190>  // b.any
    a614:	f9400401 	ldr	x1, [x0, #8]
    a618:	d1000421 	sub	x1, x1, #0x1
    a61c:	f9000401 	str	x1, [x0, #8]
    a620:	f103f83f 	cmp	x1, #0xfe
    a624:	54ff43e1 	b.ne	8ea0 <fwp_main_thread+0xa30>  // b.any
    a628:	aa1303e0 	mov	x0, x19
    a62c:	97ffe8f9 	bl	4a10 <fwp_rc_forget_slot>
    a630:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a634:	39000260 	strb	w0, [x19]
    a638:	17fffa1a 	b	8ea0 <fwp_main_thread+0xa30>
    a63c:	97ffe8ae 	bl	48f4 <fwp_rc_wide_dup>
    a640:	17fff9f8 	b	8e20 <fwp_main_thread+0x9b0>
    a644:	aa0003e1 	mov	x1, x0
    a648:	f9002293 	str	x19, [x20, #64]
    a64c:	17fff7ed 	b	8600 <fwp_main_thread+0x190>
    a650:	aa1503e0 	mov	x0, x21
    a654:	97ffeddb 	bl	5dc0 <fwp_drop0>
    a658:	f9400fe0 	ldr	x0, [sp, #24]
    a65c:	97ffedd9 	bl	5dc0 <fwp_drop0>
    a660:	91014300 	add	x0, x24, #0x50
    a664:	fd4103e8 	ldr	d8, [sp, #512]
    a668:	a95f73fb 	ldp	x27, x28, [sp, #496]
    a66c:	52800021 	mov	w1, #0x1                   	// #1
    a670:	b903c401 	str	w1, [x0, #964]
    a674:	f901e81f 	str	xzr, [x0, #976]
    a678:	17fff7ca 	b	85a0 <fwp_main_thread+0x130>
    a67c:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a680:	910ce000 	add	x0, x0, #0x338
    a684:	97ffe33f 	bl	3380 <ad_raw_fail>
    a688:	f941d280 	ldr	x0, [x20, #928]
    a68c:	97ffe981 	bl	4c90 <fwp_mem_free>
    a690:	f901d29f 	str	xzr, [x20, #928]
    a694:	f901da9f 	str	xzr, [x20, #944]
    a698:	f941f280 	ldr	x0, [x20, #992]
    a69c:	b4000353 	cbz	x19, a704 <fwp_main_thread+0x2294>
    a6a0:	f900567f 	str	xzr, [x19, #168]
    a6a4:	f9005e7f 	str	xzr, [x19, #184]
    a6a8:	b903da9f 	str	wzr, [x20, #984]
    a6ac:	eb13001f 	cmp	x0, x19
    a6b0:	54ff0060 	b.eq	86bc <fwp_main_thread+0x24c>  // b.none
    a6b4:	a91f73fb 	stp	x27, x28, [sp, #496]
    a6b8:	fd0103e8 	str	d8, [sp, #512]
    a6bc:	97ffe08d 	bl	28f0 <abort@plt>
    a6c0:	d2800016 	mov	x22, #0x0                   	// #0
    a6c4:	17fffc8b 	b	98f0 <fwp_main_thread+0x1480>
    a6c8:	aa1a03e0 	mov	x0, x26
    a6cc:	97ffe8d1 	bl	4a10 <fwp_rc_forget_slot>
    a6d0:	17fffd7b 	b	9cbc <fwp_main_thread+0x184c>
    a6d4:	aa1603e0 	mov	x0, x22
    a6d8:	f9000be1 	str	x1, [sp, #16]
    a6dc:	97ffe8cd 	bl	4a10 <fwp_rc_forget_slot>
    a6e0:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xbb0>
    a6e4:	9118c000 	add	x0, x0, #0x630
    a6e8:	12800022 	mov	w2, #0xfffffffe            	// #-2
    a6ec:	390002c2 	strb	w2, [x22]
    a6f0:	f9400be1 	ldr	x1, [sp, #16]
    a6f4:	f949ec03 	ldr	x3, [x0, #5080]
    a6f8:	f949d802 	ldr	x2, [x0, #5040]
    a6fc:	d370bc63 	lsl	x3, x3, #16
    a700:	17fffd17 	b	9b5c <fwp_main_thread+0x16ec>
    a704:	b903da9f 	str	wzr, [x20, #984]
    a708:	b4ff0740 	cbz	x0, 87f0 <fwp_main_thread+0x380>
    a70c:	17ffffea 	b	a6b4 <fwp_main_thread+0x2244>
    a710:	97ffe879 	bl	48f4 <fwp_rc_wide_dup>
    a714:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xbb0>
    a718:	9118c000 	add	x0, x0, #0x630
    a71c:	f949ec07 	ldr	x7, [x0, #5080]
    a720:	f949d803 	ldr	x3, [x0, #5040]
    a724:	d370bce7 	lsl	x7, x7, #16
    a728:	17fff991 	b	8d6c <fwp_main_thread+0x8fc>
    a72c:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a730:	91126000 	add	x0, x0, #0x498
    a734:	97ffe433 	bl	3800 <fwp_trap>
    a738:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a73c:	9114c000 	add	x0, x0, #0x530
    a740:	97ffe430 	bl	3800 <fwp_trap>
    a744:	aa1603e0 	mov	x0, x22
    a748:	97ffe8b2 	bl	4a10 <fwp_rc_forget_slot>
    a74c:	17fff904 	b	8b5c <fwp_main_thread+0x6ec>
    a750:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a754:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xbb0>
    a758:	9118c021 	add	x1, x1, #0x630
    a75c:	ca402400 	eor	x0, x0, x0, lsr #9
    a760:	8b200c20 	add	x0, x1, w0, uxtb #3
    a764:	f94a2400 	ldr	x0, [x0, #5192]
    a768:	b5000080 	cbnz	x0, a778 <fwp_main_thread+0x2308>
    a76c:	17ffff40 	b	a46c <fwp_main_thread+0x1ffc>
    a770:	f9400800 	ldr	x0, [x0, #16]
    a774:	b4ffe7c0 	cbz	x0, a46c <fwp_main_thread+0x1ffc>
    a778:	f9400001 	ldr	x1, [x0]
    a77c:	eb16003f 	cmp	x1, x22
    a780:	54ffff81 	b.ne	a770 <fwp_main_thread+0x2300>  // b.any
    a784:	f9400401 	ldr	x1, [x0, #8]
    a788:	d1000421 	sub	x1, x1, #0x1
    a78c:	f9000401 	str	x1, [x0, #8]
    a790:	f103f83f 	cmp	x1, #0xfe
    a794:	54ffaf01 	b.ne	9d74 <fwp_main_thread+0x1904>  // b.any
    a798:	aa1603e0 	mov	x0, x22
    a79c:	97ffe89d 	bl	4a10 <fwp_rc_forget_slot>
    a7a0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a7a4:	390002c0 	strb	w0, [x22]
    a7a8:	17fffd73 	b	9d74 <fwp_main_thread+0x1904>
    a7ac:	aa1603e0 	mov	x0, x22
    a7b0:	97ffe898 	bl	4a10 <fwp_rc_forget_slot>
    a7b4:	17fff90f 	b	8bf0 <fwp_main_thread+0x780>
    a7b8:	aa1603e0 	mov	x0, x22
    a7bc:	97ffe895 	bl	4a10 <fwp_rc_forget_slot>
    a7c0:	17fff932 	b	8c88 <fwp_main_thread+0x818>
    a7c4:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a7c8:	911d6000 	add	x0, x0, #0x758
    a7cc:	97ffe40d 	bl	3800 <fwp_trap>
    a7d0:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a7d4:	91164000 	add	x0, x0, #0x590
    a7d8:	97ffe40a 	bl	3800 <fwp_trap>
    a7dc:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a7e0:	911d2000 	add	x0, x0, #0x748
    a7e4:	97ffe407 	bl	3800 <fwp_trap>
    a7e8:	a91f73fb 	stp	x27, x28, [sp, #496]
    a7ec:	fd0103e8 	str	d8, [sp, #512]
    a7f0:	97ffe02c 	bl	28a0 <__stack_chk_fail@plt>
    a7f4:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a7f8:	911ae000 	add	x0, x0, #0x6b8
    a7fc:	a91f73fb 	stp	x27, x28, [sp, #496]
    a800:	fd0103e8 	str	d8, [sp, #512]
    a804:	97ffe2df 	bl	3380 <ad_raw_fail>
    a808:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a80c:	911e0000 	add	x0, x0, #0x780
    a810:	97ffe3fc 	bl	3800 <fwp_trap>
    a814:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a818:	911ca000 	add	x0, x0, #0x728
    a81c:	97ffe2d9 	bl	3380 <ad_raw_fail>
    a820:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a824:	911be000 	add	x0, x0, #0x6f8
    a828:	97ffe3f6 	bl	3800 <fwp_trap>
    a82c:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a830:	911a4000 	add	x0, x0, #0x690
    a834:	a91e6bf9 	stp	x25, x26, [sp, #480]
    a838:	a91f73fb 	stp	x27, x28, [sp, #496]
    a83c:	fd0103e8 	str	d8, [sp, #512]
    a840:	97ffe3f0 	bl	3800 <fwp_trap>
    a844:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a848:	911b6000 	add	x0, x0, #0x6d8
    a84c:	97ffe3ed 	bl	3800 <fwp_trap>
    a850:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a854:	91202000 	add	x0, x0, #0x808
    a858:	97ffe3ea 	bl	3800 <fwp_trap>
    a85c:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x70>
    a860:	91138000 	add	x0, x0, #0x4e0
    a864:	97ffe3e7 	bl	3800 <fwp_trap>
    a868:	97ffe086 	bl	2a80 <fwp_trap_overflow.constprop.0>
    a86c:	d503201f 	nop

000000000000a870 <__divti3>:
    a870:	d503245f 	bti	c
    a874:	d2800004 	mov	x4, #0x0                   	// #0
    a878:	b7f80721 	tbnz	x1, #63, a95c <__divti3+0xec>
    a87c:	b6f80083 	tbz	x3, #63, a88c <__divti3+0x1c>
    a880:	eb0203e2 	negs	x2, x2
    a884:	aa2403e4 	mvn	x4, x4
    a888:	da0303e3 	ngc	x3, x3
    a88c:	aa0203e6 	mov	x6, x2
    a890:	aa0003e7 	mov	x7, x0
    a894:	aa0103e5 	mov	x5, x1
    a898:	b5000583 	cbnz	x3, a948 <__divti3+0xd8>
    a89c:	eb01005f 	cmp	x2, x1
    a8a0:	54000e69 	b.ls	aa6c <__divti3+0x1fc>  // b.plast
    a8a4:	dac01040 	clz	x0, x2
    a8a8:	b40000e0 	cbz	x0, a8c4 <__divti3+0x54>
    a8ac:	4b0003e1 	neg	w1, w0
    a8b0:	9ac020a5 	lsl	x5, x5, x0
    a8b4:	9ac02046 	lsl	x6, x2, x0
    a8b8:	9ac124e1 	lsr	x1, x7, x1
    a8bc:	aa050025 	orr	x5, x1, x5
    a8c0:	9ac020e7 	lsl	x7, x7, x0
    a8c4:	d360fcc8 	lsr	x8, x6, #32
    a8c8:	92407cc2 	and	x2, x6, #0xffffffff
    a8cc:	9ac808a3 	udiv	x3, x5, x8
    a8d0:	9b089465 	msub	x5, x3, x8, x5
    a8d4:	aa0303e0 	mov	x0, x3
    a8d8:	9b037c41 	mul	x1, x2, x3
    a8dc:	93c780a5 	extr	x5, x5, x7, #32
    a8e0:	eb05003f 	cmp	x1, x5
    a8e4:	540000a9 	b.ls	a8f8 <__divti3+0x88>  // b.plast
    a8e8:	ab0500c5 	adds	x5, x6, x5
    a8ec:	d1000460 	sub	x0, x3, #0x1
    a8f0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a8f4:	540015a8 	b.hi	aba8 <__divti3+0x338>  // b.pmore
    a8f8:	cb0100a5 	sub	x5, x5, x1
    a8fc:	9ac808a3 	udiv	x3, x5, x8
    a900:	9b089465 	msub	x5, x3, x8, x5
    a904:	aa0303e1 	mov	x1, x3
    a908:	9b037c42 	mul	x2, x2, x3
    a90c:	aa0703e3 	mov	x3, x7
    a910:	b3607ca3 	bfi	x3, x5, #32, #32
    a914:	eb03005f 	cmp	x2, x3
    a918:	540000c9 	b.ls	a930 <__divti3+0xc0>  // b.plast
    a91c:	ab0300c3 	adds	x3, x6, x3
    a920:	d1000425 	sub	x5, x1, #0x1
    a924:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a928:	d1000821 	sub	x1, x1, #0x2
    a92c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a930:	aa008020 	orr	x0, x1, x0, lsl #32
    a934:	d2800001 	mov	x1, #0x0                   	// #0
    a938:	b4000064 	cbz	x4, a944 <__divti3+0xd4>
    a93c:	eb0003e0 	negs	x0, x0
    a940:	da0103e1 	ngc	x1, x1
    a944:	d65f03c0 	ret
    a948:	eb01007f 	cmp	x3, x1
    a94c:	54000109 	b.ls	a96c <__divti3+0xfc>  // b.plast
    a950:	d2800001 	mov	x1, #0x0                   	// #0
    a954:	d2800000 	mov	x0, #0x0                   	// #0
    a958:	17fffff8 	b	a938 <__divti3+0xc8>
    a95c:	eb0003e0 	negs	x0, x0
    a960:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a964:	da0103e1 	ngc	x1, x1
    a968:	17ffffc5 	b	a87c <__divti3+0xc>
    a96c:	dac01067 	clz	x7, x3
    a970:	b40010e7 	cbz	x7, ab8c <__divti3+0x31c>
    a974:	d2800805 	mov	x5, #0x40                  	// #64
    a978:	cb0700a5 	sub	x5, x5, x7
    a97c:	9ac72063 	lsl	x3, x3, x7
    a980:	9ac52448 	lsr	x8, x2, x5
    a984:	aa030108 	orr	x8, x8, x3
    a988:	9ac52426 	lsr	x6, x1, x5
    a98c:	92407d0a 	and	x10, x8, #0xffffffff
    a990:	d360fd09 	lsr	x9, x8, #32
    a994:	9ac52403 	lsr	x3, x0, x5
    a998:	9ac72021 	lsl	x1, x1, x7
    a99c:	aa010063 	orr	x3, x3, x1
    a9a0:	9ac72042 	lsl	x2, x2, x7
    a9a4:	9ac908cb 	udiv	x11, x6, x9
    a9a8:	9b099965 	msub	x5, x11, x9, x6
    a9ac:	aa0b03e1 	mov	x1, x11
    a9b0:	9b0b7d46 	mul	x6, x10, x11
    a9b4:	93c380a5 	extr	x5, x5, x3, #32
    a9b8:	eb0500df 	cmp	x6, x5
    a9bc:	540000a9 	b.ls	a9d0 <__divti3+0x160>  // b.plast
    a9c0:	ab050105 	adds	x5, x8, x5
    a9c4:	d1000561 	sub	x1, x11, #0x1
    a9c8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a9cc:	54000f48 	b.hi	abb4 <__divti3+0x344>  // b.pmore
    a9d0:	cb0600a6 	sub	x6, x5, x6
    a9d4:	9ac908cb 	udiv	x11, x6, x9
    a9d8:	9b099969 	msub	x9, x11, x9, x6
    a9dc:	aa0b03e5 	mov	x5, x11
    a9e0:	9b0b7d4a 	mul	x10, x10, x11
    a9e4:	b3607d23 	bfi	x3, x9, #32, #32
    a9e8:	eb03015f 	cmp	x10, x3
    a9ec:	540000a9 	b.ls	aa00 <__divti3+0x190>  // b.plast
    a9f0:	ab030103 	adds	x3, x8, x3
    a9f4:	d1000565 	sub	x5, x11, #0x1
    a9f8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a9fc:	54000e28 	b.hi	abc0 <__divti3+0x350>  // b.pmore
    aa00:	aa0180a1 	orr	x1, x5, x1, lsl #32
    aa04:	92407c48 	and	x8, x2, #0xffffffff
    aa08:	2a0503e5 	mov	w5, w5
    aa0c:	d360fc42 	lsr	x2, x2, #32
    aa10:	d360fc26 	lsr	x6, x1, #32
    aa14:	cb0a0063 	sub	x3, x3, x10
    aa18:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    aa1c:	9b087caa 	mul	x10, x5, x8
    aa20:	9b087cc8 	mul	x8, x6, x8
    aa24:	9b0220a5 	madd	x5, x5, x2, x8
    aa28:	9b027cc6 	mul	x6, x6, x2
    aa2c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    aa30:	8b0900c5 	add	x5, x6, x9
    aa34:	eb02011f 	cmp	x8, x2
    aa38:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    aa3c:	8b4280c6 	add	x6, x6, x2, lsr #32
    aa40:	eb06007f 	cmp	x3, x6
    aa44:	540000e3 	b.cc	aa60 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    aa48:	92407d4a 	and	x10, x10, #0xffffffff
    aa4c:	9ac72000 	lsl	x0, x0, x7
    aa50:	8b028142 	add	x2, x10, x2, lsl #32
    aa54:	eb02001f 	cmp	x0, x2
    aa58:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    aa5c:	54000a01 	b.ne	ab9c <__divti3+0x32c>  // b.any
    aa60:	d1000420 	sub	x0, x1, #0x1
    aa64:	d2800001 	mov	x1, #0x0                   	// #0
    aa68:	17ffffb4 	b	a938 <__divti3+0xc8>
    aa6c:	b5000062 	cbnz	x2, aa78 <__divti3+0x208>
    aa70:	d2800022 	mov	x2, #0x1                   	// #1
    aa74:	9ac30846 	udiv	x6, x2, x3
    aa78:	dac010c8 	clz	x8, x6
    aa7c:	b5000408 	cbnz	x8, aafc <__divti3+0x28c>
    aa80:	d360fcc9 	lsr	x9, x6, #32
    aa84:	92407cc5 	and	x5, x6, #0xffffffff
    aa88:	cb060023 	sub	x3, x1, x6
    aa8c:	d2800021 	mov	x1, #0x1                   	// #1
    aa90:	9ac90868 	udiv	x8, x3, x9
    aa94:	9b098d03 	msub	x3, x8, x9, x3
    aa98:	aa0803e0 	mov	x0, x8
    aa9c:	9b057d02 	mul	x2, x8, x5
    aaa0:	93c78063 	extr	x3, x3, x7, #32
    aaa4:	eb03005f 	cmp	x2, x3
    aaa8:	540000a9 	b.ls	aabc <__divti3+0x24c>  // b.plast
    aaac:	ab0300c3 	adds	x3, x6, x3
    aab0:	d1000500 	sub	x0, x8, #0x1
    aab4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    aab8:	54000968 	b.hi	abe4 <__divti3+0x374>  // b.pmore
    aabc:	cb020063 	sub	x3, x3, x2
    aac0:	9ac90862 	udiv	x2, x3, x9
    aac4:	aa0203e8 	mov	x8, x2
    aac8:	9b098c42 	msub	x2, x2, x9, x3
    aacc:	aa0703e3 	mov	x3, x7
    aad0:	9b057d05 	mul	x5, x8, x5
    aad4:	b3607c43 	bfi	x3, x2, #32, #32
    aad8:	eb0300bf 	cmp	x5, x3
    aadc:	540000c9 	b.ls	aaf4 <__divti3+0x284>  // b.plast
    aae0:	ab0300c2 	adds	x2, x6, x3
    aae4:	d1000503 	sub	x3, x8, #0x1
    aae8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    aaec:	d1000908 	sub	x8, x8, #0x2
    aaf0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    aaf4:	aa008100 	orr	x0, x8, x0, lsl #32
    aaf8:	17ffff90 	b	a938 <__divti3+0xc8>
    aafc:	9ac820c6 	lsl	x6, x6, x8
    ab00:	d2800803 	mov	x3, #0x40                  	// #64
    ab04:	cb080063 	sub	x3, x3, x8
    ab08:	d360fcc9 	lsr	x9, x6, #32
    ab0c:	9ac82027 	lsl	x7, x1, x8
    ab10:	92407cc5 	and	x5, x6, #0xffffffff
    ab14:	9ac32422 	lsr	x2, x1, x3
    ab18:	9ac32403 	lsr	x3, x0, x3
    ab1c:	aa070063 	orr	x3, x3, x7
    ab20:	9ac9084a 	udiv	x10, x2, x9
    ab24:	9ac82007 	lsl	x7, x0, x8
    ab28:	9b098940 	msub	x0, x10, x9, x2
    ab2c:	aa0a03e1 	mov	x1, x10
    ab30:	9b0a7ca2 	mul	x2, x5, x10
    ab34:	93c38000 	extr	x0, x0, x3, #32
    ab38:	eb00005f 	cmp	x2, x0
    ab3c:	540000a9 	b.ls	ab50 <__divti3+0x2e0>  // b.plast
    ab40:	ab0000c0 	adds	x0, x6, x0
    ab44:	d1000541 	sub	x1, x10, #0x1
    ab48:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    ab4c:	54000468 	b.hi	abd8 <__divti3+0x368>  // b.pmore
    ab50:	cb020000 	sub	x0, x0, x2
    ab54:	9ac9080a 	udiv	x10, x0, x9
    ab58:	9b098140 	msub	x0, x10, x9, x0
    ab5c:	aa0a03e2 	mov	x2, x10
    ab60:	9b0a7ca8 	mul	x8, x5, x10
    ab64:	b3607c03 	bfi	x3, x0, #32, #32
    ab68:	eb03011f 	cmp	x8, x3
    ab6c:	540000a9 	b.ls	ab80 <__divti3+0x310>  // b.plast
    ab70:	ab0300c3 	adds	x3, x6, x3
    ab74:	d1000542 	sub	x2, x10, #0x1
    ab78:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    ab7c:	54000288 	b.hi	abcc <__divti3+0x35c>  // b.pmore
    ab80:	cb080063 	sub	x3, x3, x8
    ab84:	aa018041 	orr	x1, x2, x1, lsl #32
    ab88:	17ffffc2 	b	aa90 <__divti3+0x220>
    ab8c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    ab90:	d2800001 	mov	x1, #0x0                   	// #0
    ab94:	9a9f87e0 	cset	x0, ls	// ls = plast
    ab98:	17ffff68 	b	a938 <__divti3+0xc8>
    ab9c:	aa0103e0 	mov	x0, x1
    aba0:	d2800001 	mov	x1, #0x0                   	// #0
    aba4:	17ffff65 	b	a938 <__divti3+0xc8>
    aba8:	d1000860 	sub	x0, x3, #0x2
    abac:	8b0600a5 	add	x5, x5, x6
    abb0:	17ffff52 	b	a8f8 <__divti3+0x88>
    abb4:	d1000961 	sub	x1, x11, #0x2
    abb8:	8b0800a5 	add	x5, x5, x8
    abbc:	17ffff85 	b	a9d0 <__divti3+0x160>
    abc0:	d1000965 	sub	x5, x11, #0x2
    abc4:	8b080063 	add	x3, x3, x8
    abc8:	17ffff8e 	b	aa00 <__divti3+0x190>
    abcc:	d1000942 	sub	x2, x10, #0x2
    abd0:	8b060063 	add	x3, x3, x6
    abd4:	17ffffeb 	b	ab80 <__divti3+0x310>
    abd8:	d1000941 	sub	x1, x10, #0x2
    abdc:	8b060000 	add	x0, x0, x6
    abe0:	17ffffdc 	b	ab50 <__divti3+0x2e0>
    abe4:	d1000900 	sub	x0, x8, #0x2
    abe8:	8b060063 	add	x3, x3, x6
    abec:	17ffffb4 	b	aabc <__divti3+0x24c>

000000000000abf0 <__modti3>:
    abf0:	d503245f 	bti	c
    abf4:	d2800004 	mov	x4, #0x0                   	// #0
    abf8:	b6f80081 	tbz	x1, #63, ac08 <__modti3+0x18>
    abfc:	eb0003e0 	negs	x0, x0
    ac00:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ac04:	da0103e1 	ngc	x1, x1
    ac08:	f100007f 	cmp	x3, #0x0
    ac0c:	5400128b 	b.lt	ae5c <__modti3+0x26c>  // b.tstop
    ac10:	aa0003e7 	mov	x7, x0
    ac14:	aa0103e6 	mov	x6, x1
    ac18:	540004e1 	b.ne	acb4 <__modti3+0xc4>  // b.any
    ac1c:	eb02003f 	cmp	x1, x2
    ac20:	54000dc2 	b.cs	add8 <__modti3+0x1e8>  // b.hs, b.nlast
    ac24:	dac01043 	clz	x3, x2
    ac28:	aa0303e5 	mov	x5, x3
    ac2c:	b40000e3 	cbz	x3, ac48 <__modti3+0x58>
    ac30:	4b0303e6 	neg	w6, w3
    ac34:	9ac32021 	lsl	x1, x1, x3
    ac38:	9ac32042 	lsl	x2, x2, x3
    ac3c:	9ac62406 	lsr	x6, x0, x6
    ac40:	aa0100c6 	orr	x6, x6, x1
    ac44:	9ac32007 	lsl	x7, x0, x3
    ac48:	d360fc40 	lsr	x0, x2, #32
    ac4c:	92407c43 	and	x3, x2, #0xffffffff
    ac50:	9ac008c1 	udiv	x1, x6, x0
    ac54:	9b009826 	msub	x6, x1, x0, x6
    ac58:	9b017c61 	mul	x1, x3, x1
    ac5c:	93c780c6 	extr	x6, x6, x7, #32
    ac60:	eb06003f 	cmp	x1, x6
    ac64:	540000a9 	b.ls	ac78 <__modti3+0x88>  // b.plast
    ac68:	ab060046 	adds	x6, x2, x6
    ac6c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    ac70:	8b0200c8 	add	x8, x6, x2
    ac74:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    ac78:	cb0100c6 	sub	x6, x6, x1
    ac7c:	9ac008c8 	udiv	x8, x6, x0
    ac80:	9b009901 	msub	x1, x8, x0, x6
    ac84:	aa0703e0 	mov	x0, x7
    ac88:	9b087c63 	mul	x3, x3, x8
    ac8c:	b3607c20 	bfi	x0, x1, #32, #32
    ac90:	eb00007f 	cmp	x3, x0
    ac94:	54001088 	b.hi	aea4 <__modti3+0x2b4>  // b.pmore
    ac98:	cb030000 	sub	x0, x0, x3
    ac9c:	9ac52400 	lsr	x0, x0, x5
    aca0:	d2800001 	mov	x1, #0x0                   	// #0
    aca4:	b4000064 	cbz	x4, acb0 <__modti3+0xc0>
    aca8:	eb0003e0 	negs	x0, x0
    acac:	da0103e1 	ngc	x1, x1
    acb0:	d65f03c0 	ret
    acb4:	dac01066 	clz	x6, x3
    acb8:	eb03003f 	cmp	x1, x3
    acbc:	54ffff43 	b.cc	aca4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    acc0:	93407cc5 	sxtw	x5, w6
    acc4:	d2800808 	mov	x8, #0x40                  	// #64
    acc8:	cb050108 	sub	x8, x8, x5
    accc:	9ac62063 	lsl	x3, x3, x6
    acd0:	9ac62025 	lsl	x5, x1, x6
    acd4:	9ac82447 	lsr	x7, x2, x8
    acd8:	aa0300e7 	orr	x7, x7, x3
    acdc:	9ac82423 	lsr	x3, x1, x8
    ace0:	92407cec 	and	x12, x7, #0xffffffff
    ace4:	d360fcea 	lsr	x10, x7, #32
    ace8:	9ac82401 	lsr	x1, x0, x8
    acec:	aa050021 	orr	x1, x1, x5
    acf0:	9ac62042 	lsl	x2, x2, x6
    acf4:	9ac62000 	lsl	x0, x0, x6
    acf8:	9aca086b 	udiv	x11, x3, x10
    acfc:	9b0a8d63 	msub	x3, x11, x10, x3
    ad00:	aa0b03e5 	mov	x5, x11
    ad04:	9b0b7d89 	mul	x9, x12, x11
    ad08:	93c18063 	extr	x3, x3, x1, #32
    ad0c:	eb03013f 	cmp	x9, x3
    ad10:	540000a9 	b.ls	ad24 <__modti3+0x134>  // b.plast
    ad14:	ab0300e3 	adds	x3, x7, x3
    ad18:	d1000565 	sub	x5, x11, #0x1
    ad1c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ad20:	54001168 	b.hi	af4c <__modti3+0x35c>  // b.pmore
    ad24:	cb090063 	sub	x3, x3, x9
    ad28:	9aca086b 	udiv	x11, x3, x10
    ad2c:	9b0a8d6a 	msub	x10, x11, x10, x3
    ad30:	aa0b03e9 	mov	x9, x11
    ad34:	9b0b7d8c 	mul	x12, x12, x11
    ad38:	b3607d41 	bfi	x1, x10, #32, #32
    ad3c:	eb01019f 	cmp	x12, x1
    ad40:	540000a9 	b.ls	ad54 <__modti3+0x164>  // b.plast
    ad44:	ab0100e1 	adds	x1, x7, x1
    ad48:	d1000569 	sub	x9, x11, #0x1
    ad4c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    ad50:	54000f88 	b.hi	af40 <__modti3+0x350>  // b.pmore
    ad54:	aa058123 	orr	x3, x9, x5, lsl #32
    ad58:	92407c4b 	and	x11, x2, #0xffffffff
    ad5c:	2a0903e9 	mov	w9, w9
    ad60:	d360fc4a 	lsr	x10, x2, #32
    ad64:	d360fc63 	lsr	x3, x3, #32
    ad68:	cb0c0021 	sub	x1, x1, x12
    ad6c:	aa0a03ec 	mov	x12, x10
    ad70:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    ad74:	9b0b7d25 	mul	x5, x9, x11
    ad78:	9b0b7c6b 	mul	x11, x3, x11
    ad7c:	9b0a2d29 	madd	x9, x9, x10, x11
    ad80:	92407caa 	and	x10, x5, #0xffffffff
    ad84:	9b0c7c63 	mul	x3, x3, x12
    ad88:	8b458125 	add	x5, x9, x5, lsr #32
    ad8c:	8b0d0069 	add	x9, x3, x13
    ad90:	eb05017f 	cmp	x11, x5
    ad94:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    ad98:	8b058149 	add	x9, x10, x5, lsl #32
    ad9c:	8b458063 	add	x3, x3, x5, lsr #32
    ada0:	eb03003f 	cmp	x1, x3
    ada4:	54000063 	b.cc	adb0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    ada8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    adac:	54000082 	b.cs	adbc <__modti3+0x1cc>  // b.hs, b.nlast
    adb0:	eb020129 	subs	x9, x9, x2
    adb4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    adb8:	cb070063 	sub	x3, x3, x7
    adbc:	eb090000 	subs	x0, x0, x9
    adc0:	da030021 	sbc	x1, x1, x3
    adc4:	9ac62400 	lsr	x0, x0, x6
    adc8:	9ac82028 	lsl	x8, x1, x8
    adcc:	aa000100 	orr	x0, x8, x0
    add0:	9ac62421 	lsr	x1, x1, x6
    add4:	17ffffb4 	b	aca4 <__modti3+0xb4>
    add8:	b5000062 	cbnz	x2, ade4 <__modti3+0x1f4>
    addc:	d2800023 	mov	x3, #0x1                   	// #1
    ade0:	9ac20862 	udiv	x2, x3, x2
    ade4:	dac01048 	clz	x8, x2
    ade8:	aa0803e5 	mov	x5, x8
    adec:	b5000668 	cbnz	x8, aeb8 <__modti3+0x2c8>
    adf0:	cb020020 	sub	x0, x1, x2
    adf4:	d360fc49 	lsr	x9, x2, #32
    adf8:	92407c4a 	and	x10, x2, #0xffffffff
    adfc:	9ac90801 	udiv	x1, x0, x9
    ae00:	9b098020 	msub	x0, x1, x9, x0
    ae04:	9b0a7c21 	mul	x1, x1, x10
    ae08:	93c78000 	extr	x0, x0, x7, #32
    ae0c:	eb00003f 	cmp	x1, x0
    ae10:	540000a9 	b.ls	ae24 <__modti3+0x234>  // b.plast
    ae14:	ab000040 	adds	x0, x2, x0
    ae18:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ae1c:	8b020003 	add	x3, x0, x2
    ae20:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ae24:	cb010001 	sub	x1, x0, x1
    ae28:	9ac90820 	udiv	x0, x1, x9
    ae2c:	9b098403 	msub	x3, x0, x9, x1
    ae30:	aa0703e1 	mov	x1, x7
    ae34:	9b0a7c00 	mul	x0, x0, x10
    ae38:	b3607c61 	bfi	x1, x3, #32, #32
    ae3c:	eb01001f 	cmp	x0, x1
    ae40:	540000a9 	b.ls	ae54 <__modti3+0x264>  // b.plast
    ae44:	ab010041 	adds	x1, x2, x1
    ae48:	8b020022 	add	x2, x1, x2
    ae4c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    ae50:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    ae54:	cb000020 	sub	x0, x1, x0
    ae58:	17ffff91 	b	ac9c <__modti3+0xac>
    ae5c:	eb0203e5 	negs	x5, x2
    ae60:	aa0003e7 	mov	x7, x0
    ae64:	da0303e8 	ngc	x8, x3
    ae68:	aa0503e2 	mov	x2, x5
    ae6c:	aa0803e3 	mov	x3, x8
    ae70:	aa0103e6 	mov	x6, x1
    ae74:	b4ffed48 	cbz	x8, ac1c <__modti3+0x2c>
    ae78:	eb01011f 	cmp	x8, x1
    ae7c:	54fff148 	b.hi	aca4 <__modti3+0xb4>  // b.pmore
    ae80:	dac01109 	clz	x9, x8
    ae84:	2a0903e6 	mov	w6, w9
    ae88:	b5fff1c9 	cbnz	x9, acc0 <__modti3+0xd0>
    ae8c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    ae90:	54000068 	b.hi	ae9c <__modti3+0x2ac>  // b.pmore
    ae94:	eb050007 	subs	x7, x0, x5
    ae98:	da080021 	sbc	x1, x1, x8
    ae9c:	aa0703e0 	mov	x0, x7
    aea0:	17ffff81 	b	aca4 <__modti3+0xb4>
    aea4:	ab000040 	adds	x0, x2, x0
    aea8:	8b020002 	add	x2, x0, x2
    aeac:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    aeb0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    aeb4:	17ffff79 	b	ac98 <__modti3+0xa8>
    aeb8:	9ac82042 	lsl	x2, x2, x8
    aebc:	d2800803 	mov	x3, #0x40                  	// #64
    aec0:	cb080063 	sub	x3, x3, x8
    aec4:	d360fc49 	lsr	x9, x2, #32
    aec8:	9ac82027 	lsl	x7, x1, x8
    aecc:	92407c4a 	and	x10, x2, #0xffffffff
    aed0:	9ac32426 	lsr	x6, x1, x3
    aed4:	9ac32403 	lsr	x3, x0, x3
    aed8:	aa070063 	orr	x3, x3, x7
    aedc:	9ac908c1 	udiv	x1, x6, x9
    aee0:	9ac82007 	lsl	x7, x0, x8
    aee4:	9b099820 	msub	x0, x1, x9, x6
    aee8:	9b017d41 	mul	x1, x10, x1
    aeec:	93c38000 	extr	x0, x0, x3, #32
    aef0:	eb00003f 	cmp	x1, x0
    aef4:	540000a9 	b.ls	af08 <__modti3+0x318>  // b.plast
    aef8:	ab000040 	adds	x0, x2, x0
    aefc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    af00:	8b020006 	add	x6, x0, x2
    af04:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    af08:	cb010000 	sub	x0, x0, x1
    af0c:	9ac90801 	udiv	x1, x0, x9
    af10:	9b098026 	msub	x6, x1, x9, x0
    af14:	aa0303e0 	mov	x0, x3
    af18:	9b017d41 	mul	x1, x10, x1
    af1c:	b3607cc0 	bfi	x0, x6, #32, #32
    af20:	eb00003f 	cmp	x1, x0
    af24:	540000a9 	b.ls	af38 <__modti3+0x348>  // b.plast
    af28:	ab000040 	adds	x0, x2, x0
    af2c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    af30:	8b020003 	add	x3, x0, x2
    af34:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    af38:	cb010000 	sub	x0, x0, x1
    af3c:	17ffffb0 	b	adfc <__modti3+0x20c>
    af40:	d1000969 	sub	x9, x11, #0x2
    af44:	8b070021 	add	x1, x1, x7
    af48:	17ffff83 	b	ad54 <__modti3+0x164>
    af4c:	d1000965 	sub	x5, x11, #0x2
    af50:	8b070063 	add	x3, x3, x7
    af54:	17ffff74 	b	ad24 <__modti3+0x134>
    af58:	d503201f 	nop
    af5c:	d503201f 	nop

000000000000af60 <atexit>:
    af60:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    af64:	d00000a2 	adrp	x2, 20000 <__data_start>
    af68:	d2800001 	mov	x1, #0x0                   	// #0
    af6c:	910003fd 	mov	x29, sp
    af70:	a8c17bfd 	ldp	x29, x30, [sp], #16
    af74:	f9400442 	ldr	x2, [x2, #8]
    af78:	17ffde0a 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000af7c <_fini>:
    af7c:	d503201f 	nop
    af80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    af84:	910003fd 	mov	x29, sp
    af88:	a8c17bfd 	ldp	x29, x30, [sp], #16
    af8c:	d65f03c0 	ret
