
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history-reference:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	b0000045 	adrp	x5, b000 <__modti3+0x30>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	9115c0a5 	add	x5, x5, #0x570
    2a20:	b0000044 	adrp	x4, b000 <__modti3+0x30>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	9115e084 	add	x4, x4, #0x578
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940002ac 	bl	3500 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91010261 	add	x1, x19, #0x40
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10c10>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9001c20 	str	x0, [x1, #56]
    2aac:	940002f5 	bl	3680 <fwp_now_ns>
    2ab0:	b0000040 	adrp	x0, b000 <__modti3+0x30>
    2ab4:	91254000 	add	x0, x0, #0x950
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0xa40>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	9116c042 	add	x2, x2, #0x5b0
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91010273 	add	x19, x19, #0x40
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9430a60 	ldr	w0, [x19, #776]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff44 	bl	28e0 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	b0000040 	adrp	x0, b000 <__modti3+0x30>
    2bfc:	91258000 	add	x0, x0, #0x960
    2c00:	94000240 	bl	3500 <fwp_trap>
    2c04:	97fffefb 	bl	27f0 <__stack_chk_fail@plt>
    2c08:	b0000040 	adrp	x0, b000 <__modti3+0x30>
    2c0c:	91280000 	add	x0, x0, #0xa00
    2c10:	9400023c 	bl	3500 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffee2 	bl	27a0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	b0000040 	adrp	x0, b000 <__modti3+0x30>
    2c24:	91276000 	add	x0, x0, #0x9d8
    2c28:	94000236 	bl	3500 <fwp_trap>
    2c2c:	b0000040 	adrp	x0, b000 <__modti3+0x30>
    2c30:	9126a000 	add	x0, x0, #0x9a8
    2c34:	94000233 	bl	3500 <fwp_trap>
    2c38:	b0000040 	adrp	x0, b000 <__modti3+0x30>
    2c3c:	91260000 	add	x0, x0, #0x980
    2c40:	94000230 	bl	3500 <fwp_trap>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	9100a000 	add	x0, x0, #0x28
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	9100a021 	add	x1, x1, #0x28
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	9100a000 	add	x0, x0, #0x28
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	9100a021 	add	x1, x1, #0x28
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	3940c260 	ldrb	w0, [x19, #48]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	3900c260 	strb	w0, [x19, #48]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	d0000041 	adrp	x1, c000 <msg.4+0x20>
    2e34:	91000021 	add	x1, x1, #0x0
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9402084 	ldr	x4, [x4, #64]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9402063 	ldr	x3, [x3, #64]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9402400 	ldr	x0, [x0, #72]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	b0000040 	adrp	x0, b000 <__modti3+0x30>
    2fd0:	910de000 	add	x0, x0, #0x378
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	91010043 	add	x3, x2, #0x40
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	91010042 	add	x2, x2, #0x40
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	90000041 	adrp	x1, b000 <__modti3+0x30>
    3098:	913f8021 	add	x1, x1, #0xfe0
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    30c4:	911542a1 	add	x1, x21, #0x550
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    30d8:	912500a5 	add	x5, x5, #0x940
    30dc:	911542a1 	add	x1, x21, #0x550
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	911542b7 	add	x23, x21, #0x550
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	911542b5 	add	x21, x21, #0x550
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	911542b5 	add	x21, x21, #0x550
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    3268:	9124e0a5 	add	x5, x5, #0x938
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	90000040 	adrp	x0, b000 <__modti3+0x30>
    3370:	910de000 	add	x0, x0, #0x378
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	91010022 	add	x2, x1, #0x40
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	91010021 	add	x1, x1, #0x40
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	90000041 	adrp	x1, b000 <__modti3+0x30>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	910e4021 	add	x1, x1, #0x390
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	90000041 	adrp	x1, b000 <__modti3+0x30>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	910e6021 	add	x1, x1, #0x398
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	90000041 	adrp	x1, b000 <__modti3+0x30>
    34e0:	910e8021 	add	x1, x1, #0x3a0
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_trap>:
    3500:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3504:	d53bd041 	mrs	x1, tpidr_el0
    3508:	91400021 	add	x1, x1, #0x0, lsl #12
    350c:	91004021 	add	x1, x1, #0x10
    3510:	910003fd 	mov	x29, sp
    3514:	a90153f3 	stp	x19, x20, [sp, #16]
    3518:	aa0003f3 	mov	x19, x0
    351c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    3520:	f947ea94 	ldr	x20, [x20, #4048]
    3524:	f90013f5 	str	x21, [sp, #32]
    3528:	f9400035 	ldr	x21, [x1]
    352c:	97fffe91 	bl	2f70 <fwp_flush>
    3530:	f9400280 	ldr	x0, [x20]
    3534:	90000042 	adrp	x2, b000 <__modti3+0x30>
    3538:	aa1303e3 	mov	x3, x19
    353c:	910ea042 	add	x2, x2, #0x3a8
    3540:	52800041 	mov	w1, #0x2                   	// #2
    3544:	97fffcc7 	bl	2860 <__fprintf_chk@plt>
    3548:	b40000b5 	cbz	x21, 355c <fwp_trap+0x5c>
    354c:	f9400280 	ldr	x0, [x20]
    3550:	97fffcf4 	bl	2920 <fflush@plt>
    3554:	52800ca0 	mov	w0, #0x65                  	// #101
    3558:	97fffd02 	bl	2960 <_Exit@plt>
    355c:	52800ca0 	mov	w0, #0x65                  	// #101
    3560:	97fffc50 	bl	26a0 <exit@plt>

0000000000003564 <fwp_closure_drop_push>:
    3564:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3568:	910003fd 	mov	x29, sp
    356c:	a90153f3 	stp	x19, x20, [sp, #16]
    3570:	aa0003f3 	mov	x19, x0
    3574:	a9408014 	ldp	x20, x0, [x0, #8]
    3578:	a9025bf5 	stp	x21, x22, [sp, #32]
    357c:	aa0103f5 	mov	x21, x1
    3580:	a90363f7 	stp	x23, x24, [sp, #48]
    3584:	eb00029f 	cmp	x20, x0
    3588:	54000160 	b.eq	35b4 <fwp_closure_drop_push+0x50>  // b.none
    358c:	f9400276 	ldr	x22, [x19]
    3590:	d37df297 	lsl	x23, x20, #3
    3594:	91000694 	add	x20, x20, #0x1
    3598:	f9000674 	str	x20, [x19, #8]
    359c:	a94153f3 	ldp	x19, x20, [sp, #16]
    35a0:	f8376ad5 	str	x21, [x22, x23]
    35a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    35a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    35ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    35b0:	d65f03c0 	ret
    35b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    35b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    35bc:	eb00029f 	cmp	x20, x0
    35c0:	54000568 	b.hi	366c <fwp_closure_drop_push+0x108>  // b.pmore
    35c4:	d37cee99 	lsl	x25, x20, #4
    35c8:	d37ffa9a 	lsl	x26, x20, #1
    35cc:	aa1903e0 	mov	x0, x25
    35d0:	97fffc70 	bl	2790 <malloc@plt>
    35d4:	aa0003f6 	mov	x22, x0
    35d8:	b4000320 	cbz	x0, 363c <fwp_closure_drop_push+0xd8>
    35dc:	aa1303f8 	mov	x24, x19
    35e0:	aa1903e3 	mov	x3, x25
    35e4:	d37df297 	lsl	x23, x20, #3
    35e8:	aa1703e2 	mov	x2, x23
    35ec:	f8418719 	ldr	x25, [x24], #24
    35f0:	aa1903e1 	mov	x1, x25
    35f4:	97fffc53 	bl	2740 <__memcpy_chk@plt>
    35f8:	eb18033f 	cmp	x25, x24
    35fc:	540000a0 	b.eq	3610 <fwp_closure_drop_push+0xac>  // b.none
    3600:	aa1903e0 	mov	x0, x25
    3604:	97fffcab 	bl	28b0 <free@plt>
    3608:	f9400674 	ldr	x20, [x19, #8]
    360c:	d37df297 	lsl	x23, x20, #3
    3610:	91000694 	add	x20, x20, #0x1
    3614:	f9000276 	str	x22, [x19]
    3618:	f9000a7a 	str	x26, [x19, #16]
    361c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3620:	f9000674 	str	x20, [x19, #8]
    3624:	f8376ad5 	str	x21, [x22, x23]
    3628:	a94153f3 	ldp	x19, x20, [sp, #16]
    362c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3630:	a94363f7 	ldp	x23, x24, [sp, #48]
    3634:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3638:	d65f03c0 	ret
    363c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3640:	f947e863 	ldr	x3, [x3, #4048]
    3644:	d2800262 	mov	x2, #0x13                  	// #19
    3648:	d2800021 	mov	x1, #0x1                   	// #1
    364c:	90000040 	adrp	x0, b000 <__modti3+0x30>
    3650:	910de000 	add	x0, x0, #0x378
    3654:	f9400063 	ldr	x3, [x3]
    3658:	97fffca6 	bl	28f0 <fwrite@plt>
    365c:	d2800000 	mov	x0, #0x0                   	// #0
    3660:	97fffcb0 	bl	2920 <fflush@plt>
    3664:	52800cc0 	mov	w0, #0x66                  	// #102
    3668:	97fffcbe 	bl	2960 <_Exit@plt>
    366c:	90000040 	adrp	x0, b000 <__modti3+0x30>
    3670:	910ee000 	add	x0, x0, #0x3b8
    3674:	97ffffa3 	bl	3500 <fwp_trap>
    3678:	d503201f 	nop
    367c:	d503201f 	nop

0000000000003680 <fwp_now_ns>:
    3680:	d100c3ff 	sub	sp, sp, #0x30
    3684:	52800020 	mov	w0, #0x1                   	// #1
    3688:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    368c:	f947f442 	ldr	x2, [x2, #4072]
    3690:	910023e1 	add	x1, sp, #0x8
    3694:	a9027bfd 	stp	x29, x30, [sp, #32]
    3698:	910083fd 	add	x29, sp, #0x20
    369c:	f9400043 	ldr	x3, [x2]
    36a0:	f9000fe3 	str	x3, [sp, #24]
    36a4:	d2800003 	mov	x3, #0x0                   	// #0
    36a8:	97fffc1e 	bl	2720 <clock_gettime@plt>
    36ac:	350002c0 	cbnz	w0, 3704 <fwp_now_ns+0x84>
    36b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    36b4:	d2994003 	mov	x3, #0xca00                	// #51712
    36b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    36bc:	9b037c20 	mul	x0, x1, x3
    36c0:	9b437c21 	smulh	x1, x1, x3
    36c4:	ab020000 	adds	x0, x0, x2
    36c8:	937ffc42 	asr	x2, x2, #63
    36cc:	9a020021 	adc	x1, x1, x2
    36d0:	f100001f 	cmp	x0, #0x0
    36d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    36d8:	b50001e1 	cbnz	x1, 3714 <fwp_now_ns+0x94>
    36dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    36e0:	f947f421 	ldr	x1, [x1, #4072]
    36e4:	f9400fe3 	ldr	x3, [sp, #24]
    36e8:	f9400022 	ldr	x2, [x1]
    36ec:	eb020063 	subs	x3, x3, x2
    36f0:	d2800002 	mov	x2, #0x0                   	// #0
    36f4:	540000e1 	b.ne	3710 <fwp_now_ns+0x90>  // b.any
    36f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    36fc:	9100c3ff 	add	sp, sp, #0x30
    3700:	d65f03c0 	ret
    3704:	90000040 	adrp	x0, b000 <__modti3+0x30>
    3708:	910f6000 	add	x0, x0, #0x3d8
    370c:	97ffff7d 	bl	3500 <fwp_trap>
    3710:	97fffc38 	bl	27f0 <__stack_chk_fail@plt>
    3714:	90000040 	adrp	x0, b000 <__modti3+0x30>
    3718:	910fe000 	add	x0, x0, #0x3f8
    371c:	97ffff79 	bl	3500 <fwp_trap>

0000000000003720 <fwp_closure_drop.part.0>:
    3720:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3724:	b0000041 	adrp	x1, c000 <msg.4+0x20>
    3728:	910003fd 	mov	x29, sp
    372c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3730:	f947f463 	ldr	x3, [x3, #4072]
    3734:	a90153f3 	stp	x19, x20, [sp, #16]
    3738:	d10883ff 	sub	sp, sp, #0x220
    373c:	910003e2 	mov	x2, sp
    3740:	d53bd053 	mrs	x19, tpidr_el0
    3744:	910063f4 	add	x20, sp, #0x18
    3748:	3dc00420 	ldr	q0, [x1, #16]
    374c:	91400264 	add	x4, x19, #0x0, lsl #12
    3750:	91004084 	add	x4, x4, #0x10
    3754:	aa0003e1 	mov	x1, x0
    3758:	aa0203e0 	mov	x0, x2
    375c:	f9400062 	ldr	x2, [x3]
    3760:	f9010fe2 	str	x2, [sp, #536]
    3764:	d2800002 	mov	x2, #0x0                   	// #0
    3768:	f90003f4 	str	x20, [sp]
    376c:	f9000080 	str	x0, [x4]
    3770:	3c8083e0 	stur	q0, [sp, #8]
    3774:	97ffff7c 	bl	3564 <fwp_closure_drop_push>
    3778:	f94007e0 	ldr	x0, [sp, #8]
    377c:	b4000280 	cbz	x0, 37cc <fwp_closure_drop.part.0+0xac>
    3780:	f90123f5 	str	x21, [sp, #576]
    3784:	b00000f5 	adrp	x21, 20000 <__data_start>
    3788:	910102b5 	add	x21, x21, #0x40
    378c:	d503201f 	nop
    3790:	f94003e1 	ldr	x1, [sp]
    3794:	d1000400 	sub	x0, x0, #0x1
    3798:	f90007e0 	str	x0, [sp, #8]
    379c:	f9401ea2 	ldr	x2, [x21, #56]
    37a0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    37a4:	b9400001 	ldr	w1, [x0]
    37a8:	8b011441 	add	x1, x2, x1, lsl #5
    37ac:	f9400c21 	ldr	x1, [x1, #24]
    37b0:	b4000321 	cbz	x1, 3814 <fwp_closure_drop.part.0+0xf4>
    37b4:	f9400422 	ldr	x2, [x1, #8]
    37b8:	52800001 	mov	w1, #0x0                   	// #0
    37bc:	d63f0040 	blr	x2
    37c0:	f94007e0 	ldr	x0, [sp, #8]
    37c4:	b5fffe60 	cbnz	x0, 3790 <fwp_closure_drop.part.0+0x70>
    37c8:	f94123f5 	ldr	x21, [sp, #576]
    37cc:	91400273 	add	x19, x19, #0x0, lsl #12
    37d0:	91004273 	add	x19, x19, #0x10
    37d4:	f94003e0 	ldr	x0, [sp]
    37d8:	f900027f 	str	xzr, [x19]
    37dc:	eb14001f 	cmp	x0, x20
    37e0:	54000040 	b.eq	37e8 <fwp_closure_drop.part.0+0xc8>  // b.none
    37e4:	97fffc33 	bl	28b0 <free@plt>
    37e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    37ec:	f947f400 	ldr	x0, [x0, #4072]
    37f0:	f9410fe2 	ldr	x2, [sp, #536]
    37f4:	f9400001 	ldr	x1, [x0]
    37f8:	eb010042 	subs	x2, x2, x1
    37fc:	d2800001 	mov	x1, #0x0                   	// #0
    3800:	54000101 	b.ne	3820 <fwp_closure_drop.part.0+0x100>  // b.any
    3804:	910883ff 	add	sp, sp, #0x220
    3808:	a94153f3 	ldp	x19, x20, [sp, #16]
    380c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3810:	d65f03c0 	ret
    3814:	90000040 	adrp	x0, b000 <__modti3+0x30>
    3818:	91108000 	add	x0, x0, #0x420
    381c:	97ffff39 	bl	3500 <fwp_trap>
    3820:	f90123f5 	str	x21, [sp, #576]
    3824:	97fffbf3 	bl	27f0 <__stack_chk_fail@plt>
    3828:	d503201f 	nop
    382c:	d503201f 	nop

0000000000003830 <fwp_tape_of>:
    3830:	92403c02 	and	x2, x0, #0xffff
    3834:	b4000262 	cbz	x2, 3880 <fwp_tape_of+0x50>
    3838:	9350fc01 	asr	x1, x0, #16
    383c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3840:	d1000440 	sub	x0, x2, #0x1
    3844:	91010062 	add	x2, x3, #0x40
    3848:	f9402042 	ldr	x2, [x2, #64]
    384c:	eb00005f 	cmp	x2, x0
    3850:	5400018d 	b.le	3880 <fwp_tape_of+0x50>
    3854:	8b000402 	add	x2, x0, x0, lsl #1
    3858:	f9402063 	ldr	x3, [x3, #64]
    385c:	8b020802 	add	x2, x0, x2, lsl #2
    3860:	d37df042 	lsl	x2, x2, #3
    3864:	8b020060 	add	x0, x3, x2
    3868:	b9400404 	ldr	w4, [x0, #4]
    386c:	340000a4 	cbz	w4, 3880 <fwp_tape_of+0x50>
    3870:	b8626862 	ldr	w2, [x3, x2]
    3874:	6b01005f 	cmp	w2, w1
    3878:	54000041 	b.ne	3880 <fwp_tape_of+0x50>  // b.any
    387c:	d65f03c0 	ret
    3880:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3884:	90000040 	adrp	x0, b000 <__modti3+0x30>
    3888:	91114000 	add	x0, x0, #0x450
    388c:	910003fd 	mov	x29, sp
    3890:	97ffff1c 	bl	3500 <fwp_trap>

0000000000003894 <fwp_format_g.constprop.0>:
    3894:	d10483ff 	sub	sp, sp, #0x120
    3898:	90000044 	adrp	x4, b000 <__modti3+0x30>
    389c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    38a0:	f947f442 	ldr	x2, [x2, #4072]
    38a4:	91128084 	add	x4, x4, #0x4a0
    38a8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    38ac:	9102c3fd 	add	x29, sp, #0xb0
    38b0:	d2800803 	mov	x3, #0x40                  	// #64
    38b4:	a90e63f7 	stp	x23, x24, [sp, #224]
    38b8:	93407c38 	sxtw	x24, w1
    38bc:	aa0303e1 	mov	x1, x3
    38c0:	fd008be8 	str	d8, [sp, #272]
    38c4:	1e604008 	fmov	d8, d0
    38c8:	a90c53f3 	stp	x19, x20, [sp, #192]
    38cc:	910083f4 	add	x20, sp, #0x20
    38d0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38d4:	aa0003f5 	mov	x21, x0
    38d8:	a91073fb 	stp	x27, x28, [sp, #256]
    38dc:	5100071c 	sub	w28, w24, #0x1
    38e0:	2a1c03e5 	mov	w5, w28
    38e4:	f9400040 	ldr	x0, [x2]
    38e8:	f90057e0 	str	x0, [sp, #168]
    38ec:	d2800000 	mov	x0, #0x0                   	// #0
    38f0:	52800042 	mov	w2, #0x2                   	// #2
    38f4:	aa1403e0 	mov	x0, x20
    38f8:	97fffb9a 	bl	2760 <__snprintf_chk@plt>
    38fc:	52800ca1 	mov	w1, #0x65                  	// #101
    3900:	aa1403e0 	mov	x0, x20
    3904:	97fffbf3 	bl	28d0 <strchr@plt>
    3908:	aa0003f3 	mov	x19, x0
    390c:	52800142 	mov	w2, #0xa                   	// #10
    3910:	91000400 	add	x0, x0, #0x1
    3914:	d2800001 	mov	x1, #0x0                   	// #0
    3918:	97fffbde 	bl	2890 <strtol@plt>
    391c:	aa0003f7 	mov	x23, x0
    3920:	11001400 	add	w0, w0, #0x5
    3924:	7100541f 	cmp	w0, #0x15
    3928:	54000d88 	b.hi	3ad8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    392c:	4b170385 	sub	w5, w28, w23
    3930:	710000bf 	cmp	w5, #0x0
    3934:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3938:	54000ba0 	b.eq	3aac <fwp_format_g.constprop.0+0x218>  // b.none
    393c:	394083e0 	ldrb	w0, [sp, #32]
    3940:	cb180273 	sub	x19, x19, x24
    3944:	91000673 	add	x19, x19, #0x1
    3948:	a90f6bf9 	stp	x25, x26, [sp, #240]
    394c:	7100b41f 	cmp	w0, #0x2d
    3950:	9a941681 	cinc	x1, x20, eq	// eq = none
    3954:	1a9f17e4 	cset	w4, eq	// eq = none
    3958:	cb010266 	sub	x6, x19, x1
    395c:	d10004da 	sub	x26, x6, #0x1
    3960:	540018c0 	b.eq	3c78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d280091b 	mov	x27, #0x48                  	// #72
    396c:	aa1903e7 	mov	x7, x25
    3970:	91000423 	add	x3, x1, #0x1
    3974:	91011cc6 	add	x6, x6, #0x47
    3978:	910004f6 	add	x22, x7, #0x1
    397c:	37f81017 	tbnz	w23, #31, 3b7c <fwp_format_g.constprop.0+0x2e8>
    3980:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3984:	93407ef7 	sxtw	x23, w23
    3988:	390000e4 	strb	w4, [x7]
    398c:	aa1303e1 	mov	x1, x19
    3990:	aa1703e2 	mov	x2, x23
    3994:	aa1603e0 	mov	x0, x22
    3998:	b9000be5 	str	w5, [sp, #8]
    399c:	cb170374 	sub	x20, x27, x23
    39a0:	a9011be3 	stp	x3, x6, [sp, #16]
    39a4:	97fffb27 	bl	2640 <memcpy@plt>
    39a8:	d1000694 	sub	x20, x20, #0x1
    39ac:	f9400be3 	ldr	x3, [sp, #16]
    39b0:	8b1702d6 	add	x22, x22, x23
    39b4:	aa1603e0 	mov	x0, x22
    39b8:	aa1a03e2 	mov	x2, x26
    39bc:	aa0303e1 	mov	x1, x3
    39c0:	aa1403e3 	mov	x3, x20
    39c4:	97fffb5f 	bl	2740 <__memcpy_chk@plt>
    39c8:	8b1a02d6 	add	x22, x22, x26
    39cc:	f9400fe6 	ldr	x6, [sp, #24]
    39d0:	d2800900 	mov	x0, #0x48                  	// #72
    39d4:	b9400be5 	ldr	w5, [sp, #8]
    39d8:	8b170261 	add	x1, x19, x23
    39dc:	cb1400c3 	sub	x3, x6, x20
    39e0:	cb060294 	sub	x20, x20, x6
    39e4:	f101207f 	cmp	x3, #0x48
    39e8:	93407cb8 	sxtw	x24, w5
    39ec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39f0:	aa1803e2 	mov	x2, x24
    39f4:	8b1802d3 	add	x19, x22, x24
    39f8:	8b140063 	add	x3, x3, x20
    39fc:	aa1603e0 	mov	x0, x22
    3a00:	97fffb50 	bl	2740 <__memcpy_chk@plt>
    3a04:	cb190273 	sub	x19, x19, x25
    3a08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3a0c:	eb00027f 	cmp	x19, x0
    3a10:	aa1903e1 	mov	x1, x25
    3a14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	aa1303e2 	mov	x2, x19
    3a20:	97fffb08 	bl	2640 <memcpy@plt>
    3a24:	38336abf 	strb	wzr, [x21, x19]
    3a28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a2c:	aa1503e0 	mov	x0, x21
    3a30:	97fffb14 	bl	2680 <strlen@plt>
    3a34:	aa0003f3 	mov	x19, x0
    3a38:	528005c1 	mov	w1, #0x2e                  	// #46
    3a3c:	aa1503e0 	mov	x0, x21
    3a40:	97fffba4 	bl	28d0 <strchr@plt>
    3a44:	b4000160 	cbz	x0, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a48:	b4000153 	cbz	x19, 3a70 <fwp_format_g.constprop.0+0x1dc>
    3a4c:	d503201f 	nop
    3a50:	aa1303e1 	mov	x1, x19
    3a54:	d1000673 	sub	x19, x19, #0x1
    3a58:	38736aa0 	ldrb	w0, [x21, x19]
    3a5c:	7100c01f 	cmp	w0, #0x30
    3a60:	54001001 	b.ne	3c60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3a64:	38336abf 	strb	wzr, [x21, x19]
    3a68:	b5ffff53 	cbnz	x19, 3a50 <fwp_format_g.constprop.0+0x1bc>
    3a6c:	d503201f 	nop
    3a70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a74:	f947f400 	ldr	x0, [x0, #4072]
    3a78:	f94057e2 	ldr	x2, [sp, #168]
    3a7c:	f9400001 	ldr	x1, [x0]
    3a80:	eb010042 	subs	x2, x2, x1
    3a84:	d2800001 	mov	x1, #0x0                   	// #0
    3a88:	54001061 	b.ne	3c94 <fwp_format_g.constprop.0+0x400>  // b.any
    3a8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3aa0:	fd408be8 	ldr	d8, [sp, #272]
    3aa4:	910483ff 	add	sp, sp, #0x120
    3aa8:	d65f03c0 	ret
    3aac:	1e604100 	fmov	d0, d8
    3ab0:	710000bf 	cmp	w5, #0x0
    3ab4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	90000044 	adrp	x4, b000 <__modti3+0x30>
    3ac0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ac4:	9112e084 	add	x4, x4, #0x4b8
    3ac8:	52800042 	mov	w2, #0x2                   	// #2
    3acc:	d2803201 	mov	x1, #0x190                 	// #400
    3ad0:	97fffb24 	bl	2760 <__snprintf_chk@plt>
    3ad4:	17ffffd6 	b	3a2c <fwp_format_g.constprop.0+0x198>
    3ad8:	cb140273 	sub	x19, x19, x20
    3adc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ae0:	910183f9 	add	x25, sp, #0x60
    3ae4:	aa1303e2 	mov	x2, x19
    3ae8:	aa1403e1 	mov	x1, x20
    3aec:	aa1903e0 	mov	x0, x25
    3af0:	d2800803 	mov	x3, #0x40                  	// #64
    3af4:	97fffb13 	bl	2740 <__memcpy_chk@plt>
    3af8:	38336b3f 	strb	wzr, [x25, x19]
    3afc:	aa1903e0 	mov	x0, x25
    3b00:	528005c1 	mov	w1, #0x2e                  	// #46
    3b04:	97fffb73 	bl	28d0 <strchr@plt>
    3b08:	b40001c0 	cbz	x0, 3b40 <fwp_format_g.constprop.0+0x2ac>
    3b0c:	b50000b3 	cbnz	x19, 3b20 <fwp_format_g.constprop.0+0x28c>
    3b10:	1400000c 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3b14:	381ff01f 	sturb	wzr, [x0, #-1]
    3b18:	f1000673 	subs	x19, x19, #0x1
    3b1c:	54000120 	b.eq	3b40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3b20:	8b130320 	add	x0, x25, x19
    3b24:	385ff001 	ldurb	w1, [x0, #-1]
    3b28:	7100c03f 	cmp	w1, #0x30
    3b2c:	54ffff40 	b.eq	3b14 <fwp_format_g.constprop.0+0x280>  // b.none
    3b30:	d1000673 	sub	x19, x19, #0x1
    3b34:	38736b20 	ldrb	w0, [x25, x19]
    3b38:	7100b81f 	cmp	w0, #0x2e
    3b3c:	54000a80 	b.eq	3c8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3b40:	710002ff 	cmp	w23, #0x0
    3b44:	528005a1 	mov	w1, #0x2d                  	// #45
    3b48:	aa1903e5 	mov	x5, x25
    3b4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b50:	aa1503e0 	mov	x0, x21
    3b54:	52800566 	mov	w6, #0x2b                  	// #43
    3b58:	90000044 	adrp	x4, b000 <__modti3+0x30>
    3b5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b60:	9112a084 	add	x4, x4, #0x4a8
    3b64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b68:	52800042 	mov	w2, #0x2                   	// #2
    3b6c:	d2803201 	mov	x1, #0x190                 	// #400
    3b70:	97fffafc 	bl	2760 <__snprintf_chk@plt>
    3b74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b78:	17ffffbe 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3b7c:	52800605 	mov	w5, #0x30                  	// #48
    3b80:	390000e5 	strb	w5, [x7]
    3b84:	d100077b 	sub	x27, x27, #0x1
    3b88:	aa0303e1 	mov	x1, x3
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	aa1b03e3 	mov	x3, x27
    3b94:	aa1a03e2 	mov	x2, x26
    3b98:	f90007e6 	str	x6, [sp, #8]
    3b9c:	b90013e4 	str	w4, [sp, #16]
    3ba0:	8b1a02d6 	add	x22, x22, x26
    3ba4:	b9001be5 	str	w5, [sp, #24]
    3ba8:	97fffae6 	bl	2740 <__memcpy_chk@plt>
    3bac:	f94007e6 	ldr	x6, [sp, #8]
    3bb0:	2a3703e7 	mvn	w7, w23
    3bb4:	b94013e4 	ldr	w4, [sp, #16]
    3bb8:	cb1b00c1 	sub	x1, x6, x27
    3bbc:	cb06037b 	sub	x27, x27, x6
    3bc0:	f101203f 	cmp	x1, #0x48
    3bc4:	d2800906 	mov	x6, #0x48                  	// #72
    3bc8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bcc:	8b1b0023 	add	x3, x1, x27
    3bd0:	310006ff 	cmn	w23, #0x1
    3bd4:	54000220 	b.eq	3c18 <fwp_format_g.constprop.0+0x384>  // b.none
    3bd8:	b9401be5 	ldr	w5, [sp, #24]
    3bdc:	d2800001 	mov	x1, #0x0                   	// #0
    3be0:	f101207f 	cmp	x3, #0x48
    3be4:	d1000462 	sub	x2, x3, #0x1
    3be8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bec:	38216ac5 	strb	w5, [x22, x1]
    3bf0:	cb030003 	sub	x3, x0, x3
    3bf4:	91000421 	add	x1, x1, #0x1
    3bf8:	91000463 	add	x3, x3, #0x1
    3bfc:	eb00007f 	cmp	x3, x0
    3c00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c04:	cb000063 	sub	x3, x3, x0
    3c08:	8b020063 	add	x3, x3, x2
    3c0c:	6b0100ff 	cmp	w7, w1
    3c10:	54fffe8c 	b.gt	3be0 <fwp_format_g.constprop.0+0x34c>
    3c14:	8b2742d6 	add	x22, x22, w7, uxtw
    3c18:	f101207f 	cmp	x3, #0x48
    3c1c:	d2800905 	mov	x5, #0x48                  	// #72
    3c20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c24:	aa1603e0 	mov	x0, x22
    3c28:	cb0300a1 	sub	x1, x5, x3
    3c2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c30:	91000421 	add	x1, x1, #0x1
    3c34:	d1000463 	sub	x3, x3, #0x1
    3c38:	eb05003f 	cmp	x1, x5
    3c3c:	38001402 	strb	w2, [x0], #1
    3c40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c44:	93407f82 	sxtw	x2, w28
    3c48:	cb050025 	sub	x5, x1, x5
    3c4c:	aa1303e1 	mov	x1, x19
    3c50:	8b0300a3 	add	x3, x5, x3
    3c54:	8b1802d3 	add	x19, x22, x24
    3c58:	97fffaba 	bl	2740 <__memcpy_chk@plt>
    3c5c:	17ffff6a 	b	3a04 <fwp_format_g.constprop.0+0x170>
    3c60:	d1000421 	sub	x1, x1, #0x1
    3c64:	38616aa0 	ldrb	w0, [x21, x1]
    3c68:	7100b81f 	cmp	w0, #0x2e
    3c6c:	54fff021 	b.ne	3a70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3c70:	38216abf 	strb	wzr, [x21, x1]
    3c74:	17ffff7f 	b	3a70 <fwp_format_g.constprop.0+0x1dc>
    3c78:	910187e7 	add	x7, sp, #0x61
    3c7c:	910183f9 	add	x25, sp, #0x60
    3c80:	d28008fb 	mov	x27, #0x47                  	// #71
    3c84:	390183e0 	strb	w0, [sp, #96]
    3c88:	17ffff3a 	b	3970 <fwp_format_g.constprop.0+0xdc>
    3c8c:	38336b3f 	strb	wzr, [x25, x19]
    3c90:	17ffffac 	b	3b40 <fwp_format_g.constprop.0+0x2ac>
    3c94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c98:	97fffad6 	bl	27f0 <__stack_chk_fail@plt>
    3c9c:	d503201f 	nop

0000000000003ca0 <fwp_heap_report>:
    3ca0:	d105c3ff 	sub	sp, sp, #0x170
    3ca4:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    3ca8:	91154042 	add	x2, x2, #0x550
    3cac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3cb0:	f947e821 	ldr	x1, [x1, #4048]
    3cb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3cb8:	910443fd 	add	x29, sp, #0x110
    3cbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3cc0:	f947f400 	ldr	x0, [x0, #4072]
    3cc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3ccc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3cdc:	f9400036 	ldr	x22, [x1]
    3ce0:	f9400001 	ldr	x1, [x0]
    3ce4:	f90087e1 	str	x1, [sp, #264]
    3ce8:	d2800001 	mov	x1, #0x0                   	// #0
    3cec:	f949e459 	ldr	x25, [x2, #5064]
    3cf0:	90000041 	adrp	x1, b000 <__modti3+0x30>
    3cf4:	f94a1057 	ldr	x23, [x2, #5152]
    3cf8:	90000040 	adrp	x0, b000 <__modti3+0x30>
    3cfc:	f94a1458 	ldr	x24, [x2, #5160]
    3d00:	91130021 	add	x1, x1, #0x4c0
    3d04:	91132000 	add	x0, x0, #0x4c8
    3d08:	97fffa9e 	bl	2780 <fopen@plt>
    3d0c:	b4000740 	cbz	x0, 3df4 <fwp_heap_report+0x154>
    3d10:	528daad5 	mov	w21, #0x6d56                	// #27990
    3d14:	a91253f3 	stp	x19, x20, [sp, #288]
    3d18:	aa0003f4 	mov	x20, x0
    3d1c:	910023f3 	add	x19, sp, #0x8
    3d20:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d24:	72aae915 	movk	w21, #0x5748, lsl #16
    3d28:	aa1403e2 	mov	x2, x20
    3d2c:	aa1303e0 	mov	x0, x19
    3d30:	52802001 	mov	w1, #0x100                 	// #256
    3d34:	97fffb1f 	bl	29b0 <fgets@plt>
    3d38:	b4000280 	cbz	x0, 3d88 <fwp_heap_report+0xe8>
    3d3c:	b9400261 	ldr	w1, [x19]
    3d40:	6b15003f 	cmp	w1, w21
    3d44:	54ffff21 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d48:	39401260 	ldrb	w0, [x19, #4]
    3d4c:	7101341f 	cmp	w0, #0x4d
    3d50:	54fffec1 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d54:	394037e0 	ldrb	w0, [sp, #13]
    3d58:	7100e81f 	cmp	w0, #0x3a
    3d5c:	54fffe61 	b.ne	3d28 <fwp_heap_report+0x88>  // b.any
    3d60:	52800142 	mov	w2, #0xa                   	// #10
    3d64:	d2800001 	mov	x1, #0x0                   	// #0
    3d68:	91003be0 	add	x0, sp, #0xe
    3d6c:	97fffac9 	bl	2890 <strtol@plt>
    3d70:	aa1403e2 	mov	x2, x20
    3d74:	aa0003fa 	mov	x26, x0
    3d78:	52802001 	mov	w1, #0x100                 	// #256
    3d7c:	aa1303e0 	mov	x0, x19
    3d80:	97fffb0c 	bl	29b0 <fgets@plt>
    3d84:	b5fffdc0 	cbnz	x0, 3d3c <fwp_heap_report+0x9c>
    3d88:	aa1403e0 	mov	x0, x20
    3d8c:	97fffa79 	bl	2770 <fclose@plt>
    3d90:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d94:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3d98:	f947f400 	ldr	x0, [x0, #4072]
    3d9c:	f94087e2 	ldr	x2, [sp, #264]
    3da0:	f9400001 	ldr	x1, [x0]
    3da4:	eb010042 	subs	x2, x2, x1
    3da8:	d2800001 	mov	x1, #0x0                   	// #0
    3dac:	54000281 	b.ne	3dfc <fwp_heap_report+0x15c>  // b.any
    3db0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3db4:	aa1a03e6 	mov	x6, x26
    3db8:	aa1903e5 	mov	x5, x25
    3dbc:	aa1803e4 	mov	x4, x24
    3dc0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dc4:	aa1703e3 	mov	x3, x23
    3dc8:	a95463f7 	ldp	x23, x24, [sp, #320]
    3dcc:	aa1603e0 	mov	x0, x22
    3dd0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dd4:	1e604121 	fmov	d1, d9
    3dd8:	1e604100 	fmov	d0, d8
    3ddc:	90000042 	adrp	x2, b000 <__modti3+0x30>
    3de0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3de4:	9113a042 	add	x2, x2, #0x4e8
    3de8:	9105c3ff 	add	sp, sp, #0x170
    3dec:	52800041 	mov	w1, #0x2                   	// #2
    3df0:	17fffa9c 	b	2860 <__fprintf_chk@plt>
    3df4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3df8:	17ffffe7 	b	3d94 <fwp_heap_report+0xf4>
    3dfc:	a91253f3 	stp	x19, x20, [sp, #288]
    3e00:	97fffa7c 	bl	27f0 <__stack_chk_fail@plt>

0000000000003e04 <fwp_heap_init>:
    3e04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3e08:	f0000163 	adrp	x3, 32000 <fwp_heap+0xab0>
    3e0c:	91114061 	add	x1, x3, #0x450
    3e10:	910003fd 	mov	x29, sp
    3e14:	a90153f3 	stp	x19, x20, [sp, #16]
    3e18:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3e1c:	91154262 	add	x2, x19, #0x550
    3e20:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e24:	52800024 	mov	w4, #0x1                   	// #1
    3e28:	52800200 	mov	w0, #0x10                  	// #16
    3e2c:	b913a444 	str	w4, [x2, #5028]
    3e30:	b8004420 	str	w0, [x1], #4
    3e34:	11004000 	add	w0, w0, #0x10
    3e38:	7104401f 	cmp	w0, #0x110
    3e3c:	54ffffa1 	b.ne	3e30 <fwp_heap_init+0x2c>  // b.any
    3e40:	b0000042 	adrp	x2, c000 <msg.4+0x20>
    3e44:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e48:	f0000161 	adrp	x1, 32000 <fwp_heap+0xab0>
    3e4c:	91124021 	add	x1, x1, #0x490
    3e50:	3dc00843 	ldr	q3, [x2, #32]
    3e54:	d2800000 	mov	x0, #0x0                   	// #0
    3e58:	4e040401 	dup	v1.4s, v0.s[0]
    3e5c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e60:	0f215400 	shl	v0.2s, v0.2s, #1
    3e64:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e68:	3ca06821 	str	q1, [x1, x0]
    3e6c:	91004000 	add	x0, x0, #0x10
    3e70:	f101801f 	cmp	x0, #0x60
    3e74:	54ffff21 	b.ne	3e58 <fwp_heap_init+0x54>  // b.any
    3e78:	f0000164 	adrp	x4, 32000 <fwp_heap+0xab0>
    3e7c:	91114063 	add	x3, x3, #0x450
    3e80:	9113c084 	add	x4, x4, #0x4f0
    3e84:	91154266 	add	x6, x19, #0x550
    3e88:	d2800002 	mov	x2, #0x0                   	// #0
    3e8c:	d2800000 	mov	x0, #0x0                   	// #0
    3e90:	d2880205 	mov	x5, #0x4010                	// #16400
    3e94:	d503201f 	nop
    3e98:	910f0001 	add	x1, x0, #0x3c0
    3e9c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	540000a2 	b.cs	3eb8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    3ea8:	91000400 	add	x0, x0, #0x1
    3eac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3eb0:	eb02003f 	cmp	x1, x2
    3eb4:	54ffffa3 	b.cc	3ea8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    3eb8:	91004042 	add	x2, x2, #0x10
    3ebc:	38001480 	strb	w0, [x4], #1
    3ec0:	eb05005f 	cmp	x2, x5
    3ec4:	54fffea1 	b.ne	3e98 <fwp_heap_init+0x94>  // b.any
    3ec8:	528000b5 	mov	w21, #0x5                   	// #5
    3ecc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ed0:	14000004 	b	3ee0 <fwp_heap_init+0xdc>
    3ed4:	d342fe94 	lsr	x20, x20, #2
    3ed8:	710006b5 	subs	w21, w21, #0x1
    3edc:	54000720 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3ee0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ee4:	d2800005 	mov	x5, #0x0                   	// #0
    3ee8:	aa1603e1 	mov	x1, x22
    3eec:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ef0:	52880443 	mov	w3, #0x4022                	// #16418
    3ef4:	52800002 	mov	w2, #0x0                   	// #0
    3ef8:	d2800000 	mov	x0, #0x0                   	// #0
    3efc:	97fffa61 	bl	2880 <mmap@plt>
    3f00:	aa0003e6 	mov	x6, x0
    3f04:	b100041f 	cmn	x0, #0x1
    3f08:	54fffe60 	b.eq	3ed4 <fwp_heap_init+0xd0>  // b.none
    3f0c:	b40005a0 	cbz	x0, 3fc0 <fwp_heap_init+0x1bc>
    3f10:	d350fe94 	lsr	x20, x20, #16
    3f14:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f18:	8b0000c7 	add	x7, x6, x0
    3f1c:	91154275 	add	x21, x19, #0x550
    3f20:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f24:	8b140a81 	add	x1, x20, x20, lsl #2
    3f28:	d2800005 	mov	x5, #0x0                   	// #0
    3f2c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f30:	d37df021 	lsl	x1, x1, #3
    3f34:	52880443 	mov	w3, #0x4022                	// #16418
    3f38:	52800002 	mov	w2, #0x0                   	// #0
    3f3c:	d2800000 	mov	x0, #0x0                   	// #0
    3f40:	f909daa7 	str	x7, [x21, #5040]
    3f44:	f909dea6 	str	x6, [x21, #5048]
    3f48:	f909e2b6 	str	x22, [x21, #5056]
    3f4c:	f909eab4 	str	x20, [x21, #5072]
    3f50:	f90a02a1 	str	x1, [x21, #5120]
    3f54:	97fffa4b 	bl	2880 <mmap@plt>
    3f58:	aa0003e1 	mov	x1, x0
    3f5c:	b100041f 	cmn	x0, #0x1
    3f60:	54000300 	b.eq	3fc0 <fwp_heap_init+0x1bc>  // b.none
    3f64:	90000040 	adrp	x0, b000 <__modti3+0x30>
    3f68:	91166000 	add	x0, x0, #0x598
    3f6c:	f909fea1 	str	x1, [x21, #5112]
    3f70:	97fffa84 	bl	2980 <getenv@plt>
    3f74:	52800002 	mov	w2, #0x0                   	// #0
    3f78:	aa0003e1 	mov	x1, x0
    3f7c:	b40000e0 	cbz	x0, 3f98 <fwp_heap_init+0x194>
    3f80:	39400000 	ldrb	w0, [x0]
    3f84:	340000a0 	cbz	w0, 3f98 <fwp_heap_init+0x194>
    3f88:	7100c000 	subs	w0, w0, #0x30
    3f8c:	54000120 	b.eq	3fb0 <fwp_heap_init+0x1ac>  // b.none
    3f90:	7100001f 	cmp	w0, #0x0
    3f94:	1a9f07e2 	cset	w2, ne	// ne = any
    3f98:	91154273 	add	x19, x19, #0x550
    3f9c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fa0:	b913aa62 	str	w2, [x19, #5032]
    3fa4:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fa8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fac:	d65f03c0 	ret
    3fb0:	39400420 	ldrb	w0, [x1, #1]
    3fb4:	7100001f 	cmp	w0, #0x0
    3fb8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fbc:	17fffff7 	b	3f98 <fwp_heap_init+0x194>
    3fc0:	97fffbfc 	bl	2fb0 <fwp_heap_oom>

0000000000003fc4 <fwp_wake_io>:
    3fc4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3fc8:	91010122 	add	x2, x9, #0x40
    3fcc:	f9400001 	ldr	x1, [x0]
    3fd0:	5280000a 	mov	w10, #0x0                   	// #0
    3fd4:	f9401446 	ldr	x6, [x2, #40]
    3fd8:	52800008 	mov	w8, #0x0                   	// #0
    3fdc:	4f000400 	movi	v0.4s, #0x0
    3fe0:	52800027 	mov	w7, #0x1                   	// #1
    3fe4:	aa0103e2 	mov	x2, x1
    3fe8:	b4000321 	cbz	x1, 404c <fwp_wake_io+0x88>
    3fec:	f9408c25 	ldr	x5, [x1, #280]
    3ff0:	39015c27 	strb	w7, [x1, #87]
    3ff4:	b4000165 	cbz	x5, 4020 <fwp_wake_io+0x5c>
    3ff8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3ffc:	b4000364 	cbz	x4, 4068 <fwp_wake_io+0xa4>
    4000:	f9009483 	str	x3, [x4, #296]
    4004:	f9409423 	ldr	x3, [x1, #296]
    4008:	b4000043 	cbz	x3, 4010 <fwp_wake_io+0x4c>
    400c:	f9009064 	str	x4, [x3, #288]
    4010:	91080023 	add	x3, x1, #0x200
    4014:	f900943f 	str	xzr, [x1, #296]
    4018:	3c918060 	stur	q0, [x3, #-232]
    401c:	f9400001 	ldr	x1, [x0]
    4020:	f9402843 	ldr	x3, [x2, #80]
    4024:	f2001c7f 	tst	x3, #0xff000000ff
    4028:	54fffde1 	b.ne	3fe4 <fwp_wake_io+0x20>  // b.any
    402c:	39015047 	strb	w7, [x2, #84]
    4030:	f900805f 	str	xzr, [x2, #256]
    4034:	b40001e6 	cbz	x6, 4070 <fwp_wake_io+0xac>
    4038:	f90080c2 	str	x2, [x6, #256]
    403c:	aa0203e6 	mov	x6, x2
    4040:	52800028 	mov	w8, #0x1                   	// #1
    4044:	aa0103e2 	mov	x2, x1
    4048:	b5fffd21 	cbnz	x1, 3fec <fwp_wake_io+0x28>
    404c:	3400006a 	cbz	w10, 4058 <fwp_wake_io+0x94>
    4050:	91010120 	add	x0, x9, #0x40
    4054:	f900180b 	str	x11, [x0, #48]
    4058:	34000068 	cbz	w8, 4064 <fwp_wake_io+0xa0>
    405c:	91010129 	add	x9, x9, #0x40
    4060:	f9001526 	str	x6, [x9, #40]
    4064:	d65f03c0 	ret
    4068:	f90000a3 	str	x3, [x5]
    406c:	17ffffe7 	b	4008 <fwp_wake_io+0x44>
    4070:	aa0203eb 	mov	x11, x2
    4074:	5280002a 	mov	w10, #0x1                   	// #1
    4078:	17fffff1 	b	403c <fwp_wake_io+0x78>
    407c:	d503201f 	nop

0000000000004080 <fwp_tape_buffers_release>:
    4080:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4084:	910003fd 	mov	x29, sp
    4088:	a90153f3 	stp	x19, x20, [sp, #16]
    408c:	aa0003f3 	mov	x19, x0
    4090:	f9401400 	ldr	x0, [x0, #40]
    4094:	b7f80760 	tbnz	x0, #63, 4180 <fwp_tape_buffers_release+0x100>
    4098:	f9401a61 	ldr	x1, [x19, #48]
    409c:	b7f80301 	tbnz	x1, #63, 40fc <fwp_tape_buffers_release+0x7c>
    40a0:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    40a4:	eb02001f 	cmp	x0, x2
    40a8:	540002a8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40ac:	8b000400 	add	x0, x0, x0, lsl #1
    40b0:	d2a00102 	mov	x2, #0x80000               	// #524288
    40b4:	d37df000 	lsl	x0, x0, #3
    40b8:	cb000042 	sub	x2, x2, x0
    40bc:	eb420c3f 	cmp	x1, x2, lsr #3
    40c0:	540001e8 	b.hi	40fc <fwp_tape_buffers_release+0x7c>  // b.pmore
    40c4:	8b010c14 	add	x20, x0, x1, lsl #3
    40c8:	f0000020 	adrp	x0, b000 <__modti3+0x30>
    40cc:	9116a000 	add	x0, x0, #0x5a8
    40d0:	97fffa2c 	bl	2980 <getenv@plt>
    40d4:	b4000240 	cbz	x0, 411c <fwp_tape_buffers_release+0x9c>
    40d8:	39400001 	ldrb	w1, [x0]
    40dc:	7100c03f 	cmp	w1, #0x30
    40e0:	540001e1 	b.ne	411c <fwp_tape_buffers_release+0x9c>  // b.any
    40e4:	39400400 	ldrb	w0, [x0, #1]
    40e8:	350001a0 	cbnz	w0, 411c <fwp_tape_buffers_release+0x9c>
    40ec:	aa1303e0 	mov	x0, x19
    40f0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40f4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40f8:	17fffc62 	b	3280 <fwp_tape_buffers_dispose>
    40fc:	f0000020 	adrp	x0, b000 <__modti3+0x30>
    4100:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4104:	9116a000 	add	x0, x0, #0x5a8
    4108:	97fffa1e 	bl	2980 <getenv@plt>
    410c:	b4ffff00 	cbz	x0, 40ec <fwp_tape_buffers_release+0x6c>
    4110:	39400001 	ldrb	w1, [x0]
    4114:	7100c03f 	cmp	w1, #0x30
    4118:	54fffe60 	b.eq	40e4 <fwp_tape_buffers_release+0x64>  // b.none
    411c:	d1000681 	sub	x1, x20, #0x1
    4120:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4124:	eb00003f 	cmp	x1, x0
    4128:	54fffe28 	b.hi	40ec <fwp_tape_buffers_release+0x6c>  // b.pmore
    412c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4130:	900000f6 	adrp	x22, 20000 <__data_start>
    4134:	910102d6 	add	x22, x22, #0x40
    4138:	910122d5 	add	x21, x22, #0x48
    413c:	aa1503e0 	mov	x0, x21
    4140:	97fffc50 	bl	3280 <fwp_tape_buffers_dispose>
    4144:	ad400a61 	ldp	q1, q2, [x19]
    4148:	f90042d4 	str	x20, [x22, #128]
    414c:	4f000400 	movi	v0.4s, #0x0
    4150:	ad000aa1 	stp	q1, q2, [x21]
    4154:	3dc00a61 	ldr	q1, [x19, #32]
    4158:	3d800aa1 	str	q1, [x21, #32]
    415c:	f9401a60 	ldr	x0, [x19, #48]
    4160:	f9001aa0 	str	x0, [x21, #48]
    4164:	f9001a7f 	str	xzr, [x19, #48]
    4168:	ad000260 	stp	q0, q0, [x19]
    416c:	3d800a60 	str	q0, [x19, #32]
    4170:	a94153f3 	ldp	x19, x20, [sp, #16]
    4174:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4178:	a8c37bfd 	ldp	x29, x30, [sp], #48
    417c:	d65f03c0 	ret
    4180:	f0000020 	adrp	x0, b000 <__modti3+0x30>
    4184:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4188:	9116a000 	add	x0, x0, #0x5a8
    418c:	97fff9fd 	bl	2980 <getenv@plt>
    4190:	b5fffa40 	cbnz	x0, 40d8 <fwp_tape_buffers_release+0x58>
    4194:	17ffffd6 	b	40ec <fwp_tape_buffers_release+0x6c>
    4198:	d503201f 	nop
    419c:	d503201f 	nop

00000000000041a0 <fwp_poll_events>:
    41a0:	d10103ff 	sub	sp, sp, #0x40
    41a4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    41a8:	f947f400 	ldr	x0, [x0, #4072]
    41ac:	a9027bfd 	stp	x29, x30, [sp, #32]
    41b0:	910083fd 	add	x29, sp, #0x20
    41b4:	a90353f3 	stp	x19, x20, [sp, #48]
    41b8:	900000f4 	adrp	x20, 20000 <__data_start>
    41bc:	f9400001 	ldr	x1, [x0]
    41c0:	f9000fe1 	str	x1, [sp, #24]
    41c4:	d2800001 	mov	x1, #0x0                   	// #0
    41c8:	97fffd2e 	bl	3680 <fwp_now_ns>
    41cc:	91010281 	add	x1, x20, #0x40
    41d0:	f9404433 	ldr	x19, [x1, #136]
    41d4:	b4000e93 	cbz	x19, 43a4 <fwp_poll_events+0x204>
    41d8:	aa1303e1 	mov	x1, x19
    41dc:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    41e0:	14000005 	b	41f4 <fwp_poll_events+0x54>
    41e4:	f9408821 	ldr	x1, [x1, #272]
    41e8:	eb03005f 	cmp	x2, x3
    41ec:	9a83d042 	csel	x2, x2, x3, le
    41f0:	b40000c1 	cbz	x1, 4208 <fwp_poll_events+0x68>
    41f4:	f9403423 	ldr	x3, [x1, #104]
    41f8:	b6ffff62 	tbz	x2, #63, 41e4 <fwp_poll_events+0x44>
    41fc:	f9408821 	ldr	x1, [x1, #272]
    4200:	aa0303e2 	mov	x2, x3
    4204:	b5ffff81 	cbnz	x1, 41f4 <fwp_poll_events+0x54>
    4208:	b7f80ce2 	tbnz	x2, #63, 43a4 <fwp_poll_events+0x204>
    420c:	cb000042 	sub	x2, x2, x0
    4210:	f100005f 	cmp	x2, #0x0
    4214:	540005cd 	b.le	42cc <fwp_poll_events+0x12c>
    4218:	d2869b60 	mov	x0, #0x34db                	// #13531
    421c:	d2884801 	mov	x1, #0x4240                	// #16960
    4220:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4224:	f2a001e1 	movk	x1, #0xf, lsl #16
    4228:	f2dbd040 	movk	x0, #0xde82, lsl #32
    422c:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4230:	f2e86360 	movk	x0, #0x431b, lsl #48
    4234:	9b407c40 	smulh	x0, x2, x0
    4238:	9352fc00 	asr	x0, x0, #18
    423c:	cb82fc00 	sub	x0, x0, x2, asr #63
    4240:	9b018802 	msub	x2, x0, x1, x2
    4244:	f100005f 	cmp	x2, #0x0
    4248:	9a800400 	cinc	x0, x0, ne	// ne = any
    424c:	eb03001f 	cmp	x0, x3
    4250:	54000a0c 	b.gt	4390 <fwp_poll_events+0x1f0>
    4254:	340003c0 	cbz	w0, 42cc <fwp_poll_events+0x12c>
    4258:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    425c:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4260:	72a20c42 	movk	w2, #0x1062, lsl #16
    4264:	9ba27c02 	umull	x2, w0, w2
    4268:	d366fc43 	lsr	x3, x2, #38
    426c:	aa0303e2 	mov	x2, x3
    4270:	1b048063 	msub	w3, w3, w4, w0
    4274:	9b217c63 	smull	x3, w3, w1
    4278:	d2800001 	mov	x1, #0x0                   	// #0
    427c:	910023e0 	add	x0, sp, #0x8
    4280:	a9008fe2 	stp	x2, x3, [sp, #8]
    4284:	97fff98f 	bl	28c0 <nanosleep@plt>
    4288:	91010280 	add	x0, x20, #0x40
    428c:	f9404413 	ldr	x19, [x0, #136]
    4290:	97fffcfc 	bl	3680 <fwp_now_ns>
    4294:	aa0003e6 	mov	x6, x0
    4298:	b50001f3 	cbnz	x19, 42d4 <fwp_poll_events+0x134>
    429c:	d503201f 	nop
    42a0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    42a4:	f947f400 	ldr	x0, [x0, #4072]
    42a8:	f9400fe2 	ldr	x2, [sp, #24]
    42ac:	f9400001 	ldr	x1, [x0]
    42b0:	eb010042 	subs	x2, x2, x1
    42b4:	d2800001 	mov	x1, #0x0                   	// #0
    42b8:	540008c1 	b.ne	43d0 <fwp_poll_events+0x230>  // b.any
    42bc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    42c0:	a94353f3 	ldp	x19, x20, [sp, #48]
    42c4:	910103ff 	add	sp, sp, #0x40
    42c8:	d65f03c0 	ret
    42cc:	97fffced 	bl	3680 <fwp_now_ns>
    42d0:	aa0003e6 	mov	x6, x0
    42d4:	4f000400 	movi	v0.4s, #0x0
    42d8:	91010288 	add	x8, x20, #0x40
    42dc:	52800027 	mov	w7, #0x1                   	// #1
    42e0:	f9403661 	ldr	x1, [x19, #104]
    42e4:	aa1303e5 	mov	x5, x19
    42e8:	f9408a73 	ldr	x19, [x19, #272]
    42ec:	eb06003f 	cmp	x1, x6
    42f0:	5400032c 	b.gt	4354 <fwp_poll_events+0x1b4>
    42f4:	394154a0 	ldrb	w0, [x5, #85]
    42f8:	36000120 	tbz	w0, #0, 431c <fwp_poll_events+0x17c>
    42fc:	f94084a0 	ldr	x0, [x5, #264]
    4300:	b40003c0 	cbz	x0, 4378 <fwp_poll_events+0x1d8>
    4304:	f9008813 	str	x19, [x0, #272]
    4308:	b4000053 	cbz	x19, 4310 <fwp_poll_events+0x170>
    430c:	f9008660 	str	x0, [x19, #264]
    4310:	910800a0 	add	x0, x5, #0x200
    4314:	390154bf 	strb	wzr, [x5, #85]
    4318:	3c908000 	stur	q0, [x0, #-248]
    431c:	f94030a0 	ldr	x0, [x5, #96]
    4320:	390158a7 	strb	w7, [x5, #86]
    4324:	f100001f 	cmp	x0, #0x0
    4328:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    432c:	5400018d 	b.le	435c <fwp_poll_events+0x1bc>
    4330:	f94028a0 	ldr	x0, [x5, #80]
    4334:	f2001c1f 	tst	x0, #0xff000000ff
    4338:	540000e1 	b.ne	4354 <fwp_poll_events+0x1b4>  // b.any
    433c:	f9401500 	ldr	x0, [x8, #40]
    4340:	390150a7 	strb	w7, [x5, #84]
    4344:	f90080bf 	str	xzr, [x5, #256]
    4348:	b40001e0 	cbz	x0, 4384 <fwp_poll_events+0x1e4>
    434c:	f9001505 	str	x5, [x8, #40]
    4350:	f9008005 	str	x5, [x0, #256]
    4354:	b5fffc73 	cbnz	x19, 42e0 <fwp_poll_events+0x140>
    4358:	17ffffd2 	b	42a0 <fwp_poll_events+0x100>
    435c:	394144a0 	ldrb	w0, [x5, #81]
    4360:	3707fe80 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    4364:	394140a0 	ldrb	w0, [x5, #80]
    4368:	3707fe40 	tbnz	w0, #0, 4330 <fwp_poll_events+0x190>
    436c:	aa0503e0 	mov	x0, x5
    4370:	97fffc20 	bl	33f0 <fwp_cancel_tree.part.0>
    4374:	17ffffef 	b	4330 <fwp_poll_events+0x190>
    4378:	91010281 	add	x1, x20, #0x40
    437c:	f9004433 	str	x19, [x1, #136]
    4380:	17ffffe2 	b	4308 <fwp_poll_events+0x168>
    4384:	f9001505 	str	x5, [x8, #40]
    4388:	f9001905 	str	x5, [x8, #48]
    438c:	17fffff2 	b	4354 <fwp_poll_events+0x1b4>
    4390:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4394:	d2989362 	mov	x2, #0xc49b                	// #50331
    4398:	f2a4d203 	movk	x3, #0x2690, lsl #16
    439c:	f2a00402 	movk	x2, #0x20, lsl #16
    43a0:	17ffffb6 	b	4278 <fwp_poll_events+0xd8>
    43a4:	97fffaf3 	bl	2f70 <fwp_flush>
    43a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    43ac:	f947e863 	ldr	x3, [x3, #4048]
    43b0:	d2800562 	mov	x2, #0x2b                  	// #43
    43b4:	d2800021 	mov	x1, #0x1                   	// #1
    43b8:	f0000020 	adrp	x0, b000 <__modti3+0x30>
    43bc:	91170000 	add	x0, x0, #0x5c0
    43c0:	f9400063 	ldr	x3, [x3]
    43c4:	97fff94b 	bl	28f0 <fwrite@plt>
    43c8:	52800ca0 	mov	w0, #0x65                  	// #101
    43cc:	97fff8b5 	bl	26a0 <exit@plt>
    43d0:	97fff908 	bl	27f0 <__stack_chk_fail@plt>

00000000000043d4 <fwp_rc_wide_dup>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	aa0003f3 	mov	x19, x0
    43e4:	ca404400 	eor	x0, x0, x0, lsr #17
    43e8:	f90013f5 	str	x21, [sp, #32]
    43ec:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    43f0:	ca402400 	eor	x0, x0, x0, lsr #9
    43f4:	911542a2 	add	x2, x21, #0x550
    43f8:	92401c00 	and	x0, x0, #0xff
    43fc:	910a2403 	add	x3, x0, #0x289
    4400:	8b000c40 	add	x0, x2, x0, lsl #3
    4404:	8b030c54 	add	x20, x2, x3, lsl #3
    4408:	f94a2401 	ldr	x1, [x0, #5192]
    440c:	b50000a1 	cbnz	x1, 4420 <fwp_rc_wide_dup+0x4c>
    4410:	1400002d 	b	44c4 <fwp_rc_wide_dup+0xf0>
    4414:	91004034 	add	x20, x1, #0x10
    4418:	f9400821 	ldr	x1, [x1, #16]
    441c:	b4000241 	cbz	x1, 4464 <fwp_rc_wide_dup+0x90>
    4420:	f9400022 	ldr	x2, [x1]
    4424:	eb02027f 	cmp	x19, x2
    4428:	54ffff61 	b.ne	4414 <fwp_rc_wide_dup+0x40>  // b.any
    442c:	f9400281 	ldr	x1, [x20]
    4430:	39400260 	ldrb	w0, [x19]
    4434:	7103f81f 	cmp	w0, #0xfe
    4438:	54000220 	b.eq	447c <fwp_rc_wide_dup+0xa8>  // b.none
    443c:	b40001a1 	cbz	x1, 4470 <fwp_rc_wide_dup+0x9c>
    4440:	f9400420 	ldr	x0, [x1, #8]
    4444:	b100041f 	cmn	x0, #0x1
    4448:	540004a0 	b.eq	44dc <fwp_rc_wide_dup+0x108>  // b.none
    444c:	91000400 	add	x0, x0, #0x1
    4450:	f9000420 	str	x0, [x1, #8]
    4454:	a94153f3 	ldp	x19, x20, [sp, #16]
    4458:	f94013f5 	ldr	x21, [sp, #32]
    445c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4460:	d65f03c0 	ret
    4464:	39400260 	ldrb	w0, [x19]
    4468:	7103f81f 	cmp	w0, #0xfe
    446c:	540000a0 	b.eq	4480 <fwp_rc_wide_dup+0xac>  // b.none
    4470:	f0000020 	adrp	x0, b000 <__modti3+0x30>
    4474:	91186000 	add	x0, x0, #0x618
    4478:	97fffc22 	bl	3500 <fwp_trap>
    447c:	b5000281 	cbnz	x1, 44cc <fwp_rc_wide_dup+0xf8>
    4480:	d2800300 	mov	x0, #0x18                  	// #24
    4484:	97fff8c3 	bl	2790 <malloc@plt>
    4488:	b4000280 	cbz	x0, 44d8 <fwp_rc_wide_dup+0x104>
    448c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4490:	a9000413 	stp	x19, x1, [x0]
    4494:	911542b5 	add	x21, x21, #0x550
    4498:	f900081f 	str	xzr, [x0, #16]
    449c:	12800001 	mov	w1, #0xffffffff            	// #-1
    44a0:	f9000280 	str	x0, [x20]
    44a4:	39000261 	strb	w1, [x19]
    44a8:	f94e26a0 	ldr	x0, [x21, #7240]
    44ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    44b0:	91000400 	add	x0, x0, #0x1
    44b4:	f90e26a0 	str	x0, [x21, #7240]
    44b8:	f94013f5 	ldr	x21, [sp, #32]
    44bc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44c0:	d65f03c0 	ret
    44c4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    44c8:	17ffffda 	b	4430 <fwp_rc_wide_dup+0x5c>
    44cc:	f0000020 	adrp	x0, b000 <__modti3+0x30>
    44d0:	9117c000 	add	x0, x0, #0x5f0
    44d4:	97fffc0b 	bl	3500 <fwp_trap>
    44d8:	97fffab6 	bl	2fb0 <fwp_heap_oom>
    44dc:	f0000020 	adrp	x0, b000 <__modti3+0x30>
    44e0:	91190000 	add	x0, x0, #0x640
    44e4:	97fffc07 	bl	3500 <fwp_trap>
    44e8:	d503201f 	nop
    44ec:	d503201f 	nop

00000000000044f0 <fwp_rc_forget_slot>:
    44f0:	aa0003e1 	mov	x1, x0
    44f4:	39400000 	ldrb	w0, [x0]
    44f8:	7103fc1f 	cmp	w0, #0xff
    44fc:	54000040 	b.eq	4504 <fwp_rc_forget_slot+0x14>  // b.none
    4500:	d65f03c0 	ret
    4504:	ca414420 	eor	x0, x1, x1, lsr #17
    4508:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    450c:	ca402400 	eor	x0, x0, x0, lsr #9
    4510:	910003fd 	mov	x29, sp
    4514:	92401c00 	and	x0, x0, #0xff
    4518:	f9000bf3 	str	x19, [sp, #16]
    451c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4520:	91154262 	add	x2, x19, #0x550
    4524:	910a2403 	add	x3, x0, #0x289
    4528:	8b000c40 	add	x0, x2, x0, lsl #3
    452c:	8b030c43 	add	x3, x2, x3, lsl #3
    4530:	f94a2400 	ldr	x0, [x0, #5192]
    4534:	b50000a0 	cbnz	x0, 4548 <fwp_rc_forget_slot+0x58>
    4538:	14000011 	b	457c <fwp_rc_forget_slot+0x8c>
    453c:	91004003 	add	x3, x0, #0x10
    4540:	f9400800 	ldr	x0, [x0, #16]
    4544:	b40001c0 	cbz	x0, 457c <fwp_rc_forget_slot+0x8c>
    4548:	f9400002 	ldr	x2, [x0]
    454c:	eb02003f 	cmp	x1, x2
    4550:	54ffff61 	b.ne	453c <fwp_rc_forget_slot+0x4c>  // b.any
    4554:	f9400801 	ldr	x1, [x0, #16]
    4558:	91154273 	add	x19, x19, #0x550
    455c:	f9000061 	str	x1, [x3]
    4560:	97fff8d4 	bl	28b0 <free@plt>
    4564:	f94e2660 	ldr	x0, [x19, #7240]
    4568:	d1000400 	sub	x0, x0, #0x1
    456c:	f90e2660 	str	x0, [x19, #7240]
    4570:	f9400bf3 	ldr	x19, [sp, #16]
    4574:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4578:	d65f03c0 	ret
    457c:	f0000020 	adrp	x0, b000 <__modti3+0x30>
    4580:	91186000 	add	x0, x0, #0x618
    4584:	97fffbdf 	bl	3500 <fwp_trap>
    4588:	d503201f 	nop
    458c:	d503201f 	nop

0000000000004590 <fwp_rc_prepare_chunk>:
    4590:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4594:	910003fd 	mov	x29, sp
    4598:	a9025bf5 	stp	x21, x22, [sp, #32]
    459c:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc90>
    45a0:	911542c2 	add	x2, x22, #0x550
    45a4:	b9401c03 	ldr	w3, [x0, #28]
    45a8:	aa0103f5 	mov	x21, x1
    45ac:	a90153f3 	stp	x19, x20, [sp, #16]
    45b0:	aa0003f4 	mov	x20, x0
    45b4:	f94e2440 	ldr	x0, [x2, #7240]
    45b8:	b4000440 	cbz	x0, 4640 <fwp_rc_prepare_chunk+0xb0>
    45bc:	d2800013 	mov	x19, #0x0                   	// #0
    45c0:	35000203 	cbnz	w3, 4600 <fwp_rc_prepare_chunk+0x70>
    45c4:	b4000361 	cbz	x1, 4630 <fwp_rc_prepare_chunk+0xa0>
    45c8:	f9401280 	ldr	x0, [x20, #32]
    45cc:	97fff8b9 	bl	28b0 <free@plt>
    45d0:	aa1503e0 	mov	x0, x21
    45d4:	d2800021 	mov	x1, #0x1                   	// #1
    45d8:	97fff87e 	bl	27d0 <calloc@plt>
    45dc:	f9001280 	str	x0, [x20, #32]
    45e0:	b5000460 	cbnz	x0, 466c <fwp_rc_prepare_chunk+0xdc>
    45e4:	97fffa73 	bl	2fb0 <fwp_heap_oom>
    45e8:	97ffffc2 	bl	44f0 <fwp_rc_forget_slot>
    45ec:	91000673 	add	x19, x19, #0x1
    45f0:	b9401e83 	ldr	w3, [x20, #28]
    45f4:	eb13007f 	cmp	x3, x19
    45f8:	54000169 	b.ls	4624 <fwp_rc_prepare_chunk+0x94>  // b.plast
    45fc:	d503201f 	nop
    4600:	f9401283 	ldr	x3, [x20, #32]
    4604:	8b130060 	add	x0, x3, x19
    4608:	38736863 	ldrb	w3, [x3, x19]
    460c:	7103fc7f 	cmp	w3, #0xff
    4610:	54fffec0 	b.eq	45e8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4614:	b9401e83 	ldr	w3, [x20, #28]
    4618:	91000673 	add	x19, x19, #0x1
    461c:	eb13007f 	cmp	x3, x19
    4620:	54ffff08 	b.hi	4600 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4624:	eb0302bf 	cmp	x21, x3
    4628:	54000121 	b.ne	464c <fwp_rc_prepare_chunk+0xbc>  // b.any
    462c:	b5000335 	cbnz	x21, 4690 <fwp_rc_prepare_chunk+0x100>
    4630:	a94153f3 	ldp	x19, x20, [sp, #16]
    4634:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4638:	a8c37bfd 	ldp	x29, x30, [sp], #48
    463c:	d65f03c0 	ret
    4640:	2a0303e3 	mov	w3, w3
    4644:	eb0302bf 	cmp	x21, x3
    4648:	54ffff20 	b.eq	462c <fwp_rc_prepare_chunk+0x9c>  // b.none
    464c:	911542c2 	add	x2, x22, #0x550
    4650:	f9401280 	ldr	x0, [x20, #32]
    4654:	f94e2841 	ldr	x1, [x2, #7248]
    4658:	cb030021 	sub	x1, x1, x3
    465c:	f90e2841 	str	x1, [x2, #7248]
    4660:	97fff894 	bl	28b0 <free@plt>
    4664:	b5fffb75 	cbnz	x21, 45d0 <fwp_rc_prepare_chunk+0x40>
    4668:	f900129f 	str	xzr, [x20, #32]
    466c:	911542d6 	add	x22, x22, #0x550
    4670:	f94e2ac0 	ldr	x0, [x22, #7248]
    4674:	b9001e95 	str	w21, [x20, #28]
    4678:	a94153f3 	ldp	x19, x20, [sp, #16]
    467c:	8b150000 	add	x0, x0, x21
    4680:	f90e2ac0 	str	x0, [x22, #7248]
    4684:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4688:	a8c37bfd 	ldp	x29, x30, [sp], #48
    468c:	d65f03c0 	ret
    4690:	f9401280 	ldr	x0, [x20, #32]
    4694:	aa1503e2 	mov	x2, x21
    4698:	a94153f3 	ldp	x19, x20, [sp, #16]
    469c:	52800001 	mov	w1, #0x0                   	// #0
    46a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46a4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46a8:	17fff846 	b	27c0 <memset@plt>
    46ac:	d503201f 	nop

00000000000046b0 <fwp_heap_refill>:
    46b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    46b4:	910003fd 	mov	x29, sp
    46b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    46bc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    46c0:	911542b5 	add	x21, x21, #0x550
    46c4:	aa0003f6 	mov	x22, x0
    46c8:	d2800020 	mov	x0, #0x1                   	// #1
    46cc:	a90153f3 	stp	x19, x20, [sp, #16]
    46d0:	a90363f7 	stp	x23, x24, [sp, #48]
    46d4:	2a0103f7 	mov	w23, w1
    46d8:	2a0203f8 	mov	w24, w2
    46dc:	97fffa75 	bl	30b0 <fwp_heap_chunks>
    46e0:	aa0003f3 	mov	x19, x0
    46e4:	f949fea2 	ldr	x2, [x21, #5112]
    46e8:	8b000800 	add	x0, x0, x0, lsl #2
    46ec:	2a1703e1 	mov	w1, w23
    46f0:	52800025 	mov	w5, #0x1                   	// #1
    46f4:	d37df000 	lsl	x0, x0, #3
    46f8:	910f0021 	add	x1, x1, #0x3c0
    46fc:	8b000054 	add	x20, x2, x0
    4700:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4704:	52a00024 	mov	w4, #0x10000               	// #65536
    4708:	38206845 	strb	w5, [x2, x0]
    470c:	aa1403e0 	mov	x0, x20
    4710:	39000698 	strb	w24, [x20, #1]
    4714:	39000a97 	strb	w23, [x20, #2]
    4718:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    471c:	b9000681 	str	w1, [x20, #4]
    4720:	2a0103e5 	mov	w5, w1
    4724:	8b0300a2 	add	x2, x5, x3
    4728:	1ac10881 	udiv	w1, w4, w1
    472c:	9ac50842 	udiv	x2, x2, x5
    4730:	b9000a81 	str	w1, [x20, #8]
    4734:	92404021 	and	x1, x1, #0x1ffff
    4738:	b9001a82 	str	w2, [x20, #24]
    473c:	97ffff95 	bl	4590 <fwp_rc_prepare_chunk>
    4740:	f949daa0 	ldr	x0, [x21, #5040]
    4744:	29408a81 	ldp	w1, w2, [x20, #4]
    4748:	8b134000 	add	x0, x0, x19, lsl #16
    474c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4750:	8b214003 	add	x3, x0, w1, uxtw
    4754:	9ba20021 	umaddl	x1, w1, w2, x0
    4758:	a94363f7 	ldp	x23, x24, [sp, #48]
    475c:	a90086c3 	stp	x3, x1, [x22, #8]
    4760:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4764:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4768:	d65f03c0 	ret
    476c:	d503201f 	nop

0000000000004770 <fwp_mem_free>:
    4770:	b40003c0 	cbz	x0, 47e8 <fwp_mem_free+0x78>
    4774:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4778:	910003fd 	mov	x29, sp
    477c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4780:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4784:	911542a1 	add	x1, x21, #0x550
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	aa0003f3 	mov	x19, x0
    4790:	f949d823 	ldr	x3, [x1, #5040]
    4794:	f949ec22 	ldr	x2, [x1, #5080]
    4798:	cb030000 	sub	x0, x0, x3
    479c:	eb02401f 	cmp	x0, x2, lsl #16
    47a0:	540001c2 	b.cs	47d8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    47a4:	d350fc16 	lsr	x22, x0, #16
    47a8:	a90363f7 	stp	x23, x24, [sp, #48]
    47ac:	f949fc22 	ldr	x2, [x1, #5112]
    47b0:	8b160ad4 	add	x20, x22, x22, lsl #2
    47b4:	d37df294 	lsl	x20, x20, #3
    47b8:	ab140057 	adds	x23, x2, x20
    47bc:	540000c0 	b.eq	47d4 <fwp_mem_free+0x64>  // b.none
    47c0:	38746842 	ldrb	w2, [x2, x20]
    47c4:	7100045f 	cmp	w2, #0x1
    47c8:	54000120 	b.eq	47ec <fwp_mem_free+0x7c>  // b.none
    47cc:	7100085f 	cmp	w2, #0x2
    47d0:	540005e0 	b.eq	488c <fwp_mem_free+0x11c>  // b.none
    47d4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    47dc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47e0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47e4:	d65f03c0 	ret
    47e8:	d65f03c0 	ret
    47ec:	f94012f8 	ldr	x24, [x23, #32]
    47f0:	b94006e1 	ldr	w1, [x23, #4]
    47f4:	f90023f9 	str	x25, [sp, #64]
    47f8:	2a0103e2 	mov	w2, w1
    47fc:	394006f9 	ldrb	w25, [x23, #1]
    4800:	39400af4 	ldrb	w20, [x23, #2]
    4804:	b4000158 	cbz	x24, 482c <fwp_mem_free+0xbc>
    4808:	92403e76 	and	x22, x19, #0xffff
    480c:	9ac20ad6 	udiv	x22, x22, x2
    4810:	38766b01 	ldrb	w1, [x24, x22]
    4814:	8b160300 	add	x0, x24, x22
    4818:	7103fc3f 	cmp	w1, #0xff
    481c:	54000980 	b.eq	494c <fwp_mem_free+0x1dc>  // b.none
    4820:	38366b1f 	strb	wzr, [x24, x22]
    4824:	b94006e1 	ldr	w1, [x23, #4]
    4828:	2a0103e2 	mov	w2, w1
    482c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4830:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4834:	cb390000 	sub	x0, x0, w25, uxtb
    4838:	8b340074 	add	x20, x3, w20, uxtb
    483c:	911542b5 	add	x21, x21, #0x550
    4840:	1e630021 	ucvtf	d1, w1
    4844:	d37ae400 	lsl	x0, x0, #6
    4848:	8b140c14 	add	x20, x0, x20, lsl #3
    484c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4850:	f8746aa0 	ldr	x0, [x21, x20]
    4854:	f94023f9 	ldr	x25, [sp, #64]
    4858:	aa2003e0 	mvn	x0, x0
    485c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4860:	f9000260 	str	x0, [x19]
    4864:	f8346ab3 	str	x19, [x21, x20]
    4868:	f94a12a0 	ldr	x0, [x21, #5152]
    486c:	1e612800 	fadd	d0, d0, d1
    4870:	a94153f3 	ldp	x19, x20, [sp, #16]
    4874:	cb020000 	sub	x0, x0, x2
    4878:	f90a12a0 	str	x0, [x21, #5152]
    487c:	fd0a22a0 	str	d0, [x21, #5184]
    4880:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4884:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4888:	d65f03c0 	ret
    488c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4890:	8b000063 	add	x3, x3, x0
    4894:	eb03027f 	cmp	x19, x3
    4898:	54fff9e1 	b.ne	47d4 <fwp_mem_free+0x64>  // b.any
    489c:	fd400ae1 	ldr	d1, [x23, #16]
    48a0:	fd4a2020 	ldr	d0, [x1, #5184]
    48a4:	f9400ae0 	ldr	x0, [x23, #16]
    48a8:	7e61d821 	ucvtf	d1, d1
    48ac:	f94a1022 	ldr	x2, [x1, #5152]
    48b0:	f94012f3 	ldr	x19, [x23, #32]
    48b4:	1e612800 	fadd	d0, d0, d1
    48b8:	cb000042 	sub	x2, x2, x0
    48bc:	f90a1022 	str	x2, [x1, #5152]
    48c0:	fd0a2020 	str	d0, [x1, #5184]
    48c4:	b40000b3 	cbz	x19, 48d8 <fwp_mem_free+0x168>
    48c8:	39400260 	ldrb	w0, [x19]
    48cc:	7103fc1f 	cmp	w0, #0xff
    48d0:	54000380 	b.eq	4940 <fwp_mem_free+0x1d0>  // b.none
    48d4:	3900027f 	strb	wzr, [x19]
    48d8:	b9400ee2 	ldr	w2, [x23, #12]
    48dc:	b4000142 	cbz	x2, 4904 <fwp_mem_free+0x194>
    48e0:	911542a1 	add	x1, x21, #0x550
    48e4:	8b160040 	add	x0, x2, x22
    48e8:	8b000800 	add	x0, x0, x0, lsl #2
    48ec:	f949fc21 	ldr	x1, [x1, #5112]
    48f0:	8b140034 	add	x20, x1, x20
    48f4:	8b000c20 	add	x0, x1, x0, lsl #3
    48f8:	3802869f 	strb	wzr, [x20], #40
    48fc:	eb00029f 	cmp	x20, x0
    4900:	54ffffc1 	b.ne	48f8 <fwp_mem_free+0x188>  // b.any
    4904:	911542a0 	add	x0, x21, #0x550
    4908:	f94a1801 	ldr	x1, [x0, #5168]
    490c:	f949f803 	ldr	x3, [x0, #5104]
    4910:	8b020021 	add	x1, x1, x2
    4914:	f90a1801 	str	x1, [x0, #5168]
    4918:	eb16007f 	cmp	x3, x22
    491c:	54000049 	b.ls	4924 <fwp_mem_free+0x1b4>  // b.plast
    4920:	f909f816 	str	x22, [x0, #5104]
    4924:	911542b5 	add	x21, x21, #0x550
    4928:	f949f6a0 	ldr	x0, [x21, #5096]
    492c:	eb16001f 	cmp	x0, x22
    4930:	54fff529 	b.ls	47d4 <fwp_mem_free+0x64>  // b.plast
    4934:	a94363f7 	ldp	x23, x24, [sp, #48]
    4938:	f909f6b6 	str	x22, [x21, #5096]
    493c:	17ffffa7 	b	47d8 <fwp_mem_free+0x68>
    4940:	aa1303e0 	mov	x0, x19
    4944:	97fffeeb 	bl	44f0 <fwp_rc_forget_slot>
    4948:	17ffffe3 	b	48d4 <fwp_mem_free+0x164>
    494c:	97fffee9 	bl	44f0 <fwp_rc_forget_slot>
    4950:	17ffffb4 	b	4820 <fwp_mem_free+0xb0>

0000000000004954 <fwp_heap_alloc_big>:
    4954:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4958:	910003fd 	mov	x29, sp
    495c:	a90153f3 	stp	x19, x20, [sp, #16]
    4960:	a9025bf5 	stp	x21, x22, [sp, #32]
    4964:	a90363f7 	stp	x23, x24, [sp, #48]
    4968:	aa0003f7 	mov	x23, x0
    496c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4970:	a9046bf9 	stp	x25, x26, [sp, #64]
    4974:	eb0002ff 	cmp	x23, x0
    4978:	54000888 	b.hi	4a88 <fwp_heap_alloc_big+0x134>  // b.pmore
    497c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4980:	8b0002f4 	add	x20, x23, x0
    4984:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc90>
    4988:	91154359 	add	x25, x26, #0x550
    498c:	d350fe94 	lsr	x20, x20, #16
    4990:	2a0103f5 	mov	w21, w1
    4994:	aa1403e0 	mov	x0, x20
    4998:	97fff9c6 	bl	30b0 <fwp_heap_chunks>
    499c:	f949ff22 	ldr	x2, [x25, #5112]
    49a0:	8b000813 	add	x19, x0, x0, lsl #2
    49a4:	aa0003f8 	mov	x24, x0
    49a8:	52800043 	mov	w3, #0x2                   	// #2
    49ac:	d37df273 	lsl	x19, x19, #3
    49b0:	d2800021 	mov	x1, #0x1                   	// #1
    49b4:	8b130040 	add	x0, x2, x19
    49b8:	38336843 	strb	w3, [x2, x19]
    49bc:	39000415 	strb	w21, [x0, #1]
    49c0:	b9000c14 	str	w20, [x0, #12]
    49c4:	f9000817 	str	x23, [x0, #16]
    49c8:	97fffef2 	bl	4590 <fwp_rc_prepare_chunk>
    49cc:	f100069f 	cmp	x20, #0x1
    49d0:	54000269 	b.ls	4a1c <fwp_heap_alloc_big+0xc8>  // b.plast
    49d4:	8b180294 	add	x20, x20, x24
    49d8:	9100a273 	add	x19, x19, #0x28
    49dc:	a90573fb 	stp	x27, x28, [sp, #80]
    49e0:	5280007b 	mov	w27, #0x3                   	// #3
    49e4:	8b140a94 	add	x20, x20, x20, lsl #2
    49e8:	2a1803fc 	mov	w28, w24
    49ec:	9adb2296 	lsl	x22, x20, x27
    49f0:	f949ff35 	ldr	x21, [x25, #5112]
    49f4:	d2800001 	mov	x1, #0x0                   	// #0
    49f8:	8b1302b4 	add	x20, x21, x19
    49fc:	aa1403e0 	mov	x0, x20
    4a00:	97fffee4 	bl	4590 <fwp_rc_prepare_chunk>
    4a04:	38336abb 	strb	w27, [x21, x19]
    4a08:	9100a273 	add	x19, x19, #0x28
    4a0c:	b9000e9c 	str	w28, [x20, #12]
    4a10:	eb1302df 	cmp	x22, x19
    4a14:	54fffee1 	b.ne	49f0 <fwp_heap_alloc_big+0x9c>  // b.any
    4a18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a1c:	91154353 	add	x19, x26, #0x550
    4a20:	aa1703e2 	mov	x2, x23
    4a24:	52800001 	mov	w1, #0x0                   	// #0
    4a28:	f949da60 	ldr	x0, [x19, #5040]
    4a2c:	8b184018 	add	x24, x0, x24, lsl #16
    4a30:	aa1803e0 	mov	x0, x24
    4a34:	97fff763 	bl	27c0 <memset@plt>
    4a38:	f94a1260 	ldr	x0, [x19, #5152]
    4a3c:	ab170000 	adds	x0, x0, x23
    4a40:	54000242 	b.cs	4a88 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4a44:	f94a1661 	ldr	x1, [x19, #5160]
    4a48:	f90a1260 	str	x0, [x19, #5152]
    4a4c:	eb01001f 	cmp	x0, x1
    4a50:	54000049 	b.ls	4a58 <fwp_heap_alloc_big+0x104>  // b.plast
    4a54:	f90a1660 	str	x0, [x19, #5160]
    4a58:	9115435a 	add	x26, x26, #0x550
    4a5c:	9e6202e0 	scvtf	d0, x23
    4a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a64:	aa1803e0 	mov	x0, x24
    4a68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a70:	1e602820 	fadd	d0, d1, d0
    4a74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a78:	fd0a1f40 	str	d0, [x26, #5176]
    4a7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a84:	d65f03c0 	ret
    4a88:	a90573fb 	stp	x27, x28, [sp, #80]
    4a8c:	97fff949 	bl	2fb0 <fwp_heap_oom>

0000000000004a90 <fwp_heap_alloc_slow>:
    4a90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a94:	910003fd 	mov	x29, sp
    4a98:	a90153f3 	stp	x19, x20, [sp, #16]
    4a9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4aa0:	91154262 	add	x2, x19, #0x550
    4aa4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4aa8:	aa0003f5 	mov	x21, x0
    4aac:	2a0103f4 	mov	w20, w1
    4ab0:	b953a440 	ldr	w0, [x2, #5028]
    4ab4:	34000600 	cbz	w0, 4b74 <fwp_heap_alloc_slow+0xe4>
    4ab8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4abc:	54000628 	b.hi	4b80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ac0:	91003ea0 	add	x0, x21, #0xf
    4ac4:	91154262 	add	x2, x19, #0x550
    4ac8:	f9001bf7 	str	x23, [sp, #48]
    4acc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ad0:	8b401040 	add	x0, x2, x0, lsr #4
    4ad4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ad8:	d37ae484 	lsl	x4, x4, #6
    4adc:	397e8003 	ldrb	w3, [x0, #4000]
    4ae0:	910f0060 	add	x0, x3, #0x3c0
    4ae4:	aa0303e1 	mov	x1, x3
    4ae8:	8b030463 	add	x3, x3, x3, lsl #1
    4aec:	8b030c83 	add	x3, x4, x3, lsl #3
    4af0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4af4:	2a1703f6 	mov	w22, w23
    4af8:	f8636844 	ldr	x4, [x2, x3]
    4afc:	b40004e4 	cbz	x4, 4b98 <fwp_heap_alloc_slow+0x108>
    4b00:	f9400080 	ldr	x0, [x4]
    4b04:	aa2003e0 	mvn	x0, x0
    4b08:	f8236840 	str	x0, [x2, x3]
    4b0c:	7100069f 	cmp	w20, #0x1
    4b10:	aa0403e0 	mov	x0, x4
    4b14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b18:	52800001 	mov	w1, #0x0                   	// #0
    4b1c:	97fff729 	bl	27c0 <memset@plt>
    4b20:	aa0003e4 	mov	x4, x0
    4b24:	91154260 	add	x0, x19, #0x550
    4b28:	f94a1001 	ldr	x1, [x0, #5152]
    4b2c:	ab160021 	adds	x1, x1, x22
    4b30:	540005c2 	b.cs	4be8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b34:	f94a1402 	ldr	x2, [x0, #5160]
    4b38:	f90a1001 	str	x1, [x0, #5152]
    4b3c:	eb02003f 	cmp	x1, x2
    4b40:	54000049 	b.ls	4b48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b44:	f90a1401 	str	x1, [x0, #5160]
    4b48:	91154273 	add	x19, x19, #0x550
    4b4c:	1e6302e1 	ucvtf	d1, w23
    4b50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b54:	aa0403e0 	mov	x0, x4
    4b58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b5c:	f9401bf7 	ldr	x23, [sp, #48]
    4b60:	1e612800 	fadd	d0, d0, d1
    4b64:	fd0a1e60 	str	d0, [x19, #5176]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b70:	d65f03c0 	ret
    4b74:	97fffca4 	bl	3e04 <fwp_heap_init>
    4b78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b7c:	54fffa29 	b.ls	4ac0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b80:	2a1403e1 	mov	w1, w20
    4b84:	aa1503e0 	mov	x0, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b94:	17ffff70 	b	4954 <fwp_heap_alloc_big>
    4b98:	8b030042 	add	x2, x2, x3
    4b9c:	f9400444 	ldr	x4, [x2, #8]
    4ba0:	b4000104 	cbz	x4, 4bc0 <fwp_heap_alloc_slow+0x130>
    4ba4:	f9400840 	ldr	x0, [x2, #16]
    4ba8:	cb040000 	sub	x0, x0, x4
    4bac:	eb16001f 	cmp	x0, x22
    4bb0:	54000083 	b.cc	4bc0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4bb4:	8b160080 	add	x0, x4, x22
    4bb8:	f9000440 	str	x0, [x2, #8]
    4bbc:	17ffffd4 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4bc0:	52800302 	mov	w2, #0x18                  	// #24
    4bc4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bc8:	91154260 	add	x0, x19, #0x550
    4bcc:	9ba27c23 	umull	x3, w1, w2
    4bd0:	2a1403e2 	mov	w2, w20
    4bd4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bd8:	8b040000 	add	x0, x0, x4
    4bdc:	97fffeb5 	bl	46b0 <fwp_heap_refill>
    4be0:	aa0003e4 	mov	x4, x0
    4be4:	17ffffca 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4be8:	97fff8f2 	bl	2fb0 <fwp_heap_oom>
    4bec:	d503201f 	nop

0000000000004bf0 <fwp_heap_alloc>:
    4bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4bf4:	f140101f 	cmp	x0, #0x4, lsl #12
    4bf8:	910003fd 	mov	x29, sp
    4bfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4c00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    4c04:	91154293 	add	x19, x20, #0x550
    4c08:	b953a662 	ldr	w2, [x19, #5028]
    4c0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c10:	54000640 	b.eq	4cd8 <fwp_heap_alloc+0xe8>  // b.none
    4c14:	91003c03 	add	x3, x0, #0xf
    4c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c20:	8b431263 	add	x3, x19, x3, lsr #4
    4c24:	cb21c042 	sub	x2, x2, w1, sxtw
    4c28:	d37ae442 	lsl	x2, x2, #6
    4c2c:	397e8063 	ldrb	w3, [x3, #4000]
    4c30:	910f0064 	add	x4, x3, #0x3c0
    4c34:	8b030463 	add	x3, x3, x3, lsl #1
    4c38:	8b030c43 	add	x3, x2, x3, lsl #3
    4c3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c40:	2a1603f5 	mov	w21, w22
    4c44:	f8636a64 	ldr	x4, [x19, x3]
    4c48:	b4000384 	cbz	x4, 4cb8 <fwp_heap_alloc+0xc8>
    4c4c:	f9400085 	ldr	x5, [x4]
    4c50:	7100043f 	cmp	w1, #0x1
    4c54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c58:	aa0403e0 	mov	x0, x4
    4c5c:	aa2503e5 	mvn	x5, x5
    4c60:	52800001 	mov	w1, #0x0                   	// #0
    4c64:	f8236a65 	str	x5, [x19, x3]
    4c68:	97fff6d6 	bl	27c0 <memset@plt>
    4c6c:	aa0003e4 	mov	x4, x0
    4c70:	f94a1260 	ldr	x0, [x19, #5152]
    4c74:	ab150000 	adds	x0, x0, x21
    4c78:	54000442 	b.cs	4d00 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c7c:	f94a1661 	ldr	x1, [x19, #5160]
    4c80:	f90a1260 	str	x0, [x19, #5152]
    4c84:	eb01001f 	cmp	x0, x1
    4c88:	54000049 	b.ls	4c90 <fwp_heap_alloc+0xa0>  // b.plast
    4c8c:	f90a1660 	str	x0, [x19, #5160]
    4c90:	91154294 	add	x20, x20, #0x550
    4c94:	1e6302c1 	ucvtf	d1, w22
    4c98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c9c:	aa0403e0 	mov	x0, x4
    4ca0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ca4:	1e612800 	fadd	d0, d0, d1
    4ca8:	fd0a1e80 	str	d0, [x20, #5176]
    4cac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cb4:	d65f03c0 	ret
    4cb8:	8b030263 	add	x3, x19, x3
    4cbc:	f9400464 	ldr	x4, [x3, #8]
    4cc0:	b40000a4 	cbz	x4, 4cd4 <fwp_heap_alloc+0xe4>
    4cc4:	f9400862 	ldr	x2, [x3, #16]
    4cc8:	cb040042 	sub	x2, x2, x4
    4ccc:	eb15005f 	cmp	x2, x21
    4cd0:	540000a2 	b.cs	4ce4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ce0:	17ffff6c 	b	4a90 <fwp_heap_alloc_slow>
    4ce4:	7100043f 	cmp	w1, #0x1
    4ce8:	8b150085 	add	x5, x4, x21
    4cec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cf0:	52800001 	mov	w1, #0x0                   	// #0
    4cf4:	aa0403e0 	mov	x0, x4
    4cf8:	f9000465 	str	x5, [x3, #8]
    4cfc:	17ffffdb 	b	4c68 <fwp_heap_alloc+0x78>
    4d00:	97fff8ac 	bl	2fb0 <fwp_heap_oom>

0000000000004d04 <fwp_apply>:
    4d04:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d08:	aa0003e6 	mov	x6, x0
    4d0c:	910003fd 	mov	x29, sp
    4d10:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d14:	f947f463 	ldr	x3, [x3, #4072]
    4d18:	a90153f3 	stp	x19, x20, [sp, #16]
    4d1c:	aa0203f4 	mov	x20, x2
    4d20:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d24:	2a0103f5 	mov	w21, w1
    4d28:	52800033 	mov	w19, #0x1                   	// #1
    4d2c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d30:	900000f7 	adrp	x23, 20000 <__data_start>
    4d34:	910102f7 	add	x23, x23, #0x40
    4d38:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d3c:	d100c3ff 	sub	sp, sp, #0x30
    4d40:	f9400060 	ldr	x0, [x3]
    4d44:	f81f83a0 	stur	x0, [x29, #-8]
    4d48:	d2800000 	mov	x0, #0x0                   	// #0
    4d4c:	294058c3 	ldp	w3, w22, [x6]
    4d50:	910003f8 	mov	x24, sp
    4d54:	f9401ee0 	ldr	x0, [x23, #56]
    4d58:	710002df 	cmp	w22, #0x0
    4d5c:	d37be863 	lsl	x3, x3, #5
    4d60:	8b030007 	add	x7, x0, x3
    4d64:	b8636819 	ldr	w25, [x0, x3]
    4d68:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4d6c:	54000163 	b.cc	4d98 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4d70:	f94004e3 	ldr	x3, [x7, #8]
    4d74:	34000bd9 	cbz	w25, 4eec <fwp_apply+0x1e8>
    4d78:	aa1403e0 	mov	x0, x20
    4d7c:	d63f0060 	blr	x3
    4d80:	aa0003e6 	mov	x6, x0
    4d84:	6b1902bf 	cmp	w21, w25
    4d88:	54000940 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4d8c:	8b394e94 	add	x20, x20, w25, uxtw #3
    4d90:	4b1902b5 	sub	w21, w21, w25
    4d94:	17ffffee 	b	4d4c <fwp_apply+0x48>
    4d98:	0b1602ba 	add	w26, w21, w22
    4d9c:	6b19035f 	cmp	w26, w25
    4da0:	54000543 	b.cc	4e48 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4da4:	7100033f 	cmp	w25, #0x0
    4da8:	4b16033a 	sub	w26, w25, w22
    4dac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4db0:	d37df000 	lsl	x0, x0, #3
    4db4:	91003c00 	add	x0, x0, #0xf
    4db8:	92704c01 	and	x1, x0, #0xfffff0000
    4dbc:	927c7c00 	and	x0, x0, #0xffffffff0
    4dc0:	cb2163e1 	sub	x1, sp, x1
    4dc4:	eb2163ff 	cmp	sp, x1
    4dc8:	540000a0 	b.eq	4ddc <fwp_apply+0xd8>  // b.none
    4dcc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4dd0:	f90203ff 	str	xzr, [sp, #1024]
    4dd4:	eb2163ff 	cmp	sp, x1
    4dd8:	54ffffa1 	b.ne	4dcc <fwp_apply+0xc8>  // b.any
    4ddc:	92403c00 	and	x0, x0, #0xffff
    4de0:	cb2063ff 	sub	sp, sp, x0
    4de4:	f90003ff 	str	xzr, [sp]
    4de8:	f110001f 	cmp	x0, #0x400
    4dec:	54000962 	b.cs	4f18 <fwp_apply+0x214>  // b.hs, b.nlast
    4df0:	910020c6 	add	x6, x6, #0x8
    4df4:	910043e0 	add	x0, sp, #0x10
    4df8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4dfc:	d2800003 	mov	x3, #0x0                   	// #0
    4e00:	340000f6 	cbz	w22, 4e1c <fwp_apply+0x118>
    4e04:	d503201f 	nop
    4e08:	f86368c4 	ldr	x4, [x6, x3]
    4e0c:	f8236804 	str	x4, [x0, x3]
    4e10:	91002063 	add	x3, x3, #0x8
    4e14:	eb0300bf 	cmp	x5, x3
    4e18:	54ffff81 	b.ne	4e08 <fwp_apply+0x104>  // b.any
    4e1c:	3400013a 	cbz	w26, 4e40 <fwp_apply+0x13c>
    4e20:	2a1a03e6 	mov	w6, w26
    4e24:	d2800003 	mov	x3, #0x0                   	// #0
    4e28:	0b0302c4 	add	w4, w22, w3
    4e2c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e30:	91000463 	add	x3, x3, #0x1
    4e34:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e38:	eb0300df 	cmp	x6, x3
    4e3c:	54ffff61 	b.ne	4e28 <fwp_apply+0x124>  // b.any
    4e40:	f94004e3 	ldr	x3, [x7, #8]
    4e44:	1400002c 	b	4ef4 <fwp_apply+0x1f0>
    4e48:	11000740 	add	w0, w26, #0x1
    4e4c:	52800041 	mov	w1, #0x2                   	// #2
    4e50:	f81e83a6 	stur	x6, [x29, #-24]
    4e54:	d37df000 	lsl	x0, x0, #3
    4e58:	97ffff66 	bl	4bf0 <fwp_heap_alloc>
    4e5c:	f85e83a6 	ldur	x6, [x29, #-24]
    4e60:	aa0003f3 	mov	x19, x0
    4e64:	b94000c1 	ldr	w1, [x6]
    4e68:	29006801 	stp	w1, w26, [x0]
    4e6c:	340000b6 	cbz	w22, 4e80 <fwp_apply+0x17c>
    4e70:	910020c1 	add	x1, x6, #0x8
    4e74:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4e78:	91002000 	add	x0, x0, #0x8
    4e7c:	97fff5f9 	bl	2660 <memmove@plt>
    4e80:	2a1503e3 	mov	w3, w21
    4e84:	d2800000 	mov	x0, #0x0                   	// #0
    4e88:	34000135 	cbz	w21, 4eac <fwp_apply+0x1a8>
    4e8c:	d503201f 	nop
    4e90:	0b0002c1 	add	w1, w22, w0
    4e94:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4e98:	8b010e61 	add	x1, x19, x1, lsl #3
    4e9c:	91000400 	add	x0, x0, #0x1
    4ea0:	f9000422 	str	x2, [x1, #8]
    4ea4:	eb00007f 	cmp	x3, x0
    4ea8:	54ffff41 	b.ne	4e90 <fwp_apply+0x18c>  // b.any
    4eac:	aa1303e6 	mov	x6, x19
    4eb0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4eb4:	f947f400 	ldr	x0, [x0, #4072]
    4eb8:	f85f83a2 	ldur	x2, [x29, #-8]
    4ebc:	f9400001 	ldr	x1, [x0]
    4ec0:	eb010042 	subs	x2, x2, x1
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	540002c1 	b.ne	4f20 <fwp_apply+0x21c>  // b.any
    4ecc:	910003bf 	mov	sp, x29
    4ed0:	aa0603e0 	mov	x0, x6
    4ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ed8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4edc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ee0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ee4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ee8:	d65f03c0 	ret
    4eec:	d10043a0 	sub	x0, x29, #0x10
    4ef0:	5280001a 	mov	w26, #0x0                   	// #0
    4ef4:	d63f0060 	blr	x3
    4ef8:	aa0003e6 	mov	x6, x0
    4efc:	6b1a02bf 	cmp	w21, w26
    4f00:	54fffd80 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4f04:	0b1602b6 	add	w22, w21, w22
    4f08:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f0c:	4b1902d5 	sub	w21, w22, w25
    4f10:	9100031f 	mov	sp, x24
    4f14:	17ffff8e 	b	4d4c <fwp_apply+0x48>
    4f18:	f90203ff 	str	xzr, [sp, #1024]
    4f1c:	17ffffb5 	b	4df0 <fwp_apply+0xec>
    4f20:	97fff634 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f24 <fwp_p_ad_push>:
    4f24:	f100001f 	cmp	x0, #0x0
    4f28:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    4f2c:	5400118b 	b.lt	515c <fwp_p_ad_push+0x238>  // b.tstop
    4f30:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f40:	aa0403f6 	mov	x22, x4
    4f44:	aa0003f5 	mov	x21, x0
    4f48:	a90363f7 	stp	x23, x24, [sp, #48]
    4f4c:	aa0203f8 	mov	x24, x2
    4f50:	6d0627e8 	stp	d8, d9, [sp, #96]
    4f54:	9e670029 	fmov	d9, x1
    4f58:	9e670068 	fmov	d8, x3
    4f5c:	aa020001 	orr	x1, x0, x2
    4f60:	b6f80dc1 	tbz	x1, #63, 5118 <fwp_p_ad_push+0x1f4>
    4f64:	9360fc14 	asr	x20, x0, #32
    4f68:	b6f800c0 	tbz	x0, #63, 4f80 <fwp_p_ad_push+0x5c>
    4f6c:	1e604109 	fmov	d9, d8
    4f70:	2f00e408 	movi	d8, #0x0
    4f74:	9360fc54 	asr	x20, x2, #32
    4f78:	aa0203f5 	mov	x21, x2
    4f7c:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    4f80:	b4001136 	cbz	x22, 51a4 <fwp_p_ad_push+0x280>
    4f84:	f94002c0 	ldr	x0, [x22]
    4f88:	eb14001f 	cmp	x0, x20
    4f8c:	54000e40 	b.eq	5154 <fwp_p_ad_push+0x230>  // b.none
    4f90:	aa1403e0 	mov	x0, x20
    4f94:	97fffa27 	bl	3830 <fwp_tape_of>
    4f98:	aa0003f3 	mov	x19, x0
    4f9c:	f9403000 	ldr	x0, [x0, #96]
    4fa0:	b50010c0 	cbnz	x0, 51b8 <fwp_p_ad_push+0x294>
    4fa4:	a9004ed4 	stp	x20, x19, [x22]
    4fa8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    4fac:	f9400a77 	ldr	x23, [x19, #16]
    4fb0:	a9046bf9 	stp	x25, x26, [sp, #64]
    4fb4:	eb0002ff 	cmp	x23, x0
    4fb8:	540013ec 	b.gt	5234 <fwp_p_ad_push+0x310>
    4fbc:	eb3542ff 	cmp	x23, w21, uxtw
    4fc0:	5400132d 	b.le	5224 <fwp_p_ad_push+0x300>
    4fc4:	b7f80078 	tbnz	x24, #63, 4fd0 <fwp_p_ad_push+0xac>
    4fc8:	eb3842ff 	cmp	x23, w24, uxtw
    4fcc:	540012cd 	b.le	5224 <fwp_p_ad_push+0x300>
    4fd0:	f9400676 	ldr	x22, [x19, #8]
    4fd4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4fd8:	cb1602f6 	sub	x22, x23, x22
    4fdc:	910006c1 	add	x1, x22, #0x1
    4fe0:	aa1603f9 	mov	x25, x22
    4fe4:	eb00003f 	cmp	x1, x0
    4fe8:	54001268 	b.hi	5234 <fwp_p_ad_push+0x310>  // b.pmore
    4fec:	a9418274 	ldp	x20, x0, [x19, #24]
    4ff0:	eb14003f 	cmp	x1, x20
    4ff4:	54000a6d 	b.le	5140 <fwp_p_ad_push+0x21c>
    4ff8:	f100029f 	cmp	x20, #0x0
    4ffc:	d2800803 	mov	x3, #0x40                  	// #64
    5000:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5004:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5008:	a90573fb 	stp	x27, x28, [sp, #80]
    500c:	eb14003f 	cmp	x1, x20
    5010:	5400008d 	b.le	5020 <fwp_p_ad_push+0xfc>
    5014:	eb02029f 	cmp	x20, x2
    5018:	5400090d 	b.le	5138 <fwp_p_ad_push+0x214>
    501c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5020:	d37df29a 	lsl	x26, x20, #3
    5024:	f940327b 	ldr	x27, [x19, #96]
    5028:	aa1a03e1 	mov	x1, x26
    502c:	97fff5ed 	bl	27e0 <realloc@plt>
    5030:	b40010a0 	cbz	x0, 5244 <fwp_p_ad_push+0x320>
    5034:	f9400e61 	ldr	x1, [x19, #24]
    5038:	8b010801 	add	x1, x0, x1, lsl #2
    503c:	a9020660 	stp	x0, x1, [x19, #32]
    5040:	b400093b 	cbz	x27, 5164 <fwp_p_ad_push+0x240>
    5044:	f9403363 	ldr	x3, [x27, #96]
    5048:	f9003be3 	str	x3, [sp, #112]
    504c:	eb03029f 	cmp	x20, x3
    5050:	5400034d 	b.le	50b8 <fwp_p_ad_push+0x194>
    5054:	f940237c 	ldr	x28, [x27, #64]
    5058:	d37cee82 	lsl	x2, x20, #4
    505c:	aa0203e0 	mov	x0, x2
    5060:	52800041 	mov	w1, #0x2                   	// #2
    5064:	f9003fe2 	str	x2, [sp, #120]
    5068:	97fffee2 	bl	4bf0 <fwp_heap_alloc>
    506c:	aa0003fa 	mov	x26, x0
    5070:	b400013c 	cbz	x28, 5094 <fwp_p_ad_push+0x170>
    5074:	a9470be3 	ldp	x3, x2, [sp, #112]
    5078:	aa1c03e1 	mov	x1, x28
    507c:	d37cec63 	lsl	x3, x3, #4
    5080:	eb02007f 	cmp	x3, x2
    5084:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    5088:	97fff56e 	bl	2640 <memcpy@plt>
    508c:	aa1c03e0 	mov	x0, x28
    5090:	97fffdb8 	bl	4770 <fwp_mem_free>
    5094:	f9403360 	ldr	x0, [x27, #96]
    5098:	52800001 	mov	w1, #0x0                   	// #0
    509c:	cb000282 	sub	x2, x20, x0
    50a0:	8b001340 	add	x0, x26, x0, lsl #4
    50a4:	d37cec42 	lsl	x2, x2, #4
    50a8:	97fff5c6 	bl	27c0 <memset@plt>
    50ac:	f9401260 	ldr	x0, [x19, #32]
    50b0:	f900237a 	str	x26, [x27, #64]
    50b4:	f9003374 	str	x20, [x27, #96]
    50b8:	b50008b6 	cbnz	x22, 51cc <fwp_p_ad_push+0x2a8>
    50bc:	a9431263 	ldp	x3, x4, [x19, #48]
    50c0:	d37ef69a 	lsl	x26, x20, #2
    50c4:	a94573fb 	ldp	x27, x28, [sp, #80]
    50c8:	8b1a0002 	add	x2, x0, x26
    50cc:	f9000e74 	str	x20, [x19, #24]
    50d0:	f9001662 	str	x2, [x19, #40]
    50d4:	b8366815 	str	w21, [x0, x22]
    50d8:	f100031f 	cmp	x24, #0x0
    50dc:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    50e0:	92607eb5 	and	x21, x21, #0xffffffff00000000
    50e4:	fc396869 	str	d9, [x3, x25]
    50e8:	aa1702a0 	orr	x0, x21, x23
    50ec:	b8366841 	str	w1, [x2, x22]
    50f0:	910006e1 	add	x1, x23, #0x1
    50f4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50f8:	fc396888 	str	d8, [x4, x25]
    50fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    5100:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5104:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5108:	f9000a61 	str	x1, [x19, #16]
    510c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5110:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5114:	d65f03c0 	ret
    5118:	9360fc54 	asr	x20, x2, #32
    511c:	eb80829f 	cmp	x20, x0, asr #32
    5120:	54fff300 	b.eq	4f80 <fwp_p_ad_push+0x5c>  // b.none
    5124:	d0000020 	adrp	x0, b000 <__modti3+0x30>
    5128:	91198000 	add	x0, x0, #0x660
    512c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5130:	a90573fb 	stp	x27, x28, [sp, #80]
    5134:	97fff8f3 	bl	3500 <fwp_trap>
    5138:	d37ffa94 	lsl	x20, x20, #1
    513c:	17ffffb4 	b	500c <fwp_p_ad_push+0xe8>
    5140:	a9428e62 	ldp	x2, x3, [x19, #40]
    5144:	d37ef6d6 	lsl	x22, x22, #2
    5148:	f9401e64 	ldr	x4, [x19, #56]
    514c:	d37df339 	lsl	x25, x25, #3
    5150:	17ffffe1 	b	50d4 <fwp_p_ad_push+0x1b0>
    5154:	f94006d3 	ldr	x19, [x22, #8]
    5158:	17ffff94 	b	4fa8 <fwp_p_ad_push+0x84>
    515c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5160:	d65f03c0 	ret
    5164:	f9401a60 	ldr	x0, [x19, #48]
    5168:	d37cee9b 	lsl	x27, x20, #4
    516c:	aa1b03e1 	mov	x1, x27
    5170:	97fff59c 	bl	27e0 <realloc@plt>
    5174:	aa0003e3 	mov	x3, x0
    5178:	b4000660 	cbz	x0, 5244 <fwp_p_ad_push+0x320>
    517c:	8b1a0004 	add	x4, x0, x26
    5180:	f9400e60 	ldr	x0, [x19, #24]
    5184:	8b000c61 	add	x1, x3, x0, lsl #3
    5188:	a9030663 	stp	x3, x1, [x19, #48]
    518c:	b5000356 	cbnz	x22, 51f4 <fwp_p_ad_push+0x2d0>
    5190:	f9401260 	ldr	x0, [x19, #32]
    5194:	d37ef69a 	lsl	x26, x20, #2
    5198:	d2800016 	mov	x22, #0x0                   	// #0
    519c:	f9001e64 	str	x4, [x19, #56]
    51a0:	17ffffc9 	b	50c4 <fwp_p_ad_push+0x1a0>
    51a4:	aa1403e0 	mov	x0, x20
    51a8:	97fff9a2 	bl	3830 <fwp_tape_of>
    51ac:	aa0003f3 	mov	x19, x0
    51b0:	f9403000 	ldr	x0, [x0, #96]
    51b4:	b4ffefa0 	cbz	x0, 4fa8 <fwp_p_ad_push+0x84>
    51b8:	d0000020 	adrp	x0, b000 <__modti3+0x30>
    51bc:	911aa000 	add	x0, x0, #0x6a8
    51c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    51c4:	a90573fb 	stp	x27, x28, [sp, #80]
    51c8:	97fff8ce 	bl	3500 <fwp_trap>
    51cc:	d37df2d9 	lsl	x25, x22, #3
    51d0:	f9401661 	ldr	x1, [x19, #40]
    51d4:	d37ef6d6 	lsl	x22, x22, #2
    51d8:	d37ef69a 	lsl	x26, x20, #2
    51dc:	aa1603e2 	mov	x2, x22
    51e0:	8b1a0000 	add	x0, x0, x26
    51e4:	97fff51f 	bl	2660 <memmove@plt>
    51e8:	f9401260 	ldr	x0, [x19, #32]
    51ec:	a9431263 	ldp	x3, x4, [x19, #48]
    51f0:	17ffffb5 	b	50c4 <fwp_p_ad_push+0x1a0>
    51f4:	eb1b035f 	cmp	x26, x27
    51f8:	d37df2d9 	lsl	x25, x22, #3
    51fc:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    5200:	aa0403e0 	mov	x0, x4
    5204:	cb1a0063 	sub	x3, x3, x26
    5208:	aa1903e2 	mov	x2, x25
    520c:	97fff5e1 	bl	2990 <__memmove_chk@plt>
    5210:	f9401a61 	ldr	x1, [x19, #48]
    5214:	f9401260 	ldr	x0, [x19, #32]
    5218:	8b1a0021 	add	x1, x1, x26
    521c:	f9001e61 	str	x1, [x19, #56]
    5220:	17ffffec 	b	51d0 <fwp_p_ad_push+0x2ac>
    5224:	d0000020 	adrp	x0, b000 <__modti3+0x30>
    5228:	911be000 	add	x0, x0, #0x6f8
    522c:	a90573fb 	stp	x27, x28, [sp, #80]
    5230:	97fff8b4 	bl	3500 <fwp_trap>
    5234:	d0000020 	adrp	x0, b000 <__modti3+0x30>
    5238:	911b6000 	add	x0, x0, #0x6d8
    523c:	a90573fb 	stp	x27, x28, [sp, #80]
    5240:	97fff8b0 	bl	3500 <fwp_trap>
    5244:	aa1303e0 	mov	x0, x19
    5248:	97fff732 	bl	2f10 <fwp_tape_unlink_scope>
    524c:	f9401260 	ldr	x0, [x19, #32]
    5250:	97fff598 	bl	28b0 <free@plt>
    5254:	f9401a60 	ldr	x0, [x19, #48]
    5258:	97fff596 	bl	28b0 <free@plt>
    525c:	f9402260 	ldr	x0, [x19, #64]
    5260:	97fff594 	bl	28b0 <free@plt>
    5264:	f9000e7f 	str	xzr, [x19, #24]
    5268:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    526c:	f947e821 	ldr	x1, [x1, #4048]
    5270:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5274:	d2800262 	mov	x2, #0x13                  	// #19
    5278:	4f000400 	movi	v0.4s, #0x0
    527c:	d0000020 	adrp	x0, b000 <__modti3+0x30>
    5280:	f9400023 	ldr	x3, [x1]
    5284:	b900067f 	str	wzr, [x19, #4]
    5288:	d2800021 	mov	x1, #0x1                   	// #1
    528c:	910de000 	add	x0, x0, #0x378
    5290:	3c808260 	stur	q0, [x19, #8]
    5294:	ad010260 	stp	q0, q0, [x19, #32]
    5298:	97fff596 	bl	28f0 <fwrite@plt>
    529c:	d2800000 	mov	x0, #0x0                   	// #0
    52a0:	97fff5a0 	bl	2920 <fflush@plt>
    52a4:	52800cc0 	mov	w0, #0x66                  	// #102
    52a8:	97fff5ae 	bl	2960 <_Exit@plt>
    52ac:	d503201f 	nop

00000000000052b0 <w107>:
    52b0:	d10203ff 	sub	sp, sp, #0x80
    52b4:	9e660003 	fmov	x3, d0
    52b8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    52bc:	f947f442 	ldr	x2, [x2, #4072]
    52c0:	a9027bfd 	stp	x29, x30, [sp, #32]
    52c4:	910083fd 	add	x29, sp, #0x20
    52c8:	6d0627e8 	stp	d8, d9, [sp, #96]
    52cc:	1e604009 	fmov	d9, d0
    52d0:	1e604028 	fmov	d8, d1
    52d4:	fd003bea 	str	d10, [sp, #112]
    52d8:	1e60080a 	fmul	d10, d0, d0
    52dc:	a90353f3 	stp	x19, x20, [sp, #48]
    52e0:	910023f3 	add	x19, sp, #0x8
    52e4:	aa0003f4 	mov	x20, x0
    52e8:	a9045bf5 	stp	x21, x22, [sp, #64]
    52ec:	aa0103f6 	mov	x22, x1
    52f0:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    52f4:	a90563f7 	stp	x23, x24, [sp, #80]
    52f8:	aa0303e1 	mov	x1, x3
    52fc:	f9400044 	ldr	x4, [x2]
    5300:	f9000fe4 	str	x4, [sp, #24]
    5304:	d2800004 	mov	x4, #0x0                   	// #0
    5308:	aa0003e2 	mov	x2, x0
    530c:	aa1303e4 	mov	x4, x19
    5310:	a900fff5 	stp	x21, xzr, [sp, #8]
    5314:	97ffff04 	bl	4f24 <fwp_p_ad_push>
    5318:	1e6a3908 	fsub	d8, d8, d10
    531c:	aa1603e2 	mov	x2, x22
    5320:	aa1303e4 	mov	x4, x19
    5324:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5328:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    532c:	9e660118 	fmov	x24, d8
    5330:	97fffefd 	bl	4f24 <fwp_p_ad_push>
    5334:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5338:	aa0003f6 	mov	x22, x0
    533c:	aa1303e4 	mov	x4, x19
    5340:	aa1403e0 	mov	x0, x20
    5344:	1e69394a 	fsub	d10, d10, d9
    5348:	aa1503e2 	mov	x2, x21
    534c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5350:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5354:	9e660157 	fmov	x23, d10
    5358:	97fffef3 	bl	4f24 <fwp_p_ad_push>
    535c:	1e680908 	fmul	d8, d8, d8
    5360:	aa0003f4 	mov	x20, x0
    5364:	aa1303e4 	mov	x4, x19
    5368:	aa1803e3 	mov	x3, x24
    536c:	aa1803e1 	mov	x1, x24
    5370:	aa1603e2 	mov	x2, x22
    5374:	aa1603e0 	mov	x0, x22
    5378:	97fffeeb 	bl	4f24 <fwp_p_ad_push>
    537c:	aa0003e2 	mov	x2, x0
    5380:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5384:	9e670029 	fmov	d9, x1
    5388:	9e660101 	fmov	x1, d8
    538c:	aa1303e4 	mov	x4, x19
    5390:	1e690909 	fmul	d9, d8, d9
    5394:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5398:	aa1503e0 	mov	x0, x21
    539c:	97fffee2 	bl	4f24 <fwp_p_ad_push>
    53a0:	1e6a094a 	fmul	d10, d10, d10
    53a4:	aa1303e4 	mov	x4, x19
    53a8:	aa1703e3 	mov	x3, x23
    53ac:	aa0003f3 	mov	x19, x0
    53b0:	aa1703e1 	mov	x1, x23
    53b4:	aa1403e2 	mov	x2, x20
    53b8:	aa1403e0 	mov	x0, x20
    53bc:	97fffeda 	bl	4f24 <fwp_p_ad_push>
    53c0:	1e6a2929 	fadd	d9, d9, d10
    53c4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    53c8:	d2800004 	mov	x4, #0x0                   	// #0
    53cc:	aa0303e1 	mov	x1, x3
    53d0:	aa1303e2 	mov	x2, x19
    53d4:	97fffed4 	bl	4f24 <fwp_p_ad_push>
    53d8:	aa0003e1 	mov	x1, x0
    53dc:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    53e0:	f947f463 	ldr	x3, [x3, #4072]
    53e4:	f9400fe0 	ldr	x0, [sp, #24]
    53e8:	f9400064 	ldr	x4, [x3]
    53ec:	eb040000 	subs	x0, x0, x4
    53f0:	d2800004 	mov	x4, #0x0                   	// #0
    53f4:	54000161 	b.ne	5420 <w107+0x170>  // b.any
    53f8:	9e660122 	fmov	x2, d9
    53fc:	fd403bea 	ldr	d10, [sp, #112]
    5400:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5404:	a94353f3 	ldp	x19, x20, [sp, #48]
    5408:	aa0203e0 	mov	x0, x2
    540c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5410:	a94563f7 	ldp	x23, x24, [sp, #80]
    5414:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5418:	910203ff 	add	sp, sp, #0x80
    541c:	d65f03c0 	ret
    5420:	97fff4f4 	bl	27f0 <__stack_chk_fail@plt>

0000000000005424 <w164.constprop.0>:
    5424:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5428:	910003fd 	mov	x29, sp
    542c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5430:	fd001be8 	str	d8, [sp, #48]
    5434:	f9400015 	ldr	x21, [x0]
    5438:	b4000355 	cbz	x21, 54a0 <w164.constprop.0+0x7c>
    543c:	2f00e408 	movi	d8, #0x0
    5440:	91002016 	add	x22, x0, #0x8
    5444:	a90153f3 	stp	x19, x20, [sp, #16]
    5448:	91004014 	add	x20, x0, #0x10
    544c:	d2800013 	mov	x19, #0x0                   	// #0
    5450:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5454:	d503201f 	nop
    5458:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    545c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5460:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    5464:	aa0303e1 	mov	x1, x3
    5468:	1e602908 	fadd	d8, d8, d0
    546c:	d2800004 	mov	x4, #0x0                   	// #0
    5470:	91000a73 	add	x19, x19, #0x2
    5474:	97fffeac 	bl	4f24 <fwp_p_ad_push>
    5478:	eb1302bf 	cmp	x21, x19
    547c:	54fffee8 	b.hi	5458 <w164.constprop.0+0x34>  // b.pmore
    5480:	9e660102 	fmov	x2, d8
    5484:	fd401be8 	ldr	d8, [sp, #48]
    5488:	a94153f3 	ldp	x19, x20, [sp, #16]
    548c:	aa0003e1 	mov	x1, x0
    5490:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5494:	aa0203e0 	mov	x0, x2
    5498:	a8c47bfd 	ldp	x29, x30, [sp], #64
    549c:	d65f03c0 	ret
    54a0:	2f00e408 	movi	d8, #0x0
    54a4:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    54a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    54ac:	aa0003e1 	mov	x1, x0
    54b0:	9e660102 	fmov	x2, d8
    54b4:	fd401be8 	ldr	d8, [sp, #48]
    54b8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    54bc:	aa0203e0 	mov	x0, x2
    54c0:	d65f03c0 	ret

00000000000054c4 <fwp_data.part.0.constprop.0>:
    54c4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    54c8:	910003fd 	mov	x29, sp
    54cc:	a90153f3 	stp	x19, x20, [sp, #16]
    54d0:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    54d4:	91154283 	add	x3, x20, #0x550
    54d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    54dc:	aa0103f5 	mov	x21, x1
    54e0:	b953a461 	ldr	w1, [x3, #5028]
    54e4:	a90363f7 	stp	x23, x24, [sp, #48]
    54e8:	2a0003f8 	mov	w24, w0
    54ec:	34000701 	cbz	w1, 55cc <fwp_data.part.0.constprop.0+0x108>
    54f0:	397e8862 	ldrb	w2, [x3, #4002]
    54f4:	910f0040 	add	x0, x2, #0x3c0
    54f8:	8b020442 	add	x2, x2, x2, lsl #1
    54fc:	d37df042 	lsl	x2, x2, #3
    5500:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5504:	2a1703f6 	mov	w22, w23
    5508:	f8626873 	ldr	x19, [x3, x2]
    550c:	b40004d3 	cbz	x19, 55a4 <fwp_data.part.0.constprop.0+0xe0>
    5510:	f9400260 	ldr	x0, [x19]
    5514:	aa2003e0 	mvn	x0, x0
    5518:	f8226860 	str	x0, [x3, x2]
    551c:	f10062df 	cmp	x22, #0x18
    5520:	540000e9 	b.ls	553c <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5524:	d10066c2 	sub	x2, x22, #0x19
    5528:	91006260 	add	x0, x19, #0x18
    552c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5530:	52800001 	mov	w1, #0x0                   	// #0
    5534:	91002042 	add	x2, x2, #0x8
    5538:	97fff4a2 	bl	27c0 <memset@plt>
    553c:	91154282 	add	x2, x20, #0x550
    5540:	f94a1041 	ldr	x1, [x2, #5152]
    5544:	ab160021 	adds	x1, x1, x22
    5548:	540004c2 	b.cs	55e0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    554c:	f94a1440 	ldr	x0, [x2, #5160]
    5550:	f90a1041 	str	x1, [x2, #5152]
    5554:	eb00003f 	cmp	x1, x0
    5558:	54000049 	b.ls	5560 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    555c:	f90a1441 	str	x1, [x2, #5160]
    5560:	91154294 	add	x20, x20, #0x550
    5564:	1e6302e1 	ucvtf	d1, w23
    5568:	fd4a1e80 	ldr	d0, [x20, #5176]
    556c:	1e612800 	fadd	d0, d0, d1
    5570:	fd0a1e80 	str	d0, [x20, #5176]
    5574:	52800041 	mov	w1, #0x2                   	// #2
    5578:	29000678 	stp	w24, w1, [x19]
    557c:	aa1303e0 	mov	x0, x19
    5580:	f94002a1 	ldr	x1, [x21]
    5584:	f9000661 	str	x1, [x19, #8]
    5588:	f94006a1 	ldr	x1, [x21, #8]
    558c:	f9000a61 	str	x1, [x19, #16]
    5590:	a94153f3 	ldp	x19, x20, [sp, #16]
    5594:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5598:	a94363f7 	ldp	x23, x24, [sp, #48]
    559c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    55a0:	d65f03c0 	ret
    55a4:	8b020063 	add	x3, x3, x2
    55a8:	f9400473 	ldr	x19, [x3, #8]
    55ac:	b4000113 	cbz	x19, 55cc <fwp_data.part.0.constprop.0+0x108>
    55b0:	f9400860 	ldr	x0, [x3, #16]
    55b4:	cb130000 	sub	x0, x0, x19
    55b8:	eb0002df 	cmp	x22, x0
    55bc:	54000088 	b.hi	55cc <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    55c0:	8b160260 	add	x0, x19, x22
    55c4:	f9000460 	str	x0, [x3, #8]
    55c8:	17ffffd5 	b	551c <fwp_data.part.0.constprop.0+0x58>
    55cc:	52800001 	mov	w1, #0x0                   	// #0
    55d0:	d2800300 	mov	x0, #0x18                  	// #24
    55d4:	97fffd87 	bl	4bf0 <fwp_heap_alloc>
    55d8:	aa0003f3 	mov	x19, x0
    55dc:	17ffffe6 	b	5574 <fwp_data.part.0.constprop.0+0xb0>
    55e0:	97fff674 	bl	2fb0 <fwp_heap_oom>

00000000000055e4 <fwp_rc_share>:
    55e4:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    55e8:	91154042 	add	x2, x2, #0x550
    55ec:	f949d843 	ldr	x3, [x2, #5040]
    55f0:	f949ec41 	ldr	x1, [x2, #5080]
    55f4:	cb030000 	sub	x0, x0, x3
    55f8:	eb01401f 	cmp	x0, x1, lsl #16
    55fc:	540002c2 	b.cs	5654 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5600:	d350fc01 	lsr	x1, x0, #16
    5604:	f949fc44 	ldr	x4, [x2, #5112]
    5608:	8b010821 	add	x1, x1, x1, lsl #2
    560c:	d37df021 	lsl	x1, x1, #3
    5610:	8b010083 	add	x3, x4, x1
    5614:	f9401062 	ldr	x2, [x3, #32]
    5618:	b40001e2 	cbz	x2, 5654 <fwp_rc_share+0x70>
    561c:	38616881 	ldrb	w1, [x4, x1]
    5620:	7100083f 	cmp	w1, #0x2
    5624:	540001a0 	b.eq	5658 <fwp_rc_share+0x74>  // b.none
    5628:	7100043f 	cmp	w1, #0x1
    562c:	54000141 	b.ne	5654 <fwp_rc_share+0x70>  // b.any
    5630:	29430464 	ldp	w4, w1, [x3, #24]
    5634:	92403c00 	and	x0, x0, #0xffff
    5638:	9b047c00 	mul	x0, x0, x4
    563c:	d360fc00 	lsr	x0, x0, #32
    5640:	eb01001f 	cmp	x0, x1
    5644:	54000082 	b.cs	5654 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5648:	8b000042 	add	x2, x2, x0
    564c:	39400040 	ldrb	w0, [x2]
    5650:	350000a0 	cbnz	w0, 5664 <fwp_rc_share+0x80>
    5654:	d65f03c0 	ret
    5658:	72003c1f 	tst	w0, #0xffff
    565c:	54ffff80 	b.eq	564c <fwp_rc_share+0x68>  // b.none
    5660:	d65f03c0 	ret
    5664:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5668:	d0000020 	adrp	x0, b000 <__modti3+0x30>
    566c:	911c6000 	add	x0, x0, #0x718
    5670:	910003fd 	mov	x29, sp
    5674:	97fff7a3 	bl	3500 <fwp_trap>
    5678:	d503201f 	nop
    567c:	d503201f 	nop

0000000000005680 <fwp_rc_free_arr>:
    5680:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    5684:	91154063 	add	x3, x3, #0x550
    5688:	f949d861 	ldr	x1, [x3, #5040]
    568c:	f949ec62 	ldr	x2, [x3, #5080]
    5690:	cb010001 	sub	x1, x0, x1
    5694:	eb02403f 	cmp	x1, x2, lsl #16
    5698:	54000342 	b.cs	5700 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    569c:	d350fc22 	lsr	x2, x1, #16
    56a0:	f949fc65 	ldr	x5, [x3, #5112]
    56a4:	8b020842 	add	x2, x2, x2, lsl #2
    56a8:	d37df042 	lsl	x2, x2, #3
    56ac:	8b0200a4 	add	x4, x5, x2
    56b0:	f9401083 	ldr	x3, [x4, #32]
    56b4:	b4000263 	cbz	x3, 5700 <fwp_rc_free_arr+0x80>
    56b8:	386268a2 	ldrb	w2, [x5, x2]
    56bc:	7100085f 	cmp	w2, #0x2
    56c0:	540001c0 	b.eq	56f8 <fwp_rc_free_arr+0x78>  // b.none
    56c4:	7100045f 	cmp	w2, #0x1
    56c8:	540001c1 	b.ne	5700 <fwp_rc_free_arr+0x80>  // b.any
    56cc:	29430885 	ldp	w5, w2, [x4, #24]
    56d0:	92403c21 	and	x1, x1, #0xffff
    56d4:	9b057c21 	mul	x1, x1, x5
    56d8:	d360fc21 	lsr	x1, x1, #32
    56dc:	eb02003f 	cmp	x1, x2
    56e0:	54000102 	b.cs	5700 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    56e4:	8b010063 	add	x3, x3, x1
    56e8:	39400061 	ldrb	w1, [x3]
    56ec:	7100043f 	cmp	w1, #0x1
    56f0:	54000081 	b.ne	5700 <fwp_rc_free_arr+0x80>  // b.any
    56f4:	17fffc1f 	b	4770 <fwp_mem_free>
    56f8:	72003c3f 	tst	w1, #0xffff
    56fc:	54ffff60 	b.eq	56e8 <fwp_rc_free_arr+0x68>  // b.none
    5700:	d65f03c0 	ret

0000000000005704 <fwp_rc_dup>:
    5704:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    5708:	91154042 	add	x2, x2, #0x550
    570c:	f949d841 	ldr	x1, [x2, #5040]
    5710:	f949ec43 	ldr	x3, [x2, #5080]
    5714:	cb010001 	sub	x1, x0, x1
    5718:	eb03403f 	cmp	x1, x3, lsl #16
    571c:	54000342 	b.cs	5784 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5720:	d350fc20 	lsr	x0, x1, #16
    5724:	f949fc44 	ldr	x4, [x2, #5112]
    5728:	8b000800 	add	x0, x0, x0, lsl #2
    572c:	d37df002 	lsl	x2, x0, #3
    5730:	8b020083 	add	x3, x4, x2
    5734:	f9401060 	ldr	x0, [x3, #32]
    5738:	b4000260 	cbz	x0, 5784 <fwp_rc_dup+0x80>
    573c:	38626882 	ldrb	w2, [x4, x2]
    5740:	7100085f 	cmp	w2, #0x2
    5744:	54000220 	b.eq	5788 <fwp_rc_dup+0x84>  // b.none
    5748:	7100045f 	cmp	w2, #0x1
    574c:	540001c1 	b.ne	5784 <fwp_rc_dup+0x80>  // b.any
    5750:	29430864 	ldp	w4, w2, [x3, #24]
    5754:	92403c21 	and	x1, x1, #0xffff
    5758:	9b047c21 	mul	x1, x1, x4
    575c:	d360fc21 	lsr	x1, x1, #32
    5760:	eb02003f 	cmp	x1, x2
    5764:	54000102 	b.cs	5784 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5768:	8b010000 	add	x0, x0, x1
    576c:	39400001 	ldrb	w1, [x0]
    5770:	340000a1 	cbz	w1, 5784 <fwp_rc_dup+0x80>
    5774:	7103f43f 	cmp	w1, #0xfd
    5778:	540000e8 	b.hi	5794 <fwp_rc_dup+0x90>  // b.pmore
    577c:	11000421 	add	w1, w1, #0x1
    5780:	39000001 	strb	w1, [x0]
    5784:	d65f03c0 	ret
    5788:	72003c3f 	tst	w1, #0xffff
    578c:	54ffff00 	b.eq	576c <fwp_rc_dup+0x68>  // b.none
    5790:	d65f03c0 	ret
    5794:	17fffb10 	b	43d4 <fwp_rc_wide_dup>
    5798:	d503201f 	nop
    579c:	d503201f 	nop

00000000000057a0 <fwp_drop0>:
    57a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    57a4:	910003fd 	mov	x29, sp
    57a8:	a90153f3 	stp	x19, x20, [sp, #16]
    57ac:	f90013f5 	str	x21, [sp, #32]
    57b0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    57b4:	911542b4 	add	x20, x21, #0x550
    57b8:	f949da81 	ldr	x1, [x20, #5040]
    57bc:	f949ee82 	ldr	x2, [x20, #5080]
    57c0:	cb010001 	sub	x1, x0, x1
    57c4:	eb02403f 	cmp	x1, x2, lsl #16
    57c8:	54000382 	b.cs	5838 <fwp_drop0+0x98>  // b.hs, b.nlast
    57cc:	d350fc22 	lsr	x2, x1, #16
    57d0:	f949fe84 	ldr	x4, [x20, #5112]
    57d4:	8b020842 	add	x2, x2, x2, lsl #2
    57d8:	d37df042 	lsl	x2, x2, #3
    57dc:	8b020083 	add	x3, x4, x2
    57e0:	f9401073 	ldr	x19, [x3, #32]
    57e4:	b40002b3 	cbz	x19, 5838 <fwp_drop0+0x98>
    57e8:	38626882 	ldrb	w2, [x4, x2]
    57ec:	7100085f 	cmp	w2, #0x2
    57f0:	540002c0 	b.eq	5848 <fwp_drop0+0xa8>  // b.none
    57f4:	7100045f 	cmp	w2, #0x1
    57f8:	54000201 	b.ne	5838 <fwp_drop0+0x98>  // b.any
    57fc:	29430864 	ldp	w4, w2, [x3, #24]
    5800:	92403c21 	and	x1, x1, #0xffff
    5804:	9b047c21 	mul	x1, x1, x4
    5808:	d360fc21 	lsr	x1, x1, #32
    580c:	eb02003f 	cmp	x1, x2
    5810:	54000142 	b.cs	5838 <fwp_drop0+0x98>  // b.hs, b.nlast
    5814:	8b010273 	add	x19, x19, x1
    5818:	39400261 	ldrb	w1, [x19]
    581c:	340000e1 	cbz	w1, 5838 <fwp_drop0+0x98>
    5820:	7100043f 	cmp	w1, #0x1
    5824:	540001e0 	b.eq	5860 <fwp_drop0+0xc0>  // b.none
    5828:	7103fc3f 	cmp	w1, #0xff
    582c:	540002e0 	b.eq	5888 <fwp_drop0+0xe8>  // b.none
    5830:	51000421 	sub	w1, w1, #0x1
    5834:	39000261 	strb	w1, [x19]
    5838:	a94153f3 	ldp	x19, x20, [sp, #16]
    583c:	f94013f5 	ldr	x21, [sp, #32]
    5840:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5844:	d65f03c0 	ret
    5848:	72003c3f 	tst	w1, #0xffff
    584c:	54fffe60 	b.eq	5818 <fwp_drop0+0x78>  // b.none
    5850:	a94153f3 	ldp	x19, x20, [sp, #16]
    5854:	f94013f5 	ldr	x21, [sp, #32]
    5858:	a8c37bfd 	ldp	x29, x30, [sp], #48
    585c:	d65f03c0 	ret
    5860:	f9400813 	ldr	x19, [x0, #16]
    5864:	97ffff87 	bl	5680 <fwp_rc_free_arr>
    5868:	911542a0 	add	x0, x21, #0x550
    586c:	f949d801 	ldr	x1, [x0, #5040]
    5870:	f949ec00 	ldr	x0, [x0, #5080]
    5874:	cb010261 	sub	x1, x19, x1
    5878:	eb00403f 	cmp	x1, x0, lsl #16
    587c:	54fffde2 	b.cs	5838 <fwp_drop0+0x98>  // b.hs, b.nlast
    5880:	aa1303e0 	mov	x0, x19
    5884:	17ffffd2 	b	57cc <fwp_drop0+0x2c>
    5888:	ca534660 	eor	x0, x19, x19, lsr #17
    588c:	911542b5 	add	x21, x21, #0x550
    5890:	ca402400 	eor	x0, x0, x0, lsr #9
    5894:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5898:	f94a2400 	ldr	x0, [x0, #5192]
    589c:	b5000080 	cbnz	x0, 58ac <fwp_drop0+0x10c>
    58a0:	14000010 	b	58e0 <fwp_drop0+0x140>
    58a4:	f9400800 	ldr	x0, [x0, #16]
    58a8:	b40001c0 	cbz	x0, 58e0 <fwp_drop0+0x140>
    58ac:	f9400001 	ldr	x1, [x0]
    58b0:	eb13003f 	cmp	x1, x19
    58b4:	54ffff81 	b.ne	58a4 <fwp_drop0+0x104>  // b.any
    58b8:	f9400401 	ldr	x1, [x0, #8]
    58bc:	d1000421 	sub	x1, x1, #0x1
    58c0:	f9000401 	str	x1, [x0, #8]
    58c4:	f103f83f 	cmp	x1, #0xfe
    58c8:	54fffb81 	b.ne	5838 <fwp_drop0+0x98>  // b.any
    58cc:	aa1303e0 	mov	x0, x19
    58d0:	97fffb08 	bl	44f0 <fwp_rc_forget_slot>
    58d4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    58d8:	39000260 	strb	w0, [x19]
    58dc:	17ffffd7 	b	5838 <fwp_drop0+0x98>
    58e0:	d0000020 	adrp	x0, b000 <__modti3+0x30>
    58e4:	91186000 	add	x0, x0, #0x618
    58e8:	97fff706 	bl	3500 <fwp_trap>
    58ec:	d503201f 	nop

00000000000058f0 <fwp_arg_drop12>:
    58f0:	7100003f 	cmp	w1, #0x0
    58f4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    58f8:	54000041 	b.ne	5900 <fwp_arg_drop12+0x10>  // b.any
    58fc:	d65f03c0 	ret
    5900:	f9400000 	ldr	x0, [x0]
    5904:	17ffffa7 	b	57a0 <fwp_drop0>
    5908:	d503201f 	nop
    590c:	d503201f 	nop

0000000000005910 <fwp_drop1>:
    5910:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5914:	910003fd 	mov	x29, sp
    5918:	a90153f3 	stp	x19, x20, [sp, #16]
    591c:	f90013f5 	str	x21, [sp, #32]
    5920:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5924:	911542b4 	add	x20, x21, #0x550
    5928:	f949da81 	ldr	x1, [x20, #5040]
    592c:	f949ee82 	ldr	x2, [x20, #5080]
    5930:	cb010001 	sub	x1, x0, x1
    5934:	eb02403f 	cmp	x1, x2, lsl #16
    5938:	54000382 	b.cs	59a8 <fwp_drop1+0x98>  // b.hs, b.nlast
    593c:	d350fc22 	lsr	x2, x1, #16
    5940:	f949fe84 	ldr	x4, [x20, #5112]
    5944:	8b020842 	add	x2, x2, x2, lsl #2
    5948:	d37df042 	lsl	x2, x2, #3
    594c:	8b020083 	add	x3, x4, x2
    5950:	f9401073 	ldr	x19, [x3, #32]
    5954:	b40002b3 	cbz	x19, 59a8 <fwp_drop1+0x98>
    5958:	38626882 	ldrb	w2, [x4, x2]
    595c:	7100085f 	cmp	w2, #0x2
    5960:	540002c0 	b.eq	59b8 <fwp_drop1+0xa8>  // b.none
    5964:	7100045f 	cmp	w2, #0x1
    5968:	54000201 	b.ne	59a8 <fwp_drop1+0x98>  // b.any
    596c:	29430864 	ldp	w4, w2, [x3, #24]
    5970:	92403c21 	and	x1, x1, #0xffff
    5974:	9b047c21 	mul	x1, x1, x4
    5978:	d360fc21 	lsr	x1, x1, #32
    597c:	eb02003f 	cmp	x1, x2
    5980:	54000142 	b.cs	59a8 <fwp_drop1+0x98>  // b.hs, b.nlast
    5984:	8b010273 	add	x19, x19, x1
    5988:	39400261 	ldrb	w1, [x19]
    598c:	340000e1 	cbz	w1, 59a8 <fwp_drop1+0x98>
    5990:	7100043f 	cmp	w1, #0x1
    5994:	540001e0 	b.eq	59d0 <fwp_drop1+0xc0>  // b.none
    5998:	7103fc3f 	cmp	w1, #0xff
    599c:	540002e0 	b.eq	59f8 <fwp_drop1+0xe8>  // b.none
    59a0:	51000421 	sub	w1, w1, #0x1
    59a4:	39000261 	strb	w1, [x19]
    59a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    59ac:	f94013f5 	ldr	x21, [sp, #32]
    59b0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    59b4:	d65f03c0 	ret
    59b8:	72003c3f 	tst	w1, #0xffff
    59bc:	54fffe60 	b.eq	5988 <fwp_drop1+0x78>  // b.none
    59c0:	a94153f3 	ldp	x19, x20, [sp, #16]
    59c4:	f94013f5 	ldr	x21, [sp, #32]
    59c8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    59cc:	d65f03c0 	ret
    59d0:	f9400813 	ldr	x19, [x0, #16]
    59d4:	97ffff2b 	bl	5680 <fwp_rc_free_arr>
    59d8:	911542a0 	add	x0, x21, #0x550
    59dc:	f949d801 	ldr	x1, [x0, #5040]
    59e0:	f949ec00 	ldr	x0, [x0, #5080]
    59e4:	cb010261 	sub	x1, x19, x1
    59e8:	eb00403f 	cmp	x1, x0, lsl #16
    59ec:	54fffde2 	b.cs	59a8 <fwp_drop1+0x98>  // b.hs, b.nlast
    59f0:	aa1303e0 	mov	x0, x19
    59f4:	17ffffd2 	b	593c <fwp_drop1+0x2c>
    59f8:	ca534660 	eor	x0, x19, x19, lsr #17
    59fc:	911542b5 	add	x21, x21, #0x550
    5a00:	ca402400 	eor	x0, x0, x0, lsr #9
    5a04:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5a08:	f94a2400 	ldr	x0, [x0, #5192]
    5a0c:	b5000080 	cbnz	x0, 5a1c <fwp_drop1+0x10c>
    5a10:	14000010 	b	5a50 <fwp_drop1+0x140>
    5a14:	f9400800 	ldr	x0, [x0, #16]
    5a18:	b40001c0 	cbz	x0, 5a50 <fwp_drop1+0x140>
    5a1c:	f9400001 	ldr	x1, [x0]
    5a20:	eb13003f 	cmp	x1, x19
    5a24:	54ffff81 	b.ne	5a14 <fwp_drop1+0x104>  // b.any
    5a28:	f9400401 	ldr	x1, [x0, #8]
    5a2c:	d1000421 	sub	x1, x1, #0x1
    5a30:	f9000401 	str	x1, [x0, #8]
    5a34:	f103f83f 	cmp	x1, #0xfe
    5a38:	54fffb81 	b.ne	59a8 <fwp_drop1+0x98>  // b.any
    5a3c:	aa1303e0 	mov	x0, x19
    5a40:	97fffaac 	bl	44f0 <fwp_rc_forget_slot>
    5a44:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5a48:	39000260 	strb	w0, [x19]
    5a4c:	17ffffd7 	b	59a8 <fwp_drop1+0x98>
    5a50:	d0000020 	adrp	x0, b000 <__modti3+0x30>
    5a54:	91186000 	add	x0, x0, #0x618
    5a58:	97fff6aa 	bl	3500 <fwp_trap>
    5a5c:	d503201f 	nop

0000000000005a60 <fwp_closure_drop>:
    5a60:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc90>
    5a64:	911540a4 	add	x4, x5, #0x550
    5a68:	aa0003e1 	mov	x1, x0
    5a6c:	f949d882 	ldr	x2, [x4, #5040]
    5a70:	f949ec80 	ldr	x0, [x4, #5080]
    5a74:	cb020022 	sub	x2, x1, x2
    5a78:	eb00405f 	cmp	x2, x0, lsl #16
    5a7c:	54000662 	b.cs	5b48 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5a80:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5a84:	d350fc43 	lsr	x3, x2, #16
    5a88:	910003fd 	mov	x29, sp
    5a8c:	8b030863 	add	x3, x3, x3, lsl #2
    5a90:	f949fc84 	ldr	x4, [x4, #5112]
    5a94:	d37df063 	lsl	x3, x3, #3
    5a98:	f9000bf3 	str	x19, [sp, #16]
    5a9c:	8b030080 	add	x0, x4, x3
    5aa0:	f9401013 	ldr	x19, [x0, #32]
    5aa4:	b40002b3 	cbz	x19, 5af8 <fwp_closure_drop+0x98>
    5aa8:	38636883 	ldrb	w3, [x4, x3]
    5aac:	7100087f 	cmp	w3, #0x2
    5ab0:	54000420 	b.eq	5b34 <fwp_closure_drop+0xd4>  // b.none
    5ab4:	7100047f 	cmp	w3, #0x1
    5ab8:	54000201 	b.ne	5af8 <fwp_closure_drop+0x98>  // b.any
    5abc:	29430003 	ldp	w3, w0, [x0, #24]
    5ac0:	92403c42 	and	x2, x2, #0xffff
    5ac4:	9b037c42 	mul	x2, x2, x3
    5ac8:	d360fc42 	lsr	x2, x2, #32
    5acc:	eb00005f 	cmp	x2, x0
    5ad0:	54000142 	b.cs	5af8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5ad4:	8b020273 	add	x19, x19, x2
    5ad8:	39400260 	ldrb	w0, [x19]
    5adc:	340000e0 	cbz	w0, 5af8 <fwp_closure_drop+0x98>
    5ae0:	7100041f 	cmp	w0, #0x1
    5ae4:	54000100 	b.eq	5b04 <fwp_closure_drop+0xa4>  // b.none
    5ae8:	7103fc1f 	cmp	w0, #0xff
    5aec:	54000300 	b.eq	5b4c <fwp_closure_drop+0xec>  // b.none
    5af0:	51000400 	sub	w0, w0, #0x1
    5af4:	39000260 	strb	w0, [x19]
    5af8:	f9400bf3 	ldr	x19, [sp, #16]
    5afc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b00:	d65f03c0 	ret
    5b04:	d53bd040 	mrs	x0, tpidr_el0
    5b08:	91400000 	add	x0, x0, #0x0, lsl #12
    5b0c:	91004000 	add	x0, x0, #0x10
    5b10:	f9400000 	ldr	x0, [x0]
    5b14:	b4000080 	cbz	x0, 5b24 <fwp_closure_drop+0xc4>
    5b18:	f9400bf3 	ldr	x19, [sp, #16]
    5b1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b20:	17fff691 	b	3564 <fwp_closure_drop_push>
    5b24:	f9400bf3 	ldr	x19, [sp, #16]
    5b28:	aa0103e0 	mov	x0, x1
    5b2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b30:	17fff6fc 	b	3720 <fwp_closure_drop.part.0>
    5b34:	72003c5f 	tst	w2, #0xffff
    5b38:	54fffd00 	b.eq	5ad8 <fwp_closure_drop+0x78>  // b.none
    5b3c:	f9400bf3 	ldr	x19, [sp, #16]
    5b40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b44:	d65f03c0 	ret
    5b48:	d65f03c0 	ret
    5b4c:	ca534660 	eor	x0, x19, x19, lsr #17
    5b50:	911540a5 	add	x5, x5, #0x550
    5b54:	ca402400 	eor	x0, x0, x0, lsr #9
    5b58:	8b200ca0 	add	x0, x5, w0, uxtb #3
    5b5c:	f94a2400 	ldr	x0, [x0, #5192]
    5b60:	b5000080 	cbnz	x0, 5b70 <fwp_closure_drop+0x110>
    5b64:	14000010 	b	5ba4 <fwp_closure_drop+0x144>
    5b68:	f9400800 	ldr	x0, [x0, #16]
    5b6c:	b40001c0 	cbz	x0, 5ba4 <fwp_closure_drop+0x144>
    5b70:	f9400001 	ldr	x1, [x0]
    5b74:	eb13003f 	cmp	x1, x19
    5b78:	54ffff81 	b.ne	5b68 <fwp_closure_drop+0x108>  // b.any
    5b7c:	f9400401 	ldr	x1, [x0, #8]
    5b80:	d1000421 	sub	x1, x1, #0x1
    5b84:	f9000401 	str	x1, [x0, #8]
    5b88:	f103f83f 	cmp	x1, #0xfe
    5b8c:	54fffb61 	b.ne	5af8 <fwp_closure_drop+0x98>  // b.any
    5b90:	aa1303e0 	mov	x0, x19
    5b94:	97fffa57 	bl	44f0 <fwp_rc_forget_slot>
    5b98:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b9c:	39000260 	strb	w0, [x19]
    5ba0:	17ffffd6 	b	5af8 <fwp_closure_drop+0x98>
    5ba4:	d0000020 	adrp	x0, b000 <__modti3+0x30>
    5ba8:	91186000 	add	x0, x0, #0x618
    5bac:	97fff655 	bl	3500 <fwp_trap>

0000000000005bb0 <fwp_owned_tape_release>:
    5bb0:	b4000940 	cbz	x0, 5cd8 <fwp_owned_tape_release+0x128>
    5bb4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5bb8:	910003fd 	mov	x29, sp
    5bbc:	a90153f3 	stp	x19, x20, [sp, #16]
    5bc0:	aa0003f3 	mov	x19, x0
    5bc4:	f9400000 	ldr	x0, [x0]
    5bc8:	b4000060 	cbz	x0, 5bd4 <fwp_owned_tape_release+0x24>
    5bcc:	f9400661 	ldr	x1, [x19, #8]
    5bd0:	f9000401 	str	x1, [x0, #8]
    5bd4:	f9400661 	ldr	x1, [x19, #8]
    5bd8:	b4000041 	cbz	x1, 5be0 <fwp_owned_tape_release+0x30>
    5bdc:	f9000020 	str	x0, [x1]
    5be0:	f9400a60 	ldr	x0, [x19, #16]
    5be4:	f9403401 	ldr	x1, [x0, #104]
    5be8:	b40005c1 	cbz	x1, 5ca0 <fwp_owned_tape_release+0xf0>
    5bec:	a9450a60 	ldp	x0, x2, [x19, #80]
    5bf0:	eb00005f 	cmp	x2, x0
    5bf4:	540002ed 	b.le	5c50 <fwp_owned_tape_release+0xa0>
    5bf8:	d2800014 	mov	x20, #0x0                   	// #0
    5bfc:	f90013f5 	str	x21, [sp, #32]
    5c00:	d2800015 	mov	x21, #0x0                   	// #0
    5c04:	d503201f 	nop
    5c08:	f9402260 	ldr	x0, [x19, #64]
    5c0c:	910006b5 	add	x21, x21, #0x1
    5c10:	f8746800 	ldr	x0, [x0, x20]
    5c14:	d63f0020 	blr	x1
    5c18:	f9402260 	ldr	x0, [x19, #64]
    5c1c:	f9400a61 	ldr	x1, [x19, #16]
    5c20:	8b140000 	add	x0, x0, x20
    5c24:	91004294 	add	x20, x20, #0x10
    5c28:	f9400400 	ldr	x0, [x0, #8]
    5c2c:	f9403421 	ldr	x1, [x1, #104]
    5c30:	d63f0020 	blr	x1
    5c34:	a9450261 	ldp	x1, x0, [x19, #80]
    5c38:	cb010000 	sub	x0, x0, x1
    5c3c:	eb15001f 	cmp	x0, x21
    5c40:	f9400a60 	ldr	x0, [x19, #16]
    5c44:	f9403401 	ldr	x1, [x0, #104]
    5c48:	54fffe0c 	b.gt	5c08 <fwp_owned_tape_release+0x58>
    5c4c:	f94013f5 	ldr	x21, [sp, #32]
    5c50:	f9403663 	ldr	x3, [x19, #104]
    5c54:	f9401262 	ldr	x2, [x19, #32]
    5c58:	f100007f 	cmp	x3, #0x0
    5c5c:	540001ed 	b.le	5c98 <fwp_owned_tape_release+0xe8>
    5c60:	d2800014 	mov	x20, #0x0                   	// #0
    5c64:	d503201f 	nop
    5c68:	f9402660 	ldr	x0, [x19, #72]
    5c6c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5c70:	eb02001f 	cmp	x0, x2
    5c74:	540000c0 	b.eq	5c8c <fwp_owned_tape_release+0xdc>  // b.none
    5c78:	d63f0020 	blr	x1
    5c7c:	f9400a60 	ldr	x0, [x19, #16]
    5c80:	f9401262 	ldr	x2, [x19, #32]
    5c84:	f9403663 	ldr	x3, [x19, #104]
    5c88:	f9403401 	ldr	x1, [x0, #104]
    5c8c:	91000694 	add	x20, x20, #0x1
    5c90:	eb14007f 	cmp	x3, x20
    5c94:	54fffeac 	b.gt	5c68 <fwp_owned_tape_release+0xb8>
    5c98:	aa0203e0 	mov	x0, x2
    5c9c:	d63f0020 	blr	x1
    5ca0:	f9401660 	ldr	x0, [x19, #40]
    5ca4:	97ffff6f 	bl	5a60 <fwp_closure_drop>
    5ca8:	f9401a60 	ldr	x0, [x19, #48]
    5cac:	97ffff6d 	bl	5a60 <fwp_closure_drop>
    5cb0:	f9401e60 	ldr	x0, [x19, #56]
    5cb4:	97ffff6b 	bl	5a60 <fwp_closure_drop>
    5cb8:	f9402260 	ldr	x0, [x19, #64]
    5cbc:	97fffaad 	bl	4770 <fwp_mem_free>
    5cc0:	f9402660 	ldr	x0, [x19, #72]
    5cc4:	97fffaab 	bl	4770 <fwp_mem_free>
    5cc8:	aa1303e0 	mov	x0, x19
    5ccc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5cd0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5cd4:	17fffaa7 	b	4770 <fwp_mem_free>
    5cd8:	d65f03c0 	ret
    5cdc:	d503201f 	nop

0000000000005ce0 <fwp_tape_finish>:
    5ce0:	d10203ff 	sub	sp, sp, #0x80
    5ce4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5ce8:	f947f421 	ldr	x1, [x1, #4072]
    5cec:	a9047bfd 	stp	x29, x30, [sp, #64]
    5cf0:	910103fd 	add	x29, sp, #0x40
    5cf4:	a90553f3 	stp	x19, x20, [sp, #80]
    5cf8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5cfc:	a90763f7 	stp	x23, x24, [sp, #112]
    5d00:	f00000d8 	adrp	x24, 20000 <__data_start>
    5d04:	91010316 	add	x22, x24, #0x40
    5d08:	f9400022 	ldr	x2, [x1]
    5d0c:	f9001fe2 	str	x2, [sp, #56]
    5d10:	d2800002 	mov	x2, #0x0                   	// #0
    5d14:	910122c0 	add	x0, x22, #0x48
    5d18:	97fff55a 	bl	3280 <fwp_tape_buffers_dispose>
    5d1c:	f90042df 	str	xzr, [x22, #128]
    5d20:	f94022c0 	ldr	x0, [x22, #64]
    5d24:	f100001f 	cmp	x0, #0x0
    5d28:	5400030d 	b.le	5d88 <fwp_tape_finish+0xa8>
    5d2c:	910003f7 	mov	x23, sp
    5d30:	d2800015 	mov	x21, #0x0                   	// #0
    5d34:	d2800014 	mov	x20, #0x0                   	// #0
    5d38:	f94002d3 	ldr	x19, [x22]
    5d3c:	91000694 	add	x20, x20, #0x1
    5d40:	8b150273 	add	x19, x19, x21
    5d44:	9101a2b5 	add	x21, x21, #0x68
    5d48:	aa1303e0 	mov	x0, x19
    5d4c:	97fff471 	bl	2f10 <fwp_tape_unlink_scope>
    5d50:	aa1703e0 	mov	x0, x23
    5d54:	f9401261 	ldr	x1, [x19, #32]
    5d58:	f90003e1 	str	x1, [sp]
    5d5c:	f9401a62 	ldr	x2, [x19, #48]
    5d60:	f9000be2 	str	x2, [sp, #16]
    5d64:	f9402261 	ldr	x1, [x19, #64]
    5d68:	f90013e1 	str	x1, [sp, #32]
    5d6c:	97fff545 	bl	3280 <fwp_tape_buffers_dispose>
    5d70:	f9403260 	ldr	x0, [x19, #96]
    5d74:	97ffff8f 	bl	5bb0 <fwp_owned_tape_release>
    5d78:	f900327f 	str	xzr, [x19, #96]
    5d7c:	f94022c0 	ldr	x0, [x22, #64]
    5d80:	eb14001f 	cmp	x0, x20
    5d84:	54fffdac 	b.gt	5d38 <fwp_tape_finish+0x58>
    5d88:	f9402300 	ldr	x0, [x24, #64]
    5d8c:	91010313 	add	x19, x24, #0x40
    5d90:	97fff2c8 	bl	28b0 <free@plt>
    5d94:	f900231f 	str	xzr, [x24, #64]
    5d98:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5d9c:	f947f400 	ldr	x0, [x0, #4072]
    5da0:	f900227f 	str	xzr, [x19, #64]
    5da4:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    5da8:	f9401fe2 	ldr	x2, [sp, #56]
    5dac:	f9400001 	ldr	x1, [x0]
    5db0:	eb010042 	subs	x2, x2, x1
    5db4:	d2800001 	mov	x1, #0x0                   	// #0
    5db8:	540000e1 	b.ne	5dd4 <fwp_tape_finish+0xf4>  // b.any
    5dbc:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5dc0:	a94553f3 	ldp	x19, x20, [sp, #80]
    5dc4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5dc8:	a94763f7 	ldp	x23, x24, [sp, #112]
    5dcc:	910203ff 	add	sp, sp, #0x80
    5dd0:	d65f03c0 	ret
    5dd4:	97fff287 	bl	27f0 <__stack_chk_fail@plt>
    5dd8:	d503201f 	nop
    5ddc:	d503201f 	nop

0000000000005de0 <fwp_tape_scope_release>:
    5de0:	d10243ff 	sub	sp, sp, #0x90
    5de4:	a9047bfd 	stp	x29, x30, [sp, #64]
    5de8:	910103fd 	add	x29, sp, #0x40
    5dec:	a90553f3 	stp	x19, x20, [sp, #80]
    5df0:	aa0003f4 	mov	x20, x0
    5df4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5df8:	f947f400 	ldr	x0, [x0, #4072]
    5dfc:	b9400285 	ldr	w5, [x20]
    5e00:	f9400001 	ldr	x1, [x0]
    5e04:	f9001fe1 	str	x1, [sp, #56]
    5e08:	d2800001 	mov	x1, #0x0                   	// #0
    5e0c:	37f806c5 	tbnz	w5, #31, 5ee4 <fwp_tape_scope_release+0x104>
    5e10:	a90763f7 	stp	x23, x24, [sp, #112]
    5e14:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    5e18:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    5e1c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    5e20:	f00000d3 	adrp	x19, 20000 <__data_start>
    5e24:	910003f7 	mov	x23, sp
    5e28:	91010273 	add	x19, x19, #0x40
    5e2c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    5e30:	a9065bf5 	stp	x21, x22, [sp, #96]
    5e34:	52800d16 	mov	w22, #0x68                  	// #104
    5e38:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    5e3c:	f90043f9 	str	x25, [sp, #128]
    5e40:	14000006 	b	5e58 <fwp_tape_scope_release+0x78>
    5e44:	97fff50f 	bl	3280 <fwp_tape_buffers_dispose>
    5e48:	aa1903e0 	mov	x0, x25
    5e4c:	97ffff59 	bl	5bb0 <fwp_owned_tape_release>
    5e50:	b9400285 	ldr	w5, [x20]
    5e54:	37f80425 	tbnz	w5, #31, 5ed8 <fwp_tape_scope_release+0xf8>
    5e58:	f9400266 	ldr	x6, [x19]
    5e5c:	9b367ca5 	smull	x5, w5, w22
    5e60:	8b0500c0 	add	x0, x6, x5
    5e64:	97fff42b 	bl	2f10 <fwp_tape_unlink_scope>
    5e68:	ad410001 	ldp	q1, q0, [x0, #32]
    5e6c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    5e70:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    5e74:	f9400c03 	ldr	x3, [x0, #24]
    5e78:	ad0003e1 	stp	q1, q0, [sp]
    5e7c:	b86568c1 	ldr	w1, [x6, x5]
    5e80:	a9440804 	ldp	x4, x2, [x0, #64]
    5e84:	b900041f 	str	wzr, [x0, #4]
    5e88:	f9403019 	ldr	x25, [x0, #96]
    5e8c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    5e90:	f9000c1f 	str	xzr, [x0, #24]
    5e94:	a9020fe4 	stp	x4, x3, [sp, #32]
    5e98:	f9001be2 	str	x2, [sp, #48]
    5e9c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    5ea0:	f900301f 	str	xzr, [x0, #96]
    5ea4:	6b15003f 	cmp	w1, w21
    5ea8:	540000e8 	b.hi	5ec4 <fwp_tape_scope_release+0xe4>  // b.pmore
    5eac:	9343fca5 	asr	x5, x5, #3
    5eb0:	f9404e60 	ldr	x0, [x19, #152]
    5eb4:	9b187ca5 	mul	x5, x5, x24
    5eb8:	eb0000bf 	cmp	x5, x0
    5ebc:	5400004a 	b.ge	5ec4 <fwp_tape_scope_release+0xe4>  // b.tcont
    5ec0:	f9004e65 	str	x5, [x19, #152]
    5ec4:	aa1703e0 	mov	x0, x23
    5ec8:	b5fffbf9 	cbnz	x25, 5e44 <fwp_tape_scope_release+0x64>
    5ecc:	97fff86d 	bl	4080 <fwp_tape_buffers_release>
    5ed0:	b9400285 	ldr	w5, [x20]
    5ed4:	36fffc25 	tbz	w5, #31, 5e58 <fwp_tape_scope_release+0x78>
    5ed8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    5edc:	a94763f7 	ldp	x23, x24, [sp, #112]
    5ee0:	f94043f9 	ldr	x25, [sp, #128]
    5ee4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    5ee8:	f947f400 	ldr	x0, [x0, #4072]
    5eec:	f9401fe2 	ldr	x2, [sp, #56]
    5ef0:	f9400001 	ldr	x1, [x0]
    5ef4:	eb010042 	subs	x2, x2, x1
    5ef8:	d2800001 	mov	x1, #0x0                   	// #0
    5efc:	540000a1 	b.ne	5f10 <fwp_tape_scope_release+0x130>  // b.any
    5f00:	a9447bfd 	ldp	x29, x30, [sp, #64]
    5f04:	a94553f3 	ldp	x19, x20, [sp, #80]
    5f08:	910243ff 	add	sp, sp, #0x90
    5f0c:	d65f03c0 	ret
    5f10:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f14:	a90763f7 	stp	x23, x24, [sp, #112]
    5f18:	f90043f9 	str	x25, [sp, #128]
    5f1c:	97fff235 	bl	27f0 <__stack_chk_fail@plt>

0000000000005f20 <fwp_task_dispose>:
    5f20:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5f24:	910003fd 	mov	x29, sp
    5f28:	f9000bf3 	str	x19, [sp, #16]
    5f2c:	aa0003f3 	mov	x19, x0
    5f30:	39414000 	ldrb	w0, [x0, #80]
    5f34:	36000720 	tbz	w0, #0, 6018 <fwp_task_dispose+0xf8>
    5f38:	f9400a60 	ldr	x0, [x19, #16]
    5f3c:	b50006e0 	cbnz	x0, 6018 <fwp_task_dispose+0xf8>
    5f40:	a9478660 	ldp	x0, x1, [x19, #120]
    5f44:	39014e7f 	strb	wzr, [x19, #83]
    5f48:	f9003e7f 	str	xzr, [x19, #120]
    5f4c:	f100003f 	cmp	x1, #0x0
    5f50:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    5f54:	54000040 	b.eq	5f5c <fwp_task_dispose+0x3c>  // b.none
    5f58:	d63f0020 	blr	x1
    5f5c:	f9405660 	ldr	x0, [x19, #168]
    5f60:	97fffa04 	bl	4770 <fwp_mem_free>
    5f64:	f900567f 	str	xzr, [x19, #168]
    5f68:	b9405e60 	ldr	w0, [x19, #92]
    5f6c:	7100041f 	cmp	w0, #0x1
    5f70:	54000420 	b.eq	5ff4 <fwp_task_dispose+0xd4>  // b.none
    5f74:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    5f78:	91154042 	add	x2, x2, #0x550
    5f7c:	f949d840 	ldr	x0, [x2, #5040]
    5f80:	f949ec41 	ldr	x1, [x2, #5080]
    5f84:	cb000260 	sub	x0, x19, x0
    5f88:	eb01401f 	cmp	x0, x1, lsl #16
    5f8c:	540002e2 	b.cs	5fe8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    5f90:	d350fc01 	lsr	x1, x0, #16
    5f94:	f949fc44 	ldr	x4, [x2, #5112]
    5f98:	8b010821 	add	x1, x1, x1, lsl #2
    5f9c:	d37df021 	lsl	x1, x1, #3
    5fa0:	8b010083 	add	x3, x4, x1
    5fa4:	f9401062 	ldr	x2, [x3, #32]
    5fa8:	b4000202 	cbz	x2, 5fe8 <fwp_task_dispose+0xc8>
    5fac:	38616881 	ldrb	w1, [x4, x1]
    5fb0:	7100083f 	cmp	w1, #0x2
    5fb4:	54000280 	b.eq	6004 <fwp_task_dispose+0xe4>  // b.none
    5fb8:	7100043f 	cmp	w1, #0x1
    5fbc:	54000161 	b.ne	5fe8 <fwp_task_dispose+0xc8>  // b.any
    5fc0:	29430464 	ldp	w4, w1, [x3, #24]
    5fc4:	92403c00 	and	x0, x0, #0xffff
    5fc8:	9b047c00 	mul	x0, x0, x4
    5fcc:	d360fc00 	lsr	x0, x0, #32
    5fd0:	eb01001f 	cmp	x0, x1
    5fd4:	540000a2 	b.cs	5fe8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    5fd8:	8b000042 	add	x2, x2, x0
    5fdc:	39400040 	ldrb	w0, [x2]
    5fe0:	7100041f 	cmp	w0, #0x1
    5fe4:	54000080 	b.eq	5ff4 <fwp_task_dispose+0xd4>  // b.none
    5fe8:	f9400bf3 	ldr	x19, [sp, #16]
    5fec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ff0:	d65f03c0 	ret
    5ff4:	aa1303e0 	mov	x0, x19
    5ff8:	f9400bf3 	ldr	x19, [sp, #16]
    5ffc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6000:	17fff9dc 	b	4770 <fwp_mem_free>
    6004:	72003c1f 	tst	w0, #0xffff
    6008:	54fffea0 	b.eq	5fdc <fwp_task_dispose+0xbc>  // b.none
    600c:	f9400bf3 	ldr	x19, [sp, #16]
    6010:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6014:	d65f03c0 	ret
    6018:	97fff20a 	bl	2840 <abort@plt>
    601c:	d503201f 	nop

0000000000006020 <fwp_free_zombie>:
    6020:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6024:	910003fd 	mov	x29, sp
    6028:	a90153f3 	stp	x19, x20, [sp, #16]
    602c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6030:	91010281 	add	x1, x20, #0x40
    6034:	f9405033 	ldr	x19, [x1, #160]
    6038:	b4000333 	cbz	x19, 609c <fwp_free_zombie+0x7c>
    603c:	f9400820 	ldr	x0, [x1, #16]
    6040:	eb00027f 	cmp	x19, x0
    6044:	540002c0 	b.eq	609c <fwp_free_zombie+0x7c>  // b.none
    6048:	b940a822 	ldr	w2, [x1, #168]
    604c:	f9400a60 	ldr	x0, [x19, #16]
    6050:	7100fc5f 	cmp	w2, #0x3f
    6054:	5400078c 	b.gt	6144 <fwp_free_zombie+0x124>
    6058:	9102c023 	add	x3, x1, #0xb0
    605c:	11000444 	add	w4, w2, #0x1
    6060:	b900a824 	str	w4, [x1, #168]
    6064:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6068:	f822d860 	str	x0, [x3, w2, sxtw #3]
    606c:	a9530261 	ldp	x1, x0, [x19, #304]
    6070:	b4000741 	cbz	x1, 6158 <fwp_free_zombie+0x138>
    6074:	f9009c20 	str	x0, [x1, #312]
    6078:	b4000040 	cbz	x0, 6080 <fwp_free_zombie+0x60>
    607c:	f9009801 	str	x1, [x0, #304]
    6080:	91010294 	add	x20, x20, #0x40
    6084:	b9405e60 	ldr	w0, [x19, #92]
    6088:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    608c:	f900529f 	str	xzr, [x20, #160]
    6090:	34000140 	cbz	w0, 60b8 <fwp_free_zombie+0x98>
    6094:	7100041f 	cmp	w0, #0x1
    6098:	54000080 	b.eq	60a8 <fwp_free_zombie+0x88>  // b.none
    609c:	a94153f3 	ldp	x19, x20, [sp, #16]
    60a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60a4:	d65f03c0 	ret
    60a8:	aa1303e0 	mov	x0, x19
    60ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    60b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    60b4:	17ffff9b 	b	5f20 <fwp_task_dispose>
    60b8:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc90>
    60bc:	91154082 	add	x2, x4, #0x550
    60c0:	f949d841 	ldr	x1, [x2, #5040]
    60c4:	f949ec40 	ldr	x0, [x2, #5080]
    60c8:	cb010261 	sub	x1, x19, x1
    60cc:	eb00403f 	cmp	x1, x0, lsl #16
    60d0:	54fffe62 	b.cs	609c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    60d4:	d350fc20 	lsr	x0, x1, #16
    60d8:	f949fc43 	ldr	x3, [x2, #5112]
    60dc:	8b000800 	add	x0, x0, x0, lsl #2
    60e0:	d37df000 	lsl	x0, x0, #3
    60e4:	8b000062 	add	x2, x3, x0
    60e8:	f9401054 	ldr	x20, [x2, #32]
    60ec:	b4fffd94 	cbz	x20, 609c <fwp_free_zombie+0x7c>
    60f0:	38606860 	ldrb	w0, [x3, x0]
    60f4:	7100081f 	cmp	w0, #0x2
    60f8:	54000360 	b.eq	6164 <fwp_free_zombie+0x144>  // b.none
    60fc:	7100041f 	cmp	w0, #0x1
    6100:	54fffce1 	b.ne	609c <fwp_free_zombie+0x7c>  // b.any
    6104:	29430043 	ldp	w3, w0, [x2, #24]
    6108:	92403c21 	and	x1, x1, #0xffff
    610c:	9b037c21 	mul	x1, x1, x3
    6110:	d360fc21 	lsr	x1, x1, #32
    6114:	eb00003f 	cmp	x1, x0
    6118:	54fffc22 	b.cs	609c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    611c:	8b010294 	add	x20, x20, x1
    6120:	39400280 	ldrb	w0, [x20]
    6124:	34fffbc0 	cbz	w0, 609c <fwp_free_zombie+0x7c>
    6128:	7100041f 	cmp	w0, #0x1
    612c:	54fffbe0 	b.eq	60a8 <fwp_free_zombie+0x88>  // b.none
    6130:	7103fc1f 	cmp	w0, #0xff
    6134:	540001e0 	b.eq	6170 <fwp_free_zombie+0x150>  // b.none
    6138:	51000400 	sub	w0, w0, #0x1
    613c:	39000280 	strb	w0, [x20]
    6140:	17ffffd7 	b	609c <fwp_free_zombie+0x7c>
    6144:	f9400e61 	ldr	x1, [x19, #24]
    6148:	97fff1f2 	bl	2910 <munmap@plt>
    614c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6150:	a9530261 	ldp	x1, x0, [x19, #304]
    6154:	b5fff901 	cbnz	x1, 6074 <fwp_free_zombie+0x54>
    6158:	91010282 	add	x2, x20, #0x40
    615c:	f9015840 	str	x0, [x2, #688]
    6160:	17ffffc6 	b	6078 <fwp_free_zombie+0x58>
    6164:	72003c3f 	tst	w1, #0xffff
    6168:	54fff9a1 	b.ne	609c <fwp_free_zombie+0x7c>  // b.any
    616c:	17ffffed 	b	6120 <fwp_free_zombie+0x100>
    6170:	ca544680 	eor	x0, x20, x20, lsr #17
    6174:	91154084 	add	x4, x4, #0x550
    6178:	ca402400 	eor	x0, x0, x0, lsr #9
    617c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6180:	f94a2400 	ldr	x0, [x0, #5192]
    6184:	b5000080 	cbnz	x0, 6194 <fwp_free_zombie+0x174>
    6188:	14000010 	b	61c8 <fwp_free_zombie+0x1a8>
    618c:	f9400800 	ldr	x0, [x0, #16]
    6190:	b40001c0 	cbz	x0, 61c8 <fwp_free_zombie+0x1a8>
    6194:	f9400001 	ldr	x1, [x0]
    6198:	eb14003f 	cmp	x1, x20
    619c:	54ffff81 	b.ne	618c <fwp_free_zombie+0x16c>  // b.any
    61a0:	f9400401 	ldr	x1, [x0, #8]
    61a4:	d1000421 	sub	x1, x1, #0x1
    61a8:	f9000401 	str	x1, [x0, #8]
    61ac:	f103f83f 	cmp	x1, #0xfe
    61b0:	54fff761 	b.ne	609c <fwp_free_zombie+0x7c>  // b.any
    61b4:	aa1403e0 	mov	x0, x20
    61b8:	97fff8ce 	bl	44f0 <fwp_rc_forget_slot>
    61bc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    61c0:	39000280 	strb	w0, [x20]
    61c4:	17ffffb6 	b	609c <fwp_free_zombie+0x7c>
    61c8:	b0000020 	adrp	x0, b000 <__modti3+0x30>
    61cc:	91186000 	add	x0, x0, #0x618
    61d0:	97fff4cc 	bl	3500 <fwp_trap>

00000000000061d4 <fwp_block>:
    61d4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    61d8:	910003fd 	mov	x29, sp
    61dc:	a90153f3 	stp	x19, x20, [sp, #16]
    61e0:	d00000d3 	adrp	x19, 20000 <__data_start>
    61e4:	91010274 	add	x20, x19, #0x40
    61e8:	f9401a82 	ldr	x2, [x20, #48]
    61ec:	b4000622 	cbz	x2, 62b0 <fwp_block+0xdc>
    61f0:	91010261 	add	x1, x19, #0x40
    61f4:	f9408040 	ldr	x0, [x2, #256]
    61f8:	f9001820 	str	x0, [x1, #48]
    61fc:	b4000680 	cbz	x0, 62cc <fwp_block+0xf8>
    6200:	91010263 	add	x3, x19, #0x40
    6204:	3901505f 	strb	wzr, [x2, #84]
    6208:	f9400864 	ldr	x4, [x3, #16]
    620c:	eb02009f 	cmp	x4, x2
    6210:	54000440 	b.eq	6298 <fwp_block+0xc4>  // b.none
    6214:	f9415c65 	ldr	x5, [x3, #696]
    6218:	f9000862 	str	x2, [x3, #16]
    621c:	f9400441 	ldr	x1, [x2, #8]
    6220:	f9004885 	str	x5, [x4, #144]
    6224:	f9416065 	ldr	x5, [x3, #704]
    6228:	f9004c85 	str	x5, [x4, #152]
    622c:	f9416465 	ldr	x5, [x3, #712]
    6230:	f9005085 	str	x5, [x4, #160]
    6234:	f9416865 	ldr	x5, [x3, #720]
    6238:	f9005485 	str	x5, [x4, #168]
    623c:	f9416c65 	ldr	x5, [x3, #728]
    6240:	f9005885 	str	x5, [x4, #176]
    6244:	f9417065 	ldr	x5, [x3, #736]
    6248:	f9005c85 	str	x5, [x4, #184]
    624c:	f9417465 	ldr	x5, [x3, #744]
    6250:	f9006085 	str	x5, [x4, #192]
    6254:	f9400480 	ldr	x0, [x4, #8]
    6258:	f9404844 	ldr	x4, [x2, #144]
    625c:	f9015c64 	str	x4, [x3, #696]
    6260:	f9404c44 	ldr	x4, [x2, #152]
    6264:	f9016064 	str	x4, [x3, #704]
    6268:	f9405044 	ldr	x4, [x2, #160]
    626c:	f9016464 	str	x4, [x3, #712]
    6270:	f9405444 	ldr	x4, [x2, #168]
    6274:	f9016864 	str	x4, [x3, #720]
    6278:	f9405844 	ldr	x4, [x2, #176]
    627c:	f9016c64 	str	x4, [x3, #728]
    6280:	a94b8844 	ldp	x4, x2, [x2, #184]
    6284:	f9017064 	str	x4, [x3, #736]
    6288:	f9017462 	str	x2, [x3, #744]
    628c:	97fff171 	bl	2850 <swapcontext@plt>
    6290:	97ffff64 	bl	6020 <fwp_free_zombie>
    6294:	d503201f 	nop
    6298:	91010260 	add	x0, x19, #0x40
    629c:	b942f000 	ldr	w0, [x0, #752]
    62a0:	340001a0 	cbz	w0, 62d4 <fwp_block+0x100>
    62a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    62a8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62ac:	d65f03c0 	ret
    62b0:	97fff7bc 	bl	41a0 <fwp_poll_events>
    62b4:	f9401a82 	ldr	x2, [x20, #48]
    62b8:	b4ffffc2 	cbz	x2, 62b0 <fwp_block+0xdc>
    62bc:	91010261 	add	x1, x19, #0x40
    62c0:	f9408040 	ldr	x0, [x2, #256]
    62c4:	f9001820 	str	x0, [x1, #48]
    62c8:	b5fff9c0 	cbnz	x0, 6200 <fwp_block+0x2c>
    62cc:	f900143f 	str	xzr, [x1, #40]
    62d0:	17ffffcc 	b	6200 <fwp_block+0x2c>
    62d4:	b0000020 	adrp	x0, b000 <__modti3+0x30>
    62d8:	911d2000 	add	x0, x0, #0x748
    62dc:	97fff1a9 	bl	2980 <getenv@plt>
    62e0:	5284e202 	mov	w2, #0x2710                	// #10000
    62e4:	b4000060 	cbz	x0, 62f0 <fwp_block+0x11c>
    62e8:	39400001 	ldrb	w1, [x0]
    62ec:	350000c1 	cbnz	w1, 6304 <fwp_block+0x130>
    62f0:	91010273 	add	x19, x19, #0x40
    62f4:	b902f262 	str	w2, [x19, #752]
    62f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    62fc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6300:	d65f03c0 	ret
    6304:	52800142 	mov	w2, #0xa                   	// #10
    6308:	d2800001 	mov	x1, #0x0                   	// #0
    630c:	97fff0ed 	bl	26c0 <strtoll@plt>
    6310:	d1000403 	sub	x3, x0, #0x1
    6314:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6318:	eb02007f 	cmp	x3, x2
    631c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6320:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6324:	17fffff3 	b	62f0 <fwp_block+0x11c>
    6328:	d503201f 	nop
    632c:	d503201f 	nop

0000000000006330 <fwp_owned_entry161>:
    6330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6334:	910003fd 	mov	x29, sp
    6338:	a90363f7 	stp	x23, x24, [sp, #48]
    633c:	a9406002 	ldp	x2, x24, [x0]
    6340:	a90153f3 	stp	x19, x20, [sp, #16]
    6344:	f9400801 	ldr	x1, [x0, #16]
    6348:	a9025bf5 	stp	x21, x22, [sp, #32]
    634c:	ab010055 	adds	x21, x2, x1
    6350:	54000d06 	b.vs	64f0 <fwp_owned_entry161+0x1c0>
    6354:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc90>
    6358:	91154281 	add	x1, x20, #0x550
    635c:	b953a420 	ldr	w0, [x1, #5028]
    6360:	34000a80 	cbz	w0, 64b0 <fwp_owned_entry161+0x180>
    6364:	397e8820 	ldrb	w0, [x1, #4002]
    6368:	910f0002 	add	x2, x0, #0x3c0
    636c:	8b000400 	add	x0, x0, x0, lsl #1
    6370:	d37df000 	lsl	x0, x0, #3
    6374:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6378:	2a1703f6 	mov	w22, w23
    637c:	f8606833 	ldr	x19, [x1, x0]
    6380:	b4000853 	cbz	x19, 6488 <fwp_owned_entry161+0x158>
    6384:	f9400262 	ldr	x2, [x19]
    6388:	aa2203e2 	mvn	x2, x2
    638c:	f8206822 	str	x2, [x1, x0]
    6390:	f10062df 	cmp	x22, #0x18
    6394:	540000e9 	b.ls	63b0 <fwp_owned_entry161+0x80>  // b.plast
    6398:	d10066c2 	sub	x2, x22, #0x19
    639c:	91006260 	add	x0, x19, #0x18
    63a0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    63a4:	52800001 	mov	w1, #0x0                   	// #0
    63a8:	91002042 	add	x2, x2, #0x8
    63ac:	97fff105 	bl	27c0 <memset@plt>
    63b0:	91154281 	add	x1, x20, #0x550
    63b4:	f94a1020 	ldr	x0, [x1, #5152]
    63b8:	ab160000 	adds	x0, x0, x22
    63bc:	540009c2 	b.cs	64f4 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    63c0:	f94a1422 	ldr	x2, [x1, #5160]
    63c4:	f90a1020 	str	x0, [x1, #5152]
    63c8:	eb02001f 	cmp	x0, x2
    63cc:	54000049 	b.ls	63d4 <fwp_owned_entry161+0xa4>  // b.plast
    63d0:	f90a1420 	str	x0, [x1, #5160]
    63d4:	91154280 	add	x0, x20, #0x550
    63d8:	1e6302e1 	ucvtf	d1, w23
    63dc:	fd4a1c00 	ldr	d0, [x0, #5176]
    63e0:	1e612800 	fadd	d0, d0, d1
    63e4:	fd0a1c00 	str	d0, [x0, #5176]
    63e8:	d0000020 	adrp	x0, c000 <msg.4+0x20>
    63ec:	91154294 	add	x20, x20, #0x550
    63f0:	a900d678 	stp	x24, x21, [x19, #8]
    63f4:	fd402000 	ldr	d0, [x0, #64]
    63f8:	fd000260 	str	d0, [x19]
    63fc:	f949da81 	ldr	x1, [x20, #5040]
    6400:	f949ee80 	ldr	x0, [x20, #5080]
    6404:	cb010261 	sub	x1, x19, x1
    6408:	eb00403f 	cmp	x1, x0, lsl #16
    640c:	54000322 	b.cs	6470 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6410:	d350fc20 	lsr	x0, x1, #16
    6414:	f949fe83 	ldr	x3, [x20, #5112]
    6418:	8b000800 	add	x0, x0, x0, lsl #2
    641c:	d37df002 	lsl	x2, x0, #3
    6420:	8b020060 	add	x0, x3, x2
    6424:	f9401014 	ldr	x20, [x0, #32]
    6428:	b4000254 	cbz	x20, 6470 <fwp_owned_entry161+0x140>
    642c:	38626862 	ldrb	w2, [x3, x2]
    6430:	7100085f 	cmp	w2, #0x2
    6434:	54000480 	b.eq	64c4 <fwp_owned_entry161+0x194>  // b.none
    6438:	7100045f 	cmp	w2, #0x1
    643c:	540001a1 	b.ne	6470 <fwp_owned_entry161+0x140>  // b.any
    6440:	29430002 	ldp	w2, w0, [x0, #24]
    6444:	92403c21 	and	x1, x1, #0xffff
    6448:	9b027c21 	mul	x1, x1, x2
    644c:	d360fc21 	lsr	x1, x1, #32
    6450:	eb00003f 	cmp	x1, x0
    6454:	540000e2 	b.cs	6470 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6458:	8b010294 	add	x20, x20, x1
    645c:	39400280 	ldrb	w0, [x20]
    6460:	7103fc1f 	cmp	w0, #0xff
    6464:	54000400 	b.eq	64e4 <fwp_owned_entry161+0x1b4>  // b.none
    6468:	52800020 	mov	w0, #0x1                   	// #1
    646c:	39000280 	strb	w0, [x20]
    6470:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6474:	aa1303e0 	mov	x0, x19
    6478:	a94153f3 	ldp	x19, x20, [sp, #16]
    647c:	a94363f7 	ldp	x23, x24, [sp, #48]
    6480:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6484:	d65f03c0 	ret
    6488:	8b000021 	add	x1, x1, x0
    648c:	f9400433 	ldr	x19, [x1, #8]
    6490:	b4000113 	cbz	x19, 64b0 <fwp_owned_entry161+0x180>
    6494:	f9400820 	ldr	x0, [x1, #16]
    6498:	cb130000 	sub	x0, x0, x19
    649c:	eb0002df 	cmp	x22, x0
    64a0:	54000088 	b.hi	64b0 <fwp_owned_entry161+0x180>  // b.pmore
    64a4:	8b160260 	add	x0, x19, x22
    64a8:	f9000420 	str	x0, [x1, #8]
    64ac:	17ffffb9 	b	6390 <fwp_owned_entry161+0x60>
    64b0:	52800001 	mov	w1, #0x0                   	// #0
    64b4:	d2800300 	mov	x0, #0x18                  	// #24
    64b8:	97fff9ce 	bl	4bf0 <fwp_heap_alloc>
    64bc:	aa0003f3 	mov	x19, x0
    64c0:	17ffffca 	b	63e8 <fwp_owned_entry161+0xb8>
    64c4:	72003c3f 	tst	w1, #0xffff
    64c8:	54fffca0 	b.eq	645c <fwp_owned_entry161+0x12c>  // b.none
    64cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    64d0:	aa1303e0 	mov	x0, x19
    64d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    64d8:	a94363f7 	ldp	x23, x24, [sp, #48]
    64dc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    64e0:	d65f03c0 	ret
    64e4:	aa1403e0 	mov	x0, x20
    64e8:	97fff802 	bl	44f0 <fwp_rc_forget_slot>
    64ec:	17ffffdf 	b	6468 <fwp_owned_entry161+0x138>
    64f0:	97fff144 	bl	2a00 <fwp_trap_overflow.constprop.0>
    64f4:	97fff2af 	bl	2fb0 <fwp_heap_oom>
    64f8:	d503201f 	nop
    64fc:	d503201f 	nop

0000000000006500 <e161>:
    6500:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    6504:	910003fd 	mov	x29, sp
    6508:	a90363f7 	stp	x23, x24, [sp, #48]
    650c:	a9406002 	ldp	x2, x24, [x0]
    6510:	a90153f3 	stp	x19, x20, [sp, #16]
    6514:	f9400801 	ldr	x1, [x0, #16]
    6518:	a9025bf5 	stp	x21, x22, [sp, #32]
    651c:	ab010055 	adds	x21, x2, x1
    6520:	54000d86 	b.vs	66d0 <e161+0x1d0>
    6524:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc90>
    6528:	91154281 	add	x1, x20, #0x550
    652c:	b953a420 	ldr	w0, [x1, #5028]
    6530:	34000ac0 	cbz	w0, 6688 <e161+0x188>
    6534:	397e8820 	ldrb	w0, [x1, #4002]
    6538:	910f0002 	add	x2, x0, #0x3c0
    653c:	8b000400 	add	x0, x0, x0, lsl #1
    6540:	d37df000 	lsl	x0, x0, #3
    6544:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6548:	2a1703f6 	mov	w22, w23
    654c:	f8606833 	ldr	x19, [x1, x0]
    6550:	b4000893 	cbz	x19, 6660 <e161+0x160>
    6554:	f9400262 	ldr	x2, [x19]
    6558:	aa2203e2 	mvn	x2, x2
    655c:	f8206822 	str	x2, [x1, x0]
    6560:	f10062df 	cmp	x22, #0x18
    6564:	540000e9 	b.ls	6580 <e161+0x80>  // b.plast
    6568:	d10066c2 	sub	x2, x22, #0x19
    656c:	91006260 	add	x0, x19, #0x18
    6570:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6574:	52800001 	mov	w1, #0x0                   	// #0
    6578:	91002042 	add	x2, x2, #0x8
    657c:	97fff091 	bl	27c0 <memset@plt>
    6580:	91154281 	add	x1, x20, #0x550
    6584:	f94a1020 	ldr	x0, [x1, #5152]
    6588:	ab160000 	adds	x0, x0, x22
    658c:	54000a42 	b.cs	66d4 <e161+0x1d4>  // b.hs, b.nlast
    6590:	f94a1422 	ldr	x2, [x1, #5160]
    6594:	f90a1020 	str	x0, [x1, #5152]
    6598:	eb02001f 	cmp	x0, x2
    659c:	54000049 	b.ls	65a4 <e161+0xa4>  // b.plast
    65a0:	f90a1420 	str	x0, [x1, #5160]
    65a4:	91154280 	add	x0, x20, #0x550
    65a8:	1e6302e1 	ucvtf	d1, w23
    65ac:	fd4a1c00 	ldr	d0, [x0, #5176]
    65b0:	1e612800 	fadd	d0, d0, d1
    65b4:	fd0a1c00 	str	d0, [x0, #5176]
    65b8:	d0000020 	adrp	x0, c000 <msg.4+0x20>
    65bc:	91154294 	add	x20, x20, #0x550
    65c0:	a900d678 	stp	x24, x21, [x19, #8]
    65c4:	fd402000 	ldr	d0, [x0, #64]
    65c8:	fd000260 	str	d0, [x19]
    65cc:	f949da81 	ldr	x1, [x20, #5040]
    65d0:	f949ee80 	ldr	x0, [x20, #5080]
    65d4:	cb010261 	sub	x1, x19, x1
    65d8:	eb00403f 	cmp	x1, x0, lsl #16
    65dc:	54000322 	b.cs	6640 <e161+0x140>  // b.hs, b.nlast
    65e0:	d350fc20 	lsr	x0, x1, #16
    65e4:	f949fe83 	ldr	x3, [x20, #5112]
    65e8:	8b000800 	add	x0, x0, x0, lsl #2
    65ec:	d37df002 	lsl	x2, x0, #3
    65f0:	8b020060 	add	x0, x3, x2
    65f4:	f9401014 	ldr	x20, [x0, #32]
    65f8:	b4000254 	cbz	x20, 6640 <e161+0x140>
    65fc:	38626862 	ldrb	w2, [x3, x2]
    6600:	7100085f 	cmp	w2, #0x2
    6604:	540004c0 	b.eq	669c <e161+0x19c>  // b.none
    6608:	7100045f 	cmp	w2, #0x1
    660c:	540001a1 	b.ne	6640 <e161+0x140>  // b.any
    6610:	29430002 	ldp	w2, w0, [x0, #24]
    6614:	92403c21 	and	x1, x1, #0xffff
    6618:	9b027c21 	mul	x1, x1, x2
    661c:	d360fc21 	lsr	x1, x1, #32
    6620:	eb00003f 	cmp	x1, x0
    6624:	540000e2 	b.cs	6640 <e161+0x140>  // b.hs, b.nlast
    6628:	8b010294 	add	x20, x20, x1
    662c:	39400280 	ldrb	w0, [x20]
    6630:	7103fc1f 	cmp	w0, #0xff
    6634:	54000480 	b.eq	66c4 <e161+0x1c4>  // b.none
    6638:	52800020 	mov	w0, #0x1                   	// #1
    663c:	39000280 	strb	w0, [x20]
    6640:	aa1303e0 	mov	x0, x19
    6644:	97fffbe8 	bl	55e4 <fwp_rc_share>
    6648:	a9425bf5 	ldp	x21, x22, [sp, #32]
    664c:	aa1303e0 	mov	x0, x19
    6650:	a94153f3 	ldp	x19, x20, [sp, #16]
    6654:	a94363f7 	ldp	x23, x24, [sp, #48]
    6658:	a8c47bfd 	ldp	x29, x30, [sp], #64
    665c:	d65f03c0 	ret
    6660:	8b000021 	add	x1, x1, x0
    6664:	f9400433 	ldr	x19, [x1, #8]
    6668:	b4000113 	cbz	x19, 6688 <e161+0x188>
    666c:	f9400820 	ldr	x0, [x1, #16]
    6670:	cb130000 	sub	x0, x0, x19
    6674:	eb0002df 	cmp	x22, x0
    6678:	54000088 	b.hi	6688 <e161+0x188>  // b.pmore
    667c:	8b160260 	add	x0, x19, x22
    6680:	f9000420 	str	x0, [x1, #8]
    6684:	17ffffb7 	b	6560 <e161+0x60>
    6688:	52800001 	mov	w1, #0x0                   	// #0
    668c:	d2800300 	mov	x0, #0x18                  	// #24
    6690:	97fff958 	bl	4bf0 <fwp_heap_alloc>
    6694:	aa0003f3 	mov	x19, x0
    6698:	17ffffc8 	b	65b8 <e161+0xb8>
    669c:	72003c3f 	tst	w1, #0xffff
    66a0:	54fffc60 	b.eq	662c <e161+0x12c>  // b.none
    66a4:	aa1303e0 	mov	x0, x19
    66a8:	97fffbcf 	bl	55e4 <fwp_rc_share>
    66ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    66b0:	aa1303e0 	mov	x0, x19
    66b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    66b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    66bc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    66c0:	d65f03c0 	ret
    66c4:	aa1403e0 	mov	x0, x20
    66c8:	97fff78a 	bl	44f0 <fwp_rc_forget_slot>
    66cc:	17ffffdb 	b	6638 <e161+0x138>
    66d0:	97fff0cc 	bl	2a00 <fwp_trap_overflow.constprop.0>
    66d4:	97fff237 	bl	2fb0 <fwp_heap_oom>
    66d8:	d503201f 	nop
    66dc:	d503201f 	nop

00000000000066e0 <fwp_drop4>:
    66e0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    66e4:	910003fd 	mov	x29, sp
    66e8:	a90153f3 	stp	x19, x20, [sp, #16]
    66ec:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc90>
    66f0:	f90013f5 	str	x21, [sp, #32]
    66f4:	91154275 	add	x21, x19, #0x550
    66f8:	f949daa1 	ldr	x1, [x21, #5040]
    66fc:	f949eea2 	ldr	x2, [x21, #5080]
    6700:	cb010001 	sub	x1, x0, x1
    6704:	eb02403f 	cmp	x1, x2, lsl #16
    6708:	54000382 	b.cs	6778 <fwp_drop4+0x98>  // b.hs, b.nlast
    670c:	d350fc22 	lsr	x2, x1, #16
    6710:	f949fea3 	ldr	x3, [x21, #5112]
    6714:	8b020842 	add	x2, x2, x2, lsl #2
    6718:	d37df042 	lsl	x2, x2, #3
    671c:	8b020064 	add	x4, x3, x2
    6720:	f9401094 	ldr	x20, [x4, #32]
    6724:	b40002b4 	cbz	x20, 6778 <fwp_drop4+0x98>
    6728:	38626862 	ldrb	w2, [x3, x2]
    672c:	7100085f 	cmp	w2, #0x2
    6730:	540007a0 	b.eq	6824 <fwp_drop4+0x144>  // b.none
    6734:	7100045f 	cmp	w2, #0x1
    6738:	54000201 	b.ne	6778 <fwp_drop4+0x98>  // b.any
    673c:	29430885 	ldp	w5, w2, [x4, #24]
    6740:	92403c21 	and	x1, x1, #0xffff
    6744:	9b057c21 	mul	x1, x1, x5
    6748:	d360fc21 	lsr	x1, x1, #32
    674c:	eb02003f 	cmp	x1, x2
    6750:	54000142 	b.cs	6778 <fwp_drop4+0x98>  // b.hs, b.nlast
    6754:	8b010294 	add	x20, x20, x1
    6758:	39400281 	ldrb	w1, [x20]
    675c:	340000e1 	cbz	w1, 6778 <fwp_drop4+0x98>
    6760:	7100043f 	cmp	w1, #0x1
    6764:	54000120 	b.eq	6788 <fwp_drop4+0xa8>  // b.none
    6768:	7103fc3f 	cmp	w1, #0xff
    676c:	540007c0 	b.eq	6864 <fwp_drop4+0x184>  // b.none
    6770:	51000421 	sub	w1, w1, #0x1
    6774:	39000281 	strb	w1, [x20]
    6778:	a94153f3 	ldp	x19, x20, [sp, #16]
    677c:	f94013f5 	ldr	x21, [sp, #32]
    6780:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6784:	d65f03c0 	ret
    6788:	f9400001 	ldr	x1, [x0]
    678c:	b7f80581 	tbnz	x1, #63, 683c <fwp_drop4+0x15c>
    6790:	91154273 	add	x19, x19, #0x550
    6794:	f949da61 	ldr	x1, [x19, #5040]
    6798:	f949ee62 	ldr	x2, [x19, #5080]
    679c:	cb010001 	sub	x1, x0, x1
    67a0:	eb02403f 	cmp	x1, x2, lsl #16
    67a4:	54fffea2 	b.cs	6778 <fwp_drop4+0x98>  // b.hs, b.nlast
    67a8:	d350fc22 	lsr	x2, x1, #16
    67ac:	8b020842 	add	x2, x2, x2, lsl #2
    67b0:	d37df042 	lsl	x2, x2, #3
    67b4:	8b020065 	add	x5, x3, x2
    67b8:	f94010a4 	ldr	x4, [x5, #32]
    67bc:	b4fffde4 	cbz	x4, 6778 <fwp_drop4+0x98>
    67c0:	38626862 	ldrb	w2, [x3, x2]
    67c4:	7100085f 	cmp	w2, #0x2
    67c8:	54000220 	b.eq	680c <fwp_drop4+0x12c>  // b.none
    67cc:	7100045f 	cmp	w2, #0x1
    67d0:	54fffd41 	b.ne	6778 <fwp_drop4+0x98>  // b.any
    67d4:	294308a3 	ldp	w3, w2, [x5, #24]
    67d8:	92403c21 	and	x1, x1, #0xffff
    67dc:	9b037c21 	mul	x1, x1, x3
    67e0:	d360fc21 	lsr	x1, x1, #32
    67e4:	eb02003f 	cmp	x1, x2
    67e8:	54fffc82 	b.cs	6778 <fwp_drop4+0x98>  // b.hs, b.nlast
    67ec:	8b010084 	add	x4, x4, x1
    67f0:	39400081 	ldrb	w1, [x4]
    67f4:	7100043f 	cmp	w1, #0x1
    67f8:	54fffc01 	b.ne	6778 <fwp_drop4+0x98>  // b.any
    67fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6800:	f94013f5 	ldr	x21, [sp, #32]
    6804:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6808:	17fff7da 	b	4770 <fwp_mem_free>
    680c:	72003c3f 	tst	w1, #0xffff
    6810:	54ffff00 	b.eq	67f0 <fwp_drop4+0x110>  // b.none
    6814:	a94153f3 	ldp	x19, x20, [sp, #16]
    6818:	f94013f5 	ldr	x21, [sp, #32]
    681c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6820:	d65f03c0 	ret
    6824:	72003c3f 	tst	w1, #0xffff
    6828:	54fff980 	b.eq	6758 <fwp_drop4+0x78>  // b.none
    682c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6830:	f94013f5 	ldr	x21, [sp, #32]
    6834:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6838:	d65f03c0 	ret
    683c:	f9400414 	ldr	x20, [x0, #8]
    6840:	97fffb90 	bl	5680 <fwp_rc_free_arr>
    6844:	91154260 	add	x0, x19, #0x550
    6848:	f949d801 	ldr	x1, [x0, #5040]
    684c:	f949ec00 	ldr	x0, [x0, #5080]
    6850:	cb010281 	sub	x1, x20, x1
    6854:	eb00403f 	cmp	x1, x0, lsl #16
    6858:	54fff902 	b.cs	6778 <fwp_drop4+0x98>  // b.hs, b.nlast
    685c:	aa1403e0 	mov	x0, x20
    6860:	17ffffab 	b	670c <fwp_drop4+0x2c>
    6864:	ca544680 	eor	x0, x20, x20, lsr #17
    6868:	91154273 	add	x19, x19, #0x550
    686c:	ca402400 	eor	x0, x0, x0, lsr #9
    6870:	8b200e60 	add	x0, x19, w0, uxtb #3
    6874:	f94a2400 	ldr	x0, [x0, #5192]
    6878:	b5000080 	cbnz	x0, 6888 <fwp_drop4+0x1a8>
    687c:	14000010 	b	68bc <fwp_drop4+0x1dc>
    6880:	f9400800 	ldr	x0, [x0, #16]
    6884:	b40001c0 	cbz	x0, 68bc <fwp_drop4+0x1dc>
    6888:	f9400001 	ldr	x1, [x0]
    688c:	eb14003f 	cmp	x1, x20
    6890:	54ffff81 	b.ne	6880 <fwp_drop4+0x1a0>  // b.any
    6894:	f9400401 	ldr	x1, [x0, #8]
    6898:	d1000421 	sub	x1, x1, #0x1
    689c:	f9000401 	str	x1, [x0, #8]
    68a0:	f103f83f 	cmp	x1, #0xfe
    68a4:	54fff6a1 	b.ne	6778 <fwp_drop4+0x98>  // b.any
    68a8:	aa1403e0 	mov	x0, x20
    68ac:	97fff711 	bl	44f0 <fwp_rc_forget_slot>
    68b0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    68b4:	39000280 	strb	w0, [x20]
    68b8:	17ffffb0 	b	6778 <fwp_drop4+0x98>
    68bc:	b0000020 	adrp	x0, b000 <__modti3+0x30>
    68c0:	91186000 	add	x0, x0, #0x618
    68c4:	97fff30f 	bl	3500 <fwp_trap>
    68c8:	d503201f 	nop
    68cc:	d503201f 	nop

00000000000068d0 <fwp_caps161>:
    68d0:	34000041 	cbz	w1, 68d8 <fwp_caps161+0x8>
    68d4:	d65f03c0 	ret
    68d8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc90>
    68dc:	91154063 	add	x3, x3, #0x550
    68e0:	f949d861 	ldr	x1, [x3, #5040]
    68e4:	f949ec62 	ldr	x2, [x3, #5080]
    68e8:	cb010001 	sub	x1, x0, x1
    68ec:	eb02403f 	cmp	x1, x2, lsl #16
    68f0:	54ffff22 	b.cs	68d4 <fwp_caps161+0x4>  // b.hs, b.nlast
    68f4:	d350fc22 	lsr	x2, x1, #16
    68f8:	f949fc65 	ldr	x5, [x3, #5112]
    68fc:	8b020842 	add	x2, x2, x2, lsl #2
    6900:	d37df042 	lsl	x2, x2, #3
    6904:	8b0200a4 	add	x4, x5, x2
    6908:	f9401083 	ldr	x3, [x4, #32]
    690c:	b4fffe43 	cbz	x3, 68d4 <fwp_caps161+0x4>
    6910:	386268a2 	ldrb	w2, [x5, x2]
    6914:	7100085f 	cmp	w2, #0x2
    6918:	540001c0 	b.eq	6950 <fwp_caps161+0x80>  // b.none
    691c:	7100045f 	cmp	w2, #0x1
    6920:	54fffda1 	b.ne	68d4 <fwp_caps161+0x4>  // b.any
    6924:	29430885 	ldp	w5, w2, [x4, #24]
    6928:	92403c21 	and	x1, x1, #0xffff
    692c:	9b057c21 	mul	x1, x1, x5
    6930:	d360fc21 	lsr	x1, x1, #32
    6934:	eb02003f 	cmp	x1, x2
    6938:	54fffce2 	b.cs	68d4 <fwp_caps161+0x4>  // b.hs, b.nlast
    693c:	8b010063 	add	x3, x3, x1
    6940:	39400061 	ldrb	w1, [x3]
    6944:	7100043f 	cmp	w1, #0x1
    6948:	54fffc61 	b.ne	68d4 <fwp_caps161+0x4>  // b.any
    694c:	17fff789 	b	4770 <fwp_mem_free>
    6950:	72003c3f 	tst	w1, #0xffff
    6954:	54ffff60 	b.eq	6940 <fwp_caps161+0x70>  // b.none
    6958:	d65f03c0 	ret
    695c:	d503201f 	nop

0000000000006960 <f12>:
    6960:	d10443ff 	sub	sp, sp, #0x110
    6964:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    6968:	f947f442 	ldr	x2, [x2, #4072]
    696c:	a90a7bfd 	stp	x29, x30, [sp, #160]
    6970:	910283fd 	add	x29, sp, #0xa0
    6974:	a90b53f3 	stp	x19, x20, [sp, #176]
    6978:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc90>
    697c:	91154283 	add	x3, x20, #0x550
    6980:	a90d63f7 	stp	x23, x24, [sp, #208]
    6984:	d00000d7 	adrp	x23, 20000 <__data_start>
    6988:	910102e4 	add	x4, x23, #0x40
    698c:	f949d861 	ldr	x1, [x3, #5040]
    6990:	a90c5bf5 	stp	x21, x22, [sp, #192]
    6994:	d00000d5 	adrp	x21, 20000 <__data_start>
    6998:	f949ec65 	ldr	x5, [x3, #5080]
    699c:	a90e6bf9 	stp	x25, x26, [sp, #224]
    69a0:	910042b5 	add	x21, x21, #0x10
    69a4:	a90f73fb 	stp	x27, x28, [sp, #240]
    69a8:	9100c3f9 	add	x25, sp, #0x30
    69ac:	9100a3f8 	add	x24, sp, #0x28
    69b0:	f9416086 	ldr	x6, [x4, #704]
    69b4:	fd0083e8 	str	d8, [sp, #256]
    69b8:	f9400047 	ldr	x7, [x2]
    69bc:	f9004fe7 	str	x7, [sp, #152]
    69c0:	d2800007 	mov	x7, #0x0                   	// #0
    69c4:	f0fffff3 	adrp	x19, 5000 <fwp_p_ad_push+0xdc>
    69c8:	12800007 	mov	w7, #0xffffffff            	// #-1
    69cc:	91378262 	add	x2, x19, #0xde0
    69d0:	cb0102a1 	sub	x1, x21, x1
    69d4:	b9002be7 	str	w7, [sp, #40]
    69d8:	a9030be6 	stp	x6, x2, [sp, #48]
    69dc:	aa0003f6 	mov	x22, x0
    69e0:	f90023f8 	str	x24, [sp, #64]
    69e4:	f9016099 	str	x25, [x4, #704]
    69e8:	eb05403f 	cmp	x1, x5, lsl #16
    69ec:	54000342 	b.cs	6a54 <f12+0xf4>  // b.hs, b.nlast
    69f0:	d350fc20 	lsr	x0, x1, #16
    69f4:	f949fc64 	ldr	x4, [x3, #5112]
    69f8:	8b000800 	add	x0, x0, x0, lsl #2
    69fc:	d37df002 	lsl	x2, x0, #3
    6a00:	8b020083 	add	x3, x4, x2
    6a04:	f9401060 	ldr	x0, [x3, #32]
    6a08:	b4000260 	cbz	x0, 6a54 <f12+0xf4>
    6a0c:	38626882 	ldrb	w2, [x4, x2]
    6a10:	7100085f 	cmp	w2, #0x2
    6a14:	540077c0 	b.eq	790c <f12+0xfac>  // b.none
    6a18:	7100045f 	cmp	w2, #0x1
    6a1c:	540001c1 	b.ne	6a54 <f12+0xf4>  // b.any
    6a20:	29430864 	ldp	w4, w2, [x3, #24]
    6a24:	92403c21 	and	x1, x1, #0xffff
    6a28:	9b047c21 	mul	x1, x1, x4
    6a2c:	d360fc21 	lsr	x1, x1, #32
    6a30:	eb02003f 	cmp	x1, x2
    6a34:	54000102 	b.cs	6a54 <f12+0xf4>  // b.hs, b.nlast
    6a38:	8b010000 	add	x0, x0, x1
    6a3c:	39400001 	ldrb	w1, [x0]
    6a40:	340000a1 	cbz	w1, 6a54 <f12+0xf4>
    6a44:	7103f43f 	cmp	w1, #0xfd
    6a48:	54007e88 	b.hi	7a18 <f12+0x10b8>  // b.pmore
    6a4c:	11000421 	add	w1, w1, #0x1
    6a50:	39000001 	strb	w1, [x0]
    6a54:	aa1503e0 	mov	x0, x21
    6a58:	97fffc02 	bl	5a60 <fwp_closure_drop>
    6a5c:	b4007636 	cbz	x22, 7920 <f12+0xfc0>
    6a60:	aa1603e0 	mov	x0, x22
    6a64:	d2800001 	mov	x1, #0x0                   	// #0
    6a68:	f9400800 	ldr	x0, [x0, #16]
    6a6c:	91000421 	add	x1, x1, #0x1
    6a70:	b5ffffc0 	cbnz	x0, 6a68 <f12+0x108>
    6a74:	aa0103fa 	mov	x26, x1
    6a78:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    6a7c:	eb00003f 	cmp	x1, x0
    6a80:	540081a8 	b.hi	7ab4 <f12+0x1154>  // b.pmore
    6a84:	910102f5 	add	x21, x23, #0x40
    6a88:	b942f6a0 	ldr	w0, [x21, #756]
    6a8c:	340072c0 	cbz	w0, 78e4 <f12+0xf84>
    6a90:	910102e0 	add	x0, x23, #0x40
    6a94:	f940201b 	ldr	x27, [x0, #64]
    6a98:	f9404c15 	ldr	x21, [x0, #152]
    6a9c:	eb1b02bf 	cmp	x21, x27
    6aa0:	5400354a 	b.ge	7148 <f12+0x7e8>  // b.tcont
    6aa4:	f94022e1 	ldr	x1, [x23, #64]
    6aa8:	8b1506a0 	add	x0, x21, x21, lsl #1
    6aac:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6ab0:	8b000aa0 	add	x0, x21, x0, lsl #2
    6ab4:	8b000c20 	add	x0, x1, x0, lsl #3
    6ab8:	b9400401 	ldr	w1, [x0, #4]
    6abc:	35000081 	cbnz	w1, 6acc <f12+0x16c>
    6ac0:	b9400001 	ldr	w1, [x0]
    6ac4:	6b02003f 	cmp	w1, w2
    6ac8:	54003409 	b.ls	7148 <f12+0x7e8>  // b.plast
    6acc:	910006b5 	add	x21, x21, #0x1
    6ad0:	9101a000 	add	x0, x0, #0x68
    6ad4:	eb1b02bf 	cmp	x21, x27
    6ad8:	54ffff01 	b.ne	6ab8 <f12+0x158>  // b.any
    6adc:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6ae0:	eb00037f 	cmp	x27, x0
    6ae4:	54007eec 	b.gt	7ac0 <f12+0x1160>
    6ae8:	910102e0 	add	x0, x23, #0x40
    6aec:	f94022fc 	ldr	x28, [x23, #64]
    6af0:	f9404800 	ldr	x0, [x0, #144]
    6af4:	eb1b001f 	cmp	x0, x27
    6af8:	54000241 	b.ne	6b40 <f12+0x1e0>  // b.any
    6afc:	b400777b 	cbz	x27, 79e8 <f12+0x1088>
    6b00:	d37ffb62 	lsl	x2, x27, #1
    6b04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    6b08:	eb00005f 	cmp	x2, x0
    6b0c:	9a80d042 	csel	x2, x2, x0, le
    6b10:	8b020441 	add	x1, x2, x2, lsl #1
    6b14:	8b010841 	add	x1, x2, x1, lsl #2
    6b18:	d37df021 	lsl	x1, x1, #3
    6b1c:	aa1c03e0 	mov	x0, x28
    6b20:	f90003e2 	str	x2, [sp]
    6b24:	97ffef2f 	bl	27e0 <realloc@plt>
    6b28:	aa0003fc 	mov	x28, x0
    6b2c:	f94003e2 	ldr	x2, [sp]
    6b30:	b4006bc0 	cbz	x0, 78a8 <f12+0xf48>
    6b34:	910102e0 	add	x0, x23, #0x40
    6b38:	f90022fc 	str	x28, [x23, #64]
    6b3c:	f9004802 	str	x2, [x0, #144]
    6b40:	910102e1 	add	x1, x23, #0x40
    6b44:	8b1b0760 	add	x0, x27, x27, lsl #1
    6b48:	4f000400 	movi	v0.4s, #0x0
    6b4c:	91000762 	add	x2, x27, #0x1
    6b50:	8b000b60 	add	x0, x27, x0, lsl #2
    6b54:	f9002022 	str	x2, [x1, #64]
    6b58:	8b1506a1 	add	x1, x21, x21, lsl #1
    6b5c:	8b000f80 	add	x0, x28, x0, lsl #3
    6b60:	8b010abb 	add	x27, x21, x1, lsl #2
    6b64:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    6b68:	ad000000 	stp	q0, q0, [x0]
    6b6c:	ad010000 	stp	q0, q0, [x0, #32]
    6b70:	ad020000 	stp	q0, q0, [x0, #64]
    6b74:	f900301f 	str	xzr, [x0, #96]
    6b78:	b0000020 	adrp	x0, b000 <__modti3+0x30>
    6b7c:	f900337f 	str	xzr, [x27, #96]
    6b80:	9116a000 	add	x0, x0, #0x5a8
    6b84:	97ffef7f 	bl	2980 <getenv@plt>
    6b88:	b5002f60 	cbnz	x0, 7174 <f12+0x814>
    6b8c:	d503201f 	nop
    6b90:	910102e0 	add	x0, x23, #0x40
    6b94:	f9404001 	ldr	x1, [x0, #128]
    6b98:	b5006d21 	cbnz	x1, 793c <f12+0xfdc>
    6b9c:	910102e1 	add	x1, x23, #0x40
    6ba0:	2f000400 	mvni	v0.2s, #0x0
    6ba4:	b9400362 	ldr	w2, [x27]
    6ba8:	52800024 	mov	w4, #0x1                   	// #1
    6bac:	910006a3 	add	x3, x21, #0x1
    6bb0:	a900eb7a 	stp	x26, x26, [x27, #8]
    6bb4:	0b040042 	add	w2, w2, w4
    6bb8:	f9416020 	ldr	x0, [x1, #704]
    6bbc:	29001362 	stp	w2, w4, [x27]
    6bc0:	f9002b7f 	str	xzr, [x27, #80]
    6bc4:	f9004c23 	str	x3, [x1, #152]
    6bc8:	fd002f60 	str	d0, [x27, #88]
    6bcc:	b40076e0 	cbz	x0, 7aa8 <f12+0x1148>
    6bd0:	91378273 	add	x19, x19, #0xde0
    6bd4:	14000003 	b	6be0 <f12+0x280>
    6bd8:	f9400000 	ldr	x0, [x0]
    6bdc:	b4007660 	cbz	x0, 7aa8 <f12+0x1148>
    6be0:	f9400401 	ldr	x1, [x0, #8]
    6be4:	eb13003f 	cmp	x1, x19
    6be8:	54ffff81 	b.ne	6bd8 <f12+0x278>  // b.any
    6bec:	f9400800 	ldr	x0, [x0, #16]
    6bf0:	2a1503e4 	mov	w4, w21
    6bf4:	b9400001 	ldr	w1, [x0]
    6bf8:	f9002b60 	str	x0, [x27, #80]
    6bfc:	b9005f61 	str	w1, [x27, #92]
    6c00:	37f80081 	tbnz	w1, #31, 6c10 <f12+0x2b0>
    6c04:	52800d05 	mov	w5, #0x68                  	// #104
    6c08:	9b257021 	smaddl	x1, w1, w5, x28
    6c0c:	b9005835 	str	w21, [x1, #88]
    6c10:	b9000004 	str	w4, [x0]
    6c14:	d3707c42 	ubfiz	x2, x2, #16, #32
    6c18:	aa03005a 	orr	x26, x2, x3
    6c1c:	aa1603e0 	mov	x0, x22
    6c20:	d2800002 	mov	x2, #0x0                   	// #0
    6c24:	b4006136 	cbz	x22, 7848 <f12+0xee8>
    6c28:	f9400800 	ldr	x0, [x0, #16]
    6c2c:	91000442 	add	x2, x2, #0x1
    6c30:	b5ffffc0 	cbnz	x0, 6c28 <f12+0x2c8>
    6c34:	aa1603e1 	mov	x1, x22
    6c38:	f9400821 	ldr	x1, [x1, #16]
    6c3c:	91000400 	add	x0, x0, #0x1
    6c40:	b5ffffc1 	cbnz	x1, 6c38 <f12+0x2d8>
    6c44:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6c48:	eb01001f 	cmp	x0, x1
    6c4c:	54007468 	b.hi	7ad8 <f12+0x1178>  // b.pmore
    6c50:	f100005f 	cmp	x2, #0x0
    6c54:	54005fad 	b.le	7848 <f12+0xee8>
    6c58:	eb00005f 	cmp	x2, x0
    6c5c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6c60:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    6c64:	eb01027f 	cmp	x19, x1
    6c68:	54007388 	b.hi	7ad8 <f12+0x1178>  // b.pmore
    6c6c:	d37ffa75 	lsl	x21, x19, #1
    6c70:	52800041 	mov	w1, #0x2                   	// #2
    6c74:	910006a0 	add	x0, x21, #0x1
    6c78:	d37df000 	lsl	x0, x0, #3
    6c7c:	97fff7dd 	bl	4bf0 <fwp_heap_alloc>
    6c80:	aa0003fb 	mov	x27, x0
    6c84:	91154281 	add	x1, x20, #0x550
    6c88:	aa0103e0 	mov	x0, x1
    6c8c:	f9000375 	str	x21, [x27]
    6c90:	f949d821 	ldr	x1, [x1, #5040]
    6c94:	f949ec00 	ldr	x0, [x0, #5080]
    6c98:	cb010361 	sub	x1, x27, x1
    6c9c:	eb00403f 	cmp	x1, x0, lsl #16
    6ca0:	540061c2 	b.cs	78d8 <f12+0xf78>  // b.hs, b.nlast
    6ca4:	91154282 	add	x2, x20, #0x550
    6ca8:	d350fc20 	lsr	x0, x1, #16
    6cac:	8b000800 	add	x0, x0, x0, lsl #2
    6cb0:	f949fc43 	ldr	x3, [x2, #5112]
    6cb4:	d37df002 	lsl	x2, x0, #3
    6cb8:	8b020060 	add	x0, x3, x2
    6cbc:	f9401015 	ldr	x21, [x0, #32]
    6cc0:	b4000255 	cbz	x21, 6d08 <f12+0x3a8>
    6cc4:	38626862 	ldrb	w2, [x3, x2]
    6cc8:	7100085f 	cmp	w2, #0x2
    6ccc:	540061a0 	b.eq	7900 <f12+0xfa0>  // b.none
    6cd0:	7100045f 	cmp	w2, #0x1
    6cd4:	540001a1 	b.ne	6d08 <f12+0x3a8>  // b.any
    6cd8:	29430002 	ldp	w2, w0, [x0, #24]
    6cdc:	92403c21 	and	x1, x1, #0xffff
    6ce0:	9b027c21 	mul	x1, x1, x2
    6ce4:	d360fc21 	lsr	x1, x1, #32
    6ce8:	eb00003f 	cmp	x1, x0
    6cec:	540000e2 	b.cs	6d08 <f12+0x3a8>  // b.hs, b.nlast
    6cf0:	8b0102b5 	add	x21, x21, x1
    6cf4:	394002a0 	ldrb	w0, [x21]
    6cf8:	7103fc1f 	cmp	w0, #0xff
    6cfc:	540067c0 	b.eq	79f4 <f12+0x1094>  // b.none
    6d00:	52800020 	mov	w0, #0x1                   	// #1
    6d04:	390002a0 	strb	w0, [x21]
    6d08:	b4000233 	cbz	x19, 6d4c <f12+0x3ec>
    6d0c:	d3607f44 	lsl	x4, x26, #32
    6d10:	aa1603e2 	mov	x2, x22
    6d14:	f94006c5 	ldr	x5, [x22, #8]
    6d18:	aa0403e3 	mov	x3, x4
    6d1c:	91002360 	add	x0, x27, #0x8
    6d20:	d2800001 	mov	x1, #0x0                   	// #0
    6d24:	14000005 	b	6d38 <f12+0x3d8>
    6d28:	f9400445 	ldr	x5, [x2, #8]
    6d2c:	ab040023 	adds	x3, x1, x4
    6d30:	91004000 	add	x0, x0, #0x10
    6d34:	54006da6 	b.vs	7ae8 <f12+0x1188>
    6d38:	a9000c05 	stp	x5, x3, [x0]
    6d3c:	91000421 	add	x1, x1, #0x1
    6d40:	f9400842 	ldr	x2, [x2, #16]
    6d44:	eb01027f 	cmp	x19, x1
    6d48:	54ffff08 	b.hi	6d28 <f12+0x3c8>  // b.pmore
    6d4c:	f9400360 	ldr	x0, [x27]
    6d50:	f100041f 	cmp	x0, #0x1
    6d54:	54005c49 	b.ls	78dc <f12+0xf7c>  // b.plast
    6d58:	d341fc00 	lsr	x0, x0, #1
    6d5c:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    6d60:	d1000401 	sub	x1, x0, #0x1
    6d64:	eb02003f 	cmp	x1, x2
    6d68:	54006b88 	b.hi	7ad8 <f12+0x1178>  // b.pmore
    6d6c:	d37ff83c 	lsl	x28, x1, #1
    6d70:	b4005b61 	cbz	x1, 78dc <f12+0xf7c>
    6d74:	d1002361 	sub	x1, x27, #0x8
    6d78:	91002373 	add	x19, x27, #0x8
    6d7c:	8b001035 	add	x21, x1, x0, lsl #4
    6d80:	f9400660 	ldr	x0, [x19, #8]
    6d84:	f9400e61 	ldr	x1, [x19, #24]
    6d88:	fd400260 	ldr	d0, [x19]
    6d8c:	fd400a61 	ldr	d1, [x19, #16]
    6d90:	97fff948 	bl	52b0 <w107>
    6d94:	a9000660 	stp	x0, x1, [x19]
    6d98:	91004273 	add	x19, x19, #0x10
    6d9c:	eb15027f 	cmp	x19, x21
    6da0:	54ffff01 	b.ne	6d80 <f12+0x420>  // b.any
    6da4:	f900037c 	str	x28, [x27]
    6da8:	aa1b03e0 	mov	x0, x27
    6dac:	93407f53 	sxtw	x19, w26
    6db0:	97fff99d 	bl	5424 <w164.constprop.0>
    6db4:	aa0103f5 	mov	x21, x1
    6db8:	aa1b03e0 	mov	x0, x27
    6dbc:	97fffe49 	bl	66e0 <fwp_drop4>
    6dc0:	aa1303e0 	mov	x0, x19
    6dc4:	97fff29b 	bl	3830 <fwp_tape_of>
    6dc8:	f9403001 	ldr	x1, [x0, #96]
    6dcc:	aa0003e8 	mov	x8, x0
    6dd0:	b50067e1 	cbnz	x1, 7acc <f12+0x116c>
    6dd4:	97fff04f 	bl	2f10 <fwp_tape_unlink_scope>
    6dd8:	b900051f 	str	wzr, [x8, #4]
    6ddc:	b9400102 	ldr	w2, [x8]
    6de0:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    6de4:	a940851c 	ldp	x28, x1, [x8, #8]
    6de8:	a941910a 	ldp	x10, x4, [x8, #24]
    6dec:	a9429905 	ldp	x5, x6, [x8, #40]
    6df0:	a9438d07 	ldp	x7, x3, [x8, #56]
    6df4:	f940251b 	ldr	x27, [x8, #72]
    6df8:	6b00005f 	cmp	w2, w0
    6dfc:	54000108 	b.hi	6e1c <f12+0x4bc>  // b.pmore
    6e00:	910102e2 	add	x2, x23, #0x40
    6e04:	92403e60 	and	x0, x19, #0xffff
    6e08:	d1000400 	sub	x0, x0, #0x1
    6e0c:	f9404c49 	ldr	x9, [x2, #152]
    6e10:	eb09001f 	cmp	x0, x9
    6e14:	5400004a 	b.ge	6e1c <f12+0x4bc>  // b.tcont
    6e18:	f9004c40 	str	x0, [x2, #152]
    6e1c:	4f000400 	movi	v0.4s, #0x0
    6e20:	910102e9 	add	x9, x23, #0x40
    6e24:	f9000d1f 	str	xzr, [x8, #24]
    6e28:	910123e0 	add	x0, sp, #0x48
    6e2c:	910183fa 	add	x26, sp, #0x60
    6e30:	d0ffffe2 	adrp	x2, 4000 <fwp_wake_io+0x3c>
    6e34:	f941612b 	ldr	x11, [x9, #704]
    6e38:	3c808100 	stur	q0, [x8, #8]
    6e3c:	91020042 	add	x2, x2, #0x80
    6e40:	ad010100 	stp	q0, q0, [x8, #32]
    6e44:	a9047d1f 	stp	xzr, xzr, [x8, #64]
    6e48:	a9048beb 	stp	x11, x2, [sp, #72]
    6e4c:	a90593fa 	stp	x26, x4, [sp, #88]
    6e50:	a9069be5 	stp	x5, x6, [sp, #104]
    6e54:	a9078fe7 	stp	x7, x3, [sp, #120]
    6e58:	a908efea 	stp	x10, x27, [sp, #136]
    6e5c:	f9016120 	str	x0, [x9, #704]
    6e60:	b7f856b5 	tbnz	x21, #63, 7934 <f12+0xfd4>
    6e64:	eb95827f 	cmp	x19, x21, asr #32
    6e68:	540060a1 	b.ne	7a7c <f12+0x111c>  // b.any
    6e6c:	92407eb3 	and	x19, x21, #0xffffffff
    6e70:	eb35403f 	cmp	x1, w21, uxtw
    6e74:	54005fed 	b.le	7a70 <f12+0x1110>
    6e78:	eb13039f 	cmp	x28, x19
    6e7c:	9a93c793 	csinc	x19, x28, x19, gt
    6e80:	eb13037f 	cmp	x27, x19
    6e84:	5400502a 	b.ge	7888 <f12+0xf28>  // b.tcont
    6e88:	f100037f 	cmp	x27, #0x0
    6e8c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    6e90:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    6e94:	14000004 	b	6ea4 <f12+0x544>
    6e98:	eb01037f 	cmp	x27, x1
    6e9c:	d37ffb7b 	lsl	x27, x27, #1
    6ea0:	9a93d37b 	csel	x27, x27, x19, le
    6ea4:	eb13037f 	cmp	x27, x19
    6ea8:	54ffff8b 	b.lt	6e98 <f12+0x538>  // b.tstop
    6eac:	a90017e4 	stp	x4, x5, [sp]
    6eb0:	a9011fe6 	stp	x6, x7, [sp, #16]
    6eb4:	b4005763 	cbz	x3, 79a0 <f12+0x1040>
    6eb8:	aa0303e0 	mov	x0, x3
    6ebc:	d37df361 	lsl	x1, x27, #3
    6ec0:	97ffee48 	bl	27e0 <realloc@plt>
    6ec4:	aa0003e3 	mov	x3, x0
    6ec8:	a94017e4 	ldp	x4, x5, [sp]
    6ecc:	a9411fe6 	ldp	x6, x7, [sp, #16]
    6ed0:	b4004dc3 	cbz	x3, 7888 <f12+0xf28>
    6ed4:	f90043e3 	str	x3, [sp, #128]
    6ed8:	f9004bfb 	str	x27, [sp, #144]
    6edc:	b5001593 	cbnz	x19, 718c <f12+0x82c>
    6ee0:	b7f800d5 	tbnz	x21, #63, 6ef8 <f12+0x598>
    6ee4:	92407eb5 	and	x21, x21, #0xffffffff
    6ee8:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    6eec:	fc757860 	ldr	d0, [x3, x21, lsl #3]
    6ef0:	1e612800 	fadd	d0, d0, d1
    6ef4:	fc357860 	str	d0, [x3, x21, lsl #3]
    6ef8:	d1000673 	sub	x19, x19, #0x1
    6efc:	d1000788 	sub	x8, x28, #0x1
    6f00:	eb13039f 	cmp	x28, x19
    6f04:	540003ac 	b.gt	6f78 <f12+0x618>
    6f08:	fc737860 	ldr	d0, [x3, x19, lsl #3]
    6f0c:	1e602008 	fcmp	d0, #0.0
    6f10:	540002e0 	b.eq	6f6c <f12+0x60c>  // b.none
    6f14:	cb1c0be0 	neg	x0, x28, lsl #2
    6f18:	cb1c03e2 	neg	x2, x28
    6f1c:	8b000081 	add	x1, x4, x0
    6f20:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    6f24:	37f80101 	tbnz	w1, #31, 6f44 <f12+0x5e4>
    6f28:	8b020cc9 	add	x9, x6, x2, lsl #3
    6f2c:	93407c21 	sxtw	x1, w1
    6f30:	fc737922 	ldr	d2, [x9, x19, lsl #3]
    6f34:	fc617861 	ldr	d1, [x3, x1, lsl #3]
    6f38:	1e620802 	fmul	d2, d0, d2
    6f3c:	1e622821 	fadd	d1, d1, d2
    6f40:	fc217861 	str	d1, [x3, x1, lsl #3]
    6f44:	8b0000a0 	add	x0, x5, x0
    6f48:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    6f4c:	37f80100 	tbnz	w0, #31, 6f6c <f12+0x60c>
    6f50:	8b020ce2 	add	x2, x7, x2, lsl #3
    6f54:	93407c00 	sxtw	x0, w0
    6f58:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    6f5c:	fc607861 	ldr	d1, [x3, x0, lsl #3]
    6f60:	1e620800 	fmul	d0, d0, d2
    6f64:	1e602820 	fadd	d0, d1, d0
    6f68:	fc207860 	str	d0, [x3, x0, lsl #3]
    6f6c:	d1000673 	sub	x19, x19, #0x1
    6f70:	eb08027f 	cmp	x19, x8
    6f74:	54fffca1 	b.ne	6f08 <f12+0x5a8>  // b.any
    6f78:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    6f7c:	eb00039f 	cmp	x28, x0
    6f80:	540058c8 	b.hi	7a98 <f12+0x1138>  // b.pmore
    6f84:	91000780 	add	x0, x28, #0x1
    6f88:	52800041 	mov	w1, #0x2                   	// #2
    6f8c:	f90003e3 	str	x3, [sp]
    6f90:	d37df000 	lsl	x0, x0, #3
    6f94:	97fff717 	bl	4bf0 <fwp_heap_alloc>
    6f98:	aa0003e2 	mov	x2, x0
    6f9c:	aa0003f3 	mov	x19, x0
    6fa0:	f94003e3 	ldr	x3, [sp]
    6fa4:	d2800001 	mov	x1, #0x0                   	// #0
    6fa8:	f800845c 	str	x28, [x2], #8
    6fac:	b40000dc 	cbz	x28, 6fc4 <f12+0x664>
    6fb0:	f8617860 	ldr	x0, [x3, x1, lsl #3]
    6fb4:	f8217840 	str	x0, [x2, x1, lsl #3]
    6fb8:	91000421 	add	x1, x1, #0x1
    6fbc:	eb01039f 	cmp	x28, x1
    6fc0:	54ffff81 	b.ne	6fb0 <f12+0x650>  // b.any
    6fc4:	910102e1 	add	x1, x23, #0x40
    6fc8:	aa1a03e0 	mov	x0, x26
    6fcc:	f94027fa 	ldr	x26, [sp, #72]
    6fd0:	f901603a 	str	x26, [x1, #704]
    6fd4:	97fff42b 	bl	4080 <fwp_tape_buffers_release>
    6fd8:	91154282 	add	x2, x20, #0x550
    6fdc:	f949d841 	ldr	x1, [x2, #5040]
    6fe0:	f949ec40 	ldr	x0, [x2, #5080]
    6fe4:	cb010261 	sub	x1, x19, x1
    6fe8:	eb00403f 	cmp	x1, x0, lsl #16
    6fec:	54000322 	b.cs	7050 <f12+0x6f0>  // b.hs, b.nlast
    6ff0:	d350fc20 	lsr	x0, x1, #16
    6ff4:	f949fc43 	ldr	x3, [x2, #5112]
    6ff8:	8b000800 	add	x0, x0, x0, lsl #2
    6ffc:	d37df002 	lsl	x2, x0, #3
    7000:	8b020060 	add	x0, x3, x2
    7004:	f9401015 	ldr	x21, [x0, #32]
    7008:	b4000255 	cbz	x21, 7050 <f12+0x6f0>
    700c:	38626862 	ldrb	w2, [x3, x2]
    7010:	7100085f 	cmp	w2, #0x2
    7014:	540048a0 	b.eq	7928 <f12+0xfc8>  // b.none
    7018:	7100045f 	cmp	w2, #0x1
    701c:	540001a1 	b.ne	7050 <f12+0x6f0>  // b.any
    7020:	29430002 	ldp	w2, w0, [x0, #24]
    7024:	92403c21 	and	x1, x1, #0xffff
    7028:	9b027c21 	mul	x1, x1, x2
    702c:	d360fc21 	lsr	x1, x1, #32
    7030:	eb00003f 	cmp	x1, x0
    7034:	540000e2 	b.cs	7050 <f12+0x6f0>  // b.hs, b.nlast
    7038:	8b0102b5 	add	x21, x21, x1
    703c:	394002a0 	ldrb	w0, [x21]
    7040:	7103fc1f 	cmp	w0, #0xff
    7044:	54004de0 	b.eq	7a00 <f12+0x10a0>  // b.none
    7048:	52800020 	mov	w0, #0x1                   	// #1
    704c:	390002a0 	strb	w0, [x21]
    7050:	eb19035f 	cmp	x26, x25
    7054:	54005481 	b.ne	7ae4 <f12+0x1184>  // b.any
    7058:	f9401be1 	ldr	x1, [sp, #48]
    705c:	910102f7 	add	x23, x23, #0x40
    7060:	aa1803e0 	mov	x0, x24
    7064:	f90162e1 	str	x1, [x23, #704]
    7068:	97fffb5e 	bl	5de0 <fwp_tape_scope_release>
    706c:	f9400260 	ldr	x0, [x19]
    7070:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    7074:	b7f83960 	tbnz	x0, #63, 77a0 <f12+0xe40>
    7078:	91154282 	add	x2, x20, #0x550
    707c:	f949d840 	ldr	x0, [x2, #5040]
    7080:	f949ec41 	ldr	x1, [x2, #5080]
    7084:	cb000260 	sub	x0, x19, x0
    7088:	eb01401f 	cmp	x0, x1, lsl #16
    708c:	540038a2 	b.cs	77a0 <f12+0xe40>  // b.hs, b.nlast
    7090:	d350fc01 	lsr	x1, x0, #16
    7094:	f949fc44 	ldr	x4, [x2, #5112]
    7098:	8b010821 	add	x1, x1, x1, lsl #2
    709c:	d37df021 	lsl	x1, x1, #3
    70a0:	8b010083 	add	x3, x4, x1
    70a4:	f9401062 	ldr	x2, [x3, #32]
    70a8:	b40037c2 	cbz	x2, 77a0 <f12+0xe40>
    70ac:	38616881 	ldrb	w1, [x4, x1]
    70b0:	7100083f 	cmp	w1, #0x2
    70b4:	54003700 	b.eq	7794 <f12+0xe34>  // b.none
    70b8:	7100043f 	cmp	w1, #0x1
    70bc:	54003721 	b.ne	77a0 <f12+0xe40>  // b.any
    70c0:	29430464 	ldp	w4, w1, [x3, #24]
    70c4:	92403c00 	and	x0, x0, #0xffff
    70c8:	9b047c00 	mul	x0, x0, x4
    70cc:	d360fc00 	lsr	x0, x0, #32
    70d0:	eb01001f 	cmp	x0, x1
    70d4:	54003662 	b.cs	77a0 <f12+0xe40>  // b.hs, b.nlast
    70d8:	8b000042 	add	x2, x2, x0
    70dc:	39400040 	ldrb	w0, [x2]
    70e0:	7100041f 	cmp	w0, #0x1
    70e4:	540035e1 	b.ne	77a0 <f12+0xe40>  // b.any
    70e8:	aa1303f9 	mov	x25, x19
    70ec:	d2800000 	mov	x0, #0x0                   	// #0
    70f0:	f9000bf3 	str	x19, [sp, #16]
    70f4:	f9400be1 	ldr	x1, [sp, #16]
    70f8:	91002023 	add	x3, x1, #0x8
    70fc:	d2800001 	mov	x1, #0x0                   	// #0
    7100:	b40005b7 	cbz	x23, 71b4 <f12+0x854>
    7104:	b0000022 	adrp	x2, c000 <msg.4+0x20>
    7108:	91002265 	add	x5, x19, #0x8
    710c:	fd402441 	ldr	d1, [x2, #72]
    7110:	14000009 	b	7134 <f12+0x7d4>
    7114:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7118:	f9400322 	ldr	x2, [x25]
    711c:	1e600820 	fmul	d0, d1, d0
    7120:	b7f84b62 	tbnz	x2, #63, 7a8c <f12+0x112c>
    7124:	91000421 	add	x1, x1, #0x1
    7128:	fc008460 	str	d0, [x3], #8
    712c:	eb0102ff 	cmp	x23, x1
    7130:	54000420 	b.eq	71b4 <f12+0x854>  // b.none
    7134:	f9400264 	ldr	x4, [x19]
    7138:	aa0503e2 	mov	x2, x5
    713c:	b6fffec4 	tbz	x4, #63, 7114 <f12+0x7b4>
    7140:	f9400a62 	ldr	x2, [x19, #16]
    7144:	17fffff4 	b	7114 <f12+0x7b4>
    7148:	eb1b02bf 	cmp	x21, x27
    714c:	54ffcc80 	b.eq	6adc <f12+0x17c>  // b.none
    7150:	f94022fc 	ldr	x28, [x23, #64]
    7154:	8b1506a1 	add	x1, x21, x21, lsl #1
    7158:	90000020 	adrp	x0, b000 <__modti3+0x30>
    715c:	9116a000 	add	x0, x0, #0x5a8
    7160:	8b010abb 	add	x27, x21, x1, lsl #2
    7164:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7168:	f900337f 	str	xzr, [x27, #96]
    716c:	97ffee05 	bl	2980 <getenv@plt>
    7170:	b4ffd100 	cbz	x0, 6b90 <f12+0x230>
    7174:	39400001 	ldrb	w1, [x0]
    7178:	7100c03f 	cmp	w1, #0x30
    717c:	54ffd0a1 	b.ne	6b90 <f12+0x230>  // b.any
    7180:	39400400 	ldrb	w0, [x0, #1]
    7184:	34ffd0c0 	cbz	w0, 6b9c <f12+0x23c>
    7188:	17fffe82 	b	6b90 <f12+0x230>
    718c:	aa0303e0 	mov	x0, x3
    7190:	d37df262 	lsl	x2, x19, #3
    7194:	52800001 	mov	w1, #0x0                   	// #0
    7198:	a90017e4 	stp	x4, x5, [sp]
    719c:	a9011fe6 	stp	x6, x7, [sp, #16]
    71a0:	97ffed88 	bl	27c0 <memset@plt>
    71a4:	aa0003e3 	mov	x3, x0
    71a8:	a94017e4 	ldp	x4, x5, [sp]
    71ac:	a9411fe6 	ldp	x6, x7, [sp, #16]
    71b0:	17ffff4c 	b	6ee0 <f12+0x580>
    71b4:	97fffd4b 	bl	66e0 <fwp_drop4>
    71b8:	aa1603e1 	mov	x1, x22
    71bc:	d2800002 	mov	x2, #0x0                   	// #0
    71c0:	b4003ff6 	cbz	x22, 79bc <f12+0x105c>
    71c4:	d503201f 	nop
    71c8:	f9400821 	ldr	x1, [x1, #16]
    71cc:	91000442 	add	x2, x2, #0x1
    71d0:	b5ffffc1 	cbnz	x1, 71c8 <f12+0x868>
    71d4:	f9400323 	ldr	x3, [x25]
    71d8:	9240f873 	and	x19, x3, #0x7fffffffffffffff
    71dc:	b7f82a63 	tbnz	x3, #63, 7728 <f12+0xdc8>
    71e0:	91154281 	add	x1, x20, #0x550
    71e4:	f9400be4 	ldr	x4, [sp, #16]
    71e8:	f949d820 	ldr	x0, [x1, #5040]
    71ec:	f949ec21 	ldr	x1, [x1, #5080]
    71f0:	cb000080 	sub	x0, x4, x0
    71f4:	eb01401f 	cmp	x0, x1, lsl #16
    71f8:	54002982 	b.cs	7728 <f12+0xdc8>  // b.hs, b.nlast
    71fc:	91154284 	add	x4, x20, #0x550
    7200:	d350fc01 	lsr	x1, x0, #16
    7204:	8b010821 	add	x1, x1, x1, lsl #2
    7208:	f949fc86 	ldr	x6, [x4, #5112]
    720c:	d37df021 	lsl	x1, x1, #3
    7210:	8b0100c5 	add	x5, x6, x1
    7214:	f94010a4 	ldr	x4, [x5, #32]
    7218:	b4002864 	cbz	x4, 7724 <f12+0xdc4>
    721c:	386168c1 	ldrb	w1, [x6, x1]
    7220:	7100083f 	cmp	w1, #0x2
    7224:	540027c0 	b.eq	771c <f12+0xdbc>  // b.none
    7228:	7100043f 	cmp	w1, #0x1
    722c:	540027c1 	b.ne	7724 <f12+0xdc4>  // b.any
    7230:	294304a6 	ldp	w6, w1, [x5, #24]
    7234:	92403c00 	and	x0, x0, #0xffff
    7238:	9b067c00 	mul	x0, x0, x6
    723c:	d360fc00 	lsr	x0, x0, #32
    7240:	eb01001f 	cmp	x0, x1
    7244:	54002702 	b.cs	7724 <f12+0xdc4>  // b.hs, b.nlast
    7248:	8b000084 	add	x4, x4, x0
    724c:	39400097 	ldrb	w23, [x4]
    7250:	710006ff 	cmp	w23, #0x1
    7254:	54002681 	b.ne	7724 <f12+0xdc4>  // b.any
    7258:	b9001bf7 	str	w23, [sp, #24]
    725c:	eb13005f 	cmp	x2, x19
    7260:	9a939053 	csel	x19, x2, x19, ls	// ls = plast
    7264:	9100233a 	add	x26, x25, #0x8
    7268:	b4003e13 	cbz	x19, 7a28 <f12+0x10c8>
    726c:	f9400be0 	ldr	x0, [sp, #16]
    7270:	d37df265 	lsl	x5, x19, #3
    7274:	aa1603e2 	mov	x2, x22
    7278:	d2800001 	mov	x1, #0x0                   	// #0
    727c:	91002000 	add	x0, x0, #0x8
    7280:	1400000a 	b	72a8 <f12+0x948>
    7284:	fc616881 	ldr	d1, [x4, x1]
    7288:	fd400440 	ldr	d0, [x2, #8]
    728c:	1e613800 	fsub	d0, d0, d1
    7290:	fc216b40 	str	d0, [x26, x1]
    7294:	91002021 	add	x1, x1, #0x8
    7298:	f9400842 	ldr	x2, [x2, #16]
    729c:	eb05003f 	cmp	x1, x5
    72a0:	540001c0 	b.eq	72d8 <f12+0x978>  // b.none
    72a4:	f9400323 	ldr	x3, [x25]
    72a8:	aa0003e4 	mov	x4, x0
    72ac:	b6fffec3 	tbz	x3, #63, 7284 <f12+0x924>
    72b0:	f9400be3 	ldr	x3, [sp, #16]
    72b4:	fd400440 	ldr	d0, [x2, #8]
    72b8:	f9400864 	ldr	x4, [x3, #16]
    72bc:	fc616881 	ldr	d1, [x4, x1]
    72c0:	1e613800 	fsub	d0, d0, d1
    72c4:	fc216b40 	str	d0, [x26, x1]
    72c8:	91002021 	add	x1, x1, #0x8
    72cc:	f9400842 	ldr	x2, [x2, #16]
    72d0:	eb05003f 	cmp	x1, x5
    72d4:	54fffe81 	b.ne	72a4 <f12+0x944>  // b.any
    72d8:	b4003a56 	cbz	x22, 7a20 <f12+0x10c0>
    72dc:	91154280 	add	x0, x20, #0x550
    72e0:	aa1603e2 	mov	x2, x22
    72e4:	d280001b 	mov	x27, #0x0                   	// #0
    72e8:	f949ec06 	ldr	x6, [x0, #5080]
    72ec:	f949d807 	ldr	x7, [x0, #5040]
    72f0:	f949fc05 	ldr	x5, [x0, #5112]
    72f4:	d370bcc6 	lsl	x6, x6, #16
    72f8:	14000006 	b	7310 <f12+0x9b0>
    72fc:	f9400842 	ldr	x2, [x2, #16]
    7300:	9100077b 	add	x27, x27, #0x1
    7304:	f100005f 	cmp	x2, #0x0
    7308:	fa531362 	ccmp	x27, x19, #0x2, ne	// ne = any
    730c:	54000322 	b.cs	7370 <f12+0xa10>  // b.hs, b.nlast
    7310:	cb070040 	sub	x0, x2, x7
    7314:	eb06001f 	cmp	x0, x6
    7318:	540002c2 	b.cs	7370 <f12+0xa10>  // b.hs, b.nlast
    731c:	d350fc01 	lsr	x1, x0, #16
    7320:	8b010821 	add	x1, x1, x1, lsl #2
    7324:	d37df021 	lsl	x1, x1, #3
    7328:	8b0100a4 	add	x4, x5, x1
    732c:	f9401083 	ldr	x3, [x4, #32]
    7330:	b4000203 	cbz	x3, 7370 <f12+0xa10>
    7334:	386168a1 	ldrb	w1, [x5, x1]
    7338:	7100083f 	cmp	w1, #0x2
    733c:	54000e00 	b.eq	74fc <f12+0xb9c>  // b.none
    7340:	7100043f 	cmp	w1, #0x1
    7344:	54000161 	b.ne	7370 <f12+0xa10>  // b.any
    7348:	29430488 	ldp	w8, w1, [x4, #24]
    734c:	92403c00 	and	x0, x0, #0xffff
    7350:	9b087c00 	mul	x0, x0, x8
    7354:	d360fc00 	lsr	x0, x0, #32
    7358:	eb01001f 	cmp	x0, x1
    735c:	540000a2 	b.cs	7370 <f12+0xa10>  // b.hs, b.nlast
    7360:	8b000063 	add	x3, x3, x0
    7364:	39400060 	ldrb	w0, [x3]
    7368:	7100041f 	cmp	w0, #0x1
    736c:	54fffc80 	b.eq	72fc <f12+0x99c>  // b.none
    7370:	d2800019 	mov	x25, #0x0                   	// #0
    7374:	eb13037f 	cmp	x27, x19
    7378:	54000cc2 	b.cs	7510 <f12+0xbb0>  // b.hs, b.nlast
    737c:	b0000020 	adrp	x0, c000 <msg.4+0x20>
    7380:	d1002357 	sub	x23, x26, #0x8
    7384:	91154298 	add	x24, x20, #0x550
    7388:	d2800019 	mov	x25, #0x0                   	// #0
    738c:	fd401008 	ldr	d8, [x0, #32]
    7390:	14000042 	b	7498 <f12+0xb38>
    7394:	f9400381 	ldr	x1, [x28]
    7398:	aa2103e1 	mvn	x1, x1
    739c:	f8207b01 	str	x1, [x24, x0, lsl #3]
    73a0:	f100609f 	cmp	x4, #0x18
    73a4:	54000169 	b.ls	73d0 <f12+0xa70>  // b.plast
    73a8:	d1006482 	sub	x2, x4, #0x19
    73ac:	91006380 	add	x0, x28, #0x18
    73b0:	927df042 	and	x2, x2, #0xfffffffffffffff8
    73b4:	52800001 	mov	w1, #0x0                   	// #0
    73b8:	91002042 	add	x2, x2, #0x8
    73bc:	f90003e4 	str	x4, [sp]
    73c0:	b9000be5 	str	w5, [sp, #8]
    73c4:	97ffecff 	bl	27c0 <memset@plt>
    73c8:	f94003e4 	ldr	x4, [sp]
    73cc:	b9400be5 	ldr	w5, [sp, #8]
    73d0:	91154282 	add	x2, x20, #0x550
    73d4:	f94a1041 	ldr	x1, [x2, #5152]
    73d8:	ab040021 	adds	x1, x1, x4
    73dc:	54003562 	b.cs	7a88 <f12+0x1128>  // b.hs, b.nlast
    73e0:	f94a1440 	ldr	x0, [x2, #5160]
    73e4:	f90a1041 	str	x1, [x2, #5152]
    73e8:	eb00003f 	cmp	x1, x0
    73ec:	54000049 	b.ls	73f4 <f12+0xa94>  // b.plast
    73f0:	f90a1441 	str	x1, [x2, #5160]
    73f4:	91154280 	add	x0, x20, #0x550
    73f8:	1e6300a1 	ucvtf	d1, w5
    73fc:	fd4a1c00 	ldr	d0, [x0, #5176]
    7400:	1e612800 	fadd	d0, d0, d1
    7404:	fd0a1c00 	str	d0, [x0, #5176]
    7408:	a900e795 	stp	x21, x25, [x28, #8]
    740c:	aa1c03f9 	mov	x25, x28
    7410:	fd000388 	str	d8, [x28]
    7414:	f949db01 	ldr	x1, [x24, #5040]
    7418:	f949ef00 	ldr	x0, [x24, #5080]
    741c:	cb010381 	sub	x1, x28, x1
    7420:	eb00403f 	cmp	x1, x0, lsl #16
    7424:	54000322 	b.cs	7488 <f12+0xb28>  // b.hs, b.nlast
    7428:	d350fc20 	lsr	x0, x1, #16
    742c:	f949ff04 	ldr	x4, [x24, #5112]
    7430:	8b000800 	add	x0, x0, x0, lsl #2
    7434:	d37df002 	lsl	x2, x0, #3
    7438:	8b020080 	add	x0, x4, x2
    743c:	f940101c 	ldr	x28, [x0, #32]
    7440:	b400025c 	cbz	x28, 7488 <f12+0xb28>
    7444:	38626882 	ldrb	w2, [x4, x2]
    7448:	7100085f 	cmp	w2, #0x2
    744c:	54000b00 	b.eq	75ac <f12+0xc4c>  // b.none
    7450:	7100045f 	cmp	w2, #0x1
    7454:	540001a1 	b.ne	7488 <f12+0xb28>  // b.any
    7458:	29430002 	ldp	w2, w0, [x0, #24]
    745c:	92403c21 	and	x1, x1, #0xffff
    7460:	9b027c21 	mul	x1, x1, x2
    7464:	d360fc21 	lsr	x1, x1, #32
    7468:	eb00003f 	cmp	x1, x0
    746c:	540000e2 	b.cs	7488 <f12+0xb28>  // b.hs, b.nlast
    7470:	8b01039c 	add	x28, x28, x1
    7474:	39400380 	ldrb	w0, [x28]
    7478:	7103fc1f 	cmp	w0, #0xff
    747c:	54002000 	b.eq	787c <f12+0xf1c>  // b.none
    7480:	52800020 	mov	w0, #0x1                   	// #1
    7484:	39000380 	strb	w0, [x28]
    7488:	d1000660 	sub	x0, x19, #0x1
    748c:	eb1b001f 	cmp	x0, x27
    7490:	54000989 	b.ls	75c0 <f12+0xc60>  // b.plast
    7494:	aa0003f3 	mov	x19, x0
    7498:	b953a700 	ldr	w0, [x24, #5028]
    749c:	f8737af5 	ldr	x21, [x23, x19, lsl #3]
    74a0:	34000240 	cbz	w0, 74e8 <f12+0xb88>
    74a4:	397e8b00 	ldrb	w0, [x24, #4002]
    74a8:	910f0001 	add	x1, x0, #0x3c0
    74ac:	8b000400 	add	x0, x0, x0, lsl #1
    74b0:	b8617b05 	ldr	w5, [x24, x1, lsl #2]
    74b4:	8b000f01 	add	x1, x24, x0, lsl #3
    74b8:	f8607b1c 	ldr	x28, [x24, x0, lsl #3]
    74bc:	2a0503e4 	mov	w4, w5
    74c0:	b5fff6bc 	cbnz	x28, 7394 <f12+0xa34>
    74c4:	f940043c 	ldr	x28, [x1, #8]
    74c8:	b400011c 	cbz	x28, 74e8 <f12+0xb88>
    74cc:	f9400820 	ldr	x0, [x1, #16]
    74d0:	cb1c0000 	sub	x0, x0, x28
    74d4:	eb00009f 	cmp	x4, x0
    74d8:	54000088 	b.hi	74e8 <f12+0xb88>  // b.pmore
    74dc:	8b040380 	add	x0, x28, x4
    74e0:	f9000420 	str	x0, [x1, #8]
    74e4:	17ffffaf 	b	73a0 <f12+0xa40>
    74e8:	52800001 	mov	w1, #0x0                   	// #0
    74ec:	d2800300 	mov	x0, #0x18                  	// #24
    74f0:	97fff5c0 	bl	4bf0 <fwp_heap_alloc>
    74f4:	aa0003fc 	mov	x28, x0
    74f8:	17ffffc4 	b	7408 <f12+0xaa8>
    74fc:	72003c1f 	tst	w0, #0xffff
    7500:	54fff320 	b.eq	7364 <f12+0xa04>  // b.none
    7504:	d2800019 	mov	x25, #0x0                   	// #0
    7508:	eb13037f 	cmp	x27, x19
    750c:	54fff383 	b.cc	737c <f12+0xa1c>  // b.lo, b.ul, b.last
    7510:	8b1b0f5b 	add	x27, x26, x27, lsl #3
    7514:	aa1a03e1 	mov	x1, x26
    7518:	aa1603e0 	mov	x0, x22
    751c:	d503201f 	nop
    7520:	f8408422 	ldr	x2, [x1], #8
    7524:	f9000402 	str	x2, [x0, #8]
    7528:	aa0003e2 	mov	x2, x0
    752c:	f9400800 	ldr	x0, [x0, #16]
    7530:	eb1b003f 	cmp	x1, x27
    7534:	54ffff61 	b.ne	7520 <f12+0xbc0>  // b.any
    7538:	b9401be1 	ldr	w1, [sp, #24]
    753c:	f9000859 	str	x25, [x2, #16]
    7540:	aa1603f9 	mov	x25, x22
    7544:	aa0003f6 	mov	x22, x0
    7548:	34000041 	cbz	w1, 7550 <f12+0xbf0>
    754c:	d280001a 	mov	x26, #0x0                   	// #0
    7550:	aa1a03e0 	mov	x0, x26
    7554:	97fff487 	bl	4770 <fwp_mem_free>
    7558:	f9400be0 	ldr	x0, [sp, #16]
    755c:	97fffc61 	bl	66e0 <fwp_drop4>
    7560:	aa1603e0 	mov	x0, x22
    7564:	97fff88f 	bl	57a0 <fwp_drop0>
    7568:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    756c:	f947f400 	ldr	x0, [x0, #4072]
    7570:	f9404fe2 	ldr	x2, [sp, #152]
    7574:	f9400001 	ldr	x1, [x0]
    7578:	eb010042 	subs	x2, x2, x1
    757c:	d2800001 	mov	x1, #0x0                   	// #0
    7580:	54002921 	b.ne	7aa4 <f12+0x1144>  // b.any
    7584:	a94a7bfd 	ldp	x29, x30, [sp, #160]
    7588:	aa1903e0 	mov	x0, x25
    758c:	a94b53f3 	ldp	x19, x20, [sp, #176]
    7590:	a94c5bf5 	ldp	x21, x22, [sp, #192]
    7594:	a94d63f7 	ldp	x23, x24, [sp, #208]
    7598:	a94e6bf9 	ldp	x25, x26, [sp, #224]
    759c:	a94f73fb 	ldp	x27, x28, [sp, #240]
    75a0:	fd4083e8 	ldr	d8, [sp, #256]
    75a4:	910443ff 	add	sp, sp, #0x110
    75a8:	d65f03c0 	ret
    75ac:	72003c3f 	tst	w1, #0xffff
    75b0:	54fff620 	b.eq	7474 <f12+0xb14>  // b.none
    75b4:	d1000660 	sub	x0, x19, #0x1
    75b8:	eb1b001f 	cmp	x0, x27
    75bc:	54fff6c8 	b.hi	7494 <f12+0xb34>  // b.pmore
    75c0:	b5fffa9b 	cbnz	x27, 7510 <f12+0xbb0>
    75c4:	b9401be1 	ldr	w1, [sp, #24]
    75c8:	7100003f 	cmp	w1, #0x0
    75cc:	9a9f035a 	csel	x26, x26, xzr, eq	// eq = none
    75d0:	b4fffc00 	cbz	x0, 7550 <f12+0xbf0>
    75d4:	91154294 	add	x20, x20, #0x550
    75d8:	b0000020 	adrp	x0, c000 <msg.4+0x20>
    75dc:	d1000a73 	sub	x19, x19, #0x2
    75e0:	52800035 	mov	w21, #0x1                   	// #1
    75e4:	fd401008 	ldr	d8, [x0, #32]
    75e8:	b953a680 	ldr	w0, [x20, #5028]
    75ec:	f8737b58 	ldr	x24, [x26, x19, lsl #3]
    75f0:	340008c0 	cbz	w0, 7708 <f12+0xda8>
    75f4:	d503201f 	nop
    75f8:	397e8a80 	ldrb	w0, [x20, #4002]
    75fc:	910f0001 	add	x1, x0, #0x3c0
    7600:	8b000400 	add	x0, x0, x0, lsl #1
    7604:	b8617a9c 	ldr	w28, [x20, x1, lsl #2]
    7608:	8b000e81 	add	x1, x20, x0, lsl #3
    760c:	f8607a97 	ldr	x23, [x20, x0, lsl #3]
    7610:	2a1c03fb 	mov	w27, w28
    7614:	b4002177 	cbz	x23, 7a40 <f12+0x10e0>
    7618:	f94002e1 	ldr	x1, [x23]
    761c:	aa2103e1 	mvn	x1, x1
    7620:	f8207a81 	str	x1, [x20, x0, lsl #3]
    7624:	f100637f 	cmp	x27, #0x18
    7628:	540000e9 	b.ls	7644 <f12+0xce4>  // b.plast
    762c:	d1006762 	sub	x2, x27, #0x19
    7630:	910062e0 	add	x0, x23, #0x18
    7634:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7638:	52800001 	mov	w1, #0x0                   	// #0
    763c:	91002042 	add	x2, x2, #0x8
    7640:	97ffec60 	bl	27c0 <memset@plt>
    7644:	f94a1280 	ldr	x0, [x20, #5152]
    7648:	ab1b0000 	adds	x0, x0, x27
    764c:	540021e2 	b.cs	7a88 <f12+0x1128>  // b.hs, b.nlast
    7650:	f94a1681 	ldr	x1, [x20, #5160]
    7654:	f90a1280 	str	x0, [x20, #5152]
    7658:	eb01001f 	cmp	x0, x1
    765c:	54000049 	b.ls	7664 <f12+0xd04>  // b.plast
    7660:	f90a1680 	str	x0, [x20, #5160]
    7664:	1e630381 	ucvtf	d1, w28
    7668:	fd4a1e80 	ldr	d0, [x20, #5176]
    766c:	1e612800 	fadd	d0, d0, d1
    7670:	fd0a1e80 	str	d0, [x20, #5176]
    7674:	a900e6f8 	stp	x24, x25, [x23, #8]
    7678:	aa1703f9 	mov	x25, x23
    767c:	fd0002e8 	str	d8, [x23]
    7680:	f949da81 	ldr	x1, [x20, #5040]
    7684:	f949ee80 	ldr	x0, [x20, #5080]
    7688:	cb0102e1 	sub	x1, x23, x1
    768c:	eb00403f 	cmp	x1, x0, lsl #16
    7690:	54000302 	b.cs	76f0 <f12+0xd90>  // b.hs, b.nlast
    7694:	d350fc22 	lsr	x2, x1, #16
    7698:	f949fe83 	ldr	x3, [x20, #5112]
    769c:	8b020842 	add	x2, x2, x2, lsl #2
    76a0:	d37df042 	lsl	x2, x2, #3
    76a4:	8b020060 	add	x0, x3, x2
    76a8:	f9401017 	ldr	x23, [x0, #32]
    76ac:	b4000237 	cbz	x23, 76f0 <f12+0xd90>
    76b0:	38626862 	ldrb	w2, [x3, x2]
    76b4:	7100085f 	cmp	w2, #0x2
    76b8:	54001d60 	b.eq	7a64 <f12+0x1104>  // b.none
    76bc:	7100045f 	cmp	w2, #0x1
    76c0:	54000181 	b.ne	76f0 <f12+0xd90>  // b.any
    76c4:	29430002 	ldp	w2, w0, [x0, #24]
    76c8:	92403c21 	and	x1, x1, #0xffff
    76cc:	9b027c21 	mul	x1, x1, x2
    76d0:	d360fc21 	lsr	x1, x1, #32
    76d4:	eb00003f 	cmp	x1, x0
    76d8:	540000c2 	b.cs	76f0 <f12+0xd90>  // b.hs, b.nlast
    76dc:	8b0102f7 	add	x23, x23, x1
    76e0:	394002e0 	ldrb	w0, [x23]
    76e4:	7103fc1f 	cmp	w0, #0xff
    76e8:	54001a60 	b.eq	7a34 <f12+0x10d4>  // b.none
    76ec:	390002f5 	strb	w21, [x23]
    76f0:	d1000673 	sub	x19, x19, #0x1
    76f4:	b100067f 	cmn	x19, #0x1
    76f8:	54fff2c0 	b.eq	7550 <f12+0xbf0>  // b.none
    76fc:	b953a680 	ldr	w0, [x20, #5028]
    7700:	f8737b58 	ldr	x24, [x26, x19, lsl #3]
    7704:	35fff7a0 	cbnz	w0, 75f8 <f12+0xc98>
    7708:	52800001 	mov	w1, #0x0                   	// #0
    770c:	d2800300 	mov	x0, #0x18                  	// #24
    7710:	97fff538 	bl	4bf0 <fwp_heap_alloc>
    7714:	aa0003f7 	mov	x23, x0
    7718:	17ffffd7 	b	7674 <f12+0xd14>
    771c:	72003c1f 	tst	w0, #0xffff
    7720:	54ffd960 	b.eq	724c <f12+0x8ec>  // b.none
    7724:	b40012b6 	cbz	x22, 7978 <f12+0x1018>
    7728:	aa1603f7 	mov	x23, x22
    772c:	d2800018 	mov	x24, #0x0                   	// #0
    7730:	f9400af7 	ldr	x23, [x23, #16]
    7734:	aa1803e0 	mov	x0, x24
    7738:	91000718 	add	x24, x24, #0x1
    773c:	b5ffffb7 	cbnz	x23, 7730 <f12+0xdd0>
    7740:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7744:	eb01031f 	cmp	x24, x1
    7748:	54001c88 	b.hi	7ad8 <f12+0x1178>  // b.pmore
    774c:	91000800 	add	x0, x0, #0x2
    7750:	52800041 	mov	w1, #0x2                   	// #2
    7754:	d37df000 	lsl	x0, x0, #3
    7758:	97fff526 	bl	4bf0 <fwp_heap_alloc>
    775c:	eb13031f 	cmp	x24, x19
    7760:	aa0003fa 	mov	x26, x0
    7764:	9a939313 	csel	x19, x24, x19, ls	// ls = plast
    7768:	aa1603e1 	mov	x1, x22
    776c:	d503201f 	nop
    7770:	f9400420 	ldr	x0, [x1, #8]
    7774:	f8377b40 	str	x0, [x26, x23, lsl #3]
    7778:	910006f7 	add	x23, x23, #0x1
    777c:	f9400821 	ldr	x1, [x1, #16]
    7780:	b5ffff81 	cbnz	x1, 7770 <f12+0xe10>
    7784:	b4001033 	cbz	x19, 7988 <f12+0x1028>
    7788:	f9400323 	ldr	x3, [x25]
    778c:	b9001bff 	str	wzr, [sp, #24]
    7790:	17fffeb7 	b	726c <f12+0x90c>
    7794:	72003c1f 	tst	w0, #0xffff
    7798:	54ffca20 	b.eq	70dc <f12+0x77c>  // b.none
    779c:	d503201f 	nop
    77a0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    77a4:	eb0002ff 	cmp	x23, x0
    77a8:	54001788 	b.hi	7a98 <f12+0x1138>  // b.pmore
    77ac:	910006e0 	add	x0, x23, #0x1
    77b0:	52800021 	mov	w1, #0x1                   	// #1
    77b4:	d37df000 	lsl	x0, x0, #3
    77b8:	97fff50e 	bl	4bf0 <fwp_heap_alloc>
    77bc:	91154282 	add	x2, x20, #0x550
    77c0:	f9000017 	str	x23, [x0]
    77c4:	aa0003f9 	mov	x25, x0
    77c8:	f9000bf9 	str	x25, [sp, #16]
    77cc:	f949d841 	ldr	x1, [x2, #5040]
    77d0:	f949ec40 	ldr	x0, [x2, #5080]
    77d4:	cb010321 	sub	x1, x25, x1
    77d8:	eb00403f 	cmp	x1, x0, lsl #16
    77dc:	54000322 	b.cs	7840 <f12+0xee0>  // b.hs, b.nlast
    77e0:	d350fc20 	lsr	x0, x1, #16
    77e4:	f949fc43 	ldr	x3, [x2, #5112]
    77e8:	8b000800 	add	x0, x0, x0, lsl #2
    77ec:	d37df002 	lsl	x2, x0, #3
    77f0:	8b020060 	add	x0, x3, x2
    77f4:	f9401018 	ldr	x24, [x0, #32]
    77f8:	b4000258 	cbz	x24, 7840 <f12+0xee0>
    77fc:	38626862 	ldrb	w2, [x3, x2]
    7800:	7100085f 	cmp	w2, #0x2
    7804:	54000c60 	b.eq	7990 <f12+0x1030>  // b.none
    7808:	7100045f 	cmp	w2, #0x1
    780c:	540001a1 	b.ne	7840 <f12+0xee0>  // b.any
    7810:	29430002 	ldp	w2, w0, [x0, #24]
    7814:	92403c21 	and	x1, x1, #0xffff
    7818:	9b027c21 	mul	x1, x1, x2
    781c:	d360fc21 	lsr	x1, x1, #32
    7820:	eb00003f 	cmp	x1, x0
    7824:	540000e2 	b.cs	7840 <f12+0xee0>  // b.hs, b.nlast
    7828:	8b010318 	add	x24, x24, x1
    782c:	39400300 	ldrb	w0, [x24]
    7830:	7103fc1f 	cmp	w0, #0xff
    7834:	54000ec0 	b.eq	7a0c <f12+0x10ac>  // b.none
    7838:	52800020 	mov	w0, #0x1                   	// #1
    783c:	39000300 	strb	w0, [x24]
    7840:	aa1303e0 	mov	x0, x19
    7844:	17fffe2c 	b	70f4 <f12+0x794>
    7848:	52800041 	mov	w1, #0x2                   	// #2
    784c:	d2800100 	mov	x0, #0x8                   	// #8
    7850:	97fff4e8 	bl	4bf0 <fwp_heap_alloc>
    7854:	aa0003fb 	mov	x27, x0
    7858:	91154280 	add	x0, x20, #0x550
    785c:	f900037f 	str	xzr, [x27]
    7860:	f949d801 	ldr	x1, [x0, #5040]
    7864:	f949ec00 	ldr	x0, [x0, #5080]
    7868:	cb010361 	sub	x1, x27, x1
    786c:	eb00403f 	cmp	x1, x0, lsl #16
    7870:	54000362 	b.cs	78dc <f12+0xf7c>  // b.hs, b.nlast
    7874:	d2800013 	mov	x19, #0x0                   	// #0
    7878:	17fffd0b 	b	6ca4 <f12+0x344>
    787c:	aa1c03e0 	mov	x0, x28
    7880:	97fff31c 	bl	44f0 <fwp_rc_forget_slot>
    7884:	17fffeff 	b	7480 <f12+0xb20>
    7888:	f100027f 	cmp	x19, #0x0
    788c:	fa401860 	ccmp	x3, #0x0, #0x0, ne	// ne = any
    7890:	54ffb261 	b.ne	6edc <f12+0x57c>  // b.any
    7894:	f94027e1 	ldr	x1, [sp, #72]
    7898:	910102f7 	add	x23, x23, #0x40
    789c:	aa1a03e0 	mov	x0, x26
    78a0:	f90162e1 	str	x1, [x23, #704]
    78a4:	97fff1f7 	bl	4080 <fwp_tape_buffers_release>
    78a8:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    78ac:	f947e863 	ldr	x3, [x3, #4048]
    78b0:	d2800262 	mov	x2, #0x13                  	// #19
    78b4:	d2800021 	mov	x1, #0x1                   	// #1
    78b8:	90000020 	adrp	x0, b000 <__modti3+0x30>
    78bc:	910de000 	add	x0, x0, #0x378
    78c0:	f9400063 	ldr	x3, [x3]
    78c4:	97ffec0b 	bl	28f0 <fwrite@plt>
    78c8:	d2800000 	mov	x0, #0x0                   	// #0
    78cc:	97ffec15 	bl	2920 <fflush@plt>
    78d0:	52800cc0 	mov	w0, #0x66                  	// #102
    78d4:	97ffec23 	bl	2960 <_Exit@plt>
    78d8:	b5ffa1b3 	cbnz	x19, 6d0c <f12+0x3ac>
    78dc:	d280001c 	mov	x28, #0x0                   	// #0
    78e0:	17fffd31 	b	6da4 <f12+0x444>
    78e4:	d0ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0xdc>
    78e8:	91338000 	add	x0, x0, #0xce0
    78ec:	94000e95 	bl	b340 <atexit>
    78f0:	35fffdc0 	cbnz	w0, 78a8 <f12+0xf48>
    78f4:	52800020 	mov	w0, #0x1                   	// #1
    78f8:	b902f6a0 	str	w0, [x21, #756]
    78fc:	17fffc65 	b	6a90 <f12+0x130>
    7900:	72003c3f 	tst	w1, #0xffff
    7904:	54ffa021 	b.ne	6d08 <f12+0x3a8>  // b.any
    7908:	17fffcfb 	b	6cf4 <f12+0x394>
    790c:	72003c3f 	tst	w1, #0xffff
    7910:	54ff8960 	b.eq	6a3c <f12+0xdc>  // b.none
    7914:	aa1503e0 	mov	x0, x21
    7918:	97fff852 	bl	5a60 <fwp_closure_drop>
    791c:	b5ff8a36 	cbnz	x22, 6a60 <f12+0x100>
    7920:	d280001a 	mov	x26, #0x0                   	// #0
    7924:	17fffc58 	b	6a84 <f12+0x124>
    7928:	72003c3f 	tst	w1, #0xffff
    792c:	54ffb921 	b.ne	7050 <f12+0x6f0>  // b.any
    7930:	17fffdc3 	b	703c <f12+0x6dc>
    7934:	aa1c03f3 	mov	x19, x28
    7938:	17fffd52 	b	6e80 <f12+0x520>
    793c:	3cc48002 	ldur	q2, [x0, #72]
    7940:	91012001 	add	x1, x0, #0x48
    7944:	3cc58001 	ldur	q1, [x0, #88]
    7948:	f900401f 	str	xzr, [x0, #128]
    794c:	4f000400 	movi	v0.4s, #0x0
    7950:	ad010762 	stp	q2, q1, [x27, #32]
    7954:	a9468002 	ldp	x2, x0, [x0, #104]
    7958:	f9000f60 	str	x0, [x27, #24]
    795c:	f9401820 	ldr	x0, [x1, #48]
    7960:	f9002362 	str	x2, [x27, #64]
    7964:	f9002760 	str	x0, [x27, #72]
    7968:	ad000020 	stp	q0, q0, [x1]
    796c:	3d800820 	str	q0, [x1, #32]
    7970:	f900183f 	str	xzr, [x1, #48]
    7974:	17fffc8a 	b	6b9c <f12+0x23c>
    7978:	52800041 	mov	w1, #0x2                   	// #2
    797c:	d2800100 	mov	x0, #0x8                   	// #8
    7980:	97fff49c 	bl	4bf0 <fwp_heap_alloc>
    7984:	aa0003fa 	mov	x26, x0
    7988:	d2800019 	mov	x25, #0x0                   	// #0
    798c:	17fffef1 	b	7550 <f12+0xbf0>
    7990:	72003c3f 	tst	w1, #0xffff
    7994:	54fff4c0 	b.eq	782c <f12+0xecc>  // b.none
    7998:	aa1303e0 	mov	x0, x19
    799c:	17fffdd6 	b	70f4 <f12+0x794>
    79a0:	aa1b03e0 	mov	x0, x27
    79a4:	d2800101 	mov	x1, #0x8                   	// #8
    79a8:	97ffeb8a 	bl	27d0 <calloc@plt>
    79ac:	aa0003e3 	mov	x3, x0
    79b0:	a94017e4 	ldp	x4, x5, [sp]
    79b4:	a9411fe6 	ldp	x6, x7, [sp, #16]
    79b8:	17fffd46 	b	6ed0 <f12+0x570>
    79bc:	f9400323 	ldr	x3, [x25]
    79c0:	b7fffdc3 	tbnz	x3, #63, 7978 <f12+0x1018>
    79c4:	91154281 	add	x1, x20, #0x550
    79c8:	f9400be4 	ldr	x4, [sp, #16]
    79cc:	f949d820 	ldr	x0, [x1, #5040]
    79d0:	f949ec21 	ldr	x1, [x1, #5080]
    79d4:	cb000080 	sub	x0, x4, x0
    79d8:	eb01401f 	cmp	x0, x1, lsl #16
    79dc:	54fffce2 	b.cs	7978 <f12+0x1018>  // b.hs, b.nlast
    79e0:	9240f873 	and	x19, x3, #0x7fffffffffffffff
    79e4:	17fffe06 	b	71fc <f12+0x89c>
    79e8:	d2800d01 	mov	x1, #0x68                  	// #104
    79ec:	d2800022 	mov	x2, #0x1                   	// #1
    79f0:	17fffc4b 	b	6b1c <f12+0x1bc>
    79f4:	aa1503e0 	mov	x0, x21
    79f8:	97fff2be 	bl	44f0 <fwp_rc_forget_slot>
    79fc:	17fffcc1 	b	6d00 <f12+0x3a0>
    7a00:	aa1503e0 	mov	x0, x21
    7a04:	97fff2bb 	bl	44f0 <fwp_rc_forget_slot>
    7a08:	17fffd90 	b	7048 <f12+0x6e8>
    7a0c:	aa1803e0 	mov	x0, x24
    7a10:	97fff2b8 	bl	44f0 <fwp_rc_forget_slot>
    7a14:	17ffff89 	b	7838 <f12+0xed8>
    7a18:	97fff26f 	bl	43d4 <fwp_rc_wide_dup>
    7a1c:	17fffc0e 	b	6a54 <f12+0xf4>
    7a20:	d280001b 	mov	x27, #0x0                   	// #0
    7a24:	17fffe56 	b	737c <f12+0xa1c>
    7a28:	d280001a 	mov	x26, #0x0                   	// #0
    7a2c:	d2800019 	mov	x25, #0x0                   	// #0
    7a30:	17fffec8 	b	7550 <f12+0xbf0>
    7a34:	aa1703e0 	mov	x0, x23
    7a38:	97fff2ae 	bl	44f0 <fwp_rc_forget_slot>
    7a3c:	17ffff2c 	b	76ec <f12+0xd8c>
    7a40:	f9400437 	ldr	x23, [x1, #8]
    7a44:	b4ffe637 	cbz	x23, 7708 <f12+0xda8>
    7a48:	f9400820 	ldr	x0, [x1, #16]
    7a4c:	cb170000 	sub	x0, x0, x23
    7a50:	eb00037f 	cmp	x27, x0
    7a54:	54ffe5a8 	b.hi	7708 <f12+0xda8>  // b.pmore
    7a58:	8b1b02e0 	add	x0, x23, x27
    7a5c:	f9000420 	str	x0, [x1, #8]
    7a60:	17fffef1 	b	7624 <f12+0xcc4>
    7a64:	72003c3f 	tst	w1, #0xffff
    7a68:	54ffe441 	b.ne	76f0 <f12+0xd90>  // b.any
    7a6c:	17ffff1d 	b	76e0 <f12+0xd80>
    7a70:	90000020 	adrp	x0, b000 <__modti3+0x30>
    7a74:	911be000 	add	x0, x0, #0x6f8
    7a78:	97ffeea2 	bl	3500 <fwp_trap>
    7a7c:	90000020 	adrp	x0, b000 <__modti3+0x30>
    7a80:	91198000 	add	x0, x0, #0x660
    7a84:	97ffee9f 	bl	3500 <fwp_trap>
    7a88:	97ffed4a 	bl	2fb0 <fwp_heap_oom>
    7a8c:	90000020 	adrp	x0, b000 <__modti3+0x30>
    7a90:	911fe000 	add	x0, x0, #0x7f8
    7a94:	97ffee9b 	bl	3500 <fwp_trap>
    7a98:	90000020 	adrp	x0, b000 <__modti3+0x30>
    7a9c:	911fa000 	add	x0, x0, #0x7e8
    7aa0:	97ffee98 	bl	3500 <fwp_trap>
    7aa4:	97ffeb53 	bl	27f0 <__stack_chk_fail@plt>
    7aa8:	90000020 	adrp	x0, b000 <__modti3+0x30>
    7aac:	911ea000 	add	x0, x0, #0x7a8
    7ab0:	97ffee94 	bl	3500 <fwp_trap>
    7ab4:	90000020 	adrp	x0, b000 <__modti3+0x30>
    7ab8:	911d6000 	add	x0, x0, #0x758
    7abc:	97ffee91 	bl	3500 <fwp_trap>
    7ac0:	90000020 	adrp	x0, b000 <__modti3+0x30>
    7ac4:	911de000 	add	x0, x0, #0x778
    7ac8:	97ffee8e 	bl	3500 <fwp_trap>
    7acc:	90000020 	adrp	x0, b000 <__modti3+0x30>
    7ad0:	911aa000 	add	x0, x0, #0x6a8
    7ad4:	97ffee8b 	bl	3500 <fwp_trap>
    7ad8:	90000020 	adrp	x0, b000 <__modti3+0x30>
    7adc:	911f6000 	add	x0, x0, #0x7d8
    7ae0:	97ffee88 	bl	3500 <fwp_trap>
    7ae4:	97ffeb57 	bl	2840 <abort@plt>
    7ae8:	97ffebc6 	bl	2a00 <fwp_trap_overflow.constprop.0>
    7aec:	d503201f 	nop

0000000000007af0 <fwp_owned_entry12>:
    7af0:	f9400000 	ldr	x0, [x0]
    7af4:	17fffb9b 	b	6960 <f12>
    7af8:	d503201f 	nop
    7afc:	d503201f 	nop

0000000000007b00 <e12>:
    7b00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7b04:	910003fd 	mov	x29, sp
    7b08:	f9000bf3 	str	x19, [sp, #16]
    7b0c:	f9400013 	ldr	x19, [x0]
    7b10:	aa1303e0 	mov	x0, x19
    7b14:	97fff6b4 	bl	55e4 <fwp_rc_share>
    7b18:	aa1303e0 	mov	x0, x19
    7b1c:	97fffb91 	bl	6960 <f12>
    7b20:	aa0003f3 	mov	x19, x0
    7b24:	97fff6b0 	bl	55e4 <fwp_rc_share>
    7b28:	aa1303e0 	mov	x0, x19
    7b2c:	f9400bf3 	ldr	x19, [sp, #16]
    7b30:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7b34:	d65f03c0 	ret
    7b38:	d503201f 	nop
    7b3c:	d503201f 	nop

0000000000007b40 <fwp_args23>:
    7b40:	7100003f 	cmp	w1, #0x0
    7b44:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7b48:	54000041 	b.ne	7b50 <fwp_args23+0x10>  // b.any
    7b4c:	d65f03c0 	ret
    7b50:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7b54:	91154042 	add	x2, x2, #0x550
    7b58:	f9400001 	ldr	x1, [x0]
    7b5c:	f949d843 	ldr	x3, [x2, #5040]
    7b60:	f949ec40 	ldr	x0, [x2, #5080]
    7b64:	cb030021 	sub	x1, x1, x3
    7b68:	eb00403f 	cmp	x1, x0, lsl #16
    7b6c:	54ffff02 	b.cs	7b4c <fwp_args23+0xc>  // b.hs, b.nlast
    7b70:	d350fc20 	lsr	x0, x1, #16
    7b74:	f949fc44 	ldr	x4, [x2, #5112]
    7b78:	8b000800 	add	x0, x0, x0, lsl #2
    7b7c:	d37df002 	lsl	x2, x0, #3
    7b80:	8b020083 	add	x3, x4, x2
    7b84:	f9401060 	ldr	x0, [x3, #32]
    7b88:	b4fffe20 	cbz	x0, 7b4c <fwp_args23+0xc>
    7b8c:	38626882 	ldrb	w2, [x4, x2]
    7b90:	7100085f 	cmp	w2, #0x2
    7b94:	54000220 	b.eq	7bd8 <fwp_args23+0x98>  // b.none
    7b98:	7100045f 	cmp	w2, #0x1
    7b9c:	54fffd81 	b.ne	7b4c <fwp_args23+0xc>  // b.any
    7ba0:	29430864 	ldp	w4, w2, [x3, #24]
    7ba4:	92403c21 	and	x1, x1, #0xffff
    7ba8:	9b047c21 	mul	x1, x1, x4
    7bac:	d360fc21 	lsr	x1, x1, #32
    7bb0:	eb02003f 	cmp	x1, x2
    7bb4:	54fffcc2 	b.cs	7b4c <fwp_args23+0xc>  // b.hs, b.nlast
    7bb8:	8b010000 	add	x0, x0, x1
    7bbc:	39400001 	ldrb	w1, [x0]
    7bc0:	34fffc61 	cbz	w1, 7b4c <fwp_args23+0xc>
    7bc4:	7103f43f 	cmp	w1, #0xfd
    7bc8:	540000e8 	b.hi	7be4 <fwp_args23+0xa4>  // b.pmore
    7bcc:	11000421 	add	w1, w1, #0x1
    7bd0:	39000001 	strb	w1, [x0]
    7bd4:	d65f03c0 	ret
    7bd8:	72003c3f 	tst	w1, #0xffff
    7bdc:	54ffff00 	b.eq	7bbc <fwp_args23+0x7c>  // b.none
    7be0:	d65f03c0 	ret
    7be4:	17fff1fc 	b	43d4 <fwp_rc_wide_dup>
    7be8:	d503201f 	nop
    7bec:	d503201f 	nop

0000000000007bf0 <fwp_args12>:
    7bf0:	7100003f 	cmp	w1, #0x0
    7bf4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7bf8:	54000041 	b.ne	7c00 <fwp_args12+0x10>  // b.any
    7bfc:	d65f03c0 	ret
    7c00:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7c04:	91154042 	add	x2, x2, #0x550
    7c08:	f9400001 	ldr	x1, [x0]
    7c0c:	f949d843 	ldr	x3, [x2, #5040]
    7c10:	f949ec40 	ldr	x0, [x2, #5080]
    7c14:	cb030021 	sub	x1, x1, x3
    7c18:	eb00403f 	cmp	x1, x0, lsl #16
    7c1c:	54ffff02 	b.cs	7bfc <fwp_args12+0xc>  // b.hs, b.nlast
    7c20:	d350fc20 	lsr	x0, x1, #16
    7c24:	f949fc44 	ldr	x4, [x2, #5112]
    7c28:	8b000800 	add	x0, x0, x0, lsl #2
    7c2c:	d37df002 	lsl	x2, x0, #3
    7c30:	8b020083 	add	x3, x4, x2
    7c34:	f9401060 	ldr	x0, [x3, #32]
    7c38:	b4fffe20 	cbz	x0, 7bfc <fwp_args12+0xc>
    7c3c:	38626882 	ldrb	w2, [x4, x2]
    7c40:	7100085f 	cmp	w2, #0x2
    7c44:	54000220 	b.eq	7c88 <fwp_args12+0x98>  // b.none
    7c48:	7100045f 	cmp	w2, #0x1
    7c4c:	54fffd81 	b.ne	7bfc <fwp_args12+0xc>  // b.any
    7c50:	29430864 	ldp	w4, w2, [x3, #24]
    7c54:	92403c21 	and	x1, x1, #0xffff
    7c58:	9b047c21 	mul	x1, x1, x4
    7c5c:	d360fc21 	lsr	x1, x1, #32
    7c60:	eb02003f 	cmp	x1, x2
    7c64:	54fffcc2 	b.cs	7bfc <fwp_args12+0xc>  // b.hs, b.nlast
    7c68:	8b010000 	add	x0, x0, x1
    7c6c:	39400001 	ldrb	w1, [x0]
    7c70:	34fffc61 	cbz	w1, 7bfc <fwp_args12+0xc>
    7c74:	7103f43f 	cmp	w1, #0xfd
    7c78:	540000e8 	b.hi	7c94 <fwp_args12+0xa4>  // b.pmore
    7c7c:	11000421 	add	w1, w1, #0x1
    7c80:	39000001 	strb	w1, [x0]
    7c84:	d65f03c0 	ret
    7c88:	72003c3f 	tst	w1, #0xffff
    7c8c:	54ffff00 	b.eq	7c6c <fwp_args12+0x7c>  // b.none
    7c90:	d65f03c0 	ret
    7c94:	17fff1d0 	b	43d4 <fwp_rc_wide_dup>
    7c98:	d503201f 	nop
    7c9c:	d503201f 	nop

0000000000007ca0 <fwp_caps12>:
    7ca0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7ca4:	910003fd 	mov	x29, sp
    7ca8:	f9000bf3 	str	x19, [sp, #16]
    7cac:	aa0003f3 	mov	x19, x0
    7cb0:	b9400400 	ldr	w0, [x0, #4]
    7cb4:	340004a0 	cbz	w0, 7d48 <fwp_caps12+0xa8>
    7cb8:	f9400660 	ldr	x0, [x19, #8]
    7cbc:	350004e1 	cbnz	w1, 7d58 <fwp_caps12+0xb8>
    7cc0:	97fff6b8 	bl	57a0 <fwp_drop0>
    7cc4:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7cc8:	91154042 	add	x2, x2, #0x550
    7ccc:	f949d840 	ldr	x0, [x2, #5040]
    7cd0:	f949ec41 	ldr	x1, [x2, #5080]
    7cd4:	cb000260 	sub	x0, x19, x0
    7cd8:	eb01401f 	cmp	x0, x1, lsl #16
    7cdc:	54000382 	b.cs	7d4c <fwp_caps12+0xac>  // b.hs, b.nlast
    7ce0:	d350fc01 	lsr	x1, x0, #16
    7ce4:	f949fc44 	ldr	x4, [x2, #5112]
    7ce8:	8b010821 	add	x1, x1, x1, lsl #2
    7cec:	d37df021 	lsl	x1, x1, #3
    7cf0:	8b010083 	add	x3, x4, x1
    7cf4:	f9401062 	ldr	x2, [x3, #32]
    7cf8:	b40002a2 	cbz	x2, 7d4c <fwp_caps12+0xac>
    7cfc:	38616881 	ldrb	w1, [x4, x1]
    7d00:	7100083f 	cmp	w1, #0x2
    7d04:	540006c0 	b.eq	7ddc <fwp_caps12+0x13c>  // b.none
    7d08:	7100043f 	cmp	w1, #0x1
    7d0c:	54000201 	b.ne	7d4c <fwp_caps12+0xac>  // b.any
    7d10:	29430464 	ldp	w4, w1, [x3, #24]
    7d14:	92403c00 	and	x0, x0, #0xffff
    7d18:	9b047c00 	mul	x0, x0, x4
    7d1c:	d360fc00 	lsr	x0, x0, #32
    7d20:	eb01001f 	cmp	x0, x1
    7d24:	54000142 	b.cs	7d4c <fwp_caps12+0xac>  // b.hs, b.nlast
    7d28:	8b000042 	add	x2, x2, x0
    7d2c:	39400040 	ldrb	w0, [x2]
    7d30:	7100041f 	cmp	w0, #0x1
    7d34:	540000c1 	b.ne	7d4c <fwp_caps12+0xac>  // b.any
    7d38:	aa1303e0 	mov	x0, x19
    7d3c:	f9400bf3 	ldr	x19, [sp, #16]
    7d40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7d44:	17fff28b 	b	4770 <fwp_mem_free>
    7d48:	34fffbe1 	cbz	w1, 7cc4 <fwp_caps12+0x24>
    7d4c:	f9400bf3 	ldr	x19, [sp, #16]
    7d50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7d54:	d65f03c0 	ret
    7d58:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7d5c:	91154042 	add	x2, x2, #0x550
    7d60:	f949d843 	ldr	x3, [x2, #5040]
    7d64:	f949ec41 	ldr	x1, [x2, #5080]
    7d68:	cb030000 	sub	x0, x0, x3
    7d6c:	eb01401f 	cmp	x0, x1, lsl #16
    7d70:	54fffee2 	b.cs	7d4c <fwp_caps12+0xac>  // b.hs, b.nlast
    7d74:	d350fc01 	lsr	x1, x0, #16
    7d78:	f949fc44 	ldr	x4, [x2, #5112]
    7d7c:	8b010821 	add	x1, x1, x1, lsl #2
    7d80:	d37df021 	lsl	x1, x1, #3
    7d84:	8b010083 	add	x3, x4, x1
    7d88:	f9401062 	ldr	x2, [x3, #32]
    7d8c:	b4fffe02 	cbz	x2, 7d4c <fwp_caps12+0xac>
    7d90:	38616881 	ldrb	w1, [x4, x1]
    7d94:	7100083f 	cmp	w1, #0x2
    7d98:	54000280 	b.eq	7de8 <fwp_caps12+0x148>  // b.none
    7d9c:	7100043f 	cmp	w1, #0x1
    7da0:	54fffd61 	b.ne	7d4c <fwp_caps12+0xac>  // b.any
    7da4:	92403c01 	and	x1, x0, #0xffff
    7da8:	29430064 	ldp	w4, w0, [x3, #24]
    7dac:	9b047c21 	mul	x1, x1, x4
    7db0:	d360fc21 	lsr	x1, x1, #32
    7db4:	eb00003f 	cmp	x1, x0
    7db8:	54fffca2 	b.cs	7d4c <fwp_caps12+0xac>  // b.hs, b.nlast
    7dbc:	8b010042 	add	x2, x2, x1
    7dc0:	39400040 	ldrb	w0, [x2]
    7dc4:	34fffc40 	cbz	w0, 7d4c <fwp_caps12+0xac>
    7dc8:	7103f41f 	cmp	w0, #0xfd
    7dcc:	54000148 	b.hi	7df4 <fwp_caps12+0x154>  // b.pmore
    7dd0:	11000400 	add	w0, w0, #0x1
    7dd4:	39000040 	strb	w0, [x2]
    7dd8:	17ffffdd 	b	7d4c <fwp_caps12+0xac>
    7ddc:	72003c1f 	tst	w0, #0xffff
    7de0:	54fffb61 	b.ne	7d4c <fwp_caps12+0xac>  // b.any
    7de4:	17ffffd2 	b	7d2c <fwp_caps12+0x8c>
    7de8:	72003c1f 	tst	w0, #0xffff
    7dec:	54fffb01 	b.ne	7d4c <fwp_caps12+0xac>  // b.any
    7df0:	17fffff4 	b	7dc0 <fwp_caps12+0x120>
    7df4:	f9400bf3 	ldr	x19, [sp, #16]
    7df8:	aa0203e0 	mov	x0, x2
    7dfc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7e00:	17fff175 	b	43d4 <fwp_rc_wide_dup>

0000000000007e04 <fwp_drop2>:
    7e04:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7e08:	910003fd 	mov	x29, sp
    7e0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    7e10:	d0000156 	adrp	x22, 31000 <fwp_root_context+0xc90>
    7e14:	911542d5 	add	x21, x22, #0x550
    7e18:	a90153f3 	stp	x19, x20, [sp, #16]
    7e1c:	aa0003f3 	mov	x19, x0
    7e20:	f949daa1 	ldr	x1, [x21, #5040]
    7e24:	f949eea0 	ldr	x0, [x21, #5080]
    7e28:	cb010261 	sub	x1, x19, x1
    7e2c:	eb00403f 	cmp	x1, x0, lsl #16
    7e30:	54000382 	b.cs	7ea0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7e34:	d350fc22 	lsr	x2, x1, #16
    7e38:	f949fea3 	ldr	x3, [x21, #5112]
    7e3c:	8b020842 	add	x2, x2, x2, lsl #2
    7e40:	d37df042 	lsl	x2, x2, #3
    7e44:	8b020060 	add	x0, x3, x2
    7e48:	f9401014 	ldr	x20, [x0, #32]
    7e4c:	b40002b4 	cbz	x20, 7ea0 <fwp_drop2+0x9c>
    7e50:	38626862 	ldrb	w2, [x3, x2]
    7e54:	7100085f 	cmp	w2, #0x2
    7e58:	540002c0 	b.eq	7eb0 <fwp_drop2+0xac>  // b.none
    7e5c:	7100045f 	cmp	w2, #0x1
    7e60:	54000201 	b.ne	7ea0 <fwp_drop2+0x9c>  // b.any
    7e64:	29430002 	ldp	w2, w0, [x0, #24]
    7e68:	92403c21 	and	x1, x1, #0xffff
    7e6c:	9b027c21 	mul	x1, x1, x2
    7e70:	d360fc21 	lsr	x1, x1, #32
    7e74:	eb00003f 	cmp	x1, x0
    7e78:	54000142 	b.cs	7ea0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7e7c:	8b010294 	add	x20, x20, x1
    7e80:	39400280 	ldrb	w0, [x20]
    7e84:	340000e0 	cbz	w0, 7ea0 <fwp_drop2+0x9c>
    7e88:	7100041f 	cmp	w0, #0x1
    7e8c:	540001e0 	b.eq	7ec8 <fwp_drop2+0xc4>  // b.none
    7e90:	7103fc1f 	cmp	w0, #0xff
    7e94:	540007e0 	b.eq	7f90 <fwp_drop2+0x18c>  // b.none
    7e98:	51000400 	sub	w0, w0, #0x1
    7e9c:	39000280 	strb	w0, [x20]
    7ea0:	a94153f3 	ldp	x19, x20, [sp, #16]
    7ea4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7ea8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7eac:	d65f03c0 	ret
    7eb0:	72003c3f 	tst	w1, #0xffff
    7eb4:	54fffe60 	b.eq	7e80 <fwp_drop2+0x7c>  // b.none
    7eb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    7ebc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7ec0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7ec4:	d65f03c0 	ret
    7ec8:	911542c2 	add	x2, x22, #0x550
    7ecc:	f9400660 	ldr	x0, [x19, #8]
    7ed0:	f949d841 	ldr	x1, [x2, #5040]
    7ed4:	f949ec42 	ldr	x2, [x2, #5080]
    7ed8:	cb010001 	sub	x1, x0, x1
    7edc:	eb02403f 	cmp	x1, x2, lsl #16
    7ee0:	54000382 	b.cs	7f50 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7ee4:	d350fc22 	lsr	x2, x1, #16
    7ee8:	8b020842 	add	x2, x2, x2, lsl #2
    7eec:	d37df042 	lsl	x2, x2, #3
    7ef0:	8b020064 	add	x4, x3, x2
    7ef4:	f9401094 	ldr	x20, [x4, #32]
    7ef8:	b40002d4 	cbz	x20, 7f50 <fwp_drop2+0x14c>
    7efc:	38626862 	ldrb	w2, [x3, x2]
    7f00:	7100085f 	cmp	w2, #0x2
    7f04:	54000400 	b.eq	7f84 <fwp_drop2+0x180>  // b.none
    7f08:	7100045f 	cmp	w2, #0x1
    7f0c:	54000221 	b.ne	7f50 <fwp_drop2+0x14c>  // b.any
    7f10:	29430883 	ldp	w3, w2, [x4, #24]
    7f14:	92403c21 	and	x1, x1, #0xffff
    7f18:	9b037c21 	mul	x1, x1, x3
    7f1c:	d360fc21 	lsr	x1, x1, #32
    7f20:	eb02003f 	cmp	x1, x2
    7f24:	54000162 	b.cs	7f50 <fwp_drop2+0x14c>  // b.hs, b.nlast
    7f28:	8b010294 	add	x20, x20, x1
    7f2c:	39400281 	ldrb	w1, [x20]
    7f30:	34000101 	cbz	w1, 7f50 <fwp_drop2+0x14c>
    7f34:	7100043f 	cmp	w1, #0x1
    7f38:	54000220 	b.eq	7f7c <fwp_drop2+0x178>  // b.none
    7f3c:	7103fc3f 	cmp	w1, #0xff
    7f40:	540005a0 	b.eq	7ff4 <fwp_drop2+0x1f0>  // b.none
    7f44:	51000421 	sub	w1, w1, #0x1
    7f48:	39000281 	strb	w1, [x20]
    7f4c:	d503201f 	nop
    7f50:	f9400a74 	ldr	x20, [x19, #16]
    7f54:	aa1303e0 	mov	x0, x19
    7f58:	97fff5ca 	bl	5680 <fwp_rc_free_arr>
    7f5c:	911542c0 	add	x0, x22, #0x550
    7f60:	f949d801 	ldr	x1, [x0, #5040]
    7f64:	f949ec00 	ldr	x0, [x0, #5080]
    7f68:	cb010281 	sub	x1, x20, x1
    7f6c:	eb00403f 	cmp	x1, x0, lsl #16
    7f70:	54fff982 	b.cs	7ea0 <fwp_drop2+0x9c>  // b.hs, b.nlast
    7f74:	aa1403f3 	mov	x19, x20
    7f78:	17ffffaf 	b	7e34 <fwp_drop2+0x30>
    7f7c:	97fff5c1 	bl	5680 <fwp_rc_free_arr>
    7f80:	17fffff4 	b	7f50 <fwp_drop2+0x14c>
    7f84:	72003c3f 	tst	w1, #0xffff
    7f88:	54fffe41 	b.ne	7f50 <fwp_drop2+0x14c>  // b.any
    7f8c:	17ffffe8 	b	7f2c <fwp_drop2+0x128>
    7f90:	ca544681 	eor	x1, x20, x20, lsr #17
    7f94:	911542c0 	add	x0, x22, #0x550
    7f98:	ca412421 	eor	x1, x1, x1, lsr #9
    7f9c:	8b210c01 	add	x1, x0, w1, uxtb #3
    7fa0:	f94a2420 	ldr	x0, [x1, #5192]
    7fa4:	b5000080 	cbnz	x0, 7fb4 <fwp_drop2+0x1b0>
    7fa8:	14000010 	b	7fe8 <fwp_drop2+0x1e4>
    7fac:	f9400800 	ldr	x0, [x0, #16]
    7fb0:	b40001c0 	cbz	x0, 7fe8 <fwp_drop2+0x1e4>
    7fb4:	f9400001 	ldr	x1, [x0]
    7fb8:	eb14003f 	cmp	x1, x20
    7fbc:	54ffff81 	b.ne	7fac <fwp_drop2+0x1a8>  // b.any
    7fc0:	f9400401 	ldr	x1, [x0, #8]
    7fc4:	d1000421 	sub	x1, x1, #0x1
    7fc8:	f9000401 	str	x1, [x0, #8]
    7fcc:	f103f83f 	cmp	x1, #0xfe
    7fd0:	54fff681 	b.ne	7ea0 <fwp_drop2+0x9c>  // b.any
    7fd4:	aa1403e0 	mov	x0, x20
    7fd8:	97fff146 	bl	44f0 <fwp_rc_forget_slot>
    7fdc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7fe0:	39000280 	strb	w0, [x20]
    7fe4:	17ffffaf 	b	7ea0 <fwp_drop2+0x9c>
    7fe8:	90000020 	adrp	x0, b000 <__modti3+0x30>
    7fec:	91186000 	add	x0, x0, #0x618
    7ff0:	97ffed44 	bl	3500 <fwp_trap>
    7ff4:	ca544680 	eor	x0, x20, x20, lsr #17
    7ff8:	911542c1 	add	x1, x22, #0x550
    7ffc:	ca402400 	eor	x0, x0, x0, lsr #9
    8000:	8b200c20 	add	x0, x1, w0, uxtb #3
    8004:	f94a2400 	ldr	x0, [x0, #5192]
    8008:	b5000080 	cbnz	x0, 8018 <fwp_drop2+0x214>
    800c:	17fffff7 	b	7fe8 <fwp_drop2+0x1e4>
    8010:	f9400800 	ldr	x0, [x0, #16]
    8014:	b4fffea0 	cbz	x0, 7fe8 <fwp_drop2+0x1e4>
    8018:	f9400001 	ldr	x1, [x0]
    801c:	eb14003f 	cmp	x1, x20
    8020:	54ffff81 	b.ne	8010 <fwp_drop2+0x20c>  // b.any
    8024:	f9400401 	ldr	x1, [x0, #8]
    8028:	d1000421 	sub	x1, x1, #0x1
    802c:	f9000401 	str	x1, [x0, #8]
    8030:	f103f83f 	cmp	x1, #0xfe
    8034:	54fff8e1 	b.ne	7f50 <fwp_drop2+0x14c>  // b.any
    8038:	aa1403e0 	mov	x0, x20
    803c:	97fff12d 	bl	44f0 <fwp_rc_forget_slot>
    8040:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8044:	39000280 	strb	w0, [x20]
    8048:	17ffffc2 	b	7f50 <fwp_drop2+0x14c>
    804c:	d503201f 	nop

0000000000008050 <fwp_arg_drop23>:
    8050:	7100003f 	cmp	w1, #0x0
    8054:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8058:	54000041 	b.ne	8060 <fwp_arg_drop23+0x10>  // b.any
    805c:	d65f03c0 	ret
    8060:	f9400000 	ldr	x0, [x0]
    8064:	17ffff68 	b	7e04 <fwp_drop2>
    8068:	d503201f 	nop
    806c:	d503201f 	nop

0000000000008070 <fwp_caps23>:
    8070:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8074:	910003fd 	mov	x29, sp
    8078:	f9000bf3 	str	x19, [sp, #16]
    807c:	aa0003f3 	mov	x19, x0
    8080:	b9400400 	ldr	w0, [x0, #4]
    8084:	340004a0 	cbz	w0, 8118 <fwp_caps23+0xa8>
    8088:	f9400660 	ldr	x0, [x19, #8]
    808c:	350004e1 	cbnz	w1, 8128 <fwp_caps23+0xb8>
    8090:	97ffff5d 	bl	7e04 <fwp_drop2>
    8094:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    8098:	91154042 	add	x2, x2, #0x550
    809c:	f949d840 	ldr	x0, [x2, #5040]
    80a0:	f949ec41 	ldr	x1, [x2, #5080]
    80a4:	cb000260 	sub	x0, x19, x0
    80a8:	eb01401f 	cmp	x0, x1, lsl #16
    80ac:	54000382 	b.cs	811c <fwp_caps23+0xac>  // b.hs, b.nlast
    80b0:	d350fc01 	lsr	x1, x0, #16
    80b4:	f949fc44 	ldr	x4, [x2, #5112]
    80b8:	8b010821 	add	x1, x1, x1, lsl #2
    80bc:	d37df021 	lsl	x1, x1, #3
    80c0:	8b010083 	add	x3, x4, x1
    80c4:	f9401062 	ldr	x2, [x3, #32]
    80c8:	b40002a2 	cbz	x2, 811c <fwp_caps23+0xac>
    80cc:	38616881 	ldrb	w1, [x4, x1]
    80d0:	7100083f 	cmp	w1, #0x2
    80d4:	540006c0 	b.eq	81ac <fwp_caps23+0x13c>  // b.none
    80d8:	7100043f 	cmp	w1, #0x1
    80dc:	54000201 	b.ne	811c <fwp_caps23+0xac>  // b.any
    80e0:	29430464 	ldp	w4, w1, [x3, #24]
    80e4:	92403c00 	and	x0, x0, #0xffff
    80e8:	9b047c00 	mul	x0, x0, x4
    80ec:	d360fc00 	lsr	x0, x0, #32
    80f0:	eb01001f 	cmp	x0, x1
    80f4:	54000142 	b.cs	811c <fwp_caps23+0xac>  // b.hs, b.nlast
    80f8:	8b000042 	add	x2, x2, x0
    80fc:	39400040 	ldrb	w0, [x2]
    8100:	7100041f 	cmp	w0, #0x1
    8104:	540000c1 	b.ne	811c <fwp_caps23+0xac>  // b.any
    8108:	aa1303e0 	mov	x0, x19
    810c:	f9400bf3 	ldr	x19, [sp, #16]
    8110:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8114:	17fff197 	b	4770 <fwp_mem_free>
    8118:	34fffbe1 	cbz	w1, 8094 <fwp_caps23+0x24>
    811c:	f9400bf3 	ldr	x19, [sp, #16]
    8120:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8124:	d65f03c0 	ret
    8128:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    812c:	91154042 	add	x2, x2, #0x550
    8130:	f949d843 	ldr	x3, [x2, #5040]
    8134:	f949ec41 	ldr	x1, [x2, #5080]
    8138:	cb030000 	sub	x0, x0, x3
    813c:	eb01401f 	cmp	x0, x1, lsl #16
    8140:	54fffee2 	b.cs	811c <fwp_caps23+0xac>  // b.hs, b.nlast
    8144:	d350fc01 	lsr	x1, x0, #16
    8148:	f949fc44 	ldr	x4, [x2, #5112]
    814c:	8b010821 	add	x1, x1, x1, lsl #2
    8150:	d37df021 	lsl	x1, x1, #3
    8154:	8b010083 	add	x3, x4, x1
    8158:	f9401062 	ldr	x2, [x3, #32]
    815c:	b4fffe02 	cbz	x2, 811c <fwp_caps23+0xac>
    8160:	38616881 	ldrb	w1, [x4, x1]
    8164:	7100083f 	cmp	w1, #0x2
    8168:	54000280 	b.eq	81b8 <fwp_caps23+0x148>  // b.none
    816c:	7100043f 	cmp	w1, #0x1
    8170:	54fffd61 	b.ne	811c <fwp_caps23+0xac>  // b.any
    8174:	92403c01 	and	x1, x0, #0xffff
    8178:	29430064 	ldp	w4, w0, [x3, #24]
    817c:	9b047c21 	mul	x1, x1, x4
    8180:	d360fc21 	lsr	x1, x1, #32
    8184:	eb00003f 	cmp	x1, x0
    8188:	54fffca2 	b.cs	811c <fwp_caps23+0xac>  // b.hs, b.nlast
    818c:	8b010042 	add	x2, x2, x1
    8190:	39400040 	ldrb	w0, [x2]
    8194:	34fffc40 	cbz	w0, 811c <fwp_caps23+0xac>
    8198:	7103f41f 	cmp	w0, #0xfd
    819c:	54000148 	b.hi	81c4 <fwp_caps23+0x154>  // b.pmore
    81a0:	11000400 	add	w0, w0, #0x1
    81a4:	39000040 	strb	w0, [x2]
    81a8:	17ffffdd 	b	811c <fwp_caps23+0xac>
    81ac:	72003c1f 	tst	w0, #0xffff
    81b0:	54fffb61 	b.ne	811c <fwp_caps23+0xac>  // b.any
    81b4:	17ffffd2 	b	80fc <fwp_caps23+0x8c>
    81b8:	72003c1f 	tst	w0, #0xffff
    81bc:	54fffb01 	b.ne	811c <fwp_caps23+0xac>  // b.any
    81c0:	17fffff4 	b	8190 <fwp_caps23+0x120>
    81c4:	f9400bf3 	ldr	x19, [sp, #16]
    81c8:	aa0203e0 	mov	x0, x2
    81cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    81d0:	17fff081 	b	43d4 <fwp_rc_wide_dup>

00000000000081d4 <f23>:
    81d4:	d101c3ff 	sub	sp, sp, #0x70
    81d8:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    81dc:	f947f421 	ldr	x1, [x1, #4072]
    81e0:	a9027bfd 	stp	x29, x30, [sp, #32]
    81e4:	910083fd 	add	x29, sp, #0x20
    81e8:	a90563f7 	stp	x23, x24, [sp, #80]
    81ec:	b0000157 	adrp	x23, 31000 <fwp_root_context+0xc90>
    81f0:	911542e3 	add	x3, x23, #0x550
    81f4:	a90353f3 	stp	x19, x20, [sp, #48]
    81f8:	a9045bf5 	stp	x21, x22, [sp, #64]
    81fc:	aa0003f6 	mov	x22, x0
    8200:	a9066bf9 	stp	x25, x26, [sp, #96]
    8204:	f949ec62 	ldr	x2, [x3, #5080]
    8208:	f9400024 	ldr	x4, [x1]
    820c:	f9000fe4 	str	x4, [sp, #24]
    8210:	d2800004 	mov	x4, #0x0                   	// #0
    8214:	f949d861 	ldr	x1, [x3, #5040]
    8218:	d370bc42 	lsl	x2, x2, #16
    821c:	b40015a0 	cbz	x0, 84d0 <f23+0x2fc>
    8220:	f9400818 	ldr	x24, [x0, #16]
    8224:	cb010301 	sub	x1, x24, x1
    8228:	eb02003f 	cmp	x1, x2
    822c:	54000362 	b.cs	8298 <f23+0xc4>  // b.hs, b.nlast
    8230:	f949fc60 	ldr	x0, [x3, #5112]
    8234:	d350fc22 	lsr	x2, x1, #16
    8238:	8b020842 	add	x2, x2, x2, lsl #2
    823c:	8b020c02 	add	x2, x0, x2, lsl #3
    8240:	f9401040 	ldr	x0, [x2, #32]
    8244:	b40002a0 	cbz	x0, 8298 <f23+0xc4>
    8248:	39400043 	ldrb	w3, [x2]
    824c:	7100087f 	cmp	w3, #0x2
    8250:	540013a0 	b.eq	84c4 <f23+0x2f0>  // b.none
    8254:	7100047f 	cmp	w3, #0x1
    8258:	540001c1 	b.ne	8290 <f23+0xbc>  // b.any
    825c:	29430843 	ldp	w3, w2, [x2, #24]
    8260:	92403c21 	and	x1, x1, #0xffff
    8264:	9b037c21 	mul	x1, x1, x3
    8268:	d360fc21 	lsr	x1, x1, #32
    826c:	eb02003f 	cmp	x1, x2
    8270:	54000102 	b.cs	8290 <f23+0xbc>  // b.hs, b.nlast
    8274:	8b010000 	add	x0, x0, x1
    8278:	39400001 	ldrb	w1, [x0]
    827c:	340000a1 	cbz	w1, 8290 <f23+0xbc>
    8280:	7103f43f 	cmp	w1, #0xfd
    8284:	54001688 	b.hi	8554 <f23+0x380>  // b.pmore
    8288:	11000421 	add	w1, w1, #0x1
    828c:	39000001 	strb	w1, [x0]
    8290:	d2800000 	mov	x0, #0x0                   	// #0
    8294:	b40000d6 	cbz	x22, 82ac <f23+0xd8>
    8298:	aa1603e1 	mov	x1, x22
    829c:	d2800000 	mov	x0, #0x0                   	// #0
    82a0:	f9400821 	ldr	x1, [x1, #16]
    82a4:	91000400 	add	x0, x0, #0x1
    82a8:	b5ffffc1 	cbnz	x1, 82a0 <f23+0xcc>
    82ac:	b40011b8 	cbz	x24, 84e0 <f23+0x30c>
    82b0:	aa1803e1 	mov	x1, x24
    82b4:	d2800002 	mov	x2, #0x0                   	// #0
    82b8:	f9400821 	ldr	x1, [x1, #16]
    82bc:	91000442 	add	x2, x2, #0x1
    82c0:	b5ffffc1 	cbnz	x1, 82b8 <f23+0xe4>
    82c4:	eb00005f 	cmp	x2, x0
    82c8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    82cc:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    82d0:	eb01033f 	cmp	x25, x1
    82d4:	54001468 	b.hi	8560 <f23+0x38c>  // b.pmore
    82d8:	d37ffb33 	lsl	x19, x25, #1
    82dc:	52800041 	mov	w1, #0x2                   	// #2
    82e0:	91000660 	add	x0, x19, #0x1
    82e4:	d37df000 	lsl	x0, x0, #3
    82e8:	97fff242 	bl	4bf0 <fwp_heap_alloc>
    82ec:	911542e1 	add	x1, x23, #0x550
    82f0:	aa0003fa 	mov	x26, x0
    82f4:	f9000013 	str	x19, [x0]
    82f8:	aa0103e0 	mov	x0, x1
    82fc:	f949d821 	ldr	x1, [x1, #5040]
    8300:	f949ec00 	ldr	x0, [x0, #5080]
    8304:	cb010341 	sub	x1, x26, x1
    8308:	eb00403f 	cmp	x1, x0, lsl #16
    830c:	54000342 	b.cs	8374 <f23+0x1a0>  // b.hs, b.nlast
    8310:	911542e2 	add	x2, x23, #0x550
    8314:	d350fc20 	lsr	x0, x1, #16
    8318:	8b000800 	add	x0, x0, x0, lsl #2
    831c:	f949fc43 	ldr	x3, [x2, #5112]
    8320:	d37df002 	lsl	x2, x0, #3
    8324:	8b020060 	add	x0, x3, x2
    8328:	f9401013 	ldr	x19, [x0, #32]
    832c:	b4000253 	cbz	x19, 8374 <f23+0x1a0>
    8330:	38626862 	ldrb	w2, [x3, x2]
    8334:	7100085f 	cmp	w2, #0x2
    8338:	54000c00 	b.eq	84b8 <f23+0x2e4>  // b.none
    833c:	7100045f 	cmp	w2, #0x1
    8340:	540001a1 	b.ne	8374 <f23+0x1a0>  // b.any
    8344:	29430002 	ldp	w2, w0, [x0, #24]
    8348:	92403c21 	and	x1, x1, #0xffff
    834c:	9b027c21 	mul	x1, x1, x2
    8350:	d360fc21 	lsr	x1, x1, #32
    8354:	eb00003f 	cmp	x1, x0
    8358:	540000e2 	b.cs	8374 <f23+0x1a0>  // b.hs, b.nlast
    835c:	8b010273 	add	x19, x19, x1
    8360:	39400260 	ldrb	w0, [x19]
    8364:	7103fc1f 	cmp	w0, #0xff
    8368:	54000da0 	b.eq	851c <f23+0x348>  // b.none
    836c:	52800020 	mov	w0, #0x1                   	// #1
    8370:	39000260 	strb	w0, [x19]
    8374:	b4000259 	cbz	x25, 83bc <f23+0x1e8>
    8378:	8b191359 	add	x25, x26, x25, lsl #4
    837c:	aa1a03f3 	mov	x19, x26
    8380:	aa1603f5 	mov	x21, x22
    8384:	aa1803f4 	mov	x20, x24
    8388:	f9400683 	ldr	x3, [x20, #8]
    838c:	f94006a2 	ldr	x2, [x21, #8]
    8390:	f9400861 	ldr	x1, [x3, #16]
    8394:	f9400840 	ldr	x0, [x2, #16]
    8398:	fd400461 	ldr	d1, [x3, #8]
    839c:	fd400440 	ldr	d0, [x2, #8]
    83a0:	97fff3c4 	bl	52b0 <w107>
    83a4:	f9000660 	str	x0, [x19, #8]
    83a8:	f8010e61 	str	x1, [x19, #16]!
    83ac:	f9400a94 	ldr	x20, [x20, #16]
    83b0:	f9400ab5 	ldr	x21, [x21, #16]
    83b4:	eb13033f 	cmp	x25, x19
    83b8:	54fffe81 	b.ne	8388 <f23+0x1b4>  // b.any
    83bc:	aa1803e0 	mov	x0, x24
    83c0:	97fffe91 	bl	7e04 <fwp_drop2>
    83c4:	aa1603e0 	mov	x0, x22
    83c8:	97fffe8f 	bl	7e04 <fwp_drop2>
    83cc:	911542f7 	add	x23, x23, #0x550
    83d0:	aa1a03e0 	mov	x0, x26
    83d4:	97fff414 	bl	5424 <w164.constprop.0>
    83d8:	aa0103f3 	mov	x19, x1
    83dc:	aa0003f4 	mov	x20, x0
    83e0:	aa1a03e0 	mov	x0, x26
    83e4:	97fff8bf 	bl	66e0 <fwp_drop4>
    83e8:	a900cff4 	stp	x20, x19, [sp, #8]
    83ec:	910023e1 	add	x1, sp, #0x8
    83f0:	52800000 	mov	w0, #0x0                   	// #0
    83f4:	97fff434 	bl	54c4 <fwp_data.part.0.constprop.0>
    83f8:	f949dae1 	ldr	x1, [x23, #5040]
    83fc:	aa0003f3 	mov	x19, x0
    8400:	f949eee0 	ldr	x0, [x23, #5080]
    8404:	cb010261 	sub	x1, x19, x1
    8408:	eb00403f 	cmp	x1, x0, lsl #16
    840c:	54000322 	b.cs	8470 <f23+0x29c>  // b.hs, b.nlast
    8410:	d350fc22 	lsr	x2, x1, #16
    8414:	f949fee3 	ldr	x3, [x23, #5112]
    8418:	8b020842 	add	x2, x2, x2, lsl #2
    841c:	d37df042 	lsl	x2, x2, #3
    8420:	8b020060 	add	x0, x3, x2
    8424:	f9401014 	ldr	x20, [x0, #32]
    8428:	b4000254 	cbz	x20, 8470 <f23+0x29c>
    842c:	38626862 	ldrb	w2, [x3, x2]
    8430:	7100085f 	cmp	w2, #0x2
    8434:	540003c0 	b.eq	84ac <f23+0x2d8>  // b.none
    8438:	7100045f 	cmp	w2, #0x1
    843c:	540001a1 	b.ne	8470 <f23+0x29c>  // b.any
    8440:	29430002 	ldp	w2, w0, [x0, #24]
    8444:	92403c21 	and	x1, x1, #0xffff
    8448:	9b027c21 	mul	x1, x1, x2
    844c:	d360fc21 	lsr	x1, x1, #32
    8450:	eb00003f 	cmp	x1, x0
    8454:	540000e2 	b.cs	8470 <f23+0x29c>  // b.hs, b.nlast
    8458:	8b010294 	add	x20, x20, x1
    845c:	39400280 	ldrb	w0, [x20]
    8460:	7103fc1f 	cmp	w0, #0xff
    8464:	54000620 	b.eq	8528 <f23+0x354>  // b.none
    8468:	52800020 	mov	w0, #0x1                   	// #1
    846c:	39000280 	strb	w0, [x20]
    8470:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8474:	f947f400 	ldr	x0, [x0, #4072]
    8478:	f9400fe2 	ldr	x2, [sp, #24]
    847c:	f9400001 	ldr	x1, [x0]
    8480:	eb010042 	subs	x2, x2, x1
    8484:	d2800001 	mov	x1, #0x0                   	// #0
    8488:	540006a1 	b.ne	855c <f23+0x388>  // b.any
    848c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    8490:	aa1303e0 	mov	x0, x19
    8494:	a94353f3 	ldp	x19, x20, [sp, #48]
    8498:	a9445bf5 	ldp	x21, x22, [sp, #64]
    849c:	a94563f7 	ldp	x23, x24, [sp, #80]
    84a0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    84a4:	9101c3ff 	add	sp, sp, #0x70
    84a8:	d65f03c0 	ret
    84ac:	72003c3f 	tst	w1, #0xffff
    84b0:	54fffe01 	b.ne	8470 <f23+0x29c>  // b.any
    84b4:	17ffffea 	b	845c <f23+0x288>
    84b8:	72003c3f 	tst	w1, #0xffff
    84bc:	54fff5c1 	b.ne	8374 <f23+0x1a0>  // b.any
    84c0:	17ffffa8 	b	8360 <f23+0x18c>
    84c4:	72003c3f 	tst	w1, #0xffff
    84c8:	54ffee41 	b.ne	8290 <f23+0xbc>  // b.any
    84cc:	17ffff6b 	b	8278 <f23+0xa4>
    84d0:	cb0103e1 	neg	x1, x1
    84d4:	eb02003f 	cmp	x1, x2
    84d8:	540002e3 	b.cc	8534 <f23+0x360>  // b.lo, b.ul, b.last
    84dc:	d503201f 	nop
    84e0:	52800041 	mov	w1, #0x2                   	// #2
    84e4:	d2800100 	mov	x0, #0x8                   	// #8
    84e8:	97fff1c2 	bl	4bf0 <fwp_heap_alloc>
    84ec:	aa0003e1 	mov	x1, x0
    84f0:	911542e0 	add	x0, x23, #0x550
    84f4:	aa0103fa 	mov	x26, x1
    84f8:	d2800018 	mov	x24, #0x0                   	// #0
    84fc:	f900003f 	str	xzr, [x1]
    8500:	f949d801 	ldr	x1, [x0, #5040]
    8504:	f949ec00 	ldr	x0, [x0, #5080]
    8508:	cb010341 	sub	x1, x26, x1
    850c:	eb00403f 	cmp	x1, x0, lsl #16
    8510:	54fff562 	b.cs	83bc <f23+0x1e8>  // b.hs, b.nlast
    8514:	d2800019 	mov	x25, #0x0                   	// #0
    8518:	17ffff7e 	b	8310 <f23+0x13c>
    851c:	aa1303e0 	mov	x0, x19
    8520:	97ffeff4 	bl	44f0 <fwp_rc_forget_slot>
    8524:	17ffff92 	b	836c <f23+0x198>
    8528:	aa1403e0 	mov	x0, x20
    852c:	97ffeff1 	bl	44f0 <fwp_rc_forget_slot>
    8530:	17ffffce 	b	8468 <f23+0x294>
    8534:	f949fc62 	ldr	x2, [x3, #5112]
    8538:	d350fc20 	lsr	x0, x1, #16
    853c:	8b000800 	add	x0, x0, x0, lsl #2
    8540:	8b000c42 	add	x2, x2, x0, lsl #3
    8544:	f9401040 	ldr	x0, [x2, #32]
    8548:	b4fffcc0 	cbz	x0, 84e0 <f23+0x30c>
    854c:	d2800018 	mov	x24, #0x0                   	// #0
    8550:	17ffff3e 	b	8248 <f23+0x74>
    8554:	97ffefa0 	bl	43d4 <fwp_rc_wide_dup>
    8558:	17ffff4e 	b	8290 <f23+0xbc>
    855c:	97ffe8a5 	bl	27f0 <__stack_chk_fail@plt>
    8560:	f0000000 	adrp	x0, b000 <__modti3+0x30>
    8564:	911f6000 	add	x0, x0, #0x7d8
    8568:	97ffebe6 	bl	3500 <fwp_trap>
    856c:	d503201f 	nop

0000000000008570 <fwp_owned_entry23>:
    8570:	f9400000 	ldr	x0, [x0]
    8574:	17ffff18 	b	81d4 <f23>
    8578:	d503201f 	nop
    857c:	d503201f 	nop

0000000000008580 <e23>:
    8580:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8584:	910003fd 	mov	x29, sp
    8588:	f9000bf3 	str	x19, [sp, #16]
    858c:	f9400013 	ldr	x19, [x0]
    8590:	aa1303e0 	mov	x0, x19
    8594:	97fff414 	bl	55e4 <fwp_rc_share>
    8598:	aa1303e0 	mov	x0, x19
    859c:	97ffff0e 	bl	81d4 <f23>
    85a0:	aa0003f3 	mov	x19, x0
    85a4:	97fff410 	bl	55e4 <fwp_rc_share>
    85a8:	aa1303e0 	mov	x0, x19
    85ac:	f9400bf3 	ldr	x19, [sp, #16]
    85b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    85b4:	d65f03c0 	ret
    85b8:	d503201f 	nop
    85bc:	d503201f 	nop

00000000000085c0 <fwp_write>:
    85c0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    85c4:	910003fd 	mov	x29, sp
    85c8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    85cc:	f947f484 	ldr	x4, [x4, #4072]
    85d0:	a90153f3 	stp	x19, x20, [sp, #16]
    85d4:	d10943ff 	sub	sp, sp, #0x250
    85d8:	b9400045 	ldr	w5, [x2]
    85dc:	aa0003f4 	mov	x20, x0
    85e0:	f9400080 	ldr	x0, [x4]
    85e4:	f90127e0 	str	x0, [sp, #584]
    85e8:	d2800000 	mov	x0, #0x0                   	// #0
    85ec:	710064bf 	cmp	w5, #0x19
    85f0:	54000408 	b.hi	8670 <fwp_write+0xb0>  // b.pmore
    85f4:	f0000000 	adrp	x0, b000 <__modti3+0x30>
    85f8:	aa0103f3 	mov	x19, x1
    85fc:	913e8000 	add	x0, x0, #0xfa0
    8600:	f9013bf5 	str	x21, [sp, #624]
    8604:	f9013ff6 	str	x22, [sp, #632]
    8608:	f90153fb 	str	x27, [sp, #672]
    860c:	f90157fc 	str	x28, [sp, #680]
    8610:	aa0203fc 	mov	x28, x2
    8614:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8618:	10000061 	adr	x1, 8624 <fwp_write+0x64>
    861c:	8b20a820 	add	x0, x1, w0, sxth #2
    8620:	d61f0000 	br	x0
    8624:	910123e0 	add	x0, sp, #0x48
    8628:	aa1303e5 	mov	x5, x19
    862c:	f0000004 	adrp	x4, b000 <__modti3+0x30>
    8630:	aa0003f3 	mov	x19, x0
    8634:	91216084 	add	x4, x4, #0x858
    8638:	d2804003 	mov	x3, #0x200                 	// #512
    863c:	aa0303e1 	mov	x1, x3
    8640:	52800042 	mov	w2, #0x2                   	// #2
    8644:	97ffe847 	bl	2760 <__snprintf_chk@plt>
    8648:	aa1303e0 	mov	x0, x19
    864c:	97ffe80d 	bl	2680 <strlen@plt>
    8650:	aa1303e1 	mov	x1, x19
    8654:	aa0003e2 	mov	x2, x0
    8658:	aa1403e0 	mov	x0, x20
    865c:	97ffeb4d 	bl	3390 <buf_put>
    8660:	f9413bf5 	ldr	x21, [sp, #624]
    8664:	f9413ff6 	ldr	x22, [sp, #632]
    8668:	f94153fb 	ldr	x27, [sp, #672]
    866c:	f94157fc 	ldr	x28, [sp, #680]
    8670:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8674:	f947f400 	ldr	x0, [x0, #4072]
    8678:	f94127e2 	ldr	x2, [sp, #584]
    867c:	f9400001 	ldr	x1, [x0]
    8680:	eb010042 	subs	x2, x2, x1
    8684:	d2800001 	mov	x1, #0x0                   	// #0
    8688:	540077c1 	b.ne	9580 <fwp_write+0xfc0>  // b.any
    868c:	910943ff 	add	sp, sp, #0x250
    8690:	a94153f3 	ldp	x19, x20, [sp, #16]
    8694:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8698:	d65f03c0 	ret
    869c:	910123e0 	add	x0, sp, #0x48
    86a0:	aa1303e5 	mov	x5, x19
    86a4:	f0000004 	adrp	x4, b000 <__modti3+0x30>
    86a8:	aa0003f3 	mov	x19, x0
    86ac:	91214084 	add	x4, x4, #0x850
    86b0:	d2804003 	mov	x3, #0x200                 	// #512
    86b4:	17ffffe2 	b	863c <fwp_write+0x7c>
    86b8:	71004cbf 	cmp	w5, #0x13
    86bc:	f0000000 	adrp	x0, b000 <__modti3+0x30>
    86c0:	f0000001 	adrp	x1, b000 <__modti3+0x30>
    86c4:	91210000 	add	x0, x0, #0x840
    86c8:	91212021 	add	x1, x1, #0x848
    86cc:	d2800082 	mov	x2, #0x4                   	// #4
    86d0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    86d4:	aa1403e0 	mov	x0, x20
    86d8:	f90143f7 	str	x23, [sp, #640]
    86dc:	d2800016 	mov	x22, #0x0                   	// #0
    86e0:	f90147f8 	str	x24, [sp, #648]
    86e4:	97ffeb2b 	bl	3390 <buf_put>
    86e8:	f9400260 	ldr	x0, [x19]
    86ec:	f0000017 	adrp	x23, b000 <__modti3+0x30>
    86f0:	d2800015 	mov	x21, #0x0                   	// #0
    86f4:	912322f7 	add	x23, x23, #0x8c8
    86f8:	b40047a0 	cbz	x0, 8fec <fwp_write+0xa2c>
    86fc:	b9400380 	ldr	w0, [x28]
    8700:	52800003 	mov	w3, #0x0                   	// #0
    8704:	f9401f82 	ldr	x2, [x28, #56]
    8708:	71004c1f 	cmp	w0, #0x13
    870c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8710:	aa1403e0 	mov	x0, x20
    8714:	8b010e61 	add	x1, x19, x1, lsl #3
    8718:	f9400421 	ldr	x1, [x1, #8]
    871c:	97ffffa9 	bl	85c0 <fwp_write>
    8720:	b9400380 	ldr	w0, [x28]
    8724:	7100481f 	cmp	w0, #0x12
    8728:	54004b40 	b.eq	9090 <fwp_write+0xad0>  // b.none
    872c:	f9400260 	ldr	x0, [x19]
    8730:	910006b5 	add	x21, x21, #0x1
    8734:	91000ad6 	add	x22, x22, #0x2
    8738:	eb15001f 	cmp	x0, x21
    873c:	54004589 	b.ls	8fec <fwp_write+0xa2c>  // b.plast
    8740:	aa1703e1 	mov	x1, x23
    8744:	aa1403e0 	mov	x0, x20
    8748:	d2800042 	mov	x2, #0x2                   	// #2
    874c:	97ffeb11 	bl	3390 <buf_put>
    8750:	17ffffeb 	b	86fc <fwp_write+0x13c>
    8754:	f0000001 	adrp	x1, b000 <__modti3+0x30>
    8758:	91220021 	add	x1, x1, #0x880
    875c:	d28000c2 	mov	x2, #0x6                   	// #6
    8760:	aa1403e0 	mov	x0, x20
    8764:	91004273 	add	x19, x19, #0x10
    8768:	97ffeb0a 	bl	3390 <buf_put>
    876c:	aa1303e0 	mov	x0, x19
    8770:	97ffe7c4 	bl	2680 <strlen@plt>
    8774:	aa1303e1 	mov	x1, x19
    8778:	aa0003e2 	mov	x2, x0
    877c:	aa1403e0 	mov	x0, x20
    8780:	97ffeb04 	bl	3390 <buf_put>
    8784:	528007c3 	mov	w3, #0x3e                  	// #62
    8788:	aa1403e0 	mov	x0, x20
    878c:	91001fe1 	add	x1, sp, #0x7
    8790:	d2800022 	mov	x2, #0x1                   	// #1
    8794:	39001fe3 	strb	w3, [sp, #7]
    8798:	17ffffb1 	b	865c <fwp_write+0x9c>
    879c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    87a0:	f947f400 	ldr	x0, [x0, #4072]
    87a4:	f94127e2 	ldr	x2, [sp, #584]
    87a8:	f9400001 	ldr	x1, [x0]
    87ac:	eb010042 	subs	x2, x2, x1
    87b0:	d2800001 	mov	x1, #0x0                   	// #0
    87b4:	540034e1 	b.ne	8e50 <fwp_write+0x890>  // b.any
    87b8:	f9413bf5 	ldr	x21, [sp, #624]
    87bc:	f0000001 	adrp	x1, b000 <__modti3+0x30>
    87c0:	f9413ff6 	ldr	x22, [sp, #632]
    87c4:	aa1403e0 	mov	x0, x20
    87c8:	91218021 	add	x1, x1, #0x860
    87cc:	d2800142 	mov	x2, #0xa                   	// #10
    87d0:	f94153fb 	ldr	x27, [sp, #672]
    87d4:	f94157fc 	ldr	x28, [sp, #680]
    87d8:	910943ff 	add	sp, sp, #0x250
    87dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    87e0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    87e4:	17ffeaeb 	b	3390 <buf_put>
    87e8:	f9400456 	ldr	x22, [x2, #8]
    87ec:	f90143f7 	str	x23, [sp, #640]
    87f0:	f90147f8 	str	x24, [sp, #648]
    87f4:	b4005b16 	cbz	x22, 9354 <fwp_write+0xd94>
    87f8:	aa1603e0 	mov	x0, x22
    87fc:	f0000001 	adrp	x1, b000 <__modti3+0x30>
    8800:	91238021 	add	x1, x1, #0x8e0
    8804:	97ffe81b 	bl	2870 <strcmp@plt>
    8808:	2a0003f5 	mov	w21, w0
    880c:	34005fe0 	cbz	w0, 9408 <fwp_write+0xe48>
    8810:	aa1603e0 	mov	x0, x22
    8814:	97ffe79b 	bl	2680 <strlen@plt>
    8818:	aa1603e1 	mov	x1, x22
    881c:	aa0003e2 	mov	x2, x0
    8820:	aa1403e0 	mov	x0, x20
    8824:	97ffeadb 	bl	3390 <buf_put>
    8828:	52800403 	mov	w3, #0x20                  	// #32
    882c:	91001ff5 	add	x21, sp, #0x7
    8830:	aa1503e1 	mov	x1, x21
    8834:	aa1403e0 	mov	x0, x20
    8838:	d2800022 	mov	x2, #0x1                   	// #1
    883c:	39001fe3 	strb	w3, [sp, #7]
    8840:	97ffead4 	bl	3390 <buf_put>
    8844:	52800f63 	mov	w3, #0x7b                  	// #123
    8848:	aa1403e0 	mov	x0, x20
    884c:	aa1503e1 	mov	x1, x21
    8850:	d2800022 	mov	x2, #0x1                   	// #1
    8854:	39001fe3 	strb	w3, [sp, #7]
    8858:	97ffeace 	bl	3390 <buf_put>
    885c:	b9401380 	ldr	w0, [x28, #16]
    8860:	52800018 	mov	w24, #0x0                   	// #0
    8864:	7100001f 	cmp	w0, #0x0
    8868:	54003aad 	b.le	8fbc <fwp_write+0x9fc>
    886c:	f9014bf9 	str	x25, [sp, #656]
    8870:	f0000019 	adrp	x25, b000 <__modti3+0x30>
    8874:	91242339 	add	x25, x25, #0x908
    8878:	f9014ffa 	str	x26, [sp, #664]
    887c:	f000001a 	adrp	x26, b000 <__modti3+0x30>
    8880:	9123235a 	add	x26, x26, #0x8c8
    8884:	91002276 	add	x22, x19, #0x8
    8888:	d2800013 	mov	x19, #0x0                   	// #0
    888c:	b5003e93 	cbnz	x19, 905c <fwp_write+0xa9c>
    8890:	d37df277 	lsl	x23, x19, #3
    8894:	34003cb8 	cbz	w24, 9028 <fwp_write+0xa68>
    8898:	f9401382 	ldr	x2, [x28, #32]
    889c:	aa1403e0 	mov	x0, x20
    88a0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    88a4:	52800003 	mov	w3, #0x0                   	// #0
    88a8:	f8776842 	ldr	x2, [x2, x23]
    88ac:	91000673 	add	x19, x19, #0x1
    88b0:	97ffff44 	bl	85c0 <fwp_write>
    88b4:	b9401380 	ldr	w0, [x28, #16]
    88b8:	6b13001f 	cmp	w0, w19
    88bc:	54fffe8c 	b.gt	888c <fwp_write+0x2cc>
    88c0:	f9414bf9 	ldr	x25, [sp, #656]
    88c4:	f9414ffa 	ldr	x26, [sp, #664]
    88c8:	340037b8 	cbz	w24, 8fbc <fwp_write+0x9fc>
    88cc:	52800523 	mov	w3, #0x29                  	// #41
    88d0:	aa1503e1 	mov	x1, x21
    88d4:	aa1403e0 	mov	x0, x20
    88d8:	d2800022 	mov	x2, #0x1                   	// #1
    88dc:	39001fe3 	strb	w3, [sp, #7]
    88e0:	97ffeaac 	bl	3390 <buf_put>
    88e4:	f9413bf5 	ldr	x21, [sp, #624]
    88e8:	f9413ff6 	ldr	x22, [sp, #632]
    88ec:	f94143f7 	ldr	x23, [sp, #640]
    88f0:	f94147f8 	ldr	x24, [sp, #648]
    88f4:	f94153fb 	ldr	x27, [sp, #672]
    88f8:	f94157fc 	ldr	x28, [sp, #680]
    88fc:	17ffff5d 	b	8670 <fwp_write+0xb0>
    8900:	b9404855 	ldr	w21, [x2, #72]
    8904:	aa1403e0 	mov	x0, x20
    8908:	93407eb6 	sxtw	x22, w21
    890c:	91000ac1 	add	x1, x22, #0x2
    8910:	97ffea6d 	bl	32c4 <buf_grow>
    8914:	a9400281 	ldp	x1, x0, [x20]
    8918:	528e8603 	mov	w3, #0x7430                	// #29744
    891c:	78206823 	strh	w3, [x1, x0]
    8920:	8b000022 	add	x2, x1, x0
    8924:	710002bf 	cmp	w21, #0x0
    8928:	540036cd 	b.le	9000 <fwp_write+0xa40>
    892c:	110006a3 	add	w3, w21, #0x1
    8930:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8934:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8938:	91000449 	add	x9, x2, #0x1
    893c:	8b23c043 	add	x3, x2, w3, sxtw
    8940:	f28aaac6 	movk	x6, #0x5556
    8944:	f2955568 	movk	x8, #0xaaab
    8948:	1400000d 	b	897c <fwp_write+0x3bc>
    894c:	d2800021 	mov	x1, #0x1                   	// #1
    8950:	528005a5 	mov	w5, #0x2d                  	// #45
    8954:	f100001f 	cmp	x0, #0x0
    8958:	9b467e60 	smulh	x0, x19, x6
    895c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8960:	381ff465 	strb	w5, [x3], #-1
    8964:	cb040000 	sub	x0, x0, x4
    8968:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    896c:	cb020000 	sub	x0, x0, x2
    8970:	8b010013 	add	x19, x0, x1
    8974:	eb03013f 	cmp	x9, x3
    8978:	54003440 	b.eq	9000 <fwp_write+0xa40>  // b.none
    897c:	9b467e60 	smulh	x0, x19, x6
    8980:	937ffe64 	asr	x4, x19, #63
    8984:	52800605 	mov	w5, #0x30                  	// #48
    8988:	cb040000 	sub	x0, x0, x4
    898c:	8b000400 	add	x0, x0, x0, lsl #1
    8990:	cb000260 	sub	x0, x19, x0
    8994:	91000c01 	add	x1, x0, #0x3
    8998:	9bc87c22 	umulh	x2, x1, x8
    899c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    89a0:	8b4204e2 	add	x2, x7, x2, lsr #1
    89a4:	eb020021 	subs	x1, x1, x2
    89a8:	54fffd60 	b.eq	8954 <fwp_write+0x394>  // b.none
    89ac:	f100043f 	cmp	x1, #0x1
    89b0:	54fffce1 	b.ne	894c <fwp_write+0x38c>  // b.any
    89b4:	d2800001 	mov	x1, #0x0                   	// #0
    89b8:	52800565 	mov	w5, #0x2b                  	// #43
    89bc:	17ffffe6 	b	8954 <fwp_write+0x394>
    89c0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    89c4:	f947f400 	ldr	x0, [x0, #4072]
    89c8:	f94127e2 	ldr	x2, [sp, #584]
    89cc:	f9400001 	ldr	x1, [x0]
    89d0:	eb010042 	subs	x2, x2, x1
    89d4:	d2800001 	mov	x1, #0x0                   	// #0
    89d8:	540023c1 	b.ne	8e50 <fwp_write+0x890>  // b.any
    89dc:	f9413bf5 	ldr	x21, [sp, #624]
    89e0:	f0000001 	adrp	x1, b000 <__modti3+0x30>
    89e4:	f9413ff6 	ldr	x22, [sp, #632]
    89e8:	aa1403e0 	mov	x0, x20
    89ec:	9121c021 	add	x1, x1, #0x870
    89f0:	d2800102 	mov	x2, #0x8                   	// #8
    89f4:	17ffff77 	b	87d0 <fwp_write+0x210>
    89f8:	aa1403e0 	mov	x0, x20
    89fc:	f0000001 	adrp	x1, b000 <__modti3+0x30>
    8a00:	d28000c2 	mov	x2, #0x6                   	// #6
    8a04:	91234021 	add	x1, x1, #0x8d0
    8a08:	97ffea62 	bl	3390 <buf_put>
    8a0c:	d2800015 	mov	x21, #0x0                   	// #0
    8a10:	f9400263 	ldr	x3, [x19]
    8a14:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8a18:	54002c60 	b.eq	8fa4 <fwp_write+0x9e4>  // b.none
    8a1c:	f9401f82 	ldr	x2, [x28, #56]
    8a20:	f90143f7 	str	x23, [sp, #640]
    8a24:	f90147f8 	str	x24, [sp, #648]
    8a28:	d2800857 	mov	x23, #0x42                  	// #66
    8a2c:	f9014bf9 	str	x25, [sp, #656]
    8a30:	f0000016 	adrp	x22, b000 <__modti3+0x30>
    8a34:	f9014ffa 	str	x26, [sp, #664]
    8a38:	912322d6 	add	x22, x22, #0x8c8
    8a3c:	d2800038 	mov	x24, #0x1                   	// #1
    8a40:	f2a18017 	movk	x23, #0xc00, lsl #16
    8a44:	d2809099 	mov	x25, #0x484                 	// #1156
    8a48:	b40004a2 	cbz	x2, 8adc <fwp_write+0x51c>
    8a4c:	b9400040 	ldr	w0, [x2]
    8a50:	7100701f 	cmp	w0, #0x1c
    8a54:	540042c0 	b.eq	92ac <fwp_write+0xcec>  // b.none
    8a58:	71006c1f 	cmp	w0, #0x1b
    8a5c:	54000408 	b.hi	8adc <fwp_write+0x51c>  // b.pmore
    8a60:	9ac02301 	lsl	x1, x24, x0
    8a64:	ea17003f 	tst	x1, x23
    8a68:	540036a1 	b.ne	913c <fwp_write+0xb7c>  // b.any
    8a6c:	ea19003f 	tst	x1, x25
    8a70:	54003521 	b.ne	9114 <fwp_write+0xb54>  // b.any
    8a74:	d2800424 	mov	x4, #0x21                  	// #33
    8a78:	ea04003f 	tst	x1, x4
    8a7c:	54000300 	b.eq	8adc <fwp_write+0x51c>  // b.none
    8a80:	b7f849c3 	tbnz	x3, #63, 93b8 <fwp_write+0xdf8>
    8a84:	91002261 	add	x1, x19, #0x8
    8a88:	8b150021 	add	x1, x1, x21
    8a8c:	39400021 	ldrb	w1, [x1]
    8a90:	7100001f 	cmp	w0, #0x0
    8a94:	93401c23 	sxtb	x3, w1
    8a98:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8a9c:	d503201f 	nop
    8aa0:	aa1403e0 	mov	x0, x20
    8aa4:	52800003 	mov	w3, #0x0                   	// #0
    8aa8:	97fffec6 	bl	85c0 <fwp_write>
    8aac:	910006b5 	add	x21, x21, #0x1
    8ab0:	f9400260 	ldr	x0, [x19]
    8ab4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8ab8:	eb0002bf 	cmp	x21, x0
    8abc:	540026c2 	b.cs	8f94 <fwp_write+0x9d4>  // b.hs, b.nlast
    8ac0:	d2800042 	mov	x2, #0x2                   	// #2
    8ac4:	aa1603e1 	mov	x1, x22
    8ac8:	aa1403e0 	mov	x0, x20
    8acc:	97ffea31 	bl	3390 <buf_put>
    8ad0:	f9401f82 	ldr	x2, [x28, #56]
    8ad4:	f9400263 	ldr	x3, [x19]
    8ad8:	b5fffba2 	cbnz	x2, 8a4c <fwp_write+0x48c>
    8adc:	d37df2a0 	lsl	x0, x21, #3
    8ae0:	b7f83f03 	tbnz	x3, #63, 92c0 <fwp_write+0xd00>
    8ae4:	91002261 	add	x1, x19, #0x8
    8ae8:	8b000020 	add	x0, x1, x0
    8aec:	f9400001 	ldr	x1, [x0]
    8af0:	17ffffec 	b	8aa0 <fwp_write+0x4e0>
    8af4:	a9400e62 	ldp	x2, x3, [x19]
    8af8:	b7f83ca3 	tbnz	x3, #63, 928c <fwp_write+0xccc>
    8afc:	910123f5 	add	x21, sp, #0x48
    8b00:	aa1503e0 	mov	x0, x21
    8b04:	97ffe8a7 	bl	2da0 <fwp_fmt_u128>
    8b08:	aa1503e0 	mov	x0, x21
    8b0c:	97ffe6dd 	bl	2680 <strlen@plt>
    8b10:	aa1503e1 	mov	x1, x21
    8b14:	aa0003e2 	mov	x2, x0
    8b18:	17fffed0 	b	8658 <fwp_write+0x98>
    8b1c:	fd015be8 	str	d8, [sp, #688]
    8b20:	1e270268 	fmov	s8, w19
    8b24:	fd015fe9 	str	d9, [sp, #696]
    8b28:	1e282100 	fcmp	s8, s8
    8b2c:	54004d26 	b.vs	94d0 <fwp_write+0xf10>
    8b30:	1e20c101 	fabs	s1, s8
    8b34:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8b38:	1e270000 	fmov	s0, w0
    8b3c:	1e202020 	fcmp	s1, s0
    8b40:	54002c0d 	b.le	90c0 <fwp_write+0xb00>
    8b44:	1e202118 	fcmpe	s8, #0.0
    8b48:	f0000002 	adrp	x2, b000 <__modti3+0x30>
    8b4c:	910e4042 	add	x2, x2, #0x390
    8b50:	910123f5 	add	x21, sp, #0x48
    8b54:	f0000001 	adrp	x1, b000 <__modti3+0x30>
    8b58:	91208021 	add	x1, x1, #0x820
    8b5c:	aa1503e0 	mov	x0, x21
    8b60:	9a81c041 	csel	x1, x2, x1, gt
    8b64:	97ffe773 	bl	2930 <strcpy@plt>
    8b68:	aa1503e0 	mov	x0, x21
    8b6c:	97ffe6c5 	bl	2680 <strlen@plt>
    8b70:	aa1503e1 	mov	x1, x21
    8b74:	aa0003e2 	mov	x2, x0
    8b78:	aa1403e0 	mov	x0, x20
    8b7c:	97ffea05 	bl	3390 <buf_put>
    8b80:	f9413bf5 	ldr	x21, [sp, #624]
    8b84:	f9413ff6 	ldr	x22, [sp, #632]
    8b88:	f94153fb 	ldr	x27, [sp, #672]
    8b8c:	f94157fc 	ldr	x28, [sp, #680]
    8b90:	fd415be8 	ldr	d8, [sp, #688]
    8b94:	fd415fe9 	ldr	d9, [sp, #696]
    8b98:	17fffeb6 	b	8670 <fwp_write+0xb0>
    8b9c:	f9400276 	ldr	x22, [x19]
    8ba0:	34002e03 	cbz	w3, 9160 <fwp_write+0xba0>
    8ba4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ba8:	f947f400 	ldr	x0, [x0, #4072]
    8bac:	f94127e2 	ldr	x2, [sp, #584]
    8bb0:	f9400001 	ldr	x1, [x0]
    8bb4:	eb010042 	subs	x2, x2, x1
    8bb8:	d2800001 	mov	x1, #0x0                   	// #0
    8bbc:	540014a1 	b.ne	8e50 <fwp_write+0x890>  // b.any
    8bc0:	aa1603e2 	mov	x2, x22
    8bc4:	91002261 	add	x1, x19, #0x8
    8bc8:	f9413bf5 	ldr	x21, [sp, #624]
    8bcc:	aa1403e0 	mov	x0, x20
    8bd0:	f9413ff6 	ldr	x22, [sp, #632]
    8bd4:	17fffeff 	b	87d0 <fwp_write+0x210>
    8bd8:	fd015be8 	str	d8, [sp, #688]
    8bdc:	9e670268 	fmov	d8, x19
    8be0:	fd015fe9 	str	d9, [sp, #696]
    8be4:	1e682100 	fcmp	d8, d8
    8be8:	54004746 	b.vs	94d0 <fwp_write+0xf10>
    8bec:	1e60c101 	fabs	d1, d8
    8bf0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8bf4:	9e670000 	fmov	d0, x0
    8bf8:	910123f5 	add	x21, sp, #0x48
    8bfc:	52800033 	mov	w19, #0x1                   	// #1
    8c00:	1e602020 	fcmp	d1, d0
    8c04:	540001ad 	b.le	8c38 <fwp_write+0x678>
    8c08:	1e602118 	fcmpe	d8, #0.0
    8c0c:	f0000002 	adrp	x2, b000 <__modti3+0x30>
    8c10:	910e4042 	add	x2, x2, #0x390
    8c14:	f0000001 	adrp	x1, b000 <__modti3+0x30>
    8c18:	91208021 	add	x1, x1, #0x820
    8c1c:	aa1503e0 	mov	x0, x21
    8c20:	9a81c041 	csel	x1, x2, x1, gt
    8c24:	97ffe743 	bl	2930 <strcpy@plt>
    8c28:	17ffffd0 	b	8b68 <fwp_write+0x5a8>
    8c2c:	11000673 	add	w19, w19, #0x1
    8c30:	71004a7f 	cmp	w19, #0x12
    8c34:	54003860 	b.eq	9340 <fwp_write+0xd80>  // b.none
    8c38:	1e604100 	fmov	d0, d8
    8c3c:	2a1303e1 	mov	w1, w19
    8c40:	aa1503e0 	mov	x0, x21
    8c44:	97ffeb14 	bl	3894 <fwp_format_g.constprop.0>
    8c48:	aa1503e0 	mov	x0, x21
    8c4c:	d2800001 	mov	x1, #0x0                   	// #0
    8c50:	97ffe6a0 	bl	26d0 <strtod@plt>
    8c54:	1e602100 	fcmp	d8, d0
    8c58:	54fffea1 	b.ne	8c2c <fwp_write+0x66c>  // b.any
    8c5c:	aa1503e0 	mov	x0, x21
    8c60:	97ffea05 	bl	3474 <fwp_finish_float>
    8c64:	17ffffc1 	b	8b68 <fwp_write+0x5a8>
    8c68:	a9400e62 	ldp	x2, x3, [x19]
    8c6c:	910123f3 	add	x19, sp, #0x48
    8c70:	aa1303e0 	mov	x0, x19
    8c74:	97ffe84b 	bl	2da0 <fwp_fmt_u128>
    8c78:	17fffe74 	b	8648 <fwp_write+0x88>
    8c7c:	f90143f7 	str	x23, [sp, #640]
    8c80:	f90147f8 	str	x24, [sp, #648]
    8c84:	2a1303f8 	mov	w24, w19
    8c88:	f9014bf9 	str	x25, [sp, #656]
    8c8c:	f9014ffa 	str	x26, [sp, #664]
    8c90:	f13ffe7f 	cmp	x19, #0xfff
    8c94:	54000049 	b.ls	8c9c <fwp_write+0x6dc>  // b.plast
    8c98:	b9400278 	ldr	w24, [x19]
    8c9c:	f9400f80 	ldr	x0, [x28, #24]
    8ca0:	2a1803f5 	mov	w21, w24
    8ca4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8ca8:	d37ef6b9 	lsl	x25, x21, #2
    8cac:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8cb0:	aa1603e0 	mov	x0, x22
    8cb4:	97ffe673 	bl	2680 <strlen@plt>
    8cb8:	aa1603e1 	mov	x1, x22
    8cbc:	aa0003e2 	mov	x2, x0
    8cc0:	aa1403e0 	mov	x0, x20
    8cc4:	97ffe9b3 	bl	3390 <buf_put>
    8cc8:	f9401780 	ldr	x0, [x28, #40]
    8ccc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8cd0:	7100001f 	cmp	w0, #0x0
    8cd4:	5400068d 	b.le	8da4 <fwp_write+0x7e4>
    8cd8:	91002276 	add	x22, x19, #0x8
    8cdc:	91001ff5 	add	x21, sp, #0x7
    8ce0:	d280001b 	mov	x27, #0x0                   	// #0
    8ce4:	5280041a 	mov	w26, #0x20                  	// #32
    8ce8:	f9401b80 	ldr	x0, [x28, #48]
    8cec:	aa1503e1 	mov	x1, x21
    8cf0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    8cf4:	d2800022 	mov	x2, #0x1                   	// #1
    8cf8:	f8786803 	ldr	x3, [x0, x24]
    8cfc:	aa1403e0 	mov	x0, x20
    8d00:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    8d04:	39001ffa 	strb	w26, [sp, #7]
    8d08:	97ffe9a2 	bl	3390 <buf_put>
    8d0c:	f13ffeff 	cmp	x23, #0xfff
    8d10:	b9400261 	ldr	w1, [x19]
    8d14:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8d18:	7100383f 	cmp	w1, #0xe
    8d1c:	54000160 	b.eq	8d48 <fwp_write+0x788>  // b.none
    8d20:	7100403f 	cmp	w1, #0x10
    8d24:	54001a60 	b.eq	9070 <fwp_write+0xab0>  // b.none
    8d28:	7100283f 	cmp	w1, #0xa
    8d2c:	54002aa0 	b.eq	9280 <fwp_write+0xcc0>  // b.none
    8d30:	540014ac 	b.gt	8fc4 <fwp_write+0xa04>
    8d34:	71000c3f 	cmp	w1, #0x3
    8d38:	540029ac 	b.gt	926c <fwp_write+0xcac>
    8d3c:	d37ffee0 	lsr	x0, x23, #63
    8d40:	37f814a1 	tbnz	w1, #31, 8fd4 <fwp_write+0xa14>
    8d44:	d503201f 	nop
    8d48:	34001460 	cbz	w0, 8fd4 <fwp_write+0xa14>
    8d4c:	52800503 	mov	w3, #0x28                  	// #40
    8d50:	aa1503e1 	mov	x1, x21
    8d54:	aa1403e0 	mov	x0, x20
    8d58:	d2800022 	mov	x2, #0x1                   	// #1
    8d5c:	39001fe3 	strb	w3, [sp, #7]
    8d60:	97ffe98c 	bl	3390 <buf_put>
    8d64:	aa1303e2 	mov	x2, x19
    8d68:	aa1703e1 	mov	x1, x23
    8d6c:	aa1403e0 	mov	x0, x20
    8d70:	52800003 	mov	w3, #0x0                   	// #0
    8d74:	97fffe13 	bl	85c0 <fwp_write>
    8d78:	52800523 	mov	w3, #0x29                  	// #41
    8d7c:	aa1503e1 	mov	x1, x21
    8d80:	aa1403e0 	mov	x0, x20
    8d84:	d2800022 	mov	x2, #0x1                   	// #1
    8d88:	39001fe3 	strb	w3, [sp, #7]
    8d8c:	97ffe981 	bl	3390 <buf_put>
    8d90:	f9401780 	ldr	x0, [x28, #40]
    8d94:	9100077b 	add	x27, x27, #0x1
    8d98:	b8796800 	ldr	w0, [x0, x25]
    8d9c:	6b1b001f 	cmp	w0, w27
    8da0:	54fffa4c 	b.gt	8ce8 <fwp_write+0x728>
    8da4:	f9413bf5 	ldr	x21, [sp, #624]
    8da8:	f9413ff6 	ldr	x22, [sp, #632]
    8dac:	f94143f7 	ldr	x23, [sp, #640]
    8db0:	f94147f8 	ldr	x24, [sp, #648]
    8db4:	f9414bf9 	ldr	x25, [sp, #656]
    8db8:	f9414ffa 	ldr	x26, [sp, #664]
    8dbc:	f94153fb 	ldr	x27, [sp, #672]
    8dc0:	f94157fc 	ldr	x28, [sp, #680]
    8dc4:	17fffe2b 	b	8670 <fwp_write+0xb0>
    8dc8:	52800783 	mov	w3, #0x3c                  	// #60
    8dcc:	91001ff3 	add	x19, sp, #0x7
    8dd0:	aa1303e1 	mov	x1, x19
    8dd4:	d2800022 	mov	x2, #0x1                   	// #1
    8dd8:	aa1403e0 	mov	x0, x20
    8ddc:	39001fe3 	strb	w3, [sp, #7]
    8de0:	97ffe96c 	bl	3390 <buf_put>
    8de4:	f9400795 	ldr	x21, [x28, #8]
    8de8:	aa1503e0 	mov	x0, x21
    8dec:	97ffe625 	bl	2680 <strlen@plt>
    8df0:	aa1503e1 	mov	x1, x21
    8df4:	aa0003e2 	mov	x2, x0
    8df8:	aa1403e0 	mov	x0, x20
    8dfc:	97ffe965 	bl	3390 <buf_put>
    8e00:	528007c3 	mov	w3, #0x3e                  	// #62
    8e04:	aa1303e1 	mov	x1, x19
    8e08:	aa1403e0 	mov	x0, x20
    8e0c:	d2800022 	mov	x2, #0x1                   	// #1
    8e10:	39001fe3 	strb	w3, [sp, #7]
    8e14:	17fffe12 	b	865c <fwp_write+0x9c>
    8e18:	f100067f 	cmp	x19, #0x1
    8e1c:	540025a0 	b.eq	92d0 <fwp_write+0xd10>  // b.none
    8e20:	b100067f 	cmn	x19, #0x1
    8e24:	54002bc0 	b.eq	939c <fwp_write+0xddc>  // b.none
    8e28:	f0000001 	adrp	x1, b000 <__modti3+0x30>
    8e2c:	9120a021 	add	x1, x1, #0x828
    8e30:	d2800022 	mov	x2, #0x1                   	// #1
    8e34:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8e38:	f947f400 	ldr	x0, [x0, #4072]
    8e3c:	f94127e4 	ldr	x4, [sp, #584]
    8e40:	f9400003 	ldr	x3, [x0]
    8e44:	eb030084 	subs	x4, x4, x3
    8e48:	d2800003 	mov	x3, #0x0                   	// #0
    8e4c:	54ffebe0 	b.eq	8bc8 <fwp_write+0x608>  // b.none
    8e50:	f90143f7 	str	x23, [sp, #640]
    8e54:	f90147f8 	str	x24, [sp, #648]
    8e58:	f9014bf9 	str	x25, [sp, #656]
    8e5c:	f9014ffa 	str	x26, [sp, #664]
    8e60:	fd015be8 	str	d8, [sp, #688]
    8e64:	fd015fe9 	str	d9, [sp, #696]
    8e68:	97ffe662 	bl	27f0 <__stack_chk_fail@plt>
    8e6c:	52800b63 	mov	w3, #0x5b                  	// #91
    8e70:	91001ff5 	add	x21, sp, #0x7
    8e74:	aa1503e1 	mov	x1, x21
    8e78:	aa1403e0 	mov	x0, x20
    8e7c:	d2800022 	mov	x2, #0x1                   	// #1
    8e80:	f0000016 	adrp	x22, b000 <__modti3+0x30>
    8e84:	912322d6 	add	x22, x22, #0x8c8
    8e88:	39001fe3 	strb	w3, [sp, #7]
    8e8c:	97ffe941 	bl	3390 <buf_put>
    8e90:	b4000273 	cbz	x19, 8edc <fwp_write+0x91c>
    8e94:	f9400661 	ldr	x1, [x19, #8]
    8e98:	aa1403e0 	mov	x0, x20
    8e9c:	f9401f82 	ldr	x2, [x28, #56]
    8ea0:	52800003 	mov	w3, #0x0                   	// #0
    8ea4:	97fffdc7 	bl	85c0 <fwp_write>
    8ea8:	f9400a73 	ldr	x19, [x19, #16]
    8eac:	b4000193 	cbz	x19, 8edc <fwp_write+0x91c>
    8eb0:	aa1603e1 	mov	x1, x22
    8eb4:	aa1403e0 	mov	x0, x20
    8eb8:	d2800042 	mov	x2, #0x2                   	// #2
    8ebc:	97ffe935 	bl	3390 <buf_put>
    8ec0:	f9400661 	ldr	x1, [x19, #8]
    8ec4:	aa1403e0 	mov	x0, x20
    8ec8:	f9401f82 	ldr	x2, [x28, #56]
    8ecc:	52800003 	mov	w3, #0x0                   	// #0
    8ed0:	97fffdbc 	bl	85c0 <fwp_write>
    8ed4:	f9400a73 	ldr	x19, [x19, #16]
    8ed8:	b5fffed3 	cbnz	x19, 8eb0 <fwp_write+0x8f0>
    8edc:	52800ba3 	mov	w3, #0x5d                  	// #93
    8ee0:	aa1503e1 	mov	x1, x21
    8ee4:	aa1403e0 	mov	x0, x20
    8ee8:	d2800022 	mov	x2, #0x1                   	// #1
    8eec:	39001fe3 	strb	w3, [sp, #7]
    8ef0:	17fffddb 	b	865c <fwp_write+0x9c>
    8ef4:	aa1403e0 	mov	x0, x20
    8ef8:	f0000001 	adrp	x1, b000 <__modti3+0x30>
    8efc:	d28000c2 	mov	x2, #0x6                   	// #6
    8f00:	9122e021 	add	x1, x1, #0x8b8
    8f04:	97ffe923 	bl	3390 <buf_put>
    8f08:	f9400260 	ldr	x0, [x19]
    8f0c:	b40004c0 	cbz	x0, 8fa4 <fwp_write+0x9e4>
    8f10:	910123f5 	add	x21, sp, #0x48
    8f14:	91002276 	add	x22, x19, #0x8
    8f18:	f90143f7 	str	x23, [sp, #640]
    8f1c:	d2800017 	mov	x23, #0x0                   	// #0
    8f20:	f90147f8 	str	x24, [sp, #648]
    8f24:	f0000018 	adrp	x24, b000 <__modti3+0x30>
    8f28:	91230318 	add	x24, x24, #0x8c0
    8f2c:	f9014bf9 	str	x25, [sp, #656]
    8f30:	f0000019 	adrp	x25, b000 <__modti3+0x30>
    8f34:	91232339 	add	x25, x25, #0x8c8
    8f38:	f9014ffa 	str	x26, [sp, #664]
    8f3c:	14000005 	b	8f50 <fwp_write+0x990>
    8f40:	aa1903e1 	mov	x1, x25
    8f44:	aa1403e0 	mov	x0, x20
    8f48:	d2800042 	mov	x2, #0x2                   	// #2
    8f4c:	97ffe911 	bl	3390 <buf_put>
    8f50:	38776ac5 	ldrb	w5, [x22, x23]
    8f54:	d2804003 	mov	x3, #0x200                 	// #512
    8f58:	aa1803e4 	mov	x4, x24
    8f5c:	aa0303e1 	mov	x1, x3
    8f60:	52800042 	mov	w2, #0x2                   	// #2
    8f64:	aa1503e0 	mov	x0, x21
    8f68:	910006f7 	add	x23, x23, #0x1
    8f6c:	97ffe5fd 	bl	2760 <__snprintf_chk@plt>
    8f70:	aa1503e0 	mov	x0, x21
    8f74:	97ffe5c3 	bl	2680 <strlen@plt>
    8f78:	aa1503e1 	mov	x1, x21
    8f7c:	aa0003e2 	mov	x2, x0
    8f80:	aa1403e0 	mov	x0, x20
    8f84:	97ffe903 	bl	3390 <buf_put>
    8f88:	f9400260 	ldr	x0, [x19]
    8f8c:	eb17001f 	cmp	x0, x23
    8f90:	54fffd88 	b.hi	8f40 <fwp_write+0x980>  // b.pmore
    8f94:	f94143f7 	ldr	x23, [sp, #640]
    8f98:	f94147f8 	ldr	x24, [sp, #648]
    8f9c:	f9414bf9 	ldr	x25, [sp, #656]
    8fa0:	f9414ffa 	ldr	x26, [sp, #664]
    8fa4:	52800ba3 	mov	w3, #0x5d                  	// #93
    8fa8:	aa1403e0 	mov	x0, x20
    8fac:	91001fe1 	add	x1, sp, #0x7
    8fb0:	d2800022 	mov	x2, #0x1                   	// #1
    8fb4:	39001fe3 	strb	w3, [sp, #7]
    8fb8:	17fffda9 	b	865c <fwp_write+0x9c>
    8fbc:	52800fa3 	mov	w3, #0x7d                  	// #125
    8fc0:	17fffe44 	b	88d0 <fwp_write+0x310>
    8fc4:	f10002ff 	cmp	x23, #0x0
    8fc8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8fcc:	71002c3f 	cmp	w1, #0xb
    8fd0:	54ffebc0 	b.eq	8d48 <fwp_write+0x788>  // b.none
    8fd4:	aa1303e2 	mov	x2, x19
    8fd8:	aa1703e1 	mov	x1, x23
    8fdc:	aa1403e0 	mov	x0, x20
    8fe0:	52800003 	mov	w3, #0x0                   	// #0
    8fe4:	97fffd77 	bl	85c0 <fwp_write>
    8fe8:	17ffff6a 	b	8d90 <fwp_write+0x7d0>
    8fec:	aa1403e0 	mov	x0, x20
    8ff0:	91001fe1 	add	x1, sp, #0x7
    8ff4:	52800fa3 	mov	w3, #0x7d                  	// #125
    8ff8:	d2800022 	mov	x2, #0x1                   	// #1
    8ffc:	17fffe38 	b	88dc <fwp_write+0x31c>
    9000:	a9400281 	ldp	x1, x0, [x20]
    9004:	91000800 	add	x0, x0, #0x2
    9008:	8b160000 	add	x0, x0, x22
    900c:	f9000680 	str	x0, [x20, #8]
    9010:	3820683f 	strb	wzr, [x1, x0]
    9014:	f9413bf5 	ldr	x21, [sp, #624]
    9018:	f9413ff6 	ldr	x22, [sp, #632]
    901c:	f94153fb 	ldr	x27, [sp, #672]
    9020:	f94157fc 	ldr	x28, [sp, #680]
    9024:	17fffd93 	b	8670 <fwp_write+0xb0>
    9028:	f9400f80 	ldr	x0, [x28, #24]
    902c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9030:	aa1b03e0 	mov	x0, x27
    9034:	97ffe593 	bl	2680 <strlen@plt>
    9038:	aa1b03e1 	mov	x1, x27
    903c:	aa0003e2 	mov	x2, x0
    9040:	aa1403e0 	mov	x0, x20
    9044:	97ffe8d3 	bl	3390 <buf_put>
    9048:	aa1903e1 	mov	x1, x25
    904c:	aa1403e0 	mov	x0, x20
    9050:	d2800062 	mov	x2, #0x3                   	// #3
    9054:	97ffe8cf 	bl	3390 <buf_put>
    9058:	17fffe10 	b	8898 <fwp_write+0x2d8>
    905c:	aa1a03e1 	mov	x1, x26
    9060:	aa1403e0 	mov	x0, x20
    9064:	d2800042 	mov	x2, #0x2                   	// #2
    9068:	97ffe8ca 	bl	3390 <buf_put>
    906c:	17fffe09 	b	8890 <fwp_write+0x2d0>
    9070:	f9400660 	ldr	x0, [x19, #8]
    9074:	b4fffb00 	cbz	x0, 8fd4 <fwp_write+0xa14>
    9078:	d0000001 	adrp	x1, b000 <__modti3+0x30>
    907c:	91238021 	add	x1, x1, #0x8e0
    9080:	97ffe5fc 	bl	2870 <strcmp@plt>
    9084:	7100001f 	cmp	w0, #0x0
    9088:	1a9f07e0 	cset	w0, ne	// ne = any
    908c:	17ffff2f 	b	8d48 <fwp_write+0x788>
    9090:	aa1403e0 	mov	x0, x20
    9094:	d2800042 	mov	x2, #0x2                   	// #2
    9098:	d0000001 	adrp	x1, b000 <__modti3+0x30>
    909c:	91236021 	add	x1, x1, #0x8d8
    90a0:	97ffe8bc 	bl	3390 <buf_put>
    90a4:	91004261 	add	x1, x19, #0x10
    90a8:	aa1403e0 	mov	x0, x20
    90ac:	f9402382 	ldr	x2, [x28, #64]
    90b0:	52800003 	mov	w3, #0x0                   	// #0
    90b4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    90b8:	97fffd42 	bl	85c0 <fwp_write>
    90bc:	17fffd9c 	b	872c <fwp_write+0x16c>
    90c0:	1e22c109 	fcvt	d9, s8
    90c4:	910123f5 	add	x21, sp, #0x48
    90c8:	52800033 	mov	w19, #0x1                   	// #1
    90cc:	d503201f 	nop
    90d0:	1e604120 	fmov	d0, d9
    90d4:	2a1303e1 	mov	w1, w19
    90d8:	aa1503e0 	mov	x0, x21
    90dc:	97ffe9ee 	bl	3894 <fwp_format_g.constprop.0>
    90e0:	aa1503e0 	mov	x0, x21
    90e4:	d2800001 	mov	x1, #0x0                   	// #0
    90e8:	97ffe5ee 	bl	28a0 <strtof@plt>
    90ec:	1e202100 	fcmp	s8, s0
    90f0:	54ffdb60 	b.eq	8c5c <fwp_write+0x69c>  // b.none
    90f4:	11000673 	add	w19, w19, #0x1
    90f8:	71002a7f 	cmp	w19, #0xa
    90fc:	54fffea1 	b.ne	90d0 <fwp_write+0xb10>  // b.any
    9100:	1e604120 	fmov	d0, d9
    9104:	aa1503e0 	mov	x0, x21
    9108:	52800121 	mov	w1, #0x9                   	// #9
    910c:	97ffe9e2 	bl	3894 <fwp_format_g.constprop.0>
    9110:	17fffed3 	b	8c5c <fwp_write+0x69c>
    9114:	d37ef6a1 	lsl	x1, x21, #2
    9118:	b7f81563 	tbnz	x3, #63, 93c4 <fwp_write+0xe04>
    911c:	91002263 	add	x3, x19, #0x8
    9120:	8b010061 	add	x1, x3, x1
    9124:	b9400023 	ldr	w3, [x1]
    9128:	7100081f 	cmp	w0, #0x2
    912c:	2a0303e1 	mov	w1, w3
    9130:	93407c63 	sxtw	x3, w3
    9134:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9138:	17fffe5a 	b	8aa0 <fwp_write+0x4e0>
    913c:	d37ffaa1 	lsl	x1, x21, #1
    9140:	b7f81363 	tbnz	x3, #63, 93ac <fwp_write+0xdec>
    9144:	91002263 	add	x3, x19, #0x8
    9148:	8b010061 	add	x1, x3, x1
    914c:	79400021 	ldrh	w1, [x1]
    9150:	7100041f 	cmp	w0, #0x1
    9154:	93403c23 	sxth	x3, w1
    9158:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    915c:	17fffe51 	b	8aa0 <fwp_write+0x4e0>
    9160:	52800443 	mov	w3, #0x22                  	// #34
    9164:	91001ff5 	add	x21, sp, #0x7
    9168:	91002273 	add	x19, x19, #0x8
    916c:	aa1503e1 	mov	x1, x21
    9170:	aa1403e0 	mov	x0, x20
    9174:	d2800022 	mov	x2, #0x1                   	// #1
    9178:	39001fe3 	strb	w3, [sp, #7]
    917c:	f90143f7 	str	x23, [sp, #640]
    9180:	8b160277 	add	x23, x19, x22
    9184:	f90147f8 	str	x24, [sp, #648]
    9188:	97ffe882 	bl	3390 <buf_put>
    918c:	b4000696 	cbz	x22, 925c <fwp_write+0xc9c>
    9190:	d0000018 	adrp	x24, b000 <__modti3+0x30>
    9194:	91222318 	add	x24, x24, #0x888
    9198:	f9014bf9 	str	x25, [sp, #656]
    919c:	d0000019 	adrp	x25, b000 <__modti3+0x30>
    91a0:	9122a339 	add	x25, x25, #0x8a8
    91a4:	f9014ffa 	str	x26, [sp, #664]
    91a8:	1400000d 	b	91dc <fwp_write+0xc1c>
    91ac:	710024bf 	cmp	w5, #0x9
    91b0:	54000460 	b.eq	923c <fwp_write+0xc7c>  // b.none
    91b4:	710028bf 	cmp	w5, #0xa
    91b8:	54000a61 	b.ne	9304 <fwp_write+0xd44>  // b.any
    91bc:	d0000001 	adrp	x1, b000 <__modti3+0x30>
    91c0:	aa1403e0 	mov	x0, x20
    91c4:	91226021 	add	x1, x1, #0x898
    91c8:	d2800042 	mov	x2, #0x2                   	// #2
    91cc:	97ffe871 	bl	3390 <buf_put>
    91d0:	91000673 	add	x19, x19, #0x1
    91d4:	eb17027f 	cmp	x19, x23
    91d8:	540003e0 	b.eq	9254 <fwp_write+0xc94>  // b.none
    91dc:	39400265 	ldrb	w5, [x19]
    91e0:	710034bf 	cmp	w5, #0xd
    91e4:	54000180 	b.eq	9214 <fwp_write+0xc54>  // b.none
    91e8:	54fffe29 	b.ls	91ac <fwp_write+0xbec>  // b.plast
    91ec:	710088bf 	cmp	w5, #0x22
    91f0:	540001c0 	b.eq	9228 <fwp_write+0xc68>  // b.none
    91f4:	710170bf 	cmp	w5, #0x5c
    91f8:	54000741 	b.ne	92e0 <fwp_write+0xd20>  // b.any
    91fc:	aa1403e0 	mov	x0, x20
    9200:	d0000001 	adrp	x1, b000 <__modti3+0x30>
    9204:	d2800042 	mov	x2, #0x2                   	// #2
    9208:	91224021 	add	x1, x1, #0x890
    920c:	97ffe861 	bl	3390 <buf_put>
    9210:	17fffff0 	b	91d0 <fwp_write+0xc10>
    9214:	aa1903e1 	mov	x1, x25
    9218:	aa1403e0 	mov	x0, x20
    921c:	d2800042 	mov	x2, #0x2                   	// #2
    9220:	97ffe85c 	bl	3390 <buf_put>
    9224:	17ffffeb 	b	91d0 <fwp_write+0xc10>
    9228:	aa1803e1 	mov	x1, x24
    922c:	aa1403e0 	mov	x0, x20
    9230:	d2800042 	mov	x2, #0x2                   	// #2
    9234:	97ffe857 	bl	3390 <buf_put>
    9238:	17ffffe6 	b	91d0 <fwp_write+0xc10>
    923c:	aa1403e0 	mov	x0, x20
    9240:	d0000001 	adrp	x1, b000 <__modti3+0x30>
    9244:	d2800042 	mov	x2, #0x2                   	// #2
    9248:	91228021 	add	x1, x1, #0x8a0
    924c:	97ffe851 	bl	3390 <buf_put>
    9250:	17ffffe0 	b	91d0 <fwp_write+0xc10>
    9254:	f9414bf9 	ldr	x25, [sp, #656]
    9258:	f9414ffa 	ldr	x26, [sp, #664]
    925c:	aa1503e1 	mov	x1, x21
    9260:	aa1403e0 	mov	x0, x20
    9264:	52800443 	mov	w3, #0x22                  	// #34
    9268:	17fffd9c 	b	88d8 <fwp_write+0x318>
    926c:	7100103f 	cmp	w1, #0x4
    9270:	54ffeb21 	b.ne	8fd4 <fwp_write+0xa14>  // b.any
    9274:	f94006e0 	ldr	x0, [x23, #8]
    9278:	d37ffc00 	lsr	x0, x0, #63
    927c:	17fffeb3 	b	8d48 <fwp_write+0x788>
    9280:	710002ff 	cmp	w23, #0x0
    9284:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9288:	17fffeb0 	b	8d48 <fwp_write+0x788>
    928c:	528005a1 	mov	w1, #0x2d                  	// #45
    9290:	eb0203e2 	negs	x2, x2
    9294:	da0303e3 	ngc	x3, x3
    9298:	910127e0 	add	x0, sp, #0x49
    929c:	910123f5 	add	x21, sp, #0x48
    92a0:	390123e1 	strb	w1, [sp, #72]
    92a4:	97ffe6bf 	bl	2da0 <fwp_fmt_u128>
    92a8:	17fffe18 	b	8b08 <fwp_write+0x548>
    92ac:	d37ceea1 	lsl	x1, x21, #4
    92b0:	b7f810a3 	tbnz	x3, #63, 94c4 <fwp_write+0xf04>
    92b4:	91002260 	add	x0, x19, #0x8
    92b8:	8b010001 	add	x1, x0, x1
    92bc:	17fffdf9 	b	8aa0 <fwp_write+0x4e0>
    92c0:	f9400a61 	ldr	x1, [x19, #16]
    92c4:	8b010000 	add	x0, x0, x1
    92c8:	f9400001 	ldr	x1, [x0]
    92cc:	17fffdf5 	b	8aa0 <fwp_write+0x4e0>
    92d0:	d0000001 	adrp	x1, b000 <__modti3+0x30>
    92d4:	d2800042 	mov	x2, #0x2                   	// #2
    92d8:	9120c021 	add	x1, x1, #0x830
    92dc:	17fffed6 	b	8e34 <fwp_write+0x874>
    92e0:	7101fcbf 	cmp	w5, #0x7f
    92e4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    92e8:	540000e9 	b.ls	9304 <fwp_write+0xd44>  // b.plast
    92ec:	aa1503e1 	mov	x1, x21
    92f0:	aa1403e0 	mov	x0, x20
    92f4:	d2800022 	mov	x2, #0x1                   	// #1
    92f8:	39001fe5 	strb	w5, [sp, #7]
    92fc:	97ffe825 	bl	3390 <buf_put>
    9300:	17ffffb4 	b	91d0 <fwp_write+0xc10>
    9304:	d2800203 	mov	x3, #0x10                  	// #16
    9308:	d0000004 	adrp	x4, b000 <__modti3+0x30>
    930c:	aa0303e1 	mov	x1, x3
    9310:	9122c084 	add	x4, x4, #0x8b0
    9314:	910123f6 	add	x22, sp, #0x48
    9318:	52800042 	mov	w2, #0x2                   	// #2
    931c:	aa1603e0 	mov	x0, x22
    9320:	97ffe510 	bl	2760 <__snprintf_chk@plt>
    9324:	aa1603e0 	mov	x0, x22
    9328:	97ffe4d6 	bl	2680 <strlen@plt>
    932c:	aa1603e1 	mov	x1, x22
    9330:	aa0003e2 	mov	x2, x0
    9334:	aa1403e0 	mov	x0, x20
    9338:	97ffe816 	bl	3390 <buf_put>
    933c:	17ffffa5 	b	91d0 <fwp_write+0xc10>
    9340:	1e604100 	fmov	d0, d8
    9344:	aa1503e0 	mov	x0, x21
    9348:	52800221 	mov	w1, #0x11                  	// #17
    934c:	97ffe952 	bl	3894 <fwp_format_g.constprop.0>
    9350:	17fffe43 	b	8c5c <fwp_write+0x69c>
    9354:	b9401040 	ldr	w0, [x2, #16]
    9358:	350003c0 	cbnz	w0, 93d0 <fwp_write+0xe10>
    935c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9360:	f947f400 	ldr	x0, [x0, #4072]
    9364:	f94127e2 	ldr	x2, [sp, #584]
    9368:	f9400001 	ldr	x1, [x0]
    936c:	eb010042 	subs	x2, x2, x1
    9370:	d2800001 	mov	x1, #0x0                   	// #0
    9374:	54ffd721 	b.ne	8e58 <fwp_write+0x898>  // b.any
    9378:	f9413bf5 	ldr	x21, [sp, #624]
    937c:	d0000001 	adrp	x1, b000 <__modti3+0x30>
    9380:	f9413ff6 	ldr	x22, [sp, #632]
    9384:	aa1403e0 	mov	x0, x20
    9388:	f94143f7 	ldr	x23, [sp, #640]
    938c:	91240021 	add	x1, x1, #0x900
    9390:	f94147f8 	ldr	x24, [sp, #648]
    9394:	d2800042 	mov	x2, #0x2                   	// #2
    9398:	17fffd0e 	b	87d0 <fwp_write+0x210>
    939c:	d0000001 	adrp	x1, b000 <__modti3+0x30>
    93a0:	d2800042 	mov	x2, #0x2                   	// #2
    93a4:	9120e021 	add	x1, x1, #0x838
    93a8:	17fffea3 	b	8e34 <fwp_write+0x874>
    93ac:	f9400a63 	ldr	x3, [x19, #16]
    93b0:	8b030021 	add	x1, x1, x3
    93b4:	17ffff66 	b	914c <fwp_write+0xb8c>
    93b8:	f9400a61 	ldr	x1, [x19, #16]
    93bc:	8b0102a1 	add	x1, x21, x1
    93c0:	17fffdb3 	b	8a8c <fwp_write+0x4cc>
    93c4:	f9400a63 	ldr	x3, [x19, #16]
    93c8:	8b030021 	add	x1, x1, x3
    93cc:	17ffff56 	b	9124 <fwp_write+0xb64>
    93d0:	b9404840 	ldr	w0, [x2, #72]
    93d4:	91001ff5 	add	x21, sp, #0x7
    93d8:	34ffa360 	cbz	w0, 8844 <fwp_write+0x284>
    93dc:	52800503 	mov	w3, #0x28                  	// #40
    93e0:	aa1403e0 	mov	x0, x20
    93e4:	aa1503e1 	mov	x1, x21
    93e8:	d2800022 	mov	x2, #0x1                   	// #1
    93ec:	39001fe3 	strb	w3, [sp, #7]
    93f0:	97ffe7e8 	bl	3390 <buf_put>
    93f4:	b9401380 	ldr	w0, [x28, #16]
    93f8:	52800038 	mov	w24, #0x1                   	// #1
    93fc:	7100001f 	cmp	w0, #0x0
    9400:	54ffa36c 	b.gt	886c <fwp_write+0x2ac>
    9404:	17fffd32 	b	88cc <fwp_write+0x30c>
    9408:	f9014bf9 	str	x25, [sp, #656]
    940c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10c10>
    9410:	f9014ffa 	str	x26, [sp, #664]
    9414:	f9400676 	ldr	x22, [x19, #8]
    9418:	91102333 	add	x19, x25, #0x408
    941c:	91002273 	add	x19, x19, #0x8
    9420:	937ffed8 	asr	x24, x22, #63
    9424:	aa1802c0 	orr	x0, x22, x24
    9428:	b5000320 	cbnz	x0, 948c <fwp_write+0xecc>
    942c:	110006b5 	add	w21, w21, #0x1
    9430:	710016bf 	cmp	w21, #0x5
    9434:	54ffffc1 	b.ne	942c <fwp_write+0xe6c>  // b.any
    9438:	b7f80578 	tbnz	x24, #63, 94e4 <fwp_write+0xf24>
    943c:	910023f3 	add	x19, sp, #0x8
    9440:	aa1603e2 	mov	x2, x22
    9444:	aa1303e0 	mov	x0, x19
    9448:	d2800003 	mov	x3, #0x0                   	// #0
    944c:	97ffe655 	bl	2da0 <fwp_fmt_u128>
    9450:	910123f5 	add	x21, sp, #0x48
    9454:	d0000003 	adrp	x3, b000 <__modti3+0x30>
    9458:	aa1303e4 	mov	x4, x19
    945c:	aa1503e0 	mov	x0, x21
    9460:	9123e063 	add	x3, x3, #0x8f8
    9464:	d2804002 	mov	x2, #0x200                 	// #512
    9468:	52800041 	mov	w1, #0x2                   	// #2
    946c:	97ffe489 	bl	2690 <__sprintf_chk@plt>
    9470:	aa1503e0 	mov	x0, x21
    9474:	97ffe483 	bl	2680 <strlen@plt>
    9478:	aa1503e1 	mov	x1, x21
    947c:	aa0003e2 	mov	x2, x0
    9480:	aa1403e0 	mov	x0, x20
    9484:	97ffe7c3 	bl	3390 <buf_put>
    9488:	17fffe47 	b	8da4 <fwp_write+0x7e4>
    948c:	f9400277 	ldr	x23, [x19]
    9490:	aa1603e0 	mov	x0, x22
    9494:	aa1803e1 	mov	x1, x24
    9498:	aa1703e2 	mov	x2, x23
    949c:	937ffefa 	asr	x26, x23, #63
    94a0:	aa1a03e3 	mov	x3, x26
    94a4:	940006cb 	bl	afd0 <__modti3>
    94a8:	aa010000 	orr	x0, x0, x1
    94ac:	b40002c0 	cbz	x0, 9504 <fwp_write+0xf44>
    94b0:	110006b5 	add	w21, w21, #0x1
    94b4:	91004273 	add	x19, x19, #0x10
    94b8:	710016bf 	cmp	w21, #0x5
    94bc:	54fffe81 	b.ne	948c <fwp_write+0xecc>  // b.any
    94c0:	17ffffde 	b	9438 <fwp_write+0xe78>
    94c4:	f9400a60 	ldr	x0, [x19, #16]
    94c8:	8b000021 	add	x1, x1, x0
    94cc:	17fffd75 	b	8aa0 <fwp_write+0x4e0>
    94d0:	528c29c0 	mov	w0, #0x614e                	// #24910
    94d4:	910123f5 	add	x21, sp, #0x48
    94d8:	72a009c0 	movk	w0, #0x4e, lsl #16
    94dc:	b9004be0 	str	w0, [sp, #72]
    94e0:	17fffda2 	b	8b68 <fwp_write+0x5a8>
    94e4:	528005a1 	mov	w1, #0x2d                  	// #45
    94e8:	eb1603e2 	negs	x2, x22
    94ec:	da1803e3 	ngc	x3, x24
    94f0:	910027e0 	add	x0, sp, #0x9
    94f4:	910023f3 	add	x19, sp, #0x8
    94f8:	390023e1 	strb	w1, [sp, #8]
    94fc:	97ffe629 	bl	2da0 <fwp_fmt_u128>
    9500:	17ffffd4 	b	9450 <fwp_write+0xe90>
    9504:	aa1703e2 	mov	x2, x23
    9508:	aa1a03e3 	mov	x3, x26
    950c:	aa1603e0 	mov	x0, x22
    9510:	aa1803e1 	mov	x1, x24
    9514:	940005cf 	bl	ac50 <__divti3>
    9518:	aa0003e2 	mov	x2, x0
    951c:	aa0103e3 	mov	x3, x1
    9520:	b7f80201 	tbnz	x1, #63, 9560 <fwp_write+0xfa0>
    9524:	910023f3 	add	x19, sp, #0x8
    9528:	aa1303e0 	mov	x0, x19
    952c:	97ffe61d 	bl	2da0 <fwp_fmt_u128>
    9530:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9534:	91102339 	add	x25, x25, #0x408
    9538:	910123f5 	add	x21, sp, #0x48
    953c:	aa1303e4 	mov	x4, x19
    9540:	aa1503e0 	mov	x0, x21
    9544:	d0000003 	adrp	x3, b000 <__modti3+0x30>
    9548:	f8616b25 	ldr	x5, [x25, x1]
    954c:	9123c063 	add	x3, x3, #0x8f0
    9550:	d2804002 	mov	x2, #0x200                 	// #512
    9554:	52800041 	mov	w1, #0x2                   	// #2
    9558:	97ffe44e 	bl	2690 <__sprintf_chk@plt>
    955c:	17ffffc5 	b	9470 <fwp_write+0xeb0>
    9560:	528005a4 	mov	w4, #0x2d                  	// #45
    9564:	eb0003e2 	negs	x2, x0
    9568:	da0103e3 	ngc	x3, x1
    956c:	910027e0 	add	x0, sp, #0x9
    9570:	910023f3 	add	x19, sp, #0x8
    9574:	390023e4 	strb	w4, [sp, #8]
    9578:	97ffe60a 	bl	2da0 <fwp_fmt_u128>
    957c:	17ffffed 	b	9530 <fwp_write+0xf70>
    9580:	f9013bf5 	str	x21, [sp, #624]
    9584:	f9013ff6 	str	x22, [sp, #632]
    9588:	f90143f7 	str	x23, [sp, #640]
    958c:	f90147f8 	str	x24, [sp, #648]
    9590:	f9014bf9 	str	x25, [sp, #656]
    9594:	f9014ffa 	str	x26, [sp, #664]
    9598:	f90153fb 	str	x27, [sp, #672]
    959c:	f90157fc 	str	x28, [sp, #680]
    95a0:	fd015be8 	str	d8, [sp, #688]
    95a4:	fd015fe9 	str	d9, [sp, #696]
    95a8:	97ffe492 	bl	27f0 <__stack_chk_fail@plt>
    95ac:	d503201f 	nop

00000000000095b0 <fwp_main_thread>:
    95b0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    95b4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    95b8:	91154001 	add	x1, x0, #0x550
    95bc:	910003fd 	mov	x29, sp
    95c0:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    95c4:	f947f400 	ldr	x0, [x0, #4072]
    95c8:	a90153f3 	stp	x19, x20, [sp, #16]
    95cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    95d0:	a90363f7 	stp	x23, x24, [sp, #48]
    95d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    95d8:	a90573fb 	stp	x27, x28, [sp, #80]
    95dc:	fd0033e8 	str	d8, [sp, #96]
    95e0:	d10603ff 	sub	sp, sp, #0x180
    95e4:	b953a421 	ldr	w1, [x1, #5028]
    95e8:	f9400002 	ldr	x2, [x0]
    95ec:	f81f83a2 	stur	x2, [x29, #-8]
    95f0:	d2800002 	mov	x2, #0x0                   	// #0
    95f4:	34002741 	cbz	w1, 9adc <fwp_main_thread+0x52c>
    95f8:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    95fc:	91154000 	add	x0, x0, #0x550
    9600:	b953a800 	ldr	w0, [x0, #5032]
    9604:	35002640 	cbnz	w0, 9acc <fwp_main_thread+0x51c>
    9608:	f00000a0 	adrp	x0, 20000 <__data_start>
    960c:	f00000a2 	adrp	x2, 20000 <__data_start>
    9610:	91010019 	add	x25, x0, #0x40
    9614:	910dc042 	add	x2, x2, #0x370
    9618:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    961c:	d2a00024 	mov	x4, #0x10000               	// #65536
    9620:	d10383bb 	sub	x27, x29, #0xe0
    9624:	d103e3b8 	sub	x24, x29, #0xf8
    9628:	aa1b03e0 	mov	x0, x27
    962c:	d2800001 	mov	x1, #0x0                   	// #0
    9630:	f81203a2 	stur	x2, [x29, #-224]
    9634:	b81283bf 	stur	wzr, [x29, #-216]
    9638:	f81303a4 	stur	x4, [x29, #-208]
    963c:	a9018f38 	stp	x24, x3, [x25, #24]
    9640:	97ffe404 	bl	2650 <sigaltstack@plt>
    9644:	3500a4e0 	cbnz	w0, aae0 <fwp_main_thread+0x1530>
    9648:	4f000400 	movi	v0.4s, #0x0
    964c:	d10263a0 	sub	x0, x29, #0x98
    9650:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9654:	913fc021 	add	x1, x1, #0xff0
    9658:	f81603a1 	stur	x1, [x29, #-160]
    965c:	52800082 	mov	w2, #0x4                   	// #4
    9660:	72a10002 	movk	w2, #0x800, lsl #16
    9664:	d10283b6 	sub	x22, x29, #0xa0
    9668:	3d802000 	str	q0, [x0, #128]
    966c:	b81e83a2 	stur	w2, [x29, #-24]
    9670:	ad000000 	stp	q0, q0, [x0]
    9674:	ad010000 	stp	q0, q0, [x0, #32]
    9678:	ad020000 	stp	q0, q0, [x0, #64]
    967c:	ad030000 	stp	q0, q0, [x0, #96]
    9680:	97ffe44c 	bl	27b0 <sigemptyset@plt>
    9684:	3500a2e0 	cbnz	w0, aae0 <fwp_main_thread+0x1530>
    9688:	aa1603e1 	mov	x1, x22
    968c:	d2800002 	mov	x2, #0x0                   	// #0
    9690:	52800160 	mov	w0, #0xb                   	// #11
    9694:	97ffe45f 	bl	2810 <sigaction@plt>
    9698:	3500a240 	cbnz	w0, aae0 <fwp_main_thread+0x1530>
    969c:	aa1603e1 	mov	x1, x22
    96a0:	d2800002 	mov	x2, #0x0                   	// #0
    96a4:	528000e0 	mov	w0, #0x7                   	// #7
    96a8:	97ffe45a 	bl	2810 <sigaction@plt>
    96ac:	3500a1a0 	cbnz	w0, aae0 <fwp_main_thread+0x1530>
    96b0:	b942fb20 	ldr	w0, [x25, #760]
    96b4:	34002180 	cbz	w0, 9ae4 <fwp_main_thread+0x534>
    96b8:	f00000a0 	adrp	x0, 20000 <__data_start>
    96bc:	91010015 	add	x21, x0, #0x40
    96c0:	f9400ab4 	ldr	x20, [x21, #16]
    96c4:	b4000c54 	cbz	x20, 984c <fwp_main_thread+0x29c>
    96c8:	aa1403f3 	mov	x19, x20
    96cc:	91010297 	add	x23, x20, #0x40
    96d0:	39414a98 	ldrb	w24, [x20, #82]
    96d4:	52800036 	mov	w22, #0x1                   	// #1
    96d8:	39014a96 	strb	w22, [x20, #82]
    96dc:	f9401680 	ldr	x0, [x20, #40]
    96e0:	b4000620 	cbz	x0, 97a4 <fwp_main_thread+0x1f4>
    96e4:	f9403281 	ldr	x1, [x20, #96]
    96e8:	39414680 	ldrb	w0, [x20, #81]
    96ec:	b4000e81 	cbz	x1, 98bc <fwp_main_thread+0x30c>
    96f0:	36000d40 	tbz	w0, #0, 9898 <fwp_main_thread+0x2e8>
    96f4:	39414a62 	ldrb	w2, [x19, #82]
    96f8:	f9402281 	ldr	x1, [x20, #64]
    96fc:	37001082 	tbnz	w2, #0, 990c <fwp_main_thread+0x35c>
    9700:	f9403260 	ldr	x0, [x19, #96]
    9704:	a911fe77 	stp	x23, xzr, [x19, #280]
    9708:	f9009661 	str	x1, [x19, #296]
    970c:	b4000041 	cbz	x1, 9714 <fwp_main_thread+0x164>
    9710:	f9009033 	str	x19, [x1, #288]
    9714:	f9002293 	str	x19, [x20, #64]
    9718:	b4000100 	cbz	x0, 9738 <fwp_main_thread+0x188>
    971c:	f94046a1 	ldr	x1, [x21, #136]
    9720:	39015676 	strb	w22, [x19, #85]
    9724:	f9003660 	str	x0, [x19, #104]
    9728:	a910867f 	stp	xzr, x1, [x19, #264]
    972c:	b4000041 	cbz	x1, 9734 <fwp_main_thread+0x184>
    9730:	f9008433 	str	x19, [x1, #264]
    9734:	f90046b3 	str	x19, [x21, #136]
    9738:	39015a7f 	strb	wzr, [x19, #86]
    973c:	97fff2a6 	bl	61d4 <fwp_block>
    9740:	f9408e62 	ldr	x2, [x19, #280]
    9744:	b4000142 	cbz	x2, 976c <fwp_main_thread+0x1bc>
    9748:	a9520261 	ldp	x1, x0, [x19, #288]
    974c:	b4000ec1 	cbz	x1, 9924 <fwp_main_thread+0x374>
    9750:	f9009420 	str	x0, [x1, #296]
    9754:	f9409660 	ldr	x0, [x19, #296]
    9758:	b4000040 	cbz	x0, 9760 <fwp_main_thread+0x1b0>
    975c:	f9009001 	str	x1, [x0, #288]
    9760:	91080260 	add	x0, x19, #0x200
    9764:	f900967f 	str	xzr, [x19, #296]
    9768:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    976c:	39415660 	ldrb	w0, [x19, #85]
    9770:	f9400aa1 	ldr	x1, [x21, #16]
    9774:	36000c80 	tbz	w0, #0, 9904 <fwp_main_thread+0x354>
    9778:	a9508262 	ldp	x2, x0, [x19, #264]
    977c:	b4000d82 	cbz	x2, 992c <fwp_main_thread+0x37c>
    9780:	f9008840 	str	x0, [x2, #272]
    9784:	b4000040 	cbz	x0, 978c <fwp_main_thread+0x1dc>
    9788:	f9008402 	str	x2, [x0, #264]
    978c:	91080260 	add	x0, x19, #0x200
    9790:	3901567f 	strb	wzr, [x19, #85]
    9794:	aa0103f3 	mov	x19, x1
    9798:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    979c:	f9401680 	ldr	x0, [x20, #40]
    97a0:	b5fffa20 	cbnz	x0, 96e4 <fwp_main_thread+0x134>
    97a4:	f00000a0 	adrp	x0, 20000 <__data_start>
    97a8:	91010000 	add	x0, x0, #0x40
    97ac:	39014a98 	strb	w24, [x20, #82]
    97b0:	f9416c00 	ldr	x0, [x0, #728]
    97b4:	b4000520 	cbz	x0, 9858 <fwp_main_thread+0x2a8>
    97b8:	f00000a0 	adrp	x0, 20000 <__data_start>
    97bc:	91010000 	add	x0, x0, #0x40
    97c0:	f9418801 	ldr	x1, [x0, #784]
    97c4:	b903081f 	str	wzr, [x0, #776]
    97c8:	eb13003f 	cmp	x1, x19
    97cc:	54000641 	b.ne	9894 <fwp_main_thread+0x2e4>  // b.any
    97d0:	b4000bd3 	cbz	x19, 9948 <fwp_main_thread+0x398>
    97d4:	f00000a0 	adrp	x0, 20000 <__data_start>
    97d8:	91010000 	add	x0, x0, #0x40
    97dc:	52800021 	mov	w1, #0x1                   	// #1
    97e0:	39014a61 	strb	w1, [x19, #82]
    97e4:	f9415805 	ldr	x5, [x0, #688]
    97e8:	b4000b05 	cbz	x5, 9948 <fwp_main_thread+0x398>
    97ec:	394140a0 	ldrb	w0, [x5, #80]
    97f0:	37000060 	tbnz	w0, #0, 97fc <fwp_main_thread+0x24c>
    97f4:	aa0503e0 	mov	x0, x5
    97f8:	97ffe6fe 	bl	33f0 <fwp_cancel_tree.part.0>
    97fc:	f9409ca5 	ldr	x5, [x5, #312]
    9800:	b5ffff65 	cbnz	x5, 97ec <fwp_main_thread+0x23c>
    9804:	f00000a0 	adrp	x0, 20000 <__data_start>
    9808:	91010014 	add	x20, x0, #0x40
    980c:	52800035 	mov	w21, #0x1                   	// #1
    9810:	f9402a60 	ldr	x0, [x19, #80]
    9814:	f2001c1f 	tst	x0, #0xff000000ff
    9818:	540000e1 	b.ne	9834 <fwp_main_thread+0x284>  // b.any
    981c:	f9401680 	ldr	x0, [x20, #40]
    9820:	39015275 	strb	w21, [x19, #84]
    9824:	f900827f 	str	xzr, [x19, #256]
    9828:	b4000860 	cbz	x0, 9934 <fwp_main_thread+0x384>
    982c:	f9008013 	str	x19, [x0, #256]
    9830:	f9001693 	str	x19, [x20, #40]
    9834:	97fff268 	bl	61d4 <fwp_block>
    9838:	97fff1fa 	bl	6020 <fwp_free_zombie>
    983c:	f9415a80 	ldr	x0, [x20, #688]
    9840:	b4000840 	cbz	x0, 9948 <fwp_main_thread+0x398>
    9844:	f9418a93 	ldr	x19, [x20, #784]
    9848:	17fffff2 	b	9810 <fwp_main_thread+0x260>
    984c:	f9416ea0 	ldr	x0, [x21, #728]
    9850:	b5000760 	cbnz	x0, 993c <fwp_main_thread+0x38c>
    9854:	d2800013 	mov	x19, #0x0                   	// #0
    9858:	f00000a0 	adrp	x0, 20000 <__data_start>
    985c:	91010014 	add	x20, x0, #0x40
    9860:	f9417680 	ldr	x0, [x20, #744]
    9864:	b5fffaa0 	cbnz	x0, 97b8 <fwp_main_thread+0x208>
    9868:	f9416a80 	ldr	x0, [x20, #720]
    986c:	97ffebc1 	bl	4770 <fwp_mem_free>
    9870:	f9016a9f 	str	xzr, [x20, #720]
    9874:	f901729f 	str	xzr, [x20, #736]
    9878:	f9418a80 	ldr	x0, [x20, #784]
    987c:	b4009cb3 	cbz	x19, ac10 <fwp_main_thread+0x1660>
    9880:	f900567f 	str	xzr, [x19, #168]
    9884:	f9005e7f 	str	xzr, [x19, #184]
    9888:	b9030a9f 	str	wzr, [x20, #776]
    988c:	eb00027f 	cmp	x19, x0
    9890:	54fffa20 	b.eq	97d4 <fwp_main_thread+0x224>  // b.none
    9894:	97ffe3eb 	bl	2840 <abort@plt>
    9898:	97ffe77a 	bl	3680 <fwp_now_ns>
    989c:	f9403281 	ldr	x1, [x20, #96]
    98a0:	eb01001f 	cmp	x0, x1
    98a4:	540000ab 	b.lt	98b8 <fwp_main_thread+0x308>  // b.tstop
    98a8:	39414280 	ldrb	w0, [x20, #80]
    98ac:	37000060 	tbnz	w0, #0, 98b8 <fwp_main_thread+0x308>
    98b0:	aa1403e0 	mov	x0, x20
    98b4:	97ffe6cf 	bl	33f0 <fwp_cancel_tree.part.0>
    98b8:	39414680 	ldrb	w0, [x20, #81]
    98bc:	39414a62 	ldrb	w2, [x19, #82]
    98c0:	3707f1c0 	tbnz	w0, #0, 96f8 <fwp_main_thread+0x148>
    98c4:	f9403280 	ldr	x0, [x20, #96]
    98c8:	370001a2 	tbnz	w2, #0, 98fc <fwp_main_thread+0x34c>
    98cc:	f9403261 	ldr	x1, [x19, #96]
    98d0:	b4000161 	cbz	x1, 98fc <fwp_main_thread+0x34c>
    98d4:	b4008ca0 	cbz	x0, aa68 <fwp_main_thread+0x14b8>
    98d8:	eb01001f 	cmp	x0, x1
    98dc:	9a81d000 	csel	x0, x0, x1, le
    98e0:	f9402281 	ldr	x1, [x20, #64]
    98e4:	a911fe77 	stp	x23, xzr, [x19, #280]
    98e8:	f9009661 	str	x1, [x19, #296]
    98ec:	b4000041 	cbz	x1, 98f4 <fwp_main_thread+0x344>
    98f0:	f9009033 	str	x19, [x1, #288]
    98f4:	f9002293 	str	x19, [x20, #64]
    98f8:	17ffff89 	b	971c <fwp_main_thread+0x16c>
    98fc:	f9402281 	ldr	x1, [x20, #64]
    9900:	17ffff81 	b	9704 <fwp_main_thread+0x154>
    9904:	aa0103f3 	mov	x19, x1
    9908:	17ffff75 	b	96dc <fwp_main_thread+0x12c>
    990c:	a911fe77 	stp	x23, xzr, [x19, #280]
    9910:	f9009661 	str	x1, [x19, #296]
    9914:	b4000041 	cbz	x1, 991c <fwp_main_thread+0x36c>
    9918:	f9009033 	str	x19, [x1, #288]
    991c:	f9002293 	str	x19, [x20, #64]
    9920:	17ffff86 	b	9738 <fwp_main_thread+0x188>
    9924:	f9000040 	str	x0, [x2]
    9928:	17ffff8c 	b	9758 <fwp_main_thread+0x1a8>
    992c:	f90046a0 	str	x0, [x21, #136]
    9930:	17ffff95 	b	9784 <fwp_main_thread+0x1d4>
    9934:	f9001a93 	str	x19, [x20, #48]
    9938:	17ffffbe 	b	9830 <fwp_main_thread+0x280>
    993c:	f9418aa0 	ldr	x0, [x21, #784]
    9940:	b9030abf 	str	wzr, [x21, #776]
    9944:	b5fffa80 	cbnz	x0, 9894 <fwp_main_thread+0x2e4>
    9948:	97fff1b6 	bl	6020 <fwp_free_zombie>
    994c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9950:	91010015 	add	x21, x0, #0x40
    9954:	f9401aa0 	ldr	x0, [x21, #48]
    9958:	b5fff9e0 	cbnz	x0, 9894 <fwp_main_thread+0x2e4>
    995c:	f94046a0 	ldr	x0, [x21, #136]
    9960:	b5fff9a0 	cbnz	x0, 9894 <fwp_main_thread+0x2e4>
    9964:	b940aaa0 	ldr	w0, [x21, #168]
    9968:	340001c0 	cbz	w0, 99a0 <fwp_main_thread+0x3f0>
    996c:	93407c14 	sxtw	x20, w0
    9970:	51000400 	sub	w0, w0, #0x1
    9974:	d1000a94 	sub	x20, x20, #0x2
    9978:	9102c2b6 	add	x22, x21, #0xb0
    997c:	cb204294 	sub	x20, x20, w0, uxtw
    9980:	93407c13 	sxtw	x19, w0
    9984:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    9988:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    998c:	b900aab3 	str	w19, [x21, #168]
    9990:	d1000673 	sub	x19, x19, #0x1
    9994:	97ffe3df 	bl	2910 <munmap@plt>
    9998:	eb14027f 	cmp	x19, x20
    999c:	54ffff41 	b.ne	9984 <fwp_main_thread+0x3d4>  // b.any
    99a0:	f00000a5 	adrp	x5, 20000 <__data_start>
    99a4:	910040a0 	add	x0, x5, #0x10
    99a8:	b9401000 	ldr	w0, [x0, #16]
    99ac:	37f800c0 	tbnz	w0, #31, 99c4 <fwp_main_thread+0x414>
    99b0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    99b4:	f91f7c25 	str	x5, [x1, #16120]
    99b8:	97ffe392 	bl	2800 <close@plt>
    99bc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    99c0:	f95f7c05 	ldr	x5, [x0, #16120]
    99c4:	f00000a0 	adrp	x0, 20000 <__data_start>
    99c8:	91010000 	add	x0, x0, #0x40
    99cc:	910040a5 	add	x5, x5, #0x10
    99d0:	12800001 	mov	w1, #0xffffffff            	// #-1
    99d4:	d2800013 	mov	x19, #0x0                   	// #0
    99d8:	f9418c15 	ldr	x21, [x0, #792]
    99dc:	b90010a1 	str	w1, [x5, #16]
    99e0:	f9419014 	ldr	x20, [x0, #800]
    99e4:	b4000175 	cbz	x21, 9a10 <fwp_main_thread+0x460>
    99e8:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    99ec:	b40000c0 	cbz	x0, 9a04 <fwp_main_thread+0x454>
    99f0:	f9400001 	ldr	x1, [x0]
    99f4:	b5fff501 	cbnz	x1, 9894 <fwp_main_thread+0x2e4>
    99f8:	f9400401 	ldr	x1, [x0, #8]
    99fc:	b5fff4c1 	cbnz	x1, 9894 <fwp_main_thread+0x2e4>
    9a00:	97ffeb5c 	bl	4770 <fwp_mem_free>
    9a04:	91000673 	add	x19, x19, #0x1
    9a08:	eb1302bf 	cmp	x21, x19
    9a0c:	54fffee1 	b.ne	99e8 <fwp_main_thread+0x438>  // b.any
    9a10:	aa1403e0 	mov	x0, x20
    9a14:	97ffeb57 	bl	4770 <fwp_mem_free>
    9a18:	f00000a0 	adrp	x0, 20000 <__data_start>
    9a1c:	91010000 	add	x0, x0, #0x40
    9a20:	f9418813 	ldr	x19, [x0, #784]
    9a24:	f9018c1f 	str	xzr, [x0, #792]
    9a28:	f901901f 	str	xzr, [x0, #800]
    9a2c:	b40001f3 	cbz	x19, 9a68 <fwp_main_thread+0x4b8>
    9a30:	f9401661 	ldr	x1, [x19, #40]
    9a34:	b5fff301 	cbnz	x1, 9894 <fwp_main_thread+0x2e4>
    9a38:	f9405661 	ldr	x1, [x19, #168]
    9a3c:	b5fff2c1 	cbnz	x1, 9894 <fwp_main_thread+0x2e4>
    9a40:	f9416c01 	ldr	x1, [x0, #728]
    9a44:	b5fff281 	cbnz	x1, 9894 <fwp_main_thread+0x2e4>
    9a48:	f9417400 	ldr	x0, [x0, #744]
    9a4c:	b5fff240 	cbnz	x0, 9894 <fwp_main_thread+0x2e4>
    9a50:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9a54:	f0000120 	adrp	x0, 30000 <alt.5+0xfc90>
    9a58:	910dc000 	add	x0, x0, #0x370
    9a5c:	97ffe359 	bl	27c0 <memset@plt>
    9a60:	aa1303e0 	mov	x0, x19
    9a64:	97ffeb43 	bl	4770 <fwp_mem_free>
    9a68:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9a6c:	f947ec00 	ldr	x0, [x0, #4056]
    9a70:	f00000a1 	adrp	x1, 20000 <__data_start>
    9a74:	91010021 	add	x1, x1, #0x40
    9a78:	f9400000 	ldr	x0, [x0]
    9a7c:	f900083f 	str	xzr, [x1, #16]
    9a80:	f901883f 	str	xzr, [x1, #784]
    9a84:	97ffe3a7 	bl	2920 <fflush@plt>
    9a88:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9a8c:	f947f400 	ldr	x0, [x0, #4072]
    9a90:	f85f83a2 	ldur	x2, [x29, #-8]
    9a94:	f9400001 	ldr	x1, [x0]
    9a98:	eb010042 	subs	x2, x2, x1
    9a9c:	d2800001 	mov	x1, #0x0                   	// #0
    9aa0:	54008261 	b.ne	aaec <fwp_main_thread+0x153c>  // b.any
    9aa4:	910003bf 	mov	sp, x29
    9aa8:	d2800000 	mov	x0, #0x0                   	// #0
    9aac:	a94153f3 	ldp	x19, x20, [sp, #16]
    9ab0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    9ab4:	a94363f7 	ldp	x23, x24, [sp, #48]
    9ab8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    9abc:	a94573fb 	ldp	x27, x28, [sp, #80]
    9ac0:	fd4033e8 	ldr	d8, [sp, #96]
    9ac4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    9ac8:	d65f03c0 	ret
    9acc:	d0ffffc0 	adrp	x0, 3000 <fwp_segv+0x10>
    9ad0:	91328000 	add	x0, x0, #0xca0
    9ad4:	9400061b 	bl	b340 <atexit>
    9ad8:	17fffecc 	b	9608 <fwp_main_thread+0x58>
    9adc:	97ffe8ca 	bl	3e04 <fwp_heap_init>
    9ae0:	17fffec6 	b	95f8 <fwp_main_thread+0x48>
    9ae4:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9ae8:	91154013 	add	x19, x0, #0x550
    9aec:	f0000000 	adrp	x0, c000 <msg.4+0x20>
    9af0:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9af4:	f9416322 	ldr	x2, [x25, #704]
    9af8:	913b4021 	add	x1, x1, #0xed0
    9afc:	fd401008 	ldr	d8, [x0, #32]
    9b00:	90ffffe0 	adrp	x0, 5000 <fwp_p_ad_push+0xdc>
    9b04:	91244000 	add	x0, x0, #0x910
    9b08:	a93303bf 	stp	xzr, x0, [x29, #-208]
    9b0c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9b10:	d2800015 	mov	x21, #0x0                   	// #0
    9b14:	d280401a 	mov	x26, #0x200                 	// #512
    9b18:	d2800014 	mov	x20, #0x0                   	// #0
    9b1c:	52800037 	mov	w23, #0x1                   	// #1
    9b20:	a93087a2 	stp	x2, x1, [x29, #-248]
    9b24:	a931ffbb 	stp	x27, xzr, [x29, #-232]
    9b28:	f9016338 	str	x24, [x25, #704]
    9b2c:	f91f7816 	str	x22, [x0, #16112]
    9b30:	f91f7c1b 	str	x27, [x0, #16120]
    9b34:	b953a660 	ldr	w0, [x19, #5028]
    9b38:	f1000759 	subs	x25, x26, #0x1
    9b3c:	f81283b9 	stur	x25, [x29, #-216]
    9b40:	da1f0296 	sbc	x22, x20, xzr
    9b44:	aa1903fa 	mov	x26, x25
    9b48:	aa1603f4 	mov	x20, x22
    9b4c:	34003b20 	cbz	w0, a2b0 <fwp_main_thread+0xd00>
    9b50:	397e8a60 	ldrb	w0, [x19, #4002]
    9b54:	910f0001 	add	x1, x0, #0x3c0
    9b58:	8b000400 	add	x0, x0, x0, lsl #1
    9b5c:	b8617a7b 	ldr	w27, [x19, x1, lsl #2]
    9b60:	8b000e61 	add	x1, x19, x0, lsl #3
    9b64:	f8607a78 	ldr	x24, [x19, x0, lsl #3]
    9b68:	2a1b03fc 	mov	w28, w27
    9b6c:	b4003918 	cbz	x24, a28c <fwp_main_thread+0xcdc>
    9b70:	f9400301 	ldr	x1, [x24]
    9b74:	aa2103e1 	mvn	x1, x1
    9b78:	f8207a61 	str	x1, [x19, x0, lsl #3]
    9b7c:	f100639f 	cmp	x28, #0x18
    9b80:	540000e9 	b.ls	9b9c <fwp_main_thread+0x5ec>  // b.plast
    9b84:	d1006782 	sub	x2, x28, #0x19
    9b88:	91006300 	add	x0, x24, #0x18
    9b8c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    9b90:	52800001 	mov	w1, #0x0                   	// #0
    9b94:	91002042 	add	x2, x2, #0x8
    9b98:	97ffe30a 	bl	27c0 <memset@plt>
    9b9c:	f94a1260 	ldr	x0, [x19, #5152]
    9ba0:	ab1c0000 	adds	x0, x0, x28
    9ba4:	540079c2 	b.cs	aadc <fwp_main_thread+0x152c>  // b.hs, b.nlast
    9ba8:	f94a1661 	ldr	x1, [x19, #5160]
    9bac:	f90a1260 	str	x0, [x19, #5152]
    9bb0:	eb01001f 	cmp	x0, x1
    9bb4:	54000049 	b.ls	9bbc <fwp_main_thread+0x60c>  // b.plast
    9bb8:	f90a1660 	str	x0, [x19, #5160]
    9bbc:	1e630361 	ucvtf	d1, w27
    9bc0:	fd4a1e60 	ldr	d0, [x19, #5176]
    9bc4:	1e612800 	fadd	d0, d0, d1
    9bc8:	fd0a1e60 	str	d0, [x19, #5176]
    9bcc:	a900d719 	stp	x25, x21, [x24, #8]
    9bd0:	aa1803f5 	mov	x21, x24
    9bd4:	fd000308 	str	d8, [x24]
    9bd8:	f949da62 	ldr	x2, [x19, #5040]
    9bdc:	f949ee60 	ldr	x0, [x19, #5080]
    9be0:	cb020302 	sub	x2, x24, x2
    9be4:	eb00405f 	cmp	x2, x0, lsl #16
    9be8:	54000302 	b.cs	9c48 <fwp_main_thread+0x698>  // b.hs, b.nlast
    9bec:	d350fc40 	lsr	x0, x2, #16
    9bf0:	f949fe64 	ldr	x4, [x19, #5112]
    9bf4:	8b000800 	add	x0, x0, x0, lsl #2
    9bf8:	d37df001 	lsl	x1, x0, #3
    9bfc:	8b010080 	add	x0, x4, x1
    9c00:	f940101c 	ldr	x28, [x0, #32]
    9c04:	b400023c 	cbz	x28, 9c48 <fwp_main_thread+0x698>
    9c08:	38616881 	ldrb	w1, [x4, x1]
    9c0c:	7100083f 	cmp	w1, #0x2
    9c10:	540035a0 	b.eq	a2c4 <fwp_main_thread+0xd14>  // b.none
    9c14:	7100043f 	cmp	w1, #0x1
    9c18:	54000181 	b.ne	9c48 <fwp_main_thread+0x698>  // b.any
    9c1c:	29430004 	ldp	w4, w0, [x0, #24]
    9c20:	92403c41 	and	x1, x2, #0xffff
    9c24:	9b047c21 	mul	x1, x1, x4
    9c28:	d360fc21 	lsr	x1, x1, #32
    9c2c:	eb00003f 	cmp	x1, x0
    9c30:	540000c2 	b.cs	9c48 <fwp_main_thread+0x698>  // b.hs, b.nlast
    9c34:	8b01039c 	add	x28, x28, x1
    9c38:	39400380 	ldrb	w0, [x28]
    9c3c:	7103fc1f 	cmp	w0, #0xff
    9c40:	540034c0 	b.eq	a2d8 <fwp_main_thread+0xd28>  // b.none
    9c44:	39000397 	strb	w23, [x28]
    9c48:	f81203b8 	stur	x24, [x29, #-224]
    9c4c:	aa160339 	orr	x25, x25, x22
    9c50:	b5fff739 	cbnz	x25, 9b34 <fwp_main_thread+0x584>
    9c54:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9c58:	d10303a1 	sub	x1, x29, #0xc0
    9c5c:	f85083a3 	ldur	x3, [x29, #-248]
    9c60:	f95f7816 	ldr	x22, [x0, #16112]
    9c64:	f91f7418 	str	x24, [x0, #16104]
    9c68:	f95f7c1b 	ldr	x27, [x0, #16120]
    9c6c:	f0000000 	adrp	x0, c000 <msg.4+0x20>
    9c70:	3dc00c00 	ldr	q0, [x0, #48]
    9c74:	f00000a0 	adrp	x0, 20000 <__data_start>
    9c78:	91010002 	add	x2, x0, #0x40
    9c7c:	52800020 	mov	w0, #0x1                   	// #1
    9c80:	3c9403a0 	stur	q0, [x29, #-192]
    9c84:	f9016043 	str	x3, [x2, #704]
    9c88:	97ffee0f 	bl	54c4 <fwp_data.part.0.constprop.0>
    9c8c:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9c90:	91154022 	add	x2, x1, #0x550
    9c94:	aa0003f4 	mov	x20, x0
    9c98:	f949d841 	ldr	x1, [x2, #5040]
    9c9c:	f949ec40 	ldr	x0, [x2, #5080]
    9ca0:	cb010281 	sub	x1, x20, x1
    9ca4:	eb00403f 	cmp	x1, x0, lsl #16
    9ca8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9cac:	f95f7406 	ldr	x6, [x0, #16104]
    9cb0:	54000322 	b.cs	9d14 <fwp_main_thread+0x764>  // b.hs, b.nlast
    9cb4:	d350fc20 	lsr	x0, x1, #16
    9cb8:	f949fc43 	ldr	x3, [x2, #5112]
    9cbc:	8b000800 	add	x0, x0, x0, lsl #2
    9cc0:	d37df002 	lsl	x2, x0, #3
    9cc4:	8b020060 	add	x0, x3, x2
    9cc8:	f9401013 	ldr	x19, [x0, #32]
    9ccc:	b4000253 	cbz	x19, 9d14 <fwp_main_thread+0x764>
    9cd0:	38626862 	ldrb	w2, [x3, x2]
    9cd4:	7100085f 	cmp	w2, #0x2
    9cd8:	54006b60 	b.eq	aa44 <fwp_main_thread+0x1494>  // b.none
    9cdc:	7100045f 	cmp	w2, #0x1
    9ce0:	540001a1 	b.ne	9d14 <fwp_main_thread+0x764>  // b.any
    9ce4:	29430002 	ldp	w2, w0, [x0, #24]
    9ce8:	92403c21 	and	x1, x1, #0xffff
    9cec:	9b027c21 	mul	x1, x1, x2
    9cf0:	d360fc21 	lsr	x1, x1, #32
    9cf4:	eb00003f 	cmp	x1, x0
    9cf8:	540000e2 	b.cs	9d14 <fwp_main_thread+0x764>  // b.hs, b.nlast
    9cfc:	8b010273 	add	x19, x19, x1
    9d00:	39400260 	ldrb	w0, [x19]
    9d04:	7103fc1f 	cmp	w0, #0xff
    9d08:	54006b40 	b.eq	aa70 <fwp_main_thread+0x14c0>  // b.none
    9d0c:	52800020 	mov	w0, #0x1                   	// #1
    9d10:	39000260 	strb	w0, [x19]
    9d14:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d18:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9d1c:	aa1603e1 	mov	x1, x22
    9d20:	a93653a2 	stp	x2, x20, [x29, #-160]
    9d24:	f91f7c06 	str	x6, [x0, #16120]
    9d28:	52800020 	mov	w0, #0x1                   	// #1
    9d2c:	97ffede6 	bl	54c4 <fwp_data.part.0.constprop.0>
    9d30:	aa0003f4 	mov	x20, x0
    9d34:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9d38:	91154022 	add	x2, x1, #0x550
    9d3c:	f949d841 	ldr	x1, [x2, #5040]
    9d40:	f949ec40 	ldr	x0, [x2, #5080]
    9d44:	cb010281 	sub	x1, x20, x1
    9d48:	eb00403f 	cmp	x1, x0, lsl #16
    9d4c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d50:	f95f7c06 	ldr	x6, [x0, #16120]
    9d54:	54000322 	b.cs	9db8 <fwp_main_thread+0x808>  // b.hs, b.nlast
    9d58:	d350fc20 	lsr	x0, x1, #16
    9d5c:	f949fc43 	ldr	x3, [x2, #5112]
    9d60:	8b000800 	add	x0, x0, x0, lsl #2
    9d64:	d37df002 	lsl	x2, x0, #3
    9d68:	8b020060 	add	x0, x3, x2
    9d6c:	f9401013 	ldr	x19, [x0, #32]
    9d70:	b4000253 	cbz	x19, 9db8 <fwp_main_thread+0x808>
    9d74:	38626862 	ldrb	w2, [x3, x2]
    9d78:	7100085f 	cmp	w2, #0x2
    9d7c:	540065e0 	b.eq	aa38 <fwp_main_thread+0x1488>  // b.none
    9d80:	7100045f 	cmp	w2, #0x1
    9d84:	540001a1 	b.ne	9db8 <fwp_main_thread+0x808>  // b.any
    9d88:	29430002 	ldp	w2, w0, [x0, #24]
    9d8c:	92403c21 	and	x1, x1, #0xffff
    9d90:	9b027c21 	mul	x1, x1, x2
    9d94:	d360fc21 	lsr	x1, x1, #32
    9d98:	eb00003f 	cmp	x1, x0
    9d9c:	540000e2 	b.cs	9db8 <fwp_main_thread+0x808>  // b.hs, b.nlast
    9da0:	8b010273 	add	x19, x19, x1
    9da4:	39400260 	ldrb	w0, [x19]
    9da8:	7103fc1f 	cmp	w0, #0xff
    9dac:	540067c0 	b.eq	aaa4 <fwp_main_thread+0x14f4>  // b.none
    9db0:	52800020 	mov	w0, #0x1                   	// #1
    9db4:	39000260 	strb	w0, [x19]
    9db8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9dbc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9dc0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9dc4:	d102c3a1 	sub	x1, x29, #0xb0
    9dc8:	a93553a2 	stp	x2, x20, [x29, #-176]
    9dcc:	f91f7c06 	str	x6, [x0, #16120]
    9dd0:	52800020 	mov	w0, #0x1                   	// #1
    9dd4:	97ffedbc 	bl	54c4 <fwp_data.part.0.constprop.0>
    9dd8:	aa0003f6 	mov	x22, x0
    9ddc:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9de0:	91154023 	add	x3, x1, #0x550
    9de4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9de8:	f949ec62 	ldr	x2, [x3, #5080]
    9dec:	f949d861 	ldr	x1, [x3, #5040]
    9df0:	d370bc42 	lsl	x2, x2, #16
    9df4:	cb0102c1 	sub	x1, x22, x1
    9df8:	f95f7c06 	ldr	x6, [x0, #16120]
    9dfc:	eb02003f 	cmp	x1, x2
    9e00:	540003e2 	b.cs	9e7c <fwp_main_thread+0x8cc>  // b.hs, b.nlast
    9e04:	d350fc20 	lsr	x0, x1, #16
    9e08:	f949fc64 	ldr	x4, [x3, #5112]
    9e0c:	8b000800 	add	x0, x0, x0, lsl #2
    9e10:	d37df003 	lsl	x3, x0, #3
    9e14:	8b030080 	add	x0, x4, x3
    9e18:	f9401013 	ldr	x19, [x0, #32]
    9e1c:	b4000313 	cbz	x19, 9e7c <fwp_main_thread+0x8cc>
    9e20:	38636883 	ldrb	w3, [x4, x3]
    9e24:	7100087f 	cmp	w3, #0x2
    9e28:	540061a0 	b.eq	aa5c <fwp_main_thread+0x14ac>  // b.none
    9e2c:	7100047f 	cmp	w3, #0x1
    9e30:	54000261 	b.ne	9e7c <fwp_main_thread+0x8cc>  // b.any
    9e34:	29430004 	ldp	w4, w0, [x0, #24]
    9e38:	92403c23 	and	x3, x1, #0xffff
    9e3c:	9b047c63 	mul	x3, x3, x4
    9e40:	d360fc63 	lsr	x3, x3, #32
    9e44:	eb00007f 	cmp	x3, x0
    9e48:	540001a2 	b.cs	9e7c <fwp_main_thread+0x8cc>  // b.hs, b.nlast
    9e4c:	8b030273 	add	x19, x19, x3
    9e50:	39400260 	ldrb	w0, [x19]
    9e54:	7103fc1f 	cmp	w0, #0xff
    9e58:	54006340 	b.eq	aac0 <fwp_main_thread+0x1510>  // b.none
    9e5c:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9e60:	91154000 	add	x0, x0, #0x550
    9e64:	52800021 	mov	w1, #0x1                   	// #1
    9e68:	39000261 	strb	w1, [x19]
    9e6c:	f949ec02 	ldr	x2, [x0, #5080]
    9e70:	f949d801 	ldr	x1, [x0, #5040]
    9e74:	d370bc42 	lsl	x2, x2, #16
    9e78:	cb0102c1 	sub	x1, x22, x1
    9e7c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9e80:	f00000a5 	adrp	x5, 20000 <__data_start>
    9e84:	910040b7 	add	x23, x5, #0x10
    9e88:	d10403b3 	sub	x19, x29, #0x100
    9e8c:	910022f7 	add	x23, x23, #0x8
    9e90:	f91f5406 	str	x6, [x0, #16040]
    9e94:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e98:	9101001c 	add	x28, x0, #0x40
    9e9c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9ea0:	f91f4c06 	str	x6, [x0, #16024]
    9ea4:	aa1703e6 	mov	x6, x23
    9ea8:	f91f5005 	str	x5, [x0, #16032]
    9eac:	f91f581b 	str	x27, [x0, #16048]
    9eb0:	f91f5c16 	str	x22, [x0, #16056]
    9eb4:	eb02003f 	cmp	x1, x2
    9eb8:	54000382 	b.cs	9f28 <fwp_main_thread+0x978>  // b.hs, b.nlast
    9ebc:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9ec0:	91154002 	add	x2, x0, #0x550
    9ec4:	d350fc20 	lsr	x0, x1, #16
    9ec8:	f949fc44 	ldr	x4, [x2, #5112]
    9ecc:	8b000800 	add	x0, x0, x0, lsl #2
    9ed0:	d37df002 	lsl	x2, x0, #3
    9ed4:	8b020083 	add	x3, x4, x2
    9ed8:	f9401060 	ldr	x0, [x3, #32]
    9edc:	b4000260 	cbz	x0, 9f28 <fwp_main_thread+0x978>
    9ee0:	38626882 	ldrb	w2, [x4, x2]
    9ee4:	7100085f 	cmp	w2, #0x2
    9ee8:	54005b40 	b.eq	aa50 <fwp_main_thread+0x14a0>  // b.none
    9eec:	7100045f 	cmp	w2, #0x1
    9ef0:	540001c1 	b.ne	9f28 <fwp_main_thread+0x978>  // b.any
    9ef4:	29430864 	ldp	w4, w2, [x3, #24]
    9ef8:	92403c21 	and	x1, x1, #0xffff
    9efc:	9b047c21 	mul	x1, x1, x4
    9f00:	d360fc21 	lsr	x1, x1, #32
    9f04:	eb02003f 	cmp	x1, x2
    9f08:	54000102 	b.cs	9f28 <fwp_main_thread+0x978>  // b.hs, b.nlast
    9f0c:	8b010000 	add	x0, x0, x1
    9f10:	39400001 	ldrb	w1, [x0]
    9f14:	340000a1 	cbz	w1, 9f28 <fwp_main_thread+0x978>
    9f18:	7103f43f 	cmp	w1, #0xfd
    9f1c:	54005b88 	b.hi	aa8c <fwp_main_thread+0x14dc>  // b.pmore
    9f20:	11000421 	add	w1, w1, #0x1
    9f24:	39000001 	strb	w1, [x0]
    9f28:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9f2c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9f30:	f9401f83 	ldr	x3, [x28, #56]
    9f34:	f95f5000 	ldr	x0, [x0, #16032]
    9f38:	f95f5c21 	ldr	x1, [x1, #16056]
    9f3c:	91004000 	add	x0, x0, #0x10
    9f40:	f81003a1 	stur	x1, [x29, #-256]
    9f44:	91002004 	add	x4, x0, #0x8
    9f48:	b9400801 	ldr	w1, [x0, #8]
    9f4c:	d37be821 	lsl	x1, x1, #5
    9f50:	8b010065 	add	x5, x3, x1
    9f54:	f9400ca2 	ldr	x2, [x5, #24]
    9f58:	b4005cc2 	cbz	x2, aaf0 <fwp_main_thread+0x1540>
    9f5c:	f9400c40 	ldr	x0, [x2, #24]
    9f60:	b4004880 	cbz	x0, a870 <fwp_main_thread+0x12c0>
    9f64:	90000140 	adrp	x0, 31000 <fwp_root_context+0xc90>
    9f68:	91154002 	add	x2, x0, #0x550
    9f6c:	f949d841 	ldr	x1, [x2, #5040]
    9f70:	f949ec40 	ldr	x0, [x2, #5080]
    9f74:	cb0100c1 	sub	x1, x6, x1
    9f78:	eb00403f 	cmp	x1, x0, lsl #16
    9f7c:	54000342 	b.cs	9fe4 <fwp_main_thread+0xa34>  // b.hs, b.nlast
    9f80:	d350fc20 	lsr	x0, x1, #16
    9f84:	f949fc44 	ldr	x4, [x2, #5112]
    9f88:	8b000800 	add	x0, x0, x0, lsl #2
    9f8c:	d37df002 	lsl	x2, x0, #3
    9f90:	8b020083 	add	x3, x4, x2
    9f94:	f9401060 	ldr	x0, [x3, #32]
    9f98:	b4000260 	cbz	x0, 9fe4 <fwp_main_thread+0xa34>
    9f9c:	38626882 	ldrb	w2, [x4, x2]
    9fa0:	7100085f 	cmp	w2, #0x2
    9fa4:	54004dc0 	b.eq	a95c <fwp_main_thread+0x13ac>  // b.none
    9fa8:	7100045f 	cmp	w2, #0x1
    9fac:	540001c1 	b.ne	9fe4 <fwp_main_thread+0xa34>  // b.any
    9fb0:	29430864 	ldp	w4, w2, [x3, #24]
    9fb4:	92403c21 	and	x1, x1, #0xffff
    9fb8:	9b047c21 	mul	x1, x1, x4
    9fbc:	d360fc21 	lsr	x1, x1, #32
    9fc0:	eb02003f 	cmp	x1, x2
    9fc4:	54000102 	b.cs	9fe4 <fwp_main_thread+0xa34>  // b.hs, b.nlast
    9fc8:	8b010000 	add	x0, x0, x1
    9fcc:	39400001 	ldrb	w1, [x0]
    9fd0:	340000a1 	cbz	w1, 9fe4 <fwp_main_thread+0xa34>
    9fd4:	7103f43f 	cmp	w1, #0xfd
    9fd8:	540050c8 	b.hi	a9f0 <fwp_main_thread+0x1440>  // b.pmore
    9fdc:	11000421 	add	w1, w1, #0x1
    9fe0:	39000001 	strb	w1, [x0]
    9fe4:	90000141 	adrp	x1, 31000 <fwp_root_context+0xc90>
    9fe8:	91154035 	add	x21, x1, #0x550
    9fec:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9ff0:	aa0603f8 	mov	x24, x6
    9ff4:	aa1303fb 	mov	x27, x19
    9ff8:	aa0603e0 	mov	x0, x6
    9ffc:	52800034 	mov	w20, #0x1                   	// #1
    a000:	f91f6033 	str	x19, [x1, #16064]
    a004:	f91f6426 	str	x6, [x1, #16072]
    a008:	b93ee834 	str	w20, [x1, #16104]
    a00c:	b93ef034 	str	w20, [x1, #16112]
    a010:	b94000a2 	ldr	w2, [x5]
    a014:	b9400401 	ldr	w1, [x0, #4]
    a018:	4b010040 	sub	w0, w2, w1
    a01c:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a020:	b93ee440 	str	w0, [x2, #16100]
    a024:	b97ee842 	ldr	w2, [x2, #16104]
    a028:	6b02001f 	cmp	w0, w2
    a02c:	1a829019 	csel	w25, w0, w2, ls	// ls = plast
    a030:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a034:	b97ef000 	ldr	w0, [x0, #16112]
    a038:	6b00033f 	cmp	w25, w0
    a03c:	1a809336 	csel	w22, w25, w0, ls	// ls = plast
    a040:	6b160322 	subs	w2, w25, w22
    a044:	540000c0 	b.eq	a05c <fwp_main_thread+0xaac>  // b.none
    a048:	f9400ca4 	ldr	x4, [x5, #24]
    a04c:	0b160021 	add	w1, w1, w22
    a050:	8b364f60 	add	x0, x27, w22, uxtw #3
    a054:	f9400884 	ldr	x4, [x4, #16]
    a058:	d63f0080 	blr	x4
    a05c:	f9401f80 	ldr	x0, [x28, #56]
    a060:	aa1803e7 	mov	x7, x24
    a064:	b9400304 	ldr	w4, [x24]
    a068:	aa1b03fa 	mov	x26, x27
    a06c:	2a1903f7 	mov	w23, w25
    a070:	aa1803e9 	mov	x9, x24
    a074:	8b041404 	add	x4, x0, x4, lsl #5
    a078:	f9400c88 	ldr	x8, [x4, #24]
    a07c:	b4001488 	cbz	x8, a30c <fwp_main_thread+0xd5c>
    a080:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a084:	aa0403f4 	mov	x20, x4
    a088:	f91f681b 	str	x27, [x0, #16080]
    a08c:	b93ed816 	str	w22, [x0, #16088]
    a090:	b93ee019 	str	w25, [x0, #16096]
    a094:	14000012 	b	a0dc <fwp_main_thread+0xb2c>
    a098:	f9400101 	ldr	x1, [x8]
    a09c:	aa1a03e0 	mov	x0, x26
    a0a0:	d63f0020 	blr	x1
    a0a4:	aa0003fb 	mov	x27, x0
    a0a8:	aa1803e0 	mov	x0, x24
    a0ac:	97ffee6d 	bl	5a60 <fwp_closure_drop>
    a0b0:	6b1702df 	cmp	w22, w23
    a0b4:	54000d00 	b.eq	a254 <fwp_main_thread+0xca4>  // b.none
    a0b8:	f9401f80 	ldr	x0, [x28, #56]
    a0bc:	8b364f5a 	add	x26, x26, w22, uxtw #3
    a0c0:	b9400364 	ldr	w4, [x27]
    a0c4:	4b130337 	sub	w23, w25, w19
    a0c8:	aa1b03e7 	mov	x7, x27
    a0cc:	8b041414 	add	x20, x0, x4, lsl #5
    a0d0:	f9400e88 	ldr	x8, [x20, #24]
    a0d4:	b4001128 	cbz	x8, a2f8 <fwp_main_thread+0xd48>
    a0d8:	aa1b03f8 	mov	x24, x27
    a0dc:	b94004e9 	ldr	w9, [x7, #4]
    a0e0:	b9400293 	ldr	w19, [x20]
    a0e4:	0b170139 	add	w25, w9, w23
    a0e8:	6b19027f 	cmp	w19, w25
    a0ec:	54002a28 	b.hi	a630 <fwp_main_thread+0x1080>  // b.pmore
    a0f0:	7100013f 	cmp	w9, #0x0
    a0f4:	4b090276 	sub	w22, w19, w9
    a0f8:	7a400a64 	ccmp	w19, #0x0, #0x4, eq	// eq = none
    a0fc:	54fffce1 	b.ne	a098 <fwp_main_thread+0xae8>  // b.any
    a100:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a104:	910003e0 	mov	x0, sp
    a108:	7100027f 	cmp	w19, #0x0
    a10c:	f91f7c20 	str	x0, [x1, #16120]
    a110:	1a9f1660 	csinc	w0, w19, wzr, ne	// ne = any
    a114:	d37df000 	lsl	x0, x0, #3
    a118:	91003c00 	add	x0, x0, #0xf
    a11c:	92704c01 	and	x1, x0, #0xfffff0000
    a120:	927c7c00 	and	x0, x0, #0xffffffff0
    a124:	cb2163e1 	sub	x1, sp, x1
    a128:	eb2163ff 	cmp	sp, x1
    a12c:	540000a0 	b.eq	a140 <fwp_main_thread+0xb90>  // b.none
    a130:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a134:	f90203ff 	str	xzr, [sp, #1024]
    a138:	eb2163ff 	cmp	sp, x1
    a13c:	54ffffa1 	b.ne	a130 <fwp_main_thread+0xb80>  // b.any
    a140:	92403c00 	and	x0, x0, #0xffff
    a144:	cb2063ff 	sub	sp, sp, x0
    a148:	f90003ff 	str	xzr, [sp]
    a14c:	f110001f 	cmp	x0, #0x400
    a150:	54000043 	b.cc	a158 <fwp_main_thread+0xba8>  // b.lo, b.ul, b.last
    a154:	f90203ff 	str	xzr, [sp, #1024]
    a158:	910043fb 	add	x27, sp, #0x10
    a15c:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a160:	910020e1 	add	x1, x7, #0x8
    a164:	d2800000 	mov	x0, #0x0                   	// #0
    a168:	340000e9 	cbz	w9, a184 <fwp_main_thread+0xbd4>
    a16c:	d503201f 	nop
    a170:	f8606823 	ldr	x3, [x1, x0]
    a174:	f8206b63 	str	x3, [x27, x0]
    a178:	91002000 	add	x0, x0, #0x8
    a17c:	eb02001f 	cmp	x0, x2
    a180:	54ffff81 	b.ne	a170 <fwp_main_thread+0xbc0>  // b.any
    a184:	2a1603e1 	mov	w1, w22
    a188:	d2800000 	mov	x0, #0x0                   	// #0
    a18c:	340000f6 	cbz	w22, a1a8 <fwp_main_thread+0xbf8>
    a190:	0b000122 	add	w2, w9, w0
    a194:	f8607b43 	ldr	x3, [x26, x0, lsl #3]
    a198:	91000400 	add	x0, x0, #0x1
    a19c:	f8227b63 	str	x3, [x27, x2, lsl #3]
    a1a0:	eb01001f 	cmp	x0, x1
    a1a4:	54ffff61 	b.ne	a190 <fwp_main_thread+0xbe0>  // b.any
    a1a8:	f949daa0 	ldr	x0, [x21, #5040]
    a1ac:	f949eea1 	ldr	x1, [x21, #5080]
    a1b0:	cb000300 	sub	x0, x24, x0
    a1b4:	eb01401f 	cmp	x0, x1, lsl #16
    a1b8:	540002e2 	b.cs	a214 <fwp_main_thread+0xc64>  // b.hs, b.nlast
    a1bc:	d350fc01 	lsr	x1, x0, #16
    a1c0:	f949fea5 	ldr	x5, [x21, #5112]
    a1c4:	8b010821 	add	x1, x1, x1, lsl #2
    a1c8:	d37df021 	lsl	x1, x1, #3
    a1cc:	8b0100a3 	add	x3, x5, x1
    a1d0:	f9401062 	ldr	x2, [x3, #32]
    a1d4:	b4000202 	cbz	x2, a214 <fwp_main_thread+0xc64>
    a1d8:	386168a1 	ldrb	w1, [x5, x1]
    a1dc:	7100083f 	cmp	w1, #0x2
    a1e0:	54000860 	b.eq	a2ec <fwp_main_thread+0xd3c>  // b.none
    a1e4:	7100043f 	cmp	w1, #0x1
    a1e8:	54000161 	b.ne	a214 <fwp_main_thread+0xc64>  // b.any
    a1ec:	29430465 	ldp	w5, w1, [x3, #24]
    a1f0:	92403c00 	and	x0, x0, #0xffff
    a1f4:	9b057c00 	mul	x0, x0, x5
    a1f8:	d360fc00 	lsr	x0, x0, #32
    a1fc:	eb01001f 	cmp	x0, x1
    a200:	540000a2 	b.cs	a214 <fwp_main_thread+0xc64>  // b.hs, b.nlast
    a204:	8b000042 	add	x2, x2, x0
    a208:	39400040 	ldrb	w0, [x2]
    a20c:	7100041f 	cmp	w0, #0x1
    a210:	540006a0 	b.eq	a2e4 <fwp_main_thread+0xd34>  // b.none
    a214:	f9400502 	ldr	x2, [x8, #8]
    a218:	aa1803e0 	mov	x0, x24
    a21c:	52800021 	mov	w1, #0x1                   	// #1
    a220:	d63f0040 	blr	x2
    a224:	f9400e81 	ldr	x1, [x20, #24]
    a228:	aa1b03e0 	mov	x0, x27
    a22c:	f9400021 	ldr	x1, [x1]
    a230:	d63f0020 	blr	x1
    a234:	aa0003fb 	mov	x27, x0
    a238:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a23c:	f95f7c00 	ldr	x0, [x0, #16120]
    a240:	9100001f 	mov	sp, x0
    a244:	aa1803e0 	mov	x0, x24
    a248:	97ffee06 	bl	5a60 <fwp_closure_drop>
    a24c:	6b1702df 	cmp	w22, w23
    a250:	54fff341 	b.ne	a0b8 <fwp_main_thread+0xb08>  // b.any
    a254:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a258:	aa1b03f8 	mov	x24, x27
    a25c:	f95f681b 	ldr	x27, [x0, #16080]
    a260:	b97ed816 	ldr	w22, [x0, #16088]
    a264:	b97ee019 	ldr	w25, [x0, #16096]
    a268:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a26c:	b97ee401 	ldr	w1, [x0, #16100]
    a270:	b97ee800 	ldr	w0, [x0, #16104]
    a274:	6b00003f 	cmp	w1, w0
    a278:	540007e3 	b.cc	a374 <fwp_main_thread+0xdc4>  // b.lo, b.ul, b.last
    a27c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a280:	f95f6013 	ldr	x19, [x0, #16064]
    a284:	f95f6406 	ldr	x6, [x0, #16072]
    a288:	14000063 	b	a414 <fwp_main_thread+0xe64>
    a28c:	f9400438 	ldr	x24, [x1, #8]
    a290:	b4000118 	cbz	x24, a2b0 <fwp_main_thread+0xd00>
    a294:	f9400820 	ldr	x0, [x1, #16]
    a298:	cb180000 	sub	x0, x0, x24
    a29c:	eb00039f 	cmp	x28, x0
    a2a0:	54000088 	b.hi	a2b0 <fwp_main_thread+0xd00>  // b.pmore
    a2a4:	8b1c0300 	add	x0, x24, x28
    a2a8:	f9000420 	str	x0, [x1, #8]
    a2ac:	17fffe34 	b	9b7c <fwp_main_thread+0x5cc>
    a2b0:	52800001 	mov	w1, #0x0                   	// #0
    a2b4:	d2800300 	mov	x0, #0x18                  	// #24
    a2b8:	97ffea4e 	bl	4bf0 <fwp_heap_alloc>
    a2bc:	aa0003f8 	mov	x24, x0
    a2c0:	17fffe43 	b	9bcc <fwp_main_thread+0x61c>
    a2c4:	72003c5f 	tst	w2, #0xffff
    a2c8:	54ffcc01 	b.ne	9c48 <fwp_main_thread+0x698>  // b.any
    a2cc:	39400380 	ldrb	w0, [x28]
    a2d0:	7103fc1f 	cmp	w0, #0xff
    a2d4:	54ffcb81 	b.ne	9c44 <fwp_main_thread+0x694>  // b.any
    a2d8:	aa1c03e0 	mov	x0, x28
    a2dc:	97ffe885 	bl	44f0 <fwp_rc_forget_slot>
    a2e0:	17fffe59 	b	9c44 <fwp_main_thread+0x694>
    a2e4:	b90004ff 	str	wzr, [x7, #4]
    a2e8:	17ffffcf 	b	a224 <fwp_main_thread+0xc74>
    a2ec:	72003c1f 	tst	w0, #0xffff
    a2f0:	54fff921 	b.ne	a214 <fwp_main_thread+0xc64>  // b.any
    a2f4:	17ffffc5 	b	a208 <fwp_main_thread+0xc58>
    a2f8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a2fc:	aa1b03e9 	mov	x9, x27
    a300:	f95f681b 	ldr	x27, [x0, #16080]
    a304:	b97ed816 	ldr	w22, [x0, #16088]
    a308:	b97ee019 	ldr	w25, [x0, #16096]
    a30c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a310:	aa0903e0 	mov	x0, x9
    a314:	f91f7c29 	str	x9, [x1, #16120]
    a318:	97ffecb3 	bl	55e4 <fwp_rc_share>
    a31c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a320:	f95f7c09 	ldr	x9, [x0, #16120]
    a324:	34000157 	cbz	w23, a34c <fwp_main_thread+0xd9c>
    a328:	8b374f53 	add	x19, x26, w23, uxtw #3
    a32c:	aa1a03f4 	mov	x20, x26
    a330:	aa0903f8 	mov	x24, x9
    a334:	d503201f 	nop
    a338:	f8408680 	ldr	x0, [x20], #8
    a33c:	97ffecaa 	bl	55e4 <fwp_rc_share>
    a340:	eb13029f 	cmp	x20, x19
    a344:	54ffffa1 	b.ne	a338 <fwp_main_thread+0xd88>  // b.any
    a348:	aa1803e9 	mov	x9, x24
    a34c:	aa1a03e2 	mov	x2, x26
    a350:	2a1703e1 	mov	w1, w23
    a354:	aa0903e0 	mov	x0, x9
    a358:	97ffea6b 	bl	4d04 <fwp_apply>
    a35c:	aa0003f8 	mov	x24, x0
    a360:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a364:	b97ee401 	ldr	w1, [x0, #16100]
    a368:	b97ee800 	ldr	w0, [x0, #16104]
    a36c:	6b00003f 	cmp	w1, w0
    a370:	54fff862 	b.cs	a27c <fwp_main_thread+0xccc>  // b.hs, b.nlast
    a374:	f9401f81 	ldr	x1, [x28, #56]
    a378:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a37c:	b9400305 	ldr	w5, [x24]
    a380:	4b190000 	sub	w0, w0, w25
    a384:	8b394f7b 	add	x27, x27, w25, uxtw #3
    a388:	b93ee840 	str	w0, [x2, #16104]
    a38c:	8b051425 	add	x5, x1, x5, lsl #5
    a390:	b97ef040 	ldr	w0, [x2, #16112]
    a394:	4b160000 	sub	w0, w0, w22
    a398:	b93ef040 	str	w0, [x2, #16112]
    a39c:	f9400ca1 	ldr	x1, [x5, #24]
    a3a0:	aa1803e0 	mov	x0, x24
    a3a4:	b5ffe361 	cbnz	x1, a010 <fwp_main_thread+0xa60>
    a3a8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3ac:	f95f6406 	ldr	x6, [x0, #16072]
    a3b0:	f91f7c06 	str	x6, [x0, #16120]
    a3b4:	f95f6013 	ldr	x19, [x0, #16064]
    a3b8:	b97ee814 	ldr	w20, [x0, #16104]
    a3bc:	aa1803e0 	mov	x0, x24
    a3c0:	97ffec89 	bl	55e4 <fwp_rc_share>
    a3c4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3c8:	f95f7c06 	ldr	x6, [x0, #16120]
    a3cc:	34000134 	cbz	w20, a3f0 <fwp_main_thread+0xe40>
    a3d0:	aa0603fa 	mov	x26, x6
    a3d4:	d2800015 	mov	x21, #0x0                   	// #0
    a3d8:	f8757b60 	ldr	x0, [x27, x21, lsl #3]
    a3dc:	910006b5 	add	x21, x21, #0x1
    a3e0:	97ffec81 	bl	55e4 <fwp_rc_share>
    a3e4:	6b15029f 	cmp	w20, w21
    a3e8:	54ffff88 	b.hi	a3d8 <fwp_main_thread+0xe28>  // b.pmore
    a3ec:	aa1a03e6 	mov	x6, x26
    a3f0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3f4:	aa1b03e2 	mov	x2, x27
    a3f8:	2a1403e1 	mov	w1, w20
    a3fc:	f91f7c06 	str	x6, [x0, #16120]
    a400:	aa1803e0 	mov	x0, x24
    a404:	97ffea40 	bl	4d04 <fwp_apply>
    a408:	aa0003f8 	mov	x24, x0
    a40c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a410:	f95f7c06 	ldr	x6, [x0, #16120]
    a414:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a418:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10c10>
    a41c:	91102042 	add	x2, x2, #0x408
    a420:	91014042 	add	x2, x2, #0x50
    a424:	aa1803e1 	mov	x1, x24
    a428:	f91f7c06 	str	x6, [x0, #16120]
    a42c:	52800023 	mov	w3, #0x1                   	// #1
    a430:	f95f5800 	ldr	x0, [x0, #16048]
    a434:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a438:	f81303bf 	stur	xzr, [x29, #-208]
    a43c:	97fff861 	bl	85c0 <fwp_write>
    a440:	a9726bb5 	ldp	x21, x26, [x29, #-224]
    a444:	b0000000 	adrp	x0, b000 <__modti3+0x30>
    a448:	9135a000 	add	x0, x0, #0xd68
    a44c:	f10002bf 	cmp	x21, #0x0
    a450:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    a454:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a458:	b1002b5f 	cmn	x26, #0xa
    a45c:	f95f7c06 	ldr	x6, [x0, #16120]
    a460:	54003628 	b.hi	ab24 <fwp_main_thread+0x1574>  // b.pmore
    a464:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a468:	52800021 	mov	w1, #0x1                   	// #1
    a46c:	f91f7c06 	str	x6, [x0, #16120]
    a470:	91002740 	add	x0, x26, #0x9
    a474:	97ffe9df 	bl	4bf0 <fwp_heap_alloc>
    a478:	aa0003f4 	mov	x20, x0
    a47c:	aa1503e1 	mov	x1, x21
    a480:	aa0003f5 	mov	x21, x0
    a484:	aa1a03e2 	mov	x2, x26
    a488:	f80086ba 	str	x26, [x21], #8
    a48c:	8b1a029a 	add	x26, x20, x26
    a490:	aa1503e0 	mov	x0, x21
    a494:	97ffe06b 	bl	2640 <memcpy@plt>
    a498:	3900235f 	strb	wzr, [x26, #8]
    a49c:	f85203a0 	ldur	x0, [x29, #-224]
    a4a0:	97ffe104 	bl	28b0 <free@plt>
    a4a4:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a4a8:	91154002 	add	x2, x0, #0x550
    a4ac:	f949d841 	ldr	x1, [x2, #5040]
    a4b0:	f949ec40 	ldr	x0, [x2, #5080]
    a4b4:	cb010281 	sub	x1, x20, x1
    a4b8:	eb00403f 	cmp	x1, x0, lsl #16
    a4bc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4c0:	f95f7c06 	ldr	x6, [x0, #16120]
    a4c4:	54000322 	b.cs	a528 <fwp_main_thread+0xf78>  // b.hs, b.nlast
    a4c8:	d350fc20 	lsr	x0, x1, #16
    a4cc:	f949fc43 	ldr	x3, [x2, #5112]
    a4d0:	8b000800 	add	x0, x0, x0, lsl #2
    a4d4:	d37df002 	lsl	x2, x0, #3
    a4d8:	8b020060 	add	x0, x3, x2
    a4dc:	f940101a 	ldr	x26, [x0, #32]
    a4e0:	b400025a 	cbz	x26, a528 <fwp_main_thread+0xf78>
    a4e4:	38626862 	ldrb	w2, [x3, x2]
    a4e8:	7100085f 	cmp	w2, #0x2
    a4ec:	54003480 	b.eq	ab7c <fwp_main_thread+0x15cc>  // b.none
    a4f0:	7100045f 	cmp	w2, #0x1
    a4f4:	540001a1 	b.ne	a528 <fwp_main_thread+0xf78>  // b.any
    a4f8:	29430002 	ldp	w2, w0, [x0, #24]
    a4fc:	92403c21 	and	x1, x1, #0xffff
    a500:	9b027c21 	mul	x1, x1, x2
    a504:	d360fc21 	lsr	x1, x1, #32
    a508:	eb00003f 	cmp	x1, x0
    a50c:	540000e2 	b.cs	a528 <fwp_main_thread+0xf78>  // b.hs, b.nlast
    a510:	8b01035a 	add	x26, x26, x1
    a514:	39400340 	ldrb	w0, [x26]
    a518:	7103fc1f 	cmp	w0, #0xff
    a51c:	54003800 	b.eq	ac1c <fwp_main_thread+0x166c>  // b.none
    a520:	52800020 	mov	w0, #0x1                   	// #1
    a524:	39000340 	strb	w0, [x26]
    a528:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a52c:	f91f7c06 	str	x6, [x0, #16120]
    a530:	aa1803e0 	mov	x0, x24
    a534:	97ffec9b 	bl	57a0 <fwp_drop0>
    a538:	d00000a0 	adrp	x0, 20000 <__data_start>
    a53c:	91010003 	add	x3, x0, #0x40
    a540:	f9400282 	ldr	x2, [x20]
    a544:	aa1503e0 	mov	x0, x21
    a548:	aa0303f5 	mov	x21, x3
    a54c:	d2800021 	mov	x1, #0x1                   	// #1
    a550:	f9400463 	ldr	x3, [x3, #8]
    a554:	97ffe0e7 	bl	28f0 <fwrite@plt>
    a558:	f94006a1 	ldr	x1, [x21, #8]
    a55c:	52800140 	mov	w0, #0xa                   	// #10
    a560:	97ffe06c 	bl	2710 <fputc@plt>
    a564:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a568:	91154002 	add	x2, x0, #0x550
    a56c:	f949d841 	ldr	x1, [x2, #5040]
    a570:	f949ec40 	ldr	x0, [x2, #5080]
    a574:	cb010281 	sub	x1, x20, x1
    a578:	eb00403f 	cmp	x1, x0, lsl #16
    a57c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a580:	f95f7c06 	ldr	x6, [x0, #16120]
    a584:	54000382 	b.cs	a5f4 <fwp_main_thread+0x1044>  // b.hs, b.nlast
    a588:	d350fc20 	lsr	x0, x1, #16
    a58c:	f949fc43 	ldr	x3, [x2, #5112]
    a590:	8b000800 	add	x0, x0, x0, lsl #2
    a594:	d37df000 	lsl	x0, x0, #3
    a598:	8b000062 	add	x2, x3, x0
    a59c:	f9401055 	ldr	x21, [x2, #32]
    a5a0:	b40002b5 	cbz	x21, a5f4 <fwp_main_thread+0x1044>
    a5a4:	38606860 	ldrb	w0, [x3, x0]
    a5a8:	7100081f 	cmp	w0, #0x2
    a5ac:	54002e20 	b.eq	ab70 <fwp_main_thread+0x15c0>  // b.none
    a5b0:	7100041f 	cmp	w0, #0x1
    a5b4:	54000201 	b.ne	a5f4 <fwp_main_thread+0x1044>  // b.any
    a5b8:	29430043 	ldp	w3, w0, [x2, #24]
    a5bc:	92403c21 	and	x1, x1, #0xffff
    a5c0:	9b037c21 	mul	x1, x1, x3
    a5c4:	d360fc21 	lsr	x1, x1, #32
    a5c8:	eb00003f 	cmp	x1, x0
    a5cc:	54000142 	b.cs	a5f4 <fwp_main_thread+0x1044>  // b.hs, b.nlast
    a5d0:	8b0102b5 	add	x21, x21, x1
    a5d4:	394002a0 	ldrb	w0, [x21]
    a5d8:	340000e0 	cbz	w0, a5f4 <fwp_main_thread+0x1044>
    a5dc:	7100041f 	cmp	w0, #0x1
    a5e0:	540030a0 	b.eq	abf4 <fwp_main_thread+0x1644>  // b.none
    a5e4:	7103fc1f 	cmp	w0, #0xff
    a5e8:	54002d00 	b.eq	ab88 <fwp_main_thread+0x15d8>  // b.none
    a5ec:	51000400 	sub	w0, w0, #0x1
    a5f0:	390002a0 	strb	w0, [x21]
    a5f4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a5f8:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a5fc:	f95f5400 	ldr	x0, [x0, #16040]
    a600:	f9400800 	ldr	x0, [x0, #16]
    a604:	f91f5420 	str	x0, [x1, #16040]
    a608:	b4002940 	cbz	x0, ab30 <fwp_main_thread+0x1580>
    a60c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a610:	91154000 	add	x0, x0, #0x550
    a614:	f949d801 	ldr	x1, [x0, #5040]
    a618:	f949ec02 	ldr	x2, [x0, #5080]
    a61c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a620:	f95f5c00 	ldr	x0, [x0, #16056]
    a624:	d370bc42 	lsl	x2, x2, #16
    a628:	cb010001 	sub	x1, x0, x1
    a62c:	17fffe22 	b	9eb4 <fwp_main_thread+0x904>
    a630:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a634:	2a1903e2 	mov	w2, w25
    a638:	aa1403e4 	mov	x4, x20
    a63c:	f95f681b 	ldr	x27, [x0, #16080]
    a640:	b97ed816 	ldr	w22, [x0, #16088]
    a644:	b97ee019 	ldr	w25, [x0, #16096]
    a648:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a64c:	9115400a 	add	x10, x0, #0x550
    a650:	11000440 	add	w0, w2, #0x1
    a654:	f120001f 	cmp	x0, #0x800
    a658:	d37df000 	lsl	x0, x0, #3
    a65c:	b953a541 	ldr	w1, [x10, #5028]
    a660:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a664:	54001940 	b.eq	a98c <fwp_main_thread+0x13dc>  // b.none
    a668:	91003c01 	add	x1, x0, #0xf
    a66c:	8b411141 	add	x1, x10, x1, lsr #4
    a670:	397e8021 	ldrb	w1, [x1, #4000]
    a674:	910f002b 	add	x11, x1, #0x3c0
    a678:	8b010428 	add	x8, x1, x1, lsl #1
    a67c:	b86b794b 	ldr	w11, [x10, x11, lsl #2]
    a680:	8b080d4c 	add	x12, x10, x8, lsl #3
    a684:	f8687953 	ldr	x19, [x10, x8, lsl #3]
    a688:	2a0b03e1 	mov	w1, w11
    a68c:	b40016f3 	cbz	x19, a968 <fwp_main_thread+0x13b8>
    a690:	f940026c 	ldr	x12, [x19]
    a694:	aa2c03ec 	mvn	x12, x12
    a698:	f828794c 	str	x12, [x10, x8, lsl #3]
    a69c:	eb01001f 	cmp	x0, x1
    a6a0:	540000c2 	b.cs	a6b8 <fwp_main_thread+0x1108>  // b.hs, b.nlast
    a6a4:	d503201f 	nop
    a6a8:	f8206a7f 	str	xzr, [x19, x0]
    a6ac:	91002000 	add	x0, x0, #0x8
    a6b0:	eb00003f 	cmp	x1, x0
    a6b4:	54ffffa8 	b.hi	a6a8 <fwp_main_thread+0x10f8>  // b.pmore
    a6b8:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a6bc:	91154008 	add	x8, x0, #0x550
    a6c0:	f94a1100 	ldr	x0, [x8, #5152]
    a6c4:	ab010000 	adds	x0, x0, x1
    a6c8:	540020a2 	b.cs	aadc <fwp_main_thread+0x152c>  // b.hs, b.nlast
    a6cc:	f94a1501 	ldr	x1, [x8, #5160]
    a6d0:	f90a1100 	str	x0, [x8, #5152]
    a6d4:	eb01001f 	cmp	x0, x1
    a6d8:	54000049 	b.ls	a6e0 <fwp_main_thread+0x1130>  // b.plast
    a6dc:	f90a1500 	str	x0, [x8, #5160]
    a6e0:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a6e4:	91154000 	add	x0, x0, #0x550
    a6e8:	1e630161 	ucvtf	d1, w11
    a6ec:	fd4a1c00 	ldr	d0, [x0, #5176]
    a6f0:	1e612800 	fadd	d0, d0, d1
    a6f4:	fd0a1c00 	str	d0, [x0, #5176]
    a6f8:	b94000e0 	ldr	w0, [x7]
    a6fc:	29000a60 	stp	w0, w2, [x19]
    a700:	340001a9 	cbz	w9, a734 <fwp_main_thread+0x1184>
    a704:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a708:	d37d7d22 	ubfiz	x2, x9, #3, #32
    a70c:	910020e1 	add	x1, x7, #0x8
    a710:	f91f6c04 	str	x4, [x0, #16088]
    a714:	b93ee009 	str	w9, [x0, #16096]
    a718:	f91f7c07 	str	x7, [x0, #16120]
    a71c:	91002260 	add	x0, x19, #0x8
    a720:	97ffdfd0 	bl	2660 <memmove@plt>
    a724:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a728:	f95f6c04 	ldr	x4, [x0, #16088]
    a72c:	f95f7c07 	ldr	x7, [x0, #16120]
    a730:	b97ee009 	ldr	w9, [x0, #16096]
    a734:	2a1703e8 	mov	w8, w23
    a738:	d2800001 	mov	x1, #0x0                   	// #0
    a73c:	34000117 	cbz	w23, a75c <fwp_main_thread+0x11ac>
    a740:	0b010120 	add	w0, w9, w1
    a744:	f8617b42 	ldr	x2, [x26, x1, lsl #3]
    a748:	8b000e60 	add	x0, x19, x0, lsl #3
    a74c:	91000421 	add	x1, x1, #0x1
    a750:	f9000402 	str	x2, [x0, #8]
    a754:	eb08003f 	cmp	x1, x8
    a758:	54ffff41 	b.ne	a740 <fwp_main_thread+0x1190>  // b.any
    a75c:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a760:	91154002 	add	x2, x0, #0x550
    a764:	f949d840 	ldr	x0, [x2, #5040]
    a768:	f949ec41 	ldr	x1, [x2, #5080]
    a76c:	cb000300 	sub	x0, x24, x0
    a770:	eb01401f 	cmp	x0, x1, lsl #16
    a774:	540002e2 	b.cs	a7d0 <fwp_main_thread+0x1220>  // b.hs, b.nlast
    a778:	d350fc01 	lsr	x1, x0, #16
    a77c:	f949fc48 	ldr	x8, [x2, #5112]
    a780:	8b010821 	add	x1, x1, x1, lsl #2
    a784:	d37df021 	lsl	x1, x1, #3
    a788:	8b010105 	add	x5, x8, x1
    a78c:	f94010a2 	ldr	x2, [x5, #32]
    a790:	b4000202 	cbz	x2, a7d0 <fwp_main_thread+0x1220>
    a794:	38616901 	ldrb	w1, [x8, x1]
    a798:	7100083f 	cmp	w1, #0x2
    a79c:	54001140 	b.eq	a9c4 <fwp_main_thread+0x1414>  // b.none
    a7a0:	7100043f 	cmp	w1, #0x1
    a7a4:	54000161 	b.ne	a7d0 <fwp_main_thread+0x1220>  // b.any
    a7a8:	294304a8 	ldp	w8, w1, [x5, #24]
    a7ac:	92403c00 	and	x0, x0, #0xffff
    a7b0:	9b087c00 	mul	x0, x0, x8
    a7b4:	d360fc00 	lsr	x0, x0, #32
    a7b8:	eb01001f 	cmp	x0, x1
    a7bc:	540000a2 	b.cs	a7d0 <fwp_main_thread+0x1220>  // b.hs, b.nlast
    a7c0:	8b000042 	add	x2, x2, x0
    a7c4:	39400040 	ldrb	w0, [x2]
    a7c8:	7100041f 	cmp	w0, #0x1
    a7cc:	54000c40 	b.eq	a954 <fwp_main_thread+0x13a4>  // b.none
    a7d0:	f9400c82 	ldr	x2, [x4, #24]
    a7d4:	aa1803e0 	mov	x0, x24
    a7d8:	52800021 	mov	w1, #0x1                   	// #1
    a7dc:	f9400442 	ldr	x2, [x2, #8]
    a7e0:	d63f0040 	blr	x2
    a7e4:	f0000120 	adrp	x0, 31000 <fwp_root_context+0xc90>
    a7e8:	91154002 	add	x2, x0, #0x550
    a7ec:	f949d841 	ldr	x1, [x2, #5040]
    a7f0:	f949ec40 	ldr	x0, [x2, #5080]
    a7f4:	cb010261 	sub	x1, x19, x1
    a7f8:	eb00403f 	cmp	x1, x0, lsl #16
    a7fc:	54000322 	b.cs	a860 <fwp_main_thread+0x12b0>  // b.hs, b.nlast
    a800:	d350fc20 	lsr	x0, x1, #16
    a804:	f949fc44 	ldr	x4, [x2, #5112]
    a808:	8b000800 	add	x0, x0, x0, lsl #2
    a80c:	d37df002 	lsl	x2, x0, #3
    a810:	8b020080 	add	x0, x4, x2
    a814:	f9401017 	ldr	x23, [x0, #32]
    a818:	b4000257 	cbz	x23, a860 <fwp_main_thread+0x12b0>
    a81c:	38626882 	ldrb	w2, [x4, x2]
    a820:	7100085f 	cmp	w2, #0x2
    a824:	54000d60 	b.eq	a9d0 <fwp_main_thread+0x1420>  // b.none
    a828:	7100045f 	cmp	w2, #0x1
    a82c:	540001a1 	b.ne	a860 <fwp_main_thread+0x12b0>  // b.any
    a830:	29430002 	ldp	w2, w0, [x0, #24]
    a834:	92403c21 	and	x1, x1, #0xffff
    a838:	9b027c21 	mul	x1, x1, x2
    a83c:	d360fc21 	lsr	x1, x1, #32
    a840:	eb00003f 	cmp	x1, x0
    a844:	540000e2 	b.cs	a860 <fwp_main_thread+0x12b0>  // b.hs, b.nlast
    a848:	8b0102f7 	add	x23, x23, x1
    a84c:	394002e0 	ldrb	w0, [x23]
    a850:	7103fc1f 	cmp	w0, #0xff
    a854:	54000c80 	b.eq	a9e4 <fwp_main_thread+0x1434>  // b.none
    a858:	52800020 	mov	w0, #0x1                   	// #1
    a85c:	390002e0 	strb	w0, [x23]
    a860:	aa1803e0 	mov	x0, x24
    a864:	aa1303f8 	mov	x24, x19
    a868:	97ffec7e 	bl	5a60 <fwp_closure_drop>
    a86c:	17fffebd 	b	a360 <fwp_main_thread+0xdb0>
    a870:	b8616860 	ldr	w0, [x3, x1]
    a874:	b9400481 	ldr	w1, [x4, #4]
    a878:	4b010003 	sub	w3, w0, w1
    a87c:	7100047f 	cmp	w3, #0x1
    a880:	54ffb721 	b.ne	9f64 <fwp_main_thread+0x9b4>  // b.any
    a884:	910003f4 	mov	x20, sp
    a888:	34000c41 	cbz	w1, aa10 <fwp_main_thread+0x1460>
    a88c:	7100001f 	cmp	w0, #0x0
    a890:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a894:	d2800102 	mov	x2, #0x8                   	// #8
    a898:	9a82101a 	csel	x26, x0, x2, ne	// ne = any
    a89c:	91003f40 	add	x0, x26, #0xf
    a8a0:	92704c02 	and	x2, x0, #0xfffff0000
    a8a4:	927c7c00 	and	x0, x0, #0xffffffff0
    a8a8:	cb2263e2 	sub	x2, sp, x2
    a8ac:	eb2263ff 	cmp	sp, x2
    a8b0:	540000a0 	b.eq	a8c4 <fwp_main_thread+0x1314>  // b.none
    a8b4:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a8b8:	f90203ff 	str	xzr, [sp, #1024]
    a8bc:	eb2263ff 	cmp	sp, x2
    a8c0:	54ffffa1 	b.ne	a8b4 <fwp_main_thread+0x1304>  // b.any
    a8c4:	92403c00 	and	x0, x0, #0xffff
    a8c8:	cb2063ff 	sub	sp, sp, x0
    a8cc:	f90003ff 	str	xzr, [sp]
    a8d0:	f110001f 	cmp	x0, #0x400
    a8d4:	54000043 	b.cc	a8dc <fwp_main_thread+0x132c>  // b.lo, b.ul, b.last
    a8d8:	f90203ff 	str	xzr, [sp, #1024]
    a8dc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8e0:	d37d7c3b 	ubfiz	x27, x1, #3, #32
    a8e4:	910043f5 	add	x21, sp, #0x10
    a8e8:	aa1b03e2 	mov	x2, x27
    a8ec:	aa1a03e3 	mov	x3, x26
    a8f0:	f91f7806 	str	x6, [x0, #16112]
    a8f4:	f91f7c05 	str	x5, [x0, #16120]
    a8f8:	f95f5000 	ldr	x0, [x0, #16032]
    a8fc:	91004001 	add	x1, x0, #0x10
    a900:	aa1503e0 	mov	x0, x21
    a904:	91004021 	add	x1, x1, #0x10
    a908:	97ffdf8e 	bl	2740 <__memcpy_chk@plt>
    a90c:	eb1b035f 	cmp	x26, x27
    a910:	aa1303e1 	mov	x1, x19
    a914:	9a9b2343 	csel	x3, x26, x27, cs	// cs = hs, nlast
    a918:	d2800102 	mov	x2, #0x8                   	// #8
    a91c:	cb1b0063 	sub	x3, x3, x27
    a920:	8b1b02a0 	add	x0, x21, x27
    a924:	97ffdf87 	bl	2740 <__memcpy_chk@plt>
    a928:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a92c:	aa1503e0 	mov	x0, x21
    a930:	f95f7c25 	ldr	x5, [x1, #16120]
    a934:	f9400ca1 	ldr	x1, [x5, #24]
    a938:	f9400021 	ldr	x1, [x1]
    a93c:	d63f0020 	blr	x1
    a940:	aa0003f8 	mov	x24, x0
    a944:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a948:	f95f7806 	ldr	x6, [x0, #16112]
    a94c:	9100029f 	mov	sp, x20
    a950:	17fffeb1 	b	a414 <fwp_main_thread+0xe64>
    a954:	b90004ff 	str	wzr, [x7, #4]
    a958:	17ffffa3 	b	a7e4 <fwp_main_thread+0x1234>
    a95c:	72003c3f 	tst	w1, #0xffff
    a960:	54ffb421 	b.ne	9fe4 <fwp_main_thread+0xa34>  // b.any
    a964:	17fffd9a 	b	9fcc <fwp_main_thread+0xa1c>
    a968:	f9400593 	ldr	x19, [x12, #8]
    a96c:	b4000113 	cbz	x19, a98c <fwp_main_thread+0x13dc>
    a970:	f9400988 	ldr	x8, [x12, #16]
    a974:	cb130108 	sub	x8, x8, x19
    a978:	eb08003f 	cmp	x1, x8
    a97c:	54000088 	b.hi	a98c <fwp_main_thread+0x13dc>  // b.pmore
    a980:	8b010268 	add	x8, x19, x1
    a984:	f9000588 	str	x8, [x12, #8]
    a988:	17ffff45 	b	a69c <fwp_main_thread+0x10ec>
    a98c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a990:	f91f6824 	str	x4, [x1, #16080]
    a994:	f91f6c27 	str	x7, [x1, #16088]
    a998:	b93ee022 	str	w2, [x1, #16096]
    a99c:	b93ef829 	str	w9, [x1, #16120]
    a9a0:	52800001 	mov	w1, #0x0                   	// #0
    a9a4:	97ffe893 	bl	4bf0 <fwp_heap_alloc>
    a9a8:	aa0003f3 	mov	x19, x0
    a9ac:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a9b0:	f95f6804 	ldr	x4, [x0, #16080]
    a9b4:	f95f6c07 	ldr	x7, [x0, #16088]
    a9b8:	b97ee002 	ldr	w2, [x0, #16096]
    a9bc:	b97ef809 	ldr	w9, [x0, #16120]
    a9c0:	17ffff4e 	b	a6f8 <fwp_main_thread+0x1148>
    a9c4:	72003c1f 	tst	w0, #0xffff
    a9c8:	54fff041 	b.ne	a7d0 <fwp_main_thread+0x1220>  // b.any
    a9cc:	17ffff7e 	b	a7c4 <fwp_main_thread+0x1214>
    a9d0:	72003c3f 	tst	w1, #0xffff
    a9d4:	54fff461 	b.ne	a860 <fwp_main_thread+0x12b0>  // b.any
    a9d8:	394002e0 	ldrb	w0, [x23]
    a9dc:	7103fc1f 	cmp	w0, #0xff
    a9e0:	54fff3c1 	b.ne	a858 <fwp_main_thread+0x12a8>  // b.any
    a9e4:	aa1703e0 	mov	x0, x23
    a9e8:	97ffe6c2 	bl	44f0 <fwp_rc_forget_slot>
    a9ec:	17ffff9b 	b	a858 <fwp_main_thread+0x12a8>
    a9f0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a9f4:	f91f7826 	str	x6, [x1, #16112]
    a9f8:	f91f7c25 	str	x5, [x1, #16120]
    a9fc:	97ffe676 	bl	43d4 <fwp_rc_wide_dup>
    aa00:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa04:	f95f7806 	ldr	x6, [x0, #16112]
    aa08:	f95f7c05 	ldr	x5, [x0, #16120]
    aa0c:	17fffd76 	b	9fe4 <fwp_main_thread+0xa34>
    aa10:	f9400041 	ldr	x1, [x2]
    aa14:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa18:	f91f7c06 	str	x6, [x0, #16120]
    aa1c:	aa1303e0 	mov	x0, x19
    aa20:	d63f0020 	blr	x1
    aa24:	aa0003f8 	mov	x24, x0
    aa28:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa2c:	f95f7c06 	ldr	x6, [x0, #16120]
    aa30:	9100029f 	mov	sp, x20
    aa34:	17fffe78 	b	a414 <fwp_main_thread+0xe64>
    aa38:	72003c3f 	tst	w1, #0xffff
    aa3c:	54ff9be1 	b.ne	9db8 <fwp_main_thread+0x808>  // b.any
    aa40:	17fffcd9 	b	9da4 <fwp_main_thread+0x7f4>
    aa44:	72003c3f 	tst	w1, #0xffff
    aa48:	54ff9661 	b.ne	9d14 <fwp_main_thread+0x764>  // b.any
    aa4c:	17fffcad 	b	9d00 <fwp_main_thread+0x750>
    aa50:	72003c3f 	tst	w1, #0xffff
    aa54:	54ffa6a1 	b.ne	9f28 <fwp_main_thread+0x978>  // b.any
    aa58:	17fffd2e 	b	9f10 <fwp_main_thread+0x960>
    aa5c:	72003c3f 	tst	w1, #0xffff
    aa60:	54ffa0e1 	b.ne	9e7c <fwp_main_thread+0x8cc>  // b.any
    aa64:	17fffcfb 	b	9e50 <fwp_main_thread+0x8a0>
    aa68:	aa0103e0 	mov	x0, x1
    aa6c:	17fffb9d 	b	98e0 <fwp_main_thread+0x330>
    aa70:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa74:	f91f7c06 	str	x6, [x0, #16120]
    aa78:	aa1303e0 	mov	x0, x19
    aa7c:	97ffe69d 	bl	44f0 <fwp_rc_forget_slot>
    aa80:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa84:	f95f7c06 	ldr	x6, [x0, #16120]
    aa88:	17fffca1 	b	9d0c <fwp_main_thread+0x75c>
    aa8c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    aa90:	f91f7c26 	str	x6, [x1, #16120]
    aa94:	97ffe650 	bl	43d4 <fwp_rc_wide_dup>
    aa98:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aa9c:	f95f7c06 	ldr	x6, [x0, #16120]
    aaa0:	17fffd22 	b	9f28 <fwp_main_thread+0x978>
    aaa4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aaa8:	f91f7c06 	str	x6, [x0, #16120]
    aaac:	aa1303e0 	mov	x0, x19
    aab0:	97ffe690 	bl	44f0 <fwp_rc_forget_slot>
    aab4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aab8:	f95f7c06 	ldr	x6, [x0, #16120]
    aabc:	17fffcbd 	b	9db0 <fwp_main_thread+0x800>
    aac0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aac4:	f91f7c06 	str	x6, [x0, #16120]
    aac8:	aa1303e0 	mov	x0, x19
    aacc:	97ffe689 	bl	44f0 <fwp_rc_forget_slot>
    aad0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aad4:	f95f7c06 	ldr	x6, [x0, #16120]
    aad8:	17fffce1 	b	9e5c <fwp_main_thread+0x8ac>
    aadc:	97ffe135 	bl	2fb0 <fwp_heap_oom>
    aae0:	b0000000 	adrp	x0, b000 <__modti3+0x30>
    aae4:	91244000 	add	x0, x0, #0x910
    aae8:	97ffe286 	bl	3500 <fwp_trap>
    aaec:	97ffdf41 	bl	27f0 <__stack_chk_fail@plt>
    aaf0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    aaf4:	aa0603e0 	mov	x0, x6
    aaf8:	aa1303fb 	mov	x27, x19
    aafc:	52800034 	mov	w20, #0x1                   	// #1
    ab00:	f91f7c26 	str	x6, [x1, #16120]
    ab04:	97ffeab8 	bl	55e4 <fwp_rc_share>
    ab08:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab0c:	f95f5c00 	ldr	x0, [x0, #16056]
    ab10:	97ffeab5 	bl	55e4 <fwp_rc_share>
    ab14:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab18:	f95f7c06 	ldr	x6, [x0, #16120]
    ab1c:	aa0603f8 	mov	x24, x6
    ab20:	17fffe34 	b	a3f0 <fwp_main_thread+0xe40>
    ab24:	b0000000 	adrp	x0, b000 <__modti3+0x30>
    ab28:	9124e000 	add	x0, x0, #0x938
    ab2c:	97ffe275 	bl	3500 <fwp_trap>
    ab30:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab34:	f95f4c06 	ldr	x6, [x0, #16024]
    ab38:	f91f7c06 	str	x6, [x0, #16120]
    ab3c:	f95f5c16 	ldr	x22, [x0, #16056]
    ab40:	aa1603e0 	mov	x0, x22
    ab44:	97ffeb17 	bl	57a0 <fwp_drop0>
    ab48:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab4c:	f95f7c06 	ldr	x6, [x0, #16120]
    ab50:	aa0603e0 	mov	x0, x6
    ab54:	97ffeb13 	bl	57a0 <fwp_drop0>
    ab58:	d00000a0 	adrp	x0, 20000 <__data_start>
    ab5c:	91010000 	add	x0, x0, #0x40
    ab60:	52800021 	mov	w1, #0x1                   	// #1
    ab64:	b902f801 	str	w1, [x0, #760]
    ab68:	f901801f 	str	xzr, [x0, #768]
    ab6c:	17fffad3 	b	96b8 <fwp_main_thread+0x108>
    ab70:	72003c3f 	tst	w1, #0xffff
    ab74:	54ffd401 	b.ne	a5f4 <fwp_main_thread+0x1044>  // b.any
    ab78:	17fffe97 	b	a5d4 <fwp_main_thread+0x1024>
    ab7c:	72003c3f 	tst	w1, #0xffff
    ab80:	54ffcd41 	b.ne	a528 <fwp_main_thread+0xf78>  // b.any
    ab84:	17fffe64 	b	a514 <fwp_main_thread+0xf64>
    ab88:	ca5546a0 	eor	x0, x21, x21, lsr #17
    ab8c:	f0000121 	adrp	x1, 31000 <fwp_root_context+0xc90>
    ab90:	91154021 	add	x1, x1, #0x550
    ab94:	ca402400 	eor	x0, x0, x0, lsr #9
    ab98:	8b200c20 	add	x0, x1, w0, uxtb #3
    ab9c:	f94a2400 	ldr	x0, [x0, #5192]
    aba0:	b5000080 	cbnz	x0, abb0 <fwp_main_thread+0x1600>
    aba4:	14000025 	b	ac38 <fwp_main_thread+0x1688>
    aba8:	f9400800 	ldr	x0, [x0, #16]
    abac:	b4000460 	cbz	x0, ac38 <fwp_main_thread+0x1688>
    abb0:	f9400001 	ldr	x1, [x0]
    abb4:	eb0102bf 	cmp	x21, x1
    abb8:	54ffff81 	b.ne	aba8 <fwp_main_thread+0x15f8>  // b.any
    abbc:	f9400401 	ldr	x1, [x0, #8]
    abc0:	d1000421 	sub	x1, x1, #0x1
    abc4:	f9000401 	str	x1, [x0, #8]
    abc8:	f103f83f 	cmp	x1, #0xfe
    abcc:	54ffd141 	b.ne	a5f4 <fwp_main_thread+0x1044>  // b.any
    abd0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    abd4:	f91f7c06 	str	x6, [x0, #16120]
    abd8:	aa1503e0 	mov	x0, x21
    abdc:	97ffe645 	bl	44f0 <fwp_rc_forget_slot>
    abe0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    abe4:	390002a0 	strb	w0, [x21]
    abe8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    abec:	f95f7c06 	ldr	x6, [x0, #16120]
    abf0:	17fffe81 	b	a5f4 <fwp_main_thread+0x1044>
    abf4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    abf8:	f91f7c06 	str	x6, [x0, #16120]
    abfc:	aa1403e0 	mov	x0, x20
    ac00:	97ffeaa0 	bl	5680 <fwp_rc_free_arr>
    ac04:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac08:	f95f7c06 	ldr	x6, [x0, #16120]
    ac0c:	17fffe7a 	b	a5f4 <fwp_main_thread+0x1044>
    ac10:	b9030a9f 	str	wzr, [x20, #776]
    ac14:	b4ff69a0 	cbz	x0, 9948 <fwp_main_thread+0x398>
    ac18:	97ffdf0a 	bl	2840 <abort@plt>
    ac1c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac20:	f91f7c06 	str	x6, [x0, #16120]
    ac24:	aa1a03e0 	mov	x0, x26
    ac28:	97ffe632 	bl	44f0 <fwp_rc_forget_slot>
    ac2c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac30:	f95f7c06 	ldr	x6, [x0, #16120]
    ac34:	17fffe3b 	b	a520 <fwp_main_thread+0xf70>
    ac38:	b0000000 	adrp	x0, b000 <__modti3+0x30>
    ac3c:	91186000 	add	x0, x0, #0x618
    ac40:	97ffe230 	bl	3500 <fwp_trap>
    ac44:	d503201f 	nop
    ac48:	d503201f 	nop
    ac4c:	d503201f 	nop

000000000000ac50 <__divti3>:
    ac50:	d503245f 	bti	c
    ac54:	d2800004 	mov	x4, #0x0                   	// #0
    ac58:	b7f80721 	tbnz	x1, #63, ad3c <__divti3+0xec>
    ac5c:	b6f80083 	tbz	x3, #63, ac6c <__divti3+0x1c>
    ac60:	eb0203e2 	negs	x2, x2
    ac64:	aa2403e4 	mvn	x4, x4
    ac68:	da0303e3 	ngc	x3, x3
    ac6c:	aa0203e6 	mov	x6, x2
    ac70:	aa0003e7 	mov	x7, x0
    ac74:	aa0103e5 	mov	x5, x1
    ac78:	b5000583 	cbnz	x3, ad28 <__divti3+0xd8>
    ac7c:	eb01005f 	cmp	x2, x1
    ac80:	54000e69 	b.ls	ae4c <__divti3+0x1fc>  // b.plast
    ac84:	dac01040 	clz	x0, x2
    ac88:	b40000e0 	cbz	x0, aca4 <__divti3+0x54>
    ac8c:	4b0003e1 	neg	w1, w0
    ac90:	9ac020a5 	lsl	x5, x5, x0
    ac94:	9ac02046 	lsl	x6, x2, x0
    ac98:	9ac124e1 	lsr	x1, x7, x1
    ac9c:	aa050025 	orr	x5, x1, x5
    aca0:	9ac020e7 	lsl	x7, x7, x0
    aca4:	d360fcc8 	lsr	x8, x6, #32
    aca8:	92407cc2 	and	x2, x6, #0xffffffff
    acac:	9ac808a3 	udiv	x3, x5, x8
    acb0:	9b089465 	msub	x5, x3, x8, x5
    acb4:	aa0303e0 	mov	x0, x3
    acb8:	9b037c41 	mul	x1, x2, x3
    acbc:	93c780a5 	extr	x5, x5, x7, #32
    acc0:	eb05003f 	cmp	x1, x5
    acc4:	540000a9 	b.ls	acd8 <__divti3+0x88>  // b.plast
    acc8:	ab0500c5 	adds	x5, x6, x5
    accc:	d1000460 	sub	x0, x3, #0x1
    acd0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    acd4:	540015a8 	b.hi	af88 <__divti3+0x338>  // b.pmore
    acd8:	cb0100a5 	sub	x5, x5, x1
    acdc:	9ac808a3 	udiv	x3, x5, x8
    ace0:	9b089465 	msub	x5, x3, x8, x5
    ace4:	aa0303e1 	mov	x1, x3
    ace8:	9b037c42 	mul	x2, x2, x3
    acec:	aa0703e3 	mov	x3, x7
    acf0:	b3607ca3 	bfi	x3, x5, #32, #32
    acf4:	eb03005f 	cmp	x2, x3
    acf8:	540000c9 	b.ls	ad10 <__divti3+0xc0>  // b.plast
    acfc:	ab0300c3 	adds	x3, x6, x3
    ad00:	d1000425 	sub	x5, x1, #0x1
    ad04:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ad08:	d1000821 	sub	x1, x1, #0x2
    ad0c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ad10:	aa008020 	orr	x0, x1, x0, lsl #32
    ad14:	d2800001 	mov	x1, #0x0                   	// #0
    ad18:	b4000064 	cbz	x4, ad24 <__divti3+0xd4>
    ad1c:	eb0003e0 	negs	x0, x0
    ad20:	da0103e1 	ngc	x1, x1
    ad24:	d65f03c0 	ret
    ad28:	eb01007f 	cmp	x3, x1
    ad2c:	54000109 	b.ls	ad4c <__divti3+0xfc>  // b.plast
    ad30:	d2800001 	mov	x1, #0x0                   	// #0
    ad34:	d2800000 	mov	x0, #0x0                   	// #0
    ad38:	17fffff8 	b	ad18 <__divti3+0xc8>
    ad3c:	eb0003e0 	negs	x0, x0
    ad40:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ad44:	da0103e1 	ngc	x1, x1
    ad48:	17ffffc5 	b	ac5c <__divti3+0xc>
    ad4c:	dac01067 	clz	x7, x3
    ad50:	b40010e7 	cbz	x7, af6c <__divti3+0x31c>
    ad54:	d2800805 	mov	x5, #0x40                  	// #64
    ad58:	cb0700a5 	sub	x5, x5, x7
    ad5c:	9ac72063 	lsl	x3, x3, x7
    ad60:	9ac52448 	lsr	x8, x2, x5
    ad64:	aa030108 	orr	x8, x8, x3
    ad68:	9ac52426 	lsr	x6, x1, x5
    ad6c:	92407d0a 	and	x10, x8, #0xffffffff
    ad70:	d360fd09 	lsr	x9, x8, #32
    ad74:	9ac52403 	lsr	x3, x0, x5
    ad78:	9ac72021 	lsl	x1, x1, x7
    ad7c:	aa010063 	orr	x3, x3, x1
    ad80:	9ac72042 	lsl	x2, x2, x7
    ad84:	9ac908cb 	udiv	x11, x6, x9
    ad88:	9b099965 	msub	x5, x11, x9, x6
    ad8c:	aa0b03e1 	mov	x1, x11
    ad90:	9b0b7d46 	mul	x6, x10, x11
    ad94:	93c380a5 	extr	x5, x5, x3, #32
    ad98:	eb0500df 	cmp	x6, x5
    ad9c:	540000a9 	b.ls	adb0 <__divti3+0x160>  // b.plast
    ada0:	ab050105 	adds	x5, x8, x5
    ada4:	d1000561 	sub	x1, x11, #0x1
    ada8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    adac:	54000f48 	b.hi	af94 <__divti3+0x344>  // b.pmore
    adb0:	cb0600a6 	sub	x6, x5, x6
    adb4:	9ac908cb 	udiv	x11, x6, x9
    adb8:	9b099969 	msub	x9, x11, x9, x6
    adbc:	aa0b03e5 	mov	x5, x11
    adc0:	9b0b7d4a 	mul	x10, x10, x11
    adc4:	b3607d23 	bfi	x3, x9, #32, #32
    adc8:	eb03015f 	cmp	x10, x3
    adcc:	540000a9 	b.ls	ade0 <__divti3+0x190>  // b.plast
    add0:	ab030103 	adds	x3, x8, x3
    add4:	d1000565 	sub	x5, x11, #0x1
    add8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    addc:	54000e28 	b.hi	afa0 <__divti3+0x350>  // b.pmore
    ade0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    ade4:	92407c48 	and	x8, x2, #0xffffffff
    ade8:	2a0503e5 	mov	w5, w5
    adec:	d360fc42 	lsr	x2, x2, #32
    adf0:	d360fc26 	lsr	x6, x1, #32
    adf4:	cb0a0063 	sub	x3, x3, x10
    adf8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    adfc:	9b087caa 	mul	x10, x5, x8
    ae00:	9b087cc8 	mul	x8, x6, x8
    ae04:	9b0220a5 	madd	x5, x5, x2, x8
    ae08:	9b027cc6 	mul	x6, x6, x2
    ae0c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    ae10:	8b0900c5 	add	x5, x6, x9
    ae14:	eb02011f 	cmp	x8, x2
    ae18:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    ae1c:	8b4280c6 	add	x6, x6, x2, lsr #32
    ae20:	eb06007f 	cmp	x3, x6
    ae24:	540000e3 	b.cc	ae40 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    ae28:	92407d4a 	and	x10, x10, #0xffffffff
    ae2c:	9ac72000 	lsl	x0, x0, x7
    ae30:	8b028142 	add	x2, x10, x2, lsl #32
    ae34:	eb02001f 	cmp	x0, x2
    ae38:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    ae3c:	54000a01 	b.ne	af7c <__divti3+0x32c>  // b.any
    ae40:	d1000420 	sub	x0, x1, #0x1
    ae44:	d2800001 	mov	x1, #0x0                   	// #0
    ae48:	17ffffb4 	b	ad18 <__divti3+0xc8>
    ae4c:	b5000062 	cbnz	x2, ae58 <__divti3+0x208>
    ae50:	d2800022 	mov	x2, #0x1                   	// #1
    ae54:	9ac30846 	udiv	x6, x2, x3
    ae58:	dac010c8 	clz	x8, x6
    ae5c:	b5000408 	cbnz	x8, aedc <__divti3+0x28c>
    ae60:	d360fcc9 	lsr	x9, x6, #32
    ae64:	92407cc5 	and	x5, x6, #0xffffffff
    ae68:	cb060023 	sub	x3, x1, x6
    ae6c:	d2800021 	mov	x1, #0x1                   	// #1
    ae70:	9ac90868 	udiv	x8, x3, x9
    ae74:	9b098d03 	msub	x3, x8, x9, x3
    ae78:	aa0803e0 	mov	x0, x8
    ae7c:	9b057d02 	mul	x2, x8, x5
    ae80:	93c78063 	extr	x3, x3, x7, #32
    ae84:	eb03005f 	cmp	x2, x3
    ae88:	540000a9 	b.ls	ae9c <__divti3+0x24c>  // b.plast
    ae8c:	ab0300c3 	adds	x3, x6, x3
    ae90:	d1000500 	sub	x0, x8, #0x1
    ae94:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ae98:	54000968 	b.hi	afc4 <__divti3+0x374>  // b.pmore
    ae9c:	cb020063 	sub	x3, x3, x2
    aea0:	9ac90862 	udiv	x2, x3, x9
    aea4:	aa0203e8 	mov	x8, x2
    aea8:	9b098c42 	msub	x2, x2, x9, x3
    aeac:	aa0703e3 	mov	x3, x7
    aeb0:	9b057d05 	mul	x5, x8, x5
    aeb4:	b3607c43 	bfi	x3, x2, #32, #32
    aeb8:	eb0300bf 	cmp	x5, x3
    aebc:	540000c9 	b.ls	aed4 <__divti3+0x284>  // b.plast
    aec0:	ab0300c2 	adds	x2, x6, x3
    aec4:	d1000503 	sub	x3, x8, #0x1
    aec8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    aecc:	d1000908 	sub	x8, x8, #0x2
    aed0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    aed4:	aa008100 	orr	x0, x8, x0, lsl #32
    aed8:	17ffff90 	b	ad18 <__divti3+0xc8>
    aedc:	9ac820c6 	lsl	x6, x6, x8
    aee0:	d2800803 	mov	x3, #0x40                  	// #64
    aee4:	cb080063 	sub	x3, x3, x8
    aee8:	d360fcc9 	lsr	x9, x6, #32
    aeec:	9ac82027 	lsl	x7, x1, x8
    aef0:	92407cc5 	and	x5, x6, #0xffffffff
    aef4:	9ac32422 	lsr	x2, x1, x3
    aef8:	9ac32403 	lsr	x3, x0, x3
    aefc:	aa070063 	orr	x3, x3, x7
    af00:	9ac9084a 	udiv	x10, x2, x9
    af04:	9ac82007 	lsl	x7, x0, x8
    af08:	9b098940 	msub	x0, x10, x9, x2
    af0c:	aa0a03e1 	mov	x1, x10
    af10:	9b0a7ca2 	mul	x2, x5, x10
    af14:	93c38000 	extr	x0, x0, x3, #32
    af18:	eb00005f 	cmp	x2, x0
    af1c:	540000a9 	b.ls	af30 <__divti3+0x2e0>  // b.plast
    af20:	ab0000c0 	adds	x0, x6, x0
    af24:	d1000541 	sub	x1, x10, #0x1
    af28:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    af2c:	54000468 	b.hi	afb8 <__divti3+0x368>  // b.pmore
    af30:	cb020000 	sub	x0, x0, x2
    af34:	9ac9080a 	udiv	x10, x0, x9
    af38:	9b098140 	msub	x0, x10, x9, x0
    af3c:	aa0a03e2 	mov	x2, x10
    af40:	9b0a7ca8 	mul	x8, x5, x10
    af44:	b3607c03 	bfi	x3, x0, #32, #32
    af48:	eb03011f 	cmp	x8, x3
    af4c:	540000a9 	b.ls	af60 <__divti3+0x310>  // b.plast
    af50:	ab0300c3 	adds	x3, x6, x3
    af54:	d1000542 	sub	x2, x10, #0x1
    af58:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    af5c:	54000288 	b.hi	afac <__divti3+0x35c>  // b.pmore
    af60:	cb080063 	sub	x3, x3, x8
    af64:	aa018041 	orr	x1, x2, x1, lsl #32
    af68:	17ffffc2 	b	ae70 <__divti3+0x220>
    af6c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    af70:	d2800001 	mov	x1, #0x0                   	// #0
    af74:	9a9f87e0 	cset	x0, ls	// ls = plast
    af78:	17ffff68 	b	ad18 <__divti3+0xc8>
    af7c:	aa0103e0 	mov	x0, x1
    af80:	d2800001 	mov	x1, #0x0                   	// #0
    af84:	17ffff65 	b	ad18 <__divti3+0xc8>
    af88:	d1000860 	sub	x0, x3, #0x2
    af8c:	8b0600a5 	add	x5, x5, x6
    af90:	17ffff52 	b	acd8 <__divti3+0x88>
    af94:	d1000961 	sub	x1, x11, #0x2
    af98:	8b0800a5 	add	x5, x5, x8
    af9c:	17ffff85 	b	adb0 <__divti3+0x160>
    afa0:	d1000965 	sub	x5, x11, #0x2
    afa4:	8b080063 	add	x3, x3, x8
    afa8:	17ffff8e 	b	ade0 <__divti3+0x190>
    afac:	d1000942 	sub	x2, x10, #0x2
    afb0:	8b060063 	add	x3, x3, x6
    afb4:	17ffffeb 	b	af60 <__divti3+0x310>
    afb8:	d1000941 	sub	x1, x10, #0x2
    afbc:	8b060000 	add	x0, x0, x6
    afc0:	17ffffdc 	b	af30 <__divti3+0x2e0>
    afc4:	d1000900 	sub	x0, x8, #0x2
    afc8:	8b060063 	add	x3, x3, x6
    afcc:	17ffffb4 	b	ae9c <__divti3+0x24c>

000000000000afd0 <__modti3>:
    afd0:	d503245f 	bti	c
    afd4:	d2800004 	mov	x4, #0x0                   	// #0
    afd8:	b6f80081 	tbz	x1, #63, afe8 <__modti3+0x18>
    afdc:	eb0003e0 	negs	x0, x0
    afe0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    afe4:	da0103e1 	ngc	x1, x1
    afe8:	f100007f 	cmp	x3, #0x0
    afec:	5400128b 	b.lt	b23c <__modti3+0x26c>  // b.tstop
    aff0:	aa0003e7 	mov	x7, x0
    aff4:	aa0103e6 	mov	x6, x1
    aff8:	540004e1 	b.ne	b094 <__modti3+0xc4>  // b.any
    affc:	eb02003f 	cmp	x1, x2
    b000:	54000dc2 	b.cs	b1b8 <__modti3+0x1e8>  // b.hs, b.nlast
    b004:	dac01043 	clz	x3, x2
    b008:	aa0303e5 	mov	x5, x3
    b00c:	b40000e3 	cbz	x3, b028 <__modti3+0x58>
    b010:	4b0303e6 	neg	w6, w3
    b014:	9ac32021 	lsl	x1, x1, x3
    b018:	9ac32042 	lsl	x2, x2, x3
    b01c:	9ac62406 	lsr	x6, x0, x6
    b020:	aa0100c6 	orr	x6, x6, x1
    b024:	9ac32007 	lsl	x7, x0, x3
    b028:	d360fc40 	lsr	x0, x2, #32
    b02c:	92407c43 	and	x3, x2, #0xffffffff
    b030:	9ac008c1 	udiv	x1, x6, x0
    b034:	9b009826 	msub	x6, x1, x0, x6
    b038:	9b017c61 	mul	x1, x3, x1
    b03c:	93c780c6 	extr	x6, x6, x7, #32
    b040:	eb06003f 	cmp	x1, x6
    b044:	540000a9 	b.ls	b058 <__modti3+0x88>  // b.plast
    b048:	ab060046 	adds	x6, x2, x6
    b04c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    b050:	8b0200c8 	add	x8, x6, x2
    b054:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    b058:	cb0100c6 	sub	x6, x6, x1
    b05c:	9ac008c8 	udiv	x8, x6, x0
    b060:	9b009901 	msub	x1, x8, x0, x6
    b064:	aa0703e0 	mov	x0, x7
    b068:	9b087c63 	mul	x3, x3, x8
    b06c:	b3607c20 	bfi	x0, x1, #32, #32
    b070:	eb00007f 	cmp	x3, x0
    b074:	54001088 	b.hi	b284 <__modti3+0x2b4>  // b.pmore
    b078:	cb030000 	sub	x0, x0, x3
    b07c:	9ac52400 	lsr	x0, x0, x5
    b080:	d2800001 	mov	x1, #0x0                   	// #0
    b084:	b4000064 	cbz	x4, b090 <__modti3+0xc0>
    b088:	eb0003e0 	negs	x0, x0
    b08c:	da0103e1 	ngc	x1, x1
    b090:	d65f03c0 	ret
    b094:	dac01066 	clz	x6, x3
    b098:	eb03003f 	cmp	x1, x3
    b09c:	54ffff43 	b.cc	b084 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b0a0:	93407cc5 	sxtw	x5, w6
    b0a4:	d2800808 	mov	x8, #0x40                  	// #64
    b0a8:	cb050108 	sub	x8, x8, x5
    b0ac:	9ac62063 	lsl	x3, x3, x6
    b0b0:	9ac62025 	lsl	x5, x1, x6
    b0b4:	9ac82447 	lsr	x7, x2, x8
    b0b8:	aa0300e7 	orr	x7, x7, x3
    b0bc:	9ac82423 	lsr	x3, x1, x8
    b0c0:	92407cec 	and	x12, x7, #0xffffffff
    b0c4:	d360fcea 	lsr	x10, x7, #32
    b0c8:	9ac82401 	lsr	x1, x0, x8
    b0cc:	aa050021 	orr	x1, x1, x5
    b0d0:	9ac62042 	lsl	x2, x2, x6
    b0d4:	9ac62000 	lsl	x0, x0, x6
    b0d8:	9aca086b 	udiv	x11, x3, x10
    b0dc:	9b0a8d63 	msub	x3, x11, x10, x3
    b0e0:	aa0b03e5 	mov	x5, x11
    b0e4:	9b0b7d89 	mul	x9, x12, x11
    b0e8:	93c18063 	extr	x3, x3, x1, #32
    b0ec:	eb03013f 	cmp	x9, x3
    b0f0:	540000a9 	b.ls	b104 <__modti3+0x134>  // b.plast
    b0f4:	ab0300e3 	adds	x3, x7, x3
    b0f8:	d1000565 	sub	x5, x11, #0x1
    b0fc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b100:	54001168 	b.hi	b32c <__modti3+0x35c>  // b.pmore
    b104:	cb090063 	sub	x3, x3, x9
    b108:	9aca086b 	udiv	x11, x3, x10
    b10c:	9b0a8d6a 	msub	x10, x11, x10, x3
    b110:	aa0b03e9 	mov	x9, x11
    b114:	9b0b7d8c 	mul	x12, x12, x11
    b118:	b3607d41 	bfi	x1, x10, #32, #32
    b11c:	eb01019f 	cmp	x12, x1
    b120:	540000a9 	b.ls	b134 <__modti3+0x164>  // b.plast
    b124:	ab0100e1 	adds	x1, x7, x1
    b128:	d1000569 	sub	x9, x11, #0x1
    b12c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b130:	54000f88 	b.hi	b320 <__modti3+0x350>  // b.pmore
    b134:	aa058123 	orr	x3, x9, x5, lsl #32
    b138:	92407c4b 	and	x11, x2, #0xffffffff
    b13c:	2a0903e9 	mov	w9, w9
    b140:	d360fc4a 	lsr	x10, x2, #32
    b144:	d360fc63 	lsr	x3, x3, #32
    b148:	cb0c0021 	sub	x1, x1, x12
    b14c:	aa0a03ec 	mov	x12, x10
    b150:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b154:	9b0b7d25 	mul	x5, x9, x11
    b158:	9b0b7c6b 	mul	x11, x3, x11
    b15c:	9b0a2d29 	madd	x9, x9, x10, x11
    b160:	92407caa 	and	x10, x5, #0xffffffff
    b164:	9b0c7c63 	mul	x3, x3, x12
    b168:	8b458125 	add	x5, x9, x5, lsr #32
    b16c:	8b0d0069 	add	x9, x3, x13
    b170:	eb05017f 	cmp	x11, x5
    b174:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b178:	8b058149 	add	x9, x10, x5, lsl #32
    b17c:	8b458063 	add	x3, x3, x5, lsr #32
    b180:	eb03003f 	cmp	x1, x3
    b184:	54000063 	b.cc	b190 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b188:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b18c:	54000082 	b.cs	b19c <__modti3+0x1cc>  // b.hs, b.nlast
    b190:	eb020129 	subs	x9, x9, x2
    b194:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b198:	cb070063 	sub	x3, x3, x7
    b19c:	eb090000 	subs	x0, x0, x9
    b1a0:	da030021 	sbc	x1, x1, x3
    b1a4:	9ac62400 	lsr	x0, x0, x6
    b1a8:	9ac82028 	lsl	x8, x1, x8
    b1ac:	aa000100 	orr	x0, x8, x0
    b1b0:	9ac62421 	lsr	x1, x1, x6
    b1b4:	17ffffb4 	b	b084 <__modti3+0xb4>
    b1b8:	b5000062 	cbnz	x2, b1c4 <__modti3+0x1f4>
    b1bc:	d2800023 	mov	x3, #0x1                   	// #1
    b1c0:	9ac20862 	udiv	x2, x3, x2
    b1c4:	dac01048 	clz	x8, x2
    b1c8:	aa0803e5 	mov	x5, x8
    b1cc:	b5000668 	cbnz	x8, b298 <__modti3+0x2c8>
    b1d0:	cb020020 	sub	x0, x1, x2
    b1d4:	d360fc49 	lsr	x9, x2, #32
    b1d8:	92407c4a 	and	x10, x2, #0xffffffff
    b1dc:	9ac90801 	udiv	x1, x0, x9
    b1e0:	9b098020 	msub	x0, x1, x9, x0
    b1e4:	9b0a7c21 	mul	x1, x1, x10
    b1e8:	93c78000 	extr	x0, x0, x7, #32
    b1ec:	eb00003f 	cmp	x1, x0
    b1f0:	540000a9 	b.ls	b204 <__modti3+0x234>  // b.plast
    b1f4:	ab000040 	adds	x0, x2, x0
    b1f8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b1fc:	8b020003 	add	x3, x0, x2
    b200:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b204:	cb010001 	sub	x1, x0, x1
    b208:	9ac90820 	udiv	x0, x1, x9
    b20c:	9b098403 	msub	x3, x0, x9, x1
    b210:	aa0703e1 	mov	x1, x7
    b214:	9b0a7c00 	mul	x0, x0, x10
    b218:	b3607c61 	bfi	x1, x3, #32, #32
    b21c:	eb01001f 	cmp	x0, x1
    b220:	540000a9 	b.ls	b234 <__modti3+0x264>  // b.plast
    b224:	ab010041 	adds	x1, x2, x1
    b228:	8b020022 	add	x2, x1, x2
    b22c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b230:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b234:	cb000020 	sub	x0, x1, x0
    b238:	17ffff91 	b	b07c <__modti3+0xac>
    b23c:	eb0203e5 	negs	x5, x2
    b240:	aa0003e7 	mov	x7, x0
    b244:	da0303e8 	ngc	x8, x3
    b248:	aa0503e2 	mov	x2, x5
    b24c:	aa0803e3 	mov	x3, x8
    b250:	aa0103e6 	mov	x6, x1
    b254:	b4ffed48 	cbz	x8, affc <__modti3+0x2c>
    b258:	eb01011f 	cmp	x8, x1
    b25c:	54fff148 	b.hi	b084 <__modti3+0xb4>  // b.pmore
    b260:	dac01109 	clz	x9, x8
    b264:	2a0903e6 	mov	w6, w9
    b268:	b5fff1c9 	cbnz	x9, b0a0 <__modti3+0xd0>
    b26c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b270:	54000068 	b.hi	b27c <__modti3+0x2ac>  // b.pmore
    b274:	eb050007 	subs	x7, x0, x5
    b278:	da080021 	sbc	x1, x1, x8
    b27c:	aa0703e0 	mov	x0, x7
    b280:	17ffff81 	b	b084 <__modti3+0xb4>
    b284:	ab000040 	adds	x0, x2, x0
    b288:	8b020002 	add	x2, x0, x2
    b28c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b290:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b294:	17ffff79 	b	b078 <__modti3+0xa8>
    b298:	9ac82042 	lsl	x2, x2, x8
    b29c:	d2800803 	mov	x3, #0x40                  	// #64
    b2a0:	cb080063 	sub	x3, x3, x8
    b2a4:	d360fc49 	lsr	x9, x2, #32
    b2a8:	9ac82027 	lsl	x7, x1, x8
    b2ac:	92407c4a 	and	x10, x2, #0xffffffff
    b2b0:	9ac32426 	lsr	x6, x1, x3
    b2b4:	9ac32403 	lsr	x3, x0, x3
    b2b8:	aa070063 	orr	x3, x3, x7
    b2bc:	9ac908c1 	udiv	x1, x6, x9
    b2c0:	9ac82007 	lsl	x7, x0, x8
    b2c4:	9b099820 	msub	x0, x1, x9, x6
    b2c8:	9b017d41 	mul	x1, x10, x1
    b2cc:	93c38000 	extr	x0, x0, x3, #32
    b2d0:	eb00003f 	cmp	x1, x0
    b2d4:	540000a9 	b.ls	b2e8 <__modti3+0x318>  // b.plast
    b2d8:	ab000040 	adds	x0, x2, x0
    b2dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b2e0:	8b020006 	add	x6, x0, x2
    b2e4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b2e8:	cb010000 	sub	x0, x0, x1
    b2ec:	9ac90801 	udiv	x1, x0, x9
    b2f0:	9b098026 	msub	x6, x1, x9, x0
    b2f4:	aa0303e0 	mov	x0, x3
    b2f8:	9b017d41 	mul	x1, x10, x1
    b2fc:	b3607cc0 	bfi	x0, x6, #32, #32
    b300:	eb00003f 	cmp	x1, x0
    b304:	540000a9 	b.ls	b318 <__modti3+0x348>  // b.plast
    b308:	ab000040 	adds	x0, x2, x0
    b30c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b310:	8b020003 	add	x3, x0, x2
    b314:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b318:	cb010000 	sub	x0, x0, x1
    b31c:	17ffffb0 	b	b1dc <__modti3+0x20c>
    b320:	d1000969 	sub	x9, x11, #0x2
    b324:	8b070021 	add	x1, x1, x7
    b328:	17ffff83 	b	b134 <__modti3+0x164>
    b32c:	d1000965 	sub	x5, x11, #0x2
    b330:	8b070063 	add	x3, x3, x7
    b334:	17ffff74 	b	b104 <__modti3+0x134>
    b338:	d503201f 	nop
    b33c:	d503201f 	nop

000000000000b340 <atexit>:
    b340:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b344:	b00000a2 	adrp	x2, 20000 <__data_start>
    b348:	d2800001 	mov	x1, #0x0                   	// #0
    b34c:	910003fd 	mov	x29, sp
    b350:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b354:	f9400442 	ldr	x2, [x2, #8]
    b358:	17ffdce6 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b35c <_fini>:
    b35c:	d503201f 	nop
    b360:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b364:	910003fd 	mov	x29, sp
    b368:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b36c:	d65f03c0 	ret
