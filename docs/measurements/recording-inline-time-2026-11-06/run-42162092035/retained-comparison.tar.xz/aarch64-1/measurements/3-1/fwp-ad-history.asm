
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002608 <_init>:
    2608:	d503201f 	nop
    260c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2610:	910003fd 	mov	x29, sp
    2614:	940001a8 	bl	2cb4 <call_weak_fn>
    2618:	a8c17bfd 	ldp	x29, x30, [sp], #16
    261c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002620 <.plt>:
    2620:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2624:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2628:	f946f611 	ldr	x17, [x16, #3560]
    262c:	9137a210 	add	x16, x16, #0xde8
    2630:	d61f0220 	br	x17
    2634:	d503201f 	nop
    2638:	d503201f 	nop
    263c:	d503201f 	nop

0000000000002640 <memcpy@plt>:
    2640:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2644:	f946fa11 	ldr	x17, [x16, #3568]
    2648:	9137c210 	add	x16, x16, #0xdf0
    264c:	d61f0220 	br	x17

0000000000002650 <sigaltstack@plt>:
    2650:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2654:	f946fe11 	ldr	x17, [x16, #3576]
    2658:	9137e210 	add	x16, x16, #0xdf8
    265c:	d61f0220 	br	x17

0000000000002660 <memmove@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2664:	f9470211 	ldr	x17, [x16, #3584]
    2668:	91380210 	add	x16, x16, #0xe00
    266c:	d61f0220 	br	x17

0000000000002670 <_exit@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2674:	f9470611 	ldr	x17, [x16, #3592]
    2678:	91382210 	add	x16, x16, #0xe08
    267c:	d61f0220 	br	x17

0000000000002680 <strlen@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2684:	f9470a11 	ldr	x17, [x16, #3600]
    2688:	91384210 	add	x16, x16, #0xe10
    268c:	d61f0220 	br	x17

0000000000002690 <__sprintf_chk@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2694:	f9470e11 	ldr	x17, [x16, #3608]
    2698:	91386210 	add	x16, x16, #0xe18
    269c:	d61f0220 	br	x17

00000000000026a0 <exit@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26a4:	f9471211 	ldr	x17, [x16, #3616]
    26a8:	91388210 	add	x16, x16, #0xe20
    26ac:	d61f0220 	br	x17

00000000000026b0 <__libc_start_main@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26b4:	f9471611 	ldr	x17, [x16, #3624]
    26b8:	9138a210 	add	x16, x16, #0xe28
    26bc:	d61f0220 	br	x17

00000000000026c0 <strtoll@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26c4:	f9471a11 	ldr	x17, [x16, #3632]
    26c8:	9138c210 	add	x16, x16, #0xe30
    26cc:	d61f0220 	br	x17

00000000000026d0 <strtod@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26d4:	f9471e11 	ldr	x17, [x16, #3640]
    26d8:	9138e210 	add	x16, x16, #0xe38
    26dc:	d61f0220 	br	x17

00000000000026e0 <__cxa_finalize@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26e4:	f9472211 	ldr	x17, [x16, #3648]
    26e8:	91390210 	add	x16, x16, #0xe40
    26ec:	d61f0220 	br	x17

00000000000026f0 <__cxa_atexit@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    26f4:	f9472611 	ldr	x17, [x16, #3656]
    26f8:	91392210 	add	x16, x16, #0xe48
    26fc:	d61f0220 	br	x17

0000000000002700 <pthread_attr_init@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2704:	f9472a11 	ldr	x17, [x16, #3664]
    2708:	91394210 	add	x16, x16, #0xe50
    270c:	d61f0220 	br	x17

0000000000002710 <fputc@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2714:	f9472e11 	ldr	x17, [x16, #3672]
    2718:	91396210 	add	x16, x16, #0xe58
    271c:	d61f0220 	br	x17

0000000000002720 <clock_gettime@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2724:	f9473211 	ldr	x17, [x16, #3680]
    2728:	91398210 	add	x16, x16, #0xe60
    272c:	d61f0220 	br	x17

0000000000002730 <setvbuf@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2734:	f9473611 	ldr	x17, [x16, #3688]
    2738:	9139a210 	add	x16, x16, #0xe68
    273c:	d61f0220 	br	x17

0000000000002740 <__memcpy_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2744:	f9473a11 	ldr	x17, [x16, #3696]
    2748:	9139c210 	add	x16, x16, #0xe70
    274c:	d61f0220 	br	x17

0000000000002750 <signal@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2754:	f9473e11 	ldr	x17, [x16, #3704]
    2758:	9139e210 	add	x16, x16, #0xe78
    275c:	d61f0220 	br	x17

0000000000002760 <__snprintf_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2764:	f9474211 	ldr	x17, [x16, #3712]
    2768:	913a0210 	add	x16, x16, #0xe80
    276c:	d61f0220 	br	x17

0000000000002770 <fclose@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2774:	f9474611 	ldr	x17, [x16, #3720]
    2778:	913a2210 	add	x16, x16, #0xe88
    277c:	d61f0220 	br	x17

0000000000002780 <fopen@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2784:	f9474a11 	ldr	x17, [x16, #3728]
    2788:	913a4210 	add	x16, x16, #0xe90
    278c:	d61f0220 	br	x17

0000000000002790 <malloc@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2794:	f9474e11 	ldr	x17, [x16, #3736]
    2798:	913a6210 	add	x16, x16, #0xe98
    279c:	d61f0220 	br	x17

00000000000027a0 <pthread_attr_destroy@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27a4:	f9475211 	ldr	x17, [x16, #3744]
    27a8:	913a8210 	add	x16, x16, #0xea0
    27ac:	d61f0220 	br	x17

00000000000027b0 <sigemptyset@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27b4:	f9475611 	ldr	x17, [x16, #3752]
    27b8:	913aa210 	add	x16, x16, #0xea8
    27bc:	d61f0220 	br	x17

00000000000027c0 <memset@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27c4:	f9475a11 	ldr	x17, [x16, #3760]
    27c8:	913ac210 	add	x16, x16, #0xeb0
    27cc:	d61f0220 	br	x17

00000000000027d0 <calloc@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27d4:	f9475e11 	ldr	x17, [x16, #3768]
    27d8:	913ae210 	add	x16, x16, #0xeb8
    27dc:	d61f0220 	br	x17

00000000000027e0 <realloc@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27e4:	f9476211 	ldr	x17, [x16, #3776]
    27e8:	913b0210 	add	x16, x16, #0xec0
    27ec:	d61f0220 	br	x17

00000000000027f0 <__stack_chk_fail@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    27f4:	f9476611 	ldr	x17, [x16, #3784]
    27f8:	913b2210 	add	x16, x16, #0xec8
    27fc:	d61f0220 	br	x17

0000000000002800 <close@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2804:	f9476a11 	ldr	x17, [x16, #3792]
    2808:	913b4210 	add	x16, x16, #0xed0
    280c:	d61f0220 	br	x17

0000000000002810 <sigaction@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2814:	f9476e11 	ldr	x17, [x16, #3800]
    2818:	913b6210 	add	x16, x16, #0xed8
    281c:	d61f0220 	br	x17

0000000000002820 <__gmon_start__@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2824:	f9477211 	ldr	x17, [x16, #3808]
    2828:	913b8210 	add	x16, x16, #0xee0
    282c:	d61f0220 	br	x17

0000000000002830 <write@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2834:	f9477611 	ldr	x17, [x16, #3816]
    2838:	913ba210 	add	x16, x16, #0xee8
    283c:	d61f0220 	br	x17

0000000000002840 <abort@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2844:	f9477a11 	ldr	x17, [x16, #3824]
    2848:	913bc210 	add	x16, x16, #0xef0
    284c:	d61f0220 	br	x17

0000000000002850 <swapcontext@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2854:	f9477e11 	ldr	x17, [x16, #3832]
    2858:	913be210 	add	x16, x16, #0xef8
    285c:	d61f0220 	br	x17

0000000000002860 <__fprintf_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2864:	f9478211 	ldr	x17, [x16, #3840]
    2868:	913c0210 	add	x16, x16, #0xf00
    286c:	d61f0220 	br	x17

0000000000002870 <strcmp@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2874:	f9478611 	ldr	x17, [x16, #3848]
    2878:	913c2210 	add	x16, x16, #0xf08
    287c:	d61f0220 	br	x17

0000000000002880 <mmap@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2884:	f9478a11 	ldr	x17, [x16, #3856]
    2888:	913c4210 	add	x16, x16, #0xf10
    288c:	d61f0220 	br	x17

0000000000002890 <strtol@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2894:	f9478e11 	ldr	x17, [x16, #3864]
    2898:	913c6210 	add	x16, x16, #0xf18
    289c:	d61f0220 	br	x17

00000000000028a0 <strtof@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28a4:	f9479211 	ldr	x17, [x16, #3872]
    28a8:	913c8210 	add	x16, x16, #0xf20
    28ac:	d61f0220 	br	x17

00000000000028b0 <free@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28b4:	f9479611 	ldr	x17, [x16, #3880]
    28b8:	913ca210 	add	x16, x16, #0xf28
    28bc:	d61f0220 	br	x17

00000000000028c0 <nanosleep@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28c4:	f9479a11 	ldr	x17, [x16, #3888]
    28c8:	913cc210 	add	x16, x16, #0xf30
    28cc:	d61f0220 	br	x17

00000000000028d0 <strchr@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28d4:	f9479e11 	ldr	x17, [x16, #3896]
    28d8:	913ce210 	add	x16, x16, #0xf38
    28dc:	d61f0220 	br	x17

00000000000028e0 <strtoull@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28e4:	f947a211 	ldr	x17, [x16, #3904]
    28e8:	913d0210 	add	x16, x16, #0xf40
    28ec:	d61f0220 	br	x17

00000000000028f0 <fwrite@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    28f4:	f947a611 	ldr	x17, [x16, #3912]
    28f8:	913d2210 	add	x16, x16, #0xf48
    28fc:	d61f0220 	br	x17

0000000000002900 <pthread_create@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2904:	f947aa11 	ldr	x17, [x16, #3920]
    2908:	913d4210 	add	x16, x16, #0xf50
    290c:	d61f0220 	br	x17

0000000000002910 <munmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2914:	f947ae11 	ldr	x17, [x16, #3928]
    2918:	913d6210 	add	x16, x16, #0xf58
    291c:	d61f0220 	br	x17

0000000000002920 <fflush@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2924:	f947b211 	ldr	x17, [x16, #3936]
    2928:	913d8210 	add	x16, x16, #0xf60
    292c:	d61f0220 	br	x17

0000000000002930 <strcpy@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2934:	f947b611 	ldr	x17, [x16, #3944]
    2938:	913da210 	add	x16, x16, #0xf68
    293c:	d61f0220 	br	x17

0000000000002940 <sysconf@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2944:	f947ba11 	ldr	x17, [x16, #3952]
    2948:	913dc210 	add	x16, x16, #0xf70
    294c:	d61f0220 	br	x17

0000000000002950 <strstr@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2954:	f947be11 	ldr	x17, [x16, #3960]
    2958:	913de210 	add	x16, x16, #0xf78
    295c:	d61f0220 	br	x17

0000000000002960 <_Exit@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2964:	f947c211 	ldr	x17, [x16, #3968]
    2968:	913e0210 	add	x16, x16, #0xf80
    296c:	d61f0220 	br	x17

0000000000002970 <pthread_join@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2974:	f947c611 	ldr	x17, [x16, #3976]
    2978:	913e2210 	add	x16, x16, #0xf88
    297c:	d61f0220 	br	x17

0000000000002980 <getenv@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2984:	f947ca11 	ldr	x17, [x16, #3984]
    2988:	913e4210 	add	x16, x16, #0xf90
    298c:	d61f0220 	br	x17

0000000000002990 <__memmove_chk@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    2994:	f947ce11 	ldr	x17, [x16, #3992]
    2998:	913e6210 	add	x16, x16, #0xf98
    299c:	d61f0220 	br	x17

00000000000029a0 <mprotect@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29a4:	f947d211 	ldr	x17, [x16, #4000]
    29a8:	913e8210 	add	x16, x16, #0xfa0
    29ac:	d61f0220 	br	x17

00000000000029b0 <fgets@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29b4:	f947d611 	ldr	x17, [x16, #4008]
    29b8:	913ea210 	add	x16, x16, #0xfa8
    29bc:	d61f0220 	br	x17

00000000000029c0 <pthread_attr_setstacksize@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb38>
    29c4:	f947da11 	ldr	x17, [x16, #4016]
    29c8:	913ec210 	add	x16, x16, #0xfb0
    29cc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	b0000045 	adrp	x5, b000 <fwp_main_thread+0x1730>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	912c60a5 	add	x5, x5, #0xb18
    2a20:	b0000044 	adrp	x4, b000 <fwp_main_thread+0x1730>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	912c8084 	add	x4, x4, #0xb20
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff46 	bl	2760 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	940004f0 	bl	3e10 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb38>
    2a7c:	f947ee94 	ldr	x20, [x20, #4056]
    2a80:	f9400282 	ldr	x2, [x20]
    2a84:	f90043f5 	str	x21, [sp, #128]
    2a88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2a8c:	910102a1 	add	x1, x21, #0x40
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10758>
    2aa0:	91132000 	add	x0, x0, #0x4c8
    2aa4:	f9000422 	str	x2, [x1, #8]
    2aa8:	f9003c20 	str	x0, [x1, #120]
    2aac:	940006f9 	bl	4690 <fwp_now_ns>
    2ab0:	b0000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    2ab4:	9138c000 	add	x0, x0, #0xe30
    2ab8:	97ffffb2 	bl	2980 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f3 	mov	x19, x0
    2ac8:	350008c1 	cbnz	w1, 2be0 <main+0x180>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff13 	bl	2720 <clock_gettime@plt>
    2ad8:	350007e0 	cbnz	w0, 2bd4 <main+0x174>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b5000620 	cbnz	x0, 2bc8 <main+0x168>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f3 	add	x19, sp, #0x18
    2b1c:	97ffff05 	bl	2730 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff0a 	bl	2750 <signal@plt>
    2b2c:	aa1303e0 	mov	x0, x19
    2b30:	97fffef4 	bl	2700 <pthread_attr_init@plt>
    2b34:	350007a0 	cbnz	w0, 2c28 <main+0x1c8>
    2b38:	aa1303e0 	mov	x0, x19
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa0 	bl	29c0 <pthread_attr_setstacksize@plt>
    2b44:	35000660 	cbnz	w0, 2c10 <main+0x1b0>
    2b48:	aa1303e1 	mov	x1, x19
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0x720>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91234042 	add	x2, x2, #0x8d0
    2b5c:	97ffff69 	bl	2900 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1303e0 	mov	x0, x19
    2b68:	2a0103f3 	mov	w19, w1
    2b6c:	97ffff0d 	bl	27a0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	35000613 	cbnz	w19, 2c34 <main+0x1d4>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff7c 	bl	2970 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	910102b5 	add	x21, x21, #0x40
    2b90:	97ffff64 	bl	2920 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b9430aa0 	ldr	w0, [x21, #776]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	54000481 	b.ne	2c40 <main+0x1e0>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	b0000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    2bcc:	91398000 	add	x0, x0, #0xe60
    2bd0:	94000490 	bl	3e10 <fwp_trap>
    2bd4:	b0000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    2bd8:	91390000 	add	x0, x0, #0xe40
    2bdc:	9400048d 	bl	3e10 <fwp_trap>
    2be0:	910003e1 	mov	x1, sp
    2be4:	52800142 	mov	w2, #0xa                   	// #10
    2be8:	97ffff3e 	bl	28e0 <strtoull@plt>
    2bec:	f94003e0 	ldr	x0, [sp]
    2bf0:	39400000 	ldrb	w0, [x0]
    2bf4:	35fff6c0 	cbnz	w0, 2acc <main+0x6c>
    2bf8:	39400260 	ldrb	w0, [x19]
    2bfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c00:	5100ac00 	sub	w0, w0, #0x2b
    2c04:	6a01001f 	tst	w0, w1
    2c08:	54fff620 	b.eq	2acc <main+0x6c>  // b.none
    2c0c:	17ffffbf 	b	2b08 <main+0xa8>
    2c10:	aa1303e0 	mov	x0, x19
    2c14:	97fffee3 	bl	27a0 <pthread_attr_destroy@plt>
    2c18:	35000160 	cbnz	w0, 2c44 <main+0x1e4>
    2c1c:	b0000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    2c20:	913ae000 	add	x0, x0, #0xeb8
    2c24:	9400047b 	bl	3e10 <fwp_trap>
    2c28:	b0000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    2c2c:	913a2000 	add	x0, x0, #0xe88
    2c30:	94000478 	bl	3e10 <fwp_trap>
    2c34:	b0000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    2c38:	913b8000 	add	x0, x0, #0xee0
    2c3c:	94000475 	bl	3e10 <fwp_trap>
    2c40:	97fffeec 	bl	27f0 <__stack_chk_fail@plt>
    2c44:	97fffeff 	bl	2840 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe81 	bl	26b0 <__libc_start_main@plt>
    2cb0:	97fffee4 	bl	2840 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffed8 	b	2820 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	9100a000 	add	x0, x0, #0x28
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	9100a021 	add	x1, x1, #0x28
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	9100a000 	add	x0, x0, #0x28
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	9100a021 	add	x1, x1, #0x28
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	3940c260 	ldrb	w0, [x19, #48]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe5c 	bl	26e0 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	3900c260 	strb	w0, [x19, #48]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	d0000041 	adrp	x1, c000 <_IO_stdin_used+0x7b0>
    2e34:	91138021 	add	x1, x1, #0x4e0
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe49 	bl	27f0 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <fwp_tape_unlink_scope>:
    2f10:	f9402803 	ldr	x3, [x0, #80]
    2f14:	b4000223 	cbz	x3, 2f58 <fwp_tape_unlink_scope+0x48>
    2f18:	294b0402 	ldp	w2, w1, [x0, #88]
    2f1c:	37f80202 	tbnz	w2, #31, 2f5c <fwp_tape_unlink_scope+0x4c>
    2f20:	d00000e4 	adrp	x4, 20000 <__data_start>
    2f24:	52800d03 	mov	w3, #0x68                  	// #104
    2f28:	f9402084 	ldr	x4, [x4, #64]
    2f2c:	9b231043 	smaddl	x3, w2, w3, x4
    2f30:	b9005c61 	str	w1, [x3, #92]
    2f34:	37f800c1 	tbnz	w1, #31, 2f4c <fwp_tape_unlink_scope+0x3c>
    2f38:	d00000e3 	adrp	x3, 20000 <__data_start>
    2f3c:	52800d04 	mov	w4, #0x68                  	// #104
    2f40:	f9402063 	ldr	x3, [x3, #64]
    2f44:	9b240c21 	smaddl	x1, w1, w4, x3
    2f48:	b9005822 	str	w2, [x1, #88]
    2f4c:	2f000400 	mvni	v0.2s, #0x0
    2f50:	f900281f 	str	xzr, [x0, #80]
    2f54:	fd002c00 	str	d0, [x0, #88]
    2f58:	d65f03c0 	ret
    2f5c:	b9000061 	str	w1, [x3]
    2f60:	17fffff5 	b	2f34 <fwp_tape_unlink_scope+0x24>

0000000000002f64 <fwp_args161>:
    2f64:	d65f03c0 	ret
    2f68:	d503201f 	nop
    2f6c:	d503201f 	nop

0000000000002f70 <fwp_flush>:
    2f70:	d00000e0 	adrp	x0, 20000 <__data_start>
    2f74:	f9402400 	ldr	x0, [x0, #72]
    2f78:	b4000120 	cbz	x0, 2f9c <fwp_flush+0x2c>
    2f7c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2f80:	910003fd 	mov	x29, sp
    2f84:	97fffe67 	bl	2920 <fflush@plt>
    2f88:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2f8c:	f947ec00 	ldr	x0, [x0, #4056]
    2f90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    2f94:	f9400000 	ldr	x0, [x0]
    2f98:	17fffe62 	b	2920 <fflush@plt>
    2f9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    2fa0:	f947ec00 	ldr	x0, [x0, #4056]
    2fa4:	f9400000 	ldr	x0, [x0]
    2fa8:	17fffe5e 	b	2920 <fflush@plt>
    2fac:	d503201f 	nop

0000000000002fb0 <fwp_heap_oom>:
    2fb0:	b00000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    2fb4:	f947e863 	ldr	x3, [x3, #4048]
    2fb8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2fbc:	d2800262 	mov	x2, #0x13                  	// #19
    2fc0:	910003fd 	mov	x29, sp
    2fc4:	f9400063 	ldr	x3, [x3]
    2fc8:	d2800021 	mov	x1, #0x1                   	// #1
    2fcc:	b0000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    2fd0:	91216000 	add	x0, x0, #0x858
    2fd4:	97fffe47 	bl	28f0 <fwrite@plt>
    2fd8:	d2800000 	mov	x0, #0x0                   	// #0
    2fdc:	97fffe51 	bl	2920 <fflush@plt>
    2fe0:	52800cc0 	mov	w0, #0x66                  	// #102
    2fe4:	97fffe5f 	bl	2960 <_Exit@plt>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_segv>:
    2ff0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    2ff4:	d00000e2 	adrp	x2, 20000 <__data_start>
    2ff8:	91010043 	add	x3, x2, #0x40
    2ffc:	910003fd 	mov	x29, sp
    3000:	a90153f3 	stp	x19, x20, [sp, #16]
    3004:	2a0003f3 	mov	w19, w0
    3008:	f9400860 	ldr	x0, [x3, #16]
    300c:	f90013f5 	str	x21, [sp, #32]
    3010:	f9400835 	ldr	x21, [x1, #16]
    3014:	b4000280 	cbz	x0, 3064 <fwp_segv+0x74>
    3018:	f9400814 	ldr	x20, [x0, #16]
    301c:	b4000254 	cbz	x20, 3064 <fwp_segv+0x74>
    3020:	528003c0 	mov	w0, #0x1e                  	// #30
    3024:	97fffe47 	bl	2940 <sysconf@plt>
    3028:	f144029f 	cmp	x20, #0x100, lsl #12
    302c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3030:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3034:	8b000294 	add	x20, x20, x0
    3038:	d1440021 	sub	x1, x1, #0x100, lsl #12
    303c:	eb0102bf 	cmp	x21, x1
    3040:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3044:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3048:	35000240 	cbnz	w0, 3090 <fwp_segv+0xa0>
    304c:	f94013f5 	ldr	x21, [sp, #32]
    3050:	2a1303e0 	mov	w0, w19
    3054:	a94153f3 	ldp	x19, x20, [sp, #16]
    3058:	d2800001 	mov	x1, #0x0                   	// #0
    305c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3060:	17fffdbc 	b	2750 <signal@plt>
    3064:	91010042 	add	x2, x2, #0x40
    3068:	f9400c40 	ldr	x0, [x2, #24]
    306c:	b4ffff00 	cbz	x0, 304c <fwp_segv+0x5c>
    3070:	f9401041 	ldr	x1, [x2, #32]
    3074:	cb010000 	sub	x0, x0, x1
    3078:	d1440001 	sub	x1, x0, #0x100, lsl #12
    307c:	91440000 	add	x0, x0, #0x100, lsl #12
    3080:	eb15003f 	cmp	x1, x21
    3084:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3088:	1a9f97e0 	cset	w0, hi	// hi = pmore
    308c:	34fffe00 	cbz	w0, 304c <fwp_segv+0x5c>
    3090:	97ffffb8 	bl	2f70 <fwp_flush>
    3094:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0x7b0>
    3098:	91130021 	add	x1, x1, #0x4c0
    309c:	d2800342 	mov	x2, #0x1a                  	// #26
    30a0:	52800040 	mov	w0, #0x2                   	// #2
    30a4:	97fffde3 	bl	2830 <write@plt>
    30a8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ac:	97fffd71 	bl	2670 <_exit@plt>

00000000000030b0 <fwp_heap_chunks>:
    30b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    30b4:	910003fd 	mov	x29, sp
    30b8:	a90153f3 	stp	x19, x20, [sp, #16]
    30bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    30c0:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    30c4:	911542a1 	add	x1, x21, #0x550
    30c8:	f100041f 	cmp	x0, #0x1
    30cc:	54000ca0 	b.eq	3260 <fwp_heap_chunks+0x1b0>  // b.none
    30d0:	f949f822 	ldr	x2, [x1, #5104]
    30d4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    30d8:	912500a5 	add	x5, x5, #0x940
    30dc:	911542a1 	add	x1, x21, #0x550
    30e0:	f949ec34 	ldr	x20, [x1, #5080]
    30e4:	eb14005f 	cmp	x2, x20
    30e8:	54000c42 	b.cs	3270 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    30ec:	f949fc23 	ldr	x3, [x1, #5112]
    30f0:	8b020841 	add	x1, x2, x2, lsl #2
    30f4:	d2800004 	mov	x4, #0x0                   	// #0
    30f8:	8b010c61 	add	x1, x3, x1, lsl #3
    30fc:	14000009 	b	3120 <fwp_heap_chunks+0x70>
    3100:	91000483 	add	x3, x4, #0x1
    3104:	eb03001f 	cmp	x0, x3
    3108:	54000940 	b.eq	3230 <fwp_heap_chunks+0x180>  // b.none
    310c:	91000442 	add	x2, x2, #0x1
    3110:	aa0303e4 	mov	x4, x3
    3114:	9100a021 	add	x1, x1, #0x28
    3118:	eb02029f 	cmp	x20, x2
    311c:	54000100 	b.eq	313c <fwp_heap_chunks+0x8c>  // b.none
    3120:	39400023 	ldrb	w3, [x1]
    3124:	34fffee3 	cbz	w3, 3100 <fwp_heap_chunks+0x50>
    3128:	91000442 	add	x2, x2, #0x1
    312c:	9100a021 	add	x1, x1, #0x28
    3130:	d2800004 	mov	x4, #0x0                   	// #0
    3134:	eb02029f 	cmp	x20, x2
    3138:	54ffff41 	b.ne	3120 <fwp_heap_chunks+0x70>  // b.any
    313c:	cb040294 	sub	x20, x20, x4
    3140:	f9001bf7 	str	x23, [sp, #48]
    3144:	911542b7 	add	x23, x21, #0x550
    3148:	8b140013 	add	x19, x0, x20
    314c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3150:	f949f2e0 	ldr	x0, [x23, #5088]
    3154:	cb040021 	sub	x1, x1, x4
    3158:	f90a1ae1 	str	x1, [x23, #5168]
    315c:	eb00027f 	cmp	x19, x0
    3160:	54000429 	b.ls	31e4 <fwp_heap_chunks+0x134>  // b.plast
    3164:	f949eae1 	ldr	x1, [x23, #5072]
    3168:	eb01027f 	cmp	x19, x1
    316c:	54000888 	b.hi	327c <fwp_heap_chunks+0x1cc>  // b.pmore
    3170:	91010276 	add	x22, x19, #0x40
    3174:	52800062 	mov	w2, #0x3                   	// #3
    3178:	f949dae3 	ldr	x3, [x23, #5040]
    317c:	eb0102df 	cmp	x22, x1
    3180:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3184:	cb0002c1 	sub	x1, x22, x0
    3188:	8b004060 	add	x0, x3, x0, lsl #16
    318c:	d370bc21 	lsl	x1, x1, #16
    3190:	97fffe04 	bl	29a0 <mprotect@plt>
    3194:	35000740 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    3198:	528003c0 	mov	w0, #0x1e                  	// #30
    319c:	97fffde9 	bl	2940 <sysconf@plt>
    31a0:	f949f2e2 	ldr	x2, [x23, #5088]
    31a4:	cb0003e5 	neg	x5, x0
    31a8:	aa0003e4 	mov	x4, x0
    31ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    31b0:	f949fee0 	ldr	x0, [x23, #5112]
    31b4:	8b020843 	add	x3, x2, x2, lsl #2
    31b8:	52800062 	mov	w2, #0x3                   	// #3
    31bc:	8b010c01 	add	x1, x0, x1, lsl #3
    31c0:	8b030c03 	add	x3, x0, x3, lsl #3
    31c4:	d1000421 	sub	x1, x1, #0x1
    31c8:	8a050060 	and	x0, x3, x5
    31cc:	8b040021 	add	x1, x1, x4
    31d0:	8a050021 	and	x1, x1, x5
    31d4:	cb000021 	sub	x1, x1, x0
    31d8:	97fffdf2 	bl	29a0 <mprotect@plt>
    31dc:	35000500 	cbnz	w0, 327c <fwp_heap_chunks+0x1cc>
    31e0:	f909f2f6 	str	x22, [x23, #5088]
    31e4:	911542b5 	add	x21, x21, #0x550
    31e8:	d370be60 	lsl	x0, x19, #16
    31ec:	f949e6a1 	ldr	x1, [x21, #5064]
    31f0:	f909eeb3 	str	x19, [x21, #5080]
    31f4:	eb01001f 	cmp	x0, x1
    31f8:	540000e8 	b.hi	3214 <fwp_heap_chunks+0x164>  // b.pmore
    31fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3200:	aa1403e0 	mov	x0, x20
    3204:	a94153f3 	ldp	x19, x20, [sp, #16]
    3208:	f9401bf7 	ldr	x23, [sp, #48]
    320c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3210:	d65f03c0 	ret
    3214:	f9401bf7 	ldr	x23, [sp, #48]
    3218:	f909e6a0 	str	x0, [x21, #5064]
    321c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3220:	aa1403e0 	mov	x0, x20
    3224:	a94153f3 	ldp	x19, x20, [sp, #16]
    3228:	a8c47bfd 	ldp	x29, x30, [sp], #64
    322c:	d65f03c0 	ret
    3230:	911542b5 	add	x21, x21, #0x550
    3234:	91000441 	add	x1, x2, #0x1
    3238:	f90000a1 	str	x1, [x5]
    323c:	cb040054 	sub	x20, x2, x4
    3240:	f94a1aa1 	ldr	x1, [x21, #5168]
    3244:	cb000020 	sub	x0, x1, x0
    3248:	f90a1aa0 	str	x0, [x21, #5168]
    324c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3250:	aa1403e0 	mov	x0, x20
    3254:	a94153f3 	ldp	x19, x20, [sp, #16]
    3258:	a8c47bfd 	ldp	x29, x30, [sp], #64
    325c:	d65f03c0 	ret
    3260:	f949f422 	ldr	x2, [x1, #5096]
    3264:	f0000165 	adrp	x5, 32000 <fwp_heap+0xab0>
    3268:	9124e0a5 	add	x5, x5, #0x938
    326c:	17ffff9c 	b	30dc <fwp_heap_chunks+0x2c>
    3270:	d2800004 	mov	x4, #0x0                   	// #0
    3274:	f9001bf7 	str	x23, [sp, #48]
    3278:	17ffffb3 	b	3144 <fwp_heap_chunks+0x94>
    327c:	97ffff4d 	bl	2fb0 <fwp_heap_oom>

0000000000003280 <fwp_tape_buffers_dispose>:
    3280:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3284:	910003fd 	mov	x29, sp
    3288:	f9000bf3 	str	x19, [sp, #16]
    328c:	aa0003f3 	mov	x19, x0
    3290:	f9400000 	ldr	x0, [x0]
    3294:	97fffd87 	bl	28b0 <free@plt>
    3298:	f9400a60 	ldr	x0, [x19, #16]
    329c:	97fffd85 	bl	28b0 <free@plt>
    32a0:	f9401260 	ldr	x0, [x19, #32]
    32a4:	97fffd83 	bl	28b0 <free@plt>
    32a8:	f9001a7f 	str	xzr, [x19, #48]
    32ac:	4f000400 	movi	v0.4s, #0x0
    32b0:	ad000260 	stp	q0, q0, [x19]
    32b4:	3d800a60 	str	q0, [x19, #32]
    32b8:	f9400bf3 	ldr	x19, [sp, #16]
    32bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    32c0:	d65f03c0 	ret

00000000000032c4 <buf_grow>:
    32c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    32c8:	910003fd 	mov	x29, sp
    32cc:	a90153f3 	stp	x19, x20, [sp, #16]
    32d0:	aa0003f4 	mov	x20, x0
    32d4:	f9400400 	ldr	x0, [x0, #8]
    32d8:	b100041f 	cmn	x0, #0x1
    32dc:	54000400 	b.eq	335c <buf_grow+0x98>  // b.none
    32e0:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    32e4:	cb000042 	sub	x2, x2, x0
    32e8:	eb01005f 	cmp	x2, x1
    32ec:	54000383 	b.cc	335c <buf_grow+0x98>  // b.lo, b.ul, b.last
    32f0:	f9400a82 	ldr	x2, [x20, #16]
    32f4:	91000421 	add	x1, x1, #0x1
    32f8:	8b000033 	add	x19, x1, x0
    32fc:	eb13005f 	cmp	x2, x19
    3300:	54000242 	b.cs	3348 <buf_grow+0x84>  // b.hs, b.nlast
    3304:	f100005f 	cmp	x2, #0x0
    3308:	b5000262 	cbnz	x2, 3354 <buf_grow+0x90>
    330c:	d2800802 	mov	x2, #0x40                  	// #64
    3310:	eb02027f 	cmp	x19, x2
    3314:	54000068 	b.hi	3320 <buf_grow+0x5c>  // b.pmore
    3318:	14000005 	b	332c <buf_grow+0x68>
    331c:	b7f800a2 	tbnz	x2, #63, 3330 <buf_grow+0x6c>
    3320:	d37ff842 	lsl	x2, x2, #1
    3324:	eb02027f 	cmp	x19, x2
    3328:	54ffffa8 	b.hi	331c <buf_grow+0x58>  // b.pmore
    332c:	aa0203f3 	mov	x19, x2
    3330:	f9400280 	ldr	x0, [x20]
    3334:	aa1303e1 	mov	x1, x19
    3338:	97fffd2a 	bl	27e0 <realloc@plt>
    333c:	b4000100 	cbz	x0, 335c <buf_grow+0x98>
    3340:	f9000280 	str	x0, [x20]
    3344:	f9000a93 	str	x19, [x20, #16]
    3348:	a94153f3 	ldp	x19, x20, [sp, #16]
    334c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3350:	d65f03c0 	ret
    3354:	54fffe6a 	b.ge	3320 <buf_grow+0x5c>  // b.tcont
    3358:	17fffff6 	b	3330 <buf_grow+0x6c>
    335c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    3360:	f947e863 	ldr	x3, [x3, #4048]
    3364:	d2800262 	mov	x2, #0x13                  	// #19
    3368:	d2800021 	mov	x1, #0x1                   	// #1
    336c:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    3370:	91216000 	add	x0, x0, #0x858
    3374:	f9400063 	ldr	x3, [x3]
    3378:	97fffd5e 	bl	28f0 <fwrite@plt>
    337c:	d2800000 	mov	x0, #0x0                   	// #0
    3380:	97fffd68 	bl	2920 <fflush@plt>
    3384:	52800cc0 	mov	w0, #0x66                  	// #102
    3388:	97fffd76 	bl	2960 <_Exit@plt>
    338c:	d503201f 	nop

0000000000003390 <buf_put>:
    3390:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3394:	910003fd 	mov	x29, sp
    3398:	a90153f3 	stp	x19, x20, [sp, #16]
    339c:	aa0003f4 	mov	x20, x0
    33a0:	aa0203f3 	mov	x19, x2
    33a4:	f90013f5 	str	x21, [sp, #32]
    33a8:	aa0103f5 	mov	x21, x1
    33ac:	aa0203e1 	mov	x1, x2
    33b0:	97ffffc5 	bl	32c4 <buf_grow>
    33b4:	a9400283 	ldp	x3, x0, [x20]
    33b8:	aa1503e1 	mov	x1, x21
    33bc:	aa1303e2 	mov	x2, x19
    33c0:	8b000060 	add	x0, x3, x0
    33c4:	97fffc9f 	bl	2640 <memcpy@plt>
    33c8:	a9400680 	ldp	x0, x1, [x20]
    33cc:	8b010273 	add	x19, x19, x1
    33d0:	f9000693 	str	x19, [x20, #8]
    33d4:	3833681f 	strb	wzr, [x0, x19]
    33d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33dc:	f94013f5 	ldr	x21, [sp, #32]
    33e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    33e4:	d65f03c0 	ret
    33e8:	d503201f 	nop
    33ec:	d503201f 	nop

00000000000033f0 <fwp_cancel_tree.part.0>:
    33f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    33f4:	91010022 	add	x2, x1, #0x40
    33f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    33fc:	52800023 	mov	w3, #0x1                   	// #1
    3400:	910003fd 	mov	x29, sp
    3404:	f9400844 	ldr	x4, [x2, #16]
    3408:	f9000bf3 	str	x19, [sp, #16]
    340c:	39014403 	strb	w3, [x0, #81]
    3410:	eb04001f 	cmp	x0, x4
    3414:	54000160 	b.eq	3440 <fwp_cancel_tree.part.0+0x50>  // b.none
    3418:	f9402804 	ldr	x4, [x0, #80]
    341c:	f2001c9f 	tst	x4, #0xff000000ff
    3420:	54000101 	b.ne	3440 <fwp_cancel_tree.part.0+0x50>  // b.any
    3424:	f9401444 	ldr	x4, [x2, #40]
    3428:	39015003 	strb	w3, [x0, #84]
    342c:	f900801f 	str	xzr, [x0, #256]
    3430:	b40001e4 	cbz	x4, 346c <fwp_cancel_tree.part.0+0x7c>
    3434:	f9008080 	str	x0, [x4, #256]
    3438:	91010021 	add	x1, x1, #0x40
    343c:	f9001420 	str	x0, [x1, #40]
    3440:	f9401413 	ldr	x19, [x0, #40]
    3444:	b40000f3 	cbz	x19, 3460 <fwp_cancel_tree.part.0+0x70>
    3448:	39414261 	ldrb	w1, [x19, #80]
    344c:	aa1303e0 	mov	x0, x19
    3450:	37000041 	tbnz	w1, #0, 3458 <fwp_cancel_tree.part.0+0x68>
    3454:	97ffffe7 	bl	33f0 <fwp_cancel_tree.part.0>
    3458:	f9401a73 	ldr	x19, [x19, #48]
    345c:	b5ffff73 	cbnz	x19, 3448 <fwp_cancel_tree.part.0+0x58>
    3460:	f9400bf3 	ldr	x19, [sp, #16]
    3464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3468:	d65f03c0 	ret
    346c:	f9001840 	str	x0, [x2, #48]
    3470:	17fffff2 	b	3438 <fwp_cancel_tree.part.0+0x48>

0000000000003474 <fwp_finish_float>:
    3474:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3478:	528005c1 	mov	w1, #0x2e                  	// #46
    347c:	910003fd 	mov	x29, sp
    3480:	f9000bf3 	str	x19, [sp, #16]
    3484:	aa0003f3 	mov	x19, x0
    3488:	97fffd12 	bl	28d0 <strchr@plt>
    348c:	b4000080 	cbz	x0, 349c <fwp_finish_float+0x28>
    3490:	f9400bf3 	ldr	x19, [sp, #16]
    3494:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3498:	d65f03c0 	ret
    349c:	aa1303e0 	mov	x0, x19
    34a0:	52800ca1 	mov	w1, #0x65                  	// #101
    34a4:	97fffd0b 	bl	28d0 <strchr@plt>
    34a8:	b5ffff40 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34ac:	90000041 	adrp	x1, b000 <fwp_main_thread+0x1730>
    34b0:	aa1303e0 	mov	x0, x19
    34b4:	9121c021 	add	x1, x1, #0x870
    34b8:	97fffd26 	bl	2950 <strstr@plt>
    34bc:	b5fffea0 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34c0:	90000041 	adrp	x1, b000 <fwp_main_thread+0x1730>
    34c4:	aa1303e0 	mov	x0, x19
    34c8:	9121e021 	add	x1, x1, #0x878
    34cc:	97fffd21 	bl	2950 <strstr@plt>
    34d0:	b5fffe00 	cbnz	x0, 3490 <fwp_finish_float+0x1c>
    34d4:	aa1303e0 	mov	x0, x19
    34d8:	97fffc6a 	bl	2680 <strlen@plt>
    34dc:	90000041 	adrp	x1, b000 <fwp_main_thread+0x1730>
    34e0:	91220021 	add	x1, x1, #0x880
    34e4:	8b000262 	add	x2, x19, x0
    34e8:	79400023 	ldrh	w3, [x1]
    34ec:	39400821 	ldrb	w1, [x1, #2]
    34f0:	78206a63 	strh	w3, [x19, x0]
    34f4:	39000841 	strb	w1, [x2, #2]
    34f8:	17ffffe6 	b	3490 <fwp_finish_float+0x1c>
    34fc:	d503201f 	nop

0000000000003500 <fwp_format_g.constprop.0>:
    3500:	d10483ff 	sub	sp, sp, #0x120
    3504:	90000044 	adrp	x4, b000 <fwp_main_thread+0x1730>
    3508:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    350c:	f947f442 	ldr	x2, [x2, #4072]
    3510:	91222084 	add	x4, x4, #0x888
    3514:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3518:	9102c3fd 	add	x29, sp, #0xb0
    351c:	d2800803 	mov	x3, #0x40                  	// #64
    3520:	a90e63f7 	stp	x23, x24, [sp, #224]
    3524:	93407c38 	sxtw	x24, w1
    3528:	aa0303e1 	mov	x1, x3
    352c:	fd008be8 	str	d8, [sp, #272]
    3530:	1e604008 	fmov	d8, d0
    3534:	a90c53f3 	stp	x19, x20, [sp, #192]
    3538:	910083f4 	add	x20, sp, #0x20
    353c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3540:	aa0003f5 	mov	x21, x0
    3544:	a91073fb 	stp	x27, x28, [sp, #256]
    3548:	5100071c 	sub	w28, w24, #0x1
    354c:	2a1c03e5 	mov	w5, w28
    3550:	f9400040 	ldr	x0, [x2]
    3554:	f90057e0 	str	x0, [sp, #168]
    3558:	d2800000 	mov	x0, #0x0                   	// #0
    355c:	52800042 	mov	w2, #0x2                   	// #2
    3560:	aa1403e0 	mov	x0, x20
    3564:	97fffc7f 	bl	2760 <__snprintf_chk@plt>
    3568:	52800ca1 	mov	w1, #0x65                  	// #101
    356c:	aa1403e0 	mov	x0, x20
    3570:	97fffcd8 	bl	28d0 <strchr@plt>
    3574:	aa0003f3 	mov	x19, x0
    3578:	52800142 	mov	w2, #0xa                   	// #10
    357c:	91000400 	add	x0, x0, #0x1
    3580:	d2800001 	mov	x1, #0x0                   	// #0
    3584:	97fffcc3 	bl	2890 <strtol@plt>
    3588:	aa0003f7 	mov	x23, x0
    358c:	11001400 	add	w0, w0, #0x5
    3590:	7100541f 	cmp	w0, #0x15
    3594:	54000d68 	b.hi	3740 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3598:	4b170385 	sub	w5, w28, w23
    359c:	710000bf 	cmp	w5, #0x0
    35a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    35a4:	54000b80 	b.eq	3714 <fwp_format_g.constprop.0+0x214>  // b.none
    35a8:	394083e0 	ldrb	w0, [sp, #32]
    35ac:	cb180273 	sub	x19, x19, x24
    35b0:	91000673 	add	x19, x19, #0x1
    35b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    35b8:	7100b41f 	cmp	w0, #0x2d
    35bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    35c0:	1a9f17e4 	cset	w4, eq	// eq = none
    35c4:	cb010266 	sub	x6, x19, x1
    35c8:	d10004da 	sub	x26, x6, #0x1
    35cc:	540018a0 	b.eq	38e0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    35d0:	910183f9 	add	x25, sp, #0x60
    35d4:	d280091b 	mov	x27, #0x48                  	// #72
    35d8:	aa1903e7 	mov	x7, x25
    35dc:	91000423 	add	x3, x1, #0x1
    35e0:	91011cc6 	add	x6, x6, #0x47
    35e4:	910004f6 	add	x22, x7, #0x1
    35e8:	37f80ff7 	tbnz	w23, #31, 37e4 <fwp_format_g.constprop.0+0x2e4>
    35ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    35f0:	93407ef7 	sxtw	x23, w23
    35f4:	390000e4 	strb	w4, [x7]
    35f8:	aa1303e1 	mov	x1, x19
    35fc:	aa1703e2 	mov	x2, x23
    3600:	aa1603e0 	mov	x0, x22
    3604:	b9000be5 	str	w5, [sp, #8]
    3608:	cb170374 	sub	x20, x27, x23
    360c:	a9011be3 	stp	x3, x6, [sp, #16]
    3610:	97fffc0c 	bl	2640 <memcpy@plt>
    3614:	d1000694 	sub	x20, x20, #0x1
    3618:	f9400be3 	ldr	x3, [sp, #16]
    361c:	8b1702d6 	add	x22, x22, x23
    3620:	aa1603e0 	mov	x0, x22
    3624:	aa1a03e2 	mov	x2, x26
    3628:	aa0303e1 	mov	x1, x3
    362c:	aa1403e3 	mov	x3, x20
    3630:	97fffc44 	bl	2740 <__memcpy_chk@plt>
    3634:	8b1a02d6 	add	x22, x22, x26
    3638:	f9400fe6 	ldr	x6, [sp, #24]
    363c:	d2800900 	mov	x0, #0x48                  	// #72
    3640:	b9400be5 	ldr	w5, [sp, #8]
    3644:	8b170261 	add	x1, x19, x23
    3648:	cb1400c3 	sub	x3, x6, x20
    364c:	cb060294 	sub	x20, x20, x6
    3650:	f101207f 	cmp	x3, #0x48
    3654:	93407cb8 	sxtw	x24, w5
    3658:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    365c:	aa1803e2 	mov	x2, x24
    3660:	8b1802d3 	add	x19, x22, x24
    3664:	8b140063 	add	x3, x3, x20
    3668:	aa1603e0 	mov	x0, x22
    366c:	97fffc35 	bl	2740 <__memcpy_chk@plt>
    3670:	cb190273 	sub	x19, x19, x25
    3674:	d28031e0 	mov	x0, #0x18f                 	// #399
    3678:	eb00027f 	cmp	x19, x0
    367c:	aa1903e1 	mov	x1, x25
    3680:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3684:	aa1503e0 	mov	x0, x21
    3688:	aa1303e2 	mov	x2, x19
    368c:	97fffbed 	bl	2640 <memcpy@plt>
    3690:	38336abf 	strb	wzr, [x21, x19]
    3694:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3698:	aa1503e0 	mov	x0, x21
    369c:	97fffbf9 	bl	2680 <strlen@plt>
    36a0:	aa0003f3 	mov	x19, x0
    36a4:	528005c1 	mov	w1, #0x2e                  	// #46
    36a8:	aa1503e0 	mov	x0, x21
    36ac:	97fffc89 	bl	28d0 <strchr@plt>
    36b0:	b4000140 	cbz	x0, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b4:	b4000133 	cbz	x19, 36d8 <fwp_format_g.constprop.0+0x1d8>
    36b8:	aa1303e1 	mov	x1, x19
    36bc:	d1000673 	sub	x19, x19, #0x1
    36c0:	38736aa0 	ldrb	w0, [x21, x19]
    36c4:	7100c01f 	cmp	w0, #0x30
    36c8:	54001001 	b.ne	38c8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    36cc:	38336abf 	strb	wzr, [x21, x19]
    36d0:	b5ffff53 	cbnz	x19, 36b8 <fwp_format_g.constprop.0+0x1b8>
    36d4:	d503201f 	nop
    36d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    36dc:	f947f400 	ldr	x0, [x0, #4072]
    36e0:	f94057e2 	ldr	x2, [sp, #168]
    36e4:	f9400001 	ldr	x1, [x0]
    36e8:	eb010042 	subs	x2, x2, x1
    36ec:	d2800001 	mov	x1, #0x0                   	// #0
    36f0:	54001061 	b.ne	38fc <fwp_format_g.constprop.0+0x3fc>  // b.any
    36f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    36f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    36fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3700:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3704:	a95073fb 	ldp	x27, x28, [sp, #256]
    3708:	fd408be8 	ldr	d8, [sp, #272]
    370c:	910483ff 	add	sp, sp, #0x120
    3710:	d65f03c0 	ret
    3714:	1e604100 	fmov	d0, d8
    3718:	710000bf 	cmp	w5, #0x0
    371c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3720:	aa1503e0 	mov	x0, x21
    3724:	90000044 	adrp	x4, b000 <fwp_main_thread+0x1730>
    3728:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    372c:	91228084 	add	x4, x4, #0x8a0
    3730:	52800042 	mov	w2, #0x2                   	// #2
    3734:	d2803201 	mov	x1, #0x190                 	// #400
    3738:	97fffc0a 	bl	2760 <__snprintf_chk@plt>
    373c:	17ffffd7 	b	3698 <fwp_format_g.constprop.0+0x198>
    3740:	cb140273 	sub	x19, x19, x20
    3744:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3748:	910183f9 	add	x25, sp, #0x60
    374c:	aa1303e2 	mov	x2, x19
    3750:	aa1403e1 	mov	x1, x20
    3754:	aa1903e0 	mov	x0, x25
    3758:	d2800803 	mov	x3, #0x40                  	// #64
    375c:	97fffbf9 	bl	2740 <__memcpy_chk@plt>
    3760:	38336b3f 	strb	wzr, [x25, x19]
    3764:	aa1903e0 	mov	x0, x25
    3768:	528005c1 	mov	w1, #0x2e                  	// #46
    376c:	97fffc59 	bl	28d0 <strchr@plt>
    3770:	b40001c0 	cbz	x0, 37a8 <fwp_format_g.constprop.0+0x2a8>
    3774:	b50000b3 	cbnz	x19, 3788 <fwp_format_g.constprop.0+0x288>
    3778:	1400000c 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    377c:	381ff01f 	sturb	wzr, [x0, #-1]
    3780:	f1000673 	subs	x19, x19, #0x1
    3784:	54000120 	b.eq	37a8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3788:	8b130320 	add	x0, x25, x19
    378c:	385ff001 	ldurb	w1, [x0, #-1]
    3790:	7100c03f 	cmp	w1, #0x30
    3794:	54ffff40 	b.eq	377c <fwp_format_g.constprop.0+0x27c>  // b.none
    3798:	d1000673 	sub	x19, x19, #0x1
    379c:	38736b20 	ldrb	w0, [x25, x19]
    37a0:	7100b81f 	cmp	w0, #0x2e
    37a4:	54000a80 	b.eq	38f4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    37a8:	710002ff 	cmp	w23, #0x0
    37ac:	528005a1 	mov	w1, #0x2d                  	// #45
    37b0:	aa1903e5 	mov	x5, x25
    37b4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    37b8:	aa1503e0 	mov	x0, x21
    37bc:	52800566 	mov	w6, #0x2b                  	// #43
    37c0:	90000044 	adrp	x4, b000 <fwp_main_thread+0x1730>
    37c4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    37c8:	91224084 	add	x4, x4, #0x890
    37cc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    37d0:	52800042 	mov	w2, #0x2                   	// #2
    37d4:	d2803201 	mov	x1, #0x190                 	// #400
    37d8:	97fffbe2 	bl	2760 <__snprintf_chk@plt>
    37dc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    37e0:	17ffffbe 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    37e4:	52800605 	mov	w5, #0x30                  	// #48
    37e8:	390000e5 	strb	w5, [x7]
    37ec:	d100077b 	sub	x27, x27, #0x1
    37f0:	aa0303e1 	mov	x1, x3
    37f4:	aa1603e0 	mov	x0, x22
    37f8:	aa1b03e3 	mov	x3, x27
    37fc:	aa1a03e2 	mov	x2, x26
    3800:	f90007e6 	str	x6, [sp, #8]
    3804:	b90013e4 	str	w4, [sp, #16]
    3808:	8b1a02d6 	add	x22, x22, x26
    380c:	b9001be5 	str	w5, [sp, #24]
    3810:	97fffbcc 	bl	2740 <__memcpy_chk@plt>
    3814:	f94007e6 	ldr	x6, [sp, #8]
    3818:	2a3703e7 	mvn	w7, w23
    381c:	b94013e4 	ldr	w4, [sp, #16]
    3820:	cb1b00c1 	sub	x1, x6, x27
    3824:	cb06037b 	sub	x27, x27, x6
    3828:	f101203f 	cmp	x1, #0x48
    382c:	d2800906 	mov	x6, #0x48                  	// #72
    3830:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3834:	8b1b0023 	add	x3, x1, x27
    3838:	310006ff 	cmn	w23, #0x1
    383c:	54000220 	b.eq	3880 <fwp_format_g.constprop.0+0x380>  // b.none
    3840:	b9401be5 	ldr	w5, [sp, #24]
    3844:	d2800001 	mov	x1, #0x0                   	// #0
    3848:	f101207f 	cmp	x3, #0x48
    384c:	d1000462 	sub	x2, x3, #0x1
    3850:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3854:	38216ac5 	strb	w5, [x22, x1]
    3858:	cb030003 	sub	x3, x0, x3
    385c:	91000421 	add	x1, x1, #0x1
    3860:	91000463 	add	x3, x3, #0x1
    3864:	eb00007f 	cmp	x3, x0
    3868:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    386c:	cb000063 	sub	x3, x3, x0
    3870:	8b020063 	add	x3, x3, x2
    3874:	6b0100ff 	cmp	w7, w1
    3878:	54fffe8c 	b.gt	3848 <fwp_format_g.constprop.0+0x348>
    387c:	8b2742d6 	add	x22, x22, w7, uxtw
    3880:	f101207f 	cmp	x3, #0x48
    3884:	d2800905 	mov	x5, #0x48                  	// #72
    3888:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    388c:	aa1603e0 	mov	x0, x22
    3890:	cb0300a1 	sub	x1, x5, x3
    3894:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3898:	91000421 	add	x1, x1, #0x1
    389c:	d1000463 	sub	x3, x3, #0x1
    38a0:	eb05003f 	cmp	x1, x5
    38a4:	38001402 	strb	w2, [x0], #1
    38a8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    38ac:	93407f82 	sxtw	x2, w28
    38b0:	cb050025 	sub	x5, x1, x5
    38b4:	aa1303e1 	mov	x1, x19
    38b8:	8b0300a3 	add	x3, x5, x3
    38bc:	8b1802d3 	add	x19, x22, x24
    38c0:	97fffba0 	bl	2740 <__memcpy_chk@plt>
    38c4:	17ffff6b 	b	3670 <fwp_format_g.constprop.0+0x170>
    38c8:	d1000421 	sub	x1, x1, #0x1
    38cc:	38616aa0 	ldrb	w0, [x21, x1]
    38d0:	7100b81f 	cmp	w0, #0x2e
    38d4:	54fff021 	b.ne	36d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    38d8:	38216abf 	strb	wzr, [x21, x1]
    38dc:	17ffff7f 	b	36d8 <fwp_format_g.constprop.0+0x1d8>
    38e0:	910187e7 	add	x7, sp, #0x61
    38e4:	910183f9 	add	x25, sp, #0x60
    38e8:	d28008fb 	mov	x27, #0x47                  	// #71
    38ec:	390183e0 	strb	w0, [sp, #96]
    38f0:	17ffff3b 	b	35dc <fwp_format_g.constprop.0+0xdc>
    38f4:	38336b3f 	strb	wzr, [x25, x19]
    38f8:	17ffffac 	b	37a8 <fwp_format_g.constprop.0+0x2a8>
    38fc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3900:	97fffbbc 	bl	27f0 <__stack_chk_fail@plt>

0000000000003904 <fwp_heap_report>:
    3904:	d105c3ff 	sub	sp, sp, #0x170
    3908:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    390c:	91154042 	add	x2, x2, #0x550
    3910:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    3914:	f947e821 	ldr	x1, [x1, #4048]
    3918:	a9117bfd 	stp	x29, x30, [sp, #272]
    391c:	910443fd 	add	x29, sp, #0x110
    3920:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3924:	f947f400 	ldr	x0, [x0, #4072]
    3928:	a9135bf5 	stp	x21, x22, [sp, #304]
    392c:	a91463f7 	stp	x23, x24, [sp, #320]
    3930:	a9156bf9 	stp	x25, x26, [sp, #336]
    3934:	6d1627e8 	stp	d8, d9, [sp, #352]
    3938:	fd4a1c48 	ldr	d8, [x2, #5176]
    393c:	fd4a2049 	ldr	d9, [x2, #5184]
    3940:	f9400036 	ldr	x22, [x1]
    3944:	f9400001 	ldr	x1, [x0]
    3948:	f90087e1 	str	x1, [sp, #264]
    394c:	d2800001 	mov	x1, #0x0                   	// #0
    3950:	f949e459 	ldr	x25, [x2, #5064]
    3954:	90000041 	adrp	x1, b000 <fwp_main_thread+0x1730>
    3958:	f94a1057 	ldr	x23, [x2, #5152]
    395c:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    3960:	f94a1458 	ldr	x24, [x2, #5160]
    3964:	9122a021 	add	x1, x1, #0x8a8
    3968:	9122c000 	add	x0, x0, #0x8b0
    396c:	97fffb85 	bl	2780 <fopen@plt>
    3970:	b4000760 	cbz	x0, 3a5c <fwp_heap_report+0x158>
    3974:	528daad5 	mov	w21, #0x6d56                	// #27990
    3978:	a91253f3 	stp	x19, x20, [sp, #288]
    397c:	aa0003f4 	mov	x20, x0
    3980:	910023f3 	add	x19, sp, #0x8
    3984:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3988:	72aae915 	movk	w21, #0x5748, lsl #16
    398c:	d503201f 	nop
    3990:	aa1403e2 	mov	x2, x20
    3994:	aa1303e0 	mov	x0, x19
    3998:	52802001 	mov	w1, #0x100                 	// #256
    399c:	97fffc05 	bl	29b0 <fgets@plt>
    39a0:	b4000280 	cbz	x0, 39f0 <fwp_heap_report+0xec>
    39a4:	b9400261 	ldr	w1, [x19]
    39a8:	6b15003f 	cmp	w1, w21
    39ac:	54ffff21 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39b0:	39401260 	ldrb	w0, [x19, #4]
    39b4:	7101341f 	cmp	w0, #0x4d
    39b8:	54fffec1 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39bc:	394037e0 	ldrb	w0, [sp, #13]
    39c0:	7100e81f 	cmp	w0, #0x3a
    39c4:	54fffe61 	b.ne	3990 <fwp_heap_report+0x8c>  // b.any
    39c8:	52800142 	mov	w2, #0xa                   	// #10
    39cc:	d2800001 	mov	x1, #0x0                   	// #0
    39d0:	91003be0 	add	x0, sp, #0xe
    39d4:	97fffbaf 	bl	2890 <strtol@plt>
    39d8:	aa1403e2 	mov	x2, x20
    39dc:	aa0003fa 	mov	x26, x0
    39e0:	52802001 	mov	w1, #0x100                 	// #256
    39e4:	aa1303e0 	mov	x0, x19
    39e8:	97fffbf2 	bl	29b0 <fgets@plt>
    39ec:	b5fffdc0 	cbnz	x0, 39a4 <fwp_heap_report+0xa0>
    39f0:	aa1403e0 	mov	x0, x20
    39f4:	97fffb5f 	bl	2770 <fclose@plt>
    39f8:	a95253f3 	ldp	x19, x20, [sp, #288]
    39fc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3a00:	f947f400 	ldr	x0, [x0, #4072]
    3a04:	f94087e2 	ldr	x2, [sp, #264]
    3a08:	f9400001 	ldr	x1, [x0]
    3a0c:	eb010042 	subs	x2, x2, x1
    3a10:	d2800001 	mov	x1, #0x0                   	// #0
    3a14:	54000281 	b.ne	3a64 <fwp_heap_report+0x160>  // b.any
    3a18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3a1c:	aa1a03e6 	mov	x6, x26
    3a20:	aa1903e5 	mov	x5, x25
    3a24:	aa1803e4 	mov	x4, x24
    3a28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3a2c:	aa1703e3 	mov	x3, x23
    3a30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3a34:	aa1603e0 	mov	x0, x22
    3a38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3a3c:	1e604121 	fmov	d1, d9
    3a40:	1e604100 	fmov	d0, d8
    3a44:	90000042 	adrp	x2, b000 <fwp_main_thread+0x1730>
    3a48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3a4c:	91234042 	add	x2, x2, #0x8d0
    3a50:	9105c3ff 	add	sp, sp, #0x170
    3a54:	52800041 	mov	w1, #0x2                   	// #2
    3a58:	17fffb82 	b	2860 <__fprintf_chk@plt>
    3a5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3a60:	17ffffe7 	b	39fc <fwp_heap_report+0xf8>
    3a64:	a91253f3 	stp	x19, x20, [sp, #288]
    3a68:	97fffb62 	bl	27f0 <__stack_chk_fail@plt>
    3a6c:	d503201f 	nop

0000000000003a70 <fwp_heap_init>:
    3a70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a74:	f0000163 	adrp	x3, 32000 <fwp_heap+0xab0>
    3a78:	91114061 	add	x1, x3, #0x450
    3a7c:	910003fd 	mov	x29, sp
    3a80:	a90153f3 	stp	x19, x20, [sp, #16]
    3a84:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3a88:	91154262 	add	x2, x19, #0x550
    3a8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3a90:	52800024 	mov	w4, #0x1                   	// #1
    3a94:	52800200 	mov	w0, #0x10                  	// #16
    3a98:	b913a444 	str	w4, [x2, #5028]
    3a9c:	d503201f 	nop
    3aa0:	b8004420 	str	w0, [x1], #4
    3aa4:	11004000 	add	w0, w0, #0x10
    3aa8:	7104401f 	cmp	w0, #0x110
    3aac:	54ffffa1 	b.ne	3aa0 <fwp_heap_init+0x30>  // b.any
    3ab0:	b0000042 	adrp	x2, c000 <_IO_stdin_used+0x7b0>
    3ab4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3ab8:	f0000161 	adrp	x1, 32000 <fwp_heap+0xab0>
    3abc:	91124021 	add	x1, x1, #0x490
    3ac0:	3dc13c43 	ldr	q3, [x2, #1264]
    3ac4:	d2800000 	mov	x0, #0x0                   	// #0
    3ac8:	4e040401 	dup	v1.4s, v0.s[0]
    3acc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3ad0:	0f215400 	shl	v0.2s, v0.2s, #1
    3ad4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3ad8:	3ca06821 	str	q1, [x1, x0]
    3adc:	91004000 	add	x0, x0, #0x10
    3ae0:	f101801f 	cmp	x0, #0x60
    3ae4:	54ffff21 	b.ne	3ac8 <fwp_heap_init+0x58>  // b.any
    3ae8:	f0000164 	adrp	x4, 32000 <fwp_heap+0xab0>
    3aec:	91114063 	add	x3, x3, #0x450
    3af0:	9113c084 	add	x4, x4, #0x4f0
    3af4:	91154266 	add	x6, x19, #0x550
    3af8:	d2800002 	mov	x2, #0x0                   	// #0
    3afc:	d2800000 	mov	x0, #0x0                   	// #0
    3b00:	d2880205 	mov	x5, #0x4010                	// #16400
    3b04:	d503201f 	nop
    3b08:	910f0001 	add	x1, x0, #0x3c0
    3b0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3b10:	eb02003f 	cmp	x1, x2
    3b14:	540000a2 	b.cs	3b28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3b18:	91000400 	add	x0, x0, #0x1
    3b1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3b20:	eb02003f 	cmp	x1, x2
    3b24:	54ffffa3 	b.cc	3b18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3b28:	91004042 	add	x2, x2, #0x10
    3b2c:	38001480 	strb	w0, [x4], #1
    3b30:	eb05005f 	cmp	x2, x5
    3b34:	54fffea1 	b.ne	3b08 <fwp_heap_init+0x98>  // b.any
    3b38:	528000b5 	mov	w21, #0x5                   	// #5
    3b3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3b40:	14000004 	b	3b50 <fwp_heap_init+0xe0>
    3b44:	d342fe94 	lsr	x20, x20, #2
    3b48:	710006b5 	subs	w21, w21, #0x1
    3b4c:	54000720 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3b50:	91404296 	add	x22, x20, #0x10, lsl #12
    3b54:	d2800005 	mov	x5, #0x0                   	// #0
    3b58:	aa1603e1 	mov	x1, x22
    3b5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3b60:	52880443 	mov	w3, #0x4022                	// #16418
    3b64:	52800002 	mov	w2, #0x0                   	// #0
    3b68:	d2800000 	mov	x0, #0x0                   	// #0
    3b6c:	97fffb45 	bl	2880 <mmap@plt>
    3b70:	aa0003e6 	mov	x6, x0
    3b74:	b100041f 	cmn	x0, #0x1
    3b78:	54fffe60 	b.eq	3b44 <fwp_heap_init+0xd4>  // b.none
    3b7c:	b40005a0 	cbz	x0, 3c30 <fwp_heap_init+0x1c0>
    3b80:	d350fe94 	lsr	x20, x20, #16
    3b84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3b88:	8b0000c7 	add	x7, x6, x0
    3b8c:	91154275 	add	x21, x19, #0x550
    3b90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3b94:	8b140a81 	add	x1, x20, x20, lsl #2
    3b98:	d2800005 	mov	x5, #0x0                   	// #0
    3b9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ba0:	d37df021 	lsl	x1, x1, #3
    3ba4:	52880443 	mov	w3, #0x4022                	// #16418
    3ba8:	52800002 	mov	w2, #0x0                   	// #0
    3bac:	d2800000 	mov	x0, #0x0                   	// #0
    3bb0:	f909daa7 	str	x7, [x21, #5040]
    3bb4:	f909dea6 	str	x6, [x21, #5048]
    3bb8:	f909e2b6 	str	x22, [x21, #5056]
    3bbc:	f909eab4 	str	x20, [x21, #5072]
    3bc0:	f90a02a1 	str	x1, [x21, #5120]
    3bc4:	97fffb2f 	bl	2880 <mmap@plt>
    3bc8:	aa0003e1 	mov	x1, x0
    3bcc:	b100041f 	cmn	x0, #0x1
    3bd0:	54000300 	b.eq	3c30 <fwp_heap_init+0x1c0>  // b.none
    3bd4:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    3bd8:	91256000 	add	x0, x0, #0x958
    3bdc:	f909fea1 	str	x1, [x21, #5112]
    3be0:	97fffb68 	bl	2980 <getenv@plt>
    3be4:	52800002 	mov	w2, #0x0                   	// #0
    3be8:	aa0003e1 	mov	x1, x0
    3bec:	b40000e0 	cbz	x0, 3c08 <fwp_heap_init+0x198>
    3bf0:	39400000 	ldrb	w0, [x0]
    3bf4:	340000a0 	cbz	w0, 3c08 <fwp_heap_init+0x198>
    3bf8:	7100c000 	subs	w0, w0, #0x30
    3bfc:	54000120 	b.eq	3c20 <fwp_heap_init+0x1b0>  // b.none
    3c00:	7100001f 	cmp	w0, #0x0
    3c04:	1a9f07e2 	cset	w2, ne	// ne = any
    3c08:	91154273 	add	x19, x19, #0x550
    3c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3c10:	b913aa62 	str	w2, [x19, #5032]
    3c14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3c1c:	d65f03c0 	ret
    3c20:	39400420 	ldrb	w0, [x1, #1]
    3c24:	7100001f 	cmp	w0, #0x0
    3c28:	1a9f07e2 	cset	w2, ne	// ne = any
    3c2c:	17fffff7 	b	3c08 <fwp_heap_init+0x198>
    3c30:	97fffce0 	bl	2fb0 <fwp_heap_oom>

0000000000003c34 <fwp_wake_io>:
    3c34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3c38:	91010122 	add	x2, x9, #0x40
    3c3c:	f9400001 	ldr	x1, [x0]
    3c40:	5280000a 	mov	w10, #0x0                   	// #0
    3c44:	f9401446 	ldr	x6, [x2, #40]
    3c48:	52800008 	mov	w8, #0x0                   	// #0
    3c4c:	4f000400 	movi	v0.4s, #0x0
    3c50:	52800027 	mov	w7, #0x1                   	// #1
    3c54:	aa0103e2 	mov	x2, x1
    3c58:	b4000321 	cbz	x1, 3cbc <fwp_wake_io+0x88>
    3c5c:	f9408c25 	ldr	x5, [x1, #280]
    3c60:	39015c27 	strb	w7, [x1, #87]
    3c64:	b4000165 	cbz	x5, 3c90 <fwp_wake_io+0x5c>
    3c68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3c6c:	b4000364 	cbz	x4, 3cd8 <fwp_wake_io+0xa4>
    3c70:	f9009483 	str	x3, [x4, #296]
    3c74:	f9409423 	ldr	x3, [x1, #296]
    3c78:	b4000043 	cbz	x3, 3c80 <fwp_wake_io+0x4c>
    3c7c:	f9009064 	str	x4, [x3, #288]
    3c80:	91080023 	add	x3, x1, #0x200
    3c84:	f900943f 	str	xzr, [x1, #296]
    3c88:	3c918060 	stur	q0, [x3, #-232]
    3c8c:	f9400001 	ldr	x1, [x0]
    3c90:	f9402843 	ldr	x3, [x2, #80]
    3c94:	f2001c7f 	tst	x3, #0xff000000ff
    3c98:	54fffde1 	b.ne	3c54 <fwp_wake_io+0x20>  // b.any
    3c9c:	39015047 	strb	w7, [x2, #84]
    3ca0:	f900805f 	str	xzr, [x2, #256]
    3ca4:	b40001e6 	cbz	x6, 3ce0 <fwp_wake_io+0xac>
    3ca8:	f90080c2 	str	x2, [x6, #256]
    3cac:	aa0203e6 	mov	x6, x2
    3cb0:	52800028 	mov	w8, #0x1                   	// #1
    3cb4:	aa0103e2 	mov	x2, x1
    3cb8:	b5fffd21 	cbnz	x1, 3c5c <fwp_wake_io+0x28>
    3cbc:	3400006a 	cbz	w10, 3cc8 <fwp_wake_io+0x94>
    3cc0:	91010120 	add	x0, x9, #0x40
    3cc4:	f900180b 	str	x11, [x0, #48]
    3cc8:	34000068 	cbz	w8, 3cd4 <fwp_wake_io+0xa0>
    3ccc:	91010129 	add	x9, x9, #0x40
    3cd0:	f9001526 	str	x6, [x9, #40]
    3cd4:	d65f03c0 	ret
    3cd8:	f90000a3 	str	x3, [x5]
    3cdc:	17ffffe7 	b	3c78 <fwp_wake_io+0x44>
    3ce0:	aa0203eb 	mov	x11, x2
    3ce4:	5280002a 	mov	w10, #0x1                   	// #1
    3ce8:	17fffff1 	b	3cac <fwp_wake_io+0x78>
    3cec:	d503201f 	nop

0000000000003cf0 <fwp_tape_buffers_release>:
    3cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3cf4:	910003fd 	mov	x29, sp
    3cf8:	a90153f3 	stp	x19, x20, [sp, #16]
    3cfc:	aa0003f3 	mov	x19, x0
    3d00:	f9401400 	ldr	x0, [x0, #40]
    3d04:	b7f80760 	tbnz	x0, #63, 3df0 <fwp_tape_buffers_release+0x100>
    3d08:	f9401a61 	ldr	x1, [x19, #48]
    3d0c:	b7f80301 	tbnz	x1, #63, 3d6c <fwp_tape_buffers_release+0x7c>
    3d10:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    3d14:	eb02001f 	cmp	x0, x2
    3d18:	540002a8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d1c:	8b000400 	add	x0, x0, x0, lsl #1
    3d20:	d2a00102 	mov	x2, #0x80000               	// #524288
    3d24:	d37df000 	lsl	x0, x0, #3
    3d28:	cb000042 	sub	x2, x2, x0
    3d2c:	eb420c3f 	cmp	x1, x2, lsr #3
    3d30:	540001e8 	b.hi	3d6c <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d34:	8b010c14 	add	x20, x0, x1, lsl #3
    3d38:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    3d3c:	9125a000 	add	x0, x0, #0x968
    3d40:	97fffb10 	bl	2980 <getenv@plt>
    3d44:	b4000240 	cbz	x0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d48:	39400001 	ldrb	w1, [x0]
    3d4c:	7100c03f 	cmp	w1, #0x30
    3d50:	540001e1 	b.ne	3d8c <fwp_tape_buffers_release+0x9c>  // b.any
    3d54:	39400400 	ldrb	w0, [x0, #1]
    3d58:	350001a0 	cbnz	w0, 3d8c <fwp_tape_buffers_release+0x9c>
    3d5c:	aa1303e0 	mov	x0, x19
    3d60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3d64:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3d68:	17fffd46 	b	3280 <fwp_tape_buffers_dispose>
    3d6c:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    3d70:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3d74:	9125a000 	add	x0, x0, #0x968
    3d78:	97fffb02 	bl	2980 <getenv@plt>
    3d7c:	b4ffff00 	cbz	x0, 3d5c <fwp_tape_buffers_release+0x6c>
    3d80:	39400001 	ldrb	w1, [x0]
    3d84:	7100c03f 	cmp	w1, #0x30
    3d88:	54fffe60 	b.eq	3d54 <fwp_tape_buffers_release+0x64>  // b.none
    3d8c:	d1000681 	sub	x1, x20, #0x1
    3d90:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    3d94:	eb00003f 	cmp	x1, x0
    3d98:	54fffe28 	b.hi	3d5c <fwp_tape_buffers_release+0x6c>  // b.pmore
    3d9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3da0:	b00000f6 	adrp	x22, 20000 <__data_start>
    3da4:	910102d6 	add	x22, x22, #0x40
    3da8:	9100e2d5 	add	x21, x22, #0x38
    3dac:	aa1503e0 	mov	x0, x21
    3db0:	97fffd34 	bl	3280 <fwp_tape_buffers_dispose>
    3db4:	ad400a61 	ldp	q1, q2, [x19]
    3db8:	f9003ad4 	str	x20, [x22, #112]
    3dbc:	4f000400 	movi	v0.4s, #0x0
    3dc0:	ad000aa1 	stp	q1, q2, [x21]
    3dc4:	3dc00a61 	ldr	q1, [x19, #32]
    3dc8:	3d800aa1 	str	q1, [x21, #32]
    3dcc:	f9401a60 	ldr	x0, [x19, #48]
    3dd0:	f9001aa0 	str	x0, [x21, #48]
    3dd4:	f9001a7f 	str	xzr, [x19, #48]
    3dd8:	ad000260 	stp	q0, q0, [x19]
    3ddc:	3d800a60 	str	q0, [x19, #32]
    3de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3de4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3de8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3dec:	d65f03c0 	ret
    3df0:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    3df4:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3df8:	9125a000 	add	x0, x0, #0x968
    3dfc:	97fffae1 	bl	2980 <getenv@plt>
    3e00:	b5fffa40 	cbnz	x0, 3d48 <fwp_tape_buffers_release+0x58>
    3e04:	17ffffd6 	b	3d5c <fwp_tape_buffers_release+0x6c>
    3e08:	d503201f 	nop
    3e0c:	d503201f 	nop

0000000000003e10 <fwp_trap>:
    3e10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e14:	b00000e2 	adrp	x2, 20000 <__data_start>
    3e18:	d53bd041 	mrs	x1, tpidr_el0
    3e1c:	910003fd 	mov	x29, sp
    3e20:	f9402442 	ldr	x2, [x2, #72]
    3e24:	91400021 	add	x1, x1, #0x0, lsl #12
    3e28:	91004021 	add	x1, x1, #0x10
    3e2c:	a90153f3 	stp	x19, x20, [sp, #16]
    3e30:	aa0003f3 	mov	x19, x0
    3e34:	f9400034 	ldr	x20, [x1]
    3e38:	b4000062 	cbz	x2, 3e44 <fwp_trap+0x34>
    3e3c:	aa0203e0 	mov	x0, x2
    3e40:	97fffab8 	bl	2920 <fflush@plt>
    3e44:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    3e48:	f947ec00 	ldr	x0, [x0, #4056]
    3e4c:	f9400000 	ldr	x0, [x0]
    3e50:	97fffab4 	bl	2920 <fflush@plt>
    3e54:	aa1303e3 	mov	x3, x19
    3e58:	90000042 	adrp	x2, b000 <fwp_main_thread+0x1730>
    3e5c:	900000f3 	adrp	x19, 1f000 <fwp_fn_table+0xb38>
    3e60:	f947ea73 	ldr	x19, [x19, #4048]
    3e64:	91260042 	add	x2, x2, #0x980
    3e68:	52800041 	mov	w1, #0x2                   	// #2
    3e6c:	f9400260 	ldr	x0, [x19]
    3e70:	97fffa7c 	bl	2860 <__fprintf_chk@plt>
    3e74:	b40000b4 	cbz	x20, 3e88 <fwp_trap+0x78>
    3e78:	f9400260 	ldr	x0, [x19]
    3e7c:	97fffaa9 	bl	2920 <fflush@plt>
    3e80:	52800ca0 	mov	w0, #0x65                  	// #101
    3e84:	97fffab7 	bl	2960 <_Exit@plt>
    3e88:	52800ca0 	mov	w0, #0x65                  	// #101
    3e8c:	97fffa05 	bl	26a0 <exit@plt>

0000000000003e90 <fwp_rc_forget_slot.part.0>:
    3e90:	ca404401 	eor	x1, x0, x0, lsr #17
    3e94:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e98:	ca412421 	eor	x1, x1, x1, lsr #9
    3e9c:	910003fd 	mov	x29, sp
    3ea0:	92401c21 	and	x1, x1, #0xff
    3ea4:	f9000bf3 	str	x19, [sp, #16]
    3ea8:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    3eac:	91154262 	add	x2, x19, #0x550
    3eb0:	910a2423 	add	x3, x1, #0x289
    3eb4:	8b010c41 	add	x1, x2, x1, lsl #3
    3eb8:	8b030c43 	add	x3, x2, x3, lsl #3
    3ebc:	f94a2421 	ldr	x1, [x1, #5192]
    3ec0:	b50000a1 	cbnz	x1, 3ed4 <fwp_rc_forget_slot.part.0+0x44>
    3ec4:	14000012 	b	3f0c <fwp_rc_forget_slot.part.0+0x7c>
    3ec8:	91004023 	add	x3, x1, #0x10
    3ecc:	f9400821 	ldr	x1, [x1, #16]
    3ed0:	b40001e1 	cbz	x1, 3f0c <fwp_rc_forget_slot.part.0+0x7c>
    3ed4:	f9400022 	ldr	x2, [x1]
    3ed8:	eb02001f 	cmp	x0, x2
    3edc:	54ffff61 	b.ne	3ec8 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    3ee0:	f9400060 	ldr	x0, [x3]
    3ee4:	91154273 	add	x19, x19, #0x550
    3ee8:	f9400801 	ldr	x1, [x0, #16]
    3eec:	f9000061 	str	x1, [x3]
    3ef0:	97fffa70 	bl	28b0 <free@plt>
    3ef4:	f94e2660 	ldr	x0, [x19, #7240]
    3ef8:	d1000400 	sub	x0, x0, #0x1
    3efc:	f90e2660 	str	x0, [x19, #7240]
    3f00:	f9400bf3 	ldr	x19, [sp, #16]
    3f04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f08:	d65f03c0 	ret
    3f0c:	90000040 	adrp	x0, b000 <fwp_main_thread+0x1730>
    3f10:	91264000 	add	x0, x0, #0x990
    3f14:	97ffffbf 	bl	3e10 <fwp_trap>
    3f18:	d503201f 	nop
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_rc_prepare_chunk>:
    3f20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3f24:	910003fd 	mov	x29, sp
    3f28:	a9025bf5 	stp	x21, x22, [sp, #32]
    3f2c:	d0000176 	adrp	x22, 31000 <fwp_root_context+0xc90>
    3f30:	911542c2 	add	x2, x22, #0x550
    3f34:	b9401c03 	ldr	w3, [x0, #28]
    3f38:	aa0103f5 	mov	x21, x1
    3f3c:	a90153f3 	stp	x19, x20, [sp, #16]
    3f40:	aa0003f4 	mov	x20, x0
    3f44:	f94e2440 	ldr	x0, [x2, #7240]
    3f48:	b4000440 	cbz	x0, 3fd0 <fwp_rc_prepare_chunk+0xb0>
    3f4c:	d2800013 	mov	x19, #0x0                   	// #0
    3f50:	35000203 	cbnz	w3, 3f90 <fwp_rc_prepare_chunk+0x70>
    3f54:	b4000361 	cbz	x1, 3fc0 <fwp_rc_prepare_chunk+0xa0>
    3f58:	f9401280 	ldr	x0, [x20, #32]
    3f5c:	97fffa55 	bl	28b0 <free@plt>
    3f60:	aa1503e0 	mov	x0, x21
    3f64:	d2800021 	mov	x1, #0x1                   	// #1
    3f68:	97fffa1a 	bl	27d0 <calloc@plt>
    3f6c:	f9001280 	str	x0, [x20, #32]
    3f70:	b5000460 	cbnz	x0, 3ffc <fwp_rc_prepare_chunk+0xdc>
    3f74:	97fffc0f 	bl	2fb0 <fwp_heap_oom>
    3f78:	97ffffc6 	bl	3e90 <fwp_rc_forget_slot.part.0>
    3f7c:	91000673 	add	x19, x19, #0x1
    3f80:	b9401e83 	ldr	w3, [x20, #28]
    3f84:	eb13007f 	cmp	x3, x19
    3f88:	54000169 	b.ls	3fb4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    3f8c:	d503201f 	nop
    3f90:	f9401283 	ldr	x3, [x20, #32]
    3f94:	8b130060 	add	x0, x3, x19
    3f98:	38736863 	ldrb	w3, [x3, x19]
    3f9c:	7103fc7f 	cmp	w3, #0xff
    3fa0:	54fffec0 	b.eq	3f78 <fwp_rc_prepare_chunk+0x58>  // b.none
    3fa4:	b9401e83 	ldr	w3, [x20, #28]
    3fa8:	91000673 	add	x19, x19, #0x1
    3fac:	eb13007f 	cmp	x3, x19
    3fb0:	54ffff08 	b.hi	3f90 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    3fb4:	eb0302bf 	cmp	x21, x3
    3fb8:	54000121 	b.ne	3fdc <fwp_rc_prepare_chunk+0xbc>  // b.any
    3fbc:	b5000335 	cbnz	x21, 4020 <fwp_rc_prepare_chunk+0x100>
    3fc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3fc4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3fc8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3fcc:	d65f03c0 	ret
    3fd0:	2a0303e3 	mov	w3, w3
    3fd4:	eb0302bf 	cmp	x21, x3
    3fd8:	54ffff20 	b.eq	3fbc <fwp_rc_prepare_chunk+0x9c>  // b.none
    3fdc:	911542c2 	add	x2, x22, #0x550
    3fe0:	f9401280 	ldr	x0, [x20, #32]
    3fe4:	f94e2841 	ldr	x1, [x2, #7248]
    3fe8:	cb030021 	sub	x1, x1, x3
    3fec:	f90e2841 	str	x1, [x2, #7248]
    3ff0:	97fffa30 	bl	28b0 <free@plt>
    3ff4:	b5fffb75 	cbnz	x21, 3f60 <fwp_rc_prepare_chunk+0x40>
    3ff8:	f900129f 	str	xzr, [x20, #32]
    3ffc:	911542d6 	add	x22, x22, #0x550
    4000:	f94e2ac0 	ldr	x0, [x22, #7248]
    4004:	b9001e95 	str	w21, [x20, #28]
    4008:	a94153f3 	ldp	x19, x20, [sp, #16]
    400c:	8b150000 	add	x0, x0, x21
    4010:	f90e2ac0 	str	x0, [x22, #7248]
    4014:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4018:	a8c37bfd 	ldp	x29, x30, [sp], #48
    401c:	d65f03c0 	ret
    4020:	f9401280 	ldr	x0, [x20, #32]
    4024:	aa1503e2 	mov	x2, x21
    4028:	a94153f3 	ldp	x19, x20, [sp, #16]
    402c:	52800001 	mov	w1, #0x0                   	// #0
    4030:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4034:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4038:	17fff9e2 	b	27c0 <memset@plt>
    403c:	d503201f 	nop

0000000000004040 <fwp_heap_refill>:
    4040:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4044:	910003fd 	mov	x29, sp
    4048:	a9025bf5 	stp	x21, x22, [sp, #32]
    404c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4050:	911542b5 	add	x21, x21, #0x550
    4054:	aa0003f6 	mov	x22, x0
    4058:	d2800020 	mov	x0, #0x1                   	// #1
    405c:	a90153f3 	stp	x19, x20, [sp, #16]
    4060:	a90363f7 	stp	x23, x24, [sp, #48]
    4064:	2a0103f7 	mov	w23, w1
    4068:	2a0203f8 	mov	w24, w2
    406c:	97fffc11 	bl	30b0 <fwp_heap_chunks>
    4070:	aa0003f3 	mov	x19, x0
    4074:	f949fea2 	ldr	x2, [x21, #5112]
    4078:	8b000800 	add	x0, x0, x0, lsl #2
    407c:	2a1703e1 	mov	w1, w23
    4080:	52800025 	mov	w5, #0x1                   	// #1
    4084:	d37df000 	lsl	x0, x0, #3
    4088:	910f0021 	add	x1, x1, #0x3c0
    408c:	8b000054 	add	x20, x2, x0
    4090:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4094:	52a00024 	mov	w4, #0x10000               	// #65536
    4098:	38206845 	strb	w5, [x2, x0]
    409c:	aa1403e0 	mov	x0, x20
    40a0:	39000698 	strb	w24, [x20, #1]
    40a4:	39000a97 	strb	w23, [x20, #2]
    40a8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    40ac:	b9000681 	str	w1, [x20, #4]
    40b0:	2a0103e5 	mov	w5, w1
    40b4:	8b0300a2 	add	x2, x5, x3
    40b8:	1ac10881 	udiv	w1, w4, w1
    40bc:	9ac50842 	udiv	x2, x2, x5
    40c0:	b9000a81 	str	w1, [x20, #8]
    40c4:	92404021 	and	x1, x1, #0x1ffff
    40c8:	b9001a82 	str	w2, [x20, #24]
    40cc:	97ffff95 	bl	3f20 <fwp_rc_prepare_chunk>
    40d0:	f949daa0 	ldr	x0, [x21, #5040]
    40d4:	29408a81 	ldp	w1, w2, [x20, #4]
    40d8:	8b134000 	add	x0, x0, x19, lsl #16
    40dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e0:	8b214003 	add	x3, x0, w1, uxtw
    40e4:	9ba20021 	umaddl	x1, w1, w2, x0
    40e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    40ec:	a90086c3 	stp	x3, x1, [x22, #8]
    40f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    40f8:	d65f03c0 	ret
    40fc:	d503201f 	nop

0000000000004100 <fwp_mem_free>:
    4100:	b40003c0 	cbz	x0, 4178 <fwp_mem_free+0x78>
    4104:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4108:	910003fd 	mov	x29, sp
    410c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4110:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4114:	911542a1 	add	x1, x21, #0x550
    4118:	a90153f3 	stp	x19, x20, [sp, #16]
    411c:	aa0003f3 	mov	x19, x0
    4120:	f949d823 	ldr	x3, [x1, #5040]
    4124:	f949ec22 	ldr	x2, [x1, #5080]
    4128:	cb030000 	sub	x0, x0, x3
    412c:	eb02401f 	cmp	x0, x2, lsl #16
    4130:	540001c2 	b.cs	4168 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4134:	d350fc16 	lsr	x22, x0, #16
    4138:	a90363f7 	stp	x23, x24, [sp, #48]
    413c:	f949fc22 	ldr	x2, [x1, #5112]
    4140:	8b160ad4 	add	x20, x22, x22, lsl #2
    4144:	d37df294 	lsl	x20, x20, #3
    4148:	ab140057 	adds	x23, x2, x20
    414c:	540000c0 	b.eq	4164 <fwp_mem_free+0x64>  // b.none
    4150:	38746842 	ldrb	w2, [x2, x20]
    4154:	7100045f 	cmp	w2, #0x1
    4158:	54000120 	b.eq	417c <fwp_mem_free+0x7c>  // b.none
    415c:	7100085f 	cmp	w2, #0x2
    4160:	540005e0 	b.eq	421c <fwp_mem_free+0x11c>  // b.none
    4164:	a94363f7 	ldp	x23, x24, [sp, #48]
    4168:	a94153f3 	ldp	x19, x20, [sp, #16]
    416c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4170:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4174:	d65f03c0 	ret
    4178:	d65f03c0 	ret
    417c:	f94012f8 	ldr	x24, [x23, #32]
    4180:	b94006e1 	ldr	w1, [x23, #4]
    4184:	f90023f9 	str	x25, [sp, #64]
    4188:	2a0103e2 	mov	w2, w1
    418c:	394006f9 	ldrb	w25, [x23, #1]
    4190:	39400af4 	ldrb	w20, [x23, #2]
    4194:	b4000158 	cbz	x24, 41bc <fwp_mem_free+0xbc>
    4198:	92403e76 	and	x22, x19, #0xffff
    419c:	9ac20ad6 	udiv	x22, x22, x2
    41a0:	38766b01 	ldrb	w1, [x24, x22]
    41a4:	8b160300 	add	x0, x24, x22
    41a8:	7103fc3f 	cmp	w1, #0xff
    41ac:	54000980 	b.eq	42dc <fwp_mem_free+0x1dc>  // b.none
    41b0:	38366b1f 	strb	wzr, [x24, x22]
    41b4:	b94006e1 	ldr	w1, [x23, #4]
    41b8:	2a0103e2 	mov	w2, w1
    41bc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    41c0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    41c4:	cb390000 	sub	x0, x0, w25, uxtb
    41c8:	8b340074 	add	x20, x3, w20, uxtb
    41cc:	911542b5 	add	x21, x21, #0x550
    41d0:	1e630021 	ucvtf	d1, w1
    41d4:	d37ae400 	lsl	x0, x0, #6
    41d8:	8b140c14 	add	x20, x0, x20, lsl #3
    41dc:	a94363f7 	ldp	x23, x24, [sp, #48]
    41e0:	f8746aa0 	ldr	x0, [x21, x20]
    41e4:	f94023f9 	ldr	x25, [sp, #64]
    41e8:	aa2003e0 	mvn	x0, x0
    41ec:	fd4a22a0 	ldr	d0, [x21, #5184]
    41f0:	f9000260 	str	x0, [x19]
    41f4:	f8346ab3 	str	x19, [x21, x20]
    41f8:	f94a12a0 	ldr	x0, [x21, #5152]
    41fc:	1e612800 	fadd	d0, d0, d1
    4200:	a94153f3 	ldp	x19, x20, [sp, #16]
    4204:	cb020000 	sub	x0, x0, x2
    4208:	f90a12a0 	str	x0, [x21, #5152]
    420c:	fd0a22a0 	str	d0, [x21, #5184]
    4210:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4214:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4218:	d65f03c0 	ret
    421c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4220:	8b000063 	add	x3, x3, x0
    4224:	eb03027f 	cmp	x19, x3
    4228:	54fff9e1 	b.ne	4164 <fwp_mem_free+0x64>  // b.any
    422c:	fd400ae1 	ldr	d1, [x23, #16]
    4230:	fd4a2020 	ldr	d0, [x1, #5184]
    4234:	f9400ae0 	ldr	x0, [x23, #16]
    4238:	7e61d821 	ucvtf	d1, d1
    423c:	f94a1022 	ldr	x2, [x1, #5152]
    4240:	f94012f3 	ldr	x19, [x23, #32]
    4244:	1e612800 	fadd	d0, d0, d1
    4248:	cb000042 	sub	x2, x2, x0
    424c:	f90a1022 	str	x2, [x1, #5152]
    4250:	fd0a2020 	str	d0, [x1, #5184]
    4254:	b40000b3 	cbz	x19, 4268 <fwp_mem_free+0x168>
    4258:	39400260 	ldrb	w0, [x19]
    425c:	7103fc1f 	cmp	w0, #0xff
    4260:	54000380 	b.eq	42d0 <fwp_mem_free+0x1d0>  // b.none
    4264:	3900027f 	strb	wzr, [x19]
    4268:	b9400ee2 	ldr	w2, [x23, #12]
    426c:	b4000142 	cbz	x2, 4294 <fwp_mem_free+0x194>
    4270:	911542a1 	add	x1, x21, #0x550
    4274:	8b160040 	add	x0, x2, x22
    4278:	8b000800 	add	x0, x0, x0, lsl #2
    427c:	f949fc21 	ldr	x1, [x1, #5112]
    4280:	8b140034 	add	x20, x1, x20
    4284:	8b000c20 	add	x0, x1, x0, lsl #3
    4288:	3802869f 	strb	wzr, [x20], #40
    428c:	eb00029f 	cmp	x20, x0
    4290:	54ffffc1 	b.ne	4288 <fwp_mem_free+0x188>  // b.any
    4294:	911542a0 	add	x0, x21, #0x550
    4298:	f94a1801 	ldr	x1, [x0, #5168]
    429c:	f949f803 	ldr	x3, [x0, #5104]
    42a0:	8b020021 	add	x1, x1, x2
    42a4:	f90a1801 	str	x1, [x0, #5168]
    42a8:	eb16007f 	cmp	x3, x22
    42ac:	54000049 	b.ls	42b4 <fwp_mem_free+0x1b4>  // b.plast
    42b0:	f909f816 	str	x22, [x0, #5104]
    42b4:	911542b5 	add	x21, x21, #0x550
    42b8:	f949f6a0 	ldr	x0, [x21, #5096]
    42bc:	eb16001f 	cmp	x0, x22
    42c0:	54fff529 	b.ls	4164 <fwp_mem_free+0x64>  // b.plast
    42c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    42c8:	f909f6b6 	str	x22, [x21, #5096]
    42cc:	17ffffa7 	b	4168 <fwp_mem_free+0x68>
    42d0:	aa1303e0 	mov	x0, x19
    42d4:	97fffeef 	bl	3e90 <fwp_rc_forget_slot.part.0>
    42d8:	17ffffe3 	b	4264 <fwp_mem_free+0x164>
    42dc:	97fffeed 	bl	3e90 <fwp_rc_forget_slot.part.0>
    42e0:	17ffffb4 	b	41b0 <fwp_mem_free+0xb0>

00000000000042e4 <fwp_rc_wide_dup>:
    42e4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    42e8:	910003fd 	mov	x29, sp
    42ec:	a90153f3 	stp	x19, x20, [sp, #16]
    42f0:	aa0003f3 	mov	x19, x0
    42f4:	ca404400 	eor	x0, x0, x0, lsr #17
    42f8:	f90013f5 	str	x21, [sp, #32]
    42fc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    4300:	ca402400 	eor	x0, x0, x0, lsr #9
    4304:	911542a2 	add	x2, x21, #0x550
    4308:	92401c00 	and	x0, x0, #0xff
    430c:	910a2403 	add	x3, x0, #0x289
    4310:	8b000c40 	add	x0, x2, x0, lsl #3
    4314:	8b030c54 	add	x20, x2, x3, lsl #3
    4318:	f94a2401 	ldr	x1, [x0, #5192]
    431c:	b50000a1 	cbnz	x1, 4330 <fwp_rc_wide_dup+0x4c>
    4320:	14000033 	b	43ec <fwp_rc_wide_dup+0x108>
    4324:	91004034 	add	x20, x1, #0x10
    4328:	f9400821 	ldr	x1, [x1, #16]
    432c:	b4000241 	cbz	x1, 4374 <fwp_rc_wide_dup+0x90>
    4330:	f9400022 	ldr	x2, [x1]
    4334:	eb02027f 	cmp	x19, x2
    4338:	54ffff61 	b.ne	4324 <fwp_rc_wide_dup+0x40>  // b.any
    433c:	f9400281 	ldr	x1, [x20]
    4340:	39400260 	ldrb	w0, [x19]
    4344:	7103f81f 	cmp	w0, #0xfe
    4348:	54000220 	b.eq	438c <fwp_rc_wide_dup+0xa8>  // b.none
    434c:	b40001a1 	cbz	x1, 4380 <fwp_rc_wide_dup+0x9c>
    4350:	f9400420 	ldr	x0, [x1, #8]
    4354:	b100041f 	cmn	x0, #0x1
    4358:	54000440 	b.eq	43e0 <fwp_rc_wide_dup+0xfc>  // b.none
    435c:	91000400 	add	x0, x0, #0x1
    4360:	f9000420 	str	x0, [x1, #8]
    4364:	a94153f3 	ldp	x19, x20, [sp, #16]
    4368:	f94013f5 	ldr	x21, [sp, #32]
    436c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4370:	d65f03c0 	ret
    4374:	39400260 	ldrb	w0, [x19]
    4378:	7103f81f 	cmp	w0, #0xfe
    437c:	54000100 	b.eq	439c <fwp_rc_wide_dup+0xb8>  // b.none
    4380:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    4384:	91264000 	add	x0, x0, #0x990
    4388:	97fffea2 	bl	3e10 <fwp_trap>
    438c:	b4000081 	cbz	x1, 439c <fwp_rc_wide_dup+0xb8>
    4390:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    4394:	9126e000 	add	x0, x0, #0x9b8
    4398:	97fffe9e 	bl	3e10 <fwp_trap>
    439c:	d2800300 	mov	x0, #0x18                  	// #24
    43a0:	97fff8fc 	bl	2790 <malloc@plt>
    43a4:	b4000280 	cbz	x0, 43f4 <fwp_rc_wide_dup+0x110>
    43a8:	d2801fe1 	mov	x1, #0xff                  	// #255
    43ac:	a9000413 	stp	x19, x1, [x0]
    43b0:	911542b5 	add	x21, x21, #0x550
    43b4:	f900081f 	str	xzr, [x0, #16]
    43b8:	12800001 	mov	w1, #0xffffffff            	// #-1
    43bc:	f9000280 	str	x0, [x20]
    43c0:	39000261 	strb	w1, [x19]
    43c4:	f94e26a0 	ldr	x0, [x21, #7240]
    43c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    43cc:	91000400 	add	x0, x0, #0x1
    43d0:	f90e26a0 	str	x0, [x21, #7240]
    43d4:	f94013f5 	ldr	x21, [sp, #32]
    43d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43dc:	d65f03c0 	ret
    43e0:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    43e4:	91278000 	add	x0, x0, #0x9e0
    43e8:	97fffe8a 	bl	3e10 <fwp_trap>
    43ec:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    43f0:	17ffffd4 	b	4340 <fwp_rc_wide_dup+0x5c>
    43f4:	97fffaef 	bl	2fb0 <fwp_heap_oom>
    43f8:	d503201f 	nop
    43fc:	d503201f 	nop

0000000000004400 <fwp_closure_drop_push>:
    4400:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4404:	910003fd 	mov	x29, sp
    4408:	a90153f3 	stp	x19, x20, [sp, #16]
    440c:	aa0003f3 	mov	x19, x0
    4410:	a9408014 	ldp	x20, x0, [x0, #8]
    4414:	a9025bf5 	stp	x21, x22, [sp, #32]
    4418:	aa0103f5 	mov	x21, x1
    441c:	a90363f7 	stp	x23, x24, [sp, #48]
    4420:	eb00029f 	cmp	x20, x0
    4424:	54000160 	b.eq	4450 <fwp_closure_drop_push+0x50>  // b.none
    4428:	f9400276 	ldr	x22, [x19]
    442c:	d37df297 	lsl	x23, x20, #3
    4430:	91000694 	add	x20, x20, #0x1
    4434:	f9000674 	str	x20, [x19, #8]
    4438:	a94153f3 	ldp	x19, x20, [sp, #16]
    443c:	f8376ad5 	str	x21, [x22, x23]
    4440:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4444:	a94363f7 	ldp	x23, x24, [sp, #48]
    4448:	a8c57bfd 	ldp	x29, x30, [sp], #80
    444c:	d65f03c0 	ret
    4450:	a9046bf9 	stp	x25, x26, [sp, #64]
    4454:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4458:	eb00029f 	cmp	x20, x0
    445c:	540003e8 	b.hi	44d8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4460:	d37cee99 	lsl	x25, x20, #4
    4464:	d37ffa9a 	lsl	x26, x20, #1
    4468:	aa1903e0 	mov	x0, x25
    446c:	97fff8c9 	bl	2790 <malloc@plt>
    4470:	aa0003f6 	mov	x22, x0
    4474:	b4000380 	cbz	x0, 44e4 <fwp_closure_drop_push+0xe4>
    4478:	aa1303f8 	mov	x24, x19
    447c:	aa1903e3 	mov	x3, x25
    4480:	d37df297 	lsl	x23, x20, #3
    4484:	aa1703e2 	mov	x2, x23
    4488:	f8418719 	ldr	x25, [x24], #24
    448c:	aa1903e1 	mov	x1, x25
    4490:	97fff8ac 	bl	2740 <__memcpy_chk@plt>
    4494:	eb18033f 	cmp	x25, x24
    4498:	540000a0 	b.eq	44ac <fwp_closure_drop_push+0xac>  // b.none
    449c:	aa1903e0 	mov	x0, x25
    44a0:	97fff904 	bl	28b0 <free@plt>
    44a4:	f9400674 	ldr	x20, [x19, #8]
    44a8:	d37df297 	lsl	x23, x20, #3
    44ac:	91000694 	add	x20, x20, #0x1
    44b0:	f9000276 	str	x22, [x19]
    44b4:	f9000a7a 	str	x26, [x19, #16]
    44b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    44bc:	f9000674 	str	x20, [x19, #8]
    44c0:	f8376ad5 	str	x21, [x22, x23]
    44c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    44c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44cc:	a94363f7 	ldp	x23, x24, [sp, #48]
    44d0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44d4:	d65f03c0 	ret
    44d8:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    44dc:	91280000 	add	x0, x0, #0xa00
    44e0:	97fffe4c 	bl	3e10 <fwp_trap>
    44e4:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    44e8:	f947e863 	ldr	x3, [x3, #4048]
    44ec:	d2800262 	mov	x2, #0x13                  	// #19
    44f0:	d2800021 	mov	x1, #0x1                   	// #1
    44f4:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    44f8:	91216000 	add	x0, x0, #0x858
    44fc:	f9400063 	ldr	x3, [x3]
    4500:	97fff8fc 	bl	28f0 <fwrite@plt>
    4504:	d2800000 	mov	x0, #0x0                   	// #0
    4508:	97fff906 	bl	2920 <fflush@plt>
    450c:	52800cc0 	mov	w0, #0x66                  	// #102
    4510:	97fff914 	bl	2960 <_Exit@plt>

0000000000004514 <fwp_closure_drop.part.0>:
    4514:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4518:	90000041 	adrp	x1, c000 <_IO_stdin_used+0x7b0>
    451c:	910003fd 	mov	x29, sp
    4520:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4524:	f947f463 	ldr	x3, [x3, #4072]
    4528:	a90153f3 	stp	x19, x20, [sp, #16]
    452c:	d10883ff 	sub	sp, sp, #0x220
    4530:	910003e2 	mov	x2, sp
    4534:	d53bd053 	mrs	x19, tpidr_el0
    4538:	910063f4 	add	x20, sp, #0x18
    453c:	3dc14020 	ldr	q0, [x1, #1280]
    4540:	91400264 	add	x4, x19, #0x0, lsl #12
    4544:	91004084 	add	x4, x4, #0x10
    4548:	aa0003e1 	mov	x1, x0
    454c:	aa0203e0 	mov	x0, x2
    4550:	f9400062 	ldr	x2, [x3]
    4554:	f9010fe2 	str	x2, [sp, #536]
    4558:	d2800002 	mov	x2, #0x0                   	// #0
    455c:	f90003f4 	str	x20, [sp]
    4560:	f9000080 	str	x0, [x4]
    4564:	3c8083e0 	stur	q0, [sp, #8]
    4568:	97ffffa6 	bl	4400 <fwp_closure_drop_push>
    456c:	f94007e0 	ldr	x0, [sp, #8]
    4570:	b40002e0 	cbz	x0, 45cc <fwp_closure_drop.part.0+0xb8>
    4574:	f90123f5 	str	x21, [sp, #576]
    4578:	900000f5 	adrp	x21, 20000 <__data_start>
    457c:	910102b5 	add	x21, x21, #0x40
    4580:	14000006 	b	4598 <fwp_closure_drop.part.0+0x84>
    4584:	f9400422 	ldr	x2, [x1, #8]
    4588:	52800001 	mov	w1, #0x0                   	// #0
    458c:	d63f0040 	blr	x2
    4590:	f94007e0 	ldr	x0, [sp, #8]
    4594:	b40001a0 	cbz	x0, 45c8 <fwp_closure_drop.part.0+0xb4>
    4598:	f94003e1 	ldr	x1, [sp]
    459c:	d1000400 	sub	x0, x0, #0x1
    45a0:	f90007e0 	str	x0, [sp, #8]
    45a4:	f9403ea2 	ldr	x2, [x21, #120]
    45a8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    45ac:	b9400001 	ldr	w1, [x0]
    45b0:	8b011441 	add	x1, x2, x1, lsl #5
    45b4:	f9400c21 	ldr	x1, [x1, #24]
    45b8:	b5fffe61 	cbnz	x1, 4584 <fwp_closure_drop.part.0+0x70>
    45bc:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    45c0:	91288000 	add	x0, x0, #0xa20
    45c4:	97fffe13 	bl	3e10 <fwp_trap>
    45c8:	f94123f5 	ldr	x21, [sp, #576]
    45cc:	91400273 	add	x19, x19, #0x0, lsl #12
    45d0:	91004273 	add	x19, x19, #0x10
    45d4:	f94003e0 	ldr	x0, [sp]
    45d8:	f900027f 	str	xzr, [x19]
    45dc:	eb14001f 	cmp	x0, x20
    45e0:	54000040 	b.eq	45e8 <fwp_closure_drop.part.0+0xd4>  // b.none
    45e4:	97fff8b3 	bl	28b0 <free@plt>
    45e8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    45ec:	f947f400 	ldr	x0, [x0, #4072]
    45f0:	f9410fe2 	ldr	x2, [sp, #536]
    45f4:	f9400001 	ldr	x1, [x0]
    45f8:	eb010042 	subs	x2, x2, x1
    45fc:	d2800001 	mov	x1, #0x0                   	// #0
    4600:	540000a1 	b.ne	4614 <fwp_closure_drop.part.0+0x100>  // b.any
    4604:	910883ff 	add	sp, sp, #0x220
    4608:	a94153f3 	ldp	x19, x20, [sp, #16]
    460c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4610:	d65f03c0 	ret
    4614:	f90123f5 	str	x21, [sp, #576]
    4618:	97fff876 	bl	27f0 <__stack_chk_fail@plt>
    461c:	d503201f 	nop

0000000000004620 <fwp_tape_of>:
    4620:	aa0003e1 	mov	x1, x0
    4624:	92403c00 	and	x0, x0, #0xffff
    4628:	b40000e0 	cbz	x0, 4644 <fwp_tape_of+0x24>
    462c:	d1000402 	sub	x2, x0, #0x1
    4630:	900000e3 	adrp	x3, 20000 <__data_start>
    4634:	91010060 	add	x0, x3, #0x40
    4638:	f9404000 	ldr	x0, [x0, #128]
    463c:	eb02001f 	cmp	x0, x2
    4640:	540000cc 	b.gt	4658 <fwp_tape_of+0x38>
    4644:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4648:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    464c:	91294000 	add	x0, x0, #0xa50
    4650:	910003fd 	mov	x29, sp
    4654:	97fffdef 	bl	3e10 <fwp_trap>
    4658:	8b020440 	add	x0, x2, x2, lsl #1
    465c:	f9402063 	ldr	x3, [x3, #64]
    4660:	8b000842 	add	x2, x2, x0, lsl #2
    4664:	d37df042 	lsl	x2, x2, #3
    4668:	8b020060 	add	x0, x3, x2
    466c:	b9400404 	ldr	w4, [x0, #4]
    4670:	34fffea4 	cbz	w4, 4644 <fwp_tape_of+0x24>
    4674:	b8626862 	ldr	w2, [x3, x2]
    4678:	9350fc21 	asr	x1, x1, #16
    467c:	6b01005f 	cmp	w2, w1
    4680:	54fffe21 	b.ne	4644 <fwp_tape_of+0x24>  // b.any
    4684:	d65f03c0 	ret
    4688:	d503201f 	nop
    468c:	d503201f 	nop

0000000000004690 <fwp_now_ns>:
    4690:	d100c3ff 	sub	sp, sp, #0x30
    4694:	52800020 	mov	w0, #0x1                   	// #1
    4698:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    469c:	f947f442 	ldr	x2, [x2, #4072]
    46a0:	910023e1 	add	x1, sp, #0x8
    46a4:	a9027bfd 	stp	x29, x30, [sp, #32]
    46a8:	910083fd 	add	x29, sp, #0x20
    46ac:	f9400043 	ldr	x3, [x2]
    46b0:	f9000fe3 	str	x3, [sp, #24]
    46b4:	d2800003 	mov	x3, #0x0                   	// #0
    46b8:	97fff81a 	bl	2720 <clock_gettime@plt>
    46bc:	350002c0 	cbnz	w0, 4714 <fwp_now_ns+0x84>
    46c0:	a9408be1 	ldp	x1, x2, [sp, #8]
    46c4:	d2994003 	mov	x3, #0xca00                	// #51712
    46c8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    46cc:	9b037c20 	mul	x0, x1, x3
    46d0:	9b437c21 	smulh	x1, x1, x3
    46d4:	ab020000 	adds	x0, x0, x2
    46d8:	937ffc42 	asr	x2, x2, #63
    46dc:	9a020021 	adc	x1, x1, x2
    46e0:	f100001f 	cmp	x0, #0x0
    46e4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    46e8:	b50001c1 	cbnz	x1, 4720 <fwp_now_ns+0x90>
    46ec:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    46f0:	f947f421 	ldr	x1, [x1, #4072]
    46f4:	f9400fe3 	ldr	x3, [sp, #24]
    46f8:	f9400022 	ldr	x2, [x1]
    46fc:	eb020063 	subs	x3, x3, x2
    4700:	d2800002 	mov	x2, #0x0                   	// #0
    4704:	54000141 	b.ne	472c <fwp_now_ns+0x9c>  // b.any
    4708:	a9427bfd 	ldp	x29, x30, [sp, #32]
    470c:	9100c3ff 	add	sp, sp, #0x30
    4710:	d65f03c0 	ret
    4714:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    4718:	912a8000 	add	x0, x0, #0xaa0
    471c:	97fffdbd 	bl	3e10 <fwp_trap>
    4720:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    4724:	912b0000 	add	x0, x0, #0xac0
    4728:	97fffdba 	bl	3e10 <fwp_trap>
    472c:	97fff831 	bl	27f0 <__stack_chk_fail@plt>

0000000000004730 <fwp_poll_events>:
    4730:	d10103ff 	sub	sp, sp, #0x40
    4734:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4738:	f947f400 	ldr	x0, [x0, #4072]
    473c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4740:	910083fd 	add	x29, sp, #0x20
    4744:	f9001bf3 	str	x19, [sp, #48]
    4748:	900000f3 	adrp	x19, 20000 <__data_start>
    474c:	f9400001 	ldr	x1, [x0]
    4750:	f9000fe1 	str	x1, [sp, #24]
    4754:	d2800001 	mov	x1, #0x0                   	// #0
    4758:	97ffffce 	bl	4690 <fwp_now_ns>
    475c:	91010261 	add	x1, x19, #0x40
    4760:	f9404421 	ldr	x1, [x1, #136]
    4764:	b4000e01 	cbz	x1, 4924 <fwp_poll_events+0x1f4>
    4768:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    476c:	14000005 	b	4780 <fwp_poll_events+0x50>
    4770:	f9408821 	ldr	x1, [x1, #272]
    4774:	eb03005f 	cmp	x2, x3
    4778:	9a83d042 	csel	x2, x2, x3, le
    477c:	b40000c1 	cbz	x1, 4794 <fwp_poll_events+0x64>
    4780:	f9403423 	ldr	x3, [x1, #104]
    4784:	b6ffff62 	tbz	x2, #63, 4770 <fwp_poll_events+0x40>
    4788:	f9408821 	ldr	x1, [x1, #272]
    478c:	aa0303e2 	mov	x2, x3
    4790:	b5ffff81 	cbnz	x1, 4780 <fwp_poll_events+0x50>
    4794:	b7f80c82 	tbnz	x2, #63, 4924 <fwp_poll_events+0x1f4>
    4798:	cb000042 	sub	x2, x2, x0
    479c:	f100005f 	cmp	x2, #0x0
    47a0:	540003ad 	b.le	4814 <fwp_poll_events+0xe4>
    47a4:	d2869b60 	mov	x0, #0x34db                	// #13531
    47a8:	d2884804 	mov	x4, #0x4240                	// #16960
    47ac:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    47b0:	f2a001e4 	movk	x4, #0xf, lsl #16
    47b4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    47b8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    47bc:	f2e86360 	movk	x0, #0x431b, lsl #48
    47c0:	9b407c40 	smulh	x0, x2, x0
    47c4:	9352fc00 	asr	x0, x0, #18
    47c8:	cb82fc00 	sub	x0, x0, x2, asr #63
    47cc:	9b048802 	msub	x2, x0, x4, x2
    47d0:	f100005f 	cmp	x2, #0x0
    47d4:	9a800400 	cinc	x0, x0, ne	// ne = any
    47d8:	eb01001f 	cmp	x0, x1
    47dc:	5400098c 	b.gt	490c <fwp_poll_events+0x1dc>
    47e0:	340001a0 	cbz	w0, 4814 <fwp_poll_events+0xe4>
    47e4:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    47e8:	52807d05 	mov	w5, #0x3e8                 	// #1000
    47ec:	72a20c41 	movk	w1, #0x1062, lsl #16
    47f0:	9ba17c01 	umull	x1, w0, w1
    47f4:	d366fc23 	lsr	x3, x1, #38
    47f8:	aa0303e2 	mov	x2, x3
    47fc:	1b058063 	msub	w3, w3, w5, w0
    4800:	9b247c63 	smull	x3, w3, w4
    4804:	910023e0 	add	x0, sp, #0x8
    4808:	d2800001 	mov	x1, #0x0                   	// #0
    480c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4810:	97fff82c 	bl	28c0 <nanosleep@plt>
    4814:	97ffff9f 	bl	4690 <fwp_now_ns>
    4818:	91010268 	add	x8, x19, #0x40
    481c:	aa0003e7 	mov	x7, x0
    4820:	4f000400 	movi	v0.4s, #0x0
    4824:	52800029 	mov	w9, #0x1                   	// #1
    4828:	f9404506 	ldr	x6, [x8, #136]
    482c:	d503201f 	nop
    4830:	b40003e6 	cbz	x6, 48ac <fwp_poll_events+0x17c>
    4834:	f94034c1 	ldr	x1, [x6, #104]
    4838:	aa0603e5 	mov	x5, x6
    483c:	f94088c6 	ldr	x6, [x6, #272]
    4840:	eb07003f 	cmp	x1, x7
    4844:	54ffff6c 	b.gt	4830 <fwp_poll_events+0x100>
    4848:	394154a0 	ldrb	w0, [x5, #85]
    484c:	36000120 	tbz	w0, #0, 4870 <fwp_poll_events+0x140>
    4850:	f94084a0 	ldr	x0, [x5, #264]
    4854:	b4000560 	cbz	x0, 4900 <fwp_poll_events+0x1d0>
    4858:	f9008806 	str	x6, [x0, #272]
    485c:	b4000046 	cbz	x6, 4864 <fwp_poll_events+0x134>
    4860:	f90084c0 	str	x0, [x6, #264]
    4864:	910800a0 	add	x0, x5, #0x200
    4868:	390154bf 	strb	wzr, [x5, #85]
    486c:	3c908000 	stur	q0, [x0, #-248]
    4870:	f94030a0 	ldr	x0, [x5, #96]
    4874:	390158a9 	strb	w9, [x5, #86]
    4878:	f100001f 	cmp	x0, #0x0
    487c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4880:	540002cd 	b.le	48d8 <fwp_poll_events+0x1a8>
    4884:	f94028a0 	ldr	x0, [x5, #80]
    4888:	f2001c1f 	tst	x0, #0xff000000ff
    488c:	54fffd21 	b.ne	4830 <fwp_poll_events+0x100>  // b.any
    4890:	f9401500 	ldr	x0, [x8, #40]
    4894:	390150a9 	strb	w9, [x5, #84]
    4898:	f90080bf 	str	xzr, [x5, #256]
    489c:	b40002c0 	cbz	x0, 48f4 <fwp_poll_events+0x1c4>
    48a0:	f9001505 	str	x5, [x8, #40]
    48a4:	f9008005 	str	x5, [x0, #256]
    48a8:	b5fffc66 	cbnz	x6, 4834 <fwp_poll_events+0x104>
    48ac:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    48b0:	f947f400 	ldr	x0, [x0, #4072]
    48b4:	f9400fe2 	ldr	x2, [sp, #24]
    48b8:	f9400001 	ldr	x1, [x0]
    48bc:	eb010042 	subs	x2, x2, x1
    48c0:	d2800001 	mov	x1, #0x0                   	// #0
    48c4:	540002e1 	b.ne	4920 <fwp_poll_events+0x1f0>  // b.any
    48c8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    48cc:	f9401bf3 	ldr	x19, [sp, #48]
    48d0:	910103ff 	add	sp, sp, #0x40
    48d4:	d65f03c0 	ret
    48d8:	394144a0 	ldrb	w0, [x5, #81]
    48dc:	3707fd40 	tbnz	w0, #0, 4884 <fwp_poll_events+0x154>
    48e0:	394140a0 	ldrb	w0, [x5, #80]
    48e4:	3707fd00 	tbnz	w0, #0, 4884 <fwp_poll_events+0x154>
    48e8:	aa0503e0 	mov	x0, x5
    48ec:	97fffac1 	bl	33f0 <fwp_cancel_tree.part.0>
    48f0:	17ffffe5 	b	4884 <fwp_poll_events+0x154>
    48f4:	f9001505 	str	x5, [x8, #40]
    48f8:	f9001905 	str	x5, [x8, #48]
    48fc:	17ffffeb 	b	48a8 <fwp_poll_events+0x178>
    4900:	91010261 	add	x1, x19, #0x40
    4904:	f9004426 	str	x6, [x1, #136]
    4908:	17ffffd5 	b	485c <fwp_poll_events+0x12c>
    490c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4910:	d2989362 	mov	x2, #0xc49b                	// #50331
    4914:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4918:	f2a00402 	movk	x2, #0x20, lsl #16
    491c:	17ffffba 	b	4804 <fwp_poll_events+0xd4>
    4920:	97fff7b4 	bl	27f0 <__stack_chk_fail@plt>
    4924:	97fff993 	bl	2f70 <fwp_flush>
    4928:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    492c:	f947e863 	ldr	x3, [x3, #4048]
    4930:	d2800562 	mov	x2, #0x2b                  	// #43
    4934:	d2800021 	mov	x1, #0x1                   	// #1
    4938:	f0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    493c:	912ba000 	add	x0, x0, #0xae8
    4940:	f9400063 	ldr	x3, [x3]
    4944:	97fff7eb 	bl	28f0 <fwrite@plt>
    4948:	52800ca0 	mov	w0, #0x65                  	// #101
    494c:	97fff755 	bl	26a0 <exit@plt>

0000000000004950 <fwp_heap_alloc_big>:
    4950:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4954:	910003fd 	mov	x29, sp
    4958:	a90153f3 	stp	x19, x20, [sp, #16]
    495c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4960:	a90363f7 	stp	x23, x24, [sp, #48]
    4964:	aa0003f7 	mov	x23, x0
    4968:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    496c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4970:	eb0002ff 	cmp	x23, x0
    4974:	540008a8 	b.hi	4a88 <fwp_heap_alloc_big+0x138>  // b.pmore
    4978:	d29fffe0 	mov	x0, #0xffff                	// #65535
    497c:	8b0002f4 	add	x20, x23, x0
    4980:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc90>
    4984:	91154359 	add	x25, x26, #0x550
    4988:	d350fe94 	lsr	x20, x20, #16
    498c:	2a0103f5 	mov	w21, w1
    4990:	aa1403e0 	mov	x0, x20
    4994:	97fff9c7 	bl	30b0 <fwp_heap_chunks>
    4998:	f949ff22 	ldr	x2, [x25, #5112]
    499c:	8b000813 	add	x19, x0, x0, lsl #2
    49a0:	aa0003f8 	mov	x24, x0
    49a4:	52800043 	mov	w3, #0x2                   	// #2
    49a8:	d37df273 	lsl	x19, x19, #3
    49ac:	d2800021 	mov	x1, #0x1                   	// #1
    49b0:	8b130040 	add	x0, x2, x19
    49b4:	38336843 	strb	w3, [x2, x19]
    49b8:	39000415 	strb	w21, [x0, #1]
    49bc:	b9000c14 	str	w20, [x0, #12]
    49c0:	f9000817 	str	x23, [x0, #16]
    49c4:	97fffd57 	bl	3f20 <fwp_rc_prepare_chunk>
    49c8:	f100069f 	cmp	x20, #0x1
    49cc:	54000289 	b.ls	4a1c <fwp_heap_alloc_big+0xcc>  // b.plast
    49d0:	8b180294 	add	x20, x20, x24
    49d4:	9100a273 	add	x19, x19, #0x28
    49d8:	a90573fb 	stp	x27, x28, [sp, #80]
    49dc:	5280007b 	mov	w27, #0x3                   	// #3
    49e0:	8b140a94 	add	x20, x20, x20, lsl #2
    49e4:	2a1803fc 	mov	w28, w24
    49e8:	9adb2296 	lsl	x22, x20, x27
    49ec:	d503201f 	nop
    49f0:	f949ff35 	ldr	x21, [x25, #5112]
    49f4:	d2800001 	mov	x1, #0x0                   	// #0
    49f8:	8b1302b4 	add	x20, x21, x19
    49fc:	aa1403e0 	mov	x0, x20
    4a00:	97fffd48 	bl	3f20 <fwp_rc_prepare_chunk>
    4a04:	38336abb 	strb	w27, [x21, x19]
    4a08:	9100a273 	add	x19, x19, #0x28
    4a0c:	b9000e9c 	str	w28, [x20, #12]
    4a10:	eb1302df 	cmp	x22, x19
    4a14:	54fffee1 	b.ne	49f0 <fwp_heap_alloc_big+0xa0>  // b.any
    4a18:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a1c:	91154353 	add	x19, x26, #0x550
    4a20:	aa1703e2 	mov	x2, x23
    4a24:	52800001 	mov	w1, #0x0                   	// #0
    4a28:	f949da60 	ldr	x0, [x19, #5040]
    4a2c:	8b184018 	add	x24, x0, x24, lsl #16
    4a30:	aa1803e0 	mov	x0, x24
    4a34:	97fff763 	bl	27c0 <memset@plt>
    4a38:	f94a1260 	ldr	x0, [x19, #5152]
    4a3c:	ab170000 	adds	x0, x0, x23
    4a40:	54000242 	b.cs	4a88 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4a44:	f94a1661 	ldr	x1, [x19, #5160]
    4a48:	f90a1260 	str	x0, [x19, #5152]
    4a4c:	eb01001f 	cmp	x0, x1
    4a50:	54000049 	b.ls	4a58 <fwp_heap_alloc_big+0x108>  // b.plast
    4a54:	f90a1660 	str	x0, [x19, #5160]
    4a58:	9115435a 	add	x26, x26, #0x550
    4a5c:	9e6202e0 	scvtf	d0, x23
    4a60:	a94153f3 	ldp	x19, x20, [sp, #16]
    4a64:	aa1803e0 	mov	x0, x24
    4a68:	fd4a1f41 	ldr	d1, [x26, #5176]
    4a6c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4a70:	1e602820 	fadd	d0, d1, d0
    4a74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4a78:	fd0a1f40 	str	d0, [x26, #5176]
    4a7c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4a80:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4a84:	d65f03c0 	ret
    4a88:	a90573fb 	stp	x27, x28, [sp, #80]
    4a8c:	97fff949 	bl	2fb0 <fwp_heap_oom>

0000000000004a90 <fwp_heap_alloc_slow>:
    4a90:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4a94:	910003fd 	mov	x29, sp
    4a98:	a90153f3 	stp	x19, x20, [sp, #16]
    4a9c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc90>
    4aa0:	91154262 	add	x2, x19, #0x550
    4aa4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4aa8:	aa0003f5 	mov	x21, x0
    4aac:	2a0103f4 	mov	w20, w1
    4ab0:	b953a440 	ldr	w0, [x2, #5028]
    4ab4:	34000600 	cbz	w0, 4b74 <fwp_heap_alloc_slow+0xe4>
    4ab8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4abc:	54000628 	b.hi	4b80 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4ac0:	91003ea0 	add	x0, x21, #0xf
    4ac4:	91154262 	add	x2, x19, #0x550
    4ac8:	f9001bf7 	str	x23, [sp, #48]
    4acc:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ad0:	8b401040 	add	x0, x2, x0, lsr #4
    4ad4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ad8:	d37ae484 	lsl	x4, x4, #6
    4adc:	397e8003 	ldrb	w3, [x0, #4000]
    4ae0:	910f0060 	add	x0, x3, #0x3c0
    4ae4:	aa0303e1 	mov	x1, x3
    4ae8:	8b030463 	add	x3, x3, x3, lsl #1
    4aec:	8b030c83 	add	x3, x4, x3, lsl #3
    4af0:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4af4:	2a1703f6 	mov	w22, w23
    4af8:	f8636844 	ldr	x4, [x2, x3]
    4afc:	b40004e4 	cbz	x4, 4b98 <fwp_heap_alloc_slow+0x108>
    4b00:	f9400080 	ldr	x0, [x4]
    4b04:	aa2003e0 	mvn	x0, x0
    4b08:	f8236840 	str	x0, [x2, x3]
    4b0c:	7100069f 	cmp	w20, #0x1
    4b10:	aa0403e0 	mov	x0, x4
    4b14:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b18:	52800001 	mov	w1, #0x0                   	// #0
    4b1c:	97fff729 	bl	27c0 <memset@plt>
    4b20:	aa0003e4 	mov	x4, x0
    4b24:	91154260 	add	x0, x19, #0x550
    4b28:	f94a1001 	ldr	x1, [x0, #5152]
    4b2c:	ab160021 	adds	x1, x1, x22
    4b30:	540005c2 	b.cs	4be8 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4b34:	f94a1402 	ldr	x2, [x0, #5160]
    4b38:	f90a1001 	str	x1, [x0, #5152]
    4b3c:	eb02003f 	cmp	x1, x2
    4b40:	54000049 	b.ls	4b48 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4b44:	f90a1401 	str	x1, [x0, #5160]
    4b48:	91154273 	add	x19, x19, #0x550
    4b4c:	1e6302e1 	ucvtf	d1, w23
    4b50:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b54:	aa0403e0 	mov	x0, x4
    4b58:	fd4a1e60 	ldr	d0, [x19, #5176]
    4b5c:	f9401bf7 	ldr	x23, [sp, #48]
    4b60:	1e612800 	fadd	d0, d0, d1
    4b64:	fd0a1e60 	str	d0, [x19, #5176]
    4b68:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b6c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b70:	d65f03c0 	ret
    4b74:	97fffbbf 	bl	3a70 <fwp_heap_init>
    4b78:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b7c:	54fffa29 	b.ls	4ac0 <fwp_heap_alloc_slow+0x30>  // b.plast
    4b80:	2a1403e1 	mov	w1, w20
    4b84:	aa1503e0 	mov	x0, x21
    4b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b90:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4b94:	17ffff6f 	b	4950 <fwp_heap_alloc_big>
    4b98:	8b030042 	add	x2, x2, x3
    4b9c:	f9400444 	ldr	x4, [x2, #8]
    4ba0:	b4000104 	cbz	x4, 4bc0 <fwp_heap_alloc_slow+0x130>
    4ba4:	f9400840 	ldr	x0, [x2, #16]
    4ba8:	cb040000 	sub	x0, x0, x4
    4bac:	eb16001f 	cmp	x0, x22
    4bb0:	54000083 	b.cc	4bc0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4bb4:	8b160080 	add	x0, x4, x22
    4bb8:	f9000440 	str	x0, [x2, #8]
    4bbc:	17ffffd4 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4bc0:	52800302 	mov	w2, #0x18                  	// #24
    4bc4:	52807804 	mov	w4, #0x3c0                 	// #960
    4bc8:	91154260 	add	x0, x19, #0x550
    4bcc:	9ba27c23 	umull	x3, w1, w2
    4bd0:	2a1403e2 	mov	w2, w20
    4bd4:	9b240e84 	smaddl	x4, w20, w4, x3
    4bd8:	8b040000 	add	x0, x0, x4
    4bdc:	97fffd19 	bl	4040 <fwp_heap_refill>
    4be0:	aa0003e4 	mov	x4, x0
    4be4:	17ffffca 	b	4b0c <fwp_heap_alloc_slow+0x7c>
    4be8:	97fff8f2 	bl	2fb0 <fwp_heap_oom>
    4bec:	d503201f 	nop

0000000000004bf0 <fwp_heap_alloc>:
    4bf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4bf4:	f140101f 	cmp	x0, #0x4, lsl #12
    4bf8:	910003fd 	mov	x29, sp
    4bfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4c00:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    4c04:	91154293 	add	x19, x20, #0x550
    4c08:	b953a662 	ldr	w2, [x19, #5028]
    4c0c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c10:	54000640 	b.eq	4cd8 <fwp_heap_alloc+0xe8>  // b.none
    4c14:	91003c03 	add	x3, x0, #0xf
    4c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c1c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4c20:	8b431263 	add	x3, x19, x3, lsr #4
    4c24:	cb21c042 	sub	x2, x2, w1, sxtw
    4c28:	d37ae442 	lsl	x2, x2, #6
    4c2c:	397e8063 	ldrb	w3, [x3, #4000]
    4c30:	910f0064 	add	x4, x3, #0x3c0
    4c34:	8b030463 	add	x3, x3, x3, lsl #1
    4c38:	8b030c43 	add	x3, x2, x3, lsl #3
    4c3c:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4c40:	2a1603f5 	mov	w21, w22
    4c44:	f8636a64 	ldr	x4, [x19, x3]
    4c48:	b4000384 	cbz	x4, 4cb8 <fwp_heap_alloc+0xc8>
    4c4c:	f9400085 	ldr	x5, [x4]
    4c50:	7100043f 	cmp	w1, #0x1
    4c54:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4c58:	aa0403e0 	mov	x0, x4
    4c5c:	aa2503e5 	mvn	x5, x5
    4c60:	52800001 	mov	w1, #0x0                   	// #0
    4c64:	f8236a65 	str	x5, [x19, x3]
    4c68:	97fff6d6 	bl	27c0 <memset@plt>
    4c6c:	aa0003e4 	mov	x4, x0
    4c70:	f94a1260 	ldr	x0, [x19, #5152]
    4c74:	ab150000 	adds	x0, x0, x21
    4c78:	54000442 	b.cs	4d00 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4c7c:	f94a1661 	ldr	x1, [x19, #5160]
    4c80:	f90a1260 	str	x0, [x19, #5152]
    4c84:	eb01001f 	cmp	x0, x1
    4c88:	54000049 	b.ls	4c90 <fwp_heap_alloc+0xa0>  // b.plast
    4c8c:	f90a1660 	str	x0, [x19, #5160]
    4c90:	91154294 	add	x20, x20, #0x550
    4c94:	1e6302c1 	ucvtf	d1, w22
    4c98:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c9c:	aa0403e0 	mov	x0, x4
    4ca0:	fd4a1e80 	ldr	d0, [x20, #5176]
    4ca4:	1e612800 	fadd	d0, d0, d1
    4ca8:	fd0a1e80 	str	d0, [x20, #5176]
    4cac:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4cb4:	d65f03c0 	ret
    4cb8:	8b030263 	add	x3, x19, x3
    4cbc:	f9400464 	ldr	x4, [x3, #8]
    4cc0:	b40000a4 	cbz	x4, 4cd4 <fwp_heap_alloc+0xe4>
    4cc4:	f9400862 	ldr	x2, [x3, #16]
    4cc8:	cb040042 	sub	x2, x2, x4
    4ccc:	eb15005f 	cmp	x2, x21
    4cd0:	540000a2 	b.cs	4ce4 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4cd4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4cd8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cdc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ce0:	17ffff6c 	b	4a90 <fwp_heap_alloc_slow>
    4ce4:	7100043f 	cmp	w1, #0x1
    4ce8:	8b150085 	add	x5, x4, x21
    4cec:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cf0:	52800001 	mov	w1, #0x0                   	// #0
    4cf4:	aa0403e0 	mov	x0, x4
    4cf8:	f9000465 	str	x5, [x3, #8]
    4cfc:	17ffffdb 	b	4c68 <fwp_heap_alloc+0x78>
    4d00:	97fff8ac 	bl	2fb0 <fwp_heap_oom>

0000000000004d04 <fwp_apply>:
    4d04:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4d08:	aa0003e6 	mov	x6, x0
    4d0c:	910003fd 	mov	x29, sp
    4d10:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    4d14:	f947f463 	ldr	x3, [x3, #4072]
    4d18:	a90153f3 	stp	x19, x20, [sp, #16]
    4d1c:	aa0203f4 	mov	x20, x2
    4d20:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d24:	2a0103f5 	mov	w21, w1
    4d28:	52800033 	mov	w19, #0x1                   	// #1
    4d2c:	a90363f7 	stp	x23, x24, [sp, #48]
    4d30:	900000f7 	adrp	x23, 20000 <__data_start>
    4d34:	910102f7 	add	x23, x23, #0x40
    4d38:	a9046bf9 	stp	x25, x26, [sp, #64]
    4d3c:	d100c3ff 	sub	sp, sp, #0x30
    4d40:	f9400060 	ldr	x0, [x3]
    4d44:	f81f83a0 	stur	x0, [x29, #-8]
    4d48:	d2800000 	mov	x0, #0x0                   	// #0
    4d4c:	294058c3 	ldp	w3, w22, [x6]
    4d50:	910003f8 	mov	x24, sp
    4d54:	f9403ee0 	ldr	x0, [x23, #120]
    4d58:	710002df 	cmp	w22, #0x0
    4d5c:	d37be863 	lsl	x3, x3, #5
    4d60:	8b030007 	add	x7, x0, x3
    4d64:	b8636819 	ldr	w25, [x0, x3]
    4d68:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    4d6c:	54000163 	b.cc	4d98 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    4d70:	f94004e3 	ldr	x3, [x7, #8]
    4d74:	34000bd9 	cbz	w25, 4eec <fwp_apply+0x1e8>
    4d78:	aa1403e0 	mov	x0, x20
    4d7c:	d63f0060 	blr	x3
    4d80:	aa0003e6 	mov	x6, x0
    4d84:	6b1902bf 	cmp	w21, w25
    4d88:	54000940 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4d8c:	8b394e94 	add	x20, x20, w25, uxtw #3
    4d90:	4b1902b5 	sub	w21, w21, w25
    4d94:	17ffffee 	b	4d4c <fwp_apply+0x48>
    4d98:	0b1602ba 	add	w26, w21, w22
    4d9c:	6b19035f 	cmp	w26, w25
    4da0:	54000543 	b.cc	4e48 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    4da4:	7100033f 	cmp	w25, #0x0
    4da8:	4b16033a 	sub	w26, w25, w22
    4dac:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    4db0:	d37df000 	lsl	x0, x0, #3
    4db4:	91003c00 	add	x0, x0, #0xf
    4db8:	92704c01 	and	x1, x0, #0xfffff0000
    4dbc:	927c7c00 	and	x0, x0, #0xffffffff0
    4dc0:	cb2163e1 	sub	x1, sp, x1
    4dc4:	eb2163ff 	cmp	sp, x1
    4dc8:	540000a0 	b.eq	4ddc <fwp_apply+0xd8>  // b.none
    4dcc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    4dd0:	f90203ff 	str	xzr, [sp, #1024]
    4dd4:	eb2163ff 	cmp	sp, x1
    4dd8:	54ffffa1 	b.ne	4dcc <fwp_apply+0xc8>  // b.any
    4ddc:	92403c00 	and	x0, x0, #0xffff
    4de0:	cb2063ff 	sub	sp, sp, x0
    4de4:	f90003ff 	str	xzr, [sp]
    4de8:	f110001f 	cmp	x0, #0x400
    4dec:	54000962 	b.cs	4f18 <fwp_apply+0x214>  // b.hs, b.nlast
    4df0:	910020c6 	add	x6, x6, #0x8
    4df4:	910043e0 	add	x0, sp, #0x10
    4df8:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    4dfc:	d2800003 	mov	x3, #0x0                   	// #0
    4e00:	340000f6 	cbz	w22, 4e1c <fwp_apply+0x118>
    4e04:	d503201f 	nop
    4e08:	f86368c4 	ldr	x4, [x6, x3]
    4e0c:	f8236804 	str	x4, [x0, x3]
    4e10:	91002063 	add	x3, x3, #0x8
    4e14:	eb0300bf 	cmp	x5, x3
    4e18:	54ffff81 	b.ne	4e08 <fwp_apply+0x104>  // b.any
    4e1c:	3400013a 	cbz	w26, 4e40 <fwp_apply+0x13c>
    4e20:	2a1a03e6 	mov	w6, w26
    4e24:	d2800003 	mov	x3, #0x0                   	// #0
    4e28:	0b0302c4 	add	w4, w22, w3
    4e2c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    4e30:	91000463 	add	x3, x3, #0x1
    4e34:	f8247805 	str	x5, [x0, x4, lsl #3]
    4e38:	eb0300df 	cmp	x6, x3
    4e3c:	54ffff61 	b.ne	4e28 <fwp_apply+0x124>  // b.any
    4e40:	f94004e3 	ldr	x3, [x7, #8]
    4e44:	1400002c 	b	4ef4 <fwp_apply+0x1f0>
    4e48:	11000740 	add	w0, w26, #0x1
    4e4c:	52800041 	mov	w1, #0x2                   	// #2
    4e50:	f81e83a6 	stur	x6, [x29, #-24]
    4e54:	d37df000 	lsl	x0, x0, #3
    4e58:	97ffff66 	bl	4bf0 <fwp_heap_alloc>
    4e5c:	f85e83a6 	ldur	x6, [x29, #-24]
    4e60:	aa0003f3 	mov	x19, x0
    4e64:	b94000c1 	ldr	w1, [x6]
    4e68:	29006801 	stp	w1, w26, [x0]
    4e6c:	340000b6 	cbz	w22, 4e80 <fwp_apply+0x17c>
    4e70:	910020c1 	add	x1, x6, #0x8
    4e74:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    4e78:	91002000 	add	x0, x0, #0x8
    4e7c:	97fff5f9 	bl	2660 <memmove@plt>
    4e80:	2a1503e3 	mov	w3, w21
    4e84:	d2800000 	mov	x0, #0x0                   	// #0
    4e88:	34000135 	cbz	w21, 4eac <fwp_apply+0x1a8>
    4e8c:	d503201f 	nop
    4e90:	0b0002c1 	add	w1, w22, w0
    4e94:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    4e98:	8b010e61 	add	x1, x19, x1, lsl #3
    4e9c:	91000400 	add	x0, x0, #0x1
    4ea0:	f9000422 	str	x2, [x1, #8]
    4ea4:	eb00007f 	cmp	x3, x0
    4ea8:	54ffff41 	b.ne	4e90 <fwp_apply+0x18c>  // b.any
    4eac:	aa1303e6 	mov	x6, x19
    4eb0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    4eb4:	f947f400 	ldr	x0, [x0, #4072]
    4eb8:	f85f83a2 	ldur	x2, [x29, #-8]
    4ebc:	f9400001 	ldr	x1, [x0]
    4ec0:	eb010042 	subs	x2, x2, x1
    4ec4:	d2800001 	mov	x1, #0x0                   	// #0
    4ec8:	540002c1 	b.ne	4f20 <fwp_apply+0x21c>  // b.any
    4ecc:	910003bf 	mov	sp, x29
    4ed0:	aa0603e0 	mov	x0, x6
    4ed4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ed8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4edc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4ee0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4ee4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4ee8:	d65f03c0 	ret
    4eec:	d10043a0 	sub	x0, x29, #0x10
    4ef0:	5280001a 	mov	w26, #0x0                   	// #0
    4ef4:	d63f0060 	blr	x3
    4ef8:	aa0003e6 	mov	x6, x0
    4efc:	6b1a02bf 	cmp	w21, w26
    4f00:	54fffd80 	b.eq	4eb0 <fwp_apply+0x1ac>  // b.none
    4f04:	0b1602b6 	add	w22, w21, w22
    4f08:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    4f0c:	4b1902d5 	sub	w21, w22, w25
    4f10:	9100031f 	mov	sp, x24
    4f14:	17ffff8e 	b	4d4c <fwp_apply+0x48>
    4f18:	f90203ff 	str	xzr, [sp, #1024]
    4f1c:	17ffffb5 	b	4df0 <fwp_apply+0xec>
    4f20:	97fff634 	bl	27f0 <__stack_chk_fail@plt>

0000000000004f24 <fwp_tape_reserve>:
    4f24:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4f28:	910003fd 	mov	x29, sp
    4f2c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f30:	aa0003f3 	mov	x19, x0
    4f34:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4f38:	eb00003f 	cmp	x1, x0
    4f3c:	54000868 	b.hi	5048 <fwp_tape_reserve+0x124>  // b.pmore
    4f40:	f9400e74 	ldr	x20, [x19, #24]
    4f44:	eb01029f 	cmp	x20, x1
    4f48:	5400076a 	b.ge	5034 <fwp_tape_reserve+0x110>  // b.tcont
    4f4c:	f100029f 	cmp	x20, #0x0
    4f50:	d2800802 	mov	x2, #0x40                  	// #64
    4f54:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    4f58:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    4f5c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f60:	a90363f7 	stp	x23, x24, [sp, #48]
    4f64:	eb01029f 	cmp	x20, x1
    4f68:	5400008a 	b.ge	4f78 <fwp_tape_reserve+0x54>  // b.tcont
    4f6c:	eb00029f 	cmp	x20, x0
    4f70:	5400068d 	b.le	5040 <fwp_tape_reserve+0x11c>
    4f74:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4f78:	a940d662 	ldp	x2, x21, [x19, #8]
    4f7c:	d37df297 	lsl	x23, x20, #3
    4f80:	f9401260 	ldr	x0, [x19, #32]
    4f84:	aa1703e1 	mov	x1, x23
    4f88:	f9403276 	ldr	x22, [x19, #96]
    4f8c:	cb0202b5 	sub	x21, x21, x2
    4f90:	97fff614 	bl	27e0 <realloc@plt>
    4f94:	b4000b00 	cbz	x0, 50f4 <fwp_tape_reserve+0x1d0>
    4f98:	f9400e61 	ldr	x1, [x19, #24]
    4f9c:	8b010801 	add	x1, x0, x1, lsl #2
    4fa0:	a9020660 	stp	x0, x1, [x19, #32]
    4fa4:	b40008b6 	cbz	x22, 50b8 <fwp_tape_reserve+0x194>
    4fa8:	f94032d7 	ldr	x23, [x22, #96]
    4fac:	eb17029f 	cmp	x20, x23
    4fb0:	5400034d 	b.le	5018 <fwp_tape_reserve+0xf4>
    4fb4:	a9046bf9 	stp	x25, x26, [sp, #64]
    4fb8:	d37cee9a 	lsl	x26, x20, #4
    4fbc:	aa1a03e0 	mov	x0, x26
    4fc0:	f94022d9 	ldr	x25, [x22, #64]
    4fc4:	52800041 	mov	w1, #0x2                   	// #2
    4fc8:	97ffff0a 	bl	4bf0 <fwp_heap_alloc>
    4fcc:	aa0003f8 	mov	x24, x0
    4fd0:	b4000119 	cbz	x25, 4ff0 <fwp_tape_reserve+0xcc>
    4fd4:	d37ceef7 	lsl	x23, x23, #4
    4fd8:	aa1903e1 	mov	x1, x25
    4fdc:	eb1a02ff 	cmp	x23, x26
    4fe0:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    4fe4:	97fff597 	bl	2640 <memcpy@plt>
    4fe8:	aa1903e0 	mov	x0, x25
    4fec:	97fffc45 	bl	4100 <fwp_mem_free>
    4ff0:	f94032c0 	ldr	x0, [x22, #96]
    4ff4:	52800001 	mov	w1, #0x0                   	// #0
    4ff8:	cb000282 	sub	x2, x20, x0
    4ffc:	8b001300 	add	x0, x24, x0, lsl #4
    5000:	d37cec42 	lsl	x2, x2, #4
    5004:	97fff5ef 	bl	27c0 <memset@plt>
    5008:	f9401260 	ldr	x0, [x19, #32]
    500c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5010:	f90022d8 	str	x24, [x22, #64]
    5014:	f90032d4 	str	x20, [x22, #96]
    5018:	d37ef696 	lsl	x22, x20, #2
    501c:	b5000375 	cbnz	x21, 5088 <fwp_tape_reserve+0x164>
    5020:	a94363f7 	ldp	x23, x24, [sp, #48]
    5024:	8b160000 	add	x0, x0, x22
    5028:	a9425bf5 	ldp	x21, x22, [sp, #32]
    502c:	f9000e74 	str	x20, [x19, #24]
    5030:	f9001660 	str	x0, [x19, #40]
    5034:	a94153f3 	ldp	x19, x20, [sp, #16]
    5038:	a8c57bfd 	ldp	x29, x30, [sp], #80
    503c:	d65f03c0 	ret
    5040:	d37ffa94 	lsl	x20, x20, #1
    5044:	17ffffc8 	b	4f64 <fwp_tape_reserve+0x40>
    5048:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    504c:	912d0000 	add	x0, x0, #0xb40
    5050:	a9025bf5 	stp	x21, x22, [sp, #32]
    5054:	a90363f7 	stp	x23, x24, [sp, #48]
    5058:	a9046bf9 	stp	x25, x26, [sp, #64]
    505c:	97fffb6d 	bl	3e10 <fwp_trap>
    5060:	eb1602ff 	cmp	x23, x22
    5064:	aa0403e0 	mov	x0, x4
    5068:	9a9622e3 	csel	x3, x23, x22, cs	// cs = hs, nlast
    506c:	d37df2a2 	lsl	x2, x21, #3
    5070:	cb170063 	sub	x3, x3, x23
    5074:	97fff647 	bl	2990 <__memmove_chk@plt>
    5078:	f9401a61 	ldr	x1, [x19, #48]
    507c:	f9401260 	ldr	x0, [x19, #32]
    5080:	8b170021 	add	x1, x1, x23
    5084:	f9001e61 	str	x1, [x19, #56]
    5088:	f9401661 	ldr	x1, [x19, #40]
    508c:	d37ef696 	lsl	x22, x20, #2
    5090:	d37ef6a2 	lsl	x2, x21, #2
    5094:	8b160000 	add	x0, x0, x22
    5098:	97fff572 	bl	2660 <memmove@plt>
    509c:	f9401260 	ldr	x0, [x19, #32]
    50a0:	a94363f7 	ldp	x23, x24, [sp, #48]
    50a4:	8b160000 	add	x0, x0, x22
    50a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50ac:	f9000e74 	str	x20, [x19, #24]
    50b0:	f9001660 	str	x0, [x19, #40]
    50b4:	17ffffe0 	b	5034 <fwp_tape_reserve+0x110>
    50b8:	f9401a60 	ldr	x0, [x19, #48]
    50bc:	d37cee96 	lsl	x22, x20, #4
    50c0:	aa1603e1 	mov	x1, x22
    50c4:	97fff5c7 	bl	27e0 <realloc@plt>
    50c8:	b4000160 	cbz	x0, 50f4 <fwp_tape_reserve+0x1d0>
    50cc:	f9400e62 	ldr	x2, [x19, #24]
    50d0:	f9001a60 	str	x0, [x19, #48]
    50d4:	8b170004 	add	x4, x0, x23
    50d8:	8b020c01 	add	x1, x0, x2, lsl #3
    50dc:	f9001e61 	str	x1, [x19, #56]
    50e0:	b5fffc15 	cbnz	x21, 5060 <fwp_tape_reserve+0x13c>
    50e4:	f9401260 	ldr	x0, [x19, #32]
    50e8:	d37ef696 	lsl	x22, x20, #2
    50ec:	f9001e64 	str	x4, [x19, #56]
    50f0:	17ffffcc 	b	5020 <fwp_tape_reserve+0xfc>
    50f4:	aa1303e0 	mov	x0, x19
    50f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    50fc:	97fff785 	bl	2f10 <fwp_tape_unlink_scope>
    5100:	f9401260 	ldr	x0, [x19, #32]
    5104:	97fff5eb 	bl	28b0 <free@plt>
    5108:	f9401a60 	ldr	x0, [x19, #48]
    510c:	97fff5e9 	bl	28b0 <free@plt>
    5110:	f9402260 	ldr	x0, [x19, #64]
    5114:	97fff5e7 	bl	28b0 <free@plt>
    5118:	f9000e7f 	str	xzr, [x19, #24]
    511c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5120:	f947e821 	ldr	x1, [x1, #4048]
    5124:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5128:	d2800262 	mov	x2, #0x13                  	// #19
    512c:	4f000400 	movi	v0.4s, #0x0
    5130:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    5134:	f9400023 	ldr	x3, [x1]
    5138:	b900067f 	str	wzr, [x19, #4]
    513c:	d2800021 	mov	x1, #0x1                   	// #1
    5140:	91216000 	add	x0, x0, #0x858
    5144:	3c808260 	stur	q0, [x19, #8]
    5148:	ad010260 	stp	q0, q0, [x19, #32]
    514c:	97fff5e9 	bl	28f0 <fwrite@plt>
    5150:	d2800000 	mov	x0, #0x0                   	// #0
    5154:	97fff5f3 	bl	2920 <fflush@plt>
    5158:	52800cc0 	mov	w0, #0x66                  	// #102
    515c:	97fff601 	bl	2960 <_Exit@plt>

0000000000005160 <f128.constprop.0>:
    5160:	f100001f 	cmp	x0, #0x0
    5164:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5168:	5400094b 	b.lt	5290 <f128.constprop.0+0x130>  // b.tstop
    516c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5170:	aa0003e2 	mov	x2, x0
    5174:	910003fd 	mov	x29, sp
    5178:	a90153f3 	stp	x19, x20, [sp, #16]
    517c:	aa0003f4 	mov	x20, x0
    5180:	aa010000 	orr	x0, x0, x1
    5184:	a9025bf5 	stp	x21, x22, [sp, #32]
    5188:	aa0103f6 	mov	x22, x1
    518c:	f9001bf7 	str	x23, [sp, #48]
    5190:	fd001fe8 	str	d8, [sp, #56]
    5194:	b7f80180 	tbnz	x0, #63, 51c4 <f128.constprop.0+0x64>
    5198:	9360fc20 	asr	x0, x1, #32
    519c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    51a0:	eb82801f 	cmp	x0, x2, asr #32
    51a4:	540007a1 	b.ne	5298 <f128.constprop.0+0x138>  // b.any
    51a8:	97fffd1e 	bl	4620 <fwp_tape_of>
    51ac:	aa0003f3 	mov	x19, x0
    51b0:	f9403000 	ldr	x0, [x0, #96]
    51b4:	b40001e0 	cbz	x0, 51f0 <f128.constprop.0+0x90>
    51b8:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    51bc:	912ea000 	add	x0, x0, #0xba8
    51c0:	97fffb14 	bl	3e10 <fwp_trap>
    51c4:	9360fc40 	asr	x0, x2, #32
    51c8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    51cc:	b6fffee2 	tbz	x2, #63, 51a8 <f128.constprop.0+0x48>
    51d0:	2f00e408 	movi	d8, #0x0
    51d4:	9360fc20 	asr	x0, x1, #32
    51d8:	aa0103f4 	mov	x20, x1
    51dc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    51e0:	97fffd10 	bl	4620 <fwp_tape_of>
    51e4:	aa0003f3 	mov	x19, x0
    51e8:	f9403000 	ldr	x0, [x0, #96]
    51ec:	b5fffe60 	cbnz	x0, 51b8 <f128.constprop.0+0x58>
    51f0:	f9400a77 	ldr	x23, [x19, #16]
    51f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    51f8:	eb0002ff 	cmp	x23, x0
    51fc:	5400044c 	b.gt	5284 <f128.constprop.0+0x124>
    5200:	eb3442ff 	cmp	x23, w20, uxtw
    5204:	5400008d 	b.le	5214 <f128.constprop.0+0xb4>
    5208:	b7f800d6 	tbnz	x22, #63, 5220 <f128.constprop.0+0xc0>
    520c:	eb3642ff 	cmp	x23, w22, uxtw
    5210:	5400008c 	b.gt	5220 <f128.constprop.0+0xc0>
    5214:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    5218:	912f6000 	add	x0, x0, #0xbd8
    521c:	97fffafd 	bl	3e10 <fwp_trap>
    5220:	f9400675 	ldr	x21, [x19, #8]
    5224:	aa1303e0 	mov	x0, x19
    5228:	cb1502f5 	sub	x21, x23, x21
    522c:	910006a1 	add	x1, x21, #0x1
    5230:	97ffff3d 	bl	4f24 <fwp_tape_reserve>
    5234:	a9420262 	ldp	x2, x0, [x19, #32]
    5238:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    523c:	f9401a61 	ldr	x1, [x19, #48]
    5240:	b8357854 	str	w20, [x2, x21, lsl #2]
    5244:	f9401e62 	ldr	x2, [x19, #56]
    5248:	f10002df 	cmp	x22, #0x0
    524c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5250:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5254:	b8357816 	str	w22, [x0, x21, lsl #2]
    5258:	92607e80 	and	x0, x20, #0xffffffff00000000
    525c:	910006e1 	add	x1, x23, #0x1
    5260:	aa170000 	orr	x0, x0, x23
    5264:	fc357848 	str	d8, [x2, x21, lsl #3]
    5268:	a9425bf5 	ldp	x21, x22, [sp, #32]
    526c:	f9401bf7 	ldr	x23, [sp, #48]
    5270:	fd401fe8 	ldr	d8, [sp, #56]
    5274:	f9000a61 	str	x1, [x19, #16]
    5278:	a94153f3 	ldp	x19, x20, [sp, #16]
    527c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5280:	d65f03c0 	ret
    5284:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    5288:	912d0000 	add	x0, x0, #0xb40
    528c:	97fffae1 	bl	3e10 <fwp_trap>
    5290:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5294:	d65f03c0 	ret
    5298:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    529c:	912d8000 	add	x0, x0, #0xb60
    52a0:	97fffadc 	bl	3e10 <fwp_trap>

00000000000052a4 <w107>:
    52a4:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    52a8:	910003fd 	mov	x29, sp
    52ac:	a90153f3 	stp	x19, x20, [sp, #16]
    52b0:	a9025bf5 	stp	x21, x22, [sp, #32]
    52b4:	aa0003f5 	mov	x21, x0
    52b8:	a90363f7 	stp	x23, x24, [sp, #48]
    52bc:	aa0103f7 	mov	x23, x1
    52c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    52c4:	f9002bfb 	str	x27, [sp, #80]
    52c8:	6d0627e8 	stp	d8, d9, [sp, #96]
    52cc:	1e604028 	fmov	d8, d1
    52d0:	1e600809 	fmul	d9, d0, d0
    52d4:	6d072fea 	stp	d10, d11, [sp, #112]
    52d8:	1e60400b 	fmov	d11, d0
    52dc:	b7f81c80 	tbnz	x0, #63, 566c <w107+0x3c8>
    52e0:	9360fc19 	asr	x25, x0, #32
    52e4:	aa1903e0 	mov	x0, x25
    52e8:	97fffcce 	bl	4620 <fwp_tape_of>
    52ec:	f9403001 	ldr	x1, [x0, #96]
    52f0:	aa0003f3 	mov	x19, x0
    52f4:	b4000081 	cbz	x1, 5304 <w107+0x60>
    52f8:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    52fc:	912ea000 	add	x0, x0, #0xba8
    5300:	97fffac4 	bl	3e10 <fwp_trap>
    5304:	f9400818 	ldr	x24, [x0, #16]
    5308:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    530c:	eb01031f 	cmp	x24, x1
    5310:	54001a8c 	b.gt	5660 <w107+0x3bc>
    5314:	eb35431f 	cmp	x24, w21, uxtw
    5318:	540019ed 	b.le	5654 <w107+0x3b0>
    531c:	f9400416 	ldr	x22, [x0, #8]
    5320:	92607eb4 	and	x20, x21, #0xffffffff00000000
    5324:	aa180294 	orr	x20, x20, x24
    5328:	cb160316 	sub	x22, x24, x22
    532c:	910006c1 	add	x1, x22, #0x1
    5330:	97fffefd 	bl	4f24 <fwp_tape_reserve>
    5334:	a9420a61 	ldp	x1, x2, [x19, #32]
    5338:	91000700 	add	x0, x24, #0x1
    533c:	f9401a63 	ldr	x3, [x19, #48]
    5340:	b8367835 	str	w21, [x1, x22, lsl #2]
    5344:	f9401e61 	ldr	x1, [x19, #56]
    5348:	1e693908 	fsub	d8, d8, d9
    534c:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5350:	9360fe9a 	asr	x26, x20, #32
    5354:	b8367855 	str	w21, [x2, x22, lsl #2]
    5358:	fc36782b 	str	d11, [x1, x22, lsl #3]
    535c:	f9000a60 	str	x0, [x19, #16]
    5360:	b7f80077 	tbnz	x23, #63, 536c <w107+0xc8>
    5364:	eb97835f 	cmp	x26, x23, asr #32
    5368:	540019a1 	b.ne	569c <w107+0x3f8>  // b.any
    536c:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5370:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    5374:	eb19035f 	cmp	x26, x25
    5378:	540000c0 	b.eq	5390 <w107+0xec>  // b.none
    537c:	aa1a03e0 	mov	x0, x26
    5380:	97fffca8 	bl	4620 <fwp_tape_of>
    5384:	aa0003f3 	mov	x19, x0
    5388:	f9403000 	ldr	x0, [x0, #96]
    538c:	b5fffb60 	cbnz	x0, 52f8 <w107+0x54>
    5390:	f9400a79 	ldr	x25, [x19, #16]
    5394:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5398:	eb00033f 	cmp	x25, x0
    539c:	5400162c 	b.gt	5660 <w107+0x3bc>
    53a0:	eb34433f 	cmp	x25, w20, uxtw
    53a4:	5400158d 	b.le	5654 <w107+0x3b0>
    53a8:	b7f80077 	tbnz	x23, #63, 53b4 <w107+0x110>
    53ac:	eb37433f 	cmp	x25, w23, uxtw
    53b0:	5400152d 	b.le	5654 <w107+0x3b0>
    53b4:	f9400676 	ldr	x22, [x19, #8]
    53b8:	aa1303e0 	mov	x0, x19
    53bc:	cb160336 	sub	x22, x25, x22
    53c0:	910006c1 	add	x1, x22, #0x1
    53c4:	97fffed8 	bl	4f24 <fwp_tape_reserve>
    53c8:	a9420e62 	ldp	x2, x3, [x19, #32]
    53cc:	f10002ff 	cmp	x23, #0x0
    53d0:	f9401a61 	ldr	x1, [x19, #48]
    53d4:	b8367854 	str	w20, [x2, x22, lsl #2]
    53d8:	f9401e62 	ldr	x2, [x19, #56]
    53dc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    53e0:	fc367829 	str	d9, [x1, x22, lsl #3]
    53e4:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    53e8:	b8367861 	str	w1, [x3, x22, lsl #2]
    53ec:	91000737 	add	x23, x25, #0x1
    53f0:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    53f4:	92607e94 	and	x20, x20, #0xffffffff00000000
    53f8:	fc36784a 	str	d10, [x2, x22, lsl #3]
    53fc:	aa190294 	orr	x20, x20, x25
    5400:	f9000a77 	str	x23, [x19, #16]
    5404:	1e6b3929 	fsub	d9, d9, d11
    5408:	b7f81675 	tbnz	x21, #63, 56d4 <w107+0x430>
    540c:	9360febb 	asr	x27, x21, #32
    5410:	eb1a037f 	cmp	x27, x26
    5414:	540000e0 	b.eq	5430 <w107+0x18c>  // b.none
    5418:	aa1b03e0 	mov	x0, x27
    541c:	97fffc81 	bl	4620 <fwp_tape_of>
    5420:	aa0003f3 	mov	x19, x0
    5424:	f9403000 	ldr	x0, [x0, #96]
    5428:	b5fff680 	cbnz	x0, 52f8 <w107+0x54>
    542c:	f9400a77 	ldr	x23, [x19, #16]
    5430:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5434:	eb0002ff 	cmp	x23, x0
    5438:	5400114c 	b.gt	5660 <w107+0x3bc>
    543c:	eb3542ff 	cmp	x23, w21, uxtw
    5440:	540010ad 	b.le	5654 <w107+0x3b0>
    5444:	f9400676 	ldr	x22, [x19, #8]
    5448:	aa1303e0 	mov	x0, x19
    544c:	cb1602f6 	sub	x22, x23, x22
    5450:	910006c1 	add	x1, x22, #0x1
    5454:	97fffeb4 	bl	4f24 <fwp_tape_reserve>
    5458:	a9420261 	ldp	x1, x0, [x19, #32]
    545c:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    5460:	f9401a63 	ldr	x3, [x19, #48]
    5464:	b8367835 	str	w21, [x1, x22, lsl #2]
    5468:	f9401e61 	ldr	x1, [x19, #56]
    546c:	12800002 	mov	w2, #0xffffffff            	// #-1
    5470:	fc367860 	str	d0, [x3, x22, lsl #3]
    5474:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5478:	b8367802 	str	w2, [x0, x22, lsl #2]
    547c:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5480:	910006e0 	add	x0, x23, #0x1
    5484:	aa1702b7 	orr	x23, x21, x23
    5488:	fc367820 	str	d0, [x1, x22, lsl #3]
    548c:	f9000a60 	str	x0, [x19, #16]
    5490:	9360fe99 	asr	x25, x20, #32
    5494:	1e68090a 	fmul	d10, d8, d8
    5498:	eb1b033f 	cmp	x25, x27
    549c:	540000c0 	b.eq	54b4 <w107+0x210>  // b.none
    54a0:	aa1903e0 	mov	x0, x25
    54a4:	97fffc5f 	bl	4620 <fwp_tape_of>
    54a8:	aa0003f3 	mov	x19, x0
    54ac:	f9403000 	ldr	x0, [x0, #96]
    54b0:	b5fff240 	cbnz	x0, 52f8 <w107+0x54>
    54b4:	f9400a75 	ldr	x21, [x19, #16]
    54b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54bc:	eb0002bf 	cmp	x21, x0
    54c0:	54000d0c 	b.gt	5660 <w107+0x3bc>
    54c4:	eb3442bf 	cmp	x21, w20, uxtw
    54c8:	54000c6d 	b.le	5654 <w107+0x3b0>
    54cc:	f9400678 	ldr	x24, [x19, #8]
    54d0:	aa1303e0 	mov	x0, x19
    54d4:	92607e96 	and	x22, x20, #0xffffffff00000000
    54d8:	cb1802b8 	sub	x24, x21, x24
    54dc:	aa1502d6 	orr	x22, x22, x21
    54e0:	91000701 	add	x1, x24, #0x1
    54e4:	97fffe90 	bl	4f24 <fwp_tape_reserve>
    54e8:	a9420261 	ldp	x1, x0, [x19, #32]
    54ec:	f9401a62 	ldr	x2, [x19, #48]
    54f0:	b8387834 	str	w20, [x1, x24, lsl #2]
    54f4:	f9401e61 	ldr	x1, [x19, #56]
    54f8:	fc387848 	str	d8, [x2, x24, lsl #3]
    54fc:	b8387814 	str	w20, [x0, x24, lsl #2]
    5500:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5504:	9e670000 	fmov	d0, x0
    5508:	910006b4 	add	x20, x21, #0x1
    550c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5510:	9360fed8 	asr	x24, x22, #32
    5514:	f9000a74 	str	x20, [x19, #16]
    5518:	1e60094a 	fmul	d10, d10, d0
    551c:	eb19031f 	cmp	x24, x25
    5520:	540000e0 	b.eq	553c <w107+0x298>  // b.none
    5524:	aa1803e0 	mov	x0, x24
    5528:	97fffc3e 	bl	4620 <fwp_tape_of>
    552c:	aa0003f3 	mov	x19, x0
    5530:	f9403000 	ldr	x0, [x0, #96]
    5534:	b5ffee20 	cbnz	x0, 52f8 <w107+0x54>
    5538:	f9400a74 	ldr	x20, [x19, #16]
    553c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5540:	eb00029f 	cmp	x20, x0
    5544:	540008ec 	b.gt	5660 <w107+0x3bc>
    5548:	eb36429f 	cmp	x20, w22, uxtw
    554c:	5400084d 	b.le	5654 <w107+0x3b0>
    5550:	f9400675 	ldr	x21, [x19, #8]
    5554:	aa1303e0 	mov	x0, x19
    5558:	cb150295 	sub	x21, x20, x21
    555c:	910006a1 	add	x1, x21, #0x1
    5560:	97fffe71 	bl	4f24 <fwp_tape_reserve>
    5564:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5568:	9e670000 	fmov	d0, x0
    556c:	a9420261 	ldp	x1, x0, [x19, #32]
    5570:	1e690928 	fmul	d8, d9, d9
    5574:	f9401a62 	ldr	x2, [x19, #48]
    5578:	b8357836 	str	w22, [x1, x21, lsl #2]
    557c:	f9401e61 	ldr	x1, [x19, #56]
    5580:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5584:	fc357840 	str	d0, [x2, x21, lsl #3]
    5588:	12800002 	mov	w2, #0xffffffff            	// #-1
    558c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5590:	91000680 	add	x0, x20, #0x1
    5594:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5598:	aa1402d6 	orr	x22, x22, x20
    559c:	f9000a60 	str	x0, [x19, #16]
    55a0:	b10006ff 	cmn	x23, #0x1
    55a4:	540009e0 	b.eq	56e0 <w107+0x43c>  // b.none
    55a8:	9360fee0 	asr	x0, x23, #32
    55ac:	eb18001f 	cmp	x0, x24
    55b0:	540000a0 	b.eq	55c4 <w107+0x320>  // b.none
    55b4:	97fffc1b 	bl	4620 <fwp_tape_of>
    55b8:	aa0003f3 	mov	x19, x0
    55bc:	f9403000 	ldr	x0, [x0, #96]
    55c0:	b5ffe9c0 	cbnz	x0, 52f8 <w107+0x54>
    55c4:	f9400a74 	ldr	x20, [x19, #16]
    55c8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    55cc:	eb00029f 	cmp	x20, x0
    55d0:	5400048c 	b.gt	5660 <w107+0x3bc>
    55d4:	eb37429f 	cmp	x20, w23, uxtw
    55d8:	540003ed 	b.le	5654 <w107+0x3b0>
    55dc:	f9400675 	ldr	x21, [x19, #8]
    55e0:	aa1303e0 	mov	x0, x19
    55e4:	cb150295 	sub	x21, x20, x21
    55e8:	910006a1 	add	x1, x21, #0x1
    55ec:	97fffe4e 	bl	4f24 <fwp_tape_reserve>
    55f0:	a9420a61 	ldp	x1, x2, [x19, #32]
    55f4:	92607ee0 	and	x0, x23, #0xffffffff00000000
    55f8:	f9401a63 	ldr	x3, [x19, #48]
    55fc:	b8357837 	str	w23, [x1, x21, lsl #2]
    5600:	f9401e61 	ldr	x1, [x19, #56]
    5604:	aa140000 	orr	x0, x0, x20
    5608:	fc357869 	str	d9, [x3, x21, lsl #3]
    560c:	91000694 	add	x20, x20, #0x1
    5610:	b8357857 	str	w23, [x2, x21, lsl #2]
    5614:	fc357829 	str	d9, [x1, x21, lsl #3]
    5618:	f9000a74 	str	x20, [x19, #16]
    561c:	1e6a2908 	fadd	d8, d8, d10
    5620:	aa1603e1 	mov	x1, x22
    5624:	97fffecf 	bl	5160 <f128.constprop.0>
    5628:	aa0003e1 	mov	x1, x0
    562c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5630:	9e660100 	fmov	x0, d8
    5634:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5638:	a94363f7 	ldp	x23, x24, [sp, #48]
    563c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5640:	f9402bfb 	ldr	x27, [sp, #80]
    5644:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5648:	6d472fea 	ldp	d10, d11, [sp, #112]
    564c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5650:	d65f03c0 	ret
    5654:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    5658:	912f6000 	add	x0, x0, #0xbd8
    565c:	97fff9ed 	bl	3e10 <fwp_trap>
    5660:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    5664:	912d0000 	add	x0, x0, #0xb40
    5668:	97fff9ea 	bl	3e10 <fwp_trap>
    566c:	1e693828 	fsub	d8, d1, d9
    5670:	b6f801c1 	tbz	x1, #63, 56a8 <w107+0x404>
    5674:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5678:	1e68090a 	fmul	d10, d8, d8
    567c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5680:	9e670000 	fmov	d0, x0
    5684:	1e6b3828 	fsub	d8, d1, d11
    5688:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    568c:	aa1603e0 	mov	x0, x22
    5690:	1e60094a 	fmul	d10, d10, d0
    5694:	1e680908 	fmul	d8, d8, d8
    5698:	17ffffe1 	b	561c <w107+0x378>
    569c:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    56a0:	912d8000 	add	x0, x0, #0xb60
    56a4:	97fff9db 	bl	3e10 <fwp_trap>
    56a8:	2f00e40a 	movi	d10, #0x0
    56ac:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    56b0:	9360fc3a 	asr	x26, x1, #32
    56b4:	aa0103f4 	mov	x20, x1
    56b8:	aa1a03e0 	mov	x0, x26
    56bc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    56c0:	97fffbd8 	bl	4620 <fwp_tape_of>
    56c4:	aa0003f3 	mov	x19, x0
    56c8:	f9403000 	ldr	x0, [x0, #96]
    56cc:	b5ffe160 	cbnz	x0, 52f8 <w107+0x54>
    56d0:	17ffff30 	b	5390 <w107+0xec>
    56d4:	aa1a03fb 	mov	x27, x26
    56d8:	aa0003f7 	mov	x23, x0
    56dc:	17ffff6d 	b	5490 <w107+0x1ec>
    56e0:	aa1703e0 	mov	x0, x23
    56e4:	17ffffce 	b	561c <w107+0x378>
    56e8:	d503201f 	nop
    56ec:	d503201f 	nop

00000000000056f0 <fwp_data.part.0.constprop.0>:
    56f0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    56f4:	910003fd 	mov	x29, sp
    56f8:	a90153f3 	stp	x19, x20, [sp, #16]
    56fc:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc90>
    5700:	91154283 	add	x3, x20, #0x550
    5704:	a9025bf5 	stp	x21, x22, [sp, #32]
    5708:	aa0103f5 	mov	x21, x1
    570c:	b953a461 	ldr	w1, [x3, #5028]
    5710:	a90363f7 	stp	x23, x24, [sp, #48]
    5714:	2a0003f8 	mov	w24, w0
    5718:	34000701 	cbz	w1, 57f8 <fwp_data.part.0.constprop.0+0x108>
    571c:	397e8862 	ldrb	w2, [x3, #4002]
    5720:	910f0040 	add	x0, x2, #0x3c0
    5724:	8b020442 	add	x2, x2, x2, lsl #1
    5728:	d37df042 	lsl	x2, x2, #3
    572c:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    5730:	2a1703f6 	mov	w22, w23
    5734:	f8626873 	ldr	x19, [x3, x2]
    5738:	b40004d3 	cbz	x19, 57d0 <fwp_data.part.0.constprop.0+0xe0>
    573c:	f9400260 	ldr	x0, [x19]
    5740:	aa2003e0 	mvn	x0, x0
    5744:	f8226860 	str	x0, [x3, x2]
    5748:	f10062df 	cmp	x22, #0x18
    574c:	540000e9 	b.ls	5768 <fwp_data.part.0.constprop.0+0x78>  // b.plast
    5750:	d10066c2 	sub	x2, x22, #0x19
    5754:	91006260 	add	x0, x19, #0x18
    5758:	927df042 	and	x2, x2, #0xfffffffffffffff8
    575c:	52800001 	mov	w1, #0x0                   	// #0
    5760:	91002042 	add	x2, x2, #0x8
    5764:	97fff417 	bl	27c0 <memset@plt>
    5768:	91154282 	add	x2, x20, #0x550
    576c:	f94a1041 	ldr	x1, [x2, #5152]
    5770:	ab160021 	adds	x1, x1, x22
    5774:	540004c2 	b.cs	580c <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    5778:	f94a1440 	ldr	x0, [x2, #5160]
    577c:	f90a1041 	str	x1, [x2, #5152]
    5780:	eb00003f 	cmp	x1, x0
    5784:	54000049 	b.ls	578c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5788:	f90a1441 	str	x1, [x2, #5160]
    578c:	91154294 	add	x20, x20, #0x550
    5790:	1e6302e1 	ucvtf	d1, w23
    5794:	fd4a1e80 	ldr	d0, [x20, #5176]
    5798:	1e612800 	fadd	d0, d0, d1
    579c:	fd0a1e80 	str	d0, [x20, #5176]
    57a0:	52800041 	mov	w1, #0x2                   	// #2
    57a4:	29000678 	stp	w24, w1, [x19]
    57a8:	aa1303e0 	mov	x0, x19
    57ac:	f94002a1 	ldr	x1, [x21]
    57b0:	f9000661 	str	x1, [x19, #8]
    57b4:	f94006a1 	ldr	x1, [x21, #8]
    57b8:	f9000a61 	str	x1, [x19, #16]
    57bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    57c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    57c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    57c8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    57cc:	d65f03c0 	ret
    57d0:	8b020063 	add	x3, x3, x2
    57d4:	f9400473 	ldr	x19, [x3, #8]
    57d8:	b4000113 	cbz	x19, 57f8 <fwp_data.part.0.constprop.0+0x108>
    57dc:	f9400860 	ldr	x0, [x3, #16]
    57e0:	cb130000 	sub	x0, x0, x19
    57e4:	eb0002df 	cmp	x22, x0
    57e8:	54000088 	b.hi	57f8 <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    57ec:	8b160260 	add	x0, x19, x22
    57f0:	f9000460 	str	x0, [x3, #8]
    57f4:	17ffffd5 	b	5748 <fwp_data.part.0.constprop.0+0x58>
    57f8:	52800001 	mov	w1, #0x0                   	// #0
    57fc:	d2800300 	mov	x0, #0x18                  	// #24
    5800:	97fffcfc 	bl	4bf0 <fwp_heap_alloc>
    5804:	aa0003f3 	mov	x19, x0
    5808:	17ffffe6 	b	57a0 <fwp_data.part.0.constprop.0+0xb0>
    580c:	97fff5e9 	bl	2fb0 <fwp_heap_oom>

0000000000005810 <fwp_rc_share>:
    5810:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    5814:	91154042 	add	x2, x2, #0x550
    5818:	f949d843 	ldr	x3, [x2, #5040]
    581c:	f949ec41 	ldr	x1, [x2, #5080]
    5820:	cb030000 	sub	x0, x0, x3
    5824:	eb01401f 	cmp	x0, x1, lsl #16
    5828:	540003a2 	b.cs	589c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    582c:	d350fc01 	lsr	x1, x0, #16
    5830:	f949fc44 	ldr	x4, [x2, #5112]
    5834:	8b010821 	add	x1, x1, x1, lsl #2
    5838:	d37df021 	lsl	x1, x1, #3
    583c:	8b010083 	add	x3, x4, x1
    5840:	f9401062 	ldr	x2, [x3, #32]
    5844:	b40002c2 	cbz	x2, 589c <fwp_rc_share+0x8c>
    5848:	38616881 	ldrb	w1, [x4, x1]
    584c:	7100083f 	cmp	w1, #0x2
    5850:	54000220 	b.eq	5894 <fwp_rc_share+0x84>  // b.none
    5854:	7100043f 	cmp	w1, #0x1
    5858:	54000221 	b.ne	589c <fwp_rc_share+0x8c>  // b.any
    585c:	29430464 	ldp	w4, w1, [x3, #24]
    5860:	92403c00 	and	x0, x0, #0xffff
    5864:	9b047c00 	mul	x0, x0, x4
    5868:	d360fc00 	lsr	x0, x0, #32
    586c:	eb01001f 	cmp	x0, x1
    5870:	54000162 	b.cs	589c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5874:	8b000042 	add	x2, x2, x0
    5878:	39400040 	ldrb	w0, [x2]
    587c:	34000100 	cbz	w0, 589c <fwp_rc_share+0x8c>
    5880:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5884:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    5888:	912fe000 	add	x0, x0, #0xbf8
    588c:	910003fd 	mov	x29, sp
    5890:	97fff960 	bl	3e10 <fwp_trap>
    5894:	72003c1f 	tst	w0, #0xffff
    5898:	54ffff00 	b.eq	5878 <fwp_rc_share+0x68>  // b.none
    589c:	d65f03c0 	ret

00000000000058a0 <fwp_rc_free_arr>:
    58a0:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc90>
    58a4:	91154063 	add	x3, x3, #0x550
    58a8:	f949d861 	ldr	x1, [x3, #5040]
    58ac:	f949ec62 	ldr	x2, [x3, #5080]
    58b0:	cb010001 	sub	x1, x0, x1
    58b4:	eb02403f 	cmp	x1, x2, lsl #16
    58b8:	54000342 	b.cs	5920 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    58bc:	d350fc22 	lsr	x2, x1, #16
    58c0:	f949fc65 	ldr	x5, [x3, #5112]
    58c4:	8b020842 	add	x2, x2, x2, lsl #2
    58c8:	d37df042 	lsl	x2, x2, #3
    58cc:	8b0200a4 	add	x4, x5, x2
    58d0:	f9401083 	ldr	x3, [x4, #32]
    58d4:	b4000263 	cbz	x3, 5920 <fwp_rc_free_arr+0x80>
    58d8:	386268a2 	ldrb	w2, [x5, x2]
    58dc:	7100085f 	cmp	w2, #0x2
    58e0:	540001c0 	b.eq	5918 <fwp_rc_free_arr+0x78>  // b.none
    58e4:	7100045f 	cmp	w2, #0x1
    58e8:	540001c1 	b.ne	5920 <fwp_rc_free_arr+0x80>  // b.any
    58ec:	29430885 	ldp	w5, w2, [x4, #24]
    58f0:	92403c21 	and	x1, x1, #0xffff
    58f4:	9b057c21 	mul	x1, x1, x5
    58f8:	d360fc21 	lsr	x1, x1, #32
    58fc:	eb02003f 	cmp	x1, x2
    5900:	54000102 	b.cs	5920 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5904:	8b010063 	add	x3, x3, x1
    5908:	39400061 	ldrb	w1, [x3]
    590c:	7100043f 	cmp	w1, #0x1
    5910:	54000081 	b.ne	5920 <fwp_rc_free_arr+0x80>  // b.any
    5914:	17fff9fb 	b	4100 <fwp_mem_free>
    5918:	72003c3f 	tst	w1, #0xffff
    591c:	54ffff60 	b.eq	5908 <fwp_rc_free_arr+0x68>  // b.none
    5920:	d65f03c0 	ret

0000000000005924 <fwp_rc_dup>:
    5924:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc90>
    5928:	91154042 	add	x2, x2, #0x550
    592c:	f949d841 	ldr	x1, [x2, #5040]
    5930:	f949ec43 	ldr	x3, [x2, #5080]
    5934:	cb010001 	sub	x1, x0, x1
    5938:	eb03403f 	cmp	x1, x3, lsl #16
    593c:	54000342 	b.cs	59a4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5940:	d350fc20 	lsr	x0, x1, #16
    5944:	f949fc44 	ldr	x4, [x2, #5112]
    5948:	8b000800 	add	x0, x0, x0, lsl #2
    594c:	d37df002 	lsl	x2, x0, #3
    5950:	8b020083 	add	x3, x4, x2
    5954:	f9401060 	ldr	x0, [x3, #32]
    5958:	b4000260 	cbz	x0, 59a4 <fwp_rc_dup+0x80>
    595c:	38626882 	ldrb	w2, [x4, x2]
    5960:	7100085f 	cmp	w2, #0x2
    5964:	54000220 	b.eq	59a8 <fwp_rc_dup+0x84>  // b.none
    5968:	7100045f 	cmp	w2, #0x1
    596c:	540001c1 	b.ne	59a4 <fwp_rc_dup+0x80>  // b.any
    5970:	29430864 	ldp	w4, w2, [x3, #24]
    5974:	92403c21 	and	x1, x1, #0xffff
    5978:	9b047c21 	mul	x1, x1, x4
    597c:	d360fc21 	lsr	x1, x1, #32
    5980:	eb02003f 	cmp	x1, x2
    5984:	54000102 	b.cs	59a4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5988:	8b010000 	add	x0, x0, x1
    598c:	39400001 	ldrb	w1, [x0]
    5990:	340000a1 	cbz	w1, 59a4 <fwp_rc_dup+0x80>
    5994:	7103f43f 	cmp	w1, #0xfd
    5998:	540000e8 	b.hi	59b4 <fwp_rc_dup+0x90>  // b.pmore
    599c:	11000421 	add	w1, w1, #0x1
    59a0:	39000001 	strb	w1, [x0]
    59a4:	d65f03c0 	ret
    59a8:	72003c3f 	tst	w1, #0xffff
    59ac:	54ffff00 	b.eq	598c <fwp_rc_dup+0x68>  // b.none
    59b0:	d65f03c0 	ret
    59b4:	17fffa4c 	b	42e4 <fwp_rc_wide_dup>
    59b8:	d503201f 	nop
    59bc:	d503201f 	nop

00000000000059c0 <fwp_drop1>:
    59c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    59c4:	910003fd 	mov	x29, sp
    59c8:	a90153f3 	stp	x19, x20, [sp, #16]
    59cc:	f90013f5 	str	x21, [sp, #32]
    59d0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    59d4:	911542b4 	add	x20, x21, #0x550
    59d8:	f949da81 	ldr	x1, [x20, #5040]
    59dc:	f949ee82 	ldr	x2, [x20, #5080]
    59e0:	cb010001 	sub	x1, x0, x1
    59e4:	eb02403f 	cmp	x1, x2, lsl #16
    59e8:	54000382 	b.cs	5a58 <fwp_drop1+0x98>  // b.hs, b.nlast
    59ec:	d350fc22 	lsr	x2, x1, #16
    59f0:	f949fe84 	ldr	x4, [x20, #5112]
    59f4:	8b020842 	add	x2, x2, x2, lsl #2
    59f8:	d37df042 	lsl	x2, x2, #3
    59fc:	8b020083 	add	x3, x4, x2
    5a00:	f9401073 	ldr	x19, [x3, #32]
    5a04:	b40002b3 	cbz	x19, 5a58 <fwp_drop1+0x98>
    5a08:	38626882 	ldrb	w2, [x4, x2]
    5a0c:	7100085f 	cmp	w2, #0x2
    5a10:	540002c0 	b.eq	5a68 <fwp_drop1+0xa8>  // b.none
    5a14:	7100045f 	cmp	w2, #0x1
    5a18:	54000201 	b.ne	5a58 <fwp_drop1+0x98>  // b.any
    5a1c:	29430864 	ldp	w4, w2, [x3, #24]
    5a20:	92403c21 	and	x1, x1, #0xffff
    5a24:	9b047c21 	mul	x1, x1, x4
    5a28:	d360fc21 	lsr	x1, x1, #32
    5a2c:	eb02003f 	cmp	x1, x2
    5a30:	54000142 	b.cs	5a58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5a34:	8b010273 	add	x19, x19, x1
    5a38:	39400261 	ldrb	w1, [x19]
    5a3c:	340000e1 	cbz	w1, 5a58 <fwp_drop1+0x98>
    5a40:	7100043f 	cmp	w1, #0x1
    5a44:	540001e0 	b.eq	5a80 <fwp_drop1+0xc0>  // b.none
    5a48:	7103fc3f 	cmp	w1, #0xff
    5a4c:	540002e0 	b.eq	5aa8 <fwp_drop1+0xe8>  // b.none
    5a50:	51000421 	sub	w1, w1, #0x1
    5a54:	39000261 	strb	w1, [x19]
    5a58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a5c:	f94013f5 	ldr	x21, [sp, #32]
    5a60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a64:	d65f03c0 	ret
    5a68:	72003c3f 	tst	w1, #0xffff
    5a6c:	54fffe60 	b.eq	5a38 <fwp_drop1+0x78>  // b.none
    5a70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a74:	f94013f5 	ldr	x21, [sp, #32]
    5a78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5a7c:	d65f03c0 	ret
    5a80:	f9400813 	ldr	x19, [x0, #16]
    5a84:	97ffff87 	bl	58a0 <fwp_rc_free_arr>
    5a88:	911542a0 	add	x0, x21, #0x550
    5a8c:	f949d801 	ldr	x1, [x0, #5040]
    5a90:	f949ec00 	ldr	x0, [x0, #5080]
    5a94:	cb010261 	sub	x1, x19, x1
    5a98:	eb00403f 	cmp	x1, x0, lsl #16
    5a9c:	54fffde2 	b.cs	5a58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5aa0:	aa1303e0 	mov	x0, x19
    5aa4:	17ffffd2 	b	59ec <fwp_drop1+0x2c>
    5aa8:	ca534660 	eor	x0, x19, x19, lsr #17
    5aac:	911542b5 	add	x21, x21, #0x550
    5ab0:	ca402400 	eor	x0, x0, x0, lsr #9
    5ab4:	92401c00 	and	x0, x0, #0xff
    5ab8:	910a2402 	add	x2, x0, #0x289
    5abc:	8b000ea0 	add	x0, x21, x0, lsl #3
    5ac0:	8b020ea2 	add	x2, x21, x2, lsl #3
    5ac4:	f94a2400 	ldr	x0, [x0, #5192]
    5ac8:	b50000a0 	cbnz	x0, 5adc <fwp_drop1+0x11c>
    5acc:	14000013 	b	5b18 <fwp_drop1+0x158>
    5ad0:	91004002 	add	x2, x0, #0x10
    5ad4:	f9400800 	ldr	x0, [x0, #16]
    5ad8:	b4000200 	cbz	x0, 5b18 <fwp_drop1+0x158>
    5adc:	f9400001 	ldr	x1, [x0]
    5ae0:	eb13003f 	cmp	x1, x19
    5ae4:	54ffff61 	b.ne	5ad0 <fwp_drop1+0x110>  // b.any
    5ae8:	f9400041 	ldr	x1, [x2]
    5aec:	f9400420 	ldr	x0, [x1, #8]
    5af0:	d1000400 	sub	x0, x0, #0x1
    5af4:	f9000420 	str	x0, [x1, #8]
    5af8:	f103f81f 	cmp	x0, #0xfe
    5afc:	54fffae1 	b.ne	5a58 <fwp_drop1+0x98>  // b.any
    5b00:	39400260 	ldrb	w0, [x19]
    5b04:	7103fc1f 	cmp	w0, #0xff
    5b08:	540000e0 	b.eq	5b24 <fwp_drop1+0x164>  // b.none
    5b0c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5b10:	39000260 	strb	w0, [x19]
    5b14:	17ffffd1 	b	5a58 <fwp_drop1+0x98>
    5b18:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    5b1c:	91264000 	add	x0, x0, #0x990
    5b20:	97fff8bc 	bl	3e10 <fwp_trap>
    5b24:	aa1303e0 	mov	x0, x19
    5b28:	97fff8da 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5b2c:	17fffff8 	b	5b0c <fwp_drop1+0x14c>

0000000000005b30 <fwp_drop0>:
    5b30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b34:	910003fd 	mov	x29, sp
    5b38:	a90153f3 	stp	x19, x20, [sp, #16]
    5b3c:	f90013f5 	str	x21, [sp, #32]
    5b40:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc90>
    5b44:	911542b4 	add	x20, x21, #0x550
    5b48:	f949da81 	ldr	x1, [x20, #5040]
    5b4c:	f949ee82 	ldr	x2, [x20, #5080]
    5b50:	cb010001 	sub	x1, x0, x1
    5b54:	eb02403f 	cmp	x1, x2, lsl #16
    5b58:	54000382 	b.cs	5bc8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b5c:	d350fc22 	lsr	x2, x1, #16
    5b60:	f949fe84 	ldr	x4, [x20, #5112]
    5b64:	8b020842 	add	x2, x2, x2, lsl #2
    5b68:	d37df042 	lsl	x2, x2, #3
    5b6c:	8b020083 	add	x3, x4, x2
    5b70:	f9401073 	ldr	x19, [x3, #32]
    5b74:	b40002b3 	cbz	x19, 5bc8 <fwp_drop0+0x98>
    5b78:	38626882 	ldrb	w2, [x4, x2]
    5b7c:	7100085f 	cmp	w2, #0x2
    5b80:	540002c0 	b.eq	5bd8 <fwp_drop0+0xa8>  // b.none
    5b84:	7100045f 	cmp	w2, #0x1
    5b88:	54000201 	b.ne	5bc8 <fwp_drop0+0x98>  // b.any
    5b8c:	29430864 	ldp	w4, w2, [x3, #24]
    5b90:	92403c21 	and	x1, x1, #0xffff
    5b94:	9b047c21 	mul	x1, x1, x4
    5b98:	d360fc21 	lsr	x1, x1, #32
    5b9c:	eb02003f 	cmp	x1, x2
    5ba0:	54000142 	b.cs	5bc8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ba4:	8b010273 	add	x19, x19, x1
    5ba8:	39400261 	ldrb	w1, [x19]
    5bac:	340000e1 	cbz	w1, 5bc8 <fwp_drop0+0x98>
    5bb0:	7100043f 	cmp	w1, #0x1
    5bb4:	540001e0 	b.eq	5bf0 <fwp_drop0+0xc0>  // b.none
    5bb8:	7103fc3f 	cmp	w1, #0xff
    5bbc:	540002e0 	b.eq	5c18 <fwp_drop0+0xe8>  // b.none
    5bc0:	51000421 	sub	w1, w1, #0x1
    5bc4:	39000261 	strb	w1, [x19]
    5bc8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bcc:	f94013f5 	ldr	x21, [sp, #32]
    5bd0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5bd4:	d65f03c0 	ret
    5bd8:	72003c3f 	tst	w1, #0xffff
    5bdc:	54fffe60 	b.eq	5ba8 <fwp_drop0+0x78>  // b.none
    5be0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5be4:	f94013f5 	ldr	x21, [sp, #32]
    5be8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5bec:	d65f03c0 	ret
    5bf0:	f9400813 	ldr	x19, [x0, #16]
    5bf4:	97ffff2b 	bl	58a0 <fwp_rc_free_arr>
    5bf8:	911542a0 	add	x0, x21, #0x550
    5bfc:	f949d801 	ldr	x1, [x0, #5040]
    5c00:	f949ec00 	ldr	x0, [x0, #5080]
    5c04:	cb010261 	sub	x1, x19, x1
    5c08:	eb00403f 	cmp	x1, x0, lsl #16
    5c0c:	54fffde2 	b.cs	5bc8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5c10:	aa1303e0 	mov	x0, x19
    5c14:	17ffffd2 	b	5b5c <fwp_drop0+0x2c>
    5c18:	ca534660 	eor	x0, x19, x19, lsr #17
    5c1c:	911542b5 	add	x21, x21, #0x550
    5c20:	ca402400 	eor	x0, x0, x0, lsr #9
    5c24:	92401c00 	and	x0, x0, #0xff
    5c28:	910a2402 	add	x2, x0, #0x289
    5c2c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5c30:	8b020ea2 	add	x2, x21, x2, lsl #3
    5c34:	f94a2400 	ldr	x0, [x0, #5192]
    5c38:	b50000a0 	cbnz	x0, 5c4c <fwp_drop0+0x11c>
    5c3c:	14000013 	b	5c88 <fwp_drop0+0x158>
    5c40:	91004002 	add	x2, x0, #0x10
    5c44:	f9400800 	ldr	x0, [x0, #16]
    5c48:	b4000200 	cbz	x0, 5c88 <fwp_drop0+0x158>
    5c4c:	f9400001 	ldr	x1, [x0]
    5c50:	eb13003f 	cmp	x1, x19
    5c54:	54ffff61 	b.ne	5c40 <fwp_drop0+0x110>  // b.any
    5c58:	f9400041 	ldr	x1, [x2]
    5c5c:	f9400420 	ldr	x0, [x1, #8]
    5c60:	d1000400 	sub	x0, x0, #0x1
    5c64:	f9000420 	str	x0, [x1, #8]
    5c68:	f103f81f 	cmp	x0, #0xfe
    5c6c:	54fffae1 	b.ne	5bc8 <fwp_drop0+0x98>  // b.any
    5c70:	39400260 	ldrb	w0, [x19]
    5c74:	7103fc1f 	cmp	w0, #0xff
    5c78:	540000e0 	b.eq	5c94 <fwp_drop0+0x164>  // b.none
    5c7c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c80:	39000260 	strb	w0, [x19]
    5c84:	17ffffd1 	b	5bc8 <fwp_drop0+0x98>
    5c88:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    5c8c:	91264000 	add	x0, x0, #0x990
    5c90:	97fff860 	bl	3e10 <fwp_trap>
    5c94:	aa1303e0 	mov	x0, x19
    5c98:	97fff87e 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5c9c:	17fffff8 	b	5c7c <fwp_drop0+0x14c>

0000000000005ca0 <fwp_arg_drop12>:
    5ca0:	7100003f 	cmp	w1, #0x0
    5ca4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    5ca8:	54000041 	b.ne	5cb0 <fwp_arg_drop12+0x10>  // b.any
    5cac:	d65f03c0 	ret
    5cb0:	f9400000 	ldr	x0, [x0]
    5cb4:	17ffff9f 	b	5b30 <fwp_drop0>
    5cb8:	d503201f 	nop
    5cbc:	d503201f 	nop

0000000000005cc0 <fwp_closure_drop>:
    5cc0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xc90>
    5cc4:	911540a4 	add	x4, x5, #0x550
    5cc8:	aa0003e1 	mov	x1, x0
    5ccc:	f949d882 	ldr	x2, [x4, #5040]
    5cd0:	f949ec80 	ldr	x0, [x4, #5080]
    5cd4:	cb020022 	sub	x2, x1, x2
    5cd8:	eb00405f 	cmp	x2, x0, lsl #16
    5cdc:	54000662 	b.cs	5da8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5ce0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5ce4:	d350fc43 	lsr	x3, x2, #16
    5ce8:	910003fd 	mov	x29, sp
    5cec:	8b030863 	add	x3, x3, x3, lsl #2
    5cf0:	f949fc84 	ldr	x4, [x4, #5112]
    5cf4:	d37df063 	lsl	x3, x3, #3
    5cf8:	f9000bf3 	str	x19, [sp, #16]
    5cfc:	8b030080 	add	x0, x4, x3
    5d00:	f9401013 	ldr	x19, [x0, #32]
    5d04:	b40002b3 	cbz	x19, 5d58 <fwp_closure_drop+0x98>
    5d08:	38636883 	ldrb	w3, [x4, x3]
    5d0c:	7100087f 	cmp	w3, #0x2
    5d10:	54000420 	b.eq	5d94 <fwp_closure_drop+0xd4>  // b.none
    5d14:	7100047f 	cmp	w3, #0x1
    5d18:	54000201 	b.ne	5d58 <fwp_closure_drop+0x98>  // b.any
    5d1c:	29430003 	ldp	w3, w0, [x0, #24]
    5d20:	92403c42 	and	x2, x2, #0xffff
    5d24:	9b037c42 	mul	x2, x2, x3
    5d28:	d360fc42 	lsr	x2, x2, #32
    5d2c:	eb00005f 	cmp	x2, x0
    5d30:	54000142 	b.cs	5d58 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5d34:	8b020273 	add	x19, x19, x2
    5d38:	39400260 	ldrb	w0, [x19]
    5d3c:	340000e0 	cbz	w0, 5d58 <fwp_closure_drop+0x98>
    5d40:	7100041f 	cmp	w0, #0x1
    5d44:	54000100 	b.eq	5d64 <fwp_closure_drop+0xa4>  // b.none
    5d48:	7103fc1f 	cmp	w0, #0xff
    5d4c:	54000300 	b.eq	5dac <fwp_closure_drop+0xec>  // b.none
    5d50:	51000400 	sub	w0, w0, #0x1
    5d54:	39000260 	strb	w0, [x19]
    5d58:	f9400bf3 	ldr	x19, [sp, #16]
    5d5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d60:	d65f03c0 	ret
    5d64:	d53bd040 	mrs	x0, tpidr_el0
    5d68:	91400000 	add	x0, x0, #0x0, lsl #12
    5d6c:	91004000 	add	x0, x0, #0x10
    5d70:	f9400000 	ldr	x0, [x0]
    5d74:	b4000080 	cbz	x0, 5d84 <fwp_closure_drop+0xc4>
    5d78:	f9400bf3 	ldr	x19, [sp, #16]
    5d7c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d80:	17fff9a0 	b	4400 <fwp_closure_drop_push>
    5d84:	f9400bf3 	ldr	x19, [sp, #16]
    5d88:	aa0103e0 	mov	x0, x1
    5d8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d90:	17fff9e1 	b	4514 <fwp_closure_drop.part.0>
    5d94:	72003c5f 	tst	w2, #0xffff
    5d98:	54fffd00 	b.eq	5d38 <fwp_closure_drop+0x78>  // b.none
    5d9c:	f9400bf3 	ldr	x19, [sp, #16]
    5da0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5da4:	d65f03c0 	ret
    5da8:	d65f03c0 	ret
    5dac:	ca534660 	eor	x0, x19, x19, lsr #17
    5db0:	911540a5 	add	x5, x5, #0x550
    5db4:	ca402400 	eor	x0, x0, x0, lsr #9
    5db8:	92401c00 	and	x0, x0, #0xff
    5dbc:	910a2402 	add	x2, x0, #0x289
    5dc0:	8b000ca0 	add	x0, x5, x0, lsl #3
    5dc4:	8b020ca2 	add	x2, x5, x2, lsl #3
    5dc8:	f94a2400 	ldr	x0, [x0, #5192]
    5dcc:	b50000a0 	cbnz	x0, 5de0 <fwp_closure_drop+0x120>
    5dd0:	14000013 	b	5e1c <fwp_closure_drop+0x15c>
    5dd4:	91004002 	add	x2, x0, #0x10
    5dd8:	f9400800 	ldr	x0, [x0, #16]
    5ddc:	b4000200 	cbz	x0, 5e1c <fwp_closure_drop+0x15c>
    5de0:	f9400001 	ldr	x1, [x0]
    5de4:	eb13003f 	cmp	x1, x19
    5de8:	54ffff61 	b.ne	5dd4 <fwp_closure_drop+0x114>  // b.any
    5dec:	f9400041 	ldr	x1, [x2]
    5df0:	f9400420 	ldr	x0, [x1, #8]
    5df4:	d1000400 	sub	x0, x0, #0x1
    5df8:	f9000420 	str	x0, [x1, #8]
    5dfc:	f103f81f 	cmp	x0, #0xfe
    5e00:	54fffac1 	b.ne	5d58 <fwp_closure_drop+0x98>  // b.any
    5e04:	39400260 	ldrb	w0, [x19]
    5e08:	7103fc1f 	cmp	w0, #0xff
    5e0c:	540000e0 	b.eq	5e28 <fwp_closure_drop+0x168>  // b.none
    5e10:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e14:	39000260 	strb	w0, [x19]
    5e18:	17ffffd0 	b	5d58 <fwp_closure_drop+0x98>
    5e1c:	d0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    5e20:	91264000 	add	x0, x0, #0x990
    5e24:	97fff7fb 	bl	3e10 <fwp_trap>
    5e28:	aa1303e0 	mov	x0, x19
    5e2c:	97fff819 	bl	3e90 <fwp_rc_forget_slot.part.0>
    5e30:	17fffff8 	b	5e10 <fwp_closure_drop+0x150>

0000000000005e34 <fwp_owned_tape_release>:
    5e34:	b4000920 	cbz	x0, 5f58 <fwp_owned_tape_release+0x124>
    5e38:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e3c:	910003fd 	mov	x29, sp
    5e40:	a90153f3 	stp	x19, x20, [sp, #16]
    5e44:	aa0003f3 	mov	x19, x0
    5e48:	f9400000 	ldr	x0, [x0]
    5e4c:	b4000060 	cbz	x0, 5e58 <fwp_owned_tape_release+0x24>
    5e50:	f9400661 	ldr	x1, [x19, #8]
    5e54:	f9000401 	str	x1, [x0, #8]
    5e58:	f9400661 	ldr	x1, [x19, #8]
    5e5c:	b4000041 	cbz	x1, 5e64 <fwp_owned_tape_release+0x30>
    5e60:	f9000020 	str	x0, [x1]
    5e64:	f9400a60 	ldr	x0, [x19, #16]
    5e68:	f9403401 	ldr	x1, [x0, #104]
    5e6c:	b40005a1 	cbz	x1, 5f20 <fwp_owned_tape_release+0xec>
    5e70:	a9450a60 	ldp	x0, x2, [x19, #80]
    5e74:	eb00005f 	cmp	x2, x0
    5e78:	540002cd 	b.le	5ed0 <fwp_owned_tape_release+0x9c>
    5e7c:	d2800014 	mov	x20, #0x0                   	// #0
    5e80:	f90013f5 	str	x21, [sp, #32]
    5e84:	d2800015 	mov	x21, #0x0                   	// #0
    5e88:	f9402260 	ldr	x0, [x19, #64]
    5e8c:	910006b5 	add	x21, x21, #0x1
    5e90:	f8746800 	ldr	x0, [x0, x20]
    5e94:	d63f0020 	blr	x1
    5e98:	f9402260 	ldr	x0, [x19, #64]
    5e9c:	f9400a61 	ldr	x1, [x19, #16]
    5ea0:	8b140000 	add	x0, x0, x20
    5ea4:	91004294 	add	x20, x20, #0x10
    5ea8:	f9400400 	ldr	x0, [x0, #8]
    5eac:	f9403421 	ldr	x1, [x1, #104]
    5eb0:	d63f0020 	blr	x1
    5eb4:	a9450261 	ldp	x1, x0, [x19, #80]
    5eb8:	cb010000 	sub	x0, x0, x1
    5ebc:	eb15001f 	cmp	x0, x21
    5ec0:	f9400a60 	ldr	x0, [x19, #16]
    5ec4:	f9403401 	ldr	x1, [x0, #104]
    5ec8:	54fffe0c 	b.gt	5e88 <fwp_owned_tape_release+0x54>
    5ecc:	f94013f5 	ldr	x21, [sp, #32]
    5ed0:	f9403663 	ldr	x3, [x19, #104]
    5ed4:	f9401262 	ldr	x2, [x19, #32]
    5ed8:	f100007f 	cmp	x3, #0x0
    5edc:	540001ed 	b.le	5f18 <fwp_owned_tape_release+0xe4>
    5ee0:	d2800014 	mov	x20, #0x0                   	// #0
    5ee4:	d503201f 	nop
    5ee8:	f9402660 	ldr	x0, [x19, #72]
    5eec:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5ef0:	eb02001f 	cmp	x0, x2
    5ef4:	540000c0 	b.eq	5f0c <fwp_owned_tape_release+0xd8>  // b.none
    5ef8:	d63f0020 	blr	x1
    5efc:	f9400a60 	ldr	x0, [x19, #16]
    5f00:	f9401262 	ldr	x2, [x19, #32]
    5f04:	f9403663 	ldr	x3, [x19, #104]
    5f08:	f9403401 	ldr	x1, [x0, #104]
    5f0c:	91000694 	add	x20, x20, #0x1
    5f10:	eb14007f 	cmp	x3, x20
    5f14:	54fffeac 	b.gt	5ee8 <fwp_owned_tape_release+0xb4>
    5f18:	aa0203e0 	mov	x0, x2
    5f1c:	d63f0020 	blr	x1
    5f20:	f9401660 	ldr	x0, [x19, #40]
    5f24:	97ffff67 	bl	5cc0 <fwp_closure_drop>
    5f28:	f9401a60 	ldr	x0, [x19, #48]
    5f2c:	97ffff65 	bl	5cc0 <fwp_closure_drop>
    5f30:	f9401e60 	ldr	x0, [x19, #56]
    5f34:	97ffff63 	bl	5cc0 <fwp_closure_drop>
    5f38:	f9402260 	ldr	x0, [x19, #64]
    5f3c:	97fff871 	bl	4100 <fwp_mem_free>
    5f40:	f9402660 	ldr	x0, [x19, #72]
    5f44:	97fff86f 	bl	4100 <fwp_mem_free>
    5f48:	aa1303e0 	mov	x0, x19
    5f4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f50:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f54:	17fff86b 	b	4100 <fwp_mem_free>
    5f58:	d65f03c0 	ret
    5f5c:	d503201f 	nop

0000000000005f60 <fwp_tape_finish>:
    5f60:	d10203ff 	sub	sp, sp, #0x80
    5f64:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    5f68:	f947f421 	ldr	x1, [x1, #4072]
    5f6c:	a9047bfd 	stp	x29, x30, [sp, #64]
    5f70:	910103fd 	add	x29, sp, #0x40
    5f74:	a90553f3 	stp	x19, x20, [sp, #80]
    5f78:	a9065bf5 	stp	x21, x22, [sp, #96]
    5f7c:	a90763f7 	stp	x23, x24, [sp, #112]
    5f80:	f00000d8 	adrp	x24, 20000 <__data_start>
    5f84:	91010316 	add	x22, x24, #0x40
    5f88:	f9400022 	ldr	x2, [x1]
    5f8c:	f9001fe2 	str	x2, [sp, #56]
    5f90:	d2800002 	mov	x2, #0x0                   	// #0
    5f94:	9100e2c0 	add	x0, x22, #0x38
    5f98:	97fff4ba 	bl	3280 <fwp_tape_buffers_dispose>
    5f9c:	f9003adf 	str	xzr, [x22, #112]
    5fa0:	f94042c0 	ldr	x0, [x22, #128]
    5fa4:	f100001f 	cmp	x0, #0x0
    5fa8:	5400030d 	b.le	6008 <fwp_tape_finish+0xa8>
    5fac:	910003f7 	mov	x23, sp
    5fb0:	d2800015 	mov	x21, #0x0                   	// #0
    5fb4:	d2800014 	mov	x20, #0x0                   	// #0
    5fb8:	f94002d3 	ldr	x19, [x22]
    5fbc:	91000694 	add	x20, x20, #0x1
    5fc0:	8b150273 	add	x19, x19, x21
    5fc4:	9101a2b5 	add	x21, x21, #0x68
    5fc8:	aa1303e0 	mov	x0, x19
    5fcc:	97fff3d1 	bl	2f10 <fwp_tape_unlink_scope>
    5fd0:	aa1703e0 	mov	x0, x23
    5fd4:	f9401261 	ldr	x1, [x19, #32]
    5fd8:	f90003e1 	str	x1, [sp]
    5fdc:	f9401a62 	ldr	x2, [x19, #48]
    5fe0:	f9000be2 	str	x2, [sp, #16]
    5fe4:	f9402261 	ldr	x1, [x19, #64]
    5fe8:	f90013e1 	str	x1, [sp, #32]
    5fec:	97fff4a5 	bl	3280 <fwp_tape_buffers_dispose>
    5ff0:	f9403260 	ldr	x0, [x19, #96]
    5ff4:	97ffff90 	bl	5e34 <fwp_owned_tape_release>
    5ff8:	f900327f 	str	xzr, [x19, #96]
    5ffc:	f94042c0 	ldr	x0, [x22, #128]
    6000:	eb14001f 	cmp	x0, x20
    6004:	54fffdac 	b.gt	5fb8 <fwp_tape_finish+0x58>
    6008:	f9402300 	ldr	x0, [x24, #64]
    600c:	91010313 	add	x19, x24, #0x40
    6010:	97fff228 	bl	28b0 <free@plt>
    6014:	f900231f 	str	xzr, [x24, #64]
    6018:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    601c:	f947f400 	ldr	x0, [x0, #4072]
    6020:	f900427f 	str	xzr, [x19, #128]
    6024:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    6028:	f9401fe2 	ldr	x2, [sp, #56]
    602c:	f9400001 	ldr	x1, [x0]
    6030:	eb010042 	subs	x2, x2, x1
    6034:	d2800001 	mov	x1, #0x0                   	// #0
    6038:	540000e1 	b.ne	6054 <fwp_tape_finish+0xf4>  // b.any
    603c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6040:	a94553f3 	ldp	x19, x20, [sp, #80]
    6044:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6048:	a94763f7 	ldp	x23, x24, [sp, #112]
    604c:	910203ff 	add	sp, sp, #0x80
    6050:	d65f03c0 	ret
    6054:	97fff1e7 	bl	27f0 <__stack_chk_fail@plt>
    6058:	d503201f 	nop
    605c:	d503201f 	nop

0000000000006060 <fwp_tape_scope_release>:
    6060:	d10243ff 	sub	sp, sp, #0x90
    6064:	a9047bfd 	stp	x29, x30, [sp, #64]
    6068:	910103fd 	add	x29, sp, #0x40
    606c:	a90553f3 	stp	x19, x20, [sp, #80]
    6070:	aa0003f4 	mov	x20, x0
    6074:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6078:	f947f400 	ldr	x0, [x0, #4072]
    607c:	b9400285 	ldr	w5, [x20]
    6080:	f9400001 	ldr	x1, [x0]
    6084:	f9001fe1 	str	x1, [sp, #56]
    6088:	d2800001 	mov	x1, #0x0                   	// #0
    608c:	37f806c5 	tbnz	w5, #31, 6164 <fwp_tape_scope_release+0x104>
    6090:	a90763f7 	stp	x23, x24, [sp, #112]
    6094:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6098:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    609c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    60a0:	d00000d3 	adrp	x19, 20000 <__data_start>
    60a4:	910003f7 	mov	x23, sp
    60a8:	91010273 	add	x19, x19, #0x40
    60ac:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    60b0:	a9065bf5 	stp	x21, x22, [sp, #96]
    60b4:	52800d16 	mov	w22, #0x68                  	// #104
    60b8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    60bc:	f90043f9 	str	x25, [sp, #128]
    60c0:	14000006 	b	60d8 <fwp_tape_scope_release+0x78>
    60c4:	97fff46f 	bl	3280 <fwp_tape_buffers_dispose>
    60c8:	aa1903e0 	mov	x0, x25
    60cc:	97ffff5a 	bl	5e34 <fwp_owned_tape_release>
    60d0:	b9400285 	ldr	w5, [x20]
    60d4:	37f80425 	tbnz	w5, #31, 6158 <fwp_tape_scope_release+0xf8>
    60d8:	f9400266 	ldr	x6, [x19]
    60dc:	9b367ca5 	smull	x5, w5, w22
    60e0:	8b0500c0 	add	x0, x6, x5
    60e4:	97fff38b 	bl	2f10 <fwp_tape_unlink_scope>
    60e8:	ad410001 	ldp	q1, q0, [x0, #32]
    60ec:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    60f0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    60f4:	f9400c03 	ldr	x3, [x0, #24]
    60f8:	ad0003e1 	stp	q1, q0, [sp]
    60fc:	b86568c1 	ldr	w1, [x6, x5]
    6100:	a9440804 	ldp	x4, x2, [x0, #64]
    6104:	b900041f 	str	wzr, [x0, #4]
    6108:	f9403019 	ldr	x25, [x0, #96]
    610c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6110:	f9000c1f 	str	xzr, [x0, #24]
    6114:	a9020fe4 	stp	x4, x3, [sp, #32]
    6118:	f9001be2 	str	x2, [sp, #48]
    611c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6120:	f900301f 	str	xzr, [x0, #96]
    6124:	6b15003f 	cmp	w1, w21
    6128:	540000e8 	b.hi	6144 <fwp_tape_scope_release+0xe4>  // b.pmore
    612c:	9343fca5 	asr	x5, x5, #3
    6130:	f9404e60 	ldr	x0, [x19, #152]
    6134:	9b187ca5 	mul	x5, x5, x24
    6138:	eb0000bf 	cmp	x5, x0
    613c:	5400004a 	b.ge	6144 <fwp_tape_scope_release+0xe4>  // b.tcont
    6140:	f9004e65 	str	x5, [x19, #152]
    6144:	aa1703e0 	mov	x0, x23
    6148:	b5fffbf9 	cbnz	x25, 60c4 <fwp_tape_scope_release+0x64>
    614c:	97fff6e9 	bl	3cf0 <fwp_tape_buffers_release>
    6150:	b9400285 	ldr	w5, [x20]
    6154:	36fffc25 	tbz	w5, #31, 60d8 <fwp_tape_scope_release+0x78>
    6158:	a9465bf5 	ldp	x21, x22, [sp, #96]
    615c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6160:	f94043f9 	ldr	x25, [sp, #128]
    6164:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    6168:	f947f400 	ldr	x0, [x0, #4072]
    616c:	f9401fe2 	ldr	x2, [sp, #56]
    6170:	f9400001 	ldr	x1, [x0]
    6174:	eb010042 	subs	x2, x2, x1
    6178:	d2800001 	mov	x1, #0x0                   	// #0
    617c:	540000a1 	b.ne	6190 <fwp_tape_scope_release+0x130>  // b.any
    6180:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6184:	a94553f3 	ldp	x19, x20, [sp, #80]
    6188:	910243ff 	add	sp, sp, #0x90
    618c:	d65f03c0 	ret
    6190:	a9065bf5 	stp	x21, x22, [sp, #96]
    6194:	a90763f7 	stp	x23, x24, [sp, #112]
    6198:	f90043f9 	str	x25, [sp, #128]
    619c:	97fff195 	bl	27f0 <__stack_chk_fail@plt>

00000000000061a0 <fwp_task_dispose>:
    61a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    61a4:	910003fd 	mov	x29, sp
    61a8:	f9000bf3 	str	x19, [sp, #16]
    61ac:	aa0003f3 	mov	x19, x0
    61b0:	39414000 	ldrb	w0, [x0, #80]
    61b4:	36000720 	tbz	w0, #0, 6298 <fwp_task_dispose+0xf8>
    61b8:	f9400a60 	ldr	x0, [x19, #16]
    61bc:	b50006e0 	cbnz	x0, 6298 <fwp_task_dispose+0xf8>
    61c0:	a9478660 	ldp	x0, x1, [x19, #120]
    61c4:	39014e7f 	strb	wzr, [x19, #83]
    61c8:	f9003e7f 	str	xzr, [x19, #120]
    61cc:	f100003f 	cmp	x1, #0x0
    61d0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    61d4:	54000040 	b.eq	61dc <fwp_task_dispose+0x3c>  // b.none
    61d8:	d63f0020 	blr	x1
    61dc:	f9405660 	ldr	x0, [x19, #168]
    61e0:	97fff7c8 	bl	4100 <fwp_mem_free>
    61e4:	f900567f 	str	xzr, [x19, #168]
    61e8:	b9405e60 	ldr	w0, [x19, #92]
    61ec:	7100041f 	cmp	w0, #0x1
    61f0:	54000420 	b.eq	6274 <fwp_task_dispose+0xd4>  // b.none
    61f4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    61f8:	91154042 	add	x2, x2, #0x550
    61fc:	f949d840 	ldr	x0, [x2, #5040]
    6200:	f949ec41 	ldr	x1, [x2, #5080]
    6204:	cb000260 	sub	x0, x19, x0
    6208:	eb01401f 	cmp	x0, x1, lsl #16
    620c:	540002e2 	b.cs	6268 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6210:	d350fc01 	lsr	x1, x0, #16
    6214:	f949fc44 	ldr	x4, [x2, #5112]
    6218:	8b010821 	add	x1, x1, x1, lsl #2
    621c:	d37df021 	lsl	x1, x1, #3
    6220:	8b010083 	add	x3, x4, x1
    6224:	f9401062 	ldr	x2, [x3, #32]
    6228:	b4000202 	cbz	x2, 6268 <fwp_task_dispose+0xc8>
    622c:	38616881 	ldrb	w1, [x4, x1]
    6230:	7100083f 	cmp	w1, #0x2
    6234:	54000280 	b.eq	6284 <fwp_task_dispose+0xe4>  // b.none
    6238:	7100043f 	cmp	w1, #0x1
    623c:	54000161 	b.ne	6268 <fwp_task_dispose+0xc8>  // b.any
    6240:	29430464 	ldp	w4, w1, [x3, #24]
    6244:	92403c00 	and	x0, x0, #0xffff
    6248:	9b047c00 	mul	x0, x0, x4
    624c:	d360fc00 	lsr	x0, x0, #32
    6250:	eb01001f 	cmp	x0, x1
    6254:	540000a2 	b.cs	6268 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6258:	8b000042 	add	x2, x2, x0
    625c:	39400040 	ldrb	w0, [x2]
    6260:	7100041f 	cmp	w0, #0x1
    6264:	54000080 	b.eq	6274 <fwp_task_dispose+0xd4>  // b.none
    6268:	f9400bf3 	ldr	x19, [sp, #16]
    626c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6270:	d65f03c0 	ret
    6274:	aa1303e0 	mov	x0, x19
    6278:	f9400bf3 	ldr	x19, [sp, #16]
    627c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6280:	17fff7a0 	b	4100 <fwp_mem_free>
    6284:	72003c1f 	tst	w0, #0xffff
    6288:	54fffea0 	b.eq	625c <fwp_task_dispose+0xbc>  // b.none
    628c:	f9400bf3 	ldr	x19, [sp, #16]
    6290:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6294:	d65f03c0 	ret
    6298:	97fff16a 	bl	2840 <abort@plt>
    629c:	d503201f 	nop

00000000000062a0 <fwp_free_zombie>:
    62a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    62a4:	910003fd 	mov	x29, sp
    62a8:	a90153f3 	stp	x19, x20, [sp, #16]
    62ac:	d00000d4 	adrp	x20, 20000 <__data_start>
    62b0:	91010281 	add	x1, x20, #0x40
    62b4:	f9405033 	ldr	x19, [x1, #160]
    62b8:	b4000333 	cbz	x19, 631c <fwp_free_zombie+0x7c>
    62bc:	f9400820 	ldr	x0, [x1, #16]
    62c0:	eb00027f 	cmp	x19, x0
    62c4:	540002c0 	b.eq	631c <fwp_free_zombie+0x7c>  // b.none
    62c8:	b940a822 	ldr	w2, [x1, #168]
    62cc:	f9400a60 	ldr	x0, [x19, #16]
    62d0:	7100fc5f 	cmp	w2, #0x3f
    62d4:	5400078c 	b.gt	63c4 <fwp_free_zombie+0x124>
    62d8:	9102c023 	add	x3, x1, #0xb0
    62dc:	11000444 	add	w4, w2, #0x1
    62e0:	b900a824 	str	w4, [x1, #168]
    62e4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    62e8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    62ec:	a9530261 	ldp	x1, x0, [x19, #304]
    62f0:	b4000741 	cbz	x1, 63d8 <fwp_free_zombie+0x138>
    62f4:	f9009c20 	str	x0, [x1, #312]
    62f8:	b4000040 	cbz	x0, 6300 <fwp_free_zombie+0x60>
    62fc:	f9009801 	str	x1, [x0, #304]
    6300:	91010294 	add	x20, x20, #0x40
    6304:	b9405e60 	ldr	w0, [x19, #92]
    6308:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    630c:	f900529f 	str	xzr, [x20, #160]
    6310:	34000140 	cbz	w0, 6338 <fwp_free_zombie+0x98>
    6314:	7100041f 	cmp	w0, #0x1
    6318:	54000080 	b.eq	6328 <fwp_free_zombie+0x88>  // b.none
    631c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6320:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6324:	d65f03c0 	ret
    6328:	aa1303e0 	mov	x0, x19
    632c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6330:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6334:	17ffff9b 	b	61a0 <fwp_task_dispose>
    6338:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc90>
    633c:	91154082 	add	x2, x4, #0x550
    6340:	f949d841 	ldr	x1, [x2, #5040]
    6344:	f949ec40 	ldr	x0, [x2, #5080]
    6348:	cb010261 	sub	x1, x19, x1
    634c:	eb00403f 	cmp	x1, x0, lsl #16
    6350:	54fffe62 	b.cs	631c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6354:	d350fc20 	lsr	x0, x1, #16
    6358:	f949fc43 	ldr	x3, [x2, #5112]
    635c:	8b000800 	add	x0, x0, x0, lsl #2
    6360:	d37df000 	lsl	x0, x0, #3
    6364:	8b000062 	add	x2, x3, x0
    6368:	f9401054 	ldr	x20, [x2, #32]
    636c:	b4fffd94 	cbz	x20, 631c <fwp_free_zombie+0x7c>
    6370:	38606860 	ldrb	w0, [x3, x0]
    6374:	7100081f 	cmp	w0, #0x2
    6378:	54000360 	b.eq	63e4 <fwp_free_zombie+0x144>  // b.none
    637c:	7100041f 	cmp	w0, #0x1
    6380:	54fffce1 	b.ne	631c <fwp_free_zombie+0x7c>  // b.any
    6384:	29430043 	ldp	w3, w0, [x2, #24]
    6388:	92403c21 	and	x1, x1, #0xffff
    638c:	9b037c21 	mul	x1, x1, x3
    6390:	d360fc21 	lsr	x1, x1, #32
    6394:	eb00003f 	cmp	x1, x0
    6398:	54fffc22 	b.cs	631c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    639c:	8b010294 	add	x20, x20, x1
    63a0:	39400280 	ldrb	w0, [x20]
    63a4:	34fffbc0 	cbz	w0, 631c <fwp_free_zombie+0x7c>
    63a8:	7100041f 	cmp	w0, #0x1
    63ac:	54fffbe0 	b.eq	6328 <fwp_free_zombie+0x88>  // b.none
    63b0:	7103fc1f 	cmp	w0, #0xff
    63b4:	540001e0 	b.eq	63f0 <fwp_free_zombie+0x150>  // b.none
    63b8:	51000400 	sub	w0, w0, #0x1
    63bc:	39000280 	strb	w0, [x20]
    63c0:	17ffffd7 	b	631c <fwp_free_zombie+0x7c>
    63c4:	f9400e61 	ldr	x1, [x19, #24]
    63c8:	97fff152 	bl	2910 <munmap@plt>
    63cc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    63d0:	a9530261 	ldp	x1, x0, [x19, #304]
    63d4:	b5fff901 	cbnz	x1, 62f4 <fwp_free_zombie+0x54>
    63d8:	91010282 	add	x2, x20, #0x40
    63dc:	f9015840 	str	x0, [x2, #688]
    63e0:	17ffffc6 	b	62f8 <fwp_free_zombie+0x58>
    63e4:	72003c3f 	tst	w1, #0xffff
    63e8:	54fff9a1 	b.ne	631c <fwp_free_zombie+0x7c>  // b.any
    63ec:	17ffffed 	b	63a0 <fwp_free_zombie+0x100>
    63f0:	ca544680 	eor	x0, x20, x20, lsr #17
    63f4:	91154084 	add	x4, x4, #0x550
    63f8:	ca402400 	eor	x0, x0, x0, lsr #9
    63fc:	92401c00 	and	x0, x0, #0xff
    6400:	910a2402 	add	x2, x0, #0x289
    6404:	8b000c80 	add	x0, x4, x0, lsl #3
    6408:	8b020c82 	add	x2, x4, x2, lsl #3
    640c:	f94a2400 	ldr	x0, [x0, #5192]
    6410:	b50000a0 	cbnz	x0, 6424 <fwp_free_zombie+0x184>
    6414:	14000013 	b	6460 <fwp_free_zombie+0x1c0>
    6418:	91004002 	add	x2, x0, #0x10
    641c:	f9400800 	ldr	x0, [x0, #16]
    6420:	b4000200 	cbz	x0, 6460 <fwp_free_zombie+0x1c0>
    6424:	f9400001 	ldr	x1, [x0]
    6428:	eb14003f 	cmp	x1, x20
    642c:	54ffff61 	b.ne	6418 <fwp_free_zombie+0x178>  // b.any
    6430:	f9400041 	ldr	x1, [x2]
    6434:	f9400420 	ldr	x0, [x1, #8]
    6438:	d1000400 	sub	x0, x0, #0x1
    643c:	f9000420 	str	x0, [x1, #8]
    6440:	f103f81f 	cmp	x0, #0xfe
    6444:	54fff6c1 	b.ne	631c <fwp_free_zombie+0x7c>  // b.any
    6448:	39400280 	ldrb	w0, [x20]
    644c:	7103fc1f 	cmp	w0, #0xff
    6450:	540000e0 	b.eq	646c <fwp_free_zombie+0x1cc>  // b.none
    6454:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6458:	39000280 	strb	w0, [x20]
    645c:	17ffffb0 	b	631c <fwp_free_zombie+0x7c>
    6460:	b0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    6464:	91264000 	add	x0, x0, #0x990
    6468:	97fff66a 	bl	3e10 <fwp_trap>
    646c:	aa1403e0 	mov	x0, x20
    6470:	97fff688 	bl	3e90 <fwp_rc_forget_slot.part.0>
    6474:	17fffff8 	b	6454 <fwp_free_zombie+0x1b4>
    6478:	d503201f 	nop
    647c:	d503201f 	nop

0000000000006480 <fwp_block>:
    6480:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6484:	910003fd 	mov	x29, sp
    6488:	a90153f3 	stp	x19, x20, [sp, #16]
    648c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6490:	91010274 	add	x20, x19, #0x40
    6494:	f9401a82 	ldr	x2, [x20, #48]
    6498:	b4000642 	cbz	x2, 6560 <fwp_block+0xe0>
    649c:	91010261 	add	x1, x19, #0x40
    64a0:	f9408040 	ldr	x0, [x2, #256]
    64a4:	f9001820 	str	x0, [x1, #48]
    64a8:	b40006a0 	cbz	x0, 657c <fwp_block+0xfc>
    64ac:	d503201f 	nop
    64b0:	91010263 	add	x3, x19, #0x40
    64b4:	3901505f 	strb	wzr, [x2, #84]
    64b8:	f9400864 	ldr	x4, [x3, #16]
    64bc:	eb02009f 	cmp	x4, x2
    64c0:	54000440 	b.eq	6548 <fwp_block+0xc8>  // b.none
    64c4:	f9415c65 	ldr	x5, [x3, #696]
    64c8:	f9000862 	str	x2, [x3, #16]
    64cc:	f9400441 	ldr	x1, [x2, #8]
    64d0:	f9004885 	str	x5, [x4, #144]
    64d4:	f9416065 	ldr	x5, [x3, #704]
    64d8:	f9004c85 	str	x5, [x4, #152]
    64dc:	f9416465 	ldr	x5, [x3, #712]
    64e0:	f9005085 	str	x5, [x4, #160]
    64e4:	f9416865 	ldr	x5, [x3, #720]
    64e8:	f9005485 	str	x5, [x4, #168]
    64ec:	f9416c65 	ldr	x5, [x3, #728]
    64f0:	f9005885 	str	x5, [x4, #176]
    64f4:	f9417065 	ldr	x5, [x3, #736]
    64f8:	f9005c85 	str	x5, [x4, #184]
    64fc:	f9417465 	ldr	x5, [x3, #744]
    6500:	f9006085 	str	x5, [x4, #192]
    6504:	f9400480 	ldr	x0, [x4, #8]
    6508:	f9404844 	ldr	x4, [x2, #144]
    650c:	f9015c64 	str	x4, [x3, #696]
    6510:	f9404c44 	ldr	x4, [x2, #152]
    6514:	f9016064 	str	x4, [x3, #704]
    6518:	f9405044 	ldr	x4, [x2, #160]
    651c:	f9016464 	str	x4, [x3, #712]
    6520:	f9405444 	ldr	x4, [x2, #168]
    6524:	f9016864 	str	x4, [x3, #720]
    6528:	f9405844 	ldr	x4, [x2, #176]
    652c:	f9016c64 	str	x4, [x3, #728]
    6530:	a94b8844 	ldp	x4, x2, [x2, #184]
    6534:	f9017064 	str	x4, [x3, #736]
    6538:	f9017462 	str	x2, [x3, #744]
    653c:	97fff0c5 	bl	2850 <swapcontext@plt>
    6540:	97ffff58 	bl	62a0 <fwp_free_zombie>
    6544:	d503201f 	nop
    6548:	91010260 	add	x0, x19, #0x40
    654c:	b942f000 	ldr	w0, [x0, #752]
    6550:	340001a0 	cbz	w0, 6584 <fwp_block+0x104>
    6554:	a94153f3 	ldp	x19, x20, [sp, #16]
    6558:	a8c27bfd 	ldp	x29, x30, [sp], #32
    655c:	d65f03c0 	ret
    6560:	97fff874 	bl	4730 <fwp_poll_events>
    6564:	f9401a82 	ldr	x2, [x20, #48]
    6568:	b4ffffc2 	cbz	x2, 6560 <fwp_block+0xe0>
    656c:	91010261 	add	x1, x19, #0x40
    6570:	f9408040 	ldr	x0, [x2, #256]
    6574:	f9001820 	str	x0, [x1, #48]
    6578:	b5fff9c0 	cbnz	x0, 64b0 <fwp_block+0x30>
    657c:	f900143f 	str	xzr, [x1, #40]
    6580:	17ffffcc 	b	64b0 <fwp_block+0x30>
    6584:	b0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    6588:	9130a000 	add	x0, x0, #0xc28
    658c:	97fff0fd 	bl	2980 <getenv@plt>
    6590:	5284e202 	mov	w2, #0x2710                	// #10000
    6594:	b4000060 	cbz	x0, 65a0 <fwp_block+0x120>
    6598:	39400001 	ldrb	w1, [x0]
    659c:	350000c1 	cbnz	w1, 65b4 <fwp_block+0x134>
    65a0:	91010273 	add	x19, x19, #0x40
    65a4:	b902f262 	str	w2, [x19, #752]
    65a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    65ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65b0:	d65f03c0 	ret
    65b4:	52800142 	mov	w2, #0xa                   	// #10
    65b8:	d2800001 	mov	x1, #0x0                   	// #0
    65bc:	97fff041 	bl	26c0 <strtoll@plt>
    65c0:	d1000403 	sub	x3, x0, #0x1
    65c4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    65c8:	eb02007f 	cmp	x3, x2
    65cc:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    65d0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    65d4:	17fffff3 	b	65a0 <fwp_block+0x120>
    65d8:	d503201f 	nop
    65dc:	d503201f 	nop

00000000000065e0 <fwp_owned_entry161>:
    65e0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    65e4:	910003fd 	mov	x29, sp
    65e8:	a90363f7 	stp	x23, x24, [sp, #48]
    65ec:	a9406002 	ldp	x2, x24, [x0]
    65f0:	a90153f3 	stp	x19, x20, [sp, #16]
    65f4:	f9400801 	ldr	x1, [x0, #16]
    65f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    65fc:	ab010055 	adds	x21, x2, x1
    6600:	54000d06 	b.vs	67a0 <fwp_owned_entry161+0x1c0>
    6604:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc90>
    6608:	91154281 	add	x1, x20, #0x550
    660c:	b953a420 	ldr	w0, [x1, #5028]
    6610:	34000a80 	cbz	w0, 6760 <fwp_owned_entry161+0x180>
    6614:	397e8820 	ldrb	w0, [x1, #4002]
    6618:	910f0002 	add	x2, x0, #0x3c0
    661c:	8b000400 	add	x0, x0, x0, lsl #1
    6620:	d37df000 	lsl	x0, x0, #3
    6624:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    6628:	2a1703f6 	mov	w22, w23
    662c:	f8606833 	ldr	x19, [x1, x0]
    6630:	b4000853 	cbz	x19, 6738 <fwp_owned_entry161+0x158>
    6634:	f9400262 	ldr	x2, [x19]
    6638:	aa2203e2 	mvn	x2, x2
    663c:	f8206822 	str	x2, [x1, x0]
    6640:	f10062df 	cmp	x22, #0x18
    6644:	540000e9 	b.ls	6660 <fwp_owned_entry161+0x80>  // b.plast
    6648:	d10066c2 	sub	x2, x22, #0x19
    664c:	91006260 	add	x0, x19, #0x18
    6650:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6654:	52800001 	mov	w1, #0x0                   	// #0
    6658:	91002042 	add	x2, x2, #0x8
    665c:	97fff059 	bl	27c0 <memset@plt>
    6660:	91154281 	add	x1, x20, #0x550
    6664:	f94a1020 	ldr	x0, [x1, #5152]
    6668:	ab160000 	adds	x0, x0, x22
    666c:	540009c2 	b.cs	67a4 <fwp_owned_entry161+0x1c4>  // b.hs, b.nlast
    6670:	f94a1422 	ldr	x2, [x1, #5160]
    6674:	f90a1020 	str	x0, [x1, #5152]
    6678:	eb02001f 	cmp	x0, x2
    667c:	54000049 	b.ls	6684 <fwp_owned_entry161+0xa4>  // b.plast
    6680:	f90a1420 	str	x0, [x1, #5160]
    6684:	91154280 	add	x0, x20, #0x550
    6688:	1e6302e1 	ucvtf	d1, w23
    668c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6690:	1e612800 	fadd	d0, d0, d1
    6694:	fd0a1c00 	str	d0, [x0, #5176]
    6698:	d0000020 	adrp	x0, c000 <_IO_stdin_used+0x7b0>
    669c:	91154294 	add	x20, x20, #0x550
    66a0:	a900d678 	stp	x24, x21, [x19, #8]
    66a4:	fd429000 	ldr	d0, [x0, #1312]
    66a8:	fd000260 	str	d0, [x19]
    66ac:	f949da81 	ldr	x1, [x20, #5040]
    66b0:	f949ee80 	ldr	x0, [x20, #5080]
    66b4:	cb010261 	sub	x1, x19, x1
    66b8:	eb00403f 	cmp	x1, x0, lsl #16
    66bc:	54000322 	b.cs	6720 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    66c0:	d350fc20 	lsr	x0, x1, #16
    66c4:	f949fe83 	ldr	x3, [x20, #5112]
    66c8:	8b000800 	add	x0, x0, x0, lsl #2
    66cc:	d37df002 	lsl	x2, x0, #3
    66d0:	8b020060 	add	x0, x3, x2
    66d4:	f9401014 	ldr	x20, [x0, #32]
    66d8:	b4000254 	cbz	x20, 6720 <fwp_owned_entry161+0x140>
    66dc:	38626862 	ldrb	w2, [x3, x2]
    66e0:	7100085f 	cmp	w2, #0x2
    66e4:	54000480 	b.eq	6774 <fwp_owned_entry161+0x194>  // b.none
    66e8:	7100045f 	cmp	w2, #0x1
    66ec:	540001a1 	b.ne	6720 <fwp_owned_entry161+0x140>  // b.any
    66f0:	29430002 	ldp	w2, w0, [x0, #24]
    66f4:	92403c21 	and	x1, x1, #0xffff
    66f8:	9b027c21 	mul	x1, x1, x2
    66fc:	d360fc21 	lsr	x1, x1, #32
    6700:	eb00003f 	cmp	x1, x0
    6704:	540000e2 	b.cs	6720 <fwp_owned_entry161+0x140>  // b.hs, b.nlast
    6708:	8b010294 	add	x20, x20, x1
    670c:	39400280 	ldrb	w0, [x20]
    6710:	7103fc1f 	cmp	w0, #0xff
    6714:	54000400 	b.eq	6794 <fwp_owned_entry161+0x1b4>  // b.none
    6718:	52800020 	mov	w0, #0x1                   	// #1
    671c:	39000280 	strb	w0, [x20]
    6720:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6724:	aa1303e0 	mov	x0, x19
    6728:	a94153f3 	ldp	x19, x20, [sp, #16]
    672c:	a94363f7 	ldp	x23, x24, [sp, #48]
    6730:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6734:	d65f03c0 	ret
    6738:	8b000021 	add	x1, x1, x0
    673c:	f9400433 	ldr	x19, [x1, #8]
    6740:	b4000113 	cbz	x19, 6760 <fwp_owned_entry161+0x180>
    6744:	f9400820 	ldr	x0, [x1, #16]
    6748:	cb130000 	sub	x0, x0, x19
    674c:	eb0002df 	cmp	x22, x0
    6750:	54000088 	b.hi	6760 <fwp_owned_entry161+0x180>  // b.pmore
    6754:	8b160260 	add	x0, x19, x22
    6758:	f9000420 	str	x0, [x1, #8]
    675c:	17ffffb9 	b	6640 <fwp_owned_entry161+0x60>
    6760:	52800001 	mov	w1, #0x0                   	// #0
    6764:	d2800300 	mov	x0, #0x18                  	// #24
    6768:	97fff922 	bl	4bf0 <fwp_heap_alloc>
    676c:	aa0003f3 	mov	x19, x0
    6770:	17ffffca 	b	6698 <fwp_owned_entry161+0xb8>
    6774:	72003c3f 	tst	w1, #0xffff
    6778:	54fffca0 	b.eq	670c <fwp_owned_entry161+0x12c>  // b.none
    677c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6780:	aa1303e0 	mov	x0, x19
    6784:	a94153f3 	ldp	x19, x20, [sp, #16]
    6788:	a94363f7 	ldp	x23, x24, [sp, #48]
    678c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6790:	d65f03c0 	ret
    6794:	aa1403e0 	mov	x0, x20
    6798:	97fff5be 	bl	3e90 <fwp_rc_forget_slot.part.0>
    679c:	17ffffdf 	b	6718 <fwp_owned_entry161+0x138>
    67a0:	97fff098 	bl	2a00 <fwp_trap_overflow.constprop.0>
    67a4:	97fff203 	bl	2fb0 <fwp_heap_oom>
    67a8:	d503201f 	nop
    67ac:	d503201f 	nop

00000000000067b0 <e161>:
    67b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    67b4:	910003fd 	mov	x29, sp
    67b8:	a90363f7 	stp	x23, x24, [sp, #48]
    67bc:	a9406002 	ldp	x2, x24, [x0]
    67c0:	a90153f3 	stp	x19, x20, [sp, #16]
    67c4:	f9400801 	ldr	x1, [x0, #16]
    67c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    67cc:	ab010055 	adds	x21, x2, x1
    67d0:	54000d86 	b.vs	6980 <e161+0x1d0>
    67d4:	f0000154 	adrp	x20, 31000 <fwp_root_context+0xc90>
    67d8:	91154281 	add	x1, x20, #0x550
    67dc:	b953a420 	ldr	w0, [x1, #5028]
    67e0:	34000ac0 	cbz	w0, 6938 <e161+0x188>
    67e4:	397e8820 	ldrb	w0, [x1, #4002]
    67e8:	910f0002 	add	x2, x0, #0x3c0
    67ec:	8b000400 	add	x0, x0, x0, lsl #1
    67f0:	d37df000 	lsl	x0, x0, #3
    67f4:	b8627837 	ldr	w23, [x1, x2, lsl #2]
    67f8:	2a1703f6 	mov	w22, w23
    67fc:	f8606833 	ldr	x19, [x1, x0]
    6800:	b4000893 	cbz	x19, 6910 <e161+0x160>
    6804:	f9400262 	ldr	x2, [x19]
    6808:	aa2203e2 	mvn	x2, x2
    680c:	f8206822 	str	x2, [x1, x0]
    6810:	f10062df 	cmp	x22, #0x18
    6814:	540000e9 	b.ls	6830 <e161+0x80>  // b.plast
    6818:	d10066c2 	sub	x2, x22, #0x19
    681c:	91006260 	add	x0, x19, #0x18
    6820:	927df042 	and	x2, x2, #0xfffffffffffffff8
    6824:	52800001 	mov	w1, #0x0                   	// #0
    6828:	91002042 	add	x2, x2, #0x8
    682c:	97ffefe5 	bl	27c0 <memset@plt>
    6830:	91154281 	add	x1, x20, #0x550
    6834:	f94a1020 	ldr	x0, [x1, #5152]
    6838:	ab160000 	adds	x0, x0, x22
    683c:	54000a42 	b.cs	6984 <e161+0x1d4>  // b.hs, b.nlast
    6840:	f94a1422 	ldr	x2, [x1, #5160]
    6844:	f90a1020 	str	x0, [x1, #5152]
    6848:	eb02001f 	cmp	x0, x2
    684c:	54000049 	b.ls	6854 <e161+0xa4>  // b.plast
    6850:	f90a1420 	str	x0, [x1, #5160]
    6854:	91154280 	add	x0, x20, #0x550
    6858:	1e6302e1 	ucvtf	d1, w23
    685c:	fd4a1c00 	ldr	d0, [x0, #5176]
    6860:	1e612800 	fadd	d0, d0, d1
    6864:	fd0a1c00 	str	d0, [x0, #5176]
    6868:	d0000020 	adrp	x0, c000 <_IO_stdin_used+0x7b0>
    686c:	91154294 	add	x20, x20, #0x550
    6870:	a900d678 	stp	x24, x21, [x19, #8]
    6874:	fd429000 	ldr	d0, [x0, #1312]
    6878:	fd000260 	str	d0, [x19]
    687c:	f949da81 	ldr	x1, [x20, #5040]
    6880:	f949ee80 	ldr	x0, [x20, #5080]
    6884:	cb010261 	sub	x1, x19, x1
    6888:	eb00403f 	cmp	x1, x0, lsl #16
    688c:	54000322 	b.cs	68f0 <e161+0x140>  // b.hs, b.nlast
    6890:	d350fc20 	lsr	x0, x1, #16
    6894:	f949fe83 	ldr	x3, [x20, #5112]
    6898:	8b000800 	add	x0, x0, x0, lsl #2
    689c:	d37df002 	lsl	x2, x0, #3
    68a0:	8b020060 	add	x0, x3, x2
    68a4:	f9401014 	ldr	x20, [x0, #32]
    68a8:	b4000254 	cbz	x20, 68f0 <e161+0x140>
    68ac:	38626862 	ldrb	w2, [x3, x2]
    68b0:	7100085f 	cmp	w2, #0x2
    68b4:	540004c0 	b.eq	694c <e161+0x19c>  // b.none
    68b8:	7100045f 	cmp	w2, #0x1
    68bc:	540001a1 	b.ne	68f0 <e161+0x140>  // b.any
    68c0:	29430002 	ldp	w2, w0, [x0, #24]
    68c4:	92403c21 	and	x1, x1, #0xffff
    68c8:	9b027c21 	mul	x1, x1, x2
    68cc:	d360fc21 	lsr	x1, x1, #32
    68d0:	eb00003f 	cmp	x1, x0
    68d4:	540000e2 	b.cs	68f0 <e161+0x140>  // b.hs, b.nlast
    68d8:	8b010294 	add	x20, x20, x1
    68dc:	39400280 	ldrb	w0, [x20]
    68e0:	7103fc1f 	cmp	w0, #0xff
    68e4:	54000480 	b.eq	6974 <e161+0x1c4>  // b.none
    68e8:	52800020 	mov	w0, #0x1                   	// #1
    68ec:	39000280 	strb	w0, [x20]
    68f0:	aa1303e0 	mov	x0, x19
    68f4:	97fffbc7 	bl	5810 <fwp_rc_share>
    68f8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    68fc:	aa1303e0 	mov	x0, x19
    6900:	a94153f3 	ldp	x19, x20, [sp, #16]
    6904:	a94363f7 	ldp	x23, x24, [sp, #48]
    6908:	a8c47bfd 	ldp	x29, x30, [sp], #64
    690c:	d65f03c0 	ret
    6910:	8b000021 	add	x1, x1, x0
    6914:	f9400433 	ldr	x19, [x1, #8]
    6918:	b4000113 	cbz	x19, 6938 <e161+0x188>
    691c:	f9400820 	ldr	x0, [x1, #16]
    6920:	cb130000 	sub	x0, x0, x19
    6924:	eb0002df 	cmp	x22, x0
    6928:	54000088 	b.hi	6938 <e161+0x188>  // b.pmore
    692c:	8b160260 	add	x0, x19, x22
    6930:	f9000420 	str	x0, [x1, #8]
    6934:	17ffffb7 	b	6810 <e161+0x60>
    6938:	52800001 	mov	w1, #0x0                   	// #0
    693c:	d2800300 	mov	x0, #0x18                  	// #24
    6940:	97fff8ac 	bl	4bf0 <fwp_heap_alloc>
    6944:	aa0003f3 	mov	x19, x0
    6948:	17ffffc8 	b	6868 <e161+0xb8>
    694c:	72003c3f 	tst	w1, #0xffff
    6950:	54fffc60 	b.eq	68dc <e161+0x12c>  // b.none
    6954:	aa1303e0 	mov	x0, x19
    6958:	97fffbae 	bl	5810 <fwp_rc_share>
    695c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6960:	aa1303e0 	mov	x0, x19
    6964:	a94153f3 	ldp	x19, x20, [sp, #16]
    6968:	a94363f7 	ldp	x23, x24, [sp, #48]
    696c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    6970:	d65f03c0 	ret
    6974:	aa1403e0 	mov	x0, x20
    6978:	97fff546 	bl	3e90 <fwp_rc_forget_slot.part.0>
    697c:	17ffffdb 	b	68e8 <e161+0x138>
    6980:	97fff020 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6984:	97fff18b 	bl	2fb0 <fwp_heap_oom>
    6988:	d503201f 	nop
    698c:	d503201f 	nop

0000000000006990 <fwp_drop4>:
    6990:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6994:	910003fd 	mov	x29, sp
    6998:	a90153f3 	stp	x19, x20, [sp, #16]
    699c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc90>
    69a0:	f90013f5 	str	x21, [sp, #32]
    69a4:	91154275 	add	x21, x19, #0x550
    69a8:	f949daa1 	ldr	x1, [x21, #5040]
    69ac:	f949eea2 	ldr	x2, [x21, #5080]
    69b0:	cb010001 	sub	x1, x0, x1
    69b4:	eb02403f 	cmp	x1, x2, lsl #16
    69b8:	54000382 	b.cs	6a28 <fwp_drop4+0x98>  // b.hs, b.nlast
    69bc:	d350fc22 	lsr	x2, x1, #16
    69c0:	f949fea3 	ldr	x3, [x21, #5112]
    69c4:	8b020842 	add	x2, x2, x2, lsl #2
    69c8:	d37df042 	lsl	x2, x2, #3
    69cc:	8b020064 	add	x4, x3, x2
    69d0:	f9401094 	ldr	x20, [x4, #32]
    69d4:	b40002b4 	cbz	x20, 6a28 <fwp_drop4+0x98>
    69d8:	38626862 	ldrb	w2, [x3, x2]
    69dc:	7100085f 	cmp	w2, #0x2
    69e0:	540007a0 	b.eq	6ad4 <fwp_drop4+0x144>  // b.none
    69e4:	7100045f 	cmp	w2, #0x1
    69e8:	54000201 	b.ne	6a28 <fwp_drop4+0x98>  // b.any
    69ec:	29430885 	ldp	w5, w2, [x4, #24]
    69f0:	92403c21 	and	x1, x1, #0xffff
    69f4:	9b057c21 	mul	x1, x1, x5
    69f8:	d360fc21 	lsr	x1, x1, #32
    69fc:	eb02003f 	cmp	x1, x2
    6a00:	54000142 	b.cs	6a28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a04:	8b010294 	add	x20, x20, x1
    6a08:	39400281 	ldrb	w1, [x20]
    6a0c:	340000e1 	cbz	w1, 6a28 <fwp_drop4+0x98>
    6a10:	7100043f 	cmp	w1, #0x1
    6a14:	54000120 	b.eq	6a38 <fwp_drop4+0xa8>  // b.none
    6a18:	7103fc3f 	cmp	w1, #0xff
    6a1c:	540007c0 	b.eq	6b14 <fwp_drop4+0x184>  // b.none
    6a20:	51000421 	sub	w1, w1, #0x1
    6a24:	39000281 	strb	w1, [x20]
    6a28:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a2c:	f94013f5 	ldr	x21, [sp, #32]
    6a30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a34:	d65f03c0 	ret
    6a38:	f9400001 	ldr	x1, [x0]
    6a3c:	b7f80581 	tbnz	x1, #63, 6aec <fwp_drop4+0x15c>
    6a40:	91154273 	add	x19, x19, #0x550
    6a44:	f949da61 	ldr	x1, [x19, #5040]
    6a48:	f949ee62 	ldr	x2, [x19, #5080]
    6a4c:	cb010001 	sub	x1, x0, x1
    6a50:	eb02403f 	cmp	x1, x2, lsl #16
    6a54:	54fffea2 	b.cs	6a28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a58:	d350fc22 	lsr	x2, x1, #16
    6a5c:	8b020842 	add	x2, x2, x2, lsl #2
    6a60:	d37df042 	lsl	x2, x2, #3
    6a64:	8b020065 	add	x5, x3, x2
    6a68:	f94010a4 	ldr	x4, [x5, #32]
    6a6c:	b4fffde4 	cbz	x4, 6a28 <fwp_drop4+0x98>
    6a70:	38626862 	ldrb	w2, [x3, x2]
    6a74:	7100085f 	cmp	w2, #0x2
    6a78:	54000220 	b.eq	6abc <fwp_drop4+0x12c>  // b.none
    6a7c:	7100045f 	cmp	w2, #0x1
    6a80:	54fffd41 	b.ne	6a28 <fwp_drop4+0x98>  // b.any
    6a84:	294308a3 	ldp	w3, w2, [x5, #24]
    6a88:	92403c21 	and	x1, x1, #0xffff
    6a8c:	9b037c21 	mul	x1, x1, x3
    6a90:	d360fc21 	lsr	x1, x1, #32
    6a94:	eb02003f 	cmp	x1, x2
    6a98:	54fffc82 	b.cs	6a28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6a9c:	8b010084 	add	x4, x4, x1
    6aa0:	39400081 	ldrb	w1, [x4]
    6aa4:	7100043f 	cmp	w1, #0x1
    6aa8:	54fffc01 	b.ne	6a28 <fwp_drop4+0x98>  // b.any
    6aac:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ab0:	f94013f5 	ldr	x21, [sp, #32]
    6ab4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ab8:	17fff592 	b	4100 <fwp_mem_free>
    6abc:	72003c3f 	tst	w1, #0xffff
    6ac0:	54ffff00 	b.eq	6aa0 <fwp_drop4+0x110>  // b.none
    6ac4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ac8:	f94013f5 	ldr	x21, [sp, #32]
    6acc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ad0:	d65f03c0 	ret
    6ad4:	72003c3f 	tst	w1, #0xffff
    6ad8:	54fff980 	b.eq	6a08 <fwp_drop4+0x78>  // b.none
    6adc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ae0:	f94013f5 	ldr	x21, [sp, #32]
    6ae4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ae8:	d65f03c0 	ret
    6aec:	f9400414 	ldr	x20, [x0, #8]
    6af0:	97fffb6c 	bl	58a0 <fwp_rc_free_arr>
    6af4:	91154260 	add	x0, x19, #0x550
    6af8:	f949d801 	ldr	x1, [x0, #5040]
    6afc:	f949ec00 	ldr	x0, [x0, #5080]
    6b00:	cb010281 	sub	x1, x20, x1
    6b04:	eb00403f 	cmp	x1, x0, lsl #16
    6b08:	54fff902 	b.cs	6a28 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b0c:	aa1403e0 	mov	x0, x20
    6b10:	17ffffab 	b	69bc <fwp_drop4+0x2c>
    6b14:	ca544680 	eor	x0, x20, x20, lsr #17
    6b18:	91154273 	add	x19, x19, #0x550
    6b1c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b20:	92401c00 	and	x0, x0, #0xff
    6b24:	910a2402 	add	x2, x0, #0x289
    6b28:	8b000e60 	add	x0, x19, x0, lsl #3
    6b2c:	8b020e62 	add	x2, x19, x2, lsl #3
    6b30:	f94a2400 	ldr	x0, [x0, #5192]
    6b34:	b50000a0 	cbnz	x0, 6b48 <fwp_drop4+0x1b8>
    6b38:	14000013 	b	6b84 <fwp_drop4+0x1f4>
    6b3c:	91004002 	add	x2, x0, #0x10
    6b40:	f9400800 	ldr	x0, [x0, #16]
    6b44:	b4000200 	cbz	x0, 6b84 <fwp_drop4+0x1f4>
    6b48:	f9400001 	ldr	x1, [x0]
    6b4c:	eb14003f 	cmp	x1, x20
    6b50:	54ffff61 	b.ne	6b3c <fwp_drop4+0x1ac>  // b.any
    6b54:	f9400041 	ldr	x1, [x2]
    6b58:	f9400420 	ldr	x0, [x1, #8]
    6b5c:	d1000400 	sub	x0, x0, #0x1
    6b60:	f9000420 	str	x0, [x1, #8]
    6b64:	f103f81f 	cmp	x0, #0xfe
    6b68:	54fff601 	b.ne	6a28 <fwp_drop4+0x98>  // b.any
    6b6c:	39400280 	ldrb	w0, [x20]
    6b70:	7103fc1f 	cmp	w0, #0xff
    6b74:	540000e0 	b.eq	6b90 <fwp_drop4+0x200>  // b.none
    6b78:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b7c:	39000280 	strb	w0, [x20]
    6b80:	17ffffaa 	b	6a28 <fwp_drop4+0x98>
    6b84:	b0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    6b88:	91264000 	add	x0, x0, #0x990
    6b8c:	97fff4a1 	bl	3e10 <fwp_trap>
    6b90:	aa1403e0 	mov	x0, x20
    6b94:	97fff4bf 	bl	3e90 <fwp_rc_forget_slot.part.0>
    6b98:	17fffff8 	b	6b78 <fwp_drop4+0x1e8>
    6b9c:	d503201f 	nop

0000000000006ba0 <fwp_caps161>:
    6ba0:	34000041 	cbz	w1, 6ba8 <fwp_caps161+0x8>
    6ba4:	d65f03c0 	ret
    6ba8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc90>
    6bac:	91154063 	add	x3, x3, #0x550
    6bb0:	f949d861 	ldr	x1, [x3, #5040]
    6bb4:	f949ec62 	ldr	x2, [x3, #5080]
    6bb8:	cb010001 	sub	x1, x0, x1
    6bbc:	eb02403f 	cmp	x1, x2, lsl #16
    6bc0:	54ffff22 	b.cs	6ba4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6bc4:	d350fc22 	lsr	x2, x1, #16
    6bc8:	f949fc65 	ldr	x5, [x3, #5112]
    6bcc:	8b020842 	add	x2, x2, x2, lsl #2
    6bd0:	d37df042 	lsl	x2, x2, #3
    6bd4:	8b0200a4 	add	x4, x5, x2
    6bd8:	f9401083 	ldr	x3, [x4, #32]
    6bdc:	b4fffe43 	cbz	x3, 6ba4 <fwp_caps161+0x4>
    6be0:	386268a2 	ldrb	w2, [x5, x2]
    6be4:	7100085f 	cmp	w2, #0x2
    6be8:	540001c0 	b.eq	6c20 <fwp_caps161+0x80>  // b.none
    6bec:	7100045f 	cmp	w2, #0x1
    6bf0:	54fffda1 	b.ne	6ba4 <fwp_caps161+0x4>  // b.any
    6bf4:	29430885 	ldp	w5, w2, [x4, #24]
    6bf8:	92403c21 	and	x1, x1, #0xffff
    6bfc:	9b057c21 	mul	x1, x1, x5
    6c00:	d360fc21 	lsr	x1, x1, #32
    6c04:	eb02003f 	cmp	x1, x2
    6c08:	54fffce2 	b.cs	6ba4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6c0c:	8b010063 	add	x3, x3, x1
    6c10:	39400061 	ldrb	w1, [x3]
    6c14:	7100043f 	cmp	w1, #0x1
    6c18:	54fffc61 	b.ne	6ba4 <fwp_caps161+0x4>  // b.any
    6c1c:	17fff539 	b	4100 <fwp_mem_free>
    6c20:	72003c3f 	tst	w1, #0xffff
    6c24:	54ffff60 	b.eq	6c10 <fwp_caps161+0x70>  // b.none
    6c28:	d65f03c0 	ret
    6c2c:	d503201f 	nop

0000000000006c30 <f12>:
    6c30:	d10483ff 	sub	sp, sp, #0x120
    6c34:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb38>
    6c38:	f947f442 	ldr	x2, [x2, #4072]
    6c3c:	a90b7bfd 	stp	x29, x30, [sp, #176]
    6c40:	9102c3fd 	add	x29, sp, #0xb0
    6c44:	a90e63f7 	stp	x23, x24, [sp, #224]
    6c48:	f0000157 	adrp	x23, 31000 <fwp_root_context+0xc90>
    6c4c:	911542e3 	add	x3, x23, #0x550
    6c50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    6c54:	d00000d6 	adrp	x22, 20000 <__data_start>
    6c58:	910102c4 	add	x4, x22, #0x40
    6c5c:	f949d861 	ldr	x1, [x3, #5040]
    6c60:	a90c53f3 	stp	x19, x20, [sp, #192]
    6c64:	d00000d3 	adrp	x19, 20000 <__data_start>
    6c68:	f949ec65 	ldr	x5, [x3, #5080]
    6c6c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    6c70:	91004273 	add	x19, x19, #0x10
    6c74:	a91073fb 	stp	x27, x28, [sp, #256]
    6c78:	910103f9 	add	x25, sp, #0x40
    6c7c:	9100e3f8 	add	x24, sp, #0x38
    6c80:	f9416086 	ldr	x6, [x4, #704]
    6c84:	fd008be8 	str	d8, [sp, #272]
    6c88:	f9400047 	ldr	x7, [x2]
    6c8c:	f90057e7 	str	x7, [sp, #168]
    6c90:	d2800007 	mov	x7, #0x0                   	// #0
    6c94:	90000015 	adrp	x21, 6000 <fwp_tape_finish+0xa0>
    6c98:	12800007 	mov	w7, #0xffffffff            	// #-1
    6c9c:	910182a2 	add	x2, x21, #0x60
    6ca0:	cb010261 	sub	x1, x19, x1
    6ca4:	b9003be7 	str	w7, [sp, #56]
    6ca8:	a9040be6 	stp	x6, x2, [sp, #64]
    6cac:	aa0003f4 	mov	x20, x0
    6cb0:	f9002bf8 	str	x24, [sp, #80]
    6cb4:	f9016099 	str	x25, [x4, #704]
    6cb8:	eb05403f 	cmp	x1, x5, lsl #16
    6cbc:	54000342 	b.cs	6d24 <f12+0xf4>  // b.hs, b.nlast
    6cc0:	d350fc20 	lsr	x0, x1, #16
    6cc4:	f949fc64 	ldr	x4, [x3, #5112]
    6cc8:	8b000800 	add	x0, x0, x0, lsl #2
    6ccc:	d37df002 	lsl	x2, x0, #3
    6cd0:	8b020083 	add	x3, x4, x2
    6cd4:	f9401060 	ldr	x0, [x3, #32]
    6cd8:	b4000260 	cbz	x0, 6d24 <f12+0xf4>
    6cdc:	38626882 	ldrb	w2, [x4, x2]
    6ce0:	7100085f 	cmp	w2, #0x2
    6ce4:	54000b60 	b.eq	6e50 <f12+0x220>  // b.none
    6ce8:	7100045f 	cmp	w2, #0x1
    6cec:	540001c1 	b.ne	6d24 <f12+0xf4>  // b.any
    6cf0:	29430864 	ldp	w4, w2, [x3, #24]
    6cf4:	92403c21 	and	x1, x1, #0xffff
    6cf8:	9b047c21 	mul	x1, x1, x4
    6cfc:	d360fc21 	lsr	x1, x1, #32
    6d00:	eb02003f 	cmp	x1, x2
    6d04:	54000102 	b.cs	6d24 <f12+0xf4>  // b.hs, b.nlast
    6d08:	8b010000 	add	x0, x0, x1
    6d0c:	39400001 	ldrb	w1, [x0]
    6d10:	340000a1 	cbz	w1, 6d24 <f12+0xf4>
    6d14:	7103f43f 	cmp	w1, #0xfd
    6d18:	540026a8 	b.hi	71ec <f12+0x5bc>  // b.pmore
    6d1c:	11000421 	add	w1, w1, #0x1
    6d20:	39000001 	strb	w1, [x0]
    6d24:	aa1303e0 	mov	x0, x19
    6d28:	97fffbe6 	bl	5cc0 <fwp_closure_drop>
    6d2c:	b40001b4 	cbz	x20, 6d60 <f12+0x130>
    6d30:	aa1403e1 	mov	x1, x20
    6d34:	d2800002 	mov	x2, #0x0                   	// #0
    6d38:	f9400821 	ldr	x1, [x1, #16]
    6d3c:	91000442 	add	x2, x2, #0x1
    6d40:	b5ffffc1 	cbnz	x1, 6d38 <f12+0x108>
    6d44:	aa0203f3 	mov	x19, x2
    6d48:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    6d4c:	eb00005f 	cmp	x2, x0
    6d50:	540000a9 	b.ls	6d64 <f12+0x134>  // b.plast
    6d54:	b0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    6d58:	9130e000 	add	x0, x0, #0xc38
    6d5c:	97fff42d 	bl	3e10 <fwp_trap>
    6d60:	d2800013 	mov	x19, #0x0                   	// #0
    6d64:	910102da 	add	x26, x22, #0x40
    6d68:	b942f740 	ldr	w0, [x26, #756]
    6d6c:	340012a0 	cbz	w0, 6fc0 <f12+0x390>
    6d70:	910102c0 	add	x0, x22, #0x40
    6d74:	f940401b 	ldr	x27, [x0, #128]
    6d78:	f9404c1a 	ldr	x26, [x0, #152]
    6d7c:	eb1b035f 	cmp	x26, x27
    6d80:	540006ea 	b.ge	6e5c <f12+0x22c>  // b.tcont
    6d84:	f94022c0 	ldr	x0, [x22, #64]
    6d88:	8b1a0741 	add	x1, x26, x26, lsl #1
    6d8c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6d90:	8b010b41 	add	x1, x26, x1, lsl #2
    6d94:	8b010c01 	add	x1, x0, x1, lsl #3
    6d98:	b9400420 	ldr	w0, [x1, #4]
    6d9c:	35000080 	cbnz	w0, 6dac <f12+0x17c>
    6da0:	b9400020 	ldr	w0, [x1]
    6da4:	6b02001f 	cmp	w0, w2
    6da8:	540005a9 	b.ls	6e5c <f12+0x22c>  // b.plast
    6dac:	9100075a 	add	x26, x26, #0x1
    6db0:	9101a021 	add	x1, x1, #0x68
    6db4:	eb1b035f 	cmp	x26, x27
    6db8:	54ffff01 	b.ne	6d98 <f12+0x168>  // b.any
    6dbc:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6dc0:	eb00037f 	cmp	x27, x0
    6dc4:	54001e6c 	b.gt	7190 <f12+0x560>
    6dc8:	910102c0 	add	x0, x22, #0x40
    6dcc:	f94022dc 	ldr	x28, [x22, #64]
    6dd0:	f9404800 	ldr	x0, [x0, #144]
    6dd4:	eb1b001f 	cmp	x0, x27
    6dd8:	54000241 	b.ne	6e20 <f12+0x1f0>  // b.any
    6ddc:	b400273b 	cbz	x27, 72c0 <f12+0x690>
    6de0:	d37ffb62 	lsl	x2, x27, #1
    6de4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    6de8:	eb00005f 	cmp	x2, x0
    6dec:	9a80d042 	csel	x2, x2, x0, le
    6df0:	8b020441 	add	x1, x2, x2, lsl #1
    6df4:	8b010841 	add	x1, x2, x1, lsl #2
    6df8:	d37df021 	lsl	x1, x1, #3
    6dfc:	aa1c03e0 	mov	x0, x28
    6e00:	f90007e2 	str	x2, [sp, #8]
    6e04:	97ffee77 	bl	27e0 <realloc@plt>
    6e08:	aa0003fc 	mov	x28, x0
    6e0c:	f94007e2 	ldr	x2, [sp, #8]
    6e10:	b4004740 	cbz	x0, 76f8 <f12+0xac8>
    6e14:	910102c0 	add	x0, x22, #0x40
    6e18:	f90022dc 	str	x28, [x22, #64]
    6e1c:	f9004802 	str	x2, [x0, #144]
    6e20:	8b1b0760 	add	x0, x27, x27, lsl #1
    6e24:	910102c1 	add	x1, x22, #0x40
    6e28:	4f000400 	movi	v0.4s, #0x0
    6e2c:	91000762 	add	x2, x27, #0x1
    6e30:	8b000b60 	add	x0, x27, x0, lsl #2
    6e34:	f9004022 	str	x2, [x1, #128]
    6e38:	8b000f80 	add	x0, x28, x0, lsl #3
    6e3c:	ad000000 	stp	q0, q0, [x0]
    6e40:	ad010000 	stp	q0, q0, [x0, #32]
    6e44:	ad020000 	stp	q0, q0, [x0, #64]
    6e48:	f900301f 	str	xzr, [x0, #96]
    6e4c:	14000007 	b	6e68 <f12+0x238>
    6e50:	72003c3f 	tst	w1, #0xffff
    6e54:	54fff681 	b.ne	6d24 <f12+0xf4>  // b.any
    6e58:	17ffffad 	b	6d0c <f12+0xdc>
    6e5c:	eb1b035f 	cmp	x26, x27
    6e60:	54fffae0 	b.eq	6dbc <f12+0x18c>  // b.none
    6e64:	f94022dc 	ldr	x28, [x22, #64]
    6e68:	8b1a075b 	add	x27, x26, x26, lsl #1
    6e6c:	b0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    6e70:	9125a000 	add	x0, x0, #0x968
    6e74:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    6e78:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    6e7c:	f900337f 	str	xzr, [x27, #96]
    6e80:	97ffeec0 	bl	2980 <getenv@plt>
    6e84:	b4000080 	cbz	x0, 6e94 <f12+0x264>
    6e88:	39400001 	ldrb	w1, [x0]
    6e8c:	7100c03f 	cmp	w1, #0x30
    6e90:	54000740 	b.eq	6f78 <f12+0x348>  // b.none
    6e94:	910102c0 	add	x0, x22, #0x40
    6e98:	f9403801 	ldr	x1, [x0, #112]
    6e9c:	b5000741 	cbnz	x1, 6f84 <f12+0x354>
    6ea0:	910102c2 	add	x2, x22, #0x40
    6ea4:	2f000400 	mvni	v0.2s, #0x0
    6ea8:	b9400363 	ldr	w3, [x27]
    6eac:	52800020 	mov	w0, #0x1                   	// #1
    6eb0:	91000744 	add	x4, x26, #0x1
    6eb4:	a900cf73 	stp	x19, x19, [x27, #8]
    6eb8:	0b000063 	add	w3, w3, w0
    6ebc:	f9416041 	ldr	x1, [x2, #704]
    6ec0:	29000363 	stp	w3, w0, [x27]
    6ec4:	f9002b7f 	str	xzr, [x27, #80]
    6ec8:	f9004c44 	str	x4, [x2, #152]
    6ecc:	fd002f60 	str	d0, [x27, #88]
    6ed0:	b4001541 	cbz	x1, 7178 <f12+0x548>
    6ed4:	910182b5 	add	x21, x21, #0x60
    6ed8:	14000003 	b	6ee4 <f12+0x2b4>
    6edc:	f9400021 	ldr	x1, [x1]
    6ee0:	b40014c1 	cbz	x1, 7178 <f12+0x548>
    6ee4:	f9400422 	ldr	x2, [x1, #8]
    6ee8:	eb15005f 	cmp	x2, x21
    6eec:	54ffff81 	b.ne	6edc <f12+0x2ac>  // b.any
    6ef0:	f9400820 	ldr	x0, [x1, #16]
    6ef4:	2a1a03e2 	mov	w2, w26
    6ef8:	b9400001 	ldr	w1, [x0]
    6efc:	f9002b60 	str	x0, [x27, #80]
    6f00:	b9005f61 	str	w1, [x27, #92]
    6f04:	37f80081 	tbnz	w1, #31, 6f14 <f12+0x2e4>
    6f08:	52800d05 	mov	w5, #0x68                  	// #104
    6f0c:	9b257021 	smaddl	x1, w1, w5, x28
    6f10:	b900583a 	str	w26, [x1, #88]
    6f14:	b9000002 	str	w2, [x0]
    6f18:	aa1403e0 	mov	x0, x20
    6f1c:	d2800002 	mov	x2, #0x0                   	// #0
    6f20:	b40005f4 	cbz	x20, 6fdc <f12+0x3ac>
    6f24:	d503201f 	nop
    6f28:	f9400800 	ldr	x0, [x0, #16]
    6f2c:	91000442 	add	x2, x2, #0x1
    6f30:	b5ffffc0 	cbnz	x0, 6f28 <f12+0x2f8>
    6f34:	aa1403e1 	mov	x1, x20
    6f38:	f9400821 	ldr	x1, [x1, #16]
    6f3c:	91000400 	add	x0, x0, #0x1
    6f40:	b5ffffc1 	cbnz	x1, 6f38 <f12+0x308>
    6f44:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    6f48:	eb01001f 	cmp	x0, x1
    6f4c:	54000108 	b.hi	6f6c <f12+0x33c>  // b.pmore
    6f50:	f100005f 	cmp	x2, #0x0
    6f54:	5400044d 	b.le	6fdc <f12+0x3ac>
    6f58:	eb00005f 	cmp	x2, x0
    6f5c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    6f60:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    6f64:	eb01027f 	cmp	x19, x1
    6f68:	540011a9 	b.ls	719c <f12+0x56c>  // b.plast
    6f6c:	b0000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    6f70:	9132e000 	add	x0, x0, #0xcb8
    6f74:	97fff3a7 	bl	3e10 <fwp_trap>
    6f78:	39400400 	ldrb	w0, [x0, #1]
    6f7c:	34fff920 	cbz	w0, 6ea0 <f12+0x270>
    6f80:	17ffffc5 	b	6e94 <f12+0x264>
    6f84:	3cc38002 	ldur	q2, [x0, #56]
    6f88:	9100e001 	add	x1, x0, #0x38
    6f8c:	3cc48001 	ldur	q1, [x0, #72]
    6f90:	f900381f 	str	xzr, [x0, #112]
    6f94:	4f000400 	movi	v0.4s, #0x0
    6f98:	ad010762 	stp	q2, q1, [x27, #32]
    6f9c:	a9458002 	ldp	x2, x0, [x0, #88]
    6fa0:	f9000f60 	str	x0, [x27, #24]
    6fa4:	f9401820 	ldr	x0, [x1, #48]
    6fa8:	f9002362 	str	x2, [x27, #64]
    6fac:	f9002760 	str	x0, [x27, #72]
    6fb0:	ad000020 	stp	q0, q0, [x1]
    6fb4:	3d800820 	str	q0, [x1, #32]
    6fb8:	f900183f 	str	xzr, [x1, #48]
    6fbc:	17ffffb9 	b	6ea0 <f12+0x270>
    6fc0:	f0ffffe0 	adrp	x0, 5000 <fwp_tape_reserve+0xdc>
    6fc4:	913d8000 	add	x0, x0, #0xf60
    6fc8:	94001216 	bl	b820 <atexit>
    6fcc:	35003960 	cbnz	w0, 76f8 <f12+0xac8>
    6fd0:	52800020 	mov	w0, #0x1                   	// #1
    6fd4:	b902f740 	str	w0, [x26, #756]
    6fd8:	17ffff66 	b	6d70 <f12+0x140>
    6fdc:	d3707c63 	ubfiz	x3, x3, #16, #32
    6fe0:	52800041 	mov	w1, #0x2                   	// #2
    6fe4:	aa040075 	orr	x21, x3, x4
    6fe8:	d2800100 	mov	x0, #0x8                   	// #8
    6fec:	97fff701 	bl	4bf0 <fwp_heap_alloc>
    6ff0:	aa0003fa 	mov	x26, x0
    6ff4:	911542e0 	add	x0, x23, #0x550
    6ff8:	f900035f 	str	xzr, [x26]
    6ffc:	f949d801 	ldr	x1, [x0, #5040]
    7000:	f949ec00 	ldr	x0, [x0, #5080]
    7004:	cb010341 	sub	x1, x26, x1
    7008:	eb00403f 	cmp	x1, x0, lsl #16
    700c:	54000ea2 	b.cs	71e0 <f12+0x5b0>  // b.hs, b.nlast
    7010:	d2800013 	mov	x19, #0x0                   	// #0
    7014:	911542e2 	add	x2, x23, #0x550
    7018:	d350fc20 	lsr	x0, x1, #16
    701c:	8b000800 	add	x0, x0, x0, lsl #2
    7020:	f949fc43 	ldr	x3, [x2, #5112]
    7024:	d37df002 	lsl	x2, x0, #3
    7028:	8b020060 	add	x0, x3, x2
    702c:	f940101b 	ldr	x27, [x0, #32]
    7030:	b400025b 	cbz	x27, 7078 <f12+0x448>
    7034:	38626862 	ldrb	w2, [x3, x2]
    7038:	7100085f 	cmp	w2, #0x2
    703c:	54000a40 	b.eq	7184 <f12+0x554>  // b.none
    7040:	7100045f 	cmp	w2, #0x1
    7044:	540001a1 	b.ne	7078 <f12+0x448>  // b.any
    7048:	29430002 	ldp	w2, w0, [x0, #24]
    704c:	92403c21 	and	x1, x1, #0xffff
    7050:	9b027c21 	mul	x1, x1, x2
    7054:	d360fc21 	lsr	x1, x1, #32
    7058:	eb00003f 	cmp	x1, x0
    705c:	540000e2 	b.cs	7078 <f12+0x448>  // b.hs, b.nlast
    7060:	8b01037b 	add	x27, x27, x1
    7064:	39400360 	ldrb	w0, [x27]
    7068:	7103fc1f 	cmp	w0, #0xff
    706c:	540032a0 	b.eq	76c0 <f12+0xa90>  // b.none
    7070:	52800020 	mov	w0, #0x1                   	// #1
    7074:	39000360 	strb	w0, [x27]
    7078:	b4000233 	cbz	x19, 70bc <f12+0x48c>
    707c:	d3607ea4 	lsl	x4, x21, #32
    7080:	aa1403e0 	mov	x0, x20
    7084:	f9400685 	ldr	x5, [x20, #8]
    7088:	aa0403e3 	mov	x3, x4
    708c:	91002342 	add	x2, x26, #0x8
    7090:	d2800001 	mov	x1, #0x0                   	// #0
    7094:	14000005 	b	70a8 <f12+0x478>
    7098:	f9400405 	ldr	x5, [x0, #8]
    709c:	ab040023 	adds	x3, x1, x4
    70a0:	91004042 	add	x2, x2, #0x10
    70a4:	54006726 	b.vs	7d88 <f12+0x1158>
    70a8:	a9000c45 	stp	x5, x3, [x2]
    70ac:	91000421 	add	x1, x1, #0x1
    70b0:	f9400800 	ldr	x0, [x0, #16]
    70b4:	eb01027f 	cmp	x19, x1
    70b8:	54ffff08 	b.hi	7098 <f12+0x468>  // b.pmore
    70bc:	f9400340 	ldr	x0, [x26]
    70c0:	f100041f 	cmp	x0, #0x1
    70c4:	540008e9 	b.ls	71e0 <f12+0x5b0>  // b.plast
    70c8:	d341fc00 	lsr	x0, x0, #1
    70cc:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    70d0:	d100041c 	sub	x28, x0, #0x1
    70d4:	eb01039f 	cmp	x28, x1
    70d8:	54fff4a8 	b.hi	6f6c <f12+0x33c>  // b.pmore
    70dc:	b400083c 	cbz	x28, 71e0 <f12+0x5b0>
    70e0:	d1002341 	sub	x1, x26, #0x8
    70e4:	91002353 	add	x19, x26, #0x8
    70e8:	8b00103b 	add	x27, x1, x0, lsl #4
    70ec:	d503201f 	nop
    70f0:	f9400660 	ldr	x0, [x19, #8]
    70f4:	f9400e61 	ldr	x1, [x19, #24]
    70f8:	fd400260 	ldr	d0, [x19]
    70fc:	fd400a61 	ldr	d1, [x19, #16]
    7100:	97fff869 	bl	52a4 <w107>
    7104:	a9000660 	stp	x0, x1, [x19]
    7108:	91004273 	add	x19, x19, #0x10
    710c:	eb1b027f 	cmp	x19, x27
    7110:	54ffff01 	b.ne	70f0 <f12+0x4c0>  // b.any
    7114:	aa1a03fb 	mov	x27, x26
    7118:	d37ffb93 	lsl	x19, x28, #1
    711c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    7120:	d280001c 	mov	x28, #0x0                   	// #0
    7124:	f8010773 	str	x19, [x27], #16
    7128:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    712c:	aa0303e0 	mov	x0, x3
    7130:	91000b9c 	add	x28, x28, #0x2
    7134:	97fff80b 	bl	5160 <f128.constprop.0>
    7138:	aa0003e3 	mov	x3, x0
    713c:	eb13039f 	cmp	x28, x19
    7140:	54ffff43 	b.cc	7128 <f12+0x4f8>  // b.lo, b.ul, b.last
    7144:	aa1a03e0 	mov	x0, x26
    7148:	93407eb5 	sxtw	x21, w21
    714c:	f90007e3 	str	x3, [sp, #8]
    7150:	97fffe10 	bl	6990 <fwp_drop4>
    7154:	aa1503e0 	mov	x0, x21
    7158:	97fff532 	bl	4620 <fwp_tape_of>
    715c:	f940301b 	ldr	x27, [x0, #96]
    7160:	aa0003e5 	mov	x5, x0
    7164:	f94007e3 	ldr	x3, [sp, #8]
    7168:	b400047b 	cbz	x27, 71f4 <f12+0x5c4>
    716c:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    7170:	912ea000 	add	x0, x0, #0xba8
    7174:	97fff327 	bl	3e10 <fwp_trap>
    7178:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    717c:	91322000 	add	x0, x0, #0xc88
    7180:	97fff324 	bl	3e10 <fwp_trap>
    7184:	72003c3f 	tst	w1, #0xffff
    7188:	54fff781 	b.ne	7078 <f12+0x448>  // b.any
    718c:	17ffffb6 	b	7064 <f12+0x434>
    7190:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    7194:	91316000 	add	x0, x0, #0xc58
    7198:	97fff31e 	bl	3e10 <fwp_trap>
    719c:	d37ffa7b 	lsl	x27, x19, #1
    71a0:	d3707c63 	ubfiz	x3, x3, #16, #32
    71a4:	91000760 	add	x0, x27, #0x1
    71a8:	52800041 	mov	w1, #0x2                   	// #2
    71ac:	aa040075 	orr	x21, x3, x4
    71b0:	d37df000 	lsl	x0, x0, #3
    71b4:	97fff68f 	bl	4bf0 <fwp_heap_alloc>
    71b8:	aa0003fa 	mov	x26, x0
    71bc:	911542e1 	add	x1, x23, #0x550
    71c0:	aa0103e0 	mov	x0, x1
    71c4:	f900035b 	str	x27, [x26]
    71c8:	f949d821 	ldr	x1, [x1, #5040]
    71cc:	f949ec00 	ldr	x0, [x0, #5080]
    71d0:	cb010341 	sub	x1, x26, x1
    71d4:	eb00403f 	cmp	x1, x0, lsl #16
    71d8:	54fff1e3 	b.cc	7014 <f12+0x3e4>  // b.lo, b.ul, b.last
    71dc:	b5fff513 	cbnz	x19, 707c <f12+0x44c>
    71e0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    71e4:	f900035f 	str	xzr, [x26]
    71e8:	17ffffd7 	b	7144 <f12+0x514>
    71ec:	97fff43e 	bl	42e4 <fwp_rc_wide_dup>
    71f0:	17fffecd 	b	6d24 <f12+0xf4>
    71f4:	f9000fe3 	str	x3, [sp, #24]
    71f8:	97ffef46 	bl	2f10 <fwp_tape_unlink_scope>
    71fc:	a94288bc 	ldp	x28, x2, [x5, #40]
    7200:	f90007e2 	str	x2, [sp, #8]
    7204:	f9401ca2 	ldr	x2, [x5, #56]
    7208:	b90004bf 	str	wzr, [x5, #4]
    720c:	b94000a1 	ldr	w1, [x5]
    7210:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    7214:	f9000be2 	str	x2, [sp, #16]
    7218:	a940acba 	ldp	x26, x11, [x5, #8]
    721c:	6b00003f 	cmp	w1, w0
    7220:	a941eca9 	ldp	x9, x27, [x5, #24]
    7224:	f9400fe3 	ldr	x3, [sp, #24]
    7228:	f94020a4 	ldr	x4, [x5, #64]
    722c:	f94024a2 	ldr	x2, [x5, #72]
    7230:	54000108 	b.hi	7250 <f12+0x620>  // b.pmore
    7234:	910102c1 	add	x1, x22, #0x40
    7238:	92403ea0 	and	x0, x21, #0xffff
    723c:	d1000400 	sub	x0, x0, #0x1
    7240:	f9404c2a 	ldr	x10, [x1, #152]
    7244:	eb0a001f 	cmp	x0, x10
    7248:	5400004a 	b.ge	7250 <f12+0x620>  // b.tcont
    724c:	f9004c20 	str	x0, [x1, #152]
    7250:	4f000400 	movi	v0.4s, #0x0
    7254:	910102c1 	add	x1, x22, #0x40
    7258:	90ffffe0 	adrp	x0, 3000 <fwp_segv+0x10>
    725c:	9133c000 	add	x0, x0, #0xcf0
    7260:	f9000cbf 	str	xzr, [x5, #24]
    7264:	910163e6 	add	x6, sp, #0x58
    7268:	f941602a 	ldr	x10, [x1, #704]
    726c:	3c8080a0 	stur	q0, [x5, #8]
    7270:	9101c3f3 	add	x19, sp, #0x70
    7274:	a90583ea 	stp	x10, x0, [sp, #88]
    7278:	f94007e0 	ldr	x0, [sp, #8]
    727c:	ad0100a0 	stp	q0, q0, [x5, #32]
    7280:	f90043e0 	str	x0, [sp, #128]
    7284:	f9400be0 	ldr	x0, [sp, #16]
    7288:	f9000fe6 	str	x6, [sp, #24]
    728c:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    7290:	a906eff3 	stp	x19, x27, [sp, #104]
    7294:	f9003ffc 	str	x28, [sp, #120]
    7298:	f90047e0 	str	x0, [sp, #136]
    729c:	a90927e4 	stp	x4, x9, [sp, #144]
    72a0:	f90053e2 	str	x2, [sp, #160]
    72a4:	f9016026 	str	x6, [x1, #704]
    72a8:	b7f82083 	tbnz	x3, #63, 76b8 <f12+0xa88>
    72ac:	eb8382bf 	cmp	x21, x3, asr #32
    72b0:	540000e0 	b.eq	72cc <f12+0x69c>  // b.none
    72b4:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    72b8:	912d8000 	add	x0, x0, #0xb60
    72bc:	97fff2d5 	bl	3e10 <fwp_trap>
    72c0:	d2800d01 	mov	x1, #0x68                  	// #104
    72c4:	d2800022 	mov	x2, #0x1                   	// #1
    72c8:	17fffecd 	b	6dfc <f12+0x1cc>
    72cc:	92407c60 	and	x0, x3, #0xffffffff
    72d0:	eb00035f 	cmp	x26, x0
    72d4:	9a80c755 	csinc	x21, x26, x0, gt
    72d8:	eb23417f 	cmp	x11, w3, uxtw
    72dc:	54001f8d 	b.le	76cc <f12+0xa9c>
    72e0:	eb15005f 	cmp	x2, x21
    72e4:	54001faa 	b.ge	76d8 <f12+0xaa8>  // b.tcont
    72e8:	f100005f 	cmp	x2, #0x0
    72ec:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    72f0:	9a951042 	csel	x2, x2, x21, ne	// ne = any
    72f4:	14000004 	b	7304 <f12+0x6d4>
    72f8:	eb01005f 	cmp	x2, x1
    72fc:	d37ff842 	lsl	x2, x2, #1
    7300:	9a95d042 	csel	x2, x2, x21, le
    7304:	eb15005f 	cmp	x2, x21
    7308:	54ffff8b 	b.lt	72f8 <f12+0x6c8>  // b.tstop
    730c:	f90017e3 	str	x3, [sp, #40]
    7310:	b40027a4 	cbz	x4, 7804 <f12+0xbd4>
    7314:	aa0403e0 	mov	x0, x4
    7318:	d37df041 	lsl	x1, x2, #3
    731c:	f90013e2 	str	x2, [sp, #32]
    7320:	97ffed30 	bl	27e0 <realloc@plt>
    7324:	a9420fe2 	ldp	x2, x3, [sp, #32]
    7328:	aa0003e4 	mov	x4, x0
    732c:	b4001d64 	cbz	x4, 76d8 <f12+0xaa8>
    7330:	f9004be4 	str	x4, [sp, #144]
    7334:	f90053e2 	str	x2, [sp, #160]
    7338:	b5001b15 	cbnz	x21, 7698 <f12+0xa68>
    733c:	b7f800c3 	tbnz	x3, #63, 7354 <f12+0x724>
    7340:	92407c63 	and	x3, x3, #0xffffffff
    7344:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7348:	fc637880 	ldr	d0, [x4, x3, lsl #3]
    734c:	1e612800 	fadd	d0, d0, d1
    7350:	fc237880 	str	d0, [x4, x3, lsl #3]
    7354:	d10006a0 	sub	x0, x21, #0x1
    7358:	d1000743 	sub	x3, x26, #0x1
    735c:	eb00035f 	cmp	x26, x0
    7360:	540003ec 	b.gt	73dc <f12+0x7ac>
    7364:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    7368:	1e602008 	fcmp	d0, #0.0
    736c:	54000320 	b.eq	73d0 <f12+0x7a0>  // b.none
    7370:	cb1a0be1 	neg	x1, x26, lsl #2
    7374:	cb1a03e5 	neg	x5, x26
    7378:	8b010362 	add	x2, x27, x1
    737c:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    7380:	37f80122 	tbnz	w2, #31, 73a4 <f12+0x774>
    7384:	f94007e6 	ldr	x6, [sp, #8]
    7388:	93407c42 	sxtw	x2, w2
    738c:	8b050cc9 	add	x9, x6, x5, lsl #3
    7390:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    7394:	fc607922 	ldr	d2, [x9, x0, lsl #3]
    7398:	1e620802 	fmul	d2, d0, d2
    739c:	1e622821 	fadd	d1, d1, d2
    73a0:	fc227881 	str	d1, [x4, x2, lsl #3]
    73a4:	8b010381 	add	x1, x28, x1
    73a8:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    73ac:	37f80121 	tbnz	w1, #31, 73d0 <f12+0x7a0>
    73b0:	f9400be2 	ldr	x2, [sp, #16]
    73b4:	93407c21 	sxtw	x1, w1
    73b8:	8b050c45 	add	x5, x2, x5, lsl #3
    73bc:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    73c0:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    73c4:	1e620800 	fmul	d0, d0, d2
    73c8:	1e602820 	fadd	d0, d1, d0
    73cc:	fc217880 	str	d0, [x4, x1, lsl #3]
    73d0:	d1000400 	sub	x0, x0, #0x1
    73d4:	eb00007f 	cmp	x3, x0
    73d8:	54fffc61 	b.ne	7364 <f12+0x734>  // b.any
    73dc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    73e0:	eb00035f 	cmp	x26, x0
    73e4:	54001a28 	b.hi	7728 <f12+0xaf8>  // b.pmore
    73e8:	91000740 	add	x0, x26, #0x1
    73ec:	52800041 	mov	w1, #0x2                   	// #2
    73f0:	f90007e4 	str	x4, [sp, #8]
    73f4:	d37df000 	lsl	x0, x0, #3
    73f8:	97fff5fe 	bl	4bf0 <fwp_heap_alloc>
    73fc:	aa0003f5 	mov	x21, x0
    7400:	f800841a 	str	x26, [x0], #8
    7404:	f94007e4 	ldr	x4, [sp, #8]
    7408:	d2800001 	mov	x1, #0x0                   	// #0
    740c:	b40000da 	cbz	x26, 7424 <f12+0x7f4>
    7410:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    7414:	f8217802 	str	x2, [x0, x1, lsl #3]
    7418:	91000421 	add	x1, x1, #0x1
    741c:	eb01035f 	cmp	x26, x1
    7420:	54ffff81 	b.ne	7410 <f12+0x7e0>  // b.any
    7424:	910102c1 	add	x1, x22, #0x40
    7428:	f9400fe2 	ldr	x2, [sp, #24]
    742c:	f9416020 	ldr	x0, [x1, #704]
    7430:	eb02001f 	cmp	x0, x2
    7434:	54004ac1 	b.ne	7d8c <f12+0x115c>  // b.any
    7438:	f9402ffa 	ldr	x26, [sp, #88]
    743c:	aa1303e0 	mov	x0, x19
    7440:	f901603a 	str	x26, [x1, #704]
    7444:	97fff22b 	bl	3cf0 <fwp_tape_buffers_release>
    7448:	911542e2 	add	x2, x23, #0x550
    744c:	f949d841 	ldr	x1, [x2, #5040]
    7450:	f949ec40 	ldr	x0, [x2, #5080]
    7454:	cb0102a1 	sub	x1, x21, x1
    7458:	eb00403f 	cmp	x1, x0, lsl #16
    745c:	54000322 	b.cs	74c0 <f12+0x890>  // b.hs, b.nlast
    7460:	d350fc20 	lsr	x0, x1, #16
    7464:	f949fc43 	ldr	x3, [x2, #5112]
    7468:	8b000800 	add	x0, x0, x0, lsl #2
    746c:	d37df002 	lsl	x2, x0, #3
    7470:	8b020060 	add	x0, x3, x2
    7474:	f9401013 	ldr	x19, [x0, #32]
    7478:	b4000253 	cbz	x19, 74c0 <f12+0x890>
    747c:	38626862 	ldrb	w2, [x3, x2]
    7480:	7100085f 	cmp	w2, #0x2
    7484:	54001ba0 	b.eq	77f8 <f12+0xbc8>  // b.none
    7488:	7100045f 	cmp	w2, #0x1
    748c:	540001a1 	b.ne	74c0 <f12+0x890>  // b.any
    7490:	29430002 	ldp	w2, w0, [x0, #24]
    7494:	92403c21 	and	x1, x1, #0xffff
    7498:	9b027c21 	mul	x1, x1, x2
    749c:	d360fc21 	lsr	x1, x1, #32
    74a0:	eb00003f 	cmp	x1, x0
    74a4:	540000e2 	b.cs	74c0 <f12+0x890>  // b.hs, b.nlast
    74a8:	8b010273 	add	x19, x19, x1
    74ac:	39400260 	ldrb	w0, [x19]
    74b0:	7103fc1f 	cmp	w0, #0xff
    74b4:	54004600 	b.eq	7d74 <f12+0x1144>  // b.none
    74b8:	52800020 	mov	w0, #0x1                   	// #1
    74bc:	39000260 	strb	w0, [x19]
    74c0:	eb19035f 	cmp	x26, x25
    74c4:	54004641 	b.ne	7d8c <f12+0x115c>  // b.any
    74c8:	f94023e1 	ldr	x1, [sp, #64]
    74cc:	910102d6 	add	x22, x22, #0x40
    74d0:	aa1803e0 	mov	x0, x24
    74d4:	f90162c1 	str	x1, [x22, #704]
    74d8:	97fffae2 	bl	6060 <fwp_tape_scope_release>
    74dc:	f94002a0 	ldr	x0, [x21]
    74e0:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    74e4:	b7f81360 	tbnz	x0, #63, 7750 <f12+0xb20>
    74e8:	911542e2 	add	x2, x23, #0x550
    74ec:	f949d840 	ldr	x0, [x2, #5040]
    74f0:	f949ec41 	ldr	x1, [x2, #5080]
    74f4:	cb0002a0 	sub	x0, x21, x0
    74f8:	eb01401f 	cmp	x0, x1, lsl #16
    74fc:	540012a2 	b.cs	7750 <f12+0xb20>  // b.hs, b.nlast
    7500:	d350fc01 	lsr	x1, x0, #16
    7504:	f949fc44 	ldr	x4, [x2, #5112]
    7508:	8b010821 	add	x1, x1, x1, lsl #2
    750c:	d37df021 	lsl	x1, x1, #3
    7510:	8b010083 	add	x3, x4, x1
    7514:	f9401062 	ldr	x2, [x3, #32]
    7518:	b40011c2 	cbz	x2, 7750 <f12+0xb20>
    751c:	38616881 	ldrb	w1, [x4, x1]
    7520:	7100083f 	cmp	w1, #0x2
    7524:	54001120 	b.eq	7748 <f12+0xb18>  // b.none
    7528:	7100043f 	cmp	w1, #0x1
    752c:	54001121 	b.ne	7750 <f12+0xb20>  // b.any
    7530:	29430464 	ldp	w4, w1, [x3, #24]
    7534:	92403c00 	and	x0, x0, #0xffff
    7538:	9b047c00 	mul	x0, x0, x4
    753c:	d360fc00 	lsr	x0, x0, #32
    7540:	eb01001f 	cmp	x0, x1
    7544:	54001062 	b.cs	7750 <f12+0xb20>  // b.hs, b.nlast
    7548:	8b000042 	add	x2, x2, x0
    754c:	39400040 	ldrb	w0, [x2]
    7550:	7100041f 	cmp	w0, #0x1
    7554:	54000fe1 	b.ne	7750 <f12+0xb20>  // b.any
    7558:	aa1503f8 	mov	x24, x21
    755c:	aa1503f6 	mov	x22, x21
    7560:	d2800000 	mov	x0, #0x0                   	// #0
    7564:	910022c2 	add	x2, x22, #0x8
    7568:	d2800001 	mov	x1, #0x0                   	// #0
    756c:	b40001f9 	cbz	x25, 75a8 <f12+0x978>
    7570:	b0000023 	adrp	x3, c000 <_IO_stdin_used+0x7b0>
    7574:	910022a4 	add	x4, x21, #0x8
    7578:	fd429461 	ldr	d1, [x3, #1320]
    757c:	f94002a5 	ldr	x5, [x21]
    7580:	aa0403e3 	mov	x3, x4
    7584:	b7f80de5 	tbnz	x5, #63, 7740 <f12+0xb10>
    7588:	f9400305 	ldr	x5, [x24]
    758c:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    7590:	b7f80d25 	tbnz	x5, #63, 7734 <f12+0xb04>
    7594:	1e600820 	fmul	d0, d1, d0
    7598:	91000421 	add	x1, x1, #0x1
    759c:	fc008440 	str	d0, [x2], #8
    75a0:	eb01033f 	cmp	x25, x1
    75a4:	54fffec1 	b.ne	757c <f12+0x94c>  // b.any
    75a8:	97fffcfa 	bl	6990 <fwp_drop4>
    75ac:	b4003db4 	cbz	x20, 7d60 <f12+0x1130>
    75b0:	aa1403e0 	mov	x0, x20
    75b4:	d2800013 	mov	x19, #0x0                   	// #0
    75b8:	f9400800 	ldr	x0, [x0, #16]
    75bc:	91000673 	add	x19, x19, #0x1
    75c0:	b5ffffc0 	cbnz	x0, 75b8 <f12+0x988>
    75c4:	f9400300 	ldr	x0, [x24]
    75c8:	9240f815 	and	x21, x0, #0x7fffffffffffffff
    75cc:	b7f81300 	tbnz	x0, #63, 782c <f12+0xbfc>
    75d0:	911542e1 	add	x1, x23, #0x550
    75d4:	f949d820 	ldr	x0, [x1, #5040]
    75d8:	f949ec22 	ldr	x2, [x1, #5080]
    75dc:	cb0002c0 	sub	x0, x22, x0
    75e0:	eb02401f 	cmp	x0, x2, lsl #16
    75e4:	54001222 	b.cs	7828 <f12+0xbf8>  // b.hs, b.nlast
    75e8:	d350fc02 	lsr	x2, x0, #16
    75ec:	d2800503 	mov	x3, #0x28                  	// #40
    75f0:	f949fc24 	ldr	x4, [x1, #5112]
    75f4:	9b037c42 	mul	x2, x2, x3
    75f8:	8b020083 	add	x3, x4, x2
    75fc:	f9401061 	ldr	x1, [x3, #32]
    7600:	b4001141 	cbz	x1, 7828 <f12+0xbf8>
    7604:	38626882 	ldrb	w2, [x4, x2]
    7608:	7100085f 	cmp	w2, #0x2
    760c:	540010a0 	b.eq	7820 <f12+0xbf0>  // b.none
    7610:	7100045f 	cmp	w2, #0x1
    7614:	540010a1 	b.ne	7828 <f12+0xbf8>  // b.any
    7618:	29430864 	ldp	w4, w2, [x3, #24]
    761c:	92403c00 	and	x0, x0, #0xffff
    7620:	9b047c00 	mul	x0, x0, x4
    7624:	d360fc00 	lsr	x0, x0, #32
    7628:	eb02001f 	cmp	x0, x2
    762c:	54000fe2 	b.cs	7828 <f12+0xbf8>  // b.hs, b.nlast
    7630:	8b000021 	add	x1, x1, x0
    7634:	39400039 	ldrb	w25, [x1]
    7638:	7100073f 	cmp	w25, #0x1
    763c:	54000f61 	b.ne	7828 <f12+0xbf8>  // b.any
    7640:	9100231b 	add	x27, x24, #0x8
    7644:	eb15027f 	cmp	x19, x21
    7648:	9a959273 	csel	x19, x19, x21, ls	// ls = plast
    764c:	b4002553 	cbz	x19, 7af4 <f12+0xec4>
    7650:	d37df264 	lsl	x4, x19, #3
    7654:	aa1403e1 	mov	x1, x20
    7658:	910022c3 	add	x3, x22, #0x8
    765c:	d2800000 	mov	x0, #0x0                   	// #0
    7660:	14000009 	b	7684 <f12+0xa54>
    7664:	fc606841 	ldr	d1, [x2, x0]
    7668:	fd400420 	ldr	d0, [x1, #8]
    766c:	1e613800 	fsub	d0, d0, d1
    7670:	fc206b60 	str	d0, [x27, x0]
    7674:	91002000 	add	x0, x0, #0x8
    7678:	f9400821 	ldr	x1, [x1, #16]
    767c:	eb04001f 	cmp	x0, x4
    7680:	54001020 	b.eq	7884 <f12+0xc54>  // b.none
    7684:	f9400305 	ldr	x5, [x24]
    7688:	aa0303e2 	mov	x2, x3
    768c:	b6fffec5 	tbz	x5, #63, 7664 <f12+0xa34>
    7690:	f9400ac2 	ldr	x2, [x22, #16]
    7694:	17fffff4 	b	7664 <f12+0xa34>
    7698:	aa0403e0 	mov	x0, x4
    769c:	d37df2a2 	lsl	x2, x21, #3
    76a0:	52800001 	mov	w1, #0x0                   	// #0
    76a4:	f90013e3 	str	x3, [sp, #32]
    76a8:	97ffec46 	bl	27c0 <memset@plt>
    76ac:	aa0003e4 	mov	x4, x0
    76b0:	f94013e3 	ldr	x3, [sp, #32]
    76b4:	17ffff22 	b	733c <f12+0x70c>
    76b8:	aa1a03f5 	mov	x21, x26
    76bc:	17ffff09 	b	72e0 <f12+0x6b0>
    76c0:	aa1b03e0 	mov	x0, x27
    76c4:	97fff1f3 	bl	3e90 <fwp_rc_forget_slot.part.0>
    76c8:	17fffe6a 	b	7070 <f12+0x440>
    76cc:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    76d0:	912f6000 	add	x0, x0, #0xbd8
    76d4:	97fff1cf 	bl	3e10 <fwp_trap>
    76d8:	f10002bf 	cmp	x21, #0x0
    76dc:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    76e0:	54ffe2c1 	b.ne	7338 <f12+0x708>  // b.any
    76e4:	f9402fe1 	ldr	x1, [sp, #88]
    76e8:	910102d6 	add	x22, x22, #0x40
    76ec:	aa1303e0 	mov	x0, x19
    76f0:	f90162c1 	str	x1, [x22, #704]
    76f4:	97fff17f 	bl	3cf0 <fwp_tape_buffers_release>
    76f8:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb38>
    76fc:	f947e863 	ldr	x3, [x3, #4048]
    7700:	d2800262 	mov	x2, #0x13                  	// #19
    7704:	d2800021 	mov	x1, #0x1                   	// #1
    7708:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    770c:	91216000 	add	x0, x0, #0x858
    7710:	f9400063 	ldr	x3, [x3]
    7714:	97ffec77 	bl	28f0 <fwrite@plt>
    7718:	d2800000 	mov	x0, #0x0                   	// #0
    771c:	97ffec81 	bl	2920 <fflush@plt>
    7720:	52800cc0 	mov	w0, #0x66                  	// #102
    7724:	97ffec8f 	bl	2960 <_Exit@plt>
    7728:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    772c:	91332000 	add	x0, x0, #0xcc8
    7730:	97fff1b8 	bl	3e10 <fwp_trap>
    7734:	90000020 	adrp	x0, b000 <fwp_main_thread+0x1730>
    7738:	91336000 	add	x0, x0, #0xcd8
    773c:	97fff1b5 	bl	3e10 <fwp_trap>
    7740:	f9400aa3 	ldr	x3, [x21, #16]
    7744:	17ffff91 	b	7588 <f12+0x958>
    7748:	72003c1f 	tst	w0, #0xffff
    774c:	54fff000 	b.eq	754c <f12+0x91c>  // b.none
    7750:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7754:	eb00033f 	cmp	x25, x0
    7758:	54fffe88 	b.hi	7728 <f12+0xaf8>  // b.pmore
    775c:	91000720 	add	x0, x25, #0x1
    7760:	52800021 	mov	w1, #0x1                   	// #1
    7764:	d37df000 	lsl	x0, x0, #3
    7768:	97fff522 	bl	4bf0 <fwp_heap_alloc>
    776c:	911542e2 	add	x2, x23, #0x550
    7770:	f9000019 	str	x25, [x0]
    7774:	aa0003f8 	mov	x24, x0
    7778:	aa0003f6 	mov	x22, x0
    777c:	f949d841 	ldr	x1, [x2, #5040]
    7780:	f949ec40 	ldr	x0, [x2, #5080]
    7784:	cb010301 	sub	x1, x24, x1
    7788:	eb00403f 	cmp	x1, x0, lsl #16
    778c:	54000322 	b.cs	77f0 <f12+0xbc0>  // b.hs, b.nlast
    7790:	d350fc20 	lsr	x0, x1, #16
    7794:	d2800504 	mov	x4, #0x28                  	// #40
    7798:	f949fc43 	ldr	x3, [x2, #5112]
    779c:	9b047c00 	mul	x0, x0, x4
    77a0:	8b000062 	add	x2, x3, x0
    77a4:	f9401053 	ldr	x19, [x2, #32]
    77a8:	b4000253 	cbz	x19, 77f0 <f12+0xbc0>
    77ac:	38606860 	ldrb	w0, [x3, x0]
    77b0:	7100081f 	cmp	w0, #0x2
    77b4:	54002ce0 	b.eq	7d50 <f12+0x1120>  // b.none
    77b8:	7100041f 	cmp	w0, #0x1
    77bc:	540001a1 	b.ne	77f0 <f12+0xbc0>  // b.any
    77c0:	29430043 	ldp	w3, w0, [x2, #24]
    77c4:	92403c21 	and	x1, x1, #0xffff
    77c8:	9b037c21 	mul	x1, x1, x3
    77cc:	d360fc21 	lsr	x1, x1, #32
    77d0:	eb00003f 	cmp	x1, x0
    77d4:	540000e2 	b.cs	77f0 <f12+0xbc0>  // b.hs, b.nlast
    77d8:	8b010273 	add	x19, x19, x1
    77dc:	39400260 	ldrb	w0, [x19]
    77e0:	7103fc1f 	cmp	w0, #0xff
    77e4:	54002b00 	b.eq	7d44 <f12+0x1114>  // b.none
    77e8:	52800020 	mov	w0, #0x1                   	// #1
    77ec:	39000260 	strb	w0, [x19]
    77f0:	aa1503e0 	mov	x0, x21
    77f4:	17ffff5c 	b	7564 <f12+0x934>
    77f8:	72003c3f 	tst	w1, #0xffff
    77fc:	54ffe621 	b.ne	74c0 <f12+0x890>  // b.any
    7800:	17ffff2b 	b	74ac <f12+0x87c>
    7804:	aa0203e0 	mov	x0, x2
    7808:	d2800101 	mov	x1, #0x8                   	// #8
    780c:	f90013e2 	str	x2, [sp, #32]
    7810:	97ffebf0 	bl	27d0 <calloc@plt>
    7814:	a9420fe2 	ldp	x2, x3, [sp, #32]
    7818:	aa0003e4 	mov	x4, x0
    781c:	17fffec4 	b	732c <f12+0x6fc>
    7820:	72003c1f 	tst	w0, #0xffff
    7824:	54fff080 	b.eq	7634 <f12+0xa04>  // b.none
    7828:	b40015d4 	cbz	x20, 7ae0 <f12+0xeb0>
    782c:	aa1403f9 	mov	x25, x20
    7830:	d2800013 	mov	x19, #0x0                   	// #0
    7834:	f9400b39 	ldr	x25, [x25, #16]
    7838:	aa1303e0 	mov	x0, x19
    783c:	91000673 	add	x19, x19, #0x1
    7840:	b5ffffb9 	cbnz	x25, 7834 <f12+0xc04>
    7844:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7848:	eb01027f 	cmp	x19, x1
    784c:	54ffb908 	b.hi	6f6c <f12+0x33c>  // b.pmore
    7850:	91000800 	add	x0, x0, #0x2
    7854:	52800041 	mov	w1, #0x2                   	// #2
    7858:	d37df000 	lsl	x0, x0, #3
    785c:	97fff4e5 	bl	4bf0 <fwp_heap_alloc>
    7860:	aa1403e1 	mov	x1, x20
    7864:	aa0003fb 	mov	x27, x0
    7868:	f9400420 	ldr	x0, [x1, #8]
    786c:	f8397b60 	str	x0, [x27, x25, lsl #3]
    7870:	91000739 	add	x25, x25, #0x1
    7874:	f9400821 	ldr	x1, [x1, #16]
    7878:	b5ffff81 	cbnz	x1, 7868 <f12+0xc38>
    787c:	52800019 	mov	w25, #0x0                   	// #0
    7880:	17ffff71 	b	7644 <f12+0xa14>
    7884:	b40012b4 	cbz	x20, 7ad8 <f12+0xea8>
    7888:	911542e0 	add	x0, x23, #0x550
    788c:	aa1403e2 	mov	x2, x20
    7890:	d280001a 	mov	x26, #0x0                   	// #0
    7894:	f949ec05 	ldr	x5, [x0, #5080]
    7898:	f949d808 	ldr	x8, [x0, #5040]
    789c:	f949fc07 	ldr	x7, [x0, #5112]
    78a0:	d370bca5 	lsl	x5, x5, #16
    78a4:	14000006 	b	78bc <f12+0xc8c>
    78a8:	f9400842 	ldr	x2, [x2, #16]
    78ac:	9100075a 	add	x26, x26, #0x1
    78b0:	f100005f 	cmp	x2, #0x0
    78b4:	fa531342 	ccmp	x26, x19, #0x2, ne	// ne = any
    78b8:	54000322 	b.cs	791c <f12+0xcec>  // b.hs, b.nlast
    78bc:	cb080040 	sub	x0, x2, x8
    78c0:	eb05001f 	cmp	x0, x5
    78c4:	540002c2 	b.cs	791c <f12+0xcec>  // b.hs, b.nlast
    78c8:	d350fc01 	lsr	x1, x0, #16
    78cc:	8b010821 	add	x1, x1, x1, lsl #2
    78d0:	d37df021 	lsl	x1, x1, #3
    78d4:	8b0100e6 	add	x6, x7, x1
    78d8:	f94010c4 	ldr	x4, [x6, #32]
    78dc:	b4000204 	cbz	x4, 791c <f12+0xcec>
    78e0:	386168e1 	ldrb	w1, [x7, x1]
    78e4:	7100083f 	cmp	w1, #0x2
    78e8:	54000f20 	b.eq	7acc <f12+0xe9c>  // b.none
    78ec:	7100043f 	cmp	w1, #0x1
    78f0:	54000161 	b.ne	791c <f12+0xcec>  // b.any
    78f4:	294304c9 	ldp	w9, w1, [x6, #24]
    78f8:	92403c00 	and	x0, x0, #0xffff
    78fc:	9b097c00 	mul	x0, x0, x9
    7900:	d360fc00 	lsr	x0, x0, #32
    7904:	eb01001f 	cmp	x0, x1
    7908:	540000a2 	b.cs	791c <f12+0xcec>  // b.hs, b.nlast
    790c:	8b000084 	add	x4, x4, x0
    7910:	39400080 	ldrb	w0, [x4]
    7914:	7100041f 	cmp	w0, #0x1
    7918:	54fffc80 	b.eq	78a8 <f12+0xc78>  // b.none
    791c:	d2800018 	mov	x24, #0x0                   	// #0
    7920:	eb13035f 	cmp	x26, x19
    7924:	540011e2 	b.cs	7b60 <f12+0xf30>  // b.hs, b.nlast
    7928:	d1002360 	sub	x0, x27, #0x8
    792c:	f9000be0 	str	x0, [sp, #16]
    7930:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x7b0>
    7934:	911542fc 	add	x28, x23, #0x550
    7938:	d2800018 	mov	x24, #0x0                   	// #0
    793c:	fd427808 	ldr	d8, [x0, #1264]
    7940:	14000043 	b	7a4c <f12+0xe1c>
    7944:	f94002a0 	ldr	x0, [x21]
    7948:	aa2003e0 	mvn	x0, x0
    794c:	f8217b80 	str	x0, [x28, x1, lsl #3]
    7950:	f10060bf 	cmp	x5, #0x18
    7954:	54000169 	b.ls	7980 <f12+0xd50>  // b.plast
    7958:	d10064a2 	sub	x2, x5, #0x19
    795c:	910062a0 	add	x0, x21, #0x18
    7960:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7964:	52800001 	mov	w1, #0x0                   	// #0
    7968:	91002042 	add	x2, x2, #0x8
    796c:	f9000fe5 	str	x5, [sp, #24]
    7970:	b90023e6 	str	w6, [sp, #32]
    7974:	97ffeb93 	bl	27c0 <memset@plt>
    7978:	f9400fe5 	ldr	x5, [sp, #24]
    797c:	b94023e6 	ldr	w6, [sp, #32]
    7980:	911542e1 	add	x1, x23, #0x550
    7984:	f94a1020 	ldr	x0, [x1, #5152]
    7988:	ab050000 	adds	x0, x0, x5
    798c:	540010a2 	b.cs	7ba0 <f12+0xf70>  // b.hs, b.nlast
    7990:	f94a1422 	ldr	x2, [x1, #5160]
    7994:	f90a1020 	str	x0, [x1, #5152]
    7998:	eb02001f 	cmp	x0, x2
    799c:	54000049 	b.ls	79a4 <f12+0xd74>  // b.plast
    79a0:	f90a1420 	str	x0, [x1, #5160]
    79a4:	911542e0 	add	x0, x23, #0x550
    79a8:	1e6300c1 	ucvtf	d1, w6
    79ac:	fd4a1c00 	ldr	d0, [x0, #5176]
    79b0:	1e612800 	fadd	d0, d0, d1
    79b4:	fd0a1c00 	str	d0, [x0, #5176]
    79b8:	f94007e0 	ldr	x0, [sp, #8]
    79bc:	a900e2a0 	stp	x0, x24, [x21, #8]
    79c0:	aa1503f8 	mov	x24, x21
    79c4:	fd0002a8 	str	d8, [x21]
    79c8:	f949db81 	ldr	x1, [x28, #5040]
    79cc:	f949ef80 	ldr	x0, [x28, #5080]
    79d0:	cb0102a1 	sub	x1, x21, x1
    79d4:	eb00403f 	cmp	x1, x0, lsl #16
    79d8:	54000322 	b.cs	7a3c <f12+0xe0c>  // b.hs, b.nlast
    79dc:	d350fc20 	lsr	x0, x1, #16
    79e0:	f949ff85 	ldr	x5, [x28, #5112]
    79e4:	8b000800 	add	x0, x0, x0, lsl #2
    79e8:	d37df002 	lsl	x2, x0, #3
    79ec:	8b0200a0 	add	x0, x5, x2
    79f0:	f9401015 	ldr	x21, [x0, #32]
    79f4:	b4000255 	cbz	x21, 7a3c <f12+0xe0c>
    79f8:	386268a2 	ldrb	w2, [x5, x2]
    79fc:	7100085f 	cmp	w2, #0x2
    7a00:	54000600 	b.eq	7ac0 <f12+0xe90>  // b.none
    7a04:	7100045f 	cmp	w2, #0x1
    7a08:	540001a1 	b.ne	7a3c <f12+0xe0c>  // b.any
    7a0c:	29430002 	ldp	w2, w0, [x0, #24]
    7a10:	92403c21 	and	x1, x1, #0xffff
    7a14:	9b027c21 	mul	x1, x1, x2
    7a18:	d360fc21 	lsr	x1, x1, #32
    7a1c:	eb00003f 	cmp	x1, x0
    7a20:	540000e2 	b.cs	7a3c <f12+0xe0c>  // b.hs, b.nlast
    7a24:	8b0102b5 	add	x21, x21, x1
    7a28:	394002a0 	ldrb	w0, [x21]
    7a2c:	7103fc1f 	cmp	w0, #0xff
    7a30:	54000b20 	b.eq	7b94 <f12+0xf64>  // b.none
    7a34:	52800020 	mov	w0, #0x1                   	// #1
    7a38:	390002a0 	strb	w0, [x21]
    7a3c:	d1000660 	sub	x0, x19, #0x1
    7a40:	eb1a001f 	cmp	x0, x26
    7a44:	54000b09 	b.ls	7ba4 <f12+0xf74>  // b.plast
    7a48:	aa0003f3 	mov	x19, x0
    7a4c:	f9400be1 	ldr	x1, [sp, #16]
    7a50:	b953a780 	ldr	w0, [x28, #5028]
    7a54:	f8737821 	ldr	x1, [x1, x19, lsl #3]
    7a58:	f90007e1 	str	x1, [sp, #8]
    7a5c:	34000280 	cbz	w0, 7aac <f12+0xe7c>
    7a60:	397e8b80 	ldrb	w0, [x28, #4002]
    7a64:	910f0002 	add	x2, x0, #0x3c0
    7a68:	8b000401 	add	x1, x0, x0, lsl #1
    7a6c:	b8627b86 	ldr	w6, [x28, x2, lsl #2]
    7a70:	8b010f82 	add	x2, x28, x1, lsl #3
    7a74:	f8617b95 	ldr	x21, [x28, x1, lsl #3]
    7a78:	2a0603e5 	mov	w5, w6
    7a7c:	b5fff655 	cbnz	x21, 7944 <f12+0xd14>
    7a80:	f9400455 	ldr	x21, [x2, #8]
    7a84:	b4000155 	cbz	x21, 7aac <f12+0xe7c>
    7a88:	f9400841 	ldr	x1, [x2, #16]
    7a8c:	cb150021 	sub	x1, x1, x21
    7a90:	eb0100bf 	cmp	x5, x1
    7a94:	540000c8 	b.hi	7aac <f12+0xe7c>  // b.pmore
    7a98:	d2800302 	mov	x2, #0x18                  	// #24
    7a9c:	8b0502a1 	add	x1, x21, x5
    7aa0:	9b027000 	madd	x0, x0, x2, x28
    7aa4:	f9000401 	str	x1, [x0, #8]
    7aa8:	17ffffaa 	b	7950 <f12+0xd20>
    7aac:	52800001 	mov	w1, #0x0                   	// #0
    7ab0:	d2800300 	mov	x0, #0x18                  	// #24
    7ab4:	97fff44f 	bl	4bf0 <fwp_heap_alloc>
    7ab8:	aa0003f5 	mov	x21, x0
    7abc:	17ffffbf 	b	79b8 <f12+0xd88>
    7ac0:	72003c3f 	tst	w1, #0xffff
    7ac4:	54fffbc1 	b.ne	7a3c <f12+0xe0c>  // b.any
    7ac8:	17ffffd8 	b	7a28 <f12+0xdf8>
    7acc:	72003c1f 	tst	w0, #0xffff
    7ad0:	54fff261 	b.ne	791c <f12+0xcec>  // b.any
    7ad4:	17ffff8f 	b	7910 <f12+0xce0>
    7ad8:	d280001a 	mov	x26, #0x0                   	// #0
    7adc:	17ffff93 	b	7928 <f12+0xcf8>
    7ae0:	52800041 	mov	w1, #0x2                   	// #2
    7ae4:	d2800100 	mov	x0, #0x8                   	// #8
    7ae8:	97fff442 	bl	4bf0 <fwp_heap_alloc>
    7aec:	aa0003fb 	mov	x27, x0
    7af0:	52800019 	mov	w25, #0x0                   	// #0
    7af4:	d2800018 	mov	x24, #0x0                   	// #0
    7af8:	7100033f 	cmp	w25, #0x0
    7afc:	9a9b13fb 	csel	x27, xzr, x27, ne	// ne = any
    7b00:	aa1b03e0 	mov	x0, x27
    7b04:	97fff17f 	bl	4100 <fwp_mem_free>
    7b08:	aa1603e0 	mov	x0, x22
    7b0c:	97fffba1 	bl	6990 <fwp_drop4>
    7b10:	aa1403e0 	mov	x0, x20
    7b14:	97fff807 	bl	5b30 <fwp_drop0>
    7b18:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    7b1c:	f947f400 	ldr	x0, [x0, #4072]
    7b20:	f94057e2 	ldr	x2, [sp, #168]
    7b24:	f9400001 	ldr	x1, [x0]
    7b28:	eb010042 	subs	x2, x2, x1
    7b2c:	d2800001 	mov	x1, #0x0                   	// #0
    7b30:	54000161 	b.ne	7b5c <f12+0xf2c>  // b.any
    7b34:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    7b38:	aa1803e0 	mov	x0, x24
    7b3c:	a94c53f3 	ldp	x19, x20, [sp, #192]
    7b40:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    7b44:	a94e63f7 	ldp	x23, x24, [sp, #224]
    7b48:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    7b4c:	a95073fb 	ldp	x27, x28, [sp, #256]
    7b50:	fd408be8 	ldr	d8, [sp, #272]
    7b54:	910483ff 	add	sp, sp, #0x120
    7b58:	d65f03c0 	ret
    7b5c:	97ffeb25 	bl	27f0 <__stack_chk_fail@plt>
    7b60:	aa1403e0 	mov	x0, x20
    7b64:	d2800001 	mov	x1, #0x0                   	// #0
    7b68:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    7b6c:	91000421 	add	x1, x1, #0x1
    7b70:	f9000402 	str	x2, [x0, #8]
    7b74:	aa0003e2 	mov	x2, x0
    7b78:	f9400800 	ldr	x0, [x0, #16]
    7b7c:	eb01035f 	cmp	x26, x1
    7b80:	54ffff48 	b.hi	7b68 <f12+0xf38>  // b.pmore
    7b84:	f9000858 	str	x24, [x2, #16]
    7b88:	aa1403f8 	mov	x24, x20
    7b8c:	aa0003f4 	mov	x20, x0
    7b90:	17ffffda 	b	7af8 <f12+0xec8>
    7b94:	aa1503e0 	mov	x0, x21
    7b98:	97fff0be 	bl	3e90 <fwp_rc_forget_slot.part.0>
    7b9c:	17ffffa6 	b	7a34 <f12+0xe04>
    7ba0:	97ffed04 	bl	2fb0 <fwp_heap_oom>
    7ba4:	b5fffdfa 	cbnz	x26, 7b60 <f12+0xf30>
    7ba8:	7100033f 	cmp	w25, #0x0
    7bac:	9a9b13fb 	csel	x27, xzr, x27, ne	// ne = any
    7bb0:	b4fffa80 	cbz	x0, 7b00 <f12+0xed0>
    7bb4:	b0000020 	adrp	x0, c000 <_IO_stdin_used+0x7b0>
    7bb8:	d1000a73 	sub	x19, x19, #0x2
    7bbc:	911542f7 	add	x23, x23, #0x550
    7bc0:	d280031a 	mov	x26, #0x18                  	// #24
    7bc4:	fd427808 	ldr	d8, [x0, #1264]
    7bc8:	52800039 	mov	w25, #0x1                   	// #1
    7bcc:	b953a6e0 	ldr	w0, [x23, #5028]
    7bd0:	f8737b7c 	ldr	x28, [x27, x19, lsl #3]
    7bd4:	34000a20 	cbz	w0, 7d18 <f12+0x10e8>
    7bd8:	397e8ae0 	ldrb	w0, [x23, #4002]
    7bdc:	910f0002 	add	x2, x0, #0x3c0
    7be0:	8b000401 	add	x1, x0, x0, lsl #1
    7be4:	b8627ae4 	ldr	w4, [x23, x2, lsl #2]
    7be8:	8b010ee2 	add	x2, x23, x1, lsl #3
    7bec:	f8617af5 	ldr	x21, [x23, x1, lsl #3]
    7bf0:	2a0403e3 	mov	w3, w4
    7bf4:	b40007f5 	cbz	x21, 7cf0 <f12+0x10c0>
    7bf8:	f94002a0 	ldr	x0, [x21]
    7bfc:	aa2003e0 	mvn	x0, x0
    7c00:	f8217ae0 	str	x0, [x23, x1, lsl #3]
    7c04:	f100607f 	cmp	x3, #0x18
    7c08:	54000169 	b.ls	7c34 <f12+0x1004>  // b.plast
    7c0c:	d1006462 	sub	x2, x3, #0x19
    7c10:	910062a0 	add	x0, x21, #0x18
    7c14:	927df042 	and	x2, x2, #0xfffffffffffffff8
    7c18:	52800001 	mov	w1, #0x0                   	// #0
    7c1c:	91002042 	add	x2, x2, #0x8
    7c20:	f90007e3 	str	x3, [sp, #8]
    7c24:	b90013e4 	str	w4, [sp, #16]
    7c28:	97ffeae6 	bl	27c0 <memset@plt>
    7c2c:	f94007e3 	ldr	x3, [sp, #8]
    7c30:	b94013e4 	ldr	w4, [sp, #16]
    7c34:	f94a12e0 	ldr	x0, [x23, #5152]
    7c38:	ab030000 	adds	x0, x0, x3
    7c3c:	54fffb22 	b.cs	7ba0 <f12+0xf70>  // b.hs, b.nlast
    7c40:	f94a16e1 	ldr	x1, [x23, #5160]
    7c44:	f90a12e0 	str	x0, [x23, #5152]
    7c48:	eb01001f 	cmp	x0, x1
    7c4c:	54000049 	b.ls	7c54 <f12+0x1024>  // b.plast
    7c50:	f90a16e0 	str	x0, [x23, #5160]
    7c54:	1e630081 	ucvtf	d1, w4
    7c58:	fd4a1ee0 	ldr	d0, [x23, #5176]
    7c5c:	1e612800 	fadd	d0, d0, d1
    7c60:	fd0a1ee0 	str	d0, [x23, #5176]
    7c64:	a900e2bc 	stp	x28, x24, [x21, #8]
    7c68:	aa1503f8 	mov	x24, x21
    7c6c:	fd0002a8 	str	d8, [x21]
    7c70:	f949dae1 	ldr	x1, [x23, #5040]
    7c74:	f949eee0 	ldr	x0, [x23, #5080]
    7c78:	cb0102a1 	sub	x1, x21, x1
    7c7c:	eb00403f 	cmp	x1, x0, lsl #16
    7c80:	54000302 	b.cs	7ce0 <f12+0x10b0>  // b.hs, b.nlast
    7c84:	d350fc20 	lsr	x0, x1, #16
    7c88:	f949fee3 	ldr	x3, [x23, #5112]
    7c8c:	8b000800 	add	x0, x0, x0, lsl #2
    7c90:	d37df002 	lsl	x2, x0, #3
    7c94:	8b020060 	add	x0, x3, x2
    7c98:	f9401015 	ldr	x21, [x0, #32]
    7c9c:	b4000235 	cbz	x21, 7ce0 <f12+0x10b0>
    7ca0:	38626862 	ldrb	w2, [x3, x2]
    7ca4:	7100085f 	cmp	w2, #0x2
    7ca8:	54000420 	b.eq	7d2c <f12+0x10fc>  // b.none
    7cac:	7100045f 	cmp	w2, #0x1
    7cb0:	54000181 	b.ne	7ce0 <f12+0x10b0>  // b.any
    7cb4:	29430002 	ldp	w2, w0, [x0, #24]
    7cb8:	92403c21 	and	x1, x1, #0xffff
    7cbc:	9b027c21 	mul	x1, x1, x2
    7cc0:	d360fc21 	lsr	x1, x1, #32
    7cc4:	eb00003f 	cmp	x1, x0
    7cc8:	540000c2 	b.cs	7ce0 <f12+0x10b0>  // b.hs, b.nlast
    7ccc:	8b0102b5 	add	x21, x21, x1
    7cd0:	394002a0 	ldrb	w0, [x21]
    7cd4:	7103fc1f 	cmp	w0, #0xff
    7cd8:	54000300 	b.eq	7d38 <f12+0x1108>  // b.none
    7cdc:	390002b9 	strb	w25, [x21]
    7ce0:	d1000673 	sub	x19, x19, #0x1
    7ce4:	b100067f 	cmn	x19, #0x1
    7ce8:	54fff721 	b.ne	7bcc <f12+0xf9c>  // b.any
    7cec:	17ffff85 	b	7b00 <f12+0xed0>
    7cf0:	f9400455 	ldr	x21, [x2, #8]
    7cf4:	b4000135 	cbz	x21, 7d18 <f12+0x10e8>
    7cf8:	f9400841 	ldr	x1, [x2, #16]
    7cfc:	cb150021 	sub	x1, x1, x21
    7d00:	eb01007f 	cmp	x3, x1
    7d04:	540000a8 	b.hi	7d18 <f12+0x10e8>  // b.pmore
    7d08:	9b1a5c00 	madd	x0, x0, x26, x23
    7d0c:	8b0302a1 	add	x1, x21, x3
    7d10:	f9000401 	str	x1, [x0, #8]
    7d14:	17ffffbc 	b	7c04 <f12+0xfd4>
    7d18:	52800001 	mov	w1, #0x0                   	// #0
    7d1c:	d2800300 	mov	x0, #0x18                  	// #24
    7d20:	97fff3b4 	bl	4bf0 <fwp_heap_alloc>
    7d24:	aa0003f5 	mov	x21, x0
    7d28:	17ffffcf 	b	7c64 <f12+0x1034>
    7d2c:	72003c3f 	tst	w1, #0xffff
    7d30:	54fffd81 	b.ne	7ce0 <f12+0x10b0>  // b.any
    7d34:	17ffffe7 	b	7cd0 <f12+0x10a0>
    7d38:	aa1503e0 	mov	x0, x21
    7d3c:	97fff055 	bl	3e90 <fwp_rc_forget_slot.part.0>
    7d40:	17ffffe7 	b	7cdc <f12+0x10ac>
    7d44:	aa1303e0 	mov	x0, x19
    7d48:	97fff052 	bl	3e90 <fwp_rc_forget_slot.part.0>
    7d4c:	17fffea7 	b	77e8 <f12+0xbb8>
    7d50:	72003c3f 	tst	w1, #0xffff
    7d54:	54ffd440 	b.eq	77dc <f12+0xbac>  // b.none
    7d58:	aa1503e0 	mov	x0, x21
    7d5c:	17fffe02 	b	7564 <f12+0x934>
    7d60:	f9400315 	ldr	x21, [x24]
    7d64:	b7ffebf5 	tbnz	x21, #63, 7ae0 <f12+0xeb0>
    7d68:	9240fab5 	and	x21, x21, #0x7fffffffffffffff
    7d6c:	d2800013 	mov	x19, #0x0                   	// #0
    7d70:	17fffe18 	b	75d0 <f12+0x9a0>
    7d74:	aa1303e0 	mov	x0, x19
    7d78:	97fff046 	bl	3e90 <fwp_rc_forget_slot.part.0>
    7d7c:	910102c0 	add	x0, x22, #0x40
    7d80:	f941601a 	ldr	x26, [x0, #704]
    7d84:	17fffdcd 	b	74b8 <f12+0x888>
    7d88:	97ffeb1e 	bl	2a00 <fwp_trap_overflow.constprop.0>
    7d8c:	97ffeaad 	bl	2840 <abort@plt>

0000000000007d90 <fwp_owned_entry12>:
    7d90:	f9400000 	ldr	x0, [x0]
    7d94:	17fffba7 	b	6c30 <f12>
    7d98:	d503201f 	nop
    7d9c:	d503201f 	nop

0000000000007da0 <e12>:
    7da0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7da4:	910003fd 	mov	x29, sp
    7da8:	f9000bf3 	str	x19, [sp, #16]
    7dac:	f9400013 	ldr	x19, [x0]
    7db0:	aa1303e0 	mov	x0, x19
    7db4:	97fff697 	bl	5810 <fwp_rc_share>
    7db8:	aa1303e0 	mov	x0, x19
    7dbc:	97fffb9d 	bl	6c30 <f12>
    7dc0:	aa0003f3 	mov	x19, x0
    7dc4:	97fff693 	bl	5810 <fwp_rc_share>
    7dc8:	aa1303e0 	mov	x0, x19
    7dcc:	f9400bf3 	ldr	x19, [sp, #16]
    7dd0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7dd4:	d65f03c0 	ret
    7dd8:	d503201f 	nop
    7ddc:	d503201f 	nop

0000000000007de0 <fwp_args12>:
    7de0:	7100003f 	cmp	w1, #0x0
    7de4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7de8:	54000041 	b.ne	7df0 <fwp_args12+0x10>  // b.any
    7dec:	d65f03c0 	ret
    7df0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7df4:	91154042 	add	x2, x2, #0x550
    7df8:	f9400001 	ldr	x1, [x0]
    7dfc:	f949d843 	ldr	x3, [x2, #5040]
    7e00:	f949ec40 	ldr	x0, [x2, #5080]
    7e04:	cb030021 	sub	x1, x1, x3
    7e08:	eb00403f 	cmp	x1, x0, lsl #16
    7e0c:	54ffff02 	b.cs	7dec <fwp_args12+0xc>  // b.hs, b.nlast
    7e10:	d350fc20 	lsr	x0, x1, #16
    7e14:	f949fc44 	ldr	x4, [x2, #5112]
    7e18:	8b000800 	add	x0, x0, x0, lsl #2
    7e1c:	d37df002 	lsl	x2, x0, #3
    7e20:	8b020083 	add	x3, x4, x2
    7e24:	f9401060 	ldr	x0, [x3, #32]
    7e28:	b4fffe20 	cbz	x0, 7dec <fwp_args12+0xc>
    7e2c:	38626882 	ldrb	w2, [x4, x2]
    7e30:	7100085f 	cmp	w2, #0x2
    7e34:	54000220 	b.eq	7e78 <fwp_args12+0x98>  // b.none
    7e38:	7100045f 	cmp	w2, #0x1
    7e3c:	54fffd81 	b.ne	7dec <fwp_args12+0xc>  // b.any
    7e40:	29430864 	ldp	w4, w2, [x3, #24]
    7e44:	92403c21 	and	x1, x1, #0xffff
    7e48:	9b047c21 	mul	x1, x1, x4
    7e4c:	d360fc21 	lsr	x1, x1, #32
    7e50:	eb02003f 	cmp	x1, x2
    7e54:	54fffcc2 	b.cs	7dec <fwp_args12+0xc>  // b.hs, b.nlast
    7e58:	8b010000 	add	x0, x0, x1
    7e5c:	39400001 	ldrb	w1, [x0]
    7e60:	34fffc61 	cbz	w1, 7dec <fwp_args12+0xc>
    7e64:	7103f43f 	cmp	w1, #0xfd
    7e68:	540000e8 	b.hi	7e84 <fwp_args12+0xa4>  // b.pmore
    7e6c:	11000421 	add	w1, w1, #0x1
    7e70:	39000001 	strb	w1, [x0]
    7e74:	d65f03c0 	ret
    7e78:	72003c3f 	tst	w1, #0xffff
    7e7c:	54ffff00 	b.eq	7e5c <fwp_args12+0x7c>  // b.none
    7e80:	d65f03c0 	ret
    7e84:	17fff118 	b	42e4 <fwp_rc_wide_dup>
    7e88:	d503201f 	nop
    7e8c:	d503201f 	nop

0000000000007e90 <fwp_args23>:
    7e90:	7100003f 	cmp	w1, #0x0
    7e94:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7e98:	54000041 	b.ne	7ea0 <fwp_args23+0x10>  // b.any
    7e9c:	d65f03c0 	ret
    7ea0:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7ea4:	91154042 	add	x2, x2, #0x550
    7ea8:	f9400001 	ldr	x1, [x0]
    7eac:	f949d843 	ldr	x3, [x2, #5040]
    7eb0:	f949ec40 	ldr	x0, [x2, #5080]
    7eb4:	cb030021 	sub	x1, x1, x3
    7eb8:	eb00403f 	cmp	x1, x0, lsl #16
    7ebc:	54ffff02 	b.cs	7e9c <fwp_args23+0xc>  // b.hs, b.nlast
    7ec0:	d350fc20 	lsr	x0, x1, #16
    7ec4:	f949fc44 	ldr	x4, [x2, #5112]
    7ec8:	8b000800 	add	x0, x0, x0, lsl #2
    7ecc:	d37df002 	lsl	x2, x0, #3
    7ed0:	8b020083 	add	x3, x4, x2
    7ed4:	f9401060 	ldr	x0, [x3, #32]
    7ed8:	b4fffe20 	cbz	x0, 7e9c <fwp_args23+0xc>
    7edc:	38626882 	ldrb	w2, [x4, x2]
    7ee0:	7100085f 	cmp	w2, #0x2
    7ee4:	54000220 	b.eq	7f28 <fwp_args23+0x98>  // b.none
    7ee8:	7100045f 	cmp	w2, #0x1
    7eec:	54fffd81 	b.ne	7e9c <fwp_args23+0xc>  // b.any
    7ef0:	29430864 	ldp	w4, w2, [x3, #24]
    7ef4:	92403c21 	and	x1, x1, #0xffff
    7ef8:	9b047c21 	mul	x1, x1, x4
    7efc:	d360fc21 	lsr	x1, x1, #32
    7f00:	eb02003f 	cmp	x1, x2
    7f04:	54fffcc2 	b.cs	7e9c <fwp_args23+0xc>  // b.hs, b.nlast
    7f08:	8b010000 	add	x0, x0, x1
    7f0c:	39400001 	ldrb	w1, [x0]
    7f10:	34fffc61 	cbz	w1, 7e9c <fwp_args23+0xc>
    7f14:	7103f43f 	cmp	w1, #0xfd
    7f18:	540000e8 	b.hi	7f34 <fwp_args23+0xa4>  // b.pmore
    7f1c:	11000421 	add	w1, w1, #0x1
    7f20:	39000001 	strb	w1, [x0]
    7f24:	d65f03c0 	ret
    7f28:	72003c3f 	tst	w1, #0xffff
    7f2c:	54ffff00 	b.eq	7f0c <fwp_args23+0x7c>  // b.none
    7f30:	d65f03c0 	ret
    7f34:	17fff0ec 	b	42e4 <fwp_rc_wide_dup>
    7f38:	d503201f 	nop
    7f3c:	d503201f 	nop

0000000000007f40 <fwp_caps12>:
    7f40:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7f44:	910003fd 	mov	x29, sp
    7f48:	f9000bf3 	str	x19, [sp, #16]
    7f4c:	aa0003f3 	mov	x19, x0
    7f50:	b9400400 	ldr	w0, [x0, #4]
    7f54:	340004a0 	cbz	w0, 7fe8 <fwp_caps12+0xa8>
    7f58:	f9400660 	ldr	x0, [x19, #8]
    7f5c:	350004e1 	cbnz	w1, 7ff8 <fwp_caps12+0xb8>
    7f60:	97fff6f4 	bl	5b30 <fwp_drop0>
    7f64:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7f68:	91154042 	add	x2, x2, #0x550
    7f6c:	f949d840 	ldr	x0, [x2, #5040]
    7f70:	f949ec41 	ldr	x1, [x2, #5080]
    7f74:	cb000260 	sub	x0, x19, x0
    7f78:	eb01401f 	cmp	x0, x1, lsl #16
    7f7c:	54000382 	b.cs	7fec <fwp_caps12+0xac>  // b.hs, b.nlast
    7f80:	d350fc01 	lsr	x1, x0, #16
    7f84:	f949fc44 	ldr	x4, [x2, #5112]
    7f88:	8b010821 	add	x1, x1, x1, lsl #2
    7f8c:	d37df021 	lsl	x1, x1, #3
    7f90:	8b010083 	add	x3, x4, x1
    7f94:	f9401062 	ldr	x2, [x3, #32]
    7f98:	b40002a2 	cbz	x2, 7fec <fwp_caps12+0xac>
    7f9c:	38616881 	ldrb	w1, [x4, x1]
    7fa0:	7100083f 	cmp	w1, #0x2
    7fa4:	540006c0 	b.eq	807c <fwp_caps12+0x13c>  // b.none
    7fa8:	7100043f 	cmp	w1, #0x1
    7fac:	54000201 	b.ne	7fec <fwp_caps12+0xac>  // b.any
    7fb0:	29430464 	ldp	w4, w1, [x3, #24]
    7fb4:	92403c00 	and	x0, x0, #0xffff
    7fb8:	9b047c00 	mul	x0, x0, x4
    7fbc:	d360fc00 	lsr	x0, x0, #32
    7fc0:	eb01001f 	cmp	x0, x1
    7fc4:	54000142 	b.cs	7fec <fwp_caps12+0xac>  // b.hs, b.nlast
    7fc8:	8b000042 	add	x2, x2, x0
    7fcc:	39400040 	ldrb	w0, [x2]
    7fd0:	7100041f 	cmp	w0, #0x1
    7fd4:	540000c1 	b.ne	7fec <fwp_caps12+0xac>  // b.any
    7fd8:	aa1303e0 	mov	x0, x19
    7fdc:	f9400bf3 	ldr	x19, [sp, #16]
    7fe0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7fe4:	17fff047 	b	4100 <fwp_mem_free>
    7fe8:	34fffbe1 	cbz	w1, 7f64 <fwp_caps12+0x24>
    7fec:	f9400bf3 	ldr	x19, [sp, #16]
    7ff0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7ff4:	d65f03c0 	ret
    7ff8:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    7ffc:	91154042 	add	x2, x2, #0x550
    8000:	f949d843 	ldr	x3, [x2, #5040]
    8004:	f949ec41 	ldr	x1, [x2, #5080]
    8008:	cb030000 	sub	x0, x0, x3
    800c:	eb01401f 	cmp	x0, x1, lsl #16
    8010:	54fffee2 	b.cs	7fec <fwp_caps12+0xac>  // b.hs, b.nlast
    8014:	d350fc01 	lsr	x1, x0, #16
    8018:	f949fc44 	ldr	x4, [x2, #5112]
    801c:	8b010821 	add	x1, x1, x1, lsl #2
    8020:	d37df021 	lsl	x1, x1, #3
    8024:	8b010083 	add	x3, x4, x1
    8028:	f9401062 	ldr	x2, [x3, #32]
    802c:	b4fffe02 	cbz	x2, 7fec <fwp_caps12+0xac>
    8030:	38616881 	ldrb	w1, [x4, x1]
    8034:	7100083f 	cmp	w1, #0x2
    8038:	54000280 	b.eq	8088 <fwp_caps12+0x148>  // b.none
    803c:	7100043f 	cmp	w1, #0x1
    8040:	54fffd61 	b.ne	7fec <fwp_caps12+0xac>  // b.any
    8044:	92403c01 	and	x1, x0, #0xffff
    8048:	29430064 	ldp	w4, w0, [x3, #24]
    804c:	9b047c21 	mul	x1, x1, x4
    8050:	d360fc21 	lsr	x1, x1, #32
    8054:	eb00003f 	cmp	x1, x0
    8058:	54fffca2 	b.cs	7fec <fwp_caps12+0xac>  // b.hs, b.nlast
    805c:	8b010042 	add	x2, x2, x1
    8060:	39400040 	ldrb	w0, [x2]
    8064:	34fffc40 	cbz	w0, 7fec <fwp_caps12+0xac>
    8068:	7103f41f 	cmp	w0, #0xfd
    806c:	54000148 	b.hi	8094 <fwp_caps12+0x154>  // b.pmore
    8070:	11000400 	add	w0, w0, #0x1
    8074:	39000040 	strb	w0, [x2]
    8078:	17ffffdd 	b	7fec <fwp_caps12+0xac>
    807c:	72003c1f 	tst	w0, #0xffff
    8080:	54fffb61 	b.ne	7fec <fwp_caps12+0xac>  // b.any
    8084:	17ffffd2 	b	7fcc <fwp_caps12+0x8c>
    8088:	72003c1f 	tst	w0, #0xffff
    808c:	54fffb01 	b.ne	7fec <fwp_caps12+0xac>  // b.any
    8090:	17fffff4 	b	8060 <fwp_caps12+0x120>
    8094:	f9400bf3 	ldr	x19, [sp, #16]
    8098:	aa0203e0 	mov	x0, x2
    809c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    80a0:	17fff091 	b	42e4 <fwp_rc_wide_dup>

00000000000080a4 <fwp_drop2>:
    80a4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    80a8:	910003fd 	mov	x29, sp
    80ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    80b0:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xc90>
    80b4:	911542d5 	add	x21, x22, #0x550
    80b8:	a90153f3 	stp	x19, x20, [sp, #16]
    80bc:	aa0003f3 	mov	x19, x0
    80c0:	f949daa1 	ldr	x1, [x21, #5040]
    80c4:	f949eea0 	ldr	x0, [x21, #5080]
    80c8:	cb010261 	sub	x1, x19, x1
    80cc:	eb00403f 	cmp	x1, x0, lsl #16
    80d0:	54000382 	b.cs	8140 <fwp_drop2+0x9c>  // b.hs, b.nlast
    80d4:	d350fc22 	lsr	x2, x1, #16
    80d8:	f949fea3 	ldr	x3, [x21, #5112]
    80dc:	8b020842 	add	x2, x2, x2, lsl #2
    80e0:	d37df042 	lsl	x2, x2, #3
    80e4:	8b020060 	add	x0, x3, x2
    80e8:	f9401014 	ldr	x20, [x0, #32]
    80ec:	b40002b4 	cbz	x20, 8140 <fwp_drop2+0x9c>
    80f0:	38626862 	ldrb	w2, [x3, x2]
    80f4:	7100085f 	cmp	w2, #0x2
    80f8:	540002c0 	b.eq	8150 <fwp_drop2+0xac>  // b.none
    80fc:	7100045f 	cmp	w2, #0x1
    8100:	54000201 	b.ne	8140 <fwp_drop2+0x9c>  // b.any
    8104:	29430002 	ldp	w2, w0, [x0, #24]
    8108:	92403c21 	and	x1, x1, #0xffff
    810c:	9b027c21 	mul	x1, x1, x2
    8110:	d360fc21 	lsr	x1, x1, #32
    8114:	eb00003f 	cmp	x1, x0
    8118:	54000142 	b.cs	8140 <fwp_drop2+0x9c>  // b.hs, b.nlast
    811c:	8b010294 	add	x20, x20, x1
    8120:	39400280 	ldrb	w0, [x20]
    8124:	340000e0 	cbz	w0, 8140 <fwp_drop2+0x9c>
    8128:	7100041f 	cmp	w0, #0x1
    812c:	540001e0 	b.eq	8168 <fwp_drop2+0xc4>  // b.none
    8130:	7103fc1f 	cmp	w0, #0xff
    8134:	540007e0 	b.eq	8230 <fwp_drop2+0x18c>  // b.none
    8138:	51000400 	sub	w0, w0, #0x1
    813c:	39000280 	strb	w0, [x20]
    8140:	a94153f3 	ldp	x19, x20, [sp, #16]
    8144:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8148:	a8c37bfd 	ldp	x29, x30, [sp], #48
    814c:	d65f03c0 	ret
    8150:	72003c3f 	tst	w1, #0xffff
    8154:	54fffe60 	b.eq	8120 <fwp_drop2+0x7c>  // b.none
    8158:	a94153f3 	ldp	x19, x20, [sp, #16]
    815c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8160:	a8c37bfd 	ldp	x29, x30, [sp], #48
    8164:	d65f03c0 	ret
    8168:	911542c2 	add	x2, x22, #0x550
    816c:	f9400660 	ldr	x0, [x19, #8]
    8170:	f949d841 	ldr	x1, [x2, #5040]
    8174:	f949ec42 	ldr	x2, [x2, #5080]
    8178:	cb010001 	sub	x1, x0, x1
    817c:	eb02403f 	cmp	x1, x2, lsl #16
    8180:	54000382 	b.cs	81f0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    8184:	d350fc22 	lsr	x2, x1, #16
    8188:	8b020842 	add	x2, x2, x2, lsl #2
    818c:	d37df042 	lsl	x2, x2, #3
    8190:	8b020064 	add	x4, x3, x2
    8194:	f9401094 	ldr	x20, [x4, #32]
    8198:	b40002d4 	cbz	x20, 81f0 <fwp_drop2+0x14c>
    819c:	38626862 	ldrb	w2, [x3, x2]
    81a0:	7100085f 	cmp	w2, #0x2
    81a4:	54000400 	b.eq	8224 <fwp_drop2+0x180>  // b.none
    81a8:	7100045f 	cmp	w2, #0x1
    81ac:	54000221 	b.ne	81f0 <fwp_drop2+0x14c>  // b.any
    81b0:	29430883 	ldp	w3, w2, [x4, #24]
    81b4:	92403c21 	and	x1, x1, #0xffff
    81b8:	9b037c21 	mul	x1, x1, x3
    81bc:	d360fc21 	lsr	x1, x1, #32
    81c0:	eb02003f 	cmp	x1, x2
    81c4:	54000162 	b.cs	81f0 <fwp_drop2+0x14c>  // b.hs, b.nlast
    81c8:	8b010294 	add	x20, x20, x1
    81cc:	39400281 	ldrb	w1, [x20]
    81d0:	34000101 	cbz	w1, 81f0 <fwp_drop2+0x14c>
    81d4:	7100043f 	cmp	w1, #0x1
    81d8:	54000220 	b.eq	821c <fwp_drop2+0x178>  // b.none
    81dc:	7103fc3f 	cmp	w1, #0xff
    81e0:	54000660 	b.eq	82ac <fwp_drop2+0x208>  // b.none
    81e4:	51000421 	sub	w1, w1, #0x1
    81e8:	39000281 	strb	w1, [x20]
    81ec:	d503201f 	nop
    81f0:	f9400a74 	ldr	x20, [x19, #16]
    81f4:	aa1303e0 	mov	x0, x19
    81f8:	97fff5aa 	bl	58a0 <fwp_rc_free_arr>
    81fc:	911542c0 	add	x0, x22, #0x550
    8200:	f949d801 	ldr	x1, [x0, #5040]
    8204:	f949ec00 	ldr	x0, [x0, #5080]
    8208:	cb010281 	sub	x1, x20, x1
    820c:	eb00403f 	cmp	x1, x0, lsl #16
    8210:	54fff982 	b.cs	8140 <fwp_drop2+0x9c>  // b.hs, b.nlast
    8214:	aa1403f3 	mov	x19, x20
    8218:	17ffffaf 	b	80d4 <fwp_drop2+0x30>
    821c:	97fff5a1 	bl	58a0 <fwp_rc_free_arr>
    8220:	17fffff4 	b	81f0 <fwp_drop2+0x14c>
    8224:	72003c3f 	tst	w1, #0xffff
    8228:	54fffe41 	b.ne	81f0 <fwp_drop2+0x14c>  // b.any
    822c:	17ffffe8 	b	81cc <fwp_drop2+0x128>
    8230:	ca544681 	eor	x1, x20, x20, lsr #17
    8234:	911542c0 	add	x0, x22, #0x550
    8238:	ca412421 	eor	x1, x1, x1, lsr #9
    823c:	92401c21 	and	x1, x1, #0xff
    8240:	910a2422 	add	x2, x1, #0x289
    8244:	8b010c01 	add	x1, x0, x1, lsl #3
    8248:	8b020c02 	add	x2, x0, x2, lsl #3
    824c:	f94a2420 	ldr	x0, [x1, #5192]
    8250:	b50000a0 	cbnz	x0, 8264 <fwp_drop2+0x1c0>
    8254:	14000013 	b	82a0 <fwp_drop2+0x1fc>
    8258:	91004002 	add	x2, x0, #0x10
    825c:	f9400800 	ldr	x0, [x0, #16]
    8260:	b4000200 	cbz	x0, 82a0 <fwp_drop2+0x1fc>
    8264:	f9400001 	ldr	x1, [x0]
    8268:	eb14003f 	cmp	x1, x20
    826c:	54ffff61 	b.ne	8258 <fwp_drop2+0x1b4>  // b.any
    8270:	f9400041 	ldr	x1, [x2]
    8274:	f9400420 	ldr	x0, [x1, #8]
    8278:	d1000400 	sub	x0, x0, #0x1
    827c:	f9000420 	str	x0, [x1, #8]
    8280:	f103f81f 	cmp	x0, #0xfe
    8284:	54fff5e1 	b.ne	8140 <fwp_drop2+0x9c>  // b.any
    8288:	39400280 	ldrb	w0, [x20]
    828c:	7103fc1f 	cmp	w0, #0xff
    8290:	54000460 	b.eq	831c <fwp_drop2+0x278>  // b.none
    8294:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8298:	39000280 	strb	w0, [x20]
    829c:	17ffffa9 	b	8140 <fwp_drop2+0x9c>
    82a0:	f0000000 	adrp	x0, b000 <fwp_main_thread+0x1730>
    82a4:	91264000 	add	x0, x0, #0x990
    82a8:	97ffeeda 	bl	3e10 <fwp_trap>
    82ac:	ca544680 	eor	x0, x20, x20, lsr #17
    82b0:	911542c1 	add	x1, x22, #0x550
    82b4:	ca402400 	eor	x0, x0, x0, lsr #9
    82b8:	92401c00 	and	x0, x0, #0xff
    82bc:	910a2402 	add	x2, x0, #0x289
    82c0:	8b000c20 	add	x0, x1, x0, lsl #3
    82c4:	8b020c22 	add	x2, x1, x2, lsl #3
    82c8:	f94a2400 	ldr	x0, [x0, #5192]
    82cc:	b50000a0 	cbnz	x0, 82e0 <fwp_drop2+0x23c>
    82d0:	17fffff4 	b	82a0 <fwp_drop2+0x1fc>
    82d4:	91004002 	add	x2, x0, #0x10
    82d8:	f9400800 	ldr	x0, [x0, #16]
    82dc:	b4fffe20 	cbz	x0, 82a0 <fwp_drop2+0x1fc>
    82e0:	f9400001 	ldr	x1, [x0]
    82e4:	eb14003f 	cmp	x1, x20
    82e8:	54ffff61 	b.ne	82d4 <fwp_drop2+0x230>  // b.any
    82ec:	f9400041 	ldr	x1, [x2]
    82f0:	f9400420 	ldr	x0, [x1, #8]
    82f4:	d1000400 	sub	x0, x0, #0x1
    82f8:	f9000420 	str	x0, [x1, #8]
    82fc:	f103f81f 	cmp	x0, #0xfe
    8300:	54fff781 	b.ne	81f0 <fwp_drop2+0x14c>  // b.any
    8304:	39400280 	ldrb	w0, [x20]
    8308:	7103fc1f 	cmp	w0, #0xff
    830c:	540000e0 	b.eq	8328 <fwp_drop2+0x284>  // b.none
    8310:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8314:	39000280 	strb	w0, [x20]
    8318:	17ffffb6 	b	81f0 <fwp_drop2+0x14c>
    831c:	aa1403e0 	mov	x0, x20
    8320:	97ffeedc 	bl	3e90 <fwp_rc_forget_slot.part.0>
    8324:	17ffffdc 	b	8294 <fwp_drop2+0x1f0>
    8328:	aa1403e0 	mov	x0, x20
    832c:	97ffeed9 	bl	3e90 <fwp_rc_forget_slot.part.0>
    8330:	17fffff8 	b	8310 <fwp_drop2+0x26c>

0000000000008334 <fwp_arg_drop23>:
    8334:	7100003f 	cmp	w1, #0x0
    8338:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    833c:	54000041 	b.ne	8344 <fwp_arg_drop23+0x10>  // b.any
    8340:	d65f03c0 	ret
    8344:	f9400000 	ldr	x0, [x0]
    8348:	17ffff57 	b	80a4 <fwp_drop2>
    834c:	d503201f 	nop

0000000000008350 <fwp_caps23>:
    8350:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8354:	910003fd 	mov	x29, sp
    8358:	f9000bf3 	str	x19, [sp, #16]
    835c:	aa0003f3 	mov	x19, x0
    8360:	b9400400 	ldr	w0, [x0, #4]
    8364:	340004a0 	cbz	w0, 83f8 <fwp_caps23+0xa8>
    8368:	f9400660 	ldr	x0, [x19, #8]
    836c:	350004e1 	cbnz	w1, 8408 <fwp_caps23+0xb8>
    8370:	97ffff4d 	bl	80a4 <fwp_drop2>
    8374:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    8378:	91154042 	add	x2, x2, #0x550
    837c:	f949d840 	ldr	x0, [x2, #5040]
    8380:	f949ec41 	ldr	x1, [x2, #5080]
    8384:	cb000260 	sub	x0, x19, x0
    8388:	eb01401f 	cmp	x0, x1, lsl #16
    838c:	54000382 	b.cs	83fc <fwp_caps23+0xac>  // b.hs, b.nlast
    8390:	d350fc01 	lsr	x1, x0, #16
    8394:	f949fc44 	ldr	x4, [x2, #5112]
    8398:	8b010821 	add	x1, x1, x1, lsl #2
    839c:	d37df021 	lsl	x1, x1, #3
    83a0:	8b010083 	add	x3, x4, x1
    83a4:	f9401062 	ldr	x2, [x3, #32]
    83a8:	b40002a2 	cbz	x2, 83fc <fwp_caps23+0xac>
    83ac:	38616881 	ldrb	w1, [x4, x1]
    83b0:	7100083f 	cmp	w1, #0x2
    83b4:	540006c0 	b.eq	848c <fwp_caps23+0x13c>  // b.none
    83b8:	7100043f 	cmp	w1, #0x1
    83bc:	54000201 	b.ne	83fc <fwp_caps23+0xac>  // b.any
    83c0:	29430464 	ldp	w4, w1, [x3, #24]
    83c4:	92403c00 	and	x0, x0, #0xffff
    83c8:	9b047c00 	mul	x0, x0, x4
    83cc:	d360fc00 	lsr	x0, x0, #32
    83d0:	eb01001f 	cmp	x0, x1
    83d4:	54000142 	b.cs	83fc <fwp_caps23+0xac>  // b.hs, b.nlast
    83d8:	8b000042 	add	x2, x2, x0
    83dc:	39400040 	ldrb	w0, [x2]
    83e0:	7100041f 	cmp	w0, #0x1
    83e4:	540000c1 	b.ne	83fc <fwp_caps23+0xac>  // b.any
    83e8:	aa1303e0 	mov	x0, x19
    83ec:	f9400bf3 	ldr	x19, [sp, #16]
    83f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    83f4:	17ffef43 	b	4100 <fwp_mem_free>
    83f8:	34fffbe1 	cbz	w1, 8374 <fwp_caps23+0x24>
    83fc:	f9400bf3 	ldr	x19, [sp, #16]
    8400:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8404:	d65f03c0 	ret
    8408:	b0000142 	adrp	x2, 31000 <fwp_root_context+0xc90>
    840c:	91154042 	add	x2, x2, #0x550
    8410:	f949d843 	ldr	x3, [x2, #5040]
    8414:	f949ec41 	ldr	x1, [x2, #5080]
    8418:	cb030000 	sub	x0, x0, x3
    841c:	eb01401f 	cmp	x0, x1, lsl #16
    8420:	54fffee2 	b.cs	83fc <fwp_caps23+0xac>  // b.hs, b.nlast
    8424:	d350fc01 	lsr	x1, x0, #16
    8428:	f949fc44 	ldr	x4, [x2, #5112]
    842c:	8b010821 	add	x1, x1, x1, lsl #2
    8430:	d37df021 	lsl	x1, x1, #3
    8434:	8b010083 	add	x3, x4, x1
    8438:	f9401062 	ldr	x2, [x3, #32]
    843c:	b4fffe02 	cbz	x2, 83fc <fwp_caps23+0xac>
    8440:	38616881 	ldrb	w1, [x4, x1]
    8444:	7100083f 	cmp	w1, #0x2
    8448:	54000280 	b.eq	8498 <fwp_caps23+0x148>  // b.none
    844c:	7100043f 	cmp	w1, #0x1
    8450:	54fffd61 	b.ne	83fc <fwp_caps23+0xac>  // b.any
    8454:	92403c01 	and	x1, x0, #0xffff
    8458:	29430064 	ldp	w4, w0, [x3, #24]
    845c:	9b047c21 	mul	x1, x1, x4
    8460:	d360fc21 	lsr	x1, x1, #32
    8464:	eb00003f 	cmp	x1, x0
    8468:	54fffca2 	b.cs	83fc <fwp_caps23+0xac>  // b.hs, b.nlast
    846c:	8b010042 	add	x2, x2, x1
    8470:	39400040 	ldrb	w0, [x2]
    8474:	34fffc40 	cbz	w0, 83fc <fwp_caps23+0xac>
    8478:	7103f41f 	cmp	w0, #0xfd
    847c:	54000148 	b.hi	84a4 <fwp_caps23+0x154>  // b.pmore
    8480:	11000400 	add	w0, w0, #0x1
    8484:	39000040 	strb	w0, [x2]
    8488:	17ffffdd 	b	83fc <fwp_caps23+0xac>
    848c:	72003c1f 	tst	w0, #0xffff
    8490:	54fffb61 	b.ne	83fc <fwp_caps23+0xac>  // b.any
    8494:	17ffffd2 	b	83dc <fwp_caps23+0x8c>
    8498:	72003c1f 	tst	w0, #0xffff
    849c:	54fffb01 	b.ne	83fc <fwp_caps23+0xac>  // b.any
    84a0:	17fffff4 	b	8470 <fwp_caps23+0x120>
    84a4:	f9400bf3 	ldr	x19, [sp, #16]
    84a8:	aa0203e0 	mov	x0, x2
    84ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    84b0:	17ffef8d 	b	42e4 <fwp_rc_wide_dup>

00000000000084b4 <f23>:
    84b4:	d10203ff 	sub	sp, sp, #0x80
    84b8:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb38>
    84bc:	f947f421 	ldr	x1, [x1, #4072]
    84c0:	a9027bfd 	stp	x29, x30, [sp, #32]
    84c4:	910083fd 	add	x29, sp, #0x20
    84c8:	a9045bf5 	stp	x21, x22, [sp, #64]
    84cc:	b0000155 	adrp	x21, 31000 <fwp_root_context+0xc90>
    84d0:	911542a3 	add	x3, x21, #0x550
    84d4:	a90353f3 	stp	x19, x20, [sp, #48]
    84d8:	aa0003f6 	mov	x22, x0
    84dc:	a90563f7 	stp	x23, x24, [sp, #80]
    84e0:	a9066bf9 	stp	x25, x26, [sp, #96]
    84e4:	f949ec62 	ldr	x2, [x3, #5080]
    84e8:	f9400024 	ldr	x4, [x1]
    84ec:	f9000fe4 	str	x4, [sp, #24]
    84f0:	d2800004 	mov	x4, #0x0                   	// #0
    84f4:	f949d861 	ldr	x1, [x3, #5040]
    84f8:	d370bc42 	lsl	x2, x2, #16
    84fc:	b4001800 	cbz	x0, 87fc <f23+0x348>
    8500:	f9400817 	ldr	x23, [x0, #16]
    8504:	cb0102e1 	sub	x1, x23, x1
    8508:	eb02003f 	cmp	x1, x2
    850c:	54000362 	b.cs	8578 <f23+0xc4>  // b.hs, b.nlast
    8510:	f949fc60 	ldr	x0, [x3, #5112]
    8514:	d350fc22 	lsr	x2, x1, #16
    8518:	8b020842 	add	x2, x2, x2, lsl #2
    851c:	8b020c02 	add	x2, x0, x2, lsl #3
    8520:	f9401040 	ldr	x0, [x2, #32]
    8524:	b40002a0 	cbz	x0, 8578 <f23+0xc4>
    8528:	39400043 	ldrb	w3, [x2]
    852c:	7100087f 	cmp	w3, #0x2
    8530:	54001540 	b.eq	87d8 <f23+0x324>  // b.none
    8534:	7100047f 	cmp	w3, #0x1
    8538:	540001c1 	b.ne	8570 <f23+0xbc>  // b.any
    853c:	29430843 	ldp	w3, w2, [x2, #24]
    8540:	92403c21 	and	x1, x1, #0xffff
    8544:	9b037c21 	mul	x1, x1, x3
    8548:	d360fc21 	lsr	x1, x1, #32
    854c:	eb02003f 	cmp	x1, x2
    8550:	54000102 	b.cs	8570 <f23+0xbc>  // b.hs, b.nlast
    8554:	8b010000 	add	x0, x0, x1
    8558:	39400001 	ldrb	w1, [x0]
    855c:	340000a1 	cbz	w1, 8570 <f23+0xbc>
    8560:	7103f43f 	cmp	w1, #0xfd
    8564:	540017e8 	b.hi	8860 <f23+0x3ac>  // b.pmore
    8568:	11000421 	add	w1, w1, #0x1
    856c:	39000001 	strb	w1, [x0]
    8570:	d2800002 	mov	x2, #0x0                   	// #0
    8574:	b40000d6 	cbz	x22, 858c <f23+0xd8>
    8578:	aa1603e1 	mov	x1, x22
    857c:	d2800002 	mov	x2, #0x0                   	// #0
    8580:	f9400821 	ldr	x1, [x1, #16]
    8584:	91000442 	add	x2, x2, #0x1
    8588:	b5ffffc1 	cbnz	x1, 8580 <f23+0xcc>
    858c:	b40013f7 	cbz	x23, 8808 <f23+0x354>
    8590:	aa1703e1 	mov	x1, x23
    8594:	d2800003 	mov	x3, #0x0                   	// #0
    8598:	f9400821 	ldr	x1, [x1, #16]
    859c:	91000463 	add	x3, x3, #0x1
    85a0:	b5ffffc1 	cbnz	x1, 8598 <f23+0xe4>
    85a4:	eb02007f 	cmp	x3, x2
    85a8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    85ac:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    85b0:	eb00027f 	cmp	x19, x0
    85b4:	540010a8 	b.hi	87c8 <f23+0x314>  // b.pmore
    85b8:	d37ffa74 	lsl	x20, x19, #1
    85bc:	52800041 	mov	w1, #0x2                   	// #2
    85c0:	91000680 	add	x0, x20, #0x1
    85c4:	d37df000 	lsl	x0, x0, #3
    85c8:	97fff18a 	bl	4bf0 <fwp_heap_alloc>
    85cc:	aa0003f8 	mov	x24, x0
    85d0:	911542a1 	add	x1, x21, #0x550
    85d4:	aa0103e0 	mov	x0, x1
    85d8:	f9000314 	str	x20, [x24]
    85dc:	f949d821 	ldr	x1, [x1, #5040]
    85e0:	f949ec00 	ldr	x0, [x0, #5080]
    85e4:	cb010301 	sub	x1, x24, x1
    85e8:	eb00403f 	cmp	x1, x0, lsl #16
    85ec:	54000342 	b.cs	8654 <f23+0x1a0>  // b.hs, b.nlast
    85f0:	911542a2 	add	x2, x21, #0x550
    85f4:	d350fc20 	lsr	x0, x1, #16
    85f8:	8b000800 	add	x0, x0, x0, lsl #2
    85fc:	f949fc43 	ldr	x3, [x2, #5112]
    8600:	d37df002 	lsl	x2, x0, #3
    8604:	8b020060 	add	x0, x3, x2
    8608:	f9401014 	ldr	x20, [x0, #32]
    860c:	b4000254 	cbz	x20, 8654 <f23+0x1a0>
    8610:	38626862 	ldrb	w2, [x3, x2]
    8614:	7100085f 	cmp	w2, #0x2
    8618:	54000ec0 	b.eq	87f0 <f23+0x33c>  // b.none
    861c:	7100045f 	cmp	w2, #0x1
    8620:	540001a1 	b.ne	8654 <f23+0x1a0>  // b.any
    8624:	29430002 	ldp	w2, w0, [x0, #24]
    8628:	92403c21 	and	x1, x1, #0xffff
    862c:	9b027c21 	mul	x1, x1, x2
    8630:	d360fc21 	lsr	x1, x1, #32
    8634:	eb00003f 	cmp	x1, x0
    8638:	540000e2 	b.cs	8654 <f23+0x1a0>  // b.hs, b.nlast
    863c:	8b010294 	add	x20, x20, x1
    8640:	39400280 	ldrb	w0, [x20]
    8644:	7103fc1f 	cmp	w0, #0xff
    8648:	54001100 	b.eq	8868 <f23+0x3b4>  // b.none
    864c:	52800020 	mov	w0, #0x1                   	// #1
    8650:	39000280 	strb	w0, [x20]
    8654:	b4000253 	cbz	x19, 869c <f23+0x1e8>
    8658:	8b131313 	add	x19, x24, x19, lsl #4
    865c:	aa1803f4 	mov	x20, x24
    8660:	aa1603fa 	mov	x26, x22
    8664:	aa1703f9 	mov	x25, x23
    8668:	f9400723 	ldr	x3, [x25, #8]
    866c:	f9400742 	ldr	x2, [x26, #8]
    8670:	f9400861 	ldr	x1, [x3, #16]
    8674:	f9400840 	ldr	x0, [x2, #16]
    8678:	fd400461 	ldr	d1, [x3, #8]
    867c:	fd400440 	ldr	d0, [x2, #8]
    8680:	97fff309 	bl	52a4 <w107>
    8684:	f9000680 	str	x0, [x20, #8]
    8688:	f8010e81 	str	x1, [x20, #16]!
    868c:	f9400b39 	ldr	x25, [x25, #16]
    8690:	f9400b5a 	ldr	x26, [x26, #16]
    8694:	eb14027f 	cmp	x19, x20
    8698:	54fffe81 	b.ne	8668 <f23+0x1b4>  // b.any
    869c:	aa1703e0 	mov	x0, x23
    86a0:	97fffe81 	bl	80a4 <fwp_drop2>
    86a4:	aa1603e0 	mov	x0, x22
    86a8:	97fffe7f 	bl	80a4 <fwp_drop2>
    86ac:	f9400316 	ldr	x22, [x24]
    86b0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    86b4:	b4000236 	cbz	x22, 86f8 <f23+0x244>
    86b8:	fd003be8 	str	d8, [sp, #112]
    86bc:	2f00e408 	movi	d8, #0x0
    86c0:	91002319 	add	x25, x24, #0x8
    86c4:	91004317 	add	x23, x24, #0x10
    86c8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    86cc:	d2800013 	mov	x19, #0x0                   	// #0
    86d0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    86d4:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    86d8:	91000a73 	add	x19, x19, #0x2
    86dc:	1e602908 	fadd	d8, d8, d0
    86e0:	97fff2a0 	bl	5160 <f128.constprop.0>
    86e4:	aa0003f4 	mov	x20, x0
    86e8:	eb1302df 	cmp	x22, x19
    86ec:	54ffff28 	b.hi	86d0 <f23+0x21c>  // b.pmore
    86f0:	9e660116 	fmov	x22, d8
    86f4:	fd403be8 	ldr	d8, [sp, #112]
    86f8:	911542b5 	add	x21, x21, #0x550
    86fc:	aa1803e0 	mov	x0, x24
    8700:	97fff8a4 	bl	6990 <fwp_drop4>
    8704:	a900d3f6 	stp	x22, x20, [sp, #8]
    8708:	910023e1 	add	x1, sp, #0x8
    870c:	52800000 	mov	w0, #0x0                   	// #0
    8710:	97fff3f8 	bl	56f0 <fwp_data.part.0.constprop.0>
    8714:	f949daa1 	ldr	x1, [x21, #5040]
    8718:	aa0003f3 	mov	x19, x0
    871c:	f949eea0 	ldr	x0, [x21, #5080]
    8720:	cb010261 	sub	x1, x19, x1
    8724:	eb00403f 	cmp	x1, x0, lsl #16
    8728:	54000322 	b.cs	878c <f23+0x2d8>  // b.hs, b.nlast
    872c:	d350fc22 	lsr	x2, x1, #16
    8730:	f949fea3 	ldr	x3, [x21, #5112]
    8734:	8b020842 	add	x2, x2, x2, lsl #2
    8738:	d37df042 	lsl	x2, x2, #3
    873c:	8b020060 	add	x0, x3, x2
    8740:	f9401014 	ldr	x20, [x0, #32]
    8744:	b4000254 	cbz	x20, 878c <f23+0x2d8>
    8748:	38626862 	ldrb	w2, [x3, x2]
    874c:	7100085f 	cmp	w2, #0x2
    8750:	540004a0 	b.eq	87e4 <f23+0x330>  // b.none
    8754:	7100045f 	cmp	w2, #0x1
    8758:	540001a1 	b.ne	878c <f23+0x2d8>  // b.any
    875c:	29430002 	ldp	w2, w0, [x0, #24]
    8760:	92403c21 	and	x1, x1, #0xffff
    8764:	9b027c21 	mul	x1, x1, x2
    8768:	d360fc21 	lsr	x1, x1, #32
    876c:	eb00003f 	cmp	x1, x0
    8770:	540000e2 	b.cs	878c <f23+0x2d8>  // b.hs, b.nlast
    8774:	8b010294 	add	x20, x20, x1
    8778:	39400280 	ldrb	w0, [x20]
    877c:	7103fc1f 	cmp	w0, #0xff
    8780:	540007a0 	b.eq	8874 <f23+0x3c0>  // b.none
    8784:	52800020 	mov	w0, #0x1                   	// #1
    8788:	39000280 	strb	w0, [x20]
    878c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8790:	f947f400 	ldr	x0, [x0, #4072]
    8794:	f9400fe2 	ldr	x2, [sp, #24]
    8798:	f9400001 	ldr	x1, [x0]
    879c:	eb010042 	subs	x2, x2, x1
    87a0:	d2800001 	mov	x1, #0x0                   	// #0
    87a4:	54000721 	b.ne	8888 <f23+0x3d4>  // b.any
    87a8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    87ac:	aa1303e0 	mov	x0, x19
    87b0:	a94353f3 	ldp	x19, x20, [sp, #48]
    87b4:	a9445bf5 	ldp	x21, x22, [sp, #64]
    87b8:	a94563f7 	ldp	x23, x24, [sp, #80]
    87bc:	a9466bf9 	ldp	x25, x26, [sp, #96]
    87c0:	910203ff 	add	sp, sp, #0x80
    87c4:	d65f03c0 	ret
    87c8:	f0000000 	adrp	x0, b000 <fwp_main_thread+0x1730>
    87cc:	9132e000 	add	x0, x0, #0xcb8
    87d0:	fd003be8 	str	d8, [sp, #112]
    87d4:	97ffed8f 	bl	3e10 <fwp_trap>
    87d8:	72003c3f 	tst	w1, #0xffff
    87dc:	54ffeca1 	b.ne	8570 <f23+0xbc>  // b.any
    87e0:	17ffff5e 	b	8558 <f23+0xa4>
    87e4:	72003c3f 	tst	w1, #0xffff
    87e8:	54fffd21 	b.ne	878c <f23+0x2d8>  // b.any
    87ec:	17ffffe3 	b	8778 <f23+0x2c4>
    87f0:	72003c3f 	tst	w1, #0xffff
    87f4:	54fff301 	b.ne	8654 <f23+0x1a0>  // b.any
    87f8:	17ffff92 	b	8640 <f23+0x18c>
    87fc:	cb0103e1 	neg	x1, x1
    8800:	eb02003f 	cmp	x1, x2
    8804:	540001e3 	b.cc	8840 <f23+0x38c>  // b.lo, b.ul, b.last
    8808:	52800041 	mov	w1, #0x2                   	// #2
    880c:	d2800100 	mov	x0, #0x8                   	// #8
    8810:	97fff0f8 	bl	4bf0 <fwp_heap_alloc>
    8814:	aa0003f8 	mov	x24, x0
    8818:	911542a0 	add	x0, x21, #0x550
    881c:	f900031f 	str	xzr, [x24]
    8820:	f949d801 	ldr	x1, [x0, #5040]
    8824:	f949ec00 	ldr	x0, [x0, #5080]
    8828:	cb010301 	sub	x1, x24, x1
    882c:	eb00403f 	cmp	x1, x0, lsl #16
    8830:	54000282 	b.cs	8880 <f23+0x3cc>  // b.hs, b.nlast
    8834:	d2800013 	mov	x19, #0x0                   	// #0
    8838:	d2800017 	mov	x23, #0x0                   	// #0
    883c:	17ffff6d 	b	85f0 <f23+0x13c>
    8840:	f949fc62 	ldr	x2, [x3, #5112]
    8844:	d350fc20 	lsr	x0, x1, #16
    8848:	8b000800 	add	x0, x0, x0, lsl #2
    884c:	8b000c42 	add	x2, x2, x0, lsl #3
    8850:	f9401040 	ldr	x0, [x2, #32]
    8854:	b4fffda0 	cbz	x0, 8808 <f23+0x354>
    8858:	d2800017 	mov	x23, #0x0                   	// #0
    885c:	17ffff33 	b	8528 <f23+0x74>
    8860:	97ffeea1 	bl	42e4 <fwp_rc_wide_dup>
    8864:	17ffff43 	b	8570 <f23+0xbc>
    8868:	aa1403e0 	mov	x0, x20
    886c:	97ffed89 	bl	3e90 <fwp_rc_forget_slot.part.0>
    8870:	17ffff77 	b	864c <f23+0x198>
    8874:	aa1403e0 	mov	x0, x20
    8878:	97ffed86 	bl	3e90 <fwp_rc_forget_slot.part.0>
    887c:	17ffffc2 	b	8784 <f23+0x2d0>
    8880:	d2800017 	mov	x23, #0x0                   	// #0
    8884:	17ffff86 	b	869c <f23+0x1e8>
    8888:	fd003be8 	str	d8, [sp, #112]
    888c:	97ffe7d9 	bl	27f0 <__stack_chk_fail@plt>

0000000000008890 <fwp_owned_entry23>:
    8890:	f9400000 	ldr	x0, [x0]
    8894:	17ffff08 	b	84b4 <f23>
    8898:	d503201f 	nop
    889c:	d503201f 	nop

00000000000088a0 <e23>:
    88a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    88a4:	910003fd 	mov	x29, sp
    88a8:	f9000bf3 	str	x19, [sp, #16]
    88ac:	f9400013 	ldr	x19, [x0]
    88b0:	aa1303e0 	mov	x0, x19
    88b4:	97fff3d7 	bl	5810 <fwp_rc_share>
    88b8:	aa1303e0 	mov	x0, x19
    88bc:	97fffefe 	bl	84b4 <f23>
    88c0:	aa0003f3 	mov	x19, x0
    88c4:	97fff3d3 	bl	5810 <fwp_rc_share>
    88c8:	aa1303e0 	mov	x0, x19
    88cc:	f9400bf3 	ldr	x19, [sp, #16]
    88d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    88d4:	d65f03c0 	ret
    88d8:	d503201f 	nop
    88dc:	d503201f 	nop

00000000000088e0 <fwp_write>:
    88e0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    88e4:	910003fd 	mov	x29, sp
    88e8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb38>
    88ec:	f947f484 	ldr	x4, [x4, #4072]
    88f0:	a90153f3 	stp	x19, x20, [sp, #16]
    88f4:	d10943ff 	sub	sp, sp, #0x250
    88f8:	b9400045 	ldr	w5, [x2]
    88fc:	aa0003f4 	mov	x20, x0
    8900:	f9400080 	ldr	x0, [x4]
    8904:	f90127e0 	str	x0, [sp, #584]
    8908:	d2800000 	mov	x0, #0x0                   	// #0
    890c:	710064bf 	cmp	w5, #0x19
    8910:	54000408 	b.hi	8990 <fwp_write+0xb0>  // b.pmore
    8914:	90000020 	adrp	x0, c000 <_IO_stdin_used+0x7b0>
    8918:	aa0103f3 	mov	x19, x1
    891c:	91120000 	add	x0, x0, #0x480
    8920:	f9013bf5 	str	x21, [sp, #624]
    8924:	f9013ff6 	str	x22, [sp, #632]
    8928:	f90153fb 	str	x27, [sp, #672]
    892c:	f90157fc 	str	x28, [sp, #680]
    8930:	aa0203fc 	mov	x28, x2
    8934:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8938:	10000061 	adr	x1, 8944 <fwp_write+0x64>
    893c:	8b20a820 	add	x0, x1, w0, sxth #2
    8940:	d61f0000 	br	x0
    8944:	910123e0 	add	x0, sp, #0x48
    8948:	aa1303e5 	mov	x5, x19
    894c:	f0000004 	adrp	x4, b000 <fwp_main_thread+0x1730>
    8950:	aa0003f3 	mov	x19, x0
    8954:	9134e084 	add	x4, x4, #0xd38
    8958:	d2804003 	mov	x3, #0x200                 	// #512
    895c:	aa0303e1 	mov	x1, x3
    8960:	52800042 	mov	w2, #0x2                   	// #2
    8964:	97ffe77f 	bl	2760 <__snprintf_chk@plt>
    8968:	aa1303e0 	mov	x0, x19
    896c:	97ffe745 	bl	2680 <strlen@plt>
    8970:	aa1303e1 	mov	x1, x19
    8974:	aa0003e2 	mov	x2, x0
    8978:	aa1403e0 	mov	x0, x20
    897c:	97ffea85 	bl	3390 <buf_put>
    8980:	f9413bf5 	ldr	x21, [sp, #624]
    8984:	f9413ff6 	ldr	x22, [sp, #632]
    8988:	f94153fb 	ldr	x27, [sp, #672]
    898c:	f94157fc 	ldr	x28, [sp, #680]
    8990:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8994:	f947f400 	ldr	x0, [x0, #4072]
    8998:	f94127e2 	ldr	x2, [sp, #584]
    899c:	f9400001 	ldr	x1, [x0]
    89a0:	eb010042 	subs	x2, x2, x1
    89a4:	d2800001 	mov	x1, #0x0                   	// #0
    89a8:	540077c1 	b.ne	98a0 <fwp_write+0xfc0>  // b.any
    89ac:	910943ff 	add	sp, sp, #0x250
    89b0:	a94153f3 	ldp	x19, x20, [sp, #16]
    89b4:	a8c77bfd 	ldp	x29, x30, [sp], #112
    89b8:	d65f03c0 	ret
    89bc:	910123e0 	add	x0, sp, #0x48
    89c0:	aa1303e5 	mov	x5, x19
    89c4:	f0000004 	adrp	x4, b000 <fwp_main_thread+0x1730>
    89c8:	aa0003f3 	mov	x19, x0
    89cc:	9134c084 	add	x4, x4, #0xd30
    89d0:	d2804003 	mov	x3, #0x200                 	// #512
    89d4:	17ffffe2 	b	895c <fwp_write+0x7c>
    89d8:	71004cbf 	cmp	w5, #0x13
    89dc:	f0000000 	adrp	x0, b000 <fwp_main_thread+0x1730>
    89e0:	f0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    89e4:	91348000 	add	x0, x0, #0xd20
    89e8:	9134a021 	add	x1, x1, #0xd28
    89ec:	d2800082 	mov	x2, #0x4                   	// #4
    89f0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    89f4:	aa1403e0 	mov	x0, x20
    89f8:	f90143f7 	str	x23, [sp, #640]
    89fc:	d2800016 	mov	x22, #0x0                   	// #0
    8a00:	f90147f8 	str	x24, [sp, #648]
    8a04:	97ffea63 	bl	3390 <buf_put>
    8a08:	f9400260 	ldr	x0, [x19]
    8a0c:	f0000017 	adrp	x23, b000 <fwp_main_thread+0x1730>
    8a10:	d2800015 	mov	x21, #0x0                   	// #0
    8a14:	9136a2f7 	add	x23, x23, #0xda8
    8a18:	b40047a0 	cbz	x0, 930c <fwp_write+0xa2c>
    8a1c:	b9400380 	ldr	w0, [x28]
    8a20:	52800003 	mov	w3, #0x0                   	// #0
    8a24:	f9401f82 	ldr	x2, [x28, #56]
    8a28:	71004c1f 	cmp	w0, #0x13
    8a2c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8a30:	aa1403e0 	mov	x0, x20
    8a34:	8b010e61 	add	x1, x19, x1, lsl #3
    8a38:	f9400421 	ldr	x1, [x1, #8]
    8a3c:	97ffffa9 	bl	88e0 <fwp_write>
    8a40:	b9400380 	ldr	w0, [x28]
    8a44:	7100481f 	cmp	w0, #0x12
    8a48:	54004b40 	b.eq	93b0 <fwp_write+0xad0>  // b.none
    8a4c:	f9400260 	ldr	x0, [x19]
    8a50:	910006b5 	add	x21, x21, #0x1
    8a54:	91000ad6 	add	x22, x22, #0x2
    8a58:	eb15001f 	cmp	x0, x21
    8a5c:	54004589 	b.ls	930c <fwp_write+0xa2c>  // b.plast
    8a60:	aa1703e1 	mov	x1, x23
    8a64:	aa1403e0 	mov	x0, x20
    8a68:	d2800042 	mov	x2, #0x2                   	// #2
    8a6c:	97ffea49 	bl	3390 <buf_put>
    8a70:	17ffffeb 	b	8a1c <fwp_write+0x13c>
    8a74:	f0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    8a78:	91358021 	add	x1, x1, #0xd60
    8a7c:	d28000c2 	mov	x2, #0x6                   	// #6
    8a80:	aa1403e0 	mov	x0, x20
    8a84:	91004273 	add	x19, x19, #0x10
    8a88:	97ffea42 	bl	3390 <buf_put>
    8a8c:	aa1303e0 	mov	x0, x19
    8a90:	97ffe6fc 	bl	2680 <strlen@plt>
    8a94:	aa1303e1 	mov	x1, x19
    8a98:	aa0003e2 	mov	x2, x0
    8a9c:	aa1403e0 	mov	x0, x20
    8aa0:	97ffea3c 	bl	3390 <buf_put>
    8aa4:	528007c3 	mov	w3, #0x3e                  	// #62
    8aa8:	aa1403e0 	mov	x0, x20
    8aac:	91001fe1 	add	x1, sp, #0x7
    8ab0:	d2800022 	mov	x2, #0x1                   	// #1
    8ab4:	39001fe3 	strb	w3, [sp, #7]
    8ab8:	17ffffb1 	b	897c <fwp_write+0x9c>
    8abc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ac0:	f947f400 	ldr	x0, [x0, #4072]
    8ac4:	f94127e2 	ldr	x2, [sp, #584]
    8ac8:	f9400001 	ldr	x1, [x0]
    8acc:	eb010042 	subs	x2, x2, x1
    8ad0:	d2800001 	mov	x1, #0x0                   	// #0
    8ad4:	540034e1 	b.ne	9170 <fwp_write+0x890>  // b.any
    8ad8:	f9413bf5 	ldr	x21, [sp, #624]
    8adc:	f0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    8ae0:	f9413ff6 	ldr	x22, [sp, #632]
    8ae4:	aa1403e0 	mov	x0, x20
    8ae8:	91350021 	add	x1, x1, #0xd40
    8aec:	d2800142 	mov	x2, #0xa                   	// #10
    8af0:	f94153fb 	ldr	x27, [sp, #672]
    8af4:	f94157fc 	ldr	x28, [sp, #680]
    8af8:	910943ff 	add	sp, sp, #0x250
    8afc:	a94153f3 	ldp	x19, x20, [sp, #16]
    8b00:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8b04:	17ffea23 	b	3390 <buf_put>
    8b08:	f9400456 	ldr	x22, [x2, #8]
    8b0c:	f90143f7 	str	x23, [sp, #640]
    8b10:	f90147f8 	str	x24, [sp, #648]
    8b14:	b4005b16 	cbz	x22, 9674 <fwp_write+0xd94>
    8b18:	aa1603e0 	mov	x0, x22
    8b1c:	f0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    8b20:	91370021 	add	x1, x1, #0xdc0
    8b24:	97ffe753 	bl	2870 <strcmp@plt>
    8b28:	2a0003f5 	mov	w21, w0
    8b2c:	34005fe0 	cbz	w0, 9728 <fwp_write+0xe48>
    8b30:	aa1603e0 	mov	x0, x22
    8b34:	97ffe6d3 	bl	2680 <strlen@plt>
    8b38:	aa1603e1 	mov	x1, x22
    8b3c:	aa0003e2 	mov	x2, x0
    8b40:	aa1403e0 	mov	x0, x20
    8b44:	97ffea13 	bl	3390 <buf_put>
    8b48:	52800403 	mov	w3, #0x20                  	// #32
    8b4c:	91001ff5 	add	x21, sp, #0x7
    8b50:	aa1503e1 	mov	x1, x21
    8b54:	aa1403e0 	mov	x0, x20
    8b58:	d2800022 	mov	x2, #0x1                   	// #1
    8b5c:	39001fe3 	strb	w3, [sp, #7]
    8b60:	97ffea0c 	bl	3390 <buf_put>
    8b64:	52800f63 	mov	w3, #0x7b                  	// #123
    8b68:	aa1403e0 	mov	x0, x20
    8b6c:	aa1503e1 	mov	x1, x21
    8b70:	d2800022 	mov	x2, #0x1                   	// #1
    8b74:	39001fe3 	strb	w3, [sp, #7]
    8b78:	97ffea06 	bl	3390 <buf_put>
    8b7c:	b9401380 	ldr	w0, [x28, #16]
    8b80:	52800018 	mov	w24, #0x0                   	// #0
    8b84:	7100001f 	cmp	w0, #0x0
    8b88:	54003aad 	b.le	92dc <fwp_write+0x9fc>
    8b8c:	f9014bf9 	str	x25, [sp, #656]
    8b90:	f0000019 	adrp	x25, b000 <fwp_main_thread+0x1730>
    8b94:	9137a339 	add	x25, x25, #0xde8
    8b98:	f9014ffa 	str	x26, [sp, #664]
    8b9c:	f000001a 	adrp	x26, b000 <fwp_main_thread+0x1730>
    8ba0:	9136a35a 	add	x26, x26, #0xda8
    8ba4:	91002276 	add	x22, x19, #0x8
    8ba8:	d2800013 	mov	x19, #0x0                   	// #0
    8bac:	b5003e93 	cbnz	x19, 937c <fwp_write+0xa9c>
    8bb0:	d37df277 	lsl	x23, x19, #3
    8bb4:	34003cb8 	cbz	w24, 9348 <fwp_write+0xa68>
    8bb8:	f9401382 	ldr	x2, [x28, #32]
    8bbc:	aa1403e0 	mov	x0, x20
    8bc0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8bc4:	52800003 	mov	w3, #0x0                   	// #0
    8bc8:	f8776842 	ldr	x2, [x2, x23]
    8bcc:	91000673 	add	x19, x19, #0x1
    8bd0:	97ffff44 	bl	88e0 <fwp_write>
    8bd4:	b9401380 	ldr	w0, [x28, #16]
    8bd8:	6b13001f 	cmp	w0, w19
    8bdc:	54fffe8c 	b.gt	8bac <fwp_write+0x2cc>
    8be0:	f9414bf9 	ldr	x25, [sp, #656]
    8be4:	f9414ffa 	ldr	x26, [sp, #664]
    8be8:	340037b8 	cbz	w24, 92dc <fwp_write+0x9fc>
    8bec:	52800523 	mov	w3, #0x29                  	// #41
    8bf0:	aa1503e1 	mov	x1, x21
    8bf4:	aa1403e0 	mov	x0, x20
    8bf8:	d2800022 	mov	x2, #0x1                   	// #1
    8bfc:	39001fe3 	strb	w3, [sp, #7]
    8c00:	97ffe9e4 	bl	3390 <buf_put>
    8c04:	f9413bf5 	ldr	x21, [sp, #624]
    8c08:	f9413ff6 	ldr	x22, [sp, #632]
    8c0c:	f94143f7 	ldr	x23, [sp, #640]
    8c10:	f94147f8 	ldr	x24, [sp, #648]
    8c14:	f94153fb 	ldr	x27, [sp, #672]
    8c18:	f94157fc 	ldr	x28, [sp, #680]
    8c1c:	17ffff5d 	b	8990 <fwp_write+0xb0>
    8c20:	b9404855 	ldr	w21, [x2, #72]
    8c24:	aa1403e0 	mov	x0, x20
    8c28:	93407eb6 	sxtw	x22, w21
    8c2c:	91000ac1 	add	x1, x22, #0x2
    8c30:	97ffe9a5 	bl	32c4 <buf_grow>
    8c34:	a9400281 	ldp	x1, x0, [x20]
    8c38:	528e8603 	mov	w3, #0x7430                	// #29744
    8c3c:	78206823 	strh	w3, [x1, x0]
    8c40:	8b000022 	add	x2, x1, x0
    8c44:	710002bf 	cmp	w21, #0x0
    8c48:	540036cd 	b.le	9320 <fwp_write+0xa40>
    8c4c:	110006a3 	add	w3, w21, #0x1
    8c50:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8c54:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8c58:	91000449 	add	x9, x2, #0x1
    8c5c:	8b23c043 	add	x3, x2, w3, sxtw
    8c60:	f28aaac6 	movk	x6, #0x5556
    8c64:	f2955568 	movk	x8, #0xaaab
    8c68:	1400000d 	b	8c9c <fwp_write+0x3bc>
    8c6c:	d2800021 	mov	x1, #0x1                   	// #1
    8c70:	528005a5 	mov	w5, #0x2d                  	// #45
    8c74:	f100001f 	cmp	x0, #0x0
    8c78:	9b467e60 	smulh	x0, x19, x6
    8c7c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8c80:	381ff465 	strb	w5, [x3], #-1
    8c84:	cb040000 	sub	x0, x0, x4
    8c88:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8c8c:	cb020000 	sub	x0, x0, x2
    8c90:	8b010013 	add	x19, x0, x1
    8c94:	eb03013f 	cmp	x9, x3
    8c98:	54003440 	b.eq	9320 <fwp_write+0xa40>  // b.none
    8c9c:	9b467e60 	smulh	x0, x19, x6
    8ca0:	937ffe64 	asr	x4, x19, #63
    8ca4:	52800605 	mov	w5, #0x30                  	// #48
    8ca8:	cb040000 	sub	x0, x0, x4
    8cac:	8b000400 	add	x0, x0, x0, lsl #1
    8cb0:	cb000260 	sub	x0, x19, x0
    8cb4:	91000c01 	add	x1, x0, #0x3
    8cb8:	9bc87c22 	umulh	x2, x1, x8
    8cbc:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8cc0:	8b4204e2 	add	x2, x7, x2, lsr #1
    8cc4:	eb020021 	subs	x1, x1, x2
    8cc8:	54fffd60 	b.eq	8c74 <fwp_write+0x394>  // b.none
    8ccc:	f100043f 	cmp	x1, #0x1
    8cd0:	54fffce1 	b.ne	8c6c <fwp_write+0x38c>  // b.any
    8cd4:	d2800001 	mov	x1, #0x0                   	// #0
    8cd8:	52800565 	mov	w5, #0x2b                  	// #43
    8cdc:	17ffffe6 	b	8c74 <fwp_write+0x394>
    8ce0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ce4:	f947f400 	ldr	x0, [x0, #4072]
    8ce8:	f94127e2 	ldr	x2, [sp, #584]
    8cec:	f9400001 	ldr	x1, [x0]
    8cf0:	eb010042 	subs	x2, x2, x1
    8cf4:	d2800001 	mov	x1, #0x0                   	// #0
    8cf8:	540023c1 	b.ne	9170 <fwp_write+0x890>  // b.any
    8cfc:	f9413bf5 	ldr	x21, [sp, #624]
    8d00:	f0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    8d04:	f9413ff6 	ldr	x22, [sp, #632]
    8d08:	aa1403e0 	mov	x0, x20
    8d0c:	91354021 	add	x1, x1, #0xd50
    8d10:	d2800102 	mov	x2, #0x8                   	// #8
    8d14:	17ffff77 	b	8af0 <fwp_write+0x210>
    8d18:	aa1403e0 	mov	x0, x20
    8d1c:	f0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    8d20:	d28000c2 	mov	x2, #0x6                   	// #6
    8d24:	9136c021 	add	x1, x1, #0xdb0
    8d28:	97ffe99a 	bl	3390 <buf_put>
    8d2c:	d2800015 	mov	x21, #0x0                   	// #0
    8d30:	f9400263 	ldr	x3, [x19]
    8d34:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8d38:	54002c60 	b.eq	92c4 <fwp_write+0x9e4>  // b.none
    8d3c:	f9401f82 	ldr	x2, [x28, #56]
    8d40:	f90143f7 	str	x23, [sp, #640]
    8d44:	f90147f8 	str	x24, [sp, #648]
    8d48:	d2800857 	mov	x23, #0x42                  	// #66
    8d4c:	f9014bf9 	str	x25, [sp, #656]
    8d50:	f0000016 	adrp	x22, b000 <fwp_main_thread+0x1730>
    8d54:	f9014ffa 	str	x26, [sp, #664]
    8d58:	9136a2d6 	add	x22, x22, #0xda8
    8d5c:	d2800038 	mov	x24, #0x1                   	// #1
    8d60:	f2a18017 	movk	x23, #0xc00, lsl #16
    8d64:	d2809099 	mov	x25, #0x484                 	// #1156
    8d68:	b40004a2 	cbz	x2, 8dfc <fwp_write+0x51c>
    8d6c:	b9400040 	ldr	w0, [x2]
    8d70:	7100701f 	cmp	w0, #0x1c
    8d74:	540042c0 	b.eq	95cc <fwp_write+0xcec>  // b.none
    8d78:	71006c1f 	cmp	w0, #0x1b
    8d7c:	54000408 	b.hi	8dfc <fwp_write+0x51c>  // b.pmore
    8d80:	9ac02301 	lsl	x1, x24, x0
    8d84:	ea17003f 	tst	x1, x23
    8d88:	540036a1 	b.ne	945c <fwp_write+0xb7c>  // b.any
    8d8c:	ea19003f 	tst	x1, x25
    8d90:	54003521 	b.ne	9434 <fwp_write+0xb54>  // b.any
    8d94:	d2800424 	mov	x4, #0x21                  	// #33
    8d98:	ea04003f 	tst	x1, x4
    8d9c:	54000300 	b.eq	8dfc <fwp_write+0x51c>  // b.none
    8da0:	b7f849c3 	tbnz	x3, #63, 96d8 <fwp_write+0xdf8>
    8da4:	91002261 	add	x1, x19, #0x8
    8da8:	8b150021 	add	x1, x1, x21
    8dac:	39400021 	ldrb	w1, [x1]
    8db0:	7100001f 	cmp	w0, #0x0
    8db4:	93401c23 	sxtb	x3, w1
    8db8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8dbc:	d503201f 	nop
    8dc0:	aa1403e0 	mov	x0, x20
    8dc4:	52800003 	mov	w3, #0x0                   	// #0
    8dc8:	97fffec6 	bl	88e0 <fwp_write>
    8dcc:	910006b5 	add	x21, x21, #0x1
    8dd0:	f9400260 	ldr	x0, [x19]
    8dd4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8dd8:	eb0002bf 	cmp	x21, x0
    8ddc:	540026c2 	b.cs	92b4 <fwp_write+0x9d4>  // b.hs, b.nlast
    8de0:	d2800042 	mov	x2, #0x2                   	// #2
    8de4:	aa1603e1 	mov	x1, x22
    8de8:	aa1403e0 	mov	x0, x20
    8dec:	97ffe969 	bl	3390 <buf_put>
    8df0:	f9401f82 	ldr	x2, [x28, #56]
    8df4:	f9400263 	ldr	x3, [x19]
    8df8:	b5fffba2 	cbnz	x2, 8d6c <fwp_write+0x48c>
    8dfc:	d37df2a0 	lsl	x0, x21, #3
    8e00:	b7f83f03 	tbnz	x3, #63, 95e0 <fwp_write+0xd00>
    8e04:	91002261 	add	x1, x19, #0x8
    8e08:	8b000020 	add	x0, x1, x0
    8e0c:	f9400001 	ldr	x1, [x0]
    8e10:	17ffffec 	b	8dc0 <fwp_write+0x4e0>
    8e14:	a9400e62 	ldp	x2, x3, [x19]
    8e18:	b7f83ca3 	tbnz	x3, #63, 95ac <fwp_write+0xccc>
    8e1c:	910123f5 	add	x21, sp, #0x48
    8e20:	aa1503e0 	mov	x0, x21
    8e24:	97ffe7df 	bl	2da0 <fwp_fmt_u128>
    8e28:	aa1503e0 	mov	x0, x21
    8e2c:	97ffe615 	bl	2680 <strlen@plt>
    8e30:	aa1503e1 	mov	x1, x21
    8e34:	aa0003e2 	mov	x2, x0
    8e38:	17fffed0 	b	8978 <fwp_write+0x98>
    8e3c:	fd015be8 	str	d8, [sp, #688]
    8e40:	1e270268 	fmov	s8, w19
    8e44:	fd015fe9 	str	d9, [sp, #696]
    8e48:	1e282100 	fcmp	s8, s8
    8e4c:	54004d26 	b.vs	97f0 <fwp_write+0xf10>
    8e50:	1e20c101 	fabs	s1, s8
    8e54:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8e58:	1e270000 	fmov	s0, w0
    8e5c:	1e202020 	fcmp	s1, s0
    8e60:	54002c0d 	b.le	93e0 <fwp_write+0xb00>
    8e64:	1e202118 	fcmpe	s8, #0.0
    8e68:	f0000002 	adrp	x2, b000 <fwp_main_thread+0x1730>
    8e6c:	9121c042 	add	x2, x2, #0x870
    8e70:	910123f5 	add	x21, sp, #0x48
    8e74:	f0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    8e78:	91340021 	add	x1, x1, #0xd00
    8e7c:	aa1503e0 	mov	x0, x21
    8e80:	9a81c041 	csel	x1, x2, x1, gt
    8e84:	97ffe6ab 	bl	2930 <strcpy@plt>
    8e88:	aa1503e0 	mov	x0, x21
    8e8c:	97ffe5fd 	bl	2680 <strlen@plt>
    8e90:	aa1503e1 	mov	x1, x21
    8e94:	aa0003e2 	mov	x2, x0
    8e98:	aa1403e0 	mov	x0, x20
    8e9c:	97ffe93d 	bl	3390 <buf_put>
    8ea0:	f9413bf5 	ldr	x21, [sp, #624]
    8ea4:	f9413ff6 	ldr	x22, [sp, #632]
    8ea8:	f94153fb 	ldr	x27, [sp, #672]
    8eac:	f94157fc 	ldr	x28, [sp, #680]
    8eb0:	fd415be8 	ldr	d8, [sp, #688]
    8eb4:	fd415fe9 	ldr	d9, [sp, #696]
    8eb8:	17fffeb6 	b	8990 <fwp_write+0xb0>
    8ebc:	f9400276 	ldr	x22, [x19]
    8ec0:	34002e03 	cbz	w3, 9480 <fwp_write+0xba0>
    8ec4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    8ec8:	f947f400 	ldr	x0, [x0, #4072]
    8ecc:	f94127e2 	ldr	x2, [sp, #584]
    8ed0:	f9400001 	ldr	x1, [x0]
    8ed4:	eb010042 	subs	x2, x2, x1
    8ed8:	d2800001 	mov	x1, #0x0                   	// #0
    8edc:	540014a1 	b.ne	9170 <fwp_write+0x890>  // b.any
    8ee0:	aa1603e2 	mov	x2, x22
    8ee4:	91002261 	add	x1, x19, #0x8
    8ee8:	f9413bf5 	ldr	x21, [sp, #624]
    8eec:	aa1403e0 	mov	x0, x20
    8ef0:	f9413ff6 	ldr	x22, [sp, #632]
    8ef4:	17fffeff 	b	8af0 <fwp_write+0x210>
    8ef8:	fd015be8 	str	d8, [sp, #688]
    8efc:	9e670268 	fmov	d8, x19
    8f00:	fd015fe9 	str	d9, [sp, #696]
    8f04:	1e682100 	fcmp	d8, d8
    8f08:	54004746 	b.vs	97f0 <fwp_write+0xf10>
    8f0c:	1e60c101 	fabs	d1, d8
    8f10:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8f14:	9e670000 	fmov	d0, x0
    8f18:	910123f5 	add	x21, sp, #0x48
    8f1c:	52800033 	mov	w19, #0x1                   	// #1
    8f20:	1e602020 	fcmp	d1, d0
    8f24:	540001ad 	b.le	8f58 <fwp_write+0x678>
    8f28:	1e602118 	fcmpe	d8, #0.0
    8f2c:	f0000002 	adrp	x2, b000 <fwp_main_thread+0x1730>
    8f30:	9121c042 	add	x2, x2, #0x870
    8f34:	f0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    8f38:	91340021 	add	x1, x1, #0xd00
    8f3c:	aa1503e0 	mov	x0, x21
    8f40:	9a81c041 	csel	x1, x2, x1, gt
    8f44:	97ffe67b 	bl	2930 <strcpy@plt>
    8f48:	17ffffd0 	b	8e88 <fwp_write+0x5a8>
    8f4c:	11000673 	add	w19, w19, #0x1
    8f50:	71004a7f 	cmp	w19, #0x12
    8f54:	54003860 	b.eq	9660 <fwp_write+0xd80>  // b.none
    8f58:	1e604100 	fmov	d0, d8
    8f5c:	2a1303e1 	mov	w1, w19
    8f60:	aa1503e0 	mov	x0, x21
    8f64:	97ffe967 	bl	3500 <fwp_format_g.constprop.0>
    8f68:	aa1503e0 	mov	x0, x21
    8f6c:	d2800001 	mov	x1, #0x0                   	// #0
    8f70:	97ffe5d8 	bl	26d0 <strtod@plt>
    8f74:	1e602100 	fcmp	d8, d0
    8f78:	54fffea1 	b.ne	8f4c <fwp_write+0x66c>  // b.any
    8f7c:	aa1503e0 	mov	x0, x21
    8f80:	97ffe93d 	bl	3474 <fwp_finish_float>
    8f84:	17ffffc1 	b	8e88 <fwp_write+0x5a8>
    8f88:	a9400e62 	ldp	x2, x3, [x19]
    8f8c:	910123f3 	add	x19, sp, #0x48
    8f90:	aa1303e0 	mov	x0, x19
    8f94:	97ffe783 	bl	2da0 <fwp_fmt_u128>
    8f98:	17fffe74 	b	8968 <fwp_write+0x88>
    8f9c:	f90143f7 	str	x23, [sp, #640]
    8fa0:	f90147f8 	str	x24, [sp, #648]
    8fa4:	2a1303f8 	mov	w24, w19
    8fa8:	f9014bf9 	str	x25, [sp, #656]
    8fac:	f9014ffa 	str	x26, [sp, #664]
    8fb0:	f13ffe7f 	cmp	x19, #0xfff
    8fb4:	54000049 	b.ls	8fbc <fwp_write+0x6dc>  // b.plast
    8fb8:	b9400278 	ldr	w24, [x19]
    8fbc:	f9400f80 	ldr	x0, [x28, #24]
    8fc0:	2a1803f5 	mov	w21, w24
    8fc4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    8fc8:	d37ef6b9 	lsl	x25, x21, #2
    8fcc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    8fd0:	aa1603e0 	mov	x0, x22
    8fd4:	97ffe5ab 	bl	2680 <strlen@plt>
    8fd8:	aa1603e1 	mov	x1, x22
    8fdc:	aa0003e2 	mov	x2, x0
    8fe0:	aa1403e0 	mov	x0, x20
    8fe4:	97ffe8eb 	bl	3390 <buf_put>
    8fe8:	f9401780 	ldr	x0, [x28, #40]
    8fec:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    8ff0:	7100001f 	cmp	w0, #0x0
    8ff4:	5400068d 	b.le	90c4 <fwp_write+0x7e4>
    8ff8:	91002276 	add	x22, x19, #0x8
    8ffc:	91001ff5 	add	x21, sp, #0x7
    9000:	d280001b 	mov	x27, #0x0                   	// #0
    9004:	5280041a 	mov	w26, #0x20                  	// #32
    9008:	f9401b80 	ldr	x0, [x28, #48]
    900c:	aa1503e1 	mov	x1, x21
    9010:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    9014:	d2800022 	mov	x2, #0x1                   	// #1
    9018:	f8786803 	ldr	x3, [x0, x24]
    901c:	aa1403e0 	mov	x0, x20
    9020:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    9024:	39001ffa 	strb	w26, [sp, #7]
    9028:	97ffe8da 	bl	3390 <buf_put>
    902c:	f13ffeff 	cmp	x23, #0xfff
    9030:	b9400261 	ldr	w1, [x19]
    9034:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9038:	7100383f 	cmp	w1, #0xe
    903c:	54000160 	b.eq	9068 <fwp_write+0x788>  // b.none
    9040:	7100403f 	cmp	w1, #0x10
    9044:	54001a60 	b.eq	9390 <fwp_write+0xab0>  // b.none
    9048:	7100283f 	cmp	w1, #0xa
    904c:	54002aa0 	b.eq	95a0 <fwp_write+0xcc0>  // b.none
    9050:	540014ac 	b.gt	92e4 <fwp_write+0xa04>
    9054:	71000c3f 	cmp	w1, #0x3
    9058:	540029ac 	b.gt	958c <fwp_write+0xcac>
    905c:	d37ffee0 	lsr	x0, x23, #63
    9060:	37f814a1 	tbnz	w1, #31, 92f4 <fwp_write+0xa14>
    9064:	d503201f 	nop
    9068:	34001460 	cbz	w0, 92f4 <fwp_write+0xa14>
    906c:	52800503 	mov	w3, #0x28                  	// #40
    9070:	aa1503e1 	mov	x1, x21
    9074:	aa1403e0 	mov	x0, x20
    9078:	d2800022 	mov	x2, #0x1                   	// #1
    907c:	39001fe3 	strb	w3, [sp, #7]
    9080:	97ffe8c4 	bl	3390 <buf_put>
    9084:	aa1303e2 	mov	x2, x19
    9088:	aa1703e1 	mov	x1, x23
    908c:	aa1403e0 	mov	x0, x20
    9090:	52800003 	mov	w3, #0x0                   	// #0
    9094:	97fffe13 	bl	88e0 <fwp_write>
    9098:	52800523 	mov	w3, #0x29                  	// #41
    909c:	aa1503e1 	mov	x1, x21
    90a0:	aa1403e0 	mov	x0, x20
    90a4:	d2800022 	mov	x2, #0x1                   	// #1
    90a8:	39001fe3 	strb	w3, [sp, #7]
    90ac:	97ffe8b9 	bl	3390 <buf_put>
    90b0:	f9401780 	ldr	x0, [x28, #40]
    90b4:	9100077b 	add	x27, x27, #0x1
    90b8:	b8796800 	ldr	w0, [x0, x25]
    90bc:	6b1b001f 	cmp	w0, w27
    90c0:	54fffa4c 	b.gt	9008 <fwp_write+0x728>
    90c4:	f9413bf5 	ldr	x21, [sp, #624]
    90c8:	f9413ff6 	ldr	x22, [sp, #632]
    90cc:	f94143f7 	ldr	x23, [sp, #640]
    90d0:	f94147f8 	ldr	x24, [sp, #648]
    90d4:	f9414bf9 	ldr	x25, [sp, #656]
    90d8:	f9414ffa 	ldr	x26, [sp, #664]
    90dc:	f94153fb 	ldr	x27, [sp, #672]
    90e0:	f94157fc 	ldr	x28, [sp, #680]
    90e4:	17fffe2b 	b	8990 <fwp_write+0xb0>
    90e8:	52800783 	mov	w3, #0x3c                  	// #60
    90ec:	91001ff3 	add	x19, sp, #0x7
    90f0:	aa1303e1 	mov	x1, x19
    90f4:	d2800022 	mov	x2, #0x1                   	// #1
    90f8:	aa1403e0 	mov	x0, x20
    90fc:	39001fe3 	strb	w3, [sp, #7]
    9100:	97ffe8a4 	bl	3390 <buf_put>
    9104:	f9400795 	ldr	x21, [x28, #8]
    9108:	aa1503e0 	mov	x0, x21
    910c:	97ffe55d 	bl	2680 <strlen@plt>
    9110:	aa1503e1 	mov	x1, x21
    9114:	aa0003e2 	mov	x2, x0
    9118:	aa1403e0 	mov	x0, x20
    911c:	97ffe89d 	bl	3390 <buf_put>
    9120:	528007c3 	mov	w3, #0x3e                  	// #62
    9124:	aa1303e1 	mov	x1, x19
    9128:	aa1403e0 	mov	x0, x20
    912c:	d2800022 	mov	x2, #0x1                   	// #1
    9130:	39001fe3 	strb	w3, [sp, #7]
    9134:	17fffe12 	b	897c <fwp_write+0x9c>
    9138:	f100067f 	cmp	x19, #0x1
    913c:	540025a0 	b.eq	95f0 <fwp_write+0xd10>  // b.none
    9140:	b100067f 	cmn	x19, #0x1
    9144:	54002bc0 	b.eq	96bc <fwp_write+0xddc>  // b.none
    9148:	d0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    914c:	91342021 	add	x1, x1, #0xd08
    9150:	d2800022 	mov	x2, #0x1                   	// #1
    9154:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9158:	f947f400 	ldr	x0, [x0, #4072]
    915c:	f94127e4 	ldr	x4, [sp, #584]
    9160:	f9400003 	ldr	x3, [x0]
    9164:	eb030084 	subs	x4, x4, x3
    9168:	d2800003 	mov	x3, #0x0                   	// #0
    916c:	54ffebe0 	b.eq	8ee8 <fwp_write+0x608>  // b.none
    9170:	f90143f7 	str	x23, [sp, #640]
    9174:	f90147f8 	str	x24, [sp, #648]
    9178:	f9014bf9 	str	x25, [sp, #656]
    917c:	f9014ffa 	str	x26, [sp, #664]
    9180:	fd015be8 	str	d8, [sp, #688]
    9184:	fd015fe9 	str	d9, [sp, #696]
    9188:	97ffe59a 	bl	27f0 <__stack_chk_fail@plt>
    918c:	52800b63 	mov	w3, #0x5b                  	// #91
    9190:	91001ff5 	add	x21, sp, #0x7
    9194:	aa1503e1 	mov	x1, x21
    9198:	aa1403e0 	mov	x0, x20
    919c:	d2800022 	mov	x2, #0x1                   	// #1
    91a0:	d0000016 	adrp	x22, b000 <fwp_main_thread+0x1730>
    91a4:	9136a2d6 	add	x22, x22, #0xda8
    91a8:	39001fe3 	strb	w3, [sp, #7]
    91ac:	97ffe879 	bl	3390 <buf_put>
    91b0:	b4000273 	cbz	x19, 91fc <fwp_write+0x91c>
    91b4:	f9400661 	ldr	x1, [x19, #8]
    91b8:	aa1403e0 	mov	x0, x20
    91bc:	f9401f82 	ldr	x2, [x28, #56]
    91c0:	52800003 	mov	w3, #0x0                   	// #0
    91c4:	97fffdc7 	bl	88e0 <fwp_write>
    91c8:	f9400a73 	ldr	x19, [x19, #16]
    91cc:	b4000193 	cbz	x19, 91fc <fwp_write+0x91c>
    91d0:	aa1603e1 	mov	x1, x22
    91d4:	aa1403e0 	mov	x0, x20
    91d8:	d2800042 	mov	x2, #0x2                   	// #2
    91dc:	97ffe86d 	bl	3390 <buf_put>
    91e0:	f9400661 	ldr	x1, [x19, #8]
    91e4:	aa1403e0 	mov	x0, x20
    91e8:	f9401f82 	ldr	x2, [x28, #56]
    91ec:	52800003 	mov	w3, #0x0                   	// #0
    91f0:	97fffdbc 	bl	88e0 <fwp_write>
    91f4:	f9400a73 	ldr	x19, [x19, #16]
    91f8:	b5fffed3 	cbnz	x19, 91d0 <fwp_write+0x8f0>
    91fc:	52800ba3 	mov	w3, #0x5d                  	// #93
    9200:	aa1503e1 	mov	x1, x21
    9204:	aa1403e0 	mov	x0, x20
    9208:	d2800022 	mov	x2, #0x1                   	// #1
    920c:	39001fe3 	strb	w3, [sp, #7]
    9210:	17fffddb 	b	897c <fwp_write+0x9c>
    9214:	aa1403e0 	mov	x0, x20
    9218:	d0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    921c:	d28000c2 	mov	x2, #0x6                   	// #6
    9220:	91366021 	add	x1, x1, #0xd98
    9224:	97ffe85b 	bl	3390 <buf_put>
    9228:	f9400260 	ldr	x0, [x19]
    922c:	b40004c0 	cbz	x0, 92c4 <fwp_write+0x9e4>
    9230:	910123f5 	add	x21, sp, #0x48
    9234:	91002276 	add	x22, x19, #0x8
    9238:	f90143f7 	str	x23, [sp, #640]
    923c:	d2800017 	mov	x23, #0x0                   	// #0
    9240:	f90147f8 	str	x24, [sp, #648]
    9244:	d0000018 	adrp	x24, b000 <fwp_main_thread+0x1730>
    9248:	91368318 	add	x24, x24, #0xda0
    924c:	f9014bf9 	str	x25, [sp, #656]
    9250:	d0000019 	adrp	x25, b000 <fwp_main_thread+0x1730>
    9254:	9136a339 	add	x25, x25, #0xda8
    9258:	f9014ffa 	str	x26, [sp, #664]
    925c:	14000005 	b	9270 <fwp_write+0x990>
    9260:	aa1903e1 	mov	x1, x25
    9264:	aa1403e0 	mov	x0, x20
    9268:	d2800042 	mov	x2, #0x2                   	// #2
    926c:	97ffe849 	bl	3390 <buf_put>
    9270:	38776ac5 	ldrb	w5, [x22, x23]
    9274:	d2804003 	mov	x3, #0x200                 	// #512
    9278:	aa1803e4 	mov	x4, x24
    927c:	aa0303e1 	mov	x1, x3
    9280:	52800042 	mov	w2, #0x2                   	// #2
    9284:	aa1503e0 	mov	x0, x21
    9288:	910006f7 	add	x23, x23, #0x1
    928c:	97ffe535 	bl	2760 <__snprintf_chk@plt>
    9290:	aa1503e0 	mov	x0, x21
    9294:	97ffe4fb 	bl	2680 <strlen@plt>
    9298:	aa1503e1 	mov	x1, x21
    929c:	aa0003e2 	mov	x2, x0
    92a0:	aa1403e0 	mov	x0, x20
    92a4:	97ffe83b 	bl	3390 <buf_put>
    92a8:	f9400260 	ldr	x0, [x19]
    92ac:	eb17001f 	cmp	x0, x23
    92b0:	54fffd88 	b.hi	9260 <fwp_write+0x980>  // b.pmore
    92b4:	f94143f7 	ldr	x23, [sp, #640]
    92b8:	f94147f8 	ldr	x24, [sp, #648]
    92bc:	f9414bf9 	ldr	x25, [sp, #656]
    92c0:	f9414ffa 	ldr	x26, [sp, #664]
    92c4:	52800ba3 	mov	w3, #0x5d                  	// #93
    92c8:	aa1403e0 	mov	x0, x20
    92cc:	91001fe1 	add	x1, sp, #0x7
    92d0:	d2800022 	mov	x2, #0x1                   	// #1
    92d4:	39001fe3 	strb	w3, [sp, #7]
    92d8:	17fffda9 	b	897c <fwp_write+0x9c>
    92dc:	52800fa3 	mov	w3, #0x7d                  	// #125
    92e0:	17fffe44 	b	8bf0 <fwp_write+0x310>
    92e4:	f10002ff 	cmp	x23, #0x0
    92e8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    92ec:	71002c3f 	cmp	w1, #0xb
    92f0:	54ffebc0 	b.eq	9068 <fwp_write+0x788>  // b.none
    92f4:	aa1303e2 	mov	x2, x19
    92f8:	aa1703e1 	mov	x1, x23
    92fc:	aa1403e0 	mov	x0, x20
    9300:	52800003 	mov	w3, #0x0                   	// #0
    9304:	97fffd77 	bl	88e0 <fwp_write>
    9308:	17ffff6a 	b	90b0 <fwp_write+0x7d0>
    930c:	aa1403e0 	mov	x0, x20
    9310:	91001fe1 	add	x1, sp, #0x7
    9314:	52800fa3 	mov	w3, #0x7d                  	// #125
    9318:	d2800022 	mov	x2, #0x1                   	// #1
    931c:	17fffe38 	b	8bfc <fwp_write+0x31c>
    9320:	a9400281 	ldp	x1, x0, [x20]
    9324:	91000800 	add	x0, x0, #0x2
    9328:	8b160000 	add	x0, x0, x22
    932c:	f9000680 	str	x0, [x20, #8]
    9330:	3820683f 	strb	wzr, [x1, x0]
    9334:	f9413bf5 	ldr	x21, [sp, #624]
    9338:	f9413ff6 	ldr	x22, [sp, #632]
    933c:	f94153fb 	ldr	x27, [sp, #672]
    9340:	f94157fc 	ldr	x28, [sp, #680]
    9344:	17fffd93 	b	8990 <fwp_write+0xb0>
    9348:	f9400f80 	ldr	x0, [x28, #24]
    934c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9350:	aa1b03e0 	mov	x0, x27
    9354:	97ffe4cb 	bl	2680 <strlen@plt>
    9358:	aa1b03e1 	mov	x1, x27
    935c:	aa0003e2 	mov	x2, x0
    9360:	aa1403e0 	mov	x0, x20
    9364:	97ffe80b 	bl	3390 <buf_put>
    9368:	aa1903e1 	mov	x1, x25
    936c:	aa1403e0 	mov	x0, x20
    9370:	d2800062 	mov	x2, #0x3                   	// #3
    9374:	97ffe807 	bl	3390 <buf_put>
    9378:	17fffe10 	b	8bb8 <fwp_write+0x2d8>
    937c:	aa1a03e1 	mov	x1, x26
    9380:	aa1403e0 	mov	x0, x20
    9384:	d2800042 	mov	x2, #0x2                   	// #2
    9388:	97ffe802 	bl	3390 <buf_put>
    938c:	17fffe09 	b	8bb0 <fwp_write+0x2d0>
    9390:	f9400660 	ldr	x0, [x19, #8]
    9394:	b4fffb00 	cbz	x0, 92f4 <fwp_write+0xa14>
    9398:	d0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    939c:	91370021 	add	x1, x1, #0xdc0
    93a0:	97ffe534 	bl	2870 <strcmp@plt>
    93a4:	7100001f 	cmp	w0, #0x0
    93a8:	1a9f07e0 	cset	w0, ne	// ne = any
    93ac:	17ffff2f 	b	9068 <fwp_write+0x788>
    93b0:	aa1403e0 	mov	x0, x20
    93b4:	d2800042 	mov	x2, #0x2                   	// #2
    93b8:	d0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    93bc:	9136e021 	add	x1, x1, #0xdb8
    93c0:	97ffe7f4 	bl	3390 <buf_put>
    93c4:	91004261 	add	x1, x19, #0x10
    93c8:	aa1403e0 	mov	x0, x20
    93cc:	f9402382 	ldr	x2, [x28, #64]
    93d0:	52800003 	mov	w3, #0x0                   	// #0
    93d4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    93d8:	97fffd42 	bl	88e0 <fwp_write>
    93dc:	17fffd9c 	b	8a4c <fwp_write+0x16c>
    93e0:	1e22c109 	fcvt	d9, s8
    93e4:	910123f5 	add	x21, sp, #0x48
    93e8:	52800033 	mov	w19, #0x1                   	// #1
    93ec:	d503201f 	nop
    93f0:	1e604120 	fmov	d0, d9
    93f4:	2a1303e1 	mov	w1, w19
    93f8:	aa1503e0 	mov	x0, x21
    93fc:	97ffe841 	bl	3500 <fwp_format_g.constprop.0>
    9400:	aa1503e0 	mov	x0, x21
    9404:	d2800001 	mov	x1, #0x0                   	// #0
    9408:	97ffe526 	bl	28a0 <strtof@plt>
    940c:	1e202100 	fcmp	s8, s0
    9410:	54ffdb60 	b.eq	8f7c <fwp_write+0x69c>  // b.none
    9414:	11000673 	add	w19, w19, #0x1
    9418:	71002a7f 	cmp	w19, #0xa
    941c:	54fffea1 	b.ne	93f0 <fwp_write+0xb10>  // b.any
    9420:	1e604120 	fmov	d0, d9
    9424:	aa1503e0 	mov	x0, x21
    9428:	52800121 	mov	w1, #0x9                   	// #9
    942c:	97ffe835 	bl	3500 <fwp_format_g.constprop.0>
    9430:	17fffed3 	b	8f7c <fwp_write+0x69c>
    9434:	d37ef6a1 	lsl	x1, x21, #2
    9438:	b7f81563 	tbnz	x3, #63, 96e4 <fwp_write+0xe04>
    943c:	91002263 	add	x3, x19, #0x8
    9440:	8b010061 	add	x1, x3, x1
    9444:	b9400023 	ldr	w3, [x1]
    9448:	7100081f 	cmp	w0, #0x2
    944c:	2a0303e1 	mov	w1, w3
    9450:	93407c63 	sxtw	x3, w3
    9454:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9458:	17fffe5a 	b	8dc0 <fwp_write+0x4e0>
    945c:	d37ffaa1 	lsl	x1, x21, #1
    9460:	b7f81363 	tbnz	x3, #63, 96cc <fwp_write+0xdec>
    9464:	91002263 	add	x3, x19, #0x8
    9468:	8b010061 	add	x1, x3, x1
    946c:	79400021 	ldrh	w1, [x1]
    9470:	7100041f 	cmp	w0, #0x1
    9474:	93403c23 	sxth	x3, w1
    9478:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    947c:	17fffe51 	b	8dc0 <fwp_write+0x4e0>
    9480:	52800443 	mov	w3, #0x22                  	// #34
    9484:	91001ff5 	add	x21, sp, #0x7
    9488:	91002273 	add	x19, x19, #0x8
    948c:	aa1503e1 	mov	x1, x21
    9490:	aa1403e0 	mov	x0, x20
    9494:	d2800022 	mov	x2, #0x1                   	// #1
    9498:	39001fe3 	strb	w3, [sp, #7]
    949c:	f90143f7 	str	x23, [sp, #640]
    94a0:	8b160277 	add	x23, x19, x22
    94a4:	f90147f8 	str	x24, [sp, #648]
    94a8:	97ffe7ba 	bl	3390 <buf_put>
    94ac:	b4000696 	cbz	x22, 957c <fwp_write+0xc9c>
    94b0:	d0000018 	adrp	x24, b000 <fwp_main_thread+0x1730>
    94b4:	9135a318 	add	x24, x24, #0xd68
    94b8:	f9014bf9 	str	x25, [sp, #656]
    94bc:	d0000019 	adrp	x25, b000 <fwp_main_thread+0x1730>
    94c0:	91362339 	add	x25, x25, #0xd88
    94c4:	f9014ffa 	str	x26, [sp, #664]
    94c8:	1400000d 	b	94fc <fwp_write+0xc1c>
    94cc:	710024bf 	cmp	w5, #0x9
    94d0:	54000460 	b.eq	955c <fwp_write+0xc7c>  // b.none
    94d4:	710028bf 	cmp	w5, #0xa
    94d8:	54000a61 	b.ne	9624 <fwp_write+0xd44>  // b.any
    94dc:	d0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    94e0:	aa1403e0 	mov	x0, x20
    94e4:	9135e021 	add	x1, x1, #0xd78
    94e8:	d2800042 	mov	x2, #0x2                   	// #2
    94ec:	97ffe7a9 	bl	3390 <buf_put>
    94f0:	91000673 	add	x19, x19, #0x1
    94f4:	eb17027f 	cmp	x19, x23
    94f8:	540003e0 	b.eq	9574 <fwp_write+0xc94>  // b.none
    94fc:	39400265 	ldrb	w5, [x19]
    9500:	710034bf 	cmp	w5, #0xd
    9504:	54000180 	b.eq	9534 <fwp_write+0xc54>  // b.none
    9508:	54fffe29 	b.ls	94cc <fwp_write+0xbec>  // b.plast
    950c:	710088bf 	cmp	w5, #0x22
    9510:	540001c0 	b.eq	9548 <fwp_write+0xc68>  // b.none
    9514:	710170bf 	cmp	w5, #0x5c
    9518:	54000741 	b.ne	9600 <fwp_write+0xd20>  // b.any
    951c:	aa1403e0 	mov	x0, x20
    9520:	d0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    9524:	d2800042 	mov	x2, #0x2                   	// #2
    9528:	9135c021 	add	x1, x1, #0xd70
    952c:	97ffe799 	bl	3390 <buf_put>
    9530:	17fffff0 	b	94f0 <fwp_write+0xc10>
    9534:	aa1903e1 	mov	x1, x25
    9538:	aa1403e0 	mov	x0, x20
    953c:	d2800042 	mov	x2, #0x2                   	// #2
    9540:	97ffe794 	bl	3390 <buf_put>
    9544:	17ffffeb 	b	94f0 <fwp_write+0xc10>
    9548:	aa1803e1 	mov	x1, x24
    954c:	aa1403e0 	mov	x0, x20
    9550:	d2800042 	mov	x2, #0x2                   	// #2
    9554:	97ffe78f 	bl	3390 <buf_put>
    9558:	17ffffe6 	b	94f0 <fwp_write+0xc10>
    955c:	aa1403e0 	mov	x0, x20
    9560:	d0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    9564:	d2800042 	mov	x2, #0x2                   	// #2
    9568:	91360021 	add	x1, x1, #0xd80
    956c:	97ffe789 	bl	3390 <buf_put>
    9570:	17ffffe0 	b	94f0 <fwp_write+0xc10>
    9574:	f9414bf9 	ldr	x25, [sp, #656]
    9578:	f9414ffa 	ldr	x26, [sp, #664]
    957c:	aa1503e1 	mov	x1, x21
    9580:	aa1403e0 	mov	x0, x20
    9584:	52800443 	mov	w3, #0x22                  	// #34
    9588:	17fffd9c 	b	8bf8 <fwp_write+0x318>
    958c:	7100103f 	cmp	w1, #0x4
    9590:	54ffeb21 	b.ne	92f4 <fwp_write+0xa14>  // b.any
    9594:	f94006e0 	ldr	x0, [x23, #8]
    9598:	d37ffc00 	lsr	x0, x0, #63
    959c:	17fffeb3 	b	9068 <fwp_write+0x788>
    95a0:	710002ff 	cmp	w23, #0x0
    95a4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    95a8:	17fffeb0 	b	9068 <fwp_write+0x788>
    95ac:	528005a1 	mov	w1, #0x2d                  	// #45
    95b0:	eb0203e2 	negs	x2, x2
    95b4:	da0303e3 	ngc	x3, x3
    95b8:	910127e0 	add	x0, sp, #0x49
    95bc:	910123f5 	add	x21, sp, #0x48
    95c0:	390123e1 	strb	w1, [sp, #72]
    95c4:	97ffe5f7 	bl	2da0 <fwp_fmt_u128>
    95c8:	17fffe18 	b	8e28 <fwp_write+0x548>
    95cc:	d37ceea1 	lsl	x1, x21, #4
    95d0:	b7f810a3 	tbnz	x3, #63, 97e4 <fwp_write+0xf04>
    95d4:	91002260 	add	x0, x19, #0x8
    95d8:	8b010001 	add	x1, x0, x1
    95dc:	17fffdf9 	b	8dc0 <fwp_write+0x4e0>
    95e0:	f9400a61 	ldr	x1, [x19, #16]
    95e4:	8b010000 	add	x0, x0, x1
    95e8:	f9400001 	ldr	x1, [x0]
    95ec:	17fffdf5 	b	8dc0 <fwp_write+0x4e0>
    95f0:	d0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    95f4:	d2800042 	mov	x2, #0x2                   	// #2
    95f8:	91344021 	add	x1, x1, #0xd10
    95fc:	17fffed6 	b	9154 <fwp_write+0x874>
    9600:	7101fcbf 	cmp	w5, #0x7f
    9604:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    9608:	540000e9 	b.ls	9624 <fwp_write+0xd44>  // b.plast
    960c:	aa1503e1 	mov	x1, x21
    9610:	aa1403e0 	mov	x0, x20
    9614:	d2800022 	mov	x2, #0x1                   	// #1
    9618:	39001fe5 	strb	w5, [sp, #7]
    961c:	97ffe75d 	bl	3390 <buf_put>
    9620:	17ffffb4 	b	94f0 <fwp_write+0xc10>
    9624:	d2800203 	mov	x3, #0x10                  	// #16
    9628:	d0000004 	adrp	x4, b000 <fwp_main_thread+0x1730>
    962c:	aa0303e1 	mov	x1, x3
    9630:	91364084 	add	x4, x4, #0xd90
    9634:	910123f6 	add	x22, sp, #0x48
    9638:	52800042 	mov	w2, #0x2                   	// #2
    963c:	aa1603e0 	mov	x0, x22
    9640:	97ffe448 	bl	2760 <__snprintf_chk@plt>
    9644:	aa1603e0 	mov	x0, x22
    9648:	97ffe40e 	bl	2680 <strlen@plt>
    964c:	aa1603e1 	mov	x1, x22
    9650:	aa0003e2 	mov	x2, x0
    9654:	aa1403e0 	mov	x0, x20
    9658:	97ffe74e 	bl	3390 <buf_put>
    965c:	17ffffa5 	b	94f0 <fwp_write+0xc10>
    9660:	1e604100 	fmov	d0, d8
    9664:	aa1503e0 	mov	x0, x21
    9668:	52800221 	mov	w1, #0x11                  	// #17
    966c:	97ffe7a5 	bl	3500 <fwp_format_g.constprop.0>
    9670:	17fffe43 	b	8f7c <fwp_write+0x69c>
    9674:	b9401040 	ldr	w0, [x2, #16]
    9678:	350003c0 	cbnz	w0, 96f0 <fwp_write+0xe10>
    967c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    9680:	f947f400 	ldr	x0, [x0, #4072]
    9684:	f94127e2 	ldr	x2, [sp, #584]
    9688:	f9400001 	ldr	x1, [x0]
    968c:	eb010042 	subs	x2, x2, x1
    9690:	d2800001 	mov	x1, #0x0                   	// #0
    9694:	54ffd721 	b.ne	9178 <fwp_write+0x898>  // b.any
    9698:	f9413bf5 	ldr	x21, [sp, #624]
    969c:	d0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    96a0:	f9413ff6 	ldr	x22, [sp, #632]
    96a4:	aa1403e0 	mov	x0, x20
    96a8:	f94143f7 	ldr	x23, [sp, #640]
    96ac:	91378021 	add	x1, x1, #0xde0
    96b0:	f94147f8 	ldr	x24, [sp, #648]
    96b4:	d2800042 	mov	x2, #0x2                   	// #2
    96b8:	17fffd0e 	b	8af0 <fwp_write+0x210>
    96bc:	d0000001 	adrp	x1, b000 <fwp_main_thread+0x1730>
    96c0:	d2800042 	mov	x2, #0x2                   	// #2
    96c4:	91346021 	add	x1, x1, #0xd18
    96c8:	17fffea3 	b	9154 <fwp_write+0x874>
    96cc:	f9400a63 	ldr	x3, [x19, #16]
    96d0:	8b030021 	add	x1, x1, x3
    96d4:	17ffff66 	b	946c <fwp_write+0xb8c>
    96d8:	f9400a61 	ldr	x1, [x19, #16]
    96dc:	8b0102a1 	add	x1, x21, x1
    96e0:	17fffdb3 	b	8dac <fwp_write+0x4cc>
    96e4:	f9400a63 	ldr	x3, [x19, #16]
    96e8:	8b030021 	add	x1, x1, x3
    96ec:	17ffff56 	b	9444 <fwp_write+0xb64>
    96f0:	b9404840 	ldr	w0, [x2, #72]
    96f4:	91001ff5 	add	x21, sp, #0x7
    96f8:	34ffa360 	cbz	w0, 8b64 <fwp_write+0x284>
    96fc:	52800503 	mov	w3, #0x28                  	// #40
    9700:	aa1403e0 	mov	x0, x20
    9704:	aa1503e1 	mov	x1, x21
    9708:	d2800022 	mov	x2, #0x1                   	// #1
    970c:	39001fe3 	strb	w3, [sp, #7]
    9710:	97ffe720 	bl	3390 <buf_put>
    9714:	b9401380 	ldr	w0, [x28, #16]
    9718:	52800038 	mov	w24, #0x1                   	// #1
    971c:	7100001f 	cmp	w0, #0x0
    9720:	54ffa36c 	b.gt	8b8c <fwp_write+0x2ac>
    9724:	17fffd32 	b	8bec <fwp_write+0x30c>
    9728:	f9014bf9 	str	x25, [sp, #656]
    972c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10758>
    9730:	f9014ffa 	str	x26, [sp, #664]
    9734:	f9400676 	ldr	x22, [x19, #8]
    9738:	91102333 	add	x19, x25, #0x408
    973c:	91002273 	add	x19, x19, #0x8
    9740:	937ffed8 	asr	x24, x22, #63
    9744:	aa1802c0 	orr	x0, x22, x24
    9748:	b5000320 	cbnz	x0, 97ac <fwp_write+0xecc>
    974c:	110006b5 	add	w21, w21, #0x1
    9750:	710016bf 	cmp	w21, #0x5
    9754:	54ffffc1 	b.ne	974c <fwp_write+0xe6c>  // b.any
    9758:	b7f80578 	tbnz	x24, #63, 9804 <fwp_write+0xf24>
    975c:	910023f3 	add	x19, sp, #0x8
    9760:	aa1603e2 	mov	x2, x22
    9764:	aa1303e0 	mov	x0, x19
    9768:	d2800003 	mov	x3, #0x0                   	// #0
    976c:	97ffe58d 	bl	2da0 <fwp_fmt_u128>
    9770:	910123f5 	add	x21, sp, #0x48
    9774:	d0000003 	adrp	x3, b000 <fwp_main_thread+0x1730>
    9778:	aa1303e4 	mov	x4, x19
    977c:	aa1503e0 	mov	x0, x21
    9780:	91376063 	add	x3, x3, #0xdd8
    9784:	d2804002 	mov	x2, #0x200                 	// #512
    9788:	52800041 	mov	w1, #0x2                   	// #2
    978c:	97ffe3c1 	bl	2690 <__sprintf_chk@plt>
    9790:	aa1503e0 	mov	x0, x21
    9794:	97ffe3bb 	bl	2680 <strlen@plt>
    9798:	aa1503e1 	mov	x1, x21
    979c:	aa0003e2 	mov	x2, x0
    97a0:	aa1403e0 	mov	x0, x20
    97a4:	97ffe6fb 	bl	3390 <buf_put>
    97a8:	17fffe47 	b	90c4 <fwp_write+0x7e4>
    97ac:	f9400277 	ldr	x23, [x19]
    97b0:	aa1603e0 	mov	x0, x22
    97b4:	aa1803e1 	mov	x1, x24
    97b8:	aa1703e2 	mov	x2, x23
    97bc:	937ffefa 	asr	x26, x23, #63
    97c0:	aa1a03e3 	mov	x3, x26
    97c4:	9400073b 	bl	b4b0 <__modti3>
    97c8:	aa010000 	orr	x0, x0, x1
    97cc:	b40002c0 	cbz	x0, 9824 <fwp_write+0xf44>
    97d0:	110006b5 	add	w21, w21, #0x1
    97d4:	91004273 	add	x19, x19, #0x10
    97d8:	710016bf 	cmp	w21, #0x5
    97dc:	54fffe81 	b.ne	97ac <fwp_write+0xecc>  // b.any
    97e0:	17ffffde 	b	9758 <fwp_write+0xe78>
    97e4:	f9400a60 	ldr	x0, [x19, #16]
    97e8:	8b000021 	add	x1, x1, x0
    97ec:	17fffd75 	b	8dc0 <fwp_write+0x4e0>
    97f0:	528c29c0 	mov	w0, #0x614e                	// #24910
    97f4:	910123f5 	add	x21, sp, #0x48
    97f8:	72a009c0 	movk	w0, #0x4e, lsl #16
    97fc:	b9004be0 	str	w0, [sp, #72]
    9800:	17fffda2 	b	8e88 <fwp_write+0x5a8>
    9804:	528005a1 	mov	w1, #0x2d                  	// #45
    9808:	eb1603e2 	negs	x2, x22
    980c:	da1803e3 	ngc	x3, x24
    9810:	910027e0 	add	x0, sp, #0x9
    9814:	910023f3 	add	x19, sp, #0x8
    9818:	390023e1 	strb	w1, [sp, #8]
    981c:	97ffe561 	bl	2da0 <fwp_fmt_u128>
    9820:	17ffffd4 	b	9770 <fwp_write+0xe90>
    9824:	aa1703e2 	mov	x2, x23
    9828:	aa1a03e3 	mov	x3, x26
    982c:	aa1603e0 	mov	x0, x22
    9830:	aa1803e1 	mov	x1, x24
    9834:	9400063f 	bl	b130 <__divti3>
    9838:	aa0003e2 	mov	x2, x0
    983c:	aa0103e3 	mov	x3, x1
    9840:	b7f80201 	tbnz	x1, #63, 9880 <fwp_write+0xfa0>
    9844:	910023f3 	add	x19, sp, #0x8
    9848:	aa1303e0 	mov	x0, x19
    984c:	97ffe555 	bl	2da0 <fwp_fmt_u128>
    9850:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9854:	91102339 	add	x25, x25, #0x408
    9858:	910123f5 	add	x21, sp, #0x48
    985c:	aa1303e4 	mov	x4, x19
    9860:	aa1503e0 	mov	x0, x21
    9864:	d0000003 	adrp	x3, b000 <fwp_main_thread+0x1730>
    9868:	f8616b25 	ldr	x5, [x25, x1]
    986c:	91374063 	add	x3, x3, #0xdd0
    9870:	d2804002 	mov	x2, #0x200                 	// #512
    9874:	52800041 	mov	w1, #0x2                   	// #2
    9878:	97ffe386 	bl	2690 <__sprintf_chk@plt>
    987c:	17ffffc5 	b	9790 <fwp_write+0xeb0>
    9880:	528005a4 	mov	w4, #0x2d                  	// #45
    9884:	eb0003e2 	negs	x2, x0
    9888:	da0103e3 	ngc	x3, x1
    988c:	910027e0 	add	x0, sp, #0x9
    9890:	910023f3 	add	x19, sp, #0x8
    9894:	390023e4 	strb	w4, [sp, #8]
    9898:	97ffe542 	bl	2da0 <fwp_fmt_u128>
    989c:	17ffffed 	b	9850 <fwp_write+0xf70>
    98a0:	f9013bf5 	str	x21, [sp, #624]
    98a4:	f9013ff6 	str	x22, [sp, #632]
    98a8:	f90143f7 	str	x23, [sp, #640]
    98ac:	f90147f8 	str	x24, [sp, #648]
    98b0:	f9014bf9 	str	x25, [sp, #656]
    98b4:	f9014ffa 	str	x26, [sp, #664]
    98b8:	f90153fb 	str	x27, [sp, #672]
    98bc:	f90157fc 	str	x28, [sp, #680]
    98c0:	fd015be8 	str	d8, [sp, #688]
    98c4:	fd015fe9 	str	d9, [sp, #696]
    98c8:	97ffe3ca 	bl	27f0 <__stack_chk_fail@plt>
    98cc:	d503201f 	nop

00000000000098d0 <fwp_main_thread>:
    98d0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    98d4:	910003fd 	mov	x29, sp
    98d8:	a90573fb 	stp	x27, x28, [sp, #80]
    98dc:	9000015c 	adrp	x28, 31000 <fwp_root_context+0xc90>
    98e0:	91154381 	add	x1, x28, #0x550
    98e4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    98e8:	f947f400 	ldr	x0, [x0, #4072]
    98ec:	a90153f3 	stp	x19, x20, [sp, #16]
    98f0:	a9025bf5 	stp	x21, x22, [sp, #32]
    98f4:	a90363f7 	stp	x23, x24, [sp, #48]
    98f8:	a9046bf9 	stp	x25, x26, [sp, #64]
    98fc:	fd0033e8 	str	d8, [sp, #96]
    9900:	d10603ff 	sub	sp, sp, #0x180
    9904:	b953a421 	ldr	w1, [x1, #5028]
    9908:	f9400002 	ldr	x2, [x0]
    990c:	f81f83a2 	stur	x2, [x29, #-8]
    9910:	d2800002 	mov	x2, #0x0                   	// #0
    9914:	34000de1 	cbz	w1, 9ad0 <fwp_main_thread+0x200>
    9918:	91154380 	add	x0, x28, #0x550
    991c:	b953a800 	ldr	w0, [x0, #5032]
    9920:	35000d00 	cbnz	w0, 9ac0 <fwp_main_thread+0x1f0>
    9924:	f00000a0 	adrp	x0, 20000 <__data_start>
    9928:	f00000a2 	adrp	x2, 20000 <__data_start>
    992c:	91010014 	add	x20, x0, #0x40
    9930:	910dc042 	add	x2, x2, #0x370
    9934:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    9938:	d2a00024 	mov	x4, #0x10000               	// #65536
    993c:	d10383b3 	sub	x19, x29, #0xe0
    9940:	d103e3b5 	sub	x21, x29, #0xf8
    9944:	aa1303e0 	mov	x0, x19
    9948:	d2800001 	mov	x1, #0x0                   	// #0
    994c:	f81203a2 	stur	x2, [x29, #-224]
    9950:	b81283bf 	stur	wzr, [x29, #-216]
    9954:	f81303a4 	stur	x4, [x29, #-208]
    9958:	a9018e95 	stp	x21, x3, [x20, #24]
    995c:	97ffe33d 	bl	2650 <sigaltstack@plt>
    9960:	35000220 	cbnz	w0, 99a4 <fwp_main_thread+0xd4>
    9964:	4f000400 	movi	v0.4s, #0x0
    9968:	d10263a0 	sub	x0, x29, #0x98
    996c:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9970:	913fc021 	add	x1, x1, #0xff0
    9974:	f81603a1 	stur	x1, [x29, #-160]
    9978:	52800082 	mov	w2, #0x4                   	// #4
    997c:	72a10002 	movk	w2, #0x800, lsl #16
    9980:	d10283b7 	sub	x23, x29, #0xa0
    9984:	3d802000 	str	q0, [x0, #128]
    9988:	b81e83a2 	stur	w2, [x29, #-24]
    998c:	ad000000 	stp	q0, q0, [x0]
    9990:	ad010000 	stp	q0, q0, [x0, #32]
    9994:	ad020000 	stp	q0, q0, [x0, #64]
    9998:	ad030000 	stp	q0, q0, [x0, #96]
    999c:	97ffe385 	bl	27b0 <sigemptyset@plt>
    99a0:	34000080 	cbz	w0, 99b0 <fwp_main_thread+0xe0>
    99a4:	d0000000 	adrp	x0, b000 <fwp_main_thread+0x1730>
    99a8:	9137c000 	add	x0, x0, #0xdf0
    99ac:	97ffe919 	bl	3e10 <fwp_trap>
    99b0:	aa1703e1 	mov	x1, x23
    99b4:	d2800002 	mov	x2, #0x0                   	// #0
    99b8:	52800160 	mov	w0, #0xb                   	// #11
    99bc:	97ffe395 	bl	2810 <sigaction@plt>
    99c0:	35ffff20 	cbnz	w0, 99a4 <fwp_main_thread+0xd4>
    99c4:	aa1703e1 	mov	x1, x23
    99c8:	d2800002 	mov	x2, #0x0                   	// #0
    99cc:	528000e0 	mov	w0, #0x7                   	// #7
    99d0:	97ffe390 	bl	2810 <sigaction@plt>
    99d4:	35fffe80 	cbnz	w0, 99a4 <fwp_main_thread+0xd4>
    99d8:	b942fa80 	ldr	w0, [x20, #760]
    99dc:	340007e0 	cbz	w0, 9ad8 <fwp_main_thread+0x208>
    99e0:	f00000a0 	adrp	x0, 20000 <__data_start>
    99e4:	91010015 	add	x21, x0, #0x40
    99e8:	f9400ab4 	ldr	x20, [x21, #16]
    99ec:	b4007f54 	cbz	x20, a9d4 <fwp_main_thread+0x1104>
    99f0:	91010296 	add	x22, x20, #0x40
    99f4:	39414a98 	ldrb	w24, [x20, #82]
    99f8:	52800037 	mov	w23, #0x1                   	// #1
    99fc:	39014a97 	strb	w23, [x20, #82]
    9a00:	f9401680 	ldr	x0, [x20, #40]
    9a04:	b4007e60 	cbz	x0, a9d0 <fwp_main_thread+0x1100>
    9a08:	f9403281 	ldr	x1, [x20, #96]
    9a0c:	39414680 	ldrb	w0, [x20, #81]
    9a10:	b40044e1 	cbz	x1, a2ac <fwp_main_thread+0x9dc>
    9a14:	360043a0 	tbz	w0, #0, a288 <fwp_main_thread+0x9b8>
    9a18:	f9400ab3 	ldr	x19, [x21, #16]
    9a1c:	f9402280 	ldr	x0, [x20, #64]
    9a20:	39414a61 	ldrb	w1, [x19, #82]
    9a24:	37007c61 	tbnz	w1, #0, a9b0 <fwp_main_thread+0x10e0>
    9a28:	f9403261 	ldr	x1, [x19, #96]
    9a2c:	a911fe76 	stp	x22, xzr, [x19, #280]
    9a30:	f9009660 	str	x0, [x19, #296]
    9a34:	b4000040 	cbz	x0, 9a3c <fwp_main_thread+0x16c>
    9a38:	f9009013 	str	x19, [x0, #288]
    9a3c:	f9002293 	str	x19, [x20, #64]
    9a40:	b4000101 	cbz	x1, 9a60 <fwp_main_thread+0x190>
    9a44:	f94046a0 	ldr	x0, [x21, #136]
    9a48:	39015677 	strb	w23, [x19, #85]
    9a4c:	f9003661 	str	x1, [x19, #104]
    9a50:	a910827f 	stp	xzr, x0, [x19, #264]
    9a54:	b4000040 	cbz	x0, 9a5c <fwp_main_thread+0x18c>
    9a58:	f9008413 	str	x19, [x0, #264]
    9a5c:	f90046b3 	str	x19, [x21, #136]
    9a60:	39015a7f 	strb	wzr, [x19, #86]
    9a64:	97fff287 	bl	6480 <fwp_block>
    9a68:	f9408e62 	ldr	x2, [x19, #280]
    9a6c:	b4000142 	cbz	x2, 9a94 <fwp_main_thread+0x1c4>
    9a70:	a9520261 	ldp	x1, x0, [x19, #288]
    9a74:	b4007aa1 	cbz	x1, a9c8 <fwp_main_thread+0x10f8>
    9a78:	f9009420 	str	x0, [x1, #296]
    9a7c:	f9409660 	ldr	x0, [x19, #296]
    9a80:	b4000040 	cbz	x0, 9a88 <fwp_main_thread+0x1b8>
    9a84:	f9009001 	str	x1, [x0, #288]
    9a88:	91080260 	add	x0, x19, #0x200
    9a8c:	f900967f 	str	xzr, [x19, #296]
    9a90:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9a94:	39415660 	ldrb	w0, [x19, #85]
    9a98:	3607fb40 	tbz	w0, #0, 9a00 <fwp_main_thread+0x130>
    9a9c:	a9508261 	ldp	x1, x0, [x19, #264]
    9aa0:	b4008ea1 	cbz	x1, ac74 <fwp_main_thread+0x13a4>
    9aa4:	f9008820 	str	x0, [x1, #272]
    9aa8:	b4000040 	cbz	x0, 9ab0 <fwp_main_thread+0x1e0>
    9aac:	f9008401 	str	x1, [x0, #264]
    9ab0:	91080260 	add	x0, x19, #0x200
    9ab4:	3901567f 	strb	wzr, [x19, #85]
    9ab8:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9abc:	17ffffd1 	b	9a00 <fwp_main_thread+0x130>
    9ac0:	d0ffffc0 	adrp	x0, 3000 <fwp_segv+0x10>
    9ac4:	91241000 	add	x0, x0, #0x904
    9ac8:	94000756 	bl	b820 <atexit>
    9acc:	17ffff96 	b	9924 <fwp_main_thread+0x54>
    9ad0:	97ffe7e8 	bl	3a70 <fwp_heap_init>
    9ad4:	17ffff91 	b	9918 <fwp_main_thread+0x48>
    9ad8:	f0000000 	adrp	x0, c000 <_IO_stdin_used+0x7b0>
    9adc:	d2800019 	mov	x25, #0x0                   	// #0
    9ae0:	f9416282 	ldr	x2, [x20, #704]
    9ae4:	91154396 	add	x22, x28, #0x550
    9ae8:	fd427808 	ldr	d8, [x0, #1264]
    9aec:	90ffffe0 	adrp	x0, 5000 <fwp_tape_reserve+0xdc>
    9af0:	91270000 	add	x0, x0, #0x9c0
    9af4:	a93303bf 	stp	xzr, x0, [x29, #-208]
    9af8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9afc:	a931ffb3 	stp	x19, xzr, [x29, #-232]
    9b00:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9b04:	d280401a 	mov	x26, #0x200                 	// #512
    9b08:	f91f7413 	str	x19, [x0, #16104]
    9b0c:	aa1903f3 	mov	x19, x25
    9b10:	913b4021 	add	x1, x1, #0xed0
    9b14:	52800038 	mov	w24, #0x1                   	// #1
    9b18:	a93087a2 	stp	x2, x1, [x29, #-248]
    9b1c:	f9016295 	str	x21, [x20, #704]
    9b20:	f91f7017 	str	x23, [x0, #16096]
    9b24:	f91f7815 	str	x21, [x0, #16112]
    9b28:	b953a6c0 	ldr	w0, [x22, #5028]
    9b2c:	f100075b 	subs	x27, x26, #0x1
    9b30:	f81283bb 	stur	x27, [x29, #-216]
    9b34:	da1f0275 	sbc	x21, x19, xzr
    9b38:	aa1b03fa 	mov	x26, x27
    9b3c:	aa1503f3 	mov	x19, x21
    9b40:	34007200 	cbz	w0, a980 <fwp_main_thread+0x10b0>
    9b44:	397e8ac0 	ldrb	w0, [x22, #4002]
    9b48:	910f0001 	add	x1, x0, #0x3c0
    9b4c:	8b000400 	add	x0, x0, x0, lsl #1
    9b50:	b8617ad7 	ldr	w23, [x22, x1, lsl #2]
    9b54:	8b000ec1 	add	x1, x22, x0, lsl #3
    9b58:	f8607ad4 	ldr	x20, [x22, x0, lsl #3]
    9b5c:	2a1703e5 	mov	w5, w23
    9b60:	b4005d34 	cbz	x20, a704 <fwp_main_thread+0xe34>
    9b64:	f9400281 	ldr	x1, [x20]
    9b68:	aa2103e1 	mvn	x1, x1
    9b6c:	f8207ac1 	str	x1, [x22, x0, lsl #3]
    9b70:	f10060bf 	cmp	x5, #0x18
    9b74:	54000169 	b.ls	9ba0 <fwp_main_thread+0x2d0>  // b.plast
    9b78:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9b7c:	d10064a2 	sub	x2, x5, #0x19
    9b80:	927df042 	and	x2, x2, #0xfffffffffffffff8
    9b84:	52800001 	mov	w1, #0x0                   	// #0
    9b88:	91002042 	add	x2, x2, #0x8
    9b8c:	f91f7c05 	str	x5, [x0, #16120]
    9b90:	91006280 	add	x0, x20, #0x18
    9b94:	97ffe30b 	bl	27c0 <memset@plt>
    9b98:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9b9c:	f95f7c05 	ldr	x5, [x0, #16120]
    9ba0:	f94a12c0 	ldr	x0, [x22, #5152]
    9ba4:	ab050000 	adds	x0, x0, x5
    9ba8:	5400a1e2 	b.cs	afe4 <fwp_main_thread+0x1714>  // b.hs, b.nlast
    9bac:	f94a16c1 	ldr	x1, [x22, #5160]
    9bb0:	f90a12c0 	str	x0, [x22, #5152]
    9bb4:	eb01001f 	cmp	x0, x1
    9bb8:	54000049 	b.ls	9bc0 <fwp_main_thread+0x2f0>  // b.plast
    9bbc:	f90a16c0 	str	x0, [x22, #5160]
    9bc0:	1e6302e1 	ucvtf	d1, w23
    9bc4:	fd4a1ec0 	ldr	d0, [x22, #5176]
    9bc8:	1e612800 	fadd	d0, d0, d1
    9bcc:	fd0a1ec0 	str	d0, [x22, #5176]
    9bd0:	a900e69b 	stp	x27, x25, [x20, #8]
    9bd4:	aa1403f9 	mov	x25, x20
    9bd8:	fd000288 	str	d8, [x20]
    9bdc:	f949dac1 	ldr	x1, [x22, #5040]
    9be0:	f949eec0 	ldr	x0, [x22, #5080]
    9be4:	cb010281 	sub	x1, x20, x1
    9be8:	eb00403f 	cmp	x1, x0, lsl #16
    9bec:	54000302 	b.cs	9c4c <fwp_main_thread+0x37c>  // b.hs, b.nlast
    9bf0:	d350fc20 	lsr	x0, x1, #16
    9bf4:	f949fec6 	ldr	x6, [x22, #5112]
    9bf8:	8b000800 	add	x0, x0, x0, lsl #2
    9bfc:	d37df002 	lsl	x2, x0, #3
    9c00:	8b0200c5 	add	x5, x6, x2
    9c04:	f94010a0 	ldr	x0, [x5, #32]
    9c08:	b4000220 	cbz	x0, 9c4c <fwp_main_thread+0x37c>
    9c0c:	386268c2 	ldrb	w2, [x6, x2]
    9c10:	7100085f 	cmp	w2, #0x2
    9c14:	54008080 	b.eq	ac24 <fwp_main_thread+0x1354>  // b.none
    9c18:	7100045f 	cmp	w2, #0x1
    9c1c:	54000181 	b.ne	9c4c <fwp_main_thread+0x37c>  // b.any
    9c20:	294308a6 	ldp	w6, w2, [x5, #24]
    9c24:	92403c21 	and	x1, x1, #0xffff
    9c28:	9b067c21 	mul	x1, x1, x6
    9c2c:	d360fc21 	lsr	x1, x1, #32
    9c30:	eb02003f 	cmp	x1, x2
    9c34:	540000c2 	b.cs	9c4c <fwp_main_thread+0x37c>  // b.hs, b.nlast
    9c38:	8b010000 	add	x0, x0, x1
    9c3c:	39400001 	ldrb	w1, [x0]
    9c40:	7103fc3f 	cmp	w1, #0xff
    9c44:	54003120 	b.eq	a268 <fwp_main_thread+0x998>  // b.none
    9c48:	39000018 	strb	w24, [x0]
    9c4c:	a9327fb4 	stp	x20, xzr, [x29, #-224]
    9c50:	aa15037b 	orr	x27, x27, x21
    9c54:	b5fff6bb 	cbnz	x27, 9b28 <fwp_main_thread+0x258>
    9c58:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9c5c:	f81203bf 	stur	xzr, [x29, #-224]
    9c60:	f95f7017 	ldr	x23, [x0, #16096]
    9c64:	f95f7413 	ldr	x19, [x0, #16104]
    9c68:	f95f7815 	ldr	x21, [x0, #16112]
    9c6c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9c70:	91010002 	add	x2, x0, #0x40
    9c74:	f9416040 	ldr	x0, [x2, #704]
    9c78:	eb15001f 	cmp	x0, x21
    9c7c:	5400a581 	b.ne	b12c <fwp_main_thread+0x185c>  // b.any
    9c80:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9c84:	d10303a1 	sub	x1, x29, #0xc0
    9c88:	f85083a3 	ldur	x3, [x29, #-248]
    9c8c:	f9016043 	str	x3, [x2, #704]
    9c90:	f91f7c14 	str	x20, [x0, #16120]
    9c94:	f0000000 	adrp	x0, c000 <_IO_stdin_used+0x7b0>
    9c98:	3dc14400 	ldr	q0, [x0, #1296]
    9c9c:	52800020 	mov	w0, #0x1                   	// #1
    9ca0:	3c9403a0 	stur	q0, [x29, #-192]
    9ca4:	97ffee93 	bl	56f0 <fwp_data.part.0.constprop.0>
    9ca8:	91154383 	add	x3, x28, #0x550
    9cac:	aa0003f5 	mov	x21, x0
    9cb0:	f949d861 	ldr	x1, [x3, #5040]
    9cb4:	f949ec60 	ldr	x0, [x3, #5080]
    9cb8:	cb0102a1 	sub	x1, x21, x1
    9cbc:	eb00403f 	cmp	x1, x0, lsl #16
    9cc0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9cc4:	f95f7c07 	ldr	x7, [x0, #16120]
    9cc8:	54000322 	b.cs	9d2c <fwp_main_thread+0x45c>  // b.hs, b.nlast
    9ccc:	d350fc22 	lsr	x2, x1, #16
    9cd0:	f949fc63 	ldr	x3, [x3, #5112]
    9cd4:	8b020842 	add	x2, x2, x2, lsl #2
    9cd8:	d37df042 	lsl	x2, x2, #3
    9cdc:	8b020060 	add	x0, x3, x2
    9ce0:	f9401014 	ldr	x20, [x0, #32]
    9ce4:	b4000254 	cbz	x20, 9d2c <fwp_main_thread+0x45c>
    9ce8:	38626862 	ldrb	w2, [x3, x2]
    9cec:	7100085f 	cmp	w2, #0x2
    9cf0:	54008200 	b.eq	ad30 <fwp_main_thread+0x1460>  // b.none
    9cf4:	7100045f 	cmp	w2, #0x1
    9cf8:	540001a1 	b.ne	9d2c <fwp_main_thread+0x45c>  // b.any
    9cfc:	29430002 	ldp	w2, w0, [x0, #24]
    9d00:	92403c21 	and	x1, x1, #0xffff
    9d04:	9b027c21 	mul	x1, x1, x2
    9d08:	d360fc21 	lsr	x1, x1, #32
    9d0c:	eb00003f 	cmp	x1, x0
    9d10:	540000e2 	b.cs	9d2c <fwp_main_thread+0x45c>  // b.hs, b.nlast
    9d14:	8b010294 	add	x20, x20, x1
    9d18:	39400280 	ldrb	w0, [x20]
    9d1c:	7103fc1f 	cmp	w0, #0xff
    9d20:	54008600 	b.eq	ade0 <fwp_main_thread+0x1510>  // b.none
    9d24:	52800020 	mov	w0, #0x1                   	// #1
    9d28:	39000280 	strb	w0, [x20]
    9d2c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d30:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    9d34:	aa1703e1 	mov	x1, x23
    9d38:	a93657a2 	stp	x2, x21, [x29, #-160]
    9d3c:	f91f7c07 	str	x7, [x0, #16120]
    9d40:	52800020 	mov	w0, #0x1                   	// #1
    9d44:	97ffee6b 	bl	56f0 <fwp_data.part.0.constprop.0>
    9d48:	aa0003f4 	mov	x20, x0
    9d4c:	91154383 	add	x3, x28, #0x550
    9d50:	f949d861 	ldr	x1, [x3, #5040]
    9d54:	f949ec60 	ldr	x0, [x3, #5080]
    9d58:	cb010281 	sub	x1, x20, x1
    9d5c:	eb00403f 	cmp	x1, x0, lsl #16
    9d60:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9d64:	f95f7c07 	ldr	x7, [x0, #16120]
    9d68:	54000322 	b.cs	9dcc <fwp_main_thread+0x4fc>  // b.hs, b.nlast
    9d6c:	d350fc22 	lsr	x2, x1, #16
    9d70:	f949fc63 	ldr	x3, [x3, #5112]
    9d74:	8b020842 	add	x2, x2, x2, lsl #2
    9d78:	d37df042 	lsl	x2, x2, #3
    9d7c:	8b020060 	add	x0, x3, x2
    9d80:	f9401015 	ldr	x21, [x0, #32]
    9d84:	b4000255 	cbz	x21, 9dcc <fwp_main_thread+0x4fc>
    9d88:	38626862 	ldrb	w2, [x3, x2]
    9d8c:	7100085f 	cmp	w2, #0x2
    9d90:	54007d60 	b.eq	ad3c <fwp_main_thread+0x146c>  // b.none
    9d94:	7100045f 	cmp	w2, #0x1
    9d98:	540001a1 	b.ne	9dcc <fwp_main_thread+0x4fc>  // b.any
    9d9c:	29430002 	ldp	w2, w0, [x0, #24]
    9da0:	92403c21 	and	x1, x1, #0xffff
    9da4:	9b027c21 	mul	x1, x1, x2
    9da8:	d360fc21 	lsr	x1, x1, #32
    9dac:	eb00003f 	cmp	x1, x0
    9db0:	540000e2 	b.cs	9dcc <fwp_main_thread+0x4fc>  // b.hs, b.nlast
    9db4:	8b0102b5 	add	x21, x21, x1
    9db8:	394002a0 	ldrb	w0, [x21]
    9dbc:	7103fc1f 	cmp	w0, #0xff
    9dc0:	540081e0 	b.eq	adfc <fwp_main_thread+0x152c>  // b.none
    9dc4:	52800020 	mov	w0, #0x1                   	// #1
    9dc8:	390002a0 	strb	w0, [x21]
    9dcc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9dd0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    9dd4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    9dd8:	d102c3a1 	sub	x1, x29, #0xb0
    9ddc:	a93553a2 	stp	x2, x20, [x29, #-176]
    9de0:	f91f7c07 	str	x7, [x0, #16120]
    9de4:	52800020 	mov	w0, #0x1                   	// #1
    9de8:	97ffee42 	bl	56f0 <fwp_data.part.0.constprop.0>
    9dec:	aa0003e9 	mov	x9, x0
    9df0:	91154382 	add	x2, x28, #0x550
    9df4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9df8:	f949ec43 	ldr	x3, [x2, #5080]
    9dfc:	f949d841 	ldr	x1, [x2, #5040]
    9e00:	d370bc63 	lsl	x3, x3, #16
    9e04:	cb010121 	sub	x1, x9, x1
    9e08:	f95f7c07 	ldr	x7, [x0, #16120]
    9e0c:	eb03003f 	cmp	x1, x3
    9e10:	540003c2 	b.cs	9e88 <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    9e14:	d350fc20 	lsr	x0, x1, #16
    9e18:	f949fc45 	ldr	x5, [x2, #5112]
    9e1c:	8b000800 	add	x0, x0, x0, lsl #2
    9e20:	d37df002 	lsl	x2, x0, #3
    9e24:	8b0200a4 	add	x4, x5, x2
    9e28:	f9401094 	ldr	x20, [x4, #32]
    9e2c:	b40002f4 	cbz	x20, 9e88 <fwp_main_thread+0x5b8>
    9e30:	386268a0 	ldrb	w0, [x5, x2]
    9e34:	7100081f 	cmp	w0, #0x2
    9e38:	54007760 	b.eq	ad24 <fwp_main_thread+0x1454>  // b.none
    9e3c:	7100041f 	cmp	w0, #0x1
    9e40:	54000241 	b.ne	9e88 <fwp_main_thread+0x5b8>  // b.any
    9e44:	29430885 	ldp	w5, w2, [x4, #24]
    9e48:	92403c20 	and	x0, x1, #0xffff
    9e4c:	9b057c00 	mul	x0, x0, x5
    9e50:	d360fc00 	lsr	x0, x0, #32
    9e54:	eb02001f 	cmp	x0, x2
    9e58:	54000182 	b.cs	9e88 <fwp_main_thread+0x5b8>  // b.hs, b.nlast
    9e5c:	8b000294 	add	x20, x20, x0
    9e60:	39400280 	ldrb	w0, [x20]
    9e64:	7103fc1f 	cmp	w0, #0xff
    9e68:	54007aa0 	b.eq	adbc <fwp_main_thread+0x14ec>  // b.none
    9e6c:	91154380 	add	x0, x28, #0x550
    9e70:	52800021 	mov	w1, #0x1                   	// #1
    9e74:	39000281 	strb	w1, [x20]
    9e78:	f949ec03 	ldr	x3, [x0, #5080]
    9e7c:	f949d801 	ldr	x1, [x0, #5040]
    9e80:	d370bc63 	lsl	x3, x3, #16
    9e84:	cb010121 	sub	x1, x9, x1
    9e88:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e8c:	91010015 	add	x21, x0, #0x40
    9e90:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9e94:	f00000a6 	adrp	x6, 20000 <__data_start>
    9e98:	91154397 	add	x23, x28, #0x550
    9e9c:	910040c5 	add	x5, x6, #0x10
    9ea0:	910020a5 	add	x5, x5, #0x8
    9ea4:	d10403b4 	sub	x20, x29, #0x100
    9ea8:	aa1703f8 	mov	x24, x23
    9eac:	f91f4806 	str	x6, [x0, #16016]
    9eb0:	f91f4c07 	str	x7, [x0, #16024]
    9eb4:	f91f5007 	str	x7, [x0, #16032]
    9eb8:	f91f5413 	str	x19, [x0, #16040]
    9ebc:	f91f5809 	str	x9, [x0, #16048]
    9ec0:	eb03003f 	cmp	x1, x3
    9ec4:	54000362 	b.cs	9f30 <fwp_main_thread+0x660>  // b.hs, b.nlast
    9ec8:	91154382 	add	x2, x28, #0x550
    9ecc:	d350fc20 	lsr	x0, x1, #16
    9ed0:	8b000800 	add	x0, x0, x0, lsl #2
    9ed4:	f949fc44 	ldr	x4, [x2, #5112]
    9ed8:	d37df002 	lsl	x2, x0, #3
    9edc:	8b020083 	add	x3, x4, x2
    9ee0:	f9401060 	ldr	x0, [x3, #32]
    9ee4:	b4000260 	cbz	x0, 9f30 <fwp_main_thread+0x660>
    9ee8:	38626882 	ldrb	w2, [x4, x2]
    9eec:	7100085f 	cmp	w2, #0x2
    9ef0:	540072c0 	b.eq	ad48 <fwp_main_thread+0x1478>  // b.none
    9ef4:	7100045f 	cmp	w2, #0x1
    9ef8:	540001c1 	b.ne	9f30 <fwp_main_thread+0x660>  // b.any
    9efc:	29430864 	ldp	w4, w2, [x3, #24]
    9f00:	92403c21 	and	x1, x1, #0xffff
    9f04:	9b047c21 	mul	x1, x1, x4
    9f08:	d360fc21 	lsr	x1, x1, #32
    9f0c:	eb02003f 	cmp	x1, x2
    9f10:	54000102 	b.cs	9f30 <fwp_main_thread+0x660>  // b.hs, b.nlast
    9f14:	8b010000 	add	x0, x0, x1
    9f18:	39400001 	ldrb	w1, [x0]
    9f1c:	340000a1 	cbz	w1, 9f30 <fwp_main_thread+0x660>
    9f20:	7103f43f 	cmp	w1, #0xfd
    9f24:	54007948 	b.hi	ae4c <fwp_main_thread+0x157c>  // b.pmore
    9f28:	11000421 	add	w1, w1, #0x1
    9f2c:	39000001 	strb	w1, [x0]
    9f30:	b94000a2 	ldr	w2, [x5]
    9f34:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    9f38:	f9403ea3 	ldr	x3, [x21, #120]
    9f3c:	aa0503fb 	mov	x27, x5
    9f40:	d37be842 	lsl	x2, x2, #5
    9f44:	8b020064 	add	x4, x3, x2
    9f48:	f95f5800 	ldr	x0, [x0, #16048]
    9f4c:	f81003a0 	stur	x0, [x29, #-256]
    9f50:	f9400c81 	ldr	x1, [x4, #24]
    9f54:	b4007921 	cbz	x1, ae78 <fwp_main_thread+0x15a8>
    9f58:	f9400c20 	ldr	x0, [x1, #24]
    9f5c:	b40066a0 	cbz	x0, ac30 <fwp_main_thread+0x1360>
    9f60:	f949db01 	ldr	x1, [x24, #5040]
    9f64:	f949ef00 	ldr	x0, [x24, #5080]
    9f68:	cb0100a1 	sub	x1, x5, x1
    9f6c:	eb00403f 	cmp	x1, x0, lsl #16
    9f70:	54000342 	b.cs	9fd8 <fwp_main_thread+0x708>  // b.hs, b.nlast
    9f74:	d350fc20 	lsr	x0, x1, #16
    9f78:	f949ff06 	ldr	x6, [x24, #5112]
    9f7c:	8b000800 	add	x0, x0, x0, lsl #2
    9f80:	d37df002 	lsl	x2, x0, #3
    9f84:	8b0200c3 	add	x3, x6, x2
    9f88:	f9401060 	ldr	x0, [x3, #32]
    9f8c:	b4000260 	cbz	x0, 9fd8 <fwp_main_thread+0x708>
    9f90:	386268c2 	ldrb	w2, [x6, x2]
    9f94:	7100085f 	cmp	w2, #0x2
    9f98:	54006760 	b.eq	ac84 <fwp_main_thread+0x13b4>  // b.none
    9f9c:	7100045f 	cmp	w2, #0x1
    9fa0:	540001c1 	b.ne	9fd8 <fwp_main_thread+0x708>  // b.any
    9fa4:	29430866 	ldp	w6, w2, [x3, #24]
    9fa8:	92403c21 	and	x1, x1, #0xffff
    9fac:	9b067c21 	mul	x1, x1, x6
    9fb0:	d360fc21 	lsr	x1, x1, #32
    9fb4:	eb02003f 	cmp	x1, x2
    9fb8:	54000102 	b.cs	9fd8 <fwp_main_thread+0x708>  // b.hs, b.nlast
    9fbc:	8b010000 	add	x0, x0, x1
    9fc0:	39400001 	ldrb	w1, [x0]
    9fc4:	340000a1 	cbz	w1, 9fd8 <fwp_main_thread+0x708>
    9fc8:	7103f43f 	cmp	w1, #0xfd
    9fcc:	54006e88 	b.hi	ad9c <fwp_main_thread+0x14cc>  // b.pmore
    9fd0:	11000421 	add	w1, w1, #0x1
    9fd4:	39000001 	strb	w1, [x0]
    9fd8:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    9fdc:	aa0503e0 	mov	x0, x5
    9fe0:	aa1803e7 	mov	x7, x24
    9fe4:	52800036 	mov	w22, #0x1                   	// #1
    9fe8:	f91f5c25 	str	x5, [x1, #16056]
    9fec:	f91f6034 	str	x20, [x1, #16064]
    9ff0:	b93ee036 	str	w22, [x1, #16096]
    9ff4:	f91f7434 	str	x20, [x1, #16104]
    9ff8:	b9400401 	ldr	w1, [x0, #4]
    9ffc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a000:	b9400097 	ldr	w23, [x4]
    a004:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a008:	4b0102f7 	sub	w23, w23, w1
    a00c:	b97ee000 	ldr	w0, [x0, #16096]
    a010:	6b1602ff 	cmp	w23, w22
    a014:	1a9692e6 	csel	w6, w23, w22, ls	// ls = plast
    a018:	6b0000df 	cmp	w6, w0
    a01c:	1a8090c0 	csel	w0, w6, w0, ls	// ls = plast
    a020:	b93edc40 	str	w0, [x2, #16092]
    a024:	6b0000c2 	subs	w2, w6, w0
    a028:	540001c0 	b.eq	a060 <fwp_main_thread+0x790>  // b.none
    a02c:	d14013a3 	sub	x3, x29, #0x4, lsl #12
    a030:	0b000021 	add	w1, w1, w0
    a034:	f91f7867 	str	x7, [x3, #16112]
    a038:	b93ef866 	str	w6, [x3, #16120]
    a03c:	f9400c83 	ldr	x3, [x4, #24]
    a040:	d14013a4 	sub	x4, x29, #0x4, lsl #12
    a044:	f9400863 	ldr	x3, [x3, #16]
    a048:	f95f7484 	ldr	x4, [x4, #16104]
    a04c:	8b204c80 	add	x0, x4, w0, uxtw #3
    a050:	d63f0060 	blr	x3
    a054:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a058:	f95f7807 	ldr	x7, [x0, #16112]
    a05c:	b97ef806 	ldr	w6, [x0, #16120]
    a060:	f9403ea0 	ldr	x0, [x21, #120]
    a064:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a068:	b9400364 	ldr	w4, [x27]
    a06c:	aa1b03ea 	mov	x10, x27
    a070:	2a0603f4 	mov	w20, w6
    a074:	aa1b03f9 	mov	x25, x27
    a078:	f95f743a 	ldr	x26, [x1, #16104]
    a07c:	8b041404 	add	x4, x0, x4, lsl #5
    a080:	f9400c8b 	ldr	x11, [x4, #24]
    a084:	b400150b 	cbz	x11, a324 <fwp_main_thread+0xa54>
    a088:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a08c:	b93ec806 	str	w6, [x0, #16072]
    a090:	b93ed017 	str	w23, [x0, #16080]
    a094:	aa0403f7 	mov	x23, x4
    a098:	b93ed816 	str	w22, [x0, #16088]
    a09c:	aa1a03f6 	mov	x22, x26
    a0a0:	f91f7c07 	str	x7, [x0, #16120]
    a0a4:	14000012 	b	a0ec <fwp_main_thread+0x81c>
    a0a8:	f9400161 	ldr	x1, [x11]
    a0ac:	aa1603e0 	mov	x0, x22
    a0b0:	d63f0020 	blr	x1
    a0b4:	aa0003fa 	mov	x26, x0
    a0b8:	aa1b03e0 	mov	x0, x27
    a0bc:	97ffef01 	bl	5cc0 <fwp_closure_drop>
    a0c0:	6b13029f 	cmp	w20, w19
    a0c4:	54004680 	b.eq	a994 <fwp_main_thread+0x10c4>  // b.none
    a0c8:	f9403ea0 	ldr	x0, [x21, #120]
    a0cc:	8b334ed6 	add	x22, x22, w19, uxtw #3
    a0d0:	b9400344 	ldr	w4, [x26]
    a0d4:	4b190314 	sub	w20, w24, w25
    a0d8:	aa1a03ea 	mov	x10, x26
    a0dc:	8b041417 	add	x23, x0, x4, lsl #5
    a0e0:	f9400eeb 	ldr	x11, [x23, #24]
    a0e4:	b400112b 	cbz	x11, a308 <fwp_main_thread+0xa38>
    a0e8:	aa1a03fb 	mov	x27, x26
    a0ec:	b9400541 	ldr	w1, [x10, #4]
    a0f0:	b94002f9 	ldr	w25, [x23]
    a0f4:	0b010298 	add	w24, w20, w1
    a0f8:	6b18033f 	cmp	w25, w24
    a0fc:	54003168 	b.hi	a728 <fwp_main_thread+0xe58>  // b.pmore
    a100:	7100003f 	cmp	w1, #0x0
    a104:	4b010333 	sub	w19, w25, w1
    a108:	7a400b24 	ccmp	w25, #0x0, #0x4, eq	// eq = none
    a10c:	54fffce1 	b.ne	a0a8 <fwp_main_thread+0x7d8>  // b.any
    a110:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a114:	910003e0 	mov	x0, sp
    a118:	7100033f 	cmp	w25, #0x0
    a11c:	f91f7840 	str	x0, [x2, #16112]
    a120:	1a9f1720 	csinc	w0, w25, wzr, ne	// ne = any
    a124:	d37df000 	lsl	x0, x0, #3
    a128:	91003c00 	add	x0, x0, #0xf
    a12c:	92704c05 	and	x5, x0, #0xfffff0000
    a130:	927c7c00 	and	x0, x0, #0xffffffff0
    a134:	cb2563e5 	sub	x5, sp, x5
    a138:	eb2563ff 	cmp	sp, x5
    a13c:	540000a0 	b.eq	a150 <fwp_main_thread+0x880>  // b.none
    a140:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a144:	f90203ff 	str	xzr, [sp, #1024]
    a148:	eb2563ff 	cmp	sp, x5
    a14c:	54ffffa1 	b.ne	a140 <fwp_main_thread+0x870>  // b.any
    a150:	92403c00 	and	x0, x0, #0xffff
    a154:	cb2063ff 	sub	sp, sp, x0
    a158:	f90003ff 	str	xzr, [sp]
    a15c:	f110001f 	cmp	x0, #0x400
    a160:	54000043 	b.cc	a168 <fwp_main_thread+0x898>  // b.lo, b.ul, b.last
    a164:	f90203ff 	str	xzr, [sp, #1024]
    a168:	910043fa 	add	x26, sp, #0x10
    a16c:	d37d7c28 	ubfiz	x8, x1, #3, #32
    a170:	91002147 	add	x7, x10, #0x8
    a174:	d2800000 	mov	x0, #0x0                   	// #0
    a178:	340000e1 	cbz	w1, a194 <fwp_main_thread+0x8c4>
    a17c:	d503201f 	nop
    a180:	f86068e2 	ldr	x2, [x7, x0]
    a184:	f8206b42 	str	x2, [x26, x0]
    a188:	91002000 	add	x0, x0, #0x8
    a18c:	eb08001f 	cmp	x0, x8
    a190:	54ffff81 	b.ne	a180 <fwp_main_thread+0x8b0>  // b.any
    a194:	2a1303e8 	mov	w8, w19
    a198:	d2800000 	mov	x0, #0x0                   	// #0
    a19c:	340000f3 	cbz	w19, a1b8 <fwp_main_thread+0x8e8>
    a1a0:	0b000022 	add	w2, w1, w0
    a1a4:	f8607ac3 	ldr	x3, [x22, x0, lsl #3]
    a1a8:	91000400 	add	x0, x0, #0x1
    a1ac:	f8227b43 	str	x3, [x26, x2, lsl #3]
    a1b0:	eb08001f 	cmp	x0, x8
    a1b4:	54ffff61 	b.ne	a1a0 <fwp_main_thread+0x8d0>  // b.any
    a1b8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a1bc:	f95f7c01 	ldr	x1, [x0, #16120]
    a1c0:	f949d820 	ldr	x0, [x1, #5040]
    a1c4:	f949ec21 	ldr	x1, [x1, #5080]
    a1c8:	cb000360 	sub	x0, x27, x0
    a1cc:	eb01401f 	cmp	x0, x1, lsl #16
    a1d0:	54000322 	b.cs	a234 <fwp_main_thread+0x964>  // b.hs, b.nlast
    a1d4:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a1d8:	d350fc01 	lsr	x1, x0, #16
    a1dc:	8b010821 	add	x1, x1, x1, lsl #2
    a1e0:	f95f7c42 	ldr	x2, [x2, #16120]
    a1e4:	d37df021 	lsl	x1, x1, #3
    a1e8:	f949fc48 	ldr	x8, [x2, #5112]
    a1ec:	8b010107 	add	x7, x8, x1
    a1f0:	f94010e6 	ldr	x6, [x7, #32]
    a1f4:	b4000206 	cbz	x6, a234 <fwp_main_thread+0x964>
    a1f8:	38616901 	ldrb	w1, [x8, x1]
    a1fc:	7100083f 	cmp	w1, #0x2
    a200:	540007a0 	b.eq	a2f4 <fwp_main_thread+0xa24>  // b.none
    a204:	7100043f 	cmp	w1, #0x1
    a208:	54000161 	b.ne	a234 <fwp_main_thread+0x964>  // b.any
    a20c:	294304e8 	ldp	w8, w1, [x7, #24]
    a210:	92403c00 	and	x0, x0, #0xffff
    a214:	9b087c00 	mul	x0, x0, x8
    a218:	d360fc00 	lsr	x0, x0, #32
    a21c:	eb01001f 	cmp	x0, x1
    a220:	540000a2 	b.cs	a234 <fwp_main_thread+0x964>  // b.hs, b.nlast
    a224:	8b0000c6 	add	x6, x6, x0
    a228:	394000c0 	ldrb	w0, [x6]
    a22c:	7100041f 	cmp	w0, #0x1
    a230:	54000280 	b.eq	a280 <fwp_main_thread+0x9b0>  // b.none
    a234:	f9400566 	ldr	x6, [x11, #8]
    a238:	aa1b03e0 	mov	x0, x27
    a23c:	52800021 	mov	w1, #0x1                   	// #1
    a240:	d63f00c0 	blr	x6
    a244:	f9400ee1 	ldr	x1, [x23, #24]
    a248:	aa1a03e0 	mov	x0, x26
    a24c:	f9400021 	ldr	x1, [x1]
    a250:	d63f0020 	blr	x1
    a254:	aa0003fa 	mov	x26, x0
    a258:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a25c:	f95f7800 	ldr	x0, [x0, #16112]
    a260:	9100001f 	mov	sp, x0
    a264:	17ffff95 	b	a0b8 <fwp_main_thread+0x7e8>
    a268:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a26c:	f91f7c20 	str	x0, [x1, #16120]
    a270:	97ffe708 	bl	3e90 <fwp_rc_forget_slot.part.0>
    a274:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a278:	f95f7c00 	ldr	x0, [x0, #16120]
    a27c:	17fffe73 	b	9c48 <fwp_main_thread+0x378>
    a280:	b900055f 	str	wzr, [x10, #4]
    a284:	17fffff0 	b	a244 <fwp_main_thread+0x974>
    a288:	97ffe902 	bl	4690 <fwp_now_ns>
    a28c:	f9403281 	ldr	x1, [x20, #96]
    a290:	eb01001f 	cmp	x0, x1
    a294:	540000ab 	b.lt	a2a8 <fwp_main_thread+0x9d8>  // b.tstop
    a298:	39414280 	ldrb	w0, [x20, #80]
    a29c:	37000060 	tbnz	w0, #0, a2a8 <fwp_main_thread+0x9d8>
    a2a0:	aa1403e0 	mov	x0, x20
    a2a4:	97ffe453 	bl	33f0 <fwp_cancel_tree.part.0>
    a2a8:	39414680 	ldrb	w0, [x20, #81]
    a2ac:	f9400ab3 	ldr	x19, [x21, #16]
    a2b0:	39414a62 	ldrb	w2, [x19, #82]
    a2b4:	3707bb20 	tbnz	w0, #0, 9a18 <fwp_main_thread+0x148>
    a2b8:	f9403281 	ldr	x1, [x20, #96]
    a2bc:	37000222 	tbnz	w2, #0, a300 <fwp_main_thread+0xa30>
    a2c0:	f9403260 	ldr	x0, [x19, #96]
    a2c4:	b40001e0 	cbz	x0, a300 <fwp_main_thread+0xa30>
    a2c8:	b4000061 	cbz	x1, a2d4 <fwp_main_thread+0xa04>
    a2cc:	eb01001f 	cmp	x0, x1
    a2d0:	9a81d000 	csel	x0, x0, x1, le
    a2d4:	f9402281 	ldr	x1, [x20, #64]
    a2d8:	a911fe76 	stp	x22, xzr, [x19, #280]
    a2dc:	f9009661 	str	x1, [x19, #296]
    a2e0:	b4005121 	cbz	x1, ad04 <fwp_main_thread+0x1434>
    a2e4:	f9009033 	str	x19, [x1, #288]
    a2e8:	aa0003e1 	mov	x1, x0
    a2ec:	f9002293 	str	x19, [x20, #64]
    a2f0:	17fffdd5 	b	9a44 <fwp_main_thread+0x174>
    a2f4:	72003c1f 	tst	w0, #0xffff
    a2f8:	54fff9e1 	b.ne	a234 <fwp_main_thread+0x964>  // b.any
    a2fc:	17ffffcb 	b	a228 <fwp_main_thread+0x958>
    a300:	f9402280 	ldr	x0, [x20, #64]
    a304:	17fffdca 	b	9a2c <fwp_main_thread+0x15c>
    a308:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a30c:	aa1a03f9 	mov	x25, x26
    a310:	aa1603fa 	mov	x26, x22
    a314:	f95f7c07 	ldr	x7, [x0, #16120]
    a318:	b97ec806 	ldr	w6, [x0, #16072]
    a31c:	b97ed017 	ldr	w23, [x0, #16080]
    a320:	b97ed816 	ldr	w22, [x0, #16088]
    a324:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a328:	f91f7807 	str	x7, [x0, #16112]
    a32c:	b93ef806 	str	w6, [x0, #16120]
    a330:	aa1903e0 	mov	x0, x25
    a334:	97ffed37 	bl	5810 <fwp_rc_share>
    a338:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a33c:	f95f7807 	ldr	x7, [x0, #16112]
    a340:	b97ef806 	ldr	w6, [x0, #16120]
    a344:	340001f4 	cbz	w20, a380 <fwp_main_thread+0xab0>
    a348:	8b344f53 	add	x19, x26, w20, uxtw #3
    a34c:	2a0603fb 	mov	w27, w6
    a350:	aa0703f8 	mov	x24, x7
    a354:	b93ef814 	str	w20, [x0, #16120]
    a358:	aa1a03f4 	mov	x20, x26
    a35c:	d503201f 	nop
    a360:	f8408680 	ldr	x0, [x20], #8
    a364:	97ffed2b 	bl	5810 <fwp_rc_share>
    a368:	eb13029f 	cmp	x20, x19
    a36c:	54ffffa1 	b.ne	a360 <fwp_main_thread+0xa90>  // b.any
    a370:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a374:	2a1b03e6 	mov	w6, w27
    a378:	aa1803e7 	mov	x7, x24
    a37c:	b97ef814 	ldr	w20, [x0, #16120]
    a380:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a384:	aa1a03e2 	mov	x2, x26
    a388:	2a1403e1 	mov	w1, w20
    a38c:	f91f7807 	str	x7, [x0, #16112]
    a390:	b93ef806 	str	w6, [x0, #16120]
    a394:	aa1903e0 	mov	x0, x25
    a398:	97ffea5b 	bl	4d04 <fwp_apply>
    a39c:	aa0003fb 	mov	x27, x0
    a3a0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3a4:	f95f7807 	ldr	x7, [x0, #16112]
    a3a8:	b97ef806 	ldr	w6, [x0, #16120]
    a3ac:	6b1602ff 	cmp	w23, w22
    a3b0:	54004b02 	b.cs	ad10 <fwp_main_thread+0x1440>  // b.hs, b.nlast
    a3b4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3b8:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a3bc:	f9403ea1 	ldr	x1, [x21, #120]
    a3c0:	4b0602d6 	sub	w22, w22, w6
    a3c4:	f95f7400 	ldr	x0, [x0, #16104]
    a3c8:	b9400364 	ldr	w4, [x27]
    a3cc:	8b264c00 	add	x0, x0, w6, uxtw #3
    a3d0:	f91f7440 	str	x0, [x2, #16104]
    a3d4:	8b041424 	add	x4, x1, x4, lsl #5
    a3d8:	b97ee040 	ldr	w0, [x2, #16096]
    a3dc:	b97edc42 	ldr	w2, [x2, #16092]
    a3e0:	4b020000 	sub	w0, w0, w2
    a3e4:	d14013a2 	sub	x2, x29, #0x4, lsl #12
    a3e8:	f9400c81 	ldr	x1, [x4, #24]
    a3ec:	b93ee040 	str	w0, [x2, #16096]
    a3f0:	aa1b03e0 	mov	x0, x27
    a3f4:	b5ffe021 	cbnz	x1, 9ff8 <fwp_main_thread+0x728>
    a3f8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a3fc:	aa0703f8 	mov	x24, x7
    a400:	f95f5c05 	ldr	x5, [x0, #16056]
    a404:	f91f7c05 	str	x5, [x0, #16120]
    a408:	f95f6014 	ldr	x20, [x0, #16064]
    a40c:	aa1b03e0 	mov	x0, x27
    a410:	97ffed00 	bl	5810 <fwp_rc_share>
    a414:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a418:	f95f7c05 	ldr	x5, [x0, #16120]
    a41c:	34000176 	cbz	w22, a448 <fwp_main_thread+0xb78>
    a420:	f95f7419 	ldr	x25, [x0, #16104]
    a424:	aa0503fa 	mov	x26, x5
    a428:	d2800017 	mov	x23, #0x0                   	// #0
    a42c:	d503201f 	nop
    a430:	f8777b20 	ldr	x0, [x25, x23, lsl #3]
    a434:	910006f7 	add	x23, x23, #0x1
    a438:	97ffecf6 	bl	5810 <fwp_rc_share>
    a43c:	6b1702df 	cmp	w22, w23
    a440:	54ffff88 	b.hi	a430 <fwp_main_thread+0xb60>  // b.pmore
    a444:	aa1a03e5 	mov	x5, x26
    a448:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a44c:	2a1603e1 	mov	w1, w22
    a450:	f95f7402 	ldr	x2, [x0, #16104]
    a454:	f91f7c05 	str	x5, [x0, #16120]
    a458:	aa1b03e0 	mov	x0, x27
    a45c:	97ffea2a 	bl	4d04 <fwp_apply>
    a460:	aa0003fb 	mov	x27, x0
    a464:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a468:	f95f7c05 	ldr	x5, [x0, #16120]
    a46c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a470:	900000a2 	adrp	x2, 1e000 <__FRAME_END__+0x10758>
    a474:	91102042 	add	x2, x2, #0x408
    a478:	91014042 	add	x2, x2, #0x50
    a47c:	aa1b03e1 	mov	x1, x27
    a480:	f91f7c05 	str	x5, [x0, #16120]
    a484:	52800023 	mov	w3, #0x1                   	// #1
    a488:	f95f5400 	ldr	x0, [x0, #16040]
    a48c:	a9327fbf 	stp	xzr, xzr, [x29, #-224]
    a490:	f81303bf 	stur	xzr, [x29, #-208]
    a494:	97fff913 	bl	88e0 <fwp_write>
    a498:	a9726bb7 	ldp	x23, x26, [x29, #-224]
    a49c:	d0000000 	adrp	x0, c000 <_IO_stdin_used+0x7b0>
    a4a0:	91092000 	add	x0, x0, #0x248
    a4a4:	f10002ff 	cmp	x23, #0x0
    a4a8:	9a970017 	csel	x23, x0, x23, eq	// eq = none
    a4ac:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4b0:	b1002b5f 	cmn	x26, #0xa
    a4b4:	f95f7c05 	ldr	x5, [x0, #16120]
    a4b8:	54004fe8 	b.hi	aeb4 <fwp_main_thread+0x15e4>  // b.pmore
    a4bc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a4c0:	52800021 	mov	w1, #0x1                   	// #1
    a4c4:	f91f7c05 	str	x5, [x0, #16120]
    a4c8:	91002740 	add	x0, x26, #0x9
    a4cc:	97ffe9c9 	bl	4bf0 <fwp_heap_alloc>
    a4d0:	aa0003f9 	mov	x25, x0
    a4d4:	aa0003f6 	mov	x22, x0
    a4d8:	aa1a03e2 	mov	x2, x26
    a4dc:	aa1703e1 	mov	x1, x23
    a4e0:	f800873a 	str	x26, [x25], #8
    a4e4:	8b1a02da 	add	x26, x22, x26
    a4e8:	aa1903e0 	mov	x0, x25
    a4ec:	97ffe055 	bl	2640 <memcpy@plt>
    a4f0:	3900235f 	strb	wzr, [x26, #8]
    a4f4:	f85203a0 	ldur	x0, [x29, #-224]
    a4f8:	97ffe0ee 	bl	28b0 <free@plt>
    a4fc:	91154382 	add	x2, x28, #0x550
    a500:	f949d841 	ldr	x1, [x2, #5040]
    a504:	f949ec40 	ldr	x0, [x2, #5080]
    a508:	cb0102c1 	sub	x1, x22, x1
    a50c:	eb00403f 	cmp	x1, x0, lsl #16
    a510:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a514:	f95f7c05 	ldr	x5, [x0, #16120]
    a518:	54000322 	b.cs	a57c <fwp_main_thread+0xcac>  // b.hs, b.nlast
    a51c:	d350fc20 	lsr	x0, x1, #16
    a520:	d2800504 	mov	x4, #0x28                  	// #40
    a524:	f949fc43 	ldr	x3, [x2, #5112]
    a528:	9b047c00 	mul	x0, x0, x4
    a52c:	8b000062 	add	x2, x3, x0
    a530:	f9401057 	ldr	x23, [x2, #32]
    a534:	b4000257 	cbz	x23, a57c <fwp_main_thread+0xcac>
    a538:	38606860 	ldrb	w0, [x3, x0]
    a53c:	7100081f 	cmp	w0, #0x2
    a540:	54004b40 	b.eq	aea8 <fwp_main_thread+0x15d8>  // b.none
    a544:	7100041f 	cmp	w0, #0x1
    a548:	540001a1 	b.ne	a57c <fwp_main_thread+0xcac>  // b.any
    a54c:	29430043 	ldp	w3, w0, [x2, #24]
    a550:	92403c21 	and	x1, x1, #0xffff
    a554:	9b037c21 	mul	x1, x1, x3
    a558:	d360fc21 	lsr	x1, x1, #32
    a55c:	eb00003f 	cmp	x1, x0
    a560:	540000e2 	b.cs	a57c <fwp_main_thread+0xcac>  // b.hs, b.nlast
    a564:	8b0102f7 	add	x23, x23, x1
    a568:	394002e0 	ldrb	w0, [x23]
    a56c:	7103fc1f 	cmp	w0, #0xff
    a570:	54005880 	b.eq	b080 <fwp_main_thread+0x17b0>  // b.none
    a574:	52800020 	mov	w0, #0x1                   	// #1
    a578:	390002e0 	strb	w0, [x23]
    a57c:	aa1803f3 	mov	x19, x24
    a580:	9115439a 	add	x26, x28, #0x550
    a584:	aa0503f8 	mov	x24, x5
    a588:	f949db41 	ldr	x1, [x26, #5040]
    a58c:	f949ef40 	ldr	x0, [x26, #5080]
    a590:	cb010361 	sub	x1, x27, x1
    a594:	eb00403f 	cmp	x1, x0, lsl #16
    a598:	540046a2 	b.cs	ae6c <fwp_main_thread+0x159c>  // b.hs, b.nlast
    a59c:	d350fc22 	lsr	x2, x1, #16
    a5a0:	d2800500 	mov	x0, #0x28                  	// #40
    a5a4:	f949ff43 	ldr	x3, [x26, #5112]
    a5a8:	9b007c42 	mul	x2, x2, x0
    a5ac:	8b020060 	add	x0, x3, x2
    a5b0:	f9401017 	ldr	x23, [x0, #32]
    a5b4:	b40045d7 	cbz	x23, ae6c <fwp_main_thread+0x159c>
    a5b8:	38626862 	ldrb	w2, [x3, x2]
    a5bc:	7100085f 	cmp	w2, #0x2
    a5c0:	54004520 	b.eq	ae64 <fwp_main_thread+0x1594>  // b.none
    a5c4:	7100045f 	cmp	w2, #0x1
    a5c8:	54004521 	b.ne	ae6c <fwp_main_thread+0x159c>  // b.any
    a5cc:	29430002 	ldp	w2, w0, [x0, #24]
    a5d0:	92403c21 	and	x1, x1, #0xffff
    a5d4:	9b027c21 	mul	x1, x1, x2
    a5d8:	d360fc21 	lsr	x1, x1, #32
    a5dc:	eb00003f 	cmp	x1, x0
    a5e0:	54004462 	b.cs	ae6c <fwp_main_thread+0x159c>  // b.hs, b.nlast
    a5e4:	8b0102f7 	add	x23, x23, x1
    a5e8:	394002e0 	ldrb	w0, [x23]
    a5ec:	34004400 	cbz	w0, ae6c <fwp_main_thread+0x159c>
    a5f0:	7100041f 	cmp	w0, #0x1
    a5f4:	54004ce0 	b.eq	af90 <fwp_main_thread+0x16c0>  // b.none
    a5f8:	aa1803e5 	mov	x5, x24
    a5fc:	aa1303f8 	mov	x24, x19
    a600:	7103fc1f 	cmp	w0, #0xff
    a604:	54004d20 	b.eq	afa8 <fwp_main_thread+0x16d8>  // b.none
    a608:	51000400 	sub	w0, w0, #0x1
    a60c:	390002e0 	strb	w0, [x23]
    a610:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a614:	d2800021 	mov	x1, #0x1                   	// #1
    a618:	f94002c2 	ldr	x2, [x22]
    a61c:	f91f7c05 	str	x5, [x0, #16120]
    a620:	d00000a0 	adrp	x0, 20000 <__data_start>
    a624:	91010017 	add	x23, x0, #0x40
    a628:	aa1903e0 	mov	x0, x25
    a62c:	f94006e3 	ldr	x3, [x23, #8]
    a630:	97ffe0b0 	bl	28f0 <fwrite@plt>
    a634:	f94006e1 	ldr	x1, [x23, #8]
    a638:	52800140 	mov	w0, #0xa                   	// #10
    a63c:	97ffe035 	bl	2710 <fputc@plt>
    a640:	91154382 	add	x2, x28, #0x550
    a644:	f949d841 	ldr	x1, [x2, #5040]
    a648:	f949ec40 	ldr	x0, [x2, #5080]
    a64c:	cb0102c1 	sub	x1, x22, x1
    a650:	eb00403f 	cmp	x1, x0, lsl #16
    a654:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a658:	f95f7c05 	ldr	x5, [x0, #16120]
    a65c:	54000382 	b.cs	a6cc <fwp_main_thread+0xdfc>  // b.hs, b.nlast
    a660:	d350fc20 	lsr	x0, x1, #16
    a664:	d2800504 	mov	x4, #0x28                  	// #40
    a668:	f949fc43 	ldr	x3, [x2, #5112]
    a66c:	9b047c00 	mul	x0, x0, x4
    a670:	8b000062 	add	x2, x3, x0
    a674:	f9401057 	ldr	x23, [x2, #32]
    a678:	b40002b7 	cbz	x23, a6cc <fwp_main_thread+0xdfc>
    a67c:	38606863 	ldrb	w3, [x3, x0]
    a680:	7100087f 	cmp	w3, #0x2
    a684:	54004380 	b.eq	aef4 <fwp_main_thread+0x1624>  // b.none
    a688:	7100047f 	cmp	w3, #0x1
    a68c:	54000201 	b.ne	a6cc <fwp_main_thread+0xdfc>  // b.any
    a690:	29431040 	ldp	w0, w4, [x2, #24]
    a694:	92403c21 	and	x1, x1, #0xffff
    a698:	9b007c20 	mul	x0, x1, x0
    a69c:	d360fc00 	lsr	x0, x0, #32
    a6a0:	eb04001f 	cmp	x0, x4
    a6a4:	54000142 	b.cs	a6cc <fwp_main_thread+0xdfc>  // b.hs, b.nlast
    a6a8:	8b0002f7 	add	x23, x23, x0
    a6ac:	394002e0 	ldrb	w0, [x23]
    a6b0:	340000e0 	cbz	w0, a6cc <fwp_main_thread+0xdfc>
    a6b4:	7100041f 	cmp	w0, #0x1
    a6b8:	54004040 	b.eq	aec0 <fwp_main_thread+0x15f0>  // b.none
    a6bc:	7103fc1f 	cmp	w0, #0xff
    a6c0:	54004ee0 	b.eq	b09c <fwp_main_thread+0x17cc>  // b.none
    a6c4:	51000400 	sub	w0, w0, #0x1
    a6c8:	390002e0 	strb	w0, [x23]
    a6cc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a6d0:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    a6d4:	f95f5000 	ldr	x0, [x0, #16032]
    a6d8:	f9400800 	ldr	x0, [x0, #16]
    a6dc:	f91f5020 	str	x0, [x1, #16032]
    a6e0:	b4004840 	cbz	x0, afe8 <fwp_main_thread+0x1718>
    a6e4:	91154380 	add	x0, x28, #0x550
    a6e8:	f949d801 	ldr	x1, [x0, #5040]
    a6ec:	f949ec03 	ldr	x3, [x0, #5080]
    a6f0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a6f4:	f95f5800 	ldr	x0, [x0, #16048]
    a6f8:	d370bc63 	lsl	x3, x3, #16
    a6fc:	cb010001 	sub	x1, x0, x1
    a700:	17fffdf0 	b	9ec0 <fwp_main_thread+0x5f0>
    a704:	f9400434 	ldr	x20, [x1, #8]
    a708:	b40013d4 	cbz	x20, a980 <fwp_main_thread+0x10b0>
    a70c:	f9400820 	ldr	x0, [x1, #16]
    a710:	cb140000 	sub	x0, x0, x20
    a714:	eb0000bf 	cmp	x5, x0
    a718:	54001348 	b.hi	a980 <fwp_main_thread+0x10b0>  // b.pmore
    a71c:	8b050280 	add	x0, x20, x5
    a720:	f9000420 	str	x0, [x1, #8]
    a724:	17fffd13 	b	9b70 <fwp_main_thread+0x2a0>
    a728:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a72c:	aa1603fa 	mov	x26, x22
    a730:	aa1703e4 	mov	x4, x23
    a734:	2a0103f9 	mov	w25, w1
    a738:	f95f7c07 	ldr	x7, [x0, #16120]
    a73c:	b97ec806 	ldr	w6, [x0, #16072]
    a740:	b97ed017 	ldr	w23, [x0, #16080]
    a744:	b97ed816 	ldr	w22, [x0, #16088]
    a748:	11000700 	add	w0, w24, #0x1
    a74c:	b953a4e1 	ldr	w1, [x7, #5028]
    a750:	f120001f 	cmp	x0, #0x800
    a754:	d37df000 	lsl	x0, x0, #3
    a758:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a75c:	54002ac0 	b.eq	acb4 <fwp_main_thread+0x13e4>  // b.none
    a760:	91003c01 	add	x1, x0, #0xf
    a764:	8b4110e1 	add	x1, x7, x1, lsr #4
    a768:	397e8021 	ldrb	w1, [x1, #4000]
    a76c:	910f002b 	add	x11, x1, #0x3c0
    a770:	8b010422 	add	x2, x1, x1, lsl #1
    a774:	b86b78eb 	ldr	w11, [x7, x11, lsl #2]
    a778:	8b020cec 	add	x12, x7, x2, lsl #3
    a77c:	f86278f3 	ldr	x19, [x7, x2, lsl #3]
    a780:	2a0b03e1 	mov	w1, w11
    a784:	b4002873 	cbz	x19, ac90 <fwp_main_thread+0x13c0>
    a788:	f940026c 	ldr	x12, [x19]
    a78c:	aa2c03ec 	mvn	x12, x12
    a790:	f82278ec 	str	x12, [x7, x2, lsl #3]
    a794:	eb01001f 	cmp	x0, x1
    a798:	540000c2 	b.cs	a7b0 <fwp_main_thread+0xee0>  // b.hs, b.nlast
    a79c:	d503201f 	nop
    a7a0:	f8206a7f 	str	xzr, [x19, x0]
    a7a4:	91002000 	add	x0, x0, #0x8
    a7a8:	eb00003f 	cmp	x1, x0
    a7ac:	54ffffa8 	b.hi	a7a0 <fwp_main_thread+0xed0>  // b.pmore
    a7b0:	f94a10e0 	ldr	x0, [x7, #5152]
    a7b4:	ab010000 	adds	x0, x0, x1
    a7b8:	54004162 	b.cs	afe4 <fwp_main_thread+0x1714>  // b.hs, b.nlast
    a7bc:	f94a14e1 	ldr	x1, [x7, #5160]
    a7c0:	f90a10e0 	str	x0, [x7, #5152]
    a7c4:	eb01001f 	cmp	x0, x1
    a7c8:	54000049 	b.ls	a7d0 <fwp_main_thread+0xf00>  // b.plast
    a7cc:	f90a14e0 	str	x0, [x7, #5160]
    a7d0:	1e630161 	ucvtf	d1, w11
    a7d4:	fd4a1ce0 	ldr	d0, [x7, #5176]
    a7d8:	1e612800 	fadd	d0, d0, d1
    a7dc:	fd0a1ce0 	str	d0, [x7, #5176]
    a7e0:	b9400140 	ldr	w0, [x10]
    a7e4:	29006260 	stp	w0, w24, [x19]
    a7e8:	340001f9 	cbz	w25, a824 <fwp_main_thread+0xf54>
    a7ec:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a7f0:	91002141 	add	x1, x10, #0x8
    a7f4:	d37d7f22 	ubfiz	x2, x25, #3, #32
    a7f8:	f91f6407 	str	x7, [x0, #16072]
    a7fc:	f91f6804 	str	x4, [x0, #16080]
    a800:	b93ef006 	str	w6, [x0, #16112]
    a804:	f91f7c0a 	str	x10, [x0, #16120]
    a808:	91002260 	add	x0, x19, #0x8
    a80c:	97ffdf95 	bl	2660 <memmove@plt>
    a810:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a814:	f95f6407 	ldr	x7, [x0, #16072]
    a818:	f95f6804 	ldr	x4, [x0, #16080]
    a81c:	f95f7c0a 	ldr	x10, [x0, #16120]
    a820:	b97ef006 	ldr	w6, [x0, #16112]
    a824:	2a1403e0 	mov	w0, w20
    a828:	d2800001 	mov	x1, #0x0                   	// #0
    a82c:	34000114 	cbz	w20, a84c <fwp_main_thread+0xf7c>
    a830:	0b010322 	add	w2, w25, w1
    a834:	f8617b43 	ldr	x3, [x26, x1, lsl #3]
    a838:	8b020e62 	add	x2, x19, x2, lsl #3
    a83c:	91000421 	add	x1, x1, #0x1
    a840:	f9000443 	str	x3, [x2, #8]
    a844:	eb00003f 	cmp	x1, x0
    a848:	54ffff41 	b.ne	a830 <fwp_main_thread+0xf60>  // b.any
    a84c:	f949d8e0 	ldr	x0, [x7, #5040]
    a850:	f949ece1 	ldr	x1, [x7, #5080]
    a854:	cb000360 	sub	x0, x27, x0
    a858:	eb01401f 	cmp	x0, x1, lsl #16
    a85c:	540002e2 	b.cs	a8b8 <fwp_main_thread+0xfe8>  // b.hs, b.nlast
    a860:	d350fc01 	lsr	x1, x0, #16
    a864:	f949fce5 	ldr	x5, [x7, #5112]
    a868:	8b010821 	add	x1, x1, x1, lsl #2
    a86c:	d37df021 	lsl	x1, x1, #3
    a870:	8b0100a3 	add	x3, x5, x1
    a874:	f9401062 	ldr	x2, [x3, #32]
    a878:	b4000202 	cbz	x2, a8b8 <fwp_main_thread+0xfe8>
    a87c:	386168a1 	ldrb	w1, [x5, x1]
    a880:	7100083f 	cmp	w1, #0x2
    a884:	540023a0 	b.eq	acf8 <fwp_main_thread+0x1428>  // b.none
    a888:	7100043f 	cmp	w1, #0x1
    a88c:	54000161 	b.ne	a8b8 <fwp_main_thread+0xfe8>  // b.any
    a890:	29430465 	ldp	w5, w1, [x3, #24]
    a894:	92403c00 	and	x0, x0, #0xffff
    a898:	9b057c00 	mul	x0, x0, x5
    a89c:	d360fc00 	lsr	x0, x0, #32
    a8a0:	eb01001f 	cmp	x0, x1
    a8a4:	540000a2 	b.cs	a8b8 <fwp_main_thread+0xfe8>  // b.hs, b.nlast
    a8a8:	8b000042 	add	x2, x2, x0
    a8ac:	39400040 	ldrb	w0, [x2]
    a8b0:	7100041f 	cmp	w0, #0x1
    a8b4:	54001e40 	b.eq	ac7c <fwp_main_thread+0x13ac>  // b.none
    a8b8:	f9400c82 	ldr	x2, [x4, #24]
    a8bc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8c0:	52800021 	mov	w1, #0x1                   	// #1
    a8c4:	f9400442 	ldr	x2, [x2, #8]
    a8c8:	f91f7807 	str	x7, [x0, #16112]
    a8cc:	b93ef806 	str	w6, [x0, #16120]
    a8d0:	aa1b03e0 	mov	x0, x27
    a8d4:	d63f0040 	blr	x2
    a8d8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a8dc:	f95f7807 	ldr	x7, [x0, #16112]
    a8e0:	b97ef806 	ldr	w6, [x0, #16120]
    a8e4:	f949d8e1 	ldr	x1, [x7, #5040]
    a8e8:	f949ece0 	ldr	x0, [x7, #5080]
    a8ec:	cb010261 	sub	x1, x19, x1
    a8f0:	eb00403f 	cmp	x1, x0, lsl #16
    a8f4:	54000322 	b.cs	a958 <fwp_main_thread+0x1088>  // b.hs, b.nlast
    a8f8:	d350fc20 	lsr	x0, x1, #16
    a8fc:	f949fce3 	ldr	x3, [x7, #5112]
    a900:	8b000800 	add	x0, x0, x0, lsl #2
    a904:	d37df002 	lsl	x2, x0, #3
    a908:	8b020060 	add	x0, x3, x2
    a90c:	f9401014 	ldr	x20, [x0, #32]
    a910:	b4000254 	cbz	x20, a958 <fwp_main_thread+0x1088>
    a914:	38626862 	ldrb	w2, [x3, x2]
    a918:	7100085f 	cmp	w2, #0x2
    a91c:	54001e80 	b.eq	acec <fwp_main_thread+0x141c>  // b.none
    a920:	7100045f 	cmp	w2, #0x1
    a924:	540001a1 	b.ne	a958 <fwp_main_thread+0x1088>  // b.any
    a928:	29430002 	ldp	w2, w0, [x0, #24]
    a92c:	92403c21 	and	x1, x1, #0xffff
    a930:	9b027c21 	mul	x1, x1, x2
    a934:	d360fc21 	lsr	x1, x1, #32
    a938:	eb00003f 	cmp	x1, x0
    a93c:	540000e2 	b.cs	a958 <fwp_main_thread+0x1088>  // b.hs, b.nlast
    a940:	8b010294 	add	x20, x20, x1
    a944:	39400280 	ldrb	w0, [x20]
    a948:	7103fc1f 	cmp	w0, #0xff
    a94c:	54002040 	b.eq	ad54 <fwp_main_thread+0x1484>  // b.none
    a950:	52800020 	mov	w0, #0x1                   	// #1
    a954:	39000280 	strb	w0, [x20]
    a958:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a95c:	f91f7807 	str	x7, [x0, #16112]
    a960:	b93ef806 	str	w6, [x0, #16120]
    a964:	aa1b03e0 	mov	x0, x27
    a968:	97ffecd6 	bl	5cc0 <fwp_closure_drop>
    a96c:	aa1303fb 	mov	x27, x19
    a970:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a974:	f95f7807 	ldr	x7, [x0, #16112]
    a978:	b97ef806 	ldr	w6, [x0, #16120]
    a97c:	17fffe8c 	b	a3ac <fwp_main_thread+0xadc>
    a980:	52800001 	mov	w1, #0x0                   	// #0
    a984:	d2800300 	mov	x0, #0x18                  	// #24
    a988:	97ffe89a 	bl	4bf0 <fwp_heap_alloc>
    a98c:	aa0003f4 	mov	x20, x0
    a990:	17fffc90 	b	9bd0 <fwp_main_thread+0x300>
    a994:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    a998:	aa1a03fb 	mov	x27, x26
    a99c:	f95f7c07 	ldr	x7, [x0, #16120]
    a9a0:	b97ec806 	ldr	w6, [x0, #16072]
    a9a4:	b97ed017 	ldr	w23, [x0, #16080]
    a9a8:	b97ed816 	ldr	w22, [x0, #16088]
    a9ac:	17fffe80 	b	a3ac <fwp_main_thread+0xadc>
    a9b0:	a911fe76 	stp	x22, xzr, [x19, #280]
    a9b4:	f9009660 	str	x0, [x19, #296]
    a9b8:	b4000040 	cbz	x0, a9c0 <fwp_main_thread+0x10f0>
    a9bc:	f9009013 	str	x19, [x0, #288]
    a9c0:	f9002293 	str	x19, [x20, #64]
    a9c4:	17fffc27 	b	9a60 <fwp_main_thread+0x190>
    a9c8:	f9000040 	str	x0, [x2]
    a9cc:	17fffc2d 	b	9a80 <fwp_main_thread+0x1b0>
    a9d0:	39014a98 	strb	w24, [x20, #82]
    a9d4:	d00000a0 	adrp	x0, 20000 <__data_start>
    a9d8:	91010013 	add	x19, x0, #0x40
    a9dc:	f9416e60 	ldr	x0, [x19, #728]
    a9e0:	b5000060 	cbnz	x0, a9ec <fwp_main_thread+0x111c>
    a9e4:	f9417660 	ldr	x0, [x19, #744]
    a9e8:	b4001c80 	cbz	x0, ad78 <fwp_main_thread+0x14a8>
    a9ec:	d00000a0 	adrp	x0, 20000 <__data_start>
    a9f0:	91010000 	add	x0, x0, #0x40
    a9f4:	f9400800 	ldr	x0, [x0, #16]
    a9f8:	d00000a1 	adrp	x1, 20000 <__data_start>
    a9fc:	91010021 	add	x1, x1, #0x40
    aa00:	f9418825 	ldr	x5, [x1, #784]
    aa04:	b903083f 	str	wzr, [x1, #776]
    aa08:	eb0000bf 	cmp	x5, x0
    aa0c:	54003901 	b.ne	b12c <fwp_main_thread+0x185c>  // b.any
    aa10:	b4000420 	cbz	x0, aa94 <fwp_main_thread+0x11c4>
    aa14:	f9415826 	ldr	x6, [x1, #688]
    aa18:	52800021 	mov	w1, #0x1                   	// #1
    aa1c:	39014801 	strb	w1, [x0, #82]
    aa20:	b40003a6 	cbz	x6, aa94 <fwp_main_thread+0x11c4>
    aa24:	d503201f 	nop
    aa28:	394140c0 	ldrb	w0, [x6, #80]
    aa2c:	37000060 	tbnz	w0, #0, aa38 <fwp_main_thread+0x1168>
    aa30:	aa0603e0 	mov	x0, x6
    aa34:	97ffe26f 	bl	33f0 <fwp_cancel_tree.part.0>
    aa38:	f9409cc6 	ldr	x6, [x6, #312]
    aa3c:	b5ffff66 	cbnz	x6, aa28 <fwp_main_thread+0x1158>
    aa40:	d00000a0 	adrp	x0, 20000 <__data_start>
    aa44:	91010013 	add	x19, x0, #0x40
    aa48:	52800034 	mov	w20, #0x1                   	// #1
    aa4c:	d503201f 	nop
    aa50:	f94028a0 	ldr	x0, [x5, #80]
    aa54:	f2001c1f 	tst	x0, #0xff000000ff
    aa58:	540000e1 	b.ne	aa74 <fwp_main_thread+0x11a4>  // b.any
    aa5c:	f9401660 	ldr	x0, [x19, #40]
    aa60:	390150b4 	strb	w20, [x5, #84]
    aa64:	f90080bf 	str	xzr, [x5, #256]
    aa68:	b4000120 	cbz	x0, aa8c <fwp_main_thread+0x11bc>
    aa6c:	f9008005 	str	x5, [x0, #256]
    aa70:	f9001665 	str	x5, [x19, #40]
    aa74:	97ffee83 	bl	6480 <fwp_block>
    aa78:	97ffee0a 	bl	62a0 <fwp_free_zombie>
    aa7c:	f9415a60 	ldr	x0, [x19, #688]
    aa80:	b40000a0 	cbz	x0, aa94 <fwp_main_thread+0x11c4>
    aa84:	f9418a65 	ldr	x5, [x19, #784]
    aa88:	17fffff2 	b	aa50 <fwp_main_thread+0x1180>
    aa8c:	f9001a65 	str	x5, [x19, #48]
    aa90:	17fffff8 	b	aa70 <fwp_main_thread+0x11a0>
    aa94:	97ffee03 	bl	62a0 <fwp_free_zombie>
    aa98:	d00000a0 	adrp	x0, 20000 <__data_start>
    aa9c:	91010014 	add	x20, x0, #0x40
    aaa0:	f9401a80 	ldr	x0, [x20, #48]
    aaa4:	b5003440 	cbnz	x0, b12c <fwp_main_thread+0x185c>
    aaa8:	f9404680 	ldr	x0, [x20, #136]
    aaac:	b5003400 	cbnz	x0, b12c <fwp_main_thread+0x185c>
    aab0:	b940aa80 	ldr	w0, [x20, #168]
    aab4:	340001c0 	cbz	w0, aaec <fwp_main_thread+0x121c>
    aab8:	93407c15 	sxtw	x21, w0
    aabc:	51000400 	sub	w0, w0, #0x1
    aac0:	d1000ab5 	sub	x21, x21, #0x2
    aac4:	9102c296 	add	x22, x20, #0xb0
    aac8:	cb2042b5 	sub	x21, x21, w0, uxtw
    aacc:	93407c13 	sxtw	x19, w0
    aad0:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    aad4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    aad8:	b900aa93 	str	w19, [x20, #168]
    aadc:	d1000673 	sub	x19, x19, #0x1
    aae0:	97ffdf8c 	bl	2910 <munmap@plt>
    aae4:	eb15027f 	cmp	x19, x21
    aae8:	54ffff41 	b.ne	aad0 <fwp_main_thread+0x1200>  // b.any
    aaec:	d00000a6 	adrp	x6, 20000 <__data_start>
    aaf0:	910040c0 	add	x0, x6, #0x10
    aaf4:	b9401000 	ldr	w0, [x0, #16]
    aaf8:	37f800c0 	tbnz	w0, #31, ab10 <fwp_main_thread+0x1240>
    aafc:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ab00:	f91f7c26 	str	x6, [x1, #16120]
    ab04:	97ffdf3f 	bl	2800 <close@plt>
    ab08:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ab0c:	f95f7c06 	ldr	x6, [x0, #16120]
    ab10:	d00000a0 	adrp	x0, 20000 <__data_start>
    ab14:	91010014 	add	x20, x0, #0x40
    ab18:	910040c6 	add	x6, x6, #0x10
    ab1c:	12800001 	mov	w1, #0xffffffff            	// #-1
    ab20:	f9419280 	ldr	x0, [x20, #800]
    ab24:	b90010c1 	str	w1, [x6, #16]
    ab28:	f9418e81 	ldr	x1, [x20, #792]
    ab2c:	b40001e0 	cbz	x0, ab68 <fwp_main_thread+0x1298>
    ab30:	d2800013 	mov	x19, #0x0                   	// #0
    ab34:	d503201f 	nop
    ab38:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    ab3c:	b40000e0 	cbz	x0, ab58 <fwp_main_thread+0x1288>
    ab40:	f9400001 	ldr	x1, [x0]
    ab44:	b5002f41 	cbnz	x1, b12c <fwp_main_thread+0x185c>
    ab48:	f9400401 	ldr	x1, [x0, #8]
    ab4c:	b5002f01 	cbnz	x1, b12c <fwp_main_thread+0x185c>
    ab50:	97ffe56c 	bl	4100 <fwp_mem_free>
    ab54:	f9418e81 	ldr	x1, [x20, #792]
    ab58:	91000673 	add	x19, x19, #0x1
    ab5c:	f9419280 	ldr	x0, [x20, #800]
    ab60:	eb00027f 	cmp	x19, x0
    ab64:	54fffea3 	b.cc	ab38 <fwp_main_thread+0x1268>  // b.lo, b.ul, b.last
    ab68:	aa0103e0 	mov	x0, x1
    ab6c:	97ffe565 	bl	4100 <fwp_mem_free>
    ab70:	d00000a0 	adrp	x0, 20000 <__data_start>
    ab74:	91010000 	add	x0, x0, #0x40
    ab78:	f9418813 	ldr	x19, [x0, #784]
    ab7c:	f9018c1f 	str	xzr, [x0, #792]
    ab80:	f901901f 	str	xzr, [x0, #800]
    ab84:	b40001f3 	cbz	x19, abc0 <fwp_main_thread+0x12f0>
    ab88:	f9401661 	ldr	x1, [x19, #40]
    ab8c:	b5002d01 	cbnz	x1, b12c <fwp_main_thread+0x185c>
    ab90:	f9405661 	ldr	x1, [x19, #168]
    ab94:	b5002cc1 	cbnz	x1, b12c <fwp_main_thread+0x185c>
    ab98:	f9416c01 	ldr	x1, [x0, #728]
    ab9c:	b5002c81 	cbnz	x1, b12c <fwp_main_thread+0x185c>
    aba0:	f9417400 	ldr	x0, [x0, #744]
    aba4:	b5002c40 	cbnz	x0, b12c <fwp_main_thread+0x185c>
    aba8:	d2823a02 	mov	x2, #0x11d0                	// #4560
    abac:	d0000120 	adrp	x0, 30000 <alt.5+0xfc90>
    abb0:	910dc000 	add	x0, x0, #0x370
    abb4:	97ffdf03 	bl	27c0 <memset@plt>
    abb8:	aa1303e0 	mov	x0, x19
    abbc:	97ffe551 	bl	4100 <fwp_mem_free>
    abc0:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    abc4:	f947ec00 	ldr	x0, [x0, #4056]
    abc8:	d00000a1 	adrp	x1, 20000 <__data_start>
    abcc:	91010021 	add	x1, x1, #0x40
    abd0:	f9400000 	ldr	x0, [x0]
    abd4:	f900083f 	str	xzr, [x1, #16]
    abd8:	f901883f 	str	xzr, [x1, #784]
    abdc:	97ffdf51 	bl	2920 <fflush@plt>
    abe0:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb38>
    abe4:	f947f400 	ldr	x0, [x0, #4072]
    abe8:	f85f83a2 	ldur	x2, [x29, #-8]
    abec:	f9400001 	ldr	x1, [x0]
    abf0:	eb010042 	subs	x2, x2, x1
    abf4:	d2800001 	mov	x1, #0x0                   	// #0
    abf8:	54001d61 	b.ne	afa4 <fwp_main_thread+0x16d4>  // b.any
    abfc:	910003bf 	mov	sp, x29
    ac00:	d2800000 	mov	x0, #0x0                   	// #0
    ac04:	a94153f3 	ldp	x19, x20, [sp, #16]
    ac08:	a9425bf5 	ldp	x21, x22, [sp, #32]
    ac0c:	a94363f7 	ldp	x23, x24, [sp, #48]
    ac10:	a9446bf9 	ldp	x25, x26, [sp, #64]
    ac14:	a94573fb 	ldp	x27, x28, [sp, #80]
    ac18:	fd4033e8 	ldr	d8, [sp, #96]
    ac1c:	a8c77bfd 	ldp	x29, x30, [sp], #112
    ac20:	d65f03c0 	ret
    ac24:	72003c3f 	tst	w1, #0xffff
    ac28:	54ff8121 	b.ne	9c4c <fwp_main_thread+0x37c>  // b.any
    ac2c:	17fffc04 	b	9c3c <fwp_main_thread+0x36c>
    ac30:	b8626860 	ldr	w0, [x3, x2]
    ac34:	b94004a2 	ldr	w2, [x5, #4]
    ac38:	4b020003 	sub	w3, w0, w2
    ac3c:	7100047f 	cmp	w3, #0x1
    ac40:	54ff9901 	b.ne	9f60 <fwp_main_thread+0x690>  // b.any
    ac44:	910003f6 	mov	x22, sp
    ac48:	35000e82 	cbnz	w2, ae18 <fwp_main_thread+0x1548>
    ac4c:	f9400021 	ldr	x1, [x1]
    ac50:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac54:	f91f7c05 	str	x5, [x0, #16120]
    ac58:	aa1403e0 	mov	x0, x20
    ac5c:	d63f0020 	blr	x1
    ac60:	aa0003fb 	mov	x27, x0
    ac64:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ac68:	f95f7c05 	ldr	x5, [x0, #16120]
    ac6c:	910002df 	mov	sp, x22
    ac70:	17fffdff 	b	a46c <fwp_main_thread+0xb9c>
    ac74:	f90046a0 	str	x0, [x21, #136]
    ac78:	17fffb8c 	b	9aa8 <fwp_main_thread+0x1d8>
    ac7c:	b900055f 	str	wzr, [x10, #4]
    ac80:	17ffff19 	b	a8e4 <fwp_main_thread+0x1014>
    ac84:	72003c3f 	tst	w1, #0xffff
    ac88:	54ff9a81 	b.ne	9fd8 <fwp_main_thread+0x708>  // b.any
    ac8c:	17fffccd 	b	9fc0 <fwp_main_thread+0x6f0>
    ac90:	f9400593 	ldr	x19, [x12, #8]
    ac94:	b4000113 	cbz	x19, acb4 <fwp_main_thread+0x13e4>
    ac98:	f9400982 	ldr	x2, [x12, #16]
    ac9c:	cb130042 	sub	x2, x2, x19
    aca0:	eb02003f 	cmp	x1, x2
    aca4:	54000088 	b.hi	acb4 <fwp_main_thread+0x13e4>  // b.pmore
    aca8:	8b010262 	add	x2, x19, x1
    acac:	f9000582 	str	x2, [x12, #8]
    acb0:	17fffeb9 	b	a794 <fwp_main_thread+0xec4>
    acb4:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    acb8:	f91f6427 	str	x7, [x1, #16072]
    acbc:	f91f6824 	str	x4, [x1, #16080]
    acc0:	b93ef026 	str	w6, [x1, #16112]
    acc4:	f91f7c2a 	str	x10, [x1, #16120]
    acc8:	52800001 	mov	w1, #0x0                   	// #0
    accc:	97ffe7c9 	bl	4bf0 <fwp_heap_alloc>
    acd0:	aa0003f3 	mov	x19, x0
    acd4:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    acd8:	f95f6407 	ldr	x7, [x0, #16072]
    acdc:	f95f6804 	ldr	x4, [x0, #16080]
    ace0:	f95f7c0a 	ldr	x10, [x0, #16120]
    ace4:	b97ef006 	ldr	w6, [x0, #16112]
    ace8:	17fffebe 	b	a7e0 <fwp_main_thread+0xf10>
    acec:	72003c3f 	tst	w1, #0xffff
    acf0:	54ffe341 	b.ne	a958 <fwp_main_thread+0x1088>  // b.any
    acf4:	17ffff14 	b	a944 <fwp_main_thread+0x1074>
    acf8:	72003c1f 	tst	w0, #0xffff
    acfc:	54ffdde1 	b.ne	a8b8 <fwp_main_thread+0xfe8>  // b.any
    ad00:	17fffeeb 	b	a8ac <fwp_main_thread+0xfdc>
    ad04:	aa0003e1 	mov	x1, x0
    ad08:	f9002293 	str	x19, [x20, #64]
    ad0c:	17fffb4e 	b	9a44 <fwp_main_thread+0x174>
    ad10:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad14:	aa0703f8 	mov	x24, x7
    ad18:	f95f5c05 	ldr	x5, [x0, #16056]
    ad1c:	f95f6014 	ldr	x20, [x0, #16064]
    ad20:	17fffdd3 	b	a46c <fwp_main_thread+0xb9c>
    ad24:	72003c3f 	tst	w1, #0xffff
    ad28:	54ff8b01 	b.ne	9e88 <fwp_main_thread+0x5b8>  // b.any
    ad2c:	17fffc4d 	b	9e60 <fwp_main_thread+0x590>
    ad30:	72003c3f 	tst	w1, #0xffff
    ad34:	54ff7fc1 	b.ne	9d2c <fwp_main_thread+0x45c>  // b.any
    ad38:	17fffbf8 	b	9d18 <fwp_main_thread+0x448>
    ad3c:	72003c3f 	tst	w1, #0xffff
    ad40:	54ff8461 	b.ne	9dcc <fwp_main_thread+0x4fc>  // b.any
    ad44:	17fffc1d 	b	9db8 <fwp_main_thread+0x4e8>
    ad48:	72003c3f 	tst	w1, #0xffff
    ad4c:	54ff8f21 	b.ne	9f30 <fwp_main_thread+0x660>  // b.any
    ad50:	17fffc72 	b	9f18 <fwp_main_thread+0x648>
    ad54:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad58:	f91f7807 	str	x7, [x0, #16112]
    ad5c:	b93ef806 	str	w6, [x0, #16120]
    ad60:	aa1403e0 	mov	x0, x20
    ad64:	97ffe44b 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ad68:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ad6c:	f95f7807 	ldr	x7, [x0, #16112]
    ad70:	b97ef806 	ldr	w6, [x0, #16120]
    ad74:	17fffef7 	b	a950 <fwp_main_thread+0x1080>
    ad78:	f9416a60 	ldr	x0, [x19, #720]
    ad7c:	97ffe4e1 	bl	4100 <fwp_mem_free>
    ad80:	f9016a7f 	str	xzr, [x19, #720]
    ad84:	f9400a60 	ldr	x0, [x19, #16]
    ad88:	f901727f 	str	xzr, [x19, #736]
    ad8c:	b4ffe360 	cbz	x0, a9f8 <fwp_main_thread+0x1128>
    ad90:	f900541f 	str	xzr, [x0, #168]
    ad94:	f9005c1f 	str	xzr, [x0, #184]
    ad98:	17ffff18 	b	a9f8 <fwp_main_thread+0x1128>
    ad9c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ada0:	f91f7825 	str	x5, [x1, #16112]
    ada4:	f91f7c24 	str	x4, [x1, #16120]
    ada8:	97ffe54f 	bl	42e4 <fwp_rc_wide_dup>
    adac:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    adb0:	f95f7805 	ldr	x5, [x0, #16112]
    adb4:	f95f7c04 	ldr	x4, [x0, #16120]
    adb8:	17fffc88 	b	9fd8 <fwp_main_thread+0x708>
    adbc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    adc0:	f91f7807 	str	x7, [x0, #16112]
    adc4:	f91f7c09 	str	x9, [x0, #16120]
    adc8:	aa1403e0 	mov	x0, x20
    adcc:	97ffe431 	bl	3e90 <fwp_rc_forget_slot.part.0>
    add0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    add4:	f95f7807 	ldr	x7, [x0, #16112]
    add8:	f95f7c09 	ldr	x9, [x0, #16120]
    addc:	17fffc24 	b	9e6c <fwp_main_thread+0x59c>
    ade0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ade4:	f91f7c07 	str	x7, [x0, #16120]
    ade8:	aa1403e0 	mov	x0, x20
    adec:	97ffe429 	bl	3e90 <fwp_rc_forget_slot.part.0>
    adf0:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    adf4:	f95f7c07 	ldr	x7, [x0, #16120]
    adf8:	17fffbcb 	b	9d24 <fwp_main_thread+0x454>
    adfc:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae00:	f91f7c07 	str	x7, [x0, #16120]
    ae04:	aa1503e0 	mov	x0, x21
    ae08:	97ffe422 	bl	3e90 <fwp_rc_forget_slot.part.0>
    ae0c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae10:	f95f7c07 	ldr	x7, [x0, #16120]
    ae14:	17fffbec 	b	9dc4 <fwp_main_thread+0x4f4>
    ae18:	7100001f 	cmp	w0, #0x0
    ae1c:	d37d7c00 	ubfiz	x0, x0, #3, #32
    ae20:	d2800101 	mov	x1, #0x8                   	// #8
    ae24:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    ae28:	91003ee0 	add	x0, x23, #0xf
    ae2c:	92704c01 	and	x1, x0, #0xfffff0000
    ae30:	927c7c00 	and	x0, x0, #0xffffffff0
    ae34:	cb2163e1 	sub	x1, sp, x1
    ae38:	eb2163ff 	cmp	sp, x1
    ae3c:	54000620 	b.eq	af00 <fwp_main_thread+0x1630>  // b.none
    ae40:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    ae44:	f90203ff 	str	xzr, [sp, #1024]
    ae48:	17fffffc 	b	ae38 <fwp_main_thread+0x1568>
    ae4c:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ae50:	f91f7c25 	str	x5, [x1, #16120]
    ae54:	97ffe524 	bl	42e4 <fwp_rc_wide_dup>
    ae58:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae5c:	f95f7c05 	ldr	x5, [x0, #16120]
    ae60:	17fffc34 	b	9f30 <fwp_main_thread+0x660>
    ae64:	72003c3f 	tst	w1, #0xffff
    ae68:	54ffbc00 	b.eq	a5e8 <fwp_main_thread+0xd18>  // b.none
    ae6c:	aa1803e5 	mov	x5, x24
    ae70:	aa1303f8 	mov	x24, x19
    ae74:	17fffde7 	b	a610 <fwp_main_thread+0xd40>
    ae78:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    ae7c:	aa0503e0 	mov	x0, x5
    ae80:	52800036 	mov	w22, #0x1                   	// #1
    ae84:	f91f7c25 	str	x5, [x1, #16120]
    ae88:	97ffea62 	bl	5810 <fwp_rc_share>
    ae8c:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae90:	f95f5800 	ldr	x0, [x0, #16048]
    ae94:	97ffea5f 	bl	5810 <fwp_rc_share>
    ae98:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    ae9c:	f95f7c05 	ldr	x5, [x0, #16120]
    aea0:	f91f7414 	str	x20, [x0, #16104]
    aea4:	17fffd69 	b	a448 <fwp_main_thread+0xb78>
    aea8:	72003c3f 	tst	w1, #0xffff
    aeac:	54ffb681 	b.ne	a57c <fwp_main_thread+0xcac>  // b.any
    aeb0:	17fffdae 	b	a568 <fwp_main_thread+0xc98>
    aeb4:	b0000000 	adrp	x0, b000 <fwp_main_thread+0x1730>
    aeb8:	91386000 	add	x0, x0, #0xe18
    aebc:	97ffe3d5 	bl	3e10 <fwp_trap>
    aec0:	7100087f 	cmp	w3, #0x2
    aec4:	540010a0 	b.eq	b0d8 <fwp_main_thread+0x1808>  // b.none
    aec8:	29430043 	ldp	w3, w0, [x2, #24]
    aecc:	9b037c21 	mul	x1, x1, x3
    aed0:	eb41801f 	cmp	x0, x1, lsr #32
    aed4:	54ffbfc9 	b.ls	a6cc <fwp_main_thread+0xdfc>  // b.plast
    aed8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aedc:	f91f7c05 	str	x5, [x0, #16120]
    aee0:	aa1603e0 	mov	x0, x22
    aee4:	97ffe487 	bl	4100 <fwp_mem_free>
    aee8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    aeec:	f95f7c05 	ldr	x5, [x0, #16120]
    aef0:	17fffdf7 	b	a6cc <fwp_main_thread+0xdfc>
    aef4:	f2403c21 	ands	x1, x1, #0xffff
    aef8:	54ffbea1 	b.ne	a6cc <fwp_main_thread+0xdfc>  // b.any
    aefc:	17fffdec 	b	a6ac <fwp_main_thread+0xddc>
    af00:	92403c00 	and	x0, x0, #0xffff
    af04:	cb2063ff 	sub	sp, sp, x0
    af08:	f90003ff 	str	xzr, [sp]
    af0c:	f110001f 	cmp	x0, #0x400
    af10:	54000043 	b.cc	af18 <fwp_main_thread+0x1648>  // b.lo, b.ul, b.last
    af14:	f90203ff 	str	xzr, [sp, #1024]
    af18:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    af1c:	d37d7c5a 	ubfiz	x26, x2, #3, #32
    af20:	910043f9 	add	x25, sp, #0x10
    af24:	aa1a03e2 	mov	x2, x26
    af28:	aa1703e3 	mov	x3, x23
    af2c:	f91f7805 	str	x5, [x0, #16112]
    af30:	f91f7c04 	str	x4, [x0, #16120]
    af34:	f95f4800 	ldr	x0, [x0, #16016]
    af38:	91004001 	add	x1, x0, #0x10
    af3c:	aa1903e0 	mov	x0, x25
    af40:	91004021 	add	x1, x1, #0x10
    af44:	97ffddff 	bl	2740 <__memcpy_chk@plt>
    af48:	eb1a02ff 	cmp	x23, x26
    af4c:	aa1403e1 	mov	x1, x20
    af50:	9a9a22e3 	csel	x3, x23, x26, cs	// cs = hs, nlast
    af54:	d2800102 	mov	x2, #0x8                   	// #8
    af58:	cb1a0063 	sub	x3, x3, x26
    af5c:	8b1a0320 	add	x0, x25, x26
    af60:	97ffddf8 	bl	2740 <__memcpy_chk@plt>
    af64:	d14013a1 	sub	x1, x29, #0x4, lsl #12
    af68:	aa1903e0 	mov	x0, x25
    af6c:	f95f7c24 	ldr	x4, [x1, #16120]
    af70:	f9400c81 	ldr	x1, [x4, #24]
    af74:	f9400021 	ldr	x1, [x1]
    af78:	d63f0020 	blr	x1
    af7c:	aa0003fb 	mov	x27, x0
    af80:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    af84:	f95f7805 	ldr	x5, [x0, #16112]
    af88:	910002df 	mov	sp, x22
    af8c:	17fffd38 	b	a46c <fwp_main_thread+0xb9c>
    af90:	f9400b77 	ldr	x23, [x27, #16]
    af94:	aa1b03e0 	mov	x0, x27
    af98:	97ffea42 	bl	58a0 <fwp_rc_free_arr>
    af9c:	aa1703fb 	mov	x27, x23
    afa0:	17fffd7a 	b	a588 <fwp_main_thread+0xcb8>
    afa4:	97ffde13 	bl	27f0 <__stack_chk_fail@plt>
    afa8:	ca5746e0 	eor	x0, x23, x23, lsr #17
    afac:	91154382 	add	x2, x28, #0x550
    afb0:	ca402400 	eor	x0, x0, x0, lsr #9
    afb4:	92401c00 	and	x0, x0, #0xff
    afb8:	910a2401 	add	x1, x0, #0x289
    afbc:	8b000c40 	add	x0, x2, x0, lsl #3
    afc0:	8b010c41 	add	x1, x2, x1, lsl #3
    afc4:	f94a2400 	ldr	x0, [x0, #5192]
    afc8:	b4000480 	cbz	x0, b058 <fwp_main_thread+0x1788>
    afcc:	f9400002 	ldr	x2, [x0]
    afd0:	eb17005f 	cmp	x2, x23
    afd4:	540002a0 	b.eq	b028 <fwp_main_thread+0x1758>  // b.none
    afd8:	91004001 	add	x1, x0, #0x10
    afdc:	f9400800 	ldr	x0, [x0, #16]
    afe0:	17fffffa 	b	afc8 <fwp_main_thread+0x16f8>
    afe4:	97ffdff3 	bl	2fb0 <fwp_heap_oom>
    afe8:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    afec:	f95f4c07 	ldr	x7, [x0, #16024]
    aff0:	f91f7c07 	str	x7, [x0, #16120]
    aff4:	f95f5809 	ldr	x9, [x0, #16048]
    aff8:	aa0903e0 	mov	x0, x9
    affc:	97ffeacd 	bl	5b30 <fwp_drop0>
    b000:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b004:	f95f7c07 	ldr	x7, [x0, #16120]
    b008:	aa0703e0 	mov	x0, x7
    b00c:	97ffeac9 	bl	5b30 <fwp_drop0>
    b010:	b00000a0 	adrp	x0, 20000 <__data_start>
    b014:	91010000 	add	x0, x0, #0x40
    b018:	52800021 	mov	w1, #0x1                   	// #1
    b01c:	b902f801 	str	w1, [x0, #760]
    b020:	f901801f 	str	xzr, [x0, #768]
    b024:	17fffa6f 	b	99e0 <fwp_main_thread+0x110>
    b028:	f9400021 	ldr	x1, [x1]
    b02c:	f9400420 	ldr	x0, [x1, #8]
    b030:	d1000400 	sub	x0, x0, #0x1
    b034:	f9000420 	str	x0, [x1, #8]
    b038:	f103f81f 	cmp	x0, #0xfe
    b03c:	54ffaea1 	b.ne	a610 <fwp_main_thread+0xd40>  // b.any
    b040:	394002e0 	ldrb	w0, [x23]
    b044:	7103fc1f 	cmp	w0, #0xff
    b048:	540000e0 	b.eq	b064 <fwp_main_thread+0x1794>  // b.none
    b04c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    b050:	390002e0 	strb	w0, [x23]
    b054:	17fffd6f 	b	a610 <fwp_main_thread+0xd40>
    b058:	90000000 	adrp	x0, b000 <fwp_main_thread+0x1730>
    b05c:	91264000 	add	x0, x0, #0x990
    b060:	97ffe36c 	bl	3e10 <fwp_trap>
    b064:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b068:	f91f7c05 	str	x5, [x0, #16120]
    b06c:	aa1703e0 	mov	x0, x23
    b070:	97ffe388 	bl	3e90 <fwp_rc_forget_slot.part.0>
    b074:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b078:	f95f7c05 	ldr	x5, [x0, #16120]
    b07c:	17fffff4 	b	b04c <fwp_main_thread+0x177c>
    b080:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b084:	f91f7c05 	str	x5, [x0, #16120]
    b088:	aa1703e0 	mov	x0, x23
    b08c:	97ffe381 	bl	3e90 <fwp_rc_forget_slot.part.0>
    b090:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b094:	f95f7c05 	ldr	x5, [x0, #16120]
    b098:	17fffd37 	b	a574 <fwp_main_thread+0xca4>
    b09c:	ca5746e0 	eor	x0, x23, x23, lsr #17
    b0a0:	91154382 	add	x2, x28, #0x550
    b0a4:	ca402400 	eor	x0, x0, x0, lsr #9
    b0a8:	92401c00 	and	x0, x0, #0xff
    b0ac:	910a2401 	add	x1, x0, #0x289
    b0b0:	8b000c40 	add	x0, x2, x0, lsl #3
    b0b4:	8b010c41 	add	x1, x2, x1, lsl #3
    b0b8:	f94a2400 	ldr	x0, [x0, #5192]
    b0bc:	b4fffce0 	cbz	x0, b058 <fwp_main_thread+0x1788>
    b0c0:	f9400002 	ldr	x2, [x0]
    b0c4:	eb0202ff 	cmp	x23, x2
    b0c8:	540000c0 	b.eq	b0e0 <fwp_main_thread+0x1810>  // b.none
    b0cc:	91004001 	add	x1, x0, #0x10
    b0d0:	f9400800 	ldr	x0, [x0, #16]
    b0d4:	17fffffa 	b	b0bc <fwp_main_thread+0x17ec>
    b0d8:	b5ffafa1 	cbnz	x1, a6cc <fwp_main_thread+0xdfc>
    b0dc:	17ffff7f 	b	aed8 <fwp_main_thread+0x1608>
    b0e0:	f9400021 	ldr	x1, [x1]
    b0e4:	f9400420 	ldr	x0, [x1, #8]
    b0e8:	d1000400 	sub	x0, x0, #0x1
    b0ec:	f9000420 	str	x0, [x1, #8]
    b0f0:	f103f81f 	cmp	x0, #0xfe
    b0f4:	54ffaec1 	b.ne	a6cc <fwp_main_thread+0xdfc>  // b.any
    b0f8:	394002e0 	ldrb	w0, [x23]
    b0fc:	7103fc1f 	cmp	w0, #0xff
    b100:	54000080 	b.eq	b110 <fwp_main_thread+0x1840>  // b.none
    b104:	12800020 	mov	w0, #0xfffffffe            	// #-2
    b108:	390002e0 	strb	w0, [x23]
    b10c:	17fffd70 	b	a6cc <fwp_main_thread+0xdfc>
    b110:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b114:	f91f7c05 	str	x5, [x0, #16120]
    b118:	aa1703e0 	mov	x0, x23
    b11c:	97ffe35d 	bl	3e90 <fwp_rc_forget_slot.part.0>
    b120:	d14013a0 	sub	x0, x29, #0x4, lsl #12
    b124:	f95f7c05 	ldr	x5, [x0, #16120]
    b128:	17fffff7 	b	b104 <fwp_main_thread+0x1834>
    b12c:	97ffddc5 	bl	2840 <abort@plt>

000000000000b130 <__divti3>:
    b130:	d503245f 	bti	c
    b134:	d2800004 	mov	x4, #0x0                   	// #0
    b138:	b7f80721 	tbnz	x1, #63, b21c <__divti3+0xec>
    b13c:	b6f80083 	tbz	x3, #63, b14c <__divti3+0x1c>
    b140:	eb0203e2 	negs	x2, x2
    b144:	aa2403e4 	mvn	x4, x4
    b148:	da0303e3 	ngc	x3, x3
    b14c:	aa0203e6 	mov	x6, x2
    b150:	aa0003e7 	mov	x7, x0
    b154:	aa0103e5 	mov	x5, x1
    b158:	b5000583 	cbnz	x3, b208 <__divti3+0xd8>
    b15c:	eb01005f 	cmp	x2, x1
    b160:	54000e69 	b.ls	b32c <__divti3+0x1fc>  // b.plast
    b164:	dac01040 	clz	x0, x2
    b168:	b40000e0 	cbz	x0, b184 <__divti3+0x54>
    b16c:	4b0003e1 	neg	w1, w0
    b170:	9ac020a5 	lsl	x5, x5, x0
    b174:	9ac02046 	lsl	x6, x2, x0
    b178:	9ac124e1 	lsr	x1, x7, x1
    b17c:	aa050025 	orr	x5, x1, x5
    b180:	9ac020e7 	lsl	x7, x7, x0
    b184:	d360fcc8 	lsr	x8, x6, #32
    b188:	92407cc2 	and	x2, x6, #0xffffffff
    b18c:	9ac808a3 	udiv	x3, x5, x8
    b190:	9b089465 	msub	x5, x3, x8, x5
    b194:	aa0303e0 	mov	x0, x3
    b198:	9b037c41 	mul	x1, x2, x3
    b19c:	93c780a5 	extr	x5, x5, x7, #32
    b1a0:	eb05003f 	cmp	x1, x5
    b1a4:	540000a9 	b.ls	b1b8 <__divti3+0x88>  // b.plast
    b1a8:	ab0500c5 	adds	x5, x6, x5
    b1ac:	d1000460 	sub	x0, x3, #0x1
    b1b0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    b1b4:	540015a8 	b.hi	b468 <__divti3+0x338>  // b.pmore
    b1b8:	cb0100a5 	sub	x5, x5, x1
    b1bc:	9ac808a3 	udiv	x3, x5, x8
    b1c0:	9b089465 	msub	x5, x3, x8, x5
    b1c4:	aa0303e1 	mov	x1, x3
    b1c8:	9b037c42 	mul	x2, x2, x3
    b1cc:	aa0703e3 	mov	x3, x7
    b1d0:	b3607ca3 	bfi	x3, x5, #32, #32
    b1d4:	eb03005f 	cmp	x2, x3
    b1d8:	540000c9 	b.ls	b1f0 <__divti3+0xc0>  // b.plast
    b1dc:	ab0300c3 	adds	x3, x6, x3
    b1e0:	d1000425 	sub	x5, x1, #0x1
    b1e4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b1e8:	d1000821 	sub	x1, x1, #0x2
    b1ec:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    b1f0:	aa008020 	orr	x0, x1, x0, lsl #32
    b1f4:	d2800001 	mov	x1, #0x0                   	// #0
    b1f8:	b4000064 	cbz	x4, b204 <__divti3+0xd4>
    b1fc:	eb0003e0 	negs	x0, x0
    b200:	da0103e1 	ngc	x1, x1
    b204:	d65f03c0 	ret
    b208:	eb01007f 	cmp	x3, x1
    b20c:	54000109 	b.ls	b22c <__divti3+0xfc>  // b.plast
    b210:	d2800001 	mov	x1, #0x0                   	// #0
    b214:	d2800000 	mov	x0, #0x0                   	// #0
    b218:	17fffff8 	b	b1f8 <__divti3+0xc8>
    b21c:	eb0003e0 	negs	x0, x0
    b220:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b224:	da0103e1 	ngc	x1, x1
    b228:	17ffffc5 	b	b13c <__divti3+0xc>
    b22c:	dac01067 	clz	x7, x3
    b230:	b40010e7 	cbz	x7, b44c <__divti3+0x31c>
    b234:	d2800805 	mov	x5, #0x40                  	// #64
    b238:	cb0700a5 	sub	x5, x5, x7
    b23c:	9ac72063 	lsl	x3, x3, x7
    b240:	9ac52448 	lsr	x8, x2, x5
    b244:	aa030108 	orr	x8, x8, x3
    b248:	9ac52426 	lsr	x6, x1, x5
    b24c:	92407d0a 	and	x10, x8, #0xffffffff
    b250:	d360fd09 	lsr	x9, x8, #32
    b254:	9ac52403 	lsr	x3, x0, x5
    b258:	9ac72021 	lsl	x1, x1, x7
    b25c:	aa010063 	orr	x3, x3, x1
    b260:	9ac72042 	lsl	x2, x2, x7
    b264:	9ac908cb 	udiv	x11, x6, x9
    b268:	9b099965 	msub	x5, x11, x9, x6
    b26c:	aa0b03e1 	mov	x1, x11
    b270:	9b0b7d46 	mul	x6, x10, x11
    b274:	93c380a5 	extr	x5, x5, x3, #32
    b278:	eb0500df 	cmp	x6, x5
    b27c:	540000a9 	b.ls	b290 <__divti3+0x160>  // b.plast
    b280:	ab050105 	adds	x5, x8, x5
    b284:	d1000561 	sub	x1, x11, #0x1
    b288:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    b28c:	54000f48 	b.hi	b474 <__divti3+0x344>  // b.pmore
    b290:	cb0600a6 	sub	x6, x5, x6
    b294:	9ac908cb 	udiv	x11, x6, x9
    b298:	9b099969 	msub	x9, x11, x9, x6
    b29c:	aa0b03e5 	mov	x5, x11
    b2a0:	9b0b7d4a 	mul	x10, x10, x11
    b2a4:	b3607d23 	bfi	x3, x9, #32, #32
    b2a8:	eb03015f 	cmp	x10, x3
    b2ac:	540000a9 	b.ls	b2c0 <__divti3+0x190>  // b.plast
    b2b0:	ab030103 	adds	x3, x8, x3
    b2b4:	d1000565 	sub	x5, x11, #0x1
    b2b8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    b2bc:	54000e28 	b.hi	b480 <__divti3+0x350>  // b.pmore
    b2c0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    b2c4:	92407c48 	and	x8, x2, #0xffffffff
    b2c8:	2a0503e5 	mov	w5, w5
    b2cc:	d360fc42 	lsr	x2, x2, #32
    b2d0:	d360fc26 	lsr	x6, x1, #32
    b2d4:	cb0a0063 	sub	x3, x3, x10
    b2d8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    b2dc:	9b087caa 	mul	x10, x5, x8
    b2e0:	9b087cc8 	mul	x8, x6, x8
    b2e4:	9b0220a5 	madd	x5, x5, x2, x8
    b2e8:	9b027cc6 	mul	x6, x6, x2
    b2ec:	8b4a80a2 	add	x2, x5, x10, lsr #32
    b2f0:	8b0900c5 	add	x5, x6, x9
    b2f4:	eb02011f 	cmp	x8, x2
    b2f8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    b2fc:	8b4280c6 	add	x6, x6, x2, lsr #32
    b300:	eb06007f 	cmp	x3, x6
    b304:	540000e3 	b.cc	b320 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    b308:	92407d4a 	and	x10, x10, #0xffffffff
    b30c:	9ac72000 	lsl	x0, x0, x7
    b310:	8b028142 	add	x2, x10, x2, lsl #32
    b314:	eb02001f 	cmp	x0, x2
    b318:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    b31c:	54000a01 	b.ne	b45c <__divti3+0x32c>  // b.any
    b320:	d1000420 	sub	x0, x1, #0x1
    b324:	d2800001 	mov	x1, #0x0                   	// #0
    b328:	17ffffb4 	b	b1f8 <__divti3+0xc8>
    b32c:	b5000062 	cbnz	x2, b338 <__divti3+0x208>
    b330:	d2800022 	mov	x2, #0x1                   	// #1
    b334:	9ac30846 	udiv	x6, x2, x3
    b338:	dac010c8 	clz	x8, x6
    b33c:	b5000408 	cbnz	x8, b3bc <__divti3+0x28c>
    b340:	d360fcc9 	lsr	x9, x6, #32
    b344:	92407cc5 	and	x5, x6, #0xffffffff
    b348:	cb060023 	sub	x3, x1, x6
    b34c:	d2800021 	mov	x1, #0x1                   	// #1
    b350:	9ac90868 	udiv	x8, x3, x9
    b354:	9b098d03 	msub	x3, x8, x9, x3
    b358:	aa0803e0 	mov	x0, x8
    b35c:	9b057d02 	mul	x2, x8, x5
    b360:	93c78063 	extr	x3, x3, x7, #32
    b364:	eb03005f 	cmp	x2, x3
    b368:	540000a9 	b.ls	b37c <__divti3+0x24c>  // b.plast
    b36c:	ab0300c3 	adds	x3, x6, x3
    b370:	d1000500 	sub	x0, x8, #0x1
    b374:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    b378:	54000968 	b.hi	b4a4 <__divti3+0x374>  // b.pmore
    b37c:	cb020063 	sub	x3, x3, x2
    b380:	9ac90862 	udiv	x2, x3, x9
    b384:	aa0203e8 	mov	x8, x2
    b388:	9b098c42 	msub	x2, x2, x9, x3
    b38c:	aa0703e3 	mov	x3, x7
    b390:	9b057d05 	mul	x5, x8, x5
    b394:	b3607c43 	bfi	x3, x2, #32, #32
    b398:	eb0300bf 	cmp	x5, x3
    b39c:	540000c9 	b.ls	b3b4 <__divti3+0x284>  // b.plast
    b3a0:	ab0300c2 	adds	x2, x6, x3
    b3a4:	d1000503 	sub	x3, x8, #0x1
    b3a8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    b3ac:	d1000908 	sub	x8, x8, #0x2
    b3b0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    b3b4:	aa008100 	orr	x0, x8, x0, lsl #32
    b3b8:	17ffff90 	b	b1f8 <__divti3+0xc8>
    b3bc:	9ac820c6 	lsl	x6, x6, x8
    b3c0:	d2800803 	mov	x3, #0x40                  	// #64
    b3c4:	cb080063 	sub	x3, x3, x8
    b3c8:	d360fcc9 	lsr	x9, x6, #32
    b3cc:	9ac82027 	lsl	x7, x1, x8
    b3d0:	92407cc5 	and	x5, x6, #0xffffffff
    b3d4:	9ac32422 	lsr	x2, x1, x3
    b3d8:	9ac32403 	lsr	x3, x0, x3
    b3dc:	aa070063 	orr	x3, x3, x7
    b3e0:	9ac9084a 	udiv	x10, x2, x9
    b3e4:	9ac82007 	lsl	x7, x0, x8
    b3e8:	9b098940 	msub	x0, x10, x9, x2
    b3ec:	aa0a03e1 	mov	x1, x10
    b3f0:	9b0a7ca2 	mul	x2, x5, x10
    b3f4:	93c38000 	extr	x0, x0, x3, #32
    b3f8:	eb00005f 	cmp	x2, x0
    b3fc:	540000a9 	b.ls	b410 <__divti3+0x2e0>  // b.plast
    b400:	ab0000c0 	adds	x0, x6, x0
    b404:	d1000541 	sub	x1, x10, #0x1
    b408:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    b40c:	54000468 	b.hi	b498 <__divti3+0x368>  // b.pmore
    b410:	cb020000 	sub	x0, x0, x2
    b414:	9ac9080a 	udiv	x10, x0, x9
    b418:	9b098140 	msub	x0, x10, x9, x0
    b41c:	aa0a03e2 	mov	x2, x10
    b420:	9b0a7ca8 	mul	x8, x5, x10
    b424:	b3607c03 	bfi	x3, x0, #32, #32
    b428:	eb03011f 	cmp	x8, x3
    b42c:	540000a9 	b.ls	b440 <__divti3+0x310>  // b.plast
    b430:	ab0300c3 	adds	x3, x6, x3
    b434:	d1000542 	sub	x2, x10, #0x1
    b438:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    b43c:	54000288 	b.hi	b48c <__divti3+0x35c>  // b.pmore
    b440:	cb080063 	sub	x3, x3, x8
    b444:	aa018041 	orr	x1, x2, x1, lsl #32
    b448:	17ffffc2 	b	b350 <__divti3+0x220>
    b44c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    b450:	d2800001 	mov	x1, #0x0                   	// #0
    b454:	9a9f87e0 	cset	x0, ls	// ls = plast
    b458:	17ffff68 	b	b1f8 <__divti3+0xc8>
    b45c:	aa0103e0 	mov	x0, x1
    b460:	d2800001 	mov	x1, #0x0                   	// #0
    b464:	17ffff65 	b	b1f8 <__divti3+0xc8>
    b468:	d1000860 	sub	x0, x3, #0x2
    b46c:	8b0600a5 	add	x5, x5, x6
    b470:	17ffff52 	b	b1b8 <__divti3+0x88>
    b474:	d1000961 	sub	x1, x11, #0x2
    b478:	8b0800a5 	add	x5, x5, x8
    b47c:	17ffff85 	b	b290 <__divti3+0x160>
    b480:	d1000965 	sub	x5, x11, #0x2
    b484:	8b080063 	add	x3, x3, x8
    b488:	17ffff8e 	b	b2c0 <__divti3+0x190>
    b48c:	d1000942 	sub	x2, x10, #0x2
    b490:	8b060063 	add	x3, x3, x6
    b494:	17ffffeb 	b	b440 <__divti3+0x310>
    b498:	d1000941 	sub	x1, x10, #0x2
    b49c:	8b060000 	add	x0, x0, x6
    b4a0:	17ffffdc 	b	b410 <__divti3+0x2e0>
    b4a4:	d1000900 	sub	x0, x8, #0x2
    b4a8:	8b060063 	add	x3, x3, x6
    b4ac:	17ffffb4 	b	b37c <__divti3+0x24c>

000000000000b4b0 <__modti3>:
    b4b0:	d503245f 	bti	c
    b4b4:	d2800004 	mov	x4, #0x0                   	// #0
    b4b8:	b6f80081 	tbz	x1, #63, b4c8 <__modti3+0x18>
    b4bc:	eb0003e0 	negs	x0, x0
    b4c0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    b4c4:	da0103e1 	ngc	x1, x1
    b4c8:	f100007f 	cmp	x3, #0x0
    b4cc:	5400128b 	b.lt	b71c <__modti3+0x26c>  // b.tstop
    b4d0:	aa0003e7 	mov	x7, x0
    b4d4:	aa0103e6 	mov	x6, x1
    b4d8:	540004e1 	b.ne	b574 <__modti3+0xc4>  // b.any
    b4dc:	eb02003f 	cmp	x1, x2
    b4e0:	54000dc2 	b.cs	b698 <__modti3+0x1e8>  // b.hs, b.nlast
    b4e4:	dac01043 	clz	x3, x2
    b4e8:	aa0303e5 	mov	x5, x3
    b4ec:	b40000e3 	cbz	x3, b508 <__modti3+0x58>
    b4f0:	4b0303e6 	neg	w6, w3
    b4f4:	9ac32021 	lsl	x1, x1, x3
    b4f8:	9ac32042 	lsl	x2, x2, x3
    b4fc:	9ac62406 	lsr	x6, x0, x6
    b500:	aa0100c6 	orr	x6, x6, x1
    b504:	9ac32007 	lsl	x7, x0, x3
    b508:	d360fc40 	lsr	x0, x2, #32
    b50c:	92407c43 	and	x3, x2, #0xffffffff
    b510:	9ac008c1 	udiv	x1, x6, x0
    b514:	9b009826 	msub	x6, x1, x0, x6
    b518:	9b017c61 	mul	x1, x3, x1
    b51c:	93c780c6 	extr	x6, x6, x7, #32
    b520:	eb06003f 	cmp	x1, x6
    b524:	540000a9 	b.ls	b538 <__modti3+0x88>  // b.plast
    b528:	ab060046 	adds	x6, x2, x6
    b52c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    b530:	8b0200c8 	add	x8, x6, x2
    b534:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    b538:	cb0100c6 	sub	x6, x6, x1
    b53c:	9ac008c8 	udiv	x8, x6, x0
    b540:	9b009901 	msub	x1, x8, x0, x6
    b544:	aa0703e0 	mov	x0, x7
    b548:	9b087c63 	mul	x3, x3, x8
    b54c:	b3607c20 	bfi	x0, x1, #32, #32
    b550:	eb00007f 	cmp	x3, x0
    b554:	54001088 	b.hi	b764 <__modti3+0x2b4>  // b.pmore
    b558:	cb030000 	sub	x0, x0, x3
    b55c:	9ac52400 	lsr	x0, x0, x5
    b560:	d2800001 	mov	x1, #0x0                   	// #0
    b564:	b4000064 	cbz	x4, b570 <__modti3+0xc0>
    b568:	eb0003e0 	negs	x0, x0
    b56c:	da0103e1 	ngc	x1, x1
    b570:	d65f03c0 	ret
    b574:	dac01066 	clz	x6, x3
    b578:	eb03003f 	cmp	x1, x3
    b57c:	54ffff43 	b.cc	b564 <__modti3+0xb4>  // b.lo, b.ul, b.last
    b580:	93407cc5 	sxtw	x5, w6
    b584:	d2800808 	mov	x8, #0x40                  	// #64
    b588:	cb050108 	sub	x8, x8, x5
    b58c:	9ac62063 	lsl	x3, x3, x6
    b590:	9ac62025 	lsl	x5, x1, x6
    b594:	9ac82447 	lsr	x7, x2, x8
    b598:	aa0300e7 	orr	x7, x7, x3
    b59c:	9ac82423 	lsr	x3, x1, x8
    b5a0:	92407cec 	and	x12, x7, #0xffffffff
    b5a4:	d360fcea 	lsr	x10, x7, #32
    b5a8:	9ac82401 	lsr	x1, x0, x8
    b5ac:	aa050021 	orr	x1, x1, x5
    b5b0:	9ac62042 	lsl	x2, x2, x6
    b5b4:	9ac62000 	lsl	x0, x0, x6
    b5b8:	9aca086b 	udiv	x11, x3, x10
    b5bc:	9b0a8d63 	msub	x3, x11, x10, x3
    b5c0:	aa0b03e5 	mov	x5, x11
    b5c4:	9b0b7d89 	mul	x9, x12, x11
    b5c8:	93c18063 	extr	x3, x3, x1, #32
    b5cc:	eb03013f 	cmp	x9, x3
    b5d0:	540000a9 	b.ls	b5e4 <__modti3+0x134>  // b.plast
    b5d4:	ab0300e3 	adds	x3, x7, x3
    b5d8:	d1000565 	sub	x5, x11, #0x1
    b5dc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    b5e0:	54001168 	b.hi	b80c <__modti3+0x35c>  // b.pmore
    b5e4:	cb090063 	sub	x3, x3, x9
    b5e8:	9aca086b 	udiv	x11, x3, x10
    b5ec:	9b0a8d6a 	msub	x10, x11, x10, x3
    b5f0:	aa0b03e9 	mov	x9, x11
    b5f4:	9b0b7d8c 	mul	x12, x12, x11
    b5f8:	b3607d41 	bfi	x1, x10, #32, #32
    b5fc:	eb01019f 	cmp	x12, x1
    b600:	540000a9 	b.ls	b614 <__modti3+0x164>  // b.plast
    b604:	ab0100e1 	adds	x1, x7, x1
    b608:	d1000569 	sub	x9, x11, #0x1
    b60c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    b610:	54000f88 	b.hi	b800 <__modti3+0x350>  // b.pmore
    b614:	aa058123 	orr	x3, x9, x5, lsl #32
    b618:	92407c4b 	and	x11, x2, #0xffffffff
    b61c:	2a0903e9 	mov	w9, w9
    b620:	d360fc4a 	lsr	x10, x2, #32
    b624:	d360fc63 	lsr	x3, x3, #32
    b628:	cb0c0021 	sub	x1, x1, x12
    b62c:	aa0a03ec 	mov	x12, x10
    b630:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    b634:	9b0b7d25 	mul	x5, x9, x11
    b638:	9b0b7c6b 	mul	x11, x3, x11
    b63c:	9b0a2d29 	madd	x9, x9, x10, x11
    b640:	92407caa 	and	x10, x5, #0xffffffff
    b644:	9b0c7c63 	mul	x3, x3, x12
    b648:	8b458125 	add	x5, x9, x5, lsr #32
    b64c:	8b0d0069 	add	x9, x3, x13
    b650:	eb05017f 	cmp	x11, x5
    b654:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    b658:	8b058149 	add	x9, x10, x5, lsl #32
    b65c:	8b458063 	add	x3, x3, x5, lsr #32
    b660:	eb03003f 	cmp	x1, x3
    b664:	54000063 	b.cc	b670 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    b668:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    b66c:	54000082 	b.cs	b67c <__modti3+0x1cc>  // b.hs, b.nlast
    b670:	eb020129 	subs	x9, x9, x2
    b674:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    b678:	cb070063 	sub	x3, x3, x7
    b67c:	eb090000 	subs	x0, x0, x9
    b680:	da030021 	sbc	x1, x1, x3
    b684:	9ac62400 	lsr	x0, x0, x6
    b688:	9ac82028 	lsl	x8, x1, x8
    b68c:	aa000100 	orr	x0, x8, x0
    b690:	9ac62421 	lsr	x1, x1, x6
    b694:	17ffffb4 	b	b564 <__modti3+0xb4>
    b698:	b5000062 	cbnz	x2, b6a4 <__modti3+0x1f4>
    b69c:	d2800023 	mov	x3, #0x1                   	// #1
    b6a0:	9ac20862 	udiv	x2, x3, x2
    b6a4:	dac01048 	clz	x8, x2
    b6a8:	aa0803e5 	mov	x5, x8
    b6ac:	b5000668 	cbnz	x8, b778 <__modti3+0x2c8>
    b6b0:	cb020020 	sub	x0, x1, x2
    b6b4:	d360fc49 	lsr	x9, x2, #32
    b6b8:	92407c4a 	and	x10, x2, #0xffffffff
    b6bc:	9ac90801 	udiv	x1, x0, x9
    b6c0:	9b098020 	msub	x0, x1, x9, x0
    b6c4:	9b0a7c21 	mul	x1, x1, x10
    b6c8:	93c78000 	extr	x0, x0, x7, #32
    b6cc:	eb00003f 	cmp	x1, x0
    b6d0:	540000a9 	b.ls	b6e4 <__modti3+0x234>  // b.plast
    b6d4:	ab000040 	adds	x0, x2, x0
    b6d8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b6dc:	8b020003 	add	x3, x0, x2
    b6e0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b6e4:	cb010001 	sub	x1, x0, x1
    b6e8:	9ac90820 	udiv	x0, x1, x9
    b6ec:	9b098403 	msub	x3, x0, x9, x1
    b6f0:	aa0703e1 	mov	x1, x7
    b6f4:	9b0a7c00 	mul	x0, x0, x10
    b6f8:	b3607c61 	bfi	x1, x3, #32, #32
    b6fc:	eb01001f 	cmp	x0, x1
    b700:	540000a9 	b.ls	b714 <__modti3+0x264>  // b.plast
    b704:	ab010041 	adds	x1, x2, x1
    b708:	8b020022 	add	x2, x1, x2
    b70c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    b710:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    b714:	cb000020 	sub	x0, x1, x0
    b718:	17ffff91 	b	b55c <__modti3+0xac>
    b71c:	eb0203e5 	negs	x5, x2
    b720:	aa0003e7 	mov	x7, x0
    b724:	da0303e8 	ngc	x8, x3
    b728:	aa0503e2 	mov	x2, x5
    b72c:	aa0803e3 	mov	x3, x8
    b730:	aa0103e6 	mov	x6, x1
    b734:	b4ffed48 	cbz	x8, b4dc <__modti3+0x2c>
    b738:	eb01011f 	cmp	x8, x1
    b73c:	54fff148 	b.hi	b564 <__modti3+0xb4>  // b.pmore
    b740:	dac01109 	clz	x9, x8
    b744:	2a0903e6 	mov	w6, w9
    b748:	b5fff1c9 	cbnz	x9, b580 <__modti3+0xd0>
    b74c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b750:	54000068 	b.hi	b75c <__modti3+0x2ac>  // b.pmore
    b754:	eb050007 	subs	x7, x0, x5
    b758:	da080021 	sbc	x1, x1, x8
    b75c:	aa0703e0 	mov	x0, x7
    b760:	17ffff81 	b	b564 <__modti3+0xb4>
    b764:	ab000040 	adds	x0, x2, x0
    b768:	8b020002 	add	x2, x0, x2
    b76c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b770:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b774:	17ffff79 	b	b558 <__modti3+0xa8>
    b778:	9ac82042 	lsl	x2, x2, x8
    b77c:	d2800803 	mov	x3, #0x40                  	// #64
    b780:	cb080063 	sub	x3, x3, x8
    b784:	d360fc49 	lsr	x9, x2, #32
    b788:	9ac82027 	lsl	x7, x1, x8
    b78c:	92407c4a 	and	x10, x2, #0xffffffff
    b790:	9ac32426 	lsr	x6, x1, x3
    b794:	9ac32403 	lsr	x3, x0, x3
    b798:	aa070063 	orr	x3, x3, x7
    b79c:	9ac908c1 	udiv	x1, x6, x9
    b7a0:	9ac82007 	lsl	x7, x0, x8
    b7a4:	9b099820 	msub	x0, x1, x9, x6
    b7a8:	9b017d41 	mul	x1, x10, x1
    b7ac:	93c38000 	extr	x0, x0, x3, #32
    b7b0:	eb00003f 	cmp	x1, x0
    b7b4:	540000a9 	b.ls	b7c8 <__modti3+0x318>  // b.plast
    b7b8:	ab000040 	adds	x0, x2, x0
    b7bc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b7c0:	8b020006 	add	x6, x0, x2
    b7c4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b7c8:	cb010000 	sub	x0, x0, x1
    b7cc:	9ac90801 	udiv	x1, x0, x9
    b7d0:	9b098026 	msub	x6, x1, x9, x0
    b7d4:	aa0303e0 	mov	x0, x3
    b7d8:	9b017d41 	mul	x1, x10, x1
    b7dc:	b3607cc0 	bfi	x0, x6, #32, #32
    b7e0:	eb00003f 	cmp	x1, x0
    b7e4:	540000a9 	b.ls	b7f8 <__modti3+0x348>  // b.plast
    b7e8:	ab000040 	adds	x0, x2, x0
    b7ec:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b7f0:	8b020003 	add	x3, x0, x2
    b7f4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b7f8:	cb010000 	sub	x0, x0, x1
    b7fc:	17ffffb0 	b	b6bc <__modti3+0x20c>
    b800:	d1000969 	sub	x9, x11, #0x2
    b804:	8b070021 	add	x1, x1, x7
    b808:	17ffff83 	b	b614 <__modti3+0x164>
    b80c:	d1000965 	sub	x5, x11, #0x2
    b810:	8b070063 	add	x3, x3, x7
    b814:	17ffff74 	b	b5e4 <__modti3+0x134>
    b818:	d503201f 	nop
    b81c:	d503201f 	nop

000000000000b820 <atexit>:
    b820:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b824:	b00000a2 	adrp	x2, 20000 <__data_start>
    b828:	d2800001 	mov	x1, #0x0                   	// #0
    b82c:	910003fd 	mov	x29, sp
    b830:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b834:	f9400442 	ldr	x2, [x2, #8]
    b838:	17ffdbae 	b	26f0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b83c <_fini>:
    b83c:	d503201f 	nop
    b840:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b844:	910003fd 	mov	x29, sp
    b848:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b84c:	d65f03c0 	ret
