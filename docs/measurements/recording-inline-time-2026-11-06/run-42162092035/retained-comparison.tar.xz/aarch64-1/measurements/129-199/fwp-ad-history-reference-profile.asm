
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	f0000045 	adrp	x5, d000 <fwp_main_thread+0x2d0>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	9135a0a5 	add	x5, x5, #0xd68
    2a20:	f0000044 	adrp	x4, d000 <fwp_main_thread+0x2d0>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	9135c084 	add	x4, x4, #0xd70
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	9400034c 	bl	3780 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91018261 	add	x1, x19, #0x60
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe108>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9006820 	str	x0, [x1, #208]
    2aac:	94000395 	bl	3900 <fwp_now_ns>
    2ab0:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    2ab4:	910ae000 	add	x0, x0, #0x2b8
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	d0000042 	adrp	x2, c000 <f0+0x193c>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	9134c042 	add	x2, x2, #0xd30
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91018273 	add	x19, x19, #0x60
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943da60 	ldr	w0, [x19, #984]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff4c 	bl	2900 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    2bfc:	910b2000 	add	x0, x0, #0x2c8
    2c00:	940002e0 	bl	3780 <fwp_trap>
    2c04:	97ffff03 	bl	2810 <__stack_chk_fail@plt>
    2c08:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    2c0c:	910da000 	add	x0, x0, #0x368
    2c10:	940002dc 	bl	3780 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffeea 	bl	27c0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    2c24:	910d0000 	add	x0, x0, #0x340
    2c28:	940002d6 	bl	3780 <fwp_trap>
    2c2c:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    2c30:	910c4000 	add	x0, x0, #0x310
    2c34:	940002d3 	bl	3780 <fwp_trap>
    2c38:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    2c3c:	910ba000 	add	x0, x0, #0x2e8
    2c40:	940002d0 	bl	3780 <fwp_trap>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91012000 	add	x0, x0, #0x48
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91012021 	add	x1, x1, #0x48
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91012000 	add	x0, x0, #0x48
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91012021 	add	x1, x1, #0x48
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39414260 	ldrb	w0, [x19, #80]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39014260 	strb	w0, [x19, #80]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    2e34:	91268021 	add	x1, x1, #0x9a0
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f18:	910180e6 	add	x6, x7, #0x60
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910180e1 	add	x1, x7, #0x60
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9407484 	ldr	x4, [x4, #232]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9407463 	ldr	x3, [x3, #232]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff8:	f9407800 	ldr	x0, [x0, #240]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b00000e2 	adrp	x2, 20000 <__data_start>
    3038:	91018043 	add	x3, x2, #0x60
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91018042 	add	x2, x2, #0x60
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    30d8:	91260021 	add	x1, x1, #0x980
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    3110:	91286000 	add	x0, x0, #0xa18
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    3144:	911902a1 	add	x1, x21, #0x640
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    3158:	9128c0a5 	add	x5, x5, #0xa30
    315c:	911902a1 	add	x1, x21, #0x640
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911902b7 	add	x23, x21, #0x640
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911902b5 	add	x21, x21, #0x640
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911902b5 	add	x21, x21, #0x640
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9c0>
    32e8:	9128a0a5 	add	x5, x5, #0xa28
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x2d0>
    331c:	9128c042 	add	x2, x2, #0xa30
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3350:	91018315 	add	x21, x24, #0x60
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x2d0>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	912a2042 	add	x2, x2, #0xa88
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	d0000059 	adrp	x25, d000 <fwp_main_thread+0x2d0>
    33a8:	d000005a 	adrp	x26, d000 <fwp_main_thread+0x2d0>
    33ac:	912ba339 	add	x25, x25, #0xae8
    33b0:	9129435a 	add	x26, x26, #0xa50
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b00000e0 	adrp	x0, 20000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	d000005b 	adrp	x27, d000 <fwp_main_thread+0x2d0>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	91296377 	add	x23, x27, #0xa58
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	912ca000 	add	x0, x0, #0xb28
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b0000161 	adrp	x1, 30000 <alt.5+0xfba0>
    3474:	b0000165 	adrp	x5, 30000 <alt.5+0xfba0>
    3478:	b0000162 	adrp	x2, 30000 <alt.5+0xfba0>
    347c:	d0000043 	adrp	x3, d000 <fwp_main_thread+0x2d0>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	d0000055 	adrp	x21, d000 <fwp_main_thread+0x2d0>
    3488:	f9423024 	ldr	x4, [x1, #1120]
    348c:	91018318 	add	x24, x24, #0x60
    3490:	f94234a5 	ldr	x5, [x5, #1128]
    3494:	91118033 	add	x19, x1, #0x460
    3498:	f9423846 	ldr	x6, [x2, #1136]
    349c:	91294063 	add	x3, x3, #0xa50
    34a0:	912d02b5 	add	x21, x21, #0xb40
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	912e0000 	add	x0, x0, #0xb80
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    352c:	91298000 	add	x0, x0, #0xa60
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    35ec:	91286000 	add	x0, x0, #0xa18
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b00000e1 	adrp	x1, 20000 <__data_start>
    3674:	91018022 	add	x2, x1, #0x60
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91018021 	add	x1, x1, #0x60
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x2d0>
    3730:	aa1303e0 	mov	x0, x19
    3734:	912e2021 	add	x1, x1, #0xb88
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x2d0>
    3744:	aa1303e0 	mov	x0, x19
    3748:	912e4021 	add	x1, x1, #0xb90
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x2d0>
    3760:	912e6021 	add	x1, x1, #0xb98
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_trap>:
    3780:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3784:	d53bd041 	mrs	x1, tpidr_el0
    3788:	91400021 	add	x1, x1, #0x0, lsl #12
    378c:	91004021 	add	x1, x1, #0x10
    3790:	910003fd 	mov	x29, sp
    3794:	a90153f3 	stp	x19, x20, [sp, #16]
    3798:	aa0003f3 	mov	x19, x0
    379c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    37a0:	f947ea94 	ldr	x20, [x20, #4048]
    37a4:	f90013f5 	str	x21, [sp, #32]
    37a8:	f9400035 	ldr	x21, [x1]
    37ac:	97fffe12 	bl	2ff4 <fwp_flush>
    37b0:	f9400280 	ldr	x0, [x20]
    37b4:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x2d0>
    37b8:	aa1303e3 	mov	x3, x19
    37bc:	912e8042 	add	x2, x2, #0xba0
    37c0:	52800041 	mov	w1, #0x2                   	// #2
    37c4:	97fffc2f 	bl	2880 <__fprintf_chk@plt>
    37c8:	b40000b5 	cbz	x21, 37dc <fwp_trap+0x5c>
    37cc:	f9400280 	ldr	x0, [x20]
    37d0:	97fffc5c 	bl	2940 <fflush@plt>
    37d4:	52800ca0 	mov	w0, #0x65                  	// #101
    37d8:	97fffc6a 	bl	2980 <_Exit@plt>
    37dc:	52800ca0 	mov	w0, #0x65                  	// #101
    37e0:	97fffbb8 	bl	26c0 <exit@plt>

00000000000037e4 <fwp_closure_drop_push>:
    37e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    37e8:	910003fd 	mov	x29, sp
    37ec:	a90153f3 	stp	x19, x20, [sp, #16]
    37f0:	aa0003f3 	mov	x19, x0
    37f4:	a9408014 	ldp	x20, x0, [x0, #8]
    37f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    37fc:	aa0103f5 	mov	x21, x1
    3800:	a90363f7 	stp	x23, x24, [sp, #48]
    3804:	eb00029f 	cmp	x20, x0
    3808:	54000160 	b.eq	3834 <fwp_closure_drop_push+0x50>  // b.none
    380c:	f9400276 	ldr	x22, [x19]
    3810:	d37df297 	lsl	x23, x20, #3
    3814:	91000694 	add	x20, x20, #0x1
    3818:	f9000674 	str	x20, [x19, #8]
    381c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3820:	f8376ad5 	str	x21, [x22, x23]
    3824:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3828:	a94363f7 	ldp	x23, x24, [sp, #48]
    382c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3830:	d65f03c0 	ret
    3834:	a9046bf9 	stp	x25, x26, [sp, #64]
    3838:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    383c:	eb00029f 	cmp	x20, x0
    3840:	54000568 	b.hi	38ec <fwp_closure_drop_push+0x108>  // b.pmore
    3844:	d37cee99 	lsl	x25, x20, #4
    3848:	d37ffa9a 	lsl	x26, x20, #1
    384c:	aa1903e0 	mov	x0, x25
    3850:	97fffbd8 	bl	27b0 <malloc@plt>
    3854:	aa0003f6 	mov	x22, x0
    3858:	b4000320 	cbz	x0, 38bc <fwp_closure_drop_push+0xd8>
    385c:	aa1303f8 	mov	x24, x19
    3860:	aa1903e3 	mov	x3, x25
    3864:	d37df297 	lsl	x23, x20, #3
    3868:	aa1703e2 	mov	x2, x23
    386c:	f8418719 	ldr	x25, [x24], #24
    3870:	aa1903e1 	mov	x1, x25
    3874:	97fffbbb 	bl	2760 <__memcpy_chk@plt>
    3878:	eb18033f 	cmp	x25, x24
    387c:	540000a0 	b.eq	3890 <fwp_closure_drop_push+0xac>  // b.none
    3880:	aa1903e0 	mov	x0, x25
    3884:	97fffc13 	bl	28d0 <free@plt>
    3888:	f9400674 	ldr	x20, [x19, #8]
    388c:	d37df297 	lsl	x23, x20, #3
    3890:	91000694 	add	x20, x20, #0x1
    3894:	f9000276 	str	x22, [x19]
    3898:	f9000a7a 	str	x26, [x19, #16]
    389c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    38a0:	f9000674 	str	x20, [x19, #8]
    38a4:	f8376ad5 	str	x21, [x22, x23]
    38a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    38ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    38b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b8:	d65f03c0 	ret
    38bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    38c0:	f947e863 	ldr	x3, [x3, #4048]
    38c4:	d2800262 	mov	x2, #0x13                  	// #19
    38c8:	d2800021 	mov	x1, #0x1                   	// #1
    38cc:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    38d0:	91286000 	add	x0, x0, #0xa18
    38d4:	f9400063 	ldr	x3, [x3]
    38d8:	97fffc0e 	bl	2910 <fwrite@plt>
    38dc:	d2800000 	mov	x0, #0x0                   	// #0
    38e0:	97fffc18 	bl	2940 <fflush@plt>
    38e4:	52800cc0 	mov	w0, #0x66                  	// #102
    38e8:	97fffc26 	bl	2980 <_Exit@plt>
    38ec:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    38f0:	912ec000 	add	x0, x0, #0xbb0
    38f4:	97ffffa3 	bl	3780 <fwp_trap>
    38f8:	d503201f 	nop
    38fc:	d503201f 	nop

0000000000003900 <fwp_now_ns>:
    3900:	d100c3ff 	sub	sp, sp, #0x30
    3904:	52800020 	mov	w0, #0x1                   	// #1
    3908:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    390c:	f947f442 	ldr	x2, [x2, #4072]
    3910:	910023e1 	add	x1, sp, #0x8
    3914:	a9027bfd 	stp	x29, x30, [sp, #32]
    3918:	910083fd 	add	x29, sp, #0x20
    391c:	f9400043 	ldr	x3, [x2]
    3920:	f9000fe3 	str	x3, [sp, #24]
    3924:	d2800003 	mov	x3, #0x0                   	// #0
    3928:	97fffb86 	bl	2740 <clock_gettime@plt>
    392c:	350002c0 	cbnz	w0, 3984 <fwp_now_ns+0x84>
    3930:	a9408be1 	ldp	x1, x2, [sp, #8]
    3934:	d2994003 	mov	x3, #0xca00                	// #51712
    3938:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    393c:	9b037c20 	mul	x0, x1, x3
    3940:	9b437c21 	smulh	x1, x1, x3
    3944:	ab020000 	adds	x0, x0, x2
    3948:	937ffc42 	asr	x2, x2, #63
    394c:	9a020021 	adc	x1, x1, x2
    3950:	f100001f 	cmp	x0, #0x0
    3954:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3958:	b50001e1 	cbnz	x1, 3994 <fwp_now_ns+0x94>
    395c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3960:	f947f421 	ldr	x1, [x1, #4072]
    3964:	f9400fe3 	ldr	x3, [sp, #24]
    3968:	f9400022 	ldr	x2, [x1]
    396c:	eb020063 	subs	x3, x3, x2
    3970:	d2800002 	mov	x2, #0x0                   	// #0
    3974:	540000e1 	b.ne	3990 <fwp_now_ns+0x90>  // b.any
    3978:	a9427bfd 	ldp	x29, x30, [sp, #32]
    397c:	9100c3ff 	add	sp, sp, #0x30
    3980:	d65f03c0 	ret
    3984:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    3988:	912f4000 	add	x0, x0, #0xbd0
    398c:	97ffff7d 	bl	3780 <fwp_trap>
    3990:	97fffba0 	bl	2810 <__stack_chk_fail@plt>
    3994:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    3998:	912fc000 	add	x0, x0, #0xbf0
    399c:	97ffff79 	bl	3780 <fwp_trap>

00000000000039a0 <fwp_closure_drop.part.0>:
    39a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39a4:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    39a8:	910003fd 	mov	x29, sp
    39ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    39b0:	f947f463 	ldr	x3, [x3, #4072]
    39b4:	a90153f3 	stp	x19, x20, [sp, #16]
    39b8:	d10883ff 	sub	sp, sp, #0x220
    39bc:	910003e2 	mov	x2, sp
    39c0:	d53bd053 	mrs	x19, tpidr_el0
    39c4:	910063f4 	add	x20, sp, #0x18
    39c8:	3dc26c20 	ldr	q0, [x1, #2480]
    39cc:	91400264 	add	x4, x19, #0x0, lsl #12
    39d0:	91004084 	add	x4, x4, #0x10
    39d4:	aa0003e1 	mov	x1, x0
    39d8:	aa0203e0 	mov	x0, x2
    39dc:	f9400062 	ldr	x2, [x3]
    39e0:	f9010fe2 	str	x2, [sp, #536]
    39e4:	d2800002 	mov	x2, #0x0                   	// #0
    39e8:	f90003f4 	str	x20, [sp]
    39ec:	f9000080 	str	x0, [x4]
    39f0:	3c8083e0 	stur	q0, [sp, #8]
    39f4:	97ffff7c 	bl	37e4 <fwp_closure_drop_push>
    39f8:	f94007e0 	ldr	x0, [sp, #8]
    39fc:	b4000280 	cbz	x0, 3a4c <fwp_closure_drop.part.0+0xac>
    3a00:	f90123f5 	str	x21, [sp, #576]
    3a04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a08:	910182b5 	add	x21, x21, #0x60
    3a0c:	d503201f 	nop
    3a10:	f94003e1 	ldr	x1, [sp]
    3a14:	d1000400 	sub	x0, x0, #0x1
    3a18:	f90007e0 	str	x0, [sp, #8]
    3a1c:	f9406aa2 	ldr	x2, [x21, #208]
    3a20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3a24:	b9400001 	ldr	w1, [x0]
    3a28:	8b011441 	add	x1, x2, x1, lsl #5
    3a2c:	f9400c21 	ldr	x1, [x1, #24]
    3a30:	b4000321 	cbz	x1, 3a94 <fwp_closure_drop.part.0+0xf4>
    3a34:	f9400422 	ldr	x2, [x1, #8]
    3a38:	52800001 	mov	w1, #0x0                   	// #0
    3a3c:	d63f0040 	blr	x2
    3a40:	f94007e0 	ldr	x0, [sp, #8]
    3a44:	b5fffe60 	cbnz	x0, 3a10 <fwp_closure_drop.part.0+0x70>
    3a48:	f94123f5 	ldr	x21, [sp, #576]
    3a4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3a50:	91004273 	add	x19, x19, #0x10
    3a54:	f94003e0 	ldr	x0, [sp]
    3a58:	f900027f 	str	xzr, [x19]
    3a5c:	eb14001f 	cmp	x0, x20
    3a60:	54000040 	b.eq	3a68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3a64:	97fffb9b 	bl	28d0 <free@plt>
    3a68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3a6c:	f947f400 	ldr	x0, [x0, #4072]
    3a70:	f9410fe2 	ldr	x2, [sp, #536]
    3a74:	f9400001 	ldr	x1, [x0]
    3a78:	eb010042 	subs	x2, x2, x1
    3a7c:	d2800001 	mov	x1, #0x0                   	// #0
    3a80:	54000101 	b.ne	3aa0 <fwp_closure_drop.part.0+0x100>  // b.any
    3a84:	910883ff 	add	sp, sp, #0x220
    3a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a90:	d65f03c0 	ret
    3a94:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    3a98:	91306000 	add	x0, x0, #0xc18
    3a9c:	97ffff39 	bl	3780 <fwp_trap>
    3aa0:	f90123f5 	str	x21, [sp, #576]
    3aa4:	97fffb5b 	bl	2810 <__stack_chk_fail@plt>
    3aa8:	d503201f 	nop
    3aac:	d503201f 	nop

0000000000003ab0 <fwp_tape_of>:
    3ab0:	92403c02 	and	x2, x0, #0xffff
    3ab4:	b4000262 	cbz	x2, 3b00 <fwp_tape_of+0x50>
    3ab8:	b00000e3 	adrp	x3, 20000 <__data_start>
    3abc:	91018063 	add	x3, x3, #0x60
    3ac0:	9350fc01 	asr	x1, x0, #16
    3ac4:	d1000440 	sub	x0, x2, #0x1
    3ac8:	f9406c62 	ldr	x2, [x3, #216]
    3acc:	eb00005f 	cmp	x2, x0
    3ad0:	5400018d 	b.le	3b00 <fwp_tape_of+0x50>
    3ad4:	8b000402 	add	x2, x0, x0, lsl #1
    3ad8:	f9404463 	ldr	x3, [x3, #136]
    3adc:	8b020802 	add	x2, x0, x2, lsl #2
    3ae0:	d37df042 	lsl	x2, x2, #3
    3ae4:	8b020060 	add	x0, x3, x2
    3ae8:	b9400404 	ldr	w4, [x0, #4]
    3aec:	340000a4 	cbz	w4, 3b00 <fwp_tape_of+0x50>
    3af0:	b8626862 	ldr	w2, [x3, x2]
    3af4:	6b01005f 	cmp	w2, w1
    3af8:	54000041 	b.ne	3b00 <fwp_tape_of+0x50>  // b.any
    3afc:	d65f03c0 	ret
    3b00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b04:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    3b08:	91312000 	add	x0, x0, #0xc48
    3b0c:	910003fd 	mov	x29, sp
    3b10:	97ffff1c 	bl	3780 <fwp_trap>

0000000000003b14 <fwp_format_g.constprop.0>:
    3b14:	d10483ff 	sub	sp, sp, #0x120
    3b18:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x2d0>
    3b1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    3b20:	f947f442 	ldr	x2, [x2, #4072]
    3b24:	91326084 	add	x4, x4, #0xc98
    3b28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3b2c:	9102c3fd 	add	x29, sp, #0xb0
    3b30:	d2800803 	mov	x3, #0x40                  	// #64
    3b34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3b38:	93407c38 	sxtw	x24, w1
    3b3c:	aa0303e1 	mov	x1, x3
    3b40:	fd008be8 	str	d8, [sp, #272]
    3b44:	1e604008 	fmov	d8, d0
    3b48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3b4c:	910083f4 	add	x20, sp, #0x20
    3b50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3b54:	aa0003f5 	mov	x21, x0
    3b58:	a91073fb 	stp	x27, x28, [sp, #256]
    3b5c:	5100071c 	sub	w28, w24, #0x1
    3b60:	2a1c03e5 	mov	w5, w28
    3b64:	f9400040 	ldr	x0, [x2]
    3b68:	f90057e0 	str	x0, [sp, #168]
    3b6c:	d2800000 	mov	x0, #0x0                   	// #0
    3b70:	52800042 	mov	w2, #0x2                   	// #2
    3b74:	aa1403e0 	mov	x0, x20
    3b78:	97fffb02 	bl	2780 <__snprintf_chk@plt>
    3b7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3b80:	aa1403e0 	mov	x0, x20
    3b84:	97fffb5b 	bl	28f0 <strchr@plt>
    3b88:	aa0003f3 	mov	x19, x0
    3b8c:	52800142 	mov	w2, #0xa                   	// #10
    3b90:	91000400 	add	x0, x0, #0x1
    3b94:	d2800001 	mov	x1, #0x0                   	// #0
    3b98:	97fffb46 	bl	28b0 <strtol@plt>
    3b9c:	aa0003f7 	mov	x23, x0
    3ba0:	11001400 	add	w0, w0, #0x5
    3ba4:	7100541f 	cmp	w0, #0x15
    3ba8:	54000d88 	b.hi	3d58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3bac:	4b170385 	sub	w5, w28, w23
    3bb0:	710000bf 	cmp	w5, #0x0
    3bb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3bb8:	54000ba0 	b.eq	3d2c <fwp_format_g.constprop.0+0x218>  // b.none
    3bbc:	394083e0 	ldrb	w0, [sp, #32]
    3bc0:	cb180273 	sub	x19, x19, x24
    3bc4:	91000673 	add	x19, x19, #0x1
    3bc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3bcc:	7100b41f 	cmp	w0, #0x2d
    3bd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3bd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3bd8:	cb010266 	sub	x6, x19, x1
    3bdc:	d10004da 	sub	x26, x6, #0x1
    3be0:	540018c0 	b.eq	3ef8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d280091b 	mov	x27, #0x48                  	// #72
    3bec:	aa1903e7 	mov	x7, x25
    3bf0:	91000423 	add	x3, x1, #0x1
    3bf4:	91011cc6 	add	x6, x6, #0x47
    3bf8:	910004f6 	add	x22, x7, #0x1
    3bfc:	37f81017 	tbnz	w23, #31, 3dfc <fwp_format_g.constprop.0+0x2e8>
    3c00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c04:	93407ef7 	sxtw	x23, w23
    3c08:	390000e4 	strb	w4, [x7]
    3c0c:	aa1303e1 	mov	x1, x19
    3c10:	aa1703e2 	mov	x2, x23
    3c14:	aa1603e0 	mov	x0, x22
    3c18:	b9000be5 	str	w5, [sp, #8]
    3c1c:	cb170374 	sub	x20, x27, x23
    3c20:	a9011be3 	stp	x3, x6, [sp, #16]
    3c24:	97fffa8f 	bl	2660 <memcpy@plt>
    3c28:	d1000694 	sub	x20, x20, #0x1
    3c2c:	f9400be3 	ldr	x3, [sp, #16]
    3c30:	8b1702d6 	add	x22, x22, x23
    3c34:	aa1603e0 	mov	x0, x22
    3c38:	aa1a03e2 	mov	x2, x26
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	aa1403e3 	mov	x3, x20
    3c44:	97fffac7 	bl	2760 <__memcpy_chk@plt>
    3c48:	8b1a02d6 	add	x22, x22, x26
    3c4c:	f9400fe6 	ldr	x6, [sp, #24]
    3c50:	d2800900 	mov	x0, #0x48                  	// #72
    3c54:	b9400be5 	ldr	w5, [sp, #8]
    3c58:	8b170261 	add	x1, x19, x23
    3c5c:	cb1400c3 	sub	x3, x6, x20
    3c60:	cb060294 	sub	x20, x20, x6
    3c64:	f101207f 	cmp	x3, #0x48
    3c68:	93407cb8 	sxtw	x24, w5
    3c6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c70:	aa1803e2 	mov	x2, x24
    3c74:	8b1802d3 	add	x19, x22, x24
    3c78:	8b140063 	add	x3, x3, x20
    3c7c:	aa1603e0 	mov	x0, x22
    3c80:	97fffab8 	bl	2760 <__memcpy_chk@plt>
    3c84:	cb190273 	sub	x19, x19, x25
    3c88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3c8c:	eb00027f 	cmp	x19, x0
    3c90:	aa1903e1 	mov	x1, x25
    3c94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3c98:	aa1503e0 	mov	x0, x21
    3c9c:	aa1303e2 	mov	x2, x19
    3ca0:	97fffa70 	bl	2660 <memcpy@plt>
    3ca4:	38336abf 	strb	wzr, [x21, x19]
    3ca8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3cac:	aa1503e0 	mov	x0, x21
    3cb0:	97fffa7c 	bl	26a0 <strlen@plt>
    3cb4:	aa0003f3 	mov	x19, x0
    3cb8:	528005c1 	mov	w1, #0x2e                  	// #46
    3cbc:	aa1503e0 	mov	x0, x21
    3cc0:	97fffb0c 	bl	28f0 <strchr@plt>
    3cc4:	b4000160 	cbz	x0, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3cc8:	b4000153 	cbz	x19, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ccc:	d503201f 	nop
    3cd0:	aa1303e1 	mov	x1, x19
    3cd4:	d1000673 	sub	x19, x19, #0x1
    3cd8:	38736aa0 	ldrb	w0, [x21, x19]
    3cdc:	7100c01f 	cmp	w0, #0x30
    3ce0:	54001001 	b.ne	3ee0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ce4:	38336abf 	strb	wzr, [x21, x19]
    3ce8:	b5ffff53 	cbnz	x19, 3cd0 <fwp_format_g.constprop.0+0x1bc>
    3cec:	d503201f 	nop
    3cf0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3cf4:	f947f400 	ldr	x0, [x0, #4072]
    3cf8:	f94057e2 	ldr	x2, [sp, #168]
    3cfc:	f9400001 	ldr	x1, [x0]
    3d00:	eb010042 	subs	x2, x2, x1
    3d04:	d2800001 	mov	x1, #0x0                   	// #0
    3d08:	54001061 	b.ne	3f14 <fwp_format_g.constprop.0+0x400>  // b.any
    3d0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3d20:	fd408be8 	ldr	d8, [sp, #272]
    3d24:	910483ff 	add	sp, sp, #0x120
    3d28:	d65f03c0 	ret
    3d2c:	1e604100 	fmov	d0, d8
    3d30:	710000bf 	cmp	w5, #0x0
    3d34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3d38:	aa1503e0 	mov	x0, x21
    3d3c:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x2d0>
    3d40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3d44:	9132c084 	add	x4, x4, #0xcb0
    3d48:	52800042 	mov	w2, #0x2                   	// #2
    3d4c:	d2803201 	mov	x1, #0x190                 	// #400
    3d50:	97fffa8c 	bl	2780 <__snprintf_chk@plt>
    3d54:	17ffffd6 	b	3cac <fwp_format_g.constprop.0+0x198>
    3d58:	cb140273 	sub	x19, x19, x20
    3d5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d60:	910183f9 	add	x25, sp, #0x60
    3d64:	aa1303e2 	mov	x2, x19
    3d68:	aa1403e1 	mov	x1, x20
    3d6c:	aa1903e0 	mov	x0, x25
    3d70:	d2800803 	mov	x3, #0x40                  	// #64
    3d74:	97fffa7b 	bl	2760 <__memcpy_chk@plt>
    3d78:	38336b3f 	strb	wzr, [x25, x19]
    3d7c:	aa1903e0 	mov	x0, x25
    3d80:	528005c1 	mov	w1, #0x2e                  	// #46
    3d84:	97fffadb 	bl	28f0 <strchr@plt>
    3d88:	b40001c0 	cbz	x0, 3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d8c:	b50000b3 	cbnz	x19, 3da0 <fwp_format_g.constprop.0+0x28c>
    3d90:	1400000c 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d94:	381ff01f 	sturb	wzr, [x0, #-1]
    3d98:	f1000673 	subs	x19, x19, #0x1
    3d9c:	54000120 	b.eq	3dc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3da0:	8b130320 	add	x0, x25, x19
    3da4:	385ff001 	ldurb	w1, [x0, #-1]
    3da8:	7100c03f 	cmp	w1, #0x30
    3dac:	54ffff40 	b.eq	3d94 <fwp_format_g.constprop.0+0x280>  // b.none
    3db0:	d1000673 	sub	x19, x19, #0x1
    3db4:	38736b20 	ldrb	w0, [x25, x19]
    3db8:	7100b81f 	cmp	w0, #0x2e
    3dbc:	54000a80 	b.eq	3f0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3dc0:	710002ff 	cmp	w23, #0x0
    3dc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3dc8:	aa1903e5 	mov	x5, x25
    3dcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3dd0:	aa1503e0 	mov	x0, x21
    3dd4:	52800566 	mov	w6, #0x2b                  	// #43
    3dd8:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x2d0>
    3ddc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3de0:	91328084 	add	x4, x4, #0xca0
    3de4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3de8:	52800042 	mov	w2, #0x2                   	// #2
    3dec:	d2803201 	mov	x1, #0x190                 	// #400
    3df0:	97fffa64 	bl	2780 <__snprintf_chk@plt>
    3df4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3df8:	17ffffbe 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3dfc:	52800605 	mov	w5, #0x30                  	// #48
    3e00:	390000e5 	strb	w5, [x7]
    3e04:	d100077b 	sub	x27, x27, #0x1
    3e08:	aa0303e1 	mov	x1, x3
    3e0c:	aa1603e0 	mov	x0, x22
    3e10:	aa1b03e3 	mov	x3, x27
    3e14:	aa1a03e2 	mov	x2, x26
    3e18:	f90007e6 	str	x6, [sp, #8]
    3e1c:	b90013e4 	str	w4, [sp, #16]
    3e20:	8b1a02d6 	add	x22, x22, x26
    3e24:	b9001be5 	str	w5, [sp, #24]
    3e28:	97fffa4e 	bl	2760 <__memcpy_chk@plt>
    3e2c:	f94007e6 	ldr	x6, [sp, #8]
    3e30:	2a3703e7 	mvn	w7, w23
    3e34:	b94013e4 	ldr	w4, [sp, #16]
    3e38:	cb1b00c1 	sub	x1, x6, x27
    3e3c:	cb06037b 	sub	x27, x27, x6
    3e40:	f101203f 	cmp	x1, #0x48
    3e44:	d2800906 	mov	x6, #0x48                  	// #72
    3e48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3e4c:	8b1b0023 	add	x3, x1, x27
    3e50:	310006ff 	cmn	w23, #0x1
    3e54:	54000220 	b.eq	3e98 <fwp_format_g.constprop.0+0x384>  // b.none
    3e58:	b9401be5 	ldr	w5, [sp, #24]
    3e5c:	d2800001 	mov	x1, #0x0                   	// #0
    3e60:	f101207f 	cmp	x3, #0x48
    3e64:	d1000462 	sub	x2, x3, #0x1
    3e68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3e6c:	38216ac5 	strb	w5, [x22, x1]
    3e70:	cb030003 	sub	x3, x0, x3
    3e74:	91000421 	add	x1, x1, #0x1
    3e78:	91000463 	add	x3, x3, #0x1
    3e7c:	eb00007f 	cmp	x3, x0
    3e80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3e84:	cb000063 	sub	x3, x3, x0
    3e88:	8b020063 	add	x3, x3, x2
    3e8c:	6b0100ff 	cmp	w7, w1
    3e90:	54fffe8c 	b.gt	3e60 <fwp_format_g.constprop.0+0x34c>
    3e94:	8b2742d6 	add	x22, x22, w7, uxtw
    3e98:	f101207f 	cmp	x3, #0x48
    3e9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ea0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ea4:	aa1603e0 	mov	x0, x22
    3ea8:	cb0300a1 	sub	x1, x5, x3
    3eac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3eb0:	91000421 	add	x1, x1, #0x1
    3eb4:	d1000463 	sub	x3, x3, #0x1
    3eb8:	eb05003f 	cmp	x1, x5
    3ebc:	38001402 	strb	w2, [x0], #1
    3ec0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3ec4:	93407f82 	sxtw	x2, w28
    3ec8:	cb050025 	sub	x5, x1, x5
    3ecc:	aa1303e1 	mov	x1, x19
    3ed0:	8b0300a3 	add	x3, x5, x3
    3ed4:	8b1802d3 	add	x19, x22, x24
    3ed8:	97fffa22 	bl	2760 <__memcpy_chk@plt>
    3edc:	17ffff6a 	b	3c84 <fwp_format_g.constprop.0+0x170>
    3ee0:	d1000421 	sub	x1, x1, #0x1
    3ee4:	38616aa0 	ldrb	w0, [x21, x1]
    3ee8:	7100b81f 	cmp	w0, #0x2e
    3eec:	54fff021 	b.ne	3cf0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ef0:	38216abf 	strb	wzr, [x21, x1]
    3ef4:	17ffff7f 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ef8:	910187e7 	add	x7, sp, #0x61
    3efc:	910183f9 	add	x25, sp, #0x60
    3f00:	d28008fb 	mov	x27, #0x47                  	// #71
    3f04:	390183e0 	strb	w0, [sp, #96]
    3f08:	17ffff3a 	b	3bf0 <fwp_format_g.constprop.0+0xdc>
    3f0c:	38336b3f 	strb	wzr, [x25, x19]
    3f10:	17ffffac 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3f14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f18:	97fffa3e 	bl	2810 <__stack_chk_fail@plt>
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_heap_report>:
    3f20:	d105c3ff 	sub	sp, sp, #0x170
    3f24:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    3f28:	91190042 	add	x2, x2, #0x640
    3f2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3f30:	f947e821 	ldr	x1, [x1, #4048]
    3f34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3f38:	910443fd 	add	x29, sp, #0x110
    3f3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3f40:	f947f400 	ldr	x0, [x0, #4072]
    3f44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3f48:	a91463f7 	stp	x23, x24, [sp, #320]
    3f4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3f50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3f54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3f58:	fd4a2049 	ldr	d9, [x2, #5184]
    3f5c:	f9400036 	ldr	x22, [x1]
    3f60:	f9400001 	ldr	x1, [x0]
    3f64:	f90087e1 	str	x1, [sp, #264]
    3f68:	d2800001 	mov	x1, #0x0                   	// #0
    3f6c:	f949e459 	ldr	x25, [x2, #5064]
    3f70:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x2d0>
    3f74:	f94a1057 	ldr	x23, [x2, #5152]
    3f78:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    3f7c:	f94a1458 	ldr	x24, [x2, #5160]
    3f80:	9132e021 	add	x1, x1, #0xcb8
    3f84:	91330000 	add	x0, x0, #0xcc0
    3f88:	97fffa06 	bl	27a0 <fopen@plt>
    3f8c:	b4000740 	cbz	x0, 4074 <fwp_heap_report+0x154>
    3f90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3f94:	a91253f3 	stp	x19, x20, [sp, #288]
    3f98:	aa0003f4 	mov	x20, x0
    3f9c:	910023f3 	add	x19, sp, #0x8
    3fa0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3fa4:	72aae915 	movk	w21, #0x5748, lsl #16
    3fa8:	aa1403e2 	mov	x2, x20
    3fac:	aa1303e0 	mov	x0, x19
    3fb0:	52802001 	mov	w1, #0x100                 	// #256
    3fb4:	97fffa83 	bl	29c0 <fgets@plt>
    3fb8:	b4000280 	cbz	x0, 4008 <fwp_heap_report+0xe8>
    3fbc:	b9400261 	ldr	w1, [x19]
    3fc0:	6b15003f 	cmp	w1, w21
    3fc4:	54ffff21 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fc8:	39401260 	ldrb	w0, [x19, #4]
    3fcc:	7101341f 	cmp	w0, #0x4d
    3fd0:	54fffec1 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fd4:	394037e0 	ldrb	w0, [sp, #13]
    3fd8:	7100e81f 	cmp	w0, #0x3a
    3fdc:	54fffe61 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fe0:	52800142 	mov	w2, #0xa                   	// #10
    3fe4:	d2800001 	mov	x1, #0x0                   	// #0
    3fe8:	91003be0 	add	x0, sp, #0xe
    3fec:	97fffa31 	bl	28b0 <strtol@plt>
    3ff0:	aa1403e2 	mov	x2, x20
    3ff4:	aa0003fa 	mov	x26, x0
    3ff8:	52802001 	mov	w1, #0x100                 	// #256
    3ffc:	aa1303e0 	mov	x0, x19
    4000:	97fffa70 	bl	29c0 <fgets@plt>
    4004:	b5fffdc0 	cbnz	x0, 3fbc <fwp_heap_report+0x9c>
    4008:	aa1403e0 	mov	x0, x20
    400c:	97fff9e1 	bl	2790 <fclose@plt>
    4010:	a95253f3 	ldp	x19, x20, [sp, #288]
    4014:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4018:	f947f400 	ldr	x0, [x0, #4072]
    401c:	f94087e2 	ldr	x2, [sp, #264]
    4020:	f9400001 	ldr	x1, [x0]
    4024:	eb010042 	subs	x2, x2, x1
    4028:	d2800001 	mov	x1, #0x0                   	// #0
    402c:	54000281 	b.ne	407c <fwp_heap_report+0x15c>  // b.any
    4030:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4034:	aa1a03e6 	mov	x6, x26
    4038:	aa1903e5 	mov	x5, x25
    403c:	aa1803e4 	mov	x4, x24
    4040:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4044:	aa1703e3 	mov	x3, x23
    4048:	a95463f7 	ldp	x23, x24, [sp, #320]
    404c:	aa1603e0 	mov	x0, x22
    4050:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4054:	1e604121 	fmov	d1, d9
    4058:	1e604100 	fmov	d0, d8
    405c:	b0000042 	adrp	x2, d000 <fwp_main_thread+0x2d0>
    4060:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4064:	91338042 	add	x2, x2, #0xce0
    4068:	9105c3ff 	add	sp, sp, #0x170
    406c:	52800041 	mov	w1, #0x2                   	// #2
    4070:	17fffa04 	b	2880 <__fprintf_chk@plt>
    4074:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4078:	17ffffe7 	b	4014 <fwp_heap_report+0xf4>
    407c:	a91253f3 	stp	x19, x20, [sp, #288]
    4080:	97fff9e4 	bl	2810 <__stack_chk_fail@plt>

0000000000004084 <fwp_heap_init>:
    4084:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4088:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9c0>
    408c:	91150061 	add	x1, x3, #0x540
    4090:	910003fd 	mov	x29, sp
    4094:	a90153f3 	stp	x19, x20, [sp, #16]
    4098:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    409c:	91190262 	add	x2, x19, #0x640
    40a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a4:	52800024 	mov	w4, #0x1                   	// #1
    40a8:	52800200 	mov	w0, #0x10                  	// #16
    40ac:	b913a444 	str	w4, [x2, #5028]
    40b0:	b8004420 	str	w0, [x1], #4
    40b4:	11004000 	add	w0, w0, #0x10
    40b8:	7104401f 	cmp	w0, #0x110
    40bc:	54ffffa1 	b.ne	40b0 <fwp_heap_init+0x2c>  // b.any
    40c0:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0x5f0>
    40c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    40c8:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9c0>
    40cc:	91160021 	add	x1, x1, #0x580
    40d0:	3dc27043 	ldr	q3, [x2, #2496]
    40d4:	d2800000 	mov	x0, #0x0                   	// #0
    40d8:	4e040401 	dup	v1.4s, v0.s[0]
    40dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    40e0:	0f215400 	shl	v0.2s, v0.2s, #1
    40e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    40e8:	3ca06821 	str	q1, [x1, x0]
    40ec:	91004000 	add	x0, x0, #0x10
    40f0:	f101801f 	cmp	x0, #0x60
    40f4:	54ffff21 	b.ne	40d8 <fwp_heap_init+0x54>  // b.any
    40f8:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9c0>
    40fc:	91150063 	add	x3, x3, #0x540
    4100:	91178084 	add	x4, x4, #0x5e0
    4104:	91190266 	add	x6, x19, #0x640
    4108:	d2800002 	mov	x2, #0x0                   	// #0
    410c:	d2800000 	mov	x0, #0x0                   	// #0
    4110:	d2880205 	mov	x5, #0x4010                	// #16400
    4114:	d503201f 	nop
    4118:	910f0001 	add	x1, x0, #0x3c0
    411c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4120:	eb02003f 	cmp	x1, x2
    4124:	540000a2 	b.cs	4138 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4128:	91000400 	add	x0, x0, #0x1
    412c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4130:	eb02003f 	cmp	x1, x2
    4134:	54ffffa3 	b.cc	4128 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4138:	91004042 	add	x2, x2, #0x10
    413c:	38001480 	strb	w0, [x4], #1
    4140:	eb05005f 	cmp	x2, x5
    4144:	54fffea1 	b.ne	4118 <fwp_heap_init+0x94>  // b.any
    4148:	528000b5 	mov	w21, #0x5                   	// #5
    414c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4150:	14000004 	b	4160 <fwp_heap_init+0xdc>
    4154:	d342fe94 	lsr	x20, x20, #2
    4158:	710006b5 	subs	w21, w21, #0x1
    415c:	54000720 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    4160:	91404296 	add	x22, x20, #0x10, lsl #12
    4164:	d2800005 	mov	x5, #0x0                   	// #0
    4168:	aa1603e1 	mov	x1, x22
    416c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4170:	52880443 	mov	w3, #0x4022                	// #16418
    4174:	52800002 	mov	w2, #0x0                   	// #0
    4178:	d2800000 	mov	x0, #0x0                   	// #0
    417c:	97fff9c9 	bl	28a0 <mmap@plt>
    4180:	aa0003e6 	mov	x6, x0
    4184:	b100041f 	cmn	x0, #0x1
    4188:	54fffe60 	b.eq	4154 <fwp_heap_init+0xd0>  // b.none
    418c:	b40005a0 	cbz	x0, 4240 <fwp_heap_init+0x1bc>
    4190:	d350fe94 	lsr	x20, x20, #16
    4194:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4198:	8b0000c7 	add	x7, x6, x0
    419c:	91190275 	add	x21, x19, #0x640
    41a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    41a4:	8b140a81 	add	x1, x20, x20, lsl #2
    41a8:	d2800005 	mov	x5, #0x0                   	// #0
    41ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    41b0:	d37df021 	lsl	x1, x1, #3
    41b4:	52880443 	mov	w3, #0x4022                	// #16418
    41b8:	52800002 	mov	w2, #0x0                   	// #0
    41bc:	d2800000 	mov	x0, #0x0                   	// #0
    41c0:	f909daa7 	str	x7, [x21, #5040]
    41c4:	f909dea6 	str	x6, [x21, #5048]
    41c8:	f909e2b6 	str	x22, [x21, #5056]
    41cc:	f909eab4 	str	x20, [x21, #5072]
    41d0:	f90a02a1 	str	x1, [x21, #5120]
    41d4:	97fff9b3 	bl	28a0 <mmap@plt>
    41d8:	aa0003e1 	mov	x1, x0
    41dc:	b100041f 	cmn	x0, #0x1
    41e0:	54000300 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    41e4:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    41e8:	91364000 	add	x0, x0, #0xd90
    41ec:	f909fea1 	str	x1, [x21, #5112]
    41f0:	97fff9ec 	bl	29a0 <getenv@plt>
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	aa0003e1 	mov	x1, x0
    41fc:	b40000e0 	cbz	x0, 4218 <fwp_heap_init+0x194>
    4200:	39400000 	ldrb	w0, [x0]
    4204:	340000a0 	cbz	w0, 4218 <fwp_heap_init+0x194>
    4208:	7100c000 	subs	w0, w0, #0x30
    420c:	54000120 	b.eq	4230 <fwp_heap_init+0x1ac>  // b.none
    4210:	7100001f 	cmp	w0, #0x0
    4214:	1a9f07e2 	cset	w2, ne	// ne = any
    4218:	91190273 	add	x19, x19, #0x640
    421c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4220:	b913aa62 	str	w2, [x19, #5032]
    4224:	a94153f3 	ldp	x19, x20, [sp, #16]
    4228:	a8c37bfd 	ldp	x29, x30, [sp], #48
    422c:	d65f03c0 	ret
    4230:	39400420 	ldrb	w0, [x1, #1]
    4234:	7100001f 	cmp	w0, #0x0
    4238:	1a9f07e2 	cset	w2, ne	// ne = any
    423c:	17fffff7 	b	4218 <fwp_heap_init+0x194>
    4240:	97fffbac 	bl	30f0 <fwp_heap_oom>

0000000000004244 <fwp_wake_io>:
    4244:	900000e9 	adrp	x9, 20000 <__data_start>
    4248:	91018122 	add	x2, x9, #0x60
    424c:	f9400001 	ldr	x1, [x0]
    4250:	5280000a 	mov	w10, #0x0                   	// #0
    4254:	f9406046 	ldr	x6, [x2, #192]
    4258:	52800008 	mov	w8, #0x0                   	// #0
    425c:	4f000400 	movi	v0.4s, #0x0
    4260:	52800027 	mov	w7, #0x1                   	// #1
    4264:	aa0103e2 	mov	x2, x1
    4268:	b4000321 	cbz	x1, 42cc <fwp_wake_io+0x88>
    426c:	f9408c25 	ldr	x5, [x1, #280]
    4270:	39015c27 	strb	w7, [x1, #87]
    4274:	b4000165 	cbz	x5, 42a0 <fwp_wake_io+0x5c>
    4278:	a9520c24 	ldp	x4, x3, [x1, #288]
    427c:	b4000364 	cbz	x4, 42e8 <fwp_wake_io+0xa4>
    4280:	f9009483 	str	x3, [x4, #296]
    4284:	f9409423 	ldr	x3, [x1, #296]
    4288:	b4000043 	cbz	x3, 4290 <fwp_wake_io+0x4c>
    428c:	f9009064 	str	x4, [x3, #288]
    4290:	91080023 	add	x3, x1, #0x200
    4294:	f900943f 	str	xzr, [x1, #296]
    4298:	3c918060 	stur	q0, [x3, #-232]
    429c:	f9400001 	ldr	x1, [x0]
    42a0:	f9402843 	ldr	x3, [x2, #80]
    42a4:	f2001c7f 	tst	x3, #0xff000000ff
    42a8:	54fffde1 	b.ne	4264 <fwp_wake_io+0x20>  // b.any
    42ac:	39015047 	strb	w7, [x2, #84]
    42b0:	f900805f 	str	xzr, [x2, #256]
    42b4:	b40001e6 	cbz	x6, 42f0 <fwp_wake_io+0xac>
    42b8:	f90080c2 	str	x2, [x6, #256]
    42bc:	aa0203e6 	mov	x6, x2
    42c0:	52800028 	mov	w8, #0x1                   	// #1
    42c4:	aa0103e2 	mov	x2, x1
    42c8:	b5fffd21 	cbnz	x1, 426c <fwp_wake_io+0x28>
    42cc:	3400006a 	cbz	w10, 42d8 <fwp_wake_io+0x94>
    42d0:	91018120 	add	x0, x9, #0x60
    42d4:	f900640b 	str	x11, [x0, #200]
    42d8:	34000068 	cbz	w8, 42e4 <fwp_wake_io+0xa0>
    42dc:	91018129 	add	x9, x9, #0x60
    42e0:	f9006126 	str	x6, [x9, #192]
    42e4:	d65f03c0 	ret
    42e8:	f90000a3 	str	x3, [x5]
    42ec:	17ffffe7 	b	4288 <fwp_wake_io+0x44>
    42f0:	aa0203eb 	mov	x11, x2
    42f4:	5280002a 	mov	w10, #0x1                   	// #1
    42f8:	17fffff1 	b	42bc <fwp_wake_io+0x78>
    42fc:	d503201f 	nop

0000000000004300 <ad_raw_free.part.0>:
    4300:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fba0>
    4304:	d2800001 	mov	x1, #0x0                   	// #0
    4308:	91118082 	add	x2, x4, #0x460
    430c:	14000005 	b	4320 <ad_raw_free.part.0+0x20>
    4310:	91000421 	add	x1, x1, #0x1
    4314:	91006042 	add	x2, x2, #0x18
    4318:	f140043f 	cmp	x1, #0x1, lsl #12
    431c:	54000220 	b.eq	4360 <ad_raw_free.part.0+0x60>  // b.none
    4320:	f9400043 	ldr	x3, [x2]
    4324:	eb03001f 	cmp	x0, x3
    4328:	54ffff41 	b.ne	4310 <ad_raw_free.part.0+0x10>  // b.any
    432c:	8b010421 	add	x1, x1, x1, lsl #1
    4330:	91118084 	add	x4, x4, #0x460
    4334:	900000e2 	adrp	x2, 20000 <__data_start>
    4338:	91018042 	add	x2, x2, #0x60
    433c:	8b010c81 	add	x1, x4, x1, lsl #3
    4340:	b9401024 	ldr	w4, [x1, #16]
    4344:	f9400425 	ldr	x5, [x1, #8]
    4348:	a9007c3f 	stp	xzr, xzr, [x1]
    434c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4350:	f900083f 	str	xzr, [x1, #16]
    4354:	cb050061 	sub	x1, x3, x5
    4358:	f8247841 	str	x1, [x2, x4, lsl #3]
    435c:	17fff95d 	b	28d0 <free@plt>
    4360:	f100001f 	cmp	x0, #0x0
    4364:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x2d0>
    4368:	9136e021 	add	x1, x1, #0xdb8
    436c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4370:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    4374:	91368000 	add	x0, x0, #0xda0
    4378:	910003fd 	mov	x29, sp
    437c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4380:	97fffbe0 	bl	3300 <ad_raw_fail>

0000000000004384 <fwp_tape_buffers_dispose>:
    4384:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4388:	910003fd 	mov	x29, sp
    438c:	f9000bf3 	str	x19, [sp, #16]
    4390:	aa0003f3 	mov	x19, x0
    4394:	f9400000 	ldr	x0, [x0]
    4398:	b4000040 	cbz	x0, 43a0 <fwp_tape_buffers_dispose+0x1c>
    439c:	97ffffd9 	bl	4300 <ad_raw_free.part.0>
    43a0:	f9400a60 	ldr	x0, [x19, #16]
    43a4:	b4000040 	cbz	x0, 43ac <fwp_tape_buffers_dispose+0x28>
    43a8:	97ffffd6 	bl	4300 <ad_raw_free.part.0>
    43ac:	f9401260 	ldr	x0, [x19, #32]
    43b0:	b4000040 	cbz	x0, 43b8 <fwp_tape_buffers_dispose+0x34>
    43b4:	97ffffd3 	bl	4300 <ad_raw_free.part.0>
    43b8:	4f000400 	movi	v0.4s, #0x0
    43bc:	f9001a7f 	str	xzr, [x19, #48]
    43c0:	ad000260 	stp	q0, q0, [x19]
    43c4:	3d800a60 	str	q0, [x19, #32]
    43c8:	f9400bf3 	ldr	x19, [sp, #16]
    43cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43d0:	d65f03c0 	ret

00000000000043d4 <ad_raw_realloc>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	f90013f5 	str	x21, [sp, #32]
    43e4:	b40005a1 	cbz	x1, 4498 <ad_raw_realloc+0xc4>
    43e8:	aa0103f4 	mov	x20, x1
    43ec:	2a0203f5 	mov	w21, w2
    43f0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fba0>
    43f4:	d2800004 	mov	x4, #0x0                   	// #0
    43f8:	91118025 	add	x5, x1, #0x460
    43fc:	14000005 	b	4410 <ad_raw_realloc+0x3c>
    4400:	91000484 	add	x4, x4, #0x1
    4404:	910060a5 	add	x5, x5, #0x18
    4408:	f140049f 	cmp	x4, #0x1, lsl #12
    440c:	54000320 	b.eq	4470 <ad_raw_realloc+0x9c>  // b.none
    4410:	f94000a6 	ldr	x6, [x5]
    4414:	eb06001f 	cmp	x0, x6
    4418:	54ffff41 	b.ne	4400 <ad_raw_realloc+0x2c>  // b.any
    441c:	8b040484 	add	x4, x4, x4, lsl #1
    4420:	91118021 	add	x1, x1, #0x460
    4424:	8b040c33 	add	x19, x1, x4, lsl #3
    4428:	b4000080 	cbz	x0, 4438 <ad_raw_realloc+0x64>
    442c:	b9401261 	ldr	w1, [x19, #16]
    4430:	6b15003f 	cmp	w1, w21
    4434:	540002c1 	b.ne	448c <ad_raw_realloc+0xb8>  // b.any
    4438:	aa1403e1 	mov	x1, x20
    443c:	97fff8f1 	bl	2800 <realloc@plt>
    4440:	aa0003ed 	mov	x13, x0
    4444:	b40000c0 	cbz	x0, 445c <ad_raw_realloc+0x88>
    4448:	2a1503e3 	mov	w3, w21
    444c:	aa1403e2 	mov	x2, x20
    4450:	aa1303e0 	mov	x0, x19
    4454:	aa0d03e1 	mov	x1, x13
    4458:	97fffaae 	bl	2f10 <ad_raw_record>
    445c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4460:	aa0d03e0 	mov	x0, x13
    4464:	f94013f5 	ldr	x21, [sp, #32]
    4468:	a8c37bfd 	ldp	x29, x30, [sp], #48
    446c:	d65f03c0 	ret
    4470:	f100001f 	cmp	x0, #0x0
    4474:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x2d0>
    4478:	9136e021 	add	x1, x1, #0xdb8
    447c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    4480:	91368000 	add	x0, x0, #0xda0
    4484:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4488:	97fffb9e 	bl	3300 <ad_raw_fail>
    448c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    4490:	9137e000 	add	x0, x0, #0xdf8
    4494:	97fffb9b 	bl	3300 <ad_raw_fail>
    4498:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    449c:	91376000 	add	x0, x0, #0xdd8
    44a0:	97fffb98 	bl	3300 <ad_raw_fail>

00000000000044a4 <fwp_tape_buffers_release>:
    44a4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44a8:	910003fd 	mov	x29, sp
    44ac:	a90153f3 	stp	x19, x20, [sp, #16]
    44b0:	aa0003f4 	mov	x20, x0
    44b4:	f9401400 	ldr	x0, [x0, #40]
    44b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    44bc:	b7f80560 	tbnz	x0, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c0:	f9401a93 	ldr	x19, [x20, #48]
    44c4:	b7f80533 	tbnz	x19, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c8:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    44cc:	eb01001f 	cmp	x0, x1
    44d0:	540004c8 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44d4:	8b000400 	add	x0, x0, x0, lsl #1
    44d8:	d2a00101 	mov	x1, #0x80000               	// #524288
    44dc:	d37df000 	lsl	x0, x0, #3
    44e0:	cb000021 	sub	x1, x1, x0
    44e4:	eb410e7f 	cmp	x19, x1, lsr #3
    44e8:	54000408 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44ec:	8b130c13 	add	x19, x0, x19, lsl #3
    44f0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    44f4:	91384000 	add	x0, x0, #0xe10
    44f8:	97fff92a 	bl	29a0 <getenv@plt>
    44fc:	b4000080 	cbz	x0, 450c <fwp_tape_buffers_release+0x68>
    4500:	39400001 	ldrb	w1, [x0]
    4504:	7100c03f 	cmp	w1, #0x30
    4508:	54000880 	b.eq	4618 <fwp_tape_buffers_release+0x174>  // b.none
    450c:	d1000661 	sub	x1, x19, #0x1
    4510:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4514:	eb00003f 	cmp	x1, x0
    4518:	54000328 	b.hi	457c <fwp_tape_buffers_release+0xd8>  // b.pmore
    451c:	900000f5 	adrp	x21, 20000 <__data_start>
    4520:	f9001bf7 	str	x23, [sp, #48]
    4524:	910182b7 	add	x23, x21, #0x60
    4528:	910382f6 	add	x22, x23, #0xe0
    452c:	aa1603e0 	mov	x0, x22
    4530:	97ffff95 	bl	4384 <fwp_tape_buffers_dispose>
    4534:	ad400a81 	ldp	q1, q2, [x20]
    4538:	f9008ef3 	str	x19, [x23, #280]
    453c:	4f000400 	movi	v0.4s, #0x0
    4540:	ad000ac1 	stp	q1, q2, [x22]
    4544:	3dc00a81 	ldr	q1, [x20, #32]
    4548:	3d800ac1 	str	q1, [x22, #32]
    454c:	f9401a80 	ldr	x0, [x20, #48]
    4550:	f9001ac0 	str	x0, [x22, #48]
    4554:	f9001a9f 	str	xzr, [x20, #48]
    4558:	ad000280 	stp	q0, q0, [x20]
    455c:	3d800a80 	str	q0, [x20, #32]
    4560:	f9401bf7 	ldr	x23, [sp, #48]
    4564:	1400000b 	b	4590 <fwp_tape_buffers_release+0xec>
    4568:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    456c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4570:	91384000 	add	x0, x0, #0xe10
    4574:	97fff90b 	bl	29a0 <getenv@plt>
    4578:	b5fffc40 	cbnz	x0, 4500 <fwp_tape_buffers_release+0x5c>
    457c:	aa1403e0 	mov	x0, x20
    4580:	97ffff81 	bl	4384 <fwp_tape_buffers_dispose>
    4584:	900000f5 	adrp	x21, 20000 <__data_start>
    4588:	910182a0 	add	x0, x21, #0x60
    458c:	f9408c13 	ldr	x19, [x0, #280]
    4590:	910182a2 	add	x2, x21, #0x60
    4594:	f9409044 	ldr	x4, [x2, #288]
    4598:	a9400c45 	ldp	x5, x3, [x2]
    459c:	8b040481 	add	x1, x4, x4, lsl #1
    45a0:	f9400840 	ldr	x0, [x2, #16]
    45a4:	8b010881 	add	x1, x4, x1, lsl #2
    45a8:	f9400c44 	ldr	x4, [x2, #24]
    45ac:	8b0300a3 	add	x3, x5, x3
    45b0:	d37df021 	lsl	x1, x1, #3
    45b4:	8b040000 	add	x0, x0, x4
    45b8:	8b030000 	add	x0, x0, x3
    45bc:	eb05003f 	cmp	x1, x5
    45c0:	54000321 	b.ne	4624 <fwp_tape_buffers_release+0x180>  // b.any
    45c4:	8b130023 	add	x3, x1, x19
    45c8:	eb00007f 	cmp	x3, x0
    45cc:	540002c8 	b.hi	4624 <fwp_tape_buffers_release+0x180>  // b.pmore
    45d0:	f9405c43 	ldr	x3, [x2, #184]
    45d4:	f140087f 	cmp	x3, #0x2, lsl #12
    45d8:	540002e0 	b.eq	4634 <fwp_tape_buffers_release+0x190>  // b.none
    45dc:	8b030464 	add	x4, x3, x3, lsl #1
    45e0:	90000165 	adrp	x5, 30000 <alt.5+0xfba0>
    45e4:	911180a5 	add	x5, x5, #0x460
    45e8:	cb010000 	sub	x0, x0, x1
    45ec:	d37df084 	lsl	x4, x4, #3
    45f0:	cb130000 	sub	x0, x0, x19
    45f4:	8b0400a6 	add	x6, x5, x4
    45f8:	91000463 	add	x3, x3, #0x1
    45fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4600:	f82468a1 	str	x1, [x5, x4]
    4604:	a90080d3 	stp	x19, x0, [x6, #8]
    4608:	f9005c43 	str	x3, [x2, #184]
    460c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4610:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4614:	d65f03c0 	ret
    4618:	39400400 	ldrb	w0, [x0, #1]
    461c:	34fffb00 	cbz	w0, 457c <fwp_tape_buffers_release+0xd8>
    4620:	17ffffbb 	b	450c <fwp_tape_buffers_release+0x68>
    4624:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    4628:	9138a000 	add	x0, x0, #0xe28
    462c:	f9001bf7 	str	x23, [sp, #48]
    4630:	97fffb34 	bl	3300 <ad_raw_fail>
    4634:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    4638:	91396000 	add	x0, x0, #0xe58
    463c:	f9001bf7 	str	x23, [sp, #48]
    4640:	97fffb30 	bl	3300 <ad_raw_fail>

0000000000004644 <fwp_poll_events>:
    4644:	d10103ff 	sub	sp, sp, #0x40
    4648:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    464c:	f947f400 	ldr	x0, [x0, #4072]
    4650:	a9027bfd 	stp	x29, x30, [sp, #32]
    4654:	910083fd 	add	x29, sp, #0x20
    4658:	a90353f3 	stp	x19, x20, [sp, #48]
    465c:	900000f4 	adrp	x20, 20000 <__data_start>
    4660:	f9400001 	ldr	x1, [x0]
    4664:	f9000fe1 	str	x1, [sp, #24]
    4668:	d2800001 	mov	x1, #0x0                   	// #0
    466c:	97fffca5 	bl	3900 <fwp_now_ns>
    4670:	91018281 	add	x1, x20, #0x60
    4674:	f9409433 	ldr	x19, [x1, #296]
    4678:	b4000e73 	cbz	x19, 4844 <fwp_poll_events+0x200>
    467c:	aa1303e1 	mov	x1, x19
    4680:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4684:	14000005 	b	4698 <fwp_poll_events+0x54>
    4688:	f9408821 	ldr	x1, [x1, #272]
    468c:	eb03005f 	cmp	x2, x3
    4690:	9a83d042 	csel	x2, x2, x3, le
    4694:	b40000c1 	cbz	x1, 46ac <fwp_poll_events+0x68>
    4698:	f9403423 	ldr	x3, [x1, #104]
    469c:	b6ffff62 	tbz	x2, #63, 4688 <fwp_poll_events+0x44>
    46a0:	f9408821 	ldr	x1, [x1, #272]
    46a4:	aa0303e2 	mov	x2, x3
    46a8:	b5ffff81 	cbnz	x1, 4698 <fwp_poll_events+0x54>
    46ac:	b7f80cc2 	tbnz	x2, #63, 4844 <fwp_poll_events+0x200>
    46b0:	cb000042 	sub	x2, x2, x0
    46b4:	f100005f 	cmp	x2, #0x0
    46b8:	540005ad 	b.le	476c <fwp_poll_events+0x128>
    46bc:	d2869b60 	mov	x0, #0x34db                	// #13531
    46c0:	d2884801 	mov	x1, #0x4240                	// #16960
    46c4:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    46c8:	f2a001e1 	movk	x1, #0xf, lsl #16
    46cc:	f2dbd040 	movk	x0, #0xde82, lsl #32
    46d0:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    46d4:	f2e86360 	movk	x0, #0x431b, lsl #48
    46d8:	9b407c40 	smulh	x0, x2, x0
    46dc:	9352fc00 	asr	x0, x0, #18
    46e0:	cb82fc00 	sub	x0, x0, x2, asr #63
    46e4:	9b018802 	msub	x2, x0, x1, x2
    46e8:	f100005f 	cmp	x2, #0x0
    46ec:	9a800400 	cinc	x0, x0, ne	// ne = any
    46f0:	eb03001f 	cmp	x0, x3
    46f4:	540009ec 	b.gt	4830 <fwp_poll_events+0x1ec>
    46f8:	340003a0 	cbz	w0, 476c <fwp_poll_events+0x128>
    46fc:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4700:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4704:	72a20c42 	movk	w2, #0x1062, lsl #16
    4708:	9ba27c02 	umull	x2, w0, w2
    470c:	d366fc43 	lsr	x3, x2, #38
    4710:	aa0303e2 	mov	x2, x3
    4714:	1b048063 	msub	w3, w3, w4, w0
    4718:	9b217c63 	smull	x3, w3, w1
    471c:	d2800001 	mov	x1, #0x0                   	// #0
    4720:	910023e0 	add	x0, sp, #0x8
    4724:	a9008fe2 	stp	x2, x3, [sp, #8]
    4728:	97fff86e 	bl	28e0 <nanosleep@plt>
    472c:	91018280 	add	x0, x20, #0x60
    4730:	f9409413 	ldr	x19, [x0, #296]
    4734:	97fffc73 	bl	3900 <fwp_now_ns>
    4738:	aa0003e6 	mov	x6, x0
    473c:	b50001d3 	cbnz	x19, 4774 <fwp_poll_events+0x130>
    4740:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4744:	f947f400 	ldr	x0, [x0, #4072]
    4748:	f9400fe2 	ldr	x2, [sp, #24]
    474c:	f9400001 	ldr	x1, [x0]
    4750:	eb010042 	subs	x2, x2, x1
    4754:	d2800001 	mov	x1, #0x0                   	// #0
    4758:	540008c1 	b.ne	4870 <fwp_poll_events+0x22c>  // b.any
    475c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4760:	a94353f3 	ldp	x19, x20, [sp, #48]
    4764:	910103ff 	add	sp, sp, #0x40
    4768:	d65f03c0 	ret
    476c:	97fffc65 	bl	3900 <fwp_now_ns>
    4770:	aa0003e6 	mov	x6, x0
    4774:	4f000400 	movi	v0.4s, #0x0
    4778:	91018288 	add	x8, x20, #0x60
    477c:	52800027 	mov	w7, #0x1                   	// #1
    4780:	f9403661 	ldr	x1, [x19, #104]
    4784:	aa1303e5 	mov	x5, x19
    4788:	f9408a73 	ldr	x19, [x19, #272]
    478c:	eb06003f 	cmp	x1, x6
    4790:	5400032c 	b.gt	47f4 <fwp_poll_events+0x1b0>
    4794:	394154a0 	ldrb	w0, [x5, #85]
    4798:	36000120 	tbz	w0, #0, 47bc <fwp_poll_events+0x178>
    479c:	f94084a0 	ldr	x0, [x5, #264]
    47a0:	b40003c0 	cbz	x0, 4818 <fwp_poll_events+0x1d4>
    47a4:	f9008813 	str	x19, [x0, #272]
    47a8:	b4000053 	cbz	x19, 47b0 <fwp_poll_events+0x16c>
    47ac:	f9008660 	str	x0, [x19, #264]
    47b0:	910800a0 	add	x0, x5, #0x200
    47b4:	390154bf 	strb	wzr, [x5, #85]
    47b8:	3c908000 	stur	q0, [x0, #-248]
    47bc:	f94030a0 	ldr	x0, [x5, #96]
    47c0:	390158a7 	strb	w7, [x5, #86]
    47c4:	f100001f 	cmp	x0, #0x0
    47c8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    47cc:	5400018d 	b.le	47fc <fwp_poll_events+0x1b8>
    47d0:	f94028a0 	ldr	x0, [x5, #80]
    47d4:	f2001c1f 	tst	x0, #0xff000000ff
    47d8:	540000e1 	b.ne	47f4 <fwp_poll_events+0x1b0>  // b.any
    47dc:	f9406100 	ldr	x0, [x8, #192]
    47e0:	390150a7 	strb	w7, [x5, #84]
    47e4:	f90080bf 	str	xzr, [x5, #256]
    47e8:	b40001e0 	cbz	x0, 4824 <fwp_poll_events+0x1e0>
    47ec:	f9006105 	str	x5, [x8, #192]
    47f0:	f9008005 	str	x5, [x0, #256]
    47f4:	b5fffc73 	cbnz	x19, 4780 <fwp_poll_events+0x13c>
    47f8:	17ffffd2 	b	4740 <fwp_poll_events+0xfc>
    47fc:	394144a0 	ldrb	w0, [x5, #81]
    4800:	3707fe80 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    4804:	394140a0 	ldrb	w0, [x5, #80]
    4808:	3707fe40 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    480c:	aa0503e0 	mov	x0, x5
    4810:	97fffb98 	bl	3670 <fwp_cancel_tree.part.0>
    4814:	17ffffef 	b	47d0 <fwp_poll_events+0x18c>
    4818:	91018281 	add	x1, x20, #0x60
    481c:	f9009433 	str	x19, [x1, #296]
    4820:	17ffffe2 	b	47a8 <fwp_poll_events+0x164>
    4824:	f9006105 	str	x5, [x8, #192]
    4828:	f9006505 	str	x5, [x8, #200]
    482c:	17fffff2 	b	47f4 <fwp_poll_events+0x1b0>
    4830:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4834:	d2989362 	mov	x2, #0xc49b                	// #50331
    4838:	f2a4d203 	movk	x3, #0x2690, lsl #16
    483c:	f2a00402 	movk	x2, #0x20, lsl #16
    4840:	17ffffb7 	b	471c <fwp_poll_events+0xd8>
    4844:	97fff9ec 	bl	2ff4 <fwp_flush>
    4848:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    484c:	f947e863 	ldr	x3, [x3, #4048]
    4850:	d2800562 	mov	x2, #0x2b                  	// #43
    4854:	d2800021 	mov	x1, #0x1                   	// #1
    4858:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    485c:	9139e000 	add	x0, x0, #0xe78
    4860:	f9400063 	ldr	x3, [x3]
    4864:	97fff82b 	bl	2910 <fwrite@plt>
    4868:	52800ca0 	mov	w0, #0x65                  	// #101
    486c:	97fff795 	bl	26c0 <exit@plt>
    4870:	97fff7e8 	bl	2810 <__stack_chk_fail@plt>

0000000000004874 <fwp_rc_wide_dup>:
    4874:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4878:	910003fd 	mov	x29, sp
    487c:	a90153f3 	stp	x19, x20, [sp, #16]
    4880:	aa0003f3 	mov	x19, x0
    4884:	ca404400 	eor	x0, x0, x0, lsr #17
    4888:	f90013f5 	str	x21, [sp, #32]
    488c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4890:	ca402400 	eor	x0, x0, x0, lsr #9
    4894:	911902a2 	add	x2, x21, #0x640
    4898:	92401c00 	and	x0, x0, #0xff
    489c:	910a2403 	add	x3, x0, #0x289
    48a0:	8b000c40 	add	x0, x2, x0, lsl #3
    48a4:	8b030c54 	add	x20, x2, x3, lsl #3
    48a8:	f94a2401 	ldr	x1, [x0, #5192]
    48ac:	b50000a1 	cbnz	x1, 48c0 <fwp_rc_wide_dup+0x4c>
    48b0:	1400002d 	b	4964 <fwp_rc_wide_dup+0xf0>
    48b4:	91004034 	add	x20, x1, #0x10
    48b8:	f9400821 	ldr	x1, [x1, #16]
    48bc:	b4000241 	cbz	x1, 4904 <fwp_rc_wide_dup+0x90>
    48c0:	f9400022 	ldr	x2, [x1]
    48c4:	eb02027f 	cmp	x19, x2
    48c8:	54ffff61 	b.ne	48b4 <fwp_rc_wide_dup+0x40>  // b.any
    48cc:	f9400281 	ldr	x1, [x20]
    48d0:	39400260 	ldrb	w0, [x19]
    48d4:	7103f81f 	cmp	w0, #0xfe
    48d8:	54000220 	b.eq	491c <fwp_rc_wide_dup+0xa8>  // b.none
    48dc:	b40001a1 	cbz	x1, 4910 <fwp_rc_wide_dup+0x9c>
    48e0:	f9400420 	ldr	x0, [x1, #8]
    48e4:	b100041f 	cmn	x0, #0x1
    48e8:	540004a0 	b.eq	497c <fwp_rc_wide_dup+0x108>  // b.none
    48ec:	91000400 	add	x0, x0, #0x1
    48f0:	f9000420 	str	x0, [x1, #8]
    48f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f8:	f94013f5 	ldr	x21, [sp, #32]
    48fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4900:	d65f03c0 	ret
    4904:	39400260 	ldrb	w0, [x19]
    4908:	7103f81f 	cmp	w0, #0xfe
    490c:	540000a0 	b.eq	4920 <fwp_rc_wide_dup+0xac>  // b.none
    4910:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    4914:	913b4000 	add	x0, x0, #0xed0
    4918:	97fffb9a 	bl	3780 <fwp_trap>
    491c:	b5000281 	cbnz	x1, 496c <fwp_rc_wide_dup+0xf8>
    4920:	d2800300 	mov	x0, #0x18                  	// #24
    4924:	97fff7a3 	bl	27b0 <malloc@plt>
    4928:	b4000280 	cbz	x0, 4978 <fwp_rc_wide_dup+0x104>
    492c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4930:	a9000413 	stp	x19, x1, [x0]
    4934:	911902b5 	add	x21, x21, #0x640
    4938:	f900081f 	str	xzr, [x0, #16]
    493c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4940:	f9000280 	str	x0, [x20]
    4944:	39000261 	strb	w1, [x19]
    4948:	f94e26a0 	ldr	x0, [x21, #7240]
    494c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4950:	91000400 	add	x0, x0, #0x1
    4954:	f90e26a0 	str	x0, [x21, #7240]
    4958:	f94013f5 	ldr	x21, [sp, #32]
    495c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4960:	d65f03c0 	ret
    4964:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4968:	17ffffda 	b	48d0 <fwp_rc_wide_dup+0x5c>
    496c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    4970:	913aa000 	add	x0, x0, #0xea8
    4974:	97fffb83 	bl	3780 <fwp_trap>
    4978:	97fff9de 	bl	30f0 <fwp_heap_oom>
    497c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    4980:	913be000 	add	x0, x0, #0xef8
    4984:	97fffb7f 	bl	3780 <fwp_trap>
    4988:	d503201f 	nop
    498c:	d503201f 	nop

0000000000004990 <fwp_rc_forget_slot>:
    4990:	aa0003e1 	mov	x1, x0
    4994:	39400000 	ldrb	w0, [x0]
    4998:	7103fc1f 	cmp	w0, #0xff
    499c:	54000040 	b.eq	49a4 <fwp_rc_forget_slot+0x14>  // b.none
    49a0:	d65f03c0 	ret
    49a4:	ca414420 	eor	x0, x1, x1, lsr #17
    49a8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    49ac:	ca402400 	eor	x0, x0, x0, lsr #9
    49b0:	910003fd 	mov	x29, sp
    49b4:	92401c00 	and	x0, x0, #0xff
    49b8:	f9000bf3 	str	x19, [sp, #16]
    49bc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    49c0:	91190262 	add	x2, x19, #0x640
    49c4:	910a2403 	add	x3, x0, #0x289
    49c8:	8b000c40 	add	x0, x2, x0, lsl #3
    49cc:	8b030c43 	add	x3, x2, x3, lsl #3
    49d0:	f94a2400 	ldr	x0, [x0, #5192]
    49d4:	b50000a0 	cbnz	x0, 49e8 <fwp_rc_forget_slot+0x58>
    49d8:	14000011 	b	4a1c <fwp_rc_forget_slot+0x8c>
    49dc:	91004003 	add	x3, x0, #0x10
    49e0:	f9400800 	ldr	x0, [x0, #16]
    49e4:	b40001c0 	cbz	x0, 4a1c <fwp_rc_forget_slot+0x8c>
    49e8:	f9400002 	ldr	x2, [x0]
    49ec:	eb02003f 	cmp	x1, x2
    49f0:	54ffff61 	b.ne	49dc <fwp_rc_forget_slot+0x4c>  // b.any
    49f4:	f9400801 	ldr	x1, [x0, #16]
    49f8:	91190273 	add	x19, x19, #0x640
    49fc:	f9000061 	str	x1, [x3]
    4a00:	97fff7b4 	bl	28d0 <free@plt>
    4a04:	f94e2660 	ldr	x0, [x19, #7240]
    4a08:	d1000400 	sub	x0, x0, #0x1
    4a0c:	f90e2660 	str	x0, [x19, #7240]
    4a10:	f9400bf3 	ldr	x19, [sp, #16]
    4a14:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a18:	d65f03c0 	ret
    4a1c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    4a20:	913b4000 	add	x0, x0, #0xed0
    4a24:	97fffb57 	bl	3780 <fwp_trap>
    4a28:	d503201f 	nop
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_rc_prepare_chunk>:
    4a30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xba0>
    4a40:	911902c2 	add	x2, x22, #0x640
    4a44:	b9401c03 	ldr	w3, [x0, #28]
    4a48:	aa0103f5 	mov	x21, x1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	aa0003f4 	mov	x20, x0
    4a54:	f94e2440 	ldr	x0, [x2, #7240]
    4a58:	b4000440 	cbz	x0, 4ae0 <fwp_rc_prepare_chunk+0xb0>
    4a5c:	d2800013 	mov	x19, #0x0                   	// #0
    4a60:	35000203 	cbnz	w3, 4aa0 <fwp_rc_prepare_chunk+0x70>
    4a64:	b4000361 	cbz	x1, 4ad0 <fwp_rc_prepare_chunk+0xa0>
    4a68:	f9401280 	ldr	x0, [x20, #32]
    4a6c:	97fff799 	bl	28d0 <free@plt>
    4a70:	aa1503e0 	mov	x0, x21
    4a74:	d2800021 	mov	x1, #0x1                   	// #1
    4a78:	97fff75e 	bl	27f0 <calloc@plt>
    4a7c:	f9001280 	str	x0, [x20, #32]
    4a80:	b5000460 	cbnz	x0, 4b0c <fwp_rc_prepare_chunk+0xdc>
    4a84:	97fff99b 	bl	30f0 <fwp_heap_oom>
    4a88:	97ffffc2 	bl	4990 <fwp_rc_forget_slot>
    4a8c:	91000673 	add	x19, x19, #0x1
    4a90:	b9401e83 	ldr	w3, [x20, #28]
    4a94:	eb13007f 	cmp	x3, x19
    4a98:	54000169 	b.ls	4ac4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4a9c:	d503201f 	nop
    4aa0:	f9401283 	ldr	x3, [x20, #32]
    4aa4:	8b130060 	add	x0, x3, x19
    4aa8:	38736863 	ldrb	w3, [x3, x19]
    4aac:	7103fc7f 	cmp	w3, #0xff
    4ab0:	54fffec0 	b.eq	4a88 <fwp_rc_prepare_chunk+0x58>  // b.none
    4ab4:	b9401e83 	ldr	w3, [x20, #28]
    4ab8:	91000673 	add	x19, x19, #0x1
    4abc:	eb13007f 	cmp	x3, x19
    4ac0:	54ffff08 	b.hi	4aa0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4ac4:	eb0302bf 	cmp	x21, x3
    4ac8:	54000121 	b.ne	4aec <fwp_rc_prepare_chunk+0xbc>  // b.any
    4acc:	b5000335 	cbnz	x21, 4b30 <fwp_rc_prepare_chunk+0x100>
    4ad0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ad8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4adc:	d65f03c0 	ret
    4ae0:	2a0303e3 	mov	w3, w3
    4ae4:	eb0302bf 	cmp	x21, x3
    4ae8:	54ffff20 	b.eq	4acc <fwp_rc_prepare_chunk+0x9c>  // b.none
    4aec:	911902c2 	add	x2, x22, #0x640
    4af0:	f9401280 	ldr	x0, [x20, #32]
    4af4:	f94e2841 	ldr	x1, [x2, #7248]
    4af8:	cb030021 	sub	x1, x1, x3
    4afc:	f90e2841 	str	x1, [x2, #7248]
    4b00:	97fff774 	bl	28d0 <free@plt>
    4b04:	b5fffb75 	cbnz	x21, 4a70 <fwp_rc_prepare_chunk+0x40>
    4b08:	f900129f 	str	xzr, [x20, #32]
    4b0c:	911902d6 	add	x22, x22, #0x640
    4b10:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b14:	b9001e95 	str	w21, [x20, #28]
    4b18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b1c:	8b150000 	add	x0, x0, x21
    4b20:	f90e2ac0 	str	x0, [x22, #7248]
    4b24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b2c:	d65f03c0 	ret
    4b30:	f9401280 	ldr	x0, [x20, #32]
    4b34:	aa1503e2 	mov	x2, x21
    4b38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b3c:	52800001 	mov	w1, #0x0                   	// #0
    4b40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b44:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b48:	17fff726 	b	27e0 <memset@plt>
    4b4c:	d503201f 	nop

0000000000004b50 <fwp_heap_refill>:
    4b50:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b54:	910003fd 	mov	x29, sp
    4b58:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b5c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4b60:	911902b5 	add	x21, x21, #0x640
    4b64:	aa0003f6 	mov	x22, x0
    4b68:	d2800020 	mov	x0, #0x1                   	// #1
    4b6c:	a90153f3 	stp	x19, x20, [sp, #16]
    4b70:	a90363f7 	stp	x23, x24, [sp, #48]
    4b74:	2a0103f7 	mov	w23, w1
    4b78:	2a0203f8 	mov	w24, w2
    4b7c:	97fff96d 	bl	3130 <fwp_heap_chunks>
    4b80:	aa0003f3 	mov	x19, x0
    4b84:	f949fea2 	ldr	x2, [x21, #5112]
    4b88:	8b000800 	add	x0, x0, x0, lsl #2
    4b8c:	2a1703e1 	mov	w1, w23
    4b90:	52800025 	mov	w5, #0x1                   	// #1
    4b94:	d37df000 	lsl	x0, x0, #3
    4b98:	910f0021 	add	x1, x1, #0x3c0
    4b9c:	8b000054 	add	x20, x2, x0
    4ba0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4ba4:	52a00024 	mov	w4, #0x10000               	// #65536
    4ba8:	38206845 	strb	w5, [x2, x0]
    4bac:	aa1403e0 	mov	x0, x20
    4bb0:	39000698 	strb	w24, [x20, #1]
    4bb4:	39000a97 	strb	w23, [x20, #2]
    4bb8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4bbc:	b9000681 	str	w1, [x20, #4]
    4bc0:	2a0103e5 	mov	w5, w1
    4bc4:	8b0300a2 	add	x2, x5, x3
    4bc8:	1ac10881 	udiv	w1, w4, w1
    4bcc:	9ac50842 	udiv	x2, x2, x5
    4bd0:	b9000a81 	str	w1, [x20, #8]
    4bd4:	92404021 	and	x1, x1, #0x1ffff
    4bd8:	b9001a82 	str	w2, [x20, #24]
    4bdc:	97ffff95 	bl	4a30 <fwp_rc_prepare_chunk>
    4be0:	f949daa0 	ldr	x0, [x21, #5040]
    4be4:	29408a81 	ldp	w1, w2, [x20, #4]
    4be8:	8b134000 	add	x0, x0, x19, lsl #16
    4bec:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf0:	8b214003 	add	x3, x0, w1, uxtw
    4bf4:	9ba20021 	umaddl	x1, w1, w2, x0
    4bf8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bfc:	a90086c3 	stp	x3, x1, [x22, #8]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c08:	d65f03c0 	ret
    4c0c:	d503201f 	nop

0000000000004c10 <fwp_mem_free>:
    4c10:	b40003c0 	cbz	x0, 4c88 <fwp_mem_free+0x78>
    4c14:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c18:	910003fd 	mov	x29, sp
    4c1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c20:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    4c24:	911902a1 	add	x1, x21, #0x640
    4c28:	a90153f3 	stp	x19, x20, [sp, #16]
    4c2c:	aa0003f3 	mov	x19, x0
    4c30:	f949d823 	ldr	x3, [x1, #5040]
    4c34:	f949ec22 	ldr	x2, [x1, #5080]
    4c38:	cb030000 	sub	x0, x0, x3
    4c3c:	eb02401f 	cmp	x0, x2, lsl #16
    4c40:	540001c2 	b.cs	4c78 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4c44:	d350fc16 	lsr	x22, x0, #16
    4c48:	a90363f7 	stp	x23, x24, [sp, #48]
    4c4c:	f949fc22 	ldr	x2, [x1, #5112]
    4c50:	8b160ad4 	add	x20, x22, x22, lsl #2
    4c54:	d37df294 	lsl	x20, x20, #3
    4c58:	ab140057 	adds	x23, x2, x20
    4c5c:	540000c0 	b.eq	4c74 <fwp_mem_free+0x64>  // b.none
    4c60:	38746842 	ldrb	w2, [x2, x20]
    4c64:	7100045f 	cmp	w2, #0x1
    4c68:	54000120 	b.eq	4c8c <fwp_mem_free+0x7c>  // b.none
    4c6c:	7100085f 	cmp	w2, #0x2
    4c70:	540005e0 	b.eq	4d2c <fwp_mem_free+0x11c>  // b.none
    4c74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c78:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c80:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c84:	d65f03c0 	ret
    4c88:	d65f03c0 	ret
    4c8c:	f94012f8 	ldr	x24, [x23, #32]
    4c90:	b94006e1 	ldr	w1, [x23, #4]
    4c94:	f90023f9 	str	x25, [sp, #64]
    4c98:	2a0103e2 	mov	w2, w1
    4c9c:	394006f9 	ldrb	w25, [x23, #1]
    4ca0:	39400af4 	ldrb	w20, [x23, #2]
    4ca4:	b4000158 	cbz	x24, 4ccc <fwp_mem_free+0xbc>
    4ca8:	92403e76 	and	x22, x19, #0xffff
    4cac:	9ac20ad6 	udiv	x22, x22, x2
    4cb0:	38766b01 	ldrb	w1, [x24, x22]
    4cb4:	8b160300 	add	x0, x24, x22
    4cb8:	7103fc3f 	cmp	w1, #0xff
    4cbc:	54000980 	b.eq	4dec <fwp_mem_free+0x1dc>  // b.none
    4cc0:	38366b1f 	strb	wzr, [x24, x22]
    4cc4:	b94006e1 	ldr	w1, [x23, #4]
    4cc8:	2a0103e2 	mov	w2, w1
    4ccc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4cd0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4cd4:	cb390000 	sub	x0, x0, w25, uxtb
    4cd8:	8b340074 	add	x20, x3, w20, uxtb
    4cdc:	911902b5 	add	x21, x21, #0x640
    4ce0:	1e630021 	ucvtf	d1, w1
    4ce4:	d37ae400 	lsl	x0, x0, #6
    4ce8:	8b140c14 	add	x20, x0, x20, lsl #3
    4cec:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf0:	f8746aa0 	ldr	x0, [x21, x20]
    4cf4:	f94023f9 	ldr	x25, [sp, #64]
    4cf8:	aa2003e0 	mvn	x0, x0
    4cfc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d00:	f9000260 	str	x0, [x19]
    4d04:	f8346ab3 	str	x19, [x21, x20]
    4d08:	f94a12a0 	ldr	x0, [x21, #5152]
    4d0c:	1e612800 	fadd	d0, d0, d1
    4d10:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d14:	cb020000 	sub	x0, x0, x2
    4d18:	f90a12a0 	str	x0, [x21, #5152]
    4d1c:	fd0a22a0 	str	d0, [x21, #5184]
    4d20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d24:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d28:	d65f03c0 	ret
    4d2c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4d30:	8b000063 	add	x3, x3, x0
    4d34:	eb03027f 	cmp	x19, x3
    4d38:	54fff9e1 	b.ne	4c74 <fwp_mem_free+0x64>  // b.any
    4d3c:	fd400ae1 	ldr	d1, [x23, #16]
    4d40:	fd4a2020 	ldr	d0, [x1, #5184]
    4d44:	f9400ae0 	ldr	x0, [x23, #16]
    4d48:	7e61d821 	ucvtf	d1, d1
    4d4c:	f94a1022 	ldr	x2, [x1, #5152]
    4d50:	f94012f3 	ldr	x19, [x23, #32]
    4d54:	1e612800 	fadd	d0, d0, d1
    4d58:	cb000042 	sub	x2, x2, x0
    4d5c:	f90a1022 	str	x2, [x1, #5152]
    4d60:	fd0a2020 	str	d0, [x1, #5184]
    4d64:	b40000b3 	cbz	x19, 4d78 <fwp_mem_free+0x168>
    4d68:	39400260 	ldrb	w0, [x19]
    4d6c:	7103fc1f 	cmp	w0, #0xff
    4d70:	54000380 	b.eq	4de0 <fwp_mem_free+0x1d0>  // b.none
    4d74:	3900027f 	strb	wzr, [x19]
    4d78:	b9400ee2 	ldr	w2, [x23, #12]
    4d7c:	b4000142 	cbz	x2, 4da4 <fwp_mem_free+0x194>
    4d80:	911902a1 	add	x1, x21, #0x640
    4d84:	8b160040 	add	x0, x2, x22
    4d88:	8b000800 	add	x0, x0, x0, lsl #2
    4d8c:	f949fc21 	ldr	x1, [x1, #5112]
    4d90:	8b140034 	add	x20, x1, x20
    4d94:	8b000c20 	add	x0, x1, x0, lsl #3
    4d98:	3802869f 	strb	wzr, [x20], #40
    4d9c:	eb00029f 	cmp	x20, x0
    4da0:	54ffffc1 	b.ne	4d98 <fwp_mem_free+0x188>  // b.any
    4da4:	911902a0 	add	x0, x21, #0x640
    4da8:	f94a1801 	ldr	x1, [x0, #5168]
    4dac:	f949f803 	ldr	x3, [x0, #5104]
    4db0:	8b020021 	add	x1, x1, x2
    4db4:	f90a1801 	str	x1, [x0, #5168]
    4db8:	eb16007f 	cmp	x3, x22
    4dbc:	54000049 	b.ls	4dc4 <fwp_mem_free+0x1b4>  // b.plast
    4dc0:	f909f816 	str	x22, [x0, #5104]
    4dc4:	911902b5 	add	x21, x21, #0x640
    4dc8:	f949f6a0 	ldr	x0, [x21, #5096]
    4dcc:	eb16001f 	cmp	x0, x22
    4dd0:	54fff529 	b.ls	4c74 <fwp_mem_free+0x64>  // b.plast
    4dd4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dd8:	f909f6b6 	str	x22, [x21, #5096]
    4ddc:	17ffffa7 	b	4c78 <fwp_mem_free+0x68>
    4de0:	aa1303e0 	mov	x0, x19
    4de4:	97fffeeb 	bl	4990 <fwp_rc_forget_slot>
    4de8:	17ffffe3 	b	4d74 <fwp_mem_free+0x164>
    4dec:	97fffee9 	bl	4990 <fwp_rc_forget_slot>
    4df0:	17ffffb4 	b	4cc0 <fwp_mem_free+0xb0>

0000000000004df4 <fwp_heap_alloc_big>:
    4df4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4df8:	910003fd 	mov	x29, sp
    4dfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4e00:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e04:	a90363f7 	stp	x23, x24, [sp, #48]
    4e08:	aa0003f7 	mov	x23, x0
    4e0c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e10:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e14:	eb0002ff 	cmp	x23, x0
    4e18:	54000888 	b.hi	4f28 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e1c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e20:	8b0002f4 	add	x20, x23, x0
    4e24:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xba0>
    4e28:	91190359 	add	x25, x26, #0x640
    4e2c:	d350fe94 	lsr	x20, x20, #16
    4e30:	2a0103f5 	mov	w21, w1
    4e34:	aa1403e0 	mov	x0, x20
    4e38:	97fff8be 	bl	3130 <fwp_heap_chunks>
    4e3c:	f949ff22 	ldr	x2, [x25, #5112]
    4e40:	8b000813 	add	x19, x0, x0, lsl #2
    4e44:	aa0003f8 	mov	x24, x0
    4e48:	52800043 	mov	w3, #0x2                   	// #2
    4e4c:	d37df273 	lsl	x19, x19, #3
    4e50:	d2800021 	mov	x1, #0x1                   	// #1
    4e54:	8b130040 	add	x0, x2, x19
    4e58:	38336843 	strb	w3, [x2, x19]
    4e5c:	39000415 	strb	w21, [x0, #1]
    4e60:	b9000c14 	str	w20, [x0, #12]
    4e64:	f9000817 	str	x23, [x0, #16]
    4e68:	97fffef2 	bl	4a30 <fwp_rc_prepare_chunk>
    4e6c:	f100069f 	cmp	x20, #0x1
    4e70:	54000269 	b.ls	4ebc <fwp_heap_alloc_big+0xc8>  // b.plast
    4e74:	8b180294 	add	x20, x20, x24
    4e78:	9100a273 	add	x19, x19, #0x28
    4e7c:	a90573fb 	stp	x27, x28, [sp, #80]
    4e80:	5280007b 	mov	w27, #0x3                   	// #3
    4e84:	8b140a94 	add	x20, x20, x20, lsl #2
    4e88:	2a1803fc 	mov	w28, w24
    4e8c:	9adb2296 	lsl	x22, x20, x27
    4e90:	f949ff35 	ldr	x21, [x25, #5112]
    4e94:	d2800001 	mov	x1, #0x0                   	// #0
    4e98:	8b1302b4 	add	x20, x21, x19
    4e9c:	aa1403e0 	mov	x0, x20
    4ea0:	97fffee4 	bl	4a30 <fwp_rc_prepare_chunk>
    4ea4:	38336abb 	strb	w27, [x21, x19]
    4ea8:	9100a273 	add	x19, x19, #0x28
    4eac:	b9000e9c 	str	w28, [x20, #12]
    4eb0:	eb1302df 	cmp	x22, x19
    4eb4:	54fffee1 	b.ne	4e90 <fwp_heap_alloc_big+0x9c>  // b.any
    4eb8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4ebc:	91190353 	add	x19, x26, #0x640
    4ec0:	aa1703e2 	mov	x2, x23
    4ec4:	52800001 	mov	w1, #0x0                   	// #0
    4ec8:	f949da60 	ldr	x0, [x19, #5040]
    4ecc:	8b184018 	add	x24, x0, x24, lsl #16
    4ed0:	aa1803e0 	mov	x0, x24
    4ed4:	97fff643 	bl	27e0 <memset@plt>
    4ed8:	f94a1260 	ldr	x0, [x19, #5152]
    4edc:	ab170000 	adds	x0, x0, x23
    4ee0:	54000242 	b.cs	4f28 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ee4:	f94a1661 	ldr	x1, [x19, #5160]
    4ee8:	f90a1260 	str	x0, [x19, #5152]
    4eec:	eb01001f 	cmp	x0, x1
    4ef0:	54000049 	b.ls	4ef8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ef4:	f90a1660 	str	x0, [x19, #5160]
    4ef8:	9119035a 	add	x26, x26, #0x640
    4efc:	9e6202e0 	scvtf	d0, x23
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	aa1803e0 	mov	x0, x24
    4f08:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	1e602820 	fadd	d0, d1, d0
    4f14:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f18:	fd0a1f40 	str	d0, [x26, #5176]
    4f1c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f20:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f24:	d65f03c0 	ret
    4f28:	a90573fb 	stp	x27, x28, [sp, #80]
    4f2c:	97fff871 	bl	30f0 <fwp_heap_oom>

0000000000004f30 <fwp_heap_alloc_slow>:
    4f30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xba0>
    4f40:	91190262 	add	x2, x19, #0x640
    4f44:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f48:	aa0003f5 	mov	x21, x0
    4f4c:	2a0103f4 	mov	w20, w1
    4f50:	b953a440 	ldr	w0, [x2, #5028]
    4f54:	34000600 	cbz	w0, 5014 <fwp_heap_alloc_slow+0xe4>
    4f58:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f5c:	54000628 	b.hi	5020 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f60:	91003ea0 	add	x0, x21, #0xf
    4f64:	91190262 	add	x2, x19, #0x640
    4f68:	f9001bf7 	str	x23, [sp, #48]
    4f6c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4f70:	8b401040 	add	x0, x2, x0, lsr #4
    4f74:	cb34c084 	sub	x4, x4, w20, sxtw
    4f78:	d37ae484 	lsl	x4, x4, #6
    4f7c:	397e8003 	ldrb	w3, [x0, #4000]
    4f80:	910f0060 	add	x0, x3, #0x3c0
    4f84:	aa0303e1 	mov	x1, x3
    4f88:	8b030463 	add	x3, x3, x3, lsl #1
    4f8c:	8b030c83 	add	x3, x4, x3, lsl #3
    4f90:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4f94:	2a1703f6 	mov	w22, w23
    4f98:	f8636844 	ldr	x4, [x2, x3]
    4f9c:	b40004e4 	cbz	x4, 5038 <fwp_heap_alloc_slow+0x108>
    4fa0:	f9400080 	ldr	x0, [x4]
    4fa4:	aa2003e0 	mvn	x0, x0
    4fa8:	f8236840 	str	x0, [x2, x3]
    4fac:	7100069f 	cmp	w20, #0x1
    4fb0:	aa0403e0 	mov	x0, x4
    4fb4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fb8:	52800001 	mov	w1, #0x0                   	// #0
    4fbc:	97fff609 	bl	27e0 <memset@plt>
    4fc0:	aa0003e4 	mov	x4, x0
    4fc4:	91190260 	add	x0, x19, #0x640
    4fc8:	f94a1001 	ldr	x1, [x0, #5152]
    4fcc:	ab160021 	adds	x1, x1, x22
    4fd0:	540005c2 	b.cs	5088 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4fd4:	f94a1402 	ldr	x2, [x0, #5160]
    4fd8:	f90a1001 	str	x1, [x0, #5152]
    4fdc:	eb02003f 	cmp	x1, x2
    4fe0:	54000049 	b.ls	4fe8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4fe4:	f90a1401 	str	x1, [x0, #5160]
    4fe8:	91190273 	add	x19, x19, #0x640
    4fec:	1e6302e1 	ucvtf	d1, w23
    4ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4ffc:	f9401bf7 	ldr	x23, [sp, #48]
    5000:	1e612800 	fadd	d0, d0, d1
    5004:	fd0a1e60 	str	d0, [x19, #5176]
    5008:	a94153f3 	ldp	x19, x20, [sp, #16]
    500c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5010:	d65f03c0 	ret
    5014:	97fffc1c 	bl	4084 <fwp_heap_init>
    5018:	f14012bf 	cmp	x21, #0x4, lsl #12
    501c:	54fffa29 	b.ls	4f60 <fwp_heap_alloc_slow+0x30>  // b.plast
    5020:	2a1403e1 	mov	w1, w20
    5024:	aa1503e0 	mov	x0, x21
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5030:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5034:	17ffff70 	b	4df4 <fwp_heap_alloc_big>
    5038:	8b030042 	add	x2, x2, x3
    503c:	f9400444 	ldr	x4, [x2, #8]
    5040:	b4000104 	cbz	x4, 5060 <fwp_heap_alloc_slow+0x130>
    5044:	f9400840 	ldr	x0, [x2, #16]
    5048:	cb040000 	sub	x0, x0, x4
    504c:	eb16001f 	cmp	x0, x22
    5050:	54000083 	b.cc	5060 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5054:	8b160080 	add	x0, x4, x22
    5058:	f9000440 	str	x0, [x2, #8]
    505c:	17ffffd4 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5060:	52800302 	mov	w2, #0x18                  	// #24
    5064:	52807804 	mov	w4, #0x3c0                 	// #960
    5068:	91190260 	add	x0, x19, #0x640
    506c:	9ba27c23 	umull	x3, w1, w2
    5070:	2a1403e2 	mov	w2, w20
    5074:	9b240e84 	smaddl	x4, w20, w4, x3
    5078:	8b040000 	add	x0, x0, x4
    507c:	97fffeb5 	bl	4b50 <fwp_heap_refill>
    5080:	aa0003e4 	mov	x4, x0
    5084:	17ffffca 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5088:	97fff81a 	bl	30f0 <fwp_heap_oom>
    508c:	d503201f 	nop

0000000000005090 <fwp_heap_alloc>:
    5090:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5094:	910003fd 	mov	x29, sp
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	f00000d6 	adrp	x22, 20000 <__data_start>
    50a0:	910182c2 	add	x2, x22, #0x60
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	b9413058 	ldr	w24, [x2, #304]
    50ac:	a90153f3 	stp	x19, x20, [sp, #16]
    50b0:	7100031f 	cmp	w24, #0x0
    50b4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50b8:	54000861 	b.ne	51c4 <fwp_heap_alloc+0x134>  // b.any
    50bc:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xba0>
    50c0:	911902f3 	add	x19, x23, #0x640
    50c4:	f140101f 	cmp	x0, #0x4, lsl #12
    50c8:	b953a662 	ldr	w2, [x19, #5028]
    50cc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    50d0:	54000740 	b.eq	51b8 <fwp_heap_alloc+0x128>  // b.none
    50d4:	91003c03 	add	x3, x0, #0xf
    50d8:	937c7c22 	sbfiz	x2, x1, #4, #32
    50dc:	cb21c042 	sub	x2, x2, w1, sxtw
    50e0:	8b431263 	add	x3, x19, x3, lsr #4
    50e4:	d37ae442 	lsl	x2, x2, #6
    50e8:	397e8063 	ldrb	w3, [x3, #4000]
    50ec:	910f0064 	add	x4, x3, #0x3c0
    50f0:	8b030463 	add	x3, x3, x3, lsl #1
    50f4:	8b030c43 	add	x3, x2, x3, lsl #3
    50f8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    50fc:	2a1503f4 	mov	w20, w21
    5100:	f8636a64 	ldr	x4, [x19, x3]
    5104:	b40004c4 	cbz	x4, 519c <fwp_heap_alloc+0x10c>
    5108:	f9400085 	ldr	x5, [x4]
    510c:	7100043f 	cmp	w1, #0x1
    5110:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5114:	aa0403e0 	mov	x0, x4
    5118:	aa2503e5 	mvn	x5, x5
    511c:	52800001 	mov	w1, #0x0                   	// #0
    5120:	f8236a65 	str	x5, [x19, x3]
    5124:	97fff5af 	bl	27e0 <memset@plt>
    5128:	aa0003e4 	mov	x4, x0
    512c:	f94a1260 	ldr	x0, [x19, #5152]
    5130:	ab140000 	adds	x0, x0, x20
    5134:	540006e2 	b.cs	5210 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    5138:	f94a1661 	ldr	x1, [x19, #5160]
    513c:	f90a1260 	str	x0, [x19, #5152]
    5140:	eb01001f 	cmp	x0, x1
    5144:	54000049 	b.ls	514c <fwp_heap_alloc+0xbc>  // b.plast
    5148:	f90a1660 	str	x0, [x19, #5160]
    514c:	911902e0 	add	x0, x23, #0x640
    5150:	1e6302a1 	ucvtf	d1, w21
    5154:	fd4a1c00 	ldr	d0, [x0, #5176]
    5158:	1e612800 	fadd	d0, d0, d1
    515c:	fd0a1c00 	str	d0, [x0, #5176]
    5160:	34000138 	cbz	w24, 5184 <fwp_heap_alloc+0xf4>
    5164:	911902e1 	add	x1, x23, #0x640
    5168:	910182c0 	add	x0, x22, #0x60
    516c:	fd4a1020 	ldr	d0, [x1, #5152]
    5170:	6d548402 	ldp	d2, d1, [x0, #328]
    5174:	7e61d800 	ucvtf	d0, d0
    5178:	1e623800 	fsub	d0, d0, d2
    517c:	1e612010 	fcmpe	d0, d1
    5180:	540002cc 	b.gt	51d8 <fwp_heap_alloc+0x148>
    5184:	a94153f3 	ldp	x19, x20, [sp, #16]
    5188:	aa0403e0 	mov	x0, x4
    518c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5190:	a94363f7 	ldp	x23, x24, [sp, #48]
    5194:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5198:	d65f03c0 	ret
    519c:	8b030263 	add	x3, x19, x3
    51a0:	f9400464 	ldr	x4, [x3, #8]
    51a4:	b40000a4 	cbz	x4, 51b8 <fwp_heap_alloc+0x128>
    51a8:	f9400862 	ldr	x2, [x3, #16]
    51ac:	cb040042 	sub	x2, x2, x4
    51b0:	eb02029f 	cmp	x20, x2
    51b4:	54000209 	b.ls	51f4 <fwp_heap_alloc+0x164>  // b.plast
    51b8:	97ffff5e 	bl	4f30 <fwp_heap_alloc_slow>
    51bc:	aa0003e4 	mov	x4, x0
    51c0:	17ffffe8 	b	5160 <fwp_heap_alloc+0xd0>
    51c4:	a9538c44 	ldp	x4, x3, [x2, #312]
    51c8:	91000484 	add	x4, x4, #0x1
    51cc:	8b000063 	add	x3, x3, x0
    51d0:	a9138c44 	stp	x4, x3, [x2, #312]
    51d4:	17ffffba 	b	50bc <fwp_heap_alloc+0x2c>
    51d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    51dc:	fd00a800 	str	d0, [x0, #336]
    51e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51e4:	aa0403e0 	mov	x0, x4
    51e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    51ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51f0:	d65f03c0 	ret
    51f4:	7100043f 	cmp	w1, #0x1
    51f8:	8b140085 	add	x5, x4, x20
    51fc:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5200:	52800001 	mov	w1, #0x0                   	// #0
    5204:	aa0403e0 	mov	x0, x4
    5208:	f9000465 	str	x5, [x3, #8]
    520c:	17ffffc6 	b	5124 <fwp_heap_alloc+0x94>
    5210:	97fff7b8 	bl	30f0 <fwp_heap_oom>

0000000000005214 <fwp_apply>:
    5214:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5218:	aa0003e6 	mov	x6, x0
    521c:	910003fd 	mov	x29, sp
    5220:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    5224:	f947f463 	ldr	x3, [x3, #4072]
    5228:	a90153f3 	stp	x19, x20, [sp, #16]
    522c:	aa0203f4 	mov	x20, x2
    5230:	a9025bf5 	stp	x21, x22, [sp, #32]
    5234:	2a0103f5 	mov	w21, w1
    5238:	52800033 	mov	w19, #0x1                   	// #1
    523c:	a90363f7 	stp	x23, x24, [sp, #48]
    5240:	f00000d7 	adrp	x23, 20000 <__data_start>
    5244:	910182f7 	add	x23, x23, #0x60
    5248:	a9046bf9 	stp	x25, x26, [sp, #64]
    524c:	d100c3ff 	sub	sp, sp, #0x30
    5250:	f9400060 	ldr	x0, [x3]
    5254:	f81f83a0 	stur	x0, [x29, #-8]
    5258:	d2800000 	mov	x0, #0x0                   	// #0
    525c:	294058c3 	ldp	w3, w22, [x6]
    5260:	910003f8 	mov	x24, sp
    5264:	f9406ae0 	ldr	x0, [x23, #208]
    5268:	710002df 	cmp	w22, #0x0
    526c:	d37be863 	lsl	x3, x3, #5
    5270:	8b030007 	add	x7, x0, x3
    5274:	b8636819 	ldr	w25, [x0, x3]
    5278:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    527c:	54000163 	b.cc	52a8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5280:	f94004e3 	ldr	x3, [x7, #8]
    5284:	34000bd9 	cbz	w25, 53fc <fwp_apply+0x1e8>
    5288:	aa1403e0 	mov	x0, x20
    528c:	d63f0060 	blr	x3
    5290:	aa0003e6 	mov	x6, x0
    5294:	6b1902bf 	cmp	w21, w25
    5298:	54000940 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    529c:	8b394e94 	add	x20, x20, w25, uxtw #3
    52a0:	4b1902b5 	sub	w21, w21, w25
    52a4:	17ffffee 	b	525c <fwp_apply+0x48>
    52a8:	0b1602ba 	add	w26, w21, w22
    52ac:	6b19035f 	cmp	w26, w25
    52b0:	54000543 	b.cc	5358 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    52b4:	7100033f 	cmp	w25, #0x0
    52b8:	4b16033a 	sub	w26, w25, w22
    52bc:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    52c0:	d37df000 	lsl	x0, x0, #3
    52c4:	91003c00 	add	x0, x0, #0xf
    52c8:	92704c01 	and	x1, x0, #0xfffff0000
    52cc:	927c7c00 	and	x0, x0, #0xffffffff0
    52d0:	cb2163e1 	sub	x1, sp, x1
    52d4:	eb2163ff 	cmp	sp, x1
    52d8:	540000a0 	b.eq	52ec <fwp_apply+0xd8>  // b.none
    52dc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    52e0:	f90203ff 	str	xzr, [sp, #1024]
    52e4:	eb2163ff 	cmp	sp, x1
    52e8:	54ffffa1 	b.ne	52dc <fwp_apply+0xc8>  // b.any
    52ec:	92403c00 	and	x0, x0, #0xffff
    52f0:	cb2063ff 	sub	sp, sp, x0
    52f4:	f90003ff 	str	xzr, [sp]
    52f8:	f110001f 	cmp	x0, #0x400
    52fc:	54000962 	b.cs	5428 <fwp_apply+0x214>  // b.hs, b.nlast
    5300:	910020c6 	add	x6, x6, #0x8
    5304:	910043e0 	add	x0, sp, #0x10
    5308:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    530c:	d2800003 	mov	x3, #0x0                   	// #0
    5310:	340000f6 	cbz	w22, 532c <fwp_apply+0x118>
    5314:	d503201f 	nop
    5318:	f86368c4 	ldr	x4, [x6, x3]
    531c:	f8236804 	str	x4, [x0, x3]
    5320:	91002063 	add	x3, x3, #0x8
    5324:	eb0300bf 	cmp	x5, x3
    5328:	54ffff81 	b.ne	5318 <fwp_apply+0x104>  // b.any
    532c:	3400013a 	cbz	w26, 5350 <fwp_apply+0x13c>
    5330:	2a1a03e6 	mov	w6, w26
    5334:	d2800003 	mov	x3, #0x0                   	// #0
    5338:	0b0302c4 	add	w4, w22, w3
    533c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5340:	91000463 	add	x3, x3, #0x1
    5344:	f8247805 	str	x5, [x0, x4, lsl #3]
    5348:	eb0300df 	cmp	x6, x3
    534c:	54ffff61 	b.ne	5338 <fwp_apply+0x124>  // b.any
    5350:	f94004e3 	ldr	x3, [x7, #8]
    5354:	1400002c 	b	5404 <fwp_apply+0x1f0>
    5358:	11000740 	add	w0, w26, #0x1
    535c:	52800041 	mov	w1, #0x2                   	// #2
    5360:	f81e83a6 	stur	x6, [x29, #-24]
    5364:	d37df000 	lsl	x0, x0, #3
    5368:	97ffff4a 	bl	5090 <fwp_heap_alloc>
    536c:	f85e83a6 	ldur	x6, [x29, #-24]
    5370:	aa0003f3 	mov	x19, x0
    5374:	b94000c1 	ldr	w1, [x6]
    5378:	29006801 	stp	w1, w26, [x0]
    537c:	340000b6 	cbz	w22, 5390 <fwp_apply+0x17c>
    5380:	910020c1 	add	x1, x6, #0x8
    5384:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5388:	91002000 	add	x0, x0, #0x8
    538c:	97fff4bd 	bl	2680 <memmove@plt>
    5390:	2a1503e3 	mov	w3, w21
    5394:	d2800000 	mov	x0, #0x0                   	// #0
    5398:	34000135 	cbz	w21, 53bc <fwp_apply+0x1a8>
    539c:	d503201f 	nop
    53a0:	0b0002c1 	add	w1, w22, w0
    53a4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53a8:	8b010e61 	add	x1, x19, x1, lsl #3
    53ac:	91000400 	add	x0, x0, #0x1
    53b0:	f9000422 	str	x2, [x1, #8]
    53b4:	eb00007f 	cmp	x3, x0
    53b8:	54ffff41 	b.ne	53a0 <fwp_apply+0x18c>  // b.any
    53bc:	aa1303e6 	mov	x6, x19
    53c0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    53c4:	f947f400 	ldr	x0, [x0, #4072]
    53c8:	f85f83a2 	ldur	x2, [x29, #-8]
    53cc:	f9400001 	ldr	x1, [x0]
    53d0:	eb010042 	subs	x2, x2, x1
    53d4:	d2800001 	mov	x1, #0x0                   	// #0
    53d8:	540002c1 	b.ne	5430 <fwp_apply+0x21c>  // b.any
    53dc:	910003bf 	mov	sp, x29
    53e0:	aa0603e0 	mov	x0, x6
    53e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    53f0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53f4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53f8:	d65f03c0 	ret
    53fc:	d10043a0 	sub	x0, x29, #0x10
    5400:	5280001a 	mov	w26, #0x0                   	// #0
    5404:	d63f0060 	blr	x3
    5408:	aa0003e6 	mov	x6, x0
    540c:	6b1a02bf 	cmp	w21, w26
    5410:	54fffd80 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    5414:	0b1602b6 	add	w22, w21, w22
    5418:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    541c:	4b1902d5 	sub	w21, w22, w25
    5420:	9100031f 	mov	sp, x24
    5424:	17ffff8e 	b	525c <fwp_apply+0x48>
    5428:	f90203ff 	str	xzr, [sp, #1024]
    542c:	17ffffb5 	b	5300 <fwp_apply+0xec>
    5430:	97fff4f8 	bl	2810 <__stack_chk_fail@plt>

0000000000005434 <fwp_p_ad_push>:
    5434:	f100001f 	cmp	x0, #0x0
    5438:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    543c:	540011ab 	b.lt	5670 <fwp_p_ad_push+0x23c>  // b.tstop
    5440:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5444:	910003fd 	mov	x29, sp
    5448:	a90153f3 	stp	x19, x20, [sp, #16]
    544c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5450:	aa0403f6 	mov	x22, x4
    5454:	aa0003f5 	mov	x21, x0
    5458:	a90363f7 	stp	x23, x24, [sp, #48]
    545c:	aa0203f8 	mov	x24, x2
    5460:	6d0627e8 	stp	d8, d9, [sp, #96]
    5464:	9e670029 	fmov	d9, x1
    5468:	9e670068 	fmov	d8, x3
    546c:	aa020001 	orr	x1, x0, x2
    5470:	b6f80de1 	tbz	x1, #63, 562c <fwp_p_ad_push+0x1f8>
    5474:	9360fc14 	asr	x20, x0, #32
    5478:	b6f800c0 	tbz	x0, #63, 5490 <fwp_p_ad_push+0x5c>
    547c:	1e604109 	fmov	d9, d8
    5480:	2f00e408 	movi	d8, #0x0
    5484:	9360fc54 	asr	x20, x2, #32
    5488:	aa0203f5 	mov	x21, x2
    548c:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5490:	b4001156 	cbz	x22, 56b8 <fwp_p_ad_push+0x284>
    5494:	f94002c0 	ldr	x0, [x22]
    5498:	eb14001f 	cmp	x0, x20
    549c:	54000e60 	b.eq	5668 <fwp_p_ad_push+0x234>  // b.none
    54a0:	aa1403e0 	mov	x0, x20
    54a4:	97fff983 	bl	3ab0 <fwp_tape_of>
    54a8:	aa0003f3 	mov	x19, x0
    54ac:	f9403000 	ldr	x0, [x0, #96]
    54b0:	b50010e0 	cbnz	x0, 56cc <fwp_p_ad_push+0x298>
    54b4:	a9004ed4 	stp	x20, x19, [x22]
    54b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54bc:	f9400a77 	ldr	x23, [x19, #16]
    54c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    54c4:	eb0002ff 	cmp	x23, x0
    54c8:	540013ac 	b.gt	573c <fwp_p_ad_push+0x308>
    54cc:	eb3542ff 	cmp	x23, w21, uxtw
    54d0:	540012ed 	b.le	572c <fwp_p_ad_push+0x2f8>
    54d4:	b7f80078 	tbnz	x24, #63, 54e0 <fwp_p_ad_push+0xac>
    54d8:	eb3842ff 	cmp	x23, w24, uxtw
    54dc:	5400128d 	b.le	572c <fwp_p_ad_push+0x2f8>
    54e0:	f9400676 	ldr	x22, [x19, #8]
    54e4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54e8:	cb1602f6 	sub	x22, x23, x22
    54ec:	910006c1 	add	x1, x22, #0x1
    54f0:	aa1603f9 	mov	x25, x22
    54f4:	eb00003f 	cmp	x1, x0
    54f8:	54001228 	b.hi	573c <fwp_p_ad_push+0x308>  // b.pmore
    54fc:	a9418274 	ldp	x20, x0, [x19, #24]
    5500:	eb14003f 	cmp	x1, x20
    5504:	54000a8d 	b.le	5654 <fwp_p_ad_push+0x220>
    5508:	f100029f 	cmp	x20, #0x0
    550c:	d2800803 	mov	x3, #0x40                  	// #64
    5510:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5514:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5518:	a90573fb 	stp	x27, x28, [sp, #80]
    551c:	eb14003f 	cmp	x1, x20
    5520:	5400008d 	b.le	5530 <fwp_p_ad_push+0xfc>
    5524:	eb02029f 	cmp	x20, x2
    5528:	5400092d 	b.le	564c <fwp_p_ad_push+0x218>
    552c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5530:	d37df29a 	lsl	x26, x20, #3
    5534:	52800022 	mov	w2, #0x1                   	// #1
    5538:	f940327b 	ldr	x27, [x19, #96]
    553c:	aa1a03e1 	mov	x1, x26
    5540:	97fffba5 	bl	43d4 <ad_raw_realloc>
    5544:	b4001040 	cbz	x0, 574c <fwp_p_ad_push+0x318>
    5548:	f9400e61 	ldr	x1, [x19, #24]
    554c:	8b010801 	add	x1, x0, x1, lsl #2
    5550:	a9020660 	stp	x0, x1, [x19, #32]
    5554:	b400093b 	cbz	x27, 5678 <fwp_p_ad_push+0x244>
    5558:	f9403363 	ldr	x3, [x27, #96]
    555c:	f9003be3 	str	x3, [sp, #112]
    5560:	eb03029f 	cmp	x20, x3
    5564:	5400034d 	b.le	55cc <fwp_p_ad_push+0x198>
    5568:	f940237c 	ldr	x28, [x27, #64]
    556c:	d37cee82 	lsl	x2, x20, #4
    5570:	aa0203e0 	mov	x0, x2
    5574:	52800041 	mov	w1, #0x2                   	// #2
    5578:	f9003fe2 	str	x2, [sp, #120]
    557c:	97fffec5 	bl	5090 <fwp_heap_alloc>
    5580:	aa0003fa 	mov	x26, x0
    5584:	b400013c 	cbz	x28, 55a8 <fwp_p_ad_push+0x174>
    5588:	a9470be3 	ldp	x3, x2, [sp, #112]
    558c:	aa1c03e1 	mov	x1, x28
    5590:	d37cec63 	lsl	x3, x3, #4
    5594:	eb02007f 	cmp	x3, x2
    5598:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    559c:	97fff431 	bl	2660 <memcpy@plt>
    55a0:	aa1c03e0 	mov	x0, x28
    55a4:	97fffd9b 	bl	4c10 <fwp_mem_free>
    55a8:	f9403360 	ldr	x0, [x27, #96]
    55ac:	52800001 	mov	w1, #0x0                   	// #0
    55b0:	cb000282 	sub	x2, x20, x0
    55b4:	8b001340 	add	x0, x26, x0, lsl #4
    55b8:	d37cec42 	lsl	x2, x2, #4
    55bc:	97fff489 	bl	27e0 <memset@plt>
    55c0:	f9401260 	ldr	x0, [x19, #32]
    55c4:	f900237a 	str	x26, [x27, #64]
    55c8:	f9003374 	str	x20, [x27, #96]
    55cc:	b50008b6 	cbnz	x22, 56e0 <fwp_p_ad_push+0x2ac>
    55d0:	a9431263 	ldp	x3, x4, [x19, #48]
    55d4:	d37ef69a 	lsl	x26, x20, #2
    55d8:	a94573fb 	ldp	x27, x28, [sp, #80]
    55dc:	8b1a0002 	add	x2, x0, x26
    55e0:	f9000e74 	str	x20, [x19, #24]
    55e4:	f9001662 	str	x2, [x19, #40]
    55e8:	b8366815 	str	w21, [x0, x22]
    55ec:	f100031f 	cmp	x24, #0x0
    55f0:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    55f4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55f8:	fc396869 	str	d9, [x3, x25]
    55fc:	aa1702a0 	orr	x0, x21, x23
    5600:	b8366841 	str	w1, [x2, x22]
    5604:	910006e1 	add	x1, x23, #0x1
    5608:	a9425bf5 	ldp	x21, x22, [sp, #32]
    560c:	fc396888 	str	d8, [x4, x25]
    5610:	a94363f7 	ldp	x23, x24, [sp, #48]
    5614:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5618:	6d4627e8 	ldp	d8, d9, [sp, #96]
    561c:	f9000a61 	str	x1, [x19, #16]
    5620:	a94153f3 	ldp	x19, x20, [sp, #16]
    5624:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5628:	d65f03c0 	ret
    562c:	9360fc54 	asr	x20, x2, #32
    5630:	eb80829f 	cmp	x20, x0, asr #32
    5634:	54fff2e0 	b.eq	5490 <fwp_p_ad_push+0x5c>  // b.none
    5638:	90000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    563c:	913c6000 	add	x0, x0, #0xf18
    5640:	a9046bf9 	stp	x25, x26, [sp, #64]
    5644:	a90573fb 	stp	x27, x28, [sp, #80]
    5648:	97fff84e 	bl	3780 <fwp_trap>
    564c:	d37ffa94 	lsl	x20, x20, #1
    5650:	17ffffb3 	b	551c <fwp_p_ad_push+0xe8>
    5654:	a9428e62 	ldp	x2, x3, [x19, #40]
    5658:	d37ef6d6 	lsl	x22, x22, #2
    565c:	f9401e64 	ldr	x4, [x19, #56]
    5660:	d37df339 	lsl	x25, x25, #3
    5664:	17ffffe1 	b	55e8 <fwp_p_ad_push+0x1b4>
    5668:	f94006d3 	ldr	x19, [x22, #8]
    566c:	17ffff93 	b	54b8 <fwp_p_ad_push+0x84>
    5670:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5674:	d65f03c0 	ret
    5678:	f9401a60 	ldr	x0, [x19, #48]
    567c:	d37cee81 	lsl	x1, x20, #4
    5680:	52800042 	mov	w2, #0x2                   	// #2
    5684:	97fffb54 	bl	43d4 <ad_raw_realloc>
    5688:	aa0003e3 	mov	x3, x0
    568c:	b4000600 	cbz	x0, 574c <fwp_p_ad_push+0x318>
    5690:	f9400e61 	ldr	x1, [x19, #24]
    5694:	8b1a0004 	add	x4, x0, x26
    5698:	8b010c01 	add	x1, x0, x1, lsl #3
    569c:	a9030660 	stp	x0, x1, [x19, #48]
    56a0:	b5000356 	cbnz	x22, 5708 <fwp_p_ad_push+0x2d4>
    56a4:	f9401260 	ldr	x0, [x19, #32]
    56a8:	d37ef69a 	lsl	x26, x20, #2
    56ac:	d2800016 	mov	x22, #0x0                   	// #0
    56b0:	f9001e64 	str	x4, [x19, #56]
    56b4:	17ffffc9 	b	55d8 <fwp_p_ad_push+0x1a4>
    56b8:	aa1403e0 	mov	x0, x20
    56bc:	97fff8fd 	bl	3ab0 <fwp_tape_of>
    56c0:	aa0003f3 	mov	x19, x0
    56c4:	f9403000 	ldr	x0, [x0, #96]
    56c8:	b4ffef80 	cbz	x0, 54b8 <fwp_p_ad_push+0x84>
    56cc:	90000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    56d0:	913d8000 	add	x0, x0, #0xf60
    56d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    56d8:	a90573fb 	stp	x27, x28, [sp, #80]
    56dc:	97fff829 	bl	3780 <fwp_trap>
    56e0:	d37df2d9 	lsl	x25, x22, #3
    56e4:	f9401661 	ldr	x1, [x19, #40]
    56e8:	d37ef6d6 	lsl	x22, x22, #2
    56ec:	d37ef69a 	lsl	x26, x20, #2
    56f0:	aa1603e2 	mov	x2, x22
    56f4:	8b1a0000 	add	x0, x0, x26
    56f8:	97fff3e2 	bl	2680 <memmove@plt>
    56fc:	f9401260 	ldr	x0, [x19, #32]
    5700:	a9431263 	ldp	x3, x4, [x19, #48]
    5704:	17ffffb5 	b	55d8 <fwp_p_ad_push+0x1a4>
    5708:	d37df2d9 	lsl	x25, x22, #3
    570c:	aa0403e0 	mov	x0, x4
    5710:	aa1903e2 	mov	x2, x25
    5714:	97fff3db 	bl	2680 <memmove@plt>
    5718:	f9401a61 	ldr	x1, [x19, #48]
    571c:	f9401260 	ldr	x0, [x19, #32]
    5720:	8b1a0021 	add	x1, x1, x26
    5724:	f9001e61 	str	x1, [x19, #56]
    5728:	17ffffef 	b	56e4 <fwp_p_ad_push+0x2b0>
    572c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    5730:	913ec000 	add	x0, x0, #0xfb0
    5734:	a90573fb 	stp	x27, x28, [sp, #80]
    5738:	97fff812 	bl	3780 <fwp_trap>
    573c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    5740:	913e4000 	add	x0, x0, #0xf90
    5744:	a90573fb 	stp	x27, x28, [sp, #80]
    5748:	97fff80e 	bl	3780 <fwp_trap>
    574c:	aa1303e0 	mov	x0, x19
    5750:	97fff611 	bl	2f94 <fwp_tape_unlink_scope>
    5754:	f9401260 	ldr	x0, [x19, #32]
    5758:	b4000040 	cbz	x0, 5760 <fwp_p_ad_push+0x32c>
    575c:	97fffae9 	bl	4300 <ad_raw_free.part.0>
    5760:	f9401a60 	ldr	x0, [x19, #48]
    5764:	b4000040 	cbz	x0, 576c <fwp_p_ad_push+0x338>
    5768:	97fffae6 	bl	4300 <ad_raw_free.part.0>
    576c:	f9402260 	ldr	x0, [x19, #64]
    5770:	b4000040 	cbz	x0, 5778 <fwp_p_ad_push+0x344>
    5774:	97fffae3 	bl	4300 <ad_raw_free.part.0>
    5778:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    577c:	f947e821 	ldr	x1, [x1, #4048]
    5780:	f9000e7f 	str	xzr, [x19, #24]
    5784:	4f000400 	movi	v0.4s, #0x0
    5788:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    578c:	d2800262 	mov	x2, #0x13                  	// #19
    5790:	f9400023 	ldr	x3, [x1]
    5794:	b900067f 	str	wzr, [x19, #4]
    5798:	d2800021 	mov	x1, #0x1                   	// #1
    579c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    57a0:	91286000 	add	x0, x0, #0xa18
    57a4:	3c808260 	stur	q0, [x19, #8]
    57a8:	ad010260 	stp	q0, q0, [x19, #32]
    57ac:	97fff459 	bl	2910 <fwrite@plt>
    57b0:	d2800000 	mov	x0, #0x0                   	// #0
    57b4:	97fff463 	bl	2940 <fflush@plt>
    57b8:	52800cc0 	mov	w0, #0x66                  	// #102
    57bc:	97fff471 	bl	2980 <_Exit@plt>

00000000000057c0 <w107>:
    57c0:	d10203ff 	sub	sp, sp, #0x80
    57c4:	9e660003 	fmov	x3, d0
    57c8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    57cc:	f947f442 	ldr	x2, [x2, #4072]
    57d0:	a9027bfd 	stp	x29, x30, [sp, #32]
    57d4:	910083fd 	add	x29, sp, #0x20
    57d8:	6d0627e8 	stp	d8, d9, [sp, #96]
    57dc:	1e604009 	fmov	d9, d0
    57e0:	1e604028 	fmov	d8, d1
    57e4:	fd003bea 	str	d10, [sp, #112]
    57e8:	1e60080a 	fmul	d10, d0, d0
    57ec:	a90353f3 	stp	x19, x20, [sp, #48]
    57f0:	910023f3 	add	x19, sp, #0x8
    57f4:	aa0003f4 	mov	x20, x0
    57f8:	a9045bf5 	stp	x21, x22, [sp, #64]
    57fc:	aa0103f6 	mov	x22, x1
    5800:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5804:	a90563f7 	stp	x23, x24, [sp, #80]
    5808:	aa0303e1 	mov	x1, x3
    580c:	f9400044 	ldr	x4, [x2]
    5810:	f9000fe4 	str	x4, [sp, #24]
    5814:	d2800004 	mov	x4, #0x0                   	// #0
    5818:	aa0003e2 	mov	x2, x0
    581c:	aa1303e4 	mov	x4, x19
    5820:	a900fff5 	stp	x21, xzr, [sp, #8]
    5824:	97ffff04 	bl	5434 <fwp_p_ad_push>
    5828:	1e6a3908 	fsub	d8, d8, d10
    582c:	aa1603e2 	mov	x2, x22
    5830:	aa1303e4 	mov	x4, x19
    5834:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5838:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    583c:	9e660118 	fmov	x24, d8
    5840:	97fffefd 	bl	5434 <fwp_p_ad_push>
    5844:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5848:	aa0003f6 	mov	x22, x0
    584c:	aa1303e4 	mov	x4, x19
    5850:	aa1403e0 	mov	x0, x20
    5854:	1e69394a 	fsub	d10, d10, d9
    5858:	aa1503e2 	mov	x2, x21
    585c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5860:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5864:	9e660157 	fmov	x23, d10
    5868:	97fffef3 	bl	5434 <fwp_p_ad_push>
    586c:	1e680908 	fmul	d8, d8, d8
    5870:	aa0003f4 	mov	x20, x0
    5874:	aa1303e4 	mov	x4, x19
    5878:	aa1803e3 	mov	x3, x24
    587c:	aa1803e1 	mov	x1, x24
    5880:	aa1603e2 	mov	x2, x22
    5884:	aa1603e0 	mov	x0, x22
    5888:	97fffeeb 	bl	5434 <fwp_p_ad_push>
    588c:	aa0003e2 	mov	x2, x0
    5890:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5894:	9e670029 	fmov	d9, x1
    5898:	9e660101 	fmov	x1, d8
    589c:	aa1303e4 	mov	x4, x19
    58a0:	1e690909 	fmul	d9, d8, d9
    58a4:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    58a8:	aa1503e0 	mov	x0, x21
    58ac:	97fffee2 	bl	5434 <fwp_p_ad_push>
    58b0:	1e6a094a 	fmul	d10, d10, d10
    58b4:	aa1303e4 	mov	x4, x19
    58b8:	aa1703e3 	mov	x3, x23
    58bc:	aa0003f3 	mov	x19, x0
    58c0:	aa1703e1 	mov	x1, x23
    58c4:	aa1403e2 	mov	x2, x20
    58c8:	aa1403e0 	mov	x0, x20
    58cc:	97fffeda 	bl	5434 <fwp_p_ad_push>
    58d0:	1e6a2929 	fadd	d9, d9, d10
    58d4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    58d8:	d2800004 	mov	x4, #0x0                   	// #0
    58dc:	aa0303e1 	mov	x1, x3
    58e0:	aa1303e2 	mov	x2, x19
    58e4:	97fffed4 	bl	5434 <fwp_p_ad_push>
    58e8:	aa0003e1 	mov	x1, x0
    58ec:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    58f0:	f947f463 	ldr	x3, [x3, #4072]
    58f4:	f9400fe0 	ldr	x0, [sp, #24]
    58f8:	f9400064 	ldr	x4, [x3]
    58fc:	eb040000 	subs	x0, x0, x4
    5900:	d2800004 	mov	x4, #0x0                   	// #0
    5904:	54000161 	b.ne	5930 <w107+0x170>  // b.any
    5908:	9e660122 	fmov	x2, d9
    590c:	fd403bea 	ldr	d10, [sp, #112]
    5910:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5914:	a94353f3 	ldp	x19, x20, [sp, #48]
    5918:	aa0203e0 	mov	x0, x2
    591c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5920:	a94563f7 	ldp	x23, x24, [sp, #80]
    5924:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5928:	910203ff 	add	sp, sp, #0x80
    592c:	d65f03c0 	ret
    5930:	97fff3b8 	bl	2810 <__stack_chk_fail@plt>

0000000000005934 <w164.constprop.0>:
    5934:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5938:	910003fd 	mov	x29, sp
    593c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5940:	fd001be8 	str	d8, [sp, #48]
    5944:	f9400015 	ldr	x21, [x0]
    5948:	b4000355 	cbz	x21, 59b0 <w164.constprop.0+0x7c>
    594c:	2f00e408 	movi	d8, #0x0
    5950:	91002016 	add	x22, x0, #0x8
    5954:	a90153f3 	stp	x19, x20, [sp, #16]
    5958:	91004014 	add	x20, x0, #0x10
    595c:	d2800013 	mov	x19, #0x0                   	// #0
    5960:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5964:	d503201f 	nop
    5968:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    596c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5970:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    5974:	aa0303e1 	mov	x1, x3
    5978:	1e602908 	fadd	d8, d8, d0
    597c:	d2800004 	mov	x4, #0x0                   	// #0
    5980:	91000a73 	add	x19, x19, #0x2
    5984:	97fffeac 	bl	5434 <fwp_p_ad_push>
    5988:	eb1302bf 	cmp	x21, x19
    598c:	54fffee8 	b.hi	5968 <w164.constprop.0+0x34>  // b.pmore
    5990:	9e660102 	fmov	x2, d8
    5994:	fd401be8 	ldr	d8, [sp, #48]
    5998:	a94153f3 	ldp	x19, x20, [sp, #16]
    599c:	aa0003e1 	mov	x1, x0
    59a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    59a4:	aa0203e0 	mov	x0, x2
    59a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    59ac:	d65f03c0 	ret
    59b0:	2f00e408 	movi	d8, #0x0
    59b4:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    59b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    59bc:	aa0003e1 	mov	x1, x0
    59c0:	9e660102 	fmov	x2, d8
    59c4:	fd401be8 	ldr	d8, [sp, #48]
    59c8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    59cc:	aa0203e0 	mov	x0, x2
    59d0:	d65f03c0 	ret

00000000000059d4 <fwp_data.part.0.constprop.0>:
    59d4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    59d8:	910003fd 	mov	x29, sp
    59dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    59e0:	f00000d6 	adrp	x22, 20000 <__data_start>
    59e4:	910182c2 	add	x2, x22, #0x60
    59e8:	a9046bf9 	stp	x25, x26, [sp, #64]
    59ec:	b9413059 	ldr	w25, [x2, #304]
    59f0:	a90153f3 	stp	x19, x20, [sp, #16]
    59f4:	aa0103f4 	mov	x20, x1
    59f8:	a90363f7 	stp	x23, x24, [sp, #48]
    59fc:	2a0003f7 	mov	w23, w0
    5a00:	340000b9 	cbz	w25, 5a14 <fwp_data.part.0.constprop.0+0x40>
    5a04:	a9538041 	ldp	x1, x0, [x2, #312]
    5a08:	91000421 	add	x1, x1, #0x1
    5a0c:	91006000 	add	x0, x0, #0x18
    5a10:	a9138041 	stp	x1, x0, [x2, #312]
    5a14:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xba0>
    5a18:	911902a3 	add	x3, x21, #0x640
    5a1c:	b953a460 	ldr	w0, [x3, #5028]
    5a20:	34000840 	cbz	w0, 5b28 <fwp_data.part.0.constprop.0+0x154>
    5a24:	397e8862 	ldrb	w2, [x3, #4002]
    5a28:	910f0040 	add	x0, x2, #0x3c0
    5a2c:	8b020442 	add	x2, x2, x2, lsl #1
    5a30:	d37df042 	lsl	x2, x2, #3
    5a34:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5a38:	2a1a03f8 	mov	w24, w26
    5a3c:	f8626873 	ldr	x19, [x3, x2]
    5a40:	b4000613 	cbz	x19, 5b00 <fwp_data.part.0.constprop.0+0x12c>
    5a44:	f9400260 	ldr	x0, [x19]
    5a48:	aa2003e0 	mvn	x0, x0
    5a4c:	f8226860 	str	x0, [x3, x2]
    5a50:	f100631f 	cmp	x24, #0x18
    5a54:	540000e9 	b.ls	5a70 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5a58:	d1006702 	sub	x2, x24, #0x19
    5a5c:	91006260 	add	x0, x19, #0x18
    5a60:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5a64:	52800001 	mov	w1, #0x0                   	// #0
    5a68:	91002042 	add	x2, x2, #0x8
    5a6c:	97fff35d 	bl	27e0 <memset@plt>
    5a70:	911902a0 	add	x0, x21, #0x640
    5a74:	f94a1001 	ldr	x1, [x0, #5152]
    5a78:	ab180021 	adds	x1, x1, x24
    5a7c:	54000642 	b.cs	5b44 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    5a80:	f94a1402 	ldr	x2, [x0, #5160]
    5a84:	f90a1001 	str	x1, [x0, #5152]
    5a88:	eb02003f 	cmp	x1, x2
    5a8c:	54000049 	b.ls	5a94 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5a90:	f90a1401 	str	x1, [x0, #5160]
    5a94:	911902a0 	add	x0, x21, #0x640
    5a98:	1e630341 	ucvtf	d1, w26
    5a9c:	fd4a1c00 	ldr	d0, [x0, #5176]
    5aa0:	1e612800 	fadd	d0, d0, d1
    5aa4:	fd0a1c00 	str	d0, [x0, #5176]
    5aa8:	34000139 	cbz	w25, 5acc <fwp_data.part.0.constprop.0+0xf8>
    5aac:	911902b5 	add	x21, x21, #0x640
    5ab0:	910182d6 	add	x22, x22, #0x60
    5ab4:	fd4a12a0 	ldr	d0, [x21, #5152]
    5ab8:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5abc:	7e61d800 	ucvtf	d0, d0
    5ac0:	1e623800 	fsub	d0, d0, d2
    5ac4:	1e612010 	fcmpe	d0, d1
    5ac8:	540003ac 	b.gt	5b3c <fwp_data.part.0.constprop.0+0x168>
    5acc:	52800040 	mov	w0, #0x2                   	// #2
    5ad0:	29000277 	stp	w23, w0, [x19]
    5ad4:	aa1303e0 	mov	x0, x19
    5ad8:	f9400281 	ldr	x1, [x20]
    5adc:	f9000661 	str	x1, [x19, #8]
    5ae0:	f9400681 	ldr	x1, [x20, #8]
    5ae4:	f9000a61 	str	x1, [x19, #16]
    5ae8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5af0:	a94363f7 	ldp	x23, x24, [sp, #48]
    5af4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5af8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5afc:	d65f03c0 	ret
    5b00:	8b020063 	add	x3, x3, x2
    5b04:	f9400473 	ldr	x19, [x3, #8]
    5b08:	b4000113 	cbz	x19, 5b28 <fwp_data.part.0.constprop.0+0x154>
    5b0c:	f9400860 	ldr	x0, [x3, #16]
    5b10:	cb130000 	sub	x0, x0, x19
    5b14:	eb00031f 	cmp	x24, x0
    5b18:	54000088 	b.hi	5b28 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5b1c:	8b180260 	add	x0, x19, x24
    5b20:	f9000460 	str	x0, [x3, #8]
    5b24:	17ffffcb 	b	5a50 <fwp_data.part.0.constprop.0+0x7c>
    5b28:	52800001 	mov	w1, #0x0                   	// #0
    5b2c:	d2800300 	mov	x0, #0x18                  	// #24
    5b30:	97fffd58 	bl	5090 <fwp_heap_alloc>
    5b34:	aa0003f3 	mov	x19, x0
    5b38:	17ffffdc 	b	5aa8 <fwp_data.part.0.constprop.0+0xd4>
    5b3c:	fd00aac0 	str	d0, [x22, #336]
    5b40:	17ffffe3 	b	5acc <fwp_data.part.0.constprop.0+0xf8>
    5b44:	97fff56b 	bl	30f0 <fwp_heap_oom>
    5b48:	d503201f 	nop
    5b4c:	d503201f 	nop

0000000000005b50 <fwp_rc_share>:
    5b50:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5b54:	91190042 	add	x2, x2, #0x640
    5b58:	f949d843 	ldr	x3, [x2, #5040]
    5b5c:	f949ec41 	ldr	x1, [x2, #5080]
    5b60:	cb030000 	sub	x0, x0, x3
    5b64:	eb01401f 	cmp	x0, x1, lsl #16
    5b68:	540002c2 	b.cs	5bc0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5b6c:	d350fc01 	lsr	x1, x0, #16
    5b70:	f949fc44 	ldr	x4, [x2, #5112]
    5b74:	8b010821 	add	x1, x1, x1, lsl #2
    5b78:	d37df021 	lsl	x1, x1, #3
    5b7c:	8b010083 	add	x3, x4, x1
    5b80:	f9401062 	ldr	x2, [x3, #32]
    5b84:	b40001e2 	cbz	x2, 5bc0 <fwp_rc_share+0x70>
    5b88:	38616881 	ldrb	w1, [x4, x1]
    5b8c:	7100083f 	cmp	w1, #0x2
    5b90:	540001a0 	b.eq	5bc4 <fwp_rc_share+0x74>  // b.none
    5b94:	7100043f 	cmp	w1, #0x1
    5b98:	54000141 	b.ne	5bc0 <fwp_rc_share+0x70>  // b.any
    5b9c:	29430464 	ldp	w4, w1, [x3, #24]
    5ba0:	92403c00 	and	x0, x0, #0xffff
    5ba4:	9b047c00 	mul	x0, x0, x4
    5ba8:	d360fc00 	lsr	x0, x0, #32
    5bac:	eb01001f 	cmp	x0, x1
    5bb0:	54000082 	b.cs	5bc0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5bb4:	8b000042 	add	x2, x2, x0
    5bb8:	39400040 	ldrb	w0, [x2]
    5bbc:	350000a0 	cbnz	w0, 5bd0 <fwp_rc_share+0x80>
    5bc0:	d65f03c0 	ret
    5bc4:	72003c1f 	tst	w0, #0xffff
    5bc8:	54ffff80 	b.eq	5bb8 <fwp_rc_share+0x68>  // b.none
    5bcc:	d65f03c0 	ret
    5bd0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5bd4:	90000040 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    5bd8:	913f4000 	add	x0, x0, #0xfd0
    5bdc:	910003fd 	mov	x29, sp
    5be0:	97fff6e8 	bl	3780 <fwp_trap>

0000000000005be4 <fwp_rc_fresh>:
    5be4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5be8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5bec:	91190063 	add	x3, x3, #0x640
    5bf0:	910003fd 	mov	x29, sp
    5bf4:	a90153f3 	stp	x19, x20, [sp, #16]
    5bf8:	aa0003f3 	mov	x19, x0
    5bfc:	f949d861 	ldr	x1, [x3, #5040]
    5c00:	f949ec60 	ldr	x0, [x3, #5080]
    5c04:	cb010261 	sub	x1, x19, x1
    5c08:	eb00403f 	cmp	x1, x0, lsl #16
    5c0c:	54000322 	b.cs	5c70 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5c10:	d350fc22 	lsr	x2, x1, #16
    5c14:	f949fc63 	ldr	x3, [x3, #5112]
    5c18:	8b020842 	add	x2, x2, x2, lsl #2
    5c1c:	d37df042 	lsl	x2, x2, #3
    5c20:	8b020060 	add	x0, x3, x2
    5c24:	f9401014 	ldr	x20, [x0, #32]
    5c28:	b4000254 	cbz	x20, 5c70 <fwp_rc_fresh+0x8c>
    5c2c:	38626862 	ldrb	w2, [x3, x2]
    5c30:	7100085f 	cmp	w2, #0x2
    5c34:	54000260 	b.eq	5c80 <fwp_rc_fresh+0x9c>  // b.none
    5c38:	7100045f 	cmp	w2, #0x1
    5c3c:	540001a1 	b.ne	5c70 <fwp_rc_fresh+0x8c>  // b.any
    5c40:	29430002 	ldp	w2, w0, [x0, #24]
    5c44:	92403c21 	and	x1, x1, #0xffff
    5c48:	9b027c21 	mul	x1, x1, x2
    5c4c:	d360fc21 	lsr	x1, x1, #32
    5c50:	eb00003f 	cmp	x1, x0
    5c54:	540000e2 	b.cs	5c70 <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5c58:	8b010294 	add	x20, x20, x1
    5c5c:	39400280 	ldrb	w0, [x20]
    5c60:	7103fc1f 	cmp	w0, #0xff
    5c64:	540001a0 	b.eq	5c98 <fwp_rc_fresh+0xb4>  // b.none
    5c68:	52800020 	mov	w0, #0x1                   	// #1
    5c6c:	39000280 	strb	w0, [x20]
    5c70:	aa1303e0 	mov	x0, x19
    5c74:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c78:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c7c:	d65f03c0 	ret
    5c80:	72003c3f 	tst	w1, #0xffff
    5c84:	54fffec0 	b.eq	5c5c <fwp_rc_fresh+0x78>  // b.none
    5c88:	aa1303e0 	mov	x0, x19
    5c8c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5c94:	d65f03c0 	ret
    5c98:	aa1403e0 	mov	x0, x20
    5c9c:	97fffb3d 	bl	4990 <fwp_rc_forget_slot>
    5ca0:	17fffff2 	b	5c68 <fwp_rc_fresh+0x84>

0000000000005ca4 <fwp_rc_free_arr>:
    5ca4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5ca8:	91190063 	add	x3, x3, #0x640
    5cac:	f949d861 	ldr	x1, [x3, #5040]
    5cb0:	f949ec62 	ldr	x2, [x3, #5080]
    5cb4:	cb010001 	sub	x1, x0, x1
    5cb8:	eb02403f 	cmp	x1, x2, lsl #16
    5cbc:	54000342 	b.cs	5d24 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5cc0:	d350fc22 	lsr	x2, x1, #16
    5cc4:	f949fc65 	ldr	x5, [x3, #5112]
    5cc8:	8b020842 	add	x2, x2, x2, lsl #2
    5ccc:	d37df042 	lsl	x2, x2, #3
    5cd0:	8b0200a4 	add	x4, x5, x2
    5cd4:	f9401083 	ldr	x3, [x4, #32]
    5cd8:	b4000263 	cbz	x3, 5d24 <fwp_rc_free_arr+0x80>
    5cdc:	386268a2 	ldrb	w2, [x5, x2]
    5ce0:	7100085f 	cmp	w2, #0x2
    5ce4:	540001c0 	b.eq	5d1c <fwp_rc_free_arr+0x78>  // b.none
    5ce8:	7100045f 	cmp	w2, #0x1
    5cec:	540001c1 	b.ne	5d24 <fwp_rc_free_arr+0x80>  // b.any
    5cf0:	29430885 	ldp	w5, w2, [x4, #24]
    5cf4:	92403c21 	and	x1, x1, #0xffff
    5cf8:	9b057c21 	mul	x1, x1, x5
    5cfc:	d360fc21 	lsr	x1, x1, #32
    5d00:	eb02003f 	cmp	x1, x2
    5d04:	54000102 	b.cs	5d24 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5d08:	8b010063 	add	x3, x3, x1
    5d0c:	39400061 	ldrb	w1, [x3]
    5d10:	7100043f 	cmp	w1, #0x1
    5d14:	54000081 	b.ne	5d24 <fwp_rc_free_arr+0x80>  // b.any
    5d18:	17fffbbe 	b	4c10 <fwp_mem_free>
    5d1c:	72003c3f 	tst	w1, #0xffff
    5d20:	54ffff60 	b.eq	5d0c <fwp_rc_free_arr+0x68>  // b.none
    5d24:	d65f03c0 	ret
    5d28:	d503201f 	nop
    5d2c:	d503201f 	nop

0000000000005d30 <fwp_rc_dup>:
    5d30:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xba0>
    5d34:	91190042 	add	x2, x2, #0x640
    5d38:	f949d841 	ldr	x1, [x2, #5040]
    5d3c:	f949ec43 	ldr	x3, [x2, #5080]
    5d40:	cb010001 	sub	x1, x0, x1
    5d44:	eb03403f 	cmp	x1, x3, lsl #16
    5d48:	540003c2 	b.cs	5dc0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5d4c:	d350fc20 	lsr	x0, x1, #16
    5d50:	f949fc44 	ldr	x4, [x2, #5112]
    5d54:	8b000800 	add	x0, x0, x0, lsl #2
    5d58:	d37df002 	lsl	x2, x0, #3
    5d5c:	8b020083 	add	x3, x4, x2
    5d60:	f9401060 	ldr	x0, [x3, #32]
    5d64:	b40002e0 	cbz	x0, 5dc0 <fwp_rc_dup+0x90>
    5d68:	38626882 	ldrb	w2, [x4, x2]
    5d6c:	7100085f 	cmp	w2, #0x2
    5d70:	540002a0 	b.eq	5dc4 <fwp_rc_dup+0x94>  // b.none
    5d74:	7100045f 	cmp	w2, #0x1
    5d78:	54000241 	b.ne	5dc0 <fwp_rc_dup+0x90>  // b.any
    5d7c:	29430864 	ldp	w4, w2, [x3, #24]
    5d80:	92403c21 	and	x1, x1, #0xffff
    5d84:	9b047c21 	mul	x1, x1, x4
    5d88:	d360fc21 	lsr	x1, x1, #32
    5d8c:	eb02003f 	cmp	x1, x2
    5d90:	54000182 	b.cs	5dc0 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5d94:	8b010000 	add	x0, x0, x1
    5d98:	39400001 	ldrb	w1, [x0]
    5d9c:	34000121 	cbz	w1, 5dc0 <fwp_rc_dup+0x90>
    5da0:	f00000c2 	adrp	x2, 20000 <__data_start>
    5da4:	91018042 	add	x2, x2, #0x60
    5da8:	b9413043 	ldr	w3, [x2, #304]
    5dac:	35000123 	cbnz	w3, 5dd0 <fwp_rc_dup+0xa0>
    5db0:	7103f43f 	cmp	w1, #0xfd
    5db4:	54000168 	b.hi	5de0 <fwp_rc_dup+0xb0>  // b.pmore
    5db8:	11000421 	add	w1, w1, #0x1
    5dbc:	39000001 	strb	w1, [x0]
    5dc0:	d65f03c0 	ret
    5dc4:	72003c3f 	tst	w1, #0xffff
    5dc8:	54fffe80 	b.eq	5d98 <fwp_rc_dup+0x68>  // b.none
    5dcc:	d65f03c0 	ret
    5dd0:	f940ac43 	ldr	x3, [x2, #344]
    5dd4:	91000463 	add	x3, x3, #0x1
    5dd8:	f900ac43 	str	x3, [x2, #344]
    5ddc:	17fffff5 	b	5db0 <fwp_rc_dup+0x80>
    5de0:	17fffaa5 	b	4874 <fwp_rc_wide_dup>

0000000000005de4 <fwp_owned_entry161>:
    5de4:	d10103ff 	sub	sp, sp, #0x40
    5de8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5dec:	f947f442 	ldr	x2, [x2, #4072]
    5df0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5df4:	910083fd 	add	x29, sp, #0x20
    5df8:	a90353f3 	stp	x19, x20, [sp, #48]
    5dfc:	f9400043 	ldr	x3, [x2]
    5e00:	f9000fe3 	str	x3, [sp, #24]
    5e04:	d2800003 	mov	x3, #0x0                   	// #0
    5e08:	a9400c01 	ldp	x1, x3, [x0]
    5e0c:	f9400802 	ldr	x2, [x0, #16]
    5e10:	ab020022 	adds	x2, x1, x2
    5e14:	540006e6 	b.vs	5ef0 <fwp_owned_entry161+0x10c>
    5e18:	910023e1 	add	x1, sp, #0x8
    5e1c:	52800000 	mov	w0, #0x0                   	// #0
    5e20:	a9008be3 	stp	x3, x2, [sp, #8]
    5e24:	97fffeec 	bl	59d4 <fwp_data.part.0.constprop.0>
    5e28:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5e2c:	91190063 	add	x3, x3, #0x640
    5e30:	aa0003f3 	mov	x19, x0
    5e34:	f949d861 	ldr	x1, [x3, #5040]
    5e38:	f949ec60 	ldr	x0, [x3, #5080]
    5e3c:	cb010261 	sub	x1, x19, x1
    5e40:	eb00403f 	cmp	x1, x0, lsl #16
    5e44:	54000322 	b.cs	5ea8 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5e48:	d350fc22 	lsr	x2, x1, #16
    5e4c:	f949fc63 	ldr	x3, [x3, #5112]
    5e50:	8b020842 	add	x2, x2, x2, lsl #2
    5e54:	d37df042 	lsl	x2, x2, #3
    5e58:	8b020060 	add	x0, x3, x2
    5e5c:	f9401014 	ldr	x20, [x0, #32]
    5e60:	b4000254 	cbz	x20, 5ea8 <fwp_owned_entry161+0xc4>
    5e64:	38626862 	ldrb	w2, [x3, x2]
    5e68:	7100085f 	cmp	w2, #0x2
    5e6c:	54000360 	b.eq	5ed8 <fwp_owned_entry161+0xf4>  // b.none
    5e70:	7100045f 	cmp	w2, #0x1
    5e74:	540001a1 	b.ne	5ea8 <fwp_owned_entry161+0xc4>  // b.any
    5e78:	29430002 	ldp	w2, w0, [x0, #24]
    5e7c:	92403c21 	and	x1, x1, #0xffff
    5e80:	9b027c21 	mul	x1, x1, x2
    5e84:	d360fc21 	lsr	x1, x1, #32
    5e88:	eb00003f 	cmp	x1, x0
    5e8c:	540000e2 	b.cs	5ea8 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5e90:	8b010294 	add	x20, x20, x1
    5e94:	39400280 	ldrb	w0, [x20]
    5e98:	7103fc1f 	cmp	w0, #0xff
    5e9c:	54000240 	b.eq	5ee4 <fwp_owned_entry161+0x100>  // b.none
    5ea0:	52800020 	mov	w0, #0x1                   	// #1
    5ea4:	39000280 	strb	w0, [x20]
    5ea8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5eac:	f947f400 	ldr	x0, [x0, #4072]
    5eb0:	f9400fe2 	ldr	x2, [sp, #24]
    5eb4:	f9400001 	ldr	x1, [x0]
    5eb8:	eb010042 	subs	x2, x2, x1
    5ebc:	d2800001 	mov	x1, #0x0                   	// #0
    5ec0:	540001a1 	b.ne	5ef4 <fwp_owned_entry161+0x110>  // b.any
    5ec4:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5ec8:	aa1303e0 	mov	x0, x19
    5ecc:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ed0:	910103ff 	add	sp, sp, #0x40
    5ed4:	d65f03c0 	ret
    5ed8:	72003c3f 	tst	w1, #0xffff
    5edc:	54fffe61 	b.ne	5ea8 <fwp_owned_entry161+0xc4>  // b.any
    5ee0:	17ffffed 	b	5e94 <fwp_owned_entry161+0xb0>
    5ee4:	aa1403e0 	mov	x0, x20
    5ee8:	97fffaaa 	bl	4990 <fwp_rc_forget_slot>
    5eec:	17ffffed 	b	5ea0 <fwp_owned_entry161+0xbc>
    5ef0:	97fff2c4 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5ef4:	97fff247 	bl	2810 <__stack_chk_fail@plt>
    5ef8:	d503201f 	nop
    5efc:	d503201f 	nop

0000000000005f00 <e161>:
    5f00:	d10103ff 	sub	sp, sp, #0x40
    5f04:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5f08:	f947f442 	ldr	x2, [x2, #4072]
    5f0c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5f10:	910083fd 	add	x29, sp, #0x20
    5f14:	a90353f3 	stp	x19, x20, [sp, #48]
    5f18:	f9400043 	ldr	x3, [x2]
    5f1c:	f9000fe3 	str	x3, [sp, #24]
    5f20:	d2800003 	mov	x3, #0x0                   	// #0
    5f24:	a9400c01 	ldp	x1, x3, [x0]
    5f28:	f9400802 	ldr	x2, [x0, #16]
    5f2c:	ab020022 	adds	x2, x1, x2
    5f30:	54000726 	b.vs	6014 <e161+0x114>
    5f34:	910023e1 	add	x1, sp, #0x8
    5f38:	52800000 	mov	w0, #0x0                   	// #0
    5f3c:	a9008be3 	stp	x3, x2, [sp, #8]
    5f40:	97fffea5 	bl	59d4 <fwp_data.part.0.constprop.0>
    5f44:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xba0>
    5f48:	91190063 	add	x3, x3, #0x640
    5f4c:	aa0003f3 	mov	x19, x0
    5f50:	f949d861 	ldr	x1, [x3, #5040]
    5f54:	f949ec60 	ldr	x0, [x3, #5080]
    5f58:	cb010261 	sub	x1, x19, x1
    5f5c:	eb00403f 	cmp	x1, x0, lsl #16
    5f60:	54000322 	b.cs	5fc4 <e161+0xc4>  // b.hs, b.nlast
    5f64:	d350fc22 	lsr	x2, x1, #16
    5f68:	f949fc63 	ldr	x3, [x3, #5112]
    5f6c:	8b020842 	add	x2, x2, x2, lsl #2
    5f70:	d37df042 	lsl	x2, x2, #3
    5f74:	8b020060 	add	x0, x3, x2
    5f78:	f9401014 	ldr	x20, [x0, #32]
    5f7c:	b4000254 	cbz	x20, 5fc4 <e161+0xc4>
    5f80:	38626862 	ldrb	w2, [x3, x2]
    5f84:	7100085f 	cmp	w2, #0x2
    5f88:	540003a0 	b.eq	5ffc <e161+0xfc>  // b.none
    5f8c:	7100045f 	cmp	w2, #0x1
    5f90:	540001a1 	b.ne	5fc4 <e161+0xc4>  // b.any
    5f94:	29430002 	ldp	w2, w0, [x0, #24]
    5f98:	92403c21 	and	x1, x1, #0xffff
    5f9c:	9b027c21 	mul	x1, x1, x2
    5fa0:	d360fc21 	lsr	x1, x1, #32
    5fa4:	eb00003f 	cmp	x1, x0
    5fa8:	540000e2 	b.cs	5fc4 <e161+0xc4>  // b.hs, b.nlast
    5fac:	8b010294 	add	x20, x20, x1
    5fb0:	39400280 	ldrb	w0, [x20]
    5fb4:	7103fc1f 	cmp	w0, #0xff
    5fb8:	54000280 	b.eq	6008 <e161+0x108>  // b.none
    5fbc:	52800020 	mov	w0, #0x1                   	// #1
    5fc0:	39000280 	strb	w0, [x20]
    5fc4:	aa1303e0 	mov	x0, x19
    5fc8:	97fffee2 	bl	5b50 <fwp_rc_share>
    5fcc:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5fd0:	f947f400 	ldr	x0, [x0, #4072]
    5fd4:	f9400fe2 	ldr	x2, [sp, #24]
    5fd8:	f9400001 	ldr	x1, [x0]
    5fdc:	eb010042 	subs	x2, x2, x1
    5fe0:	d2800001 	mov	x1, #0x0                   	// #0
    5fe4:	540001a1 	b.ne	6018 <e161+0x118>  // b.any
    5fe8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5fec:	aa1303e0 	mov	x0, x19
    5ff0:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ff4:	910103ff 	add	sp, sp, #0x40
    5ff8:	d65f03c0 	ret
    5ffc:	72003c3f 	tst	w1, #0xffff
    6000:	54fffe21 	b.ne	5fc4 <e161+0xc4>  // b.any
    6004:	17ffffeb 	b	5fb0 <e161+0xb0>
    6008:	aa1403e0 	mov	x0, x20
    600c:	97fffa61 	bl	4990 <fwp_rc_forget_slot>
    6010:	17ffffeb 	b	5fbc <e161+0xbc>
    6014:	97fff27b 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6018:	97fff1fe 	bl	2810 <__stack_chk_fail@plt>
    601c:	d503201f 	nop

0000000000006020 <fwp_drop1>:
    6020:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6024:	910003fd 	mov	x29, sp
    6028:	a90153f3 	stp	x19, x20, [sp, #16]
    602c:	f90013f5 	str	x21, [sp, #32]
    6030:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xba0>
    6034:	911902b4 	add	x20, x21, #0x640
    6038:	f949da81 	ldr	x1, [x20, #5040]
    603c:	f949ee82 	ldr	x2, [x20, #5080]
    6040:	cb010001 	sub	x1, x0, x1
    6044:	eb02403f 	cmp	x1, x2, lsl #16
    6048:	54000382 	b.cs	60b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    604c:	d350fc22 	lsr	x2, x1, #16
    6050:	f949fe84 	ldr	x4, [x20, #5112]
    6054:	8b020842 	add	x2, x2, x2, lsl #2
    6058:	d37df042 	lsl	x2, x2, #3
    605c:	8b020083 	add	x3, x4, x2
    6060:	f9401073 	ldr	x19, [x3, #32]
    6064:	b40002b3 	cbz	x19, 60b8 <fwp_drop1+0x98>
    6068:	38626882 	ldrb	w2, [x4, x2]
    606c:	7100085f 	cmp	w2, #0x2
    6070:	540002c0 	b.eq	60c8 <fwp_drop1+0xa8>  // b.none
    6074:	7100045f 	cmp	w2, #0x1
    6078:	54000201 	b.ne	60b8 <fwp_drop1+0x98>  // b.any
    607c:	29430864 	ldp	w4, w2, [x3, #24]
    6080:	92403c21 	and	x1, x1, #0xffff
    6084:	9b047c21 	mul	x1, x1, x4
    6088:	d360fc21 	lsr	x1, x1, #32
    608c:	eb02003f 	cmp	x1, x2
    6090:	54000142 	b.cs	60b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6094:	8b010273 	add	x19, x19, x1
    6098:	39400261 	ldrb	w1, [x19]
    609c:	340000e1 	cbz	w1, 60b8 <fwp_drop1+0x98>
    60a0:	7100043f 	cmp	w1, #0x1
    60a4:	540001e0 	b.eq	60e0 <fwp_drop1+0xc0>  // b.none
    60a8:	7103fc3f 	cmp	w1, #0xff
    60ac:	540002e0 	b.eq	6108 <fwp_drop1+0xe8>  // b.none
    60b0:	51000421 	sub	w1, w1, #0x1
    60b4:	39000261 	strb	w1, [x19]
    60b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    60bc:	f94013f5 	ldr	x21, [sp, #32]
    60c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60c4:	d65f03c0 	ret
    60c8:	72003c3f 	tst	w1, #0xffff
    60cc:	54fffe60 	b.eq	6098 <fwp_drop1+0x78>  // b.none
    60d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    60d4:	f94013f5 	ldr	x21, [sp, #32]
    60d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    60dc:	d65f03c0 	ret
    60e0:	f9400813 	ldr	x19, [x0, #16]
    60e4:	97fffef0 	bl	5ca4 <fwp_rc_free_arr>
    60e8:	911902a0 	add	x0, x21, #0x640
    60ec:	f949d801 	ldr	x1, [x0, #5040]
    60f0:	f949ec00 	ldr	x0, [x0, #5080]
    60f4:	cb010261 	sub	x1, x19, x1
    60f8:	eb00403f 	cmp	x1, x0, lsl #16
    60fc:	54fffde2 	b.cs	60b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6100:	aa1303e0 	mov	x0, x19
    6104:	17ffffd2 	b	604c <fwp_drop1+0x2c>
    6108:	ca534660 	eor	x0, x19, x19, lsr #17
    610c:	911902b5 	add	x21, x21, #0x640
    6110:	ca402400 	eor	x0, x0, x0, lsr #9
    6114:	8b200ea0 	add	x0, x21, w0, uxtb #3
    6118:	f94a2400 	ldr	x0, [x0, #5192]
    611c:	b5000080 	cbnz	x0, 612c <fwp_drop1+0x10c>
    6120:	14000010 	b	6160 <fwp_drop1+0x140>
    6124:	f9400800 	ldr	x0, [x0, #16]
    6128:	b40001c0 	cbz	x0, 6160 <fwp_drop1+0x140>
    612c:	f9400001 	ldr	x1, [x0]
    6130:	eb13003f 	cmp	x1, x19
    6134:	54ffff81 	b.ne	6124 <fwp_drop1+0x104>  // b.any
    6138:	f9400401 	ldr	x1, [x0, #8]
    613c:	d1000421 	sub	x1, x1, #0x1
    6140:	f9000401 	str	x1, [x0, #8]
    6144:	f103f83f 	cmp	x1, #0xfe
    6148:	54fffb81 	b.ne	60b8 <fwp_drop1+0x98>  // b.any
    614c:	aa1303e0 	mov	x0, x19
    6150:	97fffa10 	bl	4990 <fwp_rc_forget_slot>
    6154:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6158:	39000260 	strb	w0, [x19]
    615c:	17ffffd7 	b	60b8 <fwp_drop1+0x98>
    6160:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    6164:	913b4000 	add	x0, x0, #0xed0
    6168:	97fff586 	bl	3780 <fwp_trap>
    616c:	d503201f 	nop

0000000000006170 <fwp_drop0>:
    6170:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6174:	910003fd 	mov	x29, sp
    6178:	a90153f3 	stp	x19, x20, [sp, #16]
    617c:	f90013f5 	str	x21, [sp, #32]
    6180:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xba0>
    6184:	911902b4 	add	x20, x21, #0x640
    6188:	f949da81 	ldr	x1, [x20, #5040]
    618c:	f949ee82 	ldr	x2, [x20, #5080]
    6190:	cb010001 	sub	x1, x0, x1
    6194:	eb02403f 	cmp	x1, x2, lsl #16
    6198:	54000382 	b.cs	6208 <fwp_drop0+0x98>  // b.hs, b.nlast
    619c:	d350fc22 	lsr	x2, x1, #16
    61a0:	f949fe84 	ldr	x4, [x20, #5112]
    61a4:	8b020842 	add	x2, x2, x2, lsl #2
    61a8:	d37df042 	lsl	x2, x2, #3
    61ac:	8b020083 	add	x3, x4, x2
    61b0:	f9401073 	ldr	x19, [x3, #32]
    61b4:	b40002b3 	cbz	x19, 6208 <fwp_drop0+0x98>
    61b8:	38626882 	ldrb	w2, [x4, x2]
    61bc:	7100085f 	cmp	w2, #0x2
    61c0:	540002c0 	b.eq	6218 <fwp_drop0+0xa8>  // b.none
    61c4:	7100045f 	cmp	w2, #0x1
    61c8:	54000201 	b.ne	6208 <fwp_drop0+0x98>  // b.any
    61cc:	29430864 	ldp	w4, w2, [x3, #24]
    61d0:	92403c21 	and	x1, x1, #0xffff
    61d4:	9b047c21 	mul	x1, x1, x4
    61d8:	d360fc21 	lsr	x1, x1, #32
    61dc:	eb02003f 	cmp	x1, x2
    61e0:	54000142 	b.cs	6208 <fwp_drop0+0x98>  // b.hs, b.nlast
    61e4:	8b010273 	add	x19, x19, x1
    61e8:	39400261 	ldrb	w1, [x19]
    61ec:	340000e1 	cbz	w1, 6208 <fwp_drop0+0x98>
    61f0:	7100043f 	cmp	w1, #0x1
    61f4:	540001e0 	b.eq	6230 <fwp_drop0+0xc0>  // b.none
    61f8:	7103fc3f 	cmp	w1, #0xff
    61fc:	540002e0 	b.eq	6258 <fwp_drop0+0xe8>  // b.none
    6200:	51000421 	sub	w1, w1, #0x1
    6204:	39000261 	strb	w1, [x19]
    6208:	a94153f3 	ldp	x19, x20, [sp, #16]
    620c:	f94013f5 	ldr	x21, [sp, #32]
    6210:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6214:	d65f03c0 	ret
    6218:	72003c3f 	tst	w1, #0xffff
    621c:	54fffe60 	b.eq	61e8 <fwp_drop0+0x78>  // b.none
    6220:	a94153f3 	ldp	x19, x20, [sp, #16]
    6224:	f94013f5 	ldr	x21, [sp, #32]
    6228:	a8c37bfd 	ldp	x29, x30, [sp], #48
    622c:	d65f03c0 	ret
    6230:	f9400813 	ldr	x19, [x0, #16]
    6234:	97fffe9c 	bl	5ca4 <fwp_rc_free_arr>
    6238:	911902a0 	add	x0, x21, #0x640
    623c:	f949d801 	ldr	x1, [x0, #5040]
    6240:	f949ec00 	ldr	x0, [x0, #5080]
    6244:	cb010261 	sub	x1, x19, x1
    6248:	eb00403f 	cmp	x1, x0, lsl #16
    624c:	54fffde2 	b.cs	6208 <fwp_drop0+0x98>  // b.hs, b.nlast
    6250:	aa1303e0 	mov	x0, x19
    6254:	17ffffd2 	b	619c <fwp_drop0+0x2c>
    6258:	ca534660 	eor	x0, x19, x19, lsr #17
    625c:	911902b5 	add	x21, x21, #0x640
    6260:	ca402400 	eor	x0, x0, x0, lsr #9
    6264:	8b200ea0 	add	x0, x21, w0, uxtb #3
    6268:	f94a2400 	ldr	x0, [x0, #5192]
    626c:	b5000080 	cbnz	x0, 627c <fwp_drop0+0x10c>
    6270:	14000010 	b	62b0 <fwp_drop0+0x140>
    6274:	f9400800 	ldr	x0, [x0, #16]
    6278:	b40001c0 	cbz	x0, 62b0 <fwp_drop0+0x140>
    627c:	f9400001 	ldr	x1, [x0]
    6280:	eb13003f 	cmp	x1, x19
    6284:	54ffff81 	b.ne	6274 <fwp_drop0+0x104>  // b.any
    6288:	f9400401 	ldr	x1, [x0, #8]
    628c:	d1000421 	sub	x1, x1, #0x1
    6290:	f9000401 	str	x1, [x0, #8]
    6294:	f103f83f 	cmp	x1, #0xfe
    6298:	54fffb81 	b.ne	6208 <fwp_drop0+0x98>  // b.any
    629c:	aa1303e0 	mov	x0, x19
    62a0:	97fff9bc 	bl	4990 <fwp_rc_forget_slot>
    62a4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62a8:	39000260 	strb	w0, [x19]
    62ac:	17ffffd7 	b	6208 <fwp_drop0+0x98>
    62b0:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    62b4:	913b4000 	add	x0, x0, #0xed0
    62b8:	97fff532 	bl	3780 <fwp_trap>
    62bc:	d503201f 	nop

00000000000062c0 <fwp_arg_drop12>:
    62c0:	7100003f 	cmp	w1, #0x0
    62c4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    62c8:	54000041 	b.ne	62d0 <fwp_arg_drop12+0x10>  // b.any
    62cc:	d65f03c0 	ret
    62d0:	f9400000 	ldr	x0, [x0]
    62d4:	17ffffa7 	b	6170 <fwp_drop0>
    62d8:	d503201f 	nop
    62dc:	d503201f 	nop

00000000000062e0 <fwp_closure_drop>:
    62e0:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xba0>
    62e4:	911900a4 	add	x4, x5, #0x640
    62e8:	aa0003e1 	mov	x1, x0
    62ec:	f949d882 	ldr	x2, [x4, #5040]
    62f0:	f949ec80 	ldr	x0, [x4, #5080]
    62f4:	cb020022 	sub	x2, x1, x2
    62f8:	eb00405f 	cmp	x2, x0, lsl #16
    62fc:	54000662 	b.cs	63c8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6304:	d350fc43 	lsr	x3, x2, #16
    6308:	910003fd 	mov	x29, sp
    630c:	8b030863 	add	x3, x3, x3, lsl #2
    6310:	f949fc84 	ldr	x4, [x4, #5112]
    6314:	d37df063 	lsl	x3, x3, #3
    6318:	f9000bf3 	str	x19, [sp, #16]
    631c:	8b030080 	add	x0, x4, x3
    6320:	f9401013 	ldr	x19, [x0, #32]
    6324:	b40002b3 	cbz	x19, 6378 <fwp_closure_drop+0x98>
    6328:	38636883 	ldrb	w3, [x4, x3]
    632c:	7100087f 	cmp	w3, #0x2
    6330:	54000420 	b.eq	63b4 <fwp_closure_drop+0xd4>  // b.none
    6334:	7100047f 	cmp	w3, #0x1
    6338:	54000201 	b.ne	6378 <fwp_closure_drop+0x98>  // b.any
    633c:	29430003 	ldp	w3, w0, [x0, #24]
    6340:	92403c42 	and	x2, x2, #0xffff
    6344:	9b037c42 	mul	x2, x2, x3
    6348:	d360fc42 	lsr	x2, x2, #32
    634c:	eb00005f 	cmp	x2, x0
    6350:	54000142 	b.cs	6378 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6354:	8b020273 	add	x19, x19, x2
    6358:	39400260 	ldrb	w0, [x19]
    635c:	340000e0 	cbz	w0, 6378 <fwp_closure_drop+0x98>
    6360:	7100041f 	cmp	w0, #0x1
    6364:	54000100 	b.eq	6384 <fwp_closure_drop+0xa4>  // b.none
    6368:	7103fc1f 	cmp	w0, #0xff
    636c:	54000300 	b.eq	63cc <fwp_closure_drop+0xec>  // b.none
    6370:	51000400 	sub	w0, w0, #0x1
    6374:	39000260 	strb	w0, [x19]
    6378:	f9400bf3 	ldr	x19, [sp, #16]
    637c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6380:	d65f03c0 	ret
    6384:	d53bd040 	mrs	x0, tpidr_el0
    6388:	91400000 	add	x0, x0, #0x0, lsl #12
    638c:	91004000 	add	x0, x0, #0x10
    6390:	f9400000 	ldr	x0, [x0]
    6394:	b4000080 	cbz	x0, 63a4 <fwp_closure_drop+0xc4>
    6398:	f9400bf3 	ldr	x19, [sp, #16]
    639c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63a0:	17fff511 	b	37e4 <fwp_closure_drop_push>
    63a4:	f9400bf3 	ldr	x19, [sp, #16]
    63a8:	aa0103e0 	mov	x0, x1
    63ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63b0:	17fff57c 	b	39a0 <fwp_closure_drop.part.0>
    63b4:	72003c5f 	tst	w2, #0xffff
    63b8:	54fffd00 	b.eq	6358 <fwp_closure_drop+0x78>  // b.none
    63bc:	f9400bf3 	ldr	x19, [sp, #16]
    63c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    63c4:	d65f03c0 	ret
    63c8:	d65f03c0 	ret
    63cc:	ca534660 	eor	x0, x19, x19, lsr #17
    63d0:	911900a5 	add	x5, x5, #0x640
    63d4:	ca402400 	eor	x0, x0, x0, lsr #9
    63d8:	8b200ca0 	add	x0, x5, w0, uxtb #3
    63dc:	f94a2400 	ldr	x0, [x0, #5192]
    63e0:	b5000080 	cbnz	x0, 63f0 <fwp_closure_drop+0x110>
    63e4:	14000010 	b	6424 <fwp_closure_drop+0x144>
    63e8:	f9400800 	ldr	x0, [x0, #16]
    63ec:	b40001c0 	cbz	x0, 6424 <fwp_closure_drop+0x144>
    63f0:	f9400001 	ldr	x1, [x0]
    63f4:	eb13003f 	cmp	x1, x19
    63f8:	54ffff81 	b.ne	63e8 <fwp_closure_drop+0x108>  // b.any
    63fc:	f9400401 	ldr	x1, [x0, #8]
    6400:	d1000421 	sub	x1, x1, #0x1
    6404:	f9000401 	str	x1, [x0, #8]
    6408:	f103f83f 	cmp	x1, #0xfe
    640c:	54fffb61 	b.ne	6378 <fwp_closure_drop+0x98>  // b.any
    6410:	aa1303e0 	mov	x0, x19
    6414:	97fff95f 	bl	4990 <fwp_rc_forget_slot>
    6418:	12800020 	mov	w0, #0xfffffffe            	// #-2
    641c:	39000260 	strb	w0, [x19]
    6420:	17ffffd6 	b	6378 <fwp_closure_drop+0x98>
    6424:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    6428:	913b4000 	add	x0, x0, #0xed0
    642c:	97fff4d5 	bl	3780 <fwp_trap>

0000000000006430 <fwp_owned_tape_release>:
    6430:	b4000940 	cbz	x0, 6558 <fwp_owned_tape_release+0x128>
    6434:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6438:	910003fd 	mov	x29, sp
    643c:	a90153f3 	stp	x19, x20, [sp, #16]
    6440:	aa0003f3 	mov	x19, x0
    6444:	f9400000 	ldr	x0, [x0]
    6448:	b4000060 	cbz	x0, 6454 <fwp_owned_tape_release+0x24>
    644c:	f9400661 	ldr	x1, [x19, #8]
    6450:	f9000401 	str	x1, [x0, #8]
    6454:	f9400661 	ldr	x1, [x19, #8]
    6458:	b4000041 	cbz	x1, 6460 <fwp_owned_tape_release+0x30>
    645c:	f9000020 	str	x0, [x1]
    6460:	f9400a60 	ldr	x0, [x19, #16]
    6464:	f9403401 	ldr	x1, [x0, #104]
    6468:	b40005c1 	cbz	x1, 6520 <fwp_owned_tape_release+0xf0>
    646c:	a9450a60 	ldp	x0, x2, [x19, #80]
    6470:	eb00005f 	cmp	x2, x0
    6474:	540002ed 	b.le	64d0 <fwp_owned_tape_release+0xa0>
    6478:	d2800014 	mov	x20, #0x0                   	// #0
    647c:	f90013f5 	str	x21, [sp, #32]
    6480:	d2800015 	mov	x21, #0x0                   	// #0
    6484:	d503201f 	nop
    6488:	f9402260 	ldr	x0, [x19, #64]
    648c:	910006b5 	add	x21, x21, #0x1
    6490:	f8746800 	ldr	x0, [x0, x20]
    6494:	d63f0020 	blr	x1
    6498:	f9402260 	ldr	x0, [x19, #64]
    649c:	f9400a61 	ldr	x1, [x19, #16]
    64a0:	8b140000 	add	x0, x0, x20
    64a4:	91004294 	add	x20, x20, #0x10
    64a8:	f9400400 	ldr	x0, [x0, #8]
    64ac:	f9403421 	ldr	x1, [x1, #104]
    64b0:	d63f0020 	blr	x1
    64b4:	a9450261 	ldp	x1, x0, [x19, #80]
    64b8:	cb010000 	sub	x0, x0, x1
    64bc:	eb15001f 	cmp	x0, x21
    64c0:	f9400a60 	ldr	x0, [x19, #16]
    64c4:	f9403401 	ldr	x1, [x0, #104]
    64c8:	54fffe0c 	b.gt	6488 <fwp_owned_tape_release+0x58>
    64cc:	f94013f5 	ldr	x21, [sp, #32]
    64d0:	f9403663 	ldr	x3, [x19, #104]
    64d4:	f9401262 	ldr	x2, [x19, #32]
    64d8:	f100007f 	cmp	x3, #0x0
    64dc:	540001ed 	b.le	6518 <fwp_owned_tape_release+0xe8>
    64e0:	d2800014 	mov	x20, #0x0                   	// #0
    64e4:	d503201f 	nop
    64e8:	f9402660 	ldr	x0, [x19, #72]
    64ec:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    64f0:	eb02001f 	cmp	x0, x2
    64f4:	540000c0 	b.eq	650c <fwp_owned_tape_release+0xdc>  // b.none
    64f8:	d63f0020 	blr	x1
    64fc:	f9400a60 	ldr	x0, [x19, #16]
    6500:	f9401262 	ldr	x2, [x19, #32]
    6504:	f9403663 	ldr	x3, [x19, #104]
    6508:	f9403401 	ldr	x1, [x0, #104]
    650c:	91000694 	add	x20, x20, #0x1
    6510:	eb14007f 	cmp	x3, x20
    6514:	54fffeac 	b.gt	64e8 <fwp_owned_tape_release+0xb8>
    6518:	aa0203e0 	mov	x0, x2
    651c:	d63f0020 	blr	x1
    6520:	f9401660 	ldr	x0, [x19, #40]
    6524:	97ffff6f 	bl	62e0 <fwp_closure_drop>
    6528:	f9401a60 	ldr	x0, [x19, #48]
    652c:	97ffff6d 	bl	62e0 <fwp_closure_drop>
    6530:	f9401e60 	ldr	x0, [x19, #56]
    6534:	97ffff6b 	bl	62e0 <fwp_closure_drop>
    6538:	f9402260 	ldr	x0, [x19, #64]
    653c:	97fff9b5 	bl	4c10 <fwp_mem_free>
    6540:	f9402660 	ldr	x0, [x19, #72]
    6544:	97fff9b3 	bl	4c10 <fwp_mem_free>
    6548:	aa1303e0 	mov	x0, x19
    654c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6550:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6554:	17fff9af 	b	4c10 <fwp_mem_free>
    6558:	d65f03c0 	ret
    655c:	d503201f 	nop

0000000000006560 <fwp_tape_finish>:
    6560:	d10203ff 	sub	sp, sp, #0x80
    6564:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    6568:	f947f421 	ldr	x1, [x1, #4072]
    656c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6570:	910103fd 	add	x29, sp, #0x40
    6574:	a9065bf5 	stp	x21, x22, [sp, #96]
    6578:	a90763f7 	stp	x23, x24, [sp, #112]
    657c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6580:	910182f6 	add	x22, x23, #0x60
    6584:	f9400022 	ldr	x2, [x1]
    6588:	f9001fe2 	str	x2, [sp, #56]
    658c:	d2800002 	mov	x2, #0x0                   	// #0
    6590:	910382c0 	add	x0, x22, #0xe0
    6594:	97fff77c 	bl	4384 <fwp_tape_buffers_dispose>
    6598:	f9008edf 	str	xzr, [x22, #280]
    659c:	f9406ec0 	ldr	x0, [x22, #216]
    65a0:	f100001f 	cmp	x0, #0x0
    65a4:	5400034d 	b.le	660c <fwp_tape_finish+0xac>
    65a8:	910003f8 	mov	x24, sp
    65ac:	d2800015 	mov	x21, #0x0                   	// #0
    65b0:	a90553f3 	stp	x19, x20, [sp, #80]
    65b4:	d2800014 	mov	x20, #0x0                   	// #0
    65b8:	91000694 	add	x20, x20, #0x1
    65bc:	f94046d3 	ldr	x19, [x22, #136]
    65c0:	8b150273 	add	x19, x19, x21
    65c4:	9101a2b5 	add	x21, x21, #0x68
    65c8:	aa1303e0 	mov	x0, x19
    65cc:	97fff272 	bl	2f94 <fwp_tape_unlink_scope>
    65d0:	aa1803e0 	mov	x0, x24
    65d4:	a9440663 	ldp	x3, x1, [x19, #64]
    65d8:	f9001be1 	str	x1, [sp, #48]
    65dc:	f9400e62 	ldr	x2, [x19, #24]
    65e0:	a9020be3 	stp	x3, x2, [sp, #32]
    65e4:	ad410261 	ldp	q1, q0, [x19, #32]
    65e8:	ad0003e1 	stp	q1, q0, [sp]
    65ec:	97fff766 	bl	4384 <fwp_tape_buffers_dispose>
    65f0:	f9403260 	ldr	x0, [x19, #96]
    65f4:	97ffff8f 	bl	6430 <fwp_owned_tape_release>
    65f8:	f900327f 	str	xzr, [x19, #96]
    65fc:	f9406ec0 	ldr	x0, [x22, #216]
    6600:	eb14001f 	cmp	x0, x20
    6604:	54fffdac 	b.gt	65b8 <fwp_tape_finish+0x58>
    6608:	a94553f3 	ldp	x19, x20, [sp, #80]
    660c:	910182e0 	add	x0, x23, #0x60
    6610:	f9404400 	ldr	x0, [x0, #136]
    6614:	b4000040 	cbz	x0, 661c <fwp_tape_finish+0xbc>
    6618:	97fff73a 	bl	4300 <ad_raw_free.part.0>
    661c:	910182f7 	add	x23, x23, #0x60
    6620:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6624:	f947f400 	ldr	x0, [x0, #4072]
    6628:	f90046ff 	str	xzr, [x23, #136]
    662c:	f9006eff 	str	xzr, [x23, #216]
    6630:	f90092ff 	str	xzr, [x23, #288]
    6634:	f900b2ff 	str	xzr, [x23, #352]
    6638:	f9401fe2 	ldr	x2, [sp, #56]
    663c:	f9400001 	ldr	x1, [x0]
    6640:	eb010042 	subs	x2, x2, x1
    6644:	d2800001 	mov	x1, #0x0                   	// #0
    6648:	540000c1 	b.ne	6660 <fwp_tape_finish+0x100>  // b.any
    664c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6650:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6654:	a94763f7 	ldp	x23, x24, [sp, #112]
    6658:	910203ff 	add	sp, sp, #0x80
    665c:	d65f03c0 	ret
    6660:	a90553f3 	stp	x19, x20, [sp, #80]
    6664:	97fff06b 	bl	2810 <__stack_chk_fail@plt>
    6668:	d503201f 	nop
    666c:	d503201f 	nop

0000000000006670 <fwp_tape_scope_release>:
    6670:	d10243ff 	sub	sp, sp, #0x90
    6674:	a9047bfd 	stp	x29, x30, [sp, #64]
    6678:	910103fd 	add	x29, sp, #0x40
    667c:	a90553f3 	stp	x19, x20, [sp, #80]
    6680:	aa0003f4 	mov	x20, x0
    6684:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6688:	f947f400 	ldr	x0, [x0, #4072]
    668c:	b9400285 	ldr	w5, [x20]
    6690:	f9400001 	ldr	x1, [x0]
    6694:	f9001fe1 	str	x1, [sp, #56]
    6698:	d2800001 	mov	x1, #0x0                   	// #0
    669c:	37f806c5 	tbnz	w5, #31, 6774 <fwp_tape_scope_release+0x104>
    66a0:	a90763f7 	stp	x23, x24, [sp, #112]
    66a4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    66a8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    66ac:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    66b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    66b4:	910003f7 	mov	x23, sp
    66b8:	91018273 	add	x19, x19, #0x60
    66bc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    66c0:	a9065bf5 	stp	x21, x22, [sp, #96]
    66c4:	52800d16 	mov	w22, #0x68                  	// #104
    66c8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    66cc:	f90043f9 	str	x25, [sp, #128]
    66d0:	14000006 	b	66e8 <fwp_tape_scope_release+0x78>
    66d4:	97fff72c 	bl	4384 <fwp_tape_buffers_dispose>
    66d8:	aa1903e0 	mov	x0, x25
    66dc:	97ffff55 	bl	6430 <fwp_owned_tape_release>
    66e0:	b9400285 	ldr	w5, [x20]
    66e4:	37f80425 	tbnz	w5, #31, 6768 <fwp_tape_scope_release+0xf8>
    66e8:	f9404666 	ldr	x6, [x19, #136]
    66ec:	9b367ca5 	smull	x5, w5, w22
    66f0:	8b0500c0 	add	x0, x6, x5
    66f4:	97fff228 	bl	2f94 <fwp_tape_unlink_scope>
    66f8:	ad410001 	ldp	q1, q0, [x0, #32]
    66fc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6700:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6704:	f9400c03 	ldr	x3, [x0, #24]
    6708:	ad0003e1 	stp	q1, q0, [sp]
    670c:	b86568c1 	ldr	w1, [x6, x5]
    6710:	a9440804 	ldp	x4, x2, [x0, #64]
    6714:	b900041f 	str	wzr, [x0, #4]
    6718:	f9403019 	ldr	x25, [x0, #96]
    671c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6720:	f9000c1f 	str	xzr, [x0, #24]
    6724:	a9020fe4 	stp	x4, x3, [sp, #32]
    6728:	f9001be2 	str	x2, [sp, #48]
    672c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6730:	f900301f 	str	xzr, [x0, #96]
    6734:	6b15003f 	cmp	w1, w21
    6738:	540000e8 	b.hi	6754 <fwp_tape_scope_release+0xe4>  // b.pmore
    673c:	9343fca5 	asr	x5, x5, #3
    6740:	f940b260 	ldr	x0, [x19, #352]
    6744:	9b187ca5 	mul	x5, x5, x24
    6748:	eb0000bf 	cmp	x5, x0
    674c:	5400004a 	b.ge	6754 <fwp_tape_scope_release+0xe4>  // b.tcont
    6750:	f900b265 	str	x5, [x19, #352]
    6754:	aa1703e0 	mov	x0, x23
    6758:	b5fffbf9 	cbnz	x25, 66d4 <fwp_tape_scope_release+0x64>
    675c:	97fff752 	bl	44a4 <fwp_tape_buffers_release>
    6760:	b9400285 	ldr	w5, [x20]
    6764:	36fffc25 	tbz	w5, #31, 66e8 <fwp_tape_scope_release+0x78>
    6768:	a9465bf5 	ldp	x21, x22, [sp, #96]
    676c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6770:	f94043f9 	ldr	x25, [sp, #128]
    6774:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6778:	f947f400 	ldr	x0, [x0, #4072]
    677c:	f9401fe2 	ldr	x2, [sp, #56]
    6780:	f9400001 	ldr	x1, [x0]
    6784:	eb010042 	subs	x2, x2, x1
    6788:	d2800001 	mov	x1, #0x0                   	// #0
    678c:	540000a1 	b.ne	67a0 <fwp_tape_scope_release+0x130>  // b.any
    6790:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6794:	a94553f3 	ldp	x19, x20, [sp, #80]
    6798:	910243ff 	add	sp, sp, #0x90
    679c:	d65f03c0 	ret
    67a0:	a9065bf5 	stp	x21, x22, [sp, #96]
    67a4:	a90763f7 	stp	x23, x24, [sp, #112]
    67a8:	f90043f9 	str	x25, [sp, #128]
    67ac:	97fff019 	bl	2810 <__stack_chk_fail@plt>

00000000000067b0 <fwp_task_dispose>:
    67b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    67b4:	910003fd 	mov	x29, sp
    67b8:	f9000bf3 	str	x19, [sp, #16]
    67bc:	aa0003f3 	mov	x19, x0
    67c0:	39414000 	ldrb	w0, [x0, #80]
    67c4:	36000720 	tbz	w0, #0, 68a8 <fwp_task_dispose+0xf8>
    67c8:	f9400a60 	ldr	x0, [x19, #16]
    67cc:	b50006e0 	cbnz	x0, 68a8 <fwp_task_dispose+0xf8>
    67d0:	a9478660 	ldp	x0, x1, [x19, #120]
    67d4:	39014e7f 	strb	wzr, [x19, #83]
    67d8:	f9003e7f 	str	xzr, [x19, #120]
    67dc:	f100003f 	cmp	x1, #0x0
    67e0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    67e4:	54000040 	b.eq	67ec <fwp_task_dispose+0x3c>  // b.none
    67e8:	d63f0020 	blr	x1
    67ec:	f9405660 	ldr	x0, [x19, #168]
    67f0:	97fff908 	bl	4c10 <fwp_mem_free>
    67f4:	f900567f 	str	xzr, [x19, #168]
    67f8:	b9405e60 	ldr	w0, [x19, #92]
    67fc:	7100041f 	cmp	w0, #0x1
    6800:	54000420 	b.eq	6884 <fwp_task_dispose+0xd4>  // b.none
    6804:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    6808:	91190042 	add	x2, x2, #0x640
    680c:	f949d840 	ldr	x0, [x2, #5040]
    6810:	f949ec41 	ldr	x1, [x2, #5080]
    6814:	cb000260 	sub	x0, x19, x0
    6818:	eb01401f 	cmp	x0, x1, lsl #16
    681c:	540002e2 	b.cs	6878 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6820:	d350fc01 	lsr	x1, x0, #16
    6824:	f949fc44 	ldr	x4, [x2, #5112]
    6828:	8b010821 	add	x1, x1, x1, lsl #2
    682c:	d37df021 	lsl	x1, x1, #3
    6830:	8b010083 	add	x3, x4, x1
    6834:	f9401062 	ldr	x2, [x3, #32]
    6838:	b4000202 	cbz	x2, 6878 <fwp_task_dispose+0xc8>
    683c:	38616881 	ldrb	w1, [x4, x1]
    6840:	7100083f 	cmp	w1, #0x2
    6844:	54000280 	b.eq	6894 <fwp_task_dispose+0xe4>  // b.none
    6848:	7100043f 	cmp	w1, #0x1
    684c:	54000161 	b.ne	6878 <fwp_task_dispose+0xc8>  // b.any
    6850:	29430464 	ldp	w4, w1, [x3, #24]
    6854:	92403c00 	and	x0, x0, #0xffff
    6858:	9b047c00 	mul	x0, x0, x4
    685c:	d360fc00 	lsr	x0, x0, #32
    6860:	eb01001f 	cmp	x0, x1
    6864:	540000a2 	b.cs	6878 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6868:	8b000042 	add	x2, x2, x0
    686c:	39400040 	ldrb	w0, [x2]
    6870:	7100041f 	cmp	w0, #0x1
    6874:	54000080 	b.eq	6884 <fwp_task_dispose+0xd4>  // b.none
    6878:	f9400bf3 	ldr	x19, [sp, #16]
    687c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6880:	d65f03c0 	ret
    6884:	aa1303e0 	mov	x0, x19
    6888:	f9400bf3 	ldr	x19, [sp, #16]
    688c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6890:	17fff8e0 	b	4c10 <fwp_mem_free>
    6894:	72003c1f 	tst	w0, #0xffff
    6898:	54fffea0 	b.eq	686c <fwp_task_dispose+0xbc>  // b.none
    689c:	f9400bf3 	ldr	x19, [sp, #16]
    68a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68a4:	d65f03c0 	ret
    68a8:	97ffefee 	bl	2860 <abort@plt>
    68ac:	d503201f 	nop

00000000000068b0 <fwp_free_zombie>:
    68b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    68b4:	910003fd 	mov	x29, sp
    68b8:	a90153f3 	stp	x19, x20, [sp, #16]
    68bc:	d00000d4 	adrp	x20, 20000 <__data_start>
    68c0:	91018281 	add	x1, x20, #0x60
    68c4:	f940b433 	ldr	x19, [x1, #360]
    68c8:	b4000333 	cbz	x19, 692c <fwp_free_zombie+0x7c>
    68cc:	f9404c20 	ldr	x0, [x1, #152]
    68d0:	eb00027f 	cmp	x19, x0
    68d4:	540002c0 	b.eq	692c <fwp_free_zombie+0x7c>  // b.none
    68d8:	b9417022 	ldr	w2, [x1, #368]
    68dc:	f9400a60 	ldr	x0, [x19, #16]
    68e0:	7100fc5f 	cmp	w2, #0x3f
    68e4:	5400078c 	b.gt	69d4 <fwp_free_zombie+0x124>
    68e8:	91060023 	add	x3, x1, #0x180
    68ec:	11000444 	add	w4, w2, #0x1
    68f0:	b9017024 	str	w4, [x1, #368]
    68f4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    68f8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    68fc:	a9530261 	ldp	x1, x0, [x19, #304]
    6900:	b4000741 	cbz	x1, 69e8 <fwp_free_zombie+0x138>
    6904:	f9009c20 	str	x0, [x1, #312]
    6908:	b4000040 	cbz	x0, 6910 <fwp_free_zombie+0x60>
    690c:	f9009801 	str	x1, [x0, #304]
    6910:	91018294 	add	x20, x20, #0x60
    6914:	b9405e60 	ldr	w0, [x19, #92]
    6918:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    691c:	f900b69f 	str	xzr, [x20, #360]
    6920:	34000140 	cbz	w0, 6948 <fwp_free_zombie+0x98>
    6924:	7100041f 	cmp	w0, #0x1
    6928:	54000080 	b.eq	6938 <fwp_free_zombie+0x88>  // b.none
    692c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6930:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6934:	d65f03c0 	ret
    6938:	aa1303e0 	mov	x0, x19
    693c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6940:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6944:	17ffff9b 	b	67b0 <fwp_task_dispose>
    6948:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xba0>
    694c:	91190082 	add	x2, x4, #0x640
    6950:	f949d841 	ldr	x1, [x2, #5040]
    6954:	f949ec40 	ldr	x0, [x2, #5080]
    6958:	cb010261 	sub	x1, x19, x1
    695c:	eb00403f 	cmp	x1, x0, lsl #16
    6960:	54fffe62 	b.cs	692c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6964:	d350fc20 	lsr	x0, x1, #16
    6968:	f949fc43 	ldr	x3, [x2, #5112]
    696c:	8b000800 	add	x0, x0, x0, lsl #2
    6970:	d37df000 	lsl	x0, x0, #3
    6974:	8b000062 	add	x2, x3, x0
    6978:	f9401054 	ldr	x20, [x2, #32]
    697c:	b4fffd94 	cbz	x20, 692c <fwp_free_zombie+0x7c>
    6980:	38606860 	ldrb	w0, [x3, x0]
    6984:	7100081f 	cmp	w0, #0x2
    6988:	54000360 	b.eq	69f4 <fwp_free_zombie+0x144>  // b.none
    698c:	7100041f 	cmp	w0, #0x1
    6990:	54fffce1 	b.ne	692c <fwp_free_zombie+0x7c>  // b.any
    6994:	29430043 	ldp	w3, w0, [x2, #24]
    6998:	92403c21 	and	x1, x1, #0xffff
    699c:	9b037c21 	mul	x1, x1, x3
    69a0:	d360fc21 	lsr	x1, x1, #32
    69a4:	eb00003f 	cmp	x1, x0
    69a8:	54fffc22 	b.cs	692c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    69ac:	8b010294 	add	x20, x20, x1
    69b0:	39400280 	ldrb	w0, [x20]
    69b4:	34fffbc0 	cbz	w0, 692c <fwp_free_zombie+0x7c>
    69b8:	7100041f 	cmp	w0, #0x1
    69bc:	54fffbe0 	b.eq	6938 <fwp_free_zombie+0x88>  // b.none
    69c0:	7103fc1f 	cmp	w0, #0xff
    69c4:	540001e0 	b.eq	6a00 <fwp_free_zombie+0x150>  // b.none
    69c8:	51000400 	sub	w0, w0, #0x1
    69cc:	39000280 	strb	w0, [x20]
    69d0:	17ffffd7 	b	692c <fwp_free_zombie+0x7c>
    69d4:	f9400e61 	ldr	x1, [x19, #24]
    69d8:	97ffefd6 	bl	2930 <munmap@plt>
    69dc:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    69e0:	a9530261 	ldp	x1, x0, [x19, #304]
    69e4:	b5fff901 	cbnz	x1, 6904 <fwp_free_zombie+0x54>
    69e8:	91018282 	add	x2, x20, #0x60
    69ec:	f901c040 	str	x0, [x2, #896]
    69f0:	17ffffc6 	b	6908 <fwp_free_zombie+0x58>
    69f4:	72003c3f 	tst	w1, #0xffff
    69f8:	54fff9a1 	b.ne	692c <fwp_free_zombie+0x7c>  // b.any
    69fc:	17ffffed 	b	69b0 <fwp_free_zombie+0x100>
    6a00:	ca544680 	eor	x0, x20, x20, lsr #17
    6a04:	91190084 	add	x4, x4, #0x640
    6a08:	ca402400 	eor	x0, x0, x0, lsr #9
    6a0c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6a10:	f94a2400 	ldr	x0, [x0, #5192]
    6a14:	b5000080 	cbnz	x0, 6a24 <fwp_free_zombie+0x174>
    6a18:	14000010 	b	6a58 <fwp_free_zombie+0x1a8>
    6a1c:	f9400800 	ldr	x0, [x0, #16]
    6a20:	b40001c0 	cbz	x0, 6a58 <fwp_free_zombie+0x1a8>
    6a24:	f9400001 	ldr	x1, [x0]
    6a28:	eb14003f 	cmp	x1, x20
    6a2c:	54ffff81 	b.ne	6a1c <fwp_free_zombie+0x16c>  // b.any
    6a30:	f9400401 	ldr	x1, [x0, #8]
    6a34:	d1000421 	sub	x1, x1, #0x1
    6a38:	f9000401 	str	x1, [x0, #8]
    6a3c:	f103f83f 	cmp	x1, #0xfe
    6a40:	54fff761 	b.ne	692c <fwp_free_zombie+0x7c>  // b.any
    6a44:	aa1403e0 	mov	x0, x20
    6a48:	97fff7d2 	bl	4990 <fwp_rc_forget_slot>
    6a4c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a50:	39000280 	strb	w0, [x20]
    6a54:	17ffffb6 	b	692c <fwp_free_zombie+0x7c>
    6a58:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    6a5c:	913b4000 	add	x0, x0, #0xed0
    6a60:	97fff348 	bl	3780 <fwp_trap>

0000000000006a64 <fwp_block>:
    6a64:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a68:	910003fd 	mov	x29, sp
    6a6c:	a90153f3 	stp	x19, x20, [sp, #16]
    6a70:	d00000d3 	adrp	x19, 20000 <__data_start>
    6a74:	91018274 	add	x20, x19, #0x60
    6a78:	f9406682 	ldr	x2, [x20, #200]
    6a7c:	b4000622 	cbz	x2, 6b40 <fwp_block+0xdc>
    6a80:	91018261 	add	x1, x19, #0x60
    6a84:	f9408040 	ldr	x0, [x2, #256]
    6a88:	f9006420 	str	x0, [x1, #200]
    6a8c:	b4000680 	cbz	x0, 6b5c <fwp_block+0xf8>
    6a90:	91018263 	add	x3, x19, #0x60
    6a94:	3901505f 	strb	wzr, [x2, #84]
    6a98:	f9404c64 	ldr	x4, [x3, #152]
    6a9c:	eb02009f 	cmp	x4, x2
    6aa0:	54000440 	b.eq	6b28 <fwp_block+0xc4>  // b.none
    6aa4:	f941c465 	ldr	x5, [x3, #904]
    6aa8:	f9004c62 	str	x2, [x3, #152]
    6aac:	f9400441 	ldr	x1, [x2, #8]
    6ab0:	f9004885 	str	x5, [x4, #144]
    6ab4:	f941c865 	ldr	x5, [x3, #912]
    6ab8:	f9004c85 	str	x5, [x4, #152]
    6abc:	f941cc65 	ldr	x5, [x3, #920]
    6ac0:	f9005085 	str	x5, [x4, #160]
    6ac4:	f941d065 	ldr	x5, [x3, #928]
    6ac8:	f9005485 	str	x5, [x4, #168]
    6acc:	f941d465 	ldr	x5, [x3, #936]
    6ad0:	f9005885 	str	x5, [x4, #176]
    6ad4:	f941d865 	ldr	x5, [x3, #944]
    6ad8:	f9005c85 	str	x5, [x4, #184]
    6adc:	f941dc65 	ldr	x5, [x3, #952]
    6ae0:	f9006085 	str	x5, [x4, #192]
    6ae4:	f9400480 	ldr	x0, [x4, #8]
    6ae8:	f9404844 	ldr	x4, [x2, #144]
    6aec:	f901c464 	str	x4, [x3, #904]
    6af0:	f9404c44 	ldr	x4, [x2, #152]
    6af4:	f901c864 	str	x4, [x3, #912]
    6af8:	f9405044 	ldr	x4, [x2, #160]
    6afc:	f901cc64 	str	x4, [x3, #920]
    6b00:	f9405444 	ldr	x4, [x2, #168]
    6b04:	f901d064 	str	x4, [x3, #928]
    6b08:	f9405844 	ldr	x4, [x2, #176]
    6b0c:	f901d464 	str	x4, [x3, #936]
    6b10:	a94b8844 	ldp	x4, x2, [x2, #184]
    6b14:	f901d864 	str	x4, [x3, #944]
    6b18:	f901dc62 	str	x2, [x3, #952]
    6b1c:	97ffef55 	bl	2870 <swapcontext@plt>
    6b20:	97ffff64 	bl	68b0 <fwp_free_zombie>
    6b24:	d503201f 	nop
    6b28:	91018260 	add	x0, x19, #0x60
    6b2c:	b943c000 	ldr	w0, [x0, #960]
    6b30:	340001a0 	cbz	w0, 6b64 <fwp_block+0x100>
    6b34:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b38:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b3c:	d65f03c0 	ret
    6b40:	97fff6c1 	bl	4644 <fwp_poll_events>
    6b44:	f9406682 	ldr	x2, [x20, #200]
    6b48:	b4ffffc2 	cbz	x2, 6b40 <fwp_block+0xdc>
    6b4c:	91018261 	add	x1, x19, #0x60
    6b50:	f9408040 	ldr	x0, [x2, #256]
    6b54:	f9006420 	str	x0, [x1, #200]
    6b58:	b5fff9c0 	cbnz	x0, 6a90 <fwp_block+0x2c>
    6b5c:	f900603f 	str	xzr, [x1, #192]
    6b60:	17ffffcc 	b	6a90 <fwp_block+0x2c>
    6b64:	90000040 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    6b68:	91000000 	add	x0, x0, #0x0
    6b6c:	97ffef8d 	bl	29a0 <getenv@plt>
    6b70:	5284e202 	mov	w2, #0x2710                	// #10000
    6b74:	b4000060 	cbz	x0, 6b80 <fwp_block+0x11c>
    6b78:	39400001 	ldrb	w1, [x0]
    6b7c:	350000c1 	cbnz	w1, 6b94 <fwp_block+0x130>
    6b80:	91018273 	add	x19, x19, #0x60
    6b84:	b903c262 	str	w2, [x19, #960]
    6b88:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b90:	d65f03c0 	ret
    6b94:	52800142 	mov	w2, #0xa                   	// #10
    6b98:	d2800001 	mov	x1, #0x0                   	// #0
    6b9c:	97ffeed1 	bl	26e0 <strtoll@plt>
    6ba0:	d1000403 	sub	x3, x0, #0x1
    6ba4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6ba8:	eb02007f 	cmp	x3, x2
    6bac:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6bb0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6bb4:	17fffff3 	b	6b80 <fwp_block+0x11c>
    6bb8:	d503201f 	nop
    6bbc:	d503201f 	nop

0000000000006bc0 <fwp_drop4>:
    6bc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6bc4:	910003fd 	mov	x29, sp
    6bc8:	a90153f3 	stp	x19, x20, [sp, #16]
    6bcc:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xba0>
    6bd0:	f90013f5 	str	x21, [sp, #32]
    6bd4:	91190275 	add	x21, x19, #0x640
    6bd8:	f949daa1 	ldr	x1, [x21, #5040]
    6bdc:	f949eea2 	ldr	x2, [x21, #5080]
    6be0:	cb010001 	sub	x1, x0, x1
    6be4:	eb02403f 	cmp	x1, x2, lsl #16
    6be8:	54000382 	b.cs	6c58 <fwp_drop4+0x98>  // b.hs, b.nlast
    6bec:	d350fc22 	lsr	x2, x1, #16
    6bf0:	f949fea3 	ldr	x3, [x21, #5112]
    6bf4:	8b020842 	add	x2, x2, x2, lsl #2
    6bf8:	d37df042 	lsl	x2, x2, #3
    6bfc:	8b020064 	add	x4, x3, x2
    6c00:	f9401094 	ldr	x20, [x4, #32]
    6c04:	b40002b4 	cbz	x20, 6c58 <fwp_drop4+0x98>
    6c08:	38626862 	ldrb	w2, [x3, x2]
    6c0c:	7100085f 	cmp	w2, #0x2
    6c10:	540007a0 	b.eq	6d04 <fwp_drop4+0x144>  // b.none
    6c14:	7100045f 	cmp	w2, #0x1
    6c18:	54000201 	b.ne	6c58 <fwp_drop4+0x98>  // b.any
    6c1c:	29430885 	ldp	w5, w2, [x4, #24]
    6c20:	92403c21 	and	x1, x1, #0xffff
    6c24:	9b057c21 	mul	x1, x1, x5
    6c28:	d360fc21 	lsr	x1, x1, #32
    6c2c:	eb02003f 	cmp	x1, x2
    6c30:	54000142 	b.cs	6c58 <fwp_drop4+0x98>  // b.hs, b.nlast
    6c34:	8b010294 	add	x20, x20, x1
    6c38:	39400281 	ldrb	w1, [x20]
    6c3c:	340000e1 	cbz	w1, 6c58 <fwp_drop4+0x98>
    6c40:	7100043f 	cmp	w1, #0x1
    6c44:	54000120 	b.eq	6c68 <fwp_drop4+0xa8>  // b.none
    6c48:	7103fc3f 	cmp	w1, #0xff
    6c4c:	540007c0 	b.eq	6d44 <fwp_drop4+0x184>  // b.none
    6c50:	51000421 	sub	w1, w1, #0x1
    6c54:	39000281 	strb	w1, [x20]
    6c58:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c5c:	f94013f5 	ldr	x21, [sp, #32]
    6c60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c64:	d65f03c0 	ret
    6c68:	f9400001 	ldr	x1, [x0]
    6c6c:	b7f80581 	tbnz	x1, #63, 6d1c <fwp_drop4+0x15c>
    6c70:	91190273 	add	x19, x19, #0x640
    6c74:	f949da61 	ldr	x1, [x19, #5040]
    6c78:	f949ee62 	ldr	x2, [x19, #5080]
    6c7c:	cb010001 	sub	x1, x0, x1
    6c80:	eb02403f 	cmp	x1, x2, lsl #16
    6c84:	54fffea2 	b.cs	6c58 <fwp_drop4+0x98>  // b.hs, b.nlast
    6c88:	d350fc22 	lsr	x2, x1, #16
    6c8c:	8b020842 	add	x2, x2, x2, lsl #2
    6c90:	d37df042 	lsl	x2, x2, #3
    6c94:	8b020065 	add	x5, x3, x2
    6c98:	f94010a4 	ldr	x4, [x5, #32]
    6c9c:	b4fffde4 	cbz	x4, 6c58 <fwp_drop4+0x98>
    6ca0:	38626862 	ldrb	w2, [x3, x2]
    6ca4:	7100085f 	cmp	w2, #0x2
    6ca8:	54000220 	b.eq	6cec <fwp_drop4+0x12c>  // b.none
    6cac:	7100045f 	cmp	w2, #0x1
    6cb0:	54fffd41 	b.ne	6c58 <fwp_drop4+0x98>  // b.any
    6cb4:	294308a3 	ldp	w3, w2, [x5, #24]
    6cb8:	92403c21 	and	x1, x1, #0xffff
    6cbc:	9b037c21 	mul	x1, x1, x3
    6cc0:	d360fc21 	lsr	x1, x1, #32
    6cc4:	eb02003f 	cmp	x1, x2
    6cc8:	54fffc82 	b.cs	6c58 <fwp_drop4+0x98>  // b.hs, b.nlast
    6ccc:	8b010084 	add	x4, x4, x1
    6cd0:	39400081 	ldrb	w1, [x4]
    6cd4:	7100043f 	cmp	w1, #0x1
    6cd8:	54fffc01 	b.ne	6c58 <fwp_drop4+0x98>  // b.any
    6cdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ce0:	f94013f5 	ldr	x21, [sp, #32]
    6ce4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ce8:	17fff7ca 	b	4c10 <fwp_mem_free>
    6cec:	72003c3f 	tst	w1, #0xffff
    6cf0:	54ffff00 	b.eq	6cd0 <fwp_drop4+0x110>  // b.none
    6cf4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cf8:	f94013f5 	ldr	x21, [sp, #32]
    6cfc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d00:	d65f03c0 	ret
    6d04:	72003c3f 	tst	w1, #0xffff
    6d08:	54fff980 	b.eq	6c38 <fwp_drop4+0x78>  // b.none
    6d0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d10:	f94013f5 	ldr	x21, [sp, #32]
    6d14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d18:	d65f03c0 	ret
    6d1c:	f9400414 	ldr	x20, [x0, #8]
    6d20:	97fffbe1 	bl	5ca4 <fwp_rc_free_arr>
    6d24:	91190260 	add	x0, x19, #0x640
    6d28:	f949d801 	ldr	x1, [x0, #5040]
    6d2c:	f949ec00 	ldr	x0, [x0, #5080]
    6d30:	cb010281 	sub	x1, x20, x1
    6d34:	eb00403f 	cmp	x1, x0, lsl #16
    6d38:	54fff902 	b.cs	6c58 <fwp_drop4+0x98>  // b.hs, b.nlast
    6d3c:	aa1403e0 	mov	x0, x20
    6d40:	17ffffab 	b	6bec <fwp_drop4+0x2c>
    6d44:	ca544680 	eor	x0, x20, x20, lsr #17
    6d48:	91190273 	add	x19, x19, #0x640
    6d4c:	ca402400 	eor	x0, x0, x0, lsr #9
    6d50:	8b200e60 	add	x0, x19, w0, uxtb #3
    6d54:	f94a2400 	ldr	x0, [x0, #5192]
    6d58:	b5000080 	cbnz	x0, 6d68 <fwp_drop4+0x1a8>
    6d5c:	14000010 	b	6d9c <fwp_drop4+0x1dc>
    6d60:	f9400800 	ldr	x0, [x0, #16]
    6d64:	b40001c0 	cbz	x0, 6d9c <fwp_drop4+0x1dc>
    6d68:	f9400001 	ldr	x1, [x0]
    6d6c:	eb14003f 	cmp	x1, x20
    6d70:	54ffff81 	b.ne	6d60 <fwp_drop4+0x1a0>  // b.any
    6d74:	f9400401 	ldr	x1, [x0, #8]
    6d78:	d1000421 	sub	x1, x1, #0x1
    6d7c:	f9000401 	str	x1, [x0, #8]
    6d80:	f103f83f 	cmp	x1, #0xfe
    6d84:	54fff6a1 	b.ne	6c58 <fwp_drop4+0x98>  // b.any
    6d88:	aa1403e0 	mov	x0, x20
    6d8c:	97fff701 	bl	4990 <fwp_rc_forget_slot>
    6d90:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6d94:	39000280 	strb	w0, [x20]
    6d98:	17ffffb0 	b	6c58 <fwp_drop4+0x98>
    6d9c:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    6da0:	913b4000 	add	x0, x0, #0xed0
    6da4:	97fff277 	bl	3780 <fwp_trap>
    6da8:	d503201f 	nop
    6dac:	d503201f 	nop

0000000000006db0 <fwp_caps161>:
    6db0:	34000041 	cbz	w1, 6db8 <fwp_caps161+0x8>
    6db4:	d65f03c0 	ret
    6db8:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xba0>
    6dbc:	91190063 	add	x3, x3, #0x640
    6dc0:	f949d861 	ldr	x1, [x3, #5040]
    6dc4:	f949ec62 	ldr	x2, [x3, #5080]
    6dc8:	cb010001 	sub	x1, x0, x1
    6dcc:	eb02403f 	cmp	x1, x2, lsl #16
    6dd0:	54ffff22 	b.cs	6db4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6dd4:	d350fc22 	lsr	x2, x1, #16
    6dd8:	f949fc65 	ldr	x5, [x3, #5112]
    6ddc:	8b020842 	add	x2, x2, x2, lsl #2
    6de0:	d37df042 	lsl	x2, x2, #3
    6de4:	8b0200a4 	add	x4, x5, x2
    6de8:	f9401083 	ldr	x3, [x4, #32]
    6dec:	b4fffe43 	cbz	x3, 6db4 <fwp_caps161+0x4>
    6df0:	386268a2 	ldrb	w2, [x5, x2]
    6df4:	7100085f 	cmp	w2, #0x2
    6df8:	540001c0 	b.eq	6e30 <fwp_caps161+0x80>  // b.none
    6dfc:	7100045f 	cmp	w2, #0x1
    6e00:	54fffda1 	b.ne	6db4 <fwp_caps161+0x4>  // b.any
    6e04:	29430885 	ldp	w5, w2, [x4, #24]
    6e08:	92403c21 	and	x1, x1, #0xffff
    6e0c:	9b057c21 	mul	x1, x1, x5
    6e10:	d360fc21 	lsr	x1, x1, #32
    6e14:	eb02003f 	cmp	x1, x2
    6e18:	54fffce2 	b.cs	6db4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6e1c:	8b010063 	add	x3, x3, x1
    6e20:	39400061 	ldrb	w1, [x3]
    6e24:	7100043f 	cmp	w1, #0x1
    6e28:	54fffc61 	b.ne	6db4 <fwp_caps161+0x4>  // b.any
    6e2c:	17fff779 	b	4c10 <fwp_mem_free>
    6e30:	72003c3f 	tst	w1, #0xffff
    6e34:	54ffff60 	b.eq	6e20 <fwp_caps161+0x70>  // b.none
    6e38:	d65f03c0 	ret
    6e3c:	d503201f 	nop

0000000000006e40 <fwp_drop2>:
    6e40:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6e44:	910003fd 	mov	x29, sp
    6e48:	a9025bf5 	stp	x21, x22, [sp, #32]
    6e4c:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xba0>
    6e50:	911902d5 	add	x21, x22, #0x640
    6e54:	a90153f3 	stp	x19, x20, [sp, #16]
    6e58:	aa0003f3 	mov	x19, x0
    6e5c:	f949daa1 	ldr	x1, [x21, #5040]
    6e60:	f949eea0 	ldr	x0, [x21, #5080]
    6e64:	cb010261 	sub	x1, x19, x1
    6e68:	eb00403f 	cmp	x1, x0, lsl #16
    6e6c:	54000382 	b.cs	6edc <fwp_drop2+0x9c>  // b.hs, b.nlast
    6e70:	d350fc22 	lsr	x2, x1, #16
    6e74:	f949fea3 	ldr	x3, [x21, #5112]
    6e78:	8b020842 	add	x2, x2, x2, lsl #2
    6e7c:	d37df042 	lsl	x2, x2, #3
    6e80:	8b020060 	add	x0, x3, x2
    6e84:	f9401014 	ldr	x20, [x0, #32]
    6e88:	b40002b4 	cbz	x20, 6edc <fwp_drop2+0x9c>
    6e8c:	38626862 	ldrb	w2, [x3, x2]
    6e90:	7100085f 	cmp	w2, #0x2
    6e94:	540002c0 	b.eq	6eec <fwp_drop2+0xac>  // b.none
    6e98:	7100045f 	cmp	w2, #0x1
    6e9c:	54000201 	b.ne	6edc <fwp_drop2+0x9c>  // b.any
    6ea0:	29430002 	ldp	w2, w0, [x0, #24]
    6ea4:	92403c21 	and	x1, x1, #0xffff
    6ea8:	9b027c21 	mul	x1, x1, x2
    6eac:	d360fc21 	lsr	x1, x1, #32
    6eb0:	eb00003f 	cmp	x1, x0
    6eb4:	54000142 	b.cs	6edc <fwp_drop2+0x9c>  // b.hs, b.nlast
    6eb8:	8b010294 	add	x20, x20, x1
    6ebc:	39400280 	ldrb	w0, [x20]
    6ec0:	340000e0 	cbz	w0, 6edc <fwp_drop2+0x9c>
    6ec4:	7100041f 	cmp	w0, #0x1
    6ec8:	540001e0 	b.eq	6f04 <fwp_drop2+0xc4>  // b.none
    6ecc:	7103fc1f 	cmp	w0, #0xff
    6ed0:	540007c0 	b.eq	6fc8 <fwp_drop2+0x188>  // b.none
    6ed4:	51000400 	sub	w0, w0, #0x1
    6ed8:	39000280 	strb	w0, [x20]
    6edc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ee0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6ee4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ee8:	d65f03c0 	ret
    6eec:	72003c3f 	tst	w1, #0xffff
    6ef0:	54fffe60 	b.eq	6ebc <fwp_drop2+0x7c>  // b.none
    6ef4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ef8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6efc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6f00:	d65f03c0 	ret
    6f04:	911902c2 	add	x2, x22, #0x640
    6f08:	f9400660 	ldr	x0, [x19, #8]
    6f0c:	f949d841 	ldr	x1, [x2, #5040]
    6f10:	f949ec42 	ldr	x2, [x2, #5080]
    6f14:	cb010001 	sub	x1, x0, x1
    6f18:	eb02403f 	cmp	x1, x2, lsl #16
    6f1c:	54000362 	b.cs	6f88 <fwp_drop2+0x148>  // b.hs, b.nlast
    6f20:	d350fc22 	lsr	x2, x1, #16
    6f24:	8b020842 	add	x2, x2, x2, lsl #2
    6f28:	d37df042 	lsl	x2, x2, #3
    6f2c:	8b020064 	add	x4, x3, x2
    6f30:	f9401094 	ldr	x20, [x4, #32]
    6f34:	b40002b4 	cbz	x20, 6f88 <fwp_drop2+0x148>
    6f38:	38626862 	ldrb	w2, [x3, x2]
    6f3c:	7100085f 	cmp	w2, #0x2
    6f40:	540003e0 	b.eq	6fbc <fwp_drop2+0x17c>  // b.none
    6f44:	7100045f 	cmp	w2, #0x1
    6f48:	54000201 	b.ne	6f88 <fwp_drop2+0x148>  // b.any
    6f4c:	29430883 	ldp	w3, w2, [x4, #24]
    6f50:	92403c21 	and	x1, x1, #0xffff
    6f54:	9b037c21 	mul	x1, x1, x3
    6f58:	d360fc21 	lsr	x1, x1, #32
    6f5c:	eb02003f 	cmp	x1, x2
    6f60:	54000142 	b.cs	6f88 <fwp_drop2+0x148>  // b.hs, b.nlast
    6f64:	8b010294 	add	x20, x20, x1
    6f68:	39400281 	ldrb	w1, [x20]
    6f6c:	340000e1 	cbz	w1, 6f88 <fwp_drop2+0x148>
    6f70:	7100043f 	cmp	w1, #0x1
    6f74:	54000200 	b.eq	6fb4 <fwp_drop2+0x174>  // b.none
    6f78:	7103fc3f 	cmp	w1, #0xff
    6f7c:	54000580 	b.eq	702c <fwp_drop2+0x1ec>  // b.none
    6f80:	51000421 	sub	w1, w1, #0x1
    6f84:	39000281 	strb	w1, [x20]
    6f88:	f9400a74 	ldr	x20, [x19, #16]
    6f8c:	aa1303e0 	mov	x0, x19
    6f90:	97fffb45 	bl	5ca4 <fwp_rc_free_arr>
    6f94:	911902c0 	add	x0, x22, #0x640
    6f98:	f949d801 	ldr	x1, [x0, #5040]
    6f9c:	f949ec00 	ldr	x0, [x0, #5080]
    6fa0:	cb010281 	sub	x1, x20, x1
    6fa4:	eb00403f 	cmp	x1, x0, lsl #16
    6fa8:	54fff9a2 	b.cs	6edc <fwp_drop2+0x9c>  // b.hs, b.nlast
    6fac:	aa1403f3 	mov	x19, x20
    6fb0:	17ffffb0 	b	6e70 <fwp_drop2+0x30>
    6fb4:	97fffb3c 	bl	5ca4 <fwp_rc_free_arr>
    6fb8:	17fffff4 	b	6f88 <fwp_drop2+0x148>
    6fbc:	72003c3f 	tst	w1, #0xffff
    6fc0:	54fffe41 	b.ne	6f88 <fwp_drop2+0x148>  // b.any
    6fc4:	17ffffe9 	b	6f68 <fwp_drop2+0x128>
    6fc8:	ca544681 	eor	x1, x20, x20, lsr #17
    6fcc:	911902c0 	add	x0, x22, #0x640
    6fd0:	ca412421 	eor	x1, x1, x1, lsr #9
    6fd4:	8b210c01 	add	x1, x0, w1, uxtb #3
    6fd8:	f94a2420 	ldr	x0, [x1, #5192]
    6fdc:	b5000080 	cbnz	x0, 6fec <fwp_drop2+0x1ac>
    6fe0:	14000010 	b	7020 <fwp_drop2+0x1e0>
    6fe4:	f9400800 	ldr	x0, [x0, #16]
    6fe8:	b40001c0 	cbz	x0, 7020 <fwp_drop2+0x1e0>
    6fec:	f9400001 	ldr	x1, [x0]
    6ff0:	eb14003f 	cmp	x1, x20
    6ff4:	54ffff81 	b.ne	6fe4 <fwp_drop2+0x1a4>  // b.any
    6ff8:	f9400401 	ldr	x1, [x0, #8]
    6ffc:	d1000421 	sub	x1, x1, #0x1
    7000:	f9000401 	str	x1, [x0, #8]
    7004:	f103f83f 	cmp	x1, #0xfe
    7008:	54fff6a1 	b.ne	6edc <fwp_drop2+0x9c>  // b.any
    700c:	aa1403e0 	mov	x0, x20
    7010:	97fff660 	bl	4990 <fwp_rc_forget_slot>
    7014:	12800020 	mov	w0, #0xfffffffe            	// #-2
    7018:	39000280 	strb	w0, [x20]
    701c:	17ffffb0 	b	6edc <fwp_drop2+0x9c>
    7020:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    7024:	913b4000 	add	x0, x0, #0xed0
    7028:	97fff1d6 	bl	3780 <fwp_trap>
    702c:	ca544680 	eor	x0, x20, x20, lsr #17
    7030:	911902c1 	add	x1, x22, #0x640
    7034:	ca402400 	eor	x0, x0, x0, lsr #9
    7038:	8b200c20 	add	x0, x1, w0, uxtb #3
    703c:	f94a2400 	ldr	x0, [x0, #5192]
    7040:	b5000080 	cbnz	x0, 7050 <fwp_drop2+0x210>
    7044:	17fffff7 	b	7020 <fwp_drop2+0x1e0>
    7048:	f9400800 	ldr	x0, [x0, #16]
    704c:	b4fffea0 	cbz	x0, 7020 <fwp_drop2+0x1e0>
    7050:	f9400001 	ldr	x1, [x0]
    7054:	eb14003f 	cmp	x1, x20
    7058:	54ffff81 	b.ne	7048 <fwp_drop2+0x208>  // b.any
    705c:	f9400401 	ldr	x1, [x0, #8]
    7060:	d1000421 	sub	x1, x1, #0x1
    7064:	f9000401 	str	x1, [x0, #8]
    7068:	f103f83f 	cmp	x1, #0xfe
    706c:	54fff8e1 	b.ne	6f88 <fwp_drop2+0x148>  // b.any
    7070:	aa1403e0 	mov	x0, x20
    7074:	97fff647 	bl	4990 <fwp_rc_forget_slot>
    7078:	12800020 	mov	w0, #0xfffffffe            	// #-2
    707c:	39000280 	strb	w0, [x20]
    7080:	17ffffc2 	b	6f88 <fwp_drop2+0x148>

0000000000007084 <fwp_arg_drop23>:
    7084:	7100003f 	cmp	w1, #0x0
    7088:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    708c:	54000041 	b.ne	7094 <fwp_arg_drop23+0x10>  // b.any
    7090:	d65f03c0 	ret
    7094:	f9400000 	ldr	x0, [x0]
    7098:	17ffff6a 	b	6e40 <fwp_drop2>
    709c:	d503201f 	nop

00000000000070a0 <fwp_args23>:
    70a0:	7100003f 	cmp	w1, #0x0
    70a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    70a8:	54000041 	b.ne	70b0 <fwp_args23+0x10>  // b.any
    70ac:	d65f03c0 	ret
    70b0:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    70b4:	91190042 	add	x2, x2, #0x640
    70b8:	f9400001 	ldr	x1, [x0]
    70bc:	f949d843 	ldr	x3, [x2, #5040]
    70c0:	f949ec40 	ldr	x0, [x2, #5080]
    70c4:	cb030021 	sub	x1, x1, x3
    70c8:	eb00403f 	cmp	x1, x0, lsl #16
    70cc:	54ffff02 	b.cs	70ac <fwp_args23+0xc>  // b.hs, b.nlast
    70d0:	d350fc20 	lsr	x0, x1, #16
    70d4:	f949fc44 	ldr	x4, [x2, #5112]
    70d8:	8b000800 	add	x0, x0, x0, lsl #2
    70dc:	d37df002 	lsl	x2, x0, #3
    70e0:	8b020083 	add	x3, x4, x2
    70e4:	f9401060 	ldr	x0, [x3, #32]
    70e8:	b4fffe20 	cbz	x0, 70ac <fwp_args23+0xc>
    70ec:	38626882 	ldrb	w2, [x4, x2]
    70f0:	7100085f 	cmp	w2, #0x2
    70f4:	54000320 	b.eq	7158 <fwp_args23+0xb8>  // b.none
    70f8:	7100045f 	cmp	w2, #0x1
    70fc:	54fffd81 	b.ne	70ac <fwp_args23+0xc>  // b.any
    7100:	29430864 	ldp	w4, w2, [x3, #24]
    7104:	92403c21 	and	x1, x1, #0xffff
    7108:	9b047c21 	mul	x1, x1, x4
    710c:	d360fc21 	lsr	x1, x1, #32
    7110:	eb02003f 	cmp	x1, x2
    7114:	54fffcc2 	b.cs	70ac <fwp_args23+0xc>  // b.hs, b.nlast
    7118:	8b010000 	add	x0, x0, x1
    711c:	39400001 	ldrb	w1, [x0]
    7120:	34fffc61 	cbz	w1, 70ac <fwp_args23+0xc>
    7124:	b00000c2 	adrp	x2, 20000 <__data_start>
    7128:	91018042 	add	x2, x2, #0x60
    712c:	b9413043 	ldr	w3, [x2, #304]
    7130:	350000c3 	cbnz	w3, 7148 <fwp_args23+0xa8>
    7134:	7103f43f 	cmp	w1, #0xfd
    7138:	54000168 	b.hi	7164 <fwp_args23+0xc4>  // b.pmore
    713c:	11000421 	add	w1, w1, #0x1
    7140:	39000001 	strb	w1, [x0]
    7144:	d65f03c0 	ret
    7148:	f940ac43 	ldr	x3, [x2, #344]
    714c:	91000463 	add	x3, x3, #0x1
    7150:	f900ac43 	str	x3, [x2, #344]
    7154:	17fffff8 	b	7134 <fwp_args23+0x94>
    7158:	72003c3f 	tst	w1, #0xffff
    715c:	54fffe00 	b.eq	711c <fwp_args23+0x7c>  // b.none
    7160:	d65f03c0 	ret
    7164:	17fff5c4 	b	4874 <fwp_rc_wide_dup>
    7168:	d503201f 	nop
    716c:	d503201f 	nop

0000000000007170 <fwp_args12>:
    7170:	7100003f 	cmp	w1, #0x0
    7174:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7178:	54000041 	b.ne	7180 <fwp_args12+0x10>  // b.any
    717c:	d65f03c0 	ret
    7180:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    7184:	91190042 	add	x2, x2, #0x640
    7188:	f9400001 	ldr	x1, [x0]
    718c:	f949d843 	ldr	x3, [x2, #5040]
    7190:	f949ec40 	ldr	x0, [x2, #5080]
    7194:	cb030021 	sub	x1, x1, x3
    7198:	eb00403f 	cmp	x1, x0, lsl #16
    719c:	54ffff02 	b.cs	717c <fwp_args12+0xc>  // b.hs, b.nlast
    71a0:	d350fc20 	lsr	x0, x1, #16
    71a4:	f949fc44 	ldr	x4, [x2, #5112]
    71a8:	8b000800 	add	x0, x0, x0, lsl #2
    71ac:	d37df002 	lsl	x2, x0, #3
    71b0:	8b020083 	add	x3, x4, x2
    71b4:	f9401060 	ldr	x0, [x3, #32]
    71b8:	b4fffe20 	cbz	x0, 717c <fwp_args12+0xc>
    71bc:	38626882 	ldrb	w2, [x4, x2]
    71c0:	7100085f 	cmp	w2, #0x2
    71c4:	54000320 	b.eq	7228 <fwp_args12+0xb8>  // b.none
    71c8:	7100045f 	cmp	w2, #0x1
    71cc:	54fffd81 	b.ne	717c <fwp_args12+0xc>  // b.any
    71d0:	29430864 	ldp	w4, w2, [x3, #24]
    71d4:	92403c21 	and	x1, x1, #0xffff
    71d8:	9b047c21 	mul	x1, x1, x4
    71dc:	d360fc21 	lsr	x1, x1, #32
    71e0:	eb02003f 	cmp	x1, x2
    71e4:	54fffcc2 	b.cs	717c <fwp_args12+0xc>  // b.hs, b.nlast
    71e8:	8b010000 	add	x0, x0, x1
    71ec:	39400001 	ldrb	w1, [x0]
    71f0:	34fffc61 	cbz	w1, 717c <fwp_args12+0xc>
    71f4:	b00000c2 	adrp	x2, 20000 <__data_start>
    71f8:	91018042 	add	x2, x2, #0x60
    71fc:	b9413043 	ldr	w3, [x2, #304]
    7200:	350000c3 	cbnz	w3, 7218 <fwp_args12+0xa8>
    7204:	7103f43f 	cmp	w1, #0xfd
    7208:	54000168 	b.hi	7234 <fwp_args12+0xc4>  // b.pmore
    720c:	11000421 	add	w1, w1, #0x1
    7210:	39000001 	strb	w1, [x0]
    7214:	d65f03c0 	ret
    7218:	f940ac43 	ldr	x3, [x2, #344]
    721c:	91000463 	add	x3, x3, #0x1
    7220:	f900ac43 	str	x3, [x2, #344]
    7224:	17fffff8 	b	7204 <fwp_args12+0x94>
    7228:	72003c3f 	tst	w1, #0xffff
    722c:	54fffe00 	b.eq	71ec <fwp_args12+0x7c>  // b.none
    7230:	d65f03c0 	ret
    7234:	17fff590 	b	4874 <fwp_rc_wide_dup>
    7238:	d503201f 	nop
    723c:	d503201f 	nop

0000000000007240 <fwp_caps23>:
    7240:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7244:	910003fd 	mov	x29, sp
    7248:	f9000bf3 	str	x19, [sp, #16]
    724c:	aa0003f3 	mov	x19, x0
    7250:	b9400400 	ldr	w0, [x0, #4]
    7254:	340004a0 	cbz	w0, 72e8 <fwp_caps23+0xa8>
    7258:	f9400660 	ldr	x0, [x19, #8]
    725c:	350004e1 	cbnz	w1, 72f8 <fwp_caps23+0xb8>
    7260:	97fffef8 	bl	6e40 <fwp_drop2>
    7264:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    7268:	91190042 	add	x2, x2, #0x640
    726c:	f949d840 	ldr	x0, [x2, #5040]
    7270:	f949ec41 	ldr	x1, [x2, #5080]
    7274:	cb000260 	sub	x0, x19, x0
    7278:	eb01401f 	cmp	x0, x1, lsl #16
    727c:	54000382 	b.cs	72ec <fwp_caps23+0xac>  // b.hs, b.nlast
    7280:	d350fc01 	lsr	x1, x0, #16
    7284:	f949fc44 	ldr	x4, [x2, #5112]
    7288:	8b010821 	add	x1, x1, x1, lsl #2
    728c:	d37df021 	lsl	x1, x1, #3
    7290:	8b010083 	add	x3, x4, x1
    7294:	f9401062 	ldr	x2, [x3, #32]
    7298:	b40002a2 	cbz	x2, 72ec <fwp_caps23+0xac>
    729c:	38616881 	ldrb	w1, [x4, x1]
    72a0:	7100083f 	cmp	w1, #0x2
    72a4:	54000740 	b.eq	738c <fwp_caps23+0x14c>  // b.none
    72a8:	7100043f 	cmp	w1, #0x1
    72ac:	54000201 	b.ne	72ec <fwp_caps23+0xac>  // b.any
    72b0:	29430464 	ldp	w4, w1, [x3, #24]
    72b4:	92403c00 	and	x0, x0, #0xffff
    72b8:	9b047c00 	mul	x0, x0, x4
    72bc:	d360fc00 	lsr	x0, x0, #32
    72c0:	eb01001f 	cmp	x0, x1
    72c4:	54000142 	b.cs	72ec <fwp_caps23+0xac>  // b.hs, b.nlast
    72c8:	8b000042 	add	x2, x2, x0
    72cc:	39400040 	ldrb	w0, [x2]
    72d0:	7100041f 	cmp	w0, #0x1
    72d4:	540000c1 	b.ne	72ec <fwp_caps23+0xac>  // b.any
    72d8:	aa1303e0 	mov	x0, x19
    72dc:	f9400bf3 	ldr	x19, [sp, #16]
    72e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    72e4:	17fff64b 	b	4c10 <fwp_mem_free>
    72e8:	34fffbe1 	cbz	w1, 7264 <fwp_caps23+0x24>
    72ec:	f9400bf3 	ldr	x19, [sp, #16]
    72f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    72f4:	d65f03c0 	ret
    72f8:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    72fc:	91190042 	add	x2, x2, #0x640
    7300:	f949d843 	ldr	x3, [x2, #5040]
    7304:	f949ec41 	ldr	x1, [x2, #5080]
    7308:	cb030000 	sub	x0, x0, x3
    730c:	eb01401f 	cmp	x0, x1, lsl #16
    7310:	54fffee2 	b.cs	72ec <fwp_caps23+0xac>  // b.hs, b.nlast
    7314:	d350fc01 	lsr	x1, x0, #16
    7318:	f949fc44 	ldr	x4, [x2, #5112]
    731c:	8b010821 	add	x1, x1, x1, lsl #2
    7320:	d37df021 	lsl	x1, x1, #3
    7324:	8b010083 	add	x3, x4, x1
    7328:	f9401062 	ldr	x2, [x3, #32]
    732c:	b4fffe02 	cbz	x2, 72ec <fwp_caps23+0xac>
    7330:	38616881 	ldrb	w1, [x4, x1]
    7334:	7100083f 	cmp	w1, #0x2
    7338:	54000300 	b.eq	7398 <fwp_caps23+0x158>  // b.none
    733c:	7100043f 	cmp	w1, #0x1
    7340:	54fffd61 	b.ne	72ec <fwp_caps23+0xac>  // b.any
    7344:	92403c01 	and	x1, x0, #0xffff
    7348:	29430064 	ldp	w4, w0, [x3, #24]
    734c:	9b047c21 	mul	x1, x1, x4
    7350:	d360fc21 	lsr	x1, x1, #32
    7354:	eb00003f 	cmp	x1, x0
    7358:	54fffca2 	b.cs	72ec <fwp_caps23+0xac>  // b.hs, b.nlast
    735c:	8b010042 	add	x2, x2, x1
    7360:	39400040 	ldrb	w0, [x2]
    7364:	34fffc40 	cbz	w0, 72ec <fwp_caps23+0xac>
    7368:	b00000c1 	adrp	x1, 20000 <__data_start>
    736c:	91018021 	add	x1, x1, #0x60
    7370:	b9413023 	ldr	w3, [x1, #304]
    7374:	35000183 	cbnz	w3, 73a4 <fwp_caps23+0x164>
    7378:	7103f41f 	cmp	w0, #0xfd
    737c:	540001c8 	b.hi	73b4 <fwp_caps23+0x174>  // b.pmore
    7380:	11000400 	add	w0, w0, #0x1
    7384:	39000040 	strb	w0, [x2]
    7388:	17ffffd9 	b	72ec <fwp_caps23+0xac>
    738c:	72003c1f 	tst	w0, #0xffff
    7390:	54fffae1 	b.ne	72ec <fwp_caps23+0xac>  // b.any
    7394:	17ffffce 	b	72cc <fwp_caps23+0x8c>
    7398:	72003c1f 	tst	w0, #0xffff
    739c:	54fffa81 	b.ne	72ec <fwp_caps23+0xac>  // b.any
    73a0:	17fffff0 	b	7360 <fwp_caps23+0x120>
    73a4:	f940ac23 	ldr	x3, [x1, #344]
    73a8:	91000463 	add	x3, x3, #0x1
    73ac:	f900ac23 	str	x3, [x1, #344]
    73b0:	17fffff2 	b	7378 <fwp_caps23+0x138>
    73b4:	f9400bf3 	ldr	x19, [sp, #16]
    73b8:	aa0203e0 	mov	x0, x2
    73bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    73c0:	17fff52d 	b	4874 <fwp_rc_wide_dup>

00000000000073c4 <fwp_caps12>:
    73c4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    73c8:	910003fd 	mov	x29, sp
    73cc:	f9000bf3 	str	x19, [sp, #16]
    73d0:	aa0003f3 	mov	x19, x0
    73d4:	b9400400 	ldr	w0, [x0, #4]
    73d8:	340004a0 	cbz	w0, 746c <fwp_caps12+0xa8>
    73dc:	f9400660 	ldr	x0, [x19, #8]
    73e0:	350004e1 	cbnz	w1, 747c <fwp_caps12+0xb8>
    73e4:	97fffb63 	bl	6170 <fwp_drop0>
    73e8:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    73ec:	91190042 	add	x2, x2, #0x640
    73f0:	f949d840 	ldr	x0, [x2, #5040]
    73f4:	f949ec41 	ldr	x1, [x2, #5080]
    73f8:	cb000260 	sub	x0, x19, x0
    73fc:	eb01401f 	cmp	x0, x1, lsl #16
    7400:	54000382 	b.cs	7470 <fwp_caps12+0xac>  // b.hs, b.nlast
    7404:	d350fc01 	lsr	x1, x0, #16
    7408:	f949fc44 	ldr	x4, [x2, #5112]
    740c:	8b010821 	add	x1, x1, x1, lsl #2
    7410:	d37df021 	lsl	x1, x1, #3
    7414:	8b010083 	add	x3, x4, x1
    7418:	f9401062 	ldr	x2, [x3, #32]
    741c:	b40002a2 	cbz	x2, 7470 <fwp_caps12+0xac>
    7420:	38616881 	ldrb	w1, [x4, x1]
    7424:	7100083f 	cmp	w1, #0x2
    7428:	54000740 	b.eq	7510 <fwp_caps12+0x14c>  // b.none
    742c:	7100043f 	cmp	w1, #0x1
    7430:	54000201 	b.ne	7470 <fwp_caps12+0xac>  // b.any
    7434:	29430464 	ldp	w4, w1, [x3, #24]
    7438:	92403c00 	and	x0, x0, #0xffff
    743c:	9b047c00 	mul	x0, x0, x4
    7440:	d360fc00 	lsr	x0, x0, #32
    7444:	eb01001f 	cmp	x0, x1
    7448:	54000142 	b.cs	7470 <fwp_caps12+0xac>  // b.hs, b.nlast
    744c:	8b000042 	add	x2, x2, x0
    7450:	39400040 	ldrb	w0, [x2]
    7454:	7100041f 	cmp	w0, #0x1
    7458:	540000c1 	b.ne	7470 <fwp_caps12+0xac>  // b.any
    745c:	aa1303e0 	mov	x0, x19
    7460:	f9400bf3 	ldr	x19, [sp, #16]
    7464:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7468:	17fff5ea 	b	4c10 <fwp_mem_free>
    746c:	34fffbe1 	cbz	w1, 73e8 <fwp_caps12+0x24>
    7470:	f9400bf3 	ldr	x19, [sp, #16]
    7474:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7478:	d65f03c0 	ret
    747c:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xba0>
    7480:	91190042 	add	x2, x2, #0x640
    7484:	f949d843 	ldr	x3, [x2, #5040]
    7488:	f949ec41 	ldr	x1, [x2, #5080]
    748c:	cb030000 	sub	x0, x0, x3
    7490:	eb01401f 	cmp	x0, x1, lsl #16
    7494:	54fffee2 	b.cs	7470 <fwp_caps12+0xac>  // b.hs, b.nlast
    7498:	d350fc01 	lsr	x1, x0, #16
    749c:	f949fc44 	ldr	x4, [x2, #5112]
    74a0:	8b010821 	add	x1, x1, x1, lsl #2
    74a4:	d37df021 	lsl	x1, x1, #3
    74a8:	8b010083 	add	x3, x4, x1
    74ac:	f9401062 	ldr	x2, [x3, #32]
    74b0:	b4fffe02 	cbz	x2, 7470 <fwp_caps12+0xac>
    74b4:	38616881 	ldrb	w1, [x4, x1]
    74b8:	7100083f 	cmp	w1, #0x2
    74bc:	54000300 	b.eq	751c <fwp_caps12+0x158>  // b.none
    74c0:	7100043f 	cmp	w1, #0x1
    74c4:	54fffd61 	b.ne	7470 <fwp_caps12+0xac>  // b.any
    74c8:	92403c01 	and	x1, x0, #0xffff
    74cc:	29430064 	ldp	w4, w0, [x3, #24]
    74d0:	9b047c21 	mul	x1, x1, x4
    74d4:	d360fc21 	lsr	x1, x1, #32
    74d8:	eb00003f 	cmp	x1, x0
    74dc:	54fffca2 	b.cs	7470 <fwp_caps12+0xac>  // b.hs, b.nlast
    74e0:	8b010042 	add	x2, x2, x1
    74e4:	39400040 	ldrb	w0, [x2]
    74e8:	34fffc40 	cbz	w0, 7470 <fwp_caps12+0xac>
    74ec:	b00000c1 	adrp	x1, 20000 <__data_start>
    74f0:	91018021 	add	x1, x1, #0x60
    74f4:	b9413023 	ldr	w3, [x1, #304]
    74f8:	35000183 	cbnz	w3, 7528 <fwp_caps12+0x164>
    74fc:	7103f41f 	cmp	w0, #0xfd
    7500:	540001c8 	b.hi	7538 <fwp_caps12+0x174>  // b.pmore
    7504:	11000400 	add	w0, w0, #0x1
    7508:	39000040 	strb	w0, [x2]
    750c:	17ffffd9 	b	7470 <fwp_caps12+0xac>
    7510:	72003c1f 	tst	w0, #0xffff
    7514:	54fffae1 	b.ne	7470 <fwp_caps12+0xac>  // b.any
    7518:	17ffffce 	b	7450 <fwp_caps12+0x8c>
    751c:	72003c1f 	tst	w0, #0xffff
    7520:	54fffa81 	b.ne	7470 <fwp_caps12+0xac>  // b.any
    7524:	17fffff0 	b	74e4 <fwp_caps12+0x120>
    7528:	f940ac23 	ldr	x3, [x1, #344]
    752c:	91000463 	add	x3, x3, #0x1
    7530:	f900ac23 	str	x3, [x1, #344]
    7534:	17fffff2 	b	74fc <fwp_caps12+0x138>
    7538:	f9400bf3 	ldr	x19, [sp, #16]
    753c:	aa0203e0 	mov	x0, x2
    7540:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7544:	17fff4cc 	b	4874 <fwp_rc_wide_dup>
    7548:	d503201f 	nop
    754c:	d503201f 	nop

0000000000007550 <f23>:
    7550:	d101c3ff 	sub	sp, sp, #0x70
    7554:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    7558:	f947f421 	ldr	x1, [x1, #4072]
    755c:	a9027bfd 	stp	x29, x30, [sp, #32]
    7560:	910083fd 	add	x29, sp, #0x20
    7564:	a90563f7 	stp	x23, x24, [sp, #80]
    7568:	d0000397 	adrp	x23, 79000 <fwp_root_context+0xba0>
    756c:	911902e3 	add	x3, x23, #0x640
    7570:	a90353f3 	stp	x19, x20, [sp, #48]
    7574:	a9045bf5 	stp	x21, x22, [sp, #64]
    7578:	aa0003f6 	mov	x22, x0
    757c:	a9066bf9 	stp	x25, x26, [sp, #96]
    7580:	f949ec62 	ldr	x2, [x3, #5080]
    7584:	f9400024 	ldr	x4, [x1]
    7588:	f9000fe4 	str	x4, [sp, #24]
    758c:	d2800004 	mov	x4, #0x0                   	// #0
    7590:	f949d861 	ldr	x1, [x3, #5040]
    7594:	d370bc42 	lsl	x2, x2, #16
    7598:	b40016c0 	cbz	x0, 7870 <f23+0x320>
    759c:	f9400818 	ldr	x24, [x0, #16]
    75a0:	cb010301 	sub	x1, x24, x1
    75a4:	eb02003f 	cmp	x1, x2
    75a8:	540003e2 	b.cs	7624 <f23+0xd4>  // b.hs, b.nlast
    75ac:	f949fc60 	ldr	x0, [x3, #5112]
    75b0:	d350fc22 	lsr	x2, x1, #16
    75b4:	8b020842 	add	x2, x2, x2, lsl #2
    75b8:	8b020c02 	add	x2, x0, x2, lsl #3
    75bc:	f9401040 	ldr	x0, [x2, #32]
    75c0:	b4000320 	cbz	x0, 7624 <f23+0xd4>
    75c4:	39400043 	ldrb	w3, [x2]
    75c8:	7100087f 	cmp	w3, #0x2
    75cc:	54001440 	b.eq	7854 <f23+0x304>  // b.none
    75d0:	7100047f 	cmp	w3, #0x1
    75d4:	54000241 	b.ne	761c <f23+0xcc>  // b.any
    75d8:	29430843 	ldp	w3, w2, [x2, #24]
    75dc:	92403c21 	and	x1, x1, #0xffff
    75e0:	9b037c21 	mul	x1, x1, x3
    75e4:	d360fc21 	lsr	x1, x1, #32
    75e8:	eb02003f 	cmp	x1, x2
    75ec:	54000182 	b.cs	761c <f23+0xcc>  // b.hs, b.nlast
    75f0:	8b010000 	add	x0, x0, x1
    75f4:	39400001 	ldrb	w1, [x0]
    75f8:	34000121 	cbz	w1, 761c <f23+0xcc>
    75fc:	b00000c2 	adrp	x2, 20000 <__data_start>
    7600:	91018042 	add	x2, x2, #0x60
    7604:	b9413043 	ldr	w3, [x2, #304]
    7608:	350012c3 	cbnz	w3, 7860 <f23+0x310>
    760c:	7103f43f 	cmp	w1, #0xfd
    7610:	54001728 	b.hi	78f4 <f23+0x3a4>  // b.pmore
    7614:	11000421 	add	w1, w1, #0x1
    7618:	39000001 	strb	w1, [x0]
    761c:	d2800000 	mov	x0, #0x0                   	// #0
    7620:	b40000f6 	cbz	x22, 763c <f23+0xec>
    7624:	aa1603e1 	mov	x1, x22
    7628:	d2800000 	mov	x0, #0x0                   	// #0
    762c:	d503201f 	nop
    7630:	f9400821 	ldr	x1, [x1, #16]
    7634:	91000400 	add	x0, x0, #0x1
    7638:	b5ffffc1 	cbnz	x1, 7630 <f23+0xe0>
    763c:	b4001238 	cbz	x24, 7880 <f23+0x330>
    7640:	aa1803e1 	mov	x1, x24
    7644:	d2800002 	mov	x2, #0x0                   	// #0
    7648:	f9400821 	ldr	x1, [x1, #16]
    764c:	91000442 	add	x2, x2, #0x1
    7650:	b5ffffc1 	cbnz	x1, 7648 <f23+0xf8>
    7654:	eb00005f 	cmp	x2, x0
    7658:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    765c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    7660:	eb01033f 	cmp	x25, x1
    7664:	540014e8 	b.hi	7900 <f23+0x3b0>  // b.pmore
    7668:	d37ffb33 	lsl	x19, x25, #1
    766c:	52800041 	mov	w1, #0x2                   	// #2
    7670:	91000660 	add	x0, x19, #0x1
    7674:	d37df000 	lsl	x0, x0, #3
    7678:	97fff686 	bl	5090 <fwp_heap_alloc>
    767c:	911902e1 	add	x1, x23, #0x640
    7680:	aa0003fa 	mov	x26, x0
    7684:	f9000013 	str	x19, [x0]
    7688:	aa0103e0 	mov	x0, x1
    768c:	f949d821 	ldr	x1, [x1, #5040]
    7690:	f949ec00 	ldr	x0, [x0, #5080]
    7694:	cb010341 	sub	x1, x26, x1
    7698:	eb00403f 	cmp	x1, x0, lsl #16
    769c:	54000342 	b.cs	7704 <f23+0x1b4>  // b.hs, b.nlast
    76a0:	911902e2 	add	x2, x23, #0x640
    76a4:	d350fc20 	lsr	x0, x1, #16
    76a8:	8b000800 	add	x0, x0, x0, lsl #2
    76ac:	f949fc43 	ldr	x3, [x2, #5112]
    76b0:	d37df002 	lsl	x2, x0, #3
    76b4:	8b020060 	add	x0, x3, x2
    76b8:	f9401013 	ldr	x19, [x0, #32]
    76bc:	b4000253 	cbz	x19, 7704 <f23+0x1b4>
    76c0:	38626862 	ldrb	w2, [x3, x2]
    76c4:	7100085f 	cmp	w2, #0x2
    76c8:	54000c00 	b.eq	7848 <f23+0x2f8>  // b.none
    76cc:	7100045f 	cmp	w2, #0x1
    76d0:	540001a1 	b.ne	7704 <f23+0x1b4>  // b.any
    76d4:	29430002 	ldp	w2, w0, [x0, #24]
    76d8:	92403c21 	and	x1, x1, #0xffff
    76dc:	9b027c21 	mul	x1, x1, x2
    76e0:	d360fc21 	lsr	x1, x1, #32
    76e4:	eb00003f 	cmp	x1, x0
    76e8:	540000e2 	b.cs	7704 <f23+0x1b4>  // b.hs, b.nlast
    76ec:	8b010273 	add	x19, x19, x1
    76f0:	39400260 	ldrb	w0, [x19]
    76f4:	7103fc1f 	cmp	w0, #0xff
    76f8:	54000e80 	b.eq	78c8 <f23+0x378>  // b.none
    76fc:	52800020 	mov	w0, #0x1                   	// #1
    7700:	39000260 	strb	w0, [x19]
    7704:	b4000259 	cbz	x25, 774c <f23+0x1fc>
    7708:	8b191359 	add	x25, x26, x25, lsl #4
    770c:	aa1a03f3 	mov	x19, x26
    7710:	aa1603f5 	mov	x21, x22
    7714:	aa1803f4 	mov	x20, x24
    7718:	f9400683 	ldr	x3, [x20, #8]
    771c:	f94006a2 	ldr	x2, [x21, #8]
    7720:	f9400861 	ldr	x1, [x3, #16]
    7724:	f9400840 	ldr	x0, [x2, #16]
    7728:	fd400461 	ldr	d1, [x3, #8]
    772c:	fd400440 	ldr	d0, [x2, #8]
    7730:	97fff824 	bl	57c0 <w107>
    7734:	f9000660 	str	x0, [x19, #8]
    7738:	f8010e61 	str	x1, [x19, #16]!
    773c:	f9400a94 	ldr	x20, [x20, #16]
    7740:	f9400ab5 	ldr	x21, [x21, #16]
    7744:	eb13033f 	cmp	x25, x19
    7748:	54fffe81 	b.ne	7718 <f23+0x1c8>  // b.any
    774c:	aa1803e0 	mov	x0, x24
    7750:	97fffdbc 	bl	6e40 <fwp_drop2>
    7754:	aa1603e0 	mov	x0, x22
    7758:	97fffdba 	bl	6e40 <fwp_drop2>
    775c:	911902f7 	add	x23, x23, #0x640
    7760:	aa1a03e0 	mov	x0, x26
    7764:	97fff874 	bl	5934 <w164.constprop.0>
    7768:	aa0103f3 	mov	x19, x1
    776c:	aa0003f4 	mov	x20, x0
    7770:	aa1a03e0 	mov	x0, x26
    7774:	97fffd13 	bl	6bc0 <fwp_drop4>
    7778:	a900cff4 	stp	x20, x19, [sp, #8]
    777c:	910023e1 	add	x1, sp, #0x8
    7780:	52800000 	mov	w0, #0x0                   	// #0
    7784:	97fff894 	bl	59d4 <fwp_data.part.0.constprop.0>
    7788:	f949dae1 	ldr	x1, [x23, #5040]
    778c:	aa0003f3 	mov	x19, x0
    7790:	f949eee0 	ldr	x0, [x23, #5080]
    7794:	cb010261 	sub	x1, x19, x1
    7798:	eb00403f 	cmp	x1, x0, lsl #16
    779c:	54000322 	b.cs	7800 <f23+0x2b0>  // b.hs, b.nlast
    77a0:	d350fc22 	lsr	x2, x1, #16
    77a4:	f949fee3 	ldr	x3, [x23, #5112]
    77a8:	8b020842 	add	x2, x2, x2, lsl #2
    77ac:	d37df042 	lsl	x2, x2, #3
    77b0:	8b020060 	add	x0, x3, x2
    77b4:	f9401014 	ldr	x20, [x0, #32]
    77b8:	b4000254 	cbz	x20, 7800 <f23+0x2b0>
    77bc:	38626862 	ldrb	w2, [x3, x2]
    77c0:	7100085f 	cmp	w2, #0x2
    77c4:	540003c0 	b.eq	783c <f23+0x2ec>  // b.none
    77c8:	7100045f 	cmp	w2, #0x1
    77cc:	540001a1 	b.ne	7800 <f23+0x2b0>  // b.any
    77d0:	29430002 	ldp	w2, w0, [x0, #24]
    77d4:	92403c21 	and	x1, x1, #0xffff
    77d8:	9b027c21 	mul	x1, x1, x2
    77dc:	d360fc21 	lsr	x1, x1, #32
    77e0:	eb00003f 	cmp	x1, x0
    77e4:	540000e2 	b.cs	7800 <f23+0x2b0>  // b.hs, b.nlast
    77e8:	8b010294 	add	x20, x20, x1
    77ec:	39400280 	ldrb	w0, [x20]
    77f0:	7103fc1f 	cmp	w0, #0xff
    77f4:	54000640 	b.eq	78bc <f23+0x36c>  // b.none
    77f8:	52800020 	mov	w0, #0x1                   	// #1
    77fc:	39000280 	strb	w0, [x20]
    7800:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    7804:	f947f400 	ldr	x0, [x0, #4072]
    7808:	f9400fe2 	ldr	x2, [sp, #24]
    780c:	f9400001 	ldr	x1, [x0]
    7810:	eb010042 	subs	x2, x2, x1
    7814:	d2800001 	mov	x1, #0x0                   	// #0
    7818:	54000721 	b.ne	78fc <f23+0x3ac>  // b.any
    781c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7820:	aa1303e0 	mov	x0, x19
    7824:	a94353f3 	ldp	x19, x20, [sp, #48]
    7828:	a9445bf5 	ldp	x21, x22, [sp, #64]
    782c:	a94563f7 	ldp	x23, x24, [sp, #80]
    7830:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7834:	9101c3ff 	add	sp, sp, #0x70
    7838:	d65f03c0 	ret
    783c:	72003c3f 	tst	w1, #0xffff
    7840:	54fffe01 	b.ne	7800 <f23+0x2b0>  // b.any
    7844:	17ffffea 	b	77ec <f23+0x29c>
    7848:	72003c3f 	tst	w1, #0xffff
    784c:	54fff5c1 	b.ne	7704 <f23+0x1b4>  // b.any
    7850:	17ffffa8 	b	76f0 <f23+0x1a0>
    7854:	72003c3f 	tst	w1, #0xffff
    7858:	54ffee21 	b.ne	761c <f23+0xcc>  // b.any
    785c:	17ffff66 	b	75f4 <f23+0xa4>
    7860:	f940ac43 	ldr	x3, [x2, #344]
    7864:	91000463 	add	x3, x3, #0x1
    7868:	f900ac43 	str	x3, [x2, #344]
    786c:	17ffff68 	b	760c <f23+0xbc>
    7870:	cb0103e1 	neg	x1, x1
    7874:	eb02003f 	cmp	x1, x2
    7878:	540002e3 	b.cc	78d4 <f23+0x384>  // b.lo, b.ul, b.last
    787c:	d503201f 	nop
    7880:	52800041 	mov	w1, #0x2                   	// #2
    7884:	d2800100 	mov	x0, #0x8                   	// #8
    7888:	97fff602 	bl	5090 <fwp_heap_alloc>
    788c:	aa0003e1 	mov	x1, x0
    7890:	911902e0 	add	x0, x23, #0x640
    7894:	aa0103fa 	mov	x26, x1
    7898:	d2800018 	mov	x24, #0x0                   	// #0
    789c:	f900003f 	str	xzr, [x1]
    78a0:	f949d801 	ldr	x1, [x0, #5040]
    78a4:	f949ec00 	ldr	x0, [x0, #5080]
    78a8:	cb010341 	sub	x1, x26, x1
    78ac:	eb00403f 	cmp	x1, x0, lsl #16
    78b0:	54fff4e2 	b.cs	774c <f23+0x1fc>  // b.hs, b.nlast
    78b4:	d2800019 	mov	x25, #0x0                   	// #0
    78b8:	17ffff7a 	b	76a0 <f23+0x150>
    78bc:	aa1403e0 	mov	x0, x20
    78c0:	97fff434 	bl	4990 <fwp_rc_forget_slot>
    78c4:	17ffffcd 	b	77f8 <f23+0x2a8>
    78c8:	aa1303e0 	mov	x0, x19
    78cc:	97fff431 	bl	4990 <fwp_rc_forget_slot>
    78d0:	17ffff8b 	b	76fc <f23+0x1ac>
    78d4:	f949fc62 	ldr	x2, [x3, #5112]
    78d8:	d350fc20 	lsr	x0, x1, #16
    78dc:	8b000800 	add	x0, x0, x0, lsl #2
    78e0:	8b000c42 	add	x2, x2, x0, lsl #3
    78e4:	f9401040 	ldr	x0, [x2, #32]
    78e8:	b4fffcc0 	cbz	x0, 7880 <f23+0x330>
    78ec:	d2800018 	mov	x24, #0x0                   	// #0
    78f0:	17ffff35 	b	75c4 <f23+0x74>
    78f4:	97fff3e0 	bl	4874 <fwp_rc_wide_dup>
    78f8:	17ffff49 	b	761c <f23+0xcc>
    78fc:	97ffebc5 	bl	2810 <__stack_chk_fail@plt>
    7900:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    7904:	91004000 	add	x0, x0, #0x10
    7908:	97ffef9e 	bl	3780 <fwp_trap>
    790c:	d503201f 	nop

0000000000007910 <fwp_owned_entry23>:
    7910:	f9400000 	ldr	x0, [x0]
    7914:	17ffff0f 	b	7550 <f23>
    7918:	d503201f 	nop
    791c:	d503201f 	nop

0000000000007920 <e23>:
    7920:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7924:	910003fd 	mov	x29, sp
    7928:	f9000bf3 	str	x19, [sp, #16]
    792c:	f9400013 	ldr	x19, [x0]
    7930:	aa1303e0 	mov	x0, x19
    7934:	97fff887 	bl	5b50 <fwp_rc_share>
    7938:	aa1303e0 	mov	x0, x19
    793c:	97ffff05 	bl	7550 <f23>
    7940:	aa0003f3 	mov	x19, x0
    7944:	97fff883 	bl	5b50 <fwp_rc_share>
    7948:	aa1303e0 	mov	x0, x19
    794c:	f9400bf3 	ldr	x19, [sp, #16]
    7950:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7954:	d65f03c0 	ret
    7958:	d503201f 	nop
    795c:	d503201f 	nop

0000000000007960 <f12>:
    7960:	d10483ff 	sub	sp, sp, #0x120
    7964:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    7968:	f947f442 	ldr	x2, [x2, #4072]
    796c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    7970:	910303fd 	add	x29, sp, #0xc0
    7974:	a90f63f7 	stp	x23, x24, [sp, #240]
    7978:	d0000397 	adrp	x23, 79000 <fwp_root_context+0xba0>
    797c:	911902e3 	add	x3, x23, #0x640
    7980:	a90e5bf5 	stp	x21, x22, [sp, #224]
    7984:	b00000d5 	adrp	x21, 20000 <__data_start>
    7988:	910182a4 	add	x4, x21, #0x60
    798c:	f949d861 	ldr	x1, [x3, #5040]
    7990:	a90d53f3 	stp	x19, x20, [sp, #208]
    7994:	910103f8 	add	x24, sp, #0x40
    7998:	f949ec65 	ldr	x5, [x3, #5080]
    799c:	a9106bf9 	stp	x25, x26, [sp, #256]
    79a0:	b00000d9 	adrp	x25, 20000 <__data_start>
    79a4:	a91173fb 	stp	x27, x28, [sp, #272]
    79a8:	91004339 	add	x25, x25, #0x10
    79ac:	91008339 	add	x25, x25, #0x20
    79b0:	f941c886 	ldr	x6, [x4, #912]
    79b4:	f9400047 	ldr	x7, [x2]
    79b8:	f9005fe7 	str	x7, [sp, #184]
    79bc:	d2800007 	mov	x7, #0x0                   	// #0
    79c0:	9100e3f6 	add	x22, sp, #0x38
    79c4:	f0fffff3 	adrp	x19, 6000 <e161+0x100>
    79c8:	12800007 	mov	w7, #0xffffffff            	// #-1
    79cc:	9119c262 	add	x2, x19, #0x670
    79d0:	cb010321 	sub	x1, x25, x1
    79d4:	b9003be7 	str	w7, [sp, #56]
    79d8:	a9040be6 	stp	x6, x2, [sp, #64]
    79dc:	aa0003f4 	mov	x20, x0
    79e0:	f9002bf6 	str	x22, [sp, #80]
    79e4:	f901c898 	str	x24, [x4, #912]
    79e8:	eb05403f 	cmp	x1, x5, lsl #16
    79ec:	540003a2 	b.cs	7a60 <f12+0x100>  // b.hs, b.nlast
    79f0:	d350fc20 	lsr	x0, x1, #16
    79f4:	f949fc64 	ldr	x4, [x3, #5112]
    79f8:	8b000800 	add	x0, x0, x0, lsl #2
    79fc:	d37df002 	lsl	x2, x0, #3
    7a00:	8b020083 	add	x3, x4, x2
    7a04:	f9401060 	ldr	x0, [x3, #32]
    7a08:	b40002c0 	cbz	x0, 7a60 <f12+0x100>
    7a0c:	38626882 	ldrb	w2, [x4, x2]
    7a10:	7100085f 	cmp	w2, #0x2
    7a14:	54006de0 	b.eq	87d0 <f12+0xe70>  // b.none
    7a18:	7100045f 	cmp	w2, #0x1
    7a1c:	54000221 	b.ne	7a60 <f12+0x100>  // b.any
    7a20:	29430864 	ldp	w4, w2, [x3, #24]
    7a24:	92403c21 	and	x1, x1, #0xffff
    7a28:	9b047c21 	mul	x1, x1, x4
    7a2c:	d360fc21 	lsr	x1, x1, #32
    7a30:	eb02003f 	cmp	x1, x2
    7a34:	54000162 	b.cs	7a60 <f12+0x100>  // b.hs, b.nlast
    7a38:	8b010000 	add	x0, x0, x1
    7a3c:	39400001 	ldrb	w1, [x0]
    7a40:	34000101 	cbz	w1, 7a60 <f12+0x100>
    7a44:	910182a2 	add	x2, x21, #0x60
    7a48:	b9413043 	ldr	w3, [x2, #304]
    7a4c:	35006f63 	cbnz	w3, 8838 <f12+0xed8>
    7a50:	7103f43f 	cmp	w1, #0xfd
    7a54:	54007948 	b.hi	897c <f12+0x101c>  // b.pmore
    7a58:	11000421 	add	w1, w1, #0x1
    7a5c:	39000001 	strb	w1, [x0]
    7a60:	aa1903e0 	mov	x0, x25
    7a64:	97fffa1f 	bl	62e0 <fwp_closure_drop>
    7a68:	b4006bf4 	cbz	x20, 87e4 <f12+0xe84>
    7a6c:	aa1403e0 	mov	x0, x20
    7a70:	d2800001 	mov	x1, #0x0                   	// #0
    7a74:	d503201f 	nop
    7a78:	f9400800 	ldr	x0, [x0, #16]
    7a7c:	91000421 	add	x1, x1, #0x1
    7a80:	b5ffffc0 	cbnz	x0, 7a78 <f12+0x118>
    7a84:	aa0103fa 	mov	x26, x1
    7a88:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    7a8c:	eb00003f 	cmp	x1, x0
    7a90:	54007b48 	b.hi	89f8 <f12+0x1098>  // b.pmore
    7a94:	910182b9 	add	x25, x21, #0x60
    7a98:	b943c720 	ldr	w0, [x25, #964]
    7a9c:	34006860 	cbz	w0, 87a8 <f12+0xe48>
    7aa0:	910182a0 	add	x0, x21, #0x60
    7aa4:	f9406c1b 	ldr	x27, [x0, #216]
    7aa8:	f940b019 	ldr	x25, [x0, #352]
    7aac:	eb1b033f 	cmp	x25, x27
    7ab0:	5400358a 	b.ge	8160 <f12+0x800>  // b.tcont
    7ab4:	f9404401 	ldr	x1, [x0, #136]
    7ab8:	8b190720 	add	x0, x25, x25, lsl #1
    7abc:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    7ac0:	8b000b20 	add	x0, x25, x0, lsl #2
    7ac4:	8b000c20 	add	x0, x1, x0, lsl #3
    7ac8:	b9400401 	ldr	w1, [x0, #4]
    7acc:	35000081 	cbnz	w1, 7adc <f12+0x17c>
    7ad0:	b9400001 	ldr	w1, [x0]
    7ad4:	6b02003f 	cmp	w1, w2
    7ad8:	54003449 	b.ls	8160 <f12+0x800>  // b.plast
    7adc:	91000739 	add	x25, x25, #0x1
    7ae0:	9101a000 	add	x0, x0, #0x68
    7ae4:	eb1b033f 	cmp	x25, x27
    7ae8:	54ffff01 	b.ne	7ac8 <f12+0x168>  // b.any
    7aec:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7af0:	eb00037f 	cmp	x27, x0
    7af4:	540078ec 	b.gt	8a10 <f12+0x10b0>
    7af8:	910182a0 	add	x0, x21, #0x60
    7afc:	f9409001 	ldr	x1, [x0, #288]
    7b00:	f940441c 	ldr	x28, [x0, #136]
    7b04:	eb1b003f 	cmp	x1, x27
    7b08:	54000221 	b.ne	7b4c <f12+0x1ec>  // b.any
    7b0c:	b400721b 	cbz	x27, 894c <f12+0xfec>
    7b10:	d37ffb79 	lsl	x25, x27, #1
    7b14:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7b18:	eb00033f 	cmp	x25, x0
    7b1c:	9a80d339 	csel	x25, x25, x0, le
    7b20:	8b190721 	add	x1, x25, x25, lsl #1
    7b24:	8b010b21 	add	x1, x25, x1, lsl #2
    7b28:	d37df021 	lsl	x1, x1, #3
    7b2c:	aa1c03e0 	mov	x0, x28
    7b30:	52800002 	mov	w2, #0x0                   	// #0
    7b34:	97fff228 	bl	43d4 <ad_raw_realloc>
    7b38:	aa0003fc 	mov	x28, x0
    7b3c:	b40035e0 	cbz	x0, 81f8 <f12+0x898>
    7b40:	910182a0 	add	x0, x21, #0x60
    7b44:	f900441c 	str	x28, [x0, #136]
    7b48:	f9009019 	str	x25, [x0, #288]
    7b4c:	8b1b0761 	add	x1, x27, x27, lsl #1
    7b50:	910182a0 	add	x0, x21, #0x60
    7b54:	4f000400 	movi	v0.4s, #0x0
    7b58:	aa1b03f9 	mov	x25, x27
    7b5c:	8b010b61 	add	x1, x27, x1, lsl #2
    7b60:	9100077b 	add	x27, x27, #0x1
    7b64:	f9006c1b 	str	x27, [x0, #216]
    7b68:	8b19073b 	add	x27, x25, x25, lsl #1
    7b6c:	8b010f81 	add	x1, x28, x1, lsl #3
    7b70:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    7b74:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    7b78:	91384000 	add	x0, x0, #0xe10
    7b7c:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    7b80:	ad000020 	stp	q0, q0, [x1]
    7b84:	ad010020 	stp	q0, q0, [x1, #32]
    7b88:	ad020020 	stp	q0, q0, [x1, #64]
    7b8c:	f900303f 	str	xzr, [x1, #96]
    7b90:	f900337f 	str	xzr, [x27, #96]
    7b94:	97ffeb83 	bl	29a0 <getenv@plt>
    7b98:	b5002fc0 	cbnz	x0, 8190 <f12+0x830>
    7b9c:	d503201f 	nop
    7ba0:	910182a0 	add	x0, x21, #0x60
    7ba4:	f9408c01 	ldr	x1, [x0, #280]
    7ba8:	b50062c1 	cbnz	x1, 8800 <f12+0xea0>
    7bac:	910182a2 	add	x2, x21, #0x60
    7bb0:	2f000400 	mvni	v0.2s, #0x0
    7bb4:	b9400363 	ldr	w3, [x27]
    7bb8:	52800024 	mov	w4, #0x1                   	// #1
    7bbc:	91000720 	add	x0, x25, #0x1
    7bc0:	a900eb7a 	stp	x26, x26, [x27, #8]
    7bc4:	0b040063 	add	w3, w3, w4
    7bc8:	f941c841 	ldr	x1, [x2, #912]
    7bcc:	29001363 	stp	w3, w4, [x27]
    7bd0:	f9002b7f 	str	xzr, [x27, #80]
    7bd4:	f900b040 	str	x0, [x2, #352]
    7bd8:	fd002f60 	str	d0, [x27, #88]
    7bdc:	b4007081 	cbz	x1, 89ec <f12+0x108c>
    7be0:	9119c273 	add	x19, x19, #0x670
    7be4:	14000003 	b	7bf0 <f12+0x290>
    7be8:	f9400021 	ldr	x1, [x1]
    7bec:	b4007001 	cbz	x1, 89ec <f12+0x108c>
    7bf0:	f9400422 	ldr	x2, [x1, #8]
    7bf4:	eb13005f 	cmp	x2, x19
    7bf8:	54ffff81 	b.ne	7be8 <f12+0x288>  // b.any
    7bfc:	f9400821 	ldr	x1, [x1, #16]
    7c00:	2a1903e4 	mov	w4, w25
    7c04:	b9400022 	ldr	w2, [x1]
    7c08:	f9002b61 	str	x1, [x27, #80]
    7c0c:	b9005f62 	str	w2, [x27, #92]
    7c10:	37f80082 	tbnz	w2, #31, 7c20 <f12+0x2c0>
    7c14:	52800d05 	mov	w5, #0x68                  	// #104
    7c18:	9b257042 	smaddl	x2, w2, w5, x28
    7c1c:	b9005859 	str	w25, [x2, #88]
    7c20:	b9000024 	str	w4, [x1]
    7c24:	d3707c79 	ubfiz	x25, x3, #16, #32
    7c28:	aa000339 	orr	x25, x25, x0
    7c2c:	d2800002 	mov	x2, #0x0                   	// #0
    7c30:	aa1403e0 	mov	x0, x20
    7c34:	b4005934 	cbz	x20, 8758 <f12+0xdf8>
    7c38:	f9400800 	ldr	x0, [x0, #16]
    7c3c:	91000442 	add	x2, x2, #0x1
    7c40:	b5ffffc0 	cbnz	x0, 7c38 <f12+0x2d8>
    7c44:	aa1403e1 	mov	x1, x20
    7c48:	f9400821 	ldr	x1, [x1, #16]
    7c4c:	91000400 	add	x0, x0, #0x1
    7c50:	b5ffffc1 	cbnz	x1, 7c48 <f12+0x2e8>
    7c54:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7c58:	eb01001f 	cmp	x0, x1
    7c5c:	54006b68 	b.hi	89c8 <f12+0x1068>  // b.pmore
    7c60:	f100005f 	cmp	x2, #0x0
    7c64:	540057ad 	b.le	8758 <f12+0xdf8>
    7c68:	eb00005f 	cmp	x2, x0
    7c6c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7c70:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    7c74:	eb01027f 	cmp	x19, x1
    7c78:	54006a88 	b.hi	89c8 <f12+0x1068>  // b.pmore
    7c7c:	d37ffa7a 	lsl	x26, x19, #1
    7c80:	52800041 	mov	w1, #0x2                   	// #2
    7c84:	91000740 	add	x0, x26, #0x1
    7c88:	d37df000 	lsl	x0, x0, #3
    7c8c:	97fff501 	bl	5090 <fwp_heap_alloc>
    7c90:	aa0003fb 	mov	x27, x0
    7c94:	911902e1 	add	x1, x23, #0x640
    7c98:	aa0103e0 	mov	x0, x1
    7c9c:	f900037a 	str	x26, [x27]
    7ca0:	f949d821 	ldr	x1, [x1, #5040]
    7ca4:	f949ec00 	ldr	x0, [x0, #5080]
    7ca8:	cb010361 	sub	x1, x27, x1
    7cac:	eb00403f 	cmp	x1, x0, lsl #16
    7cb0:	54005742 	b.cs	8798 <f12+0xe38>  // b.hs, b.nlast
    7cb4:	911902e2 	add	x2, x23, #0x640
    7cb8:	d350fc20 	lsr	x0, x1, #16
    7cbc:	8b000800 	add	x0, x0, x0, lsl #2
    7cc0:	f949fc43 	ldr	x3, [x2, #5112]
    7cc4:	d37df002 	lsl	x2, x0, #3
    7cc8:	8b020060 	add	x0, x3, x2
    7ccc:	f940101a 	ldr	x26, [x0, #32]
    7cd0:	b400025a 	cbz	x26, 7d18 <f12+0x3b8>
    7cd4:	38626862 	ldrb	w2, [x3, x2]
    7cd8:	7100085f 	cmp	w2, #0x2
    7cdc:	54005740 	b.eq	87c4 <f12+0xe64>  // b.none
    7ce0:	7100045f 	cmp	w2, #0x1
    7ce4:	540001a1 	b.ne	7d18 <f12+0x3b8>  // b.any
    7ce8:	29430002 	ldp	w2, w0, [x0, #24]
    7cec:	92403c21 	and	x1, x1, #0xffff
    7cf0:	9b027c21 	mul	x1, x1, x2
    7cf4:	d360fc21 	lsr	x1, x1, #32
    7cf8:	eb00003f 	cmp	x1, x0
    7cfc:	540000e2 	b.cs	7d18 <f12+0x3b8>  // b.hs, b.nlast
    7d00:	8b01035a 	add	x26, x26, x1
    7d04:	39400340 	ldrb	w0, [x26]
    7d08:	7103fc1f 	cmp	w0, #0xff
    7d0c:	54006260 	b.eq	8958 <f12+0xff8>  // b.none
    7d10:	52800020 	mov	w0, #0x1                   	// #1
    7d14:	39000340 	strb	w0, [x26]
    7d18:	b4000233 	cbz	x19, 7d5c <f12+0x3fc>
    7d1c:	d3607f24 	lsl	x4, x25, #32
    7d20:	aa1403e2 	mov	x2, x20
    7d24:	f9400685 	ldr	x5, [x20, #8]
    7d28:	aa0403e3 	mov	x3, x4
    7d2c:	91002360 	add	x0, x27, #0x8
    7d30:	d2800001 	mov	x1, #0x0                   	// #0
    7d34:	14000005 	b	7d48 <f12+0x3e8>
    7d38:	f9400445 	ldr	x5, [x2, #8]
    7d3c:	ab040023 	adds	x3, x1, x4
    7d40:	91004000 	add	x0, x0, #0x10
    7d44:	54006706 	b.vs	8a24 <f12+0x10c4>
    7d48:	a9000c05 	stp	x5, x3, [x0]
    7d4c:	91000421 	add	x1, x1, #0x1
    7d50:	f9400842 	ldr	x2, [x2, #16]
    7d54:	eb01027f 	cmp	x19, x1
    7d58:	54ffff08 	b.hi	7d38 <f12+0x3d8>  // b.pmore
    7d5c:	f9400360 	ldr	x0, [x27]
    7d60:	f100041f 	cmp	x0, #0x1
    7d64:	540051e9 	b.ls	87a0 <f12+0xe40>  // b.plast
    7d68:	d341fc00 	lsr	x0, x0, #1
    7d6c:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    7d70:	d1000401 	sub	x1, x0, #0x1
    7d74:	eb02003f 	cmp	x1, x2
    7d78:	54006288 	b.hi	89c8 <f12+0x1068>  // b.pmore
    7d7c:	d37ff83c 	lsl	x28, x1, #1
    7d80:	b4005101 	cbz	x1, 87a0 <f12+0xe40>
    7d84:	d1002361 	sub	x1, x27, #0x8
    7d88:	91002373 	add	x19, x27, #0x8
    7d8c:	8b00103a 	add	x26, x1, x0, lsl #4
    7d90:	f9400660 	ldr	x0, [x19, #8]
    7d94:	f9400e61 	ldr	x1, [x19, #24]
    7d98:	fd400260 	ldr	d0, [x19]
    7d9c:	fd400a61 	ldr	d1, [x19, #16]
    7da0:	97fff688 	bl	57c0 <w107>
    7da4:	a9000660 	stp	x0, x1, [x19]
    7da8:	91004273 	add	x19, x19, #0x10
    7dac:	eb1a027f 	cmp	x19, x26
    7db0:	54ffff01 	b.ne	7d90 <f12+0x430>  // b.any
    7db4:	f900037c 	str	x28, [x27]
    7db8:	aa1b03e0 	mov	x0, x27
    7dbc:	93407f33 	sxtw	x19, w25
    7dc0:	97fff6dd 	bl	5934 <w164.constprop.0>
    7dc4:	aa0103fa 	mov	x26, x1
    7dc8:	aa1b03e0 	mov	x0, x27
    7dcc:	97fffb7d 	bl	6bc0 <fwp_drop4>
    7dd0:	aa1303e0 	mov	x0, x19
    7dd4:	97ffef37 	bl	3ab0 <fwp_tape_of>
    7dd8:	f9403001 	ldr	x1, [x0, #96]
    7ddc:	aa0003ea 	mov	x10, x0
    7de0:	b5006121 	cbnz	x1, 8a04 <f12+0x10a4>
    7de4:	97ffec6c 	bl	2f94 <fwp_tape_unlink_scope>
    7de8:	b9400002 	ldr	w2, [x0]
    7dec:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    7df0:	a940801c 	ldp	x28, x0, [x0, #8]
    7df4:	b900055f 	str	wzr, [x10, #4]
    7df8:	a941994b 	ldp	x11, x6, [x10, #24]
    7dfc:	a942a147 	ldp	x7, x8, [x10, #40]
    7e00:	a9439549 	ldp	x9, x5, [x10, #56]
    7e04:	f940255b 	ldr	x27, [x10, #72]
    7e08:	6b01005f 	cmp	w2, w1
    7e0c:	54000108 	b.hi	7e2c <f12+0x4cc>  // b.pmore
    7e10:	910182a2 	add	x2, x21, #0x60
    7e14:	92403e61 	and	x1, x19, #0xffff
    7e18:	d1000421 	sub	x1, x1, #0x1
    7e1c:	f940b043 	ldr	x3, [x2, #352]
    7e20:	eb03003f 	cmp	x1, x3
    7e24:	5400004a 	b.ge	7e2c <f12+0x4cc>  // b.tcont
    7e28:	f900b041 	str	x1, [x2, #352]
    7e2c:	4f000400 	movi	v0.4s, #0x0
    7e30:	910182a3 	add	x3, x21, #0x60
    7e34:	f9000d5f 	str	xzr, [x10, #24]
    7e38:	910163e1 	add	x1, sp, #0x58
    7e3c:	9101c3f9 	add	x25, sp, #0x70
    7e40:	b0ffffe2 	adrp	x2, 4000 <fwp_heap_report+0xe0>
    7e44:	f941c86c 	ldr	x12, [x3, #912]
    7e48:	3c808140 	stur	q0, [x10, #8]
    7e4c:	91129042 	add	x2, x2, #0x4a4
    7e50:	ad010140 	stp	q0, q0, [x10, #32]
    7e54:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    7e58:	a9058bec 	stp	x12, x2, [sp, #88]
    7e5c:	a9069bf9 	stp	x25, x6, [sp, #104]
    7e60:	a907a3e7 	stp	x7, x8, [sp, #120]
    7e64:	a90897e9 	stp	x9, x5, [sp, #136]
    7e68:	a909efeb 	stp	x11, x27, [sp, #152]
    7e6c:	f901c861 	str	x1, [x3, #912]
    7e70:	b7f84bfa 	tbnz	x26, #63, 87ec <f12+0xe8c>
    7e74:	eb9a827f 	cmp	x19, x26, asr #32
    7e78:	54005961 	b.ne	89a4 <f12+0x1044>  // b.any
    7e7c:	92407f53 	and	x19, x26, #0xffffffff
    7e80:	eb3a401f 	cmp	x0, w26, uxtw
    7e84:	5400596d 	b.le	89b0 <f12+0x1050>
    7e88:	eb13039f 	cmp	x28, x19
    7e8c:	9a93c793 	csinc	x19, x28, x19, gt
    7e90:	eb13037f 	cmp	x27, x19
    7e94:	540019ea 	b.ge	81d0 <f12+0x870>  // b.tcont
    7e98:	f100037f 	cmp	x27, #0x0
    7e9c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7ea0:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    7ea4:	14000004 	b	7eb4 <f12+0x554>
    7ea8:	eb01037f 	cmp	x27, x1
    7eac:	d37ffb7b 	lsl	x27, x27, #1
    7eb0:	9a93d37b 	csel	x27, x27, x19, le
    7eb4:	eb13037f 	cmp	x27, x19
    7eb8:	54ffff8b 	b.lt	7ea8 <f12+0x548>  // b.tstop
    7ebc:	b4004e05 	cbz	x5, 887c <f12+0xf1c>
    7ec0:	aa0503e0 	mov	x0, x5
    7ec4:	d37df361 	lsl	x1, x27, #3
    7ec8:	52800062 	mov	w2, #0x3                   	// #3
    7ecc:	a9009fe6 	stp	x6, x7, [sp, #8]
    7ed0:	a901a7e8 	stp	x8, x9, [sp, #24]
    7ed4:	97fff140 	bl	43d4 <ad_raw_realloc>
    7ed8:	aa0003e5 	mov	x5, x0
    7edc:	a9409fe6 	ldp	x6, x7, [sp, #8]
    7ee0:	a941a7e8 	ldp	x8, x9, [sp, #24]
    7ee4:	b4004b20 	cbz	x0, 8848 <f12+0xee8>
    7ee8:	f9004be5 	str	x5, [sp, #144]
    7eec:	f90053fb 	str	x27, [sp, #160]
    7ef0:	b50015d3 	cbnz	x19, 81a8 <f12+0x848>
    7ef4:	b7f800da 	tbnz	x26, #63, 7f0c <f12+0x5ac>
    7ef8:	92407f41 	and	x1, x26, #0xffffffff
    7efc:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7f00:	fc6178a0 	ldr	d0, [x5, x1, lsl #3]
    7f04:	1e612800 	fadd	d0, d0, d1
    7f08:	fc2178a0 	str	d0, [x5, x1, lsl #3]
    7f0c:	d1000673 	sub	x19, x19, #0x1
    7f10:	d1000783 	sub	x3, x28, #0x1
    7f14:	eb13039f 	cmp	x28, x19
    7f18:	540003ac 	b.gt	7f8c <f12+0x62c>
    7f1c:	fc7378a0 	ldr	d0, [x5, x19, lsl #3]
    7f20:	1e602008 	fcmp	d0, #0.0
    7f24:	540002e0 	b.eq	7f80 <f12+0x620>  // b.none
    7f28:	cb1c0be0 	neg	x0, x28, lsl #2
    7f2c:	cb1c03e2 	neg	x2, x28
    7f30:	8b0000c1 	add	x1, x6, x0
    7f34:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    7f38:	37f80101 	tbnz	w1, #31, 7f58 <f12+0x5f8>
    7f3c:	8b020d0a 	add	x10, x8, x2, lsl #3
    7f40:	93407c21 	sxtw	x1, w1
    7f44:	fc737942 	ldr	d2, [x10, x19, lsl #3]
    7f48:	fc6178a1 	ldr	d1, [x5, x1, lsl #3]
    7f4c:	1e620802 	fmul	d2, d0, d2
    7f50:	1e622821 	fadd	d1, d1, d2
    7f54:	fc2178a1 	str	d1, [x5, x1, lsl #3]
    7f58:	8b0000e0 	add	x0, x7, x0
    7f5c:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    7f60:	37f80100 	tbnz	w0, #31, 7f80 <f12+0x620>
    7f64:	8b020d22 	add	x2, x9, x2, lsl #3
    7f68:	93407c00 	sxtw	x0, w0
    7f6c:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    7f70:	fc6078a1 	ldr	d1, [x5, x0, lsl #3]
    7f74:	1e620800 	fmul	d0, d0, d2
    7f78:	1e602820 	fadd	d0, d1, d0
    7f7c:	fc2078a0 	str	d0, [x5, x0, lsl #3]
    7f80:	d1000673 	sub	x19, x19, #0x1
    7f84:	eb13007f 	cmp	x3, x19
    7f88:	54fffca1 	b.ne	7f1c <f12+0x5bc>  // b.any
    7f8c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7f90:	eb00039f 	cmp	x28, x0
    7f94:	54005208 	b.hi	89d4 <f12+0x1074>  // b.pmore
    7f98:	91000780 	add	x0, x28, #0x1
    7f9c:	52800041 	mov	w1, #0x2                   	// #2
    7fa0:	f90007e5 	str	x5, [sp, #8]
    7fa4:	d37df000 	lsl	x0, x0, #3
    7fa8:	97fff43a 	bl	5090 <fwp_heap_alloc>
    7fac:	aa0003e2 	mov	x2, x0
    7fb0:	aa0003f3 	mov	x19, x0
    7fb4:	f94007e5 	ldr	x5, [sp, #8]
    7fb8:	d2800001 	mov	x1, #0x0                   	// #0
    7fbc:	f800845c 	str	x28, [x2], #8
    7fc0:	b40000fc 	cbz	x28, 7fdc <f12+0x67c>
    7fc4:	d503201f 	nop
    7fc8:	f86178a0 	ldr	x0, [x5, x1, lsl #3]
    7fcc:	f8217840 	str	x0, [x2, x1, lsl #3]
    7fd0:	91000421 	add	x1, x1, #0x1
    7fd4:	eb01039f 	cmp	x28, x1
    7fd8:	54ffff81 	b.ne	7fc8 <f12+0x668>  // b.any
    7fdc:	910182a1 	add	x1, x21, #0x60
    7fe0:	aa1903e0 	mov	x0, x25
    7fe4:	f9402ffa 	ldr	x26, [sp, #88]
    7fe8:	f901c83a 	str	x26, [x1, #912]
    7fec:	97fff12e 	bl	44a4 <fwp_tape_buffers_release>
    7ff0:	911902e2 	add	x2, x23, #0x640
    7ff4:	f949d841 	ldr	x1, [x2, #5040]
    7ff8:	f949ec40 	ldr	x0, [x2, #5080]
    7ffc:	cb010261 	sub	x1, x19, x1
    8000:	eb00403f 	cmp	x1, x0, lsl #16
    8004:	54000322 	b.cs	8068 <f12+0x708>  // b.hs, b.nlast
    8008:	d350fc20 	lsr	x0, x1, #16
    800c:	f949fc43 	ldr	x3, [x2, #5112]
    8010:	8b000800 	add	x0, x0, x0, lsl #2
    8014:	d37df002 	lsl	x2, x0, #3
    8018:	8b020060 	add	x0, x3, x2
    801c:	f9401019 	ldr	x25, [x0, #32]
    8020:	b4000259 	cbz	x25, 8068 <f12+0x708>
    8024:	38626862 	ldrb	w2, [x3, x2]
    8028:	7100085f 	cmp	w2, #0x2
    802c:	54003e40 	b.eq	87f4 <f12+0xe94>  // b.none
    8030:	7100045f 	cmp	w2, #0x1
    8034:	540001a1 	b.ne	8068 <f12+0x708>  // b.any
    8038:	29430002 	ldp	w2, w0, [x0, #24]
    803c:	92403c21 	and	x1, x1, #0xffff
    8040:	9b027c21 	mul	x1, x1, x2
    8044:	d360fc21 	lsr	x1, x1, #32
    8048:	eb00003f 	cmp	x1, x0
    804c:	540000e2 	b.cs	8068 <f12+0x708>  // b.hs, b.nlast
    8050:	8b010339 	add	x25, x25, x1
    8054:	39400320 	ldrb	w0, [x25]
    8058:	7103fc1f 	cmp	w0, #0xff
    805c:	54004840 	b.eq	8964 <f12+0x1004>  // b.none
    8060:	52800020 	mov	w0, #0x1                   	// #1
    8064:	39000320 	strb	w0, [x25]
    8068:	eb18035f 	cmp	x26, x24
    806c:	54004da1 	b.ne	8a20 <f12+0x10c0>  // b.any
    8070:	f94023e1 	ldr	x1, [sp, #64]
    8074:	910182b5 	add	x21, x21, #0x60
    8078:	aa1603e0 	mov	x0, x22
    807c:	f901caa1 	str	x1, [x21, #912]
    8080:	97fff97c 	bl	6670 <fwp_tape_scope_release>
    8084:	f9400260 	ldr	x0, [x19]
    8088:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    808c:	b7f83120 	tbnz	x0, #63, 86b0 <f12+0xd50>
    8090:	911902e2 	add	x2, x23, #0x640
    8094:	f949d840 	ldr	x0, [x2, #5040]
    8098:	f949ec41 	ldr	x1, [x2, #5080]
    809c:	cb000260 	sub	x0, x19, x0
    80a0:	eb01401f 	cmp	x0, x1, lsl #16
    80a4:	54003062 	b.cs	86b0 <f12+0xd50>  // b.hs, b.nlast
    80a8:	d350fc01 	lsr	x1, x0, #16
    80ac:	f949fc44 	ldr	x4, [x2, #5112]
    80b0:	8b010821 	add	x1, x1, x1, lsl #2
    80b4:	d37df021 	lsl	x1, x1, #3
    80b8:	8b010083 	add	x3, x4, x1
    80bc:	f9401062 	ldr	x2, [x3, #32]
    80c0:	b4002f82 	cbz	x2, 86b0 <f12+0xd50>
    80c4:	38616881 	ldrb	w1, [x4, x1]
    80c8:	7100083f 	cmp	w1, #0x2
    80cc:	54002ec0 	b.eq	86a4 <f12+0xd44>  // b.none
    80d0:	7100043f 	cmp	w1, #0x1
    80d4:	54002ee1 	b.ne	86b0 <f12+0xd50>  // b.any
    80d8:	29430464 	ldp	w4, w1, [x3, #24]
    80dc:	92403c00 	and	x0, x0, #0xffff
    80e0:	9b047c00 	mul	x0, x0, x4
    80e4:	d360fc00 	lsr	x0, x0, #32
    80e8:	eb01001f 	cmp	x0, x1
    80ec:	54002e22 	b.cs	86b0 <f12+0xd50>  // b.hs, b.nlast
    80f0:	8b000042 	add	x2, x2, x0
    80f4:	39400040 	ldrb	w0, [x2]
    80f8:	7100041f 	cmp	w0, #0x1
    80fc:	54002da1 	b.ne	86b0 <f12+0xd50>  // b.any
    8100:	aa1303f5 	mov	x21, x19
    8104:	d2800000 	mov	x0, #0x0                   	// #0
    8108:	f90007f3 	str	x19, [sp, #8]
    810c:	f94007e1 	ldr	x1, [sp, #8]
    8110:	91002023 	add	x3, x1, #0x8
    8114:	d2800001 	mov	x1, #0x0                   	// #0
    8118:	b4000898 	cbz	x24, 8228 <f12+0x8c8>
    811c:	d0000022 	adrp	x2, e000 <_IO_stdin_used+0x5f0>
    8120:	91002265 	add	x5, x19, #0x8
    8124:	fd44f041 	ldr	d1, [x2, #2528]
    8128:	14000009 	b	814c <f12+0x7ec>
    812c:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8130:	f94002a2 	ldr	x2, [x21]
    8134:	1e600820 	fmul	d0, d1, d0
    8138:	b7f84422 	tbnz	x2, #63, 89bc <f12+0x105c>
    813c:	91000421 	add	x1, x1, #0x1
    8140:	fc008460 	str	d0, [x3], #8
    8144:	eb01031f 	cmp	x24, x1
    8148:	54000700 	b.eq	8228 <f12+0x8c8>  // b.none
    814c:	f9400264 	ldr	x4, [x19]
    8150:	aa0503e2 	mov	x2, x5
    8154:	b6fffec4 	tbz	x4, #63, 812c <f12+0x7cc>
    8158:	f9400a62 	ldr	x2, [x19, #16]
    815c:	17fffff4 	b	812c <f12+0x7cc>
    8160:	eb19037f 	cmp	x27, x25
    8164:	54ffcc40 	b.eq	7aec <f12+0x18c>  // b.none
    8168:	910182a0 	add	x0, x21, #0x60
    816c:	8b19073b 	add	x27, x25, x25, lsl #1
    8170:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    8174:	f940441c 	ldr	x28, [x0, #136]
    8178:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    817c:	91384000 	add	x0, x0, #0xe10
    8180:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    8184:	f900337f 	str	xzr, [x27, #96]
    8188:	97ffea06 	bl	29a0 <getenv@plt>
    818c:	b4ffd0a0 	cbz	x0, 7ba0 <f12+0x240>
    8190:	39400001 	ldrb	w1, [x0]
    8194:	7100c03f 	cmp	w1, #0x30
    8198:	54ffd041 	b.ne	7ba0 <f12+0x240>  // b.any
    819c:	39400400 	ldrb	w0, [x0, #1]
    81a0:	34ffd060 	cbz	w0, 7bac <f12+0x24c>
    81a4:	17fffe7f 	b	7ba0 <f12+0x240>
    81a8:	aa0503e0 	mov	x0, x5
    81ac:	d37df262 	lsl	x2, x19, #3
    81b0:	52800001 	mov	w1, #0x0                   	// #0
    81b4:	a9009fe6 	stp	x6, x7, [sp, #8]
    81b8:	a901a7e8 	stp	x8, x9, [sp, #24]
    81bc:	97ffe989 	bl	27e0 <memset@plt>
    81c0:	aa0003e5 	mov	x5, x0
    81c4:	a9409fe6 	ldp	x6, x7, [sp, #8]
    81c8:	a941a7e8 	ldp	x8, x9, [sp, #24]
    81cc:	17ffff4a 	b	7ef4 <f12+0x594>
    81d0:	f10000bf 	cmp	x5, #0x0
    81d4:	1a9f17e0 	cset	w0, eq	// eq = none
    81d8:	f100027f 	cmp	x19, #0x0
    81dc:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    81e0:	54ffe880 	b.eq	7ef0 <f12+0x590>  // b.none
    81e4:	f9402fe1 	ldr	x1, [sp, #88]
    81e8:	910182b5 	add	x21, x21, #0x60
    81ec:	aa1903e0 	mov	x0, x25
    81f0:	f901caa1 	str	x1, [x21, #912]
    81f4:	97fff0ac 	bl	44a4 <fwp_tape_buffers_release>
    81f8:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    81fc:	f947e863 	ldr	x3, [x3, #4048]
    8200:	d2800262 	mov	x2, #0x13                  	// #19
    8204:	d2800021 	mov	x1, #0x1                   	// #1
    8208:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    820c:	91286000 	add	x0, x0, #0xa18
    8210:	f9400063 	ldr	x3, [x3]
    8214:	97ffe9bf 	bl	2910 <fwrite@plt>
    8218:	d2800000 	mov	x0, #0x0                   	// #0
    821c:	97ffe9c9 	bl	2940 <fflush@plt>
    8220:	52800cc0 	mov	w0, #0x66                  	// #102
    8224:	97ffe9d7 	bl	2980 <_Exit@plt>
    8228:	97fffa66 	bl	6bc0 <fwp_drop4>
    822c:	aa1403e1 	mov	x1, x20
    8230:	d2800002 	mov	x2, #0x0                   	// #0
    8234:	b4003774 	cbz	x20, 8920 <f12+0xfc0>
    8238:	f9400821 	ldr	x1, [x1, #16]
    823c:	91000442 	add	x2, x2, #0x1
    8240:	b5ffffc1 	cbnz	x1, 8238 <f12+0x8d8>
    8244:	f94002a3 	ldr	x3, [x21]
    8248:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    824c:	b7f81f43 	tbnz	x3, #63, 8634 <f12+0xcd4>
    8250:	911902e1 	add	x1, x23, #0x640
    8254:	f94007e4 	ldr	x4, [sp, #8]
    8258:	f949d820 	ldr	x0, [x1, #5040]
    825c:	f949ec21 	ldr	x1, [x1, #5080]
    8260:	cb000080 	sub	x0, x4, x0
    8264:	eb01401f 	cmp	x0, x1, lsl #16
    8268:	54001e62 	b.cs	8634 <f12+0xcd4>  // b.hs, b.nlast
    826c:	911902e4 	add	x4, x23, #0x640
    8270:	d350fc01 	lsr	x1, x0, #16
    8274:	8b010821 	add	x1, x1, x1, lsl #2
    8278:	f949fc86 	ldr	x6, [x4, #5112]
    827c:	d37df021 	lsl	x1, x1, #3
    8280:	8b0100c5 	add	x5, x6, x1
    8284:	f94010a4 	ldr	x4, [x5, #32]
    8288:	b4001d44 	cbz	x4, 8630 <f12+0xcd0>
    828c:	386168c1 	ldrb	w1, [x6, x1]
    8290:	7100083f 	cmp	w1, #0x2
    8294:	54001ca0 	b.eq	8628 <f12+0xcc8>  // b.none
    8298:	7100043f 	cmp	w1, #0x1
    829c:	54001ca1 	b.ne	8630 <f12+0xcd0>  // b.any
    82a0:	294304a6 	ldp	w6, w1, [x5, #24]
    82a4:	92403c00 	and	x0, x0, #0xffff
    82a8:	9b067c00 	mul	x0, x0, x6
    82ac:	d360fc00 	lsr	x0, x0, #32
    82b0:	eb01001f 	cmp	x0, x1
    82b4:	54001be2 	b.cs	8630 <f12+0xcd0>  // b.hs, b.nlast
    82b8:	8b000084 	add	x4, x4, x0
    82bc:	39400098 	ldrb	w24, [x4]
    82c0:	7100071f 	cmp	w24, #0x1
    82c4:	54001b61 	b.ne	8630 <f12+0xcd0>  // b.any
    82c8:	b90013f8 	str	w24, [sp, #16]
    82cc:	eb1c005f 	cmp	x2, x28
    82d0:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    82d4:	910022b9 	add	x25, x21, #0x8
    82d8:	b400361c 	cbz	x28, 8998 <f12+0x1038>
    82dc:	f94007e0 	ldr	x0, [sp, #8]
    82e0:	d37df385 	lsl	x5, x28, #3
    82e4:	aa1403e2 	mov	x2, x20
    82e8:	d2800001 	mov	x1, #0x0                   	// #0
    82ec:	91002000 	add	x0, x0, #0x8
    82f0:	1400000a 	b	8318 <f12+0x9b8>
    82f4:	fc616881 	ldr	d1, [x4, x1]
    82f8:	fd400440 	ldr	d0, [x2, #8]
    82fc:	1e613800 	fsub	d0, d0, d1
    8300:	fc216b20 	str	d0, [x25, x1]
    8304:	91002021 	add	x1, x1, #0x8
    8308:	f9400842 	ldr	x2, [x2, #16]
    830c:	eb05003f 	cmp	x1, x5
    8310:	540001c0 	b.eq	8348 <f12+0x9e8>  // b.none
    8314:	f94002a3 	ldr	x3, [x21]
    8318:	aa0003e4 	mov	x4, x0
    831c:	b6fffec3 	tbz	x3, #63, 82f4 <f12+0x994>
    8320:	f94007e3 	ldr	x3, [sp, #8]
    8324:	fd400440 	ldr	d0, [x2, #8]
    8328:	f9400864 	ldr	x4, [x3, #16]
    832c:	fc616881 	ldr	d1, [x4, x1]
    8330:	1e613800 	fsub	d0, d0, d1
    8334:	fc216b20 	str	d0, [x25, x1]
    8338:	91002021 	add	x1, x1, #0x8
    833c:	f9400842 	ldr	x2, [x2, #16]
    8340:	eb05003f 	cmp	x1, x5
    8344:	54fffe81 	b.ne	8314 <f12+0x9b4>  // b.any
    8348:	b4003254 	cbz	x20, 8990 <f12+0x1030>
    834c:	911902e0 	add	x0, x23, #0x640
    8350:	aa1403e2 	mov	x2, x20
    8354:	d280001a 	mov	x26, #0x0                   	// #0
    8358:	f949ec06 	ldr	x6, [x0, #5080]
    835c:	f949d807 	ldr	x7, [x0, #5040]
    8360:	f949fc05 	ldr	x5, [x0, #5112]
    8364:	d370bcc6 	lsl	x6, x6, #16
    8368:	14000006 	b	8380 <f12+0xa20>
    836c:	f9400842 	ldr	x2, [x2, #16]
    8370:	9100075a 	add	x26, x26, #0x1
    8374:	f100005f 	cmp	x2, #0x0
    8378:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    837c:	54000329 	b.ls	83e0 <f12+0xa80>  // b.plast
    8380:	cb070040 	sub	x0, x2, x7
    8384:	eb06001f 	cmp	x0, x6
    8388:	540002c2 	b.cs	83e0 <f12+0xa80>  // b.hs, b.nlast
    838c:	d350fc01 	lsr	x1, x0, #16
    8390:	8b010821 	add	x1, x1, x1, lsl #2
    8394:	d37df021 	lsl	x1, x1, #3
    8398:	8b0100a4 	add	x4, x5, x1
    839c:	f9401083 	ldr	x3, [x4, #32]
    83a0:	b4000203 	cbz	x3, 83e0 <f12+0xa80>
    83a4:	386168a1 	ldrb	w1, [x5, x1]
    83a8:	7100083f 	cmp	w1, #0x2
    83ac:	54000de0 	b.eq	8568 <f12+0xc08>  // b.none
    83b0:	7100043f 	cmp	w1, #0x1
    83b4:	54000161 	b.ne	83e0 <f12+0xa80>  // b.any
    83b8:	29430488 	ldp	w8, w1, [x4, #24]
    83bc:	92403c00 	and	x0, x0, #0xffff
    83c0:	9b087c00 	mul	x0, x0, x8
    83c4:	d360fc00 	lsr	x0, x0, #32
    83c8:	eb01001f 	cmp	x0, x1
    83cc:	540000a2 	b.cs	83e0 <f12+0xa80>  // b.hs, b.nlast
    83d0:	8b000063 	add	x3, x3, x0
    83d4:	39400060 	ldrb	w0, [x3]
    83d8:	7100041f 	cmp	w0, #0x1
    83dc:	54fffc80 	b.eq	836c <f12+0xa0c>  // b.none
    83e0:	eb1a039f 	cmp	x28, x26
    83e4:	54000ca9 	b.ls	8578 <f12+0xc18>  // b.plast
    83e8:	d1002336 	sub	x22, x25, #0x8
    83ec:	9102a3f5 	add	x21, sp, #0xa8
    83f0:	911902f8 	add	x24, x23, #0x640
    83f4:	d2800013 	mov	x19, #0x0                   	// #0
    83f8:	14000012 	b	8440 <f12+0xae0>
    83fc:	7100045f 	cmp	w2, #0x1
    8400:	540001a1 	b.ne	8434 <f12+0xad4>  // b.any
    8404:	29430002 	ldp	w2, w0, [x0, #24]
    8408:	92403c21 	and	x1, x1, #0xffff
    840c:	9b027c21 	mul	x1, x1, x2
    8410:	d360fc21 	lsr	x1, x1, #32
    8414:	eb00003f 	cmp	x1, x0
    8418:	540000e2 	b.cs	8434 <f12+0xad4>  // b.hs, b.nlast
    841c:	8b01037b 	add	x27, x27, x1
    8420:	39400360 	ldrb	w0, [x27]
    8424:	7103fc1f 	cmp	w0, #0xff
    8428:	54001b20 	b.eq	878c <f12+0xe2c>  // b.none
    842c:	52800020 	mov	w0, #0x1                   	// #1
    8430:	39000360 	strb	w0, [x27]
    8434:	d100079c 	sub	x28, x28, #0x1
    8438:	eb1c035f 	cmp	x26, x28
    843c:	54000362 	b.cs	84a8 <f12+0xb48>  // b.hs, b.nlast
    8440:	f87c7ac2 	ldr	x2, [x22, x28, lsl #3]
    8444:	aa1503e1 	mov	x1, x21
    8448:	52800020 	mov	w0, #0x1                   	// #1
    844c:	a90acfe2 	stp	x2, x19, [sp, #168]
    8450:	97fff561 	bl	59d4 <fwp_data.part.0.constprop.0>
    8454:	aa0003f3 	mov	x19, x0
    8458:	f949db01 	ldr	x1, [x24, #5040]
    845c:	f949ef00 	ldr	x0, [x24, #5080]
    8460:	cb010261 	sub	x1, x19, x1
    8464:	eb00403f 	cmp	x1, x0, lsl #16
    8468:	54fffe62 	b.cs	8434 <f12+0xad4>  // b.hs, b.nlast
    846c:	d350fc22 	lsr	x2, x1, #16
    8470:	f949ff03 	ldr	x3, [x24, #5112]
    8474:	8b020842 	add	x2, x2, x2, lsl #2
    8478:	d37df042 	lsl	x2, x2, #3
    847c:	8b020060 	add	x0, x3, x2
    8480:	f940101b 	ldr	x27, [x0, #32]
    8484:	b4fffd9b 	cbz	x27, 8434 <f12+0xad4>
    8488:	38626862 	ldrb	w2, [x3, x2]
    848c:	7100085f 	cmp	w2, #0x2
    8490:	54fffb61 	b.ne	83fc <f12+0xa9c>  // b.any
    8494:	72003c3f 	tst	w1, #0xffff
    8498:	54fffc40 	b.eq	8420 <f12+0xac0>  // b.none
    849c:	d100079c 	sub	x28, x28, #0x1
    84a0:	eb1c035f 	cmp	x26, x28
    84a4:	54fffce3 	b.cc	8440 <f12+0xae0>  // b.lo, b.ul, b.last
    84a8:	b50006ba 	cbnz	x26, 857c <f12+0xc1c>
    84ac:	b94013e0 	ldr	w0, [sp, #16]
    84b0:	d2800038 	mov	x24, #0x1                   	// #1
    84b4:	d280001b 	mov	x27, #0x0                   	// #0
    84b8:	7100001f 	cmp	w0, #0x0
    84bc:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    84c0:	b40007db 	cbz	x27, 85b8 <f12+0xc58>
    84c4:	d100077b 	sub	x27, x27, #0x1
    84c8:	911902f7 	add	x23, x23, #0x640
    84cc:	d503201f 	nop
    84d0:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    84d4:	aa1503e1 	mov	x1, x21
    84d8:	52800020 	mov	w0, #0x1                   	// #1
    84dc:	a90acfe2 	stp	x2, x19, [sp, #168]
    84e0:	97fff53d 	bl	59d4 <fwp_data.part.0.constprop.0>
    84e4:	aa0003f3 	mov	x19, x0
    84e8:	f949dae1 	ldr	x1, [x23, #5040]
    84ec:	f949eee0 	ldr	x0, [x23, #5080]
    84f0:	cb010261 	sub	x1, x19, x1
    84f4:	eb00403f 	cmp	x1, x0, lsl #16
    84f8:	54000302 	b.cs	8558 <f12+0xbf8>  // b.hs, b.nlast
    84fc:	d350fc22 	lsr	x2, x1, #16
    8500:	f949fee3 	ldr	x3, [x23, #5112]
    8504:	8b020842 	add	x2, x2, x2, lsl #2
    8508:	d37df042 	lsl	x2, x2, #3
    850c:	8b020060 	add	x0, x3, x2
    8510:	f940101a 	ldr	x26, [x0, #32]
    8514:	b400023a 	cbz	x26, 8558 <f12+0xbf8>
    8518:	38626862 	ldrb	w2, [x3, x2]
    851c:	7100085f 	cmp	w2, #0x2
    8520:	540007e0 	b.eq	861c <f12+0xcbc>  // b.none
    8524:	7100045f 	cmp	w2, #0x1
    8528:	54000181 	b.ne	8558 <f12+0xbf8>  // b.any
    852c:	29430002 	ldp	w2, w0, [x0, #24]
    8530:	92403c21 	and	x1, x1, #0xffff
    8534:	9b027c21 	mul	x1, x1, x2
    8538:	d360fc21 	lsr	x1, x1, #32
    853c:	eb00003f 	cmp	x1, x0
    8540:	540000c2 	b.cs	8558 <f12+0xbf8>  // b.hs, b.nlast
    8544:	8b01035a 	add	x26, x26, x1
    8548:	39400340 	ldrb	w0, [x26]
    854c:	7103fc1f 	cmp	w0, #0xff
    8550:	54000600 	b.eq	8610 <f12+0xcb0>  // b.none
    8554:	39000358 	strb	w24, [x26]
    8558:	d100077b 	sub	x27, x27, #0x1
    855c:	b100077f 	cmn	x27, #0x1
    8560:	54fffb81 	b.ne	84d0 <f12+0xb70>  // b.any
    8564:	14000015 	b	85b8 <f12+0xc58>
    8568:	72003c1f 	tst	w0, #0xffff
    856c:	54fff340 	b.eq	83d4 <f12+0xa74>  // b.none
    8570:	eb1a039f 	cmp	x28, x26
    8574:	54fff3a8 	b.hi	83e8 <f12+0xa88>  // b.pmore
    8578:	d2800013 	mov	x19, #0x0                   	// #0
    857c:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    8580:	aa1903e1 	mov	x1, x25
    8584:	aa1403e0 	mov	x0, x20
    8588:	f8408422 	ldr	x2, [x1], #8
    858c:	f9000402 	str	x2, [x0, #8]
    8590:	aa0003e2 	mov	x2, x0
    8594:	f9400800 	ldr	x0, [x0, #16]
    8598:	eb01035f 	cmp	x26, x1
    859c:	54ffff61 	b.ne	8588 <f12+0xc28>  // b.any
    85a0:	b94013e1 	ldr	w1, [sp, #16]
    85a4:	f9000853 	str	x19, [x2, #16]
    85a8:	aa1403f3 	mov	x19, x20
    85ac:	aa0003f4 	mov	x20, x0
    85b0:	34000041 	cbz	w1, 85b8 <f12+0xc58>
    85b4:	d2800019 	mov	x25, #0x0                   	// #0
    85b8:	aa1903e0 	mov	x0, x25
    85bc:	97fff195 	bl	4c10 <fwp_mem_free>
    85c0:	f94007e0 	ldr	x0, [sp, #8]
    85c4:	97fff97f 	bl	6bc0 <fwp_drop4>
    85c8:	aa1403e0 	mov	x0, x20
    85cc:	97fff6e9 	bl	6170 <fwp_drop0>
    85d0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    85d4:	f947f400 	ldr	x0, [x0, #4072]
    85d8:	f9405fe2 	ldr	x2, [sp, #184]
    85dc:	f9400001 	ldr	x1, [x0]
    85e0:	eb010042 	subs	x2, x2, x1
    85e4:	d2800001 	mov	x1, #0x0                   	// #0
    85e8:	540021a1 	b.ne	8a1c <f12+0x10bc>  // b.any
    85ec:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    85f0:	aa1303e0 	mov	x0, x19
    85f4:	a94d53f3 	ldp	x19, x20, [sp, #208]
    85f8:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    85fc:	a94f63f7 	ldp	x23, x24, [sp, #240]
    8600:	a9506bf9 	ldp	x25, x26, [sp, #256]
    8604:	a95173fb 	ldp	x27, x28, [sp, #272]
    8608:	910483ff 	add	sp, sp, #0x120
    860c:	d65f03c0 	ret
    8610:	aa1a03e0 	mov	x0, x26
    8614:	97fff0df 	bl	4990 <fwp_rc_forget_slot>
    8618:	17ffffcf 	b	8554 <f12+0xbf4>
    861c:	72003c3f 	tst	w1, #0xffff
    8620:	54fff9c1 	b.ne	8558 <f12+0xbf8>  // b.any
    8624:	17ffffc9 	b	8548 <f12+0xbe8>
    8628:	72003c1f 	tst	w0, #0xffff
    862c:	54ffe480 	b.eq	82bc <f12+0x95c>  // b.none
    8630:	b4001134 	cbz	x20, 8854 <f12+0xef4>
    8634:	aa1403f3 	mov	x19, x20
    8638:	d2800018 	mov	x24, #0x0                   	// #0
    863c:	d503201f 	nop
    8640:	f9400a73 	ldr	x19, [x19, #16]
    8644:	aa1803e0 	mov	x0, x24
    8648:	91000718 	add	x24, x24, #0x1
    864c:	b5ffffb3 	cbnz	x19, 8640 <f12+0xce0>
    8650:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8654:	eb01031f 	cmp	x24, x1
    8658:	54001b88 	b.hi	89c8 <f12+0x1068>  // b.pmore
    865c:	91000800 	add	x0, x0, #0x2
    8660:	52800041 	mov	w1, #0x2                   	// #2
    8664:	d37df000 	lsl	x0, x0, #3
    8668:	97fff28a 	bl	5090 <fwp_heap_alloc>
    866c:	eb1c031f 	cmp	x24, x28
    8670:	aa0003f9 	mov	x25, x0
    8674:	9a9c931c 	csel	x28, x24, x28, ls	// ls = plast
    8678:	aa1403e1 	mov	x1, x20
    867c:	d503201f 	nop
    8680:	f9400420 	ldr	x0, [x1, #8]
    8684:	f8337b20 	str	x0, [x25, x19, lsl #3]
    8688:	91000673 	add	x19, x19, #0x1
    868c:	f9400821 	ldr	x1, [x1, #16]
    8690:	b5ffff81 	cbnz	x1, 8680 <f12+0xd20>
    8694:	b4000e9c 	cbz	x28, 8864 <f12+0xf04>
    8698:	f94002a3 	ldr	x3, [x21]
    869c:	b90013ff 	str	wzr, [sp, #16]
    86a0:	17ffff0f 	b	82dc <f12+0x97c>
    86a4:	72003c1f 	tst	w0, #0xffff
    86a8:	54ffd260 	b.eq	80f4 <f12+0x794>  // b.none
    86ac:	d503201f 	nop
    86b0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    86b4:	eb00031f 	cmp	x24, x0
    86b8:	540018e8 	b.hi	89d4 <f12+0x1074>  // b.pmore
    86bc:	91000700 	add	x0, x24, #0x1
    86c0:	52800021 	mov	w1, #0x1                   	// #1
    86c4:	d37df000 	lsl	x0, x0, #3
    86c8:	97fff272 	bl	5090 <fwp_heap_alloc>
    86cc:	911902e2 	add	x2, x23, #0x640
    86d0:	f9000018 	str	x24, [x0]
    86d4:	aa0003f5 	mov	x21, x0
    86d8:	f90007f5 	str	x21, [sp, #8]
    86dc:	f949d841 	ldr	x1, [x2, #5040]
    86e0:	f949ec40 	ldr	x0, [x2, #5080]
    86e4:	cb0102a1 	sub	x1, x21, x1
    86e8:	eb00403f 	cmp	x1, x0, lsl #16
    86ec:	54000322 	b.cs	8750 <f12+0xdf0>  // b.hs, b.nlast
    86f0:	d350fc20 	lsr	x0, x1, #16
    86f4:	f949fc43 	ldr	x3, [x2, #5112]
    86f8:	8b000800 	add	x0, x0, x0, lsl #2
    86fc:	d37df002 	lsl	x2, x0, #3
    8700:	8b020060 	add	x0, x3, x2
    8704:	f9401019 	ldr	x25, [x0, #32]
    8708:	b4000259 	cbz	x25, 8750 <f12+0xdf0>
    870c:	38626862 	ldrb	w2, [x3, x2]
    8710:	7100085f 	cmp	w2, #0x2
    8714:	54000ac0 	b.eq	886c <f12+0xf0c>  // b.none
    8718:	7100045f 	cmp	w2, #0x1
    871c:	540001a1 	b.ne	8750 <f12+0xdf0>  // b.any
    8720:	29430002 	ldp	w2, w0, [x0, #24]
    8724:	92403c21 	and	x1, x1, #0xffff
    8728:	9b027c21 	mul	x1, x1, x2
    872c:	d360fc21 	lsr	x1, x1, #32
    8730:	eb00003f 	cmp	x1, x0
    8734:	540000e2 	b.cs	8750 <f12+0xdf0>  // b.hs, b.nlast
    8738:	8b010339 	add	x25, x25, x1
    873c:	39400320 	ldrb	w0, [x25]
    8740:	7103fc1f 	cmp	w0, #0xff
    8744:	54001160 	b.eq	8970 <f12+0x1010>  // b.none
    8748:	52800020 	mov	w0, #0x1                   	// #1
    874c:	39000320 	strb	w0, [x25]
    8750:	aa1303e0 	mov	x0, x19
    8754:	17fffe6e 	b	810c <f12+0x7ac>
    8758:	52800041 	mov	w1, #0x2                   	// #2
    875c:	d2800100 	mov	x0, #0x8                   	// #8
    8760:	97fff24c 	bl	5090 <fwp_heap_alloc>
    8764:	aa0003fb 	mov	x27, x0
    8768:	911902e0 	add	x0, x23, #0x640
    876c:	f900037f 	str	xzr, [x27]
    8770:	f949d801 	ldr	x1, [x0, #5040]
    8774:	f949ec00 	ldr	x0, [x0, #5080]
    8778:	cb010361 	sub	x1, x27, x1
    877c:	eb00403f 	cmp	x1, x0, lsl #16
    8780:	54000102 	b.cs	87a0 <f12+0xe40>  // b.hs, b.nlast
    8784:	d2800013 	mov	x19, #0x0                   	// #0
    8788:	17fffd4b 	b	7cb4 <f12+0x354>
    878c:	aa1b03e0 	mov	x0, x27
    8790:	97fff080 	bl	4990 <fwp_rc_forget_slot>
    8794:	17ffff26 	b	842c <f12+0xacc>
    8798:	b5ffac33 	cbnz	x19, 7d1c <f12+0x3bc>
    879c:	d503201f 	nop
    87a0:	d280001c 	mov	x28, #0x0                   	// #0
    87a4:	17fffd84 	b	7db4 <f12+0x454>
    87a8:	d0ffffe0 	adrp	x0, 6000 <e161+0x100>
    87ac:	91158000 	add	x0, x0, #0x560
    87b0:	9400148c 	bl	d9e0 <atexit>
    87b4:	35ffd220 	cbnz	w0, 81f8 <f12+0x898>
    87b8:	52800020 	mov	w0, #0x1                   	// #1
    87bc:	b903c720 	str	w0, [x25, #964]
    87c0:	17fffcb8 	b	7aa0 <f12+0x140>
    87c4:	72003c3f 	tst	w1, #0xffff
    87c8:	54ffaa81 	b.ne	7d18 <f12+0x3b8>  // b.any
    87cc:	17fffd4e 	b	7d04 <f12+0x3a4>
    87d0:	72003c3f 	tst	w1, #0xffff
    87d4:	54ff9340 	b.eq	7a3c <f12+0xdc>  // b.none
    87d8:	aa1903e0 	mov	x0, x25
    87dc:	97fff6c1 	bl	62e0 <fwp_closure_drop>
    87e0:	b5ff9474 	cbnz	x20, 7a6c <f12+0x10c>
    87e4:	d280001a 	mov	x26, #0x0                   	// #0
    87e8:	17fffcab 	b	7a94 <f12+0x134>
    87ec:	aa1c03f3 	mov	x19, x28
    87f0:	17fffda8 	b	7e90 <f12+0x530>
    87f4:	72003c3f 	tst	w1, #0xffff
    87f8:	54ffc381 	b.ne	8068 <f12+0x708>  // b.any
    87fc:	17fffe16 	b	8054 <f12+0x6f4>
    8800:	ad470402 	ldp	q2, q1, [x0, #224]
    8804:	91038001 	add	x1, x0, #0xe0
    8808:	4f000400 	movi	v0.4s, #0x0
    880c:	f9008c1f 	str	xzr, [x0, #280]
    8810:	ad010762 	stp	q2, q1, [x27, #32]
    8814:	a9500002 	ldp	x2, x0, [x0, #256]
    8818:	f9000f60 	str	x0, [x27, #24]
    881c:	f9401820 	ldr	x0, [x1, #48]
    8820:	f9002362 	str	x2, [x27, #64]
    8824:	f9002760 	str	x0, [x27, #72]
    8828:	ad000020 	stp	q0, q0, [x1]
    882c:	3d800820 	str	q0, [x1, #32]
    8830:	f900183f 	str	xzr, [x1, #48]
    8834:	17fffcde 	b	7bac <f12+0x24c>
    8838:	f940ac43 	ldr	x3, [x2, #344]
    883c:	91000463 	add	x3, x3, #0x1
    8840:	f900ac43 	str	x3, [x2, #344]
    8844:	17fffc83 	b	7a50 <f12+0xf0>
    8848:	d2800005 	mov	x5, #0x0                   	// #0
    884c:	52800020 	mov	w0, #0x1                   	// #1
    8850:	17fffe62 	b	81d8 <f12+0x878>
    8854:	52800041 	mov	w1, #0x2                   	// #2
    8858:	d2800100 	mov	x0, #0x8                   	// #8
    885c:	97fff20d 	bl	5090 <fwp_heap_alloc>
    8860:	aa0003f9 	mov	x25, x0
    8864:	d2800013 	mov	x19, #0x0                   	// #0
    8868:	17ffff54 	b	85b8 <f12+0xc58>
    886c:	72003c3f 	tst	w1, #0xffff
    8870:	54fff660 	b.eq	873c <f12+0xddc>  // b.none
    8874:	aa1303e0 	mov	x0, x19
    8878:	17fffe25 	b	810c <f12+0x7ac>
    887c:	d1000761 	sub	x1, x27, #0x1
    8880:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8884:	eb00003f 	cmp	x1, x0
    8888:	54000ac8 	b.hi	89e0 <f12+0x1080>  // b.pmore
    888c:	900002c3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fba0>
    8890:	d2800000 	mov	x0, #0x0                   	// #0
    8894:	91118061 	add	x1, x3, #0x460
    8898:	14000005 	b	88ac <f12+0xf4c>
    889c:	91000400 	add	x0, x0, #0x1
    88a0:	91006021 	add	x1, x1, #0x18
    88a4:	f140041f 	cmp	x0, #0x1, lsl #12
    88a8:	540006e0 	b.eq	8984 <f12+0x1024>  // b.none
    88ac:	f9400022 	ldr	x2, [x1]
    88b0:	b5ffff62 	cbnz	x2, 889c <f12+0xf3c>
    88b4:	8b000402 	add	x2, x0, x0, lsl #1
    88b8:	91118063 	add	x3, x3, #0x460
    88bc:	aa1b03e0 	mov	x0, x27
    88c0:	d2800101 	mov	x1, #0x8                   	// #8
    88c4:	8b020c62 	add	x2, x3, x2, lsl #3
    88c8:	a9009be2 	stp	x2, x6, [sp, #8]
    88cc:	a901a3e7 	stp	x7, x8, [sp, #24]
    88d0:	f90017e9 	str	x9, [sp, #40]
    88d4:	97ffe7c7 	bl	27f0 <calloc@plt>
    88d8:	a9411fe6 	ldp	x6, x7, [sp, #16]
    88dc:	aa0003e5 	mov	x5, x0
    88e0:	a94227e8 	ldp	x8, x9, [sp, #32]
    88e4:	b4fffb20 	cbz	x0, 8848 <f12+0xee8>
    88e8:	aa0003e1 	mov	x1, x0
    88ec:	d37df362 	lsl	x2, x27, #3
    88f0:	f94007e0 	ldr	x0, [sp, #8]
    88f4:	52800063 	mov	w3, #0x3                   	// #3
    88f8:	a9009be5 	stp	x5, x6, [sp, #8]
    88fc:	a901a3e7 	stp	x7, x8, [sp, #24]
    8900:	f90017e9 	str	x9, [sp, #40]
    8904:	97ffe983 	bl	2f10 <ad_raw_record>
    8908:	a9409be5 	ldp	x5, x6, [sp, #8]
    890c:	f9004be5 	str	x5, [sp, #144]
    8910:	a941a3e7 	ldp	x7, x8, [sp, #24]
    8914:	f90053fb 	str	x27, [sp, #160]
    8918:	f94017e9 	ldr	x9, [sp, #40]
    891c:	17fffd75 	b	7ef0 <f12+0x590>
    8920:	f94002a3 	ldr	x3, [x21]
    8924:	b7fff983 	tbnz	x3, #63, 8854 <f12+0xef4>
    8928:	911902e1 	add	x1, x23, #0x640
    892c:	f94007e4 	ldr	x4, [sp, #8]
    8930:	f949d820 	ldr	x0, [x1, #5040]
    8934:	f949ec21 	ldr	x1, [x1, #5080]
    8938:	cb000080 	sub	x0, x4, x0
    893c:	eb01401f 	cmp	x0, x1, lsl #16
    8940:	54fff8a2 	b.cs	8854 <f12+0xef4>  // b.hs, b.nlast
    8944:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    8948:	17fffe49 	b	826c <f12+0x90c>
    894c:	d2800d01 	mov	x1, #0x68                  	// #104
    8950:	d2800039 	mov	x25, #0x1                   	// #1
    8954:	17fffc76 	b	7b2c <f12+0x1cc>
    8958:	aa1a03e0 	mov	x0, x26
    895c:	97fff00d 	bl	4990 <fwp_rc_forget_slot>
    8960:	17fffcec 	b	7d10 <f12+0x3b0>
    8964:	aa1903e0 	mov	x0, x25
    8968:	97fff00a 	bl	4990 <fwp_rc_forget_slot>
    896c:	17fffdbd 	b	8060 <f12+0x700>
    8970:	aa1903e0 	mov	x0, x25
    8974:	97fff007 	bl	4990 <fwp_rc_forget_slot>
    8978:	17ffff74 	b	8748 <f12+0xde8>
    897c:	97ffefbe 	bl	4874 <fwp_rc_wide_dup>
    8980:	17fffc38 	b	7a60 <f12+0x100>
    8984:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    8988:	9136e000 	add	x0, x0, #0xdb8
    898c:	97ffea5d 	bl	3300 <ad_raw_fail>
    8990:	d280001a 	mov	x26, #0x0                   	// #0
    8994:	17fffe95 	b	83e8 <f12+0xa88>
    8998:	d2800019 	mov	x25, #0x0                   	// #0
    899c:	d2800013 	mov	x19, #0x0                   	// #0
    89a0:	17ffff06 	b	85b8 <f12+0xc58>
    89a4:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    89a8:	913c6000 	add	x0, x0, #0xf18
    89ac:	97ffeb75 	bl	3780 <fwp_trap>
    89b0:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    89b4:	913ec000 	add	x0, x0, #0xfb0
    89b8:	97ffeb72 	bl	3780 <fwp_trap>
    89bc:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    89c0:	91034000 	add	x0, x0, #0xd0
    89c4:	97ffeb6f 	bl	3780 <fwp_trap>
    89c8:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    89cc:	91004000 	add	x0, x0, #0x10
    89d0:	97ffeb6c 	bl	3780 <fwp_trap>
    89d4:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    89d8:	91030000 	add	x0, x0, #0xc0
    89dc:	97ffeb69 	bl	3780 <fwp_trap>
    89e0:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    89e4:	91028000 	add	x0, x0, #0xa0
    89e8:	97ffea46 	bl	3300 <ad_raw_fail>
    89ec:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    89f0:	9101c000 	add	x0, x0, #0x70
    89f4:	97ffeb63 	bl	3780 <fwp_trap>
    89f8:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    89fc:	91008000 	add	x0, x0, #0x20
    8a00:	97ffeb60 	bl	3780 <fwp_trap>
    8a04:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    8a08:	913d8000 	add	x0, x0, #0xf60
    8a0c:	97ffeb5d 	bl	3780 <fwp_trap>
    8a10:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    8a14:	91010000 	add	x0, x0, #0x40
    8a18:	97ffeb5a 	bl	3780 <fwp_trap>
    8a1c:	97ffe77d 	bl	2810 <__stack_chk_fail@plt>
    8a20:	97ffe790 	bl	2860 <abort@plt>
    8a24:	97ffe7f7 	bl	2a00 <fwp_trap_overflow.constprop.0>
    8a28:	d503201f 	nop
    8a2c:	d503201f 	nop

0000000000008a30 <fwp_owned_entry12>:
    8a30:	f9400000 	ldr	x0, [x0]
    8a34:	17fffbcb 	b	7960 <f12>
    8a38:	d503201f 	nop
    8a3c:	d503201f 	nop

0000000000008a40 <e12>:
    8a40:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8a44:	910003fd 	mov	x29, sp
    8a48:	f9000bf3 	str	x19, [sp, #16]
    8a4c:	f9400013 	ldr	x19, [x0]
    8a50:	aa1303e0 	mov	x0, x19
    8a54:	97fff43f 	bl	5b50 <fwp_rc_share>
    8a58:	aa1303e0 	mov	x0, x19
    8a5c:	97fffbc1 	bl	7960 <f12>
    8a60:	aa0003f3 	mov	x19, x0
    8a64:	97fff43b 	bl	5b50 <fwp_rc_share>
    8a68:	aa1303e0 	mov	x0, x19
    8a6c:	f9400bf3 	ldr	x19, [sp, #16]
    8a70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8a74:	d65f03c0 	ret
    8a78:	d503201f 	nop
    8a7c:	d503201f 	nop

0000000000008a80 <fwp_write>:
    8a80:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8a84:	910003fd 	mov	x29, sp
    8a88:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    8a8c:	f947f484 	ldr	x4, [x4, #4072]
    8a90:	a90153f3 	stp	x19, x20, [sp, #16]
    8a94:	d10943ff 	sub	sp, sp, #0x250
    8a98:	b9400045 	ldr	w5, [x2]
    8a9c:	aa0003f4 	mov	x20, x0
    8aa0:	f9400080 	ldr	x0, [x4]
    8aa4:	f90127e0 	str	x0, [sp, #584]
    8aa8:	d2800000 	mov	x0, #0x0                   	// #0
    8aac:	710064bf 	cmp	w5, #0x19
    8ab0:	54000408 	b.hi	8b30 <fwp_write+0xb0>  // b.pmore
    8ab4:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    8ab8:	aa0103f3 	mov	x19, x1
    8abc:	91250000 	add	x0, x0, #0x940
    8ac0:	f9013bf5 	str	x21, [sp, #624]
    8ac4:	f9013ff6 	str	x22, [sp, #632]
    8ac8:	f90153fb 	str	x27, [sp, #672]
    8acc:	f90157fc 	str	x28, [sp, #680]
    8ad0:	aa0203fc 	mov	x28, x2
    8ad4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8ad8:	10000061 	adr	x1, 8ae4 <fwp_write+0x64>
    8adc:	8b20a820 	add	x0, x1, w0, sxth #2
    8ae0:	d61f0000 	br	x0
    8ae4:	910123e0 	add	x0, sp, #0x48
    8ae8:	aa1303e5 	mov	x5, x19
    8aec:	d0000024 	adrp	x4, e000 <_IO_stdin_used+0x5f0>
    8af0:	aa0003f3 	mov	x19, x0
    8af4:	9104c084 	add	x4, x4, #0x130
    8af8:	d2804003 	mov	x3, #0x200                 	// #512
    8afc:	aa0303e1 	mov	x1, x3
    8b00:	52800042 	mov	w2, #0x2                   	// #2
    8b04:	97ffe71f 	bl	2780 <__snprintf_chk@plt>
    8b08:	aa1303e0 	mov	x0, x19
    8b0c:	97ffe6e5 	bl	26a0 <strlen@plt>
    8b10:	aa1303e1 	mov	x1, x19
    8b14:	aa0003e2 	mov	x2, x0
    8b18:	aa1403e0 	mov	x0, x20
    8b1c:	97ffeabd 	bl	3610 <buf_put>
    8b20:	f9413bf5 	ldr	x21, [sp, #624]
    8b24:	f9413ff6 	ldr	x22, [sp, #632]
    8b28:	f94153fb 	ldr	x27, [sp, #672]
    8b2c:	f94157fc 	ldr	x28, [sp, #680]
    8b30:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8b34:	f947f400 	ldr	x0, [x0, #4072]
    8b38:	f94127e2 	ldr	x2, [sp, #584]
    8b3c:	f9400001 	ldr	x1, [x0]
    8b40:	eb010042 	subs	x2, x2, x1
    8b44:	d2800001 	mov	x1, #0x0                   	// #0
    8b48:	540077c1 	b.ne	9a40 <fwp_write+0xfc0>  // b.any
    8b4c:	910943ff 	add	sp, sp, #0x250
    8b50:	a94153f3 	ldp	x19, x20, [sp, #16]
    8b54:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8b58:	d65f03c0 	ret
    8b5c:	910123e0 	add	x0, sp, #0x48
    8b60:	aa1303e5 	mov	x5, x19
    8b64:	d0000024 	adrp	x4, e000 <_IO_stdin_used+0x5f0>
    8b68:	aa0003f3 	mov	x19, x0
    8b6c:	9104a084 	add	x4, x4, #0x128
    8b70:	d2804003 	mov	x3, #0x200                 	// #512
    8b74:	17ffffe2 	b	8afc <fwp_write+0x7c>
    8b78:	71004cbf 	cmp	w5, #0x13
    8b7c:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    8b80:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    8b84:	91046000 	add	x0, x0, #0x118
    8b88:	91048021 	add	x1, x1, #0x120
    8b8c:	d2800082 	mov	x2, #0x4                   	// #4
    8b90:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8b94:	aa1403e0 	mov	x0, x20
    8b98:	f90143f7 	str	x23, [sp, #640]
    8b9c:	d2800016 	mov	x22, #0x0                   	// #0
    8ba0:	f90147f8 	str	x24, [sp, #648]
    8ba4:	97ffea9b 	bl	3610 <buf_put>
    8ba8:	f9400260 	ldr	x0, [x19]
    8bac:	d0000037 	adrp	x23, e000 <_IO_stdin_used+0x5f0>
    8bb0:	d2800015 	mov	x21, #0x0                   	// #0
    8bb4:	910682f7 	add	x23, x23, #0x1a0
    8bb8:	b40047a0 	cbz	x0, 94ac <fwp_write+0xa2c>
    8bbc:	b9400380 	ldr	w0, [x28]
    8bc0:	52800003 	mov	w3, #0x0                   	// #0
    8bc4:	f9401f82 	ldr	x2, [x28, #56]
    8bc8:	71004c1f 	cmp	w0, #0x13
    8bcc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8bd0:	aa1403e0 	mov	x0, x20
    8bd4:	8b010e61 	add	x1, x19, x1, lsl #3
    8bd8:	f9400421 	ldr	x1, [x1, #8]
    8bdc:	97ffffa9 	bl	8a80 <fwp_write>
    8be0:	b9400380 	ldr	w0, [x28]
    8be4:	7100481f 	cmp	w0, #0x12
    8be8:	54004b40 	b.eq	9550 <fwp_write+0xad0>  // b.none
    8bec:	f9400260 	ldr	x0, [x19]
    8bf0:	910006b5 	add	x21, x21, #0x1
    8bf4:	91000ad6 	add	x22, x22, #0x2
    8bf8:	eb15001f 	cmp	x0, x21
    8bfc:	54004589 	b.ls	94ac <fwp_write+0xa2c>  // b.plast
    8c00:	aa1703e1 	mov	x1, x23
    8c04:	aa1403e0 	mov	x0, x20
    8c08:	d2800042 	mov	x2, #0x2                   	// #2
    8c0c:	97ffea81 	bl	3610 <buf_put>
    8c10:	17ffffeb 	b	8bbc <fwp_write+0x13c>
    8c14:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    8c18:	91056021 	add	x1, x1, #0x158
    8c1c:	d28000c2 	mov	x2, #0x6                   	// #6
    8c20:	aa1403e0 	mov	x0, x20
    8c24:	91004273 	add	x19, x19, #0x10
    8c28:	97ffea7a 	bl	3610 <buf_put>
    8c2c:	aa1303e0 	mov	x0, x19
    8c30:	97ffe69c 	bl	26a0 <strlen@plt>
    8c34:	aa1303e1 	mov	x1, x19
    8c38:	aa0003e2 	mov	x2, x0
    8c3c:	aa1403e0 	mov	x0, x20
    8c40:	97ffea74 	bl	3610 <buf_put>
    8c44:	528007c3 	mov	w3, #0x3e                  	// #62
    8c48:	aa1403e0 	mov	x0, x20
    8c4c:	91001fe1 	add	x1, sp, #0x7
    8c50:	d2800022 	mov	x2, #0x1                   	// #1
    8c54:	39001fe3 	strb	w3, [sp, #7]
    8c58:	17ffffb1 	b	8b1c <fwp_write+0x9c>
    8c5c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8c60:	f947f400 	ldr	x0, [x0, #4072]
    8c64:	f94127e2 	ldr	x2, [sp, #584]
    8c68:	f9400001 	ldr	x1, [x0]
    8c6c:	eb010042 	subs	x2, x2, x1
    8c70:	d2800001 	mov	x1, #0x0                   	// #0
    8c74:	540034e1 	b.ne	9310 <fwp_write+0x890>  // b.any
    8c78:	f9413bf5 	ldr	x21, [sp, #624]
    8c7c:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    8c80:	f9413ff6 	ldr	x22, [sp, #632]
    8c84:	aa1403e0 	mov	x0, x20
    8c88:	9104e021 	add	x1, x1, #0x138
    8c8c:	d2800142 	mov	x2, #0xa                   	// #10
    8c90:	f94153fb 	ldr	x27, [sp, #672]
    8c94:	f94157fc 	ldr	x28, [sp, #680]
    8c98:	910943ff 	add	sp, sp, #0x250
    8c9c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8ca0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8ca4:	17ffea5b 	b	3610 <buf_put>
    8ca8:	f9400456 	ldr	x22, [x2, #8]
    8cac:	f90143f7 	str	x23, [sp, #640]
    8cb0:	f90147f8 	str	x24, [sp, #648]
    8cb4:	b4005b16 	cbz	x22, 9814 <fwp_write+0xd94>
    8cb8:	aa1603e0 	mov	x0, x22
    8cbc:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    8cc0:	9106e021 	add	x1, x1, #0x1b8
    8cc4:	97ffe6f3 	bl	2890 <strcmp@plt>
    8cc8:	2a0003f5 	mov	w21, w0
    8ccc:	34005fe0 	cbz	w0, 98c8 <fwp_write+0xe48>
    8cd0:	aa1603e0 	mov	x0, x22
    8cd4:	97ffe673 	bl	26a0 <strlen@plt>
    8cd8:	aa1603e1 	mov	x1, x22
    8cdc:	aa0003e2 	mov	x2, x0
    8ce0:	aa1403e0 	mov	x0, x20
    8ce4:	97ffea4b 	bl	3610 <buf_put>
    8ce8:	52800403 	mov	w3, #0x20                  	// #32
    8cec:	91001ff5 	add	x21, sp, #0x7
    8cf0:	aa1503e1 	mov	x1, x21
    8cf4:	aa1403e0 	mov	x0, x20
    8cf8:	d2800022 	mov	x2, #0x1                   	// #1
    8cfc:	39001fe3 	strb	w3, [sp, #7]
    8d00:	97ffea44 	bl	3610 <buf_put>
    8d04:	52800f63 	mov	w3, #0x7b                  	// #123
    8d08:	aa1403e0 	mov	x0, x20
    8d0c:	aa1503e1 	mov	x1, x21
    8d10:	d2800022 	mov	x2, #0x1                   	// #1
    8d14:	39001fe3 	strb	w3, [sp, #7]
    8d18:	97ffea3e 	bl	3610 <buf_put>
    8d1c:	b9401380 	ldr	w0, [x28, #16]
    8d20:	52800018 	mov	w24, #0x0                   	// #0
    8d24:	7100001f 	cmp	w0, #0x0
    8d28:	54003aad 	b.le	947c <fwp_write+0x9fc>
    8d2c:	f9014bf9 	str	x25, [sp, #656]
    8d30:	d0000039 	adrp	x25, e000 <_IO_stdin_used+0x5f0>
    8d34:	91078339 	add	x25, x25, #0x1e0
    8d38:	f9014ffa 	str	x26, [sp, #664]
    8d3c:	d000003a 	adrp	x26, e000 <_IO_stdin_used+0x5f0>
    8d40:	9106835a 	add	x26, x26, #0x1a0
    8d44:	91002276 	add	x22, x19, #0x8
    8d48:	d2800013 	mov	x19, #0x0                   	// #0
    8d4c:	b5003e93 	cbnz	x19, 951c <fwp_write+0xa9c>
    8d50:	d37df277 	lsl	x23, x19, #3
    8d54:	34003cb8 	cbz	w24, 94e8 <fwp_write+0xa68>
    8d58:	f9401382 	ldr	x2, [x28, #32]
    8d5c:	aa1403e0 	mov	x0, x20
    8d60:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8d64:	52800003 	mov	w3, #0x0                   	// #0
    8d68:	f8776842 	ldr	x2, [x2, x23]
    8d6c:	91000673 	add	x19, x19, #0x1
    8d70:	97ffff44 	bl	8a80 <fwp_write>
    8d74:	b9401380 	ldr	w0, [x28, #16]
    8d78:	6b13001f 	cmp	w0, w19
    8d7c:	54fffe8c 	b.gt	8d4c <fwp_write+0x2cc>
    8d80:	f9414bf9 	ldr	x25, [sp, #656]
    8d84:	f9414ffa 	ldr	x26, [sp, #664]
    8d88:	340037b8 	cbz	w24, 947c <fwp_write+0x9fc>
    8d8c:	52800523 	mov	w3, #0x29                  	// #41
    8d90:	aa1503e1 	mov	x1, x21
    8d94:	aa1403e0 	mov	x0, x20
    8d98:	d2800022 	mov	x2, #0x1                   	// #1
    8d9c:	39001fe3 	strb	w3, [sp, #7]
    8da0:	97ffea1c 	bl	3610 <buf_put>
    8da4:	f9413bf5 	ldr	x21, [sp, #624]
    8da8:	f9413ff6 	ldr	x22, [sp, #632]
    8dac:	f94143f7 	ldr	x23, [sp, #640]
    8db0:	f94147f8 	ldr	x24, [sp, #648]
    8db4:	f94153fb 	ldr	x27, [sp, #672]
    8db8:	f94157fc 	ldr	x28, [sp, #680]
    8dbc:	17ffff5d 	b	8b30 <fwp_write+0xb0>
    8dc0:	b9404855 	ldr	w21, [x2, #72]
    8dc4:	aa1403e0 	mov	x0, x20
    8dc8:	93407eb6 	sxtw	x22, w21
    8dcc:	91000ac1 	add	x1, x22, #0x2
    8dd0:	97ffe9dc 	bl	3540 <buf_grow>
    8dd4:	a9400281 	ldp	x1, x0, [x20]
    8dd8:	528e8603 	mov	w3, #0x7430                	// #29744
    8ddc:	78206823 	strh	w3, [x1, x0]
    8de0:	8b000022 	add	x2, x1, x0
    8de4:	710002bf 	cmp	w21, #0x0
    8de8:	540036cd 	b.le	94c0 <fwp_write+0xa40>
    8dec:	110006a3 	add	w3, w21, #0x1
    8df0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8df4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8df8:	91000449 	add	x9, x2, #0x1
    8dfc:	8b23c043 	add	x3, x2, w3, sxtw
    8e00:	f28aaac6 	movk	x6, #0x5556
    8e04:	f2955568 	movk	x8, #0xaaab
    8e08:	1400000d 	b	8e3c <fwp_write+0x3bc>
    8e0c:	d2800021 	mov	x1, #0x1                   	// #1
    8e10:	528005a5 	mov	w5, #0x2d                  	// #45
    8e14:	f100001f 	cmp	x0, #0x0
    8e18:	9b467e60 	smulh	x0, x19, x6
    8e1c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8e20:	381ff465 	strb	w5, [x3], #-1
    8e24:	cb040000 	sub	x0, x0, x4
    8e28:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8e2c:	cb020000 	sub	x0, x0, x2
    8e30:	8b010013 	add	x19, x0, x1
    8e34:	eb03013f 	cmp	x9, x3
    8e38:	54003440 	b.eq	94c0 <fwp_write+0xa40>  // b.none
    8e3c:	9b467e60 	smulh	x0, x19, x6
    8e40:	937ffe64 	asr	x4, x19, #63
    8e44:	52800605 	mov	w5, #0x30                  	// #48
    8e48:	cb040000 	sub	x0, x0, x4
    8e4c:	8b000400 	add	x0, x0, x0, lsl #1
    8e50:	cb000260 	sub	x0, x19, x0
    8e54:	91000c01 	add	x1, x0, #0x3
    8e58:	9bc87c22 	umulh	x2, x1, x8
    8e5c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8e60:	8b4204e2 	add	x2, x7, x2, lsr #1
    8e64:	eb020021 	subs	x1, x1, x2
    8e68:	54fffd60 	b.eq	8e14 <fwp_write+0x394>  // b.none
    8e6c:	f100043f 	cmp	x1, #0x1
    8e70:	54fffce1 	b.ne	8e0c <fwp_write+0x38c>  // b.any
    8e74:	d2800001 	mov	x1, #0x0                   	// #0
    8e78:	52800565 	mov	w5, #0x2b                  	// #43
    8e7c:	17ffffe6 	b	8e14 <fwp_write+0x394>
    8e80:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8e84:	f947f400 	ldr	x0, [x0, #4072]
    8e88:	f94127e2 	ldr	x2, [sp, #584]
    8e8c:	f9400001 	ldr	x1, [x0]
    8e90:	eb010042 	subs	x2, x2, x1
    8e94:	d2800001 	mov	x1, #0x0                   	// #0
    8e98:	540023c1 	b.ne	9310 <fwp_write+0x890>  // b.any
    8e9c:	f9413bf5 	ldr	x21, [sp, #624]
    8ea0:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    8ea4:	f9413ff6 	ldr	x22, [sp, #632]
    8ea8:	aa1403e0 	mov	x0, x20
    8eac:	91052021 	add	x1, x1, #0x148
    8eb0:	d2800102 	mov	x2, #0x8                   	// #8
    8eb4:	17ffff77 	b	8c90 <fwp_write+0x210>
    8eb8:	aa1403e0 	mov	x0, x20
    8ebc:	d0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    8ec0:	d28000c2 	mov	x2, #0x6                   	// #6
    8ec4:	9106a021 	add	x1, x1, #0x1a8
    8ec8:	97ffe9d2 	bl	3610 <buf_put>
    8ecc:	d2800015 	mov	x21, #0x0                   	// #0
    8ed0:	f9400263 	ldr	x3, [x19]
    8ed4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8ed8:	54002c60 	b.eq	9464 <fwp_write+0x9e4>  // b.none
    8edc:	f9401f82 	ldr	x2, [x28, #56]
    8ee0:	f90143f7 	str	x23, [sp, #640]
    8ee4:	f90147f8 	str	x24, [sp, #648]
    8ee8:	d2800857 	mov	x23, #0x42                  	// #66
    8eec:	f9014bf9 	str	x25, [sp, #656]
    8ef0:	d0000036 	adrp	x22, e000 <_IO_stdin_used+0x5f0>
    8ef4:	f9014ffa 	str	x26, [sp, #664]
    8ef8:	910682d6 	add	x22, x22, #0x1a0
    8efc:	d2800038 	mov	x24, #0x1                   	// #1
    8f00:	f2a18017 	movk	x23, #0xc00, lsl #16
    8f04:	d2809099 	mov	x25, #0x484                 	// #1156
    8f08:	b40004a2 	cbz	x2, 8f9c <fwp_write+0x51c>
    8f0c:	b9400040 	ldr	w0, [x2]
    8f10:	7100701f 	cmp	w0, #0x1c
    8f14:	540042c0 	b.eq	976c <fwp_write+0xcec>  // b.none
    8f18:	71006c1f 	cmp	w0, #0x1b
    8f1c:	54000408 	b.hi	8f9c <fwp_write+0x51c>  // b.pmore
    8f20:	9ac02301 	lsl	x1, x24, x0
    8f24:	ea17003f 	tst	x1, x23
    8f28:	540036a1 	b.ne	95fc <fwp_write+0xb7c>  // b.any
    8f2c:	ea19003f 	tst	x1, x25
    8f30:	54003521 	b.ne	95d4 <fwp_write+0xb54>  // b.any
    8f34:	d2800424 	mov	x4, #0x21                  	// #33
    8f38:	ea04003f 	tst	x1, x4
    8f3c:	54000300 	b.eq	8f9c <fwp_write+0x51c>  // b.none
    8f40:	b7f849c3 	tbnz	x3, #63, 9878 <fwp_write+0xdf8>
    8f44:	91002261 	add	x1, x19, #0x8
    8f48:	8b150021 	add	x1, x1, x21
    8f4c:	39400021 	ldrb	w1, [x1]
    8f50:	7100001f 	cmp	w0, #0x0
    8f54:	93401c23 	sxtb	x3, w1
    8f58:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8f5c:	d503201f 	nop
    8f60:	aa1403e0 	mov	x0, x20
    8f64:	52800003 	mov	w3, #0x0                   	// #0
    8f68:	97fffec6 	bl	8a80 <fwp_write>
    8f6c:	910006b5 	add	x21, x21, #0x1
    8f70:	f9400260 	ldr	x0, [x19]
    8f74:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8f78:	eb0002bf 	cmp	x21, x0
    8f7c:	540026c2 	b.cs	9454 <fwp_write+0x9d4>  // b.hs, b.nlast
    8f80:	d2800042 	mov	x2, #0x2                   	// #2
    8f84:	aa1603e1 	mov	x1, x22
    8f88:	aa1403e0 	mov	x0, x20
    8f8c:	97ffe9a1 	bl	3610 <buf_put>
    8f90:	f9401f82 	ldr	x2, [x28, #56]
    8f94:	f9400263 	ldr	x3, [x19]
    8f98:	b5fffba2 	cbnz	x2, 8f0c <fwp_write+0x48c>
    8f9c:	d37df2a0 	lsl	x0, x21, #3
    8fa0:	b7f83f03 	tbnz	x3, #63, 9780 <fwp_write+0xd00>
    8fa4:	91002261 	add	x1, x19, #0x8
    8fa8:	8b000020 	add	x0, x1, x0
    8fac:	f9400001 	ldr	x1, [x0]
    8fb0:	17ffffec 	b	8f60 <fwp_write+0x4e0>
    8fb4:	a9400e62 	ldp	x2, x3, [x19]
    8fb8:	b7f83ca3 	tbnz	x3, #63, 974c <fwp_write+0xccc>
    8fbc:	910123f5 	add	x21, sp, #0x48
    8fc0:	aa1503e0 	mov	x0, x21
    8fc4:	97ffe777 	bl	2da0 <fwp_fmt_u128>
    8fc8:	aa1503e0 	mov	x0, x21
    8fcc:	97ffe5b5 	bl	26a0 <strlen@plt>
    8fd0:	aa1503e1 	mov	x1, x21
    8fd4:	aa0003e2 	mov	x2, x0
    8fd8:	17fffed0 	b	8b18 <fwp_write+0x98>
    8fdc:	fd015be8 	str	d8, [sp, #688]
    8fe0:	1e270268 	fmov	s8, w19
    8fe4:	fd015fe9 	str	d9, [sp, #696]
    8fe8:	1e282100 	fcmp	s8, s8
    8fec:	54004d26 	b.vs	9990 <fwp_write+0xf10>
    8ff0:	1e20c101 	fabs	s1, s8
    8ff4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8ff8:	1e270000 	fmov	s0, w0
    8ffc:	1e202020 	fcmp	s1, s0
    9000:	54002c0d 	b.le	9580 <fwp_write+0xb00>
    9004:	1e202118 	fcmpe	s8, #0.0
    9008:	90000022 	adrp	x2, d000 <fwp_main_thread+0x2d0>
    900c:	912e2042 	add	x2, x2, #0xb88
    9010:	910123f5 	add	x21, sp, #0x48
    9014:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    9018:	9103e021 	add	x1, x1, #0xf8
    901c:	aa1503e0 	mov	x0, x21
    9020:	9a81c041 	csel	x1, x2, x1, gt
    9024:	97ffe64b 	bl	2950 <strcpy@plt>
    9028:	aa1503e0 	mov	x0, x21
    902c:	97ffe59d 	bl	26a0 <strlen@plt>
    9030:	aa1503e1 	mov	x1, x21
    9034:	aa0003e2 	mov	x2, x0
    9038:	aa1403e0 	mov	x0, x20
    903c:	97ffe975 	bl	3610 <buf_put>
    9040:	f9413bf5 	ldr	x21, [sp, #624]
    9044:	f9413ff6 	ldr	x22, [sp, #632]
    9048:	f94153fb 	ldr	x27, [sp, #672]
    904c:	f94157fc 	ldr	x28, [sp, #680]
    9050:	fd415be8 	ldr	d8, [sp, #688]
    9054:	fd415fe9 	ldr	d9, [sp, #696]
    9058:	17fffeb6 	b	8b30 <fwp_write+0xb0>
    905c:	f9400276 	ldr	x22, [x19]
    9060:	34002e03 	cbz	w3, 9620 <fwp_write+0xba0>
    9064:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9068:	f947f400 	ldr	x0, [x0, #4072]
    906c:	f94127e2 	ldr	x2, [sp, #584]
    9070:	f9400001 	ldr	x1, [x0]
    9074:	eb010042 	subs	x2, x2, x1
    9078:	d2800001 	mov	x1, #0x0                   	// #0
    907c:	540014a1 	b.ne	9310 <fwp_write+0x890>  // b.any
    9080:	aa1603e2 	mov	x2, x22
    9084:	91002261 	add	x1, x19, #0x8
    9088:	f9413bf5 	ldr	x21, [sp, #624]
    908c:	aa1403e0 	mov	x0, x20
    9090:	f9413ff6 	ldr	x22, [sp, #632]
    9094:	17fffeff 	b	8c90 <fwp_write+0x210>
    9098:	fd015be8 	str	d8, [sp, #688]
    909c:	9e670268 	fmov	d8, x19
    90a0:	fd015fe9 	str	d9, [sp, #696]
    90a4:	1e682100 	fcmp	d8, d8
    90a8:	54004746 	b.vs	9990 <fwp_write+0xf10>
    90ac:	1e60c101 	fabs	d1, d8
    90b0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    90b4:	9e670000 	fmov	d0, x0
    90b8:	910123f5 	add	x21, sp, #0x48
    90bc:	52800033 	mov	w19, #0x1                   	// #1
    90c0:	1e602020 	fcmp	d1, d0
    90c4:	540001ad 	b.le	90f8 <fwp_write+0x678>
    90c8:	1e602118 	fcmpe	d8, #0.0
    90cc:	90000022 	adrp	x2, d000 <fwp_main_thread+0x2d0>
    90d0:	912e2042 	add	x2, x2, #0xb88
    90d4:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    90d8:	9103e021 	add	x1, x1, #0xf8
    90dc:	aa1503e0 	mov	x0, x21
    90e0:	9a81c041 	csel	x1, x2, x1, gt
    90e4:	97ffe61b 	bl	2950 <strcpy@plt>
    90e8:	17ffffd0 	b	9028 <fwp_write+0x5a8>
    90ec:	11000673 	add	w19, w19, #0x1
    90f0:	71004a7f 	cmp	w19, #0x12
    90f4:	54003860 	b.eq	9800 <fwp_write+0xd80>  // b.none
    90f8:	1e604100 	fmov	d0, d8
    90fc:	2a1303e1 	mov	w1, w19
    9100:	aa1503e0 	mov	x0, x21
    9104:	97ffea84 	bl	3b14 <fwp_format_g.constprop.0>
    9108:	aa1503e0 	mov	x0, x21
    910c:	d2800001 	mov	x1, #0x0                   	// #0
    9110:	97ffe578 	bl	26f0 <strtod@plt>
    9114:	1e602100 	fcmp	d8, d0
    9118:	54fffea1 	b.ne	90ec <fwp_write+0x66c>  // b.any
    911c:	aa1503e0 	mov	x0, x21
    9120:	97ffe975 	bl	36f4 <fwp_finish_float>
    9124:	17ffffc1 	b	9028 <fwp_write+0x5a8>
    9128:	a9400e62 	ldp	x2, x3, [x19]
    912c:	910123f3 	add	x19, sp, #0x48
    9130:	aa1303e0 	mov	x0, x19
    9134:	97ffe71b 	bl	2da0 <fwp_fmt_u128>
    9138:	17fffe74 	b	8b08 <fwp_write+0x88>
    913c:	f90143f7 	str	x23, [sp, #640]
    9140:	f90147f8 	str	x24, [sp, #648]
    9144:	2a1303f8 	mov	w24, w19
    9148:	f9014bf9 	str	x25, [sp, #656]
    914c:	f9014ffa 	str	x26, [sp, #664]
    9150:	f13ffe7f 	cmp	x19, #0xfff
    9154:	54000049 	b.ls	915c <fwp_write+0x6dc>  // b.plast
    9158:	b9400278 	ldr	w24, [x19]
    915c:	f9400f80 	ldr	x0, [x28, #24]
    9160:	2a1803f5 	mov	w21, w24
    9164:	d37d7f18 	ubfiz	x24, x24, #3, #32
    9168:	d37ef6b9 	lsl	x25, x21, #2
    916c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    9170:	aa1603e0 	mov	x0, x22
    9174:	97ffe54b 	bl	26a0 <strlen@plt>
    9178:	aa1603e1 	mov	x1, x22
    917c:	aa0003e2 	mov	x2, x0
    9180:	aa1403e0 	mov	x0, x20
    9184:	97ffe923 	bl	3610 <buf_put>
    9188:	f9401780 	ldr	x0, [x28, #40]
    918c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    9190:	7100001f 	cmp	w0, #0x0
    9194:	5400068d 	b.le	9264 <fwp_write+0x7e4>
    9198:	91002276 	add	x22, x19, #0x8
    919c:	91001ff5 	add	x21, sp, #0x7
    91a0:	d280001b 	mov	x27, #0x0                   	// #0
    91a4:	5280041a 	mov	w26, #0x20                  	// #32
    91a8:	f9401b80 	ldr	x0, [x28, #48]
    91ac:	aa1503e1 	mov	x1, x21
    91b0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    91b4:	d2800022 	mov	x2, #0x1                   	// #1
    91b8:	f8786803 	ldr	x3, [x0, x24]
    91bc:	aa1403e0 	mov	x0, x20
    91c0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    91c4:	39001ffa 	strb	w26, [sp, #7]
    91c8:	97ffe912 	bl	3610 <buf_put>
    91cc:	f13ffeff 	cmp	x23, #0xfff
    91d0:	b9400261 	ldr	w1, [x19]
    91d4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    91d8:	7100383f 	cmp	w1, #0xe
    91dc:	54000160 	b.eq	9208 <fwp_write+0x788>  // b.none
    91e0:	7100403f 	cmp	w1, #0x10
    91e4:	54001a60 	b.eq	9530 <fwp_write+0xab0>  // b.none
    91e8:	7100283f 	cmp	w1, #0xa
    91ec:	54002aa0 	b.eq	9740 <fwp_write+0xcc0>  // b.none
    91f0:	540014ac 	b.gt	9484 <fwp_write+0xa04>
    91f4:	71000c3f 	cmp	w1, #0x3
    91f8:	540029ac 	b.gt	972c <fwp_write+0xcac>
    91fc:	d37ffee0 	lsr	x0, x23, #63
    9200:	37f814a1 	tbnz	w1, #31, 9494 <fwp_write+0xa14>
    9204:	d503201f 	nop
    9208:	34001460 	cbz	w0, 9494 <fwp_write+0xa14>
    920c:	52800503 	mov	w3, #0x28                  	// #40
    9210:	aa1503e1 	mov	x1, x21
    9214:	aa1403e0 	mov	x0, x20
    9218:	d2800022 	mov	x2, #0x1                   	// #1
    921c:	39001fe3 	strb	w3, [sp, #7]
    9220:	97ffe8fc 	bl	3610 <buf_put>
    9224:	aa1303e2 	mov	x2, x19
    9228:	aa1703e1 	mov	x1, x23
    922c:	aa1403e0 	mov	x0, x20
    9230:	52800003 	mov	w3, #0x0                   	// #0
    9234:	97fffe13 	bl	8a80 <fwp_write>
    9238:	52800523 	mov	w3, #0x29                  	// #41
    923c:	aa1503e1 	mov	x1, x21
    9240:	aa1403e0 	mov	x0, x20
    9244:	d2800022 	mov	x2, #0x1                   	// #1
    9248:	39001fe3 	strb	w3, [sp, #7]
    924c:	97ffe8f1 	bl	3610 <buf_put>
    9250:	f9401780 	ldr	x0, [x28, #40]
    9254:	9100077b 	add	x27, x27, #0x1
    9258:	b8796800 	ldr	w0, [x0, x25]
    925c:	6b1b001f 	cmp	w0, w27
    9260:	54fffa4c 	b.gt	91a8 <fwp_write+0x728>
    9264:	f9413bf5 	ldr	x21, [sp, #624]
    9268:	f9413ff6 	ldr	x22, [sp, #632]
    926c:	f94143f7 	ldr	x23, [sp, #640]
    9270:	f94147f8 	ldr	x24, [sp, #648]
    9274:	f9414bf9 	ldr	x25, [sp, #656]
    9278:	f9414ffa 	ldr	x26, [sp, #664]
    927c:	f94153fb 	ldr	x27, [sp, #672]
    9280:	f94157fc 	ldr	x28, [sp, #680]
    9284:	17fffe2b 	b	8b30 <fwp_write+0xb0>
    9288:	52800783 	mov	w3, #0x3c                  	// #60
    928c:	91001ff3 	add	x19, sp, #0x7
    9290:	aa1303e1 	mov	x1, x19
    9294:	d2800022 	mov	x2, #0x1                   	// #1
    9298:	aa1403e0 	mov	x0, x20
    929c:	39001fe3 	strb	w3, [sp, #7]
    92a0:	97ffe8dc 	bl	3610 <buf_put>
    92a4:	f9400795 	ldr	x21, [x28, #8]
    92a8:	aa1503e0 	mov	x0, x21
    92ac:	97ffe4fd 	bl	26a0 <strlen@plt>
    92b0:	aa1503e1 	mov	x1, x21
    92b4:	aa0003e2 	mov	x2, x0
    92b8:	aa1403e0 	mov	x0, x20
    92bc:	97ffe8d5 	bl	3610 <buf_put>
    92c0:	528007c3 	mov	w3, #0x3e                  	// #62
    92c4:	aa1303e1 	mov	x1, x19
    92c8:	aa1403e0 	mov	x0, x20
    92cc:	d2800022 	mov	x2, #0x1                   	// #1
    92d0:	39001fe3 	strb	w3, [sp, #7]
    92d4:	17fffe12 	b	8b1c <fwp_write+0x9c>
    92d8:	f100067f 	cmp	x19, #0x1
    92dc:	540025a0 	b.eq	9790 <fwp_write+0xd10>  // b.none
    92e0:	b100067f 	cmn	x19, #0x1
    92e4:	54002bc0 	b.eq	985c <fwp_write+0xddc>  // b.none
    92e8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    92ec:	91040021 	add	x1, x1, #0x100
    92f0:	d2800022 	mov	x2, #0x1                   	// #1
    92f4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    92f8:	f947f400 	ldr	x0, [x0, #4072]
    92fc:	f94127e4 	ldr	x4, [sp, #584]
    9300:	f9400003 	ldr	x3, [x0]
    9304:	eb030084 	subs	x4, x4, x3
    9308:	d2800003 	mov	x3, #0x0                   	// #0
    930c:	54ffebe0 	b.eq	9088 <fwp_write+0x608>  // b.none
    9310:	f90143f7 	str	x23, [sp, #640]
    9314:	f90147f8 	str	x24, [sp, #648]
    9318:	f9014bf9 	str	x25, [sp, #656]
    931c:	f9014ffa 	str	x26, [sp, #664]
    9320:	fd015be8 	str	d8, [sp, #688]
    9324:	fd015fe9 	str	d9, [sp, #696]
    9328:	97ffe53a 	bl	2810 <__stack_chk_fail@plt>
    932c:	52800b63 	mov	w3, #0x5b                  	// #91
    9330:	91001ff5 	add	x21, sp, #0x7
    9334:	aa1503e1 	mov	x1, x21
    9338:	aa1403e0 	mov	x0, x20
    933c:	d2800022 	mov	x2, #0x1                   	// #1
    9340:	b0000036 	adrp	x22, e000 <_IO_stdin_used+0x5f0>
    9344:	910682d6 	add	x22, x22, #0x1a0
    9348:	39001fe3 	strb	w3, [sp, #7]
    934c:	97ffe8b1 	bl	3610 <buf_put>
    9350:	b4000273 	cbz	x19, 939c <fwp_write+0x91c>
    9354:	f9400661 	ldr	x1, [x19, #8]
    9358:	aa1403e0 	mov	x0, x20
    935c:	f9401f82 	ldr	x2, [x28, #56]
    9360:	52800003 	mov	w3, #0x0                   	// #0
    9364:	97fffdc7 	bl	8a80 <fwp_write>
    9368:	f9400a73 	ldr	x19, [x19, #16]
    936c:	b4000193 	cbz	x19, 939c <fwp_write+0x91c>
    9370:	aa1603e1 	mov	x1, x22
    9374:	aa1403e0 	mov	x0, x20
    9378:	d2800042 	mov	x2, #0x2                   	// #2
    937c:	97ffe8a5 	bl	3610 <buf_put>
    9380:	f9400661 	ldr	x1, [x19, #8]
    9384:	aa1403e0 	mov	x0, x20
    9388:	f9401f82 	ldr	x2, [x28, #56]
    938c:	52800003 	mov	w3, #0x0                   	// #0
    9390:	97fffdbc 	bl	8a80 <fwp_write>
    9394:	f9400a73 	ldr	x19, [x19, #16]
    9398:	b5fffed3 	cbnz	x19, 9370 <fwp_write+0x8f0>
    939c:	52800ba3 	mov	w3, #0x5d                  	// #93
    93a0:	aa1503e1 	mov	x1, x21
    93a4:	aa1403e0 	mov	x0, x20
    93a8:	d2800022 	mov	x2, #0x1                   	// #1
    93ac:	39001fe3 	strb	w3, [sp, #7]
    93b0:	17fffddb 	b	8b1c <fwp_write+0x9c>
    93b4:	aa1403e0 	mov	x0, x20
    93b8:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    93bc:	d28000c2 	mov	x2, #0x6                   	// #6
    93c0:	91064021 	add	x1, x1, #0x190
    93c4:	97ffe893 	bl	3610 <buf_put>
    93c8:	f9400260 	ldr	x0, [x19]
    93cc:	b40004c0 	cbz	x0, 9464 <fwp_write+0x9e4>
    93d0:	910123f5 	add	x21, sp, #0x48
    93d4:	91002276 	add	x22, x19, #0x8
    93d8:	f90143f7 	str	x23, [sp, #640]
    93dc:	d2800017 	mov	x23, #0x0                   	// #0
    93e0:	f90147f8 	str	x24, [sp, #648]
    93e4:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x5f0>
    93e8:	91066318 	add	x24, x24, #0x198
    93ec:	f9014bf9 	str	x25, [sp, #656]
    93f0:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x5f0>
    93f4:	91068339 	add	x25, x25, #0x1a0
    93f8:	f9014ffa 	str	x26, [sp, #664]
    93fc:	14000005 	b	9410 <fwp_write+0x990>
    9400:	aa1903e1 	mov	x1, x25
    9404:	aa1403e0 	mov	x0, x20
    9408:	d2800042 	mov	x2, #0x2                   	// #2
    940c:	97ffe881 	bl	3610 <buf_put>
    9410:	38776ac5 	ldrb	w5, [x22, x23]
    9414:	d2804003 	mov	x3, #0x200                 	// #512
    9418:	aa1803e4 	mov	x4, x24
    941c:	aa0303e1 	mov	x1, x3
    9420:	52800042 	mov	w2, #0x2                   	// #2
    9424:	aa1503e0 	mov	x0, x21
    9428:	910006f7 	add	x23, x23, #0x1
    942c:	97ffe4d5 	bl	2780 <__snprintf_chk@plt>
    9430:	aa1503e0 	mov	x0, x21
    9434:	97ffe49b 	bl	26a0 <strlen@plt>
    9438:	aa1503e1 	mov	x1, x21
    943c:	aa0003e2 	mov	x2, x0
    9440:	aa1403e0 	mov	x0, x20
    9444:	97ffe873 	bl	3610 <buf_put>
    9448:	f9400260 	ldr	x0, [x19]
    944c:	eb17001f 	cmp	x0, x23
    9450:	54fffd88 	b.hi	9400 <fwp_write+0x980>  // b.pmore
    9454:	f94143f7 	ldr	x23, [sp, #640]
    9458:	f94147f8 	ldr	x24, [sp, #648]
    945c:	f9414bf9 	ldr	x25, [sp, #656]
    9460:	f9414ffa 	ldr	x26, [sp, #664]
    9464:	52800ba3 	mov	w3, #0x5d                  	// #93
    9468:	aa1403e0 	mov	x0, x20
    946c:	91001fe1 	add	x1, sp, #0x7
    9470:	d2800022 	mov	x2, #0x1                   	// #1
    9474:	39001fe3 	strb	w3, [sp, #7]
    9478:	17fffda9 	b	8b1c <fwp_write+0x9c>
    947c:	52800fa3 	mov	w3, #0x7d                  	// #125
    9480:	17fffe44 	b	8d90 <fwp_write+0x310>
    9484:	f10002ff 	cmp	x23, #0x0
    9488:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    948c:	71002c3f 	cmp	w1, #0xb
    9490:	54ffebc0 	b.eq	9208 <fwp_write+0x788>  // b.none
    9494:	aa1303e2 	mov	x2, x19
    9498:	aa1703e1 	mov	x1, x23
    949c:	aa1403e0 	mov	x0, x20
    94a0:	52800003 	mov	w3, #0x0                   	// #0
    94a4:	97fffd77 	bl	8a80 <fwp_write>
    94a8:	17ffff6a 	b	9250 <fwp_write+0x7d0>
    94ac:	aa1403e0 	mov	x0, x20
    94b0:	91001fe1 	add	x1, sp, #0x7
    94b4:	52800fa3 	mov	w3, #0x7d                  	// #125
    94b8:	d2800022 	mov	x2, #0x1                   	// #1
    94bc:	17fffe38 	b	8d9c <fwp_write+0x31c>
    94c0:	a9400281 	ldp	x1, x0, [x20]
    94c4:	91000800 	add	x0, x0, #0x2
    94c8:	8b160000 	add	x0, x0, x22
    94cc:	f9000680 	str	x0, [x20, #8]
    94d0:	3820683f 	strb	wzr, [x1, x0]
    94d4:	f9413bf5 	ldr	x21, [sp, #624]
    94d8:	f9413ff6 	ldr	x22, [sp, #632]
    94dc:	f94153fb 	ldr	x27, [sp, #672]
    94e0:	f94157fc 	ldr	x28, [sp, #680]
    94e4:	17fffd93 	b	8b30 <fwp_write+0xb0>
    94e8:	f9400f80 	ldr	x0, [x28, #24]
    94ec:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    94f0:	aa1b03e0 	mov	x0, x27
    94f4:	97ffe46b 	bl	26a0 <strlen@plt>
    94f8:	aa1b03e1 	mov	x1, x27
    94fc:	aa0003e2 	mov	x2, x0
    9500:	aa1403e0 	mov	x0, x20
    9504:	97ffe843 	bl	3610 <buf_put>
    9508:	aa1903e1 	mov	x1, x25
    950c:	aa1403e0 	mov	x0, x20
    9510:	d2800062 	mov	x2, #0x3                   	// #3
    9514:	97ffe83f 	bl	3610 <buf_put>
    9518:	17fffe10 	b	8d58 <fwp_write+0x2d8>
    951c:	aa1a03e1 	mov	x1, x26
    9520:	aa1403e0 	mov	x0, x20
    9524:	d2800042 	mov	x2, #0x2                   	// #2
    9528:	97ffe83a 	bl	3610 <buf_put>
    952c:	17fffe09 	b	8d50 <fwp_write+0x2d0>
    9530:	f9400660 	ldr	x0, [x19, #8]
    9534:	b4fffb00 	cbz	x0, 9494 <fwp_write+0xa14>
    9538:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    953c:	9106e021 	add	x1, x1, #0x1b8
    9540:	97ffe4d4 	bl	2890 <strcmp@plt>
    9544:	7100001f 	cmp	w0, #0x0
    9548:	1a9f07e0 	cset	w0, ne	// ne = any
    954c:	17ffff2f 	b	9208 <fwp_write+0x788>
    9550:	aa1403e0 	mov	x0, x20
    9554:	d2800042 	mov	x2, #0x2                   	// #2
    9558:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    955c:	9106c021 	add	x1, x1, #0x1b0
    9560:	97ffe82c 	bl	3610 <buf_put>
    9564:	91004261 	add	x1, x19, #0x10
    9568:	aa1403e0 	mov	x0, x20
    956c:	f9402382 	ldr	x2, [x28, #64]
    9570:	52800003 	mov	w3, #0x0                   	// #0
    9574:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    9578:	97fffd42 	bl	8a80 <fwp_write>
    957c:	17fffd9c 	b	8bec <fwp_write+0x16c>
    9580:	1e22c109 	fcvt	d9, s8
    9584:	910123f5 	add	x21, sp, #0x48
    9588:	52800033 	mov	w19, #0x1                   	// #1
    958c:	d503201f 	nop
    9590:	1e604120 	fmov	d0, d9
    9594:	2a1303e1 	mov	w1, w19
    9598:	aa1503e0 	mov	x0, x21
    959c:	97ffe95e 	bl	3b14 <fwp_format_g.constprop.0>
    95a0:	aa1503e0 	mov	x0, x21
    95a4:	d2800001 	mov	x1, #0x0                   	// #0
    95a8:	97ffe4c6 	bl	28c0 <strtof@plt>
    95ac:	1e202100 	fcmp	s8, s0
    95b0:	54ffdb60 	b.eq	911c <fwp_write+0x69c>  // b.none
    95b4:	11000673 	add	w19, w19, #0x1
    95b8:	71002a7f 	cmp	w19, #0xa
    95bc:	54fffea1 	b.ne	9590 <fwp_write+0xb10>  // b.any
    95c0:	1e604120 	fmov	d0, d9
    95c4:	aa1503e0 	mov	x0, x21
    95c8:	52800121 	mov	w1, #0x9                   	// #9
    95cc:	97ffe952 	bl	3b14 <fwp_format_g.constprop.0>
    95d0:	17fffed3 	b	911c <fwp_write+0x69c>
    95d4:	d37ef6a1 	lsl	x1, x21, #2
    95d8:	b7f81563 	tbnz	x3, #63, 9884 <fwp_write+0xe04>
    95dc:	91002263 	add	x3, x19, #0x8
    95e0:	8b010061 	add	x1, x3, x1
    95e4:	b9400023 	ldr	w3, [x1]
    95e8:	7100081f 	cmp	w0, #0x2
    95ec:	2a0303e1 	mov	w1, w3
    95f0:	93407c63 	sxtw	x3, w3
    95f4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    95f8:	17fffe5a 	b	8f60 <fwp_write+0x4e0>
    95fc:	d37ffaa1 	lsl	x1, x21, #1
    9600:	b7f81363 	tbnz	x3, #63, 986c <fwp_write+0xdec>
    9604:	91002263 	add	x3, x19, #0x8
    9608:	8b010061 	add	x1, x3, x1
    960c:	79400021 	ldrh	w1, [x1]
    9610:	7100041f 	cmp	w0, #0x1
    9614:	93403c23 	sxth	x3, w1
    9618:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    961c:	17fffe51 	b	8f60 <fwp_write+0x4e0>
    9620:	52800443 	mov	w3, #0x22                  	// #34
    9624:	91001ff5 	add	x21, sp, #0x7
    9628:	91002273 	add	x19, x19, #0x8
    962c:	aa1503e1 	mov	x1, x21
    9630:	aa1403e0 	mov	x0, x20
    9634:	d2800022 	mov	x2, #0x1                   	// #1
    9638:	39001fe3 	strb	w3, [sp, #7]
    963c:	f90143f7 	str	x23, [sp, #640]
    9640:	8b160277 	add	x23, x19, x22
    9644:	f90147f8 	str	x24, [sp, #648]
    9648:	97ffe7f2 	bl	3610 <buf_put>
    964c:	b4000696 	cbz	x22, 971c <fwp_write+0xc9c>
    9650:	b0000038 	adrp	x24, e000 <_IO_stdin_used+0x5f0>
    9654:	91058318 	add	x24, x24, #0x160
    9658:	f9014bf9 	str	x25, [sp, #656]
    965c:	b0000039 	adrp	x25, e000 <_IO_stdin_used+0x5f0>
    9660:	91060339 	add	x25, x25, #0x180
    9664:	f9014ffa 	str	x26, [sp, #664]
    9668:	1400000d 	b	969c <fwp_write+0xc1c>
    966c:	710024bf 	cmp	w5, #0x9
    9670:	54000460 	b.eq	96fc <fwp_write+0xc7c>  // b.none
    9674:	710028bf 	cmp	w5, #0xa
    9678:	54000a61 	b.ne	97c4 <fwp_write+0xd44>  // b.any
    967c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    9680:	aa1403e0 	mov	x0, x20
    9684:	9105c021 	add	x1, x1, #0x170
    9688:	d2800042 	mov	x2, #0x2                   	// #2
    968c:	97ffe7e1 	bl	3610 <buf_put>
    9690:	91000673 	add	x19, x19, #0x1
    9694:	eb17027f 	cmp	x19, x23
    9698:	540003e0 	b.eq	9714 <fwp_write+0xc94>  // b.none
    969c:	39400265 	ldrb	w5, [x19]
    96a0:	710034bf 	cmp	w5, #0xd
    96a4:	54000180 	b.eq	96d4 <fwp_write+0xc54>  // b.none
    96a8:	54fffe29 	b.ls	966c <fwp_write+0xbec>  // b.plast
    96ac:	710088bf 	cmp	w5, #0x22
    96b0:	540001c0 	b.eq	96e8 <fwp_write+0xc68>  // b.none
    96b4:	710170bf 	cmp	w5, #0x5c
    96b8:	54000741 	b.ne	97a0 <fwp_write+0xd20>  // b.any
    96bc:	aa1403e0 	mov	x0, x20
    96c0:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    96c4:	d2800042 	mov	x2, #0x2                   	// #2
    96c8:	9105a021 	add	x1, x1, #0x168
    96cc:	97ffe7d1 	bl	3610 <buf_put>
    96d0:	17fffff0 	b	9690 <fwp_write+0xc10>
    96d4:	aa1903e1 	mov	x1, x25
    96d8:	aa1403e0 	mov	x0, x20
    96dc:	d2800042 	mov	x2, #0x2                   	// #2
    96e0:	97ffe7cc 	bl	3610 <buf_put>
    96e4:	17ffffeb 	b	9690 <fwp_write+0xc10>
    96e8:	aa1803e1 	mov	x1, x24
    96ec:	aa1403e0 	mov	x0, x20
    96f0:	d2800042 	mov	x2, #0x2                   	// #2
    96f4:	97ffe7c7 	bl	3610 <buf_put>
    96f8:	17ffffe6 	b	9690 <fwp_write+0xc10>
    96fc:	aa1403e0 	mov	x0, x20
    9700:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    9704:	d2800042 	mov	x2, #0x2                   	// #2
    9708:	9105e021 	add	x1, x1, #0x178
    970c:	97ffe7c1 	bl	3610 <buf_put>
    9710:	17ffffe0 	b	9690 <fwp_write+0xc10>
    9714:	f9414bf9 	ldr	x25, [sp, #656]
    9718:	f9414ffa 	ldr	x26, [sp, #664]
    971c:	aa1503e1 	mov	x1, x21
    9720:	aa1403e0 	mov	x0, x20
    9724:	52800443 	mov	w3, #0x22                  	// #34
    9728:	17fffd9c 	b	8d98 <fwp_write+0x318>
    972c:	7100103f 	cmp	w1, #0x4
    9730:	54ffeb21 	b.ne	9494 <fwp_write+0xa14>  // b.any
    9734:	f94006e0 	ldr	x0, [x23, #8]
    9738:	d37ffc00 	lsr	x0, x0, #63
    973c:	17fffeb3 	b	9208 <fwp_write+0x788>
    9740:	710002ff 	cmp	w23, #0x0
    9744:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9748:	17fffeb0 	b	9208 <fwp_write+0x788>
    974c:	528005a1 	mov	w1, #0x2d                  	// #45
    9750:	eb0203e2 	negs	x2, x2
    9754:	da0303e3 	ngc	x3, x3
    9758:	910127e0 	add	x0, sp, #0x49
    975c:	910123f5 	add	x21, sp, #0x48
    9760:	390123e1 	strb	w1, [sp, #72]
    9764:	97ffe58f 	bl	2da0 <fwp_fmt_u128>
    9768:	17fffe18 	b	8fc8 <fwp_write+0x548>
    976c:	d37ceea1 	lsl	x1, x21, #4
    9770:	b7f810a3 	tbnz	x3, #63, 9984 <fwp_write+0xf04>
    9774:	91002260 	add	x0, x19, #0x8
    9778:	8b010001 	add	x1, x0, x1
    977c:	17fffdf9 	b	8f60 <fwp_write+0x4e0>
    9780:	f9400a61 	ldr	x1, [x19, #16]
    9784:	8b010000 	add	x0, x0, x1
    9788:	f9400001 	ldr	x1, [x0]
    978c:	17fffdf5 	b	8f60 <fwp_write+0x4e0>
    9790:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    9794:	d2800042 	mov	x2, #0x2                   	// #2
    9798:	91042021 	add	x1, x1, #0x108
    979c:	17fffed6 	b	92f4 <fwp_write+0x874>
    97a0:	7101fcbf 	cmp	w5, #0x7f
    97a4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    97a8:	540000e9 	b.ls	97c4 <fwp_write+0xd44>  // b.plast
    97ac:	aa1503e1 	mov	x1, x21
    97b0:	aa1403e0 	mov	x0, x20
    97b4:	d2800022 	mov	x2, #0x1                   	// #1
    97b8:	39001fe5 	strb	w5, [sp, #7]
    97bc:	97ffe795 	bl	3610 <buf_put>
    97c0:	17ffffb4 	b	9690 <fwp_write+0xc10>
    97c4:	d2800203 	mov	x3, #0x10                  	// #16
    97c8:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0x5f0>
    97cc:	aa0303e1 	mov	x1, x3
    97d0:	91062084 	add	x4, x4, #0x188
    97d4:	910123f6 	add	x22, sp, #0x48
    97d8:	52800042 	mov	w2, #0x2                   	// #2
    97dc:	aa1603e0 	mov	x0, x22
    97e0:	97ffe3e8 	bl	2780 <__snprintf_chk@plt>
    97e4:	aa1603e0 	mov	x0, x22
    97e8:	97ffe3ae 	bl	26a0 <strlen@plt>
    97ec:	aa1603e1 	mov	x1, x22
    97f0:	aa0003e2 	mov	x2, x0
    97f4:	aa1403e0 	mov	x0, x20
    97f8:	97ffe786 	bl	3610 <buf_put>
    97fc:	17ffffa5 	b	9690 <fwp_write+0xc10>
    9800:	1e604100 	fmov	d0, d8
    9804:	aa1503e0 	mov	x0, x21
    9808:	52800221 	mov	w1, #0x11                  	// #17
    980c:	97ffe8c2 	bl	3b14 <fwp_format_g.constprop.0>
    9810:	17fffe43 	b	911c <fwp_write+0x69c>
    9814:	b9401040 	ldr	w0, [x2, #16]
    9818:	350003c0 	cbnz	w0, 9890 <fwp_write+0xe10>
    981c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9820:	f947f400 	ldr	x0, [x0, #4072]
    9824:	f94127e2 	ldr	x2, [sp, #584]
    9828:	f9400001 	ldr	x1, [x0]
    982c:	eb010042 	subs	x2, x2, x1
    9830:	d2800001 	mov	x1, #0x0                   	// #0
    9834:	54ffd721 	b.ne	9318 <fwp_write+0x898>  // b.any
    9838:	f9413bf5 	ldr	x21, [sp, #624]
    983c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    9840:	f9413ff6 	ldr	x22, [sp, #632]
    9844:	aa1403e0 	mov	x0, x20
    9848:	f94143f7 	ldr	x23, [sp, #640]
    984c:	91076021 	add	x1, x1, #0x1d8
    9850:	f94147f8 	ldr	x24, [sp, #648]
    9854:	d2800042 	mov	x2, #0x2                   	// #2
    9858:	17fffd0e 	b	8c90 <fwp_write+0x210>
    985c:	b0000021 	adrp	x1, e000 <_IO_stdin_used+0x5f0>
    9860:	d2800042 	mov	x2, #0x2                   	// #2
    9864:	91044021 	add	x1, x1, #0x110
    9868:	17fffea3 	b	92f4 <fwp_write+0x874>
    986c:	f9400a63 	ldr	x3, [x19, #16]
    9870:	8b030021 	add	x1, x1, x3
    9874:	17ffff66 	b	960c <fwp_write+0xb8c>
    9878:	f9400a61 	ldr	x1, [x19, #16]
    987c:	8b0102a1 	add	x1, x21, x1
    9880:	17fffdb3 	b	8f4c <fwp_write+0x4cc>
    9884:	f9400a63 	ldr	x3, [x19, #16]
    9888:	8b030021 	add	x1, x1, x3
    988c:	17ffff56 	b	95e4 <fwp_write+0xb64>
    9890:	b9404840 	ldr	w0, [x2, #72]
    9894:	91001ff5 	add	x21, sp, #0x7
    9898:	34ffa360 	cbz	w0, 8d04 <fwp_write+0x284>
    989c:	52800503 	mov	w3, #0x28                  	// #40
    98a0:	aa1403e0 	mov	x0, x20
    98a4:	aa1503e1 	mov	x1, x21
    98a8:	d2800022 	mov	x2, #0x1                   	// #1
    98ac:	39001fe3 	strb	w3, [sp, #7]
    98b0:	97ffe758 	bl	3610 <buf_put>
    98b4:	b9401380 	ldr	w0, [x28, #16]
    98b8:	52800038 	mov	w24, #0x1                   	// #1
    98bc:	7100001f 	cmp	w0, #0x0
    98c0:	54ffa36c 	b.gt	8d2c <fwp_write+0x2ac>
    98c4:	17fffd32 	b	8d8c <fwp_write+0x30c>
    98c8:	f9014bf9 	str	x25, [sp, #656]
    98cc:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe108>
    98d0:	f9014ffa 	str	x26, [sp, #664]
    98d4:	f9400676 	ldr	x22, [x19, #8]
    98d8:	91104333 	add	x19, x25, #0x410
    98dc:	91002273 	add	x19, x19, #0x8
    98e0:	937ffed8 	asr	x24, x22, #63
    98e4:	aa1802c0 	orr	x0, x22, x24
    98e8:	b5000320 	cbnz	x0, 994c <fwp_write+0xecc>
    98ec:	110006b5 	add	w21, w21, #0x1
    98f0:	710016bf 	cmp	w21, #0x5
    98f4:	54ffffc1 	b.ne	98ec <fwp_write+0xe6c>  // b.any
    98f8:	b7f80578 	tbnz	x24, #63, 99a4 <fwp_write+0xf24>
    98fc:	910023f3 	add	x19, sp, #0x8
    9900:	aa1603e2 	mov	x2, x22
    9904:	aa1303e0 	mov	x0, x19
    9908:	d2800003 	mov	x3, #0x0                   	// #0
    990c:	97ffe525 	bl	2da0 <fwp_fmt_u128>
    9910:	910123f5 	add	x21, sp, #0x48
    9914:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x5f0>
    9918:	aa1303e4 	mov	x4, x19
    991c:	aa1503e0 	mov	x0, x21
    9920:	91074063 	add	x3, x3, #0x1d0
    9924:	d2804002 	mov	x2, #0x200                 	// #512
    9928:	52800041 	mov	w1, #0x2                   	// #2
    992c:	97ffe361 	bl	26b0 <__sprintf_chk@plt>
    9930:	aa1503e0 	mov	x0, x21
    9934:	97ffe35b 	bl	26a0 <strlen@plt>
    9938:	aa1503e1 	mov	x1, x21
    993c:	aa0003e2 	mov	x2, x0
    9940:	aa1403e0 	mov	x0, x20
    9944:	97ffe733 	bl	3610 <buf_put>
    9948:	17fffe47 	b	9264 <fwp_write+0x7e4>
    994c:	f9400277 	ldr	x23, [x19]
    9950:	aa1603e0 	mov	x0, x22
    9954:	aa1803e1 	mov	x1, x24
    9958:	aa1703e2 	mov	x2, x23
    995c:	937ffefa 	asr	x26, x23, #63
    9960:	aa1a03e3 	mov	x3, x26
    9964:	94000f43 	bl	d670 <__modti3>
    9968:	aa010000 	orr	x0, x0, x1
    996c:	b40002c0 	cbz	x0, 99c4 <fwp_write+0xf44>
    9970:	110006b5 	add	w21, w21, #0x1
    9974:	91004273 	add	x19, x19, #0x10
    9978:	710016bf 	cmp	w21, #0x5
    997c:	54fffe81 	b.ne	994c <fwp_write+0xecc>  // b.any
    9980:	17ffffde 	b	98f8 <fwp_write+0xe78>
    9984:	f9400a60 	ldr	x0, [x19, #16]
    9988:	8b000021 	add	x1, x1, x0
    998c:	17fffd75 	b	8f60 <fwp_write+0x4e0>
    9990:	528c29c0 	mov	w0, #0x614e                	// #24910
    9994:	910123f5 	add	x21, sp, #0x48
    9998:	72a009c0 	movk	w0, #0x4e, lsl #16
    999c:	b9004be0 	str	w0, [sp, #72]
    99a0:	17fffda2 	b	9028 <fwp_write+0x5a8>
    99a4:	528005a1 	mov	w1, #0x2d                  	// #45
    99a8:	eb1603e2 	negs	x2, x22
    99ac:	da1803e3 	ngc	x3, x24
    99b0:	910027e0 	add	x0, sp, #0x9
    99b4:	910023f3 	add	x19, sp, #0x8
    99b8:	390023e1 	strb	w1, [sp, #8]
    99bc:	97ffe4f9 	bl	2da0 <fwp_fmt_u128>
    99c0:	17ffffd4 	b	9910 <fwp_write+0xe90>
    99c4:	aa1703e2 	mov	x2, x23
    99c8:	aa1a03e3 	mov	x3, x26
    99cc:	aa1603e0 	mov	x0, x22
    99d0:	aa1803e1 	mov	x1, x24
    99d4:	94000e47 	bl	d2f0 <__divti3>
    99d8:	aa0003e2 	mov	x2, x0
    99dc:	aa0103e3 	mov	x3, x1
    99e0:	b7f80201 	tbnz	x1, #63, 9a20 <fwp_write+0xfa0>
    99e4:	910023f3 	add	x19, sp, #0x8
    99e8:	aa1303e0 	mov	x0, x19
    99ec:	97ffe4ed 	bl	2da0 <fwp_fmt_u128>
    99f0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    99f4:	91104339 	add	x25, x25, #0x410
    99f8:	910123f5 	add	x21, sp, #0x48
    99fc:	aa1303e4 	mov	x4, x19
    9a00:	aa1503e0 	mov	x0, x21
    9a04:	b0000023 	adrp	x3, e000 <_IO_stdin_used+0x5f0>
    9a08:	f8616b25 	ldr	x5, [x25, x1]
    9a0c:	91072063 	add	x3, x3, #0x1c8
    9a10:	d2804002 	mov	x2, #0x200                 	// #512
    9a14:	52800041 	mov	w1, #0x2                   	// #2
    9a18:	97ffe326 	bl	26b0 <__sprintf_chk@plt>
    9a1c:	17ffffc5 	b	9930 <fwp_write+0xeb0>
    9a20:	528005a4 	mov	w4, #0x2d                  	// #45
    9a24:	eb0003e2 	negs	x2, x0
    9a28:	da0103e3 	ngc	x3, x1
    9a2c:	910027e0 	add	x0, sp, #0x9
    9a30:	910023f3 	add	x19, sp, #0x8
    9a34:	390023e4 	strb	w4, [sp, #8]
    9a38:	97ffe4da 	bl	2da0 <fwp_fmt_u128>
    9a3c:	17ffffed 	b	99f0 <fwp_write+0xf70>
    9a40:	f9013bf5 	str	x21, [sp, #624]
    9a44:	f9013ff6 	str	x22, [sp, #632]
    9a48:	f90143f7 	str	x23, [sp, #640]
    9a4c:	f90147f8 	str	x24, [sp, #648]
    9a50:	f9014bf9 	str	x25, [sp, #656]
    9a54:	f9014ffa 	str	x26, [sp, #664]
    9a58:	f90153fb 	str	x27, [sp, #672]
    9a5c:	f90157fc 	str	x28, [sp, #680]
    9a60:	fd015be8 	str	d8, [sp, #688]
    9a64:	fd015fe9 	str	d9, [sp, #696]
    9a68:	97ffe36a 	bl	2810 <__stack_chk_fail@plt>
    9a6c:	d503201f 	nop

0000000000009a70 <fwp_hof0.constprop.0>:
    9a70:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9a74:	d00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    9a78:	f947f442 	ldr	x2, [x2, #4072]
    9a7c:	910003fd 	mov	x29, sp
    9a80:	a90153f3 	stp	x19, x20, [sp, #16]
    9a84:	a9025bf5 	stp	x21, x22, [sp, #32]
    9a88:	a90363f7 	stp	x23, x24, [sp, #48]
    9a8c:	aa0003f7 	mov	x23, x0
    9a90:	a9046bf9 	stp	x25, x26, [sp, #64]
    9a94:	a90573fb 	stp	x27, x28, [sp, #80]
    9a98:	d10243ff 	sub	sp, sp, #0x90
    9a9c:	f9400040 	ldr	x0, [x2]
    9aa0:	f81f83a0 	stur	x0, [x29, #-8]
    9aa4:	d2800000 	mov	x0, #0x0                   	// #0
    9aa8:	b4002ee1 	cbz	x1, a084 <fwp_hof0.constprop.0+0x614>
    9aac:	f00000a0 	adrp	x0, 20000 <__data_start>
    9ab0:	9100401c 	add	x28, x0, #0x10
    9ab4:	9100a39c 	add	x28, x28, #0x28
    9ab8:	f00000a0 	adrp	x0, 20000 <__data_start>
    9abc:	aa0103fa 	mov	x26, x1
    9ac0:	d10083b4 	sub	x20, x29, #0x20
    9ac4:	91018015 	add	x21, x0, #0x60
    9ac8:	aa1c03f8 	mov	x24, x28
    9acc:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9ad0:	91190002 	add	x2, x0, #0x640
    9ad4:	f949d841 	ldr	x1, [x2, #5040]
    9ad8:	f949ec40 	ldr	x0, [x2, #5080]
    9adc:	cb0102e1 	sub	x1, x23, x1
    9ae0:	eb00403f 	cmp	x1, x0, lsl #16
    9ae4:	540003c2 	b.cs	9b5c <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    9ae8:	d350fc20 	lsr	x0, x1, #16
    9aec:	f949fc44 	ldr	x4, [x2, #5112]
    9af0:	8b000800 	add	x0, x0, x0, lsl #2
    9af4:	d37df002 	lsl	x2, x0, #3
    9af8:	8b020083 	add	x3, x4, x2
    9afc:	f9401060 	ldr	x0, [x3, #32]
    9b00:	b40002e0 	cbz	x0, 9b5c <fwp_hof0.constprop.0+0xec>
    9b04:	38626882 	ldrb	w2, [x4, x2]
    9b08:	7100085f 	cmp	w2, #0x2
    9b0c:	54005600 	b.eq	a5cc <fwp_hof0.constprop.0+0xb5c>  // b.none
    9b10:	7100045f 	cmp	w2, #0x1
    9b14:	54000241 	b.ne	9b5c <fwp_hof0.constprop.0+0xec>  // b.any
    9b18:	29430864 	ldp	w4, w2, [x3, #24]
    9b1c:	92403c21 	and	x1, x1, #0xffff
    9b20:	9b047c21 	mul	x1, x1, x4
    9b24:	d360fc21 	lsr	x1, x1, #32
    9b28:	eb02003f 	cmp	x1, x2
    9b2c:	54000182 	b.cs	9b5c <fwp_hof0.constprop.0+0xec>  // b.hs, b.nlast
    9b30:	8b010000 	add	x0, x0, x1
    9b34:	39400001 	ldrb	w1, [x0]
    9b38:	34000121 	cbz	w1, 9b5c <fwp_hof0.constprop.0+0xec>
    9b3c:	f00000a2 	adrp	x2, 20000 <__data_start>
    9b40:	91018042 	add	x2, x2, #0x60
    9b44:	b9413043 	ldr	w3, [x2, #304]
    9b48:	35005583 	cbnz	w3, a5f8 <fwp_hof0.constprop.0+0xb88>
    9b4c:	7103f43f 	cmp	w1, #0xfd
    9b50:	54005ae8 	b.hi	a6ac <fwp_hof0.constprop.0+0xc3c>  // b.pmore
    9b54:	11000421 	add	w1, w1, #0x1
    9b58:	39000001 	strb	w1, [x0]
    9b5c:	aa1703f9 	mov	x25, x23
    9b60:	a938dfba 	stp	x26, x23, [x29, #-120]
    9b64:	aa1803fa 	mov	x26, x24
    9b68:	d28018f3 	mov	x19, #0xc7                  	// #199
    9b6c:	f81983b3 	stur	x19, [x29, #-104]
    9b70:	f00000a0 	adrp	x0, 20000 <__data_start>
    9b74:	91004000 	add	x0, x0, #0x10
    9b78:	f9406aa3 	ldr	x3, [x21, #208]
    9b7c:	9100a005 	add	x5, x0, #0x28
    9b80:	b9402802 	ldr	w2, [x0, #40]
    9b84:	d37be842 	lsl	x2, x2, #5
    9b88:	8b02007b 	add	x27, x3, x2
    9b8c:	f9400f61 	ldr	x1, [x27, #24]
    9b90:	f81e03b9 	stur	x25, [x29, #-32]
    9b94:	b4005221 	cbz	x1, a5d8 <fwp_hof0.constprop.0+0xb68>
    9b98:	f9400c20 	ldr	x0, [x1, #24]
    9b9c:	b4004560 	cbz	x0, a448 <fwp_hof0.constprop.0+0x9d8>
    9ba0:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9ba4:	91190002 	add	x2, x0, #0x640
    9ba8:	f949d841 	ldr	x1, [x2, #5040]
    9bac:	f949ec40 	ldr	x0, [x2, #5080]
    9bb0:	cb010341 	sub	x1, x26, x1
    9bb4:	eb00403f 	cmp	x1, x0, lsl #16
    9bb8:	540003e2 	b.cs	9c34 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9bbc:	d350fc20 	lsr	x0, x1, #16
    9bc0:	f949fc45 	ldr	x5, [x2, #5112]
    9bc4:	8b000800 	add	x0, x0, x0, lsl #2
    9bc8:	d37df002 	lsl	x2, x0, #3
    9bcc:	8b0200a3 	add	x3, x5, x2
    9bd0:	f9401060 	ldr	x0, [x3, #32]
    9bd4:	b4000300 	cbz	x0, 9c34 <fwp_hof0.constprop.0+0x1c4>
    9bd8:	386268a2 	ldrb	w2, [x5, x2]
    9bdc:	7100085f 	cmp	w2, #0x2
    9be0:	540049c0 	b.eq	a518 <fwp_hof0.constprop.0+0xaa8>  // b.none
    9be4:	7100045f 	cmp	w2, #0x1
    9be8:	54000261 	b.ne	9c34 <fwp_hof0.constprop.0+0x1c4>  // b.any
    9bec:	29430865 	ldp	w5, w2, [x3, #24]
    9bf0:	92403c21 	and	x1, x1, #0xffff
    9bf4:	9b057c21 	mul	x1, x1, x5
    9bf8:	d360fc21 	lsr	x1, x1, #32
    9bfc:	eb02003f 	cmp	x1, x2
    9c00:	540001a2 	b.cs	9c34 <fwp_hof0.constprop.0+0x1c4>  // b.hs, b.nlast
    9c04:	8b010000 	add	x0, x0, x1
    9c08:	39400001 	ldrb	w1, [x0]
    9c0c:	34000141 	cbz	w1, 9c34 <fwp_hof0.constprop.0+0x1c4>
    9c10:	b94132a2 	ldr	w2, [x21, #304]
    9c14:	34000082 	cbz	w2, 9c24 <fwp_hof0.constprop.0+0x1b4>
    9c18:	f940aea2 	ldr	x2, [x21, #344]
    9c1c:	91000442 	add	x2, x2, #0x1
    9c20:	f900aea2 	str	x2, [x21, #344]
    9c24:	7103f43f 	cmp	w1, #0xfd
    9c28:	54004c28 	b.hi	a5ac <fwp_hof0.constprop.0+0xb3c>  // b.pmore
    9c2c:	11000421 	add	w1, w1, #0x1
    9c30:	39000001 	strb	w1, [x0]
    9c34:	aa1a03f9 	mov	x25, x26
    9c38:	aa1a03e0 	mov	x0, x26
    9c3c:	aa1b03e3 	mov	x3, x27
    9c40:	52800037 	mov	w23, #0x1                   	// #1
    9c44:	90000381 	adrp	x1, 79000 <fwp_root_context+0xba0>
    9c48:	91190036 	add	x22, x1, #0x640
    9c4c:	a93a6bb4 	stp	x20, x26, [x29, #-96]
    9c50:	f81b03b6 	stur	x22, [x29, #-80]
    9c54:	b81cc3b7 	stur	w23, [x29, #-52]
    9c58:	f81d03b4 	stur	x20, [x29, #-48]
    9c5c:	b9400401 	ldr	w1, [x0, #4]
    9c60:	b9400078 	ldr	w24, [x3]
    9c64:	b85cc3a0 	ldur	w0, [x29, #-52]
    9c68:	4b010318 	sub	w24, w24, w1
    9c6c:	6b17031f 	cmp	w24, w23
    9c70:	1a979307 	csel	w7, w24, w23, ls	// ls = plast
    9c74:	6b0000ff 	cmp	w7, w0
    9c78:	1a8090e0 	csel	w0, w7, w0, ls	// ls = plast
    9c7c:	b81c83a0 	stur	w0, [x29, #-56]
    9c80:	6b0000e2 	subs	w2, w7, w0
    9c84:	54000120 	b.eq	9ca8 <fwp_hof0.constprop.0+0x238>  // b.none
    9c88:	f9400c63 	ldr	x3, [x3, #24]
    9c8c:	0b000021 	add	w1, w1, w0
    9c90:	f85d03a4 	ldur	x4, [x29, #-48]
    9c94:	b81d83a7 	stur	w7, [x29, #-40]
    9c98:	f9400863 	ldr	x3, [x3, #16]
    9c9c:	8b204c80 	add	x0, x4, w0, uxtw #3
    9ca0:	d63f0060 	blr	x3
    9ca4:	b85d83a7 	ldur	w7, [x29, #-40]
    9ca8:	f9406aa0 	ldr	x0, [x21, #208]
    9cac:	aa1903e6 	mov	x6, x25
    9cb0:	b9400323 	ldr	w3, [x25]
    9cb4:	2a0703f4 	mov	w20, w7
    9cb8:	f85d03bb 	ldur	x27, [x29, #-48]
    9cbc:	aa1903fc 	mov	x28, x25
    9cc0:	8b03141a 	add	x26, x0, x3, lsl #5
    9cc4:	f9400f40 	ldr	x0, [x26, #24]
    9cc8:	b4002100 	cbz	x0, a0e8 <fwp_hof0.constprop.0+0x678>
    9ccc:	f85b03bc 	ldur	x28, [x29, #-80]
    9cd0:	29371fb7 	stp	w23, w7, [x29, #-72]
    9cd4:	aa1a03f7 	mov	x23, x26
    9cd8:	b81c03b8 	stur	w24, [x29, #-64]
    9cdc:	aa1b03f8 	mov	x24, x27
    9ce0:	14000012 	b	9d28 <fwp_hof0.constprop.0+0x2b8>
    9ce4:	f9400001 	ldr	x1, [x0]
    9ce8:	aa1803e0 	mov	x0, x24
    9cec:	d63f0020 	blr	x1
    9cf0:	aa0003fb 	mov	x27, x0
    9cf4:	aa1903e0 	mov	x0, x25
    9cf8:	97fff17a 	bl	62e0 <fwp_closure_drop>
    9cfc:	6b13029f 	cmp	w20, w19
    9d00:	54000cc0 	b.eq	9e98 <fwp_hof0.constprop.0+0x428>  // b.none
    9d04:	f9406aa0 	ldr	x0, [x21, #208]
    9d08:	8b334f18 	add	x24, x24, w19, uxtw #3
    9d0c:	b9400363 	ldr	w3, [x27]
    9d10:	4b1a02d4 	sub	w20, w22, w26
    9d14:	aa1b03e6 	mov	x6, x27
    9d18:	8b031417 	add	x23, x0, x3, lsl #5
    9d1c:	f9400ee0 	ldr	x0, [x23, #24]
    9d20:	b4001dc0 	cbz	x0, a0d8 <fwp_hof0.constprop.0+0x668>
    9d24:	aa1b03f9 	mov	x25, x27
    9d28:	b94004c1 	ldr	w1, [x6, #4]
    9d2c:	b94002fa 	ldr	w26, [x23]
    9d30:	0b010296 	add	w22, w20, w1
    9d34:	6b16035f 	cmp	w26, w22
    9d38:	540024a8 	b.hi	a1cc <fwp_hof0.constprop.0+0x75c>  // b.pmore
    9d3c:	7100003f 	cmp	w1, #0x0
    9d40:	4b010353 	sub	w19, w26, w1
    9d44:	7a400b44 	ccmp	w26, #0x0, #0x4, eq	// eq = none
    9d48:	54fffce1 	b.ne	9ce4 <fwp_hof0.constprop.0+0x274>  // b.any
    9d4c:	7100035f 	cmp	w26, #0x0
    9d50:	910003e2 	mov	x2, sp
    9d54:	1a9f1744 	csinc	w4, w26, wzr, ne	// ne = any
    9d58:	f81d83a2 	stur	x2, [x29, #-40]
    9d5c:	d37df084 	lsl	x4, x4, #3
    9d60:	91003c84 	add	x4, x4, #0xf
    9d64:	92704c87 	and	x7, x4, #0xfffff0000
    9d68:	927c7c84 	and	x4, x4, #0xffffffff0
    9d6c:	cb2763e7 	sub	x7, sp, x7
    9d70:	eb2763ff 	cmp	sp, x7
    9d74:	540000a0 	b.eq	9d88 <fwp_hof0.constprop.0+0x318>  // b.none
    9d78:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    9d7c:	f90203ff 	str	xzr, [sp, #1024]
    9d80:	eb2763ff 	cmp	sp, x7
    9d84:	54ffffa1 	b.ne	9d78 <fwp_hof0.constprop.0+0x308>  // b.any
    9d88:	92403c84 	and	x4, x4, #0xffff
    9d8c:	cb2463ff 	sub	sp, sp, x4
    9d90:	f90003ff 	str	xzr, [sp]
    9d94:	f110009f 	cmp	x4, #0x400
    9d98:	54000043 	b.cc	9da0 <fwp_hof0.constprop.0+0x330>  // b.lo, b.ul, b.last
    9d9c:	f90203ff 	str	xzr, [sp, #1024]
    9da0:	910043fb 	add	x27, sp, #0x10
    9da4:	d37d7c2a 	ubfiz	x10, x1, #3, #32
    9da8:	910020c9 	add	x9, x6, #0x8
    9dac:	d2800004 	mov	x4, #0x0                   	// #0
    9db0:	340000e1 	cbz	w1, 9dcc <fwp_hof0.constprop.0+0x35c>
    9db4:	d503201f 	nop
    9db8:	f8646922 	ldr	x2, [x9, x4]
    9dbc:	f8246b62 	str	x2, [x27, x4]
    9dc0:	91002084 	add	x4, x4, #0x8
    9dc4:	eb04015f 	cmp	x10, x4
    9dc8:	54ffff81 	b.ne	9db8 <fwp_hof0.constprop.0+0x348>  // b.any
    9dcc:	2a1303ea 	mov	w10, w19
    9dd0:	d2800004 	mov	x4, #0x0                   	// #0
    9dd4:	340000f3 	cbz	w19, 9df0 <fwp_hof0.constprop.0+0x380>
    9dd8:	0b040022 	add	w2, w1, w4
    9ddc:	f8647b03 	ldr	x3, [x24, x4, lsl #3]
    9de0:	91000484 	add	x4, x4, #0x1
    9de4:	f8227b63 	str	x3, [x27, x2, lsl #3]
    9de8:	eb04015f 	cmp	x10, x4
    9dec:	54ffff61 	b.ne	9dd8 <fwp_hof0.constprop.0+0x368>  // b.any
    9df0:	f949db81 	ldr	x1, [x28, #5040]
    9df4:	f949ef84 	ldr	x4, [x28, #5080]
    9df8:	cb010321 	sub	x1, x25, x1
    9dfc:	eb04403f 	cmp	x1, x4, lsl #16
    9e00:	540002e2 	b.cs	9e5c <fwp_hof0.constprop.0+0x3ec>  // b.hs, b.nlast
    9e04:	d350fc24 	lsr	x4, x1, #16
    9e08:	f949ff8a 	ldr	x10, [x28, #5112]
    9e0c:	8b040884 	add	x4, x4, x4, lsl #2
    9e10:	d37df084 	lsl	x4, x4, #3
    9e14:	8b040149 	add	x9, x10, x4
    9e18:	f9401128 	ldr	x8, [x9, #32]
    9e1c:	b4000208 	cbz	x8, 9e5c <fwp_hof0.constprop.0+0x3ec>
    9e20:	38646944 	ldrb	w4, [x10, x4]
    9e24:	7100089f 	cmp	w4, #0x2
    9e28:	54001520 	b.eq	a0cc <fwp_hof0.constprop.0+0x65c>  // b.none
    9e2c:	7100049f 	cmp	w4, #0x1
    9e30:	54000161 	b.ne	9e5c <fwp_hof0.constprop.0+0x3ec>  // b.any
    9e34:	2943112a 	ldp	w10, w4, [x9, #24]
    9e38:	92403c21 	and	x1, x1, #0xffff
    9e3c:	9b0a7c21 	mul	x1, x1, x10
    9e40:	d360fc21 	lsr	x1, x1, #32
    9e44:	eb04003f 	cmp	x1, x4
    9e48:	540000a2 	b.cs	9e5c <fwp_hof0.constprop.0+0x3ec>  // b.hs, b.nlast
    9e4c:	8b010108 	add	x8, x8, x1
    9e50:	39400101 	ldrb	w1, [x8]
    9e54:	7100043f 	cmp	w1, #0x1
    9e58:	54001360 	b.eq	a0c4 <fwp_hof0.constprop.0+0x654>  // b.none
    9e5c:	f9400404 	ldr	x4, [x0, #8]
    9e60:	52800021 	mov	w1, #0x1                   	// #1
    9e64:	aa1903e0 	mov	x0, x25
    9e68:	d63f0080 	blr	x4
    9e6c:	f9400ee1 	ldr	x1, [x23, #24]
    9e70:	aa1b03e0 	mov	x0, x27
    9e74:	f9400021 	ldr	x1, [x1]
    9e78:	d63f0020 	blr	x1
    9e7c:	aa0003fb 	mov	x27, x0
    9e80:	f85d83a0 	ldur	x0, [x29, #-40]
    9e84:	9100001f 	mov	sp, x0
    9e88:	aa1903e0 	mov	x0, x25
    9e8c:	97fff115 	bl	62e0 <fwp_closure_drop>
    9e90:	6b13029f 	cmp	w20, w19
    9e94:	54fff381 	b.ne	9d04 <fwp_hof0.constprop.0+0x294>  // b.any
    9e98:	29771fb7 	ldp	w23, w7, [x29, #-72]
    9e9c:	aa1b03f9 	mov	x25, x27
    9ea0:	b85c03b8 	ldur	w24, [x29, #-64]
    9ea4:	6b17031f 	cmp	w24, w23
    9ea8:	540014c3 	b.cc	a140 <fwp_hof0.constprop.0+0x6d0>  // b.lo, b.ul, b.last
    9eac:	f85983a0 	ldur	x0, [x29, #-104]
    9eb0:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    9eb4:	f1000400 	subs	x0, x0, #0x1
    9eb8:	f81983a0 	stur	x0, [x29, #-104]
    9ebc:	54ffe5a1 	b.ne	9b70 <fwp_hof0.constprop.0+0x100>  // b.any
    9ec0:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe108>
    9ec4:	91104042 	add	x2, x2, #0x410
    9ec8:	aa1903e1 	mov	x1, x25
    9ecc:	aa1403e0 	mov	x0, x20
    9ed0:	aa1a03f8 	mov	x24, x26
    9ed4:	aa1903fb 	mov	x27, x25
    9ed8:	a978dfba 	ldp	x26, x23, [x29, #-120]
    9edc:	91014042 	add	x2, x2, #0x50
    9ee0:	52800023 	mov	w3, #0x1                   	// #1
    9ee4:	a93e7fbf 	stp	xzr, xzr, [x29, #-32]
    9ee8:	f81f03bf 	stur	xzr, [x29, #-16]
    9eec:	97fffae5 	bl	8a80 <fwp_write>
    9ef0:	a97e67b6 	ldp	x22, x25, [x29, #-32]
    9ef4:	90000020 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    9ef8:	91294000 	add	x0, x0, #0xa50
    9efc:	f10002df 	cmp	x22, #0x0
    9f00:	9a960016 	csel	x22, x0, x22, eq	// eq = none
    9f04:	b1002b3f 	cmn	x25, #0xa
    9f08:	54003cc8 	b.hi	a6a0 <fwp_hof0.constprop.0+0xc30>  // b.pmore
    9f0c:	91002720 	add	x0, x25, #0x9
    9f10:	52800021 	mov	w1, #0x1                   	// #1
    9f14:	97ffec5f 	bl	5090 <fwp_heap_alloc>
    9f18:	aa0003f3 	mov	x19, x0
    9f1c:	aa1603e1 	mov	x1, x22
    9f20:	aa0003f6 	mov	x22, x0
    9f24:	aa1903e2 	mov	x2, x25
    9f28:	f80086d9 	str	x25, [x22], #8
    9f2c:	8b190279 	add	x25, x19, x25
    9f30:	aa1603e0 	mov	x0, x22
    9f34:	97ffe1cb 	bl	2660 <memcpy@plt>
    9f38:	3900233f 	strb	wzr, [x25, #8]
    9f3c:	f85e03a0 	ldur	x0, [x29, #-32]
    9f40:	97ffe264 	bl	28d0 <free@plt>
    9f44:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9f48:	91190002 	add	x2, x0, #0x640
    9f4c:	f949d841 	ldr	x1, [x2, #5040]
    9f50:	f949ec40 	ldr	x0, [x2, #5080]
    9f54:	cb010261 	sub	x1, x19, x1
    9f58:	eb00403f 	cmp	x1, x0, lsl #16
    9f5c:	54000322 	b.cs	9fc0 <fwp_hof0.constprop.0+0x550>  // b.hs, b.nlast
    9f60:	d350fc20 	lsr	x0, x1, #16
    9f64:	f949fc43 	ldr	x3, [x2, #5112]
    9f68:	8b000800 	add	x0, x0, x0, lsl #2
    9f6c:	d37df002 	lsl	x2, x0, #3
    9f70:	8b020060 	add	x0, x3, x2
    9f74:	f9401019 	ldr	x25, [x0, #32]
    9f78:	b4000259 	cbz	x25, 9fc0 <fwp_hof0.constprop.0+0x550>
    9f7c:	38626862 	ldrb	w2, [x3, x2]
    9f80:	7100085f 	cmp	w2, #0x2
    9f84:	54003520 	b.eq	a628 <fwp_hof0.constprop.0+0xbb8>  // b.none
    9f88:	7100045f 	cmp	w2, #0x1
    9f8c:	540001a1 	b.ne	9fc0 <fwp_hof0.constprop.0+0x550>  // b.any
    9f90:	29430002 	ldp	w2, w0, [x0, #24]
    9f94:	92403c21 	and	x1, x1, #0xffff
    9f98:	9b027c21 	mul	x1, x1, x2
    9f9c:	d360fc21 	lsr	x1, x1, #32
    9fa0:	eb00003f 	cmp	x1, x0
    9fa4:	540000e2 	b.cs	9fc0 <fwp_hof0.constprop.0+0x550>  // b.hs, b.nlast
    9fa8:	8b010339 	add	x25, x25, x1
    9fac:	39400320 	ldrb	w0, [x25]
    9fb0:	7103fc1f 	cmp	w0, #0xff
    9fb4:	54003820 	b.eq	a6b8 <fwp_hof0.constprop.0+0xc48>  // b.none
    9fb8:	52800020 	mov	w0, #0x1                   	// #1
    9fbc:	39000320 	strb	w0, [x25]
    9fc0:	aa1b03e0 	mov	x0, x27
    9fc4:	97fff06b 	bl	6170 <fwp_drop0>
    9fc8:	f00000a0 	adrp	x0, 20000 <__data_start>
    9fcc:	91018003 	add	x3, x0, #0x60
    9fd0:	f9400262 	ldr	x2, [x19]
    9fd4:	aa1603e0 	mov	x0, x22
    9fd8:	aa0303f6 	mov	x22, x3
    9fdc:	d2800021 	mov	x1, #0x1                   	// #1
    9fe0:	f9404863 	ldr	x3, [x3, #144]
    9fe4:	97ffe24b 	bl	2910 <fwrite@plt>
    9fe8:	f9404ac1 	ldr	x1, [x22, #144]
    9fec:	52800140 	mov	w0, #0xa                   	// #10
    9ff0:	97ffe1d0 	bl	2730 <fputc@plt>
    9ff4:	90000380 	adrp	x0, 79000 <fwp_root_context+0xba0>
    9ff8:	91190002 	add	x2, x0, #0x640
    9ffc:	f949d841 	ldr	x1, [x2, #5040]
    a000:	f949ec40 	ldr	x0, [x2, #5080]
    a004:	cb010261 	sub	x1, x19, x1
    a008:	eb00403f 	cmp	x1, x0, lsl #16
    a00c:	54000382 	b.cs	a07c <fwp_hof0.constprop.0+0x60c>  // b.hs, b.nlast
    a010:	d350fc20 	lsr	x0, x1, #16
    a014:	f949fc43 	ldr	x3, [x2, #5112]
    a018:	8b000800 	add	x0, x0, x0, lsl #2
    a01c:	d37df000 	lsl	x0, x0, #3
    a020:	8b000062 	add	x2, x3, x0
    a024:	f9401056 	ldr	x22, [x2, #32]
    a028:	b40002b6 	cbz	x22, a07c <fwp_hof0.constprop.0+0x60c>
    a02c:	38606860 	ldrb	w0, [x3, x0]
    a030:	7100081f 	cmp	w0, #0x2
    a034:	54002f40 	b.eq	a61c <fwp_hof0.constprop.0+0xbac>  // b.none
    a038:	7100041f 	cmp	w0, #0x1
    a03c:	54000201 	b.ne	a07c <fwp_hof0.constprop.0+0x60c>  // b.any
    a040:	29430043 	ldp	w3, w0, [x2, #24]
    a044:	92403c21 	and	x1, x1, #0xffff
    a048:	9b037c21 	mul	x1, x1, x3
    a04c:	d360fc21 	lsr	x1, x1, #32
    a050:	eb00003f 	cmp	x1, x0
    a054:	54000142 	b.cs	a07c <fwp_hof0.constprop.0+0x60c>  // b.hs, b.nlast
    a058:	8b0102d6 	add	x22, x22, x1
    a05c:	394002c0 	ldrb	w0, [x22]
    a060:	340000e0 	cbz	w0, a07c <fwp_hof0.constprop.0+0x60c>
    a064:	7100041f 	cmp	w0, #0x1
    a068:	54002d00 	b.eq	a608 <fwp_hof0.constprop.0+0xb98>  // b.none
    a06c:	7103fc1f 	cmp	w0, #0xff
    a070:	54002e20 	b.eq	a634 <fwp_hof0.constprop.0+0xbc4>  // b.none
    a074:	51000400 	sub	w0, w0, #0x1
    a078:	390002c0 	strb	w0, [x22]
    a07c:	f9400b5a 	ldr	x26, [x26, #16]
    a080:	b5ffd27a 	cbnz	x26, 9acc <fwp_hof0.constprop.0+0x5c>
    a084:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    a088:	f947f400 	ldr	x0, [x0, #4072]
    a08c:	f85f83a2 	ldur	x2, [x29, #-8]
    a090:	f9400001 	ldr	x1, [x0]
    a094:	eb010042 	subs	x2, x2, x1
    a098:	d2800001 	mov	x1, #0x0                   	// #0
    a09c:	540030c1 	b.ne	a6b4 <fwp_hof0.constprop.0+0xc44>  // b.any
    a0a0:	910003bf 	mov	sp, x29
    a0a4:	d2800000 	mov	x0, #0x0                   	// #0
    a0a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    a0ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    a0b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    a0b4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    a0b8:	a94573fb 	ldp	x27, x28, [sp, #80]
    a0bc:	a8c67bfd 	ldp	x29, x30, [sp], #96
    a0c0:	d65f03c0 	ret
    a0c4:	b90004df 	str	wzr, [x6, #4]
    a0c8:	17ffff69 	b	9e6c <fwp_hof0.constprop.0+0x3fc>
    a0cc:	72003c3f 	tst	w1, #0xffff
    a0d0:	54ffec61 	b.ne	9e5c <fwp_hof0.constprop.0+0x3ec>  // b.any
    a0d4:	17ffff5f 	b	9e50 <fwp_hof0.constprop.0+0x3e0>
    a0d8:	aa1b03fc 	mov	x28, x27
    a0dc:	aa1803fb 	mov	x27, x24
    a0e0:	29771fb7 	ldp	w23, w7, [x29, #-72]
    a0e4:	b85c03b8 	ldur	w24, [x29, #-64]
    a0e8:	aa1c03e0 	mov	x0, x28
    a0ec:	b81d83a7 	stur	w7, [x29, #-40]
    a0f0:	97ffee98 	bl	5b50 <fwp_rc_share>
    a0f4:	b85d83a7 	ldur	w7, [x29, #-40]
    a0f8:	34000134 	cbz	w20, a11c <fwp_hof0.constprop.0+0x6ac>
    a0fc:	aa1b03f6 	mov	x22, x27
    a100:	8b344f73 	add	x19, x27, w20, uxtw #3
    a104:	2a0703f9 	mov	w25, w7
    a108:	f84086c0 	ldr	x0, [x22], #8
    a10c:	97ffee91 	bl	5b50 <fwp_rc_share>
    a110:	eb16027f 	cmp	x19, x22
    a114:	54ffffa1 	b.ne	a108 <fwp_hof0.constprop.0+0x698>  // b.any
    a118:	2a1903e7 	mov	w7, w25
    a11c:	aa1b03e2 	mov	x2, x27
    a120:	2a1403e1 	mov	w1, w20
    a124:	aa1c03e0 	mov	x0, x28
    a128:	b81d83a7 	stur	w7, [x29, #-40]
    a12c:	97ffec3a 	bl	5214 <fwp_apply>
    a130:	aa0003f9 	mov	x25, x0
    a134:	b85d83a7 	ldur	w7, [x29, #-40]
    a138:	6b17031f 	cmp	w24, w23
    a13c:	54ffeb82 	b.cs	9eac <fwp_hof0.constprop.0+0x43c>  // b.hs, b.nlast
    a140:	f9406aa1 	ldr	x1, [x21, #208]
    a144:	4b0702f7 	sub	w23, w23, w7
    a148:	b9400323 	ldr	w3, [x25]
    a14c:	f85d03a0 	ldur	x0, [x29, #-48]
    a150:	8b031423 	add	x3, x1, x3, lsl #5
    a154:	b85c83a2 	ldur	w2, [x29, #-56]
    a158:	8b274c00 	add	x0, x0, w7, uxtw #3
    a15c:	f81d03a0 	stur	x0, [x29, #-48]
    a160:	f9400c61 	ldr	x1, [x3, #24]
    a164:	b85cc3a0 	ldur	w0, [x29, #-52]
    a168:	4b020000 	sub	w0, w0, w2
    a16c:	b81cc3a0 	stur	w0, [x29, #-52]
    a170:	aa1903e0 	mov	x0, x25
    a174:	b5ffd741 	cbnz	x1, 9c5c <fwp_hof0.constprop.0+0x1ec>
    a178:	a97a6bb4 	ldp	x20, x26, [x29, #-96]
    a17c:	aa1903e0 	mov	x0, x25
    a180:	97ffee74 	bl	5b50 <fwp_rc_share>
    a184:	34000117 	cbz	w23, a1a4 <fwp_hof0.constprop.0+0x734>
    a188:	f85d03b8 	ldur	x24, [x29, #-48]
    a18c:	d2800016 	mov	x22, #0x0                   	// #0
    a190:	f8767b00 	ldr	x0, [x24, x22, lsl #3]
    a194:	910006d6 	add	x22, x22, #0x1
    a198:	97ffee6e 	bl	5b50 <fwp_rc_share>
    a19c:	6b1602ff 	cmp	w23, w22
    a1a0:	54ffff88 	b.hi	a190 <fwp_hof0.constprop.0+0x720>  // b.pmore
    a1a4:	f85d03a2 	ldur	x2, [x29, #-48]
    a1a8:	aa1903e0 	mov	x0, x25
    a1ac:	2a1703e1 	mov	w1, w23
    a1b0:	97ffec19 	bl	5214 <fwp_apply>
    a1b4:	aa0003f9 	mov	x25, x0
    a1b8:	f85983a0 	ldur	x0, [x29, #-104]
    a1bc:	f1000400 	subs	x0, x0, #0x1
    a1c0:	f81983a0 	stur	x0, [x29, #-104]
    a1c4:	54ffcd61 	b.ne	9b70 <fwp_hof0.constprop.0+0x100>  // b.any
    a1c8:	17ffff3e 	b	9ec0 <fwp_hof0.constprop.0+0x450>
    a1cc:	b94132ab 	ldr	w11, [x21, #304]
    a1d0:	110006c0 	add	w0, w22, #0x1
    a1d4:	aa1703fa 	mov	x26, x23
    a1d8:	aa1803fb 	mov	x27, x24
    a1dc:	29771fb7 	ldp	w23, w7, [x29, #-72]
    a1e0:	2a0103fc 	mov	w28, w1
    a1e4:	b85c03b8 	ldur	w24, [x29, #-64]
    a1e8:	d37df000 	lsl	x0, x0, #3
    a1ec:	340000ab 	cbz	w11, a200 <fwp_hof0.constprop.0+0x790>
    a1f0:	a95386a9 	ldp	x9, x1, [x21, #312]
    a1f4:	91000529 	add	x9, x9, #0x1
    a1f8:	8b000021 	add	x1, x1, x0
    a1fc:	a91386a9 	stp	x9, x1, [x21, #312]
    a200:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a204:	9119002a 	add	x10, x1, #0x640
    a208:	f140101f 	cmp	x0, #0x4, lsl #12
    a20c:	b953a541 	ldr	w1, [x10, #5028]
    a210:	7a409824 	ccmp	w1, #0x0, #0x4, ls	// ls = plast
    a214:	540019a0 	b.eq	a548 <fwp_hof0.constprop.0+0xad8>  // b.none
    a218:	91003c01 	add	x1, x0, #0xf
    a21c:	8b411141 	add	x1, x10, x1, lsr #4
    a220:	397e8021 	ldrb	w1, [x1, #4000]
    a224:	910f002c 	add	x12, x1, #0x3c0
    a228:	8b010429 	add	x9, x1, x1, lsl #1
    a22c:	b86c794c 	ldr	w12, [x10, x12, lsl #2]
    a230:	8b090d4d 	add	x13, x10, x9, lsl #3
    a234:	f8697953 	ldr	x19, [x10, x9, lsl #3]
    a238:	2a0c03e1 	mov	w1, w12
    a23c:	b4001753 	cbz	x19, a524 <fwp_hof0.constprop.0+0xab4>
    a240:	f940026d 	ldr	x13, [x19]
    a244:	aa2d03ed 	mvn	x13, x13
    a248:	f829794d 	str	x13, [x10, x9, lsl #3]
    a24c:	eb01001f 	cmp	x0, x1
    a250:	540000c2 	b.cs	a268 <fwp_hof0.constprop.0+0x7f8>  // b.hs, b.nlast
    a254:	d503201f 	nop
    a258:	f8206a7f 	str	xzr, [x19, x0]
    a25c:	91002000 	add	x0, x0, #0x8
    a260:	eb00003f 	cmp	x1, x0
    a264:	54ffffa8 	b.hi	a258 <fwp_hof0.constprop.0+0x7e8>  // b.pmore
    a268:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a26c:	91190009 	add	x9, x0, #0x640
    a270:	f94a1120 	ldr	x0, [x9, #5152]
    a274:	ab010000 	adds	x0, x0, x1
    a278:	540020c2 	b.cs	a690 <fwp_hof0.constprop.0+0xc20>  // b.hs, b.nlast
    a27c:	f94a1521 	ldr	x1, [x9, #5160]
    a280:	f90a1120 	str	x0, [x9, #5152]
    a284:	eb01001f 	cmp	x0, x1
    a288:	54000049 	b.ls	a290 <fwp_hof0.constprop.0+0x820>  // b.plast
    a28c:	f90a1520 	str	x0, [x9, #5160]
    a290:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a294:	91190000 	add	x0, x0, #0x640
    a298:	1e630181 	ucvtf	d1, w12
    a29c:	fd4a1c00 	ldr	d0, [x0, #5176]
    a2a0:	1e612800 	fadd	d0, d0, d1
    a2a4:	fd0a1c00 	str	d0, [x0, #5176]
    a2a8:	3400012b 	cbz	w11, a2cc <fwp_hof0.constprop.0+0x85c>
    a2ac:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a2b0:	91190000 	add	x0, x0, #0x640
    a2b4:	6d5486a2 	ldp	d2, d1, [x21, #328]
    a2b8:	fd4a1000 	ldr	d0, [x0, #5152]
    a2bc:	7e61d800 	ucvtf	d0, d0
    a2c0:	1e623800 	fsub	d0, d0, d2
    a2c4:	1e612010 	fcmpe	d0, d1
    a2c8:	540016ec 	b.gt	a5a4 <fwp_hof0.constprop.0+0xb34>
    a2cc:	b94000c0 	ldr	w0, [x6]
    a2d0:	29005a60 	stp	w0, w22, [x19]
    a2d4:	3400013c 	cbz	w28, a2f8 <fwp_hof0.constprop.0+0x888>
    a2d8:	910020c1 	add	x1, x6, #0x8
    a2dc:	d37d7f82 	ubfiz	x2, x28, #3, #32
    a2e0:	91002260 	add	x0, x19, #0x8
    a2e4:	b81c03a7 	stur	w7, [x29, #-64]
    a2e8:	f81d83a6 	stur	x6, [x29, #-40]
    a2ec:	97ffe0e5 	bl	2680 <memmove@plt>
    a2f0:	f85d83a6 	ldur	x6, [x29, #-40]
    a2f4:	b85c03a7 	ldur	w7, [x29, #-64]
    a2f8:	2a1403e9 	mov	w9, w20
    a2fc:	d2800001 	mov	x1, #0x0                   	// #0
    a300:	34000134 	cbz	w20, a324 <fwp_hof0.constprop.0+0x8b4>
    a304:	d503201f 	nop
    a308:	0b010380 	add	w0, w28, w1
    a30c:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    a310:	8b000e60 	add	x0, x19, x0, lsl #3
    a314:	91000421 	add	x1, x1, #0x1
    a318:	f9000402 	str	x2, [x0, #8]
    a31c:	eb01013f 	cmp	x9, x1
    a320:	54ffff41 	b.ne	a308 <fwp_hof0.constprop.0+0x898>  // b.any
    a324:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a328:	91190002 	add	x2, x0, #0x640
    a32c:	f949d840 	ldr	x0, [x2, #5040]
    a330:	f949ec41 	ldr	x1, [x2, #5080]
    a334:	cb000320 	sub	x0, x25, x0
    a338:	eb01401f 	cmp	x0, x1, lsl #16
    a33c:	540002e2 	b.cs	a398 <fwp_hof0.constprop.0+0x928>  // b.hs, b.nlast
    a340:	d350fc01 	lsr	x1, x0, #16
    a344:	f949fc45 	ldr	x5, [x2, #5112]
    a348:	8b010821 	add	x1, x1, x1, lsl #2
    a34c:	d37df021 	lsl	x1, x1, #3
    a350:	8b0100a4 	add	x4, x5, x1
    a354:	f9401082 	ldr	x2, [x4, #32]
    a358:	b4000202 	cbz	x2, a398 <fwp_hof0.constprop.0+0x928>
    a35c:	386168a1 	ldrb	w1, [x5, x1]
    a360:	7100083f 	cmp	w1, #0x2
    a364:	54001060 	b.eq	a570 <fwp_hof0.constprop.0+0xb00>  // b.none
    a368:	7100043f 	cmp	w1, #0x1
    a36c:	54000161 	b.ne	a398 <fwp_hof0.constprop.0+0x928>  // b.any
    a370:	29430485 	ldp	w5, w1, [x4, #24]
    a374:	92403c00 	and	x0, x0, #0xffff
    a378:	9b057c00 	mul	x0, x0, x5
    a37c:	d360fc00 	lsr	x0, x0, #32
    a380:	eb01001f 	cmp	x0, x1
    a384:	540000a2 	b.cs	a398 <fwp_hof0.constprop.0+0x928>  // b.hs, b.nlast
    a388:	8b000042 	add	x2, x2, x0
    a38c:	39400040 	ldrb	w0, [x2]
    a390:	7100041f 	cmp	w0, #0x1
    a394:	54000be0 	b.eq	a510 <fwp_hof0.constprop.0+0xaa0>  // b.none
    a398:	f9400f42 	ldr	x2, [x26, #24]
    a39c:	aa1903e0 	mov	x0, x25
    a3a0:	52800021 	mov	w1, #0x1                   	// #1
    a3a4:	b81d83a7 	stur	w7, [x29, #-40]
    a3a8:	f9400442 	ldr	x2, [x2, #8]
    a3ac:	d63f0040 	blr	x2
    a3b0:	b85d83a7 	ldur	w7, [x29, #-40]
    a3b4:	f0000360 	adrp	x0, 79000 <fwp_root_context+0xba0>
    a3b8:	91190002 	add	x2, x0, #0x640
    a3bc:	f949d841 	ldr	x1, [x2, #5040]
    a3c0:	f949ec40 	ldr	x0, [x2, #5080]
    a3c4:	cb010261 	sub	x1, x19, x1
    a3c8:	eb00403f 	cmp	x1, x0, lsl #16
    a3cc:	54000322 	b.cs	a430 <fwp_hof0.constprop.0+0x9c0>  // b.hs, b.nlast
    a3d0:	d350fc20 	lsr	x0, x1, #16
    a3d4:	f949fc43 	ldr	x3, [x2, #5112]
    a3d8:	8b000800 	add	x0, x0, x0, lsl #2
    a3dc:	d37df002 	lsl	x2, x0, #3
    a3e0:	8b020060 	add	x0, x3, x2
    a3e4:	f9401014 	ldr	x20, [x0, #32]
    a3e8:	b4000254 	cbz	x20, a430 <fwp_hof0.constprop.0+0x9c0>
    a3ec:	38626862 	ldrb	w2, [x3, x2]
    a3f0:	7100085f 	cmp	w2, #0x2
    a3f4:	54000c40 	b.eq	a57c <fwp_hof0.constprop.0+0xb0c>  // b.none
    a3f8:	7100045f 	cmp	w2, #0x1
    a3fc:	540001a1 	b.ne	a430 <fwp_hof0.constprop.0+0x9c0>  // b.any
    a400:	29430002 	ldp	w2, w0, [x0, #24]
    a404:	92403c21 	and	x1, x1, #0xffff
    a408:	9b027c21 	mul	x1, x1, x2
    a40c:	d360fc21 	lsr	x1, x1, #32
    a410:	eb00003f 	cmp	x1, x0
    a414:	540000e2 	b.cs	a430 <fwp_hof0.constprop.0+0x9c0>  // b.hs, b.nlast
    a418:	8b010294 	add	x20, x20, x1
    a41c:	39400280 	ldrb	w0, [x20]
    a420:	7103fc1f 	cmp	w0, #0xff
    a424:	54000b60 	b.eq	a590 <fwp_hof0.constprop.0+0xb20>  // b.none
    a428:	52800020 	mov	w0, #0x1                   	// #1
    a42c:	39000280 	strb	w0, [x20]
    a430:	aa1903e0 	mov	x0, x25
    a434:	b81d83a7 	stur	w7, [x29, #-40]
    a438:	97ffefaa 	bl	62e0 <fwp_closure_drop>
    a43c:	aa1303f9 	mov	x25, x19
    a440:	b85d83a7 	ldur	w7, [x29, #-40]
    a444:	17ffff3d 	b	a138 <fwp_hof0.constprop.0+0x6c8>
    a448:	b8626860 	ldr	w0, [x3, x2]
    a44c:	b94004a2 	ldr	w2, [x5, #4]
    a450:	4b020003 	sub	w3, w0, w2
    a454:	7100047f 	cmp	w3, #0x1
    a458:	54ffba41 	b.ne	9ba0 <fwp_hof0.constprop.0+0x130>  // b.any
    a45c:	910003f6 	mov	x22, sp
    a460:	34000aa2 	cbz	w2, a5b4 <fwp_hof0.constprop.0+0xb44>
    a464:	7100001f 	cmp	w0, #0x0
    a468:	d37d7c00 	ubfiz	x0, x0, #3, #32
    a46c:	d2800101 	mov	x1, #0x8                   	// #8
    a470:	9a811017 	csel	x23, x0, x1, ne	// ne = any
    a474:	91003ee0 	add	x0, x23, #0xf
    a478:	92704c01 	and	x1, x0, #0xfffff0000
    a47c:	927c7c00 	and	x0, x0, #0xffffffff0
    a480:	cb2163e1 	sub	x1, sp, x1
    a484:	eb2163ff 	cmp	sp, x1
    a488:	540000a0 	b.eq	a49c <fwp_hof0.constprop.0+0xa2c>  // b.none
    a48c:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    a490:	f90203ff 	str	xzr, [sp, #1024]
    a494:	eb2163ff 	cmp	sp, x1
    a498:	54ffffa1 	b.ne	a48c <fwp_hof0.constprop.0+0xa1c>  // b.any
    a49c:	92403c00 	and	x0, x0, #0xffff
    a4a0:	cb2063ff 	sub	sp, sp, x0
    a4a4:	f90003ff 	str	xzr, [sp]
    a4a8:	f110001f 	cmp	x0, #0x400
    a4ac:	54000043 	b.cc	a4b4 <fwp_hof0.constprop.0+0xa44>  // b.lo, b.ul, b.last
    a4b0:	f90203ff 	str	xzr, [sp, #1024]
    a4b4:	d37d7c5c 	ubfiz	x28, x2, #3, #32
    a4b8:	910043f8 	add	x24, sp, #0x10
    a4bc:	d00000a0 	adrp	x0, 20000 <__data_start>
    a4c0:	91004001 	add	x1, x0, #0x10
    a4c4:	aa1c03e2 	mov	x2, x28
    a4c8:	9100c021 	add	x1, x1, #0x30
    a4cc:	aa1703e3 	mov	x3, x23
    a4d0:	aa1803e0 	mov	x0, x24
    a4d4:	97ffe0a3 	bl	2760 <__memcpy_chk@plt>
    a4d8:	eb1c02ff 	cmp	x23, x28
    a4dc:	aa1403e1 	mov	x1, x20
    a4e0:	9a9c22e3 	csel	x3, x23, x28, cs	// cs = hs, nlast
    a4e4:	d2800102 	mov	x2, #0x8                   	// #8
    a4e8:	cb1c0063 	sub	x3, x3, x28
    a4ec:	8b1c0300 	add	x0, x24, x28
    a4f0:	97ffe09c 	bl	2760 <__memcpy_chk@plt>
    a4f4:	f9400f61 	ldr	x1, [x27, #24]
    a4f8:	aa1803e0 	mov	x0, x24
    a4fc:	f9400021 	ldr	x1, [x1]
    a500:	d63f0020 	blr	x1
    a504:	aa0003f9 	mov	x25, x0
    a508:	910002df 	mov	sp, x22
    a50c:	17ffff2b 	b	a1b8 <fwp_hof0.constprop.0+0x748>
    a510:	b90004df 	str	wzr, [x6, #4]
    a514:	17ffffa8 	b	a3b4 <fwp_hof0.constprop.0+0x944>
    a518:	72003c3f 	tst	w1, #0xffff
    a51c:	54ffb8c1 	b.ne	9c34 <fwp_hof0.constprop.0+0x1c4>  // b.any
    a520:	17fffdba 	b	9c08 <fwp_hof0.constprop.0+0x198>
    a524:	f94005b3 	ldr	x19, [x13, #8]
    a528:	b4000113 	cbz	x19, a548 <fwp_hof0.constprop.0+0xad8>
    a52c:	f94009a9 	ldr	x9, [x13, #16]
    a530:	cb130129 	sub	x9, x9, x19
    a534:	eb09003f 	cmp	x1, x9
    a538:	54000088 	b.hi	a548 <fwp_hof0.constprop.0+0xad8>  // b.pmore
    a53c:	8b010269 	add	x9, x19, x1
    a540:	f90005a9 	str	x9, [x13, #8]
    a544:	17ffff42 	b	a24c <fwp_hof0.constprop.0+0x7dc>
    a548:	52800001 	mov	w1, #0x0                   	// #0
    a54c:	b81bc3ab 	stur	w11, [x29, #-68]
    a550:	f81c03a6 	stur	x6, [x29, #-64]
    a554:	b81d83a7 	stur	w7, [x29, #-40]
    a558:	97ffeace 	bl	5090 <fwp_heap_alloc>
    a55c:	f85c03a6 	ldur	x6, [x29, #-64]
    a560:	aa0003f3 	mov	x19, x0
    a564:	b85bc3ab 	ldur	w11, [x29, #-68]
    a568:	b85d83a7 	ldur	w7, [x29, #-40]
    a56c:	17ffff4f 	b	a2a8 <fwp_hof0.constprop.0+0x838>
    a570:	72003c1f 	tst	w0, #0xffff
    a574:	54fff121 	b.ne	a398 <fwp_hof0.constprop.0+0x928>  // b.any
    a578:	17ffff85 	b	a38c <fwp_hof0.constprop.0+0x91c>
    a57c:	72003c3f 	tst	w1, #0xffff
    a580:	54fff581 	b.ne	a430 <fwp_hof0.constprop.0+0x9c0>  // b.any
    a584:	39400280 	ldrb	w0, [x20]
    a588:	7103fc1f 	cmp	w0, #0xff
    a58c:	54fff4e1 	b.ne	a428 <fwp_hof0.constprop.0+0x9b8>  // b.any
    a590:	aa1403e0 	mov	x0, x20
    a594:	b81d83a7 	stur	w7, [x29, #-40]
    a598:	97ffe8fe 	bl	4990 <fwp_rc_forget_slot>
    a59c:	b85d83a7 	ldur	w7, [x29, #-40]
    a5a0:	17ffffa2 	b	a428 <fwp_hof0.constprop.0+0x9b8>
    a5a4:	fd00aaa0 	str	d0, [x21, #336]
    a5a8:	17ffff49 	b	a2cc <fwp_hof0.constprop.0+0x85c>
    a5ac:	97ffe8b2 	bl	4874 <fwp_rc_wide_dup>
    a5b0:	17fffda1 	b	9c34 <fwp_hof0.constprop.0+0x1c4>
    a5b4:	f9400021 	ldr	x1, [x1]
    a5b8:	aa1403e0 	mov	x0, x20
    a5bc:	d63f0020 	blr	x1
    a5c0:	aa0003f9 	mov	x25, x0
    a5c4:	910002df 	mov	sp, x22
    a5c8:	17fffefc 	b	a1b8 <fwp_hof0.constprop.0+0x748>
    a5cc:	72003c3f 	tst	w1, #0xffff
    a5d0:	54ffac61 	b.ne	9b5c <fwp_hof0.constprop.0+0xec>  // b.any
    a5d4:	17fffd58 	b	9b34 <fwp_hof0.constprop.0+0xc4>
    a5d8:	aa1a03e0 	mov	x0, x26
    a5dc:	97ffed5d 	bl	5b50 <fwp_rc_share>
    a5e0:	aa1903e0 	mov	x0, x25
    a5e4:	52800037 	mov	w23, #0x1                   	// #1
    a5e8:	97ffed5a 	bl	5b50 <fwp_rc_share>
    a5ec:	aa1a03f9 	mov	x25, x26
    a5f0:	f81d03b4 	stur	x20, [x29, #-48]
    a5f4:	17fffeec 	b	a1a4 <fwp_hof0.constprop.0+0x734>
    a5f8:	f940ac43 	ldr	x3, [x2, #344]
    a5fc:	91000463 	add	x3, x3, #0x1
    a600:	f900ac43 	str	x3, [x2, #344]
    a604:	17fffd52 	b	9b4c <fwp_hof0.constprop.0+0xdc>
    a608:	aa1303e0 	mov	x0, x19
    a60c:	97ffeda6 	bl	5ca4 <fwp_rc_free_arr>
    a610:	f9400b5a 	ldr	x26, [x26, #16]
    a614:	b5ffa5da 	cbnz	x26, 9acc <fwp_hof0.constprop.0+0x5c>
    a618:	17fffe9b 	b	a084 <fwp_hof0.constprop.0+0x614>
    a61c:	72003c3f 	tst	w1, #0xffff
    a620:	54ffd2e1 	b.ne	a07c <fwp_hof0.constprop.0+0x60c>  // b.any
    a624:	17fffe8e 	b	a05c <fwp_hof0.constprop.0+0x5ec>
    a628:	72003c3f 	tst	w1, #0xffff
    a62c:	54ffcca1 	b.ne	9fc0 <fwp_hof0.constprop.0+0x550>  // b.any
    a630:	17fffe5f 	b	9fac <fwp_hof0.constprop.0+0x53c>
    a634:	ca5646c0 	eor	x0, x22, x22, lsr #17
    a638:	f0000361 	adrp	x1, 79000 <fwp_root_context+0xba0>
    a63c:	91190021 	add	x1, x1, #0x640
    a640:	ca402400 	eor	x0, x0, x0, lsr #9
    a644:	8b200c20 	add	x0, x1, w0, uxtb #3
    a648:	f94a2400 	ldr	x0, [x0, #5192]
    a64c:	b5000080 	cbnz	x0, a65c <fwp_hof0.constprop.0+0xbec>
    a650:	14000011 	b	a694 <fwp_hof0.constprop.0+0xc24>
    a654:	f9400800 	ldr	x0, [x0, #16]
    a658:	b40001e0 	cbz	x0, a694 <fwp_hof0.constprop.0+0xc24>
    a65c:	f9400001 	ldr	x1, [x0]
    a660:	eb16003f 	cmp	x1, x22
    a664:	54ffff81 	b.ne	a654 <fwp_hof0.constprop.0+0xbe4>  // b.any
    a668:	f9400401 	ldr	x1, [x0, #8]
    a66c:	d1000421 	sub	x1, x1, #0x1
    a670:	f9000401 	str	x1, [x0, #8]
    a674:	f103f83f 	cmp	x1, #0xfe
    a678:	54ffd021 	b.ne	a07c <fwp_hof0.constprop.0+0x60c>  // b.any
    a67c:	aa1603e0 	mov	x0, x22
    a680:	97ffe8c4 	bl	4990 <fwp_rc_forget_slot>
    a684:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a688:	390002c0 	strb	w0, [x22]
    a68c:	17fffe7c 	b	a07c <fwp_hof0.constprop.0+0x60c>
    a690:	97ffe298 	bl	30f0 <fwp_heap_oom>
    a694:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x2d0>
    a698:	913b4000 	add	x0, x0, #0xed0
    a69c:	97ffe439 	bl	3780 <fwp_trap>
    a6a0:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    a6a4:	9107a000 	add	x0, x0, #0x1e8
    a6a8:	97ffe436 	bl	3780 <fwp_trap>
    a6ac:	97ffe872 	bl	4874 <fwp_rc_wide_dup>
    a6b0:	17fffd2b 	b	9b5c <fwp_hof0.constprop.0+0xec>
    a6b4:	97ffe057 	bl	2810 <__stack_chk_fail@plt>
    a6b8:	aa1903e0 	mov	x0, x25
    a6bc:	97ffe8b5 	bl	4990 <fwp_rc_forget_slot>
    a6c0:	17fffe3e 	b	9fb8 <fwp_hof0.constprop.0+0x548>

000000000000a6c4 <f0>:
    a6c4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a6c8:	910003fd 	mov	x29, sp
    a6cc:	a90153f3 	stp	x19, x20, [sp, #16]
    a6d0:	a9025bf5 	stp	x21, x22, [sp, #32]
    a6d4:	a90363f7 	stp	x23, x24, [sp, #48]
    a6d8:	a9046bf9 	stp	x25, x26, [sp, #64]
    a6dc:	a90573fb 	stp	x27, x28, [sp, #80]
    a6e0:	d12183ff 	sub	sp, sp, #0x860
    a6e4:	f90203ff 	str	xzr, [sp, #1024]
    a6e8:	d00000a0 	adrp	x0, 20000 <__data_start>
    a6ec:	91018005 	add	x5, x0, #0x60
    a6f0:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    a6f4:	f947f400 	ldr	x0, [x0, #4072]
    a6f8:	f0000374 	adrp	x20, 79000 <fwp_root_context+0xba0>
    a6fc:	f941c8a6 	ldr	x6, [x5, #912]
    a700:	f9400001 	ldr	x1, [x0]
    a704:	f9042fe1 	str	x1, [sp, #2136]
    a708:	d2800001 	mov	x1, #0x0                   	// #0
    a70c:	91190298 	add	x24, x20, #0x640
    a710:	912123f6 	add	x22, sp, #0x848
    a714:	910023e0 	add	x0, sp, #0x8
    a718:	910083e2 	add	x2, sp, #0x20
    a71c:	90ffffe1 	adrp	x1, 6000 <e161+0x100>
    a720:	90ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    a724:	91008021 	add	x1, x1, #0x20
    a728:	913b4084 	add	x4, x4, #0xed0
    a72c:	d2800013 	mov	x19, #0x0                   	// #0
    a730:	d2800119 	mov	x25, #0x8                   	// #8
    a734:	d2800015 	mov	x21, #0x0                   	// #0
    a738:	52800037 	mov	w23, #0x1                   	// #1
    a73c:	a90093e6 	stp	x6, x4, [sp, #8]
    a740:	a901ffe2 	stp	x2, xzr, [sp, #24]
    a744:	a90307ff 	stp	xzr, x1, [sp, #48]
    a748:	f901c8a0 	str	x0, [x5, #912]
    a74c:	d503201f 	nop
    a750:	f100073a 	subs	x26, x25, #0x1
    a754:	aa1603e1 	mov	x1, x22
    a758:	da1f02bc 	sbc	x28, x21, xzr
    a75c:	52800020 	mov	w0, #0x1                   	// #1
    a760:	f90017fa 	str	x26, [sp, #40]
    a764:	aa1a03f9 	mov	x25, x26
    a768:	f90427fa 	str	x26, [sp, #2120]
    a76c:	aa1c03f5 	mov	x21, x28
    a770:	f9042bf3 	str	x19, [sp, #2128]
    a774:	97ffec98 	bl	59d4 <fwp_data.part.0.constprop.0>
    a778:	f949db02 	ldr	x2, [x24, #5040]
    a77c:	aa0003f3 	mov	x19, x0
    a780:	f949ef00 	ldr	x0, [x24, #5080]
    a784:	cb020262 	sub	x2, x19, x2
    a788:	eb00405f 	cmp	x2, x0, lsl #16
    a78c:	54000302 	b.cs	a7ec <f0+0x128>  // b.hs, b.nlast
    a790:	d350fc40 	lsr	x0, x2, #16
    a794:	f949ff04 	ldr	x4, [x24, #5112]
    a798:	8b000800 	add	x0, x0, x0, lsl #2
    a79c:	d37df001 	lsl	x1, x0, #3
    a7a0:	8b010080 	add	x0, x4, x1
    a7a4:	f940101b 	ldr	x27, [x0, #32]
    a7a8:	b400023b 	cbz	x27, a7ec <f0+0x128>
    a7ac:	38616881 	ldrb	w1, [x4, x1]
    a7b0:	7100083f 	cmp	w1, #0x2
    a7b4:	54010de0 	b.eq	c970 <f0+0x22ac>  // b.none
    a7b8:	7100043f 	cmp	w1, #0x1
    a7bc:	54000181 	b.ne	a7ec <f0+0x128>  // b.any
    a7c0:	29430001 	ldp	w1, w0, [x0, #24]
    a7c4:	92403c42 	and	x2, x2, #0xffff
    a7c8:	9b017c42 	mul	x2, x2, x1
    a7cc:	d360fc42 	lsr	x2, x2, #32
    a7d0:	eb00005f 	cmp	x2, x0
    a7d4:	540000c2 	b.cs	a7ec <f0+0x128>  // b.hs, b.nlast
    a7d8:	8b02037b 	add	x27, x27, x2
    a7dc:	39400360 	ldrb	w0, [x27]
    a7e0:	7103fc1f 	cmp	w0, #0xff
    a7e4:	54010c00 	b.eq	c964 <f0+0x22a0>  // b.none
    a7e8:	39000377 	strb	w23, [x27]
    a7ec:	f90013f3 	str	x19, [sp, #32]
    a7f0:	aa1c035a 	orr	x26, x26, x28
    a7f4:	b5fffafa 	cbnz	x26, a750 <f0+0x8c>
    a7f8:	90000020 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    a7fc:	910103e1 	add	x1, sp, #0x40
    a800:	f94007e2 	ldr	x2, [sp, #8]
    a804:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a808:	3dc27400 	ldr	q0, [x0, #2512]
    a80c:	d00000a0 	adrp	x0, 20000 <__data_start>
    a810:	91018018 	add	x24, x0, #0x60
    a814:	52800020 	mov	w0, #0x1                   	// #1
    a818:	3d8013e0 	str	q0, [sp, #64]
    a81c:	f901cb02 	str	x2, [x24, #912]
    a820:	97ffec6d 	bl	59d4 <fwp_data.part.0.constprop.0>
    a824:	97ffecf0 	bl	5be4 <fwp_rc_fresh>
    a828:	aa0003e2 	mov	x2, x0
    a82c:	910163e1 	add	x1, sp, #0x58
    a830:	52800020 	mov	w0, #0x1                   	// #1
    a834:	a9058bf5 	stp	x21, x2, [sp, #88]
    a838:	97ffec67 	bl	59d4 <fwp_data.part.0.constprop.0>
    a83c:	97ffecea 	bl	5be4 <fwp_rc_fresh>
    a840:	aa0003e2 	mov	x2, x0
    a844:	90000023 	adrp	x3, e000 <_IO_stdin_used+0x5f0>
    a848:	9101a3e1 	add	x1, sp, #0x68
    a84c:	52800020 	mov	w0, #0x1                   	// #1
    a850:	f9003be2 	str	x2, [sp, #112]
    a854:	3dc27460 	ldr	q0, [x3, #2512]
    a858:	fd0037e0 	str	d0, [sp, #104]
    a85c:	97ffec5e 	bl	59d4 <fwp_data.part.0.constprop.0>
    a860:	97ffece1 	bl	5be4 <fwp_rc_fresh>
    a864:	aa0003e2 	mov	x2, x0
    a868:	9101e3e1 	add	x1, sp, #0x78
    a86c:	52800020 	mov	w0, #0x1                   	// #1
    a870:	a9078bf5 	stp	x21, x2, [sp, #120]
    a874:	97ffec58 	bl	59d4 <fwp_data.part.0.constprop.0>
    a878:	91190283 	add	x3, x20, #0x640
    a87c:	aa0003f5 	mov	x21, x0
    a880:	f949d861 	ldr	x1, [x3, #5040]
    a884:	f949ec60 	ldr	x0, [x3, #5080]
    a888:	cb0102a1 	sub	x1, x21, x1
    a88c:	eb00403f 	cmp	x1, x0, lsl #16
    a890:	54000322 	b.cs	a8f4 <f0+0x230>  // b.hs, b.nlast
    a894:	d350fc22 	lsr	x2, x1, #16
    a898:	f949fc63 	ldr	x3, [x3, #5112]
    a89c:	8b020842 	add	x2, x2, x2, lsl #2
    a8a0:	d37df042 	lsl	x2, x2, #3
    a8a4:	8b020060 	add	x0, x3, x2
    a8a8:	f9401017 	ldr	x23, [x0, #32]
    a8ac:	b4000257 	cbz	x23, a8f4 <f0+0x230>
    a8b0:	38626862 	ldrb	w2, [x3, x2]
    a8b4:	7100085f 	cmp	w2, #0x2
    a8b8:	540109e0 	b.eq	c9f4 <f0+0x2330>  // b.none
    a8bc:	7100045f 	cmp	w2, #0x1
    a8c0:	540001a1 	b.ne	a8f4 <f0+0x230>  // b.any
    a8c4:	29430002 	ldp	w2, w0, [x0, #24]
    a8c8:	92403c21 	and	x1, x1, #0xffff
    a8cc:	9b027c21 	mul	x1, x1, x2
    a8d0:	d360fc21 	lsr	x1, x1, #32
    a8d4:	eb00003f 	cmp	x1, x0
    a8d8:	540000e2 	b.cs	a8f4 <f0+0x230>  // b.hs, b.nlast
    a8dc:	8b0102f7 	add	x23, x23, x1
    a8e0:	394002e0 	ldrb	w0, [x23]
    a8e4:	7103fc1f 	cmp	w0, #0xff
    a8e8:	540113a0 	b.eq	cb5c <f0+0x2498>  // b.none
    a8ec:	52800020 	mov	w0, #0x1                   	// #1
    a8f0:	390002e0 	strb	w0, [x23]
    a8f4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a8f8:	910223e1 	add	x1, sp, #0x88
    a8fc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a900:	52800020 	mov	w0, #0x1                   	// #1
    a904:	a908d7e2 	stp	x2, x21, [sp, #136]
    a908:	97ffec33 	bl	59d4 <fwp_data.part.0.constprop.0>
    a90c:	91190283 	add	x3, x20, #0x640
    a910:	aa0003f5 	mov	x21, x0
    a914:	f949d861 	ldr	x1, [x3, #5040]
    a918:	f949ec60 	ldr	x0, [x3, #5080]
    a91c:	cb0102a1 	sub	x1, x21, x1
    a920:	eb00403f 	cmp	x1, x0, lsl #16
    a924:	54000322 	b.cs	a988 <f0+0x2c4>  // b.hs, b.nlast
    a928:	d350fc22 	lsr	x2, x1, #16
    a92c:	f949fc63 	ldr	x3, [x3, #5112]
    a930:	8b020842 	add	x2, x2, x2, lsl #2
    a934:	d37df042 	lsl	x2, x2, #3
    a938:	8b020060 	add	x0, x3, x2
    a93c:	f9401017 	ldr	x23, [x0, #32]
    a940:	b4000257 	cbz	x23, a988 <f0+0x2c4>
    a944:	38626862 	ldrb	w2, [x3, x2]
    a948:	7100085f 	cmp	w2, #0x2
    a94c:	540104e0 	b.eq	c9e8 <f0+0x2324>  // b.none
    a950:	7100045f 	cmp	w2, #0x1
    a954:	540001a1 	b.ne	a988 <f0+0x2c4>  // b.any
    a958:	29430002 	ldp	w2, w0, [x0, #24]
    a95c:	92403c21 	and	x1, x1, #0xffff
    a960:	9b027c21 	mul	x1, x1, x2
    a964:	d360fc21 	lsr	x1, x1, #32
    a968:	eb00003f 	cmp	x1, x0
    a96c:	540000e2 	b.cs	a988 <f0+0x2c4>  // b.hs, b.nlast
    a970:	8b0102f7 	add	x23, x23, x1
    a974:	394002e0 	ldrb	w0, [x23]
    a978:	7103fc1f 	cmp	w0, #0xff
    a97c:	54010f60 	b.eq	cb68 <f0+0x24a4>  // b.none
    a980:	52800020 	mov	w0, #0x1                   	// #1
    a984:	390002e0 	strb	w0, [x23]
    a988:	910263e1 	add	x1, sp, #0x98
    a98c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a990:	52800020 	mov	w0, #0x1                   	// #1
    a994:	a909d7e2 	stp	x2, x21, [sp, #152]
    a998:	97ffec0f 	bl	59d4 <fwp_data.part.0.constprop.0>
    a99c:	97ffec92 	bl	5be4 <fwp_rc_fresh>
    a9a0:	aa0003e2 	mov	x2, x0
    a9a4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a9a8:	9102a3e1 	add	x1, sp, #0xa8
    a9ac:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a9b0:	52800020 	mov	w0, #0x1                   	// #1
    a9b4:	a90a8be3 	stp	x3, x2, [sp, #168]
    a9b8:	97ffec07 	bl	59d4 <fwp_data.part.0.constprop.0>
    a9bc:	91190283 	add	x3, x20, #0x640
    a9c0:	aa0003f5 	mov	x21, x0
    a9c4:	f949d861 	ldr	x1, [x3, #5040]
    a9c8:	f949ec60 	ldr	x0, [x3, #5080]
    a9cc:	cb0102a1 	sub	x1, x21, x1
    a9d0:	eb00403f 	cmp	x1, x0, lsl #16
    a9d4:	54000322 	b.cs	aa38 <f0+0x374>  // b.hs, b.nlast
    a9d8:	d350fc22 	lsr	x2, x1, #16
    a9dc:	f949fc63 	ldr	x3, [x3, #5112]
    a9e0:	8b020842 	add	x2, x2, x2, lsl #2
    a9e4:	d37df042 	lsl	x2, x2, #3
    a9e8:	8b020060 	add	x0, x3, x2
    a9ec:	f9401017 	ldr	x23, [x0, #32]
    a9f0:	b4000257 	cbz	x23, aa38 <f0+0x374>
    a9f4:	38626862 	ldrb	w2, [x3, x2]
    a9f8:	7100085f 	cmp	w2, #0x2
    a9fc:	5400ff00 	b.eq	c9dc <f0+0x2318>  // b.none
    aa00:	7100045f 	cmp	w2, #0x1
    aa04:	540001a1 	b.ne	aa38 <f0+0x374>  // b.any
    aa08:	29430002 	ldp	w2, w0, [x0, #24]
    aa0c:	92403c21 	and	x1, x1, #0xffff
    aa10:	9b027c21 	mul	x1, x1, x2
    aa14:	d360fc21 	lsr	x1, x1, #32
    aa18:	eb00003f 	cmp	x1, x0
    aa1c:	540000e2 	b.cs	aa38 <f0+0x374>  // b.hs, b.nlast
    aa20:	8b0102f7 	add	x23, x23, x1
    aa24:	394002e0 	ldrb	w0, [x23]
    aa28:	7103fc1f 	cmp	w0, #0xff
    aa2c:	54010a40 	b.eq	cb74 <f0+0x24b0>  // b.none
    aa30:	52800020 	mov	w0, #0x1                   	// #1
    aa34:	390002e0 	strb	w0, [x23]
    aa38:	9102e3e1 	add	x1, sp, #0xb8
    aa3c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aa40:	52800020 	mov	w0, #0x1                   	// #1
    aa44:	a90bd7e2 	stp	x2, x21, [sp, #184]
    aa48:	97ffebe3 	bl	59d4 <fwp_data.part.0.constprop.0>
    aa4c:	97ffec66 	bl	5be4 <fwp_rc_fresh>
    aa50:	aa0003e2 	mov	x2, x0
    aa54:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aa58:	910323e1 	add	x1, sp, #0xc8
    aa5c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aa60:	52800020 	mov	w0, #0x1                   	// #1
    aa64:	a90c8be3 	stp	x3, x2, [sp, #200]
    aa68:	97ffebdb 	bl	59d4 <fwp_data.part.0.constprop.0>
    aa6c:	91190283 	add	x3, x20, #0x640
    aa70:	aa0003f5 	mov	x21, x0
    aa74:	f949d861 	ldr	x1, [x3, #5040]
    aa78:	f949ec60 	ldr	x0, [x3, #5080]
    aa7c:	cb0102a1 	sub	x1, x21, x1
    aa80:	eb00403f 	cmp	x1, x0, lsl #16
    aa84:	54000322 	b.cs	aae8 <f0+0x424>  // b.hs, b.nlast
    aa88:	d350fc22 	lsr	x2, x1, #16
    aa8c:	f949fc63 	ldr	x3, [x3, #5112]
    aa90:	8b020842 	add	x2, x2, x2, lsl #2
    aa94:	d37df042 	lsl	x2, x2, #3
    aa98:	8b020060 	add	x0, x3, x2
    aa9c:	f9401017 	ldr	x23, [x0, #32]
    aaa0:	b4000257 	cbz	x23, aae8 <f0+0x424>
    aaa4:	38626862 	ldrb	w2, [x3, x2]
    aaa8:	7100085f 	cmp	w2, #0x2
    aaac:	5400fbc0 	b.eq	ca24 <f0+0x2360>  // b.none
    aab0:	7100045f 	cmp	w2, #0x1
    aab4:	540001a1 	b.ne	aae8 <f0+0x424>  // b.any
    aab8:	29430002 	ldp	w2, w0, [x0, #24]
    aabc:	92403c21 	and	x1, x1, #0xffff
    aac0:	9b027c21 	mul	x1, x1, x2
    aac4:	d360fc21 	lsr	x1, x1, #32
    aac8:	eb00003f 	cmp	x1, x0
    aacc:	540000e2 	b.cs	aae8 <f0+0x424>  // b.hs, b.nlast
    aad0:	8b0102f7 	add	x23, x23, x1
    aad4:	394002e0 	ldrb	w0, [x23]
    aad8:	7103fc1f 	cmp	w0, #0xff
    aadc:	54010520 	b.eq	cb80 <f0+0x24bc>  // b.none
    aae0:	52800020 	mov	w0, #0x1                   	// #1
    aae4:	390002e0 	strb	w0, [x23]
    aae8:	910363e1 	add	x1, sp, #0xd8
    aaec:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    aaf0:	52800020 	mov	w0, #0x1                   	// #1
    aaf4:	a90dd7f7 	stp	x23, x21, [sp, #216]
    aaf8:	97ffebb7 	bl	59d4 <fwp_data.part.0.constprop.0>
    aafc:	97ffec3a 	bl	5be4 <fwp_rc_fresh>
    ab00:	aa0003e2 	mov	x2, x0
    ab04:	9103a3e1 	add	x1, sp, #0xe8
    ab08:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ab0c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ab10:	52800020 	mov	w0, #0x1                   	// #1
    ab14:	a90e8bf5 	stp	x21, x2, [sp, #232]
    ab18:	97ffebaf 	bl	59d4 <fwp_data.part.0.constprop.0>
    ab1c:	97ffec32 	bl	5be4 <fwp_rc_fresh>
    ab20:	aa0003e2 	mov	x2, x0
    ab24:	9103e3e1 	add	x1, sp, #0xf8
    ab28:	52800020 	mov	w0, #0x1                   	// #1
    ab2c:	a90f8bf7 	stp	x23, x2, [sp, #248]
    ab30:	97ffeba9 	bl	59d4 <fwp_data.part.0.constprop.0>
    ab34:	97ffec2c 	bl	5be4 <fwp_rc_fresh>
    ab38:	aa0003e2 	mov	x2, x0
    ab3c:	910423e1 	add	x1, sp, #0x108
    ab40:	52800020 	mov	w0, #0x1                   	// #1
    ab44:	a9108bf5 	stp	x21, x2, [sp, #264]
    ab48:	97ffeba3 	bl	59d4 <fwp_data.part.0.constprop.0>
    ab4c:	97ffec26 	bl	5be4 <fwp_rc_fresh>
    ab50:	aa0003e2 	mov	x2, x0
    ab54:	910463e1 	add	x1, sp, #0x118
    ab58:	52800020 	mov	w0, #0x1                   	// #1
    ab5c:	a9118bf7 	stp	x23, x2, [sp, #280]
    ab60:	97ffeb9d 	bl	59d4 <fwp_data.part.0.constprop.0>
    ab64:	91190283 	add	x3, x20, #0x640
    ab68:	aa0003f5 	mov	x21, x0
    ab6c:	f949d861 	ldr	x1, [x3, #5040]
    ab70:	f949ec60 	ldr	x0, [x3, #5080]
    ab74:	cb0102a1 	sub	x1, x21, x1
    ab78:	eb00403f 	cmp	x1, x0, lsl #16
    ab7c:	54000322 	b.cs	abe0 <f0+0x51c>  // b.hs, b.nlast
    ab80:	d350fc22 	lsr	x2, x1, #16
    ab84:	f949fc63 	ldr	x3, [x3, #5112]
    ab88:	8b020842 	add	x2, x2, x2, lsl #2
    ab8c:	d37df042 	lsl	x2, x2, #3
    ab90:	8b020060 	add	x0, x3, x2
    ab94:	f9401017 	ldr	x23, [x0, #32]
    ab98:	b4000257 	cbz	x23, abe0 <f0+0x51c>
    ab9c:	38626862 	ldrb	w2, [x3, x2]
    aba0:	7100085f 	cmp	w2, #0x2
    aba4:	5400f3a0 	b.eq	ca18 <f0+0x2354>  // b.none
    aba8:	7100045f 	cmp	w2, #0x1
    abac:	540001a1 	b.ne	abe0 <f0+0x51c>  // b.any
    abb0:	29430002 	ldp	w2, w0, [x0, #24]
    abb4:	92403c21 	and	x1, x1, #0xffff
    abb8:	9b027c21 	mul	x1, x1, x2
    abbc:	d360fc21 	lsr	x1, x1, #32
    abc0:	eb00003f 	cmp	x1, x0
    abc4:	540000e2 	b.cs	abe0 <f0+0x51c>  // b.hs, b.nlast
    abc8:	8b0102f7 	add	x23, x23, x1
    abcc:	394002e0 	ldrb	w0, [x23]
    abd0:	7103fc1f 	cmp	w0, #0xff
    abd4:	5400fdc0 	b.eq	cb8c <f0+0x24c8>  // b.none
    abd8:	52800020 	mov	w0, #0x1                   	// #1
    abdc:	390002e0 	strb	w0, [x23]
    abe0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    abe4:	9104a3e1 	add	x1, sp, #0x128
    abe8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    abec:	52800020 	mov	w0, #0x1                   	// #1
    abf0:	a912d7e2 	stp	x2, x21, [sp, #296]
    abf4:	97ffeb78 	bl	59d4 <fwp_data.part.0.constprop.0>
    abf8:	97ffebfb 	bl	5be4 <fwp_rc_fresh>
    abfc:	aa0003e2 	mov	x2, x0
    ac00:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ac04:	9104e3e1 	add	x1, sp, #0x138
    ac08:	52800020 	mov	w0, #0x1                   	// #1
    ac0c:	a9138be3 	stp	x3, x2, [sp, #312]
    ac10:	97ffeb71 	bl	59d4 <fwp_data.part.0.constprop.0>
    ac14:	91190283 	add	x3, x20, #0x640
    ac18:	aa0003f5 	mov	x21, x0
    ac1c:	f949d861 	ldr	x1, [x3, #5040]
    ac20:	f949ec60 	ldr	x0, [x3, #5080]
    ac24:	cb0102a1 	sub	x1, x21, x1
    ac28:	eb00403f 	cmp	x1, x0, lsl #16
    ac2c:	54000322 	b.cs	ac90 <f0+0x5cc>  // b.hs, b.nlast
    ac30:	d350fc22 	lsr	x2, x1, #16
    ac34:	f949fc63 	ldr	x3, [x3, #5112]
    ac38:	8b020842 	add	x2, x2, x2, lsl #2
    ac3c:	d37df042 	lsl	x2, x2, #3
    ac40:	8b020060 	add	x0, x3, x2
    ac44:	f9401017 	ldr	x23, [x0, #32]
    ac48:	b4000257 	cbz	x23, ac90 <f0+0x5cc>
    ac4c:	38626862 	ldrb	w2, [x3, x2]
    ac50:	7100085f 	cmp	w2, #0x2
    ac54:	5400edc0 	b.eq	ca0c <f0+0x2348>  // b.none
    ac58:	7100045f 	cmp	w2, #0x1
    ac5c:	540001a1 	b.ne	ac90 <f0+0x5cc>  // b.any
    ac60:	29430002 	ldp	w2, w0, [x0, #24]
    ac64:	92403c21 	and	x1, x1, #0xffff
    ac68:	9b027c21 	mul	x1, x1, x2
    ac6c:	d360fc21 	lsr	x1, x1, #32
    ac70:	eb00003f 	cmp	x1, x0
    ac74:	540000e2 	b.cs	ac90 <f0+0x5cc>  // b.hs, b.nlast
    ac78:	8b0102f7 	add	x23, x23, x1
    ac7c:	394002e0 	ldrb	w0, [x23]
    ac80:	7103fc1f 	cmp	w0, #0xff
    ac84:	5400f8a0 	b.eq	cb98 <f0+0x24d4>  // b.none
    ac88:	52800020 	mov	w0, #0x1                   	// #1
    ac8c:	390002e0 	strb	w0, [x23]
    ac90:	910523e1 	add	x1, sp, #0x148
    ac94:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ac98:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ac9c:	52800020 	mov	w0, #0x1                   	// #1
    aca0:	a914d7f7 	stp	x23, x21, [sp, #328]
    aca4:	97ffeb4c 	bl	59d4 <fwp_data.part.0.constprop.0>
    aca8:	97ffebcf 	bl	5be4 <fwp_rc_fresh>
    acac:	aa0003e2 	mov	x2, x0
    acb0:	910563e1 	add	x1, sp, #0x158
    acb4:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    acb8:	52800020 	mov	w0, #0x1                   	// #1
    acbc:	a9158bf5 	stp	x21, x2, [sp, #344]
    acc0:	97ffeb45 	bl	59d4 <fwp_data.part.0.constprop.0>
    acc4:	97ffebc8 	bl	5be4 <fwp_rc_fresh>
    acc8:	aa0003e2 	mov	x2, x0
    accc:	9105a3e1 	add	x1, sp, #0x168
    acd0:	52800020 	mov	w0, #0x1                   	// #1
    acd4:	a9168bf7 	stp	x23, x2, [sp, #360]
    acd8:	97ffeb3f 	bl	59d4 <fwp_data.part.0.constprop.0>
    acdc:	97ffebc2 	bl	5be4 <fwp_rc_fresh>
    ace0:	aa0003e2 	mov	x2, x0
    ace4:	9105e3e1 	add	x1, sp, #0x178
    ace8:	52800020 	mov	w0, #0x1                   	// #1
    acec:	a9178bf5 	stp	x21, x2, [sp, #376]
    acf0:	97ffeb39 	bl	59d4 <fwp_data.part.0.constprop.0>
    acf4:	91190283 	add	x3, x20, #0x640
    acf8:	aa0003f5 	mov	x21, x0
    acfc:	f949d861 	ldr	x1, [x3, #5040]
    ad00:	f949ec60 	ldr	x0, [x3, #5080]
    ad04:	cb0102a1 	sub	x1, x21, x1
    ad08:	eb00403f 	cmp	x1, x0, lsl #16
    ad0c:	54000322 	b.cs	ad70 <f0+0x6ac>  // b.hs, b.nlast
    ad10:	d350fc22 	lsr	x2, x1, #16
    ad14:	f949fc63 	ldr	x3, [x3, #5112]
    ad18:	8b020842 	add	x2, x2, x2, lsl #2
    ad1c:	d37df042 	lsl	x2, x2, #3
    ad20:	8b020060 	add	x0, x3, x2
    ad24:	f9401017 	ldr	x23, [x0, #32]
    ad28:	b4000257 	cbz	x23, ad70 <f0+0x6ac>
    ad2c:	38626862 	ldrb	w2, [x3, x2]
    ad30:	7100085f 	cmp	w2, #0x2
    ad34:	5400e660 	b.eq	ca00 <f0+0x233c>  // b.none
    ad38:	7100045f 	cmp	w2, #0x1
    ad3c:	540001a1 	b.ne	ad70 <f0+0x6ac>  // b.any
    ad40:	29430002 	ldp	w2, w0, [x0, #24]
    ad44:	92403c21 	and	x1, x1, #0xffff
    ad48:	9b027c21 	mul	x1, x1, x2
    ad4c:	d360fc21 	lsr	x1, x1, #32
    ad50:	eb00003f 	cmp	x1, x0
    ad54:	540000e2 	b.cs	ad70 <f0+0x6ac>  // b.hs, b.nlast
    ad58:	8b0102f7 	add	x23, x23, x1
    ad5c:	394002e0 	ldrb	w0, [x23]
    ad60:	7103fc1f 	cmp	w0, #0xff
    ad64:	5400f200 	b.eq	cba4 <f0+0x24e0>  // b.none
    ad68:	52800020 	mov	w0, #0x1                   	// #1
    ad6c:	390002e0 	strb	w0, [x23]
    ad70:	910623e1 	add	x1, sp, #0x188
    ad74:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ad78:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ad7c:	52800020 	mov	w0, #0x1                   	// #1
    ad80:	a918d7f7 	stp	x23, x21, [sp, #392]
    ad84:	97ffeb14 	bl	59d4 <fwp_data.part.0.constprop.0>
    ad88:	97ffeb97 	bl	5be4 <fwp_rc_fresh>
    ad8c:	aa0003e2 	mov	x2, x0
    ad90:	910663e1 	add	x1, sp, #0x198
    ad94:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ad98:	52800020 	mov	w0, #0x1                   	// #1
    ad9c:	a9198bf5 	stp	x21, x2, [sp, #408]
    ada0:	97ffeb0d 	bl	59d4 <fwp_data.part.0.constprop.0>
    ada4:	97ffeb90 	bl	5be4 <fwp_rc_fresh>
    ada8:	aa0003e2 	mov	x2, x0
    adac:	9106a3e1 	add	x1, sp, #0x1a8
    adb0:	52800020 	mov	w0, #0x1                   	// #1
    adb4:	a91a8bf7 	stp	x23, x2, [sp, #424]
    adb8:	97ffeb07 	bl	59d4 <fwp_data.part.0.constprop.0>
    adbc:	97ffeb8a 	bl	5be4 <fwp_rc_fresh>
    adc0:	aa0003e2 	mov	x2, x0
    adc4:	9106e3e1 	add	x1, sp, #0x1b8
    adc8:	52800020 	mov	w0, #0x1                   	// #1
    adcc:	a91b8bf5 	stp	x21, x2, [sp, #440]
    add0:	97ffeb01 	bl	59d4 <fwp_data.part.0.constprop.0>
    add4:	91190283 	add	x3, x20, #0x640
    add8:	aa0003f5 	mov	x21, x0
    addc:	f949d861 	ldr	x1, [x3, #5040]
    ade0:	f949ec60 	ldr	x0, [x3, #5080]
    ade4:	cb0102a1 	sub	x1, x21, x1
    ade8:	eb00403f 	cmp	x1, x0, lsl #16
    adec:	54000322 	b.cs	ae50 <f0+0x78c>  // b.hs, b.nlast
    adf0:	d350fc22 	lsr	x2, x1, #16
    adf4:	f949fc63 	ldr	x3, [x3, #5112]
    adf8:	8b020842 	add	x2, x2, x2, lsl #2
    adfc:	d37df042 	lsl	x2, x2, #3
    ae00:	8b020060 	add	x0, x3, x2
    ae04:	f9401017 	ldr	x23, [x0, #32]
    ae08:	b4000257 	cbz	x23, ae50 <f0+0x78c>
    ae0c:	38626862 	ldrb	w2, [x3, x2]
    ae10:	7100085f 	cmp	w2, #0x2
    ae14:	5400e380 	b.eq	ca84 <f0+0x23c0>  // b.none
    ae18:	7100045f 	cmp	w2, #0x1
    ae1c:	540001a1 	b.ne	ae50 <f0+0x78c>  // b.any
    ae20:	29430002 	ldp	w2, w0, [x0, #24]
    ae24:	92403c21 	and	x1, x1, #0xffff
    ae28:	9b027c21 	mul	x1, x1, x2
    ae2c:	d360fc21 	lsr	x1, x1, #32
    ae30:	eb00003f 	cmp	x1, x0
    ae34:	540000e2 	b.cs	ae50 <f0+0x78c>  // b.hs, b.nlast
    ae38:	8b0102f7 	add	x23, x23, x1
    ae3c:	394002e0 	ldrb	w0, [x23]
    ae40:	7103fc1f 	cmp	w0, #0xff
    ae44:	5400eb60 	b.eq	cbb0 <f0+0x24ec>  // b.none
    ae48:	52800020 	mov	w0, #0x1                   	// #1
    ae4c:	390002e0 	strb	w0, [x23]
    ae50:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ae54:	910723e1 	add	x1, sp, #0x1c8
    ae58:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ae5c:	52800020 	mov	w0, #0x1                   	// #1
    ae60:	a91cd7e2 	stp	x2, x21, [sp, #456]
    ae64:	97ffeadc 	bl	59d4 <fwp_data.part.0.constprop.0>
    ae68:	97ffeb5f 	bl	5be4 <fwp_rc_fresh>
    ae6c:	aa0003e2 	mov	x2, x0
    ae70:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ae74:	910763e1 	add	x1, sp, #0x1d8
    ae78:	52800020 	mov	w0, #0x1                   	// #1
    ae7c:	a91d8be3 	stp	x3, x2, [sp, #472]
    ae80:	97ffead5 	bl	59d4 <fwp_data.part.0.constprop.0>
    ae84:	91190283 	add	x3, x20, #0x640
    ae88:	aa0003f5 	mov	x21, x0
    ae8c:	f949d861 	ldr	x1, [x3, #5040]
    ae90:	f949ec60 	ldr	x0, [x3, #5080]
    ae94:	cb0102a1 	sub	x1, x21, x1
    ae98:	eb00403f 	cmp	x1, x0, lsl #16
    ae9c:	54000322 	b.cs	af00 <f0+0x83c>  // b.hs, b.nlast
    aea0:	d350fc22 	lsr	x2, x1, #16
    aea4:	f949fc63 	ldr	x3, [x3, #5112]
    aea8:	8b020842 	add	x2, x2, x2, lsl #2
    aeac:	d37df042 	lsl	x2, x2, #3
    aeb0:	8b020060 	add	x0, x3, x2
    aeb4:	f9401017 	ldr	x23, [x0, #32]
    aeb8:	b4000257 	cbz	x23, af00 <f0+0x83c>
    aebc:	38626862 	ldrb	w2, [x3, x2]
    aec0:	7100085f 	cmp	w2, #0x2
    aec4:	5400dda0 	b.eq	ca78 <f0+0x23b4>  // b.none
    aec8:	7100045f 	cmp	w2, #0x1
    aecc:	540001a1 	b.ne	af00 <f0+0x83c>  // b.any
    aed0:	29430002 	ldp	w2, w0, [x0, #24]
    aed4:	92403c21 	and	x1, x1, #0xffff
    aed8:	9b027c21 	mul	x1, x1, x2
    aedc:	d360fc21 	lsr	x1, x1, #32
    aee0:	eb00003f 	cmp	x1, x0
    aee4:	540000e2 	b.cs	af00 <f0+0x83c>  // b.hs, b.nlast
    aee8:	8b0102f7 	add	x23, x23, x1
    aeec:	394002e0 	ldrb	w0, [x23]
    aef0:	7103fc1f 	cmp	w0, #0xff
    aef4:	5400e640 	b.eq	cbbc <f0+0x24f8>  // b.none
    aef8:	52800020 	mov	w0, #0x1                   	// #1
    aefc:	390002e0 	strb	w0, [x23]
    af00:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    af04:	9107a3e1 	add	x1, sp, #0x1e8
    af08:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    af0c:	52800020 	mov	w0, #0x1                   	// #1
    af10:	a91ed7e2 	stp	x2, x21, [sp, #488]
    af14:	97ffeab0 	bl	59d4 <fwp_data.part.0.constprop.0>
    af18:	91190283 	add	x3, x20, #0x640
    af1c:	aa0003f5 	mov	x21, x0
    af20:	f949d861 	ldr	x1, [x3, #5040]
    af24:	f949ec60 	ldr	x0, [x3, #5080]
    af28:	cb0102a1 	sub	x1, x21, x1
    af2c:	eb00403f 	cmp	x1, x0, lsl #16
    af30:	54000322 	b.cs	af94 <f0+0x8d0>  // b.hs, b.nlast
    af34:	d350fc22 	lsr	x2, x1, #16
    af38:	f949fc63 	ldr	x3, [x3, #5112]
    af3c:	8b020842 	add	x2, x2, x2, lsl #2
    af40:	d37df042 	lsl	x2, x2, #3
    af44:	8b020060 	add	x0, x3, x2
    af48:	f9401017 	ldr	x23, [x0, #32]
    af4c:	b4000257 	cbz	x23, af94 <f0+0x8d0>
    af50:	38626862 	ldrb	w2, [x3, x2]
    af54:	7100085f 	cmp	w2, #0x2
    af58:	5400d8a0 	b.eq	ca6c <f0+0x23a8>  // b.none
    af5c:	7100045f 	cmp	w2, #0x1
    af60:	540001a1 	b.ne	af94 <f0+0x8d0>  // b.any
    af64:	29430002 	ldp	w2, w0, [x0, #24]
    af68:	92403c21 	and	x1, x1, #0xffff
    af6c:	9b027c21 	mul	x1, x1, x2
    af70:	d360fc21 	lsr	x1, x1, #32
    af74:	eb00003f 	cmp	x1, x0
    af78:	540000e2 	b.cs	af94 <f0+0x8d0>  // b.hs, b.nlast
    af7c:	8b0102f7 	add	x23, x23, x1
    af80:	394002e0 	ldrb	w0, [x23]
    af84:	7103fc1f 	cmp	w0, #0xff
    af88:	5400e200 	b.eq	cbc8 <f0+0x2504>  // b.none
    af8c:	52800020 	mov	w0, #0x1                   	// #1
    af90:	390002e0 	strb	w0, [x23]
    af94:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    af98:	9107e3e1 	add	x1, sp, #0x1f8
    af9c:	52800020 	mov	w0, #0x1                   	// #1
    afa0:	a91fd7e2 	stp	x2, x21, [sp, #504]
    afa4:	97ffea8c 	bl	59d4 <fwp_data.part.0.constprop.0>
    afa8:	91190283 	add	x3, x20, #0x640
    afac:	aa0003f7 	mov	x23, x0
    afb0:	f949d861 	ldr	x1, [x3, #5040]
    afb4:	f949ec60 	ldr	x0, [x3, #5080]
    afb8:	cb0102e1 	sub	x1, x23, x1
    afbc:	eb00403f 	cmp	x1, x0, lsl #16
    afc0:	54000322 	b.cs	b024 <f0+0x960>  // b.hs, b.nlast
    afc4:	d350fc22 	lsr	x2, x1, #16
    afc8:	f949fc63 	ldr	x3, [x3, #5112]
    afcc:	8b020842 	add	x2, x2, x2, lsl #2
    afd0:	d37df042 	lsl	x2, x2, #3
    afd4:	8b020060 	add	x0, x3, x2
    afd8:	f9401015 	ldr	x21, [x0, #32]
    afdc:	b4000255 	cbz	x21, b024 <f0+0x960>
    afe0:	38626862 	ldrb	w2, [x3, x2]
    afe4:	7100085f 	cmp	w2, #0x2
    afe8:	5400d3c0 	b.eq	ca60 <f0+0x239c>  // b.none
    afec:	7100045f 	cmp	w2, #0x1
    aff0:	540001a1 	b.ne	b024 <f0+0x960>  // b.any
    aff4:	29430002 	ldp	w2, w0, [x0, #24]
    aff8:	92403c21 	and	x1, x1, #0xffff
    affc:	9b027c21 	mul	x1, x1, x2
    b000:	d360fc21 	lsr	x1, x1, #32
    b004:	eb00003f 	cmp	x1, x0
    b008:	540000e2 	b.cs	b024 <f0+0x960>  // b.hs, b.nlast
    b00c:	8b0102b5 	add	x21, x21, x1
    b010:	394002a0 	ldrb	w0, [x21]
    b014:	7103fc1f 	cmp	w0, #0xff
    b018:	5400dde0 	b.eq	cbd4 <f0+0x2510>  // b.none
    b01c:	52800020 	mov	w0, #0x1                   	// #1
    b020:	390002a0 	strb	w0, [x21]
    b024:	910823e1 	add	x1, sp, #0x208
    b028:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b02c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b030:	52800020 	mov	w0, #0x1                   	// #1
    b034:	f90107f5 	str	x21, [sp, #520]
    b038:	f9010bf7 	str	x23, [sp, #528]
    b03c:	97ffea66 	bl	59d4 <fwp_data.part.0.constprop.0>
    b040:	97ffeae9 	bl	5be4 <fwp_rc_fresh>
    b044:	aa0003e2 	mov	x2, x0
    b048:	910863e1 	add	x1, sp, #0x218
    b04c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b050:	52800020 	mov	w0, #0x1                   	// #1
    b054:	f9010ff7 	str	x23, [sp, #536]
    b058:	f90113e2 	str	x2, [sp, #544]
    b05c:	97ffea5e 	bl	59d4 <fwp_data.part.0.constprop.0>
    b060:	97ffeae1 	bl	5be4 <fwp_rc_fresh>
    b064:	aa0003e2 	mov	x2, x0
    b068:	9108a3e1 	add	x1, sp, #0x228
    b06c:	52800020 	mov	w0, #0x1                   	// #1
    b070:	f90117f5 	str	x21, [sp, #552]
    b074:	f9011be2 	str	x2, [sp, #560]
    b078:	97ffea57 	bl	59d4 <fwp_data.part.0.constprop.0>
    b07c:	97ffeada 	bl	5be4 <fwp_rc_fresh>
    b080:	aa0003e2 	mov	x2, x0
    b084:	9108e3e1 	add	x1, sp, #0x238
    b088:	52800020 	mov	w0, #0x1                   	// #1
    b08c:	f9011ff7 	str	x23, [sp, #568]
    b090:	f90123e2 	str	x2, [sp, #576]
    b094:	97ffea50 	bl	59d4 <fwp_data.part.0.constprop.0>
    b098:	97ffead3 	bl	5be4 <fwp_rc_fresh>
    b09c:	aa0003e2 	mov	x2, x0
    b0a0:	910923e1 	add	x1, sp, #0x248
    b0a4:	52800020 	mov	w0, #0x1                   	// #1
    b0a8:	f90127f5 	str	x21, [sp, #584]
    b0ac:	f9012be2 	str	x2, [sp, #592]
    b0b0:	97ffea49 	bl	59d4 <fwp_data.part.0.constprop.0>
    b0b4:	97ffeacc 	bl	5be4 <fwp_rc_fresh>
    b0b8:	aa0003e2 	mov	x2, x0
    b0bc:	910963e1 	add	x1, sp, #0x258
    b0c0:	52800020 	mov	w0, #0x1                   	// #1
    b0c4:	f9012ff7 	str	x23, [sp, #600]
    b0c8:	f90133e2 	str	x2, [sp, #608]
    b0cc:	97ffea42 	bl	59d4 <fwp_data.part.0.constprop.0>
    b0d0:	97ffeac5 	bl	5be4 <fwp_rc_fresh>
    b0d4:	aa0003e2 	mov	x2, x0
    b0d8:	9109a3e1 	add	x1, sp, #0x268
    b0dc:	52800020 	mov	w0, #0x1                   	// #1
    b0e0:	f90137f5 	str	x21, [sp, #616]
    b0e4:	f9013be2 	str	x2, [sp, #624]
    b0e8:	97ffea3b 	bl	59d4 <fwp_data.part.0.constprop.0>
    b0ec:	91190283 	add	x3, x20, #0x640
    b0f0:	aa0003f5 	mov	x21, x0
    b0f4:	f949d861 	ldr	x1, [x3, #5040]
    b0f8:	f949ec60 	ldr	x0, [x3, #5080]
    b0fc:	cb0102a1 	sub	x1, x21, x1
    b100:	eb00403f 	cmp	x1, x0, lsl #16
    b104:	54000322 	b.cs	b168 <f0+0xaa4>  // b.hs, b.nlast
    b108:	d350fc22 	lsr	x2, x1, #16
    b10c:	f949fc63 	ldr	x3, [x3, #5112]
    b110:	8b020842 	add	x2, x2, x2, lsl #2
    b114:	d37df042 	lsl	x2, x2, #3
    b118:	8b020060 	add	x0, x3, x2
    b11c:	f9401017 	ldr	x23, [x0, #32]
    b120:	b4000257 	cbz	x23, b168 <f0+0xaa4>
    b124:	38626862 	ldrb	w2, [x3, x2]
    b128:	7100085f 	cmp	w2, #0x2
    b12c:	5400c940 	b.eq	ca54 <f0+0x2390>  // b.none
    b130:	7100045f 	cmp	w2, #0x1
    b134:	540001a1 	b.ne	b168 <f0+0xaa4>  // b.any
    b138:	29430002 	ldp	w2, w0, [x0, #24]
    b13c:	92403c21 	and	x1, x1, #0xffff
    b140:	9b027c21 	mul	x1, x1, x2
    b144:	d360fc21 	lsr	x1, x1, #32
    b148:	eb00003f 	cmp	x1, x0
    b14c:	540000e2 	b.cs	b168 <f0+0xaa4>  // b.hs, b.nlast
    b150:	8b0102f7 	add	x23, x23, x1
    b154:	394002e0 	ldrb	w0, [x23]
    b158:	7103fc1f 	cmp	w0, #0xff
    b15c:	5400d420 	b.eq	cbe0 <f0+0x251c>  // b.none
    b160:	52800020 	mov	w0, #0x1                   	// #1
    b164:	390002e0 	strb	w0, [x23]
    b168:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b16c:	9109e3e1 	add	x1, sp, #0x278
    b170:	52800020 	mov	w0, #0x1                   	// #1
    b174:	f9013fe2 	str	x2, [sp, #632]
    b178:	f90143f5 	str	x21, [sp, #640]
    b17c:	97ffea16 	bl	59d4 <fwp_data.part.0.constprop.0>
    b180:	91190283 	add	x3, x20, #0x640
    b184:	aa0003f5 	mov	x21, x0
    b188:	f949d861 	ldr	x1, [x3, #5040]
    b18c:	f949ec60 	ldr	x0, [x3, #5080]
    b190:	cb0102a1 	sub	x1, x21, x1
    b194:	eb00403f 	cmp	x1, x0, lsl #16
    b198:	54000322 	b.cs	b1fc <f0+0xb38>  // b.hs, b.nlast
    b19c:	d350fc22 	lsr	x2, x1, #16
    b1a0:	f949fc63 	ldr	x3, [x3, #5112]
    b1a4:	8b020842 	add	x2, x2, x2, lsl #2
    b1a8:	d37df042 	lsl	x2, x2, #3
    b1ac:	8b020060 	add	x0, x3, x2
    b1b0:	f9401017 	ldr	x23, [x0, #32]
    b1b4:	b4000257 	cbz	x23, b1fc <f0+0xb38>
    b1b8:	38626862 	ldrb	w2, [x3, x2]
    b1bc:	7100085f 	cmp	w2, #0x2
    b1c0:	5400c440 	b.eq	ca48 <f0+0x2384>  // b.none
    b1c4:	7100045f 	cmp	w2, #0x1
    b1c8:	540001a1 	b.ne	b1fc <f0+0xb38>  // b.any
    b1cc:	29430002 	ldp	w2, w0, [x0, #24]
    b1d0:	92403c21 	and	x1, x1, #0xffff
    b1d4:	9b027c21 	mul	x1, x1, x2
    b1d8:	d360fc21 	lsr	x1, x1, #32
    b1dc:	eb00003f 	cmp	x1, x0
    b1e0:	540000e2 	b.cs	b1fc <f0+0xb38>  // b.hs, b.nlast
    b1e4:	8b0102f7 	add	x23, x23, x1
    b1e8:	394002e0 	ldrb	w0, [x23]
    b1ec:	7103fc1f 	cmp	w0, #0xff
    b1f0:	5400cfe0 	b.eq	cbec <f0+0x2528>  // b.none
    b1f4:	52800020 	mov	w0, #0x1                   	// #1
    b1f8:	390002e0 	strb	w0, [x23]
    b1fc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b200:	910a23e1 	add	x1, sp, #0x288
    b204:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b208:	52800020 	mov	w0, #0x1                   	// #1
    b20c:	f90147e2 	str	x2, [sp, #648]
    b210:	f9014bf5 	str	x21, [sp, #656]
    b214:	97ffe9f0 	bl	59d4 <fwp_data.part.0.constprop.0>
    b218:	97ffea73 	bl	5be4 <fwp_rc_fresh>
    b21c:	aa0003e2 	mov	x2, x0
    b220:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b224:	910a63e1 	add	x1, sp, #0x298
    b228:	52800020 	mov	w0, #0x1                   	// #1
    b22c:	f9014fe3 	str	x3, [sp, #664]
    b230:	f90153e2 	str	x2, [sp, #672]
    b234:	97ffe9e8 	bl	59d4 <fwp_data.part.0.constprop.0>
    b238:	91190283 	add	x3, x20, #0x640
    b23c:	aa0003f5 	mov	x21, x0
    b240:	f949d861 	ldr	x1, [x3, #5040]
    b244:	f949ec60 	ldr	x0, [x3, #5080]
    b248:	cb0102a1 	sub	x1, x21, x1
    b24c:	eb00403f 	cmp	x1, x0, lsl #16
    b250:	54000322 	b.cs	b2b4 <f0+0xbf0>  // b.hs, b.nlast
    b254:	d350fc22 	lsr	x2, x1, #16
    b258:	f949fc63 	ldr	x3, [x3, #5112]
    b25c:	8b020842 	add	x2, x2, x2, lsl #2
    b260:	d37df042 	lsl	x2, x2, #3
    b264:	8b020060 	add	x0, x3, x2
    b268:	f9401017 	ldr	x23, [x0, #32]
    b26c:	b4000257 	cbz	x23, b2b4 <f0+0xbf0>
    b270:	38626862 	ldrb	w2, [x3, x2]
    b274:	7100085f 	cmp	w2, #0x2
    b278:	5400be20 	b.eq	ca3c <f0+0x2378>  // b.none
    b27c:	7100045f 	cmp	w2, #0x1
    b280:	540001a1 	b.ne	b2b4 <f0+0xbf0>  // b.any
    b284:	29430002 	ldp	w2, w0, [x0, #24]
    b288:	92403c21 	and	x1, x1, #0xffff
    b28c:	9b027c21 	mul	x1, x1, x2
    b290:	d360fc21 	lsr	x1, x1, #32
    b294:	eb00003f 	cmp	x1, x0
    b298:	540000e2 	b.cs	b2b4 <f0+0xbf0>  // b.hs, b.nlast
    b29c:	8b0102f7 	add	x23, x23, x1
    b2a0:	394002e0 	ldrb	w0, [x23]
    b2a4:	7103fc1f 	cmp	w0, #0xff
    b2a8:	5400ca80 	b.eq	cbf8 <f0+0x2534>  // b.none
    b2ac:	52800020 	mov	w0, #0x1                   	// #1
    b2b0:	390002e0 	strb	w0, [x23]
    b2b4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b2b8:	910aa3e1 	add	x1, sp, #0x2a8
    b2bc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b2c0:	52800020 	mov	w0, #0x1                   	// #1
    b2c4:	f90157e2 	str	x2, [sp, #680]
    b2c8:	f9015bf5 	str	x21, [sp, #688]
    b2cc:	97ffe9c2 	bl	59d4 <fwp_data.part.0.constprop.0>
    b2d0:	97ffea45 	bl	5be4 <fwp_rc_fresh>
    b2d4:	aa0003e2 	mov	x2, x0
    b2d8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b2dc:	910ae3e1 	add	x1, sp, #0x2b8
    b2e0:	52800020 	mov	w0, #0x1                   	// #1
    b2e4:	f9015fe3 	str	x3, [sp, #696]
    b2e8:	f90163e2 	str	x2, [sp, #704]
    b2ec:	97ffe9ba 	bl	59d4 <fwp_data.part.0.constprop.0>
    b2f0:	91190283 	add	x3, x20, #0x640
    b2f4:	aa0003f5 	mov	x21, x0
    b2f8:	f949d861 	ldr	x1, [x3, #5040]
    b2fc:	f949ec60 	ldr	x0, [x3, #5080]
    b300:	cb0102a1 	sub	x1, x21, x1
    b304:	eb00403f 	cmp	x1, x0, lsl #16
    b308:	54000322 	b.cs	b36c <f0+0xca8>  // b.hs, b.nlast
    b30c:	d350fc22 	lsr	x2, x1, #16
    b310:	f949fc63 	ldr	x3, [x3, #5112]
    b314:	8b020842 	add	x2, x2, x2, lsl #2
    b318:	d37df042 	lsl	x2, x2, #3
    b31c:	8b020060 	add	x0, x3, x2
    b320:	f9401017 	ldr	x23, [x0, #32]
    b324:	b4000257 	cbz	x23, b36c <f0+0xca8>
    b328:	38626862 	ldrb	w2, [x3, x2]
    b32c:	7100085f 	cmp	w2, #0x2
    b330:	5400b800 	b.eq	ca30 <f0+0x236c>  // b.none
    b334:	7100045f 	cmp	w2, #0x1
    b338:	540001a1 	b.ne	b36c <f0+0xca8>  // b.any
    b33c:	29430002 	ldp	w2, w0, [x0, #24]
    b340:	92403c21 	and	x1, x1, #0xffff
    b344:	9b027c21 	mul	x1, x1, x2
    b348:	d360fc21 	lsr	x1, x1, #32
    b34c:	eb00003f 	cmp	x1, x0
    b350:	540000e2 	b.cs	b36c <f0+0xca8>  // b.hs, b.nlast
    b354:	8b0102f7 	add	x23, x23, x1
    b358:	394002e0 	ldrb	w0, [x23]
    b35c:	7103fc1f 	cmp	w0, #0xff
    b360:	5400c520 	b.eq	cc04 <f0+0x2540>  // b.none
    b364:	52800020 	mov	w0, #0x1                   	// #1
    b368:	390002e0 	strb	w0, [x23]
    b36c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b370:	910b23e1 	add	x1, sp, #0x2c8
    b374:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b378:	52800020 	mov	w0, #0x1                   	// #1
    b37c:	f90167e2 	str	x2, [sp, #712]
    b380:	f9016bf5 	str	x21, [sp, #720]
    b384:	97ffe994 	bl	59d4 <fwp_data.part.0.constprop.0>
    b388:	97ffea17 	bl	5be4 <fwp_rc_fresh>
    b38c:	aa0003e2 	mov	x2, x0
    b390:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b394:	910b63e1 	add	x1, sp, #0x2d8
    b398:	52800020 	mov	w0, #0x1                   	// #1
    b39c:	f9016fe3 	str	x3, [sp, #728]
    b3a0:	f90173e2 	str	x2, [sp, #736]
    b3a4:	97ffe98c 	bl	59d4 <fwp_data.part.0.constprop.0>
    b3a8:	91190283 	add	x3, x20, #0x640
    b3ac:	aa0003f5 	mov	x21, x0
    b3b0:	f949d861 	ldr	x1, [x3, #5040]
    b3b4:	f949ec60 	ldr	x0, [x3, #5080]
    b3b8:	cb0102a1 	sub	x1, x21, x1
    b3bc:	eb00403f 	cmp	x1, x0, lsl #16
    b3c0:	54000322 	b.cs	b424 <f0+0xd60>  // b.hs, b.nlast
    b3c4:	d350fc22 	lsr	x2, x1, #16
    b3c8:	f949fc63 	ldr	x3, [x3, #5112]
    b3cc:	8b020842 	add	x2, x2, x2, lsl #2
    b3d0:	d37df042 	lsl	x2, x2, #3
    b3d4:	8b020060 	add	x0, x3, x2
    b3d8:	f9401017 	ldr	x23, [x0, #32]
    b3dc:	b4000257 	cbz	x23, b424 <f0+0xd60>
    b3e0:	38626862 	ldrb	w2, [x3, x2]
    b3e4:	7100085f 	cmp	w2, #0x2
    b3e8:	5400af40 	b.eq	c9d0 <f0+0x230c>  // b.none
    b3ec:	7100045f 	cmp	w2, #0x1
    b3f0:	540001a1 	b.ne	b424 <f0+0xd60>  // b.any
    b3f4:	29430002 	ldp	w2, w0, [x0, #24]
    b3f8:	92403c21 	and	x1, x1, #0xffff
    b3fc:	9b027c21 	mul	x1, x1, x2
    b400:	d360fc21 	lsr	x1, x1, #32
    b404:	eb00003f 	cmp	x1, x0
    b408:	540000e2 	b.cs	b424 <f0+0xd60>  // b.hs, b.nlast
    b40c:	8b0102f7 	add	x23, x23, x1
    b410:	394002e0 	ldrb	w0, [x23]
    b414:	7103fc1f 	cmp	w0, #0xff
    b418:	5400bfc0 	b.eq	cc10 <f0+0x254c>  // b.none
    b41c:	52800020 	mov	w0, #0x1                   	// #1
    b420:	390002e0 	strb	w0, [x23]
    b424:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b428:	910ba3e1 	add	x1, sp, #0x2e8
    b42c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b430:	52800020 	mov	w0, #0x1                   	// #1
    b434:	f90177e2 	str	x2, [sp, #744]
    b438:	f9017bf5 	str	x21, [sp, #752]
    b43c:	97ffe966 	bl	59d4 <fwp_data.part.0.constprop.0>
    b440:	91190283 	add	x3, x20, #0x640
    b444:	aa0003f7 	mov	x23, x0
    b448:	f949d861 	ldr	x1, [x3, #5040]
    b44c:	f949ec60 	ldr	x0, [x3, #5080]
    b450:	cb0102e1 	sub	x1, x23, x1
    b454:	eb00403f 	cmp	x1, x0, lsl #16
    b458:	54000322 	b.cs	b4bc <f0+0xdf8>  // b.hs, b.nlast
    b45c:	d350fc22 	lsr	x2, x1, #16
    b460:	f949fc63 	ldr	x3, [x3, #5112]
    b464:	8b020842 	add	x2, x2, x2, lsl #2
    b468:	d37df042 	lsl	x2, x2, #3
    b46c:	8b020060 	add	x0, x3, x2
    b470:	f9401015 	ldr	x21, [x0, #32]
    b474:	b4000255 	cbz	x21, b4bc <f0+0xdf8>
    b478:	38626862 	ldrb	w2, [x3, x2]
    b47c:	7100085f 	cmp	w2, #0x2
    b480:	5400aa20 	b.eq	c9c4 <f0+0x2300>  // b.none
    b484:	7100045f 	cmp	w2, #0x1
    b488:	540001a1 	b.ne	b4bc <f0+0xdf8>  // b.any
    b48c:	29430002 	ldp	w2, w0, [x0, #24]
    b490:	92403c21 	and	x1, x1, #0xffff
    b494:	9b027c21 	mul	x1, x1, x2
    b498:	d360fc21 	lsr	x1, x1, #32
    b49c:	eb00003f 	cmp	x1, x0
    b4a0:	540000e2 	b.cs	b4bc <f0+0xdf8>  // b.hs, b.nlast
    b4a4:	8b0102b5 	add	x21, x21, x1
    b4a8:	394002a0 	ldrb	w0, [x21]
    b4ac:	7103fc1f 	cmp	w0, #0xff
    b4b0:	5400bb60 	b.eq	cc1c <f0+0x2558>  // b.none
    b4b4:	52800020 	mov	w0, #0x1                   	// #1
    b4b8:	390002a0 	strb	w0, [x21]
    b4bc:	910be3e1 	add	x1, sp, #0x2f8
    b4c0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b4c4:	52800020 	mov	w0, #0x1                   	// #1
    b4c8:	f9017ff5 	str	x21, [sp, #760]
    b4cc:	f90183f7 	str	x23, [sp, #768]
    b4d0:	97ffe941 	bl	59d4 <fwp_data.part.0.constprop.0>
    b4d4:	97ffe9c4 	bl	5be4 <fwp_rc_fresh>
    b4d8:	aa0003e2 	mov	x2, x0
    b4dc:	910c23e1 	add	x1, sp, #0x308
    b4e0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b4e4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b4e8:	52800020 	mov	w0, #0x1                   	// #1
    b4ec:	f90187f7 	str	x23, [sp, #776]
    b4f0:	f9018be2 	str	x2, [sp, #784]
    b4f4:	97ffe938 	bl	59d4 <fwp_data.part.0.constprop.0>
    b4f8:	97ffe9bb 	bl	5be4 <fwp_rc_fresh>
    b4fc:	aa0003e2 	mov	x2, x0
    b500:	910c63e1 	add	x1, sp, #0x318
    b504:	52800020 	mov	w0, #0x1                   	// #1
    b508:	f9018ff5 	str	x21, [sp, #792]
    b50c:	f90193e2 	str	x2, [sp, #800]
    b510:	97ffe931 	bl	59d4 <fwp_data.part.0.constprop.0>
    b514:	97ffe9b4 	bl	5be4 <fwp_rc_fresh>
    b518:	aa0003e2 	mov	x2, x0
    b51c:	910ca3e1 	add	x1, sp, #0x328
    b520:	52800020 	mov	w0, #0x1                   	// #1
    b524:	f90197f7 	str	x23, [sp, #808]
    b528:	f9019be2 	str	x2, [sp, #816]
    b52c:	97ffe92a 	bl	59d4 <fwp_data.part.0.constprop.0>
    b530:	97ffe9ad 	bl	5be4 <fwp_rc_fresh>
    b534:	aa0003e2 	mov	x2, x0
    b538:	910ce3e1 	add	x1, sp, #0x338
    b53c:	52800020 	mov	w0, #0x1                   	// #1
    b540:	f9019ff5 	str	x21, [sp, #824]
    b544:	f901a3e2 	str	x2, [sp, #832]
    b548:	97ffe923 	bl	59d4 <fwp_data.part.0.constprop.0>
    b54c:	97ffe9a6 	bl	5be4 <fwp_rc_fresh>
    b550:	aa0003e2 	mov	x2, x0
    b554:	910d23e1 	add	x1, sp, #0x348
    b558:	52800020 	mov	w0, #0x1                   	// #1
    b55c:	f901a7f7 	str	x23, [sp, #840]
    b560:	f901abe2 	str	x2, [sp, #848]
    b564:	97ffe91c 	bl	59d4 <fwp_data.part.0.constprop.0>
    b568:	97ffe99f 	bl	5be4 <fwp_rc_fresh>
    b56c:	aa0003e2 	mov	x2, x0
    b570:	910d63e1 	add	x1, sp, #0x358
    b574:	52800020 	mov	w0, #0x1                   	// #1
    b578:	f901aff5 	str	x21, [sp, #856]
    b57c:	f901b3e2 	str	x2, [sp, #864]
    b580:	97ffe915 	bl	59d4 <fwp_data.part.0.constprop.0>
    b584:	97ffe998 	bl	5be4 <fwp_rc_fresh>
    b588:	aa0003e2 	mov	x2, x0
    b58c:	910da3e1 	add	x1, sp, #0x368
    b590:	52800020 	mov	w0, #0x1                   	// #1
    b594:	f901b7f7 	str	x23, [sp, #872]
    b598:	f901bbe2 	str	x2, [sp, #880]
    b59c:	97ffe90e 	bl	59d4 <fwp_data.part.0.constprop.0>
    b5a0:	97ffe991 	bl	5be4 <fwp_rc_fresh>
    b5a4:	aa0003e2 	mov	x2, x0
    b5a8:	910de3e1 	add	x1, sp, #0x378
    b5ac:	52800020 	mov	w0, #0x1                   	// #1
    b5b0:	f901bff5 	str	x21, [sp, #888]
    b5b4:	f901c3e2 	str	x2, [sp, #896]
    b5b8:	97ffe907 	bl	59d4 <fwp_data.part.0.constprop.0>
    b5bc:	97ffe98a 	bl	5be4 <fwp_rc_fresh>
    b5c0:	aa0003e2 	mov	x2, x0
    b5c4:	910e23e1 	add	x1, sp, #0x388
    b5c8:	52800020 	mov	w0, #0x1                   	// #1
    b5cc:	f901c7f7 	str	x23, [sp, #904]
    b5d0:	f901cbe2 	str	x2, [sp, #912]
    b5d4:	97ffe900 	bl	59d4 <fwp_data.part.0.constprop.0>
    b5d8:	97ffe983 	bl	5be4 <fwp_rc_fresh>
    b5dc:	aa0003e2 	mov	x2, x0
    b5e0:	910e63e1 	add	x1, sp, #0x398
    b5e4:	52800020 	mov	w0, #0x1                   	// #1
    b5e8:	f901cff5 	str	x21, [sp, #920]
    b5ec:	f901d3e2 	str	x2, [sp, #928]
    b5f0:	97ffe8f9 	bl	59d4 <fwp_data.part.0.constprop.0>
    b5f4:	97ffe97c 	bl	5be4 <fwp_rc_fresh>
    b5f8:	aa0003e2 	mov	x2, x0
    b5fc:	910ea3e1 	add	x1, sp, #0x3a8
    b600:	52800020 	mov	w0, #0x1                   	// #1
    b604:	f901d7f7 	str	x23, [sp, #936]
    b608:	f901dbe2 	str	x2, [sp, #944]
    b60c:	97ffe8f2 	bl	59d4 <fwp_data.part.0.constprop.0>
    b610:	97ffe975 	bl	5be4 <fwp_rc_fresh>
    b614:	aa0003e2 	mov	x2, x0
    b618:	910ee3e1 	add	x1, sp, #0x3b8
    b61c:	52800020 	mov	w0, #0x1                   	// #1
    b620:	f901dff5 	str	x21, [sp, #952]
    b624:	f901e3e2 	str	x2, [sp, #960]
    b628:	97ffe8eb 	bl	59d4 <fwp_data.part.0.constprop.0>
    b62c:	91190283 	add	x3, x20, #0x640
    b630:	aa0003f5 	mov	x21, x0
    b634:	f949d861 	ldr	x1, [x3, #5040]
    b638:	f949ec60 	ldr	x0, [x3, #5080]
    b63c:	cb0102a1 	sub	x1, x21, x1
    b640:	eb00403f 	cmp	x1, x0, lsl #16
    b644:	54000322 	b.cs	b6a8 <f0+0xfe4>  // b.hs, b.nlast
    b648:	d350fc22 	lsr	x2, x1, #16
    b64c:	f949fc63 	ldr	x3, [x3, #5112]
    b650:	8b020842 	add	x2, x2, x2, lsl #2
    b654:	d37df042 	lsl	x2, x2, #3
    b658:	8b020060 	add	x0, x3, x2
    b65c:	f9401017 	ldr	x23, [x0, #32]
    b660:	b4000257 	cbz	x23, b6a8 <f0+0xfe4>
    b664:	38626862 	ldrb	w2, [x3, x2]
    b668:	7100085f 	cmp	w2, #0x2
    b66c:	54009a60 	b.eq	c9b8 <f0+0x22f4>  // b.none
    b670:	7100045f 	cmp	w2, #0x1
    b674:	540001a1 	b.ne	b6a8 <f0+0xfe4>  // b.any
    b678:	29430002 	ldp	w2, w0, [x0, #24]
    b67c:	92403c21 	and	x1, x1, #0xffff
    b680:	9b027c21 	mul	x1, x1, x2
    b684:	d360fc21 	lsr	x1, x1, #32
    b688:	eb00003f 	cmp	x1, x0
    b68c:	540000e2 	b.cs	b6a8 <f0+0xfe4>  // b.hs, b.nlast
    b690:	8b0102f7 	add	x23, x23, x1
    b694:	394002e0 	ldrb	w0, [x23]
    b698:	7103fc1f 	cmp	w0, #0xff
    b69c:	5400ac60 	b.eq	cc28 <f0+0x2564>  // b.none
    b6a0:	52800020 	mov	w0, #0x1                   	// #1
    b6a4:	390002e0 	strb	w0, [x23]
    b6a8:	910f23e1 	add	x1, sp, #0x3c8
    b6ac:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b6b0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b6b4:	52800020 	mov	w0, #0x1                   	// #1
    b6b8:	f901e7f7 	str	x23, [sp, #968]
    b6bc:	f901ebf5 	str	x21, [sp, #976]
    b6c0:	97ffe8c5 	bl	59d4 <fwp_data.part.0.constprop.0>
    b6c4:	97ffe948 	bl	5be4 <fwp_rc_fresh>
    b6c8:	aa0003e2 	mov	x2, x0
    b6cc:	910f63e1 	add	x1, sp, #0x3d8
    b6d0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b6d4:	52800020 	mov	w0, #0x1                   	// #1
    b6d8:	f901eff5 	str	x21, [sp, #984]
    b6dc:	f901f3e2 	str	x2, [sp, #992]
    b6e0:	97ffe8bd 	bl	59d4 <fwp_data.part.0.constprop.0>
    b6e4:	97ffe940 	bl	5be4 <fwp_rc_fresh>
    b6e8:	aa0003e2 	mov	x2, x0
    b6ec:	910fa3e1 	add	x1, sp, #0x3e8
    b6f0:	52800020 	mov	w0, #0x1                   	// #1
    b6f4:	f901f7f7 	str	x23, [sp, #1000]
    b6f8:	f901fbe2 	str	x2, [sp, #1008]
    b6fc:	97ffe8b6 	bl	59d4 <fwp_data.part.0.constprop.0>
    b700:	97ffe939 	bl	5be4 <fwp_rc_fresh>
    b704:	aa0003e2 	mov	x2, x0
    b708:	910fe3e1 	add	x1, sp, #0x3f8
    b70c:	52800020 	mov	w0, #0x1                   	// #1
    b710:	f901fff5 	str	x21, [sp, #1016]
    b714:	f90203e2 	str	x2, [sp, #1024]
    b718:	97ffe8af 	bl	59d4 <fwp_data.part.0.constprop.0>
    b71c:	91190283 	add	x3, x20, #0x640
    b720:	aa0003f7 	mov	x23, x0
    b724:	f949d861 	ldr	x1, [x3, #5040]
    b728:	f949ec60 	ldr	x0, [x3, #5080]
    b72c:	cb0102e1 	sub	x1, x23, x1
    b730:	eb00403f 	cmp	x1, x0, lsl #16
    b734:	54000322 	b.cs	b798 <f0+0x10d4>  // b.hs, b.nlast
    b738:	d350fc22 	lsr	x2, x1, #16
    b73c:	f949fc63 	ldr	x3, [x3, #5112]
    b740:	8b020842 	add	x2, x2, x2, lsl #2
    b744:	d37df042 	lsl	x2, x2, #3
    b748:	8b020060 	add	x0, x3, x2
    b74c:	f9401015 	ldr	x21, [x0, #32]
    b750:	b4000255 	cbz	x21, b798 <f0+0x10d4>
    b754:	38626862 	ldrb	w2, [x3, x2]
    b758:	7100085f 	cmp	w2, #0x2
    b75c:	54009280 	b.eq	c9ac <f0+0x22e8>  // b.none
    b760:	7100045f 	cmp	w2, #0x1
    b764:	540001a1 	b.ne	b798 <f0+0x10d4>  // b.any
    b768:	29430002 	ldp	w2, w0, [x0, #24]
    b76c:	92403c21 	and	x1, x1, #0xffff
    b770:	9b027c21 	mul	x1, x1, x2
    b774:	d360fc21 	lsr	x1, x1, #32
    b778:	eb00003f 	cmp	x1, x0
    b77c:	540000e2 	b.cs	b798 <f0+0x10d4>  // b.hs, b.nlast
    b780:	8b0102b5 	add	x21, x21, x1
    b784:	394002a0 	ldrb	w0, [x21]
    b788:	7103fc1f 	cmp	w0, #0xff
    b78c:	5400a540 	b.eq	cc34 <f0+0x2570>  // b.none
    b790:	52800020 	mov	w0, #0x1                   	// #1
    b794:	390002a0 	strb	w0, [x21]
    b798:	911023e1 	add	x1, sp, #0x408
    b79c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b7a0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b7a4:	52800020 	mov	w0, #0x1                   	// #1
    b7a8:	f90207f5 	str	x21, [sp, #1032]
    b7ac:	f9020bf7 	str	x23, [sp, #1040]
    b7b0:	97ffe889 	bl	59d4 <fwp_data.part.0.constprop.0>
    b7b4:	97ffe90c 	bl	5be4 <fwp_rc_fresh>
    b7b8:	aa0003e2 	mov	x2, x0
    b7bc:	911063e1 	add	x1, sp, #0x418
    b7c0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b7c4:	52800020 	mov	w0, #0x1                   	// #1
    b7c8:	f9020ff7 	str	x23, [sp, #1048]
    b7cc:	f90213e2 	str	x2, [sp, #1056]
    b7d0:	97ffe881 	bl	59d4 <fwp_data.part.0.constprop.0>
    b7d4:	97ffe904 	bl	5be4 <fwp_rc_fresh>
    b7d8:	aa0003e2 	mov	x2, x0
    b7dc:	9110a3e1 	add	x1, sp, #0x428
    b7e0:	52800020 	mov	w0, #0x1                   	// #1
    b7e4:	f90217f5 	str	x21, [sp, #1064]
    b7e8:	f9021be2 	str	x2, [sp, #1072]
    b7ec:	97ffe87a 	bl	59d4 <fwp_data.part.0.constprop.0>
    b7f0:	97ffe8fd 	bl	5be4 <fwp_rc_fresh>
    b7f4:	aa0003e2 	mov	x2, x0
    b7f8:	9110e3e1 	add	x1, sp, #0x438
    b7fc:	52800020 	mov	w0, #0x1                   	// #1
    b800:	f9021ff7 	str	x23, [sp, #1080]
    b804:	f90223e2 	str	x2, [sp, #1088]
    b808:	97ffe873 	bl	59d4 <fwp_data.part.0.constprop.0>
    b80c:	97ffe8f6 	bl	5be4 <fwp_rc_fresh>
    b810:	aa0003e2 	mov	x2, x0
    b814:	911123e1 	add	x1, sp, #0x448
    b818:	52800020 	mov	w0, #0x1                   	// #1
    b81c:	f90227f5 	str	x21, [sp, #1096]
    b820:	f9022be2 	str	x2, [sp, #1104]
    b824:	97ffe86c 	bl	59d4 <fwp_data.part.0.constprop.0>
    b828:	97ffe8ef 	bl	5be4 <fwp_rc_fresh>
    b82c:	aa0003e2 	mov	x2, x0
    b830:	911163e1 	add	x1, sp, #0x458
    b834:	52800020 	mov	w0, #0x1                   	// #1
    b838:	f9022ff7 	str	x23, [sp, #1112]
    b83c:	f90233e2 	str	x2, [sp, #1120]
    b840:	97ffe865 	bl	59d4 <fwp_data.part.0.constprop.0>
    b844:	97ffe8e8 	bl	5be4 <fwp_rc_fresh>
    b848:	aa0003e2 	mov	x2, x0
    b84c:	9111a3e1 	add	x1, sp, #0x468
    b850:	52800020 	mov	w0, #0x1                   	// #1
    b854:	f90237f5 	str	x21, [sp, #1128]
    b858:	f9023be2 	str	x2, [sp, #1136]
    b85c:	97ffe85e 	bl	59d4 <fwp_data.part.0.constprop.0>
    b860:	91190283 	add	x3, x20, #0x640
    b864:	aa0003f5 	mov	x21, x0
    b868:	f949d861 	ldr	x1, [x3, #5040]
    b86c:	f949ec60 	ldr	x0, [x3, #5080]
    b870:	cb0102a1 	sub	x1, x21, x1
    b874:	eb00403f 	cmp	x1, x0, lsl #16
    b878:	54000322 	b.cs	b8dc <f0+0x1218>  // b.hs, b.nlast
    b87c:	d350fc22 	lsr	x2, x1, #16
    b880:	f949fc63 	ldr	x3, [x3, #5112]
    b884:	8b020842 	add	x2, x2, x2, lsl #2
    b888:	d37df042 	lsl	x2, x2, #3
    b88c:	8b020060 	add	x0, x3, x2
    b890:	f9401017 	ldr	x23, [x0, #32]
    b894:	b4000257 	cbz	x23, b8dc <f0+0x1218>
    b898:	38626862 	ldrb	w2, [x3, x2]
    b89c:	7100085f 	cmp	w2, #0x2
    b8a0:	54008800 	b.eq	c9a0 <f0+0x22dc>  // b.none
    b8a4:	7100045f 	cmp	w2, #0x1
    b8a8:	540001a1 	b.ne	b8dc <f0+0x1218>  // b.any
    b8ac:	29430002 	ldp	w2, w0, [x0, #24]
    b8b0:	92403c21 	and	x1, x1, #0xffff
    b8b4:	9b027c21 	mul	x1, x1, x2
    b8b8:	d360fc21 	lsr	x1, x1, #32
    b8bc:	eb00003f 	cmp	x1, x0
    b8c0:	540000e2 	b.cs	b8dc <f0+0x1218>  // b.hs, b.nlast
    b8c4:	8b0102f7 	add	x23, x23, x1
    b8c8:	394002e0 	ldrb	w0, [x23]
    b8cc:	7103fc1f 	cmp	w0, #0xff
    b8d0:	54009b80 	b.eq	cc40 <f0+0x257c>  // b.none
    b8d4:	52800020 	mov	w0, #0x1                   	// #1
    b8d8:	390002e0 	strb	w0, [x23]
    b8dc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b8e0:	9111e3e1 	add	x1, sp, #0x478
    b8e4:	52800020 	mov	w0, #0x1                   	// #1
    b8e8:	f9023fe2 	str	x2, [sp, #1144]
    b8ec:	f90243f5 	str	x21, [sp, #1152]
    b8f0:	97ffe839 	bl	59d4 <fwp_data.part.0.constprop.0>
    b8f4:	91190283 	add	x3, x20, #0x640
    b8f8:	aa0003f5 	mov	x21, x0
    b8fc:	f949d861 	ldr	x1, [x3, #5040]
    b900:	f949ec60 	ldr	x0, [x3, #5080]
    b904:	cb0102a1 	sub	x1, x21, x1
    b908:	eb00403f 	cmp	x1, x0, lsl #16
    b90c:	54000322 	b.cs	b970 <f0+0x12ac>  // b.hs, b.nlast
    b910:	d350fc22 	lsr	x2, x1, #16
    b914:	f949fc63 	ldr	x3, [x3, #5112]
    b918:	8b020842 	add	x2, x2, x2, lsl #2
    b91c:	d37df042 	lsl	x2, x2, #3
    b920:	8b020060 	add	x0, x3, x2
    b924:	f9401017 	ldr	x23, [x0, #32]
    b928:	b4000257 	cbz	x23, b970 <f0+0x12ac>
    b92c:	38626862 	ldrb	w2, [x3, x2]
    b930:	7100085f 	cmp	w2, #0x2
    b934:	54008300 	b.eq	c994 <f0+0x22d0>  // b.none
    b938:	7100045f 	cmp	w2, #0x1
    b93c:	540001a1 	b.ne	b970 <f0+0x12ac>  // b.any
    b940:	29430002 	ldp	w2, w0, [x0, #24]
    b944:	92403c21 	and	x1, x1, #0xffff
    b948:	9b027c21 	mul	x1, x1, x2
    b94c:	d360fc21 	lsr	x1, x1, #32
    b950:	eb00003f 	cmp	x1, x0
    b954:	540000e2 	b.cs	b970 <f0+0x12ac>  // b.hs, b.nlast
    b958:	8b0102f7 	add	x23, x23, x1
    b95c:	394002e0 	ldrb	w0, [x23]
    b960:	7103fc1f 	cmp	w0, #0xff
    b964:	54009740 	b.eq	cc4c <f0+0x2588>  // b.none
    b968:	52800020 	mov	w0, #0x1                   	// #1
    b96c:	390002e0 	strb	w0, [x23]
    b970:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b974:	911223e1 	add	x1, sp, #0x488
    b978:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b97c:	52800020 	mov	w0, #0x1                   	// #1
    b980:	f90247e2 	str	x2, [sp, #1160]
    b984:	f9024bf5 	str	x21, [sp, #1168]
    b988:	97ffe813 	bl	59d4 <fwp_data.part.0.constprop.0>
    b98c:	97ffe896 	bl	5be4 <fwp_rc_fresh>
    b990:	aa0003e2 	mov	x2, x0
    b994:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b998:	911263e1 	add	x1, sp, #0x498
    b99c:	52800020 	mov	w0, #0x1                   	// #1
    b9a0:	f9024fe3 	str	x3, [sp, #1176]
    b9a4:	f90253e2 	str	x2, [sp, #1184]
    b9a8:	97ffe80b 	bl	59d4 <fwp_data.part.0.constprop.0>
    b9ac:	91190283 	add	x3, x20, #0x640
    b9b0:	aa0003f5 	mov	x21, x0
    b9b4:	f949d861 	ldr	x1, [x3, #5040]
    b9b8:	f949ec60 	ldr	x0, [x3, #5080]
    b9bc:	cb0102a1 	sub	x1, x21, x1
    b9c0:	eb00403f 	cmp	x1, x0, lsl #16
    b9c4:	54000322 	b.cs	ba28 <f0+0x1364>  // b.hs, b.nlast
    b9c8:	d350fc22 	lsr	x2, x1, #16
    b9cc:	f949fc63 	ldr	x3, [x3, #5112]
    b9d0:	8b020842 	add	x2, x2, x2, lsl #2
    b9d4:	d37df042 	lsl	x2, x2, #3
    b9d8:	8b020060 	add	x0, x3, x2
    b9dc:	f9401017 	ldr	x23, [x0, #32]
    b9e0:	b4000257 	cbz	x23, ba28 <f0+0x1364>
    b9e4:	38626862 	ldrb	w2, [x3, x2]
    b9e8:	7100085f 	cmp	w2, #0x2
    b9ec:	54007ce0 	b.eq	c988 <f0+0x22c4>  // b.none
    b9f0:	7100045f 	cmp	w2, #0x1
    b9f4:	540001a1 	b.ne	ba28 <f0+0x1364>  // b.any
    b9f8:	29430002 	ldp	w2, w0, [x0, #24]
    b9fc:	92403c21 	and	x1, x1, #0xffff
    ba00:	9b027c21 	mul	x1, x1, x2
    ba04:	d360fc21 	lsr	x1, x1, #32
    ba08:	eb00003f 	cmp	x1, x0
    ba0c:	540000e2 	b.cs	ba28 <f0+0x1364>  // b.hs, b.nlast
    ba10:	8b0102f7 	add	x23, x23, x1
    ba14:	394002e0 	ldrb	w0, [x23]
    ba18:	7103fc1f 	cmp	w0, #0xff
    ba1c:	540091e0 	b.eq	cc58 <f0+0x2594>  // b.none
    ba20:	52800020 	mov	w0, #0x1                   	// #1
    ba24:	390002e0 	strb	w0, [x23]
    ba28:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ba2c:	9112a3e1 	add	x1, sp, #0x4a8
    ba30:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ba34:	52800020 	mov	w0, #0x1                   	// #1
    ba38:	f90257e2 	str	x2, [sp, #1192]
    ba3c:	f9025bf5 	str	x21, [sp, #1200]
    ba40:	97ffe7e5 	bl	59d4 <fwp_data.part.0.constprop.0>
    ba44:	97ffe868 	bl	5be4 <fwp_rc_fresh>
    ba48:	aa0003e2 	mov	x2, x0
    ba4c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ba50:	9112e3e1 	add	x1, sp, #0x4b8
    ba54:	52800020 	mov	w0, #0x1                   	// #1
    ba58:	f9025fe3 	str	x3, [sp, #1208]
    ba5c:	f90263e2 	str	x2, [sp, #1216]
    ba60:	97ffe7dd 	bl	59d4 <fwp_data.part.0.constprop.0>
    ba64:	91190283 	add	x3, x20, #0x640
    ba68:	aa0003f5 	mov	x21, x0
    ba6c:	f949d861 	ldr	x1, [x3, #5040]
    ba70:	f949ec60 	ldr	x0, [x3, #5080]
    ba74:	cb0102a1 	sub	x1, x21, x1
    ba78:	eb00403f 	cmp	x1, x0, lsl #16
    ba7c:	54000322 	b.cs	bae0 <f0+0x141c>  // b.hs, b.nlast
    ba80:	d350fc22 	lsr	x2, x1, #16
    ba84:	f949fc63 	ldr	x3, [x3, #5112]
    ba88:	8b020842 	add	x2, x2, x2, lsl #2
    ba8c:	d37df042 	lsl	x2, x2, #3
    ba90:	8b020060 	add	x0, x3, x2
    ba94:	f9401017 	ldr	x23, [x0, #32]
    ba98:	b4000257 	cbz	x23, bae0 <f0+0x141c>
    ba9c:	38626862 	ldrb	w2, [x3, x2]
    baa0:	7100085f 	cmp	w2, #0x2
    baa4:	540076c0 	b.eq	c97c <f0+0x22b8>  // b.none
    baa8:	7100045f 	cmp	w2, #0x1
    baac:	540001a1 	b.ne	bae0 <f0+0x141c>  // b.any
    bab0:	29430002 	ldp	w2, w0, [x0, #24]
    bab4:	92403c21 	and	x1, x1, #0xffff
    bab8:	9b027c21 	mul	x1, x1, x2
    babc:	d360fc21 	lsr	x1, x1, #32
    bac0:	eb00003f 	cmp	x1, x0
    bac4:	540000e2 	b.cs	bae0 <f0+0x141c>  // b.hs, b.nlast
    bac8:	8b0102f7 	add	x23, x23, x1
    bacc:	394002e0 	ldrb	w0, [x23]
    bad0:	7103fc1f 	cmp	w0, #0xff
    bad4:	54008c80 	b.eq	cc64 <f0+0x25a0>  // b.none
    bad8:	52800020 	mov	w0, #0x1                   	// #1
    badc:	390002e0 	strb	w0, [x23]
    bae0:	911323e1 	add	x1, sp, #0x4c8
    bae4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bae8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    baec:	52800020 	mov	w0, #0x1                   	// #1
    baf0:	f90267f7 	str	x23, [sp, #1224]
    baf4:	f9026bf5 	str	x21, [sp, #1232]
    baf8:	97ffe7b7 	bl	59d4 <fwp_data.part.0.constprop.0>
    bafc:	97ffe83a 	bl	5be4 <fwp_rc_fresh>
    bb00:	aa0003e2 	mov	x2, x0
    bb04:	911363e1 	add	x1, sp, #0x4d8
    bb08:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bb0c:	52800020 	mov	w0, #0x1                   	// #1
    bb10:	f9026ff5 	str	x21, [sp, #1240]
    bb14:	f90273e2 	str	x2, [sp, #1248]
    bb18:	97ffe7af 	bl	59d4 <fwp_data.part.0.constprop.0>
    bb1c:	97ffe832 	bl	5be4 <fwp_rc_fresh>
    bb20:	aa0003e2 	mov	x2, x0
    bb24:	9113a3e1 	add	x1, sp, #0x4e8
    bb28:	52800020 	mov	w0, #0x1                   	// #1
    bb2c:	f90277f7 	str	x23, [sp, #1256]
    bb30:	f9027be2 	str	x2, [sp, #1264]
    bb34:	97ffe7a8 	bl	59d4 <fwp_data.part.0.constprop.0>
    bb38:	97ffe82b 	bl	5be4 <fwp_rc_fresh>
    bb3c:	aa0003e2 	mov	x2, x0
    bb40:	9113e3e1 	add	x1, sp, #0x4f8
    bb44:	52800020 	mov	w0, #0x1                   	// #1
    bb48:	f9027ff5 	str	x21, [sp, #1272]
    bb4c:	f90283e2 	str	x2, [sp, #1280]
    bb50:	97ffe7a1 	bl	59d4 <fwp_data.part.0.constprop.0>
    bb54:	91190283 	add	x3, x20, #0x640
    bb58:	aa0003f5 	mov	x21, x0
    bb5c:	f949d861 	ldr	x1, [x3, #5040]
    bb60:	f949ec60 	ldr	x0, [x3, #5080]
    bb64:	cb0102a1 	sub	x1, x21, x1
    bb68:	eb00403f 	cmp	x1, x0, lsl #16
    bb6c:	54000322 	b.cs	bbd0 <f0+0x150c>  // b.hs, b.nlast
    bb70:	d350fc22 	lsr	x2, x1, #16
    bb74:	f949fc63 	ldr	x3, [x3, #5112]
    bb78:	8b020842 	add	x2, x2, x2, lsl #2
    bb7c:	d37df042 	lsl	x2, x2, #3
    bb80:	8b020060 	add	x0, x3, x2
    bb84:	f9401017 	ldr	x23, [x0, #32]
    bb88:	b4000257 	cbz	x23, bbd0 <f0+0x150c>
    bb8c:	38626862 	ldrb	w2, [x3, x2]
    bb90:	7100085f 	cmp	w2, #0x2
    bb94:	54007d80 	b.eq	cb44 <f0+0x2480>  // b.none
    bb98:	7100045f 	cmp	w2, #0x1
    bb9c:	540001a1 	b.ne	bbd0 <f0+0x150c>  // b.any
    bba0:	29430002 	ldp	w2, w0, [x0, #24]
    bba4:	92403c21 	and	x1, x1, #0xffff
    bba8:	9b027c21 	mul	x1, x1, x2
    bbac:	d360fc21 	lsr	x1, x1, #32
    bbb0:	eb00003f 	cmp	x1, x0
    bbb4:	540000e2 	b.cs	bbd0 <f0+0x150c>  // b.hs, b.nlast
    bbb8:	8b0102f7 	add	x23, x23, x1
    bbbc:	394002e0 	ldrb	w0, [x23]
    bbc0:	7103fc1f 	cmp	w0, #0xff
    bbc4:	54008560 	b.eq	cc70 <f0+0x25ac>  // b.none
    bbc8:	52800020 	mov	w0, #0x1                   	// #1
    bbcc:	390002e0 	strb	w0, [x23]
    bbd0:	911423e1 	add	x1, sp, #0x508
    bbd4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bbd8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bbdc:	52800020 	mov	w0, #0x1                   	// #1
    bbe0:	f90287f7 	str	x23, [sp, #1288]
    bbe4:	f9028bf5 	str	x21, [sp, #1296]
    bbe8:	97ffe77b 	bl	59d4 <fwp_data.part.0.constprop.0>
    bbec:	97ffe7fe 	bl	5be4 <fwp_rc_fresh>
    bbf0:	aa0003e2 	mov	x2, x0
    bbf4:	911463e1 	add	x1, sp, #0x518
    bbf8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bbfc:	52800020 	mov	w0, #0x1                   	// #1
    bc00:	f9028ff5 	str	x21, [sp, #1304]
    bc04:	f90293e2 	str	x2, [sp, #1312]
    bc08:	97ffe773 	bl	59d4 <fwp_data.part.0.constprop.0>
    bc0c:	97ffe7f6 	bl	5be4 <fwp_rc_fresh>
    bc10:	aa0003e2 	mov	x2, x0
    bc14:	9114a3e1 	add	x1, sp, #0x528
    bc18:	52800020 	mov	w0, #0x1                   	// #1
    bc1c:	f90297f7 	str	x23, [sp, #1320]
    bc20:	f9029be2 	str	x2, [sp, #1328]
    bc24:	97ffe76c 	bl	59d4 <fwp_data.part.0.constprop.0>
    bc28:	97ffe7ef 	bl	5be4 <fwp_rc_fresh>
    bc2c:	aa0003e2 	mov	x2, x0
    bc30:	9114e3e1 	add	x1, sp, #0x538
    bc34:	52800020 	mov	w0, #0x1                   	// #1
    bc38:	f9029ff5 	str	x21, [sp, #1336]
    bc3c:	f902a3e2 	str	x2, [sp, #1344]
    bc40:	97ffe765 	bl	59d4 <fwp_data.part.0.constprop.0>
    bc44:	91190283 	add	x3, x20, #0x640
    bc48:	aa0003f5 	mov	x21, x0
    bc4c:	f949d861 	ldr	x1, [x3, #5040]
    bc50:	f949ec60 	ldr	x0, [x3, #5080]
    bc54:	cb0102a1 	sub	x1, x21, x1
    bc58:	eb00403f 	cmp	x1, x0, lsl #16
    bc5c:	54000322 	b.cs	bcc0 <f0+0x15fc>  // b.hs, b.nlast
    bc60:	d350fc22 	lsr	x2, x1, #16
    bc64:	f949fc63 	ldr	x3, [x3, #5112]
    bc68:	8b020842 	add	x2, x2, x2, lsl #2
    bc6c:	d37df042 	lsl	x2, x2, #3
    bc70:	8b020060 	add	x0, x3, x2
    bc74:	f9401017 	ldr	x23, [x0, #32]
    bc78:	b4000257 	cbz	x23, bcc0 <f0+0x15fc>
    bc7c:	38626862 	ldrb	w2, [x3, x2]
    bc80:	7100085f 	cmp	w2, #0x2
    bc84:	540075a0 	b.eq	cb38 <f0+0x2474>  // b.none
    bc88:	7100045f 	cmp	w2, #0x1
    bc8c:	540001a1 	b.ne	bcc0 <f0+0x15fc>  // b.any
    bc90:	29430002 	ldp	w2, w0, [x0, #24]
    bc94:	92403c21 	and	x1, x1, #0xffff
    bc98:	9b027c21 	mul	x1, x1, x2
    bc9c:	d360fc21 	lsr	x1, x1, #32
    bca0:	eb00003f 	cmp	x1, x0
    bca4:	540000e2 	b.cs	bcc0 <f0+0x15fc>  // b.hs, b.nlast
    bca8:	8b0102f7 	add	x23, x23, x1
    bcac:	394002e0 	ldrb	w0, [x23]
    bcb0:	7103fc1f 	cmp	w0, #0xff
    bcb4:	54007e40 	b.eq	cc7c <f0+0x25b8>  // b.none
    bcb8:	52800020 	mov	w0, #0x1                   	// #1
    bcbc:	390002e0 	strb	w0, [x23]
    bcc0:	911523e1 	add	x1, sp, #0x548
    bcc4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bcc8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bccc:	52800020 	mov	w0, #0x1                   	// #1
    bcd0:	f902a7f7 	str	x23, [sp, #1352]
    bcd4:	f902abf5 	str	x21, [sp, #1360]
    bcd8:	97ffe73f 	bl	59d4 <fwp_data.part.0.constprop.0>
    bcdc:	97ffe7c2 	bl	5be4 <fwp_rc_fresh>
    bce0:	aa0003e2 	mov	x2, x0
    bce4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bce8:	911563e1 	add	x1, sp, #0x558
    bcec:	52800020 	mov	w0, #0x1                   	// #1
    bcf0:	f902afe3 	str	x3, [sp, #1368]
    bcf4:	f902b3e2 	str	x2, [sp, #1376]
    bcf8:	97ffe737 	bl	59d4 <fwp_data.part.0.constprop.0>
    bcfc:	97ffe7ba 	bl	5be4 <fwp_rc_fresh>
    bd00:	aa0003e2 	mov	x2, x0
    bd04:	9115a3e1 	add	x1, sp, #0x568
    bd08:	52800020 	mov	w0, #0x1                   	// #1
    bd0c:	f902b7f7 	str	x23, [sp, #1384]
    bd10:	f902bbe2 	str	x2, [sp, #1392]
    bd14:	97ffe730 	bl	59d4 <fwp_data.part.0.constprop.0>
    bd18:	91190283 	add	x3, x20, #0x640
    bd1c:	aa0003f5 	mov	x21, x0
    bd20:	f949d861 	ldr	x1, [x3, #5040]
    bd24:	f949ec60 	ldr	x0, [x3, #5080]
    bd28:	cb0102a1 	sub	x1, x21, x1
    bd2c:	eb00403f 	cmp	x1, x0, lsl #16
    bd30:	54000322 	b.cs	bd94 <f0+0x16d0>  // b.hs, b.nlast
    bd34:	d350fc22 	lsr	x2, x1, #16
    bd38:	f949fc63 	ldr	x3, [x3, #5112]
    bd3c:	8b020842 	add	x2, x2, x2, lsl #2
    bd40:	d37df042 	lsl	x2, x2, #3
    bd44:	8b020060 	add	x0, x3, x2
    bd48:	f9401017 	ldr	x23, [x0, #32]
    bd4c:	b4000257 	cbz	x23, bd94 <f0+0x16d0>
    bd50:	38626862 	ldrb	w2, [x3, x2]
    bd54:	7100085f 	cmp	w2, #0x2
    bd58:	54006ea0 	b.eq	cb2c <f0+0x2468>  // b.none
    bd5c:	7100045f 	cmp	w2, #0x1
    bd60:	540001a1 	b.ne	bd94 <f0+0x16d0>  // b.any
    bd64:	29430002 	ldp	w2, w0, [x0, #24]
    bd68:	92403c21 	and	x1, x1, #0xffff
    bd6c:	9b027c21 	mul	x1, x1, x2
    bd70:	d360fc21 	lsr	x1, x1, #32
    bd74:	eb00003f 	cmp	x1, x0
    bd78:	540000e2 	b.cs	bd94 <f0+0x16d0>  // b.hs, b.nlast
    bd7c:	8b0102f7 	add	x23, x23, x1
    bd80:	394002e0 	ldrb	w0, [x23]
    bd84:	7103fc1f 	cmp	w0, #0xff
    bd88:	54007800 	b.eq	cc88 <f0+0x25c4>  // b.none
    bd8c:	52800020 	mov	w0, #0x1                   	// #1
    bd90:	390002e0 	strb	w0, [x23]
    bd94:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bd98:	9115e3e1 	add	x1, sp, #0x578
    bd9c:	52800020 	mov	w0, #0x1                   	// #1
    bda0:	f902bfe2 	str	x2, [sp, #1400]
    bda4:	f902c3f5 	str	x21, [sp, #1408]
    bda8:	97ffe70b 	bl	59d4 <fwp_data.part.0.constprop.0>
    bdac:	91190283 	add	x3, x20, #0x640
    bdb0:	aa0003f5 	mov	x21, x0
    bdb4:	f949d861 	ldr	x1, [x3, #5040]
    bdb8:	f949ec60 	ldr	x0, [x3, #5080]
    bdbc:	cb0102a1 	sub	x1, x21, x1
    bdc0:	eb00403f 	cmp	x1, x0, lsl #16
    bdc4:	54000322 	b.cs	be28 <f0+0x1764>  // b.hs, b.nlast
    bdc8:	d350fc22 	lsr	x2, x1, #16
    bdcc:	f949fc63 	ldr	x3, [x3, #5112]
    bdd0:	8b020842 	add	x2, x2, x2, lsl #2
    bdd4:	d37df042 	lsl	x2, x2, #3
    bdd8:	8b020060 	add	x0, x3, x2
    bddc:	f9401017 	ldr	x23, [x0, #32]
    bde0:	b4000257 	cbz	x23, be28 <f0+0x1764>
    bde4:	38626862 	ldrb	w2, [x3, x2]
    bde8:	7100085f 	cmp	w2, #0x2
    bdec:	540069a0 	b.eq	cb20 <f0+0x245c>  // b.none
    bdf0:	7100045f 	cmp	w2, #0x1
    bdf4:	540001a1 	b.ne	be28 <f0+0x1764>  // b.any
    bdf8:	29430002 	ldp	w2, w0, [x0, #24]
    bdfc:	92403c21 	and	x1, x1, #0xffff
    be00:	9b027c21 	mul	x1, x1, x2
    be04:	d360fc21 	lsr	x1, x1, #32
    be08:	eb00003f 	cmp	x1, x0
    be0c:	540000e2 	b.cs	be28 <f0+0x1764>  // b.hs, b.nlast
    be10:	8b0102f7 	add	x23, x23, x1
    be14:	394002e0 	ldrb	w0, [x23]
    be18:	7103fc1f 	cmp	w0, #0xff
    be1c:	540073c0 	b.eq	cc94 <f0+0x25d0>  // b.none
    be20:	52800020 	mov	w0, #0x1                   	// #1
    be24:	390002e0 	strb	w0, [x23]
    be28:	911623e1 	add	x1, sp, #0x588
    be2c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    be30:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    be34:	52800020 	mov	w0, #0x1                   	// #1
    be38:	f902c7f7 	str	x23, [sp, #1416]
    be3c:	f902cbf5 	str	x21, [sp, #1424]
    be40:	97ffe6e5 	bl	59d4 <fwp_data.part.0.constprop.0>
    be44:	97ffe768 	bl	5be4 <fwp_rc_fresh>
    be48:	aa0003e2 	mov	x2, x0
    be4c:	911663e1 	add	x1, sp, #0x598
    be50:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    be54:	52800020 	mov	w0, #0x1                   	// #1
    be58:	f902cff5 	str	x21, [sp, #1432]
    be5c:	f902d3e2 	str	x2, [sp, #1440]
    be60:	97ffe6dd 	bl	59d4 <fwp_data.part.0.constprop.0>
    be64:	97ffe760 	bl	5be4 <fwp_rc_fresh>
    be68:	aa0003e2 	mov	x2, x0
    be6c:	9116a3e1 	add	x1, sp, #0x5a8
    be70:	52800020 	mov	w0, #0x1                   	// #1
    be74:	f902d7f7 	str	x23, [sp, #1448]
    be78:	f902dbe2 	str	x2, [sp, #1456]
    be7c:	97ffe6d6 	bl	59d4 <fwp_data.part.0.constprop.0>
    be80:	97ffe759 	bl	5be4 <fwp_rc_fresh>
    be84:	aa0003e2 	mov	x2, x0
    be88:	9116e3e1 	add	x1, sp, #0x5b8
    be8c:	52800020 	mov	w0, #0x1                   	// #1
    be90:	f902dff5 	str	x21, [sp, #1464]
    be94:	f902e3e2 	str	x2, [sp, #1472]
    be98:	97ffe6cf 	bl	59d4 <fwp_data.part.0.constprop.0>
    be9c:	91190283 	add	x3, x20, #0x640
    bea0:	aa0003f5 	mov	x21, x0
    bea4:	f949d861 	ldr	x1, [x3, #5040]
    bea8:	f949ec60 	ldr	x0, [x3, #5080]
    beac:	cb0102a1 	sub	x1, x21, x1
    beb0:	eb00403f 	cmp	x1, x0, lsl #16
    beb4:	54000322 	b.cs	bf18 <f0+0x1854>  // b.hs, b.nlast
    beb8:	d350fc22 	lsr	x2, x1, #16
    bebc:	f949fc63 	ldr	x3, [x3, #5112]
    bec0:	8b020842 	add	x2, x2, x2, lsl #2
    bec4:	d37df042 	lsl	x2, x2, #3
    bec8:	8b020060 	add	x0, x3, x2
    becc:	f9401017 	ldr	x23, [x0, #32]
    bed0:	b4000257 	cbz	x23, bf18 <f0+0x1854>
    bed4:	38626862 	ldrb	w2, [x3, x2]
    bed8:	7100085f 	cmp	w2, #0x2
    bedc:	540061c0 	b.eq	cb14 <f0+0x2450>  // b.none
    bee0:	7100045f 	cmp	w2, #0x1
    bee4:	540001a1 	b.ne	bf18 <f0+0x1854>  // b.any
    bee8:	29430002 	ldp	w2, w0, [x0, #24]
    beec:	92403c21 	and	x1, x1, #0xffff
    bef0:	9b027c21 	mul	x1, x1, x2
    bef4:	d360fc21 	lsr	x1, x1, #32
    bef8:	eb00003f 	cmp	x1, x0
    befc:	540000e2 	b.cs	bf18 <f0+0x1854>  // b.hs, b.nlast
    bf00:	8b0102f7 	add	x23, x23, x1
    bf04:	394002e0 	ldrb	w0, [x23]
    bf08:	7103fc1f 	cmp	w0, #0xff
    bf0c:	54006ca0 	b.eq	cca0 <f0+0x25dc>  // b.none
    bf10:	52800020 	mov	w0, #0x1                   	// #1
    bf14:	390002e0 	strb	w0, [x23]
    bf18:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bf1c:	911723e1 	add	x1, sp, #0x5c8
    bf20:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bf24:	52800020 	mov	w0, #0x1                   	// #1
    bf28:	f902e7e2 	str	x2, [sp, #1480]
    bf2c:	f902ebf5 	str	x21, [sp, #1488]
    bf30:	97ffe6a9 	bl	59d4 <fwp_data.part.0.constprop.0>
    bf34:	97ffe72c 	bl	5be4 <fwp_rc_fresh>
    bf38:	aa0003e2 	mov	x2, x0
    bf3c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bf40:	911763e1 	add	x1, sp, #0x5d8
    bf44:	52800020 	mov	w0, #0x1                   	// #1
    bf48:	f902efe3 	str	x3, [sp, #1496]
    bf4c:	f902f3e2 	str	x2, [sp, #1504]
    bf50:	97ffe6a1 	bl	59d4 <fwp_data.part.0.constprop.0>
    bf54:	91190283 	add	x3, x20, #0x640
    bf58:	aa0003f5 	mov	x21, x0
    bf5c:	f949d861 	ldr	x1, [x3, #5040]
    bf60:	f949ec60 	ldr	x0, [x3, #5080]
    bf64:	cb0102a1 	sub	x1, x21, x1
    bf68:	eb00403f 	cmp	x1, x0, lsl #16
    bf6c:	54000322 	b.cs	bfd0 <f0+0x190c>  // b.hs, b.nlast
    bf70:	d350fc22 	lsr	x2, x1, #16
    bf74:	f949fc63 	ldr	x3, [x3, #5112]
    bf78:	8b020842 	add	x2, x2, x2, lsl #2
    bf7c:	d37df042 	lsl	x2, x2, #3
    bf80:	8b020060 	add	x0, x3, x2
    bf84:	f9401017 	ldr	x23, [x0, #32]
    bf88:	b4000257 	cbz	x23, bfd0 <f0+0x190c>
    bf8c:	38626862 	ldrb	w2, [x3, x2]
    bf90:	7100085f 	cmp	w2, #0x2
    bf94:	54005ba0 	b.eq	cb08 <f0+0x2444>  // b.none
    bf98:	7100045f 	cmp	w2, #0x1
    bf9c:	540001a1 	b.ne	bfd0 <f0+0x190c>  // b.any
    bfa0:	29430002 	ldp	w2, w0, [x0, #24]
    bfa4:	92403c21 	and	x1, x1, #0xffff
    bfa8:	9b027c21 	mul	x1, x1, x2
    bfac:	d360fc21 	lsr	x1, x1, #32
    bfb0:	eb00003f 	cmp	x1, x0
    bfb4:	540000e2 	b.cs	bfd0 <f0+0x190c>  // b.hs, b.nlast
    bfb8:	8b0102f7 	add	x23, x23, x1
    bfbc:	394002e0 	ldrb	w0, [x23]
    bfc0:	7103fc1f 	cmp	w0, #0xff
    bfc4:	54006740 	b.eq	ccac <f0+0x25e8>  // b.none
    bfc8:	52800020 	mov	w0, #0x1                   	// #1
    bfcc:	390002e0 	strb	w0, [x23]
    bfd0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bfd4:	9117a3e1 	add	x1, sp, #0x5e8
    bfd8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bfdc:	52800020 	mov	w0, #0x1                   	// #1
    bfe0:	f902f7e2 	str	x2, [sp, #1512]
    bfe4:	f902fbf5 	str	x21, [sp, #1520]
    bfe8:	97ffe67b 	bl	59d4 <fwp_data.part.0.constprop.0>
    bfec:	91190283 	add	x3, x20, #0x640
    bff0:	aa0003f5 	mov	x21, x0
    bff4:	f949d861 	ldr	x1, [x3, #5040]
    bff8:	f949ec60 	ldr	x0, [x3, #5080]
    bffc:	cb0102a1 	sub	x1, x21, x1
    c000:	eb00403f 	cmp	x1, x0, lsl #16
    c004:	54000322 	b.cs	c068 <f0+0x19a4>  // b.hs, b.nlast
    c008:	d350fc22 	lsr	x2, x1, #16
    c00c:	f949fc63 	ldr	x3, [x3, #5112]
    c010:	8b020842 	add	x2, x2, x2, lsl #2
    c014:	d37df042 	lsl	x2, x2, #3
    c018:	8b020060 	add	x0, x3, x2
    c01c:	f9401017 	ldr	x23, [x0, #32]
    c020:	b4000257 	cbz	x23, c068 <f0+0x19a4>
    c024:	38626862 	ldrb	w2, [x3, x2]
    c028:	7100085f 	cmp	w2, #0x2
    c02c:	54005680 	b.eq	cafc <f0+0x2438>  // b.none
    c030:	7100045f 	cmp	w2, #0x1
    c034:	540001a1 	b.ne	c068 <f0+0x19a4>  // b.any
    c038:	29430002 	ldp	w2, w0, [x0, #24]
    c03c:	92403c21 	and	x1, x1, #0xffff
    c040:	9b027c21 	mul	x1, x1, x2
    c044:	d360fc21 	lsr	x1, x1, #32
    c048:	eb00003f 	cmp	x1, x0
    c04c:	540000e2 	b.cs	c068 <f0+0x19a4>  // b.hs, b.nlast
    c050:	8b0102f7 	add	x23, x23, x1
    c054:	394002e0 	ldrb	w0, [x23]
    c058:	7103fc1f 	cmp	w0, #0xff
    c05c:	540062e0 	b.eq	ccb8 <f0+0x25f4>  // b.none
    c060:	52800020 	mov	w0, #0x1                   	// #1
    c064:	390002e0 	strb	w0, [x23]
    c068:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c06c:	9117e3e1 	add	x1, sp, #0x5f8
    c070:	52800020 	mov	w0, #0x1                   	// #1
    c074:	f902ffe2 	str	x2, [sp, #1528]
    c078:	f90303f5 	str	x21, [sp, #1536]
    c07c:	97ffe656 	bl	59d4 <fwp_data.part.0.constprop.0>
    c080:	91190283 	add	x3, x20, #0x640
    c084:	aa0003f5 	mov	x21, x0
    c088:	f949d861 	ldr	x1, [x3, #5040]
    c08c:	f949ec60 	ldr	x0, [x3, #5080]
    c090:	cb0102a1 	sub	x1, x21, x1
    c094:	eb00403f 	cmp	x1, x0, lsl #16
    c098:	54000322 	b.cs	c0fc <f0+0x1a38>  // b.hs, b.nlast
    c09c:	d350fc22 	lsr	x2, x1, #16
    c0a0:	f949fc63 	ldr	x3, [x3, #5112]
    c0a4:	8b020842 	add	x2, x2, x2, lsl #2
    c0a8:	d37df042 	lsl	x2, x2, #3
    c0ac:	8b020060 	add	x0, x3, x2
    c0b0:	f9401017 	ldr	x23, [x0, #32]
    c0b4:	b4000257 	cbz	x23, c0fc <f0+0x1a38>
    c0b8:	38626862 	ldrb	w2, [x3, x2]
    c0bc:	7100085f 	cmp	w2, #0x2
    c0c0:	54005180 	b.eq	caf0 <f0+0x242c>  // b.none
    c0c4:	7100045f 	cmp	w2, #0x1
    c0c8:	540001a1 	b.ne	c0fc <f0+0x1a38>  // b.any
    c0cc:	29430002 	ldp	w2, w0, [x0, #24]
    c0d0:	92403c21 	and	x1, x1, #0xffff
    c0d4:	9b027c21 	mul	x1, x1, x2
    c0d8:	d360fc21 	lsr	x1, x1, #32
    c0dc:	eb00003f 	cmp	x1, x0
    c0e0:	540000e2 	b.cs	c0fc <f0+0x1a38>  // b.hs, b.nlast
    c0e4:	8b0102f7 	add	x23, x23, x1
    c0e8:	394002e0 	ldrb	w0, [x23]
    c0ec:	7103fc1f 	cmp	w0, #0xff
    c0f0:	54005ea0 	b.eq	ccc4 <f0+0x2600>  // b.none
    c0f4:	52800020 	mov	w0, #0x1                   	// #1
    c0f8:	390002e0 	strb	w0, [x23]
    c0fc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c100:	911823e1 	add	x1, sp, #0x608
    c104:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c108:	52800020 	mov	w0, #0x1                   	// #1
    c10c:	f90307e2 	str	x2, [sp, #1544]
    c110:	f9030bf5 	str	x21, [sp, #1552]
    c114:	97ffe630 	bl	59d4 <fwp_data.part.0.constprop.0>
    c118:	97ffe6b3 	bl	5be4 <fwp_rc_fresh>
    c11c:	aa0003e2 	mov	x2, x0
    c120:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c124:	911863e1 	add	x1, sp, #0x618
    c128:	52800020 	mov	w0, #0x1                   	// #1
    c12c:	f9030fe3 	str	x3, [sp, #1560]
    c130:	f90313e2 	str	x2, [sp, #1568]
    c134:	97ffe628 	bl	59d4 <fwp_data.part.0.constprop.0>
    c138:	91190283 	add	x3, x20, #0x640
    c13c:	aa0003f5 	mov	x21, x0
    c140:	f949d861 	ldr	x1, [x3, #5040]
    c144:	f949ec60 	ldr	x0, [x3, #5080]
    c148:	cb0102a1 	sub	x1, x21, x1
    c14c:	eb00403f 	cmp	x1, x0, lsl #16
    c150:	54000322 	b.cs	c1b4 <f0+0x1af0>  // b.hs, b.nlast
    c154:	d350fc22 	lsr	x2, x1, #16
    c158:	f949fc63 	ldr	x3, [x3, #5112]
    c15c:	8b020842 	add	x2, x2, x2, lsl #2
    c160:	d37df042 	lsl	x2, x2, #3
    c164:	8b020060 	add	x0, x3, x2
    c168:	f9401017 	ldr	x23, [x0, #32]
    c16c:	b4000257 	cbz	x23, c1b4 <f0+0x1af0>
    c170:	38626862 	ldrb	w2, [x3, x2]
    c174:	7100085f 	cmp	w2, #0x2
    c178:	54004b60 	b.eq	cae4 <f0+0x2420>  // b.none
    c17c:	7100045f 	cmp	w2, #0x1
    c180:	540001a1 	b.ne	c1b4 <f0+0x1af0>  // b.any
    c184:	29430002 	ldp	w2, w0, [x0, #24]
    c188:	92403c21 	and	x1, x1, #0xffff
    c18c:	9b027c21 	mul	x1, x1, x2
    c190:	d360fc21 	lsr	x1, x1, #32
    c194:	eb00003f 	cmp	x1, x0
    c198:	540000e2 	b.cs	c1b4 <f0+0x1af0>  // b.hs, b.nlast
    c19c:	8b0102f7 	add	x23, x23, x1
    c1a0:	394002e0 	ldrb	w0, [x23]
    c1a4:	7103fc1f 	cmp	w0, #0xff
    c1a8:	54005940 	b.eq	ccd0 <f0+0x260c>  // b.none
    c1ac:	52800020 	mov	w0, #0x1                   	// #1
    c1b0:	390002e0 	strb	w0, [x23]
    c1b4:	9118a3e1 	add	x1, sp, #0x628
    c1b8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c1bc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c1c0:	52800020 	mov	w0, #0x1                   	// #1
    c1c4:	f90317f7 	str	x23, [sp, #1576]
    c1c8:	f9031bf5 	str	x21, [sp, #1584]
    c1cc:	97ffe602 	bl	59d4 <fwp_data.part.0.constprop.0>
    c1d0:	97ffe685 	bl	5be4 <fwp_rc_fresh>
    c1d4:	aa0003e2 	mov	x2, x0
    c1d8:	9118e3e1 	add	x1, sp, #0x638
    c1dc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c1e0:	52800020 	mov	w0, #0x1                   	// #1
    c1e4:	f9031ff5 	str	x21, [sp, #1592]
    c1e8:	f90323e2 	str	x2, [sp, #1600]
    c1ec:	97ffe5fa 	bl	59d4 <fwp_data.part.0.constprop.0>
    c1f0:	97ffe67d 	bl	5be4 <fwp_rc_fresh>
    c1f4:	aa0003e2 	mov	x2, x0
    c1f8:	911923e1 	add	x1, sp, #0x648
    c1fc:	52800020 	mov	w0, #0x1                   	// #1
    c200:	f90327f7 	str	x23, [sp, #1608]
    c204:	f9032be2 	str	x2, [sp, #1616]
    c208:	97ffe5f3 	bl	59d4 <fwp_data.part.0.constprop.0>
    c20c:	97ffe676 	bl	5be4 <fwp_rc_fresh>
    c210:	aa0003e2 	mov	x2, x0
    c214:	911963e1 	add	x1, sp, #0x658
    c218:	52800020 	mov	w0, #0x1                   	// #1
    c21c:	f9032ff5 	str	x21, [sp, #1624]
    c220:	f90333e2 	str	x2, [sp, #1632]
    c224:	97ffe5ec 	bl	59d4 <fwp_data.part.0.constprop.0>
    c228:	97ffe66f 	bl	5be4 <fwp_rc_fresh>
    c22c:	aa0003e2 	mov	x2, x0
    c230:	9119a3e1 	add	x1, sp, #0x668
    c234:	52800020 	mov	w0, #0x1                   	// #1
    c238:	f90337f7 	str	x23, [sp, #1640]
    c23c:	f9033be2 	str	x2, [sp, #1648]
    c240:	97ffe5e5 	bl	59d4 <fwp_data.part.0.constprop.0>
    c244:	91190283 	add	x3, x20, #0x640
    c248:	aa0003f5 	mov	x21, x0
    c24c:	f949d861 	ldr	x1, [x3, #5040]
    c250:	f949ec60 	ldr	x0, [x3, #5080]
    c254:	cb0102a1 	sub	x1, x21, x1
    c258:	eb00403f 	cmp	x1, x0, lsl #16
    c25c:	54000322 	b.cs	c2c0 <f0+0x1bfc>  // b.hs, b.nlast
    c260:	d350fc22 	lsr	x2, x1, #16
    c264:	f949fc63 	ldr	x3, [x3, #5112]
    c268:	8b020842 	add	x2, x2, x2, lsl #2
    c26c:	d37df042 	lsl	x2, x2, #3
    c270:	8b020060 	add	x0, x3, x2
    c274:	f9401017 	ldr	x23, [x0, #32]
    c278:	b4000257 	cbz	x23, c2c0 <f0+0x1bfc>
    c27c:	38626862 	ldrb	w2, [x3, x2]
    c280:	7100085f 	cmp	w2, #0x2
    c284:	540042a0 	b.eq	cad8 <f0+0x2414>  // b.none
    c288:	7100045f 	cmp	w2, #0x1
    c28c:	540001a1 	b.ne	c2c0 <f0+0x1bfc>  // b.any
    c290:	29430002 	ldp	w2, w0, [x0, #24]
    c294:	92403c21 	and	x1, x1, #0xffff
    c298:	9b027c21 	mul	x1, x1, x2
    c29c:	d360fc21 	lsr	x1, x1, #32
    c2a0:	eb00003f 	cmp	x1, x0
    c2a4:	540000e2 	b.cs	c2c0 <f0+0x1bfc>  // b.hs, b.nlast
    c2a8:	8b0102f7 	add	x23, x23, x1
    c2ac:	394002e0 	ldrb	w0, [x23]
    c2b0:	7103fc1f 	cmp	w0, #0xff
    c2b4:	54005140 	b.eq	ccdc <f0+0x2618>  // b.none
    c2b8:	52800020 	mov	w0, #0x1                   	// #1
    c2bc:	390002e0 	strb	w0, [x23]
    c2c0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c2c4:	9119e3e1 	add	x1, sp, #0x678
    c2c8:	52800020 	mov	w0, #0x1                   	// #1
    c2cc:	f9033fe2 	str	x2, [sp, #1656]
    c2d0:	f90343f5 	str	x21, [sp, #1664]
    c2d4:	97ffe5c0 	bl	59d4 <fwp_data.part.0.constprop.0>
    c2d8:	91190283 	add	x3, x20, #0x640
    c2dc:	aa0003f5 	mov	x21, x0
    c2e0:	f949d861 	ldr	x1, [x3, #5040]
    c2e4:	f949ec60 	ldr	x0, [x3, #5080]
    c2e8:	cb0102a1 	sub	x1, x21, x1
    c2ec:	eb00403f 	cmp	x1, x0, lsl #16
    c2f0:	54000322 	b.cs	c354 <f0+0x1c90>  // b.hs, b.nlast
    c2f4:	d350fc22 	lsr	x2, x1, #16
    c2f8:	f949fc63 	ldr	x3, [x3, #5112]
    c2fc:	8b020842 	add	x2, x2, x2, lsl #2
    c300:	d37df042 	lsl	x2, x2, #3
    c304:	8b020060 	add	x0, x3, x2
    c308:	f9401017 	ldr	x23, [x0, #32]
    c30c:	b4000257 	cbz	x23, c354 <f0+0x1c90>
    c310:	38626862 	ldrb	w2, [x3, x2]
    c314:	7100085f 	cmp	w2, #0x2
    c318:	54003da0 	b.eq	cacc <f0+0x2408>  // b.none
    c31c:	7100045f 	cmp	w2, #0x1
    c320:	540001a1 	b.ne	c354 <f0+0x1c90>  // b.any
    c324:	29430002 	ldp	w2, w0, [x0, #24]
    c328:	92403c21 	and	x1, x1, #0xffff
    c32c:	9b027c21 	mul	x1, x1, x2
    c330:	d360fc21 	lsr	x1, x1, #32
    c334:	eb00003f 	cmp	x1, x0
    c338:	540000e2 	b.cs	c354 <f0+0x1c90>  // b.hs, b.nlast
    c33c:	8b0102f7 	add	x23, x23, x1
    c340:	394002e0 	ldrb	w0, [x23]
    c344:	7103fc1f 	cmp	w0, #0xff
    c348:	54004d00 	b.eq	cce8 <f0+0x2624>  // b.none
    c34c:	52800020 	mov	w0, #0x1                   	// #1
    c350:	390002e0 	strb	w0, [x23]
    c354:	911a23e1 	add	x1, sp, #0x688
    c358:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c35c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c360:	52800020 	mov	w0, #0x1                   	// #1
    c364:	f90347f7 	str	x23, [sp, #1672]
    c368:	f9034bf5 	str	x21, [sp, #1680]
    c36c:	97ffe59a 	bl	59d4 <fwp_data.part.0.constprop.0>
    c370:	97ffe61d 	bl	5be4 <fwp_rc_fresh>
    c374:	aa0003e2 	mov	x2, x0
    c378:	911a63e1 	add	x1, sp, #0x698
    c37c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c380:	52800020 	mov	w0, #0x1                   	// #1
    c384:	f9034ff5 	str	x21, [sp, #1688]
    c388:	f90353e2 	str	x2, [sp, #1696]
    c38c:	97ffe592 	bl	59d4 <fwp_data.part.0.constprop.0>
    c390:	97ffe615 	bl	5be4 <fwp_rc_fresh>
    c394:	aa0003e2 	mov	x2, x0
    c398:	911aa3e1 	add	x1, sp, #0x6a8
    c39c:	52800020 	mov	w0, #0x1                   	// #1
    c3a0:	f90357f7 	str	x23, [sp, #1704]
    c3a4:	f9035be2 	str	x2, [sp, #1712]
    c3a8:	97ffe58b 	bl	59d4 <fwp_data.part.0.constprop.0>
    c3ac:	97ffe60e 	bl	5be4 <fwp_rc_fresh>
    c3b0:	aa0003e2 	mov	x2, x0
    c3b4:	911ae3e1 	add	x1, sp, #0x6b8
    c3b8:	52800020 	mov	w0, #0x1                   	// #1
    c3bc:	f9035ff5 	str	x21, [sp, #1720]
    c3c0:	f90363e2 	str	x2, [sp, #1728]
    c3c4:	97ffe584 	bl	59d4 <fwp_data.part.0.constprop.0>
    c3c8:	91190283 	add	x3, x20, #0x640
    c3cc:	aa0003f5 	mov	x21, x0
    c3d0:	f949d861 	ldr	x1, [x3, #5040]
    c3d4:	f949ec60 	ldr	x0, [x3, #5080]
    c3d8:	cb0102a1 	sub	x1, x21, x1
    c3dc:	eb00403f 	cmp	x1, x0, lsl #16
    c3e0:	54000322 	b.cs	c444 <f0+0x1d80>  // b.hs, b.nlast
    c3e4:	d350fc22 	lsr	x2, x1, #16
    c3e8:	f949fc63 	ldr	x3, [x3, #5112]
    c3ec:	8b020842 	add	x2, x2, x2, lsl #2
    c3f0:	d37df042 	lsl	x2, x2, #3
    c3f4:	8b020060 	add	x0, x3, x2
    c3f8:	f9401017 	ldr	x23, [x0, #32]
    c3fc:	b4000257 	cbz	x23, c444 <f0+0x1d80>
    c400:	38626862 	ldrb	w2, [x3, x2]
    c404:	7100085f 	cmp	w2, #0x2
    c408:	540035c0 	b.eq	cac0 <f0+0x23fc>  // b.none
    c40c:	7100045f 	cmp	w2, #0x1
    c410:	540001a1 	b.ne	c444 <f0+0x1d80>  // b.any
    c414:	29430002 	ldp	w2, w0, [x0, #24]
    c418:	92403c21 	and	x1, x1, #0xffff
    c41c:	9b027c21 	mul	x1, x1, x2
    c420:	d360fc21 	lsr	x1, x1, #32
    c424:	eb00003f 	cmp	x1, x0
    c428:	540000e2 	b.cs	c444 <f0+0x1d80>  // b.hs, b.nlast
    c42c:	8b0102f7 	add	x23, x23, x1
    c430:	394002e0 	ldrb	w0, [x23]
    c434:	7103fc1f 	cmp	w0, #0xff
    c438:	540045e0 	b.eq	ccf4 <f0+0x2630>  // b.none
    c43c:	52800020 	mov	w0, #0x1                   	// #1
    c440:	390002e0 	strb	w0, [x23]
    c444:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c448:	911b23e1 	add	x1, sp, #0x6c8
    c44c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c450:	52800020 	mov	w0, #0x1                   	// #1
    c454:	f90367e2 	str	x2, [sp, #1736]
    c458:	f9036bf5 	str	x21, [sp, #1744]
    c45c:	97ffe55e 	bl	59d4 <fwp_data.part.0.constprop.0>
    c460:	97ffe5e1 	bl	5be4 <fwp_rc_fresh>
    c464:	aa0003e2 	mov	x2, x0
    c468:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c46c:	911b63e1 	add	x1, sp, #0x6d8
    c470:	52800020 	mov	w0, #0x1                   	// #1
    c474:	f9036fe3 	str	x3, [sp, #1752]
    c478:	f90373e2 	str	x2, [sp, #1760]
    c47c:	97ffe556 	bl	59d4 <fwp_data.part.0.constprop.0>
    c480:	91190283 	add	x3, x20, #0x640
    c484:	aa0003f5 	mov	x21, x0
    c488:	f949d861 	ldr	x1, [x3, #5040]
    c48c:	f949ec60 	ldr	x0, [x3, #5080]
    c490:	cb0102a1 	sub	x1, x21, x1
    c494:	eb00403f 	cmp	x1, x0, lsl #16
    c498:	54000322 	b.cs	c4fc <f0+0x1e38>  // b.hs, b.nlast
    c49c:	d350fc22 	lsr	x2, x1, #16
    c4a0:	f949fc63 	ldr	x3, [x3, #5112]
    c4a4:	8b020842 	add	x2, x2, x2, lsl #2
    c4a8:	d37df042 	lsl	x2, x2, #3
    c4ac:	8b020060 	add	x0, x3, x2
    c4b0:	f9401017 	ldr	x23, [x0, #32]
    c4b4:	b4000257 	cbz	x23, c4fc <f0+0x1e38>
    c4b8:	38626862 	ldrb	w2, [x3, x2]
    c4bc:	7100085f 	cmp	w2, #0x2
    c4c0:	54002fa0 	b.eq	cab4 <f0+0x23f0>  // b.none
    c4c4:	7100045f 	cmp	w2, #0x1
    c4c8:	540001a1 	b.ne	c4fc <f0+0x1e38>  // b.any
    c4cc:	29430002 	ldp	w2, w0, [x0, #24]
    c4d0:	92403c21 	and	x1, x1, #0xffff
    c4d4:	9b027c21 	mul	x1, x1, x2
    c4d8:	d360fc21 	lsr	x1, x1, #32
    c4dc:	eb00003f 	cmp	x1, x0
    c4e0:	540000e2 	b.cs	c4fc <f0+0x1e38>  // b.hs, b.nlast
    c4e4:	8b0102f7 	add	x23, x23, x1
    c4e8:	394002e0 	ldrb	w0, [x23]
    c4ec:	7103fc1f 	cmp	w0, #0xff
    c4f0:	54004080 	b.eq	cd00 <f0+0x263c>  // b.none
    c4f4:	52800020 	mov	w0, #0x1                   	// #1
    c4f8:	390002e0 	strb	w0, [x23]
    c4fc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c500:	911ba3e1 	add	x1, sp, #0x6e8
    c504:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c508:	52800020 	mov	w0, #0x1                   	// #1
    c50c:	f90377e2 	str	x2, [sp, #1768]
    c510:	f9037bf5 	str	x21, [sp, #1776]
    c514:	97ffe530 	bl	59d4 <fwp_data.part.0.constprop.0>
    c518:	91190283 	add	x3, x20, #0x640
    c51c:	aa0003f7 	mov	x23, x0
    c520:	f949d861 	ldr	x1, [x3, #5040]
    c524:	f949ec60 	ldr	x0, [x3, #5080]
    c528:	cb0102e1 	sub	x1, x23, x1
    c52c:	eb00403f 	cmp	x1, x0, lsl #16
    c530:	54000322 	b.cs	c594 <f0+0x1ed0>  // b.hs, b.nlast
    c534:	d350fc22 	lsr	x2, x1, #16
    c538:	f949fc63 	ldr	x3, [x3, #5112]
    c53c:	8b020842 	add	x2, x2, x2, lsl #2
    c540:	d37df042 	lsl	x2, x2, #3
    c544:	8b020060 	add	x0, x3, x2
    c548:	f9401015 	ldr	x21, [x0, #32]
    c54c:	b4000255 	cbz	x21, c594 <f0+0x1ed0>
    c550:	38626862 	ldrb	w2, [x3, x2]
    c554:	7100085f 	cmp	w2, #0x2
    c558:	54002a80 	b.eq	caa8 <f0+0x23e4>  // b.none
    c55c:	7100045f 	cmp	w2, #0x1
    c560:	540001a1 	b.ne	c594 <f0+0x1ed0>  // b.any
    c564:	29430002 	ldp	w2, w0, [x0, #24]
    c568:	92403c21 	and	x1, x1, #0xffff
    c56c:	9b027c21 	mul	x1, x1, x2
    c570:	d360fc21 	lsr	x1, x1, #32
    c574:	eb00003f 	cmp	x1, x0
    c578:	540000e2 	b.cs	c594 <f0+0x1ed0>  // b.hs, b.nlast
    c57c:	8b0102b5 	add	x21, x21, x1
    c580:	394002a0 	ldrb	w0, [x21]
    c584:	7103fc1f 	cmp	w0, #0xff
    c588:	54003c20 	b.eq	cd0c <f0+0x2648>  // b.none
    c58c:	52800020 	mov	w0, #0x1                   	// #1
    c590:	390002a0 	strb	w0, [x21]
    c594:	911be3e1 	add	x1, sp, #0x6f8
    c598:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c59c:	52800020 	mov	w0, #0x1                   	// #1
    c5a0:	f9037ff5 	str	x21, [sp, #1784]
    c5a4:	f90383f7 	str	x23, [sp, #1792]
    c5a8:	97ffe50b 	bl	59d4 <fwp_data.part.0.constprop.0>
    c5ac:	97ffe58e 	bl	5be4 <fwp_rc_fresh>
    c5b0:	aa0003e2 	mov	x2, x0
    c5b4:	911c23e1 	add	x1, sp, #0x708
    c5b8:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c5bc:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c5c0:	52800020 	mov	w0, #0x1                   	// #1
    c5c4:	f90387f7 	str	x23, [sp, #1800]
    c5c8:	f9038be2 	str	x2, [sp, #1808]
    c5cc:	97ffe502 	bl	59d4 <fwp_data.part.0.constprop.0>
    c5d0:	97ffe585 	bl	5be4 <fwp_rc_fresh>
    c5d4:	aa0003e2 	mov	x2, x0
    c5d8:	911c63e1 	add	x1, sp, #0x718
    c5dc:	52800020 	mov	w0, #0x1                   	// #1
    c5e0:	f9038ff5 	str	x21, [sp, #1816]
    c5e4:	f90393e2 	str	x2, [sp, #1824]
    c5e8:	97ffe4fb 	bl	59d4 <fwp_data.part.0.constprop.0>
    c5ec:	97ffe57e 	bl	5be4 <fwp_rc_fresh>
    c5f0:	aa0003e2 	mov	x2, x0
    c5f4:	911ca3e1 	add	x1, sp, #0x728
    c5f8:	52800020 	mov	w0, #0x1                   	// #1
    c5fc:	f90397f7 	str	x23, [sp, #1832]
    c600:	f9039be2 	str	x2, [sp, #1840]
    c604:	97ffe4f4 	bl	59d4 <fwp_data.part.0.constprop.0>
    c608:	97ffe577 	bl	5be4 <fwp_rc_fresh>
    c60c:	aa0003e2 	mov	x2, x0
    c610:	911ce3e1 	add	x1, sp, #0x738
    c614:	52800020 	mov	w0, #0x1                   	// #1
    c618:	f9039ff5 	str	x21, [sp, #1848]
    c61c:	f903a3e2 	str	x2, [sp, #1856]
    c620:	97ffe4ed 	bl	59d4 <fwp_data.part.0.constprop.0>
    c624:	97ffe570 	bl	5be4 <fwp_rc_fresh>
    c628:	aa0003e2 	mov	x2, x0
    c62c:	911d23e1 	add	x1, sp, #0x748
    c630:	52800020 	mov	w0, #0x1                   	// #1
    c634:	f903a7f7 	str	x23, [sp, #1864]
    c638:	f903abe2 	str	x2, [sp, #1872]
    c63c:	97ffe4e6 	bl	59d4 <fwp_data.part.0.constprop.0>
    c640:	97ffe569 	bl	5be4 <fwp_rc_fresh>
    c644:	aa0003e2 	mov	x2, x0
    c648:	911d63e1 	add	x1, sp, #0x758
    c64c:	52800020 	mov	w0, #0x1                   	// #1
    c650:	f903aff5 	str	x21, [sp, #1880]
    c654:	f903b3e2 	str	x2, [sp, #1888]
    c658:	97ffe4df 	bl	59d4 <fwp_data.part.0.constprop.0>
    c65c:	91190283 	add	x3, x20, #0x640
    c660:	aa0003f5 	mov	x21, x0
    c664:	f949d861 	ldr	x1, [x3, #5040]
    c668:	f949ec60 	ldr	x0, [x3, #5080]
    c66c:	cb0102a1 	sub	x1, x21, x1
    c670:	eb00403f 	cmp	x1, x0, lsl #16
    c674:	54000322 	b.cs	c6d8 <f0+0x2014>  // b.hs, b.nlast
    c678:	d350fc22 	lsr	x2, x1, #16
    c67c:	f949fc63 	ldr	x3, [x3, #5112]
    c680:	8b020842 	add	x2, x2, x2, lsl #2
    c684:	d37df042 	lsl	x2, x2, #3
    c688:	8b020060 	add	x0, x3, x2
    c68c:	f9401017 	ldr	x23, [x0, #32]
    c690:	b4000257 	cbz	x23, c6d8 <f0+0x2014>
    c694:	38626862 	ldrb	w2, [x3, x2]
    c698:	7100085f 	cmp	w2, #0x2
    c69c:	54002000 	b.eq	ca9c <f0+0x23d8>  // b.none
    c6a0:	7100045f 	cmp	w2, #0x1
    c6a4:	540001a1 	b.ne	c6d8 <f0+0x2014>  // b.any
    c6a8:	29430002 	ldp	w2, w0, [x0, #24]
    c6ac:	92403c21 	and	x1, x1, #0xffff
    c6b0:	9b027c21 	mul	x1, x1, x2
    c6b4:	d360fc21 	lsr	x1, x1, #32
    c6b8:	eb00003f 	cmp	x1, x0
    c6bc:	540000e2 	b.cs	c6d8 <f0+0x2014>  // b.hs, b.nlast
    c6c0:	8b0102f7 	add	x23, x23, x1
    c6c4:	394002e0 	ldrb	w0, [x23]
    c6c8:	7103fc1f 	cmp	w0, #0xff
    c6cc:	54003260 	b.eq	cd18 <f0+0x2654>  // b.none
    c6d0:	52800020 	mov	w0, #0x1                   	// #1
    c6d4:	390002e0 	strb	w0, [x23]
    c6d8:	911da3e1 	add	x1, sp, #0x768
    c6dc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c6e0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c6e4:	52800020 	mov	w0, #0x1                   	// #1
    c6e8:	f903b7f7 	str	x23, [sp, #1896]
    c6ec:	91190294 	add	x20, x20, #0x640
    c6f0:	f903bbf5 	str	x21, [sp, #1904]
    c6f4:	97ffe4b8 	bl	59d4 <fwp_data.part.0.constprop.0>
    c6f8:	97ffe53b 	bl	5be4 <fwp_rc_fresh>
    c6fc:	aa0003e2 	mov	x2, x0
    c700:	911de3e1 	add	x1, sp, #0x778
    c704:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c708:	52800020 	mov	w0, #0x1                   	// #1
    c70c:	f903bff5 	str	x21, [sp, #1912]
    c710:	f903c3e2 	str	x2, [sp, #1920]
    c714:	97ffe4b0 	bl	59d4 <fwp_data.part.0.constprop.0>
    c718:	97ffe533 	bl	5be4 <fwp_rc_fresh>
    c71c:	aa0003e2 	mov	x2, x0
    c720:	911e23e1 	add	x1, sp, #0x788
    c724:	52800020 	mov	w0, #0x1                   	// #1
    c728:	f903c7f7 	str	x23, [sp, #1928]
    c72c:	f903cbe2 	str	x2, [sp, #1936]
    c730:	97ffe4a9 	bl	59d4 <fwp_data.part.0.constprop.0>
    c734:	97ffe52c 	bl	5be4 <fwp_rc_fresh>
    c738:	aa0003e2 	mov	x2, x0
    c73c:	911e63e1 	add	x1, sp, #0x798
    c740:	52800020 	mov	w0, #0x1                   	// #1
    c744:	f903cff5 	str	x21, [sp, #1944]
    c748:	f903d3e2 	str	x2, [sp, #1952]
    c74c:	97ffe4a2 	bl	59d4 <fwp_data.part.0.constprop.0>
    c750:	97ffe525 	bl	5be4 <fwp_rc_fresh>
    c754:	aa0003e2 	mov	x2, x0
    c758:	911ea3e1 	add	x1, sp, #0x7a8
    c75c:	52800020 	mov	w0, #0x1                   	// #1
    c760:	f903d7f7 	str	x23, [sp, #1960]
    c764:	f903dbe2 	str	x2, [sp, #1968]
    c768:	97ffe49b 	bl	59d4 <fwp_data.part.0.constprop.0>
    c76c:	97ffe51e 	bl	5be4 <fwp_rc_fresh>
    c770:	aa0003e2 	mov	x2, x0
    c774:	911ee3e1 	add	x1, sp, #0x7b8
    c778:	52800020 	mov	w0, #0x1                   	// #1
    c77c:	f903dff5 	str	x21, [sp, #1976]
    c780:	f903e3e2 	str	x2, [sp, #1984]
    c784:	97ffe494 	bl	59d4 <fwp_data.part.0.constprop.0>
    c788:	97ffe517 	bl	5be4 <fwp_rc_fresh>
    c78c:	aa0003e2 	mov	x2, x0
    c790:	911f23e1 	add	x1, sp, #0x7c8
    c794:	52800020 	mov	w0, #0x1                   	// #1
    c798:	f903e7f7 	str	x23, [sp, #1992]
    c79c:	f903ebe2 	str	x2, [sp, #2000]
    c7a0:	97ffe48d 	bl	59d4 <fwp_data.part.0.constprop.0>
    c7a4:	97ffe510 	bl	5be4 <fwp_rc_fresh>
    c7a8:	aa0003e2 	mov	x2, x0
    c7ac:	911f63e1 	add	x1, sp, #0x7d8
    c7b0:	52800020 	mov	w0, #0x1                   	// #1
    c7b4:	f903eff5 	str	x21, [sp, #2008]
    c7b8:	f903f3e2 	str	x2, [sp, #2016]
    c7bc:	97ffe486 	bl	59d4 <fwp_data.part.0.constprop.0>
    c7c0:	f949da81 	ldr	x1, [x20, #5040]
    c7c4:	aa0003f5 	mov	x21, x0
    c7c8:	f949ee80 	ldr	x0, [x20, #5080]
    c7cc:	cb0102a1 	sub	x1, x21, x1
    c7d0:	eb00403f 	cmp	x1, x0, lsl #16
    c7d4:	54000322 	b.cs	c838 <f0+0x2174>  // b.hs, b.nlast
    c7d8:	d350fc22 	lsr	x2, x1, #16
    c7dc:	f949fe83 	ldr	x3, [x20, #5112]
    c7e0:	8b020842 	add	x2, x2, x2, lsl #2
    c7e4:	d37df042 	lsl	x2, x2, #3
    c7e8:	8b020060 	add	x0, x3, x2
    c7ec:	f9401014 	ldr	x20, [x0, #32]
    c7f0:	b4000254 	cbz	x20, c838 <f0+0x2174>
    c7f4:	38626862 	ldrb	w2, [x3, x2]
    c7f8:	7100085f 	cmp	w2, #0x2
    c7fc:	540014a0 	b.eq	ca90 <f0+0x23cc>  // b.none
    c800:	7100045f 	cmp	w2, #0x1
    c804:	540001a1 	b.ne	c838 <f0+0x2174>  // b.any
    c808:	29430002 	ldp	w2, w0, [x0, #24]
    c80c:	92403c21 	and	x1, x1, #0xffff
    c810:	9b027c21 	mul	x1, x1, x2
    c814:	d360fc21 	lsr	x1, x1, #32
    c818:	eb00003f 	cmp	x1, x0
    c81c:	540000e2 	b.cs	c838 <f0+0x2174>  // b.hs, b.nlast
    c820:	8b010294 	add	x20, x20, x1
    c824:	39400280 	ldrb	w0, [x20]
    c828:	7103fc1f 	cmp	w0, #0xff
    c82c:	54001920 	b.eq	cb50 <f0+0x248c>  // b.none
    c830:	52800020 	mov	w0, #0x1                   	// #1
    c834:	39000280 	strb	w0, [x20]
    c838:	911fa3e1 	add	x1, sp, #0x7e8
    c83c:	b200e7f4 	mov	x20, #0x3333333333333333    	// #3689348814741910323
    c840:	f2f7fe74 	movk	x20, #0xbff3, lsl #48
    c844:	52800020 	mov	w0, #0x1                   	// #1
    c848:	f903f7f4 	str	x20, [sp, #2024]
    c84c:	f903fbf5 	str	x21, [sp, #2032]
    c850:	97ffe461 	bl	59d4 <fwp_data.part.0.constprop.0>
    c854:	97ffe4e4 	bl	5be4 <fwp_rc_fresh>
    c858:	aa0003e2 	mov	x2, x0
    c85c:	911fe3e1 	add	x1, sp, #0x7f8
    c860:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c864:	52800020 	mov	w0, #0x1                   	// #1
    c868:	f903fff5 	str	x21, [sp, #2040]
    c86c:	f90403e2 	str	x2, [sp, #2048]
    c870:	97ffe459 	bl	59d4 <fwp_data.part.0.constprop.0>
    c874:	97ffe4dc 	bl	5be4 <fwp_rc_fresh>
    c878:	aa0003e2 	mov	x2, x0
    c87c:	912023e1 	add	x1, sp, #0x808
    c880:	52800020 	mov	w0, #0x1                   	// #1
    c884:	f90407f4 	str	x20, [sp, #2056]
    c888:	f9040be2 	str	x2, [sp, #2064]
    c88c:	97ffe452 	bl	59d4 <fwp_data.part.0.constprop.0>
    c890:	97ffe4d5 	bl	5be4 <fwp_rc_fresh>
    c894:	aa0003e2 	mov	x2, x0
    c898:	912063e1 	add	x1, sp, #0x818
    c89c:	52800020 	mov	w0, #0x1                   	// #1
    c8a0:	f9040ff5 	str	x21, [sp, #2072]
    c8a4:	f90413e2 	str	x2, [sp, #2080]
    c8a8:	97ffe44b 	bl	59d4 <fwp_data.part.0.constprop.0>
    c8ac:	97ffe4ce 	bl	5be4 <fwp_rc_fresh>
    c8b0:	aa0003e2 	mov	x2, x0
    c8b4:	9120a3e1 	add	x1, sp, #0x828
    c8b8:	52800020 	mov	w0, #0x1                   	// #1
    c8bc:	f90417f4 	str	x20, [sp, #2088]
    c8c0:	f9041be2 	str	x2, [sp, #2096]
    c8c4:	97ffe444 	bl	59d4 <fwp_data.part.0.constprop.0>
    c8c8:	97ffe4c7 	bl	5be4 <fwp_rc_fresh>
    c8cc:	aa0003e2 	mov	x2, x0
    c8d0:	9120e3e1 	add	x1, sp, #0x838
    c8d4:	52800020 	mov	w0, #0x1                   	// #1
    c8d8:	f9041ff5 	str	x21, [sp, #2104]
    c8dc:	f90423e2 	str	x2, [sp, #2112]
    c8e0:	97ffe43d 	bl	59d4 <fwp_data.part.0.constprop.0>
    c8e4:	97ffe4c0 	bl	5be4 <fwp_rc_fresh>
    c8e8:	aa0003e2 	mov	x2, x0
    c8ec:	aa1603e1 	mov	x1, x22
    c8f0:	52800020 	mov	w0, #0x1                   	// #1
    c8f4:	f90427f4 	str	x20, [sp, #2120]
    c8f8:	f9042be2 	str	x2, [sp, #2128]
    c8fc:	97ffe436 	bl	59d4 <fwp_data.part.0.constprop.0>
    c900:	97ffe4b9 	bl	5be4 <fwp_rc_fresh>
    c904:	aa0003f5 	mov	x21, x0
    c908:	aa1303e1 	mov	x1, x19
    c90c:	97fff459 	bl	9a70 <fwp_hof0.constprop.0>
    c910:	aa0003f4 	mov	x20, x0
    c914:	aa1503e0 	mov	x0, x21
    c918:	97ffe616 	bl	6170 <fwp_drop0>
    c91c:	aa1303e0 	mov	x0, x19
    c920:	97ffe614 	bl	6170 <fwp_drop0>
    c924:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    c928:	f947f400 	ldr	x0, [x0, #4072]
    c92c:	f9442fe2 	ldr	x2, [sp, #2136]
    c930:	f9400001 	ldr	x1, [x0]
    c934:	eb010042 	subs	x2, x2, x1
    c938:	d2800001 	mov	x1, #0x0                   	// #0
    c93c:	54001f41 	b.ne	cd24 <f0+0x2660>  // b.any
    c940:	912183ff 	add	sp, sp, #0x860
    c944:	aa1403e0 	mov	x0, x20
    c948:	a94153f3 	ldp	x19, x20, [sp, #16]
    c94c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c950:	a94363f7 	ldp	x23, x24, [sp, #48]
    c954:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c958:	a94573fb 	ldp	x27, x28, [sp, #80]
    c95c:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c960:	d65f03c0 	ret
    c964:	aa1b03e0 	mov	x0, x27
    c968:	97ffe00a 	bl	4990 <fwp_rc_forget_slot>
    c96c:	17fff79f 	b	a7e8 <f0+0x124>
    c970:	72003c5f 	tst	w2, #0xffff
    c974:	54fef3c1 	b.ne	a7ec <f0+0x128>  // b.any
    c978:	17fff799 	b	a7dc <f0+0x118>
    c97c:	72003c3f 	tst	w1, #0xffff
    c980:	54ff8b01 	b.ne	bae0 <f0+0x141c>  // b.any
    c984:	17fffc52 	b	bacc <f0+0x1408>
    c988:	72003c3f 	tst	w1, #0xffff
    c98c:	54ff84e1 	b.ne	ba28 <f0+0x1364>  // b.any
    c990:	17fffc21 	b	ba14 <f0+0x1350>
    c994:	72003c3f 	tst	w1, #0xffff
    c998:	54ff7ec1 	b.ne	b970 <f0+0x12ac>  // b.any
    c99c:	17fffbf0 	b	b95c <f0+0x1298>
    c9a0:	72003c3f 	tst	w1, #0xffff
    c9a4:	54ff79c1 	b.ne	b8dc <f0+0x1218>  // b.any
    c9a8:	17fffbc8 	b	b8c8 <f0+0x1204>
    c9ac:	72003c3f 	tst	w1, #0xffff
    c9b0:	54ff6f41 	b.ne	b798 <f0+0x10d4>  // b.any
    c9b4:	17fffb74 	b	b784 <f0+0x10c0>
    c9b8:	72003c3f 	tst	w1, #0xffff
    c9bc:	54ff6761 	b.ne	b6a8 <f0+0xfe4>  // b.any
    c9c0:	17fffb35 	b	b694 <f0+0xfd0>
    c9c4:	72003c3f 	tst	w1, #0xffff
    c9c8:	54ff57a1 	b.ne	b4bc <f0+0xdf8>  // b.any
    c9cc:	17fffab7 	b	b4a8 <f0+0xde4>
    c9d0:	72003c3f 	tst	w1, #0xffff
    c9d4:	54ff5281 	b.ne	b424 <f0+0xd60>  // b.any
    c9d8:	17fffa8e 	b	b410 <f0+0xd4c>
    c9dc:	72003c3f 	tst	w1, #0xffff
    c9e0:	54ff02c1 	b.ne	aa38 <f0+0x374>  // b.any
    c9e4:	17fff810 	b	aa24 <f0+0x360>
    c9e8:	72003c3f 	tst	w1, #0xffff
    c9ec:	54fefce1 	b.ne	a988 <f0+0x2c4>  // b.any
    c9f0:	17fff7e1 	b	a974 <f0+0x2b0>
    c9f4:	72003c3f 	tst	w1, #0xffff
    c9f8:	54fef7e1 	b.ne	a8f4 <f0+0x230>  // b.any
    c9fc:	17fff7b9 	b	a8e0 <f0+0x21c>
    ca00:	72003c3f 	tst	w1, #0xffff
    ca04:	54ff1b61 	b.ne	ad70 <f0+0x6ac>  // b.any
    ca08:	17fff8d5 	b	ad5c <f0+0x698>
    ca0c:	72003c3f 	tst	w1, #0xffff
    ca10:	54ff1401 	b.ne	ac90 <f0+0x5cc>  // b.any
    ca14:	17fff89a 	b	ac7c <f0+0x5b8>
    ca18:	72003c3f 	tst	w1, #0xffff
    ca1c:	54ff0e21 	b.ne	abe0 <f0+0x51c>  // b.any
    ca20:	17fff86b 	b	abcc <f0+0x508>
    ca24:	72003c3f 	tst	w1, #0xffff
    ca28:	54ff0601 	b.ne	aae8 <f0+0x424>  // b.any
    ca2c:	17fff82a 	b	aad4 <f0+0x410>
    ca30:	72003c3f 	tst	w1, #0xffff
    ca34:	54ff49c1 	b.ne	b36c <f0+0xca8>  // b.any
    ca38:	17fffa48 	b	b358 <f0+0xc94>
    ca3c:	72003c3f 	tst	w1, #0xffff
    ca40:	54ff43a1 	b.ne	b2b4 <f0+0xbf0>  // b.any
    ca44:	17fffa17 	b	b2a0 <f0+0xbdc>
    ca48:	72003c3f 	tst	w1, #0xffff
    ca4c:	54ff3d81 	b.ne	b1fc <f0+0xb38>  // b.any
    ca50:	17fff9e6 	b	b1e8 <f0+0xb24>
    ca54:	72003c3f 	tst	w1, #0xffff
    ca58:	54ff3881 	b.ne	b168 <f0+0xaa4>  // b.any
    ca5c:	17fff9be 	b	b154 <f0+0xa90>
    ca60:	72003c3f 	tst	w1, #0xffff
    ca64:	54ff2e01 	b.ne	b024 <f0+0x960>  // b.any
    ca68:	17fff96a 	b	b010 <f0+0x94c>
    ca6c:	72003c3f 	tst	w1, #0xffff
    ca70:	54ff2921 	b.ne	af94 <f0+0x8d0>  // b.any
    ca74:	17fff943 	b	af80 <f0+0x8bc>
    ca78:	72003c3f 	tst	w1, #0xffff
    ca7c:	54ff2421 	b.ne	af00 <f0+0x83c>  // b.any
    ca80:	17fff91b 	b	aeec <f0+0x828>
    ca84:	72003c3f 	tst	w1, #0xffff
    ca88:	54ff1e41 	b.ne	ae50 <f0+0x78c>  // b.any
    ca8c:	17fff8ec 	b	ae3c <f0+0x778>
    ca90:	72003c3f 	tst	w1, #0xffff
    ca94:	54ffed21 	b.ne	c838 <f0+0x2174>  // b.any
    ca98:	17ffff63 	b	c824 <f0+0x2160>
    ca9c:	72003c3f 	tst	w1, #0xffff
    caa0:	54ffe1c1 	b.ne	c6d8 <f0+0x2014>  // b.any
    caa4:	17ffff08 	b	c6c4 <f0+0x2000>
    caa8:	72003c3f 	tst	w1, #0xffff
    caac:	54ffd741 	b.ne	c594 <f0+0x1ed0>  // b.any
    cab0:	17fffeb4 	b	c580 <f0+0x1ebc>
    cab4:	72003c3f 	tst	w1, #0xffff
    cab8:	54ffd221 	b.ne	c4fc <f0+0x1e38>  // b.any
    cabc:	17fffe8b 	b	c4e8 <f0+0x1e24>
    cac0:	72003c3f 	tst	w1, #0xffff
    cac4:	54ffcc01 	b.ne	c444 <f0+0x1d80>  // b.any
    cac8:	17fffe5a 	b	c430 <f0+0x1d6c>
    cacc:	72003c3f 	tst	w1, #0xffff
    cad0:	54ffc421 	b.ne	c354 <f0+0x1c90>  // b.any
    cad4:	17fffe1b 	b	c340 <f0+0x1c7c>
    cad8:	72003c3f 	tst	w1, #0xffff
    cadc:	54ffbf21 	b.ne	c2c0 <f0+0x1bfc>  // b.any
    cae0:	17fffdf3 	b	c2ac <f0+0x1be8>
    cae4:	72003c3f 	tst	w1, #0xffff
    cae8:	54ffb661 	b.ne	c1b4 <f0+0x1af0>  // b.any
    caec:	17fffdad 	b	c1a0 <f0+0x1adc>
    caf0:	72003c3f 	tst	w1, #0xffff
    caf4:	54ffb041 	b.ne	c0fc <f0+0x1a38>  // b.any
    caf8:	17fffd7c 	b	c0e8 <f0+0x1a24>
    cafc:	72003c3f 	tst	w1, #0xffff
    cb00:	54ffab41 	b.ne	c068 <f0+0x19a4>  // b.any
    cb04:	17fffd54 	b	c054 <f0+0x1990>
    cb08:	72003c3f 	tst	w1, #0xffff
    cb0c:	54ffa621 	b.ne	bfd0 <f0+0x190c>  // b.any
    cb10:	17fffd2b 	b	bfbc <f0+0x18f8>
    cb14:	72003c3f 	tst	w1, #0xffff
    cb18:	54ffa001 	b.ne	bf18 <f0+0x1854>  // b.any
    cb1c:	17fffcfa 	b	bf04 <f0+0x1840>
    cb20:	72003c3f 	tst	w1, #0xffff
    cb24:	54ff9821 	b.ne	be28 <f0+0x1764>  // b.any
    cb28:	17fffcbb 	b	be14 <f0+0x1750>
    cb2c:	72003c3f 	tst	w1, #0xffff
    cb30:	54ff9321 	b.ne	bd94 <f0+0x16d0>  // b.any
    cb34:	17fffc93 	b	bd80 <f0+0x16bc>
    cb38:	72003c3f 	tst	w1, #0xffff
    cb3c:	54ff8c21 	b.ne	bcc0 <f0+0x15fc>  // b.any
    cb40:	17fffc5b 	b	bcac <f0+0x15e8>
    cb44:	72003c3f 	tst	w1, #0xffff
    cb48:	54ff8441 	b.ne	bbd0 <f0+0x150c>  // b.any
    cb4c:	17fffc1c 	b	bbbc <f0+0x14f8>
    cb50:	aa1403e0 	mov	x0, x20
    cb54:	97ffdf8f 	bl	4990 <fwp_rc_forget_slot>
    cb58:	17ffff36 	b	c830 <f0+0x216c>
    cb5c:	aa1703e0 	mov	x0, x23
    cb60:	97ffdf8c 	bl	4990 <fwp_rc_forget_slot>
    cb64:	17fff762 	b	a8ec <f0+0x228>
    cb68:	aa1703e0 	mov	x0, x23
    cb6c:	97ffdf89 	bl	4990 <fwp_rc_forget_slot>
    cb70:	17fff784 	b	a980 <f0+0x2bc>
    cb74:	aa1703e0 	mov	x0, x23
    cb78:	97ffdf86 	bl	4990 <fwp_rc_forget_slot>
    cb7c:	17fff7ad 	b	aa30 <f0+0x36c>
    cb80:	aa1703e0 	mov	x0, x23
    cb84:	97ffdf83 	bl	4990 <fwp_rc_forget_slot>
    cb88:	17fff7d6 	b	aae0 <f0+0x41c>
    cb8c:	aa1703e0 	mov	x0, x23
    cb90:	97ffdf80 	bl	4990 <fwp_rc_forget_slot>
    cb94:	17fff811 	b	abd8 <f0+0x514>
    cb98:	aa1703e0 	mov	x0, x23
    cb9c:	97ffdf7d 	bl	4990 <fwp_rc_forget_slot>
    cba0:	17fff83a 	b	ac88 <f0+0x5c4>
    cba4:	aa1703e0 	mov	x0, x23
    cba8:	97ffdf7a 	bl	4990 <fwp_rc_forget_slot>
    cbac:	17fff86f 	b	ad68 <f0+0x6a4>
    cbb0:	aa1703e0 	mov	x0, x23
    cbb4:	97ffdf77 	bl	4990 <fwp_rc_forget_slot>
    cbb8:	17fff8a4 	b	ae48 <f0+0x784>
    cbbc:	aa1703e0 	mov	x0, x23
    cbc0:	97ffdf74 	bl	4990 <fwp_rc_forget_slot>
    cbc4:	17fff8cd 	b	aef8 <f0+0x834>
    cbc8:	aa1703e0 	mov	x0, x23
    cbcc:	97ffdf71 	bl	4990 <fwp_rc_forget_slot>
    cbd0:	17fff8ef 	b	af8c <f0+0x8c8>
    cbd4:	aa1503e0 	mov	x0, x21
    cbd8:	97ffdf6e 	bl	4990 <fwp_rc_forget_slot>
    cbdc:	17fff910 	b	b01c <f0+0x958>
    cbe0:	aa1703e0 	mov	x0, x23
    cbe4:	97ffdf6b 	bl	4990 <fwp_rc_forget_slot>
    cbe8:	17fff95e 	b	b160 <f0+0xa9c>
    cbec:	aa1703e0 	mov	x0, x23
    cbf0:	97ffdf68 	bl	4990 <fwp_rc_forget_slot>
    cbf4:	17fff980 	b	b1f4 <f0+0xb30>
    cbf8:	aa1703e0 	mov	x0, x23
    cbfc:	97ffdf65 	bl	4990 <fwp_rc_forget_slot>
    cc00:	17fff9ab 	b	b2ac <f0+0xbe8>
    cc04:	aa1703e0 	mov	x0, x23
    cc08:	97ffdf62 	bl	4990 <fwp_rc_forget_slot>
    cc0c:	17fff9d6 	b	b364 <f0+0xca0>
    cc10:	aa1703e0 	mov	x0, x23
    cc14:	97ffdf5f 	bl	4990 <fwp_rc_forget_slot>
    cc18:	17fffa01 	b	b41c <f0+0xd58>
    cc1c:	aa1503e0 	mov	x0, x21
    cc20:	97ffdf5c 	bl	4990 <fwp_rc_forget_slot>
    cc24:	17fffa24 	b	b4b4 <f0+0xdf0>
    cc28:	aa1703e0 	mov	x0, x23
    cc2c:	97ffdf59 	bl	4990 <fwp_rc_forget_slot>
    cc30:	17fffa9c 	b	b6a0 <f0+0xfdc>
    cc34:	aa1503e0 	mov	x0, x21
    cc38:	97ffdf56 	bl	4990 <fwp_rc_forget_slot>
    cc3c:	17fffad5 	b	b790 <f0+0x10cc>
    cc40:	aa1703e0 	mov	x0, x23
    cc44:	97ffdf53 	bl	4990 <fwp_rc_forget_slot>
    cc48:	17fffb23 	b	b8d4 <f0+0x1210>
    cc4c:	aa1703e0 	mov	x0, x23
    cc50:	97ffdf50 	bl	4990 <fwp_rc_forget_slot>
    cc54:	17fffb45 	b	b968 <f0+0x12a4>
    cc58:	aa1703e0 	mov	x0, x23
    cc5c:	97ffdf4d 	bl	4990 <fwp_rc_forget_slot>
    cc60:	17fffb70 	b	ba20 <f0+0x135c>
    cc64:	aa1703e0 	mov	x0, x23
    cc68:	97ffdf4a 	bl	4990 <fwp_rc_forget_slot>
    cc6c:	17fffb9b 	b	bad8 <f0+0x1414>
    cc70:	aa1703e0 	mov	x0, x23
    cc74:	97ffdf47 	bl	4990 <fwp_rc_forget_slot>
    cc78:	17fffbd4 	b	bbc8 <f0+0x1504>
    cc7c:	aa1703e0 	mov	x0, x23
    cc80:	97ffdf44 	bl	4990 <fwp_rc_forget_slot>
    cc84:	17fffc0d 	b	bcb8 <f0+0x15f4>
    cc88:	aa1703e0 	mov	x0, x23
    cc8c:	97ffdf41 	bl	4990 <fwp_rc_forget_slot>
    cc90:	17fffc3f 	b	bd8c <f0+0x16c8>
    cc94:	aa1703e0 	mov	x0, x23
    cc98:	97ffdf3e 	bl	4990 <fwp_rc_forget_slot>
    cc9c:	17fffc61 	b	be20 <f0+0x175c>
    cca0:	aa1703e0 	mov	x0, x23
    cca4:	97ffdf3b 	bl	4990 <fwp_rc_forget_slot>
    cca8:	17fffc9a 	b	bf10 <f0+0x184c>
    ccac:	aa1703e0 	mov	x0, x23
    ccb0:	97ffdf38 	bl	4990 <fwp_rc_forget_slot>
    ccb4:	17fffcc5 	b	bfc8 <f0+0x1904>
    ccb8:	aa1703e0 	mov	x0, x23
    ccbc:	97ffdf35 	bl	4990 <fwp_rc_forget_slot>
    ccc0:	17fffce8 	b	c060 <f0+0x199c>
    ccc4:	aa1703e0 	mov	x0, x23
    ccc8:	97ffdf32 	bl	4990 <fwp_rc_forget_slot>
    cccc:	17fffd0a 	b	c0f4 <f0+0x1a30>
    ccd0:	aa1703e0 	mov	x0, x23
    ccd4:	97ffdf2f 	bl	4990 <fwp_rc_forget_slot>
    ccd8:	17fffd35 	b	c1ac <f0+0x1ae8>
    ccdc:	aa1703e0 	mov	x0, x23
    cce0:	97ffdf2c 	bl	4990 <fwp_rc_forget_slot>
    cce4:	17fffd75 	b	c2b8 <f0+0x1bf4>
    cce8:	aa1703e0 	mov	x0, x23
    ccec:	97ffdf29 	bl	4990 <fwp_rc_forget_slot>
    ccf0:	17fffd97 	b	c34c <f0+0x1c88>
    ccf4:	aa1703e0 	mov	x0, x23
    ccf8:	97ffdf26 	bl	4990 <fwp_rc_forget_slot>
    ccfc:	17fffdd0 	b	c43c <f0+0x1d78>
    cd00:	aa1703e0 	mov	x0, x23
    cd04:	97ffdf23 	bl	4990 <fwp_rc_forget_slot>
    cd08:	17fffdfb 	b	c4f4 <f0+0x1e30>
    cd0c:	aa1503e0 	mov	x0, x21
    cd10:	97ffdf20 	bl	4990 <fwp_rc_forget_slot>
    cd14:	17fffe1e 	b	c58c <f0+0x1ec8>
    cd18:	aa1703e0 	mov	x0, x23
    cd1c:	97ffdf1d 	bl	4990 <fwp_rc_forget_slot>
    cd20:	17fffe6c 	b	c6d0 <f0+0x200c>
    cd24:	97ffd6bb 	bl	2810 <__stack_chk_fail@plt>
    cd28:	d503201f 	nop
    cd2c:	d503201f 	nop

000000000000cd30 <fwp_main_thread>:
    cd30:	d10443ff 	sub	sp, sp, #0x110
    cd34:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    cd38:	f947f400 	ldr	x0, [x0, #4072]
    cd3c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    cd40:	910303fd 	add	x29, sp, #0xc0
    cd44:	a90e5bf5 	stp	x21, x22, [sp, #224]
    cd48:	b0000376 	adrp	x22, 79000 <fwp_root_context+0xba0>
    cd4c:	911902c1 	add	x1, x22, #0x640
    cd50:	a90d53f3 	stp	x19, x20, [sp, #208]
    cd54:	a90f63f7 	stp	x23, x24, [sp, #240]
    cd58:	b953a421 	ldr	w1, [x1, #5028]
    cd5c:	a9106bf9 	stp	x25, x26, [sp, #256]
    cd60:	f9400002 	ldr	x2, [x0]
    cd64:	f9005fe2 	str	x2, [sp, #184]
    cd68:	d2800002 	mov	x2, #0x0                   	// #0
    cd6c:	34002961 	cbz	w1, d298 <fwp_main_thread+0x568>
    cd70:	911902c0 	add	x0, x22, #0x640
    cd74:	b953a800 	ldr	w0, [x0, #5032]
    cd78:	35002880 	cbnz	w0, d288 <fwp_main_thread+0x558>
    cd7c:	91001fe2 	add	x2, sp, #0x7
    cd80:	900000b5 	adrp	x21, 20000 <__data_start>
    cd84:	900000a3 	adrp	x3, 20000 <__data_start>
    cd88:	910182b3 	add	x19, x21, #0x60
    cd8c:	91118063 	add	x3, x3, #0x460
    cd90:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    cd94:	d2a00025 	mov	x5, #0x10000               	// #65536
    cd98:	910023e0 	add	x0, sp, #0x8
    cd9c:	d2800001 	mov	x1, #0x0                   	// #0
    cda0:	f90007e3 	str	x3, [sp, #8]
    cda4:	b90013ff 	str	wzr, [sp, #16]
    cda8:	f9000fe5 	str	x5, [sp, #24]
    cdac:	a90a1262 	stp	x2, x4, [x19, #160]
    cdb0:	97ffd630 	bl	2670 <sigaltstack@plt>
    cdb4:	350028a0 	cbnz	w0, d2c8 <fwp_main_thread+0x598>
    cdb8:	4f000400 	movi	v0.4s, #0x0
    cdbc:	9100a3e0 	add	x0, sp, #0x28
    cdc0:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0xc>
    cdc4:	52800082 	mov	w2, #0x4                   	// #4
    cdc8:	9100c021 	add	x1, x1, #0x30
    cdcc:	72a10002 	movk	w2, #0x800, lsl #16
    cdd0:	910083f4 	add	x20, sp, #0x20
    cdd4:	f90013e1 	str	x1, [sp, #32]
    cdd8:	3d802000 	str	q0, [x0, #128]
    cddc:	b900abe2 	str	w2, [sp, #168]
    cde0:	ad000000 	stp	q0, q0, [x0]
    cde4:	ad010000 	stp	q0, q0, [x0, #32]
    cde8:	ad020000 	stp	q0, q0, [x0, #64]
    cdec:	ad030000 	stp	q0, q0, [x0, #96]
    cdf0:	97ffd678 	bl	27d0 <sigemptyset@plt>
    cdf4:	350026a0 	cbnz	w0, d2c8 <fwp_main_thread+0x598>
    cdf8:	aa1403e1 	mov	x1, x20
    cdfc:	d2800002 	mov	x2, #0x0                   	// #0
    ce00:	52800160 	mov	w0, #0xb                   	// #11
    ce04:	97ffd68b 	bl	2830 <sigaction@plt>
    ce08:	35002600 	cbnz	w0, d2c8 <fwp_main_thread+0x598>
    ce0c:	aa1403e1 	mov	x1, x20
    ce10:	d2800002 	mov	x2, #0x0                   	// #0
    ce14:	528000e0 	mov	w0, #0x7                   	// #7
    ce18:	97ffd686 	bl	2830 <sigaction@plt>
    ce1c:	35002560 	cbnz	w0, d2c8 <fwp_main_thread+0x598>
    ce20:	911902c1 	add	x1, x22, #0x640
    ce24:	52800034 	mov	w20, #0x1                   	// #1
    ce28:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    ce2c:	910cc000 	add	x0, x0, #0x330
    ce30:	b9013274 	str	w20, [x19, #304]
    ce34:	fd4a1020 	ldr	d0, [x1, #5152]
    ce38:	7e61d800 	ucvtf	d0, d0
    ce3c:	fd00a660 	str	d0, [x19, #328]
    ce40:	940002e8 	bl	d9e0 <atexit>
    ce44:	35002480 	cbnz	w0, d2d4 <fwp_main_thread+0x5a4>
    ce48:	b943ca60 	ldr	w0, [x19, #968]
    ce4c:	340022a0 	cbz	w0, d2a0 <fwp_main_thread+0x570>
    ce50:	910182ba 	add	x26, x21, #0x60
    ce54:	f9404f54 	ldr	x20, [x26, #152]
    ce58:	b40010b4 	cbz	x20, d06c <fwp_main_thread+0x33c>
    ce5c:	aa1403f3 	mov	x19, x20
    ce60:	91010297 	add	x23, x20, #0x40
    ce64:	39414a99 	ldrb	w25, [x20, #82]
    ce68:	52800038 	mov	w24, #0x1                   	// #1
    ce6c:	39014a98 	strb	w24, [x20, #82]
    ce70:	f9401680 	ldr	x0, [x20, #40]
    ce74:	b4000620 	cbz	x0, cf38 <fwp_main_thread+0x208>
    ce78:	f9403281 	ldr	x1, [x20, #96]
    ce7c:	39414680 	ldrb	w0, [x20, #81]
    ce80:	b4000b41 	cbz	x1, cfe8 <fwp_main_thread+0x2b8>
    ce84:	36000a80 	tbz	w0, #0, cfd4 <fwp_main_thread+0x2a4>
    ce88:	39414a62 	ldrb	w2, [x19, #82]
    ce8c:	f9402280 	ldr	x0, [x20, #64]
    ce90:	37000d62 	tbnz	w2, #0, d03c <fwp_main_thread+0x30c>
    ce94:	f9403261 	ldr	x1, [x19, #96]
    ce98:	a911fe77 	stp	x23, xzr, [x19, #280]
    ce9c:	f9009660 	str	x0, [x19, #296]
    cea0:	b4000040 	cbz	x0, cea8 <fwp_main_thread+0x178>
    cea4:	f9009013 	str	x19, [x0, #288]
    cea8:	f9002293 	str	x19, [x20, #64]
    ceac:	b4000101 	cbz	x1, cecc <fwp_main_thread+0x19c>
    ceb0:	f9409740 	ldr	x0, [x26, #296]
    ceb4:	39015678 	strb	w24, [x19, #85]
    ceb8:	f9003661 	str	x1, [x19, #104]
    cebc:	a910827f 	stp	xzr, x0, [x19, #264]
    cec0:	b4000040 	cbz	x0, cec8 <fwp_main_thread+0x198>
    cec4:	f9008413 	str	x19, [x0, #264]
    cec8:	f9009753 	str	x19, [x26, #296]
    cecc:	39015a7f 	strb	wzr, [x19, #86]
    ced0:	97ffe6e5 	bl	6a64 <fwp_block>
    ced4:	f9408e62 	ldr	x2, [x19, #280]
    ced8:	b4000142 	cbz	x2, cf00 <fwp_main_thread+0x1d0>
    cedc:	a9520261 	ldp	x1, x0, [x19, #288]
    cee0:	b4000ba1 	cbz	x1, d054 <fwp_main_thread+0x324>
    cee4:	f9009420 	str	x0, [x1, #296]
    cee8:	f9409660 	ldr	x0, [x19, #296]
    ceec:	b4000040 	cbz	x0, cef4 <fwp_main_thread+0x1c4>
    cef0:	f9009001 	str	x1, [x0, #288]
    cef4:	91080260 	add	x0, x19, #0x200
    cef8:	f900967f 	str	xzr, [x19, #296]
    cefc:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    cf00:	39415660 	ldrb	w0, [x19, #85]
    cf04:	f9404f42 	ldr	x2, [x26, #152]
    cf08:	36000960 	tbz	w0, #0, d034 <fwp_main_thread+0x304>
    cf0c:	a9508261 	ldp	x1, x0, [x19, #264]
    cf10:	b4000a61 	cbz	x1, d05c <fwp_main_thread+0x32c>
    cf14:	f9008820 	str	x0, [x1, #272]
    cf18:	b4000040 	cbz	x0, cf20 <fwp_main_thread+0x1f0>
    cf1c:	f9008401 	str	x1, [x0, #264]
    cf20:	91080260 	add	x0, x19, #0x200
    cf24:	3901567f 	strb	wzr, [x19, #85]
    cf28:	aa0203f3 	mov	x19, x2
    cf2c:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    cf30:	f9401680 	ldr	x0, [x20, #40]
    cf34:	b5fffa20 	cbnz	x0, ce78 <fwp_main_thread+0x148>
    cf38:	910182a0 	add	x0, x21, #0x60
    cf3c:	39014a99 	strb	w25, [x20, #82]
    cf40:	f941d400 	ldr	x0, [x0, #936]
    cf44:	b4001840 	cbz	x0, d24c <fwp_main_thread+0x51c>
    cf48:	910182a0 	add	x0, x21, #0x60
    cf4c:	f941f001 	ldr	x1, [x0, #992]
    cf50:	b903d81f 	str	wzr, [x0, #984]
    cf54:	eb13003f 	cmp	x1, x19
    cf58:	54001961 	b.ne	d284 <fwp_main_thread+0x554>  // b.any
    cf5c:	b4000933 	cbz	x19, d080 <fwp_main_thread+0x350>
    cf60:	910182a0 	add	x0, x21, #0x60
    cf64:	52800021 	mov	w1, #0x1                   	// #1
    cf68:	39014a61 	strb	w1, [x19, #82]
    cf6c:	f941c005 	ldr	x5, [x0, #896]
    cf70:	b4000885 	cbz	x5, d080 <fwp_main_thread+0x350>
    cf74:	d503201f 	nop
    cf78:	394140a0 	ldrb	w0, [x5, #80]
    cf7c:	37000060 	tbnz	w0, #0, cf88 <fwp_main_thread+0x258>
    cf80:	aa0503e0 	mov	x0, x5
    cf84:	97ffd9bb 	bl	3670 <fwp_cancel_tree.part.0>
    cf88:	f9409ca5 	ldr	x5, [x5, #312]
    cf8c:	b5ffff65 	cbnz	x5, cf78 <fwp_main_thread+0x248>
    cf90:	910182b4 	add	x20, x21, #0x60
    cf94:	52800037 	mov	w23, #0x1                   	// #1
    cf98:	f9402a60 	ldr	x0, [x19, #80]
    cf9c:	f2001c1f 	tst	x0, #0xff000000ff
    cfa0:	540000e1 	b.ne	cfbc <fwp_main_thread+0x28c>  // b.any
    cfa4:	f9406280 	ldr	x0, [x20, #192]
    cfa8:	39015277 	strb	w23, [x19, #84]
    cfac:	f900827f 	str	xzr, [x19, #256]
    cfb0:	b40005a0 	cbz	x0, d064 <fwp_main_thread+0x334>
    cfb4:	f9008013 	str	x19, [x0, #256]
    cfb8:	f9006293 	str	x19, [x20, #192]
    cfbc:	97ffe6aa 	bl	6a64 <fwp_block>
    cfc0:	97ffe63c 	bl	68b0 <fwp_free_zombie>
    cfc4:	f941c280 	ldr	x0, [x20, #896]
    cfc8:	b40005c0 	cbz	x0, d080 <fwp_main_thread+0x350>
    cfcc:	f941f293 	ldr	x19, [x20, #992]
    cfd0:	17fffff2 	b	cf98 <fwp_main_thread+0x268>
    cfd4:	97ffda4b 	bl	3900 <fwp_now_ns>
    cfd8:	f9403281 	ldr	x1, [x20, #96]
    cfdc:	eb01001f 	cmp	x0, x1
    cfe0:	5400128a 	b.ge	d230 <fwp_main_thread+0x500>  // b.tcont
    cfe4:	39414680 	ldrb	w0, [x20, #81]
    cfe8:	39414a62 	ldrb	w2, [x19, #82]
    cfec:	3707f500 	tbnz	w0, #0, ce8c <fwp_main_thread+0x15c>
    cff0:	f9403281 	ldr	x1, [x20, #96]
    cff4:	370001c2 	tbnz	w2, #0, d02c <fwp_main_thread+0x2fc>
    cff8:	f9403260 	ldr	x0, [x19, #96]
    cffc:	b4000180 	cbz	x0, d02c <fwp_main_thread+0x2fc>
    d000:	b4000061 	cbz	x1, d00c <fwp_main_thread+0x2dc>
    d004:	eb01001f 	cmp	x0, x1
    d008:	9a81d000 	csel	x0, x0, x1, le
    d00c:	f9402281 	ldr	x1, [x20, #64]
    d010:	a911fe77 	stp	x23, xzr, [x19, #280]
    d014:	f9009661 	str	x1, [x19, #296]
    d018:	b40014c1 	cbz	x1, d2b0 <fwp_main_thread+0x580>
    d01c:	f9009033 	str	x19, [x1, #288]
    d020:	aa0003e1 	mov	x1, x0
    d024:	f9002293 	str	x19, [x20, #64]
    d028:	17ffffa2 	b	ceb0 <fwp_main_thread+0x180>
    d02c:	f9402280 	ldr	x0, [x20, #64]
    d030:	17ffff9a 	b	ce98 <fwp_main_thread+0x168>
    d034:	aa0203f3 	mov	x19, x2
    d038:	17ffff8e 	b	ce70 <fwp_main_thread+0x140>
    d03c:	a911fe77 	stp	x23, xzr, [x19, #280]
    d040:	f9009660 	str	x0, [x19, #296]
    d044:	b4000040 	cbz	x0, d04c <fwp_main_thread+0x31c>
    d048:	f9009013 	str	x19, [x0, #288]
    d04c:	f9002293 	str	x19, [x20, #64]
    d050:	17ffff9f 	b	cecc <fwp_main_thread+0x19c>
    d054:	f9000040 	str	x0, [x2]
    d058:	17ffffa5 	b	ceec <fwp_main_thread+0x1bc>
    d05c:	f9009740 	str	x0, [x26, #296]
    d060:	17ffffae 	b	cf18 <fwp_main_thread+0x1e8>
    d064:	f9006693 	str	x19, [x20, #200]
    d068:	17ffffd4 	b	cfb8 <fwp_main_thread+0x288>
    d06c:	f941d740 	ldr	x0, [x26, #936]
    d070:	b4000ec0 	cbz	x0, d248 <fwp_main_thread+0x518>
    d074:	f941f340 	ldr	x0, [x26, #992]
    d078:	b903db5f 	str	wzr, [x26, #984]
    d07c:	b5001040 	cbnz	x0, d284 <fwp_main_thread+0x554>
    d080:	910182b4 	add	x20, x21, #0x60
    d084:	97ffe60b 	bl	68b0 <fwp_free_zombie>
    d088:	f9406680 	ldr	x0, [x20, #200]
    d08c:	b5000fc0 	cbnz	x0, d284 <fwp_main_thread+0x554>
    d090:	f9409680 	ldr	x0, [x20, #296]
    d094:	b5000f80 	cbnz	x0, d284 <fwp_main_thread+0x554>
    d098:	b9417293 	ldr	w19, [x20, #368]
    d09c:	340001d3 	cbz	w19, d0d4 <fwp_main_thread+0x3a4>
    d0a0:	93407e77 	sxtw	x23, w19
    d0a4:	51000673 	sub	w19, w19, #0x1
    d0a8:	d1000af7 	sub	x23, x23, #0x2
    d0ac:	91060298 	add	x24, x20, #0x180
    d0b0:	cb3342f7 	sub	x23, x23, w19, uxtw
    d0b4:	93407e73 	sxtw	x19, w19
    d0b8:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    d0bc:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    d0c0:	b9017293 	str	w19, [x20, #368]
    d0c4:	d1000673 	sub	x19, x19, #0x1
    d0c8:	97ffd61a 	bl	2930 <munmap@plt>
    d0cc:	eb1302ff 	cmp	x23, x19
    d0d0:	54ffff41 	b.ne	d0b8 <fwp_main_thread+0x388>  // b.any
    d0d4:	f0000093 	adrp	x19, 20000 <__data_start>
    d0d8:	91004260 	add	x0, x19, #0x10
    d0dc:	b9403000 	ldr	w0, [x0, #48]
    d0e0:	37f80040 	tbnz	w0, #31, d0e8 <fwp_main_thread+0x3b8>
    d0e4:	97ffd5cf 	bl	2820 <close@plt>
    d0e8:	910182a0 	add	x0, x21, #0x60
    d0ec:	91004261 	add	x1, x19, #0x10
    d0f0:	12800002 	mov	w2, #0xffffffff            	// #-1
    d0f4:	d2800013 	mov	x19, #0x0                   	// #0
    d0f8:	f941f417 	ldr	x23, [x0, #1000]
    d0fc:	b9003022 	str	w2, [x1, #48]
    d100:	f941f814 	ldr	x20, [x0, #1008]
    d104:	b4000177 	cbz	x23, d130 <fwp_main_thread+0x400>
    d108:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    d10c:	b40000c0 	cbz	x0, d124 <fwp_main_thread+0x3f4>
    d110:	f9400001 	ldr	x1, [x0]
    d114:	b5000b81 	cbnz	x1, d284 <fwp_main_thread+0x554>
    d118:	f9400401 	ldr	x1, [x0, #8]
    d11c:	b5000b41 	cbnz	x1, d284 <fwp_main_thread+0x554>
    d120:	97ffdebc 	bl	4c10 <fwp_mem_free>
    d124:	91000673 	add	x19, x19, #0x1
    d128:	eb1302ff 	cmp	x23, x19
    d12c:	54fffee1 	b.ne	d108 <fwp_main_thread+0x3d8>  // b.any
    d130:	aa1403e0 	mov	x0, x20
    d134:	97ffdeb7 	bl	4c10 <fwp_mem_free>
    d138:	910182a0 	add	x0, x21, #0x60
    d13c:	f941f013 	ldr	x19, [x0, #992]
    d140:	f901f41f 	str	xzr, [x0, #1000]
    d144:	f901f81f 	str	xzr, [x0, #1008]
    d148:	b40001f3 	cbz	x19, d184 <fwp_main_thread+0x454>
    d14c:	f9401661 	ldr	x1, [x19, #40]
    d150:	b50009a1 	cbnz	x1, d284 <fwp_main_thread+0x554>
    d154:	f9405661 	ldr	x1, [x19, #168]
    d158:	b5000961 	cbnz	x1, d284 <fwp_main_thread+0x554>
    d15c:	f941d401 	ldr	x1, [x0, #936]
    d160:	b5000921 	cbnz	x1, d284 <fwp_main_thread+0x554>
    d164:	f941dc00 	ldr	x0, [x0, #952]
    d168:	b50008e0 	cbnz	x0, d284 <fwp_main_thread+0x554>
    d16c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    d170:	f0000340 	adrp	x0, 78000 <ad_raw_blocks+0x17ba0>
    d174:	91118000 	add	x0, x0, #0x460
    d178:	97ffd59a 	bl	27e0 <memset@plt>
    d17c:	aa1303e0 	mov	x0, x19
    d180:	97ffdea4 	bl	4c10 <fwp_mem_free>
    d184:	910182a6 	add	x6, x21, #0x60
    d188:	911902d6 	add	x22, x22, #0x640
    d18c:	3dc01aa1 	ldr	q1, [x21, #96]
    d190:	52800041 	mov	w1, #0x2                   	// #2
    d194:	3dc004c2 	ldr	q2, [x6, #16]
    d198:	b0000002 	adrp	x2, e000 <_IO_stdin_used+0x5f0>
    d19c:	fd4a12c0 	ldr	d0, [x22, #5152]
    d1a0:	91092042 	add	x2, x2, #0x248
    d1a4:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    d1a8:	fd40a4c1 	ldr	d1, [x6, #328]
    d1ac:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d1b0:	f947e800 	ldr	x0, [x0, #4048]
    d1b4:	7e61d800 	ucvtf	d0, d0
    d1b8:	a95390c3 	ldp	x3, x4, [x6, #312]
    d1bc:	f9004cdf 	str	xzr, [x6, #152]
    d1c0:	f9400000 	ldr	x0, [x0]
    d1c4:	1e613801 	fsub	d1, d0, d1
    d1c8:	f940acc5 	ldr	x5, [x6, #344]
    d1cc:	b90130df 	str	wzr, [x6, #304]
    d1d0:	5ef1b842 	addp	d2, v2.2d
    d1d4:	fd40a8c0 	ldr	d0, [x6, #336]
    d1d8:	f901f0df 	str	xzr, [x6, #992]
    d1dc:	fd0058c2 	str	d2, [x6, #176]
    d1e0:	97ffd5a8 	bl	2880 <__fprintf_chk@plt>
    d1e4:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d1e8:	f947ec00 	ldr	x0, [x0, #4056]
    d1ec:	f9400000 	ldr	x0, [x0]
    d1f0:	97ffd5d4 	bl	2940 <fflush@plt>
    d1f4:	d0000080 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    d1f8:	f947f400 	ldr	x0, [x0, #4072]
    d1fc:	f9405fe2 	ldr	x2, [sp, #184]
    d200:	f9400001 	ldr	x1, [x0]
    d204:	eb010042 	subs	x2, x2, x1
    d208:	d2800001 	mov	x1, #0x0                   	// #0
    d20c:	540006a1 	b.ne	d2e0 <fwp_main_thread+0x5b0>  // b.any
    d210:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    d214:	d2800000 	mov	x0, #0x0                   	// #0
    d218:	a94d53f3 	ldp	x19, x20, [sp, #208]
    d21c:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    d220:	a94f63f7 	ldp	x23, x24, [sp, #240]
    d224:	a9506bf9 	ldp	x25, x26, [sp, #256]
    d228:	910443ff 	add	sp, sp, #0x110
    d22c:	d65f03c0 	ret
    d230:	39414280 	ldrb	w0, [x20, #80]
    d234:	3707ed80 	tbnz	w0, #0, cfe4 <fwp_main_thread+0x2b4>
    d238:	aa1403e0 	mov	x0, x20
    d23c:	97ffd90d 	bl	3670 <fwp_cancel_tree.part.0>
    d240:	39414680 	ldrb	w0, [x20, #81]
    d244:	17ffff69 	b	cfe8 <fwp_main_thread+0x2b8>
    d248:	d2800013 	mov	x19, #0x0                   	// #0
    d24c:	910182b4 	add	x20, x21, #0x60
    d250:	f941de80 	ldr	x0, [x20, #952]
    d254:	b5ffe7a0 	cbnz	x0, cf48 <fwp_main_thread+0x218>
    d258:	f941d280 	ldr	x0, [x20, #928]
    d25c:	97ffde6d 	bl	4c10 <fwp_mem_free>
    d260:	f901d29f 	str	xzr, [x20, #928]
    d264:	f901da9f 	str	xzr, [x20, #944]
    d268:	f941f280 	ldr	x0, [x20, #992]
    d26c:	b4000293 	cbz	x19, d2bc <fwp_main_thread+0x58c>
    d270:	f900567f 	str	xzr, [x19, #168]
    d274:	f9005e7f 	str	xzr, [x19, #184]
    d278:	b903da9f 	str	wzr, [x20, #984]
    d27c:	eb13001f 	cmp	x0, x19
    d280:	54ffe700 	b.eq	cf60 <fwp_main_thread+0x230>  // b.none
    d284:	97ffd577 	bl	2860 <abort@plt>
    d288:	d0ffffa0 	adrp	x0, 3000 <fwp_flush+0xc>
    d28c:	913c8000 	add	x0, x0, #0xf20
    d290:	940001d4 	bl	d9e0 <atexit>
    d294:	17fffeba 	b	cd7c <fwp_main_thread+0x4c>
    d298:	97ffdb7b 	bl	4084 <fwp_heap_init>
    d29c:	17fffeb5 	b	cd70 <fwp_main_thread+0x40>
    d2a0:	97fff509 	bl	a6c4 <f0>
    d2a4:	b903ca74 	str	w20, [x19, #968]
    d2a8:	f901ea60 	str	x0, [x19, #976]
    d2ac:	17fffee9 	b	ce50 <fwp_main_thread+0x120>
    d2b0:	aa0003e1 	mov	x1, x0
    d2b4:	f9002293 	str	x19, [x20, #64]
    d2b8:	17fffefe 	b	ceb0 <fwp_main_thread+0x180>
    d2bc:	b903da9f 	str	wzr, [x20, #984]
    d2c0:	b4ffee00 	cbz	x0, d080 <fwp_main_thread+0x350>
    d2c4:	97ffd567 	bl	2860 <abort@plt>
    d2c8:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    d2cc:	91080000 	add	x0, x0, #0x200
    d2d0:	97ffd92c 	bl	3780 <fwp_trap>
    d2d4:	b0000000 	adrp	x0, e000 <_IO_stdin_used+0x5f0>
    d2d8:	9108a000 	add	x0, x0, #0x228
    d2dc:	97ffd809 	bl	3300 <ad_raw_fail>
    d2e0:	97ffd54c 	bl	2810 <__stack_chk_fail@plt>
    d2e4:	d503201f 	nop
    d2e8:	d503201f 	nop
    d2ec:	d503201f 	nop

000000000000d2f0 <__divti3>:
    d2f0:	d503245f 	bti	c
    d2f4:	d2800004 	mov	x4, #0x0                   	// #0
    d2f8:	b7f80721 	tbnz	x1, #63, d3dc <__divti3+0xec>
    d2fc:	b6f80083 	tbz	x3, #63, d30c <__divti3+0x1c>
    d300:	eb0203e2 	negs	x2, x2
    d304:	aa2403e4 	mvn	x4, x4
    d308:	da0303e3 	ngc	x3, x3
    d30c:	aa0203e6 	mov	x6, x2
    d310:	aa0003e7 	mov	x7, x0
    d314:	aa0103e5 	mov	x5, x1
    d318:	b5000583 	cbnz	x3, d3c8 <__divti3+0xd8>
    d31c:	eb01005f 	cmp	x2, x1
    d320:	54000e69 	b.ls	d4ec <__divti3+0x1fc>  // b.plast
    d324:	dac01040 	clz	x0, x2
    d328:	b40000e0 	cbz	x0, d344 <__divti3+0x54>
    d32c:	4b0003e1 	neg	w1, w0
    d330:	9ac020a5 	lsl	x5, x5, x0
    d334:	9ac02046 	lsl	x6, x2, x0
    d338:	9ac124e1 	lsr	x1, x7, x1
    d33c:	aa050025 	orr	x5, x1, x5
    d340:	9ac020e7 	lsl	x7, x7, x0
    d344:	d360fcc8 	lsr	x8, x6, #32
    d348:	92407cc2 	and	x2, x6, #0xffffffff
    d34c:	9ac808a3 	udiv	x3, x5, x8
    d350:	9b089465 	msub	x5, x3, x8, x5
    d354:	aa0303e0 	mov	x0, x3
    d358:	9b037c41 	mul	x1, x2, x3
    d35c:	93c780a5 	extr	x5, x5, x7, #32
    d360:	eb05003f 	cmp	x1, x5
    d364:	540000a9 	b.ls	d378 <__divti3+0x88>  // b.plast
    d368:	ab0500c5 	adds	x5, x6, x5
    d36c:	d1000460 	sub	x0, x3, #0x1
    d370:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d374:	540015a8 	b.hi	d628 <__divti3+0x338>  // b.pmore
    d378:	cb0100a5 	sub	x5, x5, x1
    d37c:	9ac808a3 	udiv	x3, x5, x8
    d380:	9b089465 	msub	x5, x3, x8, x5
    d384:	aa0303e1 	mov	x1, x3
    d388:	9b037c42 	mul	x2, x2, x3
    d38c:	aa0703e3 	mov	x3, x7
    d390:	b3607ca3 	bfi	x3, x5, #32, #32
    d394:	eb03005f 	cmp	x2, x3
    d398:	540000c9 	b.ls	d3b0 <__divti3+0xc0>  // b.plast
    d39c:	ab0300c3 	adds	x3, x6, x3
    d3a0:	d1000425 	sub	x5, x1, #0x1
    d3a4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d3a8:	d1000821 	sub	x1, x1, #0x2
    d3ac:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d3b0:	aa008020 	orr	x0, x1, x0, lsl #32
    d3b4:	d2800001 	mov	x1, #0x0                   	// #0
    d3b8:	b4000064 	cbz	x4, d3c4 <__divti3+0xd4>
    d3bc:	eb0003e0 	negs	x0, x0
    d3c0:	da0103e1 	ngc	x1, x1
    d3c4:	d65f03c0 	ret
    d3c8:	eb01007f 	cmp	x3, x1
    d3cc:	54000109 	b.ls	d3ec <__divti3+0xfc>  // b.plast
    d3d0:	d2800001 	mov	x1, #0x0                   	// #0
    d3d4:	d2800000 	mov	x0, #0x0                   	// #0
    d3d8:	17fffff8 	b	d3b8 <__divti3+0xc8>
    d3dc:	eb0003e0 	negs	x0, x0
    d3e0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d3e4:	da0103e1 	ngc	x1, x1
    d3e8:	17ffffc5 	b	d2fc <__divti3+0xc>
    d3ec:	dac01067 	clz	x7, x3
    d3f0:	b40010e7 	cbz	x7, d60c <__divti3+0x31c>
    d3f4:	d2800805 	mov	x5, #0x40                  	// #64
    d3f8:	cb0700a5 	sub	x5, x5, x7
    d3fc:	9ac72063 	lsl	x3, x3, x7
    d400:	9ac52448 	lsr	x8, x2, x5
    d404:	aa030108 	orr	x8, x8, x3
    d408:	9ac52426 	lsr	x6, x1, x5
    d40c:	92407d0a 	and	x10, x8, #0xffffffff
    d410:	d360fd09 	lsr	x9, x8, #32
    d414:	9ac52403 	lsr	x3, x0, x5
    d418:	9ac72021 	lsl	x1, x1, x7
    d41c:	aa010063 	orr	x3, x3, x1
    d420:	9ac72042 	lsl	x2, x2, x7
    d424:	9ac908cb 	udiv	x11, x6, x9
    d428:	9b099965 	msub	x5, x11, x9, x6
    d42c:	aa0b03e1 	mov	x1, x11
    d430:	9b0b7d46 	mul	x6, x10, x11
    d434:	93c380a5 	extr	x5, x5, x3, #32
    d438:	eb0500df 	cmp	x6, x5
    d43c:	540000a9 	b.ls	d450 <__divti3+0x160>  // b.plast
    d440:	ab050105 	adds	x5, x8, x5
    d444:	d1000561 	sub	x1, x11, #0x1
    d448:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d44c:	54000f48 	b.hi	d634 <__divti3+0x344>  // b.pmore
    d450:	cb0600a6 	sub	x6, x5, x6
    d454:	9ac908cb 	udiv	x11, x6, x9
    d458:	9b099969 	msub	x9, x11, x9, x6
    d45c:	aa0b03e5 	mov	x5, x11
    d460:	9b0b7d4a 	mul	x10, x10, x11
    d464:	b3607d23 	bfi	x3, x9, #32, #32
    d468:	eb03015f 	cmp	x10, x3
    d46c:	540000a9 	b.ls	d480 <__divti3+0x190>  // b.plast
    d470:	ab030103 	adds	x3, x8, x3
    d474:	d1000565 	sub	x5, x11, #0x1
    d478:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d47c:	54000e28 	b.hi	d640 <__divti3+0x350>  // b.pmore
    d480:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d484:	92407c48 	and	x8, x2, #0xffffffff
    d488:	2a0503e5 	mov	w5, w5
    d48c:	d360fc42 	lsr	x2, x2, #32
    d490:	d360fc26 	lsr	x6, x1, #32
    d494:	cb0a0063 	sub	x3, x3, x10
    d498:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d49c:	9b087caa 	mul	x10, x5, x8
    d4a0:	9b087cc8 	mul	x8, x6, x8
    d4a4:	9b0220a5 	madd	x5, x5, x2, x8
    d4a8:	9b027cc6 	mul	x6, x6, x2
    d4ac:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d4b0:	8b0900c5 	add	x5, x6, x9
    d4b4:	eb02011f 	cmp	x8, x2
    d4b8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d4bc:	8b4280c6 	add	x6, x6, x2, lsr #32
    d4c0:	eb06007f 	cmp	x3, x6
    d4c4:	540000e3 	b.cc	d4e0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d4c8:	92407d4a 	and	x10, x10, #0xffffffff
    d4cc:	9ac72000 	lsl	x0, x0, x7
    d4d0:	8b028142 	add	x2, x10, x2, lsl #32
    d4d4:	eb02001f 	cmp	x0, x2
    d4d8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d4dc:	54000a01 	b.ne	d61c <__divti3+0x32c>  // b.any
    d4e0:	d1000420 	sub	x0, x1, #0x1
    d4e4:	d2800001 	mov	x1, #0x0                   	// #0
    d4e8:	17ffffb4 	b	d3b8 <__divti3+0xc8>
    d4ec:	b5000062 	cbnz	x2, d4f8 <__divti3+0x208>
    d4f0:	d2800022 	mov	x2, #0x1                   	// #1
    d4f4:	9ac30846 	udiv	x6, x2, x3
    d4f8:	dac010c8 	clz	x8, x6
    d4fc:	b5000408 	cbnz	x8, d57c <__divti3+0x28c>
    d500:	d360fcc9 	lsr	x9, x6, #32
    d504:	92407cc5 	and	x5, x6, #0xffffffff
    d508:	cb060023 	sub	x3, x1, x6
    d50c:	d2800021 	mov	x1, #0x1                   	// #1
    d510:	9ac90868 	udiv	x8, x3, x9
    d514:	9b098d03 	msub	x3, x8, x9, x3
    d518:	aa0803e0 	mov	x0, x8
    d51c:	9b057d02 	mul	x2, x8, x5
    d520:	93c78063 	extr	x3, x3, x7, #32
    d524:	eb03005f 	cmp	x2, x3
    d528:	540000a9 	b.ls	d53c <__divti3+0x24c>  // b.plast
    d52c:	ab0300c3 	adds	x3, x6, x3
    d530:	d1000500 	sub	x0, x8, #0x1
    d534:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d538:	54000968 	b.hi	d664 <__divti3+0x374>  // b.pmore
    d53c:	cb020063 	sub	x3, x3, x2
    d540:	9ac90862 	udiv	x2, x3, x9
    d544:	aa0203e8 	mov	x8, x2
    d548:	9b098c42 	msub	x2, x2, x9, x3
    d54c:	aa0703e3 	mov	x3, x7
    d550:	9b057d05 	mul	x5, x8, x5
    d554:	b3607c43 	bfi	x3, x2, #32, #32
    d558:	eb0300bf 	cmp	x5, x3
    d55c:	540000c9 	b.ls	d574 <__divti3+0x284>  // b.plast
    d560:	ab0300c2 	adds	x2, x6, x3
    d564:	d1000503 	sub	x3, x8, #0x1
    d568:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d56c:	d1000908 	sub	x8, x8, #0x2
    d570:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d574:	aa008100 	orr	x0, x8, x0, lsl #32
    d578:	17ffff90 	b	d3b8 <__divti3+0xc8>
    d57c:	9ac820c6 	lsl	x6, x6, x8
    d580:	d2800803 	mov	x3, #0x40                  	// #64
    d584:	cb080063 	sub	x3, x3, x8
    d588:	d360fcc9 	lsr	x9, x6, #32
    d58c:	9ac82027 	lsl	x7, x1, x8
    d590:	92407cc5 	and	x5, x6, #0xffffffff
    d594:	9ac32422 	lsr	x2, x1, x3
    d598:	9ac32403 	lsr	x3, x0, x3
    d59c:	aa070063 	orr	x3, x3, x7
    d5a0:	9ac9084a 	udiv	x10, x2, x9
    d5a4:	9ac82007 	lsl	x7, x0, x8
    d5a8:	9b098940 	msub	x0, x10, x9, x2
    d5ac:	aa0a03e1 	mov	x1, x10
    d5b0:	9b0a7ca2 	mul	x2, x5, x10
    d5b4:	93c38000 	extr	x0, x0, x3, #32
    d5b8:	eb00005f 	cmp	x2, x0
    d5bc:	540000a9 	b.ls	d5d0 <__divti3+0x2e0>  // b.plast
    d5c0:	ab0000c0 	adds	x0, x6, x0
    d5c4:	d1000541 	sub	x1, x10, #0x1
    d5c8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d5cc:	54000468 	b.hi	d658 <__divti3+0x368>  // b.pmore
    d5d0:	cb020000 	sub	x0, x0, x2
    d5d4:	9ac9080a 	udiv	x10, x0, x9
    d5d8:	9b098140 	msub	x0, x10, x9, x0
    d5dc:	aa0a03e2 	mov	x2, x10
    d5e0:	9b0a7ca8 	mul	x8, x5, x10
    d5e4:	b3607c03 	bfi	x3, x0, #32, #32
    d5e8:	eb03011f 	cmp	x8, x3
    d5ec:	540000a9 	b.ls	d600 <__divti3+0x310>  // b.plast
    d5f0:	ab0300c3 	adds	x3, x6, x3
    d5f4:	d1000542 	sub	x2, x10, #0x1
    d5f8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d5fc:	54000288 	b.hi	d64c <__divti3+0x35c>  // b.pmore
    d600:	cb080063 	sub	x3, x3, x8
    d604:	aa018041 	orr	x1, x2, x1, lsl #32
    d608:	17ffffc2 	b	d510 <__divti3+0x220>
    d60c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d610:	d2800001 	mov	x1, #0x0                   	// #0
    d614:	9a9f87e0 	cset	x0, ls	// ls = plast
    d618:	17ffff68 	b	d3b8 <__divti3+0xc8>
    d61c:	aa0103e0 	mov	x0, x1
    d620:	d2800001 	mov	x1, #0x0                   	// #0
    d624:	17ffff65 	b	d3b8 <__divti3+0xc8>
    d628:	d1000860 	sub	x0, x3, #0x2
    d62c:	8b0600a5 	add	x5, x5, x6
    d630:	17ffff52 	b	d378 <__divti3+0x88>
    d634:	d1000961 	sub	x1, x11, #0x2
    d638:	8b0800a5 	add	x5, x5, x8
    d63c:	17ffff85 	b	d450 <__divti3+0x160>
    d640:	d1000965 	sub	x5, x11, #0x2
    d644:	8b080063 	add	x3, x3, x8
    d648:	17ffff8e 	b	d480 <__divti3+0x190>
    d64c:	d1000942 	sub	x2, x10, #0x2
    d650:	8b060063 	add	x3, x3, x6
    d654:	17ffffeb 	b	d600 <__divti3+0x310>
    d658:	d1000941 	sub	x1, x10, #0x2
    d65c:	8b060000 	add	x0, x0, x6
    d660:	17ffffdc 	b	d5d0 <__divti3+0x2e0>
    d664:	d1000900 	sub	x0, x8, #0x2
    d668:	8b060063 	add	x3, x3, x6
    d66c:	17ffffb4 	b	d53c <__divti3+0x24c>

000000000000d670 <__modti3>:
    d670:	d503245f 	bti	c
    d674:	d2800004 	mov	x4, #0x0                   	// #0
    d678:	b6f80081 	tbz	x1, #63, d688 <__modti3+0x18>
    d67c:	eb0003e0 	negs	x0, x0
    d680:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d684:	da0103e1 	ngc	x1, x1
    d688:	f100007f 	cmp	x3, #0x0
    d68c:	5400128b 	b.lt	d8dc <__modti3+0x26c>  // b.tstop
    d690:	aa0003e7 	mov	x7, x0
    d694:	aa0103e6 	mov	x6, x1
    d698:	540004e1 	b.ne	d734 <__modti3+0xc4>  // b.any
    d69c:	eb02003f 	cmp	x1, x2
    d6a0:	54000dc2 	b.cs	d858 <__modti3+0x1e8>  // b.hs, b.nlast
    d6a4:	dac01043 	clz	x3, x2
    d6a8:	aa0303e5 	mov	x5, x3
    d6ac:	b40000e3 	cbz	x3, d6c8 <__modti3+0x58>
    d6b0:	4b0303e6 	neg	w6, w3
    d6b4:	9ac32021 	lsl	x1, x1, x3
    d6b8:	9ac32042 	lsl	x2, x2, x3
    d6bc:	9ac62406 	lsr	x6, x0, x6
    d6c0:	aa0100c6 	orr	x6, x6, x1
    d6c4:	9ac32007 	lsl	x7, x0, x3
    d6c8:	d360fc40 	lsr	x0, x2, #32
    d6cc:	92407c43 	and	x3, x2, #0xffffffff
    d6d0:	9ac008c1 	udiv	x1, x6, x0
    d6d4:	9b009826 	msub	x6, x1, x0, x6
    d6d8:	9b017c61 	mul	x1, x3, x1
    d6dc:	93c780c6 	extr	x6, x6, x7, #32
    d6e0:	eb06003f 	cmp	x1, x6
    d6e4:	540000a9 	b.ls	d6f8 <__modti3+0x88>  // b.plast
    d6e8:	ab060046 	adds	x6, x2, x6
    d6ec:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d6f0:	8b0200c8 	add	x8, x6, x2
    d6f4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d6f8:	cb0100c6 	sub	x6, x6, x1
    d6fc:	9ac008c8 	udiv	x8, x6, x0
    d700:	9b009901 	msub	x1, x8, x0, x6
    d704:	aa0703e0 	mov	x0, x7
    d708:	9b087c63 	mul	x3, x3, x8
    d70c:	b3607c20 	bfi	x0, x1, #32, #32
    d710:	eb00007f 	cmp	x3, x0
    d714:	54001088 	b.hi	d924 <__modti3+0x2b4>  // b.pmore
    d718:	cb030000 	sub	x0, x0, x3
    d71c:	9ac52400 	lsr	x0, x0, x5
    d720:	d2800001 	mov	x1, #0x0                   	// #0
    d724:	b4000064 	cbz	x4, d730 <__modti3+0xc0>
    d728:	eb0003e0 	negs	x0, x0
    d72c:	da0103e1 	ngc	x1, x1
    d730:	d65f03c0 	ret
    d734:	dac01066 	clz	x6, x3
    d738:	eb03003f 	cmp	x1, x3
    d73c:	54ffff43 	b.cc	d724 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d740:	93407cc5 	sxtw	x5, w6
    d744:	d2800808 	mov	x8, #0x40                  	// #64
    d748:	cb050108 	sub	x8, x8, x5
    d74c:	9ac62063 	lsl	x3, x3, x6
    d750:	9ac62025 	lsl	x5, x1, x6
    d754:	9ac82447 	lsr	x7, x2, x8
    d758:	aa0300e7 	orr	x7, x7, x3
    d75c:	9ac82423 	lsr	x3, x1, x8
    d760:	92407cec 	and	x12, x7, #0xffffffff
    d764:	d360fcea 	lsr	x10, x7, #32
    d768:	9ac82401 	lsr	x1, x0, x8
    d76c:	aa050021 	orr	x1, x1, x5
    d770:	9ac62042 	lsl	x2, x2, x6
    d774:	9ac62000 	lsl	x0, x0, x6
    d778:	9aca086b 	udiv	x11, x3, x10
    d77c:	9b0a8d63 	msub	x3, x11, x10, x3
    d780:	aa0b03e5 	mov	x5, x11
    d784:	9b0b7d89 	mul	x9, x12, x11
    d788:	93c18063 	extr	x3, x3, x1, #32
    d78c:	eb03013f 	cmp	x9, x3
    d790:	540000a9 	b.ls	d7a4 <__modti3+0x134>  // b.plast
    d794:	ab0300e3 	adds	x3, x7, x3
    d798:	d1000565 	sub	x5, x11, #0x1
    d79c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d7a0:	54001168 	b.hi	d9cc <__modti3+0x35c>  // b.pmore
    d7a4:	cb090063 	sub	x3, x3, x9
    d7a8:	9aca086b 	udiv	x11, x3, x10
    d7ac:	9b0a8d6a 	msub	x10, x11, x10, x3
    d7b0:	aa0b03e9 	mov	x9, x11
    d7b4:	9b0b7d8c 	mul	x12, x12, x11
    d7b8:	b3607d41 	bfi	x1, x10, #32, #32
    d7bc:	eb01019f 	cmp	x12, x1
    d7c0:	540000a9 	b.ls	d7d4 <__modti3+0x164>  // b.plast
    d7c4:	ab0100e1 	adds	x1, x7, x1
    d7c8:	d1000569 	sub	x9, x11, #0x1
    d7cc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d7d0:	54000f88 	b.hi	d9c0 <__modti3+0x350>  // b.pmore
    d7d4:	aa058123 	orr	x3, x9, x5, lsl #32
    d7d8:	92407c4b 	and	x11, x2, #0xffffffff
    d7dc:	2a0903e9 	mov	w9, w9
    d7e0:	d360fc4a 	lsr	x10, x2, #32
    d7e4:	d360fc63 	lsr	x3, x3, #32
    d7e8:	cb0c0021 	sub	x1, x1, x12
    d7ec:	aa0a03ec 	mov	x12, x10
    d7f0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d7f4:	9b0b7d25 	mul	x5, x9, x11
    d7f8:	9b0b7c6b 	mul	x11, x3, x11
    d7fc:	9b0a2d29 	madd	x9, x9, x10, x11
    d800:	92407caa 	and	x10, x5, #0xffffffff
    d804:	9b0c7c63 	mul	x3, x3, x12
    d808:	8b458125 	add	x5, x9, x5, lsr #32
    d80c:	8b0d0069 	add	x9, x3, x13
    d810:	eb05017f 	cmp	x11, x5
    d814:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d818:	8b058149 	add	x9, x10, x5, lsl #32
    d81c:	8b458063 	add	x3, x3, x5, lsr #32
    d820:	eb03003f 	cmp	x1, x3
    d824:	54000063 	b.cc	d830 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d828:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d82c:	54000082 	b.cs	d83c <__modti3+0x1cc>  // b.hs, b.nlast
    d830:	eb020129 	subs	x9, x9, x2
    d834:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d838:	cb070063 	sub	x3, x3, x7
    d83c:	eb090000 	subs	x0, x0, x9
    d840:	da030021 	sbc	x1, x1, x3
    d844:	9ac62400 	lsr	x0, x0, x6
    d848:	9ac82028 	lsl	x8, x1, x8
    d84c:	aa000100 	orr	x0, x8, x0
    d850:	9ac62421 	lsr	x1, x1, x6
    d854:	17ffffb4 	b	d724 <__modti3+0xb4>
    d858:	b5000062 	cbnz	x2, d864 <__modti3+0x1f4>
    d85c:	d2800023 	mov	x3, #0x1                   	// #1
    d860:	9ac20862 	udiv	x2, x3, x2
    d864:	dac01048 	clz	x8, x2
    d868:	aa0803e5 	mov	x5, x8
    d86c:	b5000668 	cbnz	x8, d938 <__modti3+0x2c8>
    d870:	cb020020 	sub	x0, x1, x2
    d874:	d360fc49 	lsr	x9, x2, #32
    d878:	92407c4a 	and	x10, x2, #0xffffffff
    d87c:	9ac90801 	udiv	x1, x0, x9
    d880:	9b098020 	msub	x0, x1, x9, x0
    d884:	9b0a7c21 	mul	x1, x1, x10
    d888:	93c78000 	extr	x0, x0, x7, #32
    d88c:	eb00003f 	cmp	x1, x0
    d890:	540000a9 	b.ls	d8a4 <__modti3+0x234>  // b.plast
    d894:	ab000040 	adds	x0, x2, x0
    d898:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d89c:	8b020003 	add	x3, x0, x2
    d8a0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d8a4:	cb010001 	sub	x1, x0, x1
    d8a8:	9ac90820 	udiv	x0, x1, x9
    d8ac:	9b098403 	msub	x3, x0, x9, x1
    d8b0:	aa0703e1 	mov	x1, x7
    d8b4:	9b0a7c00 	mul	x0, x0, x10
    d8b8:	b3607c61 	bfi	x1, x3, #32, #32
    d8bc:	eb01001f 	cmp	x0, x1
    d8c0:	540000a9 	b.ls	d8d4 <__modti3+0x264>  // b.plast
    d8c4:	ab010041 	adds	x1, x2, x1
    d8c8:	8b020022 	add	x2, x1, x2
    d8cc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d8d0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d8d4:	cb000020 	sub	x0, x1, x0
    d8d8:	17ffff91 	b	d71c <__modti3+0xac>
    d8dc:	eb0203e5 	negs	x5, x2
    d8e0:	aa0003e7 	mov	x7, x0
    d8e4:	da0303e8 	ngc	x8, x3
    d8e8:	aa0503e2 	mov	x2, x5
    d8ec:	aa0803e3 	mov	x3, x8
    d8f0:	aa0103e6 	mov	x6, x1
    d8f4:	b4ffed48 	cbz	x8, d69c <__modti3+0x2c>
    d8f8:	eb01011f 	cmp	x8, x1
    d8fc:	54fff148 	b.hi	d724 <__modti3+0xb4>  // b.pmore
    d900:	dac01109 	clz	x9, x8
    d904:	2a0903e6 	mov	w6, w9
    d908:	b5fff1c9 	cbnz	x9, d740 <__modti3+0xd0>
    d90c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d910:	54000068 	b.hi	d91c <__modti3+0x2ac>  // b.pmore
    d914:	eb050007 	subs	x7, x0, x5
    d918:	da080021 	sbc	x1, x1, x8
    d91c:	aa0703e0 	mov	x0, x7
    d920:	17ffff81 	b	d724 <__modti3+0xb4>
    d924:	ab000040 	adds	x0, x2, x0
    d928:	8b020002 	add	x2, x0, x2
    d92c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d930:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d934:	17ffff79 	b	d718 <__modti3+0xa8>
    d938:	9ac82042 	lsl	x2, x2, x8
    d93c:	d2800803 	mov	x3, #0x40                  	// #64
    d940:	cb080063 	sub	x3, x3, x8
    d944:	d360fc49 	lsr	x9, x2, #32
    d948:	9ac82027 	lsl	x7, x1, x8
    d94c:	92407c4a 	and	x10, x2, #0xffffffff
    d950:	9ac32426 	lsr	x6, x1, x3
    d954:	9ac32403 	lsr	x3, x0, x3
    d958:	aa070063 	orr	x3, x3, x7
    d95c:	9ac908c1 	udiv	x1, x6, x9
    d960:	9ac82007 	lsl	x7, x0, x8
    d964:	9b099820 	msub	x0, x1, x9, x6
    d968:	9b017d41 	mul	x1, x10, x1
    d96c:	93c38000 	extr	x0, x0, x3, #32
    d970:	eb00003f 	cmp	x1, x0
    d974:	540000a9 	b.ls	d988 <__modti3+0x318>  // b.plast
    d978:	ab000040 	adds	x0, x2, x0
    d97c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d980:	8b020006 	add	x6, x0, x2
    d984:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d988:	cb010000 	sub	x0, x0, x1
    d98c:	9ac90801 	udiv	x1, x0, x9
    d990:	9b098026 	msub	x6, x1, x9, x0
    d994:	aa0303e0 	mov	x0, x3
    d998:	9b017d41 	mul	x1, x10, x1
    d99c:	b3607cc0 	bfi	x0, x6, #32, #32
    d9a0:	eb00003f 	cmp	x1, x0
    d9a4:	540000a9 	b.ls	d9b8 <__modti3+0x348>  // b.plast
    d9a8:	ab000040 	adds	x0, x2, x0
    d9ac:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d9b0:	8b020003 	add	x3, x0, x2
    d9b4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d9b8:	cb010000 	sub	x0, x0, x1
    d9bc:	17ffffb0 	b	d87c <__modti3+0x20c>
    d9c0:	d1000969 	sub	x9, x11, #0x2
    d9c4:	8b070021 	add	x1, x1, x7
    d9c8:	17ffff83 	b	d7d4 <__modti3+0x164>
    d9cc:	d1000965 	sub	x5, x11, #0x2
    d9d0:	8b070063 	add	x3, x3, x7
    d9d4:	17ffff74 	b	d7a4 <__modti3+0x134>
    d9d8:	d503201f 	nop
    d9dc:	d503201f 	nop

000000000000d9e0 <atexit>:
    d9e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d9e4:	f0000082 	adrp	x2, 20000 <__data_start>
    d9e8:	d2800001 	mov	x1, #0x0                   	// #0
    d9ec:	910003fd 	mov	x29, sp
    d9f0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d9f4:	f9400442 	ldr	x2, [x2, #8]
    d9f8:	17ffd346 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d9fc <_fini>:
    d9fc:	d503201f 	nop
    da00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    da04:	910003fd 	mov	x29, sp
    da08:	a8c17bfd 	ldp	x29, x30, [sp], #16
    da0c:	d65f03c0 	ret
