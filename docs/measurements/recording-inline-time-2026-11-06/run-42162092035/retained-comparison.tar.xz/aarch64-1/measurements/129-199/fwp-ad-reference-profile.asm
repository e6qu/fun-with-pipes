
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <__divti3+0x2b0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	911f20a5 	add	x5, x5, #0x7c8
    2aa0:	f0000044 	adrp	x4, d000 <__divti3+0x2b0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	911f4084 	add	x4, x4, #0x7d0
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	9400034c 	bl	3800 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	d00000f3 	adrp	x19, 20000 <__data_start>
    2afc:	91014261 	add	x1, x19, #0x50
    2b00:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2b04:	f947ee94 	ldr	x20, [x20, #4056]
    2b08:	f9400282 	ldr	x2, [x20]
    2b0c:	f90043f5 	str	x21, [sp, #128]
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe790>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9006820 	str	x0, [x1, #208]
    2b2c:	94000395 	bl	3980 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <__divti3+0x2b0>
    2b34:	91346000 	add	x0, x0, #0xd18
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f5 	mov	x21, x0
    2b48:	35000801 	cbnz	w1, 2c48 <main+0x168>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	35000900 	cbnz	w0, 2c78 <main+0x198>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b50009a0 	cbnz	x0, 2cb8 <main+0x1d8>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f5 	add	x21, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1503e0 	mov	x0, x21
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007c0 	cbnz	w0, 2cac <main+0x1cc>
    2bb8:	aa1503e0 	mov	x0, x21
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000680 	cbnz	w0, 2c94 <main+0x1b4>
    2bc8:	aa1503e1 	mov	x1, x21
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x1f40>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	911e4042 	add	x2, x2, #0x790
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1503e0 	mov	x0, x21
    2be8:	2a0103f5 	mov	w21, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	350004b5 	cbnz	w21, 2c88 <main+0x1a8>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	91014273 	add	x19, x19, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943da60 	ldr	w0, [x19, #984]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	540002a1 	b.ne	2c84 <main+0x1a4>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	910003e1 	mov	x1, sp
    2c4c:	52800142 	mov	w2, #0xa                   	// #10
    2c50:	97ffff50 	bl	2990 <strtoull@plt>
    2c54:	f94003e0 	ldr	x0, [sp]
    2c58:	39400000 	ldrb	w0, [x0]
    2c5c:	35fff780 	cbnz	w0, 2b4c <main+0x6c>
    2c60:	394002a0 	ldrb	w0, [x21]
    2c64:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c68:	5100ac00 	sub	w0, w0, #0x2b
    2c6c:	6a01001f 	tst	w0, w1
    2c70:	54fff6e0 	b.eq	2b4c <main+0x6c>  // b.none
    2c74:	17ffffc5 	b	2b88 <main+0xa8>
    2c78:	f0000040 	adrp	x0, d000 <__divti3+0x2b0>
    2c7c:	9134a000 	add	x0, x0, #0xd28
    2c80:	940002e0 	bl	3800 <fwp_trap>
    2c84:	97ffff07 	bl	28a0 <__stack_chk_fail@plt>
    2c88:	f0000040 	adrp	x0, d000 <__divti3+0x2b0>
    2c8c:	91372000 	add	x0, x0, #0xdc8
    2c90:	940002dc 	bl	3800 <fwp_trap>
    2c94:	aa1503e0 	mov	x0, x21
    2c98:	97fffeee 	bl	2850 <pthread_attr_destroy@plt>
    2c9c:	35000140 	cbnz	w0, 2cc4 <main+0x1e4>
    2ca0:	f0000040 	adrp	x0, d000 <__divti3+0x2b0>
    2ca4:	91368000 	add	x0, x0, #0xda0
    2ca8:	940002d6 	bl	3800 <fwp_trap>
    2cac:	f0000040 	adrp	x0, d000 <__divti3+0x2b0>
    2cb0:	9135c000 	add	x0, x0, #0xd70
    2cb4:	940002d3 	bl	3800 <fwp_trap>
    2cb8:	f0000040 	adrp	x0, d000 <__divti3+0x2b0>
    2cbc:	91352000 	add	x0, x0, #0xd48
    2cc0:	940002d0 	bl	3800 <fwp_trap>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91010000 	add	x0, x0, #0x40
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91010021 	add	x1, x1, #0x40
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91010000 	add	x0, x0, #0x40
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91010021 	add	x1, x1, #0x40
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0xb90>
    2eb4:	91108021 	add	x1, x1, #0x420
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xb90>
    3158:	91100021 	add	x1, x1, #0x400
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    3190:	9111e000 	add	x0, x0, #0x478
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    31c4:	9118c2a1 	add	x1, x21, #0x630
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    31d8:	912880a5 	add	x5, x5, #0xa20
    31dc:	9118c2a1 	add	x1, x21, #0x630
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	9118c2b7 	add	x23, x21, #0x630
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	9118c2b5 	add	x21, x21, #0x630
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	9118c2b5 	add	x21, x21, #0x630
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    3368:	912860a5 	add	x5, x5, #0xa18
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	d0000042 	adrp	x2, d000 <__divti3+0x2b0>
    339c:	91124042 	add	x2, x2, #0x490
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	d0000042 	adrp	x2, d000 <__divti3+0x2b0>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	9113a042 	add	x2, x2, #0x4e8
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	d0000059 	adrp	x25, d000 <__divti3+0x2b0>
    3428:	d000005a 	adrp	x26, d000 <__divti3+0x2b0>
    342c:	91152339 	add	x25, x25, #0x548
    3430:	9112c35a 	add	x26, x26, #0x4b0
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	d000005b 	adrp	x27, d000 <__divti3+0x2b0>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	9112e377 	add	x23, x27, #0x4b8
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	91162000 	add	x0, x0, #0x588
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbb0>
    34f4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    34f8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbb0>
    34fc:	d0000043 	adrp	x3, d000 <__divti3+0x2b0>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	d0000055 	adrp	x21, d000 <__divti3+0x2b0>
    3508:	f9422824 	ldr	x4, [x1, #1104]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f9422ca5 	ldr	x5, [x5, #1112]
    3514:	91114033 	add	x19, x1, #0x450
    3518:	f9423046 	ldr	x6, [x2, #1120]
    351c:	9112c063 	add	x3, x3, #0x4b0
    3520:	911682b5 	add	x21, x21, #0x5a0
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	91178000 	add	x0, x0, #0x5e0
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    35ac:	91130000 	add	x0, x0, #0x4c0
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    366c:	9111e000 	add	x0, x0, #0x478
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <__divti3+0x2b0>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	9117a021 	add	x1, x1, #0x5e8
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <__divti3+0x2b0>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	9117c021 	add	x1, x1, #0x5f0
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <__divti3+0x2b0>
    37e0:	9117e021 	add	x1, x1, #0x5f8
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_trap>:
    3800:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3804:	d53bd041 	mrs	x1, tpidr_el0
    3808:	91400021 	add	x1, x1, #0x0, lsl #12
    380c:	91004021 	add	x1, x1, #0x10
    3810:	910003fd 	mov	x29, sp
    3814:	a90153f3 	stp	x19, x20, [sp, #16]
    3818:	aa0003f3 	mov	x19, x0
    381c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    3820:	f947ea94 	ldr	x20, [x20, #4048]
    3824:	f90013f5 	str	x21, [sp, #32]
    3828:	f9400035 	ldr	x21, [x1]
    382c:	97fffe12 	bl	3074 <fwp_flush>
    3830:	f9400280 	ldr	x0, [x20]
    3834:	d0000042 	adrp	x2, d000 <__divti3+0x2b0>
    3838:	aa1303e3 	mov	x3, x19
    383c:	91180042 	add	x2, x2, #0x600
    3840:	52800041 	mov	w1, #0x2                   	// #2
    3844:	97fffc33 	bl	2910 <__fprintf_chk@plt>
    3848:	b40000b5 	cbz	x21, 385c <fwp_trap+0x5c>
    384c:	f9400280 	ldr	x0, [x20]
    3850:	97fffc60 	bl	29d0 <fflush@plt>
    3854:	52800ca0 	mov	w0, #0x65                  	// #101
    3858:	97fffc6e 	bl	2a10 <_Exit@plt>
    385c:	52800ca0 	mov	w0, #0x65                  	// #101
    3860:	97fffbbc 	bl	2750 <exit@plt>

0000000000003864 <fwp_closure_drop_push>:
    3864:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    3868:	910003fd 	mov	x29, sp
    386c:	a90153f3 	stp	x19, x20, [sp, #16]
    3870:	aa0003f3 	mov	x19, x0
    3874:	a9408014 	ldp	x20, x0, [x0, #8]
    3878:	a9025bf5 	stp	x21, x22, [sp, #32]
    387c:	aa0103f5 	mov	x21, x1
    3880:	a90363f7 	stp	x23, x24, [sp, #48]
    3884:	eb00029f 	cmp	x20, x0
    3888:	54000160 	b.eq	38b4 <fwp_closure_drop_push+0x50>  // b.none
    388c:	f9400276 	ldr	x22, [x19]
    3890:	d37df297 	lsl	x23, x20, #3
    3894:	91000694 	add	x20, x20, #0x1
    3898:	f9000674 	str	x20, [x19, #8]
    389c:	a94153f3 	ldp	x19, x20, [sp, #16]
    38a0:	f8376ad5 	str	x21, [x22, x23]
    38a4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38a8:	a94363f7 	ldp	x23, x24, [sp, #48]
    38ac:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b0:	d65f03c0 	ret
    38b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    38b8:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    38bc:	eb00029f 	cmp	x20, x0
    38c0:	54000568 	b.hi	396c <fwp_closure_drop_push+0x108>  // b.pmore
    38c4:	d37cee99 	lsl	x25, x20, #4
    38c8:	d37ffa9a 	lsl	x26, x20, #1
    38cc:	aa1903e0 	mov	x0, x25
    38d0:	97fffbdc 	bl	2840 <malloc@plt>
    38d4:	aa0003f6 	mov	x22, x0
    38d8:	b4000320 	cbz	x0, 393c <fwp_closure_drop_push+0xd8>
    38dc:	aa1303f8 	mov	x24, x19
    38e0:	aa1903e3 	mov	x3, x25
    38e4:	d37df297 	lsl	x23, x20, #3
    38e8:	aa1703e2 	mov	x2, x23
    38ec:	f8418719 	ldr	x25, [x24], #24
    38f0:	aa1903e1 	mov	x1, x25
    38f4:	97fffbbf 	bl	27f0 <__memcpy_chk@plt>
    38f8:	eb18033f 	cmp	x25, x24
    38fc:	540000a0 	b.eq	3910 <fwp_closure_drop_push+0xac>  // b.none
    3900:	aa1903e0 	mov	x0, x25
    3904:	97fffc17 	bl	2960 <free@plt>
    3908:	f9400674 	ldr	x20, [x19, #8]
    390c:	d37df297 	lsl	x23, x20, #3
    3910:	91000694 	add	x20, x20, #0x1
    3914:	f9000276 	str	x22, [x19]
    3918:	f9000a7a 	str	x26, [x19, #16]
    391c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    3920:	f9000674 	str	x20, [x19, #8]
    3924:	f8376ad5 	str	x21, [x22, x23]
    3928:	a94153f3 	ldp	x19, x20, [sp, #16]
    392c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3930:	a94363f7 	ldp	x23, x24, [sp, #48]
    3934:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3938:	d65f03c0 	ret
    393c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3940:	f947e863 	ldr	x3, [x3, #4048]
    3944:	d2800262 	mov	x2, #0x13                  	// #19
    3948:	d2800021 	mov	x1, #0x1                   	// #1
    394c:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    3950:	9111e000 	add	x0, x0, #0x478
    3954:	f9400063 	ldr	x3, [x3]
    3958:	97fffc12 	bl	29a0 <fwrite@plt>
    395c:	d2800000 	mov	x0, #0x0                   	// #0
    3960:	97fffc1c 	bl	29d0 <fflush@plt>
    3964:	52800cc0 	mov	w0, #0x66                  	// #102
    3968:	97fffc2a 	bl	2a10 <_Exit@plt>
    396c:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    3970:	91184000 	add	x0, x0, #0x610
    3974:	97ffffa3 	bl	3800 <fwp_trap>
    3978:	d503201f 	nop
    397c:	d503201f 	nop

0000000000003980 <fwp_now_ns>:
    3980:	d100c3ff 	sub	sp, sp, #0x30
    3984:	52800020 	mov	w0, #0x1                   	// #1
    3988:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    398c:	f947f442 	ldr	x2, [x2, #4072]
    3990:	910023e1 	add	x1, sp, #0x8
    3994:	a9027bfd 	stp	x29, x30, [sp, #32]
    3998:	910083fd 	add	x29, sp, #0x20
    399c:	f9400043 	ldr	x3, [x2]
    39a0:	f9000fe3 	str	x3, [sp, #24]
    39a4:	d2800003 	mov	x3, #0x0                   	// #0
    39a8:	97fffb8a 	bl	27d0 <clock_gettime@plt>
    39ac:	350002c0 	cbnz	w0, 3a04 <fwp_now_ns+0x84>
    39b0:	a9408be1 	ldp	x1, x2, [sp, #8]
    39b4:	d2994003 	mov	x3, #0xca00                	// #51712
    39b8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    39bc:	9b037c20 	mul	x0, x1, x3
    39c0:	9b437c21 	smulh	x1, x1, x3
    39c4:	ab020000 	adds	x0, x0, x2
    39c8:	937ffc42 	asr	x2, x2, #63
    39cc:	9a020021 	adc	x1, x1, x2
    39d0:	f100001f 	cmp	x0, #0x0
    39d4:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    39d8:	b50001e1 	cbnz	x1, 3a14 <fwp_now_ns+0x94>
    39dc:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    39e0:	f947f421 	ldr	x1, [x1, #4072]
    39e4:	f9400fe3 	ldr	x3, [sp, #24]
    39e8:	f9400022 	ldr	x2, [x1]
    39ec:	eb020063 	subs	x3, x3, x2
    39f0:	d2800002 	mov	x2, #0x0                   	// #0
    39f4:	540000e1 	b.ne	3a10 <fwp_now_ns+0x90>  // b.any
    39f8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    39fc:	9100c3ff 	add	sp, sp, #0x30
    3a00:	d65f03c0 	ret
    3a04:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    3a08:	9118c000 	add	x0, x0, #0x630
    3a0c:	97ffff7d 	bl	3800 <fwp_trap>
    3a10:	97fffba4 	bl	28a0 <__stack_chk_fail@plt>
    3a14:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    3a18:	91194000 	add	x0, x0, #0x650
    3a1c:	97ffff79 	bl	3800 <fwp_trap>

0000000000003a20 <fwp_closure_drop.part.0>:
    3a20:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3a24:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xb90>
    3a28:	910003fd 	mov	x29, sp
    3a2c:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3a30:	f947f463 	ldr	x3, [x3, #4072]
    3a34:	a90153f3 	stp	x19, x20, [sp, #16]
    3a38:	d10883ff 	sub	sp, sp, #0x220
    3a3c:	910003e2 	mov	x2, sp
    3a40:	d53bd053 	mrs	x19, tpidr_el0
    3a44:	910063f4 	add	x20, sp, #0x18
    3a48:	3dc10c20 	ldr	q0, [x1, #1072]
    3a4c:	91400264 	add	x4, x19, #0x0, lsl #12
    3a50:	91004084 	add	x4, x4, #0x10
    3a54:	aa0003e1 	mov	x1, x0
    3a58:	aa0203e0 	mov	x0, x2
    3a5c:	f9400062 	ldr	x2, [x3]
    3a60:	f9010fe2 	str	x2, [sp, #536]
    3a64:	d2800002 	mov	x2, #0x0                   	// #0
    3a68:	f90003f4 	str	x20, [sp]
    3a6c:	f9000080 	str	x0, [x4]
    3a70:	3c8083e0 	stur	q0, [sp, #8]
    3a74:	97ffff7c 	bl	3864 <fwp_closure_drop_push>
    3a78:	f94007e0 	ldr	x0, [sp, #8]
    3a7c:	b4000280 	cbz	x0, 3acc <fwp_closure_drop.part.0+0xac>
    3a80:	f90123f5 	str	x21, [sp, #576]
    3a84:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a88:	910142b5 	add	x21, x21, #0x50
    3a8c:	d503201f 	nop
    3a90:	f94003e1 	ldr	x1, [sp]
    3a94:	d1000400 	sub	x0, x0, #0x1
    3a98:	f90007e0 	str	x0, [sp, #8]
    3a9c:	f9406aa2 	ldr	x2, [x21, #208]
    3aa0:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3aa4:	b9400001 	ldr	w1, [x0]
    3aa8:	8b011441 	add	x1, x2, x1, lsl #5
    3aac:	f9400c21 	ldr	x1, [x1, #24]
    3ab0:	b4000321 	cbz	x1, 3b14 <fwp_closure_drop.part.0+0xf4>
    3ab4:	f9400422 	ldr	x2, [x1, #8]
    3ab8:	52800001 	mov	w1, #0x0                   	// #0
    3abc:	d63f0040 	blr	x2
    3ac0:	f94007e0 	ldr	x0, [sp, #8]
    3ac4:	b5fffe60 	cbnz	x0, 3a90 <fwp_closure_drop.part.0+0x70>
    3ac8:	f94123f5 	ldr	x21, [sp, #576]
    3acc:	91400273 	add	x19, x19, #0x0, lsl #12
    3ad0:	91004273 	add	x19, x19, #0x10
    3ad4:	f94003e0 	ldr	x0, [sp]
    3ad8:	f900027f 	str	xzr, [x19]
    3adc:	eb14001f 	cmp	x0, x20
    3ae0:	54000040 	b.eq	3ae8 <fwp_closure_drop.part.0+0xc8>  // b.none
    3ae4:	97fffb9f 	bl	2960 <free@plt>
    3ae8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3aec:	f947f400 	ldr	x0, [x0, #4072]
    3af0:	f9410fe2 	ldr	x2, [sp, #536]
    3af4:	f9400001 	ldr	x1, [x0]
    3af8:	eb010042 	subs	x2, x2, x1
    3afc:	d2800001 	mov	x1, #0x0                   	// #0
    3b00:	54000101 	b.ne	3b20 <fwp_closure_drop.part.0+0x100>  // b.any
    3b04:	910883ff 	add	sp, sp, #0x220
    3b08:	a94153f3 	ldp	x19, x20, [sp, #16]
    3b0c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3b10:	d65f03c0 	ret
    3b14:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    3b18:	9119e000 	add	x0, x0, #0x678
    3b1c:	97ffff39 	bl	3800 <fwp_trap>
    3b20:	f90123f5 	str	x21, [sp, #576]
    3b24:	97fffb5f 	bl	28a0 <__stack_chk_fail@plt>
    3b28:	d503201f 	nop
    3b2c:	d503201f 	nop

0000000000003b30 <fwp_tape_of>:
    3b30:	92403c02 	and	x2, x0, #0xffff
    3b34:	b4000262 	cbz	x2, 3b80 <fwp_tape_of+0x50>
    3b38:	b00000e3 	adrp	x3, 20000 <__data_start>
    3b3c:	91014063 	add	x3, x3, #0x50
    3b40:	9350fc01 	asr	x1, x0, #16
    3b44:	d1000440 	sub	x0, x2, #0x1
    3b48:	f9406c62 	ldr	x2, [x3, #216]
    3b4c:	eb00005f 	cmp	x2, x0
    3b50:	5400018d 	b.le	3b80 <fwp_tape_of+0x50>
    3b54:	8b000402 	add	x2, x0, x0, lsl #1
    3b58:	f9404463 	ldr	x3, [x3, #136]
    3b5c:	8b020802 	add	x2, x0, x2, lsl #2
    3b60:	d37df042 	lsl	x2, x2, #3
    3b64:	8b020060 	add	x0, x3, x2
    3b68:	b9400404 	ldr	w4, [x0, #4]
    3b6c:	340000a4 	cbz	w4, 3b80 <fwp_tape_of+0x50>
    3b70:	b8626862 	ldr	w2, [x3, x2]
    3b74:	6b01005f 	cmp	w2, w1
    3b78:	54000041 	b.ne	3b80 <fwp_tape_of+0x50>  // b.any
    3b7c:	d65f03c0 	ret
    3b80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b84:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    3b88:	911aa000 	add	x0, x0, #0x6a8
    3b8c:	910003fd 	mov	x29, sp
    3b90:	97ffff1c 	bl	3800 <fwp_trap>

0000000000003b94 <fwp_format_g.constprop.0>:
    3b94:	d10483ff 	sub	sp, sp, #0x120
    3b98:	d0000044 	adrp	x4, d000 <__divti3+0x2b0>
    3b9c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    3ba0:	f947f442 	ldr	x2, [x2, #4072]
    3ba4:	911be084 	add	x4, x4, #0x6f8
    3ba8:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3bac:	9102c3fd 	add	x29, sp, #0xb0
    3bb0:	d2800803 	mov	x3, #0x40                  	// #64
    3bb4:	a90e63f7 	stp	x23, x24, [sp, #224]
    3bb8:	93407c38 	sxtw	x24, w1
    3bbc:	aa0303e1 	mov	x1, x3
    3bc0:	fd008be8 	str	d8, [sp, #272]
    3bc4:	1e604008 	fmov	d8, d0
    3bc8:	a90c53f3 	stp	x19, x20, [sp, #192]
    3bcc:	910083f4 	add	x20, sp, #0x20
    3bd0:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3bd4:	aa0003f5 	mov	x21, x0
    3bd8:	a91073fb 	stp	x27, x28, [sp, #256]
    3bdc:	5100071c 	sub	w28, w24, #0x1
    3be0:	2a1c03e5 	mov	w5, w28
    3be4:	f9400040 	ldr	x0, [x2]
    3be8:	f90057e0 	str	x0, [sp, #168]
    3bec:	d2800000 	mov	x0, #0x0                   	// #0
    3bf0:	52800042 	mov	w2, #0x2                   	// #2
    3bf4:	aa1403e0 	mov	x0, x20
    3bf8:	97fffb06 	bl	2810 <__snprintf_chk@plt>
    3bfc:	52800ca1 	mov	w1, #0x65                  	// #101
    3c00:	aa1403e0 	mov	x0, x20
    3c04:	97fffb5f 	bl	2980 <strchr@plt>
    3c08:	aa0003f3 	mov	x19, x0
    3c0c:	52800142 	mov	w2, #0xa                   	// #10
    3c10:	91000400 	add	x0, x0, #0x1
    3c14:	d2800001 	mov	x1, #0x0                   	// #0
    3c18:	97fffb4a 	bl	2940 <strtol@plt>
    3c1c:	aa0003f7 	mov	x23, x0
    3c20:	11001400 	add	w0, w0, #0x5
    3c24:	7100541f 	cmp	w0, #0x15
    3c28:	54000d88 	b.hi	3dd8 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3c2c:	4b170385 	sub	w5, w28, w23
    3c30:	710000bf 	cmp	w5, #0x0
    3c34:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3c38:	54000ba0 	b.eq	3dac <fwp_format_g.constprop.0+0x218>  // b.none
    3c3c:	394083e0 	ldrb	w0, [sp, #32]
    3c40:	cb180273 	sub	x19, x19, x24
    3c44:	91000673 	add	x19, x19, #0x1
    3c48:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c4c:	7100b41f 	cmp	w0, #0x2d
    3c50:	9a941681 	cinc	x1, x20, eq	// eq = none
    3c54:	1a9f17e4 	cset	w4, eq	// eq = none
    3c58:	cb010266 	sub	x6, x19, x1
    3c5c:	d10004da 	sub	x26, x6, #0x1
    3c60:	540018c0 	b.eq	3f78 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d280091b 	mov	x27, #0x48                  	// #72
    3c6c:	aa1903e7 	mov	x7, x25
    3c70:	91000423 	add	x3, x1, #0x1
    3c74:	91011cc6 	add	x6, x6, #0x47
    3c78:	910004f6 	add	x22, x7, #0x1
    3c7c:	37f81017 	tbnz	w23, #31, 3e7c <fwp_format_g.constprop.0+0x2e8>
    3c80:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c84:	93407ef7 	sxtw	x23, w23
    3c88:	390000e4 	strb	w4, [x7]
    3c8c:	aa1303e1 	mov	x1, x19
    3c90:	aa1703e2 	mov	x2, x23
    3c94:	aa1603e0 	mov	x0, x22
    3c98:	b9000be5 	str	w5, [sp, #8]
    3c9c:	cb170374 	sub	x20, x27, x23
    3ca0:	a9011be3 	stp	x3, x6, [sp, #16]
    3ca4:	97fffa93 	bl	26f0 <memcpy@plt>
    3ca8:	d1000694 	sub	x20, x20, #0x1
    3cac:	f9400be3 	ldr	x3, [sp, #16]
    3cb0:	8b1702d6 	add	x22, x22, x23
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	aa1a03e2 	mov	x2, x26
    3cbc:	aa0303e1 	mov	x1, x3
    3cc0:	aa1403e3 	mov	x3, x20
    3cc4:	97fffacb 	bl	27f0 <__memcpy_chk@plt>
    3cc8:	8b1a02d6 	add	x22, x22, x26
    3ccc:	f9400fe6 	ldr	x6, [sp, #24]
    3cd0:	d2800900 	mov	x0, #0x48                  	// #72
    3cd4:	b9400be5 	ldr	w5, [sp, #8]
    3cd8:	8b170261 	add	x1, x19, x23
    3cdc:	cb1400c3 	sub	x3, x6, x20
    3ce0:	cb060294 	sub	x20, x20, x6
    3ce4:	f101207f 	cmp	x3, #0x48
    3ce8:	93407cb8 	sxtw	x24, w5
    3cec:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3cf0:	aa1803e2 	mov	x2, x24
    3cf4:	8b1802d3 	add	x19, x22, x24
    3cf8:	8b140063 	add	x3, x3, x20
    3cfc:	aa1603e0 	mov	x0, x22
    3d00:	97fffabc 	bl	27f0 <__memcpy_chk@plt>
    3d04:	cb190273 	sub	x19, x19, x25
    3d08:	d28031e0 	mov	x0, #0x18f                 	// #399
    3d0c:	eb00027f 	cmp	x19, x0
    3d10:	aa1903e1 	mov	x1, x25
    3d14:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3d18:	aa1503e0 	mov	x0, x21
    3d1c:	aa1303e2 	mov	x2, x19
    3d20:	97fffa74 	bl	26f0 <memcpy@plt>
    3d24:	38336abf 	strb	wzr, [x21, x19]
    3d28:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3d2c:	aa1503e0 	mov	x0, x21
    3d30:	97fffa80 	bl	2730 <strlen@plt>
    3d34:	aa0003f3 	mov	x19, x0
    3d38:	528005c1 	mov	w1, #0x2e                  	// #46
    3d3c:	aa1503e0 	mov	x0, x21
    3d40:	97fffb10 	bl	2980 <strchr@plt>
    3d44:	b4000160 	cbz	x0, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d48:	b4000153 	cbz	x19, 3d70 <fwp_format_g.constprop.0+0x1dc>
    3d4c:	d503201f 	nop
    3d50:	aa1303e1 	mov	x1, x19
    3d54:	d1000673 	sub	x19, x19, #0x1
    3d58:	38736aa0 	ldrb	w0, [x21, x19]
    3d5c:	7100c01f 	cmp	w0, #0x30
    3d60:	54001001 	b.ne	3f60 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3d64:	38336abf 	strb	wzr, [x21, x19]
    3d68:	b5ffff53 	cbnz	x19, 3d50 <fwp_format_g.constprop.0+0x1bc>
    3d6c:	d503201f 	nop
    3d70:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d74:	f947f400 	ldr	x0, [x0, #4072]
    3d78:	f94057e2 	ldr	x2, [sp, #168]
    3d7c:	f9400001 	ldr	x1, [x0]
    3d80:	eb010042 	subs	x2, x2, x1
    3d84:	d2800001 	mov	x1, #0x0                   	// #0
    3d88:	54001061 	b.ne	3f94 <fwp_format_g.constprop.0+0x400>  // b.any
    3d8c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d90:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d94:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d98:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d9c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3da0:	fd408be8 	ldr	d8, [sp, #272]
    3da4:	910483ff 	add	sp, sp, #0x120
    3da8:	d65f03c0 	ret
    3dac:	1e604100 	fmov	d0, d8
    3db0:	710000bf 	cmp	w5, #0x0
    3db4:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3db8:	aa1503e0 	mov	x0, x21
    3dbc:	d0000044 	adrp	x4, d000 <__divti3+0x2b0>
    3dc0:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3dc4:	911c4084 	add	x4, x4, #0x710
    3dc8:	52800042 	mov	w2, #0x2                   	// #2
    3dcc:	d2803201 	mov	x1, #0x190                 	// #400
    3dd0:	97fffa90 	bl	2810 <__snprintf_chk@plt>
    3dd4:	17ffffd6 	b	3d2c <fwp_format_g.constprop.0+0x198>
    3dd8:	cb140273 	sub	x19, x19, x20
    3ddc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3de0:	910183f9 	add	x25, sp, #0x60
    3de4:	aa1303e2 	mov	x2, x19
    3de8:	aa1403e1 	mov	x1, x20
    3dec:	aa1903e0 	mov	x0, x25
    3df0:	d2800803 	mov	x3, #0x40                  	// #64
    3df4:	97fffa7f 	bl	27f0 <__memcpy_chk@plt>
    3df8:	38336b3f 	strb	wzr, [x25, x19]
    3dfc:	aa1903e0 	mov	x0, x25
    3e00:	528005c1 	mov	w1, #0x2e                  	// #46
    3e04:	97fffadf 	bl	2980 <strchr@plt>
    3e08:	b40001c0 	cbz	x0, 3e40 <fwp_format_g.constprop.0+0x2ac>
    3e0c:	b50000b3 	cbnz	x19, 3e20 <fwp_format_g.constprop.0+0x28c>
    3e10:	1400000c 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3e14:	381ff01f 	sturb	wzr, [x0, #-1]
    3e18:	f1000673 	subs	x19, x19, #0x1
    3e1c:	54000120 	b.eq	3e40 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3e20:	8b130320 	add	x0, x25, x19
    3e24:	385ff001 	ldurb	w1, [x0, #-1]
    3e28:	7100c03f 	cmp	w1, #0x30
    3e2c:	54ffff40 	b.eq	3e14 <fwp_format_g.constprop.0+0x280>  // b.none
    3e30:	d1000673 	sub	x19, x19, #0x1
    3e34:	38736b20 	ldrb	w0, [x25, x19]
    3e38:	7100b81f 	cmp	w0, #0x2e
    3e3c:	54000a80 	b.eq	3f8c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3e40:	710002ff 	cmp	w23, #0x0
    3e44:	528005a1 	mov	w1, #0x2d                  	// #45
    3e48:	aa1903e5 	mov	x5, x25
    3e4c:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3e50:	aa1503e0 	mov	x0, x21
    3e54:	52800566 	mov	w6, #0x2b                  	// #43
    3e58:	d0000044 	adrp	x4, d000 <__divti3+0x2b0>
    3e5c:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3e60:	911c0084 	add	x4, x4, #0x700
    3e64:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3e68:	52800042 	mov	w2, #0x2                   	// #2
    3e6c:	d2803201 	mov	x1, #0x190                 	// #400
    3e70:	97fffa68 	bl	2810 <__snprintf_chk@plt>
    3e74:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3e78:	17ffffbe 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3e7c:	52800605 	mov	w5, #0x30                  	// #48
    3e80:	390000e5 	strb	w5, [x7]
    3e84:	d100077b 	sub	x27, x27, #0x1
    3e88:	aa0303e1 	mov	x1, x3
    3e8c:	aa1603e0 	mov	x0, x22
    3e90:	aa1b03e3 	mov	x3, x27
    3e94:	aa1a03e2 	mov	x2, x26
    3e98:	f90007e6 	str	x6, [sp, #8]
    3e9c:	b90013e4 	str	w4, [sp, #16]
    3ea0:	8b1a02d6 	add	x22, x22, x26
    3ea4:	b9001be5 	str	w5, [sp, #24]
    3ea8:	97fffa52 	bl	27f0 <__memcpy_chk@plt>
    3eac:	f94007e6 	ldr	x6, [sp, #8]
    3eb0:	2a3703e7 	mvn	w7, w23
    3eb4:	b94013e4 	ldr	w4, [sp, #16]
    3eb8:	cb1b00c1 	sub	x1, x6, x27
    3ebc:	cb06037b 	sub	x27, x27, x6
    3ec0:	f101203f 	cmp	x1, #0x48
    3ec4:	d2800906 	mov	x6, #0x48                  	// #72
    3ec8:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ecc:	8b1b0023 	add	x3, x1, x27
    3ed0:	310006ff 	cmn	w23, #0x1
    3ed4:	54000220 	b.eq	3f18 <fwp_format_g.constprop.0+0x384>  // b.none
    3ed8:	b9401be5 	ldr	w5, [sp, #24]
    3edc:	d2800001 	mov	x1, #0x0                   	// #0
    3ee0:	f101207f 	cmp	x3, #0x48
    3ee4:	d1000462 	sub	x2, x3, #0x1
    3ee8:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3eec:	38216ac5 	strb	w5, [x22, x1]
    3ef0:	cb030003 	sub	x3, x0, x3
    3ef4:	91000421 	add	x1, x1, #0x1
    3ef8:	91000463 	add	x3, x3, #0x1
    3efc:	eb00007f 	cmp	x3, x0
    3f00:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3f04:	cb000063 	sub	x3, x3, x0
    3f08:	8b020063 	add	x3, x3, x2
    3f0c:	6b0100ff 	cmp	w7, w1
    3f10:	54fffe8c 	b.gt	3ee0 <fwp_format_g.constprop.0+0x34c>
    3f14:	8b2742d6 	add	x22, x22, w7, uxtw
    3f18:	f101207f 	cmp	x3, #0x48
    3f1c:	d2800905 	mov	x5, #0x48                  	// #72
    3f20:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3f24:	aa1603e0 	mov	x0, x22
    3f28:	cb0300a1 	sub	x1, x5, x3
    3f2c:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3f30:	91000421 	add	x1, x1, #0x1
    3f34:	d1000463 	sub	x3, x3, #0x1
    3f38:	eb05003f 	cmp	x1, x5
    3f3c:	38001402 	strb	w2, [x0], #1
    3f40:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3f44:	93407f82 	sxtw	x2, w28
    3f48:	cb050025 	sub	x5, x1, x5
    3f4c:	aa1303e1 	mov	x1, x19
    3f50:	8b0300a3 	add	x3, x5, x3
    3f54:	8b1802d3 	add	x19, x22, x24
    3f58:	97fffa26 	bl	27f0 <__memcpy_chk@plt>
    3f5c:	17ffff6a 	b	3d04 <fwp_format_g.constprop.0+0x170>
    3f60:	d1000421 	sub	x1, x1, #0x1
    3f64:	38616aa0 	ldrb	w0, [x21, x1]
    3f68:	7100b81f 	cmp	w0, #0x2e
    3f6c:	54fff021 	b.ne	3d70 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3f70:	38216abf 	strb	wzr, [x21, x1]
    3f74:	17ffff7f 	b	3d70 <fwp_format_g.constprop.0+0x1dc>
    3f78:	910187e7 	add	x7, sp, #0x61
    3f7c:	910183f9 	add	x25, sp, #0x60
    3f80:	d28008fb 	mov	x27, #0x47                  	// #71
    3f84:	390183e0 	strb	w0, [sp, #96]
    3f88:	17ffff3a 	b	3c70 <fwp_format_g.constprop.0+0xdc>
    3f8c:	38336b3f 	strb	wzr, [x25, x19]
    3f90:	17ffffac 	b	3e40 <fwp_format_g.constprop.0+0x2ac>
    3f94:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f98:	97fffa42 	bl	28a0 <__stack_chk_fail@plt>
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_heap_report>:
    3fa0:	d105c3ff 	sub	sp, sp, #0x170
    3fa4:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    3fa8:	9118c042 	add	x2, x2, #0x630
    3fac:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3fb0:	f947e821 	ldr	x1, [x1, #4048]
    3fb4:	a9117bfd 	stp	x29, x30, [sp, #272]
    3fb8:	910443fd 	add	x29, sp, #0x110
    3fbc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3fc0:	f947f400 	ldr	x0, [x0, #4072]
    3fc4:	a9135bf5 	stp	x21, x22, [sp, #304]
    3fc8:	a91463f7 	stp	x23, x24, [sp, #320]
    3fcc:	a9156bf9 	stp	x25, x26, [sp, #336]
    3fd0:	6d1627e8 	stp	d8, d9, [sp, #352]
    3fd4:	fd4a1c48 	ldr	d8, [x2, #5176]
    3fd8:	fd4a2049 	ldr	d9, [x2, #5184]
    3fdc:	f9400036 	ldr	x22, [x1]
    3fe0:	f9400001 	ldr	x1, [x0]
    3fe4:	f90087e1 	str	x1, [sp, #264]
    3fe8:	d2800001 	mov	x1, #0x0                   	// #0
    3fec:	f949e459 	ldr	x25, [x2, #5064]
    3ff0:	d0000041 	adrp	x1, d000 <__divti3+0x2b0>
    3ff4:	f94a1057 	ldr	x23, [x2, #5152]
    3ff8:	d0000040 	adrp	x0, d000 <__divti3+0x2b0>
    3ffc:	f94a1458 	ldr	x24, [x2, #5160]
    4000:	911c6021 	add	x1, x1, #0x718
    4004:	911c8000 	add	x0, x0, #0x720
    4008:	97fffa0a 	bl	2830 <fopen@plt>
    400c:	b4000740 	cbz	x0, 40f4 <fwp_heap_report+0x154>
    4010:	528daad5 	mov	w21, #0x6d56                	// #27990
    4014:	a91253f3 	stp	x19, x20, [sp, #288]
    4018:	aa0003f4 	mov	x20, x0
    401c:	910023f3 	add	x19, sp, #0x8
    4020:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4024:	72aae915 	movk	w21, #0x5748, lsl #16
    4028:	aa1403e2 	mov	x2, x20
    402c:	aa1303e0 	mov	x0, x19
    4030:	52802001 	mov	w1, #0x100                 	// #256
    4034:	97fffa87 	bl	2a50 <fgets@plt>
    4038:	b4000280 	cbz	x0, 4088 <fwp_heap_report+0xe8>
    403c:	b9400261 	ldr	w1, [x19]
    4040:	6b15003f 	cmp	w1, w21
    4044:	54ffff21 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4048:	39401260 	ldrb	w0, [x19, #4]
    404c:	7101341f 	cmp	w0, #0x4d
    4050:	54fffec1 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4054:	394037e0 	ldrb	w0, [sp, #13]
    4058:	7100e81f 	cmp	w0, #0x3a
    405c:	54fffe61 	b.ne	4028 <fwp_heap_report+0x88>  // b.any
    4060:	52800142 	mov	w2, #0xa                   	// #10
    4064:	d2800001 	mov	x1, #0x0                   	// #0
    4068:	91003be0 	add	x0, sp, #0xe
    406c:	97fffa35 	bl	2940 <strtol@plt>
    4070:	aa1403e2 	mov	x2, x20
    4074:	aa0003fa 	mov	x26, x0
    4078:	52802001 	mov	w1, #0x100                 	// #256
    407c:	aa1303e0 	mov	x0, x19
    4080:	97fffa74 	bl	2a50 <fgets@plt>
    4084:	b5fffdc0 	cbnz	x0, 403c <fwp_heap_report+0x9c>
    4088:	aa1403e0 	mov	x0, x20
    408c:	97fff9e5 	bl	2820 <fclose@plt>
    4090:	a95253f3 	ldp	x19, x20, [sp, #288]
    4094:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4098:	f947f400 	ldr	x0, [x0, #4072]
    409c:	f94087e2 	ldr	x2, [sp, #264]
    40a0:	f9400001 	ldr	x1, [x0]
    40a4:	eb010042 	subs	x2, x2, x1
    40a8:	d2800001 	mov	x1, #0x0                   	// #0
    40ac:	54000281 	b.ne	40fc <fwp_heap_report+0x15c>  // b.any
    40b0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    40b4:	aa1a03e6 	mov	x6, x26
    40b8:	aa1903e5 	mov	x5, x25
    40bc:	aa1803e4 	mov	x4, x24
    40c0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    40c4:	aa1703e3 	mov	x3, x23
    40c8:	a95463f7 	ldp	x23, x24, [sp, #320]
    40cc:	aa1603e0 	mov	x0, x22
    40d0:	a9535bf5 	ldp	x21, x22, [sp, #304]
    40d4:	1e604121 	fmov	d1, d9
    40d8:	1e604100 	fmov	d0, d8
    40dc:	b0000042 	adrp	x2, d000 <__divti3+0x2b0>
    40e0:	6d5627e8 	ldp	d8, d9, [sp, #352]
    40e4:	911d0042 	add	x2, x2, #0x740
    40e8:	9105c3ff 	add	sp, sp, #0x170
    40ec:	52800041 	mov	w1, #0x2                   	// #2
    40f0:	17fffa08 	b	2910 <__fprintf_chk@plt>
    40f4:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    40f8:	17ffffe7 	b	4094 <fwp_heap_report+0xf4>
    40fc:	a91253f3 	stp	x19, x20, [sp, #288]
    4100:	97fff9e8 	bl	28a0 <__stack_chk_fail@plt>

0000000000004104 <fwp_heap_init>:
    4104:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4108:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9d0>
    410c:	9114c061 	add	x1, x3, #0x530
    4110:	910003fd 	mov	x29, sp
    4114:	a90153f3 	stp	x19, x20, [sp, #16]
    4118:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    411c:	9118c262 	add	x2, x19, #0x630
    4120:	a9025bf5 	stp	x21, x22, [sp, #32]
    4124:	52800024 	mov	w4, #0x1                   	// #1
    4128:	52800200 	mov	w0, #0x10                  	// #16
    412c:	b913a444 	str	w4, [x2, #5028]
    4130:	b8004420 	str	w0, [x1], #4
    4134:	11004000 	add	w0, w0, #0x10
    4138:	7104401f 	cmp	w0, #0x110
    413c:	54ffffa1 	b.ne	4130 <fwp_heap_init+0x2c>  // b.any
    4140:	d0000042 	adrp	x2, e000 <_IO_stdin_used+0xb90>
    4144:	0f002420 	movi	v0.2s, #0x1, lsl #8
    4148:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9d0>
    414c:	9115c021 	add	x1, x1, #0x570
    4150:	3dc11043 	ldr	q3, [x2, #1088]
    4154:	d2800000 	mov	x0, #0x0                   	// #0
    4158:	4e040401 	dup	v1.4s, v0.s[0]
    415c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    4160:	0f215400 	shl	v0.2s, v0.2s, #1
    4164:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    4168:	3ca06821 	str	q1, [x1, x0]
    416c:	91004000 	add	x0, x0, #0x10
    4170:	f101801f 	cmp	x0, #0x60
    4174:	54ffff21 	b.ne	4158 <fwp_heap_init+0x54>  // b.any
    4178:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9d0>
    417c:	9114c063 	add	x3, x3, #0x530
    4180:	91174084 	add	x4, x4, #0x5d0
    4184:	9118c266 	add	x6, x19, #0x630
    4188:	d2800002 	mov	x2, #0x0                   	// #0
    418c:	d2800000 	mov	x0, #0x0                   	// #0
    4190:	d2880205 	mov	x5, #0x4010                	// #16400
    4194:	d503201f 	nop
    4198:	910f0001 	add	x1, x0, #0x3c0
    419c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    41a0:	eb02003f 	cmp	x1, x2
    41a4:	540000a2 	b.cs	41b8 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    41a8:	91000400 	add	x0, x0, #0x1
    41ac:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    41b0:	eb02003f 	cmp	x1, x2
    41b4:	54ffffa3 	b.cc	41a8 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    41b8:	91004042 	add	x2, x2, #0x10
    41bc:	38001480 	strb	w0, [x4], #1
    41c0:	eb05005f 	cmp	x2, x5
    41c4:	54fffea1 	b.ne	4198 <fwp_heap_init+0x94>  // b.any
    41c8:	528000b5 	mov	w21, #0x5                   	// #5
    41cc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    41d0:	14000004 	b	41e0 <fwp_heap_init+0xdc>
    41d4:	d342fe94 	lsr	x20, x20, #2
    41d8:	710006b5 	subs	w21, w21, #0x1
    41dc:	54000720 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    41e0:	91404296 	add	x22, x20, #0x10, lsl #12
    41e4:	d2800005 	mov	x5, #0x0                   	// #0
    41e8:	aa1603e1 	mov	x1, x22
    41ec:	12800004 	mov	w4, #0xffffffff            	// #-1
    41f0:	52880443 	mov	w3, #0x4022                	// #16418
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	d2800000 	mov	x0, #0x0                   	// #0
    41fc:	97fff9cd 	bl	2930 <mmap@plt>
    4200:	aa0003e6 	mov	x6, x0
    4204:	b100041f 	cmn	x0, #0x1
    4208:	54fffe60 	b.eq	41d4 <fwp_heap_init+0xd0>  // b.none
    420c:	b40005a0 	cbz	x0, 42c0 <fwp_heap_init+0x1bc>
    4210:	d350fe94 	lsr	x20, x20, #16
    4214:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4218:	8b0000c7 	add	x7, x6, x0
    421c:	9118c275 	add	x21, x19, #0x630
    4220:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    4224:	8b140a81 	add	x1, x20, x20, lsl #2
    4228:	d2800005 	mov	x5, #0x0                   	// #0
    422c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4230:	d37df021 	lsl	x1, x1, #3
    4234:	52880443 	mov	w3, #0x4022                	// #16418
    4238:	52800002 	mov	w2, #0x0                   	// #0
    423c:	d2800000 	mov	x0, #0x0                   	// #0
    4240:	f909daa7 	str	x7, [x21, #5040]
    4244:	f909dea6 	str	x6, [x21, #5048]
    4248:	f909e2b6 	str	x22, [x21, #5056]
    424c:	f909eab4 	str	x20, [x21, #5072]
    4250:	f90a02a1 	str	x1, [x21, #5120]
    4254:	97fff9b7 	bl	2930 <mmap@plt>
    4258:	aa0003e1 	mov	x1, x0
    425c:	b100041f 	cmn	x0, #0x1
    4260:	54000300 	b.eq	42c0 <fwp_heap_init+0x1bc>  // b.none
    4264:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    4268:	911fc000 	add	x0, x0, #0x7f0
    426c:	f909fea1 	str	x1, [x21, #5112]
    4270:	97fff9f0 	bl	2a30 <getenv@plt>
    4274:	52800002 	mov	w2, #0x0                   	// #0
    4278:	aa0003e1 	mov	x1, x0
    427c:	b40000e0 	cbz	x0, 4298 <fwp_heap_init+0x194>
    4280:	39400000 	ldrb	w0, [x0]
    4284:	340000a0 	cbz	w0, 4298 <fwp_heap_init+0x194>
    4288:	7100c000 	subs	w0, w0, #0x30
    428c:	54000120 	b.eq	42b0 <fwp_heap_init+0x1ac>  // b.none
    4290:	7100001f 	cmp	w0, #0x0
    4294:	1a9f07e2 	cset	w2, ne	// ne = any
    4298:	9118c273 	add	x19, x19, #0x630
    429c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42a0:	b913aa62 	str	w2, [x19, #5032]
    42a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    42a8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    42ac:	d65f03c0 	ret
    42b0:	39400420 	ldrb	w0, [x1, #1]
    42b4:	7100001f 	cmp	w0, #0x0
    42b8:	1a9f07e2 	cset	w2, ne	// ne = any
    42bc:	17fffff7 	b	4298 <fwp_heap_init+0x194>
    42c0:	97fffbac 	bl	3170 <fwp_heap_oom>

00000000000042c4 <fwp_wake_io>:
    42c4:	900000e9 	adrp	x9, 20000 <__data_start>
    42c8:	91014122 	add	x2, x9, #0x50
    42cc:	f9400001 	ldr	x1, [x0]
    42d0:	5280000a 	mov	w10, #0x0                   	// #0
    42d4:	f9406046 	ldr	x6, [x2, #192]
    42d8:	52800008 	mov	w8, #0x0                   	// #0
    42dc:	4f000400 	movi	v0.4s, #0x0
    42e0:	52800027 	mov	w7, #0x1                   	// #1
    42e4:	aa0103e2 	mov	x2, x1
    42e8:	b4000321 	cbz	x1, 434c <fwp_wake_io+0x88>
    42ec:	f9408c25 	ldr	x5, [x1, #280]
    42f0:	39015c27 	strb	w7, [x1, #87]
    42f4:	b4000165 	cbz	x5, 4320 <fwp_wake_io+0x5c>
    42f8:	a9520c24 	ldp	x4, x3, [x1, #288]
    42fc:	b4000364 	cbz	x4, 4368 <fwp_wake_io+0xa4>
    4300:	f9009483 	str	x3, [x4, #296]
    4304:	f9409423 	ldr	x3, [x1, #296]
    4308:	b4000043 	cbz	x3, 4310 <fwp_wake_io+0x4c>
    430c:	f9009064 	str	x4, [x3, #288]
    4310:	91080023 	add	x3, x1, #0x200
    4314:	f900943f 	str	xzr, [x1, #296]
    4318:	3c918060 	stur	q0, [x3, #-232]
    431c:	f9400001 	ldr	x1, [x0]
    4320:	f9402843 	ldr	x3, [x2, #80]
    4324:	f2001c7f 	tst	x3, #0xff000000ff
    4328:	54fffde1 	b.ne	42e4 <fwp_wake_io+0x20>  // b.any
    432c:	39015047 	strb	w7, [x2, #84]
    4330:	f900805f 	str	xzr, [x2, #256]
    4334:	b40001e6 	cbz	x6, 4370 <fwp_wake_io+0xac>
    4338:	f90080c2 	str	x2, [x6, #256]
    433c:	aa0203e6 	mov	x6, x2
    4340:	52800028 	mov	w8, #0x1                   	// #1
    4344:	aa0103e2 	mov	x2, x1
    4348:	b5fffd21 	cbnz	x1, 42ec <fwp_wake_io+0x28>
    434c:	3400006a 	cbz	w10, 4358 <fwp_wake_io+0x94>
    4350:	91014120 	add	x0, x9, #0x50
    4354:	f900640b 	str	x11, [x0, #200]
    4358:	34000068 	cbz	w8, 4364 <fwp_wake_io+0xa0>
    435c:	91014129 	add	x9, x9, #0x50
    4360:	f9006126 	str	x6, [x9, #192]
    4364:	d65f03c0 	ret
    4368:	f90000a3 	str	x3, [x5]
    436c:	17ffffe7 	b	4308 <fwp_wake_io+0x44>
    4370:	aa0203eb 	mov	x11, x2
    4374:	5280002a 	mov	w10, #0x1                   	// #1
    4378:	17fffff1 	b	433c <fwp_wake_io+0x78>
    437c:	d503201f 	nop

0000000000004380 <ad_raw_free.part.0>:
    4380:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbb0>
    4384:	d2800001 	mov	x1, #0x0                   	// #0
    4388:	91114082 	add	x2, x4, #0x450
    438c:	14000005 	b	43a0 <ad_raw_free.part.0+0x20>
    4390:	91000421 	add	x1, x1, #0x1
    4394:	91006042 	add	x2, x2, #0x18
    4398:	f140043f 	cmp	x1, #0x1, lsl #12
    439c:	54000220 	b.eq	43e0 <ad_raw_free.part.0+0x60>  // b.none
    43a0:	f9400043 	ldr	x3, [x2]
    43a4:	eb03001f 	cmp	x0, x3
    43a8:	54ffff41 	b.ne	4390 <ad_raw_free.part.0+0x10>  // b.any
    43ac:	8b010421 	add	x1, x1, x1, lsl #1
    43b0:	91114084 	add	x4, x4, #0x450
    43b4:	900000e2 	adrp	x2, 20000 <__data_start>
    43b8:	91014042 	add	x2, x2, #0x50
    43bc:	8b010c81 	add	x1, x4, x1, lsl #3
    43c0:	b9401024 	ldr	w4, [x1, #16]
    43c4:	f9400425 	ldr	x5, [x1, #8]
    43c8:	a9007c3f 	stp	xzr, xzr, [x1]
    43cc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    43d0:	f900083f 	str	xzr, [x1, #16]
    43d4:	cb050061 	sub	x1, x3, x5
    43d8:	f8247841 	str	x1, [x2, x4, lsl #3]
    43dc:	17fff961 	b	2960 <free@plt>
    43e0:	f100001f 	cmp	x0, #0x0
    43e4:	b0000041 	adrp	x1, d000 <__divti3+0x2b0>
    43e8:	91206021 	add	x1, x1, #0x818
    43ec:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    43f0:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    43f4:	91200000 	add	x0, x0, #0x800
    43f8:	910003fd 	mov	x29, sp
    43fc:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4400:	97fffbe0 	bl	3380 <ad_raw_fail>

0000000000004404 <fwp_tape_buffers_dispose>:
    4404:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4408:	910003fd 	mov	x29, sp
    440c:	f9000bf3 	str	x19, [sp, #16]
    4410:	aa0003f3 	mov	x19, x0
    4414:	f9400000 	ldr	x0, [x0]
    4418:	b4000040 	cbz	x0, 4420 <fwp_tape_buffers_dispose+0x1c>
    441c:	97ffffd9 	bl	4380 <ad_raw_free.part.0>
    4420:	f9400a60 	ldr	x0, [x19, #16]
    4424:	b4000040 	cbz	x0, 442c <fwp_tape_buffers_dispose+0x28>
    4428:	97ffffd6 	bl	4380 <ad_raw_free.part.0>
    442c:	f9401260 	ldr	x0, [x19, #32]
    4430:	b4000040 	cbz	x0, 4438 <fwp_tape_buffers_dispose+0x34>
    4434:	97ffffd3 	bl	4380 <ad_raw_free.part.0>
    4438:	4f000400 	movi	v0.4s, #0x0
    443c:	f9001a7f 	str	xzr, [x19, #48]
    4440:	ad000260 	stp	q0, q0, [x19]
    4444:	3d800a60 	str	q0, [x19, #32]
    4448:	f9400bf3 	ldr	x19, [sp, #16]
    444c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4450:	d65f03c0 	ret

0000000000004454 <ad_raw_realloc>:
    4454:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4458:	910003fd 	mov	x29, sp
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	f90013f5 	str	x21, [sp, #32]
    4464:	b40005a1 	cbz	x1, 4518 <ad_raw_realloc+0xc4>
    4468:	aa0103f4 	mov	x20, x1
    446c:	2a0203f5 	mov	w21, w2
    4470:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbb0>
    4474:	d2800004 	mov	x4, #0x0                   	// #0
    4478:	91114025 	add	x5, x1, #0x450
    447c:	14000005 	b	4490 <ad_raw_realloc+0x3c>
    4480:	91000484 	add	x4, x4, #0x1
    4484:	910060a5 	add	x5, x5, #0x18
    4488:	f140049f 	cmp	x4, #0x1, lsl #12
    448c:	54000320 	b.eq	44f0 <ad_raw_realloc+0x9c>  // b.none
    4490:	f94000a6 	ldr	x6, [x5]
    4494:	eb06001f 	cmp	x0, x6
    4498:	54ffff41 	b.ne	4480 <ad_raw_realloc+0x2c>  // b.any
    449c:	8b040484 	add	x4, x4, x4, lsl #1
    44a0:	91114021 	add	x1, x1, #0x450
    44a4:	8b040c33 	add	x19, x1, x4, lsl #3
    44a8:	b4000080 	cbz	x0, 44b8 <ad_raw_realloc+0x64>
    44ac:	b9401261 	ldr	w1, [x19, #16]
    44b0:	6b15003f 	cmp	w1, w21
    44b4:	540002c1 	b.ne	450c <ad_raw_realloc+0xb8>  // b.any
    44b8:	aa1403e1 	mov	x1, x20
    44bc:	97fff8f5 	bl	2890 <realloc@plt>
    44c0:	aa0003ed 	mov	x13, x0
    44c4:	b40000c0 	cbz	x0, 44dc <ad_raw_realloc+0x88>
    44c8:	2a1503e3 	mov	w3, w21
    44cc:	aa1403e2 	mov	x2, x20
    44d0:	aa1303e0 	mov	x0, x19
    44d4:	aa0d03e1 	mov	x1, x13
    44d8:	97fffaae 	bl	2f90 <ad_raw_record>
    44dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    44e0:	aa0d03e0 	mov	x0, x13
    44e4:	f94013f5 	ldr	x21, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	f100001f 	cmp	x0, #0x0
    44f4:	b0000041 	adrp	x1, d000 <__divti3+0x2b0>
    44f8:	91206021 	add	x1, x1, #0x818
    44fc:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    4500:	91200000 	add	x0, x0, #0x800
    4504:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4508:	97fffb9e 	bl	3380 <ad_raw_fail>
    450c:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    4510:	91216000 	add	x0, x0, #0x858
    4514:	97fffb9b 	bl	3380 <ad_raw_fail>
    4518:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    451c:	9120e000 	add	x0, x0, #0x838
    4520:	97fffb98 	bl	3380 <ad_raw_fail>

0000000000004524 <fwp_tape_buffers_release>:
    4524:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4528:	910003fd 	mov	x29, sp
    452c:	a90153f3 	stp	x19, x20, [sp, #16]
    4530:	aa0003f4 	mov	x20, x0
    4534:	f9401400 	ldr	x0, [x0, #40]
    4538:	a9025bf5 	stp	x21, x22, [sp, #32]
    453c:	b7f80560 	tbnz	x0, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4540:	f9401a93 	ldr	x19, [x20, #48]
    4544:	b7f80533 	tbnz	x19, #63, 45e8 <fwp_tape_buffers_release+0xc4>
    4548:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    454c:	eb01001f 	cmp	x0, x1
    4550:	540004c8 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4554:	8b000400 	add	x0, x0, x0, lsl #1
    4558:	d2a00101 	mov	x1, #0x80000               	// #524288
    455c:	d37df000 	lsl	x0, x0, #3
    4560:	cb000021 	sub	x1, x1, x0
    4564:	eb410e7f 	cmp	x19, x1, lsr #3
    4568:	54000408 	b.hi	45e8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    456c:	8b130c13 	add	x19, x0, x19, lsl #3
    4570:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    4574:	9121c000 	add	x0, x0, #0x870
    4578:	97fff92e 	bl	2a30 <getenv@plt>
    457c:	b4000080 	cbz	x0, 458c <fwp_tape_buffers_release+0x68>
    4580:	39400001 	ldrb	w1, [x0]
    4584:	7100c03f 	cmp	w1, #0x30
    4588:	54000880 	b.eq	4698 <fwp_tape_buffers_release+0x174>  // b.none
    458c:	d1000661 	sub	x1, x19, #0x1
    4590:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4594:	eb00003f 	cmp	x1, x0
    4598:	54000328 	b.hi	45fc <fwp_tape_buffers_release+0xd8>  // b.pmore
    459c:	900000f5 	adrp	x21, 20000 <__data_start>
    45a0:	f9001bf7 	str	x23, [sp, #48]
    45a4:	910142b7 	add	x23, x21, #0x50
    45a8:	910382f6 	add	x22, x23, #0xe0
    45ac:	aa1603e0 	mov	x0, x22
    45b0:	97ffff95 	bl	4404 <fwp_tape_buffers_dispose>
    45b4:	ad400a81 	ldp	q1, q2, [x20]
    45b8:	f9008ef3 	str	x19, [x23, #280]
    45bc:	4f000400 	movi	v0.4s, #0x0
    45c0:	ad000ac1 	stp	q1, q2, [x22]
    45c4:	3dc00a81 	ldr	q1, [x20, #32]
    45c8:	3d800ac1 	str	q1, [x22, #32]
    45cc:	f9401a80 	ldr	x0, [x20, #48]
    45d0:	f9001ac0 	str	x0, [x22, #48]
    45d4:	f9001a9f 	str	xzr, [x20, #48]
    45d8:	ad000280 	stp	q0, q0, [x20]
    45dc:	3d800a80 	str	q0, [x20, #32]
    45e0:	f9401bf7 	ldr	x23, [sp, #48]
    45e4:	1400000b 	b	4610 <fwp_tape_buffers_release+0xec>
    45e8:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    45ec:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    45f0:	9121c000 	add	x0, x0, #0x870
    45f4:	97fff90f 	bl	2a30 <getenv@plt>
    45f8:	b5fffc40 	cbnz	x0, 4580 <fwp_tape_buffers_release+0x5c>
    45fc:	aa1403e0 	mov	x0, x20
    4600:	97ffff81 	bl	4404 <fwp_tape_buffers_dispose>
    4604:	900000f5 	adrp	x21, 20000 <__data_start>
    4608:	910142a0 	add	x0, x21, #0x50
    460c:	f9408c13 	ldr	x19, [x0, #280]
    4610:	910142a2 	add	x2, x21, #0x50
    4614:	f9409044 	ldr	x4, [x2, #288]
    4618:	a9400c45 	ldp	x5, x3, [x2]
    461c:	8b040481 	add	x1, x4, x4, lsl #1
    4620:	f9400840 	ldr	x0, [x2, #16]
    4624:	8b010881 	add	x1, x4, x1, lsl #2
    4628:	f9400c44 	ldr	x4, [x2, #24]
    462c:	8b0300a3 	add	x3, x5, x3
    4630:	d37df021 	lsl	x1, x1, #3
    4634:	8b040000 	add	x0, x0, x4
    4638:	8b030000 	add	x0, x0, x3
    463c:	eb05003f 	cmp	x1, x5
    4640:	54000321 	b.ne	46a4 <fwp_tape_buffers_release+0x180>  // b.any
    4644:	8b130023 	add	x3, x1, x19
    4648:	eb00007f 	cmp	x3, x0
    464c:	540002c8 	b.hi	46a4 <fwp_tape_buffers_release+0x180>  // b.pmore
    4650:	f9405c43 	ldr	x3, [x2, #184]
    4654:	f140087f 	cmp	x3, #0x2, lsl #12
    4658:	540002e0 	b.eq	46b4 <fwp_tape_buffers_release+0x190>  // b.none
    465c:	8b030464 	add	x4, x3, x3, lsl #1
    4660:	90000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    4664:	911140a5 	add	x5, x5, #0x450
    4668:	cb010000 	sub	x0, x0, x1
    466c:	d37df084 	lsl	x4, x4, #3
    4670:	cb130000 	sub	x0, x0, x19
    4674:	8b0400a6 	add	x6, x5, x4
    4678:	91000463 	add	x3, x3, #0x1
    467c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4680:	f82468a1 	str	x1, [x5, x4]
    4684:	a90080d3 	stp	x19, x0, [x6, #8]
    4688:	f9005c43 	str	x3, [x2, #184]
    468c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4690:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4694:	d65f03c0 	ret
    4698:	39400400 	ldrb	w0, [x0, #1]
    469c:	34fffb00 	cbz	w0, 45fc <fwp_tape_buffers_release+0xd8>
    46a0:	17ffffbb 	b	458c <fwp_tape_buffers_release+0x68>
    46a4:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    46a8:	91222000 	add	x0, x0, #0x888
    46ac:	f9001bf7 	str	x23, [sp, #48]
    46b0:	97fffb34 	bl	3380 <ad_raw_fail>
    46b4:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    46b8:	9122e000 	add	x0, x0, #0x8b8
    46bc:	f9001bf7 	str	x23, [sp, #48]
    46c0:	97fffb30 	bl	3380 <ad_raw_fail>

00000000000046c4 <fwp_poll_events>:
    46c4:	d10103ff 	sub	sp, sp, #0x40
    46c8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    46cc:	f947f400 	ldr	x0, [x0, #4072]
    46d0:	a9027bfd 	stp	x29, x30, [sp, #32]
    46d4:	910083fd 	add	x29, sp, #0x20
    46d8:	a90353f3 	stp	x19, x20, [sp, #48]
    46dc:	900000f4 	adrp	x20, 20000 <__data_start>
    46e0:	f9400001 	ldr	x1, [x0]
    46e4:	f9000fe1 	str	x1, [sp, #24]
    46e8:	d2800001 	mov	x1, #0x0                   	// #0
    46ec:	97fffca5 	bl	3980 <fwp_now_ns>
    46f0:	91014281 	add	x1, x20, #0x50
    46f4:	f9409433 	ldr	x19, [x1, #296]
    46f8:	b4000e73 	cbz	x19, 48c4 <fwp_poll_events+0x200>
    46fc:	aa1303e1 	mov	x1, x19
    4700:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4704:	14000005 	b	4718 <fwp_poll_events+0x54>
    4708:	f9408821 	ldr	x1, [x1, #272]
    470c:	eb03005f 	cmp	x2, x3
    4710:	9a83d042 	csel	x2, x2, x3, le
    4714:	b40000c1 	cbz	x1, 472c <fwp_poll_events+0x68>
    4718:	f9403423 	ldr	x3, [x1, #104]
    471c:	b6ffff62 	tbz	x2, #63, 4708 <fwp_poll_events+0x44>
    4720:	f9408821 	ldr	x1, [x1, #272]
    4724:	aa0303e2 	mov	x2, x3
    4728:	b5ffff81 	cbnz	x1, 4718 <fwp_poll_events+0x54>
    472c:	b7f80cc2 	tbnz	x2, #63, 48c4 <fwp_poll_events+0x200>
    4730:	cb000042 	sub	x2, x2, x0
    4734:	f100005f 	cmp	x2, #0x0
    4738:	540005ad 	b.le	47ec <fwp_poll_events+0x128>
    473c:	d2869b60 	mov	x0, #0x34db                	// #13531
    4740:	d2884801 	mov	x1, #0x4240                	// #16960
    4744:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4748:	f2a001e1 	movk	x1, #0xf, lsl #16
    474c:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4750:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    4754:	f2e86360 	movk	x0, #0x431b, lsl #48
    4758:	9b407c40 	smulh	x0, x2, x0
    475c:	9352fc00 	asr	x0, x0, #18
    4760:	cb82fc00 	sub	x0, x0, x2, asr #63
    4764:	9b018802 	msub	x2, x0, x1, x2
    4768:	f100005f 	cmp	x2, #0x0
    476c:	9a800400 	cinc	x0, x0, ne	// ne = any
    4770:	eb03001f 	cmp	x0, x3
    4774:	540009ec 	b.gt	48b0 <fwp_poll_events+0x1ec>
    4778:	340003a0 	cbz	w0, 47ec <fwp_poll_events+0x128>
    477c:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4780:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4784:	72a20c42 	movk	w2, #0x1062, lsl #16
    4788:	9ba27c02 	umull	x2, w0, w2
    478c:	d366fc43 	lsr	x3, x2, #38
    4790:	aa0303e2 	mov	x2, x3
    4794:	1b048063 	msub	w3, w3, w4, w0
    4798:	9b217c63 	smull	x3, w3, w1
    479c:	d2800001 	mov	x1, #0x0                   	// #0
    47a0:	910023e0 	add	x0, sp, #0x8
    47a4:	a9008fe2 	stp	x2, x3, [sp, #8]
    47a8:	97fff872 	bl	2970 <nanosleep@plt>
    47ac:	91014280 	add	x0, x20, #0x50
    47b0:	f9409413 	ldr	x19, [x0, #296]
    47b4:	97fffc73 	bl	3980 <fwp_now_ns>
    47b8:	aa0003e6 	mov	x6, x0
    47bc:	b50001d3 	cbnz	x19, 47f4 <fwp_poll_events+0x130>
    47c0:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    47c4:	f947f400 	ldr	x0, [x0, #4072]
    47c8:	f9400fe2 	ldr	x2, [sp, #24]
    47cc:	f9400001 	ldr	x1, [x0]
    47d0:	eb010042 	subs	x2, x2, x1
    47d4:	d2800001 	mov	x1, #0x0                   	// #0
    47d8:	540008c1 	b.ne	48f0 <fwp_poll_events+0x22c>  // b.any
    47dc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    47e0:	a94353f3 	ldp	x19, x20, [sp, #48]
    47e4:	910103ff 	add	sp, sp, #0x40
    47e8:	d65f03c0 	ret
    47ec:	97fffc65 	bl	3980 <fwp_now_ns>
    47f0:	aa0003e6 	mov	x6, x0
    47f4:	4f000400 	movi	v0.4s, #0x0
    47f8:	91014288 	add	x8, x20, #0x50
    47fc:	52800027 	mov	w7, #0x1                   	// #1
    4800:	f9403661 	ldr	x1, [x19, #104]
    4804:	aa1303e5 	mov	x5, x19
    4808:	f9408a73 	ldr	x19, [x19, #272]
    480c:	eb06003f 	cmp	x1, x6
    4810:	5400032c 	b.gt	4874 <fwp_poll_events+0x1b0>
    4814:	394154a0 	ldrb	w0, [x5, #85]
    4818:	36000120 	tbz	w0, #0, 483c <fwp_poll_events+0x178>
    481c:	f94084a0 	ldr	x0, [x5, #264]
    4820:	b40003c0 	cbz	x0, 4898 <fwp_poll_events+0x1d4>
    4824:	f9008813 	str	x19, [x0, #272]
    4828:	b4000053 	cbz	x19, 4830 <fwp_poll_events+0x16c>
    482c:	f9008660 	str	x0, [x19, #264]
    4830:	910800a0 	add	x0, x5, #0x200
    4834:	390154bf 	strb	wzr, [x5, #85]
    4838:	3c908000 	stur	q0, [x0, #-248]
    483c:	f94030a0 	ldr	x0, [x5, #96]
    4840:	390158a7 	strb	w7, [x5, #86]
    4844:	f100001f 	cmp	x0, #0x0
    4848:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    484c:	5400018d 	b.le	487c <fwp_poll_events+0x1b8>
    4850:	f94028a0 	ldr	x0, [x5, #80]
    4854:	f2001c1f 	tst	x0, #0xff000000ff
    4858:	540000e1 	b.ne	4874 <fwp_poll_events+0x1b0>  // b.any
    485c:	f9406100 	ldr	x0, [x8, #192]
    4860:	390150a7 	strb	w7, [x5, #84]
    4864:	f90080bf 	str	xzr, [x5, #256]
    4868:	b40001e0 	cbz	x0, 48a4 <fwp_poll_events+0x1e0>
    486c:	f9006105 	str	x5, [x8, #192]
    4870:	f9008005 	str	x5, [x0, #256]
    4874:	b5fffc73 	cbnz	x19, 4800 <fwp_poll_events+0x13c>
    4878:	17ffffd2 	b	47c0 <fwp_poll_events+0xfc>
    487c:	394144a0 	ldrb	w0, [x5, #81]
    4880:	3707fe80 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    4884:	394140a0 	ldrb	w0, [x5, #80]
    4888:	3707fe40 	tbnz	w0, #0, 4850 <fwp_poll_events+0x18c>
    488c:	aa0503e0 	mov	x0, x5
    4890:	97fffb98 	bl	36f0 <fwp_cancel_tree.part.0>
    4894:	17ffffef 	b	4850 <fwp_poll_events+0x18c>
    4898:	91014281 	add	x1, x20, #0x50
    489c:	f9009433 	str	x19, [x1, #296]
    48a0:	17ffffe2 	b	4828 <fwp_poll_events+0x164>
    48a4:	f9006105 	str	x5, [x8, #192]
    48a8:	f9006505 	str	x5, [x8, #200]
    48ac:	17fffff2 	b	4874 <fwp_poll_events+0x1b0>
    48b0:	d28df803 	mov	x3, #0x6fc0                	// #28608
    48b4:	d2989362 	mov	x2, #0xc49b                	// #50331
    48b8:	f2a4d203 	movk	x3, #0x2690, lsl #16
    48bc:	f2a00402 	movk	x2, #0x20, lsl #16
    48c0:	17ffffb7 	b	479c <fwp_poll_events+0xd8>
    48c4:	97fff9ec 	bl	3074 <fwp_flush>
    48c8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    48cc:	f947e863 	ldr	x3, [x3, #4048]
    48d0:	d2800562 	mov	x2, #0x2b                  	// #43
    48d4:	d2800021 	mov	x1, #0x1                   	// #1
    48d8:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    48dc:	91236000 	add	x0, x0, #0x8d8
    48e0:	f9400063 	ldr	x3, [x3]
    48e4:	97fff82f 	bl	29a0 <fwrite@plt>
    48e8:	52800ca0 	mov	w0, #0x65                  	// #101
    48ec:	97fff799 	bl	2750 <exit@plt>
    48f0:	97fff7ec 	bl	28a0 <__stack_chk_fail@plt>

00000000000048f4 <fwp_rc_wide_dup>:
    48f4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    48f8:	910003fd 	mov	x29, sp
    48fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4900:	aa0003f3 	mov	x19, x0
    4904:	ca404400 	eor	x0, x0, x0, lsr #17
    4908:	f90013f5 	str	x21, [sp, #32]
    490c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4910:	ca402400 	eor	x0, x0, x0, lsr #9
    4914:	9118c2a2 	add	x2, x21, #0x630
    4918:	92401c00 	and	x0, x0, #0xff
    491c:	910a2403 	add	x3, x0, #0x289
    4920:	8b000c40 	add	x0, x2, x0, lsl #3
    4924:	8b030c54 	add	x20, x2, x3, lsl #3
    4928:	f94a2401 	ldr	x1, [x0, #5192]
    492c:	b50000a1 	cbnz	x1, 4940 <fwp_rc_wide_dup+0x4c>
    4930:	1400002d 	b	49e4 <fwp_rc_wide_dup+0xf0>
    4934:	91004034 	add	x20, x1, #0x10
    4938:	f9400821 	ldr	x1, [x1, #16]
    493c:	b4000241 	cbz	x1, 4984 <fwp_rc_wide_dup+0x90>
    4940:	f9400022 	ldr	x2, [x1]
    4944:	eb02027f 	cmp	x19, x2
    4948:	54ffff61 	b.ne	4934 <fwp_rc_wide_dup+0x40>  // b.any
    494c:	f9400281 	ldr	x1, [x20]
    4950:	39400260 	ldrb	w0, [x19]
    4954:	7103f81f 	cmp	w0, #0xfe
    4958:	54000220 	b.eq	499c <fwp_rc_wide_dup+0xa8>  // b.none
    495c:	b40001a1 	cbz	x1, 4990 <fwp_rc_wide_dup+0x9c>
    4960:	f9400420 	ldr	x0, [x1, #8]
    4964:	b100041f 	cmn	x0, #0x1
    4968:	540004a0 	b.eq	49fc <fwp_rc_wide_dup+0x108>  // b.none
    496c:	91000400 	add	x0, x0, #0x1
    4970:	f9000420 	str	x0, [x1, #8]
    4974:	a94153f3 	ldp	x19, x20, [sp, #16]
    4978:	f94013f5 	ldr	x21, [sp, #32]
    497c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4980:	d65f03c0 	ret
    4984:	39400260 	ldrb	w0, [x19]
    4988:	7103f81f 	cmp	w0, #0xfe
    498c:	540000a0 	b.eq	49a0 <fwp_rc_wide_dup+0xac>  // b.none
    4990:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    4994:	9124c000 	add	x0, x0, #0x930
    4998:	97fffb9a 	bl	3800 <fwp_trap>
    499c:	b5000281 	cbnz	x1, 49ec <fwp_rc_wide_dup+0xf8>
    49a0:	d2800300 	mov	x0, #0x18                  	// #24
    49a4:	97fff7a7 	bl	2840 <malloc@plt>
    49a8:	b4000280 	cbz	x0, 49f8 <fwp_rc_wide_dup+0x104>
    49ac:	d2801fe1 	mov	x1, #0xff                  	// #255
    49b0:	a9000413 	stp	x19, x1, [x0]
    49b4:	9118c2b5 	add	x21, x21, #0x630
    49b8:	f900081f 	str	xzr, [x0, #16]
    49bc:	12800001 	mov	w1, #0xffffffff            	// #-1
    49c0:	f9000280 	str	x0, [x20]
    49c4:	39000261 	strb	w1, [x19]
    49c8:	f94e26a0 	ldr	x0, [x21, #7240]
    49cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    49d0:	91000400 	add	x0, x0, #0x1
    49d4:	f90e26a0 	str	x0, [x21, #7240]
    49d8:	f94013f5 	ldr	x21, [sp, #32]
    49dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    49e0:	d65f03c0 	ret
    49e4:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    49e8:	17ffffda 	b	4950 <fwp_rc_wide_dup+0x5c>
    49ec:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    49f0:	91242000 	add	x0, x0, #0x908
    49f4:	97fffb83 	bl	3800 <fwp_trap>
    49f8:	97fff9de 	bl	3170 <fwp_heap_oom>
    49fc:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    4a00:	91256000 	add	x0, x0, #0x958
    4a04:	97fffb7f 	bl	3800 <fwp_trap>
    4a08:	d503201f 	nop
    4a0c:	d503201f 	nop

0000000000004a10 <fwp_rc_forget_slot>:
    4a10:	aa0003e1 	mov	x1, x0
    4a14:	39400000 	ldrb	w0, [x0]
    4a18:	7103fc1f 	cmp	w0, #0xff
    4a1c:	54000040 	b.eq	4a24 <fwp_rc_forget_slot+0x14>  // b.none
    4a20:	d65f03c0 	ret
    4a24:	ca414420 	eor	x0, x1, x1, lsr #17
    4a28:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4a2c:	ca402400 	eor	x0, x0, x0, lsr #9
    4a30:	910003fd 	mov	x29, sp
    4a34:	92401c00 	and	x0, x0, #0xff
    4a38:	f9000bf3 	str	x19, [sp, #16]
    4a3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4a40:	9118c262 	add	x2, x19, #0x630
    4a44:	910a2403 	add	x3, x0, #0x289
    4a48:	8b000c40 	add	x0, x2, x0, lsl #3
    4a4c:	8b030c43 	add	x3, x2, x3, lsl #3
    4a50:	f94a2400 	ldr	x0, [x0, #5192]
    4a54:	b50000a0 	cbnz	x0, 4a68 <fwp_rc_forget_slot+0x58>
    4a58:	14000011 	b	4a9c <fwp_rc_forget_slot+0x8c>
    4a5c:	91004003 	add	x3, x0, #0x10
    4a60:	f9400800 	ldr	x0, [x0, #16]
    4a64:	b40001c0 	cbz	x0, 4a9c <fwp_rc_forget_slot+0x8c>
    4a68:	f9400002 	ldr	x2, [x0]
    4a6c:	eb02003f 	cmp	x1, x2
    4a70:	54ffff61 	b.ne	4a5c <fwp_rc_forget_slot+0x4c>  // b.any
    4a74:	f9400801 	ldr	x1, [x0, #16]
    4a78:	9118c273 	add	x19, x19, #0x630
    4a7c:	f9000061 	str	x1, [x3]
    4a80:	97fff7b8 	bl	2960 <free@plt>
    4a84:	f94e2660 	ldr	x0, [x19, #7240]
    4a88:	d1000400 	sub	x0, x0, #0x1
    4a8c:	f90e2660 	str	x0, [x19, #7240]
    4a90:	f9400bf3 	ldr	x19, [sp, #16]
    4a94:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a98:	d65f03c0 	ret
    4a9c:	b0000040 	adrp	x0, d000 <__divti3+0x2b0>
    4aa0:	9124c000 	add	x0, x0, #0x930
    4aa4:	97fffb57 	bl	3800 <fwp_trap>
    4aa8:	d503201f 	nop
    4aac:	d503201f 	nop

0000000000004ab0 <fwp_rc_prepare_chunk>:
    4ab0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4ab4:	910003fd 	mov	x29, sp
    4ab8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4abc:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    4ac0:	9118c2c2 	add	x2, x22, #0x630
    4ac4:	b9401c03 	ldr	w3, [x0, #28]
    4ac8:	aa0103f5 	mov	x21, x1
    4acc:	a90153f3 	stp	x19, x20, [sp, #16]
    4ad0:	aa0003f4 	mov	x20, x0
    4ad4:	f94e2440 	ldr	x0, [x2, #7240]
    4ad8:	b4000440 	cbz	x0, 4b60 <fwp_rc_prepare_chunk+0xb0>
    4adc:	d2800013 	mov	x19, #0x0                   	// #0
    4ae0:	35000203 	cbnz	w3, 4b20 <fwp_rc_prepare_chunk+0x70>
    4ae4:	b4000361 	cbz	x1, 4b50 <fwp_rc_prepare_chunk+0xa0>
    4ae8:	f9401280 	ldr	x0, [x20, #32]
    4aec:	97fff79d 	bl	2960 <free@plt>
    4af0:	aa1503e0 	mov	x0, x21
    4af4:	d2800021 	mov	x1, #0x1                   	// #1
    4af8:	97fff762 	bl	2880 <calloc@plt>
    4afc:	f9001280 	str	x0, [x20, #32]
    4b00:	b5000460 	cbnz	x0, 4b8c <fwp_rc_prepare_chunk+0xdc>
    4b04:	97fff99b 	bl	3170 <fwp_heap_oom>
    4b08:	97ffffc2 	bl	4a10 <fwp_rc_forget_slot>
    4b0c:	91000673 	add	x19, x19, #0x1
    4b10:	b9401e83 	ldr	w3, [x20, #28]
    4b14:	eb13007f 	cmp	x3, x19
    4b18:	54000169 	b.ls	4b44 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4b1c:	d503201f 	nop
    4b20:	f9401283 	ldr	x3, [x20, #32]
    4b24:	8b130060 	add	x0, x3, x19
    4b28:	38736863 	ldrb	w3, [x3, x19]
    4b2c:	7103fc7f 	cmp	w3, #0xff
    4b30:	54fffec0 	b.eq	4b08 <fwp_rc_prepare_chunk+0x58>  // b.none
    4b34:	b9401e83 	ldr	w3, [x20, #28]
    4b38:	91000673 	add	x19, x19, #0x1
    4b3c:	eb13007f 	cmp	x3, x19
    4b40:	54ffff08 	b.hi	4b20 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4b44:	eb0302bf 	cmp	x21, x3
    4b48:	54000121 	b.ne	4b6c <fwp_rc_prepare_chunk+0xbc>  // b.any
    4b4c:	b5000335 	cbnz	x21, 4bb0 <fwp_rc_prepare_chunk+0x100>
    4b50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b58:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b5c:	d65f03c0 	ret
    4b60:	2a0303e3 	mov	w3, w3
    4b64:	eb0302bf 	cmp	x21, x3
    4b68:	54ffff20 	b.eq	4b4c <fwp_rc_prepare_chunk+0x9c>  // b.none
    4b6c:	9118c2c2 	add	x2, x22, #0x630
    4b70:	f9401280 	ldr	x0, [x20, #32]
    4b74:	f94e2841 	ldr	x1, [x2, #7248]
    4b78:	cb030021 	sub	x1, x1, x3
    4b7c:	f90e2841 	str	x1, [x2, #7248]
    4b80:	97fff778 	bl	2960 <free@plt>
    4b84:	b5fffb75 	cbnz	x21, 4af0 <fwp_rc_prepare_chunk+0x40>
    4b88:	f900129f 	str	xzr, [x20, #32]
    4b8c:	9118c2d6 	add	x22, x22, #0x630
    4b90:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b94:	b9001e95 	str	w21, [x20, #28]
    4b98:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b9c:	8b150000 	add	x0, x0, x21
    4ba0:	f90e2ac0 	str	x0, [x22, #7248]
    4ba4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ba8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bac:	d65f03c0 	ret
    4bb0:	f9401280 	ldr	x0, [x20, #32]
    4bb4:	aa1503e2 	mov	x2, x21
    4bb8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bbc:	52800001 	mov	w1, #0x0                   	// #0
    4bc0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bc4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4bc8:	17fff72a 	b	2870 <memset@plt>
    4bcc:	d503201f 	nop

0000000000004bd0 <fwp_heap_refill>:
    4bd0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4bd4:	910003fd 	mov	x29, sp
    4bd8:	a9025bf5 	stp	x21, x22, [sp, #32]
    4bdc:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4be0:	9118c2b5 	add	x21, x21, #0x630
    4be4:	aa0003f6 	mov	x22, x0
    4be8:	d2800020 	mov	x0, #0x1                   	// #1
    4bec:	a90153f3 	stp	x19, x20, [sp, #16]
    4bf0:	a90363f7 	stp	x23, x24, [sp, #48]
    4bf4:	2a0103f7 	mov	w23, w1
    4bf8:	2a0203f8 	mov	w24, w2
    4bfc:	97fff96d 	bl	31b0 <fwp_heap_chunks>
    4c00:	aa0003f3 	mov	x19, x0
    4c04:	f949fea2 	ldr	x2, [x21, #5112]
    4c08:	8b000800 	add	x0, x0, x0, lsl #2
    4c0c:	2a1703e1 	mov	w1, w23
    4c10:	52800025 	mov	w5, #0x1                   	// #1
    4c14:	d37df000 	lsl	x0, x0, #3
    4c18:	910f0021 	add	x1, x1, #0x3c0
    4c1c:	8b000054 	add	x20, x2, x0
    4c20:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4c24:	52a00024 	mov	w4, #0x10000               	// #65536
    4c28:	38206845 	strb	w5, [x2, x0]
    4c2c:	aa1403e0 	mov	x0, x20
    4c30:	39000698 	strb	w24, [x20, #1]
    4c34:	39000a97 	strb	w23, [x20, #2]
    4c38:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4c3c:	b9000681 	str	w1, [x20, #4]
    4c40:	2a0103e5 	mov	w5, w1
    4c44:	8b0300a2 	add	x2, x5, x3
    4c48:	1ac10881 	udiv	w1, w4, w1
    4c4c:	9ac50842 	udiv	x2, x2, x5
    4c50:	b9000a81 	str	w1, [x20, #8]
    4c54:	92404021 	and	x1, x1, #0x1ffff
    4c58:	b9001a82 	str	w2, [x20, #24]
    4c5c:	97ffff95 	bl	4ab0 <fwp_rc_prepare_chunk>
    4c60:	f949daa0 	ldr	x0, [x21, #5040]
    4c64:	29408a81 	ldp	w1, w2, [x20, #4]
    4c68:	8b134000 	add	x0, x0, x19, lsl #16
    4c6c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c70:	8b214003 	add	x3, x0, w1, uxtw
    4c74:	9ba20021 	umaddl	x1, w1, w2, x0
    4c78:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c7c:	a90086c3 	stp	x3, x1, [x22, #8]
    4c80:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c84:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c88:	d65f03c0 	ret
    4c8c:	d503201f 	nop

0000000000004c90 <fwp_mem_free>:
    4c90:	b40003c0 	cbz	x0, 4d08 <fwp_mem_free+0x78>
    4c94:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c98:	910003fd 	mov	x29, sp
    4c9c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ca0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4ca4:	9118c2a1 	add	x1, x21, #0x630
    4ca8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cac:	aa0003f3 	mov	x19, x0
    4cb0:	f949d823 	ldr	x3, [x1, #5040]
    4cb4:	f949ec22 	ldr	x2, [x1, #5080]
    4cb8:	cb030000 	sub	x0, x0, x3
    4cbc:	eb02401f 	cmp	x0, x2, lsl #16
    4cc0:	540001c2 	b.cs	4cf8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4cc4:	d350fc16 	lsr	x22, x0, #16
    4cc8:	a90363f7 	stp	x23, x24, [sp, #48]
    4ccc:	f949fc22 	ldr	x2, [x1, #5112]
    4cd0:	8b160ad4 	add	x20, x22, x22, lsl #2
    4cd4:	d37df294 	lsl	x20, x20, #3
    4cd8:	ab140057 	adds	x23, x2, x20
    4cdc:	540000c0 	b.eq	4cf4 <fwp_mem_free+0x64>  // b.none
    4ce0:	38746842 	ldrb	w2, [x2, x20]
    4ce4:	7100045f 	cmp	w2, #0x1
    4ce8:	54000120 	b.eq	4d0c <fwp_mem_free+0x7c>  // b.none
    4cec:	7100085f 	cmp	w2, #0x2
    4cf0:	540005e0 	b.eq	4dac <fwp_mem_free+0x11c>  // b.none
    4cf4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4cfc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d00:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d04:	d65f03c0 	ret
    4d08:	d65f03c0 	ret
    4d0c:	f94012f8 	ldr	x24, [x23, #32]
    4d10:	b94006e1 	ldr	w1, [x23, #4]
    4d14:	f90023f9 	str	x25, [sp, #64]
    4d18:	2a0103e2 	mov	w2, w1
    4d1c:	394006f9 	ldrb	w25, [x23, #1]
    4d20:	39400af4 	ldrb	w20, [x23, #2]
    4d24:	b4000158 	cbz	x24, 4d4c <fwp_mem_free+0xbc>
    4d28:	92403e76 	and	x22, x19, #0xffff
    4d2c:	9ac20ad6 	udiv	x22, x22, x2
    4d30:	38766b01 	ldrb	w1, [x24, x22]
    4d34:	8b160300 	add	x0, x24, x22
    4d38:	7103fc3f 	cmp	w1, #0xff
    4d3c:	54000980 	b.eq	4e6c <fwp_mem_free+0x1dc>  // b.none
    4d40:	38366b1f 	strb	wzr, [x24, x22]
    4d44:	b94006e1 	ldr	w1, [x23, #4]
    4d48:	2a0103e2 	mov	w2, w1
    4d4c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4d50:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4d54:	cb390000 	sub	x0, x0, w25, uxtb
    4d58:	8b340074 	add	x20, x3, w20, uxtb
    4d5c:	9118c2b5 	add	x21, x21, #0x630
    4d60:	1e630021 	ucvtf	d1, w1
    4d64:	d37ae400 	lsl	x0, x0, #6
    4d68:	8b140c14 	add	x20, x0, x20, lsl #3
    4d6c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4d70:	f8746aa0 	ldr	x0, [x21, x20]
    4d74:	f94023f9 	ldr	x25, [sp, #64]
    4d78:	aa2003e0 	mvn	x0, x0
    4d7c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d80:	f9000260 	str	x0, [x19]
    4d84:	f8346ab3 	str	x19, [x21, x20]
    4d88:	f94a12a0 	ldr	x0, [x21, #5152]
    4d8c:	1e612800 	fadd	d0, d0, d1
    4d90:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d94:	cb020000 	sub	x0, x0, x2
    4d98:	f90a12a0 	str	x0, [x21, #5152]
    4d9c:	fd0a22a0 	str	d0, [x21, #5184]
    4da0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4da4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4da8:	d65f03c0 	ret
    4dac:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4db0:	8b000063 	add	x3, x3, x0
    4db4:	eb03027f 	cmp	x19, x3
    4db8:	54fff9e1 	b.ne	4cf4 <fwp_mem_free+0x64>  // b.any
    4dbc:	fd400ae1 	ldr	d1, [x23, #16]
    4dc0:	fd4a2020 	ldr	d0, [x1, #5184]
    4dc4:	f9400ae0 	ldr	x0, [x23, #16]
    4dc8:	7e61d821 	ucvtf	d1, d1
    4dcc:	f94a1022 	ldr	x2, [x1, #5152]
    4dd0:	f94012f3 	ldr	x19, [x23, #32]
    4dd4:	1e612800 	fadd	d0, d0, d1
    4dd8:	cb000042 	sub	x2, x2, x0
    4ddc:	f90a1022 	str	x2, [x1, #5152]
    4de0:	fd0a2020 	str	d0, [x1, #5184]
    4de4:	b40000b3 	cbz	x19, 4df8 <fwp_mem_free+0x168>
    4de8:	39400260 	ldrb	w0, [x19]
    4dec:	7103fc1f 	cmp	w0, #0xff
    4df0:	54000380 	b.eq	4e60 <fwp_mem_free+0x1d0>  // b.none
    4df4:	3900027f 	strb	wzr, [x19]
    4df8:	b9400ee2 	ldr	w2, [x23, #12]
    4dfc:	b4000142 	cbz	x2, 4e24 <fwp_mem_free+0x194>
    4e00:	9118c2a1 	add	x1, x21, #0x630
    4e04:	8b160040 	add	x0, x2, x22
    4e08:	8b000800 	add	x0, x0, x0, lsl #2
    4e0c:	f949fc21 	ldr	x1, [x1, #5112]
    4e10:	8b140034 	add	x20, x1, x20
    4e14:	8b000c20 	add	x0, x1, x0, lsl #3
    4e18:	3802869f 	strb	wzr, [x20], #40
    4e1c:	eb00029f 	cmp	x20, x0
    4e20:	54ffffc1 	b.ne	4e18 <fwp_mem_free+0x188>  // b.any
    4e24:	9118c2a0 	add	x0, x21, #0x630
    4e28:	f94a1801 	ldr	x1, [x0, #5168]
    4e2c:	f949f803 	ldr	x3, [x0, #5104]
    4e30:	8b020021 	add	x1, x1, x2
    4e34:	f90a1801 	str	x1, [x0, #5168]
    4e38:	eb16007f 	cmp	x3, x22
    4e3c:	54000049 	b.ls	4e44 <fwp_mem_free+0x1b4>  // b.plast
    4e40:	f909f816 	str	x22, [x0, #5104]
    4e44:	9118c2b5 	add	x21, x21, #0x630
    4e48:	f949f6a0 	ldr	x0, [x21, #5096]
    4e4c:	eb16001f 	cmp	x0, x22
    4e50:	54fff529 	b.ls	4cf4 <fwp_mem_free+0x64>  // b.plast
    4e54:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e58:	f909f6b6 	str	x22, [x21, #5096]
    4e5c:	17ffffa7 	b	4cf8 <fwp_mem_free+0x68>
    4e60:	aa1303e0 	mov	x0, x19
    4e64:	97fffeeb 	bl	4a10 <fwp_rc_forget_slot>
    4e68:	17ffffe3 	b	4df4 <fwp_mem_free+0x164>
    4e6c:	97fffee9 	bl	4a10 <fwp_rc_forget_slot>
    4e70:	17ffffb4 	b	4d40 <fwp_mem_free+0xb0>

0000000000004e74 <fwp_heap_alloc_big>:
    4e74:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e78:	910003fd 	mov	x29, sp
    4e7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4e80:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e84:	a90363f7 	stp	x23, x24, [sp, #48]
    4e88:	aa0003f7 	mov	x23, x0
    4e8c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e90:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e94:	eb0002ff 	cmp	x23, x0
    4e98:	54000888 	b.hi	4fa8 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e9c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4ea0:	8b0002f4 	add	x20, x23, x0
    4ea4:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbb0>
    4ea8:	9118c359 	add	x25, x26, #0x630
    4eac:	d350fe94 	lsr	x20, x20, #16
    4eb0:	2a0103f5 	mov	w21, w1
    4eb4:	aa1403e0 	mov	x0, x20
    4eb8:	97fff8be 	bl	31b0 <fwp_heap_chunks>
    4ebc:	f949ff22 	ldr	x2, [x25, #5112]
    4ec0:	8b000813 	add	x19, x0, x0, lsl #2
    4ec4:	aa0003f8 	mov	x24, x0
    4ec8:	52800043 	mov	w3, #0x2                   	// #2
    4ecc:	d37df273 	lsl	x19, x19, #3
    4ed0:	d2800021 	mov	x1, #0x1                   	// #1
    4ed4:	8b130040 	add	x0, x2, x19
    4ed8:	38336843 	strb	w3, [x2, x19]
    4edc:	39000415 	strb	w21, [x0, #1]
    4ee0:	b9000c14 	str	w20, [x0, #12]
    4ee4:	f9000817 	str	x23, [x0, #16]
    4ee8:	97fffef2 	bl	4ab0 <fwp_rc_prepare_chunk>
    4eec:	f100069f 	cmp	x20, #0x1
    4ef0:	54000269 	b.ls	4f3c <fwp_heap_alloc_big+0xc8>  // b.plast
    4ef4:	8b180294 	add	x20, x20, x24
    4ef8:	9100a273 	add	x19, x19, #0x28
    4efc:	a90573fb 	stp	x27, x28, [sp, #80]
    4f00:	5280007b 	mov	w27, #0x3                   	// #3
    4f04:	8b140a94 	add	x20, x20, x20, lsl #2
    4f08:	2a1803fc 	mov	w28, w24
    4f0c:	9adb2296 	lsl	x22, x20, x27
    4f10:	f949ff35 	ldr	x21, [x25, #5112]
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	8b1302b4 	add	x20, x21, x19
    4f1c:	aa1403e0 	mov	x0, x20
    4f20:	97fffee4 	bl	4ab0 <fwp_rc_prepare_chunk>
    4f24:	38336abb 	strb	w27, [x21, x19]
    4f28:	9100a273 	add	x19, x19, #0x28
    4f2c:	b9000e9c 	str	w28, [x20, #12]
    4f30:	eb1302df 	cmp	x22, x19
    4f34:	54fffee1 	b.ne	4f10 <fwp_heap_alloc_big+0x9c>  // b.any
    4f38:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f3c:	9118c353 	add	x19, x26, #0x630
    4f40:	aa1703e2 	mov	x2, x23
    4f44:	52800001 	mov	w1, #0x0                   	// #0
    4f48:	f949da60 	ldr	x0, [x19, #5040]
    4f4c:	8b184018 	add	x24, x0, x24, lsl #16
    4f50:	aa1803e0 	mov	x0, x24
    4f54:	97fff647 	bl	2870 <memset@plt>
    4f58:	f94a1260 	ldr	x0, [x19, #5152]
    4f5c:	ab170000 	adds	x0, x0, x23
    4f60:	54000242 	b.cs	4fa8 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4f64:	f94a1661 	ldr	x1, [x19, #5160]
    4f68:	f90a1260 	str	x0, [x19, #5152]
    4f6c:	eb01001f 	cmp	x0, x1
    4f70:	54000049 	b.ls	4f78 <fwp_heap_alloc_big+0x104>  // b.plast
    4f74:	f90a1660 	str	x0, [x19, #5160]
    4f78:	9118c35a 	add	x26, x26, #0x630
    4f7c:	9e6202e0 	scvtf	d0, x23
    4f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f84:	aa1803e0 	mov	x0, x24
    4f88:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f90:	1e602820 	fadd	d0, d1, d0
    4f94:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f98:	fd0a1f40 	str	d0, [x26, #5176]
    4f9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4fa4:	d65f03c0 	ret
    4fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    4fac:	97fff871 	bl	3170 <fwp_heap_oom>

0000000000004fb0 <fwp_heap_alloc_slow>:
    4fb0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fb4:	910003fd 	mov	x29, sp
    4fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fbc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4fc0:	9118c262 	add	x2, x19, #0x630
    4fc4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fc8:	aa0003f5 	mov	x21, x0
    4fcc:	2a0103f4 	mov	w20, w1
    4fd0:	b953a440 	ldr	w0, [x2, #5028]
    4fd4:	34000600 	cbz	w0, 5094 <fwp_heap_alloc_slow+0xe4>
    4fd8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fdc:	54000628 	b.hi	50a0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fe0:	91003ea0 	add	x0, x21, #0xf
    4fe4:	9118c262 	add	x2, x19, #0x630
    4fe8:	f9001bf7 	str	x23, [sp, #48]
    4fec:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ff0:	8b401040 	add	x0, x2, x0, lsr #4
    4ff4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ff8:	d37ae484 	lsl	x4, x4, #6
    4ffc:	397e8003 	ldrb	w3, [x0, #4000]
    5000:	910f0060 	add	x0, x3, #0x3c0
    5004:	aa0303e1 	mov	x1, x3
    5008:	8b030463 	add	x3, x3, x3, lsl #1
    500c:	8b030c83 	add	x3, x4, x3, lsl #3
    5010:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5014:	2a1703f6 	mov	w22, w23
    5018:	f8636844 	ldr	x4, [x2, x3]
    501c:	b40004e4 	cbz	x4, 50b8 <fwp_heap_alloc_slow+0x108>
    5020:	f9400080 	ldr	x0, [x4]
    5024:	aa2003e0 	mvn	x0, x0
    5028:	f8236840 	str	x0, [x2, x3]
    502c:	7100069f 	cmp	w20, #0x1
    5030:	aa0403e0 	mov	x0, x4
    5034:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5038:	52800001 	mov	w1, #0x0                   	// #0
    503c:	97fff60d 	bl	2870 <memset@plt>
    5040:	aa0003e4 	mov	x4, x0
    5044:	9118c260 	add	x0, x19, #0x630
    5048:	f94a1001 	ldr	x1, [x0, #5152]
    504c:	ab160021 	adds	x1, x1, x22
    5050:	540005c2 	b.cs	5108 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5054:	f94a1402 	ldr	x2, [x0, #5160]
    5058:	f90a1001 	str	x1, [x0, #5152]
    505c:	eb02003f 	cmp	x1, x2
    5060:	54000049 	b.ls	5068 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5064:	f90a1401 	str	x1, [x0, #5160]
    5068:	9118c273 	add	x19, x19, #0x630
    506c:	1e6302e1 	ucvtf	d1, w23
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	aa0403e0 	mov	x0, x4
    5078:	fd4a1e60 	ldr	d0, [x19, #5176]
    507c:	f9401bf7 	ldr	x23, [sp, #48]
    5080:	1e612800 	fadd	d0, d0, d1
    5084:	fd0a1e60 	str	d0, [x19, #5176]
    5088:	a94153f3 	ldp	x19, x20, [sp, #16]
    508c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5090:	d65f03c0 	ret
    5094:	97fffc1c 	bl	4104 <fwp_heap_init>
    5098:	f14012bf 	cmp	x21, #0x4, lsl #12
    509c:	54fffa29 	b.ls	4fe0 <fwp_heap_alloc_slow+0x30>  // b.plast
    50a0:	2a1403e1 	mov	w1, w20
    50a4:	aa1503e0 	mov	x0, x21
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50b4:	17ffff70 	b	4e74 <fwp_heap_alloc_big>
    50b8:	8b030042 	add	x2, x2, x3
    50bc:	f9400444 	ldr	x4, [x2, #8]
    50c0:	b4000104 	cbz	x4, 50e0 <fwp_heap_alloc_slow+0x130>
    50c4:	f9400840 	ldr	x0, [x2, #16]
    50c8:	cb040000 	sub	x0, x0, x4
    50cc:	eb16001f 	cmp	x0, x22
    50d0:	54000083 	b.cc	50e0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50d4:	8b160080 	add	x0, x4, x22
    50d8:	f9000440 	str	x0, [x2, #8]
    50dc:	17ffffd4 	b	502c <fwp_heap_alloc_slow+0x7c>
    50e0:	52800302 	mov	w2, #0x18                  	// #24
    50e4:	52807804 	mov	w4, #0x3c0                 	// #960
    50e8:	9118c260 	add	x0, x19, #0x630
    50ec:	9ba27c23 	umull	x3, w1, w2
    50f0:	2a1403e2 	mov	w2, w20
    50f4:	9b240e84 	smaddl	x4, w20, w4, x3
    50f8:	8b040000 	add	x0, x0, x4
    50fc:	97fffeb5 	bl	4bd0 <fwp_heap_refill>
    5100:	aa0003e4 	mov	x4, x0
    5104:	17ffffca 	b	502c <fwp_heap_alloc_slow+0x7c>
    5108:	97fff81a 	bl	3170 <fwp_heap_oom>
    510c:	d503201f 	nop

0000000000005110 <fwp_heap_alloc>:
    5110:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5114:	910003fd 	mov	x29, sp
    5118:	a9025bf5 	stp	x21, x22, [sp, #32]
    511c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5120:	910142c2 	add	x2, x22, #0x50
    5124:	a90363f7 	stp	x23, x24, [sp, #48]
    5128:	b9413058 	ldr	w24, [x2, #304]
    512c:	a90153f3 	stp	x19, x20, [sp, #16]
    5130:	7100031f 	cmp	w24, #0x0
    5134:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5138:	54000861 	b.ne	5244 <fwp_heap_alloc+0x134>  // b.any
    513c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    5140:	9118c2f3 	add	x19, x23, #0x630
    5144:	f140101f 	cmp	x0, #0x4, lsl #12
    5148:	b953a662 	ldr	w2, [x19, #5028]
    514c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5150:	54000740 	b.eq	5238 <fwp_heap_alloc+0x128>  // b.none
    5154:	91003c03 	add	x3, x0, #0xf
    5158:	937c7c22 	sbfiz	x2, x1, #4, #32
    515c:	cb21c042 	sub	x2, x2, w1, sxtw
    5160:	8b431263 	add	x3, x19, x3, lsr #4
    5164:	d37ae442 	lsl	x2, x2, #6
    5168:	397e8063 	ldrb	w3, [x3, #4000]
    516c:	910f0064 	add	x4, x3, #0x3c0
    5170:	8b030463 	add	x3, x3, x3, lsl #1
    5174:	8b030c43 	add	x3, x2, x3, lsl #3
    5178:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    517c:	2a1503f4 	mov	w20, w21
    5180:	f8636a64 	ldr	x4, [x19, x3]
    5184:	b40004c4 	cbz	x4, 521c <fwp_heap_alloc+0x10c>
    5188:	f9400085 	ldr	x5, [x4]
    518c:	7100043f 	cmp	w1, #0x1
    5190:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5194:	aa0403e0 	mov	x0, x4
    5198:	aa2503e5 	mvn	x5, x5
    519c:	52800001 	mov	w1, #0x0                   	// #0
    51a0:	f8236a65 	str	x5, [x19, x3]
    51a4:	97fff5b3 	bl	2870 <memset@plt>
    51a8:	aa0003e4 	mov	x4, x0
    51ac:	f94a1260 	ldr	x0, [x19, #5152]
    51b0:	ab140000 	adds	x0, x0, x20
    51b4:	540006e2 	b.cs	5290 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    51b8:	f94a1661 	ldr	x1, [x19, #5160]
    51bc:	f90a1260 	str	x0, [x19, #5152]
    51c0:	eb01001f 	cmp	x0, x1
    51c4:	54000049 	b.ls	51cc <fwp_heap_alloc+0xbc>  // b.plast
    51c8:	f90a1660 	str	x0, [x19, #5160]
    51cc:	9118c2e0 	add	x0, x23, #0x630
    51d0:	1e6302a1 	ucvtf	d1, w21
    51d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51d8:	1e612800 	fadd	d0, d0, d1
    51dc:	fd0a1c00 	str	d0, [x0, #5176]
    51e0:	34000138 	cbz	w24, 5204 <fwp_heap_alloc+0xf4>
    51e4:	9118c2e1 	add	x1, x23, #0x630
    51e8:	910142c0 	add	x0, x22, #0x50
    51ec:	fd4a1020 	ldr	d0, [x1, #5152]
    51f0:	6d548402 	ldp	d2, d1, [x0, #328]
    51f4:	7e61d800 	ucvtf	d0, d0
    51f8:	1e623800 	fsub	d0, d0, d2
    51fc:	1e612010 	fcmpe	d0, d1
    5200:	540002cc 	b.gt	5258 <fwp_heap_alloc+0x148>
    5204:	a94153f3 	ldp	x19, x20, [sp, #16]
    5208:	aa0403e0 	mov	x0, x4
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	a94363f7 	ldp	x23, x24, [sp, #48]
    5214:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5218:	d65f03c0 	ret
    521c:	8b030263 	add	x3, x19, x3
    5220:	f9400464 	ldr	x4, [x3, #8]
    5224:	b40000a4 	cbz	x4, 5238 <fwp_heap_alloc+0x128>
    5228:	f9400862 	ldr	x2, [x3, #16]
    522c:	cb040042 	sub	x2, x2, x4
    5230:	eb02029f 	cmp	x20, x2
    5234:	54000209 	b.ls	5274 <fwp_heap_alloc+0x164>  // b.plast
    5238:	97ffff5e 	bl	4fb0 <fwp_heap_alloc_slow>
    523c:	aa0003e4 	mov	x4, x0
    5240:	17ffffe8 	b	51e0 <fwp_heap_alloc+0xd0>
    5244:	a9538c44 	ldp	x4, x3, [x2, #312]
    5248:	91000484 	add	x4, x4, #0x1
    524c:	8b000063 	add	x3, x3, x0
    5250:	a9138c44 	stp	x4, x3, [x2, #312]
    5254:	17ffffba 	b	513c <fwp_heap_alloc+0x2c>
    5258:	a94153f3 	ldp	x19, x20, [sp, #16]
    525c:	fd00a800 	str	d0, [x0, #336]
    5260:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5264:	aa0403e0 	mov	x0, x4
    5268:	a94363f7 	ldp	x23, x24, [sp, #48]
    526c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5270:	d65f03c0 	ret
    5274:	7100043f 	cmp	w1, #0x1
    5278:	8b140085 	add	x5, x4, x20
    527c:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5280:	52800001 	mov	w1, #0x0                   	// #0
    5284:	aa0403e0 	mov	x0, x4
    5288:	f9000465 	str	x5, [x3, #8]
    528c:	17ffffc6 	b	51a4 <fwp_heap_alloc+0x94>
    5290:	97fff7b8 	bl	3170 <fwp_heap_oom>

0000000000005294 <fwp_data.part.0.constprop.0>:
    5294:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5298:	910003fd 	mov	x29, sp
    529c:	a9025bf5 	stp	x21, x22, [sp, #32]
    52a0:	f00000d6 	adrp	x22, 20000 <__data_start>
    52a4:	910142c2 	add	x2, x22, #0x50
    52a8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52ac:	b9413059 	ldr	w25, [x2, #304]
    52b0:	a90153f3 	stp	x19, x20, [sp, #16]
    52b4:	aa0103f4 	mov	x20, x1
    52b8:	a90363f7 	stp	x23, x24, [sp, #48]
    52bc:	2a0003f7 	mov	w23, w0
    52c0:	340000b9 	cbz	w25, 52d4 <fwp_data.part.0.constprop.0+0x40>
    52c4:	a9538041 	ldp	x1, x0, [x2, #312]
    52c8:	91000421 	add	x1, x1, #0x1
    52cc:	91006000 	add	x0, x0, #0x18
    52d0:	a9138041 	stp	x1, x0, [x2, #312]
    52d4:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    52d8:	9118c2a3 	add	x3, x21, #0x630
    52dc:	b953a460 	ldr	w0, [x3, #5028]
    52e0:	34000840 	cbz	w0, 53e8 <fwp_data.part.0.constprop.0+0x154>
    52e4:	397e8862 	ldrb	w2, [x3, #4002]
    52e8:	910f0040 	add	x0, x2, #0x3c0
    52ec:	8b020442 	add	x2, x2, x2, lsl #1
    52f0:	d37df042 	lsl	x2, x2, #3
    52f4:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    52f8:	2a1a03f8 	mov	w24, w26
    52fc:	f8626873 	ldr	x19, [x3, x2]
    5300:	b4000613 	cbz	x19, 53c0 <fwp_data.part.0.constprop.0+0x12c>
    5304:	f9400260 	ldr	x0, [x19]
    5308:	aa2003e0 	mvn	x0, x0
    530c:	f8226860 	str	x0, [x3, x2]
    5310:	f100631f 	cmp	x24, #0x18
    5314:	540000e9 	b.ls	5330 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5318:	d1006702 	sub	x2, x24, #0x19
    531c:	91006260 	add	x0, x19, #0x18
    5320:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5324:	52800001 	mov	w1, #0x0                   	// #0
    5328:	91002042 	add	x2, x2, #0x8
    532c:	97fff551 	bl	2870 <memset@plt>
    5330:	9118c2a0 	add	x0, x21, #0x630
    5334:	f94a1001 	ldr	x1, [x0, #5152]
    5338:	ab180021 	adds	x1, x1, x24
    533c:	54000642 	b.cs	5404 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    5340:	f94a1402 	ldr	x2, [x0, #5160]
    5344:	f90a1001 	str	x1, [x0, #5152]
    5348:	eb02003f 	cmp	x1, x2
    534c:	54000049 	b.ls	5354 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5350:	f90a1401 	str	x1, [x0, #5160]
    5354:	9118c2a0 	add	x0, x21, #0x630
    5358:	1e630341 	ucvtf	d1, w26
    535c:	fd4a1c00 	ldr	d0, [x0, #5176]
    5360:	1e612800 	fadd	d0, d0, d1
    5364:	fd0a1c00 	str	d0, [x0, #5176]
    5368:	34000139 	cbz	w25, 538c <fwp_data.part.0.constprop.0+0xf8>
    536c:	9118c2b5 	add	x21, x21, #0x630
    5370:	910142d6 	add	x22, x22, #0x50
    5374:	fd4a12a0 	ldr	d0, [x21, #5152]
    5378:	6d5486c2 	ldp	d2, d1, [x22, #328]
    537c:	7e61d800 	ucvtf	d0, d0
    5380:	1e623800 	fsub	d0, d0, d2
    5384:	1e612010 	fcmpe	d0, d1
    5388:	540003ac 	b.gt	53fc <fwp_data.part.0.constprop.0+0x168>
    538c:	52800040 	mov	w0, #0x2                   	// #2
    5390:	29000277 	stp	w23, w0, [x19]
    5394:	aa1303e0 	mov	x0, x19
    5398:	f9400281 	ldr	x1, [x20]
    539c:	f9000661 	str	x1, [x19, #8]
    53a0:	f9400681 	ldr	x1, [x20, #8]
    53a4:	f9000a61 	str	x1, [x19, #16]
    53a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    53ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    53b4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53b8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53bc:	d65f03c0 	ret
    53c0:	8b020063 	add	x3, x3, x2
    53c4:	f9400473 	ldr	x19, [x3, #8]
    53c8:	b4000113 	cbz	x19, 53e8 <fwp_data.part.0.constprop.0+0x154>
    53cc:	f9400860 	ldr	x0, [x3, #16]
    53d0:	cb130000 	sub	x0, x0, x19
    53d4:	eb00031f 	cmp	x24, x0
    53d8:	54000088 	b.hi	53e8 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    53dc:	8b180260 	add	x0, x19, x24
    53e0:	f9000460 	str	x0, [x3, #8]
    53e4:	17ffffcb 	b	5310 <fwp_data.part.0.constprop.0+0x7c>
    53e8:	52800001 	mov	w1, #0x0                   	// #0
    53ec:	d2800300 	mov	x0, #0x18                  	// #24
    53f0:	97ffff48 	bl	5110 <fwp_heap_alloc>
    53f4:	aa0003f3 	mov	x19, x0
    53f8:	17ffffdc 	b	5368 <fwp_data.part.0.constprop.0+0xd4>
    53fc:	fd00aac0 	str	d0, [x22, #336]
    5400:	17ffffe3 	b	538c <fwp_data.part.0.constprop.0+0xf8>
    5404:	97fff75b 	bl	3170 <fwp_heap_oom>
    5408:	d503201f 	nop
    540c:	d503201f 	nop

0000000000005410 <fwp_p_ad_push>:
    5410:	f100001f 	cmp	x0, #0x0
    5414:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    5418:	540011ab 	b.lt	564c <fwp_p_ad_push+0x23c>  // b.tstop
    541c:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5420:	910003fd 	mov	x29, sp
    5424:	a90153f3 	stp	x19, x20, [sp, #16]
    5428:	a9025bf5 	stp	x21, x22, [sp, #32]
    542c:	aa0403f6 	mov	x22, x4
    5430:	aa0003f5 	mov	x21, x0
    5434:	a90363f7 	stp	x23, x24, [sp, #48]
    5438:	aa0203f8 	mov	x24, x2
    543c:	6d0627e8 	stp	d8, d9, [sp, #96]
    5440:	9e670029 	fmov	d9, x1
    5444:	9e670068 	fmov	d8, x3
    5448:	aa020001 	orr	x1, x0, x2
    544c:	b6f80de1 	tbz	x1, #63, 5608 <fwp_p_ad_push+0x1f8>
    5450:	9360fc14 	asr	x20, x0, #32
    5454:	b6f800c0 	tbz	x0, #63, 546c <fwp_p_ad_push+0x5c>
    5458:	1e604109 	fmov	d9, d8
    545c:	2f00e408 	movi	d8, #0x0
    5460:	9360fc54 	asr	x20, x2, #32
    5464:	aa0203f5 	mov	x21, x2
    5468:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    546c:	b4001156 	cbz	x22, 5694 <fwp_p_ad_push+0x284>
    5470:	f94002c0 	ldr	x0, [x22]
    5474:	eb14001f 	cmp	x0, x20
    5478:	54000e60 	b.eq	5644 <fwp_p_ad_push+0x234>  // b.none
    547c:	aa1403e0 	mov	x0, x20
    5480:	97fff9ac 	bl	3b30 <fwp_tape_of>
    5484:	aa0003f3 	mov	x19, x0
    5488:	f9403000 	ldr	x0, [x0, #96]
    548c:	b50010e0 	cbnz	x0, 56a8 <fwp_p_ad_push+0x298>
    5490:	a9004ed4 	stp	x20, x19, [x22]
    5494:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5498:	f9400a77 	ldr	x23, [x19, #16]
    549c:	a9046bf9 	stp	x25, x26, [sp, #64]
    54a0:	eb0002ff 	cmp	x23, x0
    54a4:	540013ac 	b.gt	5718 <fwp_p_ad_push+0x308>
    54a8:	eb3542ff 	cmp	x23, w21, uxtw
    54ac:	540012ed 	b.le	5708 <fwp_p_ad_push+0x2f8>
    54b0:	b7f80078 	tbnz	x24, #63, 54bc <fwp_p_ad_push+0xac>
    54b4:	eb3842ff 	cmp	x23, w24, uxtw
    54b8:	5400128d 	b.le	5708 <fwp_p_ad_push+0x2f8>
    54bc:	f9400676 	ldr	x22, [x19, #8]
    54c0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54c4:	cb1602f6 	sub	x22, x23, x22
    54c8:	910006c1 	add	x1, x22, #0x1
    54cc:	aa1603f9 	mov	x25, x22
    54d0:	eb00003f 	cmp	x1, x0
    54d4:	54001228 	b.hi	5718 <fwp_p_ad_push+0x308>  // b.pmore
    54d8:	a9418274 	ldp	x20, x0, [x19, #24]
    54dc:	eb14003f 	cmp	x1, x20
    54e0:	54000a8d 	b.le	5630 <fwp_p_ad_push+0x220>
    54e4:	f100029f 	cmp	x20, #0x0
    54e8:	d2800803 	mov	x3, #0x40                  	// #64
    54ec:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    54f0:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    54f4:	a90573fb 	stp	x27, x28, [sp, #80]
    54f8:	eb14003f 	cmp	x1, x20
    54fc:	5400008d 	b.le	550c <fwp_p_ad_push+0xfc>
    5500:	eb02029f 	cmp	x20, x2
    5504:	5400092d 	b.le	5628 <fwp_p_ad_push+0x218>
    5508:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    550c:	d37df29a 	lsl	x26, x20, #3
    5510:	52800022 	mov	w2, #0x1                   	// #1
    5514:	f940327b 	ldr	x27, [x19, #96]
    5518:	aa1a03e1 	mov	x1, x26
    551c:	97fffbce 	bl	4454 <ad_raw_realloc>
    5520:	b4001040 	cbz	x0, 5728 <fwp_p_ad_push+0x318>
    5524:	f9400e61 	ldr	x1, [x19, #24]
    5528:	8b010801 	add	x1, x0, x1, lsl #2
    552c:	a9020660 	stp	x0, x1, [x19, #32]
    5530:	b400093b 	cbz	x27, 5654 <fwp_p_ad_push+0x244>
    5534:	f9403363 	ldr	x3, [x27, #96]
    5538:	f9003be3 	str	x3, [sp, #112]
    553c:	eb03029f 	cmp	x20, x3
    5540:	5400034d 	b.le	55a8 <fwp_p_ad_push+0x198>
    5544:	f940237c 	ldr	x28, [x27, #64]
    5548:	d37cee82 	lsl	x2, x20, #4
    554c:	aa0203e0 	mov	x0, x2
    5550:	52800041 	mov	w1, #0x2                   	// #2
    5554:	f9003fe2 	str	x2, [sp, #120]
    5558:	97fffeee 	bl	5110 <fwp_heap_alloc>
    555c:	aa0003fa 	mov	x26, x0
    5560:	b400013c 	cbz	x28, 5584 <fwp_p_ad_push+0x174>
    5564:	a9470be3 	ldp	x3, x2, [sp, #112]
    5568:	aa1c03e1 	mov	x1, x28
    556c:	d37cec63 	lsl	x3, x3, #4
    5570:	eb02007f 	cmp	x3, x2
    5574:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    5578:	97fff45e 	bl	26f0 <memcpy@plt>
    557c:	aa1c03e0 	mov	x0, x28
    5580:	97fffdc4 	bl	4c90 <fwp_mem_free>
    5584:	f9403360 	ldr	x0, [x27, #96]
    5588:	52800001 	mov	w1, #0x0                   	// #0
    558c:	cb000282 	sub	x2, x20, x0
    5590:	8b001340 	add	x0, x26, x0, lsl #4
    5594:	d37cec42 	lsl	x2, x2, #4
    5598:	97fff4b6 	bl	2870 <memset@plt>
    559c:	f9401260 	ldr	x0, [x19, #32]
    55a0:	f900237a 	str	x26, [x27, #64]
    55a4:	f9003374 	str	x20, [x27, #96]
    55a8:	b50008b6 	cbnz	x22, 56bc <fwp_p_ad_push+0x2ac>
    55ac:	a9431263 	ldp	x3, x4, [x19, #48]
    55b0:	d37ef69a 	lsl	x26, x20, #2
    55b4:	a94573fb 	ldp	x27, x28, [sp, #80]
    55b8:	8b1a0002 	add	x2, x0, x26
    55bc:	f9000e74 	str	x20, [x19, #24]
    55c0:	f9001662 	str	x2, [x19, #40]
    55c4:	b8366815 	str	w21, [x0, x22]
    55c8:	f100031f 	cmp	x24, #0x0
    55cc:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    55d0:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55d4:	fc396869 	str	d9, [x3, x25]
    55d8:	aa1702a0 	orr	x0, x21, x23
    55dc:	b8366841 	str	w1, [x2, x22]
    55e0:	910006e1 	add	x1, x23, #0x1
    55e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55e8:	fc396888 	str	d8, [x4, x25]
    55ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    55f0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    55f4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55f8:	f9000a61 	str	x1, [x19, #16]
    55fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5600:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5604:	d65f03c0 	ret
    5608:	9360fc54 	asr	x20, x2, #32
    560c:	eb80829f 	cmp	x20, x0, asr #32
    5610:	54fff2e0 	b.eq	546c <fwp_p_ad_push+0x5c>  // b.none
    5614:	90000040 	adrp	x0, d000 <__divti3+0x2b0>
    5618:	9125e000 	add	x0, x0, #0x978
    561c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5620:	a90573fb 	stp	x27, x28, [sp, #80]
    5624:	97fff877 	bl	3800 <fwp_trap>
    5628:	d37ffa94 	lsl	x20, x20, #1
    562c:	17ffffb3 	b	54f8 <fwp_p_ad_push+0xe8>
    5630:	a9428e62 	ldp	x2, x3, [x19, #40]
    5634:	d37ef6d6 	lsl	x22, x22, #2
    5638:	f9401e64 	ldr	x4, [x19, #56]
    563c:	d37df339 	lsl	x25, x25, #3
    5640:	17ffffe1 	b	55c4 <fwp_p_ad_push+0x1b4>
    5644:	f94006d3 	ldr	x19, [x22, #8]
    5648:	17ffff93 	b	5494 <fwp_p_ad_push+0x84>
    564c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5650:	d65f03c0 	ret
    5654:	f9401a60 	ldr	x0, [x19, #48]
    5658:	d37cee81 	lsl	x1, x20, #4
    565c:	52800042 	mov	w2, #0x2                   	// #2
    5660:	97fffb7d 	bl	4454 <ad_raw_realloc>
    5664:	aa0003e3 	mov	x3, x0
    5668:	b4000600 	cbz	x0, 5728 <fwp_p_ad_push+0x318>
    566c:	f9400e61 	ldr	x1, [x19, #24]
    5670:	8b1a0004 	add	x4, x0, x26
    5674:	8b010c01 	add	x1, x0, x1, lsl #3
    5678:	a9030660 	stp	x0, x1, [x19, #48]
    567c:	b5000356 	cbnz	x22, 56e4 <fwp_p_ad_push+0x2d4>
    5680:	f9401260 	ldr	x0, [x19, #32]
    5684:	d37ef69a 	lsl	x26, x20, #2
    5688:	d2800016 	mov	x22, #0x0                   	// #0
    568c:	f9001e64 	str	x4, [x19, #56]
    5690:	17ffffc9 	b	55b4 <fwp_p_ad_push+0x1a4>
    5694:	aa1403e0 	mov	x0, x20
    5698:	97fff926 	bl	3b30 <fwp_tape_of>
    569c:	aa0003f3 	mov	x19, x0
    56a0:	f9403000 	ldr	x0, [x0, #96]
    56a4:	b4ffef80 	cbz	x0, 5494 <fwp_p_ad_push+0x84>
    56a8:	90000040 	adrp	x0, d000 <__divti3+0x2b0>
    56ac:	91270000 	add	x0, x0, #0x9c0
    56b0:	a9046bf9 	stp	x25, x26, [sp, #64]
    56b4:	a90573fb 	stp	x27, x28, [sp, #80]
    56b8:	97fff852 	bl	3800 <fwp_trap>
    56bc:	d37df2d9 	lsl	x25, x22, #3
    56c0:	f9401661 	ldr	x1, [x19, #40]
    56c4:	d37ef6d6 	lsl	x22, x22, #2
    56c8:	d37ef69a 	lsl	x26, x20, #2
    56cc:	aa1603e2 	mov	x2, x22
    56d0:	8b1a0000 	add	x0, x0, x26
    56d4:	97fff40f 	bl	2710 <memmove@plt>
    56d8:	f9401260 	ldr	x0, [x19, #32]
    56dc:	a9431263 	ldp	x3, x4, [x19, #48]
    56e0:	17ffffb5 	b	55b4 <fwp_p_ad_push+0x1a4>
    56e4:	d37df2d9 	lsl	x25, x22, #3
    56e8:	aa0403e0 	mov	x0, x4
    56ec:	aa1903e2 	mov	x2, x25
    56f0:	97fff408 	bl	2710 <memmove@plt>
    56f4:	f9401a61 	ldr	x1, [x19, #48]
    56f8:	f9401260 	ldr	x0, [x19, #32]
    56fc:	8b1a0021 	add	x1, x1, x26
    5700:	f9001e61 	str	x1, [x19, #56]
    5704:	17ffffef 	b	56c0 <fwp_p_ad_push+0x2b0>
    5708:	90000040 	adrp	x0, d000 <__divti3+0x2b0>
    570c:	91284000 	add	x0, x0, #0xa10
    5710:	a90573fb 	stp	x27, x28, [sp, #80]
    5714:	97fff83b 	bl	3800 <fwp_trap>
    5718:	90000040 	adrp	x0, d000 <__divti3+0x2b0>
    571c:	9127c000 	add	x0, x0, #0x9f0
    5720:	a90573fb 	stp	x27, x28, [sp, #80]
    5724:	97fff837 	bl	3800 <fwp_trap>
    5728:	aa1303e0 	mov	x0, x19
    572c:	97fff63a 	bl	3014 <fwp_tape_unlink_scope>
    5730:	f9401260 	ldr	x0, [x19, #32]
    5734:	b4000040 	cbz	x0, 573c <fwp_p_ad_push+0x32c>
    5738:	97fffb12 	bl	4380 <ad_raw_free.part.0>
    573c:	f9401a60 	ldr	x0, [x19, #48]
    5740:	b4000040 	cbz	x0, 5748 <fwp_p_ad_push+0x338>
    5744:	97fffb0f 	bl	4380 <ad_raw_free.part.0>
    5748:	f9402260 	ldr	x0, [x19, #64]
    574c:	b4000040 	cbz	x0, 5754 <fwp_p_ad_push+0x344>
    5750:	97fffb0c 	bl	4380 <ad_raw_free.part.0>
    5754:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    5758:	f947e821 	ldr	x1, [x1, #4048]
    575c:	f9000e7f 	str	xzr, [x19, #24]
    5760:	4f000400 	movi	v0.4s, #0x0
    5764:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    5768:	d2800262 	mov	x2, #0x13                  	// #19
    576c:	f9400023 	ldr	x3, [x1]
    5770:	b900067f 	str	wzr, [x19, #4]
    5774:	d2800021 	mov	x1, #0x1                   	// #1
    5778:	90000040 	adrp	x0, d000 <__divti3+0x2b0>
    577c:	9111e000 	add	x0, x0, #0x478
    5780:	3c808260 	stur	q0, [x19, #8]
    5784:	ad010260 	stp	q0, q0, [x19, #32]
    5788:	97fff486 	bl	29a0 <fwrite@plt>
    578c:	d2800000 	mov	x0, #0x0                   	// #0
    5790:	97fff490 	bl	29d0 <fflush@plt>
    5794:	52800cc0 	mov	w0, #0x66                  	// #102
    5798:	97fff49e 	bl	2a10 <_Exit@plt>
    579c:	d503201f 	nop

00000000000057a0 <w120>:
    57a0:	d10203ff 	sub	sp, sp, #0x80
    57a4:	9e660003 	fmov	x3, d0
    57a8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    57ac:	f947f442 	ldr	x2, [x2, #4072]
    57b0:	a9027bfd 	stp	x29, x30, [sp, #32]
    57b4:	910083fd 	add	x29, sp, #0x20
    57b8:	6d0627e8 	stp	d8, d9, [sp, #96]
    57bc:	1e604009 	fmov	d9, d0
    57c0:	1e604028 	fmov	d8, d1
    57c4:	fd003bea 	str	d10, [sp, #112]
    57c8:	1e60080a 	fmul	d10, d0, d0
    57cc:	a90353f3 	stp	x19, x20, [sp, #48]
    57d0:	910023f3 	add	x19, sp, #0x8
    57d4:	aa0003f4 	mov	x20, x0
    57d8:	a9045bf5 	stp	x21, x22, [sp, #64]
    57dc:	aa0103f6 	mov	x22, x1
    57e0:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    57e4:	a90563f7 	stp	x23, x24, [sp, #80]
    57e8:	aa0303e1 	mov	x1, x3
    57ec:	f9400044 	ldr	x4, [x2]
    57f0:	f9000fe4 	str	x4, [sp, #24]
    57f4:	d2800004 	mov	x4, #0x0                   	// #0
    57f8:	aa0003e2 	mov	x2, x0
    57fc:	aa1303e4 	mov	x4, x19
    5800:	a900fff5 	stp	x21, xzr, [sp, #8]
    5804:	97ffff03 	bl	5410 <fwp_p_ad_push>
    5808:	1e6a3908 	fsub	d8, d8, d10
    580c:	aa1603e2 	mov	x2, x22
    5810:	aa1303e4 	mov	x4, x19
    5814:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5818:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    581c:	9e660118 	fmov	x24, d8
    5820:	97fffefc 	bl	5410 <fwp_p_ad_push>
    5824:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5828:	aa0003f6 	mov	x22, x0
    582c:	aa1303e4 	mov	x4, x19
    5830:	aa1403e0 	mov	x0, x20
    5834:	1e69394a 	fsub	d10, d10, d9
    5838:	aa1503e2 	mov	x2, x21
    583c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5840:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5844:	9e660157 	fmov	x23, d10
    5848:	97fffef2 	bl	5410 <fwp_p_ad_push>
    584c:	1e680908 	fmul	d8, d8, d8
    5850:	aa0003f4 	mov	x20, x0
    5854:	aa1303e4 	mov	x4, x19
    5858:	aa1803e3 	mov	x3, x24
    585c:	aa1803e1 	mov	x1, x24
    5860:	aa1603e2 	mov	x2, x22
    5864:	aa1603e0 	mov	x0, x22
    5868:	97fffeea 	bl	5410 <fwp_p_ad_push>
    586c:	aa0003e2 	mov	x2, x0
    5870:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5874:	9e670029 	fmov	d9, x1
    5878:	9e660101 	fmov	x1, d8
    587c:	aa1303e4 	mov	x4, x19
    5880:	1e690909 	fmul	d9, d8, d9
    5884:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    5888:	aa1503e0 	mov	x0, x21
    588c:	97fffee1 	bl	5410 <fwp_p_ad_push>
    5890:	1e6a094a 	fmul	d10, d10, d10
    5894:	aa1303e4 	mov	x4, x19
    5898:	aa1703e3 	mov	x3, x23
    589c:	aa0003f3 	mov	x19, x0
    58a0:	aa1703e1 	mov	x1, x23
    58a4:	aa1403e2 	mov	x2, x20
    58a8:	aa1403e0 	mov	x0, x20
    58ac:	97fffed9 	bl	5410 <fwp_p_ad_push>
    58b0:	1e6a2929 	fadd	d9, d9, d10
    58b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    58b8:	d2800004 	mov	x4, #0x0                   	// #0
    58bc:	aa0303e1 	mov	x1, x3
    58c0:	aa1303e2 	mov	x2, x19
    58c4:	97fffed3 	bl	5410 <fwp_p_ad_push>
    58c8:	aa0003e1 	mov	x1, x0
    58cc:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    58d0:	f947f463 	ldr	x3, [x3, #4072]
    58d4:	f9400fe0 	ldr	x0, [sp, #24]
    58d8:	f9400064 	ldr	x4, [x3]
    58dc:	eb040000 	subs	x0, x0, x4
    58e0:	d2800004 	mov	x4, #0x0                   	// #0
    58e4:	54000161 	b.ne	5910 <w120+0x170>  // b.any
    58e8:	9e660122 	fmov	x2, d9
    58ec:	fd403bea 	ldr	d10, [sp, #112]
    58f0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    58f4:	a94353f3 	ldp	x19, x20, [sp, #48]
    58f8:	aa0203e0 	mov	x0, x2
    58fc:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5900:	a94563f7 	ldp	x23, x24, [sp, #80]
    5904:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5908:	910203ff 	add	sp, sp, #0x80
    590c:	d65f03c0 	ret
    5910:	97fff3e4 	bl	28a0 <__stack_chk_fail@plt>

0000000000005914 <w176.constprop.0>:
    5914:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5918:	910003fd 	mov	x29, sp
    591c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5920:	fd001be8 	str	d8, [sp, #48]
    5924:	f9400015 	ldr	x21, [x0]
    5928:	b4000355 	cbz	x21, 5990 <w176.constprop.0+0x7c>
    592c:	2f00e408 	movi	d8, #0x0
    5930:	91002016 	add	x22, x0, #0x8
    5934:	a90153f3 	stp	x19, x20, [sp, #16]
    5938:	91004014 	add	x20, x0, #0x10
    593c:	d2800013 	mov	x19, #0x0                   	// #0
    5940:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5944:	d503201f 	nop
    5948:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    594c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5950:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    5954:	aa0303e1 	mov	x1, x3
    5958:	1e602908 	fadd	d8, d8, d0
    595c:	d2800004 	mov	x4, #0x0                   	// #0
    5960:	91000a73 	add	x19, x19, #0x2
    5964:	97fffeab 	bl	5410 <fwp_p_ad_push>
    5968:	eb1302bf 	cmp	x21, x19
    596c:	54fffee8 	b.hi	5948 <w176.constprop.0+0x34>  // b.pmore
    5970:	9e660102 	fmov	x2, d8
    5974:	fd401be8 	ldr	d8, [sp, #48]
    5978:	a94153f3 	ldp	x19, x20, [sp, #16]
    597c:	aa0003e1 	mov	x1, x0
    5980:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5984:	aa0203e0 	mov	x0, x2
    5988:	a8c47bfd 	ldp	x29, x30, [sp], #64
    598c:	d65f03c0 	ret
    5990:	2f00e408 	movi	d8, #0x0
    5994:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5998:	a9425bf5 	ldp	x21, x22, [sp, #32]
    599c:	aa0003e1 	mov	x1, x0
    59a0:	9e660102 	fmov	x2, d8
    59a4:	fd401be8 	ldr	d8, [sp, #48]
    59a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    59ac:	aa0203e0 	mov	x0, x2
    59b0:	d65f03c0 	ret

00000000000059b4 <fwp_rc_share>:
    59b4:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    59b8:	9118c042 	add	x2, x2, #0x630
    59bc:	f949d843 	ldr	x3, [x2, #5040]
    59c0:	f949ec41 	ldr	x1, [x2, #5080]
    59c4:	cb030000 	sub	x0, x0, x3
    59c8:	eb01401f 	cmp	x0, x1, lsl #16
    59cc:	540002c2 	b.cs	5a24 <fwp_rc_share+0x70>  // b.hs, b.nlast
    59d0:	d350fc01 	lsr	x1, x0, #16
    59d4:	f949fc44 	ldr	x4, [x2, #5112]
    59d8:	8b010821 	add	x1, x1, x1, lsl #2
    59dc:	d37df021 	lsl	x1, x1, #3
    59e0:	8b010083 	add	x3, x4, x1
    59e4:	f9401062 	ldr	x2, [x3, #32]
    59e8:	b40001e2 	cbz	x2, 5a24 <fwp_rc_share+0x70>
    59ec:	38616881 	ldrb	w1, [x4, x1]
    59f0:	7100083f 	cmp	w1, #0x2
    59f4:	540001a0 	b.eq	5a28 <fwp_rc_share+0x74>  // b.none
    59f8:	7100043f 	cmp	w1, #0x1
    59fc:	54000141 	b.ne	5a24 <fwp_rc_share+0x70>  // b.any
    5a00:	29430464 	ldp	w4, w1, [x3, #24]
    5a04:	92403c00 	and	x0, x0, #0xffff
    5a08:	9b047c00 	mul	x0, x0, x4
    5a0c:	d360fc00 	lsr	x0, x0, #32
    5a10:	eb01001f 	cmp	x0, x1
    5a14:	54000082 	b.cs	5a24 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5a18:	8b000042 	add	x2, x2, x0
    5a1c:	39400040 	ldrb	w0, [x2]
    5a20:	350000a0 	cbnz	w0, 5a34 <fwp_rc_share+0x80>
    5a24:	d65f03c0 	ret
    5a28:	72003c1f 	tst	w0, #0xffff
    5a2c:	54ffff80 	b.eq	5a1c <fwp_rc_share+0x68>  // b.none
    5a30:	d65f03c0 	ret
    5a34:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5a38:	90000040 	adrp	x0, d000 <__divti3+0x2b0>
    5a3c:	9128c000 	add	x0, x0, #0xa30
    5a40:	910003fd 	mov	x29, sp
    5a44:	97fff76f 	bl	3800 <fwp_trap>
    5a48:	d503201f 	nop
    5a4c:	d503201f 	nop

0000000000005a50 <fwp_rc_fresh>:
    5a50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5a54:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5a58:	9118c063 	add	x3, x3, #0x630
    5a5c:	910003fd 	mov	x29, sp
    5a60:	a90153f3 	stp	x19, x20, [sp, #16]
    5a64:	aa0003f3 	mov	x19, x0
    5a68:	f949d861 	ldr	x1, [x3, #5040]
    5a6c:	f949ec60 	ldr	x0, [x3, #5080]
    5a70:	cb010261 	sub	x1, x19, x1
    5a74:	eb00403f 	cmp	x1, x0, lsl #16
    5a78:	54000322 	b.cs	5adc <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5a7c:	d350fc22 	lsr	x2, x1, #16
    5a80:	f949fc63 	ldr	x3, [x3, #5112]
    5a84:	8b020842 	add	x2, x2, x2, lsl #2
    5a88:	d37df042 	lsl	x2, x2, #3
    5a8c:	8b020060 	add	x0, x3, x2
    5a90:	f9401014 	ldr	x20, [x0, #32]
    5a94:	b4000254 	cbz	x20, 5adc <fwp_rc_fresh+0x8c>
    5a98:	38626862 	ldrb	w2, [x3, x2]
    5a9c:	7100085f 	cmp	w2, #0x2
    5aa0:	54000260 	b.eq	5aec <fwp_rc_fresh+0x9c>  // b.none
    5aa4:	7100045f 	cmp	w2, #0x1
    5aa8:	540001a1 	b.ne	5adc <fwp_rc_fresh+0x8c>  // b.any
    5aac:	29430002 	ldp	w2, w0, [x0, #24]
    5ab0:	92403c21 	and	x1, x1, #0xffff
    5ab4:	9b027c21 	mul	x1, x1, x2
    5ab8:	d360fc21 	lsr	x1, x1, #32
    5abc:	eb00003f 	cmp	x1, x0
    5ac0:	540000e2 	b.cs	5adc <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5ac4:	8b010294 	add	x20, x20, x1
    5ac8:	39400280 	ldrb	w0, [x20]
    5acc:	7103fc1f 	cmp	w0, #0xff
    5ad0:	540001a0 	b.eq	5b04 <fwp_rc_fresh+0xb4>  // b.none
    5ad4:	52800020 	mov	w0, #0x1                   	// #1
    5ad8:	39000280 	strb	w0, [x20]
    5adc:	aa1303e0 	mov	x0, x19
    5ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ae4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ae8:	d65f03c0 	ret
    5aec:	72003c3f 	tst	w1, #0xffff
    5af0:	54fffec0 	b.eq	5ac8 <fwp_rc_fresh+0x78>  // b.none
    5af4:	aa1303e0 	mov	x0, x19
    5af8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5afc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5b00:	d65f03c0 	ret
    5b04:	aa1403e0 	mov	x0, x20
    5b08:	97fffbc2 	bl	4a10 <fwp_rc_forget_slot>
    5b0c:	17fffff2 	b	5ad4 <fwp_rc_fresh+0x84>

0000000000005b10 <fwp_rc_free_arr>:
    5b10:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5b14:	9118c063 	add	x3, x3, #0x630
    5b18:	f949d861 	ldr	x1, [x3, #5040]
    5b1c:	f949ec62 	ldr	x2, [x3, #5080]
    5b20:	cb010001 	sub	x1, x0, x1
    5b24:	eb02403f 	cmp	x1, x2, lsl #16
    5b28:	54000342 	b.cs	5b90 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5b2c:	d350fc22 	lsr	x2, x1, #16
    5b30:	f949fc65 	ldr	x5, [x3, #5112]
    5b34:	8b020842 	add	x2, x2, x2, lsl #2
    5b38:	d37df042 	lsl	x2, x2, #3
    5b3c:	8b0200a4 	add	x4, x5, x2
    5b40:	f9401083 	ldr	x3, [x4, #32]
    5b44:	b4000263 	cbz	x3, 5b90 <fwp_rc_free_arr+0x80>
    5b48:	386268a2 	ldrb	w2, [x5, x2]
    5b4c:	7100085f 	cmp	w2, #0x2
    5b50:	540001c0 	b.eq	5b88 <fwp_rc_free_arr+0x78>  // b.none
    5b54:	7100045f 	cmp	w2, #0x1
    5b58:	540001c1 	b.ne	5b90 <fwp_rc_free_arr+0x80>  // b.any
    5b5c:	29430885 	ldp	w5, w2, [x4, #24]
    5b60:	92403c21 	and	x1, x1, #0xffff
    5b64:	9b057c21 	mul	x1, x1, x5
    5b68:	d360fc21 	lsr	x1, x1, #32
    5b6c:	eb02003f 	cmp	x1, x2
    5b70:	54000102 	b.cs	5b90 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5b74:	8b010063 	add	x3, x3, x1
    5b78:	39400061 	ldrb	w1, [x3]
    5b7c:	7100043f 	cmp	w1, #0x1
    5b80:	54000081 	b.ne	5b90 <fwp_rc_free_arr+0x80>  // b.any
    5b84:	17fffc43 	b	4c90 <fwp_mem_free>
    5b88:	72003c3f 	tst	w1, #0xffff
    5b8c:	54ffff60 	b.eq	5b78 <fwp_rc_free_arr+0x68>  // b.none
    5b90:	d65f03c0 	ret

0000000000005b94 <fwp_rc_dup>:
    5b94:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5b98:	9118c042 	add	x2, x2, #0x630
    5b9c:	f949d841 	ldr	x1, [x2, #5040]
    5ba0:	f949ec43 	ldr	x3, [x2, #5080]
    5ba4:	cb010001 	sub	x1, x0, x1
    5ba8:	eb03403f 	cmp	x1, x3, lsl #16
    5bac:	540003c2 	b.cs	5c24 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5bb0:	d350fc20 	lsr	x0, x1, #16
    5bb4:	f949fc44 	ldr	x4, [x2, #5112]
    5bb8:	8b000800 	add	x0, x0, x0, lsl #2
    5bbc:	d37df002 	lsl	x2, x0, #3
    5bc0:	8b020083 	add	x3, x4, x2
    5bc4:	f9401060 	ldr	x0, [x3, #32]
    5bc8:	b40002e0 	cbz	x0, 5c24 <fwp_rc_dup+0x90>
    5bcc:	38626882 	ldrb	w2, [x4, x2]
    5bd0:	7100085f 	cmp	w2, #0x2
    5bd4:	540002a0 	b.eq	5c28 <fwp_rc_dup+0x94>  // b.none
    5bd8:	7100045f 	cmp	w2, #0x1
    5bdc:	54000241 	b.ne	5c24 <fwp_rc_dup+0x90>  // b.any
    5be0:	29430864 	ldp	w4, w2, [x3, #24]
    5be4:	92403c21 	and	x1, x1, #0xffff
    5be8:	9b047c21 	mul	x1, x1, x4
    5bec:	d360fc21 	lsr	x1, x1, #32
    5bf0:	eb02003f 	cmp	x1, x2
    5bf4:	54000182 	b.cs	5c24 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5bf8:	8b010000 	add	x0, x0, x1
    5bfc:	39400001 	ldrb	w1, [x0]
    5c00:	34000121 	cbz	w1, 5c24 <fwp_rc_dup+0x90>
    5c04:	f00000c2 	adrp	x2, 20000 <__data_start>
    5c08:	91014042 	add	x2, x2, #0x50
    5c0c:	b9413043 	ldr	w3, [x2, #304]
    5c10:	35000123 	cbnz	w3, 5c34 <fwp_rc_dup+0xa0>
    5c14:	7103f43f 	cmp	w1, #0xfd
    5c18:	54000168 	b.hi	5c44 <fwp_rc_dup+0xb0>  // b.pmore
    5c1c:	11000421 	add	w1, w1, #0x1
    5c20:	39000001 	strb	w1, [x0]
    5c24:	d65f03c0 	ret
    5c28:	72003c3f 	tst	w1, #0xffff
    5c2c:	54fffe80 	b.eq	5bfc <fwp_rc_dup+0x68>  // b.none
    5c30:	d65f03c0 	ret
    5c34:	f940ac43 	ldr	x3, [x2, #344]
    5c38:	91000463 	add	x3, x3, #0x1
    5c3c:	f900ac43 	str	x3, [x2, #344]
    5c40:	17fffff5 	b	5c14 <fwp_rc_dup+0x80>
    5c44:	17fffb2c 	b	48f4 <fwp_rc_wide_dup>
    5c48:	d503201f 	nop
    5c4c:	d503201f 	nop

0000000000005c50 <fwp_owned_entry173>:
    5c50:	d10103ff 	sub	sp, sp, #0x40
    5c54:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5c58:	f947f442 	ldr	x2, [x2, #4072]
    5c5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5c60:	910083fd 	add	x29, sp, #0x20
    5c64:	a90353f3 	stp	x19, x20, [sp, #48]
    5c68:	f9400043 	ldr	x3, [x2]
    5c6c:	f9000fe3 	str	x3, [sp, #24]
    5c70:	d2800003 	mov	x3, #0x0                   	// #0
    5c74:	a9400c01 	ldp	x1, x3, [x0]
    5c78:	f9400802 	ldr	x2, [x0, #16]
    5c7c:	ab020022 	adds	x2, x1, x2
    5c80:	540006e6 	b.vs	5d5c <fwp_owned_entry173+0x10c>
    5c84:	910023e1 	add	x1, sp, #0x8
    5c88:	52800000 	mov	w0, #0x0                   	// #0
    5c8c:	a9008be3 	stp	x3, x2, [sp, #8]
    5c90:	97fffd81 	bl	5294 <fwp_data.part.0.constprop.0>
    5c94:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5c98:	9118c063 	add	x3, x3, #0x630
    5c9c:	aa0003f3 	mov	x19, x0
    5ca0:	f949d861 	ldr	x1, [x3, #5040]
    5ca4:	f949ec60 	ldr	x0, [x3, #5080]
    5ca8:	cb010261 	sub	x1, x19, x1
    5cac:	eb00403f 	cmp	x1, x0, lsl #16
    5cb0:	54000322 	b.cs	5d14 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5cb4:	d350fc22 	lsr	x2, x1, #16
    5cb8:	f949fc63 	ldr	x3, [x3, #5112]
    5cbc:	8b020842 	add	x2, x2, x2, lsl #2
    5cc0:	d37df042 	lsl	x2, x2, #3
    5cc4:	8b020060 	add	x0, x3, x2
    5cc8:	f9401014 	ldr	x20, [x0, #32]
    5ccc:	b4000254 	cbz	x20, 5d14 <fwp_owned_entry173+0xc4>
    5cd0:	38626862 	ldrb	w2, [x3, x2]
    5cd4:	7100085f 	cmp	w2, #0x2
    5cd8:	54000360 	b.eq	5d44 <fwp_owned_entry173+0xf4>  // b.none
    5cdc:	7100045f 	cmp	w2, #0x1
    5ce0:	540001a1 	b.ne	5d14 <fwp_owned_entry173+0xc4>  // b.any
    5ce4:	29430002 	ldp	w2, w0, [x0, #24]
    5ce8:	92403c21 	and	x1, x1, #0xffff
    5cec:	9b027c21 	mul	x1, x1, x2
    5cf0:	d360fc21 	lsr	x1, x1, #32
    5cf4:	eb00003f 	cmp	x1, x0
    5cf8:	540000e2 	b.cs	5d14 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5cfc:	8b010294 	add	x20, x20, x1
    5d00:	39400280 	ldrb	w0, [x20]
    5d04:	7103fc1f 	cmp	w0, #0xff
    5d08:	54000240 	b.eq	5d50 <fwp_owned_entry173+0x100>  // b.none
    5d0c:	52800020 	mov	w0, #0x1                   	// #1
    5d10:	39000280 	strb	w0, [x20]
    5d14:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5d18:	f947f400 	ldr	x0, [x0, #4072]
    5d1c:	f9400fe2 	ldr	x2, [sp, #24]
    5d20:	f9400001 	ldr	x1, [x0]
    5d24:	eb010042 	subs	x2, x2, x1
    5d28:	d2800001 	mov	x1, #0x0                   	// #0
    5d2c:	540001a1 	b.ne	5d60 <fwp_owned_entry173+0x110>  // b.any
    5d30:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5d34:	aa1303e0 	mov	x0, x19
    5d38:	a94353f3 	ldp	x19, x20, [sp, #48]
    5d3c:	910103ff 	add	sp, sp, #0x40
    5d40:	d65f03c0 	ret
    5d44:	72003c3f 	tst	w1, #0xffff
    5d48:	54fffe61 	b.ne	5d14 <fwp_owned_entry173+0xc4>  // b.any
    5d4c:	17ffffed 	b	5d00 <fwp_owned_entry173+0xb0>
    5d50:	aa1403e0 	mov	x0, x20
    5d54:	97fffb2f 	bl	4a10 <fwp_rc_forget_slot>
    5d58:	17ffffed 	b	5d0c <fwp_owned_entry173+0xbc>
    5d5c:	97fff349 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5d60:	97fff2d0 	bl	28a0 <__stack_chk_fail@plt>

0000000000005d64 <e173>:
    5d64:	d10103ff 	sub	sp, sp, #0x40
    5d68:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5d6c:	f947f442 	ldr	x2, [x2, #4072]
    5d70:	a9027bfd 	stp	x29, x30, [sp, #32]
    5d74:	910083fd 	add	x29, sp, #0x20
    5d78:	a90353f3 	stp	x19, x20, [sp, #48]
    5d7c:	f9400043 	ldr	x3, [x2]
    5d80:	f9000fe3 	str	x3, [sp, #24]
    5d84:	d2800003 	mov	x3, #0x0                   	// #0
    5d88:	a9400c01 	ldp	x1, x3, [x0]
    5d8c:	f9400802 	ldr	x2, [x0, #16]
    5d90:	ab020022 	adds	x2, x1, x2
    5d94:	54000726 	b.vs	5e78 <e173+0x114>
    5d98:	910023e1 	add	x1, sp, #0x8
    5d9c:	52800000 	mov	w0, #0x0                   	// #0
    5da0:	a9008be3 	stp	x3, x2, [sp, #8]
    5da4:	97fffd3c 	bl	5294 <fwp_data.part.0.constprop.0>
    5da8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5dac:	9118c063 	add	x3, x3, #0x630
    5db0:	aa0003f3 	mov	x19, x0
    5db4:	f949d861 	ldr	x1, [x3, #5040]
    5db8:	f949ec60 	ldr	x0, [x3, #5080]
    5dbc:	cb010261 	sub	x1, x19, x1
    5dc0:	eb00403f 	cmp	x1, x0, lsl #16
    5dc4:	54000322 	b.cs	5e28 <e173+0xc4>  // b.hs, b.nlast
    5dc8:	d350fc22 	lsr	x2, x1, #16
    5dcc:	f949fc63 	ldr	x3, [x3, #5112]
    5dd0:	8b020842 	add	x2, x2, x2, lsl #2
    5dd4:	d37df042 	lsl	x2, x2, #3
    5dd8:	8b020060 	add	x0, x3, x2
    5ddc:	f9401014 	ldr	x20, [x0, #32]
    5de0:	b4000254 	cbz	x20, 5e28 <e173+0xc4>
    5de4:	38626862 	ldrb	w2, [x3, x2]
    5de8:	7100085f 	cmp	w2, #0x2
    5dec:	540003a0 	b.eq	5e60 <e173+0xfc>  // b.none
    5df0:	7100045f 	cmp	w2, #0x1
    5df4:	540001a1 	b.ne	5e28 <e173+0xc4>  // b.any
    5df8:	29430002 	ldp	w2, w0, [x0, #24]
    5dfc:	92403c21 	and	x1, x1, #0xffff
    5e00:	9b027c21 	mul	x1, x1, x2
    5e04:	d360fc21 	lsr	x1, x1, #32
    5e08:	eb00003f 	cmp	x1, x0
    5e0c:	540000e2 	b.cs	5e28 <e173+0xc4>  // b.hs, b.nlast
    5e10:	8b010294 	add	x20, x20, x1
    5e14:	39400280 	ldrb	w0, [x20]
    5e18:	7103fc1f 	cmp	w0, #0xff
    5e1c:	54000280 	b.eq	5e6c <e173+0x108>  // b.none
    5e20:	52800020 	mov	w0, #0x1                   	// #1
    5e24:	39000280 	strb	w0, [x20]
    5e28:	aa1303e0 	mov	x0, x19
    5e2c:	97fffee2 	bl	59b4 <fwp_rc_share>
    5e30:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5e34:	f947f400 	ldr	x0, [x0, #4072]
    5e38:	f9400fe2 	ldr	x2, [sp, #24]
    5e3c:	f9400001 	ldr	x1, [x0]
    5e40:	eb010042 	subs	x2, x2, x1
    5e44:	d2800001 	mov	x1, #0x0                   	// #0
    5e48:	540001a1 	b.ne	5e7c <e173+0x118>  // b.any
    5e4c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5e50:	aa1303e0 	mov	x0, x19
    5e54:	a94353f3 	ldp	x19, x20, [sp, #48]
    5e58:	910103ff 	add	sp, sp, #0x40
    5e5c:	d65f03c0 	ret
    5e60:	72003c3f 	tst	w1, #0xffff
    5e64:	54fffe21 	b.ne	5e28 <e173+0xc4>  // b.any
    5e68:	17ffffeb 	b	5e14 <e173+0xb0>
    5e6c:	aa1403e0 	mov	x0, x20
    5e70:	97fffae8 	bl	4a10 <fwp_rc_forget_slot>
    5e74:	17ffffeb 	b	5e20 <e173+0xbc>
    5e78:	97fff302 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5e7c:	97fff289 	bl	28a0 <__stack_chk_fail@plt>

0000000000005e80 <fwp_drop1>:
    5e80:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e84:	910003fd 	mov	x29, sp
    5e88:	a90153f3 	stp	x19, x20, [sp, #16]
    5e8c:	f90013f5 	str	x21, [sp, #32]
    5e90:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    5e94:	9118c2b4 	add	x20, x21, #0x630
    5e98:	f949da81 	ldr	x1, [x20, #5040]
    5e9c:	f949ee82 	ldr	x2, [x20, #5080]
    5ea0:	cb010001 	sub	x1, x0, x1
    5ea4:	eb02403f 	cmp	x1, x2, lsl #16
    5ea8:	54000382 	b.cs	5f18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5eac:	d350fc22 	lsr	x2, x1, #16
    5eb0:	f949fe84 	ldr	x4, [x20, #5112]
    5eb4:	8b020842 	add	x2, x2, x2, lsl #2
    5eb8:	d37df042 	lsl	x2, x2, #3
    5ebc:	8b020083 	add	x3, x4, x2
    5ec0:	f9401073 	ldr	x19, [x3, #32]
    5ec4:	b40002b3 	cbz	x19, 5f18 <fwp_drop1+0x98>
    5ec8:	38626882 	ldrb	w2, [x4, x2]
    5ecc:	7100085f 	cmp	w2, #0x2
    5ed0:	540002c0 	b.eq	5f28 <fwp_drop1+0xa8>  // b.none
    5ed4:	7100045f 	cmp	w2, #0x1
    5ed8:	54000201 	b.ne	5f18 <fwp_drop1+0x98>  // b.any
    5edc:	29430864 	ldp	w4, w2, [x3, #24]
    5ee0:	92403c21 	and	x1, x1, #0xffff
    5ee4:	9b047c21 	mul	x1, x1, x4
    5ee8:	d360fc21 	lsr	x1, x1, #32
    5eec:	eb02003f 	cmp	x1, x2
    5ef0:	54000142 	b.cs	5f18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ef4:	8b010273 	add	x19, x19, x1
    5ef8:	39400261 	ldrb	w1, [x19]
    5efc:	340000e1 	cbz	w1, 5f18 <fwp_drop1+0x98>
    5f00:	7100043f 	cmp	w1, #0x1
    5f04:	540001e0 	b.eq	5f40 <fwp_drop1+0xc0>  // b.none
    5f08:	7103fc3f 	cmp	w1, #0xff
    5f0c:	540002e0 	b.eq	5f68 <fwp_drop1+0xe8>  // b.none
    5f10:	51000421 	sub	w1, w1, #0x1
    5f14:	39000261 	strb	w1, [x19]
    5f18:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f1c:	f94013f5 	ldr	x21, [sp, #32]
    5f20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f24:	d65f03c0 	ret
    5f28:	72003c3f 	tst	w1, #0xffff
    5f2c:	54fffe60 	b.eq	5ef8 <fwp_drop1+0x78>  // b.none
    5f30:	a94153f3 	ldp	x19, x20, [sp, #16]
    5f34:	f94013f5 	ldr	x21, [sp, #32]
    5f38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5f3c:	d65f03c0 	ret
    5f40:	f9400813 	ldr	x19, [x0, #16]
    5f44:	97fffef3 	bl	5b10 <fwp_rc_free_arr>
    5f48:	9118c2a0 	add	x0, x21, #0x630
    5f4c:	f949d801 	ldr	x1, [x0, #5040]
    5f50:	f949ec00 	ldr	x0, [x0, #5080]
    5f54:	cb010261 	sub	x1, x19, x1
    5f58:	eb00403f 	cmp	x1, x0, lsl #16
    5f5c:	54fffde2 	b.cs	5f18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5f60:	aa1303e0 	mov	x0, x19
    5f64:	17ffffd2 	b	5eac <fwp_drop1+0x2c>
    5f68:	ca534660 	eor	x0, x19, x19, lsr #17
    5f6c:	9118c2b5 	add	x21, x21, #0x630
    5f70:	ca402400 	eor	x0, x0, x0, lsr #9
    5f74:	8b200ea0 	add	x0, x21, w0, uxtb #3
    5f78:	f94a2400 	ldr	x0, [x0, #5192]
    5f7c:	b5000080 	cbnz	x0, 5f8c <fwp_drop1+0x10c>
    5f80:	14000010 	b	5fc0 <fwp_drop1+0x140>
    5f84:	f9400800 	ldr	x0, [x0, #16]
    5f88:	b40001c0 	cbz	x0, 5fc0 <fwp_drop1+0x140>
    5f8c:	f9400001 	ldr	x1, [x0]
    5f90:	eb13003f 	cmp	x1, x19
    5f94:	54ffff81 	b.ne	5f84 <fwp_drop1+0x104>  // b.any
    5f98:	f9400401 	ldr	x1, [x0, #8]
    5f9c:	d1000421 	sub	x1, x1, #0x1
    5fa0:	f9000401 	str	x1, [x0, #8]
    5fa4:	f103f83f 	cmp	x1, #0xfe
    5fa8:	54fffb81 	b.ne	5f18 <fwp_drop1+0x98>  // b.any
    5fac:	aa1303e0 	mov	x0, x19
    5fb0:	97fffa98 	bl	4a10 <fwp_rc_forget_slot>
    5fb4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5fb8:	39000260 	strb	w0, [x19]
    5fbc:	17ffffd7 	b	5f18 <fwp_drop1+0x98>
    5fc0:	90000040 	adrp	x0, d000 <__divti3+0x2b0>
    5fc4:	9124c000 	add	x0, x0, #0x930
    5fc8:	97fff60e 	bl	3800 <fwp_trap>
    5fcc:	d503201f 	nop

0000000000005fd0 <fwp_drop0>:
    5fd0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5fd4:	910003fd 	mov	x29, sp
    5fd8:	a90153f3 	stp	x19, x20, [sp, #16]
    5fdc:	f90013f5 	str	x21, [sp, #32]
    5fe0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    5fe4:	9118c2b4 	add	x20, x21, #0x630
    5fe8:	f949da81 	ldr	x1, [x20, #5040]
    5fec:	f949ee82 	ldr	x2, [x20, #5080]
    5ff0:	cb010001 	sub	x1, x0, x1
    5ff4:	eb02403f 	cmp	x1, x2, lsl #16
    5ff8:	54000382 	b.cs	6068 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ffc:	d350fc22 	lsr	x2, x1, #16
    6000:	f949fe84 	ldr	x4, [x20, #5112]
    6004:	8b020842 	add	x2, x2, x2, lsl #2
    6008:	d37df042 	lsl	x2, x2, #3
    600c:	8b020083 	add	x3, x4, x2
    6010:	f9401073 	ldr	x19, [x3, #32]
    6014:	b40002b3 	cbz	x19, 6068 <fwp_drop0+0x98>
    6018:	38626882 	ldrb	w2, [x4, x2]
    601c:	7100085f 	cmp	w2, #0x2
    6020:	540002c0 	b.eq	6078 <fwp_drop0+0xa8>  // b.none
    6024:	7100045f 	cmp	w2, #0x1
    6028:	54000201 	b.ne	6068 <fwp_drop0+0x98>  // b.any
    602c:	29430864 	ldp	w4, w2, [x3, #24]
    6030:	92403c21 	and	x1, x1, #0xffff
    6034:	9b047c21 	mul	x1, x1, x4
    6038:	d360fc21 	lsr	x1, x1, #32
    603c:	eb02003f 	cmp	x1, x2
    6040:	54000142 	b.cs	6068 <fwp_drop0+0x98>  // b.hs, b.nlast
    6044:	8b010273 	add	x19, x19, x1
    6048:	39400261 	ldrb	w1, [x19]
    604c:	340000e1 	cbz	w1, 6068 <fwp_drop0+0x98>
    6050:	7100043f 	cmp	w1, #0x1
    6054:	540001e0 	b.eq	6090 <fwp_drop0+0xc0>  // b.none
    6058:	7103fc3f 	cmp	w1, #0xff
    605c:	540002e0 	b.eq	60b8 <fwp_drop0+0xe8>  // b.none
    6060:	51000421 	sub	w1, w1, #0x1
    6064:	39000261 	strb	w1, [x19]
    6068:	a94153f3 	ldp	x19, x20, [sp, #16]
    606c:	f94013f5 	ldr	x21, [sp, #32]
    6070:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6074:	d65f03c0 	ret
    6078:	72003c3f 	tst	w1, #0xffff
    607c:	54fffe60 	b.eq	6048 <fwp_drop0+0x78>  // b.none
    6080:	a94153f3 	ldp	x19, x20, [sp, #16]
    6084:	f94013f5 	ldr	x21, [sp, #32]
    6088:	a8c37bfd 	ldp	x29, x30, [sp], #48
    608c:	d65f03c0 	ret
    6090:	f9400813 	ldr	x19, [x0, #16]
    6094:	97fffe9f 	bl	5b10 <fwp_rc_free_arr>
    6098:	9118c2a0 	add	x0, x21, #0x630
    609c:	f949d801 	ldr	x1, [x0, #5040]
    60a0:	f949ec00 	ldr	x0, [x0, #5080]
    60a4:	cb010261 	sub	x1, x19, x1
    60a8:	eb00403f 	cmp	x1, x0, lsl #16
    60ac:	54fffde2 	b.cs	6068 <fwp_drop0+0x98>  // b.hs, b.nlast
    60b0:	aa1303e0 	mov	x0, x19
    60b4:	17ffffd2 	b	5ffc <fwp_drop0+0x2c>
    60b8:	ca534660 	eor	x0, x19, x19, lsr #17
    60bc:	9118c2b5 	add	x21, x21, #0x630
    60c0:	ca402400 	eor	x0, x0, x0, lsr #9
    60c4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    60c8:	f94a2400 	ldr	x0, [x0, #5192]
    60cc:	b5000080 	cbnz	x0, 60dc <fwp_drop0+0x10c>
    60d0:	14000010 	b	6110 <fwp_drop0+0x140>
    60d4:	f9400800 	ldr	x0, [x0, #16]
    60d8:	b40001c0 	cbz	x0, 6110 <fwp_drop0+0x140>
    60dc:	f9400001 	ldr	x1, [x0]
    60e0:	eb13003f 	cmp	x1, x19
    60e4:	54ffff81 	b.ne	60d4 <fwp_drop0+0x104>  // b.any
    60e8:	f9400401 	ldr	x1, [x0, #8]
    60ec:	d1000421 	sub	x1, x1, #0x1
    60f0:	f9000401 	str	x1, [x0, #8]
    60f4:	f103f83f 	cmp	x1, #0xfe
    60f8:	54fffb81 	b.ne	6068 <fwp_drop0+0x98>  // b.any
    60fc:	aa1303e0 	mov	x0, x19
    6100:	97fffa44 	bl	4a10 <fwp_rc_forget_slot>
    6104:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6108:	39000260 	strb	w0, [x19]
    610c:	17ffffd7 	b	6068 <fwp_drop0+0x98>
    6110:	f0000020 	adrp	x0, d000 <__divti3+0x2b0>
    6114:	9124c000 	add	x0, x0, #0x930
    6118:	97fff5ba 	bl	3800 <fwp_trap>
    611c:	d503201f 	nop

0000000000006120 <fwp_closure_drop>:
    6120:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xbb0>
    6124:	9118c0a4 	add	x4, x5, #0x630
    6128:	aa0003e1 	mov	x1, x0
    612c:	f949d882 	ldr	x2, [x4, #5040]
    6130:	f949ec80 	ldr	x0, [x4, #5080]
    6134:	cb020022 	sub	x2, x1, x2
    6138:	eb00405f 	cmp	x2, x0, lsl #16
    613c:	54000662 	b.cs	6208 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6140:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6144:	d350fc43 	lsr	x3, x2, #16
    6148:	910003fd 	mov	x29, sp
    614c:	8b030863 	add	x3, x3, x3, lsl #2
    6150:	f949fc84 	ldr	x4, [x4, #5112]
    6154:	d37df063 	lsl	x3, x3, #3
    6158:	f9000bf3 	str	x19, [sp, #16]
    615c:	8b030080 	add	x0, x4, x3
    6160:	f9401013 	ldr	x19, [x0, #32]
    6164:	b40002b3 	cbz	x19, 61b8 <fwp_closure_drop+0x98>
    6168:	38636883 	ldrb	w3, [x4, x3]
    616c:	7100087f 	cmp	w3, #0x2
    6170:	54000420 	b.eq	61f4 <fwp_closure_drop+0xd4>  // b.none
    6174:	7100047f 	cmp	w3, #0x1
    6178:	54000201 	b.ne	61b8 <fwp_closure_drop+0x98>  // b.any
    617c:	29430003 	ldp	w3, w0, [x0, #24]
    6180:	92403c42 	and	x2, x2, #0xffff
    6184:	9b037c42 	mul	x2, x2, x3
    6188:	d360fc42 	lsr	x2, x2, #32
    618c:	eb00005f 	cmp	x2, x0
    6190:	54000142 	b.cs	61b8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6194:	8b020273 	add	x19, x19, x2
    6198:	39400260 	ldrb	w0, [x19]
    619c:	340000e0 	cbz	w0, 61b8 <fwp_closure_drop+0x98>
    61a0:	7100041f 	cmp	w0, #0x1
    61a4:	54000100 	b.eq	61c4 <fwp_closure_drop+0xa4>  // b.none
    61a8:	7103fc1f 	cmp	w0, #0xff
    61ac:	54000300 	b.eq	620c <fwp_closure_drop+0xec>  // b.none
    61b0:	51000400 	sub	w0, w0, #0x1
    61b4:	39000260 	strb	w0, [x19]
    61b8:	f9400bf3 	ldr	x19, [sp, #16]
    61bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61c0:	d65f03c0 	ret
    61c4:	d53bd040 	mrs	x0, tpidr_el0
    61c8:	91400000 	add	x0, x0, #0x0, lsl #12
    61cc:	91004000 	add	x0, x0, #0x10
    61d0:	f9400000 	ldr	x0, [x0]
    61d4:	b4000080 	cbz	x0, 61e4 <fwp_closure_drop+0xc4>
    61d8:	f9400bf3 	ldr	x19, [sp, #16]
    61dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61e0:	17fff5a1 	b	3864 <fwp_closure_drop_push>
    61e4:	f9400bf3 	ldr	x19, [sp, #16]
    61e8:	aa0103e0 	mov	x0, x1
    61ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61f0:	17fff60c 	b	3a20 <fwp_closure_drop.part.0>
    61f4:	72003c5f 	tst	w2, #0xffff
    61f8:	54fffd00 	b.eq	6198 <fwp_closure_drop+0x78>  // b.none
    61fc:	f9400bf3 	ldr	x19, [sp, #16]
    6200:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6204:	d65f03c0 	ret
    6208:	d65f03c0 	ret
    620c:	ca534660 	eor	x0, x19, x19, lsr #17
    6210:	9118c0a5 	add	x5, x5, #0x630
    6214:	ca402400 	eor	x0, x0, x0, lsr #9
    6218:	8b200ca0 	add	x0, x5, w0, uxtb #3
    621c:	f94a2400 	ldr	x0, [x0, #5192]
    6220:	b5000080 	cbnz	x0, 6230 <fwp_closure_drop+0x110>
    6224:	14000010 	b	6264 <fwp_closure_drop+0x144>
    6228:	f9400800 	ldr	x0, [x0, #16]
    622c:	b40001c0 	cbz	x0, 6264 <fwp_closure_drop+0x144>
    6230:	f9400001 	ldr	x1, [x0]
    6234:	eb13003f 	cmp	x1, x19
    6238:	54ffff81 	b.ne	6228 <fwp_closure_drop+0x108>  // b.any
    623c:	f9400401 	ldr	x1, [x0, #8]
    6240:	d1000421 	sub	x1, x1, #0x1
    6244:	f9000401 	str	x1, [x0, #8]
    6248:	f103f83f 	cmp	x1, #0xfe
    624c:	54fffb61 	b.ne	61b8 <fwp_closure_drop+0x98>  // b.any
    6250:	aa1303e0 	mov	x0, x19
    6254:	97fff9ef 	bl	4a10 <fwp_rc_forget_slot>
    6258:	12800020 	mov	w0, #0xfffffffe            	// #-2
    625c:	39000260 	strb	w0, [x19]
    6260:	17ffffd6 	b	61b8 <fwp_closure_drop+0x98>
    6264:	f0000020 	adrp	x0, d000 <__divti3+0x2b0>
    6268:	9124c000 	add	x0, x0, #0x930
    626c:	97fff565 	bl	3800 <fwp_trap>

0000000000006270 <fwp_owned_tape_release>:
    6270:	b4000940 	cbz	x0, 6398 <fwp_owned_tape_release+0x128>
    6274:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6278:	910003fd 	mov	x29, sp
    627c:	a90153f3 	stp	x19, x20, [sp, #16]
    6280:	aa0003f3 	mov	x19, x0
    6284:	f9400000 	ldr	x0, [x0]
    6288:	b4000060 	cbz	x0, 6294 <fwp_owned_tape_release+0x24>
    628c:	f9400661 	ldr	x1, [x19, #8]
    6290:	f9000401 	str	x1, [x0, #8]
    6294:	f9400661 	ldr	x1, [x19, #8]
    6298:	b4000041 	cbz	x1, 62a0 <fwp_owned_tape_release+0x30>
    629c:	f9000020 	str	x0, [x1]
    62a0:	f9400a60 	ldr	x0, [x19, #16]
    62a4:	f9403401 	ldr	x1, [x0, #104]
    62a8:	b40005c1 	cbz	x1, 6360 <fwp_owned_tape_release+0xf0>
    62ac:	a9450a60 	ldp	x0, x2, [x19, #80]
    62b0:	eb00005f 	cmp	x2, x0
    62b4:	540002ed 	b.le	6310 <fwp_owned_tape_release+0xa0>
    62b8:	d2800014 	mov	x20, #0x0                   	// #0
    62bc:	f90013f5 	str	x21, [sp, #32]
    62c0:	d2800015 	mov	x21, #0x0                   	// #0
    62c4:	d503201f 	nop
    62c8:	f9402260 	ldr	x0, [x19, #64]
    62cc:	910006b5 	add	x21, x21, #0x1
    62d0:	f8746800 	ldr	x0, [x0, x20]
    62d4:	d63f0020 	blr	x1
    62d8:	f9402260 	ldr	x0, [x19, #64]
    62dc:	f9400a61 	ldr	x1, [x19, #16]
    62e0:	8b140000 	add	x0, x0, x20
    62e4:	91004294 	add	x20, x20, #0x10
    62e8:	f9400400 	ldr	x0, [x0, #8]
    62ec:	f9403421 	ldr	x1, [x1, #104]
    62f0:	d63f0020 	blr	x1
    62f4:	a9450261 	ldp	x1, x0, [x19, #80]
    62f8:	cb010000 	sub	x0, x0, x1
    62fc:	eb15001f 	cmp	x0, x21
    6300:	f9400a60 	ldr	x0, [x19, #16]
    6304:	f9403401 	ldr	x1, [x0, #104]
    6308:	54fffe0c 	b.gt	62c8 <fwp_owned_tape_release+0x58>
    630c:	f94013f5 	ldr	x21, [sp, #32]
    6310:	f9403663 	ldr	x3, [x19, #104]
    6314:	f9401262 	ldr	x2, [x19, #32]
    6318:	f100007f 	cmp	x3, #0x0
    631c:	540001ed 	b.le	6358 <fwp_owned_tape_release+0xe8>
    6320:	d2800014 	mov	x20, #0x0                   	// #0
    6324:	d503201f 	nop
    6328:	f9402660 	ldr	x0, [x19, #72]
    632c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6330:	eb02001f 	cmp	x0, x2
    6334:	540000c0 	b.eq	634c <fwp_owned_tape_release+0xdc>  // b.none
    6338:	d63f0020 	blr	x1
    633c:	f9400a60 	ldr	x0, [x19, #16]
    6340:	f9401262 	ldr	x2, [x19, #32]
    6344:	f9403663 	ldr	x3, [x19, #104]
    6348:	f9403401 	ldr	x1, [x0, #104]
    634c:	91000694 	add	x20, x20, #0x1
    6350:	eb14007f 	cmp	x3, x20
    6354:	54fffeac 	b.gt	6328 <fwp_owned_tape_release+0xb8>
    6358:	aa0203e0 	mov	x0, x2
    635c:	d63f0020 	blr	x1
    6360:	f9401660 	ldr	x0, [x19, #40]
    6364:	97ffff6f 	bl	6120 <fwp_closure_drop>
    6368:	f9401a60 	ldr	x0, [x19, #48]
    636c:	97ffff6d 	bl	6120 <fwp_closure_drop>
    6370:	f9401e60 	ldr	x0, [x19, #56]
    6374:	97ffff6b 	bl	6120 <fwp_closure_drop>
    6378:	f9402260 	ldr	x0, [x19, #64]
    637c:	97fffa45 	bl	4c90 <fwp_mem_free>
    6380:	f9402660 	ldr	x0, [x19, #72]
    6384:	97fffa43 	bl	4c90 <fwp_mem_free>
    6388:	aa1303e0 	mov	x0, x19
    638c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6390:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6394:	17fffa3f 	b	4c90 <fwp_mem_free>
    6398:	d65f03c0 	ret
    639c:	d503201f 	nop

00000000000063a0 <fwp_tape_finish>:
    63a0:	d10203ff 	sub	sp, sp, #0x80
    63a4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    63a8:	f947f421 	ldr	x1, [x1, #4072]
    63ac:	a9047bfd 	stp	x29, x30, [sp, #64]
    63b0:	910103fd 	add	x29, sp, #0x40
    63b4:	a9065bf5 	stp	x21, x22, [sp, #96]
    63b8:	a90763f7 	stp	x23, x24, [sp, #112]
    63bc:	d00000d7 	adrp	x23, 20000 <__data_start>
    63c0:	910142f6 	add	x22, x23, #0x50
    63c4:	f9400022 	ldr	x2, [x1]
    63c8:	f9001fe2 	str	x2, [sp, #56]
    63cc:	d2800002 	mov	x2, #0x0                   	// #0
    63d0:	910382c0 	add	x0, x22, #0xe0
    63d4:	97fff80c 	bl	4404 <fwp_tape_buffers_dispose>
    63d8:	f9008edf 	str	xzr, [x22, #280]
    63dc:	f9406ec0 	ldr	x0, [x22, #216]
    63e0:	f100001f 	cmp	x0, #0x0
    63e4:	5400034d 	b.le	644c <fwp_tape_finish+0xac>
    63e8:	910003f8 	mov	x24, sp
    63ec:	d2800015 	mov	x21, #0x0                   	// #0
    63f0:	a90553f3 	stp	x19, x20, [sp, #80]
    63f4:	d2800014 	mov	x20, #0x0                   	// #0
    63f8:	91000694 	add	x20, x20, #0x1
    63fc:	f94046d3 	ldr	x19, [x22, #136]
    6400:	8b150273 	add	x19, x19, x21
    6404:	9101a2b5 	add	x21, x21, #0x68
    6408:	aa1303e0 	mov	x0, x19
    640c:	97fff302 	bl	3014 <fwp_tape_unlink_scope>
    6410:	aa1803e0 	mov	x0, x24
    6414:	a9440663 	ldp	x3, x1, [x19, #64]
    6418:	f9001be1 	str	x1, [sp, #48]
    641c:	f9400e62 	ldr	x2, [x19, #24]
    6420:	a9020be3 	stp	x3, x2, [sp, #32]
    6424:	ad410261 	ldp	q1, q0, [x19, #32]
    6428:	ad0003e1 	stp	q1, q0, [sp]
    642c:	97fff7f6 	bl	4404 <fwp_tape_buffers_dispose>
    6430:	f9403260 	ldr	x0, [x19, #96]
    6434:	97ffff8f 	bl	6270 <fwp_owned_tape_release>
    6438:	f900327f 	str	xzr, [x19, #96]
    643c:	f9406ec0 	ldr	x0, [x22, #216]
    6440:	eb14001f 	cmp	x0, x20
    6444:	54fffdac 	b.gt	63f8 <fwp_tape_finish+0x58>
    6448:	a94553f3 	ldp	x19, x20, [sp, #80]
    644c:	910142e0 	add	x0, x23, #0x50
    6450:	f9404400 	ldr	x0, [x0, #136]
    6454:	b4000040 	cbz	x0, 645c <fwp_tape_finish+0xbc>
    6458:	97fff7ca 	bl	4380 <ad_raw_free.part.0>
    645c:	910142f7 	add	x23, x23, #0x50
    6460:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6464:	f947f400 	ldr	x0, [x0, #4072]
    6468:	f90046ff 	str	xzr, [x23, #136]
    646c:	f9006eff 	str	xzr, [x23, #216]
    6470:	f90092ff 	str	xzr, [x23, #288]
    6474:	f900b2ff 	str	xzr, [x23, #352]
    6478:	f9401fe2 	ldr	x2, [sp, #56]
    647c:	f9400001 	ldr	x1, [x0]
    6480:	eb010042 	subs	x2, x2, x1
    6484:	d2800001 	mov	x1, #0x0                   	// #0
    6488:	540000c1 	b.ne	64a0 <fwp_tape_finish+0x100>  // b.any
    648c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6490:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6494:	a94763f7 	ldp	x23, x24, [sp, #112]
    6498:	910203ff 	add	sp, sp, #0x80
    649c:	d65f03c0 	ret
    64a0:	a90553f3 	stp	x19, x20, [sp, #80]
    64a4:	97fff0ff 	bl	28a0 <__stack_chk_fail@plt>
    64a8:	d503201f 	nop
    64ac:	d503201f 	nop

00000000000064b0 <fwp_tape_scope_release>:
    64b0:	d10243ff 	sub	sp, sp, #0x90
    64b4:	a9047bfd 	stp	x29, x30, [sp, #64]
    64b8:	910103fd 	add	x29, sp, #0x40
    64bc:	a90553f3 	stp	x19, x20, [sp, #80]
    64c0:	aa0003f4 	mov	x20, x0
    64c4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    64c8:	f947f400 	ldr	x0, [x0, #4072]
    64cc:	b9400285 	ldr	w5, [x20]
    64d0:	f9400001 	ldr	x1, [x0]
    64d4:	f9001fe1 	str	x1, [sp, #56]
    64d8:	d2800001 	mov	x1, #0x0                   	// #0
    64dc:	37f806c5 	tbnz	w5, #31, 65b4 <fwp_tape_scope_release+0x104>
    64e0:	a90763f7 	stp	x23, x24, [sp, #112]
    64e4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    64e8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    64ec:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    64f0:	d00000d3 	adrp	x19, 20000 <__data_start>
    64f4:	910003f7 	mov	x23, sp
    64f8:	91014273 	add	x19, x19, #0x50
    64fc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6500:	a9065bf5 	stp	x21, x22, [sp, #96]
    6504:	52800d16 	mov	w22, #0x68                  	// #104
    6508:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    650c:	f90043f9 	str	x25, [sp, #128]
    6510:	14000006 	b	6528 <fwp_tape_scope_release+0x78>
    6514:	97fff7bc 	bl	4404 <fwp_tape_buffers_dispose>
    6518:	aa1903e0 	mov	x0, x25
    651c:	97ffff55 	bl	6270 <fwp_owned_tape_release>
    6520:	b9400285 	ldr	w5, [x20]
    6524:	37f80425 	tbnz	w5, #31, 65a8 <fwp_tape_scope_release+0xf8>
    6528:	f9404666 	ldr	x6, [x19, #136]
    652c:	9b367ca5 	smull	x5, w5, w22
    6530:	8b0500c0 	add	x0, x6, x5
    6534:	97fff2b8 	bl	3014 <fwp_tape_unlink_scope>
    6538:	ad410001 	ldp	q1, q0, [x0, #32]
    653c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6540:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6544:	f9400c03 	ldr	x3, [x0, #24]
    6548:	ad0003e1 	stp	q1, q0, [sp]
    654c:	b86568c1 	ldr	w1, [x6, x5]
    6550:	a9440804 	ldp	x4, x2, [x0, #64]
    6554:	b900041f 	str	wzr, [x0, #4]
    6558:	f9403019 	ldr	x25, [x0, #96]
    655c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6560:	f9000c1f 	str	xzr, [x0, #24]
    6564:	a9020fe4 	stp	x4, x3, [sp, #32]
    6568:	f9001be2 	str	x2, [sp, #48]
    656c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6570:	f900301f 	str	xzr, [x0, #96]
    6574:	6b15003f 	cmp	w1, w21
    6578:	540000e8 	b.hi	6594 <fwp_tape_scope_release+0xe4>  // b.pmore
    657c:	9343fca5 	asr	x5, x5, #3
    6580:	f940b260 	ldr	x0, [x19, #352]
    6584:	9b187ca5 	mul	x5, x5, x24
    6588:	eb0000bf 	cmp	x5, x0
    658c:	5400004a 	b.ge	6594 <fwp_tape_scope_release+0xe4>  // b.tcont
    6590:	f900b265 	str	x5, [x19, #352]
    6594:	aa1703e0 	mov	x0, x23
    6598:	b5fffbf9 	cbnz	x25, 6514 <fwp_tape_scope_release+0x64>
    659c:	97fff7e2 	bl	4524 <fwp_tape_buffers_release>
    65a0:	b9400285 	ldr	w5, [x20]
    65a4:	36fffc25 	tbz	w5, #31, 6528 <fwp_tape_scope_release+0x78>
    65a8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    65ac:	a94763f7 	ldp	x23, x24, [sp, #112]
    65b0:	f94043f9 	ldr	x25, [sp, #128]
    65b4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    65b8:	f947f400 	ldr	x0, [x0, #4072]
    65bc:	f9401fe2 	ldr	x2, [sp, #56]
    65c0:	f9400001 	ldr	x1, [x0]
    65c4:	eb010042 	subs	x2, x2, x1
    65c8:	d2800001 	mov	x1, #0x0                   	// #0
    65cc:	540000a1 	b.ne	65e0 <fwp_tape_scope_release+0x130>  // b.any
    65d0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    65d4:	a94553f3 	ldp	x19, x20, [sp, #80]
    65d8:	910243ff 	add	sp, sp, #0x90
    65dc:	d65f03c0 	ret
    65e0:	a9065bf5 	stp	x21, x22, [sp, #96]
    65e4:	a90763f7 	stp	x23, x24, [sp, #112]
    65e8:	f90043f9 	str	x25, [sp, #128]
    65ec:	97fff0ad 	bl	28a0 <__stack_chk_fail@plt>

00000000000065f0 <fwp_drop4>:
    65f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    65f4:	910003fd 	mov	x29, sp
    65f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    65fc:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    6600:	9118c2d5 	add	x21, x22, #0x630
    6604:	a90153f3 	stp	x19, x20, [sp, #16]
    6608:	aa0003f3 	mov	x19, x0
    660c:	f949daa1 	ldr	x1, [x21, #5040]
    6610:	f949eea0 	ldr	x0, [x21, #5080]
    6614:	cb010261 	sub	x1, x19, x1
    6618:	eb00403f 	cmp	x1, x0, lsl #16
    661c:	54000382 	b.cs	668c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6620:	d350fc22 	lsr	x2, x1, #16
    6624:	f949fea3 	ldr	x3, [x21, #5112]
    6628:	8b020842 	add	x2, x2, x2, lsl #2
    662c:	d37df042 	lsl	x2, x2, #3
    6630:	8b020060 	add	x0, x3, x2
    6634:	f9401014 	ldr	x20, [x0, #32]
    6638:	b40002b4 	cbz	x20, 668c <fwp_drop4+0x9c>
    663c:	38626862 	ldrb	w2, [x3, x2]
    6640:	7100085f 	cmp	w2, #0x2
    6644:	540002c0 	b.eq	669c <fwp_drop4+0xac>  // b.none
    6648:	7100045f 	cmp	w2, #0x1
    664c:	54000201 	b.ne	668c <fwp_drop4+0x9c>  // b.any
    6650:	29430002 	ldp	w2, w0, [x0, #24]
    6654:	92403c21 	and	x1, x1, #0xffff
    6658:	9b027c21 	mul	x1, x1, x2
    665c:	d360fc21 	lsr	x1, x1, #32
    6660:	eb00003f 	cmp	x1, x0
    6664:	54000142 	b.cs	668c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6668:	8b010294 	add	x20, x20, x1
    666c:	39400280 	ldrb	w0, [x20]
    6670:	340000e0 	cbz	w0, 668c <fwp_drop4+0x9c>
    6674:	7100041f 	cmp	w0, #0x1
    6678:	540001e0 	b.eq	66b4 <fwp_drop4+0xc4>  // b.none
    667c:	7103fc1f 	cmp	w0, #0xff
    6680:	540007c0 	b.eq	6778 <fwp_drop4+0x188>  // b.none
    6684:	51000400 	sub	w0, w0, #0x1
    6688:	39000280 	strb	w0, [x20]
    668c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6690:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6694:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6698:	d65f03c0 	ret
    669c:	72003c3f 	tst	w1, #0xffff
    66a0:	54fffe60 	b.eq	666c <fwp_drop4+0x7c>  // b.none
    66a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    66a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    66ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    66b0:	d65f03c0 	ret
    66b4:	9118c2c2 	add	x2, x22, #0x630
    66b8:	f9400660 	ldr	x0, [x19, #8]
    66bc:	f949d841 	ldr	x1, [x2, #5040]
    66c0:	f949ec42 	ldr	x2, [x2, #5080]
    66c4:	cb010001 	sub	x1, x0, x1
    66c8:	eb02403f 	cmp	x1, x2, lsl #16
    66cc:	54000362 	b.cs	6738 <fwp_drop4+0x148>  // b.hs, b.nlast
    66d0:	d350fc22 	lsr	x2, x1, #16
    66d4:	8b020842 	add	x2, x2, x2, lsl #2
    66d8:	d37df042 	lsl	x2, x2, #3
    66dc:	8b020064 	add	x4, x3, x2
    66e0:	f9401094 	ldr	x20, [x4, #32]
    66e4:	b40002b4 	cbz	x20, 6738 <fwp_drop4+0x148>
    66e8:	38626862 	ldrb	w2, [x3, x2]
    66ec:	7100085f 	cmp	w2, #0x2
    66f0:	540003e0 	b.eq	676c <fwp_drop4+0x17c>  // b.none
    66f4:	7100045f 	cmp	w2, #0x1
    66f8:	54000201 	b.ne	6738 <fwp_drop4+0x148>  // b.any
    66fc:	29430883 	ldp	w3, w2, [x4, #24]
    6700:	92403c21 	and	x1, x1, #0xffff
    6704:	9b037c21 	mul	x1, x1, x3
    6708:	d360fc21 	lsr	x1, x1, #32
    670c:	eb02003f 	cmp	x1, x2
    6710:	54000142 	b.cs	6738 <fwp_drop4+0x148>  // b.hs, b.nlast
    6714:	8b010294 	add	x20, x20, x1
    6718:	39400281 	ldrb	w1, [x20]
    671c:	340000e1 	cbz	w1, 6738 <fwp_drop4+0x148>
    6720:	7100043f 	cmp	w1, #0x1
    6724:	54000200 	b.eq	6764 <fwp_drop4+0x174>  // b.none
    6728:	7103fc3f 	cmp	w1, #0xff
    672c:	54000580 	b.eq	67dc <fwp_drop4+0x1ec>  // b.none
    6730:	51000421 	sub	w1, w1, #0x1
    6734:	39000281 	strb	w1, [x20]
    6738:	f9400a74 	ldr	x20, [x19, #16]
    673c:	aa1303e0 	mov	x0, x19
    6740:	97fffcf4 	bl	5b10 <fwp_rc_free_arr>
    6744:	9118c2c0 	add	x0, x22, #0x630
    6748:	f949d801 	ldr	x1, [x0, #5040]
    674c:	f949ec00 	ldr	x0, [x0, #5080]
    6750:	cb010281 	sub	x1, x20, x1
    6754:	eb00403f 	cmp	x1, x0, lsl #16
    6758:	54fff9a2 	b.cs	668c <fwp_drop4+0x9c>  // b.hs, b.nlast
    675c:	aa1403f3 	mov	x19, x20
    6760:	17ffffb0 	b	6620 <fwp_drop4+0x30>
    6764:	97fffceb 	bl	5b10 <fwp_rc_free_arr>
    6768:	17fffff4 	b	6738 <fwp_drop4+0x148>
    676c:	72003c3f 	tst	w1, #0xffff
    6770:	54fffe41 	b.ne	6738 <fwp_drop4+0x148>  // b.any
    6774:	17ffffe9 	b	6718 <fwp_drop4+0x128>
    6778:	ca544681 	eor	x1, x20, x20, lsr #17
    677c:	9118c2c0 	add	x0, x22, #0x630
    6780:	ca412421 	eor	x1, x1, x1, lsr #9
    6784:	8b210c01 	add	x1, x0, w1, uxtb #3
    6788:	f94a2420 	ldr	x0, [x1, #5192]
    678c:	b5000080 	cbnz	x0, 679c <fwp_drop4+0x1ac>
    6790:	14000010 	b	67d0 <fwp_drop4+0x1e0>
    6794:	f9400800 	ldr	x0, [x0, #16]
    6798:	b40001c0 	cbz	x0, 67d0 <fwp_drop4+0x1e0>
    679c:	f9400001 	ldr	x1, [x0]
    67a0:	eb14003f 	cmp	x1, x20
    67a4:	54ffff81 	b.ne	6794 <fwp_drop4+0x1a4>  // b.any
    67a8:	f9400401 	ldr	x1, [x0, #8]
    67ac:	d1000421 	sub	x1, x1, #0x1
    67b0:	f9000401 	str	x1, [x0, #8]
    67b4:	f103f83f 	cmp	x1, #0xfe
    67b8:	54fff6a1 	b.ne	668c <fwp_drop4+0x9c>  // b.any
    67bc:	aa1403e0 	mov	x0, x20
    67c0:	97fff894 	bl	4a10 <fwp_rc_forget_slot>
    67c4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    67c8:	39000280 	strb	w0, [x20]
    67cc:	17ffffb0 	b	668c <fwp_drop4+0x9c>
    67d0:	f0000020 	adrp	x0, d000 <__divti3+0x2b0>
    67d4:	9124c000 	add	x0, x0, #0x930
    67d8:	97fff40a 	bl	3800 <fwp_trap>
    67dc:	ca544680 	eor	x0, x20, x20, lsr #17
    67e0:	9118c2c1 	add	x1, x22, #0x630
    67e4:	ca402400 	eor	x0, x0, x0, lsr #9
    67e8:	8b200c20 	add	x0, x1, w0, uxtb #3
    67ec:	f94a2400 	ldr	x0, [x0, #5192]
    67f0:	b5000080 	cbnz	x0, 6800 <fwp_drop4+0x210>
    67f4:	17fffff7 	b	67d0 <fwp_drop4+0x1e0>
    67f8:	f9400800 	ldr	x0, [x0, #16]
    67fc:	b4fffea0 	cbz	x0, 67d0 <fwp_drop4+0x1e0>
    6800:	f9400001 	ldr	x1, [x0]
    6804:	eb14003f 	cmp	x1, x20
    6808:	54ffff81 	b.ne	67f8 <fwp_drop4+0x208>  // b.any
    680c:	f9400401 	ldr	x1, [x0, #8]
    6810:	d1000421 	sub	x1, x1, #0x1
    6814:	f9000401 	str	x1, [x0, #8]
    6818:	f103f83f 	cmp	x1, #0xfe
    681c:	54fff8e1 	b.ne	6738 <fwp_drop4+0x148>  // b.any
    6820:	aa1403e0 	mov	x0, x20
    6824:	97fff87b 	bl	4a10 <fwp_rc_forget_slot>
    6828:	12800020 	mov	w0, #0xfffffffe            	// #-2
    682c:	39000280 	strb	w0, [x20]
    6830:	17ffffc2 	b	6738 <fwp_drop4+0x148>

0000000000006834 <fwp_arg_drop37>:
    6834:	7100003f 	cmp	w1, #0x0
    6838:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    683c:	54000041 	b.ne	6844 <fwp_arg_drop37+0x10>  // b.any
    6840:	d65f03c0 	ret
    6844:	f9400000 	ldr	x0, [x0]
    6848:	17ffff6a 	b	65f0 <fwp_drop4>
    684c:	d503201f 	nop

0000000000006850 <fwp_task_dispose>:
    6850:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6854:	910003fd 	mov	x29, sp
    6858:	f9000bf3 	str	x19, [sp, #16]
    685c:	aa0003f3 	mov	x19, x0
    6860:	39414000 	ldrb	w0, [x0, #80]
    6864:	36000720 	tbz	w0, #0, 6948 <fwp_task_dispose+0xf8>
    6868:	f9400a60 	ldr	x0, [x19, #16]
    686c:	b50006e0 	cbnz	x0, 6948 <fwp_task_dispose+0xf8>
    6870:	a9478660 	ldp	x0, x1, [x19, #120]
    6874:	39014e7f 	strb	wzr, [x19, #83]
    6878:	f9003e7f 	str	xzr, [x19, #120]
    687c:	f100003f 	cmp	x1, #0x0
    6880:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6884:	54000040 	b.eq	688c <fwp_task_dispose+0x3c>  // b.none
    6888:	d63f0020 	blr	x1
    688c:	f9405660 	ldr	x0, [x19, #168]
    6890:	97fff900 	bl	4c90 <fwp_mem_free>
    6894:	f900567f 	str	xzr, [x19, #168]
    6898:	b9405e60 	ldr	w0, [x19, #92]
    689c:	7100041f 	cmp	w0, #0x1
    68a0:	54000420 	b.eq	6924 <fwp_task_dispose+0xd4>  // b.none
    68a4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    68a8:	9118c042 	add	x2, x2, #0x630
    68ac:	f949d840 	ldr	x0, [x2, #5040]
    68b0:	f949ec41 	ldr	x1, [x2, #5080]
    68b4:	cb000260 	sub	x0, x19, x0
    68b8:	eb01401f 	cmp	x0, x1, lsl #16
    68bc:	540002e2 	b.cs	6918 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    68c0:	d350fc01 	lsr	x1, x0, #16
    68c4:	f949fc44 	ldr	x4, [x2, #5112]
    68c8:	8b010821 	add	x1, x1, x1, lsl #2
    68cc:	d37df021 	lsl	x1, x1, #3
    68d0:	8b010083 	add	x3, x4, x1
    68d4:	f9401062 	ldr	x2, [x3, #32]
    68d8:	b4000202 	cbz	x2, 6918 <fwp_task_dispose+0xc8>
    68dc:	38616881 	ldrb	w1, [x4, x1]
    68e0:	7100083f 	cmp	w1, #0x2
    68e4:	54000280 	b.eq	6934 <fwp_task_dispose+0xe4>  // b.none
    68e8:	7100043f 	cmp	w1, #0x1
    68ec:	54000161 	b.ne	6918 <fwp_task_dispose+0xc8>  // b.any
    68f0:	29430464 	ldp	w4, w1, [x3, #24]
    68f4:	92403c00 	and	x0, x0, #0xffff
    68f8:	9b047c00 	mul	x0, x0, x4
    68fc:	d360fc00 	lsr	x0, x0, #32
    6900:	eb01001f 	cmp	x0, x1
    6904:	540000a2 	b.cs	6918 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6908:	8b000042 	add	x2, x2, x0
    690c:	39400040 	ldrb	w0, [x2]
    6910:	7100041f 	cmp	w0, #0x1
    6914:	54000080 	b.eq	6924 <fwp_task_dispose+0xd4>  // b.none
    6918:	f9400bf3 	ldr	x19, [sp, #16]
    691c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6920:	d65f03c0 	ret
    6924:	aa1303e0 	mov	x0, x19
    6928:	f9400bf3 	ldr	x19, [sp, #16]
    692c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6930:	17fff8d8 	b	4c90 <fwp_mem_free>
    6934:	72003c1f 	tst	w0, #0xffff
    6938:	54fffea0 	b.eq	690c <fwp_task_dispose+0xbc>  // b.none
    693c:	f9400bf3 	ldr	x19, [sp, #16]
    6940:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6944:	d65f03c0 	ret
    6948:	97ffefea 	bl	28f0 <abort@plt>
    694c:	d503201f 	nop

0000000000006950 <fwp_free_zombie>:
    6950:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6954:	910003fd 	mov	x29, sp
    6958:	a90153f3 	stp	x19, x20, [sp, #16]
    695c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6960:	91014281 	add	x1, x20, #0x50
    6964:	f940b433 	ldr	x19, [x1, #360]
    6968:	b4000333 	cbz	x19, 69cc <fwp_free_zombie+0x7c>
    696c:	f9404c20 	ldr	x0, [x1, #152]
    6970:	eb00027f 	cmp	x19, x0
    6974:	540002c0 	b.eq	69cc <fwp_free_zombie+0x7c>  // b.none
    6978:	b9417022 	ldr	w2, [x1, #368]
    697c:	f9400a60 	ldr	x0, [x19, #16]
    6980:	7100fc5f 	cmp	w2, #0x3f
    6984:	5400078c 	b.gt	6a74 <fwp_free_zombie+0x124>
    6988:	91060023 	add	x3, x1, #0x180
    698c:	11000444 	add	w4, w2, #0x1
    6990:	b9017024 	str	w4, [x1, #368]
    6994:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6998:	f822d860 	str	x0, [x3, w2, sxtw #3]
    699c:	a9530261 	ldp	x1, x0, [x19, #304]
    69a0:	b4000741 	cbz	x1, 6a88 <fwp_free_zombie+0x138>
    69a4:	f9009c20 	str	x0, [x1, #312]
    69a8:	b4000040 	cbz	x0, 69b0 <fwp_free_zombie+0x60>
    69ac:	f9009801 	str	x1, [x0, #304]
    69b0:	91014294 	add	x20, x20, #0x50
    69b4:	b9405e60 	ldr	w0, [x19, #92]
    69b8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    69bc:	f900b69f 	str	xzr, [x20, #360]
    69c0:	34000140 	cbz	w0, 69e8 <fwp_free_zombie+0x98>
    69c4:	7100041f 	cmp	w0, #0x1
    69c8:	54000080 	b.eq	69d8 <fwp_free_zombie+0x88>  // b.none
    69cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    69d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69d4:	d65f03c0 	ret
    69d8:	aa1303e0 	mov	x0, x19
    69dc:	a94153f3 	ldp	x19, x20, [sp, #16]
    69e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    69e4:	17ffff9b 	b	6850 <fwp_task_dispose>
    69e8:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbb0>
    69ec:	9118c082 	add	x2, x4, #0x630
    69f0:	f949d841 	ldr	x1, [x2, #5040]
    69f4:	f949ec40 	ldr	x0, [x2, #5080]
    69f8:	cb010261 	sub	x1, x19, x1
    69fc:	eb00403f 	cmp	x1, x0, lsl #16
    6a00:	54fffe62 	b.cs	69cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6a04:	d350fc20 	lsr	x0, x1, #16
    6a08:	f949fc43 	ldr	x3, [x2, #5112]
    6a0c:	8b000800 	add	x0, x0, x0, lsl #2
    6a10:	d37df000 	lsl	x0, x0, #3
    6a14:	8b000062 	add	x2, x3, x0
    6a18:	f9401054 	ldr	x20, [x2, #32]
    6a1c:	b4fffd94 	cbz	x20, 69cc <fwp_free_zombie+0x7c>
    6a20:	38606860 	ldrb	w0, [x3, x0]
    6a24:	7100081f 	cmp	w0, #0x2
    6a28:	54000360 	b.eq	6a94 <fwp_free_zombie+0x144>  // b.none
    6a2c:	7100041f 	cmp	w0, #0x1
    6a30:	54fffce1 	b.ne	69cc <fwp_free_zombie+0x7c>  // b.any
    6a34:	29430043 	ldp	w3, w0, [x2, #24]
    6a38:	92403c21 	and	x1, x1, #0xffff
    6a3c:	9b037c21 	mul	x1, x1, x3
    6a40:	d360fc21 	lsr	x1, x1, #32
    6a44:	eb00003f 	cmp	x1, x0
    6a48:	54fffc22 	b.cs	69cc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6a4c:	8b010294 	add	x20, x20, x1
    6a50:	39400280 	ldrb	w0, [x20]
    6a54:	34fffbc0 	cbz	w0, 69cc <fwp_free_zombie+0x7c>
    6a58:	7100041f 	cmp	w0, #0x1
    6a5c:	54fffbe0 	b.eq	69d8 <fwp_free_zombie+0x88>  // b.none
    6a60:	7103fc1f 	cmp	w0, #0xff
    6a64:	540001e0 	b.eq	6aa0 <fwp_free_zombie+0x150>  // b.none
    6a68:	51000400 	sub	w0, w0, #0x1
    6a6c:	39000280 	strb	w0, [x20]
    6a70:	17ffffd7 	b	69cc <fwp_free_zombie+0x7c>
    6a74:	f9400e61 	ldr	x1, [x19, #24]
    6a78:	97ffefd2 	bl	29c0 <munmap@plt>
    6a7c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6a80:	a9530261 	ldp	x1, x0, [x19, #304]
    6a84:	b5fff901 	cbnz	x1, 69a4 <fwp_free_zombie+0x54>
    6a88:	91014282 	add	x2, x20, #0x50
    6a8c:	f901c040 	str	x0, [x2, #896]
    6a90:	17ffffc6 	b	69a8 <fwp_free_zombie+0x58>
    6a94:	72003c3f 	tst	w1, #0xffff
    6a98:	54fff9a1 	b.ne	69cc <fwp_free_zombie+0x7c>  // b.any
    6a9c:	17ffffed 	b	6a50 <fwp_free_zombie+0x100>
    6aa0:	ca544680 	eor	x0, x20, x20, lsr #17
    6aa4:	9118c084 	add	x4, x4, #0x630
    6aa8:	ca402400 	eor	x0, x0, x0, lsr #9
    6aac:	8b200c80 	add	x0, x4, w0, uxtb #3
    6ab0:	f94a2400 	ldr	x0, [x0, #5192]
    6ab4:	b5000080 	cbnz	x0, 6ac4 <fwp_free_zombie+0x174>
    6ab8:	14000010 	b	6af8 <fwp_free_zombie+0x1a8>
    6abc:	f9400800 	ldr	x0, [x0, #16]
    6ac0:	b40001c0 	cbz	x0, 6af8 <fwp_free_zombie+0x1a8>
    6ac4:	f9400001 	ldr	x1, [x0]
    6ac8:	eb14003f 	cmp	x1, x20
    6acc:	54ffff81 	b.ne	6abc <fwp_free_zombie+0x16c>  // b.any
    6ad0:	f9400401 	ldr	x1, [x0, #8]
    6ad4:	d1000421 	sub	x1, x1, #0x1
    6ad8:	f9000401 	str	x1, [x0, #8]
    6adc:	f103f83f 	cmp	x1, #0xfe
    6ae0:	54fff761 	b.ne	69cc <fwp_free_zombie+0x7c>  // b.any
    6ae4:	aa1403e0 	mov	x0, x20
    6ae8:	97fff7ca 	bl	4a10 <fwp_rc_forget_slot>
    6aec:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6af0:	39000280 	strb	w0, [x20]
    6af4:	17ffffb6 	b	69cc <fwp_free_zombie+0x7c>
    6af8:	f0000020 	adrp	x0, d000 <__divti3+0x2b0>
    6afc:	9124c000 	add	x0, x0, #0x930
    6b00:	97fff340 	bl	3800 <fwp_trap>

0000000000006b04 <fwp_block>:
    6b04:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b08:	910003fd 	mov	x29, sp
    6b0c:	a90153f3 	stp	x19, x20, [sp, #16]
    6b10:	d00000d3 	adrp	x19, 20000 <__data_start>
    6b14:	91014274 	add	x20, x19, #0x50
    6b18:	f9406682 	ldr	x2, [x20, #200]
    6b1c:	b4000622 	cbz	x2, 6be0 <fwp_block+0xdc>
    6b20:	91014261 	add	x1, x19, #0x50
    6b24:	f9408040 	ldr	x0, [x2, #256]
    6b28:	f9006420 	str	x0, [x1, #200]
    6b2c:	b4000680 	cbz	x0, 6bfc <fwp_block+0xf8>
    6b30:	91014263 	add	x3, x19, #0x50
    6b34:	3901505f 	strb	wzr, [x2, #84]
    6b38:	f9404c64 	ldr	x4, [x3, #152]
    6b3c:	eb02009f 	cmp	x4, x2
    6b40:	54000440 	b.eq	6bc8 <fwp_block+0xc4>  // b.none
    6b44:	f941c465 	ldr	x5, [x3, #904]
    6b48:	f9004c62 	str	x2, [x3, #152]
    6b4c:	f9400441 	ldr	x1, [x2, #8]
    6b50:	f9004885 	str	x5, [x4, #144]
    6b54:	f941c865 	ldr	x5, [x3, #912]
    6b58:	f9004c85 	str	x5, [x4, #152]
    6b5c:	f941cc65 	ldr	x5, [x3, #920]
    6b60:	f9005085 	str	x5, [x4, #160]
    6b64:	f941d065 	ldr	x5, [x3, #928]
    6b68:	f9005485 	str	x5, [x4, #168]
    6b6c:	f941d465 	ldr	x5, [x3, #936]
    6b70:	f9005885 	str	x5, [x4, #176]
    6b74:	f941d865 	ldr	x5, [x3, #944]
    6b78:	f9005c85 	str	x5, [x4, #184]
    6b7c:	f941dc65 	ldr	x5, [x3, #952]
    6b80:	f9006085 	str	x5, [x4, #192]
    6b84:	f9400480 	ldr	x0, [x4, #8]
    6b88:	f9404844 	ldr	x4, [x2, #144]
    6b8c:	f901c464 	str	x4, [x3, #904]
    6b90:	f9404c44 	ldr	x4, [x2, #152]
    6b94:	f901c864 	str	x4, [x3, #912]
    6b98:	f9405044 	ldr	x4, [x2, #160]
    6b9c:	f901cc64 	str	x4, [x3, #920]
    6ba0:	f9405444 	ldr	x4, [x2, #168]
    6ba4:	f901d064 	str	x4, [x3, #928]
    6ba8:	f9405844 	ldr	x4, [x2, #176]
    6bac:	f901d464 	str	x4, [x3, #936]
    6bb0:	a94b8844 	ldp	x4, x2, [x2, #184]
    6bb4:	f901d864 	str	x4, [x3, #944]
    6bb8:	f901dc62 	str	x2, [x3, #952]
    6bbc:	97ffef51 	bl	2900 <swapcontext@plt>
    6bc0:	97ffff64 	bl	6950 <fwp_free_zombie>
    6bc4:	d503201f 	nop
    6bc8:	91014260 	add	x0, x19, #0x50
    6bcc:	b943c000 	ldr	w0, [x0, #960]
    6bd0:	340001a0 	cbz	w0, 6c04 <fwp_block+0x100>
    6bd4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6bd8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6bdc:	d65f03c0 	ret
    6be0:	97fff6b9 	bl	46c4 <fwp_poll_events>
    6be4:	f9406682 	ldr	x2, [x20, #200]
    6be8:	b4ffffc2 	cbz	x2, 6be0 <fwp_block+0xdc>
    6bec:	91014261 	add	x1, x19, #0x50
    6bf0:	f9408040 	ldr	x0, [x2, #256]
    6bf4:	f9006420 	str	x0, [x1, #200]
    6bf8:	b5fff9c0 	cbnz	x0, 6b30 <fwp_block+0x2c>
    6bfc:	f900603f 	str	xzr, [x1, #192]
    6c00:	17ffffcc 	b	6b30 <fwp_block+0x2c>
    6c04:	f0000020 	adrp	x0, d000 <__divti3+0x2b0>
    6c08:	91298000 	add	x0, x0, #0xa60
    6c0c:	97ffef89 	bl	2a30 <getenv@plt>
    6c10:	5284e202 	mov	w2, #0x2710                	// #10000
    6c14:	b4000060 	cbz	x0, 6c20 <fwp_block+0x11c>
    6c18:	39400001 	ldrb	w1, [x0]
    6c1c:	350000c1 	cbnz	w1, 6c34 <fwp_block+0x130>
    6c20:	91014273 	add	x19, x19, #0x50
    6c24:	b903c262 	str	w2, [x19, #960]
    6c28:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c30:	d65f03c0 	ret
    6c34:	52800142 	mov	w2, #0xa                   	// #10
    6c38:	d2800001 	mov	x1, #0x0                   	// #0
    6c3c:	97ffeecd 	bl	2770 <strtoll@plt>
    6c40:	d1000403 	sub	x3, x0, #0x1
    6c44:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6c48:	eb02007f 	cmp	x3, x2
    6c4c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6c50:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6c54:	17fffff3 	b	6c20 <fwp_block+0x11c>
    6c58:	d503201f 	nop
    6c5c:	d503201f 	nop

0000000000006c60 <fwp_drop10>:
    6c60:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6c64:	910003fd 	mov	x29, sp
    6c68:	a90153f3 	stp	x19, x20, [sp, #16]
    6c6c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    6c70:	f90013f5 	str	x21, [sp, #32]
    6c74:	9118c275 	add	x21, x19, #0x630
    6c78:	f949daa1 	ldr	x1, [x21, #5040]
    6c7c:	f949eea2 	ldr	x2, [x21, #5080]
    6c80:	cb010001 	sub	x1, x0, x1
    6c84:	eb02403f 	cmp	x1, x2, lsl #16
    6c88:	54000382 	b.cs	6cf8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6c8c:	d350fc22 	lsr	x2, x1, #16
    6c90:	f949fea3 	ldr	x3, [x21, #5112]
    6c94:	8b020842 	add	x2, x2, x2, lsl #2
    6c98:	d37df042 	lsl	x2, x2, #3
    6c9c:	8b020064 	add	x4, x3, x2
    6ca0:	f9401094 	ldr	x20, [x4, #32]
    6ca4:	b40002b4 	cbz	x20, 6cf8 <fwp_drop10+0x98>
    6ca8:	38626862 	ldrb	w2, [x3, x2]
    6cac:	7100085f 	cmp	w2, #0x2
    6cb0:	540007a0 	b.eq	6da4 <fwp_drop10+0x144>  // b.none
    6cb4:	7100045f 	cmp	w2, #0x1
    6cb8:	54000201 	b.ne	6cf8 <fwp_drop10+0x98>  // b.any
    6cbc:	29430885 	ldp	w5, w2, [x4, #24]
    6cc0:	92403c21 	and	x1, x1, #0xffff
    6cc4:	9b057c21 	mul	x1, x1, x5
    6cc8:	d360fc21 	lsr	x1, x1, #32
    6ccc:	eb02003f 	cmp	x1, x2
    6cd0:	54000142 	b.cs	6cf8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6cd4:	8b010294 	add	x20, x20, x1
    6cd8:	39400281 	ldrb	w1, [x20]
    6cdc:	340000e1 	cbz	w1, 6cf8 <fwp_drop10+0x98>
    6ce0:	7100043f 	cmp	w1, #0x1
    6ce4:	54000120 	b.eq	6d08 <fwp_drop10+0xa8>  // b.none
    6ce8:	7103fc3f 	cmp	w1, #0xff
    6cec:	540007c0 	b.eq	6de4 <fwp_drop10+0x184>  // b.none
    6cf0:	51000421 	sub	w1, w1, #0x1
    6cf4:	39000281 	strb	w1, [x20]
    6cf8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cfc:	f94013f5 	ldr	x21, [sp, #32]
    6d00:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d04:	d65f03c0 	ret
    6d08:	f9400001 	ldr	x1, [x0]
    6d0c:	b7f80581 	tbnz	x1, #63, 6dbc <fwp_drop10+0x15c>
    6d10:	9118c273 	add	x19, x19, #0x630
    6d14:	f949da61 	ldr	x1, [x19, #5040]
    6d18:	f949ee62 	ldr	x2, [x19, #5080]
    6d1c:	cb010001 	sub	x1, x0, x1
    6d20:	eb02403f 	cmp	x1, x2, lsl #16
    6d24:	54fffea2 	b.cs	6cf8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d28:	d350fc22 	lsr	x2, x1, #16
    6d2c:	8b020842 	add	x2, x2, x2, lsl #2
    6d30:	d37df042 	lsl	x2, x2, #3
    6d34:	8b020065 	add	x5, x3, x2
    6d38:	f94010a4 	ldr	x4, [x5, #32]
    6d3c:	b4fffde4 	cbz	x4, 6cf8 <fwp_drop10+0x98>
    6d40:	38626862 	ldrb	w2, [x3, x2]
    6d44:	7100085f 	cmp	w2, #0x2
    6d48:	54000220 	b.eq	6d8c <fwp_drop10+0x12c>  // b.none
    6d4c:	7100045f 	cmp	w2, #0x1
    6d50:	54fffd41 	b.ne	6cf8 <fwp_drop10+0x98>  // b.any
    6d54:	294308a3 	ldp	w3, w2, [x5, #24]
    6d58:	92403c21 	and	x1, x1, #0xffff
    6d5c:	9b037c21 	mul	x1, x1, x3
    6d60:	d360fc21 	lsr	x1, x1, #32
    6d64:	eb02003f 	cmp	x1, x2
    6d68:	54fffc82 	b.cs	6cf8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d6c:	8b010084 	add	x4, x4, x1
    6d70:	39400081 	ldrb	w1, [x4]
    6d74:	7100043f 	cmp	w1, #0x1
    6d78:	54fffc01 	b.ne	6cf8 <fwp_drop10+0x98>  // b.any
    6d7c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d80:	f94013f5 	ldr	x21, [sp, #32]
    6d84:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d88:	17fff7c2 	b	4c90 <fwp_mem_free>
    6d8c:	72003c3f 	tst	w1, #0xffff
    6d90:	54ffff00 	b.eq	6d70 <fwp_drop10+0x110>  // b.none
    6d94:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d98:	f94013f5 	ldr	x21, [sp, #32]
    6d9c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6da0:	d65f03c0 	ret
    6da4:	72003c3f 	tst	w1, #0xffff
    6da8:	54fff980 	b.eq	6cd8 <fwp_drop10+0x78>  // b.none
    6dac:	a94153f3 	ldp	x19, x20, [sp, #16]
    6db0:	f94013f5 	ldr	x21, [sp, #32]
    6db4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6db8:	d65f03c0 	ret
    6dbc:	f9400414 	ldr	x20, [x0, #8]
    6dc0:	97fffb54 	bl	5b10 <fwp_rc_free_arr>
    6dc4:	9118c260 	add	x0, x19, #0x630
    6dc8:	f949d801 	ldr	x1, [x0, #5040]
    6dcc:	f949ec00 	ldr	x0, [x0, #5080]
    6dd0:	cb010281 	sub	x1, x20, x1
    6dd4:	eb00403f 	cmp	x1, x0, lsl #16
    6dd8:	54fff902 	b.cs	6cf8 <fwp_drop10+0x98>  // b.hs, b.nlast
    6ddc:	aa1403e0 	mov	x0, x20
    6de0:	17ffffab 	b	6c8c <fwp_drop10+0x2c>
    6de4:	ca544680 	eor	x0, x20, x20, lsr #17
    6de8:	9118c273 	add	x19, x19, #0x630
    6dec:	ca402400 	eor	x0, x0, x0, lsr #9
    6df0:	8b200e60 	add	x0, x19, w0, uxtb #3
    6df4:	f94a2400 	ldr	x0, [x0, #5192]
    6df8:	b5000080 	cbnz	x0, 6e08 <fwp_drop10+0x1a8>
    6dfc:	14000010 	b	6e3c <fwp_drop10+0x1dc>
    6e00:	f9400800 	ldr	x0, [x0, #16]
    6e04:	b40001c0 	cbz	x0, 6e3c <fwp_drop10+0x1dc>
    6e08:	f9400001 	ldr	x1, [x0]
    6e0c:	eb14003f 	cmp	x1, x20
    6e10:	54ffff81 	b.ne	6e00 <fwp_drop10+0x1a0>  // b.any
    6e14:	f9400401 	ldr	x1, [x0, #8]
    6e18:	d1000421 	sub	x1, x1, #0x1
    6e1c:	f9000401 	str	x1, [x0, #8]
    6e20:	f103f83f 	cmp	x1, #0xfe
    6e24:	54fff6a1 	b.ne	6cf8 <fwp_drop10+0x98>  // b.any
    6e28:	aa1403e0 	mov	x0, x20
    6e2c:	97fff6f9 	bl	4a10 <fwp_rc_forget_slot>
    6e30:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6e34:	39000280 	strb	w0, [x20]
    6e38:	17ffffb0 	b	6cf8 <fwp_drop10+0x98>
    6e3c:	f0000020 	adrp	x0, d000 <__divti3+0x2b0>
    6e40:	9124c000 	add	x0, x0, #0x930
    6e44:	97fff26f 	bl	3800 <fwp_trap>
    6e48:	d503201f 	nop
    6e4c:	d503201f 	nop

0000000000006e50 <fwp_caps173>:
    6e50:	34000041 	cbz	w1, 6e58 <fwp_caps173+0x8>
    6e54:	d65f03c0 	ret
    6e58:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    6e5c:	9118c063 	add	x3, x3, #0x630
    6e60:	f949d861 	ldr	x1, [x3, #5040]
    6e64:	f949ec62 	ldr	x2, [x3, #5080]
    6e68:	cb010001 	sub	x1, x0, x1
    6e6c:	eb02403f 	cmp	x1, x2, lsl #16
    6e70:	54ffff22 	b.cs	6e54 <fwp_caps173+0x4>  // b.hs, b.nlast
    6e74:	d350fc22 	lsr	x2, x1, #16
    6e78:	f949fc65 	ldr	x5, [x3, #5112]
    6e7c:	8b020842 	add	x2, x2, x2, lsl #2
    6e80:	d37df042 	lsl	x2, x2, #3
    6e84:	8b0200a4 	add	x4, x5, x2
    6e88:	f9401083 	ldr	x3, [x4, #32]
    6e8c:	b4fffe43 	cbz	x3, 6e54 <fwp_caps173+0x4>
    6e90:	386268a2 	ldrb	w2, [x5, x2]
    6e94:	7100085f 	cmp	w2, #0x2
    6e98:	540001c0 	b.eq	6ed0 <fwp_caps173+0x80>  // b.none
    6e9c:	7100045f 	cmp	w2, #0x1
    6ea0:	54fffda1 	b.ne	6e54 <fwp_caps173+0x4>  // b.any
    6ea4:	29430885 	ldp	w5, w2, [x4, #24]
    6ea8:	92403c21 	and	x1, x1, #0xffff
    6eac:	9b057c21 	mul	x1, x1, x5
    6eb0:	d360fc21 	lsr	x1, x1, #32
    6eb4:	eb02003f 	cmp	x1, x2
    6eb8:	54fffce2 	b.cs	6e54 <fwp_caps173+0x4>  // b.hs, b.nlast
    6ebc:	8b010063 	add	x3, x3, x1
    6ec0:	39400061 	ldrb	w1, [x3]
    6ec4:	7100043f 	cmp	w1, #0x1
    6ec8:	54fffc61 	b.ne	6e54 <fwp_caps173+0x4>  // b.any
    6ecc:	17fff771 	b	4c90 <fwp_mem_free>
    6ed0:	72003c3f 	tst	w1, #0xffff
    6ed4:	54ffff60 	b.eq	6ec0 <fwp_caps173+0x70>  // b.none
    6ed8:	d65f03c0 	ret
    6edc:	d503201f 	nop

0000000000006ee0 <fwp_args37>:
    6ee0:	7100003f 	cmp	w1, #0x0
    6ee4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6ee8:	54000041 	b.ne	6ef0 <fwp_args37+0x10>  // b.any
    6eec:	d65f03c0 	ret
    6ef0:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6ef4:	9118c042 	add	x2, x2, #0x630
    6ef8:	f9400001 	ldr	x1, [x0]
    6efc:	f949d843 	ldr	x3, [x2, #5040]
    6f00:	f949ec40 	ldr	x0, [x2, #5080]
    6f04:	cb030021 	sub	x1, x1, x3
    6f08:	eb00403f 	cmp	x1, x0, lsl #16
    6f0c:	54ffff02 	b.cs	6eec <fwp_args37+0xc>  // b.hs, b.nlast
    6f10:	d350fc20 	lsr	x0, x1, #16
    6f14:	f949fc44 	ldr	x4, [x2, #5112]
    6f18:	8b000800 	add	x0, x0, x0, lsl #2
    6f1c:	d37df002 	lsl	x2, x0, #3
    6f20:	8b020083 	add	x3, x4, x2
    6f24:	f9401060 	ldr	x0, [x3, #32]
    6f28:	b4fffe20 	cbz	x0, 6eec <fwp_args37+0xc>
    6f2c:	38626882 	ldrb	w2, [x4, x2]
    6f30:	7100085f 	cmp	w2, #0x2
    6f34:	54000320 	b.eq	6f98 <fwp_args37+0xb8>  // b.none
    6f38:	7100045f 	cmp	w2, #0x1
    6f3c:	54fffd81 	b.ne	6eec <fwp_args37+0xc>  // b.any
    6f40:	29430864 	ldp	w4, w2, [x3, #24]
    6f44:	92403c21 	and	x1, x1, #0xffff
    6f48:	9b047c21 	mul	x1, x1, x4
    6f4c:	d360fc21 	lsr	x1, x1, #32
    6f50:	eb02003f 	cmp	x1, x2
    6f54:	54fffcc2 	b.cs	6eec <fwp_args37+0xc>  // b.hs, b.nlast
    6f58:	8b010000 	add	x0, x0, x1
    6f5c:	39400001 	ldrb	w1, [x0]
    6f60:	34fffc61 	cbz	w1, 6eec <fwp_args37+0xc>
    6f64:	d00000c2 	adrp	x2, 20000 <__data_start>
    6f68:	91014042 	add	x2, x2, #0x50
    6f6c:	b9413043 	ldr	w3, [x2, #304]
    6f70:	350000c3 	cbnz	w3, 6f88 <fwp_args37+0xa8>
    6f74:	7103f43f 	cmp	w1, #0xfd
    6f78:	54000168 	b.hi	6fa4 <fwp_args37+0xc4>  // b.pmore
    6f7c:	11000421 	add	w1, w1, #0x1
    6f80:	39000001 	strb	w1, [x0]
    6f84:	d65f03c0 	ret
    6f88:	f940ac43 	ldr	x3, [x2, #344]
    6f8c:	91000463 	add	x3, x3, #0x1
    6f90:	f900ac43 	str	x3, [x2, #344]
    6f94:	17fffff8 	b	6f74 <fwp_args37+0x94>
    6f98:	72003c3f 	tst	w1, #0xffff
    6f9c:	54fffe00 	b.eq	6f5c <fwp_args37+0x7c>  // b.none
    6fa0:	d65f03c0 	ret
    6fa4:	17fff654 	b	48f4 <fwp_rc_wide_dup>
    6fa8:	d503201f 	nop
    6fac:	d503201f 	nop

0000000000006fb0 <fwp_caps37>:
    6fb0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6fb4:	910003fd 	mov	x29, sp
    6fb8:	f9000bf3 	str	x19, [sp, #16]
    6fbc:	aa0003f3 	mov	x19, x0
    6fc0:	b9400400 	ldr	w0, [x0, #4]
    6fc4:	340004a0 	cbz	w0, 7058 <fwp_caps37+0xa8>
    6fc8:	f9400660 	ldr	x0, [x19, #8]
    6fcc:	350004e1 	cbnz	w1, 7068 <fwp_caps37+0xb8>
    6fd0:	97fffd88 	bl	65f0 <fwp_drop4>
    6fd4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6fd8:	9118c042 	add	x2, x2, #0x630
    6fdc:	f949d840 	ldr	x0, [x2, #5040]
    6fe0:	f949ec41 	ldr	x1, [x2, #5080]
    6fe4:	cb000260 	sub	x0, x19, x0
    6fe8:	eb01401f 	cmp	x0, x1, lsl #16
    6fec:	54000382 	b.cs	705c <fwp_caps37+0xac>  // b.hs, b.nlast
    6ff0:	d350fc01 	lsr	x1, x0, #16
    6ff4:	f949fc44 	ldr	x4, [x2, #5112]
    6ff8:	8b010821 	add	x1, x1, x1, lsl #2
    6ffc:	d37df021 	lsl	x1, x1, #3
    7000:	8b010083 	add	x3, x4, x1
    7004:	f9401062 	ldr	x2, [x3, #32]
    7008:	b40002a2 	cbz	x2, 705c <fwp_caps37+0xac>
    700c:	38616881 	ldrb	w1, [x4, x1]
    7010:	7100083f 	cmp	w1, #0x2
    7014:	54000740 	b.eq	70fc <fwp_caps37+0x14c>  // b.none
    7018:	7100043f 	cmp	w1, #0x1
    701c:	54000201 	b.ne	705c <fwp_caps37+0xac>  // b.any
    7020:	29430464 	ldp	w4, w1, [x3, #24]
    7024:	92403c00 	and	x0, x0, #0xffff
    7028:	9b047c00 	mul	x0, x0, x4
    702c:	d360fc00 	lsr	x0, x0, #32
    7030:	eb01001f 	cmp	x0, x1
    7034:	54000142 	b.cs	705c <fwp_caps37+0xac>  // b.hs, b.nlast
    7038:	8b000042 	add	x2, x2, x0
    703c:	39400040 	ldrb	w0, [x2]
    7040:	7100041f 	cmp	w0, #0x1
    7044:	540000c1 	b.ne	705c <fwp_caps37+0xac>  // b.any
    7048:	aa1303e0 	mov	x0, x19
    704c:	f9400bf3 	ldr	x19, [sp, #16]
    7050:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7054:	17fff70f 	b	4c90 <fwp_mem_free>
    7058:	34fffbe1 	cbz	w1, 6fd4 <fwp_caps37+0x24>
    705c:	f9400bf3 	ldr	x19, [sp, #16]
    7060:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7064:	d65f03c0 	ret
    7068:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    706c:	9118c042 	add	x2, x2, #0x630
    7070:	f949d843 	ldr	x3, [x2, #5040]
    7074:	f949ec41 	ldr	x1, [x2, #5080]
    7078:	cb030000 	sub	x0, x0, x3
    707c:	eb01401f 	cmp	x0, x1, lsl #16
    7080:	54fffee2 	b.cs	705c <fwp_caps37+0xac>  // b.hs, b.nlast
    7084:	d350fc01 	lsr	x1, x0, #16
    7088:	f949fc44 	ldr	x4, [x2, #5112]
    708c:	8b010821 	add	x1, x1, x1, lsl #2
    7090:	d37df021 	lsl	x1, x1, #3
    7094:	8b010083 	add	x3, x4, x1
    7098:	f9401062 	ldr	x2, [x3, #32]
    709c:	b4fffe02 	cbz	x2, 705c <fwp_caps37+0xac>
    70a0:	38616881 	ldrb	w1, [x4, x1]
    70a4:	7100083f 	cmp	w1, #0x2
    70a8:	54000300 	b.eq	7108 <fwp_caps37+0x158>  // b.none
    70ac:	7100043f 	cmp	w1, #0x1
    70b0:	54fffd61 	b.ne	705c <fwp_caps37+0xac>  // b.any
    70b4:	92403c01 	and	x1, x0, #0xffff
    70b8:	29430064 	ldp	w4, w0, [x3, #24]
    70bc:	9b047c21 	mul	x1, x1, x4
    70c0:	d360fc21 	lsr	x1, x1, #32
    70c4:	eb00003f 	cmp	x1, x0
    70c8:	54fffca2 	b.cs	705c <fwp_caps37+0xac>  // b.hs, b.nlast
    70cc:	8b010042 	add	x2, x2, x1
    70d0:	39400040 	ldrb	w0, [x2]
    70d4:	34fffc40 	cbz	w0, 705c <fwp_caps37+0xac>
    70d8:	b00000c1 	adrp	x1, 20000 <__data_start>
    70dc:	91014021 	add	x1, x1, #0x50
    70e0:	b9413023 	ldr	w3, [x1, #304]
    70e4:	35000183 	cbnz	w3, 7114 <fwp_caps37+0x164>
    70e8:	7103f41f 	cmp	w0, #0xfd
    70ec:	540001c8 	b.hi	7124 <fwp_caps37+0x174>  // b.pmore
    70f0:	11000400 	add	w0, w0, #0x1
    70f4:	39000040 	strb	w0, [x2]
    70f8:	17ffffd9 	b	705c <fwp_caps37+0xac>
    70fc:	72003c1f 	tst	w0, #0xffff
    7100:	54fffae1 	b.ne	705c <fwp_caps37+0xac>  // b.any
    7104:	17ffffce 	b	703c <fwp_caps37+0x8c>
    7108:	72003c1f 	tst	w0, #0xffff
    710c:	54fffa81 	b.ne	705c <fwp_caps37+0xac>  // b.any
    7110:	17fffff0 	b	70d0 <fwp_caps37+0x120>
    7114:	f940ac23 	ldr	x3, [x1, #344]
    7118:	91000463 	add	x3, x3, #0x1
    711c:	f900ac23 	str	x3, [x1, #344]
    7120:	17fffff2 	b	70e8 <fwp_caps37+0x138>
    7124:	f9400bf3 	ldr	x19, [sp, #16]
    7128:	aa0203e0 	mov	x0, x2
    712c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7130:	17fff5f1 	b	48f4 <fwp_rc_wide_dup>

0000000000007134 <f37>:
    7134:	d101c3ff 	sub	sp, sp, #0x70
    7138:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    713c:	f947f421 	ldr	x1, [x1, #4072]
    7140:	a9027bfd 	stp	x29, x30, [sp, #32]
    7144:	910083fd 	add	x29, sp, #0x20
    7148:	a90563f7 	stp	x23, x24, [sp, #80]
    714c:	d0000397 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    7150:	9118c2e3 	add	x3, x23, #0x630
    7154:	a90353f3 	stp	x19, x20, [sp, #48]
    7158:	a9045bf5 	stp	x21, x22, [sp, #64]
    715c:	aa0003f6 	mov	x22, x0
    7160:	a9066bf9 	stp	x25, x26, [sp, #96]
    7164:	f949ec62 	ldr	x2, [x3, #5080]
    7168:	f9400024 	ldr	x4, [x1]
    716c:	f9000fe4 	str	x4, [sp, #24]
    7170:	d2800004 	mov	x4, #0x0                   	// #0
    7174:	f949d861 	ldr	x1, [x3, #5040]
    7178:	d370bc42 	lsl	x2, x2, #16
    717c:	b40016a0 	cbz	x0, 7450 <f37+0x31c>
    7180:	f9400818 	ldr	x24, [x0, #16]
    7184:	cb010301 	sub	x1, x24, x1
    7188:	eb02003f 	cmp	x1, x2
    718c:	540003e2 	b.cs	7208 <f37+0xd4>  // b.hs, b.nlast
    7190:	f949fc60 	ldr	x0, [x3, #5112]
    7194:	d350fc22 	lsr	x2, x1, #16
    7198:	8b020842 	add	x2, x2, x2, lsl #2
    719c:	8b020c02 	add	x2, x0, x2, lsl #3
    71a0:	f9401040 	ldr	x0, [x2, #32]
    71a4:	b4000320 	cbz	x0, 7208 <f37+0xd4>
    71a8:	39400043 	ldrb	w3, [x2]
    71ac:	7100087f 	cmp	w3, #0x2
    71b0:	54001420 	b.eq	7434 <f37+0x300>  // b.none
    71b4:	7100047f 	cmp	w3, #0x1
    71b8:	54000241 	b.ne	7200 <f37+0xcc>  // b.any
    71bc:	29430843 	ldp	w3, w2, [x2, #24]
    71c0:	92403c21 	and	x1, x1, #0xffff
    71c4:	9b037c21 	mul	x1, x1, x3
    71c8:	d360fc21 	lsr	x1, x1, #32
    71cc:	eb02003f 	cmp	x1, x2
    71d0:	54000182 	b.cs	7200 <f37+0xcc>  // b.hs, b.nlast
    71d4:	8b010000 	add	x0, x0, x1
    71d8:	39400001 	ldrb	w1, [x0]
    71dc:	34000121 	cbz	w1, 7200 <f37+0xcc>
    71e0:	b00000c2 	adrp	x2, 20000 <__data_start>
    71e4:	91014042 	add	x2, x2, #0x50
    71e8:	b9413043 	ldr	w3, [x2, #304]
    71ec:	350012a3 	cbnz	w3, 7440 <f37+0x30c>
    71f0:	7103f43f 	cmp	w1, #0xfd
    71f4:	54001708 	b.hi	74d4 <f37+0x3a0>  // b.pmore
    71f8:	11000421 	add	w1, w1, #0x1
    71fc:	39000001 	strb	w1, [x0]
    7200:	d2800000 	mov	x0, #0x0                   	// #0
    7204:	b40000d6 	cbz	x22, 721c <f37+0xe8>
    7208:	aa1603e1 	mov	x1, x22
    720c:	d2800000 	mov	x0, #0x0                   	// #0
    7210:	f9400821 	ldr	x1, [x1, #16]
    7214:	91000400 	add	x0, x0, #0x1
    7218:	b5ffffc1 	cbnz	x1, 7210 <f37+0xdc>
    721c:	b4001238 	cbz	x24, 7460 <f37+0x32c>
    7220:	aa1803e1 	mov	x1, x24
    7224:	d2800002 	mov	x2, #0x0                   	// #0
    7228:	f9400821 	ldr	x1, [x1, #16]
    722c:	91000442 	add	x2, x2, #0x1
    7230:	b5ffffc1 	cbnz	x1, 7228 <f37+0xf4>
    7234:	eb00005f 	cmp	x2, x0
    7238:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    723c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    7240:	eb01033f 	cmp	x25, x1
    7244:	540014e8 	b.hi	74e0 <f37+0x3ac>  // b.pmore
    7248:	d37ffb33 	lsl	x19, x25, #1
    724c:	52800041 	mov	w1, #0x2                   	// #2
    7250:	91000660 	add	x0, x19, #0x1
    7254:	d37df000 	lsl	x0, x0, #3
    7258:	97fff7ae 	bl	5110 <fwp_heap_alloc>
    725c:	9118c2e1 	add	x1, x23, #0x630
    7260:	aa0003fa 	mov	x26, x0
    7264:	f9000013 	str	x19, [x0]
    7268:	aa0103e0 	mov	x0, x1
    726c:	f949d821 	ldr	x1, [x1, #5040]
    7270:	f949ec00 	ldr	x0, [x0, #5080]
    7274:	cb010341 	sub	x1, x26, x1
    7278:	eb00403f 	cmp	x1, x0, lsl #16
    727c:	54000342 	b.cs	72e4 <f37+0x1b0>  // b.hs, b.nlast
    7280:	9118c2e2 	add	x2, x23, #0x630
    7284:	d350fc20 	lsr	x0, x1, #16
    7288:	8b000800 	add	x0, x0, x0, lsl #2
    728c:	f949fc43 	ldr	x3, [x2, #5112]
    7290:	d37df002 	lsl	x2, x0, #3
    7294:	8b020060 	add	x0, x3, x2
    7298:	f9401013 	ldr	x19, [x0, #32]
    729c:	b4000253 	cbz	x19, 72e4 <f37+0x1b0>
    72a0:	38626862 	ldrb	w2, [x3, x2]
    72a4:	7100085f 	cmp	w2, #0x2
    72a8:	54000c00 	b.eq	7428 <f37+0x2f4>  // b.none
    72ac:	7100045f 	cmp	w2, #0x1
    72b0:	540001a1 	b.ne	72e4 <f37+0x1b0>  // b.any
    72b4:	29430002 	ldp	w2, w0, [x0, #24]
    72b8:	92403c21 	and	x1, x1, #0xffff
    72bc:	9b027c21 	mul	x1, x1, x2
    72c0:	d360fc21 	lsr	x1, x1, #32
    72c4:	eb00003f 	cmp	x1, x0
    72c8:	540000e2 	b.cs	72e4 <f37+0x1b0>  // b.hs, b.nlast
    72cc:	8b010273 	add	x19, x19, x1
    72d0:	39400260 	ldrb	w0, [x19]
    72d4:	7103fc1f 	cmp	w0, #0xff
    72d8:	54000e80 	b.eq	74a8 <f37+0x374>  // b.none
    72dc:	52800020 	mov	w0, #0x1                   	// #1
    72e0:	39000260 	strb	w0, [x19]
    72e4:	b4000259 	cbz	x25, 732c <f37+0x1f8>
    72e8:	8b191359 	add	x25, x26, x25, lsl #4
    72ec:	aa1a03f3 	mov	x19, x26
    72f0:	aa1603f5 	mov	x21, x22
    72f4:	aa1803f4 	mov	x20, x24
    72f8:	f9400683 	ldr	x3, [x20, #8]
    72fc:	f94006a2 	ldr	x2, [x21, #8]
    7300:	f9400861 	ldr	x1, [x3, #16]
    7304:	f9400840 	ldr	x0, [x2, #16]
    7308:	fd400461 	ldr	d1, [x3, #8]
    730c:	fd400440 	ldr	d0, [x2, #8]
    7310:	97fff924 	bl	57a0 <w120>
    7314:	f9000660 	str	x0, [x19, #8]
    7318:	f8010e61 	str	x1, [x19, #16]!
    731c:	f9400a94 	ldr	x20, [x20, #16]
    7320:	f9400ab5 	ldr	x21, [x21, #16]
    7324:	eb13033f 	cmp	x25, x19
    7328:	54fffe81 	b.ne	72f8 <f37+0x1c4>  // b.any
    732c:	aa1803e0 	mov	x0, x24
    7330:	97fffcb0 	bl	65f0 <fwp_drop4>
    7334:	aa1603e0 	mov	x0, x22
    7338:	97fffcae 	bl	65f0 <fwp_drop4>
    733c:	9118c2f7 	add	x23, x23, #0x630
    7340:	aa1a03e0 	mov	x0, x26
    7344:	97fff974 	bl	5914 <w176.constprop.0>
    7348:	aa0103f3 	mov	x19, x1
    734c:	aa0003f4 	mov	x20, x0
    7350:	aa1a03e0 	mov	x0, x26
    7354:	97fffe43 	bl	6c60 <fwp_drop10>
    7358:	a900cff4 	stp	x20, x19, [sp, #8]
    735c:	910023e1 	add	x1, sp, #0x8
    7360:	52800000 	mov	w0, #0x0                   	// #0
    7364:	97fff7cc 	bl	5294 <fwp_data.part.0.constprop.0>
    7368:	f949dae1 	ldr	x1, [x23, #5040]
    736c:	aa0003f3 	mov	x19, x0
    7370:	f949eee0 	ldr	x0, [x23, #5080]
    7374:	cb010261 	sub	x1, x19, x1
    7378:	eb00403f 	cmp	x1, x0, lsl #16
    737c:	54000322 	b.cs	73e0 <f37+0x2ac>  // b.hs, b.nlast
    7380:	d350fc22 	lsr	x2, x1, #16
    7384:	f949fee3 	ldr	x3, [x23, #5112]
    7388:	8b020842 	add	x2, x2, x2, lsl #2
    738c:	d37df042 	lsl	x2, x2, #3
    7390:	8b020060 	add	x0, x3, x2
    7394:	f9401014 	ldr	x20, [x0, #32]
    7398:	b4000254 	cbz	x20, 73e0 <f37+0x2ac>
    739c:	38626862 	ldrb	w2, [x3, x2]
    73a0:	7100085f 	cmp	w2, #0x2
    73a4:	540003c0 	b.eq	741c <f37+0x2e8>  // b.none
    73a8:	7100045f 	cmp	w2, #0x1
    73ac:	540001a1 	b.ne	73e0 <f37+0x2ac>  // b.any
    73b0:	29430002 	ldp	w2, w0, [x0, #24]
    73b4:	92403c21 	and	x1, x1, #0xffff
    73b8:	9b027c21 	mul	x1, x1, x2
    73bc:	d360fc21 	lsr	x1, x1, #32
    73c0:	eb00003f 	cmp	x1, x0
    73c4:	540000e2 	b.cs	73e0 <f37+0x2ac>  // b.hs, b.nlast
    73c8:	8b010294 	add	x20, x20, x1
    73cc:	39400280 	ldrb	w0, [x20]
    73d0:	7103fc1f 	cmp	w0, #0xff
    73d4:	54000640 	b.eq	749c <f37+0x368>  // b.none
    73d8:	52800020 	mov	w0, #0x1                   	// #1
    73dc:	39000280 	strb	w0, [x20]
    73e0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    73e4:	f947f400 	ldr	x0, [x0, #4072]
    73e8:	f9400fe2 	ldr	x2, [sp, #24]
    73ec:	f9400001 	ldr	x1, [x0]
    73f0:	eb010042 	subs	x2, x2, x1
    73f4:	d2800001 	mov	x1, #0x0                   	// #0
    73f8:	54000721 	b.ne	74dc <f37+0x3a8>  // b.any
    73fc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    7400:	aa1303e0 	mov	x0, x19
    7404:	a94353f3 	ldp	x19, x20, [sp, #48]
    7408:	a9445bf5 	ldp	x21, x22, [sp, #64]
    740c:	a94563f7 	ldp	x23, x24, [sp, #80]
    7410:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7414:	9101c3ff 	add	sp, sp, #0x70
    7418:	d65f03c0 	ret
    741c:	72003c3f 	tst	w1, #0xffff
    7420:	54fffe01 	b.ne	73e0 <f37+0x2ac>  // b.any
    7424:	17ffffea 	b	73cc <f37+0x298>
    7428:	72003c3f 	tst	w1, #0xffff
    742c:	54fff5c1 	b.ne	72e4 <f37+0x1b0>  // b.any
    7430:	17ffffa8 	b	72d0 <f37+0x19c>
    7434:	72003c3f 	tst	w1, #0xffff
    7438:	54ffee41 	b.ne	7200 <f37+0xcc>  // b.any
    743c:	17ffff67 	b	71d8 <f37+0xa4>
    7440:	f940ac43 	ldr	x3, [x2, #344]
    7444:	91000463 	add	x3, x3, #0x1
    7448:	f900ac43 	str	x3, [x2, #344]
    744c:	17ffff69 	b	71f0 <f37+0xbc>
    7450:	cb0103e1 	neg	x1, x1
    7454:	eb02003f 	cmp	x1, x2
    7458:	540002e3 	b.cc	74b4 <f37+0x380>  // b.lo, b.ul, b.last
    745c:	d503201f 	nop
    7460:	52800041 	mov	w1, #0x2                   	// #2
    7464:	d2800100 	mov	x0, #0x8                   	// #8
    7468:	97fff72a 	bl	5110 <fwp_heap_alloc>
    746c:	aa0003e1 	mov	x1, x0
    7470:	9118c2e0 	add	x0, x23, #0x630
    7474:	aa0103fa 	mov	x26, x1
    7478:	d2800018 	mov	x24, #0x0                   	// #0
    747c:	f900003f 	str	xzr, [x1]
    7480:	f949d801 	ldr	x1, [x0, #5040]
    7484:	f949ec00 	ldr	x0, [x0, #5080]
    7488:	cb010341 	sub	x1, x26, x1
    748c:	eb00403f 	cmp	x1, x0, lsl #16
    7490:	54fff4e2 	b.cs	732c <f37+0x1f8>  // b.hs, b.nlast
    7494:	d2800019 	mov	x25, #0x0                   	// #0
    7498:	17ffff7a 	b	7280 <f37+0x14c>
    749c:	aa1403e0 	mov	x0, x20
    74a0:	97fff55c 	bl	4a10 <fwp_rc_forget_slot>
    74a4:	17ffffcd 	b	73d8 <f37+0x2a4>
    74a8:	aa1303e0 	mov	x0, x19
    74ac:	97fff559 	bl	4a10 <fwp_rc_forget_slot>
    74b0:	17ffff8b 	b	72dc <f37+0x1a8>
    74b4:	f949fc62 	ldr	x2, [x3, #5112]
    74b8:	d350fc20 	lsr	x0, x1, #16
    74bc:	8b000800 	add	x0, x0, x0, lsl #2
    74c0:	8b000c42 	add	x2, x2, x0, lsl #3
    74c4:	f9401040 	ldr	x0, [x2, #32]
    74c8:	b4fffcc0 	cbz	x0, 7460 <f37+0x32c>
    74cc:	d2800018 	mov	x24, #0x0                   	// #0
    74d0:	17ffff36 	b	71a8 <f37+0x74>
    74d4:	97fff508 	bl	48f4 <fwp_rc_wide_dup>
    74d8:	17ffff4a 	b	7200 <f37+0xcc>
    74dc:	97ffecf1 	bl	28a0 <__stack_chk_fail@plt>
    74e0:	d0000020 	adrp	x0, d000 <__divti3+0x2b0>
    74e4:	9129c000 	add	x0, x0, #0xa70
    74e8:	97fff0c6 	bl	3800 <fwp_trap>
    74ec:	d503201f 	nop

00000000000074f0 <fwp_owned_entry37>:
    74f0:	f9400000 	ldr	x0, [x0]
    74f4:	17ffff10 	b	7134 <f37>
    74f8:	d503201f 	nop
    74fc:	d503201f 	nop

0000000000007500 <e37>:
    7500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7504:	910003fd 	mov	x29, sp
    7508:	f9000bf3 	str	x19, [sp, #16]
    750c:	f9400013 	ldr	x19, [x0]
    7510:	aa1303e0 	mov	x0, x19
    7514:	97fff928 	bl	59b4 <fwp_rc_share>
    7518:	aa1303e0 	mov	x0, x19
    751c:	97ffff06 	bl	7134 <f37>
    7520:	aa0003f3 	mov	x19, x0
    7524:	97fff924 	bl	59b4 <fwp_rc_share>
    7528:	aa1303e0 	mov	x0, x19
    752c:	f9400bf3 	ldr	x19, [sp, #16]
    7530:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7534:	d65f03c0 	ret
    7538:	d503201f 	nop
    753c:	d503201f 	nop

0000000000007540 <fwp_write>:
    7540:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    7544:	910003fd 	mov	x29, sp
    7548:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    754c:	f947f484 	ldr	x4, [x4, #4072]
    7550:	a90153f3 	stp	x19, x20, [sp, #16]
    7554:	d10943ff 	sub	sp, sp, #0x250
    7558:	b9400045 	ldr	w5, [x2]
    755c:	aa0003f4 	mov	x20, x0
    7560:	f9400080 	ldr	x0, [x4]
    7564:	f90127e0 	str	x0, [sp, #584]
    7568:	d2800000 	mov	x0, #0x0                   	// #0
    756c:	710064bf 	cmp	w5, #0x19
    7570:	54000408 	b.hi	75f0 <fwp_write+0xb0>  // b.pmore
    7574:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0xb90>
    7578:	aa0103f3 	mov	x19, x1
    757c:	910f0000 	add	x0, x0, #0x3c0
    7580:	f9013bf5 	str	x21, [sp, #624]
    7584:	f9013ff6 	str	x22, [sp, #632]
    7588:	f90153fb 	str	x27, [sp, #672]
    758c:	f90157fc 	str	x28, [sp, #680]
    7590:	aa0203fc 	mov	x28, x2
    7594:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    7598:	10000061 	adr	x1, 75a4 <fwp_write+0x64>
    759c:	8b20a820 	add	x0, x1, w0, sxth #2
    75a0:	d61f0000 	br	x0
    75a4:	910123e0 	add	x0, sp, #0x48
    75a8:	aa1303e5 	mov	x5, x19
    75ac:	d0000024 	adrp	x4, d000 <__divti3+0x2b0>
    75b0:	aa0003f3 	mov	x19, x0
    75b4:	912ae084 	add	x4, x4, #0xab8
    75b8:	d2804003 	mov	x3, #0x200                 	// #512
    75bc:	aa0303e1 	mov	x1, x3
    75c0:	52800042 	mov	w2, #0x2                   	// #2
    75c4:	97ffec93 	bl	2810 <__snprintf_chk@plt>
    75c8:	aa1303e0 	mov	x0, x19
    75cc:	97ffec59 	bl	2730 <strlen@plt>
    75d0:	aa1303e1 	mov	x1, x19
    75d4:	aa0003e2 	mov	x2, x0
    75d8:	aa1403e0 	mov	x0, x20
    75dc:	97fff02d 	bl	3690 <buf_put>
    75e0:	f9413bf5 	ldr	x21, [sp, #624]
    75e4:	f9413ff6 	ldr	x22, [sp, #632]
    75e8:	f94153fb 	ldr	x27, [sp, #672]
    75ec:	f94157fc 	ldr	x28, [sp, #680]
    75f0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    75f4:	f947f400 	ldr	x0, [x0, #4072]
    75f8:	f94127e2 	ldr	x2, [sp, #584]
    75fc:	f9400001 	ldr	x1, [x0]
    7600:	eb010042 	subs	x2, x2, x1
    7604:	d2800001 	mov	x1, #0x0                   	// #0
    7608:	540077c1 	b.ne	8500 <fwp_write+0xfc0>  // b.any
    760c:	910943ff 	add	sp, sp, #0x250
    7610:	a94153f3 	ldp	x19, x20, [sp, #16]
    7614:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7618:	d65f03c0 	ret
    761c:	910123e0 	add	x0, sp, #0x48
    7620:	aa1303e5 	mov	x5, x19
    7624:	d0000024 	adrp	x4, d000 <__divti3+0x2b0>
    7628:	aa0003f3 	mov	x19, x0
    762c:	912ac084 	add	x4, x4, #0xab0
    7630:	d2804003 	mov	x3, #0x200                 	// #512
    7634:	17ffffe2 	b	75bc <fwp_write+0x7c>
    7638:	71004cbf 	cmp	w5, #0x13
    763c:	d0000020 	adrp	x0, d000 <__divti3+0x2b0>
    7640:	d0000021 	adrp	x1, d000 <__divti3+0x2b0>
    7644:	912a8000 	add	x0, x0, #0xaa0
    7648:	912aa021 	add	x1, x1, #0xaa8
    764c:	d2800082 	mov	x2, #0x4                   	// #4
    7650:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    7654:	aa1403e0 	mov	x0, x20
    7658:	f90143f7 	str	x23, [sp, #640]
    765c:	d2800016 	mov	x22, #0x0                   	// #0
    7660:	f90147f8 	str	x24, [sp, #648]
    7664:	97fff00b 	bl	3690 <buf_put>
    7668:	f9400260 	ldr	x0, [x19]
    766c:	d0000037 	adrp	x23, d000 <__divti3+0x2b0>
    7670:	d2800015 	mov	x21, #0x0                   	// #0
    7674:	912ca2f7 	add	x23, x23, #0xb28
    7678:	b40047a0 	cbz	x0, 7f6c <fwp_write+0xa2c>
    767c:	b9400380 	ldr	w0, [x28]
    7680:	52800003 	mov	w3, #0x0                   	// #0
    7684:	f9401f82 	ldr	x2, [x28, #56]
    7688:	71004c1f 	cmp	w0, #0x13
    768c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7690:	aa1403e0 	mov	x0, x20
    7694:	8b010e61 	add	x1, x19, x1, lsl #3
    7698:	f9400421 	ldr	x1, [x1, #8]
    769c:	97ffffa9 	bl	7540 <fwp_write>
    76a0:	b9400380 	ldr	w0, [x28]
    76a4:	7100481f 	cmp	w0, #0x12
    76a8:	54004b40 	b.eq	8010 <fwp_write+0xad0>  // b.none
    76ac:	f9400260 	ldr	x0, [x19]
    76b0:	910006b5 	add	x21, x21, #0x1
    76b4:	91000ad6 	add	x22, x22, #0x2
    76b8:	eb15001f 	cmp	x0, x21
    76bc:	54004589 	b.ls	7f6c <fwp_write+0xa2c>  // b.plast
    76c0:	aa1703e1 	mov	x1, x23
    76c4:	aa1403e0 	mov	x0, x20
    76c8:	d2800042 	mov	x2, #0x2                   	// #2
    76cc:	97ffeff1 	bl	3690 <buf_put>
    76d0:	17ffffeb 	b	767c <fwp_write+0x13c>
    76d4:	d0000021 	adrp	x1, d000 <__divti3+0x2b0>
    76d8:	912b8021 	add	x1, x1, #0xae0
    76dc:	d28000c2 	mov	x2, #0x6                   	// #6
    76e0:	aa1403e0 	mov	x0, x20
    76e4:	91004273 	add	x19, x19, #0x10
    76e8:	97ffefea 	bl	3690 <buf_put>
    76ec:	aa1303e0 	mov	x0, x19
    76f0:	97ffec10 	bl	2730 <strlen@plt>
    76f4:	aa1303e1 	mov	x1, x19
    76f8:	aa0003e2 	mov	x2, x0
    76fc:	aa1403e0 	mov	x0, x20
    7700:	97ffefe4 	bl	3690 <buf_put>
    7704:	528007c3 	mov	w3, #0x3e                  	// #62
    7708:	aa1403e0 	mov	x0, x20
    770c:	91001fe1 	add	x1, sp, #0x7
    7710:	d2800022 	mov	x2, #0x1                   	// #1
    7714:	39001fe3 	strb	w3, [sp, #7]
    7718:	17ffffb1 	b	75dc <fwp_write+0x9c>
    771c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7720:	f947f400 	ldr	x0, [x0, #4072]
    7724:	f94127e2 	ldr	x2, [sp, #584]
    7728:	f9400001 	ldr	x1, [x0]
    772c:	eb010042 	subs	x2, x2, x1
    7730:	d2800001 	mov	x1, #0x0                   	// #0
    7734:	540034e1 	b.ne	7dd0 <fwp_write+0x890>  // b.any
    7738:	f9413bf5 	ldr	x21, [sp, #624]
    773c:	d0000021 	adrp	x1, d000 <__divti3+0x2b0>
    7740:	f9413ff6 	ldr	x22, [sp, #632]
    7744:	aa1403e0 	mov	x0, x20
    7748:	912b0021 	add	x1, x1, #0xac0
    774c:	d2800142 	mov	x2, #0xa                   	// #10
    7750:	f94153fb 	ldr	x27, [sp, #672]
    7754:	f94157fc 	ldr	x28, [sp, #680]
    7758:	910943ff 	add	sp, sp, #0x250
    775c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7760:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7764:	17ffefcb 	b	3690 <buf_put>
    7768:	f9400456 	ldr	x22, [x2, #8]
    776c:	f90143f7 	str	x23, [sp, #640]
    7770:	f90147f8 	str	x24, [sp, #648]
    7774:	b4005b16 	cbz	x22, 82d4 <fwp_write+0xd94>
    7778:	aa1603e0 	mov	x0, x22
    777c:	d0000021 	adrp	x1, d000 <__divti3+0x2b0>
    7780:	912d0021 	add	x1, x1, #0xb40
    7784:	97ffec67 	bl	2920 <strcmp@plt>
    7788:	2a0003f5 	mov	w21, w0
    778c:	34005fe0 	cbz	w0, 8388 <fwp_write+0xe48>
    7790:	aa1603e0 	mov	x0, x22
    7794:	97ffebe7 	bl	2730 <strlen@plt>
    7798:	aa1603e1 	mov	x1, x22
    779c:	aa0003e2 	mov	x2, x0
    77a0:	aa1403e0 	mov	x0, x20
    77a4:	97ffefbb 	bl	3690 <buf_put>
    77a8:	52800403 	mov	w3, #0x20                  	// #32
    77ac:	91001ff5 	add	x21, sp, #0x7
    77b0:	aa1503e1 	mov	x1, x21
    77b4:	aa1403e0 	mov	x0, x20
    77b8:	d2800022 	mov	x2, #0x1                   	// #1
    77bc:	39001fe3 	strb	w3, [sp, #7]
    77c0:	97ffefb4 	bl	3690 <buf_put>
    77c4:	52800f63 	mov	w3, #0x7b                  	// #123
    77c8:	aa1403e0 	mov	x0, x20
    77cc:	aa1503e1 	mov	x1, x21
    77d0:	d2800022 	mov	x2, #0x1                   	// #1
    77d4:	39001fe3 	strb	w3, [sp, #7]
    77d8:	97ffefae 	bl	3690 <buf_put>
    77dc:	b9401380 	ldr	w0, [x28, #16]
    77e0:	52800018 	mov	w24, #0x0                   	// #0
    77e4:	7100001f 	cmp	w0, #0x0
    77e8:	54003aad 	b.le	7f3c <fwp_write+0x9fc>
    77ec:	f9014bf9 	str	x25, [sp, #656]
    77f0:	d0000039 	adrp	x25, d000 <__divti3+0x2b0>
    77f4:	912da339 	add	x25, x25, #0xb68
    77f8:	f9014ffa 	str	x26, [sp, #664]
    77fc:	d000003a 	adrp	x26, d000 <__divti3+0x2b0>
    7800:	912ca35a 	add	x26, x26, #0xb28
    7804:	91002276 	add	x22, x19, #0x8
    7808:	d2800013 	mov	x19, #0x0                   	// #0
    780c:	b5003e93 	cbnz	x19, 7fdc <fwp_write+0xa9c>
    7810:	d37df277 	lsl	x23, x19, #3
    7814:	34003cb8 	cbz	w24, 7fa8 <fwp_write+0xa68>
    7818:	f9401382 	ldr	x2, [x28, #32]
    781c:	aa1403e0 	mov	x0, x20
    7820:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7824:	52800003 	mov	w3, #0x0                   	// #0
    7828:	f8776842 	ldr	x2, [x2, x23]
    782c:	91000673 	add	x19, x19, #0x1
    7830:	97ffff44 	bl	7540 <fwp_write>
    7834:	b9401380 	ldr	w0, [x28, #16]
    7838:	6b13001f 	cmp	w0, w19
    783c:	54fffe8c 	b.gt	780c <fwp_write+0x2cc>
    7840:	f9414bf9 	ldr	x25, [sp, #656]
    7844:	f9414ffa 	ldr	x26, [sp, #664]
    7848:	340037b8 	cbz	w24, 7f3c <fwp_write+0x9fc>
    784c:	52800523 	mov	w3, #0x29                  	// #41
    7850:	aa1503e1 	mov	x1, x21
    7854:	aa1403e0 	mov	x0, x20
    7858:	d2800022 	mov	x2, #0x1                   	// #1
    785c:	39001fe3 	strb	w3, [sp, #7]
    7860:	97ffef8c 	bl	3690 <buf_put>
    7864:	f9413bf5 	ldr	x21, [sp, #624]
    7868:	f9413ff6 	ldr	x22, [sp, #632]
    786c:	f94143f7 	ldr	x23, [sp, #640]
    7870:	f94147f8 	ldr	x24, [sp, #648]
    7874:	f94153fb 	ldr	x27, [sp, #672]
    7878:	f94157fc 	ldr	x28, [sp, #680]
    787c:	17ffff5d 	b	75f0 <fwp_write+0xb0>
    7880:	b9404855 	ldr	w21, [x2, #72]
    7884:	aa1403e0 	mov	x0, x20
    7888:	93407eb6 	sxtw	x22, w21
    788c:	91000ac1 	add	x1, x22, #0x2
    7890:	97ffef4c 	bl	35c0 <buf_grow>
    7894:	a9400281 	ldp	x1, x0, [x20]
    7898:	528e8603 	mov	w3, #0x7430                	// #29744
    789c:	78206823 	strh	w3, [x1, x0]
    78a0:	8b000022 	add	x2, x1, x0
    78a4:	710002bf 	cmp	w21, #0x0
    78a8:	540036cd 	b.le	7f80 <fwp_write+0xa40>
    78ac:	110006a3 	add	w3, w21, #0x1
    78b0:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    78b4:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    78b8:	91000449 	add	x9, x2, #0x1
    78bc:	8b23c043 	add	x3, x2, w3, sxtw
    78c0:	f28aaac6 	movk	x6, #0x5556
    78c4:	f2955568 	movk	x8, #0xaaab
    78c8:	1400000d 	b	78fc <fwp_write+0x3bc>
    78cc:	d2800021 	mov	x1, #0x1                   	// #1
    78d0:	528005a5 	mov	w5, #0x2d                  	// #45
    78d4:	f100001f 	cmp	x0, #0x0
    78d8:	9b467e60 	smulh	x0, x19, x6
    78dc:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    78e0:	381ff465 	strb	w5, [x3], #-1
    78e4:	cb040000 	sub	x0, x0, x4
    78e8:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    78ec:	cb020000 	sub	x0, x0, x2
    78f0:	8b010013 	add	x19, x0, x1
    78f4:	eb03013f 	cmp	x9, x3
    78f8:	54003440 	b.eq	7f80 <fwp_write+0xa40>  // b.none
    78fc:	9b467e60 	smulh	x0, x19, x6
    7900:	937ffe64 	asr	x4, x19, #63
    7904:	52800605 	mov	w5, #0x30                  	// #48
    7908:	cb040000 	sub	x0, x0, x4
    790c:	8b000400 	add	x0, x0, x0, lsl #1
    7910:	cb000260 	sub	x0, x19, x0
    7914:	91000c01 	add	x1, x0, #0x3
    7918:	9bc87c22 	umulh	x2, x1, x8
    791c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7920:	8b4204e2 	add	x2, x7, x2, lsr #1
    7924:	eb020021 	subs	x1, x1, x2
    7928:	54fffd60 	b.eq	78d4 <fwp_write+0x394>  // b.none
    792c:	f100043f 	cmp	x1, #0x1
    7930:	54fffce1 	b.ne	78cc <fwp_write+0x38c>  // b.any
    7934:	d2800001 	mov	x1, #0x0                   	// #0
    7938:	52800565 	mov	w5, #0x2b                  	// #43
    793c:	17ffffe6 	b	78d4 <fwp_write+0x394>
    7940:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7944:	f947f400 	ldr	x0, [x0, #4072]
    7948:	f94127e2 	ldr	x2, [sp, #584]
    794c:	f9400001 	ldr	x1, [x0]
    7950:	eb010042 	subs	x2, x2, x1
    7954:	d2800001 	mov	x1, #0x0                   	// #0
    7958:	540023c1 	b.ne	7dd0 <fwp_write+0x890>  // b.any
    795c:	f9413bf5 	ldr	x21, [sp, #624]
    7960:	d0000021 	adrp	x1, d000 <__divti3+0x2b0>
    7964:	f9413ff6 	ldr	x22, [sp, #632]
    7968:	aa1403e0 	mov	x0, x20
    796c:	912b4021 	add	x1, x1, #0xad0
    7970:	d2800102 	mov	x2, #0x8                   	// #8
    7974:	17ffff77 	b	7750 <fwp_write+0x210>
    7978:	aa1403e0 	mov	x0, x20
    797c:	d0000021 	adrp	x1, d000 <__divti3+0x2b0>
    7980:	d28000c2 	mov	x2, #0x6                   	// #6
    7984:	912cc021 	add	x1, x1, #0xb30
    7988:	97ffef42 	bl	3690 <buf_put>
    798c:	d2800015 	mov	x21, #0x0                   	// #0
    7990:	f9400263 	ldr	x3, [x19]
    7994:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7998:	54002c60 	b.eq	7f24 <fwp_write+0x9e4>  // b.none
    799c:	f9401f82 	ldr	x2, [x28, #56]
    79a0:	f90143f7 	str	x23, [sp, #640]
    79a4:	f90147f8 	str	x24, [sp, #648]
    79a8:	d2800857 	mov	x23, #0x42                  	// #66
    79ac:	f9014bf9 	str	x25, [sp, #656]
    79b0:	d0000036 	adrp	x22, d000 <__divti3+0x2b0>
    79b4:	f9014ffa 	str	x26, [sp, #664]
    79b8:	912ca2d6 	add	x22, x22, #0xb28
    79bc:	d2800038 	mov	x24, #0x1                   	// #1
    79c0:	f2a18017 	movk	x23, #0xc00, lsl #16
    79c4:	d2809099 	mov	x25, #0x484                 	// #1156
    79c8:	b40004a2 	cbz	x2, 7a5c <fwp_write+0x51c>
    79cc:	b9400040 	ldr	w0, [x2]
    79d0:	7100701f 	cmp	w0, #0x1c
    79d4:	540042c0 	b.eq	822c <fwp_write+0xcec>  // b.none
    79d8:	71006c1f 	cmp	w0, #0x1b
    79dc:	54000408 	b.hi	7a5c <fwp_write+0x51c>  // b.pmore
    79e0:	9ac02301 	lsl	x1, x24, x0
    79e4:	ea17003f 	tst	x1, x23
    79e8:	540036a1 	b.ne	80bc <fwp_write+0xb7c>  // b.any
    79ec:	ea19003f 	tst	x1, x25
    79f0:	54003521 	b.ne	8094 <fwp_write+0xb54>  // b.any
    79f4:	d2800424 	mov	x4, #0x21                  	// #33
    79f8:	ea04003f 	tst	x1, x4
    79fc:	54000300 	b.eq	7a5c <fwp_write+0x51c>  // b.none
    7a00:	b7f849c3 	tbnz	x3, #63, 8338 <fwp_write+0xdf8>
    7a04:	91002261 	add	x1, x19, #0x8
    7a08:	8b150021 	add	x1, x1, x21
    7a0c:	39400021 	ldrb	w1, [x1]
    7a10:	7100001f 	cmp	w0, #0x0
    7a14:	93401c23 	sxtb	x3, w1
    7a18:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7a1c:	d503201f 	nop
    7a20:	aa1403e0 	mov	x0, x20
    7a24:	52800003 	mov	w3, #0x0                   	// #0
    7a28:	97fffec6 	bl	7540 <fwp_write>
    7a2c:	910006b5 	add	x21, x21, #0x1
    7a30:	f9400260 	ldr	x0, [x19]
    7a34:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7a38:	eb0002bf 	cmp	x21, x0
    7a3c:	540026c2 	b.cs	7f14 <fwp_write+0x9d4>  // b.hs, b.nlast
    7a40:	d2800042 	mov	x2, #0x2                   	// #2
    7a44:	aa1603e1 	mov	x1, x22
    7a48:	aa1403e0 	mov	x0, x20
    7a4c:	97ffef11 	bl	3690 <buf_put>
    7a50:	f9401f82 	ldr	x2, [x28, #56]
    7a54:	f9400263 	ldr	x3, [x19]
    7a58:	b5fffba2 	cbnz	x2, 79cc <fwp_write+0x48c>
    7a5c:	d37df2a0 	lsl	x0, x21, #3
    7a60:	b7f83f03 	tbnz	x3, #63, 8240 <fwp_write+0xd00>
    7a64:	91002261 	add	x1, x19, #0x8
    7a68:	8b000020 	add	x0, x1, x0
    7a6c:	f9400001 	ldr	x1, [x0]
    7a70:	17ffffec 	b	7a20 <fwp_write+0x4e0>
    7a74:	a9400e62 	ldp	x2, x3, [x19]
    7a78:	b7f83ca3 	tbnz	x3, #63, 820c <fwp_write+0xccc>
    7a7c:	910123f5 	add	x21, sp, #0x48
    7a80:	aa1503e0 	mov	x0, x21
    7a84:	97ffece7 	bl	2e20 <fwp_fmt_u128>
    7a88:	aa1503e0 	mov	x0, x21
    7a8c:	97ffeb29 	bl	2730 <strlen@plt>
    7a90:	aa1503e1 	mov	x1, x21
    7a94:	aa0003e2 	mov	x2, x0
    7a98:	17fffed0 	b	75d8 <fwp_write+0x98>
    7a9c:	fd015be8 	str	d8, [sp, #688]
    7aa0:	1e270268 	fmov	s8, w19
    7aa4:	fd015fe9 	str	d9, [sp, #696]
    7aa8:	1e282100 	fcmp	s8, s8
    7aac:	54004d26 	b.vs	8450 <fwp_write+0xf10>
    7ab0:	1e20c101 	fabs	s1, s8
    7ab4:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7ab8:	1e270000 	fmov	s0, w0
    7abc:	1e202020 	fcmp	s1, s0
    7ac0:	54002c0d 	b.le	8040 <fwp_write+0xb00>
    7ac4:	1e202118 	fcmpe	s8, #0.0
    7ac8:	d0000022 	adrp	x2, d000 <__divti3+0x2b0>
    7acc:	9117a042 	add	x2, x2, #0x5e8
    7ad0:	910123f5 	add	x21, sp, #0x48
    7ad4:	d0000021 	adrp	x1, d000 <__divti3+0x2b0>
    7ad8:	912a0021 	add	x1, x1, #0xa80
    7adc:	aa1503e0 	mov	x0, x21
    7ae0:	9a81c041 	csel	x1, x2, x1, gt
    7ae4:	97ffebbf 	bl	29e0 <strcpy@plt>
    7ae8:	aa1503e0 	mov	x0, x21
    7aec:	97ffeb11 	bl	2730 <strlen@plt>
    7af0:	aa1503e1 	mov	x1, x21
    7af4:	aa0003e2 	mov	x2, x0
    7af8:	aa1403e0 	mov	x0, x20
    7afc:	97ffeee5 	bl	3690 <buf_put>
    7b00:	f9413bf5 	ldr	x21, [sp, #624]
    7b04:	f9413ff6 	ldr	x22, [sp, #632]
    7b08:	f94153fb 	ldr	x27, [sp, #672]
    7b0c:	f94157fc 	ldr	x28, [sp, #680]
    7b10:	fd415be8 	ldr	d8, [sp, #688]
    7b14:	fd415fe9 	ldr	d9, [sp, #696]
    7b18:	17fffeb6 	b	75f0 <fwp_write+0xb0>
    7b1c:	f9400276 	ldr	x22, [x19]
    7b20:	34002e03 	cbz	w3, 80e0 <fwp_write+0xba0>
    7b24:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7b28:	f947f400 	ldr	x0, [x0, #4072]
    7b2c:	f94127e2 	ldr	x2, [sp, #584]
    7b30:	f9400001 	ldr	x1, [x0]
    7b34:	eb010042 	subs	x2, x2, x1
    7b38:	d2800001 	mov	x1, #0x0                   	// #0
    7b3c:	540014a1 	b.ne	7dd0 <fwp_write+0x890>  // b.any
    7b40:	aa1603e2 	mov	x2, x22
    7b44:	91002261 	add	x1, x19, #0x8
    7b48:	f9413bf5 	ldr	x21, [sp, #624]
    7b4c:	aa1403e0 	mov	x0, x20
    7b50:	f9413ff6 	ldr	x22, [sp, #632]
    7b54:	17fffeff 	b	7750 <fwp_write+0x210>
    7b58:	fd015be8 	str	d8, [sp, #688]
    7b5c:	9e670268 	fmov	d8, x19
    7b60:	fd015fe9 	str	d9, [sp, #696]
    7b64:	1e682100 	fcmp	d8, d8
    7b68:	54004746 	b.vs	8450 <fwp_write+0xf10>
    7b6c:	1e60c101 	fabs	d1, d8
    7b70:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7b74:	9e670000 	fmov	d0, x0
    7b78:	910123f5 	add	x21, sp, #0x48
    7b7c:	52800033 	mov	w19, #0x1                   	// #1
    7b80:	1e602020 	fcmp	d1, d0
    7b84:	540001ad 	b.le	7bb8 <fwp_write+0x678>
    7b88:	1e602118 	fcmpe	d8, #0.0
    7b8c:	d0000022 	adrp	x2, d000 <__divti3+0x2b0>
    7b90:	9117a042 	add	x2, x2, #0x5e8
    7b94:	d0000021 	adrp	x1, d000 <__divti3+0x2b0>
    7b98:	912a0021 	add	x1, x1, #0xa80
    7b9c:	aa1503e0 	mov	x0, x21
    7ba0:	9a81c041 	csel	x1, x2, x1, gt
    7ba4:	97ffeb8f 	bl	29e0 <strcpy@plt>
    7ba8:	17ffffd0 	b	7ae8 <fwp_write+0x5a8>
    7bac:	11000673 	add	w19, w19, #0x1
    7bb0:	71004a7f 	cmp	w19, #0x12
    7bb4:	54003860 	b.eq	82c0 <fwp_write+0xd80>  // b.none
    7bb8:	1e604100 	fmov	d0, d8
    7bbc:	2a1303e1 	mov	w1, w19
    7bc0:	aa1503e0 	mov	x0, x21
    7bc4:	97ffeff4 	bl	3b94 <fwp_format_g.constprop.0>
    7bc8:	aa1503e0 	mov	x0, x21
    7bcc:	d2800001 	mov	x1, #0x0                   	// #0
    7bd0:	97ffeaec 	bl	2780 <strtod@plt>
    7bd4:	1e602100 	fcmp	d8, d0
    7bd8:	54fffea1 	b.ne	7bac <fwp_write+0x66c>  // b.any
    7bdc:	aa1503e0 	mov	x0, x21
    7be0:	97ffeee5 	bl	3774 <fwp_finish_float>
    7be4:	17ffffc1 	b	7ae8 <fwp_write+0x5a8>
    7be8:	a9400e62 	ldp	x2, x3, [x19]
    7bec:	910123f3 	add	x19, sp, #0x48
    7bf0:	aa1303e0 	mov	x0, x19
    7bf4:	97ffec8b 	bl	2e20 <fwp_fmt_u128>
    7bf8:	17fffe74 	b	75c8 <fwp_write+0x88>
    7bfc:	f90143f7 	str	x23, [sp, #640]
    7c00:	f90147f8 	str	x24, [sp, #648]
    7c04:	2a1303f8 	mov	w24, w19
    7c08:	f9014bf9 	str	x25, [sp, #656]
    7c0c:	f9014ffa 	str	x26, [sp, #664]
    7c10:	f13ffe7f 	cmp	x19, #0xfff
    7c14:	54000049 	b.ls	7c1c <fwp_write+0x6dc>  // b.plast
    7c18:	b9400278 	ldr	w24, [x19]
    7c1c:	f9400f80 	ldr	x0, [x28, #24]
    7c20:	2a1803f5 	mov	w21, w24
    7c24:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7c28:	d37ef6b9 	lsl	x25, x21, #2
    7c2c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7c30:	aa1603e0 	mov	x0, x22
    7c34:	97ffeabf 	bl	2730 <strlen@plt>
    7c38:	aa1603e1 	mov	x1, x22
    7c3c:	aa0003e2 	mov	x2, x0
    7c40:	aa1403e0 	mov	x0, x20
    7c44:	97ffee93 	bl	3690 <buf_put>
    7c48:	f9401780 	ldr	x0, [x28, #40]
    7c4c:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7c50:	7100001f 	cmp	w0, #0x0
    7c54:	5400068d 	b.le	7d24 <fwp_write+0x7e4>
    7c58:	91002276 	add	x22, x19, #0x8
    7c5c:	91001ff5 	add	x21, sp, #0x7
    7c60:	d280001b 	mov	x27, #0x0                   	// #0
    7c64:	5280041a 	mov	w26, #0x20                  	// #32
    7c68:	f9401b80 	ldr	x0, [x28, #48]
    7c6c:	aa1503e1 	mov	x1, x21
    7c70:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7c74:	d2800022 	mov	x2, #0x1                   	// #1
    7c78:	f8786803 	ldr	x3, [x0, x24]
    7c7c:	aa1403e0 	mov	x0, x20
    7c80:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7c84:	39001ffa 	strb	w26, [sp, #7]
    7c88:	97ffee82 	bl	3690 <buf_put>
    7c8c:	f13ffeff 	cmp	x23, #0xfff
    7c90:	b9400261 	ldr	w1, [x19]
    7c94:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7c98:	7100383f 	cmp	w1, #0xe
    7c9c:	54000160 	b.eq	7cc8 <fwp_write+0x788>  // b.none
    7ca0:	7100403f 	cmp	w1, #0x10
    7ca4:	54001a60 	b.eq	7ff0 <fwp_write+0xab0>  // b.none
    7ca8:	7100283f 	cmp	w1, #0xa
    7cac:	54002aa0 	b.eq	8200 <fwp_write+0xcc0>  // b.none
    7cb0:	540014ac 	b.gt	7f44 <fwp_write+0xa04>
    7cb4:	71000c3f 	cmp	w1, #0x3
    7cb8:	540029ac 	b.gt	81ec <fwp_write+0xcac>
    7cbc:	d37ffee0 	lsr	x0, x23, #63
    7cc0:	37f814a1 	tbnz	w1, #31, 7f54 <fwp_write+0xa14>
    7cc4:	d503201f 	nop
    7cc8:	34001460 	cbz	w0, 7f54 <fwp_write+0xa14>
    7ccc:	52800503 	mov	w3, #0x28                  	// #40
    7cd0:	aa1503e1 	mov	x1, x21
    7cd4:	aa1403e0 	mov	x0, x20
    7cd8:	d2800022 	mov	x2, #0x1                   	// #1
    7cdc:	39001fe3 	strb	w3, [sp, #7]
    7ce0:	97ffee6c 	bl	3690 <buf_put>
    7ce4:	aa1303e2 	mov	x2, x19
    7ce8:	aa1703e1 	mov	x1, x23
    7cec:	aa1403e0 	mov	x0, x20
    7cf0:	52800003 	mov	w3, #0x0                   	// #0
    7cf4:	97fffe13 	bl	7540 <fwp_write>
    7cf8:	52800523 	mov	w3, #0x29                  	// #41
    7cfc:	aa1503e1 	mov	x1, x21
    7d00:	aa1403e0 	mov	x0, x20
    7d04:	d2800022 	mov	x2, #0x1                   	// #1
    7d08:	39001fe3 	strb	w3, [sp, #7]
    7d0c:	97ffee61 	bl	3690 <buf_put>
    7d10:	f9401780 	ldr	x0, [x28, #40]
    7d14:	9100077b 	add	x27, x27, #0x1
    7d18:	b8796800 	ldr	w0, [x0, x25]
    7d1c:	6b1b001f 	cmp	w0, w27
    7d20:	54fffa4c 	b.gt	7c68 <fwp_write+0x728>
    7d24:	f9413bf5 	ldr	x21, [sp, #624]
    7d28:	f9413ff6 	ldr	x22, [sp, #632]
    7d2c:	f94143f7 	ldr	x23, [sp, #640]
    7d30:	f94147f8 	ldr	x24, [sp, #648]
    7d34:	f9414bf9 	ldr	x25, [sp, #656]
    7d38:	f9414ffa 	ldr	x26, [sp, #664]
    7d3c:	f94153fb 	ldr	x27, [sp, #672]
    7d40:	f94157fc 	ldr	x28, [sp, #680]
    7d44:	17fffe2b 	b	75f0 <fwp_write+0xb0>
    7d48:	52800783 	mov	w3, #0x3c                  	// #60
    7d4c:	91001ff3 	add	x19, sp, #0x7
    7d50:	aa1303e1 	mov	x1, x19
    7d54:	d2800022 	mov	x2, #0x1                   	// #1
    7d58:	aa1403e0 	mov	x0, x20
    7d5c:	39001fe3 	strb	w3, [sp, #7]
    7d60:	97ffee4c 	bl	3690 <buf_put>
    7d64:	f9400795 	ldr	x21, [x28, #8]
    7d68:	aa1503e0 	mov	x0, x21
    7d6c:	97ffea71 	bl	2730 <strlen@plt>
    7d70:	aa1503e1 	mov	x1, x21
    7d74:	aa0003e2 	mov	x2, x0
    7d78:	aa1403e0 	mov	x0, x20
    7d7c:	97ffee45 	bl	3690 <buf_put>
    7d80:	528007c3 	mov	w3, #0x3e                  	// #62
    7d84:	aa1303e1 	mov	x1, x19
    7d88:	aa1403e0 	mov	x0, x20
    7d8c:	d2800022 	mov	x2, #0x1                   	// #1
    7d90:	39001fe3 	strb	w3, [sp, #7]
    7d94:	17fffe12 	b	75dc <fwp_write+0x9c>
    7d98:	f100067f 	cmp	x19, #0x1
    7d9c:	540025a0 	b.eq	8250 <fwp_write+0xd10>  // b.none
    7da0:	b100067f 	cmn	x19, #0x1
    7da4:	54002bc0 	b.eq	831c <fwp_write+0xddc>  // b.none
    7da8:	d0000021 	adrp	x1, d000 <__divti3+0x2b0>
    7dac:	912a2021 	add	x1, x1, #0xa88
    7db0:	d2800022 	mov	x2, #0x1                   	// #1
    7db4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7db8:	f947f400 	ldr	x0, [x0, #4072]
    7dbc:	f94127e4 	ldr	x4, [sp, #584]
    7dc0:	f9400003 	ldr	x3, [x0]
    7dc4:	eb030084 	subs	x4, x4, x3
    7dc8:	d2800003 	mov	x3, #0x0                   	// #0
    7dcc:	54ffebe0 	b.eq	7b48 <fwp_write+0x608>  // b.none
    7dd0:	f90143f7 	str	x23, [sp, #640]
    7dd4:	f90147f8 	str	x24, [sp, #648]
    7dd8:	f9014bf9 	str	x25, [sp, #656]
    7ddc:	f9014ffa 	str	x26, [sp, #664]
    7de0:	fd015be8 	str	d8, [sp, #688]
    7de4:	fd015fe9 	str	d9, [sp, #696]
    7de8:	97ffeaae 	bl	28a0 <__stack_chk_fail@plt>
    7dec:	52800b63 	mov	w3, #0x5b                  	// #91
    7df0:	91001ff5 	add	x21, sp, #0x7
    7df4:	aa1503e1 	mov	x1, x21
    7df8:	aa1403e0 	mov	x0, x20
    7dfc:	d2800022 	mov	x2, #0x1                   	// #1
    7e00:	d0000036 	adrp	x22, d000 <__divti3+0x2b0>
    7e04:	912ca2d6 	add	x22, x22, #0xb28
    7e08:	39001fe3 	strb	w3, [sp, #7]
    7e0c:	97ffee21 	bl	3690 <buf_put>
    7e10:	b4000273 	cbz	x19, 7e5c <fwp_write+0x91c>
    7e14:	f9400661 	ldr	x1, [x19, #8]
    7e18:	aa1403e0 	mov	x0, x20
    7e1c:	f9401f82 	ldr	x2, [x28, #56]
    7e20:	52800003 	mov	w3, #0x0                   	// #0
    7e24:	97fffdc7 	bl	7540 <fwp_write>
    7e28:	f9400a73 	ldr	x19, [x19, #16]
    7e2c:	b4000193 	cbz	x19, 7e5c <fwp_write+0x91c>
    7e30:	aa1603e1 	mov	x1, x22
    7e34:	aa1403e0 	mov	x0, x20
    7e38:	d2800042 	mov	x2, #0x2                   	// #2
    7e3c:	97ffee15 	bl	3690 <buf_put>
    7e40:	f9400661 	ldr	x1, [x19, #8]
    7e44:	aa1403e0 	mov	x0, x20
    7e48:	f9401f82 	ldr	x2, [x28, #56]
    7e4c:	52800003 	mov	w3, #0x0                   	// #0
    7e50:	97fffdbc 	bl	7540 <fwp_write>
    7e54:	f9400a73 	ldr	x19, [x19, #16]
    7e58:	b5fffed3 	cbnz	x19, 7e30 <fwp_write+0x8f0>
    7e5c:	52800ba3 	mov	w3, #0x5d                  	// #93
    7e60:	aa1503e1 	mov	x1, x21
    7e64:	aa1403e0 	mov	x0, x20
    7e68:	d2800022 	mov	x2, #0x1                   	// #1
    7e6c:	39001fe3 	strb	w3, [sp, #7]
    7e70:	17fffddb 	b	75dc <fwp_write+0x9c>
    7e74:	aa1403e0 	mov	x0, x20
    7e78:	d0000021 	adrp	x1, d000 <__divti3+0x2b0>
    7e7c:	d28000c2 	mov	x2, #0x6                   	// #6
    7e80:	912c6021 	add	x1, x1, #0xb18
    7e84:	97ffee03 	bl	3690 <buf_put>
    7e88:	f9400260 	ldr	x0, [x19]
    7e8c:	b40004c0 	cbz	x0, 7f24 <fwp_write+0x9e4>
    7e90:	910123f5 	add	x21, sp, #0x48
    7e94:	91002276 	add	x22, x19, #0x8
    7e98:	f90143f7 	str	x23, [sp, #640]
    7e9c:	d2800017 	mov	x23, #0x0                   	// #0
    7ea0:	f90147f8 	str	x24, [sp, #648]
    7ea4:	d0000038 	adrp	x24, d000 <__divti3+0x2b0>
    7ea8:	912c8318 	add	x24, x24, #0xb20
    7eac:	f9014bf9 	str	x25, [sp, #656]
    7eb0:	d0000039 	adrp	x25, d000 <__divti3+0x2b0>
    7eb4:	912ca339 	add	x25, x25, #0xb28
    7eb8:	f9014ffa 	str	x26, [sp, #664]
    7ebc:	14000005 	b	7ed0 <fwp_write+0x990>
    7ec0:	aa1903e1 	mov	x1, x25
    7ec4:	aa1403e0 	mov	x0, x20
    7ec8:	d2800042 	mov	x2, #0x2                   	// #2
    7ecc:	97ffedf1 	bl	3690 <buf_put>
    7ed0:	38776ac5 	ldrb	w5, [x22, x23]
    7ed4:	d2804003 	mov	x3, #0x200                 	// #512
    7ed8:	aa1803e4 	mov	x4, x24
    7edc:	aa0303e1 	mov	x1, x3
    7ee0:	52800042 	mov	w2, #0x2                   	// #2
    7ee4:	aa1503e0 	mov	x0, x21
    7ee8:	910006f7 	add	x23, x23, #0x1
    7eec:	97ffea49 	bl	2810 <__snprintf_chk@plt>
    7ef0:	aa1503e0 	mov	x0, x21
    7ef4:	97ffea0f 	bl	2730 <strlen@plt>
    7ef8:	aa1503e1 	mov	x1, x21
    7efc:	aa0003e2 	mov	x2, x0
    7f00:	aa1403e0 	mov	x0, x20
    7f04:	97ffede3 	bl	3690 <buf_put>
    7f08:	f9400260 	ldr	x0, [x19]
    7f0c:	eb17001f 	cmp	x0, x23
    7f10:	54fffd88 	b.hi	7ec0 <fwp_write+0x980>  // b.pmore
    7f14:	f94143f7 	ldr	x23, [sp, #640]
    7f18:	f94147f8 	ldr	x24, [sp, #648]
    7f1c:	f9414bf9 	ldr	x25, [sp, #656]
    7f20:	f9414ffa 	ldr	x26, [sp, #664]
    7f24:	52800ba3 	mov	w3, #0x5d                  	// #93
    7f28:	aa1403e0 	mov	x0, x20
    7f2c:	91001fe1 	add	x1, sp, #0x7
    7f30:	d2800022 	mov	x2, #0x1                   	// #1
    7f34:	39001fe3 	strb	w3, [sp, #7]
    7f38:	17fffda9 	b	75dc <fwp_write+0x9c>
    7f3c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7f40:	17fffe44 	b	7850 <fwp_write+0x310>
    7f44:	f10002ff 	cmp	x23, #0x0
    7f48:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7f4c:	71002c3f 	cmp	w1, #0xb
    7f50:	54ffebc0 	b.eq	7cc8 <fwp_write+0x788>  // b.none
    7f54:	aa1303e2 	mov	x2, x19
    7f58:	aa1703e1 	mov	x1, x23
    7f5c:	aa1403e0 	mov	x0, x20
    7f60:	52800003 	mov	w3, #0x0                   	// #0
    7f64:	97fffd77 	bl	7540 <fwp_write>
    7f68:	17ffff6a 	b	7d10 <fwp_write+0x7d0>
    7f6c:	aa1403e0 	mov	x0, x20
    7f70:	91001fe1 	add	x1, sp, #0x7
    7f74:	52800fa3 	mov	w3, #0x7d                  	// #125
    7f78:	d2800022 	mov	x2, #0x1                   	// #1
    7f7c:	17fffe38 	b	785c <fwp_write+0x31c>
    7f80:	a9400281 	ldp	x1, x0, [x20]
    7f84:	91000800 	add	x0, x0, #0x2
    7f88:	8b160000 	add	x0, x0, x22
    7f8c:	f9000680 	str	x0, [x20, #8]
    7f90:	3820683f 	strb	wzr, [x1, x0]
    7f94:	f9413bf5 	ldr	x21, [sp, #624]
    7f98:	f9413ff6 	ldr	x22, [sp, #632]
    7f9c:	f94153fb 	ldr	x27, [sp, #672]
    7fa0:	f94157fc 	ldr	x28, [sp, #680]
    7fa4:	17fffd93 	b	75f0 <fwp_write+0xb0>
    7fa8:	f9400f80 	ldr	x0, [x28, #24]
    7fac:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7fb0:	aa1b03e0 	mov	x0, x27
    7fb4:	97ffe9df 	bl	2730 <strlen@plt>
    7fb8:	aa1b03e1 	mov	x1, x27
    7fbc:	aa0003e2 	mov	x2, x0
    7fc0:	aa1403e0 	mov	x0, x20
    7fc4:	97ffedb3 	bl	3690 <buf_put>
    7fc8:	aa1903e1 	mov	x1, x25
    7fcc:	aa1403e0 	mov	x0, x20
    7fd0:	d2800062 	mov	x2, #0x3                   	// #3
    7fd4:	97ffedaf 	bl	3690 <buf_put>
    7fd8:	17fffe10 	b	7818 <fwp_write+0x2d8>
    7fdc:	aa1a03e1 	mov	x1, x26
    7fe0:	aa1403e0 	mov	x0, x20
    7fe4:	d2800042 	mov	x2, #0x2                   	// #2
    7fe8:	97ffedaa 	bl	3690 <buf_put>
    7fec:	17fffe09 	b	7810 <fwp_write+0x2d0>
    7ff0:	f9400660 	ldr	x0, [x19, #8]
    7ff4:	b4fffb00 	cbz	x0, 7f54 <fwp_write+0xa14>
    7ff8:	d0000021 	adrp	x1, d000 <__divti3+0x2b0>
    7ffc:	912d0021 	add	x1, x1, #0xb40
    8000:	97ffea48 	bl	2920 <strcmp@plt>
    8004:	7100001f 	cmp	w0, #0x0
    8008:	1a9f07e0 	cset	w0, ne	// ne = any
    800c:	17ffff2f 	b	7cc8 <fwp_write+0x788>
    8010:	aa1403e0 	mov	x0, x20
    8014:	d2800042 	mov	x2, #0x2                   	// #2
    8018:	b0000021 	adrp	x1, d000 <__divti3+0x2b0>
    801c:	912ce021 	add	x1, x1, #0xb38
    8020:	97ffed9c 	bl	3690 <buf_put>
    8024:	91004261 	add	x1, x19, #0x10
    8028:	aa1403e0 	mov	x0, x20
    802c:	f9402382 	ldr	x2, [x28, #64]
    8030:	52800003 	mov	w3, #0x0                   	// #0
    8034:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8038:	97fffd42 	bl	7540 <fwp_write>
    803c:	17fffd9c 	b	76ac <fwp_write+0x16c>
    8040:	1e22c109 	fcvt	d9, s8
    8044:	910123f5 	add	x21, sp, #0x48
    8048:	52800033 	mov	w19, #0x1                   	// #1
    804c:	d503201f 	nop
    8050:	1e604120 	fmov	d0, d9
    8054:	2a1303e1 	mov	w1, w19
    8058:	aa1503e0 	mov	x0, x21
    805c:	97ffeece 	bl	3b94 <fwp_format_g.constprop.0>
    8060:	aa1503e0 	mov	x0, x21
    8064:	d2800001 	mov	x1, #0x0                   	// #0
    8068:	97ffea3a 	bl	2950 <strtof@plt>
    806c:	1e202100 	fcmp	s8, s0
    8070:	54ffdb60 	b.eq	7bdc <fwp_write+0x69c>  // b.none
    8074:	11000673 	add	w19, w19, #0x1
    8078:	71002a7f 	cmp	w19, #0xa
    807c:	54fffea1 	b.ne	8050 <fwp_write+0xb10>  // b.any
    8080:	1e604120 	fmov	d0, d9
    8084:	aa1503e0 	mov	x0, x21
    8088:	52800121 	mov	w1, #0x9                   	// #9
    808c:	97ffeec2 	bl	3b94 <fwp_format_g.constprop.0>
    8090:	17fffed3 	b	7bdc <fwp_write+0x69c>
    8094:	d37ef6a1 	lsl	x1, x21, #2
    8098:	b7f81563 	tbnz	x3, #63, 8344 <fwp_write+0xe04>
    809c:	91002263 	add	x3, x19, #0x8
    80a0:	8b010061 	add	x1, x3, x1
    80a4:	b9400023 	ldr	w3, [x1]
    80a8:	7100081f 	cmp	w0, #0x2
    80ac:	2a0303e1 	mov	w1, w3
    80b0:	93407c63 	sxtw	x3, w3
    80b4:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    80b8:	17fffe5a 	b	7a20 <fwp_write+0x4e0>
    80bc:	d37ffaa1 	lsl	x1, x21, #1
    80c0:	b7f81363 	tbnz	x3, #63, 832c <fwp_write+0xdec>
    80c4:	91002263 	add	x3, x19, #0x8
    80c8:	8b010061 	add	x1, x3, x1
    80cc:	79400021 	ldrh	w1, [x1]
    80d0:	7100041f 	cmp	w0, #0x1
    80d4:	93403c23 	sxth	x3, w1
    80d8:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    80dc:	17fffe51 	b	7a20 <fwp_write+0x4e0>
    80e0:	52800443 	mov	w3, #0x22                  	// #34
    80e4:	91001ff5 	add	x21, sp, #0x7
    80e8:	91002273 	add	x19, x19, #0x8
    80ec:	aa1503e1 	mov	x1, x21
    80f0:	aa1403e0 	mov	x0, x20
    80f4:	d2800022 	mov	x2, #0x1                   	// #1
    80f8:	39001fe3 	strb	w3, [sp, #7]
    80fc:	f90143f7 	str	x23, [sp, #640]
    8100:	8b160277 	add	x23, x19, x22
    8104:	f90147f8 	str	x24, [sp, #648]
    8108:	97ffed62 	bl	3690 <buf_put>
    810c:	b4000696 	cbz	x22, 81dc <fwp_write+0xc9c>
    8110:	b0000038 	adrp	x24, d000 <__divti3+0x2b0>
    8114:	912ba318 	add	x24, x24, #0xae8
    8118:	f9014bf9 	str	x25, [sp, #656]
    811c:	b0000039 	adrp	x25, d000 <__divti3+0x2b0>
    8120:	912c2339 	add	x25, x25, #0xb08
    8124:	f9014ffa 	str	x26, [sp, #664]
    8128:	1400000d 	b	815c <fwp_write+0xc1c>
    812c:	710024bf 	cmp	w5, #0x9
    8130:	54000460 	b.eq	81bc <fwp_write+0xc7c>  // b.none
    8134:	710028bf 	cmp	w5, #0xa
    8138:	54000a61 	b.ne	8284 <fwp_write+0xd44>  // b.any
    813c:	b0000021 	adrp	x1, d000 <__divti3+0x2b0>
    8140:	aa1403e0 	mov	x0, x20
    8144:	912be021 	add	x1, x1, #0xaf8
    8148:	d2800042 	mov	x2, #0x2                   	// #2
    814c:	97ffed51 	bl	3690 <buf_put>
    8150:	91000673 	add	x19, x19, #0x1
    8154:	eb17027f 	cmp	x19, x23
    8158:	540003e0 	b.eq	81d4 <fwp_write+0xc94>  // b.none
    815c:	39400265 	ldrb	w5, [x19]
    8160:	710034bf 	cmp	w5, #0xd
    8164:	54000180 	b.eq	8194 <fwp_write+0xc54>  // b.none
    8168:	54fffe29 	b.ls	812c <fwp_write+0xbec>  // b.plast
    816c:	710088bf 	cmp	w5, #0x22
    8170:	540001c0 	b.eq	81a8 <fwp_write+0xc68>  // b.none
    8174:	710170bf 	cmp	w5, #0x5c
    8178:	54000741 	b.ne	8260 <fwp_write+0xd20>  // b.any
    817c:	aa1403e0 	mov	x0, x20
    8180:	b0000021 	adrp	x1, d000 <__divti3+0x2b0>
    8184:	d2800042 	mov	x2, #0x2                   	// #2
    8188:	912bc021 	add	x1, x1, #0xaf0
    818c:	97ffed41 	bl	3690 <buf_put>
    8190:	17fffff0 	b	8150 <fwp_write+0xc10>
    8194:	aa1903e1 	mov	x1, x25
    8198:	aa1403e0 	mov	x0, x20
    819c:	d2800042 	mov	x2, #0x2                   	// #2
    81a0:	97ffed3c 	bl	3690 <buf_put>
    81a4:	17ffffeb 	b	8150 <fwp_write+0xc10>
    81a8:	aa1803e1 	mov	x1, x24
    81ac:	aa1403e0 	mov	x0, x20
    81b0:	d2800042 	mov	x2, #0x2                   	// #2
    81b4:	97ffed37 	bl	3690 <buf_put>
    81b8:	17ffffe6 	b	8150 <fwp_write+0xc10>
    81bc:	aa1403e0 	mov	x0, x20
    81c0:	b0000021 	adrp	x1, d000 <__divti3+0x2b0>
    81c4:	d2800042 	mov	x2, #0x2                   	// #2
    81c8:	912c0021 	add	x1, x1, #0xb00
    81cc:	97ffed31 	bl	3690 <buf_put>
    81d0:	17ffffe0 	b	8150 <fwp_write+0xc10>
    81d4:	f9414bf9 	ldr	x25, [sp, #656]
    81d8:	f9414ffa 	ldr	x26, [sp, #664]
    81dc:	aa1503e1 	mov	x1, x21
    81e0:	aa1403e0 	mov	x0, x20
    81e4:	52800443 	mov	w3, #0x22                  	// #34
    81e8:	17fffd9c 	b	7858 <fwp_write+0x318>
    81ec:	7100103f 	cmp	w1, #0x4
    81f0:	54ffeb21 	b.ne	7f54 <fwp_write+0xa14>  // b.any
    81f4:	f94006e0 	ldr	x0, [x23, #8]
    81f8:	d37ffc00 	lsr	x0, x0, #63
    81fc:	17fffeb3 	b	7cc8 <fwp_write+0x788>
    8200:	710002ff 	cmp	w23, #0x0
    8204:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8208:	17fffeb0 	b	7cc8 <fwp_write+0x788>
    820c:	528005a1 	mov	w1, #0x2d                  	// #45
    8210:	eb0203e2 	negs	x2, x2
    8214:	da0303e3 	ngc	x3, x3
    8218:	910127e0 	add	x0, sp, #0x49
    821c:	910123f5 	add	x21, sp, #0x48
    8220:	390123e1 	strb	w1, [sp, #72]
    8224:	97ffeaff 	bl	2e20 <fwp_fmt_u128>
    8228:	17fffe18 	b	7a88 <fwp_write+0x548>
    822c:	d37ceea1 	lsl	x1, x21, #4
    8230:	b7f810a3 	tbnz	x3, #63, 8444 <fwp_write+0xf04>
    8234:	91002260 	add	x0, x19, #0x8
    8238:	8b010001 	add	x1, x0, x1
    823c:	17fffdf9 	b	7a20 <fwp_write+0x4e0>
    8240:	f9400a61 	ldr	x1, [x19, #16]
    8244:	8b010000 	add	x0, x0, x1
    8248:	f9400001 	ldr	x1, [x0]
    824c:	17fffdf5 	b	7a20 <fwp_write+0x4e0>
    8250:	b0000021 	adrp	x1, d000 <__divti3+0x2b0>
    8254:	d2800042 	mov	x2, #0x2                   	// #2
    8258:	912a4021 	add	x1, x1, #0xa90
    825c:	17fffed6 	b	7db4 <fwp_write+0x874>
    8260:	7101fcbf 	cmp	w5, #0x7f
    8264:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    8268:	540000e9 	b.ls	8284 <fwp_write+0xd44>  // b.plast
    826c:	aa1503e1 	mov	x1, x21
    8270:	aa1403e0 	mov	x0, x20
    8274:	d2800022 	mov	x2, #0x1                   	// #1
    8278:	39001fe5 	strb	w5, [sp, #7]
    827c:	97ffed05 	bl	3690 <buf_put>
    8280:	17ffffb4 	b	8150 <fwp_write+0xc10>
    8284:	d2800203 	mov	x3, #0x10                  	// #16
    8288:	b0000024 	adrp	x4, d000 <__divti3+0x2b0>
    828c:	aa0303e1 	mov	x1, x3
    8290:	912c4084 	add	x4, x4, #0xb10
    8294:	910123f6 	add	x22, sp, #0x48
    8298:	52800042 	mov	w2, #0x2                   	// #2
    829c:	aa1603e0 	mov	x0, x22
    82a0:	97ffe95c 	bl	2810 <__snprintf_chk@plt>
    82a4:	aa1603e0 	mov	x0, x22
    82a8:	97ffe922 	bl	2730 <strlen@plt>
    82ac:	aa1603e1 	mov	x1, x22
    82b0:	aa0003e2 	mov	x2, x0
    82b4:	aa1403e0 	mov	x0, x20
    82b8:	97ffecf6 	bl	3690 <buf_put>
    82bc:	17ffffa5 	b	8150 <fwp_write+0xc10>
    82c0:	1e604100 	fmov	d0, d8
    82c4:	aa1503e0 	mov	x0, x21
    82c8:	52800221 	mov	w1, #0x11                  	// #17
    82cc:	97ffee32 	bl	3b94 <fwp_format_g.constprop.0>
    82d0:	17fffe43 	b	7bdc <fwp_write+0x69c>
    82d4:	b9401040 	ldr	w0, [x2, #16]
    82d8:	350003c0 	cbnz	w0, 8350 <fwp_write+0xe10>
    82dc:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    82e0:	f947f400 	ldr	x0, [x0, #4072]
    82e4:	f94127e2 	ldr	x2, [sp, #584]
    82e8:	f9400001 	ldr	x1, [x0]
    82ec:	eb010042 	subs	x2, x2, x1
    82f0:	d2800001 	mov	x1, #0x0                   	// #0
    82f4:	54ffd721 	b.ne	7dd8 <fwp_write+0x898>  // b.any
    82f8:	f9413bf5 	ldr	x21, [sp, #624]
    82fc:	b0000021 	adrp	x1, d000 <__divti3+0x2b0>
    8300:	f9413ff6 	ldr	x22, [sp, #632]
    8304:	aa1403e0 	mov	x0, x20
    8308:	f94143f7 	ldr	x23, [sp, #640]
    830c:	912d8021 	add	x1, x1, #0xb60
    8310:	f94147f8 	ldr	x24, [sp, #648]
    8314:	d2800042 	mov	x2, #0x2                   	// #2
    8318:	17fffd0e 	b	7750 <fwp_write+0x210>
    831c:	b0000021 	adrp	x1, d000 <__divti3+0x2b0>
    8320:	d2800042 	mov	x2, #0x2                   	// #2
    8324:	912a6021 	add	x1, x1, #0xa98
    8328:	17fffea3 	b	7db4 <fwp_write+0x874>
    832c:	f9400a63 	ldr	x3, [x19, #16]
    8330:	8b030021 	add	x1, x1, x3
    8334:	17ffff66 	b	80cc <fwp_write+0xb8c>
    8338:	f9400a61 	ldr	x1, [x19, #16]
    833c:	8b0102a1 	add	x1, x21, x1
    8340:	17fffdb3 	b	7a0c <fwp_write+0x4cc>
    8344:	f9400a63 	ldr	x3, [x19, #16]
    8348:	8b030021 	add	x1, x1, x3
    834c:	17ffff56 	b	80a4 <fwp_write+0xb64>
    8350:	b9404840 	ldr	w0, [x2, #72]
    8354:	91001ff5 	add	x21, sp, #0x7
    8358:	34ffa360 	cbz	w0, 77c4 <fwp_write+0x284>
    835c:	52800503 	mov	w3, #0x28                  	// #40
    8360:	aa1403e0 	mov	x0, x20
    8364:	aa1503e1 	mov	x1, x21
    8368:	d2800022 	mov	x2, #0x1                   	// #1
    836c:	39001fe3 	strb	w3, [sp, #7]
    8370:	97ffecc8 	bl	3690 <buf_put>
    8374:	b9401380 	ldr	w0, [x28, #16]
    8378:	52800038 	mov	w24, #0x1                   	// #1
    837c:	7100001f 	cmp	w0, #0x0
    8380:	54ffa36c 	b.gt	77ec <fwp_write+0x2ac>
    8384:	17fffd32 	b	784c <fwp_write+0x30c>
    8388:	f9014bf9 	str	x25, [sp, #656]
    838c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe790>
    8390:	f9014ffa 	str	x26, [sp, #664]
    8394:	f9400676 	ldr	x22, [x19, #8]
    8398:	910ac333 	add	x19, x25, #0x2b0
    839c:	91002273 	add	x19, x19, #0x8
    83a0:	937ffed8 	asr	x24, x22, #63
    83a4:	aa1802c0 	orr	x0, x22, x24
    83a8:	b5000320 	cbnz	x0, 840c <fwp_write+0xecc>
    83ac:	110006b5 	add	w21, w21, #0x1
    83b0:	710016bf 	cmp	w21, #0x5
    83b4:	54ffffc1 	b.ne	83ac <fwp_write+0xe6c>  // b.any
    83b8:	b7f80578 	tbnz	x24, #63, 8464 <fwp_write+0xf24>
    83bc:	910023f3 	add	x19, sp, #0x8
    83c0:	aa1603e2 	mov	x2, x22
    83c4:	aa1303e0 	mov	x0, x19
    83c8:	d2800003 	mov	x3, #0x0                   	// #0
    83cc:	97ffea95 	bl	2e20 <fwp_fmt_u128>
    83d0:	910123f5 	add	x21, sp, #0x48
    83d4:	b0000023 	adrp	x3, d000 <__divti3+0x2b0>
    83d8:	aa1303e4 	mov	x4, x19
    83dc:	aa1503e0 	mov	x0, x21
    83e0:	912d6063 	add	x3, x3, #0xb58
    83e4:	d2804002 	mov	x2, #0x200                 	// #512
    83e8:	52800041 	mov	w1, #0x2                   	// #2
    83ec:	97ffe8d5 	bl	2740 <__sprintf_chk@plt>
    83f0:	aa1503e0 	mov	x0, x21
    83f4:	97ffe8cf 	bl	2730 <strlen@plt>
    83f8:	aa1503e1 	mov	x1, x21
    83fc:	aa0003e2 	mov	x2, x0
    8400:	aa1403e0 	mov	x0, x20
    8404:	97ffeca3 	bl	3690 <buf_put>
    8408:	17fffe47 	b	7d24 <fwp_write+0x7e4>
    840c:	f9400277 	ldr	x23, [x19]
    8410:	aa1603e0 	mov	x0, x22
    8414:	aa1803e1 	mov	x1, x24
    8418:	aa1703e2 	mov	x2, x23
    841c:	937ffefa 	asr	x26, x23, #63
    8420:	aa1a03e3 	mov	x3, x26
    8424:	9400132b 	bl	d0d0 <__modti3>
    8428:	aa010000 	orr	x0, x0, x1
    842c:	b40002c0 	cbz	x0, 8484 <fwp_write+0xf44>
    8430:	110006b5 	add	w21, w21, #0x1
    8434:	91004273 	add	x19, x19, #0x10
    8438:	710016bf 	cmp	w21, #0x5
    843c:	54fffe81 	b.ne	840c <fwp_write+0xecc>  // b.any
    8440:	17ffffde 	b	83b8 <fwp_write+0xe78>
    8444:	f9400a60 	ldr	x0, [x19, #16]
    8448:	8b000021 	add	x1, x1, x0
    844c:	17fffd75 	b	7a20 <fwp_write+0x4e0>
    8450:	528c29c0 	mov	w0, #0x614e                	// #24910
    8454:	910123f5 	add	x21, sp, #0x48
    8458:	72a009c0 	movk	w0, #0x4e, lsl #16
    845c:	b9004be0 	str	w0, [sp, #72]
    8460:	17fffda2 	b	7ae8 <fwp_write+0x5a8>
    8464:	528005a1 	mov	w1, #0x2d                  	// #45
    8468:	eb1603e2 	negs	x2, x22
    846c:	da1803e3 	ngc	x3, x24
    8470:	910027e0 	add	x0, sp, #0x9
    8474:	910023f3 	add	x19, sp, #0x8
    8478:	390023e1 	strb	w1, [sp, #8]
    847c:	97ffea69 	bl	2e20 <fwp_fmt_u128>
    8480:	17ffffd4 	b	83d0 <fwp_write+0xe90>
    8484:	aa1703e2 	mov	x2, x23
    8488:	aa1a03e3 	mov	x3, x26
    848c:	aa1603e0 	mov	x0, x22
    8490:	aa1803e1 	mov	x1, x24
    8494:	9400122f 	bl	cd50 <__divti3>
    8498:	aa0003e2 	mov	x2, x0
    849c:	aa0103e3 	mov	x3, x1
    84a0:	b7f80201 	tbnz	x1, #63, 84e0 <fwp_write+0xfa0>
    84a4:	910023f3 	add	x19, sp, #0x8
    84a8:	aa1303e0 	mov	x0, x19
    84ac:	97ffea5d 	bl	2e20 <fwp_fmt_u128>
    84b0:	937c7ea1 	sbfiz	x1, x21, #4, #32
    84b4:	910ac339 	add	x25, x25, #0x2b0
    84b8:	910123f5 	add	x21, sp, #0x48
    84bc:	aa1303e4 	mov	x4, x19
    84c0:	aa1503e0 	mov	x0, x21
    84c4:	b0000023 	adrp	x3, d000 <__divti3+0x2b0>
    84c8:	f8616b25 	ldr	x5, [x25, x1]
    84cc:	912d4063 	add	x3, x3, #0xb50
    84d0:	d2804002 	mov	x2, #0x200                 	// #512
    84d4:	52800041 	mov	w1, #0x2                   	// #2
    84d8:	97ffe89a 	bl	2740 <__sprintf_chk@plt>
    84dc:	17ffffc5 	b	83f0 <fwp_write+0xeb0>
    84e0:	528005a4 	mov	w4, #0x2d                  	// #45
    84e4:	eb0003e2 	negs	x2, x0
    84e8:	da0103e3 	ngc	x3, x1
    84ec:	910027e0 	add	x0, sp, #0x9
    84f0:	910023f3 	add	x19, sp, #0x8
    84f4:	390023e4 	strb	w4, [sp, #8]
    84f8:	97ffea4a 	bl	2e20 <fwp_fmt_u128>
    84fc:	17ffffed 	b	84b0 <fwp_write+0xf70>
    8500:	f9013bf5 	str	x21, [sp, #624]
    8504:	f9013ff6 	str	x22, [sp, #632]
    8508:	f90143f7 	str	x23, [sp, #640]
    850c:	f90147f8 	str	x24, [sp, #648]
    8510:	f9014bf9 	str	x25, [sp, #656]
    8514:	f9014ffa 	str	x26, [sp, #664]
    8518:	f90153fb 	str	x27, [sp, #672]
    851c:	f90157fc 	str	x28, [sp, #680]
    8520:	fd015be8 	str	d8, [sp, #688]
    8524:	fd015fe9 	str	d9, [sp, #696]
    8528:	97ffe8de 	bl	28a0 <__stack_chk_fail@plt>
    852c:	d503201f 	nop

0000000000008530 <fwp_hof0.constprop.0>:
    8530:	d10543ff 	sub	sp, sp, #0x150
    8534:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    8538:	f947f442 	ldr	x2, [x2, #4072]
    853c:	a90e7bfd 	stp	x29, x30, [sp, #224]
    8540:	910383fd 	add	x29, sp, #0xe0
    8544:	f90023e0 	str	x0, [sp, #64]
    8548:	f9400040 	ldr	x0, [x2]
    854c:	f9006fe0 	str	x0, [sp, #216]
    8550:	d2800000 	mov	x0, #0x0                   	// #0
    8554:	f90027e1 	str	x1, [sp, #72]
    8558:	b400a5a1 	cbz	x1, 9a0c <fwp_hof0.constprop.0+0x14dc>
    855c:	900000c0 	adrp	x0, 20000 <__data_start>
    8560:	91004000 	add	x0, x0, #0x10
    8564:	91008000 	add	x0, x0, #0x20
    8568:	f90017e0 	str	x0, [sp, #40]
    856c:	910163e0 	add	x0, sp, #0x58
    8570:	f9000fe0 	str	x0, [sp, #24]
    8574:	910183e0 	add	x0, sp, #0x60
    8578:	f90013e0 	str	x0, [sp, #32]
    857c:	d0000020 	adrp	x0, e000 <_IO_stdin_used+0xb90>
    8580:	fd00a3e8 	str	d8, [sp, #320]
    8584:	a90f53f3 	stp	x19, x20, [sp, #240]
    8588:	b0000394 	adrp	x20, 79000 <fwp_root_context+0xbb0>
    858c:	fd423008 	ldr	d8, [x0, #1120]
    8590:	a9105bf5 	stp	x21, x22, [sp, #256]
    8594:	a91163f7 	stp	x23, x24, [sp, #272]
    8598:	a9126bf9 	stp	x25, x26, [sp, #288]
    859c:	a91373fb 	stp	x27, x28, [sp, #304]
    85a0:	9118c282 	add	x2, x20, #0x630
    85a4:	f94023e0 	ldr	x0, [sp, #64]
    85a8:	f949ec43 	ldr	x3, [x2, #5080]
    85ac:	f949d841 	ldr	x1, [x2, #5040]
    85b0:	d370bc63 	lsl	x3, x3, #16
    85b4:	cb010004 	sub	x4, x0, x1
    85b8:	eb03009f 	cmp	x4, x3
    85bc:	540004c2 	b.cs	8654 <fwp_hof0.constprop.0+0x124>  // b.hs, b.nlast
    85c0:	d350fc80 	lsr	x0, x4, #16
    85c4:	f949fc46 	ldr	x6, [x2, #5112]
    85c8:	8b000800 	add	x0, x0, x0, lsl #2
    85cc:	d37df002 	lsl	x2, x0, #3
    85d0:	8b0200c5 	add	x5, x6, x2
    85d4:	f94010a0 	ldr	x0, [x5, #32]
    85d8:	b40003e0 	cbz	x0, 8654 <fwp_hof0.constprop.0+0x124>
    85dc:	386268c2 	ldrb	w2, [x6, x2]
    85e0:	7100085f 	cmp	w2, #0x2
    85e4:	5400bea0 	b.eq	9db8 <fwp_hof0.constprop.0+0x1888>  // b.none
    85e8:	7100045f 	cmp	w2, #0x1
    85ec:	54000341 	b.ne	8654 <fwp_hof0.constprop.0+0x124>  // b.any
    85f0:	92403c82 	and	x2, x4, #0xffff
    85f4:	294310a6 	ldp	w6, w4, [x5, #24]
    85f8:	9b067c42 	mul	x2, x2, x6
    85fc:	d360fc42 	lsr	x2, x2, #32
    8600:	eb04005f 	cmp	x2, x4
    8604:	54000282 	b.cs	8654 <fwp_hof0.constprop.0+0x124>  // b.hs, b.nlast
    8608:	8b020000 	add	x0, x0, x2
    860c:	39400002 	ldrb	w2, [x0]
    8610:	34000222 	cbz	w2, 8654 <fwp_hof0.constprop.0+0x124>
    8614:	900000c1 	adrp	x1, 20000 <__data_start>
    8618:	91014021 	add	x1, x1, #0x50
    861c:	b9413023 	ldr	w3, [x1, #304]
    8620:	34000083 	cbz	w3, 8630 <fwp_hof0.constprop.0+0x100>
    8624:	f940ac23 	ldr	x3, [x1, #344]
    8628:	91000463 	add	x3, x3, #0x1
    862c:	f900ac23 	str	x3, [x1, #344]
    8630:	7103f45f 	cmp	w2, #0xfd
    8634:	5400cbe8 	b.hi	9fb0 <fwp_hof0.constprop.0+0x1a80>  // b.pmore
    8638:	9118c281 	add	x1, x20, #0x630
    863c:	11000442 	add	w2, w2, #0x1
    8640:	39000002 	strb	w2, [x0]
    8644:	aa0103e0 	mov	x0, x1
    8648:	f949d821 	ldr	x1, [x1, #5040]
    864c:	f949ec03 	ldr	x3, [x0, #5080]
    8650:	d370bc63 	lsl	x3, x3, #16
    8654:	f94023f5 	ldr	x21, [sp, #64]
    8658:	d28018c0 	mov	x0, #0xc6                  	// #198
    865c:	f90007e0 	str	x0, [sp, #8]
    8660:	900000c0 	adrp	x0, 20000 <__data_start>
    8664:	91014002 	add	x2, x0, #0x50
    8668:	f94017e0 	ldr	x0, [sp, #40]
    866c:	12800004 	mov	w4, #0xffffffff            	// #-1
    8670:	b9005be4 	str	w4, [sp, #88]
    8674:	cb010001 	sub	x1, x0, x1
    8678:	d0ffffe0 	adrp	x0, 6000 <fwp_drop0+0x30>
    867c:	9112c000 	add	x0, x0, #0x4b0
    8680:	f90037e0 	str	x0, [sp, #104]
    8684:	f941c840 	ldr	x0, [x2, #912]
    8688:	f90033e0 	str	x0, [sp, #96]
    868c:	f9400fe0 	ldr	x0, [sp, #24]
    8690:	f9003be0 	str	x0, [sp, #112]
    8694:	f94013e0 	ldr	x0, [sp, #32]
    8698:	f901c840 	str	x0, [x2, #912]
    869c:	eb03003f 	cmp	x1, x3
    86a0:	54000882 	b.cs	87b0 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    86a4:	9118c282 	add	x2, x20, #0x630
    86a8:	d350fc20 	lsr	x0, x1, #16
    86ac:	8b000800 	add	x0, x0, x0, lsl #2
    86b0:	f949fc44 	ldr	x4, [x2, #5112]
    86b4:	d37df003 	lsl	x3, x0, #3
    86b8:	8b030082 	add	x2, x4, x3
    86bc:	f9401053 	ldr	x19, [x2, #32]
    86c0:	b4000793 	cbz	x19, 87b0 <fwp_hof0.constprop.0+0x280>
    86c4:	38636880 	ldrb	w0, [x4, x3]
    86c8:	7100081f 	cmp	w0, #0x2
    86cc:	5400a5a0 	b.eq	9b80 <fwp_hof0.constprop.0+0x1650>  // b.none
    86d0:	7100041f 	cmp	w0, #0x1
    86d4:	540006e1 	b.ne	87b0 <fwp_hof0.constprop.0+0x280>  // b.any
    86d8:	29430c44 	ldp	w4, w3, [x2, #24]
    86dc:	92403c20 	and	x0, x1, #0xffff
    86e0:	9b047c00 	mul	x0, x0, x4
    86e4:	d360fc00 	lsr	x0, x0, #32
    86e8:	eb03001f 	cmp	x0, x3
    86ec:	54000382 	b.cs	875c <fwp_hof0.constprop.0+0x22c>  // b.hs, b.nlast
    86f0:	8b000260 	add	x0, x19, x0
    86f4:	39400003 	ldrb	w3, [x0]
    86f8:	34000323 	cbz	w3, 875c <fwp_hof0.constprop.0+0x22c>
    86fc:	900000c1 	adrp	x1, 20000 <__data_start>
    8700:	91014021 	add	x1, x1, #0x50
    8704:	b9413022 	ldr	w2, [x1, #304]
    8708:	34000082 	cbz	w2, 8718 <fwp_hof0.constprop.0+0x1e8>
    870c:	f940ac22 	ldr	x2, [x1, #344]
    8710:	91000442 	add	x2, x2, #0x1
    8714:	f900ac22 	str	x2, [x1, #344]
    8718:	7103f47f 	cmp	w3, #0xfd
    871c:	5400c0a8 	b.hi	9f30 <fwp_hof0.constprop.0+0x1a00>  // b.pmore
    8720:	11000463 	add	w3, w3, #0x1
    8724:	39000003 	strb	w3, [x0]
    8728:	9118c280 	add	x0, x20, #0x630
    872c:	f94017e3 	ldr	x3, [sp, #40]
    8730:	f949d801 	ldr	x1, [x0, #5040]
    8734:	f949ec02 	ldr	x2, [x0, #5080]
    8738:	cb010061 	sub	x1, x3, x1
    873c:	eb02403f 	cmp	x1, x2, lsl #16
    8740:	54000382 	b.cs	87b0 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    8744:	f949fc00 	ldr	x0, [x0, #5112]
    8748:	d350fc22 	lsr	x2, x1, #16
    874c:	8b020842 	add	x2, x2, x2, lsl #2
    8750:	8b020c02 	add	x2, x0, x2, lsl #3
    8754:	f9401053 	ldr	x19, [x2, #32]
    8758:	b40002d3 	cbz	x19, 87b0 <fwp_hof0.constprop.0+0x280>
    875c:	39400040 	ldrb	w0, [x2]
    8760:	7100081f 	cmp	w0, #0x2
    8764:	5400a160 	b.eq	9b90 <fwp_hof0.constprop.0+0x1660>  // b.none
    8768:	7100041f 	cmp	w0, #0x1
    876c:	54000221 	b.ne	87b0 <fwp_hof0.constprop.0+0x280>  // b.any
    8770:	29430043 	ldp	w3, w0, [x2, #24]
    8774:	92403c21 	and	x1, x1, #0xffff
    8778:	9b037c21 	mul	x1, x1, x3
    877c:	d360fc21 	lsr	x1, x1, #32
    8780:	eb00003f 	cmp	x1, x0
    8784:	54000162 	b.cs	87b0 <fwp_hof0.constprop.0+0x280>  // b.hs, b.nlast
    8788:	8b010273 	add	x19, x19, x1
    878c:	39400261 	ldrb	w1, [x19]
    8790:	34000101 	cbz	w1, 87b0 <fwp_hof0.constprop.0+0x280>
    8794:	7100043f 	cmp	w1, #0x1
    8798:	540075a0 	b.eq	964c <fwp_hof0.constprop.0+0x111c>  // b.none
    879c:	7103fc3f 	cmp	w1, #0xff
    87a0:	5400bcc0 	b.eq	9f38 <fwp_hof0.constprop.0+0x1a08>  // b.none
    87a4:	51000421 	sub	w1, w1, #0x1
    87a8:	39000261 	strb	w1, [x19]
    87ac:	d503201f 	nop
    87b0:	b40075f5 	cbz	x21, 966c <fwp_hof0.constprop.0+0x113c>
    87b4:	aa1503e0 	mov	x0, x21
    87b8:	d2800001 	mov	x1, #0x0                   	// #0
    87bc:	d503201f 	nop
    87c0:	f9400800 	ldr	x0, [x0, #16]
    87c4:	91000421 	add	x1, x1, #0x1
    87c8:	b5ffffc0 	cbnz	x0, 87c0 <fwp_hof0.constprop.0+0x290>
    87cc:	aa0103f6 	mov	x22, x1
    87d0:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    87d4:	eb00003f 	cmp	x1, x0
    87d8:	5400c4a8 	b.hi	a06c <fwp_hof0.constprop.0+0x1b3c>  // b.pmore
    87dc:	900000c0 	adrp	x0, 20000 <__data_start>
    87e0:	91014013 	add	x19, x0, #0x50
    87e4:	b943c660 	ldr	w0, [x19, #964]
    87e8:	340074c0 	cbz	w0, 9680 <fwp_hof0.constprop.0+0x1150>
    87ec:	900000c0 	adrp	x0, 20000 <__data_start>
    87f0:	91014000 	add	x0, x0, #0x50
    87f4:	f9406c13 	ldr	x19, [x0, #216]
    87f8:	f940b017 	ldr	x23, [x0, #352]
    87fc:	eb1302ff 	cmp	x23, x19
    8800:	5400758a 	b.ge	96b0 <fwp_hof0.constprop.0+0x1180>  // b.tcont
    8804:	f9404401 	ldr	x1, [x0, #136]
    8808:	8b1706e0 	add	x0, x23, x23, lsl #1
    880c:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8810:	8b000ae0 	add	x0, x23, x0, lsl #2
    8814:	8b000c20 	add	x0, x1, x0, lsl #3
    8818:	b9400401 	ldr	w1, [x0, #4]
    881c:	35000081 	cbnz	w1, 882c <fwp_hof0.constprop.0+0x2fc>
    8820:	b9400001 	ldr	w1, [x0]
    8824:	6b02003f 	cmp	w1, w2
    8828:	54007449 	b.ls	96b0 <fwp_hof0.constprop.0+0x1180>  // b.plast
    882c:	910006f7 	add	x23, x23, #0x1
    8830:	9101a000 	add	x0, x0, #0x68
    8834:	eb1302ff 	cmp	x23, x19
    8838:	54ffff01 	b.ne	8818 <fwp_hof0.constprop.0+0x2e8>  // b.any
    883c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8840:	eb00027f 	cmp	x19, x0
    8844:	5400c1ac 	b.gt	a078 <fwp_hof0.constprop.0+0x1b48>
    8848:	900000c0 	adrp	x0, 20000 <__data_start>
    884c:	91014000 	add	x0, x0, #0x50
    8850:	f9409001 	ldr	x1, [x0, #288]
    8854:	f940441c 	ldr	x28, [x0, #136]
    8858:	eb13003f 	cmp	x1, x19
    885c:	54000241 	b.ne	88a4 <fwp_hof0.constprop.0+0x374>  // b.any
    8860:	b400a873 	cbz	x19, 9d6c <fwp_hof0.constprop.0+0x183c>
    8864:	d37ffa7b 	lsl	x27, x19, #1
    8868:	d29fffe0 	mov	x0, #0xffff                	// #65535
    886c:	eb00037f 	cmp	x27, x0
    8870:	9a80d37b 	csel	x27, x27, x0, le
    8874:	8b1b0761 	add	x1, x27, x27, lsl #1
    8878:	8b010b61 	add	x1, x27, x1, lsl #2
    887c:	d37df021 	lsl	x1, x1, #3
    8880:	aa1c03e0 	mov	x0, x28
    8884:	52800002 	mov	w2, #0x0                   	// #0
    8888:	97ffeef3 	bl	4454 <ad_raw_realloc>
    888c:	aa0003fc 	mov	x28, x0
    8890:	b4003800 	cbz	x0, 8f90 <fwp_hof0.constprop.0+0xa60>
    8894:	900000c0 	adrp	x0, 20000 <__data_start>
    8898:	91014000 	add	x0, x0, #0x50
    889c:	f900441c 	str	x28, [x0, #136]
    88a0:	f900901b 	str	x27, [x0, #288]
    88a4:	8b130660 	add	x0, x19, x19, lsl #1
    88a8:	8b1706fb 	add	x27, x23, x23, lsl #1
    88ac:	4f000400 	movi	v0.4s, #0x0
    88b0:	91000662 	add	x2, x19, #0x1
    88b4:	8b000a60 	add	x0, x19, x0, lsl #2
    88b8:	8b1b0afb 	add	x27, x23, x27, lsl #2
    88bc:	900000c1 	adrp	x1, 20000 <__data_start>
    88c0:	91014021 	add	x1, x1, #0x50
    88c4:	8b000f80 	add	x0, x28, x0, lsl #3
    88c8:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    88cc:	f9006c22 	str	x2, [x1, #216]
    88d0:	ad000000 	stp	q0, q0, [x0]
    88d4:	ad010000 	stp	q0, q0, [x0, #32]
    88d8:	ad020000 	stp	q0, q0, [x0, #64]
    88dc:	f900301f 	str	xzr, [x0, #96]
    88e0:	b0000020 	adrp	x0, d000 <__divti3+0x2b0>
    88e4:	f900337f 	str	xzr, [x27, #96]
    88e8:	9121c000 	add	x0, x0, #0x870
    88ec:	97ffe851 	bl	2a30 <getenv@plt>
    88f0:	b4006fa0 	cbz	x0, 96e4 <fwp_hof0.constprop.0+0x11b4>
    88f4:	39400001 	ldrb	w1, [x0]
    88f8:	7100c03f 	cmp	w1, #0x30
    88fc:	54006f41 	b.ne	96e4 <fwp_hof0.constprop.0+0x11b4>  // b.any
    8900:	39400400 	ldrb	w0, [x0, #1]
    8904:	35006f00 	cbnz	w0, 96e4 <fwp_hof0.constprop.0+0x11b4>
    8908:	900000c0 	adrp	x0, 20000 <__data_start>
    890c:	91014000 	add	x0, x0, #0x50
    8910:	2f000400 	mvni	v0.2s, #0x0
    8914:	b9400373 	ldr	w19, [x27]
    8918:	52800022 	mov	w2, #0x1                   	// #1
    891c:	910006e4 	add	x4, x23, #0x1
    8920:	f941c801 	ldr	x1, [x0, #912]
    8924:	0b020273 	add	w19, w19, w2
    8928:	29000b73 	stp	w19, w2, [x27]
    892c:	a900db76 	stp	x22, x22, [x27, #8]
    8930:	f9002b7f 	str	xzr, [x27, #80]
    8934:	f900b004 	str	x4, [x0, #352]
    8938:	fd002f60 	str	d0, [x27, #88]
    893c:	b400ba41 	cbz	x1, a084 <fwp_hof0.constprop.0+0x1b54>
    8940:	d0ffffe0 	adrp	x0, 6000 <fwp_drop0+0x30>
    8944:	9112c003 	add	x3, x0, #0x4b0
    8948:	14000003 	b	8954 <fwp_hof0.constprop.0+0x424>
    894c:	f9400021 	ldr	x1, [x1]
    8950:	b400b9a1 	cbz	x1, a084 <fwp_hof0.constprop.0+0x1b54>
    8954:	f9400422 	ldr	x2, [x1, #8]
    8958:	eb03005f 	cmp	x2, x3
    895c:	54ffff81 	b.ne	894c <fwp_hof0.constprop.0+0x41c>  // b.any
    8960:	f9400820 	ldr	x0, [x1, #16]
    8964:	2a1703e2 	mov	w2, w23
    8968:	b9400001 	ldr	w1, [x0]
    896c:	f9002b60 	str	x0, [x27, #80]
    8970:	b9005f61 	str	w1, [x27, #92]
    8974:	37f80081 	tbnz	w1, #31, 8984 <fwp_hof0.constprop.0+0x454>
    8978:	52800d03 	mov	w3, #0x68                  	// #104
    897c:	9b237021 	smaddl	x1, w1, w3, x28
    8980:	b9005837 	str	w23, [x1, #88]
    8984:	b9000002 	str	w2, [x0]
    8988:	d3707e73 	ubfiz	x19, x19, #16, #32
    898c:	aa040273 	orr	x19, x19, x4
    8990:	aa1503e0 	mov	x0, x21
    8994:	d2800002 	mov	x2, #0x0                   	// #0
    8998:	b4007255 	cbz	x21, 97e0 <fwp_hof0.constprop.0+0x12b0>
    899c:	d503201f 	nop
    89a0:	f9400800 	ldr	x0, [x0, #16]
    89a4:	91000442 	add	x2, x2, #0x1
    89a8:	b5ffffc0 	cbnz	x0, 89a0 <fwp_hof0.constprop.0+0x470>
    89ac:	aa1503e1 	mov	x1, x21
    89b0:	f9400821 	ldr	x1, [x1, #16]
    89b4:	91000400 	add	x0, x0, #0x1
    89b8:	b5ffffc1 	cbnz	x1, 89b0 <fwp_hof0.constprop.0+0x480>
    89bc:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    89c0:	eb01001f 	cmp	x0, x1
    89c4:	5400b3a8 	b.hi	a038 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    89c8:	f100005f 	cmp	x2, #0x0
    89cc:	540070ad 	b.le	97e0 <fwp_hof0.constprop.0+0x12b0>
    89d0:	eb00005f 	cmp	x2, x0
    89d4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    89d8:	9a809056 	csel	x22, x2, x0, ls	// ls = plast
    89dc:	eb0102df 	cmp	x22, x1
    89e0:	5400b2c8 	b.hi	a038 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    89e4:	d37ffadc 	lsl	x28, x22, #1
    89e8:	52800041 	mov	w1, #0x2                   	// #2
    89ec:	91000780 	add	x0, x28, #0x1
    89f0:	d37df000 	lsl	x0, x0, #3
    89f4:	97fff1c7 	bl	5110 <fwp_heap_alloc>
    89f8:	aa0003f7 	mov	x23, x0
    89fc:	9118c281 	add	x1, x20, #0x630
    8a00:	aa0003fb 	mov	x27, x0
    8a04:	aa0103e0 	mov	x0, x1
    8a08:	f90002fc 	str	x28, [x23]
    8a0c:	f949d821 	ldr	x1, [x1, #5040]
    8a10:	f949ec00 	ldr	x0, [x0, #5080]
    8a14:	cb0102e1 	sub	x1, x23, x1
    8a18:	eb00403f 	cmp	x1, x0, lsl #16
    8a1c:	540080e2 	b.cs	9a38 <fwp_hof0.constprop.0+0x1508>  // b.hs, b.nlast
    8a20:	9118c282 	add	x2, x20, #0x630
    8a24:	d350fc20 	lsr	x0, x1, #16
    8a28:	8b000800 	add	x0, x0, x0, lsl #2
    8a2c:	f949fc43 	ldr	x3, [x2, #5112]
    8a30:	d37df002 	lsl	x2, x0, #3
    8a34:	8b020060 	add	x0, x3, x2
    8a38:	f940101c 	ldr	x28, [x0, #32]
    8a3c:	b400025c 	cbz	x28, 8a84 <fwp_hof0.constprop.0+0x554>
    8a40:	38626862 	ldrb	w2, [x3, x2]
    8a44:	7100085f 	cmp	w2, #0x2
    8a48:	54008aa0 	b.eq	9b9c <fwp_hof0.constprop.0+0x166c>  // b.none
    8a4c:	7100045f 	cmp	w2, #0x1
    8a50:	540001a1 	b.ne	8a84 <fwp_hof0.constprop.0+0x554>  // b.any
    8a54:	29430002 	ldp	w2, w0, [x0, #24]
    8a58:	92403c21 	and	x1, x1, #0xffff
    8a5c:	9b027c21 	mul	x1, x1, x2
    8a60:	d360fc21 	lsr	x1, x1, #32
    8a64:	eb00003f 	cmp	x1, x0
    8a68:	540000e2 	b.cs	8a84 <fwp_hof0.constprop.0+0x554>  // b.hs, b.nlast
    8a6c:	8b01039c 	add	x28, x28, x1
    8a70:	39400380 	ldrb	w0, [x28]
    8a74:	7103fc1f 	cmp	w0, #0xff
    8a78:	540089c0 	b.eq	9bb0 <fwp_hof0.constprop.0+0x1680>  // b.none
    8a7c:	52800020 	mov	w0, #0x1                   	// #1
    8a80:	39000380 	strb	w0, [x28]
    8a84:	b4000236 	cbz	x22, 8ac8 <fwp_hof0.constprop.0+0x598>
    8a88:	d3607e64 	lsl	x4, x19, #32
    8a8c:	aa1503e1 	mov	x1, x21
    8a90:	f94006a5 	ldr	x5, [x21, #8]
    8a94:	aa0403e3 	mov	x3, x4
    8a98:	910022e2 	add	x2, x23, #0x8
    8a9c:	d2800000 	mov	x0, #0x0                   	// #0
    8aa0:	14000005 	b	8ab4 <fwp_hof0.constprop.0+0x584>
    8aa4:	f9400425 	ldr	x5, [x1, #8]
    8aa8:	ab040003 	adds	x3, x0, x4
    8aac:	91004042 	add	x2, x2, #0x10
    8ab0:	5400b046 	b.vs	a0b8 <fwp_hof0.constprop.0+0x1b88>
    8ab4:	a9000c45 	stp	x5, x3, [x2]
    8ab8:	91000400 	add	x0, x0, #0x1
    8abc:	f9400821 	ldr	x1, [x1, #16]
    8ac0:	eb16001f 	cmp	x0, x22
    8ac4:	54ffff03 	b.cc	8aa4 <fwp_hof0.constprop.0+0x574>  // b.lo, b.ul, b.last
    8ac8:	f94002e0 	ldr	x0, [x23]
    8acc:	f100041f 	cmp	x0, #0x1
    8ad0:	54007b89 	b.ls	9a40 <fwp_hof0.constprop.0+0x1510>  // b.plast
    8ad4:	d341fc00 	lsr	x0, x0, #1
    8ad8:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    8adc:	d1000401 	sub	x1, x0, #0x1
    8ae0:	eb02003f 	cmp	x1, x2
    8ae4:	5400aaa8 	b.hi	a038 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    8ae8:	d37ff83c 	lsl	x28, x1, #1
    8aec:	b4007aa1 	cbz	x1, 9a40 <fwp_hof0.constprop.0+0x1510>
    8af0:	d10022e1 	sub	x1, x23, #0x8
    8af4:	910022f8 	add	x24, x23, #0x8
    8af8:	8b001036 	add	x22, x1, x0, lsl #4
    8afc:	d503201f 	nop
    8b00:	f9400700 	ldr	x0, [x24, #8]
    8b04:	f9400f01 	ldr	x1, [x24, #24]
    8b08:	fd400300 	ldr	d0, [x24]
    8b0c:	fd400b01 	ldr	d1, [x24, #16]
    8b10:	97fff324 	bl	57a0 <w120>
    8b14:	a9000700 	stp	x0, x1, [x24]
    8b18:	91004318 	add	x24, x24, #0x10
    8b1c:	eb16031f 	cmp	x24, x22
    8b20:	54ffff01 	b.ne	8b00 <fwp_hof0.constprop.0+0x5d0>  // b.any
    8b24:	9118c296 	add	x22, x20, #0x630
    8b28:	f90002fc 	str	x28, [x23]
    8b2c:	aa1703e0 	mov	x0, x23
    8b30:	97fff379 	bl	5914 <w176.constprop.0>
    8b34:	aa0103fc 	mov	x28, x1
    8b38:	f949dac1 	ldr	x1, [x22, #5040]
    8b3c:	f949eec0 	ldr	x0, [x22, #5080]
    8b40:	cb0102e1 	sub	x1, x23, x1
    8b44:	eb00403f 	cmp	x1, x0, lsl #16
    8b48:	54000382 	b.cs	8bb8 <fwp_hof0.constprop.0+0x688>  // b.hs, b.nlast
    8b4c:	d350fc20 	lsr	x0, x1, #16
    8b50:	f949fec4 	ldr	x4, [x22, #5112]
    8b54:	8b000800 	add	x0, x0, x0, lsl #2
    8b58:	d37df000 	lsl	x0, x0, #3
    8b5c:	8b000082 	add	x2, x4, x0
    8b60:	f9401057 	ldr	x23, [x2, #32]
    8b64:	b40002b7 	cbz	x23, 8bb8 <fwp_hof0.constprop.0+0x688>
    8b68:	38606880 	ldrb	w0, [x4, x0]
    8b6c:	7100081f 	cmp	w0, #0x2
    8b70:	540076c0 	b.eq	9a48 <fwp_hof0.constprop.0+0x1518>  // b.none
    8b74:	7100041f 	cmp	w0, #0x1
    8b78:	54000201 	b.ne	8bb8 <fwp_hof0.constprop.0+0x688>  // b.any
    8b7c:	29430043 	ldp	w3, w0, [x2, #24]
    8b80:	92403c21 	and	x1, x1, #0xffff
    8b84:	9b037c21 	mul	x1, x1, x3
    8b88:	d360fc21 	lsr	x1, x1, #32
    8b8c:	eb00003f 	cmp	x1, x0
    8b90:	54000142 	b.cs	8bb8 <fwp_hof0.constprop.0+0x688>  // b.hs, b.nlast
    8b94:	8b0102f7 	add	x23, x23, x1
    8b98:	394002e0 	ldrb	w0, [x23]
    8b9c:	340000e0 	cbz	w0, 8bb8 <fwp_hof0.constprop.0+0x688>
    8ba0:	7100041f 	cmp	w0, #0x1
    8ba4:	540020e0 	b.eq	8fc0 <fwp_hof0.constprop.0+0xa90>  // b.none
    8ba8:	7103fc1f 	cmp	w0, #0xff
    8bac:	540090c0 	b.eq	9dc4 <fwp_hof0.constprop.0+0x1894>  // b.none
    8bb0:	51000400 	sub	w0, w0, #0x1
    8bb4:	390002e0 	strb	w0, [x23]
    8bb8:	93407e73 	sxtw	x19, w19
    8bbc:	aa1303e0 	mov	x0, x19
    8bc0:	97ffebdc 	bl	3b30 <fwp_tape_of>
    8bc4:	f9403001 	ldr	x1, [x0, #96]
    8bc8:	aa0003ea 	mov	x10, x0
    8bcc:	b500a4a1 	cbnz	x1, a060 <fwp_hof0.constprop.0+0x1b30>
    8bd0:	97ffe911 	bl	3014 <fwp_tape_unlink_scope>
    8bd4:	b9400002 	ldr	w2, [x0]
    8bd8:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    8bdc:	a9408018 	ldp	x24, x0, [x0, #8]
    8be0:	b900055f 	str	wzr, [x10, #4]
    8be4:	a941e94b 	ldp	x11, x26, [x10, #24]
    8be8:	a942a15b 	ldp	x27, x8, [x10, #40]
    8bec:	a943e549 	ldp	x9, x25, [x10, #56]
    8bf0:	f9402557 	ldr	x23, [x10, #72]
    8bf4:	6b01005f 	cmp	w2, w1
    8bf8:	54000128 	b.hi	8c1c <fwp_hof0.constprop.0+0x6ec>  // b.pmore
    8bfc:	900000c1 	adrp	x1, 20000 <__data_start>
    8c00:	91014022 	add	x2, x1, #0x50
    8c04:	92403e61 	and	x1, x19, #0xffff
    8c08:	d1000421 	sub	x1, x1, #0x1
    8c0c:	f940b043 	ldr	x3, [x2, #352]
    8c10:	eb03003f 	cmp	x1, x3
    8c14:	5400004a 	b.ge	8c1c <fwp_hof0.constprop.0+0x6ec>  // b.tcont
    8c18:	f900b041 	str	x1, [x2, #352]
    8c1c:	4f000400 	movi	v0.4s, #0x0
    8c20:	900000c1 	adrp	x1, 20000 <__data_start>
    8c24:	91014023 	add	x3, x1, #0x50
    8c28:	f9000d5f 	str	xzr, [x10, #24]
    8c2c:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    8c30:	910243e4 	add	x4, sp, #0x90
    8c34:	9101e3e1 	add	x1, sp, #0x78
    8c38:	f941c86c 	ldr	x12, [x3, #912]
    8c3c:	3c808140 	stur	q0, [x10, #8]
    8c40:	90ffffe2 	adrp	x2, 4000 <fwp_heap_report+0x60>
    8c44:	ad010140 	stp	q0, q0, [x10, #32]
    8c48:	91149042 	add	x2, x2, #0x524
    8c4c:	f9000be4 	str	x4, [sp, #16]
    8c50:	a9078bec 	stp	x12, x2, [sp, #120]
    8c54:	a908ebe4 	stp	x4, x26, [sp, #136]
    8c58:	a909a3fb 	stp	x27, x8, [sp, #152]
    8c5c:	a90ae7e9 	stp	x9, x25, [sp, #168]
    8c60:	a90bdfeb 	stp	x11, x23, [sp, #184]
    8c64:	f901c861 	str	x1, [x3, #912]
    8c68:	b7f87abc 	tbnz	x28, #63, 9bbc <fwp_hof0.constprop.0+0x168c>
    8c6c:	eb9c827f 	cmp	x19, x28, asr #32
    8c70:	54009ac1 	b.ne	9fc8 <fwp_hof0.constprop.0+0x1a98>  // b.any
    8c74:	92407f96 	and	x22, x28, #0xffffffff
    8c78:	eb3c401f 	cmp	x0, w28, uxtw
    8c7c:	5400994d 	b.le	9fa4 <fwp_hof0.constprop.0+0x1a74>
    8c80:	eb16031f 	cmp	x24, x22
    8c84:	9a96c716 	csinc	x22, x24, x22, gt
    8c88:	eb1602ff 	cmp	x23, x22
    8c8c:	540016ca 	b.ge	8f64 <fwp_hof0.constprop.0+0xa34>  // b.tcont
    8c90:	f10002ff 	cmp	x23, #0x0
    8c94:	9a9612f7 	csel	x23, x23, x22, ne	// ne = any
    8c98:	14000005 	b	8cac <fwp_hof0.constprop.0+0x77c>
    8c9c:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    8ca0:	eb0002ff 	cmp	x23, x0
    8ca4:	d37ffaf7 	lsl	x23, x23, #1
    8ca8:	9a96d2f7 	csel	x23, x23, x22, le
    8cac:	eb1602ff 	cmp	x23, x22
    8cb0:	54ffff6b 	b.lt	8c9c <fwp_hof0.constprop.0+0x76c>  // b.tstop
    8cb4:	b4008099 	cbz	x25, 9cc4 <fwp_hof0.constprop.0+0x1794>
    8cb8:	aa1903e0 	mov	x0, x25
    8cbc:	d37df2e1 	lsl	x1, x23, #3
    8cc0:	52800062 	mov	w2, #0x3                   	// #3
    8cc4:	a90327e8 	stp	x8, x9, [sp, #48]
    8cc8:	97ffede3 	bl	4454 <ad_raw_realloc>
    8ccc:	a94327e8 	ldp	x8, x9, [sp, #48]
    8cd0:	aa0003f9 	mov	x25, x0
    8cd4:	b4007e40 	cbz	x0, 9c9c <fwp_hof0.constprop.0+0x176c>
    8cd8:	f9005bf9 	str	x25, [sp, #176]
    8cdc:	f90063f7 	str	x23, [sp, #192]
    8ce0:	b5001356 	cbnz	x22, 8f48 <fwp_hof0.constprop.0+0xa18>
    8ce4:	b7f800dc 	tbnz	x28, #63, 8cfc <fwp_hof0.constprop.0+0x7cc>
    8ce8:	92407f81 	and	x1, x28, #0xffffffff
    8cec:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8cf0:	fc617b20 	ldr	d0, [x25, x1, lsl #3]
    8cf4:	1e612800 	fadd	d0, d0, d1
    8cf8:	fc217b20 	str	d0, [x25, x1, lsl #3]
    8cfc:	d10006d6 	sub	x22, x22, #0x1
    8d00:	d1000703 	sub	x3, x24, #0x1
    8d04:	eb16031f 	cmp	x24, x22
    8d08:	540003ac 	b.gt	8d7c <fwp_hof0.constprop.0+0x84c>
    8d0c:	fc767b20 	ldr	d0, [x25, x22, lsl #3]
    8d10:	1e602008 	fcmp	d0, #0.0
    8d14:	540002e0 	b.eq	8d70 <fwp_hof0.constprop.0+0x840>  // b.none
    8d18:	cb180be0 	neg	x0, x24, lsl #2
    8d1c:	cb1803e2 	neg	x2, x24
    8d20:	8b000341 	add	x1, x26, x0
    8d24:	b8767821 	ldr	w1, [x1, x22, lsl #2]
    8d28:	37f80101 	tbnz	w1, #31, 8d48 <fwp_hof0.constprop.0+0x818>
    8d2c:	8b020d0a 	add	x10, x8, x2, lsl #3
    8d30:	93407c21 	sxtw	x1, w1
    8d34:	fc767942 	ldr	d2, [x10, x22, lsl #3]
    8d38:	fc617b21 	ldr	d1, [x25, x1, lsl #3]
    8d3c:	1e620802 	fmul	d2, d0, d2
    8d40:	1e622821 	fadd	d1, d1, d2
    8d44:	fc217b21 	str	d1, [x25, x1, lsl #3]
    8d48:	8b000360 	add	x0, x27, x0
    8d4c:	b8767800 	ldr	w0, [x0, x22, lsl #2]
    8d50:	37f80100 	tbnz	w0, #31, 8d70 <fwp_hof0.constprop.0+0x840>
    8d54:	8b020d22 	add	x2, x9, x2, lsl #3
    8d58:	93407c00 	sxtw	x0, w0
    8d5c:	fc767842 	ldr	d2, [x2, x22, lsl #3]
    8d60:	fc607b21 	ldr	d1, [x25, x0, lsl #3]
    8d64:	1e620800 	fmul	d0, d0, d2
    8d68:	1e602820 	fadd	d0, d1, d0
    8d6c:	fc207b20 	str	d0, [x25, x0, lsl #3]
    8d70:	d10006d6 	sub	x22, x22, #0x1
    8d74:	eb16007f 	cmp	x3, x22
    8d78:	54fffca1 	b.ne	8d0c <fwp_hof0.constprop.0+0x7dc>  // b.any
    8d7c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    8d80:	eb00031f 	cmp	x24, x0
    8d84:	540098c8 	b.hi	a09c <fwp_hof0.constprop.0+0x1b6c>  // b.pmore
    8d88:	91000700 	add	x0, x24, #0x1
    8d8c:	52800041 	mov	w1, #0x2                   	// #2
    8d90:	d37df000 	lsl	x0, x0, #3
    8d94:	97fff0df 	bl	5110 <fwp_heap_alloc>
    8d98:	aa0003e2 	mov	x2, x0
    8d9c:	aa0003f3 	mov	x19, x0
    8da0:	d2800001 	mov	x1, #0x0                   	// #0
    8da4:	f8008458 	str	x24, [x2], #8
    8da8:	b40000f8 	cbz	x24, 8dc4 <fwp_hof0.constprop.0+0x894>
    8dac:	d503201f 	nop
    8db0:	f8617b20 	ldr	x0, [x25, x1, lsl #3]
    8db4:	f8217840 	str	x0, [x2, x1, lsl #3]
    8db8:	91000421 	add	x1, x1, #0x1
    8dbc:	eb01031f 	cmp	x24, x1
    8dc0:	54ffff81 	b.ne	8db0 <fwp_hof0.constprop.0+0x880>  // b.any
    8dc4:	900000c0 	adrp	x0, 20000 <__data_start>
    8dc8:	91014001 	add	x1, x0, #0x50
    8dcc:	f9400be0 	ldr	x0, [sp, #16]
    8dd0:	f9403ff7 	ldr	x23, [sp, #120]
    8dd4:	f901c837 	str	x23, [x1, #912]
    8dd8:	97ffedd3 	bl	4524 <fwp_tape_buffers_release>
    8ddc:	9118c282 	add	x2, x20, #0x630
    8de0:	f949d841 	ldr	x1, [x2, #5040]
    8de4:	f949ec40 	ldr	x0, [x2, #5080]
    8de8:	cb010261 	sub	x1, x19, x1
    8dec:	eb00403f 	cmp	x1, x0, lsl #16
    8df0:	54000322 	b.cs	8e54 <fwp_hof0.constprop.0+0x924>  // b.hs, b.nlast
    8df4:	d350fc20 	lsr	x0, x1, #16
    8df8:	f949fc43 	ldr	x3, [x2, #5112]
    8dfc:	8b000800 	add	x0, x0, x0, lsl #2
    8e00:	d37df002 	lsl	x2, x0, #3
    8e04:	8b020060 	add	x0, x3, x2
    8e08:	f9401016 	ldr	x22, [x0, #32]
    8e0c:	b4000256 	cbz	x22, 8e54 <fwp_hof0.constprop.0+0x924>
    8e10:	38626862 	ldrb	w2, [x3, x2]
    8e14:	7100085f 	cmp	w2, #0x2
    8e18:	54006d60 	b.eq	9bc4 <fwp_hof0.constprop.0+0x1694>  // b.none
    8e1c:	7100045f 	cmp	w2, #0x1
    8e20:	540001a1 	b.ne	8e54 <fwp_hof0.constprop.0+0x924>  // b.any
    8e24:	29430002 	ldp	w2, w0, [x0, #24]
    8e28:	92403c21 	and	x1, x1, #0xffff
    8e2c:	9b027c21 	mul	x1, x1, x2
    8e30:	d360fc21 	lsr	x1, x1, #32
    8e34:	eb00003f 	cmp	x1, x0
    8e38:	540000e2 	b.cs	8e54 <fwp_hof0.constprop.0+0x924>  // b.hs, b.nlast
    8e3c:	8b0102d6 	add	x22, x22, x1
    8e40:	394002c0 	ldrb	w0, [x22]
    8e44:	7103fc1f 	cmp	w0, #0xff
    8e48:	54006c80 	b.eq	9bd8 <fwp_hof0.constprop.0+0x16a8>  // b.none
    8e4c:	52800020 	mov	w0, #0x1                   	// #1
    8e50:	390002c0 	strb	w0, [x22]
    8e54:	f94013e0 	ldr	x0, [sp, #32]
    8e58:	eb0002ff 	cmp	x23, x0
    8e5c:	540092c1 	b.ne	a0b4 <fwp_hof0.constprop.0+0x1b84>  // b.any
    8e60:	900000c0 	adrp	x0, 20000 <__data_start>
    8e64:	91014001 	add	x1, x0, #0x50
    8e68:	f9400fe0 	ldr	x0, [sp, #24]
    8e6c:	f94033e2 	ldr	x2, [sp, #96]
    8e70:	f901c822 	str	x2, [x1, #912]
    8e74:	97fff58f 	bl	64b0 <fwp_tape_scope_release>
    8e78:	f9400260 	ldr	x0, [x19]
    8e7c:	9240f817 	and	x23, x0, #0x7fffffffffffffff
    8e80:	b7f845c0 	tbnz	x0, #63, 9738 <fwp_hof0.constprop.0+0x1208>
    8e84:	9118c282 	add	x2, x20, #0x630
    8e88:	f949d840 	ldr	x0, [x2, #5040]
    8e8c:	f949ec41 	ldr	x1, [x2, #5080]
    8e90:	cb000260 	sub	x0, x19, x0
    8e94:	eb01401f 	cmp	x0, x1, lsl #16
    8e98:	54004502 	b.cs	9738 <fwp_hof0.constprop.0+0x1208>  // b.hs, b.nlast
    8e9c:	d350fc01 	lsr	x1, x0, #16
    8ea0:	f949fc44 	ldr	x4, [x2, #5112]
    8ea4:	8b010821 	add	x1, x1, x1, lsl #2
    8ea8:	d37df021 	lsl	x1, x1, #3
    8eac:	8b010083 	add	x3, x4, x1
    8eb0:	f9401062 	ldr	x2, [x3, #32]
    8eb4:	b4004422 	cbz	x2, 9738 <fwp_hof0.constprop.0+0x1208>
    8eb8:	38616881 	ldrb	w1, [x4, x1]
    8ebc:	7100083f 	cmp	w1, #0x2
    8ec0:	54004360 	b.eq	972c <fwp_hof0.constprop.0+0x11fc>  // b.none
    8ec4:	7100043f 	cmp	w1, #0x1
    8ec8:	54004381 	b.ne	9738 <fwp_hof0.constprop.0+0x1208>  // b.any
    8ecc:	29430464 	ldp	w4, w1, [x3, #24]
    8ed0:	92403c00 	and	x0, x0, #0xffff
    8ed4:	9b047c00 	mul	x0, x0, x4
    8ed8:	d360fc00 	lsr	x0, x0, #32
    8edc:	eb01001f 	cmp	x0, x1
    8ee0:	540042c2 	b.cs	9738 <fwp_hof0.constprop.0+0x1208>  // b.hs, b.nlast
    8ee4:	8b000042 	add	x2, x2, x0
    8ee8:	39400040 	ldrb	w0, [x2]
    8eec:	7100041f 	cmp	w0, #0x1
    8ef0:	54004241 	b.ne	9738 <fwp_hof0.constprop.0+0x1208>  // b.any
    8ef4:	aa1303fc 	mov	x28, x19
    8ef8:	aa1303f6 	mov	x22, x19
    8efc:	d2800000 	mov	x0, #0x0                   	// #0
    8f00:	910022c3 	add	x3, x22, #0x8
    8f04:	91002265 	add	x5, x19, #0x8
    8f08:	d2800001 	mov	x1, #0x0                   	// #0
    8f0c:	b5000157 	cbnz	x23, 8f34 <fwp_hof0.constprop.0+0xa04>
    8f10:	1400004d 	b	9044 <fwp_hof0.constprop.0+0xb14>
    8f14:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    8f18:	f9400382 	ldr	x2, [x28]
    8f1c:	1e600900 	fmul	d0, d8, d0
    8f20:	b7f88862 	tbnz	x2, #63, a02c <fwp_hof0.constprop.0+0x1afc>
    8f24:	91000421 	add	x1, x1, #0x1
    8f28:	fc008460 	str	d0, [x3], #8
    8f2c:	eb0102ff 	cmp	x23, x1
    8f30:	540008a0 	b.eq	9044 <fwp_hof0.constprop.0+0xb14>  // b.none
    8f34:	f9400264 	ldr	x4, [x19]
    8f38:	aa0503e2 	mov	x2, x5
    8f3c:	b6fffec4 	tbz	x4, #63, 8f14 <fwp_hof0.constprop.0+0x9e4>
    8f40:	f9400a62 	ldr	x2, [x19, #16]
    8f44:	17fffff4 	b	8f14 <fwp_hof0.constprop.0+0x9e4>
    8f48:	d37df2c2 	lsl	x2, x22, #3
    8f4c:	aa1903e0 	mov	x0, x25
    8f50:	52800001 	mov	w1, #0x0                   	// #0
    8f54:	a90327e8 	stp	x8, x9, [sp, #48]
    8f58:	97ffe646 	bl	2870 <memset@plt>
    8f5c:	a94327e8 	ldp	x8, x9, [sp, #48]
    8f60:	17ffff61 	b	8ce4 <fwp_hof0.constprop.0+0x7b4>
    8f64:	f100033f 	cmp	x25, #0x0
    8f68:	1a9f17e0 	cset	w0, eq	// eq = none
    8f6c:	f10002df 	cmp	x22, #0x0
    8f70:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    8f74:	54ffeb60 	b.eq	8ce0 <fwp_hof0.constprop.0+0x7b0>  // b.none
    8f78:	900000c0 	adrp	x0, 20000 <__data_start>
    8f7c:	91014018 	add	x24, x0, #0x50
    8f80:	f9400be0 	ldr	x0, [sp, #16]
    8f84:	f9403fe1 	ldr	x1, [sp, #120]
    8f88:	f901cb01 	str	x1, [x24, #912]
    8f8c:	97ffed66 	bl	4524 <fwp_tape_buffers_release>
    8f90:	f00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    8f94:	f947e863 	ldr	x3, [x3, #4048]
    8f98:	d2800262 	mov	x2, #0x13                  	// #19
    8f9c:	d2800021 	mov	x1, #0x1                   	// #1
    8fa0:	b0000020 	adrp	x0, d000 <__divti3+0x2b0>
    8fa4:	9111e000 	add	x0, x0, #0x478
    8fa8:	f9400063 	ldr	x3, [x3]
    8fac:	97ffe67d 	bl	29a0 <fwrite@plt>
    8fb0:	d2800000 	mov	x0, #0x0                   	// #0
    8fb4:	97ffe687 	bl	29d0 <fflush@plt>
    8fb8:	52800cc0 	mov	w0, #0x66                  	// #102
    8fbc:	97ffe695 	bl	2a10 <_Exit@plt>
    8fc0:	f9400365 	ldr	x5, [x27]
    8fc4:	aa1b03e0 	mov	x0, x27
    8fc8:	f949eec3 	ldr	x3, [x22, #5080]
    8fcc:	f949dac1 	ldr	x1, [x22, #5040]
    8fd0:	d370bc63 	lsl	x3, x3, #16
    8fd4:	cb010362 	sub	x2, x27, x1
    8fd8:	b7f85445 	tbnz	x5, #63, 9a60 <fwp_hof0.constprop.0+0x1530>
    8fdc:	eb03005f 	cmp	x2, x3
    8fe0:	54ffdec2 	b.cs	8bb8 <fwp_hof0.constprop.0+0x688>  // b.hs, b.nlast
    8fe4:	d350fc40 	lsr	x0, x2, #16
    8fe8:	8b000800 	add	x0, x0, x0, lsl #2
    8fec:	d37df000 	lsl	x0, x0, #3
    8ff0:	8b000083 	add	x3, x4, x0
    8ff4:	f9401061 	ldr	x1, [x3, #32]
    8ff8:	b4ffde01 	cbz	x1, 8bb8 <fwp_hof0.constprop.0+0x688>
    8ffc:	38606880 	ldrb	w0, [x4, x0]
    9000:	7100081f 	cmp	w0, #0x2
    9004:	54005f00 	b.eq	9be4 <fwp_hof0.constprop.0+0x16b4>  // b.none
    9008:	7100041f 	cmp	w0, #0x1
    900c:	54ffdd61 	b.ne	8bb8 <fwp_hof0.constprop.0+0x688>  // b.any
    9010:	92403c40 	and	x0, x2, #0xffff
    9014:	29430864 	ldp	w4, w2, [x3, #24]
    9018:	9b047c00 	mul	x0, x0, x4
    901c:	d360fc00 	lsr	x0, x0, #32
    9020:	eb02001f 	cmp	x0, x2
    9024:	54ffdca2 	b.cs	8bb8 <fwp_hof0.constprop.0+0x688>  // b.hs, b.nlast
    9028:	8b000021 	add	x1, x1, x0
    902c:	39400020 	ldrb	w0, [x1]
    9030:	7100041f 	cmp	w0, #0x1
    9034:	54ffdc21 	b.ne	8bb8 <fwp_hof0.constprop.0+0x688>  // b.any
    9038:	aa1b03e0 	mov	x0, x27
    903c:	97ffef15 	bl	4c90 <fwp_mem_free>
    9040:	17fffede 	b	8bb8 <fwp_hof0.constprop.0+0x688>
    9044:	97fff707 	bl	6c60 <fwp_drop10>
    9048:	aa1503e1 	mov	x1, x21
    904c:	d2800002 	mov	x2, #0x0                   	// #0
    9050:	b40067b5 	cbz	x21, 9d44 <fwp_hof0.constprop.0+0x1814>
    9054:	d503201f 	nop
    9058:	f9400821 	ldr	x1, [x1, #16]
    905c:	91000442 	add	x2, x2, #0x1
    9060:	b5ffffc1 	cbnz	x1, 9058 <fwp_hof0.constprop.0+0xb28>
    9064:	f9400385 	ldr	x5, [x28]
    9068:	9240f8a4 	and	x4, x5, #0x7fffffffffffffff
    906c:	b7f82b65 	tbnz	x5, #63, 95d8 <fwp_hof0.constprop.0+0x10a8>
    9070:	9118c281 	add	x1, x20, #0x630
    9074:	f949d820 	ldr	x0, [x1, #5040]
    9078:	f949ec21 	ldr	x1, [x1, #5080]
    907c:	cb0002c0 	sub	x0, x22, x0
    9080:	eb01401f 	cmp	x0, x1, lsl #16
    9084:	54002aa2 	b.cs	95d8 <fwp_hof0.constprop.0+0x10a8>  // b.hs, b.nlast
    9088:	9118c283 	add	x3, x20, #0x630
    908c:	d350fc01 	lsr	x1, x0, #16
    9090:	8b010821 	add	x1, x1, x1, lsl #2
    9094:	f949fc67 	ldr	x7, [x3, #5112]
    9098:	d37df021 	lsl	x1, x1, #3
    909c:	8b0100e6 	add	x6, x7, x1
    90a0:	f94010c3 	ldr	x3, [x6, #32]
    90a4:	b4002983 	cbz	x3, 95d4 <fwp_hof0.constprop.0+0x10a4>
    90a8:	386168e1 	ldrb	w1, [x7, x1]
    90ac:	7100083f 	cmp	w1, #0x2
    90b0:	540028e0 	b.eq	95cc <fwp_hof0.constprop.0+0x109c>  // b.none
    90b4:	7100043f 	cmp	w1, #0x1
    90b8:	540028e1 	b.ne	95d4 <fwp_hof0.constprop.0+0x10a4>  // b.any
    90bc:	294304c7 	ldp	w7, w1, [x6, #24]
    90c0:	92403c00 	and	x0, x0, #0xffff
    90c4:	9b077c00 	mul	x0, x0, x7
    90c8:	d360fc00 	lsr	x0, x0, #32
    90cc:	eb01001f 	cmp	x0, x1
    90d0:	54002822 	b.cs	95d4 <fwp_hof0.constprop.0+0x10a4>  // b.hs, b.nlast
    90d4:	8b000063 	add	x3, x3, x0
    90d8:	39400060 	ldrb	w0, [x3]
    90dc:	7100041f 	cmp	w0, #0x1
    90e0:	540027a1 	b.ne	95d4 <fwp_hof0.constprop.0+0x10a4>  // b.any
    90e4:	b90033e0 	str	w0, [sp, #48]
    90e8:	eb02009f 	cmp	x4, x2
    90ec:	9a829084 	csel	x4, x4, x2, ls	// ls = plast
    90f0:	9100239b 	add	x27, x28, #0x8
    90f4:	b4007184 	cbz	x4, 9f24 <fwp_hof0.constprop.0+0x19f4>
    90f8:	d37df087 	lsl	x7, x4, #3
    90fc:	aa1503e2 	mov	x2, x21
    9100:	910022c0 	add	x0, x22, #0x8
    9104:	d2800001 	mov	x1, #0x0                   	// #0
    9108:	1400000a 	b	9130 <fwp_hof0.constprop.0+0xc00>
    910c:	fc6168c1 	ldr	d1, [x6, x1]
    9110:	fd400440 	ldr	d0, [x2, #8]
    9114:	1e613800 	fsub	d0, d0, d1
    9118:	fc216b60 	str	d0, [x27, x1]
    911c:	91002021 	add	x1, x1, #0x8
    9120:	f9400842 	ldr	x2, [x2, #16]
    9124:	eb07003f 	cmp	x1, x7
    9128:	540001a0 	b.eq	915c <fwp_hof0.constprop.0+0xc2c>  // b.none
    912c:	f9400385 	ldr	x5, [x28]
    9130:	aa0003e6 	mov	x6, x0
    9134:	b6fffec5 	tbz	x5, #63, 910c <fwp_hof0.constprop.0+0xbdc>
    9138:	f9400ac6 	ldr	x6, [x22, #16]
    913c:	fd400440 	ldr	d0, [x2, #8]
    9140:	fc6168c1 	ldr	d1, [x6, x1]
    9144:	1e613800 	fsub	d0, d0, d1
    9148:	fc216b60 	str	d0, [x27, x1]
    914c:	91002021 	add	x1, x1, #0x8
    9150:	f9400842 	ldr	x2, [x2, #16]
    9154:	eb07003f 	cmp	x1, x7
    9158:	54fffea1 	b.ne	912c <fwp_hof0.constprop.0+0xbfc>  // b.any
    915c:	b4007215 	cbz	x21, 9f9c <fwp_hof0.constprop.0+0x1a6c>
    9160:	9118c280 	add	x0, x20, #0x630
    9164:	aa1503e7 	mov	x7, x21
    9168:	d2800017 	mov	x23, #0x0                   	// #0
    916c:	f949ec09 	ldr	x9, [x0, #5080]
    9170:	f949d80a 	ldr	x10, [x0, #5040]
    9174:	f949fc08 	ldr	x8, [x0, #5112]
    9178:	d370bd29 	lsl	x9, x9, #16
    917c:	14000006 	b	9194 <fwp_hof0.constprop.0+0xc64>
    9180:	f94008e7 	ldr	x7, [x7, #16]
    9184:	910006f7 	add	x23, x23, #0x1
    9188:	f10000ff 	cmp	x7, #0x0
    918c:	fa571080 	ccmp	x4, x23, #0x0, ne	// ne = any
    9190:	54000329 	b.ls	91f4 <fwp_hof0.constprop.0+0xcc4>  // b.plast
    9194:	cb0a00e0 	sub	x0, x7, x10
    9198:	eb09001f 	cmp	x0, x9
    919c:	540002c2 	b.cs	91f4 <fwp_hof0.constprop.0+0xcc4>  // b.hs, b.nlast
    91a0:	d350fc01 	lsr	x1, x0, #16
    91a4:	8b010821 	add	x1, x1, x1, lsl #2
    91a8:	d37df021 	lsl	x1, x1, #3
    91ac:	8b010106 	add	x6, x8, x1
    91b0:	f94010c2 	ldr	x2, [x6, #32]
    91b4:	b4000202 	cbz	x2, 91f4 <fwp_hof0.constprop.0+0xcc4>
    91b8:	38616901 	ldrb	w1, [x8, x1]
    91bc:	7100083f 	cmp	w1, #0x2
    91c0:	54000e00 	b.eq	9380 <fwp_hof0.constprop.0+0xe50>  // b.none
    91c4:	7100043f 	cmp	w1, #0x1
    91c8:	54000161 	b.ne	91f4 <fwp_hof0.constprop.0+0xcc4>  // b.any
    91cc:	294304cb 	ldp	w11, w1, [x6, #24]
    91d0:	92403c00 	and	x0, x0, #0xffff
    91d4:	9b0b7c00 	mul	x0, x0, x11
    91d8:	d360fc00 	lsr	x0, x0, #32
    91dc:	eb01001f 	cmp	x0, x1
    91e0:	540000a2 	b.cs	91f4 <fwp_hof0.constprop.0+0xcc4>  // b.hs, b.nlast
    91e4:	8b000042 	add	x2, x2, x0
    91e8:	39400040 	ldrb	w0, [x2]
    91ec:	7100041f 	cmp	w0, #0x1
    91f0:	54fffc80 	b.eq	9180 <fwp_hof0.constprop.0+0xc50>  // b.none
    91f4:	eb17009f 	cmp	x4, x23
    91f8:	54000cc9 	b.ls	9390 <fwp_hof0.constprop.0+0xe60>  // b.plast
    91fc:	aa0403f8 	mov	x24, x4
    9200:	d1002379 	sub	x25, x27, #0x8
    9204:	910323f3 	add	x19, sp, #0xc8
    9208:	9118c29a 	add	x26, x20, #0x630
    920c:	d280001c 	mov	x28, #0x0                   	// #0
    9210:	14000012 	b	9258 <fwp_hof0.constprop.0+0xd28>
    9214:	7100045f 	cmp	w2, #0x1
    9218:	540001a1 	b.ne	924c <fwp_hof0.constprop.0+0xd1c>  // b.any
    921c:	29430909 	ldp	w9, w2, [x8, #24]
    9220:	92403c21 	and	x1, x1, #0xffff
    9224:	9b097c21 	mul	x1, x1, x9
    9228:	d360fc21 	lsr	x1, x1, #32
    922c:	eb02003f 	cmp	x1, x2
    9230:	540000e2 	b.cs	924c <fwp_hof0.constprop.0+0xd1c>  // b.hs, b.nlast
    9234:	8b010000 	add	x0, x0, x1
    9238:	39400001 	ldrb	w1, [x0]
    923c:	7103fc3f 	cmp	w1, #0xff
    9240:	54002f80 	b.eq	9830 <fwp_hof0.constprop.0+0x1300>  // b.none
    9244:	52800021 	mov	w1, #0x1                   	// #1
    9248:	39000001 	strb	w1, [x0]
    924c:	d1000718 	sub	x24, x24, #0x1
    9250:	eb1802ff 	cmp	x23, x24
    9254:	54000362 	b.cs	92c0 <fwp_hof0.constprop.0+0xd90>  // b.hs, b.nlast
    9258:	f8787b22 	ldr	x2, [x25, x24, lsl #3]
    925c:	aa1303e1 	mov	x1, x19
    9260:	52800020 	mov	w0, #0x1                   	// #1
    9264:	a90cf3e2 	stp	x2, x28, [sp, #200]
    9268:	97fff00b 	bl	5294 <fwp_data.part.0.constprop.0>
    926c:	aa0003fc 	mov	x28, x0
    9270:	f949db41 	ldr	x1, [x26, #5040]
    9274:	f949ef40 	ldr	x0, [x26, #5080]
    9278:	cb010381 	sub	x1, x28, x1
    927c:	eb00403f 	cmp	x1, x0, lsl #16
    9280:	54fffe62 	b.cs	924c <fwp_hof0.constprop.0+0xd1c>  // b.hs, b.nlast
    9284:	d350fc20 	lsr	x0, x1, #16
    9288:	f949ff49 	ldr	x9, [x26, #5112]
    928c:	8b000800 	add	x0, x0, x0, lsl #2
    9290:	d37df002 	lsl	x2, x0, #3
    9294:	8b020128 	add	x8, x9, x2
    9298:	f9401100 	ldr	x0, [x8, #32]
    929c:	b4fffd80 	cbz	x0, 924c <fwp_hof0.constprop.0+0xd1c>
    92a0:	38626922 	ldrb	w2, [x9, x2]
    92a4:	7100085f 	cmp	w2, #0x2
    92a8:	54fffb61 	b.ne	9214 <fwp_hof0.constprop.0+0xce4>  // b.any
    92ac:	72003c3f 	tst	w1, #0xffff
    92b0:	54fffc40 	b.eq	9238 <fwp_hof0.constprop.0+0xd08>  // b.none
    92b4:	d1000718 	sub	x24, x24, #0x1
    92b8:	eb1802ff 	cmp	x23, x24
    92bc:	54fffce3 	b.cc	9258 <fwp_hof0.constprop.0+0xd28>  // b.lo, b.ul, b.last
    92c0:	b50006b7 	cbnz	x23, 9394 <fwp_hof0.constprop.0+0xe64>
    92c4:	b94033e0 	ldr	w0, [sp, #48]
    92c8:	d2800004 	mov	x4, #0x0                   	// #0
    92cc:	7100001f 	cmp	w0, #0x0
    92d0:	d2800020 	mov	x0, #0x1                   	// #1
    92d4:	9a9f037b 	csel	x27, x27, xzr, eq	// eq = none
    92d8:	b40007c4 	cbz	x4, 93d0 <fwp_hof0.constprop.0+0xea0>
    92dc:	d1000497 	sub	x23, x4, #0x1
    92e0:	2a0003f9 	mov	w25, w0
    92e4:	9118c29a 	add	x26, x20, #0x630
    92e8:	f8777b62 	ldr	x2, [x27, x23, lsl #3]
    92ec:	aa1303e1 	mov	x1, x19
    92f0:	52800020 	mov	w0, #0x1                   	// #1
    92f4:	a90cf3e2 	stp	x2, x28, [sp, #200]
    92f8:	97ffefe7 	bl	5294 <fwp_data.part.0.constprop.0>
    92fc:	aa0003fc 	mov	x28, x0
    9300:	f949db41 	ldr	x1, [x26, #5040]
    9304:	f949ef40 	ldr	x0, [x26, #5080]
    9308:	cb010381 	sub	x1, x28, x1
    930c:	eb00403f 	cmp	x1, x0, lsl #16
    9310:	54000302 	b.cs	9370 <fwp_hof0.constprop.0+0xe40>  // b.hs, b.nlast
    9314:	d350fc22 	lsr	x2, x1, #16
    9318:	f949ff47 	ldr	x7, [x26, #5112]
    931c:	8b020842 	add	x2, x2, x2, lsl #2
    9320:	d37df042 	lsl	x2, x2, #3
    9324:	8b0200e5 	add	x5, x7, x2
    9328:	f94010b8 	ldr	x24, [x5, #32]
    932c:	b4000238 	cbz	x24, 9370 <fwp_hof0.constprop.0+0xe40>
    9330:	386268e2 	ldrb	w2, [x7, x2]
    9334:	7100085f 	cmp	w2, #0x2
    9338:	54001440 	b.eq	95c0 <fwp_hof0.constprop.0+0x1090>  // b.none
    933c:	7100045f 	cmp	w2, #0x1
    9340:	54000181 	b.ne	9370 <fwp_hof0.constprop.0+0xe40>  // b.any
    9344:	294308a7 	ldp	w7, w2, [x5, #24]
    9348:	92403c21 	and	x1, x1, #0xffff
    934c:	9b077c21 	mul	x1, x1, x7
    9350:	d360fc21 	lsr	x1, x1, #32
    9354:	eb02003f 	cmp	x1, x2
    9358:	540000c2 	b.cs	9370 <fwp_hof0.constprop.0+0xe40>  // b.hs, b.nlast
    935c:	8b010318 	add	x24, x24, x1
    9360:	39400301 	ldrb	w1, [x24]
    9364:	7103fc3f 	cmp	w1, #0xff
    9368:	54001260 	b.eq	95b4 <fwp_hof0.constprop.0+0x1084>  // b.none
    936c:	39000319 	strb	w25, [x24]
    9370:	d10006f7 	sub	x23, x23, #0x1
    9374:	b10006ff 	cmn	x23, #0x1
    9378:	54fffb81 	b.ne	92e8 <fwp_hof0.constprop.0+0xdb8>  // b.any
    937c:	14000015 	b	93d0 <fwp_hof0.constprop.0+0xea0>
    9380:	72003c1f 	tst	w0, #0xffff
    9384:	54fff320 	b.eq	91e8 <fwp_hof0.constprop.0+0xcb8>  // b.none
    9388:	eb17009f 	cmp	x4, x23
    938c:	54fff388 	b.hi	91fc <fwp_hof0.constprop.0+0xccc>  // b.pmore
    9390:	d280001c 	mov	x28, #0x0                   	// #0
    9394:	8b170f65 	add	x5, x27, x23, lsl #3
    9398:	aa1b03e1 	mov	x1, x27
    939c:	aa1503e0 	mov	x0, x21
    93a0:	f8408422 	ldr	x2, [x1], #8
    93a4:	f9000402 	str	x2, [x0, #8]
    93a8:	aa0003e2 	mov	x2, x0
    93ac:	f9400800 	ldr	x0, [x0, #16]
    93b0:	eb05003f 	cmp	x1, x5
    93b4:	54ffff61 	b.ne	93a0 <fwp_hof0.constprop.0+0xe70>  // b.any
    93b8:	b94033e1 	ldr	w1, [sp, #48]
    93bc:	f900085c 	str	x28, [x2, #16]
    93c0:	aa1503fc 	mov	x28, x21
    93c4:	aa0003f5 	mov	x21, x0
    93c8:	34000041 	cbz	w1, 93d0 <fwp_hof0.constprop.0+0xea0>
    93cc:	d280001b 	mov	x27, #0x0                   	// #0
    93d0:	9118c293 	add	x19, x20, #0x630
    93d4:	aa1b03e0 	mov	x0, x27
    93d8:	97ffee2e 	bl	4c90 <fwp_mem_free>
    93dc:	f949ee62 	ldr	x2, [x19, #5080]
    93e0:	f949da61 	ldr	x1, [x19, #5040]
    93e4:	d370bc42 	lsl	x2, x2, #16
    93e8:	cb0102c3 	sub	x3, x22, x1
    93ec:	eb02007f 	cmp	x3, x2
    93f0:	54000402 	b.cs	9470 <fwp_hof0.constprop.0+0xf40>  // b.hs, b.nlast
    93f4:	d350fc60 	lsr	x0, x3, #16
    93f8:	f949fe65 	ldr	x5, [x19, #5112]
    93fc:	8b000800 	add	x0, x0, x0, lsl #2
    9400:	d37df000 	lsl	x0, x0, #3
    9404:	8b0000a2 	add	x2, x5, x0
    9408:	f9401057 	ldr	x23, [x2, #32]
    940c:	b4000cb7 	cbz	x23, 95a0 <fwp_hof0.constprop.0+0x1070>
    9410:	386068a1 	ldrb	w1, [x5, x0]
    9414:	7100083f 	cmp	w1, #0x2
    9418:	540031e0 	b.eq	9a54 <fwp_hof0.constprop.0+0x1524>  // b.none
    941c:	7100043f 	cmp	w1, #0x1
    9420:	54000c01 	b.ne	95a0 <fwp_hof0.constprop.0+0x1070>  // b.any
    9424:	29430844 	ldp	w4, w2, [x2, #24]
    9428:	92403c61 	and	x1, x3, #0xffff
    942c:	9b047c21 	mul	x1, x1, x4
    9430:	d360fc21 	lsr	x1, x1, #32
    9434:	eb02003f 	cmp	x1, x2
    9438:	54000b42 	b.cs	95a0 <fwp_hof0.constprop.0+0x1070>  // b.hs, b.nlast
    943c:	8b0102f7 	add	x23, x23, x1
    9440:	394002e1 	ldrb	w1, [x23]
    9444:	34000ae1 	cbz	w1, 95a0 <fwp_hof0.constprop.0+0x1070>
    9448:	7100043f 	cmp	w1, #0x1
    944c:	540006a0 	b.eq	9520 <fwp_hof0.constprop.0+0xff0>  // b.none
    9450:	7103fc3f 	cmp	w1, #0xff
    9454:	54005340 	b.eq	9ebc <fwp_hof0.constprop.0+0x198c>  // b.none
    9458:	9118c280 	add	x0, x20, #0x630
    945c:	51000421 	sub	w1, w1, #0x1
    9460:	390002e1 	strb	w1, [x23]
    9464:	f949ec02 	ldr	x2, [x0, #5080]
    9468:	f949d801 	ldr	x1, [x0, #5040]
    946c:	d370bc42 	lsl	x2, x2, #16
    9470:	cb0102a1 	sub	x1, x21, x1
    9474:	eb01005f 	cmp	x2, x1
    9478:	540003c9 	b.ls	94f0 <fwp_hof0.constprop.0+0xfc0>  // b.plast
    947c:	9118c296 	add	x22, x20, #0x630
    9480:	d350fc20 	lsr	x0, x1, #16
    9484:	f949fec3 	ldr	x3, [x22, #5112]
    9488:	8b000800 	add	x0, x0, x0, lsl #2
    948c:	d37df000 	lsl	x0, x0, #3
    9490:	8b000062 	add	x2, x3, x0
    9494:	f9401053 	ldr	x19, [x2, #32]
    9498:	b40002d3 	cbz	x19, 94f0 <fwp_hof0.constprop.0+0xfc0>
    949c:	38606860 	ldrb	w0, [x3, x0]
    94a0:	7100081f 	cmp	w0, #0x2
    94a4:	54003200 	b.eq	9ae4 <fwp_hof0.constprop.0+0x15b4>  // b.none
    94a8:	7100041f 	cmp	w0, #0x1
    94ac:	54000221 	b.ne	94f0 <fwp_hof0.constprop.0+0xfc0>  // b.any
    94b0:	29430044 	ldp	w4, w0, [x2, #24]
    94b4:	92403c21 	and	x1, x1, #0xffff
    94b8:	9b047c21 	mul	x1, x1, x4
    94bc:	d360fc21 	lsr	x1, x1, #32
    94c0:	eb00003f 	cmp	x1, x0
    94c4:	54000162 	b.cs	94f0 <fwp_hof0.constprop.0+0xfc0>  // b.hs, b.nlast
    94c8:	8b010273 	add	x19, x19, x1
    94cc:	39400260 	ldrb	w0, [x19]
    94d0:	34000100 	cbz	w0, 94f0 <fwp_hof0.constprop.0+0xfc0>
    94d4:	7100041f 	cmp	w0, #0x1
    94d8:	540038c0 	b.eq	9bf0 <fwp_hof0.constprop.0+0x16c0>  // b.none
    94dc:	7103fc1f 	cmp	w0, #0xff
    94e0:	54004b20 	b.eq	9e44 <fwp_hof0.constprop.0+0x1914>  // b.none
    94e4:	51000400 	sub	w0, w0, #0x1
    94e8:	39000260 	strb	w0, [x19]
    94ec:	d503201f 	nop
    94f0:	f94007e0 	ldr	x0, [sp, #8]
    94f4:	b4001a60 	cbz	x0, 9840 <fwp_hof0.constprop.0+0x1310>
    94f8:	f94007e0 	ldr	x0, [sp, #8]
    94fc:	f100041a 	subs	x26, x0, #0x1
    9500:	f90007fa 	str	x26, [sp, #8]
    9504:	54005da6 	b.vs	a0b8 <fwp_hof0.constprop.0+0x1b88>
    9508:	9118c280 	add	x0, x20, #0x630
    950c:	aa1c03f5 	mov	x21, x28
    9510:	f949ec03 	ldr	x3, [x0, #5080]
    9514:	f949d801 	ldr	x1, [x0, #5040]
    9518:	d370bc63 	lsl	x3, x3, #16
    951c:	17fffc51 	b	8660 <fwp_hof0.constprop.0+0x130>
    9520:	f94002c3 	ldr	x3, [x22]
    9524:	aa1603e0 	mov	x0, x22
    9528:	f949ee62 	ldr	x2, [x19, #5080]
    952c:	f949da61 	ldr	x1, [x19, #5040]
    9530:	d370bc42 	lsl	x2, x2, #16
    9534:	cb0102c7 	sub	x7, x22, x1
    9538:	b7f82dc3 	tbnz	x3, #63, 9af0 <fwp_hof0.constprop.0+0x15c0>
    953c:	eb0200ff 	cmp	x7, x2
    9540:	54fff982 	b.cs	9470 <fwp_hof0.constprop.0+0xf40>  // b.hs, b.nlast
    9544:	d350fce3 	lsr	x3, x7, #16
    9548:	8b030863 	add	x3, x3, x3, lsl #2
    954c:	d37df063 	lsl	x3, x3, #3
    9550:	8b0300a6 	add	x6, x5, x3
    9554:	f94010c4 	ldr	x4, [x6, #32]
    9558:	b4fff8c4 	cbz	x4, 9470 <fwp_hof0.constprop.0+0xf40>
    955c:	386368a3 	ldrb	w3, [x5, x3]
    9560:	7100087f 	cmp	w3, #0x2
    9564:	54003960 	b.eq	9c90 <fwp_hof0.constprop.0+0x1760>  // b.none
    9568:	7100047f 	cmp	w3, #0x1
    956c:	54fff821 	b.ne	9470 <fwp_hof0.constprop.0+0xf40>  // b.any
    9570:	29430cc5 	ldp	w5, w3, [x6, #24]
    9574:	92403ce0 	and	x0, x7, #0xffff
    9578:	9b057c00 	mul	x0, x0, x5
    957c:	d360fc00 	lsr	x0, x0, #32
    9580:	eb03001f 	cmp	x0, x3
    9584:	54fff762 	b.cs	9470 <fwp_hof0.constprop.0+0xf40>  // b.hs, b.nlast
    9588:	8b000084 	add	x4, x4, x0
    958c:	39400080 	ldrb	w0, [x4]
    9590:	7100041f 	cmp	w0, #0x1
    9594:	54fff6e1 	b.ne	9470 <fwp_hof0.constprop.0+0xf40>  // b.any
    9598:	aa1603e0 	mov	x0, x22
    959c:	97ffedbd 	bl	4c90 <fwp_mem_free>
    95a0:	9118c280 	add	x0, x20, #0x630
    95a4:	f949ec02 	ldr	x2, [x0, #5080]
    95a8:	f949d801 	ldr	x1, [x0, #5040]
    95ac:	d370bc42 	lsl	x2, x2, #16
    95b0:	17ffffb0 	b	9470 <fwp_hof0.constprop.0+0xf40>
    95b4:	aa1803e0 	mov	x0, x24
    95b8:	97ffed16 	bl	4a10 <fwp_rc_forget_slot>
    95bc:	17ffff6c 	b	936c <fwp_hof0.constprop.0+0xe3c>
    95c0:	72003c3f 	tst	w1, #0xffff
    95c4:	54ffed61 	b.ne	9370 <fwp_hof0.constprop.0+0xe40>  // b.any
    95c8:	17ffff66 	b	9360 <fwp_hof0.constprop.0+0xe30>
    95cc:	72003c1f 	tst	w0, #0xffff
    95d0:	54ffd840 	b.eq	90d8 <fwp_hof0.constprop.0+0xba8>  // b.none
    95d4:	b4001235 	cbz	x21, 9818 <fwp_hof0.constprop.0+0x12e8>
    95d8:	aa1503f3 	mov	x19, x21
    95dc:	d2800017 	mov	x23, #0x0                   	// #0
    95e0:	f9400a73 	ldr	x19, [x19, #16]
    95e4:	aa1703e0 	mov	x0, x23
    95e8:	910006f7 	add	x23, x23, #0x1
    95ec:	b5ffffb3 	cbnz	x19, 95e0 <fwp_hof0.constprop.0+0x10b0>
    95f0:	f9001be4 	str	x4, [sp, #48]
    95f4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    95f8:	eb0102ff 	cmp	x23, x1
    95fc:	540051e8 	b.hi	a038 <fwp_hof0.constprop.0+0x1b08>  // b.pmore
    9600:	91000800 	add	x0, x0, #0x2
    9604:	52800041 	mov	w1, #0x2                   	// #2
    9608:	d37df000 	lsl	x0, x0, #3
    960c:	97ffeec1 	bl	5110 <fwp_heap_alloc>
    9610:	f9401be4 	ldr	x4, [sp, #48]
    9614:	aa0003fb 	mov	x27, x0
    9618:	aa1503e1 	mov	x1, x21
    961c:	eb0402ff 	cmp	x23, x4
    9620:	9a8492e4 	csel	x4, x23, x4, ls	// ls = plast
    9624:	d503201f 	nop
    9628:	f9400420 	ldr	x0, [x1, #8]
    962c:	f8337b60 	str	x0, [x27, x19, lsl #3]
    9630:	91000673 	add	x19, x19, #0x1
    9634:	f9400821 	ldr	x1, [x1, #16]
    9638:	b5ffff81 	cbnz	x1, 9628 <fwp_hof0.constprop.0+0x10f8>
    963c:	b4000f64 	cbz	x4, 9828 <fwp_hof0.constprop.0+0x12f8>
    9640:	f9400385 	ldr	x5, [x28]
    9644:	b90033ff 	str	wzr, [sp, #48]
    9648:	17fffeac 	b	90f8 <fwp_hof0.constprop.0+0xbc8>
    964c:	d53bd040 	mrs	x0, tpidr_el0
    9650:	91400000 	add	x0, x0, #0x0, lsl #12
    9654:	91004000 	add	x0, x0, #0x10
    9658:	f9400000 	ldr	x0, [x0]
    965c:	b40028c0 	cbz	x0, 9b74 <fwp_hof0.constprop.0+0x1644>
    9660:	f94017e1 	ldr	x1, [sp, #40]
    9664:	97ffe880 	bl	3864 <fwp_closure_drop_push>
    9668:	b5ff8a75 	cbnz	x21, 87b4 <fwp_hof0.constprop.0+0x284>
    966c:	f00000a0 	adrp	x0, 20000 <__data_start>
    9670:	91014013 	add	x19, x0, #0x50
    9674:	d2800016 	mov	x22, #0x0                   	// #0
    9678:	b943c660 	ldr	w0, [x19, #964]
    967c:	35ff8b80 	cbnz	w0, 87ec <fwp_hof0.constprop.0+0x2bc>
    9680:	b0ffffe0 	adrp	x0, 6000 <fwp_drop0+0x30>
    9684:	910e8000 	add	x0, x0, #0x3a0
    9688:	94000f6e 	bl	d440 <atexit>
    968c:	35ffc820 	cbnz	w0, 8f90 <fwp_hof0.constprop.0+0xa60>
    9690:	52800020 	mov	w0, #0x1                   	// #1
    9694:	b903c660 	str	w0, [x19, #964]
    9698:	f00000a0 	adrp	x0, 20000 <__data_start>
    969c:	91014000 	add	x0, x0, #0x50
    96a0:	f9406c13 	ldr	x19, [x0, #216]
    96a4:	f940b017 	ldr	x23, [x0, #352]
    96a8:	eb1302ff 	cmp	x23, x19
    96ac:	54ff8acb 	b.lt	8804 <fwp_hof0.constprop.0+0x2d4>  // b.tstop
    96b0:	eb1302ff 	cmp	x23, x19
    96b4:	54ff8c40 	b.eq	883c <fwp_hof0.constprop.0+0x30c>  // b.none
    96b8:	f00000a0 	adrp	x0, 20000 <__data_start>
    96bc:	91014000 	add	x0, x0, #0x50
    96c0:	8b1706fb 	add	x27, x23, x23, lsl #1
    96c4:	f940441c 	ldr	x28, [x0, #136]
    96c8:	8b1b0afb 	add	x27, x23, x27, lsl #2
    96cc:	90000020 	adrp	x0, d000 <__divti3+0x2b0>
    96d0:	9121c000 	add	x0, x0, #0x870
    96d4:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    96d8:	f900337f 	str	xzr, [x27, #96]
    96dc:	97ffe4d5 	bl	2a30 <getenv@plt>
    96e0:	b5ff90a0 	cbnz	x0, 88f4 <fwp_hof0.constprop.0+0x3c4>
    96e4:	f00000a0 	adrp	x0, 20000 <__data_start>
    96e8:	91014000 	add	x0, x0, #0x50
    96ec:	f9408c01 	ldr	x1, [x0, #280]
    96f0:	b4ff90c1 	cbz	x1, 8908 <fwp_hof0.constprop.0+0x3d8>
    96f4:	ad470402 	ldp	q2, q1, [x0, #224]
    96f8:	91038001 	add	x1, x0, #0xe0
    96fc:	4f000400 	movi	v0.4s, #0x0
    9700:	f9008c1f 	str	xzr, [x0, #280]
    9704:	ad010762 	stp	q2, q1, [x27, #32]
    9708:	a9500002 	ldp	x2, x0, [x0, #256]
    970c:	f9000f60 	str	x0, [x27, #24]
    9710:	f9401820 	ldr	x0, [x1, #48]
    9714:	f9002362 	str	x2, [x27, #64]
    9718:	f9002760 	str	x0, [x27, #72]
    971c:	ad000020 	stp	q0, q0, [x1]
    9720:	3d800820 	str	q0, [x1, #32]
    9724:	f900183f 	str	xzr, [x1, #48]
    9728:	17fffc78 	b	8908 <fwp_hof0.constprop.0+0x3d8>
    972c:	72003c1f 	tst	w0, #0xffff
    9730:	54ffbdc0 	b.eq	8ee8 <fwp_hof0.constprop.0+0x9b8>  // b.none
    9734:	d503201f 	nop
    9738:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    973c:	eb0002ff 	cmp	x23, x0
    9740:	54004ae8 	b.hi	a09c <fwp_hof0.constprop.0+0x1b6c>  // b.pmore
    9744:	910006e0 	add	x0, x23, #0x1
    9748:	52800021 	mov	w1, #0x1                   	// #1
    974c:	d37df000 	lsl	x0, x0, #3
    9750:	97ffee70 	bl	5110 <fwp_heap_alloc>
    9754:	9118c282 	add	x2, x20, #0x630
    9758:	f9000017 	str	x23, [x0]
    975c:	aa0003fc 	mov	x28, x0
    9760:	aa0003f6 	mov	x22, x0
    9764:	f949d841 	ldr	x1, [x2, #5040]
    9768:	f949ec40 	ldr	x0, [x2, #5080]
    976c:	cb010381 	sub	x1, x28, x1
    9770:	eb00403f 	cmp	x1, x0, lsl #16
    9774:	54000322 	b.cs	97d8 <fwp_hof0.constprop.0+0x12a8>  // b.hs, b.nlast
    9778:	d350fc20 	lsr	x0, x1, #16
    977c:	f949fc44 	ldr	x4, [x2, #5112]
    9780:	8b000800 	add	x0, x0, x0, lsl #2
    9784:	d37df002 	lsl	x2, x0, #3
    9788:	8b020083 	add	x3, x4, x2
    978c:	f9401078 	ldr	x24, [x3, #32]
    9790:	b4000258 	cbz	x24, 97d8 <fwp_hof0.constprop.0+0x12a8>
    9794:	38626882 	ldrb	w2, [x4, x2]
    9798:	7100085f 	cmp	w2, #0x2
    979c:	54002860 	b.eq	9ca8 <fwp_hof0.constprop.0+0x1778>  // b.none
    97a0:	7100045f 	cmp	w2, #0x1
    97a4:	540001a1 	b.ne	97d8 <fwp_hof0.constprop.0+0x12a8>  // b.any
    97a8:	29430864 	ldp	w4, w2, [x3, #24]
    97ac:	92403c21 	and	x1, x1, #0xffff
    97b0:	9b047c21 	mul	x1, x1, x4
    97b4:	d360fc21 	lsr	x1, x1, #32
    97b8:	eb02003f 	cmp	x1, x2
    97bc:	540000e2 	b.cs	97d8 <fwp_hof0.constprop.0+0x12a8>  // b.hs, b.nlast
    97c0:	8b010318 	add	x24, x24, x1
    97c4:	39400301 	ldrb	w1, [x24]
    97c8:	7103fc3f 	cmp	w1, #0xff
    97cc:	54002760 	b.eq	9cb8 <fwp_hof0.constprop.0+0x1788>  // b.none
    97d0:	52800021 	mov	w1, #0x1                   	// #1
    97d4:	39000301 	strb	w1, [x24]
    97d8:	aa1303e0 	mov	x0, x19
    97dc:	17fffdc9 	b	8f00 <fwp_hof0.constprop.0+0x9d0>
    97e0:	52800041 	mov	w1, #0x2                   	// #2
    97e4:	d2800100 	mov	x0, #0x8                   	// #8
    97e8:	97ffee4a 	bl	5110 <fwp_heap_alloc>
    97ec:	aa0003f7 	mov	x23, x0
    97f0:	9118c280 	add	x0, x20, #0x630
    97f4:	aa1703fb 	mov	x27, x23
    97f8:	f90002ff 	str	xzr, [x23]
    97fc:	f949d801 	ldr	x1, [x0, #5040]
    9800:	f949ec00 	ldr	x0, [x0, #5080]
    9804:	cb0102e1 	sub	x1, x23, x1
    9808:	eb00403f 	cmp	x1, x0, lsl #16
    980c:	540011a2 	b.cs	9a40 <fwp_hof0.constprop.0+0x1510>  // b.hs, b.nlast
    9810:	d2800016 	mov	x22, #0x0                   	// #0
    9814:	17fffc83 	b	8a20 <fwp_hof0.constprop.0+0x4f0>
    9818:	52800041 	mov	w1, #0x2                   	// #2
    981c:	d2800100 	mov	x0, #0x8                   	// #8
    9820:	97ffee3c 	bl	5110 <fwp_heap_alloc>
    9824:	aa0003fb 	mov	x27, x0
    9828:	d280001c 	mov	x28, #0x0                   	// #0
    982c:	17fffee9 	b	93d0 <fwp_hof0.constprop.0+0xea0>
    9830:	f9001fe0 	str	x0, [sp, #56]
    9834:	97ffec77 	bl	4a10 <fwp_rc_forget_slot>
    9838:	f9401fe0 	ldr	x0, [sp, #56]
    983c:	17fffe82 	b	9244 <fwp_hof0.constprop.0+0xd14>
    9840:	f9400be0 	ldr	x0, [sp, #16]
    9844:	b00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe790>
    9848:	910ac042 	add	x2, x2, #0x2b0
    984c:	aa1c03e1 	mov	x1, x28
    9850:	91014042 	add	x2, x2, #0x50
    9854:	52800023 	mov	w3, #0x1                   	// #1
    9858:	a9097fff 	stp	xzr, xzr, [sp, #144]
    985c:	f90053ff 	str	xzr, [sp, #160]
    9860:	97fff738 	bl	7540 <fwp_write>
    9864:	a9495bf5 	ldp	x21, x22, [sp, #144]
    9868:	90000020 	adrp	x0, d000 <__divti3+0x2b0>
    986c:	9112c000 	add	x0, x0, #0x4b0
    9870:	f10002bf 	cmp	x21, #0x0
    9874:	9a950015 	csel	x21, x0, x21, eq	// eq = none
    9878:	b1002adf 	cmn	x22, #0xa
    987c:	54004168 	b.hi	a0a8 <fwp_hof0.constprop.0+0x1b78>  // b.pmore
    9880:	910026c0 	add	x0, x22, #0x9
    9884:	52800021 	mov	w1, #0x1                   	// #1
    9888:	97ffee22 	bl	5110 <fwp_heap_alloc>
    988c:	aa0003f7 	mov	x23, x0
    9890:	aa0003f3 	mov	x19, x0
    9894:	aa1603e2 	mov	x2, x22
    9898:	aa1503e1 	mov	x1, x21
    989c:	f80086f6 	str	x22, [x23], #8
    98a0:	8b160276 	add	x22, x19, x22
    98a4:	aa1703e0 	mov	x0, x23
    98a8:	97ffe392 	bl	26f0 <memcpy@plt>
    98ac:	390022df 	strb	wzr, [x22, #8]
    98b0:	f9404be0 	ldr	x0, [sp, #144]
    98b4:	97ffe42b 	bl	2960 <free@plt>
    98b8:	9118c281 	add	x1, x20, #0x630
    98bc:	f949d822 	ldr	x2, [x1, #5040]
    98c0:	f949ec20 	ldr	x0, [x1, #5080]
    98c4:	cb020262 	sub	x2, x19, x2
    98c8:	eb00405f 	cmp	x2, x0, lsl #16
    98cc:	54000322 	b.cs	9930 <fwp_hof0.constprop.0+0x1400>  // b.hs, b.nlast
    98d0:	d350fc40 	lsr	x0, x2, #16
    98d4:	f949fc23 	ldr	x3, [x1, #5112]
    98d8:	8b000800 	add	x0, x0, x0, lsl #2
    98dc:	d37df001 	lsl	x1, x0, #3
    98e0:	8b010060 	add	x0, x3, x1
    98e4:	f9401015 	ldr	x21, [x0, #32]
    98e8:	b4000255 	cbz	x21, 9930 <fwp_hof0.constprop.0+0x1400>
    98ec:	38616861 	ldrb	w1, [x3, x1]
    98f0:	7100083f 	cmp	w1, #0x2
    98f4:	54002d40 	b.eq	9e9c <fwp_hof0.constprop.0+0x196c>  // b.none
    98f8:	7100043f 	cmp	w1, #0x1
    98fc:	540001a1 	b.ne	9930 <fwp_hof0.constprop.0+0x1400>  // b.any
    9900:	29430003 	ldp	w3, w0, [x0, #24]
    9904:	92403c41 	and	x1, x2, #0xffff
    9908:	9b037c21 	mul	x1, x1, x3
    990c:	d360fc21 	lsr	x1, x1, #32
    9910:	eb00003f 	cmp	x1, x0
    9914:	540000e2 	b.cs	9930 <fwp_hof0.constprop.0+0x1400>  // b.hs, b.nlast
    9918:	8b0102b5 	add	x21, x21, x1
    991c:	394002a0 	ldrb	w0, [x21]
    9920:	7103fc1f 	cmp	w0, #0xff
    9924:	54002c60 	b.eq	9eb0 <fwp_hof0.constprop.0+0x1980>  // b.none
    9928:	52800020 	mov	w0, #0x1                   	// #1
    992c:	390002a0 	strb	w0, [x21]
    9930:	aa1c03e0 	mov	x0, x28
    9934:	97fff1a7 	bl	5fd0 <fwp_drop0>
    9938:	f00000a0 	adrp	x0, 20000 <__data_start>
    993c:	91014015 	add	x21, x0, #0x50
    9940:	f9400262 	ldr	x2, [x19]
    9944:	d2800021 	mov	x1, #0x1                   	// #1
    9948:	f9404aa3 	ldr	x3, [x21, #144]
    994c:	aa1703e0 	mov	x0, x23
    9950:	97ffe414 	bl	29a0 <fwrite@plt>
    9954:	f9404aa1 	ldr	x1, [x21, #144]
    9958:	52800140 	mov	w0, #0xa                   	// #10
    995c:	97ffe399 	bl	27c0 <fputc@plt>
    9960:	9118c281 	add	x1, x20, #0x630
    9964:	f949d822 	ldr	x2, [x1, #5040]
    9968:	f949ec20 	ldr	x0, [x1, #5080]
    996c:	cb020262 	sub	x2, x19, x2
    9970:	eb00405f 	cmp	x2, x0, lsl #16
    9974:	54000382 	b.cs	99e4 <fwp_hof0.constprop.0+0x14b4>  // b.hs, b.nlast
    9978:	d350fc40 	lsr	x0, x2, #16
    997c:	f949fc23 	ldr	x3, [x1, #5112]
    9980:	8b000800 	add	x0, x0, x0, lsl #2
    9984:	d37df001 	lsl	x1, x0, #3
    9988:	8b010060 	add	x0, x3, x1
    998c:	f9401015 	ldr	x21, [x0, #32]
    9990:	b40002b5 	cbz	x21, 99e4 <fwp_hof0.constprop.0+0x14b4>
    9994:	38616861 	ldrb	w1, [x3, x1]
    9998:	7100083f 	cmp	w1, #0x2
    999c:	54002460 	b.eq	9e28 <fwp_hof0.constprop.0+0x18f8>  // b.none
    99a0:	7100043f 	cmp	w1, #0x1
    99a4:	54000201 	b.ne	99e4 <fwp_hof0.constprop.0+0x14b4>  // b.any
    99a8:	29430003 	ldp	w3, w0, [x0, #24]
    99ac:	92403c41 	and	x1, x2, #0xffff
    99b0:	9b037c21 	mul	x1, x1, x3
    99b4:	d360fc21 	lsr	x1, x1, #32
    99b8:	eb00003f 	cmp	x1, x0
    99bc:	54000142 	b.cs	99e4 <fwp_hof0.constprop.0+0x14b4>  // b.hs, b.nlast
    99c0:	8b0102b5 	add	x21, x21, x1
    99c4:	394002a0 	ldrb	w0, [x21]
    99c8:	340000e0 	cbz	w0, 99e4 <fwp_hof0.constprop.0+0x14b4>
    99cc:	7100041f 	cmp	w0, #0x1
    99d0:	54001da0 	b.eq	9d84 <fwp_hof0.constprop.0+0x1854>  // b.none
    99d4:	7103fc1f 	cmp	w0, #0xff
    99d8:	54002fe0 	b.eq	9fd4 <fwp_hof0.constprop.0+0x1aa4>  // b.none
    99dc:	51000400 	sub	w0, w0, #0x1
    99e0:	390002a0 	strb	w0, [x21]
    99e4:	f94027e0 	ldr	x0, [sp, #72]
    99e8:	f9400800 	ldr	x0, [x0, #16]
    99ec:	f90027e0 	str	x0, [sp, #72]
    99f0:	b5ff5d80 	cbnz	x0, 85a0 <fwp_hof0.constprop.0+0x70>
    99f4:	a94f53f3 	ldp	x19, x20, [sp, #240]
    99f8:	a9505bf5 	ldp	x21, x22, [sp, #256]
    99fc:	a95163f7 	ldp	x23, x24, [sp, #272]
    9a00:	a9526bf9 	ldp	x25, x26, [sp, #288]
    9a04:	a95373fb 	ldp	x27, x28, [sp, #304]
    9a08:	fd40a3e8 	ldr	d8, [sp, #320]
    9a0c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    9a10:	f947f400 	ldr	x0, [x0, #4072]
    9a14:	f9406fe2 	ldr	x2, [sp, #216]
    9a18:	f9400001 	ldr	x1, [x0]
    9a1c:	eb010042 	subs	x2, x2, x1
    9a20:	d2800001 	mov	x1, #0x0                   	// #0
    9a24:	54003101 	b.ne	a044 <fwp_hof0.constprop.0+0x1b14>  // b.any
    9a28:	a94e7bfd 	ldp	x29, x30, [sp, #224]
    9a2c:	d2800000 	mov	x0, #0x0                   	// #0
    9a30:	910543ff 	add	sp, sp, #0x150
    9a34:	d65f03c0 	ret
    9a38:	b5ff8296 	cbnz	x22, 8a88 <fwp_hof0.constprop.0+0x558>
    9a3c:	d503201f 	nop
    9a40:	d280001c 	mov	x28, #0x0                   	// #0
    9a44:	17fffc38 	b	8b24 <fwp_hof0.constprop.0+0x5f4>
    9a48:	72003c3f 	tst	w1, #0xffff
    9a4c:	54ff8b61 	b.ne	8bb8 <fwp_hof0.constprop.0+0x688>  // b.any
    9a50:	17fffc52 	b	8b98 <fwp_hof0.constprop.0+0x668>
    9a54:	72003c7f 	tst	w3, #0xffff
    9a58:	54ffda41 	b.ne	95a0 <fwp_hof0.constprop.0+0x1070>  // b.any
    9a5c:	17fffe79 	b	9440 <fwp_hof0.constprop.0+0xf10>
    9a60:	f940077b 	ldr	x27, [x27, #8]
    9a64:	eb03005f 	cmp	x2, x3
    9a68:	54000362 	b.cs	9ad4 <fwp_hof0.constprop.0+0x15a4>  // b.hs, b.nlast
    9a6c:	d350fc45 	lsr	x5, x2, #16
    9a70:	8b0508a5 	add	x5, x5, x5, lsl #2
    9a74:	d37df0a5 	lsl	x5, x5, #3
    9a78:	8b050087 	add	x7, x4, x5
    9a7c:	f94010e6 	ldr	x6, [x7, #32]
    9a80:	b40002a6 	cbz	x6, 9ad4 <fwp_hof0.constprop.0+0x15a4>
    9a84:	38656884 	ldrb	w4, [x4, x5]
    9a88:	7100089f 	cmp	w4, #0x2
    9a8c:	54001760 	b.eq	9d78 <fwp_hof0.constprop.0+0x1848>  // b.none
    9a90:	7100049f 	cmp	w4, #0x1
    9a94:	54000201 	b.ne	9ad4 <fwp_hof0.constprop.0+0x15a4>  // b.any
    9a98:	294310e5 	ldp	w5, w4, [x7, #24]
    9a9c:	92403c42 	and	x2, x2, #0xffff
    9aa0:	9b057c42 	mul	x2, x2, x5
    9aa4:	d360fc42 	lsr	x2, x2, #32
    9aa8:	eb04005f 	cmp	x2, x4
    9aac:	54000142 	b.cs	9ad4 <fwp_hof0.constprop.0+0x15a4>  // b.hs, b.nlast
    9ab0:	8b0200c6 	add	x6, x6, x2
    9ab4:	394000c2 	ldrb	w2, [x6]
    9ab8:	7100045f 	cmp	w2, #0x1
    9abc:	540000c1 	b.ne	9ad4 <fwp_hof0.constprop.0+0x15a4>  // b.any
    9ac0:	97ffec74 	bl	4c90 <fwp_mem_free>
    9ac4:	9118c280 	add	x0, x20, #0x630
    9ac8:	f949ec03 	ldr	x3, [x0, #5080]
    9acc:	f949d801 	ldr	x1, [x0, #5040]
    9ad0:	d370bc63 	lsl	x3, x3, #16
    9ad4:	cb010361 	sub	x1, x27, x1
    9ad8:	eb03003f 	cmp	x1, x3
    9adc:	54ff8383 	b.cc	8b4c <fwp_hof0.constprop.0+0x61c>  // b.lo, b.ul, b.last
    9ae0:	17fffc36 	b	8bb8 <fwp_hof0.constprop.0+0x688>
    9ae4:	72003c3f 	tst	w1, #0xffff
    9ae8:	54ffd041 	b.ne	94f0 <fwp_hof0.constprop.0+0xfc0>  // b.any
    9aec:	17fffe78 	b	94cc <fwp_hof0.constprop.0+0xf9c>
    9af0:	f94006d6 	ldr	x22, [x22, #8]
    9af4:	eb0200ff 	cmp	x7, x2
    9af8:	54000362 	b.cs	9b64 <fwp_hof0.constprop.0+0x1634>  // b.hs, b.nlast
    9afc:	d350fce3 	lsr	x3, x7, #16
    9b00:	8b030863 	add	x3, x3, x3, lsl #2
    9b04:	d37df063 	lsl	x3, x3, #3
    9b08:	8b0300a6 	add	x6, x5, x3
    9b0c:	f94010c4 	ldr	x4, [x6, #32]
    9b10:	b40002a4 	cbz	x4, 9b64 <fwp_hof0.constprop.0+0x1634>
    9b14:	386368a3 	ldrb	w3, [x5, x3]
    9b18:	7100087f 	cmp	w3, #0x2
    9b1c:	54001420 	b.eq	9da0 <fwp_hof0.constprop.0+0x1870>  // b.none
    9b20:	7100047f 	cmp	w3, #0x1
    9b24:	54000201 	b.ne	9b64 <fwp_hof0.constprop.0+0x1634>  // b.any
    9b28:	294314c8 	ldp	w8, w5, [x6, #24]
    9b2c:	92403ce3 	and	x3, x7, #0xffff
    9b30:	9b087c63 	mul	x3, x3, x8
    9b34:	d360fc63 	lsr	x3, x3, #32
    9b38:	eb05007f 	cmp	x3, x5
    9b3c:	54000142 	b.cs	9b64 <fwp_hof0.constprop.0+0x1634>  // b.hs, b.nlast
    9b40:	8b030084 	add	x4, x4, x3
    9b44:	39400083 	ldrb	w3, [x4]
    9b48:	7100047f 	cmp	w3, #0x1
    9b4c:	540000c1 	b.ne	9b64 <fwp_hof0.constprop.0+0x1634>  // b.any
    9b50:	97ffec50 	bl	4c90 <fwp_mem_free>
    9b54:	9118c280 	add	x0, x20, #0x630
    9b58:	f949ec02 	ldr	x2, [x0, #5080]
    9b5c:	f949d801 	ldr	x1, [x0, #5040]
    9b60:	d370bc42 	lsl	x2, x2, #16
    9b64:	cb0102c3 	sub	x3, x22, x1
    9b68:	eb02007f 	cmp	x3, x2
    9b6c:	54ffc443 	b.cc	93f4 <fwp_hof0.constprop.0+0xec4>  // b.lo, b.ul, b.last
    9b70:	17fffe40 	b	9470 <fwp_hof0.constprop.0+0xf40>
    9b74:	f94017e0 	ldr	x0, [sp, #40]
    9b78:	97ffe7aa 	bl	3a20 <fwp_closure_drop.part.0>
    9b7c:	17fffb0d 	b	87b0 <fwp_hof0.constprop.0+0x280>
    9b80:	72003c3f 	tst	w1, #0xffff
    9b84:	54ff5ec1 	b.ne	875c <fwp_hof0.constprop.0+0x22c>  // b.any
    9b88:	aa1303e0 	mov	x0, x19
    9b8c:	17fffada 	b	86f4 <fwp_hof0.constprop.0+0x1c4>
    9b90:	72003c3f 	tst	w1, #0xffff
    9b94:	54ff60e1 	b.ne	87b0 <fwp_hof0.constprop.0+0x280>  // b.any
    9b98:	17fffafd 	b	878c <fwp_hof0.constprop.0+0x25c>
    9b9c:	72003c3f 	tst	w1, #0xffff
    9ba0:	54ff7721 	b.ne	8a84 <fwp_hof0.constprop.0+0x554>  // b.any
    9ba4:	39400380 	ldrb	w0, [x28]
    9ba8:	7103fc1f 	cmp	w0, #0xff
    9bac:	54ff7681 	b.ne	8a7c <fwp_hof0.constprop.0+0x54c>  // b.any
    9bb0:	aa1c03e0 	mov	x0, x28
    9bb4:	97ffeb97 	bl	4a10 <fwp_rc_forget_slot>
    9bb8:	17fffbb1 	b	8a7c <fwp_hof0.constprop.0+0x54c>
    9bbc:	aa1803f6 	mov	x22, x24
    9bc0:	17fffc32 	b	8c88 <fwp_hof0.constprop.0+0x758>
    9bc4:	72003c3f 	tst	w1, #0xffff
    9bc8:	54ff9461 	b.ne	8e54 <fwp_hof0.constprop.0+0x924>  // b.any
    9bcc:	394002c0 	ldrb	w0, [x22]
    9bd0:	7103fc1f 	cmp	w0, #0xff
    9bd4:	54ff93c1 	b.ne	8e4c <fwp_hof0.constprop.0+0x91c>  // b.any
    9bd8:	aa1603e0 	mov	x0, x22
    9bdc:	97ffeb8d 	bl	4a10 <fwp_rc_forget_slot>
    9be0:	17fffc9b 	b	8e4c <fwp_hof0.constprop.0+0x91c>
    9be4:	72003c5f 	tst	w2, #0xffff
    9be8:	54ff7e81 	b.ne	8bb8 <fwp_hof0.constprop.0+0x688>  // b.any
    9bec:	17fffd10 	b	902c <fwp_hof0.constprop.0+0xafc>
    9bf0:	9118c280 	add	x0, x20, #0x630
    9bf4:	f9400ab3 	ldr	x19, [x21, #16]
    9bf8:	f949ec04 	ldr	x4, [x0, #5080]
    9bfc:	f949d801 	ldr	x1, [x0, #5040]
    9c00:	d370bc84 	lsl	x4, x4, #16
    9c04:	cb0102a0 	sub	x0, x21, x1
    9c08:	eb04001f 	cmp	x0, x4
    9c0c:	54000382 	b.cs	9c7c <fwp_hof0.constprop.0+0x174c>  // b.hs, b.nlast
    9c10:	d350fc02 	lsr	x2, x0, #16
    9c14:	8b020842 	add	x2, x2, x2, lsl #2
    9c18:	d37df042 	lsl	x2, x2, #3
    9c1c:	8b020066 	add	x6, x3, x2
    9c20:	f94010c5 	ldr	x5, [x6, #32]
    9c24:	b40002c5 	cbz	x5, 9c7c <fwp_hof0.constprop.0+0x174c>
    9c28:	38626862 	ldrb	w2, [x3, x2]
    9c2c:	7100085f 	cmp	w2, #0x2
    9c30:	54000be0 	b.eq	9dac <fwp_hof0.constprop.0+0x187c>  // b.none
    9c34:	7100045f 	cmp	w2, #0x1
    9c38:	54000221 	b.ne	9c7c <fwp_hof0.constprop.0+0x174c>  // b.any
    9c3c:	294308c3 	ldp	w3, w2, [x6, #24]
    9c40:	92403c00 	and	x0, x0, #0xffff
    9c44:	9b037c00 	mul	x0, x0, x3
    9c48:	d360fc00 	lsr	x0, x0, #32
    9c4c:	eb02001f 	cmp	x0, x2
    9c50:	54000162 	b.cs	9c7c <fwp_hof0.constprop.0+0x174c>  // b.hs, b.nlast
    9c54:	8b0000a5 	add	x5, x5, x0
    9c58:	394000a0 	ldrb	w0, [x5]
    9c5c:	7100041f 	cmp	w0, #0x1
    9c60:	540000e1 	b.ne	9c7c <fwp_hof0.constprop.0+0x174c>  // b.any
    9c64:	aa1503e0 	mov	x0, x21
    9c68:	97ffec0a 	bl	4c90 <fwp_mem_free>
    9c6c:	9118c280 	add	x0, x20, #0x630
    9c70:	f949ec04 	ldr	x4, [x0, #5080]
    9c74:	f949d801 	ldr	x1, [x0, #5040]
    9c78:	d370bc84 	lsl	x4, x4, #16
    9c7c:	cb010261 	sub	x1, x19, x1
    9c80:	eb01009f 	cmp	x4, x1
    9c84:	54ffc369 	b.ls	94f0 <fwp_hof0.constprop.0+0xfc0>  // b.plast
    9c88:	aa1303f5 	mov	x21, x19
    9c8c:	17fffdfd 	b	9480 <fwp_hof0.constprop.0+0xf50>
    9c90:	72003cff 	tst	w7, #0xffff
    9c94:	54ffbee1 	b.ne	9470 <fwp_hof0.constprop.0+0xf40>  // b.any
    9c98:	17fffe3d 	b	958c <fwp_hof0.constprop.0+0x105c>
    9c9c:	d2800019 	mov	x25, #0x0                   	// #0
    9ca0:	52800020 	mov	w0, #0x1                   	// #1
    9ca4:	17fffcb2 	b	8f6c <fwp_hof0.constprop.0+0xa3c>
    9ca8:	72003c3f 	tst	w1, #0xffff
    9cac:	54ffd8c0 	b.eq	97c4 <fwp_hof0.constprop.0+0x1294>  // b.none
    9cb0:	aa1303e0 	mov	x0, x19
    9cb4:	17fffc93 	b	8f00 <fwp_hof0.constprop.0+0x9d0>
    9cb8:	aa1803e0 	mov	x0, x24
    9cbc:	97ffeb55 	bl	4a10 <fwp_rc_forget_slot>
    9cc0:	17fffec4 	b	97d0 <fwp_hof0.constprop.0+0x12a0>
    9cc4:	d10006e1 	sub	x1, x23, #0x1
    9cc8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9ccc:	eb00003f 	cmp	x1, x0
    9cd0:	54001e08 	b.hi	a090 <fwp_hof0.constprop.0+0x1b60>  // b.pmore
    9cd4:	f00002a3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fbb0>
    9cd8:	d2800000 	mov	x0, #0x0                   	// #0
    9cdc:	91114061 	add	x1, x3, #0x450
    9ce0:	14000005 	b	9cf4 <fwp_hof0.constprop.0+0x17c4>
    9ce4:	91000400 	add	x0, x0, #0x1
    9ce8:	91006021 	add	x1, x1, #0x18
    9cec:	f140041f 	cmp	x0, #0x1, lsl #12
    9cf0:	54001500 	b.eq	9f90 <fwp_hof0.constprop.0+0x1a60>  // b.none
    9cf4:	f9400022 	ldr	x2, [x1]
    9cf8:	b5ffff62 	cbnz	x2, 9ce4 <fwp_hof0.constprop.0+0x17b4>
    9cfc:	8b000402 	add	x2, x0, x0, lsl #1
    9d00:	91114063 	add	x3, x3, #0x450
    9d04:	aa1703e0 	mov	x0, x23
    9d08:	d2800101 	mov	x1, #0x8                   	// #8
    9d0c:	8b020c73 	add	x19, x3, x2, lsl #3
    9d10:	a90327e8 	stp	x8, x9, [sp, #48]
    9d14:	97ffe2db 	bl	2880 <calloc@plt>
    9d18:	a94327e8 	ldp	x8, x9, [sp, #48]
    9d1c:	aa0003f9 	mov	x25, x0
    9d20:	b4fffbe0 	cbz	x0, 9c9c <fwp_hof0.constprop.0+0x176c>
    9d24:	aa1303e0 	mov	x0, x19
    9d28:	d37df2e2 	lsl	x2, x23, #3
    9d2c:	aa1903e1 	mov	x1, x25
    9d30:	52800063 	mov	w3, #0x3                   	// #3
    9d34:	a90327e8 	stp	x8, x9, [sp, #48]
    9d38:	97ffe496 	bl	2f90 <ad_raw_record>
    9d3c:	a94327e8 	ldp	x8, x9, [sp, #48]
    9d40:	17fffbe6 	b	8cd8 <fwp_hof0.constprop.0+0x7a8>
    9d44:	f9400385 	ldr	x5, [x28]
    9d48:	b7ffd685 	tbnz	x5, #63, 9818 <fwp_hof0.constprop.0+0x12e8>
    9d4c:	9118c281 	add	x1, x20, #0x630
    9d50:	f949d820 	ldr	x0, [x1, #5040]
    9d54:	f949ec21 	ldr	x1, [x1, #5080]
    9d58:	cb0002c0 	sub	x0, x22, x0
    9d5c:	eb01401f 	cmp	x0, x1, lsl #16
    9d60:	54ffd5c2 	b.cs	9818 <fwp_hof0.constprop.0+0x12e8>  // b.hs, b.nlast
    9d64:	9240f8a4 	and	x4, x5, #0x7fffffffffffffff
    9d68:	17fffcc8 	b	9088 <fwp_hof0.constprop.0+0xb58>
    9d6c:	d2800d01 	mov	x1, #0x68                  	// #104
    9d70:	d280003b 	mov	x27, #0x1                   	// #1
    9d74:	17fffac3 	b	8880 <fwp_hof0.constprop.0+0x350>
    9d78:	72003c5f 	tst	w2, #0xffff
    9d7c:	54ffeac1 	b.ne	9ad4 <fwp_hof0.constprop.0+0x15a4>  // b.any
    9d80:	17ffff4d 	b	9ab4 <fwp_hof0.constprop.0+0x1584>
    9d84:	aa1303e0 	mov	x0, x19
    9d88:	97ffef62 	bl	5b10 <fwp_rc_free_arr>
    9d8c:	f94027e0 	ldr	x0, [sp, #72]
    9d90:	f9400800 	ldr	x0, [x0, #16]
    9d94:	f90027e0 	str	x0, [sp, #72]
    9d98:	b5ff4040 	cbnz	x0, 85a0 <fwp_hof0.constprop.0+0x70>
    9d9c:	17ffff16 	b	99f4 <fwp_hof0.constprop.0+0x14c4>
    9da0:	72003cff 	tst	w7, #0xffff
    9da4:	54ffee01 	b.ne	9b64 <fwp_hof0.constprop.0+0x1634>  // b.any
    9da8:	17ffff67 	b	9b44 <fwp_hof0.constprop.0+0x1614>
    9dac:	72003c1f 	tst	w0, #0xffff
    9db0:	54fff661 	b.ne	9c7c <fwp_hof0.constprop.0+0x174c>  // b.any
    9db4:	17ffffa9 	b	9c58 <fwp_hof0.constprop.0+0x1728>
    9db8:	72003c9f 	tst	w4, #0xffff
    9dbc:	54ff44c1 	b.ne	8654 <fwp_hof0.constprop.0+0x124>  // b.any
    9dc0:	17fffa13 	b	860c <fwp_hof0.constprop.0+0xdc>
    9dc4:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9dc8:	9118c281 	add	x1, x20, #0x630
    9dcc:	ca402400 	eor	x0, x0, x0, lsr #9
    9dd0:	8b200c20 	add	x0, x1, w0, uxtb #3
    9dd4:	f94a2400 	ldr	x0, [x0, #5192]
    9dd8:	b5000080 	cbnz	x0, 9de8 <fwp_hof0.constprop.0+0x18b8>
    9ddc:	14000010 	b	9e1c <fwp_hof0.constprop.0+0x18ec>
    9de0:	f9400800 	ldr	x0, [x0, #16]
    9de4:	b40001c0 	cbz	x0, 9e1c <fwp_hof0.constprop.0+0x18ec>
    9de8:	f9400001 	ldr	x1, [x0]
    9dec:	eb17003f 	cmp	x1, x23
    9df0:	54ffff81 	b.ne	9de0 <fwp_hof0.constprop.0+0x18b0>  // b.any
    9df4:	f9400401 	ldr	x1, [x0, #8]
    9df8:	d1000421 	sub	x1, x1, #0x1
    9dfc:	f9000401 	str	x1, [x0, #8]
    9e00:	f103f83f 	cmp	x1, #0xfe
    9e04:	54ff6da1 	b.ne	8bb8 <fwp_hof0.constprop.0+0x688>  // b.any
    9e08:	aa1703e0 	mov	x0, x23
    9e0c:	97ffeb01 	bl	4a10 <fwp_rc_forget_slot>
    9e10:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9e14:	390002e0 	strb	w0, [x23]
    9e18:	17fffb68 	b	8bb8 <fwp_hof0.constprop.0+0x688>
    9e1c:	90000020 	adrp	x0, d000 <__divti3+0x2b0>
    9e20:	9124c000 	add	x0, x0, #0x930
    9e24:	97ffe677 	bl	3800 <fwp_trap>
    9e28:	72003c5f 	tst	w2, #0xffff
    9e2c:	54ffdcc0 	b.eq	99c4 <fwp_hof0.constprop.0+0x1494>  // b.none
    9e30:	f94027e0 	ldr	x0, [sp, #72]
    9e34:	f9400800 	ldr	x0, [x0, #16]
    9e38:	f90027e0 	str	x0, [sp, #72]
    9e3c:	b5ff3b20 	cbnz	x0, 85a0 <fwp_hof0.constprop.0+0x70>
    9e40:	17fffeed 	b	99f4 <fwp_hof0.constprop.0+0x14c4>
    9e44:	ca534660 	eor	x0, x19, x19, lsr #17
    9e48:	9118c281 	add	x1, x20, #0x630
    9e4c:	ca402400 	eor	x0, x0, x0, lsr #9
    9e50:	8b200c20 	add	x0, x1, w0, uxtb #3
    9e54:	f94a2400 	ldr	x0, [x0, #5192]
    9e58:	b5000080 	cbnz	x0, 9e68 <fwp_hof0.constprop.0+0x1938>
    9e5c:	17fffff0 	b	9e1c <fwp_hof0.constprop.0+0x18ec>
    9e60:	f9400800 	ldr	x0, [x0, #16]
    9e64:	b4fffdc0 	cbz	x0, 9e1c <fwp_hof0.constprop.0+0x18ec>
    9e68:	f9400001 	ldr	x1, [x0]
    9e6c:	eb01027f 	cmp	x19, x1
    9e70:	54ffff81 	b.ne	9e60 <fwp_hof0.constprop.0+0x1930>  // b.any
    9e74:	f9400401 	ldr	x1, [x0, #8]
    9e78:	d1000421 	sub	x1, x1, #0x1
    9e7c:	f9000401 	str	x1, [x0, #8]
    9e80:	f103f83f 	cmp	x1, #0xfe
    9e84:	54ffb361 	b.ne	94f0 <fwp_hof0.constprop.0+0xfc0>  // b.any
    9e88:	aa1303e0 	mov	x0, x19
    9e8c:	97ffeae1 	bl	4a10 <fwp_rc_forget_slot>
    9e90:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9e94:	39000260 	strb	w0, [x19]
    9e98:	17fffd96 	b	94f0 <fwp_hof0.constprop.0+0xfc0>
    9e9c:	72003c5f 	tst	w2, #0xffff
    9ea0:	54ffd481 	b.ne	9930 <fwp_hof0.constprop.0+0x1400>  // b.any
    9ea4:	394002a0 	ldrb	w0, [x21]
    9ea8:	7103fc1f 	cmp	w0, #0xff
    9eac:	54ffd3e1 	b.ne	9928 <fwp_hof0.constprop.0+0x13f8>  // b.any
    9eb0:	aa1503e0 	mov	x0, x21
    9eb4:	97ffead7 	bl	4a10 <fwp_rc_forget_slot>
    9eb8:	17fffe9c 	b	9928 <fwp_hof0.constprop.0+0x13f8>
    9ebc:	ca5746e0 	eor	x0, x23, x23, lsr #17
    9ec0:	9118c281 	add	x1, x20, #0x630
    9ec4:	ca402400 	eor	x0, x0, x0, lsr #9
    9ec8:	8b200c20 	add	x0, x1, w0, uxtb #3
    9ecc:	f94a2401 	ldr	x1, [x0, #5192]
    9ed0:	b5000081 	cbnz	x1, 9ee0 <fwp_hof0.constprop.0+0x19b0>
    9ed4:	17ffffd2 	b	9e1c <fwp_hof0.constprop.0+0x18ec>
    9ed8:	f9400821 	ldr	x1, [x1, #16]
    9edc:	b4fffa01 	cbz	x1, 9e1c <fwp_hof0.constprop.0+0x18ec>
    9ee0:	f9400020 	ldr	x0, [x1]
    9ee4:	eb17001f 	cmp	x0, x23
    9ee8:	54ffff81 	b.ne	9ed8 <fwp_hof0.constprop.0+0x19a8>  // b.any
    9eec:	f9400420 	ldr	x0, [x1, #8]
    9ef0:	d1000400 	sub	x0, x0, #0x1
    9ef4:	f9000420 	str	x0, [x1, #8]
    9ef8:	f103f81f 	cmp	x0, #0xfe
    9efc:	54ffb521 	b.ne	95a0 <fwp_hof0.constprop.0+0x1070>  // b.any
    9f00:	aa1703e0 	mov	x0, x23
    9f04:	97ffeac3 	bl	4a10 <fwp_rc_forget_slot>
    9f08:	9118c280 	add	x0, x20, #0x630
    9f0c:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9f10:	390002e1 	strb	w1, [x23]
    9f14:	f949ec02 	ldr	x2, [x0, #5080]
    9f18:	f949d801 	ldr	x1, [x0, #5040]
    9f1c:	d370bc42 	lsl	x2, x2, #16
    9f20:	17fffd54 	b	9470 <fwp_hof0.constprop.0+0xf40>
    9f24:	d280001b 	mov	x27, #0x0                   	// #0
    9f28:	d280001c 	mov	x28, #0x0                   	// #0
    9f2c:	17fffd29 	b	93d0 <fwp_hof0.constprop.0+0xea0>
    9f30:	97ffea71 	bl	48f4 <fwp_rc_wide_dup>
    9f34:	17fff9fd 	b	8728 <fwp_hof0.constprop.0+0x1f8>
    9f38:	ca534660 	eor	x0, x19, x19, lsr #17
    9f3c:	9118c281 	add	x1, x20, #0x630
    9f40:	ca402400 	eor	x0, x0, x0, lsr #9
    9f44:	8b200c20 	add	x0, x1, w0, uxtb #3
    9f48:	f94a2400 	ldr	x0, [x0, #5192]
    9f4c:	b5000080 	cbnz	x0, 9f5c <fwp_hof0.constprop.0+0x1a2c>
    9f50:	17ffffb3 	b	9e1c <fwp_hof0.constprop.0+0x18ec>
    9f54:	f9400800 	ldr	x0, [x0, #16]
    9f58:	b4fff620 	cbz	x0, 9e1c <fwp_hof0.constprop.0+0x18ec>
    9f5c:	f9400001 	ldr	x1, [x0]
    9f60:	eb01027f 	cmp	x19, x1
    9f64:	54ffff81 	b.ne	9f54 <fwp_hof0.constprop.0+0x1a24>  // b.any
    9f68:	f9400401 	ldr	x1, [x0, #8]
    9f6c:	d1000421 	sub	x1, x1, #0x1
    9f70:	f9000401 	str	x1, [x0, #8]
    9f74:	f103f83f 	cmp	x1, #0xfe
    9f78:	54ff41c1 	b.ne	87b0 <fwp_hof0.constprop.0+0x280>  // b.any
    9f7c:	aa1303e0 	mov	x0, x19
    9f80:	97ffeaa4 	bl	4a10 <fwp_rc_forget_slot>
    9f84:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9f88:	39000260 	strb	w0, [x19]
    9f8c:	17fffa09 	b	87b0 <fwp_hof0.constprop.0+0x280>
    9f90:	90000020 	adrp	x0, d000 <__divti3+0x2b0>
    9f94:	91206000 	add	x0, x0, #0x818
    9f98:	97ffe4fa 	bl	3380 <ad_raw_fail>
    9f9c:	d2800017 	mov	x23, #0x0                   	// #0
    9fa0:	17fffc97 	b	91fc <fwp_hof0.constprop.0+0xccc>
    9fa4:	90000020 	adrp	x0, d000 <__divti3+0x2b0>
    9fa8:	91284000 	add	x0, x0, #0xa10
    9fac:	97ffe615 	bl	3800 <fwp_trap>
    9fb0:	97ffea51 	bl	48f4 <fwp_rc_wide_dup>
    9fb4:	9118c280 	add	x0, x20, #0x630
    9fb8:	f949ec03 	ldr	x3, [x0, #5080]
    9fbc:	f949d801 	ldr	x1, [x0, #5040]
    9fc0:	d370bc63 	lsl	x3, x3, #16
    9fc4:	17fff9a4 	b	8654 <fwp_hof0.constprop.0+0x124>
    9fc8:	90000020 	adrp	x0, d000 <__divti3+0x2b0>
    9fcc:	9125e000 	add	x0, x0, #0x978
    9fd0:	97ffe60c 	bl	3800 <fwp_trap>
    9fd4:	ca5546a0 	eor	x0, x21, x21, lsr #17
    9fd8:	9118c281 	add	x1, x20, #0x630
    9fdc:	ca402400 	eor	x0, x0, x0, lsr #9
    9fe0:	8b200c20 	add	x0, x1, w0, uxtb #3
    9fe4:	f94a2400 	ldr	x0, [x0, #5192]
    9fe8:	b5000080 	cbnz	x0, 9ff8 <fwp_hof0.constprop.0+0x1ac8>
    9fec:	17ffff8c 	b	9e1c <fwp_hof0.constprop.0+0x18ec>
    9ff0:	f9400800 	ldr	x0, [x0, #16]
    9ff4:	b4fff140 	cbz	x0, 9e1c <fwp_hof0.constprop.0+0x18ec>
    9ff8:	f9400001 	ldr	x1, [x0]
    9ffc:	eb0102bf 	cmp	x21, x1
    a000:	54ffff81 	b.ne	9ff0 <fwp_hof0.constprop.0+0x1ac0>  // b.any
    a004:	f9400401 	ldr	x1, [x0, #8]
    a008:	d1000421 	sub	x1, x1, #0x1
    a00c:	f9000401 	str	x1, [x0, #8]
    a010:	f103f83f 	cmp	x1, #0xfe
    a014:	54ffce81 	b.ne	99e4 <fwp_hof0.constprop.0+0x14b4>  // b.any
    a018:	aa1503e0 	mov	x0, x21
    a01c:	97ffea7d 	bl	4a10 <fwp_rc_forget_slot>
    a020:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a024:	390002a0 	strb	w0, [x21]
    a028:	17fffe6f 	b	99e4 <fwp_hof0.constprop.0+0x14b4>
    a02c:	f0000000 	adrp	x0, d000 <__divti3+0x2b0>
    a030:	912fc000 	add	x0, x0, #0xbf0
    a034:	97ffe5f3 	bl	3800 <fwp_trap>
    a038:	f0000000 	adrp	x0, d000 <__divti3+0x2b0>
    a03c:	9129c000 	add	x0, x0, #0xa70
    a040:	97ffe5f0 	bl	3800 <fwp_trap>
    a044:	a90f53f3 	stp	x19, x20, [sp, #240]
    a048:	a9105bf5 	stp	x21, x22, [sp, #256]
    a04c:	a91163f7 	stp	x23, x24, [sp, #272]
    a050:	a9126bf9 	stp	x25, x26, [sp, #288]
    a054:	a91373fb 	stp	x27, x28, [sp, #304]
    a058:	fd00a3e8 	str	d8, [sp, #320]
    a05c:	97ffe211 	bl	28a0 <__stack_chk_fail@plt>
    a060:	f0000000 	adrp	x0, d000 <__divti3+0x2b0>
    a064:	91270000 	add	x0, x0, #0x9c0
    a068:	97ffe5e6 	bl	3800 <fwp_trap>
    a06c:	f0000000 	adrp	x0, d000 <__divti3+0x2b0>
    a070:	912dc000 	add	x0, x0, #0xb70
    a074:	97ffe5e3 	bl	3800 <fwp_trap>
    a078:	f0000000 	adrp	x0, d000 <__divti3+0x2b0>
    a07c:	912e4000 	add	x0, x0, #0xb90
    a080:	97ffe5e0 	bl	3800 <fwp_trap>
    a084:	f0000000 	adrp	x0, d000 <__divti3+0x2b0>
    a088:	9130c000 	add	x0, x0, #0xc30
    a08c:	97ffe5dd 	bl	3800 <fwp_trap>
    a090:	f0000000 	adrp	x0, d000 <__divti3+0x2b0>
    a094:	912f0000 	add	x0, x0, #0xbc0
    a098:	97ffe4ba 	bl	3380 <ad_raw_fail>
    a09c:	f0000000 	adrp	x0, d000 <__divti3+0x2b0>
    a0a0:	912f8000 	add	x0, x0, #0xbe0
    a0a4:	97ffe5d7 	bl	3800 <fwp_trap>
    a0a8:	f0000000 	adrp	x0, d000 <__divti3+0x2b0>
    a0ac:	91306000 	add	x0, x0, #0xc18
    a0b0:	97ffe5d4 	bl	3800 <fwp_trap>
    a0b4:	97ffe20f 	bl	28f0 <abort@plt>
    a0b8:	97ffe272 	bl	2a80 <fwp_trap_overflow.constprop.0>
    a0bc:	d503201f 	nop

000000000000a0c0 <f0>:
    a0c0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a0c4:	910003fd 	mov	x29, sp
    a0c8:	a90153f3 	stp	x19, x20, [sp, #16]
    a0cc:	a9025bf5 	stp	x21, x22, [sp, #32]
    a0d0:	a90363f7 	stp	x23, x24, [sp, #48]
    a0d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    a0d8:	a90573fb 	stp	x27, x28, [sp, #80]
    a0dc:	d12183ff 	sub	sp, sp, #0x860
    a0e0:	f90203ff 	str	xzr, [sp, #1024]
    a0e4:	d00000a0 	adrp	x0, 20000 <__data_start>
    a0e8:	91014005 	add	x5, x0, #0x50
    a0ec:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    a0f0:	f947f400 	ldr	x0, [x0, #4072]
    a0f4:	f0000374 	adrp	x20, 79000 <fwp_root_context+0xbb0>
    a0f8:	f941c8a6 	ldr	x6, [x5, #912]
    a0fc:	f9400001 	ldr	x1, [x0]
    a100:	f9042fe1 	str	x1, [sp, #2136]
    a104:	d2800001 	mov	x1, #0x0                   	// #0
    a108:	9118c298 	add	x24, x20, #0x630
    a10c:	912123f6 	add	x22, sp, #0x848
    a110:	910023e0 	add	x0, sp, #0x8
    a114:	910083e2 	add	x2, sp, #0x20
    a118:	f0ffffc1 	adrp	x1, 5000 <fwp_heap_alloc_slow+0x50>
    a11c:	90ffffc4 	adrp	x4, 2000 <__abi_tag+0x1d50>
    a120:	913a0021 	add	x1, x1, #0xe80
    a124:	913d4084 	add	x4, x4, #0xf50
    a128:	d2800013 	mov	x19, #0x0                   	// #0
    a12c:	d2800119 	mov	x25, #0x8                   	// #8
    a130:	d2800015 	mov	x21, #0x0                   	// #0
    a134:	52800037 	mov	w23, #0x1                   	// #1
    a138:	a90093e6 	stp	x6, x4, [sp, #8]
    a13c:	a901ffe2 	stp	x2, xzr, [sp, #24]
    a140:	a90307ff 	stp	xzr, x1, [sp, #48]
    a144:	f901c8a0 	str	x0, [x5, #912]
    a148:	f100073a 	subs	x26, x25, #0x1
    a14c:	aa1603e1 	mov	x1, x22
    a150:	da1f02bc 	sbc	x28, x21, xzr
    a154:	52800020 	mov	w0, #0x1                   	// #1
    a158:	f90017fa 	str	x26, [sp, #40]
    a15c:	aa1a03f9 	mov	x25, x26
    a160:	f90427fa 	str	x26, [sp, #2120]
    a164:	aa1c03f5 	mov	x21, x28
    a168:	f9042bf3 	str	x19, [sp, #2128]
    a16c:	97ffec4a 	bl	5294 <fwp_data.part.0.constprop.0>
    a170:	f949db02 	ldr	x2, [x24, #5040]
    a174:	aa0003f3 	mov	x19, x0
    a178:	f949ef00 	ldr	x0, [x24, #5080]
    a17c:	cb020262 	sub	x2, x19, x2
    a180:	eb00405f 	cmp	x2, x0, lsl #16
    a184:	54000302 	b.cs	a1e4 <f0+0x124>  // b.hs, b.nlast
    a188:	d350fc40 	lsr	x0, x2, #16
    a18c:	f949ff04 	ldr	x4, [x24, #5112]
    a190:	8b000800 	add	x0, x0, x0, lsl #2
    a194:	d37df001 	lsl	x1, x0, #3
    a198:	8b010080 	add	x0, x4, x1
    a19c:	f940101b 	ldr	x27, [x0, #32]
    a1a0:	b400023b 	cbz	x27, a1e4 <f0+0x124>
    a1a4:	38616881 	ldrb	w1, [x4, x1]
    a1a8:	7100083f 	cmp	w1, #0x2
    a1ac:	54011140 	b.eq	c3d4 <f0+0x2314>  // b.none
    a1b0:	7100043f 	cmp	w1, #0x1
    a1b4:	54000181 	b.ne	a1e4 <f0+0x124>  // b.any
    a1b8:	29430001 	ldp	w1, w0, [x0, #24]
    a1bc:	92403c42 	and	x2, x2, #0xffff
    a1c0:	9b017c42 	mul	x2, x2, x1
    a1c4:	d360fc42 	lsr	x2, x2, #32
    a1c8:	eb00005f 	cmp	x2, x0
    a1cc:	540000c2 	b.cs	a1e4 <f0+0x124>  // b.hs, b.nlast
    a1d0:	8b02037b 	add	x27, x27, x2
    a1d4:	39400360 	ldrb	w0, [x27]
    a1d8:	7103fc1f 	cmp	w0, #0xff
    a1dc:	54010f60 	b.eq	c3c8 <f0+0x2308>  // b.none
    a1e0:	39000377 	strb	w23, [x27]
    a1e4:	f90013f3 	str	x19, [sp, #32]
    a1e8:	aa1c035a 	orr	x26, x26, x28
    a1ec:	b5fffafa 	cbnz	x26, a148 <f0+0x88>
    a1f0:	90000023 	adrp	x3, e000 <_IO_stdin_used+0xb90>
    a1f4:	910103e1 	add	x1, sp, #0x40
    a1f8:	f94007e2 	ldr	x2, [sp, #8]
    a1fc:	d00000a0 	adrp	x0, 20000 <__data_start>
    a200:	3dc11460 	ldr	q0, [x3, #1104]
    a204:	91014018 	add	x24, x0, #0x50
    a208:	52800020 	mov	w0, #0x1                   	// #1
    a20c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a210:	3d8013e0 	str	q0, [sp, #64]
    a214:	f901cb02 	str	x2, [x24, #912]
    a218:	97ffec1f 	bl	5294 <fwp_data.part.0.constprop.0>
    a21c:	97ffee0d 	bl	5a50 <fwp_rc_fresh>
    a220:	aa0003e2 	mov	x2, x0
    a224:	910163e1 	add	x1, sp, #0x58
    a228:	52800020 	mov	w0, #0x1                   	// #1
    a22c:	a9058bf5 	stp	x21, x2, [sp, #88]
    a230:	97ffec19 	bl	5294 <fwp_data.part.0.constprop.0>
    a234:	97ffee07 	bl	5a50 <fwp_rc_fresh>
    a238:	aa0003e2 	mov	x2, x0
    a23c:	9101a3e1 	add	x1, sp, #0x68
    a240:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a244:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a248:	52800020 	mov	w0, #0x1                   	// #1
    a24c:	a9068be3 	stp	x3, x2, [sp, #104]
    a250:	97ffec11 	bl	5294 <fwp_data.part.0.constprop.0>
    a254:	97ffedff 	bl	5a50 <fwp_rc_fresh>
    a258:	aa0003e2 	mov	x2, x0
    a25c:	9101e3e1 	add	x1, sp, #0x78
    a260:	52800020 	mov	w0, #0x1                   	// #1
    a264:	a9078bf5 	stp	x21, x2, [sp, #120]
    a268:	97ffec0b 	bl	5294 <fwp_data.part.0.constprop.0>
    a26c:	97ffedf9 	bl	5a50 <fwp_rc_fresh>
    a270:	aa0003e2 	mov	x2, x0
    a274:	910223e1 	add	x1, sp, #0x88
    a278:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a27c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a280:	52800020 	mov	w0, #0x1                   	// #1
    a284:	a9088be3 	stp	x3, x2, [sp, #136]
    a288:	97ffec03 	bl	5294 <fwp_data.part.0.constprop.0>
    a28c:	97ffedf1 	bl	5a50 <fwp_rc_fresh>
    a290:	aa0003e2 	mov	x2, x0
    a294:	910263e1 	add	x1, sp, #0x98
    a298:	52800020 	mov	w0, #0x1                   	// #1
    a29c:	a9098bf5 	stp	x21, x2, [sp, #152]
    a2a0:	97ffebfd 	bl	5294 <fwp_data.part.0.constprop.0>
    a2a4:	97ffedeb 	bl	5a50 <fwp_rc_fresh>
    a2a8:	aa0003e2 	mov	x2, x0
    a2ac:	9102a3e1 	add	x1, sp, #0xa8
    a2b0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a2b4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a2b8:	52800020 	mov	w0, #0x1                   	// #1
    a2bc:	a90a8be3 	stp	x3, x2, [sp, #168]
    a2c0:	97ffebf5 	bl	5294 <fwp_data.part.0.constprop.0>
    a2c4:	97ffede3 	bl	5a50 <fwp_rc_fresh>
    a2c8:	aa0003e2 	mov	x2, x0
    a2cc:	9102e3e1 	add	x1, sp, #0xb8
    a2d0:	52800020 	mov	w0, #0x1                   	// #1
    a2d4:	a90b8bf5 	stp	x21, x2, [sp, #184]
    a2d8:	97ffebef 	bl	5294 <fwp_data.part.0.constprop.0>
    a2dc:	97ffeddd 	bl	5a50 <fwp_rc_fresh>
    a2e0:	aa0003e2 	mov	x2, x0
    a2e4:	910323e1 	add	x1, sp, #0xc8
    a2e8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a2ec:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a2f0:	52800020 	mov	w0, #0x1                   	// #1
    a2f4:	a90c8be3 	stp	x3, x2, [sp, #200]
    a2f8:	97ffebe7 	bl	5294 <fwp_data.part.0.constprop.0>
    a2fc:	97ffedd5 	bl	5a50 <fwp_rc_fresh>
    a300:	aa0003e2 	mov	x2, x0
    a304:	910363e1 	add	x1, sp, #0xd8
    a308:	52800020 	mov	w0, #0x1                   	// #1
    a30c:	a90d8bf5 	stp	x21, x2, [sp, #216]
    a310:	97ffebe1 	bl	5294 <fwp_data.part.0.constprop.0>
    a314:	97ffedcf 	bl	5a50 <fwp_rc_fresh>
    a318:	aa0003e2 	mov	x2, x0
    a31c:	9103a3e1 	add	x1, sp, #0xe8
    a320:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a324:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a328:	52800020 	mov	w0, #0x1                   	// #1
    a32c:	a90e8be3 	stp	x3, x2, [sp, #232]
    a330:	97ffebd9 	bl	5294 <fwp_data.part.0.constprop.0>
    a334:	97ffedc7 	bl	5a50 <fwp_rc_fresh>
    a338:	aa0003e2 	mov	x2, x0
    a33c:	9103e3e1 	add	x1, sp, #0xf8
    a340:	52800020 	mov	w0, #0x1                   	// #1
    a344:	a90f8bf5 	stp	x21, x2, [sp, #248]
    a348:	97ffebd3 	bl	5294 <fwp_data.part.0.constprop.0>
    a34c:	97ffedc1 	bl	5a50 <fwp_rc_fresh>
    a350:	aa0003e2 	mov	x2, x0
    a354:	910423e1 	add	x1, sp, #0x108
    a358:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a35c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a360:	52800020 	mov	w0, #0x1                   	// #1
    a364:	a9108be3 	stp	x3, x2, [sp, #264]
    a368:	97ffebcb 	bl	5294 <fwp_data.part.0.constprop.0>
    a36c:	97ffedb9 	bl	5a50 <fwp_rc_fresh>
    a370:	aa0003e2 	mov	x2, x0
    a374:	910463e1 	add	x1, sp, #0x118
    a378:	52800020 	mov	w0, #0x1                   	// #1
    a37c:	a9118bf5 	stp	x21, x2, [sp, #280]
    a380:	97ffebc5 	bl	5294 <fwp_data.part.0.constprop.0>
    a384:	97ffedb3 	bl	5a50 <fwp_rc_fresh>
    a388:	aa0003e2 	mov	x2, x0
    a38c:	9104a3e1 	add	x1, sp, #0x128
    a390:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a394:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a398:	52800020 	mov	w0, #0x1                   	// #1
    a39c:	a9128be3 	stp	x3, x2, [sp, #296]
    a3a0:	97ffebbd 	bl	5294 <fwp_data.part.0.constprop.0>
    a3a4:	97ffedab 	bl	5a50 <fwp_rc_fresh>
    a3a8:	aa0003e2 	mov	x2, x0
    a3ac:	9104e3e1 	add	x1, sp, #0x138
    a3b0:	52800020 	mov	w0, #0x1                   	// #1
    a3b4:	a9138bf5 	stp	x21, x2, [sp, #312]
    a3b8:	97ffebb7 	bl	5294 <fwp_data.part.0.constprop.0>
    a3bc:	97ffeda5 	bl	5a50 <fwp_rc_fresh>
    a3c0:	aa0003e2 	mov	x2, x0
    a3c4:	910523e1 	add	x1, sp, #0x148
    a3c8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a3cc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a3d0:	52800020 	mov	w0, #0x1                   	// #1
    a3d4:	a9148be3 	stp	x3, x2, [sp, #328]
    a3d8:	97ffebaf 	bl	5294 <fwp_data.part.0.constprop.0>
    a3dc:	97ffed9d 	bl	5a50 <fwp_rc_fresh>
    a3e0:	aa0003e2 	mov	x2, x0
    a3e4:	910563e1 	add	x1, sp, #0x158
    a3e8:	52800020 	mov	w0, #0x1                   	// #1
    a3ec:	a9158bf5 	stp	x21, x2, [sp, #344]
    a3f0:	97ffeba9 	bl	5294 <fwp_data.part.0.constprop.0>
    a3f4:	97ffed97 	bl	5a50 <fwp_rc_fresh>
    a3f8:	aa0003e2 	mov	x2, x0
    a3fc:	9105a3e1 	add	x1, sp, #0x168
    a400:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a404:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a408:	52800020 	mov	w0, #0x1                   	// #1
    a40c:	a9168be3 	stp	x3, x2, [sp, #360]
    a410:	97ffeba1 	bl	5294 <fwp_data.part.0.constprop.0>
    a414:	97ffed8f 	bl	5a50 <fwp_rc_fresh>
    a418:	aa0003e2 	mov	x2, x0
    a41c:	9105e3e1 	add	x1, sp, #0x178
    a420:	52800020 	mov	w0, #0x1                   	// #1
    a424:	a9178bf5 	stp	x21, x2, [sp, #376]
    a428:	97ffeb9b 	bl	5294 <fwp_data.part.0.constprop.0>
    a42c:	97ffed89 	bl	5a50 <fwp_rc_fresh>
    a430:	aa0003e2 	mov	x2, x0
    a434:	910623e1 	add	x1, sp, #0x188
    a438:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a43c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a440:	52800020 	mov	w0, #0x1                   	// #1
    a444:	a9188be3 	stp	x3, x2, [sp, #392]
    a448:	97ffeb93 	bl	5294 <fwp_data.part.0.constprop.0>
    a44c:	97ffed81 	bl	5a50 <fwp_rc_fresh>
    a450:	aa0003e2 	mov	x2, x0
    a454:	910663e1 	add	x1, sp, #0x198
    a458:	52800020 	mov	w0, #0x1                   	// #1
    a45c:	a9198bf5 	stp	x21, x2, [sp, #408]
    a460:	97ffeb8d 	bl	5294 <fwp_data.part.0.constprop.0>
    a464:	97ffed7b 	bl	5a50 <fwp_rc_fresh>
    a468:	aa0003e2 	mov	x2, x0
    a46c:	9106a3e1 	add	x1, sp, #0x1a8
    a470:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a474:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a478:	52800020 	mov	w0, #0x1                   	// #1
    a47c:	a91a8be3 	stp	x3, x2, [sp, #424]
    a480:	97ffeb85 	bl	5294 <fwp_data.part.0.constprop.0>
    a484:	97ffed73 	bl	5a50 <fwp_rc_fresh>
    a488:	aa0003e2 	mov	x2, x0
    a48c:	9106e3e1 	add	x1, sp, #0x1b8
    a490:	52800020 	mov	w0, #0x1                   	// #1
    a494:	a91b8bf5 	stp	x21, x2, [sp, #440]
    a498:	97ffeb7f 	bl	5294 <fwp_data.part.0.constprop.0>
    a49c:	97ffed6d 	bl	5a50 <fwp_rc_fresh>
    a4a0:	aa0003e2 	mov	x2, x0
    a4a4:	910723e1 	add	x1, sp, #0x1c8
    a4a8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a4ac:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a4b0:	52800020 	mov	w0, #0x1                   	// #1
    a4b4:	a91c8be3 	stp	x3, x2, [sp, #456]
    a4b8:	97ffeb77 	bl	5294 <fwp_data.part.0.constprop.0>
    a4bc:	97ffed65 	bl	5a50 <fwp_rc_fresh>
    a4c0:	aa0003e2 	mov	x2, x0
    a4c4:	910763e1 	add	x1, sp, #0x1d8
    a4c8:	52800020 	mov	w0, #0x1                   	// #1
    a4cc:	a91d8bf5 	stp	x21, x2, [sp, #472]
    a4d0:	97ffeb71 	bl	5294 <fwp_data.part.0.constprop.0>
    a4d4:	97ffed5f 	bl	5a50 <fwp_rc_fresh>
    a4d8:	aa0003e2 	mov	x2, x0
    a4dc:	9107a3e1 	add	x1, sp, #0x1e8
    a4e0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a4e4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a4e8:	52800020 	mov	w0, #0x1                   	// #1
    a4ec:	a91e8be3 	stp	x3, x2, [sp, #488]
    a4f0:	97ffeb69 	bl	5294 <fwp_data.part.0.constprop.0>
    a4f4:	97ffed57 	bl	5a50 <fwp_rc_fresh>
    a4f8:	aa0003e2 	mov	x2, x0
    a4fc:	9107e3e1 	add	x1, sp, #0x1f8
    a500:	52800020 	mov	w0, #0x1                   	// #1
    a504:	a91f8bf5 	stp	x21, x2, [sp, #504]
    a508:	97ffeb63 	bl	5294 <fwp_data.part.0.constprop.0>
    a50c:	97ffed51 	bl	5a50 <fwp_rc_fresh>
    a510:	aa0003e2 	mov	x2, x0
    a514:	910823e1 	add	x1, sp, #0x208
    a518:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a51c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a520:	52800020 	mov	w0, #0x1                   	// #1
    a524:	f90107e3 	str	x3, [sp, #520]
    a528:	f9010be2 	str	x2, [sp, #528]
    a52c:	97ffeb5a 	bl	5294 <fwp_data.part.0.constprop.0>
    a530:	97ffed48 	bl	5a50 <fwp_rc_fresh>
    a534:	aa0003e2 	mov	x2, x0
    a538:	910863e1 	add	x1, sp, #0x218
    a53c:	52800020 	mov	w0, #0x1                   	// #1
    a540:	f9010ff5 	str	x21, [sp, #536]
    a544:	f90113e2 	str	x2, [sp, #544]
    a548:	97ffeb53 	bl	5294 <fwp_data.part.0.constprop.0>
    a54c:	97ffed41 	bl	5a50 <fwp_rc_fresh>
    a550:	aa0003e2 	mov	x2, x0
    a554:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a558:	9108a3e1 	add	x1, sp, #0x228
    a55c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a560:	52800020 	mov	w0, #0x1                   	// #1
    a564:	f90117e3 	str	x3, [sp, #552]
    a568:	f9011be2 	str	x2, [sp, #560]
    a56c:	97ffeb4a 	bl	5294 <fwp_data.part.0.constprop.0>
    a570:	97ffed38 	bl	5a50 <fwp_rc_fresh>
    a574:	aa0003e2 	mov	x2, x0
    a578:	9108e3e1 	add	x1, sp, #0x238
    a57c:	52800020 	mov	w0, #0x1                   	// #1
    a580:	f9011ff5 	str	x21, [sp, #568]
    a584:	f90123e2 	str	x2, [sp, #576]
    a588:	97ffeb43 	bl	5294 <fwp_data.part.0.constprop.0>
    a58c:	9118c283 	add	x3, x20, #0x630
    a590:	aa0003f5 	mov	x21, x0
    a594:	f949d861 	ldr	x1, [x3, #5040]
    a598:	f949ec60 	ldr	x0, [x3, #5080]
    a59c:	cb0102a1 	sub	x1, x21, x1
    a5a0:	eb00403f 	cmp	x1, x0, lsl #16
    a5a4:	54000322 	b.cs	a608 <f0+0x548>  // b.hs, b.nlast
    a5a8:	d350fc22 	lsr	x2, x1, #16
    a5ac:	f949fc63 	ldr	x3, [x3, #5112]
    a5b0:	8b020842 	add	x2, x2, x2, lsl #2
    a5b4:	d37df042 	lsl	x2, x2, #3
    a5b8:	8b020060 	add	x0, x3, x2
    a5bc:	f9401017 	ldr	x23, [x0, #32]
    a5c0:	b4000257 	cbz	x23, a608 <f0+0x548>
    a5c4:	38626862 	ldrb	w2, [x3, x2]
    a5c8:	7100085f 	cmp	w2, #0x2
    a5cc:	5400f460 	b.eq	c458 <f0+0x2398>  // b.none
    a5d0:	7100045f 	cmp	w2, #0x1
    a5d4:	540001a1 	b.ne	a608 <f0+0x548>  // b.any
    a5d8:	29430002 	ldp	w2, w0, [x0, #24]
    a5dc:	92403c21 	and	x1, x1, #0xffff
    a5e0:	9b027c21 	mul	x1, x1, x2
    a5e4:	d360fc21 	lsr	x1, x1, #32
    a5e8:	eb00003f 	cmp	x1, x0
    a5ec:	540000e2 	b.cs	a608 <f0+0x548>  // b.hs, b.nlast
    a5f0:	8b0102f7 	add	x23, x23, x1
    a5f4:	394002e0 	ldrb	w0, [x23]
    a5f8:	7103fc1f 	cmp	w0, #0xff
    a5fc:	5400fe20 	b.eq	c5c0 <f0+0x2500>  // b.none
    a600:	52800020 	mov	w0, #0x1                   	// #1
    a604:	390002e0 	strb	w0, [x23]
    a608:	910923e1 	add	x1, sp, #0x248
    a60c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a610:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a614:	52800020 	mov	w0, #0x1                   	// #1
    a618:	f90127f7 	str	x23, [sp, #584]
    a61c:	f9012bf5 	str	x21, [sp, #592]
    a620:	97ffeb1d 	bl	5294 <fwp_data.part.0.constprop.0>
    a624:	97ffed0b 	bl	5a50 <fwp_rc_fresh>
    a628:	aa0003e2 	mov	x2, x0
    a62c:	910963e1 	add	x1, sp, #0x258
    a630:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a634:	52800020 	mov	w0, #0x1                   	// #1
    a638:	f9012ff5 	str	x21, [sp, #600]
    a63c:	f90133e2 	str	x2, [sp, #608]
    a640:	97ffeb15 	bl	5294 <fwp_data.part.0.constprop.0>
    a644:	97ffed03 	bl	5a50 <fwp_rc_fresh>
    a648:	aa0003e2 	mov	x2, x0
    a64c:	9109a3e1 	add	x1, sp, #0x268
    a650:	52800020 	mov	w0, #0x1                   	// #1
    a654:	f90137f7 	str	x23, [sp, #616]
    a658:	f9013be2 	str	x2, [sp, #624]
    a65c:	97ffeb0e 	bl	5294 <fwp_data.part.0.constprop.0>
    a660:	97ffecfc 	bl	5a50 <fwp_rc_fresh>
    a664:	aa0003e2 	mov	x2, x0
    a668:	9109e3e1 	add	x1, sp, #0x278
    a66c:	52800020 	mov	w0, #0x1                   	// #1
    a670:	f9013ff5 	str	x21, [sp, #632]
    a674:	f90143e2 	str	x2, [sp, #640]
    a678:	97ffeb07 	bl	5294 <fwp_data.part.0.constprop.0>
    a67c:	97ffecf5 	bl	5a50 <fwp_rc_fresh>
    a680:	aa0003e2 	mov	x2, x0
    a684:	910a23e1 	add	x1, sp, #0x288
    a688:	52800020 	mov	w0, #0x1                   	// #1
    a68c:	f90147f7 	str	x23, [sp, #648]
    a690:	f9014be2 	str	x2, [sp, #656]
    a694:	97ffeb00 	bl	5294 <fwp_data.part.0.constprop.0>
    a698:	97ffecee 	bl	5a50 <fwp_rc_fresh>
    a69c:	aa0003e2 	mov	x2, x0
    a6a0:	910a63e1 	add	x1, sp, #0x298
    a6a4:	52800020 	mov	w0, #0x1                   	// #1
    a6a8:	f9014ff5 	str	x21, [sp, #664]
    a6ac:	f90153e2 	str	x2, [sp, #672]
    a6b0:	97ffeaf9 	bl	5294 <fwp_data.part.0.constprop.0>
    a6b4:	9118c283 	add	x3, x20, #0x630
    a6b8:	aa0003f5 	mov	x21, x0
    a6bc:	f949d861 	ldr	x1, [x3, #5040]
    a6c0:	f949ec60 	ldr	x0, [x3, #5080]
    a6c4:	cb0102a1 	sub	x1, x21, x1
    a6c8:	eb00403f 	cmp	x1, x0, lsl #16
    a6cc:	54000322 	b.cs	a730 <f0+0x670>  // b.hs, b.nlast
    a6d0:	d350fc22 	lsr	x2, x1, #16
    a6d4:	f949fc63 	ldr	x3, [x3, #5112]
    a6d8:	8b020842 	add	x2, x2, x2, lsl #2
    a6dc:	d37df042 	lsl	x2, x2, #3
    a6e0:	8b020060 	add	x0, x3, x2
    a6e4:	f9401017 	ldr	x23, [x0, #32]
    a6e8:	b4000257 	cbz	x23, a730 <f0+0x670>
    a6ec:	38626862 	ldrb	w2, [x3, x2]
    a6f0:	7100085f 	cmp	w2, #0x2
    a6f4:	5400eac0 	b.eq	c44c <f0+0x238c>  // b.none
    a6f8:	7100045f 	cmp	w2, #0x1
    a6fc:	540001a1 	b.ne	a730 <f0+0x670>  // b.any
    a700:	29430002 	ldp	w2, w0, [x0, #24]
    a704:	92403c21 	and	x1, x1, #0xffff
    a708:	9b027c21 	mul	x1, x1, x2
    a70c:	d360fc21 	lsr	x1, x1, #32
    a710:	eb00003f 	cmp	x1, x0
    a714:	540000e2 	b.cs	a730 <f0+0x670>  // b.hs, b.nlast
    a718:	8b0102f7 	add	x23, x23, x1
    a71c:	394002e0 	ldrb	w0, [x23]
    a720:	7103fc1f 	cmp	w0, #0xff
    a724:	5400f540 	b.eq	c5cc <f0+0x250c>  // b.none
    a728:	52800020 	mov	w0, #0x1                   	// #1
    a72c:	390002e0 	strb	w0, [x23]
    a730:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a734:	910aa3e1 	add	x1, sp, #0x2a8
    a738:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a73c:	52800020 	mov	w0, #0x1                   	// #1
    a740:	f90157e2 	str	x2, [sp, #680]
    a744:	f9015bf5 	str	x21, [sp, #688]
    a748:	97ffead3 	bl	5294 <fwp_data.part.0.constprop.0>
    a74c:	97ffecc1 	bl	5a50 <fwp_rc_fresh>
    a750:	aa0003e2 	mov	x2, x0
    a754:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a758:	910ae3e1 	add	x1, sp, #0x2b8
    a75c:	52800020 	mov	w0, #0x1                   	// #1
    a760:	f9015fe3 	str	x3, [sp, #696]
    a764:	f90163e2 	str	x2, [sp, #704]
    a768:	97ffeacb 	bl	5294 <fwp_data.part.0.constprop.0>
    a76c:	9118c283 	add	x3, x20, #0x630
    a770:	aa0003f5 	mov	x21, x0
    a774:	f949d861 	ldr	x1, [x3, #5040]
    a778:	f949ec60 	ldr	x0, [x3, #5080]
    a77c:	cb0102a1 	sub	x1, x21, x1
    a780:	eb00403f 	cmp	x1, x0, lsl #16
    a784:	54000322 	b.cs	a7e8 <f0+0x728>  // b.hs, b.nlast
    a788:	d350fc22 	lsr	x2, x1, #16
    a78c:	f949fc63 	ldr	x3, [x3, #5112]
    a790:	8b020842 	add	x2, x2, x2, lsl #2
    a794:	d37df042 	lsl	x2, x2, #3
    a798:	8b020060 	add	x0, x3, x2
    a79c:	f9401017 	ldr	x23, [x0, #32]
    a7a0:	b4000257 	cbz	x23, a7e8 <f0+0x728>
    a7a4:	38626862 	ldrb	w2, [x3, x2]
    a7a8:	7100085f 	cmp	w2, #0x2
    a7ac:	5400e4a0 	b.eq	c440 <f0+0x2380>  // b.none
    a7b0:	7100045f 	cmp	w2, #0x1
    a7b4:	540001a1 	b.ne	a7e8 <f0+0x728>  // b.any
    a7b8:	29430002 	ldp	w2, w0, [x0, #24]
    a7bc:	92403c21 	and	x1, x1, #0xffff
    a7c0:	9b027c21 	mul	x1, x1, x2
    a7c4:	d360fc21 	lsr	x1, x1, #32
    a7c8:	eb00003f 	cmp	x1, x0
    a7cc:	540000e2 	b.cs	a7e8 <f0+0x728>  // b.hs, b.nlast
    a7d0:	8b0102f7 	add	x23, x23, x1
    a7d4:	394002e0 	ldrb	w0, [x23]
    a7d8:	7103fc1f 	cmp	w0, #0xff
    a7dc:	5400efe0 	b.eq	c5d8 <f0+0x2518>  // b.none
    a7e0:	52800020 	mov	w0, #0x1                   	// #1
    a7e4:	390002e0 	strb	w0, [x23]
    a7e8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a7ec:	910b23e1 	add	x1, sp, #0x2c8
    a7f0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a7f4:	52800020 	mov	w0, #0x1                   	// #1
    a7f8:	f90167e2 	str	x2, [sp, #712]
    a7fc:	f9016bf5 	str	x21, [sp, #720]
    a800:	97ffeaa5 	bl	5294 <fwp_data.part.0.constprop.0>
    a804:	9118c283 	add	x3, x20, #0x630
    a808:	aa0003f5 	mov	x21, x0
    a80c:	f949d861 	ldr	x1, [x3, #5040]
    a810:	f949ec60 	ldr	x0, [x3, #5080]
    a814:	cb0102a1 	sub	x1, x21, x1
    a818:	eb00403f 	cmp	x1, x0, lsl #16
    a81c:	54000322 	b.cs	a880 <f0+0x7c0>  // b.hs, b.nlast
    a820:	d350fc22 	lsr	x2, x1, #16
    a824:	f949fc63 	ldr	x3, [x3, #5112]
    a828:	8b020842 	add	x2, x2, x2, lsl #2
    a82c:	d37df042 	lsl	x2, x2, #3
    a830:	8b020060 	add	x0, x3, x2
    a834:	f9401017 	ldr	x23, [x0, #32]
    a838:	b4000257 	cbz	x23, a880 <f0+0x7c0>
    a83c:	38626862 	ldrb	w2, [x3, x2]
    a840:	7100085f 	cmp	w2, #0x2
    a844:	5400e220 	b.eq	c488 <f0+0x23c8>  // b.none
    a848:	7100045f 	cmp	w2, #0x1
    a84c:	540001a1 	b.ne	a880 <f0+0x7c0>  // b.any
    a850:	29430002 	ldp	w2, w0, [x0, #24]
    a854:	92403c21 	and	x1, x1, #0xffff
    a858:	9b027c21 	mul	x1, x1, x2
    a85c:	d360fc21 	lsr	x1, x1, #32
    a860:	eb00003f 	cmp	x1, x0
    a864:	540000e2 	b.cs	a880 <f0+0x7c0>  // b.hs, b.nlast
    a868:	8b0102f7 	add	x23, x23, x1
    a86c:	394002e0 	ldrb	w0, [x23]
    a870:	7103fc1f 	cmp	w0, #0xff
    a874:	5400eb80 	b.eq	c5e4 <f0+0x2524>  // b.none
    a878:	52800020 	mov	w0, #0x1                   	// #1
    a87c:	390002e0 	strb	w0, [x23]
    a880:	910b63e1 	add	x1, sp, #0x2d8
    a884:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a888:	52800020 	mov	w0, #0x1                   	// #1
    a88c:	f9016ff7 	str	x23, [sp, #728]
    a890:	f90173f5 	str	x21, [sp, #736]
    a894:	97ffea80 	bl	5294 <fwp_data.part.0.constprop.0>
    a898:	97ffec6e 	bl	5a50 <fwp_rc_fresh>
    a89c:	aa0003e2 	mov	x2, x0
    a8a0:	910ba3e1 	add	x1, sp, #0x2e8
    a8a4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a8a8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a8ac:	52800020 	mov	w0, #0x1                   	// #1
    a8b0:	f90177f5 	str	x21, [sp, #744]
    a8b4:	f9017be2 	str	x2, [sp, #752]
    a8b8:	97ffea77 	bl	5294 <fwp_data.part.0.constprop.0>
    a8bc:	97ffec65 	bl	5a50 <fwp_rc_fresh>
    a8c0:	aa0003e2 	mov	x2, x0
    a8c4:	910be3e1 	add	x1, sp, #0x2f8
    a8c8:	52800020 	mov	w0, #0x1                   	// #1
    a8cc:	f9017ff7 	str	x23, [sp, #760]
    a8d0:	f90183e2 	str	x2, [sp, #768]
    a8d4:	97ffea70 	bl	5294 <fwp_data.part.0.constprop.0>
    a8d8:	97ffec5e 	bl	5a50 <fwp_rc_fresh>
    a8dc:	aa0003e2 	mov	x2, x0
    a8e0:	910c23e1 	add	x1, sp, #0x308
    a8e4:	52800020 	mov	w0, #0x1                   	// #1
    a8e8:	f90187f5 	str	x21, [sp, #776]
    a8ec:	f9018be2 	str	x2, [sp, #784]
    a8f0:	97ffea69 	bl	5294 <fwp_data.part.0.constprop.0>
    a8f4:	9118c283 	add	x3, x20, #0x630
    a8f8:	aa0003f5 	mov	x21, x0
    a8fc:	f949d861 	ldr	x1, [x3, #5040]
    a900:	f949ec60 	ldr	x0, [x3, #5080]
    a904:	cb0102a1 	sub	x1, x21, x1
    a908:	eb00403f 	cmp	x1, x0, lsl #16
    a90c:	54000322 	b.cs	a970 <f0+0x8b0>  // b.hs, b.nlast
    a910:	d350fc22 	lsr	x2, x1, #16
    a914:	f949fc63 	ldr	x3, [x3, #5112]
    a918:	8b020842 	add	x2, x2, x2, lsl #2
    a91c:	d37df042 	lsl	x2, x2, #3
    a920:	8b020060 	add	x0, x3, x2
    a924:	f9401017 	ldr	x23, [x0, #32]
    a928:	b4000257 	cbz	x23, a970 <f0+0x8b0>
    a92c:	38626862 	ldrb	w2, [x3, x2]
    a930:	7100085f 	cmp	w2, #0x2
    a934:	5400da40 	b.eq	c47c <f0+0x23bc>  // b.none
    a938:	7100045f 	cmp	w2, #0x1
    a93c:	540001a1 	b.ne	a970 <f0+0x8b0>  // b.any
    a940:	29430002 	ldp	w2, w0, [x0, #24]
    a944:	92403c21 	and	x1, x1, #0xffff
    a948:	9b027c21 	mul	x1, x1, x2
    a94c:	d360fc21 	lsr	x1, x1, #32
    a950:	eb00003f 	cmp	x1, x0
    a954:	540000e2 	b.cs	a970 <f0+0x8b0>  // b.hs, b.nlast
    a958:	8b0102f7 	add	x23, x23, x1
    a95c:	394002e0 	ldrb	w0, [x23]
    a960:	7103fc1f 	cmp	w0, #0xff
    a964:	5400e460 	b.eq	c5f0 <f0+0x2530>  // b.none
    a968:	52800020 	mov	w0, #0x1                   	// #1
    a96c:	390002e0 	strb	w0, [x23]
    a970:	910c63e1 	add	x1, sp, #0x318
    a974:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a978:	52800020 	mov	w0, #0x1                   	// #1
    a97c:	f9018ff7 	str	x23, [sp, #792]
    a980:	f90193f5 	str	x21, [sp, #800]
    a984:	97ffea44 	bl	5294 <fwp_data.part.0.constprop.0>
    a988:	97ffec32 	bl	5a50 <fwp_rc_fresh>
    a98c:	aa0003e2 	mov	x2, x0
    a990:	910ca3e1 	add	x1, sp, #0x328
    a994:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a998:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a99c:	52800020 	mov	w0, #0x1                   	// #1
    a9a0:	f90197f5 	str	x21, [sp, #808]
    a9a4:	f9019be2 	str	x2, [sp, #816]
    a9a8:	97ffea3b 	bl	5294 <fwp_data.part.0.constprop.0>
    a9ac:	97ffec29 	bl	5a50 <fwp_rc_fresh>
    a9b0:	aa0003e2 	mov	x2, x0
    a9b4:	910ce3e1 	add	x1, sp, #0x338
    a9b8:	52800020 	mov	w0, #0x1                   	// #1
    a9bc:	f9019ff7 	str	x23, [sp, #824]
    a9c0:	f901a3e2 	str	x2, [sp, #832]
    a9c4:	97ffea34 	bl	5294 <fwp_data.part.0.constprop.0>
    a9c8:	97ffec22 	bl	5a50 <fwp_rc_fresh>
    a9cc:	aa0003e2 	mov	x2, x0
    a9d0:	910d23e1 	add	x1, sp, #0x348
    a9d4:	52800020 	mov	w0, #0x1                   	// #1
    a9d8:	f901a7f5 	str	x21, [sp, #840]
    a9dc:	f901abe2 	str	x2, [sp, #848]
    a9e0:	97ffea2d 	bl	5294 <fwp_data.part.0.constprop.0>
    a9e4:	97ffec1b 	bl	5a50 <fwp_rc_fresh>
    a9e8:	aa0003e2 	mov	x2, x0
    a9ec:	910d63e1 	add	x1, sp, #0x358
    a9f0:	52800020 	mov	w0, #0x1                   	// #1
    a9f4:	f901aff7 	str	x23, [sp, #856]
    a9f8:	f901b3e2 	str	x2, [sp, #864]
    a9fc:	97ffea26 	bl	5294 <fwp_data.part.0.constprop.0>
    aa00:	97ffec14 	bl	5a50 <fwp_rc_fresh>
    aa04:	aa0003e2 	mov	x2, x0
    aa08:	910da3e1 	add	x1, sp, #0x368
    aa0c:	52800020 	mov	w0, #0x1                   	// #1
    aa10:	f901b7f5 	str	x21, [sp, #872]
    aa14:	f901bbe2 	str	x2, [sp, #880]
    aa18:	97ffea1f 	bl	5294 <fwp_data.part.0.constprop.0>
    aa1c:	97ffec0d 	bl	5a50 <fwp_rc_fresh>
    aa20:	aa0003e2 	mov	x2, x0
    aa24:	910de3e1 	add	x1, sp, #0x378
    aa28:	52800020 	mov	w0, #0x1                   	// #1
    aa2c:	f901bff7 	str	x23, [sp, #888]
    aa30:	f901c3e2 	str	x2, [sp, #896]
    aa34:	97ffea18 	bl	5294 <fwp_data.part.0.constprop.0>
    aa38:	97ffec06 	bl	5a50 <fwp_rc_fresh>
    aa3c:	aa0003e2 	mov	x2, x0
    aa40:	910e23e1 	add	x1, sp, #0x388
    aa44:	52800020 	mov	w0, #0x1                   	// #1
    aa48:	f901c7f5 	str	x21, [sp, #904]
    aa4c:	f901cbe2 	str	x2, [sp, #912]
    aa50:	97ffea11 	bl	5294 <fwp_data.part.0.constprop.0>
    aa54:	97ffebff 	bl	5a50 <fwp_rc_fresh>
    aa58:	aa0003e2 	mov	x2, x0
    aa5c:	910e63e1 	add	x1, sp, #0x398
    aa60:	52800020 	mov	w0, #0x1                   	// #1
    aa64:	f901cff7 	str	x23, [sp, #920]
    aa68:	f901d3e2 	str	x2, [sp, #928]
    aa6c:	97ffea0a 	bl	5294 <fwp_data.part.0.constprop.0>
    aa70:	97ffebf8 	bl	5a50 <fwp_rc_fresh>
    aa74:	aa0003e2 	mov	x2, x0
    aa78:	910ea3e1 	add	x1, sp, #0x3a8
    aa7c:	52800020 	mov	w0, #0x1                   	// #1
    aa80:	f901d7f5 	str	x21, [sp, #936]
    aa84:	f901dbe2 	str	x2, [sp, #944]
    aa88:	97ffea03 	bl	5294 <fwp_data.part.0.constprop.0>
    aa8c:	9118c283 	add	x3, x20, #0x630
    aa90:	aa0003f5 	mov	x21, x0
    aa94:	f949d861 	ldr	x1, [x3, #5040]
    aa98:	f949ec60 	ldr	x0, [x3, #5080]
    aa9c:	cb0102a1 	sub	x1, x21, x1
    aaa0:	eb00403f 	cmp	x1, x0, lsl #16
    aaa4:	54000322 	b.cs	ab08 <f0+0xa48>  // b.hs, b.nlast
    aaa8:	d350fc22 	lsr	x2, x1, #16
    aaac:	f949fc63 	ldr	x3, [x3, #5112]
    aab0:	8b020842 	add	x2, x2, x2, lsl #2
    aab4:	d37df042 	lsl	x2, x2, #3
    aab8:	8b020060 	add	x0, x3, x2
    aabc:	f9401017 	ldr	x23, [x0, #32]
    aac0:	b4000257 	cbz	x23, ab08 <f0+0xa48>
    aac4:	38626862 	ldrb	w2, [x3, x2]
    aac8:	7100085f 	cmp	w2, #0x2
    aacc:	5400cd20 	b.eq	c470 <f0+0x23b0>  // b.none
    aad0:	7100045f 	cmp	w2, #0x1
    aad4:	540001a1 	b.ne	ab08 <f0+0xa48>  // b.any
    aad8:	29430002 	ldp	w2, w0, [x0, #24]
    aadc:	92403c21 	and	x1, x1, #0xffff
    aae0:	9b027c21 	mul	x1, x1, x2
    aae4:	d360fc21 	lsr	x1, x1, #32
    aae8:	eb00003f 	cmp	x1, x0
    aaec:	540000e2 	b.cs	ab08 <f0+0xa48>  // b.hs, b.nlast
    aaf0:	8b0102f7 	add	x23, x23, x1
    aaf4:	394002e0 	ldrb	w0, [x23]
    aaf8:	7103fc1f 	cmp	w0, #0xff
    aafc:	5400d800 	b.eq	c5fc <f0+0x253c>  // b.none
    ab00:	52800020 	mov	w0, #0x1                   	// #1
    ab04:	390002e0 	strb	w0, [x23]
    ab08:	910ee3e1 	add	x1, sp, #0x3b8
    ab0c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ab10:	52800020 	mov	w0, #0x1                   	// #1
    ab14:	f901dfe2 	str	x2, [sp, #952]
    ab18:	f901e3f5 	str	x21, [sp, #960]
    ab1c:	97ffe9de 	bl	5294 <fwp_data.part.0.constprop.0>
    ab20:	97ffebcc 	bl	5a50 <fwp_rc_fresh>
    ab24:	aa0003e2 	mov	x2, x0
    ab28:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ab2c:	910f23e1 	add	x1, sp, #0x3c8
    ab30:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ab34:	52800020 	mov	w0, #0x1                   	// #1
    ab38:	f901e7e3 	str	x3, [sp, #968]
    ab3c:	f901ebe2 	str	x2, [sp, #976]
    ab40:	97ffe9d5 	bl	5294 <fwp_data.part.0.constprop.0>
    ab44:	9118c283 	add	x3, x20, #0x630
    ab48:	aa0003f5 	mov	x21, x0
    ab4c:	f949d861 	ldr	x1, [x3, #5040]
    ab50:	f949ec60 	ldr	x0, [x3, #5080]
    ab54:	cb0102a1 	sub	x1, x21, x1
    ab58:	eb00403f 	cmp	x1, x0, lsl #16
    ab5c:	54000322 	b.cs	abc0 <f0+0xb00>  // b.hs, b.nlast
    ab60:	d350fc22 	lsr	x2, x1, #16
    ab64:	f949fc63 	ldr	x3, [x3, #5112]
    ab68:	8b020842 	add	x2, x2, x2, lsl #2
    ab6c:	d37df042 	lsl	x2, x2, #3
    ab70:	8b020060 	add	x0, x3, x2
    ab74:	f9401017 	ldr	x23, [x0, #32]
    ab78:	b4000257 	cbz	x23, abc0 <f0+0xb00>
    ab7c:	38626862 	ldrb	w2, [x3, x2]
    ab80:	7100085f 	cmp	w2, #0x2
    ab84:	5400c700 	b.eq	c464 <f0+0x23a4>  // b.none
    ab88:	7100045f 	cmp	w2, #0x1
    ab8c:	540001a1 	b.ne	abc0 <f0+0xb00>  // b.any
    ab90:	29430002 	ldp	w2, w0, [x0, #24]
    ab94:	92403c21 	and	x1, x1, #0xffff
    ab98:	9b027c21 	mul	x1, x1, x2
    ab9c:	d360fc21 	lsr	x1, x1, #32
    aba0:	eb00003f 	cmp	x1, x0
    aba4:	540000e2 	b.cs	abc0 <f0+0xb00>  // b.hs, b.nlast
    aba8:	8b0102f7 	add	x23, x23, x1
    abac:	394002e0 	ldrb	w0, [x23]
    abb0:	7103fc1f 	cmp	w0, #0xff
    abb4:	5400d2a0 	b.eq	c608 <f0+0x2548>  // b.none
    abb8:	52800020 	mov	w0, #0x1                   	// #1
    abbc:	390002e0 	strb	w0, [x23]
    abc0:	910f63e1 	add	x1, sp, #0x3d8
    abc4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    abc8:	52800020 	mov	w0, #0x1                   	// #1
    abcc:	f901efe2 	str	x2, [sp, #984]
    abd0:	f901f3f5 	str	x21, [sp, #992]
    abd4:	97ffe9b0 	bl	5294 <fwp_data.part.0.constprop.0>
    abd8:	97ffeb9e 	bl	5a50 <fwp_rc_fresh>
    abdc:	aa0003e2 	mov	x2, x0
    abe0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    abe4:	910fa3e1 	add	x1, sp, #0x3e8
    abe8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    abec:	52800020 	mov	w0, #0x1                   	// #1
    abf0:	f901f7e3 	str	x3, [sp, #1000]
    abf4:	f901fbe2 	str	x2, [sp, #1008]
    abf8:	97ffe9a7 	bl	5294 <fwp_data.part.0.constprop.0>
    abfc:	9118c283 	add	x3, x20, #0x630
    ac00:	aa0003f7 	mov	x23, x0
    ac04:	f949d861 	ldr	x1, [x3, #5040]
    ac08:	f949ec60 	ldr	x0, [x3, #5080]
    ac0c:	cb0102e1 	sub	x1, x23, x1
    ac10:	eb00403f 	cmp	x1, x0, lsl #16
    ac14:	54000322 	b.cs	ac78 <f0+0xbb8>  // b.hs, b.nlast
    ac18:	d350fc22 	lsr	x2, x1, #16
    ac1c:	f949fc63 	ldr	x3, [x3, #5112]
    ac20:	8b020842 	add	x2, x2, x2, lsl #2
    ac24:	d37df042 	lsl	x2, x2, #3
    ac28:	8b020060 	add	x0, x3, x2
    ac2c:	f9401015 	ldr	x21, [x0, #32]
    ac30:	b4000255 	cbz	x21, ac78 <f0+0xbb8>
    ac34:	38626862 	ldrb	w2, [x3, x2]
    ac38:	7100085f 	cmp	w2, #0x2
    ac3c:	5400c560 	b.eq	c4e8 <f0+0x2428>  // b.none
    ac40:	7100045f 	cmp	w2, #0x1
    ac44:	540001a1 	b.ne	ac78 <f0+0xbb8>  // b.any
    ac48:	29430002 	ldp	w2, w0, [x0, #24]
    ac4c:	92403c21 	and	x1, x1, #0xffff
    ac50:	9b027c21 	mul	x1, x1, x2
    ac54:	d360fc21 	lsr	x1, x1, #32
    ac58:	eb00003f 	cmp	x1, x0
    ac5c:	540000e2 	b.cs	ac78 <f0+0xbb8>  // b.hs, b.nlast
    ac60:	8b0102b5 	add	x21, x21, x1
    ac64:	394002a0 	ldrb	w0, [x21]
    ac68:	7103fc1f 	cmp	w0, #0xff
    ac6c:	5400cd40 	b.eq	c614 <f0+0x2554>  // b.none
    ac70:	52800020 	mov	w0, #0x1                   	// #1
    ac74:	390002a0 	strb	w0, [x21]
    ac78:	910fe3e1 	add	x1, sp, #0x3f8
    ac7c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    ac80:	52800020 	mov	w0, #0x1                   	// #1
    ac84:	f901fff5 	str	x21, [sp, #1016]
    ac88:	f90203f7 	str	x23, [sp, #1024]
    ac8c:	97ffe982 	bl	5294 <fwp_data.part.0.constprop.0>
    ac90:	97ffeb70 	bl	5a50 <fwp_rc_fresh>
    ac94:	aa0003e2 	mov	x2, x0
    ac98:	911023e1 	add	x1, sp, #0x408
    ac9c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    aca0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    aca4:	52800020 	mov	w0, #0x1                   	// #1
    aca8:	f90207f7 	str	x23, [sp, #1032]
    acac:	f9020be2 	str	x2, [sp, #1040]
    acb0:	97ffe979 	bl	5294 <fwp_data.part.0.constprop.0>
    acb4:	97ffeb67 	bl	5a50 <fwp_rc_fresh>
    acb8:	aa0003e2 	mov	x2, x0
    acbc:	911063e1 	add	x1, sp, #0x418
    acc0:	52800020 	mov	w0, #0x1                   	// #1
    acc4:	f9020ff5 	str	x21, [sp, #1048]
    acc8:	f90213e2 	str	x2, [sp, #1056]
    accc:	97ffe972 	bl	5294 <fwp_data.part.0.constprop.0>
    acd0:	97ffeb60 	bl	5a50 <fwp_rc_fresh>
    acd4:	aa0003e2 	mov	x2, x0
    acd8:	9110a3e1 	add	x1, sp, #0x428
    acdc:	52800020 	mov	w0, #0x1                   	// #1
    ace0:	f90217f7 	str	x23, [sp, #1064]
    ace4:	f9021be2 	str	x2, [sp, #1072]
    ace8:	97ffe96b 	bl	5294 <fwp_data.part.0.constprop.0>
    acec:	97ffeb59 	bl	5a50 <fwp_rc_fresh>
    acf0:	aa0003e2 	mov	x2, x0
    acf4:	9110e3e1 	add	x1, sp, #0x438
    acf8:	52800020 	mov	w0, #0x1                   	// #1
    acfc:	f9021ff5 	str	x21, [sp, #1080]
    ad00:	f90223e2 	str	x2, [sp, #1088]
    ad04:	97ffe964 	bl	5294 <fwp_data.part.0.constprop.0>
    ad08:	97ffeb52 	bl	5a50 <fwp_rc_fresh>
    ad0c:	aa0003e2 	mov	x2, x0
    ad10:	911123e1 	add	x1, sp, #0x448
    ad14:	52800020 	mov	w0, #0x1                   	// #1
    ad18:	f90227f7 	str	x23, [sp, #1096]
    ad1c:	f9022be2 	str	x2, [sp, #1104]
    ad20:	97ffe95d 	bl	5294 <fwp_data.part.0.constprop.0>
    ad24:	97ffeb4b 	bl	5a50 <fwp_rc_fresh>
    ad28:	aa0003e2 	mov	x2, x0
    ad2c:	911163e1 	add	x1, sp, #0x458
    ad30:	52800020 	mov	w0, #0x1                   	// #1
    ad34:	f9022ff5 	str	x21, [sp, #1112]
    ad38:	f90233e2 	str	x2, [sp, #1120]
    ad3c:	97ffe956 	bl	5294 <fwp_data.part.0.constprop.0>
    ad40:	9118c283 	add	x3, x20, #0x630
    ad44:	aa0003f5 	mov	x21, x0
    ad48:	f949d861 	ldr	x1, [x3, #5040]
    ad4c:	f949ec60 	ldr	x0, [x3, #5080]
    ad50:	cb0102a1 	sub	x1, x21, x1
    ad54:	eb00403f 	cmp	x1, x0, lsl #16
    ad58:	54000322 	b.cs	adbc <f0+0xcfc>  // b.hs, b.nlast
    ad5c:	d350fc22 	lsr	x2, x1, #16
    ad60:	f949fc63 	ldr	x3, [x3, #5112]
    ad64:	8b020842 	add	x2, x2, x2, lsl #2
    ad68:	d37df042 	lsl	x2, x2, #3
    ad6c:	8b020060 	add	x0, x3, x2
    ad70:	f9401017 	ldr	x23, [x0, #32]
    ad74:	b4000257 	cbz	x23, adbc <f0+0xcfc>
    ad78:	38626862 	ldrb	w2, [x3, x2]
    ad7c:	7100085f 	cmp	w2, #0x2
    ad80:	5400bae0 	b.eq	c4dc <f0+0x241c>  // b.none
    ad84:	7100045f 	cmp	w2, #0x1
    ad88:	540001a1 	b.ne	adbc <f0+0xcfc>  // b.any
    ad8c:	29430002 	ldp	w2, w0, [x0, #24]
    ad90:	92403c21 	and	x1, x1, #0xffff
    ad94:	9b027c21 	mul	x1, x1, x2
    ad98:	d360fc21 	lsr	x1, x1, #32
    ad9c:	eb00003f 	cmp	x1, x0
    ada0:	540000e2 	b.cs	adbc <f0+0xcfc>  // b.hs, b.nlast
    ada4:	8b0102f7 	add	x23, x23, x1
    ada8:	394002e0 	ldrb	w0, [x23]
    adac:	7103fc1f 	cmp	w0, #0xff
    adb0:	5400c380 	b.eq	c620 <f0+0x2560>  // b.none
    adb4:	52800020 	mov	w0, #0x1                   	// #1
    adb8:	390002e0 	strb	w0, [x23]
    adbc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    adc0:	9111a3e1 	add	x1, sp, #0x468
    adc4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    adc8:	52800020 	mov	w0, #0x1                   	// #1
    adcc:	f90237e2 	str	x2, [sp, #1128]
    add0:	f9023bf5 	str	x21, [sp, #1136]
    add4:	97ffe930 	bl	5294 <fwp_data.part.0.constprop.0>
    add8:	9118c283 	add	x3, x20, #0x630
    addc:	aa0003f5 	mov	x21, x0
    ade0:	f949d861 	ldr	x1, [x3, #5040]
    ade4:	f949ec60 	ldr	x0, [x3, #5080]
    ade8:	cb0102a1 	sub	x1, x21, x1
    adec:	eb00403f 	cmp	x1, x0, lsl #16
    adf0:	54000322 	b.cs	ae54 <f0+0xd94>  // b.hs, b.nlast
    adf4:	d350fc22 	lsr	x2, x1, #16
    adf8:	f949fc63 	ldr	x3, [x3, #5112]
    adfc:	8b020842 	add	x2, x2, x2, lsl #2
    ae00:	d37df042 	lsl	x2, x2, #3
    ae04:	8b020060 	add	x0, x3, x2
    ae08:	f9401017 	ldr	x23, [x0, #32]
    ae0c:	b4000257 	cbz	x23, ae54 <f0+0xd94>
    ae10:	38626862 	ldrb	w2, [x3, x2]
    ae14:	7100085f 	cmp	w2, #0x2
    ae18:	5400b5c0 	b.eq	c4d0 <f0+0x2410>  // b.none
    ae1c:	7100045f 	cmp	w2, #0x1
    ae20:	540001a1 	b.ne	ae54 <f0+0xd94>  // b.any
    ae24:	29430002 	ldp	w2, w0, [x0, #24]
    ae28:	92403c21 	and	x1, x1, #0xffff
    ae2c:	9b027c21 	mul	x1, x1, x2
    ae30:	d360fc21 	lsr	x1, x1, #32
    ae34:	eb00003f 	cmp	x1, x0
    ae38:	540000e2 	b.cs	ae54 <f0+0xd94>  // b.hs, b.nlast
    ae3c:	8b0102f7 	add	x23, x23, x1
    ae40:	394002e0 	ldrb	w0, [x23]
    ae44:	7103fc1f 	cmp	w0, #0xff
    ae48:	5400bf20 	b.eq	c62c <f0+0x256c>  // b.none
    ae4c:	52800020 	mov	w0, #0x1                   	// #1
    ae50:	390002e0 	strb	w0, [x23]
    ae54:	9111e3e1 	add	x1, sp, #0x478
    ae58:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ae5c:	52800020 	mov	w0, #0x1                   	// #1
    ae60:	f9023fe2 	str	x2, [sp, #1144]
    ae64:	f90243f5 	str	x21, [sp, #1152]
    ae68:	97ffe90b 	bl	5294 <fwp_data.part.0.constprop.0>
    ae6c:	97ffeaf9 	bl	5a50 <fwp_rc_fresh>
    ae70:	aa0003e2 	mov	x2, x0
    ae74:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ae78:	911223e1 	add	x1, sp, #0x488
    ae7c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ae80:	52800020 	mov	w0, #0x1                   	// #1
    ae84:	f90247e3 	str	x3, [sp, #1160]
    ae88:	f9024be2 	str	x2, [sp, #1168]
    ae8c:	97ffe902 	bl	5294 <fwp_data.part.0.constprop.0>
    ae90:	9118c283 	add	x3, x20, #0x630
    ae94:	aa0003f5 	mov	x21, x0
    ae98:	f949d861 	ldr	x1, [x3, #5040]
    ae9c:	f949ec60 	ldr	x0, [x3, #5080]
    aea0:	cb0102a1 	sub	x1, x21, x1
    aea4:	eb00403f 	cmp	x1, x0, lsl #16
    aea8:	54000322 	b.cs	af0c <f0+0xe4c>  // b.hs, b.nlast
    aeac:	d350fc22 	lsr	x2, x1, #16
    aeb0:	f949fc63 	ldr	x3, [x3, #5112]
    aeb4:	8b020842 	add	x2, x2, x2, lsl #2
    aeb8:	d37df042 	lsl	x2, x2, #3
    aebc:	8b020060 	add	x0, x3, x2
    aec0:	f9401017 	ldr	x23, [x0, #32]
    aec4:	b4000257 	cbz	x23, af0c <f0+0xe4c>
    aec8:	38626862 	ldrb	w2, [x3, x2]
    aecc:	7100085f 	cmp	w2, #0x2
    aed0:	5400afa0 	b.eq	c4c4 <f0+0x2404>  // b.none
    aed4:	7100045f 	cmp	w2, #0x1
    aed8:	540001a1 	b.ne	af0c <f0+0xe4c>  // b.any
    aedc:	29430002 	ldp	w2, w0, [x0, #24]
    aee0:	92403c21 	and	x1, x1, #0xffff
    aee4:	9b027c21 	mul	x1, x1, x2
    aee8:	d360fc21 	lsr	x1, x1, #32
    aeec:	eb00003f 	cmp	x1, x0
    aef0:	540000e2 	b.cs	af0c <f0+0xe4c>  // b.hs, b.nlast
    aef4:	8b0102f7 	add	x23, x23, x1
    aef8:	394002e0 	ldrb	w0, [x23]
    aefc:	7103fc1f 	cmp	w0, #0xff
    af00:	5400b9c0 	b.eq	c638 <f0+0x2578>  // b.none
    af04:	52800020 	mov	w0, #0x1                   	// #1
    af08:	390002e0 	strb	w0, [x23]
    af0c:	911263e1 	add	x1, sp, #0x498
    af10:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    af14:	52800020 	mov	w0, #0x1                   	// #1
    af18:	f9024fe2 	str	x2, [sp, #1176]
    af1c:	f90253f5 	str	x21, [sp, #1184]
    af20:	97ffe8dd 	bl	5294 <fwp_data.part.0.constprop.0>
    af24:	97ffeacb 	bl	5a50 <fwp_rc_fresh>
    af28:	aa0003e2 	mov	x2, x0
    af2c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    af30:	9112a3e1 	add	x1, sp, #0x4a8
    af34:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    af38:	52800020 	mov	w0, #0x1                   	// #1
    af3c:	f90257e3 	str	x3, [sp, #1192]
    af40:	f9025be2 	str	x2, [sp, #1200]
    af44:	97ffe8d4 	bl	5294 <fwp_data.part.0.constprop.0>
    af48:	9118c283 	add	x3, x20, #0x630
    af4c:	aa0003f5 	mov	x21, x0
    af50:	f949d861 	ldr	x1, [x3, #5040]
    af54:	f949ec60 	ldr	x0, [x3, #5080]
    af58:	cb0102a1 	sub	x1, x21, x1
    af5c:	eb00403f 	cmp	x1, x0, lsl #16
    af60:	54000322 	b.cs	afc4 <f0+0xf04>  // b.hs, b.nlast
    af64:	d350fc22 	lsr	x2, x1, #16
    af68:	f949fc63 	ldr	x3, [x3, #5112]
    af6c:	8b020842 	add	x2, x2, x2, lsl #2
    af70:	d37df042 	lsl	x2, x2, #3
    af74:	8b020060 	add	x0, x3, x2
    af78:	f9401017 	ldr	x23, [x0, #32]
    af7c:	b4000257 	cbz	x23, afc4 <f0+0xf04>
    af80:	38626862 	ldrb	w2, [x3, x2]
    af84:	7100085f 	cmp	w2, #0x2
    af88:	5400a980 	b.eq	c4b8 <f0+0x23f8>  // b.none
    af8c:	7100045f 	cmp	w2, #0x1
    af90:	540001a1 	b.ne	afc4 <f0+0xf04>  // b.any
    af94:	29430002 	ldp	w2, w0, [x0, #24]
    af98:	92403c21 	and	x1, x1, #0xffff
    af9c:	9b027c21 	mul	x1, x1, x2
    afa0:	d360fc21 	lsr	x1, x1, #32
    afa4:	eb00003f 	cmp	x1, x0
    afa8:	540000e2 	b.cs	afc4 <f0+0xf04>  // b.hs, b.nlast
    afac:	8b0102f7 	add	x23, x23, x1
    afb0:	394002e0 	ldrb	w0, [x23]
    afb4:	7103fc1f 	cmp	w0, #0xff
    afb8:	5400b460 	b.eq	c644 <f0+0x2584>  // b.none
    afbc:	52800020 	mov	w0, #0x1                   	// #1
    afc0:	390002e0 	strb	w0, [x23]
    afc4:	9112e3e1 	add	x1, sp, #0x4b8
    afc8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    afcc:	52800020 	mov	w0, #0x1                   	// #1
    afd0:	f9025ff7 	str	x23, [sp, #1208]
    afd4:	f90263f5 	str	x21, [sp, #1216]
    afd8:	97ffe8af 	bl	5294 <fwp_data.part.0.constprop.0>
    afdc:	97ffea9d 	bl	5a50 <fwp_rc_fresh>
    afe0:	aa0003e2 	mov	x2, x0
    afe4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    afe8:	911323e1 	add	x1, sp, #0x4c8
    afec:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aff0:	52800020 	mov	w0, #0x1                   	// #1
    aff4:	f90267e3 	str	x3, [sp, #1224]
    aff8:	f9026be2 	str	x2, [sp, #1232]
    affc:	97ffe8a6 	bl	5294 <fwp_data.part.0.constprop.0>
    b000:	97ffea94 	bl	5a50 <fwp_rc_fresh>
    b004:	aa0003e2 	mov	x2, x0
    b008:	911363e1 	add	x1, sp, #0x4d8
    b00c:	52800020 	mov	w0, #0x1                   	// #1
    b010:	f9026ff7 	str	x23, [sp, #1240]
    b014:	f90273e2 	str	x2, [sp, #1248]
    b018:	97ffe89f 	bl	5294 <fwp_data.part.0.constprop.0>
    b01c:	9118c283 	add	x3, x20, #0x630
    b020:	aa0003f5 	mov	x21, x0
    b024:	f949d861 	ldr	x1, [x3, #5040]
    b028:	f949ec60 	ldr	x0, [x3, #5080]
    b02c:	cb0102a1 	sub	x1, x21, x1
    b030:	eb00403f 	cmp	x1, x0, lsl #16
    b034:	54000322 	b.cs	b098 <f0+0xfd8>  // b.hs, b.nlast
    b038:	d350fc22 	lsr	x2, x1, #16
    b03c:	f949fc63 	ldr	x3, [x3, #5112]
    b040:	8b020842 	add	x2, x2, x2, lsl #2
    b044:	d37df042 	lsl	x2, x2, #3
    b048:	8b020060 	add	x0, x3, x2
    b04c:	f9401017 	ldr	x23, [x0, #32]
    b050:	b4000257 	cbz	x23, b098 <f0+0xfd8>
    b054:	38626862 	ldrb	w2, [x3, x2]
    b058:	7100085f 	cmp	w2, #0x2
    b05c:	5400a280 	b.eq	c4ac <f0+0x23ec>  // b.none
    b060:	7100045f 	cmp	w2, #0x1
    b064:	540001a1 	b.ne	b098 <f0+0xfd8>  // b.any
    b068:	29430002 	ldp	w2, w0, [x0, #24]
    b06c:	92403c21 	and	x1, x1, #0xffff
    b070:	9b027c21 	mul	x1, x1, x2
    b074:	d360fc21 	lsr	x1, x1, #32
    b078:	eb00003f 	cmp	x1, x0
    b07c:	540000e2 	b.cs	b098 <f0+0xfd8>  // b.hs, b.nlast
    b080:	8b0102f7 	add	x23, x23, x1
    b084:	394002e0 	ldrb	w0, [x23]
    b088:	7103fc1f 	cmp	w0, #0xff
    b08c:	5400ae20 	b.eq	c650 <f0+0x2590>  // b.none
    b090:	52800020 	mov	w0, #0x1                   	// #1
    b094:	390002e0 	strb	w0, [x23]
    b098:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b09c:	9113a3e1 	add	x1, sp, #0x4e8
    b0a0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b0a4:	52800020 	mov	w0, #0x1                   	// #1
    b0a8:	f90277e2 	str	x2, [sp, #1256]
    b0ac:	f9027bf5 	str	x21, [sp, #1264]
    b0b0:	97ffe879 	bl	5294 <fwp_data.part.0.constprop.0>
    b0b4:	9118c283 	add	x3, x20, #0x630
    b0b8:	aa0003f5 	mov	x21, x0
    b0bc:	f949d861 	ldr	x1, [x3, #5040]
    b0c0:	f949ec60 	ldr	x0, [x3, #5080]
    b0c4:	cb0102a1 	sub	x1, x21, x1
    b0c8:	eb00403f 	cmp	x1, x0, lsl #16
    b0cc:	54000322 	b.cs	b130 <f0+0x1070>  // b.hs, b.nlast
    b0d0:	d350fc22 	lsr	x2, x1, #16
    b0d4:	f949fc63 	ldr	x3, [x3, #5112]
    b0d8:	8b020842 	add	x2, x2, x2, lsl #2
    b0dc:	d37df042 	lsl	x2, x2, #3
    b0e0:	8b020060 	add	x0, x3, x2
    b0e4:	f9401017 	ldr	x23, [x0, #32]
    b0e8:	b4000257 	cbz	x23, b130 <f0+0x1070>
    b0ec:	38626862 	ldrb	w2, [x3, x2]
    b0f0:	7100085f 	cmp	w2, #0x2
    b0f4:	54009d60 	b.eq	c4a0 <f0+0x23e0>  // b.none
    b0f8:	7100045f 	cmp	w2, #0x1
    b0fc:	540001a1 	b.ne	b130 <f0+0x1070>  // b.any
    b100:	29430002 	ldp	w2, w0, [x0, #24]
    b104:	92403c21 	and	x1, x1, #0xffff
    b108:	9b027c21 	mul	x1, x1, x2
    b10c:	d360fc21 	lsr	x1, x1, #32
    b110:	eb00003f 	cmp	x1, x0
    b114:	540000e2 	b.cs	b130 <f0+0x1070>  // b.hs, b.nlast
    b118:	8b0102f7 	add	x23, x23, x1
    b11c:	394002e0 	ldrb	w0, [x23]
    b120:	7103fc1f 	cmp	w0, #0xff
    b124:	5400a9c0 	b.eq	c65c <f0+0x259c>  // b.none
    b128:	52800020 	mov	w0, #0x1                   	// #1
    b12c:	390002e0 	strb	w0, [x23]
    b130:	9113e3e1 	add	x1, sp, #0x4f8
    b134:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b138:	52800020 	mov	w0, #0x1                   	// #1
    b13c:	f9027fe2 	str	x2, [sp, #1272]
    b140:	f90283f5 	str	x21, [sp, #1280]
    b144:	97ffe854 	bl	5294 <fwp_data.part.0.constprop.0>
    b148:	97ffea42 	bl	5a50 <fwp_rc_fresh>
    b14c:	aa0003e2 	mov	x2, x0
    b150:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b154:	911423e1 	add	x1, sp, #0x508
    b158:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b15c:	52800020 	mov	w0, #0x1                   	// #1
    b160:	f90287e3 	str	x3, [sp, #1288]
    b164:	f9028be2 	str	x2, [sp, #1296]
    b168:	97ffe84b 	bl	5294 <fwp_data.part.0.constprop.0>
    b16c:	9118c283 	add	x3, x20, #0x630
    b170:	aa0003f5 	mov	x21, x0
    b174:	f949d861 	ldr	x1, [x3, #5040]
    b178:	f949ec60 	ldr	x0, [x3, #5080]
    b17c:	cb0102a1 	sub	x1, x21, x1
    b180:	eb00403f 	cmp	x1, x0, lsl #16
    b184:	54000322 	b.cs	b1e8 <f0+0x1128>  // b.hs, b.nlast
    b188:	d350fc22 	lsr	x2, x1, #16
    b18c:	f949fc63 	ldr	x3, [x3, #5112]
    b190:	8b020842 	add	x2, x2, x2, lsl #2
    b194:	d37df042 	lsl	x2, x2, #3
    b198:	8b020060 	add	x0, x3, x2
    b19c:	f9401017 	ldr	x23, [x0, #32]
    b1a0:	b4000257 	cbz	x23, b1e8 <f0+0x1128>
    b1a4:	38626862 	ldrb	w2, [x3, x2]
    b1a8:	7100085f 	cmp	w2, #0x2
    b1ac:	54009740 	b.eq	c494 <f0+0x23d4>  // b.none
    b1b0:	7100045f 	cmp	w2, #0x1
    b1b4:	540001a1 	b.ne	b1e8 <f0+0x1128>  // b.any
    b1b8:	29430002 	ldp	w2, w0, [x0, #24]
    b1bc:	92403c21 	and	x1, x1, #0xffff
    b1c0:	9b027c21 	mul	x1, x1, x2
    b1c4:	d360fc21 	lsr	x1, x1, #32
    b1c8:	eb00003f 	cmp	x1, x0
    b1cc:	540000e2 	b.cs	b1e8 <f0+0x1128>  // b.hs, b.nlast
    b1d0:	8b0102f7 	add	x23, x23, x1
    b1d4:	394002e0 	ldrb	w0, [x23]
    b1d8:	7103fc1f 	cmp	w0, #0xff
    b1dc:	5400a460 	b.eq	c668 <f0+0x25a8>  // b.none
    b1e0:	52800020 	mov	w0, #0x1                   	// #1
    b1e4:	390002e0 	strb	w0, [x23]
    b1e8:	911463e1 	add	x1, sp, #0x518
    b1ec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b1f0:	52800020 	mov	w0, #0x1                   	// #1
    b1f4:	f9028fe2 	str	x2, [sp, #1304]
    b1f8:	f90293f5 	str	x21, [sp, #1312]
    b1fc:	97ffe826 	bl	5294 <fwp_data.part.0.constprop.0>
    b200:	97ffea14 	bl	5a50 <fwp_rc_fresh>
    b204:	aa0003e2 	mov	x2, x0
    b208:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b20c:	9114a3e1 	add	x1, sp, #0x528
    b210:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b214:	52800020 	mov	w0, #0x1                   	// #1
    b218:	f90297e3 	str	x3, [sp, #1320]
    b21c:	f9029be2 	str	x2, [sp, #1328]
    b220:	97ffe81d 	bl	5294 <fwp_data.part.0.constprop.0>
    b224:	9118c283 	add	x3, x20, #0x630
    b228:	aa0003f5 	mov	x21, x0
    b22c:	f949d861 	ldr	x1, [x3, #5040]
    b230:	f949ec60 	ldr	x0, [x3, #5080]
    b234:	cb0102a1 	sub	x1, x21, x1
    b238:	eb00403f 	cmp	x1, x0, lsl #16
    b23c:	54000322 	b.cs	b2a0 <f0+0x11e0>  // b.hs, b.nlast
    b240:	d350fc22 	lsr	x2, x1, #16
    b244:	f949fc63 	ldr	x3, [x3, #5112]
    b248:	8b020842 	add	x2, x2, x2, lsl #2
    b24c:	d37df042 	lsl	x2, x2, #3
    b250:	8b020060 	add	x0, x3, x2
    b254:	f9401017 	ldr	x23, [x0, #32]
    b258:	b4000257 	cbz	x23, b2a0 <f0+0x11e0>
    b25c:	38626862 	ldrb	w2, [x3, x2]
    b260:	7100085f 	cmp	w2, #0x2
    b264:	54008e80 	b.eq	c434 <f0+0x2374>  // b.none
    b268:	7100045f 	cmp	w2, #0x1
    b26c:	540001a1 	b.ne	b2a0 <f0+0x11e0>  // b.any
    b270:	29430002 	ldp	w2, w0, [x0, #24]
    b274:	92403c21 	and	x1, x1, #0xffff
    b278:	9b027c21 	mul	x1, x1, x2
    b27c:	d360fc21 	lsr	x1, x1, #32
    b280:	eb00003f 	cmp	x1, x0
    b284:	540000e2 	b.cs	b2a0 <f0+0x11e0>  // b.hs, b.nlast
    b288:	8b0102f7 	add	x23, x23, x1
    b28c:	394002e0 	ldrb	w0, [x23]
    b290:	7103fc1f 	cmp	w0, #0xff
    b294:	54009f00 	b.eq	c674 <f0+0x25b4>  // b.none
    b298:	52800020 	mov	w0, #0x1                   	// #1
    b29c:	390002e0 	strb	w0, [x23]
    b2a0:	9114e3e1 	add	x1, sp, #0x538
    b2a4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b2a8:	52800020 	mov	w0, #0x1                   	// #1
    b2ac:	f9029ff7 	str	x23, [sp, #1336]
    b2b0:	f902a3f5 	str	x21, [sp, #1344]
    b2b4:	97ffe7f8 	bl	5294 <fwp_data.part.0.constprop.0>
    b2b8:	97ffe9e6 	bl	5a50 <fwp_rc_fresh>
    b2bc:	aa0003e2 	mov	x2, x0
    b2c0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b2c4:	911523e1 	add	x1, sp, #0x548
    b2c8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b2cc:	52800020 	mov	w0, #0x1                   	// #1
    b2d0:	f902a7e3 	str	x3, [sp, #1352]
    b2d4:	f902abe2 	str	x2, [sp, #1360]
    b2d8:	97ffe7ef 	bl	5294 <fwp_data.part.0.constprop.0>
    b2dc:	97ffe9dd 	bl	5a50 <fwp_rc_fresh>
    b2e0:	aa0003e2 	mov	x2, x0
    b2e4:	911563e1 	add	x1, sp, #0x558
    b2e8:	52800020 	mov	w0, #0x1                   	// #1
    b2ec:	f902aff7 	str	x23, [sp, #1368]
    b2f0:	f902b3e2 	str	x2, [sp, #1376]
    b2f4:	97ffe7e8 	bl	5294 <fwp_data.part.0.constprop.0>
    b2f8:	9118c283 	add	x3, x20, #0x630
    b2fc:	aa0003f5 	mov	x21, x0
    b300:	f949d861 	ldr	x1, [x3, #5040]
    b304:	f949ec60 	ldr	x0, [x3, #5080]
    b308:	cb0102a1 	sub	x1, x21, x1
    b30c:	eb00403f 	cmp	x1, x0, lsl #16
    b310:	54000322 	b.cs	b374 <f0+0x12b4>  // b.hs, b.nlast
    b314:	d350fc22 	lsr	x2, x1, #16
    b318:	f949fc63 	ldr	x3, [x3, #5112]
    b31c:	8b020842 	add	x2, x2, x2, lsl #2
    b320:	d37df042 	lsl	x2, x2, #3
    b324:	8b020060 	add	x0, x3, x2
    b328:	f9401017 	ldr	x23, [x0, #32]
    b32c:	b4000257 	cbz	x23, b374 <f0+0x12b4>
    b330:	38626862 	ldrb	w2, [x3, x2]
    b334:	7100085f 	cmp	w2, #0x2
    b338:	54008780 	b.eq	c428 <f0+0x2368>  // b.none
    b33c:	7100045f 	cmp	w2, #0x1
    b340:	540001a1 	b.ne	b374 <f0+0x12b4>  // b.any
    b344:	29430002 	ldp	w2, w0, [x0, #24]
    b348:	92403c21 	and	x1, x1, #0xffff
    b34c:	9b027c21 	mul	x1, x1, x2
    b350:	d360fc21 	lsr	x1, x1, #32
    b354:	eb00003f 	cmp	x1, x0
    b358:	540000e2 	b.cs	b374 <f0+0x12b4>  // b.hs, b.nlast
    b35c:	8b0102f7 	add	x23, x23, x1
    b360:	394002e0 	ldrb	w0, [x23]
    b364:	7103fc1f 	cmp	w0, #0xff
    b368:	540098c0 	b.eq	c680 <f0+0x25c0>  // b.none
    b36c:	52800020 	mov	w0, #0x1                   	// #1
    b370:	390002e0 	strb	w0, [x23]
    b374:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b378:	9115a3e1 	add	x1, sp, #0x568
    b37c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b380:	52800020 	mov	w0, #0x1                   	// #1
    b384:	f902b7e2 	str	x2, [sp, #1384]
    b388:	f902bbf5 	str	x21, [sp, #1392]
    b38c:	97ffe7c2 	bl	5294 <fwp_data.part.0.constprop.0>
    b390:	9118c283 	add	x3, x20, #0x630
    b394:	aa0003f5 	mov	x21, x0
    b398:	f949d861 	ldr	x1, [x3, #5040]
    b39c:	f949ec60 	ldr	x0, [x3, #5080]
    b3a0:	cb0102a1 	sub	x1, x21, x1
    b3a4:	eb00403f 	cmp	x1, x0, lsl #16
    b3a8:	54000322 	b.cs	b40c <f0+0x134c>  // b.hs, b.nlast
    b3ac:	d350fc22 	lsr	x2, x1, #16
    b3b0:	f949fc63 	ldr	x3, [x3, #5112]
    b3b4:	8b020842 	add	x2, x2, x2, lsl #2
    b3b8:	d37df042 	lsl	x2, x2, #3
    b3bc:	8b020060 	add	x0, x3, x2
    b3c0:	f9401017 	ldr	x23, [x0, #32]
    b3c4:	b4000257 	cbz	x23, b40c <f0+0x134c>
    b3c8:	38626862 	ldrb	w2, [x3, x2]
    b3cc:	7100085f 	cmp	w2, #0x2
    b3d0:	54008260 	b.eq	c41c <f0+0x235c>  // b.none
    b3d4:	7100045f 	cmp	w2, #0x1
    b3d8:	540001a1 	b.ne	b40c <f0+0x134c>  // b.any
    b3dc:	29430002 	ldp	w2, w0, [x0, #24]
    b3e0:	92403c21 	and	x1, x1, #0xffff
    b3e4:	9b027c21 	mul	x1, x1, x2
    b3e8:	d360fc21 	lsr	x1, x1, #32
    b3ec:	eb00003f 	cmp	x1, x0
    b3f0:	540000e2 	b.cs	b40c <f0+0x134c>  // b.hs, b.nlast
    b3f4:	8b0102f7 	add	x23, x23, x1
    b3f8:	394002e0 	ldrb	w0, [x23]
    b3fc:	7103fc1f 	cmp	w0, #0xff
    b400:	54009460 	b.eq	c68c <f0+0x25cc>  // b.none
    b404:	52800020 	mov	w0, #0x1                   	// #1
    b408:	390002e0 	strb	w0, [x23]
    b40c:	9115e3e1 	add	x1, sp, #0x578
    b410:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b414:	52800020 	mov	w0, #0x1                   	// #1
    b418:	f902bfe2 	str	x2, [sp, #1400]
    b41c:	f902c3f5 	str	x21, [sp, #1408]
    b420:	97ffe79d 	bl	5294 <fwp_data.part.0.constprop.0>
    b424:	97ffe98b 	bl	5a50 <fwp_rc_fresh>
    b428:	aa0003e2 	mov	x2, x0
    b42c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b430:	911623e1 	add	x1, sp, #0x588
    b434:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b438:	52800020 	mov	w0, #0x1                   	// #1
    b43c:	f902c7e3 	str	x3, [sp, #1416]
    b440:	f902cbe2 	str	x2, [sp, #1424]
    b444:	97ffe794 	bl	5294 <fwp_data.part.0.constprop.0>
    b448:	9118c283 	add	x3, x20, #0x630
    b44c:	aa0003f5 	mov	x21, x0
    b450:	f949d861 	ldr	x1, [x3, #5040]
    b454:	f949ec60 	ldr	x0, [x3, #5080]
    b458:	cb0102a1 	sub	x1, x21, x1
    b45c:	eb00403f 	cmp	x1, x0, lsl #16
    b460:	54000322 	b.cs	b4c4 <f0+0x1404>  // b.hs, b.nlast
    b464:	d350fc22 	lsr	x2, x1, #16
    b468:	f949fc63 	ldr	x3, [x3, #5112]
    b46c:	8b020842 	add	x2, x2, x2, lsl #2
    b470:	d37df042 	lsl	x2, x2, #3
    b474:	8b020060 	add	x0, x3, x2
    b478:	f9401017 	ldr	x23, [x0, #32]
    b47c:	b4000257 	cbz	x23, b4c4 <f0+0x1404>
    b480:	38626862 	ldrb	w2, [x3, x2]
    b484:	7100085f 	cmp	w2, #0x2
    b488:	54007c40 	b.eq	c410 <f0+0x2350>  // b.none
    b48c:	7100045f 	cmp	w2, #0x1
    b490:	540001a1 	b.ne	b4c4 <f0+0x1404>  // b.any
    b494:	29430002 	ldp	w2, w0, [x0, #24]
    b498:	92403c21 	and	x1, x1, #0xffff
    b49c:	9b027c21 	mul	x1, x1, x2
    b4a0:	d360fc21 	lsr	x1, x1, #32
    b4a4:	eb00003f 	cmp	x1, x0
    b4a8:	540000e2 	b.cs	b4c4 <f0+0x1404>  // b.hs, b.nlast
    b4ac:	8b0102f7 	add	x23, x23, x1
    b4b0:	394002e0 	ldrb	w0, [x23]
    b4b4:	7103fc1f 	cmp	w0, #0xff
    b4b8:	54008f00 	b.eq	c698 <f0+0x25d8>  // b.none
    b4bc:	52800020 	mov	w0, #0x1                   	// #1
    b4c0:	390002e0 	strb	w0, [x23]
    b4c4:	911663e1 	add	x1, sp, #0x598
    b4c8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b4cc:	52800020 	mov	w0, #0x1                   	// #1
    b4d0:	f902cfe2 	str	x2, [sp, #1432]
    b4d4:	f902d3f5 	str	x21, [sp, #1440]
    b4d8:	97ffe76f 	bl	5294 <fwp_data.part.0.constprop.0>
    b4dc:	97ffe95d 	bl	5a50 <fwp_rc_fresh>
    b4e0:	aa0003e2 	mov	x2, x0
    b4e4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b4e8:	9116a3e1 	add	x1, sp, #0x5a8
    b4ec:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b4f0:	52800020 	mov	w0, #0x1                   	// #1
    b4f4:	f902d7e3 	str	x3, [sp, #1448]
    b4f8:	f902dbe2 	str	x2, [sp, #1456]
    b4fc:	97ffe766 	bl	5294 <fwp_data.part.0.constprop.0>
    b500:	9118c283 	add	x3, x20, #0x630
    b504:	aa0003f5 	mov	x21, x0
    b508:	f949d861 	ldr	x1, [x3, #5040]
    b50c:	f949ec60 	ldr	x0, [x3, #5080]
    b510:	cb0102a1 	sub	x1, x21, x1
    b514:	eb00403f 	cmp	x1, x0, lsl #16
    b518:	54000322 	b.cs	b57c <f0+0x14bc>  // b.hs, b.nlast
    b51c:	d350fc22 	lsr	x2, x1, #16
    b520:	f949fc63 	ldr	x3, [x3, #5112]
    b524:	8b020842 	add	x2, x2, x2, lsl #2
    b528:	d37df042 	lsl	x2, x2, #3
    b52c:	8b020060 	add	x0, x3, x2
    b530:	f9401017 	ldr	x23, [x0, #32]
    b534:	b4000257 	cbz	x23, b57c <f0+0x14bc>
    b538:	38626862 	ldrb	w2, [x3, x2]
    b53c:	7100085f 	cmp	w2, #0x2
    b540:	54007620 	b.eq	c404 <f0+0x2344>  // b.none
    b544:	7100045f 	cmp	w2, #0x1
    b548:	540001a1 	b.ne	b57c <f0+0x14bc>  // b.any
    b54c:	29430002 	ldp	w2, w0, [x0, #24]
    b550:	92403c21 	and	x1, x1, #0xffff
    b554:	9b027c21 	mul	x1, x1, x2
    b558:	d360fc21 	lsr	x1, x1, #32
    b55c:	eb00003f 	cmp	x1, x0
    b560:	540000e2 	b.cs	b57c <f0+0x14bc>  // b.hs, b.nlast
    b564:	8b0102f7 	add	x23, x23, x1
    b568:	394002e0 	ldrb	w0, [x23]
    b56c:	7103fc1f 	cmp	w0, #0xff
    b570:	540089a0 	b.eq	c6a4 <f0+0x25e4>  // b.none
    b574:	52800020 	mov	w0, #0x1                   	// #1
    b578:	390002e0 	strb	w0, [x23]
    b57c:	9116e3e1 	add	x1, sp, #0x5b8
    b580:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b584:	52800020 	mov	w0, #0x1                   	// #1
    b588:	f902dff7 	str	x23, [sp, #1464]
    b58c:	f902e3f5 	str	x21, [sp, #1472]
    b590:	97ffe741 	bl	5294 <fwp_data.part.0.constprop.0>
    b594:	97ffe92f 	bl	5a50 <fwp_rc_fresh>
    b598:	aa0003e2 	mov	x2, x0
    b59c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b5a0:	911723e1 	add	x1, sp, #0x5c8
    b5a4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b5a8:	52800020 	mov	w0, #0x1                   	// #1
    b5ac:	f902e7e3 	str	x3, [sp, #1480]
    b5b0:	f902ebe2 	str	x2, [sp, #1488]
    b5b4:	97ffe738 	bl	5294 <fwp_data.part.0.constprop.0>
    b5b8:	97ffe926 	bl	5a50 <fwp_rc_fresh>
    b5bc:	aa0003e2 	mov	x2, x0
    b5c0:	911763e1 	add	x1, sp, #0x5d8
    b5c4:	52800020 	mov	w0, #0x1                   	// #1
    b5c8:	f902eff7 	str	x23, [sp, #1496]
    b5cc:	f902f3e2 	str	x2, [sp, #1504]
    b5d0:	97ffe731 	bl	5294 <fwp_data.part.0.constprop.0>
    b5d4:	9118c283 	add	x3, x20, #0x630
    b5d8:	aa0003f5 	mov	x21, x0
    b5dc:	f949d861 	ldr	x1, [x3, #5040]
    b5e0:	f949ec60 	ldr	x0, [x3, #5080]
    b5e4:	cb0102a1 	sub	x1, x21, x1
    b5e8:	eb00403f 	cmp	x1, x0, lsl #16
    b5ec:	54000322 	b.cs	b650 <f0+0x1590>  // b.hs, b.nlast
    b5f0:	d350fc22 	lsr	x2, x1, #16
    b5f4:	f949fc63 	ldr	x3, [x3, #5112]
    b5f8:	8b020842 	add	x2, x2, x2, lsl #2
    b5fc:	d37df042 	lsl	x2, x2, #3
    b600:	8b020060 	add	x0, x3, x2
    b604:	f9401017 	ldr	x23, [x0, #32]
    b608:	b4000257 	cbz	x23, b650 <f0+0x1590>
    b60c:	38626862 	ldrb	w2, [x3, x2]
    b610:	7100085f 	cmp	w2, #0x2
    b614:	54006f20 	b.eq	c3f8 <f0+0x2338>  // b.none
    b618:	7100045f 	cmp	w2, #0x1
    b61c:	540001a1 	b.ne	b650 <f0+0x1590>  // b.any
    b620:	29430002 	ldp	w2, w0, [x0, #24]
    b624:	92403c21 	and	x1, x1, #0xffff
    b628:	9b027c21 	mul	x1, x1, x2
    b62c:	d360fc21 	lsr	x1, x1, #32
    b630:	eb00003f 	cmp	x1, x0
    b634:	540000e2 	b.cs	b650 <f0+0x1590>  // b.hs, b.nlast
    b638:	8b0102f7 	add	x23, x23, x1
    b63c:	394002e0 	ldrb	w0, [x23]
    b640:	7103fc1f 	cmp	w0, #0xff
    b644:	54008360 	b.eq	c6b0 <f0+0x25f0>  // b.none
    b648:	52800020 	mov	w0, #0x1                   	// #1
    b64c:	390002e0 	strb	w0, [x23]
    b650:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b654:	9117a3e1 	add	x1, sp, #0x5e8
    b658:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b65c:	52800020 	mov	w0, #0x1                   	// #1
    b660:	f902f7e2 	str	x2, [sp, #1512]
    b664:	f902fbf5 	str	x21, [sp, #1520]
    b668:	97ffe70b 	bl	5294 <fwp_data.part.0.constprop.0>
    b66c:	9118c283 	add	x3, x20, #0x630
    b670:	aa0003f5 	mov	x21, x0
    b674:	f949d861 	ldr	x1, [x3, #5040]
    b678:	f949ec60 	ldr	x0, [x3, #5080]
    b67c:	cb0102a1 	sub	x1, x21, x1
    b680:	eb00403f 	cmp	x1, x0, lsl #16
    b684:	54000322 	b.cs	b6e8 <f0+0x1628>  // b.hs, b.nlast
    b688:	d350fc22 	lsr	x2, x1, #16
    b68c:	f949fc63 	ldr	x3, [x3, #5112]
    b690:	8b020842 	add	x2, x2, x2, lsl #2
    b694:	d37df042 	lsl	x2, x2, #3
    b698:	8b020060 	add	x0, x3, x2
    b69c:	f9401017 	ldr	x23, [x0, #32]
    b6a0:	b4000257 	cbz	x23, b6e8 <f0+0x1628>
    b6a4:	38626862 	ldrb	w2, [x3, x2]
    b6a8:	7100085f 	cmp	w2, #0x2
    b6ac:	54006a00 	b.eq	c3ec <f0+0x232c>  // b.none
    b6b0:	7100045f 	cmp	w2, #0x1
    b6b4:	540001a1 	b.ne	b6e8 <f0+0x1628>  // b.any
    b6b8:	29430002 	ldp	w2, w0, [x0, #24]
    b6bc:	92403c21 	and	x1, x1, #0xffff
    b6c0:	9b027c21 	mul	x1, x1, x2
    b6c4:	d360fc21 	lsr	x1, x1, #32
    b6c8:	eb00003f 	cmp	x1, x0
    b6cc:	540000e2 	b.cs	b6e8 <f0+0x1628>  // b.hs, b.nlast
    b6d0:	8b0102f7 	add	x23, x23, x1
    b6d4:	394002e0 	ldrb	w0, [x23]
    b6d8:	7103fc1f 	cmp	w0, #0xff
    b6dc:	54007f00 	b.eq	c6bc <f0+0x25fc>  // b.none
    b6e0:	52800020 	mov	w0, #0x1                   	// #1
    b6e4:	390002e0 	strb	w0, [x23]
    b6e8:	9117e3e1 	add	x1, sp, #0x5f8
    b6ec:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b6f0:	52800020 	mov	w0, #0x1                   	// #1
    b6f4:	f902ffe2 	str	x2, [sp, #1528]
    b6f8:	f90303f5 	str	x21, [sp, #1536]
    b6fc:	97ffe6e6 	bl	5294 <fwp_data.part.0.constprop.0>
    b700:	97ffe8d4 	bl	5a50 <fwp_rc_fresh>
    b704:	aa0003e2 	mov	x2, x0
    b708:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b70c:	911823e1 	add	x1, sp, #0x608
    b710:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b714:	52800020 	mov	w0, #0x1                   	// #1
    b718:	f90307e3 	str	x3, [sp, #1544]
    b71c:	f9030be2 	str	x2, [sp, #1552]
    b720:	97ffe6dd 	bl	5294 <fwp_data.part.0.constprop.0>
    b724:	9118c283 	add	x3, x20, #0x630
    b728:	aa0003f5 	mov	x21, x0
    b72c:	f949d861 	ldr	x1, [x3, #5040]
    b730:	f949ec60 	ldr	x0, [x3, #5080]
    b734:	cb0102a1 	sub	x1, x21, x1
    b738:	eb00403f 	cmp	x1, x0, lsl #16
    b73c:	54000322 	b.cs	b7a0 <f0+0x16e0>  // b.hs, b.nlast
    b740:	d350fc22 	lsr	x2, x1, #16
    b744:	f949fc63 	ldr	x3, [x3, #5112]
    b748:	8b020842 	add	x2, x2, x2, lsl #2
    b74c:	d37df042 	lsl	x2, x2, #3
    b750:	8b020060 	add	x0, x3, x2
    b754:	f9401017 	ldr	x23, [x0, #32]
    b758:	b4000257 	cbz	x23, b7a0 <f0+0x16e0>
    b75c:	38626862 	ldrb	w2, [x3, x2]
    b760:	7100085f 	cmp	w2, #0x2
    b764:	540063e0 	b.eq	c3e0 <f0+0x2320>  // b.none
    b768:	7100045f 	cmp	w2, #0x1
    b76c:	540001a1 	b.ne	b7a0 <f0+0x16e0>  // b.any
    b770:	29430002 	ldp	w2, w0, [x0, #24]
    b774:	92403c21 	and	x1, x1, #0xffff
    b778:	9b027c21 	mul	x1, x1, x2
    b77c:	d360fc21 	lsr	x1, x1, #32
    b780:	eb00003f 	cmp	x1, x0
    b784:	540000e2 	b.cs	b7a0 <f0+0x16e0>  // b.hs, b.nlast
    b788:	8b0102f7 	add	x23, x23, x1
    b78c:	394002e0 	ldrb	w0, [x23]
    b790:	7103fc1f 	cmp	w0, #0xff
    b794:	540079a0 	b.eq	c6c8 <f0+0x2608>  // b.none
    b798:	52800020 	mov	w0, #0x1                   	// #1
    b79c:	390002e0 	strb	w0, [x23]
    b7a0:	911863e1 	add	x1, sp, #0x618
    b7a4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b7a8:	52800020 	mov	w0, #0x1                   	// #1
    b7ac:	f9030fe2 	str	x2, [sp, #1560]
    b7b0:	f90313f5 	str	x21, [sp, #1568]
    b7b4:	97ffe6b8 	bl	5294 <fwp_data.part.0.constprop.0>
    b7b8:	97ffe8a6 	bl	5a50 <fwp_rc_fresh>
    b7bc:	aa0003e2 	mov	x2, x0
    b7c0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b7c4:	9118a3e1 	add	x1, sp, #0x628
    b7c8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b7cc:	52800020 	mov	w0, #0x1                   	// #1
    b7d0:	f90317e3 	str	x3, [sp, #1576]
    b7d4:	f9031be2 	str	x2, [sp, #1584]
    b7d8:	97ffe6af 	bl	5294 <fwp_data.part.0.constprop.0>
    b7dc:	9118c283 	add	x3, x20, #0x630
    b7e0:	aa0003f5 	mov	x21, x0
    b7e4:	f949d861 	ldr	x1, [x3, #5040]
    b7e8:	f949ec60 	ldr	x0, [x3, #5080]
    b7ec:	cb0102a1 	sub	x1, x21, x1
    b7f0:	eb00403f 	cmp	x1, x0, lsl #16
    b7f4:	54000322 	b.cs	b858 <f0+0x1798>  // b.hs, b.nlast
    b7f8:	d350fc22 	lsr	x2, x1, #16
    b7fc:	f949fc63 	ldr	x3, [x3, #5112]
    b800:	8b020842 	add	x2, x2, x2, lsl #2
    b804:	d37df042 	lsl	x2, x2, #3
    b808:	8b020060 	add	x0, x3, x2
    b80c:	f9401017 	ldr	x23, [x0, #32]
    b810:	b4000257 	cbz	x23, b858 <f0+0x1798>
    b814:	38626862 	ldrb	w2, [x3, x2]
    b818:	7100085f 	cmp	w2, #0x2
    b81c:	54006c60 	b.eq	c5a8 <f0+0x24e8>  // b.none
    b820:	7100045f 	cmp	w2, #0x1
    b824:	540001a1 	b.ne	b858 <f0+0x1798>  // b.any
    b828:	29430002 	ldp	w2, w0, [x0, #24]
    b82c:	92403c21 	and	x1, x1, #0xffff
    b830:	9b027c21 	mul	x1, x1, x2
    b834:	d360fc21 	lsr	x1, x1, #32
    b838:	eb00003f 	cmp	x1, x0
    b83c:	540000e2 	b.cs	b858 <f0+0x1798>  // b.hs, b.nlast
    b840:	8b0102f7 	add	x23, x23, x1
    b844:	394002e0 	ldrb	w0, [x23]
    b848:	7103fc1f 	cmp	w0, #0xff
    b84c:	54007440 	b.eq	c6d4 <f0+0x2614>  // b.none
    b850:	52800020 	mov	w0, #0x1                   	// #1
    b854:	390002e0 	strb	w0, [x23]
    b858:	9118e3e1 	add	x1, sp, #0x638
    b85c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b860:	52800020 	mov	w0, #0x1                   	// #1
    b864:	f9031fe2 	str	x2, [sp, #1592]
    b868:	f90323f5 	str	x21, [sp, #1600]
    b86c:	97ffe68a 	bl	5294 <fwp_data.part.0.constprop.0>
    b870:	97ffe878 	bl	5a50 <fwp_rc_fresh>
    b874:	aa0003e2 	mov	x2, x0
    b878:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b87c:	911923e1 	add	x1, sp, #0x648
    b880:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b884:	52800020 	mov	w0, #0x1                   	// #1
    b888:	f90327e3 	str	x3, [sp, #1608]
    b88c:	f9032be2 	str	x2, [sp, #1616]
    b890:	97ffe681 	bl	5294 <fwp_data.part.0.constprop.0>
    b894:	9118c283 	add	x3, x20, #0x630
    b898:	aa0003f5 	mov	x21, x0
    b89c:	f949d861 	ldr	x1, [x3, #5040]
    b8a0:	f949ec60 	ldr	x0, [x3, #5080]
    b8a4:	cb0102a1 	sub	x1, x21, x1
    b8a8:	eb00403f 	cmp	x1, x0, lsl #16
    b8ac:	54000322 	b.cs	b910 <f0+0x1850>  // b.hs, b.nlast
    b8b0:	d350fc22 	lsr	x2, x1, #16
    b8b4:	f949fc63 	ldr	x3, [x3, #5112]
    b8b8:	8b020842 	add	x2, x2, x2, lsl #2
    b8bc:	d37df042 	lsl	x2, x2, #3
    b8c0:	8b020060 	add	x0, x3, x2
    b8c4:	f9401017 	ldr	x23, [x0, #32]
    b8c8:	b4000257 	cbz	x23, b910 <f0+0x1850>
    b8cc:	38626862 	ldrb	w2, [x3, x2]
    b8d0:	7100085f 	cmp	w2, #0x2
    b8d4:	54006640 	b.eq	c59c <f0+0x24dc>  // b.none
    b8d8:	7100045f 	cmp	w2, #0x1
    b8dc:	540001a1 	b.ne	b910 <f0+0x1850>  // b.any
    b8e0:	29430002 	ldp	w2, w0, [x0, #24]
    b8e4:	92403c21 	and	x1, x1, #0xffff
    b8e8:	9b027c21 	mul	x1, x1, x2
    b8ec:	d360fc21 	lsr	x1, x1, #32
    b8f0:	eb00003f 	cmp	x1, x0
    b8f4:	540000e2 	b.cs	b910 <f0+0x1850>  // b.hs, b.nlast
    b8f8:	8b0102f7 	add	x23, x23, x1
    b8fc:	394002e0 	ldrb	w0, [x23]
    b900:	7103fc1f 	cmp	w0, #0xff
    b904:	54006ee0 	b.eq	c6e0 <f0+0x2620>  // b.none
    b908:	52800020 	mov	w0, #0x1                   	// #1
    b90c:	390002e0 	strb	w0, [x23]
    b910:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b914:	911963e1 	add	x1, sp, #0x658
    b918:	52800020 	mov	w0, #0x1                   	// #1
    b91c:	f9032fe2 	str	x2, [sp, #1624]
    b920:	f90333f5 	str	x21, [sp, #1632]
    b924:	97ffe65c 	bl	5294 <fwp_data.part.0.constprop.0>
    b928:	9118c283 	add	x3, x20, #0x630
    b92c:	aa0003f5 	mov	x21, x0
    b930:	f949d861 	ldr	x1, [x3, #5040]
    b934:	f949ec60 	ldr	x0, [x3, #5080]
    b938:	cb0102a1 	sub	x1, x21, x1
    b93c:	eb00403f 	cmp	x1, x0, lsl #16
    b940:	54000322 	b.cs	b9a4 <f0+0x18e4>  // b.hs, b.nlast
    b944:	d350fc22 	lsr	x2, x1, #16
    b948:	f949fc63 	ldr	x3, [x3, #5112]
    b94c:	8b020842 	add	x2, x2, x2, lsl #2
    b950:	d37df042 	lsl	x2, x2, #3
    b954:	8b020060 	add	x0, x3, x2
    b958:	f9401017 	ldr	x23, [x0, #32]
    b95c:	b4000257 	cbz	x23, b9a4 <f0+0x18e4>
    b960:	38626862 	ldrb	w2, [x3, x2]
    b964:	7100085f 	cmp	w2, #0x2
    b968:	54006140 	b.eq	c590 <f0+0x24d0>  // b.none
    b96c:	7100045f 	cmp	w2, #0x1
    b970:	540001a1 	b.ne	b9a4 <f0+0x18e4>  // b.any
    b974:	29430002 	ldp	w2, w0, [x0, #24]
    b978:	92403c21 	and	x1, x1, #0xffff
    b97c:	9b027c21 	mul	x1, x1, x2
    b980:	d360fc21 	lsr	x1, x1, #32
    b984:	eb00003f 	cmp	x1, x0
    b988:	540000e2 	b.cs	b9a4 <f0+0x18e4>  // b.hs, b.nlast
    b98c:	8b0102f7 	add	x23, x23, x1
    b990:	394002e0 	ldrb	w0, [x23]
    b994:	7103fc1f 	cmp	w0, #0xff
    b998:	54006aa0 	b.eq	c6ec <f0+0x262c>  // b.none
    b99c:	52800020 	mov	w0, #0x1                   	// #1
    b9a0:	390002e0 	strb	w0, [x23]
    b9a4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b9a8:	9119a3e1 	add	x1, sp, #0x668
    b9ac:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b9b0:	52800020 	mov	w0, #0x1                   	// #1
    b9b4:	f90337e2 	str	x2, [sp, #1640]
    b9b8:	f9033bf5 	str	x21, [sp, #1648]
    b9bc:	97ffe636 	bl	5294 <fwp_data.part.0.constprop.0>
    b9c0:	9118c283 	add	x3, x20, #0x630
    b9c4:	aa0003f5 	mov	x21, x0
    b9c8:	f949d861 	ldr	x1, [x3, #5040]
    b9cc:	f949ec60 	ldr	x0, [x3, #5080]
    b9d0:	cb0102a1 	sub	x1, x21, x1
    b9d4:	eb00403f 	cmp	x1, x0, lsl #16
    b9d8:	54000322 	b.cs	ba3c <f0+0x197c>  // b.hs, b.nlast
    b9dc:	d350fc22 	lsr	x2, x1, #16
    b9e0:	f949fc63 	ldr	x3, [x3, #5112]
    b9e4:	8b020842 	add	x2, x2, x2, lsl #2
    b9e8:	d37df042 	lsl	x2, x2, #3
    b9ec:	8b020060 	add	x0, x3, x2
    b9f0:	f9401017 	ldr	x23, [x0, #32]
    b9f4:	b4000257 	cbz	x23, ba3c <f0+0x197c>
    b9f8:	38626862 	ldrb	w2, [x3, x2]
    b9fc:	7100085f 	cmp	w2, #0x2
    ba00:	54005c20 	b.eq	c584 <f0+0x24c4>  // b.none
    ba04:	7100045f 	cmp	w2, #0x1
    ba08:	540001a1 	b.ne	ba3c <f0+0x197c>  // b.any
    ba0c:	29430002 	ldp	w2, w0, [x0, #24]
    ba10:	92403c21 	and	x1, x1, #0xffff
    ba14:	9b027c21 	mul	x1, x1, x2
    ba18:	d360fc21 	lsr	x1, x1, #32
    ba1c:	eb00003f 	cmp	x1, x0
    ba20:	540000e2 	b.cs	ba3c <f0+0x197c>  // b.hs, b.nlast
    ba24:	8b0102f7 	add	x23, x23, x1
    ba28:	394002e0 	ldrb	w0, [x23]
    ba2c:	7103fc1f 	cmp	w0, #0xff
    ba30:	54006640 	b.eq	c6f8 <f0+0x2638>  // b.none
    ba34:	52800020 	mov	w0, #0x1                   	// #1
    ba38:	390002e0 	strb	w0, [x23]
    ba3c:	9119e3e1 	add	x1, sp, #0x678
    ba40:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ba44:	52800020 	mov	w0, #0x1                   	// #1
    ba48:	f9033ff7 	str	x23, [sp, #1656]
    ba4c:	f90343f5 	str	x21, [sp, #1664]
    ba50:	97ffe611 	bl	5294 <fwp_data.part.0.constprop.0>
    ba54:	97ffe7ff 	bl	5a50 <fwp_rc_fresh>
    ba58:	aa0003e2 	mov	x2, x0
    ba5c:	911a23e1 	add	x1, sp, #0x688
    ba60:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ba64:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ba68:	52800020 	mov	w0, #0x1                   	// #1
    ba6c:	f90347f5 	str	x21, [sp, #1672]
    ba70:	f9034be2 	str	x2, [sp, #1680]
    ba74:	97ffe608 	bl	5294 <fwp_data.part.0.constprop.0>
    ba78:	97ffe7f6 	bl	5a50 <fwp_rc_fresh>
    ba7c:	aa0003e2 	mov	x2, x0
    ba80:	911a63e1 	add	x1, sp, #0x698
    ba84:	52800020 	mov	w0, #0x1                   	// #1
    ba88:	f9034ff7 	str	x23, [sp, #1688]
    ba8c:	f90353e2 	str	x2, [sp, #1696]
    ba90:	97ffe601 	bl	5294 <fwp_data.part.0.constprop.0>
    ba94:	97ffe7ef 	bl	5a50 <fwp_rc_fresh>
    ba98:	aa0003e2 	mov	x2, x0
    ba9c:	911aa3e1 	add	x1, sp, #0x6a8
    baa0:	52800020 	mov	w0, #0x1                   	// #1
    baa4:	f90357f5 	str	x21, [sp, #1704]
    baa8:	f9035be2 	str	x2, [sp, #1712]
    baac:	97ffe5fa 	bl	5294 <fwp_data.part.0.constprop.0>
    bab0:	9118c283 	add	x3, x20, #0x630
    bab4:	aa0003f5 	mov	x21, x0
    bab8:	f949d861 	ldr	x1, [x3, #5040]
    babc:	f949ec60 	ldr	x0, [x3, #5080]
    bac0:	cb0102a1 	sub	x1, x21, x1
    bac4:	eb00403f 	cmp	x1, x0, lsl #16
    bac8:	54000322 	b.cs	bb2c <f0+0x1a6c>  // b.hs, b.nlast
    bacc:	d350fc22 	lsr	x2, x1, #16
    bad0:	f949fc63 	ldr	x3, [x3, #5112]
    bad4:	8b020842 	add	x2, x2, x2, lsl #2
    bad8:	d37df042 	lsl	x2, x2, #3
    badc:	8b020060 	add	x0, x3, x2
    bae0:	f9401017 	ldr	x23, [x0, #32]
    bae4:	b4000257 	cbz	x23, bb2c <f0+0x1a6c>
    bae8:	38626862 	ldrb	w2, [x3, x2]
    baec:	7100085f 	cmp	w2, #0x2
    baf0:	54005440 	b.eq	c578 <f0+0x24b8>  // b.none
    baf4:	7100045f 	cmp	w2, #0x1
    baf8:	540001a1 	b.ne	bb2c <f0+0x1a6c>  // b.any
    bafc:	29430002 	ldp	w2, w0, [x0, #24]
    bb00:	92403c21 	and	x1, x1, #0xffff
    bb04:	9b027c21 	mul	x1, x1, x2
    bb08:	d360fc21 	lsr	x1, x1, #32
    bb0c:	eb00003f 	cmp	x1, x0
    bb10:	540000e2 	b.cs	bb2c <f0+0x1a6c>  // b.hs, b.nlast
    bb14:	8b0102f7 	add	x23, x23, x1
    bb18:	394002e0 	ldrb	w0, [x23]
    bb1c:	7103fc1f 	cmp	w0, #0xff
    bb20:	54005f20 	b.eq	c704 <f0+0x2644>  // b.none
    bb24:	52800020 	mov	w0, #0x1                   	// #1
    bb28:	390002e0 	strb	w0, [x23]
    bb2c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bb30:	911ae3e1 	add	x1, sp, #0x6b8
    bb34:	52800020 	mov	w0, #0x1                   	// #1
    bb38:	f9035fe2 	str	x2, [sp, #1720]
    bb3c:	f90363f5 	str	x21, [sp, #1728]
    bb40:	97ffe5d5 	bl	5294 <fwp_data.part.0.constprop.0>
    bb44:	9118c283 	add	x3, x20, #0x630
    bb48:	aa0003f5 	mov	x21, x0
    bb4c:	f949d861 	ldr	x1, [x3, #5040]
    bb50:	f949ec60 	ldr	x0, [x3, #5080]
    bb54:	cb0102a1 	sub	x1, x21, x1
    bb58:	eb00403f 	cmp	x1, x0, lsl #16
    bb5c:	54000322 	b.cs	bbc0 <f0+0x1b00>  // b.hs, b.nlast
    bb60:	d350fc22 	lsr	x2, x1, #16
    bb64:	f949fc63 	ldr	x3, [x3, #5112]
    bb68:	8b020842 	add	x2, x2, x2, lsl #2
    bb6c:	d37df042 	lsl	x2, x2, #3
    bb70:	8b020060 	add	x0, x3, x2
    bb74:	f9401017 	ldr	x23, [x0, #32]
    bb78:	b4000257 	cbz	x23, bbc0 <f0+0x1b00>
    bb7c:	38626862 	ldrb	w2, [x3, x2]
    bb80:	7100085f 	cmp	w2, #0x2
    bb84:	54004f40 	b.eq	c56c <f0+0x24ac>  // b.none
    bb88:	7100045f 	cmp	w2, #0x1
    bb8c:	540001a1 	b.ne	bbc0 <f0+0x1b00>  // b.any
    bb90:	29430002 	ldp	w2, w0, [x0, #24]
    bb94:	92403c21 	and	x1, x1, #0xffff
    bb98:	9b027c21 	mul	x1, x1, x2
    bb9c:	d360fc21 	lsr	x1, x1, #32
    bba0:	eb00003f 	cmp	x1, x0
    bba4:	540000e2 	b.cs	bbc0 <f0+0x1b00>  // b.hs, b.nlast
    bba8:	8b0102f7 	add	x23, x23, x1
    bbac:	394002e0 	ldrb	w0, [x23]
    bbb0:	7103fc1f 	cmp	w0, #0xff
    bbb4:	54005ae0 	b.eq	c710 <f0+0x2650>  // b.none
    bbb8:	52800020 	mov	w0, #0x1                   	// #1
    bbbc:	390002e0 	strb	w0, [x23]
    bbc0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bbc4:	911b23e1 	add	x1, sp, #0x6c8
    bbc8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bbcc:	52800020 	mov	w0, #0x1                   	// #1
    bbd0:	f90367e2 	str	x2, [sp, #1736]
    bbd4:	f9036bf5 	str	x21, [sp, #1744]
    bbd8:	97ffe5af 	bl	5294 <fwp_data.part.0.constprop.0>
    bbdc:	9118c283 	add	x3, x20, #0x630
    bbe0:	aa0003f5 	mov	x21, x0
    bbe4:	f949d861 	ldr	x1, [x3, #5040]
    bbe8:	f949ec60 	ldr	x0, [x3, #5080]
    bbec:	cb0102a1 	sub	x1, x21, x1
    bbf0:	eb00403f 	cmp	x1, x0, lsl #16
    bbf4:	54000322 	b.cs	bc58 <f0+0x1b98>  // b.hs, b.nlast
    bbf8:	d350fc22 	lsr	x2, x1, #16
    bbfc:	f949fc63 	ldr	x3, [x3, #5112]
    bc00:	8b020842 	add	x2, x2, x2, lsl #2
    bc04:	d37df042 	lsl	x2, x2, #3
    bc08:	8b020060 	add	x0, x3, x2
    bc0c:	f9401017 	ldr	x23, [x0, #32]
    bc10:	b4000257 	cbz	x23, bc58 <f0+0x1b98>
    bc14:	38626862 	ldrb	w2, [x3, x2]
    bc18:	7100085f 	cmp	w2, #0x2
    bc1c:	54004a20 	b.eq	c560 <f0+0x24a0>  // b.none
    bc20:	7100045f 	cmp	w2, #0x1
    bc24:	540001a1 	b.ne	bc58 <f0+0x1b98>  // b.any
    bc28:	29430002 	ldp	w2, w0, [x0, #24]
    bc2c:	92403c21 	and	x1, x1, #0xffff
    bc30:	9b027c21 	mul	x1, x1, x2
    bc34:	d360fc21 	lsr	x1, x1, #32
    bc38:	eb00003f 	cmp	x1, x0
    bc3c:	540000e2 	b.cs	bc58 <f0+0x1b98>  // b.hs, b.nlast
    bc40:	8b0102f7 	add	x23, x23, x1
    bc44:	394002e0 	ldrb	w0, [x23]
    bc48:	7103fc1f 	cmp	w0, #0xff
    bc4c:	54005680 	b.eq	c71c <f0+0x265c>  // b.none
    bc50:	52800020 	mov	w0, #0x1                   	// #1
    bc54:	390002e0 	strb	w0, [x23]
    bc58:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bc5c:	911b63e1 	add	x1, sp, #0x6d8
    bc60:	52800020 	mov	w0, #0x1                   	// #1
    bc64:	f9036fe2 	str	x2, [sp, #1752]
    bc68:	f90373f5 	str	x21, [sp, #1760]
    bc6c:	97ffe58a 	bl	5294 <fwp_data.part.0.constprop.0>
    bc70:	9118c283 	add	x3, x20, #0x630
    bc74:	aa0003f5 	mov	x21, x0
    bc78:	f949d861 	ldr	x1, [x3, #5040]
    bc7c:	f949ec60 	ldr	x0, [x3, #5080]
    bc80:	cb0102a1 	sub	x1, x21, x1
    bc84:	eb00403f 	cmp	x1, x0, lsl #16
    bc88:	54000322 	b.cs	bcec <f0+0x1c2c>  // b.hs, b.nlast
    bc8c:	d350fc22 	lsr	x2, x1, #16
    bc90:	f949fc63 	ldr	x3, [x3, #5112]
    bc94:	8b020842 	add	x2, x2, x2, lsl #2
    bc98:	d37df042 	lsl	x2, x2, #3
    bc9c:	8b020060 	add	x0, x3, x2
    bca0:	f9401017 	ldr	x23, [x0, #32]
    bca4:	b4000257 	cbz	x23, bcec <f0+0x1c2c>
    bca8:	38626862 	ldrb	w2, [x3, x2]
    bcac:	7100085f 	cmp	w2, #0x2
    bcb0:	54004520 	b.eq	c554 <f0+0x2494>  // b.none
    bcb4:	7100045f 	cmp	w2, #0x1
    bcb8:	540001a1 	b.ne	bcec <f0+0x1c2c>  // b.any
    bcbc:	29430002 	ldp	w2, w0, [x0, #24]
    bcc0:	92403c21 	and	x1, x1, #0xffff
    bcc4:	9b027c21 	mul	x1, x1, x2
    bcc8:	d360fc21 	lsr	x1, x1, #32
    bccc:	eb00003f 	cmp	x1, x0
    bcd0:	540000e2 	b.cs	bcec <f0+0x1c2c>  // b.hs, b.nlast
    bcd4:	8b0102f7 	add	x23, x23, x1
    bcd8:	394002e0 	ldrb	w0, [x23]
    bcdc:	7103fc1f 	cmp	w0, #0xff
    bce0:	54005240 	b.eq	c728 <f0+0x2668>  // b.none
    bce4:	52800020 	mov	w0, #0x1                   	// #1
    bce8:	390002e0 	strb	w0, [x23]
    bcec:	911ba3e1 	add	x1, sp, #0x6e8
    bcf0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bcf4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bcf8:	52800020 	mov	w0, #0x1                   	// #1
    bcfc:	f90377f7 	str	x23, [sp, #1768]
    bd00:	f9037bf5 	str	x21, [sp, #1776]
    bd04:	97ffe564 	bl	5294 <fwp_data.part.0.constprop.0>
    bd08:	97ffe752 	bl	5a50 <fwp_rc_fresh>
    bd0c:	aa0003e2 	mov	x2, x0
    bd10:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bd14:	911be3e1 	add	x1, sp, #0x6f8
    bd18:	52800020 	mov	w0, #0x1                   	// #1
    bd1c:	f9037fe3 	str	x3, [sp, #1784]
    bd20:	f90383e2 	str	x2, [sp, #1792]
    bd24:	97ffe55c 	bl	5294 <fwp_data.part.0.constprop.0>
    bd28:	97ffe74a 	bl	5a50 <fwp_rc_fresh>
    bd2c:	aa0003e2 	mov	x2, x0
    bd30:	911c23e1 	add	x1, sp, #0x708
    bd34:	52800020 	mov	w0, #0x1                   	// #1
    bd38:	f90387f7 	str	x23, [sp, #1800]
    bd3c:	f9038be2 	str	x2, [sp, #1808]
    bd40:	97ffe555 	bl	5294 <fwp_data.part.0.constprop.0>
    bd44:	9118c283 	add	x3, x20, #0x630
    bd48:	aa0003f5 	mov	x21, x0
    bd4c:	f949d861 	ldr	x1, [x3, #5040]
    bd50:	f949ec60 	ldr	x0, [x3, #5080]
    bd54:	cb0102a1 	sub	x1, x21, x1
    bd58:	eb00403f 	cmp	x1, x0, lsl #16
    bd5c:	54000322 	b.cs	bdc0 <f0+0x1d00>  // b.hs, b.nlast
    bd60:	d350fc22 	lsr	x2, x1, #16
    bd64:	f949fc63 	ldr	x3, [x3, #5112]
    bd68:	8b020842 	add	x2, x2, x2, lsl #2
    bd6c:	d37df042 	lsl	x2, x2, #3
    bd70:	8b020060 	add	x0, x3, x2
    bd74:	f9401017 	ldr	x23, [x0, #32]
    bd78:	b4000257 	cbz	x23, bdc0 <f0+0x1d00>
    bd7c:	38626862 	ldrb	w2, [x3, x2]
    bd80:	7100085f 	cmp	w2, #0x2
    bd84:	54003e20 	b.eq	c548 <f0+0x2488>  // b.none
    bd88:	7100045f 	cmp	w2, #0x1
    bd8c:	540001a1 	b.ne	bdc0 <f0+0x1d00>  // b.any
    bd90:	29430002 	ldp	w2, w0, [x0, #24]
    bd94:	92403c21 	and	x1, x1, #0xffff
    bd98:	9b027c21 	mul	x1, x1, x2
    bd9c:	d360fc21 	lsr	x1, x1, #32
    bda0:	eb00003f 	cmp	x1, x0
    bda4:	540000e2 	b.cs	bdc0 <f0+0x1d00>  // b.hs, b.nlast
    bda8:	8b0102f7 	add	x23, x23, x1
    bdac:	394002e0 	ldrb	w0, [x23]
    bdb0:	7103fc1f 	cmp	w0, #0xff
    bdb4:	54004c00 	b.eq	c734 <f0+0x2674>  // b.none
    bdb8:	52800020 	mov	w0, #0x1                   	// #1
    bdbc:	390002e0 	strb	w0, [x23]
    bdc0:	911c63e1 	add	x1, sp, #0x718
    bdc4:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bdc8:	52800020 	mov	w0, #0x1                   	// #1
    bdcc:	f9038ff7 	str	x23, [sp, #1816]
    bdd0:	f90393f5 	str	x21, [sp, #1824]
    bdd4:	97ffe530 	bl	5294 <fwp_data.part.0.constprop.0>
    bdd8:	97ffe71e 	bl	5a50 <fwp_rc_fresh>
    bddc:	aa0003e2 	mov	x2, x0
    bde0:	911ca3e1 	add	x1, sp, #0x728
    bde4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bde8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bdec:	52800020 	mov	w0, #0x1                   	// #1
    bdf0:	f90397f5 	str	x21, [sp, #1832]
    bdf4:	f9039be2 	str	x2, [sp, #1840]
    bdf8:	97ffe527 	bl	5294 <fwp_data.part.0.constprop.0>
    bdfc:	97ffe715 	bl	5a50 <fwp_rc_fresh>
    be00:	aa0003e2 	mov	x2, x0
    be04:	911ce3e1 	add	x1, sp, #0x738
    be08:	52800020 	mov	w0, #0x1                   	// #1
    be0c:	f9039ff7 	str	x23, [sp, #1848]
    be10:	f903a3e2 	str	x2, [sp, #1856]
    be14:	97ffe520 	bl	5294 <fwp_data.part.0.constprop.0>
    be18:	97ffe70e 	bl	5a50 <fwp_rc_fresh>
    be1c:	aa0003e2 	mov	x2, x0
    be20:	911d23e1 	add	x1, sp, #0x748
    be24:	52800020 	mov	w0, #0x1                   	// #1
    be28:	f903a7f5 	str	x21, [sp, #1864]
    be2c:	f903abe2 	str	x2, [sp, #1872]
    be30:	97ffe519 	bl	5294 <fwp_data.part.0.constprop.0>
    be34:	97ffe707 	bl	5a50 <fwp_rc_fresh>
    be38:	aa0003e2 	mov	x2, x0
    be3c:	911d63e1 	add	x1, sp, #0x758
    be40:	52800020 	mov	w0, #0x1                   	// #1
    be44:	f903aff7 	str	x23, [sp, #1880]
    be48:	f903b3e2 	str	x2, [sp, #1888]
    be4c:	97ffe512 	bl	5294 <fwp_data.part.0.constprop.0>
    be50:	9118c283 	add	x3, x20, #0x630
    be54:	aa0003f5 	mov	x21, x0
    be58:	f949d861 	ldr	x1, [x3, #5040]
    be5c:	f949ec60 	ldr	x0, [x3, #5080]
    be60:	cb0102a1 	sub	x1, x21, x1
    be64:	eb00403f 	cmp	x1, x0, lsl #16
    be68:	54000322 	b.cs	becc <f0+0x1e0c>  // b.hs, b.nlast
    be6c:	d350fc22 	lsr	x2, x1, #16
    be70:	f949fc63 	ldr	x3, [x3, #5112]
    be74:	8b020842 	add	x2, x2, x2, lsl #2
    be78:	d37df042 	lsl	x2, x2, #3
    be7c:	8b020060 	add	x0, x3, x2
    be80:	f9401017 	ldr	x23, [x0, #32]
    be84:	b4000257 	cbz	x23, becc <f0+0x1e0c>
    be88:	38626862 	ldrb	w2, [x3, x2]
    be8c:	7100085f 	cmp	w2, #0x2
    be90:	54003560 	b.eq	c53c <f0+0x247c>  // b.none
    be94:	7100045f 	cmp	w2, #0x1
    be98:	540001a1 	b.ne	becc <f0+0x1e0c>  // b.any
    be9c:	29430002 	ldp	w2, w0, [x0, #24]
    bea0:	92403c21 	and	x1, x1, #0xffff
    bea4:	9b027c21 	mul	x1, x1, x2
    bea8:	d360fc21 	lsr	x1, x1, #32
    beac:	eb00003f 	cmp	x1, x0
    beb0:	540000e2 	b.cs	becc <f0+0x1e0c>  // b.hs, b.nlast
    beb4:	8b0102f7 	add	x23, x23, x1
    beb8:	394002e0 	ldrb	w0, [x23]
    bebc:	7103fc1f 	cmp	w0, #0xff
    bec0:	54004400 	b.eq	c740 <f0+0x2680>  // b.none
    bec4:	52800020 	mov	w0, #0x1                   	// #1
    bec8:	390002e0 	strb	w0, [x23]
    becc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bed0:	911da3e1 	add	x1, sp, #0x768
    bed4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bed8:	52800020 	mov	w0, #0x1                   	// #1
    bedc:	f903b7e2 	str	x2, [sp, #1896]
    bee0:	f903bbf5 	str	x21, [sp, #1904]
    bee4:	97ffe4ec 	bl	5294 <fwp_data.part.0.constprop.0>
    bee8:	9118c283 	add	x3, x20, #0x630
    beec:	aa0003f5 	mov	x21, x0
    bef0:	f949d861 	ldr	x1, [x3, #5040]
    bef4:	f949ec60 	ldr	x0, [x3, #5080]
    bef8:	cb0102a1 	sub	x1, x21, x1
    befc:	eb00403f 	cmp	x1, x0, lsl #16
    bf00:	54000322 	b.cs	bf64 <f0+0x1ea4>  // b.hs, b.nlast
    bf04:	d350fc22 	lsr	x2, x1, #16
    bf08:	f949fc63 	ldr	x3, [x3, #5112]
    bf0c:	8b020842 	add	x2, x2, x2, lsl #2
    bf10:	d37df042 	lsl	x2, x2, #3
    bf14:	8b020060 	add	x0, x3, x2
    bf18:	f9401017 	ldr	x23, [x0, #32]
    bf1c:	b4000257 	cbz	x23, bf64 <f0+0x1ea4>
    bf20:	38626862 	ldrb	w2, [x3, x2]
    bf24:	7100085f 	cmp	w2, #0x2
    bf28:	54003040 	b.eq	c530 <f0+0x2470>  // b.none
    bf2c:	7100045f 	cmp	w2, #0x1
    bf30:	540001a1 	b.ne	bf64 <f0+0x1ea4>  // b.any
    bf34:	29430002 	ldp	w2, w0, [x0, #24]
    bf38:	92403c21 	and	x1, x1, #0xffff
    bf3c:	9b027c21 	mul	x1, x1, x2
    bf40:	d360fc21 	lsr	x1, x1, #32
    bf44:	eb00003f 	cmp	x1, x0
    bf48:	540000e2 	b.cs	bf64 <f0+0x1ea4>  // b.hs, b.nlast
    bf4c:	8b0102f7 	add	x23, x23, x1
    bf50:	394002e0 	ldrb	w0, [x23]
    bf54:	7103fc1f 	cmp	w0, #0xff
    bf58:	54003fa0 	b.eq	c74c <f0+0x268c>  // b.none
    bf5c:	52800020 	mov	w0, #0x1                   	// #1
    bf60:	390002e0 	strb	w0, [x23]
    bf64:	911de3e1 	add	x1, sp, #0x778
    bf68:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bf6c:	52800020 	mov	w0, #0x1                   	// #1
    bf70:	f903bff7 	str	x23, [sp, #1912]
    bf74:	f903c3f5 	str	x21, [sp, #1920]
    bf78:	97ffe4c7 	bl	5294 <fwp_data.part.0.constprop.0>
    bf7c:	97ffe6b5 	bl	5a50 <fwp_rc_fresh>
    bf80:	aa0003e2 	mov	x2, x0
    bf84:	911e23e1 	add	x1, sp, #0x788
    bf88:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bf8c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bf90:	52800020 	mov	w0, #0x1                   	// #1
    bf94:	f903c7f5 	str	x21, [sp, #1928]
    bf98:	f903cbe2 	str	x2, [sp, #1936]
    bf9c:	97ffe4be 	bl	5294 <fwp_data.part.0.constprop.0>
    bfa0:	97ffe6ac 	bl	5a50 <fwp_rc_fresh>
    bfa4:	aa0003e2 	mov	x2, x0
    bfa8:	911e63e1 	add	x1, sp, #0x798
    bfac:	52800020 	mov	w0, #0x1                   	// #1
    bfb0:	f903cff7 	str	x23, [sp, #1944]
    bfb4:	f903d3e2 	str	x2, [sp, #1952]
    bfb8:	97ffe4b7 	bl	5294 <fwp_data.part.0.constprop.0>
    bfbc:	97ffe6a5 	bl	5a50 <fwp_rc_fresh>
    bfc0:	aa0003e2 	mov	x2, x0
    bfc4:	911ea3e1 	add	x1, sp, #0x7a8
    bfc8:	52800020 	mov	w0, #0x1                   	// #1
    bfcc:	f903d7f5 	str	x21, [sp, #1960]
    bfd0:	f903dbe2 	str	x2, [sp, #1968]
    bfd4:	97ffe4b0 	bl	5294 <fwp_data.part.0.constprop.0>
    bfd8:	9118c283 	add	x3, x20, #0x630
    bfdc:	aa0003f5 	mov	x21, x0
    bfe0:	f949d861 	ldr	x1, [x3, #5040]
    bfe4:	f949ec60 	ldr	x0, [x3, #5080]
    bfe8:	cb0102a1 	sub	x1, x21, x1
    bfec:	eb00403f 	cmp	x1, x0, lsl #16
    bff0:	54000322 	b.cs	c054 <f0+0x1f94>  // b.hs, b.nlast
    bff4:	d350fc22 	lsr	x2, x1, #16
    bff8:	f949fc63 	ldr	x3, [x3, #5112]
    bffc:	8b020842 	add	x2, x2, x2, lsl #2
    c000:	d37df042 	lsl	x2, x2, #3
    c004:	8b020060 	add	x0, x3, x2
    c008:	f9401017 	ldr	x23, [x0, #32]
    c00c:	b4000257 	cbz	x23, c054 <f0+0x1f94>
    c010:	38626862 	ldrb	w2, [x3, x2]
    c014:	7100085f 	cmp	w2, #0x2
    c018:	54002860 	b.eq	c524 <f0+0x2464>  // b.none
    c01c:	7100045f 	cmp	w2, #0x1
    c020:	540001a1 	b.ne	c054 <f0+0x1f94>  // b.any
    c024:	29430002 	ldp	w2, w0, [x0, #24]
    c028:	92403c21 	and	x1, x1, #0xffff
    c02c:	9b027c21 	mul	x1, x1, x2
    c030:	d360fc21 	lsr	x1, x1, #32
    c034:	eb00003f 	cmp	x1, x0
    c038:	540000e2 	b.cs	c054 <f0+0x1f94>  // b.hs, b.nlast
    c03c:	8b0102f7 	add	x23, x23, x1
    c040:	394002e0 	ldrb	w0, [x23]
    c044:	7103fc1f 	cmp	w0, #0xff
    c048:	54003880 	b.eq	c758 <f0+0x2698>  // b.none
    c04c:	52800020 	mov	w0, #0x1                   	// #1
    c050:	390002e0 	strb	w0, [x23]
    c054:	911ee3e1 	add	x1, sp, #0x7b8
    c058:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c05c:	52800020 	mov	w0, #0x1                   	// #1
    c060:	f903dfe2 	str	x2, [sp, #1976]
    c064:	f903e3f5 	str	x21, [sp, #1984]
    c068:	97ffe48b 	bl	5294 <fwp_data.part.0.constprop.0>
    c06c:	97ffe679 	bl	5a50 <fwp_rc_fresh>
    c070:	aa0003e2 	mov	x2, x0
    c074:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c078:	911f23e1 	add	x1, sp, #0x7c8
    c07c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c080:	52800020 	mov	w0, #0x1                   	// #1
    c084:	f903e7e3 	str	x3, [sp, #1992]
    c088:	f903ebe2 	str	x2, [sp, #2000]
    c08c:	97ffe482 	bl	5294 <fwp_data.part.0.constprop.0>
    c090:	9118c283 	add	x3, x20, #0x630
    c094:	aa0003f5 	mov	x21, x0
    c098:	f949d861 	ldr	x1, [x3, #5040]
    c09c:	f949ec60 	ldr	x0, [x3, #5080]
    c0a0:	cb0102a1 	sub	x1, x21, x1
    c0a4:	eb00403f 	cmp	x1, x0, lsl #16
    c0a8:	54000322 	b.cs	c10c <f0+0x204c>  // b.hs, b.nlast
    c0ac:	d350fc22 	lsr	x2, x1, #16
    c0b0:	f949fc63 	ldr	x3, [x3, #5112]
    c0b4:	8b020842 	add	x2, x2, x2, lsl #2
    c0b8:	d37df042 	lsl	x2, x2, #3
    c0bc:	8b020060 	add	x0, x3, x2
    c0c0:	f9401017 	ldr	x23, [x0, #32]
    c0c4:	b4000257 	cbz	x23, c10c <f0+0x204c>
    c0c8:	38626862 	ldrb	w2, [x3, x2]
    c0cc:	7100085f 	cmp	w2, #0x2
    c0d0:	54002240 	b.eq	c518 <f0+0x2458>  // b.none
    c0d4:	7100045f 	cmp	w2, #0x1
    c0d8:	540001a1 	b.ne	c10c <f0+0x204c>  // b.any
    c0dc:	29430002 	ldp	w2, w0, [x0, #24]
    c0e0:	92403c21 	and	x1, x1, #0xffff
    c0e4:	9b027c21 	mul	x1, x1, x2
    c0e8:	d360fc21 	lsr	x1, x1, #32
    c0ec:	eb00003f 	cmp	x1, x0
    c0f0:	540000e2 	b.cs	c10c <f0+0x204c>  // b.hs, b.nlast
    c0f4:	8b0102f7 	add	x23, x23, x1
    c0f8:	394002e0 	ldrb	w0, [x23]
    c0fc:	7103fc1f 	cmp	w0, #0xff
    c100:	54003320 	b.eq	c764 <f0+0x26a4>  // b.none
    c104:	52800020 	mov	w0, #0x1                   	// #1
    c108:	390002e0 	strb	w0, [x23]
    c10c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c110:	911f63e1 	add	x1, sp, #0x7d8
    c114:	52800020 	mov	w0, #0x1                   	// #1
    c118:	f903efe2 	str	x2, [sp, #2008]
    c11c:	f903f3f5 	str	x21, [sp, #2016]
    c120:	97ffe45d 	bl	5294 <fwp_data.part.0.constprop.0>
    c124:	9118c283 	add	x3, x20, #0x630
    c128:	aa0003f5 	mov	x21, x0
    c12c:	f949d861 	ldr	x1, [x3, #5040]
    c130:	f949ec60 	ldr	x0, [x3, #5080]
    c134:	cb0102a1 	sub	x1, x21, x1
    c138:	eb00403f 	cmp	x1, x0, lsl #16
    c13c:	54000322 	b.cs	c1a0 <f0+0x20e0>  // b.hs, b.nlast
    c140:	d350fc22 	lsr	x2, x1, #16
    c144:	f949fc63 	ldr	x3, [x3, #5112]
    c148:	8b020842 	add	x2, x2, x2, lsl #2
    c14c:	d37df042 	lsl	x2, x2, #3
    c150:	8b020060 	add	x0, x3, x2
    c154:	f9401017 	ldr	x23, [x0, #32]
    c158:	b4000257 	cbz	x23, c1a0 <f0+0x20e0>
    c15c:	38626862 	ldrb	w2, [x3, x2]
    c160:	7100085f 	cmp	w2, #0x2
    c164:	54001d40 	b.eq	c50c <f0+0x244c>  // b.none
    c168:	7100045f 	cmp	w2, #0x1
    c16c:	540001a1 	b.ne	c1a0 <f0+0x20e0>  // b.any
    c170:	29430002 	ldp	w2, w0, [x0, #24]
    c174:	92403c21 	and	x1, x1, #0xffff
    c178:	9b027c21 	mul	x1, x1, x2
    c17c:	d360fc21 	lsr	x1, x1, #32
    c180:	eb00003f 	cmp	x1, x0
    c184:	540000e2 	b.cs	c1a0 <f0+0x20e0>  // b.hs, b.nlast
    c188:	8b0102f7 	add	x23, x23, x1
    c18c:	394002e0 	ldrb	w0, [x23]
    c190:	7103fc1f 	cmp	w0, #0xff
    c194:	54002ee0 	b.eq	c770 <f0+0x26b0>  // b.none
    c198:	52800020 	mov	w0, #0x1                   	// #1
    c19c:	390002e0 	strb	w0, [x23]
    c1a0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c1a4:	911fa3e1 	add	x1, sp, #0x7e8
    c1a8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c1ac:	52800020 	mov	w0, #0x1                   	// #1
    c1b0:	f903f7e2 	str	x2, [sp, #2024]
    c1b4:	f903fbf5 	str	x21, [sp, #2032]
    c1b8:	97ffe437 	bl	5294 <fwp_data.part.0.constprop.0>
    c1bc:	9118c283 	add	x3, x20, #0x630
    c1c0:	aa0003f5 	mov	x21, x0
    c1c4:	f949d861 	ldr	x1, [x3, #5040]
    c1c8:	f949ec60 	ldr	x0, [x3, #5080]
    c1cc:	cb0102a1 	sub	x1, x21, x1
    c1d0:	eb00403f 	cmp	x1, x0, lsl #16
    c1d4:	54000322 	b.cs	c238 <f0+0x2178>  // b.hs, b.nlast
    c1d8:	d350fc22 	lsr	x2, x1, #16
    c1dc:	f949fc63 	ldr	x3, [x3, #5112]
    c1e0:	8b020842 	add	x2, x2, x2, lsl #2
    c1e4:	d37df042 	lsl	x2, x2, #3
    c1e8:	8b020060 	add	x0, x3, x2
    c1ec:	f9401017 	ldr	x23, [x0, #32]
    c1f0:	b4000257 	cbz	x23, c238 <f0+0x2178>
    c1f4:	38626862 	ldrb	w2, [x3, x2]
    c1f8:	7100085f 	cmp	w2, #0x2
    c1fc:	54001820 	b.eq	c500 <f0+0x2440>  // b.none
    c200:	7100045f 	cmp	w2, #0x1
    c204:	540001a1 	b.ne	c238 <f0+0x2178>  // b.any
    c208:	29430002 	ldp	w2, w0, [x0, #24]
    c20c:	92403c21 	and	x1, x1, #0xffff
    c210:	9b027c21 	mul	x1, x1, x2
    c214:	d360fc21 	lsr	x1, x1, #32
    c218:	eb00003f 	cmp	x1, x0
    c21c:	540000e2 	b.cs	c238 <f0+0x2178>  // b.hs, b.nlast
    c220:	8b0102f7 	add	x23, x23, x1
    c224:	394002e0 	ldrb	w0, [x23]
    c228:	7103fc1f 	cmp	w0, #0xff
    c22c:	54002a80 	b.eq	c77c <f0+0x26bc>  // b.none
    c230:	52800020 	mov	w0, #0x1                   	// #1
    c234:	390002e0 	strb	w0, [x23]
    c238:	911fe3e1 	add	x1, sp, #0x7f8
    c23c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c240:	52800020 	mov	w0, #0x1                   	// #1
    c244:	f903fff7 	str	x23, [sp, #2040]
    c248:	f90403f5 	str	x21, [sp, #2048]
    c24c:	97ffe412 	bl	5294 <fwp_data.part.0.constprop.0>
    c250:	97ffe600 	bl	5a50 <fwp_rc_fresh>
    c254:	aa0003e2 	mov	x2, x0
    c258:	912023e1 	add	x1, sp, #0x808
    c25c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    c260:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    c264:	52800020 	mov	w0, #0x1                   	// #1
    c268:	f90407f5 	str	x21, [sp, #2056]
    c26c:	9118c294 	add	x20, x20, #0x630
    c270:	f9040be2 	str	x2, [sp, #2064]
    c274:	97ffe408 	bl	5294 <fwp_data.part.0.constprop.0>
    c278:	97ffe5f6 	bl	5a50 <fwp_rc_fresh>
    c27c:	aa0003e2 	mov	x2, x0
    c280:	912063e1 	add	x1, sp, #0x818
    c284:	52800020 	mov	w0, #0x1                   	// #1
    c288:	f9040ff7 	str	x23, [sp, #2072]
    c28c:	f90413e2 	str	x2, [sp, #2080]
    c290:	97ffe401 	bl	5294 <fwp_data.part.0.constprop.0>
    c294:	97ffe5ef 	bl	5a50 <fwp_rc_fresh>
    c298:	aa0003e2 	mov	x2, x0
    c29c:	9120a3e1 	add	x1, sp, #0x828
    c2a0:	52800020 	mov	w0, #0x1                   	// #1
    c2a4:	f90417f5 	str	x21, [sp, #2088]
    c2a8:	f9041be2 	str	x2, [sp, #2096]
    c2ac:	97ffe3fa 	bl	5294 <fwp_data.part.0.constprop.0>
    c2b0:	f949da81 	ldr	x1, [x20, #5040]
    c2b4:	aa0003f5 	mov	x21, x0
    c2b8:	f949ee80 	ldr	x0, [x20, #5080]
    c2bc:	cb0102a1 	sub	x1, x21, x1
    c2c0:	eb00403f 	cmp	x1, x0, lsl #16
    c2c4:	54000322 	b.cs	c328 <f0+0x2268>  // b.hs, b.nlast
    c2c8:	d350fc22 	lsr	x2, x1, #16
    c2cc:	f949fe83 	ldr	x3, [x20, #5112]
    c2d0:	8b020842 	add	x2, x2, x2, lsl #2
    c2d4:	d37df042 	lsl	x2, x2, #3
    c2d8:	8b020060 	add	x0, x3, x2
    c2dc:	f9401014 	ldr	x20, [x0, #32]
    c2e0:	b4000254 	cbz	x20, c328 <f0+0x2268>
    c2e4:	38626862 	ldrb	w2, [x3, x2]
    c2e8:	7100085f 	cmp	w2, #0x2
    c2ec:	54001040 	b.eq	c4f4 <f0+0x2434>  // b.none
    c2f0:	7100045f 	cmp	w2, #0x1
    c2f4:	540001a1 	b.ne	c328 <f0+0x2268>  // b.any
    c2f8:	29430002 	ldp	w2, w0, [x0, #24]
    c2fc:	92403c21 	and	x1, x1, #0xffff
    c300:	9b027c21 	mul	x1, x1, x2
    c304:	d360fc21 	lsr	x1, x1, #32
    c308:	eb00003f 	cmp	x1, x0
    c30c:	540000e2 	b.cs	c328 <f0+0x2268>  // b.hs, b.nlast
    c310:	8b010294 	add	x20, x20, x1
    c314:	39400280 	ldrb	w0, [x20]
    c318:	7103fc1f 	cmp	w0, #0xff
    c31c:	540014c0 	b.eq	c5b4 <f0+0x24f4>  // b.none
    c320:	52800020 	mov	w0, #0x1                   	// #1
    c324:	39000280 	strb	w0, [x20]
    c328:	9120e3e1 	add	x1, sp, #0x838
    c32c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c330:	52800020 	mov	w0, #0x1                   	// #1
    c334:	f9041fe2 	str	x2, [sp, #2104]
    c338:	f90423f5 	str	x21, [sp, #2112]
    c33c:	97ffe3d6 	bl	5294 <fwp_data.part.0.constprop.0>
    c340:	97ffe5c4 	bl	5a50 <fwp_rc_fresh>
    c344:	aa0003e2 	mov	x2, x0
    c348:	aa1603e1 	mov	x1, x22
    c34c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c350:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c354:	52800020 	mov	w0, #0x1                   	// #1
    c358:	f90427e3 	str	x3, [sp, #2120]
    c35c:	f9042be2 	str	x2, [sp, #2128]
    c360:	97ffe3cd 	bl	5294 <fwp_data.part.0.constprop.0>
    c364:	97ffe5bb 	bl	5a50 <fwp_rc_fresh>
    c368:	aa0003f5 	mov	x21, x0
    c36c:	aa1303e1 	mov	x1, x19
    c370:	97fff070 	bl	8530 <fwp_hof0.constprop.0>
    c374:	aa0003f4 	mov	x20, x0
    c378:	aa1503e0 	mov	x0, x21
    c37c:	97ffe715 	bl	5fd0 <fwp_drop0>
    c380:	aa1303e0 	mov	x0, x19
    c384:	97ffe713 	bl	5fd0 <fwp_drop0>
    c388:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    c38c:	f947f400 	ldr	x0, [x0, #4072]
    c390:	f9442fe2 	ldr	x2, [sp, #2136]
    c394:	f9400001 	ldr	x1, [x0]
    c398:	eb010042 	subs	x2, x2, x1
    c39c:	d2800001 	mov	x1, #0x0                   	// #0
    c3a0:	54001f41 	b.ne	c788 <f0+0x26c8>  // b.any
    c3a4:	912183ff 	add	sp, sp, #0x860
    c3a8:	aa1403e0 	mov	x0, x20
    c3ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    c3b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c3b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    c3b8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c3bc:	a94573fb 	ldp	x27, x28, [sp, #80]
    c3c0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c3c4:	d65f03c0 	ret
    c3c8:	aa1b03e0 	mov	x0, x27
    c3cc:	97ffe191 	bl	4a10 <fwp_rc_forget_slot>
    c3d0:	17fff784 	b	a1e0 <f0+0x120>
    c3d4:	72003c5f 	tst	w2, #0xffff
    c3d8:	54fef061 	b.ne	a1e4 <f0+0x124>  // b.any
    c3dc:	17fff77e 	b	a1d4 <f0+0x114>
    c3e0:	72003c3f 	tst	w1, #0xffff
    c3e4:	54ff9de1 	b.ne	b7a0 <f0+0x16e0>  // b.any
    c3e8:	17fffce9 	b	b78c <f0+0x16cc>
    c3ec:	72003c3f 	tst	w1, #0xffff
    c3f0:	54ff97c1 	b.ne	b6e8 <f0+0x1628>  // b.any
    c3f4:	17fffcb8 	b	b6d4 <f0+0x1614>
    c3f8:	72003c3f 	tst	w1, #0xffff
    c3fc:	54ff92a1 	b.ne	b650 <f0+0x1590>  // b.any
    c400:	17fffc8f 	b	b63c <f0+0x157c>
    c404:	72003c3f 	tst	w1, #0xffff
    c408:	54ff8ba1 	b.ne	b57c <f0+0x14bc>  // b.any
    c40c:	17fffc57 	b	b568 <f0+0x14a8>
    c410:	72003c3f 	tst	w1, #0xffff
    c414:	54ff8581 	b.ne	b4c4 <f0+0x1404>  // b.any
    c418:	17fffc26 	b	b4b0 <f0+0x13f0>
    c41c:	72003c3f 	tst	w1, #0xffff
    c420:	54ff7f61 	b.ne	b40c <f0+0x134c>  // b.any
    c424:	17fffbf5 	b	b3f8 <f0+0x1338>
    c428:	72003c3f 	tst	w1, #0xffff
    c42c:	54ff7a41 	b.ne	b374 <f0+0x12b4>  // b.any
    c430:	17fffbcc 	b	b360 <f0+0x12a0>
    c434:	72003c3f 	tst	w1, #0xffff
    c438:	54ff7341 	b.ne	b2a0 <f0+0x11e0>  // b.any
    c43c:	17fffb94 	b	b28c <f0+0x11cc>
    c440:	72003c3f 	tst	w1, #0xffff
    c444:	54ff1d21 	b.ne	a7e8 <f0+0x728>  // b.any
    c448:	17fff8e3 	b	a7d4 <f0+0x714>
    c44c:	72003c3f 	tst	w1, #0xffff
    c450:	54ff1701 	b.ne	a730 <f0+0x670>  // b.any
    c454:	17fff8b2 	b	a71c <f0+0x65c>
    c458:	72003c3f 	tst	w1, #0xffff
    c45c:	54ff0d61 	b.ne	a608 <f0+0x548>  // b.any
    c460:	17fff865 	b	a5f4 <f0+0x534>
    c464:	72003c3f 	tst	w1, #0xffff
    c468:	54ff3ac1 	b.ne	abc0 <f0+0xb00>  // b.any
    c46c:	17fff9d0 	b	abac <f0+0xaec>
    c470:	72003c3f 	tst	w1, #0xffff
    c474:	54ff34a1 	b.ne	ab08 <f0+0xa48>  // b.any
    c478:	17fff99f 	b	aaf4 <f0+0xa34>
    c47c:	72003c3f 	tst	w1, #0xffff
    c480:	54ff2781 	b.ne	a970 <f0+0x8b0>  // b.any
    c484:	17fff936 	b	a95c <f0+0x89c>
    c488:	72003c3f 	tst	w1, #0xffff
    c48c:	54ff1fa1 	b.ne	a880 <f0+0x7c0>  // b.any
    c490:	17fff8f7 	b	a86c <f0+0x7ac>
    c494:	72003c3f 	tst	w1, #0xffff
    c498:	54ff6a81 	b.ne	b1e8 <f0+0x1128>  // b.any
    c49c:	17fffb4e 	b	b1d4 <f0+0x1114>
    c4a0:	72003c3f 	tst	w1, #0xffff
    c4a4:	54ff6461 	b.ne	b130 <f0+0x1070>  // b.any
    c4a8:	17fffb1d 	b	b11c <f0+0x105c>
    c4ac:	72003c3f 	tst	w1, #0xffff
    c4b0:	54ff5f41 	b.ne	b098 <f0+0xfd8>  // b.any
    c4b4:	17fffaf4 	b	b084 <f0+0xfc4>
    c4b8:	72003c3f 	tst	w1, #0xffff
    c4bc:	54ff5841 	b.ne	afc4 <f0+0xf04>  // b.any
    c4c0:	17fffabc 	b	afb0 <f0+0xef0>
    c4c4:	72003c3f 	tst	w1, #0xffff
    c4c8:	54ff5221 	b.ne	af0c <f0+0xe4c>  // b.any
    c4cc:	17fffa8b 	b	aef8 <f0+0xe38>
    c4d0:	72003c3f 	tst	w1, #0xffff
    c4d4:	54ff4c01 	b.ne	ae54 <f0+0xd94>  // b.any
    c4d8:	17fffa5a 	b	ae40 <f0+0xd80>
    c4dc:	72003c3f 	tst	w1, #0xffff
    c4e0:	54ff46e1 	b.ne	adbc <f0+0xcfc>  // b.any
    c4e4:	17fffa31 	b	ada8 <f0+0xce8>
    c4e8:	72003c3f 	tst	w1, #0xffff
    c4ec:	54ff3c61 	b.ne	ac78 <f0+0xbb8>  // b.any
    c4f0:	17fff9dd 	b	ac64 <f0+0xba4>
    c4f4:	72003c3f 	tst	w1, #0xffff
    c4f8:	54fff181 	b.ne	c328 <f0+0x2268>  // b.any
    c4fc:	17ffff86 	b	c314 <f0+0x2254>
    c500:	72003c3f 	tst	w1, #0xffff
    c504:	54ffe9a1 	b.ne	c238 <f0+0x2178>  // b.any
    c508:	17ffff47 	b	c224 <f0+0x2164>
    c50c:	72003c3f 	tst	w1, #0xffff
    c510:	54ffe481 	b.ne	c1a0 <f0+0x20e0>  // b.any
    c514:	17ffff1e 	b	c18c <f0+0x20cc>
    c518:	72003c3f 	tst	w1, #0xffff
    c51c:	54ffdf81 	b.ne	c10c <f0+0x204c>  // b.any
    c520:	17fffef6 	b	c0f8 <f0+0x2038>
    c524:	72003c3f 	tst	w1, #0xffff
    c528:	54ffd961 	b.ne	c054 <f0+0x1f94>  // b.any
    c52c:	17fffec5 	b	c040 <f0+0x1f80>
    c530:	72003c3f 	tst	w1, #0xffff
    c534:	54ffd181 	b.ne	bf64 <f0+0x1ea4>  // b.any
    c538:	17fffe86 	b	bf50 <f0+0x1e90>
    c53c:	72003c3f 	tst	w1, #0xffff
    c540:	54ffcc61 	b.ne	becc <f0+0x1e0c>  // b.any
    c544:	17fffe5d 	b	beb8 <f0+0x1df8>
    c548:	72003c3f 	tst	w1, #0xffff
    c54c:	54ffc3a1 	b.ne	bdc0 <f0+0x1d00>  // b.any
    c550:	17fffe17 	b	bdac <f0+0x1cec>
    c554:	72003c3f 	tst	w1, #0xffff
    c558:	54ffbca1 	b.ne	bcec <f0+0x1c2c>  // b.any
    c55c:	17fffddf 	b	bcd8 <f0+0x1c18>
    c560:	72003c3f 	tst	w1, #0xffff
    c564:	54ffb7a1 	b.ne	bc58 <f0+0x1b98>  // b.any
    c568:	17fffdb7 	b	bc44 <f0+0x1b84>
    c56c:	72003c3f 	tst	w1, #0xffff
    c570:	54ffb281 	b.ne	bbc0 <f0+0x1b00>  // b.any
    c574:	17fffd8e 	b	bbac <f0+0x1aec>
    c578:	72003c3f 	tst	w1, #0xffff
    c57c:	54ffad81 	b.ne	bb2c <f0+0x1a6c>  // b.any
    c580:	17fffd66 	b	bb18 <f0+0x1a58>
    c584:	72003c3f 	tst	w1, #0xffff
    c588:	54ffa5a1 	b.ne	ba3c <f0+0x197c>  // b.any
    c58c:	17fffd27 	b	ba28 <f0+0x1968>
    c590:	72003c3f 	tst	w1, #0xffff
    c594:	54ffa081 	b.ne	b9a4 <f0+0x18e4>  // b.any
    c598:	17fffcfe 	b	b990 <f0+0x18d0>
    c59c:	72003c3f 	tst	w1, #0xffff
    c5a0:	54ff9b81 	b.ne	b910 <f0+0x1850>  // b.any
    c5a4:	17fffcd6 	b	b8fc <f0+0x183c>
    c5a8:	72003c3f 	tst	w1, #0xffff
    c5ac:	54ff9561 	b.ne	b858 <f0+0x1798>  // b.any
    c5b0:	17fffca5 	b	b844 <f0+0x1784>
    c5b4:	aa1403e0 	mov	x0, x20
    c5b8:	97ffe116 	bl	4a10 <fwp_rc_forget_slot>
    c5bc:	17ffff59 	b	c320 <f0+0x2260>
    c5c0:	aa1703e0 	mov	x0, x23
    c5c4:	97ffe113 	bl	4a10 <fwp_rc_forget_slot>
    c5c8:	17fff80e 	b	a600 <f0+0x540>
    c5cc:	aa1703e0 	mov	x0, x23
    c5d0:	97ffe110 	bl	4a10 <fwp_rc_forget_slot>
    c5d4:	17fff855 	b	a728 <f0+0x668>
    c5d8:	aa1703e0 	mov	x0, x23
    c5dc:	97ffe10d 	bl	4a10 <fwp_rc_forget_slot>
    c5e0:	17fff880 	b	a7e0 <f0+0x720>
    c5e4:	aa1703e0 	mov	x0, x23
    c5e8:	97ffe10a 	bl	4a10 <fwp_rc_forget_slot>
    c5ec:	17fff8a3 	b	a878 <f0+0x7b8>
    c5f0:	aa1703e0 	mov	x0, x23
    c5f4:	97ffe107 	bl	4a10 <fwp_rc_forget_slot>
    c5f8:	17fff8dc 	b	a968 <f0+0x8a8>
    c5fc:	aa1703e0 	mov	x0, x23
    c600:	97ffe104 	bl	4a10 <fwp_rc_forget_slot>
    c604:	17fff93f 	b	ab00 <f0+0xa40>
    c608:	aa1703e0 	mov	x0, x23
    c60c:	97ffe101 	bl	4a10 <fwp_rc_forget_slot>
    c610:	17fff96a 	b	abb8 <f0+0xaf8>
    c614:	aa1503e0 	mov	x0, x21
    c618:	97ffe0fe 	bl	4a10 <fwp_rc_forget_slot>
    c61c:	17fff995 	b	ac70 <f0+0xbb0>
    c620:	aa1703e0 	mov	x0, x23
    c624:	97ffe0fb 	bl	4a10 <fwp_rc_forget_slot>
    c628:	17fff9e3 	b	adb4 <f0+0xcf4>
    c62c:	aa1703e0 	mov	x0, x23
    c630:	97ffe0f8 	bl	4a10 <fwp_rc_forget_slot>
    c634:	17fffa06 	b	ae4c <f0+0xd8c>
    c638:	aa1703e0 	mov	x0, x23
    c63c:	97ffe0f5 	bl	4a10 <fwp_rc_forget_slot>
    c640:	17fffa31 	b	af04 <f0+0xe44>
    c644:	aa1703e0 	mov	x0, x23
    c648:	97ffe0f2 	bl	4a10 <fwp_rc_forget_slot>
    c64c:	17fffa5c 	b	afbc <f0+0xefc>
    c650:	aa1703e0 	mov	x0, x23
    c654:	97ffe0ef 	bl	4a10 <fwp_rc_forget_slot>
    c658:	17fffa8e 	b	b090 <f0+0xfd0>
    c65c:	aa1703e0 	mov	x0, x23
    c660:	97ffe0ec 	bl	4a10 <fwp_rc_forget_slot>
    c664:	17fffab1 	b	b128 <f0+0x1068>
    c668:	aa1703e0 	mov	x0, x23
    c66c:	97ffe0e9 	bl	4a10 <fwp_rc_forget_slot>
    c670:	17fffadc 	b	b1e0 <f0+0x1120>
    c674:	aa1703e0 	mov	x0, x23
    c678:	97ffe0e6 	bl	4a10 <fwp_rc_forget_slot>
    c67c:	17fffb07 	b	b298 <f0+0x11d8>
    c680:	aa1703e0 	mov	x0, x23
    c684:	97ffe0e3 	bl	4a10 <fwp_rc_forget_slot>
    c688:	17fffb39 	b	b36c <f0+0x12ac>
    c68c:	aa1703e0 	mov	x0, x23
    c690:	97ffe0e0 	bl	4a10 <fwp_rc_forget_slot>
    c694:	17fffb5c 	b	b404 <f0+0x1344>
    c698:	aa1703e0 	mov	x0, x23
    c69c:	97ffe0dd 	bl	4a10 <fwp_rc_forget_slot>
    c6a0:	17fffb87 	b	b4bc <f0+0x13fc>
    c6a4:	aa1703e0 	mov	x0, x23
    c6a8:	97ffe0da 	bl	4a10 <fwp_rc_forget_slot>
    c6ac:	17fffbb2 	b	b574 <f0+0x14b4>
    c6b0:	aa1703e0 	mov	x0, x23
    c6b4:	97ffe0d7 	bl	4a10 <fwp_rc_forget_slot>
    c6b8:	17fffbe4 	b	b648 <f0+0x1588>
    c6bc:	aa1703e0 	mov	x0, x23
    c6c0:	97ffe0d4 	bl	4a10 <fwp_rc_forget_slot>
    c6c4:	17fffc07 	b	b6e0 <f0+0x1620>
    c6c8:	aa1703e0 	mov	x0, x23
    c6cc:	97ffe0d1 	bl	4a10 <fwp_rc_forget_slot>
    c6d0:	17fffc32 	b	b798 <f0+0x16d8>
    c6d4:	aa1703e0 	mov	x0, x23
    c6d8:	97ffe0ce 	bl	4a10 <fwp_rc_forget_slot>
    c6dc:	17fffc5d 	b	b850 <f0+0x1790>
    c6e0:	aa1703e0 	mov	x0, x23
    c6e4:	97ffe0cb 	bl	4a10 <fwp_rc_forget_slot>
    c6e8:	17fffc88 	b	b908 <f0+0x1848>
    c6ec:	aa1703e0 	mov	x0, x23
    c6f0:	97ffe0c8 	bl	4a10 <fwp_rc_forget_slot>
    c6f4:	17fffcaa 	b	b99c <f0+0x18dc>
    c6f8:	aa1703e0 	mov	x0, x23
    c6fc:	97ffe0c5 	bl	4a10 <fwp_rc_forget_slot>
    c700:	17fffccd 	b	ba34 <f0+0x1974>
    c704:	aa1703e0 	mov	x0, x23
    c708:	97ffe0c2 	bl	4a10 <fwp_rc_forget_slot>
    c70c:	17fffd06 	b	bb24 <f0+0x1a64>
    c710:	aa1703e0 	mov	x0, x23
    c714:	97ffe0bf 	bl	4a10 <fwp_rc_forget_slot>
    c718:	17fffd28 	b	bbb8 <f0+0x1af8>
    c71c:	aa1703e0 	mov	x0, x23
    c720:	97ffe0bc 	bl	4a10 <fwp_rc_forget_slot>
    c724:	17fffd4b 	b	bc50 <f0+0x1b90>
    c728:	aa1703e0 	mov	x0, x23
    c72c:	97ffe0b9 	bl	4a10 <fwp_rc_forget_slot>
    c730:	17fffd6d 	b	bce4 <f0+0x1c24>
    c734:	aa1703e0 	mov	x0, x23
    c738:	97ffe0b6 	bl	4a10 <fwp_rc_forget_slot>
    c73c:	17fffd9f 	b	bdb8 <f0+0x1cf8>
    c740:	aa1703e0 	mov	x0, x23
    c744:	97ffe0b3 	bl	4a10 <fwp_rc_forget_slot>
    c748:	17fffddf 	b	bec4 <f0+0x1e04>
    c74c:	aa1703e0 	mov	x0, x23
    c750:	97ffe0b0 	bl	4a10 <fwp_rc_forget_slot>
    c754:	17fffe02 	b	bf5c <f0+0x1e9c>
    c758:	aa1703e0 	mov	x0, x23
    c75c:	97ffe0ad 	bl	4a10 <fwp_rc_forget_slot>
    c760:	17fffe3b 	b	c04c <f0+0x1f8c>
    c764:	aa1703e0 	mov	x0, x23
    c768:	97ffe0aa 	bl	4a10 <fwp_rc_forget_slot>
    c76c:	17fffe66 	b	c104 <f0+0x2044>
    c770:	aa1703e0 	mov	x0, x23
    c774:	97ffe0a7 	bl	4a10 <fwp_rc_forget_slot>
    c778:	17fffe88 	b	c198 <f0+0x20d8>
    c77c:	aa1703e0 	mov	x0, x23
    c780:	97ffe0a4 	bl	4a10 <fwp_rc_forget_slot>
    c784:	17fffeab 	b	c230 <f0+0x2170>
    c788:	97ffd846 	bl	28a0 <__stack_chk_fail@plt>
    c78c:	d503201f 	nop

000000000000c790 <fwp_main_thread>:
    c790:	d10443ff 	sub	sp, sp, #0x110
    c794:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    c798:	f947f400 	ldr	x0, [x0, #4072]
    c79c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c7a0:	910303fd 	add	x29, sp, #0xc0
    c7a4:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c7a8:	b0000376 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    c7ac:	9118c2c1 	add	x1, x22, #0x630
    c7b0:	a90d53f3 	stp	x19, x20, [sp, #208]
    c7b4:	a90f63f7 	stp	x23, x24, [sp, #240]
    c7b8:	b953a421 	ldr	w1, [x1, #5028]
    c7bc:	a9106bf9 	stp	x25, x26, [sp, #256]
    c7c0:	f9400002 	ldr	x2, [x0]
    c7c4:	f9005fe2 	str	x2, [sp, #184]
    c7c8:	d2800002 	mov	x2, #0x0                   	// #0
    c7cc:	34002961 	cbz	w1, ccf8 <fwp_main_thread+0x568>
    c7d0:	9118c2c0 	add	x0, x22, #0x630
    c7d4:	b953a800 	ldr	w0, [x0, #5032]
    c7d8:	35002880 	cbnz	w0, cce8 <fwp_main_thread+0x558>
    c7dc:	91001fe2 	add	x2, sp, #0x7
    c7e0:	900000b5 	adrp	x21, 20000 <__data_start>
    c7e4:	900000a3 	adrp	x3, 20000 <__data_start>
    c7e8:	910142b3 	add	x19, x21, #0x50
    c7ec:	91114063 	add	x3, x3, #0x450
    c7f0:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c7f4:	d2a00025 	mov	x5, #0x10000               	// #65536
    c7f8:	910023e0 	add	x0, sp, #0x8
    c7fc:	d2800001 	mov	x1, #0x0                   	// #0
    c800:	f90007e3 	str	x3, [sp, #8]
    c804:	b90013ff 	str	wzr, [sp, #16]
    c808:	f9000fe5 	str	x5, [sp, #24]
    c80c:	a90a1262 	stp	x2, x4, [x19, #160]
    c810:	97ffd7bc 	bl	2700 <sigaltstack@plt>
    c814:	350028a0 	cbnz	w0, cd28 <fwp_main_thread+0x598>
    c818:	4f000400 	movi	v0.4s, #0x0
    c81c:	9100a3e0 	add	x0, sp, #0x28
    c820:	f0ffffa1 	adrp	x1, 3000 <ad_raw_record+0x70>
    c824:	52800082 	mov	w2, #0x4                   	// #4
    c828:	9102c021 	add	x1, x1, #0xb0
    c82c:	72a10002 	movk	w2, #0x800, lsl #16
    c830:	910083f4 	add	x20, sp, #0x20
    c834:	f90013e1 	str	x1, [sp, #32]
    c838:	3d802000 	str	q0, [x0, #128]
    c83c:	b900abe2 	str	w2, [sp, #168]
    c840:	ad000000 	stp	q0, q0, [x0]
    c844:	ad010000 	stp	q0, q0, [x0, #32]
    c848:	ad020000 	stp	q0, q0, [x0, #64]
    c84c:	ad030000 	stp	q0, q0, [x0, #96]
    c850:	97ffd804 	bl	2860 <sigemptyset@plt>
    c854:	350026a0 	cbnz	w0, cd28 <fwp_main_thread+0x598>
    c858:	aa1403e1 	mov	x1, x20
    c85c:	d2800002 	mov	x2, #0x0                   	// #0
    c860:	52800160 	mov	w0, #0xb                   	// #11
    c864:	97ffd817 	bl	28c0 <sigaction@plt>
    c868:	35002600 	cbnz	w0, cd28 <fwp_main_thread+0x598>
    c86c:	aa1403e1 	mov	x1, x20
    c870:	d2800002 	mov	x2, #0x0                   	// #0
    c874:	528000e0 	mov	w0, #0x7                   	// #7
    c878:	97ffd812 	bl	28c0 <sigaction@plt>
    c87c:	35002560 	cbnz	w0, cd28 <fwp_main_thread+0x598>
    c880:	9118c2c1 	add	x1, x22, #0x630
    c884:	52800034 	mov	w20, #0x1                   	// #1
    c888:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    c88c:	910ec000 	add	x0, x0, #0x3b0
    c890:	b9013274 	str	w20, [x19, #304]
    c894:	fd4a1020 	ldr	d0, [x1, #5152]
    c898:	7e61d800 	ucvtf	d0, d0
    c89c:	fd00a660 	str	d0, [x19, #328]
    c8a0:	940002e8 	bl	d440 <atexit>
    c8a4:	35002480 	cbnz	w0, cd34 <fwp_main_thread+0x5a4>
    c8a8:	b943ca60 	ldr	w0, [x19, #968]
    c8ac:	340022a0 	cbz	w0, cd00 <fwp_main_thread+0x570>
    c8b0:	910142ba 	add	x26, x21, #0x50
    c8b4:	f9404f54 	ldr	x20, [x26, #152]
    c8b8:	b40010b4 	cbz	x20, cacc <fwp_main_thread+0x33c>
    c8bc:	aa1403f3 	mov	x19, x20
    c8c0:	91010297 	add	x23, x20, #0x40
    c8c4:	39414a99 	ldrb	w25, [x20, #82]
    c8c8:	52800038 	mov	w24, #0x1                   	// #1
    c8cc:	39014a98 	strb	w24, [x20, #82]
    c8d0:	f9401680 	ldr	x0, [x20, #40]
    c8d4:	b4000620 	cbz	x0, c998 <fwp_main_thread+0x208>
    c8d8:	f9403281 	ldr	x1, [x20, #96]
    c8dc:	39414680 	ldrb	w0, [x20, #81]
    c8e0:	b4000b41 	cbz	x1, ca48 <fwp_main_thread+0x2b8>
    c8e4:	36000a80 	tbz	w0, #0, ca34 <fwp_main_thread+0x2a4>
    c8e8:	39414a62 	ldrb	w2, [x19, #82]
    c8ec:	f9402280 	ldr	x0, [x20, #64]
    c8f0:	37000d62 	tbnz	w2, #0, ca9c <fwp_main_thread+0x30c>
    c8f4:	f9403261 	ldr	x1, [x19, #96]
    c8f8:	a911fe77 	stp	x23, xzr, [x19, #280]
    c8fc:	f9009660 	str	x0, [x19, #296]
    c900:	b4000040 	cbz	x0, c908 <fwp_main_thread+0x178>
    c904:	f9009013 	str	x19, [x0, #288]
    c908:	f9002293 	str	x19, [x20, #64]
    c90c:	b4000101 	cbz	x1, c92c <fwp_main_thread+0x19c>
    c910:	f9409740 	ldr	x0, [x26, #296]
    c914:	39015678 	strb	w24, [x19, #85]
    c918:	f9003661 	str	x1, [x19, #104]
    c91c:	a910827f 	stp	xzr, x0, [x19, #264]
    c920:	b4000040 	cbz	x0, c928 <fwp_main_thread+0x198>
    c924:	f9008413 	str	x19, [x0, #264]
    c928:	f9009753 	str	x19, [x26, #296]
    c92c:	39015a7f 	strb	wzr, [x19, #86]
    c930:	97ffe875 	bl	6b04 <fwp_block>
    c934:	f9408e62 	ldr	x2, [x19, #280]
    c938:	b4000142 	cbz	x2, c960 <fwp_main_thread+0x1d0>
    c93c:	a9520261 	ldp	x1, x0, [x19, #288]
    c940:	b4000ba1 	cbz	x1, cab4 <fwp_main_thread+0x324>
    c944:	f9009420 	str	x0, [x1, #296]
    c948:	f9409660 	ldr	x0, [x19, #296]
    c94c:	b4000040 	cbz	x0, c954 <fwp_main_thread+0x1c4>
    c950:	f9009001 	str	x1, [x0, #288]
    c954:	91080260 	add	x0, x19, #0x200
    c958:	f900967f 	str	xzr, [x19, #296]
    c95c:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c960:	39415660 	ldrb	w0, [x19, #85]
    c964:	f9404f42 	ldr	x2, [x26, #152]
    c968:	36000960 	tbz	w0, #0, ca94 <fwp_main_thread+0x304>
    c96c:	a9508261 	ldp	x1, x0, [x19, #264]
    c970:	b4000a61 	cbz	x1, cabc <fwp_main_thread+0x32c>
    c974:	f9008820 	str	x0, [x1, #272]
    c978:	b4000040 	cbz	x0, c980 <fwp_main_thread+0x1f0>
    c97c:	f9008401 	str	x1, [x0, #264]
    c980:	91080260 	add	x0, x19, #0x200
    c984:	3901567f 	strb	wzr, [x19, #85]
    c988:	aa0203f3 	mov	x19, x2
    c98c:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c990:	f9401680 	ldr	x0, [x20, #40]
    c994:	b5fffa20 	cbnz	x0, c8d8 <fwp_main_thread+0x148>
    c998:	910142a0 	add	x0, x21, #0x50
    c99c:	39014a99 	strb	w25, [x20, #82]
    c9a0:	f941d400 	ldr	x0, [x0, #936]
    c9a4:	b4001840 	cbz	x0, ccac <fwp_main_thread+0x51c>
    c9a8:	910142a0 	add	x0, x21, #0x50
    c9ac:	f941f001 	ldr	x1, [x0, #992]
    c9b0:	b903d81f 	str	wzr, [x0, #984]
    c9b4:	eb13003f 	cmp	x1, x19
    c9b8:	54001961 	b.ne	cce4 <fwp_main_thread+0x554>  // b.any
    c9bc:	b4000933 	cbz	x19, cae0 <fwp_main_thread+0x350>
    c9c0:	910142a0 	add	x0, x21, #0x50
    c9c4:	52800021 	mov	w1, #0x1                   	// #1
    c9c8:	39014a61 	strb	w1, [x19, #82]
    c9cc:	f941c005 	ldr	x5, [x0, #896]
    c9d0:	b4000885 	cbz	x5, cae0 <fwp_main_thread+0x350>
    c9d4:	d503201f 	nop
    c9d8:	394140a0 	ldrb	w0, [x5, #80]
    c9dc:	37000060 	tbnz	w0, #0, c9e8 <fwp_main_thread+0x258>
    c9e0:	aa0503e0 	mov	x0, x5
    c9e4:	97ffdb43 	bl	36f0 <fwp_cancel_tree.part.0>
    c9e8:	f9409ca5 	ldr	x5, [x5, #312]
    c9ec:	b5ffff65 	cbnz	x5, c9d8 <fwp_main_thread+0x248>
    c9f0:	910142b4 	add	x20, x21, #0x50
    c9f4:	52800037 	mov	w23, #0x1                   	// #1
    c9f8:	f9402a60 	ldr	x0, [x19, #80]
    c9fc:	f2001c1f 	tst	x0, #0xff000000ff
    ca00:	540000e1 	b.ne	ca1c <fwp_main_thread+0x28c>  // b.any
    ca04:	f9406280 	ldr	x0, [x20, #192]
    ca08:	39015277 	strb	w23, [x19, #84]
    ca0c:	f900827f 	str	xzr, [x19, #256]
    ca10:	b40005a0 	cbz	x0, cac4 <fwp_main_thread+0x334>
    ca14:	f9008013 	str	x19, [x0, #256]
    ca18:	f9006293 	str	x19, [x20, #192]
    ca1c:	97ffe83a 	bl	6b04 <fwp_block>
    ca20:	97ffe7cc 	bl	6950 <fwp_free_zombie>
    ca24:	f941c280 	ldr	x0, [x20, #896]
    ca28:	b40005c0 	cbz	x0, cae0 <fwp_main_thread+0x350>
    ca2c:	f941f293 	ldr	x19, [x20, #992]
    ca30:	17fffff2 	b	c9f8 <fwp_main_thread+0x268>
    ca34:	97ffdbd3 	bl	3980 <fwp_now_ns>
    ca38:	f9403281 	ldr	x1, [x20, #96]
    ca3c:	eb01001f 	cmp	x0, x1
    ca40:	5400128a 	b.ge	cc90 <fwp_main_thread+0x500>  // b.tcont
    ca44:	39414680 	ldrb	w0, [x20, #81]
    ca48:	39414a62 	ldrb	w2, [x19, #82]
    ca4c:	3707f500 	tbnz	w0, #0, c8ec <fwp_main_thread+0x15c>
    ca50:	f9403281 	ldr	x1, [x20, #96]
    ca54:	370001c2 	tbnz	w2, #0, ca8c <fwp_main_thread+0x2fc>
    ca58:	f9403260 	ldr	x0, [x19, #96]
    ca5c:	b4000180 	cbz	x0, ca8c <fwp_main_thread+0x2fc>
    ca60:	b4000061 	cbz	x1, ca6c <fwp_main_thread+0x2dc>
    ca64:	eb01001f 	cmp	x0, x1
    ca68:	9a81d000 	csel	x0, x0, x1, le
    ca6c:	f9402281 	ldr	x1, [x20, #64]
    ca70:	a911fe77 	stp	x23, xzr, [x19, #280]
    ca74:	f9009661 	str	x1, [x19, #296]
    ca78:	b40014c1 	cbz	x1, cd10 <fwp_main_thread+0x580>
    ca7c:	f9009033 	str	x19, [x1, #288]
    ca80:	aa0003e1 	mov	x1, x0
    ca84:	f9002293 	str	x19, [x20, #64]
    ca88:	17ffffa2 	b	c910 <fwp_main_thread+0x180>
    ca8c:	f9402280 	ldr	x0, [x20, #64]
    ca90:	17ffff9a 	b	c8f8 <fwp_main_thread+0x168>
    ca94:	aa0203f3 	mov	x19, x2
    ca98:	17ffff8e 	b	c8d0 <fwp_main_thread+0x140>
    ca9c:	a911fe77 	stp	x23, xzr, [x19, #280]
    caa0:	f9009660 	str	x0, [x19, #296]
    caa4:	b4000040 	cbz	x0, caac <fwp_main_thread+0x31c>
    caa8:	f9009013 	str	x19, [x0, #288]
    caac:	f9002293 	str	x19, [x20, #64]
    cab0:	17ffff9f 	b	c92c <fwp_main_thread+0x19c>
    cab4:	f9000040 	str	x0, [x2]
    cab8:	17ffffa5 	b	c94c <fwp_main_thread+0x1bc>
    cabc:	f9009740 	str	x0, [x26, #296]
    cac0:	17ffffae 	b	c978 <fwp_main_thread+0x1e8>
    cac4:	f9006693 	str	x19, [x20, #200]
    cac8:	17ffffd4 	b	ca18 <fwp_main_thread+0x288>
    cacc:	f941d740 	ldr	x0, [x26, #936]
    cad0:	b4000ec0 	cbz	x0, cca8 <fwp_main_thread+0x518>
    cad4:	f941f340 	ldr	x0, [x26, #992]
    cad8:	b903db5f 	str	wzr, [x26, #984]
    cadc:	b5001040 	cbnz	x0, cce4 <fwp_main_thread+0x554>
    cae0:	910142b4 	add	x20, x21, #0x50
    cae4:	97ffe79b 	bl	6950 <fwp_free_zombie>
    cae8:	f9406680 	ldr	x0, [x20, #200]
    caec:	b5000fc0 	cbnz	x0, cce4 <fwp_main_thread+0x554>
    caf0:	f9409680 	ldr	x0, [x20, #296]
    caf4:	b5000f80 	cbnz	x0, cce4 <fwp_main_thread+0x554>
    caf8:	b9417293 	ldr	w19, [x20, #368]
    cafc:	340001d3 	cbz	w19, cb34 <fwp_main_thread+0x3a4>
    cb00:	93407e77 	sxtw	x23, w19
    cb04:	51000673 	sub	w19, w19, #0x1
    cb08:	d1000af7 	sub	x23, x23, #0x2
    cb0c:	91060298 	add	x24, x20, #0x180
    cb10:	cb3342f7 	sub	x23, x23, w19, uxtw
    cb14:	93407e73 	sxtw	x19, w19
    cb18:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    cb1c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cb20:	b9017293 	str	w19, [x20, #368]
    cb24:	d1000673 	sub	x19, x19, #0x1
    cb28:	97ffd7a6 	bl	29c0 <munmap@plt>
    cb2c:	eb1302ff 	cmp	x23, x19
    cb30:	54ffff41 	b.ne	cb18 <fwp_main_thread+0x388>  // b.any
    cb34:	900000b3 	adrp	x19, 20000 <__data_start>
    cb38:	91004260 	add	x0, x19, #0x10
    cb3c:	b9402800 	ldr	w0, [x0, #40]
    cb40:	37f80040 	tbnz	w0, #31, cb48 <fwp_main_thread+0x3b8>
    cb44:	97ffd75b 	bl	28b0 <close@plt>
    cb48:	910142a0 	add	x0, x21, #0x50
    cb4c:	91004261 	add	x1, x19, #0x10
    cb50:	12800002 	mov	w2, #0xffffffff            	// #-1
    cb54:	d2800013 	mov	x19, #0x0                   	// #0
    cb58:	f941f417 	ldr	x23, [x0, #1000]
    cb5c:	b9002822 	str	w2, [x1, #40]
    cb60:	f941f814 	ldr	x20, [x0, #1008]
    cb64:	b4000177 	cbz	x23, cb90 <fwp_main_thread+0x400>
    cb68:	f8737a80 	ldr	x0, [x20, x19, lsl #3]
    cb6c:	b40000c0 	cbz	x0, cb84 <fwp_main_thread+0x3f4>
    cb70:	f9400001 	ldr	x1, [x0]
    cb74:	b5000b81 	cbnz	x1, cce4 <fwp_main_thread+0x554>
    cb78:	f9400401 	ldr	x1, [x0, #8]
    cb7c:	b5000b41 	cbnz	x1, cce4 <fwp_main_thread+0x554>
    cb80:	97ffe044 	bl	4c90 <fwp_mem_free>
    cb84:	91000673 	add	x19, x19, #0x1
    cb88:	eb1302ff 	cmp	x23, x19
    cb8c:	54fffee1 	b.ne	cb68 <fwp_main_thread+0x3d8>  // b.any
    cb90:	aa1403e0 	mov	x0, x20
    cb94:	97ffe03f 	bl	4c90 <fwp_mem_free>
    cb98:	910142a0 	add	x0, x21, #0x50
    cb9c:	f941f013 	ldr	x19, [x0, #992]
    cba0:	f901f41f 	str	xzr, [x0, #1000]
    cba4:	f901f81f 	str	xzr, [x0, #1008]
    cba8:	b40001f3 	cbz	x19, cbe4 <fwp_main_thread+0x454>
    cbac:	f9401661 	ldr	x1, [x19, #40]
    cbb0:	b50009a1 	cbnz	x1, cce4 <fwp_main_thread+0x554>
    cbb4:	f9405661 	ldr	x1, [x19, #168]
    cbb8:	b5000961 	cbnz	x1, cce4 <fwp_main_thread+0x554>
    cbbc:	f941d401 	ldr	x1, [x0, #936]
    cbc0:	b5000921 	cbnz	x1, cce4 <fwp_main_thread+0x554>
    cbc4:	f941dc00 	ldr	x0, [x0, #952]
    cbc8:	b50008e0 	cbnz	x0, cce4 <fwp_main_thread+0x554>
    cbcc:	d2823a02 	mov	x2, #0x11d0                	// #4560
    cbd0:	90000360 	adrp	x0, 78000 <ad_raw_blocks+0x17bb0>
    cbd4:	91114000 	add	x0, x0, #0x450
    cbd8:	97ffd726 	bl	2870 <memset@plt>
    cbdc:	aa1303e0 	mov	x0, x19
    cbe0:	97ffe02c 	bl	4c90 <fwp_mem_free>
    cbe4:	910142a6 	add	x6, x21, #0x50
    cbe8:	9118c2d6 	add	x22, x22, #0x630
    cbec:	3dc016a1 	ldr	q1, [x21, #80]
    cbf0:	52800041 	mov	w1, #0x2                   	// #2
    cbf4:	3dc004c2 	ldr	q2, [x6, #16]
    cbf8:	b0000002 	adrp	x2, d000 <__divti3+0x2b0>
    cbfc:	fd4a12c0 	ldr	d0, [x22, #5152]
    cc00:	9132a042 	add	x2, x2, #0xca8
    cc04:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    cc08:	fd40a4c1 	ldr	d1, [x6, #328]
    cc0c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cc10:	f947e800 	ldr	x0, [x0, #4048]
    cc14:	7e61d800 	ucvtf	d0, d0
    cc18:	a95390c3 	ldp	x3, x4, [x6, #312]
    cc1c:	f9004cdf 	str	xzr, [x6, #152]
    cc20:	f9400000 	ldr	x0, [x0]
    cc24:	1e613801 	fsub	d1, d0, d1
    cc28:	f940acc5 	ldr	x5, [x6, #344]
    cc2c:	b90130df 	str	wzr, [x6, #304]
    cc30:	5ef1b842 	addp	d2, v2.2d
    cc34:	fd40a8c0 	ldr	d0, [x6, #336]
    cc38:	f901f0df 	str	xzr, [x6, #992]
    cc3c:	fd0058c2 	str	d2, [x6, #176]
    cc40:	97ffd734 	bl	2910 <__fprintf_chk@plt>
    cc44:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cc48:	f947ec00 	ldr	x0, [x0, #4056]
    cc4c:	f9400000 	ldr	x0, [x0]
    cc50:	97ffd760 	bl	29d0 <fflush@plt>
    cc54:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cc58:	f947f400 	ldr	x0, [x0, #4072]
    cc5c:	f9405fe2 	ldr	x2, [sp, #184]
    cc60:	f9400001 	ldr	x1, [x0]
    cc64:	eb010042 	subs	x2, x2, x1
    cc68:	d2800001 	mov	x1, #0x0                   	// #0
    cc6c:	540006a1 	b.ne	cd40 <fwp_main_thread+0x5b0>  // b.any
    cc70:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cc74:	d2800000 	mov	x0, #0x0                   	// #0
    cc78:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cc7c:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cc80:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cc84:	a9506bf9 	ldp	x25, x26, [sp, #256]
    cc88:	910443ff 	add	sp, sp, #0x110
    cc8c:	d65f03c0 	ret
    cc90:	39414280 	ldrb	w0, [x20, #80]
    cc94:	3707ed80 	tbnz	w0, #0, ca44 <fwp_main_thread+0x2b4>
    cc98:	aa1403e0 	mov	x0, x20
    cc9c:	97ffda95 	bl	36f0 <fwp_cancel_tree.part.0>
    cca0:	39414680 	ldrb	w0, [x20, #81]
    cca4:	17ffff69 	b	ca48 <fwp_main_thread+0x2b8>
    cca8:	d2800013 	mov	x19, #0x0                   	// #0
    ccac:	910142b4 	add	x20, x21, #0x50
    ccb0:	f941de80 	ldr	x0, [x20, #952]
    ccb4:	b5ffe7a0 	cbnz	x0, c9a8 <fwp_main_thread+0x218>
    ccb8:	f941d280 	ldr	x0, [x20, #928]
    ccbc:	97ffdff5 	bl	4c90 <fwp_mem_free>
    ccc0:	f901d29f 	str	xzr, [x20, #928]
    ccc4:	f901da9f 	str	xzr, [x20, #944]
    ccc8:	f941f280 	ldr	x0, [x20, #992]
    cccc:	b4000293 	cbz	x19, cd1c <fwp_main_thread+0x58c>
    ccd0:	f900567f 	str	xzr, [x19, #168]
    ccd4:	f9005e7f 	str	xzr, [x19, #184]
    ccd8:	b903da9f 	str	wzr, [x20, #984]
    ccdc:	eb13001f 	cmp	x0, x19
    cce0:	54ffe700 	b.eq	c9c0 <fwp_main_thread+0x230>  // b.none
    cce4:	97ffd703 	bl	28f0 <abort@plt>
    cce8:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    ccec:	913e8000 	add	x0, x0, #0xfa0
    ccf0:	940001d4 	bl	d440 <atexit>
    ccf4:	17fffeba 	b	c7dc <fwp_main_thread+0x4c>
    ccf8:	97ffdd03 	bl	4104 <fwp_heap_init>
    ccfc:	17fffeb5 	b	c7d0 <fwp_main_thread+0x40>
    cd00:	97fff4f0 	bl	a0c0 <f0>
    cd04:	b903ca74 	str	w20, [x19, #968]
    cd08:	f901ea60 	str	x0, [x19, #976]
    cd0c:	17fffee9 	b	c8b0 <fwp_main_thread+0x120>
    cd10:	aa0003e1 	mov	x1, x0
    cd14:	f9002293 	str	x19, [x20, #64]
    cd18:	17fffefe 	b	c910 <fwp_main_thread+0x180>
    cd1c:	b903da9f 	str	wzr, [x20, #984]
    cd20:	b4ffee00 	cbz	x0, cae0 <fwp_main_thread+0x350>
    cd24:	97ffd6f3 	bl	28f0 <abort@plt>
    cd28:	b0000000 	adrp	x0, d000 <__divti3+0x2b0>
    cd2c:	91318000 	add	x0, x0, #0xc60
    cd30:	97ffdab4 	bl	3800 <fwp_trap>
    cd34:	b0000000 	adrp	x0, d000 <__divti3+0x2b0>
    cd38:	91322000 	add	x0, x0, #0xc88
    cd3c:	97ffd991 	bl	3380 <ad_raw_fail>
    cd40:	97ffd6d8 	bl	28a0 <__stack_chk_fail@plt>
    cd44:	d503201f 	nop
    cd48:	d503201f 	nop
    cd4c:	d503201f 	nop

000000000000cd50 <__divti3>:
    cd50:	d503245f 	bti	c
    cd54:	d2800004 	mov	x4, #0x0                   	// #0
    cd58:	b7f80721 	tbnz	x1, #63, ce3c <__divti3+0xec>
    cd5c:	b6f80083 	tbz	x3, #63, cd6c <__divti3+0x1c>
    cd60:	eb0203e2 	negs	x2, x2
    cd64:	aa2403e4 	mvn	x4, x4
    cd68:	da0303e3 	ngc	x3, x3
    cd6c:	aa0203e6 	mov	x6, x2
    cd70:	aa0003e7 	mov	x7, x0
    cd74:	aa0103e5 	mov	x5, x1
    cd78:	b5000583 	cbnz	x3, ce28 <__divti3+0xd8>
    cd7c:	eb01005f 	cmp	x2, x1
    cd80:	54000e69 	b.ls	cf4c <__divti3+0x1fc>  // b.plast
    cd84:	dac01040 	clz	x0, x2
    cd88:	b40000e0 	cbz	x0, cda4 <__divti3+0x54>
    cd8c:	4b0003e1 	neg	w1, w0
    cd90:	9ac020a5 	lsl	x5, x5, x0
    cd94:	9ac02046 	lsl	x6, x2, x0
    cd98:	9ac124e1 	lsr	x1, x7, x1
    cd9c:	aa050025 	orr	x5, x1, x5
    cda0:	9ac020e7 	lsl	x7, x7, x0
    cda4:	d360fcc8 	lsr	x8, x6, #32
    cda8:	92407cc2 	and	x2, x6, #0xffffffff
    cdac:	9ac808a3 	udiv	x3, x5, x8
    cdb0:	9b089465 	msub	x5, x3, x8, x5
    cdb4:	aa0303e0 	mov	x0, x3
    cdb8:	9b037c41 	mul	x1, x2, x3
    cdbc:	93c780a5 	extr	x5, x5, x7, #32
    cdc0:	eb05003f 	cmp	x1, x5
    cdc4:	540000a9 	b.ls	cdd8 <__divti3+0x88>  // b.plast
    cdc8:	ab0500c5 	adds	x5, x6, x5
    cdcc:	d1000460 	sub	x0, x3, #0x1
    cdd0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    cdd4:	540015a8 	b.hi	d088 <__divti3+0x338>  // b.pmore
    cdd8:	cb0100a5 	sub	x5, x5, x1
    cddc:	9ac808a3 	udiv	x3, x5, x8
    cde0:	9b089465 	msub	x5, x3, x8, x5
    cde4:	aa0303e1 	mov	x1, x3
    cde8:	9b037c42 	mul	x2, x2, x3
    cdec:	aa0703e3 	mov	x3, x7
    cdf0:	b3607ca3 	bfi	x3, x5, #32, #32
    cdf4:	eb03005f 	cmp	x2, x3
    cdf8:	540000c9 	b.ls	ce10 <__divti3+0xc0>  // b.plast
    cdfc:	ab0300c3 	adds	x3, x6, x3
    ce00:	d1000425 	sub	x5, x1, #0x1
    ce04:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ce08:	d1000821 	sub	x1, x1, #0x2
    ce0c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    ce10:	aa008020 	orr	x0, x1, x0, lsl #32
    ce14:	d2800001 	mov	x1, #0x0                   	// #0
    ce18:	b4000064 	cbz	x4, ce24 <__divti3+0xd4>
    ce1c:	eb0003e0 	negs	x0, x0
    ce20:	da0103e1 	ngc	x1, x1
    ce24:	d65f03c0 	ret
    ce28:	eb01007f 	cmp	x3, x1
    ce2c:	54000109 	b.ls	ce4c <__divti3+0xfc>  // b.plast
    ce30:	d2800001 	mov	x1, #0x0                   	// #0
    ce34:	d2800000 	mov	x0, #0x0                   	// #0
    ce38:	17fffff8 	b	ce18 <__divti3+0xc8>
    ce3c:	eb0003e0 	negs	x0, x0
    ce40:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ce44:	da0103e1 	ngc	x1, x1
    ce48:	17ffffc5 	b	cd5c <__divti3+0xc>
    ce4c:	dac01067 	clz	x7, x3
    ce50:	b40010e7 	cbz	x7, d06c <__divti3+0x31c>
    ce54:	d2800805 	mov	x5, #0x40                  	// #64
    ce58:	cb0700a5 	sub	x5, x5, x7
    ce5c:	9ac72063 	lsl	x3, x3, x7
    ce60:	9ac52448 	lsr	x8, x2, x5
    ce64:	aa030108 	orr	x8, x8, x3
    ce68:	9ac52426 	lsr	x6, x1, x5
    ce6c:	92407d0a 	and	x10, x8, #0xffffffff
    ce70:	d360fd09 	lsr	x9, x8, #32
    ce74:	9ac52403 	lsr	x3, x0, x5
    ce78:	9ac72021 	lsl	x1, x1, x7
    ce7c:	aa010063 	orr	x3, x3, x1
    ce80:	9ac72042 	lsl	x2, x2, x7
    ce84:	9ac908cb 	udiv	x11, x6, x9
    ce88:	9b099965 	msub	x5, x11, x9, x6
    ce8c:	aa0b03e1 	mov	x1, x11
    ce90:	9b0b7d46 	mul	x6, x10, x11
    ce94:	93c380a5 	extr	x5, x5, x3, #32
    ce98:	eb0500df 	cmp	x6, x5
    ce9c:	540000a9 	b.ls	ceb0 <__divti3+0x160>  // b.plast
    cea0:	ab050105 	adds	x5, x8, x5
    cea4:	d1000561 	sub	x1, x11, #0x1
    cea8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ceac:	54000f48 	b.hi	d094 <__divti3+0x344>  // b.pmore
    ceb0:	cb0600a6 	sub	x6, x5, x6
    ceb4:	9ac908cb 	udiv	x11, x6, x9
    ceb8:	9b099969 	msub	x9, x11, x9, x6
    cebc:	aa0b03e5 	mov	x5, x11
    cec0:	9b0b7d4a 	mul	x10, x10, x11
    cec4:	b3607d23 	bfi	x3, x9, #32, #32
    cec8:	eb03015f 	cmp	x10, x3
    cecc:	540000a9 	b.ls	cee0 <__divti3+0x190>  // b.plast
    ced0:	ab030103 	adds	x3, x8, x3
    ced4:	d1000565 	sub	x5, x11, #0x1
    ced8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    cedc:	54000e28 	b.hi	d0a0 <__divti3+0x350>  // b.pmore
    cee0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    cee4:	92407c48 	and	x8, x2, #0xffffffff
    cee8:	2a0503e5 	mov	w5, w5
    ceec:	d360fc42 	lsr	x2, x2, #32
    cef0:	d360fc26 	lsr	x6, x1, #32
    cef4:	cb0a0063 	sub	x3, x3, x10
    cef8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    cefc:	9b087caa 	mul	x10, x5, x8
    cf00:	9b087cc8 	mul	x8, x6, x8
    cf04:	9b0220a5 	madd	x5, x5, x2, x8
    cf08:	9b027cc6 	mul	x6, x6, x2
    cf0c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cf10:	8b0900c5 	add	x5, x6, x9
    cf14:	eb02011f 	cmp	x8, x2
    cf18:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cf1c:	8b4280c6 	add	x6, x6, x2, lsr #32
    cf20:	eb06007f 	cmp	x3, x6
    cf24:	540000e3 	b.cc	cf40 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cf28:	92407d4a 	and	x10, x10, #0xffffffff
    cf2c:	9ac72000 	lsl	x0, x0, x7
    cf30:	8b028142 	add	x2, x10, x2, lsl #32
    cf34:	eb02001f 	cmp	x0, x2
    cf38:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cf3c:	54000a01 	b.ne	d07c <__divti3+0x32c>  // b.any
    cf40:	d1000420 	sub	x0, x1, #0x1
    cf44:	d2800001 	mov	x1, #0x0                   	// #0
    cf48:	17ffffb4 	b	ce18 <__divti3+0xc8>
    cf4c:	b5000062 	cbnz	x2, cf58 <__divti3+0x208>
    cf50:	d2800022 	mov	x2, #0x1                   	// #1
    cf54:	9ac30846 	udiv	x6, x2, x3
    cf58:	dac010c8 	clz	x8, x6
    cf5c:	b5000408 	cbnz	x8, cfdc <__divti3+0x28c>
    cf60:	d360fcc9 	lsr	x9, x6, #32
    cf64:	92407cc5 	and	x5, x6, #0xffffffff
    cf68:	cb060023 	sub	x3, x1, x6
    cf6c:	d2800021 	mov	x1, #0x1                   	// #1
    cf70:	9ac90868 	udiv	x8, x3, x9
    cf74:	9b098d03 	msub	x3, x8, x9, x3
    cf78:	aa0803e0 	mov	x0, x8
    cf7c:	9b057d02 	mul	x2, x8, x5
    cf80:	93c78063 	extr	x3, x3, x7, #32
    cf84:	eb03005f 	cmp	x2, x3
    cf88:	540000a9 	b.ls	cf9c <__divti3+0x24c>  // b.plast
    cf8c:	ab0300c3 	adds	x3, x6, x3
    cf90:	d1000500 	sub	x0, x8, #0x1
    cf94:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cf98:	54000968 	b.hi	d0c4 <__divti3+0x374>  // b.pmore
    cf9c:	cb020063 	sub	x3, x3, x2
    cfa0:	9ac90862 	udiv	x2, x3, x9
    cfa4:	aa0203e8 	mov	x8, x2
    cfa8:	9b098c42 	msub	x2, x2, x9, x3
    cfac:	aa0703e3 	mov	x3, x7
    cfb0:	9b057d05 	mul	x5, x8, x5
    cfb4:	b3607c43 	bfi	x3, x2, #32, #32
    cfb8:	eb0300bf 	cmp	x5, x3
    cfbc:	540000c9 	b.ls	cfd4 <__divti3+0x284>  // b.plast
    cfc0:	ab0300c2 	adds	x2, x6, x3
    cfc4:	d1000503 	sub	x3, x8, #0x1
    cfc8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cfcc:	d1000908 	sub	x8, x8, #0x2
    cfd0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cfd4:	aa008100 	orr	x0, x8, x0, lsl #32
    cfd8:	17ffff90 	b	ce18 <__divti3+0xc8>
    cfdc:	9ac820c6 	lsl	x6, x6, x8
    cfe0:	d2800803 	mov	x3, #0x40                  	// #64
    cfe4:	cb080063 	sub	x3, x3, x8
    cfe8:	d360fcc9 	lsr	x9, x6, #32
    cfec:	9ac82027 	lsl	x7, x1, x8
    cff0:	92407cc5 	and	x5, x6, #0xffffffff
    cff4:	9ac32422 	lsr	x2, x1, x3
    cff8:	9ac32403 	lsr	x3, x0, x3
    cffc:	aa070063 	orr	x3, x3, x7
    d000:	9ac9084a 	udiv	x10, x2, x9
    d004:	9ac82007 	lsl	x7, x0, x8
    d008:	9b098940 	msub	x0, x10, x9, x2
    d00c:	aa0a03e1 	mov	x1, x10
    d010:	9b0a7ca2 	mul	x2, x5, x10
    d014:	93c38000 	extr	x0, x0, x3, #32
    d018:	eb00005f 	cmp	x2, x0
    d01c:	540000a9 	b.ls	d030 <__divti3+0x2e0>  // b.plast
    d020:	ab0000c0 	adds	x0, x6, x0
    d024:	d1000541 	sub	x1, x10, #0x1
    d028:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d02c:	54000468 	b.hi	d0b8 <__divti3+0x368>  // b.pmore
    d030:	cb020000 	sub	x0, x0, x2
    d034:	9ac9080a 	udiv	x10, x0, x9
    d038:	9b098140 	msub	x0, x10, x9, x0
    d03c:	aa0a03e2 	mov	x2, x10
    d040:	9b0a7ca8 	mul	x8, x5, x10
    d044:	b3607c03 	bfi	x3, x0, #32, #32
    d048:	eb03011f 	cmp	x8, x3
    d04c:	540000a9 	b.ls	d060 <__divti3+0x310>  // b.plast
    d050:	ab0300c3 	adds	x3, x6, x3
    d054:	d1000542 	sub	x2, x10, #0x1
    d058:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d05c:	54000288 	b.hi	d0ac <__divti3+0x35c>  // b.pmore
    d060:	cb080063 	sub	x3, x3, x8
    d064:	aa018041 	orr	x1, x2, x1, lsl #32
    d068:	17ffffc2 	b	cf70 <__divti3+0x220>
    d06c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d070:	d2800001 	mov	x1, #0x0                   	// #0
    d074:	9a9f87e0 	cset	x0, ls	// ls = plast
    d078:	17ffff68 	b	ce18 <__divti3+0xc8>
    d07c:	aa0103e0 	mov	x0, x1
    d080:	d2800001 	mov	x1, #0x0                   	// #0
    d084:	17ffff65 	b	ce18 <__divti3+0xc8>
    d088:	d1000860 	sub	x0, x3, #0x2
    d08c:	8b0600a5 	add	x5, x5, x6
    d090:	17ffff52 	b	cdd8 <__divti3+0x88>
    d094:	d1000961 	sub	x1, x11, #0x2
    d098:	8b0800a5 	add	x5, x5, x8
    d09c:	17ffff85 	b	ceb0 <__divti3+0x160>
    d0a0:	d1000965 	sub	x5, x11, #0x2
    d0a4:	8b080063 	add	x3, x3, x8
    d0a8:	17ffff8e 	b	cee0 <__divti3+0x190>
    d0ac:	d1000942 	sub	x2, x10, #0x2
    d0b0:	8b060063 	add	x3, x3, x6
    d0b4:	17ffffeb 	b	d060 <__divti3+0x310>
    d0b8:	d1000941 	sub	x1, x10, #0x2
    d0bc:	8b060000 	add	x0, x0, x6
    d0c0:	17ffffdc 	b	d030 <__divti3+0x2e0>
    d0c4:	d1000900 	sub	x0, x8, #0x2
    d0c8:	8b060063 	add	x3, x3, x6
    d0cc:	17ffffb4 	b	cf9c <__divti3+0x24c>

000000000000d0d0 <__modti3>:
    d0d0:	d503245f 	bti	c
    d0d4:	d2800004 	mov	x4, #0x0                   	// #0
    d0d8:	b6f80081 	tbz	x1, #63, d0e8 <__modti3+0x18>
    d0dc:	eb0003e0 	negs	x0, x0
    d0e0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d0e4:	da0103e1 	ngc	x1, x1
    d0e8:	f100007f 	cmp	x3, #0x0
    d0ec:	5400128b 	b.lt	d33c <__modti3+0x26c>  // b.tstop
    d0f0:	aa0003e7 	mov	x7, x0
    d0f4:	aa0103e6 	mov	x6, x1
    d0f8:	540004e1 	b.ne	d194 <__modti3+0xc4>  // b.any
    d0fc:	eb02003f 	cmp	x1, x2
    d100:	54000dc2 	b.cs	d2b8 <__modti3+0x1e8>  // b.hs, b.nlast
    d104:	dac01043 	clz	x3, x2
    d108:	aa0303e5 	mov	x5, x3
    d10c:	b40000e3 	cbz	x3, d128 <__modti3+0x58>
    d110:	4b0303e6 	neg	w6, w3
    d114:	9ac32021 	lsl	x1, x1, x3
    d118:	9ac32042 	lsl	x2, x2, x3
    d11c:	9ac62406 	lsr	x6, x0, x6
    d120:	aa0100c6 	orr	x6, x6, x1
    d124:	9ac32007 	lsl	x7, x0, x3
    d128:	d360fc40 	lsr	x0, x2, #32
    d12c:	92407c43 	and	x3, x2, #0xffffffff
    d130:	9ac008c1 	udiv	x1, x6, x0
    d134:	9b009826 	msub	x6, x1, x0, x6
    d138:	9b017c61 	mul	x1, x3, x1
    d13c:	93c780c6 	extr	x6, x6, x7, #32
    d140:	eb06003f 	cmp	x1, x6
    d144:	540000a9 	b.ls	d158 <__modti3+0x88>  // b.plast
    d148:	ab060046 	adds	x6, x2, x6
    d14c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d150:	8b0200c8 	add	x8, x6, x2
    d154:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d158:	cb0100c6 	sub	x6, x6, x1
    d15c:	9ac008c8 	udiv	x8, x6, x0
    d160:	9b009901 	msub	x1, x8, x0, x6
    d164:	aa0703e0 	mov	x0, x7
    d168:	9b087c63 	mul	x3, x3, x8
    d16c:	b3607c20 	bfi	x0, x1, #32, #32
    d170:	eb00007f 	cmp	x3, x0
    d174:	54001088 	b.hi	d384 <__modti3+0x2b4>  // b.pmore
    d178:	cb030000 	sub	x0, x0, x3
    d17c:	9ac52400 	lsr	x0, x0, x5
    d180:	d2800001 	mov	x1, #0x0                   	// #0
    d184:	b4000064 	cbz	x4, d190 <__modti3+0xc0>
    d188:	eb0003e0 	negs	x0, x0
    d18c:	da0103e1 	ngc	x1, x1
    d190:	d65f03c0 	ret
    d194:	dac01066 	clz	x6, x3
    d198:	eb03003f 	cmp	x1, x3
    d19c:	54ffff43 	b.cc	d184 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d1a0:	93407cc5 	sxtw	x5, w6
    d1a4:	d2800808 	mov	x8, #0x40                  	// #64
    d1a8:	cb050108 	sub	x8, x8, x5
    d1ac:	9ac62063 	lsl	x3, x3, x6
    d1b0:	9ac62025 	lsl	x5, x1, x6
    d1b4:	9ac82447 	lsr	x7, x2, x8
    d1b8:	aa0300e7 	orr	x7, x7, x3
    d1bc:	9ac82423 	lsr	x3, x1, x8
    d1c0:	92407cec 	and	x12, x7, #0xffffffff
    d1c4:	d360fcea 	lsr	x10, x7, #32
    d1c8:	9ac82401 	lsr	x1, x0, x8
    d1cc:	aa050021 	orr	x1, x1, x5
    d1d0:	9ac62042 	lsl	x2, x2, x6
    d1d4:	9ac62000 	lsl	x0, x0, x6
    d1d8:	9aca086b 	udiv	x11, x3, x10
    d1dc:	9b0a8d63 	msub	x3, x11, x10, x3
    d1e0:	aa0b03e5 	mov	x5, x11
    d1e4:	9b0b7d89 	mul	x9, x12, x11
    d1e8:	93c18063 	extr	x3, x3, x1, #32
    d1ec:	eb03013f 	cmp	x9, x3
    d1f0:	540000a9 	b.ls	d204 <__modti3+0x134>  // b.plast
    d1f4:	ab0300e3 	adds	x3, x7, x3
    d1f8:	d1000565 	sub	x5, x11, #0x1
    d1fc:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d200:	54001168 	b.hi	d42c <__modti3+0x35c>  // b.pmore
    d204:	cb090063 	sub	x3, x3, x9
    d208:	9aca086b 	udiv	x11, x3, x10
    d20c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d210:	aa0b03e9 	mov	x9, x11
    d214:	9b0b7d8c 	mul	x12, x12, x11
    d218:	b3607d41 	bfi	x1, x10, #32, #32
    d21c:	eb01019f 	cmp	x12, x1
    d220:	540000a9 	b.ls	d234 <__modti3+0x164>  // b.plast
    d224:	ab0100e1 	adds	x1, x7, x1
    d228:	d1000569 	sub	x9, x11, #0x1
    d22c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d230:	54000f88 	b.hi	d420 <__modti3+0x350>  // b.pmore
    d234:	aa058123 	orr	x3, x9, x5, lsl #32
    d238:	92407c4b 	and	x11, x2, #0xffffffff
    d23c:	2a0903e9 	mov	w9, w9
    d240:	d360fc4a 	lsr	x10, x2, #32
    d244:	d360fc63 	lsr	x3, x3, #32
    d248:	cb0c0021 	sub	x1, x1, x12
    d24c:	aa0a03ec 	mov	x12, x10
    d250:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d254:	9b0b7d25 	mul	x5, x9, x11
    d258:	9b0b7c6b 	mul	x11, x3, x11
    d25c:	9b0a2d29 	madd	x9, x9, x10, x11
    d260:	92407caa 	and	x10, x5, #0xffffffff
    d264:	9b0c7c63 	mul	x3, x3, x12
    d268:	8b458125 	add	x5, x9, x5, lsr #32
    d26c:	8b0d0069 	add	x9, x3, x13
    d270:	eb05017f 	cmp	x11, x5
    d274:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d278:	8b058149 	add	x9, x10, x5, lsl #32
    d27c:	8b458063 	add	x3, x3, x5, lsr #32
    d280:	eb03003f 	cmp	x1, x3
    d284:	54000063 	b.cc	d290 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d288:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d28c:	54000082 	b.cs	d29c <__modti3+0x1cc>  // b.hs, b.nlast
    d290:	eb020129 	subs	x9, x9, x2
    d294:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d298:	cb070063 	sub	x3, x3, x7
    d29c:	eb090000 	subs	x0, x0, x9
    d2a0:	da030021 	sbc	x1, x1, x3
    d2a4:	9ac62400 	lsr	x0, x0, x6
    d2a8:	9ac82028 	lsl	x8, x1, x8
    d2ac:	aa000100 	orr	x0, x8, x0
    d2b0:	9ac62421 	lsr	x1, x1, x6
    d2b4:	17ffffb4 	b	d184 <__modti3+0xb4>
    d2b8:	b5000062 	cbnz	x2, d2c4 <__modti3+0x1f4>
    d2bc:	d2800023 	mov	x3, #0x1                   	// #1
    d2c0:	9ac20862 	udiv	x2, x3, x2
    d2c4:	dac01048 	clz	x8, x2
    d2c8:	aa0803e5 	mov	x5, x8
    d2cc:	b5000668 	cbnz	x8, d398 <__modti3+0x2c8>
    d2d0:	cb020020 	sub	x0, x1, x2
    d2d4:	d360fc49 	lsr	x9, x2, #32
    d2d8:	92407c4a 	and	x10, x2, #0xffffffff
    d2dc:	9ac90801 	udiv	x1, x0, x9
    d2e0:	9b098020 	msub	x0, x1, x9, x0
    d2e4:	9b0a7c21 	mul	x1, x1, x10
    d2e8:	93c78000 	extr	x0, x0, x7, #32
    d2ec:	eb00003f 	cmp	x1, x0
    d2f0:	540000a9 	b.ls	d304 <__modti3+0x234>  // b.plast
    d2f4:	ab000040 	adds	x0, x2, x0
    d2f8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d2fc:	8b020003 	add	x3, x0, x2
    d300:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d304:	cb010001 	sub	x1, x0, x1
    d308:	9ac90820 	udiv	x0, x1, x9
    d30c:	9b098403 	msub	x3, x0, x9, x1
    d310:	aa0703e1 	mov	x1, x7
    d314:	9b0a7c00 	mul	x0, x0, x10
    d318:	b3607c61 	bfi	x1, x3, #32, #32
    d31c:	eb01001f 	cmp	x0, x1
    d320:	540000a9 	b.ls	d334 <__modti3+0x264>  // b.plast
    d324:	ab010041 	adds	x1, x2, x1
    d328:	8b020022 	add	x2, x1, x2
    d32c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d330:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d334:	cb000020 	sub	x0, x1, x0
    d338:	17ffff91 	b	d17c <__modti3+0xac>
    d33c:	eb0203e5 	negs	x5, x2
    d340:	aa0003e7 	mov	x7, x0
    d344:	da0303e8 	ngc	x8, x3
    d348:	aa0503e2 	mov	x2, x5
    d34c:	aa0803e3 	mov	x3, x8
    d350:	aa0103e6 	mov	x6, x1
    d354:	b4ffed48 	cbz	x8, d0fc <__modti3+0x2c>
    d358:	eb01011f 	cmp	x8, x1
    d35c:	54fff148 	b.hi	d184 <__modti3+0xb4>  // b.pmore
    d360:	dac01109 	clz	x9, x8
    d364:	2a0903e6 	mov	w6, w9
    d368:	b5fff1c9 	cbnz	x9, d1a0 <__modti3+0xd0>
    d36c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d370:	54000068 	b.hi	d37c <__modti3+0x2ac>  // b.pmore
    d374:	eb050007 	subs	x7, x0, x5
    d378:	da080021 	sbc	x1, x1, x8
    d37c:	aa0703e0 	mov	x0, x7
    d380:	17ffff81 	b	d184 <__modti3+0xb4>
    d384:	ab000040 	adds	x0, x2, x0
    d388:	8b020002 	add	x2, x0, x2
    d38c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d390:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d394:	17ffff79 	b	d178 <__modti3+0xa8>
    d398:	9ac82042 	lsl	x2, x2, x8
    d39c:	d2800803 	mov	x3, #0x40                  	// #64
    d3a0:	cb080063 	sub	x3, x3, x8
    d3a4:	d360fc49 	lsr	x9, x2, #32
    d3a8:	9ac82027 	lsl	x7, x1, x8
    d3ac:	92407c4a 	and	x10, x2, #0xffffffff
    d3b0:	9ac32426 	lsr	x6, x1, x3
    d3b4:	9ac32403 	lsr	x3, x0, x3
    d3b8:	aa070063 	orr	x3, x3, x7
    d3bc:	9ac908c1 	udiv	x1, x6, x9
    d3c0:	9ac82007 	lsl	x7, x0, x8
    d3c4:	9b099820 	msub	x0, x1, x9, x6
    d3c8:	9b017d41 	mul	x1, x10, x1
    d3cc:	93c38000 	extr	x0, x0, x3, #32
    d3d0:	eb00003f 	cmp	x1, x0
    d3d4:	540000a9 	b.ls	d3e8 <__modti3+0x318>  // b.plast
    d3d8:	ab000040 	adds	x0, x2, x0
    d3dc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d3e0:	8b020006 	add	x6, x0, x2
    d3e4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d3e8:	cb010000 	sub	x0, x0, x1
    d3ec:	9ac90801 	udiv	x1, x0, x9
    d3f0:	9b098026 	msub	x6, x1, x9, x0
    d3f4:	aa0303e0 	mov	x0, x3
    d3f8:	9b017d41 	mul	x1, x10, x1
    d3fc:	b3607cc0 	bfi	x0, x6, #32, #32
    d400:	eb00003f 	cmp	x1, x0
    d404:	540000a9 	b.ls	d418 <__modti3+0x348>  // b.plast
    d408:	ab000040 	adds	x0, x2, x0
    d40c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d410:	8b020003 	add	x3, x0, x2
    d414:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d418:	cb010000 	sub	x0, x0, x1
    d41c:	17ffffb0 	b	d2dc <__modti3+0x20c>
    d420:	d1000969 	sub	x9, x11, #0x2
    d424:	8b070021 	add	x1, x1, x7
    d428:	17ffff83 	b	d234 <__modti3+0x164>
    d42c:	d1000965 	sub	x5, x11, #0x2
    d430:	8b070063 	add	x3, x3, x7
    d434:	17ffff74 	b	d204 <__modti3+0x134>
    d438:	d503201f 	nop
    d43c:	d503201f 	nop

000000000000d440 <atexit>:
    d440:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d444:	f0000082 	adrp	x2, 20000 <__data_start>
    d448:	d2800001 	mov	x1, #0x0                   	// #0
    d44c:	910003fd 	mov	x29, sp
    d450:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d454:	f9400442 	ldr	x2, [x2, #8]
    d458:	17ffd4d2 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d45c <_fini>:
    d45c:	d503201f 	nop
    d460:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d464:	910003fd 	mov	x29, sp
    d468:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d46c:	d65f03c0 	ret
