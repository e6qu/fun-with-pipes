
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-profile:     file format elf64-littleaarch64


Disassembly of section .init:

00000000000026b8 <_init>:
    26b8:	d503201f 	nop
    26bc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26c0:	910003fd 	mov	x29, sp
    26c4:	9400019c 	bl	2d34 <call_weak_fn>
    26c8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26cc:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026d0 <.plt>:
    26d0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26d4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26d8:	f946fa11 	ldr	x17, [x16, #3568]
    26dc:	9137c210 	add	x16, x16, #0xdf0
    26e0:	d61f0220 	br	x17
    26e4:	d503201f 	nop
    26e8:	d503201f 	nop
    26ec:	d503201f 	nop

00000000000026f0 <memcpy@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    26f4:	f946fe11 	ldr	x17, [x16, #3576]
    26f8:	9137e210 	add	x16, x16, #0xdf8
    26fc:	d61f0220 	br	x17

0000000000002700 <sigaltstack@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2704:	f9470211 	ldr	x17, [x16, #3584]
    2708:	91380210 	add	x16, x16, #0xe00
    270c:	d61f0220 	br	x17

0000000000002710 <memmove@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2714:	f9470611 	ldr	x17, [x16, #3592]
    2718:	91382210 	add	x16, x16, #0xe08
    271c:	d61f0220 	br	x17

0000000000002720 <_exit@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2724:	f9470a11 	ldr	x17, [x16, #3600]
    2728:	91384210 	add	x16, x16, #0xe10
    272c:	d61f0220 	br	x17

0000000000002730 <strlen@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2734:	f9470e11 	ldr	x17, [x16, #3608]
    2738:	91386210 	add	x16, x16, #0xe18
    273c:	d61f0220 	br	x17

0000000000002740 <__sprintf_chk@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2744:	f9471211 	ldr	x17, [x16, #3616]
    2748:	91388210 	add	x16, x16, #0xe20
    274c:	d61f0220 	br	x17

0000000000002750 <exit@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2754:	f9471611 	ldr	x17, [x16, #3624]
    2758:	9138a210 	add	x16, x16, #0xe28
    275c:	d61f0220 	br	x17

0000000000002760 <__libc_start_main@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2764:	f9471a11 	ldr	x17, [x16, #3632]
    2768:	9138c210 	add	x16, x16, #0xe30
    276c:	d61f0220 	br	x17

0000000000002770 <strtoll@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2774:	f9471e11 	ldr	x17, [x16, #3640]
    2778:	9138e210 	add	x16, x16, #0xe38
    277c:	d61f0220 	br	x17

0000000000002780 <strtod@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2784:	f9472211 	ldr	x17, [x16, #3648]
    2788:	91390210 	add	x16, x16, #0xe40
    278c:	d61f0220 	br	x17

0000000000002790 <__cxa_finalize@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2794:	f9472611 	ldr	x17, [x16, #3656]
    2798:	91392210 	add	x16, x16, #0xe48
    279c:	d61f0220 	br	x17

00000000000027a0 <__cxa_atexit@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27a4:	f9472a11 	ldr	x17, [x16, #3664]
    27a8:	91394210 	add	x16, x16, #0xe50
    27ac:	d61f0220 	br	x17

00000000000027b0 <pthread_attr_init@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27b4:	f9472e11 	ldr	x17, [x16, #3672]
    27b8:	91396210 	add	x16, x16, #0xe58
    27bc:	d61f0220 	br	x17

00000000000027c0 <fputc@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27c4:	f9473211 	ldr	x17, [x16, #3680]
    27c8:	91398210 	add	x16, x16, #0xe60
    27cc:	d61f0220 	br	x17

00000000000027d0 <clock_gettime@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27d4:	f9473611 	ldr	x17, [x16, #3688]
    27d8:	9139a210 	add	x16, x16, #0xe68
    27dc:	d61f0220 	br	x17

00000000000027e0 <setvbuf@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27e4:	f9473a11 	ldr	x17, [x16, #3696]
    27e8:	9139c210 	add	x16, x16, #0xe70
    27ec:	d61f0220 	br	x17

00000000000027f0 <__memcpy_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    27f4:	f9473e11 	ldr	x17, [x16, #3704]
    27f8:	9139e210 	add	x16, x16, #0xe78
    27fc:	d61f0220 	br	x17

0000000000002800 <signal@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2804:	f9474211 	ldr	x17, [x16, #3712]
    2808:	913a0210 	add	x16, x16, #0xe80
    280c:	d61f0220 	br	x17

0000000000002810 <__snprintf_chk@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2814:	f9474611 	ldr	x17, [x16, #3720]
    2818:	913a2210 	add	x16, x16, #0xe88
    281c:	d61f0220 	br	x17

0000000000002820 <fclose@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2824:	f9474a11 	ldr	x17, [x16, #3728]
    2828:	913a4210 	add	x16, x16, #0xe90
    282c:	d61f0220 	br	x17

0000000000002830 <fopen@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2834:	f9474e11 	ldr	x17, [x16, #3736]
    2838:	913a6210 	add	x16, x16, #0xe98
    283c:	d61f0220 	br	x17

0000000000002840 <malloc@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2844:	f9475211 	ldr	x17, [x16, #3744]
    2848:	913a8210 	add	x16, x16, #0xea0
    284c:	d61f0220 	br	x17

0000000000002850 <pthread_attr_destroy@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2854:	f9475611 	ldr	x17, [x16, #3752]
    2858:	913aa210 	add	x16, x16, #0xea8
    285c:	d61f0220 	br	x17

0000000000002860 <sigemptyset@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2864:	f9475a11 	ldr	x17, [x16, #3760]
    2868:	913ac210 	add	x16, x16, #0xeb0
    286c:	d61f0220 	br	x17

0000000000002870 <memset@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2874:	f9475e11 	ldr	x17, [x16, #3768]
    2878:	913ae210 	add	x16, x16, #0xeb8
    287c:	d61f0220 	br	x17

0000000000002880 <calloc@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2884:	f9476211 	ldr	x17, [x16, #3776]
    2888:	913b0210 	add	x16, x16, #0xec0
    288c:	d61f0220 	br	x17

0000000000002890 <realloc@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2894:	f9476611 	ldr	x17, [x16, #3784]
    2898:	913b2210 	add	x16, x16, #0xec8
    289c:	d61f0220 	br	x17

00000000000028a0 <__stack_chk_fail@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28a4:	f9476a11 	ldr	x17, [x16, #3792]
    28a8:	913b4210 	add	x16, x16, #0xed0
    28ac:	d61f0220 	br	x17

00000000000028b0 <close@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28b4:	f9476e11 	ldr	x17, [x16, #3800]
    28b8:	913b6210 	add	x16, x16, #0xed8
    28bc:	d61f0220 	br	x17

00000000000028c0 <sigaction@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28c4:	f9477211 	ldr	x17, [x16, #3808]
    28c8:	913b8210 	add	x16, x16, #0xee0
    28cc:	d61f0220 	br	x17

00000000000028d0 <__gmon_start__@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28d4:	f9477611 	ldr	x17, [x16, #3816]
    28d8:	913ba210 	add	x16, x16, #0xee8
    28dc:	d61f0220 	br	x17

00000000000028e0 <write@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28e4:	f9477a11 	ldr	x17, [x16, #3824]
    28e8:	913bc210 	add	x16, x16, #0xef0
    28ec:	d61f0220 	br	x17

00000000000028f0 <abort@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    28f4:	f9477e11 	ldr	x17, [x16, #3832]
    28f8:	913be210 	add	x16, x16, #0xef8
    28fc:	d61f0220 	br	x17

0000000000002900 <swapcontext@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2904:	f9478211 	ldr	x17, [x16, #3840]
    2908:	913c0210 	add	x16, x16, #0xf00
    290c:	d61f0220 	br	x17

0000000000002910 <__fprintf_chk@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2914:	f9478611 	ldr	x17, [x16, #3848]
    2918:	913c2210 	add	x16, x16, #0xf08
    291c:	d61f0220 	br	x17

0000000000002920 <strcmp@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2924:	f9478a11 	ldr	x17, [x16, #3856]
    2928:	913c4210 	add	x16, x16, #0xf10
    292c:	d61f0220 	br	x17

0000000000002930 <mmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2934:	f9478e11 	ldr	x17, [x16, #3864]
    2938:	913c6210 	add	x16, x16, #0xf18
    293c:	d61f0220 	br	x17

0000000000002940 <strtol@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2944:	f9479211 	ldr	x17, [x16, #3872]
    2948:	913c8210 	add	x16, x16, #0xf20
    294c:	d61f0220 	br	x17

0000000000002950 <strtof@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2954:	f9479611 	ldr	x17, [x16, #3880]
    2958:	913ca210 	add	x16, x16, #0xf28
    295c:	d61f0220 	br	x17

0000000000002960 <free@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2964:	f9479a11 	ldr	x17, [x16, #3888]
    2968:	913cc210 	add	x16, x16, #0xf30
    296c:	d61f0220 	br	x17

0000000000002970 <nanosleep@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2974:	f9479e11 	ldr	x17, [x16, #3896]
    2978:	913ce210 	add	x16, x16, #0xf38
    297c:	d61f0220 	br	x17

0000000000002980 <strchr@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2984:	f947a211 	ldr	x17, [x16, #3904]
    2988:	913d0210 	add	x16, x16, #0xf40
    298c:	d61f0220 	br	x17

0000000000002990 <strtoull@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2994:	f947a611 	ldr	x17, [x16, #3912]
    2998:	913d2210 	add	x16, x16, #0xf48
    299c:	d61f0220 	br	x17

00000000000029a0 <fwrite@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29a4:	f947aa11 	ldr	x17, [x16, #3920]
    29a8:	913d4210 	add	x16, x16, #0xf50
    29ac:	d61f0220 	br	x17

00000000000029b0 <pthread_create@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29b4:	f947ae11 	ldr	x17, [x16, #3928]
    29b8:	913d6210 	add	x16, x16, #0xf58
    29bc:	d61f0220 	br	x17

00000000000029c0 <munmap@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29c4:	f947b211 	ldr	x17, [x16, #3936]
    29c8:	913d8210 	add	x16, x16, #0xf60
    29cc:	d61f0220 	br	x17

00000000000029d0 <fflush@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29d4:	f947b611 	ldr	x17, [x16, #3944]
    29d8:	913da210 	add	x16, x16, #0xf68
    29dc:	d61f0220 	br	x17

00000000000029e0 <strcpy@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29e4:	f947ba11 	ldr	x17, [x16, #3952]
    29e8:	913dc210 	add	x16, x16, #0xf70
    29ec:	d61f0220 	br	x17

00000000000029f0 <sysconf@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    29f4:	f947be11 	ldr	x17, [x16, #3960]
    29f8:	913de210 	add	x16, x16, #0xf78
    29fc:	d61f0220 	br	x17

0000000000002a00 <strstr@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a04:	f947c211 	ldr	x17, [x16, #3968]
    2a08:	913e0210 	add	x16, x16, #0xf80
    2a0c:	d61f0220 	br	x17

0000000000002a10 <_Exit@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a14:	f947c611 	ldr	x17, [x16, #3976]
    2a18:	913e2210 	add	x16, x16, #0xf88
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_join@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a24:	f947ca11 	ldr	x17, [x16, #3984]
    2a28:	913e4210 	add	x16, x16, #0xf90
    2a2c:	d61f0220 	br	x17

0000000000002a30 <getenv@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a34:	f947ce11 	ldr	x17, [x16, #3992]
    2a38:	913e6210 	add	x16, x16, #0xf98
    2a3c:	d61f0220 	br	x17

0000000000002a40 <mprotect@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a44:	f947d211 	ldr	x17, [x16, #4000]
    2a48:	913e8210 	add	x16, x16, #0xfa0
    2a4c:	d61f0220 	br	x17

0000000000002a50 <fgets@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a54:	f947d611 	ldr	x17, [x16, #4008]
    2a58:	913ea210 	add	x16, x16, #0xfa8
    2a5c:	d61f0220 	br	x17

0000000000002a60 <pthread_attr_setstacksize@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc90>
    2a64:	f947da11 	ldr	x17, [x16, #4016]
    2a68:	913ec210 	add	x16, x16, #0xfb0
    2a6c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <fwp_main_thread+0x520>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	9131c0a5 	add	x5, x5, #0xc70
    2aa0:	f0000044 	adrp	x4, d000 <fwp_main_thread+0x520>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	9131e084 	add	x4, x4, #0xc78
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff52 	bl	2810 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	94000619 	bl	4334 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc90>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	910142a1 	add	x1, x21, #0x50
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xe4b0>
    2b20:	910dc000 	add	x0, x0, #0x370
    2b24:	f9004822 	str	x2, [x1, #144]
    2b28:	f9008c20 	str	x0, [x1, #280]
    2b2c:	94000821 	bl	4bb0 <fwp_now_ns>
    2b30:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x870>
    2b34:	9100e000 	add	x0, x0, #0x38
    2b38:	97ffffbe 	bl	2a30 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff1f 	bl	27d0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff11 	bl	27e0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff16 	bl	2800 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97ffff00 	bl	27b0 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa8 	bl	2a60 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x1bcc>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	912b8042 	add	x2, x2, #0xae0
    2bdc:	97ffff75 	bl	29b0 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff19 	bl	2850 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff88 	bl	2a20 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	910142b5 	add	x21, x21, #0x50
    2c10:	97ffff70 	bl	29d0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b943daa0 	ldr	w0, [x21, #984]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x870>
    2c4c:	9101a000 	add	x0, x0, #0x68
    2c50:	940005b9 	bl	4334 <fwp_trap>
    2c54:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x870>
    2c58:	91012000 	add	x0, x0, #0x48
    2c5c:	940005b6 	bl	4334 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff4a 	bl	2990 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffeef 	bl	2850 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x870>
    2ca0:	91030000 	add	x0, x0, #0xc0
    2ca4:	940005a4 	bl	4334 <fwp_trap>
    2ca8:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x870>
    2cac:	91024000 	add	x0, x0, #0x90
    2cb0:	940005a1 	bl	4334 <fwp_trap>
    2cb4:	90000060 	adrp	x0, e000 <_IO_stdin_used+0x870>
    2cb8:	9103a000 	add	x0, x0, #0xe8
    2cbc:	9400059e 	bl	4334 <fwp_trap>
    2cc0:	97fffef8 	bl	28a0 <__stack_chk_fail@plt>
    2cc4:	97ffff0b 	bl	28f0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe8d 	bl	2760 <__libc_start_main@plt>
    2d30:	97fffef0 	bl	28f0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffee4 	b	28d0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91010000 	add	x0, x0, #0x40
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91010021 	add	x1, x1, #0x40
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91010000 	add	x0, x0, #0x40
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91010021 	add	x1, x1, #0x40
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39410260 	ldrb	w0, [x19, #64]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe68 	bl	2790 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39010260 	strb	w0, [x19, #64]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000061 	adrp	x1, e000 <_IO_stdin_used+0x870>
    2eb4:	911d0021 	add	x1, x1, #0x740
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe55 	bl	28a0 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <ad_raw_record>:
    2f90:	2a0303e4 	mov	w4, w3
    2f94:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f98:	910140e6 	add	x6, x7, #0x50
    2f9c:	b9001003 	str	w3, [x0, #16]
    2fa0:	f940040c 	ldr	x12, [x0, #8]
    2fa4:	910080ca 	add	x10, x6, #0x20
    2fa8:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2fac:	910100c9 	add	x9, x6, #0x40
    2fb0:	910180cb 	add	x11, x6, #0x60
    2fb4:	a9000801 	stp	x1, x2, [x0]
    2fb8:	cb0c00a1 	sub	x1, x5, x12
    2fbc:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2fc0:	8b020021 	add	x1, x1, x2
    2fc4:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2fc8:	91000508 	add	x8, x8, #0x1
    2fcc:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2fd0:	8b0200a5 	add	x5, x5, x2
    2fd4:	f8247948 	str	x8, [x10, x4, lsl #3]
    2fd8:	f8247925 	str	x5, [x9, x4, lsl #3]
    2fdc:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2fe0:	eb0c003f 	cmp	x1, x12
    2fe4:	54000049 	b.ls	2fec <ad_raw_record+0x5c>  // b.plast
    2fe8:	f8247961 	str	x1, [x11, x4, lsl #3]
    2fec:	910140e1 	add	x1, x7, #0x50
    2ff0:	ad400021 	ldp	q1, q0, [x1]
    2ff4:	f9404022 	ldr	x2, [x1, #128]
    2ff8:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2ffc:	5ef1b800 	addp	d0, v0.2d
    3000:	9e660000 	fmov	x0, d0
    3004:	eb00005f 	cmp	x2, x0
    3008:	54000042 	b.cs	3010 <ad_raw_record+0x80>  // b.hs, b.nlast
    300c:	fd004020 	str	d0, [x1, #128]
    3010:	d65f03c0 	ret

0000000000003014 <fwp_tape_unlink_scope>:
    3014:	f9402803 	ldr	x3, [x0, #80]
    3018:	b4000223 	cbz	x3, 305c <fwp_tape_unlink_scope+0x48>
    301c:	294b0402 	ldp	w2, w1, [x0, #88]
    3020:	37f80202 	tbnz	w2, #31, 3060 <fwp_tape_unlink_scope+0x4c>
    3024:	b00000e4 	adrp	x4, 20000 <__data_start>
    3028:	52800d03 	mov	w3, #0x68                  	// #104
    302c:	f9406c84 	ldr	x4, [x4, #216]
    3030:	9b231043 	smaddl	x3, w2, w3, x4
    3034:	b9005c61 	str	w1, [x3, #92]
    3038:	37f800c1 	tbnz	w1, #31, 3050 <fwp_tape_unlink_scope+0x3c>
    303c:	b00000e3 	adrp	x3, 20000 <__data_start>
    3040:	52800d04 	mov	w4, #0x68                  	// #104
    3044:	f9406c63 	ldr	x3, [x3, #216]
    3048:	9b240c21 	smaddl	x1, w1, w4, x3
    304c:	b9005822 	str	w2, [x1, #88]
    3050:	2f000400 	mvni	v0.2s, #0x0
    3054:	f900281f 	str	xzr, [x0, #80]
    3058:	fd002c00 	str	d0, [x0, #88]
    305c:	d65f03c0 	ret
    3060:	b9000061 	str	w1, [x3]
    3064:	17fffff5 	b	3038 <fwp_tape_unlink_scope+0x24>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_args173>:
    3070:	d65f03c0 	ret

0000000000003074 <fwp_flush>:
    3074:	b00000e0 	adrp	x0, 20000 <__data_start>
    3078:	f9407000 	ldr	x0, [x0, #224]
    307c:	b4000120 	cbz	x0, 30a0 <fwp_flush+0x2c>
    3080:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3084:	910003fd 	mov	x29, sp
    3088:	97fffe52 	bl	29d0 <fflush@plt>
    308c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3090:	f947ec00 	ldr	x0, [x0, #4056]
    3094:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3098:	f9400000 	ldr	x0, [x0]
    309c:	17fffe4d 	b	29d0 <fflush@plt>
    30a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    30a4:	f947ec00 	ldr	x0, [x0, #4056]
    30a8:	f9400000 	ldr	x0, [x0]
    30ac:	17fffe49 	b	29d0 <fflush@plt>

00000000000030b0 <fwp_segv>:
    30b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30b4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30b8:	91014043 	add	x3, x2, #0x50
    30bc:	910003fd 	mov	x29, sp
    30c0:	a90153f3 	stp	x19, x20, [sp, #16]
    30c4:	2a0003f3 	mov	w19, w0
    30c8:	f9404c60 	ldr	x0, [x3, #152]
    30cc:	f90013f5 	str	x21, [sp, #32]
    30d0:	f9400835 	ldr	x21, [x1, #16]
    30d4:	b4000280 	cbz	x0, 3124 <fwp_segv+0x74>
    30d8:	f9400814 	ldr	x20, [x0, #16]
    30dc:	b4000254 	cbz	x20, 3124 <fwp_segv+0x74>
    30e0:	528003c0 	mov	w0, #0x1e                  	// #30
    30e4:	97fffe43 	bl	29f0 <sysconf@plt>
    30e8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ec:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30f0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30f4:	8b000294 	add	x20, x20, x0
    30f8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30fc:	eb0102bf 	cmp	x21, x1
    3100:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3104:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3108:	35000240 	cbnz	w0, 3150 <fwp_segv+0xa0>
    310c:	f94013f5 	ldr	x21, [sp, #32]
    3110:	2a1303e0 	mov	w0, w19
    3114:	a94153f3 	ldp	x19, x20, [sp, #16]
    3118:	d2800001 	mov	x1, #0x0                   	// #0
    311c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3120:	17fffdb8 	b	2800 <signal@plt>
    3124:	91014042 	add	x2, x2, #0x50
    3128:	f9405040 	ldr	x0, [x2, #160]
    312c:	b4ffff00 	cbz	x0, 310c <fwp_segv+0x5c>
    3130:	f9405441 	ldr	x1, [x2, #168]
    3134:	cb010000 	sub	x0, x0, x1
    3138:	d1440001 	sub	x1, x0, #0x100, lsl #12
    313c:	91440000 	add	x0, x0, #0x100, lsl #12
    3140:	eb15003f 	cmp	x1, x21
    3144:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3148:	1a9f97e0 	cset	w0, hi	// hi = pmore
    314c:	34fffe00 	cbz	w0, 310c <fwp_segv+0x5c>
    3150:	97ffffc9 	bl	3074 <fwp_flush>
    3154:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0x870>
    3158:	911c8021 	add	x1, x1, #0x720
    315c:	d2800342 	mov	x2, #0x1a                  	// #26
    3160:	52800040 	mov	w0, #0x2                   	// #2
    3164:	97fffddf 	bl	28e0 <write@plt>
    3168:	52800ca0 	mov	w0, #0x65                  	// #101
    316c:	97fffd6d 	bl	2720 <_exit@plt>

0000000000003170 <fwp_heap_oom>:
    3170:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    3174:	f947e863 	ldr	x3, [x3, #4048]
    3178:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    317c:	d2800262 	mov	x2, #0x13                  	// #19
    3180:	910003fd 	mov	x29, sp
    3184:	f9400063 	ldr	x3, [x3]
    3188:	d2800021 	mov	x1, #0x1                   	// #1
    318c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    3190:	911e6000 	add	x0, x0, #0x798
    3194:	97fffe03 	bl	29a0 <fwrite@plt>
    3198:	d2800000 	mov	x0, #0x0                   	// #0
    319c:	97fffe0d 	bl	29d0 <fflush@plt>
    31a0:	52800cc0 	mov	w0, #0x66                  	// #102
    31a4:	97fffe1b 	bl	2a10 <_Exit@plt>
    31a8:	d503201f 	nop
    31ac:	d503201f 	nop

00000000000031b0 <fwp_heap_chunks>:
    31b0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    31b4:	910003fd 	mov	x29, sp
    31b8:	a90153f3 	stp	x19, x20, [sp, #16]
    31bc:	a9025bf5 	stp	x21, x22, [sp, #32]
    31c0:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    31c4:	9118c2a1 	add	x1, x21, #0x630
    31c8:	f100041f 	cmp	x0, #0x1
    31cc:	54000ca0 	b.eq	3360 <fwp_heap_chunks+0x1b0>  // b.none
    31d0:	f949f822 	ldr	x2, [x1, #5104]
    31d4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    31d8:	912880a5 	add	x5, x5, #0xa20
    31dc:	9118c2a1 	add	x1, x21, #0x630
    31e0:	f949ec34 	ldr	x20, [x1, #5080]
    31e4:	eb14005f 	cmp	x2, x20
    31e8:	54000c42 	b.cs	3370 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    31ec:	f949fc23 	ldr	x3, [x1, #5112]
    31f0:	8b020841 	add	x1, x2, x2, lsl #2
    31f4:	d2800004 	mov	x4, #0x0                   	// #0
    31f8:	8b010c61 	add	x1, x3, x1, lsl #3
    31fc:	14000009 	b	3220 <fwp_heap_chunks+0x70>
    3200:	91000483 	add	x3, x4, #0x1
    3204:	eb03001f 	cmp	x0, x3
    3208:	54000940 	b.eq	3330 <fwp_heap_chunks+0x180>  // b.none
    320c:	91000442 	add	x2, x2, #0x1
    3210:	aa0303e4 	mov	x4, x3
    3214:	9100a021 	add	x1, x1, #0x28
    3218:	eb02029f 	cmp	x20, x2
    321c:	54000100 	b.eq	323c <fwp_heap_chunks+0x8c>  // b.none
    3220:	39400023 	ldrb	w3, [x1]
    3224:	34fffee3 	cbz	w3, 3200 <fwp_heap_chunks+0x50>
    3228:	91000442 	add	x2, x2, #0x1
    322c:	9100a021 	add	x1, x1, #0x28
    3230:	d2800004 	mov	x4, #0x0                   	// #0
    3234:	eb02029f 	cmp	x20, x2
    3238:	54ffff41 	b.ne	3220 <fwp_heap_chunks+0x70>  // b.any
    323c:	cb040294 	sub	x20, x20, x4
    3240:	f9001bf7 	str	x23, [sp, #48]
    3244:	9118c2b7 	add	x23, x21, #0x630
    3248:	8b140013 	add	x19, x0, x20
    324c:	f94a1ae1 	ldr	x1, [x23, #5168]
    3250:	f949f2e0 	ldr	x0, [x23, #5088]
    3254:	cb040021 	sub	x1, x1, x4
    3258:	f90a1ae1 	str	x1, [x23, #5168]
    325c:	eb00027f 	cmp	x19, x0
    3260:	54000429 	b.ls	32e4 <fwp_heap_chunks+0x134>  // b.plast
    3264:	f949eae1 	ldr	x1, [x23, #5072]
    3268:	eb01027f 	cmp	x19, x1
    326c:	54000888 	b.hi	337c <fwp_heap_chunks+0x1cc>  // b.pmore
    3270:	91010276 	add	x22, x19, #0x40
    3274:	52800062 	mov	w2, #0x3                   	// #3
    3278:	f949dae3 	ldr	x3, [x23, #5040]
    327c:	eb0102df 	cmp	x22, x1
    3280:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3284:	cb0002c1 	sub	x1, x22, x0
    3288:	8b004060 	add	x0, x3, x0, lsl #16
    328c:	d370bc21 	lsl	x1, x1, #16
    3290:	97fffdec 	bl	2a40 <mprotect@plt>
    3294:	35000740 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    3298:	528003c0 	mov	w0, #0x1e                  	// #30
    329c:	97fffdd5 	bl	29f0 <sysconf@plt>
    32a0:	f949f2e2 	ldr	x2, [x23, #5088]
    32a4:	cb0003e5 	neg	x5, x0
    32a8:	aa0003e4 	mov	x4, x0
    32ac:	8b160ac1 	add	x1, x22, x22, lsl #2
    32b0:	f949fee0 	ldr	x0, [x23, #5112]
    32b4:	8b020843 	add	x3, x2, x2, lsl #2
    32b8:	52800062 	mov	w2, #0x3                   	// #3
    32bc:	8b010c01 	add	x1, x0, x1, lsl #3
    32c0:	8b030c03 	add	x3, x0, x3, lsl #3
    32c4:	d1000421 	sub	x1, x1, #0x1
    32c8:	8a050060 	and	x0, x3, x5
    32cc:	8b040021 	add	x1, x1, x4
    32d0:	8a050021 	and	x1, x1, x5
    32d4:	cb000021 	sub	x1, x1, x0
    32d8:	97fffdda 	bl	2a40 <mprotect@plt>
    32dc:	35000500 	cbnz	w0, 337c <fwp_heap_chunks+0x1cc>
    32e0:	f909f2f6 	str	x22, [x23, #5088]
    32e4:	9118c2b5 	add	x21, x21, #0x630
    32e8:	d370be60 	lsl	x0, x19, #16
    32ec:	f949e6a1 	ldr	x1, [x21, #5064]
    32f0:	f909eeb3 	str	x19, [x21, #5080]
    32f4:	eb01001f 	cmp	x0, x1
    32f8:	540000e8 	b.hi	3314 <fwp_heap_chunks+0x164>  // b.pmore
    32fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3300:	aa1403e0 	mov	x0, x20
    3304:	a94153f3 	ldp	x19, x20, [sp, #16]
    3308:	f9401bf7 	ldr	x23, [sp, #48]
    330c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3310:	d65f03c0 	ret
    3314:	f9401bf7 	ldr	x23, [sp, #48]
    3318:	f909e6a0 	str	x0, [x21, #5064]
    331c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3320:	aa1403e0 	mov	x0, x20
    3324:	a94153f3 	ldp	x19, x20, [sp, #16]
    3328:	a8c47bfd 	ldp	x29, x30, [sp], #64
    332c:	d65f03c0 	ret
    3330:	9118c2b5 	add	x21, x21, #0x630
    3334:	91000441 	add	x1, x2, #0x1
    3338:	f90000a1 	str	x1, [x5]
    333c:	cb040054 	sub	x20, x2, x4
    3340:	f94a1aa1 	ldr	x1, [x21, #5168]
    3344:	cb000020 	sub	x0, x1, x0
    3348:	f90a1aa0 	str	x0, [x21, #5168]
    334c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3350:	aa1403e0 	mov	x0, x20
    3354:	a94153f3 	ldp	x19, x20, [sp, #16]
    3358:	a8c47bfd 	ldp	x29, x30, [sp], #64
    335c:	d65f03c0 	ret
    3360:	f949f422 	ldr	x2, [x1, #5096]
    3364:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    3368:	912860a5 	add	x5, x5, #0xa18
    336c:	17ffff9c 	b	31dc <fwp_heap_chunks+0x2c>
    3370:	d2800004 	mov	x4, #0x0                   	// #0
    3374:	f9001bf7 	str	x23, [sp, #48]
    3378:	17ffffb3 	b	3244 <fwp_heap_chunks+0x94>
    337c:	97ffff7d 	bl	3170 <fwp_heap_oom>

0000000000003380 <ad_raw_fail>:
    3380:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    3384:	f947e884 	ldr	x4, [x4, #4048]
    3388:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    338c:	aa0003e3 	mov	x3, x0
    3390:	910003fd 	mov	x29, sp
    3394:	f9400080 	ldr	x0, [x4]
    3398:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x520>
    339c:	911ec042 	add	x2, x2, #0x7b0
    33a0:	52800041 	mov	w1, #0x2                   	// #2
    33a4:	97fffd5b 	bl	2910 <__fprintf_chk@plt>
    33a8:	52801d00 	mov	w0, #0xe8                  	// #232
    33ac:	97fffce9 	bl	2750 <exit@plt>

00000000000033b0 <ad_raw_report>:
    33b0:	d10243ff 	sub	sp, sp, #0x90
    33b4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    33b8:	f947f400 	ldr	x0, [x0, #4072]
    33bc:	a9037bfd 	stp	x29, x30, [sp, #48]
    33c0:	9100c3fd 	add	x29, sp, #0x30
    33c4:	a9055bf5 	stp	x21, x22, [sp, #80]
    33c8:	a90663f7 	stp	x23, x24, [sp, #96]
    33cc:	b00000f8 	adrp	x24, 20000 <__data_start>
    33d0:	91014315 	add	x21, x24, #0x50
    33d4:	a90453f3 	stp	x19, x20, [sp, #64]
    33d8:	ad4002a1 	ldp	q1, q0, [x21]
    33dc:	a9076bf9 	stp	x25, x26, [sp, #112]
    33e0:	a90873fb 	stp	x27, x28, [sp, #128]
    33e4:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    33e8:	f9400001 	ldr	x1, [x0]
    33ec:	f90017e1 	str	x1, [sp, #40]
    33f0:	d2800001 	mov	x1, #0x0                   	// #0
    33f4:	5ef1b800 	addp	d0, v0.2d
    33f8:	9e660014 	fmov	x20, d0
    33fc:	b5000d74 	cbnz	x20, 35a8 <ad_raw_report+0x1f8>
    3400:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xc90>
    3404:	f947ead6 	ldr	x22, [x22, #4048]
    3408:	52800041 	mov	w1, #0x2                   	// #2
    340c:	f94042a3 	ldr	x3, [x21, #128]
    3410:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x520>
    3414:	f94002c0 	ldr	x0, [x22]
    3418:	91202042 	add	x2, x2, #0x808
    341c:	f9405aa4 	ldr	x4, [x21, #176]
    3420:	d2800005 	mov	x5, #0x0                   	// #0
    3424:	d0000059 	adrp	x25, d000 <fwp_main_thread+0x520>
    3428:	d000005a 	adrp	x26, d000 <fwp_main_thread+0x520>
    342c:	9121a339 	add	x25, x25, #0x868
    3430:	911f435a 	add	x26, x26, #0x7d0
    3434:	97fffd37 	bl	2910 <__fprintf_chk@plt>
    3438:	d2800013 	mov	x19, #0x0                   	// #0
    343c:	b00000e0 	adrp	x0, 20000 <__data_start>
    3440:	91004000 	add	x0, x0, #0x10
    3444:	910023e1 	add	x1, sp, #0x8
    3448:	d000005b 	adrp	x27, d000 <fwp_main_thread+0x520>
    344c:	aa0103fc 	mov	x28, x1
    3450:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    3454:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    3458:	f94002c0 	ldr	x0, [x22]
    345c:	b4000273 	cbz	x19, 34a8 <ad_raw_report+0xf8>
    3460:	910182a3 	add	x3, x21, #0x60
    3464:	910102a2 	add	x2, x21, #0x40
    3468:	910082a1 	add	x1, x21, #0x20
    346c:	911f6377 	add	x23, x27, #0x7d8
    3470:	f9400384 	ldr	x4, [x28]
    3474:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    3478:	aa1703e3 	mov	x3, x23
    347c:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3480:	aa1903e2 	mov	x2, x25
    3484:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3488:	91000673 	add	x19, x19, #0x1
    348c:	52800041 	mov	w1, #0x2                   	// #2
    3490:	97fffd20 	bl	2910 <__fprintf_chk@plt>
    3494:	f100127f 	cmp	x19, #0x4
    3498:	540001c0 	b.eq	34d0 <ad_raw_report+0x120>  // b.none
    349c:	f94002c0 	ldr	x0, [x22]
    34a0:	9100239c 	add	x28, x28, #0x8
    34a4:	b5fffdf3 	cbnz	x19, 3460 <ad_raw_report+0xb0>
    34a8:	f8408784 	ldr	x4, [x28], #8
    34ac:	aa1a03e3 	mov	x3, x26
    34b0:	f94012a5 	ldr	x5, [x21, #32]
    34b4:	aa1903e2 	mov	x2, x25
    34b8:	f94022a6 	ldr	x6, [x21, #64]
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	f94032a7 	ldr	x7, [x21, #96]
    34c4:	d2800033 	mov	x19, #0x1                   	// #1
    34c8:	97fffd12 	bl	2910 <__fprintf_chk@plt>
    34cc:	17ffffe3 	b	3458 <ad_raw_report+0xa8>
    34d0:	f94002c3 	ldr	x3, [x22]
    34d4:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    34d8:	d2800262 	mov	x2, #0x13                  	// #19
    34dc:	9122a000 	add	x0, x0, #0x8a8
    34e0:	d2800021 	mov	x1, #0x1                   	// #1
    34e4:	97fffd2f 	bl	29a0 <fwrite@plt>
    34e8:	f9405ea0 	ldr	x0, [x21, #184]
    34ec:	b4000360 	cbz	x0, 3558 <ad_raw_report+0x1a8>
    34f0:	b0000161 	adrp	x1, 30000 <alt.5+0xfbb0>
    34f4:	b0000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    34f8:	b0000162 	adrp	x2, 30000 <alt.5+0xfbb0>
    34fc:	d0000043 	adrp	x3, d000 <fwp_main_thread+0x520>
    3500:	f94002c0 	ldr	x0, [x22]
    3504:	d0000055 	adrp	x21, d000 <fwp_main_thread+0x520>
    3508:	f9422824 	ldr	x4, [x1, #1104]
    350c:	91014318 	add	x24, x24, #0x50
    3510:	f9422ca5 	ldr	x5, [x5, #1112]
    3514:	91114033 	add	x19, x1, #0x450
    3518:	f9423046 	ldr	x6, [x2, #1120]
    351c:	911f4063 	add	x3, x3, #0x7d0
    3520:	912302b5 	add	x21, x21, #0x8c0
    3524:	14000005 	b	3538 <ad_raw_report+0x188>
    3528:	a9401664 	ldp	x4, x5, [x19]
    352c:	aa1703e3 	mov	x3, x23
    3530:	f94002c0 	ldr	x0, [x22]
    3534:	f9400a66 	ldr	x6, [x19, #16]
    3538:	aa1503e2 	mov	x2, x21
    353c:	52800041 	mov	w1, #0x2                   	// #2
    3540:	97fffcf4 	bl	2910 <__fprintf_chk@plt>
    3544:	f9405f00 	ldr	x0, [x24, #184]
    3548:	91000694 	add	x20, x20, #0x1
    354c:	91006273 	add	x19, x19, #0x18
    3550:	eb14001f 	cmp	x0, x20
    3554:	54fffea8 	b.hi	3528 <ad_raw_report+0x178>  // b.pmore
    3558:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    355c:	f947f400 	ldr	x0, [x0, #4072]
    3560:	f94017e2 	ldr	x2, [sp, #40]
    3564:	f9400001 	ldr	x1, [x0]
    3568:	eb010042 	subs	x2, x2, x1
    356c:	d2800001 	mov	x1, #0x0                   	// #0
    3570:	54000221 	b.ne	35b4 <ad_raw_report+0x204>  // b.any
    3574:	f94002c3 	ldr	x3, [x22]
    3578:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    357c:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3580:	91240000 	add	x0, x0, #0x900
    3584:	a94453f3 	ldp	x19, x20, [sp, #64]
    3588:	d2800082 	mov	x2, #0x4                   	// #4
    358c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3590:	d2800021 	mov	x1, #0x1                   	// #1
    3594:	a94663f7 	ldp	x23, x24, [sp, #96]
    3598:	a9476bf9 	ldp	x25, x26, [sp, #112]
    359c:	a94873fb 	ldp	x27, x28, [sp, #128]
    35a0:	910243ff 	add	sp, sp, #0x90
    35a4:	17fffcff 	b	29a0 <fwrite@plt>
    35a8:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    35ac:	911f8000 	add	x0, x0, #0x7e0
    35b0:	97ffff74 	bl	3380 <ad_raw_fail>
    35b4:	97fffcbb 	bl	28a0 <__stack_chk_fail@plt>
    35b8:	d503201f 	nop
    35bc:	d503201f 	nop

00000000000035c0 <buf_grow>:
    35c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    35c4:	910003fd 	mov	x29, sp
    35c8:	a90153f3 	stp	x19, x20, [sp, #16]
    35cc:	aa0003f4 	mov	x20, x0
    35d0:	f9400400 	ldr	x0, [x0, #8]
    35d4:	b100041f 	cmn	x0, #0x1
    35d8:	54000400 	b.eq	3658 <buf_grow+0x98>  // b.none
    35dc:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    35e0:	cb000042 	sub	x2, x2, x0
    35e4:	eb01005f 	cmp	x2, x1
    35e8:	54000383 	b.cc	3658 <buf_grow+0x98>  // b.lo, b.ul, b.last
    35ec:	f9400a82 	ldr	x2, [x20, #16]
    35f0:	91000421 	add	x1, x1, #0x1
    35f4:	8b000033 	add	x19, x1, x0
    35f8:	eb13005f 	cmp	x2, x19
    35fc:	54000242 	b.cs	3644 <buf_grow+0x84>  // b.hs, b.nlast
    3600:	f100005f 	cmp	x2, #0x0
    3604:	b5000262 	cbnz	x2, 3650 <buf_grow+0x90>
    3608:	d2800802 	mov	x2, #0x40                  	// #64
    360c:	eb02027f 	cmp	x19, x2
    3610:	54000068 	b.hi	361c <buf_grow+0x5c>  // b.pmore
    3614:	14000005 	b	3628 <buf_grow+0x68>
    3618:	b7f800a2 	tbnz	x2, #63, 362c <buf_grow+0x6c>
    361c:	d37ff842 	lsl	x2, x2, #1
    3620:	eb02027f 	cmp	x19, x2
    3624:	54ffffa8 	b.hi	3618 <buf_grow+0x58>  // b.pmore
    3628:	aa0203f3 	mov	x19, x2
    362c:	f9400280 	ldr	x0, [x20]
    3630:	aa1303e1 	mov	x1, x19
    3634:	97fffc97 	bl	2890 <realloc@plt>
    3638:	b4000100 	cbz	x0, 3658 <buf_grow+0x98>
    363c:	f9000280 	str	x0, [x20]
    3640:	f9000a93 	str	x19, [x20, #16]
    3644:	a94153f3 	ldp	x19, x20, [sp, #16]
    3648:	a8c27bfd 	ldp	x29, x30, [sp], #32
    364c:	d65f03c0 	ret
    3650:	54fffe6a 	b.ge	361c <buf_grow+0x5c>  // b.tcont
    3654:	17fffff6 	b	362c <buf_grow+0x6c>
    3658:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    365c:	f947e863 	ldr	x3, [x3, #4048]
    3660:	d2800262 	mov	x2, #0x13                  	// #19
    3664:	d2800021 	mov	x1, #0x1                   	// #1
    3668:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    366c:	911e6000 	add	x0, x0, #0x798
    3670:	f9400063 	ldr	x3, [x3]
    3674:	97fffccb 	bl	29a0 <fwrite@plt>
    3678:	d2800000 	mov	x0, #0x0                   	// #0
    367c:	97fffcd5 	bl	29d0 <fflush@plt>
    3680:	52800cc0 	mov	w0, #0x66                  	// #102
    3684:	97fffce3 	bl	2a10 <_Exit@plt>
    3688:	d503201f 	nop
    368c:	d503201f 	nop

0000000000003690 <buf_put>:
    3690:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3694:	910003fd 	mov	x29, sp
    3698:	a90153f3 	stp	x19, x20, [sp, #16]
    369c:	aa0003f4 	mov	x20, x0
    36a0:	aa0203f3 	mov	x19, x2
    36a4:	f90013f5 	str	x21, [sp, #32]
    36a8:	aa0103f5 	mov	x21, x1
    36ac:	aa0203e1 	mov	x1, x2
    36b0:	97ffffc4 	bl	35c0 <buf_grow>
    36b4:	a9400283 	ldp	x3, x0, [x20]
    36b8:	aa1503e1 	mov	x1, x21
    36bc:	aa1303e2 	mov	x2, x19
    36c0:	8b000060 	add	x0, x3, x0
    36c4:	97fffc0b 	bl	26f0 <memcpy@plt>
    36c8:	a9400680 	ldp	x0, x1, [x20]
    36cc:	8b010273 	add	x19, x19, x1
    36d0:	f9000693 	str	x19, [x20, #8]
    36d4:	3833681f 	strb	wzr, [x0, x19]
    36d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    36dc:	f94013f5 	ldr	x21, [sp, #32]
    36e0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    36e4:	d65f03c0 	ret
    36e8:	d503201f 	nop
    36ec:	d503201f 	nop

00000000000036f0 <fwp_cancel_tree.part.0>:
    36f0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36f4:	91014022 	add	x2, x1, #0x50
    36f8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36fc:	52800023 	mov	w3, #0x1                   	// #1
    3700:	910003fd 	mov	x29, sp
    3704:	f9404c44 	ldr	x4, [x2, #152]
    3708:	f9000bf3 	str	x19, [sp, #16]
    370c:	39014403 	strb	w3, [x0, #81]
    3710:	eb04001f 	cmp	x0, x4
    3714:	54000160 	b.eq	3740 <fwp_cancel_tree.part.0+0x50>  // b.none
    3718:	f9402804 	ldr	x4, [x0, #80]
    371c:	f2001c9f 	tst	x4, #0xff000000ff
    3720:	54000101 	b.ne	3740 <fwp_cancel_tree.part.0+0x50>  // b.any
    3724:	f9406044 	ldr	x4, [x2, #192]
    3728:	39015003 	strb	w3, [x0, #84]
    372c:	f900801f 	str	xzr, [x0, #256]
    3730:	b40001e4 	cbz	x4, 376c <fwp_cancel_tree.part.0+0x7c>
    3734:	f9008080 	str	x0, [x4, #256]
    3738:	91014021 	add	x1, x1, #0x50
    373c:	f9006020 	str	x0, [x1, #192]
    3740:	f9401413 	ldr	x19, [x0, #40]
    3744:	b40000f3 	cbz	x19, 3760 <fwp_cancel_tree.part.0+0x70>
    3748:	39414261 	ldrb	w1, [x19, #80]
    374c:	aa1303e0 	mov	x0, x19
    3750:	37000041 	tbnz	w1, #0, 3758 <fwp_cancel_tree.part.0+0x68>
    3754:	97ffffe7 	bl	36f0 <fwp_cancel_tree.part.0>
    3758:	f9401a73 	ldr	x19, [x19, #48]
    375c:	b5ffff73 	cbnz	x19, 3748 <fwp_cancel_tree.part.0+0x58>
    3760:	f9400bf3 	ldr	x19, [sp, #16]
    3764:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3768:	d65f03c0 	ret
    376c:	f9006440 	str	x0, [x2, #200]
    3770:	17fffff2 	b	3738 <fwp_cancel_tree.part.0+0x48>

0000000000003774 <fwp_finish_float>:
    3774:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3778:	528005c1 	mov	w1, #0x2e                  	// #46
    377c:	910003fd 	mov	x29, sp
    3780:	f9000bf3 	str	x19, [sp, #16]
    3784:	aa0003f3 	mov	x19, x0
    3788:	97fffc7e 	bl	2980 <strchr@plt>
    378c:	b4000080 	cbz	x0, 379c <fwp_finish_float+0x28>
    3790:	f9400bf3 	ldr	x19, [sp, #16]
    3794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3798:	d65f03c0 	ret
    379c:	aa1303e0 	mov	x0, x19
    37a0:	52800ca1 	mov	w1, #0x65                  	// #101
    37a4:	97fffc77 	bl	2980 <strchr@plt>
    37a8:	b5ffff40 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37ac:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x520>
    37b0:	aa1303e0 	mov	x0, x19
    37b4:	91242021 	add	x1, x1, #0x908
    37b8:	97fffc92 	bl	2a00 <strstr@plt>
    37bc:	b5fffea0 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37c0:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x520>
    37c4:	aa1303e0 	mov	x0, x19
    37c8:	91244021 	add	x1, x1, #0x910
    37cc:	97fffc8d 	bl	2a00 <strstr@plt>
    37d0:	b5fffe00 	cbnz	x0, 3790 <fwp_finish_float+0x1c>
    37d4:	aa1303e0 	mov	x0, x19
    37d8:	97fffbd6 	bl	2730 <strlen@plt>
    37dc:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x520>
    37e0:	91246021 	add	x1, x1, #0x918
    37e4:	8b000262 	add	x2, x19, x0
    37e8:	79400023 	ldrh	w3, [x1]
    37ec:	39400821 	ldrb	w1, [x1, #2]
    37f0:	78206a63 	strh	w3, [x19, x0]
    37f4:	39000841 	strb	w1, [x2, #2]
    37f8:	17ffffe6 	b	3790 <fwp_finish_float+0x1c>
    37fc:	d503201f 	nop

0000000000003800 <fwp_format_g.constprop.0>:
    3800:	d10483ff 	sub	sp, sp, #0x120
    3804:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x520>
    3808:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    380c:	f947f442 	ldr	x2, [x2, #4072]
    3810:	91248084 	add	x4, x4, #0x920
    3814:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3818:	9102c3fd 	add	x29, sp, #0xb0
    381c:	d2800803 	mov	x3, #0x40                  	// #64
    3820:	a90e63f7 	stp	x23, x24, [sp, #224]
    3824:	93407c38 	sxtw	x24, w1
    3828:	aa0303e1 	mov	x1, x3
    382c:	fd008be8 	str	d8, [sp, #272]
    3830:	1e604008 	fmov	d8, d0
    3834:	a90c53f3 	stp	x19, x20, [sp, #192]
    3838:	910083f4 	add	x20, sp, #0x20
    383c:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3840:	aa0003f5 	mov	x21, x0
    3844:	a91073fb 	stp	x27, x28, [sp, #256]
    3848:	5100071c 	sub	w28, w24, #0x1
    384c:	2a1c03e5 	mov	w5, w28
    3850:	f9400040 	ldr	x0, [x2]
    3854:	f90057e0 	str	x0, [sp, #168]
    3858:	d2800000 	mov	x0, #0x0                   	// #0
    385c:	52800042 	mov	w2, #0x2                   	// #2
    3860:	aa1403e0 	mov	x0, x20
    3864:	97fffbeb 	bl	2810 <__snprintf_chk@plt>
    3868:	52800ca1 	mov	w1, #0x65                  	// #101
    386c:	aa1403e0 	mov	x0, x20
    3870:	97fffc44 	bl	2980 <strchr@plt>
    3874:	aa0003f3 	mov	x19, x0
    3878:	52800142 	mov	w2, #0xa                   	// #10
    387c:	91000400 	add	x0, x0, #0x1
    3880:	d2800001 	mov	x1, #0x0                   	// #0
    3884:	97fffc2f 	bl	2940 <strtol@plt>
    3888:	aa0003f7 	mov	x23, x0
    388c:	11001400 	add	w0, w0, #0x5
    3890:	7100541f 	cmp	w0, #0x15
    3894:	54000d68 	b.hi	3a40 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3898:	4b170385 	sub	w5, w28, w23
    389c:	710000bf 	cmp	w5, #0x0
    38a0:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    38a4:	54000b80 	b.eq	3a14 <fwp_format_g.constprop.0+0x214>  // b.none
    38a8:	394083e0 	ldrb	w0, [sp, #32]
    38ac:	cb180273 	sub	x19, x19, x24
    38b0:	91000673 	add	x19, x19, #0x1
    38b4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    38b8:	7100b41f 	cmp	w0, #0x2d
    38bc:	9a941681 	cinc	x1, x20, eq	// eq = none
    38c0:	1a9f17e4 	cset	w4, eq	// eq = none
    38c4:	cb010266 	sub	x6, x19, x1
    38c8:	d10004da 	sub	x26, x6, #0x1
    38cc:	540018a0 	b.eq	3be0 <fwp_format_g.constprop.0+0x3e0>  // b.none
    38d0:	910183f9 	add	x25, sp, #0x60
    38d4:	d280091b 	mov	x27, #0x48                  	// #72
    38d8:	aa1903e7 	mov	x7, x25
    38dc:	91000423 	add	x3, x1, #0x1
    38e0:	91011cc6 	add	x6, x6, #0x47
    38e4:	910004f6 	add	x22, x7, #0x1
    38e8:	37f80ff7 	tbnz	w23, #31, 3ae4 <fwp_format_g.constprop.0+0x2e4>
    38ec:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    38f0:	93407ef7 	sxtw	x23, w23
    38f4:	390000e4 	strb	w4, [x7]
    38f8:	aa1303e1 	mov	x1, x19
    38fc:	aa1703e2 	mov	x2, x23
    3900:	aa1603e0 	mov	x0, x22
    3904:	b9000be5 	str	w5, [sp, #8]
    3908:	cb170374 	sub	x20, x27, x23
    390c:	a9011be3 	stp	x3, x6, [sp, #16]
    3910:	97fffb78 	bl	26f0 <memcpy@plt>
    3914:	d1000694 	sub	x20, x20, #0x1
    3918:	f9400be3 	ldr	x3, [sp, #16]
    391c:	8b1702d6 	add	x22, x22, x23
    3920:	aa1603e0 	mov	x0, x22
    3924:	aa1a03e2 	mov	x2, x26
    3928:	aa0303e1 	mov	x1, x3
    392c:	aa1403e3 	mov	x3, x20
    3930:	97fffbb0 	bl	27f0 <__memcpy_chk@plt>
    3934:	8b1a02d6 	add	x22, x22, x26
    3938:	f9400fe6 	ldr	x6, [sp, #24]
    393c:	d2800900 	mov	x0, #0x48                  	// #72
    3940:	b9400be5 	ldr	w5, [sp, #8]
    3944:	8b170261 	add	x1, x19, x23
    3948:	cb1400c3 	sub	x3, x6, x20
    394c:	cb060294 	sub	x20, x20, x6
    3950:	f101207f 	cmp	x3, #0x48
    3954:	93407cb8 	sxtw	x24, w5
    3958:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    395c:	aa1803e2 	mov	x2, x24
    3960:	8b1802d3 	add	x19, x22, x24
    3964:	8b140063 	add	x3, x3, x20
    3968:	aa1603e0 	mov	x0, x22
    396c:	97fffba1 	bl	27f0 <__memcpy_chk@plt>
    3970:	cb190273 	sub	x19, x19, x25
    3974:	d28031e0 	mov	x0, #0x18f                 	// #399
    3978:	eb00027f 	cmp	x19, x0
    397c:	aa1903e1 	mov	x1, x25
    3980:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3984:	aa1503e0 	mov	x0, x21
    3988:	aa1303e2 	mov	x2, x19
    398c:	97fffb59 	bl	26f0 <memcpy@plt>
    3990:	38336abf 	strb	wzr, [x21, x19]
    3994:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3998:	aa1503e0 	mov	x0, x21
    399c:	97fffb65 	bl	2730 <strlen@plt>
    39a0:	aa0003f3 	mov	x19, x0
    39a4:	528005c1 	mov	w1, #0x2e                  	// #46
    39a8:	aa1503e0 	mov	x0, x21
    39ac:	97fffbf5 	bl	2980 <strchr@plt>
    39b0:	b4000140 	cbz	x0, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b4:	b4000133 	cbz	x19, 39d8 <fwp_format_g.constprop.0+0x1d8>
    39b8:	aa1303e1 	mov	x1, x19
    39bc:	d1000673 	sub	x19, x19, #0x1
    39c0:	38736aa0 	ldrb	w0, [x21, x19]
    39c4:	7100c01f 	cmp	w0, #0x30
    39c8:	54001001 	b.ne	3bc8 <fwp_format_g.constprop.0+0x3c8>  // b.any
    39cc:	38336abf 	strb	wzr, [x21, x19]
    39d0:	b5ffff53 	cbnz	x19, 39b8 <fwp_format_g.constprop.0+0x1b8>
    39d4:	d503201f 	nop
    39d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    39dc:	f947f400 	ldr	x0, [x0, #4072]
    39e0:	f94057e2 	ldr	x2, [sp, #168]
    39e4:	f9400001 	ldr	x1, [x0]
    39e8:	eb010042 	subs	x2, x2, x1
    39ec:	d2800001 	mov	x1, #0x0                   	// #0
    39f0:	54001061 	b.ne	3bfc <fwp_format_g.constprop.0+0x3fc>  // b.any
    39f4:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    39f8:	a94c53f3 	ldp	x19, x20, [sp, #192]
    39fc:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a00:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a04:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a08:	fd408be8 	ldr	d8, [sp, #272]
    3a0c:	910483ff 	add	sp, sp, #0x120
    3a10:	d65f03c0 	ret
    3a14:	1e604100 	fmov	d0, d8
    3a18:	710000bf 	cmp	w5, #0x0
    3a1c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3a20:	aa1503e0 	mov	x0, x21
    3a24:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x520>
    3a28:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a2c:	9124e084 	add	x4, x4, #0x938
    3a30:	52800042 	mov	w2, #0x2                   	// #2
    3a34:	d2803201 	mov	x1, #0x190                 	// #400
    3a38:	97fffb76 	bl	2810 <__snprintf_chk@plt>
    3a3c:	17ffffd7 	b	3998 <fwp_format_g.constprop.0+0x198>
    3a40:	cb140273 	sub	x19, x19, x20
    3a44:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3a48:	910183f9 	add	x25, sp, #0x60
    3a4c:	aa1303e2 	mov	x2, x19
    3a50:	aa1403e1 	mov	x1, x20
    3a54:	aa1903e0 	mov	x0, x25
    3a58:	d2800803 	mov	x3, #0x40                  	// #64
    3a5c:	97fffb65 	bl	27f0 <__memcpy_chk@plt>
    3a60:	38336b3f 	strb	wzr, [x25, x19]
    3a64:	aa1903e0 	mov	x0, x25
    3a68:	528005c1 	mov	w1, #0x2e                  	// #46
    3a6c:	97fffbc5 	bl	2980 <strchr@plt>
    3a70:	b40001c0 	cbz	x0, 3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a74:	b50000b3 	cbnz	x19, 3a88 <fwp_format_g.constprop.0+0x288>
    3a78:	1400000c 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3a7c:	381ff01f 	sturb	wzr, [x0, #-1]
    3a80:	f1000673 	subs	x19, x19, #0x1
    3a84:	54000120 	b.eq	3aa8 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a88:	8b130320 	add	x0, x25, x19
    3a8c:	385ff001 	ldurb	w1, [x0, #-1]
    3a90:	7100c03f 	cmp	w1, #0x30
    3a94:	54ffff40 	b.eq	3a7c <fwp_format_g.constprop.0+0x27c>  // b.none
    3a98:	d1000673 	sub	x19, x19, #0x1
    3a9c:	38736b20 	ldrb	w0, [x25, x19]
    3aa0:	7100b81f 	cmp	w0, #0x2e
    3aa4:	54000a80 	b.eq	3bf4 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3aa8:	710002ff 	cmp	w23, #0x0
    3aac:	528005a1 	mov	w1, #0x2d                  	// #45
    3ab0:	aa1903e5 	mov	x5, x25
    3ab4:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3ab8:	aa1503e0 	mov	x0, x21
    3abc:	52800566 	mov	w6, #0x2b                  	// #43
    3ac0:	d0000044 	adrp	x4, d000 <fwp_main_thread+0x520>
    3ac4:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3ac8:	9124a084 	add	x4, x4, #0x928
    3acc:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3ad0:	52800042 	mov	w2, #0x2                   	// #2
    3ad4:	d2803201 	mov	x1, #0x190                 	// #400
    3ad8:	97fffb4e 	bl	2810 <__snprintf_chk@plt>
    3adc:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3ae0:	17ffffbe 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3ae4:	52800605 	mov	w5, #0x30                  	// #48
    3ae8:	390000e5 	strb	w5, [x7]
    3aec:	d100077b 	sub	x27, x27, #0x1
    3af0:	aa0303e1 	mov	x1, x3
    3af4:	aa1603e0 	mov	x0, x22
    3af8:	aa1b03e3 	mov	x3, x27
    3afc:	aa1a03e2 	mov	x2, x26
    3b00:	f90007e6 	str	x6, [sp, #8]
    3b04:	b90013e4 	str	w4, [sp, #16]
    3b08:	8b1a02d6 	add	x22, x22, x26
    3b0c:	b9001be5 	str	w5, [sp, #24]
    3b10:	97fffb38 	bl	27f0 <__memcpy_chk@plt>
    3b14:	f94007e6 	ldr	x6, [sp, #8]
    3b18:	2a3703e7 	mvn	w7, w23
    3b1c:	b94013e4 	ldr	w4, [sp, #16]
    3b20:	cb1b00c1 	sub	x1, x6, x27
    3b24:	cb06037b 	sub	x27, x27, x6
    3b28:	f101203f 	cmp	x1, #0x48
    3b2c:	d2800906 	mov	x6, #0x48                  	// #72
    3b30:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3b34:	8b1b0023 	add	x3, x1, x27
    3b38:	310006ff 	cmn	w23, #0x1
    3b3c:	54000220 	b.eq	3b80 <fwp_format_g.constprop.0+0x380>  // b.none
    3b40:	b9401be5 	ldr	w5, [sp, #24]
    3b44:	d2800001 	mov	x1, #0x0                   	// #0
    3b48:	f101207f 	cmp	x3, #0x48
    3b4c:	d1000462 	sub	x2, x3, #0x1
    3b50:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3b54:	38216ac5 	strb	w5, [x22, x1]
    3b58:	cb030003 	sub	x3, x0, x3
    3b5c:	91000421 	add	x1, x1, #0x1
    3b60:	91000463 	add	x3, x3, #0x1
    3b64:	eb00007f 	cmp	x3, x0
    3b68:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3b6c:	cb000063 	sub	x3, x3, x0
    3b70:	8b020063 	add	x3, x3, x2
    3b74:	6b0100ff 	cmp	w7, w1
    3b78:	54fffe8c 	b.gt	3b48 <fwp_format_g.constprop.0+0x348>
    3b7c:	8b2742d6 	add	x22, x22, w7, uxtw
    3b80:	f101207f 	cmp	x3, #0x48
    3b84:	d2800905 	mov	x5, #0x48                  	// #72
    3b88:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b8c:	aa1603e0 	mov	x0, x22
    3b90:	cb0300a1 	sub	x1, x5, x3
    3b94:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b98:	91000421 	add	x1, x1, #0x1
    3b9c:	d1000463 	sub	x3, x3, #0x1
    3ba0:	eb05003f 	cmp	x1, x5
    3ba4:	38001402 	strb	w2, [x0], #1
    3ba8:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3bac:	93407f82 	sxtw	x2, w28
    3bb0:	cb050025 	sub	x5, x1, x5
    3bb4:	aa1303e1 	mov	x1, x19
    3bb8:	8b0300a3 	add	x3, x5, x3
    3bbc:	8b1802d3 	add	x19, x22, x24
    3bc0:	97fffb0c 	bl	27f0 <__memcpy_chk@plt>
    3bc4:	17ffff6b 	b	3970 <fwp_format_g.constprop.0+0x170>
    3bc8:	d1000421 	sub	x1, x1, #0x1
    3bcc:	38616aa0 	ldrb	w0, [x21, x1]
    3bd0:	7100b81f 	cmp	w0, #0x2e
    3bd4:	54fff021 	b.ne	39d8 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3bd8:	38216abf 	strb	wzr, [x21, x1]
    3bdc:	17ffff7f 	b	39d8 <fwp_format_g.constprop.0+0x1d8>
    3be0:	910187e7 	add	x7, sp, #0x61
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d28008fb 	mov	x27, #0x47                  	// #71
    3bec:	390183e0 	strb	w0, [sp, #96]
    3bf0:	17ffff3b 	b	38dc <fwp_format_g.constprop.0+0xdc>
    3bf4:	38336b3f 	strb	wzr, [x25, x19]
    3bf8:	17ffffac 	b	3aa8 <fwp_format_g.constprop.0+0x2a8>
    3bfc:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c00:	97fffb28 	bl	28a0 <__stack_chk_fail@plt>

0000000000003c04 <fwp_heap_report>:
    3c04:	d105c3ff 	sub	sp, sp, #0x170
    3c08:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    3c0c:	9118c042 	add	x2, x2, #0x630
    3c10:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    3c14:	f947e821 	ldr	x1, [x1, #4048]
    3c18:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c1c:	910443fd 	add	x29, sp, #0x110
    3c20:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3c24:	f947f400 	ldr	x0, [x0, #4072]
    3c28:	a9135bf5 	stp	x21, x22, [sp, #304]
    3c2c:	a91463f7 	stp	x23, x24, [sp, #320]
    3c30:	a9156bf9 	stp	x25, x26, [sp, #336]
    3c34:	6d1627e8 	stp	d8, d9, [sp, #352]
    3c38:	fd4a1c48 	ldr	d8, [x2, #5176]
    3c3c:	fd4a2049 	ldr	d9, [x2, #5184]
    3c40:	f9400036 	ldr	x22, [x1]
    3c44:	f9400001 	ldr	x1, [x0]
    3c48:	f90087e1 	str	x1, [sp, #264]
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	f949e459 	ldr	x25, [x2, #5064]
    3c54:	d0000041 	adrp	x1, d000 <fwp_main_thread+0x520>
    3c58:	f94a1057 	ldr	x23, [x2, #5152]
    3c5c:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    3c60:	f94a1458 	ldr	x24, [x2, #5160]
    3c64:	91250021 	add	x1, x1, #0x940
    3c68:	91252000 	add	x0, x0, #0x948
    3c6c:	97fffaf1 	bl	2830 <fopen@plt>
    3c70:	b4000760 	cbz	x0, 3d5c <fwp_heap_report+0x158>
    3c74:	528daad5 	mov	w21, #0x6d56                	// #27990
    3c78:	a91253f3 	stp	x19, x20, [sp, #288]
    3c7c:	aa0003f4 	mov	x20, x0
    3c80:	910023f3 	add	x19, sp, #0x8
    3c84:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c88:	72aae915 	movk	w21, #0x5748, lsl #16
    3c8c:	d503201f 	nop
    3c90:	aa1403e2 	mov	x2, x20
    3c94:	aa1303e0 	mov	x0, x19
    3c98:	52802001 	mov	w1, #0x100                 	// #256
    3c9c:	97fffb6d 	bl	2a50 <fgets@plt>
    3ca0:	b4000280 	cbz	x0, 3cf0 <fwp_heap_report+0xec>
    3ca4:	b9400261 	ldr	w1, [x19]
    3ca8:	6b15003f 	cmp	w1, w21
    3cac:	54ffff21 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cb0:	39401260 	ldrb	w0, [x19, #4]
    3cb4:	7101341f 	cmp	w0, #0x4d
    3cb8:	54fffec1 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cbc:	394037e0 	ldrb	w0, [sp, #13]
    3cc0:	7100e81f 	cmp	w0, #0x3a
    3cc4:	54fffe61 	b.ne	3c90 <fwp_heap_report+0x8c>  // b.any
    3cc8:	52800142 	mov	w2, #0xa                   	// #10
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	91003be0 	add	x0, sp, #0xe
    3cd4:	97fffb1b 	bl	2940 <strtol@plt>
    3cd8:	aa1403e2 	mov	x2, x20
    3cdc:	aa0003fa 	mov	x26, x0
    3ce0:	52802001 	mov	w1, #0x100                 	// #256
    3ce4:	aa1303e0 	mov	x0, x19
    3ce8:	97fffb5a 	bl	2a50 <fgets@plt>
    3cec:	b5fffdc0 	cbnz	x0, 3ca4 <fwp_heap_report+0xa0>
    3cf0:	aa1403e0 	mov	x0, x20
    3cf4:	97fffacb 	bl	2820 <fclose@plt>
    3cf8:	a95253f3 	ldp	x19, x20, [sp, #288]
    3cfc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    3d00:	f947f400 	ldr	x0, [x0, #4072]
    3d04:	f94087e2 	ldr	x2, [sp, #264]
    3d08:	f9400001 	ldr	x1, [x0]
    3d0c:	eb010042 	subs	x2, x2, x1
    3d10:	d2800001 	mov	x1, #0x0                   	// #0
    3d14:	54000281 	b.ne	3d64 <fwp_heap_report+0x160>  // b.any
    3d18:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d1c:	aa1a03e6 	mov	x6, x26
    3d20:	aa1903e5 	mov	x5, x25
    3d24:	aa1803e4 	mov	x4, x24
    3d28:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3d2c:	aa1703e3 	mov	x3, x23
    3d30:	a95463f7 	ldp	x23, x24, [sp, #320]
    3d34:	aa1603e0 	mov	x0, x22
    3d38:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3d3c:	1e604121 	fmov	d1, d9
    3d40:	1e604100 	fmov	d0, d8
    3d44:	d0000042 	adrp	x2, d000 <fwp_main_thread+0x520>
    3d48:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3d4c:	9125a042 	add	x2, x2, #0x968
    3d50:	9105c3ff 	add	sp, sp, #0x170
    3d54:	52800041 	mov	w1, #0x2                   	// #2
    3d58:	17fffaee 	b	2910 <__fprintf_chk@plt>
    3d5c:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d60:	17ffffe7 	b	3cfc <fwp_heap_report+0xf8>
    3d64:	a91253f3 	stp	x19, x20, [sp, #288]
    3d68:	97ffface 	bl	28a0 <__stack_chk_fail@plt>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_heap_init>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	f00003a3 	adrp	x3, 7a000 <fwp_heap+0x9d0>
    3d78:	9114c061 	add	x1, x3, #0x530
    3d7c:	910003fd 	mov	x29, sp
    3d80:	a90153f3 	stp	x19, x20, [sp, #16]
    3d84:	d00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    3d88:	9118c262 	add	x2, x19, #0x630
    3d8c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d90:	52800024 	mov	w4, #0x1                   	// #1
    3d94:	52800200 	mov	w0, #0x10                  	// #16
    3d98:	b913a444 	str	w4, [x2, #5028]
    3d9c:	d503201f 	nop
    3da0:	b8004420 	str	w0, [x1], #4
    3da4:	11004000 	add	w0, w0, #0x10
    3da8:	7104401f 	cmp	w0, #0x110
    3dac:	54ffffa1 	b.ne	3da0 <fwp_heap_init+0x30>  // b.any
    3db0:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0x870>
    3db4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3db8:	f00003a1 	adrp	x1, 7a000 <fwp_heap+0x9d0>
    3dbc:	9115c021 	add	x1, x1, #0x570
    3dc0:	3dc1d443 	ldr	q3, [x2, #1872]
    3dc4:	d2800000 	mov	x0, #0x0                   	// #0
    3dc8:	4e040401 	dup	v1.4s, v0.s[0]
    3dcc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3dd0:	0f215400 	shl	v0.2s, v0.2s, #1
    3dd4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3dd8:	3ca06821 	str	q1, [x1, x0]
    3ddc:	91004000 	add	x0, x0, #0x10
    3de0:	f101801f 	cmp	x0, #0x60
    3de4:	54ffff21 	b.ne	3dc8 <fwp_heap_init+0x58>  // b.any
    3de8:	f00003a4 	adrp	x4, 7a000 <fwp_heap+0x9d0>
    3dec:	9114c063 	add	x3, x3, #0x530
    3df0:	91174084 	add	x4, x4, #0x5d0
    3df4:	9118c266 	add	x6, x19, #0x630
    3df8:	d2800002 	mov	x2, #0x0                   	// #0
    3dfc:	d2800000 	mov	x0, #0x0                   	// #0
    3e00:	d2880205 	mov	x5, #0x4010                	// #16400
    3e04:	d503201f 	nop
    3e08:	910f0001 	add	x1, x0, #0x3c0
    3e0c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e10:	eb02003f 	cmp	x1, x2
    3e14:	540000a2 	b.cs	3e28 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e18:	91000400 	add	x0, x0, #0x1
    3e1c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3e20:	eb02003f 	cmp	x1, x2
    3e24:	54ffffa3 	b.cc	3e18 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3e28:	91004042 	add	x2, x2, #0x10
    3e2c:	38001480 	strb	w0, [x4], #1
    3e30:	eb05005f 	cmp	x2, x5
    3e34:	54fffea1 	b.ne	3e08 <fwp_heap_init+0x98>  // b.any
    3e38:	528000b5 	mov	w21, #0x5                   	// #5
    3e3c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3e40:	14000004 	b	3e50 <fwp_heap_init+0xe0>
    3e44:	d342fe94 	lsr	x20, x20, #2
    3e48:	710006b5 	subs	w21, w21, #0x1
    3e4c:	54000720 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3e50:	91404296 	add	x22, x20, #0x10, lsl #12
    3e54:	d2800005 	mov	x5, #0x0                   	// #0
    3e58:	aa1603e1 	mov	x1, x22
    3e5c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e60:	52880443 	mov	w3, #0x4022                	// #16418
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	d2800000 	mov	x0, #0x0                   	// #0
    3e6c:	97fffab1 	bl	2930 <mmap@plt>
    3e70:	aa0003e6 	mov	x6, x0
    3e74:	b100041f 	cmn	x0, #0x1
    3e78:	54fffe60 	b.eq	3e44 <fwp_heap_init+0xd4>  // b.none
    3e7c:	b40005a0 	cbz	x0, 3f30 <fwp_heap_init+0x1c0>
    3e80:	d350fe94 	lsr	x20, x20, #16
    3e84:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e88:	8b0000c7 	add	x7, x6, x0
    3e8c:	9118c275 	add	x21, x19, #0x630
    3e90:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e94:	8b140a81 	add	x1, x20, x20, lsl #2
    3e98:	d2800005 	mov	x5, #0x0                   	// #0
    3e9c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ea0:	d37df021 	lsl	x1, x1, #3
    3ea4:	52880443 	mov	w3, #0x4022                	// #16418
    3ea8:	52800002 	mov	w2, #0x0                   	// #0
    3eac:	d2800000 	mov	x0, #0x0                   	// #0
    3eb0:	f909daa7 	str	x7, [x21, #5040]
    3eb4:	f909dea6 	str	x6, [x21, #5048]
    3eb8:	f909e2b6 	str	x22, [x21, #5056]
    3ebc:	f909eab4 	str	x20, [x21, #5072]
    3ec0:	f90a02a1 	str	x1, [x21, #5120]
    3ec4:	97fffa9b 	bl	2930 <mmap@plt>
    3ec8:	aa0003e1 	mov	x1, x0
    3ecc:	b100041f 	cmn	x0, #0x1
    3ed0:	54000300 	b.eq	3f30 <fwp_heap_init+0x1c0>  // b.none
    3ed4:	d0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    3ed8:	9127c000 	add	x0, x0, #0x9f0
    3edc:	f909fea1 	str	x1, [x21, #5112]
    3ee0:	97fffad4 	bl	2a30 <getenv@plt>
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	aa0003e1 	mov	x1, x0
    3eec:	b40000e0 	cbz	x0, 3f08 <fwp_heap_init+0x198>
    3ef0:	39400000 	ldrb	w0, [x0]
    3ef4:	340000a0 	cbz	w0, 3f08 <fwp_heap_init+0x198>
    3ef8:	7100c000 	subs	w0, w0, #0x30
    3efc:	54000120 	b.eq	3f20 <fwp_heap_init+0x1b0>  // b.none
    3f00:	7100001f 	cmp	w0, #0x0
    3f04:	1a9f07e2 	cset	w2, ne	// ne = any
    3f08:	9118c273 	add	x19, x19, #0x630
    3f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f10:	b913aa62 	str	w2, [x19, #5032]
    3f14:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f18:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f1c:	d65f03c0 	ret
    3f20:	39400420 	ldrb	w0, [x1, #1]
    3f24:	7100001f 	cmp	w0, #0x0
    3f28:	1a9f07e2 	cset	w2, ne	// ne = any
    3f2c:	17fffff7 	b	3f08 <fwp_heap_init+0x198>
    3f30:	97fffc90 	bl	3170 <fwp_heap_oom>

0000000000003f34 <fwp_wake_io>:
    3f34:	b00000e9 	adrp	x9, 20000 <__data_start>
    3f38:	91014122 	add	x2, x9, #0x50
    3f3c:	f9400001 	ldr	x1, [x0]
    3f40:	5280000a 	mov	w10, #0x0                   	// #0
    3f44:	f9406046 	ldr	x6, [x2, #192]
    3f48:	52800008 	mov	w8, #0x0                   	// #0
    3f4c:	4f000400 	movi	v0.4s, #0x0
    3f50:	52800027 	mov	w7, #0x1                   	// #1
    3f54:	aa0103e2 	mov	x2, x1
    3f58:	b4000321 	cbz	x1, 3fbc <fwp_wake_io+0x88>
    3f5c:	f9408c25 	ldr	x5, [x1, #280]
    3f60:	39015c27 	strb	w7, [x1, #87]
    3f64:	b4000165 	cbz	x5, 3f90 <fwp_wake_io+0x5c>
    3f68:	a9520c24 	ldp	x4, x3, [x1, #288]
    3f6c:	b4000364 	cbz	x4, 3fd8 <fwp_wake_io+0xa4>
    3f70:	f9009483 	str	x3, [x4, #296]
    3f74:	f9409423 	ldr	x3, [x1, #296]
    3f78:	b4000043 	cbz	x3, 3f80 <fwp_wake_io+0x4c>
    3f7c:	f9009064 	str	x4, [x3, #288]
    3f80:	91080023 	add	x3, x1, #0x200
    3f84:	f900943f 	str	xzr, [x1, #296]
    3f88:	3c918060 	stur	q0, [x3, #-232]
    3f8c:	f9400001 	ldr	x1, [x0]
    3f90:	f9402843 	ldr	x3, [x2, #80]
    3f94:	f2001c7f 	tst	x3, #0xff000000ff
    3f98:	54fffde1 	b.ne	3f54 <fwp_wake_io+0x20>  // b.any
    3f9c:	39015047 	strb	w7, [x2, #84]
    3fa0:	f900805f 	str	xzr, [x2, #256]
    3fa4:	b40001e6 	cbz	x6, 3fe0 <fwp_wake_io+0xac>
    3fa8:	f90080c2 	str	x2, [x6, #256]
    3fac:	aa0203e6 	mov	x6, x2
    3fb0:	52800028 	mov	w8, #0x1                   	// #1
    3fb4:	aa0103e2 	mov	x2, x1
    3fb8:	b5fffd21 	cbnz	x1, 3f5c <fwp_wake_io+0x28>
    3fbc:	3400006a 	cbz	w10, 3fc8 <fwp_wake_io+0x94>
    3fc0:	91014120 	add	x0, x9, #0x50
    3fc4:	f900640b 	str	x11, [x0, #200]
    3fc8:	34000068 	cbz	w8, 3fd4 <fwp_wake_io+0xa0>
    3fcc:	91014129 	add	x9, x9, #0x50
    3fd0:	f9006126 	str	x6, [x9, #192]
    3fd4:	d65f03c0 	ret
    3fd8:	f90000a3 	str	x3, [x5]
    3fdc:	17ffffe7 	b	3f78 <fwp_wake_io+0x44>
    3fe0:	aa0203eb 	mov	x11, x2
    3fe4:	5280002a 	mov	w10, #0x1                   	// #1
    3fe8:	17fffff1 	b	3fac <fwp_wake_io+0x78>
    3fec:	d503201f 	nop

0000000000003ff0 <ad_raw_free.part.0>:
    3ff0:	b00002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbb0>
    3ff4:	d2800001 	mov	x1, #0x0                   	// #0
    3ff8:	91114082 	add	x2, x4, #0x450
    3ffc:	14000005 	b	4010 <ad_raw_free.part.0+0x20>
    4000:	91000421 	add	x1, x1, #0x1
    4004:	91006042 	add	x2, x2, #0x18
    4008:	f140043f 	cmp	x1, #0x1, lsl #12
    400c:	54000220 	b.eq	4050 <ad_raw_free.part.0+0x60>  // b.none
    4010:	f9400043 	ldr	x3, [x2]
    4014:	eb03001f 	cmp	x0, x3
    4018:	54ffff41 	b.ne	4000 <ad_raw_free.part.0+0x10>  // b.any
    401c:	8b010421 	add	x1, x1, x1, lsl #1
    4020:	91114084 	add	x4, x4, #0x450
    4024:	900000e2 	adrp	x2, 20000 <__data_start>
    4028:	91014042 	add	x2, x2, #0x50
    402c:	8b010c81 	add	x1, x4, x1, lsl #3
    4030:	b9401024 	ldr	w4, [x1, #16]
    4034:	f9400425 	ldr	x5, [x1, #8]
    4038:	a9007c3f 	stp	xzr, xzr, [x1]
    403c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4040:	f900083f 	str	xzr, [x1, #16]
    4044:	cb050061 	sub	x1, x3, x5
    4048:	f8247841 	str	x1, [x2, x4, lsl #3]
    404c:	17fffa45 	b	2960 <free@plt>
    4050:	f100001f 	cmp	x0, #0x0
    4054:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x520>
    4058:	91286021 	add	x1, x1, #0xa18
    405c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4060:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4064:	91280000 	add	x0, x0, #0xa00
    4068:	910003fd 	mov	x29, sp
    406c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4070:	97fffcc4 	bl	3380 <ad_raw_fail>

0000000000004074 <fwp_tape_buffers_dispose>:
    4074:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4078:	910003fd 	mov	x29, sp
    407c:	f9000bf3 	str	x19, [sp, #16]
    4080:	aa0003f3 	mov	x19, x0
    4084:	f9400000 	ldr	x0, [x0]
    4088:	b4000040 	cbz	x0, 4090 <fwp_tape_buffers_dispose+0x1c>
    408c:	97ffffd9 	bl	3ff0 <ad_raw_free.part.0>
    4090:	f9400a60 	ldr	x0, [x19, #16]
    4094:	b4000040 	cbz	x0, 409c <fwp_tape_buffers_dispose+0x28>
    4098:	97ffffd6 	bl	3ff0 <ad_raw_free.part.0>
    409c:	f9401260 	ldr	x0, [x19, #32]
    40a0:	b4000040 	cbz	x0, 40a8 <fwp_tape_buffers_dispose+0x34>
    40a4:	97ffffd3 	bl	3ff0 <ad_raw_free.part.0>
    40a8:	4f000400 	movi	v0.4s, #0x0
    40ac:	f9001a7f 	str	xzr, [x19, #48]
    40b0:	ad000260 	stp	q0, q0, [x19]
    40b4:	3d800a60 	str	q0, [x19, #32]
    40b8:	f9400bf3 	ldr	x19, [sp, #16]
    40bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    40c0:	d65f03c0 	ret

00000000000040c4 <ad_raw_realloc>:
    40c4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    40c8:	910003fd 	mov	x29, sp
    40cc:	a90153f3 	stp	x19, x20, [sp, #16]
    40d0:	f90013f5 	str	x21, [sp, #32]
    40d4:	b40005a1 	cbz	x1, 4188 <ad_raw_realloc+0xc4>
    40d8:	aa0103f4 	mov	x20, x1
    40dc:	2a0203f5 	mov	w21, w2
    40e0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbb0>
    40e4:	d2800004 	mov	x4, #0x0                   	// #0
    40e8:	91114025 	add	x5, x1, #0x450
    40ec:	14000005 	b	4100 <ad_raw_realloc+0x3c>
    40f0:	91000484 	add	x4, x4, #0x1
    40f4:	910060a5 	add	x5, x5, #0x18
    40f8:	f140049f 	cmp	x4, #0x1, lsl #12
    40fc:	54000320 	b.eq	4160 <ad_raw_realloc+0x9c>  // b.none
    4100:	f94000a6 	ldr	x6, [x5]
    4104:	eb06001f 	cmp	x0, x6
    4108:	54ffff41 	b.ne	40f0 <ad_raw_realloc+0x2c>  // b.any
    410c:	8b040484 	add	x4, x4, x4, lsl #1
    4110:	91114021 	add	x1, x1, #0x450
    4114:	8b040c33 	add	x19, x1, x4, lsl #3
    4118:	b4000080 	cbz	x0, 4128 <ad_raw_realloc+0x64>
    411c:	b9401261 	ldr	w1, [x19, #16]
    4120:	6b15003f 	cmp	w1, w21
    4124:	540002c1 	b.ne	417c <ad_raw_realloc+0xb8>  // b.any
    4128:	aa1403e1 	mov	x1, x20
    412c:	97fff9d9 	bl	2890 <realloc@plt>
    4130:	aa0003ed 	mov	x13, x0
    4134:	b40000c0 	cbz	x0, 414c <ad_raw_realloc+0x88>
    4138:	2a1503e3 	mov	w3, w21
    413c:	aa1403e2 	mov	x2, x20
    4140:	aa1303e0 	mov	x0, x19
    4144:	aa0d03e1 	mov	x1, x13
    4148:	97fffb92 	bl	2f90 <ad_raw_record>
    414c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4150:	aa0d03e0 	mov	x0, x13
    4154:	f94013f5 	ldr	x21, [sp, #32]
    4158:	a8c37bfd 	ldp	x29, x30, [sp], #48
    415c:	d65f03c0 	ret
    4160:	f100001f 	cmp	x0, #0x0
    4164:	b0000041 	adrp	x1, d000 <fwp_main_thread+0x520>
    4168:	91286021 	add	x1, x1, #0xa18
    416c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4170:	91280000 	add	x0, x0, #0xa00
    4174:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4178:	97fffc82 	bl	3380 <ad_raw_fail>
    417c:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4180:	91296000 	add	x0, x0, #0xa58
    4184:	97fffc7f 	bl	3380 <ad_raw_fail>
    4188:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    418c:	9128e000 	add	x0, x0, #0xa38
    4190:	97fffc7c 	bl	3380 <ad_raw_fail>

0000000000004194 <fwp_tape_buffers_release>:
    4194:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4198:	910003fd 	mov	x29, sp
    419c:	a90153f3 	stp	x19, x20, [sp, #16]
    41a0:	aa0003f4 	mov	x20, x0
    41a4:	f9401400 	ldr	x0, [x0, #40]
    41a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    41ac:	b7f80560 	tbnz	x0, #63, 4258 <fwp_tape_buffers_release+0xc4>
    41b0:	f9401a93 	ldr	x19, [x20, #48]
    41b4:	b7f80533 	tbnz	x19, #63, 4258 <fwp_tape_buffers_release+0xc4>
    41b8:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    41bc:	eb01001f 	cmp	x0, x1
    41c0:	540004c8 	b.hi	4258 <fwp_tape_buffers_release+0xc4>  // b.pmore
    41c4:	8b000400 	add	x0, x0, x0, lsl #1
    41c8:	d2a00101 	mov	x1, #0x80000               	// #524288
    41cc:	d37df000 	lsl	x0, x0, #3
    41d0:	cb000021 	sub	x1, x1, x0
    41d4:	eb410e7f 	cmp	x19, x1, lsr #3
    41d8:	54000408 	b.hi	4258 <fwp_tape_buffers_release+0xc4>  // b.pmore
    41dc:	8b130c13 	add	x19, x0, x19, lsl #3
    41e0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    41e4:	9129c000 	add	x0, x0, #0xa70
    41e8:	97fffa12 	bl	2a30 <getenv@plt>
    41ec:	b4000080 	cbz	x0, 41fc <fwp_tape_buffers_release+0x68>
    41f0:	39400001 	ldrb	w1, [x0]
    41f4:	7100c03f 	cmp	w1, #0x30
    41f8:	54000880 	b.eq	4308 <fwp_tape_buffers_release+0x174>  // b.none
    41fc:	d1000661 	sub	x1, x19, #0x1
    4200:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4204:	eb00003f 	cmp	x1, x0
    4208:	54000328 	b.hi	426c <fwp_tape_buffers_release+0xd8>  // b.pmore
    420c:	900000f5 	adrp	x21, 20000 <__data_start>
    4210:	f9001bf7 	str	x23, [sp, #48]
    4214:	910142b7 	add	x23, x21, #0x50
    4218:	910342f6 	add	x22, x23, #0xd0
    421c:	aa1603e0 	mov	x0, x22
    4220:	97ffff95 	bl	4074 <fwp_tape_buffers_dispose>
    4224:	ad400a81 	ldp	q1, q2, [x20]
    4228:	f90086f3 	str	x19, [x23, #264]
    422c:	4f000400 	movi	v0.4s, #0x0
    4230:	ad000ac1 	stp	q1, q2, [x22]
    4234:	3dc00a81 	ldr	q1, [x20, #32]
    4238:	3d800ac1 	str	q1, [x22, #32]
    423c:	f9401a80 	ldr	x0, [x20, #48]
    4240:	f9001ac0 	str	x0, [x22, #48]
    4244:	f9001a9f 	str	xzr, [x20, #48]
    4248:	ad000280 	stp	q0, q0, [x20]
    424c:	3d800a80 	str	q0, [x20, #32]
    4250:	f9401bf7 	ldr	x23, [sp, #48]
    4254:	1400000b 	b	4280 <fwp_tape_buffers_release+0xec>
    4258:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    425c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4260:	9129c000 	add	x0, x0, #0xa70
    4264:	97fff9f3 	bl	2a30 <getenv@plt>
    4268:	b5fffc40 	cbnz	x0, 41f0 <fwp_tape_buffers_release+0x5c>
    426c:	aa1403e0 	mov	x0, x20
    4270:	97ffff81 	bl	4074 <fwp_tape_buffers_dispose>
    4274:	900000f5 	adrp	x21, 20000 <__data_start>
    4278:	910142a0 	add	x0, x21, #0x50
    427c:	f9408413 	ldr	x19, [x0, #264]
    4280:	910142a2 	add	x2, x21, #0x50
    4284:	f9408844 	ldr	x4, [x2, #272]
    4288:	a9400c45 	ldp	x5, x3, [x2]
    428c:	8b040481 	add	x1, x4, x4, lsl #1
    4290:	f9400840 	ldr	x0, [x2, #16]
    4294:	8b010881 	add	x1, x4, x1, lsl #2
    4298:	f9400c44 	ldr	x4, [x2, #24]
    429c:	8b0300a3 	add	x3, x5, x3
    42a0:	d37df021 	lsl	x1, x1, #3
    42a4:	8b040000 	add	x0, x0, x4
    42a8:	8b030000 	add	x0, x0, x3
    42ac:	eb05003f 	cmp	x1, x5
    42b0:	54000321 	b.ne	4314 <fwp_tape_buffers_release+0x180>  // b.any
    42b4:	8b130023 	add	x3, x1, x19
    42b8:	eb00007f 	cmp	x3, x0
    42bc:	540002c8 	b.hi	4314 <fwp_tape_buffers_release+0x180>  // b.pmore
    42c0:	f9405c43 	ldr	x3, [x2, #184]
    42c4:	f140087f 	cmp	x3, #0x2, lsl #12
    42c8:	540002e0 	b.eq	4324 <fwp_tape_buffers_release+0x190>  // b.none
    42cc:	8b030464 	add	x4, x3, x3, lsl #1
    42d0:	90000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    42d4:	911140a5 	add	x5, x5, #0x450
    42d8:	cb010000 	sub	x0, x0, x1
    42dc:	d37df084 	lsl	x4, x4, #3
    42e0:	cb130000 	sub	x0, x0, x19
    42e4:	8b0400a6 	add	x6, x5, x4
    42e8:	91000463 	add	x3, x3, #0x1
    42ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    42f0:	f82468a1 	str	x1, [x5, x4]
    42f4:	a90080d3 	stp	x19, x0, [x6, #8]
    42f8:	f9005c43 	str	x3, [x2, #184]
    42fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4300:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4304:	d65f03c0 	ret
    4308:	39400400 	ldrb	w0, [x0, #1]
    430c:	34fffb00 	cbz	w0, 426c <fwp_tape_buffers_release+0xd8>
    4310:	17ffffbb 	b	41fc <fwp_tape_buffers_release+0x68>
    4314:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4318:	912a2000 	add	x0, x0, #0xa88
    431c:	f9001bf7 	str	x23, [sp, #48]
    4320:	97fffc18 	bl	3380 <ad_raw_fail>
    4324:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4328:	912ae000 	add	x0, x0, #0xab8
    432c:	f9001bf7 	str	x23, [sp, #48]
    4330:	97fffc14 	bl	3380 <ad_raw_fail>

0000000000004334 <fwp_trap>:
    4334:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4338:	900000e2 	adrp	x2, 20000 <__data_start>
    433c:	d53bd041 	mrs	x1, tpidr_el0
    4340:	910003fd 	mov	x29, sp
    4344:	f9407042 	ldr	x2, [x2, #224]
    4348:	91400021 	add	x1, x1, #0x0, lsl #12
    434c:	91004021 	add	x1, x1, #0x10
    4350:	a90153f3 	stp	x19, x20, [sp, #16]
    4354:	aa0003f3 	mov	x19, x0
    4358:	f9400034 	ldr	x20, [x1]
    435c:	b4000062 	cbz	x2, 4368 <fwp_trap+0x34>
    4360:	aa0203e0 	mov	x0, x2
    4364:	97fff99b 	bl	29d0 <fflush@plt>
    4368:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    436c:	f947ec00 	ldr	x0, [x0, #4056]
    4370:	f9400000 	ldr	x0, [x0]
    4374:	97fff997 	bl	29d0 <fflush@plt>
    4378:	aa1303e3 	mov	x3, x19
    437c:	b0000042 	adrp	x2, d000 <fwp_main_thread+0x520>
    4380:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc90>
    4384:	f947ea73 	ldr	x19, [x19, #4048]
    4388:	912b6042 	add	x2, x2, #0xad8
    438c:	52800041 	mov	w1, #0x2                   	// #2
    4390:	f9400260 	ldr	x0, [x19]
    4394:	97fff95f 	bl	2910 <__fprintf_chk@plt>
    4398:	b40000b4 	cbz	x20, 43ac <fwp_trap+0x78>
    439c:	f9400260 	ldr	x0, [x19]
    43a0:	97fff98c 	bl	29d0 <fflush@plt>
    43a4:	52800ca0 	mov	w0, #0x65                  	// #101
    43a8:	97fff99a 	bl	2a10 <_Exit@plt>
    43ac:	52800ca0 	mov	w0, #0x65                  	// #101
    43b0:	97fff8e8 	bl	2750 <exit@plt>

00000000000043b4 <fwp_rc_forget_slot.part.0>:
    43b4:	ca404401 	eor	x1, x0, x0, lsr #17
    43b8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    43bc:	ca412421 	eor	x1, x1, x1, lsr #9
    43c0:	910003fd 	mov	x29, sp
    43c4:	92401c21 	and	x1, x1, #0xff
    43c8:	f9000bf3 	str	x19, [sp, #16]
    43cc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    43d0:	9118c262 	add	x2, x19, #0x630
    43d4:	910a2423 	add	x3, x1, #0x289
    43d8:	8b010c41 	add	x1, x2, x1, lsl #3
    43dc:	8b030c43 	add	x3, x2, x3, lsl #3
    43e0:	f94a2421 	ldr	x1, [x1, #5192]
    43e4:	b50000a1 	cbnz	x1, 43f8 <fwp_rc_forget_slot.part.0+0x44>
    43e8:	14000012 	b	4430 <fwp_rc_forget_slot.part.0+0x7c>
    43ec:	91004023 	add	x3, x1, #0x10
    43f0:	f9400821 	ldr	x1, [x1, #16]
    43f4:	b40001e1 	cbz	x1, 4430 <fwp_rc_forget_slot.part.0+0x7c>
    43f8:	f9400022 	ldr	x2, [x1]
    43fc:	eb02001f 	cmp	x0, x2
    4400:	54ffff61 	b.ne	43ec <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4404:	f9400060 	ldr	x0, [x3]
    4408:	9118c273 	add	x19, x19, #0x630
    440c:	f9400801 	ldr	x1, [x0, #16]
    4410:	f9000061 	str	x1, [x3]
    4414:	97fff953 	bl	2960 <free@plt>
    4418:	f94e2660 	ldr	x0, [x19, #7240]
    441c:	d1000400 	sub	x0, x0, #0x1
    4420:	f90e2660 	str	x0, [x19, #7240]
    4424:	f9400bf3 	ldr	x19, [sp, #16]
    4428:	a8c27bfd 	ldp	x29, x30, [sp], #32
    442c:	d65f03c0 	ret
    4430:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4434:	912ba000 	add	x0, x0, #0xae8
    4438:	97ffffbf 	bl	4334 <fwp_trap>
    443c:	d503201f 	nop

0000000000004440 <fwp_rc_prepare_chunk>:
    4440:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4444:	910003fd 	mov	x29, sp
    4448:	a9025bf5 	stp	x21, x22, [sp, #32]
    444c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    4450:	9118c2c2 	add	x2, x22, #0x630
    4454:	b9401c03 	ldr	w3, [x0, #28]
    4458:	aa0103f5 	mov	x21, x1
    445c:	a90153f3 	stp	x19, x20, [sp, #16]
    4460:	aa0003f4 	mov	x20, x0
    4464:	f94e2440 	ldr	x0, [x2, #7240]
    4468:	b4000440 	cbz	x0, 44f0 <fwp_rc_prepare_chunk+0xb0>
    446c:	d2800013 	mov	x19, #0x0                   	// #0
    4470:	35000203 	cbnz	w3, 44b0 <fwp_rc_prepare_chunk+0x70>
    4474:	b4000361 	cbz	x1, 44e0 <fwp_rc_prepare_chunk+0xa0>
    4478:	f9401280 	ldr	x0, [x20, #32]
    447c:	97fff939 	bl	2960 <free@plt>
    4480:	aa1503e0 	mov	x0, x21
    4484:	d2800021 	mov	x1, #0x1                   	// #1
    4488:	97fff8fe 	bl	2880 <calloc@plt>
    448c:	f9001280 	str	x0, [x20, #32]
    4490:	b5000460 	cbnz	x0, 451c <fwp_rc_prepare_chunk+0xdc>
    4494:	97fffb37 	bl	3170 <fwp_heap_oom>
    4498:	97ffffc7 	bl	43b4 <fwp_rc_forget_slot.part.0>
    449c:	91000673 	add	x19, x19, #0x1
    44a0:	b9401e83 	ldr	w3, [x20, #28]
    44a4:	eb13007f 	cmp	x3, x19
    44a8:	54000169 	b.ls	44d4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    44ac:	d503201f 	nop
    44b0:	f9401283 	ldr	x3, [x20, #32]
    44b4:	8b130060 	add	x0, x3, x19
    44b8:	38736863 	ldrb	w3, [x3, x19]
    44bc:	7103fc7f 	cmp	w3, #0xff
    44c0:	54fffec0 	b.eq	4498 <fwp_rc_prepare_chunk+0x58>  // b.none
    44c4:	b9401e83 	ldr	w3, [x20, #28]
    44c8:	91000673 	add	x19, x19, #0x1
    44cc:	eb13007f 	cmp	x3, x19
    44d0:	54ffff08 	b.hi	44b0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    44d4:	eb0302bf 	cmp	x21, x3
    44d8:	54000121 	b.ne	44fc <fwp_rc_prepare_chunk+0xbc>  // b.any
    44dc:	b5000335 	cbnz	x21, 4540 <fwp_rc_prepare_chunk+0x100>
    44e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    44e4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44e8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44ec:	d65f03c0 	ret
    44f0:	2a0303e3 	mov	w3, w3
    44f4:	eb0302bf 	cmp	x21, x3
    44f8:	54ffff20 	b.eq	44dc <fwp_rc_prepare_chunk+0x9c>  // b.none
    44fc:	9118c2c2 	add	x2, x22, #0x630
    4500:	f9401280 	ldr	x0, [x20, #32]
    4504:	f94e2841 	ldr	x1, [x2, #7248]
    4508:	cb030021 	sub	x1, x1, x3
    450c:	f90e2841 	str	x1, [x2, #7248]
    4510:	97fff914 	bl	2960 <free@plt>
    4514:	b5fffb75 	cbnz	x21, 4480 <fwp_rc_prepare_chunk+0x40>
    4518:	f900129f 	str	xzr, [x20, #32]
    451c:	9118c2d6 	add	x22, x22, #0x630
    4520:	f94e2ac0 	ldr	x0, [x22, #7248]
    4524:	b9001e95 	str	w21, [x20, #28]
    4528:	a94153f3 	ldp	x19, x20, [sp, #16]
    452c:	8b150000 	add	x0, x0, x21
    4530:	f90e2ac0 	str	x0, [x22, #7248]
    4534:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4538:	a8c37bfd 	ldp	x29, x30, [sp], #48
    453c:	d65f03c0 	ret
    4540:	f9401280 	ldr	x0, [x20, #32]
    4544:	aa1503e2 	mov	x2, x21
    4548:	a94153f3 	ldp	x19, x20, [sp, #16]
    454c:	52800001 	mov	w1, #0x0                   	// #0
    4550:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4554:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4558:	17fff8c6 	b	2870 <memset@plt>
    455c:	d503201f 	nop

0000000000004560 <fwp_heap_refill>:
    4560:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4564:	910003fd 	mov	x29, sp
    4568:	a9025bf5 	stp	x21, x22, [sp, #32]
    456c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4570:	9118c2b5 	add	x21, x21, #0x630
    4574:	aa0003f6 	mov	x22, x0
    4578:	d2800020 	mov	x0, #0x1                   	// #1
    457c:	a90153f3 	stp	x19, x20, [sp, #16]
    4580:	a90363f7 	stp	x23, x24, [sp, #48]
    4584:	2a0103f7 	mov	w23, w1
    4588:	2a0203f8 	mov	w24, w2
    458c:	97fffb09 	bl	31b0 <fwp_heap_chunks>
    4590:	aa0003f3 	mov	x19, x0
    4594:	f949fea2 	ldr	x2, [x21, #5112]
    4598:	8b000800 	add	x0, x0, x0, lsl #2
    459c:	2a1703e1 	mov	w1, w23
    45a0:	52800025 	mov	w5, #0x1                   	// #1
    45a4:	d37df000 	lsl	x0, x0, #3
    45a8:	910f0021 	add	x1, x1, #0x3c0
    45ac:	8b000054 	add	x20, x2, x0
    45b0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    45b4:	52a00024 	mov	w4, #0x10000               	// #65536
    45b8:	38206845 	strb	w5, [x2, x0]
    45bc:	aa1403e0 	mov	x0, x20
    45c0:	39000698 	strb	w24, [x20, #1]
    45c4:	39000a97 	strb	w23, [x20, #2]
    45c8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    45cc:	b9000681 	str	w1, [x20, #4]
    45d0:	2a0103e5 	mov	w5, w1
    45d4:	8b0300a2 	add	x2, x5, x3
    45d8:	1ac10881 	udiv	w1, w4, w1
    45dc:	9ac50842 	udiv	x2, x2, x5
    45e0:	b9000a81 	str	w1, [x20, #8]
    45e4:	92404021 	and	x1, x1, #0x1ffff
    45e8:	b9001a82 	str	w2, [x20, #24]
    45ec:	97ffff95 	bl	4440 <fwp_rc_prepare_chunk>
    45f0:	f949daa0 	ldr	x0, [x21, #5040]
    45f4:	29408a81 	ldp	w1, w2, [x20, #4]
    45f8:	8b134000 	add	x0, x0, x19, lsl #16
    45fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    4600:	8b214003 	add	x3, x0, w1, uxtw
    4604:	9ba20021 	umaddl	x1, w1, w2, x0
    4608:	a94363f7 	ldp	x23, x24, [sp, #48]
    460c:	a90086c3 	stp	x3, x1, [x22, #8]
    4610:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4614:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4618:	d65f03c0 	ret
    461c:	d503201f 	nop

0000000000004620 <fwp_mem_free>:
    4620:	b40003c0 	cbz	x0, 4698 <fwp_mem_free+0x78>
    4624:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4628:	910003fd 	mov	x29, sp
    462c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4630:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4634:	9118c2a1 	add	x1, x21, #0x630
    4638:	a90153f3 	stp	x19, x20, [sp, #16]
    463c:	aa0003f3 	mov	x19, x0
    4640:	f949d823 	ldr	x3, [x1, #5040]
    4644:	f949ec22 	ldr	x2, [x1, #5080]
    4648:	cb030000 	sub	x0, x0, x3
    464c:	eb02401f 	cmp	x0, x2, lsl #16
    4650:	540001c2 	b.cs	4688 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4654:	d350fc16 	lsr	x22, x0, #16
    4658:	a90363f7 	stp	x23, x24, [sp, #48]
    465c:	f949fc22 	ldr	x2, [x1, #5112]
    4660:	8b160ad4 	add	x20, x22, x22, lsl #2
    4664:	d37df294 	lsl	x20, x20, #3
    4668:	ab140057 	adds	x23, x2, x20
    466c:	540000c0 	b.eq	4684 <fwp_mem_free+0x64>  // b.none
    4670:	38746842 	ldrb	w2, [x2, x20]
    4674:	7100045f 	cmp	w2, #0x1
    4678:	54000120 	b.eq	469c <fwp_mem_free+0x7c>  // b.none
    467c:	7100085f 	cmp	w2, #0x2
    4680:	540005e0 	b.eq	473c <fwp_mem_free+0x11c>  // b.none
    4684:	a94363f7 	ldp	x23, x24, [sp, #48]
    4688:	a94153f3 	ldp	x19, x20, [sp, #16]
    468c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4690:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4694:	d65f03c0 	ret
    4698:	d65f03c0 	ret
    469c:	f94012f8 	ldr	x24, [x23, #32]
    46a0:	b94006e1 	ldr	w1, [x23, #4]
    46a4:	f90023f9 	str	x25, [sp, #64]
    46a8:	2a0103e2 	mov	w2, w1
    46ac:	394006f9 	ldrb	w25, [x23, #1]
    46b0:	39400af4 	ldrb	w20, [x23, #2]
    46b4:	b4000158 	cbz	x24, 46dc <fwp_mem_free+0xbc>
    46b8:	92403e76 	and	x22, x19, #0xffff
    46bc:	9ac20ad6 	udiv	x22, x22, x2
    46c0:	38766b01 	ldrb	w1, [x24, x22]
    46c4:	8b160300 	add	x0, x24, x22
    46c8:	7103fc3f 	cmp	w1, #0xff
    46cc:	54000980 	b.eq	47fc <fwp_mem_free+0x1dc>  // b.none
    46d0:	38366b1f 	strb	wzr, [x24, x22]
    46d4:	b94006e1 	ldr	w1, [x23, #4]
    46d8:	2a0103e2 	mov	w2, w1
    46dc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    46e0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    46e4:	cb390000 	sub	x0, x0, w25, uxtb
    46e8:	8b340074 	add	x20, x3, w20, uxtb
    46ec:	9118c2b5 	add	x21, x21, #0x630
    46f0:	1e630021 	ucvtf	d1, w1
    46f4:	d37ae400 	lsl	x0, x0, #6
    46f8:	8b140c14 	add	x20, x0, x20, lsl #3
    46fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    4700:	f8746aa0 	ldr	x0, [x21, x20]
    4704:	f94023f9 	ldr	x25, [sp, #64]
    4708:	aa2003e0 	mvn	x0, x0
    470c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4710:	f9000260 	str	x0, [x19]
    4714:	f8346ab3 	str	x19, [x21, x20]
    4718:	f94a12a0 	ldr	x0, [x21, #5152]
    471c:	1e612800 	fadd	d0, d0, d1
    4720:	a94153f3 	ldp	x19, x20, [sp, #16]
    4724:	cb020000 	sub	x0, x0, x2
    4728:	f90a12a0 	str	x0, [x21, #5152]
    472c:	fd0a22a0 	str	d0, [x21, #5184]
    4730:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4734:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4738:	d65f03c0 	ret
    473c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4740:	8b000063 	add	x3, x3, x0
    4744:	eb03027f 	cmp	x19, x3
    4748:	54fff9e1 	b.ne	4684 <fwp_mem_free+0x64>  // b.any
    474c:	fd400ae1 	ldr	d1, [x23, #16]
    4750:	fd4a2020 	ldr	d0, [x1, #5184]
    4754:	f9400ae0 	ldr	x0, [x23, #16]
    4758:	7e61d821 	ucvtf	d1, d1
    475c:	f94a1022 	ldr	x2, [x1, #5152]
    4760:	f94012f3 	ldr	x19, [x23, #32]
    4764:	1e612800 	fadd	d0, d0, d1
    4768:	cb000042 	sub	x2, x2, x0
    476c:	f90a1022 	str	x2, [x1, #5152]
    4770:	fd0a2020 	str	d0, [x1, #5184]
    4774:	b40000b3 	cbz	x19, 4788 <fwp_mem_free+0x168>
    4778:	39400260 	ldrb	w0, [x19]
    477c:	7103fc1f 	cmp	w0, #0xff
    4780:	54000380 	b.eq	47f0 <fwp_mem_free+0x1d0>  // b.none
    4784:	3900027f 	strb	wzr, [x19]
    4788:	b9400ee2 	ldr	w2, [x23, #12]
    478c:	b4000142 	cbz	x2, 47b4 <fwp_mem_free+0x194>
    4790:	9118c2a1 	add	x1, x21, #0x630
    4794:	8b160040 	add	x0, x2, x22
    4798:	8b000800 	add	x0, x0, x0, lsl #2
    479c:	f949fc21 	ldr	x1, [x1, #5112]
    47a0:	8b140034 	add	x20, x1, x20
    47a4:	8b000c20 	add	x0, x1, x0, lsl #3
    47a8:	3802869f 	strb	wzr, [x20], #40
    47ac:	eb00029f 	cmp	x20, x0
    47b0:	54ffffc1 	b.ne	47a8 <fwp_mem_free+0x188>  // b.any
    47b4:	9118c2a0 	add	x0, x21, #0x630
    47b8:	f94a1801 	ldr	x1, [x0, #5168]
    47bc:	f949f803 	ldr	x3, [x0, #5104]
    47c0:	8b020021 	add	x1, x1, x2
    47c4:	f90a1801 	str	x1, [x0, #5168]
    47c8:	eb16007f 	cmp	x3, x22
    47cc:	54000049 	b.ls	47d4 <fwp_mem_free+0x1b4>  // b.plast
    47d0:	f909f816 	str	x22, [x0, #5104]
    47d4:	9118c2b5 	add	x21, x21, #0x630
    47d8:	f949f6a0 	ldr	x0, [x21, #5096]
    47dc:	eb16001f 	cmp	x0, x22
    47e0:	54fff529 	b.ls	4684 <fwp_mem_free+0x64>  // b.plast
    47e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47e8:	f909f6b6 	str	x22, [x21, #5096]
    47ec:	17ffffa7 	b	4688 <fwp_mem_free+0x68>
    47f0:	aa1303e0 	mov	x0, x19
    47f4:	97fffef0 	bl	43b4 <fwp_rc_forget_slot.part.0>
    47f8:	17ffffe3 	b	4784 <fwp_mem_free+0x164>
    47fc:	97fffeee 	bl	43b4 <fwp_rc_forget_slot.part.0>
    4800:	17ffffb4 	b	46d0 <fwp_mem_free+0xb0>

0000000000004804 <fwp_rc_wide_dup>:
    4804:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4808:	910003fd 	mov	x29, sp
    480c:	a90153f3 	stp	x19, x20, [sp, #16]
    4810:	aa0003f3 	mov	x19, x0
    4814:	ca404400 	eor	x0, x0, x0, lsr #17
    4818:	f90013f5 	str	x21, [sp, #32]
    481c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4820:	ca402400 	eor	x0, x0, x0, lsr #9
    4824:	9118c2a2 	add	x2, x21, #0x630
    4828:	92401c00 	and	x0, x0, #0xff
    482c:	910a2403 	add	x3, x0, #0x289
    4830:	8b000c40 	add	x0, x2, x0, lsl #3
    4834:	8b030c54 	add	x20, x2, x3, lsl #3
    4838:	f94a2401 	ldr	x1, [x0, #5192]
    483c:	b50000a1 	cbnz	x1, 4850 <fwp_rc_wide_dup+0x4c>
    4840:	14000033 	b	490c <fwp_rc_wide_dup+0x108>
    4844:	91004034 	add	x20, x1, #0x10
    4848:	f9400821 	ldr	x1, [x1, #16]
    484c:	b4000241 	cbz	x1, 4894 <fwp_rc_wide_dup+0x90>
    4850:	f9400022 	ldr	x2, [x1]
    4854:	eb02027f 	cmp	x19, x2
    4858:	54ffff61 	b.ne	4844 <fwp_rc_wide_dup+0x40>  // b.any
    485c:	f9400281 	ldr	x1, [x20]
    4860:	39400260 	ldrb	w0, [x19]
    4864:	7103f81f 	cmp	w0, #0xfe
    4868:	54000220 	b.eq	48ac <fwp_rc_wide_dup+0xa8>  // b.none
    486c:	b40001a1 	cbz	x1, 48a0 <fwp_rc_wide_dup+0x9c>
    4870:	f9400420 	ldr	x0, [x1, #8]
    4874:	b100041f 	cmn	x0, #0x1
    4878:	54000440 	b.eq	4900 <fwp_rc_wide_dup+0xfc>  // b.none
    487c:	91000400 	add	x0, x0, #0x1
    4880:	f9000420 	str	x0, [x1, #8]
    4884:	a94153f3 	ldp	x19, x20, [sp, #16]
    4888:	f94013f5 	ldr	x21, [sp, #32]
    488c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4890:	d65f03c0 	ret
    4894:	39400260 	ldrb	w0, [x19]
    4898:	7103f81f 	cmp	w0, #0xfe
    489c:	54000100 	b.eq	48bc <fwp_rc_wide_dup+0xb8>  // b.none
    48a0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    48a4:	912ba000 	add	x0, x0, #0xae8
    48a8:	97fffea3 	bl	4334 <fwp_trap>
    48ac:	b4000081 	cbz	x1, 48bc <fwp_rc_wide_dup+0xb8>
    48b0:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    48b4:	912c4000 	add	x0, x0, #0xb10
    48b8:	97fffe9f 	bl	4334 <fwp_trap>
    48bc:	d2800300 	mov	x0, #0x18                  	// #24
    48c0:	97fff7e0 	bl	2840 <malloc@plt>
    48c4:	b4000280 	cbz	x0, 4914 <fwp_rc_wide_dup+0x110>
    48c8:	d2801fe1 	mov	x1, #0xff                  	// #255
    48cc:	a9000413 	stp	x19, x1, [x0]
    48d0:	9118c2b5 	add	x21, x21, #0x630
    48d4:	f900081f 	str	xzr, [x0, #16]
    48d8:	12800001 	mov	w1, #0xffffffff            	// #-1
    48dc:	f9000280 	str	x0, [x20]
    48e0:	39000261 	strb	w1, [x19]
    48e4:	f94e26a0 	ldr	x0, [x21, #7240]
    48e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48ec:	91000400 	add	x0, x0, #0x1
    48f0:	f90e26a0 	str	x0, [x21, #7240]
    48f4:	f94013f5 	ldr	x21, [sp, #32]
    48f8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    48fc:	d65f03c0 	ret
    4900:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4904:	912ce000 	add	x0, x0, #0xb38
    4908:	97fffe8b 	bl	4334 <fwp_trap>
    490c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4910:	17ffffd4 	b	4860 <fwp_rc_wide_dup+0x5c>
    4914:	97fffa17 	bl	3170 <fwp_heap_oom>
    4918:	d503201f 	nop
    491c:	d503201f 	nop

0000000000004920 <fwp_closure_drop_push>:
    4920:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4924:	910003fd 	mov	x29, sp
    4928:	a90153f3 	stp	x19, x20, [sp, #16]
    492c:	aa0003f3 	mov	x19, x0
    4930:	a9408014 	ldp	x20, x0, [x0, #8]
    4934:	a9025bf5 	stp	x21, x22, [sp, #32]
    4938:	aa0103f5 	mov	x21, x1
    493c:	a90363f7 	stp	x23, x24, [sp, #48]
    4940:	eb00029f 	cmp	x20, x0
    4944:	54000160 	b.eq	4970 <fwp_closure_drop_push+0x50>  // b.none
    4948:	f9400276 	ldr	x22, [x19]
    494c:	d37df297 	lsl	x23, x20, #3
    4950:	91000694 	add	x20, x20, #0x1
    4954:	f9000674 	str	x20, [x19, #8]
    4958:	a94153f3 	ldp	x19, x20, [sp, #16]
    495c:	f8376ad5 	str	x21, [x22, x23]
    4960:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4964:	a94363f7 	ldp	x23, x24, [sp, #48]
    4968:	a8c57bfd 	ldp	x29, x30, [sp], #80
    496c:	d65f03c0 	ret
    4970:	a9046bf9 	stp	x25, x26, [sp, #64]
    4974:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    4978:	eb00029f 	cmp	x20, x0
    497c:	540003e8 	b.hi	49f8 <fwp_closure_drop_push+0xd8>  // b.pmore
    4980:	d37cee99 	lsl	x25, x20, #4
    4984:	d37ffa9a 	lsl	x26, x20, #1
    4988:	aa1903e0 	mov	x0, x25
    498c:	97fff7ad 	bl	2840 <malloc@plt>
    4990:	aa0003f6 	mov	x22, x0
    4994:	b4000380 	cbz	x0, 4a04 <fwp_closure_drop_push+0xe4>
    4998:	aa1303f8 	mov	x24, x19
    499c:	aa1903e3 	mov	x3, x25
    49a0:	d37df297 	lsl	x23, x20, #3
    49a4:	aa1703e2 	mov	x2, x23
    49a8:	f8418719 	ldr	x25, [x24], #24
    49ac:	aa1903e1 	mov	x1, x25
    49b0:	97fff790 	bl	27f0 <__memcpy_chk@plt>
    49b4:	eb18033f 	cmp	x25, x24
    49b8:	540000a0 	b.eq	49cc <fwp_closure_drop_push+0xac>  // b.none
    49bc:	aa1903e0 	mov	x0, x25
    49c0:	97fff7e8 	bl	2960 <free@plt>
    49c4:	f9400674 	ldr	x20, [x19, #8]
    49c8:	d37df297 	lsl	x23, x20, #3
    49cc:	91000694 	add	x20, x20, #0x1
    49d0:	f9000276 	str	x22, [x19]
    49d4:	f9000a7a 	str	x26, [x19, #16]
    49d8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    49dc:	f9000674 	str	x20, [x19, #8]
    49e0:	f8376ad5 	str	x21, [x22, x23]
    49e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    49e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    49ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    49f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    49f4:	d65f03c0 	ret
    49f8:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    49fc:	912d6000 	add	x0, x0, #0xb58
    4a00:	97fffe4d 	bl	4334 <fwp_trap>
    4a04:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4a08:	f947e863 	ldr	x3, [x3, #4048]
    4a0c:	d2800262 	mov	x2, #0x13                  	// #19
    4a10:	d2800021 	mov	x1, #0x1                   	// #1
    4a14:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4a18:	911e6000 	add	x0, x0, #0x798
    4a1c:	f9400063 	ldr	x3, [x3]
    4a20:	97fff7e0 	bl	29a0 <fwrite@plt>
    4a24:	d2800000 	mov	x0, #0x0                   	// #0
    4a28:	97fff7ea 	bl	29d0 <fflush@plt>
    4a2c:	52800cc0 	mov	w0, #0x66                  	// #102
    4a30:	97fff7f8 	bl	2a10 <_Exit@plt>

0000000000004a34 <fwp_closure_drop.part.0>:
    4a34:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a38:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0x870>
    4a3c:	910003fd 	mov	x29, sp
    4a40:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4a44:	f947f463 	ldr	x3, [x3, #4072]
    4a48:	a90153f3 	stp	x19, x20, [sp, #16]
    4a4c:	d10883ff 	sub	sp, sp, #0x220
    4a50:	910003e2 	mov	x2, sp
    4a54:	d53bd053 	mrs	x19, tpidr_el0
    4a58:	910063f4 	add	x20, sp, #0x18
    4a5c:	3dc1d820 	ldr	q0, [x1, #1888]
    4a60:	91400264 	add	x4, x19, #0x0, lsl #12
    4a64:	91004084 	add	x4, x4, #0x10
    4a68:	aa0003e1 	mov	x1, x0
    4a6c:	aa0203e0 	mov	x0, x2
    4a70:	f9400062 	ldr	x2, [x3]
    4a74:	f9010fe2 	str	x2, [sp, #536]
    4a78:	d2800002 	mov	x2, #0x0                   	// #0
    4a7c:	f90003f4 	str	x20, [sp]
    4a80:	f9000080 	str	x0, [x4]
    4a84:	3c8083e0 	stur	q0, [sp, #8]
    4a88:	97ffffa6 	bl	4920 <fwp_closure_drop_push>
    4a8c:	f94007e0 	ldr	x0, [sp, #8]
    4a90:	b40002e0 	cbz	x0, 4aec <fwp_closure_drop.part.0+0xb8>
    4a94:	f90123f5 	str	x21, [sp, #576]
    4a98:	900000f5 	adrp	x21, 20000 <__data_start>
    4a9c:	910142b5 	add	x21, x21, #0x50
    4aa0:	14000006 	b	4ab8 <fwp_closure_drop.part.0+0x84>
    4aa4:	f9400422 	ldr	x2, [x1, #8]
    4aa8:	52800001 	mov	w1, #0x0                   	// #0
    4aac:	d63f0040 	blr	x2
    4ab0:	f94007e0 	ldr	x0, [sp, #8]
    4ab4:	b40001a0 	cbz	x0, 4ae8 <fwp_closure_drop.part.0+0xb4>
    4ab8:	f94003e1 	ldr	x1, [sp]
    4abc:	d1000400 	sub	x0, x0, #0x1
    4ac0:	f90007e0 	str	x0, [sp, #8]
    4ac4:	f9408ea2 	ldr	x2, [x21, #280]
    4ac8:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    4acc:	b9400001 	ldr	w1, [x0]
    4ad0:	8b011441 	add	x1, x2, x1, lsl #5
    4ad4:	f9400c21 	ldr	x1, [x1, #24]
    4ad8:	b5fffe61 	cbnz	x1, 4aa4 <fwp_closure_drop.part.0+0x70>
    4adc:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4ae0:	912de000 	add	x0, x0, #0xb78
    4ae4:	97fffe14 	bl	4334 <fwp_trap>
    4ae8:	f94123f5 	ldr	x21, [sp, #576]
    4aec:	91400273 	add	x19, x19, #0x0, lsl #12
    4af0:	91004273 	add	x19, x19, #0x10
    4af4:	f94003e0 	ldr	x0, [sp]
    4af8:	f900027f 	str	xzr, [x19]
    4afc:	eb14001f 	cmp	x0, x20
    4b00:	54000040 	b.eq	4b08 <fwp_closure_drop.part.0+0xd4>  // b.none
    4b04:	97fff797 	bl	2960 <free@plt>
    4b08:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4b0c:	f947f400 	ldr	x0, [x0, #4072]
    4b10:	f9410fe2 	ldr	x2, [sp, #536]
    4b14:	f9400001 	ldr	x1, [x0]
    4b18:	eb010042 	subs	x2, x2, x1
    4b1c:	d2800001 	mov	x1, #0x0                   	// #0
    4b20:	540000a1 	b.ne	4b34 <fwp_closure_drop.part.0+0x100>  // b.any
    4b24:	910883ff 	add	sp, sp, #0x220
    4b28:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b2c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b30:	d65f03c0 	ret
    4b34:	f90123f5 	str	x21, [sp, #576]
    4b38:	97fff75a 	bl	28a0 <__stack_chk_fail@plt>
    4b3c:	d503201f 	nop

0000000000004b40 <fwp_tape_of>:
    4b40:	aa0003e1 	mov	x1, x0
    4b44:	92403c00 	and	x0, x0, #0xffff
    4b48:	b40000e0 	cbz	x0, 4b64 <fwp_tape_of+0x24>
    4b4c:	d1000402 	sub	x2, x0, #0x1
    4b50:	900000e0 	adrp	x0, 20000 <__data_start>
    4b54:	91014000 	add	x0, x0, #0x50
    4b58:	f9409003 	ldr	x3, [x0, #288]
    4b5c:	eb02007f 	cmp	x3, x2
    4b60:	540000cc 	b.gt	4b78 <fwp_tape_of+0x38>
    4b64:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4b68:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4b6c:	912ea000 	add	x0, x0, #0xba8
    4b70:	910003fd 	mov	x29, sp
    4b74:	97fffdf0 	bl	4334 <fwp_trap>
    4b78:	8b020443 	add	x3, x2, x2, lsl #1
    4b7c:	f9404404 	ldr	x4, [x0, #136]
    4b80:	8b030842 	add	x2, x2, x3, lsl #2
    4b84:	d37df042 	lsl	x2, x2, #3
    4b88:	8b020080 	add	x0, x4, x2
    4b8c:	b9400403 	ldr	w3, [x0, #4]
    4b90:	34fffea3 	cbz	w3, 4b64 <fwp_tape_of+0x24>
    4b94:	b8626882 	ldr	w2, [x4, x2]
    4b98:	9350fc21 	asr	x1, x1, #16
    4b9c:	6b01005f 	cmp	w2, w1
    4ba0:	54fffe21 	b.ne	4b64 <fwp_tape_of+0x24>  // b.any
    4ba4:	d65f03c0 	ret
    4ba8:	d503201f 	nop
    4bac:	d503201f 	nop

0000000000004bb0 <fwp_now_ns>:
    4bb0:	d100c3ff 	sub	sp, sp, #0x30
    4bb4:	52800020 	mov	w0, #0x1                   	// #1
    4bb8:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    4bbc:	f947f442 	ldr	x2, [x2, #4072]
    4bc0:	910023e1 	add	x1, sp, #0x8
    4bc4:	a9027bfd 	stp	x29, x30, [sp, #32]
    4bc8:	910083fd 	add	x29, sp, #0x20
    4bcc:	f9400043 	ldr	x3, [x2]
    4bd0:	f9000fe3 	str	x3, [sp, #24]
    4bd4:	d2800003 	mov	x3, #0x0                   	// #0
    4bd8:	97fff6fe 	bl	27d0 <clock_gettime@plt>
    4bdc:	350002c0 	cbnz	w0, 4c34 <fwp_now_ns+0x84>
    4be0:	a9408be1 	ldp	x1, x2, [sp, #8]
    4be4:	d2994003 	mov	x3, #0xca00                	// #51712
    4be8:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4bec:	9b037c20 	mul	x0, x1, x3
    4bf0:	9b437c21 	smulh	x1, x1, x3
    4bf4:	ab020000 	adds	x0, x0, x2
    4bf8:	937ffc42 	asr	x2, x2, #63
    4bfc:	9a020021 	adc	x1, x1, x2
    4c00:	f100001f 	cmp	x0, #0x0
    4c04:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4c08:	b50001c1 	cbnz	x1, 4c40 <fwp_now_ns+0x90>
    4c0c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    4c10:	f947f421 	ldr	x1, [x1, #4072]
    4c14:	f9400fe3 	ldr	x3, [sp, #24]
    4c18:	f9400022 	ldr	x2, [x1]
    4c1c:	eb020063 	subs	x3, x3, x2
    4c20:	d2800002 	mov	x2, #0x0                   	// #0
    4c24:	54000141 	b.ne	4c4c <fwp_now_ns+0x9c>  // b.any
    4c28:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4c2c:	9100c3ff 	add	sp, sp, #0x30
    4c30:	d65f03c0 	ret
    4c34:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4c38:	912fe000 	add	x0, x0, #0xbf8
    4c3c:	97fffdbe 	bl	4334 <fwp_trap>
    4c40:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4c44:	91306000 	add	x0, x0, #0xc18
    4c48:	97fffdbb 	bl	4334 <fwp_trap>
    4c4c:	97fff715 	bl	28a0 <__stack_chk_fail@plt>

0000000000004c50 <fwp_poll_events>:
    4c50:	d10103ff 	sub	sp, sp, #0x40
    4c54:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4c58:	f947f400 	ldr	x0, [x0, #4072]
    4c5c:	a9027bfd 	stp	x29, x30, [sp, #32]
    4c60:	910083fd 	add	x29, sp, #0x20
    4c64:	f9001bf3 	str	x19, [sp, #48]
    4c68:	900000f3 	adrp	x19, 20000 <__data_start>
    4c6c:	f9400001 	ldr	x1, [x0]
    4c70:	f9000fe1 	str	x1, [sp, #24]
    4c74:	d2800001 	mov	x1, #0x0                   	// #0
    4c78:	97ffffce 	bl	4bb0 <fwp_now_ns>
    4c7c:	91014261 	add	x1, x19, #0x50
    4c80:	f9409421 	ldr	x1, [x1, #296]
    4c84:	b4000e01 	cbz	x1, 4e44 <fwp_poll_events+0x1f4>
    4c88:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4c8c:	14000005 	b	4ca0 <fwp_poll_events+0x50>
    4c90:	f9408821 	ldr	x1, [x1, #272]
    4c94:	eb03005f 	cmp	x2, x3
    4c98:	9a83d042 	csel	x2, x2, x3, le
    4c9c:	b40000c1 	cbz	x1, 4cb4 <fwp_poll_events+0x64>
    4ca0:	f9403423 	ldr	x3, [x1, #104]
    4ca4:	b6ffff62 	tbz	x2, #63, 4c90 <fwp_poll_events+0x40>
    4ca8:	f9408821 	ldr	x1, [x1, #272]
    4cac:	aa0303e2 	mov	x2, x3
    4cb0:	b5ffff81 	cbnz	x1, 4ca0 <fwp_poll_events+0x50>
    4cb4:	b7f80c82 	tbnz	x2, #63, 4e44 <fwp_poll_events+0x1f4>
    4cb8:	cb000042 	sub	x2, x2, x0
    4cbc:	f100005f 	cmp	x2, #0x0
    4cc0:	540003ad 	b.le	4d34 <fwp_poll_events+0xe4>
    4cc4:	d2869b60 	mov	x0, #0x34db                	// #13531
    4cc8:	d2884804 	mov	x4, #0x4240                	// #16960
    4ccc:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4cd0:	f2a001e4 	movk	x4, #0xf, lsl #16
    4cd4:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4cd8:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4cdc:	f2e86360 	movk	x0, #0x431b, lsl #48
    4ce0:	9b407c40 	smulh	x0, x2, x0
    4ce4:	9352fc00 	asr	x0, x0, #18
    4ce8:	cb82fc00 	sub	x0, x0, x2, asr #63
    4cec:	9b048802 	msub	x2, x0, x4, x2
    4cf0:	f100005f 	cmp	x2, #0x0
    4cf4:	9a800400 	cinc	x0, x0, ne	// ne = any
    4cf8:	eb01001f 	cmp	x0, x1
    4cfc:	5400098c 	b.gt	4e2c <fwp_poll_events+0x1dc>
    4d00:	340001a0 	cbz	w0, 4d34 <fwp_poll_events+0xe4>
    4d04:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4d08:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4d0c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4d10:	9ba17c01 	umull	x1, w0, w1
    4d14:	d366fc23 	lsr	x3, x1, #38
    4d18:	aa0303e2 	mov	x2, x3
    4d1c:	1b058063 	msub	w3, w3, w5, w0
    4d20:	9b247c63 	smull	x3, w3, w4
    4d24:	910023e0 	add	x0, sp, #0x8
    4d28:	d2800001 	mov	x1, #0x0                   	// #0
    4d2c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4d30:	97fff710 	bl	2970 <nanosleep@plt>
    4d34:	97ffff9f 	bl	4bb0 <fwp_now_ns>
    4d38:	91014268 	add	x8, x19, #0x50
    4d3c:	aa0003e7 	mov	x7, x0
    4d40:	4f000400 	movi	v0.4s, #0x0
    4d44:	52800029 	mov	w9, #0x1                   	// #1
    4d48:	f9409506 	ldr	x6, [x8, #296]
    4d4c:	d503201f 	nop
    4d50:	b40003e6 	cbz	x6, 4dcc <fwp_poll_events+0x17c>
    4d54:	f94034c1 	ldr	x1, [x6, #104]
    4d58:	aa0603e5 	mov	x5, x6
    4d5c:	f94088c6 	ldr	x6, [x6, #272]
    4d60:	eb07003f 	cmp	x1, x7
    4d64:	54ffff6c 	b.gt	4d50 <fwp_poll_events+0x100>
    4d68:	394154a0 	ldrb	w0, [x5, #85]
    4d6c:	36000120 	tbz	w0, #0, 4d90 <fwp_poll_events+0x140>
    4d70:	f94084a0 	ldr	x0, [x5, #264]
    4d74:	b4000560 	cbz	x0, 4e20 <fwp_poll_events+0x1d0>
    4d78:	f9008806 	str	x6, [x0, #272]
    4d7c:	b4000046 	cbz	x6, 4d84 <fwp_poll_events+0x134>
    4d80:	f90084c0 	str	x0, [x6, #264]
    4d84:	910800a0 	add	x0, x5, #0x200
    4d88:	390154bf 	strb	wzr, [x5, #85]
    4d8c:	3c908000 	stur	q0, [x0, #-248]
    4d90:	f94030a0 	ldr	x0, [x5, #96]
    4d94:	390158a9 	strb	w9, [x5, #86]
    4d98:	f100001f 	cmp	x0, #0x0
    4d9c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4da0:	540002cd 	b.le	4df8 <fwp_poll_events+0x1a8>
    4da4:	f94028a0 	ldr	x0, [x5, #80]
    4da8:	f2001c1f 	tst	x0, #0xff000000ff
    4dac:	54fffd21 	b.ne	4d50 <fwp_poll_events+0x100>  // b.any
    4db0:	f9406100 	ldr	x0, [x8, #192]
    4db4:	390150a9 	strb	w9, [x5, #84]
    4db8:	f90080bf 	str	xzr, [x5, #256]
    4dbc:	b40002c0 	cbz	x0, 4e14 <fwp_poll_events+0x1c4>
    4dc0:	f9006105 	str	x5, [x8, #192]
    4dc4:	f9008005 	str	x5, [x0, #256]
    4dc8:	b5fffc66 	cbnz	x6, 4d54 <fwp_poll_events+0x104>
    4dcc:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    4dd0:	f947f400 	ldr	x0, [x0, #4072]
    4dd4:	f9400fe2 	ldr	x2, [sp, #24]
    4dd8:	f9400001 	ldr	x1, [x0]
    4ddc:	eb010042 	subs	x2, x2, x1
    4de0:	d2800001 	mov	x1, #0x0                   	// #0
    4de4:	540002e1 	b.ne	4e40 <fwp_poll_events+0x1f0>  // b.any
    4de8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4dec:	f9401bf3 	ldr	x19, [sp, #48]
    4df0:	910103ff 	add	sp, sp, #0x40
    4df4:	d65f03c0 	ret
    4df8:	394144a0 	ldrb	w0, [x5, #81]
    4dfc:	3707fd40 	tbnz	w0, #0, 4da4 <fwp_poll_events+0x154>
    4e00:	394140a0 	ldrb	w0, [x5, #80]
    4e04:	3707fd00 	tbnz	w0, #0, 4da4 <fwp_poll_events+0x154>
    4e08:	aa0503e0 	mov	x0, x5
    4e0c:	97fffa39 	bl	36f0 <fwp_cancel_tree.part.0>
    4e10:	17ffffe5 	b	4da4 <fwp_poll_events+0x154>
    4e14:	f9006105 	str	x5, [x8, #192]
    4e18:	f9006505 	str	x5, [x8, #200]
    4e1c:	17ffffeb 	b	4dc8 <fwp_poll_events+0x178>
    4e20:	91014261 	add	x1, x19, #0x50
    4e24:	f9009426 	str	x6, [x1, #296]
    4e28:	17ffffd5 	b	4d7c <fwp_poll_events+0x12c>
    4e2c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4e30:	d2989362 	mov	x2, #0xc49b                	// #50331
    4e34:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4e38:	f2a00402 	movk	x2, #0x20, lsl #16
    4e3c:	17ffffba 	b	4d24 <fwp_poll_events+0xd4>
    4e40:	97fff698 	bl	28a0 <__stack_chk_fail@plt>
    4e44:	97fff88c 	bl	3074 <fwp_flush>
    4e48:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    4e4c:	f947e863 	ldr	x3, [x3, #4048]
    4e50:	d2800562 	mov	x2, #0x2b                  	// #43
    4e54:	d2800021 	mov	x1, #0x1                   	// #1
    4e58:	b0000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    4e5c:	91310000 	add	x0, x0, #0xc40
    4e60:	f9400063 	ldr	x3, [x3]
    4e64:	97fff6cf 	bl	29a0 <fwrite@plt>
    4e68:	52800ca0 	mov	w0, #0x65                  	// #101
    4e6c:	97fff639 	bl	2750 <exit@plt>

0000000000004e70 <fwp_heap_alloc_big>:
    4e70:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4e74:	910003fd 	mov	x29, sp
    4e78:	a90153f3 	stp	x19, x20, [sp, #16]
    4e7c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e80:	a90363f7 	stp	x23, x24, [sp, #48]
    4e84:	aa0003f7 	mov	x23, x0
    4e88:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e8c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e90:	eb0002ff 	cmp	x23, x0
    4e94:	540008a8 	b.hi	4fa8 <fwp_heap_alloc_big+0x138>  // b.pmore
    4e98:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e9c:	8b0002f4 	add	x20, x23, x0
    4ea0:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbb0>
    4ea4:	9118c359 	add	x25, x26, #0x630
    4ea8:	d350fe94 	lsr	x20, x20, #16
    4eac:	2a0103f5 	mov	w21, w1
    4eb0:	aa1403e0 	mov	x0, x20
    4eb4:	97fff8bf 	bl	31b0 <fwp_heap_chunks>
    4eb8:	f949ff22 	ldr	x2, [x25, #5112]
    4ebc:	8b000813 	add	x19, x0, x0, lsl #2
    4ec0:	aa0003f8 	mov	x24, x0
    4ec4:	52800043 	mov	w3, #0x2                   	// #2
    4ec8:	d37df273 	lsl	x19, x19, #3
    4ecc:	d2800021 	mov	x1, #0x1                   	// #1
    4ed0:	8b130040 	add	x0, x2, x19
    4ed4:	38336843 	strb	w3, [x2, x19]
    4ed8:	39000415 	strb	w21, [x0, #1]
    4edc:	b9000c14 	str	w20, [x0, #12]
    4ee0:	f9000817 	str	x23, [x0, #16]
    4ee4:	97fffd57 	bl	4440 <fwp_rc_prepare_chunk>
    4ee8:	f100069f 	cmp	x20, #0x1
    4eec:	54000289 	b.ls	4f3c <fwp_heap_alloc_big+0xcc>  // b.plast
    4ef0:	8b180294 	add	x20, x20, x24
    4ef4:	9100a273 	add	x19, x19, #0x28
    4ef8:	a90573fb 	stp	x27, x28, [sp, #80]
    4efc:	5280007b 	mov	w27, #0x3                   	// #3
    4f00:	8b140a94 	add	x20, x20, x20, lsl #2
    4f04:	2a1803fc 	mov	w28, w24
    4f08:	9adb2296 	lsl	x22, x20, x27
    4f0c:	d503201f 	nop
    4f10:	f949ff35 	ldr	x21, [x25, #5112]
    4f14:	d2800001 	mov	x1, #0x0                   	// #0
    4f18:	8b1302b4 	add	x20, x21, x19
    4f1c:	aa1403e0 	mov	x0, x20
    4f20:	97fffd48 	bl	4440 <fwp_rc_prepare_chunk>
    4f24:	38336abb 	strb	w27, [x21, x19]
    4f28:	9100a273 	add	x19, x19, #0x28
    4f2c:	b9000e9c 	str	w28, [x20, #12]
    4f30:	eb1302df 	cmp	x22, x19
    4f34:	54fffee1 	b.ne	4f10 <fwp_heap_alloc_big+0xa0>  // b.any
    4f38:	a94573fb 	ldp	x27, x28, [sp, #80]
    4f3c:	9118c353 	add	x19, x26, #0x630
    4f40:	aa1703e2 	mov	x2, x23
    4f44:	52800001 	mov	w1, #0x0                   	// #0
    4f48:	f949da60 	ldr	x0, [x19, #5040]
    4f4c:	8b184018 	add	x24, x0, x24, lsl #16
    4f50:	aa1803e0 	mov	x0, x24
    4f54:	97fff647 	bl	2870 <memset@plt>
    4f58:	f94a1260 	ldr	x0, [x19, #5152]
    4f5c:	ab170000 	adds	x0, x0, x23
    4f60:	54000242 	b.cs	4fa8 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4f64:	f94a1661 	ldr	x1, [x19, #5160]
    4f68:	f90a1260 	str	x0, [x19, #5152]
    4f6c:	eb01001f 	cmp	x0, x1
    4f70:	54000049 	b.ls	4f78 <fwp_heap_alloc_big+0x108>  // b.plast
    4f74:	f90a1660 	str	x0, [x19, #5160]
    4f78:	9118c35a 	add	x26, x26, #0x630
    4f7c:	9e6202e0 	scvtf	d0, x23
    4f80:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f84:	aa1803e0 	mov	x0, x24
    4f88:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f90:	1e602820 	fadd	d0, d1, d0
    4f94:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f98:	fd0a1f40 	str	d0, [x26, #5176]
    4f9c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4fa0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4fa4:	d65f03c0 	ret
    4fa8:	a90573fb 	stp	x27, x28, [sp, #80]
    4fac:	97fff871 	bl	3170 <fwp_heap_oom>

0000000000004fb0 <fwp_heap_alloc_slow>:
    4fb0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4fb4:	910003fd 	mov	x29, sp
    4fb8:	a90153f3 	stp	x19, x20, [sp, #16]
    4fbc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4fc0:	9118c262 	add	x2, x19, #0x630
    4fc4:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fc8:	aa0003f5 	mov	x21, x0
    4fcc:	2a0103f4 	mov	w20, w1
    4fd0:	b953a440 	ldr	w0, [x2, #5028]
    4fd4:	34000600 	cbz	w0, 5094 <fwp_heap_alloc_slow+0xe4>
    4fd8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4fdc:	54000628 	b.hi	50a0 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4fe0:	91003ea0 	add	x0, x21, #0xf
    4fe4:	9118c262 	add	x2, x19, #0x630
    4fe8:	f9001bf7 	str	x23, [sp, #48]
    4fec:	937c7e84 	sbfiz	x4, x20, #4, #32
    4ff0:	8b401040 	add	x0, x2, x0, lsr #4
    4ff4:	cb34c084 	sub	x4, x4, w20, sxtw
    4ff8:	d37ae484 	lsl	x4, x4, #6
    4ffc:	397e8003 	ldrb	w3, [x0, #4000]
    5000:	910f0060 	add	x0, x3, #0x3c0
    5004:	aa0303e1 	mov	x1, x3
    5008:	8b030463 	add	x3, x3, x3, lsl #1
    500c:	8b030c83 	add	x3, x4, x3, lsl #3
    5010:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    5014:	2a1703f6 	mov	w22, w23
    5018:	f8636844 	ldr	x4, [x2, x3]
    501c:	b40004e4 	cbz	x4, 50b8 <fwp_heap_alloc_slow+0x108>
    5020:	f9400080 	ldr	x0, [x4]
    5024:	aa2003e0 	mvn	x0, x0
    5028:	f8236840 	str	x0, [x2, x3]
    502c:	7100069f 	cmp	w20, #0x1
    5030:	aa0403e0 	mov	x0, x4
    5034:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    5038:	52800001 	mov	w1, #0x0                   	// #0
    503c:	97fff60d 	bl	2870 <memset@plt>
    5040:	aa0003e4 	mov	x4, x0
    5044:	9118c260 	add	x0, x19, #0x630
    5048:	f94a1001 	ldr	x1, [x0, #5152]
    504c:	ab160021 	adds	x1, x1, x22
    5050:	540005c2 	b.cs	5108 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    5054:	f94a1402 	ldr	x2, [x0, #5160]
    5058:	f90a1001 	str	x1, [x0, #5152]
    505c:	eb02003f 	cmp	x1, x2
    5060:	54000049 	b.ls	5068 <fwp_heap_alloc_slow+0xb8>  // b.plast
    5064:	f90a1401 	str	x1, [x0, #5160]
    5068:	9118c273 	add	x19, x19, #0x630
    506c:	1e6302e1 	ucvtf	d1, w23
    5070:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5074:	aa0403e0 	mov	x0, x4
    5078:	fd4a1e60 	ldr	d0, [x19, #5176]
    507c:	f9401bf7 	ldr	x23, [sp, #48]
    5080:	1e612800 	fadd	d0, d0, d1
    5084:	fd0a1e60 	str	d0, [x19, #5176]
    5088:	a94153f3 	ldp	x19, x20, [sp, #16]
    508c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5090:	d65f03c0 	ret
    5094:	97fffb37 	bl	3d70 <fwp_heap_init>
    5098:	f14012bf 	cmp	x21, #0x4, lsl #12
    509c:	54fffa29 	b.ls	4fe0 <fwp_heap_alloc_slow+0x30>  // b.plast
    50a0:	2a1403e1 	mov	w1, w20
    50a4:	aa1503e0 	mov	x0, x21
    50a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    50ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    50b0:	a8c47bfd 	ldp	x29, x30, [sp], #64
    50b4:	17ffff6f 	b	4e70 <fwp_heap_alloc_big>
    50b8:	8b030042 	add	x2, x2, x3
    50bc:	f9400444 	ldr	x4, [x2, #8]
    50c0:	b4000104 	cbz	x4, 50e0 <fwp_heap_alloc_slow+0x130>
    50c4:	f9400840 	ldr	x0, [x2, #16]
    50c8:	cb040000 	sub	x0, x0, x4
    50cc:	eb16001f 	cmp	x0, x22
    50d0:	54000083 	b.cc	50e0 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    50d4:	8b160080 	add	x0, x4, x22
    50d8:	f9000440 	str	x0, [x2, #8]
    50dc:	17ffffd4 	b	502c <fwp_heap_alloc_slow+0x7c>
    50e0:	52800302 	mov	w2, #0x18                  	// #24
    50e4:	52807804 	mov	w4, #0x3c0                 	// #960
    50e8:	9118c260 	add	x0, x19, #0x630
    50ec:	9ba27c23 	umull	x3, w1, w2
    50f0:	2a1403e2 	mov	w2, w20
    50f4:	9b240e84 	smaddl	x4, w20, w4, x3
    50f8:	8b040000 	add	x0, x0, x4
    50fc:	97fffd19 	bl	4560 <fwp_heap_refill>
    5100:	aa0003e4 	mov	x4, x0
    5104:	17ffffca 	b	502c <fwp_heap_alloc_slow+0x7c>
    5108:	97fff81a 	bl	3170 <fwp_heap_oom>
    510c:	d503201f 	nop

0000000000005110 <fwp_heap_alloc>:
    5110:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5114:	910003fd 	mov	x29, sp
    5118:	a9025bf5 	stp	x21, x22, [sp, #32]
    511c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5120:	910142c2 	add	x2, x22, #0x50
    5124:	a90363f7 	stp	x23, x24, [sp, #48]
    5128:	b9413058 	ldr	w24, [x2, #304]
    512c:	a90153f3 	stp	x19, x20, [sp, #16]
    5130:	7100031f 	cmp	w24, #0x0
    5134:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    5138:	540008a1 	b.ne	524c <fwp_heap_alloc+0x13c>  // b.any
    513c:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    5140:	9118c2f3 	add	x19, x23, #0x630
    5144:	f140101f 	cmp	x0, #0x4, lsl #12
    5148:	b953a662 	ldr	w2, [x19, #5028]
    514c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    5150:	54000740 	b.eq	5238 <fwp_heap_alloc+0x128>  // b.none
    5154:	91003c03 	add	x3, x0, #0xf
    5158:	937c7c22 	sbfiz	x2, x1, #4, #32
    515c:	cb21c042 	sub	x2, x2, w1, sxtw
    5160:	8b431263 	add	x3, x19, x3, lsr #4
    5164:	d37ae442 	lsl	x2, x2, #6
    5168:	397e8063 	ldrb	w3, [x3, #4000]
    516c:	910f0064 	add	x4, x3, #0x3c0
    5170:	8b030463 	add	x3, x3, x3, lsl #1
    5174:	8b030c43 	add	x3, x2, x3, lsl #3
    5178:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    517c:	2a1503f4 	mov	w20, w21
    5180:	f8636a64 	ldr	x4, [x19, x3]
    5184:	b40004c4 	cbz	x4, 521c <fwp_heap_alloc+0x10c>
    5188:	f9400085 	ldr	x5, [x4]
    518c:	7100043f 	cmp	w1, #0x1
    5190:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5194:	aa0403e0 	mov	x0, x4
    5198:	aa2503e5 	mvn	x5, x5
    519c:	52800001 	mov	w1, #0x0                   	// #0
    51a0:	f8236a65 	str	x5, [x19, x3]
    51a4:	97fff5b3 	bl	2870 <memset@plt>
    51a8:	aa0003e4 	mov	x4, x0
    51ac:	f94a1260 	ldr	x0, [x19, #5152]
    51b0:	ab140000 	adds	x0, x0, x20
    51b4:	54000722 	b.cs	5298 <fwp_heap_alloc+0x188>  // b.hs, b.nlast
    51b8:	f94a1661 	ldr	x1, [x19, #5160]
    51bc:	f90a1260 	str	x0, [x19, #5152]
    51c0:	eb01001f 	cmp	x0, x1
    51c4:	54000049 	b.ls	51cc <fwp_heap_alloc+0xbc>  // b.plast
    51c8:	f90a1660 	str	x0, [x19, #5160]
    51cc:	9118c2e0 	add	x0, x23, #0x630
    51d0:	1e6302a1 	ucvtf	d1, w21
    51d4:	fd4a1c00 	ldr	d0, [x0, #5176]
    51d8:	1e612800 	fadd	d0, d0, d1
    51dc:	fd0a1c00 	str	d0, [x0, #5176]
    51e0:	34000138 	cbz	w24, 5204 <fwp_heap_alloc+0xf4>
    51e4:	9118c2e1 	add	x1, x23, #0x630
    51e8:	910142c0 	add	x0, x22, #0x50
    51ec:	fd4a1020 	ldr	d0, [x1, #5152]
    51f0:	6d548402 	ldp	d2, d1, [x0, #328]
    51f4:	7e61d800 	ucvtf	d0, d0
    51f8:	1e623800 	fsub	d0, d0, d2
    51fc:	1e612010 	fcmpe	d0, d1
    5200:	5400030c 	b.gt	5260 <fwp_heap_alloc+0x150>
    5204:	a94153f3 	ldp	x19, x20, [sp, #16]
    5208:	aa0403e0 	mov	x0, x4
    520c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5210:	a94363f7 	ldp	x23, x24, [sp, #48]
    5214:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5218:	d65f03c0 	ret
    521c:	8b030263 	add	x3, x19, x3
    5220:	f9400464 	ldr	x4, [x3, #8]
    5224:	b40000a4 	cbz	x4, 5238 <fwp_heap_alloc+0x128>
    5228:	f9400862 	ldr	x2, [x3, #16]
    522c:	cb040042 	sub	x2, x2, x4
    5230:	eb02029f 	cmp	x20, x2
    5234:	54000249 	b.ls	527c <fwp_heap_alloc+0x16c>  // b.plast
    5238:	97ffff5e 	bl	4fb0 <fwp_heap_alloc_slow>
    523c:	aa0003e4 	mov	x4, x0
    5240:	910142c1 	add	x1, x22, #0x50
    5244:	b9413038 	ldr	w24, [x1, #304]
    5248:	17ffffe6 	b	51e0 <fwp_heap_alloc+0xd0>
    524c:	a9538c44 	ldp	x4, x3, [x2, #312]
    5250:	91000484 	add	x4, x4, #0x1
    5254:	8b000063 	add	x3, x3, x0
    5258:	a9138c44 	stp	x4, x3, [x2, #312]
    525c:	17ffffb8 	b	513c <fwp_heap_alloc+0x2c>
    5260:	a94153f3 	ldp	x19, x20, [sp, #16]
    5264:	fd00a800 	str	d0, [x0, #336]
    5268:	a9425bf5 	ldp	x21, x22, [sp, #32]
    526c:	aa0403e0 	mov	x0, x4
    5270:	a94363f7 	ldp	x23, x24, [sp, #48]
    5274:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5278:	d65f03c0 	ret
    527c:	7100043f 	cmp	w1, #0x1
    5280:	8b140085 	add	x5, x4, x20
    5284:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5288:	52800001 	mov	w1, #0x0                   	// #0
    528c:	aa0403e0 	mov	x0, x4
    5290:	f9000465 	str	x5, [x3, #8]
    5294:	17ffffc4 	b	51a4 <fwp_heap_alloc+0x94>
    5298:	97fff7b6 	bl	3170 <fwp_heap_oom>
    529c:	d503201f 	nop

00000000000052a0 <fwp_data.part.0.constprop.0>:
    52a0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    52a4:	910003fd 	mov	x29, sp
    52a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    52ac:	f00000d6 	adrp	x22, 20000 <__data_start>
    52b0:	910142c2 	add	x2, x22, #0x50
    52b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    52b8:	b9413059 	ldr	w25, [x2, #304]
    52bc:	a90153f3 	stp	x19, x20, [sp, #16]
    52c0:	aa0103f4 	mov	x20, x1
    52c4:	a90363f7 	stp	x23, x24, [sp, #48]
    52c8:	2a0003f7 	mov	w23, w0
    52cc:	340000b9 	cbz	w25, 52e0 <fwp_data.part.0.constprop.0+0x40>
    52d0:	a9538041 	ldp	x1, x0, [x2, #312]
    52d4:	91000421 	add	x1, x1, #0x1
    52d8:	91006000 	add	x0, x0, #0x18
    52dc:	a9138041 	stp	x1, x0, [x2, #312]
    52e0:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    52e4:	9118c2a3 	add	x3, x21, #0x630
    52e8:	b953a460 	ldr	w0, [x3, #5028]
    52ec:	34000840 	cbz	w0, 53f4 <fwp_data.part.0.constprop.0+0x154>
    52f0:	397e8862 	ldrb	w2, [x3, #4002]
    52f4:	910f0040 	add	x0, x2, #0x3c0
    52f8:	8b020442 	add	x2, x2, x2, lsl #1
    52fc:	d37df042 	lsl	x2, x2, #3
    5300:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5304:	2a1a03f8 	mov	w24, w26
    5308:	f8626873 	ldr	x19, [x3, x2]
    530c:	b4000613 	cbz	x19, 53cc <fwp_data.part.0.constprop.0+0x12c>
    5310:	f9400260 	ldr	x0, [x19]
    5314:	aa2003e0 	mvn	x0, x0
    5318:	f8226860 	str	x0, [x3, x2]
    531c:	f100631f 	cmp	x24, #0x18
    5320:	540000e9 	b.ls	533c <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5324:	d1006702 	sub	x2, x24, #0x19
    5328:	91006260 	add	x0, x19, #0x18
    532c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5330:	52800001 	mov	w1, #0x0                   	// #0
    5334:	91002042 	add	x2, x2, #0x8
    5338:	97fff54e 	bl	2870 <memset@plt>
    533c:	9118c2a0 	add	x0, x21, #0x630
    5340:	f94a1001 	ldr	x1, [x0, #5152]
    5344:	ab180021 	adds	x1, x1, x24
    5348:	54000682 	b.cs	5418 <fwp_data.part.0.constprop.0+0x178>  // b.hs, b.nlast
    534c:	f94a1402 	ldr	x2, [x0, #5160]
    5350:	f90a1001 	str	x1, [x0, #5152]
    5354:	eb02003f 	cmp	x1, x2
    5358:	54000049 	b.ls	5360 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    535c:	f90a1401 	str	x1, [x0, #5160]
    5360:	9118c2a0 	add	x0, x21, #0x630
    5364:	1e630341 	ucvtf	d1, w26
    5368:	fd4a1c00 	ldr	d0, [x0, #5176]
    536c:	1e612800 	fadd	d0, d0, d1
    5370:	fd0a1c00 	str	d0, [x0, #5176]
    5374:	34000139 	cbz	w25, 5398 <fwp_data.part.0.constprop.0+0xf8>
    5378:	9118c2b5 	add	x21, x21, #0x630
    537c:	910142d6 	add	x22, x22, #0x50
    5380:	fd4a12a0 	ldr	d0, [x21, #5152]
    5384:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5388:	7e61d800 	ucvtf	d0, d0
    538c:	1e623800 	fsub	d0, d0, d2
    5390:	1e612010 	fcmpe	d0, d1
    5394:	540003ec 	b.gt	5410 <fwp_data.part.0.constprop.0+0x170>
    5398:	52800040 	mov	w0, #0x2                   	// #2
    539c:	29000277 	stp	w23, w0, [x19]
    53a0:	aa1303e0 	mov	x0, x19
    53a4:	f9400281 	ldr	x1, [x20]
    53a8:	f9000661 	str	x1, [x19, #8]
    53ac:	f9400681 	ldr	x1, [x20, #8]
    53b0:	f9000a61 	str	x1, [x19, #16]
    53b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53bc:	a94363f7 	ldp	x23, x24, [sp, #48]
    53c0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53c4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53c8:	d65f03c0 	ret
    53cc:	8b020063 	add	x3, x3, x2
    53d0:	f9400473 	ldr	x19, [x3, #8]
    53d4:	b4000113 	cbz	x19, 53f4 <fwp_data.part.0.constprop.0+0x154>
    53d8:	f9400860 	ldr	x0, [x3, #16]
    53dc:	cb130000 	sub	x0, x0, x19
    53e0:	eb00031f 	cmp	x24, x0
    53e4:	54000088 	b.hi	53f4 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    53e8:	8b180260 	add	x0, x19, x24
    53ec:	f9000460 	str	x0, [x3, #8]
    53f0:	17ffffcb 	b	531c <fwp_data.part.0.constprop.0+0x7c>
    53f4:	52800001 	mov	w1, #0x0                   	// #0
    53f8:	d2800300 	mov	x0, #0x18                  	// #24
    53fc:	97ffff45 	bl	5110 <fwp_heap_alloc>
    5400:	aa0003f3 	mov	x19, x0
    5404:	910142c1 	add	x1, x22, #0x50
    5408:	b9413039 	ldr	w25, [x1, #304]
    540c:	17ffffda 	b	5374 <fwp_data.part.0.constprop.0+0xd4>
    5410:	fd00aac0 	str	d0, [x22, #336]
    5414:	17ffffe1 	b	5398 <fwp_data.part.0.constprop.0+0xf8>
    5418:	97fff756 	bl	3170 <fwp_heap_oom>
    541c:	d503201f 	nop

0000000000005420 <fwp_tape_reserve>:
    5420:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5424:	910003fd 	mov	x29, sp
    5428:	a90153f3 	stp	x19, x20, [sp, #16]
    542c:	aa0003f3 	mov	x19, x0
    5430:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5434:	eb00003f 	cmp	x1, x0
    5438:	54000888 	b.hi	5548 <fwp_tape_reserve+0x128>  // b.pmore
    543c:	f9400e74 	ldr	x20, [x19, #24]
    5440:	eb01029f 	cmp	x20, x1
    5444:	5400078a 	b.ge	5534 <fwp_tape_reserve+0x114>  // b.tcont
    5448:	f100029f 	cmp	x20, #0x0
    544c:	d2800802 	mov	x2, #0x40                  	// #64
    5450:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    5454:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    5458:	a9025bf5 	stp	x21, x22, [sp, #32]
    545c:	a90363f7 	stp	x23, x24, [sp, #48]
    5460:	eb01029f 	cmp	x20, x1
    5464:	5400008a 	b.ge	5474 <fwp_tape_reserve+0x54>  // b.tcont
    5468:	eb00029f 	cmp	x20, x0
    546c:	540006ad 	b.le	5540 <fwp_tape_reserve+0x120>
    5470:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5474:	a940d663 	ldp	x3, x21, [x19, #8]
    5478:	d37df297 	lsl	x23, x20, #3
    547c:	f9401260 	ldr	x0, [x19, #32]
    5480:	aa1703e1 	mov	x1, x23
    5484:	f9403276 	ldr	x22, [x19, #96]
    5488:	52800022 	mov	w2, #0x1                   	// #1
    548c:	cb0302b5 	sub	x21, x21, x3
    5490:	97fffb0d 	bl	40c4 <ad_raw_realloc>
    5494:	b4000aa0 	cbz	x0, 55e8 <fwp_tape_reserve+0x1c8>
    5498:	f9400e61 	ldr	x1, [x19, #24]
    549c:	8b010801 	add	x1, x0, x1, lsl #2
    54a0:	a9020660 	stp	x0, x1, [x19, #32]
    54a4:	b4000856 	cbz	x22, 55ac <fwp_tape_reserve+0x18c>
    54a8:	f94032d7 	ldr	x23, [x22, #96]
    54ac:	eb17029f 	cmp	x20, x23
    54b0:	5400034d 	b.le	5518 <fwp_tape_reserve+0xf8>
    54b4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54b8:	d37cee9a 	lsl	x26, x20, #4
    54bc:	aa1a03e0 	mov	x0, x26
    54c0:	f94022d9 	ldr	x25, [x22, #64]
    54c4:	52800041 	mov	w1, #0x2                   	// #2
    54c8:	97ffff12 	bl	5110 <fwp_heap_alloc>
    54cc:	aa0003f8 	mov	x24, x0
    54d0:	b4000119 	cbz	x25, 54f0 <fwp_tape_reserve+0xd0>
    54d4:	d37ceef7 	lsl	x23, x23, #4
    54d8:	aa1903e1 	mov	x1, x25
    54dc:	eb1a02ff 	cmp	x23, x26
    54e0:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    54e4:	97fff483 	bl	26f0 <memcpy@plt>
    54e8:	aa1903e0 	mov	x0, x25
    54ec:	97fffc4d 	bl	4620 <fwp_mem_free>
    54f0:	f94032c0 	ldr	x0, [x22, #96]
    54f4:	52800001 	mov	w1, #0x0                   	// #0
    54f8:	cb000282 	sub	x2, x20, x0
    54fc:	8b001300 	add	x0, x24, x0, lsl #4
    5500:	d37cec42 	lsl	x2, x2, #4
    5504:	97fff4db 	bl	2870 <memset@plt>
    5508:	f9401260 	ldr	x0, [x19, #32]
    550c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5510:	f90022d8 	str	x24, [x22, #64]
    5514:	f90032d4 	str	x20, [x22, #96]
    5518:	d37ef696 	lsl	x22, x20, #2
    551c:	b5000315 	cbnz	x21, 557c <fwp_tape_reserve+0x15c>
    5520:	a94363f7 	ldp	x23, x24, [sp, #48]
    5524:	8b160000 	add	x0, x0, x22
    5528:	a9425bf5 	ldp	x21, x22, [sp, #32]
    552c:	f9000e74 	str	x20, [x19, #24]
    5530:	f9001660 	str	x0, [x19, #40]
    5534:	a94153f3 	ldp	x19, x20, [sp, #16]
    5538:	a8c57bfd 	ldp	x29, x30, [sp], #80
    553c:	d65f03c0 	ret
    5540:	d37ffa94 	lsl	x20, x20, #1
    5544:	17ffffc7 	b	5460 <fwp_tape_reserve+0x40>
    5548:	90000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    554c:	91326000 	add	x0, x0, #0xc98
    5550:	a9025bf5 	stp	x21, x22, [sp, #32]
    5554:	a90363f7 	stp	x23, x24, [sp, #48]
    5558:	a9046bf9 	stp	x25, x26, [sp, #64]
    555c:	97fffb76 	bl	4334 <fwp_trap>
    5560:	aa0303e0 	mov	x0, x3
    5564:	d37df2a2 	lsl	x2, x21, #3
    5568:	97fff46a 	bl	2710 <memmove@plt>
    556c:	f9401a61 	ldr	x1, [x19, #48]
    5570:	f9401260 	ldr	x0, [x19, #32]
    5574:	8b170021 	add	x1, x1, x23
    5578:	f9001e61 	str	x1, [x19, #56]
    557c:	f9401661 	ldr	x1, [x19, #40]
    5580:	d37ef696 	lsl	x22, x20, #2
    5584:	d37ef6a2 	lsl	x2, x21, #2
    5588:	8b160000 	add	x0, x0, x22
    558c:	97fff461 	bl	2710 <memmove@plt>
    5590:	f9401260 	ldr	x0, [x19, #32]
    5594:	a94363f7 	ldp	x23, x24, [sp, #48]
    5598:	8b160000 	add	x0, x0, x22
    559c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55a0:	f9000e74 	str	x20, [x19, #24]
    55a4:	f9001660 	str	x0, [x19, #40]
    55a8:	17ffffe3 	b	5534 <fwp_tape_reserve+0x114>
    55ac:	f9401a60 	ldr	x0, [x19, #48]
    55b0:	d37cee81 	lsl	x1, x20, #4
    55b4:	52800042 	mov	w2, #0x2                   	// #2
    55b8:	97fffac3 	bl	40c4 <ad_raw_realloc>
    55bc:	b4000160 	cbz	x0, 55e8 <fwp_tape_reserve+0x1c8>
    55c0:	f9400e62 	ldr	x2, [x19, #24]
    55c4:	f9001a60 	str	x0, [x19, #48]
    55c8:	8b170003 	add	x3, x0, x23
    55cc:	8b020c01 	add	x1, x0, x2, lsl #3
    55d0:	f9001e61 	str	x1, [x19, #56]
    55d4:	b5fffc75 	cbnz	x21, 5560 <fwp_tape_reserve+0x140>
    55d8:	f9401260 	ldr	x0, [x19, #32]
    55dc:	d37ef696 	lsl	x22, x20, #2
    55e0:	f9001e63 	str	x3, [x19, #56]
    55e4:	17ffffcf 	b	5520 <fwp_tape_reserve+0x100>
    55e8:	aa1303e0 	mov	x0, x19
    55ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    55f0:	97fff689 	bl	3014 <fwp_tape_unlink_scope>
    55f4:	f9401260 	ldr	x0, [x19, #32]
    55f8:	b4000040 	cbz	x0, 5600 <fwp_tape_reserve+0x1e0>
    55fc:	97fffa7d 	bl	3ff0 <ad_raw_free.part.0>
    5600:	f9401a60 	ldr	x0, [x19, #48]
    5604:	b4000040 	cbz	x0, 560c <fwp_tape_reserve+0x1ec>
    5608:	97fffa7a 	bl	3ff0 <ad_raw_free.part.0>
    560c:	f9402260 	ldr	x0, [x19, #64]
    5610:	b4000040 	cbz	x0, 5618 <fwp_tape_reserve+0x1f8>
    5614:	97fffa77 	bl	3ff0 <ad_raw_free.part.0>
    5618:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    561c:	f947e821 	ldr	x1, [x1, #4048]
    5620:	f9000e7f 	str	xzr, [x19, #24]
    5624:	4f000400 	movi	v0.4s, #0x0
    5628:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    562c:	d2800262 	mov	x2, #0x13                  	// #19
    5630:	f9400023 	ldr	x3, [x1]
    5634:	b900067f 	str	wzr, [x19, #4]
    5638:	d2800021 	mov	x1, #0x1                   	// #1
    563c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    5640:	911e6000 	add	x0, x0, #0x798
    5644:	3c808260 	stur	q0, [x19, #8]
    5648:	ad010260 	stp	q0, q0, [x19, #32]
    564c:	97fff4d5 	bl	29a0 <fwrite@plt>
    5650:	d2800000 	mov	x0, #0x0                   	// #0
    5654:	97fff4df 	bl	29d0 <fflush@plt>
    5658:	52800cc0 	mov	w0, #0x66                  	// #102
    565c:	97fff4ed 	bl	2a10 <_Exit@plt>

0000000000005660 <f141.constprop.0>:
    5660:	f100001f 	cmp	x0, #0x0
    5664:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5668:	5400094b 	b.lt	5790 <f141.constprop.0+0x130>  // b.tstop
    566c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5670:	aa0003e2 	mov	x2, x0
    5674:	910003fd 	mov	x29, sp
    5678:	a90153f3 	stp	x19, x20, [sp, #16]
    567c:	aa0003f4 	mov	x20, x0
    5680:	aa010000 	orr	x0, x0, x1
    5684:	a9025bf5 	stp	x21, x22, [sp, #32]
    5688:	aa0103f6 	mov	x22, x1
    568c:	f9001bf7 	str	x23, [sp, #48]
    5690:	fd001fe8 	str	d8, [sp, #56]
    5694:	b7f80180 	tbnz	x0, #63, 56c4 <f141.constprop.0+0x64>
    5698:	9360fc20 	asr	x0, x1, #32
    569c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56a0:	eb82801f 	cmp	x0, x2, asr #32
    56a4:	540007a1 	b.ne	5798 <f141.constprop.0+0x138>  // b.any
    56a8:	97fffd26 	bl	4b40 <fwp_tape_of>
    56ac:	aa0003f3 	mov	x19, x0
    56b0:	f9403000 	ldr	x0, [x0, #96]
    56b4:	b40001e0 	cbz	x0, 56f0 <f141.constprop.0+0x90>
    56b8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    56bc:	91340000 	add	x0, x0, #0xd00
    56c0:	97fffb1d 	bl	4334 <fwp_trap>
    56c4:	9360fc40 	asr	x0, x2, #32
    56c8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56cc:	b6fffee2 	tbz	x2, #63, 56a8 <f141.constprop.0+0x48>
    56d0:	2f00e408 	movi	d8, #0x0
    56d4:	9360fc20 	asr	x0, x1, #32
    56d8:	aa0103f4 	mov	x20, x1
    56dc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    56e0:	97fffd18 	bl	4b40 <fwp_tape_of>
    56e4:	aa0003f3 	mov	x19, x0
    56e8:	f9403000 	ldr	x0, [x0, #96]
    56ec:	b5fffe60 	cbnz	x0, 56b8 <f141.constprop.0+0x58>
    56f0:	f9400a77 	ldr	x23, [x19, #16]
    56f4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    56f8:	eb0002ff 	cmp	x23, x0
    56fc:	5400044c 	b.gt	5784 <f141.constprop.0+0x124>
    5700:	eb3442ff 	cmp	x23, w20, uxtw
    5704:	5400008d 	b.le	5714 <f141.constprop.0+0xb4>
    5708:	b7f800d6 	tbnz	x22, #63, 5720 <f141.constprop.0+0xc0>
    570c:	eb3642ff 	cmp	x23, w22, uxtw
    5710:	5400008c 	b.gt	5720 <f141.constprop.0+0xc0>
    5714:	90000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    5718:	9134c000 	add	x0, x0, #0xd30
    571c:	97fffb06 	bl	4334 <fwp_trap>
    5720:	f9400675 	ldr	x21, [x19, #8]
    5724:	aa1303e0 	mov	x0, x19
    5728:	cb1502f5 	sub	x21, x23, x21
    572c:	910006a1 	add	x1, x21, #0x1
    5730:	97ffff3c 	bl	5420 <fwp_tape_reserve>
    5734:	a9420262 	ldp	x2, x0, [x19, #32]
    5738:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    573c:	f9401a61 	ldr	x1, [x19, #48]
    5740:	b8357854 	str	w20, [x2, x21, lsl #2]
    5744:	f9401e62 	ldr	x2, [x19, #56]
    5748:	f10002df 	cmp	x22, #0x0
    574c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5750:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5754:	b8357816 	str	w22, [x0, x21, lsl #2]
    5758:	92607e80 	and	x0, x20, #0xffffffff00000000
    575c:	910006e1 	add	x1, x23, #0x1
    5760:	aa170000 	orr	x0, x0, x23
    5764:	fc357848 	str	d8, [x2, x21, lsl #3]
    5768:	a9425bf5 	ldp	x21, x22, [sp, #32]
    576c:	f9401bf7 	ldr	x23, [sp, #48]
    5770:	fd401fe8 	ldr	d8, [sp, #56]
    5774:	f9000a61 	str	x1, [x19, #16]
    5778:	a94153f3 	ldp	x19, x20, [sp, #16]
    577c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5780:	d65f03c0 	ret
    5784:	90000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    5788:	91326000 	add	x0, x0, #0xc98
    578c:	97fffaea 	bl	4334 <fwp_trap>
    5790:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5794:	d65f03c0 	ret
    5798:	90000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    579c:	9132e000 	add	x0, x0, #0xcb8
    57a0:	97fffae5 	bl	4334 <fwp_trap>

00000000000057a4 <w120>:
    57a4:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    57a8:	910003fd 	mov	x29, sp
    57ac:	a90153f3 	stp	x19, x20, [sp, #16]
    57b0:	a9025bf5 	stp	x21, x22, [sp, #32]
    57b4:	aa0003f5 	mov	x21, x0
    57b8:	a90363f7 	stp	x23, x24, [sp, #48]
    57bc:	aa0103f7 	mov	x23, x1
    57c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    57c4:	f9002bfb 	str	x27, [sp, #80]
    57c8:	6d0627e8 	stp	d8, d9, [sp, #96]
    57cc:	1e604028 	fmov	d8, d1
    57d0:	1e600809 	fmul	d9, d0, d0
    57d4:	6d072fea 	stp	d10, d11, [sp, #112]
    57d8:	1e60400b 	fmov	d11, d0
    57dc:	b7f81c80 	tbnz	x0, #63, 5b6c <w120+0x3c8>
    57e0:	9360fc19 	asr	x25, x0, #32
    57e4:	aa1903e0 	mov	x0, x25
    57e8:	97fffcd6 	bl	4b40 <fwp_tape_of>
    57ec:	f9403001 	ldr	x1, [x0, #96]
    57f0:	aa0003f3 	mov	x19, x0
    57f4:	b4000081 	cbz	x1, 5804 <w120+0x60>
    57f8:	90000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    57fc:	91340000 	add	x0, x0, #0xd00
    5800:	97fffacd 	bl	4334 <fwp_trap>
    5804:	f9400818 	ldr	x24, [x0, #16]
    5808:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    580c:	eb01031f 	cmp	x24, x1
    5810:	54001a8c 	b.gt	5b60 <w120+0x3bc>
    5814:	eb35431f 	cmp	x24, w21, uxtw
    5818:	540019ed 	b.le	5b54 <w120+0x3b0>
    581c:	f9400416 	ldr	x22, [x0, #8]
    5820:	92607eb4 	and	x20, x21, #0xffffffff00000000
    5824:	aa180294 	orr	x20, x20, x24
    5828:	cb160316 	sub	x22, x24, x22
    582c:	910006c1 	add	x1, x22, #0x1
    5830:	97fffefc 	bl	5420 <fwp_tape_reserve>
    5834:	a9420a61 	ldp	x1, x2, [x19, #32]
    5838:	91000700 	add	x0, x24, #0x1
    583c:	f9401a63 	ldr	x3, [x19, #48]
    5840:	b8367835 	str	w21, [x1, x22, lsl #2]
    5844:	f9401e61 	ldr	x1, [x19, #56]
    5848:	1e693908 	fsub	d8, d8, d9
    584c:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5850:	9360fe9a 	asr	x26, x20, #32
    5854:	b8367855 	str	w21, [x2, x22, lsl #2]
    5858:	fc36782b 	str	d11, [x1, x22, lsl #3]
    585c:	f9000a60 	str	x0, [x19, #16]
    5860:	b7f80077 	tbnz	x23, #63, 586c <w120+0xc8>
    5864:	eb97835f 	cmp	x26, x23, asr #32
    5868:	540019a1 	b.ne	5b9c <w120+0x3f8>  // b.any
    586c:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5870:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    5874:	eb19035f 	cmp	x26, x25
    5878:	540000c0 	b.eq	5890 <w120+0xec>  // b.none
    587c:	aa1a03e0 	mov	x0, x26
    5880:	97fffcb0 	bl	4b40 <fwp_tape_of>
    5884:	aa0003f3 	mov	x19, x0
    5888:	f9403000 	ldr	x0, [x0, #96]
    588c:	b5fffb60 	cbnz	x0, 57f8 <w120+0x54>
    5890:	f9400a79 	ldr	x25, [x19, #16]
    5894:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5898:	eb00033f 	cmp	x25, x0
    589c:	5400162c 	b.gt	5b60 <w120+0x3bc>
    58a0:	eb34433f 	cmp	x25, w20, uxtw
    58a4:	5400158d 	b.le	5b54 <w120+0x3b0>
    58a8:	b7f80077 	tbnz	x23, #63, 58b4 <w120+0x110>
    58ac:	eb37433f 	cmp	x25, w23, uxtw
    58b0:	5400152d 	b.le	5b54 <w120+0x3b0>
    58b4:	f9400676 	ldr	x22, [x19, #8]
    58b8:	aa1303e0 	mov	x0, x19
    58bc:	cb160336 	sub	x22, x25, x22
    58c0:	910006c1 	add	x1, x22, #0x1
    58c4:	97fffed7 	bl	5420 <fwp_tape_reserve>
    58c8:	a9420e62 	ldp	x2, x3, [x19, #32]
    58cc:	f10002ff 	cmp	x23, #0x0
    58d0:	f9401a61 	ldr	x1, [x19, #48]
    58d4:	b8367854 	str	w20, [x2, x22, lsl #2]
    58d8:	f9401e62 	ldr	x2, [x19, #56]
    58dc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    58e0:	fc367829 	str	d9, [x1, x22, lsl #3]
    58e4:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    58e8:	b8367861 	str	w1, [x3, x22, lsl #2]
    58ec:	91000737 	add	x23, x25, #0x1
    58f0:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    58f4:	92607e94 	and	x20, x20, #0xffffffff00000000
    58f8:	fc36784a 	str	d10, [x2, x22, lsl #3]
    58fc:	aa190294 	orr	x20, x20, x25
    5900:	f9000a77 	str	x23, [x19, #16]
    5904:	1e6b3929 	fsub	d9, d9, d11
    5908:	b7f81675 	tbnz	x21, #63, 5bd4 <w120+0x430>
    590c:	9360febb 	asr	x27, x21, #32
    5910:	eb1a037f 	cmp	x27, x26
    5914:	540000e0 	b.eq	5930 <w120+0x18c>  // b.none
    5918:	aa1b03e0 	mov	x0, x27
    591c:	97fffc89 	bl	4b40 <fwp_tape_of>
    5920:	aa0003f3 	mov	x19, x0
    5924:	f9403000 	ldr	x0, [x0, #96]
    5928:	b5fff680 	cbnz	x0, 57f8 <w120+0x54>
    592c:	f9400a77 	ldr	x23, [x19, #16]
    5930:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5934:	eb0002ff 	cmp	x23, x0
    5938:	5400114c 	b.gt	5b60 <w120+0x3bc>
    593c:	eb3542ff 	cmp	x23, w21, uxtw
    5940:	540010ad 	b.le	5b54 <w120+0x3b0>
    5944:	f9400676 	ldr	x22, [x19, #8]
    5948:	aa1303e0 	mov	x0, x19
    594c:	cb1602f6 	sub	x22, x23, x22
    5950:	910006c1 	add	x1, x22, #0x1
    5954:	97fffeb3 	bl	5420 <fwp_tape_reserve>
    5958:	a9420261 	ldp	x1, x0, [x19, #32]
    595c:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    5960:	f9401a63 	ldr	x3, [x19, #48]
    5964:	b8367835 	str	w21, [x1, x22, lsl #2]
    5968:	f9401e61 	ldr	x1, [x19, #56]
    596c:	12800002 	mov	w2, #0xffffffff            	// #-1
    5970:	fc367860 	str	d0, [x3, x22, lsl #3]
    5974:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5978:	b8367802 	str	w2, [x0, x22, lsl #2]
    597c:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5980:	910006e0 	add	x0, x23, #0x1
    5984:	aa1702b7 	orr	x23, x21, x23
    5988:	fc367820 	str	d0, [x1, x22, lsl #3]
    598c:	f9000a60 	str	x0, [x19, #16]
    5990:	9360fe99 	asr	x25, x20, #32
    5994:	1e68090a 	fmul	d10, d8, d8
    5998:	eb1b033f 	cmp	x25, x27
    599c:	540000c0 	b.eq	59b4 <w120+0x210>  // b.none
    59a0:	aa1903e0 	mov	x0, x25
    59a4:	97fffc67 	bl	4b40 <fwp_tape_of>
    59a8:	aa0003f3 	mov	x19, x0
    59ac:	f9403000 	ldr	x0, [x0, #96]
    59b0:	b5fff240 	cbnz	x0, 57f8 <w120+0x54>
    59b4:	f9400a75 	ldr	x21, [x19, #16]
    59b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    59bc:	eb0002bf 	cmp	x21, x0
    59c0:	54000d0c 	b.gt	5b60 <w120+0x3bc>
    59c4:	eb3442bf 	cmp	x21, w20, uxtw
    59c8:	54000c6d 	b.le	5b54 <w120+0x3b0>
    59cc:	f9400678 	ldr	x24, [x19, #8]
    59d0:	aa1303e0 	mov	x0, x19
    59d4:	92607e96 	and	x22, x20, #0xffffffff00000000
    59d8:	cb1802b8 	sub	x24, x21, x24
    59dc:	aa1502d6 	orr	x22, x22, x21
    59e0:	91000701 	add	x1, x24, #0x1
    59e4:	97fffe8f 	bl	5420 <fwp_tape_reserve>
    59e8:	a9420261 	ldp	x1, x0, [x19, #32]
    59ec:	f9401a62 	ldr	x2, [x19, #48]
    59f0:	b8387834 	str	w20, [x1, x24, lsl #2]
    59f4:	f9401e61 	ldr	x1, [x19, #56]
    59f8:	fc387848 	str	d8, [x2, x24, lsl #3]
    59fc:	b8387814 	str	w20, [x0, x24, lsl #2]
    5a00:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a04:	9e670000 	fmov	d0, x0
    5a08:	910006b4 	add	x20, x21, #0x1
    5a0c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5a10:	9360fed8 	asr	x24, x22, #32
    5a14:	f9000a74 	str	x20, [x19, #16]
    5a18:	1e60094a 	fmul	d10, d10, d0
    5a1c:	eb19031f 	cmp	x24, x25
    5a20:	540000e0 	b.eq	5a3c <w120+0x298>  // b.none
    5a24:	aa1803e0 	mov	x0, x24
    5a28:	97fffc46 	bl	4b40 <fwp_tape_of>
    5a2c:	aa0003f3 	mov	x19, x0
    5a30:	f9403000 	ldr	x0, [x0, #96]
    5a34:	b5ffee20 	cbnz	x0, 57f8 <w120+0x54>
    5a38:	f9400a74 	ldr	x20, [x19, #16]
    5a3c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5a40:	eb00029f 	cmp	x20, x0
    5a44:	540008ec 	b.gt	5b60 <w120+0x3bc>
    5a48:	eb36429f 	cmp	x20, w22, uxtw
    5a4c:	5400084d 	b.le	5b54 <w120+0x3b0>
    5a50:	f9400675 	ldr	x21, [x19, #8]
    5a54:	aa1303e0 	mov	x0, x19
    5a58:	cb150295 	sub	x21, x20, x21
    5a5c:	910006a1 	add	x1, x21, #0x1
    5a60:	97fffe70 	bl	5420 <fwp_tape_reserve>
    5a64:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a68:	9e670000 	fmov	d0, x0
    5a6c:	a9420261 	ldp	x1, x0, [x19, #32]
    5a70:	1e690928 	fmul	d8, d9, d9
    5a74:	f9401a62 	ldr	x2, [x19, #48]
    5a78:	b8357836 	str	w22, [x1, x21, lsl #2]
    5a7c:	f9401e61 	ldr	x1, [x19, #56]
    5a80:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5a84:	fc357840 	str	d0, [x2, x21, lsl #3]
    5a88:	12800002 	mov	w2, #0xffffffff            	// #-1
    5a8c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5a90:	91000680 	add	x0, x20, #0x1
    5a94:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5a98:	aa1402d6 	orr	x22, x22, x20
    5a9c:	f9000a60 	str	x0, [x19, #16]
    5aa0:	b10006ff 	cmn	x23, #0x1
    5aa4:	540009e0 	b.eq	5be0 <w120+0x43c>  // b.none
    5aa8:	9360fee0 	asr	x0, x23, #32
    5aac:	eb18001f 	cmp	x0, x24
    5ab0:	540000a0 	b.eq	5ac4 <w120+0x320>  // b.none
    5ab4:	97fffc23 	bl	4b40 <fwp_tape_of>
    5ab8:	aa0003f3 	mov	x19, x0
    5abc:	f9403000 	ldr	x0, [x0, #96]
    5ac0:	b5ffe9c0 	cbnz	x0, 57f8 <w120+0x54>
    5ac4:	f9400a74 	ldr	x20, [x19, #16]
    5ac8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5acc:	eb00029f 	cmp	x20, x0
    5ad0:	5400048c 	b.gt	5b60 <w120+0x3bc>
    5ad4:	eb37429f 	cmp	x20, w23, uxtw
    5ad8:	540003ed 	b.le	5b54 <w120+0x3b0>
    5adc:	f9400675 	ldr	x21, [x19, #8]
    5ae0:	aa1303e0 	mov	x0, x19
    5ae4:	cb150295 	sub	x21, x20, x21
    5ae8:	910006a1 	add	x1, x21, #0x1
    5aec:	97fffe4d 	bl	5420 <fwp_tape_reserve>
    5af0:	a9420a61 	ldp	x1, x2, [x19, #32]
    5af4:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5af8:	f9401a63 	ldr	x3, [x19, #48]
    5afc:	b8357837 	str	w23, [x1, x21, lsl #2]
    5b00:	f9401e61 	ldr	x1, [x19, #56]
    5b04:	aa140000 	orr	x0, x0, x20
    5b08:	fc357869 	str	d9, [x3, x21, lsl #3]
    5b0c:	91000694 	add	x20, x20, #0x1
    5b10:	b8357857 	str	w23, [x2, x21, lsl #2]
    5b14:	fc357829 	str	d9, [x1, x21, lsl #3]
    5b18:	f9000a74 	str	x20, [x19, #16]
    5b1c:	1e6a2908 	fadd	d8, d8, d10
    5b20:	aa1603e1 	mov	x1, x22
    5b24:	97fffecf 	bl	5660 <f141.constprop.0>
    5b28:	aa0003e1 	mov	x1, x0
    5b2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b30:	9e660100 	fmov	x0, d8
    5b34:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5b38:	a94363f7 	ldp	x23, x24, [sp, #48]
    5b3c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5b40:	f9402bfb 	ldr	x27, [sp, #80]
    5b44:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5b48:	6d472fea 	ldp	d10, d11, [sp, #112]
    5b4c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5b50:	d65f03c0 	ret
    5b54:	90000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    5b58:	9134c000 	add	x0, x0, #0xd30
    5b5c:	97fff9f6 	bl	4334 <fwp_trap>
    5b60:	90000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    5b64:	91326000 	add	x0, x0, #0xc98
    5b68:	97fff9f3 	bl	4334 <fwp_trap>
    5b6c:	1e693828 	fsub	d8, d1, d9
    5b70:	b6f801c1 	tbz	x1, #63, 5ba8 <w120+0x404>
    5b74:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5b78:	1e68090a 	fmul	d10, d8, d8
    5b7c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5b80:	9e670000 	fmov	d0, x0
    5b84:	1e6b3828 	fsub	d8, d1, d11
    5b88:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5b8c:	aa1603e0 	mov	x0, x22
    5b90:	1e60094a 	fmul	d10, d10, d0
    5b94:	1e680908 	fmul	d8, d8, d8
    5b98:	17ffffe1 	b	5b1c <w120+0x378>
    5b9c:	90000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    5ba0:	9132e000 	add	x0, x0, #0xcb8
    5ba4:	97fff9e4 	bl	4334 <fwp_trap>
    5ba8:	2f00e40a 	movi	d10, #0x0
    5bac:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5bb0:	9360fc3a 	asr	x26, x1, #32
    5bb4:	aa0103f4 	mov	x20, x1
    5bb8:	aa1a03e0 	mov	x0, x26
    5bbc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5bc0:	97fffbe0 	bl	4b40 <fwp_tape_of>
    5bc4:	aa0003f3 	mov	x19, x0
    5bc8:	f9403000 	ldr	x0, [x0, #96]
    5bcc:	b5ffe160 	cbnz	x0, 57f8 <w120+0x54>
    5bd0:	17ffff30 	b	5890 <w120+0xec>
    5bd4:	aa1a03fb 	mov	x27, x26
    5bd8:	aa0003f7 	mov	x23, x0
    5bdc:	17ffff6d 	b	5990 <w120+0x1ec>
    5be0:	aa1703e0 	mov	x0, x23
    5be4:	17ffffce 	b	5b1c <w120+0x378>
    5be8:	d503201f 	nop
    5bec:	d503201f 	nop

0000000000005bf0 <fwp_rc_share>:
    5bf0:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5bf4:	9118c042 	add	x2, x2, #0x630
    5bf8:	f949d843 	ldr	x3, [x2, #5040]
    5bfc:	f949ec41 	ldr	x1, [x2, #5080]
    5c00:	cb030000 	sub	x0, x0, x3
    5c04:	eb01401f 	cmp	x0, x1, lsl #16
    5c08:	540003a2 	b.cs	5c7c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5c0c:	d350fc01 	lsr	x1, x0, #16
    5c10:	f949fc44 	ldr	x4, [x2, #5112]
    5c14:	8b010821 	add	x1, x1, x1, lsl #2
    5c18:	d37df021 	lsl	x1, x1, #3
    5c1c:	8b010083 	add	x3, x4, x1
    5c20:	f9401062 	ldr	x2, [x3, #32]
    5c24:	b40002c2 	cbz	x2, 5c7c <fwp_rc_share+0x8c>
    5c28:	38616881 	ldrb	w1, [x4, x1]
    5c2c:	7100083f 	cmp	w1, #0x2
    5c30:	54000220 	b.eq	5c74 <fwp_rc_share+0x84>  // b.none
    5c34:	7100043f 	cmp	w1, #0x1
    5c38:	54000221 	b.ne	5c7c <fwp_rc_share+0x8c>  // b.any
    5c3c:	29430464 	ldp	w4, w1, [x3, #24]
    5c40:	92403c00 	and	x0, x0, #0xffff
    5c44:	9b047c00 	mul	x0, x0, x4
    5c48:	d360fc00 	lsr	x0, x0, #32
    5c4c:	eb01001f 	cmp	x0, x1
    5c50:	54000162 	b.cs	5c7c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5c54:	8b000042 	add	x2, x2, x0
    5c58:	39400040 	ldrb	w0, [x2]
    5c5c:	34000100 	cbz	w0, 5c7c <fwp_rc_share+0x8c>
    5c60:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5c64:	90000040 	adrp	x0, d000 <fwp_main_thread+0x520>
    5c68:	91354000 	add	x0, x0, #0xd50
    5c6c:	910003fd 	mov	x29, sp
    5c70:	97fff9b1 	bl	4334 <fwp_trap>
    5c74:	72003c1f 	tst	w0, #0xffff
    5c78:	54ffff00 	b.eq	5c58 <fwp_rc_share+0x68>  // b.none
    5c7c:	d65f03c0 	ret

0000000000005c80 <fwp_rc_fresh>:
    5c80:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5c84:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5c88:	9118c063 	add	x3, x3, #0x630
    5c8c:	910003fd 	mov	x29, sp
    5c90:	a90153f3 	stp	x19, x20, [sp, #16]
    5c94:	aa0003f3 	mov	x19, x0
    5c98:	f949d861 	ldr	x1, [x3, #5040]
    5c9c:	f949ec60 	ldr	x0, [x3, #5080]
    5ca0:	cb010261 	sub	x1, x19, x1
    5ca4:	eb00403f 	cmp	x1, x0, lsl #16
    5ca8:	54000322 	b.cs	5d0c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5cac:	d350fc22 	lsr	x2, x1, #16
    5cb0:	f949fc63 	ldr	x3, [x3, #5112]
    5cb4:	8b020842 	add	x2, x2, x2, lsl #2
    5cb8:	d37df042 	lsl	x2, x2, #3
    5cbc:	8b020060 	add	x0, x3, x2
    5cc0:	f9401014 	ldr	x20, [x0, #32]
    5cc4:	b4000254 	cbz	x20, 5d0c <fwp_rc_fresh+0x8c>
    5cc8:	38626862 	ldrb	w2, [x3, x2]
    5ccc:	7100085f 	cmp	w2, #0x2
    5cd0:	54000260 	b.eq	5d1c <fwp_rc_fresh+0x9c>  // b.none
    5cd4:	7100045f 	cmp	w2, #0x1
    5cd8:	540001a1 	b.ne	5d0c <fwp_rc_fresh+0x8c>  // b.any
    5cdc:	29430002 	ldp	w2, w0, [x0, #24]
    5ce0:	92403c21 	and	x1, x1, #0xffff
    5ce4:	9b027c21 	mul	x1, x1, x2
    5ce8:	d360fc21 	lsr	x1, x1, #32
    5cec:	eb00003f 	cmp	x1, x0
    5cf0:	540000e2 	b.cs	5d0c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5cf4:	8b010294 	add	x20, x20, x1
    5cf8:	39400280 	ldrb	w0, [x20]
    5cfc:	7103fc1f 	cmp	w0, #0xff
    5d00:	540001a0 	b.eq	5d34 <fwp_rc_fresh+0xb4>  // b.none
    5d04:	52800020 	mov	w0, #0x1                   	// #1
    5d08:	39000280 	strb	w0, [x20]
    5d0c:	aa1303e0 	mov	x0, x19
    5d10:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d14:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d18:	d65f03c0 	ret
    5d1c:	72003c3f 	tst	w1, #0xffff
    5d20:	54fffec0 	b.eq	5cf8 <fwp_rc_fresh+0x78>  // b.none
    5d24:	aa1303e0 	mov	x0, x19
    5d28:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d2c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5d30:	d65f03c0 	ret
    5d34:	aa1403e0 	mov	x0, x20
    5d38:	97fff99f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    5d3c:	17fffff2 	b	5d04 <fwp_rc_fresh+0x84>

0000000000005d40 <fwp_rc_free_arr>:
    5d40:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5d44:	9118c063 	add	x3, x3, #0x630
    5d48:	f949d861 	ldr	x1, [x3, #5040]
    5d4c:	f949ec62 	ldr	x2, [x3, #5080]
    5d50:	cb010001 	sub	x1, x0, x1
    5d54:	eb02403f 	cmp	x1, x2, lsl #16
    5d58:	54000342 	b.cs	5dc0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5d5c:	d350fc22 	lsr	x2, x1, #16
    5d60:	f949fc65 	ldr	x5, [x3, #5112]
    5d64:	8b020842 	add	x2, x2, x2, lsl #2
    5d68:	d37df042 	lsl	x2, x2, #3
    5d6c:	8b0200a4 	add	x4, x5, x2
    5d70:	f9401083 	ldr	x3, [x4, #32]
    5d74:	b4000263 	cbz	x3, 5dc0 <fwp_rc_free_arr+0x80>
    5d78:	386268a2 	ldrb	w2, [x5, x2]
    5d7c:	7100085f 	cmp	w2, #0x2
    5d80:	540001c0 	b.eq	5db8 <fwp_rc_free_arr+0x78>  // b.none
    5d84:	7100045f 	cmp	w2, #0x1
    5d88:	540001c1 	b.ne	5dc0 <fwp_rc_free_arr+0x80>  // b.any
    5d8c:	29430885 	ldp	w5, w2, [x4, #24]
    5d90:	92403c21 	and	x1, x1, #0xffff
    5d94:	9b057c21 	mul	x1, x1, x5
    5d98:	d360fc21 	lsr	x1, x1, #32
    5d9c:	eb02003f 	cmp	x1, x2
    5da0:	54000102 	b.cs	5dc0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5da4:	8b010063 	add	x3, x3, x1
    5da8:	39400061 	ldrb	w1, [x3]
    5dac:	7100043f 	cmp	w1, #0x1
    5db0:	54000081 	b.ne	5dc0 <fwp_rc_free_arr+0x80>  // b.any
    5db4:	17fffa1b 	b	4620 <fwp_mem_free>
    5db8:	72003c3f 	tst	w1, #0xffff
    5dbc:	54ffff60 	b.eq	5da8 <fwp_rc_free_arr+0x68>  // b.none
    5dc0:	d65f03c0 	ret

0000000000005dc4 <fwp_rc_dup>:
    5dc4:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5dc8:	9118c042 	add	x2, x2, #0x630
    5dcc:	f949d841 	ldr	x1, [x2, #5040]
    5dd0:	f949ec43 	ldr	x3, [x2, #5080]
    5dd4:	cb010001 	sub	x1, x0, x1
    5dd8:	eb03403f 	cmp	x1, x3, lsl #16
    5ddc:	540003c2 	b.cs	5e54 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5de0:	d350fc20 	lsr	x0, x1, #16
    5de4:	f949fc44 	ldr	x4, [x2, #5112]
    5de8:	8b000800 	add	x0, x0, x0, lsl #2
    5dec:	d37df002 	lsl	x2, x0, #3
    5df0:	8b020083 	add	x3, x4, x2
    5df4:	f9401060 	ldr	x0, [x3, #32]
    5df8:	b40002e0 	cbz	x0, 5e54 <fwp_rc_dup+0x90>
    5dfc:	38626882 	ldrb	w2, [x4, x2]
    5e00:	7100085f 	cmp	w2, #0x2
    5e04:	540002a0 	b.eq	5e58 <fwp_rc_dup+0x94>  // b.none
    5e08:	7100045f 	cmp	w2, #0x1
    5e0c:	54000241 	b.ne	5e54 <fwp_rc_dup+0x90>  // b.any
    5e10:	29430864 	ldp	w4, w2, [x3, #24]
    5e14:	92403c21 	and	x1, x1, #0xffff
    5e18:	9b047c21 	mul	x1, x1, x4
    5e1c:	d360fc21 	lsr	x1, x1, #32
    5e20:	eb02003f 	cmp	x1, x2
    5e24:	54000182 	b.cs	5e54 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5e28:	8b010000 	add	x0, x0, x1
    5e2c:	39400001 	ldrb	w1, [x0]
    5e30:	34000121 	cbz	w1, 5e54 <fwp_rc_dup+0x90>
    5e34:	f00000c2 	adrp	x2, 20000 <__data_start>
    5e38:	91014042 	add	x2, x2, #0x50
    5e3c:	b9413043 	ldr	w3, [x2, #304]
    5e40:	35000123 	cbnz	w3, 5e64 <fwp_rc_dup+0xa0>
    5e44:	7103f43f 	cmp	w1, #0xfd
    5e48:	54000168 	b.hi	5e74 <fwp_rc_dup+0xb0>  // b.pmore
    5e4c:	11000421 	add	w1, w1, #0x1
    5e50:	39000001 	strb	w1, [x0]
    5e54:	d65f03c0 	ret
    5e58:	72003c3f 	tst	w1, #0xffff
    5e5c:	54fffe80 	b.eq	5e2c <fwp_rc_dup+0x68>  // b.none
    5e60:	d65f03c0 	ret
    5e64:	f940ac43 	ldr	x3, [x2, #344]
    5e68:	91000463 	add	x3, x3, #0x1
    5e6c:	f900ac43 	str	x3, [x2, #344]
    5e70:	17fffff5 	b	5e44 <fwp_rc_dup+0x80>
    5e74:	17fffa64 	b	4804 <fwp_rc_wide_dup>
    5e78:	d503201f 	nop
    5e7c:	d503201f 	nop

0000000000005e80 <fwp_owned_entry173>:
    5e80:	d10103ff 	sub	sp, sp, #0x40
    5e84:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5e88:	f947f442 	ldr	x2, [x2, #4072]
    5e8c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5e90:	910083fd 	add	x29, sp, #0x20
    5e94:	a90353f3 	stp	x19, x20, [sp, #48]
    5e98:	f9400043 	ldr	x3, [x2]
    5e9c:	f9000fe3 	str	x3, [sp, #24]
    5ea0:	d2800003 	mov	x3, #0x0                   	// #0
    5ea4:	a9400c01 	ldp	x1, x3, [x0]
    5ea8:	f9400802 	ldr	x2, [x0, #16]
    5eac:	ab020022 	adds	x2, x1, x2
    5eb0:	540006e6 	b.vs	5f8c <fwp_owned_entry173+0x10c>
    5eb4:	910023e1 	add	x1, sp, #0x8
    5eb8:	52800000 	mov	w0, #0x0                   	// #0
    5ebc:	a9008be3 	stp	x3, x2, [sp, #8]
    5ec0:	97fffcf8 	bl	52a0 <fwp_data.part.0.constprop.0>
    5ec4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5ec8:	9118c063 	add	x3, x3, #0x630
    5ecc:	aa0003f3 	mov	x19, x0
    5ed0:	f949d861 	ldr	x1, [x3, #5040]
    5ed4:	f949ec60 	ldr	x0, [x3, #5080]
    5ed8:	cb010261 	sub	x1, x19, x1
    5edc:	eb00403f 	cmp	x1, x0, lsl #16
    5ee0:	54000322 	b.cs	5f44 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5ee4:	d350fc22 	lsr	x2, x1, #16
    5ee8:	f949fc63 	ldr	x3, [x3, #5112]
    5eec:	8b020842 	add	x2, x2, x2, lsl #2
    5ef0:	d37df042 	lsl	x2, x2, #3
    5ef4:	8b020060 	add	x0, x3, x2
    5ef8:	f9401014 	ldr	x20, [x0, #32]
    5efc:	b4000254 	cbz	x20, 5f44 <fwp_owned_entry173+0xc4>
    5f00:	38626862 	ldrb	w2, [x3, x2]
    5f04:	7100085f 	cmp	w2, #0x2
    5f08:	54000360 	b.eq	5f74 <fwp_owned_entry173+0xf4>  // b.none
    5f0c:	7100045f 	cmp	w2, #0x1
    5f10:	540001a1 	b.ne	5f44 <fwp_owned_entry173+0xc4>  // b.any
    5f14:	29430002 	ldp	w2, w0, [x0, #24]
    5f18:	92403c21 	and	x1, x1, #0xffff
    5f1c:	9b027c21 	mul	x1, x1, x2
    5f20:	d360fc21 	lsr	x1, x1, #32
    5f24:	eb00003f 	cmp	x1, x0
    5f28:	540000e2 	b.cs	5f44 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5f2c:	8b010294 	add	x20, x20, x1
    5f30:	39400280 	ldrb	w0, [x20]
    5f34:	7103fc1f 	cmp	w0, #0xff
    5f38:	54000240 	b.eq	5f80 <fwp_owned_entry173+0x100>  // b.none
    5f3c:	52800020 	mov	w0, #0x1                   	// #1
    5f40:	39000280 	strb	w0, [x20]
    5f44:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    5f48:	f947f400 	ldr	x0, [x0, #4072]
    5f4c:	f9400fe2 	ldr	x2, [sp, #24]
    5f50:	f9400001 	ldr	x1, [x0]
    5f54:	eb010042 	subs	x2, x2, x1
    5f58:	d2800001 	mov	x1, #0x0                   	// #0
    5f5c:	540001a1 	b.ne	5f90 <fwp_owned_entry173+0x110>  // b.any
    5f60:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5f64:	aa1303e0 	mov	x0, x19
    5f68:	a94353f3 	ldp	x19, x20, [sp, #48]
    5f6c:	910103ff 	add	sp, sp, #0x40
    5f70:	d65f03c0 	ret
    5f74:	72003c3f 	tst	w1, #0xffff
    5f78:	54fffe61 	b.ne	5f44 <fwp_owned_entry173+0xc4>  // b.any
    5f7c:	17ffffed 	b	5f30 <fwp_owned_entry173+0xb0>
    5f80:	aa1403e0 	mov	x0, x20
    5f84:	97fff90c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    5f88:	17ffffed 	b	5f3c <fwp_owned_entry173+0xbc>
    5f8c:	97fff2bd 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5f90:	97fff244 	bl	28a0 <__stack_chk_fail@plt>

0000000000005f94 <e173>:
    5f94:	d10103ff 	sub	sp, sp, #0x40
    5f98:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    5f9c:	f947f442 	ldr	x2, [x2, #4072]
    5fa0:	a9027bfd 	stp	x29, x30, [sp, #32]
    5fa4:	910083fd 	add	x29, sp, #0x20
    5fa8:	a90353f3 	stp	x19, x20, [sp, #48]
    5fac:	f9400043 	ldr	x3, [x2]
    5fb0:	f9000fe3 	str	x3, [sp, #24]
    5fb4:	d2800003 	mov	x3, #0x0                   	// #0
    5fb8:	a9400c01 	ldp	x1, x3, [x0]
    5fbc:	f9400802 	ldr	x2, [x0, #16]
    5fc0:	ab020022 	adds	x2, x1, x2
    5fc4:	54000726 	b.vs	60a8 <e173+0x114>
    5fc8:	910023e1 	add	x1, sp, #0x8
    5fcc:	52800000 	mov	w0, #0x0                   	// #0
    5fd0:	a9008be3 	stp	x3, x2, [sp, #8]
    5fd4:	97fffcb3 	bl	52a0 <fwp_data.part.0.constprop.0>
    5fd8:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5fdc:	9118c063 	add	x3, x3, #0x630
    5fe0:	aa0003f3 	mov	x19, x0
    5fe4:	f949d861 	ldr	x1, [x3, #5040]
    5fe8:	f949ec60 	ldr	x0, [x3, #5080]
    5fec:	cb010261 	sub	x1, x19, x1
    5ff0:	eb00403f 	cmp	x1, x0, lsl #16
    5ff4:	54000322 	b.cs	6058 <e173+0xc4>  // b.hs, b.nlast
    5ff8:	d350fc22 	lsr	x2, x1, #16
    5ffc:	f949fc63 	ldr	x3, [x3, #5112]
    6000:	8b020842 	add	x2, x2, x2, lsl #2
    6004:	d37df042 	lsl	x2, x2, #3
    6008:	8b020060 	add	x0, x3, x2
    600c:	f9401014 	ldr	x20, [x0, #32]
    6010:	b4000254 	cbz	x20, 6058 <e173+0xc4>
    6014:	38626862 	ldrb	w2, [x3, x2]
    6018:	7100085f 	cmp	w2, #0x2
    601c:	540003a0 	b.eq	6090 <e173+0xfc>  // b.none
    6020:	7100045f 	cmp	w2, #0x1
    6024:	540001a1 	b.ne	6058 <e173+0xc4>  // b.any
    6028:	29430002 	ldp	w2, w0, [x0, #24]
    602c:	92403c21 	and	x1, x1, #0xffff
    6030:	9b027c21 	mul	x1, x1, x2
    6034:	d360fc21 	lsr	x1, x1, #32
    6038:	eb00003f 	cmp	x1, x0
    603c:	540000e2 	b.cs	6058 <e173+0xc4>  // b.hs, b.nlast
    6040:	8b010294 	add	x20, x20, x1
    6044:	39400280 	ldrb	w0, [x20]
    6048:	7103fc1f 	cmp	w0, #0xff
    604c:	54000280 	b.eq	609c <e173+0x108>  // b.none
    6050:	52800020 	mov	w0, #0x1                   	// #1
    6054:	39000280 	strb	w0, [x20]
    6058:	aa1303e0 	mov	x0, x19
    605c:	97fffee5 	bl	5bf0 <fwp_rc_share>
    6060:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6064:	f947f400 	ldr	x0, [x0, #4072]
    6068:	f9400fe2 	ldr	x2, [sp, #24]
    606c:	f9400001 	ldr	x1, [x0]
    6070:	eb010042 	subs	x2, x2, x1
    6074:	d2800001 	mov	x1, #0x0                   	// #0
    6078:	540001a1 	b.ne	60ac <e173+0x118>  // b.any
    607c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6080:	aa1303e0 	mov	x0, x19
    6084:	a94353f3 	ldp	x19, x20, [sp, #48]
    6088:	910103ff 	add	sp, sp, #0x40
    608c:	d65f03c0 	ret
    6090:	72003c3f 	tst	w1, #0xffff
    6094:	54fffe21 	b.ne	6058 <e173+0xc4>  // b.any
    6098:	17ffffeb 	b	6044 <e173+0xb0>
    609c:	aa1403e0 	mov	x0, x20
    60a0:	97fff8c5 	bl	43b4 <fwp_rc_forget_slot.part.0>
    60a4:	17ffffeb 	b	6050 <e173+0xbc>
    60a8:	97fff276 	bl	2a80 <fwp_trap_overflow.constprop.0>
    60ac:	97fff1fd 	bl	28a0 <__stack_chk_fail@plt>

00000000000060b0 <fwp_drop0>:
    60b0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    60b4:	910003fd 	mov	x29, sp
    60b8:	a90153f3 	stp	x19, x20, [sp, #16]
    60bc:	f90013f5 	str	x21, [sp, #32]
    60c0:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    60c4:	9118c2b4 	add	x20, x21, #0x630
    60c8:	f949da81 	ldr	x1, [x20, #5040]
    60cc:	f949ee82 	ldr	x2, [x20, #5080]
    60d0:	cb010001 	sub	x1, x0, x1
    60d4:	eb02403f 	cmp	x1, x2, lsl #16
    60d8:	54000382 	b.cs	6148 <fwp_drop0+0x98>  // b.hs, b.nlast
    60dc:	d350fc22 	lsr	x2, x1, #16
    60e0:	f949fe84 	ldr	x4, [x20, #5112]
    60e4:	8b020842 	add	x2, x2, x2, lsl #2
    60e8:	d37df042 	lsl	x2, x2, #3
    60ec:	8b020083 	add	x3, x4, x2
    60f0:	f9401073 	ldr	x19, [x3, #32]
    60f4:	b40002b3 	cbz	x19, 6148 <fwp_drop0+0x98>
    60f8:	38626882 	ldrb	w2, [x4, x2]
    60fc:	7100085f 	cmp	w2, #0x2
    6100:	540002c0 	b.eq	6158 <fwp_drop0+0xa8>  // b.none
    6104:	7100045f 	cmp	w2, #0x1
    6108:	54000201 	b.ne	6148 <fwp_drop0+0x98>  // b.any
    610c:	29430864 	ldp	w4, w2, [x3, #24]
    6110:	92403c21 	and	x1, x1, #0xffff
    6114:	9b047c21 	mul	x1, x1, x4
    6118:	d360fc21 	lsr	x1, x1, #32
    611c:	eb02003f 	cmp	x1, x2
    6120:	54000142 	b.cs	6148 <fwp_drop0+0x98>  // b.hs, b.nlast
    6124:	8b010273 	add	x19, x19, x1
    6128:	39400261 	ldrb	w1, [x19]
    612c:	340000e1 	cbz	w1, 6148 <fwp_drop0+0x98>
    6130:	7100043f 	cmp	w1, #0x1
    6134:	540001e0 	b.eq	6170 <fwp_drop0+0xc0>  // b.none
    6138:	7103fc3f 	cmp	w1, #0xff
    613c:	540002e0 	b.eq	6198 <fwp_drop0+0xe8>  // b.none
    6140:	51000421 	sub	w1, w1, #0x1
    6144:	39000261 	strb	w1, [x19]
    6148:	a94153f3 	ldp	x19, x20, [sp, #16]
    614c:	f94013f5 	ldr	x21, [sp, #32]
    6150:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6154:	d65f03c0 	ret
    6158:	72003c3f 	tst	w1, #0xffff
    615c:	54fffe60 	b.eq	6128 <fwp_drop0+0x78>  // b.none
    6160:	a94153f3 	ldp	x19, x20, [sp, #16]
    6164:	f94013f5 	ldr	x21, [sp, #32]
    6168:	a8c37bfd 	ldp	x29, x30, [sp], #48
    616c:	d65f03c0 	ret
    6170:	f9400813 	ldr	x19, [x0, #16]
    6174:	97fffef3 	bl	5d40 <fwp_rc_free_arr>
    6178:	9118c2a0 	add	x0, x21, #0x630
    617c:	f949d801 	ldr	x1, [x0, #5040]
    6180:	f949ec00 	ldr	x0, [x0, #5080]
    6184:	cb010261 	sub	x1, x19, x1
    6188:	eb00403f 	cmp	x1, x0, lsl #16
    618c:	54fffde2 	b.cs	6148 <fwp_drop0+0x98>  // b.hs, b.nlast
    6190:	aa1303e0 	mov	x0, x19
    6194:	17ffffd2 	b	60dc <fwp_drop0+0x2c>
    6198:	ca534660 	eor	x0, x19, x19, lsr #17
    619c:	9118c2b5 	add	x21, x21, #0x630
    61a0:	ca402400 	eor	x0, x0, x0, lsr #9
    61a4:	92401c00 	and	x0, x0, #0xff
    61a8:	910a2402 	add	x2, x0, #0x289
    61ac:	8b000ea0 	add	x0, x21, x0, lsl #3
    61b0:	8b020ea2 	add	x2, x21, x2, lsl #3
    61b4:	f94a2400 	ldr	x0, [x0, #5192]
    61b8:	b50000a0 	cbnz	x0, 61cc <fwp_drop0+0x11c>
    61bc:	14000013 	b	6208 <fwp_drop0+0x158>
    61c0:	91004002 	add	x2, x0, #0x10
    61c4:	f9400800 	ldr	x0, [x0, #16]
    61c8:	b4000200 	cbz	x0, 6208 <fwp_drop0+0x158>
    61cc:	f9400001 	ldr	x1, [x0]
    61d0:	eb13003f 	cmp	x1, x19
    61d4:	54ffff61 	b.ne	61c0 <fwp_drop0+0x110>  // b.any
    61d8:	f9400041 	ldr	x1, [x2]
    61dc:	f9400420 	ldr	x0, [x1, #8]
    61e0:	d1000400 	sub	x0, x0, #0x1
    61e4:	f9000420 	str	x0, [x1, #8]
    61e8:	f103f81f 	cmp	x0, #0xfe
    61ec:	54fffae1 	b.ne	6148 <fwp_drop0+0x98>  // b.any
    61f0:	39400260 	ldrb	w0, [x19]
    61f4:	7103fc1f 	cmp	w0, #0xff
    61f8:	540000e0 	b.eq	6214 <fwp_drop0+0x164>  // b.none
    61fc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6200:	39000260 	strb	w0, [x19]
    6204:	17ffffd1 	b	6148 <fwp_drop0+0x98>
    6208:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    620c:	912ba000 	add	x0, x0, #0xae8
    6210:	97fff849 	bl	4334 <fwp_trap>
    6214:	aa1303e0 	mov	x0, x19
    6218:	97fff867 	bl	43b4 <fwp_rc_forget_slot.part.0>
    621c:	17fffff8 	b	61fc <fwp_drop0+0x14c>

0000000000006220 <fwp_drop1>:
    6220:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6224:	910003fd 	mov	x29, sp
    6228:	a90153f3 	stp	x19, x20, [sp, #16]
    622c:	f90013f5 	str	x21, [sp, #32]
    6230:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    6234:	9118c2b4 	add	x20, x21, #0x630
    6238:	f949da81 	ldr	x1, [x20, #5040]
    623c:	f949ee82 	ldr	x2, [x20, #5080]
    6240:	cb010001 	sub	x1, x0, x1
    6244:	eb02403f 	cmp	x1, x2, lsl #16
    6248:	54000382 	b.cs	62b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    624c:	d350fc22 	lsr	x2, x1, #16
    6250:	f949fe84 	ldr	x4, [x20, #5112]
    6254:	8b020842 	add	x2, x2, x2, lsl #2
    6258:	d37df042 	lsl	x2, x2, #3
    625c:	8b020083 	add	x3, x4, x2
    6260:	f9401073 	ldr	x19, [x3, #32]
    6264:	b40002b3 	cbz	x19, 62b8 <fwp_drop1+0x98>
    6268:	38626882 	ldrb	w2, [x4, x2]
    626c:	7100085f 	cmp	w2, #0x2
    6270:	540002c0 	b.eq	62c8 <fwp_drop1+0xa8>  // b.none
    6274:	7100045f 	cmp	w2, #0x1
    6278:	54000201 	b.ne	62b8 <fwp_drop1+0x98>  // b.any
    627c:	29430864 	ldp	w4, w2, [x3, #24]
    6280:	92403c21 	and	x1, x1, #0xffff
    6284:	9b047c21 	mul	x1, x1, x4
    6288:	d360fc21 	lsr	x1, x1, #32
    628c:	eb02003f 	cmp	x1, x2
    6290:	54000142 	b.cs	62b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6294:	8b010273 	add	x19, x19, x1
    6298:	39400261 	ldrb	w1, [x19]
    629c:	340000e1 	cbz	w1, 62b8 <fwp_drop1+0x98>
    62a0:	7100043f 	cmp	w1, #0x1
    62a4:	540001e0 	b.eq	62e0 <fwp_drop1+0xc0>  // b.none
    62a8:	7103fc3f 	cmp	w1, #0xff
    62ac:	540002e0 	b.eq	6308 <fwp_drop1+0xe8>  // b.none
    62b0:	51000421 	sub	w1, w1, #0x1
    62b4:	39000261 	strb	w1, [x19]
    62b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    62bc:	f94013f5 	ldr	x21, [sp, #32]
    62c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62c4:	d65f03c0 	ret
    62c8:	72003c3f 	tst	w1, #0xffff
    62cc:	54fffe60 	b.eq	6298 <fwp_drop1+0x78>  // b.none
    62d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    62d4:	f94013f5 	ldr	x21, [sp, #32]
    62d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62dc:	d65f03c0 	ret
    62e0:	f9400813 	ldr	x19, [x0, #16]
    62e4:	97fffe97 	bl	5d40 <fwp_rc_free_arr>
    62e8:	9118c2a0 	add	x0, x21, #0x630
    62ec:	f949d801 	ldr	x1, [x0, #5040]
    62f0:	f949ec00 	ldr	x0, [x0, #5080]
    62f4:	cb010261 	sub	x1, x19, x1
    62f8:	eb00403f 	cmp	x1, x0, lsl #16
    62fc:	54fffde2 	b.cs	62b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6300:	aa1303e0 	mov	x0, x19
    6304:	17ffffd2 	b	624c <fwp_drop1+0x2c>
    6308:	ca534660 	eor	x0, x19, x19, lsr #17
    630c:	9118c2b5 	add	x21, x21, #0x630
    6310:	ca402400 	eor	x0, x0, x0, lsr #9
    6314:	92401c00 	and	x0, x0, #0xff
    6318:	910a2402 	add	x2, x0, #0x289
    631c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6320:	8b020ea2 	add	x2, x21, x2, lsl #3
    6324:	f94a2400 	ldr	x0, [x0, #5192]
    6328:	b50000a0 	cbnz	x0, 633c <fwp_drop1+0x11c>
    632c:	14000013 	b	6378 <fwp_drop1+0x158>
    6330:	91004002 	add	x2, x0, #0x10
    6334:	f9400800 	ldr	x0, [x0, #16]
    6338:	b4000200 	cbz	x0, 6378 <fwp_drop1+0x158>
    633c:	f9400001 	ldr	x1, [x0]
    6340:	eb13003f 	cmp	x1, x19
    6344:	54ffff61 	b.ne	6330 <fwp_drop1+0x110>  // b.any
    6348:	f9400041 	ldr	x1, [x2]
    634c:	f9400420 	ldr	x0, [x1, #8]
    6350:	d1000400 	sub	x0, x0, #0x1
    6354:	f9000420 	str	x0, [x1, #8]
    6358:	f103f81f 	cmp	x0, #0xfe
    635c:	54fffae1 	b.ne	62b8 <fwp_drop1+0x98>  // b.any
    6360:	39400260 	ldrb	w0, [x19]
    6364:	7103fc1f 	cmp	w0, #0xff
    6368:	540000e0 	b.eq	6384 <fwp_drop1+0x164>  // b.none
    636c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6370:	39000260 	strb	w0, [x19]
    6374:	17ffffd1 	b	62b8 <fwp_drop1+0x98>
    6378:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    637c:	912ba000 	add	x0, x0, #0xae8
    6380:	97fff7ed 	bl	4334 <fwp_trap>
    6384:	aa1303e0 	mov	x0, x19
    6388:	97fff80b 	bl	43b4 <fwp_rc_forget_slot.part.0>
    638c:	17fffff8 	b	636c <fwp_drop1+0x14c>

0000000000006390 <fwp_closure_drop>:
    6390:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xbb0>
    6394:	9118c0a4 	add	x4, x5, #0x630
    6398:	aa0003e1 	mov	x1, x0
    639c:	f949d882 	ldr	x2, [x4, #5040]
    63a0:	f949ec80 	ldr	x0, [x4, #5080]
    63a4:	cb020022 	sub	x2, x1, x2
    63a8:	eb00405f 	cmp	x2, x0, lsl #16
    63ac:	54000662 	b.cs	6478 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    63b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    63b4:	d350fc43 	lsr	x3, x2, #16
    63b8:	910003fd 	mov	x29, sp
    63bc:	8b030863 	add	x3, x3, x3, lsl #2
    63c0:	f949fc84 	ldr	x4, [x4, #5112]
    63c4:	d37df063 	lsl	x3, x3, #3
    63c8:	f9000bf3 	str	x19, [sp, #16]
    63cc:	8b030080 	add	x0, x4, x3
    63d0:	f9401013 	ldr	x19, [x0, #32]
    63d4:	b40002b3 	cbz	x19, 6428 <fwp_closure_drop+0x98>
    63d8:	38636883 	ldrb	w3, [x4, x3]
    63dc:	7100087f 	cmp	w3, #0x2
    63e0:	54000420 	b.eq	6464 <fwp_closure_drop+0xd4>  // b.none
    63e4:	7100047f 	cmp	w3, #0x1
    63e8:	54000201 	b.ne	6428 <fwp_closure_drop+0x98>  // b.any
    63ec:	29430003 	ldp	w3, w0, [x0, #24]
    63f0:	92403c42 	and	x2, x2, #0xffff
    63f4:	9b037c42 	mul	x2, x2, x3
    63f8:	d360fc42 	lsr	x2, x2, #32
    63fc:	eb00005f 	cmp	x2, x0
    6400:	54000142 	b.cs	6428 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6404:	8b020273 	add	x19, x19, x2
    6408:	39400260 	ldrb	w0, [x19]
    640c:	340000e0 	cbz	w0, 6428 <fwp_closure_drop+0x98>
    6410:	7100041f 	cmp	w0, #0x1
    6414:	54000100 	b.eq	6434 <fwp_closure_drop+0xa4>  // b.none
    6418:	7103fc1f 	cmp	w0, #0xff
    641c:	54000300 	b.eq	647c <fwp_closure_drop+0xec>  // b.none
    6420:	51000400 	sub	w0, w0, #0x1
    6424:	39000260 	strb	w0, [x19]
    6428:	f9400bf3 	ldr	x19, [sp, #16]
    642c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6430:	d65f03c0 	ret
    6434:	d53bd040 	mrs	x0, tpidr_el0
    6438:	91400000 	add	x0, x0, #0x0, lsl #12
    643c:	91004000 	add	x0, x0, #0x10
    6440:	f9400000 	ldr	x0, [x0]
    6444:	b4000080 	cbz	x0, 6454 <fwp_closure_drop+0xc4>
    6448:	f9400bf3 	ldr	x19, [sp, #16]
    644c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6450:	17fff934 	b	4920 <fwp_closure_drop_push>
    6454:	f9400bf3 	ldr	x19, [sp, #16]
    6458:	aa0103e0 	mov	x0, x1
    645c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6460:	17fff975 	b	4a34 <fwp_closure_drop.part.0>
    6464:	72003c5f 	tst	w2, #0xffff
    6468:	54fffd00 	b.eq	6408 <fwp_closure_drop+0x78>  // b.none
    646c:	f9400bf3 	ldr	x19, [sp, #16]
    6470:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6474:	d65f03c0 	ret
    6478:	d65f03c0 	ret
    647c:	ca534660 	eor	x0, x19, x19, lsr #17
    6480:	9118c0a5 	add	x5, x5, #0x630
    6484:	ca402400 	eor	x0, x0, x0, lsr #9
    6488:	92401c00 	and	x0, x0, #0xff
    648c:	910a2402 	add	x2, x0, #0x289
    6490:	8b000ca0 	add	x0, x5, x0, lsl #3
    6494:	8b020ca2 	add	x2, x5, x2, lsl #3
    6498:	f94a2400 	ldr	x0, [x0, #5192]
    649c:	b50000a0 	cbnz	x0, 64b0 <fwp_closure_drop+0x120>
    64a0:	14000013 	b	64ec <fwp_closure_drop+0x15c>
    64a4:	91004002 	add	x2, x0, #0x10
    64a8:	f9400800 	ldr	x0, [x0, #16]
    64ac:	b4000200 	cbz	x0, 64ec <fwp_closure_drop+0x15c>
    64b0:	f9400001 	ldr	x1, [x0]
    64b4:	eb13003f 	cmp	x1, x19
    64b8:	54ffff61 	b.ne	64a4 <fwp_closure_drop+0x114>  // b.any
    64bc:	f9400041 	ldr	x1, [x2]
    64c0:	f9400420 	ldr	x0, [x1, #8]
    64c4:	d1000400 	sub	x0, x0, #0x1
    64c8:	f9000420 	str	x0, [x1, #8]
    64cc:	f103f81f 	cmp	x0, #0xfe
    64d0:	54fffac1 	b.ne	6428 <fwp_closure_drop+0x98>  // b.any
    64d4:	39400260 	ldrb	w0, [x19]
    64d8:	7103fc1f 	cmp	w0, #0xff
    64dc:	540000e0 	b.eq	64f8 <fwp_closure_drop+0x168>  // b.none
    64e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64e4:	39000260 	strb	w0, [x19]
    64e8:	17ffffd0 	b	6428 <fwp_closure_drop+0x98>
    64ec:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    64f0:	912ba000 	add	x0, x0, #0xae8
    64f4:	97fff790 	bl	4334 <fwp_trap>
    64f8:	aa1303e0 	mov	x0, x19
    64fc:	97fff7ae 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6500:	17fffff8 	b	64e0 <fwp_closure_drop+0x150>

0000000000006504 <fwp_owned_tape_release>:
    6504:	b4000920 	cbz	x0, 6628 <fwp_owned_tape_release+0x124>
    6508:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    650c:	910003fd 	mov	x29, sp
    6510:	a90153f3 	stp	x19, x20, [sp, #16]
    6514:	aa0003f3 	mov	x19, x0
    6518:	f9400000 	ldr	x0, [x0]
    651c:	b4000060 	cbz	x0, 6528 <fwp_owned_tape_release+0x24>
    6520:	f9400661 	ldr	x1, [x19, #8]
    6524:	f9000401 	str	x1, [x0, #8]
    6528:	f9400661 	ldr	x1, [x19, #8]
    652c:	b4000041 	cbz	x1, 6534 <fwp_owned_tape_release+0x30>
    6530:	f9000020 	str	x0, [x1]
    6534:	f9400a60 	ldr	x0, [x19, #16]
    6538:	f9403401 	ldr	x1, [x0, #104]
    653c:	b40005a1 	cbz	x1, 65f0 <fwp_owned_tape_release+0xec>
    6540:	a9450a60 	ldp	x0, x2, [x19, #80]
    6544:	eb00005f 	cmp	x2, x0
    6548:	540002cd 	b.le	65a0 <fwp_owned_tape_release+0x9c>
    654c:	d2800014 	mov	x20, #0x0                   	// #0
    6550:	f90013f5 	str	x21, [sp, #32]
    6554:	d2800015 	mov	x21, #0x0                   	// #0
    6558:	f9402260 	ldr	x0, [x19, #64]
    655c:	910006b5 	add	x21, x21, #0x1
    6560:	f8746800 	ldr	x0, [x0, x20]
    6564:	d63f0020 	blr	x1
    6568:	f9402260 	ldr	x0, [x19, #64]
    656c:	f9400a61 	ldr	x1, [x19, #16]
    6570:	8b140000 	add	x0, x0, x20
    6574:	91004294 	add	x20, x20, #0x10
    6578:	f9400400 	ldr	x0, [x0, #8]
    657c:	f9403421 	ldr	x1, [x1, #104]
    6580:	d63f0020 	blr	x1
    6584:	a9450261 	ldp	x1, x0, [x19, #80]
    6588:	cb010000 	sub	x0, x0, x1
    658c:	eb15001f 	cmp	x0, x21
    6590:	f9400a60 	ldr	x0, [x19, #16]
    6594:	f9403401 	ldr	x1, [x0, #104]
    6598:	54fffe0c 	b.gt	6558 <fwp_owned_tape_release+0x54>
    659c:	f94013f5 	ldr	x21, [sp, #32]
    65a0:	f9403663 	ldr	x3, [x19, #104]
    65a4:	f9401262 	ldr	x2, [x19, #32]
    65a8:	f100007f 	cmp	x3, #0x0
    65ac:	540001ed 	b.le	65e8 <fwp_owned_tape_release+0xe4>
    65b0:	d2800014 	mov	x20, #0x0                   	// #0
    65b4:	d503201f 	nop
    65b8:	f9402660 	ldr	x0, [x19, #72]
    65bc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    65c0:	eb02001f 	cmp	x0, x2
    65c4:	540000c0 	b.eq	65dc <fwp_owned_tape_release+0xd8>  // b.none
    65c8:	d63f0020 	blr	x1
    65cc:	f9400a60 	ldr	x0, [x19, #16]
    65d0:	f9401262 	ldr	x2, [x19, #32]
    65d4:	f9403663 	ldr	x3, [x19, #104]
    65d8:	f9403401 	ldr	x1, [x0, #104]
    65dc:	91000694 	add	x20, x20, #0x1
    65e0:	eb14007f 	cmp	x3, x20
    65e4:	54fffeac 	b.gt	65b8 <fwp_owned_tape_release+0xb4>
    65e8:	aa0203e0 	mov	x0, x2
    65ec:	d63f0020 	blr	x1
    65f0:	f9401660 	ldr	x0, [x19, #40]
    65f4:	97ffff67 	bl	6390 <fwp_closure_drop>
    65f8:	f9401a60 	ldr	x0, [x19, #48]
    65fc:	97ffff65 	bl	6390 <fwp_closure_drop>
    6600:	f9401e60 	ldr	x0, [x19, #56]
    6604:	97ffff63 	bl	6390 <fwp_closure_drop>
    6608:	f9402260 	ldr	x0, [x19, #64]
    660c:	97fff805 	bl	4620 <fwp_mem_free>
    6610:	f9402660 	ldr	x0, [x19, #72]
    6614:	97fff803 	bl	4620 <fwp_mem_free>
    6618:	aa1303e0 	mov	x0, x19
    661c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6620:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6624:	17fff7ff 	b	4620 <fwp_mem_free>
    6628:	d65f03c0 	ret
    662c:	d503201f 	nop

0000000000006630 <fwp_tape_finish>:
    6630:	d10203ff 	sub	sp, sp, #0x80
    6634:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    6638:	f947f421 	ldr	x1, [x1, #4072]
    663c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6640:	910103fd 	add	x29, sp, #0x40
    6644:	a9065bf5 	stp	x21, x22, [sp, #96]
    6648:	a90763f7 	stp	x23, x24, [sp, #112]
    664c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6650:	910142f6 	add	x22, x23, #0x50
    6654:	f9400022 	ldr	x2, [x1]
    6658:	f9001fe2 	str	x2, [sp, #56]
    665c:	d2800002 	mov	x2, #0x0                   	// #0
    6660:	910342c0 	add	x0, x22, #0xd0
    6664:	97fff684 	bl	4074 <fwp_tape_buffers_dispose>
    6668:	f90086df 	str	xzr, [x22, #264]
    666c:	f94092c0 	ldr	x0, [x22, #288]
    6670:	f100001f 	cmp	x0, #0x0
    6674:	5400034d 	b.le	66dc <fwp_tape_finish+0xac>
    6678:	910003f8 	mov	x24, sp
    667c:	d2800015 	mov	x21, #0x0                   	// #0
    6680:	a90553f3 	stp	x19, x20, [sp, #80]
    6684:	d2800014 	mov	x20, #0x0                   	// #0
    6688:	91000694 	add	x20, x20, #0x1
    668c:	f94046d3 	ldr	x19, [x22, #136]
    6690:	8b150273 	add	x19, x19, x21
    6694:	9101a2b5 	add	x21, x21, #0x68
    6698:	aa1303e0 	mov	x0, x19
    669c:	97fff25e 	bl	3014 <fwp_tape_unlink_scope>
    66a0:	aa1803e0 	mov	x0, x24
    66a4:	a9440663 	ldp	x3, x1, [x19, #64]
    66a8:	f9001be1 	str	x1, [sp, #48]
    66ac:	f9400e62 	ldr	x2, [x19, #24]
    66b0:	a9020be3 	stp	x3, x2, [sp, #32]
    66b4:	ad410261 	ldp	q1, q0, [x19, #32]
    66b8:	ad0003e1 	stp	q1, q0, [sp]
    66bc:	97fff66e 	bl	4074 <fwp_tape_buffers_dispose>
    66c0:	f9403260 	ldr	x0, [x19, #96]
    66c4:	97ffff90 	bl	6504 <fwp_owned_tape_release>
    66c8:	f900327f 	str	xzr, [x19, #96]
    66cc:	f94092c0 	ldr	x0, [x22, #288]
    66d0:	eb14001f 	cmp	x0, x20
    66d4:	54fffdac 	b.gt	6688 <fwp_tape_finish+0x58>
    66d8:	a94553f3 	ldp	x19, x20, [sp, #80]
    66dc:	910142e0 	add	x0, x23, #0x50
    66e0:	f9404400 	ldr	x0, [x0, #136]
    66e4:	b4000040 	cbz	x0, 66ec <fwp_tape_finish+0xbc>
    66e8:	97fff642 	bl	3ff0 <ad_raw_free.part.0>
    66ec:	910142f7 	add	x23, x23, #0x50
    66f0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    66f4:	f947f400 	ldr	x0, [x0, #4072]
    66f8:	f90046ff 	str	xzr, [x23, #136]
    66fc:	f9008aff 	str	xzr, [x23, #272]
    6700:	f90092ff 	str	xzr, [x23, #288]
    6704:	f900b2ff 	str	xzr, [x23, #352]
    6708:	f9401fe2 	ldr	x2, [sp, #56]
    670c:	f9400001 	ldr	x1, [x0]
    6710:	eb010042 	subs	x2, x2, x1
    6714:	d2800001 	mov	x1, #0x0                   	// #0
    6718:	540000c1 	b.ne	6730 <fwp_tape_finish+0x100>  // b.any
    671c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6720:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6724:	a94763f7 	ldp	x23, x24, [sp, #112]
    6728:	910203ff 	add	sp, sp, #0x80
    672c:	d65f03c0 	ret
    6730:	a90553f3 	stp	x19, x20, [sp, #80]
    6734:	97fff05b 	bl	28a0 <__stack_chk_fail@plt>
    6738:	d503201f 	nop
    673c:	d503201f 	nop

0000000000006740 <fwp_tape_scope_release>:
    6740:	d10243ff 	sub	sp, sp, #0x90
    6744:	a9047bfd 	stp	x29, x30, [sp, #64]
    6748:	910103fd 	add	x29, sp, #0x40
    674c:	a90553f3 	stp	x19, x20, [sp, #80]
    6750:	aa0003f4 	mov	x20, x0
    6754:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6758:	f947f400 	ldr	x0, [x0, #4072]
    675c:	b9400285 	ldr	w5, [x20]
    6760:	f9400001 	ldr	x1, [x0]
    6764:	f9001fe1 	str	x1, [sp, #56]
    6768:	d2800001 	mov	x1, #0x0                   	// #0
    676c:	37f806c5 	tbnz	w5, #31, 6844 <fwp_tape_scope_release+0x104>
    6770:	a90763f7 	stp	x23, x24, [sp, #112]
    6774:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6778:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    677c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6780:	d00000d3 	adrp	x19, 20000 <__data_start>
    6784:	910003f7 	mov	x23, sp
    6788:	91014273 	add	x19, x19, #0x50
    678c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6790:	a9065bf5 	stp	x21, x22, [sp, #96]
    6794:	52800d16 	mov	w22, #0x68                  	// #104
    6798:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    679c:	f90043f9 	str	x25, [sp, #128]
    67a0:	14000006 	b	67b8 <fwp_tape_scope_release+0x78>
    67a4:	97fff634 	bl	4074 <fwp_tape_buffers_dispose>
    67a8:	aa1903e0 	mov	x0, x25
    67ac:	97ffff56 	bl	6504 <fwp_owned_tape_release>
    67b0:	b9400285 	ldr	w5, [x20]
    67b4:	37f80425 	tbnz	w5, #31, 6838 <fwp_tape_scope_release+0xf8>
    67b8:	f9404666 	ldr	x6, [x19, #136]
    67bc:	9b367ca5 	smull	x5, w5, w22
    67c0:	8b0500c0 	add	x0, x6, x5
    67c4:	97fff214 	bl	3014 <fwp_tape_unlink_scope>
    67c8:	ad410001 	ldp	q1, q0, [x0, #32]
    67cc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    67d0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    67d4:	f9400c03 	ldr	x3, [x0, #24]
    67d8:	ad0003e1 	stp	q1, q0, [sp]
    67dc:	b86568c1 	ldr	w1, [x6, x5]
    67e0:	a9440804 	ldp	x4, x2, [x0, #64]
    67e4:	b900041f 	str	wzr, [x0, #4]
    67e8:	f9403019 	ldr	x25, [x0, #96]
    67ec:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    67f0:	f9000c1f 	str	xzr, [x0, #24]
    67f4:	a9020fe4 	stp	x4, x3, [sp, #32]
    67f8:	f9001be2 	str	x2, [sp, #48]
    67fc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6800:	f900301f 	str	xzr, [x0, #96]
    6804:	6b15003f 	cmp	w1, w21
    6808:	540000e8 	b.hi	6824 <fwp_tape_scope_release+0xe4>  // b.pmore
    680c:	9343fca5 	asr	x5, x5, #3
    6810:	f940b260 	ldr	x0, [x19, #352]
    6814:	9b187ca5 	mul	x5, x5, x24
    6818:	eb0000bf 	cmp	x5, x0
    681c:	5400004a 	b.ge	6824 <fwp_tape_scope_release+0xe4>  // b.tcont
    6820:	f900b265 	str	x5, [x19, #352]
    6824:	aa1703e0 	mov	x0, x23
    6828:	b5fffbf9 	cbnz	x25, 67a4 <fwp_tape_scope_release+0x64>
    682c:	97fff65a 	bl	4194 <fwp_tape_buffers_release>
    6830:	b9400285 	ldr	w5, [x20]
    6834:	36fffc25 	tbz	w5, #31, 67b8 <fwp_tape_scope_release+0x78>
    6838:	a9465bf5 	ldp	x21, x22, [sp, #96]
    683c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6840:	f94043f9 	ldr	x25, [sp, #128]
    6844:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    6848:	f947f400 	ldr	x0, [x0, #4072]
    684c:	f9401fe2 	ldr	x2, [sp, #56]
    6850:	f9400001 	ldr	x1, [x0]
    6854:	eb010042 	subs	x2, x2, x1
    6858:	d2800001 	mov	x1, #0x0                   	// #0
    685c:	540000a1 	b.ne	6870 <fwp_tape_scope_release+0x130>  // b.any
    6860:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6864:	a94553f3 	ldp	x19, x20, [sp, #80]
    6868:	910243ff 	add	sp, sp, #0x90
    686c:	d65f03c0 	ret
    6870:	a9065bf5 	stp	x21, x22, [sp, #96]
    6874:	a90763f7 	stp	x23, x24, [sp, #112]
    6878:	f90043f9 	str	x25, [sp, #128]
    687c:	97fff009 	bl	28a0 <__stack_chk_fail@plt>

0000000000006880 <fwp_drop4>:
    6880:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6884:	910003fd 	mov	x29, sp
    6888:	a9025bf5 	stp	x21, x22, [sp, #32]
    688c:	f0000396 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    6890:	9118c2d5 	add	x21, x22, #0x630
    6894:	a90153f3 	stp	x19, x20, [sp, #16]
    6898:	aa0003f3 	mov	x19, x0
    689c:	f949daa1 	ldr	x1, [x21, #5040]
    68a0:	f949eea0 	ldr	x0, [x21, #5080]
    68a4:	cb010261 	sub	x1, x19, x1
    68a8:	eb00403f 	cmp	x1, x0, lsl #16
    68ac:	54000382 	b.cs	691c <fwp_drop4+0x9c>  // b.hs, b.nlast
    68b0:	d350fc22 	lsr	x2, x1, #16
    68b4:	f949fea3 	ldr	x3, [x21, #5112]
    68b8:	8b020842 	add	x2, x2, x2, lsl #2
    68bc:	d37df042 	lsl	x2, x2, #3
    68c0:	8b020060 	add	x0, x3, x2
    68c4:	f9401014 	ldr	x20, [x0, #32]
    68c8:	b40002b4 	cbz	x20, 691c <fwp_drop4+0x9c>
    68cc:	38626862 	ldrb	w2, [x3, x2]
    68d0:	7100085f 	cmp	w2, #0x2
    68d4:	540002c0 	b.eq	692c <fwp_drop4+0xac>  // b.none
    68d8:	7100045f 	cmp	w2, #0x1
    68dc:	54000201 	b.ne	691c <fwp_drop4+0x9c>  // b.any
    68e0:	29430002 	ldp	w2, w0, [x0, #24]
    68e4:	92403c21 	and	x1, x1, #0xffff
    68e8:	9b027c21 	mul	x1, x1, x2
    68ec:	d360fc21 	lsr	x1, x1, #32
    68f0:	eb00003f 	cmp	x1, x0
    68f4:	54000142 	b.cs	691c <fwp_drop4+0x9c>  // b.hs, b.nlast
    68f8:	8b010294 	add	x20, x20, x1
    68fc:	39400280 	ldrb	w0, [x20]
    6900:	340000e0 	cbz	w0, 691c <fwp_drop4+0x9c>
    6904:	7100041f 	cmp	w0, #0x1
    6908:	540001e0 	b.eq	6944 <fwp_drop4+0xc4>  // b.none
    690c:	7103fc1f 	cmp	w0, #0xff
    6910:	540007c0 	b.eq	6a08 <fwp_drop4+0x188>  // b.none
    6914:	51000400 	sub	w0, w0, #0x1
    6918:	39000280 	strb	w0, [x20]
    691c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6920:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6924:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6928:	d65f03c0 	ret
    692c:	72003c3f 	tst	w1, #0xffff
    6930:	54fffe60 	b.eq	68fc <fwp_drop4+0x7c>  // b.none
    6934:	a94153f3 	ldp	x19, x20, [sp, #16]
    6938:	a9425bf5 	ldp	x21, x22, [sp, #32]
    693c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6940:	d65f03c0 	ret
    6944:	9118c2c2 	add	x2, x22, #0x630
    6948:	f9400660 	ldr	x0, [x19, #8]
    694c:	f949d841 	ldr	x1, [x2, #5040]
    6950:	f949ec42 	ldr	x2, [x2, #5080]
    6954:	cb010001 	sub	x1, x0, x1
    6958:	eb02403f 	cmp	x1, x2, lsl #16
    695c:	54000362 	b.cs	69c8 <fwp_drop4+0x148>  // b.hs, b.nlast
    6960:	d350fc22 	lsr	x2, x1, #16
    6964:	8b020842 	add	x2, x2, x2, lsl #2
    6968:	d37df042 	lsl	x2, x2, #3
    696c:	8b020064 	add	x4, x3, x2
    6970:	f9401094 	ldr	x20, [x4, #32]
    6974:	b40002b4 	cbz	x20, 69c8 <fwp_drop4+0x148>
    6978:	38626862 	ldrb	w2, [x3, x2]
    697c:	7100085f 	cmp	w2, #0x2
    6980:	540003e0 	b.eq	69fc <fwp_drop4+0x17c>  // b.none
    6984:	7100045f 	cmp	w2, #0x1
    6988:	54000201 	b.ne	69c8 <fwp_drop4+0x148>  // b.any
    698c:	29430883 	ldp	w3, w2, [x4, #24]
    6990:	92403c21 	and	x1, x1, #0xffff
    6994:	9b037c21 	mul	x1, x1, x3
    6998:	d360fc21 	lsr	x1, x1, #32
    699c:	eb02003f 	cmp	x1, x2
    69a0:	54000142 	b.cs	69c8 <fwp_drop4+0x148>  // b.hs, b.nlast
    69a4:	8b010294 	add	x20, x20, x1
    69a8:	39400281 	ldrb	w1, [x20]
    69ac:	340000e1 	cbz	w1, 69c8 <fwp_drop4+0x148>
    69b0:	7100043f 	cmp	w1, #0x1
    69b4:	54000200 	b.eq	69f4 <fwp_drop4+0x174>  // b.none
    69b8:	7103fc3f 	cmp	w1, #0xff
    69bc:	54000640 	b.eq	6a84 <fwp_drop4+0x204>  // b.none
    69c0:	51000421 	sub	w1, w1, #0x1
    69c4:	39000281 	strb	w1, [x20]
    69c8:	f9400a74 	ldr	x20, [x19, #16]
    69cc:	aa1303e0 	mov	x0, x19
    69d0:	97fffcdc 	bl	5d40 <fwp_rc_free_arr>
    69d4:	9118c2c0 	add	x0, x22, #0x630
    69d8:	f949d801 	ldr	x1, [x0, #5040]
    69dc:	f949ec00 	ldr	x0, [x0, #5080]
    69e0:	cb010281 	sub	x1, x20, x1
    69e4:	eb00403f 	cmp	x1, x0, lsl #16
    69e8:	54fff9a2 	b.cs	691c <fwp_drop4+0x9c>  // b.hs, b.nlast
    69ec:	aa1403f3 	mov	x19, x20
    69f0:	17ffffb0 	b	68b0 <fwp_drop4+0x30>
    69f4:	97fffcd3 	bl	5d40 <fwp_rc_free_arr>
    69f8:	17fffff4 	b	69c8 <fwp_drop4+0x148>
    69fc:	72003c3f 	tst	w1, #0xffff
    6a00:	54fffe41 	b.ne	69c8 <fwp_drop4+0x148>  // b.any
    6a04:	17ffffe9 	b	69a8 <fwp_drop4+0x128>
    6a08:	ca544681 	eor	x1, x20, x20, lsr #17
    6a0c:	9118c2c0 	add	x0, x22, #0x630
    6a10:	ca412421 	eor	x1, x1, x1, lsr #9
    6a14:	92401c21 	and	x1, x1, #0xff
    6a18:	910a2422 	add	x2, x1, #0x289
    6a1c:	8b010c01 	add	x1, x0, x1, lsl #3
    6a20:	8b020c02 	add	x2, x0, x2, lsl #3
    6a24:	f94a2420 	ldr	x0, [x1, #5192]
    6a28:	b50000a0 	cbnz	x0, 6a3c <fwp_drop4+0x1bc>
    6a2c:	14000013 	b	6a78 <fwp_drop4+0x1f8>
    6a30:	91004002 	add	x2, x0, #0x10
    6a34:	f9400800 	ldr	x0, [x0, #16]
    6a38:	b4000200 	cbz	x0, 6a78 <fwp_drop4+0x1f8>
    6a3c:	f9400001 	ldr	x1, [x0]
    6a40:	eb14003f 	cmp	x1, x20
    6a44:	54ffff61 	b.ne	6a30 <fwp_drop4+0x1b0>  // b.any
    6a48:	f9400041 	ldr	x1, [x2]
    6a4c:	f9400420 	ldr	x0, [x1, #8]
    6a50:	d1000400 	sub	x0, x0, #0x1
    6a54:	f9000420 	str	x0, [x1, #8]
    6a58:	f103f81f 	cmp	x0, #0xfe
    6a5c:	54fff601 	b.ne	691c <fwp_drop4+0x9c>  // b.any
    6a60:	39400280 	ldrb	w0, [x20]
    6a64:	7103fc1f 	cmp	w0, #0xff
    6a68:	54000460 	b.eq	6af4 <fwp_drop4+0x274>  // b.none
    6a6c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6a70:	39000280 	strb	w0, [x20]
    6a74:	17ffffaa 	b	691c <fwp_drop4+0x9c>
    6a78:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    6a7c:	912ba000 	add	x0, x0, #0xae8
    6a80:	97fff62d 	bl	4334 <fwp_trap>
    6a84:	ca544680 	eor	x0, x20, x20, lsr #17
    6a88:	9118c2c1 	add	x1, x22, #0x630
    6a8c:	ca402400 	eor	x0, x0, x0, lsr #9
    6a90:	92401c00 	and	x0, x0, #0xff
    6a94:	910a2402 	add	x2, x0, #0x289
    6a98:	8b000c20 	add	x0, x1, x0, lsl #3
    6a9c:	8b020c22 	add	x2, x1, x2, lsl #3
    6aa0:	f94a2400 	ldr	x0, [x0, #5192]
    6aa4:	b50000a0 	cbnz	x0, 6ab8 <fwp_drop4+0x238>
    6aa8:	17fffff4 	b	6a78 <fwp_drop4+0x1f8>
    6aac:	91004002 	add	x2, x0, #0x10
    6ab0:	f9400800 	ldr	x0, [x0, #16]
    6ab4:	b4fffe20 	cbz	x0, 6a78 <fwp_drop4+0x1f8>
    6ab8:	f9400001 	ldr	x1, [x0]
    6abc:	eb14003f 	cmp	x1, x20
    6ac0:	54ffff61 	b.ne	6aac <fwp_drop4+0x22c>  // b.any
    6ac4:	f9400041 	ldr	x1, [x2]
    6ac8:	f9400420 	ldr	x0, [x1, #8]
    6acc:	d1000400 	sub	x0, x0, #0x1
    6ad0:	f9000420 	str	x0, [x1, #8]
    6ad4:	f103f81f 	cmp	x0, #0xfe
    6ad8:	54fff781 	b.ne	69c8 <fwp_drop4+0x148>  // b.any
    6adc:	39400280 	ldrb	w0, [x20]
    6ae0:	7103fc1f 	cmp	w0, #0xff
    6ae4:	540000e0 	b.eq	6b00 <fwp_drop4+0x280>  // b.none
    6ae8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6aec:	39000280 	strb	w0, [x20]
    6af0:	17ffffb6 	b	69c8 <fwp_drop4+0x148>
    6af4:	aa1403e0 	mov	x0, x20
    6af8:	97fff62f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6afc:	17ffffdc 	b	6a6c <fwp_drop4+0x1ec>
    6b00:	aa1403e0 	mov	x0, x20
    6b04:	97fff62c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6b08:	17fffff8 	b	6ae8 <fwp_drop4+0x268>
    6b0c:	d503201f 	nop

0000000000006b10 <fwp_arg_drop37>:
    6b10:	7100003f 	cmp	w1, #0x0
    6b14:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6b18:	54000041 	b.ne	6b20 <fwp_arg_drop37+0x10>  // b.any
    6b1c:	d65f03c0 	ret
    6b20:	f9400000 	ldr	x0, [x0]
    6b24:	17ffff57 	b	6880 <fwp_drop4>
    6b28:	d503201f 	nop
    6b2c:	d503201f 	nop

0000000000006b30 <fwp_task_dispose>:
    6b30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b34:	910003fd 	mov	x29, sp
    6b38:	f9000bf3 	str	x19, [sp, #16]
    6b3c:	aa0003f3 	mov	x19, x0
    6b40:	39414000 	ldrb	w0, [x0, #80]
    6b44:	36000720 	tbz	w0, #0, 6c28 <fwp_task_dispose+0xf8>
    6b48:	f9400a60 	ldr	x0, [x19, #16]
    6b4c:	b50006e0 	cbnz	x0, 6c28 <fwp_task_dispose+0xf8>
    6b50:	a9478660 	ldp	x0, x1, [x19, #120]
    6b54:	39014e7f 	strb	wzr, [x19, #83]
    6b58:	f9003e7f 	str	xzr, [x19, #120]
    6b5c:	f100003f 	cmp	x1, #0x0
    6b60:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6b64:	54000040 	b.eq	6b6c <fwp_task_dispose+0x3c>  // b.none
    6b68:	d63f0020 	blr	x1
    6b6c:	f9405660 	ldr	x0, [x19, #168]
    6b70:	97fff6ac 	bl	4620 <fwp_mem_free>
    6b74:	f900567f 	str	xzr, [x19, #168]
    6b78:	b9405e60 	ldr	w0, [x19, #92]
    6b7c:	7100041f 	cmp	w0, #0x1
    6b80:	54000420 	b.eq	6c04 <fwp_task_dispose+0xd4>  // b.none
    6b84:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6b88:	9118c042 	add	x2, x2, #0x630
    6b8c:	f949d840 	ldr	x0, [x2, #5040]
    6b90:	f949ec41 	ldr	x1, [x2, #5080]
    6b94:	cb000260 	sub	x0, x19, x0
    6b98:	eb01401f 	cmp	x0, x1, lsl #16
    6b9c:	540002e2 	b.cs	6bf8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6ba0:	d350fc01 	lsr	x1, x0, #16
    6ba4:	f949fc44 	ldr	x4, [x2, #5112]
    6ba8:	8b010821 	add	x1, x1, x1, lsl #2
    6bac:	d37df021 	lsl	x1, x1, #3
    6bb0:	8b010083 	add	x3, x4, x1
    6bb4:	f9401062 	ldr	x2, [x3, #32]
    6bb8:	b4000202 	cbz	x2, 6bf8 <fwp_task_dispose+0xc8>
    6bbc:	38616881 	ldrb	w1, [x4, x1]
    6bc0:	7100083f 	cmp	w1, #0x2
    6bc4:	54000280 	b.eq	6c14 <fwp_task_dispose+0xe4>  // b.none
    6bc8:	7100043f 	cmp	w1, #0x1
    6bcc:	54000161 	b.ne	6bf8 <fwp_task_dispose+0xc8>  // b.any
    6bd0:	29430464 	ldp	w4, w1, [x3, #24]
    6bd4:	92403c00 	and	x0, x0, #0xffff
    6bd8:	9b047c00 	mul	x0, x0, x4
    6bdc:	d360fc00 	lsr	x0, x0, #32
    6be0:	eb01001f 	cmp	x0, x1
    6be4:	540000a2 	b.cs	6bf8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6be8:	8b000042 	add	x2, x2, x0
    6bec:	39400040 	ldrb	w0, [x2]
    6bf0:	7100041f 	cmp	w0, #0x1
    6bf4:	54000080 	b.eq	6c04 <fwp_task_dispose+0xd4>  // b.none
    6bf8:	f9400bf3 	ldr	x19, [sp, #16]
    6bfc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c00:	d65f03c0 	ret
    6c04:	aa1303e0 	mov	x0, x19
    6c08:	f9400bf3 	ldr	x19, [sp, #16]
    6c0c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c10:	17fff684 	b	4620 <fwp_mem_free>
    6c14:	72003c1f 	tst	w0, #0xffff
    6c18:	54fffea0 	b.eq	6bec <fwp_task_dispose+0xbc>  // b.none
    6c1c:	f9400bf3 	ldr	x19, [sp, #16]
    6c20:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c24:	d65f03c0 	ret
    6c28:	97ffef32 	bl	28f0 <abort@plt>
    6c2c:	d503201f 	nop

0000000000006c30 <fwp_free_zombie>:
    6c30:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c34:	910003fd 	mov	x29, sp
    6c38:	a90153f3 	stp	x19, x20, [sp, #16]
    6c3c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6c40:	91014281 	add	x1, x20, #0x50
    6c44:	f940b433 	ldr	x19, [x1, #360]
    6c48:	b4000333 	cbz	x19, 6cac <fwp_free_zombie+0x7c>
    6c4c:	f9404c20 	ldr	x0, [x1, #152]
    6c50:	eb00027f 	cmp	x19, x0
    6c54:	540002c0 	b.eq	6cac <fwp_free_zombie+0x7c>  // b.none
    6c58:	b9417022 	ldr	w2, [x1, #368]
    6c5c:	f9400a60 	ldr	x0, [x19, #16]
    6c60:	7100fc5f 	cmp	w2, #0x3f
    6c64:	5400078c 	b.gt	6d54 <fwp_free_zombie+0x124>
    6c68:	91060023 	add	x3, x1, #0x180
    6c6c:	11000444 	add	w4, w2, #0x1
    6c70:	b9017024 	str	w4, [x1, #368]
    6c74:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6c78:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6c7c:	a9530261 	ldp	x1, x0, [x19, #304]
    6c80:	b4000741 	cbz	x1, 6d68 <fwp_free_zombie+0x138>
    6c84:	f9009c20 	str	x0, [x1, #312]
    6c88:	b4000040 	cbz	x0, 6c90 <fwp_free_zombie+0x60>
    6c8c:	f9009801 	str	x1, [x0, #304]
    6c90:	91014294 	add	x20, x20, #0x50
    6c94:	b9405e60 	ldr	w0, [x19, #92]
    6c98:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6c9c:	f900b69f 	str	xzr, [x20, #360]
    6ca0:	34000140 	cbz	w0, 6cc8 <fwp_free_zombie+0x98>
    6ca4:	7100041f 	cmp	w0, #0x1
    6ca8:	54000080 	b.eq	6cb8 <fwp_free_zombie+0x88>  // b.none
    6cac:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cb0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6cb4:	d65f03c0 	ret
    6cb8:	aa1303e0 	mov	x0, x19
    6cbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6cc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6cc4:	17ffff9b 	b	6b30 <fwp_task_dispose>
    6cc8:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbb0>
    6ccc:	9118c082 	add	x2, x4, #0x630
    6cd0:	f949d841 	ldr	x1, [x2, #5040]
    6cd4:	f949ec40 	ldr	x0, [x2, #5080]
    6cd8:	cb010261 	sub	x1, x19, x1
    6cdc:	eb00403f 	cmp	x1, x0, lsl #16
    6ce0:	54fffe62 	b.cs	6cac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6ce4:	d350fc20 	lsr	x0, x1, #16
    6ce8:	f949fc43 	ldr	x3, [x2, #5112]
    6cec:	8b000800 	add	x0, x0, x0, lsl #2
    6cf0:	d37df000 	lsl	x0, x0, #3
    6cf4:	8b000062 	add	x2, x3, x0
    6cf8:	f9401054 	ldr	x20, [x2, #32]
    6cfc:	b4fffd94 	cbz	x20, 6cac <fwp_free_zombie+0x7c>
    6d00:	38606860 	ldrb	w0, [x3, x0]
    6d04:	7100081f 	cmp	w0, #0x2
    6d08:	54000360 	b.eq	6d74 <fwp_free_zombie+0x144>  // b.none
    6d0c:	7100041f 	cmp	w0, #0x1
    6d10:	54fffce1 	b.ne	6cac <fwp_free_zombie+0x7c>  // b.any
    6d14:	29430043 	ldp	w3, w0, [x2, #24]
    6d18:	92403c21 	and	x1, x1, #0xffff
    6d1c:	9b037c21 	mul	x1, x1, x3
    6d20:	d360fc21 	lsr	x1, x1, #32
    6d24:	eb00003f 	cmp	x1, x0
    6d28:	54fffc22 	b.cs	6cac <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6d2c:	8b010294 	add	x20, x20, x1
    6d30:	39400280 	ldrb	w0, [x20]
    6d34:	34fffbc0 	cbz	w0, 6cac <fwp_free_zombie+0x7c>
    6d38:	7100041f 	cmp	w0, #0x1
    6d3c:	54fffbe0 	b.eq	6cb8 <fwp_free_zombie+0x88>  // b.none
    6d40:	7103fc1f 	cmp	w0, #0xff
    6d44:	540001e0 	b.eq	6d80 <fwp_free_zombie+0x150>  // b.none
    6d48:	51000400 	sub	w0, w0, #0x1
    6d4c:	39000280 	strb	w0, [x20]
    6d50:	17ffffd7 	b	6cac <fwp_free_zombie+0x7c>
    6d54:	f9400e61 	ldr	x1, [x19, #24]
    6d58:	97ffef1a 	bl	29c0 <munmap@plt>
    6d5c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6d60:	a9530261 	ldp	x1, x0, [x19, #304]
    6d64:	b5fff901 	cbnz	x1, 6c84 <fwp_free_zombie+0x54>
    6d68:	91014282 	add	x2, x20, #0x50
    6d6c:	f901c040 	str	x0, [x2, #896]
    6d70:	17ffffc6 	b	6c88 <fwp_free_zombie+0x58>
    6d74:	72003c3f 	tst	w1, #0xffff
    6d78:	54fff9a1 	b.ne	6cac <fwp_free_zombie+0x7c>  // b.any
    6d7c:	17ffffed 	b	6d30 <fwp_free_zombie+0x100>
    6d80:	ca544680 	eor	x0, x20, x20, lsr #17
    6d84:	9118c084 	add	x4, x4, #0x630
    6d88:	ca402400 	eor	x0, x0, x0, lsr #9
    6d8c:	92401c00 	and	x0, x0, #0xff
    6d90:	910a2402 	add	x2, x0, #0x289
    6d94:	8b000c80 	add	x0, x4, x0, lsl #3
    6d98:	8b020c82 	add	x2, x4, x2, lsl #3
    6d9c:	f94a2400 	ldr	x0, [x0, #5192]
    6da0:	b50000a0 	cbnz	x0, 6db4 <fwp_free_zombie+0x184>
    6da4:	14000013 	b	6df0 <fwp_free_zombie+0x1c0>
    6da8:	91004002 	add	x2, x0, #0x10
    6dac:	f9400800 	ldr	x0, [x0, #16]
    6db0:	b4000200 	cbz	x0, 6df0 <fwp_free_zombie+0x1c0>
    6db4:	f9400001 	ldr	x1, [x0]
    6db8:	eb14003f 	cmp	x1, x20
    6dbc:	54ffff61 	b.ne	6da8 <fwp_free_zombie+0x178>  // b.any
    6dc0:	f9400041 	ldr	x1, [x2]
    6dc4:	f9400420 	ldr	x0, [x1, #8]
    6dc8:	d1000400 	sub	x0, x0, #0x1
    6dcc:	f9000420 	str	x0, [x1, #8]
    6dd0:	f103f81f 	cmp	x0, #0xfe
    6dd4:	54fff6c1 	b.ne	6cac <fwp_free_zombie+0x7c>  // b.any
    6dd8:	39400280 	ldrb	w0, [x20]
    6ddc:	7103fc1f 	cmp	w0, #0xff
    6de0:	540000e0 	b.eq	6dfc <fwp_free_zombie+0x1cc>  // b.none
    6de4:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6de8:	39000280 	strb	w0, [x20]
    6dec:	17ffffb0 	b	6cac <fwp_free_zombie+0x7c>
    6df0:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    6df4:	912ba000 	add	x0, x0, #0xae8
    6df8:	97fff54f 	bl	4334 <fwp_trap>
    6dfc:	aa1403e0 	mov	x0, x20
    6e00:	97fff56d 	bl	43b4 <fwp_rc_forget_slot.part.0>
    6e04:	17fffff8 	b	6de4 <fwp_free_zombie+0x1b4>
    6e08:	d503201f 	nop
    6e0c:	d503201f 	nop

0000000000006e10 <fwp_block>:
    6e10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6e14:	910003fd 	mov	x29, sp
    6e18:	a90153f3 	stp	x19, x20, [sp, #16]
    6e1c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6e20:	91014274 	add	x20, x19, #0x50
    6e24:	f9406682 	ldr	x2, [x20, #200]
    6e28:	b4000642 	cbz	x2, 6ef0 <fwp_block+0xe0>
    6e2c:	91014261 	add	x1, x19, #0x50
    6e30:	f9408040 	ldr	x0, [x2, #256]
    6e34:	f9006420 	str	x0, [x1, #200]
    6e38:	b40006a0 	cbz	x0, 6f0c <fwp_block+0xfc>
    6e3c:	d503201f 	nop
    6e40:	91014263 	add	x3, x19, #0x50
    6e44:	3901505f 	strb	wzr, [x2, #84]
    6e48:	f9404c64 	ldr	x4, [x3, #152]
    6e4c:	eb02009f 	cmp	x4, x2
    6e50:	54000440 	b.eq	6ed8 <fwp_block+0xc8>  // b.none
    6e54:	f941c465 	ldr	x5, [x3, #904]
    6e58:	f9004c62 	str	x2, [x3, #152]
    6e5c:	f9400441 	ldr	x1, [x2, #8]
    6e60:	f9004885 	str	x5, [x4, #144]
    6e64:	f941c865 	ldr	x5, [x3, #912]
    6e68:	f9004c85 	str	x5, [x4, #152]
    6e6c:	f941cc65 	ldr	x5, [x3, #920]
    6e70:	f9005085 	str	x5, [x4, #160]
    6e74:	f941d065 	ldr	x5, [x3, #928]
    6e78:	f9005485 	str	x5, [x4, #168]
    6e7c:	f941d465 	ldr	x5, [x3, #936]
    6e80:	f9005885 	str	x5, [x4, #176]
    6e84:	f941d865 	ldr	x5, [x3, #944]
    6e88:	f9005c85 	str	x5, [x4, #184]
    6e8c:	f941dc65 	ldr	x5, [x3, #952]
    6e90:	f9006085 	str	x5, [x4, #192]
    6e94:	f9400480 	ldr	x0, [x4, #8]
    6e98:	f9404844 	ldr	x4, [x2, #144]
    6e9c:	f901c464 	str	x4, [x3, #904]
    6ea0:	f9404c44 	ldr	x4, [x2, #152]
    6ea4:	f901c864 	str	x4, [x3, #912]
    6ea8:	f9405044 	ldr	x4, [x2, #160]
    6eac:	f901cc64 	str	x4, [x3, #920]
    6eb0:	f9405444 	ldr	x4, [x2, #168]
    6eb4:	f901d064 	str	x4, [x3, #928]
    6eb8:	f9405844 	ldr	x4, [x2, #176]
    6ebc:	f901d464 	str	x4, [x3, #936]
    6ec0:	a94b8844 	ldp	x4, x2, [x2, #184]
    6ec4:	f901d864 	str	x4, [x3, #944]
    6ec8:	f901dc62 	str	x2, [x3, #952]
    6ecc:	97ffee8d 	bl	2900 <swapcontext@plt>
    6ed0:	97ffff58 	bl	6c30 <fwp_free_zombie>
    6ed4:	d503201f 	nop
    6ed8:	91014260 	add	x0, x19, #0x50
    6edc:	b943c000 	ldr	w0, [x0, #960]
    6ee0:	340001a0 	cbz	w0, 6f14 <fwp_block+0x104>
    6ee4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ee8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6eec:	d65f03c0 	ret
    6ef0:	97fff758 	bl	4c50 <fwp_poll_events>
    6ef4:	f9406682 	ldr	x2, [x20, #200]
    6ef8:	b4ffffc2 	cbz	x2, 6ef0 <fwp_block+0xe0>
    6efc:	91014261 	add	x1, x19, #0x50
    6f00:	f9408040 	ldr	x0, [x2, #256]
    6f04:	f9006420 	str	x0, [x1, #200]
    6f08:	b5fff9c0 	cbnz	x0, 6e40 <fwp_block+0x30>
    6f0c:	f900603f 	str	xzr, [x1, #192]
    6f10:	17ffffcc 	b	6e40 <fwp_block+0x30>
    6f14:	f0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    6f18:	91360000 	add	x0, x0, #0xd80
    6f1c:	97ffeec5 	bl	2a30 <getenv@plt>
    6f20:	5284e202 	mov	w2, #0x2710                	// #10000
    6f24:	b4000060 	cbz	x0, 6f30 <fwp_block+0x120>
    6f28:	39400001 	ldrb	w1, [x0]
    6f2c:	350000c1 	cbnz	w1, 6f44 <fwp_block+0x134>
    6f30:	91014273 	add	x19, x19, #0x50
    6f34:	b903c262 	str	w2, [x19, #960]
    6f38:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f3c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6f40:	d65f03c0 	ret
    6f44:	52800142 	mov	w2, #0xa                   	// #10
    6f48:	d2800001 	mov	x1, #0x0                   	// #0
    6f4c:	97ffee09 	bl	2770 <strtoll@plt>
    6f50:	d1000403 	sub	x3, x0, #0x1
    6f54:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6f58:	eb02007f 	cmp	x3, x2
    6f5c:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6f60:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6f64:	17fffff3 	b	6f30 <fwp_block+0x120>
    6f68:	d503201f 	nop
    6f6c:	d503201f 	nop

0000000000006f70 <fwp_drop10>:
    6f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6f74:	910003fd 	mov	x29, sp
    6f78:	a90153f3 	stp	x19, x20, [sp, #16]
    6f7c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    6f80:	f90013f5 	str	x21, [sp, #32]
    6f84:	9118c275 	add	x21, x19, #0x630
    6f88:	f949daa1 	ldr	x1, [x21, #5040]
    6f8c:	f949eea2 	ldr	x2, [x21, #5080]
    6f90:	cb010001 	sub	x1, x0, x1
    6f94:	eb02403f 	cmp	x1, x2, lsl #16
    6f98:	54000382 	b.cs	7008 <fwp_drop10+0x98>  // b.hs, b.nlast
    6f9c:	d350fc22 	lsr	x2, x1, #16
    6fa0:	f949fea3 	ldr	x3, [x21, #5112]
    6fa4:	8b020842 	add	x2, x2, x2, lsl #2
    6fa8:	d37df042 	lsl	x2, x2, #3
    6fac:	8b020064 	add	x4, x3, x2
    6fb0:	f9401094 	ldr	x20, [x4, #32]
    6fb4:	b40002b4 	cbz	x20, 7008 <fwp_drop10+0x98>
    6fb8:	38626862 	ldrb	w2, [x3, x2]
    6fbc:	7100085f 	cmp	w2, #0x2
    6fc0:	540007a0 	b.eq	70b4 <fwp_drop10+0x144>  // b.none
    6fc4:	7100045f 	cmp	w2, #0x1
    6fc8:	54000201 	b.ne	7008 <fwp_drop10+0x98>  // b.any
    6fcc:	29430885 	ldp	w5, w2, [x4, #24]
    6fd0:	92403c21 	and	x1, x1, #0xffff
    6fd4:	9b057c21 	mul	x1, x1, x5
    6fd8:	d360fc21 	lsr	x1, x1, #32
    6fdc:	eb02003f 	cmp	x1, x2
    6fe0:	54000142 	b.cs	7008 <fwp_drop10+0x98>  // b.hs, b.nlast
    6fe4:	8b010294 	add	x20, x20, x1
    6fe8:	39400281 	ldrb	w1, [x20]
    6fec:	340000e1 	cbz	w1, 7008 <fwp_drop10+0x98>
    6ff0:	7100043f 	cmp	w1, #0x1
    6ff4:	54000120 	b.eq	7018 <fwp_drop10+0xa8>  // b.none
    6ff8:	7103fc3f 	cmp	w1, #0xff
    6ffc:	540007c0 	b.eq	70f4 <fwp_drop10+0x184>  // b.none
    7000:	51000421 	sub	w1, w1, #0x1
    7004:	39000281 	strb	w1, [x20]
    7008:	a94153f3 	ldp	x19, x20, [sp, #16]
    700c:	f94013f5 	ldr	x21, [sp, #32]
    7010:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7014:	d65f03c0 	ret
    7018:	f9400001 	ldr	x1, [x0]
    701c:	b7f80581 	tbnz	x1, #63, 70cc <fwp_drop10+0x15c>
    7020:	9118c273 	add	x19, x19, #0x630
    7024:	f949da61 	ldr	x1, [x19, #5040]
    7028:	f949ee62 	ldr	x2, [x19, #5080]
    702c:	cb010001 	sub	x1, x0, x1
    7030:	eb02403f 	cmp	x1, x2, lsl #16
    7034:	54fffea2 	b.cs	7008 <fwp_drop10+0x98>  // b.hs, b.nlast
    7038:	d350fc22 	lsr	x2, x1, #16
    703c:	8b020842 	add	x2, x2, x2, lsl #2
    7040:	d37df042 	lsl	x2, x2, #3
    7044:	8b020065 	add	x5, x3, x2
    7048:	f94010a4 	ldr	x4, [x5, #32]
    704c:	b4fffde4 	cbz	x4, 7008 <fwp_drop10+0x98>
    7050:	38626862 	ldrb	w2, [x3, x2]
    7054:	7100085f 	cmp	w2, #0x2
    7058:	54000220 	b.eq	709c <fwp_drop10+0x12c>  // b.none
    705c:	7100045f 	cmp	w2, #0x1
    7060:	54fffd41 	b.ne	7008 <fwp_drop10+0x98>  // b.any
    7064:	294308a3 	ldp	w3, w2, [x5, #24]
    7068:	92403c21 	and	x1, x1, #0xffff
    706c:	9b037c21 	mul	x1, x1, x3
    7070:	d360fc21 	lsr	x1, x1, #32
    7074:	eb02003f 	cmp	x1, x2
    7078:	54fffc82 	b.cs	7008 <fwp_drop10+0x98>  // b.hs, b.nlast
    707c:	8b010084 	add	x4, x4, x1
    7080:	39400081 	ldrb	w1, [x4]
    7084:	7100043f 	cmp	w1, #0x1
    7088:	54fffc01 	b.ne	7008 <fwp_drop10+0x98>  // b.any
    708c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7090:	f94013f5 	ldr	x21, [sp, #32]
    7094:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7098:	17fff562 	b	4620 <fwp_mem_free>
    709c:	72003c3f 	tst	w1, #0xffff
    70a0:	54ffff00 	b.eq	7080 <fwp_drop10+0x110>  // b.none
    70a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    70a8:	f94013f5 	ldr	x21, [sp, #32]
    70ac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    70b0:	d65f03c0 	ret
    70b4:	72003c3f 	tst	w1, #0xffff
    70b8:	54fff980 	b.eq	6fe8 <fwp_drop10+0x78>  // b.none
    70bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    70c0:	f94013f5 	ldr	x21, [sp, #32]
    70c4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    70c8:	d65f03c0 	ret
    70cc:	f9400414 	ldr	x20, [x0, #8]
    70d0:	97fffb1c 	bl	5d40 <fwp_rc_free_arr>
    70d4:	9118c260 	add	x0, x19, #0x630
    70d8:	f949d801 	ldr	x1, [x0, #5040]
    70dc:	f949ec00 	ldr	x0, [x0, #5080]
    70e0:	cb010281 	sub	x1, x20, x1
    70e4:	eb00403f 	cmp	x1, x0, lsl #16
    70e8:	54fff902 	b.cs	7008 <fwp_drop10+0x98>  // b.hs, b.nlast
    70ec:	aa1403e0 	mov	x0, x20
    70f0:	17ffffab 	b	6f9c <fwp_drop10+0x2c>
    70f4:	ca544680 	eor	x0, x20, x20, lsr #17
    70f8:	9118c273 	add	x19, x19, #0x630
    70fc:	ca402400 	eor	x0, x0, x0, lsr #9
    7100:	92401c00 	and	x0, x0, #0xff
    7104:	910a2402 	add	x2, x0, #0x289
    7108:	8b000e60 	add	x0, x19, x0, lsl #3
    710c:	8b020e62 	add	x2, x19, x2, lsl #3
    7110:	f94a2400 	ldr	x0, [x0, #5192]
    7114:	b50000a0 	cbnz	x0, 7128 <fwp_drop10+0x1b8>
    7118:	14000013 	b	7164 <fwp_drop10+0x1f4>
    711c:	91004002 	add	x2, x0, #0x10
    7120:	f9400800 	ldr	x0, [x0, #16]
    7124:	b4000200 	cbz	x0, 7164 <fwp_drop10+0x1f4>
    7128:	f9400001 	ldr	x1, [x0]
    712c:	eb14003f 	cmp	x1, x20
    7130:	54ffff61 	b.ne	711c <fwp_drop10+0x1ac>  // b.any
    7134:	f9400041 	ldr	x1, [x2]
    7138:	f9400420 	ldr	x0, [x1, #8]
    713c:	d1000400 	sub	x0, x0, #0x1
    7140:	f9000420 	str	x0, [x1, #8]
    7144:	f103f81f 	cmp	x0, #0xfe
    7148:	54fff601 	b.ne	7008 <fwp_drop10+0x98>  // b.any
    714c:	39400280 	ldrb	w0, [x20]
    7150:	7103fc1f 	cmp	w0, #0xff
    7154:	540000e0 	b.eq	7170 <fwp_drop10+0x200>  // b.none
    7158:	12800020 	mov	w0, #0xfffffffe            	// #-2
    715c:	39000280 	strb	w0, [x20]
    7160:	17ffffaa 	b	7008 <fwp_drop10+0x98>
    7164:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    7168:	912ba000 	add	x0, x0, #0xae8
    716c:	97fff472 	bl	4334 <fwp_trap>
    7170:	aa1403e0 	mov	x0, x20
    7174:	97fff490 	bl	43b4 <fwp_rc_forget_slot.part.0>
    7178:	17fffff8 	b	7158 <fwp_drop10+0x1e8>
    717c:	d503201f 	nop

0000000000007180 <fwp_caps173>:
    7180:	34000041 	cbz	w1, 7188 <fwp_caps173+0x8>
    7184:	d65f03c0 	ret
    7188:	d0000383 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    718c:	9118c063 	add	x3, x3, #0x630
    7190:	f949d861 	ldr	x1, [x3, #5040]
    7194:	f949ec62 	ldr	x2, [x3, #5080]
    7198:	cb010001 	sub	x1, x0, x1
    719c:	eb02403f 	cmp	x1, x2, lsl #16
    71a0:	54ffff22 	b.cs	7184 <fwp_caps173+0x4>  // b.hs, b.nlast
    71a4:	d350fc22 	lsr	x2, x1, #16
    71a8:	f949fc65 	ldr	x5, [x3, #5112]
    71ac:	8b020842 	add	x2, x2, x2, lsl #2
    71b0:	d37df042 	lsl	x2, x2, #3
    71b4:	8b0200a4 	add	x4, x5, x2
    71b8:	f9401083 	ldr	x3, [x4, #32]
    71bc:	b4fffe43 	cbz	x3, 7184 <fwp_caps173+0x4>
    71c0:	386268a2 	ldrb	w2, [x5, x2]
    71c4:	7100085f 	cmp	w2, #0x2
    71c8:	540001c0 	b.eq	7200 <fwp_caps173+0x80>  // b.none
    71cc:	7100045f 	cmp	w2, #0x1
    71d0:	54fffda1 	b.ne	7184 <fwp_caps173+0x4>  // b.any
    71d4:	29430885 	ldp	w5, w2, [x4, #24]
    71d8:	92403c21 	and	x1, x1, #0xffff
    71dc:	9b057c21 	mul	x1, x1, x5
    71e0:	d360fc21 	lsr	x1, x1, #32
    71e4:	eb02003f 	cmp	x1, x2
    71e8:	54fffce2 	b.cs	7184 <fwp_caps173+0x4>  // b.hs, b.nlast
    71ec:	8b010063 	add	x3, x3, x1
    71f0:	39400061 	ldrb	w1, [x3]
    71f4:	7100043f 	cmp	w1, #0x1
    71f8:	54fffc61 	b.ne	7184 <fwp_caps173+0x4>  // b.any
    71fc:	17fff509 	b	4620 <fwp_mem_free>
    7200:	72003c3f 	tst	w1, #0xffff
    7204:	54ffff60 	b.eq	71f0 <fwp_caps173+0x70>  // b.none
    7208:	d65f03c0 	ret
    720c:	d503201f 	nop

0000000000007210 <fwp_args37>:
    7210:	7100003f 	cmp	w1, #0x0
    7214:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    7218:	54000041 	b.ne	7220 <fwp_args37+0x10>  // b.any
    721c:	d65f03c0 	ret
    7220:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    7224:	9118c042 	add	x2, x2, #0x630
    7228:	f9400001 	ldr	x1, [x0]
    722c:	f949d843 	ldr	x3, [x2, #5040]
    7230:	f949ec40 	ldr	x0, [x2, #5080]
    7234:	cb030021 	sub	x1, x1, x3
    7238:	eb00403f 	cmp	x1, x0, lsl #16
    723c:	54ffff02 	b.cs	721c <fwp_args37+0xc>  // b.hs, b.nlast
    7240:	d350fc20 	lsr	x0, x1, #16
    7244:	f949fc44 	ldr	x4, [x2, #5112]
    7248:	8b000800 	add	x0, x0, x0, lsl #2
    724c:	d37df002 	lsl	x2, x0, #3
    7250:	8b020083 	add	x3, x4, x2
    7254:	f9401060 	ldr	x0, [x3, #32]
    7258:	b4fffe20 	cbz	x0, 721c <fwp_args37+0xc>
    725c:	38626882 	ldrb	w2, [x4, x2]
    7260:	7100085f 	cmp	w2, #0x2
    7264:	54000320 	b.eq	72c8 <fwp_args37+0xb8>  // b.none
    7268:	7100045f 	cmp	w2, #0x1
    726c:	54fffd81 	b.ne	721c <fwp_args37+0xc>  // b.any
    7270:	29430864 	ldp	w4, w2, [x3, #24]
    7274:	92403c21 	and	x1, x1, #0xffff
    7278:	9b047c21 	mul	x1, x1, x4
    727c:	d360fc21 	lsr	x1, x1, #32
    7280:	eb02003f 	cmp	x1, x2
    7284:	54fffcc2 	b.cs	721c <fwp_args37+0xc>  // b.hs, b.nlast
    7288:	8b010000 	add	x0, x0, x1
    728c:	39400001 	ldrb	w1, [x0]
    7290:	34fffc61 	cbz	w1, 721c <fwp_args37+0xc>
    7294:	b00000c2 	adrp	x2, 20000 <__data_start>
    7298:	91014042 	add	x2, x2, #0x50
    729c:	b9413043 	ldr	w3, [x2, #304]
    72a0:	350000c3 	cbnz	w3, 72b8 <fwp_args37+0xa8>
    72a4:	7103f43f 	cmp	w1, #0xfd
    72a8:	54000168 	b.hi	72d4 <fwp_args37+0xc4>  // b.pmore
    72ac:	11000421 	add	w1, w1, #0x1
    72b0:	39000001 	strb	w1, [x0]
    72b4:	d65f03c0 	ret
    72b8:	f940ac43 	ldr	x3, [x2, #344]
    72bc:	91000463 	add	x3, x3, #0x1
    72c0:	f900ac43 	str	x3, [x2, #344]
    72c4:	17fffff8 	b	72a4 <fwp_args37+0x94>
    72c8:	72003c3f 	tst	w1, #0xffff
    72cc:	54fffe00 	b.eq	728c <fwp_args37+0x7c>  // b.none
    72d0:	d65f03c0 	ret
    72d4:	17fff54c 	b	4804 <fwp_rc_wide_dup>
    72d8:	d503201f 	nop
    72dc:	d503201f 	nop

00000000000072e0 <fwp_caps37>:
    72e0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    72e4:	910003fd 	mov	x29, sp
    72e8:	f9000bf3 	str	x19, [sp, #16]
    72ec:	aa0003f3 	mov	x19, x0
    72f0:	b9400400 	ldr	w0, [x0, #4]
    72f4:	340004a0 	cbz	w0, 7388 <fwp_caps37+0xa8>
    72f8:	f9400660 	ldr	x0, [x19, #8]
    72fc:	350004e1 	cbnz	w1, 7398 <fwp_caps37+0xb8>
    7300:	97fffd60 	bl	6880 <fwp_drop4>
    7304:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    7308:	9118c042 	add	x2, x2, #0x630
    730c:	f949d840 	ldr	x0, [x2, #5040]
    7310:	f949ec41 	ldr	x1, [x2, #5080]
    7314:	cb000260 	sub	x0, x19, x0
    7318:	eb01401f 	cmp	x0, x1, lsl #16
    731c:	54000382 	b.cs	738c <fwp_caps37+0xac>  // b.hs, b.nlast
    7320:	d350fc01 	lsr	x1, x0, #16
    7324:	f949fc44 	ldr	x4, [x2, #5112]
    7328:	8b010821 	add	x1, x1, x1, lsl #2
    732c:	d37df021 	lsl	x1, x1, #3
    7330:	8b010083 	add	x3, x4, x1
    7334:	f9401062 	ldr	x2, [x3, #32]
    7338:	b40002a2 	cbz	x2, 738c <fwp_caps37+0xac>
    733c:	38616881 	ldrb	w1, [x4, x1]
    7340:	7100083f 	cmp	w1, #0x2
    7344:	54000740 	b.eq	742c <fwp_caps37+0x14c>  // b.none
    7348:	7100043f 	cmp	w1, #0x1
    734c:	54000201 	b.ne	738c <fwp_caps37+0xac>  // b.any
    7350:	29430464 	ldp	w4, w1, [x3, #24]
    7354:	92403c00 	and	x0, x0, #0xffff
    7358:	9b047c00 	mul	x0, x0, x4
    735c:	d360fc00 	lsr	x0, x0, #32
    7360:	eb01001f 	cmp	x0, x1
    7364:	54000142 	b.cs	738c <fwp_caps37+0xac>  // b.hs, b.nlast
    7368:	8b000042 	add	x2, x2, x0
    736c:	39400040 	ldrb	w0, [x2]
    7370:	7100041f 	cmp	w0, #0x1
    7374:	540000c1 	b.ne	738c <fwp_caps37+0xac>  // b.any
    7378:	aa1303e0 	mov	x0, x19
    737c:	f9400bf3 	ldr	x19, [sp, #16]
    7380:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7384:	17fff4a7 	b	4620 <fwp_mem_free>
    7388:	34fffbe1 	cbz	w1, 7304 <fwp_caps37+0x24>
    738c:	f9400bf3 	ldr	x19, [sp, #16]
    7390:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7394:	d65f03c0 	ret
    7398:	d0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    739c:	9118c042 	add	x2, x2, #0x630
    73a0:	f949d843 	ldr	x3, [x2, #5040]
    73a4:	f949ec41 	ldr	x1, [x2, #5080]
    73a8:	cb030000 	sub	x0, x0, x3
    73ac:	eb01401f 	cmp	x0, x1, lsl #16
    73b0:	54fffee2 	b.cs	738c <fwp_caps37+0xac>  // b.hs, b.nlast
    73b4:	d350fc01 	lsr	x1, x0, #16
    73b8:	f949fc44 	ldr	x4, [x2, #5112]
    73bc:	8b010821 	add	x1, x1, x1, lsl #2
    73c0:	d37df021 	lsl	x1, x1, #3
    73c4:	8b010083 	add	x3, x4, x1
    73c8:	f9401062 	ldr	x2, [x3, #32]
    73cc:	b4fffe02 	cbz	x2, 738c <fwp_caps37+0xac>
    73d0:	38616881 	ldrb	w1, [x4, x1]
    73d4:	7100083f 	cmp	w1, #0x2
    73d8:	54000300 	b.eq	7438 <fwp_caps37+0x158>  // b.none
    73dc:	7100043f 	cmp	w1, #0x1
    73e0:	54fffd61 	b.ne	738c <fwp_caps37+0xac>  // b.any
    73e4:	92403c01 	and	x1, x0, #0xffff
    73e8:	29430064 	ldp	w4, w0, [x3, #24]
    73ec:	9b047c21 	mul	x1, x1, x4
    73f0:	d360fc21 	lsr	x1, x1, #32
    73f4:	eb00003f 	cmp	x1, x0
    73f8:	54fffca2 	b.cs	738c <fwp_caps37+0xac>  // b.hs, b.nlast
    73fc:	8b010042 	add	x2, x2, x1
    7400:	39400040 	ldrb	w0, [x2]
    7404:	34fffc40 	cbz	w0, 738c <fwp_caps37+0xac>
    7408:	b00000c1 	adrp	x1, 20000 <__data_start>
    740c:	91014021 	add	x1, x1, #0x50
    7410:	b9413023 	ldr	w3, [x1, #304]
    7414:	35000183 	cbnz	w3, 7444 <fwp_caps37+0x164>
    7418:	7103f41f 	cmp	w0, #0xfd
    741c:	540001c8 	b.hi	7454 <fwp_caps37+0x174>  // b.pmore
    7420:	11000400 	add	w0, w0, #0x1
    7424:	39000040 	strb	w0, [x2]
    7428:	17ffffd9 	b	738c <fwp_caps37+0xac>
    742c:	72003c1f 	tst	w0, #0xffff
    7430:	54fffae1 	b.ne	738c <fwp_caps37+0xac>  // b.any
    7434:	17ffffce 	b	736c <fwp_caps37+0x8c>
    7438:	72003c1f 	tst	w0, #0xffff
    743c:	54fffa81 	b.ne	738c <fwp_caps37+0xac>  // b.any
    7440:	17fffff0 	b	7400 <fwp_caps37+0x120>
    7444:	f940ac23 	ldr	x3, [x1, #344]
    7448:	91000463 	add	x3, x3, #0x1
    744c:	f900ac23 	str	x3, [x1, #344]
    7450:	17fffff2 	b	7418 <fwp_caps37+0x138>
    7454:	f9400bf3 	ldr	x19, [sp, #16]
    7458:	aa0203e0 	mov	x0, x2
    745c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7460:	17fff4e9 	b	4804 <fwp_rc_wide_dup>

0000000000007464 <f37>:
    7464:	d10203ff 	sub	sp, sp, #0x80
    7468:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc90>
    746c:	f947f421 	ldr	x1, [x1, #4072]
    7470:	a9027bfd 	stp	x29, x30, [sp, #32]
    7474:	910083fd 	add	x29, sp, #0x20
    7478:	a9045bf5 	stp	x21, x22, [sp, #64]
    747c:	d0000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    7480:	9118c2a3 	add	x3, x21, #0x630
    7484:	a90353f3 	stp	x19, x20, [sp, #48]
    7488:	aa0003f6 	mov	x22, x0
    748c:	a90563f7 	stp	x23, x24, [sp, #80]
    7490:	a9066bf9 	stp	x25, x26, [sp, #96]
    7494:	f949ec62 	ldr	x2, [x3, #5080]
    7498:	f9400024 	ldr	x4, [x1]
    749c:	f9000fe4 	str	x4, [sp, #24]
    74a0:	d2800004 	mov	x4, #0x0                   	// #0
    74a4:	f949d861 	ldr	x1, [x3, #5040]
    74a8:	d370bc42 	lsl	x2, x2, #16
    74ac:	b4001900 	cbz	x0, 77cc <f37+0x368>
    74b0:	f9400817 	ldr	x23, [x0, #16]
    74b4:	cb0102e1 	sub	x1, x23, x1
    74b8:	eb02003f 	cmp	x1, x2
    74bc:	540003e2 	b.cs	7538 <f37+0xd4>  // b.hs, b.nlast
    74c0:	f949fc60 	ldr	x0, [x3, #5112]
    74c4:	d350fc22 	lsr	x2, x1, #16
    74c8:	8b020842 	add	x2, x2, x2, lsl #2
    74cc:	8b020c02 	add	x2, x0, x2, lsl #3
    74d0:	f9401040 	ldr	x0, [x2, #32]
    74d4:	b4000320 	cbz	x0, 7538 <f37+0xd4>
    74d8:	39400043 	ldrb	w3, [x2]
    74dc:	7100087f 	cmp	w3, #0x2
    74e0:	540015c0 	b.eq	7798 <f37+0x334>  // b.none
    74e4:	7100047f 	cmp	w3, #0x1
    74e8:	54000241 	b.ne	7530 <f37+0xcc>  // b.any
    74ec:	29430843 	ldp	w3, w2, [x2, #24]
    74f0:	92403c21 	and	x1, x1, #0xffff
    74f4:	9b037c21 	mul	x1, x1, x3
    74f8:	d360fc21 	lsr	x1, x1, #32
    74fc:	eb02003f 	cmp	x1, x2
    7500:	54000182 	b.cs	7530 <f37+0xcc>  // b.hs, b.nlast
    7504:	8b010000 	add	x0, x0, x1
    7508:	39400001 	ldrb	w1, [x0]
    750c:	34000121 	cbz	w1, 7530 <f37+0xcc>
    7510:	b00000c2 	adrp	x2, 20000 <__data_start>
    7514:	91014042 	add	x2, x2, #0x50
    7518:	b9413043 	ldr	w3, [x2, #304]
    751c:	35001443 	cbnz	w3, 77a4 <f37+0x340>
    7520:	7103f43f 	cmp	w1, #0xfd
    7524:	54001868 	b.hi	7830 <f37+0x3cc>  // b.pmore
    7528:	11000421 	add	w1, w1, #0x1
    752c:	39000001 	strb	w1, [x0]
    7530:	d2800002 	mov	x2, #0x0                   	// #0
    7534:	b40000d6 	cbz	x22, 754c <f37+0xe8>
    7538:	aa1603e1 	mov	x1, x22
    753c:	d2800002 	mov	x2, #0x0                   	// #0
    7540:	f9400821 	ldr	x1, [x1, #16]
    7544:	91000442 	add	x2, x2, #0x1
    7548:	b5ffffc1 	cbnz	x1, 7540 <f37+0xdc>
    754c:	b4001477 	cbz	x23, 77d8 <f37+0x374>
    7550:	aa1703e1 	mov	x1, x23
    7554:	d2800003 	mov	x3, #0x0                   	// #0
    7558:	f9400821 	ldr	x1, [x1, #16]
    755c:	91000463 	add	x3, x3, #0x1
    7560:	b5ffffc1 	cbnz	x1, 7558 <f37+0xf4>
    7564:	eb02007f 	cmp	x3, x2
    7568:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    756c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7570:	eb00027f 	cmp	x19, x0
    7574:	540010a8 	b.hi	7788 <f37+0x324>  // b.pmore
    7578:	d37ffa74 	lsl	x20, x19, #1
    757c:	52800041 	mov	w1, #0x2                   	// #2
    7580:	91000680 	add	x0, x20, #0x1
    7584:	d37df000 	lsl	x0, x0, #3
    7588:	97fff6e2 	bl	5110 <fwp_heap_alloc>
    758c:	aa0003f8 	mov	x24, x0
    7590:	9118c2a1 	add	x1, x21, #0x630
    7594:	aa0103e0 	mov	x0, x1
    7598:	f9000314 	str	x20, [x24]
    759c:	f949d821 	ldr	x1, [x1, #5040]
    75a0:	f949ec00 	ldr	x0, [x0, #5080]
    75a4:	cb010301 	sub	x1, x24, x1
    75a8:	eb00403f 	cmp	x1, x0, lsl #16
    75ac:	54000342 	b.cs	7614 <f37+0x1b0>  // b.hs, b.nlast
    75b0:	9118c2a2 	add	x2, x21, #0x630
    75b4:	d350fc20 	lsr	x0, x1, #16
    75b8:	8b000800 	add	x0, x0, x0, lsl #2
    75bc:	f949fc43 	ldr	x3, [x2, #5112]
    75c0:	d37df002 	lsl	x2, x0, #3
    75c4:	8b020060 	add	x0, x3, x2
    75c8:	f9401014 	ldr	x20, [x0, #32]
    75cc:	b4000254 	cbz	x20, 7614 <f37+0x1b0>
    75d0:	38626862 	ldrb	w2, [x3, x2]
    75d4:	7100085f 	cmp	w2, #0x2
    75d8:	54000ee0 	b.eq	77b4 <f37+0x350>  // b.none
    75dc:	7100045f 	cmp	w2, #0x1
    75e0:	540001a1 	b.ne	7614 <f37+0x1b0>  // b.any
    75e4:	29430002 	ldp	w2, w0, [x0, #24]
    75e8:	92403c21 	and	x1, x1, #0xffff
    75ec:	9b027c21 	mul	x1, x1, x2
    75f0:	d360fc21 	lsr	x1, x1, #32
    75f4:	eb00003f 	cmp	x1, x0
    75f8:	540000e2 	b.cs	7614 <f37+0x1b0>  // b.hs, b.nlast
    75fc:	8b010294 	add	x20, x20, x1
    7600:	39400280 	ldrb	w0, [x20]
    7604:	7103fc1f 	cmp	w0, #0xff
    7608:	54001180 	b.eq	7838 <f37+0x3d4>  // b.none
    760c:	52800020 	mov	w0, #0x1                   	// #1
    7610:	39000280 	strb	w0, [x20]
    7614:	b4000253 	cbz	x19, 765c <f37+0x1f8>
    7618:	8b131313 	add	x19, x24, x19, lsl #4
    761c:	aa1803f4 	mov	x20, x24
    7620:	aa1603fa 	mov	x26, x22
    7624:	aa1703f9 	mov	x25, x23
    7628:	f9400723 	ldr	x3, [x25, #8]
    762c:	f9400742 	ldr	x2, [x26, #8]
    7630:	f9400861 	ldr	x1, [x3, #16]
    7634:	f9400840 	ldr	x0, [x2, #16]
    7638:	fd400461 	ldr	d1, [x3, #8]
    763c:	fd400440 	ldr	d0, [x2, #8]
    7640:	97fff859 	bl	57a4 <w120>
    7644:	f9000680 	str	x0, [x20, #8]
    7648:	f8010e81 	str	x1, [x20, #16]!
    764c:	f9400b39 	ldr	x25, [x25, #16]
    7650:	f9400b5a 	ldr	x26, [x26, #16]
    7654:	eb14027f 	cmp	x19, x20
    7658:	54fffe81 	b.ne	7628 <f37+0x1c4>  // b.any
    765c:	aa1703e0 	mov	x0, x23
    7660:	97fffc88 	bl	6880 <fwp_drop4>
    7664:	aa1603e0 	mov	x0, x22
    7668:	97fffc86 	bl	6880 <fwp_drop4>
    766c:	f9400316 	ldr	x22, [x24]
    7670:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7674:	b4000236 	cbz	x22, 76b8 <f37+0x254>
    7678:	fd003be8 	str	d8, [sp, #112]
    767c:	2f00e408 	movi	d8, #0x0
    7680:	91002319 	add	x25, x24, #0x8
    7684:	91004317 	add	x23, x24, #0x10
    7688:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    768c:	d2800013 	mov	x19, #0x0                   	// #0
    7690:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7694:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7698:	91000a73 	add	x19, x19, #0x2
    769c:	1e602908 	fadd	d8, d8, d0
    76a0:	97fff7f0 	bl	5660 <f141.constprop.0>
    76a4:	aa0003f4 	mov	x20, x0
    76a8:	eb1302df 	cmp	x22, x19
    76ac:	54ffff28 	b.hi	7690 <f37+0x22c>  // b.pmore
    76b0:	9e660116 	fmov	x22, d8
    76b4:	fd403be8 	ldr	d8, [sp, #112]
    76b8:	9118c2b5 	add	x21, x21, #0x630
    76bc:	aa1803e0 	mov	x0, x24
    76c0:	97fffe2c 	bl	6f70 <fwp_drop10>
    76c4:	a900d3f6 	stp	x22, x20, [sp, #8]
    76c8:	910023e1 	add	x1, sp, #0x8
    76cc:	52800000 	mov	w0, #0x0                   	// #0
    76d0:	97fff6f4 	bl	52a0 <fwp_data.part.0.constprop.0>
    76d4:	f949daa1 	ldr	x1, [x21, #5040]
    76d8:	aa0003f3 	mov	x19, x0
    76dc:	f949eea0 	ldr	x0, [x21, #5080]
    76e0:	cb010261 	sub	x1, x19, x1
    76e4:	eb00403f 	cmp	x1, x0, lsl #16
    76e8:	54000322 	b.cs	774c <f37+0x2e8>  // b.hs, b.nlast
    76ec:	d350fc22 	lsr	x2, x1, #16
    76f0:	f949fea3 	ldr	x3, [x21, #5112]
    76f4:	8b020842 	add	x2, x2, x2, lsl #2
    76f8:	d37df042 	lsl	x2, x2, #3
    76fc:	8b020060 	add	x0, x3, x2
    7700:	f9401014 	ldr	x20, [x0, #32]
    7704:	b4000254 	cbz	x20, 774c <f37+0x2e8>
    7708:	38626862 	ldrb	w2, [x3, x2]
    770c:	7100085f 	cmp	w2, #0x2
    7710:	54000580 	b.eq	77c0 <f37+0x35c>  // b.none
    7714:	7100045f 	cmp	w2, #0x1
    7718:	540001a1 	b.ne	774c <f37+0x2e8>  // b.any
    771c:	29430002 	ldp	w2, w0, [x0, #24]
    7720:	92403c21 	and	x1, x1, #0xffff
    7724:	9b027c21 	mul	x1, x1, x2
    7728:	d360fc21 	lsr	x1, x1, #32
    772c:	eb00003f 	cmp	x1, x0
    7730:	540000e2 	b.cs	774c <f37+0x2e8>  // b.hs, b.nlast
    7734:	8b010294 	add	x20, x20, x1
    7738:	39400280 	ldrb	w0, [x20]
    773c:	7103fc1f 	cmp	w0, #0xff
    7740:	54000820 	b.eq	7844 <f37+0x3e0>  // b.none
    7744:	52800020 	mov	w0, #0x1                   	// #1
    7748:	39000280 	strb	w0, [x20]
    774c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7750:	f947f400 	ldr	x0, [x0, #4072]
    7754:	f9400fe2 	ldr	x2, [sp, #24]
    7758:	f9400001 	ldr	x1, [x0]
    775c:	eb010042 	subs	x2, x2, x1
    7760:	d2800001 	mov	x1, #0x0                   	// #0
    7764:	540007a1 	b.ne	7858 <f37+0x3f4>  // b.any
    7768:	a9427bfd 	ldp	x29, x30, [sp, #32]
    776c:	aa1303e0 	mov	x0, x19
    7770:	a94353f3 	ldp	x19, x20, [sp, #48]
    7774:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7778:	a94563f7 	ldp	x23, x24, [sp, #80]
    777c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7780:	910203ff 	add	sp, sp, #0x80
    7784:	d65f03c0 	ret
    7788:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    778c:	91364000 	add	x0, x0, #0xd90
    7790:	fd003be8 	str	d8, [sp, #112]
    7794:	97fff2e8 	bl	4334 <fwp_trap>
    7798:	72003c3f 	tst	w1, #0xffff
    779c:	54ffeca1 	b.ne	7530 <f37+0xcc>  // b.any
    77a0:	17ffff5a 	b	7508 <f37+0xa4>
    77a4:	f940ac43 	ldr	x3, [x2, #344]
    77a8:	91000463 	add	x3, x3, #0x1
    77ac:	f900ac43 	str	x3, [x2, #344]
    77b0:	17ffff5c 	b	7520 <f37+0xbc>
    77b4:	72003c3f 	tst	w1, #0xffff
    77b8:	54fff2e1 	b.ne	7614 <f37+0x1b0>  // b.any
    77bc:	17ffff91 	b	7600 <f37+0x19c>
    77c0:	72003c3f 	tst	w1, #0xffff
    77c4:	54fffc41 	b.ne	774c <f37+0x2e8>  // b.any
    77c8:	17ffffdc 	b	7738 <f37+0x2d4>
    77cc:	cb0103e1 	neg	x1, x1
    77d0:	eb02003f 	cmp	x1, x2
    77d4:	540001e3 	b.cc	7810 <f37+0x3ac>  // b.lo, b.ul, b.last
    77d8:	52800041 	mov	w1, #0x2                   	// #2
    77dc:	d2800100 	mov	x0, #0x8                   	// #8
    77e0:	97fff64c 	bl	5110 <fwp_heap_alloc>
    77e4:	aa0003f8 	mov	x24, x0
    77e8:	9118c2a0 	add	x0, x21, #0x630
    77ec:	f900031f 	str	xzr, [x24]
    77f0:	f949d801 	ldr	x1, [x0, #5040]
    77f4:	f949ec00 	ldr	x0, [x0, #5080]
    77f8:	cb010301 	sub	x1, x24, x1
    77fc:	eb00403f 	cmp	x1, x0, lsl #16
    7800:	54000282 	b.cs	7850 <f37+0x3ec>  // b.hs, b.nlast
    7804:	d2800013 	mov	x19, #0x0                   	// #0
    7808:	d2800017 	mov	x23, #0x0                   	// #0
    780c:	17ffff69 	b	75b0 <f37+0x14c>
    7810:	f949fc62 	ldr	x2, [x3, #5112]
    7814:	d350fc20 	lsr	x0, x1, #16
    7818:	8b000800 	add	x0, x0, x0, lsl #2
    781c:	8b000c42 	add	x2, x2, x0, lsl #3
    7820:	f9401040 	ldr	x0, [x2, #32]
    7824:	b4fffda0 	cbz	x0, 77d8 <f37+0x374>
    7828:	d2800017 	mov	x23, #0x0                   	// #0
    782c:	17ffff2b 	b	74d8 <f37+0x74>
    7830:	97fff3f5 	bl	4804 <fwp_rc_wide_dup>
    7834:	17ffff3f 	b	7530 <f37+0xcc>
    7838:	aa1403e0 	mov	x0, x20
    783c:	97fff2de 	bl	43b4 <fwp_rc_forget_slot.part.0>
    7840:	17ffff73 	b	760c <f37+0x1a8>
    7844:	aa1403e0 	mov	x0, x20
    7848:	97fff2db 	bl	43b4 <fwp_rc_forget_slot.part.0>
    784c:	17ffffbe 	b	7744 <f37+0x2e0>
    7850:	d2800017 	mov	x23, #0x0                   	// #0
    7854:	17ffff82 	b	765c <f37+0x1f8>
    7858:	fd003be8 	str	d8, [sp, #112]
    785c:	97ffec11 	bl	28a0 <__stack_chk_fail@plt>

0000000000007860 <fwp_owned_entry37>:
    7860:	f9400000 	ldr	x0, [x0]
    7864:	17ffff00 	b	7464 <f37>
    7868:	d503201f 	nop
    786c:	d503201f 	nop

0000000000007870 <e37>:
    7870:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7874:	910003fd 	mov	x29, sp
    7878:	f9000bf3 	str	x19, [sp, #16]
    787c:	f9400013 	ldr	x19, [x0]
    7880:	aa1303e0 	mov	x0, x19
    7884:	97fff8db 	bl	5bf0 <fwp_rc_share>
    7888:	aa1303e0 	mov	x0, x19
    788c:	97fffef6 	bl	7464 <f37>
    7890:	aa0003f3 	mov	x19, x0
    7894:	97fff8d7 	bl	5bf0 <fwp_rc_share>
    7898:	aa1303e0 	mov	x0, x19
    789c:	f9400bf3 	ldr	x19, [sp, #16]
    78a0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    78a4:	d65f03c0 	ret
    78a8:	d503201f 	nop
    78ac:	d503201f 	nop

00000000000078b0 <fwp_write>:
    78b0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    78b4:	910003fd 	mov	x29, sp
    78b8:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc90>
    78bc:	f947f484 	ldr	x4, [x4, #4072]
    78c0:	a90153f3 	stp	x19, x20, [sp, #16]
    78c4:	d10943ff 	sub	sp, sp, #0x250
    78c8:	b9400045 	ldr	w5, [x2]
    78cc:	aa0003f4 	mov	x20, x0
    78d0:	f9400080 	ldr	x0, [x4]
    78d4:	f90127e0 	str	x0, [sp, #584]
    78d8:	d2800000 	mov	x0, #0x0                   	// #0
    78dc:	710064bf 	cmp	w5, #0x19
    78e0:	54000408 	b.hi	7960 <fwp_write+0xb0>  // b.pmore
    78e4:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0x870>
    78e8:	aa0103f3 	mov	x19, x1
    78ec:	911b8000 	add	x0, x0, #0x6e0
    78f0:	f9013bf5 	str	x21, [sp, #624]
    78f4:	f9013ff6 	str	x22, [sp, #632]
    78f8:	f90153fb 	str	x27, [sp, #672]
    78fc:	f90157fc 	str	x28, [sp, #680]
    7900:	aa0203fc 	mov	x28, x2
    7904:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    7908:	10000061 	adr	x1, 7914 <fwp_write+0x64>
    790c:	8b20a820 	add	x0, x1, w0, sxth #2
    7910:	d61f0000 	br	x0
    7914:	910123e0 	add	x0, sp, #0x48
    7918:	aa1303e5 	mov	x5, x19
    791c:	d0000024 	adrp	x4, d000 <fwp_main_thread+0x520>
    7920:	aa0003f3 	mov	x19, x0
    7924:	91376084 	add	x4, x4, #0xdd8
    7928:	d2804003 	mov	x3, #0x200                 	// #512
    792c:	aa0303e1 	mov	x1, x3
    7930:	52800042 	mov	w2, #0x2                   	// #2
    7934:	97ffebb7 	bl	2810 <__snprintf_chk@plt>
    7938:	aa1303e0 	mov	x0, x19
    793c:	97ffeb7d 	bl	2730 <strlen@plt>
    7940:	aa1303e1 	mov	x1, x19
    7944:	aa0003e2 	mov	x2, x0
    7948:	aa1403e0 	mov	x0, x20
    794c:	97ffef51 	bl	3690 <buf_put>
    7950:	f9413bf5 	ldr	x21, [sp, #624]
    7954:	f9413ff6 	ldr	x22, [sp, #632]
    7958:	f94153fb 	ldr	x27, [sp, #672]
    795c:	f94157fc 	ldr	x28, [sp, #680]
    7960:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7964:	f947f400 	ldr	x0, [x0, #4072]
    7968:	f94127e2 	ldr	x2, [sp, #584]
    796c:	f9400001 	ldr	x1, [x0]
    7970:	eb010042 	subs	x2, x2, x1
    7974:	d2800001 	mov	x1, #0x0                   	// #0
    7978:	540077c1 	b.ne	8870 <fwp_write+0xfc0>  // b.any
    797c:	910943ff 	add	sp, sp, #0x250
    7980:	a94153f3 	ldp	x19, x20, [sp, #16]
    7984:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7988:	d65f03c0 	ret
    798c:	910123e0 	add	x0, sp, #0x48
    7990:	aa1303e5 	mov	x5, x19
    7994:	d0000024 	adrp	x4, d000 <fwp_main_thread+0x520>
    7998:	aa0003f3 	mov	x19, x0
    799c:	91374084 	add	x4, x4, #0xdd0
    79a0:	d2804003 	mov	x3, #0x200                 	// #512
    79a4:	17ffffe2 	b	792c <fwp_write+0x7c>
    79a8:	71004cbf 	cmp	w5, #0x13
    79ac:	d0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    79b0:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    79b4:	91370000 	add	x0, x0, #0xdc0
    79b8:	91372021 	add	x1, x1, #0xdc8
    79bc:	d2800082 	mov	x2, #0x4                   	// #4
    79c0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    79c4:	aa1403e0 	mov	x0, x20
    79c8:	f90143f7 	str	x23, [sp, #640]
    79cc:	d2800016 	mov	x22, #0x0                   	// #0
    79d0:	f90147f8 	str	x24, [sp, #648]
    79d4:	97ffef2f 	bl	3690 <buf_put>
    79d8:	f9400260 	ldr	x0, [x19]
    79dc:	d0000037 	adrp	x23, d000 <fwp_main_thread+0x520>
    79e0:	d2800015 	mov	x21, #0x0                   	// #0
    79e4:	913922f7 	add	x23, x23, #0xe48
    79e8:	b40047a0 	cbz	x0, 82dc <fwp_write+0xa2c>
    79ec:	b9400380 	ldr	w0, [x28]
    79f0:	52800003 	mov	w3, #0x0                   	// #0
    79f4:	f9401f82 	ldr	x2, [x28, #56]
    79f8:	71004c1f 	cmp	w0, #0x13
    79fc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7a00:	aa1403e0 	mov	x0, x20
    7a04:	8b010e61 	add	x1, x19, x1, lsl #3
    7a08:	f9400421 	ldr	x1, [x1, #8]
    7a0c:	97ffffa9 	bl	78b0 <fwp_write>
    7a10:	b9400380 	ldr	w0, [x28]
    7a14:	7100481f 	cmp	w0, #0x12
    7a18:	54004b40 	b.eq	8380 <fwp_write+0xad0>  // b.none
    7a1c:	f9400260 	ldr	x0, [x19]
    7a20:	910006b5 	add	x21, x21, #0x1
    7a24:	91000ad6 	add	x22, x22, #0x2
    7a28:	eb15001f 	cmp	x0, x21
    7a2c:	54004589 	b.ls	82dc <fwp_write+0xa2c>  // b.plast
    7a30:	aa1703e1 	mov	x1, x23
    7a34:	aa1403e0 	mov	x0, x20
    7a38:	d2800042 	mov	x2, #0x2                   	// #2
    7a3c:	97ffef15 	bl	3690 <buf_put>
    7a40:	17ffffeb 	b	79ec <fwp_write+0x13c>
    7a44:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    7a48:	91380021 	add	x1, x1, #0xe00
    7a4c:	d28000c2 	mov	x2, #0x6                   	// #6
    7a50:	aa1403e0 	mov	x0, x20
    7a54:	91004273 	add	x19, x19, #0x10
    7a58:	97ffef0e 	bl	3690 <buf_put>
    7a5c:	aa1303e0 	mov	x0, x19
    7a60:	97ffeb34 	bl	2730 <strlen@plt>
    7a64:	aa1303e1 	mov	x1, x19
    7a68:	aa0003e2 	mov	x2, x0
    7a6c:	aa1403e0 	mov	x0, x20
    7a70:	97ffef08 	bl	3690 <buf_put>
    7a74:	528007c3 	mov	w3, #0x3e                  	// #62
    7a78:	aa1403e0 	mov	x0, x20
    7a7c:	91001fe1 	add	x1, sp, #0x7
    7a80:	d2800022 	mov	x2, #0x1                   	// #1
    7a84:	39001fe3 	strb	w3, [sp, #7]
    7a88:	17ffffb1 	b	794c <fwp_write+0x9c>
    7a8c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7a90:	f947f400 	ldr	x0, [x0, #4072]
    7a94:	f94127e2 	ldr	x2, [sp, #584]
    7a98:	f9400001 	ldr	x1, [x0]
    7a9c:	eb010042 	subs	x2, x2, x1
    7aa0:	d2800001 	mov	x1, #0x0                   	// #0
    7aa4:	540034e1 	b.ne	8140 <fwp_write+0x890>  // b.any
    7aa8:	f9413bf5 	ldr	x21, [sp, #624]
    7aac:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    7ab0:	f9413ff6 	ldr	x22, [sp, #632]
    7ab4:	aa1403e0 	mov	x0, x20
    7ab8:	91378021 	add	x1, x1, #0xde0
    7abc:	d2800142 	mov	x2, #0xa                   	// #10
    7ac0:	f94153fb 	ldr	x27, [sp, #672]
    7ac4:	f94157fc 	ldr	x28, [sp, #680]
    7ac8:	910943ff 	add	sp, sp, #0x250
    7acc:	a94153f3 	ldp	x19, x20, [sp, #16]
    7ad0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7ad4:	17ffeeef 	b	3690 <buf_put>
    7ad8:	f9400456 	ldr	x22, [x2, #8]
    7adc:	f90143f7 	str	x23, [sp, #640]
    7ae0:	f90147f8 	str	x24, [sp, #648]
    7ae4:	b4005b16 	cbz	x22, 8644 <fwp_write+0xd94>
    7ae8:	aa1603e0 	mov	x0, x22
    7aec:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    7af0:	91398021 	add	x1, x1, #0xe60
    7af4:	97ffeb8b 	bl	2920 <strcmp@plt>
    7af8:	2a0003f5 	mov	w21, w0
    7afc:	34005fe0 	cbz	w0, 86f8 <fwp_write+0xe48>
    7b00:	aa1603e0 	mov	x0, x22
    7b04:	97ffeb0b 	bl	2730 <strlen@plt>
    7b08:	aa1603e1 	mov	x1, x22
    7b0c:	aa0003e2 	mov	x2, x0
    7b10:	aa1403e0 	mov	x0, x20
    7b14:	97ffeedf 	bl	3690 <buf_put>
    7b18:	52800403 	mov	w3, #0x20                  	// #32
    7b1c:	91001ff5 	add	x21, sp, #0x7
    7b20:	aa1503e1 	mov	x1, x21
    7b24:	aa1403e0 	mov	x0, x20
    7b28:	d2800022 	mov	x2, #0x1                   	// #1
    7b2c:	39001fe3 	strb	w3, [sp, #7]
    7b30:	97ffeed8 	bl	3690 <buf_put>
    7b34:	52800f63 	mov	w3, #0x7b                  	// #123
    7b38:	aa1403e0 	mov	x0, x20
    7b3c:	aa1503e1 	mov	x1, x21
    7b40:	d2800022 	mov	x2, #0x1                   	// #1
    7b44:	39001fe3 	strb	w3, [sp, #7]
    7b48:	97ffeed2 	bl	3690 <buf_put>
    7b4c:	b9401380 	ldr	w0, [x28, #16]
    7b50:	52800018 	mov	w24, #0x0                   	// #0
    7b54:	7100001f 	cmp	w0, #0x0
    7b58:	54003aad 	b.le	82ac <fwp_write+0x9fc>
    7b5c:	f9014bf9 	str	x25, [sp, #656]
    7b60:	d0000039 	adrp	x25, d000 <fwp_main_thread+0x520>
    7b64:	913a2339 	add	x25, x25, #0xe88
    7b68:	f9014ffa 	str	x26, [sp, #664]
    7b6c:	d000003a 	adrp	x26, d000 <fwp_main_thread+0x520>
    7b70:	9139235a 	add	x26, x26, #0xe48
    7b74:	91002276 	add	x22, x19, #0x8
    7b78:	d2800013 	mov	x19, #0x0                   	// #0
    7b7c:	b5003e93 	cbnz	x19, 834c <fwp_write+0xa9c>
    7b80:	d37df277 	lsl	x23, x19, #3
    7b84:	34003cb8 	cbz	w24, 8318 <fwp_write+0xa68>
    7b88:	f9401382 	ldr	x2, [x28, #32]
    7b8c:	aa1403e0 	mov	x0, x20
    7b90:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7b94:	52800003 	mov	w3, #0x0                   	// #0
    7b98:	f8776842 	ldr	x2, [x2, x23]
    7b9c:	91000673 	add	x19, x19, #0x1
    7ba0:	97ffff44 	bl	78b0 <fwp_write>
    7ba4:	b9401380 	ldr	w0, [x28, #16]
    7ba8:	6b13001f 	cmp	w0, w19
    7bac:	54fffe8c 	b.gt	7b7c <fwp_write+0x2cc>
    7bb0:	f9414bf9 	ldr	x25, [sp, #656]
    7bb4:	f9414ffa 	ldr	x26, [sp, #664]
    7bb8:	340037b8 	cbz	w24, 82ac <fwp_write+0x9fc>
    7bbc:	52800523 	mov	w3, #0x29                  	// #41
    7bc0:	aa1503e1 	mov	x1, x21
    7bc4:	aa1403e0 	mov	x0, x20
    7bc8:	d2800022 	mov	x2, #0x1                   	// #1
    7bcc:	39001fe3 	strb	w3, [sp, #7]
    7bd0:	97ffeeb0 	bl	3690 <buf_put>
    7bd4:	f9413bf5 	ldr	x21, [sp, #624]
    7bd8:	f9413ff6 	ldr	x22, [sp, #632]
    7bdc:	f94143f7 	ldr	x23, [sp, #640]
    7be0:	f94147f8 	ldr	x24, [sp, #648]
    7be4:	f94153fb 	ldr	x27, [sp, #672]
    7be8:	f94157fc 	ldr	x28, [sp, #680]
    7bec:	17ffff5d 	b	7960 <fwp_write+0xb0>
    7bf0:	b9404855 	ldr	w21, [x2, #72]
    7bf4:	aa1403e0 	mov	x0, x20
    7bf8:	93407eb6 	sxtw	x22, w21
    7bfc:	91000ac1 	add	x1, x22, #0x2
    7c00:	97ffee70 	bl	35c0 <buf_grow>
    7c04:	a9400281 	ldp	x1, x0, [x20]
    7c08:	528e8603 	mov	w3, #0x7430                	// #29744
    7c0c:	78206823 	strh	w3, [x1, x0]
    7c10:	8b000022 	add	x2, x1, x0
    7c14:	710002bf 	cmp	w21, #0x0
    7c18:	540036cd 	b.le	82f0 <fwp_write+0xa40>
    7c1c:	110006a3 	add	w3, w21, #0x1
    7c20:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7c24:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7c28:	91000449 	add	x9, x2, #0x1
    7c2c:	8b23c043 	add	x3, x2, w3, sxtw
    7c30:	f28aaac6 	movk	x6, #0x5556
    7c34:	f2955568 	movk	x8, #0xaaab
    7c38:	1400000d 	b	7c6c <fwp_write+0x3bc>
    7c3c:	d2800021 	mov	x1, #0x1                   	// #1
    7c40:	528005a5 	mov	w5, #0x2d                  	// #45
    7c44:	f100001f 	cmp	x0, #0x0
    7c48:	9b467e60 	smulh	x0, x19, x6
    7c4c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7c50:	381ff465 	strb	w5, [x3], #-1
    7c54:	cb040000 	sub	x0, x0, x4
    7c58:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7c5c:	cb020000 	sub	x0, x0, x2
    7c60:	8b010013 	add	x19, x0, x1
    7c64:	eb03013f 	cmp	x9, x3
    7c68:	54003440 	b.eq	82f0 <fwp_write+0xa40>  // b.none
    7c6c:	9b467e60 	smulh	x0, x19, x6
    7c70:	937ffe64 	asr	x4, x19, #63
    7c74:	52800605 	mov	w5, #0x30                  	// #48
    7c78:	cb040000 	sub	x0, x0, x4
    7c7c:	8b000400 	add	x0, x0, x0, lsl #1
    7c80:	cb000260 	sub	x0, x19, x0
    7c84:	91000c01 	add	x1, x0, #0x3
    7c88:	9bc87c22 	umulh	x2, x1, x8
    7c8c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7c90:	8b4204e2 	add	x2, x7, x2, lsr #1
    7c94:	eb020021 	subs	x1, x1, x2
    7c98:	54fffd60 	b.eq	7c44 <fwp_write+0x394>  // b.none
    7c9c:	f100043f 	cmp	x1, #0x1
    7ca0:	54fffce1 	b.ne	7c3c <fwp_write+0x38c>  // b.any
    7ca4:	d2800001 	mov	x1, #0x0                   	// #0
    7ca8:	52800565 	mov	w5, #0x2b                  	// #43
    7cac:	17ffffe6 	b	7c44 <fwp_write+0x394>
    7cb0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7cb4:	f947f400 	ldr	x0, [x0, #4072]
    7cb8:	f94127e2 	ldr	x2, [sp, #584]
    7cbc:	f9400001 	ldr	x1, [x0]
    7cc0:	eb010042 	subs	x2, x2, x1
    7cc4:	d2800001 	mov	x1, #0x0                   	// #0
    7cc8:	540023c1 	b.ne	8140 <fwp_write+0x890>  // b.any
    7ccc:	f9413bf5 	ldr	x21, [sp, #624]
    7cd0:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    7cd4:	f9413ff6 	ldr	x22, [sp, #632]
    7cd8:	aa1403e0 	mov	x0, x20
    7cdc:	9137c021 	add	x1, x1, #0xdf0
    7ce0:	d2800102 	mov	x2, #0x8                   	// #8
    7ce4:	17ffff77 	b	7ac0 <fwp_write+0x210>
    7ce8:	aa1403e0 	mov	x0, x20
    7cec:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    7cf0:	d28000c2 	mov	x2, #0x6                   	// #6
    7cf4:	91394021 	add	x1, x1, #0xe50
    7cf8:	97ffee66 	bl	3690 <buf_put>
    7cfc:	d2800015 	mov	x21, #0x0                   	// #0
    7d00:	f9400263 	ldr	x3, [x19]
    7d04:	f240f87f 	tst	x3, #0x7fffffffffffffff
    7d08:	54002c60 	b.eq	8294 <fwp_write+0x9e4>  // b.none
    7d0c:	f9401f82 	ldr	x2, [x28, #56]
    7d10:	f90143f7 	str	x23, [sp, #640]
    7d14:	f90147f8 	str	x24, [sp, #648]
    7d18:	d2800857 	mov	x23, #0x42                  	// #66
    7d1c:	f9014bf9 	str	x25, [sp, #656]
    7d20:	d0000036 	adrp	x22, d000 <fwp_main_thread+0x520>
    7d24:	f9014ffa 	str	x26, [sp, #664]
    7d28:	913922d6 	add	x22, x22, #0xe48
    7d2c:	d2800038 	mov	x24, #0x1                   	// #1
    7d30:	f2a18017 	movk	x23, #0xc00, lsl #16
    7d34:	d2809099 	mov	x25, #0x484                 	// #1156
    7d38:	b40004a2 	cbz	x2, 7dcc <fwp_write+0x51c>
    7d3c:	b9400040 	ldr	w0, [x2]
    7d40:	7100701f 	cmp	w0, #0x1c
    7d44:	540042c0 	b.eq	859c <fwp_write+0xcec>  // b.none
    7d48:	71006c1f 	cmp	w0, #0x1b
    7d4c:	54000408 	b.hi	7dcc <fwp_write+0x51c>  // b.pmore
    7d50:	9ac02301 	lsl	x1, x24, x0
    7d54:	ea17003f 	tst	x1, x23
    7d58:	540036a1 	b.ne	842c <fwp_write+0xb7c>  // b.any
    7d5c:	ea19003f 	tst	x1, x25
    7d60:	54003521 	b.ne	8404 <fwp_write+0xb54>  // b.any
    7d64:	d2800424 	mov	x4, #0x21                  	// #33
    7d68:	ea04003f 	tst	x1, x4
    7d6c:	54000300 	b.eq	7dcc <fwp_write+0x51c>  // b.none
    7d70:	b7f849c3 	tbnz	x3, #63, 86a8 <fwp_write+0xdf8>
    7d74:	91002261 	add	x1, x19, #0x8
    7d78:	8b150021 	add	x1, x1, x21
    7d7c:	39400021 	ldrb	w1, [x1]
    7d80:	7100001f 	cmp	w0, #0x0
    7d84:	93401c23 	sxtb	x3, w1
    7d88:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7d8c:	d503201f 	nop
    7d90:	aa1403e0 	mov	x0, x20
    7d94:	52800003 	mov	w3, #0x0                   	// #0
    7d98:	97fffec6 	bl	78b0 <fwp_write>
    7d9c:	910006b5 	add	x21, x21, #0x1
    7da0:	f9400260 	ldr	x0, [x19]
    7da4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7da8:	eb0002bf 	cmp	x21, x0
    7dac:	540026c2 	b.cs	8284 <fwp_write+0x9d4>  // b.hs, b.nlast
    7db0:	d2800042 	mov	x2, #0x2                   	// #2
    7db4:	aa1603e1 	mov	x1, x22
    7db8:	aa1403e0 	mov	x0, x20
    7dbc:	97ffee35 	bl	3690 <buf_put>
    7dc0:	f9401f82 	ldr	x2, [x28, #56]
    7dc4:	f9400263 	ldr	x3, [x19]
    7dc8:	b5fffba2 	cbnz	x2, 7d3c <fwp_write+0x48c>
    7dcc:	d37df2a0 	lsl	x0, x21, #3
    7dd0:	b7f83f03 	tbnz	x3, #63, 85b0 <fwp_write+0xd00>
    7dd4:	91002261 	add	x1, x19, #0x8
    7dd8:	8b000020 	add	x0, x1, x0
    7ddc:	f9400001 	ldr	x1, [x0]
    7de0:	17ffffec 	b	7d90 <fwp_write+0x4e0>
    7de4:	a9400e62 	ldp	x2, x3, [x19]
    7de8:	b7f83ca3 	tbnz	x3, #63, 857c <fwp_write+0xccc>
    7dec:	910123f5 	add	x21, sp, #0x48
    7df0:	aa1503e0 	mov	x0, x21
    7df4:	97ffec0b 	bl	2e20 <fwp_fmt_u128>
    7df8:	aa1503e0 	mov	x0, x21
    7dfc:	97ffea4d 	bl	2730 <strlen@plt>
    7e00:	aa1503e1 	mov	x1, x21
    7e04:	aa0003e2 	mov	x2, x0
    7e08:	17fffed0 	b	7948 <fwp_write+0x98>
    7e0c:	fd015be8 	str	d8, [sp, #688]
    7e10:	1e270268 	fmov	s8, w19
    7e14:	fd015fe9 	str	d9, [sp, #696]
    7e18:	1e282100 	fcmp	s8, s8
    7e1c:	54004d26 	b.vs	87c0 <fwp_write+0xf10>
    7e20:	1e20c101 	fabs	s1, s8
    7e24:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7e28:	1e270000 	fmov	s0, w0
    7e2c:	1e202020 	fcmp	s1, s0
    7e30:	54002c0d 	b.le	83b0 <fwp_write+0xb00>
    7e34:	1e202118 	fcmpe	s8, #0.0
    7e38:	d0000022 	adrp	x2, d000 <fwp_main_thread+0x520>
    7e3c:	91242042 	add	x2, x2, #0x908
    7e40:	910123f5 	add	x21, sp, #0x48
    7e44:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    7e48:	91368021 	add	x1, x1, #0xda0
    7e4c:	aa1503e0 	mov	x0, x21
    7e50:	9a81c041 	csel	x1, x2, x1, gt
    7e54:	97ffeae3 	bl	29e0 <strcpy@plt>
    7e58:	aa1503e0 	mov	x0, x21
    7e5c:	97ffea35 	bl	2730 <strlen@plt>
    7e60:	aa1503e1 	mov	x1, x21
    7e64:	aa0003e2 	mov	x2, x0
    7e68:	aa1403e0 	mov	x0, x20
    7e6c:	97ffee09 	bl	3690 <buf_put>
    7e70:	f9413bf5 	ldr	x21, [sp, #624]
    7e74:	f9413ff6 	ldr	x22, [sp, #632]
    7e78:	f94153fb 	ldr	x27, [sp, #672]
    7e7c:	f94157fc 	ldr	x28, [sp, #680]
    7e80:	fd415be8 	ldr	d8, [sp, #688]
    7e84:	fd415fe9 	ldr	d9, [sp, #696]
    7e88:	17fffeb6 	b	7960 <fwp_write+0xb0>
    7e8c:	f9400276 	ldr	x22, [x19]
    7e90:	34002e03 	cbz	w3, 8450 <fwp_write+0xba0>
    7e94:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    7e98:	f947f400 	ldr	x0, [x0, #4072]
    7e9c:	f94127e2 	ldr	x2, [sp, #584]
    7ea0:	f9400001 	ldr	x1, [x0]
    7ea4:	eb010042 	subs	x2, x2, x1
    7ea8:	d2800001 	mov	x1, #0x0                   	// #0
    7eac:	540014a1 	b.ne	8140 <fwp_write+0x890>  // b.any
    7eb0:	aa1603e2 	mov	x2, x22
    7eb4:	91002261 	add	x1, x19, #0x8
    7eb8:	f9413bf5 	ldr	x21, [sp, #624]
    7ebc:	aa1403e0 	mov	x0, x20
    7ec0:	f9413ff6 	ldr	x22, [sp, #632]
    7ec4:	17fffeff 	b	7ac0 <fwp_write+0x210>
    7ec8:	fd015be8 	str	d8, [sp, #688]
    7ecc:	9e670268 	fmov	d8, x19
    7ed0:	fd015fe9 	str	d9, [sp, #696]
    7ed4:	1e682100 	fcmp	d8, d8
    7ed8:	54004746 	b.vs	87c0 <fwp_write+0xf10>
    7edc:	1e60c101 	fabs	d1, d8
    7ee0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7ee4:	9e670000 	fmov	d0, x0
    7ee8:	910123f5 	add	x21, sp, #0x48
    7eec:	52800033 	mov	w19, #0x1                   	// #1
    7ef0:	1e602020 	fcmp	d1, d0
    7ef4:	540001ad 	b.le	7f28 <fwp_write+0x678>
    7ef8:	1e602118 	fcmpe	d8, #0.0
    7efc:	d0000022 	adrp	x2, d000 <fwp_main_thread+0x520>
    7f00:	91242042 	add	x2, x2, #0x908
    7f04:	d0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    7f08:	91368021 	add	x1, x1, #0xda0
    7f0c:	aa1503e0 	mov	x0, x21
    7f10:	9a81c041 	csel	x1, x2, x1, gt
    7f14:	97ffeab3 	bl	29e0 <strcpy@plt>
    7f18:	17ffffd0 	b	7e58 <fwp_write+0x5a8>
    7f1c:	11000673 	add	w19, w19, #0x1
    7f20:	71004a7f 	cmp	w19, #0x12
    7f24:	54003860 	b.eq	8630 <fwp_write+0xd80>  // b.none
    7f28:	1e604100 	fmov	d0, d8
    7f2c:	2a1303e1 	mov	w1, w19
    7f30:	aa1503e0 	mov	x0, x21
    7f34:	97ffee33 	bl	3800 <fwp_format_g.constprop.0>
    7f38:	aa1503e0 	mov	x0, x21
    7f3c:	d2800001 	mov	x1, #0x0                   	// #0
    7f40:	97ffea10 	bl	2780 <strtod@plt>
    7f44:	1e602100 	fcmp	d8, d0
    7f48:	54fffea1 	b.ne	7f1c <fwp_write+0x66c>  // b.any
    7f4c:	aa1503e0 	mov	x0, x21
    7f50:	97ffee09 	bl	3774 <fwp_finish_float>
    7f54:	17ffffc1 	b	7e58 <fwp_write+0x5a8>
    7f58:	a9400e62 	ldp	x2, x3, [x19]
    7f5c:	910123f3 	add	x19, sp, #0x48
    7f60:	aa1303e0 	mov	x0, x19
    7f64:	97ffebaf 	bl	2e20 <fwp_fmt_u128>
    7f68:	17fffe74 	b	7938 <fwp_write+0x88>
    7f6c:	f90143f7 	str	x23, [sp, #640]
    7f70:	f90147f8 	str	x24, [sp, #648]
    7f74:	2a1303f8 	mov	w24, w19
    7f78:	f9014bf9 	str	x25, [sp, #656]
    7f7c:	f9014ffa 	str	x26, [sp, #664]
    7f80:	f13ffe7f 	cmp	x19, #0xfff
    7f84:	54000049 	b.ls	7f8c <fwp_write+0x6dc>  // b.plast
    7f88:	b9400278 	ldr	w24, [x19]
    7f8c:	f9400f80 	ldr	x0, [x28, #24]
    7f90:	2a1803f5 	mov	w21, w24
    7f94:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7f98:	d37ef6b9 	lsl	x25, x21, #2
    7f9c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7fa0:	aa1603e0 	mov	x0, x22
    7fa4:	97ffe9e3 	bl	2730 <strlen@plt>
    7fa8:	aa1603e1 	mov	x1, x22
    7fac:	aa0003e2 	mov	x2, x0
    7fb0:	aa1403e0 	mov	x0, x20
    7fb4:	97ffedb7 	bl	3690 <buf_put>
    7fb8:	f9401780 	ldr	x0, [x28, #40]
    7fbc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7fc0:	7100001f 	cmp	w0, #0x0
    7fc4:	5400068d 	b.le	8094 <fwp_write+0x7e4>
    7fc8:	91002276 	add	x22, x19, #0x8
    7fcc:	91001ff5 	add	x21, sp, #0x7
    7fd0:	d280001b 	mov	x27, #0x0                   	// #0
    7fd4:	5280041a 	mov	w26, #0x20                  	// #32
    7fd8:	f9401b80 	ldr	x0, [x28, #48]
    7fdc:	aa1503e1 	mov	x1, x21
    7fe0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7fe4:	d2800022 	mov	x2, #0x1                   	// #1
    7fe8:	f8786803 	ldr	x3, [x0, x24]
    7fec:	aa1403e0 	mov	x0, x20
    7ff0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7ff4:	39001ffa 	strb	w26, [sp, #7]
    7ff8:	97ffeda6 	bl	3690 <buf_put>
    7ffc:	f13ffeff 	cmp	x23, #0xfff
    8000:	b9400261 	ldr	w1, [x19]
    8004:	1a9f97e0 	cset	w0, hi	// hi = pmore
    8008:	7100383f 	cmp	w1, #0xe
    800c:	54000160 	b.eq	8038 <fwp_write+0x788>  // b.none
    8010:	7100403f 	cmp	w1, #0x10
    8014:	54001a60 	b.eq	8360 <fwp_write+0xab0>  // b.none
    8018:	7100283f 	cmp	w1, #0xa
    801c:	54002aa0 	b.eq	8570 <fwp_write+0xcc0>  // b.none
    8020:	540014ac 	b.gt	82b4 <fwp_write+0xa04>
    8024:	71000c3f 	cmp	w1, #0x3
    8028:	540029ac 	b.gt	855c <fwp_write+0xcac>
    802c:	d37ffee0 	lsr	x0, x23, #63
    8030:	37f814a1 	tbnz	w1, #31, 82c4 <fwp_write+0xa14>
    8034:	d503201f 	nop
    8038:	34001460 	cbz	w0, 82c4 <fwp_write+0xa14>
    803c:	52800503 	mov	w3, #0x28                  	// #40
    8040:	aa1503e1 	mov	x1, x21
    8044:	aa1403e0 	mov	x0, x20
    8048:	d2800022 	mov	x2, #0x1                   	// #1
    804c:	39001fe3 	strb	w3, [sp, #7]
    8050:	97ffed90 	bl	3690 <buf_put>
    8054:	aa1303e2 	mov	x2, x19
    8058:	aa1703e1 	mov	x1, x23
    805c:	aa1403e0 	mov	x0, x20
    8060:	52800003 	mov	w3, #0x0                   	// #0
    8064:	97fffe13 	bl	78b0 <fwp_write>
    8068:	52800523 	mov	w3, #0x29                  	// #41
    806c:	aa1503e1 	mov	x1, x21
    8070:	aa1403e0 	mov	x0, x20
    8074:	d2800022 	mov	x2, #0x1                   	// #1
    8078:	39001fe3 	strb	w3, [sp, #7]
    807c:	97ffed85 	bl	3690 <buf_put>
    8080:	f9401780 	ldr	x0, [x28, #40]
    8084:	9100077b 	add	x27, x27, #0x1
    8088:	b8796800 	ldr	w0, [x0, x25]
    808c:	6b1b001f 	cmp	w0, w27
    8090:	54fffa4c 	b.gt	7fd8 <fwp_write+0x728>
    8094:	f9413bf5 	ldr	x21, [sp, #624]
    8098:	f9413ff6 	ldr	x22, [sp, #632]
    809c:	f94143f7 	ldr	x23, [sp, #640]
    80a0:	f94147f8 	ldr	x24, [sp, #648]
    80a4:	f9414bf9 	ldr	x25, [sp, #656]
    80a8:	f9414ffa 	ldr	x26, [sp, #664]
    80ac:	f94153fb 	ldr	x27, [sp, #672]
    80b0:	f94157fc 	ldr	x28, [sp, #680]
    80b4:	17fffe2b 	b	7960 <fwp_write+0xb0>
    80b8:	52800783 	mov	w3, #0x3c                  	// #60
    80bc:	91001ff3 	add	x19, sp, #0x7
    80c0:	aa1303e1 	mov	x1, x19
    80c4:	d2800022 	mov	x2, #0x1                   	// #1
    80c8:	aa1403e0 	mov	x0, x20
    80cc:	39001fe3 	strb	w3, [sp, #7]
    80d0:	97ffed70 	bl	3690 <buf_put>
    80d4:	f9400795 	ldr	x21, [x28, #8]
    80d8:	aa1503e0 	mov	x0, x21
    80dc:	97ffe995 	bl	2730 <strlen@plt>
    80e0:	aa1503e1 	mov	x1, x21
    80e4:	aa0003e2 	mov	x2, x0
    80e8:	aa1403e0 	mov	x0, x20
    80ec:	97ffed69 	bl	3690 <buf_put>
    80f0:	528007c3 	mov	w3, #0x3e                  	// #62
    80f4:	aa1303e1 	mov	x1, x19
    80f8:	aa1403e0 	mov	x0, x20
    80fc:	d2800022 	mov	x2, #0x1                   	// #1
    8100:	39001fe3 	strb	w3, [sp, #7]
    8104:	17fffe12 	b	794c <fwp_write+0x9c>
    8108:	f100067f 	cmp	x19, #0x1
    810c:	540025a0 	b.eq	85c0 <fwp_write+0xd10>  // b.none
    8110:	b100067f 	cmn	x19, #0x1
    8114:	54002bc0 	b.eq	868c <fwp_write+0xddc>  // b.none
    8118:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    811c:	9136a021 	add	x1, x1, #0xda8
    8120:	d2800022 	mov	x2, #0x1                   	// #1
    8124:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8128:	f947f400 	ldr	x0, [x0, #4072]
    812c:	f94127e4 	ldr	x4, [sp, #584]
    8130:	f9400003 	ldr	x3, [x0]
    8134:	eb030084 	subs	x4, x4, x3
    8138:	d2800003 	mov	x3, #0x0                   	// #0
    813c:	54ffebe0 	b.eq	7eb8 <fwp_write+0x608>  // b.none
    8140:	f90143f7 	str	x23, [sp, #640]
    8144:	f90147f8 	str	x24, [sp, #648]
    8148:	f9014bf9 	str	x25, [sp, #656]
    814c:	f9014ffa 	str	x26, [sp, #664]
    8150:	fd015be8 	str	d8, [sp, #688]
    8154:	fd015fe9 	str	d9, [sp, #696]
    8158:	97ffe9d2 	bl	28a0 <__stack_chk_fail@plt>
    815c:	52800b63 	mov	w3, #0x5b                  	// #91
    8160:	91001ff5 	add	x21, sp, #0x7
    8164:	aa1503e1 	mov	x1, x21
    8168:	aa1403e0 	mov	x0, x20
    816c:	d2800022 	mov	x2, #0x1                   	// #1
    8170:	b0000036 	adrp	x22, d000 <fwp_main_thread+0x520>
    8174:	913922d6 	add	x22, x22, #0xe48
    8178:	39001fe3 	strb	w3, [sp, #7]
    817c:	97ffed45 	bl	3690 <buf_put>
    8180:	b4000273 	cbz	x19, 81cc <fwp_write+0x91c>
    8184:	f9400661 	ldr	x1, [x19, #8]
    8188:	aa1403e0 	mov	x0, x20
    818c:	f9401f82 	ldr	x2, [x28, #56]
    8190:	52800003 	mov	w3, #0x0                   	// #0
    8194:	97fffdc7 	bl	78b0 <fwp_write>
    8198:	f9400a73 	ldr	x19, [x19, #16]
    819c:	b4000193 	cbz	x19, 81cc <fwp_write+0x91c>
    81a0:	aa1603e1 	mov	x1, x22
    81a4:	aa1403e0 	mov	x0, x20
    81a8:	d2800042 	mov	x2, #0x2                   	// #2
    81ac:	97ffed39 	bl	3690 <buf_put>
    81b0:	f9400661 	ldr	x1, [x19, #8]
    81b4:	aa1403e0 	mov	x0, x20
    81b8:	f9401f82 	ldr	x2, [x28, #56]
    81bc:	52800003 	mov	w3, #0x0                   	// #0
    81c0:	97fffdbc 	bl	78b0 <fwp_write>
    81c4:	f9400a73 	ldr	x19, [x19, #16]
    81c8:	b5fffed3 	cbnz	x19, 81a0 <fwp_write+0x8f0>
    81cc:	52800ba3 	mov	w3, #0x5d                  	// #93
    81d0:	aa1503e1 	mov	x1, x21
    81d4:	aa1403e0 	mov	x0, x20
    81d8:	d2800022 	mov	x2, #0x1                   	// #1
    81dc:	39001fe3 	strb	w3, [sp, #7]
    81e0:	17fffddb 	b	794c <fwp_write+0x9c>
    81e4:	aa1403e0 	mov	x0, x20
    81e8:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    81ec:	d28000c2 	mov	x2, #0x6                   	// #6
    81f0:	9138e021 	add	x1, x1, #0xe38
    81f4:	97ffed27 	bl	3690 <buf_put>
    81f8:	f9400260 	ldr	x0, [x19]
    81fc:	b40004c0 	cbz	x0, 8294 <fwp_write+0x9e4>
    8200:	910123f5 	add	x21, sp, #0x48
    8204:	91002276 	add	x22, x19, #0x8
    8208:	f90143f7 	str	x23, [sp, #640]
    820c:	d2800017 	mov	x23, #0x0                   	// #0
    8210:	f90147f8 	str	x24, [sp, #648]
    8214:	b0000038 	adrp	x24, d000 <fwp_main_thread+0x520>
    8218:	91390318 	add	x24, x24, #0xe40
    821c:	f9014bf9 	str	x25, [sp, #656]
    8220:	b0000039 	adrp	x25, d000 <fwp_main_thread+0x520>
    8224:	91392339 	add	x25, x25, #0xe48
    8228:	f9014ffa 	str	x26, [sp, #664]
    822c:	14000005 	b	8240 <fwp_write+0x990>
    8230:	aa1903e1 	mov	x1, x25
    8234:	aa1403e0 	mov	x0, x20
    8238:	d2800042 	mov	x2, #0x2                   	// #2
    823c:	97ffed15 	bl	3690 <buf_put>
    8240:	38776ac5 	ldrb	w5, [x22, x23]
    8244:	d2804003 	mov	x3, #0x200                 	// #512
    8248:	aa1803e4 	mov	x4, x24
    824c:	aa0303e1 	mov	x1, x3
    8250:	52800042 	mov	w2, #0x2                   	// #2
    8254:	aa1503e0 	mov	x0, x21
    8258:	910006f7 	add	x23, x23, #0x1
    825c:	97ffe96d 	bl	2810 <__snprintf_chk@plt>
    8260:	aa1503e0 	mov	x0, x21
    8264:	97ffe933 	bl	2730 <strlen@plt>
    8268:	aa1503e1 	mov	x1, x21
    826c:	aa0003e2 	mov	x2, x0
    8270:	aa1403e0 	mov	x0, x20
    8274:	97ffed07 	bl	3690 <buf_put>
    8278:	f9400260 	ldr	x0, [x19]
    827c:	eb17001f 	cmp	x0, x23
    8280:	54fffd88 	b.hi	8230 <fwp_write+0x980>  // b.pmore
    8284:	f94143f7 	ldr	x23, [sp, #640]
    8288:	f94147f8 	ldr	x24, [sp, #648]
    828c:	f9414bf9 	ldr	x25, [sp, #656]
    8290:	f9414ffa 	ldr	x26, [sp, #664]
    8294:	52800ba3 	mov	w3, #0x5d                  	// #93
    8298:	aa1403e0 	mov	x0, x20
    829c:	91001fe1 	add	x1, sp, #0x7
    82a0:	d2800022 	mov	x2, #0x1                   	// #1
    82a4:	39001fe3 	strb	w3, [sp, #7]
    82a8:	17fffda9 	b	794c <fwp_write+0x9c>
    82ac:	52800fa3 	mov	w3, #0x7d                  	// #125
    82b0:	17fffe44 	b	7bc0 <fwp_write+0x310>
    82b4:	f10002ff 	cmp	x23, #0x0
    82b8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    82bc:	71002c3f 	cmp	w1, #0xb
    82c0:	54ffebc0 	b.eq	8038 <fwp_write+0x788>  // b.none
    82c4:	aa1303e2 	mov	x2, x19
    82c8:	aa1703e1 	mov	x1, x23
    82cc:	aa1403e0 	mov	x0, x20
    82d0:	52800003 	mov	w3, #0x0                   	// #0
    82d4:	97fffd77 	bl	78b0 <fwp_write>
    82d8:	17ffff6a 	b	8080 <fwp_write+0x7d0>
    82dc:	aa1403e0 	mov	x0, x20
    82e0:	91001fe1 	add	x1, sp, #0x7
    82e4:	52800fa3 	mov	w3, #0x7d                  	// #125
    82e8:	d2800022 	mov	x2, #0x1                   	// #1
    82ec:	17fffe38 	b	7bcc <fwp_write+0x31c>
    82f0:	a9400281 	ldp	x1, x0, [x20]
    82f4:	91000800 	add	x0, x0, #0x2
    82f8:	8b160000 	add	x0, x0, x22
    82fc:	f9000680 	str	x0, [x20, #8]
    8300:	3820683f 	strb	wzr, [x1, x0]
    8304:	f9413bf5 	ldr	x21, [sp, #624]
    8308:	f9413ff6 	ldr	x22, [sp, #632]
    830c:	f94153fb 	ldr	x27, [sp, #672]
    8310:	f94157fc 	ldr	x28, [sp, #680]
    8314:	17fffd93 	b	7960 <fwp_write+0xb0>
    8318:	f9400f80 	ldr	x0, [x28, #24]
    831c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8320:	aa1b03e0 	mov	x0, x27
    8324:	97ffe903 	bl	2730 <strlen@plt>
    8328:	aa1b03e1 	mov	x1, x27
    832c:	aa0003e2 	mov	x2, x0
    8330:	aa1403e0 	mov	x0, x20
    8334:	97ffecd7 	bl	3690 <buf_put>
    8338:	aa1903e1 	mov	x1, x25
    833c:	aa1403e0 	mov	x0, x20
    8340:	d2800062 	mov	x2, #0x3                   	// #3
    8344:	97ffecd3 	bl	3690 <buf_put>
    8348:	17fffe10 	b	7b88 <fwp_write+0x2d8>
    834c:	aa1a03e1 	mov	x1, x26
    8350:	aa1403e0 	mov	x0, x20
    8354:	d2800042 	mov	x2, #0x2                   	// #2
    8358:	97ffecce 	bl	3690 <buf_put>
    835c:	17fffe09 	b	7b80 <fwp_write+0x2d0>
    8360:	f9400660 	ldr	x0, [x19, #8]
    8364:	b4fffb00 	cbz	x0, 82c4 <fwp_write+0xa14>
    8368:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    836c:	91398021 	add	x1, x1, #0xe60
    8370:	97ffe96c 	bl	2920 <strcmp@plt>
    8374:	7100001f 	cmp	w0, #0x0
    8378:	1a9f07e0 	cset	w0, ne	// ne = any
    837c:	17ffff2f 	b	8038 <fwp_write+0x788>
    8380:	aa1403e0 	mov	x0, x20
    8384:	d2800042 	mov	x2, #0x2                   	// #2
    8388:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    838c:	91396021 	add	x1, x1, #0xe58
    8390:	97ffecc0 	bl	3690 <buf_put>
    8394:	91004261 	add	x1, x19, #0x10
    8398:	aa1403e0 	mov	x0, x20
    839c:	f9402382 	ldr	x2, [x28, #64]
    83a0:	52800003 	mov	w3, #0x0                   	// #0
    83a4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    83a8:	97fffd42 	bl	78b0 <fwp_write>
    83ac:	17fffd9c 	b	7a1c <fwp_write+0x16c>
    83b0:	1e22c109 	fcvt	d9, s8
    83b4:	910123f5 	add	x21, sp, #0x48
    83b8:	52800033 	mov	w19, #0x1                   	// #1
    83bc:	d503201f 	nop
    83c0:	1e604120 	fmov	d0, d9
    83c4:	2a1303e1 	mov	w1, w19
    83c8:	aa1503e0 	mov	x0, x21
    83cc:	97ffed0d 	bl	3800 <fwp_format_g.constprop.0>
    83d0:	aa1503e0 	mov	x0, x21
    83d4:	d2800001 	mov	x1, #0x0                   	// #0
    83d8:	97ffe95e 	bl	2950 <strtof@plt>
    83dc:	1e202100 	fcmp	s8, s0
    83e0:	54ffdb60 	b.eq	7f4c <fwp_write+0x69c>  // b.none
    83e4:	11000673 	add	w19, w19, #0x1
    83e8:	71002a7f 	cmp	w19, #0xa
    83ec:	54fffea1 	b.ne	83c0 <fwp_write+0xb10>  // b.any
    83f0:	1e604120 	fmov	d0, d9
    83f4:	aa1503e0 	mov	x0, x21
    83f8:	52800121 	mov	w1, #0x9                   	// #9
    83fc:	97ffed01 	bl	3800 <fwp_format_g.constprop.0>
    8400:	17fffed3 	b	7f4c <fwp_write+0x69c>
    8404:	d37ef6a1 	lsl	x1, x21, #2
    8408:	b7f81563 	tbnz	x3, #63, 86b4 <fwp_write+0xe04>
    840c:	91002263 	add	x3, x19, #0x8
    8410:	8b010061 	add	x1, x3, x1
    8414:	b9400023 	ldr	w3, [x1]
    8418:	7100081f 	cmp	w0, #0x2
    841c:	2a0303e1 	mov	w1, w3
    8420:	93407c63 	sxtw	x3, w3
    8424:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8428:	17fffe5a 	b	7d90 <fwp_write+0x4e0>
    842c:	d37ffaa1 	lsl	x1, x21, #1
    8430:	b7f81363 	tbnz	x3, #63, 869c <fwp_write+0xdec>
    8434:	91002263 	add	x3, x19, #0x8
    8438:	8b010061 	add	x1, x3, x1
    843c:	79400021 	ldrh	w1, [x1]
    8440:	7100041f 	cmp	w0, #0x1
    8444:	93403c23 	sxth	x3, w1
    8448:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    844c:	17fffe51 	b	7d90 <fwp_write+0x4e0>
    8450:	52800443 	mov	w3, #0x22                  	// #34
    8454:	91001ff5 	add	x21, sp, #0x7
    8458:	91002273 	add	x19, x19, #0x8
    845c:	aa1503e1 	mov	x1, x21
    8460:	aa1403e0 	mov	x0, x20
    8464:	d2800022 	mov	x2, #0x1                   	// #1
    8468:	39001fe3 	strb	w3, [sp, #7]
    846c:	f90143f7 	str	x23, [sp, #640]
    8470:	8b160277 	add	x23, x19, x22
    8474:	f90147f8 	str	x24, [sp, #648]
    8478:	97ffec86 	bl	3690 <buf_put>
    847c:	b4000696 	cbz	x22, 854c <fwp_write+0xc9c>
    8480:	b0000038 	adrp	x24, d000 <fwp_main_thread+0x520>
    8484:	91382318 	add	x24, x24, #0xe08
    8488:	f9014bf9 	str	x25, [sp, #656]
    848c:	b0000039 	adrp	x25, d000 <fwp_main_thread+0x520>
    8490:	9138a339 	add	x25, x25, #0xe28
    8494:	f9014ffa 	str	x26, [sp, #664]
    8498:	1400000d 	b	84cc <fwp_write+0xc1c>
    849c:	710024bf 	cmp	w5, #0x9
    84a0:	54000460 	b.eq	852c <fwp_write+0xc7c>  // b.none
    84a4:	710028bf 	cmp	w5, #0xa
    84a8:	54000a61 	b.ne	85f4 <fwp_write+0xd44>  // b.any
    84ac:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    84b0:	aa1403e0 	mov	x0, x20
    84b4:	91386021 	add	x1, x1, #0xe18
    84b8:	d2800042 	mov	x2, #0x2                   	// #2
    84bc:	97ffec75 	bl	3690 <buf_put>
    84c0:	91000673 	add	x19, x19, #0x1
    84c4:	eb17027f 	cmp	x19, x23
    84c8:	540003e0 	b.eq	8544 <fwp_write+0xc94>  // b.none
    84cc:	39400265 	ldrb	w5, [x19]
    84d0:	710034bf 	cmp	w5, #0xd
    84d4:	54000180 	b.eq	8504 <fwp_write+0xc54>  // b.none
    84d8:	54fffe29 	b.ls	849c <fwp_write+0xbec>  // b.plast
    84dc:	710088bf 	cmp	w5, #0x22
    84e0:	540001c0 	b.eq	8518 <fwp_write+0xc68>  // b.none
    84e4:	710170bf 	cmp	w5, #0x5c
    84e8:	54000741 	b.ne	85d0 <fwp_write+0xd20>  // b.any
    84ec:	aa1403e0 	mov	x0, x20
    84f0:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    84f4:	d2800042 	mov	x2, #0x2                   	// #2
    84f8:	91384021 	add	x1, x1, #0xe10
    84fc:	97ffec65 	bl	3690 <buf_put>
    8500:	17fffff0 	b	84c0 <fwp_write+0xc10>
    8504:	aa1903e1 	mov	x1, x25
    8508:	aa1403e0 	mov	x0, x20
    850c:	d2800042 	mov	x2, #0x2                   	// #2
    8510:	97ffec60 	bl	3690 <buf_put>
    8514:	17ffffeb 	b	84c0 <fwp_write+0xc10>
    8518:	aa1803e1 	mov	x1, x24
    851c:	aa1403e0 	mov	x0, x20
    8520:	d2800042 	mov	x2, #0x2                   	// #2
    8524:	97ffec5b 	bl	3690 <buf_put>
    8528:	17ffffe6 	b	84c0 <fwp_write+0xc10>
    852c:	aa1403e0 	mov	x0, x20
    8530:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    8534:	d2800042 	mov	x2, #0x2                   	// #2
    8538:	91388021 	add	x1, x1, #0xe20
    853c:	97ffec55 	bl	3690 <buf_put>
    8540:	17ffffe0 	b	84c0 <fwp_write+0xc10>
    8544:	f9414bf9 	ldr	x25, [sp, #656]
    8548:	f9414ffa 	ldr	x26, [sp, #664]
    854c:	aa1503e1 	mov	x1, x21
    8550:	aa1403e0 	mov	x0, x20
    8554:	52800443 	mov	w3, #0x22                  	// #34
    8558:	17fffd9c 	b	7bc8 <fwp_write+0x318>
    855c:	7100103f 	cmp	w1, #0x4
    8560:	54ffeb21 	b.ne	82c4 <fwp_write+0xa14>  // b.any
    8564:	f94006e0 	ldr	x0, [x23, #8]
    8568:	d37ffc00 	lsr	x0, x0, #63
    856c:	17fffeb3 	b	8038 <fwp_write+0x788>
    8570:	710002ff 	cmp	w23, #0x0
    8574:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8578:	17fffeb0 	b	8038 <fwp_write+0x788>
    857c:	528005a1 	mov	w1, #0x2d                  	// #45
    8580:	eb0203e2 	negs	x2, x2
    8584:	da0303e3 	ngc	x3, x3
    8588:	910127e0 	add	x0, sp, #0x49
    858c:	910123f5 	add	x21, sp, #0x48
    8590:	390123e1 	strb	w1, [sp, #72]
    8594:	97ffea23 	bl	2e20 <fwp_fmt_u128>
    8598:	17fffe18 	b	7df8 <fwp_write+0x548>
    859c:	d37ceea1 	lsl	x1, x21, #4
    85a0:	b7f810a3 	tbnz	x3, #63, 87b4 <fwp_write+0xf04>
    85a4:	91002260 	add	x0, x19, #0x8
    85a8:	8b010001 	add	x1, x0, x1
    85ac:	17fffdf9 	b	7d90 <fwp_write+0x4e0>
    85b0:	f9400a61 	ldr	x1, [x19, #16]
    85b4:	8b010000 	add	x0, x0, x1
    85b8:	f9400001 	ldr	x1, [x0]
    85bc:	17fffdf5 	b	7d90 <fwp_write+0x4e0>
    85c0:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    85c4:	d2800042 	mov	x2, #0x2                   	// #2
    85c8:	9136c021 	add	x1, x1, #0xdb0
    85cc:	17fffed6 	b	8124 <fwp_write+0x874>
    85d0:	7101fcbf 	cmp	w5, #0x7f
    85d4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    85d8:	540000e9 	b.ls	85f4 <fwp_write+0xd44>  // b.plast
    85dc:	aa1503e1 	mov	x1, x21
    85e0:	aa1403e0 	mov	x0, x20
    85e4:	d2800022 	mov	x2, #0x1                   	// #1
    85e8:	39001fe5 	strb	w5, [sp, #7]
    85ec:	97ffec29 	bl	3690 <buf_put>
    85f0:	17ffffb4 	b	84c0 <fwp_write+0xc10>
    85f4:	d2800203 	mov	x3, #0x10                  	// #16
    85f8:	b0000024 	adrp	x4, d000 <fwp_main_thread+0x520>
    85fc:	aa0303e1 	mov	x1, x3
    8600:	9138c084 	add	x4, x4, #0xe30
    8604:	910123f6 	add	x22, sp, #0x48
    8608:	52800042 	mov	w2, #0x2                   	// #2
    860c:	aa1603e0 	mov	x0, x22
    8610:	97ffe880 	bl	2810 <__snprintf_chk@plt>
    8614:	aa1603e0 	mov	x0, x22
    8618:	97ffe846 	bl	2730 <strlen@plt>
    861c:	aa1603e1 	mov	x1, x22
    8620:	aa0003e2 	mov	x2, x0
    8624:	aa1403e0 	mov	x0, x20
    8628:	97ffec1a 	bl	3690 <buf_put>
    862c:	17ffffa5 	b	84c0 <fwp_write+0xc10>
    8630:	1e604100 	fmov	d0, d8
    8634:	aa1503e0 	mov	x0, x21
    8638:	52800221 	mov	w1, #0x11                  	// #17
    863c:	97ffec71 	bl	3800 <fwp_format_g.constprop.0>
    8640:	17fffe43 	b	7f4c <fwp_write+0x69c>
    8644:	b9401040 	ldr	w0, [x2, #16]
    8648:	350003c0 	cbnz	w0, 86c0 <fwp_write+0xe10>
    864c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8650:	f947f400 	ldr	x0, [x0, #4072]
    8654:	f94127e2 	ldr	x2, [sp, #584]
    8658:	f9400001 	ldr	x1, [x0]
    865c:	eb010042 	subs	x2, x2, x1
    8660:	d2800001 	mov	x1, #0x0                   	// #0
    8664:	54ffd721 	b.ne	8148 <fwp_write+0x898>  // b.any
    8668:	f9413bf5 	ldr	x21, [sp, #624]
    866c:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    8670:	f9413ff6 	ldr	x22, [sp, #632]
    8674:	aa1403e0 	mov	x0, x20
    8678:	f94143f7 	ldr	x23, [sp, #640]
    867c:	913a0021 	add	x1, x1, #0xe80
    8680:	f94147f8 	ldr	x24, [sp, #648]
    8684:	d2800042 	mov	x2, #0x2                   	// #2
    8688:	17fffd0e 	b	7ac0 <fwp_write+0x210>
    868c:	b0000021 	adrp	x1, d000 <fwp_main_thread+0x520>
    8690:	d2800042 	mov	x2, #0x2                   	// #2
    8694:	9136e021 	add	x1, x1, #0xdb8
    8698:	17fffea3 	b	8124 <fwp_write+0x874>
    869c:	f9400a63 	ldr	x3, [x19, #16]
    86a0:	8b030021 	add	x1, x1, x3
    86a4:	17ffff66 	b	843c <fwp_write+0xb8c>
    86a8:	f9400a61 	ldr	x1, [x19, #16]
    86ac:	8b0102a1 	add	x1, x21, x1
    86b0:	17fffdb3 	b	7d7c <fwp_write+0x4cc>
    86b4:	f9400a63 	ldr	x3, [x19, #16]
    86b8:	8b030021 	add	x1, x1, x3
    86bc:	17ffff56 	b	8414 <fwp_write+0xb64>
    86c0:	b9404840 	ldr	w0, [x2, #72]
    86c4:	91001ff5 	add	x21, sp, #0x7
    86c8:	34ffa360 	cbz	w0, 7b34 <fwp_write+0x284>
    86cc:	52800503 	mov	w3, #0x28                  	// #40
    86d0:	aa1403e0 	mov	x0, x20
    86d4:	aa1503e1 	mov	x1, x21
    86d8:	d2800022 	mov	x2, #0x1                   	// #1
    86dc:	39001fe3 	strb	w3, [sp, #7]
    86e0:	97ffebec 	bl	3690 <buf_put>
    86e4:	b9401380 	ldr	w0, [x28, #16]
    86e8:	52800038 	mov	w24, #0x1                   	// #1
    86ec:	7100001f 	cmp	w0, #0x0
    86f0:	54ffa36c 	b.gt	7b5c <fwp_write+0x2ac>
    86f4:	17fffd32 	b	7bbc <fwp_write+0x30c>
    86f8:	f9014bf9 	str	x25, [sp, #656]
    86fc:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xe4b0>
    8700:	f9014ffa 	str	x26, [sp, #664]
    8704:	f9400676 	ldr	x22, [x19, #8]
    8708:	910ac333 	add	x19, x25, #0x2b0
    870c:	91002273 	add	x19, x19, #0x8
    8710:	937ffed8 	asr	x24, x22, #63
    8714:	aa1802c0 	orr	x0, x22, x24
    8718:	b5000320 	cbnz	x0, 877c <fwp_write+0xecc>
    871c:	110006b5 	add	w21, w21, #0x1
    8720:	710016bf 	cmp	w21, #0x5
    8724:	54ffffc1 	b.ne	871c <fwp_write+0xe6c>  // b.any
    8728:	b7f80578 	tbnz	x24, #63, 87d4 <fwp_write+0xf24>
    872c:	910023f3 	add	x19, sp, #0x8
    8730:	aa1603e2 	mov	x2, x22
    8734:	aa1303e0 	mov	x0, x19
    8738:	d2800003 	mov	x3, #0x0                   	// #0
    873c:	97ffe9b9 	bl	2e20 <fwp_fmt_u128>
    8740:	910123f5 	add	x21, sp, #0x48
    8744:	b0000023 	adrp	x3, d000 <fwp_main_thread+0x520>
    8748:	aa1303e4 	mov	x4, x19
    874c:	aa1503e0 	mov	x0, x21
    8750:	9139e063 	add	x3, x3, #0xe78
    8754:	d2804002 	mov	x2, #0x200                 	// #512
    8758:	52800041 	mov	w1, #0x2                   	// #2
    875c:	97ffe7f9 	bl	2740 <__sprintf_chk@plt>
    8760:	aa1503e0 	mov	x0, x21
    8764:	97ffe7f3 	bl	2730 <strlen@plt>
    8768:	aa1503e1 	mov	x1, x21
    876c:	aa0003e2 	mov	x2, x0
    8770:	aa1403e0 	mov	x0, x20
    8774:	97ffebc7 	bl	3690 <buf_put>
    8778:	17fffe47 	b	8094 <fwp_write+0x7e4>
    877c:	f9400277 	ldr	x23, [x19]
    8780:	aa1603e0 	mov	x0, x22
    8784:	aa1803e1 	mov	x1, x24
    8788:	aa1703e2 	mov	x2, x23
    878c:	937ffefa 	asr	x26, x23, #63
    8790:	aa1a03e3 	mov	x3, x26
    8794:	94001317 	bl	d3f0 <__modti3>
    8798:	aa010000 	orr	x0, x0, x1
    879c:	b40002c0 	cbz	x0, 87f4 <fwp_write+0xf44>
    87a0:	110006b5 	add	w21, w21, #0x1
    87a4:	91004273 	add	x19, x19, #0x10
    87a8:	710016bf 	cmp	w21, #0x5
    87ac:	54fffe81 	b.ne	877c <fwp_write+0xecc>  // b.any
    87b0:	17ffffde 	b	8728 <fwp_write+0xe78>
    87b4:	f9400a60 	ldr	x0, [x19, #16]
    87b8:	8b000021 	add	x1, x1, x0
    87bc:	17fffd75 	b	7d90 <fwp_write+0x4e0>
    87c0:	528c29c0 	mov	w0, #0x614e                	// #24910
    87c4:	910123f5 	add	x21, sp, #0x48
    87c8:	72a009c0 	movk	w0, #0x4e, lsl #16
    87cc:	b9004be0 	str	w0, [sp, #72]
    87d0:	17fffda2 	b	7e58 <fwp_write+0x5a8>
    87d4:	528005a1 	mov	w1, #0x2d                  	// #45
    87d8:	eb1603e2 	negs	x2, x22
    87dc:	da1803e3 	ngc	x3, x24
    87e0:	910027e0 	add	x0, sp, #0x9
    87e4:	910023f3 	add	x19, sp, #0x8
    87e8:	390023e1 	strb	w1, [sp, #8]
    87ec:	97ffe98d 	bl	2e20 <fwp_fmt_u128>
    87f0:	17ffffd4 	b	8740 <fwp_write+0xe90>
    87f4:	aa1703e2 	mov	x2, x23
    87f8:	aa1a03e3 	mov	x3, x26
    87fc:	aa1603e0 	mov	x0, x22
    8800:	aa1803e1 	mov	x1, x24
    8804:	9400121b 	bl	d070 <__divti3>
    8808:	aa0003e2 	mov	x2, x0
    880c:	aa0103e3 	mov	x3, x1
    8810:	b7f80201 	tbnz	x1, #63, 8850 <fwp_write+0xfa0>
    8814:	910023f3 	add	x19, sp, #0x8
    8818:	aa1303e0 	mov	x0, x19
    881c:	97ffe981 	bl	2e20 <fwp_fmt_u128>
    8820:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8824:	910ac339 	add	x25, x25, #0x2b0
    8828:	910123f5 	add	x21, sp, #0x48
    882c:	aa1303e4 	mov	x4, x19
    8830:	aa1503e0 	mov	x0, x21
    8834:	b0000023 	adrp	x3, d000 <fwp_main_thread+0x520>
    8838:	f8616b25 	ldr	x5, [x25, x1]
    883c:	9139c063 	add	x3, x3, #0xe70
    8840:	d2804002 	mov	x2, #0x200                 	// #512
    8844:	52800041 	mov	w1, #0x2                   	// #2
    8848:	97ffe7be 	bl	2740 <__sprintf_chk@plt>
    884c:	17ffffc5 	b	8760 <fwp_write+0xeb0>
    8850:	528005a4 	mov	w4, #0x2d                  	// #45
    8854:	eb0003e2 	negs	x2, x0
    8858:	da0103e3 	ngc	x3, x1
    885c:	910027e0 	add	x0, sp, #0x9
    8860:	910023f3 	add	x19, sp, #0x8
    8864:	390023e4 	strb	w4, [sp, #8]
    8868:	97ffe96e 	bl	2e20 <fwp_fmt_u128>
    886c:	17ffffed 	b	8820 <fwp_write+0xf70>
    8870:	f9013bf5 	str	x21, [sp, #624]
    8874:	f9013ff6 	str	x22, [sp, #632]
    8878:	f90143f7 	str	x23, [sp, #640]
    887c:	f90147f8 	str	x24, [sp, #648]
    8880:	f9014bf9 	str	x25, [sp, #656]
    8884:	f9014ffa 	str	x26, [sp, #664]
    8888:	f90153fb 	str	x27, [sp, #672]
    888c:	f90157fc 	str	x28, [sp, #680]
    8890:	fd015be8 	str	d8, [sp, #688]
    8894:	fd015fe9 	str	d9, [sp, #696]
    8898:	97ffe802 	bl	28a0 <__stack_chk_fail@plt>
    889c:	d503201f 	nop

00000000000088a0 <fwp_hof0.constprop.0>:
    88a0:	d105c3ff 	sub	sp, sp, #0x170
    88a4:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc90>
    88a8:	f947f442 	ldr	x2, [x2, #4072]
    88ac:	a9117bfd 	stp	x29, x30, [sp, #272]
    88b0:	910443fd 	add	x29, sp, #0x110
    88b4:	a91673fb 	stp	x27, x28, [sp, #352]
    88b8:	aa0003fc 	mov	x28, x0
    88bc:	f9400040 	ldr	x0, [x2]
    88c0:	f90087e0 	str	x0, [sp, #264]
    88c4:	d2800000 	mov	x0, #0x0                   	// #0
    88c8:	b4003701 	cbz	x1, 8fa8 <fwp_hof0.constprop.0+0x708>
    88cc:	a91253f3 	stp	x19, x20, [sp, #288]
    88d0:	900000d3 	adrp	x19, 20000 <__data_start>
    88d4:	91004273 	add	x19, x19, #0x10
    88d8:	910223e0 	add	x0, sp, #0x88
    88dc:	900000d4 	adrp	x20, 20000 <__data_start>
    88e0:	91008273 	add	x19, x19, #0x20
    88e4:	a9135bf5 	stp	x21, x22, [sp, #304]
    88e8:	b0000396 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    88ec:	9118c2db 	add	x27, x22, #0x630
    88f0:	a91463f7 	stp	x23, x24, [sp, #320]
    88f4:	91014297 	add	x23, x20, #0x50
    88f8:	a9156bf9 	stp	x25, x26, [sp, #336]
    88fc:	aa1c03fa 	mov	x26, x28
    8900:	d0fffff8 	adrp	x24, 6000 <e173+0x6c>
    8904:	f90003e0 	str	x0, [sp]
    8908:	910243e0 	add	x0, sp, #0x90
    890c:	f90007e0 	str	x0, [sp, #8]
    8910:	f9000fe1 	str	x1, [sp, #24]
    8914:	f949ef64 	ldr	x4, [x27, #5080]
    8918:	f949db61 	ldr	x1, [x27, #5040]
    891c:	d370bc84 	lsl	x4, x4, #16
    8920:	cb010343 	sub	x3, x26, x1
    8924:	eb04007f 	cmp	x3, x4
    8928:	54000442 	b.cs	89b0 <fwp_hof0.constprop.0+0x110>  // b.hs, b.nlast
    892c:	d350fc60 	lsr	x0, x3, #16
    8930:	f949ff66 	ldr	x6, [x27, #5112]
    8934:	8b000800 	add	x0, x0, x0, lsl #2
    8938:	d37df002 	lsl	x2, x0, #3
    893c:	8b0200c5 	add	x5, x6, x2
    8940:	f94010a0 	ldr	x0, [x5, #32]
    8944:	b4000360 	cbz	x0, 89b0 <fwp_hof0.constprop.0+0x110>
    8948:	386268c2 	ldrb	w2, [x6, x2]
    894c:	7100085f 	cmp	w2, #0x2
    8950:	54000e40 	b.eq	8b18 <fwp_hof0.constprop.0+0x278>  // b.none
    8954:	7100045f 	cmp	w2, #0x1
    8958:	540002c1 	b.ne	89b0 <fwp_hof0.constprop.0+0x110>  // b.any
    895c:	92403c62 	and	x2, x3, #0xffff
    8960:	29430ca6 	ldp	w6, w3, [x5, #24]
    8964:	9b067c42 	mul	x2, x2, x6
    8968:	d360fc42 	lsr	x2, x2, #32
    896c:	eb03005f 	cmp	x2, x3
    8970:	54000202 	b.cs	89b0 <fwp_hof0.constprop.0+0x110>  // b.hs, b.nlast
    8974:	8b020000 	add	x0, x0, x2
    8978:	39400002 	ldrb	w2, [x0]
    897c:	340001a2 	cbz	w2, 89b0 <fwp_hof0.constprop.0+0x110>
    8980:	91014281 	add	x1, x20, #0x50
    8984:	b9413023 	ldr	w3, [x1, #304]
    8988:	35002003 	cbnz	w3, 8d88 <fwp_hof0.constprop.0+0x4e8>
    898c:	7103f45f 	cmp	w2, #0xfd
    8990:	54005028 	b.hi	9394 <fwp_hof0.constprop.0+0xaf4>  // b.pmore
    8994:	9118c2c1 	add	x1, x22, #0x630
    8998:	11000442 	add	w2, w2, #0x1
    899c:	39000002 	strb	w2, [x0]
    89a0:	aa0103e0 	mov	x0, x1
    89a4:	f949d821 	ldr	x1, [x1, #5040]
    89a8:	f949ec04 	ldr	x4, [x0, #5080]
    89ac:	d370bc84 	lsl	x4, x4, #16
    89b0:	911d0319 	add	x25, x24, #0x740
    89b4:	a9026ffa 	stp	x26, x27, [sp, #32]
    89b8:	aa1703fb 	mov	x27, x23
    89bc:	d28018c0 	mov	x0, #0xc6                  	// #198
    89c0:	b2407bfc 	mov	x28, #0x7fffffff            	// #2147483647
    89c4:	f9000be0 	str	x0, [sp, #16]
    89c8:	f941cb60 	ldr	x0, [x27, #912]
    89cc:	a90967e0 	stp	x0, x25, [sp, #144]
    89d0:	12800002 	mov	w2, #0xffffffff            	// #-1
    89d4:	f94003e0 	ldr	x0, [sp]
    89d8:	f90053e0 	str	x0, [sp, #160]
    89dc:	f94007e0 	ldr	x0, [sp, #8]
    89e0:	cb010261 	sub	x1, x19, x1
    89e4:	b9008be2 	str	w2, [sp, #136]
    89e8:	f901cb60 	str	x0, [x27, #912]
    89ec:	eb04003f 	cmp	x1, x4
    89f0:	540007c2 	b.cs	8ae8 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    89f4:	9118c2c2 	add	x2, x22, #0x630
    89f8:	d350fc20 	lsr	x0, x1, #16
    89fc:	8b000800 	add	x0, x0, x0, lsl #2
    8a00:	f949fc43 	ldr	x3, [x2, #5112]
    8a04:	d37df000 	lsl	x0, x0, #3
    8a08:	8b000062 	add	x2, x3, x0
    8a0c:	f9401055 	ldr	x21, [x2, #32]
    8a10:	b40006d5 	cbz	x21, 8ae8 <fwp_hof0.constprop.0+0x248>
    8a14:	38606860 	ldrb	w0, [x3, x0]
    8a18:	7100081f 	cmp	w0, #0x2
    8a1c:	54000840 	b.eq	8b24 <fwp_hof0.constprop.0+0x284>  // b.none
    8a20:	7100041f 	cmp	w0, #0x1
    8a24:	54000621 	b.ne	8ae8 <fwp_hof0.constprop.0+0x248>  // b.any
    8a28:	29430c44 	ldp	w4, w3, [x2, #24]
    8a2c:	92403c20 	and	x0, x1, #0xffff
    8a30:	9b047c00 	mul	x0, x0, x4
    8a34:	d360fc00 	lsr	x0, x0, #32
    8a38:	eb03001f 	cmp	x0, x3
    8a3c:	540002e2 	b.cs	8a98 <fwp_hof0.constprop.0+0x1f8>  // b.hs, b.nlast
    8a40:	8b0002a0 	add	x0, x21, x0
    8a44:	39400003 	ldrb	w3, [x0]
    8a48:	34000283 	cbz	w3, 8a98 <fwp_hof0.constprop.0+0x1f8>
    8a4c:	91014281 	add	x1, x20, #0x50
    8a50:	b9413022 	ldr	w2, [x1, #304]
    8a54:	35001a22 	cbnz	w2, 8d98 <fwp_hof0.constprop.0+0x4f8>
    8a58:	7103f47f 	cmp	w3, #0xfd
    8a5c:	54004a88 	b.hi	93ac <fwp_hof0.constprop.0+0xb0c>  // b.pmore
    8a60:	11000463 	add	w3, w3, #0x1
    8a64:	39000003 	strb	w3, [x0]
    8a68:	9118c2c0 	add	x0, x22, #0x630
    8a6c:	f949d801 	ldr	x1, [x0, #5040]
    8a70:	f949ec02 	ldr	x2, [x0, #5080]
    8a74:	cb010261 	sub	x1, x19, x1
    8a78:	eb02403f 	cmp	x1, x2, lsl #16
    8a7c:	54000362 	b.cs	8ae8 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    8a80:	f949fc00 	ldr	x0, [x0, #5112]
    8a84:	d350fc22 	lsr	x2, x1, #16
    8a88:	8b020842 	add	x2, x2, x2, lsl #2
    8a8c:	8b020c02 	add	x2, x0, x2, lsl #3
    8a90:	f9401055 	ldr	x21, [x2, #32]
    8a94:	b40002b5 	cbz	x21, 8ae8 <fwp_hof0.constprop.0+0x248>
    8a98:	39400040 	ldrb	w0, [x2]
    8a9c:	7100081f 	cmp	w0, #0x2
    8aa0:	54000600 	b.eq	8b60 <fwp_hof0.constprop.0+0x2c0>  // b.none
    8aa4:	7100041f 	cmp	w0, #0x1
    8aa8:	54000201 	b.ne	8ae8 <fwp_hof0.constprop.0+0x248>  // b.any
    8aac:	29430043 	ldp	w3, w0, [x2, #24]
    8ab0:	92403c21 	and	x1, x1, #0xffff
    8ab4:	9b037c21 	mul	x1, x1, x3
    8ab8:	d360fc21 	lsr	x1, x1, #32
    8abc:	eb00003f 	cmp	x1, x0
    8ac0:	54000142 	b.cs	8ae8 <fwp_hof0.constprop.0+0x248>  // b.hs, b.nlast
    8ac4:	8b0102b5 	add	x21, x21, x1
    8ac8:	394002a0 	ldrb	w0, [x21]
    8acc:	340000e0 	cbz	w0, 8ae8 <fwp_hof0.constprop.0+0x248>
    8ad0:	7100041f 	cmp	w0, #0x1
    8ad4:	54000300 	b.eq	8b34 <fwp_hof0.constprop.0+0x294>  // b.none
    8ad8:	7103fc1f 	cmp	w0, #0xff
    8adc:	540046c0 	b.eq	93b4 <fwp_hof0.constprop.0+0xb14>  // b.none
    8ae0:	51000400 	sub	w0, w0, #0x1
    8ae4:	390002a0 	strb	w0, [x21]
    8ae8:	b4003b3a 	cbz	x26, 924c <fwp_hof0.constprop.0+0x9ac>
    8aec:	aa1a03e0 	mov	x0, x26
    8af0:	d2800001 	mov	x1, #0x0                   	// #0
    8af4:	d503201f 	nop
    8af8:	f9400800 	ldr	x0, [x0, #16]
    8afc:	91000421 	add	x1, x1, #0x1
    8b00:	b5ffffc0 	cbnz	x0, 8af8 <fwp_hof0.constprop.0+0x258>
    8b04:	eb1c003f 	cmp	x1, x28
    8b08:	54000329 	b.ls	8b6c <fwp_hof0.constprop.0+0x2cc>  // b.plast
    8b0c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    8b10:	913a4000 	add	x0, x0, #0xe90
    8b14:	97ffee08 	bl	4334 <fwp_trap>
    8b18:	72003c7f 	tst	w3, #0xffff
    8b1c:	54fff4a1 	b.ne	89b0 <fwp_hof0.constprop.0+0x110>  // b.any
    8b20:	17ffff96 	b	8978 <fwp_hof0.constprop.0+0xd8>
    8b24:	72003c3f 	tst	w1, #0xffff
    8b28:	54fffb81 	b.ne	8a98 <fwp_hof0.constprop.0+0x1f8>  // b.any
    8b2c:	aa1503e0 	mov	x0, x21
    8b30:	17ffffc5 	b	8a44 <fwp_hof0.constprop.0+0x1a4>
    8b34:	d53bd040 	mrs	x0, tpidr_el0
    8b38:	91400000 	add	x0, x0, #0x0, lsl #12
    8b3c:	91004000 	add	x0, x0, #0x10
    8b40:	f9400000 	ldr	x0, [x0]
    8b44:	b4000080 	cbz	x0, 8b54 <fwp_hof0.constprop.0+0x2b4>
    8b48:	aa1303e1 	mov	x1, x19
    8b4c:	97ffef75 	bl	4920 <fwp_closure_drop_push>
    8b50:	17ffffe6 	b	8ae8 <fwp_hof0.constprop.0+0x248>
    8b54:	aa1303e0 	mov	x0, x19
    8b58:	97ffefb7 	bl	4a34 <fwp_closure_drop.part.0>
    8b5c:	17ffffe3 	b	8ae8 <fwp_hof0.constprop.0+0x248>
    8b60:	72003c3f 	tst	w1, #0xffff
    8b64:	54fffc21 	b.ne	8ae8 <fwp_hof0.constprop.0+0x248>  // b.any
    8b68:	17ffffd8 	b	8ac8 <fwp_hof0.constprop.0+0x228>
    8b6c:	aa0103f7 	mov	x23, x1
    8b70:	91014295 	add	x21, x20, #0x50
    8b74:	b943c6a0 	ldr	w0, [x21, #964]
    8b78:	34002300 	cbz	w0, 8fd8 <fwp_hof0.constprop.0+0x738>
    8b7c:	91014280 	add	x0, x20, #0x50
    8b80:	f9409003 	ldr	x3, [x0, #288]
    8b84:	f940b015 	ldr	x21, [x0, #352]
    8b88:	eb0302bf 	cmp	x21, x3
    8b8c:	540006ca 	b.ge	8c64 <fwp_hof0.constprop.0+0x3c4>  // b.tcont
    8b90:	f9404401 	ldr	x1, [x0, #136]
    8b94:	8b1506a0 	add	x0, x21, x21, lsl #1
    8b98:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    8b9c:	8b000aa0 	add	x0, x21, x0, lsl #2
    8ba0:	8b000c20 	add	x0, x1, x0, lsl #3
    8ba4:	d503201f 	nop
    8ba8:	b9400401 	ldr	w1, [x0, #4]
    8bac:	35000081 	cbnz	w1, 8bbc <fwp_hof0.constprop.0+0x31c>
    8bb0:	b9400001 	ldr	w1, [x0]
    8bb4:	6b02003f 	cmp	w1, w2
    8bb8:	54000569 	b.ls	8c64 <fwp_hof0.constprop.0+0x3c4>  // b.plast
    8bbc:	910006b5 	add	x21, x21, #0x1
    8bc0:	9101a000 	add	x0, x0, #0x68
    8bc4:	eb0302bf 	cmp	x21, x3
    8bc8:	54ffff01 	b.ne	8ba8 <fwp_hof0.constprop.0+0x308>  // b.any
    8bcc:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    8bd0:	eb00007f 	cmp	x3, x0
    8bd4:	54003dac 	b.gt	9388 <fwp_hof0.constprop.0+0xae8>
    8bd8:	91014280 	add	x0, x20, #0x50
    8bdc:	f9408801 	ldr	x1, [x0, #272]
    8be0:	f9404408 	ldr	x8, [x0, #136]
    8be4:	eb03003f 	cmp	x1, x3
    8be8:	54000261 	b.ne	8c34 <fwp_hof0.constprop.0+0x394>  // b.any
    8bec:	b40048e3 	cbz	x3, 9508 <fwp_hof0.constprop.0+0xc68>
    8bf0:	d37ff864 	lsl	x4, x3, #1
    8bf4:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8bf8:	eb00009f 	cmp	x4, x0
    8bfc:	9a80d084 	csel	x4, x4, x0, le
    8c00:	8b040481 	add	x1, x4, x4, lsl #1
    8c04:	8b010881 	add	x1, x4, x1, lsl #2
    8c08:	d37df021 	lsl	x1, x1, #3
    8c0c:	aa0803e0 	mov	x0, x8
    8c10:	52800002 	mov	w2, #0x0                   	// #0
    8c14:	a9030fe4 	stp	x4, x3, [sp, #48]
    8c18:	97ffed2b 	bl	40c4 <ad_raw_realloc>
    8c1c:	aa0003e8 	mov	x8, x0
    8c20:	a9430fe4 	ldp	x4, x3, [sp, #48]
    8c24:	b4007020 	cbz	x0, 9a28 <fwp_hof0.constprop.0+0x1188>
    8c28:	91014280 	add	x0, x20, #0x50
    8c2c:	f9004408 	str	x8, [x0, #136]
    8c30:	f9008804 	str	x4, [x0, #272]
    8c34:	8b030460 	add	x0, x3, x3, lsl #1
    8c38:	91014281 	add	x1, x20, #0x50
    8c3c:	4f000400 	movi	v0.4s, #0x0
    8c40:	91000462 	add	x2, x3, #0x1
    8c44:	8b000860 	add	x0, x3, x0, lsl #2
    8c48:	f9009022 	str	x2, [x1, #288]
    8c4c:	8b000d00 	add	x0, x8, x0, lsl #3
    8c50:	ad000000 	stp	q0, q0, [x0]
    8c54:	ad010000 	stp	q0, q0, [x0, #32]
    8c58:	ad020000 	stp	q0, q0, [x0, #64]
    8c5c:	f900301f 	str	xzr, [x0, #96]
    8c60:	14000005 	b	8c74 <fwp_hof0.constprop.0+0x3d4>
    8c64:	eb0302bf 	cmp	x21, x3
    8c68:	54fffb20 	b.eq	8bcc <fwp_hof0.constprop.0+0x32c>  // b.none
    8c6c:	91014280 	add	x0, x20, #0x50
    8c70:	f9404408 	ldr	x8, [x0, #136]
    8c74:	8b1506a3 	add	x3, x21, x21, lsl #1
    8c78:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    8c7c:	9129c000 	add	x0, x0, #0xa70
    8c80:	8b030aa3 	add	x3, x21, x3, lsl #2
    8c84:	8b030d03 	add	x3, x8, x3, lsl #3
    8c88:	a90323e3 	stp	x3, x8, [sp, #48]
    8c8c:	f900307f 	str	xzr, [x3, #96]
    8c90:	97ffe768 	bl	2a30 <getenv@plt>
    8c94:	a94323e3 	ldp	x3, x8, [sp, #48]
    8c98:	b4000080 	cbz	x0, 8ca8 <fwp_hof0.constprop.0+0x408>
    8c9c:	39400001 	ldrb	w1, [x0]
    8ca0:	7100c03f 	cmp	w1, #0x30
    8ca4:	54000820 	b.eq	8da8 <fwp_hof0.constprop.0+0x508>  // b.none
    8ca8:	91014280 	add	x0, x20, #0x50
    8cac:	f9408401 	ldr	x1, [x0, #264]
    8cb0:	b50034e1 	cbnz	x1, 934c <fwp_hof0.constprop.0+0xaac>
    8cb4:	91014280 	add	x0, x20, #0x50
    8cb8:	2f000400 	mvni	v0.2s, #0x0
    8cbc:	b9400067 	ldr	w7, [x3]
    8cc0:	910006a9 	add	x9, x21, #0x1
    8cc4:	52800022 	mov	w2, #0x1                   	// #1
    8cc8:	a900dc77 	stp	x23, x23, [x3, #8]
    8ccc:	110004e7 	add	w7, w7, #0x1
    8cd0:	f941c801 	ldr	x1, [x0, #912]
    8cd4:	29000867 	stp	w7, w2, [x3]
    8cd8:	f900287f 	str	xzr, [x3, #80]
    8cdc:	f900b009 	str	x9, [x0, #352]
    8ce0:	fd002c60 	str	d0, [x3, #88]
    8ce4:	b40032e1 	cbz	x1, 9340 <fwp_hof0.constprop.0+0xaa0>
    8ce8:	911d0304 	add	x4, x24, #0x740
    8cec:	14000003 	b	8cf8 <fwp_hof0.constprop.0+0x458>
    8cf0:	f9400021 	ldr	x1, [x1]
    8cf4:	b4003261 	cbz	x1, 9340 <fwp_hof0.constprop.0+0xaa0>
    8cf8:	f9400420 	ldr	x0, [x1, #8]
    8cfc:	eb04001f 	cmp	x0, x4
    8d00:	54ffff81 	b.ne	8cf0 <fwp_hof0.constprop.0+0x450>  // b.any
    8d04:	f9400820 	ldr	x0, [x1, #16]
    8d08:	2a1503e2 	mov	w2, w21
    8d0c:	b9400001 	ldr	w1, [x0]
    8d10:	f9002860 	str	x0, [x3, #80]
    8d14:	b9005c61 	str	w1, [x3, #92]
    8d18:	37f80081 	tbnz	w1, #31, 8d28 <fwp_hof0.constprop.0+0x488>
    8d1c:	52800d03 	mov	w3, #0x68                  	// #104
    8d20:	9b232021 	smaddl	x1, w1, w3, x8
    8d24:	b9005835 	str	w21, [x1, #88]
    8d28:	b9000002 	str	w2, [x0]
    8d2c:	aa1a03e0 	mov	x0, x26
    8d30:	d2800002 	mov	x2, #0x0                   	// #0
    8d34:	b400161a 	cbz	x26, 8ff4 <fwp_hof0.constprop.0+0x754>
    8d38:	f9400800 	ldr	x0, [x0, #16]
    8d3c:	91000442 	add	x2, x2, #0x1
    8d40:	b5ffffc0 	cbnz	x0, 8d38 <fwp_hof0.constprop.0+0x498>
    8d44:	aa1a03e1 	mov	x1, x26
    8d48:	f9400821 	ldr	x1, [x1, #16]
    8d4c:	91000400 	add	x0, x0, #0x1
    8d50:	b5ffffc1 	cbnz	x1, 8d48 <fwp_hof0.constprop.0+0x4a8>
    8d54:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8d58:	eb01001f 	cmp	x0, x1
    8d5c:	54000108 	b.hi	8d7c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    8d60:	f100005f 	cmp	x2, #0x0
    8d64:	5400148d 	b.le	8ff4 <fwp_hof0.constprop.0+0x754>
    8d68:	eb00005f 	cmp	x2, x0
    8d6c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8d70:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8d74:	eb0102ff 	cmp	x23, x1
    8d78:	540026e9 	b.ls	9254 <fwp_hof0.constprop.0+0x9b4>  // b.plast
    8d7c:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    8d80:	91364000 	add	x0, x0, #0xd90
    8d84:	97ffed6c 	bl	4334 <fwp_trap>
    8d88:	f940ac23 	ldr	x3, [x1, #344]
    8d8c:	91000463 	add	x3, x3, #0x1
    8d90:	f900ac23 	str	x3, [x1, #344]
    8d94:	17fffefe 	b	898c <fwp_hof0.constprop.0+0xec>
    8d98:	f940ac22 	ldr	x2, [x1, #344]
    8d9c:	91000442 	add	x2, x2, #0x1
    8da0:	f900ac22 	str	x2, [x1, #344]
    8da4:	17ffff2d 	b	8a58 <fwp_hof0.constprop.0+0x1b8>
    8da8:	39400400 	ldrb	w0, [x0, #1]
    8dac:	34fff840 	cbz	w0, 8cb4 <fwp_hof0.constprop.0+0x414>
    8db0:	17ffffbe 	b	8ca8 <fwp_hof0.constprop.0+0x408>
    8db4:	f9401be0 	ldr	x0, [sp, #48]
    8db8:	d00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xe4b0>
    8dbc:	910ac042 	add	x2, x2, #0x2b0
    8dc0:	aa1a03e1 	mov	x1, x26
    8dc4:	91014042 	add	x2, x2, #0x50
    8dc8:	52800023 	mov	w3, #0x1                   	// #1
    8dcc:	aa1a03f5 	mov	x21, x26
    8dd0:	aa1b03f7 	mov	x23, x27
    8dd4:	a9426ffa 	ldp	x26, x27, [sp, #32]
    8dd8:	a90c7fff 	stp	xzr, xzr, [sp, #192]
    8ddc:	f9006bff 	str	xzr, [sp, #208]
    8de0:	97fffab4 	bl	78b0 <fwp_write>
    8de4:	a94c0be3 	ldp	x3, x2, [sp, #192]
    8de8:	b0000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    8dec:	911f4000 	add	x0, x0, #0x7d0
    8df0:	f100007f 	cmp	x3, #0x0
    8df4:	9a830003 	csel	x3, x0, x3, eq	// eq = none
    8df8:	b100285f 	cmn	x2, #0xa
    8dfc:	54008fa8 	b.hi	9ff0 <fwp_hof0.constprop.0+0x1750>  // b.pmore
    8e00:	91002440 	add	x0, x2, #0x9
    8e04:	52800021 	mov	w1, #0x1                   	// #1
    8e08:	f9000be2 	str	x2, [sp, #16]
    8e0c:	f90013e3 	str	x3, [sp, #32]
    8e10:	97fff0c0 	bl	5110 <fwp_heap_alloc>
    8e14:	f94013e3 	ldr	x3, [sp, #32]
    8e18:	aa0003f9 	mov	x25, x0
    8e1c:	f9400be2 	ldr	x2, [sp, #16]
    8e20:	aa0303e1 	mov	x1, x3
    8e24:	aa0003e3 	mov	x3, x0
    8e28:	f90013e2 	str	x2, [sp, #32]
    8e2c:	f8008462 	str	x2, [x3], #8
    8e30:	aa0303e0 	mov	x0, x3
    8e34:	f9000be3 	str	x3, [sp, #16]
    8e38:	97ffe62e 	bl	26f0 <memcpy@plt>
    8e3c:	f94013e2 	ldr	x2, [sp, #32]
    8e40:	8b020322 	add	x2, x25, x2
    8e44:	3900205f 	strb	wzr, [x2, #8]
    8e48:	f94063e0 	ldr	x0, [sp, #192]
    8e4c:	97ffe6c5 	bl	2960 <free@plt>
    8e50:	9118c2c2 	add	x2, x22, #0x630
    8e54:	f9400be3 	ldr	x3, [sp, #16]
    8e58:	f949d841 	ldr	x1, [x2, #5040]
    8e5c:	f949ec40 	ldr	x0, [x2, #5080]
    8e60:	cb010321 	sub	x1, x25, x1
    8e64:	eb00403f 	cmp	x1, x0, lsl #16
    8e68:	54000322 	b.cs	8ecc <fwp_hof0.constprop.0+0x62c>  // b.hs, b.nlast
    8e6c:	d350fc20 	lsr	x0, x1, #16
    8e70:	f949fc45 	ldr	x5, [x2, #5112]
    8e74:	8b000800 	add	x0, x0, x0, lsl #2
    8e78:	d37df002 	lsl	x2, x0, #3
    8e7c:	8b0200a4 	add	x4, x5, x2
    8e80:	f9401080 	ldr	x0, [x4, #32]
    8e84:	b4000240 	cbz	x0, 8ecc <fwp_hof0.constprop.0+0x62c>
    8e88:	386268a2 	ldrb	w2, [x5, x2]
    8e8c:	7100085f 	cmp	w2, #0x2
    8e90:	54008c20 	b.eq	a014 <fwp_hof0.constprop.0+0x1774>  // b.none
    8e94:	7100045f 	cmp	w2, #0x1
    8e98:	540001a1 	b.ne	8ecc <fwp_hof0.constprop.0+0x62c>  // b.any
    8e9c:	29430885 	ldp	w5, w2, [x4, #24]
    8ea0:	92403c21 	and	x1, x1, #0xffff
    8ea4:	9b057c21 	mul	x1, x1, x5
    8ea8:	d360fc21 	lsr	x1, x1, #32
    8eac:	eb02003f 	cmp	x1, x2
    8eb0:	540000e2 	b.cs	8ecc <fwp_hof0.constprop.0+0x62c>  // b.hs, b.nlast
    8eb4:	8b010000 	add	x0, x0, x1
    8eb8:	39400001 	ldrb	w1, [x0]
    8ebc:	7103fc3f 	cmp	w1, #0xff
    8ec0:	54008b00 	b.eq	a020 <fwp_hof0.constprop.0+0x1780>  // b.none
    8ec4:	52800021 	mov	w1, #0x1                   	// #1
    8ec8:	39000001 	strb	w1, [x0]
    8ecc:	aa1503e0 	mov	x0, x21
    8ed0:	f9000be3 	str	x3, [sp, #16]
    8ed4:	97fff477 	bl	60b0 <fwp_drop0>
    8ed8:	91014295 	add	x21, x20, #0x50
    8edc:	f9400be3 	ldr	x3, [sp, #16]
    8ee0:	d2800021 	mov	x1, #0x1                   	// #1
    8ee4:	f9400322 	ldr	x2, [x25]
    8ee8:	aa0303e0 	mov	x0, x3
    8eec:	f9404aa3 	ldr	x3, [x21, #144]
    8ef0:	97ffe6ac 	bl	29a0 <fwrite@plt>
    8ef4:	f9404aa1 	ldr	x1, [x21, #144]
    8ef8:	52800140 	mov	w0, #0xa                   	// #10
    8efc:	97ffe631 	bl	27c0 <fputc@plt>
    8f00:	9118c2c2 	add	x2, x22, #0x630
    8f04:	f949d841 	ldr	x1, [x2, #5040]
    8f08:	f949ec40 	ldr	x0, [x2, #5080]
    8f0c:	cb010321 	sub	x1, x25, x1
    8f10:	eb00403f 	cmp	x1, x0, lsl #16
    8f14:	54000382 	b.cs	8f84 <fwp_hof0.constprop.0+0x6e4>  // b.hs, b.nlast
    8f18:	d350fc20 	lsr	x0, x1, #16
    8f1c:	f949fc44 	ldr	x4, [x2, #5112]
    8f20:	8b000800 	add	x0, x0, x0, lsl #2
    8f24:	d37df002 	lsl	x2, x0, #3
    8f28:	8b020083 	add	x3, x4, x2
    8f2c:	f9401075 	ldr	x21, [x3, #32]
    8f30:	b40002b5 	cbz	x21, 8f84 <fwp_hof0.constprop.0+0x6e4>
    8f34:	38626882 	ldrb	w2, [x4, x2]
    8f38:	7100085f 	cmp	w2, #0x2
    8f3c:	54008660 	b.eq	a008 <fwp_hof0.constprop.0+0x1768>  // b.none
    8f40:	7100045f 	cmp	w2, #0x1
    8f44:	54000201 	b.ne	8f84 <fwp_hof0.constprop.0+0x6e4>  // b.any
    8f48:	29430062 	ldp	w2, w0, [x3, #24]
    8f4c:	92403c21 	and	x1, x1, #0xffff
    8f50:	9b027c21 	mul	x1, x1, x2
    8f54:	d360fc21 	lsr	x1, x1, #32
    8f58:	eb00003f 	cmp	x1, x0
    8f5c:	54000142 	b.cs	8f84 <fwp_hof0.constprop.0+0x6e4>  // b.hs, b.nlast
    8f60:	8b0102b5 	add	x21, x21, x1
    8f64:	394002a1 	ldrb	w1, [x21]
    8f68:	340000e1 	cbz	w1, 8f84 <fwp_hof0.constprop.0+0x6e4>
    8f6c:	7100043f 	cmp	w1, #0x1
    8f70:	54008460 	b.eq	9ffc <fwp_hof0.constprop.0+0x175c>  // b.none
    8f74:	7103fc3f 	cmp	w1, #0xff
    8f78:	54008600 	b.eq	a038 <fwp_hof0.constprop.0+0x1798>  // b.none
    8f7c:	51000421 	sub	w1, w1, #0x1
    8f80:	390002a1 	strb	w1, [x21]
    8f84:	f9400fe0 	ldr	x0, [sp, #24]
    8f88:	f9400800 	ldr	x0, [x0, #16]
    8f8c:	f9000fe0 	str	x0, [sp, #24]
    8f90:	b5ffcc20 	cbnz	x0, 8914 <fwp_hof0.constprop.0+0x74>
    8f94:	a95253f3 	ldp	x19, x20, [sp, #288]
    8f98:	a9535bf5 	ldp	x21, x22, [sp, #304]
    8f9c:	a95463f7 	ldp	x23, x24, [sp, #320]
    8fa0:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8fa4:	d503201f 	nop
    8fa8:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    8fac:	f947f400 	ldr	x0, [x0, #4072]
    8fb0:	f94087e2 	ldr	x2, [sp, #264]
    8fb4:	f9400001 	ldr	x1, [x0]
    8fb8:	eb010042 	subs	x2, x2, x1
    8fbc:	d2800001 	mov	x1, #0x0                   	// #0
    8fc0:	54009a21 	b.ne	a304 <fwp_hof0.constprop.0+0x1a64>  // b.any
    8fc4:	a9517bfd 	ldp	x29, x30, [sp, #272]
    8fc8:	d2800000 	mov	x0, #0x0                   	// #0
    8fcc:	a95673fb 	ldp	x27, x28, [sp, #352]
    8fd0:	9105c3ff 	add	sp, sp, #0x170
    8fd4:	d65f03c0 	ret
    8fd8:	d0ffffe0 	adrp	x0, 6000 <e173+0x6c>
    8fdc:	9118c000 	add	x0, x0, #0x630
    8fe0:	940011e0 	bl	d760 <atexit>
    8fe4:	35005220 	cbnz	w0, 9a28 <fwp_hof0.constprop.0+0x1188>
    8fe8:	52800020 	mov	w0, #0x1                   	// #1
    8fec:	b903c6a0 	str	w0, [x21, #964]
    8ff0:	17fffee3 	b	8b7c <fwp_hof0.constprop.0+0x2dc>
    8ff4:	d3707ce7 	ubfiz	x7, x7, #16, #32
    8ff8:	52800041 	mov	w1, #0x2                   	// #2
    8ffc:	aa0900e0 	orr	x0, x7, x9
    9000:	f9001be0 	str	x0, [sp, #48]
    9004:	d2800100 	mov	x0, #0x8                   	// #8
    9008:	97fff042 	bl	5110 <fwp_heap_alloc>
    900c:	aa0003e9 	mov	x9, x0
    9010:	9118c2c0 	add	x0, x22, #0x630
    9014:	aa0903ea 	mov	x10, x9
    9018:	f900013f 	str	xzr, [x9]
    901c:	f949d801 	ldr	x1, [x0, #5040]
    9020:	f949ec00 	ldr	x0, [x0, #5080]
    9024:	cb010121 	sub	x1, x9, x1
    9028:	eb00403f 	cmp	x1, x0, lsl #16
    902c:	540013c2 	b.cs	92a4 <fwp_hof0.constprop.0+0xa04>  // b.hs, b.nlast
    9030:	d2800017 	mov	x23, #0x0                   	// #0
    9034:	9118c2c2 	add	x2, x22, #0x630
    9038:	d350fc20 	lsr	x0, x1, #16
    903c:	8b000800 	add	x0, x0, x0, lsl #2
    9040:	f949fc44 	ldr	x4, [x2, #5112]
    9044:	d37df002 	lsl	x2, x0, #3
    9048:	8b020083 	add	x3, x4, x2
    904c:	f9401075 	ldr	x21, [x3, #32]
    9050:	b4000255 	cbz	x21, 9098 <fwp_hof0.constprop.0+0x7f8>
    9054:	38626882 	ldrb	w2, [x4, x2]
    9058:	7100085f 	cmp	w2, #0x2
    905c:	540012a0 	b.eq	92b0 <fwp_hof0.constprop.0+0xa10>  // b.none
    9060:	7100045f 	cmp	w2, #0x1
    9064:	540001a1 	b.ne	9098 <fwp_hof0.constprop.0+0x7f8>  // b.any
    9068:	29430864 	ldp	w4, w2, [x3, #24]
    906c:	92403c21 	and	x1, x1, #0xffff
    9070:	9b047c21 	mul	x1, x1, x4
    9074:	d360fc21 	lsr	x1, x1, #32
    9078:	eb02003f 	cmp	x1, x2
    907c:	540000e2 	b.cs	9098 <fwp_hof0.constprop.0+0x7f8>  // b.hs, b.nlast
    9080:	8b0102b5 	add	x21, x21, x1
    9084:	394002a1 	ldrb	w1, [x21]
    9088:	7103fc3f 	cmp	w1, #0xff
    908c:	54004a60 	b.eq	99d8 <fwp_hof0.constprop.0+0x1138>  // b.none
    9090:	52800021 	mov	w1, #0x1                   	// #1
    9094:	390002a1 	strb	w1, [x21]
    9098:	b4000257 	cbz	x23, 90e0 <fwp_hof0.constprop.0+0x840>
    909c:	f9401be0 	ldr	x0, [sp, #48]
    90a0:	aa1a03e2 	mov	x2, x26
    90a4:	f9400748 	ldr	x8, [x26, #8]
    90a8:	91002123 	add	x3, x9, #0x8
    90ac:	d3607c07 	lsl	x7, x0, #32
    90b0:	d2800001 	mov	x1, #0x0                   	// #0
    90b4:	aa0703e4 	mov	x4, x7
    90b8:	14000005 	b	90cc <fwp_hof0.constprop.0+0x82c>
    90bc:	f9400448 	ldr	x8, [x2, #8]
    90c0:	ab070024 	adds	x4, x1, x7
    90c4:	91004063 	add	x3, x3, #0x10
    90c8:	54009b26 	b.vs	a42c <fwp_hof0.constprop.0+0x1b8c>
    90cc:	a9001068 	stp	x8, x4, [x3]
    90d0:	91000421 	add	x1, x1, #0x1
    90d4:	f9400842 	ldr	x2, [x2, #16]
    90d8:	eb17003f 	cmp	x1, x23
    90dc:	54ffff03 	b.cc	90bc <fwp_hof0.constprop.0+0x81c>  // b.lo, b.ul, b.last
    90e0:	f9400120 	ldr	x0, [x9]
    90e4:	f100041f 	cmp	x0, #0x1
    90e8:	54000de9 	b.ls	92a4 <fwp_hof0.constprop.0+0xa04>  // b.plast
    90ec:	d341fc17 	lsr	x23, x0, #1
    90f0:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    90f4:	d10006e0 	sub	x0, x23, #0x1
    90f8:	eb01001f 	cmp	x0, x1
    90fc:	54ffe408 	b.hi	8d7c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    9100:	b4000d20 	cbz	x0, 92a4 <fwp_hof0.constprop.0+0xa04>
    9104:	91002135 	add	x21, x9, #0x8
    9108:	d1002121 	sub	x1, x9, #0x8
    910c:	8b171037 	add	x23, x1, x23, lsl #4
    9110:	a903cfea 	stp	x10, x19, [sp, #56]
    9114:	aa1503f3 	mov	x19, x21
    9118:	aa0003f5 	mov	x21, x0
    911c:	f90027e9 	str	x9, [sp, #72]
    9120:	f9400660 	ldr	x0, [x19, #8]
    9124:	f9400e61 	ldr	x1, [x19, #24]
    9128:	fd400260 	ldr	d0, [x19]
    912c:	fd400a61 	ldr	d1, [x19, #16]
    9130:	97fff19d 	bl	57a4 <w120>
    9134:	a9000660 	stp	x0, x1, [x19]
    9138:	91004273 	add	x19, x19, #0x10
    913c:	eb17027f 	cmp	x19, x23
    9140:	54ffff01 	b.ne	9120 <fwp_hof0.constprop.0+0x880>  // b.any
    9144:	a94427f3 	ldp	x19, x9, [sp, #64]
    9148:	d37ffaa1 	lsl	x1, x21, #1
    914c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    9150:	d2800015 	mov	x21, #0x0                   	// #0
    9154:	aa1703e0 	mov	x0, x23
    9158:	aa1503f7 	mov	x23, x21
    915c:	aa0103f5 	mov	x21, x1
    9160:	a90467e9 	stp	x9, x25, [sp, #64]
    9164:	aa0903e2 	mov	x2, x9
    9168:	aa1303f9 	mov	x25, x19
    916c:	f8010441 	str	x1, [x2], #16
    9170:	aa0203f3 	mov	x19, x2
    9174:	d503201f 	nop
    9178:	f8777a61 	ldr	x1, [x19, x23, lsl #3]
    917c:	91000af7 	add	x23, x23, #0x2
    9180:	97fff138 	bl	5660 <f141.constprop.0>
    9184:	eb1502ff 	cmp	x23, x21
    9188:	54ffff83 	b.cc	9178 <fwp_hof0.constprop.0+0x8d8>  // b.lo, b.ul, b.last
    918c:	a943a7ea 	ldp	x10, x9, [sp, #56]
    9190:	aa1903f3 	mov	x19, x25
    9194:	f94027f9 	ldr	x25, [sp, #72]
    9198:	aa0003f7 	mov	x23, x0
    919c:	9118c2c3 	add	x3, x22, #0x630
    91a0:	aa0303f5 	mov	x21, x3
    91a4:	f949d861 	ldr	x1, [x3, #5040]
    91a8:	f949ec60 	ldr	x0, [x3, #5080]
    91ac:	cb010121 	sub	x1, x9, x1
    91b0:	eb00403f 	cmp	x1, x0, lsl #16
    91b4:	540003a2 	b.cs	9228 <fwp_hof0.constprop.0+0x988>  // b.hs, b.nlast
    91b8:	d350fc20 	lsr	x0, x1, #16
    91bc:	f949fea4 	ldr	x4, [x21, #5112]
    91c0:	8b000800 	add	x0, x0, x0, lsl #2
    91c4:	d37df002 	lsl	x2, x0, #3
    91c8:	8b020083 	add	x3, x4, x2
    91cc:	f9401060 	ldr	x0, [x3, #32]
    91d0:	b40002c0 	cbz	x0, 9228 <fwp_hof0.constprop.0+0x988>
    91d4:	38626882 	ldrb	w2, [x4, x2]
    91d8:	7100085f 	cmp	w2, #0x2
    91dc:	540019c0 	b.eq	9514 <fwp_hof0.constprop.0+0xc74>  // b.none
    91e0:	7100045f 	cmp	w2, #0x1
    91e4:	54000221 	b.ne	9228 <fwp_hof0.constprop.0+0x988>  // b.any
    91e8:	29430865 	ldp	w5, w2, [x3, #24]
    91ec:	92403c21 	and	x1, x1, #0xffff
    91f0:	9b057c21 	mul	x1, x1, x5
    91f4:	d360fc21 	lsr	x1, x1, #32
    91f8:	eb02003f 	cmp	x1, x2
    91fc:	54000162 	b.cs	9228 <fwp_hof0.constprop.0+0x988>  // b.hs, b.nlast
    9200:	8b010000 	add	x0, x0, x1
    9204:	39400001 	ldrb	w1, [x0]
    9208:	34000101 	cbz	w1, 9228 <fwp_hof0.constprop.0+0x988>
    920c:	7100043f 	cmp	w1, #0x1
    9210:	54000560 	b.eq	92bc <fwp_hof0.constprop.0+0xa1c>  // b.none
    9214:	7103fc3f 	cmp	w1, #0xff
    9218:	54004200 	b.eq	9a58 <fwp_hof0.constprop.0+0x11b8>  // b.none
    921c:	51000421 	sub	w1, w1, #0x1
    9220:	39000001 	strb	w1, [x0]
    9224:	d503201f 	nop
    9228:	b98033f5 	ldrsw	x21, [sp, #48]
    922c:	aa1503e0 	mov	x0, x21
    9230:	97ffee44 	bl	4b40 <fwp_tape_of>
    9234:	f9403002 	ldr	x2, [x0, #96]
    9238:	aa0003e7 	mov	x7, x0
    923c:	b4000f42 	cbz	x2, 9424 <fwp_hof0.constprop.0+0xb84>
    9240:	90000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    9244:	91340000 	add	x0, x0, #0xd00
    9248:	97ffec3b 	bl	4334 <fwp_trap>
    924c:	d2800017 	mov	x23, #0x0                   	// #0
    9250:	17fffe48 	b	8b70 <fwp_hof0.constprop.0+0x2d0>
    9254:	d37ffae2 	lsl	x2, x23, #1
    9258:	d3707ce7 	ubfiz	x7, x7, #16, #32
    925c:	91000440 	add	x0, x2, #0x1
    9260:	aa0900e1 	orr	x1, x7, x9
    9264:	aa0203f5 	mov	x21, x2
    9268:	f9001be1 	str	x1, [sp, #48]
    926c:	d37df000 	lsl	x0, x0, #3
    9270:	52800041 	mov	w1, #0x2                   	// #2
    9274:	97ffefa7 	bl	5110 <fwp_heap_alloc>
    9278:	aa0003e9 	mov	x9, x0
    927c:	9118c2c1 	add	x1, x22, #0x630
    9280:	aa0003ea 	mov	x10, x0
    9284:	aa0103e0 	mov	x0, x1
    9288:	f9000135 	str	x21, [x9]
    928c:	f949d821 	ldr	x1, [x1, #5040]
    9290:	f949ec00 	ldr	x0, [x0, #5080]
    9294:	cb010121 	sub	x1, x9, x1
    9298:	eb00403f 	cmp	x1, x0, lsl #16
    929c:	54ffecc3 	b.cc	9034 <fwp_hof0.constprop.0+0x794>  // b.lo, b.ul, b.last
    92a0:	b5ffeff7 	cbnz	x23, 909c <fwp_hof0.constprop.0+0x7fc>
    92a4:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    92a8:	f900013f 	str	xzr, [x9]
    92ac:	17ffffbc 	b	919c <fwp_hof0.constprop.0+0x8fc>
    92b0:	72003c3f 	tst	w1, #0xffff
    92b4:	54ffef21 	b.ne	9098 <fwp_hof0.constprop.0+0x7f8>  // b.any
    92b8:	17ffff73 	b	9084 <fwp_hof0.constprop.0+0x7e4>
    92bc:	f9400143 	ldr	x3, [x10]
    92c0:	aa0a03e5 	mov	x5, x10
    92c4:	f949eea2 	ldr	x2, [x21, #5080]
    92c8:	f949daa1 	ldr	x1, [x21, #5040]
    92cc:	d370bc47 	lsl	x7, x2, #16
    92d0:	cb010140 	sub	x0, x10, x1
    92d4:	b7f81263 	tbnz	x3, #63, 9520 <fwp_hof0.constprop.0+0xc80>
    92d8:	eb0000ff 	cmp	x7, x0
    92dc:	54fffa69 	b.ls	9228 <fwp_hof0.constprop.0+0x988>  // b.plast
    92e0:	d350fc01 	lsr	x1, x0, #16
    92e4:	8b010821 	add	x1, x1, x1, lsl #2
    92e8:	d37df021 	lsl	x1, x1, #3
    92ec:	8b010083 	add	x3, x4, x1
    92f0:	f9401062 	ldr	x2, [x3, #32]
    92f4:	b4fff9a2 	cbz	x2, 9228 <fwp_hof0.constprop.0+0x988>
    92f8:	38616881 	ldrb	w1, [x4, x1]
    92fc:	7100083f 	cmp	w1, #0x2
    9300:	54003560 	b.eq	99ac <fwp_hof0.constprop.0+0x110c>  // b.none
    9304:	7100043f 	cmp	w1, #0x1
    9308:	54fff901 	b.ne	9228 <fwp_hof0.constprop.0+0x988>  // b.any
    930c:	29430464 	ldp	w4, w1, [x3, #24]
    9310:	92403c00 	and	x0, x0, #0xffff
    9314:	9b047c00 	mul	x0, x0, x4
    9318:	d360fc00 	lsr	x0, x0, #32
    931c:	eb01001f 	cmp	x0, x1
    9320:	54fff842 	b.cs	9228 <fwp_hof0.constprop.0+0x988>  // b.hs, b.nlast
    9324:	8b000042 	add	x2, x2, x0
    9328:	39400040 	ldrb	w0, [x2]
    932c:	7100041f 	cmp	w0, #0x1
    9330:	54fff7c1 	b.ne	9228 <fwp_hof0.constprop.0+0x988>  // b.any
    9334:	aa0a03e0 	mov	x0, x10
    9338:	97ffecba 	bl	4620 <fwp_mem_free>
    933c:	17ffffbb 	b	9228 <fwp_hof0.constprop.0+0x988>
    9340:	90000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    9344:	913d4000 	add	x0, x0, #0xf50
    9348:	97ffebfb 	bl	4334 <fwp_trap>
    934c:	ad468402 	ldp	q2, q1, [x0, #208]
    9350:	91034001 	add	x1, x0, #0xd0
    9354:	4f000400 	movi	v0.4s, #0x0
    9358:	f900841f 	str	xzr, [x0, #264]
    935c:	ad010462 	stp	q2, q1, [x3, #32]
    9360:	f9408000 	ldr	x0, [x0, #256]
    9364:	f9002460 	str	x0, [x3, #72]
    9368:	f9401020 	ldr	x0, [x1, #32]
    936c:	f9002060 	str	x0, [x3, #64]
    9370:	f9401420 	ldr	x0, [x1, #40]
    9374:	f9000c60 	str	x0, [x3, #24]
    9378:	f900183f 	str	xzr, [x1, #48]
    937c:	ad000020 	stp	q0, q0, [x1]
    9380:	3d800820 	str	q0, [x1, #32]
    9384:	17fffe4c 	b	8cb4 <fwp_hof0.constprop.0+0x414>
    9388:	90000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    938c:	913ac000 	add	x0, x0, #0xeb0
    9390:	97ffebe9 	bl	4334 <fwp_trap>
    9394:	97ffed1c 	bl	4804 <fwp_rc_wide_dup>
    9398:	9118c2c0 	add	x0, x22, #0x630
    939c:	f949ec04 	ldr	x4, [x0, #5080]
    93a0:	f949d801 	ldr	x1, [x0, #5040]
    93a4:	d370bc84 	lsl	x4, x4, #16
    93a8:	17fffd82 	b	89b0 <fwp_hof0.constprop.0+0x110>
    93ac:	97ffed16 	bl	4804 <fwp_rc_wide_dup>
    93b0:	17fffdae 	b	8a68 <fwp_hof0.constprop.0+0x1c8>
    93b4:	ca5546a0 	eor	x0, x21, x21, lsr #17
    93b8:	9118c2c1 	add	x1, x22, #0x630
    93bc:	ca402400 	eor	x0, x0, x0, lsr #9
    93c0:	92401c00 	and	x0, x0, #0xff
    93c4:	910a2402 	add	x2, x0, #0x289
    93c8:	8b000c20 	add	x0, x1, x0, lsl #3
    93cc:	8b020c22 	add	x2, x1, x2, lsl #3
    93d0:	f94a2400 	ldr	x0, [x0, #5192]
    93d4:	b50000a0 	cbnz	x0, 93e8 <fwp_hof0.constprop.0+0xb48>
    93d8:	14000178 	b	99b8 <fwp_hof0.constprop.0+0x1118>
    93dc:	91004002 	add	x2, x0, #0x10
    93e0:	f9400800 	ldr	x0, [x0, #16]
    93e4:	b4002ea0 	cbz	x0, 99b8 <fwp_hof0.constprop.0+0x1118>
    93e8:	f9400001 	ldr	x1, [x0]
    93ec:	eb15003f 	cmp	x1, x21
    93f0:	54ffff61 	b.ne	93dc <fwp_hof0.constprop.0+0xb3c>  // b.any
    93f4:	f9400041 	ldr	x1, [x2]
    93f8:	f9400420 	ldr	x0, [x1, #8]
    93fc:	d1000400 	sub	x0, x0, #0x1
    9400:	f9000420 	str	x0, [x1, #8]
    9404:	f103f81f 	cmp	x0, #0xfe
    9408:	54ffb701 	b.ne	8ae8 <fwp_hof0.constprop.0+0x248>  // b.any
    940c:	394002a0 	ldrb	w0, [x21]
    9410:	7103fc1f 	cmp	w0, #0xff
    9414:	54002f20 	b.eq	99f8 <fwp_hof0.constprop.0+0x1158>  // b.none
    9418:	12800020 	mov	w0, #0xfffffffe            	// #-2
    941c:	390002a0 	strb	w0, [x21]
    9420:	17fffdb2 	b	8ae8 <fwp_hof0.constprop.0+0x248>
    9424:	97ffe6fc 	bl	3014 <fwp_tape_unlink_scope>
    9428:	b90004ff 	str	wzr, [x7, #4]
    942c:	a94190e2 	ldp	x2, x4, [x7, #24]
    9430:	f9001fe4 	str	x4, [sp, #56]
    9434:	f94014e4 	ldr	x4, [x7, #40]
    9438:	f90023e4 	str	x4, [sp, #64]
    943c:	f94018e4 	ldr	x4, [x7, #48]
    9440:	f90027e4 	str	x4, [sp, #72]
    9444:	f9401ce4 	ldr	x4, [x7, #56]
    9448:	f9002be4 	str	x4, [sp, #80]
    944c:	b94000e1 	ldr	w1, [x7]
    9450:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    9454:	a9408ce8 	ldp	x8, x3, [x7, #8]
    9458:	f94020e4 	ldr	x4, [x7, #64]
    945c:	f94024e9 	ldr	x9, [x7, #72]
    9460:	6b00003f 	cmp	w1, w0
    9464:	54000108 	b.hi	9484 <fwp_hof0.constprop.0+0xbe4>  // b.pmore
    9468:	91014281 	add	x1, x20, #0x50
    946c:	92403ea0 	and	x0, x21, #0xffff
    9470:	d1000400 	sub	x0, x0, #0x1
    9474:	f940b02a 	ldr	x10, [x1, #352]
    9478:	eb0a001f 	cmp	x0, x10
    947c:	5400004a 	b.ge	9484 <fwp_hof0.constprop.0+0xbe4>  // b.tcont
    9480:	f900b020 	str	x0, [x1, #352]
    9484:	4f000400 	movi	v0.4s, #0x0
    9488:	f9000cff 	str	xzr, [x7, #24]
    948c:	f9401fe0 	ldr	x0, [sp, #56]
    9490:	a9047cff 	stp	xzr, xzr, [x7, #64]
    9494:	91014281 	add	x1, x20, #0x50
    9498:	3c8080e0 	stur	q0, [x7, #8]
    949c:	9102a3e5 	add	x5, sp, #0xa8
    94a0:	ad0100e0 	stp	q0, q0, [x7, #32]
    94a4:	f90063e0 	str	x0, [sp, #192]
    94a8:	f94023e0 	ldr	x0, [sp, #64]
    94ac:	f90067e0 	str	x0, [sp, #200]
    94b0:	f94027e0 	ldr	x0, [sp, #72]
    94b4:	f9006be0 	str	x0, [sp, #208]
    94b8:	f9402be0 	ldr	x0, [sp, #80]
    94bc:	f9006fe0 	str	x0, [sp, #216]
    94c0:	f941c820 	ldr	x0, [x1, #912]
    94c4:	f90057e0 	str	x0, [sp, #168]
    94c8:	f0ffffc0 	adrp	x0, 4000 <ad_raw_free.part.0+0x10>
    94cc:	91065000 	add	x0, x0, #0x194
    94d0:	f9002fe5 	str	x5, [sp, #88]
    94d4:	f9005be0 	str	x0, [sp, #176]
    94d8:	910303e0 	add	x0, sp, #0xc0
    94dc:	f9001be0 	str	x0, [sp, #48]
    94e0:	f9005fe0 	str	x0, [sp, #184]
    94e4:	a90e0be4 	stp	x4, x2, [sp, #224]
    94e8:	f9007be9 	str	x9, [sp, #240]
    94ec:	f901c825 	str	x5, [x1, #912]
    94f0:	b7f826b7 	tbnz	x23, #63, 99c4 <fwp_hof0.constprop.0+0x1124>
    94f4:	eb9782bf 	cmp	x21, x23, asr #32
    94f8:	540005c0 	b.eq	95b0 <fwp_hof0.constprop.0+0xd10>  // b.none
    94fc:	90000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    9500:	9132e000 	add	x0, x0, #0xcb8
    9504:	97ffeb8c 	bl	4334 <fwp_trap>
    9508:	d2800d01 	mov	x1, #0x68                  	// #104
    950c:	d2800024 	mov	x4, #0x1                   	// #1
    9510:	17fffdbf 	b	8c0c <fwp_hof0.constprop.0+0x36c>
    9514:	72003c3f 	tst	w1, #0xffff
    9518:	54ffe881 	b.ne	9228 <fwp_hof0.constprop.0+0x988>  // b.any
    951c:	17ffff3a 	b	9204 <fwp_hof0.constprop.0+0x964>
    9520:	f940054a 	ldr	x10, [x10, #8]
    9524:	eb0000ff 	cmp	x7, x0
    9528:	540003c9 	b.ls	95a0 <fwp_hof0.constprop.0+0xd00>  // b.plast
    952c:	d350fc02 	lsr	x2, x0, #16
    9530:	8b020842 	add	x2, x2, x2, lsl #2
    9534:	d37df042 	lsl	x2, x2, #3
    9538:	8b020086 	add	x6, x4, x2
    953c:	f94010c3 	ldr	x3, [x6, #32]
    9540:	b4000303 	cbz	x3, 95a0 <fwp_hof0.constprop.0+0xd00>
    9544:	38626882 	ldrb	w2, [x4, x2]
    9548:	7100085f 	cmp	w2, #0x2
    954c:	54002500 	b.eq	99ec <fwp_hof0.constprop.0+0x114c>  // b.none
    9550:	7100045f 	cmp	w2, #0x1
    9554:	54000261 	b.ne	95a0 <fwp_hof0.constprop.0+0xd00>  // b.any
    9558:	92403c02 	and	x2, x0, #0xffff
    955c:	294300c4 	ldp	w4, w0, [x6, #24]
    9560:	9b047c42 	mul	x2, x2, x4
    9564:	d360fc42 	lsr	x2, x2, #32
    9568:	eb00005f 	cmp	x2, x0
    956c:	540001a2 	b.cs	95a0 <fwp_hof0.constprop.0+0xd00>  // b.hs, b.nlast
    9570:	8b020063 	add	x3, x3, x2
    9574:	39400060 	ldrb	w0, [x3]
    9578:	7100041f 	cmp	w0, #0x1
    957c:	54000121 	b.ne	95a0 <fwp_hof0.constprop.0+0xd00>  // b.any
    9580:	aa0503e0 	mov	x0, x5
    9584:	f9001fea 	str	x10, [sp, #56]
    9588:	97ffec26 	bl	4620 <fwp_mem_free>
    958c:	9118c2c0 	add	x0, x22, #0x630
    9590:	f9401fea 	ldr	x10, [sp, #56]
    9594:	f949ec02 	ldr	x2, [x0, #5080]
    9598:	f949d801 	ldr	x1, [x0, #5040]
    959c:	d370bc47 	lsl	x7, x2, #16
    95a0:	cb010141 	sub	x1, x10, x1
    95a4:	eb07003f 	cmp	x1, x7
    95a8:	54ffe083 	b.cc	91b8 <fwp_hof0.constprop.0+0x918>  // b.lo, b.ul, b.last
    95ac:	17ffff1f 	b	9228 <fwp_hof0.constprop.0+0x988>
    95b0:	92407ee0 	and	x0, x23, #0xffffffff
    95b4:	eb37407f 	cmp	x3, w23, uxtw
    95b8:	540020ad 	b.le	99cc <fwp_hof0.constprop.0+0x112c>
    95bc:	eb08001f 	cmp	x0, x8
    95c0:	9a80b515 	csinc	x21, x8, x0, lt	// lt = tstop
    95c4:	eb15013f 	cmp	x9, x21
    95c8:	5400220a 	b.ge	9a08 <fwp_hof0.constprop.0+0x1168>  // b.tcont
    95cc:	f100013f 	cmp	x9, #0x0
    95d0:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    95d4:	9a951129 	csel	x9, x9, x21, ne	// ne = any
    95d8:	14000004 	b	95e8 <fwp_hof0.constprop.0+0xd48>
    95dc:	eb02013f 	cmp	x9, x2
    95e0:	d37ff929 	lsl	x9, x9, #1
    95e4:	9a95d129 	csel	x9, x9, x21, le
    95e8:	eb15013f 	cmp	x9, x21
    95ec:	54ffff8b 	b.lt	95dc <fwp_hof0.constprop.0+0xd3c>  // b.tstop
    95f0:	b4005984 	cbz	x4, a120 <fwp_hof0.constprop.0+0x1880>
    95f4:	aa0403e0 	mov	x0, x4
    95f8:	d37df121 	lsl	x1, x9, #3
    95fc:	52800062 	mov	w2, #0x3                   	// #3
    9600:	a90623e9 	stp	x9, x8, [sp, #96]
    9604:	97ffeab0 	bl	40c4 <ad_raw_realloc>
    9608:	a94623e9 	ldp	x9, x8, [sp, #96]
    960c:	aa0003e4 	mov	x4, x0
    9610:	b4001fa0 	cbz	x0, 9a04 <fwp_hof0.constprop.0+0x1164>
    9614:	f90073e4 	str	x4, [sp, #224]
    9618:	f9007be9 	str	x9, [sp, #240]
    961c:	b5001b95 	cbnz	x21, 998c <fwp_hof0.constprop.0+0x10ec>
    9620:	b7f800d7 	tbnz	x23, #63, 9638 <fwp_hof0.constprop.0+0xd98>
    9624:	92407ef7 	and	x23, x23, #0xffffffff
    9628:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    962c:	fc777880 	ldr	d0, [x4, x23, lsl #3]
    9630:	1e612800 	fadd	d0, d0, d1
    9634:	fc377880 	str	d0, [x4, x23, lsl #3]
    9638:	d10006a0 	sub	x0, x21, #0x1
    963c:	d1000503 	sub	x3, x8, #0x1
    9640:	eb00011f 	cmp	x8, x0
    9644:	5400042c 	b.gt	96c8 <fwp_hof0.constprop.0+0xe28>
    9648:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    964c:	1e602008 	fcmp	d0, #0.0
    9650:	54000360 	b.eq	96bc <fwp_hof0.constprop.0+0xe1c>  // b.none
    9654:	f9401fe2 	ldr	x2, [sp, #56]
    9658:	cb080be1 	neg	x1, x8, lsl #2
    965c:	cb0803e5 	neg	x5, x8
    9660:	8b010042 	add	x2, x2, x1
    9664:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    9668:	37f80122 	tbnz	w2, #31, 968c <fwp_hof0.constprop.0+0xdec>
    966c:	f94027e6 	ldr	x6, [sp, #72]
    9670:	93407c42 	sxtw	x2, w2
    9674:	8b050cc6 	add	x6, x6, x5, lsl #3
    9678:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    967c:	fc6078c2 	ldr	d2, [x6, x0, lsl #3]
    9680:	1e620802 	fmul	d2, d0, d2
    9684:	1e622821 	fadd	d1, d1, d2
    9688:	fc227881 	str	d1, [x4, x2, lsl #3]
    968c:	f94023e2 	ldr	x2, [sp, #64]
    9690:	8b010041 	add	x1, x2, x1
    9694:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    9698:	37f80121 	tbnz	w1, #31, 96bc <fwp_hof0.constprop.0+0xe1c>
    969c:	f9402be2 	ldr	x2, [sp, #80]
    96a0:	93407c21 	sxtw	x1, w1
    96a4:	8b050c45 	add	x5, x2, x5, lsl #3
    96a8:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    96ac:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    96b0:	1e620800 	fmul	d0, d0, d2
    96b4:	1e602820 	fadd	d0, d1, d0
    96b8:	fc217880 	str	d0, [x4, x1, lsl #3]
    96bc:	d1000400 	sub	x0, x0, #0x1
    96c0:	eb03001f 	cmp	x0, x3
    96c4:	54fffc21 	b.ne	9648 <fwp_hof0.constprop.0+0xda8>  // b.any
    96c8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    96cc:	eb00011f 	cmp	x8, x0
    96d0:	54001fc8 	b.hi	9ac8 <fwp_hof0.constprop.0+0x1228>  // b.pmore
    96d4:	91000500 	add	x0, x8, #0x1
    96d8:	52800041 	mov	w1, #0x2                   	// #2
    96dc:	a90393e8 	stp	x8, x4, [sp, #56]
    96e0:	d37df000 	lsl	x0, x0, #3
    96e4:	97ffee8b 	bl	5110 <fwp_heap_alloc>
    96e8:	aa0003f7 	mov	x23, x0
    96ec:	a94393e8 	ldp	x8, x4, [sp, #56]
    96f0:	f8008408 	str	x8, [x0], #8
    96f4:	d2800001 	mov	x1, #0x0                   	// #0
    96f8:	b40000c8 	cbz	x8, 9710 <fwp_hof0.constprop.0+0xe70>
    96fc:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    9700:	f8217802 	str	x2, [x0, x1, lsl #3]
    9704:	91000421 	add	x1, x1, #0x1
    9708:	eb01011f 	cmp	x8, x1
    970c:	54ffff81 	b.ne	96fc <fwp_hof0.constprop.0+0xe5c>  // b.any
    9710:	91014281 	add	x1, x20, #0x50
    9714:	f9402fe2 	ldr	x2, [sp, #88]
    9718:	f941c820 	ldr	x0, [x1, #912]
    971c:	eb02001f 	cmp	x0, x2
    9720:	54006881 	b.ne	a430 <fwp_hof0.constprop.0+0x1b90>  // b.any
    9724:	f9401be0 	ldr	x0, [sp, #48]
    9728:	f94057e4 	ldr	x4, [sp, #168]
    972c:	f9001fe4 	str	x4, [sp, #56]
    9730:	f901c824 	str	x4, [x1, #912]
    9734:	97ffea98 	bl	4194 <fwp_tape_buffers_release>
    9738:	9118c2c2 	add	x2, x22, #0x630
    973c:	f9401fe4 	ldr	x4, [sp, #56]
    9740:	f949d841 	ldr	x1, [x2, #5040]
    9744:	f949ec40 	ldr	x0, [x2, #5080]
    9748:	cb0102e1 	sub	x1, x23, x1
    974c:	eb00403f 	cmp	x1, x0, lsl #16
    9750:	54000322 	b.cs	97b4 <fwp_hof0.constprop.0+0xf14>  // b.hs, b.nlast
    9754:	d350fc20 	lsr	x0, x1, #16
    9758:	f949fc47 	ldr	x7, [x2, #5112]
    975c:	8b000800 	add	x0, x0, x0, lsl #2
    9760:	d37df002 	lsl	x2, x0, #3
    9764:	8b0200e3 	add	x3, x7, x2
    9768:	f9401075 	ldr	x21, [x3, #32]
    976c:	b4000255 	cbz	x21, 97b4 <fwp_hof0.constprop.0+0xf14>
    9770:	386268e0 	ldrb	w0, [x7, x2]
    9774:	7100081f 	cmp	w0, #0x2
    9778:	54004ce0 	b.eq	a114 <fwp_hof0.constprop.0+0x1874>  // b.none
    977c:	7100041f 	cmp	w0, #0x1
    9780:	540001a1 	b.ne	97b4 <fwp_hof0.constprop.0+0xf14>  // b.any
    9784:	29430062 	ldp	w2, w0, [x3, #24]
    9788:	92403c21 	and	x1, x1, #0xffff
    978c:	9b027c21 	mul	x1, x1, x2
    9790:	d360fc21 	lsr	x1, x1, #32
    9794:	eb00003f 	cmp	x1, x0
    9798:	540000e2 	b.cs	97b4 <fwp_hof0.constprop.0+0xf14>  // b.hs, b.nlast
    979c:	8b0102b5 	add	x21, x21, x1
    97a0:	394002a0 	ldrb	w0, [x21]
    97a4:	7103fc1f 	cmp	w0, #0xff
    97a8:	54005bc0 	b.eq	a320 <fwp_hof0.constprop.0+0x1a80>  // b.none
    97ac:	52800020 	mov	w0, #0x1                   	// #1
    97b0:	390002a0 	strb	w0, [x21]
    97b4:	f94007e0 	ldr	x0, [sp, #8]
    97b8:	eb00009f 	cmp	x4, x0
    97bc:	540063a1 	b.ne	a430 <fwp_hof0.constprop.0+0x1b90>  // b.any
    97c0:	f94003e0 	ldr	x0, [sp]
    97c4:	91014281 	add	x1, x20, #0x50
    97c8:	f9404be2 	ldr	x2, [sp, #144]
    97cc:	f901c822 	str	x2, [x1, #912]
    97d0:	97fff3dc 	bl	6740 <fwp_tape_scope_release>
    97d4:	f94002e0 	ldr	x0, [x23]
    97d8:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    97dc:	b7f818a0 	tbnz	x0, #63, 9af0 <fwp_hof0.constprop.0+0x1250>
    97e0:	9118c2c3 	add	x3, x22, #0x630
    97e4:	f949d860 	ldr	x0, [x3, #5040]
    97e8:	f949ec61 	ldr	x1, [x3, #5080]
    97ec:	cb0002e0 	sub	x0, x23, x0
    97f0:	eb01401f 	cmp	x0, x1, lsl #16
    97f4:	540017e2 	b.cs	9af0 <fwp_hof0.constprop.0+0x1250>  // b.hs, b.nlast
    97f8:	d350fc01 	lsr	x1, x0, #16
    97fc:	f949fc67 	ldr	x7, [x3, #5112]
    9800:	8b010821 	add	x1, x1, x1, lsl #2
    9804:	d37df021 	lsl	x1, x1, #3
    9808:	8b0100e4 	add	x4, x7, x1
    980c:	f9401083 	ldr	x3, [x4, #32]
    9810:	b4001703 	cbz	x3, 9af0 <fwp_hof0.constprop.0+0x1250>
    9814:	386168e1 	ldrb	w1, [x7, x1]
    9818:	7100083f 	cmp	w1, #0x2
    981c:	54001660 	b.eq	9ae8 <fwp_hof0.constprop.0+0x1248>  // b.none
    9820:	7100043f 	cmp	w1, #0x1
    9824:	54001661 	b.ne	9af0 <fwp_hof0.constprop.0+0x1250>  // b.any
    9828:	29430487 	ldp	w7, w1, [x4, #24]
    982c:	92403c00 	and	x0, x0, #0xffff
    9830:	9b077c00 	mul	x0, x0, x7
    9834:	d360fc00 	lsr	x0, x0, #32
    9838:	eb01001f 	cmp	x0, x1
    983c:	540015a2 	b.cs	9af0 <fwp_hof0.constprop.0+0x1250>  // b.hs, b.nlast
    9840:	8b000063 	add	x3, x3, x0
    9844:	39400060 	ldrb	w0, [x3]
    9848:	7100041f 	cmp	w0, #0x1
    984c:	54001521 	b.ne	9af0 <fwp_hof0.constprop.0+0x1250>  // b.any
    9850:	aa1703f5 	mov	x21, x23
    9854:	d2800000 	mov	x0, #0x0                   	// #0
    9858:	910022a3 	add	x3, x21, #0x8
    985c:	d2800001 	mov	x1, #0x0                   	// #0
    9860:	b40001e2 	cbz	x2, 989c <fwp_hof0.constprop.0+0xffc>
    9864:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0x870>
    9868:	910022e7 	add	x7, x23, #0x8
    986c:	fd43c081 	ldr	d1, [x4, #1920]
    9870:	f94002e5 	ldr	x5, [x23]
    9874:	aa0703e4 	mov	x4, x7
    9878:	b7f81345 	tbnz	x5, #63, 9ae0 <fwp_hof0.constprop.0+0x1240>
    987c:	f94002a5 	ldr	x5, [x21]
    9880:	fc617880 	ldr	d0, [x4, x1, lsl #3]
    9884:	b7f81285 	tbnz	x5, #63, 9ad4 <fwp_hof0.constprop.0+0x1234>
    9888:	1e600820 	fmul	d0, d1, d0
    988c:	91000421 	add	x1, x1, #0x1
    9890:	fc008460 	str	d0, [x3], #8
    9894:	eb01005f 	cmp	x2, x1
    9898:	54fffec1 	b.ne	9870 <fwp_hof0.constprop.0+0xfd0>  // b.any
    989c:	97fff5b5 	bl	6f70 <fwp_drop10>
    98a0:	b400575a 	cbz	x26, a388 <fwp_hof0.constprop.0+0x1ae8>
    98a4:	aa1a03e0 	mov	x0, x26
    98a8:	d2800017 	mov	x23, #0x0                   	// #0
    98ac:	f9400800 	ldr	x0, [x0, #16]
    98b0:	910006f7 	add	x23, x23, #0x1
    98b4:	b5ffffc0 	cbnz	x0, 98ac <fwp_hof0.constprop.0+0x100c>
    98b8:	f94002a0 	ldr	x0, [x21]
    98bc:	9240f803 	and	x3, x0, #0x7fffffffffffffff
    98c0:	b7f81740 	tbnz	x0, #63, 9ba8 <fwp_hof0.constprop.0+0x1308>
    98c4:	9118c2c1 	add	x1, x22, #0x630
    98c8:	f949d820 	ldr	x0, [x1, #5040]
    98cc:	f949ec22 	ldr	x2, [x1, #5080]
    98d0:	cb0002a0 	sub	x0, x21, x0
    98d4:	eb02401f 	cmp	x0, x2, lsl #16
    98d8:	54001662 	b.cs	9ba4 <fwp_hof0.constprop.0+0x1304>  // b.hs, b.nlast
    98dc:	d350fc02 	lsr	x2, x0, #16
    98e0:	d2800504 	mov	x4, #0x28                  	// #40
    98e4:	f949fc27 	ldr	x7, [x1, #5112]
    98e8:	9b047c42 	mul	x2, x2, x4
    98ec:	8b0200e4 	add	x4, x7, x2
    98f0:	f9401081 	ldr	x1, [x4, #32]
    98f4:	b4001581 	cbz	x1, 9ba4 <fwp_hof0.constprop.0+0x1304>
    98f8:	386268e2 	ldrb	w2, [x7, x2]
    98fc:	7100085f 	cmp	w2, #0x2
    9900:	540014e0 	b.eq	9b9c <fwp_hof0.constprop.0+0x12fc>  // b.none
    9904:	7100045f 	cmp	w2, #0x1
    9908:	540014e1 	b.ne	9ba4 <fwp_hof0.constprop.0+0x1304>  // b.any
    990c:	29430887 	ldp	w7, w2, [x4, #24]
    9910:	92403c00 	and	x0, x0, #0xffff
    9914:	9b077c00 	mul	x0, x0, x7
    9918:	d360fc00 	lsr	x0, x0, #32
    991c:	eb02001f 	cmp	x0, x2
    9920:	54001422 	b.cs	9ba4 <fwp_hof0.constprop.0+0x1304>  // b.hs, b.nlast
    9924:	8b000021 	add	x1, x1, x0
    9928:	39400028 	ldrb	w8, [x1]
    992c:	7100051f 	cmp	w8, #0x1
    9930:	540013a1 	b.ne	9ba4 <fwp_hof0.constprop.0+0x1304>  // b.any
    9934:	910022a2 	add	x2, x21, #0x8
    9938:	eb17007f 	cmp	x3, x23
    993c:	9a979077 	csel	x23, x3, x23, ls	// ls = plast
    9940:	b4005397 	cbz	x23, a3b0 <fwp_hof0.constprop.0+0x1b10>
    9944:	d37df2e7 	lsl	x7, x23, #3
    9948:	aa1a03e1 	mov	x1, x26
    994c:	910022a4 	add	x4, x21, #0x8
    9950:	d2800000 	mov	x0, #0x0                   	// #0
    9954:	14000009 	b	9978 <fwp_hof0.constprop.0+0x10d8>
    9958:	fc606861 	ldr	d1, [x3, x0]
    995c:	fd400420 	ldr	d0, [x1, #8]
    9960:	1e613800 	fsub	d0, d0, d1
    9964:	fc206840 	str	d0, [x2, x0]
    9968:	91002000 	add	x0, x0, #0x8
    996c:	f9400821 	ldr	x1, [x1, #16]
    9970:	eb0000ff 	cmp	x7, x0
    9974:	54001480 	b.eq	9c04 <fwp_hof0.constprop.0+0x1364>  // b.none
    9978:	f94002a5 	ldr	x5, [x21]
    997c:	aa0403e3 	mov	x3, x4
    9980:	b6fffec5 	tbz	x5, #63, 9958 <fwp_hof0.constprop.0+0x10b8>
    9984:	f9400aa3 	ldr	x3, [x21, #16]
    9988:	17fffff4 	b	9958 <fwp_hof0.constprop.0+0x10b8>
    998c:	aa0403e0 	mov	x0, x4
    9990:	d37df2a2 	lsl	x2, x21, #3
    9994:	52800001 	mov	w1, #0x0                   	// #0
    9998:	f90033e8 	str	x8, [sp, #96]
    999c:	97ffe3b5 	bl	2870 <memset@plt>
    99a0:	aa0003e4 	mov	x4, x0
    99a4:	f94033e8 	ldr	x8, [sp, #96]
    99a8:	17ffff1e 	b	9620 <fwp_hof0.constprop.0+0xd80>
    99ac:	72003c1f 	tst	w0, #0xffff
    99b0:	54ffc3c1 	b.ne	9228 <fwp_hof0.constprop.0+0x988>  // b.any
    99b4:	17fffe5d 	b	9328 <fwp_hof0.constprop.0+0xa88>
    99b8:	90000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    99bc:	912ba000 	add	x0, x0, #0xae8
    99c0:	97ffea5d 	bl	4334 <fwp_trap>
    99c4:	aa0803f5 	mov	x21, x8
    99c8:	17fffeff 	b	95c4 <fwp_hof0.constprop.0+0xd24>
    99cc:	90000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    99d0:	9134c000 	add	x0, x0, #0xd30
    99d4:	97ffea58 	bl	4334 <fwp_trap>
    99d8:	aa1503e0 	mov	x0, x21
    99dc:	a903a7ea 	stp	x10, x9, [sp, #56]
    99e0:	97ffea75 	bl	43b4 <fwp_rc_forget_slot.part.0>
    99e4:	a943a7ea 	ldp	x10, x9, [sp, #56]
    99e8:	17fffdaa 	b	9090 <fwp_hof0.constprop.0+0x7f0>
    99ec:	72003c1f 	tst	w0, #0xffff
    99f0:	54ffdd81 	b.ne	95a0 <fwp_hof0.constprop.0+0xd00>  // b.any
    99f4:	17fffee0 	b	9574 <fwp_hof0.constprop.0+0xcd4>
    99f8:	aa1503e0 	mov	x0, x21
    99fc:	97ffea6e 	bl	43b4 <fwp_rc_forget_slot.part.0>
    9a00:	17fffe86 	b	9418 <fwp_hof0.constprop.0+0xb78>
    9a04:	d2800004 	mov	x4, #0x0                   	// #0
    9a08:	f10002bf 	cmp	x21, #0x0
    9a0c:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    9a10:	54ffe061 	b.ne	961c <fwp_hof0.constprop.0+0xd7c>  // b.any
    9a14:	f9401be0 	ldr	x0, [sp, #48]
    9a18:	91014294 	add	x20, x20, #0x50
    9a1c:	f94057e1 	ldr	x1, [sp, #168]
    9a20:	f901ca81 	str	x1, [x20, #912]
    9a24:	97ffe9dc 	bl	4194 <fwp_tape_buffers_release>
    9a28:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc90>
    9a2c:	f947e863 	ldr	x3, [x3, #4048]
    9a30:	d2800262 	mov	x2, #0x13                  	// #19
    9a34:	d2800021 	mov	x1, #0x1                   	// #1
    9a38:	90000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    9a3c:	911e6000 	add	x0, x0, #0x798
    9a40:	f9400063 	ldr	x3, [x3]
    9a44:	97ffe3d7 	bl	29a0 <fwrite@plt>
    9a48:	d2800000 	mov	x0, #0x0                   	// #0
    9a4c:	97ffe3e1 	bl	29d0 <fflush@plt>
    9a50:	52800cc0 	mov	w0, #0x66                  	// #102
    9a54:	97ffe3ef 	bl	2a10 <_Exit@plt>
    9a58:	ca404401 	eor	x1, x0, x0, lsr #17
    9a5c:	9118c2c3 	add	x3, x22, #0x630
    9a60:	ca412421 	eor	x1, x1, x1, lsr #9
    9a64:	92401c21 	and	x1, x1, #0xff
    9a68:	910a2422 	add	x2, x1, #0x289
    9a6c:	8b010c61 	add	x1, x3, x1, lsl #3
    9a70:	8b020c62 	add	x2, x3, x2, lsl #3
    9a74:	f94a2421 	ldr	x1, [x1, #5192]
    9a78:	b50000a1 	cbnz	x1, 9a8c <fwp_hof0.constprop.0+0x11ec>
    9a7c:	17ffffcf 	b	99b8 <fwp_hof0.constprop.0+0x1118>
    9a80:	91004022 	add	x2, x1, #0x10
    9a84:	f9400821 	ldr	x1, [x1, #16]
    9a88:	b4fff981 	cbz	x1, 99b8 <fwp_hof0.constprop.0+0x1118>
    9a8c:	f9400023 	ldr	x3, [x1]
    9a90:	eb00007f 	cmp	x3, x0
    9a94:	54ffff61 	b.ne	9a80 <fwp_hof0.constprop.0+0x11e0>  // b.any
    9a98:	f9400042 	ldr	x2, [x2]
    9a9c:	f9400441 	ldr	x1, [x2, #8]
    9aa0:	d1000421 	sub	x1, x1, #0x1
    9aa4:	f9000441 	str	x1, [x2, #8]
    9aa8:	f103f83f 	cmp	x1, #0xfe
    9aac:	54ffbbe1 	b.ne	9228 <fwp_hof0.constprop.0+0x988>  // b.any
    9ab0:	39400001 	ldrb	w1, [x0]
    9ab4:	7103fc3f 	cmp	w1, #0xff
    9ab8:	540043e0 	b.eq	a334 <fwp_hof0.constprop.0+0x1a94>  // b.none
    9abc:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9ac0:	39000001 	strb	w1, [x0]
    9ac4:	17fffdd9 	b	9228 <fwp_hof0.constprop.0+0x988>
    9ac8:	90000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    9acc:	913c0000 	add	x0, x0, #0xf00
    9ad0:	97ffea19 	bl	4334 <fwp_trap>
    9ad4:	90000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    9ad8:	913c4000 	add	x0, x0, #0xf10
    9adc:	97ffea16 	bl	4334 <fwp_trap>
    9ae0:	f9400ae4 	ldr	x4, [x23, #16]
    9ae4:	17ffff66 	b	987c <fwp_hof0.constprop.0+0xfdc>
    9ae8:	72003c1f 	tst	w0, #0xffff
    9aec:	54ffeac0 	b.eq	9844 <fwp_hof0.constprop.0+0xfa4>  // b.none
    9af0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9af4:	eb00005f 	cmp	x2, x0
    9af8:	54fffe88 	b.hi	9ac8 <fwp_hof0.constprop.0+0x1228>  // b.pmore
    9afc:	91000440 	add	x0, x2, #0x1
    9b00:	52800021 	mov	w1, #0x1                   	// #1
    9b04:	f9001fe2 	str	x2, [sp, #56]
    9b08:	d37df000 	lsl	x0, x0, #3
    9b0c:	97ffed81 	bl	5110 <fwp_heap_alloc>
    9b10:	f9401fe2 	ldr	x2, [sp, #56]
    9b14:	9118c2c4 	add	x4, x22, #0x630
    9b18:	f9000002 	str	x2, [x0]
    9b1c:	aa0003f5 	mov	x21, x0
    9b20:	f949d881 	ldr	x1, [x4, #5040]
    9b24:	f949ec80 	ldr	x0, [x4, #5080]
    9b28:	cb0102a1 	sub	x1, x21, x1
    9b2c:	eb00403f 	cmp	x1, x0, lsl #16
    9b30:	54000322 	b.cs	9b94 <fwp_hof0.constprop.0+0x12f4>  // b.hs, b.nlast
    9b34:	d350fc23 	lsr	x3, x1, #16
    9b38:	d2800500 	mov	x0, #0x28                  	// #40
    9b3c:	f949fc87 	ldr	x7, [x4, #5112]
    9b40:	9b007c63 	mul	x3, x3, x0
    9b44:	8b0300e4 	add	x4, x7, x3
    9b48:	f9401080 	ldr	x0, [x4, #32]
    9b4c:	b4000240 	cbz	x0, 9b94 <fwp_hof0.constprop.0+0x12f4>
    9b50:	386368e3 	ldrb	w3, [x7, x3]
    9b54:	7100087f 	cmp	w3, #0x2
    9b58:	54003ce0 	b.eq	a2f4 <fwp_hof0.constprop.0+0x1a54>  // b.none
    9b5c:	7100047f 	cmp	w3, #0x1
    9b60:	540001a1 	b.ne	9b94 <fwp_hof0.constprop.0+0x12f4>  // b.any
    9b64:	29430c87 	ldp	w7, w3, [x4, #24]
    9b68:	92403c21 	and	x1, x1, #0xffff
    9b6c:	9b077c21 	mul	x1, x1, x7
    9b70:	d360fc21 	lsr	x1, x1, #32
    9b74:	eb03003f 	cmp	x1, x3
    9b78:	540000e2 	b.cs	9b94 <fwp_hof0.constprop.0+0x12f4>  // b.hs, b.nlast
    9b7c:	8b010000 	add	x0, x0, x1
    9b80:	39400001 	ldrb	w1, [x0]
    9b84:	7103fc3f 	cmp	w1, #0xff
    9b88:	54003ae0 	b.eq	a2e4 <fwp_hof0.constprop.0+0x1a44>  // b.none
    9b8c:	52800021 	mov	w1, #0x1                   	// #1
    9b90:	39000001 	strb	w1, [x0]
    9b94:	aa1703e0 	mov	x0, x23
    9b98:	17ffff30 	b	9858 <fwp_hof0.constprop.0+0xfb8>
    9b9c:	72003c1f 	tst	w0, #0xffff
    9ba0:	54ffec40 	b.eq	9928 <fwp_hof0.constprop.0+0x1088>  // b.none
    9ba4:	b4003fda 	cbz	x26, a39c <fwp_hof0.constprop.0+0x1afc>
    9ba8:	aa1a03e1 	mov	x1, x26
    9bac:	d2800017 	mov	x23, #0x0                   	// #0
    9bb0:	f9400821 	ldr	x1, [x1, #16]
    9bb4:	aa1703e0 	mov	x0, x23
    9bb8:	910006f7 	add	x23, x23, #0x1
    9bbc:	b5ffffa1 	cbnz	x1, 9bb0 <fwp_hof0.constprop.0+0x1310>
    9bc0:	f9001fe3 	str	x3, [sp, #56]
    9bc4:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9bc8:	eb0102ff 	cmp	x23, x1
    9bcc:	54ff8d88 	b.hi	8d7c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    9bd0:	91000800 	add	x0, x0, #0x2
    9bd4:	52800041 	mov	w1, #0x2                   	// #2
    9bd8:	d37df000 	lsl	x0, x0, #3
    9bdc:	97ffed4d 	bl	5110 <fwp_heap_alloc>
    9be0:	f9401fe3 	ldr	x3, [sp, #56]
    9be4:	aa1a03e1 	mov	x1, x26
    9be8:	aa0003e2 	mov	x2, x0
    9bec:	f9400424 	ldr	x4, [x1, #8]
    9bf0:	f8008404 	str	x4, [x0], #8
    9bf4:	f9400821 	ldr	x1, [x1, #16]
    9bf8:	b5ffffa1 	cbnz	x1, 9bec <fwp_hof0.constprop.0+0x134c>
    9bfc:	52800008 	mov	w8, #0x0                   	// #0
    9c00:	17ffff4e 	b	9938 <fwp_hof0.constprop.0+0x1098>
    9c04:	b40038ba 	cbz	x26, a318 <fwp_hof0.constprop.0+0x1a78>
    9c08:	9118c2c0 	add	x0, x22, #0x630
    9c0c:	aa1a03e7 	mov	x7, x26
    9c10:	d2800004 	mov	x4, #0x0                   	// #0
    9c14:	f949ec09 	ldr	x9, [x0, #5080]
    9c18:	f949d80b 	ldr	x11, [x0, #5040]
    9c1c:	f949fc0c 	ldr	x12, [x0, #5112]
    9c20:	d370bd29 	lsl	x9, x9, #16
    9c24:	14000006 	b	9c3c <fwp_hof0.constprop.0+0x139c>
    9c28:	f94008e7 	ldr	x7, [x7, #16]
    9c2c:	91000484 	add	x4, x4, #0x1
    9c30:	f10000ff 	cmp	x7, #0x0
    9c34:	fa4412e0 	ccmp	x23, x4, #0x0, ne	// ne = any
    9c38:	54000329 	b.ls	9c9c <fwp_hof0.constprop.0+0x13fc>  // b.plast
    9c3c:	cb0b00e0 	sub	x0, x7, x11
    9c40:	eb09001f 	cmp	x0, x9
    9c44:	540002c2 	b.cs	9c9c <fwp_hof0.constprop.0+0x13fc>  // b.hs, b.nlast
    9c48:	d350fc01 	lsr	x1, x0, #16
    9c4c:	8b010821 	add	x1, x1, x1, lsl #2
    9c50:	d37df021 	lsl	x1, x1, #3
    9c54:	8b010185 	add	x5, x12, x1
    9c58:	f94010a3 	ldr	x3, [x5, #32]
    9c5c:	b4000203 	cbz	x3, 9c9c <fwp_hof0.constprop.0+0x13fc>
    9c60:	38616981 	ldrb	w1, [x12, x1]
    9c64:	7100083f 	cmp	w1, #0x2
    9c68:	54002500 	b.eq	a108 <fwp_hof0.constprop.0+0x1868>  // b.none
    9c6c:	7100043f 	cmp	w1, #0x1
    9c70:	54000161 	b.ne	9c9c <fwp_hof0.constprop.0+0x13fc>  // b.any
    9c74:	294304a6 	ldp	w6, w1, [x5, #24]
    9c78:	92403c00 	and	x0, x0, #0xffff
    9c7c:	9b067c00 	mul	x0, x0, x6
    9c80:	d360fc00 	lsr	x0, x0, #32
    9c84:	eb01001f 	cmp	x0, x1
    9c88:	540000a2 	b.cs	9c9c <fwp_hof0.constprop.0+0x13fc>  // b.hs, b.nlast
    9c8c:	8b000063 	add	x3, x3, x0
    9c90:	39400060 	ldrb	w0, [x3]
    9c94:	7100041f 	cmp	w0, #0x1
    9c98:	54fffc80 	b.eq	9c28 <fwp_hof0.constprop.0+0x1388>  // b.none
    9c9c:	d2800003 	mov	x3, #0x0                   	// #0
    9ca0:	eb0402ff 	cmp	x23, x4
    9ca4:	54002fe9 	b.ls	a2a0 <fwp_hof0.constprop.0+0x1a00>  // b.plast
    9ca8:	d1002040 	sub	x0, x2, #0x8
    9cac:	9118c2ca 	add	x10, x22, #0x630
    9cb0:	d2800003 	mov	x3, #0x0                   	// #0
    9cb4:	a9046be0 	stp	x0, x26, [sp, #64]
    9cb8:	9103e3e0 	add	x0, sp, #0xf8
    9cbc:	aa0403fa 	mov	x26, x4
    9cc0:	f9001fe0 	str	x0, [sp, #56]
    9cc4:	f9002be2 	str	x2, [sp, #80]
    9cc8:	b9005be8 	str	w8, [sp, #88]
    9ccc:	a9064ff5 	stp	x21, x19, [sp, #96]
    9cd0:	aa1703f3 	mov	x19, x23
    9cd4:	aa0a03f5 	mov	x21, x10
    9cd8:	14000012 	b	9d20 <fwp_hof0.constprop.0+0x1480>
    9cdc:	7100045f 	cmp	w2, #0x1
    9ce0:	540001a1 	b.ne	9d14 <fwp_hof0.constprop.0+0x1474>  // b.any
    9ce4:	29430885 	ldp	w5, w2, [x4, #24]
    9ce8:	92403c21 	and	x1, x1, #0xffff
    9cec:	9b057c21 	mul	x1, x1, x5
    9cf0:	d360fc21 	lsr	x1, x1, #32
    9cf4:	eb02003f 	cmp	x1, x2
    9cf8:	540000e2 	b.cs	9d14 <fwp_hof0.constprop.0+0x1474>  // b.hs, b.nlast
    9cfc:	8b010000 	add	x0, x0, x1
    9d00:	39400001 	ldrb	w1, [x0]
    9d04:	7103fc3f 	cmp	w1, #0xff
    9d08:	54002e60 	b.eq	a2d4 <fwp_hof0.constprop.0+0x1a34>  // b.none
    9d0c:	52800021 	mov	w1, #0x1                   	// #1
    9d10:	39000001 	strb	w1, [x0]
    9d14:	d1000673 	sub	x19, x19, #0x1
    9d18:	eb1a027f 	cmp	x19, x26
    9d1c:	54000329 	b.ls	9d80 <fwp_hof0.constprop.0+0x14e0>  // b.plast
    9d20:	a94383e1 	ldp	x1, x0, [sp, #56]
    9d24:	f8737800 	ldr	x0, [x0, x19, lsl #3]
    9d28:	a90f8fe0 	stp	x0, x3, [sp, #248]
    9d2c:	52800020 	mov	w0, #0x1                   	// #1
    9d30:	97ffed5c 	bl	52a0 <fwp_data.part.0.constprop.0>
    9d34:	aa0003e3 	mov	x3, x0
    9d38:	f949daa1 	ldr	x1, [x21, #5040]
    9d3c:	f949eea0 	ldr	x0, [x21, #5080]
    9d40:	cb010061 	sub	x1, x3, x1
    9d44:	eb00403f 	cmp	x1, x0, lsl #16
    9d48:	54fffe62 	b.cs	9d14 <fwp_hof0.constprop.0+0x1474>  // b.hs, b.nlast
    9d4c:	d350fc20 	lsr	x0, x1, #16
    9d50:	f949fea5 	ldr	x5, [x21, #5112]
    9d54:	8b000800 	add	x0, x0, x0, lsl #2
    9d58:	d37df002 	lsl	x2, x0, #3
    9d5c:	8b0200a4 	add	x4, x5, x2
    9d60:	f9401080 	ldr	x0, [x4, #32]
    9d64:	b4fffd80 	cbz	x0, 9d14 <fwp_hof0.constprop.0+0x1474>
    9d68:	386268a2 	ldrb	w2, [x5, x2]
    9d6c:	7100085f 	cmp	w2, #0x2
    9d70:	54fffb61 	b.ne	9cdc <fwp_hof0.constprop.0+0x143c>  // b.any
    9d74:	72003c3f 	tst	w1, #0xffff
    9d78:	54fffce1 	b.ne	9d14 <fwp_hof0.constprop.0+0x1474>  // b.any
    9d7c:	17ffffe1 	b	9d00 <fwp_hof0.constprop.0+0x1460>
    9d80:	d10006e1 	sub	x1, x23, #0x1
    9d84:	cb170340 	sub	x0, x26, x23
    9d88:	eb1a003f 	cmp	x1, x26
    9d8c:	aa1a03e4 	mov	x4, x26
    9d90:	9a8037e0 	csinc	x0, xzr, x0, cc	// cc = lo, ul, last
    9d94:	b9405be8 	ldr	w8, [sp, #88]
    9d98:	a9448bfa 	ldp	x26, x2, [sp, #72]
    9d9c:	8b010000 	add	x0, x0, x1
    9da0:	a9464ff5 	ldp	x21, x19, [sp, #96]
    9da4:	b50027e4 	cbnz	x4, a2a0 <fwp_hof0.constprop.0+0x1a00>
    9da8:	7100011f 	cmp	w8, #0x0
    9dac:	9a8213e2 	csel	x2, xzr, x2, ne	// ne = any
    9db0:	b4002680 	cbz	x0, a280 <fwp_hof0.constprop.0+0x19e0>
    9db4:	d1000417 	sub	x23, x0, #0x1
    9db8:	9118c2c7 	add	x7, x22, #0x630
    9dbc:	a9044ff5 	stp	x21, x19, [sp, #64]
    9dc0:	aa1703f5 	mov	x21, x23
    9dc4:	aa0203f3 	mov	x19, x2
    9dc8:	f9002bf9 	str	x25, [sp, #80]
    9dcc:	aa0703f9 	mov	x25, x7
    9dd0:	14000012 	b	9e18 <fwp_hof0.constprop.0+0x1578>
    9dd4:	7100049f 	cmp	w4, #0x1
    9dd8:	540001a1 	b.ne	9e0c <fwp_hof0.constprop.0+0x156c>  // b.any
    9ddc:	29430004 	ldp	w4, w0, [x0, #24]
    9de0:	92403c21 	and	x1, x1, #0xffff
    9de4:	9b047c21 	mul	x1, x1, x4
    9de8:	d360fc21 	lsr	x1, x1, #32
    9dec:	eb00003f 	cmp	x1, x0
    9df0:	540000e2 	b.cs	9e0c <fwp_hof0.constprop.0+0x156c>  // b.hs, b.nlast
    9df4:	8b0102f7 	add	x23, x23, x1
    9df8:	394002e0 	ldrb	w0, [x23]
    9dfc:	7103fc1f 	cmp	w0, #0xff
    9e00:	54002460 	b.eq	a28c <fwp_hof0.constprop.0+0x19ec>  // b.none
    9e04:	52800020 	mov	w0, #0x1                   	// #1
    9e08:	390002e0 	strb	w0, [x23]
    9e0c:	d10006b5 	sub	x21, x21, #0x1
    9e10:	b10006bf 	cmn	x21, #0x1
    9e14:	54000320 	b.eq	9e78 <fwp_hof0.constprop.0+0x15d8>  // b.none
    9e18:	f9401fe1 	ldr	x1, [sp, #56]
    9e1c:	f8757a60 	ldr	x0, [x19, x21, lsl #3]
    9e20:	a90f8fe0 	stp	x0, x3, [sp, #248]
    9e24:	52800020 	mov	w0, #0x1                   	// #1
    9e28:	97ffed1e 	bl	52a0 <fwp_data.part.0.constprop.0>
    9e2c:	aa0003e3 	mov	x3, x0
    9e30:	f949db21 	ldr	x1, [x25, #5040]
    9e34:	f949ef20 	ldr	x0, [x25, #5080]
    9e38:	cb010061 	sub	x1, x3, x1
    9e3c:	eb00403f 	cmp	x1, x0, lsl #16
    9e40:	54fffe62 	b.cs	9e0c <fwp_hof0.constprop.0+0x156c>  // b.hs, b.nlast
    9e44:	d350fc20 	lsr	x0, x1, #16
    9e48:	f949ff26 	ldr	x6, [x25, #5112]
    9e4c:	8b000800 	add	x0, x0, x0, lsl #2
    9e50:	d37df004 	lsl	x4, x0, #3
    9e54:	8b0400c0 	add	x0, x6, x4
    9e58:	f9401017 	ldr	x23, [x0, #32]
    9e5c:	b4fffd97 	cbz	x23, 9e0c <fwp_hof0.constprop.0+0x156c>
    9e60:	386468c4 	ldrb	w4, [x6, x4]
    9e64:	7100089f 	cmp	w4, #0x2
    9e68:	54fffb61 	b.ne	9dd4 <fwp_hof0.constprop.0+0x1534>  // b.any
    9e6c:	72003c3f 	tst	w1, #0xffff
    9e70:	54fffce1 	b.ne	9e0c <fwp_hof0.constprop.0+0x156c>  // b.any
    9e74:	17ffffe1 	b	9df8 <fwp_hof0.constprop.0+0x1558>
    9e78:	aa1303e2 	mov	x2, x19
    9e7c:	aa1a03f7 	mov	x23, x26
    9e80:	a9444ff5 	ldp	x21, x19, [sp, #64]
    9e84:	aa0303fa 	mov	x26, x3
    9e88:	f9402bf9 	ldr	x25, [sp, #80]
    9e8c:	aa0203e0 	mov	x0, x2
    9e90:	97ffe9e4 	bl	4620 <fwp_mem_free>
    9e94:	f9001ff9 	str	x25, [sp, #56]
    9e98:	9118c2c4 	add	x4, x22, #0x630
    9e9c:	aa1303f9 	mov	x25, x19
    9ea0:	aa0403f3 	mov	x19, x4
    9ea4:	d2800507 	mov	x7, #0x28                  	// #40
    9ea8:	f949da61 	ldr	x1, [x19, #5040]
    9eac:	f949ee60 	ldr	x0, [x19, #5080]
    9eb0:	cb0102a1 	sub	x1, x21, x1
    9eb4:	eb00403f 	cmp	x1, x0, lsl #16
    9eb8:	54001222 	b.cs	a0fc <fwp_hof0.constprop.0+0x185c>  // b.hs, b.nlast
    9ebc:	d350fc22 	lsr	x2, x1, #16
    9ec0:	f949fe63 	ldr	x3, [x19, #5112]
    9ec4:	9b077c42 	mul	x2, x2, x7
    9ec8:	8b020068 	add	x8, x3, x2
    9ecc:	f9401100 	ldr	x0, [x8, #32]
    9ed0:	b4001160 	cbz	x0, a0fc <fwp_hof0.constprop.0+0x185c>
    9ed4:	38626863 	ldrb	w3, [x3, x2]
    9ed8:	7100087f 	cmp	w3, #0x2
    9edc:	540010c0 	b.eq	a0f4 <fwp_hof0.constprop.0+0x1854>  // b.none
    9ee0:	7100047f 	cmp	w3, #0x1
    9ee4:	540010c1 	b.ne	a0fc <fwp_hof0.constprop.0+0x185c>  // b.any
    9ee8:	29431502 	ldp	w2, w5, [x8, #24]
    9eec:	92403c21 	and	x1, x1, #0xffff
    9ef0:	9b027c22 	mul	x2, x1, x2
    9ef4:	d360fc42 	lsr	x2, x2, #32
    9ef8:	eb05005f 	cmp	x2, x5
    9efc:	54001002 	b.cs	a0fc <fwp_hof0.constprop.0+0x185c>  // b.hs, b.nlast
    9f00:	8b020000 	add	x0, x0, x2
    9f04:	39400002 	ldrb	w2, [x0]
    9f08:	34000fa2 	cbz	w2, a0fc <fwp_hof0.constprop.0+0x185c>
    9f0c:	7100045f 	cmp	w2, #0x1
    9f10:	54000d60 	b.eq	a0bc <fwp_hof0.constprop.0+0x181c>  // b.none
    9f14:	aa1903f3 	mov	x19, x25
    9f18:	f9401ff9 	ldr	x25, [sp, #56]
    9f1c:	7103fc5f 	cmp	w2, #0xff
    9f20:	54002120 	b.eq	a344 <fwp_hof0.constprop.0+0x1aa4>  // b.none
    9f24:	51000442 	sub	w2, w2, #0x1
    9f28:	39000002 	strb	w2, [x0]
    9f2c:	9118c2c4 	add	x4, x22, #0x630
    9f30:	f9001ff9 	str	x25, [sp, #56]
    9f34:	aa1303f9 	mov	x25, x19
    9f38:	aa0403f3 	mov	x19, x4
    9f3c:	d2800507 	mov	x7, #0x28                  	// #40
    9f40:	f949da60 	ldr	x0, [x19, #5040]
    9f44:	f949ee61 	ldr	x1, [x19, #5080]
    9f48:	cb0002e0 	sub	x0, x23, x0
    9f4c:	eb01401f 	cmp	x0, x1, lsl #16
    9f50:	54000b02 	b.cs	a0b0 <fwp_hof0.constprop.0+0x1810>  // b.hs, b.nlast
    9f54:	d350fc01 	lsr	x1, x0, #16
    9f58:	f949fe62 	ldr	x2, [x19, #5112]
    9f5c:	9b077c21 	mul	x1, x1, x7
    9f60:	8b010043 	add	x3, x2, x1
    9f64:	f9401075 	ldr	x21, [x3, #32]
    9f68:	b4000a55 	cbz	x21, a0b0 <fwp_hof0.constprop.0+0x1810>
    9f6c:	38616845 	ldrb	w5, [x2, x1]
    9f70:	710008bf 	cmp	w5, #0x2
    9f74:	540009a0 	b.eq	a0a8 <fwp_hof0.constprop.0+0x1808>  // b.none
    9f78:	710004bf 	cmp	w5, #0x1
    9f7c:	540009a1 	b.ne	a0b0 <fwp_hof0.constprop.0+0x1810>  // b.any
    9f80:	29430861 	ldp	w1, w2, [x3, #24]
    9f84:	92403c00 	and	x0, x0, #0xffff
    9f88:	9b017c01 	mul	x1, x0, x1
    9f8c:	d360fc21 	lsr	x1, x1, #32
    9f90:	eb02003f 	cmp	x1, x2
    9f94:	540008e2 	b.cs	a0b0 <fwp_hof0.constprop.0+0x1810>  // b.hs, b.nlast
    9f98:	8b0102b5 	add	x21, x21, x1
    9f9c:	394002a2 	ldrb	w2, [x21]
    9fa0:	34000882 	cbz	w2, a0b0 <fwp_hof0.constprop.0+0x1810>
    9fa4:	7100045f 	cmp	w2, #0x1
    9fa8:	540012c0 	b.eq	a200 <fwp_hof0.constprop.0+0x1960>  // b.none
    9fac:	aa1903f3 	mov	x19, x25
    9fb0:	f9401ff9 	ldr	x25, [sp, #56]
    9fb4:	7103fc5f 	cmp	w2, #0xff
    9fb8:	54001060 	b.eq	a1c4 <fwp_hof0.constprop.0+0x1924>  // b.none
    9fbc:	51000442 	sub	w2, w2, #0x1
    9fc0:	390002a2 	strb	w2, [x21]
    9fc4:	f9400be0 	ldr	x0, [sp, #16]
    9fc8:	b4ff6f60 	cbz	x0, 8db4 <fwp_hof0.constprop.0+0x514>
    9fcc:	f9400be0 	ldr	x0, [sp, #16]
    9fd0:	f1000400 	subs	x0, x0, #0x1
    9fd4:	f9000be0 	str	x0, [sp, #16]
    9fd8:	540022a6 	b.vs	a42c <fwp_hof0.constprop.0+0x1b8c>
    9fdc:	9118c2c0 	add	x0, x22, #0x630
    9fe0:	f949ec04 	ldr	x4, [x0, #5080]
    9fe4:	f949d801 	ldr	x1, [x0, #5040]
    9fe8:	d370bc84 	lsl	x4, x4, #16
    9fec:	17fffa77 	b	89c8 <fwp_hof0.constprop.0+0x128>
    9ff0:	90000020 	adrp	x0, d000 <fwp_main_thread+0x520>
    9ff4:	913ce000 	add	x0, x0, #0xf38
    9ff8:	97ffe8cf 	bl	4334 <fwp_trap>
    9ffc:	aa1903e0 	mov	x0, x25
    a000:	97ffef50 	bl	5d40 <fwp_rc_free_arr>
    a004:	17fffbe0 	b	8f84 <fwp_hof0.constprop.0+0x6e4>
    a008:	72003c3f 	tst	w1, #0xffff
    a00c:	54ff7bc1 	b.ne	8f84 <fwp_hof0.constprop.0+0x6e4>  // b.any
    a010:	17fffbd5 	b	8f64 <fwp_hof0.constprop.0+0x6c4>
    a014:	72003c3f 	tst	w1, #0xffff
    a018:	54ff75a1 	b.ne	8ecc <fwp_hof0.constprop.0+0x62c>  // b.any
    a01c:	17fffba7 	b	8eb8 <fwp_hof0.constprop.0+0x618>
    a020:	f9000be0 	str	x0, [sp, #16]
    a024:	f90013e3 	str	x3, [sp, #32]
    a028:	97ffe8e3 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a02c:	f9400be0 	ldr	x0, [sp, #16]
    a030:	f94013e3 	ldr	x3, [sp, #32]
    a034:	17fffba4 	b	8ec4 <fwp_hof0.constprop.0+0x624>
    a038:	ca5546a1 	eor	x1, x21, x21, lsr #17
    a03c:	9118c2c2 	add	x2, x22, #0x630
    a040:	ca412421 	eor	x1, x1, x1, lsr #9
    a044:	92401c21 	and	x1, x1, #0xff
    a048:	910a2420 	add	x0, x1, #0x289
    a04c:	8b010c41 	add	x1, x2, x1, lsl #3
    a050:	8b000c40 	add	x0, x2, x0, lsl #3
    a054:	f94a2421 	ldr	x1, [x1, #5192]
    a058:	b50000a1 	cbnz	x1, a06c <fwp_hof0.constprop.0+0x17cc>
    a05c:	17fffe57 	b	99b8 <fwp_hof0.constprop.0+0x1118>
    a060:	91004020 	add	x0, x1, #0x10
    a064:	f9400821 	ldr	x1, [x1, #16]
    a068:	b4ffca81 	cbz	x1, 99b8 <fwp_hof0.constprop.0+0x1118>
    a06c:	f9400022 	ldr	x2, [x1]
    a070:	eb15005f 	cmp	x2, x21
    a074:	54ffff61 	b.ne	a060 <fwp_hof0.constprop.0+0x17c0>  // b.any
    a078:	f9400001 	ldr	x1, [x0]
    a07c:	f9400420 	ldr	x0, [x1, #8]
    a080:	d1000400 	sub	x0, x0, #0x1
    a084:	f9000420 	str	x0, [x1, #8]
    a088:	f103f81f 	cmp	x0, #0xfe
    a08c:	54ff77c1 	b.ne	8f84 <fwp_hof0.constprop.0+0x6e4>  // b.any
    a090:	394002a0 	ldrb	w0, [x21]
    a094:	7103fc1f 	cmp	w0, #0xff
    a098:	54000e80 	b.eq	a268 <fwp_hof0.constprop.0+0x19c8>  // b.none
    a09c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a0a0:	390002a0 	strb	w0, [x21]
    a0a4:	17fffbb8 	b	8f84 <fwp_hof0.constprop.0+0x6e4>
    a0a8:	f2403c00 	ands	x0, x0, #0xffff
    a0ac:	54fff780 	b.eq	9f9c <fwp_hof0.constprop.0+0x16fc>  // b.none
    a0b0:	aa1903f3 	mov	x19, x25
    a0b4:	f9401ff9 	ldr	x25, [sp, #56]
    a0b8:	17ffffc3 	b	9fc4 <fwp_hof0.constprop.0+0x1724>
    a0bc:	f94002a2 	ldr	x2, [x21]
    a0c0:	aa1503e0 	mov	x0, x21
    a0c4:	b7f817c2 	tbnz	x2, #63, a3bc <fwp_hof0.constprop.0+0x1b1c>
    a0c8:	aa1903f3 	mov	x19, x25
    a0cc:	f9401ff9 	ldr	x25, [sp, #56]
    a0d0:	7100087f 	cmp	w3, #0x2
    a0d4:	54001560 	b.eq	a380 <fwp_hof0.constprop.0+0x1ae0>  // b.none
    a0d8:	29430102 	ldp	w2, w0, [x8, #24]
    a0dc:	9b027c21 	mul	x1, x1, x2
    a0e0:	eb41801f 	cmp	x0, x1, lsr #32
    a0e4:	54fff249 	b.ls	9f2c <fwp_hof0.constprop.0+0x168c>  // b.plast
    a0e8:	aa1503e0 	mov	x0, x21
    a0ec:	97ffe94d 	bl	4620 <fwp_mem_free>
    a0f0:	17ffff8f 	b	9f2c <fwp_hof0.constprop.0+0x168c>
    a0f4:	f2403c21 	ands	x1, x1, #0xffff
    a0f8:	54fff060 	b.eq	9f04 <fwp_hof0.constprop.0+0x1664>  // b.none
    a0fc:	aa1903f3 	mov	x19, x25
    a100:	f9401ff9 	ldr	x25, [sp, #56]
    a104:	17ffff8a 	b	9f2c <fwp_hof0.constprop.0+0x168c>
    a108:	72003c1f 	tst	w0, #0xffff
    a10c:	54ffdc81 	b.ne	9c9c <fwp_hof0.constprop.0+0x13fc>  // b.any
    a110:	17fffee0 	b	9c90 <fwp_hof0.constprop.0+0x13f0>
    a114:	72003c3f 	tst	w1, #0xffff
    a118:	54ffb4e1 	b.ne	97b4 <fwp_hof0.constprop.0+0xf14>  // b.any
    a11c:	17fffda1 	b	97a0 <fwp_hof0.constprop.0+0xf00>
    a120:	d1000521 	sub	x1, x9, #0x1
    a124:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    a128:	eb00003f 	cmp	x1, x0
    a12c:	54000408 	b.hi	a1ac <fwp_hof0.constprop.0+0x190c>  // b.pmore
    a130:	d00002a0 	adrp	x0, 60000 <ad_raw_checkpoints+0x2fbb0>
    a134:	d2800003 	mov	x3, #0x0                   	// #0
    a138:	91114001 	add	x1, x0, #0x450
    a13c:	14000005 	b	a150 <fwp_hof0.constprop.0+0x18b0>
    a140:	91000463 	add	x3, x3, #0x1
    a144:	91006021 	add	x1, x1, #0x18
    a148:	f140047f 	cmp	x3, #0x1, lsl #12
    a14c:	54000360 	b.eq	a1b8 <fwp_hof0.constprop.0+0x1918>  // b.none
    a150:	f9400022 	ldr	x2, [x1]
    a154:	b5ffff62 	cbnz	x2, a140 <fwp_hof0.constprop.0+0x18a0>
    a158:	91114002 	add	x2, x0, #0x450
    a15c:	d2800304 	mov	x4, #0x18                  	// #24
    a160:	aa0903e0 	mov	x0, x9
    a164:	d2800101 	mov	x1, #0x8                   	// #8
    a168:	f9003be8 	str	x8, [sp, #112]
    a16c:	9b040862 	madd	x2, x3, x4, x2
    a170:	a90627e2 	stp	x2, x9, [sp, #96]
    a174:	97ffe1c3 	bl	2880 <calloc@plt>
    a178:	aa0003e4 	mov	x4, x0
    a17c:	a946a3e9 	ldp	x9, x8, [sp, #104]
    a180:	b4ffc420 	cbz	x0, 9a04 <fwp_hof0.constprop.0+0x1164>
    a184:	aa0003e1 	mov	x1, x0
    a188:	d37df122 	lsl	x2, x9, #3
    a18c:	f94033e0 	ldr	x0, [sp, #96]
    a190:	52800063 	mov	w3, #0x3                   	// #3
    a194:	a90627e4 	stp	x4, x9, [sp, #96]
    a198:	f9003be8 	str	x8, [sp, #112]
    a19c:	97ffe37d 	bl	2f90 <ad_raw_record>
    a1a0:	a94627e4 	ldp	x4, x9, [sp, #96]
    a1a4:	f9403be8 	ldr	x8, [sp, #112]
    a1a8:	17fffd1b 	b	9614 <fwp_hof0.constprop.0+0xd74>
    a1ac:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x520>
    a1b0:	913b8000 	add	x0, x0, #0xee0
    a1b4:	97ffe473 	bl	3380 <ad_raw_fail>
    a1b8:	f0000000 	adrp	x0, d000 <fwp_main_thread+0x520>
    a1bc:	91286000 	add	x0, x0, #0xa18
    a1c0:	97ffe470 	bl	3380 <ad_raw_fail>
    a1c4:	ca5546a1 	eor	x1, x21, x21, lsr #17
    a1c8:	9118c2c0 	add	x0, x22, #0x630
    a1cc:	ca412421 	eor	x1, x1, x1, lsr #9
    a1d0:	92401c21 	and	x1, x1, #0xff
    a1d4:	910a2422 	add	x2, x1, #0x289
    a1d8:	8b010c01 	add	x1, x0, x1, lsl #3
    a1dc:	8b020c02 	add	x2, x0, x2, lsl #3
    a1e0:	f94a2420 	ldr	x0, [x1, #5192]
    a1e4:	b4ffbea0 	cbz	x0, 99b8 <fwp_hof0.constprop.0+0x1118>
    a1e8:	f9400001 	ldr	x1, [x0]
    a1ec:	eb0102bf 	cmp	x21, x1
    a1f0:	54000240 	b.eq	a238 <fwp_hof0.constprop.0+0x1998>  // b.none
    a1f4:	91004002 	add	x2, x0, #0x10
    a1f8:	f9400800 	ldr	x0, [x0, #16]
    a1fc:	17fffffa 	b	a1e4 <fwp_hof0.constprop.0+0x1944>
    a200:	aa1703e1 	mov	x1, x23
    a204:	f9400af7 	ldr	x23, [x23, #16]
    a208:	710008bf 	cmp	w5, #0x2
    a20c:	54000120 	b.eq	a230 <fwp_hof0.constprop.0+0x1990>  // b.none
    a210:	29430865 	ldp	w5, w2, [x3, #24]
    a214:	9b057c00 	mul	x0, x0, x5
    a218:	eb40805f 	cmp	x2, x0, lsr #32
    a21c:	54ffe929 	b.ls	9f40 <fwp_hof0.constprop.0+0x16a0>  // b.plast
    a220:	aa0103e0 	mov	x0, x1
    a224:	97ffe8ff 	bl	4620 <fwp_mem_free>
    a228:	d2800507 	mov	x7, #0x28                  	// #40
    a22c:	17ffff45 	b	9f40 <fwp_hof0.constprop.0+0x16a0>
    a230:	b5ffe880 	cbnz	x0, 9f40 <fwp_hof0.constprop.0+0x16a0>
    a234:	17fffffb 	b	a220 <fwp_hof0.constprop.0+0x1980>
    a238:	f9400041 	ldr	x1, [x2]
    a23c:	f9400420 	ldr	x0, [x1, #8]
    a240:	d1000400 	sub	x0, x0, #0x1
    a244:	f9000420 	str	x0, [x1, #8]
    a248:	f103f81f 	cmp	x0, #0xfe
    a24c:	54ffebc1 	b.ne	9fc4 <fwp_hof0.constprop.0+0x1724>  // b.any
    a250:	394002a0 	ldrb	w0, [x21]
    a254:	7103fc1f 	cmp	w0, #0xff
    a258:	540000e0 	b.eq	a274 <fwp_hof0.constprop.0+0x19d4>  // b.none
    a25c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a260:	390002a0 	strb	w0, [x21]
    a264:	17ffff58 	b	9fc4 <fwp_hof0.constprop.0+0x1724>
    a268:	aa1503e0 	mov	x0, x21
    a26c:	97ffe852 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a270:	17ffff8b 	b	a09c <fwp_hof0.constprop.0+0x17fc>
    a274:	aa1503e0 	mov	x0, x21
    a278:	97ffe84f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a27c:	17fffff8 	b	a25c <fwp_hof0.constprop.0+0x19bc>
    a280:	aa1a03f7 	mov	x23, x26
    a284:	aa0303fa 	mov	x26, x3
    a288:	17ffff01 	b	9e8c <fwp_hof0.constprop.0+0x15ec>
    a28c:	aa1703e0 	mov	x0, x23
    a290:	f9002fe3 	str	x3, [sp, #88]
    a294:	97ffe848 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a298:	f9402fe3 	ldr	x3, [sp, #88]
    a29c:	17fffeda 	b	9e04 <fwp_hof0.constprop.0+0x1564>
    a2a0:	aa1a03f7 	mov	x23, x26
    a2a4:	d2800000 	mov	x0, #0x0                   	// #0
    a2a8:	f8607841 	ldr	x1, [x2, x0, lsl #3]
    a2ac:	91000400 	add	x0, x0, #0x1
    a2b0:	f90006e1 	str	x1, [x23, #8]
    a2b4:	aa1703e1 	mov	x1, x23
    a2b8:	f9400af7 	ldr	x23, [x23, #16]
    a2bc:	eb00009f 	cmp	x4, x0
    a2c0:	54ffff48 	b.hi	a2a8 <fwp_hof0.constprop.0+0x1a08>  // b.pmore
    a2c4:	f9000823 	str	x3, [x1, #16]
    a2c8:	7100011f 	cmp	w8, #0x0
    a2cc:	9a8213e2 	csel	x2, xzr, x2, ne	// ne = any
    a2d0:	17fffeef 	b	9e8c <fwp_hof0.constprop.0+0x15ec>
    a2d4:	a9070fe0 	stp	x0, x3, [sp, #112]
    a2d8:	97ffe837 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a2dc:	a9470fe0 	ldp	x0, x3, [sp, #112]
    a2e0:	17fffe8b 	b	9d0c <fwp_hof0.constprop.0+0x146c>
    a2e4:	a9038be0 	stp	x0, x2, [sp, #56]
    a2e8:	97ffe833 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a2ec:	a9438be0 	ldp	x0, x2, [sp, #56]
    a2f0:	17fffe27 	b	9b8c <fwp_hof0.constprop.0+0x12ec>
    a2f4:	72003c3f 	tst	w1, #0xffff
    a2f8:	54ffc440 	b.eq	9b80 <fwp_hof0.constprop.0+0x12e0>  // b.none
    a2fc:	aa1703e0 	mov	x0, x23
    a300:	17fffd56 	b	9858 <fwp_hof0.constprop.0+0xfb8>
    a304:	a91253f3 	stp	x19, x20, [sp, #288]
    a308:	a9135bf5 	stp	x21, x22, [sp, #304]
    a30c:	a91463f7 	stp	x23, x24, [sp, #320]
    a310:	a9156bf9 	stp	x25, x26, [sp, #336]
    a314:	97ffe163 	bl	28a0 <__stack_chk_fail@plt>
    a318:	d2800004 	mov	x4, #0x0                   	// #0
    a31c:	17fffe63 	b	9ca8 <fwp_hof0.constprop.0+0x1408>
    a320:	aa1503e0 	mov	x0, x21
    a324:	97ffe824 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a328:	91014280 	add	x0, x20, #0x50
    a32c:	f941c804 	ldr	x4, [x0, #912]
    a330:	17fffd1f 	b	97ac <fwp_hof0.constprop.0+0xf0c>
    a334:	f9001fe0 	str	x0, [sp, #56]
    a338:	97ffe81f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a33c:	f9401fe0 	ldr	x0, [sp, #56]
    a340:	17fffddf 	b	9abc <fwp_hof0.constprop.0+0x121c>
    a344:	ca404401 	eor	x1, x0, x0, lsr #17
    a348:	9118c2c3 	add	x3, x22, #0x630
    a34c:	ca412421 	eor	x1, x1, x1, lsr #9
    a350:	92401c21 	and	x1, x1, #0xff
    a354:	910a2422 	add	x2, x1, #0x289
    a358:	8b010c61 	add	x1, x3, x1, lsl #3
    a35c:	8b020c62 	add	x2, x3, x2, lsl #3
    a360:	f94a2421 	ldr	x1, [x1, #5192]
    a364:	b4ffb2a1 	cbz	x1, 99b8 <fwp_hof0.constprop.0+0x1118>
    a368:	f9400023 	ldr	x3, [x1]
    a36c:	eb03001f 	cmp	x0, x3
    a370:	540003a0 	b.eq	a3e4 <fwp_hof0.constprop.0+0x1b44>  // b.none
    a374:	91004022 	add	x2, x1, #0x10
    a378:	f9400821 	ldr	x1, [x1, #16]
    a37c:	17fffffa 	b	a364 <fwp_hof0.constprop.0+0x1ac4>
    a380:	b5ffdd61 	cbnz	x1, 9f2c <fwp_hof0.constprop.0+0x168c>
    a384:	17ffff59 	b	a0e8 <fwp_hof0.constprop.0+0x1848>
    a388:	f94002a3 	ldr	x3, [x21]
    a38c:	b7f80083 	tbnz	x3, #63, a39c <fwp_hof0.constprop.0+0x1afc>
    a390:	9240f863 	and	x3, x3, #0x7fffffffffffffff
    a394:	d2800017 	mov	x23, #0x0                   	// #0
    a398:	17fffd4b 	b	98c4 <fwp_hof0.constprop.0+0x1024>
    a39c:	52800041 	mov	w1, #0x2                   	// #2
    a3a0:	d2800100 	mov	x0, #0x8                   	// #8
    a3a4:	97ffeb5b 	bl	5110 <fwp_heap_alloc>
    a3a8:	aa0003e2 	mov	x2, x0
    a3ac:	52800008 	mov	w8, #0x0                   	// #0
    a3b0:	aa1a03f7 	mov	x23, x26
    a3b4:	d280001a 	mov	x26, #0x0                   	// #0
    a3b8:	17ffffc4 	b	a2c8 <fwp_hof0.constprop.0+0x1a28>
    a3bc:	f94006b5 	ldr	x21, [x21, #8]
    a3c0:	7100087f 	cmp	w3, #0x2
    a3c4:	54000280 	b.eq	a414 <fwp_hof0.constprop.0+0x1b74>  // b.none
    a3c8:	29430903 	ldp	w3, w2, [x8, #24]
    a3cc:	9b037c21 	mul	x1, x1, x3
    a3d0:	eb41805f 	cmp	x2, x1, lsr #32
    a3d4:	54ffd6a9 	b.ls	9ea8 <fwp_hof0.constprop.0+0x1608>  // b.plast
    a3d8:	97ffe892 	bl	4620 <fwp_mem_free>
    a3dc:	d2800507 	mov	x7, #0x28                  	// #40
    a3e0:	17fffeb2 	b	9ea8 <fwp_hof0.constprop.0+0x1608>
    a3e4:	f9400042 	ldr	x2, [x2]
    a3e8:	f9400441 	ldr	x1, [x2, #8]
    a3ec:	d1000421 	sub	x1, x1, #0x1
    a3f0:	f9000441 	str	x1, [x2, #8]
    a3f4:	f103f83f 	cmp	x1, #0xfe
    a3f8:	54ffd9a1 	b.ne	9f2c <fwp_hof0.constprop.0+0x168c>  // b.any
    a3fc:	39400001 	ldrb	w1, [x0]
    a400:	7103fc3f 	cmp	w1, #0xff
    a404:	540000c0 	b.eq	a41c <fwp_hof0.constprop.0+0x1b7c>  // b.none
    a408:	12800021 	mov	w1, #0xfffffffe            	// #-2
    a40c:	39000001 	strb	w1, [x0]
    a410:	17fffec7 	b	9f2c <fwp_hof0.constprop.0+0x168c>
    a414:	b5ffd4a1 	cbnz	x1, 9ea8 <fwp_hof0.constprop.0+0x1608>
    a418:	17fffff0 	b	a3d8 <fwp_hof0.constprop.0+0x1b38>
    a41c:	f9001fe0 	str	x0, [sp, #56]
    a420:	97ffe7e5 	bl	43b4 <fwp_rc_forget_slot.part.0>
    a424:	f9401fe0 	ldr	x0, [sp, #56]
    a428:	17fffff8 	b	a408 <fwp_hof0.constprop.0+0x1b68>
    a42c:	97ffe195 	bl	2a80 <fwp_trap_overflow.constprop.0>
    a430:	97ffe130 	bl	28f0 <abort@plt>

000000000000a434 <f0>:
    a434:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a438:	910003fd 	mov	x29, sp
    a43c:	a90153f3 	stp	x19, x20, [sp, #16]
    a440:	a9025bf5 	stp	x21, x22, [sp, #32]
    a444:	a90363f7 	stp	x23, x24, [sp, #48]
    a448:	a9046bf9 	stp	x25, x26, [sp, #64]
    a44c:	a90573fb 	stp	x27, x28, [sp, #80]
    a450:	d121c3ff 	sub	sp, sp, #0x870
    a454:	f90203ff 	str	xzr, [sp, #1024]
    a458:	d00000a0 	adrp	x0, 20000 <__data_start>
    a45c:	91014003 	add	x3, x0, #0x50
    a460:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    a464:	f947f400 	ldr	x0, [x0, #4072]
    a468:	f0000374 	adrp	x20, 79000 <fwp_root_context+0xbb0>
    a46c:	f941c865 	ldr	x5, [x3, #912]
    a470:	f9400001 	ldr	x1, [x0]
    a474:	f90437e1 	str	x1, [sp, #2152]
    a478:	d2800001 	mov	x1, #0x0                   	// #0
    a47c:	9118c299 	add	x25, x20, #0x630
    a480:	912163f6 	add	x22, sp, #0x858
    a484:	910063e4 	add	x4, sp, #0x18
    a488:	9100c3e1 	add	x1, sp, #0x30
    a48c:	90ffffe0 	adrp	x0, 6000 <e173+0x6c>
    a490:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    a494:	91088000 	add	x0, x0, #0x220
    a498:	913d4042 	add	x2, x2, #0xf50
    a49c:	d2800013 	mov	x19, #0x0                   	// #0
    a4a0:	d280011a 	mov	x26, #0x8                   	// #8
    a4a4:	d2800015 	mov	x21, #0x0                   	// #0
    a4a8:	52800037 	mov	w23, #0x1                   	// #1
    a4ac:	f90007e4 	str	x4, [sp, #8]
    a4b0:	a9018be5 	stp	x5, x2, [sp, #24]
    a4b4:	a902ffe1 	stp	x1, xzr, [sp, #40]
    a4b8:	a90403ff 	stp	xzr, x0, [sp, #64]
    a4bc:	f901c864 	str	x4, [x3, #912]
    a4c0:	f100075b 	subs	x27, x26, #0x1
    a4c4:	aa1603e1 	mov	x1, x22
    a4c8:	da1f02b8 	sbc	x24, x21, xzr
    a4cc:	52800020 	mov	w0, #0x1                   	// #1
    a4d0:	f9001ffb 	str	x27, [sp, #56]
    a4d4:	aa1b03fa 	mov	x26, x27
    a4d8:	f9042ffb 	str	x27, [sp, #2136]
    a4dc:	aa1803f5 	mov	x21, x24
    a4e0:	f90433f3 	str	x19, [sp, #2144]
    a4e4:	97ffeb6f 	bl	52a0 <fwp_data.part.0.constprop.0>
    a4e8:	f949db22 	ldr	x2, [x25, #5040]
    a4ec:	aa0003f3 	mov	x19, x0
    a4f0:	f949ef20 	ldr	x0, [x25, #5080]
    a4f4:	cb020262 	sub	x2, x19, x2
    a4f8:	eb00405f 	cmp	x2, x0, lsl #16
    a4fc:	54000302 	b.cs	a55c <f0+0x128>  // b.hs, b.nlast
    a500:	d350fc40 	lsr	x0, x2, #16
    a504:	f949ff25 	ldr	x5, [x25, #5112]
    a508:	8b000800 	add	x0, x0, x0, lsl #2
    a50c:	d37df001 	lsl	x1, x0, #3
    a510:	8b0100a0 	add	x0, x5, x1
    a514:	f940101c 	ldr	x28, [x0, #32]
    a518:	b400023c 	cbz	x28, a55c <f0+0x128>
    a51c:	386168a1 	ldrb	w1, [x5, x1]
    a520:	7100083f 	cmp	w1, #0x2
    a524:	54010fc0 	b.eq	c71c <f0+0x22e8>  // b.none
    a528:	7100043f 	cmp	w1, #0x1
    a52c:	54000181 	b.ne	a55c <f0+0x128>  // b.any
    a530:	29430001 	ldp	w1, w0, [x0, #24]
    a534:	92403c42 	and	x2, x2, #0xffff
    a538:	9b017c42 	mul	x2, x2, x1
    a53c:	d360fc42 	lsr	x2, x2, #32
    a540:	eb00005f 	cmp	x2, x0
    a544:	540000c2 	b.cs	a55c <f0+0x128>  // b.hs, b.nlast
    a548:	8b02039c 	add	x28, x28, x2
    a54c:	39400380 	ldrb	w0, [x28]
    a550:	7103fc1f 	cmp	w0, #0xff
    a554:	54010de0 	b.eq	c710 <f0+0x22dc>  // b.none
    a558:	39000397 	strb	w23, [x28]
    a55c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    a560:	aa18037b 	orr	x27, x27, x24
    a564:	b5fffafb 	cbnz	x27, a4c0 <f0+0x8c>
    a568:	d00000a0 	adrp	x0, 20000 <__data_start>
    a56c:	91014018 	add	x24, x0, #0x50
    a570:	f94007e1 	ldr	x1, [sp, #8]
    a574:	f9001bff 	str	xzr, [sp, #48]
    a578:	f941cb00 	ldr	x0, [x24, #912]
    a57c:	eb01001f 	cmp	x0, x1
    a580:	54012aa1 	b.ne	cad4 <f0+0x26a0>  // b.any
    a584:	90000023 	adrp	x3, e000 <_IO_stdin_used+0x870>
    a588:	910143e1 	add	x1, sp, #0x50
    a58c:	f9400fe2 	ldr	x2, [sp, #24]
    a590:	52800020 	mov	w0, #0x1                   	// #1
    a594:	3dc1dc60 	ldr	q0, [x3, #1904]
    a598:	f901cb02 	str	x2, [x24, #912]
    a59c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a5a0:	3d8017e0 	str	q0, [sp, #80]
    a5a4:	97ffeb3f 	bl	52a0 <fwp_data.part.0.constprop.0>
    a5a8:	97ffedb6 	bl	5c80 <fwp_rc_fresh>
    a5ac:	9101a3e1 	add	x1, sp, #0x68
    a5b0:	aa0003e2 	mov	x2, x0
    a5b4:	52800020 	mov	w0, #0x1                   	// #1
    a5b8:	a9068bf5 	stp	x21, x2, [sp, #104]
    a5bc:	97ffeb39 	bl	52a0 <fwp_data.part.0.constprop.0>
    a5c0:	97ffedb0 	bl	5c80 <fwp_rc_fresh>
    a5c4:	aa0003e2 	mov	x2, x0
    a5c8:	9101e3e1 	add	x1, sp, #0x78
    a5cc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a5d0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a5d4:	52800020 	mov	w0, #0x1                   	// #1
    a5d8:	a9078be3 	stp	x3, x2, [sp, #120]
    a5dc:	97ffeb31 	bl	52a0 <fwp_data.part.0.constprop.0>
    a5e0:	97ffeda8 	bl	5c80 <fwp_rc_fresh>
    a5e4:	aa0003e2 	mov	x2, x0
    a5e8:	910223e1 	add	x1, sp, #0x88
    a5ec:	52800020 	mov	w0, #0x1                   	// #1
    a5f0:	a9088bf5 	stp	x21, x2, [sp, #136]
    a5f4:	97ffeb2b 	bl	52a0 <fwp_data.part.0.constprop.0>
    a5f8:	97ffeda2 	bl	5c80 <fwp_rc_fresh>
    a5fc:	aa0003e2 	mov	x2, x0
    a600:	910263e1 	add	x1, sp, #0x98
    a604:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a608:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a60c:	52800020 	mov	w0, #0x1                   	// #1
    a610:	a9098be3 	stp	x3, x2, [sp, #152]
    a614:	97ffeb23 	bl	52a0 <fwp_data.part.0.constprop.0>
    a618:	97ffed9a 	bl	5c80 <fwp_rc_fresh>
    a61c:	aa0003e2 	mov	x2, x0
    a620:	9102a3e1 	add	x1, sp, #0xa8
    a624:	52800020 	mov	w0, #0x1                   	// #1
    a628:	a90a8bf5 	stp	x21, x2, [sp, #168]
    a62c:	97ffeb1d 	bl	52a0 <fwp_data.part.0.constprop.0>
    a630:	97ffed94 	bl	5c80 <fwp_rc_fresh>
    a634:	aa0003e2 	mov	x2, x0
    a638:	9102e3e1 	add	x1, sp, #0xb8
    a63c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a640:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a644:	52800020 	mov	w0, #0x1                   	// #1
    a648:	a90b8be3 	stp	x3, x2, [sp, #184]
    a64c:	97ffeb15 	bl	52a0 <fwp_data.part.0.constprop.0>
    a650:	97ffed8c 	bl	5c80 <fwp_rc_fresh>
    a654:	aa0003e2 	mov	x2, x0
    a658:	910323e1 	add	x1, sp, #0xc8
    a65c:	52800020 	mov	w0, #0x1                   	// #1
    a660:	a90c8bf5 	stp	x21, x2, [sp, #200]
    a664:	97ffeb0f 	bl	52a0 <fwp_data.part.0.constprop.0>
    a668:	97ffed86 	bl	5c80 <fwp_rc_fresh>
    a66c:	aa0003e2 	mov	x2, x0
    a670:	910363e1 	add	x1, sp, #0xd8
    a674:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a678:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a67c:	52800020 	mov	w0, #0x1                   	// #1
    a680:	a90d8be3 	stp	x3, x2, [sp, #216]
    a684:	97ffeb07 	bl	52a0 <fwp_data.part.0.constprop.0>
    a688:	97ffed7e 	bl	5c80 <fwp_rc_fresh>
    a68c:	aa0003e2 	mov	x2, x0
    a690:	9103a3e1 	add	x1, sp, #0xe8
    a694:	52800020 	mov	w0, #0x1                   	// #1
    a698:	a90e8bf5 	stp	x21, x2, [sp, #232]
    a69c:	97ffeb01 	bl	52a0 <fwp_data.part.0.constprop.0>
    a6a0:	97ffed78 	bl	5c80 <fwp_rc_fresh>
    a6a4:	aa0003e2 	mov	x2, x0
    a6a8:	9103e3e1 	add	x1, sp, #0xf8
    a6ac:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a6b0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a6b4:	52800020 	mov	w0, #0x1                   	// #1
    a6b8:	a90f8be3 	stp	x3, x2, [sp, #248]
    a6bc:	97ffeaf9 	bl	52a0 <fwp_data.part.0.constprop.0>
    a6c0:	97ffed70 	bl	5c80 <fwp_rc_fresh>
    a6c4:	aa0003e2 	mov	x2, x0
    a6c8:	910423e1 	add	x1, sp, #0x108
    a6cc:	52800020 	mov	w0, #0x1                   	// #1
    a6d0:	a9108bf5 	stp	x21, x2, [sp, #264]
    a6d4:	97ffeaf3 	bl	52a0 <fwp_data.part.0.constprop.0>
    a6d8:	97ffed6a 	bl	5c80 <fwp_rc_fresh>
    a6dc:	aa0003e2 	mov	x2, x0
    a6e0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a6e4:	910463e1 	add	x1, sp, #0x118
    a6e8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a6ec:	52800020 	mov	w0, #0x1                   	// #1
    a6f0:	a9118be3 	stp	x3, x2, [sp, #280]
    a6f4:	97ffeaeb 	bl	52a0 <fwp_data.part.0.constprop.0>
    a6f8:	9118c283 	add	x3, x20, #0x630
    a6fc:	aa0003f5 	mov	x21, x0
    a700:	f949d861 	ldr	x1, [x3, #5040]
    a704:	f949ec60 	ldr	x0, [x3, #5080]
    a708:	cb0102a1 	sub	x1, x21, x1
    a70c:	eb00403f 	cmp	x1, x0, lsl #16
    a710:	54000322 	b.cs	a774 <f0+0x340>  // b.hs, b.nlast
    a714:	d350fc22 	lsr	x2, x1, #16
    a718:	f949fc63 	ldr	x3, [x3, #5112]
    a71c:	8b020842 	add	x2, x2, x2, lsl #2
    a720:	d37df042 	lsl	x2, x2, #3
    a724:	8b020060 	add	x0, x3, x2
    a728:	f9401017 	ldr	x23, [x0, #32]
    a72c:	b4000257 	cbz	x23, a774 <f0+0x340>
    a730:	38626862 	ldrb	w2, [x3, x2]
    a734:	7100085f 	cmp	w2, #0x2
    a738:	5400ff80 	b.eq	c728 <f0+0x22f4>  // b.none
    a73c:	7100045f 	cmp	w2, #0x1
    a740:	540001a1 	b.ne	a774 <f0+0x340>  // b.any
    a744:	29430002 	ldp	w2, w0, [x0, #24]
    a748:	92403c21 	and	x1, x1, #0xffff
    a74c:	9b027c21 	mul	x1, x1, x2
    a750:	d360fc21 	lsr	x1, x1, #32
    a754:	eb00003f 	cmp	x1, x0
    a758:	540000e2 	b.cs	a774 <f0+0x340>  // b.hs, b.nlast
    a75c:	8b0102f7 	add	x23, x23, x1
    a760:	394002e0 	ldrb	w0, [x23]
    a764:	7103fc1f 	cmp	w0, #0xff
    a768:	54010d00 	b.eq	c908 <f0+0x24d4>  // b.none
    a76c:	52800020 	mov	w0, #0x1                   	// #1
    a770:	390002e0 	strb	w0, [x23]
    a774:	9104a3e1 	add	x1, sp, #0x128
    a778:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a77c:	52800020 	mov	w0, #0x1                   	// #1
    a780:	a912d7e2 	stp	x2, x21, [sp, #296]
    a784:	97ffeac7 	bl	52a0 <fwp_data.part.0.constprop.0>
    a788:	97ffed3e 	bl	5c80 <fwp_rc_fresh>
    a78c:	aa0003e2 	mov	x2, x0
    a790:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a794:	9104e3e1 	add	x1, sp, #0x138
    a798:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a79c:	52800020 	mov	w0, #0x1                   	// #1
    a7a0:	a9138be3 	stp	x3, x2, [sp, #312]
    a7a4:	97ffeabf 	bl	52a0 <fwp_data.part.0.constprop.0>
    a7a8:	9118c283 	add	x3, x20, #0x630
    a7ac:	aa0003f5 	mov	x21, x0
    a7b0:	f949d861 	ldr	x1, [x3, #5040]
    a7b4:	f949ec60 	ldr	x0, [x3, #5080]
    a7b8:	cb0102a1 	sub	x1, x21, x1
    a7bc:	eb00403f 	cmp	x1, x0, lsl #16
    a7c0:	54000322 	b.cs	a824 <f0+0x3f0>  // b.hs, b.nlast
    a7c4:	d350fc22 	lsr	x2, x1, #16
    a7c8:	f949fc63 	ldr	x3, [x3, #5112]
    a7cc:	8b020842 	add	x2, x2, x2, lsl #2
    a7d0:	d37df042 	lsl	x2, x2, #3
    a7d4:	8b020060 	add	x0, x3, x2
    a7d8:	f9401017 	ldr	x23, [x0, #32]
    a7dc:	b4000257 	cbz	x23, a824 <f0+0x3f0>
    a7e0:	38626862 	ldrb	w2, [x3, x2]
    a7e4:	7100085f 	cmp	w2, #0x2
    a7e8:	5400fac0 	b.eq	c740 <f0+0x230c>  // b.none
    a7ec:	7100045f 	cmp	w2, #0x1
    a7f0:	540001a1 	b.ne	a824 <f0+0x3f0>  // b.any
    a7f4:	29430002 	ldp	w2, w0, [x0, #24]
    a7f8:	92403c21 	and	x1, x1, #0xffff
    a7fc:	9b027c21 	mul	x1, x1, x2
    a800:	d360fc21 	lsr	x1, x1, #32
    a804:	eb00003f 	cmp	x1, x0
    a808:	540000e2 	b.cs	a824 <f0+0x3f0>  // b.hs, b.nlast
    a80c:	8b0102f7 	add	x23, x23, x1
    a810:	394002e0 	ldrb	w0, [x23]
    a814:	7103fc1f 	cmp	w0, #0xff
    a818:	540107e0 	b.eq	c914 <f0+0x24e0>  // b.none
    a81c:	52800020 	mov	w0, #0x1                   	// #1
    a820:	390002e0 	strb	w0, [x23]
    a824:	910523e1 	add	x1, sp, #0x148
    a828:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a82c:	52800020 	mov	w0, #0x1                   	// #1
    a830:	a914d7f7 	stp	x23, x21, [sp, #328]
    a834:	97ffea9b 	bl	52a0 <fwp_data.part.0.constprop.0>
    a838:	97ffed12 	bl	5c80 <fwp_rc_fresh>
    a83c:	aa0003e2 	mov	x2, x0
    a840:	910563e1 	add	x1, sp, #0x158
    a844:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a848:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a84c:	52800020 	mov	w0, #0x1                   	// #1
    a850:	a9158bf5 	stp	x21, x2, [sp, #344]
    a854:	97ffea93 	bl	52a0 <fwp_data.part.0.constprop.0>
    a858:	97ffed0a 	bl	5c80 <fwp_rc_fresh>
    a85c:	aa0003e2 	mov	x2, x0
    a860:	9105a3e1 	add	x1, sp, #0x168
    a864:	52800020 	mov	w0, #0x1                   	// #1
    a868:	a9168bf7 	stp	x23, x2, [sp, #360]
    a86c:	97ffea8d 	bl	52a0 <fwp_data.part.0.constprop.0>
    a870:	97ffed04 	bl	5c80 <fwp_rc_fresh>
    a874:	aa0003e2 	mov	x2, x0
    a878:	9105e3e1 	add	x1, sp, #0x178
    a87c:	52800020 	mov	w0, #0x1                   	// #1
    a880:	a9178bf5 	stp	x21, x2, [sp, #376]
    a884:	97ffea87 	bl	52a0 <fwp_data.part.0.constprop.0>
    a888:	9118c283 	add	x3, x20, #0x630
    a88c:	aa0003f5 	mov	x21, x0
    a890:	f949d861 	ldr	x1, [x3, #5040]
    a894:	f949ec60 	ldr	x0, [x3, #5080]
    a898:	cb0102a1 	sub	x1, x21, x1
    a89c:	eb00403f 	cmp	x1, x0, lsl #16
    a8a0:	54000322 	b.cs	a904 <f0+0x4d0>  // b.hs, b.nlast
    a8a4:	d350fc22 	lsr	x2, x1, #16
    a8a8:	f949fc63 	ldr	x3, [x3, #5112]
    a8ac:	8b020842 	add	x2, x2, x2, lsl #2
    a8b0:	d37df042 	lsl	x2, x2, #3
    a8b4:	8b020060 	add	x0, x3, x2
    a8b8:	f9401017 	ldr	x23, [x0, #32]
    a8bc:	b4000257 	cbz	x23, a904 <f0+0x4d0>
    a8c0:	38626862 	ldrb	w2, [x3, x2]
    a8c4:	7100085f 	cmp	w2, #0x2
    a8c8:	5400f360 	b.eq	c734 <f0+0x2300>  // b.none
    a8cc:	7100045f 	cmp	w2, #0x1
    a8d0:	540001a1 	b.ne	a904 <f0+0x4d0>  // b.any
    a8d4:	29430002 	ldp	w2, w0, [x0, #24]
    a8d8:	92403c21 	and	x1, x1, #0xffff
    a8dc:	9b027c21 	mul	x1, x1, x2
    a8e0:	d360fc21 	lsr	x1, x1, #32
    a8e4:	eb00003f 	cmp	x1, x0
    a8e8:	540000e2 	b.cs	a904 <f0+0x4d0>  // b.hs, b.nlast
    a8ec:	8b0102f7 	add	x23, x23, x1
    a8f0:	394002e0 	ldrb	w0, [x23]
    a8f4:	7103fc1f 	cmp	w0, #0xff
    a8f8:	54010140 	b.eq	c920 <f0+0x24ec>  // b.none
    a8fc:	52800020 	mov	w0, #0x1                   	// #1
    a900:	390002e0 	strb	w0, [x23]
    a904:	910623e1 	add	x1, sp, #0x188
    a908:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a90c:	52800020 	mov	w0, #0x1                   	// #1
    a910:	a918d7f7 	stp	x23, x21, [sp, #392]
    a914:	97ffea63 	bl	52a0 <fwp_data.part.0.constprop.0>
    a918:	97ffecda 	bl	5c80 <fwp_rc_fresh>
    a91c:	aa0003e2 	mov	x2, x0
    a920:	910663e1 	add	x1, sp, #0x198
    a924:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a928:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a92c:	52800020 	mov	w0, #0x1                   	// #1
    a930:	a9198bf5 	stp	x21, x2, [sp, #408]
    a934:	97ffea5b 	bl	52a0 <fwp_data.part.0.constprop.0>
    a938:	97ffecd2 	bl	5c80 <fwp_rc_fresh>
    a93c:	aa0003e2 	mov	x2, x0
    a940:	9106a3e1 	add	x1, sp, #0x1a8
    a944:	52800020 	mov	w0, #0x1                   	// #1
    a948:	a91a8bf7 	stp	x23, x2, [sp, #424]
    a94c:	97ffea55 	bl	52a0 <fwp_data.part.0.constprop.0>
    a950:	97ffeccc 	bl	5c80 <fwp_rc_fresh>
    a954:	aa0003e2 	mov	x2, x0
    a958:	9106e3e1 	add	x1, sp, #0x1b8
    a95c:	52800020 	mov	w0, #0x1                   	// #1
    a960:	a91b8bf5 	stp	x21, x2, [sp, #440]
    a964:	97ffea4f 	bl	52a0 <fwp_data.part.0.constprop.0>
    a968:	9118c283 	add	x3, x20, #0x630
    a96c:	aa0003f5 	mov	x21, x0
    a970:	f949d861 	ldr	x1, [x3, #5040]
    a974:	f949ec60 	ldr	x0, [x3, #5080]
    a978:	cb0102a1 	sub	x1, x21, x1
    a97c:	eb00403f 	cmp	x1, x0, lsl #16
    a980:	54000322 	b.cs	a9e4 <f0+0x5b0>  // b.hs, b.nlast
    a984:	d350fc22 	lsr	x2, x1, #16
    a988:	f949fc63 	ldr	x3, [x3, #5112]
    a98c:	8b020842 	add	x2, x2, x2, lsl #2
    a990:	d37df042 	lsl	x2, x2, #3
    a994:	8b020060 	add	x0, x3, x2
    a998:	f9401017 	ldr	x23, [x0, #32]
    a99c:	b4000257 	cbz	x23, a9e4 <f0+0x5b0>
    a9a0:	38626862 	ldrb	w2, [x3, x2]
    a9a4:	7100085f 	cmp	w2, #0x2
    a9a8:	5400ed80 	b.eq	c758 <f0+0x2324>  // b.none
    a9ac:	7100045f 	cmp	w2, #0x1
    a9b0:	540001a1 	b.ne	a9e4 <f0+0x5b0>  // b.any
    a9b4:	29430002 	ldp	w2, w0, [x0, #24]
    a9b8:	92403c21 	and	x1, x1, #0xffff
    a9bc:	9b027c21 	mul	x1, x1, x2
    a9c0:	d360fc21 	lsr	x1, x1, #32
    a9c4:	eb00003f 	cmp	x1, x0
    a9c8:	540000e2 	b.cs	a9e4 <f0+0x5b0>  // b.hs, b.nlast
    a9cc:	8b0102f7 	add	x23, x23, x1
    a9d0:	394002e0 	ldrb	w0, [x23]
    a9d4:	7103fc1f 	cmp	w0, #0xff
    a9d8:	5400faa0 	b.eq	c92c <f0+0x24f8>  // b.none
    a9dc:	52800020 	mov	w0, #0x1                   	// #1
    a9e0:	390002e0 	strb	w0, [x23]
    a9e4:	910723e1 	add	x1, sp, #0x1c8
    a9e8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a9ec:	52800020 	mov	w0, #0x1                   	// #1
    a9f0:	a91cd7e2 	stp	x2, x21, [sp, #456]
    a9f4:	97ffea2b 	bl	52a0 <fwp_data.part.0.constprop.0>
    a9f8:	97ffeca2 	bl	5c80 <fwp_rc_fresh>
    a9fc:	aa0003e2 	mov	x2, x0
    aa00:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aa04:	910763e1 	add	x1, sp, #0x1d8
    aa08:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aa0c:	52800020 	mov	w0, #0x1                   	// #1
    aa10:	a91d8be3 	stp	x3, x2, [sp, #472]
    aa14:	97ffea23 	bl	52a0 <fwp_data.part.0.constprop.0>
    aa18:	9118c283 	add	x3, x20, #0x630
    aa1c:	aa0003f5 	mov	x21, x0
    aa20:	f949d861 	ldr	x1, [x3, #5040]
    aa24:	f949ec60 	ldr	x0, [x3, #5080]
    aa28:	cb0102a1 	sub	x1, x21, x1
    aa2c:	eb00403f 	cmp	x1, x0, lsl #16
    aa30:	54000322 	b.cs	aa94 <f0+0x660>  // b.hs, b.nlast
    aa34:	d350fc22 	lsr	x2, x1, #16
    aa38:	f949fc63 	ldr	x3, [x3, #5112]
    aa3c:	8b020842 	add	x2, x2, x2, lsl #2
    aa40:	d37df042 	lsl	x2, x2, #3
    aa44:	8b020060 	add	x0, x3, x2
    aa48:	f9401017 	ldr	x23, [x0, #32]
    aa4c:	b4000257 	cbz	x23, aa94 <f0+0x660>
    aa50:	38626862 	ldrb	w2, [x3, x2]
    aa54:	7100085f 	cmp	w2, #0x2
    aa58:	5400e7a0 	b.eq	c74c <f0+0x2318>  // b.none
    aa5c:	7100045f 	cmp	w2, #0x1
    aa60:	540001a1 	b.ne	aa94 <f0+0x660>  // b.any
    aa64:	29430002 	ldp	w2, w0, [x0, #24]
    aa68:	92403c21 	and	x1, x1, #0xffff
    aa6c:	9b027c21 	mul	x1, x1, x2
    aa70:	d360fc21 	lsr	x1, x1, #32
    aa74:	eb00003f 	cmp	x1, x0
    aa78:	540000e2 	b.cs	aa94 <f0+0x660>  // b.hs, b.nlast
    aa7c:	8b0102f7 	add	x23, x23, x1
    aa80:	394002e0 	ldrb	w0, [x23]
    aa84:	7103fc1f 	cmp	w0, #0xff
    aa88:	5400f580 	b.eq	c938 <f0+0x2504>  // b.none
    aa8c:	52800020 	mov	w0, #0x1                   	// #1
    aa90:	390002e0 	strb	w0, [x23]
    aa94:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aa98:	9107a3e1 	add	x1, sp, #0x1e8
    aa9c:	52800020 	mov	w0, #0x1                   	// #1
    aaa0:	a91ed7e2 	stp	x2, x21, [sp, #488]
    aaa4:	97ffe9ff 	bl	52a0 <fwp_data.part.0.constprop.0>
    aaa8:	9118c283 	add	x3, x20, #0x630
    aaac:	aa0003f5 	mov	x21, x0
    aab0:	f949d861 	ldr	x1, [x3, #5040]
    aab4:	f949ec60 	ldr	x0, [x3, #5080]
    aab8:	cb0102a1 	sub	x1, x21, x1
    aabc:	eb00403f 	cmp	x1, x0, lsl #16
    aac0:	54000322 	b.cs	ab24 <f0+0x6f0>  // b.hs, b.nlast
    aac4:	d350fc22 	lsr	x2, x1, #16
    aac8:	f949fc63 	ldr	x3, [x3, #5112]
    aacc:	8b020842 	add	x2, x2, x2, lsl #2
    aad0:	d37df042 	lsl	x2, x2, #3
    aad4:	8b020060 	add	x0, x3, x2
    aad8:	f9401017 	ldr	x23, [x0, #32]
    aadc:	b4000257 	cbz	x23, ab24 <f0+0x6f0>
    aae0:	38626862 	ldrb	w2, [x3, x2]
    aae4:	7100085f 	cmp	w2, #0x2
    aae8:	5400e440 	b.eq	c770 <f0+0x233c>  // b.none
    aaec:	7100045f 	cmp	w2, #0x1
    aaf0:	540001a1 	b.ne	ab24 <f0+0x6f0>  // b.any
    aaf4:	29430002 	ldp	w2, w0, [x0, #24]
    aaf8:	92403c21 	and	x1, x1, #0xffff
    aafc:	9b027c21 	mul	x1, x1, x2
    ab00:	d360fc21 	lsr	x1, x1, #32
    ab04:	eb00003f 	cmp	x1, x0
    ab08:	540000e2 	b.cs	ab24 <f0+0x6f0>  // b.hs, b.nlast
    ab0c:	8b0102f7 	add	x23, x23, x1
    ab10:	394002e0 	ldrb	w0, [x23]
    ab14:	7103fc1f 	cmp	w0, #0xff
    ab18:	5400f160 	b.eq	c944 <f0+0x2510>  // b.none
    ab1c:	52800020 	mov	w0, #0x1                   	// #1
    ab20:	390002e0 	strb	w0, [x23]
    ab24:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ab28:	9107e3e1 	add	x1, sp, #0x1f8
    ab2c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ab30:	52800020 	mov	w0, #0x1                   	// #1
    ab34:	a91fd7e2 	stp	x2, x21, [sp, #504]
    ab38:	97ffe9da 	bl	52a0 <fwp_data.part.0.constprop.0>
    ab3c:	9118c283 	add	x3, x20, #0x630
    ab40:	aa0003f7 	mov	x23, x0
    ab44:	f949d861 	ldr	x1, [x3, #5040]
    ab48:	f949ec60 	ldr	x0, [x3, #5080]
    ab4c:	cb0102e1 	sub	x1, x23, x1
    ab50:	eb00403f 	cmp	x1, x0, lsl #16
    ab54:	54000322 	b.cs	abb8 <f0+0x784>  // b.hs, b.nlast
    ab58:	d350fc22 	lsr	x2, x1, #16
    ab5c:	f949fc63 	ldr	x3, [x3, #5112]
    ab60:	8b020842 	add	x2, x2, x2, lsl #2
    ab64:	d37df042 	lsl	x2, x2, #3
    ab68:	8b020060 	add	x0, x3, x2
    ab6c:	f9401015 	ldr	x21, [x0, #32]
    ab70:	b4000255 	cbz	x21, abb8 <f0+0x784>
    ab74:	38626862 	ldrb	w2, [x3, x2]
    ab78:	7100085f 	cmp	w2, #0x2
    ab7c:	5400df40 	b.eq	c764 <f0+0x2330>  // b.none
    ab80:	7100045f 	cmp	w2, #0x1
    ab84:	540001a1 	b.ne	abb8 <f0+0x784>  // b.any
    ab88:	29430002 	ldp	w2, w0, [x0, #24]
    ab8c:	92403c21 	and	x1, x1, #0xffff
    ab90:	9b027c21 	mul	x1, x1, x2
    ab94:	d360fc21 	lsr	x1, x1, #32
    ab98:	eb00003f 	cmp	x1, x0
    ab9c:	540000e2 	b.cs	abb8 <f0+0x784>  // b.hs, b.nlast
    aba0:	8b0102b5 	add	x21, x21, x1
    aba4:	394002a0 	ldrb	w0, [x21]
    aba8:	7103fc1f 	cmp	w0, #0xff
    abac:	5400ed20 	b.eq	c950 <f0+0x251c>  // b.none
    abb0:	52800020 	mov	w0, #0x1                   	// #1
    abb4:	390002a0 	strb	w0, [x21]
    abb8:	910823e1 	add	x1, sp, #0x208
    abbc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    abc0:	52800020 	mov	w0, #0x1                   	// #1
    abc4:	f90107f5 	str	x21, [sp, #520]
    abc8:	f9010bf7 	str	x23, [sp, #528]
    abcc:	97ffe9b5 	bl	52a0 <fwp_data.part.0.constprop.0>
    abd0:	97ffec2c 	bl	5c80 <fwp_rc_fresh>
    abd4:	aa0003e2 	mov	x2, x0
    abd8:	910863e1 	add	x1, sp, #0x218
    abdc:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    abe0:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    abe4:	52800020 	mov	w0, #0x1                   	// #1
    abe8:	f9010ff7 	str	x23, [sp, #536]
    abec:	f90113e2 	str	x2, [sp, #544]
    abf0:	97ffe9ac 	bl	52a0 <fwp_data.part.0.constprop.0>
    abf4:	97ffec23 	bl	5c80 <fwp_rc_fresh>
    abf8:	aa0003e2 	mov	x2, x0
    abfc:	9108a3e1 	add	x1, sp, #0x228
    ac00:	52800020 	mov	w0, #0x1                   	// #1
    ac04:	f90117f5 	str	x21, [sp, #552]
    ac08:	f9011be2 	str	x2, [sp, #560]
    ac0c:	97ffe9a5 	bl	52a0 <fwp_data.part.0.constprop.0>
    ac10:	97ffec1c 	bl	5c80 <fwp_rc_fresh>
    ac14:	aa0003e2 	mov	x2, x0
    ac18:	9108e3e1 	add	x1, sp, #0x238
    ac1c:	52800020 	mov	w0, #0x1                   	// #1
    ac20:	f9011ff7 	str	x23, [sp, #568]
    ac24:	f90123e2 	str	x2, [sp, #576]
    ac28:	97ffe99e 	bl	52a0 <fwp_data.part.0.constprop.0>
    ac2c:	97ffec15 	bl	5c80 <fwp_rc_fresh>
    ac30:	aa0003e2 	mov	x2, x0
    ac34:	910923e1 	add	x1, sp, #0x248
    ac38:	52800020 	mov	w0, #0x1                   	// #1
    ac3c:	f90127f5 	str	x21, [sp, #584]
    ac40:	f9012be2 	str	x2, [sp, #592]
    ac44:	97ffe997 	bl	52a0 <fwp_data.part.0.constprop.0>
    ac48:	97ffec0e 	bl	5c80 <fwp_rc_fresh>
    ac4c:	aa0003e2 	mov	x2, x0
    ac50:	910963e1 	add	x1, sp, #0x258
    ac54:	52800020 	mov	w0, #0x1                   	// #1
    ac58:	f9012ff7 	str	x23, [sp, #600]
    ac5c:	f90133e2 	str	x2, [sp, #608]
    ac60:	97ffe990 	bl	52a0 <fwp_data.part.0.constprop.0>
    ac64:	97ffec07 	bl	5c80 <fwp_rc_fresh>
    ac68:	aa0003e2 	mov	x2, x0
    ac6c:	9109a3e1 	add	x1, sp, #0x268
    ac70:	52800020 	mov	w0, #0x1                   	// #1
    ac74:	f90137f5 	str	x21, [sp, #616]
    ac78:	f9013be2 	str	x2, [sp, #624]
    ac7c:	97ffe989 	bl	52a0 <fwp_data.part.0.constprop.0>
    ac80:	9118c283 	add	x3, x20, #0x630
    ac84:	aa0003f5 	mov	x21, x0
    ac88:	f949d861 	ldr	x1, [x3, #5040]
    ac8c:	f949ec60 	ldr	x0, [x3, #5080]
    ac90:	cb0102a1 	sub	x1, x21, x1
    ac94:	eb00403f 	cmp	x1, x0, lsl #16
    ac98:	54000322 	b.cs	acfc <f0+0x8c8>  // b.hs, b.nlast
    ac9c:	d350fc22 	lsr	x2, x1, #16
    aca0:	f949fc63 	ldr	x3, [x3, #5112]
    aca4:	8b020842 	add	x2, x2, x2, lsl #2
    aca8:	d37df042 	lsl	x2, x2, #3
    acac:	8b020060 	add	x0, x3, x2
    acb0:	f9401017 	ldr	x23, [x0, #32]
    acb4:	b4000257 	cbz	x23, acfc <f0+0x8c8>
    acb8:	38626862 	ldrb	w2, [x3, x2]
    acbc:	7100085f 	cmp	w2, #0x2
    acc0:	5400dc40 	b.eq	c848 <f0+0x2414>  // b.none
    acc4:	7100045f 	cmp	w2, #0x1
    acc8:	540001a1 	b.ne	acfc <f0+0x8c8>  // b.any
    accc:	29430002 	ldp	w2, w0, [x0, #24]
    acd0:	92403c21 	and	x1, x1, #0xffff
    acd4:	9b027c21 	mul	x1, x1, x2
    acd8:	d360fc21 	lsr	x1, x1, #32
    acdc:	eb00003f 	cmp	x1, x0
    ace0:	540000e2 	b.cs	acfc <f0+0x8c8>  // b.hs, b.nlast
    ace4:	8b0102f7 	add	x23, x23, x1
    ace8:	394002e0 	ldrb	w0, [x23]
    acec:	7103fc1f 	cmp	w0, #0xff
    acf0:	5400e360 	b.eq	c95c <f0+0x2528>  // b.none
    acf4:	52800020 	mov	w0, #0x1                   	// #1
    acf8:	390002e0 	strb	w0, [x23]
    acfc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ad00:	9109e3e1 	add	x1, sp, #0x278
    ad04:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ad08:	52800020 	mov	w0, #0x1                   	// #1
    ad0c:	f9013fe2 	str	x2, [sp, #632]
    ad10:	f90143f5 	str	x21, [sp, #640]
    ad14:	97ffe963 	bl	52a0 <fwp_data.part.0.constprop.0>
    ad18:	9118c283 	add	x3, x20, #0x630
    ad1c:	aa0003f5 	mov	x21, x0
    ad20:	f949d861 	ldr	x1, [x3, #5040]
    ad24:	f949ec60 	ldr	x0, [x3, #5080]
    ad28:	cb0102a1 	sub	x1, x21, x1
    ad2c:	eb00403f 	cmp	x1, x0, lsl #16
    ad30:	54000322 	b.cs	ad94 <f0+0x960>  // b.hs, b.nlast
    ad34:	d350fc22 	lsr	x2, x1, #16
    ad38:	f949fc63 	ldr	x3, [x3, #5112]
    ad3c:	8b020842 	add	x2, x2, x2, lsl #2
    ad40:	d37df042 	lsl	x2, x2, #3
    ad44:	8b020060 	add	x0, x3, x2
    ad48:	f9401017 	ldr	x23, [x0, #32]
    ad4c:	b4000257 	cbz	x23, ad94 <f0+0x960>
    ad50:	38626862 	ldrb	w2, [x3, x2]
    ad54:	7100085f 	cmp	w2, #0x2
    ad58:	5400d720 	b.eq	c83c <f0+0x2408>  // b.none
    ad5c:	7100045f 	cmp	w2, #0x1
    ad60:	540001a1 	b.ne	ad94 <f0+0x960>  // b.any
    ad64:	29430002 	ldp	w2, w0, [x0, #24]
    ad68:	92403c21 	and	x1, x1, #0xffff
    ad6c:	9b027c21 	mul	x1, x1, x2
    ad70:	d360fc21 	lsr	x1, x1, #32
    ad74:	eb00003f 	cmp	x1, x0
    ad78:	540000e2 	b.cs	ad94 <f0+0x960>  // b.hs, b.nlast
    ad7c:	8b0102f7 	add	x23, x23, x1
    ad80:	394002e0 	ldrb	w0, [x23]
    ad84:	7103fc1f 	cmp	w0, #0xff
    ad88:	5400df00 	b.eq	c968 <f0+0x2534>  // b.none
    ad8c:	52800020 	mov	w0, #0x1                   	// #1
    ad90:	390002e0 	strb	w0, [x23]
    ad94:	910a23e1 	add	x1, sp, #0x288
    ad98:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ad9c:	52800020 	mov	w0, #0x1                   	// #1
    ada0:	f90147e2 	str	x2, [sp, #648]
    ada4:	f9014bf5 	str	x21, [sp, #656]
    ada8:	97ffe93e 	bl	52a0 <fwp_data.part.0.constprop.0>
    adac:	97ffebb5 	bl	5c80 <fwp_rc_fresh>
    adb0:	aa0003e2 	mov	x2, x0
    adb4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    adb8:	910a63e1 	add	x1, sp, #0x298
    adbc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    adc0:	52800020 	mov	w0, #0x1                   	// #1
    adc4:	f9014fe3 	str	x3, [sp, #664]
    adc8:	f90153e2 	str	x2, [sp, #672]
    adcc:	97ffe935 	bl	52a0 <fwp_data.part.0.constprop.0>
    add0:	9118c283 	add	x3, x20, #0x630
    add4:	aa0003f5 	mov	x21, x0
    add8:	f949d861 	ldr	x1, [x3, #5040]
    addc:	f949ec60 	ldr	x0, [x3, #5080]
    ade0:	cb0102a1 	sub	x1, x21, x1
    ade4:	eb00403f 	cmp	x1, x0, lsl #16
    ade8:	54000322 	b.cs	ae4c <f0+0xa18>  // b.hs, b.nlast
    adec:	d350fc22 	lsr	x2, x1, #16
    adf0:	f949fc63 	ldr	x3, [x3, #5112]
    adf4:	8b020842 	add	x2, x2, x2, lsl #2
    adf8:	d37df042 	lsl	x2, x2, #3
    adfc:	8b020060 	add	x0, x3, x2
    ae00:	f9401017 	ldr	x23, [x0, #32]
    ae04:	b4000257 	cbz	x23, ae4c <f0+0xa18>
    ae08:	38626862 	ldrb	w2, [x3, x2]
    ae0c:	7100085f 	cmp	w2, #0x2
    ae10:	5400d280 	b.eq	c860 <f0+0x242c>  // b.none
    ae14:	7100045f 	cmp	w2, #0x1
    ae18:	540001a1 	b.ne	ae4c <f0+0xa18>  // b.any
    ae1c:	29430002 	ldp	w2, w0, [x0, #24]
    ae20:	92403c21 	and	x1, x1, #0xffff
    ae24:	9b027c21 	mul	x1, x1, x2
    ae28:	d360fc21 	lsr	x1, x1, #32
    ae2c:	eb00003f 	cmp	x1, x0
    ae30:	540000e2 	b.cs	ae4c <f0+0xa18>  // b.hs, b.nlast
    ae34:	8b0102f7 	add	x23, x23, x1
    ae38:	394002e0 	ldrb	w0, [x23]
    ae3c:	7103fc1f 	cmp	w0, #0xff
    ae40:	5400d9a0 	b.eq	c974 <f0+0x2540>  // b.none
    ae44:	52800020 	mov	w0, #0x1                   	// #1
    ae48:	390002e0 	strb	w0, [x23]
    ae4c:	910aa3e1 	add	x1, sp, #0x2a8
    ae50:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ae54:	52800020 	mov	w0, #0x1                   	// #1
    ae58:	f90157e2 	str	x2, [sp, #680]
    ae5c:	f9015bf5 	str	x21, [sp, #688]
    ae60:	97ffe910 	bl	52a0 <fwp_data.part.0.constprop.0>
    ae64:	97ffeb87 	bl	5c80 <fwp_rc_fresh>
    ae68:	aa0003e2 	mov	x2, x0
    ae6c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ae70:	910ae3e1 	add	x1, sp, #0x2b8
    ae74:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ae78:	52800020 	mov	w0, #0x1                   	// #1
    ae7c:	f9015fe3 	str	x3, [sp, #696]
    ae80:	f90163e2 	str	x2, [sp, #704]
    ae84:	97ffe907 	bl	52a0 <fwp_data.part.0.constprop.0>
    ae88:	9118c283 	add	x3, x20, #0x630
    ae8c:	aa0003f5 	mov	x21, x0
    ae90:	f949d861 	ldr	x1, [x3, #5040]
    ae94:	f949ec60 	ldr	x0, [x3, #5080]
    ae98:	cb0102a1 	sub	x1, x21, x1
    ae9c:	eb00403f 	cmp	x1, x0, lsl #16
    aea0:	54000322 	b.cs	af04 <f0+0xad0>  // b.hs, b.nlast
    aea4:	d350fc22 	lsr	x2, x1, #16
    aea8:	f949fc63 	ldr	x3, [x3, #5112]
    aeac:	8b020842 	add	x2, x2, x2, lsl #2
    aeb0:	d37df042 	lsl	x2, x2, #3
    aeb4:	8b020060 	add	x0, x3, x2
    aeb8:	f9401017 	ldr	x23, [x0, #32]
    aebc:	b4000257 	cbz	x23, af04 <f0+0xad0>
    aec0:	38626862 	ldrb	w2, [x3, x2]
    aec4:	7100085f 	cmp	w2, #0x2
    aec8:	5400cc60 	b.eq	c854 <f0+0x2420>  // b.none
    aecc:	7100045f 	cmp	w2, #0x1
    aed0:	540001a1 	b.ne	af04 <f0+0xad0>  // b.any
    aed4:	29430002 	ldp	w2, w0, [x0, #24]
    aed8:	92403c21 	and	x1, x1, #0xffff
    aedc:	9b027c21 	mul	x1, x1, x2
    aee0:	d360fc21 	lsr	x1, x1, #32
    aee4:	eb00003f 	cmp	x1, x0
    aee8:	540000e2 	b.cs	af04 <f0+0xad0>  // b.hs, b.nlast
    aeec:	8b0102f7 	add	x23, x23, x1
    aef0:	394002e0 	ldrb	w0, [x23]
    aef4:	7103fc1f 	cmp	w0, #0xff
    aef8:	5400d440 	b.eq	c980 <f0+0x254c>  // b.none
    aefc:	52800020 	mov	w0, #0x1                   	// #1
    af00:	390002e0 	strb	w0, [x23]
    af04:	910b23e1 	add	x1, sp, #0x2c8
    af08:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    af0c:	52800020 	mov	w0, #0x1                   	// #1
    af10:	f90167e2 	str	x2, [sp, #712]
    af14:	f9016bf5 	str	x21, [sp, #720]
    af18:	97ffe8e2 	bl	52a0 <fwp_data.part.0.constprop.0>
    af1c:	97ffeb59 	bl	5c80 <fwp_rc_fresh>
    af20:	aa0003e2 	mov	x2, x0
    af24:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    af28:	910b63e1 	add	x1, sp, #0x2d8
    af2c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    af30:	52800020 	mov	w0, #0x1                   	// #1
    af34:	f9016fe3 	str	x3, [sp, #728]
    af38:	f90173e2 	str	x2, [sp, #736]
    af3c:	97ffe8d9 	bl	52a0 <fwp_data.part.0.constprop.0>
    af40:	9118c283 	add	x3, x20, #0x630
    af44:	aa0003f5 	mov	x21, x0
    af48:	f949d861 	ldr	x1, [x3, #5040]
    af4c:	f949ec60 	ldr	x0, [x3, #5080]
    af50:	cb0102a1 	sub	x1, x21, x1
    af54:	eb00403f 	cmp	x1, x0, lsl #16
    af58:	54000322 	b.cs	afbc <f0+0xb88>  // b.hs, b.nlast
    af5c:	d350fc22 	lsr	x2, x1, #16
    af60:	f949fc63 	ldr	x3, [x3, #5112]
    af64:	8b020842 	add	x2, x2, x2, lsl #2
    af68:	d37df042 	lsl	x2, x2, #3
    af6c:	8b020060 	add	x0, x3, x2
    af70:	f9401017 	ldr	x23, [x0, #32]
    af74:	b4000257 	cbz	x23, afbc <f0+0xb88>
    af78:	38626862 	ldrb	w2, [x3, x2]
    af7c:	7100085f 	cmp	w2, #0x2
    af80:	5400c7c0 	b.eq	c878 <f0+0x2444>  // b.none
    af84:	7100045f 	cmp	w2, #0x1
    af88:	540001a1 	b.ne	afbc <f0+0xb88>  // b.any
    af8c:	29430002 	ldp	w2, w0, [x0, #24]
    af90:	92403c21 	and	x1, x1, #0xffff
    af94:	9b027c21 	mul	x1, x1, x2
    af98:	d360fc21 	lsr	x1, x1, #32
    af9c:	eb00003f 	cmp	x1, x0
    afa0:	540000e2 	b.cs	afbc <f0+0xb88>  // b.hs, b.nlast
    afa4:	8b0102f7 	add	x23, x23, x1
    afa8:	394002e0 	ldrb	w0, [x23]
    afac:	7103fc1f 	cmp	w0, #0xff
    afb0:	5400cee0 	b.eq	c98c <f0+0x2558>  // b.none
    afb4:	52800020 	mov	w0, #0x1                   	// #1
    afb8:	390002e0 	strb	w0, [x23]
    afbc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    afc0:	910ba3e1 	add	x1, sp, #0x2e8
    afc4:	52800020 	mov	w0, #0x1                   	// #1
    afc8:	f90177e2 	str	x2, [sp, #744]
    afcc:	f9017bf5 	str	x21, [sp, #752]
    afd0:	97ffe8b4 	bl	52a0 <fwp_data.part.0.constprop.0>
    afd4:	9118c283 	add	x3, x20, #0x630
    afd8:	aa0003f7 	mov	x23, x0
    afdc:	f949d861 	ldr	x1, [x3, #5040]
    afe0:	f949ec60 	ldr	x0, [x3, #5080]
    afe4:	cb0102e1 	sub	x1, x23, x1
    afe8:	eb00403f 	cmp	x1, x0, lsl #16
    afec:	54000322 	b.cs	b050 <f0+0xc1c>  // b.hs, b.nlast
    aff0:	d350fc22 	lsr	x2, x1, #16
    aff4:	f949fc63 	ldr	x3, [x3, #5112]
    aff8:	8b020842 	add	x2, x2, x2, lsl #2
    affc:	d37df042 	lsl	x2, x2, #3
    b000:	8b020060 	add	x0, x3, x2
    b004:	f9401015 	ldr	x21, [x0, #32]
    b008:	b4000255 	cbz	x21, b050 <f0+0xc1c>
    b00c:	38626862 	ldrb	w2, [x3, x2]
    b010:	7100085f 	cmp	w2, #0x2
    b014:	5400c2c0 	b.eq	c86c <f0+0x2438>  // b.none
    b018:	7100045f 	cmp	w2, #0x1
    b01c:	540001a1 	b.ne	b050 <f0+0xc1c>  // b.any
    b020:	29430002 	ldp	w2, w0, [x0, #24]
    b024:	92403c21 	and	x1, x1, #0xffff
    b028:	9b027c21 	mul	x1, x1, x2
    b02c:	d360fc21 	lsr	x1, x1, #32
    b030:	eb00003f 	cmp	x1, x0
    b034:	540000e2 	b.cs	b050 <f0+0xc1c>  // b.hs, b.nlast
    b038:	8b0102b5 	add	x21, x21, x1
    b03c:	394002a0 	ldrb	w0, [x21]
    b040:	7103fc1f 	cmp	w0, #0xff
    b044:	5400caa0 	b.eq	c998 <f0+0x2564>  // b.none
    b048:	52800020 	mov	w0, #0x1                   	// #1
    b04c:	390002a0 	strb	w0, [x21]
    b050:	910be3e1 	add	x1, sp, #0x2f8
    b054:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b058:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b05c:	52800020 	mov	w0, #0x1                   	// #1
    b060:	f9017ff5 	str	x21, [sp, #760]
    b064:	f90183f7 	str	x23, [sp, #768]
    b068:	97ffe88e 	bl	52a0 <fwp_data.part.0.constprop.0>
    b06c:	97ffeb05 	bl	5c80 <fwp_rc_fresh>
    b070:	aa0003e2 	mov	x2, x0
    b074:	910c23e1 	add	x1, sp, #0x308
    b078:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b07c:	52800020 	mov	w0, #0x1                   	// #1
    b080:	f90187f7 	str	x23, [sp, #776]
    b084:	f9018be2 	str	x2, [sp, #784]
    b088:	97ffe886 	bl	52a0 <fwp_data.part.0.constprop.0>
    b08c:	97ffeafd 	bl	5c80 <fwp_rc_fresh>
    b090:	aa0003e2 	mov	x2, x0
    b094:	910c63e1 	add	x1, sp, #0x318
    b098:	52800020 	mov	w0, #0x1                   	// #1
    b09c:	f9018ff5 	str	x21, [sp, #792]
    b0a0:	f90193e2 	str	x2, [sp, #800]
    b0a4:	97ffe87f 	bl	52a0 <fwp_data.part.0.constprop.0>
    b0a8:	97ffeaf6 	bl	5c80 <fwp_rc_fresh>
    b0ac:	aa0003e2 	mov	x2, x0
    b0b0:	910ca3e1 	add	x1, sp, #0x328
    b0b4:	52800020 	mov	w0, #0x1                   	// #1
    b0b8:	f90197f7 	str	x23, [sp, #808]
    b0bc:	f9019be2 	str	x2, [sp, #816]
    b0c0:	97ffe878 	bl	52a0 <fwp_data.part.0.constprop.0>
    b0c4:	97ffeaef 	bl	5c80 <fwp_rc_fresh>
    b0c8:	aa0003e2 	mov	x2, x0
    b0cc:	910ce3e1 	add	x1, sp, #0x338
    b0d0:	52800020 	mov	w0, #0x1                   	// #1
    b0d4:	f9019ff5 	str	x21, [sp, #824]
    b0d8:	f901a3e2 	str	x2, [sp, #832]
    b0dc:	97ffe871 	bl	52a0 <fwp_data.part.0.constprop.0>
    b0e0:	97ffeae8 	bl	5c80 <fwp_rc_fresh>
    b0e4:	aa0003e2 	mov	x2, x0
    b0e8:	910d23e1 	add	x1, sp, #0x348
    b0ec:	52800020 	mov	w0, #0x1                   	// #1
    b0f0:	f901a7f7 	str	x23, [sp, #840]
    b0f4:	f901abe2 	str	x2, [sp, #848]
    b0f8:	97ffe86a 	bl	52a0 <fwp_data.part.0.constprop.0>
    b0fc:	97ffeae1 	bl	5c80 <fwp_rc_fresh>
    b100:	aa0003e2 	mov	x2, x0
    b104:	910d63e1 	add	x1, sp, #0x358
    b108:	52800020 	mov	w0, #0x1                   	// #1
    b10c:	f901aff5 	str	x21, [sp, #856]
    b110:	f901b3e2 	str	x2, [sp, #864]
    b114:	97ffe863 	bl	52a0 <fwp_data.part.0.constprop.0>
    b118:	97ffeada 	bl	5c80 <fwp_rc_fresh>
    b11c:	aa0003e2 	mov	x2, x0
    b120:	910da3e1 	add	x1, sp, #0x368
    b124:	52800020 	mov	w0, #0x1                   	// #1
    b128:	f901b7f7 	str	x23, [sp, #872]
    b12c:	f901bbe2 	str	x2, [sp, #880]
    b130:	97ffe85c 	bl	52a0 <fwp_data.part.0.constprop.0>
    b134:	97ffead3 	bl	5c80 <fwp_rc_fresh>
    b138:	aa0003e2 	mov	x2, x0
    b13c:	910de3e1 	add	x1, sp, #0x378
    b140:	52800020 	mov	w0, #0x1                   	// #1
    b144:	f901bff5 	str	x21, [sp, #888]
    b148:	f901c3e2 	str	x2, [sp, #896]
    b14c:	97ffe855 	bl	52a0 <fwp_data.part.0.constprop.0>
    b150:	97ffeacc 	bl	5c80 <fwp_rc_fresh>
    b154:	aa0003e2 	mov	x2, x0
    b158:	910e23e1 	add	x1, sp, #0x388
    b15c:	52800020 	mov	w0, #0x1                   	// #1
    b160:	f901c7f7 	str	x23, [sp, #904]
    b164:	f901cbe2 	str	x2, [sp, #912]
    b168:	97ffe84e 	bl	52a0 <fwp_data.part.0.constprop.0>
    b16c:	97ffeac5 	bl	5c80 <fwp_rc_fresh>
    b170:	aa0003e2 	mov	x2, x0
    b174:	910e63e1 	add	x1, sp, #0x398
    b178:	52800020 	mov	w0, #0x1                   	// #1
    b17c:	f901cff5 	str	x21, [sp, #920]
    b180:	f901d3e2 	str	x2, [sp, #928]
    b184:	97ffe847 	bl	52a0 <fwp_data.part.0.constprop.0>
    b188:	97ffeabe 	bl	5c80 <fwp_rc_fresh>
    b18c:	aa0003e2 	mov	x2, x0
    b190:	910ea3e1 	add	x1, sp, #0x3a8
    b194:	52800020 	mov	w0, #0x1                   	// #1
    b198:	f901d7f7 	str	x23, [sp, #936]
    b19c:	f901dbe2 	str	x2, [sp, #944]
    b1a0:	97ffe840 	bl	52a0 <fwp_data.part.0.constprop.0>
    b1a4:	97ffeab7 	bl	5c80 <fwp_rc_fresh>
    b1a8:	aa0003e2 	mov	x2, x0
    b1ac:	910ee3e1 	add	x1, sp, #0x3b8
    b1b0:	52800020 	mov	w0, #0x1                   	// #1
    b1b4:	f901dff5 	str	x21, [sp, #952]
    b1b8:	f901e3e2 	str	x2, [sp, #960]
    b1bc:	97ffe839 	bl	52a0 <fwp_data.part.0.constprop.0>
    b1c0:	9118c283 	add	x3, x20, #0x630
    b1c4:	aa0003f5 	mov	x21, x0
    b1c8:	f949d861 	ldr	x1, [x3, #5040]
    b1cc:	f949ec60 	ldr	x0, [x3, #5080]
    b1d0:	cb0102a1 	sub	x1, x21, x1
    b1d4:	eb00403f 	cmp	x1, x0, lsl #16
    b1d8:	54000322 	b.cs	b23c <f0+0xe08>  // b.hs, b.nlast
    b1dc:	d350fc22 	lsr	x2, x1, #16
    b1e0:	f949fc63 	ldr	x3, [x3, #5112]
    b1e4:	8b020842 	add	x2, x2, x2, lsl #2
    b1e8:	d37df042 	lsl	x2, x2, #3
    b1ec:	8b020060 	add	x0, x3, x2
    b1f0:	f9401017 	ldr	x23, [x0, #32]
    b1f4:	b4000257 	cbz	x23, b23c <f0+0xe08>
    b1f8:	38626862 	ldrb	w2, [x3, x2]
    b1fc:	7100085f 	cmp	w2, #0x2
    b200:	5400b480 	b.eq	c890 <f0+0x245c>  // b.none
    b204:	7100045f 	cmp	w2, #0x1
    b208:	540001a1 	b.ne	b23c <f0+0xe08>  // b.any
    b20c:	29430002 	ldp	w2, w0, [x0, #24]
    b210:	92403c21 	and	x1, x1, #0xffff
    b214:	9b027c21 	mul	x1, x1, x2
    b218:	d360fc21 	lsr	x1, x1, #32
    b21c:	eb00003f 	cmp	x1, x0
    b220:	540000e2 	b.cs	b23c <f0+0xe08>  // b.hs, b.nlast
    b224:	8b0102f7 	add	x23, x23, x1
    b228:	394002e0 	ldrb	w0, [x23]
    b22c:	7103fc1f 	cmp	w0, #0xff
    b230:	5400bba0 	b.eq	c9a4 <f0+0x2570>  // b.none
    b234:	52800020 	mov	w0, #0x1                   	// #1
    b238:	390002e0 	strb	w0, [x23]
    b23c:	910f23e1 	add	x1, sp, #0x3c8
    b240:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b244:	52800020 	mov	w0, #0x1                   	// #1
    b248:	f901e7f7 	str	x23, [sp, #968]
    b24c:	f901ebf5 	str	x21, [sp, #976]
    b250:	97ffe814 	bl	52a0 <fwp_data.part.0.constprop.0>
    b254:	97ffea8b 	bl	5c80 <fwp_rc_fresh>
    b258:	aa0003e2 	mov	x2, x0
    b25c:	910f63e1 	add	x1, sp, #0x3d8
    b260:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b264:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b268:	52800020 	mov	w0, #0x1                   	// #1
    b26c:	f901eff5 	str	x21, [sp, #984]
    b270:	f901f3e2 	str	x2, [sp, #992]
    b274:	97ffe80b 	bl	52a0 <fwp_data.part.0.constprop.0>
    b278:	97ffea82 	bl	5c80 <fwp_rc_fresh>
    b27c:	aa0003e2 	mov	x2, x0
    b280:	910fa3e1 	add	x1, sp, #0x3e8
    b284:	52800020 	mov	w0, #0x1                   	// #1
    b288:	f901f7f7 	str	x23, [sp, #1000]
    b28c:	f901fbe2 	str	x2, [sp, #1008]
    b290:	97ffe804 	bl	52a0 <fwp_data.part.0.constprop.0>
    b294:	97ffea7b 	bl	5c80 <fwp_rc_fresh>
    b298:	aa0003e2 	mov	x2, x0
    b29c:	910fe3e1 	add	x1, sp, #0x3f8
    b2a0:	52800020 	mov	w0, #0x1                   	// #1
    b2a4:	f901fff5 	str	x21, [sp, #1016]
    b2a8:	f90203e2 	str	x2, [sp, #1024]
    b2ac:	97ffe7fd 	bl	52a0 <fwp_data.part.0.constprop.0>
    b2b0:	9118c283 	add	x3, x20, #0x630
    b2b4:	aa0003f7 	mov	x23, x0
    b2b8:	f949d861 	ldr	x1, [x3, #5040]
    b2bc:	f949ec60 	ldr	x0, [x3, #5080]
    b2c0:	cb0102e1 	sub	x1, x23, x1
    b2c4:	eb00403f 	cmp	x1, x0, lsl #16
    b2c8:	54000322 	b.cs	b32c <f0+0xef8>  // b.hs, b.nlast
    b2cc:	d350fc22 	lsr	x2, x1, #16
    b2d0:	f949fc63 	ldr	x3, [x3, #5112]
    b2d4:	8b020842 	add	x2, x2, x2, lsl #2
    b2d8:	d37df042 	lsl	x2, x2, #3
    b2dc:	8b020060 	add	x0, x3, x2
    b2e0:	f9401015 	ldr	x21, [x0, #32]
    b2e4:	b4000255 	cbz	x21, b32c <f0+0xef8>
    b2e8:	38626862 	ldrb	w2, [x3, x2]
    b2ec:	7100085f 	cmp	w2, #0x2
    b2f0:	5400aca0 	b.eq	c884 <f0+0x2450>  // b.none
    b2f4:	7100045f 	cmp	w2, #0x1
    b2f8:	540001a1 	b.ne	b32c <f0+0xef8>  // b.any
    b2fc:	29430002 	ldp	w2, w0, [x0, #24]
    b300:	92403c21 	and	x1, x1, #0xffff
    b304:	9b027c21 	mul	x1, x1, x2
    b308:	d360fc21 	lsr	x1, x1, #32
    b30c:	eb00003f 	cmp	x1, x0
    b310:	540000e2 	b.cs	b32c <f0+0xef8>  // b.hs, b.nlast
    b314:	8b0102b5 	add	x21, x21, x1
    b318:	394002a0 	ldrb	w0, [x21]
    b31c:	7103fc1f 	cmp	w0, #0xff
    b320:	5400b480 	b.eq	c9b0 <f0+0x257c>  // b.none
    b324:	52800020 	mov	w0, #0x1                   	// #1
    b328:	390002a0 	strb	w0, [x21]
    b32c:	911023e1 	add	x1, sp, #0x408
    b330:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b334:	52800020 	mov	w0, #0x1                   	// #1
    b338:	f90207f5 	str	x21, [sp, #1032]
    b33c:	f9020bf7 	str	x23, [sp, #1040]
    b340:	97ffe7d8 	bl	52a0 <fwp_data.part.0.constprop.0>
    b344:	97ffea4f 	bl	5c80 <fwp_rc_fresh>
    b348:	aa0003e2 	mov	x2, x0
    b34c:	911063e1 	add	x1, sp, #0x418
    b350:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b354:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b358:	52800020 	mov	w0, #0x1                   	// #1
    b35c:	f9020ff7 	str	x23, [sp, #1048]
    b360:	f90213e2 	str	x2, [sp, #1056]
    b364:	97ffe7cf 	bl	52a0 <fwp_data.part.0.constprop.0>
    b368:	97ffea46 	bl	5c80 <fwp_rc_fresh>
    b36c:	aa0003e2 	mov	x2, x0
    b370:	9110a3e1 	add	x1, sp, #0x428
    b374:	52800020 	mov	w0, #0x1                   	// #1
    b378:	f90217f5 	str	x21, [sp, #1064]
    b37c:	f9021be2 	str	x2, [sp, #1072]
    b380:	97ffe7c8 	bl	52a0 <fwp_data.part.0.constprop.0>
    b384:	97ffea3f 	bl	5c80 <fwp_rc_fresh>
    b388:	aa0003e2 	mov	x2, x0
    b38c:	9110e3e1 	add	x1, sp, #0x438
    b390:	52800020 	mov	w0, #0x1                   	// #1
    b394:	f9021ff7 	str	x23, [sp, #1080]
    b398:	f90223e2 	str	x2, [sp, #1088]
    b39c:	97ffe7c1 	bl	52a0 <fwp_data.part.0.constprop.0>
    b3a0:	97ffea38 	bl	5c80 <fwp_rc_fresh>
    b3a4:	aa0003e2 	mov	x2, x0
    b3a8:	911123e1 	add	x1, sp, #0x448
    b3ac:	52800020 	mov	w0, #0x1                   	// #1
    b3b0:	f90227f5 	str	x21, [sp, #1096]
    b3b4:	f9022be2 	str	x2, [sp, #1104]
    b3b8:	97ffe7ba 	bl	52a0 <fwp_data.part.0.constprop.0>
    b3bc:	97ffea31 	bl	5c80 <fwp_rc_fresh>
    b3c0:	aa0003e2 	mov	x2, x0
    b3c4:	911163e1 	add	x1, sp, #0x458
    b3c8:	52800020 	mov	w0, #0x1                   	// #1
    b3cc:	f9022ff7 	str	x23, [sp, #1112]
    b3d0:	f90233e2 	str	x2, [sp, #1120]
    b3d4:	97ffe7b3 	bl	52a0 <fwp_data.part.0.constprop.0>
    b3d8:	97ffea2a 	bl	5c80 <fwp_rc_fresh>
    b3dc:	aa0003e2 	mov	x2, x0
    b3e0:	9111a3e1 	add	x1, sp, #0x468
    b3e4:	52800020 	mov	w0, #0x1                   	// #1
    b3e8:	f90237f5 	str	x21, [sp, #1128]
    b3ec:	f9023be2 	str	x2, [sp, #1136]
    b3f0:	97ffe7ac 	bl	52a0 <fwp_data.part.0.constprop.0>
    b3f4:	9118c283 	add	x3, x20, #0x630
    b3f8:	aa0003f5 	mov	x21, x0
    b3fc:	f949d861 	ldr	x1, [x3, #5040]
    b400:	f949ec60 	ldr	x0, [x3, #5080]
    b404:	cb0102a1 	sub	x1, x21, x1
    b408:	eb00403f 	cmp	x1, x0, lsl #16
    b40c:	54000322 	b.cs	b470 <f0+0x103c>  // b.hs, b.nlast
    b410:	d350fc22 	lsr	x2, x1, #16
    b414:	f949fc63 	ldr	x3, [x3, #5112]
    b418:	8b020842 	add	x2, x2, x2, lsl #2
    b41c:	d37df042 	lsl	x2, x2, #3
    b420:	8b020060 	add	x0, x3, x2
    b424:	f9401017 	ldr	x23, [x0, #32]
    b428:	b4000257 	cbz	x23, b470 <f0+0x103c>
    b42c:	38626862 	ldrb	w2, [x3, x2]
    b430:	7100085f 	cmp	w2, #0x2
    b434:	5400a3a0 	b.eq	c8a8 <f0+0x2474>  // b.none
    b438:	7100045f 	cmp	w2, #0x1
    b43c:	540001a1 	b.ne	b470 <f0+0x103c>  // b.any
    b440:	29430002 	ldp	w2, w0, [x0, #24]
    b444:	92403c21 	and	x1, x1, #0xffff
    b448:	9b027c21 	mul	x1, x1, x2
    b44c:	d360fc21 	lsr	x1, x1, #32
    b450:	eb00003f 	cmp	x1, x0
    b454:	540000e2 	b.cs	b470 <f0+0x103c>  // b.hs, b.nlast
    b458:	8b0102f7 	add	x23, x23, x1
    b45c:	394002e0 	ldrb	w0, [x23]
    b460:	7103fc1f 	cmp	w0, #0xff
    b464:	5400aac0 	b.eq	c9bc <f0+0x2588>  // b.none
    b468:	52800020 	mov	w0, #0x1                   	// #1
    b46c:	390002e0 	strb	w0, [x23]
    b470:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b474:	9111e3e1 	add	x1, sp, #0x478
    b478:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b47c:	52800020 	mov	w0, #0x1                   	// #1
    b480:	f9023fe2 	str	x2, [sp, #1144]
    b484:	f90243f5 	str	x21, [sp, #1152]
    b488:	97ffe786 	bl	52a0 <fwp_data.part.0.constprop.0>
    b48c:	9118c283 	add	x3, x20, #0x630
    b490:	aa0003f5 	mov	x21, x0
    b494:	f949d861 	ldr	x1, [x3, #5040]
    b498:	f949ec60 	ldr	x0, [x3, #5080]
    b49c:	cb0102a1 	sub	x1, x21, x1
    b4a0:	eb00403f 	cmp	x1, x0, lsl #16
    b4a4:	54000322 	b.cs	b508 <f0+0x10d4>  // b.hs, b.nlast
    b4a8:	d350fc22 	lsr	x2, x1, #16
    b4ac:	f949fc63 	ldr	x3, [x3, #5112]
    b4b0:	8b020842 	add	x2, x2, x2, lsl #2
    b4b4:	d37df042 	lsl	x2, x2, #3
    b4b8:	8b020060 	add	x0, x3, x2
    b4bc:	f9401017 	ldr	x23, [x0, #32]
    b4c0:	b4000257 	cbz	x23, b508 <f0+0x10d4>
    b4c4:	38626862 	ldrb	w2, [x3, x2]
    b4c8:	7100085f 	cmp	w2, #0x2
    b4cc:	54009e80 	b.eq	c89c <f0+0x2468>  // b.none
    b4d0:	7100045f 	cmp	w2, #0x1
    b4d4:	540001a1 	b.ne	b508 <f0+0x10d4>  // b.any
    b4d8:	29430002 	ldp	w2, w0, [x0, #24]
    b4dc:	92403c21 	and	x1, x1, #0xffff
    b4e0:	9b027c21 	mul	x1, x1, x2
    b4e4:	d360fc21 	lsr	x1, x1, #32
    b4e8:	eb00003f 	cmp	x1, x0
    b4ec:	540000e2 	b.cs	b508 <f0+0x10d4>  // b.hs, b.nlast
    b4f0:	8b0102f7 	add	x23, x23, x1
    b4f4:	394002e0 	ldrb	w0, [x23]
    b4f8:	7103fc1f 	cmp	w0, #0xff
    b4fc:	5400a660 	b.eq	c9c8 <f0+0x2594>  // b.none
    b500:	52800020 	mov	w0, #0x1                   	// #1
    b504:	390002e0 	strb	w0, [x23]
    b508:	911223e1 	add	x1, sp, #0x488
    b50c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b510:	52800020 	mov	w0, #0x1                   	// #1
    b514:	f90247e2 	str	x2, [sp, #1160]
    b518:	f9024bf5 	str	x21, [sp, #1168]
    b51c:	97ffe761 	bl	52a0 <fwp_data.part.0.constprop.0>
    b520:	97ffe9d8 	bl	5c80 <fwp_rc_fresh>
    b524:	aa0003e2 	mov	x2, x0
    b528:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b52c:	911263e1 	add	x1, sp, #0x498
    b530:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b534:	52800020 	mov	w0, #0x1                   	// #1
    b538:	f9024fe3 	str	x3, [sp, #1176]
    b53c:	f90253e2 	str	x2, [sp, #1184]
    b540:	97ffe758 	bl	52a0 <fwp_data.part.0.constprop.0>
    b544:	9118c283 	add	x3, x20, #0x630
    b548:	aa0003f5 	mov	x21, x0
    b54c:	f949d861 	ldr	x1, [x3, #5040]
    b550:	f949ec60 	ldr	x0, [x3, #5080]
    b554:	cb0102a1 	sub	x1, x21, x1
    b558:	eb00403f 	cmp	x1, x0, lsl #16
    b55c:	54000322 	b.cs	b5c0 <f0+0x118c>  // b.hs, b.nlast
    b560:	d350fc22 	lsr	x2, x1, #16
    b564:	f949fc63 	ldr	x3, [x3, #5112]
    b568:	8b020842 	add	x2, x2, x2, lsl #2
    b56c:	d37df042 	lsl	x2, x2, #3
    b570:	8b020060 	add	x0, x3, x2
    b574:	f9401017 	ldr	x23, [x0, #32]
    b578:	b4000257 	cbz	x23, b5c0 <f0+0x118c>
    b57c:	38626862 	ldrb	w2, [x3, x2]
    b580:	7100085f 	cmp	w2, #0x2
    b584:	540099e0 	b.eq	c8c0 <f0+0x248c>  // b.none
    b588:	7100045f 	cmp	w2, #0x1
    b58c:	540001a1 	b.ne	b5c0 <f0+0x118c>  // b.any
    b590:	29430002 	ldp	w2, w0, [x0, #24]
    b594:	92403c21 	and	x1, x1, #0xffff
    b598:	9b027c21 	mul	x1, x1, x2
    b59c:	d360fc21 	lsr	x1, x1, #32
    b5a0:	eb00003f 	cmp	x1, x0
    b5a4:	540000e2 	b.cs	b5c0 <f0+0x118c>  // b.hs, b.nlast
    b5a8:	8b0102f7 	add	x23, x23, x1
    b5ac:	394002e0 	ldrb	w0, [x23]
    b5b0:	7103fc1f 	cmp	w0, #0xff
    b5b4:	5400a100 	b.eq	c9d4 <f0+0x25a0>  // b.none
    b5b8:	52800020 	mov	w0, #0x1                   	// #1
    b5bc:	390002e0 	strb	w0, [x23]
    b5c0:	9112a3e1 	add	x1, sp, #0x4a8
    b5c4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b5c8:	52800020 	mov	w0, #0x1                   	// #1
    b5cc:	f90257e2 	str	x2, [sp, #1192]
    b5d0:	f9025bf5 	str	x21, [sp, #1200]
    b5d4:	97ffe733 	bl	52a0 <fwp_data.part.0.constprop.0>
    b5d8:	97ffe9aa 	bl	5c80 <fwp_rc_fresh>
    b5dc:	aa0003e2 	mov	x2, x0
    b5e0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b5e4:	9112e3e1 	add	x1, sp, #0x4b8
    b5e8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b5ec:	52800020 	mov	w0, #0x1                   	// #1
    b5f0:	f9025fe3 	str	x3, [sp, #1208]
    b5f4:	f90263e2 	str	x2, [sp, #1216]
    b5f8:	97ffe72a 	bl	52a0 <fwp_data.part.0.constprop.0>
    b5fc:	9118c283 	add	x3, x20, #0x630
    b600:	aa0003f5 	mov	x21, x0
    b604:	f949d861 	ldr	x1, [x3, #5040]
    b608:	f949ec60 	ldr	x0, [x3, #5080]
    b60c:	cb0102a1 	sub	x1, x21, x1
    b610:	eb00403f 	cmp	x1, x0, lsl #16
    b614:	54000322 	b.cs	b678 <f0+0x1244>  // b.hs, b.nlast
    b618:	d350fc22 	lsr	x2, x1, #16
    b61c:	f949fc63 	ldr	x3, [x3, #5112]
    b620:	8b020842 	add	x2, x2, x2, lsl #2
    b624:	d37df042 	lsl	x2, x2, #3
    b628:	8b020060 	add	x0, x3, x2
    b62c:	f9401017 	ldr	x23, [x0, #32]
    b630:	b4000257 	cbz	x23, b678 <f0+0x1244>
    b634:	38626862 	ldrb	w2, [x3, x2]
    b638:	7100085f 	cmp	w2, #0x2
    b63c:	540093c0 	b.eq	c8b4 <f0+0x2480>  // b.none
    b640:	7100045f 	cmp	w2, #0x1
    b644:	540001a1 	b.ne	b678 <f0+0x1244>  // b.any
    b648:	29430002 	ldp	w2, w0, [x0, #24]
    b64c:	92403c21 	and	x1, x1, #0xffff
    b650:	9b027c21 	mul	x1, x1, x2
    b654:	d360fc21 	lsr	x1, x1, #32
    b658:	eb00003f 	cmp	x1, x0
    b65c:	540000e2 	b.cs	b678 <f0+0x1244>  // b.hs, b.nlast
    b660:	8b0102f7 	add	x23, x23, x1
    b664:	394002e0 	ldrb	w0, [x23]
    b668:	7103fc1f 	cmp	w0, #0xff
    b66c:	54009ba0 	b.eq	c9e0 <f0+0x25ac>  // b.none
    b670:	52800020 	mov	w0, #0x1                   	// #1
    b674:	390002e0 	strb	w0, [x23]
    b678:	911323e1 	add	x1, sp, #0x4c8
    b67c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b680:	52800020 	mov	w0, #0x1                   	// #1
    b684:	f90267f7 	str	x23, [sp, #1224]
    b688:	f9026bf5 	str	x21, [sp, #1232]
    b68c:	97ffe705 	bl	52a0 <fwp_data.part.0.constprop.0>
    b690:	97ffe97c 	bl	5c80 <fwp_rc_fresh>
    b694:	aa0003e2 	mov	x2, x0
    b698:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b69c:	911363e1 	add	x1, sp, #0x4d8
    b6a0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b6a4:	52800020 	mov	w0, #0x1                   	// #1
    b6a8:	f9026fe3 	str	x3, [sp, #1240]
    b6ac:	f90273e2 	str	x2, [sp, #1248]
    b6b0:	97ffe6fc 	bl	52a0 <fwp_data.part.0.constprop.0>
    b6b4:	97ffe973 	bl	5c80 <fwp_rc_fresh>
    b6b8:	aa0003e2 	mov	x2, x0
    b6bc:	9113a3e1 	add	x1, sp, #0x4e8
    b6c0:	52800020 	mov	w0, #0x1                   	// #1
    b6c4:	f90277f7 	str	x23, [sp, #1256]
    b6c8:	f9027be2 	str	x2, [sp, #1264]
    b6cc:	97ffe6f5 	bl	52a0 <fwp_data.part.0.constprop.0>
    b6d0:	9118c283 	add	x3, x20, #0x630
    b6d4:	aa0003f5 	mov	x21, x0
    b6d8:	f949d861 	ldr	x1, [x3, #5040]
    b6dc:	f949ec60 	ldr	x0, [x3, #5080]
    b6e0:	cb0102a1 	sub	x1, x21, x1
    b6e4:	eb00403f 	cmp	x1, x0, lsl #16
    b6e8:	54000322 	b.cs	b74c <f0+0x1318>  // b.hs, b.nlast
    b6ec:	d350fc22 	lsr	x2, x1, #16
    b6f0:	f949fc63 	ldr	x3, [x3, #5112]
    b6f4:	8b020842 	add	x2, x2, x2, lsl #2
    b6f8:	d37df042 	lsl	x2, x2, #3
    b6fc:	8b020060 	add	x0, x3, x2
    b700:	f9401017 	ldr	x23, [x0, #32]
    b704:	b4000257 	cbz	x23, b74c <f0+0x1318>
    b708:	38626862 	ldrb	w2, [x3, x2]
    b70c:	7100085f 	cmp	w2, #0x2
    b710:	54008e40 	b.eq	c8d8 <f0+0x24a4>  // b.none
    b714:	7100045f 	cmp	w2, #0x1
    b718:	540001a1 	b.ne	b74c <f0+0x1318>  // b.any
    b71c:	29430002 	ldp	w2, w0, [x0, #24]
    b720:	92403c21 	and	x1, x1, #0xffff
    b724:	9b027c21 	mul	x1, x1, x2
    b728:	d360fc21 	lsr	x1, x1, #32
    b72c:	eb00003f 	cmp	x1, x0
    b730:	540000e2 	b.cs	b74c <f0+0x1318>  // b.hs, b.nlast
    b734:	8b0102f7 	add	x23, x23, x1
    b738:	394002e0 	ldrb	w0, [x23]
    b73c:	7103fc1f 	cmp	w0, #0xff
    b740:	54009560 	b.eq	c9ec <f0+0x25b8>  // b.none
    b744:	52800020 	mov	w0, #0x1                   	// #1
    b748:	390002e0 	strb	w0, [x23]
    b74c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b750:	9113e3e1 	add	x1, sp, #0x4f8
    b754:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b758:	52800020 	mov	w0, #0x1                   	// #1
    b75c:	f9027fe2 	str	x2, [sp, #1272]
    b760:	f90283f5 	str	x21, [sp, #1280]
    b764:	97ffe6cf 	bl	52a0 <fwp_data.part.0.constprop.0>
    b768:	9118c283 	add	x3, x20, #0x630
    b76c:	aa0003f5 	mov	x21, x0
    b770:	f949d861 	ldr	x1, [x3, #5040]
    b774:	f949ec60 	ldr	x0, [x3, #5080]
    b778:	cb0102a1 	sub	x1, x21, x1
    b77c:	eb00403f 	cmp	x1, x0, lsl #16
    b780:	54000322 	b.cs	b7e4 <f0+0x13b0>  // b.hs, b.nlast
    b784:	d350fc22 	lsr	x2, x1, #16
    b788:	f949fc63 	ldr	x3, [x3, #5112]
    b78c:	8b020842 	add	x2, x2, x2, lsl #2
    b790:	d37df042 	lsl	x2, x2, #3
    b794:	8b020060 	add	x0, x3, x2
    b798:	f9401017 	ldr	x23, [x0, #32]
    b79c:	b4000257 	cbz	x23, b7e4 <f0+0x13b0>
    b7a0:	38626862 	ldrb	w2, [x3, x2]
    b7a4:	7100085f 	cmp	w2, #0x2
    b7a8:	54008920 	b.eq	c8cc <f0+0x2498>  // b.none
    b7ac:	7100045f 	cmp	w2, #0x1
    b7b0:	540001a1 	b.ne	b7e4 <f0+0x13b0>  // b.any
    b7b4:	29430002 	ldp	w2, w0, [x0, #24]
    b7b8:	92403c21 	and	x1, x1, #0xffff
    b7bc:	9b027c21 	mul	x1, x1, x2
    b7c0:	d360fc21 	lsr	x1, x1, #32
    b7c4:	eb00003f 	cmp	x1, x0
    b7c8:	540000e2 	b.cs	b7e4 <f0+0x13b0>  // b.hs, b.nlast
    b7cc:	8b0102f7 	add	x23, x23, x1
    b7d0:	394002e0 	ldrb	w0, [x23]
    b7d4:	7103fc1f 	cmp	w0, #0xff
    b7d8:	54009100 	b.eq	c9f8 <f0+0x25c4>  // b.none
    b7dc:	52800020 	mov	w0, #0x1                   	// #1
    b7e0:	390002e0 	strb	w0, [x23]
    b7e4:	911423e1 	add	x1, sp, #0x508
    b7e8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b7ec:	52800020 	mov	w0, #0x1                   	// #1
    b7f0:	f90287f7 	str	x23, [sp, #1288]
    b7f4:	f9028bf5 	str	x21, [sp, #1296]
    b7f8:	97ffe6aa 	bl	52a0 <fwp_data.part.0.constprop.0>
    b7fc:	97ffe921 	bl	5c80 <fwp_rc_fresh>
    b800:	aa0003e2 	mov	x2, x0
    b804:	911463e1 	add	x1, sp, #0x518
    b808:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b80c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b810:	52800020 	mov	w0, #0x1                   	// #1
    b814:	f9028ff5 	str	x21, [sp, #1304]
    b818:	f90293e2 	str	x2, [sp, #1312]
    b81c:	97ffe6a1 	bl	52a0 <fwp_data.part.0.constprop.0>
    b820:	97ffe918 	bl	5c80 <fwp_rc_fresh>
    b824:	aa0003e2 	mov	x2, x0
    b828:	9114a3e1 	add	x1, sp, #0x528
    b82c:	52800020 	mov	w0, #0x1                   	// #1
    b830:	f90297f7 	str	x23, [sp, #1320]
    b834:	f9029be2 	str	x2, [sp, #1328]
    b838:	97ffe69a 	bl	52a0 <fwp_data.part.0.constprop.0>
    b83c:	97ffe911 	bl	5c80 <fwp_rc_fresh>
    b840:	aa0003e2 	mov	x2, x0
    b844:	9114e3e1 	add	x1, sp, #0x538
    b848:	52800020 	mov	w0, #0x1                   	// #1
    b84c:	f9029ff5 	str	x21, [sp, #1336]
    b850:	f902a3e2 	str	x2, [sp, #1344]
    b854:	97ffe693 	bl	52a0 <fwp_data.part.0.constprop.0>
    b858:	9118c283 	add	x3, x20, #0x630
    b85c:	aa0003f5 	mov	x21, x0
    b860:	f949d861 	ldr	x1, [x3, #5040]
    b864:	f949ec60 	ldr	x0, [x3, #5080]
    b868:	cb0102a1 	sub	x1, x21, x1
    b86c:	eb00403f 	cmp	x1, x0, lsl #16
    b870:	54000322 	b.cs	b8d4 <f0+0x14a0>  // b.hs, b.nlast
    b874:	d350fc22 	lsr	x2, x1, #16
    b878:	f949fc63 	ldr	x3, [x3, #5112]
    b87c:	8b020842 	add	x2, x2, x2, lsl #2
    b880:	d37df042 	lsl	x2, x2, #3
    b884:	8b020060 	add	x0, x3, x2
    b888:	f9401017 	ldr	x23, [x0, #32]
    b88c:	b4000257 	cbz	x23, b8d4 <f0+0x14a0>
    b890:	38626862 	ldrb	w2, [x3, x2]
    b894:	7100085f 	cmp	w2, #0x2
    b898:	540082c0 	b.eq	c8f0 <f0+0x24bc>  // b.none
    b89c:	7100045f 	cmp	w2, #0x1
    b8a0:	540001a1 	b.ne	b8d4 <f0+0x14a0>  // b.any
    b8a4:	29430002 	ldp	w2, w0, [x0, #24]
    b8a8:	92403c21 	and	x1, x1, #0xffff
    b8ac:	9b027c21 	mul	x1, x1, x2
    b8b0:	d360fc21 	lsr	x1, x1, #32
    b8b4:	eb00003f 	cmp	x1, x0
    b8b8:	540000e2 	b.cs	b8d4 <f0+0x14a0>  // b.hs, b.nlast
    b8bc:	8b0102f7 	add	x23, x23, x1
    b8c0:	394002e0 	ldrb	w0, [x23]
    b8c4:	7103fc1f 	cmp	w0, #0xff
    b8c8:	540089e0 	b.eq	ca04 <f0+0x25d0>  // b.none
    b8cc:	52800020 	mov	w0, #0x1                   	// #1
    b8d0:	390002e0 	strb	w0, [x23]
    b8d4:	911523e1 	add	x1, sp, #0x548
    b8d8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b8dc:	52800020 	mov	w0, #0x1                   	// #1
    b8e0:	f902a7f7 	str	x23, [sp, #1352]
    b8e4:	f902abf5 	str	x21, [sp, #1360]
    b8e8:	97ffe66e 	bl	52a0 <fwp_data.part.0.constprop.0>
    b8ec:	97ffe8e5 	bl	5c80 <fwp_rc_fresh>
    b8f0:	aa0003e2 	mov	x2, x0
    b8f4:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b8f8:	911563e1 	add	x1, sp, #0x558
    b8fc:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b900:	52800020 	mov	w0, #0x1                   	// #1
    b904:	f902afe3 	str	x3, [sp, #1368]
    b908:	f902b3e2 	str	x2, [sp, #1376]
    b90c:	97ffe665 	bl	52a0 <fwp_data.part.0.constprop.0>
    b910:	97ffe8dc 	bl	5c80 <fwp_rc_fresh>
    b914:	aa0003e2 	mov	x2, x0
    b918:	9115a3e1 	add	x1, sp, #0x568
    b91c:	52800020 	mov	w0, #0x1                   	// #1
    b920:	f902b7f7 	str	x23, [sp, #1384]
    b924:	f902bbe2 	str	x2, [sp, #1392]
    b928:	97ffe65e 	bl	52a0 <fwp_data.part.0.constprop.0>
    b92c:	9118c283 	add	x3, x20, #0x630
    b930:	aa0003f5 	mov	x21, x0
    b934:	f949d861 	ldr	x1, [x3, #5040]
    b938:	f949ec60 	ldr	x0, [x3, #5080]
    b93c:	cb0102a1 	sub	x1, x21, x1
    b940:	eb00403f 	cmp	x1, x0, lsl #16
    b944:	54000322 	b.cs	b9a8 <f0+0x1574>  // b.hs, b.nlast
    b948:	d350fc22 	lsr	x2, x1, #16
    b94c:	f949fc63 	ldr	x3, [x3, #5112]
    b950:	8b020842 	add	x2, x2, x2, lsl #2
    b954:	d37df042 	lsl	x2, x2, #3
    b958:	8b020060 	add	x0, x3, x2
    b95c:	f9401017 	ldr	x23, [x0, #32]
    b960:	b4000257 	cbz	x23, b9a8 <f0+0x1574>
    b964:	38626862 	ldrb	w2, [x3, x2]
    b968:	7100085f 	cmp	w2, #0x2
    b96c:	54007bc0 	b.eq	c8e4 <f0+0x24b0>  // b.none
    b970:	7100045f 	cmp	w2, #0x1
    b974:	540001a1 	b.ne	b9a8 <f0+0x1574>  // b.any
    b978:	29430002 	ldp	w2, w0, [x0, #24]
    b97c:	92403c21 	and	x1, x1, #0xffff
    b980:	9b027c21 	mul	x1, x1, x2
    b984:	d360fc21 	lsr	x1, x1, #32
    b988:	eb00003f 	cmp	x1, x0
    b98c:	540000e2 	b.cs	b9a8 <f0+0x1574>  // b.hs, b.nlast
    b990:	8b0102f7 	add	x23, x23, x1
    b994:	394002e0 	ldrb	w0, [x23]
    b998:	7103fc1f 	cmp	w0, #0xff
    b99c:	540083a0 	b.eq	ca10 <f0+0x25dc>  // b.none
    b9a0:	52800020 	mov	w0, #0x1                   	// #1
    b9a4:	390002e0 	strb	w0, [x23]
    b9a8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b9ac:	9115e3e1 	add	x1, sp, #0x578
    b9b0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b9b4:	52800020 	mov	w0, #0x1                   	// #1
    b9b8:	f902bfe2 	str	x2, [sp, #1400]
    b9bc:	f902c3f5 	str	x21, [sp, #1408]
    b9c0:	97ffe638 	bl	52a0 <fwp_data.part.0.constprop.0>
    b9c4:	9118c283 	add	x3, x20, #0x630
    b9c8:	aa0003f5 	mov	x21, x0
    b9cc:	f949d861 	ldr	x1, [x3, #5040]
    b9d0:	f949ec60 	ldr	x0, [x3, #5080]
    b9d4:	cb0102a1 	sub	x1, x21, x1
    b9d8:	eb00403f 	cmp	x1, x0, lsl #16
    b9dc:	54000322 	b.cs	ba40 <f0+0x160c>  // b.hs, b.nlast
    b9e0:	d350fc22 	lsr	x2, x1, #16
    b9e4:	f949fc63 	ldr	x3, [x3, #5112]
    b9e8:	8b020842 	add	x2, x2, x2, lsl #2
    b9ec:	d37df042 	lsl	x2, x2, #3
    b9f0:	8b020060 	add	x0, x3, x2
    b9f4:	f9401017 	ldr	x23, [x0, #32]
    b9f8:	b4000257 	cbz	x23, ba40 <f0+0x160c>
    b9fc:	38626862 	ldrb	w2, [x3, x2]
    ba00:	7100085f 	cmp	w2, #0x2
    ba04:	54006c20 	b.eq	c788 <f0+0x2354>  // b.none
    ba08:	7100045f 	cmp	w2, #0x1
    ba0c:	540001a1 	b.ne	ba40 <f0+0x160c>  // b.any
    ba10:	29430002 	ldp	w2, w0, [x0, #24]
    ba14:	92403c21 	and	x1, x1, #0xffff
    ba18:	9b027c21 	mul	x1, x1, x2
    ba1c:	d360fc21 	lsr	x1, x1, #32
    ba20:	eb00003f 	cmp	x1, x0
    ba24:	540000e2 	b.cs	ba40 <f0+0x160c>  // b.hs, b.nlast
    ba28:	8b0102f7 	add	x23, x23, x1
    ba2c:	394002e0 	ldrb	w0, [x23]
    ba30:	7103fc1f 	cmp	w0, #0xff
    ba34:	54007f40 	b.eq	ca1c <f0+0x25e8>  // b.none
    ba38:	52800020 	mov	w0, #0x1                   	// #1
    ba3c:	390002e0 	strb	w0, [x23]
    ba40:	911623e1 	add	x1, sp, #0x588
    ba44:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ba48:	52800020 	mov	w0, #0x1                   	// #1
    ba4c:	f902c7f7 	str	x23, [sp, #1416]
    ba50:	f902cbf5 	str	x21, [sp, #1424]
    ba54:	97ffe613 	bl	52a0 <fwp_data.part.0.constprop.0>
    ba58:	97ffe88a 	bl	5c80 <fwp_rc_fresh>
    ba5c:	aa0003e2 	mov	x2, x0
    ba60:	911663e1 	add	x1, sp, #0x598
    ba64:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    ba68:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    ba6c:	52800020 	mov	w0, #0x1                   	// #1
    ba70:	f902cff5 	str	x21, [sp, #1432]
    ba74:	f902d3e2 	str	x2, [sp, #1440]
    ba78:	97ffe60a 	bl	52a0 <fwp_data.part.0.constprop.0>
    ba7c:	97ffe881 	bl	5c80 <fwp_rc_fresh>
    ba80:	aa0003e2 	mov	x2, x0
    ba84:	9116a3e1 	add	x1, sp, #0x5a8
    ba88:	52800020 	mov	w0, #0x1                   	// #1
    ba8c:	f902d7f7 	str	x23, [sp, #1448]
    ba90:	f902dbe2 	str	x2, [sp, #1456]
    ba94:	97ffe603 	bl	52a0 <fwp_data.part.0.constprop.0>
    ba98:	97ffe87a 	bl	5c80 <fwp_rc_fresh>
    ba9c:	aa0003e2 	mov	x2, x0
    baa0:	9116e3e1 	add	x1, sp, #0x5b8
    baa4:	52800020 	mov	w0, #0x1                   	// #1
    baa8:	f902dff5 	str	x21, [sp, #1464]
    baac:	f902e3e2 	str	x2, [sp, #1472]
    bab0:	97ffe5fc 	bl	52a0 <fwp_data.part.0.constprop.0>
    bab4:	9118c283 	add	x3, x20, #0x630
    bab8:	aa0003f5 	mov	x21, x0
    babc:	f949d861 	ldr	x1, [x3, #5040]
    bac0:	f949ec60 	ldr	x0, [x3, #5080]
    bac4:	cb0102a1 	sub	x1, x21, x1
    bac8:	eb00403f 	cmp	x1, x0, lsl #16
    bacc:	54000322 	b.cs	bb30 <f0+0x16fc>  // b.hs, b.nlast
    bad0:	d350fc22 	lsr	x2, x1, #16
    bad4:	f949fc63 	ldr	x3, [x3, #5112]
    bad8:	8b020842 	add	x2, x2, x2, lsl #2
    badc:	d37df042 	lsl	x2, x2, #3
    bae0:	8b020060 	add	x0, x3, x2
    bae4:	f9401017 	ldr	x23, [x0, #32]
    bae8:	b4000257 	cbz	x23, bb30 <f0+0x16fc>
    baec:	38626862 	ldrb	w2, [x3, x2]
    baf0:	7100085f 	cmp	w2, #0x2
    baf4:	54006440 	b.eq	c77c <f0+0x2348>  // b.none
    baf8:	7100045f 	cmp	w2, #0x1
    bafc:	540001a1 	b.ne	bb30 <f0+0x16fc>  // b.any
    bb00:	29430002 	ldp	w2, w0, [x0, #24]
    bb04:	92403c21 	and	x1, x1, #0xffff
    bb08:	9b027c21 	mul	x1, x1, x2
    bb0c:	d360fc21 	lsr	x1, x1, #32
    bb10:	eb00003f 	cmp	x1, x0
    bb14:	540000e2 	b.cs	bb30 <f0+0x16fc>  // b.hs, b.nlast
    bb18:	8b0102f7 	add	x23, x23, x1
    bb1c:	394002e0 	ldrb	w0, [x23]
    bb20:	7103fc1f 	cmp	w0, #0xff
    bb24:	54007820 	b.eq	ca28 <f0+0x25f4>  // b.none
    bb28:	52800020 	mov	w0, #0x1                   	// #1
    bb2c:	390002e0 	strb	w0, [x23]
    bb30:	911723e1 	add	x1, sp, #0x5c8
    bb34:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bb38:	52800020 	mov	w0, #0x1                   	// #1
    bb3c:	f902e7e2 	str	x2, [sp, #1480]
    bb40:	f902ebf5 	str	x21, [sp, #1488]
    bb44:	97ffe5d7 	bl	52a0 <fwp_data.part.0.constprop.0>
    bb48:	97ffe84e 	bl	5c80 <fwp_rc_fresh>
    bb4c:	aa0003e2 	mov	x2, x0
    bb50:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bb54:	911763e1 	add	x1, sp, #0x5d8
    bb58:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bb5c:	52800020 	mov	w0, #0x1                   	// #1
    bb60:	f902efe3 	str	x3, [sp, #1496]
    bb64:	f902f3e2 	str	x2, [sp, #1504]
    bb68:	97ffe5ce 	bl	52a0 <fwp_data.part.0.constprop.0>
    bb6c:	9118c283 	add	x3, x20, #0x630
    bb70:	aa0003f5 	mov	x21, x0
    bb74:	f949d861 	ldr	x1, [x3, #5040]
    bb78:	f949ec60 	ldr	x0, [x3, #5080]
    bb7c:	cb0102a1 	sub	x1, x21, x1
    bb80:	eb00403f 	cmp	x1, x0, lsl #16
    bb84:	54000322 	b.cs	bbe8 <f0+0x17b4>  // b.hs, b.nlast
    bb88:	d350fc22 	lsr	x2, x1, #16
    bb8c:	f949fc63 	ldr	x3, [x3, #5112]
    bb90:	8b020842 	add	x2, x2, x2, lsl #2
    bb94:	d37df042 	lsl	x2, x2, #3
    bb98:	8b020060 	add	x0, x3, x2
    bb9c:	f9401017 	ldr	x23, [x0, #32]
    bba0:	b4000257 	cbz	x23, bbe8 <f0+0x17b4>
    bba4:	38626862 	ldrb	w2, [x3, x2]
    bba8:	7100085f 	cmp	w2, #0x2
    bbac:	54005fa0 	b.eq	c7a0 <f0+0x236c>  // b.none
    bbb0:	7100045f 	cmp	w2, #0x1
    bbb4:	540001a1 	b.ne	bbe8 <f0+0x17b4>  // b.any
    bbb8:	29430002 	ldp	w2, w0, [x0, #24]
    bbbc:	92403c21 	and	x1, x1, #0xffff
    bbc0:	9b027c21 	mul	x1, x1, x2
    bbc4:	d360fc21 	lsr	x1, x1, #32
    bbc8:	eb00003f 	cmp	x1, x0
    bbcc:	540000e2 	b.cs	bbe8 <f0+0x17b4>  // b.hs, b.nlast
    bbd0:	8b0102f7 	add	x23, x23, x1
    bbd4:	394002e0 	ldrb	w0, [x23]
    bbd8:	7103fc1f 	cmp	w0, #0xff
    bbdc:	540072c0 	b.eq	ca34 <f0+0x2600>  // b.none
    bbe0:	52800020 	mov	w0, #0x1                   	// #1
    bbe4:	390002e0 	strb	w0, [x23]
    bbe8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bbec:	9117a3e1 	add	x1, sp, #0x5e8
    bbf0:	52800020 	mov	w0, #0x1                   	// #1
    bbf4:	f902f7e2 	str	x2, [sp, #1512]
    bbf8:	f902fbf5 	str	x21, [sp, #1520]
    bbfc:	97ffe5a9 	bl	52a0 <fwp_data.part.0.constprop.0>
    bc00:	9118c283 	add	x3, x20, #0x630
    bc04:	aa0003f5 	mov	x21, x0
    bc08:	f949d861 	ldr	x1, [x3, #5040]
    bc0c:	f949ec60 	ldr	x0, [x3, #5080]
    bc10:	cb0102a1 	sub	x1, x21, x1
    bc14:	eb00403f 	cmp	x1, x0, lsl #16
    bc18:	54000322 	b.cs	bc7c <f0+0x1848>  // b.hs, b.nlast
    bc1c:	d350fc22 	lsr	x2, x1, #16
    bc20:	f949fc63 	ldr	x3, [x3, #5112]
    bc24:	8b020842 	add	x2, x2, x2, lsl #2
    bc28:	d37df042 	lsl	x2, x2, #3
    bc2c:	8b020060 	add	x0, x3, x2
    bc30:	f9401017 	ldr	x23, [x0, #32]
    bc34:	b4000257 	cbz	x23, bc7c <f0+0x1848>
    bc38:	38626862 	ldrb	w2, [x3, x2]
    bc3c:	7100085f 	cmp	w2, #0x2
    bc40:	54005aa0 	b.eq	c794 <f0+0x2360>  // b.none
    bc44:	7100045f 	cmp	w2, #0x1
    bc48:	540001a1 	b.ne	bc7c <f0+0x1848>  // b.any
    bc4c:	29430002 	ldp	w2, w0, [x0, #24]
    bc50:	92403c21 	and	x1, x1, #0xffff
    bc54:	9b027c21 	mul	x1, x1, x2
    bc58:	d360fc21 	lsr	x1, x1, #32
    bc5c:	eb00003f 	cmp	x1, x0
    bc60:	540000e2 	b.cs	bc7c <f0+0x1848>  // b.hs, b.nlast
    bc64:	8b0102f7 	add	x23, x23, x1
    bc68:	394002e0 	ldrb	w0, [x23]
    bc6c:	7103fc1f 	cmp	w0, #0xff
    bc70:	54006e80 	b.eq	ca40 <f0+0x260c>  // b.none
    bc74:	52800020 	mov	w0, #0x1                   	// #1
    bc78:	390002e0 	strb	w0, [x23]
    bc7c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bc80:	9117e3e1 	add	x1, sp, #0x5f8
    bc84:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bc88:	52800020 	mov	w0, #0x1                   	// #1
    bc8c:	f902ffe2 	str	x2, [sp, #1528]
    bc90:	f90303f5 	str	x21, [sp, #1536]
    bc94:	97ffe583 	bl	52a0 <fwp_data.part.0.constprop.0>
    bc98:	9118c283 	add	x3, x20, #0x630
    bc9c:	aa0003f5 	mov	x21, x0
    bca0:	f949d861 	ldr	x1, [x3, #5040]
    bca4:	f949ec60 	ldr	x0, [x3, #5080]
    bca8:	cb0102a1 	sub	x1, x21, x1
    bcac:	eb00403f 	cmp	x1, x0, lsl #16
    bcb0:	54000322 	b.cs	bd14 <f0+0x18e0>  // b.hs, b.nlast
    bcb4:	d350fc22 	lsr	x2, x1, #16
    bcb8:	f949fc63 	ldr	x3, [x3, #5112]
    bcbc:	8b020842 	add	x2, x2, x2, lsl #2
    bcc0:	d37df042 	lsl	x2, x2, #3
    bcc4:	8b020060 	add	x0, x3, x2
    bcc8:	f9401017 	ldr	x23, [x0, #32]
    bccc:	b4000257 	cbz	x23, bd14 <f0+0x18e0>
    bcd0:	38626862 	ldrb	w2, [x3, x2]
    bcd4:	7100085f 	cmp	w2, #0x2
    bcd8:	54005700 	b.eq	c7b8 <f0+0x2384>  // b.none
    bcdc:	7100045f 	cmp	w2, #0x1
    bce0:	540001a1 	b.ne	bd14 <f0+0x18e0>  // b.any
    bce4:	29430002 	ldp	w2, w0, [x0, #24]
    bce8:	92403c21 	and	x1, x1, #0xffff
    bcec:	9b027c21 	mul	x1, x1, x2
    bcf0:	d360fc21 	lsr	x1, x1, #32
    bcf4:	eb00003f 	cmp	x1, x0
    bcf8:	540000e2 	b.cs	bd14 <f0+0x18e0>  // b.hs, b.nlast
    bcfc:	8b0102f7 	add	x23, x23, x1
    bd00:	394002e0 	ldrb	w0, [x23]
    bd04:	7103fc1f 	cmp	w0, #0xff
    bd08:	54006a20 	b.eq	ca4c <f0+0x2618>  // b.none
    bd0c:	52800020 	mov	w0, #0x1                   	// #1
    bd10:	390002e0 	strb	w0, [x23]
    bd14:	911823e1 	add	x1, sp, #0x608
    bd18:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bd1c:	52800020 	mov	w0, #0x1                   	// #1
    bd20:	f90307e2 	str	x2, [sp, #1544]
    bd24:	f9030bf5 	str	x21, [sp, #1552]
    bd28:	97ffe55e 	bl	52a0 <fwp_data.part.0.constprop.0>
    bd2c:	97ffe7d5 	bl	5c80 <fwp_rc_fresh>
    bd30:	aa0003e2 	mov	x2, x0
    bd34:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bd38:	911863e1 	add	x1, sp, #0x618
    bd3c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bd40:	52800020 	mov	w0, #0x1                   	// #1
    bd44:	f9030fe3 	str	x3, [sp, #1560]
    bd48:	f90313e2 	str	x2, [sp, #1568]
    bd4c:	97ffe555 	bl	52a0 <fwp_data.part.0.constprop.0>
    bd50:	9118c283 	add	x3, x20, #0x630
    bd54:	aa0003f5 	mov	x21, x0
    bd58:	f949d861 	ldr	x1, [x3, #5040]
    bd5c:	f949ec60 	ldr	x0, [x3, #5080]
    bd60:	cb0102a1 	sub	x1, x21, x1
    bd64:	eb00403f 	cmp	x1, x0, lsl #16
    bd68:	54000322 	b.cs	bdcc <f0+0x1998>  // b.hs, b.nlast
    bd6c:	d350fc22 	lsr	x2, x1, #16
    bd70:	f949fc63 	ldr	x3, [x3, #5112]
    bd74:	8b020842 	add	x2, x2, x2, lsl #2
    bd78:	d37df042 	lsl	x2, x2, #3
    bd7c:	8b020060 	add	x0, x3, x2
    bd80:	f9401017 	ldr	x23, [x0, #32]
    bd84:	b4000257 	cbz	x23, bdcc <f0+0x1998>
    bd88:	38626862 	ldrb	w2, [x3, x2]
    bd8c:	7100085f 	cmp	w2, #0x2
    bd90:	540050e0 	b.eq	c7ac <f0+0x2378>  // b.none
    bd94:	7100045f 	cmp	w2, #0x1
    bd98:	540001a1 	b.ne	bdcc <f0+0x1998>  // b.any
    bd9c:	29430002 	ldp	w2, w0, [x0, #24]
    bda0:	92403c21 	and	x1, x1, #0xffff
    bda4:	9b027c21 	mul	x1, x1, x2
    bda8:	d360fc21 	lsr	x1, x1, #32
    bdac:	eb00003f 	cmp	x1, x0
    bdb0:	540000e2 	b.cs	bdcc <f0+0x1998>  // b.hs, b.nlast
    bdb4:	8b0102f7 	add	x23, x23, x1
    bdb8:	394002e0 	ldrb	w0, [x23]
    bdbc:	7103fc1f 	cmp	w0, #0xff
    bdc0:	540064c0 	b.eq	ca58 <f0+0x2624>  // b.none
    bdc4:	52800020 	mov	w0, #0x1                   	// #1
    bdc8:	390002e0 	strb	w0, [x23]
    bdcc:	9118a3e1 	add	x1, sp, #0x628
    bdd0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bdd4:	52800020 	mov	w0, #0x1                   	// #1
    bdd8:	f90317f7 	str	x23, [sp, #1576]
    bddc:	f9031bf5 	str	x21, [sp, #1584]
    bde0:	97ffe530 	bl	52a0 <fwp_data.part.0.constprop.0>
    bde4:	97ffe7a7 	bl	5c80 <fwp_rc_fresh>
    bde8:	aa0003e2 	mov	x2, x0
    bdec:	9118e3e1 	add	x1, sp, #0x638
    bdf0:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bdf4:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bdf8:	52800020 	mov	w0, #0x1                   	// #1
    bdfc:	f9031ff5 	str	x21, [sp, #1592]
    be00:	f90323e2 	str	x2, [sp, #1600]
    be04:	97ffe527 	bl	52a0 <fwp_data.part.0.constprop.0>
    be08:	97ffe79e 	bl	5c80 <fwp_rc_fresh>
    be0c:	aa0003e2 	mov	x2, x0
    be10:	911923e1 	add	x1, sp, #0x648
    be14:	52800020 	mov	w0, #0x1                   	// #1
    be18:	f90327f7 	str	x23, [sp, #1608]
    be1c:	f9032be2 	str	x2, [sp, #1616]
    be20:	97ffe520 	bl	52a0 <fwp_data.part.0.constprop.0>
    be24:	97ffe797 	bl	5c80 <fwp_rc_fresh>
    be28:	aa0003e2 	mov	x2, x0
    be2c:	911963e1 	add	x1, sp, #0x658
    be30:	52800020 	mov	w0, #0x1                   	// #1
    be34:	f9032ff5 	str	x21, [sp, #1624]
    be38:	f90333e2 	str	x2, [sp, #1632]
    be3c:	97ffe519 	bl	52a0 <fwp_data.part.0.constprop.0>
    be40:	97ffe790 	bl	5c80 <fwp_rc_fresh>
    be44:	aa0003e2 	mov	x2, x0
    be48:	9119a3e1 	add	x1, sp, #0x668
    be4c:	52800020 	mov	w0, #0x1                   	// #1
    be50:	f90337f7 	str	x23, [sp, #1640]
    be54:	f9033be2 	str	x2, [sp, #1648]
    be58:	97ffe512 	bl	52a0 <fwp_data.part.0.constprop.0>
    be5c:	9118c283 	add	x3, x20, #0x630
    be60:	aa0003f5 	mov	x21, x0
    be64:	f949d861 	ldr	x1, [x3, #5040]
    be68:	f949ec60 	ldr	x0, [x3, #5080]
    be6c:	cb0102a1 	sub	x1, x21, x1
    be70:	eb00403f 	cmp	x1, x0, lsl #16
    be74:	54000322 	b.cs	bed8 <f0+0x1aa4>  // b.hs, b.nlast
    be78:	d350fc22 	lsr	x2, x1, #16
    be7c:	f949fc63 	ldr	x3, [x3, #5112]
    be80:	8b020842 	add	x2, x2, x2, lsl #2
    be84:	d37df042 	lsl	x2, x2, #3
    be88:	8b020060 	add	x0, x3, x2
    be8c:	f9401017 	ldr	x23, [x0, #32]
    be90:	b4000257 	cbz	x23, bed8 <f0+0x1aa4>
    be94:	38626862 	ldrb	w2, [x3, x2]
    be98:	7100085f 	cmp	w2, #0x2
    be9c:	540049a0 	b.eq	c7d0 <f0+0x239c>  // b.none
    bea0:	7100045f 	cmp	w2, #0x1
    bea4:	540001a1 	b.ne	bed8 <f0+0x1aa4>  // b.any
    bea8:	29430002 	ldp	w2, w0, [x0, #24]
    beac:	92403c21 	and	x1, x1, #0xffff
    beb0:	9b027c21 	mul	x1, x1, x2
    beb4:	d360fc21 	lsr	x1, x1, #32
    beb8:	eb00003f 	cmp	x1, x0
    bebc:	540000e2 	b.cs	bed8 <f0+0x1aa4>  // b.hs, b.nlast
    bec0:	8b0102f7 	add	x23, x23, x1
    bec4:	394002e0 	ldrb	w0, [x23]
    bec8:	7103fc1f 	cmp	w0, #0xff
    becc:	54005cc0 	b.eq	ca64 <f0+0x2630>  // b.none
    bed0:	52800020 	mov	w0, #0x1                   	// #1
    bed4:	390002e0 	strb	w0, [x23]
    bed8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bedc:	9119e3e1 	add	x1, sp, #0x678
    bee0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bee4:	52800020 	mov	w0, #0x1                   	// #1
    bee8:	f9033fe2 	str	x2, [sp, #1656]
    beec:	f90343f5 	str	x21, [sp, #1664]
    bef0:	97ffe4ec 	bl	52a0 <fwp_data.part.0.constprop.0>
    bef4:	9118c283 	add	x3, x20, #0x630
    bef8:	aa0003f5 	mov	x21, x0
    befc:	f949d861 	ldr	x1, [x3, #5040]
    bf00:	f949ec60 	ldr	x0, [x3, #5080]
    bf04:	cb0102a1 	sub	x1, x21, x1
    bf08:	eb00403f 	cmp	x1, x0, lsl #16
    bf0c:	54000322 	b.cs	bf70 <f0+0x1b3c>  // b.hs, b.nlast
    bf10:	d350fc22 	lsr	x2, x1, #16
    bf14:	f949fc63 	ldr	x3, [x3, #5112]
    bf18:	8b020842 	add	x2, x2, x2, lsl #2
    bf1c:	d37df042 	lsl	x2, x2, #3
    bf20:	8b020060 	add	x0, x3, x2
    bf24:	f9401017 	ldr	x23, [x0, #32]
    bf28:	b4000257 	cbz	x23, bf70 <f0+0x1b3c>
    bf2c:	38626862 	ldrb	w2, [x3, x2]
    bf30:	7100085f 	cmp	w2, #0x2
    bf34:	54004480 	b.eq	c7c4 <f0+0x2390>  // b.none
    bf38:	7100045f 	cmp	w2, #0x1
    bf3c:	540001a1 	b.ne	bf70 <f0+0x1b3c>  // b.any
    bf40:	29430002 	ldp	w2, w0, [x0, #24]
    bf44:	92403c21 	and	x1, x1, #0xffff
    bf48:	9b027c21 	mul	x1, x1, x2
    bf4c:	d360fc21 	lsr	x1, x1, #32
    bf50:	eb00003f 	cmp	x1, x0
    bf54:	540000e2 	b.cs	bf70 <f0+0x1b3c>  // b.hs, b.nlast
    bf58:	8b0102f7 	add	x23, x23, x1
    bf5c:	394002e0 	ldrb	w0, [x23]
    bf60:	7103fc1f 	cmp	w0, #0xff
    bf64:	54005860 	b.eq	ca70 <f0+0x263c>  // b.none
    bf68:	52800020 	mov	w0, #0x1                   	// #1
    bf6c:	390002e0 	strb	w0, [x23]
    bf70:	911a23e1 	add	x1, sp, #0x688
    bf74:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bf78:	52800020 	mov	w0, #0x1                   	// #1
    bf7c:	f90347f7 	str	x23, [sp, #1672]
    bf80:	f9034bf5 	str	x21, [sp, #1680]
    bf84:	97ffe4c7 	bl	52a0 <fwp_data.part.0.constprop.0>
    bf88:	97ffe73e 	bl	5c80 <fwp_rc_fresh>
    bf8c:	aa0003e2 	mov	x2, x0
    bf90:	911a63e1 	add	x1, sp, #0x698
    bf94:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bf98:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bf9c:	52800020 	mov	w0, #0x1                   	// #1
    bfa0:	f9034ff5 	str	x21, [sp, #1688]
    bfa4:	f90353e2 	str	x2, [sp, #1696]
    bfa8:	97ffe4be 	bl	52a0 <fwp_data.part.0.constprop.0>
    bfac:	97ffe735 	bl	5c80 <fwp_rc_fresh>
    bfb0:	aa0003e2 	mov	x2, x0
    bfb4:	911aa3e1 	add	x1, sp, #0x6a8
    bfb8:	52800020 	mov	w0, #0x1                   	// #1
    bfbc:	f90357f7 	str	x23, [sp, #1704]
    bfc0:	f9035be2 	str	x2, [sp, #1712]
    bfc4:	97ffe4b7 	bl	52a0 <fwp_data.part.0.constprop.0>
    bfc8:	97ffe72e 	bl	5c80 <fwp_rc_fresh>
    bfcc:	aa0003e2 	mov	x2, x0
    bfd0:	911ae3e1 	add	x1, sp, #0x6b8
    bfd4:	52800020 	mov	w0, #0x1                   	// #1
    bfd8:	f9035ff5 	str	x21, [sp, #1720]
    bfdc:	f90363e2 	str	x2, [sp, #1728]
    bfe0:	97ffe4b0 	bl	52a0 <fwp_data.part.0.constprop.0>
    bfe4:	9118c283 	add	x3, x20, #0x630
    bfe8:	aa0003f5 	mov	x21, x0
    bfec:	f949d861 	ldr	x1, [x3, #5040]
    bff0:	f949ec60 	ldr	x0, [x3, #5080]
    bff4:	cb0102a1 	sub	x1, x21, x1
    bff8:	eb00403f 	cmp	x1, x0, lsl #16
    bffc:	54000322 	b.cs	c060 <f0+0x1c2c>  // b.hs, b.nlast
    c000:	d350fc22 	lsr	x2, x1, #16
    c004:	f949fc63 	ldr	x3, [x3, #5112]
    c008:	8b020842 	add	x2, x2, x2, lsl #2
    c00c:	d37df042 	lsl	x2, x2, #3
    c010:	8b020060 	add	x0, x3, x2
    c014:	f9401017 	ldr	x23, [x0, #32]
    c018:	b4000257 	cbz	x23, c060 <f0+0x1c2c>
    c01c:	38626862 	ldrb	w2, [x3, x2]
    c020:	7100085f 	cmp	w2, #0x2
    c024:	54003e20 	b.eq	c7e8 <f0+0x23b4>  // b.none
    c028:	7100045f 	cmp	w2, #0x1
    c02c:	540001a1 	b.ne	c060 <f0+0x1c2c>  // b.any
    c030:	29430002 	ldp	w2, w0, [x0, #24]
    c034:	92403c21 	and	x1, x1, #0xffff
    c038:	9b027c21 	mul	x1, x1, x2
    c03c:	d360fc21 	lsr	x1, x1, #32
    c040:	eb00003f 	cmp	x1, x0
    c044:	540000e2 	b.cs	c060 <f0+0x1c2c>  // b.hs, b.nlast
    c048:	8b0102f7 	add	x23, x23, x1
    c04c:	394002e0 	ldrb	w0, [x23]
    c050:	7103fc1f 	cmp	w0, #0xff
    c054:	54005140 	b.eq	ca7c <f0+0x2648>  // b.none
    c058:	52800020 	mov	w0, #0x1                   	// #1
    c05c:	390002e0 	strb	w0, [x23]
    c060:	911b23e1 	add	x1, sp, #0x6c8
    c064:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c068:	52800020 	mov	w0, #0x1                   	// #1
    c06c:	f90367e2 	str	x2, [sp, #1736]
    c070:	f9036bf5 	str	x21, [sp, #1744]
    c074:	97ffe48b 	bl	52a0 <fwp_data.part.0.constprop.0>
    c078:	97ffe702 	bl	5c80 <fwp_rc_fresh>
    c07c:	aa0003e2 	mov	x2, x0
    c080:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c084:	911b63e1 	add	x1, sp, #0x6d8
    c088:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c08c:	52800020 	mov	w0, #0x1                   	// #1
    c090:	f9036fe3 	str	x3, [sp, #1752]
    c094:	f90373e2 	str	x2, [sp, #1760]
    c098:	97ffe482 	bl	52a0 <fwp_data.part.0.constprop.0>
    c09c:	9118c283 	add	x3, x20, #0x630
    c0a0:	aa0003f5 	mov	x21, x0
    c0a4:	f949d861 	ldr	x1, [x3, #5040]
    c0a8:	f949ec60 	ldr	x0, [x3, #5080]
    c0ac:	cb0102a1 	sub	x1, x21, x1
    c0b0:	eb00403f 	cmp	x1, x0, lsl #16
    c0b4:	54000322 	b.cs	c118 <f0+0x1ce4>  // b.hs, b.nlast
    c0b8:	d350fc22 	lsr	x2, x1, #16
    c0bc:	f949fc63 	ldr	x3, [x3, #5112]
    c0c0:	8b020842 	add	x2, x2, x2, lsl #2
    c0c4:	d37df042 	lsl	x2, x2, #3
    c0c8:	8b020060 	add	x0, x3, x2
    c0cc:	f9401017 	ldr	x23, [x0, #32]
    c0d0:	b4000257 	cbz	x23, c118 <f0+0x1ce4>
    c0d4:	38626862 	ldrb	w2, [x3, x2]
    c0d8:	7100085f 	cmp	w2, #0x2
    c0dc:	54003800 	b.eq	c7dc <f0+0x23a8>  // b.none
    c0e0:	7100045f 	cmp	w2, #0x1
    c0e4:	540001a1 	b.ne	c118 <f0+0x1ce4>  // b.any
    c0e8:	29430002 	ldp	w2, w0, [x0, #24]
    c0ec:	92403c21 	and	x1, x1, #0xffff
    c0f0:	9b027c21 	mul	x1, x1, x2
    c0f4:	d360fc21 	lsr	x1, x1, #32
    c0f8:	eb00003f 	cmp	x1, x0
    c0fc:	540000e2 	b.cs	c118 <f0+0x1ce4>  // b.hs, b.nlast
    c100:	8b0102f7 	add	x23, x23, x1
    c104:	394002e0 	ldrb	w0, [x23]
    c108:	7103fc1f 	cmp	w0, #0xff
    c10c:	54004be0 	b.eq	ca88 <f0+0x2654>  // b.none
    c110:	52800020 	mov	w0, #0x1                   	// #1
    c114:	390002e0 	strb	w0, [x23]
    c118:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c11c:	911ba3e1 	add	x1, sp, #0x6e8
    c120:	52800020 	mov	w0, #0x1                   	// #1
    c124:	f90377e2 	str	x2, [sp, #1768]
    c128:	f9037bf5 	str	x21, [sp, #1776]
    c12c:	97ffe45d 	bl	52a0 <fwp_data.part.0.constprop.0>
    c130:	9118c283 	add	x3, x20, #0x630
    c134:	aa0003f5 	mov	x21, x0
    c138:	f949d861 	ldr	x1, [x3, #5040]
    c13c:	f949ec60 	ldr	x0, [x3, #5080]
    c140:	cb0102a1 	sub	x1, x21, x1
    c144:	eb00403f 	cmp	x1, x0, lsl #16
    c148:	54000322 	b.cs	c1ac <f0+0x1d78>  // b.hs, b.nlast
    c14c:	d350fc22 	lsr	x2, x1, #16
    c150:	f949fc63 	ldr	x3, [x3, #5112]
    c154:	8b020842 	add	x2, x2, x2, lsl #2
    c158:	d37df042 	lsl	x2, x2, #3
    c15c:	8b020060 	add	x0, x3, x2
    c160:	f9401017 	ldr	x23, [x0, #32]
    c164:	b4000257 	cbz	x23, c1ac <f0+0x1d78>
    c168:	38626862 	ldrb	w2, [x3, x2]
    c16c:	7100085f 	cmp	w2, #0x2
    c170:	54003480 	b.eq	c800 <f0+0x23cc>  // b.none
    c174:	7100045f 	cmp	w2, #0x1
    c178:	540001a1 	b.ne	c1ac <f0+0x1d78>  // b.any
    c17c:	29430002 	ldp	w2, w0, [x0, #24]
    c180:	92403c21 	and	x1, x1, #0xffff
    c184:	9b027c21 	mul	x1, x1, x2
    c188:	d360fc21 	lsr	x1, x1, #32
    c18c:	eb00003f 	cmp	x1, x0
    c190:	540000e2 	b.cs	c1ac <f0+0x1d78>  // b.hs, b.nlast
    c194:	8b0102f7 	add	x23, x23, x1
    c198:	394002e0 	ldrb	w0, [x23]
    c19c:	7103fc1f 	cmp	w0, #0xff
    c1a0:	540047a0 	b.eq	ca94 <f0+0x2660>  // b.none
    c1a4:	52800020 	mov	w0, #0x1                   	// #1
    c1a8:	390002e0 	strb	w0, [x23]
    c1ac:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c1b0:	911be3e1 	add	x1, sp, #0x6f8
    c1b4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c1b8:	52800020 	mov	w0, #0x1                   	// #1
    c1bc:	f9037fe2 	str	x2, [sp, #1784]
    c1c0:	f90383f5 	str	x21, [sp, #1792]
    c1c4:	97ffe437 	bl	52a0 <fwp_data.part.0.constprop.0>
    c1c8:	97ffe6ae 	bl	5c80 <fwp_rc_fresh>
    c1cc:	aa0003e2 	mov	x2, x0
    c1d0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c1d4:	911c23e1 	add	x1, sp, #0x708
    c1d8:	52800020 	mov	w0, #0x1                   	// #1
    c1dc:	f90387e3 	str	x3, [sp, #1800]
    c1e0:	f9038be2 	str	x2, [sp, #1808]
    c1e4:	97ffe42f 	bl	52a0 <fwp_data.part.0.constprop.0>
    c1e8:	9118c283 	add	x3, x20, #0x630
    c1ec:	aa0003f5 	mov	x21, x0
    c1f0:	f949d861 	ldr	x1, [x3, #5040]
    c1f4:	f949ec60 	ldr	x0, [x3, #5080]
    c1f8:	cb0102a1 	sub	x1, x21, x1
    c1fc:	eb00403f 	cmp	x1, x0, lsl #16
    c200:	54000322 	b.cs	c264 <f0+0x1e30>  // b.hs, b.nlast
    c204:	d350fc22 	lsr	x2, x1, #16
    c208:	f949fc63 	ldr	x3, [x3, #5112]
    c20c:	8b020842 	add	x2, x2, x2, lsl #2
    c210:	d37df042 	lsl	x2, x2, #3
    c214:	8b020060 	add	x0, x3, x2
    c218:	f9401017 	ldr	x23, [x0, #32]
    c21c:	b4000257 	cbz	x23, c264 <f0+0x1e30>
    c220:	38626862 	ldrb	w2, [x3, x2]
    c224:	7100085f 	cmp	w2, #0x2
    c228:	54002e60 	b.eq	c7f4 <f0+0x23c0>  // b.none
    c22c:	7100045f 	cmp	w2, #0x1
    c230:	540001a1 	b.ne	c264 <f0+0x1e30>  // b.any
    c234:	29430002 	ldp	w2, w0, [x0, #24]
    c238:	92403c21 	and	x1, x1, #0xffff
    c23c:	9b027c21 	mul	x1, x1, x2
    c240:	d360fc21 	lsr	x1, x1, #32
    c244:	eb00003f 	cmp	x1, x0
    c248:	540000e2 	b.cs	c264 <f0+0x1e30>  // b.hs, b.nlast
    c24c:	8b0102f7 	add	x23, x23, x1
    c250:	394002e0 	ldrb	w0, [x23]
    c254:	7103fc1f 	cmp	w0, #0xff
    c258:	54004240 	b.eq	caa0 <f0+0x266c>  // b.none
    c25c:	52800020 	mov	w0, #0x1                   	// #1
    c260:	390002e0 	strb	w0, [x23]
    c264:	911c63e1 	add	x1, sp, #0x718
    c268:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c26c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c270:	52800020 	mov	w0, #0x1                   	// #1
    c274:	f9038ff7 	str	x23, [sp, #1816]
    c278:	f90393f5 	str	x21, [sp, #1824]
    c27c:	97ffe409 	bl	52a0 <fwp_data.part.0.constprop.0>
    c280:	97ffe680 	bl	5c80 <fwp_rc_fresh>
    c284:	aa0003e2 	mov	x2, x0
    c288:	911ca3e1 	add	x1, sp, #0x728
    c28c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c290:	52800020 	mov	w0, #0x1                   	// #1
    c294:	f90397f5 	str	x21, [sp, #1832]
    c298:	f9039be2 	str	x2, [sp, #1840]
    c29c:	97ffe401 	bl	52a0 <fwp_data.part.0.constprop.0>
    c2a0:	97ffe678 	bl	5c80 <fwp_rc_fresh>
    c2a4:	aa0003e2 	mov	x2, x0
    c2a8:	911ce3e1 	add	x1, sp, #0x738
    c2ac:	52800020 	mov	w0, #0x1                   	// #1
    c2b0:	f9039ff7 	str	x23, [sp, #1848]
    c2b4:	f903a3e2 	str	x2, [sp, #1856]
    c2b8:	97ffe3fa 	bl	52a0 <fwp_data.part.0.constprop.0>
    c2bc:	97ffe671 	bl	5c80 <fwp_rc_fresh>
    c2c0:	aa0003e2 	mov	x2, x0
    c2c4:	911d23e1 	add	x1, sp, #0x748
    c2c8:	52800020 	mov	w0, #0x1                   	// #1
    c2cc:	f903a7f5 	str	x21, [sp, #1864]
    c2d0:	f903abe2 	str	x2, [sp, #1872]
    c2d4:	97ffe3f3 	bl	52a0 <fwp_data.part.0.constprop.0>
    c2d8:	9118c283 	add	x3, x20, #0x630
    c2dc:	aa0003f5 	mov	x21, x0
    c2e0:	f949d861 	ldr	x1, [x3, #5040]
    c2e4:	f949ec60 	ldr	x0, [x3, #5080]
    c2e8:	cb0102a1 	sub	x1, x21, x1
    c2ec:	eb00403f 	cmp	x1, x0, lsl #16
    c2f0:	54000322 	b.cs	c354 <f0+0x1f20>  // b.hs, b.nlast
    c2f4:	d350fc22 	lsr	x2, x1, #16
    c2f8:	f949fc63 	ldr	x3, [x3, #5112]
    c2fc:	8b020842 	add	x2, x2, x2, lsl #2
    c300:	d37df042 	lsl	x2, x2, #3
    c304:	8b020060 	add	x0, x3, x2
    c308:	f9401017 	ldr	x23, [x0, #32]
    c30c:	b4000257 	cbz	x23, c354 <f0+0x1f20>
    c310:	38626862 	ldrb	w2, [x3, x2]
    c314:	7100085f 	cmp	w2, #0x2
    c318:	54002800 	b.eq	c818 <f0+0x23e4>  // b.none
    c31c:	7100045f 	cmp	w2, #0x1
    c320:	540001a1 	b.ne	c354 <f0+0x1f20>  // b.any
    c324:	29430002 	ldp	w2, w0, [x0, #24]
    c328:	92403c21 	and	x1, x1, #0xffff
    c32c:	9b027c21 	mul	x1, x1, x2
    c330:	d360fc21 	lsr	x1, x1, #32
    c334:	eb00003f 	cmp	x1, x0
    c338:	540000e2 	b.cs	c354 <f0+0x1f20>  // b.hs, b.nlast
    c33c:	8b0102f7 	add	x23, x23, x1
    c340:	394002e0 	ldrb	w0, [x23]
    c344:	7103fc1f 	cmp	w0, #0xff
    c348:	54003b20 	b.eq	caac <f0+0x2678>  // b.none
    c34c:	52800020 	mov	w0, #0x1                   	// #1
    c350:	390002e0 	strb	w0, [x23]
    c354:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c358:	911d63e1 	add	x1, sp, #0x758
    c35c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c360:	52800020 	mov	w0, #0x1                   	// #1
    c364:	f903afe2 	str	x2, [sp, #1880]
    c368:	f903b3f5 	str	x21, [sp, #1888]
    c36c:	97ffe3cd 	bl	52a0 <fwp_data.part.0.constprop.0>
    c370:	9118c283 	add	x3, x20, #0x630
    c374:	aa0003f5 	mov	x21, x0
    c378:	f949d861 	ldr	x1, [x3, #5040]
    c37c:	f949ec60 	ldr	x0, [x3, #5080]
    c380:	cb0102a1 	sub	x1, x21, x1
    c384:	eb00403f 	cmp	x1, x0, lsl #16
    c388:	54000322 	b.cs	c3ec <f0+0x1fb8>  // b.hs, b.nlast
    c38c:	d350fc22 	lsr	x2, x1, #16
    c390:	f949fc63 	ldr	x3, [x3, #5112]
    c394:	8b020842 	add	x2, x2, x2, lsl #2
    c398:	d37df042 	lsl	x2, x2, #3
    c39c:	8b020060 	add	x0, x3, x2
    c3a0:	f9401017 	ldr	x23, [x0, #32]
    c3a4:	b4000257 	cbz	x23, c3ec <f0+0x1fb8>
    c3a8:	38626862 	ldrb	w2, [x3, x2]
    c3ac:	7100085f 	cmp	w2, #0x2
    c3b0:	540022e0 	b.eq	c80c <f0+0x23d8>  // b.none
    c3b4:	7100045f 	cmp	w2, #0x1
    c3b8:	540001a1 	b.ne	c3ec <f0+0x1fb8>  // b.any
    c3bc:	29430002 	ldp	w2, w0, [x0, #24]
    c3c0:	92403c21 	and	x1, x1, #0xffff
    c3c4:	9b027c21 	mul	x1, x1, x2
    c3c8:	d360fc21 	lsr	x1, x1, #32
    c3cc:	eb00003f 	cmp	x1, x0
    c3d0:	540000e2 	b.cs	c3ec <f0+0x1fb8>  // b.hs, b.nlast
    c3d4:	8b0102f7 	add	x23, x23, x1
    c3d8:	394002e0 	ldrb	w0, [x23]
    c3dc:	7103fc1f 	cmp	w0, #0xff
    c3e0:	540036c0 	b.eq	cab8 <f0+0x2684>  // b.none
    c3e4:	52800020 	mov	w0, #0x1                   	// #1
    c3e8:	390002e0 	strb	w0, [x23]
    c3ec:	911da3e1 	add	x1, sp, #0x768
    c3f0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    c3f4:	52800020 	mov	w0, #0x1                   	// #1
    c3f8:	f903b7f7 	str	x23, [sp, #1896]
    c3fc:	f903bbf5 	str	x21, [sp, #1904]
    c400:	97ffe3a8 	bl	52a0 <fwp_data.part.0.constprop.0>
    c404:	97ffe61f 	bl	5c80 <fwp_rc_fresh>
    c408:	aa0003e2 	mov	x2, x0
    c40c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c410:	911de3e1 	add	x1, sp, #0x778
    c414:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c418:	52800020 	mov	w0, #0x1                   	// #1
    c41c:	f903bfe3 	str	x3, [sp, #1912]
    c420:	f903c3e2 	str	x2, [sp, #1920]
    c424:	97ffe39f 	bl	52a0 <fwp_data.part.0.constprop.0>
    c428:	97ffe616 	bl	5c80 <fwp_rc_fresh>
    c42c:	aa0003e2 	mov	x2, x0
    c430:	911e23e1 	add	x1, sp, #0x788
    c434:	52800020 	mov	w0, #0x1                   	// #1
    c438:	f903c7f7 	str	x23, [sp, #1928]
    c43c:	f903cbe2 	str	x2, [sp, #1936]
    c440:	97ffe398 	bl	52a0 <fwp_data.part.0.constprop.0>
    c444:	9118c283 	add	x3, x20, #0x630
    c448:	aa0003f5 	mov	x21, x0
    c44c:	f949d861 	ldr	x1, [x3, #5040]
    c450:	f949ec60 	ldr	x0, [x3, #5080]
    c454:	cb0102a1 	sub	x1, x21, x1
    c458:	eb00403f 	cmp	x1, x0, lsl #16
    c45c:	54000322 	b.cs	c4c0 <f0+0x208c>  // b.hs, b.nlast
    c460:	d350fc22 	lsr	x2, x1, #16
    c464:	f949fc63 	ldr	x3, [x3, #5112]
    c468:	8b020842 	add	x2, x2, x2, lsl #2
    c46c:	d37df042 	lsl	x2, x2, #3
    c470:	8b020060 	add	x0, x3, x2
    c474:	f9401017 	ldr	x23, [x0, #32]
    c478:	b4000257 	cbz	x23, c4c0 <f0+0x208c>
    c47c:	38626862 	ldrb	w2, [x3, x2]
    c480:	7100085f 	cmp	w2, #0x2
    c484:	54001d60 	b.eq	c830 <f0+0x23fc>  // b.none
    c488:	7100045f 	cmp	w2, #0x1
    c48c:	540001a1 	b.ne	c4c0 <f0+0x208c>  // b.any
    c490:	29430002 	ldp	w2, w0, [x0, #24]
    c494:	92403c21 	and	x1, x1, #0xffff
    c498:	9b027c21 	mul	x1, x1, x2
    c49c:	d360fc21 	lsr	x1, x1, #32
    c4a0:	eb00003f 	cmp	x1, x0
    c4a4:	540000e2 	b.cs	c4c0 <f0+0x208c>  // b.hs, b.nlast
    c4a8:	8b0102f7 	add	x23, x23, x1
    c4ac:	394002e0 	ldrb	w0, [x23]
    c4b0:	7103fc1f 	cmp	w0, #0xff
    c4b4:	54003080 	b.eq	cac4 <f0+0x2690>  // b.none
    c4b8:	52800020 	mov	w0, #0x1                   	// #1
    c4bc:	390002e0 	strb	w0, [x23]
    c4c0:	911e63e1 	add	x1, sp, #0x798
    c4c4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c4c8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c4cc:	52800020 	mov	w0, #0x1                   	// #1
    c4d0:	f903cff7 	str	x23, [sp, #1944]
    c4d4:	9118c294 	add	x20, x20, #0x630
    c4d8:	f903d3f5 	str	x21, [sp, #1952]
    c4dc:	97ffe371 	bl	52a0 <fwp_data.part.0.constprop.0>
    c4e0:	97ffe5e8 	bl	5c80 <fwp_rc_fresh>
    c4e4:	aa0003e2 	mov	x2, x0
    c4e8:	911ea3e1 	add	x1, sp, #0x7a8
    c4ec:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    c4f0:	52800020 	mov	w0, #0x1                   	// #1
    c4f4:	f903d7f5 	str	x21, [sp, #1960]
    c4f8:	f903dbe2 	str	x2, [sp, #1968]
    c4fc:	97ffe369 	bl	52a0 <fwp_data.part.0.constprop.0>
    c500:	97ffe5e0 	bl	5c80 <fwp_rc_fresh>
    c504:	aa0003e2 	mov	x2, x0
    c508:	911ee3e1 	add	x1, sp, #0x7b8
    c50c:	52800020 	mov	w0, #0x1                   	// #1
    c510:	f903dff7 	str	x23, [sp, #1976]
    c514:	f903e3e2 	str	x2, [sp, #1984]
    c518:	97ffe362 	bl	52a0 <fwp_data.part.0.constprop.0>
    c51c:	97ffe5d9 	bl	5c80 <fwp_rc_fresh>
    c520:	aa0003e2 	mov	x2, x0
    c524:	911f23e1 	add	x1, sp, #0x7c8
    c528:	52800020 	mov	w0, #0x1                   	// #1
    c52c:	f903e7f5 	str	x21, [sp, #1992]
    c530:	f903ebe2 	str	x2, [sp, #2000]
    c534:	97ffe35b 	bl	52a0 <fwp_data.part.0.constprop.0>
    c538:	97ffe5d2 	bl	5c80 <fwp_rc_fresh>
    c53c:	aa0003e2 	mov	x2, x0
    c540:	911f63e1 	add	x1, sp, #0x7d8
    c544:	52800020 	mov	w0, #0x1                   	// #1
    c548:	f903eff7 	str	x23, [sp, #2008]
    c54c:	f903f3e2 	str	x2, [sp, #2016]
    c550:	97ffe354 	bl	52a0 <fwp_data.part.0.constprop.0>
    c554:	97ffe5cb 	bl	5c80 <fwp_rc_fresh>
    c558:	aa0003e2 	mov	x2, x0
    c55c:	911fa3e1 	add	x1, sp, #0x7e8
    c560:	52800020 	mov	w0, #0x1                   	// #1
    c564:	f903f7f5 	str	x21, [sp, #2024]
    c568:	f903fbe2 	str	x2, [sp, #2032]
    c56c:	97ffe34d 	bl	52a0 <fwp_data.part.0.constprop.0>
    c570:	97ffe5c4 	bl	5c80 <fwp_rc_fresh>
    c574:	aa0003e2 	mov	x2, x0
    c578:	911fe3e1 	add	x1, sp, #0x7f8
    c57c:	52800020 	mov	w0, #0x1                   	// #1
    c580:	f903fff7 	str	x23, [sp, #2040]
    c584:	f90403e2 	str	x2, [sp, #2048]
    c588:	97ffe346 	bl	52a0 <fwp_data.part.0.constprop.0>
    c58c:	97ffe5bd 	bl	5c80 <fwp_rc_fresh>
    c590:	aa0003e2 	mov	x2, x0
    c594:	912023e1 	add	x1, sp, #0x808
    c598:	52800020 	mov	w0, #0x1                   	// #1
    c59c:	f90407f5 	str	x21, [sp, #2056]
    c5a0:	f9040be2 	str	x2, [sp, #2064]
    c5a4:	97ffe33f 	bl	52a0 <fwp_data.part.0.constprop.0>
    c5a8:	97ffe5b6 	bl	5c80 <fwp_rc_fresh>
    c5ac:	aa0003e2 	mov	x2, x0
    c5b0:	912063e1 	add	x1, sp, #0x818
    c5b4:	52800020 	mov	w0, #0x1                   	// #1
    c5b8:	f9040ff7 	str	x23, [sp, #2072]
    c5bc:	f90413e2 	str	x2, [sp, #2080]
    c5c0:	97ffe338 	bl	52a0 <fwp_data.part.0.constprop.0>
    c5c4:	97ffe5af 	bl	5c80 <fwp_rc_fresh>
    c5c8:	aa0003e2 	mov	x2, x0
    c5cc:	9120a3e1 	add	x1, sp, #0x828
    c5d0:	52800020 	mov	w0, #0x1                   	// #1
    c5d4:	f90417f5 	str	x21, [sp, #2088]
    c5d8:	f9041be2 	str	x2, [sp, #2096]
    c5dc:	97ffe331 	bl	52a0 <fwp_data.part.0.constprop.0>
    c5e0:	97ffe5a8 	bl	5c80 <fwp_rc_fresh>
    c5e4:	aa0003e2 	mov	x2, x0
    c5e8:	9120e3e1 	add	x1, sp, #0x838
    c5ec:	52800020 	mov	w0, #0x1                   	// #1
    c5f0:	f9041ff7 	str	x23, [sp, #2104]
    c5f4:	f90423e2 	str	x2, [sp, #2112]
    c5f8:	97ffe32a 	bl	52a0 <fwp_data.part.0.constprop.0>
    c5fc:	97ffe5a1 	bl	5c80 <fwp_rc_fresh>
    c600:	aa0003e2 	mov	x2, x0
    c604:	912123e1 	add	x1, sp, #0x848
    c608:	52800020 	mov	w0, #0x1                   	// #1
    c60c:	f90427f5 	str	x21, [sp, #2120]
    c610:	f9042be2 	str	x2, [sp, #2128]
    c614:	97ffe323 	bl	52a0 <fwp_data.part.0.constprop.0>
    c618:	f949da81 	ldr	x1, [x20, #5040]
    c61c:	aa0003f5 	mov	x21, x0
    c620:	f949ee80 	ldr	x0, [x20, #5080]
    c624:	cb0102a1 	sub	x1, x21, x1
    c628:	eb00403f 	cmp	x1, x0, lsl #16
    c62c:	54000322 	b.cs	c690 <f0+0x225c>  // b.hs, b.nlast
    c630:	d350fc22 	lsr	x2, x1, #16
    c634:	f949fe83 	ldr	x3, [x20, #5112]
    c638:	8b020842 	add	x2, x2, x2, lsl #2
    c63c:	d37df042 	lsl	x2, x2, #3
    c640:	8b020060 	add	x0, x3, x2
    c644:	f9401014 	ldr	x20, [x0, #32]
    c648:	b4000254 	cbz	x20, c690 <f0+0x225c>
    c64c:	38626862 	ldrb	w2, [x3, x2]
    c650:	7100085f 	cmp	w2, #0x2
    c654:	54000e80 	b.eq	c824 <f0+0x23f0>  // b.none
    c658:	7100045f 	cmp	w2, #0x1
    c65c:	540001a1 	b.ne	c690 <f0+0x225c>  // b.any
    c660:	29430002 	ldp	w2, w0, [x0, #24]
    c664:	92403c21 	and	x1, x1, #0xffff
    c668:	9b027c21 	mul	x1, x1, x2
    c66c:	d360fc21 	lsr	x1, x1, #32
    c670:	eb00003f 	cmp	x1, x0
    c674:	540000e2 	b.cs	c690 <f0+0x225c>  // b.hs, b.nlast
    c678:	8b010294 	add	x20, x20, x1
    c67c:	39400280 	ldrb	w0, [x20]
    c680:	7103fc1f 	cmp	w0, #0xff
    c684:	540013c0 	b.eq	c8fc <f0+0x24c8>  // b.none
    c688:	52800020 	mov	w0, #0x1                   	// #1
    c68c:	39000280 	strb	w0, [x20]
    c690:	aa1603e1 	mov	x1, x22
    c694:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    c698:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    c69c:	52800020 	mov	w0, #0x1                   	// #1
    c6a0:	f9042fe2 	str	x2, [sp, #2136]
    c6a4:	f90433f5 	str	x21, [sp, #2144]
    c6a8:	97ffe2fe 	bl	52a0 <fwp_data.part.0.constprop.0>
    c6ac:	97ffe575 	bl	5c80 <fwp_rc_fresh>
    c6b0:	aa0003f5 	mov	x21, x0
    c6b4:	aa1303e1 	mov	x1, x19
    c6b8:	97fff07a 	bl	88a0 <fwp_hof0.constprop.0>
    c6bc:	aa0003f4 	mov	x20, x0
    c6c0:	aa1503e0 	mov	x0, x21
    c6c4:	97ffe67b 	bl	60b0 <fwp_drop0>
    c6c8:	aa1303e0 	mov	x0, x19
    c6cc:	97ffe679 	bl	60b0 <fwp_drop0>
    c6d0:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    c6d4:	f947f400 	ldr	x0, [x0, #4072]
    c6d8:	f94437e2 	ldr	x2, [sp, #2152]
    c6dc:	f9400001 	ldr	x1, [x0]
    c6e0:	eb010042 	subs	x2, x2, x1
    c6e4:	d2800001 	mov	x1, #0x0                   	// #0
    c6e8:	54001f41 	b.ne	cad0 <f0+0x269c>  // b.any
    c6ec:	9121c3ff 	add	sp, sp, #0x870
    c6f0:	aa1403e0 	mov	x0, x20
    c6f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    c6f8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c6fc:	a94363f7 	ldp	x23, x24, [sp, #48]
    c700:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c704:	a94573fb 	ldp	x27, x28, [sp, #80]
    c708:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c70c:	d65f03c0 	ret
    c710:	aa1c03e0 	mov	x0, x28
    c714:	97ffdf28 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c718:	17fff790 	b	a558 <f0+0x124>
    c71c:	72003c5f 	tst	w2, #0xffff
    c720:	54fef1e1 	b.ne	a55c <f0+0x128>  // b.any
    c724:	17fff78a 	b	a54c <f0+0x118>
    c728:	72003c3f 	tst	w1, #0xffff
    c72c:	54ff0241 	b.ne	a774 <f0+0x340>  // b.any
    c730:	17fff80c 	b	a760 <f0+0x32c>
    c734:	72003c3f 	tst	w1, #0xffff
    c738:	54ff0e61 	b.ne	a904 <f0+0x4d0>  // b.any
    c73c:	17fff86d 	b	a8f0 <f0+0x4bc>
    c740:	72003c3f 	tst	w1, #0xffff
    c744:	54ff0701 	b.ne	a824 <f0+0x3f0>  // b.any
    c748:	17fff832 	b	a810 <f0+0x3dc>
    c74c:	72003c3f 	tst	w1, #0xffff
    c750:	54ff1a21 	b.ne	aa94 <f0+0x660>  // b.any
    c754:	17fff8cb 	b	aa80 <f0+0x64c>
    c758:	72003c3f 	tst	w1, #0xffff
    c75c:	54ff1441 	b.ne	a9e4 <f0+0x5b0>  // b.any
    c760:	17fff89c 	b	a9d0 <f0+0x59c>
    c764:	72003c3f 	tst	w1, #0xffff
    c768:	54ff2281 	b.ne	abb8 <f0+0x784>  // b.any
    c76c:	17fff90e 	b	aba4 <f0+0x770>
    c770:	72003c3f 	tst	w1, #0xffff
    c774:	54ff1d81 	b.ne	ab24 <f0+0x6f0>  // b.any
    c778:	17fff8e6 	b	ab10 <f0+0x6dc>
    c77c:	72003c3f 	tst	w1, #0xffff
    c780:	54ff9d81 	b.ne	bb30 <f0+0x16fc>  // b.any
    c784:	17fffce6 	b	bb1c <f0+0x16e8>
    c788:	72003c3f 	tst	w1, #0xffff
    c78c:	54ff95a1 	b.ne	ba40 <f0+0x160c>  // b.any
    c790:	17fffca7 	b	ba2c <f0+0x15f8>
    c794:	72003c3f 	tst	w1, #0xffff
    c798:	54ffa721 	b.ne	bc7c <f0+0x1848>  // b.any
    c79c:	17fffd33 	b	bc68 <f0+0x1834>
    c7a0:	72003c3f 	tst	w1, #0xffff
    c7a4:	54ffa221 	b.ne	bbe8 <f0+0x17b4>  // b.any
    c7a8:	17fffd0b 	b	bbd4 <f0+0x17a0>
    c7ac:	72003c3f 	tst	w1, #0xffff
    c7b0:	54ffb0e1 	b.ne	bdcc <f0+0x1998>  // b.any
    c7b4:	17fffd81 	b	bdb8 <f0+0x1984>
    c7b8:	72003c3f 	tst	w1, #0xffff
    c7bc:	54ffaac1 	b.ne	bd14 <f0+0x18e0>  // b.any
    c7c0:	17fffd50 	b	bd00 <f0+0x18cc>
    c7c4:	72003c3f 	tst	w1, #0xffff
    c7c8:	54ffbd41 	b.ne	bf70 <f0+0x1b3c>  // b.any
    c7cc:	17fffde4 	b	bf5c <f0+0x1b28>
    c7d0:	72003c3f 	tst	w1, #0xffff
    c7d4:	54ffb821 	b.ne	bed8 <f0+0x1aa4>  // b.any
    c7d8:	17fffdbb 	b	bec4 <f0+0x1a90>
    c7dc:	72003c3f 	tst	w1, #0xffff
    c7e0:	54ffc9c1 	b.ne	c118 <f0+0x1ce4>  // b.any
    c7e4:	17fffe48 	b	c104 <f0+0x1cd0>
    c7e8:	72003c3f 	tst	w1, #0xffff
    c7ec:	54ffc3a1 	b.ne	c060 <f0+0x1c2c>  // b.any
    c7f0:	17fffe17 	b	c04c <f0+0x1c18>
    c7f4:	72003c3f 	tst	w1, #0xffff
    c7f8:	54ffd361 	b.ne	c264 <f0+0x1e30>  // b.any
    c7fc:	17fffe95 	b	c250 <f0+0x1e1c>
    c800:	72003c3f 	tst	w1, #0xffff
    c804:	54ffcd41 	b.ne	c1ac <f0+0x1d78>  // b.any
    c808:	17fffe64 	b	c198 <f0+0x1d64>
    c80c:	72003c3f 	tst	w1, #0xffff
    c810:	54ffdee1 	b.ne	c3ec <f0+0x1fb8>  // b.any
    c814:	17fffef1 	b	c3d8 <f0+0x1fa4>
    c818:	72003c3f 	tst	w1, #0xffff
    c81c:	54ffd9c1 	b.ne	c354 <f0+0x1f20>  // b.any
    c820:	17fffec8 	b	c340 <f0+0x1f0c>
    c824:	72003c3f 	tst	w1, #0xffff
    c828:	54fff341 	b.ne	c690 <f0+0x225c>  // b.any
    c82c:	17ffff94 	b	c67c <f0+0x2248>
    c830:	72003c3f 	tst	w1, #0xffff
    c834:	54ffe461 	b.ne	c4c0 <f0+0x208c>  // b.any
    c838:	17ffff1d 	b	c4ac <f0+0x2078>
    c83c:	72003c3f 	tst	w1, #0xffff
    c840:	54ff2aa1 	b.ne	ad94 <f0+0x960>  // b.any
    c844:	17fff94f 	b	ad80 <f0+0x94c>
    c848:	72003c3f 	tst	w1, #0xffff
    c84c:	54ff2581 	b.ne	acfc <f0+0x8c8>  // b.any
    c850:	17fff926 	b	ace8 <f0+0x8b4>
    c854:	72003c3f 	tst	w1, #0xffff
    c858:	54ff3561 	b.ne	af04 <f0+0xad0>  // b.any
    c85c:	17fff9a5 	b	aef0 <f0+0xabc>
    c860:	72003c3f 	tst	w1, #0xffff
    c864:	54ff2f41 	b.ne	ae4c <f0+0xa18>  // b.any
    c868:	17fff974 	b	ae38 <f0+0xa04>
    c86c:	72003c3f 	tst	w1, #0xffff
    c870:	54ff3f01 	b.ne	b050 <f0+0xc1c>  // b.any
    c874:	17fff9f2 	b	b03c <f0+0xc08>
    c878:	72003c3f 	tst	w1, #0xffff
    c87c:	54ff3a01 	b.ne	afbc <f0+0xb88>  // b.any
    c880:	17fff9ca 	b	afa8 <f0+0xb74>
    c884:	72003c3f 	tst	w1, #0xffff
    c888:	54ff5521 	b.ne	b32c <f0+0xef8>  // b.any
    c88c:	17fffaa3 	b	b318 <f0+0xee4>
    c890:	72003c3f 	tst	w1, #0xffff
    c894:	54ff4d41 	b.ne	b23c <f0+0xe08>  // b.any
    c898:	17fffa64 	b	b228 <f0+0xdf4>
    c89c:	72003c3f 	tst	w1, #0xffff
    c8a0:	54ff6341 	b.ne	b508 <f0+0x10d4>  // b.any
    c8a4:	17fffb14 	b	b4f4 <f0+0x10c0>
    c8a8:	72003c3f 	tst	w1, #0xffff
    c8ac:	54ff5e21 	b.ne	b470 <f0+0x103c>  // b.any
    c8b0:	17fffaeb 	b	b45c <f0+0x1028>
    c8b4:	72003c3f 	tst	w1, #0xffff
    c8b8:	54ff6e01 	b.ne	b678 <f0+0x1244>  // b.any
    c8bc:	17fffb6a 	b	b664 <f0+0x1230>
    c8c0:	72003c3f 	tst	w1, #0xffff
    c8c4:	54ff67e1 	b.ne	b5c0 <f0+0x118c>  // b.any
    c8c8:	17fffb39 	b	b5ac <f0+0x1178>
    c8cc:	72003c3f 	tst	w1, #0xffff
    c8d0:	54ff78a1 	b.ne	b7e4 <f0+0x13b0>  // b.any
    c8d4:	17fffbbf 	b	b7d0 <f0+0x139c>
    c8d8:	72003c3f 	tst	w1, #0xffff
    c8dc:	54ff7381 	b.ne	b74c <f0+0x1318>  // b.any
    c8e0:	17fffb96 	b	b738 <f0+0x1304>
    c8e4:	72003c3f 	tst	w1, #0xffff
    c8e8:	54ff8601 	b.ne	b9a8 <f0+0x1574>  // b.any
    c8ec:	17fffc2a 	b	b994 <f0+0x1560>
    c8f0:	72003c3f 	tst	w1, #0xffff
    c8f4:	54ff7f01 	b.ne	b8d4 <f0+0x14a0>  // b.any
    c8f8:	17fffbf2 	b	b8c0 <f0+0x148c>
    c8fc:	aa1403e0 	mov	x0, x20
    c900:	97ffdead 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c904:	17ffff61 	b	c688 <f0+0x2254>
    c908:	aa1703e0 	mov	x0, x23
    c90c:	97ffdeaa 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c910:	17fff797 	b	a76c <f0+0x338>
    c914:	aa1703e0 	mov	x0, x23
    c918:	97ffdea7 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c91c:	17fff7c0 	b	a81c <f0+0x3e8>
    c920:	aa1703e0 	mov	x0, x23
    c924:	97ffdea4 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c928:	17fff7f5 	b	a8fc <f0+0x4c8>
    c92c:	aa1703e0 	mov	x0, x23
    c930:	97ffdea1 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c934:	17fff82a 	b	a9dc <f0+0x5a8>
    c938:	aa1703e0 	mov	x0, x23
    c93c:	97ffde9e 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c940:	17fff853 	b	aa8c <f0+0x658>
    c944:	aa1703e0 	mov	x0, x23
    c948:	97ffde9b 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c94c:	17fff874 	b	ab1c <f0+0x6e8>
    c950:	aa1503e0 	mov	x0, x21
    c954:	97ffde98 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c958:	17fff896 	b	abb0 <f0+0x77c>
    c95c:	aa1703e0 	mov	x0, x23
    c960:	97ffde95 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c964:	17fff8e4 	b	acf4 <f0+0x8c0>
    c968:	aa1703e0 	mov	x0, x23
    c96c:	97ffde92 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c970:	17fff907 	b	ad8c <f0+0x958>
    c974:	aa1703e0 	mov	x0, x23
    c978:	97ffde8f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c97c:	17fff932 	b	ae44 <f0+0xa10>
    c980:	aa1703e0 	mov	x0, x23
    c984:	97ffde8c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c988:	17fff95d 	b	aefc <f0+0xac8>
    c98c:	aa1703e0 	mov	x0, x23
    c990:	97ffde89 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c994:	17fff988 	b	afb4 <f0+0xb80>
    c998:	aa1503e0 	mov	x0, x21
    c99c:	97ffde86 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9a0:	17fff9aa 	b	b048 <f0+0xc14>
    c9a4:	aa1703e0 	mov	x0, x23
    c9a8:	97ffde83 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9ac:	17fffa22 	b	b234 <f0+0xe00>
    c9b0:	aa1503e0 	mov	x0, x21
    c9b4:	97ffde80 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9b8:	17fffa5b 	b	b324 <f0+0xef0>
    c9bc:	aa1703e0 	mov	x0, x23
    c9c0:	97ffde7d 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9c4:	17fffaa9 	b	b468 <f0+0x1034>
    c9c8:	aa1703e0 	mov	x0, x23
    c9cc:	97ffde7a 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9d0:	17fffacc 	b	b500 <f0+0x10cc>
    c9d4:	aa1703e0 	mov	x0, x23
    c9d8:	97ffde77 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9dc:	17fffaf7 	b	b5b8 <f0+0x1184>
    c9e0:	aa1703e0 	mov	x0, x23
    c9e4:	97ffde74 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9e8:	17fffb22 	b	b670 <f0+0x123c>
    c9ec:	aa1703e0 	mov	x0, x23
    c9f0:	97ffde71 	bl	43b4 <fwp_rc_forget_slot.part.0>
    c9f4:	17fffb54 	b	b744 <f0+0x1310>
    c9f8:	aa1703e0 	mov	x0, x23
    c9fc:	97ffde6e 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca00:	17fffb77 	b	b7dc <f0+0x13a8>
    ca04:	aa1703e0 	mov	x0, x23
    ca08:	97ffde6b 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca0c:	17fffbb0 	b	b8cc <f0+0x1498>
    ca10:	aa1703e0 	mov	x0, x23
    ca14:	97ffde68 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca18:	17fffbe2 	b	b9a0 <f0+0x156c>
    ca1c:	aa1703e0 	mov	x0, x23
    ca20:	97ffde65 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca24:	17fffc05 	b	ba38 <f0+0x1604>
    ca28:	aa1703e0 	mov	x0, x23
    ca2c:	97ffde62 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca30:	17fffc3e 	b	bb28 <f0+0x16f4>
    ca34:	aa1703e0 	mov	x0, x23
    ca38:	97ffde5f 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca3c:	17fffc69 	b	bbe0 <f0+0x17ac>
    ca40:	aa1703e0 	mov	x0, x23
    ca44:	97ffde5c 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca48:	17fffc8b 	b	bc74 <f0+0x1840>
    ca4c:	aa1703e0 	mov	x0, x23
    ca50:	97ffde59 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca54:	17fffcae 	b	bd0c <f0+0x18d8>
    ca58:	aa1703e0 	mov	x0, x23
    ca5c:	97ffde56 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca60:	17fffcd9 	b	bdc4 <f0+0x1990>
    ca64:	aa1703e0 	mov	x0, x23
    ca68:	97ffde53 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca6c:	17fffd19 	b	bed0 <f0+0x1a9c>
    ca70:	aa1703e0 	mov	x0, x23
    ca74:	97ffde50 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca78:	17fffd3c 	b	bf68 <f0+0x1b34>
    ca7c:	aa1703e0 	mov	x0, x23
    ca80:	97ffde4d 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca84:	17fffd75 	b	c058 <f0+0x1c24>
    ca88:	aa1703e0 	mov	x0, x23
    ca8c:	97ffde4a 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca90:	17fffda0 	b	c110 <f0+0x1cdc>
    ca94:	aa1703e0 	mov	x0, x23
    ca98:	97ffde47 	bl	43b4 <fwp_rc_forget_slot.part.0>
    ca9c:	17fffdc2 	b	c1a4 <f0+0x1d70>
    caa0:	aa1703e0 	mov	x0, x23
    caa4:	97ffde44 	bl	43b4 <fwp_rc_forget_slot.part.0>
    caa8:	17fffded 	b	c25c <f0+0x1e28>
    caac:	aa1703e0 	mov	x0, x23
    cab0:	97ffde41 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cab4:	17fffe26 	b	c34c <f0+0x1f18>
    cab8:	aa1703e0 	mov	x0, x23
    cabc:	97ffde3e 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cac0:	17fffe49 	b	c3e4 <f0+0x1fb0>
    cac4:	aa1703e0 	mov	x0, x23
    cac8:	97ffde3b 	bl	43b4 <fwp_rc_forget_slot.part.0>
    cacc:	17fffe7b 	b	c4b8 <f0+0x2084>
    cad0:	97ffd774 	bl	28a0 <__stack_chk_fail@plt>
    cad4:	97ffd787 	bl	28f0 <abort@plt>
    cad8:	d503201f 	nop
    cadc:	d503201f 	nop

000000000000cae0 <fwp_main_thread>:
    cae0:	d10443ff 	sub	sp, sp, #0x110
    cae4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cae8:	f947f400 	ldr	x0, [x0, #4072]
    caec:	a90c7bfd 	stp	x29, x30, [sp, #192]
    caf0:	910303fd 	add	x29, sp, #0xc0
    caf4:	a90d53f3 	stp	x19, x20, [sp, #208]
    caf8:	b0000374 	adrp	x20, 79000 <fwp_root_context+0xbb0>
    cafc:	9118c281 	add	x1, x20, #0x630
    cb00:	a90e5bf5 	stp	x21, x22, [sp, #224]
    cb04:	a90f63f7 	stp	x23, x24, [sp, #240]
    cb08:	b953a421 	ldr	w1, [x1, #5028]
    cb0c:	a9106bf9 	stp	x25, x26, [sp, #256]
    cb10:	f9400002 	ldr	x2, [x0]
    cb14:	f9005fe2 	str	x2, [sp, #184]
    cb18:	d2800002 	mov	x2, #0x0                   	// #0
    cb1c:	34000ee1 	cbz	w1, ccf8 <fwp_main_thread+0x218>
    cb20:	9118c280 	add	x0, x20, #0x630
    cb24:	b953a800 	ldr	w0, [x0, #5032]
    cb28:	35000e00 	cbnz	w0, cce8 <fwp_main_thread+0x208>
    cb2c:	91001fe2 	add	x2, sp, #0x7
    cb30:	900000b5 	adrp	x21, 20000 <__data_start>
    cb34:	900000a3 	adrp	x3, 20000 <__data_start>
    cb38:	910142b3 	add	x19, x21, #0x50
    cb3c:	91114063 	add	x3, x3, #0x450
    cb40:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    cb44:	d2a00025 	mov	x5, #0x10000               	// #65536
    cb48:	910023e0 	add	x0, sp, #0x8
    cb4c:	d2800001 	mov	x1, #0x0                   	// #0
    cb50:	f90007e3 	str	x3, [sp, #8]
    cb54:	b90013ff 	str	wzr, [sp, #16]
    cb58:	f9000fe5 	str	x5, [sp, #24]
    cb5c:	a90a1262 	stp	x2, x4, [x19, #160]
    cb60:	97ffd6e8 	bl	2700 <sigaltstack@plt>
    cb64:	35000220 	cbnz	w0, cba8 <fwp_main_thread+0xc8>
    cb68:	4f000400 	movi	v0.4s, #0x0
    cb6c:	9100a3e0 	add	x0, sp, #0x28
    cb70:	f0ffffa1 	adrp	x1, 3000 <ad_raw_record+0x70>
    cb74:	52800082 	mov	w2, #0x4                   	// #4
    cb78:	9102c021 	add	x1, x1, #0xb0
    cb7c:	72a10002 	movk	w2, #0x800, lsl #16
    cb80:	910083f6 	add	x22, sp, #0x20
    cb84:	f90013e1 	str	x1, [sp, #32]
    cb88:	3d802000 	str	q0, [x0, #128]
    cb8c:	b900abe2 	str	w2, [sp, #168]
    cb90:	ad000000 	stp	q0, q0, [x0]
    cb94:	ad010000 	stp	q0, q0, [x0, #32]
    cb98:	ad020000 	stp	q0, q0, [x0, #64]
    cb9c:	ad030000 	stp	q0, q0, [x0, #96]
    cba0:	97ffd730 	bl	2860 <sigemptyset@plt>
    cba4:	34000080 	cbz	w0, cbb4 <fwp_main_thread+0xd4>
    cba8:	b0000000 	adrp	x0, d000 <fwp_main_thread+0x520>
    cbac:	913e0000 	add	x0, x0, #0xf80
    cbb0:	97ffdde1 	bl	4334 <fwp_trap>
    cbb4:	aa1603e1 	mov	x1, x22
    cbb8:	d2800002 	mov	x2, #0x0                   	// #0
    cbbc:	52800160 	mov	w0, #0xb                   	// #11
    cbc0:	97ffd740 	bl	28c0 <sigaction@plt>
    cbc4:	35ffff20 	cbnz	w0, cba8 <fwp_main_thread+0xc8>
    cbc8:	aa1603e1 	mov	x1, x22
    cbcc:	d2800002 	mov	x2, #0x0                   	// #0
    cbd0:	528000e0 	mov	w0, #0x7                   	// #7
    cbd4:	97ffd73b 	bl	28c0 <sigaction@plt>
    cbd8:	35fffe80 	cbnz	w0, cba8 <fwp_main_thread+0xc8>
    cbdc:	9118c281 	add	x1, x20, #0x630
    cbe0:	52800036 	mov	w22, #0x1                   	// #1
    cbe4:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    cbe8:	910ec000 	add	x0, x0, #0x3b0
    cbec:	b9013276 	str	w22, [x19, #304]
    cbf0:	fd4a1020 	ldr	d0, [x1, #5152]
    cbf4:	7e61d800 	ucvtf	d0, d0
    cbf8:	fd00a660 	str	d0, [x19, #328]
    cbfc:	940002d9 	bl	d760 <atexit>
    cc00:	350022a0 	cbnz	w0, d054 <fwp_main_thread+0x574>
    cc04:	b943ca60 	ldr	w0, [x19, #968]
    cc08:	34001c40 	cbz	w0, cf90 <fwp_main_thread+0x4b0>
    cc0c:	910142ba 	add	x26, x21, #0x50
    cc10:	f9404f56 	ldr	x22, [x26, #152]
    cc14:	b4000796 	cbz	x22, cd04 <fwp_main_thread+0x224>
    cc18:	910102d7 	add	x23, x22, #0x40
    cc1c:	39414ad9 	ldrb	w25, [x22, #82]
    cc20:	52800038 	mov	w24, #0x1                   	// #1
    cc24:	39014ad8 	strb	w24, [x22, #82]
    cc28:	f94016c0 	ldr	x0, [x22, #40]
    cc2c:	b40006a0 	cbz	x0, cd00 <fwp_main_thread+0x220>
    cc30:	f94032c1 	ldr	x1, [x22, #96]
    cc34:	394146c0 	ldrb	w0, [x22, #81]
    cc38:	b4001c61 	cbz	x1, cfc4 <fwp_main_thread+0x4e4>
    cc3c:	36001b20 	tbz	w0, #0, cfa0 <fwp_main_thread+0x4c0>
    cc40:	f9404f53 	ldr	x19, [x26, #152]
    cc44:	f94022c0 	ldr	x0, [x22, #64]
    cc48:	39414a61 	ldrb	w1, [x19, #82]
    cc4c:	37001e81 	tbnz	w1, #0, d01c <fwp_main_thread+0x53c>
    cc50:	f9403261 	ldr	x1, [x19, #96]
    cc54:	a911fe77 	stp	x23, xzr, [x19, #280]
    cc58:	f9009660 	str	x0, [x19, #296]
    cc5c:	b4000040 	cbz	x0, cc64 <fwp_main_thread+0x184>
    cc60:	f9009013 	str	x19, [x0, #288]
    cc64:	f90022d3 	str	x19, [x22, #64]
    cc68:	b4000101 	cbz	x1, cc88 <fwp_main_thread+0x1a8>
    cc6c:	f9409740 	ldr	x0, [x26, #296]
    cc70:	39015678 	strb	w24, [x19, #85]
    cc74:	f9003661 	str	x1, [x19, #104]
    cc78:	a910827f 	stp	xzr, x0, [x19, #264]
    cc7c:	b4000040 	cbz	x0, cc84 <fwp_main_thread+0x1a4>
    cc80:	f9008413 	str	x19, [x0, #264]
    cc84:	f9009753 	str	x19, [x26, #296]
    cc88:	39015a7f 	strb	wzr, [x19, #86]
    cc8c:	97ffe861 	bl	6e10 <fwp_block>
    cc90:	f9408e62 	ldr	x2, [x19, #280]
    cc94:	b4000142 	cbz	x2, ccbc <fwp_main_thread+0x1dc>
    cc98:	a9520261 	ldp	x1, x0, [x19, #288]
    cc9c:	b4001cc1 	cbz	x1, d034 <fwp_main_thread+0x554>
    cca0:	f9009420 	str	x0, [x1, #296]
    cca4:	f9409660 	ldr	x0, [x19, #296]
    cca8:	b4000040 	cbz	x0, ccb0 <fwp_main_thread+0x1d0>
    ccac:	f9009001 	str	x1, [x0, #288]
    ccb0:	91080260 	add	x0, x19, #0x200
    ccb4:	f900967f 	str	xzr, [x19, #296]
    ccb8:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    ccbc:	39415660 	ldrb	w0, [x19, #85]
    ccc0:	3607fb40 	tbz	w0, #0, cc28 <fwp_main_thread+0x148>
    ccc4:	a9508261 	ldp	x1, x0, [x19, #264]
    ccc8:	b4001ba1 	cbz	x1, d03c <fwp_main_thread+0x55c>
    cccc:	f9008820 	str	x0, [x1, #272]
    ccd0:	b4000040 	cbz	x0, ccd8 <fwp_main_thread+0x1f8>
    ccd4:	f9008401 	str	x1, [x0, #264]
    ccd8:	91080260 	add	x0, x19, #0x200
    ccdc:	3901567f 	strb	wzr, [x19, #85]
    cce0:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    cce4:	17ffffd1 	b	cc28 <fwp_main_thread+0x148>
    cce8:	f0ffffa0 	adrp	x0, 3000 <ad_raw_record+0x70>
    ccec:	91301000 	add	x0, x0, #0xc04
    ccf0:	9400029c 	bl	d760 <atexit>
    ccf4:	17ffff8e 	b	cb2c <fwp_main_thread+0x4c>
    ccf8:	97ffdc1e 	bl	3d70 <fwp_heap_init>
    ccfc:	17ffff89 	b	cb20 <fwp_main_thread+0x40>
    cd00:	39014ad9 	strb	w25, [x22, #82]
    cd04:	910142b3 	add	x19, x21, #0x50
    cd08:	f941d660 	ldr	x0, [x19, #936]
    cd0c:	b5000180 	cbnz	x0, cd3c <fwp_main_thread+0x25c>
    cd10:	f941de60 	ldr	x0, [x19, #952]
    cd14:	b5000140 	cbnz	x0, cd3c <fwp_main_thread+0x25c>
    cd18:	f941d260 	ldr	x0, [x19, #928]
    cd1c:	97ffde41 	bl	4620 <fwp_mem_free>
    cd20:	f901d27f 	str	xzr, [x19, #928]
    cd24:	f9404e60 	ldr	x0, [x19, #152]
    cd28:	f901da7f 	str	xzr, [x19, #944]
    cd2c:	b40000c0 	cbz	x0, cd44 <fwp_main_thread+0x264>
    cd30:	f900541f 	str	xzr, [x0, #168]
    cd34:	f9005c1f 	str	xzr, [x0, #184]
    cd38:	14000003 	b	cd44 <fwp_main_thread+0x264>
    cd3c:	910142a0 	add	x0, x21, #0x50
    cd40:	f9404c00 	ldr	x0, [x0, #152]
    cd44:	910142a1 	add	x1, x21, #0x50
    cd48:	f941f026 	ldr	x6, [x1, #992]
    cd4c:	b903d83f 	str	wzr, [x1, #984]
    cd50:	eb0000df 	cmp	x6, x0
    cd54:	54001861 	b.ne	d060 <fwp_main_thread+0x580>  // b.any
    cd58:	b40003a0 	cbz	x0, cdcc <fwp_main_thread+0x2ec>
    cd5c:	f941c025 	ldr	x5, [x1, #896]
    cd60:	52800021 	mov	w1, #0x1                   	// #1
    cd64:	39014801 	strb	w1, [x0, #82]
    cd68:	b4000325 	cbz	x5, cdcc <fwp_main_thread+0x2ec>
    cd6c:	d503201f 	nop
    cd70:	394140a0 	ldrb	w0, [x5, #80]
    cd74:	37000060 	tbnz	w0, #0, cd80 <fwp_main_thread+0x2a0>
    cd78:	aa0503e0 	mov	x0, x5
    cd7c:	97ffda5d 	bl	36f0 <fwp_cancel_tree.part.0>
    cd80:	f9409ca5 	ldr	x5, [x5, #312]
    cd84:	b5ffff65 	cbnz	x5, cd70 <fwp_main_thread+0x290>
    cd88:	910142b3 	add	x19, x21, #0x50
    cd8c:	52800036 	mov	w22, #0x1                   	// #1
    cd90:	f94028c0 	ldr	x0, [x6, #80]
    cd94:	f2001c1f 	tst	x0, #0xff000000ff
    cd98:	540000e1 	b.ne	cdb4 <fwp_main_thread+0x2d4>  // b.any
    cd9c:	f9406260 	ldr	x0, [x19, #192]
    cda0:	390150d6 	strb	w22, [x6, #84]
    cda4:	f90080df 	str	xzr, [x6, #256]
    cda8:	b4001360 	cbz	x0, d014 <fwp_main_thread+0x534>
    cdac:	f9008006 	str	x6, [x0, #256]
    cdb0:	f9006266 	str	x6, [x19, #192]
    cdb4:	97ffe817 	bl	6e10 <fwp_block>
    cdb8:	97ffe79e 	bl	6c30 <fwp_free_zombie>
    cdbc:	f941c260 	ldr	x0, [x19, #896]
    cdc0:	b4000060 	cbz	x0, cdcc <fwp_main_thread+0x2ec>
    cdc4:	f941f266 	ldr	x6, [x19, #992]
    cdc8:	17fffff2 	b	cd90 <fwp_main_thread+0x2b0>
    cdcc:	910142b6 	add	x22, x21, #0x50
    cdd0:	97ffe798 	bl	6c30 <fwp_free_zombie>
    cdd4:	f94066c0 	ldr	x0, [x22, #200]
    cdd8:	b5001440 	cbnz	x0, d060 <fwp_main_thread+0x580>
    cddc:	f94096c0 	ldr	x0, [x22, #296]
    cde0:	b5001400 	cbnz	x0, d060 <fwp_main_thread+0x580>
    cde4:	b94172d3 	ldr	w19, [x22, #368]
    cde8:	340001f3 	cbz	w19, ce24 <fwp_main_thread+0x344>
    cdec:	93407e77 	sxtw	x23, w19
    cdf0:	51000673 	sub	w19, w19, #0x1
    cdf4:	d1000af7 	sub	x23, x23, #0x2
    cdf8:	910602d8 	add	x24, x22, #0x180
    cdfc:	cb3342f7 	sub	x23, x23, w19, uxtw
    ce00:	93407e73 	sxtw	x19, w19
    ce04:	d503201f 	nop
    ce08:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    ce0c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    ce10:	b90172d3 	str	w19, [x22, #368]
    ce14:	d1000673 	sub	x19, x19, #0x1
    ce18:	97ffd6ea 	bl	29c0 <munmap@plt>
    ce1c:	eb1302ff 	cmp	x23, x19
    ce20:	54ffff41 	b.ne	ce08 <fwp_main_thread+0x328>  // b.any
    ce24:	900000b3 	adrp	x19, 20000 <__data_start>
    ce28:	91004260 	add	x0, x19, #0x10
    ce2c:	b9402800 	ldr	w0, [x0, #40]
    ce30:	36f80ac0 	tbz	w0, #31, cf88 <fwp_main_thread+0x4a8>
    ce34:	910142b6 	add	x22, x21, #0x50
    ce38:	91004273 	add	x19, x19, #0x10
    ce3c:	12800001 	mov	w1, #0xffffffff            	// #-1
    ce40:	f941fac0 	ldr	x0, [x22, #1008]
    ce44:	b9002a61 	str	w1, [x19, #40]
    ce48:	f941f6c1 	ldr	x1, [x22, #1000]
    ce4c:	b40001e0 	cbz	x0, ce88 <fwp_main_thread+0x3a8>
    ce50:	d2800013 	mov	x19, #0x0                   	// #0
    ce54:	d503201f 	nop
    ce58:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    ce5c:	b40000e0 	cbz	x0, ce78 <fwp_main_thread+0x398>
    ce60:	f9400001 	ldr	x1, [x0]
    ce64:	b5000fe1 	cbnz	x1, d060 <fwp_main_thread+0x580>
    ce68:	f9400401 	ldr	x1, [x0, #8]
    ce6c:	b5000fa1 	cbnz	x1, d060 <fwp_main_thread+0x580>
    ce70:	97ffddec 	bl	4620 <fwp_mem_free>
    ce74:	f941f6c1 	ldr	x1, [x22, #1000]
    ce78:	91000673 	add	x19, x19, #0x1
    ce7c:	f941fac0 	ldr	x0, [x22, #1008]
    ce80:	eb00027f 	cmp	x19, x0
    ce84:	54fffea3 	b.cc	ce58 <fwp_main_thread+0x378>  // b.lo, b.ul, b.last
    ce88:	aa0103e0 	mov	x0, x1
    ce8c:	97ffdde5 	bl	4620 <fwp_mem_free>
    ce90:	910142a0 	add	x0, x21, #0x50
    ce94:	f941f013 	ldr	x19, [x0, #992]
    ce98:	f901f41f 	str	xzr, [x0, #1000]
    ce9c:	f901f81f 	str	xzr, [x0, #1008]
    cea0:	b40001f3 	cbz	x19, cedc <fwp_main_thread+0x3fc>
    cea4:	f9401661 	ldr	x1, [x19, #40]
    cea8:	b5000dc1 	cbnz	x1, d060 <fwp_main_thread+0x580>
    ceac:	f9405661 	ldr	x1, [x19, #168]
    ceb0:	b5000d81 	cbnz	x1, d060 <fwp_main_thread+0x580>
    ceb4:	f941d401 	ldr	x1, [x0, #936]
    ceb8:	b5000d41 	cbnz	x1, d060 <fwp_main_thread+0x580>
    cebc:	f941dc00 	ldr	x0, [x0, #952]
    cec0:	b5000d00 	cbnz	x0, d060 <fwp_main_thread+0x580>
    cec4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    cec8:	90000360 	adrp	x0, 78000 <ad_raw_blocks+0x17bb0>
    cecc:	91114000 	add	x0, x0, #0x450
    ced0:	97ffd668 	bl	2870 <memset@plt>
    ced4:	aa1303e0 	mov	x0, x19
    ced8:	97ffddd2 	bl	4620 <fwp_mem_free>
    cedc:	910142a6 	add	x6, x21, #0x50
    cee0:	9118c294 	add	x20, x20, #0x630
    cee4:	3dc016a1 	ldr	q1, [x21, #80]
    cee8:	52800041 	mov	w1, #0x2                   	// #2
    ceec:	3dc004c2 	ldr	q2, [x6, #16]
    cef0:	b0000002 	adrp	x2, d000 <fwp_main_thread+0x520>
    cef4:	fd4a1280 	ldr	d0, [x20, #5152]
    cef8:	913f2042 	add	x2, x2, #0xfc8
    cefc:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    cf00:	fd40a4c1 	ldr	d1, [x6, #328]
    cf04:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cf08:	f947e800 	ldr	x0, [x0, #4048]
    cf0c:	7e61d800 	ucvtf	d0, d0
    cf10:	a95390c3 	ldp	x3, x4, [x6, #312]
    cf14:	f9004cdf 	str	xzr, [x6, #152]
    cf18:	f9400000 	ldr	x0, [x0]
    cf1c:	1e613801 	fsub	d1, d0, d1
    cf20:	f940acc5 	ldr	x5, [x6, #344]
    cf24:	b90130df 	str	wzr, [x6, #304]
    cf28:	5ef1b842 	addp	d2, v2.2d
    cf2c:	fd40a8c0 	ldr	d0, [x6, #336]
    cf30:	f901f0df 	str	xzr, [x6, #992]
    cf34:	fd0058c2 	str	d2, [x6, #176]
    cf38:	97ffd676 	bl	2910 <__fprintf_chk@plt>
    cf3c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cf40:	f947ec00 	ldr	x0, [x0, #4056]
    cf44:	f9400000 	ldr	x0, [x0]
    cf48:	97ffd6a2 	bl	29d0 <fflush@plt>
    cf4c:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc90>
    cf50:	f947f400 	ldr	x0, [x0, #4072]
    cf54:	f9405fe2 	ldr	x2, [sp, #184]
    cf58:	f9400001 	ldr	x1, [x0]
    cf5c:	eb010042 	subs	x2, x2, x1
    cf60:	d2800001 	mov	x1, #0x0                   	// #0
    cf64:	54000761 	b.ne	d050 <fwp_main_thread+0x570>  // b.any
    cf68:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cf6c:	d2800000 	mov	x0, #0x0                   	// #0
    cf70:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cf74:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cf78:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cf7c:	a9506bf9 	ldp	x25, x26, [sp, #256]
    cf80:	910443ff 	add	sp, sp, #0x110
    cf84:	d65f03c0 	ret
    cf88:	97ffd64a 	bl	28b0 <close@plt>
    cf8c:	17ffffaa 	b	ce34 <fwp_main_thread+0x354>
    cf90:	97fff529 	bl	a434 <f0>
    cf94:	b903ca76 	str	w22, [x19, #968]
    cf98:	f901ea60 	str	x0, [x19, #976]
    cf9c:	17ffff1c 	b	cc0c <fwp_main_thread+0x12c>
    cfa0:	97ffdf04 	bl	4bb0 <fwp_now_ns>
    cfa4:	f94032c1 	ldr	x1, [x22, #96]
    cfa8:	eb01001f 	cmp	x0, x1
    cfac:	540000ab 	b.lt	cfc0 <fwp_main_thread+0x4e0>  // b.tstop
    cfb0:	394142c0 	ldrb	w0, [x22, #80]
    cfb4:	37000060 	tbnz	w0, #0, cfc0 <fwp_main_thread+0x4e0>
    cfb8:	aa1603e0 	mov	x0, x22
    cfbc:	97ffd9cd 	bl	36f0 <fwp_cancel_tree.part.0>
    cfc0:	394146c0 	ldrb	w0, [x22, #81]
    cfc4:	f9404f53 	ldr	x19, [x26, #152]
    cfc8:	39414a62 	ldrb	w2, [x19, #82]
    cfcc:	3707e3a0 	tbnz	w0, #0, cc40 <fwp_main_thread+0x160>
    cfd0:	f94032c1 	ldr	x1, [x22, #96]
    cfd4:	370001c2 	tbnz	w2, #0, d00c <fwp_main_thread+0x52c>
    cfd8:	f9403260 	ldr	x0, [x19, #96]
    cfdc:	b4000180 	cbz	x0, d00c <fwp_main_thread+0x52c>
    cfe0:	b4000061 	cbz	x1, cfec <fwp_main_thread+0x50c>
    cfe4:	eb01001f 	cmp	x0, x1
    cfe8:	9a81d000 	csel	x0, x0, x1, le
    cfec:	f94022c1 	ldr	x1, [x22, #64]
    cff0:	a911fe77 	stp	x23, xzr, [x19, #280]
    cff4:	f9009661 	str	x1, [x19, #296]
    cff8:	b4000261 	cbz	x1, d044 <fwp_main_thread+0x564>
    cffc:	f9009033 	str	x19, [x1, #288]
    d000:	aa0003e1 	mov	x1, x0
    d004:	f90022d3 	str	x19, [x22, #64]
    d008:	17ffff19 	b	cc6c <fwp_main_thread+0x18c>
    d00c:	f94022c0 	ldr	x0, [x22, #64]
    d010:	17ffff11 	b	cc54 <fwp_main_thread+0x174>
    d014:	f9006666 	str	x6, [x19, #200]
    d018:	17ffff66 	b	cdb0 <fwp_main_thread+0x2d0>
    d01c:	a911fe77 	stp	x23, xzr, [x19, #280]
    d020:	f9009660 	str	x0, [x19, #296]
    d024:	b4000040 	cbz	x0, d02c <fwp_main_thread+0x54c>
    d028:	f9009013 	str	x19, [x0, #288]
    d02c:	f90022d3 	str	x19, [x22, #64]
    d030:	17ffff16 	b	cc88 <fwp_main_thread+0x1a8>
    d034:	f9000040 	str	x0, [x2]
    d038:	17ffff1c 	b	cca8 <fwp_main_thread+0x1c8>
    d03c:	f9009740 	str	x0, [x26, #296]
    d040:	17ffff24 	b	ccd0 <fwp_main_thread+0x1f0>
    d044:	aa0003e1 	mov	x1, x0
    d048:	f90022d3 	str	x19, [x22, #64]
    d04c:	17ffff08 	b	cc6c <fwp_main_thread+0x18c>
    d050:	97ffd614 	bl	28a0 <__stack_chk_fail@plt>
    d054:	90000000 	adrp	x0, d000 <fwp_main_thread+0x520>
    d058:	913ea000 	add	x0, x0, #0xfa8
    d05c:	97ffd8c9 	bl	3380 <ad_raw_fail>
    d060:	97ffd624 	bl	28f0 <abort@plt>
    d064:	d503201f 	nop
    d068:	d503201f 	nop
    d06c:	d503201f 	nop

000000000000d070 <__divti3>:
    d070:	d503245f 	bti	c
    d074:	d2800004 	mov	x4, #0x0                   	// #0
    d078:	b7f80721 	tbnz	x1, #63, d15c <__divti3+0xec>
    d07c:	b6f80083 	tbz	x3, #63, d08c <__divti3+0x1c>
    d080:	eb0203e2 	negs	x2, x2
    d084:	aa2403e4 	mvn	x4, x4
    d088:	da0303e3 	ngc	x3, x3
    d08c:	aa0203e6 	mov	x6, x2
    d090:	aa0003e7 	mov	x7, x0
    d094:	aa0103e5 	mov	x5, x1
    d098:	b5000583 	cbnz	x3, d148 <__divti3+0xd8>
    d09c:	eb01005f 	cmp	x2, x1
    d0a0:	54000e69 	b.ls	d26c <__divti3+0x1fc>  // b.plast
    d0a4:	dac01040 	clz	x0, x2
    d0a8:	b40000e0 	cbz	x0, d0c4 <__divti3+0x54>
    d0ac:	4b0003e1 	neg	w1, w0
    d0b0:	9ac020a5 	lsl	x5, x5, x0
    d0b4:	9ac02046 	lsl	x6, x2, x0
    d0b8:	9ac124e1 	lsr	x1, x7, x1
    d0bc:	aa050025 	orr	x5, x1, x5
    d0c0:	9ac020e7 	lsl	x7, x7, x0
    d0c4:	d360fcc8 	lsr	x8, x6, #32
    d0c8:	92407cc2 	and	x2, x6, #0xffffffff
    d0cc:	9ac808a3 	udiv	x3, x5, x8
    d0d0:	9b089465 	msub	x5, x3, x8, x5
    d0d4:	aa0303e0 	mov	x0, x3
    d0d8:	9b037c41 	mul	x1, x2, x3
    d0dc:	93c780a5 	extr	x5, x5, x7, #32
    d0e0:	eb05003f 	cmp	x1, x5
    d0e4:	540000a9 	b.ls	d0f8 <__divti3+0x88>  // b.plast
    d0e8:	ab0500c5 	adds	x5, x6, x5
    d0ec:	d1000460 	sub	x0, x3, #0x1
    d0f0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    d0f4:	540015a8 	b.hi	d3a8 <__divti3+0x338>  // b.pmore
    d0f8:	cb0100a5 	sub	x5, x5, x1
    d0fc:	9ac808a3 	udiv	x3, x5, x8
    d100:	9b089465 	msub	x5, x3, x8, x5
    d104:	aa0303e1 	mov	x1, x3
    d108:	9b037c42 	mul	x2, x2, x3
    d10c:	aa0703e3 	mov	x3, x7
    d110:	b3607ca3 	bfi	x3, x5, #32, #32
    d114:	eb03005f 	cmp	x2, x3
    d118:	540000c9 	b.ls	d130 <__divti3+0xc0>  // b.plast
    d11c:	ab0300c3 	adds	x3, x6, x3
    d120:	d1000425 	sub	x5, x1, #0x1
    d124:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d128:	d1000821 	sub	x1, x1, #0x2
    d12c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    d130:	aa008020 	orr	x0, x1, x0, lsl #32
    d134:	d2800001 	mov	x1, #0x0                   	// #0
    d138:	b4000064 	cbz	x4, d144 <__divti3+0xd4>
    d13c:	eb0003e0 	negs	x0, x0
    d140:	da0103e1 	ngc	x1, x1
    d144:	d65f03c0 	ret
    d148:	eb01007f 	cmp	x3, x1
    d14c:	54000109 	b.ls	d16c <__divti3+0xfc>  // b.plast
    d150:	d2800001 	mov	x1, #0x0                   	// #0
    d154:	d2800000 	mov	x0, #0x0                   	// #0
    d158:	17fffff8 	b	d138 <__divti3+0xc8>
    d15c:	eb0003e0 	negs	x0, x0
    d160:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d164:	da0103e1 	ngc	x1, x1
    d168:	17ffffc5 	b	d07c <__divti3+0xc>
    d16c:	dac01067 	clz	x7, x3
    d170:	b40010e7 	cbz	x7, d38c <__divti3+0x31c>
    d174:	d2800805 	mov	x5, #0x40                  	// #64
    d178:	cb0700a5 	sub	x5, x5, x7
    d17c:	9ac72063 	lsl	x3, x3, x7
    d180:	9ac52448 	lsr	x8, x2, x5
    d184:	aa030108 	orr	x8, x8, x3
    d188:	9ac52426 	lsr	x6, x1, x5
    d18c:	92407d0a 	and	x10, x8, #0xffffffff
    d190:	d360fd09 	lsr	x9, x8, #32
    d194:	9ac52403 	lsr	x3, x0, x5
    d198:	9ac72021 	lsl	x1, x1, x7
    d19c:	aa010063 	orr	x3, x3, x1
    d1a0:	9ac72042 	lsl	x2, x2, x7
    d1a4:	9ac908cb 	udiv	x11, x6, x9
    d1a8:	9b099965 	msub	x5, x11, x9, x6
    d1ac:	aa0b03e1 	mov	x1, x11
    d1b0:	9b0b7d46 	mul	x6, x10, x11
    d1b4:	93c380a5 	extr	x5, x5, x3, #32
    d1b8:	eb0500df 	cmp	x6, x5
    d1bc:	540000a9 	b.ls	d1d0 <__divti3+0x160>  // b.plast
    d1c0:	ab050105 	adds	x5, x8, x5
    d1c4:	d1000561 	sub	x1, x11, #0x1
    d1c8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    d1cc:	54000f48 	b.hi	d3b4 <__divti3+0x344>  // b.pmore
    d1d0:	cb0600a6 	sub	x6, x5, x6
    d1d4:	9ac908cb 	udiv	x11, x6, x9
    d1d8:	9b099969 	msub	x9, x11, x9, x6
    d1dc:	aa0b03e5 	mov	x5, x11
    d1e0:	9b0b7d4a 	mul	x10, x10, x11
    d1e4:	b3607d23 	bfi	x3, x9, #32, #32
    d1e8:	eb03015f 	cmp	x10, x3
    d1ec:	540000a9 	b.ls	d200 <__divti3+0x190>  // b.plast
    d1f0:	ab030103 	adds	x3, x8, x3
    d1f4:	d1000565 	sub	x5, x11, #0x1
    d1f8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    d1fc:	54000e28 	b.hi	d3c0 <__divti3+0x350>  // b.pmore
    d200:	aa0180a1 	orr	x1, x5, x1, lsl #32
    d204:	92407c48 	and	x8, x2, #0xffffffff
    d208:	2a0503e5 	mov	w5, w5
    d20c:	d360fc42 	lsr	x2, x2, #32
    d210:	d360fc26 	lsr	x6, x1, #32
    d214:	cb0a0063 	sub	x3, x3, x10
    d218:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    d21c:	9b087caa 	mul	x10, x5, x8
    d220:	9b087cc8 	mul	x8, x6, x8
    d224:	9b0220a5 	madd	x5, x5, x2, x8
    d228:	9b027cc6 	mul	x6, x6, x2
    d22c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    d230:	8b0900c5 	add	x5, x6, x9
    d234:	eb02011f 	cmp	x8, x2
    d238:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    d23c:	8b4280c6 	add	x6, x6, x2, lsr #32
    d240:	eb06007f 	cmp	x3, x6
    d244:	540000e3 	b.cc	d260 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    d248:	92407d4a 	and	x10, x10, #0xffffffff
    d24c:	9ac72000 	lsl	x0, x0, x7
    d250:	8b028142 	add	x2, x10, x2, lsl #32
    d254:	eb02001f 	cmp	x0, x2
    d258:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    d25c:	54000a01 	b.ne	d39c <__divti3+0x32c>  // b.any
    d260:	d1000420 	sub	x0, x1, #0x1
    d264:	d2800001 	mov	x1, #0x0                   	// #0
    d268:	17ffffb4 	b	d138 <__divti3+0xc8>
    d26c:	b5000062 	cbnz	x2, d278 <__divti3+0x208>
    d270:	d2800022 	mov	x2, #0x1                   	// #1
    d274:	9ac30846 	udiv	x6, x2, x3
    d278:	dac010c8 	clz	x8, x6
    d27c:	b5000408 	cbnz	x8, d2fc <__divti3+0x28c>
    d280:	d360fcc9 	lsr	x9, x6, #32
    d284:	92407cc5 	and	x5, x6, #0xffffffff
    d288:	cb060023 	sub	x3, x1, x6
    d28c:	d2800021 	mov	x1, #0x1                   	// #1
    d290:	9ac90868 	udiv	x8, x3, x9
    d294:	9b098d03 	msub	x3, x8, x9, x3
    d298:	aa0803e0 	mov	x0, x8
    d29c:	9b057d02 	mul	x2, x8, x5
    d2a0:	93c78063 	extr	x3, x3, x7, #32
    d2a4:	eb03005f 	cmp	x2, x3
    d2a8:	540000a9 	b.ls	d2bc <__divti3+0x24c>  // b.plast
    d2ac:	ab0300c3 	adds	x3, x6, x3
    d2b0:	d1000500 	sub	x0, x8, #0x1
    d2b4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    d2b8:	54000968 	b.hi	d3e4 <__divti3+0x374>  // b.pmore
    d2bc:	cb020063 	sub	x3, x3, x2
    d2c0:	9ac90862 	udiv	x2, x3, x9
    d2c4:	aa0203e8 	mov	x8, x2
    d2c8:	9b098c42 	msub	x2, x2, x9, x3
    d2cc:	aa0703e3 	mov	x3, x7
    d2d0:	9b057d05 	mul	x5, x8, x5
    d2d4:	b3607c43 	bfi	x3, x2, #32, #32
    d2d8:	eb0300bf 	cmp	x5, x3
    d2dc:	540000c9 	b.ls	d2f4 <__divti3+0x284>  // b.plast
    d2e0:	ab0300c2 	adds	x2, x6, x3
    d2e4:	d1000503 	sub	x3, x8, #0x1
    d2e8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    d2ec:	d1000908 	sub	x8, x8, #0x2
    d2f0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    d2f4:	aa008100 	orr	x0, x8, x0, lsl #32
    d2f8:	17ffff90 	b	d138 <__divti3+0xc8>
    d2fc:	9ac820c6 	lsl	x6, x6, x8
    d300:	d2800803 	mov	x3, #0x40                  	// #64
    d304:	cb080063 	sub	x3, x3, x8
    d308:	d360fcc9 	lsr	x9, x6, #32
    d30c:	9ac82027 	lsl	x7, x1, x8
    d310:	92407cc5 	and	x5, x6, #0xffffffff
    d314:	9ac32422 	lsr	x2, x1, x3
    d318:	9ac32403 	lsr	x3, x0, x3
    d31c:	aa070063 	orr	x3, x3, x7
    d320:	9ac9084a 	udiv	x10, x2, x9
    d324:	9ac82007 	lsl	x7, x0, x8
    d328:	9b098940 	msub	x0, x10, x9, x2
    d32c:	aa0a03e1 	mov	x1, x10
    d330:	9b0a7ca2 	mul	x2, x5, x10
    d334:	93c38000 	extr	x0, x0, x3, #32
    d338:	eb00005f 	cmp	x2, x0
    d33c:	540000a9 	b.ls	d350 <__divti3+0x2e0>  // b.plast
    d340:	ab0000c0 	adds	x0, x6, x0
    d344:	d1000541 	sub	x1, x10, #0x1
    d348:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    d34c:	54000468 	b.hi	d3d8 <__divti3+0x368>  // b.pmore
    d350:	cb020000 	sub	x0, x0, x2
    d354:	9ac9080a 	udiv	x10, x0, x9
    d358:	9b098140 	msub	x0, x10, x9, x0
    d35c:	aa0a03e2 	mov	x2, x10
    d360:	9b0a7ca8 	mul	x8, x5, x10
    d364:	b3607c03 	bfi	x3, x0, #32, #32
    d368:	eb03011f 	cmp	x8, x3
    d36c:	540000a9 	b.ls	d380 <__divti3+0x310>  // b.plast
    d370:	ab0300c3 	adds	x3, x6, x3
    d374:	d1000542 	sub	x2, x10, #0x1
    d378:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    d37c:	54000288 	b.hi	d3cc <__divti3+0x35c>  // b.pmore
    d380:	cb080063 	sub	x3, x3, x8
    d384:	aa018041 	orr	x1, x2, x1, lsl #32
    d388:	17ffffc2 	b	d290 <__divti3+0x220>
    d38c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d390:	d2800001 	mov	x1, #0x0                   	// #0
    d394:	9a9f87e0 	cset	x0, ls	// ls = plast
    d398:	17ffff68 	b	d138 <__divti3+0xc8>
    d39c:	aa0103e0 	mov	x0, x1
    d3a0:	d2800001 	mov	x1, #0x0                   	// #0
    d3a4:	17ffff65 	b	d138 <__divti3+0xc8>
    d3a8:	d1000860 	sub	x0, x3, #0x2
    d3ac:	8b0600a5 	add	x5, x5, x6
    d3b0:	17ffff52 	b	d0f8 <__divti3+0x88>
    d3b4:	d1000961 	sub	x1, x11, #0x2
    d3b8:	8b0800a5 	add	x5, x5, x8
    d3bc:	17ffff85 	b	d1d0 <__divti3+0x160>
    d3c0:	d1000965 	sub	x5, x11, #0x2
    d3c4:	8b080063 	add	x3, x3, x8
    d3c8:	17ffff8e 	b	d200 <__divti3+0x190>
    d3cc:	d1000942 	sub	x2, x10, #0x2
    d3d0:	8b060063 	add	x3, x3, x6
    d3d4:	17ffffeb 	b	d380 <__divti3+0x310>
    d3d8:	d1000941 	sub	x1, x10, #0x2
    d3dc:	8b060000 	add	x0, x0, x6
    d3e0:	17ffffdc 	b	d350 <__divti3+0x2e0>
    d3e4:	d1000900 	sub	x0, x8, #0x2
    d3e8:	8b060063 	add	x3, x3, x6
    d3ec:	17ffffb4 	b	d2bc <__divti3+0x24c>

000000000000d3f0 <__modti3>:
    d3f0:	d503245f 	bti	c
    d3f4:	d2800004 	mov	x4, #0x0                   	// #0
    d3f8:	b6f80081 	tbz	x1, #63, d408 <__modti3+0x18>
    d3fc:	eb0003e0 	negs	x0, x0
    d400:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d404:	da0103e1 	ngc	x1, x1
    d408:	f100007f 	cmp	x3, #0x0
    d40c:	5400128b 	b.lt	d65c <__modti3+0x26c>  // b.tstop
    d410:	aa0003e7 	mov	x7, x0
    d414:	aa0103e6 	mov	x6, x1
    d418:	540004e1 	b.ne	d4b4 <__modti3+0xc4>  // b.any
    d41c:	eb02003f 	cmp	x1, x2
    d420:	54000dc2 	b.cs	d5d8 <__modti3+0x1e8>  // b.hs, b.nlast
    d424:	dac01043 	clz	x3, x2
    d428:	aa0303e5 	mov	x5, x3
    d42c:	b40000e3 	cbz	x3, d448 <__modti3+0x58>
    d430:	4b0303e6 	neg	w6, w3
    d434:	9ac32021 	lsl	x1, x1, x3
    d438:	9ac32042 	lsl	x2, x2, x3
    d43c:	9ac62406 	lsr	x6, x0, x6
    d440:	aa0100c6 	orr	x6, x6, x1
    d444:	9ac32007 	lsl	x7, x0, x3
    d448:	d360fc40 	lsr	x0, x2, #32
    d44c:	92407c43 	and	x3, x2, #0xffffffff
    d450:	9ac008c1 	udiv	x1, x6, x0
    d454:	9b009826 	msub	x6, x1, x0, x6
    d458:	9b017c61 	mul	x1, x3, x1
    d45c:	93c780c6 	extr	x6, x6, x7, #32
    d460:	eb06003f 	cmp	x1, x6
    d464:	540000a9 	b.ls	d478 <__modti3+0x88>  // b.plast
    d468:	ab060046 	adds	x6, x2, x6
    d46c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d470:	8b0200c8 	add	x8, x6, x2
    d474:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d478:	cb0100c6 	sub	x6, x6, x1
    d47c:	9ac008c8 	udiv	x8, x6, x0
    d480:	9b009901 	msub	x1, x8, x0, x6
    d484:	aa0703e0 	mov	x0, x7
    d488:	9b087c63 	mul	x3, x3, x8
    d48c:	b3607c20 	bfi	x0, x1, #32, #32
    d490:	eb00007f 	cmp	x3, x0
    d494:	54001088 	b.hi	d6a4 <__modti3+0x2b4>  // b.pmore
    d498:	cb030000 	sub	x0, x0, x3
    d49c:	9ac52400 	lsr	x0, x0, x5
    d4a0:	d2800001 	mov	x1, #0x0                   	// #0
    d4a4:	b4000064 	cbz	x4, d4b0 <__modti3+0xc0>
    d4a8:	eb0003e0 	negs	x0, x0
    d4ac:	da0103e1 	ngc	x1, x1
    d4b0:	d65f03c0 	ret
    d4b4:	dac01066 	clz	x6, x3
    d4b8:	eb03003f 	cmp	x1, x3
    d4bc:	54ffff43 	b.cc	d4a4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d4c0:	93407cc5 	sxtw	x5, w6
    d4c4:	d2800808 	mov	x8, #0x40                  	// #64
    d4c8:	cb050108 	sub	x8, x8, x5
    d4cc:	9ac62063 	lsl	x3, x3, x6
    d4d0:	9ac62025 	lsl	x5, x1, x6
    d4d4:	9ac82447 	lsr	x7, x2, x8
    d4d8:	aa0300e7 	orr	x7, x7, x3
    d4dc:	9ac82423 	lsr	x3, x1, x8
    d4e0:	92407cec 	and	x12, x7, #0xffffffff
    d4e4:	d360fcea 	lsr	x10, x7, #32
    d4e8:	9ac82401 	lsr	x1, x0, x8
    d4ec:	aa050021 	orr	x1, x1, x5
    d4f0:	9ac62042 	lsl	x2, x2, x6
    d4f4:	9ac62000 	lsl	x0, x0, x6
    d4f8:	9aca086b 	udiv	x11, x3, x10
    d4fc:	9b0a8d63 	msub	x3, x11, x10, x3
    d500:	aa0b03e5 	mov	x5, x11
    d504:	9b0b7d89 	mul	x9, x12, x11
    d508:	93c18063 	extr	x3, x3, x1, #32
    d50c:	eb03013f 	cmp	x9, x3
    d510:	540000a9 	b.ls	d524 <__modti3+0x134>  // b.plast
    d514:	ab0300e3 	adds	x3, x7, x3
    d518:	d1000565 	sub	x5, x11, #0x1
    d51c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d520:	54001168 	b.hi	d74c <__modti3+0x35c>  // b.pmore
    d524:	cb090063 	sub	x3, x3, x9
    d528:	9aca086b 	udiv	x11, x3, x10
    d52c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d530:	aa0b03e9 	mov	x9, x11
    d534:	9b0b7d8c 	mul	x12, x12, x11
    d538:	b3607d41 	bfi	x1, x10, #32, #32
    d53c:	eb01019f 	cmp	x12, x1
    d540:	540000a9 	b.ls	d554 <__modti3+0x164>  // b.plast
    d544:	ab0100e1 	adds	x1, x7, x1
    d548:	d1000569 	sub	x9, x11, #0x1
    d54c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d550:	54000f88 	b.hi	d740 <__modti3+0x350>  // b.pmore
    d554:	aa058123 	orr	x3, x9, x5, lsl #32
    d558:	92407c4b 	and	x11, x2, #0xffffffff
    d55c:	2a0903e9 	mov	w9, w9
    d560:	d360fc4a 	lsr	x10, x2, #32
    d564:	d360fc63 	lsr	x3, x3, #32
    d568:	cb0c0021 	sub	x1, x1, x12
    d56c:	aa0a03ec 	mov	x12, x10
    d570:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d574:	9b0b7d25 	mul	x5, x9, x11
    d578:	9b0b7c6b 	mul	x11, x3, x11
    d57c:	9b0a2d29 	madd	x9, x9, x10, x11
    d580:	92407caa 	and	x10, x5, #0xffffffff
    d584:	9b0c7c63 	mul	x3, x3, x12
    d588:	8b458125 	add	x5, x9, x5, lsr #32
    d58c:	8b0d0069 	add	x9, x3, x13
    d590:	eb05017f 	cmp	x11, x5
    d594:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d598:	8b058149 	add	x9, x10, x5, lsl #32
    d59c:	8b458063 	add	x3, x3, x5, lsr #32
    d5a0:	eb03003f 	cmp	x1, x3
    d5a4:	54000063 	b.cc	d5b0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d5a8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d5ac:	54000082 	b.cs	d5bc <__modti3+0x1cc>  // b.hs, b.nlast
    d5b0:	eb020129 	subs	x9, x9, x2
    d5b4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d5b8:	cb070063 	sub	x3, x3, x7
    d5bc:	eb090000 	subs	x0, x0, x9
    d5c0:	da030021 	sbc	x1, x1, x3
    d5c4:	9ac62400 	lsr	x0, x0, x6
    d5c8:	9ac82028 	lsl	x8, x1, x8
    d5cc:	aa000100 	orr	x0, x8, x0
    d5d0:	9ac62421 	lsr	x1, x1, x6
    d5d4:	17ffffb4 	b	d4a4 <__modti3+0xb4>
    d5d8:	b5000062 	cbnz	x2, d5e4 <__modti3+0x1f4>
    d5dc:	d2800023 	mov	x3, #0x1                   	// #1
    d5e0:	9ac20862 	udiv	x2, x3, x2
    d5e4:	dac01048 	clz	x8, x2
    d5e8:	aa0803e5 	mov	x5, x8
    d5ec:	b5000668 	cbnz	x8, d6b8 <__modti3+0x2c8>
    d5f0:	cb020020 	sub	x0, x1, x2
    d5f4:	d360fc49 	lsr	x9, x2, #32
    d5f8:	92407c4a 	and	x10, x2, #0xffffffff
    d5fc:	9ac90801 	udiv	x1, x0, x9
    d600:	9b098020 	msub	x0, x1, x9, x0
    d604:	9b0a7c21 	mul	x1, x1, x10
    d608:	93c78000 	extr	x0, x0, x7, #32
    d60c:	eb00003f 	cmp	x1, x0
    d610:	540000a9 	b.ls	d624 <__modti3+0x234>  // b.plast
    d614:	ab000040 	adds	x0, x2, x0
    d618:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d61c:	8b020003 	add	x3, x0, x2
    d620:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d624:	cb010001 	sub	x1, x0, x1
    d628:	9ac90820 	udiv	x0, x1, x9
    d62c:	9b098403 	msub	x3, x0, x9, x1
    d630:	aa0703e1 	mov	x1, x7
    d634:	9b0a7c00 	mul	x0, x0, x10
    d638:	b3607c61 	bfi	x1, x3, #32, #32
    d63c:	eb01001f 	cmp	x0, x1
    d640:	540000a9 	b.ls	d654 <__modti3+0x264>  // b.plast
    d644:	ab010041 	adds	x1, x2, x1
    d648:	8b020022 	add	x2, x1, x2
    d64c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d650:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d654:	cb000020 	sub	x0, x1, x0
    d658:	17ffff91 	b	d49c <__modti3+0xac>
    d65c:	eb0203e5 	negs	x5, x2
    d660:	aa0003e7 	mov	x7, x0
    d664:	da0303e8 	ngc	x8, x3
    d668:	aa0503e2 	mov	x2, x5
    d66c:	aa0803e3 	mov	x3, x8
    d670:	aa0103e6 	mov	x6, x1
    d674:	b4ffed48 	cbz	x8, d41c <__modti3+0x2c>
    d678:	eb01011f 	cmp	x8, x1
    d67c:	54fff148 	b.hi	d4a4 <__modti3+0xb4>  // b.pmore
    d680:	dac01109 	clz	x9, x8
    d684:	2a0903e6 	mov	w6, w9
    d688:	b5fff1c9 	cbnz	x9, d4c0 <__modti3+0xd0>
    d68c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d690:	54000068 	b.hi	d69c <__modti3+0x2ac>  // b.pmore
    d694:	eb050007 	subs	x7, x0, x5
    d698:	da080021 	sbc	x1, x1, x8
    d69c:	aa0703e0 	mov	x0, x7
    d6a0:	17ffff81 	b	d4a4 <__modti3+0xb4>
    d6a4:	ab000040 	adds	x0, x2, x0
    d6a8:	8b020002 	add	x2, x0, x2
    d6ac:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d6b0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d6b4:	17ffff79 	b	d498 <__modti3+0xa8>
    d6b8:	9ac82042 	lsl	x2, x2, x8
    d6bc:	d2800803 	mov	x3, #0x40                  	// #64
    d6c0:	cb080063 	sub	x3, x3, x8
    d6c4:	d360fc49 	lsr	x9, x2, #32
    d6c8:	9ac82027 	lsl	x7, x1, x8
    d6cc:	92407c4a 	and	x10, x2, #0xffffffff
    d6d0:	9ac32426 	lsr	x6, x1, x3
    d6d4:	9ac32403 	lsr	x3, x0, x3
    d6d8:	aa070063 	orr	x3, x3, x7
    d6dc:	9ac908c1 	udiv	x1, x6, x9
    d6e0:	9ac82007 	lsl	x7, x0, x8
    d6e4:	9b099820 	msub	x0, x1, x9, x6
    d6e8:	9b017d41 	mul	x1, x10, x1
    d6ec:	93c38000 	extr	x0, x0, x3, #32
    d6f0:	eb00003f 	cmp	x1, x0
    d6f4:	540000a9 	b.ls	d708 <__modti3+0x318>  // b.plast
    d6f8:	ab000040 	adds	x0, x2, x0
    d6fc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d700:	8b020006 	add	x6, x0, x2
    d704:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d708:	cb010000 	sub	x0, x0, x1
    d70c:	9ac90801 	udiv	x1, x0, x9
    d710:	9b098026 	msub	x6, x1, x9, x0
    d714:	aa0303e0 	mov	x0, x3
    d718:	9b017d41 	mul	x1, x10, x1
    d71c:	b3607cc0 	bfi	x0, x6, #32, #32
    d720:	eb00003f 	cmp	x1, x0
    d724:	540000a9 	b.ls	d738 <__modti3+0x348>  // b.plast
    d728:	ab000040 	adds	x0, x2, x0
    d72c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d730:	8b020003 	add	x3, x0, x2
    d734:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d738:	cb010000 	sub	x0, x0, x1
    d73c:	17ffffb0 	b	d5fc <__modti3+0x20c>
    d740:	d1000969 	sub	x9, x11, #0x2
    d744:	8b070021 	add	x1, x1, x7
    d748:	17ffff83 	b	d554 <__modti3+0x164>
    d74c:	d1000965 	sub	x5, x11, #0x2
    d750:	8b070063 	add	x3, x3, x7
    d754:	17ffff74 	b	d524 <__modti3+0x134>
    d758:	d503201f 	nop
    d75c:	d503201f 	nop

000000000000d760 <atexit>:
    d760:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d764:	f0000082 	adrp	x2, 20000 <__data_start>
    d768:	d2800001 	mov	x1, #0x0                   	// #0
    d76c:	910003fd 	mov	x29, sp
    d770:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d774:	f9400442 	ldr	x2, [x2, #8]
    d778:	17ffd40a 	b	27a0 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d77c <_fini>:
    d77c:	d503201f 	nop
    d780:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d784:	910003fd 	mov	x29, sp
    d788:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d78c:	d65f03c0 	ret
