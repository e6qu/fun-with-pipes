
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-phases:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002728 <_init>:
    2728:	d503201f 	nop
    272c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2730:	910003fd 	mov	x29, sp
    2734:	940001a0 	bl	2db4 <call_weak_fn>
    2738:	a8c17bfd 	ldp	x29, x30, [sp], #16
    273c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002740 <.plt>:
    2740:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2744:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2748:	f946f611 	ldr	x17, [x16, #3560]
    274c:	9137a210 	add	x16, x16, #0xde8
    2750:	d61f0220 	br	x17
    2754:	d503201f 	nop
    2758:	d503201f 	nop
    275c:	d503201f 	nop

0000000000002760 <memcpy@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f946fa11 	ldr	x17, [x16, #3568]
    2768:	9137c210 	add	x16, x16, #0xdf0
    276c:	d61f0220 	br	x17

0000000000002770 <sigaltstack@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f946fe11 	ldr	x17, [x16, #3576]
    2778:	9137e210 	add	x16, x16, #0xdf8
    277c:	d61f0220 	br	x17

0000000000002780 <memmove@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9470211 	ldr	x17, [x16, #3584]
    2788:	91380210 	add	x16, x16, #0xe00
    278c:	d61f0220 	br	x17

0000000000002790 <_exit@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9470611 	ldr	x17, [x16, #3592]
    2798:	91382210 	add	x16, x16, #0xe08
    279c:	d61f0220 	br	x17

00000000000027a0 <strlen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9470a11 	ldr	x17, [x16, #3600]
    27a8:	91384210 	add	x16, x16, #0xe10
    27ac:	d61f0220 	br	x17

00000000000027b0 <__sprintf_chk@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9470e11 	ldr	x17, [x16, #3608]
    27b8:	91386210 	add	x16, x16, #0xe18
    27bc:	d61f0220 	br	x17

00000000000027c0 <exit@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9471211 	ldr	x17, [x16, #3616]
    27c8:	91388210 	add	x16, x16, #0xe20
    27cc:	d61f0220 	br	x17

00000000000027d0 <__libc_start_main@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9471611 	ldr	x17, [x16, #3624]
    27d8:	9138a210 	add	x16, x16, #0xe28
    27dc:	d61f0220 	br	x17

00000000000027e0 <strtoll@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9471a11 	ldr	x17, [x16, #3632]
    27e8:	9138c210 	add	x16, x16, #0xe30
    27ec:	d61f0220 	br	x17

00000000000027f0 <strtod@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9471e11 	ldr	x17, [x16, #3640]
    27f8:	9138e210 	add	x16, x16, #0xe38
    27fc:	d61f0220 	br	x17

0000000000002800 <__cxa_finalize@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9472211 	ldr	x17, [x16, #3648]
    2808:	91390210 	add	x16, x16, #0xe40
    280c:	d61f0220 	br	x17

0000000000002810 <__cxa_atexit@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9472611 	ldr	x17, [x16, #3656]
    2818:	91392210 	add	x16, x16, #0xe48
    281c:	d61f0220 	br	x17

0000000000002820 <pthread_attr_init@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9472a11 	ldr	x17, [x16, #3664]
    2828:	91394210 	add	x16, x16, #0xe50
    282c:	d61f0220 	br	x17

0000000000002830 <fputc@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9472e11 	ldr	x17, [x16, #3672]
    2838:	91396210 	add	x16, x16, #0xe58
    283c:	d61f0220 	br	x17

0000000000002840 <clock_gettime@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9473211 	ldr	x17, [x16, #3680]
    2848:	91398210 	add	x16, x16, #0xe60
    284c:	d61f0220 	br	x17

0000000000002850 <setvbuf@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9473611 	ldr	x17, [x16, #3688]
    2858:	9139a210 	add	x16, x16, #0xe68
    285c:	d61f0220 	br	x17

0000000000002860 <__memcpy_chk@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9473a11 	ldr	x17, [x16, #3696]
    2868:	9139c210 	add	x16, x16, #0xe70
    286c:	d61f0220 	br	x17

0000000000002870 <signal@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9473e11 	ldr	x17, [x16, #3704]
    2878:	9139e210 	add	x16, x16, #0xe78
    287c:	d61f0220 	br	x17

0000000000002880 <__snprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9474211 	ldr	x17, [x16, #3712]
    2888:	913a0210 	add	x16, x16, #0xe80
    288c:	d61f0220 	br	x17

0000000000002890 <fclose@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9474611 	ldr	x17, [x16, #3720]
    2898:	913a2210 	add	x16, x16, #0xe88
    289c:	d61f0220 	br	x17

00000000000028a0 <fopen@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9474a11 	ldr	x17, [x16, #3728]
    28a8:	913a4210 	add	x16, x16, #0xe90
    28ac:	d61f0220 	br	x17

00000000000028b0 <malloc@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9474e11 	ldr	x17, [x16, #3736]
    28b8:	913a6210 	add	x16, x16, #0xe98
    28bc:	d61f0220 	br	x17

00000000000028c0 <pthread_attr_destroy@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9475211 	ldr	x17, [x16, #3744]
    28c8:	913a8210 	add	x16, x16, #0xea0
    28cc:	d61f0220 	br	x17

00000000000028d0 <sigemptyset@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9475611 	ldr	x17, [x16, #3752]
    28d8:	913aa210 	add	x16, x16, #0xea8
    28dc:	d61f0220 	br	x17

00000000000028e0 <memset@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9475a11 	ldr	x17, [x16, #3760]
    28e8:	913ac210 	add	x16, x16, #0xeb0
    28ec:	d61f0220 	br	x17

00000000000028f0 <calloc@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9475e11 	ldr	x17, [x16, #3768]
    28f8:	913ae210 	add	x16, x16, #0xeb8
    28fc:	d61f0220 	br	x17

0000000000002900 <realloc@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9476211 	ldr	x17, [x16, #3776]
    2908:	913b0210 	add	x16, x16, #0xec0
    290c:	d61f0220 	br	x17

0000000000002910 <__stack_chk_fail@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9476611 	ldr	x17, [x16, #3784]
    2918:	913b2210 	add	x16, x16, #0xec8
    291c:	d61f0220 	br	x17

0000000000002920 <close@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9476a11 	ldr	x17, [x16, #3792]
    2928:	913b4210 	add	x16, x16, #0xed0
    292c:	d61f0220 	br	x17

0000000000002930 <sigaction@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9476e11 	ldr	x17, [x16, #3800]
    2938:	913b6210 	add	x16, x16, #0xed8
    293c:	d61f0220 	br	x17

0000000000002940 <__gmon_start__@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9477211 	ldr	x17, [x16, #3808]
    2948:	913b8210 	add	x16, x16, #0xee0
    294c:	d61f0220 	br	x17

0000000000002950 <write@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9477611 	ldr	x17, [x16, #3816]
    2958:	913ba210 	add	x16, x16, #0xee8
    295c:	d61f0220 	br	x17

0000000000002960 <abort@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9477a11 	ldr	x17, [x16, #3824]
    2968:	913bc210 	add	x16, x16, #0xef0
    296c:	d61f0220 	br	x17

0000000000002970 <swapcontext@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f9477e11 	ldr	x17, [x16, #3832]
    2978:	913be210 	add	x16, x16, #0xef8
    297c:	d61f0220 	br	x17

0000000000002980 <__fprintf_chk@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f9478211 	ldr	x17, [x16, #3840]
    2988:	913c0210 	add	x16, x16, #0xf00
    298c:	d61f0220 	br	x17

0000000000002990 <strcmp@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f9478611 	ldr	x17, [x16, #3848]
    2998:	913c2210 	add	x16, x16, #0xf08
    299c:	d61f0220 	br	x17

00000000000029a0 <mmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f9478a11 	ldr	x17, [x16, #3856]
    29a8:	913c4210 	add	x16, x16, #0xf10
    29ac:	d61f0220 	br	x17

00000000000029b0 <strtol@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f9478e11 	ldr	x17, [x16, #3864]
    29b8:	913c6210 	add	x16, x16, #0xf18
    29bc:	d61f0220 	br	x17

00000000000029c0 <strtof@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f9479211 	ldr	x17, [x16, #3872]
    29c8:	913c8210 	add	x16, x16, #0xf20
    29cc:	d61f0220 	br	x17

00000000000029d0 <free@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f9479611 	ldr	x17, [x16, #3880]
    29d8:	913ca210 	add	x16, x16, #0xf28
    29dc:	d61f0220 	br	x17

00000000000029e0 <nanosleep@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f9479a11 	ldr	x17, [x16, #3888]
    29e8:	913cc210 	add	x16, x16, #0xf30
    29ec:	d61f0220 	br	x17

00000000000029f0 <strchr@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f9479e11 	ldr	x17, [x16, #3896]
    29f8:	913ce210 	add	x16, x16, #0xf38
    29fc:	d61f0220 	br	x17

0000000000002a00 <strtoull@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947a211 	ldr	x17, [x16, #3904]
    2a08:	913d0210 	add	x16, x16, #0xf40
    2a0c:	d61f0220 	br	x17

0000000000002a10 <fwrite@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947a611 	ldr	x17, [x16, #3912]
    2a18:	913d2210 	add	x16, x16, #0xf48
    2a1c:	d61f0220 	br	x17

0000000000002a20 <pthread_create@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947aa11 	ldr	x17, [x16, #3920]
    2a28:	913d4210 	add	x16, x16, #0xf50
    2a2c:	d61f0220 	br	x17

0000000000002a30 <munmap@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947ae11 	ldr	x17, [x16, #3928]
    2a38:	913d6210 	add	x16, x16, #0xf58
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fflush@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947b211 	ldr	x17, [x16, #3936]
    2a48:	913d8210 	add	x16, x16, #0xf60
    2a4c:	d61f0220 	br	x17

0000000000002a50 <strcpy@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947b611 	ldr	x17, [x16, #3944]
    2a58:	913da210 	add	x16, x16, #0xf68
    2a5c:	d61f0220 	br	x17

0000000000002a60 <sysconf@plt>:
    2a60:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a64:	f947ba11 	ldr	x17, [x16, #3952]
    2a68:	913dc210 	add	x16, x16, #0xf70
    2a6c:	d61f0220 	br	x17

0000000000002a70 <strstr@plt>:
    2a70:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a74:	f947be11 	ldr	x17, [x16, #3960]
    2a78:	913de210 	add	x16, x16, #0xf78
    2a7c:	d61f0220 	br	x17

0000000000002a80 <_Exit@plt>:
    2a80:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a84:	f947c211 	ldr	x17, [x16, #3968]
    2a88:	913e0210 	add	x16, x16, #0xf80
    2a8c:	d61f0220 	br	x17

0000000000002a90 <pthread_join@plt>:
    2a90:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a94:	f947c611 	ldr	x17, [x16, #3976]
    2a98:	913e2210 	add	x16, x16, #0xf88
    2a9c:	d61f0220 	br	x17

0000000000002aa0 <getenv@plt>:
    2aa0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2aa4:	f947ca11 	ldr	x17, [x16, #3984]
    2aa8:	913e4210 	add	x16, x16, #0xf90
    2aac:	d61f0220 	br	x17

0000000000002ab0 <__memmove_chk@plt>:
    2ab0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ab4:	f947ce11 	ldr	x17, [x16, #3992]
    2ab8:	913e6210 	add	x16, x16, #0xf98
    2abc:	d61f0220 	br	x17

0000000000002ac0 <mprotect@plt>:
    2ac0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ac4:	f947d211 	ldr	x17, [x16, #4000]
    2ac8:	913e8210 	add	x16, x16, #0xfa0
    2acc:	d61f0220 	br	x17

0000000000002ad0 <fgets@plt>:
    2ad0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ad4:	f947d611 	ldr	x17, [x16, #4008]
    2ad8:	913ea210 	add	x16, x16, #0xfa8
    2adc:	d61f0220 	br	x17

0000000000002ae0 <pthread_attr_setstacksize@plt>:
    2ae0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2ae4:	f947da11 	ldr	x17, [x16, #4016]
    2ae8:	913ec210 	add	x16, x16, #0xfb0
    2aec:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002b00 <fwp_trap_overflow.constprop.0>:
    2b00:	d10243ff 	sub	sp, sp, #0x90
    2b04:	d2800c03 	mov	x3, #0x60                  	// #96
    2b08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2b0c:	f947f421 	ldr	x1, [x1, #4072]
    2b10:	f0000045 	adrp	x5, d000 <__divti3+0x320>
    2b14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2b18:	9101c3fd 	add	x29, sp, #0x70
    2b1c:	911e00a5 	add	x5, x5, #0x780
    2b20:	f0000044 	adrp	x4, d000 <__divti3+0x320>
    2b24:	f90043f3 	str	x19, [sp, #128]
    2b28:	911e2084 	add	x4, x4, #0x788
    2b2c:	910023f3 	add	x19, sp, #0x8
    2b30:	f9400022 	ldr	x2, [x1]
    2b34:	f90037e2 	str	x2, [sp, #104]
    2b38:	d2800002 	mov	x2, #0x0                   	// #0
    2b3c:	aa0303e1 	mov	x1, x3
    2b40:	52800042 	mov	w2, #0x2                   	// #2
    2b44:	aa1303e0 	mov	x0, x19
    2b48:	97ffff4e 	bl	2880 <__snprintf_chk@plt>
    2b4c:	aa1303e0 	mov	x0, x19
    2b50:	94000590 	bl	4190 <fwp_trap>
    2b54:	d503201f 	nop
    2b58:	d503201f 	nop
    2b5c:	d503201f 	nop

0000000000002b60 <main>:
    2b60:	d10243ff 	sub	sp, sp, #0x90
    2b64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2b68:	f947f400 	ldr	x0, [x0, #4072]
    2b6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2b70:	910183fd 	add	x29, sp, #0x60
    2b74:	a90753f3 	stp	x19, x20, [sp, #112]
    2b78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2b7c:	f947ee94 	ldr	x20, [x20, #4056]
    2b80:	f9400282 	ldr	x2, [x20]
    2b84:	f90043f5 	str	x21, [sp, #128]
    2b88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b8c:	9101c2a1 	add	x1, x21, #0x70
    2b90:	f9400003 	ldr	x3, [x0]
    2b94:	f9002fe3 	str	x3, [sp, #88]
    2b98:	d2800003 	mov	x3, #0x0                   	// #0
    2b9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xea28>
    2ba0:	910da000 	add	x0, x0, #0x368
    2ba4:	f9000422 	str	x2, [x1, #8]
    2ba8:	f9006420 	str	x0, [x1, #200]
    2bac:	94000799 	bl	4a10 <fwp_now_ns>
    2bb0:	f0000040 	adrp	x0, d000 <__divti3+0x320>
    2bb4:	912a6000 	add	x0, x0, #0xa98
    2bb8:	97ffffba 	bl	2aa0 <getenv@plt>
    2bbc:	b4000080 	cbz	x0, 2bcc <main+0x6c>
    2bc0:	39400001 	ldrb	w1, [x0]
    2bc4:	aa0003f3 	mov	x19, x0
    2bc8:	350008c1 	cbnz	w1, 2ce0 <main+0x180>
    2bcc:	910023e1 	add	x1, sp, #0x8
    2bd0:	52800000 	mov	w0, #0x0                   	// #0
    2bd4:	97ffff1b 	bl	2840 <clock_gettime@plt>
    2bd8:	350007e0 	cbnz	w0, 2cd4 <main+0x174>
    2bdc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2be0:	d2994003 	mov	x3, #0xca00                	// #51712
    2be4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2be8:	9b037c01 	mul	x1, x0, x3
    2bec:	9b437c00 	smulh	x0, x0, x3
    2bf0:	ab020021 	adds	x1, x1, x2
    2bf4:	937ffc42 	asr	x2, x2, #63
    2bf8:	9a020000 	adc	x0, x0, x2
    2bfc:	f100003f 	cmp	x1, #0x0
    2c00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2c04:	b5000620 	cbnz	x0, 2cc8 <main+0x168>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2c10:	52800002 	mov	w2, #0x0                   	// #0
    2c14:	d2800001 	mov	x1, #0x0                   	// #0
    2c18:	910063f3 	add	x19, sp, #0x18
    2c1c:	97ffff0d 	bl	2850 <setvbuf@plt>
    2c20:	d2800021 	mov	x1, #0x1                   	// #1
    2c24:	528001a0 	mov	w0, #0xd                   	// #13
    2c28:	97ffff12 	bl	2870 <signal@plt>
    2c2c:	aa1303e0 	mov	x0, x19
    2c30:	97fffefc 	bl	2820 <pthread_attr_init@plt>
    2c34:	350007a0 	cbnz	w0, 2d28 <main+0x1c8>
    2c38:	aa1303e0 	mov	x0, x19
    2c3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2c40:	97ffffa8 	bl	2ae0 <pthread_attr_setstacksize@plt>
    2c44:	35000660 	cbnz	w0, 2d10 <main+0x1b0>
    2c48:	aa1303e1 	mov	x1, x19
    2c4c:	910023e0 	add	x0, sp, #0x8
    2c50:	d0000042 	adrp	x2, c000 <f0+0x1ef0>
    2c54:	d2800003 	mov	x3, #0x0                   	// #0
    2c58:	911e8042 	add	x2, x2, #0x7a0
    2c5c:	97ffff71 	bl	2a20 <pthread_create@plt>
    2c60:	2a0003e1 	mov	w1, w0
    2c64:	aa1303e0 	mov	x0, x19
    2c68:	2a0103f3 	mov	w19, w1
    2c6c:	97ffff15 	bl	28c0 <pthread_attr_destroy@plt>
    2c70:	350006a0 	cbnz	w0, 2d44 <main+0x1e4>
    2c74:	35000613 	cbnz	w19, 2d34 <main+0x1d4>
    2c78:	f94007e0 	ldr	x0, [sp, #8]
    2c7c:	d2800001 	mov	x1, #0x0                   	// #0
    2c80:	97ffff84 	bl	2a90 <pthread_join@plt>
    2c84:	35000600 	cbnz	w0, 2d44 <main+0x1e4>
    2c88:	f9400280 	ldr	x0, [x20]
    2c8c:	9101c2b5 	add	x21, x21, #0x70
    2c90:	97ffff6c 	bl	2a40 <fflush@plt>
    2c94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c98:	f947f421 	ldr	x1, [x1, #4072]
    2c9c:	b9435aa0 	ldr	w0, [x21, #856]
    2ca0:	f9402fe3 	ldr	x3, [sp, #88]
    2ca4:	f9400022 	ldr	x2, [x1]
    2ca8:	eb020063 	subs	x3, x3, x2
    2cac:	d2800002 	mov	x2, #0x0                   	// #0
    2cb0:	54000481 	b.ne	2d40 <main+0x1e0>  // b.any
    2cb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2cb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2cbc:	f94043f5 	ldr	x21, [sp, #128]
    2cc0:	910243ff 	add	sp, sp, #0x90
    2cc4:	d65f03c0 	ret
    2cc8:	f0000040 	adrp	x0, d000 <__divti3+0x320>
    2ccc:	912b2000 	add	x0, x0, #0xac8
    2cd0:	94000530 	bl	4190 <fwp_trap>
    2cd4:	f0000040 	adrp	x0, d000 <__divti3+0x320>
    2cd8:	912aa000 	add	x0, x0, #0xaa8
    2cdc:	9400052d 	bl	4190 <fwp_trap>
    2ce0:	910003e1 	mov	x1, sp
    2ce4:	52800142 	mov	w2, #0xa                   	// #10
    2ce8:	97ffff46 	bl	2a00 <strtoull@plt>
    2cec:	f94003e0 	ldr	x0, [sp]
    2cf0:	39400000 	ldrb	w0, [x0]
    2cf4:	35fff6c0 	cbnz	w0, 2bcc <main+0x6c>
    2cf8:	39400260 	ldrb	w0, [x19]
    2cfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2d00:	5100ac00 	sub	w0, w0, #0x2b
    2d04:	6a01001f 	tst	w0, w1
    2d08:	54fff620 	b.eq	2bcc <main+0x6c>  // b.none
    2d0c:	17ffffbf 	b	2c08 <main+0xa8>
    2d10:	aa1303e0 	mov	x0, x19
    2d14:	97fffeeb 	bl	28c0 <pthread_attr_destroy@plt>
    2d18:	35000160 	cbnz	w0, 2d44 <main+0x1e4>
    2d1c:	f0000040 	adrp	x0, d000 <__divti3+0x320>
    2d20:	912c8000 	add	x0, x0, #0xb20
    2d24:	9400051b 	bl	4190 <fwp_trap>
    2d28:	f0000040 	adrp	x0, d000 <__divti3+0x320>
    2d2c:	912bc000 	add	x0, x0, #0xaf0
    2d30:	94000518 	bl	4190 <fwp_trap>
    2d34:	f0000040 	adrp	x0, d000 <__divti3+0x320>
    2d38:	912d2000 	add	x0, x0, #0xb48
    2d3c:	94000515 	bl	4190 <fwp_trap>
    2d40:	97fffef4 	bl	2910 <__stack_chk_fail@plt>
    2d44:	97ffff07 	bl	2960 <abort@plt>
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop
    2d50:	d503201f 	nop
    2d54:	d503201f 	nop
    2d58:	d503201f 	nop
    2d5c:	d503201f 	nop
    2d60:	d503201f 	nop
    2d64:	d503201f 	nop
    2d68:	d503201f 	nop
    2d6c:	d503201f 	nop
    2d70:	d503201f 	nop
    2d74:	d503201f 	nop
    2d78:	d503201f 	nop
    2d7c:	d503201f 	nop

0000000000002d80 <_start>:
    2d80:	d503201f 	nop
    2d84:	d280001d 	mov	x29, #0x0                   	// #0
    2d88:	d280001e 	mov	x30, #0x0                   	// #0
    2d8c:	aa0003e5 	mov	x5, x0
    2d90:	f94003e1 	ldr	x1, [sp]
    2d94:	910023e2 	add	x2, sp, #0x8
    2d98:	910003e6 	mov	x6, sp
    2d9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2da0:	f947f800 	ldr	x0, [x0, #4080]
    2da4:	d2800003 	mov	x3, #0x0                   	// #0
    2da8:	d2800004 	mov	x4, #0x0                   	// #0
    2dac:	97fffe89 	bl	27d0 <__libc_start_main@plt>
    2db0:	97fffeec 	bl	2960 <abort@plt>

0000000000002db4 <call_weak_fn>:
    2db4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2db8:	f947f000 	ldr	x0, [x0, #4064]
    2dbc:	b4000040 	cbz	x0, 2dc4 <call_weak_fn+0x10>
    2dc0:	17fffee0 	b	2940 <__gmon_start__@plt>
    2dc4:	d65f03c0 	ret
    2dc8:	d503201f 	nop
    2dcc:	d503201f 	nop

0000000000002dd0 <deregister_tm_clones>:
    2dd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dd4:	91016000 	add	x0, x0, #0x58
    2dd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2ddc:	91016021 	add	x1, x1, #0x58
    2de0:	eb00003f 	cmp	x1, x0
    2de4:	540000c0 	b.eq	2dfc <deregister_tm_clones+0x2c>  // b.none
    2de8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2dec:	f947e021 	ldr	x1, [x1, #4032]
    2df0:	b4000061 	cbz	x1, 2dfc <deregister_tm_clones+0x2c>
    2df4:	aa0103f0 	mov	x16, x1
    2df8:	d61f0200 	br	x16
    2dfc:	d65f03c0 	ret

0000000000002e00 <register_tm_clones>:
    2e00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e04:	91016000 	add	x0, x0, #0x58
    2e08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2e0c:	91016021 	add	x1, x1, #0x58
    2e10:	cb000021 	sub	x1, x1, x0
    2e14:	d37ffc22 	lsr	x2, x1, #63
    2e18:	8b810c41 	add	x1, x2, x1, asr #3
    2e1c:	9341fc21 	asr	x1, x1, #1
    2e20:	b40000c1 	cbz	x1, 2e38 <register_tm_clones+0x38>
    2e24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947fc42 	ldr	x2, [x2, #4088]
    2e2c:	b4000062 	cbz	x2, 2e38 <register_tm_clones+0x38>
    2e30:	aa0203f0 	mov	x16, x2
    2e34:	d61f0200 	br	x16
    2e38:	d65f03c0 	ret
    2e3c:	d503201f 	nop

0000000000002e40 <__do_global_dtors_aux>:
    2e40:	d503233f 	paciasp
    2e44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2e48:	910003fd 	mov	x29, sp
    2e4c:	f9000bf3 	str	x19, [sp, #16]
    2e50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2e54:	39418260 	ldrb	w0, [x19, #96]
    2e58:	37000140 	tbnz	w0, #0, 2e80 <__do_global_dtors_aux+0x40>
    2e5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2e60:	f947e400 	ldr	x0, [x0, #4040]
    2e64:	b4000080 	cbz	x0, 2e74 <__do_global_dtors_aux+0x34>
    2e68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2e6c:	f9400400 	ldr	x0, [x0, #8]
    2e70:	97fffe64 	bl	2800 <__cxa_finalize@plt>
    2e74:	97ffffd7 	bl	2dd0 <deregister_tm_clones>
    2e78:	52800020 	mov	w0, #0x1                   	// #1
    2e7c:	39018260 	strb	w0, [x19, #96]
    2e80:	f9400bf3 	ldr	x19, [sp, #16]
    2e84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e88:	d50323bf 	autiasp
    2e8c:	d65f03c0 	ret

0000000000002e90 <frame_dummy>:
    2e90:	d503245f 	bti	c
    2e94:	17ffffdb 	b	2e00 <register_tm_clones>
    2e98:	d503201f 	nop
    2e9c:	d503201f 	nop

0000000000002ea0 <fwp_fmt_u128>:
    2ea0:	d10183ff 	sub	sp, sp, #0x60
    2ea4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2ea8:	f947f421 	ldr	x1, [x1, #4072]
    2eac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2eb0:	910143fd 	add	x29, sp, #0x50
    2eb4:	f9400024 	ldr	x4, [x1]
    2eb8:	f90027e4 	str	x4, [sp, #72]
    2ebc:	d2800004 	mov	x4, #0x0                   	// #0
    2ec0:	aa030041 	orr	x1, x2, x3
    2ec4:	b5000361 	cbnz	x1, 2f30 <fwp_fmt_u128+0x90>
    2ec8:	910023e9 	add	x9, sp, #0x8
    2ecc:	52800601 	mov	w1, #0x30                  	// #48
    2ed0:	5280002d 	mov	w13, #0x1                   	// #1
    2ed4:	390023e1 	strb	w1, [sp, #8]
    2ed8:	93407dad 	sxtw	x13, w13
    2edc:	aa0d03e1 	mov	x1, x13
    2ee0:	8b0d0004 	add	x4, x0, x13
    2ee4:	d503201f 	nop
    2ee8:	8b010123 	add	x3, x9, x1
    2eec:	cb0103e2 	neg	x2, x1
    2ef0:	d1000421 	sub	x1, x1, #0x1
    2ef4:	385ff063 	ldurb	w3, [x3, #-1]
    2ef8:	38226883 	strb	w3, [x4, x2]
    2efc:	35ffff61 	cbnz	w1, 2ee8 <fwp_fmt_u128+0x48>
    2f00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2f04:	f947f421 	ldr	x1, [x1, #4072]
    2f08:	382d681f 	strb	wzr, [x0, x13]
    2f0c:	aa0103e0 	mov	x0, x1
    2f10:	f94027e2 	ldr	x2, [sp, #72]
    2f14:	f9400001 	ldr	x1, [x0]
    2f18:	eb010042 	subs	x2, x2, x1
    2f1c:	d2800001 	mov	x1, #0x0                   	// #0
    2f20:	54000561 	b.ne	2fcc <fwp_fmt_u128+0x12c>  // b.any
    2f24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2f28:	910183ff 	add	sp, sp, #0x60
    2f2c:	d65f03c0 	ret
    2f30:	90000061 	adrp	x1, e000 <_IO_stdin_used+0xc00>
    2f34:	91074021 	add	x1, x1, #0x1d0
    2f38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2f3c:	910023e9 	add	x9, sp, #0x8
    2f40:	d2800027 	mov	x7, #0x1                   	// #1
    2f44:	f29999af 	movk	x15, #0xcccd
    2f48:	a9402826 	ldp	x6, x10, [x1]
    2f4c:	d503201f 	nop
    2f50:	ab030041 	adds	x1, x2, x3
    2f54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2f58:	aa0303eb 	mov	x11, x3
    2f5c:	8b070128 	add	x8, x9, x7
    2f60:	aa0203ee 	mov	x14, x2
    2f64:	aa0703ed 	mov	x13, x7
    2f68:	910004e7 	add	x7, x7, #0x1
    2f6c:	9bcf7c24 	umulh	x4, x1, x15
    2f70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2f74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2f78:	cb040021 	sub	x1, x1, x4
    2f7c:	eb010041 	subs	x1, x2, x1
    2f80:	da1f0063 	sbc	x3, x3, xzr
    2f84:	9bc67c24 	umulh	x4, x1, x6
    2f88:	9b061064 	madd	x4, x3, x6, x4
    2f8c:	9b067c2c 	mul	x12, x1, x6
    2f90:	9b0a1024 	madd	x4, x1, x10, x4
    2f94:	9bc67c25 	umulh	x5, x1, x6
    2f98:	9b061465 	madd	x5, x3, x6, x5
    2f9c:	9b0a1425 	madd	x5, x1, x10, x5
    2fa0:	93cc0484 	extr	x4, x4, x12, #1
    2fa4:	8b040884 	add	x4, x4, x4, lsl #2
    2fa8:	d341fca3 	lsr	x3, x5, #1
    2fac:	cb040444 	sub	x4, x2, x4, lsl #1
    2fb0:	93cc04a2 	extr	x2, x5, x12, #1
    2fb4:	1100c084 	add	w4, w4, #0x30
    2fb8:	381ff104 	sturb	w4, [x8, #-1]
    2fbc:	b5fffcab 	cbnz	x11, 2f50 <fwp_fmt_u128+0xb0>
    2fc0:	f10025df 	cmp	x14, #0x9
    2fc4:	54fffc68 	b.hi	2f50 <fwp_fmt_u128+0xb0>  // b.pmore
    2fc8:	17ffffc4 	b	2ed8 <fwp_fmt_u128+0x38>
    2fcc:	97fffe51 	bl	2910 <__stack_chk_fail@plt>

0000000000002fd0 <fwp_range_release>:
    2fd0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2fd4:	910003fd 	mov	x29, sp
    2fd8:	f9400801 	ldr	x1, [x0, #16]
    2fdc:	f9000bf3 	str	x19, [sp, #16]
    2fe0:	aa0003f3 	mov	x19, x0
    2fe4:	b4000061 	cbz	x1, 2ff0 <fwp_range_release+0x20>
    2fe8:	f9400400 	ldr	x0, [x0, #8]
    2fec:	d63f0020 	blr	x1
    2ff0:	f9400260 	ldr	x0, [x19]
    2ff4:	f9400e61 	ldr	x1, [x19, #24]
    2ff8:	f9400bf3 	ldr	x19, [sp, #16]
    2ffc:	aa0103f0 	mov	x16, x1
    3000:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3004:	d61f0200 	br	x16
    3008:	d503201f 	nop
    300c:	d503201f 	nop

0000000000003010 <fwp_tape_unlink_scope>:
    3010:	f9402803 	ldr	x3, [x0, #80]
    3014:	b4000223 	cbz	x3, 3058 <fwp_tape_unlink_scope+0x48>
    3018:	294b0402 	ldp	w2, w1, [x0, #88]
    301c:	37f80202 	tbnz	w2, #31, 305c <fwp_tape_unlink_scope+0x4c>
    3020:	b00000e4 	adrp	x4, 20000 <__data_start>
    3024:	52800d03 	mov	w3, #0x68                  	// #104
    3028:	f9403884 	ldr	x4, [x4, #112]
    302c:	9b231043 	smaddl	x3, w2, w3, x4
    3030:	b9005c61 	str	w1, [x3, #92]
    3034:	37f800c1 	tbnz	w1, #31, 304c <fwp_tape_unlink_scope+0x3c>
    3038:	b00000e3 	adrp	x3, 20000 <__data_start>
    303c:	52800d04 	mov	w4, #0x68                  	// #104
    3040:	f9403863 	ldr	x3, [x3, #112]
    3044:	9b240c21 	smaddl	x1, w1, w4, x3
    3048:	b9005822 	str	w2, [x1, #88]
    304c:	2f000400 	mvni	v0.2s, #0x0
    3050:	f900281f 	str	xzr, [x0, #80]
    3054:	fd002c00 	str	d0, [x0, #88]
    3058:	d65f03c0 	ret
    305c:	b9000061 	str	w1, [x3]
    3060:	17fffff5 	b	3034 <fwp_tape_unlink_scope+0x24>

0000000000003064 <fwp_args173>:
    3064:	d65f03c0 	ret
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_flush>:
    3070:	b00000e0 	adrp	x0, 20000 <__data_start>
    3074:	f9403c00 	ldr	x0, [x0, #120]
    3078:	b4000120 	cbz	x0, 309c <fwp_flush+0x2c>
    307c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3080:	910003fd 	mov	x29, sp
    3084:	97fffe6f 	bl	2a40 <fflush@plt>
    3088:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    308c:	f947ec00 	ldr	x0, [x0, #4056]
    3090:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3094:	f9400000 	ldr	x0, [x0]
    3098:	17fffe6a 	b	2a40 <fflush@plt>
    309c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    30a0:	f947ec00 	ldr	x0, [x0, #4056]
    30a4:	f9400000 	ldr	x0, [x0]
    30a8:	17fffe66 	b	2a40 <fflush@plt>
    30ac:	d503201f 	nop

00000000000030b0 <fwp_heap_oom>:
    30b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    30b4:	f947e863 	ldr	x3, [x3, #4048]
    30b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30bc:	d2800262 	mov	x2, #0x13                  	// #19
    30c0:	910003fd 	mov	x29, sp
    30c4:	f9400063 	ldr	x3, [x3]
    30c8:	d2800021 	mov	x1, #0x1                   	// #1
    30cc:	d0000040 	adrp	x0, d000 <__divti3+0x320>
    30d0:	91102000 	add	x0, x0, #0x408
    30d4:	97fffe4f 	bl	2a10 <fwrite@plt>
    30d8:	d2800000 	mov	x0, #0x0                   	// #0
    30dc:	97fffe59 	bl	2a40 <fflush@plt>
    30e0:	52800cc0 	mov	w0, #0x66                  	// #102
    30e4:	97fffe67 	bl	2a80 <_Exit@plt>
    30e8:	d503201f 	nop
    30ec:	d503201f 	nop

00000000000030f0 <fwp_segv>:
    30f0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    30f4:	b00000e2 	adrp	x2, 20000 <__data_start>
    30f8:	9101c043 	add	x3, x2, #0x70
    30fc:	910003fd 	mov	x29, sp
    3100:	a90153f3 	stp	x19, x20, [sp, #16]
    3104:	2a0003f3 	mov	w19, w0
    3108:	f9400860 	ldr	x0, [x3, #16]
    310c:	f90013f5 	str	x21, [sp, #32]
    3110:	f9400835 	ldr	x21, [x1, #16]
    3114:	b4000280 	cbz	x0, 3164 <fwp_segv+0x74>
    3118:	f9400814 	ldr	x20, [x0, #16]
    311c:	b4000254 	cbz	x20, 3164 <fwp_segv+0x74>
    3120:	528003c0 	mov	w0, #0x1e                  	// #30
    3124:	97fffe4f 	bl	2a60 <sysconf@plt>
    3128:	f144029f 	cmp	x20, #0x100, lsl #12
    312c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3130:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3134:	8b000294 	add	x20, x20, x0
    3138:	d1440021 	sub	x1, x1, #0x100, lsl #12
    313c:	eb0102bf 	cmp	x21, x1
    3140:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3144:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3148:	35000240 	cbnz	w0, 3190 <fwp_segv+0xa0>
    314c:	f94013f5 	ldr	x21, [sp, #32]
    3150:	2a1303e0 	mov	w0, w19
    3154:	a94153f3 	ldp	x19, x20, [sp, #16]
    3158:	d2800001 	mov	x1, #0x0                   	// #0
    315c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3160:	17fffdc4 	b	2870 <signal@plt>
    3164:	9101c042 	add	x2, x2, #0x70
    3168:	f9400c40 	ldr	x0, [x2, #24]
    316c:	b4ffff00 	cbz	x0, 314c <fwp_segv+0x5c>
    3170:	f9401041 	ldr	x1, [x2, #32]
    3174:	cb010000 	sub	x0, x0, x1
    3178:	d1440001 	sub	x1, x0, #0x100, lsl #12
    317c:	91440000 	add	x0, x0, #0x100, lsl #12
    3180:	eb15003f 	cmp	x1, x21
    3184:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3188:	1a9f97e0 	cset	w0, hi	// hi = pmore
    318c:	34fffe00 	cbz	w0, 314c <fwp_segv+0x5c>
    3190:	97ffffb8 	bl	3070 <fwp_flush>
    3194:	f0000041 	adrp	x1, e000 <_IO_stdin_used+0xc00>
    3198:	9106c021 	add	x1, x1, #0x1b0
    319c:	d2800342 	mov	x2, #0x1a                  	// #26
    31a0:	52800040 	mov	w0, #0x2                   	// #2
    31a4:	97fffdeb 	bl	2950 <write@plt>
    31a8:	52800ca0 	mov	w0, #0x65                  	// #101
    31ac:	97fffd79 	bl	2790 <_exit@plt>

00000000000031b0 <descent_phase_fail>:
    31b0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    31b4:	f947e863 	ldr	x3, [x3, #4048]
    31b8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    31bc:	d2800822 	mov	x2, #0x41                  	// #65
    31c0:	910003fd 	mov	x29, sp
    31c4:	f9400063 	ldr	x3, [x3]
    31c8:	d2800021 	mov	x1, #0x1                   	// #1
    31cc:	d0000040 	adrp	x0, d000 <__divti3+0x320>
    31d0:	91108000 	add	x0, x0, #0x420
    31d4:	97fffe0f 	bl	2a10 <fwrite@plt>
    31d8:	52801d20 	mov	w0, #0xe9                  	// #233
    31dc:	97fffe29 	bl	2a80 <_Exit@plt>

00000000000031e0 <descent_phase_report>:
    31e0:	d10243ff 	sub	sp, sp, #0x90
    31e4:	b00000e1 	adrp	x1, 20000 <__data_start>
    31e8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    31ec:	f947f400 	ldr	x0, [x0, #4072]
    31f0:	91004023 	add	x3, x1, #0x10
    31f4:	a9047bfd 	stp	x29, x30, [sp, #64]
    31f8:	910103fd 	add	x29, sp, #0x40
    31fc:	b9401021 	ldr	w1, [x1, #16]
    3200:	a90553f3 	stp	x19, x20, [sp, #80]
    3204:	a9065bf5 	stp	x21, x22, [sp, #96]
    3208:	a90763f7 	stp	x23, x24, [sp, #112]
    320c:	f90043f9 	str	x25, [sp, #128]
    3210:	f9400002 	ldr	x2, [x0]
    3214:	f9001fe2 	str	x2, [sp, #56]
    3218:	d2800002 	mov	x2, #0x0                   	// #0
    321c:	3100043f 	cmn	w1, #0x1
    3220:	54000841 	b.ne	3328 <descent_phase_report+0x148>  // b.any
    3224:	b00000f4 	adrp	x20, 20000 <__data_start>
    3228:	9101c294 	add	x20, x20, #0x70
    322c:	900000f5 	adrp	x21, 1f000 <fwp_fn_table+0xc98>
    3230:	f947eab5 	ldr	x21, [x21, #4048]
    3234:	91002063 	add	x3, x3, #0x8
    3238:	a9429285 	ldp	x5, x4, [x20, #40]
    323c:	910023f7 	add	x23, sp, #0x8
    3240:	ad400861 	ldp	q1, q2, [x3]
    3244:	d0000042 	adrp	x2, d000 <__divti3+0x320>
    3248:	f94002a0 	ldr	x0, [x21]
    324c:	d0000056 	adrp	x22, d000 <__divti3+0x320>
    3250:	3dc00860 	ldr	q0, [x3, #32]
    3254:	d0000058 	adrp	x24, d000 <__divti3+0x320>
    3258:	f9401e83 	ldr	x3, [x20, #56]
    325c:	9111a042 	add	x2, x2, #0x468
    3260:	911302d6 	add	x22, x22, #0x4c0
    3264:	913d4318 	add	x24, x24, #0xf50
    3268:	52800041 	mov	w1, #0x2                   	// #2
    326c:	d2800033 	mov	x19, #0x1                   	// #1
    3270:	d0000059 	adrp	x25, d000 <__divti3+0x320>
    3274:	ad000ae1 	stp	q1, q2, [x23]
    3278:	3d800ae0 	str	q0, [x23, #32]
    327c:	97fffdc1 	bl	2980 <__fprintf_chk@plt>
    3280:	f94002a0 	ldr	x0, [x21]
    3284:	7100067f 	cmp	w19, #0x1
    3288:	54000400 	b.eq	3308 <descent_phase_report+0x128>  // b.none
    328c:	d37df261 	lsl	x1, x19, #3
    3290:	9112e323 	add	x3, x25, #0x4b8
    3294:	8b010285 	add	x5, x20, x1
    3298:	8b0102e4 	add	x4, x23, x1
    329c:	91000673 	add	x19, x19, #0x1
    32a0:	aa1603e2 	mov	x2, x22
    32a4:	52800041 	mov	w1, #0x2                   	// #2
    32a8:	f85f8084 	ldur	x4, [x4, #-8]
    32ac:	f9401ca5 	ldr	x5, [x5, #56]
    32b0:	97fffdb4 	bl	2980 <__fprintf_chk@plt>
    32b4:	f1001e7f 	cmp	x19, #0x7
    32b8:	54fffe41 	b.ne	3280 <descent_phase_report+0xa0>  // b.any
    32bc:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    32c0:	f947f400 	ldr	x0, [x0, #4072]
    32c4:	f9401fe2 	ldr	x2, [sp, #56]
    32c8:	f9400001 	ldr	x1, [x0]
    32cc:	eb010042 	subs	x2, x2, x1
    32d0:	d2800001 	mov	x1, #0x0                   	// #0
    32d4:	540002c1 	b.ne	332c <descent_phase_report+0x14c>  // b.any
    32d8:	f94002a3 	ldr	x3, [x21]
    32dc:	d0000040 	adrp	x0, d000 <__divti3+0x320>
    32e0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    32e4:	91134000 	add	x0, x0, #0x4d0
    32e8:	a94553f3 	ldp	x19, x20, [sp, #80]
    32ec:	d2800082 	mov	x2, #0x4                   	// #4
    32f0:	a9465bf5 	ldp	x21, x22, [sp, #96]
    32f4:	d2800021 	mov	x1, #0x1                   	// #1
    32f8:	a94763f7 	ldp	x23, x24, [sp, #112]
    32fc:	f94043f9 	ldr	x25, [sp, #128]
    3300:	910243ff 	add	sp, sp, #0x90
    3304:	17fffdc3 	b	2a10 <fwrite@plt>
    3308:	f94007e4 	ldr	x4, [sp, #8]
    330c:	aa1803e3 	mov	x3, x24
    3310:	f9402285 	ldr	x5, [x20, #64]
    3314:	aa1603e2 	mov	x2, x22
    3318:	52800041 	mov	w1, #0x2                   	// #2
    331c:	d2800053 	mov	x19, #0x2                   	// #2
    3320:	97fffd98 	bl	2980 <__fprintf_chk@plt>
    3324:	17ffffd7 	b	3280 <descent_phase_report+0xa0>
    3328:	97ffffa2 	bl	31b0 <descent_phase_fail>
    332c:	97fffd79 	bl	2910 <__stack_chk_fail@plt>

0000000000003330 <fwp_heap_chunks>:
    3330:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3334:	910003fd 	mov	x29, sp
    3338:	a90153f3 	stp	x19, x20, [sp, #16]
    333c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3340:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    3344:	911742a1 	add	x1, x21, #0x5d0
    3348:	f100041f 	cmp	x0, #0x1
    334c:	54000ca0 	b.eq	34e0 <fwp_heap_chunks+0x1b0>  // b.none
    3350:	f949f822 	ldr	x2, [x1, #5104]
    3354:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    3358:	912700a5 	add	x5, x5, #0x9c0
    335c:	911742a1 	add	x1, x21, #0x5d0
    3360:	f949ec34 	ldr	x20, [x1, #5080]
    3364:	eb14005f 	cmp	x2, x20
    3368:	54000c42 	b.cs	34f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    336c:	f949fc23 	ldr	x3, [x1, #5112]
    3370:	8b020841 	add	x1, x2, x2, lsl #2
    3374:	d2800004 	mov	x4, #0x0                   	// #0
    3378:	8b010c61 	add	x1, x3, x1, lsl #3
    337c:	14000009 	b	33a0 <fwp_heap_chunks+0x70>
    3380:	91000483 	add	x3, x4, #0x1
    3384:	eb03001f 	cmp	x0, x3
    3388:	54000940 	b.eq	34b0 <fwp_heap_chunks+0x180>  // b.none
    338c:	91000442 	add	x2, x2, #0x1
    3390:	aa0303e4 	mov	x4, x3
    3394:	9100a021 	add	x1, x1, #0x28
    3398:	eb02029f 	cmp	x20, x2
    339c:	54000100 	b.eq	33bc <fwp_heap_chunks+0x8c>  // b.none
    33a0:	39400023 	ldrb	w3, [x1]
    33a4:	34fffee3 	cbz	w3, 3380 <fwp_heap_chunks+0x50>
    33a8:	91000442 	add	x2, x2, #0x1
    33ac:	9100a021 	add	x1, x1, #0x28
    33b0:	d2800004 	mov	x4, #0x0                   	// #0
    33b4:	eb02029f 	cmp	x20, x2
    33b8:	54ffff41 	b.ne	33a0 <fwp_heap_chunks+0x70>  // b.any
    33bc:	cb040294 	sub	x20, x20, x4
    33c0:	f9001bf7 	str	x23, [sp, #48]
    33c4:	911742b7 	add	x23, x21, #0x5d0
    33c8:	8b140013 	add	x19, x0, x20
    33cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    33d0:	f949f2e0 	ldr	x0, [x23, #5088]
    33d4:	cb040021 	sub	x1, x1, x4
    33d8:	f90a1ae1 	str	x1, [x23, #5168]
    33dc:	eb00027f 	cmp	x19, x0
    33e0:	54000429 	b.ls	3464 <fwp_heap_chunks+0x134>  // b.plast
    33e4:	f949eae1 	ldr	x1, [x23, #5072]
    33e8:	eb01027f 	cmp	x19, x1
    33ec:	54000888 	b.hi	34fc <fwp_heap_chunks+0x1cc>  // b.pmore
    33f0:	91010276 	add	x22, x19, #0x40
    33f4:	52800062 	mov	w2, #0x3                   	// #3
    33f8:	f949dae3 	ldr	x3, [x23, #5040]
    33fc:	eb0102df 	cmp	x22, x1
    3400:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3404:	cb0002c1 	sub	x1, x22, x0
    3408:	8b004060 	add	x0, x3, x0, lsl #16
    340c:	d370bc21 	lsl	x1, x1, #16
    3410:	97fffdac 	bl	2ac0 <mprotect@plt>
    3414:	35000740 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3418:	528003c0 	mov	w0, #0x1e                  	// #30
    341c:	97fffd91 	bl	2a60 <sysconf@plt>
    3420:	f949f2e2 	ldr	x2, [x23, #5088]
    3424:	cb0003e5 	neg	x5, x0
    3428:	aa0003e4 	mov	x4, x0
    342c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3430:	f949fee0 	ldr	x0, [x23, #5112]
    3434:	8b020843 	add	x3, x2, x2, lsl #2
    3438:	52800062 	mov	w2, #0x3                   	// #3
    343c:	8b010c01 	add	x1, x0, x1, lsl #3
    3440:	8b030c03 	add	x3, x0, x3, lsl #3
    3444:	d1000421 	sub	x1, x1, #0x1
    3448:	8a050060 	and	x0, x3, x5
    344c:	8b040021 	add	x1, x1, x4
    3450:	8a050021 	and	x1, x1, x5
    3454:	cb000021 	sub	x1, x1, x0
    3458:	97fffd9a 	bl	2ac0 <mprotect@plt>
    345c:	35000500 	cbnz	w0, 34fc <fwp_heap_chunks+0x1cc>
    3460:	f909f2f6 	str	x22, [x23, #5088]
    3464:	911742b5 	add	x21, x21, #0x5d0
    3468:	d370be60 	lsl	x0, x19, #16
    346c:	f949e6a1 	ldr	x1, [x21, #5064]
    3470:	f909eeb3 	str	x19, [x21, #5080]
    3474:	eb01001f 	cmp	x0, x1
    3478:	540000e8 	b.hi	3494 <fwp_heap_chunks+0x164>  // b.pmore
    347c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3480:	aa1403e0 	mov	x0, x20
    3484:	a94153f3 	ldp	x19, x20, [sp, #16]
    3488:	f9401bf7 	ldr	x23, [sp, #48]
    348c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3490:	d65f03c0 	ret
    3494:	f9401bf7 	ldr	x23, [sp, #48]
    3498:	f909e6a0 	str	x0, [x21, #5064]
    349c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34a0:	aa1403e0 	mov	x0, x20
    34a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34ac:	d65f03c0 	ret
    34b0:	911742b5 	add	x21, x21, #0x5d0
    34b4:	91000441 	add	x1, x2, #0x1
    34b8:	f90000a1 	str	x1, [x5]
    34bc:	cb040054 	sub	x20, x2, x4
    34c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    34c4:	cb000020 	sub	x0, x1, x0
    34c8:	f90a1aa0 	str	x0, [x21, #5168]
    34cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    34d0:	aa1403e0 	mov	x0, x20
    34d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    34d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    34dc:	d65f03c0 	ret
    34e0:	f949f422 	ldr	x2, [x1, #5096]
    34e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xa30>
    34e8:	9126e0a5 	add	x5, x5, #0x9b8
    34ec:	17ffff9c 	b	335c <fwp_heap_chunks+0x2c>
    34f0:	d2800004 	mov	x4, #0x0                   	// #0
    34f4:	f9001bf7 	str	x23, [sp, #48]
    34f8:	17ffffb3 	b	33c4 <fwp_heap_chunks+0x94>
    34fc:	97fffeed 	bl	30b0 <fwp_heap_oom>

0000000000003500 <fwp_tape_buffers_dispose>:
    3500:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3504:	910003fd 	mov	x29, sp
    3508:	f9000bf3 	str	x19, [sp, #16]
    350c:	aa0003f3 	mov	x19, x0
    3510:	f9400000 	ldr	x0, [x0]
    3514:	97fffd2f 	bl	29d0 <free@plt>
    3518:	f9400a60 	ldr	x0, [x19, #16]
    351c:	97fffd2d 	bl	29d0 <free@plt>
    3520:	f9401260 	ldr	x0, [x19, #32]
    3524:	97fffd2b 	bl	29d0 <free@plt>
    3528:	f9001a7f 	str	xzr, [x19, #48]
    352c:	4f000400 	movi	v0.4s, #0x0
    3530:	ad000260 	stp	q0, q0, [x19]
    3534:	3d800a60 	str	q0, [x19, #32]
    3538:	f9400bf3 	ldr	x19, [sp, #16]
    353c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3540:	d65f03c0 	ret

0000000000003544 <buf_grow>:
    3544:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3548:	910003fd 	mov	x29, sp
    354c:	a90153f3 	stp	x19, x20, [sp, #16]
    3550:	aa0003f4 	mov	x20, x0
    3554:	f9400400 	ldr	x0, [x0, #8]
    3558:	b100041f 	cmn	x0, #0x1
    355c:	54000400 	b.eq	35dc <buf_grow+0x98>  // b.none
    3560:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3564:	cb000042 	sub	x2, x2, x0
    3568:	eb01005f 	cmp	x2, x1
    356c:	54000383 	b.cc	35dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3570:	f9400a82 	ldr	x2, [x20, #16]
    3574:	91000421 	add	x1, x1, #0x1
    3578:	8b000033 	add	x19, x1, x0
    357c:	eb13005f 	cmp	x2, x19
    3580:	54000242 	b.cs	35c8 <buf_grow+0x84>  // b.hs, b.nlast
    3584:	f100005f 	cmp	x2, #0x0
    3588:	b5000262 	cbnz	x2, 35d4 <buf_grow+0x90>
    358c:	d2800802 	mov	x2, #0x40                  	// #64
    3590:	eb02027f 	cmp	x19, x2
    3594:	54000068 	b.hi	35a0 <buf_grow+0x5c>  // b.pmore
    3598:	14000005 	b	35ac <buf_grow+0x68>
    359c:	b7f800a2 	tbnz	x2, #63, 35b0 <buf_grow+0x6c>
    35a0:	d37ff842 	lsl	x2, x2, #1
    35a4:	eb02027f 	cmp	x19, x2
    35a8:	54ffffa8 	b.hi	359c <buf_grow+0x58>  // b.pmore
    35ac:	aa0203f3 	mov	x19, x2
    35b0:	f9400280 	ldr	x0, [x20]
    35b4:	aa1303e1 	mov	x1, x19
    35b8:	97fffcd2 	bl	2900 <realloc@plt>
    35bc:	b4000100 	cbz	x0, 35dc <buf_grow+0x98>
    35c0:	f9000280 	str	x0, [x20]
    35c4:	f9000a93 	str	x19, [x20, #16]
    35c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    35cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35d0:	d65f03c0 	ret
    35d4:	54fffe6a 	b.ge	35a0 <buf_grow+0x5c>  // b.tcont
    35d8:	17fffff6 	b	35b0 <buf_grow+0x6c>
    35dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    35e0:	f947e863 	ldr	x3, [x3, #4048]
    35e4:	d2800262 	mov	x2, #0x13                  	// #19
    35e8:	d2800021 	mov	x1, #0x1                   	// #1
    35ec:	d0000040 	adrp	x0, d000 <__divti3+0x320>
    35f0:	91102000 	add	x0, x0, #0x408
    35f4:	f9400063 	ldr	x3, [x3]
    35f8:	97fffd06 	bl	2a10 <fwrite@plt>
    35fc:	d2800000 	mov	x0, #0x0                   	// #0
    3600:	97fffd10 	bl	2a40 <fflush@plt>
    3604:	52800cc0 	mov	w0, #0x66                  	// #102
    3608:	97fffd1e 	bl	2a80 <_Exit@plt>
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc5 	bl	3544 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc47 	bl	2760 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <descent_phase_step>:
    3670:	d10143ff 	sub	sp, sp, #0x50
    3674:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3678:	f947f421 	ldr	x1, [x1, #4072]
    367c:	a9027bfd 	stp	x29, x30, [sp, #32]
    3680:	910083fd 	add	x29, sp, #0x20
    3684:	f90023f5 	str	x21, [sp, #64]
    3688:	b00000f5 	adrp	x21, 20000 <__data_start>
    368c:	a90353f3 	stp	x19, x20, [sp, #48]
    3690:	2a0003f3 	mov	w19, w0
    3694:	b94012b4 	ldr	w20, [x21, #16]
    3698:	f9400020 	ldr	x0, [x1]
    369c:	f9000fe0 	str	x0, [sp, #24]
    36a0:	d2800000 	mov	x0, #0x0                   	// #0
    36a4:	11000680 	add	w0, w20, #0x1
    36a8:	6b13001f 	cmp	w0, w19
    36ac:	540005a1 	b.ne	3760 <descent_phase_step+0xf0>  // b.any
    36b0:	910023e1 	add	x1, sp, #0x8
    36b4:	52800020 	mov	w0, #0x1                   	// #1
    36b8:	97fffc62 	bl	2840 <clock_gettime@plt>
    36bc:	35000520 	cbnz	w0, 3760 <descent_phase_step+0xf0>
    36c0:	a94087e0 	ldp	x0, x1, [sp, #8]
    36c4:	d2994002 	mov	x2, #0xca00                	// #51712
    36c8:	f2a77342 	movk	x2, #0x3b9a, lsl #16
    36cc:	9b020400 	madd	x0, x0, x2, x1
    36d0:	b00000e1 	adrp	x1, 20000 <__data_start>
    36d4:	3100069f 	cmn	w20, #0x1
    36d8:	54000160 	b.eq	3704 <descent_phase_step+0x94>  // b.none
    36dc:	9101c022 	add	x2, x1, #0x70
    36e0:	f9403844 	ldr	x4, [x2, #112]
    36e4:	eb00009f 	cmp	x4, x0
    36e8:	540003c8 	b.hi	3760 <descent_phase_step+0xf0>  // b.pmore
    36ec:	91010042 	add	x2, x2, #0x40
    36f0:	93407e94 	sxtw	x20, w20
    36f4:	f8747843 	ldr	x3, [x2, x20, lsl #3]
    36f8:	cb040063 	sub	x3, x3, x4
    36fc:	8b000063 	add	x3, x3, x0
    3700:	f8347843 	str	x3, [x2, x20, lsl #3]
    3704:	71001a7f 	cmp	w19, #0x6
    3708:	540000c1 	b.ne	3720 <descent_phase_step+0xb0>  // b.any
    370c:	9101c023 	add	x3, x1, #0x70
    3710:	12800013 	mov	w19, #0xffffffff            	// #-1
    3714:	f9401c62 	ldr	x2, [x3, #56]
    3718:	91000442 	add	x2, x2, #0x1
    371c:	f9001c62 	str	x2, [x3, #56]
    3720:	9101c021 	add	x1, x1, #0x70
    3724:	b90012b3 	str	w19, [x21, #16]
    3728:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    372c:	f947f442 	ldr	x2, [x2, #4072]
    3730:	f9003820 	str	x0, [x1, #112]
    3734:	aa0203e0 	mov	x0, x2
    3738:	f9400fe2 	ldr	x2, [sp, #24]
    373c:	f9400001 	ldr	x1, [x0]
    3740:	eb010042 	subs	x2, x2, x1
    3744:	d2800001 	mov	x1, #0x0                   	// #0
    3748:	540000e1 	b.ne	3764 <descent_phase_step+0xf4>  // b.any
    374c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    3750:	a94353f3 	ldp	x19, x20, [sp, #48]
    3754:	f94023f5 	ldr	x21, [sp, #64]
    3758:	910143ff 	add	sp, sp, #0x50
    375c:	d65f03c0 	ret
    3760:	97fffe94 	bl	31b0 <descent_phase_fail>
    3764:	97fffc6b 	bl	2910 <__stack_chk_fail@plt>
    3768:	d503201f 	nop
    376c:	d503201f 	nop

0000000000003770 <fwp_cancel_tree.part.0>:
    3770:	b00000e1 	adrp	x1, 20000 <__data_start>
    3774:	9101c022 	add	x2, x1, #0x70
    3778:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    377c:	52800023 	mov	w3, #0x1                   	// #1
    3780:	910003fd 	mov	x29, sp
    3784:	f9400844 	ldr	x4, [x2, #16]
    3788:	f9000bf3 	str	x19, [sp, #16]
    378c:	39014403 	strb	w3, [x0, #81]
    3790:	eb04001f 	cmp	x0, x4
    3794:	54000160 	b.eq	37c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3798:	f9402804 	ldr	x4, [x0, #80]
    379c:	f2001c9f 	tst	x4, #0xff000000ff
    37a0:	54000101 	b.ne	37c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    37a4:	f9403c44 	ldr	x4, [x2, #120]
    37a8:	39015003 	strb	w3, [x0, #84]
    37ac:	f900801f 	str	xzr, [x0, #256]
    37b0:	b40001e4 	cbz	x4, 37ec <fwp_cancel_tree.part.0+0x7c>
    37b4:	f9008080 	str	x0, [x4, #256]
    37b8:	9101c021 	add	x1, x1, #0x70
    37bc:	f9003c20 	str	x0, [x1, #120]
    37c0:	f9401413 	ldr	x19, [x0, #40]
    37c4:	b40000f3 	cbz	x19, 37e0 <fwp_cancel_tree.part.0+0x70>
    37c8:	39414261 	ldrb	w1, [x19, #80]
    37cc:	aa1303e0 	mov	x0, x19
    37d0:	37000041 	tbnz	w1, #0, 37d8 <fwp_cancel_tree.part.0+0x68>
    37d4:	97ffffe7 	bl	3770 <fwp_cancel_tree.part.0>
    37d8:	f9401a73 	ldr	x19, [x19, #48]
    37dc:	b5ffff73 	cbnz	x19, 37c8 <fwp_cancel_tree.part.0+0x58>
    37e0:	f9400bf3 	ldr	x19, [sp, #16]
    37e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    37e8:	d65f03c0 	ret
    37ec:	f9004040 	str	x0, [x2, #128]
    37f0:	17fffff2 	b	37b8 <fwp_cancel_tree.part.0+0x48>

00000000000037f4 <fwp_finish_float>:
    37f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    37f8:	528005c1 	mov	w1, #0x2e                  	// #46
    37fc:	910003fd 	mov	x29, sp
    3800:	f9000bf3 	str	x19, [sp, #16]
    3804:	aa0003f3 	mov	x19, x0
    3808:	97fffc7a 	bl	29f0 <strchr@plt>
    380c:	b4000080 	cbz	x0, 381c <fwp_finish_float+0x28>
    3810:	f9400bf3 	ldr	x19, [sp, #16]
    3814:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3818:	d65f03c0 	ret
    381c:	aa1303e0 	mov	x0, x19
    3820:	52800ca1 	mov	w1, #0x65                  	// #101
    3824:	97fffc73 	bl	29f0 <strchr@plt>
    3828:	b5ffff40 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    382c:	d0000041 	adrp	x1, d000 <__divti3+0x320>
    3830:	aa1303e0 	mov	x0, x19
    3834:	91136021 	add	x1, x1, #0x4d8
    3838:	97fffc8e 	bl	2a70 <strstr@plt>
    383c:	b5fffea0 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3840:	d0000041 	adrp	x1, d000 <__divti3+0x320>
    3844:	aa1303e0 	mov	x0, x19
    3848:	91138021 	add	x1, x1, #0x4e0
    384c:	97fffc89 	bl	2a70 <strstr@plt>
    3850:	b5fffe00 	cbnz	x0, 3810 <fwp_finish_float+0x1c>
    3854:	aa1303e0 	mov	x0, x19
    3858:	97fffbd2 	bl	27a0 <strlen@plt>
    385c:	d0000041 	adrp	x1, d000 <__divti3+0x320>
    3860:	9113a021 	add	x1, x1, #0x4e8
    3864:	8b000262 	add	x2, x19, x0
    3868:	79400023 	ldrh	w3, [x1]
    386c:	39400821 	ldrb	w1, [x1, #2]
    3870:	78206a63 	strh	w3, [x19, x0]
    3874:	39000841 	strb	w1, [x2, #2]
    3878:	17ffffe6 	b	3810 <fwp_finish_float+0x1c>
    387c:	d503201f 	nop

0000000000003880 <fwp_format_g.constprop.0>:
    3880:	d10483ff 	sub	sp, sp, #0x120
    3884:	d0000044 	adrp	x4, d000 <__divti3+0x320>
    3888:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    388c:	f947f442 	ldr	x2, [x2, #4072]
    3890:	9113c084 	add	x4, x4, #0x4f0
    3894:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3898:	9102c3fd 	add	x29, sp, #0xb0
    389c:	d2800803 	mov	x3, #0x40                  	// #64
    38a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    38a4:	93407c38 	sxtw	x24, w1
    38a8:	aa0303e1 	mov	x1, x3
    38ac:	fd008be8 	str	d8, [sp, #272]
    38b0:	1e604008 	fmov	d8, d0
    38b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    38b8:	910083f4 	add	x20, sp, #0x20
    38bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    38c0:	aa0003f5 	mov	x21, x0
    38c4:	a91073fb 	stp	x27, x28, [sp, #256]
    38c8:	5100071c 	sub	w28, w24, #0x1
    38cc:	2a1c03e5 	mov	w5, w28
    38d0:	f9400040 	ldr	x0, [x2]
    38d4:	f90057e0 	str	x0, [sp, #168]
    38d8:	d2800000 	mov	x0, #0x0                   	// #0
    38dc:	52800042 	mov	w2, #0x2                   	// #2
    38e0:	aa1403e0 	mov	x0, x20
    38e4:	97fffbe7 	bl	2880 <__snprintf_chk@plt>
    38e8:	52800ca1 	mov	w1, #0x65                  	// #101
    38ec:	aa1403e0 	mov	x0, x20
    38f0:	97fffc40 	bl	29f0 <strchr@plt>
    38f4:	aa0003f3 	mov	x19, x0
    38f8:	52800142 	mov	w2, #0xa                   	// #10
    38fc:	91000400 	add	x0, x0, #0x1
    3900:	d2800001 	mov	x1, #0x0                   	// #0
    3904:	97fffc2b 	bl	29b0 <strtol@plt>
    3908:	aa0003f7 	mov	x23, x0
    390c:	11001400 	add	w0, w0, #0x5
    3910:	7100541f 	cmp	w0, #0x15
    3914:	54000d68 	b.hi	3ac0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3918:	4b170385 	sub	w5, w28, w23
    391c:	710000bf 	cmp	w5, #0x0
    3920:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3924:	54000b80 	b.eq	3a94 <fwp_format_g.constprop.0+0x214>  // b.none
    3928:	394083e0 	ldrb	w0, [sp, #32]
    392c:	cb180273 	sub	x19, x19, x24
    3930:	91000673 	add	x19, x19, #0x1
    3934:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3938:	7100b41f 	cmp	w0, #0x2d
    393c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3940:	1a9f17e4 	cset	w4, eq	// eq = none
    3944:	cb010266 	sub	x6, x19, x1
    3948:	d10004da 	sub	x26, x6, #0x1
    394c:	540018a0 	b.eq	3c60 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3950:	910183f9 	add	x25, sp, #0x60
    3954:	d280091b 	mov	x27, #0x48                  	// #72
    3958:	aa1903e7 	mov	x7, x25
    395c:	91000423 	add	x3, x1, #0x1
    3960:	91011cc6 	add	x6, x6, #0x47
    3964:	910004f6 	add	x22, x7, #0x1
    3968:	37f80ff7 	tbnz	w23, #31, 3b64 <fwp_format_g.constprop.0+0x2e4>
    396c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3970:	93407ef7 	sxtw	x23, w23
    3974:	390000e4 	strb	w4, [x7]
    3978:	aa1303e1 	mov	x1, x19
    397c:	aa1703e2 	mov	x2, x23
    3980:	aa1603e0 	mov	x0, x22
    3984:	b9000be5 	str	w5, [sp, #8]
    3988:	cb170374 	sub	x20, x27, x23
    398c:	a9011be3 	stp	x3, x6, [sp, #16]
    3990:	97fffb74 	bl	2760 <memcpy@plt>
    3994:	d1000694 	sub	x20, x20, #0x1
    3998:	f9400be3 	ldr	x3, [sp, #16]
    399c:	8b1702d6 	add	x22, x22, x23
    39a0:	aa1603e0 	mov	x0, x22
    39a4:	aa1a03e2 	mov	x2, x26
    39a8:	aa0303e1 	mov	x1, x3
    39ac:	aa1403e3 	mov	x3, x20
    39b0:	97fffbac 	bl	2860 <__memcpy_chk@plt>
    39b4:	8b1a02d6 	add	x22, x22, x26
    39b8:	f9400fe6 	ldr	x6, [sp, #24]
    39bc:	d2800900 	mov	x0, #0x48                  	// #72
    39c0:	b9400be5 	ldr	w5, [sp, #8]
    39c4:	8b170261 	add	x1, x19, x23
    39c8:	cb1400c3 	sub	x3, x6, x20
    39cc:	cb060294 	sub	x20, x20, x6
    39d0:	f101207f 	cmp	x3, #0x48
    39d4:	93407cb8 	sxtw	x24, w5
    39d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    39dc:	aa1803e2 	mov	x2, x24
    39e0:	8b1802d3 	add	x19, x22, x24
    39e4:	8b140063 	add	x3, x3, x20
    39e8:	aa1603e0 	mov	x0, x22
    39ec:	97fffb9d 	bl	2860 <__memcpy_chk@plt>
    39f0:	cb190273 	sub	x19, x19, x25
    39f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    39f8:	eb00027f 	cmp	x19, x0
    39fc:	aa1903e1 	mov	x1, x25
    3a00:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3a04:	aa1503e0 	mov	x0, x21
    3a08:	aa1303e2 	mov	x2, x19
    3a0c:	97fffb55 	bl	2760 <memcpy@plt>
    3a10:	38336abf 	strb	wzr, [x21, x19]
    3a14:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a18:	aa1503e0 	mov	x0, x21
    3a1c:	97fffb61 	bl	27a0 <strlen@plt>
    3a20:	aa0003f3 	mov	x19, x0
    3a24:	528005c1 	mov	w1, #0x2e                  	// #46
    3a28:	aa1503e0 	mov	x0, x21
    3a2c:	97fffbf1 	bl	29f0 <strchr@plt>
    3a30:	b4000140 	cbz	x0, 3a58 <fwp_format_g.constprop.0+0x1d8>
    3a34:	b4000133 	cbz	x19, 3a58 <fwp_format_g.constprop.0+0x1d8>
    3a38:	aa1303e1 	mov	x1, x19
    3a3c:	d1000673 	sub	x19, x19, #0x1
    3a40:	38736aa0 	ldrb	w0, [x21, x19]
    3a44:	7100c01f 	cmp	w0, #0x30
    3a48:	54001001 	b.ne	3c48 <fwp_format_g.constprop.0+0x3c8>  // b.any
    3a4c:	38336abf 	strb	wzr, [x21, x19]
    3a50:	b5ffff53 	cbnz	x19, 3a38 <fwp_format_g.constprop.0+0x1b8>
    3a54:	d503201f 	nop
    3a58:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3a5c:	f947f400 	ldr	x0, [x0, #4072]
    3a60:	f94057e2 	ldr	x2, [sp, #168]
    3a64:	f9400001 	ldr	x1, [x0]
    3a68:	eb010042 	subs	x2, x2, x1
    3a6c:	d2800001 	mov	x1, #0x0                   	// #0
    3a70:	54001061 	b.ne	3c7c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3a74:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3a78:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3a7c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3a80:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3a84:	a95073fb 	ldp	x27, x28, [sp, #256]
    3a88:	fd408be8 	ldr	d8, [sp, #272]
    3a8c:	910483ff 	add	sp, sp, #0x120
    3a90:	d65f03c0 	ret
    3a94:	1e604100 	fmov	d0, d8
    3a98:	710000bf 	cmp	w5, #0x0
    3a9c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3aa0:	aa1503e0 	mov	x0, x21
    3aa4:	d0000044 	adrp	x4, d000 <__divti3+0x320>
    3aa8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3aac:	91142084 	add	x4, x4, #0x508
    3ab0:	52800042 	mov	w2, #0x2                   	// #2
    3ab4:	d2803201 	mov	x1, #0x190                 	// #400
    3ab8:	97fffb72 	bl	2880 <__snprintf_chk@plt>
    3abc:	17ffffd7 	b	3a18 <fwp_format_g.constprop.0+0x198>
    3ac0:	cb140273 	sub	x19, x19, x20
    3ac4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3ac8:	910183f9 	add	x25, sp, #0x60
    3acc:	aa1303e2 	mov	x2, x19
    3ad0:	aa1403e1 	mov	x1, x20
    3ad4:	aa1903e0 	mov	x0, x25
    3ad8:	d2800803 	mov	x3, #0x40                  	// #64
    3adc:	97fffb61 	bl	2860 <__memcpy_chk@plt>
    3ae0:	38336b3f 	strb	wzr, [x25, x19]
    3ae4:	aa1903e0 	mov	x0, x25
    3ae8:	528005c1 	mov	w1, #0x2e                  	// #46
    3aec:	97fffbc1 	bl	29f0 <strchr@plt>
    3af0:	b40001c0 	cbz	x0, 3b28 <fwp_format_g.constprop.0+0x2a8>
    3af4:	b50000b3 	cbnz	x19, 3b08 <fwp_format_g.constprop.0+0x288>
    3af8:	1400000c 	b	3b28 <fwp_format_g.constprop.0+0x2a8>
    3afc:	381ff01f 	sturb	wzr, [x0, #-1]
    3b00:	f1000673 	subs	x19, x19, #0x1
    3b04:	54000120 	b.eq	3b28 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3b08:	8b130320 	add	x0, x25, x19
    3b0c:	385ff001 	ldurb	w1, [x0, #-1]
    3b10:	7100c03f 	cmp	w1, #0x30
    3b14:	54ffff40 	b.eq	3afc <fwp_format_g.constprop.0+0x27c>  // b.none
    3b18:	d1000673 	sub	x19, x19, #0x1
    3b1c:	38736b20 	ldrb	w0, [x25, x19]
    3b20:	7100b81f 	cmp	w0, #0x2e
    3b24:	54000a80 	b.eq	3c74 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3b28:	710002ff 	cmp	w23, #0x0
    3b2c:	528005a1 	mov	w1, #0x2d                  	// #45
    3b30:	aa1903e5 	mov	x5, x25
    3b34:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3b38:	aa1503e0 	mov	x0, x21
    3b3c:	52800566 	mov	w6, #0x2b                  	// #43
    3b40:	d0000044 	adrp	x4, d000 <__divti3+0x320>
    3b44:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3b48:	9113e084 	add	x4, x4, #0x4f8
    3b4c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3b50:	52800042 	mov	w2, #0x2                   	// #2
    3b54:	d2803201 	mov	x1, #0x190                 	// #400
    3b58:	97fffb4a 	bl	2880 <__snprintf_chk@plt>
    3b5c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3b60:	17ffffbe 	b	3a58 <fwp_format_g.constprop.0+0x1d8>
    3b64:	52800605 	mov	w5, #0x30                  	// #48
    3b68:	390000e5 	strb	w5, [x7]
    3b6c:	d100077b 	sub	x27, x27, #0x1
    3b70:	aa0303e1 	mov	x1, x3
    3b74:	aa1603e0 	mov	x0, x22
    3b78:	aa1b03e3 	mov	x3, x27
    3b7c:	aa1a03e2 	mov	x2, x26
    3b80:	f90007e6 	str	x6, [sp, #8]
    3b84:	b90013e4 	str	w4, [sp, #16]
    3b88:	8b1a02d6 	add	x22, x22, x26
    3b8c:	b9001be5 	str	w5, [sp, #24]
    3b90:	97fffb34 	bl	2860 <__memcpy_chk@plt>
    3b94:	f94007e6 	ldr	x6, [sp, #8]
    3b98:	2a3703e7 	mvn	w7, w23
    3b9c:	b94013e4 	ldr	w4, [sp, #16]
    3ba0:	cb1b00c1 	sub	x1, x6, x27
    3ba4:	cb06037b 	sub	x27, x27, x6
    3ba8:	f101203f 	cmp	x1, #0x48
    3bac:	d2800906 	mov	x6, #0x48                  	// #72
    3bb0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3bb4:	8b1b0023 	add	x3, x1, x27
    3bb8:	310006ff 	cmn	w23, #0x1
    3bbc:	54000220 	b.eq	3c00 <fwp_format_g.constprop.0+0x380>  // b.none
    3bc0:	b9401be5 	ldr	w5, [sp, #24]
    3bc4:	d2800001 	mov	x1, #0x0                   	// #0
    3bc8:	f101207f 	cmp	x3, #0x48
    3bcc:	d1000462 	sub	x2, x3, #0x1
    3bd0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3bd4:	38216ac5 	strb	w5, [x22, x1]
    3bd8:	cb030003 	sub	x3, x0, x3
    3bdc:	91000421 	add	x1, x1, #0x1
    3be0:	91000463 	add	x3, x3, #0x1
    3be4:	eb00007f 	cmp	x3, x0
    3be8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3bec:	cb000063 	sub	x3, x3, x0
    3bf0:	8b020063 	add	x3, x3, x2
    3bf4:	6b0100ff 	cmp	w7, w1
    3bf8:	54fffe8c 	b.gt	3bc8 <fwp_format_g.constprop.0+0x348>
    3bfc:	8b2742d6 	add	x22, x22, w7, uxtw
    3c00:	f101207f 	cmp	x3, #0x48
    3c04:	d2800905 	mov	x5, #0x48                  	// #72
    3c08:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3c0c:	aa1603e0 	mov	x0, x22
    3c10:	cb0300a1 	sub	x1, x5, x3
    3c14:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3c18:	91000421 	add	x1, x1, #0x1
    3c1c:	d1000463 	sub	x3, x3, #0x1
    3c20:	eb05003f 	cmp	x1, x5
    3c24:	38001402 	strb	w2, [x0], #1
    3c28:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3c2c:	93407f82 	sxtw	x2, w28
    3c30:	cb050025 	sub	x5, x1, x5
    3c34:	aa1303e1 	mov	x1, x19
    3c38:	8b0300a3 	add	x3, x5, x3
    3c3c:	8b1802d3 	add	x19, x22, x24
    3c40:	97fffb08 	bl	2860 <__memcpy_chk@plt>
    3c44:	17ffff6b 	b	39f0 <fwp_format_g.constprop.0+0x170>
    3c48:	d1000421 	sub	x1, x1, #0x1
    3c4c:	38616aa0 	ldrb	w0, [x21, x1]
    3c50:	7100b81f 	cmp	w0, #0x2e
    3c54:	54fff021 	b.ne	3a58 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3c58:	38216abf 	strb	wzr, [x21, x1]
    3c5c:	17ffff7f 	b	3a58 <fwp_format_g.constprop.0+0x1d8>
    3c60:	910187e7 	add	x7, sp, #0x61
    3c64:	910183f9 	add	x25, sp, #0x60
    3c68:	d28008fb 	mov	x27, #0x47                  	// #71
    3c6c:	390183e0 	strb	w0, [sp, #96]
    3c70:	17ffff3b 	b	395c <fwp_format_g.constprop.0+0xdc>
    3c74:	38336b3f 	strb	wzr, [x25, x19]
    3c78:	17ffffac 	b	3b28 <fwp_format_g.constprop.0+0x2a8>
    3c7c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3c80:	97fffb24 	bl	2910 <__stack_chk_fail@plt>

0000000000003c84 <fwp_heap_report>:
    3c84:	d105c3ff 	sub	sp, sp, #0x170
    3c88:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    3c8c:	91174042 	add	x2, x2, #0x5d0
    3c90:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3c94:	f947e821 	ldr	x1, [x1, #4048]
    3c98:	a9117bfd 	stp	x29, x30, [sp, #272]
    3c9c:	910443fd 	add	x29, sp, #0x110
    3ca0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3ca4:	f947f400 	ldr	x0, [x0, #4072]
    3ca8:	a9135bf5 	stp	x21, x22, [sp, #304]
    3cac:	a91463f7 	stp	x23, x24, [sp, #320]
    3cb0:	a9156bf9 	stp	x25, x26, [sp, #336]
    3cb4:	6d1627e8 	stp	d8, d9, [sp, #352]
    3cb8:	fd4a1c48 	ldr	d8, [x2, #5176]
    3cbc:	fd4a2049 	ldr	d9, [x2, #5184]
    3cc0:	f9400036 	ldr	x22, [x1]
    3cc4:	f9400001 	ldr	x1, [x0]
    3cc8:	f90087e1 	str	x1, [sp, #264]
    3ccc:	d2800001 	mov	x1, #0x0                   	// #0
    3cd0:	f949e459 	ldr	x25, [x2, #5064]
    3cd4:	d0000041 	adrp	x1, d000 <__divti3+0x320>
    3cd8:	f94a1057 	ldr	x23, [x2, #5152]
    3cdc:	d0000040 	adrp	x0, d000 <__divti3+0x320>
    3ce0:	f94a1458 	ldr	x24, [x2, #5160]
    3ce4:	91144021 	add	x1, x1, #0x510
    3ce8:	91146000 	add	x0, x0, #0x518
    3cec:	97fffaed 	bl	28a0 <fopen@plt>
    3cf0:	b4000760 	cbz	x0, 3ddc <fwp_heap_report+0x158>
    3cf4:	528daad5 	mov	w21, #0x6d56                	// #27990
    3cf8:	a91253f3 	stp	x19, x20, [sp, #288]
    3cfc:	aa0003f4 	mov	x20, x0
    3d00:	910023f3 	add	x19, sp, #0x8
    3d04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3d08:	72aae915 	movk	w21, #0x5748, lsl #16
    3d0c:	d503201f 	nop
    3d10:	aa1403e2 	mov	x2, x20
    3d14:	aa1303e0 	mov	x0, x19
    3d18:	52802001 	mov	w1, #0x100                 	// #256
    3d1c:	97fffb6d 	bl	2ad0 <fgets@plt>
    3d20:	b4000280 	cbz	x0, 3d70 <fwp_heap_report+0xec>
    3d24:	b9400261 	ldr	w1, [x19]
    3d28:	6b15003f 	cmp	w1, w21
    3d2c:	54ffff21 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d30:	39401260 	ldrb	w0, [x19, #4]
    3d34:	7101341f 	cmp	w0, #0x4d
    3d38:	54fffec1 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d3c:	394037e0 	ldrb	w0, [sp, #13]
    3d40:	7100e81f 	cmp	w0, #0x3a
    3d44:	54fffe61 	b.ne	3d10 <fwp_heap_report+0x8c>  // b.any
    3d48:	52800142 	mov	w2, #0xa                   	// #10
    3d4c:	d2800001 	mov	x1, #0x0                   	// #0
    3d50:	91003be0 	add	x0, sp, #0xe
    3d54:	97fffb17 	bl	29b0 <strtol@plt>
    3d58:	aa1403e2 	mov	x2, x20
    3d5c:	aa0003fa 	mov	x26, x0
    3d60:	52802001 	mov	w1, #0x100                 	// #256
    3d64:	aa1303e0 	mov	x0, x19
    3d68:	97fffb5a 	bl	2ad0 <fgets@plt>
    3d6c:	b5fffdc0 	cbnz	x0, 3d24 <fwp_heap_report+0xa0>
    3d70:	aa1403e0 	mov	x0, x20
    3d74:	97fffac7 	bl	2890 <fclose@plt>
    3d78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3d7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3d80:	f947f400 	ldr	x0, [x0, #4072]
    3d84:	f94087e2 	ldr	x2, [sp, #264]
    3d88:	f9400001 	ldr	x1, [x0]
    3d8c:	eb010042 	subs	x2, x2, x1
    3d90:	d2800001 	mov	x1, #0x0                   	// #0
    3d94:	54000281 	b.ne	3de4 <fwp_heap_report+0x160>  // b.any
    3d98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3d9c:	aa1a03e6 	mov	x6, x26
    3da0:	aa1903e5 	mov	x5, x25
    3da4:	aa1803e4 	mov	x4, x24
    3da8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3dac:	aa1703e3 	mov	x3, x23
    3db0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3db4:	aa1603e0 	mov	x0, x22
    3db8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3dbc:	1e604121 	fmov	d1, d9
    3dc0:	1e604100 	fmov	d0, d8
    3dc4:	d0000042 	adrp	x2, d000 <__divti3+0x320>
    3dc8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3dcc:	9114e042 	add	x2, x2, #0x538
    3dd0:	9105c3ff 	add	sp, sp, #0x170
    3dd4:	52800041 	mov	w1, #0x2                   	// #2
    3dd8:	17fffaea 	b	2980 <__fprintf_chk@plt>
    3ddc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3de0:	17ffffe7 	b	3d7c <fwp_heap_report+0xf8>
    3de4:	a91253f3 	stp	x19, x20, [sp, #288]
    3de8:	97fffaca 	bl	2910 <__stack_chk_fail@plt>
    3dec:	d503201f 	nop

0000000000003df0 <fwp_heap_init>:
    3df0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3df4:	f0000163 	adrp	x3, 32000 <fwp_heap+0xa30>
    3df8:	91134061 	add	x1, x3, #0x4d0
    3dfc:	910003fd 	mov	x29, sp
    3e00:	a90153f3 	stp	x19, x20, [sp, #16]
    3e04:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    3e08:	91174262 	add	x2, x19, #0x5d0
    3e0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e10:	52800024 	mov	w4, #0x1                   	// #1
    3e14:	52800200 	mov	w0, #0x10                  	// #16
    3e18:	b913a444 	str	w4, [x2, #5028]
    3e1c:	d503201f 	nop
    3e20:	b8004420 	str	w0, [x1], #4
    3e24:	11004000 	add	w0, w0, #0x10
    3e28:	7104401f 	cmp	w0, #0x110
    3e2c:	54ffffa1 	b.ne	3e20 <fwp_heap_init+0x30>  // b.any
    3e30:	f0000042 	adrp	x2, e000 <_IO_stdin_used+0xc00>
    3e34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3e38:	f0000161 	adrp	x1, 32000 <fwp_heap+0xa30>
    3e3c:	91144021 	add	x1, x1, #0x510
    3e40:	3dc07843 	ldr	q3, [x2, #480]
    3e44:	d2800000 	mov	x0, #0x0                   	// #0
    3e48:	4e040401 	dup	v1.4s, v0.s[0]
    3e4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3e50:	0f215400 	shl	v0.2s, v0.2s, #1
    3e54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3e58:	3ca06821 	str	q1, [x1, x0]
    3e5c:	91004000 	add	x0, x0, #0x10
    3e60:	f101801f 	cmp	x0, #0x60
    3e64:	54ffff21 	b.ne	3e48 <fwp_heap_init+0x58>  // b.any
    3e68:	f0000164 	adrp	x4, 32000 <fwp_heap+0xa30>
    3e6c:	91134063 	add	x3, x3, #0x4d0
    3e70:	9115c084 	add	x4, x4, #0x570
    3e74:	91174266 	add	x6, x19, #0x5d0
    3e78:	d2800002 	mov	x2, #0x0                   	// #0
    3e7c:	d2800000 	mov	x0, #0x0                   	// #0
    3e80:	d2880205 	mov	x5, #0x4010                	// #16400
    3e84:	d503201f 	nop
    3e88:	910f0001 	add	x1, x0, #0x3c0
    3e8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3e90:	eb02003f 	cmp	x1, x2
    3e94:	540000a2 	b.cs	3ea8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3e98:	91000400 	add	x0, x0, #0x1
    3e9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3ea0:	eb02003f 	cmp	x1, x2
    3ea4:	54ffffa3 	b.cc	3e98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3ea8:	91004042 	add	x2, x2, #0x10
    3eac:	38001480 	strb	w0, [x4], #1
    3eb0:	eb05005f 	cmp	x2, x5
    3eb4:	54fffea1 	b.ne	3e88 <fwp_heap_init+0x98>  // b.any
    3eb8:	528000b5 	mov	w21, #0x5                   	// #5
    3ebc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3ec0:	14000004 	b	3ed0 <fwp_heap_init+0xe0>
    3ec4:	d342fe94 	lsr	x20, x20, #2
    3ec8:	710006b5 	subs	w21, w21, #0x1
    3ecc:	54000720 	b.eq	3fb0 <fwp_heap_init+0x1c0>  // b.none
    3ed0:	91404296 	add	x22, x20, #0x10, lsl #12
    3ed4:	d2800005 	mov	x5, #0x0                   	// #0
    3ed8:	aa1603e1 	mov	x1, x22
    3edc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3ee0:	52880443 	mov	w3, #0x4022                	// #16418
    3ee4:	52800002 	mov	w2, #0x0                   	// #0
    3ee8:	d2800000 	mov	x0, #0x0                   	// #0
    3eec:	97fffaad 	bl	29a0 <mmap@plt>
    3ef0:	aa0003e6 	mov	x6, x0
    3ef4:	b100041f 	cmn	x0, #0x1
    3ef8:	54fffe60 	b.eq	3ec4 <fwp_heap_init+0xd4>  // b.none
    3efc:	b40005a0 	cbz	x0, 3fb0 <fwp_heap_init+0x1c0>
    3f00:	d350fe94 	lsr	x20, x20, #16
    3f04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3f08:	8b0000c7 	add	x7, x6, x0
    3f0c:	91174275 	add	x21, x19, #0x5d0
    3f10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3f14:	8b140a81 	add	x1, x20, x20, lsl #2
    3f18:	d2800005 	mov	x5, #0x0                   	// #0
    3f1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3f20:	d37df021 	lsl	x1, x1, #3
    3f24:	52880443 	mov	w3, #0x4022                	// #16418
    3f28:	52800002 	mov	w2, #0x0                   	// #0
    3f2c:	d2800000 	mov	x0, #0x0                   	// #0
    3f30:	f909daa7 	str	x7, [x21, #5040]
    3f34:	f909dea6 	str	x6, [x21, #5048]
    3f38:	f909e2b6 	str	x22, [x21, #5056]
    3f3c:	f909eab4 	str	x20, [x21, #5072]
    3f40:	f90a02a1 	str	x1, [x21, #5120]
    3f44:	97fffa97 	bl	29a0 <mmap@plt>
    3f48:	aa0003e1 	mov	x1, x0
    3f4c:	b100041f 	cmn	x0, #0x1
    3f50:	54000300 	b.eq	3fb0 <fwp_heap_init+0x1c0>  // b.none
    3f54:	d0000040 	adrp	x0, d000 <__divti3+0x320>
    3f58:	91170000 	add	x0, x0, #0x5c0
    3f5c:	f909fea1 	str	x1, [x21, #5112]
    3f60:	97fffad0 	bl	2aa0 <getenv@plt>
    3f64:	52800002 	mov	w2, #0x0                   	// #0
    3f68:	aa0003e1 	mov	x1, x0
    3f6c:	b40000e0 	cbz	x0, 3f88 <fwp_heap_init+0x198>
    3f70:	39400000 	ldrb	w0, [x0]
    3f74:	340000a0 	cbz	w0, 3f88 <fwp_heap_init+0x198>
    3f78:	7100c000 	subs	w0, w0, #0x30
    3f7c:	54000120 	b.eq	3fa0 <fwp_heap_init+0x1b0>  // b.none
    3f80:	7100001f 	cmp	w0, #0x0
    3f84:	1a9f07e2 	cset	w2, ne	// ne = any
    3f88:	91174273 	add	x19, x19, #0x5d0
    3f8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3f90:	b913aa62 	str	w2, [x19, #5032]
    3f94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3f98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3f9c:	d65f03c0 	ret
    3fa0:	39400420 	ldrb	w0, [x1, #1]
    3fa4:	7100001f 	cmp	w0, #0x0
    3fa8:	1a9f07e2 	cset	w2, ne	// ne = any
    3fac:	17fffff7 	b	3f88 <fwp_heap_init+0x198>
    3fb0:	97fffc40 	bl	30b0 <fwp_heap_oom>

0000000000003fb4 <fwp_wake_io>:
    3fb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3fb8:	9101c122 	add	x2, x9, #0x70
    3fbc:	f9400001 	ldr	x1, [x0]
    3fc0:	5280000a 	mov	w10, #0x0                   	// #0
    3fc4:	f9403c46 	ldr	x6, [x2, #120]
    3fc8:	52800008 	mov	w8, #0x0                   	// #0
    3fcc:	4f000400 	movi	v0.4s, #0x0
    3fd0:	52800027 	mov	w7, #0x1                   	// #1
    3fd4:	aa0103e2 	mov	x2, x1
    3fd8:	b4000321 	cbz	x1, 403c <fwp_wake_io+0x88>
    3fdc:	f9408c25 	ldr	x5, [x1, #280]
    3fe0:	39015c27 	strb	w7, [x1, #87]
    3fe4:	b4000165 	cbz	x5, 4010 <fwp_wake_io+0x5c>
    3fe8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3fec:	b4000364 	cbz	x4, 4058 <fwp_wake_io+0xa4>
    3ff0:	f9009483 	str	x3, [x4, #296]
    3ff4:	f9409423 	ldr	x3, [x1, #296]
    3ff8:	b4000043 	cbz	x3, 4000 <fwp_wake_io+0x4c>
    3ffc:	f9009064 	str	x4, [x3, #288]
    4000:	91080023 	add	x3, x1, #0x200
    4004:	f900943f 	str	xzr, [x1, #296]
    4008:	3c918060 	stur	q0, [x3, #-232]
    400c:	f9400001 	ldr	x1, [x0]
    4010:	f9402843 	ldr	x3, [x2, #80]
    4014:	f2001c7f 	tst	x3, #0xff000000ff
    4018:	54fffde1 	b.ne	3fd4 <fwp_wake_io+0x20>  // b.any
    401c:	39015047 	strb	w7, [x2, #84]
    4020:	f900805f 	str	xzr, [x2, #256]
    4024:	b40001e6 	cbz	x6, 4060 <fwp_wake_io+0xac>
    4028:	f90080c2 	str	x2, [x6, #256]
    402c:	aa0203e6 	mov	x6, x2
    4030:	52800028 	mov	w8, #0x1                   	// #1
    4034:	aa0103e2 	mov	x2, x1
    4038:	b5fffd21 	cbnz	x1, 3fdc <fwp_wake_io+0x28>
    403c:	3400006a 	cbz	w10, 4048 <fwp_wake_io+0x94>
    4040:	9101c120 	add	x0, x9, #0x70
    4044:	f900400b 	str	x11, [x0, #128]
    4048:	34000068 	cbz	w8, 4054 <fwp_wake_io+0xa0>
    404c:	9101c129 	add	x9, x9, #0x70
    4050:	f9003d26 	str	x6, [x9, #120]
    4054:	d65f03c0 	ret
    4058:	f90000a3 	str	x3, [x5]
    405c:	17ffffe7 	b	3ff8 <fwp_wake_io+0x44>
    4060:	aa0203eb 	mov	x11, x2
    4064:	5280002a 	mov	w10, #0x1                   	// #1
    4068:	17fffff1 	b	402c <fwp_wake_io+0x78>
    406c:	d503201f 	nop

0000000000004070 <fwp_tape_buffers_release>:
    4070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4074:	910003fd 	mov	x29, sp
    4078:	a90153f3 	stp	x19, x20, [sp, #16]
    407c:	aa0003f3 	mov	x19, x0
    4080:	f9401400 	ldr	x0, [x0, #40]
    4084:	b7f80760 	tbnz	x0, #63, 4170 <fwp_tape_buffers_release+0x100>
    4088:	f9401a61 	ldr	x1, [x19, #48]
    408c:	b7f80301 	tbnz	x1, #63, 40ec <fwp_tape_buffers_release+0x7c>
    4090:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    4094:	eb02001f 	cmp	x0, x2
    4098:	540002a8 	b.hi	40ec <fwp_tape_buffers_release+0x7c>  // b.pmore
    409c:	8b000400 	add	x0, x0, x0, lsl #1
    40a0:	d2a00102 	mov	x2, #0x80000               	// #524288
    40a4:	d37df000 	lsl	x0, x0, #3
    40a8:	cb000042 	sub	x2, x2, x0
    40ac:	eb420c3f 	cmp	x1, x2, lsr #3
    40b0:	540001e8 	b.hi	40ec <fwp_tape_buffers_release+0x7c>  // b.pmore
    40b4:	8b010c14 	add	x20, x0, x1, lsl #3
    40b8:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    40bc:	91174000 	add	x0, x0, #0x5d0
    40c0:	97fffa78 	bl	2aa0 <getenv@plt>
    40c4:	b4000240 	cbz	x0, 410c <fwp_tape_buffers_release+0x9c>
    40c8:	39400001 	ldrb	w1, [x0]
    40cc:	7100c03f 	cmp	w1, #0x30
    40d0:	540001e1 	b.ne	410c <fwp_tape_buffers_release+0x9c>  // b.any
    40d4:	39400400 	ldrb	w0, [x0, #1]
    40d8:	350001a0 	cbnz	w0, 410c <fwp_tape_buffers_release+0x9c>
    40dc:	aa1303e0 	mov	x0, x19
    40e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    40e4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40e8:	17fffd06 	b	3500 <fwp_tape_buffers_dispose>
    40ec:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    40f0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    40f4:	91174000 	add	x0, x0, #0x5d0
    40f8:	97fffa6a 	bl	2aa0 <getenv@plt>
    40fc:	b4ffff00 	cbz	x0, 40dc <fwp_tape_buffers_release+0x6c>
    4100:	39400001 	ldrb	w1, [x0]
    4104:	7100c03f 	cmp	w1, #0x30
    4108:	54fffe60 	b.eq	40d4 <fwp_tape_buffers_release+0x64>  // b.none
    410c:	d1000681 	sub	x1, x20, #0x1
    4110:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4114:	eb00003f 	cmp	x1, x0
    4118:	54fffe28 	b.hi	40dc <fwp_tape_buffers_release+0x6c>  // b.pmore
    411c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4120:	900000f6 	adrp	x22, 20000 <__data_start>
    4124:	9101c2d6 	add	x22, x22, #0x70
    4128:	910222d5 	add	x21, x22, #0x88
    412c:	aa1503e0 	mov	x0, x21
    4130:	97fffcf4 	bl	3500 <fwp_tape_buffers_dispose>
    4134:	ad400a61 	ldp	q1, q2, [x19]
    4138:	f90062d4 	str	x20, [x22, #192]
    413c:	4f000400 	movi	v0.4s, #0x0
    4140:	ad000aa1 	stp	q1, q2, [x21]
    4144:	3dc00a61 	ldr	q1, [x19, #32]
    4148:	3d800aa1 	str	q1, [x21, #32]
    414c:	f9401a60 	ldr	x0, [x19, #48]
    4150:	f9001aa0 	str	x0, [x21, #48]
    4154:	f9001a7f 	str	xzr, [x19, #48]
    4158:	ad000260 	stp	q0, q0, [x19]
    415c:	3d800a60 	str	q0, [x19, #32]
    4160:	a94153f3 	ldp	x19, x20, [sp, #16]
    4164:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4168:	a8c37bfd 	ldp	x29, x30, [sp], #48
    416c:	d65f03c0 	ret
    4170:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    4174:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    4178:	91174000 	add	x0, x0, #0x5d0
    417c:	97fffa49 	bl	2aa0 <getenv@plt>
    4180:	b5fffa40 	cbnz	x0, 40c8 <fwp_tape_buffers_release+0x58>
    4184:	17ffffd6 	b	40dc <fwp_tape_buffers_release+0x6c>
    4188:	d503201f 	nop
    418c:	d503201f 	nop

0000000000004190 <fwp_trap>:
    4190:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4194:	900000e2 	adrp	x2, 20000 <__data_start>
    4198:	d53bd041 	mrs	x1, tpidr_el0
    419c:	910003fd 	mov	x29, sp
    41a0:	f9403c42 	ldr	x2, [x2, #120]
    41a4:	91400021 	add	x1, x1, #0x0, lsl #12
    41a8:	91004021 	add	x1, x1, #0x10
    41ac:	a90153f3 	stp	x19, x20, [sp, #16]
    41b0:	aa0003f3 	mov	x19, x0
    41b4:	f9400034 	ldr	x20, [x1]
    41b8:	b4000062 	cbz	x2, 41c4 <fwp_trap+0x34>
    41bc:	aa0203e0 	mov	x0, x2
    41c0:	97fffa20 	bl	2a40 <fflush@plt>
    41c4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    41c8:	f947ec00 	ldr	x0, [x0, #4056]
    41cc:	f9400000 	ldr	x0, [x0]
    41d0:	97fffa1c 	bl	2a40 <fflush@plt>
    41d4:	aa1303e3 	mov	x3, x19
    41d8:	b0000042 	adrp	x2, d000 <__divti3+0x320>
    41dc:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xc98>
    41e0:	f947ea73 	ldr	x19, [x19, #4048]
    41e4:	9117a042 	add	x2, x2, #0x5e8
    41e8:	52800041 	mov	w1, #0x2                   	// #2
    41ec:	f9400260 	ldr	x0, [x19]
    41f0:	97fff9e4 	bl	2980 <__fprintf_chk@plt>
    41f4:	b40000b4 	cbz	x20, 4208 <fwp_trap+0x78>
    41f8:	f9400260 	ldr	x0, [x19]
    41fc:	97fffa11 	bl	2a40 <fflush@plt>
    4200:	52800ca0 	mov	w0, #0x65                  	// #101
    4204:	97fffa1f 	bl	2a80 <_Exit@plt>
    4208:	52800ca0 	mov	w0, #0x65                  	// #101
    420c:	97fff96d 	bl	27c0 <exit@plt>

0000000000004210 <fwp_rc_forget_slot.part.0>:
    4210:	ca404401 	eor	x1, x0, x0, lsr #17
    4214:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4218:	ca412421 	eor	x1, x1, x1, lsr #9
    421c:	910003fd 	mov	x29, sp
    4220:	92401c21 	and	x1, x1, #0xff
    4224:	f9000bf3 	str	x19, [sp, #16]
    4228:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    422c:	91174262 	add	x2, x19, #0x5d0
    4230:	910a2423 	add	x3, x1, #0x289
    4234:	8b010c41 	add	x1, x2, x1, lsl #3
    4238:	8b030c43 	add	x3, x2, x3, lsl #3
    423c:	f94a2421 	ldr	x1, [x1, #5192]
    4240:	b50000a1 	cbnz	x1, 4254 <fwp_rc_forget_slot.part.0+0x44>
    4244:	14000012 	b	428c <fwp_rc_forget_slot.part.0+0x7c>
    4248:	91004023 	add	x3, x1, #0x10
    424c:	f9400821 	ldr	x1, [x1, #16]
    4250:	b40001e1 	cbz	x1, 428c <fwp_rc_forget_slot.part.0+0x7c>
    4254:	f9400022 	ldr	x2, [x1]
    4258:	eb02001f 	cmp	x0, x2
    425c:	54ffff61 	b.ne	4248 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4260:	f9400060 	ldr	x0, [x3]
    4264:	91174273 	add	x19, x19, #0x5d0
    4268:	f9400801 	ldr	x1, [x0, #16]
    426c:	f9000061 	str	x1, [x3]
    4270:	97fff9d8 	bl	29d0 <free@plt>
    4274:	f94e2660 	ldr	x0, [x19, #7240]
    4278:	d1000400 	sub	x0, x0, #0x1
    427c:	f90e2660 	str	x0, [x19, #7240]
    4280:	f9400bf3 	ldr	x19, [sp, #16]
    4284:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4288:	d65f03c0 	ret
    428c:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    4290:	9117e000 	add	x0, x0, #0x5f8
    4294:	97ffffbf 	bl	4190 <fwp_trap>
    4298:	d503201f 	nop
    429c:	d503201f 	nop

00000000000042a0 <fwp_rc_prepare_chunk>:
    42a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    42a4:	910003fd 	mov	x29, sp
    42a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    42ac:	b0000176 	adrp	x22, 31000 <fwp_root_context+0xc10>
    42b0:	911742c2 	add	x2, x22, #0x5d0
    42b4:	b9401c03 	ldr	w3, [x0, #28]
    42b8:	aa0103f5 	mov	x21, x1
    42bc:	a90153f3 	stp	x19, x20, [sp, #16]
    42c0:	aa0003f4 	mov	x20, x0
    42c4:	f94e2440 	ldr	x0, [x2, #7240]
    42c8:	b4000440 	cbz	x0, 4350 <fwp_rc_prepare_chunk+0xb0>
    42cc:	d2800013 	mov	x19, #0x0                   	// #0
    42d0:	35000203 	cbnz	w3, 4310 <fwp_rc_prepare_chunk+0x70>
    42d4:	b4000361 	cbz	x1, 4340 <fwp_rc_prepare_chunk+0xa0>
    42d8:	f9401280 	ldr	x0, [x20, #32]
    42dc:	97fff9bd 	bl	29d0 <free@plt>
    42e0:	aa1503e0 	mov	x0, x21
    42e4:	d2800021 	mov	x1, #0x1                   	// #1
    42e8:	97fff982 	bl	28f0 <calloc@plt>
    42ec:	f9001280 	str	x0, [x20, #32]
    42f0:	b5000460 	cbnz	x0, 437c <fwp_rc_prepare_chunk+0xdc>
    42f4:	97fffb6f 	bl	30b0 <fwp_heap_oom>
    42f8:	97ffffc6 	bl	4210 <fwp_rc_forget_slot.part.0>
    42fc:	91000673 	add	x19, x19, #0x1
    4300:	b9401e83 	ldr	w3, [x20, #28]
    4304:	eb13007f 	cmp	x3, x19
    4308:	54000169 	b.ls	4334 <fwp_rc_prepare_chunk+0x94>  // b.plast
    430c:	d503201f 	nop
    4310:	f9401283 	ldr	x3, [x20, #32]
    4314:	8b130060 	add	x0, x3, x19
    4318:	38736863 	ldrb	w3, [x3, x19]
    431c:	7103fc7f 	cmp	w3, #0xff
    4320:	54fffec0 	b.eq	42f8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4324:	b9401e83 	ldr	w3, [x20, #28]
    4328:	91000673 	add	x19, x19, #0x1
    432c:	eb13007f 	cmp	x3, x19
    4330:	54ffff08 	b.hi	4310 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4334:	eb0302bf 	cmp	x21, x3
    4338:	54000121 	b.ne	435c <fwp_rc_prepare_chunk+0xbc>  // b.any
    433c:	b5000335 	cbnz	x21, 43a0 <fwp_rc_prepare_chunk+0x100>
    4340:	a94153f3 	ldp	x19, x20, [sp, #16]
    4344:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4348:	a8c37bfd 	ldp	x29, x30, [sp], #48
    434c:	d65f03c0 	ret
    4350:	2a0303e3 	mov	w3, w3
    4354:	eb0302bf 	cmp	x21, x3
    4358:	54ffff20 	b.eq	433c <fwp_rc_prepare_chunk+0x9c>  // b.none
    435c:	911742c2 	add	x2, x22, #0x5d0
    4360:	f9401280 	ldr	x0, [x20, #32]
    4364:	f94e2841 	ldr	x1, [x2, #7248]
    4368:	cb030021 	sub	x1, x1, x3
    436c:	f90e2841 	str	x1, [x2, #7248]
    4370:	97fff998 	bl	29d0 <free@plt>
    4374:	b5fffb75 	cbnz	x21, 42e0 <fwp_rc_prepare_chunk+0x40>
    4378:	f900129f 	str	xzr, [x20, #32]
    437c:	911742d6 	add	x22, x22, #0x5d0
    4380:	f94e2ac0 	ldr	x0, [x22, #7248]
    4384:	b9001e95 	str	w21, [x20, #28]
    4388:	a94153f3 	ldp	x19, x20, [sp, #16]
    438c:	8b150000 	add	x0, x0, x21
    4390:	f90e2ac0 	str	x0, [x22, #7248]
    4394:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4398:	a8c37bfd 	ldp	x29, x30, [sp], #48
    439c:	d65f03c0 	ret
    43a0:	f9401280 	ldr	x0, [x20, #32]
    43a4:	aa1503e2 	mov	x2, x21
    43a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    43ac:	52800001 	mov	w1, #0x0                   	// #0
    43b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    43b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43b8:	17fff94a 	b	28e0 <memset@plt>
    43bc:	d503201f 	nop

00000000000043c0 <fwp_heap_refill>:
    43c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    43c4:	910003fd 	mov	x29, sp
    43c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    43cc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    43d0:	911742b5 	add	x21, x21, #0x5d0
    43d4:	aa0003f6 	mov	x22, x0
    43d8:	d2800020 	mov	x0, #0x1                   	// #1
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	a90363f7 	stp	x23, x24, [sp, #48]
    43e4:	2a0103f7 	mov	w23, w1
    43e8:	2a0203f8 	mov	w24, w2
    43ec:	97fffbd1 	bl	3330 <fwp_heap_chunks>
    43f0:	aa0003f3 	mov	x19, x0
    43f4:	f949fea2 	ldr	x2, [x21, #5112]
    43f8:	8b000800 	add	x0, x0, x0, lsl #2
    43fc:	2a1703e1 	mov	w1, w23
    4400:	52800025 	mov	w5, #0x1                   	// #1
    4404:	d37df000 	lsl	x0, x0, #3
    4408:	910f0021 	add	x1, x1, #0x3c0
    440c:	8b000054 	add	x20, x2, x0
    4410:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4414:	52a00024 	mov	w4, #0x10000               	// #65536
    4418:	38206845 	strb	w5, [x2, x0]
    441c:	aa1403e0 	mov	x0, x20
    4420:	39000698 	strb	w24, [x20, #1]
    4424:	39000a97 	strb	w23, [x20, #2]
    4428:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    442c:	b9000681 	str	w1, [x20, #4]
    4430:	2a0103e5 	mov	w5, w1
    4434:	8b0300a2 	add	x2, x5, x3
    4438:	1ac10881 	udiv	w1, w4, w1
    443c:	9ac50842 	udiv	x2, x2, x5
    4440:	b9000a81 	str	w1, [x20, #8]
    4444:	92404021 	and	x1, x1, #0x1ffff
    4448:	b9001a82 	str	w2, [x20, #24]
    444c:	97ffff95 	bl	42a0 <fwp_rc_prepare_chunk>
    4450:	f949daa0 	ldr	x0, [x21, #5040]
    4454:	29408a81 	ldp	w1, w2, [x20, #4]
    4458:	8b134000 	add	x0, x0, x19, lsl #16
    445c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4460:	8b214003 	add	x3, x0, w1, uxtw
    4464:	9ba20021 	umaddl	x1, w1, w2, x0
    4468:	a94363f7 	ldp	x23, x24, [sp, #48]
    446c:	a90086c3 	stp	x3, x1, [x22, #8]
    4470:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4474:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4478:	d65f03c0 	ret
    447c:	d503201f 	nop

0000000000004480 <fwp_mem_free>:
    4480:	b40003c0 	cbz	x0, 44f8 <fwp_mem_free+0x78>
    4484:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4488:	910003fd 	mov	x29, sp
    448c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4490:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4494:	911742a1 	add	x1, x21, #0x5d0
    4498:	a90153f3 	stp	x19, x20, [sp, #16]
    449c:	aa0003f3 	mov	x19, x0
    44a0:	f949d823 	ldr	x3, [x1, #5040]
    44a4:	f949ec22 	ldr	x2, [x1, #5080]
    44a8:	cb030000 	sub	x0, x0, x3
    44ac:	eb02401f 	cmp	x0, x2, lsl #16
    44b0:	540001c2 	b.cs	44e8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    44b4:	d350fc16 	lsr	x22, x0, #16
    44b8:	a90363f7 	stp	x23, x24, [sp, #48]
    44bc:	f949fc22 	ldr	x2, [x1, #5112]
    44c0:	8b160ad4 	add	x20, x22, x22, lsl #2
    44c4:	d37df294 	lsl	x20, x20, #3
    44c8:	ab140057 	adds	x23, x2, x20
    44cc:	540000c0 	b.eq	44e4 <fwp_mem_free+0x64>  // b.none
    44d0:	38746842 	ldrb	w2, [x2, x20]
    44d4:	7100045f 	cmp	w2, #0x1
    44d8:	54000120 	b.eq	44fc <fwp_mem_free+0x7c>  // b.none
    44dc:	7100085f 	cmp	w2, #0x2
    44e0:	540005e0 	b.eq	459c <fwp_mem_free+0x11c>  // b.none
    44e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    44e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44f4:	d65f03c0 	ret
    44f8:	d65f03c0 	ret
    44fc:	f94012f8 	ldr	x24, [x23, #32]
    4500:	b94006e1 	ldr	w1, [x23, #4]
    4504:	f90023f9 	str	x25, [sp, #64]
    4508:	2a0103e2 	mov	w2, w1
    450c:	394006f9 	ldrb	w25, [x23, #1]
    4510:	39400af4 	ldrb	w20, [x23, #2]
    4514:	b4000158 	cbz	x24, 453c <fwp_mem_free+0xbc>
    4518:	92403e76 	and	x22, x19, #0xffff
    451c:	9ac20ad6 	udiv	x22, x22, x2
    4520:	38766b01 	ldrb	w1, [x24, x22]
    4524:	8b160300 	add	x0, x24, x22
    4528:	7103fc3f 	cmp	w1, #0xff
    452c:	54000980 	b.eq	465c <fwp_mem_free+0x1dc>  // b.none
    4530:	38366b1f 	strb	wzr, [x24, x22]
    4534:	b94006e1 	ldr	w1, [x23, #4]
    4538:	2a0103e2 	mov	w2, w1
    453c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4540:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4544:	cb390000 	sub	x0, x0, w25, uxtb
    4548:	8b340074 	add	x20, x3, w20, uxtb
    454c:	911742b5 	add	x21, x21, #0x5d0
    4550:	1e630021 	ucvtf	d1, w1
    4554:	d37ae400 	lsl	x0, x0, #6
    4558:	8b140c14 	add	x20, x0, x20, lsl #3
    455c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4560:	f8746aa0 	ldr	x0, [x21, x20]
    4564:	f94023f9 	ldr	x25, [sp, #64]
    4568:	aa2003e0 	mvn	x0, x0
    456c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4570:	f9000260 	str	x0, [x19]
    4574:	f8346ab3 	str	x19, [x21, x20]
    4578:	f94a12a0 	ldr	x0, [x21, #5152]
    457c:	1e612800 	fadd	d0, d0, d1
    4580:	a94153f3 	ldp	x19, x20, [sp, #16]
    4584:	cb020000 	sub	x0, x0, x2
    4588:	f90a12a0 	str	x0, [x21, #5152]
    458c:	fd0a22a0 	str	d0, [x21, #5184]
    4590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4594:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4598:	d65f03c0 	ret
    459c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    45a0:	8b000063 	add	x3, x3, x0
    45a4:	eb03027f 	cmp	x19, x3
    45a8:	54fff9e1 	b.ne	44e4 <fwp_mem_free+0x64>  // b.any
    45ac:	fd400ae1 	ldr	d1, [x23, #16]
    45b0:	fd4a2020 	ldr	d0, [x1, #5184]
    45b4:	f9400ae0 	ldr	x0, [x23, #16]
    45b8:	7e61d821 	ucvtf	d1, d1
    45bc:	f94a1022 	ldr	x2, [x1, #5152]
    45c0:	f94012f3 	ldr	x19, [x23, #32]
    45c4:	1e612800 	fadd	d0, d0, d1
    45c8:	cb000042 	sub	x2, x2, x0
    45cc:	f90a1022 	str	x2, [x1, #5152]
    45d0:	fd0a2020 	str	d0, [x1, #5184]
    45d4:	b40000b3 	cbz	x19, 45e8 <fwp_mem_free+0x168>
    45d8:	39400260 	ldrb	w0, [x19]
    45dc:	7103fc1f 	cmp	w0, #0xff
    45e0:	54000380 	b.eq	4650 <fwp_mem_free+0x1d0>  // b.none
    45e4:	3900027f 	strb	wzr, [x19]
    45e8:	b9400ee2 	ldr	w2, [x23, #12]
    45ec:	b4000142 	cbz	x2, 4614 <fwp_mem_free+0x194>
    45f0:	911742a1 	add	x1, x21, #0x5d0
    45f4:	8b160040 	add	x0, x2, x22
    45f8:	8b000800 	add	x0, x0, x0, lsl #2
    45fc:	f949fc21 	ldr	x1, [x1, #5112]
    4600:	8b140034 	add	x20, x1, x20
    4604:	8b000c20 	add	x0, x1, x0, lsl #3
    4608:	3802869f 	strb	wzr, [x20], #40
    460c:	eb00029f 	cmp	x20, x0
    4610:	54ffffc1 	b.ne	4608 <fwp_mem_free+0x188>  // b.any
    4614:	911742a0 	add	x0, x21, #0x5d0
    4618:	f94a1801 	ldr	x1, [x0, #5168]
    461c:	f949f803 	ldr	x3, [x0, #5104]
    4620:	8b020021 	add	x1, x1, x2
    4624:	f90a1801 	str	x1, [x0, #5168]
    4628:	eb16007f 	cmp	x3, x22
    462c:	54000049 	b.ls	4634 <fwp_mem_free+0x1b4>  // b.plast
    4630:	f909f816 	str	x22, [x0, #5104]
    4634:	911742b5 	add	x21, x21, #0x5d0
    4638:	f949f6a0 	ldr	x0, [x21, #5096]
    463c:	eb16001f 	cmp	x0, x22
    4640:	54fff529 	b.ls	44e4 <fwp_mem_free+0x64>  // b.plast
    4644:	a94363f7 	ldp	x23, x24, [sp, #48]
    4648:	f909f6b6 	str	x22, [x21, #5096]
    464c:	17ffffa7 	b	44e8 <fwp_mem_free+0x68>
    4650:	aa1303e0 	mov	x0, x19
    4654:	97fffeef 	bl	4210 <fwp_rc_forget_slot.part.0>
    4658:	17ffffe3 	b	45e4 <fwp_mem_free+0x164>
    465c:	97fffeed 	bl	4210 <fwp_rc_forget_slot.part.0>
    4660:	17ffffb4 	b	4530 <fwp_mem_free+0xb0>

0000000000004664 <fwp_rc_wide_dup>:
    4664:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4668:	910003fd 	mov	x29, sp
    466c:	a90153f3 	stp	x19, x20, [sp, #16]
    4670:	aa0003f3 	mov	x19, x0
    4674:	ca404400 	eor	x0, x0, x0, lsr #17
    4678:	f90013f5 	str	x21, [sp, #32]
    467c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    4680:	ca402400 	eor	x0, x0, x0, lsr #9
    4684:	911742a2 	add	x2, x21, #0x5d0
    4688:	92401c00 	and	x0, x0, #0xff
    468c:	910a2403 	add	x3, x0, #0x289
    4690:	8b000c40 	add	x0, x2, x0, lsl #3
    4694:	8b030c54 	add	x20, x2, x3, lsl #3
    4698:	f94a2401 	ldr	x1, [x0, #5192]
    469c:	b50000a1 	cbnz	x1, 46b0 <fwp_rc_wide_dup+0x4c>
    46a0:	14000033 	b	476c <fwp_rc_wide_dup+0x108>
    46a4:	91004034 	add	x20, x1, #0x10
    46a8:	f9400821 	ldr	x1, [x1, #16]
    46ac:	b4000241 	cbz	x1, 46f4 <fwp_rc_wide_dup+0x90>
    46b0:	f9400022 	ldr	x2, [x1]
    46b4:	eb02027f 	cmp	x19, x2
    46b8:	54ffff61 	b.ne	46a4 <fwp_rc_wide_dup+0x40>  // b.any
    46bc:	f9400281 	ldr	x1, [x20]
    46c0:	39400260 	ldrb	w0, [x19]
    46c4:	7103f81f 	cmp	w0, #0xfe
    46c8:	54000220 	b.eq	470c <fwp_rc_wide_dup+0xa8>  // b.none
    46cc:	b40001a1 	cbz	x1, 4700 <fwp_rc_wide_dup+0x9c>
    46d0:	f9400420 	ldr	x0, [x1, #8]
    46d4:	b100041f 	cmn	x0, #0x1
    46d8:	54000440 	b.eq	4760 <fwp_rc_wide_dup+0xfc>  // b.none
    46dc:	91000400 	add	x0, x0, #0x1
    46e0:	f9000420 	str	x0, [x1, #8]
    46e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    46e8:	f94013f5 	ldr	x21, [sp, #32]
    46ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    46f0:	d65f03c0 	ret
    46f4:	39400260 	ldrb	w0, [x19]
    46f8:	7103f81f 	cmp	w0, #0xfe
    46fc:	54000100 	b.eq	471c <fwp_rc_wide_dup+0xb8>  // b.none
    4700:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    4704:	9117e000 	add	x0, x0, #0x5f8
    4708:	97fffea2 	bl	4190 <fwp_trap>
    470c:	b4000081 	cbz	x1, 471c <fwp_rc_wide_dup+0xb8>
    4710:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    4714:	91188000 	add	x0, x0, #0x620
    4718:	97fffe9e 	bl	4190 <fwp_trap>
    471c:	d2800300 	mov	x0, #0x18                  	// #24
    4720:	97fff864 	bl	28b0 <malloc@plt>
    4724:	b4000280 	cbz	x0, 4774 <fwp_rc_wide_dup+0x110>
    4728:	d2801fe1 	mov	x1, #0xff                  	// #255
    472c:	a9000413 	stp	x19, x1, [x0]
    4730:	911742b5 	add	x21, x21, #0x5d0
    4734:	f900081f 	str	xzr, [x0, #16]
    4738:	12800001 	mov	w1, #0xffffffff            	// #-1
    473c:	f9000280 	str	x0, [x20]
    4740:	39000261 	strb	w1, [x19]
    4744:	f94e26a0 	ldr	x0, [x21, #7240]
    4748:	a94153f3 	ldp	x19, x20, [sp, #16]
    474c:	91000400 	add	x0, x0, #0x1
    4750:	f90e26a0 	str	x0, [x21, #7240]
    4754:	f94013f5 	ldr	x21, [sp, #32]
    4758:	a8c37bfd 	ldp	x29, x30, [sp], #48
    475c:	d65f03c0 	ret
    4760:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    4764:	91192000 	add	x0, x0, #0x648
    4768:	97fffe8a 	bl	4190 <fwp_trap>
    476c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4770:	17ffffd4 	b	46c0 <fwp_rc_wide_dup+0x5c>
    4774:	97fffa4f 	bl	30b0 <fwp_heap_oom>
    4778:	d503201f 	nop
    477c:	d503201f 	nop

0000000000004780 <fwp_closure_drop_push>:
    4780:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4784:	910003fd 	mov	x29, sp
    4788:	a90153f3 	stp	x19, x20, [sp, #16]
    478c:	aa0003f3 	mov	x19, x0
    4790:	a9408014 	ldp	x20, x0, [x0, #8]
    4794:	a9025bf5 	stp	x21, x22, [sp, #32]
    4798:	aa0103f5 	mov	x21, x1
    479c:	a90363f7 	stp	x23, x24, [sp, #48]
    47a0:	eb00029f 	cmp	x20, x0
    47a4:	54000160 	b.eq	47d0 <fwp_closure_drop_push+0x50>  // b.none
    47a8:	f9400276 	ldr	x22, [x19]
    47ac:	d37df297 	lsl	x23, x20, #3
    47b0:	91000694 	add	x20, x20, #0x1
    47b4:	f9000674 	str	x20, [x19, #8]
    47b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    47bc:	f8376ad5 	str	x21, [x22, x23]
    47c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    47c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    47c8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    47cc:	d65f03c0 	ret
    47d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    47d4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    47d8:	eb00029f 	cmp	x20, x0
    47dc:	540003e8 	b.hi	4858 <fwp_closure_drop_push+0xd8>  // b.pmore
    47e0:	d37cee99 	lsl	x25, x20, #4
    47e4:	d37ffa9a 	lsl	x26, x20, #1
    47e8:	aa1903e0 	mov	x0, x25
    47ec:	97fff831 	bl	28b0 <malloc@plt>
    47f0:	aa0003f6 	mov	x22, x0
    47f4:	b4000380 	cbz	x0, 4864 <fwp_closure_drop_push+0xe4>
    47f8:	aa1303f8 	mov	x24, x19
    47fc:	aa1903e3 	mov	x3, x25
    4800:	d37df297 	lsl	x23, x20, #3
    4804:	aa1703e2 	mov	x2, x23
    4808:	f8418719 	ldr	x25, [x24], #24
    480c:	aa1903e1 	mov	x1, x25
    4810:	97fff814 	bl	2860 <__memcpy_chk@plt>
    4814:	eb18033f 	cmp	x25, x24
    4818:	540000a0 	b.eq	482c <fwp_closure_drop_push+0xac>  // b.none
    481c:	aa1903e0 	mov	x0, x25
    4820:	97fff86c 	bl	29d0 <free@plt>
    4824:	f9400674 	ldr	x20, [x19, #8]
    4828:	d37df297 	lsl	x23, x20, #3
    482c:	91000694 	add	x20, x20, #0x1
    4830:	f9000276 	str	x22, [x19]
    4834:	f9000a7a 	str	x26, [x19, #16]
    4838:	a9446bf9 	ldp	x25, x26, [sp, #64]
    483c:	f9000674 	str	x20, [x19, #8]
    4840:	f8376ad5 	str	x21, [x22, x23]
    4844:	a94153f3 	ldp	x19, x20, [sp, #16]
    4848:	a9425bf5 	ldp	x21, x22, [sp, #32]
    484c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4850:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4854:	d65f03c0 	ret
    4858:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    485c:	9119a000 	add	x0, x0, #0x668
    4860:	97fffe4c 	bl	4190 <fwp_trap>
    4864:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4868:	f947e863 	ldr	x3, [x3, #4048]
    486c:	d2800262 	mov	x2, #0x13                  	// #19
    4870:	d2800021 	mov	x1, #0x1                   	// #1
    4874:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    4878:	91102000 	add	x0, x0, #0x408
    487c:	f9400063 	ldr	x3, [x3]
    4880:	97fff864 	bl	2a10 <fwrite@plt>
    4884:	d2800000 	mov	x0, #0x0                   	// #0
    4888:	97fff86e 	bl	2a40 <fflush@plt>
    488c:	52800cc0 	mov	w0, #0x66                  	// #102
    4890:	97fff87c 	bl	2a80 <_Exit@plt>

0000000000004894 <fwp_closure_drop.part.0>:
    4894:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4898:	d0000041 	adrp	x1, e000 <_IO_stdin_used+0xc00>
    489c:	910003fd 	mov	x29, sp
    48a0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    48a4:	f947f463 	ldr	x3, [x3, #4072]
    48a8:	a90153f3 	stp	x19, x20, [sp, #16]
    48ac:	d10883ff 	sub	sp, sp, #0x220
    48b0:	910003e2 	mov	x2, sp
    48b4:	d53bd053 	mrs	x19, tpidr_el0
    48b8:	910063f4 	add	x20, sp, #0x18
    48bc:	3dc07c20 	ldr	q0, [x1, #496]
    48c0:	91400264 	add	x4, x19, #0x0, lsl #12
    48c4:	91004084 	add	x4, x4, #0x10
    48c8:	aa0003e1 	mov	x1, x0
    48cc:	aa0203e0 	mov	x0, x2
    48d0:	f9400062 	ldr	x2, [x3]
    48d4:	f9010fe2 	str	x2, [sp, #536]
    48d8:	d2800002 	mov	x2, #0x0                   	// #0
    48dc:	f90003f4 	str	x20, [sp]
    48e0:	f9000080 	str	x0, [x4]
    48e4:	3c8083e0 	stur	q0, [sp, #8]
    48e8:	97ffffa6 	bl	4780 <fwp_closure_drop_push>
    48ec:	f94007e0 	ldr	x0, [sp, #8]
    48f0:	b40002e0 	cbz	x0, 494c <fwp_closure_drop.part.0+0xb8>
    48f4:	f90123f5 	str	x21, [sp, #576]
    48f8:	900000f5 	adrp	x21, 20000 <__data_start>
    48fc:	9101c2b5 	add	x21, x21, #0x70
    4900:	14000006 	b	4918 <fwp_closure_drop.part.0+0x84>
    4904:	f9400422 	ldr	x2, [x1, #8]
    4908:	52800001 	mov	w1, #0x0                   	// #0
    490c:	d63f0040 	blr	x2
    4910:	f94007e0 	ldr	x0, [sp, #8]
    4914:	b40001a0 	cbz	x0, 4948 <fwp_closure_drop.part.0+0xb4>
    4918:	f94003e1 	ldr	x1, [sp]
    491c:	d1000400 	sub	x0, x0, #0x1
    4920:	f90007e0 	str	x0, [sp, #8]
    4924:	f94066a2 	ldr	x2, [x21, #200]
    4928:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    492c:	b9400001 	ldr	w1, [x0]
    4930:	8b011441 	add	x1, x2, x1, lsl #5
    4934:	f9400c21 	ldr	x1, [x1, #24]
    4938:	b5fffe61 	cbnz	x1, 4904 <fwp_closure_drop.part.0+0x70>
    493c:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    4940:	911a2000 	add	x0, x0, #0x688
    4944:	97fffe13 	bl	4190 <fwp_trap>
    4948:	f94123f5 	ldr	x21, [sp, #576]
    494c:	91400273 	add	x19, x19, #0x0, lsl #12
    4950:	91004273 	add	x19, x19, #0x10
    4954:	f94003e0 	ldr	x0, [sp]
    4958:	f900027f 	str	xzr, [x19]
    495c:	eb14001f 	cmp	x0, x20
    4960:	54000040 	b.eq	4968 <fwp_closure_drop.part.0+0xd4>  // b.none
    4964:	97fff81b 	bl	29d0 <free@plt>
    4968:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    496c:	f947f400 	ldr	x0, [x0, #4072]
    4970:	f9410fe2 	ldr	x2, [sp, #536]
    4974:	f9400001 	ldr	x1, [x0]
    4978:	eb010042 	subs	x2, x2, x1
    497c:	d2800001 	mov	x1, #0x0                   	// #0
    4980:	540000a1 	b.ne	4994 <fwp_closure_drop.part.0+0x100>  // b.any
    4984:	910883ff 	add	sp, sp, #0x220
    4988:	a94153f3 	ldp	x19, x20, [sp, #16]
    498c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4990:	d65f03c0 	ret
    4994:	f90123f5 	str	x21, [sp, #576]
    4998:	97fff7de 	bl	2910 <__stack_chk_fail@plt>
    499c:	d503201f 	nop

00000000000049a0 <fwp_tape_of>:
    49a0:	aa0003e1 	mov	x1, x0
    49a4:	92403c00 	and	x0, x0, #0xffff
    49a8:	b40000e0 	cbz	x0, 49c4 <fwp_tape_of+0x24>
    49ac:	d1000402 	sub	x2, x0, #0x1
    49b0:	900000e3 	adrp	x3, 20000 <__data_start>
    49b4:	9101c060 	add	x0, x3, #0x70
    49b8:	f9406800 	ldr	x0, [x0, #208]
    49bc:	eb02001f 	cmp	x0, x2
    49c0:	540000cc 	b.gt	49d8 <fwp_tape_of+0x38>
    49c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    49c8:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    49cc:	911ae000 	add	x0, x0, #0x6b8
    49d0:	910003fd 	mov	x29, sp
    49d4:	97fffdef 	bl	4190 <fwp_trap>
    49d8:	8b020440 	add	x0, x2, x2, lsl #1
    49dc:	f9403863 	ldr	x3, [x3, #112]
    49e0:	8b000842 	add	x2, x2, x0, lsl #2
    49e4:	d37df042 	lsl	x2, x2, #3
    49e8:	8b020060 	add	x0, x3, x2
    49ec:	b9400404 	ldr	w4, [x0, #4]
    49f0:	34fffea4 	cbz	w4, 49c4 <fwp_tape_of+0x24>
    49f4:	b8626862 	ldr	w2, [x3, x2]
    49f8:	9350fc21 	asr	x1, x1, #16
    49fc:	6b01005f 	cmp	w2, w1
    4a00:	54fffe21 	b.ne	49c4 <fwp_tape_of+0x24>  // b.any
    4a04:	d65f03c0 	ret
    4a08:	d503201f 	nop
    4a0c:	d503201f 	nop

0000000000004a10 <fwp_now_ns>:
    4a10:	d100c3ff 	sub	sp, sp, #0x30
    4a14:	52800020 	mov	w0, #0x1                   	// #1
    4a18:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    4a1c:	f947f442 	ldr	x2, [x2, #4072]
    4a20:	910023e1 	add	x1, sp, #0x8
    4a24:	a9027bfd 	stp	x29, x30, [sp, #32]
    4a28:	910083fd 	add	x29, sp, #0x20
    4a2c:	f9400043 	ldr	x3, [x2]
    4a30:	f9000fe3 	str	x3, [sp, #24]
    4a34:	d2800003 	mov	x3, #0x0                   	// #0
    4a38:	97fff782 	bl	2840 <clock_gettime@plt>
    4a3c:	350002c0 	cbnz	w0, 4a94 <fwp_now_ns+0x84>
    4a40:	a9408be1 	ldp	x1, x2, [sp, #8]
    4a44:	d2994003 	mov	x3, #0xca00                	// #51712
    4a48:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4a4c:	9b037c20 	mul	x0, x1, x3
    4a50:	9b437c21 	smulh	x1, x1, x3
    4a54:	ab020000 	adds	x0, x0, x2
    4a58:	937ffc42 	asr	x2, x2, #63
    4a5c:	9a020021 	adc	x1, x1, x2
    4a60:	f100001f 	cmp	x0, #0x0
    4a64:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4a68:	b50001c1 	cbnz	x1, 4aa0 <fwp_now_ns+0x90>
    4a6c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4a70:	f947f421 	ldr	x1, [x1, #4072]
    4a74:	f9400fe3 	ldr	x3, [sp, #24]
    4a78:	f9400022 	ldr	x2, [x1]
    4a7c:	eb020063 	subs	x3, x3, x2
    4a80:	d2800002 	mov	x2, #0x0                   	// #0
    4a84:	54000141 	b.ne	4aac <fwp_now_ns+0x9c>  // b.any
    4a88:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4a8c:	9100c3ff 	add	sp, sp, #0x30
    4a90:	d65f03c0 	ret
    4a94:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    4a98:	911c2000 	add	x0, x0, #0x708
    4a9c:	97fffdbd 	bl	4190 <fwp_trap>
    4aa0:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    4aa4:	911ca000 	add	x0, x0, #0x728
    4aa8:	97fffdba 	bl	4190 <fwp_trap>
    4aac:	97fff799 	bl	2910 <__stack_chk_fail@plt>

0000000000004ab0 <fwp_poll_events>:
    4ab0:	d10103ff 	sub	sp, sp, #0x40
    4ab4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4ab8:	f947f400 	ldr	x0, [x0, #4072]
    4abc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4ac0:	910083fd 	add	x29, sp, #0x20
    4ac4:	f9001bf3 	str	x19, [sp, #48]
    4ac8:	900000f3 	adrp	x19, 20000 <__data_start>
    4acc:	f9400001 	ldr	x1, [x0]
    4ad0:	f9000fe1 	str	x1, [sp, #24]
    4ad4:	d2800001 	mov	x1, #0x0                   	// #0
    4ad8:	97ffffce 	bl	4a10 <fwp_now_ns>
    4adc:	9101c261 	add	x1, x19, #0x70
    4ae0:	f9406c21 	ldr	x1, [x1, #216]
    4ae4:	b4000e01 	cbz	x1, 4ca4 <fwp_poll_events+0x1f4>
    4ae8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4aec:	14000005 	b	4b00 <fwp_poll_events+0x50>
    4af0:	f9408821 	ldr	x1, [x1, #272]
    4af4:	eb03005f 	cmp	x2, x3
    4af8:	9a83d042 	csel	x2, x2, x3, le
    4afc:	b40000c1 	cbz	x1, 4b14 <fwp_poll_events+0x64>
    4b00:	f9403423 	ldr	x3, [x1, #104]
    4b04:	b6ffff62 	tbz	x2, #63, 4af0 <fwp_poll_events+0x40>
    4b08:	f9408821 	ldr	x1, [x1, #272]
    4b0c:	aa0303e2 	mov	x2, x3
    4b10:	b5ffff81 	cbnz	x1, 4b00 <fwp_poll_events+0x50>
    4b14:	b7f80c82 	tbnz	x2, #63, 4ca4 <fwp_poll_events+0x1f4>
    4b18:	cb000042 	sub	x2, x2, x0
    4b1c:	f100005f 	cmp	x2, #0x0
    4b20:	540003ad 	b.le	4b94 <fwp_poll_events+0xe4>
    4b24:	d2869b60 	mov	x0, #0x34db                	// #13531
    4b28:	d2884804 	mov	x4, #0x4240                	// #16960
    4b2c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4b30:	f2a001e4 	movk	x4, #0xf, lsl #16
    4b34:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4b38:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4b3c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4b40:	9b407c40 	smulh	x0, x2, x0
    4b44:	9352fc00 	asr	x0, x0, #18
    4b48:	cb82fc00 	sub	x0, x0, x2, asr #63
    4b4c:	9b048802 	msub	x2, x0, x4, x2
    4b50:	f100005f 	cmp	x2, #0x0
    4b54:	9a800400 	cinc	x0, x0, ne	// ne = any
    4b58:	eb01001f 	cmp	x0, x1
    4b5c:	5400098c 	b.gt	4c8c <fwp_poll_events+0x1dc>
    4b60:	340001a0 	cbz	w0, 4b94 <fwp_poll_events+0xe4>
    4b64:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4b68:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4b6c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4b70:	9ba17c01 	umull	x1, w0, w1
    4b74:	d366fc23 	lsr	x3, x1, #38
    4b78:	aa0303e2 	mov	x2, x3
    4b7c:	1b058063 	msub	w3, w3, w5, w0
    4b80:	9b247c63 	smull	x3, w3, w4
    4b84:	910023e0 	add	x0, sp, #0x8
    4b88:	d2800001 	mov	x1, #0x0                   	// #0
    4b8c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4b90:	97fff794 	bl	29e0 <nanosleep@plt>
    4b94:	97ffff9f 	bl	4a10 <fwp_now_ns>
    4b98:	9101c268 	add	x8, x19, #0x70
    4b9c:	aa0003e7 	mov	x7, x0
    4ba0:	4f000400 	movi	v0.4s, #0x0
    4ba4:	52800029 	mov	w9, #0x1                   	// #1
    4ba8:	f9406d06 	ldr	x6, [x8, #216]
    4bac:	d503201f 	nop
    4bb0:	b40003e6 	cbz	x6, 4c2c <fwp_poll_events+0x17c>
    4bb4:	f94034c1 	ldr	x1, [x6, #104]
    4bb8:	aa0603e5 	mov	x5, x6
    4bbc:	f94088c6 	ldr	x6, [x6, #272]
    4bc0:	eb07003f 	cmp	x1, x7
    4bc4:	54ffff6c 	b.gt	4bb0 <fwp_poll_events+0x100>
    4bc8:	394154a0 	ldrb	w0, [x5, #85]
    4bcc:	36000120 	tbz	w0, #0, 4bf0 <fwp_poll_events+0x140>
    4bd0:	f94084a0 	ldr	x0, [x5, #264]
    4bd4:	b4000560 	cbz	x0, 4c80 <fwp_poll_events+0x1d0>
    4bd8:	f9008806 	str	x6, [x0, #272]
    4bdc:	b4000046 	cbz	x6, 4be4 <fwp_poll_events+0x134>
    4be0:	f90084c0 	str	x0, [x6, #264]
    4be4:	910800a0 	add	x0, x5, #0x200
    4be8:	390154bf 	strb	wzr, [x5, #85]
    4bec:	3c908000 	stur	q0, [x0, #-248]
    4bf0:	f94030a0 	ldr	x0, [x5, #96]
    4bf4:	390158a9 	strb	w9, [x5, #86]
    4bf8:	f100001f 	cmp	x0, #0x0
    4bfc:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4c00:	540002cd 	b.le	4c58 <fwp_poll_events+0x1a8>
    4c04:	f94028a0 	ldr	x0, [x5, #80]
    4c08:	f2001c1f 	tst	x0, #0xff000000ff
    4c0c:	54fffd21 	b.ne	4bb0 <fwp_poll_events+0x100>  // b.any
    4c10:	f9403d00 	ldr	x0, [x8, #120]
    4c14:	390150a9 	strb	w9, [x5, #84]
    4c18:	f90080bf 	str	xzr, [x5, #256]
    4c1c:	b40002c0 	cbz	x0, 4c74 <fwp_poll_events+0x1c4>
    4c20:	f9003d05 	str	x5, [x8, #120]
    4c24:	f9008005 	str	x5, [x0, #256]
    4c28:	b5fffc66 	cbnz	x6, 4bb4 <fwp_poll_events+0x104>
    4c2c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4c30:	f947f400 	ldr	x0, [x0, #4072]
    4c34:	f9400fe2 	ldr	x2, [sp, #24]
    4c38:	f9400001 	ldr	x1, [x0]
    4c3c:	eb010042 	subs	x2, x2, x1
    4c40:	d2800001 	mov	x1, #0x0                   	// #0
    4c44:	540002e1 	b.ne	4ca0 <fwp_poll_events+0x1f0>  // b.any
    4c48:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4c4c:	f9401bf3 	ldr	x19, [sp, #48]
    4c50:	910103ff 	add	sp, sp, #0x40
    4c54:	d65f03c0 	ret
    4c58:	394144a0 	ldrb	w0, [x5, #81]
    4c5c:	3707fd40 	tbnz	w0, #0, 4c04 <fwp_poll_events+0x154>
    4c60:	394140a0 	ldrb	w0, [x5, #80]
    4c64:	3707fd00 	tbnz	w0, #0, 4c04 <fwp_poll_events+0x154>
    4c68:	aa0503e0 	mov	x0, x5
    4c6c:	97fffac1 	bl	3770 <fwp_cancel_tree.part.0>
    4c70:	17ffffe5 	b	4c04 <fwp_poll_events+0x154>
    4c74:	f9003d05 	str	x5, [x8, #120]
    4c78:	f9004105 	str	x5, [x8, #128]
    4c7c:	17ffffeb 	b	4c28 <fwp_poll_events+0x178>
    4c80:	9101c261 	add	x1, x19, #0x70
    4c84:	f9006c26 	str	x6, [x1, #216]
    4c88:	17ffffd5 	b	4bdc <fwp_poll_events+0x12c>
    4c8c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4c90:	d2989362 	mov	x2, #0xc49b                	// #50331
    4c94:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4c98:	f2a00402 	movk	x2, #0x20, lsl #16
    4c9c:	17ffffba 	b	4b84 <fwp_poll_events+0xd4>
    4ca0:	97fff71c 	bl	2910 <__stack_chk_fail@plt>
    4ca4:	97fff8f3 	bl	3070 <fwp_flush>
    4ca8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4cac:	f947e863 	ldr	x3, [x3, #4048]
    4cb0:	d2800562 	mov	x2, #0x2b                  	// #43
    4cb4:	d2800021 	mov	x1, #0x1                   	// #1
    4cb8:	b0000040 	adrp	x0, d000 <__divti3+0x320>
    4cbc:	911d4000 	add	x0, x0, #0x750
    4cc0:	f9400063 	ldr	x3, [x3]
    4cc4:	97fff753 	bl	2a10 <fwrite@plt>
    4cc8:	52800ca0 	mov	w0, #0x65                  	// #101
    4ccc:	97fff6bd 	bl	27c0 <exit@plt>

0000000000004cd0 <fwp_heap_alloc_big>:
    4cd0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4cd4:	910003fd 	mov	x29, sp
    4cd8:	a90153f3 	stp	x19, x20, [sp, #16]
    4cdc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ce0:	a90363f7 	stp	x23, x24, [sp, #48]
    4ce4:	aa0003f7 	mov	x23, x0
    4ce8:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4cec:	a9046bf9 	stp	x25, x26, [sp, #64]
    4cf0:	eb0002ff 	cmp	x23, x0
    4cf4:	540008a8 	b.hi	4e08 <fwp_heap_alloc_big+0x138>  // b.pmore
    4cf8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4cfc:	8b0002f4 	add	x20, x23, x0
    4d00:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xc10>
    4d04:	91174359 	add	x25, x26, #0x5d0
    4d08:	d350fe94 	lsr	x20, x20, #16
    4d0c:	2a0103f5 	mov	w21, w1
    4d10:	aa1403e0 	mov	x0, x20
    4d14:	97fff987 	bl	3330 <fwp_heap_chunks>
    4d18:	f949ff22 	ldr	x2, [x25, #5112]
    4d1c:	8b000813 	add	x19, x0, x0, lsl #2
    4d20:	aa0003f8 	mov	x24, x0
    4d24:	52800043 	mov	w3, #0x2                   	// #2
    4d28:	d37df273 	lsl	x19, x19, #3
    4d2c:	d2800021 	mov	x1, #0x1                   	// #1
    4d30:	8b130040 	add	x0, x2, x19
    4d34:	38336843 	strb	w3, [x2, x19]
    4d38:	39000415 	strb	w21, [x0, #1]
    4d3c:	b9000c14 	str	w20, [x0, #12]
    4d40:	f9000817 	str	x23, [x0, #16]
    4d44:	97fffd57 	bl	42a0 <fwp_rc_prepare_chunk>
    4d48:	f100069f 	cmp	x20, #0x1
    4d4c:	54000289 	b.ls	4d9c <fwp_heap_alloc_big+0xcc>  // b.plast
    4d50:	8b180294 	add	x20, x20, x24
    4d54:	9100a273 	add	x19, x19, #0x28
    4d58:	a90573fb 	stp	x27, x28, [sp, #80]
    4d5c:	5280007b 	mov	w27, #0x3                   	// #3
    4d60:	8b140a94 	add	x20, x20, x20, lsl #2
    4d64:	2a1803fc 	mov	w28, w24
    4d68:	9adb2296 	lsl	x22, x20, x27
    4d6c:	d503201f 	nop
    4d70:	f949ff35 	ldr	x21, [x25, #5112]
    4d74:	d2800001 	mov	x1, #0x0                   	// #0
    4d78:	8b1302b4 	add	x20, x21, x19
    4d7c:	aa1403e0 	mov	x0, x20
    4d80:	97fffd48 	bl	42a0 <fwp_rc_prepare_chunk>
    4d84:	38336abb 	strb	w27, [x21, x19]
    4d88:	9100a273 	add	x19, x19, #0x28
    4d8c:	b9000e9c 	str	w28, [x20, #12]
    4d90:	eb1302df 	cmp	x22, x19
    4d94:	54fffee1 	b.ne	4d70 <fwp_heap_alloc_big+0xa0>  // b.any
    4d98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4d9c:	91174353 	add	x19, x26, #0x5d0
    4da0:	aa1703e2 	mov	x2, x23
    4da4:	52800001 	mov	w1, #0x0                   	// #0
    4da8:	f949da60 	ldr	x0, [x19, #5040]
    4dac:	8b184018 	add	x24, x0, x24, lsl #16
    4db0:	aa1803e0 	mov	x0, x24
    4db4:	97fff6cb 	bl	28e0 <memset@plt>
    4db8:	f94a1260 	ldr	x0, [x19, #5152]
    4dbc:	ab170000 	adds	x0, x0, x23
    4dc0:	54000242 	b.cs	4e08 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4dc4:	f94a1661 	ldr	x1, [x19, #5160]
    4dc8:	f90a1260 	str	x0, [x19, #5152]
    4dcc:	eb01001f 	cmp	x0, x1
    4dd0:	54000049 	b.ls	4dd8 <fwp_heap_alloc_big+0x108>  // b.plast
    4dd4:	f90a1660 	str	x0, [x19, #5160]
    4dd8:	9117435a 	add	x26, x26, #0x5d0
    4ddc:	9e6202e0 	scvtf	d0, x23
    4de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4de4:	aa1803e0 	mov	x0, x24
    4de8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4dec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4df0:	1e602820 	fadd	d0, d1, d0
    4df4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4df8:	fd0a1f40 	str	d0, [x26, #5176]
    4dfc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4e00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4e04:	d65f03c0 	ret
    4e08:	a90573fb 	stp	x27, x28, [sp, #80]
    4e0c:	97fff8a9 	bl	30b0 <fwp_heap_oom>

0000000000004e10 <fwp_heap_alloc_slow>:
    4e10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4e14:	910003fd 	mov	x29, sp
    4e18:	a90153f3 	stp	x19, x20, [sp, #16]
    4e1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xc10>
    4e20:	91174262 	add	x2, x19, #0x5d0
    4e24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e28:	aa0003f5 	mov	x21, x0
    4e2c:	2a0103f4 	mov	w20, w1
    4e30:	b953a440 	ldr	w0, [x2, #5028]
    4e34:	34000600 	cbz	w0, 4ef4 <fwp_heap_alloc_slow+0xe4>
    4e38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4e3c:	54000628 	b.hi	4f00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4e40:	91003ea0 	add	x0, x21, #0xf
    4e44:	91174262 	add	x2, x19, #0x5d0
    4e48:	f9001bf7 	str	x23, [sp, #48]
    4e4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4e50:	8b401040 	add	x0, x2, x0, lsr #4
    4e54:	cb34c084 	sub	x4, x4, w20, sxtw
    4e58:	d37ae484 	lsl	x4, x4, #6
    4e5c:	397e8003 	ldrb	w3, [x0, #4000]
    4e60:	910f0060 	add	x0, x3, #0x3c0
    4e64:	aa0303e1 	mov	x1, x3
    4e68:	8b030463 	add	x3, x3, x3, lsl #1
    4e6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4e70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4e74:	2a1703f6 	mov	w22, w23
    4e78:	f8636844 	ldr	x4, [x2, x3]
    4e7c:	b40004e4 	cbz	x4, 4f18 <fwp_heap_alloc_slow+0x108>
    4e80:	f9400080 	ldr	x0, [x4]
    4e84:	aa2003e0 	mvn	x0, x0
    4e88:	f8236840 	str	x0, [x2, x3]
    4e8c:	7100069f 	cmp	w20, #0x1
    4e90:	aa0403e0 	mov	x0, x4
    4e94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4e98:	52800001 	mov	w1, #0x0                   	// #0
    4e9c:	97fff691 	bl	28e0 <memset@plt>
    4ea0:	aa0003e4 	mov	x4, x0
    4ea4:	91174260 	add	x0, x19, #0x5d0
    4ea8:	f94a1001 	ldr	x1, [x0, #5152]
    4eac:	ab160021 	adds	x1, x1, x22
    4eb0:	540005c2 	b.cs	4f68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4eb4:	f94a1402 	ldr	x2, [x0, #5160]
    4eb8:	f90a1001 	str	x1, [x0, #5152]
    4ebc:	eb02003f 	cmp	x1, x2
    4ec0:	54000049 	b.ls	4ec8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4ec4:	f90a1401 	str	x1, [x0, #5160]
    4ec8:	91174273 	add	x19, x19, #0x5d0
    4ecc:	1e6302e1 	ucvtf	d1, w23
    4ed0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ed4:	aa0403e0 	mov	x0, x4
    4ed8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4edc:	f9401bf7 	ldr	x23, [sp, #48]
    4ee0:	1e612800 	fadd	d0, d0, d1
    4ee4:	fd0a1e60 	str	d0, [x19, #5176]
    4ee8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4eec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4ef0:	d65f03c0 	ret
    4ef4:	97fffbbf 	bl	3df0 <fwp_heap_init>
    4ef8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4efc:	54fffa29 	b.ls	4e40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4f00:	2a1403e1 	mov	w1, w20
    4f04:	aa1503e0 	mov	x0, x21
    4f08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4f14:	17ffff6f 	b	4cd0 <fwp_heap_alloc_big>
    4f18:	8b030042 	add	x2, x2, x3
    4f1c:	f9400444 	ldr	x4, [x2, #8]
    4f20:	b4000104 	cbz	x4, 4f40 <fwp_heap_alloc_slow+0x130>
    4f24:	f9400840 	ldr	x0, [x2, #16]
    4f28:	cb040000 	sub	x0, x0, x4
    4f2c:	eb16001f 	cmp	x0, x22
    4f30:	54000083 	b.cc	4f40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4f34:	8b160080 	add	x0, x4, x22
    4f38:	f9000440 	str	x0, [x2, #8]
    4f3c:	17ffffd4 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f40:	52800302 	mov	w2, #0x18                  	// #24
    4f44:	52807804 	mov	w4, #0x3c0                 	// #960
    4f48:	91174260 	add	x0, x19, #0x5d0
    4f4c:	9ba27c23 	umull	x3, w1, w2
    4f50:	2a1403e2 	mov	w2, w20
    4f54:	9b240e84 	smaddl	x4, w20, w4, x3
    4f58:	8b040000 	add	x0, x0, x4
    4f5c:	97fffd19 	bl	43c0 <fwp_heap_refill>
    4f60:	aa0003e4 	mov	x4, x0
    4f64:	17ffffca 	b	4e8c <fwp_heap_alloc_slow+0x7c>
    4f68:	97fff852 	bl	30b0 <fwp_heap_oom>
    4f6c:	d503201f 	nop

0000000000004f70 <fwp_heap_alloc>:
    4f70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4f74:	f140101f 	cmp	x0, #0x4, lsl #12
    4f78:	910003fd 	mov	x29, sp
    4f7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4f80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    4f84:	91174293 	add	x19, x20, #0x5d0
    4f88:	b953a662 	ldr	w2, [x19, #5028]
    4f8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4f90:	54000640 	b.eq	5058 <fwp_heap_alloc+0xe8>  // b.none
    4f94:	91003c03 	add	x3, x0, #0xf
    4f98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4fa0:	8b431263 	add	x3, x19, x3, lsr #4
    4fa4:	cb21c042 	sub	x2, x2, w1, sxtw
    4fa8:	d37ae442 	lsl	x2, x2, #6
    4fac:	397e8063 	ldrb	w3, [x3, #4000]
    4fb0:	910f0064 	add	x4, x3, #0x3c0
    4fb4:	8b030463 	add	x3, x3, x3, lsl #1
    4fb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4fbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4fc0:	2a1603f5 	mov	w21, w22
    4fc4:	f8636a64 	ldr	x4, [x19, x3]
    4fc8:	b4000384 	cbz	x4, 5038 <fwp_heap_alloc+0xc8>
    4fcc:	f9400085 	ldr	x5, [x4]
    4fd0:	7100043f 	cmp	w1, #0x1
    4fd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4fd8:	aa0403e0 	mov	x0, x4
    4fdc:	aa2503e5 	mvn	x5, x5
    4fe0:	52800001 	mov	w1, #0x0                   	// #0
    4fe4:	f8236a65 	str	x5, [x19, x3]
    4fe8:	97fff63e 	bl	28e0 <memset@plt>
    4fec:	aa0003e4 	mov	x4, x0
    4ff0:	f94a1260 	ldr	x0, [x19, #5152]
    4ff4:	ab150000 	adds	x0, x0, x21
    4ff8:	54000442 	b.cs	5080 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4ffc:	f94a1661 	ldr	x1, [x19, #5160]
    5000:	f90a1260 	str	x0, [x19, #5152]
    5004:	eb01001f 	cmp	x0, x1
    5008:	54000049 	b.ls	5010 <fwp_heap_alloc+0xa0>  // b.plast
    500c:	f90a1660 	str	x0, [x19, #5160]
    5010:	91174294 	add	x20, x20, #0x5d0
    5014:	1e6302c1 	ucvtf	d1, w22
    5018:	a9425bf5 	ldp	x21, x22, [sp, #32]
    501c:	aa0403e0 	mov	x0, x4
    5020:	fd4a1e80 	ldr	d0, [x20, #5176]
    5024:	1e612800 	fadd	d0, d0, d1
    5028:	fd0a1e80 	str	d0, [x20, #5176]
    502c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5030:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5034:	d65f03c0 	ret
    5038:	8b030263 	add	x3, x19, x3
    503c:	f9400464 	ldr	x4, [x3, #8]
    5040:	b40000a4 	cbz	x4, 5054 <fwp_heap_alloc+0xe4>
    5044:	f9400862 	ldr	x2, [x3, #16]
    5048:	cb040042 	sub	x2, x2, x4
    504c:	eb15005f 	cmp	x2, x21
    5050:	540000a2 	b.cs	5064 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    5054:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5058:	a94153f3 	ldp	x19, x20, [sp, #16]
    505c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5060:	17ffff6c 	b	4e10 <fwp_heap_alloc_slow>
    5064:	7100043f 	cmp	w1, #0x1
    5068:	8b150085 	add	x5, x4, x21
    506c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    5070:	52800001 	mov	w1, #0x0                   	// #0
    5074:	aa0403e0 	mov	x0, x4
    5078:	f9000465 	str	x5, [x3, #8]
    507c:	17ffffdb 	b	4fe8 <fwp_heap_alloc+0x78>
    5080:	97fff80c 	bl	30b0 <fwp_heap_oom>

0000000000005084 <fwp_data.part.0.constprop.0>:
    5084:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5088:	910003fd 	mov	x29, sp
    508c:	a90153f3 	stp	x19, x20, [sp, #16]
    5090:	90000174 	adrp	x20, 31000 <fwp_root_context+0xc10>
    5094:	91174283 	add	x3, x20, #0x5d0
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	aa0103f5 	mov	x21, x1
    50a0:	b953a461 	ldr	w1, [x3, #5028]
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	2a0003f8 	mov	w24, w0
    50ac:	34000701 	cbz	w1, 518c <fwp_data.part.0.constprop.0+0x108>
    50b0:	397e8862 	ldrb	w2, [x3, #4002]
    50b4:	910f0040 	add	x0, x2, #0x3c0
    50b8:	8b020442 	add	x2, x2, x2, lsl #1
    50bc:	d37df042 	lsl	x2, x2, #3
    50c0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    50c4:	2a1703f6 	mov	w22, w23
    50c8:	f8626873 	ldr	x19, [x3, x2]
    50cc:	b40004d3 	cbz	x19, 5164 <fwp_data.part.0.constprop.0+0xe0>
    50d0:	f9400260 	ldr	x0, [x19]
    50d4:	aa2003e0 	mvn	x0, x0
    50d8:	f8226860 	str	x0, [x3, x2]
    50dc:	f10062df 	cmp	x22, #0x18
    50e0:	540000e9 	b.ls	50fc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    50e4:	d10066c2 	sub	x2, x22, #0x19
    50e8:	91006260 	add	x0, x19, #0x18
    50ec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    50f0:	52800001 	mov	w1, #0x0                   	// #0
    50f4:	91002042 	add	x2, x2, #0x8
    50f8:	97fff5fa 	bl	28e0 <memset@plt>
    50fc:	91174282 	add	x2, x20, #0x5d0
    5100:	f94a1041 	ldr	x1, [x2, #5152]
    5104:	ab160021 	adds	x1, x1, x22
    5108:	540004c2 	b.cs	51a0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    510c:	f94a1440 	ldr	x0, [x2, #5160]
    5110:	f90a1041 	str	x1, [x2, #5152]
    5114:	eb00003f 	cmp	x1, x0
    5118:	54000049 	b.ls	5120 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    511c:	f90a1441 	str	x1, [x2, #5160]
    5120:	91174294 	add	x20, x20, #0x5d0
    5124:	1e6302e1 	ucvtf	d1, w23
    5128:	fd4a1e80 	ldr	d0, [x20, #5176]
    512c:	1e612800 	fadd	d0, d0, d1
    5130:	fd0a1e80 	str	d0, [x20, #5176]
    5134:	52800041 	mov	w1, #0x2                   	// #2
    5138:	29000678 	stp	w24, w1, [x19]
    513c:	aa1303e0 	mov	x0, x19
    5140:	f94002a1 	ldr	x1, [x21]
    5144:	f9000661 	str	x1, [x19, #8]
    5148:	f94006a1 	ldr	x1, [x21, #8]
    514c:	f9000a61 	str	x1, [x19, #16]
    5150:	a94153f3 	ldp	x19, x20, [sp, #16]
    5154:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5158:	a94363f7 	ldp	x23, x24, [sp, #48]
    515c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5160:	d65f03c0 	ret
    5164:	8b020063 	add	x3, x3, x2
    5168:	f9400473 	ldr	x19, [x3, #8]
    516c:	b4000113 	cbz	x19, 518c <fwp_data.part.0.constprop.0+0x108>
    5170:	f9400860 	ldr	x0, [x3, #16]
    5174:	cb130000 	sub	x0, x0, x19
    5178:	eb0002df 	cmp	x22, x0
    517c:	54000088 	b.hi	518c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    5180:	8b160260 	add	x0, x19, x22
    5184:	f9000460 	str	x0, [x3, #8]
    5188:	17ffffd5 	b	50dc <fwp_data.part.0.constprop.0+0x58>
    518c:	52800001 	mov	w1, #0x0                   	// #0
    5190:	d2800300 	mov	x0, #0x18                  	// #24
    5194:	97ffff77 	bl	4f70 <fwp_heap_alloc>
    5198:	aa0003f3 	mov	x19, x0
    519c:	17ffffe6 	b	5134 <fwp_data.part.0.constprop.0+0xb0>
    51a0:	97fff7c4 	bl	30b0 <fwp_heap_oom>

00000000000051a4 <fwp_tape_reserve>:
    51a4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    51a8:	910003fd 	mov	x29, sp
    51ac:	a90153f3 	stp	x19, x20, [sp, #16]
    51b0:	aa0003f3 	mov	x19, x0
    51b4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    51b8:	eb00003f 	cmp	x1, x0
    51bc:	54000868 	b.hi	52c8 <fwp_tape_reserve+0x124>  // b.pmore
    51c0:	f9400e74 	ldr	x20, [x19, #24]
    51c4:	eb01029f 	cmp	x20, x1
    51c8:	5400076a 	b.ge	52b4 <fwp_tape_reserve+0x110>  // b.tcont
    51cc:	f100029f 	cmp	x20, #0x0
    51d0:	d2800802 	mov	x2, #0x40                  	// #64
    51d4:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    51d8:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    51dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    51e0:	a90363f7 	stp	x23, x24, [sp, #48]
    51e4:	eb01029f 	cmp	x20, x1
    51e8:	5400008a 	b.ge	51f8 <fwp_tape_reserve+0x54>  // b.tcont
    51ec:	eb00029f 	cmp	x20, x0
    51f0:	5400068d 	b.le	52c0 <fwp_tape_reserve+0x11c>
    51f4:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    51f8:	a940d662 	ldp	x2, x21, [x19, #8]
    51fc:	d37df297 	lsl	x23, x20, #3
    5200:	f9401260 	ldr	x0, [x19, #32]
    5204:	aa1703e1 	mov	x1, x23
    5208:	f9403276 	ldr	x22, [x19, #96]
    520c:	cb0202b5 	sub	x21, x21, x2
    5210:	97fff5bc 	bl	2900 <realloc@plt>
    5214:	b4000b00 	cbz	x0, 5374 <fwp_tape_reserve+0x1d0>
    5218:	f9400e61 	ldr	x1, [x19, #24]
    521c:	8b010801 	add	x1, x0, x1, lsl #2
    5220:	a9020660 	stp	x0, x1, [x19, #32]
    5224:	b40008b6 	cbz	x22, 5338 <fwp_tape_reserve+0x194>
    5228:	f94032d7 	ldr	x23, [x22, #96]
    522c:	eb17029f 	cmp	x20, x23
    5230:	5400034d 	b.le	5298 <fwp_tape_reserve+0xf4>
    5234:	a9046bf9 	stp	x25, x26, [sp, #64]
    5238:	d37cee9a 	lsl	x26, x20, #4
    523c:	aa1a03e0 	mov	x0, x26
    5240:	f94022d9 	ldr	x25, [x22, #64]
    5244:	52800041 	mov	w1, #0x2                   	// #2
    5248:	97ffff4a 	bl	4f70 <fwp_heap_alloc>
    524c:	aa0003f8 	mov	x24, x0
    5250:	b4000119 	cbz	x25, 5270 <fwp_tape_reserve+0xcc>
    5254:	d37ceef7 	lsl	x23, x23, #4
    5258:	aa1903e1 	mov	x1, x25
    525c:	eb1a02ff 	cmp	x23, x26
    5260:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    5264:	97fff53f 	bl	2760 <memcpy@plt>
    5268:	aa1903e0 	mov	x0, x25
    526c:	97fffc85 	bl	4480 <fwp_mem_free>
    5270:	f94032c0 	ldr	x0, [x22, #96]
    5274:	52800001 	mov	w1, #0x0                   	// #0
    5278:	cb000282 	sub	x2, x20, x0
    527c:	8b001300 	add	x0, x24, x0, lsl #4
    5280:	d37cec42 	lsl	x2, x2, #4
    5284:	97fff597 	bl	28e0 <memset@plt>
    5288:	f9401260 	ldr	x0, [x19, #32]
    528c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5290:	f90022d8 	str	x24, [x22, #64]
    5294:	f90032d4 	str	x20, [x22, #96]
    5298:	d37ef696 	lsl	x22, x20, #2
    529c:	b5000375 	cbnz	x21, 5308 <fwp_tape_reserve+0x164>
    52a0:	a94363f7 	ldp	x23, x24, [sp, #48]
    52a4:	8b160000 	add	x0, x0, x22
    52a8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    52ac:	f9000e74 	str	x20, [x19, #24]
    52b0:	f9001660 	str	x0, [x19, #40]
    52b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    52b8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    52bc:	d65f03c0 	ret
    52c0:	d37ffa94 	lsl	x20, x20, #1
    52c4:	17ffffc8 	b	51e4 <fwp_tape_reserve+0x40>
    52c8:	90000040 	adrp	x0, d000 <__divti3+0x320>
    52cc:	911ea000 	add	x0, x0, #0x7a8
    52d0:	a9025bf5 	stp	x21, x22, [sp, #32]
    52d4:	a90363f7 	stp	x23, x24, [sp, #48]
    52d8:	a9046bf9 	stp	x25, x26, [sp, #64]
    52dc:	97fffbad 	bl	4190 <fwp_trap>
    52e0:	eb1602ff 	cmp	x23, x22
    52e4:	aa0403e0 	mov	x0, x4
    52e8:	9a9622e3 	csel	x3, x23, x22, cs	// cs = hs, nlast
    52ec:	d37df2a2 	lsl	x2, x21, #3
    52f0:	cb170063 	sub	x3, x3, x23
    52f4:	97fff5ef 	bl	2ab0 <__memmove_chk@plt>
    52f8:	f9401a61 	ldr	x1, [x19, #48]
    52fc:	f9401260 	ldr	x0, [x19, #32]
    5300:	8b170021 	add	x1, x1, x23
    5304:	f9001e61 	str	x1, [x19, #56]
    5308:	f9401661 	ldr	x1, [x19, #40]
    530c:	d37ef696 	lsl	x22, x20, #2
    5310:	d37ef6a2 	lsl	x2, x21, #2
    5314:	8b160000 	add	x0, x0, x22
    5318:	97fff51a 	bl	2780 <memmove@plt>
    531c:	f9401260 	ldr	x0, [x19, #32]
    5320:	a94363f7 	ldp	x23, x24, [sp, #48]
    5324:	8b160000 	add	x0, x0, x22
    5328:	a9425bf5 	ldp	x21, x22, [sp, #32]
    532c:	f9000e74 	str	x20, [x19, #24]
    5330:	f9001660 	str	x0, [x19, #40]
    5334:	17ffffe0 	b	52b4 <fwp_tape_reserve+0x110>
    5338:	f9401a60 	ldr	x0, [x19, #48]
    533c:	d37cee96 	lsl	x22, x20, #4
    5340:	aa1603e1 	mov	x1, x22
    5344:	97fff56f 	bl	2900 <realloc@plt>
    5348:	b4000160 	cbz	x0, 5374 <fwp_tape_reserve+0x1d0>
    534c:	f9400e62 	ldr	x2, [x19, #24]
    5350:	f9001a60 	str	x0, [x19, #48]
    5354:	8b170004 	add	x4, x0, x23
    5358:	8b020c01 	add	x1, x0, x2, lsl #3
    535c:	f9001e61 	str	x1, [x19, #56]
    5360:	b5fffc15 	cbnz	x21, 52e0 <fwp_tape_reserve+0x13c>
    5364:	f9401260 	ldr	x0, [x19, #32]
    5368:	d37ef696 	lsl	x22, x20, #2
    536c:	f9001e64 	str	x4, [x19, #56]
    5370:	17ffffcc 	b	52a0 <fwp_tape_reserve+0xfc>
    5374:	aa1303e0 	mov	x0, x19
    5378:	a9046bf9 	stp	x25, x26, [sp, #64]
    537c:	97fff725 	bl	3010 <fwp_tape_unlink_scope>
    5380:	f9401260 	ldr	x0, [x19, #32]
    5384:	97fff593 	bl	29d0 <free@plt>
    5388:	f9401a60 	ldr	x0, [x19, #48]
    538c:	97fff591 	bl	29d0 <free@plt>
    5390:	f9402260 	ldr	x0, [x19, #64]
    5394:	97fff58f 	bl	29d0 <free@plt>
    5398:	f9000e7f 	str	xzr, [x19, #24]
    539c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    53a0:	f947e821 	ldr	x1, [x1, #4048]
    53a4:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    53a8:	d2800262 	mov	x2, #0x13                  	// #19
    53ac:	4f000400 	movi	v0.4s, #0x0
    53b0:	90000040 	adrp	x0, d000 <__divti3+0x320>
    53b4:	f9400023 	ldr	x3, [x1]
    53b8:	b900067f 	str	wzr, [x19, #4]
    53bc:	d2800021 	mov	x1, #0x1                   	// #1
    53c0:	91102000 	add	x0, x0, #0x408
    53c4:	3c808260 	stur	q0, [x19, #8]
    53c8:	ad010260 	stp	q0, q0, [x19, #32]
    53cc:	97fff591 	bl	2a10 <fwrite@plt>
    53d0:	d2800000 	mov	x0, #0x0                   	// #0
    53d4:	97fff59b 	bl	2a40 <fflush@plt>
    53d8:	52800cc0 	mov	w0, #0x66                  	// #102
    53dc:	97fff5a9 	bl	2a80 <_Exit@plt>

00000000000053e0 <f141.constprop.0>:
    53e0:	f100001f 	cmp	x0, #0x0
    53e4:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    53e8:	5400094b 	b.lt	5510 <f141.constprop.0+0x130>  // b.tstop
    53ec:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    53f0:	aa0003e2 	mov	x2, x0
    53f4:	910003fd 	mov	x29, sp
    53f8:	a90153f3 	stp	x19, x20, [sp, #16]
    53fc:	aa0003f4 	mov	x20, x0
    5400:	aa010000 	orr	x0, x0, x1
    5404:	a9025bf5 	stp	x21, x22, [sp, #32]
    5408:	aa0103f6 	mov	x22, x1
    540c:	f9001bf7 	str	x23, [sp, #48]
    5410:	fd001fe8 	str	d8, [sp, #56]
    5414:	b7f80180 	tbnz	x0, #63, 5444 <f141.constprop.0+0x64>
    5418:	9360fc20 	asr	x0, x1, #32
    541c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    5420:	eb82801f 	cmp	x0, x2, asr #32
    5424:	540007a1 	b.ne	5518 <f141.constprop.0+0x138>  // b.any
    5428:	97fffd5e 	bl	49a0 <fwp_tape_of>
    542c:	aa0003f3 	mov	x19, x0
    5430:	f9403000 	ldr	x0, [x0, #96]
    5434:	b40001e0 	cbz	x0, 5470 <f141.constprop.0+0x90>
    5438:	90000040 	adrp	x0, d000 <__divti3+0x320>
    543c:	91204000 	add	x0, x0, #0x810
    5440:	97fffb54 	bl	4190 <fwp_trap>
    5444:	9360fc40 	asr	x0, x2, #32
    5448:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    544c:	b6fffee2 	tbz	x2, #63, 5428 <f141.constprop.0+0x48>
    5450:	2f00e408 	movi	d8, #0x0
    5454:	9360fc20 	asr	x0, x1, #32
    5458:	aa0103f4 	mov	x20, x1
    545c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5460:	97fffd50 	bl	49a0 <fwp_tape_of>
    5464:	aa0003f3 	mov	x19, x0
    5468:	f9403000 	ldr	x0, [x0, #96]
    546c:	b5fffe60 	cbnz	x0, 5438 <f141.constprop.0+0x58>
    5470:	f9400a77 	ldr	x23, [x19, #16]
    5474:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5478:	eb0002ff 	cmp	x23, x0
    547c:	5400044c 	b.gt	5504 <f141.constprop.0+0x124>
    5480:	eb3442ff 	cmp	x23, w20, uxtw
    5484:	5400008d 	b.le	5494 <f141.constprop.0+0xb4>
    5488:	b7f800d6 	tbnz	x22, #63, 54a0 <f141.constprop.0+0xc0>
    548c:	eb3642ff 	cmp	x23, w22, uxtw
    5490:	5400008c 	b.gt	54a0 <f141.constprop.0+0xc0>
    5494:	90000040 	adrp	x0, d000 <__divti3+0x320>
    5498:	91210000 	add	x0, x0, #0x840
    549c:	97fffb3d 	bl	4190 <fwp_trap>
    54a0:	f9400675 	ldr	x21, [x19, #8]
    54a4:	aa1303e0 	mov	x0, x19
    54a8:	cb1502f5 	sub	x21, x23, x21
    54ac:	910006a1 	add	x1, x21, #0x1
    54b0:	97ffff3d 	bl	51a4 <fwp_tape_reserve>
    54b4:	a9420262 	ldp	x2, x0, [x19, #32]
    54b8:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    54bc:	f9401a61 	ldr	x1, [x19, #48]
    54c0:	b8357854 	str	w20, [x2, x21, lsl #2]
    54c4:	f9401e62 	ldr	x2, [x19, #56]
    54c8:	f10002df 	cmp	x22, #0x0
    54cc:	fc357820 	str	d0, [x1, x21, lsl #3]
    54d0:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    54d4:	b8357816 	str	w22, [x0, x21, lsl #2]
    54d8:	92607e80 	and	x0, x20, #0xffffffff00000000
    54dc:	910006e1 	add	x1, x23, #0x1
    54e0:	aa170000 	orr	x0, x0, x23
    54e4:	fc357848 	str	d8, [x2, x21, lsl #3]
    54e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    54ec:	f9401bf7 	ldr	x23, [sp, #48]
    54f0:	fd401fe8 	ldr	d8, [sp, #56]
    54f4:	f9000a61 	str	x1, [x19, #16]
    54f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    54fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5500:	d65f03c0 	ret
    5504:	90000040 	adrp	x0, d000 <__divti3+0x320>
    5508:	911ea000 	add	x0, x0, #0x7a8
    550c:	97fffb21 	bl	4190 <fwp_trap>
    5510:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5514:	d65f03c0 	ret
    5518:	90000040 	adrp	x0, d000 <__divti3+0x320>
    551c:	911f2000 	add	x0, x0, #0x7c8
    5520:	97fffb1c 	bl	4190 <fwp_trap>

0000000000005524 <w120>:
    5524:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5528:	910003fd 	mov	x29, sp
    552c:	a90153f3 	stp	x19, x20, [sp, #16]
    5530:	a9025bf5 	stp	x21, x22, [sp, #32]
    5534:	aa0003f5 	mov	x21, x0
    5538:	a90363f7 	stp	x23, x24, [sp, #48]
    553c:	aa0103f7 	mov	x23, x1
    5540:	a9046bf9 	stp	x25, x26, [sp, #64]
    5544:	f9002bfb 	str	x27, [sp, #80]
    5548:	6d0627e8 	stp	d8, d9, [sp, #96]
    554c:	1e604028 	fmov	d8, d1
    5550:	1e600809 	fmul	d9, d0, d0
    5554:	6d072fea 	stp	d10, d11, [sp, #112]
    5558:	1e60400b 	fmov	d11, d0
    555c:	b7f81c80 	tbnz	x0, #63, 58ec <w120+0x3c8>
    5560:	9360fc19 	asr	x25, x0, #32
    5564:	aa1903e0 	mov	x0, x25
    5568:	97fffd0e 	bl	49a0 <fwp_tape_of>
    556c:	f9403001 	ldr	x1, [x0, #96]
    5570:	aa0003f3 	mov	x19, x0
    5574:	b4000081 	cbz	x1, 5584 <w120+0x60>
    5578:	90000040 	adrp	x0, d000 <__divti3+0x320>
    557c:	91204000 	add	x0, x0, #0x810
    5580:	97fffb04 	bl	4190 <fwp_trap>
    5584:	f9400818 	ldr	x24, [x0, #16]
    5588:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    558c:	eb01031f 	cmp	x24, x1
    5590:	54001a8c 	b.gt	58e0 <w120+0x3bc>
    5594:	eb35431f 	cmp	x24, w21, uxtw
    5598:	540019ed 	b.le	58d4 <w120+0x3b0>
    559c:	f9400416 	ldr	x22, [x0, #8]
    55a0:	92607eb4 	and	x20, x21, #0xffffffff00000000
    55a4:	aa180294 	orr	x20, x20, x24
    55a8:	cb160316 	sub	x22, x24, x22
    55ac:	910006c1 	add	x1, x22, #0x1
    55b0:	97fffefd 	bl	51a4 <fwp_tape_reserve>
    55b4:	a9420a61 	ldp	x1, x2, [x19, #32]
    55b8:	91000700 	add	x0, x24, #0x1
    55bc:	f9401a63 	ldr	x3, [x19, #48]
    55c0:	b8367835 	str	w21, [x1, x22, lsl #2]
    55c4:	f9401e61 	ldr	x1, [x19, #56]
    55c8:	1e693908 	fsub	d8, d8, d9
    55cc:	fc36786b 	str	d11, [x3, x22, lsl #3]
    55d0:	9360fe9a 	asr	x26, x20, #32
    55d4:	b8367855 	str	w21, [x2, x22, lsl #2]
    55d8:	fc36782b 	str	d11, [x1, x22, lsl #3]
    55dc:	f9000a60 	str	x0, [x19, #16]
    55e0:	b7f80077 	tbnz	x23, #63, 55ec <w120+0xc8>
    55e4:	eb97835f 	cmp	x26, x23, asr #32
    55e8:	540019a1 	b.ne	591c <w120+0x3f8>  // b.any
    55ec:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    55f0:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    55f4:	eb19035f 	cmp	x26, x25
    55f8:	540000c0 	b.eq	5610 <w120+0xec>  // b.none
    55fc:	aa1a03e0 	mov	x0, x26
    5600:	97fffce8 	bl	49a0 <fwp_tape_of>
    5604:	aa0003f3 	mov	x19, x0
    5608:	f9403000 	ldr	x0, [x0, #96]
    560c:	b5fffb60 	cbnz	x0, 5578 <w120+0x54>
    5610:	f9400a79 	ldr	x25, [x19, #16]
    5614:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5618:	eb00033f 	cmp	x25, x0
    561c:	5400162c 	b.gt	58e0 <w120+0x3bc>
    5620:	eb34433f 	cmp	x25, w20, uxtw
    5624:	5400158d 	b.le	58d4 <w120+0x3b0>
    5628:	b7f80077 	tbnz	x23, #63, 5634 <w120+0x110>
    562c:	eb37433f 	cmp	x25, w23, uxtw
    5630:	5400152d 	b.le	58d4 <w120+0x3b0>
    5634:	f9400676 	ldr	x22, [x19, #8]
    5638:	aa1303e0 	mov	x0, x19
    563c:	cb160336 	sub	x22, x25, x22
    5640:	910006c1 	add	x1, x22, #0x1
    5644:	97fffed8 	bl	51a4 <fwp_tape_reserve>
    5648:	a9420e62 	ldp	x2, x3, [x19, #32]
    564c:	f10002ff 	cmp	x23, #0x0
    5650:	f9401a61 	ldr	x1, [x19, #48]
    5654:	b8367854 	str	w20, [x2, x22, lsl #2]
    5658:	f9401e62 	ldr	x2, [x19, #56]
    565c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5660:	fc367829 	str	d9, [x1, x22, lsl #3]
    5664:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    5668:	b8367861 	str	w1, [x3, x22, lsl #2]
    566c:	91000737 	add	x23, x25, #0x1
    5670:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5674:	92607e94 	and	x20, x20, #0xffffffff00000000
    5678:	fc36784a 	str	d10, [x2, x22, lsl #3]
    567c:	aa190294 	orr	x20, x20, x25
    5680:	f9000a77 	str	x23, [x19, #16]
    5684:	1e6b3929 	fsub	d9, d9, d11
    5688:	b7f81675 	tbnz	x21, #63, 5954 <w120+0x430>
    568c:	9360febb 	asr	x27, x21, #32
    5690:	eb1a037f 	cmp	x27, x26
    5694:	540000e0 	b.eq	56b0 <w120+0x18c>  // b.none
    5698:	aa1b03e0 	mov	x0, x27
    569c:	97fffcc1 	bl	49a0 <fwp_tape_of>
    56a0:	aa0003f3 	mov	x19, x0
    56a4:	f9403000 	ldr	x0, [x0, #96]
    56a8:	b5fff680 	cbnz	x0, 5578 <w120+0x54>
    56ac:	f9400a77 	ldr	x23, [x19, #16]
    56b0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    56b4:	eb0002ff 	cmp	x23, x0
    56b8:	5400114c 	b.gt	58e0 <w120+0x3bc>
    56bc:	eb3542ff 	cmp	x23, w21, uxtw
    56c0:	540010ad 	b.le	58d4 <w120+0x3b0>
    56c4:	f9400676 	ldr	x22, [x19, #8]
    56c8:	aa1303e0 	mov	x0, x19
    56cc:	cb1602f6 	sub	x22, x23, x22
    56d0:	910006c1 	add	x1, x22, #0x1
    56d4:	97fffeb4 	bl	51a4 <fwp_tape_reserve>
    56d8:	a9420261 	ldp	x1, x0, [x19, #32]
    56dc:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    56e0:	f9401a63 	ldr	x3, [x19, #48]
    56e4:	b8367835 	str	w21, [x1, x22, lsl #2]
    56e8:	f9401e61 	ldr	x1, [x19, #56]
    56ec:	12800002 	mov	w2, #0xffffffff            	// #-1
    56f0:	fc367860 	str	d0, [x3, x22, lsl #3]
    56f4:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    56f8:	b8367802 	str	w2, [x0, x22, lsl #2]
    56fc:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5700:	910006e0 	add	x0, x23, #0x1
    5704:	aa1702b7 	orr	x23, x21, x23
    5708:	fc367820 	str	d0, [x1, x22, lsl #3]
    570c:	f9000a60 	str	x0, [x19, #16]
    5710:	9360fe99 	asr	x25, x20, #32
    5714:	1e68090a 	fmul	d10, d8, d8
    5718:	eb1b033f 	cmp	x25, x27
    571c:	540000c0 	b.eq	5734 <w120+0x210>  // b.none
    5720:	aa1903e0 	mov	x0, x25
    5724:	97fffc9f 	bl	49a0 <fwp_tape_of>
    5728:	aa0003f3 	mov	x19, x0
    572c:	f9403000 	ldr	x0, [x0, #96]
    5730:	b5fff240 	cbnz	x0, 5578 <w120+0x54>
    5734:	f9400a75 	ldr	x21, [x19, #16]
    5738:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    573c:	eb0002bf 	cmp	x21, x0
    5740:	54000d0c 	b.gt	58e0 <w120+0x3bc>
    5744:	eb3442bf 	cmp	x21, w20, uxtw
    5748:	54000c6d 	b.le	58d4 <w120+0x3b0>
    574c:	f9400678 	ldr	x24, [x19, #8]
    5750:	aa1303e0 	mov	x0, x19
    5754:	92607e96 	and	x22, x20, #0xffffffff00000000
    5758:	cb1802b8 	sub	x24, x21, x24
    575c:	aa1502d6 	orr	x22, x22, x21
    5760:	91000701 	add	x1, x24, #0x1
    5764:	97fffe90 	bl	51a4 <fwp_tape_reserve>
    5768:	a9420261 	ldp	x1, x0, [x19, #32]
    576c:	f9401a62 	ldr	x2, [x19, #48]
    5770:	b8387834 	str	w20, [x1, x24, lsl #2]
    5774:	f9401e61 	ldr	x1, [x19, #56]
    5778:	fc387848 	str	d8, [x2, x24, lsl #3]
    577c:	b8387814 	str	w20, [x0, x24, lsl #2]
    5780:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5784:	9e670000 	fmov	d0, x0
    5788:	910006b4 	add	x20, x21, #0x1
    578c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5790:	9360fed8 	asr	x24, x22, #32
    5794:	f9000a74 	str	x20, [x19, #16]
    5798:	1e60094a 	fmul	d10, d10, d0
    579c:	eb19031f 	cmp	x24, x25
    57a0:	540000e0 	b.eq	57bc <w120+0x298>  // b.none
    57a4:	aa1803e0 	mov	x0, x24
    57a8:	97fffc7e 	bl	49a0 <fwp_tape_of>
    57ac:	aa0003f3 	mov	x19, x0
    57b0:	f9403000 	ldr	x0, [x0, #96]
    57b4:	b5ffee20 	cbnz	x0, 5578 <w120+0x54>
    57b8:	f9400a74 	ldr	x20, [x19, #16]
    57bc:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    57c0:	eb00029f 	cmp	x20, x0
    57c4:	540008ec 	b.gt	58e0 <w120+0x3bc>
    57c8:	eb36429f 	cmp	x20, w22, uxtw
    57cc:	5400084d 	b.le	58d4 <w120+0x3b0>
    57d0:	f9400675 	ldr	x21, [x19, #8]
    57d4:	aa1303e0 	mov	x0, x19
    57d8:	cb150295 	sub	x21, x20, x21
    57dc:	910006a1 	add	x1, x21, #0x1
    57e0:	97fffe71 	bl	51a4 <fwp_tape_reserve>
    57e4:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    57e8:	9e670000 	fmov	d0, x0
    57ec:	a9420261 	ldp	x1, x0, [x19, #32]
    57f0:	1e690928 	fmul	d8, d9, d9
    57f4:	f9401a62 	ldr	x2, [x19, #48]
    57f8:	b8357836 	str	w22, [x1, x21, lsl #2]
    57fc:	f9401e61 	ldr	x1, [x19, #56]
    5800:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5804:	fc357840 	str	d0, [x2, x21, lsl #3]
    5808:	12800002 	mov	w2, #0xffffffff            	// #-1
    580c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5810:	91000680 	add	x0, x20, #0x1
    5814:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5818:	aa1402d6 	orr	x22, x22, x20
    581c:	f9000a60 	str	x0, [x19, #16]
    5820:	b10006ff 	cmn	x23, #0x1
    5824:	540009e0 	b.eq	5960 <w120+0x43c>  // b.none
    5828:	9360fee0 	asr	x0, x23, #32
    582c:	eb18001f 	cmp	x0, x24
    5830:	540000a0 	b.eq	5844 <w120+0x320>  // b.none
    5834:	97fffc5b 	bl	49a0 <fwp_tape_of>
    5838:	aa0003f3 	mov	x19, x0
    583c:	f9403000 	ldr	x0, [x0, #96]
    5840:	b5ffe9c0 	cbnz	x0, 5578 <w120+0x54>
    5844:	f9400a74 	ldr	x20, [x19, #16]
    5848:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    584c:	eb00029f 	cmp	x20, x0
    5850:	5400048c 	b.gt	58e0 <w120+0x3bc>
    5854:	eb37429f 	cmp	x20, w23, uxtw
    5858:	540003ed 	b.le	58d4 <w120+0x3b0>
    585c:	f9400675 	ldr	x21, [x19, #8]
    5860:	aa1303e0 	mov	x0, x19
    5864:	cb150295 	sub	x21, x20, x21
    5868:	910006a1 	add	x1, x21, #0x1
    586c:	97fffe4e 	bl	51a4 <fwp_tape_reserve>
    5870:	a9420a61 	ldp	x1, x2, [x19, #32]
    5874:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5878:	f9401a63 	ldr	x3, [x19, #48]
    587c:	b8357837 	str	w23, [x1, x21, lsl #2]
    5880:	f9401e61 	ldr	x1, [x19, #56]
    5884:	aa140000 	orr	x0, x0, x20
    5888:	fc357869 	str	d9, [x3, x21, lsl #3]
    588c:	91000694 	add	x20, x20, #0x1
    5890:	b8357857 	str	w23, [x2, x21, lsl #2]
    5894:	fc357829 	str	d9, [x1, x21, lsl #3]
    5898:	f9000a74 	str	x20, [x19, #16]
    589c:	1e6a2908 	fadd	d8, d8, d10
    58a0:	aa1603e1 	mov	x1, x22
    58a4:	97fffecf 	bl	53e0 <f141.constprop.0>
    58a8:	aa0003e1 	mov	x1, x0
    58ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    58b0:	9e660100 	fmov	x0, d8
    58b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    58b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    58bc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    58c0:	f9402bfb 	ldr	x27, [sp, #80]
    58c4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    58c8:	6d472fea 	ldp	d10, d11, [sp, #112]
    58cc:	a8c87bfd 	ldp	x29, x30, [sp], #128
    58d0:	d65f03c0 	ret
    58d4:	90000040 	adrp	x0, d000 <__divti3+0x320>
    58d8:	91210000 	add	x0, x0, #0x840
    58dc:	97fffa2d 	bl	4190 <fwp_trap>
    58e0:	90000040 	adrp	x0, d000 <__divti3+0x320>
    58e4:	911ea000 	add	x0, x0, #0x7a8
    58e8:	97fffa2a 	bl	4190 <fwp_trap>
    58ec:	1e693828 	fsub	d8, d1, d9
    58f0:	b6f801c1 	tbz	x1, #63, 5928 <w120+0x404>
    58f4:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    58f8:	1e68090a 	fmul	d10, d8, d8
    58fc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5900:	9e670000 	fmov	d0, x0
    5904:	1e6b3828 	fsub	d8, d1, d11
    5908:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    590c:	aa1603e0 	mov	x0, x22
    5910:	1e60094a 	fmul	d10, d10, d0
    5914:	1e680908 	fmul	d8, d8, d8
    5918:	17ffffe1 	b	589c <w120+0x378>
    591c:	90000040 	adrp	x0, d000 <__divti3+0x320>
    5920:	911f2000 	add	x0, x0, #0x7c8
    5924:	97fffa1b 	bl	4190 <fwp_trap>
    5928:	2f00e40a 	movi	d10, #0x0
    592c:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5930:	9360fc3a 	asr	x26, x1, #32
    5934:	aa0103f4 	mov	x20, x1
    5938:	aa1a03e0 	mov	x0, x26
    593c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5940:	97fffc18 	bl	49a0 <fwp_tape_of>
    5944:	aa0003f3 	mov	x19, x0
    5948:	f9403000 	ldr	x0, [x0, #96]
    594c:	b5ffe160 	cbnz	x0, 5578 <w120+0x54>
    5950:	17ffff30 	b	5610 <w120+0xec>
    5954:	aa1a03fb 	mov	x27, x26
    5958:	aa0003f7 	mov	x23, x0
    595c:	17ffff6d 	b	5710 <w120+0x1ec>
    5960:	aa1703e0 	mov	x0, x23
    5964:	17ffffce 	b	589c <w120+0x378>
    5968:	d503201f 	nop
    596c:	d503201f 	nop

0000000000005970 <fwp_rc_share>:
    5970:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5974:	91174042 	add	x2, x2, #0x5d0
    5978:	f949d843 	ldr	x3, [x2, #5040]
    597c:	f949ec41 	ldr	x1, [x2, #5080]
    5980:	cb030000 	sub	x0, x0, x3
    5984:	eb01401f 	cmp	x0, x1, lsl #16
    5988:	540003a2 	b.cs	59fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    598c:	d350fc01 	lsr	x1, x0, #16
    5990:	f949fc44 	ldr	x4, [x2, #5112]
    5994:	8b010821 	add	x1, x1, x1, lsl #2
    5998:	d37df021 	lsl	x1, x1, #3
    599c:	8b010083 	add	x3, x4, x1
    59a0:	f9401062 	ldr	x2, [x3, #32]
    59a4:	b40002c2 	cbz	x2, 59fc <fwp_rc_share+0x8c>
    59a8:	38616881 	ldrb	w1, [x4, x1]
    59ac:	7100083f 	cmp	w1, #0x2
    59b0:	54000220 	b.eq	59f4 <fwp_rc_share+0x84>  // b.none
    59b4:	7100043f 	cmp	w1, #0x1
    59b8:	54000221 	b.ne	59fc <fwp_rc_share+0x8c>  // b.any
    59bc:	29430464 	ldp	w4, w1, [x3, #24]
    59c0:	92403c00 	and	x0, x0, #0xffff
    59c4:	9b047c00 	mul	x0, x0, x4
    59c8:	d360fc00 	lsr	x0, x0, #32
    59cc:	eb01001f 	cmp	x0, x1
    59d0:	54000162 	b.cs	59fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    59d4:	8b000042 	add	x2, x2, x0
    59d8:	39400040 	ldrb	w0, [x2]
    59dc:	34000100 	cbz	w0, 59fc <fwp_rc_share+0x8c>
    59e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    59e4:	90000040 	adrp	x0, d000 <__divti3+0x320>
    59e8:	91218000 	add	x0, x0, #0x860
    59ec:	910003fd 	mov	x29, sp
    59f0:	97fff9e8 	bl	4190 <fwp_trap>
    59f4:	72003c1f 	tst	w0, #0xffff
    59f8:	54ffff00 	b.eq	59d8 <fwp_rc_share+0x68>  // b.none
    59fc:	d65f03c0 	ret

0000000000005a00 <fwp_rc_fresh>:
    5a00:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5a04:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5a08:	91174063 	add	x3, x3, #0x5d0
    5a0c:	910003fd 	mov	x29, sp
    5a10:	a90153f3 	stp	x19, x20, [sp, #16]
    5a14:	aa0003f3 	mov	x19, x0
    5a18:	f949d861 	ldr	x1, [x3, #5040]
    5a1c:	f949ec60 	ldr	x0, [x3, #5080]
    5a20:	cb010261 	sub	x1, x19, x1
    5a24:	eb00403f 	cmp	x1, x0, lsl #16
    5a28:	54000322 	b.cs	5a8c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5a2c:	d350fc22 	lsr	x2, x1, #16
    5a30:	f949fc63 	ldr	x3, [x3, #5112]
    5a34:	8b020842 	add	x2, x2, x2, lsl #2
    5a38:	d37df042 	lsl	x2, x2, #3
    5a3c:	8b020060 	add	x0, x3, x2
    5a40:	f9401014 	ldr	x20, [x0, #32]
    5a44:	b4000254 	cbz	x20, 5a8c <fwp_rc_fresh+0x8c>
    5a48:	38626862 	ldrb	w2, [x3, x2]
    5a4c:	7100085f 	cmp	w2, #0x2
    5a50:	54000260 	b.eq	5a9c <fwp_rc_fresh+0x9c>  // b.none
    5a54:	7100045f 	cmp	w2, #0x1
    5a58:	540001a1 	b.ne	5a8c <fwp_rc_fresh+0x8c>  // b.any
    5a5c:	29430002 	ldp	w2, w0, [x0, #24]
    5a60:	92403c21 	and	x1, x1, #0xffff
    5a64:	9b027c21 	mul	x1, x1, x2
    5a68:	d360fc21 	lsr	x1, x1, #32
    5a6c:	eb00003f 	cmp	x1, x0
    5a70:	540000e2 	b.cs	5a8c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5a74:	8b010294 	add	x20, x20, x1
    5a78:	39400280 	ldrb	w0, [x20]
    5a7c:	7103fc1f 	cmp	w0, #0xff
    5a80:	540001a0 	b.eq	5ab4 <fwp_rc_fresh+0xb4>  // b.none
    5a84:	52800020 	mov	w0, #0x1                   	// #1
    5a88:	39000280 	strb	w0, [x20]
    5a8c:	aa1303e0 	mov	x0, x19
    5a90:	a94153f3 	ldp	x19, x20, [sp, #16]
    5a94:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5a98:	d65f03c0 	ret
    5a9c:	72003c3f 	tst	w1, #0xffff
    5aa0:	54fffec0 	b.eq	5a78 <fwp_rc_fresh+0x78>  // b.none
    5aa4:	aa1303e0 	mov	x0, x19
    5aa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5aac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ab0:	d65f03c0 	ret
    5ab4:	aa1403e0 	mov	x0, x20
    5ab8:	97fff9d6 	bl	4210 <fwp_rc_forget_slot.part.0>
    5abc:	17fffff2 	b	5a84 <fwp_rc_fresh+0x84>

0000000000005ac0 <fwp_rc_free_arr>:
    5ac0:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5ac4:	91174063 	add	x3, x3, #0x5d0
    5ac8:	f949d861 	ldr	x1, [x3, #5040]
    5acc:	f949ec62 	ldr	x2, [x3, #5080]
    5ad0:	cb010001 	sub	x1, x0, x1
    5ad4:	eb02403f 	cmp	x1, x2, lsl #16
    5ad8:	54000342 	b.cs	5b40 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5adc:	d350fc22 	lsr	x2, x1, #16
    5ae0:	f949fc65 	ldr	x5, [x3, #5112]
    5ae4:	8b020842 	add	x2, x2, x2, lsl #2
    5ae8:	d37df042 	lsl	x2, x2, #3
    5aec:	8b0200a4 	add	x4, x5, x2
    5af0:	f9401083 	ldr	x3, [x4, #32]
    5af4:	b4000263 	cbz	x3, 5b40 <fwp_rc_free_arr+0x80>
    5af8:	386268a2 	ldrb	w2, [x5, x2]
    5afc:	7100085f 	cmp	w2, #0x2
    5b00:	540001c0 	b.eq	5b38 <fwp_rc_free_arr+0x78>  // b.none
    5b04:	7100045f 	cmp	w2, #0x1
    5b08:	540001c1 	b.ne	5b40 <fwp_rc_free_arr+0x80>  // b.any
    5b0c:	29430885 	ldp	w5, w2, [x4, #24]
    5b10:	92403c21 	and	x1, x1, #0xffff
    5b14:	9b057c21 	mul	x1, x1, x5
    5b18:	d360fc21 	lsr	x1, x1, #32
    5b1c:	eb02003f 	cmp	x1, x2
    5b20:	54000102 	b.cs	5b40 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5b24:	8b010063 	add	x3, x3, x1
    5b28:	39400061 	ldrb	w1, [x3]
    5b2c:	7100043f 	cmp	w1, #0x1
    5b30:	54000081 	b.ne	5b40 <fwp_rc_free_arr+0x80>  // b.any
    5b34:	17fffa53 	b	4480 <fwp_mem_free>
    5b38:	72003c3f 	tst	w1, #0xffff
    5b3c:	54ffff60 	b.eq	5b28 <fwp_rc_free_arr+0x68>  // b.none
    5b40:	d65f03c0 	ret

0000000000005b44 <fwp_rc_dup>:
    5b44:	90000162 	adrp	x2, 31000 <fwp_root_context+0xc10>
    5b48:	91174042 	add	x2, x2, #0x5d0
    5b4c:	f949d841 	ldr	x1, [x2, #5040]
    5b50:	f949ec43 	ldr	x3, [x2, #5080]
    5b54:	cb010001 	sub	x1, x0, x1
    5b58:	eb03403f 	cmp	x1, x3, lsl #16
    5b5c:	54000342 	b.cs	5bc4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5b60:	d350fc20 	lsr	x0, x1, #16
    5b64:	f949fc44 	ldr	x4, [x2, #5112]
    5b68:	8b000800 	add	x0, x0, x0, lsl #2
    5b6c:	d37df002 	lsl	x2, x0, #3
    5b70:	8b020083 	add	x3, x4, x2
    5b74:	f9401060 	ldr	x0, [x3, #32]
    5b78:	b4000260 	cbz	x0, 5bc4 <fwp_rc_dup+0x80>
    5b7c:	38626882 	ldrb	w2, [x4, x2]
    5b80:	7100085f 	cmp	w2, #0x2
    5b84:	54000220 	b.eq	5bc8 <fwp_rc_dup+0x84>  // b.none
    5b88:	7100045f 	cmp	w2, #0x1
    5b8c:	540001c1 	b.ne	5bc4 <fwp_rc_dup+0x80>  // b.any
    5b90:	29430864 	ldp	w4, w2, [x3, #24]
    5b94:	92403c21 	and	x1, x1, #0xffff
    5b98:	9b047c21 	mul	x1, x1, x4
    5b9c:	d360fc21 	lsr	x1, x1, #32
    5ba0:	eb02003f 	cmp	x1, x2
    5ba4:	54000102 	b.cs	5bc4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5ba8:	8b010000 	add	x0, x0, x1
    5bac:	39400001 	ldrb	w1, [x0]
    5bb0:	340000a1 	cbz	w1, 5bc4 <fwp_rc_dup+0x80>
    5bb4:	7103f43f 	cmp	w1, #0xfd
    5bb8:	540000e8 	b.hi	5bd4 <fwp_rc_dup+0x90>  // b.pmore
    5bbc:	11000421 	add	w1, w1, #0x1
    5bc0:	39000001 	strb	w1, [x0]
    5bc4:	d65f03c0 	ret
    5bc8:	72003c3f 	tst	w1, #0xffff
    5bcc:	54ffff00 	b.eq	5bac <fwp_rc_dup+0x68>  // b.none
    5bd0:	d65f03c0 	ret
    5bd4:	17fffaa4 	b	4664 <fwp_rc_wide_dup>
    5bd8:	d503201f 	nop
    5bdc:	d503201f 	nop

0000000000005be0 <fwp_owned_entry173>:
    5be0:	d10103ff 	sub	sp, sp, #0x40
    5be4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5be8:	f947f442 	ldr	x2, [x2, #4072]
    5bec:	a9027bfd 	stp	x29, x30, [sp, #32]
    5bf0:	910083fd 	add	x29, sp, #0x20
    5bf4:	a90353f3 	stp	x19, x20, [sp, #48]
    5bf8:	f9400043 	ldr	x3, [x2]
    5bfc:	f9000fe3 	str	x3, [sp, #24]
    5c00:	d2800003 	mov	x3, #0x0                   	// #0
    5c04:	a9400c01 	ldp	x1, x3, [x0]
    5c08:	f9400802 	ldr	x2, [x0, #16]
    5c0c:	ab020022 	adds	x2, x1, x2
    5c10:	540006e6 	b.vs	5cec <fwp_owned_entry173+0x10c>
    5c14:	910023e1 	add	x1, sp, #0x8
    5c18:	52800000 	mov	w0, #0x0                   	// #0
    5c1c:	a9008be3 	stp	x3, x2, [sp, #8]
    5c20:	97fffd19 	bl	5084 <fwp_data.part.0.constprop.0>
    5c24:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5c28:	91174063 	add	x3, x3, #0x5d0
    5c2c:	aa0003f3 	mov	x19, x0
    5c30:	f949d861 	ldr	x1, [x3, #5040]
    5c34:	f949ec60 	ldr	x0, [x3, #5080]
    5c38:	cb010261 	sub	x1, x19, x1
    5c3c:	eb00403f 	cmp	x1, x0, lsl #16
    5c40:	54000322 	b.cs	5ca4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5c44:	d350fc22 	lsr	x2, x1, #16
    5c48:	f949fc63 	ldr	x3, [x3, #5112]
    5c4c:	8b020842 	add	x2, x2, x2, lsl #2
    5c50:	d37df042 	lsl	x2, x2, #3
    5c54:	8b020060 	add	x0, x3, x2
    5c58:	f9401014 	ldr	x20, [x0, #32]
    5c5c:	b4000254 	cbz	x20, 5ca4 <fwp_owned_entry173+0xc4>
    5c60:	38626862 	ldrb	w2, [x3, x2]
    5c64:	7100085f 	cmp	w2, #0x2
    5c68:	54000360 	b.eq	5cd4 <fwp_owned_entry173+0xf4>  // b.none
    5c6c:	7100045f 	cmp	w2, #0x1
    5c70:	540001a1 	b.ne	5ca4 <fwp_owned_entry173+0xc4>  // b.any
    5c74:	29430002 	ldp	w2, w0, [x0, #24]
    5c78:	92403c21 	and	x1, x1, #0xffff
    5c7c:	9b027c21 	mul	x1, x1, x2
    5c80:	d360fc21 	lsr	x1, x1, #32
    5c84:	eb00003f 	cmp	x1, x0
    5c88:	540000e2 	b.cs	5ca4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5c8c:	8b010294 	add	x20, x20, x1
    5c90:	39400280 	ldrb	w0, [x20]
    5c94:	7103fc1f 	cmp	w0, #0xff
    5c98:	54000240 	b.eq	5ce0 <fwp_owned_entry173+0x100>  // b.none
    5c9c:	52800020 	mov	w0, #0x1                   	// #1
    5ca0:	39000280 	strb	w0, [x20]
    5ca4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ca8:	f947f400 	ldr	x0, [x0, #4072]
    5cac:	f9400fe2 	ldr	x2, [sp, #24]
    5cb0:	f9400001 	ldr	x1, [x0]
    5cb4:	eb010042 	subs	x2, x2, x1
    5cb8:	d2800001 	mov	x1, #0x0                   	// #0
    5cbc:	540001a1 	b.ne	5cf0 <fwp_owned_entry173+0x110>  // b.any
    5cc0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5cc4:	aa1303e0 	mov	x0, x19
    5cc8:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ccc:	910103ff 	add	sp, sp, #0x40
    5cd0:	d65f03c0 	ret
    5cd4:	72003c3f 	tst	w1, #0xffff
    5cd8:	54fffe61 	b.ne	5ca4 <fwp_owned_entry173+0xc4>  // b.any
    5cdc:	17ffffed 	b	5c90 <fwp_owned_entry173+0xb0>
    5ce0:	aa1403e0 	mov	x0, x20
    5ce4:	97fff94b 	bl	4210 <fwp_rc_forget_slot.part.0>
    5ce8:	17ffffed 	b	5c9c <fwp_owned_entry173+0xbc>
    5cec:	97fff385 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5cf0:	97fff308 	bl	2910 <__stack_chk_fail@plt>

0000000000005cf4 <e173>:
    5cf4:	d10103ff 	sub	sp, sp, #0x40
    5cf8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5cfc:	f947f442 	ldr	x2, [x2, #4072]
    5d00:	a9027bfd 	stp	x29, x30, [sp, #32]
    5d04:	910083fd 	add	x29, sp, #0x20
    5d08:	a90353f3 	stp	x19, x20, [sp, #48]
    5d0c:	f9400043 	ldr	x3, [x2]
    5d10:	f9000fe3 	str	x3, [sp, #24]
    5d14:	d2800003 	mov	x3, #0x0                   	// #0
    5d18:	a9400c01 	ldp	x1, x3, [x0]
    5d1c:	f9400802 	ldr	x2, [x0, #16]
    5d20:	ab020022 	adds	x2, x1, x2
    5d24:	54000726 	b.vs	5e08 <e173+0x114>
    5d28:	910023e1 	add	x1, sp, #0x8
    5d2c:	52800000 	mov	w0, #0x0                   	// #0
    5d30:	a9008be3 	stp	x3, x2, [sp, #8]
    5d34:	97fffcd4 	bl	5084 <fwp_data.part.0.constprop.0>
    5d38:	90000163 	adrp	x3, 31000 <fwp_root_context+0xc10>
    5d3c:	91174063 	add	x3, x3, #0x5d0
    5d40:	aa0003f3 	mov	x19, x0
    5d44:	f949d861 	ldr	x1, [x3, #5040]
    5d48:	f949ec60 	ldr	x0, [x3, #5080]
    5d4c:	cb010261 	sub	x1, x19, x1
    5d50:	eb00403f 	cmp	x1, x0, lsl #16
    5d54:	54000322 	b.cs	5db8 <e173+0xc4>  // b.hs, b.nlast
    5d58:	d350fc22 	lsr	x2, x1, #16
    5d5c:	f949fc63 	ldr	x3, [x3, #5112]
    5d60:	8b020842 	add	x2, x2, x2, lsl #2
    5d64:	d37df042 	lsl	x2, x2, #3
    5d68:	8b020060 	add	x0, x3, x2
    5d6c:	f9401014 	ldr	x20, [x0, #32]
    5d70:	b4000254 	cbz	x20, 5db8 <e173+0xc4>
    5d74:	38626862 	ldrb	w2, [x3, x2]
    5d78:	7100085f 	cmp	w2, #0x2
    5d7c:	540003a0 	b.eq	5df0 <e173+0xfc>  // b.none
    5d80:	7100045f 	cmp	w2, #0x1
    5d84:	540001a1 	b.ne	5db8 <e173+0xc4>  // b.any
    5d88:	29430002 	ldp	w2, w0, [x0, #24]
    5d8c:	92403c21 	and	x1, x1, #0xffff
    5d90:	9b027c21 	mul	x1, x1, x2
    5d94:	d360fc21 	lsr	x1, x1, #32
    5d98:	eb00003f 	cmp	x1, x0
    5d9c:	540000e2 	b.cs	5db8 <e173+0xc4>  // b.hs, b.nlast
    5da0:	8b010294 	add	x20, x20, x1
    5da4:	39400280 	ldrb	w0, [x20]
    5da8:	7103fc1f 	cmp	w0, #0xff
    5dac:	54000280 	b.eq	5dfc <e173+0x108>  // b.none
    5db0:	52800020 	mov	w0, #0x1                   	// #1
    5db4:	39000280 	strb	w0, [x20]
    5db8:	aa1303e0 	mov	x0, x19
    5dbc:	97fffeed 	bl	5970 <fwp_rc_share>
    5dc0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5dc4:	f947f400 	ldr	x0, [x0, #4072]
    5dc8:	f9400fe2 	ldr	x2, [sp, #24]
    5dcc:	f9400001 	ldr	x1, [x0]
    5dd0:	eb010042 	subs	x2, x2, x1
    5dd4:	d2800001 	mov	x1, #0x0                   	// #0
    5dd8:	540001a1 	b.ne	5e0c <e173+0x118>  // b.any
    5ddc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5de0:	aa1303e0 	mov	x0, x19
    5de4:	a94353f3 	ldp	x19, x20, [sp, #48]
    5de8:	910103ff 	add	sp, sp, #0x40
    5dec:	d65f03c0 	ret
    5df0:	72003c3f 	tst	w1, #0xffff
    5df4:	54fffe21 	b.ne	5db8 <e173+0xc4>  // b.any
    5df8:	17ffffeb 	b	5da4 <e173+0xb0>
    5dfc:	aa1403e0 	mov	x0, x20
    5e00:	97fff904 	bl	4210 <fwp_rc_forget_slot.part.0>
    5e04:	17ffffeb 	b	5db0 <e173+0xbc>
    5e08:	97fff33e 	bl	2b00 <fwp_trap_overflow.constprop.0>
    5e0c:	97fff2c1 	bl	2910 <__stack_chk_fail@plt>

0000000000005e10 <fwp_drop0>:
    5e10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5e14:	910003fd 	mov	x29, sp
    5e18:	a90153f3 	stp	x19, x20, [sp, #16]
    5e1c:	f90013f5 	str	x21, [sp, #32]
    5e20:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5e24:	911742b4 	add	x20, x21, #0x5d0
    5e28:	f949da81 	ldr	x1, [x20, #5040]
    5e2c:	f949ee82 	ldr	x2, [x20, #5080]
    5e30:	cb010001 	sub	x1, x0, x1
    5e34:	eb02403f 	cmp	x1, x2, lsl #16
    5e38:	54000382 	b.cs	5ea8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e3c:	d350fc22 	lsr	x2, x1, #16
    5e40:	f949fe84 	ldr	x4, [x20, #5112]
    5e44:	8b020842 	add	x2, x2, x2, lsl #2
    5e48:	d37df042 	lsl	x2, x2, #3
    5e4c:	8b020083 	add	x3, x4, x2
    5e50:	f9401073 	ldr	x19, [x3, #32]
    5e54:	b40002b3 	cbz	x19, 5ea8 <fwp_drop0+0x98>
    5e58:	38626882 	ldrb	w2, [x4, x2]
    5e5c:	7100085f 	cmp	w2, #0x2
    5e60:	540002c0 	b.eq	5eb8 <fwp_drop0+0xa8>  // b.none
    5e64:	7100045f 	cmp	w2, #0x1
    5e68:	54000201 	b.ne	5ea8 <fwp_drop0+0x98>  // b.any
    5e6c:	29430864 	ldp	w4, w2, [x3, #24]
    5e70:	92403c21 	and	x1, x1, #0xffff
    5e74:	9b047c21 	mul	x1, x1, x4
    5e78:	d360fc21 	lsr	x1, x1, #32
    5e7c:	eb02003f 	cmp	x1, x2
    5e80:	54000142 	b.cs	5ea8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5e84:	8b010273 	add	x19, x19, x1
    5e88:	39400261 	ldrb	w1, [x19]
    5e8c:	340000e1 	cbz	w1, 5ea8 <fwp_drop0+0x98>
    5e90:	7100043f 	cmp	w1, #0x1
    5e94:	540001e0 	b.eq	5ed0 <fwp_drop0+0xc0>  // b.none
    5e98:	7103fc3f 	cmp	w1, #0xff
    5e9c:	540002e0 	b.eq	5ef8 <fwp_drop0+0xe8>  // b.none
    5ea0:	51000421 	sub	w1, w1, #0x1
    5ea4:	39000261 	strb	w1, [x19]
    5ea8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5eac:	f94013f5 	ldr	x21, [sp, #32]
    5eb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5eb4:	d65f03c0 	ret
    5eb8:	72003c3f 	tst	w1, #0xffff
    5ebc:	54fffe60 	b.eq	5e88 <fwp_drop0+0x78>  // b.none
    5ec0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ec4:	f94013f5 	ldr	x21, [sp, #32]
    5ec8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5ecc:	d65f03c0 	ret
    5ed0:	f9400813 	ldr	x19, [x0, #16]
    5ed4:	97fffefb 	bl	5ac0 <fwp_rc_free_arr>
    5ed8:	911742a0 	add	x0, x21, #0x5d0
    5edc:	f949d801 	ldr	x1, [x0, #5040]
    5ee0:	f949ec00 	ldr	x0, [x0, #5080]
    5ee4:	cb010261 	sub	x1, x19, x1
    5ee8:	eb00403f 	cmp	x1, x0, lsl #16
    5eec:	54fffde2 	b.cs	5ea8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ef0:	aa1303e0 	mov	x0, x19
    5ef4:	17ffffd2 	b	5e3c <fwp_drop0+0x2c>
    5ef8:	ca534660 	eor	x0, x19, x19, lsr #17
    5efc:	911742b5 	add	x21, x21, #0x5d0
    5f00:	ca402400 	eor	x0, x0, x0, lsr #9
    5f04:	92401c00 	and	x0, x0, #0xff
    5f08:	910a2402 	add	x2, x0, #0x289
    5f0c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5f10:	8b020ea2 	add	x2, x21, x2, lsl #3
    5f14:	f94a2400 	ldr	x0, [x0, #5192]
    5f18:	b50000a0 	cbnz	x0, 5f2c <fwp_drop0+0x11c>
    5f1c:	14000013 	b	5f68 <fwp_drop0+0x158>
    5f20:	91004002 	add	x2, x0, #0x10
    5f24:	f9400800 	ldr	x0, [x0, #16]
    5f28:	b4000200 	cbz	x0, 5f68 <fwp_drop0+0x158>
    5f2c:	f9400001 	ldr	x1, [x0]
    5f30:	eb13003f 	cmp	x1, x19
    5f34:	54ffff61 	b.ne	5f20 <fwp_drop0+0x110>  // b.any
    5f38:	f9400041 	ldr	x1, [x2]
    5f3c:	f9400420 	ldr	x0, [x1, #8]
    5f40:	d1000400 	sub	x0, x0, #0x1
    5f44:	f9000420 	str	x0, [x1, #8]
    5f48:	f103f81f 	cmp	x0, #0xfe
    5f4c:	54fffae1 	b.ne	5ea8 <fwp_drop0+0x98>  // b.any
    5f50:	39400260 	ldrb	w0, [x19]
    5f54:	7103fc1f 	cmp	w0, #0xff
    5f58:	540000e0 	b.eq	5f74 <fwp_drop0+0x164>  // b.none
    5f5c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f60:	39000260 	strb	w0, [x19]
    5f64:	17ffffd1 	b	5ea8 <fwp_drop0+0x98>
    5f68:	90000040 	adrp	x0, d000 <__divti3+0x320>
    5f6c:	9117e000 	add	x0, x0, #0x5f8
    5f70:	97fff888 	bl	4190 <fwp_trap>
    5f74:	aa1303e0 	mov	x0, x19
    5f78:	97fff8a6 	bl	4210 <fwp_rc_forget_slot.part.0>
    5f7c:	17fffff8 	b	5f5c <fwp_drop0+0x14c>

0000000000005f80 <fwp_drop1>:
    5f80:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f84:	910003fd 	mov	x29, sp
    5f88:	a90153f3 	stp	x19, x20, [sp, #16]
    5f8c:	f90013f5 	str	x21, [sp, #32]
    5f90:	90000175 	adrp	x21, 31000 <fwp_root_context+0xc10>
    5f94:	911742b4 	add	x20, x21, #0x5d0
    5f98:	f949da81 	ldr	x1, [x20, #5040]
    5f9c:	f949ee82 	ldr	x2, [x20, #5080]
    5fa0:	cb010001 	sub	x1, x0, x1
    5fa4:	eb02403f 	cmp	x1, x2, lsl #16
    5fa8:	54000382 	b.cs	6018 <fwp_drop1+0x98>  // b.hs, b.nlast
    5fac:	d350fc22 	lsr	x2, x1, #16
    5fb0:	f949fe84 	ldr	x4, [x20, #5112]
    5fb4:	8b020842 	add	x2, x2, x2, lsl #2
    5fb8:	d37df042 	lsl	x2, x2, #3
    5fbc:	8b020083 	add	x3, x4, x2
    5fc0:	f9401073 	ldr	x19, [x3, #32]
    5fc4:	b40002b3 	cbz	x19, 6018 <fwp_drop1+0x98>
    5fc8:	38626882 	ldrb	w2, [x4, x2]
    5fcc:	7100085f 	cmp	w2, #0x2
    5fd0:	540002c0 	b.eq	6028 <fwp_drop1+0xa8>  // b.none
    5fd4:	7100045f 	cmp	w2, #0x1
    5fd8:	54000201 	b.ne	6018 <fwp_drop1+0x98>  // b.any
    5fdc:	29430864 	ldp	w4, w2, [x3, #24]
    5fe0:	92403c21 	and	x1, x1, #0xffff
    5fe4:	9b047c21 	mul	x1, x1, x4
    5fe8:	d360fc21 	lsr	x1, x1, #32
    5fec:	eb02003f 	cmp	x1, x2
    5ff0:	54000142 	b.cs	6018 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ff4:	8b010273 	add	x19, x19, x1
    5ff8:	39400261 	ldrb	w1, [x19]
    5ffc:	340000e1 	cbz	w1, 6018 <fwp_drop1+0x98>
    6000:	7100043f 	cmp	w1, #0x1
    6004:	540001e0 	b.eq	6040 <fwp_drop1+0xc0>  // b.none
    6008:	7103fc3f 	cmp	w1, #0xff
    600c:	540002e0 	b.eq	6068 <fwp_drop1+0xe8>  // b.none
    6010:	51000421 	sub	w1, w1, #0x1
    6014:	39000261 	strb	w1, [x19]
    6018:	a94153f3 	ldp	x19, x20, [sp, #16]
    601c:	f94013f5 	ldr	x21, [sp, #32]
    6020:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6024:	d65f03c0 	ret
    6028:	72003c3f 	tst	w1, #0xffff
    602c:	54fffe60 	b.eq	5ff8 <fwp_drop1+0x78>  // b.none
    6030:	a94153f3 	ldp	x19, x20, [sp, #16]
    6034:	f94013f5 	ldr	x21, [sp, #32]
    6038:	a8c37bfd 	ldp	x29, x30, [sp], #48
    603c:	d65f03c0 	ret
    6040:	f9400813 	ldr	x19, [x0, #16]
    6044:	97fffe9f 	bl	5ac0 <fwp_rc_free_arr>
    6048:	911742a0 	add	x0, x21, #0x5d0
    604c:	f949d801 	ldr	x1, [x0, #5040]
    6050:	f949ec00 	ldr	x0, [x0, #5080]
    6054:	cb010261 	sub	x1, x19, x1
    6058:	eb00403f 	cmp	x1, x0, lsl #16
    605c:	54fffde2 	b.cs	6018 <fwp_drop1+0x98>  // b.hs, b.nlast
    6060:	aa1303e0 	mov	x0, x19
    6064:	17ffffd2 	b	5fac <fwp_drop1+0x2c>
    6068:	ca534660 	eor	x0, x19, x19, lsr #17
    606c:	911742b5 	add	x21, x21, #0x5d0
    6070:	ca402400 	eor	x0, x0, x0, lsr #9
    6074:	92401c00 	and	x0, x0, #0xff
    6078:	910a2402 	add	x2, x0, #0x289
    607c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6080:	8b020ea2 	add	x2, x21, x2, lsl #3
    6084:	f94a2400 	ldr	x0, [x0, #5192]
    6088:	b50000a0 	cbnz	x0, 609c <fwp_drop1+0x11c>
    608c:	14000013 	b	60d8 <fwp_drop1+0x158>
    6090:	91004002 	add	x2, x0, #0x10
    6094:	f9400800 	ldr	x0, [x0, #16]
    6098:	b4000200 	cbz	x0, 60d8 <fwp_drop1+0x158>
    609c:	f9400001 	ldr	x1, [x0]
    60a0:	eb13003f 	cmp	x1, x19
    60a4:	54ffff61 	b.ne	6090 <fwp_drop1+0x110>  // b.any
    60a8:	f9400041 	ldr	x1, [x2]
    60ac:	f9400420 	ldr	x0, [x1, #8]
    60b0:	d1000400 	sub	x0, x0, #0x1
    60b4:	f9000420 	str	x0, [x1, #8]
    60b8:	f103f81f 	cmp	x0, #0xfe
    60bc:	54fffae1 	b.ne	6018 <fwp_drop1+0x98>  // b.any
    60c0:	39400260 	ldrb	w0, [x19]
    60c4:	7103fc1f 	cmp	w0, #0xff
    60c8:	540000e0 	b.eq	60e4 <fwp_drop1+0x164>  // b.none
    60cc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    60d0:	39000260 	strb	w0, [x19]
    60d4:	17ffffd1 	b	6018 <fwp_drop1+0x98>
    60d8:	f0000020 	adrp	x0, d000 <__divti3+0x320>
    60dc:	9117e000 	add	x0, x0, #0x5f8
    60e0:	97fff82c 	bl	4190 <fwp_trap>
    60e4:	aa1303e0 	mov	x0, x19
    60e8:	97fff84a 	bl	4210 <fwp_rc_forget_slot.part.0>
    60ec:	17fffff8 	b	60cc <fwp_drop1+0x14c>

00000000000060f0 <fwp_closure_drop>:
    60f0:	f0000145 	adrp	x5, 31000 <fwp_root_context+0xc10>
    60f4:	911740a4 	add	x4, x5, #0x5d0
    60f8:	aa0003e1 	mov	x1, x0
    60fc:	f949d882 	ldr	x2, [x4, #5040]
    6100:	f949ec80 	ldr	x0, [x4, #5080]
    6104:	cb020022 	sub	x2, x1, x2
    6108:	eb00405f 	cmp	x2, x0, lsl #16
    610c:	54000662 	b.cs	61d8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6110:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6114:	d350fc43 	lsr	x3, x2, #16
    6118:	910003fd 	mov	x29, sp
    611c:	8b030863 	add	x3, x3, x3, lsl #2
    6120:	f949fc84 	ldr	x4, [x4, #5112]
    6124:	d37df063 	lsl	x3, x3, #3
    6128:	f9000bf3 	str	x19, [sp, #16]
    612c:	8b030080 	add	x0, x4, x3
    6130:	f9401013 	ldr	x19, [x0, #32]
    6134:	b40002b3 	cbz	x19, 6188 <fwp_closure_drop+0x98>
    6138:	38636883 	ldrb	w3, [x4, x3]
    613c:	7100087f 	cmp	w3, #0x2
    6140:	54000420 	b.eq	61c4 <fwp_closure_drop+0xd4>  // b.none
    6144:	7100047f 	cmp	w3, #0x1
    6148:	54000201 	b.ne	6188 <fwp_closure_drop+0x98>  // b.any
    614c:	29430003 	ldp	w3, w0, [x0, #24]
    6150:	92403c42 	and	x2, x2, #0xffff
    6154:	9b037c42 	mul	x2, x2, x3
    6158:	d360fc42 	lsr	x2, x2, #32
    615c:	eb00005f 	cmp	x2, x0
    6160:	54000142 	b.cs	6188 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6164:	8b020273 	add	x19, x19, x2
    6168:	39400260 	ldrb	w0, [x19]
    616c:	340000e0 	cbz	w0, 6188 <fwp_closure_drop+0x98>
    6170:	7100041f 	cmp	w0, #0x1
    6174:	54000100 	b.eq	6194 <fwp_closure_drop+0xa4>  // b.none
    6178:	7103fc1f 	cmp	w0, #0xff
    617c:	54000300 	b.eq	61dc <fwp_closure_drop+0xec>  // b.none
    6180:	51000400 	sub	w0, w0, #0x1
    6184:	39000260 	strb	w0, [x19]
    6188:	f9400bf3 	ldr	x19, [sp, #16]
    618c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6190:	d65f03c0 	ret
    6194:	d53bd040 	mrs	x0, tpidr_el0
    6198:	91400000 	add	x0, x0, #0x0, lsl #12
    619c:	91004000 	add	x0, x0, #0x10
    61a0:	f9400000 	ldr	x0, [x0]
    61a4:	b4000080 	cbz	x0, 61b4 <fwp_closure_drop+0xc4>
    61a8:	f9400bf3 	ldr	x19, [sp, #16]
    61ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61b0:	17fff974 	b	4780 <fwp_closure_drop_push>
    61b4:	f9400bf3 	ldr	x19, [sp, #16]
    61b8:	aa0103e0 	mov	x0, x1
    61bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61c0:	17fff9b5 	b	4894 <fwp_closure_drop.part.0>
    61c4:	72003c5f 	tst	w2, #0xffff
    61c8:	54fffd00 	b.eq	6168 <fwp_closure_drop+0x78>  // b.none
    61cc:	f9400bf3 	ldr	x19, [sp, #16]
    61d0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    61d4:	d65f03c0 	ret
    61d8:	d65f03c0 	ret
    61dc:	ca534660 	eor	x0, x19, x19, lsr #17
    61e0:	911740a5 	add	x5, x5, #0x5d0
    61e4:	ca402400 	eor	x0, x0, x0, lsr #9
    61e8:	92401c00 	and	x0, x0, #0xff
    61ec:	910a2402 	add	x2, x0, #0x289
    61f0:	8b000ca0 	add	x0, x5, x0, lsl #3
    61f4:	8b020ca2 	add	x2, x5, x2, lsl #3
    61f8:	f94a2400 	ldr	x0, [x0, #5192]
    61fc:	b50000a0 	cbnz	x0, 6210 <fwp_closure_drop+0x120>
    6200:	14000013 	b	624c <fwp_closure_drop+0x15c>
    6204:	91004002 	add	x2, x0, #0x10
    6208:	f9400800 	ldr	x0, [x0, #16]
    620c:	b4000200 	cbz	x0, 624c <fwp_closure_drop+0x15c>
    6210:	f9400001 	ldr	x1, [x0]
    6214:	eb13003f 	cmp	x1, x19
    6218:	54ffff61 	b.ne	6204 <fwp_closure_drop+0x114>  // b.any
    621c:	f9400041 	ldr	x1, [x2]
    6220:	f9400420 	ldr	x0, [x1, #8]
    6224:	d1000400 	sub	x0, x0, #0x1
    6228:	f9000420 	str	x0, [x1, #8]
    622c:	f103f81f 	cmp	x0, #0xfe
    6230:	54fffac1 	b.ne	6188 <fwp_closure_drop+0x98>  // b.any
    6234:	39400260 	ldrb	w0, [x19]
    6238:	7103fc1f 	cmp	w0, #0xff
    623c:	540000e0 	b.eq	6258 <fwp_closure_drop+0x168>  // b.none
    6240:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6244:	39000260 	strb	w0, [x19]
    6248:	17ffffd0 	b	6188 <fwp_closure_drop+0x98>
    624c:	f0000020 	adrp	x0, d000 <__divti3+0x320>
    6250:	9117e000 	add	x0, x0, #0x5f8
    6254:	97fff7cf 	bl	4190 <fwp_trap>
    6258:	aa1303e0 	mov	x0, x19
    625c:	97fff7ed 	bl	4210 <fwp_rc_forget_slot.part.0>
    6260:	17fffff8 	b	6240 <fwp_closure_drop+0x150>

0000000000006264 <fwp_owned_tape_release>:
    6264:	b4000920 	cbz	x0, 6388 <fwp_owned_tape_release+0x124>
    6268:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    626c:	910003fd 	mov	x29, sp
    6270:	a90153f3 	stp	x19, x20, [sp, #16]
    6274:	aa0003f3 	mov	x19, x0
    6278:	f9400000 	ldr	x0, [x0]
    627c:	b4000060 	cbz	x0, 6288 <fwp_owned_tape_release+0x24>
    6280:	f9400661 	ldr	x1, [x19, #8]
    6284:	f9000401 	str	x1, [x0, #8]
    6288:	f9400661 	ldr	x1, [x19, #8]
    628c:	b4000041 	cbz	x1, 6294 <fwp_owned_tape_release+0x30>
    6290:	f9000020 	str	x0, [x1]
    6294:	f9400a60 	ldr	x0, [x19, #16]
    6298:	f9403401 	ldr	x1, [x0, #104]
    629c:	b40005a1 	cbz	x1, 6350 <fwp_owned_tape_release+0xec>
    62a0:	a9450a60 	ldp	x0, x2, [x19, #80]
    62a4:	eb00005f 	cmp	x2, x0
    62a8:	540002cd 	b.le	6300 <fwp_owned_tape_release+0x9c>
    62ac:	d2800014 	mov	x20, #0x0                   	// #0
    62b0:	f90013f5 	str	x21, [sp, #32]
    62b4:	d2800015 	mov	x21, #0x0                   	// #0
    62b8:	f9402260 	ldr	x0, [x19, #64]
    62bc:	910006b5 	add	x21, x21, #0x1
    62c0:	f8746800 	ldr	x0, [x0, x20]
    62c4:	d63f0020 	blr	x1
    62c8:	f9402260 	ldr	x0, [x19, #64]
    62cc:	f9400a61 	ldr	x1, [x19, #16]
    62d0:	8b140000 	add	x0, x0, x20
    62d4:	91004294 	add	x20, x20, #0x10
    62d8:	f9400400 	ldr	x0, [x0, #8]
    62dc:	f9403421 	ldr	x1, [x1, #104]
    62e0:	d63f0020 	blr	x1
    62e4:	a9450261 	ldp	x1, x0, [x19, #80]
    62e8:	cb010000 	sub	x0, x0, x1
    62ec:	eb15001f 	cmp	x0, x21
    62f0:	f9400a60 	ldr	x0, [x19, #16]
    62f4:	f9403401 	ldr	x1, [x0, #104]
    62f8:	54fffe0c 	b.gt	62b8 <fwp_owned_tape_release+0x54>
    62fc:	f94013f5 	ldr	x21, [sp, #32]
    6300:	f9403663 	ldr	x3, [x19, #104]
    6304:	f9401262 	ldr	x2, [x19, #32]
    6308:	f100007f 	cmp	x3, #0x0
    630c:	540001ed 	b.le	6348 <fwp_owned_tape_release+0xe4>
    6310:	d2800014 	mov	x20, #0x0                   	// #0
    6314:	d503201f 	nop
    6318:	f9402660 	ldr	x0, [x19, #72]
    631c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6320:	eb02001f 	cmp	x0, x2
    6324:	540000c0 	b.eq	633c <fwp_owned_tape_release+0xd8>  // b.none
    6328:	d63f0020 	blr	x1
    632c:	f9400a60 	ldr	x0, [x19, #16]
    6330:	f9401262 	ldr	x2, [x19, #32]
    6334:	f9403663 	ldr	x3, [x19, #104]
    6338:	f9403401 	ldr	x1, [x0, #104]
    633c:	91000694 	add	x20, x20, #0x1
    6340:	eb14007f 	cmp	x3, x20
    6344:	54fffeac 	b.gt	6318 <fwp_owned_tape_release+0xb4>
    6348:	aa0203e0 	mov	x0, x2
    634c:	d63f0020 	blr	x1
    6350:	f9401660 	ldr	x0, [x19, #40]
    6354:	97ffff67 	bl	60f0 <fwp_closure_drop>
    6358:	f9401a60 	ldr	x0, [x19, #48]
    635c:	97ffff65 	bl	60f0 <fwp_closure_drop>
    6360:	f9401e60 	ldr	x0, [x19, #56]
    6364:	97ffff63 	bl	60f0 <fwp_closure_drop>
    6368:	f9402260 	ldr	x0, [x19, #64]
    636c:	97fff845 	bl	4480 <fwp_mem_free>
    6370:	f9402660 	ldr	x0, [x19, #72]
    6374:	97fff843 	bl	4480 <fwp_mem_free>
    6378:	aa1303e0 	mov	x0, x19
    637c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6380:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6384:	17fff83f 	b	4480 <fwp_mem_free>
    6388:	d65f03c0 	ret
    638c:	d503201f 	nop

0000000000006390 <fwp_tape_finish>:
    6390:	d10203ff 	sub	sp, sp, #0x80
    6394:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6398:	f947f421 	ldr	x1, [x1, #4072]
    639c:	a9047bfd 	stp	x29, x30, [sp, #64]
    63a0:	910103fd 	add	x29, sp, #0x40
    63a4:	a90553f3 	stp	x19, x20, [sp, #80]
    63a8:	a9065bf5 	stp	x21, x22, [sp, #96]
    63ac:	a90763f7 	stp	x23, x24, [sp, #112]
    63b0:	d00000d8 	adrp	x24, 20000 <__data_start>
    63b4:	9101c316 	add	x22, x24, #0x70
    63b8:	f9400022 	ldr	x2, [x1]
    63bc:	f9001fe2 	str	x2, [sp, #56]
    63c0:	d2800002 	mov	x2, #0x0                   	// #0
    63c4:	910222c0 	add	x0, x22, #0x88
    63c8:	97fff44e 	bl	3500 <fwp_tape_buffers_dispose>
    63cc:	f90062df 	str	xzr, [x22, #192]
    63d0:	f9406ac0 	ldr	x0, [x22, #208]
    63d4:	f100001f 	cmp	x0, #0x0
    63d8:	5400030d 	b.le	6438 <fwp_tape_finish+0xa8>
    63dc:	910003f7 	mov	x23, sp
    63e0:	d2800015 	mov	x21, #0x0                   	// #0
    63e4:	d2800014 	mov	x20, #0x0                   	// #0
    63e8:	f94002d3 	ldr	x19, [x22]
    63ec:	91000694 	add	x20, x20, #0x1
    63f0:	8b150273 	add	x19, x19, x21
    63f4:	9101a2b5 	add	x21, x21, #0x68
    63f8:	aa1303e0 	mov	x0, x19
    63fc:	97fff305 	bl	3010 <fwp_tape_unlink_scope>
    6400:	aa1703e0 	mov	x0, x23
    6404:	f9401261 	ldr	x1, [x19, #32]
    6408:	f90003e1 	str	x1, [sp]
    640c:	f9401a62 	ldr	x2, [x19, #48]
    6410:	f9000be2 	str	x2, [sp, #16]
    6414:	f9402261 	ldr	x1, [x19, #64]
    6418:	f90013e1 	str	x1, [sp, #32]
    641c:	97fff439 	bl	3500 <fwp_tape_buffers_dispose>
    6420:	f9403260 	ldr	x0, [x19, #96]
    6424:	97ffff90 	bl	6264 <fwp_owned_tape_release>
    6428:	f900327f 	str	xzr, [x19, #96]
    642c:	f9406ac0 	ldr	x0, [x22, #208]
    6430:	eb14001f 	cmp	x0, x20
    6434:	54fffdac 	b.gt	63e8 <fwp_tape_finish+0x58>
    6438:	f9403b00 	ldr	x0, [x24, #112]
    643c:	9101c313 	add	x19, x24, #0x70
    6440:	97fff164 	bl	29d0 <free@plt>
    6444:	f9003b1f 	str	xzr, [x24, #112]
    6448:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    644c:	f947f400 	ldr	x0, [x0, #4072]
    6450:	f9006a7f 	str	xzr, [x19, #208]
    6454:	a90e7e7f 	stp	xzr, xzr, [x19, #224]
    6458:	f9401fe2 	ldr	x2, [sp, #56]
    645c:	f9400001 	ldr	x1, [x0]
    6460:	eb010042 	subs	x2, x2, x1
    6464:	d2800001 	mov	x1, #0x0                   	// #0
    6468:	540000e1 	b.ne	6484 <fwp_tape_finish+0xf4>  // b.any
    646c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6470:	a94553f3 	ldp	x19, x20, [sp, #80]
    6474:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6478:	a94763f7 	ldp	x23, x24, [sp, #112]
    647c:	910203ff 	add	sp, sp, #0x80
    6480:	d65f03c0 	ret
    6484:	97fff123 	bl	2910 <__stack_chk_fail@plt>
    6488:	d503201f 	nop
    648c:	d503201f 	nop

0000000000006490 <fwp_tape_scope_release>:
    6490:	d10243ff 	sub	sp, sp, #0x90
    6494:	a9047bfd 	stp	x29, x30, [sp, #64]
    6498:	910103fd 	add	x29, sp, #0x40
    649c:	a90553f3 	stp	x19, x20, [sp, #80]
    64a0:	aa0003f4 	mov	x20, x0
    64a4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    64a8:	f947f400 	ldr	x0, [x0, #4072]
    64ac:	b9400285 	ldr	w5, [x20]
    64b0:	f9400001 	ldr	x1, [x0]
    64b4:	f9001fe1 	str	x1, [sp, #56]
    64b8:	d2800001 	mov	x1, #0x0                   	// #0
    64bc:	37f806c5 	tbnz	w5, #31, 6594 <fwp_tape_scope_release+0x104>
    64c0:	a90763f7 	stp	x23, x24, [sp, #112]
    64c4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    64c8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    64cc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    64d0:	d00000d3 	adrp	x19, 20000 <__data_start>
    64d4:	910003f7 	mov	x23, sp
    64d8:	9101c273 	add	x19, x19, #0x70
    64dc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    64e0:	a9065bf5 	stp	x21, x22, [sp, #96]
    64e4:	52800d16 	mov	w22, #0x68                  	// #104
    64e8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    64ec:	f90043f9 	str	x25, [sp, #128]
    64f0:	14000006 	b	6508 <fwp_tape_scope_release+0x78>
    64f4:	97fff403 	bl	3500 <fwp_tape_buffers_dispose>
    64f8:	aa1903e0 	mov	x0, x25
    64fc:	97ffff5a 	bl	6264 <fwp_owned_tape_release>
    6500:	b9400285 	ldr	w5, [x20]
    6504:	37f80425 	tbnz	w5, #31, 6588 <fwp_tape_scope_release+0xf8>
    6508:	f9400266 	ldr	x6, [x19]
    650c:	9b367ca5 	smull	x5, w5, w22
    6510:	8b0500c0 	add	x0, x6, x5
    6514:	97fff2bf 	bl	3010 <fwp_tape_unlink_scope>
    6518:	ad410001 	ldp	q1, q0, [x0, #32]
    651c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6520:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6524:	f9400c03 	ldr	x3, [x0, #24]
    6528:	ad0003e1 	stp	q1, q0, [sp]
    652c:	b86568c1 	ldr	w1, [x6, x5]
    6530:	a9440804 	ldp	x4, x2, [x0, #64]
    6534:	b900041f 	str	wzr, [x0, #4]
    6538:	f9403019 	ldr	x25, [x0, #96]
    653c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6540:	f9000c1f 	str	xzr, [x0, #24]
    6544:	a9020fe4 	stp	x4, x3, [sp, #32]
    6548:	f9001be2 	str	x2, [sp, #48]
    654c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6550:	f900301f 	str	xzr, [x0, #96]
    6554:	6b15003f 	cmp	w1, w21
    6558:	540000e8 	b.hi	6574 <fwp_tape_scope_release+0xe4>  // b.pmore
    655c:	9343fca5 	asr	x5, x5, #3
    6560:	f9407660 	ldr	x0, [x19, #232]
    6564:	9b187ca5 	mul	x5, x5, x24
    6568:	eb0000bf 	cmp	x5, x0
    656c:	5400004a 	b.ge	6574 <fwp_tape_scope_release+0xe4>  // b.tcont
    6570:	f9007665 	str	x5, [x19, #232]
    6574:	aa1703e0 	mov	x0, x23
    6578:	b5fffbf9 	cbnz	x25, 64f4 <fwp_tape_scope_release+0x64>
    657c:	97fff6bd 	bl	4070 <fwp_tape_buffers_release>
    6580:	b9400285 	ldr	w5, [x20]
    6584:	36fffc25 	tbz	w5, #31, 6508 <fwp_tape_scope_release+0x78>
    6588:	a9465bf5 	ldp	x21, x22, [sp, #96]
    658c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6590:	f94043f9 	ldr	x25, [sp, #128]
    6594:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6598:	f947f400 	ldr	x0, [x0, #4072]
    659c:	f9401fe2 	ldr	x2, [sp, #56]
    65a0:	f9400001 	ldr	x1, [x0]
    65a4:	eb010042 	subs	x2, x2, x1
    65a8:	d2800001 	mov	x1, #0x0                   	// #0
    65ac:	540000a1 	b.ne	65c0 <fwp_tape_scope_release+0x130>  // b.any
    65b0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    65b4:	a94553f3 	ldp	x19, x20, [sp, #80]
    65b8:	910243ff 	add	sp, sp, #0x90
    65bc:	d65f03c0 	ret
    65c0:	a9065bf5 	stp	x21, x22, [sp, #96]
    65c4:	a90763f7 	stp	x23, x24, [sp, #112]
    65c8:	f90043f9 	str	x25, [sp, #128]
    65cc:	97fff0d1 	bl	2910 <__stack_chk_fail@plt>

00000000000065d0 <fwp_drop4>:
    65d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    65d4:	910003fd 	mov	x29, sp
    65d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    65dc:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xc10>
    65e0:	911742d5 	add	x21, x22, #0x5d0
    65e4:	a90153f3 	stp	x19, x20, [sp, #16]
    65e8:	aa0003f3 	mov	x19, x0
    65ec:	f949daa1 	ldr	x1, [x21, #5040]
    65f0:	f949eea0 	ldr	x0, [x21, #5080]
    65f4:	cb010261 	sub	x1, x19, x1
    65f8:	eb00403f 	cmp	x1, x0, lsl #16
    65fc:	54000382 	b.cs	666c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6600:	d350fc22 	lsr	x2, x1, #16
    6604:	f949fea3 	ldr	x3, [x21, #5112]
    6608:	8b020842 	add	x2, x2, x2, lsl #2
    660c:	d37df042 	lsl	x2, x2, #3
    6610:	8b020060 	add	x0, x3, x2
    6614:	f9401014 	ldr	x20, [x0, #32]
    6618:	b40002b4 	cbz	x20, 666c <fwp_drop4+0x9c>
    661c:	38626862 	ldrb	w2, [x3, x2]
    6620:	7100085f 	cmp	w2, #0x2
    6624:	540002c0 	b.eq	667c <fwp_drop4+0xac>  // b.none
    6628:	7100045f 	cmp	w2, #0x1
    662c:	54000201 	b.ne	666c <fwp_drop4+0x9c>  // b.any
    6630:	29430002 	ldp	w2, w0, [x0, #24]
    6634:	92403c21 	and	x1, x1, #0xffff
    6638:	9b027c21 	mul	x1, x1, x2
    663c:	d360fc21 	lsr	x1, x1, #32
    6640:	eb00003f 	cmp	x1, x0
    6644:	54000142 	b.cs	666c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6648:	8b010294 	add	x20, x20, x1
    664c:	39400280 	ldrb	w0, [x20]
    6650:	340000e0 	cbz	w0, 666c <fwp_drop4+0x9c>
    6654:	7100041f 	cmp	w0, #0x1
    6658:	540001e0 	b.eq	6694 <fwp_drop4+0xc4>  // b.none
    665c:	7103fc1f 	cmp	w0, #0xff
    6660:	540007c0 	b.eq	6758 <fwp_drop4+0x188>  // b.none
    6664:	51000400 	sub	w0, w0, #0x1
    6668:	39000280 	strb	w0, [x20]
    666c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6670:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6674:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6678:	d65f03c0 	ret
    667c:	72003c3f 	tst	w1, #0xffff
    6680:	54fffe60 	b.eq	664c <fwp_drop4+0x7c>  // b.none
    6684:	a94153f3 	ldp	x19, x20, [sp, #16]
    6688:	a9425bf5 	ldp	x21, x22, [sp, #32]
    668c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6690:	d65f03c0 	ret
    6694:	911742c2 	add	x2, x22, #0x5d0
    6698:	f9400660 	ldr	x0, [x19, #8]
    669c:	f949d841 	ldr	x1, [x2, #5040]
    66a0:	f949ec42 	ldr	x2, [x2, #5080]
    66a4:	cb010001 	sub	x1, x0, x1
    66a8:	eb02403f 	cmp	x1, x2, lsl #16
    66ac:	54000362 	b.cs	6718 <fwp_drop4+0x148>  // b.hs, b.nlast
    66b0:	d350fc22 	lsr	x2, x1, #16
    66b4:	8b020842 	add	x2, x2, x2, lsl #2
    66b8:	d37df042 	lsl	x2, x2, #3
    66bc:	8b020064 	add	x4, x3, x2
    66c0:	f9401094 	ldr	x20, [x4, #32]
    66c4:	b40002b4 	cbz	x20, 6718 <fwp_drop4+0x148>
    66c8:	38626862 	ldrb	w2, [x3, x2]
    66cc:	7100085f 	cmp	w2, #0x2
    66d0:	540003e0 	b.eq	674c <fwp_drop4+0x17c>  // b.none
    66d4:	7100045f 	cmp	w2, #0x1
    66d8:	54000201 	b.ne	6718 <fwp_drop4+0x148>  // b.any
    66dc:	29430883 	ldp	w3, w2, [x4, #24]
    66e0:	92403c21 	and	x1, x1, #0xffff
    66e4:	9b037c21 	mul	x1, x1, x3
    66e8:	d360fc21 	lsr	x1, x1, #32
    66ec:	eb02003f 	cmp	x1, x2
    66f0:	54000142 	b.cs	6718 <fwp_drop4+0x148>  // b.hs, b.nlast
    66f4:	8b010294 	add	x20, x20, x1
    66f8:	39400281 	ldrb	w1, [x20]
    66fc:	340000e1 	cbz	w1, 6718 <fwp_drop4+0x148>
    6700:	7100043f 	cmp	w1, #0x1
    6704:	54000200 	b.eq	6744 <fwp_drop4+0x174>  // b.none
    6708:	7103fc3f 	cmp	w1, #0xff
    670c:	54000640 	b.eq	67d4 <fwp_drop4+0x204>  // b.none
    6710:	51000421 	sub	w1, w1, #0x1
    6714:	39000281 	strb	w1, [x20]
    6718:	f9400a74 	ldr	x20, [x19, #16]
    671c:	aa1303e0 	mov	x0, x19
    6720:	97fffce8 	bl	5ac0 <fwp_rc_free_arr>
    6724:	911742c0 	add	x0, x22, #0x5d0
    6728:	f949d801 	ldr	x1, [x0, #5040]
    672c:	f949ec00 	ldr	x0, [x0, #5080]
    6730:	cb010281 	sub	x1, x20, x1
    6734:	eb00403f 	cmp	x1, x0, lsl #16
    6738:	54fff9a2 	b.cs	666c <fwp_drop4+0x9c>  // b.hs, b.nlast
    673c:	aa1403f3 	mov	x19, x20
    6740:	17ffffb0 	b	6600 <fwp_drop4+0x30>
    6744:	97fffcdf 	bl	5ac0 <fwp_rc_free_arr>
    6748:	17fffff4 	b	6718 <fwp_drop4+0x148>
    674c:	72003c3f 	tst	w1, #0xffff
    6750:	54fffe41 	b.ne	6718 <fwp_drop4+0x148>  // b.any
    6754:	17ffffe9 	b	66f8 <fwp_drop4+0x128>
    6758:	ca544681 	eor	x1, x20, x20, lsr #17
    675c:	911742c0 	add	x0, x22, #0x5d0
    6760:	ca412421 	eor	x1, x1, x1, lsr #9
    6764:	92401c21 	and	x1, x1, #0xff
    6768:	910a2422 	add	x2, x1, #0x289
    676c:	8b010c01 	add	x1, x0, x1, lsl #3
    6770:	8b020c02 	add	x2, x0, x2, lsl #3
    6774:	f94a2420 	ldr	x0, [x1, #5192]
    6778:	b50000a0 	cbnz	x0, 678c <fwp_drop4+0x1bc>
    677c:	14000013 	b	67c8 <fwp_drop4+0x1f8>
    6780:	91004002 	add	x2, x0, #0x10
    6784:	f9400800 	ldr	x0, [x0, #16]
    6788:	b4000200 	cbz	x0, 67c8 <fwp_drop4+0x1f8>
    678c:	f9400001 	ldr	x1, [x0]
    6790:	eb14003f 	cmp	x1, x20
    6794:	54ffff61 	b.ne	6780 <fwp_drop4+0x1b0>  // b.any
    6798:	f9400041 	ldr	x1, [x2]
    679c:	f9400420 	ldr	x0, [x1, #8]
    67a0:	d1000400 	sub	x0, x0, #0x1
    67a4:	f9000420 	str	x0, [x1, #8]
    67a8:	f103f81f 	cmp	x0, #0xfe
    67ac:	54fff601 	b.ne	666c <fwp_drop4+0x9c>  // b.any
    67b0:	39400280 	ldrb	w0, [x20]
    67b4:	7103fc1f 	cmp	w0, #0xff
    67b8:	54000460 	b.eq	6844 <fwp_drop4+0x274>  // b.none
    67bc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    67c0:	39000280 	strb	w0, [x20]
    67c4:	17ffffaa 	b	666c <fwp_drop4+0x9c>
    67c8:	f0000020 	adrp	x0, d000 <__divti3+0x320>
    67cc:	9117e000 	add	x0, x0, #0x5f8
    67d0:	97fff670 	bl	4190 <fwp_trap>
    67d4:	ca544680 	eor	x0, x20, x20, lsr #17
    67d8:	911742c1 	add	x1, x22, #0x5d0
    67dc:	ca402400 	eor	x0, x0, x0, lsr #9
    67e0:	92401c00 	and	x0, x0, #0xff
    67e4:	910a2402 	add	x2, x0, #0x289
    67e8:	8b000c20 	add	x0, x1, x0, lsl #3
    67ec:	8b020c22 	add	x2, x1, x2, lsl #3
    67f0:	f94a2400 	ldr	x0, [x0, #5192]
    67f4:	b50000a0 	cbnz	x0, 6808 <fwp_drop4+0x238>
    67f8:	17fffff4 	b	67c8 <fwp_drop4+0x1f8>
    67fc:	91004002 	add	x2, x0, #0x10
    6800:	f9400800 	ldr	x0, [x0, #16]
    6804:	b4fffe20 	cbz	x0, 67c8 <fwp_drop4+0x1f8>
    6808:	f9400001 	ldr	x1, [x0]
    680c:	eb14003f 	cmp	x1, x20
    6810:	54ffff61 	b.ne	67fc <fwp_drop4+0x22c>  // b.any
    6814:	f9400041 	ldr	x1, [x2]
    6818:	f9400420 	ldr	x0, [x1, #8]
    681c:	d1000400 	sub	x0, x0, #0x1
    6820:	f9000420 	str	x0, [x1, #8]
    6824:	f103f81f 	cmp	x0, #0xfe
    6828:	54fff781 	b.ne	6718 <fwp_drop4+0x148>  // b.any
    682c:	39400280 	ldrb	w0, [x20]
    6830:	7103fc1f 	cmp	w0, #0xff
    6834:	540000e0 	b.eq	6850 <fwp_drop4+0x280>  // b.none
    6838:	12800020 	mov	w0, #0xfffffffe            	// #-2
    683c:	39000280 	strb	w0, [x20]
    6840:	17ffffb6 	b	6718 <fwp_drop4+0x148>
    6844:	aa1403e0 	mov	x0, x20
    6848:	97fff672 	bl	4210 <fwp_rc_forget_slot.part.0>
    684c:	17ffffdc 	b	67bc <fwp_drop4+0x1ec>
    6850:	aa1403e0 	mov	x0, x20
    6854:	97fff66f 	bl	4210 <fwp_rc_forget_slot.part.0>
    6858:	17fffff8 	b	6838 <fwp_drop4+0x268>
    685c:	d503201f 	nop

0000000000006860 <fwp_arg_drop37>:
    6860:	7100003f 	cmp	w1, #0x0
    6864:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6868:	54000041 	b.ne	6870 <fwp_arg_drop37+0x10>  // b.any
    686c:	d65f03c0 	ret
    6870:	f9400000 	ldr	x0, [x0]
    6874:	17ffff57 	b	65d0 <fwp_drop4>
    6878:	d503201f 	nop
    687c:	d503201f 	nop

0000000000006880 <fwp_task_dispose>:
    6880:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6884:	910003fd 	mov	x29, sp
    6888:	f9000bf3 	str	x19, [sp, #16]
    688c:	aa0003f3 	mov	x19, x0
    6890:	39414000 	ldrb	w0, [x0, #80]
    6894:	36000720 	tbz	w0, #0, 6978 <fwp_task_dispose+0xf8>
    6898:	f9400a60 	ldr	x0, [x19, #16]
    689c:	b50006e0 	cbnz	x0, 6978 <fwp_task_dispose+0xf8>
    68a0:	a9478660 	ldp	x0, x1, [x19, #120]
    68a4:	39014e7f 	strb	wzr, [x19, #83]
    68a8:	f9003e7f 	str	xzr, [x19, #120]
    68ac:	f100003f 	cmp	x1, #0x0
    68b0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    68b4:	54000040 	b.eq	68bc <fwp_task_dispose+0x3c>  // b.none
    68b8:	d63f0020 	blr	x1
    68bc:	f9405660 	ldr	x0, [x19, #168]
    68c0:	97fff6f0 	bl	4480 <fwp_mem_free>
    68c4:	f900567f 	str	xzr, [x19, #168]
    68c8:	b9405e60 	ldr	w0, [x19, #92]
    68cc:	7100041f 	cmp	w0, #0x1
    68d0:	54000420 	b.eq	6954 <fwp_task_dispose+0xd4>  // b.none
    68d4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    68d8:	91174042 	add	x2, x2, #0x5d0
    68dc:	f949d840 	ldr	x0, [x2, #5040]
    68e0:	f949ec41 	ldr	x1, [x2, #5080]
    68e4:	cb000260 	sub	x0, x19, x0
    68e8:	eb01401f 	cmp	x0, x1, lsl #16
    68ec:	540002e2 	b.cs	6948 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    68f0:	d350fc01 	lsr	x1, x0, #16
    68f4:	f949fc44 	ldr	x4, [x2, #5112]
    68f8:	8b010821 	add	x1, x1, x1, lsl #2
    68fc:	d37df021 	lsl	x1, x1, #3
    6900:	8b010083 	add	x3, x4, x1
    6904:	f9401062 	ldr	x2, [x3, #32]
    6908:	b4000202 	cbz	x2, 6948 <fwp_task_dispose+0xc8>
    690c:	38616881 	ldrb	w1, [x4, x1]
    6910:	7100083f 	cmp	w1, #0x2
    6914:	54000280 	b.eq	6964 <fwp_task_dispose+0xe4>  // b.none
    6918:	7100043f 	cmp	w1, #0x1
    691c:	54000161 	b.ne	6948 <fwp_task_dispose+0xc8>  // b.any
    6920:	29430464 	ldp	w4, w1, [x3, #24]
    6924:	92403c00 	and	x0, x0, #0xffff
    6928:	9b047c00 	mul	x0, x0, x4
    692c:	d360fc00 	lsr	x0, x0, #32
    6930:	eb01001f 	cmp	x0, x1
    6934:	540000a2 	b.cs	6948 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6938:	8b000042 	add	x2, x2, x0
    693c:	39400040 	ldrb	w0, [x2]
    6940:	7100041f 	cmp	w0, #0x1
    6944:	54000080 	b.eq	6954 <fwp_task_dispose+0xd4>  // b.none
    6948:	f9400bf3 	ldr	x19, [sp, #16]
    694c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6950:	d65f03c0 	ret
    6954:	aa1303e0 	mov	x0, x19
    6958:	f9400bf3 	ldr	x19, [sp, #16]
    695c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6960:	17fff6c8 	b	4480 <fwp_mem_free>
    6964:	72003c1f 	tst	w0, #0xffff
    6968:	54fffea0 	b.eq	693c <fwp_task_dispose+0xbc>  // b.none
    696c:	f9400bf3 	ldr	x19, [sp, #16]
    6970:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6974:	d65f03c0 	ret
    6978:	97ffeffa 	bl	2960 <abort@plt>
    697c:	d503201f 	nop

0000000000006980 <fwp_free_zombie>:
    6980:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6984:	910003fd 	mov	x29, sp
    6988:	a90153f3 	stp	x19, x20, [sp, #16]
    698c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6990:	9101c281 	add	x1, x20, #0x70
    6994:	f9407833 	ldr	x19, [x1, #240]
    6998:	b4000333 	cbz	x19, 69fc <fwp_free_zombie+0x7c>
    699c:	f9400820 	ldr	x0, [x1, #16]
    69a0:	eb00027f 	cmp	x19, x0
    69a4:	540002c0 	b.eq	69fc <fwp_free_zombie+0x7c>  // b.none
    69a8:	b940f822 	ldr	w2, [x1, #248]
    69ac:	f9400a60 	ldr	x0, [x19, #16]
    69b0:	7100fc5f 	cmp	w2, #0x3f
    69b4:	5400078c 	b.gt	6aa4 <fwp_free_zombie+0x124>
    69b8:	91040023 	add	x3, x1, #0x100
    69bc:	11000444 	add	w4, w2, #0x1
    69c0:	b900f824 	str	w4, [x1, #248]
    69c4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    69c8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    69cc:	a9530261 	ldp	x1, x0, [x19, #304]
    69d0:	b4000741 	cbz	x1, 6ab8 <fwp_free_zombie+0x138>
    69d4:	f9009c20 	str	x0, [x1, #312]
    69d8:	b4000040 	cbz	x0, 69e0 <fwp_free_zombie+0x60>
    69dc:	f9009801 	str	x1, [x0, #304]
    69e0:	9101c294 	add	x20, x20, #0x70
    69e4:	b9405e60 	ldr	w0, [x19, #92]
    69e8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    69ec:	f9007a9f 	str	xzr, [x20, #240]
    69f0:	34000140 	cbz	w0, 6a18 <fwp_free_zombie+0x98>
    69f4:	7100041f 	cmp	w0, #0x1
    69f8:	54000080 	b.eq	6a08 <fwp_free_zombie+0x88>  // b.none
    69fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a04:	d65f03c0 	ret
    6a08:	aa1303e0 	mov	x0, x19
    6a0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a14:	17ffff9b 	b	6880 <fwp_task_dispose>
    6a18:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xc10>
    6a1c:	91174082 	add	x2, x4, #0x5d0
    6a20:	f949d841 	ldr	x1, [x2, #5040]
    6a24:	f949ec40 	ldr	x0, [x2, #5080]
    6a28:	cb010261 	sub	x1, x19, x1
    6a2c:	eb00403f 	cmp	x1, x0, lsl #16
    6a30:	54fffe62 	b.cs	69fc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6a34:	d350fc20 	lsr	x0, x1, #16
    6a38:	f949fc43 	ldr	x3, [x2, #5112]
    6a3c:	8b000800 	add	x0, x0, x0, lsl #2
    6a40:	d37df000 	lsl	x0, x0, #3
    6a44:	8b000062 	add	x2, x3, x0
    6a48:	f9401054 	ldr	x20, [x2, #32]
    6a4c:	b4fffd94 	cbz	x20, 69fc <fwp_free_zombie+0x7c>
    6a50:	38606860 	ldrb	w0, [x3, x0]
    6a54:	7100081f 	cmp	w0, #0x2
    6a58:	54000360 	b.eq	6ac4 <fwp_free_zombie+0x144>  // b.none
    6a5c:	7100041f 	cmp	w0, #0x1
    6a60:	54fffce1 	b.ne	69fc <fwp_free_zombie+0x7c>  // b.any
    6a64:	29430043 	ldp	w3, w0, [x2, #24]
    6a68:	92403c21 	and	x1, x1, #0xffff
    6a6c:	9b037c21 	mul	x1, x1, x3
    6a70:	d360fc21 	lsr	x1, x1, #32
    6a74:	eb00003f 	cmp	x1, x0
    6a78:	54fffc22 	b.cs	69fc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6a7c:	8b010294 	add	x20, x20, x1
    6a80:	39400280 	ldrb	w0, [x20]
    6a84:	34fffbc0 	cbz	w0, 69fc <fwp_free_zombie+0x7c>
    6a88:	7100041f 	cmp	w0, #0x1
    6a8c:	54fffbe0 	b.eq	6a08 <fwp_free_zombie+0x88>  // b.none
    6a90:	7103fc1f 	cmp	w0, #0xff
    6a94:	540001e0 	b.eq	6ad0 <fwp_free_zombie+0x150>  // b.none
    6a98:	51000400 	sub	w0, w0, #0x1
    6a9c:	39000280 	strb	w0, [x20]
    6aa0:	17ffffd7 	b	69fc <fwp_free_zombie+0x7c>
    6aa4:	f9400e61 	ldr	x1, [x19, #24]
    6aa8:	97ffefe2 	bl	2a30 <munmap@plt>
    6aac:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6ab0:	a9530261 	ldp	x1, x0, [x19, #304]
    6ab4:	b5fff901 	cbnz	x1, 69d4 <fwp_free_zombie+0x54>
    6ab8:	9101c282 	add	x2, x20, #0x70
    6abc:	f9018040 	str	x0, [x2, #768]
    6ac0:	17ffffc6 	b	69d8 <fwp_free_zombie+0x58>
    6ac4:	72003c3f 	tst	w1, #0xffff
    6ac8:	54fff9a1 	b.ne	69fc <fwp_free_zombie+0x7c>  // b.any
    6acc:	17ffffed 	b	6a80 <fwp_free_zombie+0x100>
    6ad0:	ca544680 	eor	x0, x20, x20, lsr #17
    6ad4:	91174084 	add	x4, x4, #0x5d0
    6ad8:	ca402400 	eor	x0, x0, x0, lsr #9
    6adc:	92401c00 	and	x0, x0, #0xff
    6ae0:	910a2402 	add	x2, x0, #0x289
    6ae4:	8b000c80 	add	x0, x4, x0, lsl #3
    6ae8:	8b020c82 	add	x2, x4, x2, lsl #3
    6aec:	f94a2400 	ldr	x0, [x0, #5192]
    6af0:	b50000a0 	cbnz	x0, 6b04 <fwp_free_zombie+0x184>
    6af4:	14000013 	b	6b40 <fwp_free_zombie+0x1c0>
    6af8:	91004002 	add	x2, x0, #0x10
    6afc:	f9400800 	ldr	x0, [x0, #16]
    6b00:	b4000200 	cbz	x0, 6b40 <fwp_free_zombie+0x1c0>
    6b04:	f9400001 	ldr	x1, [x0]
    6b08:	eb14003f 	cmp	x1, x20
    6b0c:	54ffff61 	b.ne	6af8 <fwp_free_zombie+0x178>  // b.any
    6b10:	f9400041 	ldr	x1, [x2]
    6b14:	f9400420 	ldr	x0, [x1, #8]
    6b18:	d1000400 	sub	x0, x0, #0x1
    6b1c:	f9000420 	str	x0, [x1, #8]
    6b20:	f103f81f 	cmp	x0, #0xfe
    6b24:	54fff6c1 	b.ne	69fc <fwp_free_zombie+0x7c>  // b.any
    6b28:	39400280 	ldrb	w0, [x20]
    6b2c:	7103fc1f 	cmp	w0, #0xff
    6b30:	540000e0 	b.eq	6b4c <fwp_free_zombie+0x1cc>  // b.none
    6b34:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6b38:	39000280 	strb	w0, [x20]
    6b3c:	17ffffb0 	b	69fc <fwp_free_zombie+0x7c>
    6b40:	f0000020 	adrp	x0, d000 <__divti3+0x320>
    6b44:	9117e000 	add	x0, x0, #0x5f8
    6b48:	97fff592 	bl	4190 <fwp_trap>
    6b4c:	aa1403e0 	mov	x0, x20
    6b50:	97fff5b0 	bl	4210 <fwp_rc_forget_slot.part.0>
    6b54:	17fffff8 	b	6b34 <fwp_free_zombie+0x1b4>
    6b58:	d503201f 	nop
    6b5c:	d503201f 	nop

0000000000006b60 <fwp_block>:
    6b60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6b64:	910003fd 	mov	x29, sp
    6b68:	a90153f3 	stp	x19, x20, [sp, #16]
    6b6c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6b70:	9101c274 	add	x20, x19, #0x70
    6b74:	f9404282 	ldr	x2, [x20, #128]
    6b78:	b4000642 	cbz	x2, 6c40 <fwp_block+0xe0>
    6b7c:	9101c261 	add	x1, x19, #0x70
    6b80:	f9408040 	ldr	x0, [x2, #256]
    6b84:	f9004020 	str	x0, [x1, #128]
    6b88:	b40006a0 	cbz	x0, 6c5c <fwp_block+0xfc>
    6b8c:	d503201f 	nop
    6b90:	9101c263 	add	x3, x19, #0x70
    6b94:	3901505f 	strb	wzr, [x2, #84]
    6b98:	f9400864 	ldr	x4, [x3, #16]
    6b9c:	eb02009f 	cmp	x4, x2
    6ba0:	54000440 	b.eq	6c28 <fwp_block+0xc8>  // b.none
    6ba4:	f9418465 	ldr	x5, [x3, #776]
    6ba8:	f9000862 	str	x2, [x3, #16]
    6bac:	f9400441 	ldr	x1, [x2, #8]
    6bb0:	f9004885 	str	x5, [x4, #144]
    6bb4:	f9418865 	ldr	x5, [x3, #784]
    6bb8:	f9004c85 	str	x5, [x4, #152]
    6bbc:	f9418c65 	ldr	x5, [x3, #792]
    6bc0:	f9005085 	str	x5, [x4, #160]
    6bc4:	f9419065 	ldr	x5, [x3, #800]
    6bc8:	f9005485 	str	x5, [x4, #168]
    6bcc:	f9419465 	ldr	x5, [x3, #808]
    6bd0:	f9005885 	str	x5, [x4, #176]
    6bd4:	f9419865 	ldr	x5, [x3, #816]
    6bd8:	f9005c85 	str	x5, [x4, #184]
    6bdc:	f9419c65 	ldr	x5, [x3, #824]
    6be0:	f9006085 	str	x5, [x4, #192]
    6be4:	f9400480 	ldr	x0, [x4, #8]
    6be8:	f9404844 	ldr	x4, [x2, #144]
    6bec:	f9018464 	str	x4, [x3, #776]
    6bf0:	f9404c44 	ldr	x4, [x2, #152]
    6bf4:	f9018864 	str	x4, [x3, #784]
    6bf8:	f9405044 	ldr	x4, [x2, #160]
    6bfc:	f9018c64 	str	x4, [x3, #792]
    6c00:	f9405444 	ldr	x4, [x2, #168]
    6c04:	f9019064 	str	x4, [x3, #800]
    6c08:	f9405844 	ldr	x4, [x2, #176]
    6c0c:	f9019464 	str	x4, [x3, #808]
    6c10:	a94b8844 	ldp	x4, x2, [x2, #184]
    6c14:	f9019864 	str	x4, [x3, #816]
    6c18:	f9019c62 	str	x2, [x3, #824]
    6c1c:	97ffef55 	bl	2970 <swapcontext@plt>
    6c20:	97ffff58 	bl	6980 <fwp_free_zombie>
    6c24:	d503201f 	nop
    6c28:	9101c260 	add	x0, x19, #0x70
    6c2c:	b9434000 	ldr	w0, [x0, #832]
    6c30:	340001a0 	cbz	w0, 6c64 <fwp_block+0x104>
    6c34:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c38:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c3c:	d65f03c0 	ret
    6c40:	97fff79c 	bl	4ab0 <fwp_poll_events>
    6c44:	f9404282 	ldr	x2, [x20, #128]
    6c48:	b4ffffc2 	cbz	x2, 6c40 <fwp_block+0xe0>
    6c4c:	9101c261 	add	x1, x19, #0x70
    6c50:	f9408040 	ldr	x0, [x2, #256]
    6c54:	f9004020 	str	x0, [x1, #128]
    6c58:	b5fff9c0 	cbnz	x0, 6b90 <fwp_block+0x30>
    6c5c:	f9003c3f 	str	xzr, [x1, #120]
    6c60:	17ffffcc 	b	6b90 <fwp_block+0x30>
    6c64:	f0000020 	adrp	x0, d000 <__divti3+0x320>
    6c68:	91224000 	add	x0, x0, #0x890
    6c6c:	97ffef8d 	bl	2aa0 <getenv@plt>
    6c70:	5284e202 	mov	w2, #0x2710                	// #10000
    6c74:	b4000060 	cbz	x0, 6c80 <fwp_block+0x120>
    6c78:	39400001 	ldrb	w1, [x0]
    6c7c:	350000c1 	cbnz	w1, 6c94 <fwp_block+0x134>
    6c80:	9101c273 	add	x19, x19, #0x70
    6c84:	b9034262 	str	w2, [x19, #832]
    6c88:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6c90:	d65f03c0 	ret
    6c94:	52800142 	mov	w2, #0xa                   	// #10
    6c98:	d2800001 	mov	x1, #0x0                   	// #0
    6c9c:	97ffeed1 	bl	27e0 <strtoll@plt>
    6ca0:	d1000403 	sub	x3, x0, #0x1
    6ca4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6ca8:	eb02007f 	cmp	x3, x2
    6cac:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6cb0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6cb4:	17fffff3 	b	6c80 <fwp_block+0x120>
    6cb8:	d503201f 	nop
    6cbc:	d503201f 	nop

0000000000006cc0 <fwp_drop10>:
    6cc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6cc4:	910003fd 	mov	x29, sp
    6cc8:	a90153f3 	stp	x19, x20, [sp, #16]
    6ccc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xc10>
    6cd0:	f90013f5 	str	x21, [sp, #32]
    6cd4:	91174275 	add	x21, x19, #0x5d0
    6cd8:	f949daa1 	ldr	x1, [x21, #5040]
    6cdc:	f949eea2 	ldr	x2, [x21, #5080]
    6ce0:	cb010001 	sub	x1, x0, x1
    6ce4:	eb02403f 	cmp	x1, x2, lsl #16
    6ce8:	54000382 	b.cs	6d58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6cec:	d350fc22 	lsr	x2, x1, #16
    6cf0:	f949fea3 	ldr	x3, [x21, #5112]
    6cf4:	8b020842 	add	x2, x2, x2, lsl #2
    6cf8:	d37df042 	lsl	x2, x2, #3
    6cfc:	8b020064 	add	x4, x3, x2
    6d00:	f9401094 	ldr	x20, [x4, #32]
    6d04:	b40002b4 	cbz	x20, 6d58 <fwp_drop10+0x98>
    6d08:	38626862 	ldrb	w2, [x3, x2]
    6d0c:	7100085f 	cmp	w2, #0x2
    6d10:	540007a0 	b.eq	6e04 <fwp_drop10+0x144>  // b.none
    6d14:	7100045f 	cmp	w2, #0x1
    6d18:	54000201 	b.ne	6d58 <fwp_drop10+0x98>  // b.any
    6d1c:	29430885 	ldp	w5, w2, [x4, #24]
    6d20:	92403c21 	and	x1, x1, #0xffff
    6d24:	9b057c21 	mul	x1, x1, x5
    6d28:	d360fc21 	lsr	x1, x1, #32
    6d2c:	eb02003f 	cmp	x1, x2
    6d30:	54000142 	b.cs	6d58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d34:	8b010294 	add	x20, x20, x1
    6d38:	39400281 	ldrb	w1, [x20]
    6d3c:	340000e1 	cbz	w1, 6d58 <fwp_drop10+0x98>
    6d40:	7100043f 	cmp	w1, #0x1
    6d44:	54000120 	b.eq	6d68 <fwp_drop10+0xa8>  // b.none
    6d48:	7103fc3f 	cmp	w1, #0xff
    6d4c:	540007c0 	b.eq	6e44 <fwp_drop10+0x184>  // b.none
    6d50:	51000421 	sub	w1, w1, #0x1
    6d54:	39000281 	strb	w1, [x20]
    6d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d5c:	f94013f5 	ldr	x21, [sp, #32]
    6d60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6d64:	d65f03c0 	ret
    6d68:	f9400001 	ldr	x1, [x0]
    6d6c:	b7f80581 	tbnz	x1, #63, 6e1c <fwp_drop10+0x15c>
    6d70:	91174273 	add	x19, x19, #0x5d0
    6d74:	f949da61 	ldr	x1, [x19, #5040]
    6d78:	f949ee62 	ldr	x2, [x19, #5080]
    6d7c:	cb010001 	sub	x1, x0, x1
    6d80:	eb02403f 	cmp	x1, x2, lsl #16
    6d84:	54fffea2 	b.cs	6d58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6d88:	d350fc22 	lsr	x2, x1, #16
    6d8c:	8b020842 	add	x2, x2, x2, lsl #2
    6d90:	d37df042 	lsl	x2, x2, #3
    6d94:	8b020065 	add	x5, x3, x2
    6d98:	f94010a4 	ldr	x4, [x5, #32]
    6d9c:	b4fffde4 	cbz	x4, 6d58 <fwp_drop10+0x98>
    6da0:	38626862 	ldrb	w2, [x3, x2]
    6da4:	7100085f 	cmp	w2, #0x2
    6da8:	54000220 	b.eq	6dec <fwp_drop10+0x12c>  // b.none
    6dac:	7100045f 	cmp	w2, #0x1
    6db0:	54fffd41 	b.ne	6d58 <fwp_drop10+0x98>  // b.any
    6db4:	294308a3 	ldp	w3, w2, [x5, #24]
    6db8:	92403c21 	and	x1, x1, #0xffff
    6dbc:	9b037c21 	mul	x1, x1, x3
    6dc0:	d360fc21 	lsr	x1, x1, #32
    6dc4:	eb02003f 	cmp	x1, x2
    6dc8:	54fffc82 	b.cs	6d58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6dcc:	8b010084 	add	x4, x4, x1
    6dd0:	39400081 	ldrb	w1, [x4]
    6dd4:	7100043f 	cmp	w1, #0x1
    6dd8:	54fffc01 	b.ne	6d58 <fwp_drop10+0x98>  // b.any
    6ddc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6de0:	f94013f5 	ldr	x21, [sp, #32]
    6de4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6de8:	17fff5a6 	b	4480 <fwp_mem_free>
    6dec:	72003c3f 	tst	w1, #0xffff
    6df0:	54ffff00 	b.eq	6dd0 <fwp_drop10+0x110>  // b.none
    6df4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6df8:	f94013f5 	ldr	x21, [sp, #32]
    6dfc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e00:	d65f03c0 	ret
    6e04:	72003c3f 	tst	w1, #0xffff
    6e08:	54fff980 	b.eq	6d38 <fwp_drop10+0x78>  // b.none
    6e0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e10:	f94013f5 	ldr	x21, [sp, #32]
    6e14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e18:	d65f03c0 	ret
    6e1c:	f9400414 	ldr	x20, [x0, #8]
    6e20:	97fffb28 	bl	5ac0 <fwp_rc_free_arr>
    6e24:	91174260 	add	x0, x19, #0x5d0
    6e28:	f949d801 	ldr	x1, [x0, #5040]
    6e2c:	f949ec00 	ldr	x0, [x0, #5080]
    6e30:	cb010281 	sub	x1, x20, x1
    6e34:	eb00403f 	cmp	x1, x0, lsl #16
    6e38:	54fff902 	b.cs	6d58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6e3c:	aa1403e0 	mov	x0, x20
    6e40:	17ffffab 	b	6cec <fwp_drop10+0x2c>
    6e44:	ca544680 	eor	x0, x20, x20, lsr #17
    6e48:	91174273 	add	x19, x19, #0x5d0
    6e4c:	ca402400 	eor	x0, x0, x0, lsr #9
    6e50:	92401c00 	and	x0, x0, #0xff
    6e54:	910a2402 	add	x2, x0, #0x289
    6e58:	8b000e60 	add	x0, x19, x0, lsl #3
    6e5c:	8b020e62 	add	x2, x19, x2, lsl #3
    6e60:	f94a2400 	ldr	x0, [x0, #5192]
    6e64:	b50000a0 	cbnz	x0, 6e78 <fwp_drop10+0x1b8>
    6e68:	14000013 	b	6eb4 <fwp_drop10+0x1f4>
    6e6c:	91004002 	add	x2, x0, #0x10
    6e70:	f9400800 	ldr	x0, [x0, #16]
    6e74:	b4000200 	cbz	x0, 6eb4 <fwp_drop10+0x1f4>
    6e78:	f9400001 	ldr	x1, [x0]
    6e7c:	eb14003f 	cmp	x1, x20
    6e80:	54ffff61 	b.ne	6e6c <fwp_drop10+0x1ac>  // b.any
    6e84:	f9400041 	ldr	x1, [x2]
    6e88:	f9400420 	ldr	x0, [x1, #8]
    6e8c:	d1000400 	sub	x0, x0, #0x1
    6e90:	f9000420 	str	x0, [x1, #8]
    6e94:	f103f81f 	cmp	x0, #0xfe
    6e98:	54fff601 	b.ne	6d58 <fwp_drop10+0x98>  // b.any
    6e9c:	39400280 	ldrb	w0, [x20]
    6ea0:	7103fc1f 	cmp	w0, #0xff
    6ea4:	540000e0 	b.eq	6ec0 <fwp_drop10+0x200>  // b.none
    6ea8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6eac:	39000280 	strb	w0, [x20]
    6eb0:	17ffffaa 	b	6d58 <fwp_drop10+0x98>
    6eb4:	f0000020 	adrp	x0, d000 <__divti3+0x320>
    6eb8:	9117e000 	add	x0, x0, #0x5f8
    6ebc:	97fff4b5 	bl	4190 <fwp_trap>
    6ec0:	aa1403e0 	mov	x0, x20
    6ec4:	97fff4d3 	bl	4210 <fwp_rc_forget_slot.part.0>
    6ec8:	17fffff8 	b	6ea8 <fwp_drop10+0x1e8>
    6ecc:	d503201f 	nop

0000000000006ed0 <fwp_caps173>:
    6ed0:	34000041 	cbz	w1, 6ed8 <fwp_caps173+0x8>
    6ed4:	d65f03c0 	ret
    6ed8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xc10>
    6edc:	91174063 	add	x3, x3, #0x5d0
    6ee0:	f949d861 	ldr	x1, [x3, #5040]
    6ee4:	f949ec62 	ldr	x2, [x3, #5080]
    6ee8:	cb010001 	sub	x1, x0, x1
    6eec:	eb02403f 	cmp	x1, x2, lsl #16
    6ef0:	54ffff22 	b.cs	6ed4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6ef4:	d350fc22 	lsr	x2, x1, #16
    6ef8:	f949fc65 	ldr	x5, [x3, #5112]
    6efc:	8b020842 	add	x2, x2, x2, lsl #2
    6f00:	d37df042 	lsl	x2, x2, #3
    6f04:	8b0200a4 	add	x4, x5, x2
    6f08:	f9401083 	ldr	x3, [x4, #32]
    6f0c:	b4fffe43 	cbz	x3, 6ed4 <fwp_caps173+0x4>
    6f10:	386268a2 	ldrb	w2, [x5, x2]
    6f14:	7100085f 	cmp	w2, #0x2
    6f18:	540001c0 	b.eq	6f50 <fwp_caps173+0x80>  // b.none
    6f1c:	7100045f 	cmp	w2, #0x1
    6f20:	54fffda1 	b.ne	6ed4 <fwp_caps173+0x4>  // b.any
    6f24:	29430885 	ldp	w5, w2, [x4, #24]
    6f28:	92403c21 	and	x1, x1, #0xffff
    6f2c:	9b057c21 	mul	x1, x1, x5
    6f30:	d360fc21 	lsr	x1, x1, #32
    6f34:	eb02003f 	cmp	x1, x2
    6f38:	54fffce2 	b.cs	6ed4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6f3c:	8b010063 	add	x3, x3, x1
    6f40:	39400061 	ldrb	w1, [x3]
    6f44:	7100043f 	cmp	w1, #0x1
    6f48:	54fffc61 	b.ne	6ed4 <fwp_caps173+0x4>  // b.any
    6f4c:	17fff54d 	b	4480 <fwp_mem_free>
    6f50:	72003c3f 	tst	w1, #0xffff
    6f54:	54ffff60 	b.eq	6f40 <fwp_caps173+0x70>  // b.none
    6f58:	d65f03c0 	ret
    6f5c:	d503201f 	nop

0000000000006f60 <fwp_args37>:
    6f60:	7100003f 	cmp	w1, #0x0
    6f64:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6f68:	54000041 	b.ne	6f70 <fwp_args37+0x10>  // b.any
    6f6c:	d65f03c0 	ret
    6f70:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    6f74:	91174042 	add	x2, x2, #0x5d0
    6f78:	f9400001 	ldr	x1, [x0]
    6f7c:	f949d843 	ldr	x3, [x2, #5040]
    6f80:	f949ec40 	ldr	x0, [x2, #5080]
    6f84:	cb030021 	sub	x1, x1, x3
    6f88:	eb00403f 	cmp	x1, x0, lsl #16
    6f8c:	54ffff02 	b.cs	6f6c <fwp_args37+0xc>  // b.hs, b.nlast
    6f90:	d350fc20 	lsr	x0, x1, #16
    6f94:	f949fc44 	ldr	x4, [x2, #5112]
    6f98:	8b000800 	add	x0, x0, x0, lsl #2
    6f9c:	d37df002 	lsl	x2, x0, #3
    6fa0:	8b020083 	add	x3, x4, x2
    6fa4:	f9401060 	ldr	x0, [x3, #32]
    6fa8:	b4fffe20 	cbz	x0, 6f6c <fwp_args37+0xc>
    6fac:	38626882 	ldrb	w2, [x4, x2]
    6fb0:	7100085f 	cmp	w2, #0x2
    6fb4:	54000220 	b.eq	6ff8 <fwp_args37+0x98>  // b.none
    6fb8:	7100045f 	cmp	w2, #0x1
    6fbc:	54fffd81 	b.ne	6f6c <fwp_args37+0xc>  // b.any
    6fc0:	29430864 	ldp	w4, w2, [x3, #24]
    6fc4:	92403c21 	and	x1, x1, #0xffff
    6fc8:	9b047c21 	mul	x1, x1, x4
    6fcc:	d360fc21 	lsr	x1, x1, #32
    6fd0:	eb02003f 	cmp	x1, x2
    6fd4:	54fffcc2 	b.cs	6f6c <fwp_args37+0xc>  // b.hs, b.nlast
    6fd8:	8b010000 	add	x0, x0, x1
    6fdc:	39400001 	ldrb	w1, [x0]
    6fe0:	34fffc61 	cbz	w1, 6f6c <fwp_args37+0xc>
    6fe4:	7103f43f 	cmp	w1, #0xfd
    6fe8:	540000e8 	b.hi	7004 <fwp_args37+0xa4>  // b.pmore
    6fec:	11000421 	add	w1, w1, #0x1
    6ff0:	39000001 	strb	w1, [x0]
    6ff4:	d65f03c0 	ret
    6ff8:	72003c3f 	tst	w1, #0xffff
    6ffc:	54ffff00 	b.eq	6fdc <fwp_args37+0x7c>  // b.none
    7000:	d65f03c0 	ret
    7004:	17fff598 	b	4664 <fwp_rc_wide_dup>
    7008:	d503201f 	nop
    700c:	d503201f 	nop

0000000000007010 <fwp_caps37>:
    7010:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7014:	910003fd 	mov	x29, sp
    7018:	f9000bf3 	str	x19, [sp, #16]
    701c:	aa0003f3 	mov	x19, x0
    7020:	b9400400 	ldr	w0, [x0, #4]
    7024:	340004a0 	cbz	w0, 70b8 <fwp_caps37+0xa8>
    7028:	f9400660 	ldr	x0, [x19, #8]
    702c:	350004e1 	cbnz	w1, 70c8 <fwp_caps37+0xb8>
    7030:	97fffd68 	bl	65d0 <fwp_drop4>
    7034:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    7038:	91174042 	add	x2, x2, #0x5d0
    703c:	f949d840 	ldr	x0, [x2, #5040]
    7040:	f949ec41 	ldr	x1, [x2, #5080]
    7044:	cb000260 	sub	x0, x19, x0
    7048:	eb01401f 	cmp	x0, x1, lsl #16
    704c:	54000382 	b.cs	70bc <fwp_caps37+0xac>  // b.hs, b.nlast
    7050:	d350fc01 	lsr	x1, x0, #16
    7054:	f949fc44 	ldr	x4, [x2, #5112]
    7058:	8b010821 	add	x1, x1, x1, lsl #2
    705c:	d37df021 	lsl	x1, x1, #3
    7060:	8b010083 	add	x3, x4, x1
    7064:	f9401062 	ldr	x2, [x3, #32]
    7068:	b40002a2 	cbz	x2, 70bc <fwp_caps37+0xac>
    706c:	38616881 	ldrb	w1, [x4, x1]
    7070:	7100083f 	cmp	w1, #0x2
    7074:	540006c0 	b.eq	714c <fwp_caps37+0x13c>  // b.none
    7078:	7100043f 	cmp	w1, #0x1
    707c:	54000201 	b.ne	70bc <fwp_caps37+0xac>  // b.any
    7080:	29430464 	ldp	w4, w1, [x3, #24]
    7084:	92403c00 	and	x0, x0, #0xffff
    7088:	9b047c00 	mul	x0, x0, x4
    708c:	d360fc00 	lsr	x0, x0, #32
    7090:	eb01001f 	cmp	x0, x1
    7094:	54000142 	b.cs	70bc <fwp_caps37+0xac>  // b.hs, b.nlast
    7098:	8b000042 	add	x2, x2, x0
    709c:	39400040 	ldrb	w0, [x2]
    70a0:	7100041f 	cmp	w0, #0x1
    70a4:	540000c1 	b.ne	70bc <fwp_caps37+0xac>  // b.any
    70a8:	aa1303e0 	mov	x0, x19
    70ac:	f9400bf3 	ldr	x19, [sp, #16]
    70b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    70b4:	17fff4f3 	b	4480 <fwp_mem_free>
    70b8:	34fffbe1 	cbz	w1, 7034 <fwp_caps37+0x24>
    70bc:	f9400bf3 	ldr	x19, [sp, #16]
    70c0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    70c4:	d65f03c0 	ret
    70c8:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xc10>
    70cc:	91174042 	add	x2, x2, #0x5d0
    70d0:	f949d843 	ldr	x3, [x2, #5040]
    70d4:	f949ec41 	ldr	x1, [x2, #5080]
    70d8:	cb030000 	sub	x0, x0, x3
    70dc:	eb01401f 	cmp	x0, x1, lsl #16
    70e0:	54fffee2 	b.cs	70bc <fwp_caps37+0xac>  // b.hs, b.nlast
    70e4:	d350fc01 	lsr	x1, x0, #16
    70e8:	f949fc44 	ldr	x4, [x2, #5112]
    70ec:	8b010821 	add	x1, x1, x1, lsl #2
    70f0:	d37df021 	lsl	x1, x1, #3
    70f4:	8b010083 	add	x3, x4, x1
    70f8:	f9401062 	ldr	x2, [x3, #32]
    70fc:	b4fffe02 	cbz	x2, 70bc <fwp_caps37+0xac>
    7100:	38616881 	ldrb	w1, [x4, x1]
    7104:	7100083f 	cmp	w1, #0x2
    7108:	54000280 	b.eq	7158 <fwp_caps37+0x148>  // b.none
    710c:	7100043f 	cmp	w1, #0x1
    7110:	54fffd61 	b.ne	70bc <fwp_caps37+0xac>  // b.any
    7114:	92403c01 	and	x1, x0, #0xffff
    7118:	29430064 	ldp	w4, w0, [x3, #24]
    711c:	9b047c21 	mul	x1, x1, x4
    7120:	d360fc21 	lsr	x1, x1, #32
    7124:	eb00003f 	cmp	x1, x0
    7128:	54fffca2 	b.cs	70bc <fwp_caps37+0xac>  // b.hs, b.nlast
    712c:	8b010042 	add	x2, x2, x1
    7130:	39400040 	ldrb	w0, [x2]
    7134:	34fffc40 	cbz	w0, 70bc <fwp_caps37+0xac>
    7138:	7103f41f 	cmp	w0, #0xfd
    713c:	54000148 	b.hi	7164 <fwp_caps37+0x154>  // b.pmore
    7140:	11000400 	add	w0, w0, #0x1
    7144:	39000040 	strb	w0, [x2]
    7148:	17ffffdd 	b	70bc <fwp_caps37+0xac>
    714c:	72003c1f 	tst	w0, #0xffff
    7150:	54fffb61 	b.ne	70bc <fwp_caps37+0xac>  // b.any
    7154:	17ffffd2 	b	709c <fwp_caps37+0x8c>
    7158:	72003c1f 	tst	w0, #0xffff
    715c:	54fffb01 	b.ne	70bc <fwp_caps37+0xac>  // b.any
    7160:	17fffff4 	b	7130 <fwp_caps37+0x120>
    7164:	f9400bf3 	ldr	x19, [sp, #16]
    7168:	aa0203e0 	mov	x0, x2
    716c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7170:	17fff53d 	b	4664 <fwp_rc_wide_dup>

0000000000007174 <f37>:
    7174:	d10203ff 	sub	sp, sp, #0x80
    7178:	900000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    717c:	f947f421 	ldr	x1, [x1, #4072]
    7180:	a9027bfd 	stp	x29, x30, [sp, #32]
    7184:	910083fd 	add	x29, sp, #0x20
    7188:	a9045bf5 	stp	x21, x22, [sp, #64]
    718c:	d0000155 	adrp	x21, 31000 <fwp_root_context+0xc10>
    7190:	911742a3 	add	x3, x21, #0x5d0
    7194:	a90353f3 	stp	x19, x20, [sp, #48]
    7198:	aa0003f6 	mov	x22, x0
    719c:	a90563f7 	stp	x23, x24, [sp, #80]
    71a0:	a9066bf9 	stp	x25, x26, [sp, #96]
    71a4:	f949ec62 	ldr	x2, [x3, #5080]
    71a8:	f9400024 	ldr	x4, [x1]
    71ac:	f9000fe4 	str	x4, [sp, #24]
    71b0:	d2800004 	mov	x4, #0x0                   	// #0
    71b4:	f949d861 	ldr	x1, [x3, #5040]
    71b8:	d370bc42 	lsl	x2, x2, #16
    71bc:	b4001800 	cbz	x0, 74bc <f37+0x348>
    71c0:	f9400817 	ldr	x23, [x0, #16]
    71c4:	cb0102e1 	sub	x1, x23, x1
    71c8:	eb02003f 	cmp	x1, x2
    71cc:	54000362 	b.cs	7238 <f37+0xc4>  // b.hs, b.nlast
    71d0:	f949fc60 	ldr	x0, [x3, #5112]
    71d4:	d350fc22 	lsr	x2, x1, #16
    71d8:	8b020842 	add	x2, x2, x2, lsl #2
    71dc:	8b020c02 	add	x2, x0, x2, lsl #3
    71e0:	f9401040 	ldr	x0, [x2, #32]
    71e4:	b40002a0 	cbz	x0, 7238 <f37+0xc4>
    71e8:	39400043 	ldrb	w3, [x2]
    71ec:	7100087f 	cmp	w3, #0x2
    71f0:	54001540 	b.eq	7498 <f37+0x324>  // b.none
    71f4:	7100047f 	cmp	w3, #0x1
    71f8:	540001c1 	b.ne	7230 <f37+0xbc>  // b.any
    71fc:	29430843 	ldp	w3, w2, [x2, #24]
    7200:	92403c21 	and	x1, x1, #0xffff
    7204:	9b037c21 	mul	x1, x1, x3
    7208:	d360fc21 	lsr	x1, x1, #32
    720c:	eb02003f 	cmp	x1, x2
    7210:	54000102 	b.cs	7230 <f37+0xbc>  // b.hs, b.nlast
    7214:	8b010000 	add	x0, x0, x1
    7218:	39400001 	ldrb	w1, [x0]
    721c:	340000a1 	cbz	w1, 7230 <f37+0xbc>
    7220:	7103f43f 	cmp	w1, #0xfd
    7224:	540017e8 	b.hi	7520 <f37+0x3ac>  // b.pmore
    7228:	11000421 	add	w1, w1, #0x1
    722c:	39000001 	strb	w1, [x0]
    7230:	d2800002 	mov	x2, #0x0                   	// #0
    7234:	b40000d6 	cbz	x22, 724c <f37+0xd8>
    7238:	aa1603e1 	mov	x1, x22
    723c:	d2800002 	mov	x2, #0x0                   	// #0
    7240:	f9400821 	ldr	x1, [x1, #16]
    7244:	91000442 	add	x2, x2, #0x1
    7248:	b5ffffc1 	cbnz	x1, 7240 <f37+0xcc>
    724c:	b40013f7 	cbz	x23, 74c8 <f37+0x354>
    7250:	aa1703e1 	mov	x1, x23
    7254:	d2800003 	mov	x3, #0x0                   	// #0
    7258:	f9400821 	ldr	x1, [x1, #16]
    725c:	91000463 	add	x3, x3, #0x1
    7260:	b5ffffc1 	cbnz	x1, 7258 <f37+0xe4>
    7264:	eb02007f 	cmp	x3, x2
    7268:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    726c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    7270:	eb00027f 	cmp	x19, x0
    7274:	540010a8 	b.hi	7488 <f37+0x314>  // b.pmore
    7278:	d37ffa74 	lsl	x20, x19, #1
    727c:	52800041 	mov	w1, #0x2                   	// #2
    7280:	91000680 	add	x0, x20, #0x1
    7284:	d37df000 	lsl	x0, x0, #3
    7288:	97fff73a 	bl	4f70 <fwp_heap_alloc>
    728c:	aa0003f8 	mov	x24, x0
    7290:	911742a1 	add	x1, x21, #0x5d0
    7294:	aa0103e0 	mov	x0, x1
    7298:	f9000314 	str	x20, [x24]
    729c:	f949d821 	ldr	x1, [x1, #5040]
    72a0:	f949ec00 	ldr	x0, [x0, #5080]
    72a4:	cb010301 	sub	x1, x24, x1
    72a8:	eb00403f 	cmp	x1, x0, lsl #16
    72ac:	54000342 	b.cs	7314 <f37+0x1a0>  // b.hs, b.nlast
    72b0:	911742a2 	add	x2, x21, #0x5d0
    72b4:	d350fc20 	lsr	x0, x1, #16
    72b8:	8b000800 	add	x0, x0, x0, lsl #2
    72bc:	f949fc43 	ldr	x3, [x2, #5112]
    72c0:	d37df002 	lsl	x2, x0, #3
    72c4:	8b020060 	add	x0, x3, x2
    72c8:	f9401014 	ldr	x20, [x0, #32]
    72cc:	b4000254 	cbz	x20, 7314 <f37+0x1a0>
    72d0:	38626862 	ldrb	w2, [x3, x2]
    72d4:	7100085f 	cmp	w2, #0x2
    72d8:	54000ec0 	b.eq	74b0 <f37+0x33c>  // b.none
    72dc:	7100045f 	cmp	w2, #0x1
    72e0:	540001a1 	b.ne	7314 <f37+0x1a0>  // b.any
    72e4:	29430002 	ldp	w2, w0, [x0, #24]
    72e8:	92403c21 	and	x1, x1, #0xffff
    72ec:	9b027c21 	mul	x1, x1, x2
    72f0:	d360fc21 	lsr	x1, x1, #32
    72f4:	eb00003f 	cmp	x1, x0
    72f8:	540000e2 	b.cs	7314 <f37+0x1a0>  // b.hs, b.nlast
    72fc:	8b010294 	add	x20, x20, x1
    7300:	39400280 	ldrb	w0, [x20]
    7304:	7103fc1f 	cmp	w0, #0xff
    7308:	54001100 	b.eq	7528 <f37+0x3b4>  // b.none
    730c:	52800020 	mov	w0, #0x1                   	// #1
    7310:	39000280 	strb	w0, [x20]
    7314:	b4000253 	cbz	x19, 735c <f37+0x1e8>
    7318:	8b131313 	add	x19, x24, x19, lsl #4
    731c:	aa1803f4 	mov	x20, x24
    7320:	aa1603fa 	mov	x26, x22
    7324:	aa1703f9 	mov	x25, x23
    7328:	f9400723 	ldr	x3, [x25, #8]
    732c:	f9400742 	ldr	x2, [x26, #8]
    7330:	f9400861 	ldr	x1, [x3, #16]
    7334:	f9400840 	ldr	x0, [x2, #16]
    7338:	fd400461 	ldr	d1, [x3, #8]
    733c:	fd400440 	ldr	d0, [x2, #8]
    7340:	97fff879 	bl	5524 <w120>
    7344:	f9000680 	str	x0, [x20, #8]
    7348:	f8010e81 	str	x1, [x20, #16]!
    734c:	f9400b39 	ldr	x25, [x25, #16]
    7350:	f9400b5a 	ldr	x26, [x26, #16]
    7354:	eb14027f 	cmp	x19, x20
    7358:	54fffe81 	b.ne	7328 <f37+0x1b4>  // b.any
    735c:	aa1703e0 	mov	x0, x23
    7360:	97fffc9c 	bl	65d0 <fwp_drop4>
    7364:	aa1603e0 	mov	x0, x22
    7368:	97fffc9a 	bl	65d0 <fwp_drop4>
    736c:	f9400316 	ldr	x22, [x24]
    7370:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7374:	b4000236 	cbz	x22, 73b8 <f37+0x244>
    7378:	fd003be8 	str	d8, [sp, #112]
    737c:	2f00e408 	movi	d8, #0x0
    7380:	91002319 	add	x25, x24, #0x8
    7384:	91004317 	add	x23, x24, #0x10
    7388:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    738c:	d2800013 	mov	x19, #0x0                   	// #0
    7390:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7394:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7398:	91000a73 	add	x19, x19, #0x2
    739c:	1e602908 	fadd	d8, d8, d0
    73a0:	97fff810 	bl	53e0 <f141.constprop.0>
    73a4:	aa0003f4 	mov	x20, x0
    73a8:	eb1302df 	cmp	x22, x19
    73ac:	54ffff28 	b.hi	7390 <f37+0x21c>  // b.pmore
    73b0:	9e660116 	fmov	x22, d8
    73b4:	fd403be8 	ldr	d8, [sp, #112]
    73b8:	911742b5 	add	x21, x21, #0x5d0
    73bc:	aa1803e0 	mov	x0, x24
    73c0:	97fffe40 	bl	6cc0 <fwp_drop10>
    73c4:	a900d3f6 	stp	x22, x20, [sp, #8]
    73c8:	910023e1 	add	x1, sp, #0x8
    73cc:	52800000 	mov	w0, #0x0                   	// #0
    73d0:	97fff72d 	bl	5084 <fwp_data.part.0.constprop.0>
    73d4:	f949daa1 	ldr	x1, [x21, #5040]
    73d8:	aa0003f3 	mov	x19, x0
    73dc:	f949eea0 	ldr	x0, [x21, #5080]
    73e0:	cb010261 	sub	x1, x19, x1
    73e4:	eb00403f 	cmp	x1, x0, lsl #16
    73e8:	54000322 	b.cs	744c <f37+0x2d8>  // b.hs, b.nlast
    73ec:	d350fc22 	lsr	x2, x1, #16
    73f0:	f949fea3 	ldr	x3, [x21, #5112]
    73f4:	8b020842 	add	x2, x2, x2, lsl #2
    73f8:	d37df042 	lsl	x2, x2, #3
    73fc:	8b020060 	add	x0, x3, x2
    7400:	f9401014 	ldr	x20, [x0, #32]
    7404:	b4000254 	cbz	x20, 744c <f37+0x2d8>
    7408:	38626862 	ldrb	w2, [x3, x2]
    740c:	7100085f 	cmp	w2, #0x2
    7410:	540004a0 	b.eq	74a4 <f37+0x330>  // b.none
    7414:	7100045f 	cmp	w2, #0x1
    7418:	540001a1 	b.ne	744c <f37+0x2d8>  // b.any
    741c:	29430002 	ldp	w2, w0, [x0, #24]
    7420:	92403c21 	and	x1, x1, #0xffff
    7424:	9b027c21 	mul	x1, x1, x2
    7428:	d360fc21 	lsr	x1, x1, #32
    742c:	eb00003f 	cmp	x1, x0
    7430:	540000e2 	b.cs	744c <f37+0x2d8>  // b.hs, b.nlast
    7434:	8b010294 	add	x20, x20, x1
    7438:	39400280 	ldrb	w0, [x20]
    743c:	7103fc1f 	cmp	w0, #0xff
    7440:	540007a0 	b.eq	7534 <f37+0x3c0>  // b.none
    7444:	52800020 	mov	w0, #0x1                   	// #1
    7448:	39000280 	strb	w0, [x20]
    744c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7450:	f947f400 	ldr	x0, [x0, #4072]
    7454:	f9400fe2 	ldr	x2, [sp, #24]
    7458:	f9400001 	ldr	x1, [x0]
    745c:	eb010042 	subs	x2, x2, x1
    7460:	d2800001 	mov	x1, #0x0                   	// #0
    7464:	54000721 	b.ne	7548 <f37+0x3d4>  // b.any
    7468:	a9427bfd 	ldp	x29, x30, [sp, #32]
    746c:	aa1303e0 	mov	x0, x19
    7470:	a94353f3 	ldp	x19, x20, [sp, #48]
    7474:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7478:	a94563f7 	ldp	x23, x24, [sp, #80]
    747c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7480:	910203ff 	add	sp, sp, #0x80
    7484:	d65f03c0 	ret
    7488:	d0000020 	adrp	x0, d000 <__divti3+0x320>
    748c:	91228000 	add	x0, x0, #0x8a0
    7490:	fd003be8 	str	d8, [sp, #112]
    7494:	97fff33f 	bl	4190 <fwp_trap>
    7498:	72003c3f 	tst	w1, #0xffff
    749c:	54ffeca1 	b.ne	7230 <f37+0xbc>  // b.any
    74a0:	17ffff5e 	b	7218 <f37+0xa4>
    74a4:	72003c3f 	tst	w1, #0xffff
    74a8:	54fffd21 	b.ne	744c <f37+0x2d8>  // b.any
    74ac:	17ffffe3 	b	7438 <f37+0x2c4>
    74b0:	72003c3f 	tst	w1, #0xffff
    74b4:	54fff301 	b.ne	7314 <f37+0x1a0>  // b.any
    74b8:	17ffff92 	b	7300 <f37+0x18c>
    74bc:	cb0103e1 	neg	x1, x1
    74c0:	eb02003f 	cmp	x1, x2
    74c4:	540001e3 	b.cc	7500 <f37+0x38c>  // b.lo, b.ul, b.last
    74c8:	52800041 	mov	w1, #0x2                   	// #2
    74cc:	d2800100 	mov	x0, #0x8                   	// #8
    74d0:	97fff6a8 	bl	4f70 <fwp_heap_alloc>
    74d4:	aa0003f8 	mov	x24, x0
    74d8:	911742a0 	add	x0, x21, #0x5d0
    74dc:	f900031f 	str	xzr, [x24]
    74e0:	f949d801 	ldr	x1, [x0, #5040]
    74e4:	f949ec00 	ldr	x0, [x0, #5080]
    74e8:	cb010301 	sub	x1, x24, x1
    74ec:	eb00403f 	cmp	x1, x0, lsl #16
    74f0:	54000282 	b.cs	7540 <f37+0x3cc>  // b.hs, b.nlast
    74f4:	d2800013 	mov	x19, #0x0                   	// #0
    74f8:	d2800017 	mov	x23, #0x0                   	// #0
    74fc:	17ffff6d 	b	72b0 <f37+0x13c>
    7500:	f949fc62 	ldr	x2, [x3, #5112]
    7504:	d350fc20 	lsr	x0, x1, #16
    7508:	8b000800 	add	x0, x0, x0, lsl #2
    750c:	8b000c42 	add	x2, x2, x0, lsl #3
    7510:	f9401040 	ldr	x0, [x2, #32]
    7514:	b4fffda0 	cbz	x0, 74c8 <f37+0x354>
    7518:	d2800017 	mov	x23, #0x0                   	// #0
    751c:	17ffff33 	b	71e8 <f37+0x74>
    7520:	97fff451 	bl	4664 <fwp_rc_wide_dup>
    7524:	17ffff43 	b	7230 <f37+0xbc>
    7528:	aa1403e0 	mov	x0, x20
    752c:	97fff339 	bl	4210 <fwp_rc_forget_slot.part.0>
    7530:	17ffff77 	b	730c <f37+0x198>
    7534:	aa1403e0 	mov	x0, x20
    7538:	97fff336 	bl	4210 <fwp_rc_forget_slot.part.0>
    753c:	17ffffc2 	b	7444 <f37+0x2d0>
    7540:	d2800017 	mov	x23, #0x0                   	// #0
    7544:	17ffff86 	b	735c <f37+0x1e8>
    7548:	fd003be8 	str	d8, [sp, #112]
    754c:	97ffecf1 	bl	2910 <__stack_chk_fail@plt>

0000000000007550 <fwp_owned_entry37>:
    7550:	f9400000 	ldr	x0, [x0]
    7554:	17ffff08 	b	7174 <f37>
    7558:	d503201f 	nop
    755c:	d503201f 	nop

0000000000007560 <e37>:
    7560:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7564:	910003fd 	mov	x29, sp
    7568:	f9000bf3 	str	x19, [sp, #16]
    756c:	f9400013 	ldr	x19, [x0]
    7570:	aa1303e0 	mov	x0, x19
    7574:	97fff8ff 	bl	5970 <fwp_rc_share>
    7578:	aa1303e0 	mov	x0, x19
    757c:	97fffefe 	bl	7174 <f37>
    7580:	aa0003f3 	mov	x19, x0
    7584:	97fff8fb 	bl	5970 <fwp_rc_share>
    7588:	aa1303e0 	mov	x0, x19
    758c:	f9400bf3 	ldr	x19, [sp, #16]
    7590:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7594:	d65f03c0 	ret
    7598:	d503201f 	nop
    759c:	d503201f 	nop

00000000000075a0 <fwp_write>:
    75a0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    75a4:	910003fd 	mov	x29, sp
    75a8:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    75ac:	f947f484 	ldr	x4, [x4, #4072]
    75b0:	a90153f3 	stp	x19, x20, [sp, #16]
    75b4:	d10943ff 	sub	sp, sp, #0x250
    75b8:	b9400045 	ldr	w5, [x2]
    75bc:	aa0003f4 	mov	x20, x0
    75c0:	f9400080 	ldr	x0, [x4]
    75c4:	f90127e0 	str	x0, [sp, #584]
    75c8:	d2800000 	mov	x0, #0x0                   	// #0
    75cc:	710064bf 	cmp	w5, #0x19
    75d0:	54000408 	b.hi	7650 <fwp_write+0xb0>  // b.pmore
    75d4:	f0000020 	adrp	x0, e000 <_IO_stdin_used+0xc00>
    75d8:	aa0103f3 	mov	x19, x1
    75dc:	9105c000 	add	x0, x0, #0x170
    75e0:	f9013bf5 	str	x21, [sp, #624]
    75e4:	f9013ff6 	str	x22, [sp, #632]
    75e8:	f90153fb 	str	x27, [sp, #672]
    75ec:	f90157fc 	str	x28, [sp, #680]
    75f0:	aa0203fc 	mov	x28, x2
    75f4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    75f8:	10000061 	adr	x1, 7604 <fwp_write+0x64>
    75fc:	8b20a820 	add	x0, x1, w0, sxth #2
    7600:	d61f0000 	br	x0
    7604:	910123e0 	add	x0, sp, #0x48
    7608:	aa1303e5 	mov	x5, x19
    760c:	d0000024 	adrp	x4, d000 <__divti3+0x320>
    7610:	aa0003f3 	mov	x19, x0
    7614:	9123a084 	add	x4, x4, #0x8e8
    7618:	d2804003 	mov	x3, #0x200                 	// #512
    761c:	aa0303e1 	mov	x1, x3
    7620:	52800042 	mov	w2, #0x2                   	// #2
    7624:	97ffec97 	bl	2880 <__snprintf_chk@plt>
    7628:	aa1303e0 	mov	x0, x19
    762c:	97ffec5d 	bl	27a0 <strlen@plt>
    7630:	aa1303e1 	mov	x1, x19
    7634:	aa0003e2 	mov	x2, x0
    7638:	aa1403e0 	mov	x0, x20
    763c:	97ffeff5 	bl	3610 <buf_put>
    7640:	f9413bf5 	ldr	x21, [sp, #624]
    7644:	f9413ff6 	ldr	x22, [sp, #632]
    7648:	f94153fb 	ldr	x27, [sp, #672]
    764c:	f94157fc 	ldr	x28, [sp, #680]
    7650:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7654:	f947f400 	ldr	x0, [x0, #4072]
    7658:	f94127e2 	ldr	x2, [sp, #584]
    765c:	f9400001 	ldr	x1, [x0]
    7660:	eb010042 	subs	x2, x2, x1
    7664:	d2800001 	mov	x1, #0x0                   	// #0
    7668:	540077c1 	b.ne	8560 <fwp_write+0xfc0>  // b.any
    766c:	910943ff 	add	sp, sp, #0x250
    7670:	a94153f3 	ldp	x19, x20, [sp, #16]
    7674:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7678:	d65f03c0 	ret
    767c:	910123e0 	add	x0, sp, #0x48
    7680:	aa1303e5 	mov	x5, x19
    7684:	d0000024 	adrp	x4, d000 <__divti3+0x320>
    7688:	aa0003f3 	mov	x19, x0
    768c:	91238084 	add	x4, x4, #0x8e0
    7690:	d2804003 	mov	x3, #0x200                 	// #512
    7694:	17ffffe2 	b	761c <fwp_write+0x7c>
    7698:	71004cbf 	cmp	w5, #0x13
    769c:	d0000020 	adrp	x0, d000 <__divti3+0x320>
    76a0:	d0000021 	adrp	x1, d000 <__divti3+0x320>
    76a4:	91234000 	add	x0, x0, #0x8d0
    76a8:	91236021 	add	x1, x1, #0x8d8
    76ac:	d2800082 	mov	x2, #0x4                   	// #4
    76b0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    76b4:	aa1403e0 	mov	x0, x20
    76b8:	f90143f7 	str	x23, [sp, #640]
    76bc:	d2800016 	mov	x22, #0x0                   	// #0
    76c0:	f90147f8 	str	x24, [sp, #648]
    76c4:	97ffefd3 	bl	3610 <buf_put>
    76c8:	f9400260 	ldr	x0, [x19]
    76cc:	d0000037 	adrp	x23, d000 <__divti3+0x320>
    76d0:	d2800015 	mov	x21, #0x0                   	// #0
    76d4:	912562f7 	add	x23, x23, #0x958
    76d8:	b40047a0 	cbz	x0, 7fcc <fwp_write+0xa2c>
    76dc:	b9400380 	ldr	w0, [x28]
    76e0:	52800003 	mov	w3, #0x0                   	// #0
    76e4:	f9401f82 	ldr	x2, [x28, #56]
    76e8:	71004c1f 	cmp	w0, #0x13
    76ec:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    76f0:	aa1403e0 	mov	x0, x20
    76f4:	8b010e61 	add	x1, x19, x1, lsl #3
    76f8:	f9400421 	ldr	x1, [x1, #8]
    76fc:	97ffffa9 	bl	75a0 <fwp_write>
    7700:	b9400380 	ldr	w0, [x28]
    7704:	7100481f 	cmp	w0, #0x12
    7708:	54004b40 	b.eq	8070 <fwp_write+0xad0>  // b.none
    770c:	f9400260 	ldr	x0, [x19]
    7710:	910006b5 	add	x21, x21, #0x1
    7714:	91000ad6 	add	x22, x22, #0x2
    7718:	eb15001f 	cmp	x0, x21
    771c:	54004589 	b.ls	7fcc <fwp_write+0xa2c>  // b.plast
    7720:	aa1703e1 	mov	x1, x23
    7724:	aa1403e0 	mov	x0, x20
    7728:	d2800042 	mov	x2, #0x2                   	// #2
    772c:	97ffefb9 	bl	3610 <buf_put>
    7730:	17ffffeb 	b	76dc <fwp_write+0x13c>
    7734:	d0000021 	adrp	x1, d000 <__divti3+0x320>
    7738:	91244021 	add	x1, x1, #0x910
    773c:	d28000c2 	mov	x2, #0x6                   	// #6
    7740:	aa1403e0 	mov	x0, x20
    7744:	91004273 	add	x19, x19, #0x10
    7748:	97ffefb2 	bl	3610 <buf_put>
    774c:	aa1303e0 	mov	x0, x19
    7750:	97ffec14 	bl	27a0 <strlen@plt>
    7754:	aa1303e1 	mov	x1, x19
    7758:	aa0003e2 	mov	x2, x0
    775c:	aa1403e0 	mov	x0, x20
    7760:	97ffefac 	bl	3610 <buf_put>
    7764:	528007c3 	mov	w3, #0x3e                  	// #62
    7768:	aa1403e0 	mov	x0, x20
    776c:	91001fe1 	add	x1, sp, #0x7
    7770:	d2800022 	mov	x2, #0x1                   	// #1
    7774:	39001fe3 	strb	w3, [sp, #7]
    7778:	17ffffb1 	b	763c <fwp_write+0x9c>
    777c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7780:	f947f400 	ldr	x0, [x0, #4072]
    7784:	f94127e2 	ldr	x2, [sp, #584]
    7788:	f9400001 	ldr	x1, [x0]
    778c:	eb010042 	subs	x2, x2, x1
    7790:	d2800001 	mov	x1, #0x0                   	// #0
    7794:	540034e1 	b.ne	7e30 <fwp_write+0x890>  // b.any
    7798:	f9413bf5 	ldr	x21, [sp, #624]
    779c:	d0000021 	adrp	x1, d000 <__divti3+0x320>
    77a0:	f9413ff6 	ldr	x22, [sp, #632]
    77a4:	aa1403e0 	mov	x0, x20
    77a8:	9123c021 	add	x1, x1, #0x8f0
    77ac:	d2800142 	mov	x2, #0xa                   	// #10
    77b0:	f94153fb 	ldr	x27, [sp, #672]
    77b4:	f94157fc 	ldr	x28, [sp, #680]
    77b8:	910943ff 	add	sp, sp, #0x250
    77bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    77c0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    77c4:	17ffef93 	b	3610 <buf_put>
    77c8:	f9400456 	ldr	x22, [x2, #8]
    77cc:	f90143f7 	str	x23, [sp, #640]
    77d0:	f90147f8 	str	x24, [sp, #648]
    77d4:	b4005b16 	cbz	x22, 8334 <fwp_write+0xd94>
    77d8:	aa1603e0 	mov	x0, x22
    77dc:	d0000021 	adrp	x1, d000 <__divti3+0x320>
    77e0:	9125c021 	add	x1, x1, #0x970
    77e4:	97ffec6b 	bl	2990 <strcmp@plt>
    77e8:	2a0003f5 	mov	w21, w0
    77ec:	34005fe0 	cbz	w0, 83e8 <fwp_write+0xe48>
    77f0:	aa1603e0 	mov	x0, x22
    77f4:	97ffebeb 	bl	27a0 <strlen@plt>
    77f8:	aa1603e1 	mov	x1, x22
    77fc:	aa0003e2 	mov	x2, x0
    7800:	aa1403e0 	mov	x0, x20
    7804:	97ffef83 	bl	3610 <buf_put>
    7808:	52800403 	mov	w3, #0x20                  	// #32
    780c:	91001ff5 	add	x21, sp, #0x7
    7810:	aa1503e1 	mov	x1, x21
    7814:	aa1403e0 	mov	x0, x20
    7818:	d2800022 	mov	x2, #0x1                   	// #1
    781c:	39001fe3 	strb	w3, [sp, #7]
    7820:	97ffef7c 	bl	3610 <buf_put>
    7824:	52800f63 	mov	w3, #0x7b                  	// #123
    7828:	aa1403e0 	mov	x0, x20
    782c:	aa1503e1 	mov	x1, x21
    7830:	d2800022 	mov	x2, #0x1                   	// #1
    7834:	39001fe3 	strb	w3, [sp, #7]
    7838:	97ffef76 	bl	3610 <buf_put>
    783c:	b9401380 	ldr	w0, [x28, #16]
    7840:	52800018 	mov	w24, #0x0                   	// #0
    7844:	7100001f 	cmp	w0, #0x0
    7848:	54003aad 	b.le	7f9c <fwp_write+0x9fc>
    784c:	f9014bf9 	str	x25, [sp, #656]
    7850:	d0000039 	adrp	x25, d000 <__divti3+0x320>
    7854:	91266339 	add	x25, x25, #0x998
    7858:	f9014ffa 	str	x26, [sp, #664]
    785c:	d000003a 	adrp	x26, d000 <__divti3+0x320>
    7860:	9125635a 	add	x26, x26, #0x958
    7864:	91002276 	add	x22, x19, #0x8
    7868:	d2800013 	mov	x19, #0x0                   	// #0
    786c:	b5003e93 	cbnz	x19, 803c <fwp_write+0xa9c>
    7870:	d37df277 	lsl	x23, x19, #3
    7874:	34003cb8 	cbz	w24, 8008 <fwp_write+0xa68>
    7878:	f9401382 	ldr	x2, [x28, #32]
    787c:	aa1403e0 	mov	x0, x20
    7880:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7884:	52800003 	mov	w3, #0x0                   	// #0
    7888:	f8776842 	ldr	x2, [x2, x23]
    788c:	91000673 	add	x19, x19, #0x1
    7890:	97ffff44 	bl	75a0 <fwp_write>
    7894:	b9401380 	ldr	w0, [x28, #16]
    7898:	6b13001f 	cmp	w0, w19
    789c:	54fffe8c 	b.gt	786c <fwp_write+0x2cc>
    78a0:	f9414bf9 	ldr	x25, [sp, #656]
    78a4:	f9414ffa 	ldr	x26, [sp, #664]
    78a8:	340037b8 	cbz	w24, 7f9c <fwp_write+0x9fc>
    78ac:	52800523 	mov	w3, #0x29                  	// #41
    78b0:	aa1503e1 	mov	x1, x21
    78b4:	aa1403e0 	mov	x0, x20
    78b8:	d2800022 	mov	x2, #0x1                   	// #1
    78bc:	39001fe3 	strb	w3, [sp, #7]
    78c0:	97ffef54 	bl	3610 <buf_put>
    78c4:	f9413bf5 	ldr	x21, [sp, #624]
    78c8:	f9413ff6 	ldr	x22, [sp, #632]
    78cc:	f94143f7 	ldr	x23, [sp, #640]
    78d0:	f94147f8 	ldr	x24, [sp, #648]
    78d4:	f94153fb 	ldr	x27, [sp, #672]
    78d8:	f94157fc 	ldr	x28, [sp, #680]
    78dc:	17ffff5d 	b	7650 <fwp_write+0xb0>
    78e0:	b9404855 	ldr	w21, [x2, #72]
    78e4:	aa1403e0 	mov	x0, x20
    78e8:	93407eb6 	sxtw	x22, w21
    78ec:	91000ac1 	add	x1, x22, #0x2
    78f0:	97ffef15 	bl	3544 <buf_grow>
    78f4:	a9400281 	ldp	x1, x0, [x20]
    78f8:	528e8603 	mov	w3, #0x7430                	// #29744
    78fc:	78206823 	strh	w3, [x1, x0]
    7900:	8b000022 	add	x2, x1, x0
    7904:	710002bf 	cmp	w21, #0x0
    7908:	540036cd 	b.le	7fe0 <fwp_write+0xa40>
    790c:	110006a3 	add	w3, w21, #0x1
    7910:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7914:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7918:	91000449 	add	x9, x2, #0x1
    791c:	8b23c043 	add	x3, x2, w3, sxtw
    7920:	f28aaac6 	movk	x6, #0x5556
    7924:	f2955568 	movk	x8, #0xaaab
    7928:	1400000d 	b	795c <fwp_write+0x3bc>
    792c:	d2800021 	mov	x1, #0x1                   	// #1
    7930:	528005a5 	mov	w5, #0x2d                  	// #45
    7934:	f100001f 	cmp	x0, #0x0
    7938:	9b467e60 	smulh	x0, x19, x6
    793c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7940:	381ff465 	strb	w5, [x3], #-1
    7944:	cb040000 	sub	x0, x0, x4
    7948:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    794c:	cb020000 	sub	x0, x0, x2
    7950:	8b010013 	add	x19, x0, x1
    7954:	eb03013f 	cmp	x9, x3
    7958:	54003440 	b.eq	7fe0 <fwp_write+0xa40>  // b.none
    795c:	9b467e60 	smulh	x0, x19, x6
    7960:	937ffe64 	asr	x4, x19, #63
    7964:	52800605 	mov	w5, #0x30                  	// #48
    7968:	cb040000 	sub	x0, x0, x4
    796c:	8b000400 	add	x0, x0, x0, lsl #1
    7970:	cb000260 	sub	x0, x19, x0
    7974:	91000c01 	add	x1, x0, #0x3
    7978:	9bc87c22 	umulh	x2, x1, x8
    797c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7980:	8b4204e2 	add	x2, x7, x2, lsr #1
    7984:	eb020021 	subs	x1, x1, x2
    7988:	54fffd60 	b.eq	7934 <fwp_write+0x394>  // b.none
    798c:	f100043f 	cmp	x1, #0x1
    7990:	54fffce1 	b.ne	792c <fwp_write+0x38c>  // b.any
    7994:	d2800001 	mov	x1, #0x0                   	// #0
    7998:	52800565 	mov	w5, #0x2b                  	// #43
    799c:	17ffffe6 	b	7934 <fwp_write+0x394>
    79a0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    79a4:	f947f400 	ldr	x0, [x0, #4072]
    79a8:	f94127e2 	ldr	x2, [sp, #584]
    79ac:	f9400001 	ldr	x1, [x0]
    79b0:	eb010042 	subs	x2, x2, x1
    79b4:	d2800001 	mov	x1, #0x0                   	// #0
    79b8:	540023c1 	b.ne	7e30 <fwp_write+0x890>  // b.any
    79bc:	f9413bf5 	ldr	x21, [sp, #624]
    79c0:	d0000021 	adrp	x1, d000 <__divti3+0x320>
    79c4:	f9413ff6 	ldr	x22, [sp, #632]
    79c8:	aa1403e0 	mov	x0, x20
    79cc:	91240021 	add	x1, x1, #0x900
    79d0:	d2800102 	mov	x2, #0x8                   	// #8
    79d4:	17ffff77 	b	77b0 <fwp_write+0x210>
    79d8:	aa1403e0 	mov	x0, x20
    79dc:	d0000021 	adrp	x1, d000 <__divti3+0x320>
    79e0:	d28000c2 	mov	x2, #0x6                   	// #6
    79e4:	91258021 	add	x1, x1, #0x960
    79e8:	97ffef0a 	bl	3610 <buf_put>
    79ec:	d2800015 	mov	x21, #0x0                   	// #0
    79f0:	f9400263 	ldr	x3, [x19]
    79f4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    79f8:	54002c60 	b.eq	7f84 <fwp_write+0x9e4>  // b.none
    79fc:	f9401f82 	ldr	x2, [x28, #56]
    7a00:	f90143f7 	str	x23, [sp, #640]
    7a04:	f90147f8 	str	x24, [sp, #648]
    7a08:	d2800857 	mov	x23, #0x42                  	// #66
    7a0c:	f9014bf9 	str	x25, [sp, #656]
    7a10:	d0000036 	adrp	x22, d000 <__divti3+0x320>
    7a14:	f9014ffa 	str	x26, [sp, #664]
    7a18:	912562d6 	add	x22, x22, #0x958
    7a1c:	d2800038 	mov	x24, #0x1                   	// #1
    7a20:	f2a18017 	movk	x23, #0xc00, lsl #16
    7a24:	d2809099 	mov	x25, #0x484                 	// #1156
    7a28:	b40004a2 	cbz	x2, 7abc <fwp_write+0x51c>
    7a2c:	b9400040 	ldr	w0, [x2]
    7a30:	7100701f 	cmp	w0, #0x1c
    7a34:	540042c0 	b.eq	828c <fwp_write+0xcec>  // b.none
    7a38:	71006c1f 	cmp	w0, #0x1b
    7a3c:	54000408 	b.hi	7abc <fwp_write+0x51c>  // b.pmore
    7a40:	9ac02301 	lsl	x1, x24, x0
    7a44:	ea17003f 	tst	x1, x23
    7a48:	540036a1 	b.ne	811c <fwp_write+0xb7c>  // b.any
    7a4c:	ea19003f 	tst	x1, x25
    7a50:	54003521 	b.ne	80f4 <fwp_write+0xb54>  // b.any
    7a54:	d2800424 	mov	x4, #0x21                  	// #33
    7a58:	ea04003f 	tst	x1, x4
    7a5c:	54000300 	b.eq	7abc <fwp_write+0x51c>  // b.none
    7a60:	b7f849c3 	tbnz	x3, #63, 8398 <fwp_write+0xdf8>
    7a64:	91002261 	add	x1, x19, #0x8
    7a68:	8b150021 	add	x1, x1, x21
    7a6c:	39400021 	ldrb	w1, [x1]
    7a70:	7100001f 	cmp	w0, #0x0
    7a74:	93401c23 	sxtb	x3, w1
    7a78:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7a7c:	d503201f 	nop
    7a80:	aa1403e0 	mov	x0, x20
    7a84:	52800003 	mov	w3, #0x0                   	// #0
    7a88:	97fffec6 	bl	75a0 <fwp_write>
    7a8c:	910006b5 	add	x21, x21, #0x1
    7a90:	f9400260 	ldr	x0, [x19]
    7a94:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7a98:	eb0002bf 	cmp	x21, x0
    7a9c:	540026c2 	b.cs	7f74 <fwp_write+0x9d4>  // b.hs, b.nlast
    7aa0:	d2800042 	mov	x2, #0x2                   	// #2
    7aa4:	aa1603e1 	mov	x1, x22
    7aa8:	aa1403e0 	mov	x0, x20
    7aac:	97ffeed9 	bl	3610 <buf_put>
    7ab0:	f9401f82 	ldr	x2, [x28, #56]
    7ab4:	f9400263 	ldr	x3, [x19]
    7ab8:	b5fffba2 	cbnz	x2, 7a2c <fwp_write+0x48c>
    7abc:	d37df2a0 	lsl	x0, x21, #3
    7ac0:	b7f83f03 	tbnz	x3, #63, 82a0 <fwp_write+0xd00>
    7ac4:	91002261 	add	x1, x19, #0x8
    7ac8:	8b000020 	add	x0, x1, x0
    7acc:	f9400001 	ldr	x1, [x0]
    7ad0:	17ffffec 	b	7a80 <fwp_write+0x4e0>
    7ad4:	a9400e62 	ldp	x2, x3, [x19]
    7ad8:	b7f83ca3 	tbnz	x3, #63, 826c <fwp_write+0xccc>
    7adc:	910123f5 	add	x21, sp, #0x48
    7ae0:	aa1503e0 	mov	x0, x21
    7ae4:	97ffecef 	bl	2ea0 <fwp_fmt_u128>
    7ae8:	aa1503e0 	mov	x0, x21
    7aec:	97ffeb2d 	bl	27a0 <strlen@plt>
    7af0:	aa1503e1 	mov	x1, x21
    7af4:	aa0003e2 	mov	x2, x0
    7af8:	17fffed0 	b	7638 <fwp_write+0x98>
    7afc:	fd015be8 	str	d8, [sp, #688]
    7b00:	1e270268 	fmov	s8, w19
    7b04:	fd015fe9 	str	d9, [sp, #696]
    7b08:	1e282100 	fcmp	s8, s8
    7b0c:	54004d26 	b.vs	84b0 <fwp_write+0xf10>
    7b10:	1e20c101 	fabs	s1, s8
    7b14:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7b18:	1e270000 	fmov	s0, w0
    7b1c:	1e202020 	fcmp	s1, s0
    7b20:	54002c0d 	b.le	80a0 <fwp_write+0xb00>
    7b24:	1e202118 	fcmpe	s8, #0.0
    7b28:	d0000022 	adrp	x2, d000 <__divti3+0x320>
    7b2c:	91136042 	add	x2, x2, #0x4d8
    7b30:	910123f5 	add	x21, sp, #0x48
    7b34:	d0000021 	adrp	x1, d000 <__divti3+0x320>
    7b38:	9122c021 	add	x1, x1, #0x8b0
    7b3c:	aa1503e0 	mov	x0, x21
    7b40:	9a81c041 	csel	x1, x2, x1, gt
    7b44:	97ffebc3 	bl	2a50 <strcpy@plt>
    7b48:	aa1503e0 	mov	x0, x21
    7b4c:	97ffeb15 	bl	27a0 <strlen@plt>
    7b50:	aa1503e1 	mov	x1, x21
    7b54:	aa0003e2 	mov	x2, x0
    7b58:	aa1403e0 	mov	x0, x20
    7b5c:	97ffeead 	bl	3610 <buf_put>
    7b60:	f9413bf5 	ldr	x21, [sp, #624]
    7b64:	f9413ff6 	ldr	x22, [sp, #632]
    7b68:	f94153fb 	ldr	x27, [sp, #672]
    7b6c:	f94157fc 	ldr	x28, [sp, #680]
    7b70:	fd415be8 	ldr	d8, [sp, #688]
    7b74:	fd415fe9 	ldr	d9, [sp, #696]
    7b78:	17fffeb6 	b	7650 <fwp_write+0xb0>
    7b7c:	f9400276 	ldr	x22, [x19]
    7b80:	34002e03 	cbz	w3, 8140 <fwp_write+0xba0>
    7b84:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7b88:	f947f400 	ldr	x0, [x0, #4072]
    7b8c:	f94127e2 	ldr	x2, [sp, #584]
    7b90:	f9400001 	ldr	x1, [x0]
    7b94:	eb010042 	subs	x2, x2, x1
    7b98:	d2800001 	mov	x1, #0x0                   	// #0
    7b9c:	540014a1 	b.ne	7e30 <fwp_write+0x890>  // b.any
    7ba0:	aa1603e2 	mov	x2, x22
    7ba4:	91002261 	add	x1, x19, #0x8
    7ba8:	f9413bf5 	ldr	x21, [sp, #624]
    7bac:	aa1403e0 	mov	x0, x20
    7bb0:	f9413ff6 	ldr	x22, [sp, #632]
    7bb4:	17fffeff 	b	77b0 <fwp_write+0x210>
    7bb8:	fd015be8 	str	d8, [sp, #688]
    7bbc:	9e670268 	fmov	d8, x19
    7bc0:	fd015fe9 	str	d9, [sp, #696]
    7bc4:	1e682100 	fcmp	d8, d8
    7bc8:	54004746 	b.vs	84b0 <fwp_write+0xf10>
    7bcc:	1e60c101 	fabs	d1, d8
    7bd0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7bd4:	9e670000 	fmov	d0, x0
    7bd8:	910123f5 	add	x21, sp, #0x48
    7bdc:	52800033 	mov	w19, #0x1                   	// #1
    7be0:	1e602020 	fcmp	d1, d0
    7be4:	540001ad 	b.le	7c18 <fwp_write+0x678>
    7be8:	1e602118 	fcmpe	d8, #0.0
    7bec:	d0000022 	adrp	x2, d000 <__divti3+0x320>
    7bf0:	91136042 	add	x2, x2, #0x4d8
    7bf4:	d0000021 	adrp	x1, d000 <__divti3+0x320>
    7bf8:	9122c021 	add	x1, x1, #0x8b0
    7bfc:	aa1503e0 	mov	x0, x21
    7c00:	9a81c041 	csel	x1, x2, x1, gt
    7c04:	97ffeb93 	bl	2a50 <strcpy@plt>
    7c08:	17ffffd0 	b	7b48 <fwp_write+0x5a8>
    7c0c:	11000673 	add	w19, w19, #0x1
    7c10:	71004a7f 	cmp	w19, #0x12
    7c14:	54003860 	b.eq	8320 <fwp_write+0xd80>  // b.none
    7c18:	1e604100 	fmov	d0, d8
    7c1c:	2a1303e1 	mov	w1, w19
    7c20:	aa1503e0 	mov	x0, x21
    7c24:	97ffef17 	bl	3880 <fwp_format_g.constprop.0>
    7c28:	aa1503e0 	mov	x0, x21
    7c2c:	d2800001 	mov	x1, #0x0                   	// #0
    7c30:	97ffeaf0 	bl	27f0 <strtod@plt>
    7c34:	1e602100 	fcmp	d8, d0
    7c38:	54fffea1 	b.ne	7c0c <fwp_write+0x66c>  // b.any
    7c3c:	aa1503e0 	mov	x0, x21
    7c40:	97ffeeed 	bl	37f4 <fwp_finish_float>
    7c44:	17ffffc1 	b	7b48 <fwp_write+0x5a8>
    7c48:	a9400e62 	ldp	x2, x3, [x19]
    7c4c:	910123f3 	add	x19, sp, #0x48
    7c50:	aa1303e0 	mov	x0, x19
    7c54:	97ffec93 	bl	2ea0 <fwp_fmt_u128>
    7c58:	17fffe74 	b	7628 <fwp_write+0x88>
    7c5c:	f90143f7 	str	x23, [sp, #640]
    7c60:	f90147f8 	str	x24, [sp, #648]
    7c64:	2a1303f8 	mov	w24, w19
    7c68:	f9014bf9 	str	x25, [sp, #656]
    7c6c:	f9014ffa 	str	x26, [sp, #664]
    7c70:	f13ffe7f 	cmp	x19, #0xfff
    7c74:	54000049 	b.ls	7c7c <fwp_write+0x6dc>  // b.plast
    7c78:	b9400278 	ldr	w24, [x19]
    7c7c:	f9400f80 	ldr	x0, [x28, #24]
    7c80:	2a1803f5 	mov	w21, w24
    7c84:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7c88:	d37ef6b9 	lsl	x25, x21, #2
    7c8c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7c90:	aa1603e0 	mov	x0, x22
    7c94:	97ffeac3 	bl	27a0 <strlen@plt>
    7c98:	aa1603e1 	mov	x1, x22
    7c9c:	aa0003e2 	mov	x2, x0
    7ca0:	aa1403e0 	mov	x0, x20
    7ca4:	97ffee5b 	bl	3610 <buf_put>
    7ca8:	f9401780 	ldr	x0, [x28, #40]
    7cac:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    7cb0:	7100001f 	cmp	w0, #0x0
    7cb4:	5400068d 	b.le	7d84 <fwp_write+0x7e4>
    7cb8:	91002276 	add	x22, x19, #0x8
    7cbc:	91001ff5 	add	x21, sp, #0x7
    7cc0:	d280001b 	mov	x27, #0x0                   	// #0
    7cc4:	5280041a 	mov	w26, #0x20                  	// #32
    7cc8:	f9401b80 	ldr	x0, [x28, #48]
    7ccc:	aa1503e1 	mov	x1, x21
    7cd0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7cd4:	d2800022 	mov	x2, #0x1                   	// #1
    7cd8:	f8786803 	ldr	x3, [x0, x24]
    7cdc:	aa1403e0 	mov	x0, x20
    7ce0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7ce4:	39001ffa 	strb	w26, [sp, #7]
    7ce8:	97ffee4a 	bl	3610 <buf_put>
    7cec:	f13ffeff 	cmp	x23, #0xfff
    7cf0:	b9400261 	ldr	w1, [x19]
    7cf4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7cf8:	7100383f 	cmp	w1, #0xe
    7cfc:	54000160 	b.eq	7d28 <fwp_write+0x788>  // b.none
    7d00:	7100403f 	cmp	w1, #0x10
    7d04:	54001a60 	b.eq	8050 <fwp_write+0xab0>  // b.none
    7d08:	7100283f 	cmp	w1, #0xa
    7d0c:	54002aa0 	b.eq	8260 <fwp_write+0xcc0>  // b.none
    7d10:	540014ac 	b.gt	7fa4 <fwp_write+0xa04>
    7d14:	71000c3f 	cmp	w1, #0x3
    7d18:	540029ac 	b.gt	824c <fwp_write+0xcac>
    7d1c:	d37ffee0 	lsr	x0, x23, #63
    7d20:	37f814a1 	tbnz	w1, #31, 7fb4 <fwp_write+0xa14>
    7d24:	d503201f 	nop
    7d28:	34001460 	cbz	w0, 7fb4 <fwp_write+0xa14>
    7d2c:	52800503 	mov	w3, #0x28                  	// #40
    7d30:	aa1503e1 	mov	x1, x21
    7d34:	aa1403e0 	mov	x0, x20
    7d38:	d2800022 	mov	x2, #0x1                   	// #1
    7d3c:	39001fe3 	strb	w3, [sp, #7]
    7d40:	97ffee34 	bl	3610 <buf_put>
    7d44:	aa1303e2 	mov	x2, x19
    7d48:	aa1703e1 	mov	x1, x23
    7d4c:	aa1403e0 	mov	x0, x20
    7d50:	52800003 	mov	w3, #0x0                   	// #0
    7d54:	97fffe13 	bl	75a0 <fwp_write>
    7d58:	52800523 	mov	w3, #0x29                  	// #41
    7d5c:	aa1503e1 	mov	x1, x21
    7d60:	aa1403e0 	mov	x0, x20
    7d64:	d2800022 	mov	x2, #0x1                   	// #1
    7d68:	39001fe3 	strb	w3, [sp, #7]
    7d6c:	97ffee29 	bl	3610 <buf_put>
    7d70:	f9401780 	ldr	x0, [x28, #40]
    7d74:	9100077b 	add	x27, x27, #0x1
    7d78:	b8796800 	ldr	w0, [x0, x25]
    7d7c:	6b1b001f 	cmp	w0, w27
    7d80:	54fffa4c 	b.gt	7cc8 <fwp_write+0x728>
    7d84:	f9413bf5 	ldr	x21, [sp, #624]
    7d88:	f9413ff6 	ldr	x22, [sp, #632]
    7d8c:	f94143f7 	ldr	x23, [sp, #640]
    7d90:	f94147f8 	ldr	x24, [sp, #648]
    7d94:	f9414bf9 	ldr	x25, [sp, #656]
    7d98:	f9414ffa 	ldr	x26, [sp, #664]
    7d9c:	f94153fb 	ldr	x27, [sp, #672]
    7da0:	f94157fc 	ldr	x28, [sp, #680]
    7da4:	17fffe2b 	b	7650 <fwp_write+0xb0>
    7da8:	52800783 	mov	w3, #0x3c                  	// #60
    7dac:	91001ff3 	add	x19, sp, #0x7
    7db0:	aa1303e1 	mov	x1, x19
    7db4:	d2800022 	mov	x2, #0x1                   	// #1
    7db8:	aa1403e0 	mov	x0, x20
    7dbc:	39001fe3 	strb	w3, [sp, #7]
    7dc0:	97ffee14 	bl	3610 <buf_put>
    7dc4:	f9400795 	ldr	x21, [x28, #8]
    7dc8:	aa1503e0 	mov	x0, x21
    7dcc:	97ffea75 	bl	27a0 <strlen@plt>
    7dd0:	aa1503e1 	mov	x1, x21
    7dd4:	aa0003e2 	mov	x2, x0
    7dd8:	aa1403e0 	mov	x0, x20
    7ddc:	97ffee0d 	bl	3610 <buf_put>
    7de0:	528007c3 	mov	w3, #0x3e                  	// #62
    7de4:	aa1303e1 	mov	x1, x19
    7de8:	aa1403e0 	mov	x0, x20
    7dec:	d2800022 	mov	x2, #0x1                   	// #1
    7df0:	39001fe3 	strb	w3, [sp, #7]
    7df4:	17fffe12 	b	763c <fwp_write+0x9c>
    7df8:	f100067f 	cmp	x19, #0x1
    7dfc:	540025a0 	b.eq	82b0 <fwp_write+0xd10>  // b.none
    7e00:	b100067f 	cmn	x19, #0x1
    7e04:	54002bc0 	b.eq	837c <fwp_write+0xddc>  // b.none
    7e08:	d0000021 	adrp	x1, d000 <__divti3+0x320>
    7e0c:	9122e021 	add	x1, x1, #0x8b8
    7e10:	d2800022 	mov	x2, #0x1                   	// #1
    7e14:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7e18:	f947f400 	ldr	x0, [x0, #4072]
    7e1c:	f94127e4 	ldr	x4, [sp, #584]
    7e20:	f9400003 	ldr	x3, [x0]
    7e24:	eb030084 	subs	x4, x4, x3
    7e28:	d2800003 	mov	x3, #0x0                   	// #0
    7e2c:	54ffebe0 	b.eq	7ba8 <fwp_write+0x608>  // b.none
    7e30:	f90143f7 	str	x23, [sp, #640]
    7e34:	f90147f8 	str	x24, [sp, #648]
    7e38:	f9014bf9 	str	x25, [sp, #656]
    7e3c:	f9014ffa 	str	x26, [sp, #664]
    7e40:	fd015be8 	str	d8, [sp, #688]
    7e44:	fd015fe9 	str	d9, [sp, #696]
    7e48:	97ffeab2 	bl	2910 <__stack_chk_fail@plt>
    7e4c:	52800b63 	mov	w3, #0x5b                  	// #91
    7e50:	91001ff5 	add	x21, sp, #0x7
    7e54:	aa1503e1 	mov	x1, x21
    7e58:	aa1403e0 	mov	x0, x20
    7e5c:	d2800022 	mov	x2, #0x1                   	// #1
    7e60:	d0000036 	adrp	x22, d000 <__divti3+0x320>
    7e64:	912562d6 	add	x22, x22, #0x958
    7e68:	39001fe3 	strb	w3, [sp, #7]
    7e6c:	97ffede9 	bl	3610 <buf_put>
    7e70:	b4000273 	cbz	x19, 7ebc <fwp_write+0x91c>
    7e74:	f9400661 	ldr	x1, [x19, #8]
    7e78:	aa1403e0 	mov	x0, x20
    7e7c:	f9401f82 	ldr	x2, [x28, #56]
    7e80:	52800003 	mov	w3, #0x0                   	// #0
    7e84:	97fffdc7 	bl	75a0 <fwp_write>
    7e88:	f9400a73 	ldr	x19, [x19, #16]
    7e8c:	b4000193 	cbz	x19, 7ebc <fwp_write+0x91c>
    7e90:	aa1603e1 	mov	x1, x22
    7e94:	aa1403e0 	mov	x0, x20
    7e98:	d2800042 	mov	x2, #0x2                   	// #2
    7e9c:	97ffeddd 	bl	3610 <buf_put>
    7ea0:	f9400661 	ldr	x1, [x19, #8]
    7ea4:	aa1403e0 	mov	x0, x20
    7ea8:	f9401f82 	ldr	x2, [x28, #56]
    7eac:	52800003 	mov	w3, #0x0                   	// #0
    7eb0:	97fffdbc 	bl	75a0 <fwp_write>
    7eb4:	f9400a73 	ldr	x19, [x19, #16]
    7eb8:	b5fffed3 	cbnz	x19, 7e90 <fwp_write+0x8f0>
    7ebc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7ec0:	aa1503e1 	mov	x1, x21
    7ec4:	aa1403e0 	mov	x0, x20
    7ec8:	d2800022 	mov	x2, #0x1                   	// #1
    7ecc:	39001fe3 	strb	w3, [sp, #7]
    7ed0:	17fffddb 	b	763c <fwp_write+0x9c>
    7ed4:	aa1403e0 	mov	x0, x20
    7ed8:	d0000021 	adrp	x1, d000 <__divti3+0x320>
    7edc:	d28000c2 	mov	x2, #0x6                   	// #6
    7ee0:	91252021 	add	x1, x1, #0x948
    7ee4:	97ffedcb 	bl	3610 <buf_put>
    7ee8:	f9400260 	ldr	x0, [x19]
    7eec:	b40004c0 	cbz	x0, 7f84 <fwp_write+0x9e4>
    7ef0:	910123f5 	add	x21, sp, #0x48
    7ef4:	91002276 	add	x22, x19, #0x8
    7ef8:	f90143f7 	str	x23, [sp, #640]
    7efc:	d2800017 	mov	x23, #0x0                   	// #0
    7f00:	f90147f8 	str	x24, [sp, #648]
    7f04:	d0000038 	adrp	x24, d000 <__divti3+0x320>
    7f08:	91254318 	add	x24, x24, #0x950
    7f0c:	f9014bf9 	str	x25, [sp, #656]
    7f10:	d0000039 	adrp	x25, d000 <__divti3+0x320>
    7f14:	91256339 	add	x25, x25, #0x958
    7f18:	f9014ffa 	str	x26, [sp, #664]
    7f1c:	14000005 	b	7f30 <fwp_write+0x990>
    7f20:	aa1903e1 	mov	x1, x25
    7f24:	aa1403e0 	mov	x0, x20
    7f28:	d2800042 	mov	x2, #0x2                   	// #2
    7f2c:	97ffedb9 	bl	3610 <buf_put>
    7f30:	38776ac5 	ldrb	w5, [x22, x23]
    7f34:	d2804003 	mov	x3, #0x200                 	// #512
    7f38:	aa1803e4 	mov	x4, x24
    7f3c:	aa0303e1 	mov	x1, x3
    7f40:	52800042 	mov	w2, #0x2                   	// #2
    7f44:	aa1503e0 	mov	x0, x21
    7f48:	910006f7 	add	x23, x23, #0x1
    7f4c:	97ffea4d 	bl	2880 <__snprintf_chk@plt>
    7f50:	aa1503e0 	mov	x0, x21
    7f54:	97ffea13 	bl	27a0 <strlen@plt>
    7f58:	aa1503e1 	mov	x1, x21
    7f5c:	aa0003e2 	mov	x2, x0
    7f60:	aa1403e0 	mov	x0, x20
    7f64:	97ffedab 	bl	3610 <buf_put>
    7f68:	f9400260 	ldr	x0, [x19]
    7f6c:	eb17001f 	cmp	x0, x23
    7f70:	54fffd88 	b.hi	7f20 <fwp_write+0x980>  // b.pmore
    7f74:	f94143f7 	ldr	x23, [sp, #640]
    7f78:	f94147f8 	ldr	x24, [sp, #648]
    7f7c:	f9414bf9 	ldr	x25, [sp, #656]
    7f80:	f9414ffa 	ldr	x26, [sp, #664]
    7f84:	52800ba3 	mov	w3, #0x5d                  	// #93
    7f88:	aa1403e0 	mov	x0, x20
    7f8c:	91001fe1 	add	x1, sp, #0x7
    7f90:	d2800022 	mov	x2, #0x1                   	// #1
    7f94:	39001fe3 	strb	w3, [sp, #7]
    7f98:	17fffda9 	b	763c <fwp_write+0x9c>
    7f9c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7fa0:	17fffe44 	b	78b0 <fwp_write+0x310>
    7fa4:	f10002ff 	cmp	x23, #0x0
    7fa8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7fac:	71002c3f 	cmp	w1, #0xb
    7fb0:	54ffebc0 	b.eq	7d28 <fwp_write+0x788>  // b.none
    7fb4:	aa1303e2 	mov	x2, x19
    7fb8:	aa1703e1 	mov	x1, x23
    7fbc:	aa1403e0 	mov	x0, x20
    7fc0:	52800003 	mov	w3, #0x0                   	// #0
    7fc4:	97fffd77 	bl	75a0 <fwp_write>
    7fc8:	17ffff6a 	b	7d70 <fwp_write+0x7d0>
    7fcc:	aa1403e0 	mov	x0, x20
    7fd0:	91001fe1 	add	x1, sp, #0x7
    7fd4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7fd8:	d2800022 	mov	x2, #0x1                   	// #1
    7fdc:	17fffe38 	b	78bc <fwp_write+0x31c>
    7fe0:	a9400281 	ldp	x1, x0, [x20]
    7fe4:	91000800 	add	x0, x0, #0x2
    7fe8:	8b160000 	add	x0, x0, x22
    7fec:	f9000680 	str	x0, [x20, #8]
    7ff0:	3820683f 	strb	wzr, [x1, x0]
    7ff4:	f9413bf5 	ldr	x21, [sp, #624]
    7ff8:	f9413ff6 	ldr	x22, [sp, #632]
    7ffc:	f94153fb 	ldr	x27, [sp, #672]
    8000:	f94157fc 	ldr	x28, [sp, #680]
    8004:	17fffd93 	b	7650 <fwp_write+0xb0>
    8008:	f9400f80 	ldr	x0, [x28, #24]
    800c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    8010:	aa1b03e0 	mov	x0, x27
    8014:	97ffe9e3 	bl	27a0 <strlen@plt>
    8018:	aa1b03e1 	mov	x1, x27
    801c:	aa0003e2 	mov	x2, x0
    8020:	aa1403e0 	mov	x0, x20
    8024:	97ffed7b 	bl	3610 <buf_put>
    8028:	aa1903e1 	mov	x1, x25
    802c:	aa1403e0 	mov	x0, x20
    8030:	d2800062 	mov	x2, #0x3                   	// #3
    8034:	97ffed77 	bl	3610 <buf_put>
    8038:	17fffe10 	b	7878 <fwp_write+0x2d8>
    803c:	aa1a03e1 	mov	x1, x26
    8040:	aa1403e0 	mov	x0, x20
    8044:	d2800042 	mov	x2, #0x2                   	// #2
    8048:	97ffed72 	bl	3610 <buf_put>
    804c:	17fffe09 	b	7870 <fwp_write+0x2d0>
    8050:	f9400660 	ldr	x0, [x19, #8]
    8054:	b4fffb00 	cbz	x0, 7fb4 <fwp_write+0xa14>
    8058:	b0000021 	adrp	x1, d000 <__divti3+0x320>
    805c:	9125c021 	add	x1, x1, #0x970
    8060:	97ffea4c 	bl	2990 <strcmp@plt>
    8064:	7100001f 	cmp	w0, #0x0
    8068:	1a9f07e0 	cset	w0, ne	// ne = any
    806c:	17ffff2f 	b	7d28 <fwp_write+0x788>
    8070:	aa1403e0 	mov	x0, x20
    8074:	d2800042 	mov	x2, #0x2                   	// #2
    8078:	b0000021 	adrp	x1, d000 <__divti3+0x320>
    807c:	9125a021 	add	x1, x1, #0x968
    8080:	97ffed64 	bl	3610 <buf_put>
    8084:	91004261 	add	x1, x19, #0x10
    8088:	aa1403e0 	mov	x0, x20
    808c:	f9402382 	ldr	x2, [x28, #64]
    8090:	52800003 	mov	w3, #0x0                   	// #0
    8094:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    8098:	97fffd42 	bl	75a0 <fwp_write>
    809c:	17fffd9c 	b	770c <fwp_write+0x16c>
    80a0:	1e22c109 	fcvt	d9, s8
    80a4:	910123f5 	add	x21, sp, #0x48
    80a8:	52800033 	mov	w19, #0x1                   	// #1
    80ac:	d503201f 	nop
    80b0:	1e604120 	fmov	d0, d9
    80b4:	2a1303e1 	mov	w1, w19
    80b8:	aa1503e0 	mov	x0, x21
    80bc:	97ffedf1 	bl	3880 <fwp_format_g.constprop.0>
    80c0:	aa1503e0 	mov	x0, x21
    80c4:	d2800001 	mov	x1, #0x0                   	// #0
    80c8:	97ffea3e 	bl	29c0 <strtof@plt>
    80cc:	1e202100 	fcmp	s8, s0
    80d0:	54ffdb60 	b.eq	7c3c <fwp_write+0x69c>  // b.none
    80d4:	11000673 	add	w19, w19, #0x1
    80d8:	71002a7f 	cmp	w19, #0xa
    80dc:	54fffea1 	b.ne	80b0 <fwp_write+0xb10>  // b.any
    80e0:	1e604120 	fmov	d0, d9
    80e4:	aa1503e0 	mov	x0, x21
    80e8:	52800121 	mov	w1, #0x9                   	// #9
    80ec:	97ffede5 	bl	3880 <fwp_format_g.constprop.0>
    80f0:	17fffed3 	b	7c3c <fwp_write+0x69c>
    80f4:	d37ef6a1 	lsl	x1, x21, #2
    80f8:	b7f81563 	tbnz	x3, #63, 83a4 <fwp_write+0xe04>
    80fc:	91002263 	add	x3, x19, #0x8
    8100:	8b010061 	add	x1, x3, x1
    8104:	b9400023 	ldr	w3, [x1]
    8108:	7100081f 	cmp	w0, #0x2
    810c:	2a0303e1 	mov	w1, w3
    8110:	93407c63 	sxtw	x3, w3
    8114:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8118:	17fffe5a 	b	7a80 <fwp_write+0x4e0>
    811c:	d37ffaa1 	lsl	x1, x21, #1
    8120:	b7f81363 	tbnz	x3, #63, 838c <fwp_write+0xdec>
    8124:	91002263 	add	x3, x19, #0x8
    8128:	8b010061 	add	x1, x3, x1
    812c:	79400021 	ldrh	w1, [x1]
    8130:	7100041f 	cmp	w0, #0x1
    8134:	93403c23 	sxth	x3, w1
    8138:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    813c:	17fffe51 	b	7a80 <fwp_write+0x4e0>
    8140:	52800443 	mov	w3, #0x22                  	// #34
    8144:	91001ff5 	add	x21, sp, #0x7
    8148:	91002273 	add	x19, x19, #0x8
    814c:	aa1503e1 	mov	x1, x21
    8150:	aa1403e0 	mov	x0, x20
    8154:	d2800022 	mov	x2, #0x1                   	// #1
    8158:	39001fe3 	strb	w3, [sp, #7]
    815c:	f90143f7 	str	x23, [sp, #640]
    8160:	8b160277 	add	x23, x19, x22
    8164:	f90147f8 	str	x24, [sp, #648]
    8168:	97ffed2a 	bl	3610 <buf_put>
    816c:	b4000696 	cbz	x22, 823c <fwp_write+0xc9c>
    8170:	b0000038 	adrp	x24, d000 <__divti3+0x320>
    8174:	91246318 	add	x24, x24, #0x918
    8178:	f9014bf9 	str	x25, [sp, #656]
    817c:	b0000039 	adrp	x25, d000 <__divti3+0x320>
    8180:	9124e339 	add	x25, x25, #0x938
    8184:	f9014ffa 	str	x26, [sp, #664]
    8188:	1400000d 	b	81bc <fwp_write+0xc1c>
    818c:	710024bf 	cmp	w5, #0x9
    8190:	54000460 	b.eq	821c <fwp_write+0xc7c>  // b.none
    8194:	710028bf 	cmp	w5, #0xa
    8198:	54000a61 	b.ne	82e4 <fwp_write+0xd44>  // b.any
    819c:	b0000021 	adrp	x1, d000 <__divti3+0x320>
    81a0:	aa1403e0 	mov	x0, x20
    81a4:	9124a021 	add	x1, x1, #0x928
    81a8:	d2800042 	mov	x2, #0x2                   	// #2
    81ac:	97ffed19 	bl	3610 <buf_put>
    81b0:	91000673 	add	x19, x19, #0x1
    81b4:	eb17027f 	cmp	x19, x23
    81b8:	540003e0 	b.eq	8234 <fwp_write+0xc94>  // b.none
    81bc:	39400265 	ldrb	w5, [x19]
    81c0:	710034bf 	cmp	w5, #0xd
    81c4:	54000180 	b.eq	81f4 <fwp_write+0xc54>  // b.none
    81c8:	54fffe29 	b.ls	818c <fwp_write+0xbec>  // b.plast
    81cc:	710088bf 	cmp	w5, #0x22
    81d0:	540001c0 	b.eq	8208 <fwp_write+0xc68>  // b.none
    81d4:	710170bf 	cmp	w5, #0x5c
    81d8:	54000741 	b.ne	82c0 <fwp_write+0xd20>  // b.any
    81dc:	aa1403e0 	mov	x0, x20
    81e0:	b0000021 	adrp	x1, d000 <__divti3+0x320>
    81e4:	d2800042 	mov	x2, #0x2                   	// #2
    81e8:	91248021 	add	x1, x1, #0x920
    81ec:	97ffed09 	bl	3610 <buf_put>
    81f0:	17fffff0 	b	81b0 <fwp_write+0xc10>
    81f4:	aa1903e1 	mov	x1, x25
    81f8:	aa1403e0 	mov	x0, x20
    81fc:	d2800042 	mov	x2, #0x2                   	// #2
    8200:	97ffed04 	bl	3610 <buf_put>
    8204:	17ffffeb 	b	81b0 <fwp_write+0xc10>
    8208:	aa1803e1 	mov	x1, x24
    820c:	aa1403e0 	mov	x0, x20
    8210:	d2800042 	mov	x2, #0x2                   	// #2
    8214:	97ffecff 	bl	3610 <buf_put>
    8218:	17ffffe6 	b	81b0 <fwp_write+0xc10>
    821c:	aa1403e0 	mov	x0, x20
    8220:	b0000021 	adrp	x1, d000 <__divti3+0x320>
    8224:	d2800042 	mov	x2, #0x2                   	// #2
    8228:	9124c021 	add	x1, x1, #0x930
    822c:	97ffecf9 	bl	3610 <buf_put>
    8230:	17ffffe0 	b	81b0 <fwp_write+0xc10>
    8234:	f9414bf9 	ldr	x25, [sp, #656]
    8238:	f9414ffa 	ldr	x26, [sp, #664]
    823c:	aa1503e1 	mov	x1, x21
    8240:	aa1403e0 	mov	x0, x20
    8244:	52800443 	mov	w3, #0x22                  	// #34
    8248:	17fffd9c 	b	78b8 <fwp_write+0x318>
    824c:	7100103f 	cmp	w1, #0x4
    8250:	54ffeb21 	b.ne	7fb4 <fwp_write+0xa14>  // b.any
    8254:	f94006e0 	ldr	x0, [x23, #8]
    8258:	d37ffc00 	lsr	x0, x0, #63
    825c:	17fffeb3 	b	7d28 <fwp_write+0x788>
    8260:	710002ff 	cmp	w23, #0x0
    8264:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    8268:	17fffeb0 	b	7d28 <fwp_write+0x788>
    826c:	528005a1 	mov	w1, #0x2d                  	// #45
    8270:	eb0203e2 	negs	x2, x2
    8274:	da0303e3 	ngc	x3, x3
    8278:	910127e0 	add	x0, sp, #0x49
    827c:	910123f5 	add	x21, sp, #0x48
    8280:	390123e1 	strb	w1, [sp, #72]
    8284:	97ffeb07 	bl	2ea0 <fwp_fmt_u128>
    8288:	17fffe18 	b	7ae8 <fwp_write+0x548>
    828c:	d37ceea1 	lsl	x1, x21, #4
    8290:	b7f810a3 	tbnz	x3, #63, 84a4 <fwp_write+0xf04>
    8294:	91002260 	add	x0, x19, #0x8
    8298:	8b010001 	add	x1, x0, x1
    829c:	17fffdf9 	b	7a80 <fwp_write+0x4e0>
    82a0:	f9400a61 	ldr	x1, [x19, #16]
    82a4:	8b010000 	add	x0, x0, x1
    82a8:	f9400001 	ldr	x1, [x0]
    82ac:	17fffdf5 	b	7a80 <fwp_write+0x4e0>
    82b0:	b0000021 	adrp	x1, d000 <__divti3+0x320>
    82b4:	d2800042 	mov	x2, #0x2                   	// #2
    82b8:	91230021 	add	x1, x1, #0x8c0
    82bc:	17fffed6 	b	7e14 <fwp_write+0x874>
    82c0:	7101fcbf 	cmp	w5, #0x7f
    82c4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    82c8:	540000e9 	b.ls	82e4 <fwp_write+0xd44>  // b.plast
    82cc:	aa1503e1 	mov	x1, x21
    82d0:	aa1403e0 	mov	x0, x20
    82d4:	d2800022 	mov	x2, #0x1                   	// #1
    82d8:	39001fe5 	strb	w5, [sp, #7]
    82dc:	97ffeccd 	bl	3610 <buf_put>
    82e0:	17ffffb4 	b	81b0 <fwp_write+0xc10>
    82e4:	d2800203 	mov	x3, #0x10                  	// #16
    82e8:	b0000024 	adrp	x4, d000 <__divti3+0x320>
    82ec:	aa0303e1 	mov	x1, x3
    82f0:	91250084 	add	x4, x4, #0x940
    82f4:	910123f6 	add	x22, sp, #0x48
    82f8:	52800042 	mov	w2, #0x2                   	// #2
    82fc:	aa1603e0 	mov	x0, x22
    8300:	97ffe960 	bl	2880 <__snprintf_chk@plt>
    8304:	aa1603e0 	mov	x0, x22
    8308:	97ffe926 	bl	27a0 <strlen@plt>
    830c:	aa1603e1 	mov	x1, x22
    8310:	aa0003e2 	mov	x2, x0
    8314:	aa1403e0 	mov	x0, x20
    8318:	97ffecbe 	bl	3610 <buf_put>
    831c:	17ffffa5 	b	81b0 <fwp_write+0xc10>
    8320:	1e604100 	fmov	d0, d8
    8324:	aa1503e0 	mov	x0, x21
    8328:	52800221 	mov	w1, #0x11                  	// #17
    832c:	97ffed55 	bl	3880 <fwp_format_g.constprop.0>
    8330:	17fffe43 	b	7c3c <fwp_write+0x69c>
    8334:	b9401040 	ldr	w0, [x2, #16]
    8338:	350003c0 	cbnz	w0, 83b0 <fwp_write+0xe10>
    833c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8340:	f947f400 	ldr	x0, [x0, #4072]
    8344:	f94127e2 	ldr	x2, [sp, #584]
    8348:	f9400001 	ldr	x1, [x0]
    834c:	eb010042 	subs	x2, x2, x1
    8350:	d2800001 	mov	x1, #0x0                   	// #0
    8354:	54ffd721 	b.ne	7e38 <fwp_write+0x898>  // b.any
    8358:	f9413bf5 	ldr	x21, [sp, #624]
    835c:	b0000021 	adrp	x1, d000 <__divti3+0x320>
    8360:	f9413ff6 	ldr	x22, [sp, #632]
    8364:	aa1403e0 	mov	x0, x20
    8368:	f94143f7 	ldr	x23, [sp, #640]
    836c:	91264021 	add	x1, x1, #0x990
    8370:	f94147f8 	ldr	x24, [sp, #648]
    8374:	d2800042 	mov	x2, #0x2                   	// #2
    8378:	17fffd0e 	b	77b0 <fwp_write+0x210>
    837c:	b0000021 	adrp	x1, d000 <__divti3+0x320>
    8380:	d2800042 	mov	x2, #0x2                   	// #2
    8384:	91232021 	add	x1, x1, #0x8c8
    8388:	17fffea3 	b	7e14 <fwp_write+0x874>
    838c:	f9400a63 	ldr	x3, [x19, #16]
    8390:	8b030021 	add	x1, x1, x3
    8394:	17ffff66 	b	812c <fwp_write+0xb8c>
    8398:	f9400a61 	ldr	x1, [x19, #16]
    839c:	8b0102a1 	add	x1, x21, x1
    83a0:	17fffdb3 	b	7a6c <fwp_write+0x4cc>
    83a4:	f9400a63 	ldr	x3, [x19, #16]
    83a8:	8b030021 	add	x1, x1, x3
    83ac:	17ffff56 	b	8104 <fwp_write+0xb64>
    83b0:	b9404840 	ldr	w0, [x2, #72]
    83b4:	91001ff5 	add	x21, sp, #0x7
    83b8:	34ffa360 	cbz	w0, 7824 <fwp_write+0x284>
    83bc:	52800503 	mov	w3, #0x28                  	// #40
    83c0:	aa1403e0 	mov	x0, x20
    83c4:	aa1503e1 	mov	x1, x21
    83c8:	d2800022 	mov	x2, #0x1                   	// #1
    83cc:	39001fe3 	strb	w3, [sp, #7]
    83d0:	97ffec90 	bl	3610 <buf_put>
    83d4:	b9401380 	ldr	w0, [x28, #16]
    83d8:	52800038 	mov	w24, #0x1                   	// #1
    83dc:	7100001f 	cmp	w0, #0x0
    83e0:	54ffa36c 	b.gt	784c <fwp_write+0x2ac>
    83e4:	17fffd32 	b	78ac <fwp_write+0x30c>
    83e8:	f9014bf9 	str	x25, [sp, #656]
    83ec:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xea28>
    83f0:	f9014ffa 	str	x26, [sp, #664]
    83f4:	f9400676 	ldr	x22, [x19, #8]
    83f8:	910aa333 	add	x19, x25, #0x2a8
    83fc:	91002273 	add	x19, x19, #0x8
    8400:	937ffed8 	asr	x24, x22, #63
    8404:	aa1802c0 	orr	x0, x22, x24
    8408:	b5000320 	cbnz	x0, 846c <fwp_write+0xecc>
    840c:	110006b5 	add	w21, w21, #0x1
    8410:	710016bf 	cmp	w21, #0x5
    8414:	54ffffc1 	b.ne	840c <fwp_write+0xe6c>  // b.any
    8418:	b7f80578 	tbnz	x24, #63, 84c4 <fwp_write+0xf24>
    841c:	910023f3 	add	x19, sp, #0x8
    8420:	aa1603e2 	mov	x2, x22
    8424:	aa1303e0 	mov	x0, x19
    8428:	d2800003 	mov	x3, #0x0                   	// #0
    842c:	97ffea9d 	bl	2ea0 <fwp_fmt_u128>
    8430:	910123f5 	add	x21, sp, #0x48
    8434:	b0000023 	adrp	x3, d000 <__divti3+0x320>
    8438:	aa1303e4 	mov	x4, x19
    843c:	aa1503e0 	mov	x0, x21
    8440:	91262063 	add	x3, x3, #0x988
    8444:	d2804002 	mov	x2, #0x200                 	// #512
    8448:	52800041 	mov	w1, #0x2                   	// #2
    844c:	97ffe8d9 	bl	27b0 <__sprintf_chk@plt>
    8450:	aa1503e0 	mov	x0, x21
    8454:	97ffe8d3 	bl	27a0 <strlen@plt>
    8458:	aa1503e1 	mov	x1, x21
    845c:	aa0003e2 	mov	x2, x0
    8460:	aa1403e0 	mov	x0, x20
    8464:	97ffec6b 	bl	3610 <buf_put>
    8468:	17fffe47 	b	7d84 <fwp_write+0x7e4>
    846c:	f9400277 	ldr	x23, [x19]
    8470:	aa1603e0 	mov	x0, x22
    8474:	aa1803e1 	mov	x1, x24
    8478:	aa1703e2 	mov	x2, x23
    847c:	937ffefa 	asr	x26, x23, #63
    8480:	aa1a03e3 	mov	x3, x26
    8484:	940012f7 	bl	d060 <__modti3>
    8488:	aa010000 	orr	x0, x0, x1
    848c:	b40002c0 	cbz	x0, 84e4 <fwp_write+0xf44>
    8490:	110006b5 	add	w21, w21, #0x1
    8494:	91004273 	add	x19, x19, #0x10
    8498:	710016bf 	cmp	w21, #0x5
    849c:	54fffe81 	b.ne	846c <fwp_write+0xecc>  // b.any
    84a0:	17ffffde 	b	8418 <fwp_write+0xe78>
    84a4:	f9400a60 	ldr	x0, [x19, #16]
    84a8:	8b000021 	add	x1, x1, x0
    84ac:	17fffd75 	b	7a80 <fwp_write+0x4e0>
    84b0:	528c29c0 	mov	w0, #0x614e                	// #24910
    84b4:	910123f5 	add	x21, sp, #0x48
    84b8:	72a009c0 	movk	w0, #0x4e, lsl #16
    84bc:	b9004be0 	str	w0, [sp, #72]
    84c0:	17fffda2 	b	7b48 <fwp_write+0x5a8>
    84c4:	528005a1 	mov	w1, #0x2d                  	// #45
    84c8:	eb1603e2 	negs	x2, x22
    84cc:	da1803e3 	ngc	x3, x24
    84d0:	910027e0 	add	x0, sp, #0x9
    84d4:	910023f3 	add	x19, sp, #0x8
    84d8:	390023e1 	strb	w1, [sp, #8]
    84dc:	97ffea71 	bl	2ea0 <fwp_fmt_u128>
    84e0:	17ffffd4 	b	8430 <fwp_write+0xe90>
    84e4:	aa1703e2 	mov	x2, x23
    84e8:	aa1a03e3 	mov	x3, x26
    84ec:	aa1603e0 	mov	x0, x22
    84f0:	aa1803e1 	mov	x1, x24
    84f4:	940011fb 	bl	cce0 <__divti3>
    84f8:	aa0003e2 	mov	x2, x0
    84fc:	aa0103e3 	mov	x3, x1
    8500:	b7f80201 	tbnz	x1, #63, 8540 <fwp_write+0xfa0>
    8504:	910023f3 	add	x19, sp, #0x8
    8508:	aa1303e0 	mov	x0, x19
    850c:	97ffea65 	bl	2ea0 <fwp_fmt_u128>
    8510:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8514:	910aa339 	add	x25, x25, #0x2a8
    8518:	910123f5 	add	x21, sp, #0x48
    851c:	aa1303e4 	mov	x4, x19
    8520:	aa1503e0 	mov	x0, x21
    8524:	b0000023 	adrp	x3, d000 <__divti3+0x320>
    8528:	f8616b25 	ldr	x5, [x25, x1]
    852c:	91260063 	add	x3, x3, #0x980
    8530:	d2804002 	mov	x2, #0x200                 	// #512
    8534:	52800041 	mov	w1, #0x2                   	// #2
    8538:	97ffe89e 	bl	27b0 <__sprintf_chk@plt>
    853c:	17ffffc5 	b	8450 <fwp_write+0xeb0>
    8540:	528005a4 	mov	w4, #0x2d                  	// #45
    8544:	eb0003e2 	negs	x2, x0
    8548:	da0103e3 	ngc	x3, x1
    854c:	910027e0 	add	x0, sp, #0x9
    8550:	910023f3 	add	x19, sp, #0x8
    8554:	390023e4 	strb	w4, [sp, #8]
    8558:	97ffea52 	bl	2ea0 <fwp_fmt_u128>
    855c:	17ffffed 	b	8510 <fwp_write+0xf70>
    8560:	f9013bf5 	str	x21, [sp, #624]
    8564:	f9013ff6 	str	x22, [sp, #632]
    8568:	f90143f7 	str	x23, [sp, #640]
    856c:	f90147f8 	str	x24, [sp, #648]
    8570:	f9014bf9 	str	x25, [sp, #656]
    8574:	f9014ffa 	str	x26, [sp, #664]
    8578:	f90153fb 	str	x27, [sp, #672]
    857c:	f90157fc 	str	x28, [sp, #680]
    8580:	fd015be8 	str	d8, [sp, #688]
    8584:	fd015fe9 	str	d9, [sp, #696]
    8588:	97ffe8e2 	bl	2910 <__stack_chk_fail@plt>
    858c:	d503201f 	nop

0000000000008590 <fwp_hof0.constprop.0>:
    8590:	d105c3ff 	sub	sp, sp, #0x170
    8594:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    8598:	f947f442 	ldr	x2, [x2, #4072]
    859c:	a9117bfd 	stp	x29, x30, [sp, #272]
    85a0:	910443fd 	add	x29, sp, #0x110
    85a4:	a91673fb 	stp	x27, x28, [sp, #352]
    85a8:	aa0003fc 	mov	x28, x0
    85ac:	f9400040 	ldr	x0, [x2]
    85b0:	f90087e0 	str	x0, [sp, #264]
    85b4:	d2800000 	mov	x0, #0x0                   	// #0
    85b8:	b40036c1 	cbz	x1, 8c90 <fwp_hof0.constprop.0+0x700>
    85bc:	a91253f3 	stp	x19, x20, [sp, #288]
    85c0:	900000d4 	adrp	x20, 20000 <__data_start>
    85c4:	91004294 	add	x20, x20, #0x10
    85c8:	a91463f7 	stp	x23, x24, [sp, #320]
    85cc:	b0000157 	adrp	x23, 31000 <fwp_root_context+0xc10>
    85d0:	911742e4 	add	x4, x23, #0x5d0
    85d4:	910223e0 	add	x0, sp, #0x88
    85d8:	9100e294 	add	x20, x20, #0x38
    85dc:	aa1c03fb 	mov	x27, x28
    85e0:	a9135bf5 	stp	x21, x22, [sp, #304]
    85e4:	900000d5 	adrp	x21, 20000 <__data_start>
    85e8:	9101c2b8 	add	x24, x21, #0x70
    85ec:	a9156bf9 	stp	x25, x26, [sp, #336]
    85f0:	aa0403fa 	mov	x26, x4
    85f4:	d0fffff9 	adrp	x25, 6000 <fwp_drop1+0x80>
    85f8:	f90003e0 	str	x0, [sp]
    85fc:	910243e0 	add	x0, sp, #0x90
    8600:	f90007e0 	str	x0, [sp, #8]
    8604:	f9000fe1 	str	x1, [sp, #24]
    8608:	f949ef45 	ldr	x5, [x26, #5080]
    860c:	f949db41 	ldr	x1, [x26, #5040]
    8610:	d370bca5 	lsl	x5, x5, #16
    8614:	cb010363 	sub	x3, x27, x1
    8618:	eb05007f 	cmp	x3, x5
    861c:	540003e2 	b.cs	8698 <fwp_hof0.constprop.0+0x108>  // b.hs, b.nlast
    8620:	d350fc60 	lsr	x0, x3, #16
    8624:	f949ff47 	ldr	x7, [x26, #5112]
    8628:	8b000800 	add	x0, x0, x0, lsl #2
    862c:	d37df002 	lsl	x2, x0, #3
    8630:	8b0200e6 	add	x6, x7, x2
    8634:	f94010c0 	ldr	x0, [x6, #32]
    8638:	b4000300 	cbz	x0, 8698 <fwp_hof0.constprop.0+0x108>
    863c:	386268e2 	ldrb	w2, [x7, x2]
    8640:	7100085f 	cmp	w2, #0x2
    8644:	54000de0 	b.eq	8800 <fwp_hof0.constprop.0+0x270>  // b.none
    8648:	7100045f 	cmp	w2, #0x1
    864c:	54000261 	b.ne	8698 <fwp_hof0.constprop.0+0x108>  // b.any
    8650:	92403c62 	and	x2, x3, #0xffff
    8654:	29430cc7 	ldp	w7, w3, [x6, #24]
    8658:	9b077c42 	mul	x2, x2, x7
    865c:	d360fc42 	lsr	x2, x2, #32
    8660:	eb03005f 	cmp	x2, x3
    8664:	540001a2 	b.cs	8698 <fwp_hof0.constprop.0+0x108>  // b.hs, b.nlast
    8668:	8b020000 	add	x0, x0, x2
    866c:	39400002 	ldrb	w2, [x0]
    8670:	34000142 	cbz	w2, 8698 <fwp_hof0.constprop.0+0x108>
    8674:	7103f45f 	cmp	w2, #0xfd
    8678:	54005028 	b.hi	907c <fwp_hof0.constprop.0+0xaec>  // b.pmore
    867c:	911742e1 	add	x1, x23, #0x5d0
    8680:	11000442 	add	w2, w2, #0x1
    8684:	39000002 	strb	w2, [x0]
    8688:	aa0103e0 	mov	x0, x1
    868c:	f949d821 	ldr	x1, [x1, #5040]
    8690:	f949ec05 	ldr	x5, [x0, #5080]
    8694:	d370bca5 	lsl	x5, x5, #16
    8698:	aa1b03f3 	mov	x19, x27
    869c:	91124336 	add	x22, x25, #0x490
    86a0:	d28018c0 	mov	x0, #0xc6                  	// #198
    86a4:	b2407bfc 	mov	x28, #0x7fffffff            	// #2147483647
    86a8:	f9000be0 	str	x0, [sp, #16]
    86ac:	a9026bfb 	stp	x27, x26, [sp, #32]
    86b0:	12800002 	mov	w2, #0xffffffff            	// #-1
    86b4:	f9418b00 	ldr	x0, [x24, #784]
    86b8:	a9095be0 	stp	x0, x22, [sp, #144]
    86bc:	cb010281 	sub	x1, x20, x1
    86c0:	f94003e0 	ldr	x0, [sp]
    86c4:	f90053e0 	str	x0, [sp, #160]
    86c8:	f94007e0 	ldr	x0, [sp, #8]
    86cc:	b9008be2 	str	w2, [sp, #136]
    86d0:	f9018b00 	str	x0, [x24, #784]
    86d4:	eb05003f 	cmp	x1, x5
    86d8:	54000782 	b.cs	87c8 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    86dc:	911742e2 	add	x2, x23, #0x5d0
    86e0:	d350fc20 	lsr	x0, x1, #16
    86e4:	8b000800 	add	x0, x0, x0, lsl #2
    86e8:	f949fc43 	ldr	x3, [x2, #5112]
    86ec:	d37df000 	lsl	x0, x0, #3
    86f0:	8b000062 	add	x2, x3, x0
    86f4:	f940105a 	ldr	x26, [x2, #32]
    86f8:	b400069a 	cbz	x26, 87c8 <fwp_hof0.constprop.0+0x238>
    86fc:	38606860 	ldrb	w0, [x3, x0]
    8700:	7100081f 	cmp	w0, #0x2
    8704:	54000840 	b.eq	880c <fwp_hof0.constprop.0+0x27c>  // b.none
    8708:	7100041f 	cmp	w0, #0x1
    870c:	540005e1 	b.ne	87c8 <fwp_hof0.constprop.0+0x238>  // b.any
    8710:	29430c44 	ldp	w4, w3, [x2, #24]
    8714:	92403c20 	and	x0, x1, #0xffff
    8718:	9b047c00 	mul	x0, x0, x4
    871c:	d360fc00 	lsr	x0, x0, #32
    8720:	eb03001f 	cmp	x0, x3
    8724:	54000282 	b.cs	8774 <fwp_hof0.constprop.0+0x1e4>  // b.hs, b.nlast
    8728:	8b000340 	add	x0, x26, x0
    872c:	39400003 	ldrb	w3, [x0]
    8730:	34000223 	cbz	w3, 8774 <fwp_hof0.constprop.0+0x1e4>
    8734:	7103f47f 	cmp	w3, #0xfd
    8738:	54004e68 	b.hi	9104 <fwp_hof0.constprop.0+0xb74>  // b.pmore
    873c:	11000463 	add	w3, w3, #0x1
    8740:	39000003 	strb	w3, [x0]
    8744:	911742e0 	add	x0, x23, #0x5d0
    8748:	f949d801 	ldr	x1, [x0, #5040]
    874c:	f949ec02 	ldr	x2, [x0, #5080]
    8750:	cb010281 	sub	x1, x20, x1
    8754:	eb02403f 	cmp	x1, x2, lsl #16
    8758:	54000382 	b.cs	87c8 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    875c:	f949fc00 	ldr	x0, [x0, #5112]
    8760:	d350fc22 	lsr	x2, x1, #16
    8764:	8b020842 	add	x2, x2, x2, lsl #2
    8768:	8b020c02 	add	x2, x0, x2, lsl #3
    876c:	f940105a 	ldr	x26, [x2, #32]
    8770:	b40002da 	cbz	x26, 87c8 <fwp_hof0.constprop.0+0x238>
    8774:	39400040 	ldrb	w0, [x2]
    8778:	7100081f 	cmp	w0, #0x2
    877c:	54000dc0 	b.eq	8934 <fwp_hof0.constprop.0+0x3a4>  // b.none
    8780:	7100041f 	cmp	w0, #0x1
    8784:	54000221 	b.ne	87c8 <fwp_hof0.constprop.0+0x238>  // b.any
    8788:	29430043 	ldp	w3, w0, [x2, #24]
    878c:	92403c21 	and	x1, x1, #0xffff
    8790:	9b037c21 	mul	x1, x1, x3
    8794:	d360fc21 	lsr	x1, x1, #32
    8798:	eb00003f 	cmp	x1, x0
    879c:	54000162 	b.cs	87c8 <fwp_hof0.constprop.0+0x238>  // b.hs, b.nlast
    87a0:	8b01035a 	add	x26, x26, x1
    87a4:	39400340 	ldrb	w0, [x26]
    87a8:	34000100 	cbz	w0, 87c8 <fwp_hof0.constprop.0+0x238>
    87ac:	7100041f 	cmp	w0, #0x1
    87b0:	54000360 	b.eq	881c <fwp_hof0.constprop.0+0x28c>  // b.none
    87b4:	7103fc1f 	cmp	w0, #0xff
    87b8:	540046e0 	b.eq	9094 <fwp_hof0.constprop.0+0xb04>  // b.none
    87bc:	51000400 	sub	w0, w0, #0x1
    87c0:	39000340 	strb	w0, [x26]
    87c4:	d503201f 	nop
    87c8:	b40003b3 	cbz	x19, 883c <fwp_hof0.constprop.0+0x2ac>
    87cc:	aa1303e0 	mov	x0, x19
    87d0:	d280001b 	mov	x27, #0x0                   	// #0
    87d4:	d503201f 	nop
    87d8:	f9400800 	ldr	x0, [x0, #16]
    87dc:	9100077b 	add	x27, x27, #0x1
    87e0:	b5ffffc0 	cbnz	x0, 87d8 <fwp_hof0.constprop.0+0x248>
    87e4:	52800000 	mov	w0, #0x0                   	// #0
    87e8:	97ffeba2 	bl	3670 <descent_phase_step>
    87ec:	eb1c037f 	cmp	x27, x28
    87f0:	540002c9 	b.ls	8848 <fwp_hof0.constprop.0+0x2b8>  // b.plast
    87f4:	b0000020 	adrp	x0, d000 <__divti3+0x320>
    87f8:	91268000 	add	x0, x0, #0x9a0
    87fc:	97ffee65 	bl	4190 <fwp_trap>
    8800:	72003c7f 	tst	w3, #0xffff
    8804:	54fff4a1 	b.ne	8698 <fwp_hof0.constprop.0+0x108>  // b.any
    8808:	17ffff99 	b	866c <fwp_hof0.constprop.0+0xdc>
    880c:	72003c3f 	tst	w1, #0xffff
    8810:	54fffb21 	b.ne	8774 <fwp_hof0.constprop.0+0x1e4>  // b.any
    8814:	aa1a03e0 	mov	x0, x26
    8818:	17ffffc5 	b	872c <fwp_hof0.constprop.0+0x19c>
    881c:	d53bd040 	mrs	x0, tpidr_el0
    8820:	91400000 	add	x0, x0, #0x0, lsl #12
    8824:	91004000 	add	x0, x0, #0x10
    8828:	f9400000 	ldr	x0, [x0]
    882c:	b40007e0 	cbz	x0, 8928 <fwp_hof0.constprop.0+0x398>
    8830:	aa1403e1 	mov	x1, x20
    8834:	97ffefd3 	bl	4780 <fwp_closure_drop_push>
    8838:	17ffffe4 	b	87c8 <fwp_hof0.constprop.0+0x238>
    883c:	d280001b 	mov	x27, #0x0                   	// #0
    8840:	52800000 	mov	w0, #0x0                   	// #0
    8844:	97ffeb8b 	bl	3670 <descent_phase_step>
    8848:	9101c2ba 	add	x26, x21, #0x70
    884c:	b9434740 	ldr	w0, [x26, #836]
    8850:	34002380 	cbz	w0, 8cc0 <fwp_hof0.constprop.0+0x730>
    8854:	9101c2a0 	add	x0, x21, #0x70
    8858:	f9406802 	ldr	x2, [x0, #208]
    885c:	f940741a 	ldr	x26, [x0, #232]
    8860:	eb02035f 	cmp	x26, x2
    8864:	540006ea 	b.ge	8940 <fwp_hof0.constprop.0+0x3b0>  // b.tcont
    8868:	f9403aa1 	ldr	x1, [x21, #112]
    886c:	8b1a0740 	add	x0, x26, x26, lsl #1
    8870:	528fffc3 	mov	w3, #0x7ffe                	// #32766
    8874:	8b000b40 	add	x0, x26, x0, lsl #2
    8878:	8b000c20 	add	x0, x1, x0, lsl #3
    887c:	d503201f 	nop
    8880:	b9400401 	ldr	w1, [x0, #4]
    8884:	35000081 	cbnz	w1, 8894 <fwp_hof0.constprop.0+0x304>
    8888:	b9400001 	ldr	w1, [x0]
    888c:	6b03003f 	cmp	w1, w3
    8890:	54000589 	b.ls	8940 <fwp_hof0.constprop.0+0x3b0>  // b.plast
    8894:	9100075a 	add	x26, x26, #0x1
    8898:	9101a000 	add	x0, x0, #0x68
    889c:	eb02035f 	cmp	x26, x2
    88a0:	54ffff01 	b.ne	8880 <fwp_hof0.constprop.0+0x2f0>  // b.any
    88a4:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    88a8:	eb00005f 	cmp	x2, x0
    88ac:	5400348c 	b.gt	8f3c <fwp_hof0.constprop.0+0x9ac>
    88b0:	9101c2a0 	add	x0, x21, #0x70
    88b4:	f9403aa5 	ldr	x5, [x21, #112]
    88b8:	f9407000 	ldr	x0, [x0, #224]
    88bc:	eb02001f 	cmp	x0, x2
    88c0:	540001a1 	b.ne	88f4 <fwp_hof0.constprop.0+0x364>  // b.any
    88c4:	b5003422 	cbnz	x2, 8f48 <fwp_hof0.constprop.0+0x9b8>
    88c8:	d2800d01 	mov	x1, #0x68                  	// #104
    88cc:	d280003a 	mov	x26, #0x1                   	// #1
    88d0:	aa0503e0 	mov	x0, x5
    88d4:	f9001be2 	str	x2, [sp, #48]
    88d8:	97ffe80a 	bl	2900 <realloc@plt>
    88dc:	aa0003e5 	mov	x5, x0
    88e0:	f9401be2 	ldr	x2, [sp, #48]
    88e4:	b4007360 	cbz	x0, 9750 <fwp_hof0.constprop.0+0x11c0>
    88e8:	9101c2a0 	add	x0, x21, #0x70
    88ec:	f9003aa5 	str	x5, [x21, #112]
    88f0:	f900701a 	str	x26, [x0, #224]
    88f4:	8b020440 	add	x0, x2, x2, lsl #1
    88f8:	9101c2a1 	add	x1, x21, #0x70
    88fc:	4f000400 	movi	v0.4s, #0x0
    8900:	aa0203fa 	mov	x26, x2
    8904:	8b000840 	add	x0, x2, x0, lsl #2
    8908:	91000442 	add	x2, x2, #0x1
    890c:	f9006822 	str	x2, [x1, #208]
    8910:	8b000ca0 	add	x0, x5, x0, lsl #3
    8914:	ad000000 	stp	q0, q0, [x0]
    8918:	ad010000 	stp	q0, q0, [x0, #32]
    891c:	ad020000 	stp	q0, q0, [x0, #64]
    8920:	f900301f 	str	xzr, [x0, #96]
    8924:	1400000a 	b	894c <fwp_hof0.constprop.0+0x3bc>
    8928:	aa1403e0 	mov	x0, x20
    892c:	97ffefda 	bl	4894 <fwp_closure_drop.part.0>
    8930:	17ffffa6 	b	87c8 <fwp_hof0.constprop.0+0x238>
    8934:	72003c3f 	tst	w1, #0xffff
    8938:	54fff481 	b.ne	87c8 <fwp_hof0.constprop.0+0x238>  // b.any
    893c:	17ffff9a 	b	87a4 <fwp_hof0.constprop.0+0x214>
    8940:	eb1a005f 	cmp	x2, x26
    8944:	54fffb00 	b.eq	88a4 <fwp_hof0.constprop.0+0x314>  // b.none
    8948:	f9403aa5 	ldr	x5, [x21, #112]
    894c:	8b1a0743 	add	x3, x26, x26, lsl #1
    8950:	b0000020 	adrp	x0, d000 <__divti3+0x320>
    8954:	91174000 	add	x0, x0, #0x5d0
    8958:	8b030b43 	add	x3, x26, x3, lsl #2
    895c:	8b030ca3 	add	x3, x5, x3, lsl #3
    8960:	a90317e3 	stp	x3, x5, [sp, #48]
    8964:	f900307f 	str	xzr, [x3, #96]
    8968:	97ffe84e 	bl	2aa0 <getenv@plt>
    896c:	a94317e3 	ldp	x3, x5, [sp, #48]
    8970:	b4000840 	cbz	x0, 8a78 <fwp_hof0.constprop.0+0x4e8>
    8974:	39400001 	ldrb	w1, [x0]
    8978:	7100c03f 	cmp	w1, #0x30
    897c:	540007e1 	b.ne	8a78 <fwp_hof0.constprop.0+0x4e8>  // b.any
    8980:	39400400 	ldrb	w0, [x0, #1]
    8984:	350007a0 	cbnz	w0, 8a78 <fwp_hof0.constprop.0+0x4e8>
    8988:	9101c2a2 	add	x2, x21, #0x70
    898c:	2f000400 	mvni	v0.2s, #0x0
    8990:	b9400060 	ldr	w0, [x3]
    8994:	91000747 	add	x7, x26, #0x1
    8998:	a900ec7b 	stp	x27, x27, [x3, #8]
    899c:	11000406 	add	w6, w0, #0x1
    89a0:	f9418841 	ldr	x1, [x2, #784]
    89a4:	52800020 	mov	w0, #0x1                   	// #1
    89a8:	29000066 	stp	w6, w0, [x3]
    89ac:	f900287f 	str	xzr, [x3, #80]
    89b0:	f9007447 	str	x7, [x2, #232]
    89b4:	fd002c60 	str	d0, [x3, #88]
    89b8:	b4003541 	cbz	x1, 9060 <fwp_hof0.constprop.0+0xad0>
    89bc:	91124324 	add	x4, x25, #0x490
    89c0:	14000003 	b	89cc <fwp_hof0.constprop.0+0x43c>
    89c4:	f9400021 	ldr	x1, [x1]
    89c8:	b40034c1 	cbz	x1, 9060 <fwp_hof0.constprop.0+0xad0>
    89cc:	f9400420 	ldr	x0, [x1, #8]
    89d0:	eb04001f 	cmp	x0, x4
    89d4:	54ffff81 	b.ne	89c4 <fwp_hof0.constprop.0+0x434>  // b.any
    89d8:	f9400820 	ldr	x0, [x1, #16]
    89dc:	2a1a03e2 	mov	w2, w26
    89e0:	b9400001 	ldr	w1, [x0]
    89e4:	f9002860 	str	x0, [x3, #80]
    89e8:	b9005c61 	str	w1, [x3, #92]
    89ec:	37f80081 	tbnz	w1, #31, 89fc <fwp_hof0.constprop.0+0x46c>
    89f0:	52800d03 	mov	w3, #0x68                  	// #104
    89f4:	9b231421 	smaddl	x1, w1, w3, x5
    89f8:	b900583a 	str	w26, [x1, #88]
    89fc:	b9000002 	str	w2, [x0]
    8a00:	52800020 	mov	w0, #0x1                   	// #1
    8a04:	b90033e6 	str	w6, [sp, #48]
    8a08:	f9001fe7 	str	x7, [sp, #56]
    8a0c:	97ffeb19 	bl	3670 <descent_phase_step>
    8a10:	f9401fe7 	ldr	x7, [sp, #56]
    8a14:	aa1303e0 	mov	x0, x19
    8a18:	b94033e6 	ldr	w6, [sp, #48]
    8a1c:	d2800002 	mov	x2, #0x0                   	// #0
    8a20:	b40015f3 	cbz	x19, 8cdc <fwp_hof0.constprop.0+0x74c>
    8a24:	d503201f 	nop
    8a28:	f9400800 	ldr	x0, [x0, #16]
    8a2c:	91000442 	add	x2, x2, #0x1
    8a30:	b5ffffc0 	cbnz	x0, 8a28 <fwp_hof0.constprop.0+0x498>
    8a34:	aa1303e1 	mov	x1, x19
    8a38:	f9400821 	ldr	x1, [x1, #16]
    8a3c:	91000400 	add	x0, x0, #0x1
    8a40:	b5ffffc1 	cbnz	x1, 8a38 <fwp_hof0.constprop.0+0x4a8>
    8a44:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8a48:	eb01001f 	cmp	x0, x1
    8a4c:	54000108 	b.hi	8a6c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    8a50:	f100005f 	cmp	x2, #0x0
    8a54:	5400144d 	b.le	8cdc <fwp_hof0.constprop.0+0x74c>
    8a58:	eb00005f 	cmp	x2, x0
    8a5c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8a60:	9a80905b 	csel	x27, x2, x0, ls	// ls = plast
    8a64:	eb01037f 	cmp	x27, x1
    8a68:	54002809 	b.ls	8f68 <fwp_hof0.constprop.0+0x9d8>  // b.plast
    8a6c:	b0000020 	adrp	x0, d000 <__divti3+0x320>
    8a70:	91228000 	add	x0, x0, #0x8a0
    8a74:	97ffedc7 	bl	4190 <fwp_trap>
    8a78:	9101c2a0 	add	x0, x21, #0x70
    8a7c:	f9406001 	ldr	x1, [x0, #192]
    8a80:	b4fff841 	cbz	x1, 8988 <fwp_hof0.constprop.0+0x3f8>
    8a84:	3cc88002 	ldur	q2, [x0, #136]
    8a88:	91022001 	add	x1, x0, #0x88
    8a8c:	3cc98001 	ldur	q1, [x0, #152]
    8a90:	f900601f 	str	xzr, [x0, #192]
    8a94:	4f000400 	movi	v0.4s, #0x0
    8a98:	ad010462 	stp	q2, q1, [x3, #32]
    8a9c:	f9405c00 	ldr	x0, [x0, #184]
    8aa0:	f9002460 	str	x0, [x3, #72]
    8aa4:	f9401020 	ldr	x0, [x1, #32]
    8aa8:	f9002060 	str	x0, [x3, #64]
    8aac:	f9401420 	ldr	x0, [x1, #40]
    8ab0:	f9000c60 	str	x0, [x3, #24]
    8ab4:	f900183f 	str	xzr, [x1, #48]
    8ab8:	ad000020 	stp	q0, q0, [x1]
    8abc:	3d800820 	str	q0, [x1, #32]
    8ac0:	17ffffb2 	b	8988 <fwp_hof0.constprop.0+0x3f8>
    8ac4:	f9401be0 	ldr	x0, [sp, #48]
    8ac8:	d00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xea28>
    8acc:	910aa042 	add	x2, x2, #0x2a8
    8ad0:	aa1303e1 	mov	x1, x19
    8ad4:	a9426bfb 	ldp	x27, x26, [sp, #32]
    8ad8:	91014042 	add	x2, x2, #0x50
    8adc:	52800023 	mov	w3, #0x1                   	// #1
    8ae0:	a90c7fff 	stp	xzr, xzr, [sp, #192]
    8ae4:	f9006bff 	str	xzr, [sp, #208]
    8ae8:	97fffaae 	bl	75a0 <fwp_write>
    8aec:	a94c0bfc 	ldp	x28, x2, [sp, #192]
    8af0:	b0000020 	adrp	x0, d000 <__divti3+0x320>
    8af4:	913d4000 	add	x0, x0, #0xf50
    8af8:	f100039f 	cmp	x28, #0x0
    8afc:	9a9c001c 	csel	x28, x0, x28, eq	// eq = none
    8b00:	b100285f 	cmn	x2, #0xa
    8b04:	54008de8 	b.hi	9cc0 <fwp_hof0.constprop.0+0x1730>  // b.pmore
    8b08:	91002440 	add	x0, x2, #0x9
    8b0c:	52800021 	mov	w1, #0x1                   	// #1
    8b10:	f9000be2 	str	x2, [sp, #16]
    8b14:	97fff117 	bl	4f70 <fwp_heap_alloc>
    8b18:	aa1c03e1 	mov	x1, x28
    8b1c:	aa0003fc 	mov	x28, x0
    8b20:	f9400be2 	ldr	x2, [sp, #16]
    8b24:	aa0003f6 	mov	x22, x0
    8b28:	f8008782 	str	x2, [x28], #8
    8b2c:	aa1c03e0 	mov	x0, x28
    8b30:	97ffe70c 	bl	2760 <memcpy@plt>
    8b34:	f9400be2 	ldr	x2, [sp, #16]
    8b38:	8b0202c2 	add	x2, x22, x2
    8b3c:	3900205f 	strb	wzr, [x2, #8]
    8b40:	f94063e0 	ldr	x0, [sp, #192]
    8b44:	97ffe7a3 	bl	29d0 <free@plt>
    8b48:	911742e2 	add	x2, x23, #0x5d0
    8b4c:	f949d841 	ldr	x1, [x2, #5040]
    8b50:	f949ec40 	ldr	x0, [x2, #5080]
    8b54:	cb0102c1 	sub	x1, x22, x1
    8b58:	eb00403f 	cmp	x1, x0, lsl #16
    8b5c:	54000322 	b.cs	8bc0 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    8b60:	d350fc20 	lsr	x0, x1, #16
    8b64:	f949fc45 	ldr	x5, [x2, #5112]
    8b68:	8b000800 	add	x0, x0, x0, lsl #2
    8b6c:	d37df002 	lsl	x2, x0, #3
    8b70:	8b0200a3 	add	x3, x5, x2
    8b74:	f9401060 	ldr	x0, [x3, #32]
    8b78:	b4000240 	cbz	x0, 8bc0 <fwp_hof0.constprop.0+0x630>
    8b7c:	386268a2 	ldrb	w2, [x5, x2]
    8b80:	7100085f 	cmp	w2, #0x2
    8b84:	54008b00 	b.eq	9ce4 <fwp_hof0.constprop.0+0x1754>  // b.none
    8b88:	7100045f 	cmp	w2, #0x1
    8b8c:	540001a1 	b.ne	8bc0 <fwp_hof0.constprop.0+0x630>  // b.any
    8b90:	29430865 	ldp	w5, w2, [x3, #24]
    8b94:	92403c21 	and	x1, x1, #0xffff
    8b98:	9b057c21 	mul	x1, x1, x5
    8b9c:	d360fc21 	lsr	x1, x1, #32
    8ba0:	eb02003f 	cmp	x1, x2
    8ba4:	540000e2 	b.cs	8bc0 <fwp_hof0.constprop.0+0x630>  // b.hs, b.nlast
    8ba8:	8b010000 	add	x0, x0, x1
    8bac:	39400001 	ldrb	w1, [x0]
    8bb0:	7103fc3f 	cmp	w1, #0xff
    8bb4:	540089e0 	b.eq	9cf0 <fwp_hof0.constprop.0+0x1760>  // b.none
    8bb8:	52800021 	mov	w1, #0x1                   	// #1
    8bbc:	39000001 	strb	w1, [x0]
    8bc0:	aa1303e0 	mov	x0, x19
    8bc4:	9101c2b3 	add	x19, x21, #0x70
    8bc8:	97fff492 	bl	5e10 <fwp_drop0>
    8bcc:	f94002c2 	ldr	x2, [x22]
    8bd0:	d2800021 	mov	x1, #0x1                   	// #1
    8bd4:	f9400663 	ldr	x3, [x19, #8]
    8bd8:	aa1c03e0 	mov	x0, x28
    8bdc:	97ffe78d 	bl	2a10 <fwrite@plt>
    8be0:	f9400661 	ldr	x1, [x19, #8]
    8be4:	52800140 	mov	w0, #0xa                   	// #10
    8be8:	97ffe712 	bl	2830 <fputc@plt>
    8bec:	911742e2 	add	x2, x23, #0x5d0
    8bf0:	f949d841 	ldr	x1, [x2, #5040]
    8bf4:	f949ec40 	ldr	x0, [x2, #5080]
    8bf8:	cb0102c1 	sub	x1, x22, x1
    8bfc:	eb00403f 	cmp	x1, x0, lsl #16
    8c00:	54000382 	b.cs	8c70 <fwp_hof0.constprop.0+0x6e0>  // b.hs, b.nlast
    8c04:	d350fc20 	lsr	x0, x1, #16
    8c08:	f949fc45 	ldr	x5, [x2, #5112]
    8c0c:	8b000800 	add	x0, x0, x0, lsl #2
    8c10:	d37df002 	lsl	x2, x0, #3
    8c14:	8b0200a3 	add	x3, x5, x2
    8c18:	f9401073 	ldr	x19, [x3, #32]
    8c1c:	b40002b3 	cbz	x19, 8c70 <fwp_hof0.constprop.0+0x6e0>
    8c20:	386268a2 	ldrb	w2, [x5, x2]
    8c24:	7100085f 	cmp	w2, #0x2
    8c28:	54008580 	b.eq	9cd8 <fwp_hof0.constprop.0+0x1748>  // b.none
    8c2c:	7100045f 	cmp	w2, #0x1
    8c30:	54000201 	b.ne	8c70 <fwp_hof0.constprop.0+0x6e0>  // b.any
    8c34:	29430062 	ldp	w2, w0, [x3, #24]
    8c38:	92403c21 	and	x1, x1, #0xffff
    8c3c:	9b027c21 	mul	x1, x1, x2
    8c40:	d360fc21 	lsr	x1, x1, #32
    8c44:	eb00003f 	cmp	x1, x0
    8c48:	54000142 	b.cs	8c70 <fwp_hof0.constprop.0+0x6e0>  // b.hs, b.nlast
    8c4c:	8b010273 	add	x19, x19, x1
    8c50:	39400261 	ldrb	w1, [x19]
    8c54:	340000e1 	cbz	w1, 8c70 <fwp_hof0.constprop.0+0x6e0>
    8c58:	7100043f 	cmp	w1, #0x1
    8c5c:	54008380 	b.eq	9ccc <fwp_hof0.constprop.0+0x173c>  // b.none
    8c60:	7103fc3f 	cmp	w1, #0xff
    8c64:	540084e0 	b.eq	9d00 <fwp_hof0.constprop.0+0x1770>  // b.none
    8c68:	51000421 	sub	w1, w1, #0x1
    8c6c:	39000261 	strb	w1, [x19]
    8c70:	f9400fe0 	ldr	x0, [sp, #24]
    8c74:	f9400800 	ldr	x0, [x0, #16]
    8c78:	f9000fe0 	str	x0, [sp, #24]
    8c7c:	b5ffcc60 	cbnz	x0, 8608 <fwp_hof0.constprop.0+0x78>
    8c80:	a95253f3 	ldp	x19, x20, [sp, #288]
    8c84:	a9535bf5 	ldp	x21, x22, [sp, #304]
    8c88:	a95463f7 	ldp	x23, x24, [sp, #320]
    8c8c:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8c90:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8c94:	f947f400 	ldr	x0, [x0, #4072]
    8c98:	f94087e2 	ldr	x2, [sp, #264]
    8c9c:	f9400001 	ldr	x1, [x0]
    8ca0:	eb010042 	subs	x2, x2, x1
    8ca4:	d2800001 	mov	x1, #0x0                   	// #0
    8ca8:	54009621 	b.ne	9f6c <fwp_hof0.constprop.0+0x19dc>  // b.any
    8cac:	a9517bfd 	ldp	x29, x30, [sp, #272]
    8cb0:	d2800000 	mov	x0, #0x0                   	// #0
    8cb4:	a95673fb 	ldp	x27, x28, [sp, #352]
    8cb8:	9105c3ff 	add	sp, sp, #0x170
    8cbc:	d65f03c0 	ret
    8cc0:	d0ffffe0 	adrp	x0, 6000 <fwp_drop1+0x80>
    8cc4:	910e4000 	add	x0, x0, #0x390
    8cc8:	940011c2 	bl	d3d0 <atexit>
    8ccc:	35005420 	cbnz	w0, 9750 <fwp_hof0.constprop.0+0x11c0>
    8cd0:	52800020 	mov	w0, #0x1                   	// #1
    8cd4:	b9034740 	str	w0, [x26, #836]
    8cd8:	17fffedf 	b	8854 <fwp_hof0.constprop.0+0x2c4>
    8cdc:	d3707cc0 	ubfiz	x0, x6, #16, #32
    8ce0:	52800041 	mov	w1, #0x2                   	// #2
    8ce4:	aa070000 	orr	x0, x0, x7
    8ce8:	f9001be0 	str	x0, [sp, #48]
    8cec:	d2800100 	mov	x0, #0x8                   	// #8
    8cf0:	97fff0a0 	bl	4f70 <fwp_heap_alloc>
    8cf4:	aa0003e7 	mov	x7, x0
    8cf8:	911742e0 	add	x0, x23, #0x5d0
    8cfc:	aa0703e8 	mov	x8, x7
    8d00:	f90000ff 	str	xzr, [x7]
    8d04:	f949d801 	ldr	x1, [x0, #5040]
    8d08:	f949ec00 	ldr	x0, [x0, #5080]
    8d0c:	cb0100e1 	sub	x1, x7, x1
    8d10:	eb00403f 	cmp	x1, x0, lsl #16
    8d14:	54001522 	b.cs	8fb8 <fwp_hof0.constprop.0+0xa28>  // b.hs, b.nlast
    8d18:	d280001b 	mov	x27, #0x0                   	// #0
    8d1c:	911742e2 	add	x2, x23, #0x5d0
    8d20:	d350fc20 	lsr	x0, x1, #16
    8d24:	8b000800 	add	x0, x0, x0, lsl #2
    8d28:	f949fc44 	ldr	x4, [x2, #5112]
    8d2c:	d37df002 	lsl	x2, x0, #3
    8d30:	8b020083 	add	x3, x4, x2
    8d34:	f940107a 	ldr	x26, [x3, #32]
    8d38:	b400025a 	cbz	x26, 8d80 <fwp_hof0.constprop.0+0x7f0>
    8d3c:	38626882 	ldrb	w2, [x4, x2]
    8d40:	7100085f 	cmp	w2, #0x2
    8d44:	54001400 	b.eq	8fc4 <fwp_hof0.constprop.0+0xa34>  // b.none
    8d48:	7100045f 	cmp	w2, #0x1
    8d4c:	540001a1 	b.ne	8d80 <fwp_hof0.constprop.0+0x7f0>  // b.any
    8d50:	29430864 	ldp	w4, w2, [x3, #24]
    8d54:	92403c21 	and	x1, x1, #0xffff
    8d58:	9b047c21 	mul	x1, x1, x4
    8d5c:	d360fc21 	lsr	x1, x1, #32
    8d60:	eb02003f 	cmp	x1, x2
    8d64:	540000e2 	b.cs	8d80 <fwp_hof0.constprop.0+0x7f0>  // b.hs, b.nlast
    8d68:	8b01035a 	add	x26, x26, x1
    8d6c:	39400341 	ldrb	w1, [x26]
    8d70:	7103fc3f 	cmp	w1, #0xff
    8d74:	54004c20 	b.eq	96f8 <fwp_hof0.constprop.0+0x1168>  // b.none
    8d78:	52800021 	mov	w1, #0x1                   	// #1
    8d7c:	39000341 	strb	w1, [x26]
    8d80:	b400025b 	cbz	x27, 8dc8 <fwp_hof0.constprop.0+0x838>
    8d84:	f9401be0 	ldr	x0, [sp, #48]
    8d88:	aa1303e2 	mov	x2, x19
    8d8c:	f9400666 	ldr	x6, [x19, #8]
    8d90:	910020e3 	add	x3, x7, #0x8
    8d94:	d3607c05 	lsl	x5, x0, #32
    8d98:	d2800001 	mov	x1, #0x0                   	// #0
    8d9c:	aa0503e4 	mov	x4, x5
    8da0:	14000005 	b	8db4 <fwp_hof0.constprop.0+0x824>
    8da4:	f9400446 	ldr	x6, [x2, #8]
    8da8:	ab0100a4 	adds	x4, x5, x1
    8dac:	91004063 	add	x3, x3, #0x10
    8db0:	54009ae6 	b.vs	a10c <fwp_hof0.constprop.0+0x1b7c>
    8db4:	a9001066 	stp	x6, x4, [x3]
    8db8:	91000421 	add	x1, x1, #0x1
    8dbc:	f9400842 	ldr	x2, [x2, #16]
    8dc0:	eb1b003f 	cmp	x1, x27
    8dc4:	54ffff03 	b.cc	8da4 <fwp_hof0.constprop.0+0x814>  // b.lo, b.ul, b.last
    8dc8:	f94000e0 	ldr	x0, [x7]
    8dcc:	f100041f 	cmp	x0, #0x1
    8dd0:	54000f49 	b.ls	8fb8 <fwp_hof0.constprop.0+0xa28>  // b.plast
    8dd4:	d341fc1b 	lsr	x27, x0, #1
    8dd8:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8ddc:	d1000760 	sub	x0, x27, #0x1
    8de0:	eb01001f 	cmp	x0, x1
    8de4:	54ffe448 	b.hi	8a6c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    8de8:	b4000e80 	cbz	x0, 8fb8 <fwp_hof0.constprop.0+0xa28>
    8dec:	910020fa 	add	x26, x7, #0x8
    8df0:	d10020e1 	sub	x1, x7, #0x8
    8df4:	8b1b103b 	add	x27, x1, x27, lsl #4
    8df8:	a903a3f3 	stp	x19, x8, [sp, #56]
    8dfc:	aa1a03f3 	mov	x19, x26
    8e00:	aa0003fa 	mov	x26, x0
    8e04:	f90027e7 	str	x7, [sp, #72]
    8e08:	f9400660 	ldr	x0, [x19, #8]
    8e0c:	f9400e61 	ldr	x1, [x19, #24]
    8e10:	fd400260 	ldr	d0, [x19]
    8e14:	fd400a61 	ldr	d1, [x19, #16]
    8e18:	97fff1c3 	bl	5524 <w120>
    8e1c:	a9000660 	stp	x0, x1, [x19]
    8e20:	91004273 	add	x19, x19, #0x10
    8e24:	eb1b027f 	cmp	x19, x27
    8e28:	54ffff01 	b.ne	8e08 <fwp_hof0.constprop.0+0x878>  // b.any
    8e2c:	f94027e7 	ldr	x7, [sp, #72]
    8e30:	d37ffb41 	lsl	x1, x26, #1
    8e34:	d280001b 	mov	x27, #0x0                   	// #0
    8e38:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    8e3c:	aa0703fa 	mov	x26, x7
    8e40:	aa1b03f3 	mov	x19, x27
    8e44:	aa0303e0 	mov	x0, x3
    8e48:	f8010741 	str	x1, [x26], #16
    8e4c:	aa1a03fb 	mov	x27, x26
    8e50:	aa0103fa 	mov	x26, x1
    8e54:	d503201f 	nop
    8e58:	f8737b61 	ldr	x1, [x27, x19, lsl #3]
    8e5c:	91000a73 	add	x19, x19, #0x2
    8e60:	97fff160 	bl	53e0 <f141.constprop.0>
    8e64:	eb1a027f 	cmp	x19, x26
    8e68:	54ffff83 	b.cc	8e58 <fwp_hof0.constprop.0+0x8c8>  // b.lo, b.ul, b.last
    8e6c:	a943a3f3 	ldp	x19, x8, [sp, #56]
    8e70:	aa0003e3 	mov	x3, x0
    8e74:	f94027e7 	ldr	x7, [sp, #72]
    8e78:	911742fb 	add	x27, x23, #0x5d0
    8e7c:	aa0303fa 	mov	x26, x3
    8e80:	f949db61 	ldr	x1, [x27, #5040]
    8e84:	f949ef60 	ldr	x0, [x27, #5080]
    8e88:	cb0100e1 	sub	x1, x7, x1
    8e8c:	eb00403f 	cmp	x1, x0, lsl #16
    8e90:	540003c2 	b.cs	8f08 <fwp_hof0.constprop.0+0x978>  // b.hs, b.nlast
    8e94:	d350fc20 	lsr	x0, x1, #16
    8e98:	f949ff65 	ldr	x5, [x27, #5112]
    8e9c:	8b000800 	add	x0, x0, x0, lsl #2
    8ea0:	d37df002 	lsl	x2, x0, #3
    8ea4:	8b0200a4 	add	x4, x5, x2
    8ea8:	f9401080 	ldr	x0, [x4, #32]
    8eac:	b4000e40 	cbz	x0, 9074 <fwp_hof0.constprop.0+0xae4>
    8eb0:	386268a2 	ldrb	w2, [x5, x2]
    8eb4:	7100085f 	cmp	w2, #0x2
    8eb8:	54000da0 	b.eq	906c <fwp_hof0.constprop.0+0xadc>  // b.none
    8ebc:	7100045f 	cmp	w2, #0x1
    8ec0:	54000da1 	b.ne	9074 <fwp_hof0.constprop.0+0xae4>  // b.any
    8ec4:	29430886 	ldp	w6, w2, [x4, #24]
    8ec8:	92403c21 	and	x1, x1, #0xffff
    8ecc:	9b067c21 	mul	x1, x1, x6
    8ed0:	d360fc21 	lsr	x1, x1, #32
    8ed4:	eb02003f 	cmp	x1, x2
    8ed8:	54000ce2 	b.cs	9074 <fwp_hof0.constprop.0+0xae4>  // b.hs, b.nlast
    8edc:	8b010000 	add	x0, x0, x1
    8ee0:	39400001 	ldrb	w1, [x0]
    8ee4:	34000c81 	cbz	w1, 9074 <fwp_hof0.constprop.0+0xae4>
    8ee8:	7100043f 	cmp	w1, #0x1
    8eec:	54000720 	b.eq	8fd0 <fwp_hof0.constprop.0+0xa40>  // b.none
    8ef0:	aa1a03e3 	mov	x3, x26
    8ef4:	7103fc3f 	cmp	w1, #0xff
    8ef8:	54004440 	b.eq	9780 <fwp_hof0.constprop.0+0x11f0>  // b.none
    8efc:	51000421 	sub	w1, w1, #0x1
    8f00:	39000001 	strb	w1, [x0]
    8f04:	d503201f 	nop
    8f08:	52800040 	mov	w0, #0x2                   	// #2
    8f0c:	f9001fe3 	str	x3, [sp, #56]
    8f10:	97ffe9d8 	bl	3670 <descent_phase_step>
    8f14:	b98033fa 	ldrsw	x26, [sp, #48]
    8f18:	aa1a03e0 	mov	x0, x26
    8f1c:	97ffeea1 	bl	49a0 <fwp_tape_of>
    8f20:	f940301b 	ldr	x27, [x0, #96]
    8f24:	aa0003e5 	mov	x5, x0
    8f28:	f9401fe3 	ldr	x3, [sp, #56]
    8f2c:	b4000f1b 	cbz	x27, 910c <fwp_hof0.constprop.0+0xb7c>
    8f30:	b0000020 	adrp	x0, d000 <__divti3+0x320>
    8f34:	91204000 	add	x0, x0, #0x810
    8f38:	97ffec96 	bl	4190 <fwp_trap>
    8f3c:	b0000020 	adrp	x0, d000 <__divti3+0x320>
    8f40:	91270000 	add	x0, x0, #0x9c0
    8f44:	97ffec93 	bl	4190 <fwp_trap>
    8f48:	d37ff85a 	lsl	x26, x2, #1
    8f4c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    8f50:	eb00035f 	cmp	x26, x0
    8f54:	9a80d35a 	csel	x26, x26, x0, le
    8f58:	8b1a0741 	add	x1, x26, x26, lsl #1
    8f5c:	8b010b41 	add	x1, x26, x1, lsl #2
    8f60:	d37df021 	lsl	x1, x1, #3
    8f64:	17fffe5b 	b	88d0 <fwp_hof0.constprop.0+0x340>
    8f68:	d37ffb62 	lsl	x2, x27, #1
    8f6c:	d3707cc6 	ubfiz	x6, x6, #16, #32
    8f70:	91000440 	add	x0, x2, #0x1
    8f74:	aa0700c1 	orr	x1, x6, x7
    8f78:	aa0203fa 	mov	x26, x2
    8f7c:	f9001be1 	str	x1, [sp, #48]
    8f80:	d37df000 	lsl	x0, x0, #3
    8f84:	52800041 	mov	w1, #0x2                   	// #2
    8f88:	97ffeffa 	bl	4f70 <fwp_heap_alloc>
    8f8c:	aa0003e7 	mov	x7, x0
    8f90:	911742e1 	add	x1, x23, #0x5d0
    8f94:	aa0003e8 	mov	x8, x0
    8f98:	aa0103e0 	mov	x0, x1
    8f9c:	f90000fa 	str	x26, [x7]
    8fa0:	f949d821 	ldr	x1, [x1, #5040]
    8fa4:	f949ec00 	ldr	x0, [x0, #5080]
    8fa8:	cb0100e1 	sub	x1, x7, x1
    8fac:	eb00403f 	cmp	x1, x0, lsl #16
    8fb0:	54ffeb63 	b.cc	8d1c <fwp_hof0.constprop.0+0x78c>  // b.lo, b.ul, b.last
    8fb4:	b5ffee9b 	cbnz	x27, 8d84 <fwp_hof0.constprop.0+0x7f4>
    8fb8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    8fbc:	f90000ff 	str	xzr, [x7]
    8fc0:	17ffffae 	b	8e78 <fwp_hof0.constprop.0+0x8e8>
    8fc4:	72003c3f 	tst	w1, #0xffff
    8fc8:	54ffedc1 	b.ne	8d80 <fwp_hof0.constprop.0+0x7f0>  // b.any
    8fcc:	17ffff68 	b	8d6c <fwp_hof0.constprop.0+0x7dc>
    8fd0:	f9400106 	ldr	x6, [x8]
    8fd4:	aa0803e0 	mov	x0, x8
    8fd8:	f949ef62 	ldr	x2, [x27, #5080]
    8fdc:	f949db61 	ldr	x1, [x27, #5040]
    8fe0:	d370bc44 	lsl	x4, x2, #16
    8fe4:	cb010102 	sub	x2, x8, x1
    8fe8:	b7f81086 	tbnz	x6, #63, 91f8 <fwp_hof0.constprop.0+0xc68>
    8fec:	aa1a03e3 	mov	x3, x26
    8ff0:	eb02009f 	cmp	x4, x2
    8ff4:	54fff8a9 	b.ls	8f08 <fwp_hof0.constprop.0+0x978>  // b.plast
    8ff8:	d350fc40 	lsr	x0, x2, #16
    8ffc:	8b000800 	add	x0, x0, x0, lsl #2
    9000:	d37df000 	lsl	x0, x0, #3
    9004:	8b0000a4 	add	x4, x5, x0
    9008:	f9401081 	ldr	x1, [x4, #32]
    900c:	b4fff7e1 	cbz	x1, 8f08 <fwp_hof0.constprop.0+0x978>
    9010:	386068a0 	ldrb	w0, [x5, x0]
    9014:	7100081f 	cmp	w0, #0x2
    9018:	54003600 	b.eq	96d8 <fwp_hof0.constprop.0+0x1148>  // b.none
    901c:	7100041f 	cmp	w0, #0x1
    9020:	54fff741 	b.ne	8f08 <fwp_hof0.constprop.0+0x978>  // b.any
    9024:	92403c40 	and	x0, x2, #0xffff
    9028:	29430885 	ldp	w5, w2, [x4, #24]
    902c:	9b057c00 	mul	x0, x0, x5
    9030:	d360fc00 	lsr	x0, x0, #32
    9034:	eb02001f 	cmp	x0, x2
    9038:	54fff682 	b.cs	8f08 <fwp_hof0.constprop.0+0x978>  // b.hs, b.nlast
    903c:	8b000021 	add	x1, x1, x0
    9040:	39400020 	ldrb	w0, [x1]
    9044:	7100041f 	cmp	w0, #0x1
    9048:	54fff601 	b.ne	8f08 <fwp_hof0.constprop.0+0x978>  // b.any
    904c:	aa0803e0 	mov	x0, x8
    9050:	f9001fe3 	str	x3, [sp, #56]
    9054:	97ffed0b 	bl	4480 <fwp_mem_free>
    9058:	f9401fe3 	ldr	x3, [sp, #56]
    905c:	17ffffab 	b	8f08 <fwp_hof0.constprop.0+0x978>
    9060:	90000020 	adrp	x0, d000 <__divti3+0x320>
    9064:	91290000 	add	x0, x0, #0xa40
    9068:	97ffec4a 	bl	4190 <fwp_trap>
    906c:	72003c3f 	tst	w1, #0xffff
    9070:	54fff380 	b.eq	8ee0 <fwp_hof0.constprop.0+0x950>  // b.none
    9074:	aa1a03e3 	mov	x3, x26
    9078:	17ffffa4 	b	8f08 <fwp_hof0.constprop.0+0x978>
    907c:	97ffed7a 	bl	4664 <fwp_rc_wide_dup>
    9080:	911742e0 	add	x0, x23, #0x5d0
    9084:	f949ec05 	ldr	x5, [x0, #5080]
    9088:	f949d801 	ldr	x1, [x0, #5040]
    908c:	d370bca5 	lsl	x5, x5, #16
    9090:	17fffd82 	b	8698 <fwp_hof0.constprop.0+0x108>
    9094:	ca5a4740 	eor	x0, x26, x26, lsr #17
    9098:	911742e1 	add	x1, x23, #0x5d0
    909c:	ca402400 	eor	x0, x0, x0, lsr #9
    90a0:	92401c00 	and	x0, x0, #0xff
    90a4:	910a2402 	add	x2, x0, #0x289
    90a8:	8b000c20 	add	x0, x1, x0, lsl #3
    90ac:	8b020c22 	add	x2, x1, x2, lsl #3
    90b0:	f94a2400 	ldr	x0, [x0, #5192]
    90b4:	b50000a0 	cbnz	x0, 90c8 <fwp_hof0.constprop.0+0xb38>
    90b8:	1400018b 	b	96e4 <fwp_hof0.constprop.0+0x1154>
    90bc:	91004002 	add	x2, x0, #0x10
    90c0:	f9400800 	ldr	x0, [x0, #16]
    90c4:	b4003100 	cbz	x0, 96e4 <fwp_hof0.constprop.0+0x1154>
    90c8:	f9400001 	ldr	x1, [x0]
    90cc:	eb1a003f 	cmp	x1, x26
    90d0:	54ffff61 	b.ne	90bc <fwp_hof0.constprop.0+0xb2c>  // b.any
    90d4:	f9400041 	ldr	x1, [x2]
    90d8:	f9400420 	ldr	x0, [x1, #8]
    90dc:	d1000400 	sub	x0, x0, #0x1
    90e0:	f9000420 	str	x0, [x1, #8]
    90e4:	f103f81f 	cmp	x0, #0xfe
    90e8:	54ffb701 	b.ne	87c8 <fwp_hof0.constprop.0+0x238>  // b.any
    90ec:	39400340 	ldrb	w0, [x26]
    90f0:	7103fc1f 	cmp	w0, #0xff
    90f4:	54003180 	b.eq	9724 <fwp_hof0.constprop.0+0x1194>  // b.none
    90f8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    90fc:	39000340 	strb	w0, [x26]
    9100:	17fffdb2 	b	87c8 <fwp_hof0.constprop.0+0x238>
    9104:	97ffed58 	bl	4664 <fwp_rc_wide_dup>
    9108:	17fffd8f 	b	8744 <fwp_hof0.constprop.0+0x1b4>
    910c:	f9001be3 	str	x3, [sp, #48]
    9110:	97ffe7c0 	bl	3010 <fwp_tape_unlink_scope>
    9114:	a94188a7 	ldp	x7, x2, [x5, #24]
    9118:	f90023e2 	str	x2, [sp, #64]
    911c:	f94014a2 	ldr	x2, [x5, #40]
    9120:	f90027e2 	str	x2, [sp, #72]
    9124:	f94018a2 	ldr	x2, [x5, #48]
    9128:	f9002be2 	str	x2, [sp, #80]
    912c:	f9401ca2 	ldr	x2, [x5, #56]
    9130:	b90004bf 	str	wzr, [x5, #4]
    9134:	b94000a1 	ldr	w1, [x5]
    9138:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    913c:	f9002fe2 	str	x2, [sp, #88]
    9140:	a940a0bb 	ldp	x27, x8, [x5, #8]
    9144:	6b00003f 	cmp	w1, w0
    9148:	f9401be3 	ldr	x3, [sp, #48]
    914c:	f94020a4 	ldr	x4, [x5, #64]
    9150:	f94024a2 	ldr	x2, [x5, #72]
    9154:	54000108 	b.hi	9174 <fwp_hof0.constprop.0+0xbe4>  // b.pmore
    9158:	9101c2a1 	add	x1, x21, #0x70
    915c:	92403f40 	and	x0, x26, #0xffff
    9160:	d1000400 	sub	x0, x0, #0x1
    9164:	f9407429 	ldr	x9, [x1, #232]
    9168:	eb09001f 	cmp	x0, x9
    916c:	5400004a 	b.ge	9174 <fwp_hof0.constprop.0+0xbe4>  // b.tcont
    9170:	f9007420 	str	x0, [x1, #232]
    9174:	4f000400 	movi	v0.4s, #0x0
    9178:	f9000cbf 	str	xzr, [x5, #24]
    917c:	f94023e0 	ldr	x0, [sp, #64]
    9180:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    9184:	9101c2a1 	add	x1, x21, #0x70
    9188:	3c8080a0 	stur	q0, [x5, #8]
    918c:	ad0100a0 	stp	q0, q0, [x5, #32]
    9190:	9102a3e5 	add	x5, sp, #0xa8
    9194:	f90063e0 	str	x0, [sp, #192]
    9198:	f94027e0 	ldr	x0, [sp, #72]
    919c:	f90067e0 	str	x0, [sp, #200]
    91a0:	f9402be0 	ldr	x0, [sp, #80]
    91a4:	f9006be0 	str	x0, [sp, #208]
    91a8:	f9402fe0 	ldr	x0, [sp, #88]
    91ac:	f9006fe0 	str	x0, [sp, #216]
    91b0:	f9418820 	ldr	x0, [x1, #784]
    91b4:	f90057e0 	str	x0, [sp, #168]
    91b8:	f0ffffc0 	adrp	x0, 4000 <fwp_wake_io+0x4c>
    91bc:	9101c000 	add	x0, x0, #0x70
    91c0:	f90033e5 	str	x5, [sp, #96]
    91c4:	f9005be0 	str	x0, [sp, #176]
    91c8:	910303e0 	add	x0, sp, #0xc0
    91cc:	f9001be0 	str	x0, [sp, #48]
    91d0:	f9005fe0 	str	x0, [sp, #184]
    91d4:	a90e1fe4 	stp	x4, x7, [sp, #224]
    91d8:	f9007be2 	str	x2, [sp, #240]
    91dc:	f9018825 	str	x5, [x1, #784]
    91e0:	b7f82883 	tbnz	x3, #63, 96f0 <fwp_hof0.constprop.0+0x1160>
    91e4:	eb83835f 	cmp	x26, x3, asr #32
    91e8:	54000500 	b.eq	9288 <fwp_hof0.constprop.0+0xcf8>  // b.none
    91ec:	90000020 	adrp	x0, d000 <__divti3+0x320>
    91f0:	911f2000 	add	x0, x0, #0x7c8
    91f4:	97ffebe7 	bl	4190 <fwp_trap>
    91f8:	f9400508 	ldr	x8, [x8, #8]
    91fc:	eb02009f 	cmp	x4, x2
    9200:	540003a9 	b.ls	9274 <fwp_hof0.constprop.0+0xce4>  // b.plast
    9204:	d350fc46 	lsr	x6, x2, #16
    9208:	8b0608c6 	add	x6, x6, x6, lsl #2
    920c:	d37df0c6 	lsl	x6, x6, #3
    9210:	8b0600a9 	add	x9, x5, x6
    9214:	f9401127 	ldr	x7, [x9, #32]
    9218:	b40002e7 	cbz	x7, 9274 <fwp_hof0.constprop.0+0xce4>
    921c:	386668a5 	ldrb	w5, [x5, x6]
    9220:	710008bf 	cmp	w5, #0x2
    9224:	54002740 	b.eq	970c <fwp_hof0.constprop.0+0x117c>  // b.none
    9228:	710004bf 	cmp	w5, #0x1
    922c:	54000241 	b.ne	9274 <fwp_hof0.constprop.0+0xce4>  // b.any
    9230:	29431526 	ldp	w6, w5, [x9, #24]
    9234:	92403c42 	and	x2, x2, #0xffff
    9238:	9b067c42 	mul	x2, x2, x6
    923c:	d360fc42 	lsr	x2, x2, #32
    9240:	eb05005f 	cmp	x2, x5
    9244:	54000182 	b.cs	9274 <fwp_hof0.constprop.0+0xce4>  // b.hs, b.nlast
    9248:	8b0200e7 	add	x7, x7, x2
    924c:	394000e2 	ldrb	w2, [x7]
    9250:	7100045f 	cmp	w2, #0x1
    9254:	54000101 	b.ne	9274 <fwp_hof0.constprop.0+0xce4>  // b.any
    9258:	f9001fe8 	str	x8, [sp, #56]
    925c:	97ffec89 	bl	4480 <fwp_mem_free>
    9260:	911742e0 	add	x0, x23, #0x5d0
    9264:	f9401fe8 	ldr	x8, [sp, #56]
    9268:	f949ec02 	ldr	x2, [x0, #5080]
    926c:	f949d801 	ldr	x1, [x0, #5040]
    9270:	d370bc44 	lsl	x4, x2, #16
    9274:	cb010101 	sub	x1, x8, x1
    9278:	eb01009f 	cmp	x4, x1
    927c:	54ffe0c8 	b.hi	8e94 <fwp_hof0.constprop.0+0x904>  // b.pmore
    9280:	aa1a03e3 	mov	x3, x26
    9284:	17ffff21 	b	8f08 <fwp_hof0.constprop.0+0x978>
    9288:	92407c60 	and	x0, x3, #0xffffffff
    928c:	eb23411f 	cmp	x8, w3, uxtw
    9290:	5400244d 	b.le	9718 <fwp_hof0.constprop.0+0x1188>
    9294:	eb00037f 	cmp	x27, x0
    9298:	9a80c77a 	csinc	x26, x27, x0, gt
    929c:	eb1a005f 	cmp	x2, x26
    92a0:	5400248a 	b.ge	9730 <fwp_hof0.constprop.0+0x11a0>  // b.tcont
    92a4:	f100005f 	cmp	x2, #0x0
    92a8:	b24077e5 	mov	x5, #0x3fffffff            	// #1073741823
    92ac:	9a9a1042 	csel	x2, x2, x26, ne	// ne = any
    92b0:	14000004 	b	92c0 <fwp_hof0.constprop.0+0xd30>
    92b4:	eb05005f 	cmp	x2, x5
    92b8:	d37ff842 	lsl	x2, x2, #1
    92bc:	9a9ad042 	csel	x2, x2, x26, le
    92c0:	eb1a005f 	cmp	x2, x26
    92c4:	54ffff8b 	b.lt	92b4 <fwp_hof0.constprop.0+0xd24>  // b.tstop
    92c8:	f90037e3 	str	x3, [sp, #104]
    92cc:	b4003ec4 	cbz	x4, 9aa4 <fwp_hof0.constprop.0+0x1514>
    92d0:	aa0403e0 	mov	x0, x4
    92d4:	d37df041 	lsl	x1, x2, #3
    92d8:	f9001fe2 	str	x2, [sp, #56]
    92dc:	97ffe589 	bl	2900 <realloc@plt>
    92e0:	f9401fe2 	ldr	x2, [sp, #56]
    92e4:	aa0003e4 	mov	x4, x0
    92e8:	f94037e3 	ldr	x3, [sp, #104]
    92ec:	b4002224 	cbz	x4, 9730 <fwp_hof0.constprop.0+0x11a0>
    92f0:	f90073e4 	str	x4, [sp, #224]
    92f4:	f9007be2 	str	x2, [sp, #240]
    92f8:	b5001e1a 	cbnz	x26, 96b8 <fwp_hof0.constprop.0+0x1128>
    92fc:	b7f800c3 	tbnz	x3, #63, 9314 <fwp_hof0.constprop.0+0xd84>
    9300:	92407c63 	and	x3, x3, #0xffffffff
    9304:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    9308:	fc637880 	ldr	d0, [x4, x3, lsl #3]
    930c:	1e612800 	fadd	d0, d0, d1
    9310:	fc237880 	str	d0, [x4, x3, lsl #3]
    9314:	9101c2a1 	add	x1, x21, #0x70
    9318:	cb1b0342 	sub	x2, x26, x27
    931c:	52800060 	mov	w0, #0x3                   	// #3
    9320:	f9001fe4 	str	x4, [sp, #56]
    9324:	a9428c25 	ldp	x5, x3, [x1, #40]
    9328:	8b050042 	add	x2, x2, x5
    932c:	8b1b0063 	add	x3, x3, x27
    9330:	a9028c22 	stp	x2, x3, [x1, #40]
    9334:	97ffe8cf 	bl	3670 <descent_phase_step>
    9338:	d1000740 	sub	x0, x26, #0x1
    933c:	d1000762 	sub	x2, x27, #0x1
    9340:	f9401fe4 	ldr	x4, [sp, #56]
    9344:	eb00037f 	cmp	x27, x0
    9348:	5400042c 	b.gt	93cc <fwp_hof0.constprop.0+0xe3c>
    934c:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    9350:	1e602008 	fcmp	d0, #0.0
    9354:	54000360 	b.eq	93c0 <fwp_hof0.constprop.0+0xe30>  // b.none
    9358:	f94023e3 	ldr	x3, [sp, #64]
    935c:	cb1b0be1 	neg	x1, x27, lsl #2
    9360:	cb1b03e5 	neg	x5, x27
    9364:	8b010063 	add	x3, x3, x1
    9368:	b8607863 	ldr	w3, [x3, x0, lsl #2]
    936c:	37f80123 	tbnz	w3, #31, 9390 <fwp_hof0.constprop.0+0xe00>
    9370:	f9402be6 	ldr	x6, [sp, #80]
    9374:	93407c63 	sxtw	x3, w3
    9378:	8b050cc6 	add	x6, x6, x5, lsl #3
    937c:	fc637881 	ldr	d1, [x4, x3, lsl #3]
    9380:	fc6078c2 	ldr	d2, [x6, x0, lsl #3]
    9384:	1e620802 	fmul	d2, d0, d2
    9388:	1e622821 	fadd	d1, d1, d2
    938c:	fc237881 	str	d1, [x4, x3, lsl #3]
    9390:	f94027e3 	ldr	x3, [sp, #72]
    9394:	8b010061 	add	x1, x3, x1
    9398:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    939c:	37f80121 	tbnz	w1, #31, 93c0 <fwp_hof0.constprop.0+0xe30>
    93a0:	f9402fe3 	ldr	x3, [sp, #88]
    93a4:	93407c21 	sxtw	x1, w1
    93a8:	8b050c65 	add	x5, x3, x5, lsl #3
    93ac:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    93b0:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    93b4:	1e620800 	fmul	d0, d0, d2
    93b8:	1e602820 	fadd	d0, d1, d0
    93bc:	fc217880 	str	d0, [x4, x1, lsl #3]
    93c0:	d1000400 	sub	x0, x0, #0x1
    93c4:	eb02001f 	cmp	x0, x2
    93c8:	54fffc21 	b.ne	934c <fwp_hof0.constprop.0+0xdbc>  // b.any
    93cc:	52800080 	mov	w0, #0x4                   	// #4
    93d0:	f9001fe4 	str	x4, [sp, #56]
    93d4:	97ffe8a7 	bl	3670 <descent_phase_step>
    93d8:	f9401fe4 	ldr	x4, [sp, #56]
    93dc:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    93e0:	eb00037f 	cmp	x27, x0
    93e4:	540025c8 	b.hi	989c <fwp_hof0.constprop.0+0x130c>  // b.pmore
    93e8:	91000760 	add	x0, x27, #0x1
    93ec:	52800041 	mov	w1, #0x2                   	// #2
    93f0:	f9001fe4 	str	x4, [sp, #56]
    93f4:	d37df000 	lsl	x0, x0, #3
    93f8:	97ffeede 	bl	4f70 <fwp_heap_alloc>
    93fc:	aa0003fa 	mov	x26, x0
    9400:	f800841b 	str	x27, [x0], #8
    9404:	f9401fe4 	ldr	x4, [sp, #56]
    9408:	d2800001 	mov	x1, #0x0                   	// #0
    940c:	b40000db 	cbz	x27, 9424 <fwp_hof0.constprop.0+0xe94>
    9410:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    9414:	f8217802 	str	x2, [x0, x1, lsl #3]
    9418:	91000421 	add	x1, x1, #0x1
    941c:	eb01037f 	cmp	x27, x1
    9420:	54ffff81 	b.ne	9410 <fwp_hof0.constprop.0+0xe80>  // b.any
    9424:	528000a0 	mov	w0, #0x5                   	// #5
    9428:	97ffe892 	bl	3670 <descent_phase_step>
    942c:	9101c2a1 	add	x1, x21, #0x70
    9430:	f94033e2 	ldr	x2, [sp, #96]
    9434:	f9418820 	ldr	x0, [x1, #784]
    9438:	eb02001f 	cmp	x0, x2
    943c:	54006661 	b.ne	a108 <fwp_hof0.constprop.0+0x1b78>  // b.any
    9440:	f9401be0 	ldr	x0, [sp, #48]
    9444:	f94057e3 	ldr	x3, [sp, #168]
    9448:	f9001fe3 	str	x3, [sp, #56]
    944c:	f9018823 	str	x3, [x1, #784]
    9450:	97ffeb08 	bl	4070 <fwp_tape_buffers_release>
    9454:	528000c0 	mov	w0, #0x6                   	// #6
    9458:	97ffe886 	bl	3670 <descent_phase_step>
    945c:	911742e2 	add	x2, x23, #0x5d0
    9460:	f9401fe3 	ldr	x3, [sp, #56]
    9464:	f949d841 	ldr	x1, [x2, #5040]
    9468:	f949ec40 	ldr	x0, [x2, #5080]
    946c:	cb010341 	sub	x1, x26, x1
    9470:	eb00403f 	cmp	x1, x0, lsl #16
    9474:	54000322 	b.cs	94d8 <fwp_hof0.constprop.0+0xf48>  // b.hs, b.nlast
    9478:	d350fc20 	lsr	x0, x1, #16
    947c:	f949fc44 	ldr	x4, [x2, #5112]
    9480:	8b000800 	add	x0, x0, x0, lsl #2
    9484:	d37df002 	lsl	x2, x0, #3
    9488:	8b020080 	add	x0, x4, x2
    948c:	f940101b 	ldr	x27, [x0, #32]
    9490:	b400025b 	cbz	x27, 94d8 <fwp_hof0.constprop.0+0xf48>
    9494:	38626882 	ldrb	w2, [x4, x2]
    9498:	7100085f 	cmp	w2, #0x2
    949c:	54002fe0 	b.eq	9a98 <fwp_hof0.constprop.0+0x1508>  // b.none
    94a0:	7100045f 	cmp	w2, #0x1
    94a4:	540001a1 	b.ne	94d8 <fwp_hof0.constprop.0+0xf48>  // b.any
    94a8:	29430002 	ldp	w2, w0, [x0, #24]
    94ac:	92403c21 	and	x1, x1, #0xffff
    94b0:	9b027c21 	mul	x1, x1, x2
    94b4:	d360fc21 	lsr	x1, x1, #32
    94b8:	eb00003f 	cmp	x1, x0
    94bc:	540000e2 	b.cs	94d8 <fwp_hof0.constprop.0+0xf48>  // b.hs, b.nlast
    94c0:	8b01037b 	add	x27, x27, x1
    94c4:	39400360 	ldrb	w0, [x27]
    94c8:	7103fc1f 	cmp	w0, #0xff
    94cc:	54003020 	b.eq	9ad0 <fwp_hof0.constprop.0+0x1540>  // b.none
    94d0:	52800020 	mov	w0, #0x1                   	// #1
    94d4:	39000360 	strb	w0, [x27]
    94d8:	f94007e0 	ldr	x0, [sp, #8]
    94dc:	eb00007f 	cmp	x3, x0
    94e0:	54006141 	b.ne	a108 <fwp_hof0.constprop.0+0x1b78>  // b.any
    94e4:	f94003e0 	ldr	x0, [sp]
    94e8:	9101c2a1 	add	x1, x21, #0x70
    94ec:	f9404be2 	ldr	x2, [sp, #144]
    94f0:	f9018822 	str	x2, [x1, #784]
    94f4:	97fff3e7 	bl	6490 <fwp_tape_scope_release>
    94f8:	f9400340 	ldr	x0, [x26]
    94fc:	9240f81b 	and	x27, x0, #0x7fffffffffffffff
    9500:	b7f817c0 	tbnz	x0, #63, 97f8 <fwp_hof0.constprop.0+0x1268>
    9504:	911742e2 	add	x2, x23, #0x5d0
    9508:	f949d840 	ldr	x0, [x2, #5040]
    950c:	f949ec41 	ldr	x1, [x2, #5080]
    9510:	cb000340 	sub	x0, x26, x0
    9514:	eb01401f 	cmp	x0, x1, lsl #16
    9518:	54001702 	b.cs	97f8 <fwp_hof0.constprop.0+0x1268>  // b.hs, b.nlast
    951c:	d350fc01 	lsr	x1, x0, #16
    9520:	f949fc44 	ldr	x4, [x2, #5112]
    9524:	8b010821 	add	x1, x1, x1, lsl #2
    9528:	d37df021 	lsl	x1, x1, #3
    952c:	8b010083 	add	x3, x4, x1
    9530:	f9401062 	ldr	x2, [x3, #32]
    9534:	b4001622 	cbz	x2, 97f8 <fwp_hof0.constprop.0+0x1268>
    9538:	38616881 	ldrb	w1, [x4, x1]
    953c:	7100083f 	cmp	w1, #0x2
    9540:	54001580 	b.eq	97f0 <fwp_hof0.constprop.0+0x1260>  // b.none
    9544:	7100043f 	cmp	w1, #0x1
    9548:	54001581 	b.ne	97f8 <fwp_hof0.constprop.0+0x1268>  // b.any
    954c:	29430464 	ldp	w4, w1, [x3, #24]
    9550:	92403c00 	and	x0, x0, #0xffff
    9554:	9b047c00 	mul	x0, x0, x4
    9558:	d360fc00 	lsr	x0, x0, #32
    955c:	eb01001f 	cmp	x0, x1
    9560:	540014c2 	b.cs	97f8 <fwp_hof0.constprop.0+0x1268>  // b.hs, b.nlast
    9564:	8b000042 	add	x2, x2, x0
    9568:	39400040 	ldrb	w0, [x2]
    956c:	7100041f 	cmp	w0, #0x1
    9570:	54001441 	b.ne	97f8 <fwp_hof0.constprop.0+0x1268>  // b.any
    9574:	aa1a03e3 	mov	x3, x26
    9578:	d2800000 	mov	x0, #0x0                   	// #0
    957c:	91002062 	add	x2, x3, #0x8
    9580:	d2800001 	mov	x1, #0x0                   	// #0
    9584:	b40001fb 	cbz	x27, 95c0 <fwp_hof0.constprop.0+0x1030>
    9588:	b0000024 	adrp	x4, e000 <_IO_stdin_used+0xc00>
    958c:	91002345 	add	x5, x26, #0x8
    9590:	fd410881 	ldr	d1, [x4, #528]
    9594:	f9400346 	ldr	x6, [x26]
    9598:	aa0503e4 	mov	x4, x5
    959c:	b7f81866 	tbnz	x6, #63, 98a8 <fwp_hof0.constprop.0+0x1318>
    95a0:	f9400066 	ldr	x6, [x3]
    95a4:	fc617880 	ldr	d0, [x4, x1, lsl #3]
    95a8:	b7f828e6 	tbnz	x6, #63, 9ac4 <fwp_hof0.constprop.0+0x1534>
    95ac:	1e600820 	fmul	d0, d1, d0
    95b0:	91000421 	add	x1, x1, #0x1
    95b4:	fc008440 	str	d0, [x2], #8
    95b8:	eb01037f 	cmp	x27, x1
    95bc:	54fffec1 	b.ne	9594 <fwp_hof0.constprop.0+0x1004>  // b.any
    95c0:	f9001fe3 	str	x3, [sp, #56]
    95c4:	97fff5bf 	bl	6cc0 <fwp_drop10>
    95c8:	f9401fe3 	ldr	x3, [sp, #56]
    95cc:	b4002953 	cbz	x19, 9af4 <fwp_hof0.constprop.0+0x1564>
    95d0:	aa1303e0 	mov	x0, x19
    95d4:	d280001a 	mov	x26, #0x0                   	// #0
    95d8:	f9400800 	ldr	x0, [x0, #16]
    95dc:	9100075a 	add	x26, x26, #0x1
    95e0:	b5ffffc0 	cbnz	x0, 95d8 <fwp_hof0.constprop.0+0x1048>
    95e4:	f9400060 	ldr	x0, [x3]
    95e8:	9240f81b 	and	x27, x0, #0x7fffffffffffffff
    95ec:	b7f81620 	tbnz	x0, #63, 98b0 <fwp_hof0.constprop.0+0x1320>
    95f0:	911742e1 	add	x1, x23, #0x5d0
    95f4:	f949d820 	ldr	x0, [x1, #5040]
    95f8:	f949ec22 	ldr	x2, [x1, #5080]
    95fc:	cb000060 	sub	x0, x3, x0
    9600:	eb02401f 	cmp	x0, x2, lsl #16
    9604:	54002862 	b.cs	9b10 <fwp_hof0.constprop.0+0x1580>  // b.hs, b.nlast
    9608:	d350fc02 	lsr	x2, x0, #16
    960c:	d2800504 	mov	x4, #0x28                  	// #40
    9610:	f949fc25 	ldr	x5, [x1, #5112]
    9614:	9b047c42 	mul	x2, x2, x4
    9618:	8b0200a4 	add	x4, x5, x2
    961c:	f9401081 	ldr	x1, [x4, #32]
    9620:	b4002781 	cbz	x1, 9b10 <fwp_hof0.constprop.0+0x1580>
    9624:	386268a2 	ldrb	w2, [x5, x2]
    9628:	7100085f 	cmp	w2, #0x2
    962c:	540026e0 	b.eq	9b08 <fwp_hof0.constprop.0+0x1578>  // b.none
    9630:	7100045f 	cmp	w2, #0x1
    9634:	540026e1 	b.ne	9b10 <fwp_hof0.constprop.0+0x1580>  // b.any
    9638:	29430885 	ldp	w5, w2, [x4, #24]
    963c:	92403c00 	and	x0, x0, #0xffff
    9640:	9b057c00 	mul	x0, x0, x5
    9644:	d360fc00 	lsr	x0, x0, #32
    9648:	eb02001f 	cmp	x0, x2
    964c:	54002622 	b.cs	9b10 <fwp_hof0.constprop.0+0x1580>  // b.hs, b.nlast
    9650:	8b000021 	add	x1, x1, x0
    9654:	39400028 	ldrb	w8, [x1]
    9658:	7100051f 	cmp	w8, #0x1
    965c:	540025a1 	b.ne	9b10 <fwp_hof0.constprop.0+0x1580>  // b.any
    9660:	91002065 	add	x5, x3, #0x8
    9664:	eb1a037f 	cmp	x27, x26
    9668:	9a9a9362 	csel	x2, x27, x26, ls	// ls = plast
    966c:	b4002622 	cbz	x2, 9b30 <fwp_hof0.constprop.0+0x15a0>
    9670:	d37df047 	lsl	x7, x2, #3
    9674:	aa1303e1 	mov	x1, x19
    9678:	91002066 	add	x6, x3, #0x8
    967c:	d2800000 	mov	x0, #0x0                   	// #0
    9680:	14000009 	b	96a4 <fwp_hof0.constprop.0+0x1114>
    9684:	fc606881 	ldr	d1, [x4, x0]
    9688:	fd400420 	ldr	d0, [x1, #8]
    968c:	1e613800 	fsub	d0, d0, d1
    9690:	fc2068a0 	str	d0, [x5, x0]
    9694:	91002000 	add	x0, x0, #0x8
    9698:	f9400821 	ldr	x1, [x1, #16]
    969c:	eb0000ff 	cmp	x7, x0
    96a0:	54001360 	b.eq	990c <fwp_hof0.constprop.0+0x137c>  // b.none
    96a4:	f9400069 	ldr	x9, [x3]
    96a8:	aa0603e4 	mov	x4, x6
    96ac:	b6fffec9 	tbz	x9, #63, 9684 <fwp_hof0.constprop.0+0x10f4>
    96b0:	f9400864 	ldr	x4, [x3, #16]
    96b4:	17fffff4 	b	9684 <fwp_hof0.constprop.0+0x10f4>
    96b8:	aa0403e0 	mov	x0, x4
    96bc:	d37df342 	lsl	x2, x26, #3
    96c0:	52800001 	mov	w1, #0x0                   	// #0
    96c4:	f9001fe3 	str	x3, [sp, #56]
    96c8:	97ffe486 	bl	28e0 <memset@plt>
    96cc:	aa0003e4 	mov	x4, x0
    96d0:	f9401fe3 	ldr	x3, [sp, #56]
    96d4:	17ffff0a 	b	92fc <fwp_hof0.constprop.0+0xd6c>
    96d8:	72003c5f 	tst	w2, #0xffff
    96dc:	54ffc161 	b.ne	8f08 <fwp_hof0.constprop.0+0x978>  // b.any
    96e0:	17fffe58 	b	9040 <fwp_hof0.constprop.0+0xab0>
    96e4:	90000020 	adrp	x0, d000 <__divti3+0x320>
    96e8:	9117e000 	add	x0, x0, #0x5f8
    96ec:	97ffeaa9 	bl	4190 <fwp_trap>
    96f0:	aa1b03fa 	mov	x26, x27
    96f4:	17fffeea 	b	929c <fwp_hof0.constprop.0+0xd0c>
    96f8:	aa1a03e0 	mov	x0, x26
    96fc:	a9039fe8 	stp	x8, x7, [sp, #56]
    9700:	97ffeac4 	bl	4210 <fwp_rc_forget_slot.part.0>
    9704:	a9439fe8 	ldp	x8, x7, [sp, #56]
    9708:	17fffd9c 	b	8d78 <fwp_hof0.constprop.0+0x7e8>
    970c:	72003c5f 	tst	w2, #0xffff
    9710:	54ffdb21 	b.ne	9274 <fwp_hof0.constprop.0+0xce4>  // b.any
    9714:	17fffece 	b	924c <fwp_hof0.constprop.0+0xcbc>
    9718:	90000020 	adrp	x0, d000 <__divti3+0x320>
    971c:	91210000 	add	x0, x0, #0x840
    9720:	97ffea9c 	bl	4190 <fwp_trap>
    9724:	aa1a03e0 	mov	x0, x26
    9728:	97ffeaba 	bl	4210 <fwp_rc_forget_slot.part.0>
    972c:	17fffe73 	b	90f8 <fwp_hof0.constprop.0+0xb68>
    9730:	f100035f 	cmp	x26, #0x0
    9734:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    9738:	54ffde01 	b.ne	92f8 <fwp_hof0.constprop.0+0xd68>  // b.any
    973c:	f9401be0 	ldr	x0, [sp, #48]
    9740:	9101c2b5 	add	x21, x21, #0x70
    9744:	f94057e1 	ldr	x1, [sp, #168]
    9748:	f9018aa1 	str	x1, [x21, #784]
    974c:	97ffea49 	bl	4070 <fwp_tape_buffers_release>
    9750:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    9754:	f947e863 	ldr	x3, [x3, #4048]
    9758:	d2800262 	mov	x2, #0x13                  	// #19
    975c:	d2800021 	mov	x1, #0x1                   	// #1
    9760:	90000020 	adrp	x0, d000 <__divti3+0x320>
    9764:	91102000 	add	x0, x0, #0x408
    9768:	f9400063 	ldr	x3, [x3]
    976c:	97ffe4a9 	bl	2a10 <fwrite@plt>
    9770:	d2800000 	mov	x0, #0x0                   	// #0
    9774:	97ffe4b3 	bl	2a40 <fflush@plt>
    9778:	52800cc0 	mov	w0, #0x66                  	// #102
    977c:	97ffe4c1 	bl	2a80 <_Exit@plt>
    9780:	ca404401 	eor	x1, x0, x0, lsr #17
    9784:	911742e4 	add	x4, x23, #0x5d0
    9788:	ca412421 	eor	x1, x1, x1, lsr #9
    978c:	92401c21 	and	x1, x1, #0xff
    9790:	910a2422 	add	x2, x1, #0x289
    9794:	8b010c81 	add	x1, x4, x1, lsl #3
    9798:	8b020c82 	add	x2, x4, x2, lsl #3
    979c:	f94a2421 	ldr	x1, [x1, #5192]
    97a0:	b50000a1 	cbnz	x1, 97b4 <fwp_hof0.constprop.0+0x1224>
    97a4:	17ffffd0 	b	96e4 <fwp_hof0.constprop.0+0x1154>
    97a8:	91004022 	add	x2, x1, #0x10
    97ac:	f9400821 	ldr	x1, [x1, #16]
    97b0:	b4fff9a1 	cbz	x1, 96e4 <fwp_hof0.constprop.0+0x1154>
    97b4:	f9400024 	ldr	x4, [x1]
    97b8:	eb00009f 	cmp	x4, x0
    97bc:	54ffff61 	b.ne	97a8 <fwp_hof0.constprop.0+0x1218>  // b.any
    97c0:	f9400042 	ldr	x2, [x2]
    97c4:	f9400441 	ldr	x1, [x2, #8]
    97c8:	d1000421 	sub	x1, x1, #0x1
    97cc:	f9000441 	str	x1, [x2, #8]
    97d0:	f103f83f 	cmp	x1, #0xfe
    97d4:	54ffb9a1 	b.ne	8f08 <fwp_hof0.constprop.0+0x978>  // b.any
    97d8:	39400001 	ldrb	w1, [x0]
    97dc:	7103fc3f 	cmp	w1, #0xff
    97e0:	54001820 	b.eq	9ae4 <fwp_hof0.constprop.0+0x1554>  // b.none
    97e4:	12800021 	mov	w1, #0xfffffffe            	// #-2
    97e8:	39000001 	strb	w1, [x0]
    97ec:	17fffdc7 	b	8f08 <fwp_hof0.constprop.0+0x978>
    97f0:	72003c1f 	tst	w0, #0xffff
    97f4:	54ffeba0 	b.eq	9568 <fwp_hof0.constprop.0+0xfd8>  // b.none
    97f8:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    97fc:	eb00037f 	cmp	x27, x0
    9800:	540004e8 	b.hi	989c <fwp_hof0.constprop.0+0x130c>  // b.pmore
    9804:	91000760 	add	x0, x27, #0x1
    9808:	52800021 	mov	w1, #0x1                   	// #1
    980c:	d37df000 	lsl	x0, x0, #3
    9810:	97ffedd8 	bl	4f70 <fwp_heap_alloc>
    9814:	911742e4 	add	x4, x23, #0x5d0
    9818:	f900001b 	str	x27, [x0]
    981c:	aa0003e3 	mov	x3, x0
    9820:	f949d881 	ldr	x1, [x4, #5040]
    9824:	f949ec80 	ldr	x0, [x4, #5080]
    9828:	cb010061 	sub	x1, x3, x1
    982c:	eb00403f 	cmp	x1, x0, lsl #16
    9830:	54000322 	b.cs	9894 <fwp_hof0.constprop.0+0x1304>  // b.hs, b.nlast
    9834:	d350fc22 	lsr	x2, x1, #16
    9838:	d2800500 	mov	x0, #0x28                  	// #40
    983c:	f949fc85 	ldr	x5, [x4, #5112]
    9840:	9b007c42 	mul	x2, x2, x0
    9844:	8b0200a4 	add	x4, x5, x2
    9848:	f9401080 	ldr	x0, [x4, #32]
    984c:	b4000240 	cbz	x0, 9894 <fwp_hof0.constprop.0+0x1304>
    9850:	386268a2 	ldrb	w2, [x5, x2]
    9854:	7100085f 	cmp	w2, #0x2
    9858:	54003820 	b.eq	9f5c <fwp_hof0.constprop.0+0x19cc>  // b.none
    985c:	7100045f 	cmp	w2, #0x1
    9860:	540001a1 	b.ne	9894 <fwp_hof0.constprop.0+0x1304>  // b.any
    9864:	29430885 	ldp	w5, w2, [x4, #24]
    9868:	92403c21 	and	x1, x1, #0xffff
    986c:	9b057c21 	mul	x1, x1, x5
    9870:	d360fc21 	lsr	x1, x1, #32
    9874:	eb02003f 	cmp	x1, x2
    9878:	540000e2 	b.cs	9894 <fwp_hof0.constprop.0+0x1304>  // b.hs, b.nlast
    987c:	8b010000 	add	x0, x0, x1
    9880:	39400001 	ldrb	w1, [x0]
    9884:	7103fc3f 	cmp	w1, #0xff
    9888:	54003620 	b.eq	9f4c <fwp_hof0.constprop.0+0x19bc>  // b.none
    988c:	52800021 	mov	w1, #0x1                   	// #1
    9890:	39000001 	strb	w1, [x0]
    9894:	aa1a03e0 	mov	x0, x26
    9898:	17ffff39 	b	957c <fwp_hof0.constprop.0+0xfec>
    989c:	90000020 	adrp	x0, d000 <__divti3+0x320>
    98a0:	9127c000 	add	x0, x0, #0x9f0
    98a4:	97ffea3b 	bl	4190 <fwp_trap>
    98a8:	f9400b44 	ldr	x4, [x26, #16]
    98ac:	17ffff3d 	b	95a0 <fwp_hof0.constprop.0+0x1010>
    98b0:	aa1303e1 	mov	x1, x19
    98b4:	d280001a 	mov	x26, #0x0                   	// #0
    98b8:	f9400821 	ldr	x1, [x1, #16]
    98bc:	aa1a03e0 	mov	x0, x26
    98c0:	9100075a 	add	x26, x26, #0x1
    98c4:	b5ffffa1 	cbnz	x1, 98b8 <fwp_hof0.constprop.0+0x1328>
    98c8:	f9001fe3 	str	x3, [sp, #56]
    98cc:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    98d0:	eb01035f 	cmp	x26, x1
    98d4:	54ff8cc8 	b.hi	8a6c <fwp_hof0.constprop.0+0x4dc>  // b.pmore
    98d8:	91000800 	add	x0, x0, #0x2
    98dc:	52800041 	mov	w1, #0x2                   	// #2
    98e0:	d37df000 	lsl	x0, x0, #3
    98e4:	97ffeda3 	bl	4f70 <fwp_heap_alloc>
    98e8:	f9401fe3 	ldr	x3, [sp, #56]
    98ec:	aa1303e1 	mov	x1, x19
    98f0:	aa0003e5 	mov	x5, x0
    98f4:	f9400422 	ldr	x2, [x1, #8]
    98f8:	f8008402 	str	x2, [x0], #8
    98fc:	f9400821 	ldr	x1, [x1, #16]
    9900:	b5ffffa1 	cbnz	x1, 98f4 <fwp_hof0.constprop.0+0x1364>
    9904:	52800008 	mov	w8, #0x0                   	// #0
    9908:	17ffff57 	b	9664 <fwp_hof0.constprop.0+0x10d4>
    990c:	b4003e33 	cbz	x19, a0d0 <fwp_hof0.constprop.0+0x1b40>
    9910:	911742e0 	add	x0, x23, #0x5d0
    9914:	aa1303e4 	mov	x4, x19
    9918:	d280001b 	mov	x27, #0x0                   	// #0
    991c:	f949ec09 	ldr	x9, [x0, #5080]
    9920:	f949d80b 	ldr	x11, [x0, #5040]
    9924:	f949fc0c 	ldr	x12, [x0, #5112]
    9928:	d370bd29 	lsl	x9, x9, #16
    992c:	14000006 	b	9944 <fwp_hof0.constprop.0+0x13b4>
    9930:	f9400884 	ldr	x4, [x4, #16]
    9934:	9100077b 	add	x27, x27, #0x1
    9938:	f100009f 	cmp	x4, #0x0
    993c:	fa5b1040 	ccmp	x2, x27, #0x0, ne	// ne = any
    9940:	54000329 	b.ls	99a4 <fwp_hof0.constprop.0+0x1414>  // b.plast
    9944:	cb0b0080 	sub	x0, x4, x11
    9948:	eb09001f 	cmp	x0, x9
    994c:	540002c2 	b.cs	99a4 <fwp_hof0.constprop.0+0x1414>  // b.hs, b.nlast
    9950:	d350fc01 	lsr	x1, x0, #16
    9954:	8b010821 	add	x1, x1, x1, lsl #2
    9958:	d37df021 	lsl	x1, x1, #3
    995c:	8b010187 	add	x7, x12, x1
    9960:	f94010e6 	ldr	x6, [x7, #32]
    9964:	b4000206 	cbz	x6, 99a4 <fwp_hof0.constprop.0+0x1414>
    9968:	38616981 	ldrb	w1, [x12, x1]
    996c:	7100083f 	cmp	w1, #0x2
    9970:	540008e0 	b.eq	9a8c <fwp_hof0.constprop.0+0x14fc>  // b.none
    9974:	7100043f 	cmp	w1, #0x1
    9978:	54000161 	b.ne	99a4 <fwp_hof0.constprop.0+0x1414>  // b.any
    997c:	294304ea 	ldp	w10, w1, [x7, #24]
    9980:	92403c00 	and	x0, x0, #0xffff
    9984:	9b0a7c00 	mul	x0, x0, x10
    9988:	d360fc00 	lsr	x0, x0, #32
    998c:	eb01001f 	cmp	x0, x1
    9990:	540000a2 	b.cs	99a4 <fwp_hof0.constprop.0+0x1414>  // b.hs, b.nlast
    9994:	8b0000c6 	add	x6, x6, x0
    9998:	394000c0 	ldrb	w0, [x6]
    999c:	7100041f 	cmp	w0, #0x1
    99a0:	54fffc80 	b.eq	9930 <fwp_hof0.constprop.0+0x13a0>  // b.none
    99a4:	d2800004 	mov	x4, #0x0                   	// #0
    99a8:	eb1b005f 	cmp	x2, x27
    99ac:	540036e9 	b.ls	a088 <fwp_hof0.constprop.0+0x1af8>  // b.plast
    99b0:	d10020a0 	sub	x0, x5, #0x8
    99b4:	911742fa 	add	x26, x23, #0x5d0
    99b8:	d2800004 	mov	x4, #0x0                   	// #0
    99bc:	a9044fe0 	stp	x0, x19, [sp, #64]
    99c0:	9103e3e0 	add	x0, sp, #0xf8
    99c4:	aa0203f3 	mov	x19, x2
    99c8:	f9001fe0 	str	x0, [sp, #56]
    99cc:	a90517f4 	stp	x20, x5, [sp, #80]
    99d0:	aa1a03f4 	mov	x20, x26
    99d4:	aa1603fa 	mov	x26, x22
    99d8:	aa0303f6 	mov	x22, x3
    99dc:	b90063e8 	str	w8, [sp, #96]
    99e0:	f90037e2 	str	x2, [sp, #104]
    99e4:	14000012 	b	9a2c <fwp_hof0.constprop.0+0x149c>
    99e8:	7100045f 	cmp	w2, #0x1
    99ec:	540001a1 	b.ne	9a20 <fwp_hof0.constprop.0+0x1490>  // b.any
    99f0:	29430866 	ldp	w6, w2, [x3, #24]
    99f4:	92403c21 	and	x1, x1, #0xffff
    99f8:	9b067c21 	mul	x1, x1, x6
    99fc:	d360fc21 	lsr	x1, x1, #32
    9a00:	eb02003f 	cmp	x1, x2
    9a04:	540000e2 	b.cs	9a20 <fwp_hof0.constprop.0+0x1490>  // b.hs, b.nlast
    9a08:	8b010000 	add	x0, x0, x1
    9a0c:	39400001 	ldrb	w1, [x0]
    9a10:	7103fc3f 	cmp	w1, #0xff
    9a14:	54003500 	b.eq	a0b4 <fwp_hof0.constprop.0+0x1b24>  // b.none
    9a18:	52800021 	mov	w1, #0x1                   	// #1
    9a1c:	39000001 	strb	w1, [x0]
    9a20:	d1000673 	sub	x19, x19, #0x1
    9a24:	eb13037f 	cmp	x27, x19
    9a28:	54002ac2 	b.cs	9f80 <fwp_hof0.constprop.0+0x19f0>  // b.hs, b.nlast
    9a2c:	a94383e1 	ldp	x1, x0, [sp, #56]
    9a30:	f8737800 	ldr	x0, [x0, x19, lsl #3]
    9a34:	a90f93e0 	stp	x0, x4, [sp, #248]
    9a38:	52800020 	mov	w0, #0x1                   	// #1
    9a3c:	97ffed92 	bl	5084 <fwp_data.part.0.constprop.0>
    9a40:	aa0003e4 	mov	x4, x0
    9a44:	f949da81 	ldr	x1, [x20, #5040]
    9a48:	f949ee80 	ldr	x0, [x20, #5080]
    9a4c:	cb010081 	sub	x1, x4, x1
    9a50:	eb00403f 	cmp	x1, x0, lsl #16
    9a54:	54fffe62 	b.cs	9a20 <fwp_hof0.constprop.0+0x1490>  // b.hs, b.nlast
    9a58:	d350fc20 	lsr	x0, x1, #16
    9a5c:	f949fe86 	ldr	x6, [x20, #5112]
    9a60:	8b000800 	add	x0, x0, x0, lsl #2
    9a64:	d37df002 	lsl	x2, x0, #3
    9a68:	8b0200c3 	add	x3, x6, x2
    9a6c:	f9401060 	ldr	x0, [x3, #32]
    9a70:	b4fffd80 	cbz	x0, 9a20 <fwp_hof0.constprop.0+0x1490>
    9a74:	386268c2 	ldrb	w2, [x6, x2]
    9a78:	7100085f 	cmp	w2, #0x2
    9a7c:	54fffb61 	b.ne	99e8 <fwp_hof0.constprop.0+0x1458>  // b.any
    9a80:	72003c3f 	tst	w1, #0xffff
    9a84:	54fffce1 	b.ne	9a20 <fwp_hof0.constprop.0+0x1490>  // b.any
    9a88:	17ffffe1 	b	9a0c <fwp_hof0.constprop.0+0x147c>
    9a8c:	72003c1f 	tst	w0, #0xffff
    9a90:	54fff8a1 	b.ne	99a4 <fwp_hof0.constprop.0+0x1414>  // b.any
    9a94:	17ffffc1 	b	9998 <fwp_hof0.constprop.0+0x1408>
    9a98:	72003c3f 	tst	w1, #0xffff
    9a9c:	54ffd1e1 	b.ne	94d8 <fwp_hof0.constprop.0+0xf48>  // b.any
    9aa0:	17fffe89 	b	94c4 <fwp_hof0.constprop.0+0xf34>
    9aa4:	aa0203e0 	mov	x0, x2
    9aa8:	d2800101 	mov	x1, #0x8                   	// #8
    9aac:	f9001fe2 	str	x2, [sp, #56]
    9ab0:	97ffe390 	bl	28f0 <calloc@plt>
    9ab4:	f9401fe2 	ldr	x2, [sp, #56]
    9ab8:	aa0003e4 	mov	x4, x0
    9abc:	f94037e3 	ldr	x3, [sp, #104]
    9ac0:	17fffe0b 	b	92ec <fwp_hof0.constprop.0+0xd5c>
    9ac4:	90000020 	adrp	x0, d000 <__divti3+0x320>
    9ac8:	91280000 	add	x0, x0, #0xa00
    9acc:	97ffe9b1 	bl	4190 <fwp_trap>
    9ad0:	aa1b03e0 	mov	x0, x27
    9ad4:	97ffe9cf 	bl	4210 <fwp_rc_forget_slot.part.0>
    9ad8:	9101c2a0 	add	x0, x21, #0x70
    9adc:	f9418803 	ldr	x3, [x0, #784]
    9ae0:	17fffe7c 	b	94d0 <fwp_hof0.constprop.0+0xf40>
    9ae4:	a9038fe0 	stp	x0, x3, [sp, #56]
    9ae8:	97ffe9ca 	bl	4210 <fwp_rc_forget_slot.part.0>
    9aec:	a9438fe0 	ldp	x0, x3, [sp, #56]
    9af0:	17ffff3d 	b	97e4 <fwp_hof0.constprop.0+0x1254>
    9af4:	f9400062 	ldr	x2, [x3]
    9af8:	b7f800e2 	tbnz	x2, #63, 9b14 <fwp_hof0.constprop.0+0x1584>
    9afc:	9240f85b 	and	x27, x2, #0x7fffffffffffffff
    9b00:	d280001a 	mov	x26, #0x0                   	// #0
    9b04:	17fffebb 	b	95f0 <fwp_hof0.constprop.0+0x1060>
    9b08:	72003c1f 	tst	w0, #0xffff
    9b0c:	54ffda40 	b.eq	9654 <fwp_hof0.constprop.0+0x10c4>  // b.none
    9b10:	b5ffed13 	cbnz	x19, 98b0 <fwp_hof0.constprop.0+0x1320>
    9b14:	52800041 	mov	w1, #0x2                   	// #2
    9b18:	d2800100 	mov	x0, #0x8                   	// #8
    9b1c:	f9001fe3 	str	x3, [sp, #56]
    9b20:	97ffed14 	bl	4f70 <fwp_heap_alloc>
    9b24:	f9401fe3 	ldr	x3, [sp, #56]
    9b28:	aa0003e5 	mov	x5, x0
    9b2c:	52800008 	mov	w8, #0x0                   	// #0
    9b30:	aa1303fa 	mov	x26, x19
    9b34:	d2800013 	mov	x19, #0x0                   	// #0
    9b38:	7100011f 	cmp	w8, #0x0
    9b3c:	9a8513fb 	csel	x27, xzr, x5, ne	// ne = any
    9b40:	aa1b03e0 	mov	x0, x27
    9b44:	f90027e3 	str	x3, [sp, #72]
    9b48:	97ffea4e 	bl	4480 <fwp_mem_free>
    9b4c:	a903dbf8 	stp	x24, x22, [sp, #56]
    9b50:	911742e6 	add	x6, x23, #0x5d0
    9b54:	f94027e3 	ldr	x3, [sp, #72]
    9b58:	aa1403f8 	mov	x24, x20
    9b5c:	aa1303f6 	mov	x22, x19
    9b60:	aa0603f4 	mov	x20, x6
    9b64:	aa0303f3 	mov	x19, x3
    9b68:	d2800507 	mov	x7, #0x28                  	// #40
    9b6c:	f949da80 	ldr	x0, [x20, #5040]
    9b70:	f949ee81 	ldr	x1, [x20, #5080]
    9b74:	cb000260 	sub	x0, x19, x0
    9b78:	eb01401f 	cmp	x0, x1, lsl #16
    9b7c:	540012a2 	b.cs	9dd0 <fwp_hof0.constprop.0+0x1840>  // b.hs, b.nlast
    9b80:	d350fc01 	lsr	x1, x0, #16
    9b84:	f949fe82 	ldr	x2, [x20, #5112]
    9b88:	9b077c21 	mul	x1, x1, x7
    9b8c:	8b010044 	add	x4, x2, x1
    9b90:	f940109b 	ldr	x27, [x4, #32]
    9b94:	b40011fb 	cbz	x27, 9dd0 <fwp_hof0.constprop.0+0x1840>
    9b98:	38616845 	ldrb	w5, [x2, x1]
    9b9c:	710008bf 	cmp	w5, #0x2
    9ba0:	54001140 	b.eq	9dc8 <fwp_hof0.constprop.0+0x1838>  // b.none
    9ba4:	710004bf 	cmp	w5, #0x1
    9ba8:	54001141 	b.ne	9dd0 <fwp_hof0.constprop.0+0x1840>  // b.any
    9bac:	29432082 	ldp	w2, w8, [x4, #24]
    9bb0:	92403c01 	and	x1, x0, #0xffff
    9bb4:	9b027c20 	mul	x0, x1, x2
    9bb8:	d360fc00 	lsr	x0, x0, #32
    9bbc:	eb08001f 	cmp	x0, x8
    9bc0:	54001082 	b.cs	9dd0 <fwp_hof0.constprop.0+0x1840>  // b.hs, b.nlast
    9bc4:	8b00037b 	add	x27, x27, x0
    9bc8:	39400362 	ldrb	w2, [x27]
    9bcc:	34001022 	cbz	w2, 9dd0 <fwp_hof0.constprop.0+0x1840>
    9bd0:	7100045f 	cmp	w2, #0x1
    9bd4:	54000da0 	b.eq	9d88 <fwp_hof0.constprop.0+0x17f8>  // b.none
    9bd8:	aa1603f3 	mov	x19, x22
    9bdc:	aa1803f4 	mov	x20, x24
    9be0:	a943dbf8 	ldp	x24, x22, [sp, #56]
    9be4:	7103fc5f 	cmp	w2, #0xff
    9be8:	54000fc0 	b.eq	9de0 <fwp_hof0.constprop.0+0x1850>  // b.none
    9bec:	51000442 	sub	w2, w2, #0x1
    9bf0:	39000362 	strb	w2, [x27]
    9bf4:	911742e4 	add	x4, x23, #0x5d0
    9bf8:	f9001ff6 	str	x22, [sp, #56]
    9bfc:	aa1403f6 	mov	x22, x20
    9c00:	aa1303f4 	mov	x20, x19
    9c04:	aa0403f3 	mov	x19, x4
    9c08:	d2800506 	mov	x6, #0x28                  	// #40
    9c0c:	f949da60 	ldr	x0, [x19, #5040]
    9c10:	f949ee61 	ldr	x1, [x19, #5080]
    9c14:	cb000340 	sub	x0, x26, x0
    9c18:	eb01401f 	cmp	x0, x1, lsl #16
    9c1c:	54000ae2 	b.cs	9d78 <fwp_hof0.constprop.0+0x17e8>  // b.hs, b.nlast
    9c20:	d350fc01 	lsr	x1, x0, #16
    9c24:	f949fe62 	ldr	x2, [x19, #5112]
    9c28:	9b067c21 	mul	x1, x1, x6
    9c2c:	8b010043 	add	x3, x2, x1
    9c30:	f940107b 	ldr	x27, [x3, #32]
    9c34:	b4000a3b 	cbz	x27, 9d78 <fwp_hof0.constprop.0+0x17e8>
    9c38:	38616845 	ldrb	w5, [x2, x1]
    9c3c:	710008bf 	cmp	w5, #0x2
    9c40:	54000980 	b.eq	9d70 <fwp_hof0.constprop.0+0x17e0>  // b.none
    9c44:	710004bf 	cmp	w5, #0x1
    9c48:	54000981 	b.ne	9d78 <fwp_hof0.constprop.0+0x17e8>  // b.any
    9c4c:	29430861 	ldp	w1, w2, [x3, #24]
    9c50:	92403c00 	and	x0, x0, #0xffff
    9c54:	9b017c01 	mul	x1, x0, x1
    9c58:	d360fc21 	lsr	x1, x1, #32
    9c5c:	eb02003f 	cmp	x1, x2
    9c60:	540008c2 	b.cs	9d78 <fwp_hof0.constprop.0+0x17e8>  // b.hs, b.nlast
    9c64:	8b01037b 	add	x27, x27, x1
    9c68:	39400362 	ldrb	w2, [x27]
    9c6c:	34000862 	cbz	w2, 9d78 <fwp_hof0.constprop.0+0x17e8>
    9c70:	7100045f 	cmp	w2, #0x1
    9c74:	540012c0 	b.eq	9ecc <fwp_hof0.constprop.0+0x193c>  // b.none
    9c78:	aa1403f3 	mov	x19, x20
    9c7c:	aa1603f4 	mov	x20, x22
    9c80:	f9401ff6 	ldr	x22, [sp, #56]
    9c84:	7103fc5f 	cmp	w2, #0xff
    9c88:	54001040 	b.eq	9e90 <fwp_hof0.constprop.0+0x1900>  // b.none
    9c8c:	51000442 	sub	w2, w2, #0x1
    9c90:	39000362 	strb	w2, [x27]
    9c94:	f9400be0 	ldr	x0, [sp, #16]
    9c98:	b4ff7160 	cbz	x0, 8ac4 <fwp_hof0.constprop.0+0x534>
    9c9c:	f9400be0 	ldr	x0, [sp, #16]
    9ca0:	f1000400 	subs	x0, x0, #0x1
    9ca4:	f9000be0 	str	x0, [sp, #16]
    9ca8:	54002326 	b.vs	a10c <fwp_hof0.constprop.0+0x1b7c>
    9cac:	911742e0 	add	x0, x23, #0x5d0
    9cb0:	f949ec05 	ldr	x5, [x0, #5080]
    9cb4:	f949d801 	ldr	x1, [x0, #5040]
    9cb8:	d370bca5 	lsl	x5, x5, #16
    9cbc:	17fffa7d 	b	86b0 <fwp_hof0.constprop.0+0x120>
    9cc0:	90000020 	adrp	x0, d000 <__divti3+0x320>
    9cc4:	9128a000 	add	x0, x0, #0xa28
    9cc8:	97ffe932 	bl	4190 <fwp_trap>
    9ccc:	aa1603e0 	mov	x0, x22
    9cd0:	97ffef7c 	bl	5ac0 <fwp_rc_free_arr>
    9cd4:	17fffbe7 	b	8c70 <fwp_hof0.constprop.0+0x6e0>
    9cd8:	72003c3f 	tst	w1, #0xffff
    9cdc:	54ff7ca1 	b.ne	8c70 <fwp_hof0.constprop.0+0x6e0>  // b.any
    9ce0:	17fffbdc 	b	8c50 <fwp_hof0.constprop.0+0x6c0>
    9ce4:	72003c3f 	tst	w1, #0xffff
    9ce8:	54ff76c1 	b.ne	8bc0 <fwp_hof0.constprop.0+0x630>  // b.any
    9cec:	17fffbb0 	b	8bac <fwp_hof0.constprop.0+0x61c>
    9cf0:	f9000be0 	str	x0, [sp, #16]
    9cf4:	97ffe947 	bl	4210 <fwp_rc_forget_slot.part.0>
    9cf8:	f9400be0 	ldr	x0, [sp, #16]
    9cfc:	17fffbaf 	b	8bb8 <fwp_hof0.constprop.0+0x628>
    9d00:	ca534661 	eor	x1, x19, x19, lsr #17
    9d04:	911742e2 	add	x2, x23, #0x5d0
    9d08:	ca412421 	eor	x1, x1, x1, lsr #9
    9d0c:	92401c21 	and	x1, x1, #0xff
    9d10:	910a2420 	add	x0, x1, #0x289
    9d14:	8b010c41 	add	x1, x2, x1, lsl #3
    9d18:	8b000c40 	add	x0, x2, x0, lsl #3
    9d1c:	f94a2421 	ldr	x1, [x1, #5192]
    9d20:	b50000a1 	cbnz	x1, 9d34 <fwp_hof0.constprop.0+0x17a4>
    9d24:	17fffe70 	b	96e4 <fwp_hof0.constprop.0+0x1154>
    9d28:	91004020 	add	x0, x1, #0x10
    9d2c:	f9400821 	ldr	x1, [x1, #16]
    9d30:	b4ffcda1 	cbz	x1, 96e4 <fwp_hof0.constprop.0+0x1154>
    9d34:	f9400022 	ldr	x2, [x1]
    9d38:	eb13005f 	cmp	x2, x19
    9d3c:	54ffff61 	b.ne	9d28 <fwp_hof0.constprop.0+0x1798>  // b.any
    9d40:	f9400001 	ldr	x1, [x0]
    9d44:	f9400420 	ldr	x0, [x1, #8]
    9d48:	d1000400 	sub	x0, x0, #0x1
    9d4c:	f9000420 	str	x0, [x1, #8]
    9d50:	f103f81f 	cmp	x0, #0xfe
    9d54:	54ff78e1 	b.ne	8c70 <fwp_hof0.constprop.0+0x6e0>  // b.any
    9d58:	39400260 	ldrb	w0, [x19]
    9d5c:	7103fc1f 	cmp	w0, #0xff
    9d60:	54000ea0 	b.eq	9f34 <fwp_hof0.constprop.0+0x19a4>  // b.none
    9d64:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9d68:	39000260 	strb	w0, [x19]
    9d6c:	17fffbc1 	b	8c70 <fwp_hof0.constprop.0+0x6e0>
    9d70:	f2403c00 	ands	x0, x0, #0xffff
    9d74:	54fff7a0 	b.eq	9c68 <fwp_hof0.constprop.0+0x16d8>  // b.none
    9d78:	aa1403f3 	mov	x19, x20
    9d7c:	aa1603f4 	mov	x20, x22
    9d80:	f9401ff6 	ldr	x22, [sp, #56]
    9d84:	17ffffc4 	b	9c94 <fwp_hof0.constprop.0+0x1704>
    9d88:	f9400262 	ldr	x2, [x19]
    9d8c:	aa1303e0 	mov	x0, x19
    9d90:	b7f804a2 	tbnz	x2, #63, 9e24 <fwp_hof0.constprop.0+0x1894>
    9d94:	aa1803f4 	mov	x20, x24
    9d98:	aa1303e3 	mov	x3, x19
    9d9c:	aa1603f3 	mov	x19, x22
    9da0:	a943dbf8 	ldp	x24, x22, [sp, #56]
    9da4:	710008bf 	cmp	w5, #0x2
    9da8:	540003a0 	b.eq	9e1c <fwp_hof0.constprop.0+0x188c>  // b.none
    9dac:	29430082 	ldp	w2, w0, [x4, #24]
    9db0:	9b027c21 	mul	x1, x1, x2
    9db4:	eb41801f 	cmp	x0, x1, lsr #32
    9db8:	54fff1e9 	b.ls	9bf4 <fwp_hof0.constprop.0+0x1664>  // b.plast
    9dbc:	aa0303e0 	mov	x0, x3
    9dc0:	97ffe9b0 	bl	4480 <fwp_mem_free>
    9dc4:	17ffff8c 	b	9bf4 <fwp_hof0.constprop.0+0x1664>
    9dc8:	f2403c01 	ands	x1, x0, #0xffff
    9dcc:	54ffefe0 	b.eq	9bc8 <fwp_hof0.constprop.0+0x1638>  // b.none
    9dd0:	aa1603f3 	mov	x19, x22
    9dd4:	aa1803f4 	mov	x20, x24
    9dd8:	a943dbf8 	ldp	x24, x22, [sp, #56]
    9ddc:	17ffff86 	b	9bf4 <fwp_hof0.constprop.0+0x1664>
    9de0:	ca5b4761 	eor	x1, x27, x27, lsr #17
    9de4:	911742e0 	add	x0, x23, #0x5d0
    9de8:	ca412421 	eor	x1, x1, x1, lsr #9
    9dec:	92401c21 	and	x1, x1, #0xff
    9df0:	910a2422 	add	x2, x1, #0x289
    9df4:	8b010c01 	add	x1, x0, x1, lsl #3
    9df8:	8b020c02 	add	x2, x0, x2, lsl #3
    9dfc:	f94a2420 	ldr	x0, [x1, #5192]
    9e00:	b4ffc720 	cbz	x0, 96e4 <fwp_hof0.constprop.0+0x1154>
    9e04:	f9400001 	ldr	x1, [x0]
    9e08:	eb01037f 	cmp	x27, x1
    9e0c:	54000200 	b.eq	9e4c <fwp_hof0.constprop.0+0x18bc>  // b.none
    9e10:	91004002 	add	x2, x0, #0x10
    9e14:	f9400800 	ldr	x0, [x0, #16]
    9e18:	17fffffa 	b	9e00 <fwp_hof0.constprop.0+0x1870>
    9e1c:	b5ffeec1 	cbnz	x1, 9bf4 <fwp_hof0.constprop.0+0x1664>
    9e20:	17ffffe7 	b	9dbc <fwp_hof0.constprop.0+0x182c>
    9e24:	f9400673 	ldr	x19, [x19, #8]
    9e28:	710008bf 	cmp	w5, #0x2
    9e2c:	54000280 	b.eq	9e7c <fwp_hof0.constprop.0+0x18ec>  // b.none
    9e30:	29430885 	ldp	w5, w2, [x4, #24]
    9e34:	9b057c21 	mul	x1, x1, x5
    9e38:	eb41805f 	cmp	x2, x1, lsr #32
    9e3c:	54ffe989 	b.ls	9b6c <fwp_hof0.constprop.0+0x15dc>  // b.plast
    9e40:	97ffe990 	bl	4480 <fwp_mem_free>
    9e44:	d2800507 	mov	x7, #0x28                  	// #40
    9e48:	17ffff49 	b	9b6c <fwp_hof0.constprop.0+0x15dc>
    9e4c:	f9400041 	ldr	x1, [x2]
    9e50:	f9400420 	ldr	x0, [x1, #8]
    9e54:	d1000400 	sub	x0, x0, #0x1
    9e58:	f9000420 	str	x0, [x1, #8]
    9e5c:	f103f81f 	cmp	x0, #0xfe
    9e60:	54ffeca1 	b.ne	9bf4 <fwp_hof0.constprop.0+0x1664>  // b.any
    9e64:	39400360 	ldrb	w0, [x27]
    9e68:	7103fc1f 	cmp	w0, #0xff
    9e6c:	540000c0 	b.eq	9e84 <fwp_hof0.constprop.0+0x18f4>  // b.none
    9e70:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9e74:	39000360 	strb	w0, [x27]
    9e78:	17ffff5f 	b	9bf4 <fwp_hof0.constprop.0+0x1664>
    9e7c:	b5ffe781 	cbnz	x1, 9b6c <fwp_hof0.constprop.0+0x15dc>
    9e80:	17fffff0 	b	9e40 <fwp_hof0.constprop.0+0x18b0>
    9e84:	aa1b03e0 	mov	x0, x27
    9e88:	97ffe8e2 	bl	4210 <fwp_rc_forget_slot.part.0>
    9e8c:	17fffff9 	b	9e70 <fwp_hof0.constprop.0+0x18e0>
    9e90:	ca5b4761 	eor	x1, x27, x27, lsr #17
    9e94:	911742e0 	add	x0, x23, #0x5d0
    9e98:	ca412421 	eor	x1, x1, x1, lsr #9
    9e9c:	92401c21 	and	x1, x1, #0xff
    9ea0:	910a2422 	add	x2, x1, #0x289
    9ea4:	8b010c01 	add	x1, x0, x1, lsl #3
    9ea8:	8b020c02 	add	x2, x0, x2, lsl #3
    9eac:	f94a2420 	ldr	x0, [x1, #5192]
    9eb0:	b4ffc1a0 	cbz	x0, 96e4 <fwp_hof0.constprop.0+0x1154>
    9eb4:	f9400001 	ldr	x1, [x0]
    9eb8:	eb01037f 	cmp	x27, x1
    9ebc:	54000240 	b.eq	9f04 <fwp_hof0.constprop.0+0x1974>  // b.none
    9ec0:	91004002 	add	x2, x0, #0x10
    9ec4:	f9400800 	ldr	x0, [x0, #16]
    9ec8:	17fffffa 	b	9eb0 <fwp_hof0.constprop.0+0x1920>
    9ecc:	aa1a03e1 	mov	x1, x26
    9ed0:	f9400b5a 	ldr	x26, [x26, #16]
    9ed4:	710008bf 	cmp	w5, #0x2
    9ed8:	54000120 	b.eq	9efc <fwp_hof0.constprop.0+0x196c>  // b.none
    9edc:	29430865 	ldp	w5, w2, [x3, #24]
    9ee0:	9b057c00 	mul	x0, x0, x5
    9ee4:	eb40805f 	cmp	x2, x0, lsr #32
    9ee8:	54ffe929 	b.ls	9c0c <fwp_hof0.constprop.0+0x167c>  // b.plast
    9eec:	aa0103e0 	mov	x0, x1
    9ef0:	97ffe964 	bl	4480 <fwp_mem_free>
    9ef4:	d2800506 	mov	x6, #0x28                  	// #40
    9ef8:	17ffff45 	b	9c0c <fwp_hof0.constprop.0+0x167c>
    9efc:	b5ffe880 	cbnz	x0, 9c0c <fwp_hof0.constprop.0+0x167c>
    9f00:	17fffffb 	b	9eec <fwp_hof0.constprop.0+0x195c>
    9f04:	f9400041 	ldr	x1, [x2]
    9f08:	f9400420 	ldr	x0, [x1, #8]
    9f0c:	d1000400 	sub	x0, x0, #0x1
    9f10:	f9000420 	str	x0, [x1, #8]
    9f14:	f103f81f 	cmp	x0, #0xfe
    9f18:	54ffebe1 	b.ne	9c94 <fwp_hof0.constprop.0+0x1704>  // b.any
    9f1c:	39400360 	ldrb	w0, [x27]
    9f20:	7103fc1f 	cmp	w0, #0xff
    9f24:	540000e0 	b.eq	9f40 <fwp_hof0.constprop.0+0x19b0>  // b.none
    9f28:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9f2c:	39000360 	strb	w0, [x27]
    9f30:	17ffff59 	b	9c94 <fwp_hof0.constprop.0+0x1704>
    9f34:	aa1303e0 	mov	x0, x19
    9f38:	97ffe8b6 	bl	4210 <fwp_rc_forget_slot.part.0>
    9f3c:	17ffff8a 	b	9d64 <fwp_hof0.constprop.0+0x17d4>
    9f40:	aa1b03e0 	mov	x0, x27
    9f44:	97ffe8b3 	bl	4210 <fwp_rc_forget_slot.part.0>
    9f48:	17fffff8 	b	9f28 <fwp_hof0.constprop.0+0x1998>
    9f4c:	a9038fe0 	stp	x0, x3, [sp, #56]
    9f50:	97ffe8b0 	bl	4210 <fwp_rc_forget_slot.part.0>
    9f54:	a9438fe0 	ldp	x0, x3, [sp, #56]
    9f58:	17fffe4d 	b	988c <fwp_hof0.constprop.0+0x12fc>
    9f5c:	72003c3f 	tst	w1, #0xffff
    9f60:	54ffc900 	b.eq	9880 <fwp_hof0.constprop.0+0x12f0>  // b.none
    9f64:	aa1a03e0 	mov	x0, x26
    9f68:	17fffd85 	b	957c <fwp_hof0.constprop.0+0xfec>
    9f6c:	a91253f3 	stp	x19, x20, [sp, #288]
    9f70:	a9135bf5 	stp	x21, x22, [sp, #304]
    9f74:	a91463f7 	stp	x23, x24, [sp, #320]
    9f78:	a9156bf9 	stp	x25, x26, [sp, #336]
    9f7c:	97ffe265 	bl	2910 <__stack_chk_fail@plt>
    9f80:	f94037e2 	ldr	x2, [sp, #104]
    9f84:	aa1603e3 	mov	x3, x22
    9f88:	a944d3f3 	ldp	x19, x20, [sp, #72]
    9f8c:	d1000441 	sub	x1, x2, #0x1
    9f90:	cb020360 	sub	x0, x27, x2
    9f94:	eb01037f 	cmp	x27, x1
    9f98:	9a8087e0 	csinc	x0, xzr, x0, hi	// hi = pmore
    9f9c:	b94063e8 	ldr	w8, [sp, #96]
    9fa0:	f9402fe5 	ldr	x5, [sp, #88]
    9fa4:	aa1a03f6 	mov	x22, x26
    9fa8:	8b010000 	add	x0, x0, x1
    9fac:	b50006fb 	cbnz	x27, a088 <fwp_hof0.constprop.0+0x1af8>
    9fb0:	7100011f 	cmp	w8, #0x0
    9fb4:	9a8513fb 	csel	x27, xzr, x5, ne	// ne = any
    9fb8:	b4000860 	cbz	x0, a0c4 <fwp_hof0.constprop.0+0x1b34>
    9fbc:	911742fa 	add	x26, x23, #0x5d0
    9fc0:	d1000406 	sub	x6, x0, #0x1
    9fc4:	aa1a03e0 	mov	x0, x26
    9fc8:	aa1603fa 	mov	x26, x22
    9fcc:	aa0003f6 	mov	x22, x0
    9fd0:	a90453f3 	stp	x19, x20, [sp, #64]
    9fd4:	aa1b03f3 	mov	x19, x27
    9fd8:	aa0603f4 	mov	x20, x6
    9fdc:	f9002be3 	str	x3, [sp, #80]
    9fe0:	14000012 	b	a028 <fwp_hof0.constprop.0+0x1a98>
    9fe4:	7100045f 	cmp	w2, #0x1
    9fe8:	540001a1 	b.ne	a01c <fwp_hof0.constprop.0+0x1a8c>  // b.any
    9fec:	29430002 	ldp	w2, w0, [x0, #24]
    9ff0:	92403c21 	and	x1, x1, #0xffff
    9ff4:	9b027c21 	mul	x1, x1, x2
    9ff8:	d360fc21 	lsr	x1, x1, #32
    9ffc:	eb00003f 	cmp	x1, x0
    a000:	540000e2 	b.cs	a01c <fwp_hof0.constprop.0+0x1a8c>  // b.hs, b.nlast
    a004:	8b01037b 	add	x27, x27, x1
    a008:	39400360 	ldrb	w0, [x27]
    a00c:	7103fc1f 	cmp	w0, #0xff
    a010:	54000640 	b.eq	a0d8 <fwp_hof0.constprop.0+0x1b48>  // b.none
    a014:	52800020 	mov	w0, #0x1                   	// #1
    a018:	39000360 	strb	w0, [x27]
    a01c:	d1000694 	sub	x20, x20, #0x1
    a020:	b100069f 	cmn	x20, #0x1
    a024:	54000640 	b.eq	a0ec <fwp_hof0.constprop.0+0x1b5c>  // b.none
    a028:	f9401fe1 	ldr	x1, [sp, #56]
    a02c:	f8747a60 	ldr	x0, [x19, x20, lsl #3]
    a030:	a90f93e0 	stp	x0, x4, [sp, #248]
    a034:	52800020 	mov	w0, #0x1                   	// #1
    a038:	97ffec13 	bl	5084 <fwp_data.part.0.constprop.0>
    a03c:	aa0003e4 	mov	x4, x0
    a040:	f949dac1 	ldr	x1, [x22, #5040]
    a044:	f949eec0 	ldr	x0, [x22, #5080]
    a048:	cb010081 	sub	x1, x4, x1
    a04c:	eb00403f 	cmp	x1, x0, lsl #16
    a050:	54fffe62 	b.cs	a01c <fwp_hof0.constprop.0+0x1a8c>  // b.hs, b.nlast
    a054:	d350fc20 	lsr	x0, x1, #16
    a058:	f949fec7 	ldr	x7, [x22, #5112]
    a05c:	8b000800 	add	x0, x0, x0, lsl #2
    a060:	d37df002 	lsl	x2, x0, #3
    a064:	8b0200e0 	add	x0, x7, x2
    a068:	f940101b 	ldr	x27, [x0, #32]
    a06c:	b4fffd9b 	cbz	x27, a01c <fwp_hof0.constprop.0+0x1a8c>
    a070:	386268e2 	ldrb	w2, [x7, x2]
    a074:	7100085f 	cmp	w2, #0x2
    a078:	54fffb61 	b.ne	9fe4 <fwp_hof0.constprop.0+0x1a54>  // b.any
    a07c:	72003c3f 	tst	w1, #0xffff
    a080:	54fffce1 	b.ne	a01c <fwp_hof0.constprop.0+0x1a8c>  // b.any
    a084:	17ffffe1 	b	a008 <fwp_hof0.constprop.0+0x1a78>
    a088:	aa1303fa 	mov	x26, x19
    a08c:	d2800000 	mov	x0, #0x0                   	// #0
    a090:	f86078a1 	ldr	x1, [x5, x0, lsl #3]
    a094:	91000400 	add	x0, x0, #0x1
    a098:	f9000741 	str	x1, [x26, #8]
    a09c:	aa1a03e1 	mov	x1, x26
    a0a0:	f9400b5a 	ldr	x26, [x26, #16]
    a0a4:	eb00037f 	cmp	x27, x0
    a0a8:	54ffff48 	b.hi	a090 <fwp_hof0.constprop.0+0x1b00>  // b.pmore
    a0ac:	f9000824 	str	x4, [x1, #16]
    a0b0:	17fffea2 	b	9b38 <fwp_hof0.constprop.0+0x15a8>
    a0b4:	a90713e0 	stp	x0, x4, [sp, #112]
    a0b8:	97ffe856 	bl	4210 <fwp_rc_forget_slot.part.0>
    a0bc:	a94713e0 	ldp	x0, x4, [sp, #112]
    a0c0:	17fffe56 	b	9a18 <fwp_hof0.constprop.0+0x1488>
    a0c4:	aa1303fa 	mov	x26, x19
    a0c8:	aa0403f3 	mov	x19, x4
    a0cc:	17fffe9d 	b	9b40 <fwp_hof0.constprop.0+0x15b0>
    a0d0:	d280001b 	mov	x27, #0x0                   	// #0
    a0d4:	17fffe37 	b	99b0 <fwp_hof0.constprop.0+0x1420>
    a0d8:	aa1b03e0 	mov	x0, x27
    a0dc:	f9002fe4 	str	x4, [sp, #88]
    a0e0:	97ffe84c 	bl	4210 <fwp_rc_forget_slot.part.0>
    a0e4:	f9402fe4 	ldr	x4, [sp, #88]
    a0e8:	17ffffcb 	b	a014 <fwp_hof0.constprop.0+0x1a84>
    a0ec:	aa1303fb 	mov	x27, x19
    a0f0:	aa1a03f6 	mov	x22, x26
    a0f4:	a94453f3 	ldp	x19, x20, [sp, #64]
    a0f8:	f9402be3 	ldr	x3, [sp, #80]
    a0fc:	aa1303fa 	mov	x26, x19
    a100:	aa0403f3 	mov	x19, x4
    a104:	17fffe8f 	b	9b40 <fwp_hof0.constprop.0+0x15b0>
    a108:	97ffe216 	bl	2960 <abort@plt>
    a10c:	97ffe27d 	bl	2b00 <fwp_trap_overflow.constprop.0>

000000000000a110 <f0>:
    a110:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    a114:	910003fd 	mov	x29, sp
    a118:	a90153f3 	stp	x19, x20, [sp, #16]
    a11c:	a9025bf5 	stp	x21, x22, [sp, #32]
    a120:	a90363f7 	stp	x23, x24, [sp, #48]
    a124:	a9046bf9 	stp	x25, x26, [sp, #64]
    a128:	a90573fb 	stp	x27, x28, [sp, #80]
    a12c:	d121c3ff 	sub	sp, sp, #0x870
    a130:	f90203ff 	str	xzr, [sp, #1024]
    a134:	d00000a0 	adrp	x0, 20000 <__data_start>
    a138:	9101c003 	add	x3, x0, #0x70
    a13c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    a140:	f947f400 	ldr	x0, [x0, #4072]
    a144:	f0000134 	adrp	x20, 31000 <fwp_root_context+0xc10>
    a148:	f9418865 	ldr	x5, [x3, #784]
    a14c:	f9400001 	ldr	x1, [x0]
    a150:	f90437e1 	str	x1, [sp, #2152]
    a154:	d2800001 	mov	x1, #0x0                   	// #0
    a158:	91174299 	add	x25, x20, #0x5d0
    a15c:	912163f6 	add	x22, sp, #0x858
    a160:	910063e4 	add	x4, sp, #0x18
    a164:	9100c3e1 	add	x1, sp, #0x30
    a168:	f0ffffc0 	adrp	x0, 5000 <fwp_heap_alloc+0x90>
    a16c:	90ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    a170:	913e0000 	add	x0, x0, #0xf80
    a174:	913f4042 	add	x2, x2, #0xfd0
    a178:	d2800013 	mov	x19, #0x0                   	// #0
    a17c:	d280011a 	mov	x26, #0x8                   	// #8
    a180:	d2800015 	mov	x21, #0x0                   	// #0
    a184:	52800037 	mov	w23, #0x1                   	// #1
    a188:	f90007e4 	str	x4, [sp, #8]
    a18c:	a9018be5 	stp	x5, x2, [sp, #24]
    a190:	a902ffe1 	stp	x1, xzr, [sp, #40]
    a194:	a90403ff 	stp	xzr, x0, [sp, #64]
    a198:	f9018864 	str	x4, [x3, #784]
    a19c:	d503201f 	nop
    a1a0:	f100075b 	subs	x27, x26, #0x1
    a1a4:	aa1603e1 	mov	x1, x22
    a1a8:	da1f02b8 	sbc	x24, x21, xzr
    a1ac:	52800020 	mov	w0, #0x1                   	// #1
    a1b0:	f9001ffb 	str	x27, [sp, #56]
    a1b4:	aa1b03fa 	mov	x26, x27
    a1b8:	f9042ffb 	str	x27, [sp, #2136]
    a1bc:	aa1803f5 	mov	x21, x24
    a1c0:	f90433f3 	str	x19, [sp, #2144]
    a1c4:	97ffebb0 	bl	5084 <fwp_data.part.0.constprop.0>
    a1c8:	f949db22 	ldr	x2, [x25, #5040]
    a1cc:	aa0003f3 	mov	x19, x0
    a1d0:	f949ef20 	ldr	x0, [x25, #5080]
    a1d4:	cb020262 	sub	x2, x19, x2
    a1d8:	eb00405f 	cmp	x2, x0, lsl #16
    a1dc:	54000302 	b.cs	a23c <f0+0x12c>  // b.hs, b.nlast
    a1e0:	d350fc40 	lsr	x0, x2, #16
    a1e4:	f949ff25 	ldr	x5, [x25, #5112]
    a1e8:	8b000800 	add	x0, x0, x0, lsl #2
    a1ec:	d37df001 	lsl	x1, x0, #3
    a1f0:	8b0100a0 	add	x0, x5, x1
    a1f4:	f940101c 	ldr	x28, [x0, #32]
    a1f8:	b400023c 	cbz	x28, a23c <f0+0x12c>
    a1fc:	386168a1 	ldrb	w1, [x5, x1]
    a200:	7100083f 	cmp	w1, #0x2
    a204:	54010f00 	b.eq	c3e4 <f0+0x22d4>  // b.none
    a208:	7100043f 	cmp	w1, #0x1
    a20c:	54000181 	b.ne	a23c <f0+0x12c>  // b.any
    a210:	29430001 	ldp	w1, w0, [x0, #24]
    a214:	92403c42 	and	x2, x2, #0xffff
    a218:	9b017c42 	mul	x2, x2, x1
    a21c:	d360fc42 	lsr	x2, x2, #32
    a220:	eb00005f 	cmp	x2, x0
    a224:	540000c2 	b.cs	a23c <f0+0x12c>  // b.hs, b.nlast
    a228:	8b02039c 	add	x28, x28, x2
    a22c:	39400380 	ldrb	w0, [x28]
    a230:	7103fc1f 	cmp	w0, #0xff
    a234:	54010d20 	b.eq	c3d8 <f0+0x22c8>  // b.none
    a238:	39000397 	strb	w23, [x28]
    a23c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    a240:	aa18037b 	orr	x27, x27, x24
    a244:	b5fffafb 	cbnz	x27, a1a0 <f0+0x90>
    a248:	d00000a0 	adrp	x0, 20000 <__data_start>
    a24c:	9101c018 	add	x24, x0, #0x70
    a250:	f94007e1 	ldr	x1, [sp, #8]
    a254:	f9001bff 	str	xzr, [sp, #48]
    a258:	f9418b00 	ldr	x0, [x24, #784]
    a25c:	eb01001f 	cmp	x0, x1
    a260:	540129e1 	b.ne	c79c <f0+0x268c>  // b.any
    a264:	90000020 	adrp	x0, e000 <_IO_stdin_used+0xc00>
    a268:	910143e1 	add	x1, sp, #0x50
    a26c:	f9400fe2 	ldr	x2, [sp, #24]
    a270:	f9018b02 	str	x2, [x24, #784]
    a274:	3dc08000 	ldr	q0, [x0, #512]
    a278:	52800020 	mov	w0, #0x1                   	// #1
    a27c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a280:	3d8017e0 	str	q0, [sp, #80]
    a284:	97ffeb80 	bl	5084 <fwp_data.part.0.constprop.0>
    a288:	97ffedde 	bl	5a00 <fwp_rc_fresh>
    a28c:	9101a3e1 	add	x1, sp, #0x68
    a290:	aa0003e2 	mov	x2, x0
    a294:	52800020 	mov	w0, #0x1                   	// #1
    a298:	a9068bf5 	stp	x21, x2, [sp, #104]
    a29c:	97ffeb7a 	bl	5084 <fwp_data.part.0.constprop.0>
    a2a0:	97ffedd8 	bl	5a00 <fwp_rc_fresh>
    a2a4:	aa0003e2 	mov	x2, x0
    a2a8:	90000023 	adrp	x3, e000 <_IO_stdin_used+0xc00>
    a2ac:	9101e3e1 	add	x1, sp, #0x78
    a2b0:	52800020 	mov	w0, #0x1                   	// #1
    a2b4:	f90043e2 	str	x2, [sp, #128]
    a2b8:	3dc08060 	ldr	q0, [x3, #512]
    a2bc:	fd003fe0 	str	d0, [sp, #120]
    a2c0:	97ffeb71 	bl	5084 <fwp_data.part.0.constprop.0>
    a2c4:	97ffedcf 	bl	5a00 <fwp_rc_fresh>
    a2c8:	aa0003e2 	mov	x2, x0
    a2cc:	910223e1 	add	x1, sp, #0x88
    a2d0:	52800020 	mov	w0, #0x1                   	// #1
    a2d4:	a9088bf5 	stp	x21, x2, [sp, #136]
    a2d8:	97ffeb6b 	bl	5084 <fwp_data.part.0.constprop.0>
    a2dc:	97ffedc9 	bl	5a00 <fwp_rc_fresh>
    a2e0:	aa0003e2 	mov	x2, x0
    a2e4:	90000023 	adrp	x3, e000 <_IO_stdin_used+0xc00>
    a2e8:	910263e1 	add	x1, sp, #0x98
    a2ec:	52800020 	mov	w0, #0x1                   	// #1
    a2f0:	f90053e2 	str	x2, [sp, #160]
    a2f4:	3dc08060 	ldr	q0, [x3, #512]
    a2f8:	fd004fe0 	str	d0, [sp, #152]
    a2fc:	97ffeb62 	bl	5084 <fwp_data.part.0.constprop.0>
    a300:	97ffedc0 	bl	5a00 <fwp_rc_fresh>
    a304:	aa0003e2 	mov	x2, x0
    a308:	9102a3e1 	add	x1, sp, #0xa8
    a30c:	52800020 	mov	w0, #0x1                   	// #1
    a310:	a90a8bf5 	stp	x21, x2, [sp, #168]
    a314:	97ffeb5c 	bl	5084 <fwp_data.part.0.constprop.0>
    a318:	91174283 	add	x3, x20, #0x5d0
    a31c:	aa0003f5 	mov	x21, x0
    a320:	f949d861 	ldr	x1, [x3, #5040]
    a324:	f949ec60 	ldr	x0, [x3, #5080]
    a328:	cb0102a1 	sub	x1, x21, x1
    a32c:	eb00403f 	cmp	x1, x0, lsl #16
    a330:	54000322 	b.cs	a394 <f0+0x284>  // b.hs, b.nlast
    a334:	d350fc22 	lsr	x2, x1, #16
    a338:	f949fc63 	ldr	x3, [x3, #5112]
    a33c:	8b020842 	add	x2, x2, x2, lsl #2
    a340:	d37df042 	lsl	x2, x2, #3
    a344:	8b020060 	add	x0, x3, x2
    a348:	f9401017 	ldr	x23, [x0, #32]
    a34c:	b4000257 	cbz	x23, a394 <f0+0x284>
    a350:	38626862 	ldrb	w2, [x3, x2]
    a354:	7100085f 	cmp	w2, #0x2
    a358:	540104c0 	b.eq	c3f0 <f0+0x22e0>  // b.none
    a35c:	7100045f 	cmp	w2, #0x1
    a360:	540001a1 	b.ne	a394 <f0+0x284>  // b.any
    a364:	29430002 	ldp	w2, w0, [x0, #24]
    a368:	92403c21 	and	x1, x1, #0xffff
    a36c:	9b027c21 	mul	x1, x1, x2
    a370:	d360fc21 	lsr	x1, x1, #32
    a374:	eb00003f 	cmp	x1, x0
    a378:	540000e2 	b.cs	a394 <f0+0x284>  // b.hs, b.nlast
    a37c:	8b0102f7 	add	x23, x23, x1
    a380:	394002e0 	ldrb	w0, [x23]
    a384:	7103fc1f 	cmp	w0, #0xff
    a388:	54011240 	b.eq	c5d0 <f0+0x24c0>  // b.none
    a38c:	52800020 	mov	w0, #0x1                   	// #1
    a390:	390002e0 	strb	w0, [x23]
    a394:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a398:	9102e3e1 	add	x1, sp, #0xb8
    a39c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a3a0:	52800020 	mov	w0, #0x1                   	// #1
    a3a4:	a90bd7e2 	stp	x2, x21, [sp, #184]
    a3a8:	97ffeb37 	bl	5084 <fwp_data.part.0.constprop.0>
    a3ac:	97ffed95 	bl	5a00 <fwp_rc_fresh>
    a3b0:	aa0003e2 	mov	x2, x0
    a3b4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a3b8:	910323e1 	add	x1, sp, #0xc8
    a3bc:	52800020 	mov	w0, #0x1                   	// #1
    a3c0:	a90c8be3 	stp	x3, x2, [sp, #200]
    a3c4:	97ffeb30 	bl	5084 <fwp_data.part.0.constprop.0>
    a3c8:	91174283 	add	x3, x20, #0x5d0
    a3cc:	aa0003f5 	mov	x21, x0
    a3d0:	f949d861 	ldr	x1, [x3, #5040]
    a3d4:	f949ec60 	ldr	x0, [x3, #5080]
    a3d8:	cb0102a1 	sub	x1, x21, x1
    a3dc:	eb00403f 	cmp	x1, x0, lsl #16
    a3e0:	54000322 	b.cs	a444 <f0+0x334>  // b.hs, b.nlast
    a3e4:	d350fc22 	lsr	x2, x1, #16
    a3e8:	f949fc63 	ldr	x3, [x3, #5112]
    a3ec:	8b020842 	add	x2, x2, x2, lsl #2
    a3f0:	d37df042 	lsl	x2, x2, #3
    a3f4:	8b020060 	add	x0, x3, x2
    a3f8:	f9401017 	ldr	x23, [x0, #32]
    a3fc:	b4000257 	cbz	x23, a444 <f0+0x334>
    a400:	38626862 	ldrb	w2, [x3, x2]
    a404:	7100085f 	cmp	w2, #0x2
    a408:	54010000 	b.eq	c408 <f0+0x22f8>  // b.none
    a40c:	7100045f 	cmp	w2, #0x1
    a410:	540001a1 	b.ne	a444 <f0+0x334>  // b.any
    a414:	29430002 	ldp	w2, w0, [x0, #24]
    a418:	92403c21 	and	x1, x1, #0xffff
    a41c:	9b027c21 	mul	x1, x1, x2
    a420:	d360fc21 	lsr	x1, x1, #32
    a424:	eb00003f 	cmp	x1, x0
    a428:	540000e2 	b.cs	a444 <f0+0x334>  // b.hs, b.nlast
    a42c:	8b0102f7 	add	x23, x23, x1
    a430:	394002e0 	ldrb	w0, [x23]
    a434:	7103fc1f 	cmp	w0, #0xff
    a438:	54010d20 	b.eq	c5dc <f0+0x24cc>  // b.none
    a43c:	52800020 	mov	w0, #0x1                   	// #1
    a440:	390002e0 	strb	w0, [x23]
    a444:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a448:	910363e1 	add	x1, sp, #0xd8
    a44c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a450:	52800020 	mov	w0, #0x1                   	// #1
    a454:	a90dd7e2 	stp	x2, x21, [sp, #216]
    a458:	97ffeb0b 	bl	5084 <fwp_data.part.0.constprop.0>
    a45c:	91174283 	add	x3, x20, #0x5d0
    a460:	aa0003f5 	mov	x21, x0
    a464:	f949d861 	ldr	x1, [x3, #5040]
    a468:	f949ec60 	ldr	x0, [x3, #5080]
    a46c:	cb0102a1 	sub	x1, x21, x1
    a470:	eb00403f 	cmp	x1, x0, lsl #16
    a474:	54000322 	b.cs	a4d8 <f0+0x3c8>  // b.hs, b.nlast
    a478:	d350fc22 	lsr	x2, x1, #16
    a47c:	f949fc63 	ldr	x3, [x3, #5112]
    a480:	8b020842 	add	x2, x2, x2, lsl #2
    a484:	d37df042 	lsl	x2, x2, #3
    a488:	8b020060 	add	x0, x3, x2
    a48c:	f9401017 	ldr	x23, [x0, #32]
    a490:	b4000257 	cbz	x23, a4d8 <f0+0x3c8>
    a494:	38626862 	ldrb	w2, [x3, x2]
    a498:	7100085f 	cmp	w2, #0x2
    a49c:	5400fb00 	b.eq	c3fc <f0+0x22ec>  // b.none
    a4a0:	7100045f 	cmp	w2, #0x1
    a4a4:	540001a1 	b.ne	a4d8 <f0+0x3c8>  // b.any
    a4a8:	29430002 	ldp	w2, w0, [x0, #24]
    a4ac:	92403c21 	and	x1, x1, #0xffff
    a4b0:	9b027c21 	mul	x1, x1, x2
    a4b4:	d360fc21 	lsr	x1, x1, #32
    a4b8:	eb00003f 	cmp	x1, x0
    a4bc:	540000e2 	b.cs	a4d8 <f0+0x3c8>  // b.hs, b.nlast
    a4c0:	8b0102f7 	add	x23, x23, x1
    a4c4:	394002e0 	ldrb	w0, [x23]
    a4c8:	7103fc1f 	cmp	w0, #0xff
    a4cc:	540108e0 	b.eq	c5e8 <f0+0x24d8>  // b.none
    a4d0:	52800020 	mov	w0, #0x1                   	// #1
    a4d4:	390002e0 	strb	w0, [x23]
    a4d8:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a4dc:	9103a3e1 	add	x1, sp, #0xe8
    a4e0:	52800020 	mov	w0, #0x1                   	// #1
    a4e4:	a90ed7e2 	stp	x2, x21, [sp, #232]
    a4e8:	97ffeae7 	bl	5084 <fwp_data.part.0.constprop.0>
    a4ec:	91174283 	add	x3, x20, #0x5d0
    a4f0:	aa0003f5 	mov	x21, x0
    a4f4:	f949d861 	ldr	x1, [x3, #5040]
    a4f8:	f949ec60 	ldr	x0, [x3, #5080]
    a4fc:	cb0102a1 	sub	x1, x21, x1
    a500:	eb00403f 	cmp	x1, x0, lsl #16
    a504:	54000322 	b.cs	a568 <f0+0x458>  // b.hs, b.nlast
    a508:	d350fc22 	lsr	x2, x1, #16
    a50c:	f949fc63 	ldr	x3, [x3, #5112]
    a510:	8b020842 	add	x2, x2, x2, lsl #2
    a514:	d37df042 	lsl	x2, x2, #3
    a518:	8b020060 	add	x0, x3, x2
    a51c:	f9401017 	ldr	x23, [x0, #32]
    a520:	b4000257 	cbz	x23, a568 <f0+0x458>
    a524:	38626862 	ldrb	w2, [x3, x2]
    a528:	7100085f 	cmp	w2, #0x2
    a52c:	5400f7a0 	b.eq	c420 <f0+0x2310>  // b.none
    a530:	7100045f 	cmp	w2, #0x1
    a534:	540001a1 	b.ne	a568 <f0+0x458>  // b.any
    a538:	29430002 	ldp	w2, w0, [x0, #24]
    a53c:	92403c21 	and	x1, x1, #0xffff
    a540:	9b027c21 	mul	x1, x1, x2
    a544:	d360fc21 	lsr	x1, x1, #32
    a548:	eb00003f 	cmp	x1, x0
    a54c:	540000e2 	b.cs	a568 <f0+0x458>  // b.hs, b.nlast
    a550:	8b0102f7 	add	x23, x23, x1
    a554:	394002e0 	ldrb	w0, [x23]
    a558:	7103fc1f 	cmp	w0, #0xff
    a55c:	540104c0 	b.eq	c5f4 <f0+0x24e4>  // b.none
    a560:	52800020 	mov	w0, #0x1                   	// #1
    a564:	390002e0 	strb	w0, [x23]
    a568:	9103e3e1 	add	x1, sp, #0xf8
    a56c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a570:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a574:	52800020 	mov	w0, #0x1                   	// #1
    a578:	a90fd7f7 	stp	x23, x21, [sp, #248]
    a57c:	97ffeac2 	bl	5084 <fwp_data.part.0.constprop.0>
    a580:	97ffed20 	bl	5a00 <fwp_rc_fresh>
    a584:	aa0003e2 	mov	x2, x0
    a588:	910423e1 	add	x1, sp, #0x108
    a58c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a590:	52800020 	mov	w0, #0x1                   	// #1
    a594:	a9108bf5 	stp	x21, x2, [sp, #264]
    a598:	97ffeabb 	bl	5084 <fwp_data.part.0.constprop.0>
    a59c:	97ffed19 	bl	5a00 <fwp_rc_fresh>
    a5a0:	aa0003e2 	mov	x2, x0
    a5a4:	910463e1 	add	x1, sp, #0x118
    a5a8:	52800020 	mov	w0, #0x1                   	// #1
    a5ac:	a9118bf7 	stp	x23, x2, [sp, #280]
    a5b0:	97ffeab5 	bl	5084 <fwp_data.part.0.constprop.0>
    a5b4:	97ffed13 	bl	5a00 <fwp_rc_fresh>
    a5b8:	aa0003e2 	mov	x2, x0
    a5bc:	9104a3e1 	add	x1, sp, #0x128
    a5c0:	52800020 	mov	w0, #0x1                   	// #1
    a5c4:	a9128bf5 	stp	x21, x2, [sp, #296]
    a5c8:	97ffeaaf 	bl	5084 <fwp_data.part.0.constprop.0>
    a5cc:	91174283 	add	x3, x20, #0x5d0
    a5d0:	aa0003f5 	mov	x21, x0
    a5d4:	f949d861 	ldr	x1, [x3, #5040]
    a5d8:	f949ec60 	ldr	x0, [x3, #5080]
    a5dc:	cb0102a1 	sub	x1, x21, x1
    a5e0:	eb00403f 	cmp	x1, x0, lsl #16
    a5e4:	54000322 	b.cs	a648 <f0+0x538>  // b.hs, b.nlast
    a5e8:	d350fc22 	lsr	x2, x1, #16
    a5ec:	f949fc63 	ldr	x3, [x3, #5112]
    a5f0:	8b020842 	add	x2, x2, x2, lsl #2
    a5f4:	d37df042 	lsl	x2, x2, #3
    a5f8:	8b020060 	add	x0, x3, x2
    a5fc:	f9401017 	ldr	x23, [x0, #32]
    a600:	b4000257 	cbz	x23, a648 <f0+0x538>
    a604:	38626862 	ldrb	w2, [x3, x2]
    a608:	7100085f 	cmp	w2, #0x2
    a60c:	5400f040 	b.eq	c414 <f0+0x2304>  // b.none
    a610:	7100045f 	cmp	w2, #0x1
    a614:	540001a1 	b.ne	a648 <f0+0x538>  // b.any
    a618:	29430002 	ldp	w2, w0, [x0, #24]
    a61c:	92403c21 	and	x1, x1, #0xffff
    a620:	9b027c21 	mul	x1, x1, x2
    a624:	d360fc21 	lsr	x1, x1, #32
    a628:	eb00003f 	cmp	x1, x0
    a62c:	540000e2 	b.cs	a648 <f0+0x538>  // b.hs, b.nlast
    a630:	8b0102f7 	add	x23, x23, x1
    a634:	394002e0 	ldrb	w0, [x23]
    a638:	7103fc1f 	cmp	w0, #0xff
    a63c:	5400fe20 	b.eq	c600 <f0+0x24f0>  // b.none
    a640:	52800020 	mov	w0, #0x1                   	// #1
    a644:	390002e0 	strb	w0, [x23]
    a648:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a64c:	9104e3e1 	add	x1, sp, #0x138
    a650:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a654:	52800020 	mov	w0, #0x1                   	// #1
    a658:	a913d7e2 	stp	x2, x21, [sp, #312]
    a65c:	97ffea8a 	bl	5084 <fwp_data.part.0.constprop.0>
    a660:	97ffece8 	bl	5a00 <fwp_rc_fresh>
    a664:	aa0003e2 	mov	x2, x0
    a668:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a66c:	910523e1 	add	x1, sp, #0x148
    a670:	52800020 	mov	w0, #0x1                   	// #1
    a674:	a9148be3 	stp	x3, x2, [sp, #328]
    a678:	97ffea83 	bl	5084 <fwp_data.part.0.constprop.0>
    a67c:	91174283 	add	x3, x20, #0x5d0
    a680:	aa0003f5 	mov	x21, x0
    a684:	f949d861 	ldr	x1, [x3, #5040]
    a688:	f949ec60 	ldr	x0, [x3, #5080]
    a68c:	cb0102a1 	sub	x1, x21, x1
    a690:	eb00403f 	cmp	x1, x0, lsl #16
    a694:	54000322 	b.cs	a6f8 <f0+0x5e8>  // b.hs, b.nlast
    a698:	d350fc22 	lsr	x2, x1, #16
    a69c:	f949fc63 	ldr	x3, [x3, #5112]
    a6a0:	8b020842 	add	x2, x2, x2, lsl #2
    a6a4:	d37df042 	lsl	x2, x2, #3
    a6a8:	8b020060 	add	x0, x3, x2
    a6ac:	f9401017 	ldr	x23, [x0, #32]
    a6b0:	b4000257 	cbz	x23, a6f8 <f0+0x5e8>
    a6b4:	38626862 	ldrb	w2, [x3, x2]
    a6b8:	7100085f 	cmp	w2, #0x2
    a6bc:	5400ebe0 	b.eq	c438 <f0+0x2328>  // b.none
    a6c0:	7100045f 	cmp	w2, #0x1
    a6c4:	540001a1 	b.ne	a6f8 <f0+0x5e8>  // b.any
    a6c8:	29430002 	ldp	w2, w0, [x0, #24]
    a6cc:	92403c21 	and	x1, x1, #0xffff
    a6d0:	9b027c21 	mul	x1, x1, x2
    a6d4:	d360fc21 	lsr	x1, x1, #32
    a6d8:	eb00003f 	cmp	x1, x0
    a6dc:	540000e2 	b.cs	a6f8 <f0+0x5e8>  // b.hs, b.nlast
    a6e0:	8b0102f7 	add	x23, x23, x1
    a6e4:	394002e0 	ldrb	w0, [x23]
    a6e8:	7103fc1f 	cmp	w0, #0xff
    a6ec:	5400f900 	b.eq	c60c <f0+0x24fc>  // b.none
    a6f0:	52800020 	mov	w0, #0x1                   	// #1
    a6f4:	390002e0 	strb	w0, [x23]
    a6f8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a6fc:	910563e1 	add	x1, sp, #0x158
    a700:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a704:	52800020 	mov	w0, #0x1                   	// #1
    a708:	a915d7e2 	stp	x2, x21, [sp, #344]
    a70c:	97ffea5e 	bl	5084 <fwp_data.part.0.constprop.0>
    a710:	97ffecbc 	bl	5a00 <fwp_rc_fresh>
    a714:	aa0003e2 	mov	x2, x0
    a718:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a71c:	9105a3e1 	add	x1, sp, #0x168
    a720:	52800020 	mov	w0, #0x1                   	// #1
    a724:	a9168be3 	stp	x3, x2, [sp, #360]
    a728:	97ffea57 	bl	5084 <fwp_data.part.0.constprop.0>
    a72c:	91174283 	add	x3, x20, #0x5d0
    a730:	aa0003f5 	mov	x21, x0
    a734:	f949d861 	ldr	x1, [x3, #5040]
    a738:	f949ec60 	ldr	x0, [x3, #5080]
    a73c:	cb0102a1 	sub	x1, x21, x1
    a740:	eb00403f 	cmp	x1, x0, lsl #16
    a744:	54000322 	b.cs	a7a8 <f0+0x698>  // b.hs, b.nlast
    a748:	d350fc22 	lsr	x2, x1, #16
    a74c:	f949fc63 	ldr	x3, [x3, #5112]
    a750:	8b020842 	add	x2, x2, x2, lsl #2
    a754:	d37df042 	lsl	x2, x2, #3
    a758:	8b020060 	add	x0, x3, x2
    a75c:	f9401017 	ldr	x23, [x0, #32]
    a760:	b4000257 	cbz	x23, a7a8 <f0+0x698>
    a764:	38626862 	ldrb	w2, [x3, x2]
    a768:	7100085f 	cmp	w2, #0x2
    a76c:	5400e600 	b.eq	c42c <f0+0x231c>  // b.none
    a770:	7100045f 	cmp	w2, #0x1
    a774:	540001a1 	b.ne	a7a8 <f0+0x698>  // b.any
    a778:	29430002 	ldp	w2, w0, [x0, #24]
    a77c:	92403c21 	and	x1, x1, #0xffff
    a780:	9b027c21 	mul	x1, x1, x2
    a784:	d360fc21 	lsr	x1, x1, #32
    a788:	eb00003f 	cmp	x1, x0
    a78c:	540000e2 	b.cs	a7a8 <f0+0x698>  // b.hs, b.nlast
    a790:	8b0102f7 	add	x23, x23, x1
    a794:	394002e0 	ldrb	w0, [x23]
    a798:	7103fc1f 	cmp	w0, #0xff
    a79c:	5400f3e0 	b.eq	c618 <f0+0x2508>  // b.none
    a7a0:	52800020 	mov	w0, #0x1                   	// #1
    a7a4:	390002e0 	strb	w0, [x23]
    a7a8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a7ac:	9105e3e1 	add	x1, sp, #0x178
    a7b0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a7b4:	52800020 	mov	w0, #0x1                   	// #1
    a7b8:	a917d7e2 	stp	x2, x21, [sp, #376]
    a7bc:	97ffea32 	bl	5084 <fwp_data.part.0.constprop.0>
    a7c0:	97ffec90 	bl	5a00 <fwp_rc_fresh>
    a7c4:	aa0003e2 	mov	x2, x0
    a7c8:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a7cc:	910623e1 	add	x1, sp, #0x188
    a7d0:	52800020 	mov	w0, #0x1                   	// #1
    a7d4:	a9188be3 	stp	x3, x2, [sp, #392]
    a7d8:	97ffea2b 	bl	5084 <fwp_data.part.0.constprop.0>
    a7dc:	91174283 	add	x3, x20, #0x5d0
    a7e0:	aa0003f5 	mov	x21, x0
    a7e4:	f949d861 	ldr	x1, [x3, #5040]
    a7e8:	f949ec60 	ldr	x0, [x3, #5080]
    a7ec:	cb0102a1 	sub	x1, x21, x1
    a7f0:	eb00403f 	cmp	x1, x0, lsl #16
    a7f4:	54000322 	b.cs	a858 <f0+0x748>  // b.hs, b.nlast
    a7f8:	d350fc22 	lsr	x2, x1, #16
    a7fc:	f949fc63 	ldr	x3, [x3, #5112]
    a800:	8b020842 	add	x2, x2, x2, lsl #2
    a804:	d37df042 	lsl	x2, x2, #3
    a808:	8b020060 	add	x0, x3, x2
    a80c:	f9401017 	ldr	x23, [x0, #32]
    a810:	b4000257 	cbz	x23, a858 <f0+0x748>
    a814:	38626862 	ldrb	w2, [x3, x2]
    a818:	7100085f 	cmp	w2, #0x2
    a81c:	5400e7a0 	b.eq	c510 <f0+0x2400>  // b.none
    a820:	7100045f 	cmp	w2, #0x1
    a824:	540001a1 	b.ne	a858 <f0+0x748>  // b.any
    a828:	29430002 	ldp	w2, w0, [x0, #24]
    a82c:	92403c21 	and	x1, x1, #0xffff
    a830:	9b027c21 	mul	x1, x1, x2
    a834:	d360fc21 	lsr	x1, x1, #32
    a838:	eb00003f 	cmp	x1, x0
    a83c:	540000e2 	b.cs	a858 <f0+0x748>  // b.hs, b.nlast
    a840:	8b0102f7 	add	x23, x23, x1
    a844:	394002e0 	ldrb	w0, [x23]
    a848:	7103fc1f 	cmp	w0, #0xff
    a84c:	5400eec0 	b.eq	c624 <f0+0x2514>  // b.none
    a850:	52800020 	mov	w0, #0x1                   	// #1
    a854:	390002e0 	strb	w0, [x23]
    a858:	910663e1 	add	x1, sp, #0x198
    a85c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a860:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a864:	52800020 	mov	w0, #0x1                   	// #1
    a868:	a919d7f7 	stp	x23, x21, [sp, #408]
    a86c:	97ffea06 	bl	5084 <fwp_data.part.0.constprop.0>
    a870:	97ffec64 	bl	5a00 <fwp_rc_fresh>
    a874:	aa0003e2 	mov	x2, x0
    a878:	9106a3e1 	add	x1, sp, #0x1a8
    a87c:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a880:	52800020 	mov	w0, #0x1                   	// #1
    a884:	a91a8bf5 	stp	x21, x2, [sp, #424]
    a888:	97ffe9ff 	bl	5084 <fwp_data.part.0.constprop.0>
    a88c:	97ffec5d 	bl	5a00 <fwp_rc_fresh>
    a890:	aa0003e2 	mov	x2, x0
    a894:	9106e3e1 	add	x1, sp, #0x1b8
    a898:	52800020 	mov	w0, #0x1                   	// #1
    a89c:	a91b8bf7 	stp	x23, x2, [sp, #440]
    a8a0:	97ffe9f9 	bl	5084 <fwp_data.part.0.constprop.0>
    a8a4:	97ffec57 	bl	5a00 <fwp_rc_fresh>
    a8a8:	aa0003e2 	mov	x2, x0
    a8ac:	910723e1 	add	x1, sp, #0x1c8
    a8b0:	52800020 	mov	w0, #0x1                   	// #1
    a8b4:	a91c8bf5 	stp	x21, x2, [sp, #456]
    a8b8:	97ffe9f3 	bl	5084 <fwp_data.part.0.constprop.0>
    a8bc:	91174283 	add	x3, x20, #0x5d0
    a8c0:	aa0003f5 	mov	x21, x0
    a8c4:	f949d861 	ldr	x1, [x3, #5040]
    a8c8:	f949ec60 	ldr	x0, [x3, #5080]
    a8cc:	cb0102a1 	sub	x1, x21, x1
    a8d0:	eb00403f 	cmp	x1, x0, lsl #16
    a8d4:	54000322 	b.cs	a938 <f0+0x828>  // b.hs, b.nlast
    a8d8:	d350fc22 	lsr	x2, x1, #16
    a8dc:	f949fc63 	ldr	x3, [x3, #5112]
    a8e0:	8b020842 	add	x2, x2, x2, lsl #2
    a8e4:	d37df042 	lsl	x2, x2, #3
    a8e8:	8b020060 	add	x0, x3, x2
    a8ec:	f9401017 	ldr	x23, [x0, #32]
    a8f0:	b4000257 	cbz	x23, a938 <f0+0x828>
    a8f4:	38626862 	ldrb	w2, [x3, x2]
    a8f8:	7100085f 	cmp	w2, #0x2
    a8fc:	5400e040 	b.eq	c504 <f0+0x23f4>  // b.none
    a900:	7100045f 	cmp	w2, #0x1
    a904:	540001a1 	b.ne	a938 <f0+0x828>  // b.any
    a908:	29430002 	ldp	w2, w0, [x0, #24]
    a90c:	92403c21 	and	x1, x1, #0xffff
    a910:	9b027c21 	mul	x1, x1, x2
    a914:	d360fc21 	lsr	x1, x1, #32
    a918:	eb00003f 	cmp	x1, x0
    a91c:	540000e2 	b.cs	a938 <f0+0x828>  // b.hs, b.nlast
    a920:	8b0102f7 	add	x23, x23, x1
    a924:	394002e0 	ldrb	w0, [x23]
    a928:	7103fc1f 	cmp	w0, #0xff
    a92c:	5400e820 	b.eq	c630 <f0+0x2520>  // b.none
    a930:	52800020 	mov	w0, #0x1                   	// #1
    a934:	390002e0 	strb	w0, [x23]
    a938:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a93c:	910763e1 	add	x1, sp, #0x1d8
    a940:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a944:	52800020 	mov	w0, #0x1                   	// #1
    a948:	a91dd7e2 	stp	x2, x21, [sp, #472]
    a94c:	97ffe9ce 	bl	5084 <fwp_data.part.0.constprop.0>
    a950:	97ffec2c 	bl	5a00 <fwp_rc_fresh>
    a954:	aa0003e2 	mov	x2, x0
    a958:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a95c:	9107a3e1 	add	x1, sp, #0x1e8
    a960:	52800020 	mov	w0, #0x1                   	// #1
    a964:	a91e8be3 	stp	x3, x2, [sp, #488]
    a968:	97ffe9c7 	bl	5084 <fwp_data.part.0.constprop.0>
    a96c:	91174283 	add	x3, x20, #0x5d0
    a970:	aa0003f5 	mov	x21, x0
    a974:	f949d861 	ldr	x1, [x3, #5040]
    a978:	f949ec60 	ldr	x0, [x3, #5080]
    a97c:	cb0102a1 	sub	x1, x21, x1
    a980:	eb00403f 	cmp	x1, x0, lsl #16
    a984:	54000322 	b.cs	a9e8 <f0+0x8d8>  // b.hs, b.nlast
    a988:	d350fc22 	lsr	x2, x1, #16
    a98c:	f949fc63 	ldr	x3, [x3, #5112]
    a990:	8b020842 	add	x2, x2, x2, lsl #2
    a994:	d37df042 	lsl	x2, x2, #3
    a998:	8b020060 	add	x0, x3, x2
    a99c:	f9401017 	ldr	x23, [x0, #32]
    a9a0:	b4000257 	cbz	x23, a9e8 <f0+0x8d8>
    a9a4:	38626862 	ldrb	w2, [x3, x2]
    a9a8:	7100085f 	cmp	w2, #0x2
    a9ac:	5400dbe0 	b.eq	c528 <f0+0x2418>  // b.none
    a9b0:	7100045f 	cmp	w2, #0x1
    a9b4:	540001a1 	b.ne	a9e8 <f0+0x8d8>  // b.any
    a9b8:	29430002 	ldp	w2, w0, [x0, #24]
    a9bc:	92403c21 	and	x1, x1, #0xffff
    a9c0:	9b027c21 	mul	x1, x1, x2
    a9c4:	d360fc21 	lsr	x1, x1, #32
    a9c8:	eb00003f 	cmp	x1, x0
    a9cc:	540000e2 	b.cs	a9e8 <f0+0x8d8>  // b.hs, b.nlast
    a9d0:	8b0102f7 	add	x23, x23, x1
    a9d4:	394002e0 	ldrb	w0, [x23]
    a9d8:	7103fc1f 	cmp	w0, #0xff
    a9dc:	5400e300 	b.eq	c63c <f0+0x252c>  // b.none
    a9e0:	52800020 	mov	w0, #0x1                   	// #1
    a9e4:	390002e0 	strb	w0, [x23]
    a9e8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a9ec:	9107e3e1 	add	x1, sp, #0x1f8
    a9f0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a9f4:	52800020 	mov	w0, #0x1                   	// #1
    a9f8:	a91fd7e2 	stp	x2, x21, [sp, #504]
    a9fc:	97ffe9a2 	bl	5084 <fwp_data.part.0.constprop.0>
    aa00:	97ffec00 	bl	5a00 <fwp_rc_fresh>
    aa04:	aa0003e2 	mov	x2, x0
    aa08:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aa0c:	910823e1 	add	x1, sp, #0x208
    aa10:	52800020 	mov	w0, #0x1                   	// #1
    aa14:	f90107e3 	str	x3, [sp, #520]
    aa18:	f9010be2 	str	x2, [sp, #528]
    aa1c:	97ffe99a 	bl	5084 <fwp_data.part.0.constprop.0>
    aa20:	91174283 	add	x3, x20, #0x5d0
    aa24:	aa0003f5 	mov	x21, x0
    aa28:	f949d861 	ldr	x1, [x3, #5040]
    aa2c:	f949ec60 	ldr	x0, [x3, #5080]
    aa30:	cb0102a1 	sub	x1, x21, x1
    aa34:	eb00403f 	cmp	x1, x0, lsl #16
    aa38:	54000322 	b.cs	aa9c <f0+0x98c>  // b.hs, b.nlast
    aa3c:	d350fc22 	lsr	x2, x1, #16
    aa40:	f949fc63 	ldr	x3, [x3, #5112]
    aa44:	8b020842 	add	x2, x2, x2, lsl #2
    aa48:	d37df042 	lsl	x2, x2, #3
    aa4c:	8b020060 	add	x0, x3, x2
    aa50:	f9401017 	ldr	x23, [x0, #32]
    aa54:	b4000257 	cbz	x23, aa9c <f0+0x98c>
    aa58:	38626862 	ldrb	w2, [x3, x2]
    aa5c:	7100085f 	cmp	w2, #0x2
    aa60:	5400d5e0 	b.eq	c51c <f0+0x240c>  // b.none
    aa64:	7100045f 	cmp	w2, #0x1
    aa68:	540001a1 	b.ne	aa9c <f0+0x98c>  // b.any
    aa6c:	29430002 	ldp	w2, w0, [x0, #24]
    aa70:	92403c21 	and	x1, x1, #0xffff
    aa74:	9b027c21 	mul	x1, x1, x2
    aa78:	d360fc21 	lsr	x1, x1, #32
    aa7c:	eb00003f 	cmp	x1, x0
    aa80:	540000e2 	b.cs	aa9c <f0+0x98c>  // b.hs, b.nlast
    aa84:	8b0102f7 	add	x23, x23, x1
    aa88:	394002e0 	ldrb	w0, [x23]
    aa8c:	7103fc1f 	cmp	w0, #0xff
    aa90:	5400ddc0 	b.eq	c648 <f0+0x2538>  // b.none
    aa94:	52800020 	mov	w0, #0x1                   	// #1
    aa98:	390002e0 	strb	w0, [x23]
    aa9c:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    aaa0:	910863e1 	add	x1, sp, #0x218
    aaa4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    aaa8:	52800020 	mov	w0, #0x1                   	// #1
    aaac:	f9010fe2 	str	x2, [sp, #536]
    aab0:	f90113f5 	str	x21, [sp, #544]
    aab4:	97ffe974 	bl	5084 <fwp_data.part.0.constprop.0>
    aab8:	97ffebd2 	bl	5a00 <fwp_rc_fresh>
    aabc:	aa0003e2 	mov	x2, x0
    aac0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    aac4:	9108a3e1 	add	x1, sp, #0x228
    aac8:	52800020 	mov	w0, #0x1                   	// #1
    aacc:	f90117e3 	str	x3, [sp, #552]
    aad0:	f9011be2 	str	x2, [sp, #560]
    aad4:	97ffe96c 	bl	5084 <fwp_data.part.0.constprop.0>
    aad8:	91174283 	add	x3, x20, #0x5d0
    aadc:	aa0003f5 	mov	x21, x0
    aae0:	f949d861 	ldr	x1, [x3, #5040]
    aae4:	f949ec60 	ldr	x0, [x3, #5080]
    aae8:	cb0102a1 	sub	x1, x21, x1
    aaec:	eb00403f 	cmp	x1, x0, lsl #16
    aaf0:	54000322 	b.cs	ab54 <f0+0xa44>  // b.hs, b.nlast
    aaf4:	d350fc22 	lsr	x2, x1, #16
    aaf8:	f949fc63 	ldr	x3, [x3, #5112]
    aafc:	8b020842 	add	x2, x2, x2, lsl #2
    ab00:	d37df042 	lsl	x2, x2, #3
    ab04:	8b020060 	add	x0, x3, x2
    ab08:	f9401017 	ldr	x23, [x0, #32]
    ab0c:	b4000257 	cbz	x23, ab54 <f0+0xa44>
    ab10:	38626862 	ldrb	w2, [x3, x2]
    ab14:	7100085f 	cmp	w2, #0x2
    ab18:	5400d140 	b.eq	c540 <f0+0x2430>  // b.none
    ab1c:	7100045f 	cmp	w2, #0x1
    ab20:	540001a1 	b.ne	ab54 <f0+0xa44>  // b.any
    ab24:	29430002 	ldp	w2, w0, [x0, #24]
    ab28:	92403c21 	and	x1, x1, #0xffff
    ab2c:	9b027c21 	mul	x1, x1, x2
    ab30:	d360fc21 	lsr	x1, x1, #32
    ab34:	eb00003f 	cmp	x1, x0
    ab38:	540000e2 	b.cs	ab54 <f0+0xa44>  // b.hs, b.nlast
    ab3c:	8b0102f7 	add	x23, x23, x1
    ab40:	394002e0 	ldrb	w0, [x23]
    ab44:	7103fc1f 	cmp	w0, #0xff
    ab48:	5400d860 	b.eq	c654 <f0+0x2544>  // b.none
    ab4c:	52800020 	mov	w0, #0x1                   	// #1
    ab50:	390002e0 	strb	w0, [x23]
    ab54:	9108e3e1 	add	x1, sp, #0x238
    ab58:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    ab5c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    ab60:	52800020 	mov	w0, #0x1                   	// #1
    ab64:	f9011ff7 	str	x23, [sp, #568]
    ab68:	f90123f5 	str	x21, [sp, #576]
    ab6c:	97ffe946 	bl	5084 <fwp_data.part.0.constprop.0>
    ab70:	97ffeba4 	bl	5a00 <fwp_rc_fresh>
    ab74:	aa0003e2 	mov	x2, x0
    ab78:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ab7c:	910923e1 	add	x1, sp, #0x248
    ab80:	52800020 	mov	w0, #0x1                   	// #1
    ab84:	f90127e3 	str	x3, [sp, #584]
    ab88:	f9012be2 	str	x2, [sp, #592]
    ab8c:	97ffe93e 	bl	5084 <fwp_data.part.0.constprop.0>
    ab90:	97ffeb9c 	bl	5a00 <fwp_rc_fresh>
    ab94:	aa0003e2 	mov	x2, x0
    ab98:	910963e1 	add	x1, sp, #0x258
    ab9c:	52800020 	mov	w0, #0x1                   	// #1
    aba0:	f9012ff7 	str	x23, [sp, #600]
    aba4:	f90133e2 	str	x2, [sp, #608]
    aba8:	97ffe937 	bl	5084 <fwp_data.part.0.constprop.0>
    abac:	91174283 	add	x3, x20, #0x5d0
    abb0:	aa0003f5 	mov	x21, x0
    abb4:	f949d861 	ldr	x1, [x3, #5040]
    abb8:	f949ec60 	ldr	x0, [x3, #5080]
    abbc:	cb0102a1 	sub	x1, x21, x1
    abc0:	eb00403f 	cmp	x1, x0, lsl #16
    abc4:	54000322 	b.cs	ac28 <f0+0xb18>  // b.hs, b.nlast
    abc8:	d350fc22 	lsr	x2, x1, #16
    abcc:	f949fc63 	ldr	x3, [x3, #5112]
    abd0:	8b020842 	add	x2, x2, x2, lsl #2
    abd4:	d37df042 	lsl	x2, x2, #3
    abd8:	8b020060 	add	x0, x3, x2
    abdc:	f9401017 	ldr	x23, [x0, #32]
    abe0:	b4000257 	cbz	x23, ac28 <f0+0xb18>
    abe4:	38626862 	ldrb	w2, [x3, x2]
    abe8:	7100085f 	cmp	w2, #0x2
    abec:	5400ca40 	b.eq	c534 <f0+0x2424>  // b.none
    abf0:	7100045f 	cmp	w2, #0x1
    abf4:	540001a1 	b.ne	ac28 <f0+0xb18>  // b.any
    abf8:	29430002 	ldp	w2, w0, [x0, #24]
    abfc:	92403c21 	and	x1, x1, #0xffff
    ac00:	9b027c21 	mul	x1, x1, x2
    ac04:	d360fc21 	lsr	x1, x1, #32
    ac08:	eb00003f 	cmp	x1, x0
    ac0c:	540000e2 	b.cs	ac28 <f0+0xb18>  // b.hs, b.nlast
    ac10:	8b0102f7 	add	x23, x23, x1
    ac14:	394002e0 	ldrb	w0, [x23]
    ac18:	7103fc1f 	cmp	w0, #0xff
    ac1c:	5400d220 	b.eq	c660 <f0+0x2550>  // b.none
    ac20:	52800020 	mov	w0, #0x1                   	// #1
    ac24:	390002e0 	strb	w0, [x23]
    ac28:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ac2c:	9109a3e1 	add	x1, sp, #0x268
    ac30:	52800020 	mov	w0, #0x1                   	// #1
    ac34:	f90137e2 	str	x2, [sp, #616]
    ac38:	f9013bf5 	str	x21, [sp, #624]
    ac3c:	97ffe912 	bl	5084 <fwp_data.part.0.constprop.0>
    ac40:	91174283 	add	x3, x20, #0x5d0
    ac44:	aa0003f5 	mov	x21, x0
    ac48:	f949d861 	ldr	x1, [x3, #5040]
    ac4c:	f949ec60 	ldr	x0, [x3, #5080]
    ac50:	cb0102a1 	sub	x1, x21, x1
    ac54:	eb00403f 	cmp	x1, x0, lsl #16
    ac58:	54000322 	b.cs	acbc <f0+0xbac>  // b.hs, b.nlast
    ac5c:	d350fc22 	lsr	x2, x1, #16
    ac60:	f949fc63 	ldr	x3, [x3, #5112]
    ac64:	8b020842 	add	x2, x2, x2, lsl #2
    ac68:	d37df042 	lsl	x2, x2, #3
    ac6c:	8b020060 	add	x0, x3, x2
    ac70:	f9401017 	ldr	x23, [x0, #32]
    ac74:	b4000257 	cbz	x23, acbc <f0+0xbac>
    ac78:	38626862 	ldrb	w2, [x3, x2]
    ac7c:	7100085f 	cmp	w2, #0x2
    ac80:	5400c6c0 	b.eq	c558 <f0+0x2448>  // b.none
    ac84:	7100045f 	cmp	w2, #0x1
    ac88:	540001a1 	b.ne	acbc <f0+0xbac>  // b.any
    ac8c:	29430002 	ldp	w2, w0, [x0, #24]
    ac90:	92403c21 	and	x1, x1, #0xffff
    ac94:	9b027c21 	mul	x1, x1, x2
    ac98:	d360fc21 	lsr	x1, x1, #32
    ac9c:	eb00003f 	cmp	x1, x0
    aca0:	540000e2 	b.cs	acbc <f0+0xbac>  // b.hs, b.nlast
    aca4:	8b0102f7 	add	x23, x23, x1
    aca8:	394002e0 	ldrb	w0, [x23]
    acac:	7103fc1f 	cmp	w0, #0xff
    acb0:	5400cde0 	b.eq	c66c <f0+0x255c>  // b.none
    acb4:	52800020 	mov	w0, #0x1                   	// #1
    acb8:	390002e0 	strb	w0, [x23]
    acbc:	9109e3e1 	add	x1, sp, #0x278
    acc0:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    acc4:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    acc8:	52800020 	mov	w0, #0x1                   	// #1
    accc:	f9013ff7 	str	x23, [sp, #632]
    acd0:	f90143f5 	str	x21, [sp, #640]
    acd4:	97ffe8ec 	bl	5084 <fwp_data.part.0.constprop.0>
    acd8:	97ffeb4a 	bl	5a00 <fwp_rc_fresh>
    acdc:	aa0003e2 	mov	x2, x0
    ace0:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    ace4:	910a23e1 	add	x1, sp, #0x288
    ace8:	52800020 	mov	w0, #0x1                   	// #1
    acec:	f90147e3 	str	x3, [sp, #648]
    acf0:	f9014be2 	str	x2, [sp, #656]
    acf4:	97ffe8e4 	bl	5084 <fwp_data.part.0.constprop.0>
    acf8:	97ffeb42 	bl	5a00 <fwp_rc_fresh>
    acfc:	aa0003e2 	mov	x2, x0
    ad00:	910a63e1 	add	x1, sp, #0x298
    ad04:	52800020 	mov	w0, #0x1                   	// #1
    ad08:	f9014ff7 	str	x23, [sp, #664]
    ad0c:	f90153e2 	str	x2, [sp, #672]
    ad10:	97ffe8dd 	bl	5084 <fwp_data.part.0.constprop.0>
    ad14:	91174283 	add	x3, x20, #0x5d0
    ad18:	aa0003f5 	mov	x21, x0
    ad1c:	f949d861 	ldr	x1, [x3, #5040]
    ad20:	f949ec60 	ldr	x0, [x3, #5080]
    ad24:	cb0102a1 	sub	x1, x21, x1
    ad28:	eb00403f 	cmp	x1, x0, lsl #16
    ad2c:	54000322 	b.cs	ad90 <f0+0xc80>  // b.hs, b.nlast
    ad30:	d350fc22 	lsr	x2, x1, #16
    ad34:	f949fc63 	ldr	x3, [x3, #5112]
    ad38:	8b020842 	add	x2, x2, x2, lsl #2
    ad3c:	d37df042 	lsl	x2, x2, #3
    ad40:	8b020060 	add	x0, x3, x2
    ad44:	f9401017 	ldr	x23, [x0, #32]
    ad48:	b4000257 	cbz	x23, ad90 <f0+0xc80>
    ad4c:	38626862 	ldrb	w2, [x3, x2]
    ad50:	7100085f 	cmp	w2, #0x2
    ad54:	5400bfc0 	b.eq	c54c <f0+0x243c>  // b.none
    ad58:	7100045f 	cmp	w2, #0x1
    ad5c:	540001a1 	b.ne	ad90 <f0+0xc80>  // b.any
    ad60:	29430002 	ldp	w2, w0, [x0, #24]
    ad64:	92403c21 	and	x1, x1, #0xffff
    ad68:	9b027c21 	mul	x1, x1, x2
    ad6c:	d360fc21 	lsr	x1, x1, #32
    ad70:	eb00003f 	cmp	x1, x0
    ad74:	540000e2 	b.cs	ad90 <f0+0xc80>  // b.hs, b.nlast
    ad78:	8b0102f7 	add	x23, x23, x1
    ad7c:	394002e0 	ldrb	w0, [x23]
    ad80:	7103fc1f 	cmp	w0, #0xff
    ad84:	5400c7a0 	b.eq	c678 <f0+0x2568>  // b.none
    ad88:	52800020 	mov	w0, #0x1                   	// #1
    ad8c:	390002e0 	strb	w0, [x23]
    ad90:	910aa3e1 	add	x1, sp, #0x2a8
    ad94:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ad98:	52800020 	mov	w0, #0x1                   	// #1
    ad9c:	f90157f7 	str	x23, [sp, #680]
    ada0:	f9015bf5 	str	x21, [sp, #688]
    ada4:	97ffe8b8 	bl	5084 <fwp_data.part.0.constprop.0>
    ada8:	97ffeb16 	bl	5a00 <fwp_rc_fresh>
    adac:	aa0003e2 	mov	x2, x0
    adb0:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    adb4:	910ae3e1 	add	x1, sp, #0x2b8
    adb8:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    adbc:	52800020 	mov	w0, #0x1                   	// #1
    adc0:	f9015fe3 	str	x3, [sp, #696]
    adc4:	f90163e2 	str	x2, [sp, #704]
    adc8:	97ffe8af 	bl	5084 <fwp_data.part.0.constprop.0>
    adcc:	97ffeb0d 	bl	5a00 <fwp_rc_fresh>
    add0:	aa0003e2 	mov	x2, x0
    add4:	910b23e1 	add	x1, sp, #0x2c8
    add8:	52800020 	mov	w0, #0x1                   	// #1
    addc:	f90167f7 	str	x23, [sp, #712]
    ade0:	f9016be2 	str	x2, [sp, #720]
    ade4:	97ffe8a8 	bl	5084 <fwp_data.part.0.constprop.0>
    ade8:	91174283 	add	x3, x20, #0x5d0
    adec:	aa0003f5 	mov	x21, x0
    adf0:	f949d861 	ldr	x1, [x3, #5040]
    adf4:	f949ec60 	ldr	x0, [x3, #5080]
    adf8:	cb0102a1 	sub	x1, x21, x1
    adfc:	eb00403f 	cmp	x1, x0, lsl #16
    ae00:	54000322 	b.cs	ae64 <f0+0xd54>  // b.hs, b.nlast
    ae04:	d350fc22 	lsr	x2, x1, #16
    ae08:	f949fc63 	ldr	x3, [x3, #5112]
    ae0c:	8b020842 	add	x2, x2, x2, lsl #2
    ae10:	d37df042 	lsl	x2, x2, #3
    ae14:	8b020060 	add	x0, x3, x2
    ae18:	f9401017 	ldr	x23, [x0, #32]
    ae1c:	b4000257 	cbz	x23, ae64 <f0+0xd54>
    ae20:	38626862 	ldrb	w2, [x3, x2]
    ae24:	7100085f 	cmp	w2, #0x2
    ae28:	5400ba40 	b.eq	c570 <f0+0x2460>  // b.none
    ae2c:	7100045f 	cmp	w2, #0x1
    ae30:	540001a1 	b.ne	ae64 <f0+0xd54>  // b.any
    ae34:	29430002 	ldp	w2, w0, [x0, #24]
    ae38:	92403c21 	and	x1, x1, #0xffff
    ae3c:	9b027c21 	mul	x1, x1, x2
    ae40:	d360fc21 	lsr	x1, x1, #32
    ae44:	eb00003f 	cmp	x1, x0
    ae48:	540000e2 	b.cs	ae64 <f0+0xd54>  // b.hs, b.nlast
    ae4c:	8b0102f7 	add	x23, x23, x1
    ae50:	394002e0 	ldrb	w0, [x23]
    ae54:	7103fc1f 	cmp	w0, #0xff
    ae58:	5400c160 	b.eq	c684 <f0+0x2574>  // b.none
    ae5c:	52800020 	mov	w0, #0x1                   	// #1
    ae60:	390002e0 	strb	w0, [x23]
    ae64:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ae68:	910b63e1 	add	x1, sp, #0x2d8
    ae6c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ae70:	52800020 	mov	w0, #0x1                   	// #1
    ae74:	f9016fe2 	str	x2, [sp, #728]
    ae78:	f90173f5 	str	x21, [sp, #736]
    ae7c:	97ffe882 	bl	5084 <fwp_data.part.0.constprop.0>
    ae80:	91174283 	add	x3, x20, #0x5d0
    ae84:	aa0003f5 	mov	x21, x0
    ae88:	f949d861 	ldr	x1, [x3, #5040]
    ae8c:	f949ec60 	ldr	x0, [x3, #5080]
    ae90:	cb0102a1 	sub	x1, x21, x1
    ae94:	eb00403f 	cmp	x1, x0, lsl #16
    ae98:	54000322 	b.cs	aefc <f0+0xdec>  // b.hs, b.nlast
    ae9c:	d350fc22 	lsr	x2, x1, #16
    aea0:	f949fc63 	ldr	x3, [x3, #5112]
    aea4:	8b020842 	add	x2, x2, x2, lsl #2
    aea8:	d37df042 	lsl	x2, x2, #3
    aeac:	8b020060 	add	x0, x3, x2
    aeb0:	f9401017 	ldr	x23, [x0, #32]
    aeb4:	b4000257 	cbz	x23, aefc <f0+0xdec>
    aeb8:	38626862 	ldrb	w2, [x3, x2]
    aebc:	7100085f 	cmp	w2, #0x2
    aec0:	5400b520 	b.eq	c564 <f0+0x2454>  // b.none
    aec4:	7100045f 	cmp	w2, #0x1
    aec8:	540001a1 	b.ne	aefc <f0+0xdec>  // b.any
    aecc:	29430002 	ldp	w2, w0, [x0, #24]
    aed0:	92403c21 	and	x1, x1, #0xffff
    aed4:	9b027c21 	mul	x1, x1, x2
    aed8:	d360fc21 	lsr	x1, x1, #32
    aedc:	eb00003f 	cmp	x1, x0
    aee0:	540000e2 	b.cs	aefc <f0+0xdec>  // b.hs, b.nlast
    aee4:	8b0102f7 	add	x23, x23, x1
    aee8:	394002e0 	ldrb	w0, [x23]
    aeec:	7103fc1f 	cmp	w0, #0xff
    aef0:	5400bd00 	b.eq	c690 <f0+0x2580>  // b.none
    aef4:	52800020 	mov	w0, #0x1                   	// #1
    aef8:	390002e0 	strb	w0, [x23]
    aefc:	910ba3e1 	add	x1, sp, #0x2e8
    af00:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    af04:	52800020 	mov	w0, #0x1                   	// #1
    af08:	f90177f7 	str	x23, [sp, #744]
    af0c:	f9017bf5 	str	x21, [sp, #752]
    af10:	97ffe85d 	bl	5084 <fwp_data.part.0.constprop.0>
    af14:	97ffeabb 	bl	5a00 <fwp_rc_fresh>
    af18:	aa0003e2 	mov	x2, x0
    af1c:	910be3e1 	add	x1, sp, #0x2f8
    af20:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    af24:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    af28:	52800020 	mov	w0, #0x1                   	// #1
    af2c:	f9017ff5 	str	x21, [sp, #760]
    af30:	f90183e2 	str	x2, [sp, #768]
    af34:	97ffe854 	bl	5084 <fwp_data.part.0.constprop.0>
    af38:	97ffeab2 	bl	5a00 <fwp_rc_fresh>
    af3c:	aa0003e2 	mov	x2, x0
    af40:	910c23e1 	add	x1, sp, #0x308
    af44:	52800020 	mov	w0, #0x1                   	// #1
    af48:	f90187f7 	str	x23, [sp, #776]
    af4c:	f9018be2 	str	x2, [sp, #784]
    af50:	97ffe84d 	bl	5084 <fwp_data.part.0.constprop.0>
    af54:	97ffeaab 	bl	5a00 <fwp_rc_fresh>
    af58:	aa0003e2 	mov	x2, x0
    af5c:	910c63e1 	add	x1, sp, #0x318
    af60:	52800020 	mov	w0, #0x1                   	// #1
    af64:	f9018ff5 	str	x21, [sp, #792]
    af68:	f90193e2 	str	x2, [sp, #800]
    af6c:	97ffe846 	bl	5084 <fwp_data.part.0.constprop.0>
    af70:	97ffeaa4 	bl	5a00 <fwp_rc_fresh>
    af74:	aa0003e2 	mov	x2, x0
    af78:	910ca3e1 	add	x1, sp, #0x328
    af7c:	52800020 	mov	w0, #0x1                   	// #1
    af80:	f90197f7 	str	x23, [sp, #808]
    af84:	f9019be2 	str	x2, [sp, #816]
    af88:	97ffe83f 	bl	5084 <fwp_data.part.0.constprop.0>
    af8c:	97ffea9d 	bl	5a00 <fwp_rc_fresh>
    af90:	aa0003e2 	mov	x2, x0
    af94:	910ce3e1 	add	x1, sp, #0x338
    af98:	52800020 	mov	w0, #0x1                   	// #1
    af9c:	f9019ff5 	str	x21, [sp, #824]
    afa0:	f901a3e2 	str	x2, [sp, #832]
    afa4:	97ffe838 	bl	5084 <fwp_data.part.0.constprop.0>
    afa8:	97ffea96 	bl	5a00 <fwp_rc_fresh>
    afac:	aa0003e2 	mov	x2, x0
    afb0:	910d23e1 	add	x1, sp, #0x348
    afb4:	52800020 	mov	w0, #0x1                   	// #1
    afb8:	f901a7f7 	str	x23, [sp, #840]
    afbc:	f901abe2 	str	x2, [sp, #848]
    afc0:	97ffe831 	bl	5084 <fwp_data.part.0.constprop.0>
    afc4:	97ffea8f 	bl	5a00 <fwp_rc_fresh>
    afc8:	aa0003e2 	mov	x2, x0
    afcc:	910d63e1 	add	x1, sp, #0x358
    afd0:	52800020 	mov	w0, #0x1                   	// #1
    afd4:	f901aff5 	str	x21, [sp, #856]
    afd8:	f901b3e2 	str	x2, [sp, #864]
    afdc:	97ffe82a 	bl	5084 <fwp_data.part.0.constprop.0>
    afe0:	97ffea88 	bl	5a00 <fwp_rc_fresh>
    afe4:	aa0003e2 	mov	x2, x0
    afe8:	910da3e1 	add	x1, sp, #0x368
    afec:	52800020 	mov	w0, #0x1                   	// #1
    aff0:	f901b7f7 	str	x23, [sp, #872]
    aff4:	f901bbe2 	str	x2, [sp, #880]
    aff8:	97ffe823 	bl	5084 <fwp_data.part.0.constprop.0>
    affc:	97ffea81 	bl	5a00 <fwp_rc_fresh>
    b000:	aa0003e2 	mov	x2, x0
    b004:	910de3e1 	add	x1, sp, #0x378
    b008:	52800020 	mov	w0, #0x1                   	// #1
    b00c:	f901bff5 	str	x21, [sp, #888]
    b010:	f901c3e2 	str	x2, [sp, #896]
    b014:	97ffe81c 	bl	5084 <fwp_data.part.0.constprop.0>
    b018:	97ffea7a 	bl	5a00 <fwp_rc_fresh>
    b01c:	aa0003e2 	mov	x2, x0
    b020:	910e23e1 	add	x1, sp, #0x388
    b024:	52800020 	mov	w0, #0x1                   	// #1
    b028:	f901c7f7 	str	x23, [sp, #904]
    b02c:	f901cbe2 	str	x2, [sp, #912]
    b030:	97ffe815 	bl	5084 <fwp_data.part.0.constprop.0>
    b034:	97ffea73 	bl	5a00 <fwp_rc_fresh>
    b038:	aa0003e2 	mov	x2, x0
    b03c:	910e63e1 	add	x1, sp, #0x398
    b040:	52800020 	mov	w0, #0x1                   	// #1
    b044:	f901cff5 	str	x21, [sp, #920]
    b048:	f901d3e2 	str	x2, [sp, #928]
    b04c:	97ffe80e 	bl	5084 <fwp_data.part.0.constprop.0>
    b050:	97ffea6c 	bl	5a00 <fwp_rc_fresh>
    b054:	aa0003e2 	mov	x2, x0
    b058:	910ea3e1 	add	x1, sp, #0x3a8
    b05c:	52800020 	mov	w0, #0x1                   	// #1
    b060:	f901d7f7 	str	x23, [sp, #936]
    b064:	f901dbe2 	str	x2, [sp, #944]
    b068:	97ffe807 	bl	5084 <fwp_data.part.0.constprop.0>
    b06c:	97ffea65 	bl	5a00 <fwp_rc_fresh>
    b070:	aa0003e2 	mov	x2, x0
    b074:	910ee3e1 	add	x1, sp, #0x3b8
    b078:	52800020 	mov	w0, #0x1                   	// #1
    b07c:	f901dff5 	str	x21, [sp, #952]
    b080:	f901e3e2 	str	x2, [sp, #960]
    b084:	97ffe800 	bl	5084 <fwp_data.part.0.constprop.0>
    b088:	97ffea5e 	bl	5a00 <fwp_rc_fresh>
    b08c:	aa0003e2 	mov	x2, x0
    b090:	910f23e1 	add	x1, sp, #0x3c8
    b094:	52800020 	mov	w0, #0x1                   	// #1
    b098:	f901e7f7 	str	x23, [sp, #968]
    b09c:	f901ebe2 	str	x2, [sp, #976]
    b0a0:	97ffe7f9 	bl	5084 <fwp_data.part.0.constprop.0>
    b0a4:	97ffea57 	bl	5a00 <fwp_rc_fresh>
    b0a8:	aa0003e2 	mov	x2, x0
    b0ac:	910f63e1 	add	x1, sp, #0x3d8
    b0b0:	52800020 	mov	w0, #0x1                   	// #1
    b0b4:	f901eff5 	str	x21, [sp, #984]
    b0b8:	f901f3e2 	str	x2, [sp, #992]
    b0bc:	97ffe7f2 	bl	5084 <fwp_data.part.0.constprop.0>
    b0c0:	91174283 	add	x3, x20, #0x5d0
    b0c4:	aa0003f5 	mov	x21, x0
    b0c8:	f949d861 	ldr	x1, [x3, #5040]
    b0cc:	f949ec60 	ldr	x0, [x3, #5080]
    b0d0:	cb0102a1 	sub	x1, x21, x1
    b0d4:	eb00403f 	cmp	x1, x0, lsl #16
    b0d8:	54000322 	b.cs	b13c <f0+0x102c>  // b.hs, b.nlast
    b0dc:	d350fc22 	lsr	x2, x1, #16
    b0e0:	f949fc63 	ldr	x3, [x3, #5112]
    b0e4:	8b020842 	add	x2, x2, x2, lsl #2
    b0e8:	d37df042 	lsl	x2, x2, #3
    b0ec:	8b020060 	add	x0, x3, x2
    b0f0:	f9401017 	ldr	x23, [x0, #32]
    b0f4:	b4000257 	cbz	x23, b13c <f0+0x102c>
    b0f8:	38626862 	ldrb	w2, [x3, x2]
    b0fc:	7100085f 	cmp	w2, #0x2
    b100:	5400a440 	b.eq	c588 <f0+0x2478>  // b.none
    b104:	7100045f 	cmp	w2, #0x1
    b108:	540001a1 	b.ne	b13c <f0+0x102c>  // b.any
    b10c:	29430002 	ldp	w2, w0, [x0, #24]
    b110:	92403c21 	and	x1, x1, #0xffff
    b114:	9b027c21 	mul	x1, x1, x2
    b118:	d360fc21 	lsr	x1, x1, #32
    b11c:	eb00003f 	cmp	x1, x0
    b120:	540000e2 	b.cs	b13c <f0+0x102c>  // b.hs, b.nlast
    b124:	8b0102f7 	add	x23, x23, x1
    b128:	394002e0 	ldrb	w0, [x23]
    b12c:	7103fc1f 	cmp	w0, #0xff
    b130:	5400ab60 	b.eq	c69c <f0+0x258c>  // b.none
    b134:	52800020 	mov	w0, #0x1                   	// #1
    b138:	390002e0 	strb	w0, [x23]
    b13c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b140:	910fa3e1 	add	x1, sp, #0x3e8
    b144:	52800020 	mov	w0, #0x1                   	// #1
    b148:	f901f7e2 	str	x2, [sp, #1000]
    b14c:	f901fbf5 	str	x21, [sp, #1008]
    b150:	97ffe7cd 	bl	5084 <fwp_data.part.0.constprop.0>
    b154:	91174283 	add	x3, x20, #0x5d0
    b158:	aa0003f5 	mov	x21, x0
    b15c:	f949d861 	ldr	x1, [x3, #5040]
    b160:	f949ec60 	ldr	x0, [x3, #5080]
    b164:	cb0102a1 	sub	x1, x21, x1
    b168:	eb00403f 	cmp	x1, x0, lsl #16
    b16c:	54000322 	b.cs	b1d0 <f0+0x10c0>  // b.hs, b.nlast
    b170:	d350fc22 	lsr	x2, x1, #16
    b174:	f949fc63 	ldr	x3, [x3, #5112]
    b178:	8b020842 	add	x2, x2, x2, lsl #2
    b17c:	d37df042 	lsl	x2, x2, #3
    b180:	8b020060 	add	x0, x3, x2
    b184:	f9401017 	ldr	x23, [x0, #32]
    b188:	b4000257 	cbz	x23, b1d0 <f0+0x10c0>
    b18c:	38626862 	ldrb	w2, [x3, x2]
    b190:	7100085f 	cmp	w2, #0x2
    b194:	54009f40 	b.eq	c57c <f0+0x246c>  // b.none
    b198:	7100045f 	cmp	w2, #0x1
    b19c:	540001a1 	b.ne	b1d0 <f0+0x10c0>  // b.any
    b1a0:	29430002 	ldp	w2, w0, [x0, #24]
    b1a4:	92403c21 	and	x1, x1, #0xffff
    b1a8:	9b027c21 	mul	x1, x1, x2
    b1ac:	d360fc21 	lsr	x1, x1, #32
    b1b0:	eb00003f 	cmp	x1, x0
    b1b4:	540000e2 	b.cs	b1d0 <f0+0x10c0>  // b.hs, b.nlast
    b1b8:	8b0102f7 	add	x23, x23, x1
    b1bc:	394002e0 	ldrb	w0, [x23]
    b1c0:	7103fc1f 	cmp	w0, #0xff
    b1c4:	5400a720 	b.eq	c6a8 <f0+0x2598>  // b.none
    b1c8:	52800020 	mov	w0, #0x1                   	// #1
    b1cc:	390002e0 	strb	w0, [x23]
    b1d0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b1d4:	910fe3e1 	add	x1, sp, #0x3f8
    b1d8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b1dc:	52800020 	mov	w0, #0x1                   	// #1
    b1e0:	f901ffe2 	str	x2, [sp, #1016]
    b1e4:	f90203f5 	str	x21, [sp, #1024]
    b1e8:	97ffe7a7 	bl	5084 <fwp_data.part.0.constprop.0>
    b1ec:	97ffea05 	bl	5a00 <fwp_rc_fresh>
    b1f0:	aa0003e2 	mov	x2, x0
    b1f4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b1f8:	911023e1 	add	x1, sp, #0x408
    b1fc:	52800020 	mov	w0, #0x1                   	// #1
    b200:	f90207e3 	str	x3, [sp, #1032]
    b204:	f9020be2 	str	x2, [sp, #1040]
    b208:	97ffe79f 	bl	5084 <fwp_data.part.0.constprop.0>
    b20c:	91174283 	add	x3, x20, #0x5d0
    b210:	aa0003f5 	mov	x21, x0
    b214:	f949d861 	ldr	x1, [x3, #5040]
    b218:	f949ec60 	ldr	x0, [x3, #5080]
    b21c:	cb0102a1 	sub	x1, x21, x1
    b220:	eb00403f 	cmp	x1, x0, lsl #16
    b224:	54000322 	b.cs	b288 <f0+0x1178>  // b.hs, b.nlast
    b228:	d350fc22 	lsr	x2, x1, #16
    b22c:	f949fc63 	ldr	x3, [x3, #5112]
    b230:	8b020842 	add	x2, x2, x2, lsl #2
    b234:	d37df042 	lsl	x2, x2, #3
    b238:	8b020060 	add	x0, x3, x2
    b23c:	f9401017 	ldr	x23, [x0, #32]
    b240:	b4000257 	cbz	x23, b288 <f0+0x1178>
    b244:	38626862 	ldrb	w2, [x3, x2]
    b248:	7100085f 	cmp	w2, #0x2
    b24c:	54009aa0 	b.eq	c5a0 <f0+0x2490>  // b.none
    b250:	7100045f 	cmp	w2, #0x1
    b254:	540001a1 	b.ne	b288 <f0+0x1178>  // b.any
    b258:	29430002 	ldp	w2, w0, [x0, #24]
    b25c:	92403c21 	and	x1, x1, #0xffff
    b260:	9b027c21 	mul	x1, x1, x2
    b264:	d360fc21 	lsr	x1, x1, #32
    b268:	eb00003f 	cmp	x1, x0
    b26c:	540000e2 	b.cs	b288 <f0+0x1178>  // b.hs, b.nlast
    b270:	8b0102f7 	add	x23, x23, x1
    b274:	394002e0 	ldrb	w0, [x23]
    b278:	7103fc1f 	cmp	w0, #0xff
    b27c:	5400a1c0 	b.eq	c6b4 <f0+0x25a4>  // b.none
    b280:	52800020 	mov	w0, #0x1                   	// #1
    b284:	390002e0 	strb	w0, [x23]
    b288:	911063e1 	add	x1, sp, #0x418
    b28c:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b290:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b294:	52800020 	mov	w0, #0x1                   	// #1
    b298:	f9020ff7 	str	x23, [sp, #1048]
    b29c:	f90213f5 	str	x21, [sp, #1056]
    b2a0:	97ffe779 	bl	5084 <fwp_data.part.0.constprop.0>
    b2a4:	97ffe9d7 	bl	5a00 <fwp_rc_fresh>
    b2a8:	aa0003e2 	mov	x2, x0
    b2ac:	9110a3e1 	add	x1, sp, #0x428
    b2b0:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b2b4:	52800020 	mov	w0, #0x1                   	// #1
    b2b8:	f90217f5 	str	x21, [sp, #1064]
    b2bc:	f9021be2 	str	x2, [sp, #1072]
    b2c0:	97ffe771 	bl	5084 <fwp_data.part.0.constprop.0>
    b2c4:	97ffe9cf 	bl	5a00 <fwp_rc_fresh>
    b2c8:	aa0003e2 	mov	x2, x0
    b2cc:	9110e3e1 	add	x1, sp, #0x438
    b2d0:	52800020 	mov	w0, #0x1                   	// #1
    b2d4:	f9021ff7 	str	x23, [sp, #1080]
    b2d8:	f90223e2 	str	x2, [sp, #1088]
    b2dc:	97ffe76a 	bl	5084 <fwp_data.part.0.constprop.0>
    b2e0:	97ffe9c8 	bl	5a00 <fwp_rc_fresh>
    b2e4:	aa0003e2 	mov	x2, x0
    b2e8:	911123e1 	add	x1, sp, #0x448
    b2ec:	52800020 	mov	w0, #0x1                   	// #1
    b2f0:	f90227f5 	str	x21, [sp, #1096]
    b2f4:	f9022be2 	str	x2, [sp, #1104]
    b2f8:	97ffe763 	bl	5084 <fwp_data.part.0.constprop.0>
    b2fc:	97ffe9c1 	bl	5a00 <fwp_rc_fresh>
    b300:	aa0003e2 	mov	x2, x0
    b304:	911163e1 	add	x1, sp, #0x458
    b308:	52800020 	mov	w0, #0x1                   	// #1
    b30c:	f9022ff7 	str	x23, [sp, #1112]
    b310:	f90233e2 	str	x2, [sp, #1120]
    b314:	97ffe75c 	bl	5084 <fwp_data.part.0.constprop.0>
    b318:	97ffe9ba 	bl	5a00 <fwp_rc_fresh>
    b31c:	aa0003e2 	mov	x2, x0
    b320:	9111a3e1 	add	x1, sp, #0x468
    b324:	52800020 	mov	w0, #0x1                   	// #1
    b328:	f90237f5 	str	x21, [sp, #1128]
    b32c:	f9023be2 	str	x2, [sp, #1136]
    b330:	97ffe755 	bl	5084 <fwp_data.part.0.constprop.0>
    b334:	91174283 	add	x3, x20, #0x5d0
    b338:	aa0003f5 	mov	x21, x0
    b33c:	f949d861 	ldr	x1, [x3, #5040]
    b340:	f949ec60 	ldr	x0, [x3, #5080]
    b344:	cb0102a1 	sub	x1, x21, x1
    b348:	eb00403f 	cmp	x1, x0, lsl #16
    b34c:	54000322 	b.cs	b3b0 <f0+0x12a0>  // b.hs, b.nlast
    b350:	d350fc22 	lsr	x2, x1, #16
    b354:	f949fc63 	ldr	x3, [x3, #5112]
    b358:	8b020842 	add	x2, x2, x2, lsl #2
    b35c:	d37df042 	lsl	x2, x2, #3
    b360:	8b020060 	add	x0, x3, x2
    b364:	f9401017 	ldr	x23, [x0, #32]
    b368:	b4000257 	cbz	x23, b3b0 <f0+0x12a0>
    b36c:	38626862 	ldrb	w2, [x3, x2]
    b370:	7100085f 	cmp	w2, #0x2
    b374:	54009100 	b.eq	c594 <f0+0x2484>  // b.none
    b378:	7100045f 	cmp	w2, #0x1
    b37c:	540001a1 	b.ne	b3b0 <f0+0x12a0>  // b.any
    b380:	29430002 	ldp	w2, w0, [x0, #24]
    b384:	92403c21 	and	x1, x1, #0xffff
    b388:	9b027c21 	mul	x1, x1, x2
    b38c:	d360fc21 	lsr	x1, x1, #32
    b390:	eb00003f 	cmp	x1, x0
    b394:	540000e2 	b.cs	b3b0 <f0+0x12a0>  // b.hs, b.nlast
    b398:	8b0102f7 	add	x23, x23, x1
    b39c:	394002e0 	ldrb	w0, [x23]
    b3a0:	7103fc1f 	cmp	w0, #0xff
    b3a4:	540098e0 	b.eq	c6c0 <f0+0x25b0>  // b.none
    b3a8:	52800020 	mov	w0, #0x1                   	// #1
    b3ac:	390002e0 	strb	w0, [x23]
    b3b0:	9111e3e1 	add	x1, sp, #0x478
    b3b4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b3b8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b3bc:	52800020 	mov	w0, #0x1                   	// #1
    b3c0:	f9023ff7 	str	x23, [sp, #1144]
    b3c4:	f90243f5 	str	x21, [sp, #1152]
    b3c8:	97ffe72f 	bl	5084 <fwp_data.part.0.constprop.0>
    b3cc:	97ffe98d 	bl	5a00 <fwp_rc_fresh>
    b3d0:	aa0003e2 	mov	x2, x0
    b3d4:	911223e1 	add	x1, sp, #0x488
    b3d8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b3dc:	52800020 	mov	w0, #0x1                   	// #1
    b3e0:	f90247f5 	str	x21, [sp, #1160]
    b3e4:	f9024be2 	str	x2, [sp, #1168]
    b3e8:	97ffe727 	bl	5084 <fwp_data.part.0.constprop.0>
    b3ec:	97ffe985 	bl	5a00 <fwp_rc_fresh>
    b3f0:	aa0003e2 	mov	x2, x0
    b3f4:	911263e1 	add	x1, sp, #0x498
    b3f8:	52800020 	mov	w0, #0x1                   	// #1
    b3fc:	f9024ff7 	str	x23, [sp, #1176]
    b400:	f90253e2 	str	x2, [sp, #1184]
    b404:	97ffe720 	bl	5084 <fwp_data.part.0.constprop.0>
    b408:	97ffe97e 	bl	5a00 <fwp_rc_fresh>
    b40c:	aa0003e2 	mov	x2, x0
    b410:	9112a3e1 	add	x1, sp, #0x4a8
    b414:	52800020 	mov	w0, #0x1                   	// #1
    b418:	f90257f5 	str	x21, [sp, #1192]
    b41c:	f9025be2 	str	x2, [sp, #1200]
    b420:	97ffe719 	bl	5084 <fwp_data.part.0.constprop.0>
    b424:	91174283 	add	x3, x20, #0x5d0
    b428:	aa0003f5 	mov	x21, x0
    b42c:	f949d861 	ldr	x1, [x3, #5040]
    b430:	f949ec60 	ldr	x0, [x3, #5080]
    b434:	cb0102a1 	sub	x1, x21, x1
    b438:	eb00403f 	cmp	x1, x0, lsl #16
    b43c:	54000322 	b.cs	b4a0 <f0+0x1390>  // b.hs, b.nlast
    b440:	d350fc22 	lsr	x2, x1, #16
    b444:	f949fc63 	ldr	x3, [x3, #5112]
    b448:	8b020842 	add	x2, x2, x2, lsl #2
    b44c:	d37df042 	lsl	x2, x2, #3
    b450:	8b020060 	add	x0, x3, x2
    b454:	f9401017 	ldr	x23, [x0, #32]
    b458:	b4000257 	cbz	x23, b4a0 <f0+0x1390>
    b45c:	38626862 	ldrb	w2, [x3, x2]
    b460:	7100085f 	cmp	w2, #0x2
    b464:	54008aa0 	b.eq	c5b8 <f0+0x24a8>  // b.none
    b468:	7100045f 	cmp	w2, #0x1
    b46c:	540001a1 	b.ne	b4a0 <f0+0x1390>  // b.any
    b470:	29430002 	ldp	w2, w0, [x0, #24]
    b474:	92403c21 	and	x1, x1, #0xffff
    b478:	9b027c21 	mul	x1, x1, x2
    b47c:	d360fc21 	lsr	x1, x1, #32
    b480:	eb00003f 	cmp	x1, x0
    b484:	540000e2 	b.cs	b4a0 <f0+0x1390>  // b.hs, b.nlast
    b488:	8b0102f7 	add	x23, x23, x1
    b48c:	394002e0 	ldrb	w0, [x23]
    b490:	7103fc1f 	cmp	w0, #0xff
    b494:	540091c0 	b.eq	c6cc <f0+0x25bc>  // b.none
    b498:	52800020 	mov	w0, #0x1                   	// #1
    b49c:	390002e0 	strb	w0, [x23]
    b4a0:	9112e3e1 	add	x1, sp, #0x4b8
    b4a4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b4a8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b4ac:	52800020 	mov	w0, #0x1                   	// #1
    b4b0:	f9025ff7 	str	x23, [sp, #1208]
    b4b4:	f90263f5 	str	x21, [sp, #1216]
    b4b8:	97ffe6f3 	bl	5084 <fwp_data.part.0.constprop.0>
    b4bc:	97ffe951 	bl	5a00 <fwp_rc_fresh>
    b4c0:	aa0003e2 	mov	x2, x0
    b4c4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    b4c8:	911323e1 	add	x1, sp, #0x4c8
    b4cc:	52800020 	mov	w0, #0x1                   	// #1
    b4d0:	f90267e3 	str	x3, [sp, #1224]
    b4d4:	f9026be2 	str	x2, [sp, #1232]
    b4d8:	97ffe6eb 	bl	5084 <fwp_data.part.0.constprop.0>
    b4dc:	97ffe949 	bl	5a00 <fwp_rc_fresh>
    b4e0:	aa0003e2 	mov	x2, x0
    b4e4:	911363e1 	add	x1, sp, #0x4d8
    b4e8:	52800020 	mov	w0, #0x1                   	// #1
    b4ec:	f9026ff7 	str	x23, [sp, #1240]
    b4f0:	f90273e2 	str	x2, [sp, #1248]
    b4f4:	97ffe6e4 	bl	5084 <fwp_data.part.0.constprop.0>
    b4f8:	91174283 	add	x3, x20, #0x5d0
    b4fc:	aa0003f7 	mov	x23, x0
    b500:	f949d861 	ldr	x1, [x3, #5040]
    b504:	f949ec60 	ldr	x0, [x3, #5080]
    b508:	cb0102e1 	sub	x1, x23, x1
    b50c:	eb00403f 	cmp	x1, x0, lsl #16
    b510:	54000322 	b.cs	b574 <f0+0x1464>  // b.hs, b.nlast
    b514:	d350fc22 	lsr	x2, x1, #16
    b518:	f949fc63 	ldr	x3, [x3, #5112]
    b51c:	8b020842 	add	x2, x2, x2, lsl #2
    b520:	d37df042 	lsl	x2, x2, #3
    b524:	8b020060 	add	x0, x3, x2
    b528:	f9401015 	ldr	x21, [x0, #32]
    b52c:	b4000255 	cbz	x21, b574 <f0+0x1464>
    b530:	38626862 	ldrb	w2, [x3, x2]
    b534:	7100085f 	cmp	w2, #0x2
    b538:	540083a0 	b.eq	c5ac <f0+0x249c>  // b.none
    b53c:	7100045f 	cmp	w2, #0x1
    b540:	540001a1 	b.ne	b574 <f0+0x1464>  // b.any
    b544:	29430002 	ldp	w2, w0, [x0, #24]
    b548:	92403c21 	and	x1, x1, #0xffff
    b54c:	9b027c21 	mul	x1, x1, x2
    b550:	d360fc21 	lsr	x1, x1, #32
    b554:	eb00003f 	cmp	x1, x0
    b558:	540000e2 	b.cs	b574 <f0+0x1464>  // b.hs, b.nlast
    b55c:	8b0102b5 	add	x21, x21, x1
    b560:	394002a0 	ldrb	w0, [x21]
    b564:	7103fc1f 	cmp	w0, #0xff
    b568:	54008b80 	b.eq	c6d8 <f0+0x25c8>  // b.none
    b56c:	52800020 	mov	w0, #0x1                   	// #1
    b570:	390002a0 	strb	w0, [x21]
    b574:	9113a3e1 	add	x1, sp, #0x4e8
    b578:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b57c:	52800020 	mov	w0, #0x1                   	// #1
    b580:	f90277f5 	str	x21, [sp, #1256]
    b584:	f9027bf7 	str	x23, [sp, #1264]
    b588:	97ffe6bf 	bl	5084 <fwp_data.part.0.constprop.0>
    b58c:	97ffe91d 	bl	5a00 <fwp_rc_fresh>
    b590:	aa0003e2 	mov	x2, x0
    b594:	9113e3e1 	add	x1, sp, #0x4f8
    b598:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b59c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b5a0:	52800020 	mov	w0, #0x1                   	// #1
    b5a4:	f9027ff7 	str	x23, [sp, #1272]
    b5a8:	f90283e2 	str	x2, [sp, #1280]
    b5ac:	97ffe6b6 	bl	5084 <fwp_data.part.0.constprop.0>
    b5b0:	97ffe914 	bl	5a00 <fwp_rc_fresh>
    b5b4:	aa0003e2 	mov	x2, x0
    b5b8:	911423e1 	add	x1, sp, #0x508
    b5bc:	52800020 	mov	w0, #0x1                   	// #1
    b5c0:	f90287f5 	str	x21, [sp, #1288]
    b5c4:	f9028be2 	str	x2, [sp, #1296]
    b5c8:	97ffe6af 	bl	5084 <fwp_data.part.0.constprop.0>
    b5cc:	97ffe90d 	bl	5a00 <fwp_rc_fresh>
    b5d0:	aa0003e2 	mov	x2, x0
    b5d4:	911463e1 	add	x1, sp, #0x518
    b5d8:	52800020 	mov	w0, #0x1                   	// #1
    b5dc:	f9028ff7 	str	x23, [sp, #1304]
    b5e0:	f90293e2 	str	x2, [sp, #1312]
    b5e4:	97ffe6a8 	bl	5084 <fwp_data.part.0.constprop.0>
    b5e8:	97ffe906 	bl	5a00 <fwp_rc_fresh>
    b5ec:	aa0003e2 	mov	x2, x0
    b5f0:	9114a3e1 	add	x1, sp, #0x528
    b5f4:	52800020 	mov	w0, #0x1                   	// #1
    b5f8:	f90297f5 	str	x21, [sp, #1320]
    b5fc:	f9029be2 	str	x2, [sp, #1328]
    b600:	97ffe6a1 	bl	5084 <fwp_data.part.0.constprop.0>
    b604:	97ffe8ff 	bl	5a00 <fwp_rc_fresh>
    b608:	aa0003e2 	mov	x2, x0
    b60c:	9114e3e1 	add	x1, sp, #0x538
    b610:	52800020 	mov	w0, #0x1                   	// #1
    b614:	f9029ff7 	str	x23, [sp, #1336]
    b618:	f902a3e2 	str	x2, [sp, #1344]
    b61c:	97ffe69a 	bl	5084 <fwp_data.part.0.constprop.0>
    b620:	97ffe8f8 	bl	5a00 <fwp_rc_fresh>
    b624:	aa0003e2 	mov	x2, x0
    b628:	911523e1 	add	x1, sp, #0x548
    b62c:	52800020 	mov	w0, #0x1                   	// #1
    b630:	f902a7f5 	str	x21, [sp, #1352]
    b634:	f902abe2 	str	x2, [sp, #1360]
    b638:	97ffe693 	bl	5084 <fwp_data.part.0.constprop.0>
    b63c:	97ffe8f1 	bl	5a00 <fwp_rc_fresh>
    b640:	aa0003e2 	mov	x2, x0
    b644:	911563e1 	add	x1, sp, #0x558
    b648:	52800020 	mov	w0, #0x1                   	// #1
    b64c:	f902aff7 	str	x23, [sp, #1368]
    b650:	f902b3e2 	str	x2, [sp, #1376]
    b654:	97ffe68c 	bl	5084 <fwp_data.part.0.constprop.0>
    b658:	97ffe8ea 	bl	5a00 <fwp_rc_fresh>
    b65c:	aa0003e2 	mov	x2, x0
    b660:	9115a3e1 	add	x1, sp, #0x568
    b664:	52800020 	mov	w0, #0x1                   	// #1
    b668:	f902b7f5 	str	x21, [sp, #1384]
    b66c:	f902bbe2 	str	x2, [sp, #1392]
    b670:	97ffe685 	bl	5084 <fwp_data.part.0.constprop.0>
    b674:	91174283 	add	x3, x20, #0x5d0
    b678:	aa0003f7 	mov	x23, x0
    b67c:	f949d861 	ldr	x1, [x3, #5040]
    b680:	f949ec60 	ldr	x0, [x3, #5080]
    b684:	cb0102e1 	sub	x1, x23, x1
    b688:	eb00403f 	cmp	x1, x0, lsl #16
    b68c:	54000322 	b.cs	b6f0 <f0+0x15e0>  // b.hs, b.nlast
    b690:	d350fc22 	lsr	x2, x1, #16
    b694:	f949fc63 	ldr	x3, [x3, #5112]
    b698:	8b020842 	add	x2, x2, x2, lsl #2
    b69c:	d37df042 	lsl	x2, x2, #3
    b6a0:	8b020060 	add	x0, x3, x2
    b6a4:	f9401015 	ldr	x21, [x0, #32]
    b6a8:	b4000255 	cbz	x21, b6f0 <f0+0x15e0>
    b6ac:	38626862 	ldrb	w2, [x3, x2]
    b6b0:	7100085f 	cmp	w2, #0x2
    b6b4:	54006ce0 	b.eq	c450 <f0+0x2340>  // b.none
    b6b8:	7100045f 	cmp	w2, #0x1
    b6bc:	540001a1 	b.ne	b6f0 <f0+0x15e0>  // b.any
    b6c0:	29430002 	ldp	w2, w0, [x0, #24]
    b6c4:	92403c21 	and	x1, x1, #0xffff
    b6c8:	9b027c21 	mul	x1, x1, x2
    b6cc:	d360fc21 	lsr	x1, x1, #32
    b6d0:	eb00003f 	cmp	x1, x0
    b6d4:	540000e2 	b.cs	b6f0 <f0+0x15e0>  // b.hs, b.nlast
    b6d8:	8b0102b5 	add	x21, x21, x1
    b6dc:	394002a0 	ldrb	w0, [x21]
    b6e0:	7103fc1f 	cmp	w0, #0xff
    b6e4:	54008000 	b.eq	c6e4 <f0+0x25d4>  // b.none
    b6e8:	52800020 	mov	w0, #0x1                   	// #1
    b6ec:	390002a0 	strb	w0, [x21]
    b6f0:	9115e3e1 	add	x1, sp, #0x578
    b6f4:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b6f8:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b6fc:	52800020 	mov	w0, #0x1                   	// #1
    b700:	f902bff5 	str	x21, [sp, #1400]
    b704:	f902c3f7 	str	x23, [sp, #1408]
    b708:	97ffe65f 	bl	5084 <fwp_data.part.0.constprop.0>
    b70c:	97ffe8bd 	bl	5a00 <fwp_rc_fresh>
    b710:	aa0003e2 	mov	x2, x0
    b714:	911623e1 	add	x1, sp, #0x588
    b718:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b71c:	52800020 	mov	w0, #0x1                   	// #1
    b720:	f902c7f7 	str	x23, [sp, #1416]
    b724:	f902cbe2 	str	x2, [sp, #1424]
    b728:	97ffe657 	bl	5084 <fwp_data.part.0.constprop.0>
    b72c:	97ffe8b5 	bl	5a00 <fwp_rc_fresh>
    b730:	aa0003e2 	mov	x2, x0
    b734:	911663e1 	add	x1, sp, #0x598
    b738:	52800020 	mov	w0, #0x1                   	// #1
    b73c:	f902cff5 	str	x21, [sp, #1432]
    b740:	f902d3e2 	str	x2, [sp, #1440]
    b744:	97ffe650 	bl	5084 <fwp_data.part.0.constprop.0>
    b748:	97ffe8ae 	bl	5a00 <fwp_rc_fresh>
    b74c:	aa0003e2 	mov	x2, x0
    b750:	9116a3e1 	add	x1, sp, #0x5a8
    b754:	52800020 	mov	w0, #0x1                   	// #1
    b758:	f902d7f7 	str	x23, [sp, #1448]
    b75c:	f902dbe2 	str	x2, [sp, #1456]
    b760:	97ffe649 	bl	5084 <fwp_data.part.0.constprop.0>
    b764:	97ffe8a7 	bl	5a00 <fwp_rc_fresh>
    b768:	aa0003e2 	mov	x2, x0
    b76c:	9116e3e1 	add	x1, sp, #0x5b8
    b770:	52800020 	mov	w0, #0x1                   	// #1
    b774:	f902dff5 	str	x21, [sp, #1464]
    b778:	f902e3e2 	str	x2, [sp, #1472]
    b77c:	97ffe642 	bl	5084 <fwp_data.part.0.constprop.0>
    b780:	97ffe8a0 	bl	5a00 <fwp_rc_fresh>
    b784:	aa0003e2 	mov	x2, x0
    b788:	911723e1 	add	x1, sp, #0x5c8
    b78c:	52800020 	mov	w0, #0x1                   	// #1
    b790:	f902e7f7 	str	x23, [sp, #1480]
    b794:	f902ebe2 	str	x2, [sp, #1488]
    b798:	97ffe63b 	bl	5084 <fwp_data.part.0.constprop.0>
    b79c:	97ffe899 	bl	5a00 <fwp_rc_fresh>
    b7a0:	aa0003e2 	mov	x2, x0
    b7a4:	911763e1 	add	x1, sp, #0x5d8
    b7a8:	52800020 	mov	w0, #0x1                   	// #1
    b7ac:	f902eff5 	str	x21, [sp, #1496]
    b7b0:	f902f3e2 	str	x2, [sp, #1504]
    b7b4:	97ffe634 	bl	5084 <fwp_data.part.0.constprop.0>
    b7b8:	91174283 	add	x3, x20, #0x5d0
    b7bc:	aa0003f5 	mov	x21, x0
    b7c0:	f949d861 	ldr	x1, [x3, #5040]
    b7c4:	f949ec60 	ldr	x0, [x3, #5080]
    b7c8:	cb0102a1 	sub	x1, x21, x1
    b7cc:	eb00403f 	cmp	x1, x0, lsl #16
    b7d0:	54000322 	b.cs	b834 <f0+0x1724>  // b.hs, b.nlast
    b7d4:	d350fc22 	lsr	x2, x1, #16
    b7d8:	f949fc63 	ldr	x3, [x3, #5112]
    b7dc:	8b020842 	add	x2, x2, x2, lsl #2
    b7e0:	d37df042 	lsl	x2, x2, #3
    b7e4:	8b020060 	add	x0, x3, x2
    b7e8:	f9401017 	ldr	x23, [x0, #32]
    b7ec:	b4000257 	cbz	x23, b834 <f0+0x1724>
    b7f0:	38626862 	ldrb	w2, [x3, x2]
    b7f4:	7100085f 	cmp	w2, #0x2
    b7f8:	54006260 	b.eq	c444 <f0+0x2334>  // b.none
    b7fc:	7100045f 	cmp	w2, #0x1
    b800:	540001a1 	b.ne	b834 <f0+0x1724>  // b.any
    b804:	29430002 	ldp	w2, w0, [x0, #24]
    b808:	92403c21 	and	x1, x1, #0xffff
    b80c:	9b027c21 	mul	x1, x1, x2
    b810:	d360fc21 	lsr	x1, x1, #32
    b814:	eb00003f 	cmp	x1, x0
    b818:	540000e2 	b.cs	b834 <f0+0x1724>  // b.hs, b.nlast
    b81c:	8b0102f7 	add	x23, x23, x1
    b820:	394002e0 	ldrb	w0, [x23]
    b824:	7103fc1f 	cmp	w0, #0xff
    b828:	54007640 	b.eq	c6f0 <f0+0x25e0>  // b.none
    b82c:	52800020 	mov	w0, #0x1                   	// #1
    b830:	390002e0 	strb	w0, [x23]
    b834:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b838:	9117a3e1 	add	x1, sp, #0x5e8
    b83c:	52800020 	mov	w0, #0x1                   	// #1
    b840:	f902f7e2 	str	x2, [sp, #1512]
    b844:	f902fbf5 	str	x21, [sp, #1520]
    b848:	97ffe60f 	bl	5084 <fwp_data.part.0.constprop.0>
    b84c:	91174283 	add	x3, x20, #0x5d0
    b850:	aa0003f7 	mov	x23, x0
    b854:	f949d861 	ldr	x1, [x3, #5040]
    b858:	f949ec60 	ldr	x0, [x3, #5080]
    b85c:	cb0102e1 	sub	x1, x23, x1
    b860:	eb00403f 	cmp	x1, x0, lsl #16
    b864:	54000322 	b.cs	b8c8 <f0+0x17b8>  // b.hs, b.nlast
    b868:	d350fc22 	lsr	x2, x1, #16
    b86c:	f949fc63 	ldr	x3, [x3, #5112]
    b870:	8b020842 	add	x2, x2, x2, lsl #2
    b874:	d37df042 	lsl	x2, x2, #3
    b878:	8b020060 	add	x0, x3, x2
    b87c:	f9401015 	ldr	x21, [x0, #32]
    b880:	b4000255 	cbz	x21, b8c8 <f0+0x17b8>
    b884:	38626862 	ldrb	w2, [x3, x2]
    b888:	7100085f 	cmp	w2, #0x2
    b88c:	54005ee0 	b.eq	c468 <f0+0x2358>  // b.none
    b890:	7100045f 	cmp	w2, #0x1
    b894:	540001a1 	b.ne	b8c8 <f0+0x17b8>  // b.any
    b898:	29430002 	ldp	w2, w0, [x0, #24]
    b89c:	92403c21 	and	x1, x1, #0xffff
    b8a0:	9b027c21 	mul	x1, x1, x2
    b8a4:	d360fc21 	lsr	x1, x1, #32
    b8a8:	eb00003f 	cmp	x1, x0
    b8ac:	540000e2 	b.cs	b8c8 <f0+0x17b8>  // b.hs, b.nlast
    b8b0:	8b0102b5 	add	x21, x21, x1
    b8b4:	394002a0 	ldrb	w0, [x21]
    b8b8:	7103fc1f 	cmp	w0, #0xff
    b8bc:	54007200 	b.eq	c6fc <f0+0x25ec>  // b.none
    b8c0:	52800020 	mov	w0, #0x1                   	// #1
    b8c4:	390002a0 	strb	w0, [x21]
    b8c8:	9117e3e1 	add	x1, sp, #0x5f8
    b8cc:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b8d0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b8d4:	52800020 	mov	w0, #0x1                   	// #1
    b8d8:	f902fff5 	str	x21, [sp, #1528]
    b8dc:	f90303f7 	str	x23, [sp, #1536]
    b8e0:	97ffe5e9 	bl	5084 <fwp_data.part.0.constprop.0>
    b8e4:	97ffe847 	bl	5a00 <fwp_rc_fresh>
    b8e8:	aa0003e2 	mov	x2, x0
    b8ec:	911823e1 	add	x1, sp, #0x608
    b8f0:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b8f4:	52800020 	mov	w0, #0x1                   	// #1
    b8f8:	f90307f7 	str	x23, [sp, #1544]
    b8fc:	f9030be2 	str	x2, [sp, #1552]
    b900:	97ffe5e1 	bl	5084 <fwp_data.part.0.constprop.0>
    b904:	97ffe83f 	bl	5a00 <fwp_rc_fresh>
    b908:	aa0003e2 	mov	x2, x0
    b90c:	911863e1 	add	x1, sp, #0x618
    b910:	52800020 	mov	w0, #0x1                   	// #1
    b914:	f9030ff5 	str	x21, [sp, #1560]
    b918:	f90313e2 	str	x2, [sp, #1568]
    b91c:	97ffe5da 	bl	5084 <fwp_data.part.0.constprop.0>
    b920:	97ffe838 	bl	5a00 <fwp_rc_fresh>
    b924:	aa0003e2 	mov	x2, x0
    b928:	9118a3e1 	add	x1, sp, #0x628
    b92c:	52800020 	mov	w0, #0x1                   	// #1
    b930:	f90317f7 	str	x23, [sp, #1576]
    b934:	f9031be2 	str	x2, [sp, #1584]
    b938:	97ffe5d3 	bl	5084 <fwp_data.part.0.constprop.0>
    b93c:	97ffe831 	bl	5a00 <fwp_rc_fresh>
    b940:	aa0003e2 	mov	x2, x0
    b944:	9118e3e1 	add	x1, sp, #0x638
    b948:	52800020 	mov	w0, #0x1                   	// #1
    b94c:	f9031ff5 	str	x21, [sp, #1592]
    b950:	f90323e2 	str	x2, [sp, #1600]
    b954:	97ffe5cc 	bl	5084 <fwp_data.part.0.constprop.0>
    b958:	97ffe82a 	bl	5a00 <fwp_rc_fresh>
    b95c:	aa0003e2 	mov	x2, x0
    b960:	911923e1 	add	x1, sp, #0x648
    b964:	52800020 	mov	w0, #0x1                   	// #1
    b968:	f90327f7 	str	x23, [sp, #1608]
    b96c:	f9032be2 	str	x2, [sp, #1616]
    b970:	97ffe5c5 	bl	5084 <fwp_data.part.0.constprop.0>
    b974:	97ffe823 	bl	5a00 <fwp_rc_fresh>
    b978:	aa0003e2 	mov	x2, x0
    b97c:	911963e1 	add	x1, sp, #0x658
    b980:	52800020 	mov	w0, #0x1                   	// #1
    b984:	f9032ff5 	str	x21, [sp, #1624]
    b988:	f90333e2 	str	x2, [sp, #1632]
    b98c:	97ffe5be 	bl	5084 <fwp_data.part.0.constprop.0>
    b990:	91174283 	add	x3, x20, #0x5d0
    b994:	aa0003f5 	mov	x21, x0
    b998:	f949d861 	ldr	x1, [x3, #5040]
    b99c:	f949ec60 	ldr	x0, [x3, #5080]
    b9a0:	cb0102a1 	sub	x1, x21, x1
    b9a4:	eb00403f 	cmp	x1, x0, lsl #16
    b9a8:	54000322 	b.cs	ba0c <f0+0x18fc>  // b.hs, b.nlast
    b9ac:	d350fc22 	lsr	x2, x1, #16
    b9b0:	f949fc63 	ldr	x3, [x3, #5112]
    b9b4:	8b020842 	add	x2, x2, x2, lsl #2
    b9b8:	d37df042 	lsl	x2, x2, #3
    b9bc:	8b020060 	add	x0, x3, x2
    b9c0:	f9401017 	ldr	x23, [x0, #32]
    b9c4:	b4000257 	cbz	x23, ba0c <f0+0x18fc>
    b9c8:	38626862 	ldrb	w2, [x3, x2]
    b9cc:	7100085f 	cmp	w2, #0x2
    b9d0:	54005460 	b.eq	c45c <f0+0x234c>  // b.none
    b9d4:	7100045f 	cmp	w2, #0x1
    b9d8:	540001a1 	b.ne	ba0c <f0+0x18fc>  // b.any
    b9dc:	29430002 	ldp	w2, w0, [x0, #24]
    b9e0:	92403c21 	and	x1, x1, #0xffff
    b9e4:	9b027c21 	mul	x1, x1, x2
    b9e8:	d360fc21 	lsr	x1, x1, #32
    b9ec:	eb00003f 	cmp	x1, x0
    b9f0:	540000e2 	b.cs	ba0c <f0+0x18fc>  // b.hs, b.nlast
    b9f4:	8b0102f7 	add	x23, x23, x1
    b9f8:	394002e0 	ldrb	w0, [x23]
    b9fc:	7103fc1f 	cmp	w0, #0xff
    ba00:	54006840 	b.eq	c708 <f0+0x25f8>  // b.none
    ba04:	52800020 	mov	w0, #0x1                   	// #1
    ba08:	390002e0 	strb	w0, [x23]
    ba0c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    ba10:	9119a3e1 	add	x1, sp, #0x668
    ba14:	52800020 	mov	w0, #0x1                   	// #1
    ba18:	f90337e2 	str	x2, [sp, #1640]
    ba1c:	f9033bf5 	str	x21, [sp, #1648]
    ba20:	97ffe599 	bl	5084 <fwp_data.part.0.constprop.0>
    ba24:	91174283 	add	x3, x20, #0x5d0
    ba28:	aa0003f5 	mov	x21, x0
    ba2c:	f949d861 	ldr	x1, [x3, #5040]
    ba30:	f949ec60 	ldr	x0, [x3, #5080]
    ba34:	cb0102a1 	sub	x1, x21, x1
    ba38:	eb00403f 	cmp	x1, x0, lsl #16
    ba3c:	54000322 	b.cs	baa0 <f0+0x1990>  // b.hs, b.nlast
    ba40:	d350fc22 	lsr	x2, x1, #16
    ba44:	f949fc63 	ldr	x3, [x3, #5112]
    ba48:	8b020842 	add	x2, x2, x2, lsl #2
    ba4c:	d37df042 	lsl	x2, x2, #3
    ba50:	8b020060 	add	x0, x3, x2
    ba54:	f9401017 	ldr	x23, [x0, #32]
    ba58:	b4000257 	cbz	x23, baa0 <f0+0x1990>
    ba5c:	38626862 	ldrb	w2, [x3, x2]
    ba60:	7100085f 	cmp	w2, #0x2
    ba64:	540050e0 	b.eq	c480 <f0+0x2370>  // b.none
    ba68:	7100045f 	cmp	w2, #0x1
    ba6c:	540001a1 	b.ne	baa0 <f0+0x1990>  // b.any
    ba70:	29430002 	ldp	w2, w0, [x0, #24]
    ba74:	92403c21 	and	x1, x1, #0xffff
    ba78:	9b027c21 	mul	x1, x1, x2
    ba7c:	d360fc21 	lsr	x1, x1, #32
    ba80:	eb00003f 	cmp	x1, x0
    ba84:	540000e2 	b.cs	baa0 <f0+0x1990>  // b.hs, b.nlast
    ba88:	8b0102f7 	add	x23, x23, x1
    ba8c:	394002e0 	ldrb	w0, [x23]
    ba90:	7103fc1f 	cmp	w0, #0xff
    ba94:	54006400 	b.eq	c714 <f0+0x2604>  // b.none
    ba98:	52800020 	mov	w0, #0x1                   	// #1
    ba9c:	390002e0 	strb	w0, [x23]
    baa0:	9119e3e1 	add	x1, sp, #0x678
    baa4:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    baa8:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    baac:	52800020 	mov	w0, #0x1                   	// #1
    bab0:	f9033ff7 	str	x23, [sp, #1656]
    bab4:	f90343f5 	str	x21, [sp, #1664]
    bab8:	97ffe573 	bl	5084 <fwp_data.part.0.constprop.0>
    babc:	97ffe7d1 	bl	5a00 <fwp_rc_fresh>
    bac0:	aa0003e2 	mov	x2, x0
    bac4:	911a23e1 	add	x1, sp, #0x688
    bac8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    bacc:	52800020 	mov	w0, #0x1                   	// #1
    bad0:	f90347f5 	str	x21, [sp, #1672]
    bad4:	f9034be2 	str	x2, [sp, #1680]
    bad8:	97ffe56b 	bl	5084 <fwp_data.part.0.constprop.0>
    badc:	97ffe7c9 	bl	5a00 <fwp_rc_fresh>
    bae0:	aa0003e2 	mov	x2, x0
    bae4:	911a63e1 	add	x1, sp, #0x698
    bae8:	52800020 	mov	w0, #0x1                   	// #1
    baec:	f9034ff7 	str	x23, [sp, #1688]
    baf0:	f90353e2 	str	x2, [sp, #1696]
    baf4:	97ffe564 	bl	5084 <fwp_data.part.0.constprop.0>
    baf8:	97ffe7c2 	bl	5a00 <fwp_rc_fresh>
    bafc:	aa0003e2 	mov	x2, x0
    bb00:	911aa3e1 	add	x1, sp, #0x6a8
    bb04:	52800020 	mov	w0, #0x1                   	// #1
    bb08:	f90357f5 	str	x21, [sp, #1704]
    bb0c:	f9035be2 	str	x2, [sp, #1712]
    bb10:	97ffe55d 	bl	5084 <fwp_data.part.0.constprop.0>
    bb14:	91174283 	add	x3, x20, #0x5d0
    bb18:	aa0003f5 	mov	x21, x0
    bb1c:	f949d861 	ldr	x1, [x3, #5040]
    bb20:	f949ec60 	ldr	x0, [x3, #5080]
    bb24:	cb0102a1 	sub	x1, x21, x1
    bb28:	eb00403f 	cmp	x1, x0, lsl #16
    bb2c:	54000322 	b.cs	bb90 <f0+0x1a80>  // b.hs, b.nlast
    bb30:	d350fc22 	lsr	x2, x1, #16
    bb34:	f949fc63 	ldr	x3, [x3, #5112]
    bb38:	8b020842 	add	x2, x2, x2, lsl #2
    bb3c:	d37df042 	lsl	x2, x2, #3
    bb40:	8b020060 	add	x0, x3, x2
    bb44:	f9401017 	ldr	x23, [x0, #32]
    bb48:	b4000257 	cbz	x23, bb90 <f0+0x1a80>
    bb4c:	38626862 	ldrb	w2, [x3, x2]
    bb50:	7100085f 	cmp	w2, #0x2
    bb54:	54004900 	b.eq	c474 <f0+0x2364>  // b.none
    bb58:	7100045f 	cmp	w2, #0x1
    bb5c:	540001a1 	b.ne	bb90 <f0+0x1a80>  // b.any
    bb60:	29430002 	ldp	w2, w0, [x0, #24]
    bb64:	92403c21 	and	x1, x1, #0xffff
    bb68:	9b027c21 	mul	x1, x1, x2
    bb6c:	d360fc21 	lsr	x1, x1, #32
    bb70:	eb00003f 	cmp	x1, x0
    bb74:	540000e2 	b.cs	bb90 <f0+0x1a80>  // b.hs, b.nlast
    bb78:	8b0102f7 	add	x23, x23, x1
    bb7c:	394002e0 	ldrb	w0, [x23]
    bb80:	7103fc1f 	cmp	w0, #0xff
    bb84:	54005ce0 	b.eq	c720 <f0+0x2610>  // b.none
    bb88:	52800020 	mov	w0, #0x1                   	// #1
    bb8c:	390002e0 	strb	w0, [x23]
    bb90:	911ae3e1 	add	x1, sp, #0x6b8
    bb94:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    bb98:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    bb9c:	52800020 	mov	w0, #0x1                   	// #1
    bba0:	f9035ff7 	str	x23, [sp, #1720]
    bba4:	f90363f5 	str	x21, [sp, #1728]
    bba8:	97ffe537 	bl	5084 <fwp_data.part.0.constprop.0>
    bbac:	97ffe795 	bl	5a00 <fwp_rc_fresh>
    bbb0:	aa0003e2 	mov	x2, x0
    bbb4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bbb8:	911b23e1 	add	x1, sp, #0x6c8
    bbbc:	52800020 	mov	w0, #0x1                   	// #1
    bbc0:	f90367e3 	str	x3, [sp, #1736]
    bbc4:	f9036be2 	str	x2, [sp, #1744]
    bbc8:	97ffe52f 	bl	5084 <fwp_data.part.0.constprop.0>
    bbcc:	97ffe78d 	bl	5a00 <fwp_rc_fresh>
    bbd0:	aa0003e2 	mov	x2, x0
    bbd4:	911b63e1 	add	x1, sp, #0x6d8
    bbd8:	52800020 	mov	w0, #0x1                   	// #1
    bbdc:	f9036ff7 	str	x23, [sp, #1752]
    bbe0:	f90373e2 	str	x2, [sp, #1760]
    bbe4:	97ffe528 	bl	5084 <fwp_data.part.0.constprop.0>
    bbe8:	91174283 	add	x3, x20, #0x5d0
    bbec:	aa0003f5 	mov	x21, x0
    bbf0:	f949d861 	ldr	x1, [x3, #5040]
    bbf4:	f949ec60 	ldr	x0, [x3, #5080]
    bbf8:	cb0102a1 	sub	x1, x21, x1
    bbfc:	eb00403f 	cmp	x1, x0, lsl #16
    bc00:	54000322 	b.cs	bc64 <f0+0x1b54>  // b.hs, b.nlast
    bc04:	d350fc22 	lsr	x2, x1, #16
    bc08:	f949fc63 	ldr	x3, [x3, #5112]
    bc0c:	8b020842 	add	x2, x2, x2, lsl #2
    bc10:	d37df042 	lsl	x2, x2, #3
    bc14:	8b020060 	add	x0, x3, x2
    bc18:	f9401017 	ldr	x23, [x0, #32]
    bc1c:	b4000257 	cbz	x23, bc64 <f0+0x1b54>
    bc20:	38626862 	ldrb	w2, [x3, x2]
    bc24:	7100085f 	cmp	w2, #0x2
    bc28:	54004380 	b.eq	c498 <f0+0x2388>  // b.none
    bc2c:	7100045f 	cmp	w2, #0x1
    bc30:	540001a1 	b.ne	bc64 <f0+0x1b54>  // b.any
    bc34:	29430002 	ldp	w2, w0, [x0, #24]
    bc38:	92403c21 	and	x1, x1, #0xffff
    bc3c:	9b027c21 	mul	x1, x1, x2
    bc40:	d360fc21 	lsr	x1, x1, #32
    bc44:	eb00003f 	cmp	x1, x0
    bc48:	540000e2 	b.cs	bc64 <f0+0x1b54>  // b.hs, b.nlast
    bc4c:	8b0102f7 	add	x23, x23, x1
    bc50:	394002e0 	ldrb	w0, [x23]
    bc54:	7103fc1f 	cmp	w0, #0xff
    bc58:	540056a0 	b.eq	c72c <f0+0x261c>  // b.none
    bc5c:	52800020 	mov	w0, #0x1                   	// #1
    bc60:	390002e0 	strb	w0, [x23]
    bc64:	911ba3e1 	add	x1, sp, #0x6e8
    bc68:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bc6c:	52800020 	mov	w0, #0x1                   	// #1
    bc70:	f90377f7 	str	x23, [sp, #1768]
    bc74:	f9037bf5 	str	x21, [sp, #1776]
    bc78:	97ffe503 	bl	5084 <fwp_data.part.0.constprop.0>
    bc7c:	97ffe761 	bl	5a00 <fwp_rc_fresh>
    bc80:	aa0003e2 	mov	x2, x0
    bc84:	911be3e1 	add	x1, sp, #0x6f8
    bc88:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bc8c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bc90:	52800020 	mov	w0, #0x1                   	// #1
    bc94:	f9037ff5 	str	x21, [sp, #1784]
    bc98:	f90383e2 	str	x2, [sp, #1792]
    bc9c:	97ffe4fa 	bl	5084 <fwp_data.part.0.constprop.0>
    bca0:	97ffe758 	bl	5a00 <fwp_rc_fresh>
    bca4:	aa0003e2 	mov	x2, x0
    bca8:	911c23e1 	add	x1, sp, #0x708
    bcac:	52800020 	mov	w0, #0x1                   	// #1
    bcb0:	f90387f7 	str	x23, [sp, #1800]
    bcb4:	f9038be2 	str	x2, [sp, #1808]
    bcb8:	97ffe4f3 	bl	5084 <fwp_data.part.0.constprop.0>
    bcbc:	97ffe751 	bl	5a00 <fwp_rc_fresh>
    bcc0:	aa0003e2 	mov	x2, x0
    bcc4:	911c63e1 	add	x1, sp, #0x718
    bcc8:	52800020 	mov	w0, #0x1                   	// #1
    bccc:	f9038ff5 	str	x21, [sp, #1816]
    bcd0:	f90393e2 	str	x2, [sp, #1824]
    bcd4:	97ffe4ec 	bl	5084 <fwp_data.part.0.constprop.0>
    bcd8:	97ffe74a 	bl	5a00 <fwp_rc_fresh>
    bcdc:	aa0003e2 	mov	x2, x0
    bce0:	911ca3e1 	add	x1, sp, #0x728
    bce4:	52800020 	mov	w0, #0x1                   	// #1
    bce8:	f90397f7 	str	x23, [sp, #1832]
    bcec:	f9039be2 	str	x2, [sp, #1840]
    bcf0:	97ffe4e5 	bl	5084 <fwp_data.part.0.constprop.0>
    bcf4:	97ffe743 	bl	5a00 <fwp_rc_fresh>
    bcf8:	aa0003e2 	mov	x2, x0
    bcfc:	911ce3e1 	add	x1, sp, #0x738
    bd00:	52800020 	mov	w0, #0x1                   	// #1
    bd04:	f9039ff5 	str	x21, [sp, #1848]
    bd08:	f903a3e2 	str	x2, [sp, #1856]
    bd0c:	97ffe4de 	bl	5084 <fwp_data.part.0.constprop.0>
    bd10:	97ffe73c 	bl	5a00 <fwp_rc_fresh>
    bd14:	aa0003e2 	mov	x2, x0
    bd18:	911d23e1 	add	x1, sp, #0x748
    bd1c:	52800020 	mov	w0, #0x1                   	// #1
    bd20:	f903a7f7 	str	x23, [sp, #1864]
    bd24:	f903abe2 	str	x2, [sp, #1872]
    bd28:	97ffe4d7 	bl	5084 <fwp_data.part.0.constprop.0>
    bd2c:	97ffe735 	bl	5a00 <fwp_rc_fresh>
    bd30:	aa0003e2 	mov	x2, x0
    bd34:	911d63e1 	add	x1, sp, #0x758
    bd38:	52800020 	mov	w0, #0x1                   	// #1
    bd3c:	f903aff5 	str	x21, [sp, #1880]
    bd40:	f903b3e2 	str	x2, [sp, #1888]
    bd44:	97ffe4d0 	bl	5084 <fwp_data.part.0.constprop.0>
    bd48:	91174283 	add	x3, x20, #0x5d0
    bd4c:	aa0003f5 	mov	x21, x0
    bd50:	f949d861 	ldr	x1, [x3, #5040]
    bd54:	f949ec60 	ldr	x0, [x3, #5080]
    bd58:	cb0102a1 	sub	x1, x21, x1
    bd5c:	eb00403f 	cmp	x1, x0, lsl #16
    bd60:	54000322 	b.cs	bdc4 <f0+0x1cb4>  // b.hs, b.nlast
    bd64:	d350fc22 	lsr	x2, x1, #16
    bd68:	f949fc63 	ldr	x3, [x3, #5112]
    bd6c:	8b020842 	add	x2, x2, x2, lsl #2
    bd70:	d37df042 	lsl	x2, x2, #3
    bd74:	8b020060 	add	x0, x3, x2
    bd78:	f9401017 	ldr	x23, [x0, #32]
    bd7c:	b4000257 	cbz	x23, bdc4 <f0+0x1cb4>
    bd80:	38626862 	ldrb	w2, [x3, x2]
    bd84:	7100085f 	cmp	w2, #0x2
    bd88:	54003820 	b.eq	c48c <f0+0x237c>  // b.none
    bd8c:	7100045f 	cmp	w2, #0x1
    bd90:	540001a1 	b.ne	bdc4 <f0+0x1cb4>  // b.any
    bd94:	29430002 	ldp	w2, w0, [x0, #24]
    bd98:	92403c21 	and	x1, x1, #0xffff
    bd9c:	9b027c21 	mul	x1, x1, x2
    bda0:	d360fc21 	lsr	x1, x1, #32
    bda4:	eb00003f 	cmp	x1, x0
    bda8:	540000e2 	b.cs	bdc4 <f0+0x1cb4>  // b.hs, b.nlast
    bdac:	8b0102f7 	add	x23, x23, x1
    bdb0:	394002e0 	ldrb	w0, [x23]
    bdb4:	7103fc1f 	cmp	w0, #0xff
    bdb8:	54004c00 	b.eq	c738 <f0+0x2628>  // b.none
    bdbc:	52800020 	mov	w0, #0x1                   	// #1
    bdc0:	390002e0 	strb	w0, [x23]
    bdc4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bdc8:	911da3e1 	add	x1, sp, #0x768
    bdcc:	52800020 	mov	w0, #0x1                   	// #1
    bdd0:	f903b7e2 	str	x2, [sp, #1896]
    bdd4:	f903bbf5 	str	x21, [sp, #1904]
    bdd8:	97ffe4ab 	bl	5084 <fwp_data.part.0.constprop.0>
    bddc:	91174283 	add	x3, x20, #0x5d0
    bde0:	aa0003f5 	mov	x21, x0
    bde4:	f949d861 	ldr	x1, [x3, #5040]
    bde8:	f949ec60 	ldr	x0, [x3, #5080]
    bdec:	cb0102a1 	sub	x1, x21, x1
    bdf0:	eb00403f 	cmp	x1, x0, lsl #16
    bdf4:	54000322 	b.cs	be58 <f0+0x1d48>  // b.hs, b.nlast
    bdf8:	d350fc22 	lsr	x2, x1, #16
    bdfc:	f949fc63 	ldr	x3, [x3, #5112]
    be00:	8b020842 	add	x2, x2, x2, lsl #2
    be04:	d37df042 	lsl	x2, x2, #3
    be08:	8b020060 	add	x0, x3, x2
    be0c:	f9401017 	ldr	x23, [x0, #32]
    be10:	b4000257 	cbz	x23, be58 <f0+0x1d48>
    be14:	38626862 	ldrb	w2, [x3, x2]
    be18:	7100085f 	cmp	w2, #0x2
    be1c:	540034a0 	b.eq	c4b0 <f0+0x23a0>  // b.none
    be20:	7100045f 	cmp	w2, #0x1
    be24:	540001a1 	b.ne	be58 <f0+0x1d48>  // b.any
    be28:	29430002 	ldp	w2, w0, [x0, #24]
    be2c:	92403c21 	and	x1, x1, #0xffff
    be30:	9b027c21 	mul	x1, x1, x2
    be34:	d360fc21 	lsr	x1, x1, #32
    be38:	eb00003f 	cmp	x1, x0
    be3c:	540000e2 	b.cs	be58 <f0+0x1d48>  // b.hs, b.nlast
    be40:	8b0102f7 	add	x23, x23, x1
    be44:	394002e0 	ldrb	w0, [x23]
    be48:	7103fc1f 	cmp	w0, #0xff
    be4c:	540047c0 	b.eq	c744 <f0+0x2634>  // b.none
    be50:	52800020 	mov	w0, #0x1                   	// #1
    be54:	390002e0 	strb	w0, [x23]
    be58:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    be5c:	911de3e1 	add	x1, sp, #0x778
    be60:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    be64:	52800020 	mov	w0, #0x1                   	// #1
    be68:	f903bfe2 	str	x2, [sp, #1912]
    be6c:	f903c3f5 	str	x21, [sp, #1920]
    be70:	97ffe485 	bl	5084 <fwp_data.part.0.constprop.0>
    be74:	97ffe6e3 	bl	5a00 <fwp_rc_fresh>
    be78:	aa0003e2 	mov	x2, x0
    be7c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    be80:	911e23e1 	add	x1, sp, #0x788
    be84:	52800020 	mov	w0, #0x1                   	// #1
    be88:	f903c7e3 	str	x3, [sp, #1928]
    be8c:	f903cbe2 	str	x2, [sp, #1936]
    be90:	97ffe47d 	bl	5084 <fwp_data.part.0.constprop.0>
    be94:	91174283 	add	x3, x20, #0x5d0
    be98:	aa0003f5 	mov	x21, x0
    be9c:	f949d861 	ldr	x1, [x3, #5040]
    bea0:	f949ec60 	ldr	x0, [x3, #5080]
    bea4:	cb0102a1 	sub	x1, x21, x1
    bea8:	eb00403f 	cmp	x1, x0, lsl #16
    beac:	54000322 	b.cs	bf10 <f0+0x1e00>  // b.hs, b.nlast
    beb0:	d350fc22 	lsr	x2, x1, #16
    beb4:	f949fc63 	ldr	x3, [x3, #5112]
    beb8:	8b020842 	add	x2, x2, x2, lsl #2
    bebc:	d37df042 	lsl	x2, x2, #3
    bec0:	8b020060 	add	x0, x3, x2
    bec4:	f9401017 	ldr	x23, [x0, #32]
    bec8:	b4000257 	cbz	x23, bf10 <f0+0x1e00>
    becc:	38626862 	ldrb	w2, [x3, x2]
    bed0:	7100085f 	cmp	w2, #0x2
    bed4:	54002e80 	b.eq	c4a4 <f0+0x2394>  // b.none
    bed8:	7100045f 	cmp	w2, #0x1
    bedc:	540001a1 	b.ne	bf10 <f0+0x1e00>  // b.any
    bee0:	29430002 	ldp	w2, w0, [x0, #24]
    bee4:	92403c21 	and	x1, x1, #0xffff
    bee8:	9b027c21 	mul	x1, x1, x2
    beec:	d360fc21 	lsr	x1, x1, #32
    bef0:	eb00003f 	cmp	x1, x0
    bef4:	540000e2 	b.cs	bf10 <f0+0x1e00>  // b.hs, b.nlast
    bef8:	8b0102f7 	add	x23, x23, x1
    befc:	394002e0 	ldrb	w0, [x23]
    bf00:	7103fc1f 	cmp	w0, #0xff
    bf04:	54004260 	b.eq	c750 <f0+0x2640>  // b.none
    bf08:	52800020 	mov	w0, #0x1                   	// #1
    bf0c:	390002e0 	strb	w0, [x23]
    bf10:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bf14:	911e63e1 	add	x1, sp, #0x798
    bf18:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bf1c:	52800020 	mov	w0, #0x1                   	// #1
    bf20:	f903cfe2 	str	x2, [sp, #1944]
    bf24:	f903d3f5 	str	x21, [sp, #1952]
    bf28:	97ffe457 	bl	5084 <fwp_data.part.0.constprop.0>
    bf2c:	97ffe6b5 	bl	5a00 <fwp_rc_fresh>
    bf30:	aa0003e2 	mov	x2, x0
    bf34:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    bf38:	911ea3e1 	add	x1, sp, #0x7a8
    bf3c:	52800020 	mov	w0, #0x1                   	// #1
    bf40:	f903d7e3 	str	x3, [sp, #1960]
    bf44:	f903dbe2 	str	x2, [sp, #1968]
    bf48:	97ffe44f 	bl	5084 <fwp_data.part.0.constprop.0>
    bf4c:	91174283 	add	x3, x20, #0x5d0
    bf50:	aa0003f5 	mov	x21, x0
    bf54:	f949d861 	ldr	x1, [x3, #5040]
    bf58:	f949ec60 	ldr	x0, [x3, #5080]
    bf5c:	cb0102a1 	sub	x1, x21, x1
    bf60:	eb00403f 	cmp	x1, x0, lsl #16
    bf64:	54000322 	b.cs	bfc8 <f0+0x1eb8>  // b.hs, b.nlast
    bf68:	d350fc22 	lsr	x2, x1, #16
    bf6c:	f949fc63 	ldr	x3, [x3, #5112]
    bf70:	8b020842 	add	x2, x2, x2, lsl #2
    bf74:	d37df042 	lsl	x2, x2, #3
    bf78:	8b020060 	add	x0, x3, x2
    bf7c:	f9401017 	ldr	x23, [x0, #32]
    bf80:	b4000257 	cbz	x23, bfc8 <f0+0x1eb8>
    bf84:	38626862 	ldrb	w2, [x3, x2]
    bf88:	7100085f 	cmp	w2, #0x2
    bf8c:	540029e0 	b.eq	c4c8 <f0+0x23b8>  // b.none
    bf90:	7100045f 	cmp	w2, #0x1
    bf94:	540001a1 	b.ne	bfc8 <f0+0x1eb8>  // b.any
    bf98:	29430002 	ldp	w2, w0, [x0, #24]
    bf9c:	92403c21 	and	x1, x1, #0xffff
    bfa0:	9b027c21 	mul	x1, x1, x2
    bfa4:	d360fc21 	lsr	x1, x1, #32
    bfa8:	eb00003f 	cmp	x1, x0
    bfac:	540000e2 	b.cs	bfc8 <f0+0x1eb8>  // b.hs, b.nlast
    bfb0:	8b0102f7 	add	x23, x23, x1
    bfb4:	394002e0 	ldrb	w0, [x23]
    bfb8:	7103fc1f 	cmp	w0, #0xff
    bfbc:	54003d00 	b.eq	c75c <f0+0x264c>  // b.none
    bfc0:	52800020 	mov	w0, #0x1                   	// #1
    bfc4:	390002e0 	strb	w0, [x23]
    bfc8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bfcc:	911ee3e1 	add	x1, sp, #0x7b8
    bfd0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bfd4:	52800020 	mov	w0, #0x1                   	// #1
    bfd8:	f903dfe2 	str	x2, [sp, #1976]
    bfdc:	f903e3f5 	str	x21, [sp, #1984]
    bfe0:	97ffe429 	bl	5084 <fwp_data.part.0.constprop.0>
    bfe4:	91174283 	add	x3, x20, #0x5d0
    bfe8:	aa0003f5 	mov	x21, x0
    bfec:	f949d861 	ldr	x1, [x3, #5040]
    bff0:	f949ec60 	ldr	x0, [x3, #5080]
    bff4:	cb0102a1 	sub	x1, x21, x1
    bff8:	eb00403f 	cmp	x1, x0, lsl #16
    bffc:	54000322 	b.cs	c060 <f0+0x1f50>  // b.hs, b.nlast
    c000:	d350fc22 	lsr	x2, x1, #16
    c004:	f949fc63 	ldr	x3, [x3, #5112]
    c008:	8b020842 	add	x2, x2, x2, lsl #2
    c00c:	d37df042 	lsl	x2, x2, #3
    c010:	8b020060 	add	x0, x3, x2
    c014:	f9401017 	ldr	x23, [x0, #32]
    c018:	b4000257 	cbz	x23, c060 <f0+0x1f50>
    c01c:	38626862 	ldrb	w2, [x3, x2]
    c020:	7100085f 	cmp	w2, #0x2
    c024:	540024c0 	b.eq	c4bc <f0+0x23ac>  // b.none
    c028:	7100045f 	cmp	w2, #0x1
    c02c:	540001a1 	b.ne	c060 <f0+0x1f50>  // b.any
    c030:	29430002 	ldp	w2, w0, [x0, #24]
    c034:	92403c21 	and	x1, x1, #0xffff
    c038:	9b027c21 	mul	x1, x1, x2
    c03c:	d360fc21 	lsr	x1, x1, #32
    c040:	eb00003f 	cmp	x1, x0
    c044:	540000e2 	b.cs	c060 <f0+0x1f50>  // b.hs, b.nlast
    c048:	8b0102f7 	add	x23, x23, x1
    c04c:	394002e0 	ldrb	w0, [x23]
    c050:	7103fc1f 	cmp	w0, #0xff
    c054:	540038a0 	b.eq	c768 <f0+0x2658>  // b.none
    c058:	52800020 	mov	w0, #0x1                   	// #1
    c05c:	390002e0 	strb	w0, [x23]
    c060:	911f23e1 	add	x1, sp, #0x7c8
    c064:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c068:	52800020 	mov	w0, #0x1                   	// #1
    c06c:	f903e7e2 	str	x2, [sp, #1992]
    c070:	f903ebf5 	str	x21, [sp, #2000]
    c074:	97ffe404 	bl	5084 <fwp_data.part.0.constprop.0>
    c078:	97ffe662 	bl	5a00 <fwp_rc_fresh>
    c07c:	aa0003e2 	mov	x2, x0
    c080:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c084:	911f63e1 	add	x1, sp, #0x7d8
    c088:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c08c:	52800020 	mov	w0, #0x1                   	// #1
    c090:	f903efe3 	str	x3, [sp, #2008]
    c094:	f903f3e2 	str	x2, [sp, #2016]
    c098:	97ffe3fb 	bl	5084 <fwp_data.part.0.constprop.0>
    c09c:	91174283 	add	x3, x20, #0x5d0
    c0a0:	aa0003f5 	mov	x21, x0
    c0a4:	f949d861 	ldr	x1, [x3, #5040]
    c0a8:	f949ec60 	ldr	x0, [x3, #5080]
    c0ac:	cb0102a1 	sub	x1, x21, x1
    c0b0:	eb00403f 	cmp	x1, x0, lsl #16
    c0b4:	54000322 	b.cs	c118 <f0+0x2008>  // b.hs, b.nlast
    c0b8:	d350fc22 	lsr	x2, x1, #16
    c0bc:	f949fc63 	ldr	x3, [x3, #5112]
    c0c0:	8b020842 	add	x2, x2, x2, lsl #2
    c0c4:	d37df042 	lsl	x2, x2, #3
    c0c8:	8b020060 	add	x0, x3, x2
    c0cc:	f9401017 	ldr	x23, [x0, #32]
    c0d0:	b4000257 	cbz	x23, c118 <f0+0x2008>
    c0d4:	38626862 	ldrb	w2, [x3, x2]
    c0d8:	7100085f 	cmp	w2, #0x2
    c0dc:	54002020 	b.eq	c4e0 <f0+0x23d0>  // b.none
    c0e0:	7100045f 	cmp	w2, #0x1
    c0e4:	540001a1 	b.ne	c118 <f0+0x2008>  // b.any
    c0e8:	29430002 	ldp	w2, w0, [x0, #24]
    c0ec:	92403c21 	and	x1, x1, #0xffff
    c0f0:	9b027c21 	mul	x1, x1, x2
    c0f4:	d360fc21 	lsr	x1, x1, #32
    c0f8:	eb00003f 	cmp	x1, x0
    c0fc:	540000e2 	b.cs	c118 <f0+0x2008>  // b.hs, b.nlast
    c100:	8b0102f7 	add	x23, x23, x1
    c104:	394002e0 	ldrb	w0, [x23]
    c108:	7103fc1f 	cmp	w0, #0xff
    c10c:	54003340 	b.eq	c774 <f0+0x2664>  // b.none
    c110:	52800020 	mov	w0, #0x1                   	// #1
    c114:	390002e0 	strb	w0, [x23]
    c118:	911fa3e1 	add	x1, sp, #0x7e8
    c11c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c120:	52800020 	mov	w0, #0x1                   	// #1
    c124:	f903f7e2 	str	x2, [sp, #2024]
    c128:	f903fbf5 	str	x21, [sp, #2032]
    c12c:	97ffe3d6 	bl	5084 <fwp_data.part.0.constprop.0>
    c130:	97ffe634 	bl	5a00 <fwp_rc_fresh>
    c134:	aa0003e2 	mov	x2, x0
    c138:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c13c:	911fe3e1 	add	x1, sp, #0x7f8
    c140:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c144:	52800020 	mov	w0, #0x1                   	// #1
    c148:	f903ffe3 	str	x3, [sp, #2040]
    c14c:	f90403e2 	str	x2, [sp, #2048]
    c150:	97ffe3cd 	bl	5084 <fwp_data.part.0.constprop.0>
    c154:	91174283 	add	x3, x20, #0x5d0
    c158:	aa0003f5 	mov	x21, x0
    c15c:	f949d861 	ldr	x1, [x3, #5040]
    c160:	f949ec60 	ldr	x0, [x3, #5080]
    c164:	cb0102a1 	sub	x1, x21, x1
    c168:	eb00403f 	cmp	x1, x0, lsl #16
    c16c:	54000322 	b.cs	c1d0 <f0+0x20c0>  // b.hs, b.nlast
    c170:	d350fc22 	lsr	x2, x1, #16
    c174:	f949fc63 	ldr	x3, [x3, #5112]
    c178:	8b020842 	add	x2, x2, x2, lsl #2
    c17c:	d37df042 	lsl	x2, x2, #3
    c180:	8b020060 	add	x0, x3, x2
    c184:	f9401017 	ldr	x23, [x0, #32]
    c188:	b4000257 	cbz	x23, c1d0 <f0+0x20c0>
    c18c:	38626862 	ldrb	w2, [x3, x2]
    c190:	7100085f 	cmp	w2, #0x2
    c194:	54001a00 	b.eq	c4d4 <f0+0x23c4>  // b.none
    c198:	7100045f 	cmp	w2, #0x1
    c19c:	540001a1 	b.ne	c1d0 <f0+0x20c0>  // b.any
    c1a0:	29430002 	ldp	w2, w0, [x0, #24]
    c1a4:	92403c21 	and	x1, x1, #0xffff
    c1a8:	9b027c21 	mul	x1, x1, x2
    c1ac:	d360fc21 	lsr	x1, x1, #32
    c1b0:	eb00003f 	cmp	x1, x0
    c1b4:	540000e2 	b.cs	c1d0 <f0+0x20c0>  // b.hs, b.nlast
    c1b8:	8b0102f7 	add	x23, x23, x1
    c1bc:	394002e0 	ldrb	w0, [x23]
    c1c0:	7103fc1f 	cmp	w0, #0xff
    c1c4:	54002de0 	b.eq	c780 <f0+0x2670>  // b.none
    c1c8:	52800020 	mov	w0, #0x1                   	// #1
    c1cc:	390002e0 	strb	w0, [x23]
    c1d0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c1d4:	912023e1 	add	x1, sp, #0x808
    c1d8:	52800020 	mov	w0, #0x1                   	// #1
    c1dc:	f90407e2 	str	x2, [sp, #2056]
    c1e0:	f9040bf5 	str	x21, [sp, #2064]
    c1e4:	97ffe3a8 	bl	5084 <fwp_data.part.0.constprop.0>
    c1e8:	91174283 	add	x3, x20, #0x5d0
    c1ec:	aa0003f5 	mov	x21, x0
    c1f0:	f949d861 	ldr	x1, [x3, #5040]
    c1f4:	f949ec60 	ldr	x0, [x3, #5080]
    c1f8:	cb0102a1 	sub	x1, x21, x1
    c1fc:	eb00403f 	cmp	x1, x0, lsl #16
    c200:	54000322 	b.cs	c264 <f0+0x2154>  // b.hs, b.nlast
    c204:	d350fc22 	lsr	x2, x1, #16
    c208:	f949fc63 	ldr	x3, [x3, #5112]
    c20c:	8b020842 	add	x2, x2, x2, lsl #2
    c210:	d37df042 	lsl	x2, x2, #3
    c214:	8b020060 	add	x0, x3, x2
    c218:	f9401017 	ldr	x23, [x0, #32]
    c21c:	b4000257 	cbz	x23, c264 <f0+0x2154>
    c220:	38626862 	ldrb	w2, [x3, x2]
    c224:	7100085f 	cmp	w2, #0x2
    c228:	54001680 	b.eq	c4f8 <f0+0x23e8>  // b.none
    c22c:	7100045f 	cmp	w2, #0x1
    c230:	540001a1 	b.ne	c264 <f0+0x2154>  // b.any
    c234:	29430002 	ldp	w2, w0, [x0, #24]
    c238:	92403c21 	and	x1, x1, #0xffff
    c23c:	9b027c21 	mul	x1, x1, x2
    c240:	d360fc21 	lsr	x1, x1, #32
    c244:	eb00003f 	cmp	x1, x0
    c248:	540000e2 	b.cs	c264 <f0+0x2154>  // b.hs, b.nlast
    c24c:	8b0102f7 	add	x23, x23, x1
    c250:	394002e0 	ldrb	w0, [x23]
    c254:	7103fc1f 	cmp	w0, #0xff
    c258:	540029a0 	b.eq	c78c <f0+0x267c>  // b.none
    c25c:	52800020 	mov	w0, #0x1                   	// #1
    c260:	390002e0 	strb	w0, [x23]
    c264:	912063e1 	add	x1, sp, #0x818
    c268:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    c26c:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    c270:	52800020 	mov	w0, #0x1                   	// #1
    c274:	f9040ff7 	str	x23, [sp, #2072]
    c278:	91174294 	add	x20, x20, #0x5d0
    c27c:	f90413f5 	str	x21, [sp, #2080]
    c280:	97ffe381 	bl	5084 <fwp_data.part.0.constprop.0>
    c284:	97ffe5df 	bl	5a00 <fwp_rc_fresh>
    c288:	aa0003e2 	mov	x2, x0
    c28c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    c290:	9120a3e1 	add	x1, sp, #0x828
    c294:	52800020 	mov	w0, #0x1                   	// #1
    c298:	f90417e3 	str	x3, [sp, #2088]
    c29c:	f9041be2 	str	x2, [sp, #2096]
    c2a0:	97ffe379 	bl	5084 <fwp_data.part.0.constprop.0>
    c2a4:	97ffe5d7 	bl	5a00 <fwp_rc_fresh>
    c2a8:	aa0003e2 	mov	x2, x0
    c2ac:	9120e3e1 	add	x1, sp, #0x838
    c2b0:	52800020 	mov	w0, #0x1                   	// #1
    c2b4:	f9041ff7 	str	x23, [sp, #2104]
    c2b8:	f90423e2 	str	x2, [sp, #2112]
    c2bc:	97ffe372 	bl	5084 <fwp_data.part.0.constprop.0>
    c2c0:	f949da81 	ldr	x1, [x20, #5040]
    c2c4:	aa0003f5 	mov	x21, x0
    c2c8:	f949ee80 	ldr	x0, [x20, #5080]
    c2cc:	cb0102a1 	sub	x1, x21, x1
    c2d0:	eb00403f 	cmp	x1, x0, lsl #16
    c2d4:	54000322 	b.cs	c338 <f0+0x2228>  // b.hs, b.nlast
    c2d8:	d350fc22 	lsr	x2, x1, #16
    c2dc:	f949fe83 	ldr	x3, [x20, #5112]
    c2e0:	8b020842 	add	x2, x2, x2, lsl #2
    c2e4:	d37df042 	lsl	x2, x2, #3
    c2e8:	8b020060 	add	x0, x3, x2
    c2ec:	f9401014 	ldr	x20, [x0, #32]
    c2f0:	b4000254 	cbz	x20, c338 <f0+0x2228>
    c2f4:	38626862 	ldrb	w2, [x3, x2]
    c2f8:	7100085f 	cmp	w2, #0x2
    c2fc:	54000f80 	b.eq	c4ec <f0+0x23dc>  // b.none
    c300:	7100045f 	cmp	w2, #0x1
    c304:	540001a1 	b.ne	c338 <f0+0x2228>  // b.any
    c308:	29430002 	ldp	w2, w0, [x0, #24]
    c30c:	92403c21 	and	x1, x1, #0xffff
    c310:	9b027c21 	mul	x1, x1, x2
    c314:	d360fc21 	lsr	x1, x1, #32
    c318:	eb00003f 	cmp	x1, x0
    c31c:	540000e2 	b.cs	c338 <f0+0x2228>  // b.hs, b.nlast
    c320:	8b010294 	add	x20, x20, x1
    c324:	39400280 	ldrb	w0, [x20]
    c328:	7103fc1f 	cmp	w0, #0xff
    c32c:	540014c0 	b.eq	c5c4 <f0+0x24b4>  // b.none
    c330:	52800020 	mov	w0, #0x1                   	// #1
    c334:	39000280 	strb	w0, [x20]
    c338:	912123e1 	add	x1, sp, #0x848
    c33c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    c340:	52800020 	mov	w0, #0x1                   	// #1
    c344:	f90427e2 	str	x2, [sp, #2120]
    c348:	f9042bf5 	str	x21, [sp, #2128]
    c34c:	97ffe34e 	bl	5084 <fwp_data.part.0.constprop.0>
    c350:	97ffe5ac 	bl	5a00 <fwp_rc_fresh>
    c354:	aa0003e2 	mov	x2, x0
    c358:	aa1603e1 	mov	x1, x22
    c35c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    c360:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    c364:	52800020 	mov	w0, #0x1                   	// #1
    c368:	f9042fe3 	str	x3, [sp, #2136]
    c36c:	f90433e2 	str	x2, [sp, #2144]
    c370:	97ffe345 	bl	5084 <fwp_data.part.0.constprop.0>
    c374:	97ffe5a3 	bl	5a00 <fwp_rc_fresh>
    c378:	aa0003f5 	mov	x21, x0
    c37c:	aa1303e1 	mov	x1, x19
    c380:	97fff084 	bl	8590 <fwp_hof0.constprop.0>
    c384:	aa0003f4 	mov	x20, x0
    c388:	aa1503e0 	mov	x0, x21
    c38c:	97ffe6a1 	bl	5e10 <fwp_drop0>
    c390:	aa1303e0 	mov	x0, x19
    c394:	97ffe69f 	bl	5e10 <fwp_drop0>
    c398:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c39c:	f947f400 	ldr	x0, [x0, #4072]
    c3a0:	f94437e2 	ldr	x2, [sp, #2152]
    c3a4:	f9400001 	ldr	x1, [x0]
    c3a8:	eb010042 	subs	x2, x2, x1
    c3ac:	d2800001 	mov	x1, #0x0                   	// #0
    c3b0:	54001f41 	b.ne	c798 <f0+0x2688>  // b.any
    c3b4:	9121c3ff 	add	sp, sp, #0x870
    c3b8:	aa1403e0 	mov	x0, x20
    c3bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    c3c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c3c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    c3c8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c3cc:	a94573fb 	ldp	x27, x28, [sp, #80]
    c3d0:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c3d4:	d65f03c0 	ret
    c3d8:	aa1c03e0 	mov	x0, x28
    c3dc:	97ffdf8d 	bl	4210 <fwp_rc_forget_slot.part.0>
    c3e0:	17fff796 	b	a238 <f0+0x128>
    c3e4:	72003c5f 	tst	w2, #0xffff
    c3e8:	54fef2a1 	b.ne	a23c <f0+0x12c>  // b.any
    c3ec:	17fff790 	b	a22c <f0+0x11c>
    c3f0:	72003c3f 	tst	w1, #0xffff
    c3f4:	54fefd01 	b.ne	a394 <f0+0x284>  // b.any
    c3f8:	17fff7e2 	b	a380 <f0+0x270>
    c3fc:	72003c3f 	tst	w1, #0xffff
    c400:	54ff06c1 	b.ne	a4d8 <f0+0x3c8>  // b.any
    c404:	17fff830 	b	a4c4 <f0+0x3b4>
    c408:	72003c3f 	tst	w1, #0xffff
    c40c:	54ff01c1 	b.ne	a444 <f0+0x334>  // b.any
    c410:	17fff808 	b	a430 <f0+0x320>
    c414:	72003c3f 	tst	w1, #0xffff
    c418:	54ff1181 	b.ne	a648 <f0+0x538>  // b.any
    c41c:	17fff886 	b	a634 <f0+0x524>
    c420:	72003c3f 	tst	w1, #0xffff
    c424:	54ff0a21 	b.ne	a568 <f0+0x458>  // b.any
    c428:	17fff84b 	b	a554 <f0+0x444>
    c42c:	72003c3f 	tst	w1, #0xffff
    c430:	54ff1bc1 	b.ne	a7a8 <f0+0x698>  // b.any
    c434:	17fff8d8 	b	a794 <f0+0x684>
    c438:	72003c3f 	tst	w1, #0xffff
    c43c:	54ff15e1 	b.ne	a6f8 <f0+0x5e8>  // b.any
    c440:	17fff8a9 	b	a6e4 <f0+0x5d4>
    c444:	72003c3f 	tst	w1, #0xffff
    c448:	54ff9f61 	b.ne	b834 <f0+0x1724>  // b.any
    c44c:	17fffcf5 	b	b820 <f0+0x1710>
    c450:	72003c3f 	tst	w1, #0xffff
    c454:	54ff94e1 	b.ne	b6f0 <f0+0x15e0>  // b.any
    c458:	17fffca1 	b	b6dc <f0+0x15cc>
    c45c:	72003c3f 	tst	w1, #0xffff
    c460:	54ffad61 	b.ne	ba0c <f0+0x18fc>  // b.any
    c464:	17fffd65 	b	b9f8 <f0+0x18e8>
    c468:	72003c3f 	tst	w1, #0xffff
    c46c:	54ffa2e1 	b.ne	b8c8 <f0+0x17b8>  // b.any
    c470:	17fffd11 	b	b8b4 <f0+0x17a4>
    c474:	72003c3f 	tst	w1, #0xffff
    c478:	54ffb8c1 	b.ne	bb90 <f0+0x1a80>  // b.any
    c47c:	17fffdc0 	b	bb7c <f0+0x1a6c>
    c480:	72003c3f 	tst	w1, #0xffff
    c484:	54ffb0e1 	b.ne	baa0 <f0+0x1990>  // b.any
    c488:	17fffd81 	b	ba8c <f0+0x197c>
    c48c:	72003c3f 	tst	w1, #0xffff
    c490:	54ffc9a1 	b.ne	bdc4 <f0+0x1cb4>  // b.any
    c494:	17fffe47 	b	bdb0 <f0+0x1ca0>
    c498:	72003c3f 	tst	w1, #0xffff
    c49c:	54ffbe41 	b.ne	bc64 <f0+0x1b54>  // b.any
    c4a0:	17fffdec 	b	bc50 <f0+0x1b40>
    c4a4:	72003c3f 	tst	w1, #0xffff
    c4a8:	54ffd341 	b.ne	bf10 <f0+0x1e00>  // b.any
    c4ac:	17fffe94 	b	befc <f0+0x1dec>
    c4b0:	72003c3f 	tst	w1, #0xffff
    c4b4:	54ffcd21 	b.ne	be58 <f0+0x1d48>  // b.any
    c4b8:	17fffe63 	b	be44 <f0+0x1d34>
    c4bc:	72003c3f 	tst	w1, #0xffff
    c4c0:	54ffdd01 	b.ne	c060 <f0+0x1f50>  // b.any
    c4c4:	17fffee2 	b	c04c <f0+0x1f3c>
    c4c8:	72003c3f 	tst	w1, #0xffff
    c4cc:	54ffd7e1 	b.ne	bfc8 <f0+0x1eb8>  // b.any
    c4d0:	17fffeb9 	b	bfb4 <f0+0x1ea4>
    c4d4:	72003c3f 	tst	w1, #0xffff
    c4d8:	54ffe7c1 	b.ne	c1d0 <f0+0x20c0>  // b.any
    c4dc:	17ffff38 	b	c1bc <f0+0x20ac>
    c4e0:	72003c3f 	tst	w1, #0xffff
    c4e4:	54ffe1a1 	b.ne	c118 <f0+0x2008>  // b.any
    c4e8:	17ffff07 	b	c104 <f0+0x1ff4>
    c4ec:	72003c3f 	tst	w1, #0xffff
    c4f0:	54fff241 	b.ne	c338 <f0+0x2228>  // b.any
    c4f4:	17ffff8c 	b	c324 <f0+0x2214>
    c4f8:	72003c3f 	tst	w1, #0xffff
    c4fc:	54ffeb41 	b.ne	c264 <f0+0x2154>  // b.any
    c500:	17ffff54 	b	c250 <f0+0x2140>
    c504:	72003c3f 	tst	w1, #0xffff
    c508:	54ff2181 	b.ne	a938 <f0+0x828>  // b.any
    c50c:	17fff906 	b	a924 <f0+0x814>
    c510:	72003c3f 	tst	w1, #0xffff
    c514:	54ff1a21 	b.ne	a858 <f0+0x748>  // b.any
    c518:	17fff8cb 	b	a844 <f0+0x734>
    c51c:	72003c3f 	tst	w1, #0xffff
    c520:	54ff2be1 	b.ne	aa9c <f0+0x98c>  // b.any
    c524:	17fff959 	b	aa88 <f0+0x978>
    c528:	72003c3f 	tst	w1, #0xffff
    c52c:	54ff25e1 	b.ne	a9e8 <f0+0x8d8>  // b.any
    c530:	17fff929 	b	a9d4 <f0+0x8c4>
    c534:	72003c3f 	tst	w1, #0xffff
    c538:	54ff3781 	b.ne	ac28 <f0+0xb18>  // b.any
    c53c:	17fff9b6 	b	ac14 <f0+0xb04>
    c540:	72003c3f 	tst	w1, #0xffff
    c544:	54ff3081 	b.ne	ab54 <f0+0xa44>  // b.any
    c548:	17fff97e 	b	ab40 <f0+0xa30>
    c54c:	72003c3f 	tst	w1, #0xffff
    c550:	54ff4201 	b.ne	ad90 <f0+0xc80>  // b.any
    c554:	17fffa0a 	b	ad7c <f0+0xc6c>
    c558:	72003c3f 	tst	w1, #0xffff
    c55c:	54ff3b01 	b.ne	acbc <f0+0xbac>  // b.any
    c560:	17fff9d2 	b	aca8 <f0+0xb98>
    c564:	72003c3f 	tst	w1, #0xffff
    c568:	54ff4ca1 	b.ne	aefc <f0+0xdec>  // b.any
    c56c:	17fffa5f 	b	aee8 <f0+0xdd8>
    c570:	72003c3f 	tst	w1, #0xffff
    c574:	54ff4781 	b.ne	ae64 <f0+0xd54>  // b.any
    c578:	17fffa36 	b	ae50 <f0+0xd40>
    c57c:	72003c3f 	tst	w1, #0xffff
    c580:	54ff6281 	b.ne	b1d0 <f0+0x10c0>  // b.any
    c584:	17fffb0e 	b	b1bc <f0+0x10ac>
    c588:	72003c3f 	tst	w1, #0xffff
    c58c:	54ff5d81 	b.ne	b13c <f0+0x102c>  // b.any
    c590:	17fffae6 	b	b128 <f0+0x1018>
    c594:	72003c3f 	tst	w1, #0xffff
    c598:	54ff70c1 	b.ne	b3b0 <f0+0x12a0>  // b.any
    c59c:	17fffb80 	b	b39c <f0+0x128c>
    c5a0:	72003c3f 	tst	w1, #0xffff
    c5a4:	54ff6721 	b.ne	b288 <f0+0x1178>  // b.any
    c5a8:	17fffb33 	b	b274 <f0+0x1164>
    c5ac:	72003c3f 	tst	w1, #0xffff
    c5b0:	54ff7e21 	b.ne	b574 <f0+0x1464>  // b.any
    c5b4:	17fffbeb 	b	b560 <f0+0x1450>
    c5b8:	72003c3f 	tst	w1, #0xffff
    c5bc:	54ff7721 	b.ne	b4a0 <f0+0x1390>  // b.any
    c5c0:	17fffbb3 	b	b48c <f0+0x137c>
    c5c4:	aa1403e0 	mov	x0, x20
    c5c8:	97ffdf12 	bl	4210 <fwp_rc_forget_slot.part.0>
    c5cc:	17ffff59 	b	c330 <f0+0x2220>
    c5d0:	aa1703e0 	mov	x0, x23
    c5d4:	97ffdf0f 	bl	4210 <fwp_rc_forget_slot.part.0>
    c5d8:	17fff76d 	b	a38c <f0+0x27c>
    c5dc:	aa1703e0 	mov	x0, x23
    c5e0:	97ffdf0c 	bl	4210 <fwp_rc_forget_slot.part.0>
    c5e4:	17fff796 	b	a43c <f0+0x32c>
    c5e8:	aa1703e0 	mov	x0, x23
    c5ec:	97ffdf09 	bl	4210 <fwp_rc_forget_slot.part.0>
    c5f0:	17fff7b8 	b	a4d0 <f0+0x3c0>
    c5f4:	aa1703e0 	mov	x0, x23
    c5f8:	97ffdf06 	bl	4210 <fwp_rc_forget_slot.part.0>
    c5fc:	17fff7d9 	b	a560 <f0+0x450>
    c600:	aa1703e0 	mov	x0, x23
    c604:	97ffdf03 	bl	4210 <fwp_rc_forget_slot.part.0>
    c608:	17fff80e 	b	a640 <f0+0x530>
    c60c:	aa1703e0 	mov	x0, x23
    c610:	97ffdf00 	bl	4210 <fwp_rc_forget_slot.part.0>
    c614:	17fff837 	b	a6f0 <f0+0x5e0>
    c618:	aa1703e0 	mov	x0, x23
    c61c:	97ffdefd 	bl	4210 <fwp_rc_forget_slot.part.0>
    c620:	17fff860 	b	a7a0 <f0+0x690>
    c624:	aa1703e0 	mov	x0, x23
    c628:	97ffdefa 	bl	4210 <fwp_rc_forget_slot.part.0>
    c62c:	17fff889 	b	a850 <f0+0x740>
    c630:	aa1703e0 	mov	x0, x23
    c634:	97ffdef7 	bl	4210 <fwp_rc_forget_slot.part.0>
    c638:	17fff8be 	b	a930 <f0+0x820>
    c63c:	aa1703e0 	mov	x0, x23
    c640:	97ffdef4 	bl	4210 <fwp_rc_forget_slot.part.0>
    c644:	17fff8e7 	b	a9e0 <f0+0x8d0>
    c648:	aa1703e0 	mov	x0, x23
    c64c:	97ffdef1 	bl	4210 <fwp_rc_forget_slot.part.0>
    c650:	17fff911 	b	aa94 <f0+0x984>
    c654:	aa1703e0 	mov	x0, x23
    c658:	97ffdeee 	bl	4210 <fwp_rc_forget_slot.part.0>
    c65c:	17fff93c 	b	ab4c <f0+0xa3c>
    c660:	aa1703e0 	mov	x0, x23
    c664:	97ffdeeb 	bl	4210 <fwp_rc_forget_slot.part.0>
    c668:	17fff96e 	b	ac20 <f0+0xb10>
    c66c:	aa1703e0 	mov	x0, x23
    c670:	97ffdee8 	bl	4210 <fwp_rc_forget_slot.part.0>
    c674:	17fff990 	b	acb4 <f0+0xba4>
    c678:	aa1703e0 	mov	x0, x23
    c67c:	97ffdee5 	bl	4210 <fwp_rc_forget_slot.part.0>
    c680:	17fff9c2 	b	ad88 <f0+0xc78>
    c684:	aa1703e0 	mov	x0, x23
    c688:	97ffdee2 	bl	4210 <fwp_rc_forget_slot.part.0>
    c68c:	17fff9f4 	b	ae5c <f0+0xd4c>
    c690:	aa1703e0 	mov	x0, x23
    c694:	97ffdedf 	bl	4210 <fwp_rc_forget_slot.part.0>
    c698:	17fffa17 	b	aef4 <f0+0xde4>
    c69c:	aa1703e0 	mov	x0, x23
    c6a0:	97ffdedc 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6a4:	17fffaa4 	b	b134 <f0+0x1024>
    c6a8:	aa1703e0 	mov	x0, x23
    c6ac:	97ffded9 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6b0:	17fffac6 	b	b1c8 <f0+0x10b8>
    c6b4:	aa1703e0 	mov	x0, x23
    c6b8:	97ffded6 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6bc:	17fffaf1 	b	b280 <f0+0x1170>
    c6c0:	aa1703e0 	mov	x0, x23
    c6c4:	97ffded3 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6c8:	17fffb38 	b	b3a8 <f0+0x1298>
    c6cc:	aa1703e0 	mov	x0, x23
    c6d0:	97ffded0 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6d4:	17fffb71 	b	b498 <f0+0x1388>
    c6d8:	aa1503e0 	mov	x0, x21
    c6dc:	97ffdecd 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6e0:	17fffba3 	b	b56c <f0+0x145c>
    c6e4:	aa1503e0 	mov	x0, x21
    c6e8:	97ffdeca 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6ec:	17fffbff 	b	b6e8 <f0+0x15d8>
    c6f0:	aa1703e0 	mov	x0, x23
    c6f4:	97ffdec7 	bl	4210 <fwp_rc_forget_slot.part.0>
    c6f8:	17fffc4d 	b	b82c <f0+0x171c>
    c6fc:	aa1503e0 	mov	x0, x21
    c700:	97ffdec4 	bl	4210 <fwp_rc_forget_slot.part.0>
    c704:	17fffc6f 	b	b8c0 <f0+0x17b0>
    c708:	aa1703e0 	mov	x0, x23
    c70c:	97ffdec1 	bl	4210 <fwp_rc_forget_slot.part.0>
    c710:	17fffcbd 	b	ba04 <f0+0x18f4>
    c714:	aa1703e0 	mov	x0, x23
    c718:	97ffdebe 	bl	4210 <fwp_rc_forget_slot.part.0>
    c71c:	17fffcdf 	b	ba98 <f0+0x1988>
    c720:	aa1703e0 	mov	x0, x23
    c724:	97ffdebb 	bl	4210 <fwp_rc_forget_slot.part.0>
    c728:	17fffd18 	b	bb88 <f0+0x1a78>
    c72c:	aa1703e0 	mov	x0, x23
    c730:	97ffdeb8 	bl	4210 <fwp_rc_forget_slot.part.0>
    c734:	17fffd4a 	b	bc5c <f0+0x1b4c>
    c738:	aa1703e0 	mov	x0, x23
    c73c:	97ffdeb5 	bl	4210 <fwp_rc_forget_slot.part.0>
    c740:	17fffd9f 	b	bdbc <f0+0x1cac>
    c744:	aa1703e0 	mov	x0, x23
    c748:	97ffdeb2 	bl	4210 <fwp_rc_forget_slot.part.0>
    c74c:	17fffdc1 	b	be50 <f0+0x1d40>
    c750:	aa1703e0 	mov	x0, x23
    c754:	97ffdeaf 	bl	4210 <fwp_rc_forget_slot.part.0>
    c758:	17fffdec 	b	bf08 <f0+0x1df8>
    c75c:	aa1703e0 	mov	x0, x23
    c760:	97ffdeac 	bl	4210 <fwp_rc_forget_slot.part.0>
    c764:	17fffe17 	b	bfc0 <f0+0x1eb0>
    c768:	aa1703e0 	mov	x0, x23
    c76c:	97ffdea9 	bl	4210 <fwp_rc_forget_slot.part.0>
    c770:	17fffe3a 	b	c058 <f0+0x1f48>
    c774:	aa1703e0 	mov	x0, x23
    c778:	97ffdea6 	bl	4210 <fwp_rc_forget_slot.part.0>
    c77c:	17fffe65 	b	c110 <f0+0x2000>
    c780:	aa1703e0 	mov	x0, x23
    c784:	97ffdea3 	bl	4210 <fwp_rc_forget_slot.part.0>
    c788:	17fffe90 	b	c1c8 <f0+0x20b8>
    c78c:	aa1703e0 	mov	x0, x23
    c790:	97ffdea0 	bl	4210 <fwp_rc_forget_slot.part.0>
    c794:	17fffeb2 	b	c25c <f0+0x214c>
    c798:	97ffd85e 	bl	2910 <__stack_chk_fail@plt>
    c79c:	97ffd871 	bl	2960 <abort@plt>

000000000000c7a0 <fwp_main_thread>:
    c7a0:	d10443ff 	sub	sp, sp, #0x110
    c7a4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c7a8:	f947f400 	ldr	x0, [x0, #4072]
    c7ac:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c7b0:	910303fd 	add	x29, sp, #0xc0
    c7b4:	a90d53f3 	stp	x19, x20, [sp, #208]
    c7b8:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xc10>
    c7bc:	91174261 	add	x1, x19, #0x5d0
    c7c0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c7c4:	b953a421 	ldr	w1, [x1, #5028]
    c7c8:	f9400002 	ldr	x2, [x0]
    c7cc:	f9005fe2 	str	x2, [sp, #184]
    c7d0:	d2800002 	mov	x2, #0x0                   	// #0
    c7d4:	34000ea1 	cbz	w1, c9a8 <fwp_main_thread+0x208>
    c7d8:	91174273 	add	x19, x19, #0x5d0
    c7dc:	b953aa60 	ldr	w0, [x19, #5032]
    c7e0:	35000dc0 	cbnz	w0, c998 <fwp_main_thread+0x1f8>
    c7e4:	91001fe2 	add	x2, sp, #0x7
    c7e8:	900000b4 	adrp	x20, 20000 <__data_start>
    c7ec:	900000a3 	adrp	x3, 20000 <__data_start>
    c7f0:	9101c293 	add	x19, x20, #0x70
    c7f4:	910fc063 	add	x3, x3, #0x3f0
    c7f8:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c7fc:	d2a00025 	mov	x5, #0x10000               	// #65536
    c800:	910023e0 	add	x0, sp, #0x8
    c804:	d2800001 	mov	x1, #0x0                   	// #0
    c808:	f90007e3 	str	x3, [sp, #8]
    c80c:	b90013ff 	str	wzr, [sp, #16]
    c810:	a9019262 	stp	x2, x4, [x19, #24]
    c814:	f9000fe5 	str	x5, [sp, #24]
    c818:	97ffd7d6 	bl	2770 <sigaltstack@plt>
    c81c:	35000220 	cbnz	w0, c860 <fwp_main_thread+0xc0>
    c820:	4f000400 	movi	v0.4s, #0x0
    c824:	9100a3e0 	add	x0, sp, #0x28
    c828:	f0ffffa1 	adrp	x1, 3000 <fwp_range_release+0x30>
    c82c:	52800082 	mov	w2, #0x4                   	// #4
    c830:	9103c021 	add	x1, x1, #0xf0
    c834:	72a10002 	movk	w2, #0x800, lsl #16
    c838:	910083f5 	add	x21, sp, #0x20
    c83c:	f90013e1 	str	x1, [sp, #32]
    c840:	3d802000 	str	q0, [x0, #128]
    c844:	b900abe2 	str	w2, [sp, #168]
    c848:	ad000000 	stp	q0, q0, [x0]
    c84c:	ad010000 	stp	q0, q0, [x0, #32]
    c850:	ad020000 	stp	q0, q0, [x0, #64]
    c854:	ad030000 	stp	q0, q0, [x0, #96]
    c858:	97ffd81e 	bl	28d0 <sigemptyset@plt>
    c85c:	340000c0 	cbz	w0, c874 <fwp_main_thread+0xd4>
    c860:	b0000000 	adrp	x0, d000 <__divti3+0x320>
    c864:	9129c000 	add	x0, x0, #0xa70
    c868:	a90f63f7 	stp	x23, x24, [sp, #240]
    c86c:	f90083f9 	str	x25, [sp, #256]
    c870:	97ffde48 	bl	4190 <fwp_trap>
    c874:	aa1503e1 	mov	x1, x21
    c878:	d2800002 	mov	x2, #0x0                   	// #0
    c87c:	52800160 	mov	w0, #0xb                   	// #11
    c880:	97ffd82c 	bl	2930 <sigaction@plt>
    c884:	35fffee0 	cbnz	w0, c860 <fwp_main_thread+0xc0>
    c888:	aa1503e1 	mov	x1, x21
    c88c:	d2800002 	mov	x2, #0x0                   	// #0
    c890:	528000e0 	mov	w0, #0x7                   	// #7
    c894:	97ffd827 	bl	2930 <sigaction@plt>
    c898:	35fffe40 	cbnz	w0, c860 <fwp_main_thread+0xc0>
    c89c:	b9434a60 	ldr	w0, [x19, #840]
    c8a0:	34000880 	cbz	w0, c9b0 <fwp_main_thread+0x210>
    c8a4:	a90f63f7 	stp	x23, x24, [sp, #240]
    c8a8:	9101c293 	add	x19, x20, #0x70
    c8ac:	b9434e60 	ldr	w0, [x19, #844]
    c8b0:	34001e80 	cbz	w0, cc80 <fwp_main_thread+0x4e0>
    c8b4:	9101c296 	add	x22, x20, #0x70
    c8b8:	f9400ad5 	ldr	x21, [x22, #16]
    c8bc:	b4000d95 	cbz	x21, ca6c <fwp_main_thread+0x2cc>
    c8c0:	910102b7 	add	x23, x21, #0x40
    c8c4:	f90083f9 	str	x25, [sp, #256]
    c8c8:	52800038 	mov	w24, #0x1                   	// #1
    c8cc:	39414ab9 	ldrb	w25, [x21, #82]
    c8d0:	39014ab8 	strb	w24, [x21, #82]
    c8d4:	d503201f 	nop
    c8d8:	f94016a0 	ldr	x0, [x21, #40]
    c8dc:	b4000c40 	cbz	x0, ca64 <fwp_main_thread+0x2c4>
    c8e0:	f94032a1 	ldr	x1, [x21, #96]
    c8e4:	394146a0 	ldrb	w0, [x21, #81]
    c8e8:	b4000861 	cbz	x1, c9f4 <fwp_main_thread+0x254>
    c8ec:	36000720 	tbz	w0, #0, c9d0 <fwp_main_thread+0x230>
    c8f0:	f9400ad3 	ldr	x19, [x22, #16]
    c8f4:	f94022a0 	ldr	x0, [x21, #64]
    c8f8:	39414a61 	ldrb	w1, [x19, #82]
    c8fc:	37000a41 	tbnz	w1, #0, ca44 <fwp_main_thread+0x2a4>
    c900:	f9403261 	ldr	x1, [x19, #96]
    c904:	a911fe77 	stp	x23, xzr, [x19, #280]
    c908:	f9009660 	str	x0, [x19, #296]
    c90c:	b4000040 	cbz	x0, c914 <fwp_main_thread+0x174>
    c910:	f9009013 	str	x19, [x0, #288]
    c914:	f90022b3 	str	x19, [x21, #64]
    c918:	b4000101 	cbz	x1, c938 <fwp_main_thread+0x198>
    c91c:	f9406ec0 	ldr	x0, [x22, #216]
    c920:	39015678 	strb	w24, [x19, #85]
    c924:	f9003661 	str	x1, [x19, #104]
    c928:	a910827f 	stp	xzr, x0, [x19, #264]
    c92c:	b4000040 	cbz	x0, c934 <fwp_main_thread+0x194>
    c930:	f9008413 	str	x19, [x0, #264]
    c934:	f9006ed3 	str	x19, [x22, #216]
    c938:	39015a7f 	strb	wzr, [x19, #86]
    c93c:	97ffe889 	bl	6b60 <fwp_block>
    c940:	f9408e62 	ldr	x2, [x19, #280]
    c944:	b4000142 	cbz	x2, c96c <fwp_main_thread+0x1cc>
    c948:	a9520261 	ldp	x1, x0, [x19, #288]
    c94c:	b4000881 	cbz	x1, ca5c <fwp_main_thread+0x2bc>
    c950:	f9009420 	str	x0, [x1, #296]
    c954:	f9409660 	ldr	x0, [x19, #296]
    c958:	b4000040 	cbz	x0, c960 <fwp_main_thread+0x1c0>
    c95c:	f9009001 	str	x1, [x0, #288]
    c960:	91080260 	add	x0, x19, #0x200
    c964:	f900967f 	str	xzr, [x19, #296]
    c968:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c96c:	39415660 	ldrb	w0, [x19, #85]
    c970:	3607fb40 	tbz	w0, #0, c8d8 <fwp_main_thread+0x138>
    c974:	a9508261 	ldp	x1, x0, [x19, #264]
    c978:	b4001801 	cbz	x1, cc78 <fwp_main_thread+0x4d8>
    c97c:	f9008820 	str	x0, [x1, #272]
    c980:	b4000040 	cbz	x0, c988 <fwp_main_thread+0x1e8>
    c984:	f9008401 	str	x1, [x0, #264]
    c988:	91080260 	add	x0, x19, #0x200
    c98c:	3901567f 	strb	wzr, [x19, #85]
    c990:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c994:	17ffffd1 	b	c8d8 <fwp_main_thread+0x138>
    c998:	f0ffffa0 	adrp	x0, 3000 <fwp_range_release+0x30>
    c99c:	91321000 	add	x0, x0, #0xc84
    c9a0:	9400028c 	bl	d3d0 <atexit>
    c9a4:	17ffff90 	b	c7e4 <fwp_main_thread+0x44>
    c9a8:	97ffdd12 	bl	3df0 <fwp_heap_init>
    c9ac:	17ffff8b 	b	c7d8 <fwp_main_thread+0x38>
    c9b0:	f0ffffa0 	adrp	x0, 3000 <fwp_range_release+0x30>
    c9b4:	91078000 	add	x0, x0, #0x1e0
    c9b8:	94000286 	bl	d3d0 <atexit>
    c9bc:	a90f63f7 	stp	x23, x24, [sp, #240]
    c9c0:	35001860 	cbnz	w0, cccc <fwp_main_thread+0x52c>
    c9c4:	52800020 	mov	w0, #0x1                   	// #1
    c9c8:	b9034a60 	str	w0, [x19, #840]
    c9cc:	17ffffb7 	b	c8a8 <fwp_main_thread+0x108>
    c9d0:	97ffe010 	bl	4a10 <fwp_now_ns>
    c9d4:	f94032a1 	ldr	x1, [x21, #96]
    c9d8:	eb01001f 	cmp	x0, x1
    c9dc:	540000ab 	b.lt	c9f0 <fwp_main_thread+0x250>  // b.tstop
    c9e0:	394142a0 	ldrb	w0, [x21, #80]
    c9e4:	37000060 	tbnz	w0, #0, c9f0 <fwp_main_thread+0x250>
    c9e8:	aa1503e0 	mov	x0, x21
    c9ec:	97ffdb61 	bl	3770 <fwp_cancel_tree.part.0>
    c9f0:	394146a0 	ldrb	w0, [x21, #81]
    c9f4:	f9400ad3 	ldr	x19, [x22, #16]
    c9f8:	39414a62 	ldrb	w2, [x19, #82]
    c9fc:	3707f7a0 	tbnz	w0, #0, c8f0 <fwp_main_thread+0x150>
    ca00:	f94032a1 	ldr	x1, [x21, #96]
    ca04:	370001c2 	tbnz	w2, #0, ca3c <fwp_main_thread+0x29c>
    ca08:	f9403260 	ldr	x0, [x19, #96]
    ca0c:	b4000180 	cbz	x0, ca3c <fwp_main_thread+0x29c>
    ca10:	b4000061 	cbz	x1, ca1c <fwp_main_thread+0x27c>
    ca14:	eb01001f 	cmp	x0, x1
    ca18:	9a81d000 	csel	x0, x0, x1, le
    ca1c:	f94022a1 	ldr	x1, [x21, #64]
    ca20:	a911fe77 	stp	x23, xzr, [x19, #280]
    ca24:	f9009661 	str	x1, [x19, #296]
    ca28:	b4001361 	cbz	x1, cc94 <fwp_main_thread+0x4f4>
    ca2c:	f9009033 	str	x19, [x1, #288]
    ca30:	aa0003e1 	mov	x1, x0
    ca34:	f90022b3 	str	x19, [x21, #64]
    ca38:	17ffffb9 	b	c91c <fwp_main_thread+0x17c>
    ca3c:	f94022a0 	ldr	x0, [x21, #64]
    ca40:	17ffffb1 	b	c904 <fwp_main_thread+0x164>
    ca44:	a911fe77 	stp	x23, xzr, [x19, #280]
    ca48:	f9009660 	str	x0, [x19, #296]
    ca4c:	b4000040 	cbz	x0, ca54 <fwp_main_thread+0x2b4>
    ca50:	f9009013 	str	x19, [x0, #288]
    ca54:	f90022b3 	str	x19, [x21, #64]
    ca58:	17ffffb8 	b	c938 <fwp_main_thread+0x198>
    ca5c:	f9000040 	str	x0, [x2]
    ca60:	17ffffbe 	b	c958 <fwp_main_thread+0x1b8>
    ca64:	39014ab9 	strb	w25, [x21, #82]
    ca68:	f94083f9 	ldr	x25, [sp, #256]
    ca6c:	9101c293 	add	x19, x20, #0x70
    ca70:	f9419660 	ldr	x0, [x19, #808]
    ca74:	b5000060 	cbnz	x0, ca80 <fwp_main_thread+0x2e0>
    ca78:	f9419e60 	ldr	x0, [x19, #824]
    ca7c:	b4001120 	cbz	x0, cca0 <fwp_main_thread+0x500>
    ca80:	9101c280 	add	x0, x20, #0x70
    ca84:	f9400800 	ldr	x0, [x0, #16]
    ca88:	9101c281 	add	x1, x20, #0x70
    ca8c:	f941b026 	ldr	x6, [x1, #864]
    ca90:	b903583f 	str	wzr, [x1, #856]
    ca94:	eb0000df 	cmp	x6, x0
    ca98:	540011e1 	b.ne	ccd4 <fwp_main_thread+0x534>  // b.any
    ca9c:	b40003c0 	cbz	x0, cb14 <fwp_main_thread+0x374>
    caa0:	f9418025 	ldr	x5, [x1, #768]
    caa4:	52800021 	mov	w1, #0x1                   	// #1
    caa8:	39014801 	strb	w1, [x0, #82]
    caac:	b4000345 	cbz	x5, cb14 <fwp_main_thread+0x374>
    cab0:	394140a0 	ldrb	w0, [x5, #80]
    cab4:	37000060 	tbnz	w0, #0, cac0 <fwp_main_thread+0x320>
    cab8:	aa0503e0 	mov	x0, x5
    cabc:	97ffdb2d 	bl	3770 <fwp_cancel_tree.part.0>
    cac0:	f9409ca5 	ldr	x5, [x5, #312]
    cac4:	b5ffff65 	cbnz	x5, cab0 <fwp_main_thread+0x310>
    cac8:	9101c293 	add	x19, x20, #0x70
    cacc:	52800035 	mov	w21, #0x1                   	// #1
    cad0:	f94028c0 	ldr	x0, [x6, #80]
    cad4:	f2001c1f 	tst	x0, #0xff000000ff
    cad8:	540000e1 	b.ne	caf4 <fwp_main_thread+0x354>  // b.any
    cadc:	f9403e60 	ldr	x0, [x19, #120]
    cae0:	390150d5 	strb	w21, [x6, #84]
    cae4:	f90080df 	str	xzr, [x6, #256]
    cae8:	b4000120 	cbz	x0, cb0c <fwp_main_thread+0x36c>
    caec:	f9008006 	str	x6, [x0, #256]
    caf0:	f9003e66 	str	x6, [x19, #120]
    caf4:	97ffe81b 	bl	6b60 <fwp_block>
    caf8:	97ffe7a2 	bl	6980 <fwp_free_zombie>
    cafc:	f9418260 	ldr	x0, [x19, #768]
    cb00:	b40000a0 	cbz	x0, cb14 <fwp_main_thread+0x374>
    cb04:	f941b266 	ldr	x6, [x19, #864]
    cb08:	17fffff2 	b	cad0 <fwp_main_thread+0x330>
    cb0c:	f9004266 	str	x6, [x19, #128]
    cb10:	17fffff8 	b	caf0 <fwp_main_thread+0x350>
    cb14:	9101c295 	add	x21, x20, #0x70
    cb18:	97ffe79a 	bl	6980 <fwp_free_zombie>
    cb1c:	f94042a0 	ldr	x0, [x21, #128]
    cb20:	b5000da0 	cbnz	x0, ccd4 <fwp_main_thread+0x534>
    cb24:	f9406ea0 	ldr	x0, [x21, #216]
    cb28:	b5000d60 	cbnz	x0, ccd4 <fwp_main_thread+0x534>
    cb2c:	b940fab3 	ldr	w19, [x21, #248]
    cb30:	340001f3 	cbz	w19, cb6c <fwp_main_thread+0x3cc>
    cb34:	93407e76 	sxtw	x22, w19
    cb38:	51000673 	sub	w19, w19, #0x1
    cb3c:	d1000ad6 	sub	x22, x22, #0x2
    cb40:	910402b7 	add	x23, x21, #0x100
    cb44:	cb3342d6 	sub	x22, x22, w19, uxtw
    cb48:	93407e73 	sxtw	x19, w19
    cb4c:	d503201f 	nop
    cb50:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    cb54:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    cb58:	b900fab3 	str	w19, [x21, #248]
    cb5c:	d1000673 	sub	x19, x19, #0x1
    cb60:	97ffd7b4 	bl	2a30 <munmap@plt>
    cb64:	eb1302df 	cmp	x22, x19
    cb68:	54ffff41 	b.ne	cb50 <fwp_main_thread+0x3b0>  // b.any
    cb6c:	900000b3 	adrp	x19, 20000 <__data_start>
    cb70:	91004260 	add	x0, x19, #0x10
    cb74:	b9404000 	ldr	w0, [x0, #64]
    cb78:	37f80040 	tbnz	w0, #31, cb80 <fwp_main_thread+0x3e0>
    cb7c:	97ffd769 	bl	2920 <close@plt>
    cb80:	9101c295 	add	x21, x20, #0x70
    cb84:	91004273 	add	x19, x19, #0x10
    cb88:	12800001 	mov	w1, #0xffffffff            	// #-1
    cb8c:	f941baa0 	ldr	x0, [x21, #880]
    cb90:	b9004261 	str	w1, [x19, #64]
    cb94:	f941b6a1 	ldr	x1, [x21, #872]
    cb98:	b40001c0 	cbz	x0, cbd0 <fwp_main_thread+0x430>
    cb9c:	d2800013 	mov	x19, #0x0                   	// #0
    cba0:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    cba4:	b40000e0 	cbz	x0, cbc0 <fwp_main_thread+0x420>
    cba8:	f9400001 	ldr	x1, [x0]
    cbac:	b5000941 	cbnz	x1, ccd4 <fwp_main_thread+0x534>
    cbb0:	f9400401 	ldr	x1, [x0, #8]
    cbb4:	b5000901 	cbnz	x1, ccd4 <fwp_main_thread+0x534>
    cbb8:	97ffde32 	bl	4480 <fwp_mem_free>
    cbbc:	f941b6a1 	ldr	x1, [x21, #872]
    cbc0:	91000673 	add	x19, x19, #0x1
    cbc4:	f941baa0 	ldr	x0, [x21, #880]
    cbc8:	eb00027f 	cmp	x19, x0
    cbcc:	54fffea3 	b.cc	cba0 <fwp_main_thread+0x400>  // b.lo, b.ul, b.last
    cbd0:	aa0103e0 	mov	x0, x1
    cbd4:	97ffde2b 	bl	4480 <fwp_mem_free>
    cbd8:	9101c280 	add	x0, x20, #0x70
    cbdc:	f941b013 	ldr	x19, [x0, #864]
    cbe0:	f901b41f 	str	xzr, [x0, #872]
    cbe4:	f901b81f 	str	xzr, [x0, #880]
    cbe8:	b40001f3 	cbz	x19, cc24 <fwp_main_thread+0x484>
    cbec:	f9401661 	ldr	x1, [x19, #40]
    cbf0:	b5000721 	cbnz	x1, ccd4 <fwp_main_thread+0x534>
    cbf4:	f9405661 	ldr	x1, [x19, #168]
    cbf8:	b50006e1 	cbnz	x1, ccd4 <fwp_main_thread+0x534>
    cbfc:	f9419401 	ldr	x1, [x0, #808]
    cc00:	b50006a1 	cbnz	x1, ccd4 <fwp_main_thread+0x534>
    cc04:	f9419c00 	ldr	x0, [x0, #824]
    cc08:	b5000660 	cbnz	x0, ccd4 <fwp_main_thread+0x534>
    cc0c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    cc10:	90000120 	adrp	x0, 30000 <alt.5+0xfc10>
    cc14:	910fc000 	add	x0, x0, #0x3f0
    cc18:	97ffd732 	bl	28e0 <memset@plt>
    cc1c:	aa1303e0 	mov	x0, x19
    cc20:	97ffde18 	bl	4480 <fwp_mem_free>
    cc24:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    cc28:	f947ec00 	ldr	x0, [x0, #4056]
    cc2c:	9101c294 	add	x20, x20, #0x70
    cc30:	f9400000 	ldr	x0, [x0]
    cc34:	f9000a9f 	str	xzr, [x20, #16]
    cc38:	f901b29f 	str	xzr, [x20, #864]
    cc3c:	97ffd781 	bl	2a40 <fflush@plt>
    cc40:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    cc44:	f947f400 	ldr	x0, [x0, #4072]
    cc48:	f9405fe2 	ldr	x2, [sp, #184]
    cc4c:	f9400001 	ldr	x1, [x0]
    cc50:	eb010042 	subs	x2, x2, x1
    cc54:	d2800001 	mov	x1, #0x0                   	// #0
    cc58:	54000361 	b.ne	ccc4 <fwp_main_thread+0x524>  // b.any
    cc5c:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    cc60:	d2800000 	mov	x0, #0x0                   	// #0
    cc64:	a94d53f3 	ldp	x19, x20, [sp, #208]
    cc68:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    cc6c:	a94f63f7 	ldp	x23, x24, [sp, #240]
    cc70:	910443ff 	add	sp, sp, #0x110
    cc74:	d65f03c0 	ret
    cc78:	f9006ec0 	str	x0, [x22, #216]
    cc7c:	17ffff41 	b	c980 <fwp_main_thread+0x1e0>
    cc80:	97fff524 	bl	a110 <f0>
    cc84:	f901aa60 	str	x0, [x19, #848]
    cc88:	52800021 	mov	w1, #0x1                   	// #1
    cc8c:	b9034e61 	str	w1, [x19, #844]
    cc90:	17ffff09 	b	c8b4 <fwp_main_thread+0x114>
    cc94:	aa0003e1 	mov	x1, x0
    cc98:	f90022b3 	str	x19, [x21, #64]
    cc9c:	17ffff20 	b	c91c <fwp_main_thread+0x17c>
    cca0:	f9419260 	ldr	x0, [x19, #800]
    cca4:	97ffddf7 	bl	4480 <fwp_mem_free>
    cca8:	f901927f 	str	xzr, [x19, #800]
    ccac:	f9400a60 	ldr	x0, [x19, #16]
    ccb0:	f9019a7f 	str	xzr, [x19, #816]
    ccb4:	b4ffeea0 	cbz	x0, ca88 <fwp_main_thread+0x2e8>
    ccb8:	f900541f 	str	xzr, [x0, #168]
    ccbc:	f9005c1f 	str	xzr, [x0, #184]
    ccc0:	17ffff72 	b	ca88 <fwp_main_thread+0x2e8>
    ccc4:	f90083f9 	str	x25, [sp, #256]
    ccc8:	97ffd712 	bl	2910 <__stack_chk_fail@plt>
    cccc:	f90083f9 	str	x25, [sp, #256]
    ccd0:	97ffd938 	bl	31b0 <descent_phase_fail>
    ccd4:	f90083f9 	str	x25, [sp, #256]
    ccd8:	97ffd722 	bl	2960 <abort@plt>
    ccdc:	d503201f 	nop

000000000000cce0 <__divti3>:
    cce0:	d503245f 	bti	c
    cce4:	d2800004 	mov	x4, #0x0                   	// #0
    cce8:	b7f80721 	tbnz	x1, #63, cdcc <__divti3+0xec>
    ccec:	b6f80083 	tbz	x3, #63, ccfc <__divti3+0x1c>
    ccf0:	eb0203e2 	negs	x2, x2
    ccf4:	aa2403e4 	mvn	x4, x4
    ccf8:	da0303e3 	ngc	x3, x3
    ccfc:	aa0203e6 	mov	x6, x2
    cd00:	aa0003e7 	mov	x7, x0
    cd04:	aa0103e5 	mov	x5, x1
    cd08:	b5000583 	cbnz	x3, cdb8 <__divti3+0xd8>
    cd0c:	eb01005f 	cmp	x2, x1
    cd10:	54000e69 	b.ls	cedc <__divti3+0x1fc>  // b.plast
    cd14:	dac01040 	clz	x0, x2
    cd18:	b40000e0 	cbz	x0, cd34 <__divti3+0x54>
    cd1c:	4b0003e1 	neg	w1, w0
    cd20:	9ac020a5 	lsl	x5, x5, x0
    cd24:	9ac02046 	lsl	x6, x2, x0
    cd28:	9ac124e1 	lsr	x1, x7, x1
    cd2c:	aa050025 	orr	x5, x1, x5
    cd30:	9ac020e7 	lsl	x7, x7, x0
    cd34:	d360fcc8 	lsr	x8, x6, #32
    cd38:	92407cc2 	and	x2, x6, #0xffffffff
    cd3c:	9ac808a3 	udiv	x3, x5, x8
    cd40:	9b089465 	msub	x5, x3, x8, x5
    cd44:	aa0303e0 	mov	x0, x3
    cd48:	9b037c41 	mul	x1, x2, x3
    cd4c:	93c780a5 	extr	x5, x5, x7, #32
    cd50:	eb05003f 	cmp	x1, x5
    cd54:	540000a9 	b.ls	cd68 <__divti3+0x88>  // b.plast
    cd58:	ab0500c5 	adds	x5, x6, x5
    cd5c:	d1000460 	sub	x0, x3, #0x1
    cd60:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    cd64:	540015a8 	b.hi	d018 <__divti3+0x338>  // b.pmore
    cd68:	cb0100a5 	sub	x5, x5, x1
    cd6c:	9ac808a3 	udiv	x3, x5, x8
    cd70:	9b089465 	msub	x5, x3, x8, x5
    cd74:	aa0303e1 	mov	x1, x3
    cd78:	9b037c42 	mul	x2, x2, x3
    cd7c:	aa0703e3 	mov	x3, x7
    cd80:	b3607ca3 	bfi	x3, x5, #32, #32
    cd84:	eb03005f 	cmp	x2, x3
    cd88:	540000c9 	b.ls	cda0 <__divti3+0xc0>  // b.plast
    cd8c:	ab0300c3 	adds	x3, x6, x3
    cd90:	d1000425 	sub	x5, x1, #0x1
    cd94:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cd98:	d1000821 	sub	x1, x1, #0x2
    cd9c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    cda0:	aa008020 	orr	x0, x1, x0, lsl #32
    cda4:	d2800001 	mov	x1, #0x0                   	// #0
    cda8:	b4000064 	cbz	x4, cdb4 <__divti3+0xd4>
    cdac:	eb0003e0 	negs	x0, x0
    cdb0:	da0103e1 	ngc	x1, x1
    cdb4:	d65f03c0 	ret
    cdb8:	eb01007f 	cmp	x3, x1
    cdbc:	54000109 	b.ls	cddc <__divti3+0xfc>  // b.plast
    cdc0:	d2800001 	mov	x1, #0x0                   	// #0
    cdc4:	d2800000 	mov	x0, #0x0                   	// #0
    cdc8:	17fffff8 	b	cda8 <__divti3+0xc8>
    cdcc:	eb0003e0 	negs	x0, x0
    cdd0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cdd4:	da0103e1 	ngc	x1, x1
    cdd8:	17ffffc5 	b	ccec <__divti3+0xc>
    cddc:	dac01067 	clz	x7, x3
    cde0:	b40010e7 	cbz	x7, cffc <__divti3+0x31c>
    cde4:	d2800805 	mov	x5, #0x40                  	// #64
    cde8:	cb0700a5 	sub	x5, x5, x7
    cdec:	9ac72063 	lsl	x3, x3, x7
    cdf0:	9ac52448 	lsr	x8, x2, x5
    cdf4:	aa030108 	orr	x8, x8, x3
    cdf8:	9ac52426 	lsr	x6, x1, x5
    cdfc:	92407d0a 	and	x10, x8, #0xffffffff
    ce00:	d360fd09 	lsr	x9, x8, #32
    ce04:	9ac52403 	lsr	x3, x0, x5
    ce08:	9ac72021 	lsl	x1, x1, x7
    ce0c:	aa010063 	orr	x3, x3, x1
    ce10:	9ac72042 	lsl	x2, x2, x7
    ce14:	9ac908cb 	udiv	x11, x6, x9
    ce18:	9b099965 	msub	x5, x11, x9, x6
    ce1c:	aa0b03e1 	mov	x1, x11
    ce20:	9b0b7d46 	mul	x6, x10, x11
    ce24:	93c380a5 	extr	x5, x5, x3, #32
    ce28:	eb0500df 	cmp	x6, x5
    ce2c:	540000a9 	b.ls	ce40 <__divti3+0x160>  // b.plast
    ce30:	ab050105 	adds	x5, x8, x5
    ce34:	d1000561 	sub	x1, x11, #0x1
    ce38:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ce3c:	54000f48 	b.hi	d024 <__divti3+0x344>  // b.pmore
    ce40:	cb0600a6 	sub	x6, x5, x6
    ce44:	9ac908cb 	udiv	x11, x6, x9
    ce48:	9b099969 	msub	x9, x11, x9, x6
    ce4c:	aa0b03e5 	mov	x5, x11
    ce50:	9b0b7d4a 	mul	x10, x10, x11
    ce54:	b3607d23 	bfi	x3, x9, #32, #32
    ce58:	eb03015f 	cmp	x10, x3
    ce5c:	540000a9 	b.ls	ce70 <__divti3+0x190>  // b.plast
    ce60:	ab030103 	adds	x3, x8, x3
    ce64:	d1000565 	sub	x5, x11, #0x1
    ce68:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    ce6c:	54000e28 	b.hi	d030 <__divti3+0x350>  // b.pmore
    ce70:	aa0180a1 	orr	x1, x5, x1, lsl #32
    ce74:	92407c48 	and	x8, x2, #0xffffffff
    ce78:	2a0503e5 	mov	w5, w5
    ce7c:	d360fc42 	lsr	x2, x2, #32
    ce80:	d360fc26 	lsr	x6, x1, #32
    ce84:	cb0a0063 	sub	x3, x3, x10
    ce88:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    ce8c:	9b087caa 	mul	x10, x5, x8
    ce90:	9b087cc8 	mul	x8, x6, x8
    ce94:	9b0220a5 	madd	x5, x5, x2, x8
    ce98:	9b027cc6 	mul	x6, x6, x2
    ce9c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cea0:	8b0900c5 	add	x5, x6, x9
    cea4:	eb02011f 	cmp	x8, x2
    cea8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    ceac:	8b4280c6 	add	x6, x6, x2, lsr #32
    ceb0:	eb06007f 	cmp	x3, x6
    ceb4:	540000e3 	b.cc	ced0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    ceb8:	92407d4a 	and	x10, x10, #0xffffffff
    cebc:	9ac72000 	lsl	x0, x0, x7
    cec0:	8b028142 	add	x2, x10, x2, lsl #32
    cec4:	eb02001f 	cmp	x0, x2
    cec8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    cecc:	54000a01 	b.ne	d00c <__divti3+0x32c>  // b.any
    ced0:	d1000420 	sub	x0, x1, #0x1
    ced4:	d2800001 	mov	x1, #0x0                   	// #0
    ced8:	17ffffb4 	b	cda8 <__divti3+0xc8>
    cedc:	b5000062 	cbnz	x2, cee8 <__divti3+0x208>
    cee0:	d2800022 	mov	x2, #0x1                   	// #1
    cee4:	9ac30846 	udiv	x6, x2, x3
    cee8:	dac010c8 	clz	x8, x6
    ceec:	b5000408 	cbnz	x8, cf6c <__divti3+0x28c>
    cef0:	d360fcc9 	lsr	x9, x6, #32
    cef4:	92407cc5 	and	x5, x6, #0xffffffff
    cef8:	cb060023 	sub	x3, x1, x6
    cefc:	d2800021 	mov	x1, #0x1                   	// #1
    cf00:	9ac90868 	udiv	x8, x3, x9
    cf04:	9b098d03 	msub	x3, x8, x9, x3
    cf08:	aa0803e0 	mov	x0, x8
    cf0c:	9b057d02 	mul	x2, x8, x5
    cf10:	93c78063 	extr	x3, x3, x7, #32
    cf14:	eb03005f 	cmp	x2, x3
    cf18:	540000a9 	b.ls	cf2c <__divti3+0x24c>  // b.plast
    cf1c:	ab0300c3 	adds	x3, x6, x3
    cf20:	d1000500 	sub	x0, x8, #0x1
    cf24:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cf28:	54000968 	b.hi	d054 <__divti3+0x374>  // b.pmore
    cf2c:	cb020063 	sub	x3, x3, x2
    cf30:	9ac90862 	udiv	x2, x3, x9
    cf34:	aa0203e8 	mov	x8, x2
    cf38:	9b098c42 	msub	x2, x2, x9, x3
    cf3c:	aa0703e3 	mov	x3, x7
    cf40:	9b057d05 	mul	x5, x8, x5
    cf44:	b3607c43 	bfi	x3, x2, #32, #32
    cf48:	eb0300bf 	cmp	x5, x3
    cf4c:	540000c9 	b.ls	cf64 <__divti3+0x284>  // b.plast
    cf50:	ab0300c2 	adds	x2, x6, x3
    cf54:	d1000503 	sub	x3, x8, #0x1
    cf58:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cf5c:	d1000908 	sub	x8, x8, #0x2
    cf60:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cf64:	aa008100 	orr	x0, x8, x0, lsl #32
    cf68:	17ffff90 	b	cda8 <__divti3+0xc8>
    cf6c:	9ac820c6 	lsl	x6, x6, x8
    cf70:	d2800803 	mov	x3, #0x40                  	// #64
    cf74:	cb080063 	sub	x3, x3, x8
    cf78:	d360fcc9 	lsr	x9, x6, #32
    cf7c:	9ac82027 	lsl	x7, x1, x8
    cf80:	92407cc5 	and	x5, x6, #0xffffffff
    cf84:	9ac32422 	lsr	x2, x1, x3
    cf88:	9ac32403 	lsr	x3, x0, x3
    cf8c:	aa070063 	orr	x3, x3, x7
    cf90:	9ac9084a 	udiv	x10, x2, x9
    cf94:	9ac82007 	lsl	x7, x0, x8
    cf98:	9b098940 	msub	x0, x10, x9, x2
    cf9c:	aa0a03e1 	mov	x1, x10
    cfa0:	9b0a7ca2 	mul	x2, x5, x10
    cfa4:	93c38000 	extr	x0, x0, x3, #32
    cfa8:	eb00005f 	cmp	x2, x0
    cfac:	540000a9 	b.ls	cfc0 <__divti3+0x2e0>  // b.plast
    cfb0:	ab0000c0 	adds	x0, x6, x0
    cfb4:	d1000541 	sub	x1, x10, #0x1
    cfb8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cfbc:	54000468 	b.hi	d048 <__divti3+0x368>  // b.pmore
    cfc0:	cb020000 	sub	x0, x0, x2
    cfc4:	9ac9080a 	udiv	x10, x0, x9
    cfc8:	9b098140 	msub	x0, x10, x9, x0
    cfcc:	aa0a03e2 	mov	x2, x10
    cfd0:	9b0a7ca8 	mul	x8, x5, x10
    cfd4:	b3607c03 	bfi	x3, x0, #32, #32
    cfd8:	eb03011f 	cmp	x8, x3
    cfdc:	540000a9 	b.ls	cff0 <__divti3+0x310>  // b.plast
    cfe0:	ab0300c3 	adds	x3, x6, x3
    cfe4:	d1000542 	sub	x2, x10, #0x1
    cfe8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cfec:	54000288 	b.hi	d03c <__divti3+0x35c>  // b.pmore
    cff0:	cb080063 	sub	x3, x3, x8
    cff4:	aa018041 	orr	x1, x2, x1, lsl #32
    cff8:	17ffffc2 	b	cf00 <__divti3+0x220>
    cffc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    d000:	d2800001 	mov	x1, #0x0                   	// #0
    d004:	9a9f87e0 	cset	x0, ls	// ls = plast
    d008:	17ffff68 	b	cda8 <__divti3+0xc8>
    d00c:	aa0103e0 	mov	x0, x1
    d010:	d2800001 	mov	x1, #0x0                   	// #0
    d014:	17ffff65 	b	cda8 <__divti3+0xc8>
    d018:	d1000860 	sub	x0, x3, #0x2
    d01c:	8b0600a5 	add	x5, x5, x6
    d020:	17ffff52 	b	cd68 <__divti3+0x88>
    d024:	d1000961 	sub	x1, x11, #0x2
    d028:	8b0800a5 	add	x5, x5, x8
    d02c:	17ffff85 	b	ce40 <__divti3+0x160>
    d030:	d1000965 	sub	x5, x11, #0x2
    d034:	8b080063 	add	x3, x3, x8
    d038:	17ffff8e 	b	ce70 <__divti3+0x190>
    d03c:	d1000942 	sub	x2, x10, #0x2
    d040:	8b060063 	add	x3, x3, x6
    d044:	17ffffeb 	b	cff0 <__divti3+0x310>
    d048:	d1000941 	sub	x1, x10, #0x2
    d04c:	8b060000 	add	x0, x0, x6
    d050:	17ffffdc 	b	cfc0 <__divti3+0x2e0>
    d054:	d1000900 	sub	x0, x8, #0x2
    d058:	8b060063 	add	x3, x3, x6
    d05c:	17ffffb4 	b	cf2c <__divti3+0x24c>

000000000000d060 <__modti3>:
    d060:	d503245f 	bti	c
    d064:	d2800004 	mov	x4, #0x0                   	// #0
    d068:	b6f80081 	tbz	x1, #63, d078 <__modti3+0x18>
    d06c:	eb0003e0 	negs	x0, x0
    d070:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    d074:	da0103e1 	ngc	x1, x1
    d078:	f100007f 	cmp	x3, #0x0
    d07c:	5400128b 	b.lt	d2cc <__modti3+0x26c>  // b.tstop
    d080:	aa0003e7 	mov	x7, x0
    d084:	aa0103e6 	mov	x6, x1
    d088:	540004e1 	b.ne	d124 <__modti3+0xc4>  // b.any
    d08c:	eb02003f 	cmp	x1, x2
    d090:	54000dc2 	b.cs	d248 <__modti3+0x1e8>  // b.hs, b.nlast
    d094:	dac01043 	clz	x3, x2
    d098:	aa0303e5 	mov	x5, x3
    d09c:	b40000e3 	cbz	x3, d0b8 <__modti3+0x58>
    d0a0:	4b0303e6 	neg	w6, w3
    d0a4:	9ac32021 	lsl	x1, x1, x3
    d0a8:	9ac32042 	lsl	x2, x2, x3
    d0ac:	9ac62406 	lsr	x6, x0, x6
    d0b0:	aa0100c6 	orr	x6, x6, x1
    d0b4:	9ac32007 	lsl	x7, x0, x3
    d0b8:	d360fc40 	lsr	x0, x2, #32
    d0bc:	92407c43 	and	x3, x2, #0xffffffff
    d0c0:	9ac008c1 	udiv	x1, x6, x0
    d0c4:	9b009826 	msub	x6, x1, x0, x6
    d0c8:	9b017c61 	mul	x1, x3, x1
    d0cc:	93c780c6 	extr	x6, x6, x7, #32
    d0d0:	eb06003f 	cmp	x1, x6
    d0d4:	540000a9 	b.ls	d0e8 <__modti3+0x88>  // b.plast
    d0d8:	ab060046 	adds	x6, x2, x6
    d0dc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    d0e0:	8b0200c8 	add	x8, x6, x2
    d0e4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    d0e8:	cb0100c6 	sub	x6, x6, x1
    d0ec:	9ac008c8 	udiv	x8, x6, x0
    d0f0:	9b009901 	msub	x1, x8, x0, x6
    d0f4:	aa0703e0 	mov	x0, x7
    d0f8:	9b087c63 	mul	x3, x3, x8
    d0fc:	b3607c20 	bfi	x0, x1, #32, #32
    d100:	eb00007f 	cmp	x3, x0
    d104:	54001088 	b.hi	d314 <__modti3+0x2b4>  // b.pmore
    d108:	cb030000 	sub	x0, x0, x3
    d10c:	9ac52400 	lsr	x0, x0, x5
    d110:	d2800001 	mov	x1, #0x0                   	// #0
    d114:	b4000064 	cbz	x4, d120 <__modti3+0xc0>
    d118:	eb0003e0 	negs	x0, x0
    d11c:	da0103e1 	ngc	x1, x1
    d120:	d65f03c0 	ret
    d124:	dac01066 	clz	x6, x3
    d128:	eb03003f 	cmp	x1, x3
    d12c:	54ffff43 	b.cc	d114 <__modti3+0xb4>  // b.lo, b.ul, b.last
    d130:	93407cc5 	sxtw	x5, w6
    d134:	d2800808 	mov	x8, #0x40                  	// #64
    d138:	cb050108 	sub	x8, x8, x5
    d13c:	9ac62063 	lsl	x3, x3, x6
    d140:	9ac62025 	lsl	x5, x1, x6
    d144:	9ac82447 	lsr	x7, x2, x8
    d148:	aa0300e7 	orr	x7, x7, x3
    d14c:	9ac82423 	lsr	x3, x1, x8
    d150:	92407cec 	and	x12, x7, #0xffffffff
    d154:	d360fcea 	lsr	x10, x7, #32
    d158:	9ac82401 	lsr	x1, x0, x8
    d15c:	aa050021 	orr	x1, x1, x5
    d160:	9ac62042 	lsl	x2, x2, x6
    d164:	9ac62000 	lsl	x0, x0, x6
    d168:	9aca086b 	udiv	x11, x3, x10
    d16c:	9b0a8d63 	msub	x3, x11, x10, x3
    d170:	aa0b03e5 	mov	x5, x11
    d174:	9b0b7d89 	mul	x9, x12, x11
    d178:	93c18063 	extr	x3, x3, x1, #32
    d17c:	eb03013f 	cmp	x9, x3
    d180:	540000a9 	b.ls	d194 <__modti3+0x134>  // b.plast
    d184:	ab0300e3 	adds	x3, x7, x3
    d188:	d1000565 	sub	x5, x11, #0x1
    d18c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    d190:	54001168 	b.hi	d3bc <__modti3+0x35c>  // b.pmore
    d194:	cb090063 	sub	x3, x3, x9
    d198:	9aca086b 	udiv	x11, x3, x10
    d19c:	9b0a8d6a 	msub	x10, x11, x10, x3
    d1a0:	aa0b03e9 	mov	x9, x11
    d1a4:	9b0b7d8c 	mul	x12, x12, x11
    d1a8:	b3607d41 	bfi	x1, x10, #32, #32
    d1ac:	eb01019f 	cmp	x12, x1
    d1b0:	540000a9 	b.ls	d1c4 <__modti3+0x164>  // b.plast
    d1b4:	ab0100e1 	adds	x1, x7, x1
    d1b8:	d1000569 	sub	x9, x11, #0x1
    d1bc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    d1c0:	54000f88 	b.hi	d3b0 <__modti3+0x350>  // b.pmore
    d1c4:	aa058123 	orr	x3, x9, x5, lsl #32
    d1c8:	92407c4b 	and	x11, x2, #0xffffffff
    d1cc:	2a0903e9 	mov	w9, w9
    d1d0:	d360fc4a 	lsr	x10, x2, #32
    d1d4:	d360fc63 	lsr	x3, x3, #32
    d1d8:	cb0c0021 	sub	x1, x1, x12
    d1dc:	aa0a03ec 	mov	x12, x10
    d1e0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    d1e4:	9b0b7d25 	mul	x5, x9, x11
    d1e8:	9b0b7c6b 	mul	x11, x3, x11
    d1ec:	9b0a2d29 	madd	x9, x9, x10, x11
    d1f0:	92407caa 	and	x10, x5, #0xffffffff
    d1f4:	9b0c7c63 	mul	x3, x3, x12
    d1f8:	8b458125 	add	x5, x9, x5, lsr #32
    d1fc:	8b0d0069 	add	x9, x3, x13
    d200:	eb05017f 	cmp	x11, x5
    d204:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    d208:	8b058149 	add	x9, x10, x5, lsl #32
    d20c:	8b458063 	add	x3, x3, x5, lsr #32
    d210:	eb03003f 	cmp	x1, x3
    d214:	54000063 	b.cc	d220 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    d218:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    d21c:	54000082 	b.cs	d22c <__modti3+0x1cc>  // b.hs, b.nlast
    d220:	eb020129 	subs	x9, x9, x2
    d224:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    d228:	cb070063 	sub	x3, x3, x7
    d22c:	eb090000 	subs	x0, x0, x9
    d230:	da030021 	sbc	x1, x1, x3
    d234:	9ac62400 	lsr	x0, x0, x6
    d238:	9ac82028 	lsl	x8, x1, x8
    d23c:	aa000100 	orr	x0, x8, x0
    d240:	9ac62421 	lsr	x1, x1, x6
    d244:	17ffffb4 	b	d114 <__modti3+0xb4>
    d248:	b5000062 	cbnz	x2, d254 <__modti3+0x1f4>
    d24c:	d2800023 	mov	x3, #0x1                   	// #1
    d250:	9ac20862 	udiv	x2, x3, x2
    d254:	dac01048 	clz	x8, x2
    d258:	aa0803e5 	mov	x5, x8
    d25c:	b5000668 	cbnz	x8, d328 <__modti3+0x2c8>
    d260:	cb020020 	sub	x0, x1, x2
    d264:	d360fc49 	lsr	x9, x2, #32
    d268:	92407c4a 	and	x10, x2, #0xffffffff
    d26c:	9ac90801 	udiv	x1, x0, x9
    d270:	9b098020 	msub	x0, x1, x9, x0
    d274:	9b0a7c21 	mul	x1, x1, x10
    d278:	93c78000 	extr	x0, x0, x7, #32
    d27c:	eb00003f 	cmp	x1, x0
    d280:	540000a9 	b.ls	d294 <__modti3+0x234>  // b.plast
    d284:	ab000040 	adds	x0, x2, x0
    d288:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d28c:	8b020003 	add	x3, x0, x2
    d290:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d294:	cb010001 	sub	x1, x0, x1
    d298:	9ac90820 	udiv	x0, x1, x9
    d29c:	9b098403 	msub	x3, x0, x9, x1
    d2a0:	aa0703e1 	mov	x1, x7
    d2a4:	9b0a7c00 	mul	x0, x0, x10
    d2a8:	b3607c61 	bfi	x1, x3, #32, #32
    d2ac:	eb01001f 	cmp	x0, x1
    d2b0:	540000a9 	b.ls	d2c4 <__modti3+0x264>  // b.plast
    d2b4:	ab010041 	adds	x1, x2, x1
    d2b8:	8b020022 	add	x2, x1, x2
    d2bc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    d2c0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    d2c4:	cb000020 	sub	x0, x1, x0
    d2c8:	17ffff91 	b	d10c <__modti3+0xac>
    d2cc:	eb0203e5 	negs	x5, x2
    d2d0:	aa0003e7 	mov	x7, x0
    d2d4:	da0303e8 	ngc	x8, x3
    d2d8:	aa0503e2 	mov	x2, x5
    d2dc:	aa0803e3 	mov	x3, x8
    d2e0:	aa0103e6 	mov	x6, x1
    d2e4:	b4ffed48 	cbz	x8, d08c <__modti3+0x2c>
    d2e8:	eb01011f 	cmp	x8, x1
    d2ec:	54fff148 	b.hi	d114 <__modti3+0xb4>  // b.pmore
    d2f0:	dac01109 	clz	x9, x8
    d2f4:	2a0903e6 	mov	w6, w9
    d2f8:	b5fff1c9 	cbnz	x9, d130 <__modti3+0xd0>
    d2fc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    d300:	54000068 	b.hi	d30c <__modti3+0x2ac>  // b.pmore
    d304:	eb050007 	subs	x7, x0, x5
    d308:	da080021 	sbc	x1, x1, x8
    d30c:	aa0703e0 	mov	x0, x7
    d310:	17ffff81 	b	d114 <__modti3+0xb4>
    d314:	ab000040 	adds	x0, x2, x0
    d318:	8b020002 	add	x2, x0, x2
    d31c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    d320:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    d324:	17ffff79 	b	d108 <__modti3+0xa8>
    d328:	9ac82042 	lsl	x2, x2, x8
    d32c:	d2800803 	mov	x3, #0x40                  	// #64
    d330:	cb080063 	sub	x3, x3, x8
    d334:	d360fc49 	lsr	x9, x2, #32
    d338:	9ac82027 	lsl	x7, x1, x8
    d33c:	92407c4a 	and	x10, x2, #0xffffffff
    d340:	9ac32426 	lsr	x6, x1, x3
    d344:	9ac32403 	lsr	x3, x0, x3
    d348:	aa070063 	orr	x3, x3, x7
    d34c:	9ac908c1 	udiv	x1, x6, x9
    d350:	9ac82007 	lsl	x7, x0, x8
    d354:	9b099820 	msub	x0, x1, x9, x6
    d358:	9b017d41 	mul	x1, x10, x1
    d35c:	93c38000 	extr	x0, x0, x3, #32
    d360:	eb00003f 	cmp	x1, x0
    d364:	540000a9 	b.ls	d378 <__modti3+0x318>  // b.plast
    d368:	ab000040 	adds	x0, x2, x0
    d36c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d370:	8b020006 	add	x6, x0, x2
    d374:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    d378:	cb010000 	sub	x0, x0, x1
    d37c:	9ac90801 	udiv	x1, x0, x9
    d380:	9b098026 	msub	x6, x1, x9, x0
    d384:	aa0303e0 	mov	x0, x3
    d388:	9b017d41 	mul	x1, x10, x1
    d38c:	b3607cc0 	bfi	x0, x6, #32, #32
    d390:	eb00003f 	cmp	x1, x0
    d394:	540000a9 	b.ls	d3a8 <__modti3+0x348>  // b.plast
    d398:	ab000040 	adds	x0, x2, x0
    d39c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    d3a0:	8b020003 	add	x3, x0, x2
    d3a4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    d3a8:	cb010000 	sub	x0, x0, x1
    d3ac:	17ffffb0 	b	d26c <__modti3+0x20c>
    d3b0:	d1000969 	sub	x9, x11, #0x2
    d3b4:	8b070021 	add	x1, x1, x7
    d3b8:	17ffff83 	b	d1c4 <__modti3+0x164>
    d3bc:	d1000965 	sub	x5, x11, #0x2
    d3c0:	8b070063 	add	x3, x3, x7
    d3c4:	17ffff74 	b	d194 <__modti3+0x134>
    d3c8:	d503201f 	nop
    d3cc:	d503201f 	nop

000000000000d3d0 <atexit>:
    d3d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d3d4:	f0000082 	adrp	x2, 20000 <__data_start>
    d3d8:	d2800001 	mov	x1, #0x0                   	// #0
    d3dc:	910003fd 	mov	x29, sp
    d3e0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d3e4:	f9400442 	ldr	x2, [x2, #8]
    d3e8:	17ffd50a 	b	2810 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d3ec <_fini>:
    d3ec:	d503201f 	nop
    d3f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d3f4:	910003fd 	mov	x29, sp
    d3f8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d3fc:	d65f03c0 	ret
