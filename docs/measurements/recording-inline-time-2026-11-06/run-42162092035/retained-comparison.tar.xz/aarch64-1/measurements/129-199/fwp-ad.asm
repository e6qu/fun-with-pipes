
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000045 	adrp	x5, d000 <atexit+0x10>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	910ba0a5 	add	x5, x5, #0x2e8
    2aa0:	f0000044 	adrp	x4, d000 <atexit+0x10>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	910bc084 	add	x4, x4, #0x2f0
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940004f0 	bl	3e90 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	9100c2a1 	add	x1, x21, #0x30
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0xefd0>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9003c20 	str	x0, [x1, #120]
    2b2c:	940006f9 	bl	4710 <fwp_now_ns>
    2b30:	f0000040 	adrp	x0, d000 <atexit+0x10>
    2b34:	91180000 	add	x0, x0, #0x600
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000042 	adrp	x2, c000 <f0+0x22b0>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	910f9042 	add	x2, x2, #0x3e4
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c2b5 	add	x21, x21, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b9430aa0 	ldr	w0, [x21, #776]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	f0000040 	adrp	x0, d000 <atexit+0x10>
    2c4c:	9118c000 	add	x0, x0, #0x630
    2c50:	94000490 	bl	3e90 <fwp_trap>
    2c54:	f0000040 	adrp	x0, d000 <atexit+0x10>
    2c58:	91184000 	add	x0, x0, #0x610
    2c5c:	9400048d 	bl	3e90 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff42 	bl	2970 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffee7 	bl	2830 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	f0000040 	adrp	x0, d000 <atexit+0x10>
    2ca0:	911a2000 	add	x0, x0, #0x688
    2ca4:	9400047b 	bl	3e90 <fwp_trap>
    2ca8:	f0000040 	adrp	x0, d000 <atexit+0x10>
    2cac:	91196000 	add	x0, x0, #0x658
    2cb0:	94000478 	bl	3e90 <fwp_trap>
    2cb4:	f0000040 	adrp	x0, d000 <atexit+0x10>
    2cb8:	911ac000 	add	x0, x0, #0x6b0
    2cbc:	94000475 	bl	3e90 <fwp_trap>
    2cc0:	97fffef0 	bl	2880 <__stack_chk_fail@plt>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91008000 	add	x0, x0, #0x20
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91008021 	add	x1, x1, #0x20
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91008000 	add	x0, x0, #0x20
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91008021 	add	x1, x1, #0x20
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	f0000041 	adrp	x1, d000 <atexit+0x10>
    2eb4:	91334021 	add	x1, x1, #0xcd0
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000040 	adrp	x0, d000 <atexit+0x10>
    3050:	9100a000 	add	x0, x0, #0x28
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	d0000041 	adrp	x1, d000 <atexit+0x10>
    3118:	9132c021 	add	x1, x1, #0xcb0
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    3144:	911502a1 	add	x1, x21, #0x540
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    3158:	9124c0a5 	add	x5, x5, #0x930
    315c:	911502a1 	add	x1, x21, #0x540
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	911502b7 	add	x23, x21, #0x540
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	911502b5 	add	x21, x21, #0x540
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	911502b5 	add	x21, x21, #0x540
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xac0>
    32e8:	9124a0a5 	add	x5, x5, #0x928
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	d0000040 	adrp	x0, d000 <atexit+0x10>
    33f0:	9100a000 	add	x0, x0, #0x28
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	d0000041 	adrp	x1, d000 <atexit+0x10>
    3530:	aa1303e0 	mov	x0, x19
    3534:	91010021 	add	x1, x1, #0x40
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	d0000041 	adrp	x1, d000 <atexit+0x10>
    3544:	aa1303e0 	mov	x0, x19
    3548:	91012021 	add	x1, x1, #0x48
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	d0000041 	adrp	x1, d000 <atexit+0x10>
    3560:	91014021 	add	x1, x1, #0x50
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_format_g.constprop.0>:
    3580:	d10483ff 	sub	sp, sp, #0x120
    3584:	d0000044 	adrp	x4, d000 <atexit+0x10>
    3588:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    358c:	f947f442 	ldr	x2, [x2, #4072]
    3590:	91016084 	add	x4, x4, #0x58
    3594:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3598:	9102c3fd 	add	x29, sp, #0xb0
    359c:	d2800803 	mov	x3, #0x40                  	// #64
    35a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    35a4:	93407c38 	sxtw	x24, w1
    35a8:	aa0303e1 	mov	x1, x3
    35ac:	fd008be8 	str	d8, [sp, #272]
    35b0:	1e604008 	fmov	d8, d0
    35b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    35b8:	910083f4 	add	x20, sp, #0x20
    35bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    35c0:	aa0003f5 	mov	x21, x0
    35c4:	a91073fb 	stp	x27, x28, [sp, #256]
    35c8:	5100071c 	sub	w28, w24, #0x1
    35cc:	2a1c03e5 	mov	w5, w28
    35d0:	f9400040 	ldr	x0, [x2]
    35d4:	f90057e0 	str	x0, [sp, #168]
    35d8:	d2800000 	mov	x0, #0x0                   	// #0
    35dc:	52800042 	mov	w2, #0x2                   	// #2
    35e0:	aa1403e0 	mov	x0, x20
    35e4:	97fffc83 	bl	27f0 <__snprintf_chk@plt>
    35e8:	52800ca1 	mov	w1, #0x65                  	// #101
    35ec:	aa1403e0 	mov	x0, x20
    35f0:	97fffcdc 	bl	2960 <strchr@plt>
    35f4:	aa0003f3 	mov	x19, x0
    35f8:	52800142 	mov	w2, #0xa                   	// #10
    35fc:	91000400 	add	x0, x0, #0x1
    3600:	d2800001 	mov	x1, #0x0                   	// #0
    3604:	97fffcc7 	bl	2920 <strtol@plt>
    3608:	aa0003f7 	mov	x23, x0
    360c:	11001400 	add	w0, w0, #0x5
    3610:	7100541f 	cmp	w0, #0x15
    3614:	54000d68 	b.hi	37c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3618:	4b170385 	sub	w5, w28, w23
    361c:	710000bf 	cmp	w5, #0x0
    3620:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3624:	54000b80 	b.eq	3794 <fwp_format_g.constprop.0+0x214>  // b.none
    3628:	394083e0 	ldrb	w0, [sp, #32]
    362c:	cb180273 	sub	x19, x19, x24
    3630:	91000673 	add	x19, x19, #0x1
    3634:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3638:	7100b41f 	cmp	w0, #0x2d
    363c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3640:	1a9f17e4 	cset	w4, eq	// eq = none
    3644:	cb010266 	sub	x6, x19, x1
    3648:	d10004da 	sub	x26, x6, #0x1
    364c:	540018a0 	b.eq	3960 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3650:	910183f9 	add	x25, sp, #0x60
    3654:	d280091b 	mov	x27, #0x48                  	// #72
    3658:	aa1903e7 	mov	x7, x25
    365c:	91000423 	add	x3, x1, #0x1
    3660:	91011cc6 	add	x6, x6, #0x47
    3664:	910004f6 	add	x22, x7, #0x1
    3668:	37f80ff7 	tbnz	w23, #31, 3864 <fwp_format_g.constprop.0+0x2e4>
    366c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3670:	93407ef7 	sxtw	x23, w23
    3674:	390000e4 	strb	w4, [x7]
    3678:	aa1303e1 	mov	x1, x19
    367c:	aa1703e2 	mov	x2, x23
    3680:	aa1603e0 	mov	x0, x22
    3684:	b9000be5 	str	w5, [sp, #8]
    3688:	cb170374 	sub	x20, x27, x23
    368c:	a9011be3 	stp	x3, x6, [sp, #16]
    3690:	97fffc10 	bl	26d0 <memcpy@plt>
    3694:	d1000694 	sub	x20, x20, #0x1
    3698:	f9400be3 	ldr	x3, [sp, #16]
    369c:	8b1702d6 	add	x22, x22, x23
    36a0:	aa1603e0 	mov	x0, x22
    36a4:	aa1a03e2 	mov	x2, x26
    36a8:	aa0303e1 	mov	x1, x3
    36ac:	aa1403e3 	mov	x3, x20
    36b0:	97fffc48 	bl	27d0 <__memcpy_chk@plt>
    36b4:	8b1a02d6 	add	x22, x22, x26
    36b8:	f9400fe6 	ldr	x6, [sp, #24]
    36bc:	d2800900 	mov	x0, #0x48                  	// #72
    36c0:	b9400be5 	ldr	w5, [sp, #8]
    36c4:	8b170261 	add	x1, x19, x23
    36c8:	cb1400c3 	sub	x3, x6, x20
    36cc:	cb060294 	sub	x20, x20, x6
    36d0:	f101207f 	cmp	x3, #0x48
    36d4:	93407cb8 	sxtw	x24, w5
    36d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    36dc:	aa1803e2 	mov	x2, x24
    36e0:	8b1802d3 	add	x19, x22, x24
    36e4:	8b140063 	add	x3, x3, x20
    36e8:	aa1603e0 	mov	x0, x22
    36ec:	97fffc39 	bl	27d0 <__memcpy_chk@plt>
    36f0:	cb190273 	sub	x19, x19, x25
    36f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    36f8:	eb00027f 	cmp	x19, x0
    36fc:	aa1903e1 	mov	x1, x25
    3700:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3704:	aa1503e0 	mov	x0, x21
    3708:	aa1303e2 	mov	x2, x19
    370c:	97fffbf1 	bl	26d0 <memcpy@plt>
    3710:	38336abf 	strb	wzr, [x21, x19]
    3714:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3718:	aa1503e0 	mov	x0, x21
    371c:	97fffbfd 	bl	2710 <strlen@plt>
    3720:	aa0003f3 	mov	x19, x0
    3724:	528005c1 	mov	w1, #0x2e                  	// #46
    3728:	aa1503e0 	mov	x0, x21
    372c:	97fffc8d 	bl	2960 <strchr@plt>
    3730:	b4000140 	cbz	x0, 3758 <fwp_format_g.constprop.0+0x1d8>
    3734:	b4000133 	cbz	x19, 3758 <fwp_format_g.constprop.0+0x1d8>
    3738:	aa1303e1 	mov	x1, x19
    373c:	d1000673 	sub	x19, x19, #0x1
    3740:	38736aa0 	ldrb	w0, [x21, x19]
    3744:	7100c01f 	cmp	w0, #0x30
    3748:	54001001 	b.ne	3948 <fwp_format_g.constprop.0+0x3c8>  // b.any
    374c:	38336abf 	strb	wzr, [x21, x19]
    3750:	b5ffff53 	cbnz	x19, 3738 <fwp_format_g.constprop.0+0x1b8>
    3754:	d503201f 	nop
    3758:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    375c:	f947f400 	ldr	x0, [x0, #4072]
    3760:	f94057e2 	ldr	x2, [sp, #168]
    3764:	f9400001 	ldr	x1, [x0]
    3768:	eb010042 	subs	x2, x2, x1
    376c:	d2800001 	mov	x1, #0x0                   	// #0
    3770:	54001061 	b.ne	397c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3774:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3778:	a94c53f3 	ldp	x19, x20, [sp, #192]
    377c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3780:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3784:	a95073fb 	ldp	x27, x28, [sp, #256]
    3788:	fd408be8 	ldr	d8, [sp, #272]
    378c:	910483ff 	add	sp, sp, #0x120
    3790:	d65f03c0 	ret
    3794:	1e604100 	fmov	d0, d8
    3798:	710000bf 	cmp	w5, #0x0
    379c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    37a0:	aa1503e0 	mov	x0, x21
    37a4:	d0000044 	adrp	x4, d000 <atexit+0x10>
    37a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    37ac:	9101c084 	add	x4, x4, #0x70
    37b0:	52800042 	mov	w2, #0x2                   	// #2
    37b4:	d2803201 	mov	x1, #0x190                 	// #400
    37b8:	97fffc0e 	bl	27f0 <__snprintf_chk@plt>
    37bc:	17ffffd7 	b	3718 <fwp_format_g.constprop.0+0x198>
    37c0:	cb140273 	sub	x19, x19, x20
    37c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    37c8:	910183f9 	add	x25, sp, #0x60
    37cc:	aa1303e2 	mov	x2, x19
    37d0:	aa1403e1 	mov	x1, x20
    37d4:	aa1903e0 	mov	x0, x25
    37d8:	d2800803 	mov	x3, #0x40                  	// #64
    37dc:	97fffbfd 	bl	27d0 <__memcpy_chk@plt>
    37e0:	38336b3f 	strb	wzr, [x25, x19]
    37e4:	aa1903e0 	mov	x0, x25
    37e8:	528005c1 	mov	w1, #0x2e                  	// #46
    37ec:	97fffc5d 	bl	2960 <strchr@plt>
    37f0:	b40001c0 	cbz	x0, 3828 <fwp_format_g.constprop.0+0x2a8>
    37f4:	b50000b3 	cbnz	x19, 3808 <fwp_format_g.constprop.0+0x288>
    37f8:	1400000c 	b	3828 <fwp_format_g.constprop.0+0x2a8>
    37fc:	381ff01f 	sturb	wzr, [x0, #-1]
    3800:	f1000673 	subs	x19, x19, #0x1
    3804:	54000120 	b.eq	3828 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3808:	8b130320 	add	x0, x25, x19
    380c:	385ff001 	ldurb	w1, [x0, #-1]
    3810:	7100c03f 	cmp	w1, #0x30
    3814:	54ffff40 	b.eq	37fc <fwp_format_g.constprop.0+0x27c>  // b.none
    3818:	d1000673 	sub	x19, x19, #0x1
    381c:	38736b20 	ldrb	w0, [x25, x19]
    3820:	7100b81f 	cmp	w0, #0x2e
    3824:	54000a80 	b.eq	3974 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3828:	710002ff 	cmp	w23, #0x0
    382c:	528005a1 	mov	w1, #0x2d                  	// #45
    3830:	aa1903e5 	mov	x5, x25
    3834:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3838:	aa1503e0 	mov	x0, x21
    383c:	52800566 	mov	w6, #0x2b                  	// #43
    3840:	d0000044 	adrp	x4, d000 <atexit+0x10>
    3844:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3848:	91018084 	add	x4, x4, #0x60
    384c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3850:	52800042 	mov	w2, #0x2                   	// #2
    3854:	d2803201 	mov	x1, #0x190                 	// #400
    3858:	97fffbe6 	bl	27f0 <__snprintf_chk@plt>
    385c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3860:	17ffffbe 	b	3758 <fwp_format_g.constprop.0+0x1d8>
    3864:	52800605 	mov	w5, #0x30                  	// #48
    3868:	390000e5 	strb	w5, [x7]
    386c:	d100077b 	sub	x27, x27, #0x1
    3870:	aa0303e1 	mov	x1, x3
    3874:	aa1603e0 	mov	x0, x22
    3878:	aa1b03e3 	mov	x3, x27
    387c:	aa1a03e2 	mov	x2, x26
    3880:	f90007e6 	str	x6, [sp, #8]
    3884:	b90013e4 	str	w4, [sp, #16]
    3888:	8b1a02d6 	add	x22, x22, x26
    388c:	b9001be5 	str	w5, [sp, #24]
    3890:	97fffbd0 	bl	27d0 <__memcpy_chk@plt>
    3894:	f94007e6 	ldr	x6, [sp, #8]
    3898:	2a3703e7 	mvn	w7, w23
    389c:	b94013e4 	ldr	w4, [sp, #16]
    38a0:	cb1b00c1 	sub	x1, x6, x27
    38a4:	cb06037b 	sub	x27, x27, x6
    38a8:	f101203f 	cmp	x1, #0x48
    38ac:	d2800906 	mov	x6, #0x48                  	// #72
    38b0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    38b4:	8b1b0023 	add	x3, x1, x27
    38b8:	310006ff 	cmn	w23, #0x1
    38bc:	54000220 	b.eq	3900 <fwp_format_g.constprop.0+0x380>  // b.none
    38c0:	b9401be5 	ldr	w5, [sp, #24]
    38c4:	d2800001 	mov	x1, #0x0                   	// #0
    38c8:	f101207f 	cmp	x3, #0x48
    38cc:	d1000462 	sub	x2, x3, #0x1
    38d0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    38d4:	38216ac5 	strb	w5, [x22, x1]
    38d8:	cb030003 	sub	x3, x0, x3
    38dc:	91000421 	add	x1, x1, #0x1
    38e0:	91000463 	add	x3, x3, #0x1
    38e4:	eb00007f 	cmp	x3, x0
    38e8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    38ec:	cb000063 	sub	x3, x3, x0
    38f0:	8b020063 	add	x3, x3, x2
    38f4:	6b0100ff 	cmp	w7, w1
    38f8:	54fffe8c 	b.gt	38c8 <fwp_format_g.constprop.0+0x348>
    38fc:	8b2742d6 	add	x22, x22, w7, uxtw
    3900:	f101207f 	cmp	x3, #0x48
    3904:	d2800905 	mov	x5, #0x48                  	// #72
    3908:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    390c:	aa1603e0 	mov	x0, x22
    3910:	cb0300a1 	sub	x1, x5, x3
    3914:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3918:	91000421 	add	x1, x1, #0x1
    391c:	d1000463 	sub	x3, x3, #0x1
    3920:	eb05003f 	cmp	x1, x5
    3924:	38001402 	strb	w2, [x0], #1
    3928:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    392c:	93407f82 	sxtw	x2, w28
    3930:	cb050025 	sub	x5, x1, x5
    3934:	aa1303e1 	mov	x1, x19
    3938:	8b0300a3 	add	x3, x5, x3
    393c:	8b1802d3 	add	x19, x22, x24
    3940:	97fffba4 	bl	27d0 <__memcpy_chk@plt>
    3944:	17ffff6b 	b	36f0 <fwp_format_g.constprop.0+0x170>
    3948:	d1000421 	sub	x1, x1, #0x1
    394c:	38616aa0 	ldrb	w0, [x21, x1]
    3950:	7100b81f 	cmp	w0, #0x2e
    3954:	54fff021 	b.ne	3758 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3958:	38216abf 	strb	wzr, [x21, x1]
    395c:	17ffff7f 	b	3758 <fwp_format_g.constprop.0+0x1d8>
    3960:	910187e7 	add	x7, sp, #0x61
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d28008fb 	mov	x27, #0x47                  	// #71
    396c:	390183e0 	strb	w0, [sp, #96]
    3970:	17ffff3b 	b	365c <fwp_format_g.constprop.0+0xdc>
    3974:	38336b3f 	strb	wzr, [x25, x19]
    3978:	17ffffac 	b	3828 <fwp_format_g.constprop.0+0x2a8>
    397c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3980:	97fffbc0 	bl	2880 <__stack_chk_fail@plt>

0000000000003984 <fwp_heap_report>:
    3984:	d105c3ff 	sub	sp, sp, #0x170
    3988:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    398c:	91150042 	add	x2, x2, #0x540
    3990:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3994:	f947e821 	ldr	x1, [x1, #4048]
    3998:	a9117bfd 	stp	x29, x30, [sp, #272]
    399c:	910443fd 	add	x29, sp, #0x110
    39a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    39a4:	f947f400 	ldr	x0, [x0, #4072]
    39a8:	a9135bf5 	stp	x21, x22, [sp, #304]
    39ac:	a91463f7 	stp	x23, x24, [sp, #320]
    39b0:	a9156bf9 	stp	x25, x26, [sp, #336]
    39b4:	6d1627e8 	stp	d8, d9, [sp, #352]
    39b8:	fd4a1c48 	ldr	d8, [x2, #5176]
    39bc:	fd4a2049 	ldr	d9, [x2, #5184]
    39c0:	f9400036 	ldr	x22, [x1]
    39c4:	f9400001 	ldr	x1, [x0]
    39c8:	f90087e1 	str	x1, [sp, #264]
    39cc:	d2800001 	mov	x1, #0x0                   	// #0
    39d0:	f949e459 	ldr	x25, [x2, #5064]
    39d4:	d0000041 	adrp	x1, d000 <atexit+0x10>
    39d8:	f94a1057 	ldr	x23, [x2, #5152]
    39dc:	d0000040 	adrp	x0, d000 <atexit+0x10>
    39e0:	f94a1458 	ldr	x24, [x2, #5160]
    39e4:	9101e021 	add	x1, x1, #0x78
    39e8:	91020000 	add	x0, x0, #0x80
    39ec:	97fffb89 	bl	2810 <fopen@plt>
    39f0:	b4000760 	cbz	x0, 3adc <fwp_heap_report+0x158>
    39f4:	528daad5 	mov	w21, #0x6d56                	// #27990
    39f8:	a91253f3 	stp	x19, x20, [sp, #288]
    39fc:	aa0003f4 	mov	x20, x0
    3a00:	910023f3 	add	x19, sp, #0x8
    3a04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3a08:	72aae915 	movk	w21, #0x5748, lsl #16
    3a0c:	d503201f 	nop
    3a10:	aa1403e2 	mov	x2, x20
    3a14:	aa1303e0 	mov	x0, x19
    3a18:	52802001 	mov	w1, #0x100                 	// #256
    3a1c:	97fffc09 	bl	2a40 <fgets@plt>
    3a20:	b4000280 	cbz	x0, 3a70 <fwp_heap_report+0xec>
    3a24:	b9400261 	ldr	w1, [x19]
    3a28:	6b15003f 	cmp	w1, w21
    3a2c:	54ffff21 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a30:	39401260 	ldrb	w0, [x19, #4]
    3a34:	7101341f 	cmp	w0, #0x4d
    3a38:	54fffec1 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a3c:	394037e0 	ldrb	w0, [sp, #13]
    3a40:	7100e81f 	cmp	w0, #0x3a
    3a44:	54fffe61 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a48:	52800142 	mov	w2, #0xa                   	// #10
    3a4c:	d2800001 	mov	x1, #0x0                   	// #0
    3a50:	91003be0 	add	x0, sp, #0xe
    3a54:	97fffbb3 	bl	2920 <strtol@plt>
    3a58:	aa1403e2 	mov	x2, x20
    3a5c:	aa0003fa 	mov	x26, x0
    3a60:	52802001 	mov	w1, #0x100                 	// #256
    3a64:	aa1303e0 	mov	x0, x19
    3a68:	97fffbf6 	bl	2a40 <fgets@plt>
    3a6c:	b5fffdc0 	cbnz	x0, 3a24 <fwp_heap_report+0xa0>
    3a70:	aa1403e0 	mov	x0, x20
    3a74:	97fffb63 	bl	2800 <fclose@plt>
    3a78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3a7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3a80:	f947f400 	ldr	x0, [x0, #4072]
    3a84:	f94087e2 	ldr	x2, [sp, #264]
    3a88:	f9400001 	ldr	x1, [x0]
    3a8c:	eb010042 	subs	x2, x2, x1
    3a90:	d2800001 	mov	x1, #0x0                   	// #0
    3a94:	54000281 	b.ne	3ae4 <fwp_heap_report+0x160>  // b.any
    3a98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3a9c:	aa1a03e6 	mov	x6, x26
    3aa0:	aa1903e5 	mov	x5, x25
    3aa4:	aa1803e4 	mov	x4, x24
    3aa8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3aac:	aa1703e3 	mov	x3, x23
    3ab0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3ab4:	aa1603e0 	mov	x0, x22
    3ab8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3abc:	1e604121 	fmov	d1, d9
    3ac0:	1e604100 	fmov	d0, d8
    3ac4:	d0000042 	adrp	x2, d000 <atexit+0x10>
    3ac8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3acc:	91028042 	add	x2, x2, #0xa0
    3ad0:	9105c3ff 	add	sp, sp, #0x170
    3ad4:	52800041 	mov	w1, #0x2                   	// #2
    3ad8:	17fffb86 	b	28f0 <__fprintf_chk@plt>
    3adc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3ae0:	17ffffe7 	b	3a7c <fwp_heap_report+0xf8>
    3ae4:	a91253f3 	stp	x19, x20, [sp, #288]
    3ae8:	97fffb66 	bl	2880 <__stack_chk_fail@plt>
    3aec:	d503201f 	nop

0000000000003af0 <fwp_heap_init>:
    3af0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3af4:	f0000163 	adrp	x3, 32000 <fwp_heap+0xac0>
    3af8:	91110061 	add	x1, x3, #0x440
    3afc:	910003fd 	mov	x29, sp
    3b00:	a90153f3 	stp	x19, x20, [sp, #16]
    3b04:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3b08:	91150262 	add	x2, x19, #0x540
    3b0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3b10:	52800024 	mov	w4, #0x1                   	// #1
    3b14:	52800200 	mov	w0, #0x10                  	// #16
    3b18:	b913a444 	str	w4, [x2, #5028]
    3b1c:	d503201f 	nop
    3b20:	b8004420 	str	w0, [x1], #4
    3b24:	11004000 	add	w0, w0, #0x10
    3b28:	7104401f 	cmp	w0, #0x110
    3b2c:	54ffffa1 	b.ne	3b20 <fwp_heap_init+0x30>  // b.any
    3b30:	d0000042 	adrp	x2, d000 <atexit+0x10>
    3b34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3b38:	f0000161 	adrp	x1, 32000 <fwp_heap+0xac0>
    3b3c:	91120021 	add	x1, x1, #0x480
    3b40:	3dc33843 	ldr	q3, [x2, #3296]
    3b44:	d2800000 	mov	x0, #0x0                   	// #0
    3b48:	4e040401 	dup	v1.4s, v0.s[0]
    3b4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3b50:	0f215400 	shl	v0.2s, v0.2s, #1
    3b54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3b58:	3ca06821 	str	q1, [x1, x0]
    3b5c:	91004000 	add	x0, x0, #0x10
    3b60:	f101801f 	cmp	x0, #0x60
    3b64:	54ffff21 	b.ne	3b48 <fwp_heap_init+0x58>  // b.any
    3b68:	f0000164 	adrp	x4, 32000 <fwp_heap+0xac0>
    3b6c:	91110063 	add	x3, x3, #0x440
    3b70:	91138084 	add	x4, x4, #0x4e0
    3b74:	91150266 	add	x6, x19, #0x540
    3b78:	d2800002 	mov	x2, #0x0                   	// #0
    3b7c:	d2800000 	mov	x0, #0x0                   	// #0
    3b80:	d2880205 	mov	x5, #0x4010                	// #16400
    3b84:	d503201f 	nop
    3b88:	910f0001 	add	x1, x0, #0x3c0
    3b8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3b90:	eb02003f 	cmp	x1, x2
    3b94:	540000a2 	b.cs	3ba8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3b98:	91000400 	add	x0, x0, #0x1
    3b9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3ba0:	eb02003f 	cmp	x1, x2
    3ba4:	54ffffa3 	b.cc	3b98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3ba8:	91004042 	add	x2, x2, #0x10
    3bac:	38001480 	strb	w0, [x4], #1
    3bb0:	eb05005f 	cmp	x2, x5
    3bb4:	54fffea1 	b.ne	3b88 <fwp_heap_init+0x98>  // b.any
    3bb8:	528000b5 	mov	w21, #0x5                   	// #5
    3bbc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3bc0:	14000004 	b	3bd0 <fwp_heap_init+0xe0>
    3bc4:	d342fe94 	lsr	x20, x20, #2
    3bc8:	710006b5 	subs	w21, w21, #0x1
    3bcc:	54000720 	b.eq	3cb0 <fwp_heap_init+0x1c0>  // b.none
    3bd0:	91404296 	add	x22, x20, #0x10, lsl #12
    3bd4:	d2800005 	mov	x5, #0x0                   	// #0
    3bd8:	aa1603e1 	mov	x1, x22
    3bdc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3be0:	52880443 	mov	w3, #0x4022                	// #16418
    3be4:	52800002 	mov	w2, #0x0                   	// #0
    3be8:	d2800000 	mov	x0, #0x0                   	// #0
    3bec:	97fffb49 	bl	2910 <mmap@plt>
    3bf0:	aa0003e6 	mov	x6, x0
    3bf4:	b100041f 	cmn	x0, #0x1
    3bf8:	54fffe60 	b.eq	3bc4 <fwp_heap_init+0xd4>  // b.none
    3bfc:	b40005a0 	cbz	x0, 3cb0 <fwp_heap_init+0x1c0>
    3c00:	d350fe94 	lsr	x20, x20, #16
    3c04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3c08:	8b0000c7 	add	x7, x6, x0
    3c0c:	91150275 	add	x21, x19, #0x540
    3c10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3c14:	8b140a81 	add	x1, x20, x20, lsl #2
    3c18:	d2800005 	mov	x5, #0x0                   	// #0
    3c1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3c20:	d37df021 	lsl	x1, x1, #3
    3c24:	52880443 	mov	w3, #0x4022                	// #16418
    3c28:	52800002 	mov	w2, #0x0                   	// #0
    3c2c:	d2800000 	mov	x0, #0x0                   	// #0
    3c30:	f909daa7 	str	x7, [x21, #5040]
    3c34:	f909dea6 	str	x6, [x21, #5048]
    3c38:	f909e2b6 	str	x22, [x21, #5056]
    3c3c:	f909eab4 	str	x20, [x21, #5072]
    3c40:	f90a02a1 	str	x1, [x21, #5120]
    3c44:	97fffb33 	bl	2910 <mmap@plt>
    3c48:	aa0003e1 	mov	x1, x0
    3c4c:	b100041f 	cmn	x0, #0x1
    3c50:	54000300 	b.eq	3cb0 <fwp_heap_init+0x1c0>  // b.none
    3c54:	d0000040 	adrp	x0, d000 <atexit+0x10>
    3c58:	9104a000 	add	x0, x0, #0x128
    3c5c:	f909fea1 	str	x1, [x21, #5112]
    3c60:	97fffb6c 	bl	2a10 <getenv@plt>
    3c64:	52800002 	mov	w2, #0x0                   	// #0
    3c68:	aa0003e1 	mov	x1, x0
    3c6c:	b40000e0 	cbz	x0, 3c88 <fwp_heap_init+0x198>
    3c70:	39400000 	ldrb	w0, [x0]
    3c74:	340000a0 	cbz	w0, 3c88 <fwp_heap_init+0x198>
    3c78:	7100c000 	subs	w0, w0, #0x30
    3c7c:	54000120 	b.eq	3ca0 <fwp_heap_init+0x1b0>  // b.none
    3c80:	7100001f 	cmp	w0, #0x0
    3c84:	1a9f07e2 	cset	w2, ne	// ne = any
    3c88:	91150273 	add	x19, x19, #0x540
    3c8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3c90:	b913aa62 	str	w2, [x19, #5032]
    3c94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3c9c:	d65f03c0 	ret
    3ca0:	39400420 	ldrb	w0, [x1, #1]
    3ca4:	7100001f 	cmp	w0, #0x0
    3ca8:	1a9f07e2 	cset	w2, ne	// ne = any
    3cac:	17fffff7 	b	3c88 <fwp_heap_init+0x198>
    3cb0:	97fffce0 	bl	3030 <fwp_heap_oom>

0000000000003cb4 <fwp_wake_io>:
    3cb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3cb8:	9100c122 	add	x2, x9, #0x30
    3cbc:	f9400001 	ldr	x1, [x0]
    3cc0:	5280000a 	mov	w10, #0x0                   	// #0
    3cc4:	f9401446 	ldr	x6, [x2, #40]
    3cc8:	52800008 	mov	w8, #0x0                   	// #0
    3ccc:	4f000400 	movi	v0.4s, #0x0
    3cd0:	52800027 	mov	w7, #0x1                   	// #1
    3cd4:	aa0103e2 	mov	x2, x1
    3cd8:	b4000321 	cbz	x1, 3d3c <fwp_wake_io+0x88>
    3cdc:	f9408c25 	ldr	x5, [x1, #280]
    3ce0:	39015c27 	strb	w7, [x1, #87]
    3ce4:	b4000165 	cbz	x5, 3d10 <fwp_wake_io+0x5c>
    3ce8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3cec:	b4000364 	cbz	x4, 3d58 <fwp_wake_io+0xa4>
    3cf0:	f9009483 	str	x3, [x4, #296]
    3cf4:	f9409423 	ldr	x3, [x1, #296]
    3cf8:	b4000043 	cbz	x3, 3d00 <fwp_wake_io+0x4c>
    3cfc:	f9009064 	str	x4, [x3, #288]
    3d00:	91080023 	add	x3, x1, #0x200
    3d04:	f900943f 	str	xzr, [x1, #296]
    3d08:	3c918060 	stur	q0, [x3, #-232]
    3d0c:	f9400001 	ldr	x1, [x0]
    3d10:	f9402843 	ldr	x3, [x2, #80]
    3d14:	f2001c7f 	tst	x3, #0xff000000ff
    3d18:	54fffde1 	b.ne	3cd4 <fwp_wake_io+0x20>  // b.any
    3d1c:	39015047 	strb	w7, [x2, #84]
    3d20:	f900805f 	str	xzr, [x2, #256]
    3d24:	b40001e6 	cbz	x6, 3d60 <fwp_wake_io+0xac>
    3d28:	f90080c2 	str	x2, [x6, #256]
    3d2c:	aa0203e6 	mov	x6, x2
    3d30:	52800028 	mov	w8, #0x1                   	// #1
    3d34:	aa0103e2 	mov	x2, x1
    3d38:	b5fffd21 	cbnz	x1, 3cdc <fwp_wake_io+0x28>
    3d3c:	3400006a 	cbz	w10, 3d48 <fwp_wake_io+0x94>
    3d40:	9100c120 	add	x0, x9, #0x30
    3d44:	f900180b 	str	x11, [x0, #48]
    3d48:	34000068 	cbz	w8, 3d54 <fwp_wake_io+0xa0>
    3d4c:	9100c129 	add	x9, x9, #0x30
    3d50:	f9001526 	str	x6, [x9, #40]
    3d54:	d65f03c0 	ret
    3d58:	f90000a3 	str	x3, [x5]
    3d5c:	17ffffe7 	b	3cf8 <fwp_wake_io+0x44>
    3d60:	aa0203eb 	mov	x11, x2
    3d64:	5280002a 	mov	w10, #0x1                   	// #1
    3d68:	17fffff1 	b	3d2c <fwp_wake_io+0x78>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_tape_buffers_release>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	910003fd 	mov	x29, sp
    3d78:	a90153f3 	stp	x19, x20, [sp, #16]
    3d7c:	aa0003f3 	mov	x19, x0
    3d80:	f9401400 	ldr	x0, [x0, #40]
    3d84:	b7f80760 	tbnz	x0, #63, 3e70 <fwp_tape_buffers_release+0x100>
    3d88:	f9401a61 	ldr	x1, [x19, #48]
    3d8c:	b7f80301 	tbnz	x1, #63, 3dec <fwp_tape_buffers_release+0x7c>
    3d90:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    3d94:	eb02001f 	cmp	x0, x2
    3d98:	540002a8 	b.hi	3dec <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d9c:	8b000400 	add	x0, x0, x0, lsl #1
    3da0:	d2a00102 	mov	x2, #0x80000               	// #524288
    3da4:	d37df000 	lsl	x0, x0, #3
    3da8:	cb000042 	sub	x2, x2, x0
    3dac:	eb420c3f 	cmp	x1, x2, lsr #3
    3db0:	540001e8 	b.hi	3dec <fwp_tape_buffers_release+0x7c>  // b.pmore
    3db4:	8b010c14 	add	x20, x0, x1, lsl #3
    3db8:	d0000040 	adrp	x0, d000 <atexit+0x10>
    3dbc:	9104e000 	add	x0, x0, #0x138
    3dc0:	97fffb14 	bl	2a10 <getenv@plt>
    3dc4:	b4000240 	cbz	x0, 3e0c <fwp_tape_buffers_release+0x9c>
    3dc8:	39400001 	ldrb	w1, [x0]
    3dcc:	7100c03f 	cmp	w1, #0x30
    3dd0:	540001e1 	b.ne	3e0c <fwp_tape_buffers_release+0x9c>  // b.any
    3dd4:	39400400 	ldrb	w0, [x0, #1]
    3dd8:	350001a0 	cbnz	w0, 3e0c <fwp_tape_buffers_release+0x9c>
    3ddc:	aa1303e0 	mov	x0, x19
    3de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3de4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3de8:	17fffd46 	b	3300 <fwp_tape_buffers_dispose>
    3dec:	d0000040 	adrp	x0, d000 <atexit+0x10>
    3df0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3df4:	9104e000 	add	x0, x0, #0x138
    3df8:	97fffb06 	bl	2a10 <getenv@plt>
    3dfc:	b4ffff00 	cbz	x0, 3ddc <fwp_tape_buffers_release+0x6c>
    3e00:	39400001 	ldrb	w1, [x0]
    3e04:	7100c03f 	cmp	w1, #0x30
    3e08:	54fffe60 	b.eq	3dd4 <fwp_tape_buffers_release+0x64>  // b.none
    3e0c:	d1000681 	sub	x1, x20, #0x1
    3e10:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    3e14:	eb00003f 	cmp	x1, x0
    3e18:	54fffe28 	b.hi	3ddc <fwp_tape_buffers_release+0x6c>  // b.pmore
    3e1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e20:	b00000f6 	adrp	x22, 20000 <__data_start>
    3e24:	9100c2d6 	add	x22, x22, #0x30
    3e28:	9100e2d5 	add	x21, x22, #0x38
    3e2c:	aa1503e0 	mov	x0, x21
    3e30:	97fffd34 	bl	3300 <fwp_tape_buffers_dispose>
    3e34:	ad400a61 	ldp	q1, q2, [x19]
    3e38:	f9003ad4 	str	x20, [x22, #112]
    3e3c:	4f000400 	movi	v0.4s, #0x0
    3e40:	ad000aa1 	stp	q1, q2, [x21]
    3e44:	3dc00a61 	ldr	q1, [x19, #32]
    3e48:	3d800aa1 	str	q1, [x21, #32]
    3e4c:	f9401a60 	ldr	x0, [x19, #48]
    3e50:	f9001aa0 	str	x0, [x21, #48]
    3e54:	f9001a7f 	str	xzr, [x19, #48]
    3e58:	ad000260 	stp	q0, q0, [x19]
    3e5c:	3d800a60 	str	q0, [x19, #32]
    3e60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e64:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3e68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3e6c:	d65f03c0 	ret
    3e70:	d0000040 	adrp	x0, d000 <atexit+0x10>
    3e74:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3e78:	9104e000 	add	x0, x0, #0x138
    3e7c:	97fffae5 	bl	2a10 <getenv@plt>
    3e80:	b5fffa40 	cbnz	x0, 3dc8 <fwp_tape_buffers_release+0x58>
    3e84:	17ffffd6 	b	3ddc <fwp_tape_buffers_release+0x6c>
    3e88:	d503201f 	nop
    3e8c:	d503201f 	nop

0000000000003e90 <fwp_trap>:
    3e90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e94:	b00000e2 	adrp	x2, 20000 <__data_start>
    3e98:	d53bd041 	mrs	x1, tpidr_el0
    3e9c:	910003fd 	mov	x29, sp
    3ea0:	f9401c42 	ldr	x2, [x2, #56]
    3ea4:	91400021 	add	x1, x1, #0x0, lsl #12
    3ea8:	91004021 	add	x1, x1, #0x10
    3eac:	a90153f3 	stp	x19, x20, [sp, #16]
    3eb0:	aa0003f3 	mov	x19, x0
    3eb4:	f9400034 	ldr	x20, [x1]
    3eb8:	b4000062 	cbz	x2, 3ec4 <fwp_trap+0x34>
    3ebc:	aa0203e0 	mov	x0, x2
    3ec0:	97fffabc 	bl	29b0 <fflush@plt>
    3ec4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3ec8:	f947ec00 	ldr	x0, [x0, #4056]
    3ecc:	f9400000 	ldr	x0, [x0]
    3ed0:	97fffab8 	bl	29b0 <fflush@plt>
    3ed4:	aa1303e3 	mov	x3, x19
    3ed8:	d0000042 	adrp	x2, d000 <atexit+0x10>
    3edc:	900000f3 	adrp	x19, 1f000 <fwp_fn_table+0xc98>
    3ee0:	f947ea73 	ldr	x19, [x19, #4048]
    3ee4:	91054042 	add	x2, x2, #0x150
    3ee8:	52800041 	mov	w1, #0x2                   	// #2
    3eec:	f9400260 	ldr	x0, [x19]
    3ef0:	97fffa80 	bl	28f0 <__fprintf_chk@plt>
    3ef4:	b40000b4 	cbz	x20, 3f08 <fwp_trap+0x78>
    3ef8:	f9400260 	ldr	x0, [x19]
    3efc:	97fffaad 	bl	29b0 <fflush@plt>
    3f00:	52800ca0 	mov	w0, #0x65                  	// #101
    3f04:	97fffabb 	bl	29f0 <_Exit@plt>
    3f08:	52800ca0 	mov	w0, #0x65                  	// #101
    3f0c:	97fffa09 	bl	2730 <exit@plt>

0000000000003f10 <fwp_rc_forget_slot.part.0>:
    3f10:	ca404401 	eor	x1, x0, x0, lsr #17
    3f14:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3f18:	ca412421 	eor	x1, x1, x1, lsr #9
    3f1c:	910003fd 	mov	x29, sp
    3f20:	92401c21 	and	x1, x1, #0xff
    3f24:	f9000bf3 	str	x19, [sp, #16]
    3f28:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    3f2c:	91150262 	add	x2, x19, #0x540
    3f30:	910a2423 	add	x3, x1, #0x289
    3f34:	8b010c41 	add	x1, x2, x1, lsl #3
    3f38:	8b030c43 	add	x3, x2, x3, lsl #3
    3f3c:	f94a2421 	ldr	x1, [x1, #5192]
    3f40:	b50000a1 	cbnz	x1, 3f54 <fwp_rc_forget_slot.part.0+0x44>
    3f44:	14000012 	b	3f8c <fwp_rc_forget_slot.part.0+0x7c>
    3f48:	91004023 	add	x3, x1, #0x10
    3f4c:	f9400821 	ldr	x1, [x1, #16]
    3f50:	b40001e1 	cbz	x1, 3f8c <fwp_rc_forget_slot.part.0+0x7c>
    3f54:	f9400022 	ldr	x2, [x1]
    3f58:	eb02001f 	cmp	x0, x2
    3f5c:	54ffff61 	b.ne	3f48 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    3f60:	f9400060 	ldr	x0, [x3]
    3f64:	91150273 	add	x19, x19, #0x540
    3f68:	f9400801 	ldr	x1, [x0, #16]
    3f6c:	f9000061 	str	x1, [x3]
    3f70:	97fffa74 	bl	2940 <free@plt>
    3f74:	f94e2660 	ldr	x0, [x19, #7240]
    3f78:	d1000400 	sub	x0, x0, #0x1
    3f7c:	f90e2660 	str	x0, [x19, #7240]
    3f80:	f9400bf3 	ldr	x19, [sp, #16]
    3f84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f88:	d65f03c0 	ret
    3f8c:	d0000040 	adrp	x0, d000 <atexit+0x10>
    3f90:	91058000 	add	x0, x0, #0x160
    3f94:	97ffffbf 	bl	3e90 <fwp_trap>
    3f98:	d503201f 	nop
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_rc_prepare_chunk>:
    3fa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3fa4:	910003fd 	mov	x29, sp
    3fa8:	a9025bf5 	stp	x21, x22, [sp, #32]
    3fac:	d0000176 	adrp	x22, 31000 <fwp_root_context+0xca0>
    3fb0:	911502c2 	add	x2, x22, #0x540
    3fb4:	b9401c03 	ldr	w3, [x0, #28]
    3fb8:	aa0103f5 	mov	x21, x1
    3fbc:	a90153f3 	stp	x19, x20, [sp, #16]
    3fc0:	aa0003f4 	mov	x20, x0
    3fc4:	f94e2440 	ldr	x0, [x2, #7240]
    3fc8:	b4000440 	cbz	x0, 4050 <fwp_rc_prepare_chunk+0xb0>
    3fcc:	d2800013 	mov	x19, #0x0                   	// #0
    3fd0:	35000203 	cbnz	w3, 4010 <fwp_rc_prepare_chunk+0x70>
    3fd4:	b4000361 	cbz	x1, 4040 <fwp_rc_prepare_chunk+0xa0>
    3fd8:	f9401280 	ldr	x0, [x20, #32]
    3fdc:	97fffa59 	bl	2940 <free@plt>
    3fe0:	aa1503e0 	mov	x0, x21
    3fe4:	d2800021 	mov	x1, #0x1                   	// #1
    3fe8:	97fffa1e 	bl	2860 <calloc@plt>
    3fec:	f9001280 	str	x0, [x20, #32]
    3ff0:	b5000460 	cbnz	x0, 407c <fwp_rc_prepare_chunk+0xdc>
    3ff4:	97fffc0f 	bl	3030 <fwp_heap_oom>
    3ff8:	97ffffc6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    3ffc:	91000673 	add	x19, x19, #0x1
    4000:	b9401e83 	ldr	w3, [x20, #28]
    4004:	eb13007f 	cmp	x3, x19
    4008:	54000169 	b.ls	4034 <fwp_rc_prepare_chunk+0x94>  // b.plast
    400c:	d503201f 	nop
    4010:	f9401283 	ldr	x3, [x20, #32]
    4014:	8b130060 	add	x0, x3, x19
    4018:	38736863 	ldrb	w3, [x3, x19]
    401c:	7103fc7f 	cmp	w3, #0xff
    4020:	54fffec0 	b.eq	3ff8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4024:	b9401e83 	ldr	w3, [x20, #28]
    4028:	91000673 	add	x19, x19, #0x1
    402c:	eb13007f 	cmp	x3, x19
    4030:	54ffff08 	b.hi	4010 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4034:	eb0302bf 	cmp	x21, x3
    4038:	54000121 	b.ne	405c <fwp_rc_prepare_chunk+0xbc>  // b.any
    403c:	b5000335 	cbnz	x21, 40a0 <fwp_rc_prepare_chunk+0x100>
    4040:	a94153f3 	ldp	x19, x20, [sp, #16]
    4044:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4048:	a8c37bfd 	ldp	x29, x30, [sp], #48
    404c:	d65f03c0 	ret
    4050:	2a0303e3 	mov	w3, w3
    4054:	eb0302bf 	cmp	x21, x3
    4058:	54ffff20 	b.eq	403c <fwp_rc_prepare_chunk+0x9c>  // b.none
    405c:	911502c2 	add	x2, x22, #0x540
    4060:	f9401280 	ldr	x0, [x20, #32]
    4064:	f94e2841 	ldr	x1, [x2, #7248]
    4068:	cb030021 	sub	x1, x1, x3
    406c:	f90e2841 	str	x1, [x2, #7248]
    4070:	97fffa34 	bl	2940 <free@plt>
    4074:	b5fffb75 	cbnz	x21, 3fe0 <fwp_rc_prepare_chunk+0x40>
    4078:	f900129f 	str	xzr, [x20, #32]
    407c:	911502d6 	add	x22, x22, #0x540
    4080:	f94e2ac0 	ldr	x0, [x22, #7248]
    4084:	b9001e95 	str	w21, [x20, #28]
    4088:	a94153f3 	ldp	x19, x20, [sp, #16]
    408c:	8b150000 	add	x0, x0, x21
    4090:	f90e2ac0 	str	x0, [x22, #7248]
    4094:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4098:	a8c37bfd 	ldp	x29, x30, [sp], #48
    409c:	d65f03c0 	ret
    40a0:	f9401280 	ldr	x0, [x20, #32]
    40a4:	aa1503e2 	mov	x2, x21
    40a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    40ac:	52800001 	mov	w1, #0x0                   	// #0
    40b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40b8:	17fff9e6 	b	2850 <memset@plt>
    40bc:	d503201f 	nop

00000000000040c0 <fwp_heap_refill>:
    40c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    40c4:	910003fd 	mov	x29, sp
    40c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    40cc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    40d0:	911502b5 	add	x21, x21, #0x540
    40d4:	aa0003f6 	mov	x22, x0
    40d8:	d2800020 	mov	x0, #0x1                   	// #1
    40dc:	a90153f3 	stp	x19, x20, [sp, #16]
    40e0:	a90363f7 	stp	x23, x24, [sp, #48]
    40e4:	2a0103f7 	mov	w23, w1
    40e8:	2a0203f8 	mov	w24, w2
    40ec:	97fffc11 	bl	3130 <fwp_heap_chunks>
    40f0:	aa0003f3 	mov	x19, x0
    40f4:	f949fea2 	ldr	x2, [x21, #5112]
    40f8:	8b000800 	add	x0, x0, x0, lsl #2
    40fc:	2a1703e1 	mov	w1, w23
    4100:	52800025 	mov	w5, #0x1                   	// #1
    4104:	d37df000 	lsl	x0, x0, #3
    4108:	910f0021 	add	x1, x1, #0x3c0
    410c:	8b000054 	add	x20, x2, x0
    4110:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4114:	52a00024 	mov	w4, #0x10000               	// #65536
    4118:	38206845 	strb	w5, [x2, x0]
    411c:	aa1403e0 	mov	x0, x20
    4120:	39000698 	strb	w24, [x20, #1]
    4124:	39000a97 	strb	w23, [x20, #2]
    4128:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    412c:	b9000681 	str	w1, [x20, #4]
    4130:	2a0103e5 	mov	w5, w1
    4134:	8b0300a2 	add	x2, x5, x3
    4138:	1ac10881 	udiv	w1, w4, w1
    413c:	9ac50842 	udiv	x2, x2, x5
    4140:	b9000a81 	str	w1, [x20, #8]
    4144:	92404021 	and	x1, x1, #0x1ffff
    4148:	b9001a82 	str	w2, [x20, #24]
    414c:	97ffff95 	bl	3fa0 <fwp_rc_prepare_chunk>
    4150:	f949daa0 	ldr	x0, [x21, #5040]
    4154:	29408a81 	ldp	w1, w2, [x20, #4]
    4158:	8b134000 	add	x0, x0, x19, lsl #16
    415c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4160:	8b214003 	add	x3, x0, w1, uxtw
    4164:	9ba20021 	umaddl	x1, w1, w2, x0
    4168:	a94363f7 	ldp	x23, x24, [sp, #48]
    416c:	a90086c3 	stp	x3, x1, [x22, #8]
    4170:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4174:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4178:	d65f03c0 	ret
    417c:	d503201f 	nop

0000000000004180 <fwp_mem_free>:
    4180:	b40003c0 	cbz	x0, 41f8 <fwp_mem_free+0x78>
    4184:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4188:	910003fd 	mov	x29, sp
    418c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4190:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4194:	911502a1 	add	x1, x21, #0x540
    4198:	a90153f3 	stp	x19, x20, [sp, #16]
    419c:	aa0003f3 	mov	x19, x0
    41a0:	f949d823 	ldr	x3, [x1, #5040]
    41a4:	f949ec22 	ldr	x2, [x1, #5080]
    41a8:	cb030000 	sub	x0, x0, x3
    41ac:	eb02401f 	cmp	x0, x2, lsl #16
    41b0:	540001c2 	b.cs	41e8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    41b4:	d350fc16 	lsr	x22, x0, #16
    41b8:	a90363f7 	stp	x23, x24, [sp, #48]
    41bc:	f949fc22 	ldr	x2, [x1, #5112]
    41c0:	8b160ad4 	add	x20, x22, x22, lsl #2
    41c4:	d37df294 	lsl	x20, x20, #3
    41c8:	ab140057 	adds	x23, x2, x20
    41cc:	540000c0 	b.eq	41e4 <fwp_mem_free+0x64>  // b.none
    41d0:	38746842 	ldrb	w2, [x2, x20]
    41d4:	7100045f 	cmp	w2, #0x1
    41d8:	54000120 	b.eq	41fc <fwp_mem_free+0x7c>  // b.none
    41dc:	7100085f 	cmp	w2, #0x2
    41e0:	540005e0 	b.eq	429c <fwp_mem_free+0x11c>  // b.none
    41e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    41e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    41ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    41f4:	d65f03c0 	ret
    41f8:	d65f03c0 	ret
    41fc:	f94012f8 	ldr	x24, [x23, #32]
    4200:	b94006e1 	ldr	w1, [x23, #4]
    4204:	f90023f9 	str	x25, [sp, #64]
    4208:	2a0103e2 	mov	w2, w1
    420c:	394006f9 	ldrb	w25, [x23, #1]
    4210:	39400af4 	ldrb	w20, [x23, #2]
    4214:	b4000158 	cbz	x24, 423c <fwp_mem_free+0xbc>
    4218:	92403e76 	and	x22, x19, #0xffff
    421c:	9ac20ad6 	udiv	x22, x22, x2
    4220:	38766b01 	ldrb	w1, [x24, x22]
    4224:	8b160300 	add	x0, x24, x22
    4228:	7103fc3f 	cmp	w1, #0xff
    422c:	54000980 	b.eq	435c <fwp_mem_free+0x1dc>  // b.none
    4230:	38366b1f 	strb	wzr, [x24, x22]
    4234:	b94006e1 	ldr	w1, [x23, #4]
    4238:	2a0103e2 	mov	w2, w1
    423c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4240:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4244:	cb390000 	sub	x0, x0, w25, uxtb
    4248:	8b340074 	add	x20, x3, w20, uxtb
    424c:	911502b5 	add	x21, x21, #0x540
    4250:	1e630021 	ucvtf	d1, w1
    4254:	d37ae400 	lsl	x0, x0, #6
    4258:	8b140c14 	add	x20, x0, x20, lsl #3
    425c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4260:	f8746aa0 	ldr	x0, [x21, x20]
    4264:	f94023f9 	ldr	x25, [sp, #64]
    4268:	aa2003e0 	mvn	x0, x0
    426c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4270:	f9000260 	str	x0, [x19]
    4274:	f8346ab3 	str	x19, [x21, x20]
    4278:	f94a12a0 	ldr	x0, [x21, #5152]
    427c:	1e612800 	fadd	d0, d0, d1
    4280:	a94153f3 	ldp	x19, x20, [sp, #16]
    4284:	cb020000 	sub	x0, x0, x2
    4288:	f90a12a0 	str	x0, [x21, #5152]
    428c:	fd0a22a0 	str	d0, [x21, #5184]
    4290:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4294:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4298:	d65f03c0 	ret
    429c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    42a0:	8b000063 	add	x3, x3, x0
    42a4:	eb03027f 	cmp	x19, x3
    42a8:	54fff9e1 	b.ne	41e4 <fwp_mem_free+0x64>  // b.any
    42ac:	fd400ae1 	ldr	d1, [x23, #16]
    42b0:	fd4a2020 	ldr	d0, [x1, #5184]
    42b4:	f9400ae0 	ldr	x0, [x23, #16]
    42b8:	7e61d821 	ucvtf	d1, d1
    42bc:	f94a1022 	ldr	x2, [x1, #5152]
    42c0:	f94012f3 	ldr	x19, [x23, #32]
    42c4:	1e612800 	fadd	d0, d0, d1
    42c8:	cb000042 	sub	x2, x2, x0
    42cc:	f90a1022 	str	x2, [x1, #5152]
    42d0:	fd0a2020 	str	d0, [x1, #5184]
    42d4:	b40000b3 	cbz	x19, 42e8 <fwp_mem_free+0x168>
    42d8:	39400260 	ldrb	w0, [x19]
    42dc:	7103fc1f 	cmp	w0, #0xff
    42e0:	54000380 	b.eq	4350 <fwp_mem_free+0x1d0>  // b.none
    42e4:	3900027f 	strb	wzr, [x19]
    42e8:	b9400ee2 	ldr	w2, [x23, #12]
    42ec:	b4000142 	cbz	x2, 4314 <fwp_mem_free+0x194>
    42f0:	911502a1 	add	x1, x21, #0x540
    42f4:	8b160040 	add	x0, x2, x22
    42f8:	8b000800 	add	x0, x0, x0, lsl #2
    42fc:	f949fc21 	ldr	x1, [x1, #5112]
    4300:	8b140034 	add	x20, x1, x20
    4304:	8b000c20 	add	x0, x1, x0, lsl #3
    4308:	3802869f 	strb	wzr, [x20], #40
    430c:	eb00029f 	cmp	x20, x0
    4310:	54ffffc1 	b.ne	4308 <fwp_mem_free+0x188>  // b.any
    4314:	911502a0 	add	x0, x21, #0x540
    4318:	f94a1801 	ldr	x1, [x0, #5168]
    431c:	f949f803 	ldr	x3, [x0, #5104]
    4320:	8b020021 	add	x1, x1, x2
    4324:	f90a1801 	str	x1, [x0, #5168]
    4328:	eb16007f 	cmp	x3, x22
    432c:	54000049 	b.ls	4334 <fwp_mem_free+0x1b4>  // b.plast
    4330:	f909f816 	str	x22, [x0, #5104]
    4334:	911502b5 	add	x21, x21, #0x540
    4338:	f949f6a0 	ldr	x0, [x21, #5096]
    433c:	eb16001f 	cmp	x0, x22
    4340:	54fff529 	b.ls	41e4 <fwp_mem_free+0x64>  // b.plast
    4344:	a94363f7 	ldp	x23, x24, [sp, #48]
    4348:	f909f6b6 	str	x22, [x21, #5096]
    434c:	17ffffa7 	b	41e8 <fwp_mem_free+0x68>
    4350:	aa1303e0 	mov	x0, x19
    4354:	97fffeef 	bl	3f10 <fwp_rc_forget_slot.part.0>
    4358:	17ffffe3 	b	42e4 <fwp_mem_free+0x164>
    435c:	97fffeed 	bl	3f10 <fwp_rc_forget_slot.part.0>
    4360:	17ffffb4 	b	4230 <fwp_mem_free+0xb0>

0000000000004364 <fwp_rc_wide_dup>:
    4364:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4368:	910003fd 	mov	x29, sp
    436c:	a90153f3 	stp	x19, x20, [sp, #16]
    4370:	aa0003f3 	mov	x19, x0
    4374:	ca404400 	eor	x0, x0, x0, lsr #17
    4378:	f90013f5 	str	x21, [sp, #32]
    437c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    4380:	ca402400 	eor	x0, x0, x0, lsr #9
    4384:	911502a2 	add	x2, x21, #0x540
    4388:	92401c00 	and	x0, x0, #0xff
    438c:	910a2403 	add	x3, x0, #0x289
    4390:	8b000c40 	add	x0, x2, x0, lsl #3
    4394:	8b030c54 	add	x20, x2, x3, lsl #3
    4398:	f94a2401 	ldr	x1, [x0, #5192]
    439c:	b50000a1 	cbnz	x1, 43b0 <fwp_rc_wide_dup+0x4c>
    43a0:	14000033 	b	446c <fwp_rc_wide_dup+0x108>
    43a4:	91004034 	add	x20, x1, #0x10
    43a8:	f9400821 	ldr	x1, [x1, #16]
    43ac:	b4000241 	cbz	x1, 43f4 <fwp_rc_wide_dup+0x90>
    43b0:	f9400022 	ldr	x2, [x1]
    43b4:	eb02027f 	cmp	x19, x2
    43b8:	54ffff61 	b.ne	43a4 <fwp_rc_wide_dup+0x40>  // b.any
    43bc:	f9400281 	ldr	x1, [x20]
    43c0:	39400260 	ldrb	w0, [x19]
    43c4:	7103f81f 	cmp	w0, #0xfe
    43c8:	54000220 	b.eq	440c <fwp_rc_wide_dup+0xa8>  // b.none
    43cc:	b40001a1 	cbz	x1, 4400 <fwp_rc_wide_dup+0x9c>
    43d0:	f9400420 	ldr	x0, [x1, #8]
    43d4:	b100041f 	cmn	x0, #0x1
    43d8:	54000440 	b.eq	4460 <fwp_rc_wide_dup+0xfc>  // b.none
    43dc:	91000400 	add	x0, x0, #0x1
    43e0:	f9000420 	str	x0, [x1, #8]
    43e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    43e8:	f94013f5 	ldr	x21, [sp, #32]
    43ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43f0:	d65f03c0 	ret
    43f4:	39400260 	ldrb	w0, [x19]
    43f8:	7103f81f 	cmp	w0, #0xfe
    43fc:	54000100 	b.eq	441c <fwp_rc_wide_dup+0xb8>  // b.none
    4400:	b0000040 	adrp	x0, d000 <atexit+0x10>
    4404:	91058000 	add	x0, x0, #0x160
    4408:	97fffea2 	bl	3e90 <fwp_trap>
    440c:	b4000081 	cbz	x1, 441c <fwp_rc_wide_dup+0xb8>
    4410:	b0000040 	adrp	x0, d000 <atexit+0x10>
    4414:	91062000 	add	x0, x0, #0x188
    4418:	97fffe9e 	bl	3e90 <fwp_trap>
    441c:	d2800300 	mov	x0, #0x18                  	// #24
    4420:	97fff900 	bl	2820 <malloc@plt>
    4424:	b4000280 	cbz	x0, 4474 <fwp_rc_wide_dup+0x110>
    4428:	d2801fe1 	mov	x1, #0xff                  	// #255
    442c:	a9000413 	stp	x19, x1, [x0]
    4430:	911502b5 	add	x21, x21, #0x540
    4434:	f900081f 	str	xzr, [x0, #16]
    4438:	12800001 	mov	w1, #0xffffffff            	// #-1
    443c:	f9000280 	str	x0, [x20]
    4440:	39000261 	strb	w1, [x19]
    4444:	f94e26a0 	ldr	x0, [x21, #7240]
    4448:	a94153f3 	ldp	x19, x20, [sp, #16]
    444c:	91000400 	add	x0, x0, #0x1
    4450:	f90e26a0 	str	x0, [x21, #7240]
    4454:	f94013f5 	ldr	x21, [sp, #32]
    4458:	a8c37bfd 	ldp	x29, x30, [sp], #48
    445c:	d65f03c0 	ret
    4460:	b0000040 	adrp	x0, d000 <atexit+0x10>
    4464:	9106c000 	add	x0, x0, #0x1b0
    4468:	97fffe8a 	bl	3e90 <fwp_trap>
    446c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4470:	17ffffd4 	b	43c0 <fwp_rc_wide_dup+0x5c>
    4474:	97fffaef 	bl	3030 <fwp_heap_oom>
    4478:	d503201f 	nop
    447c:	d503201f 	nop

0000000000004480 <fwp_closure_drop_push>:
    4480:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4484:	910003fd 	mov	x29, sp
    4488:	a90153f3 	stp	x19, x20, [sp, #16]
    448c:	aa0003f3 	mov	x19, x0
    4490:	a9408014 	ldp	x20, x0, [x0, #8]
    4494:	a9025bf5 	stp	x21, x22, [sp, #32]
    4498:	aa0103f5 	mov	x21, x1
    449c:	a90363f7 	stp	x23, x24, [sp, #48]
    44a0:	eb00029f 	cmp	x20, x0
    44a4:	54000160 	b.eq	44d0 <fwp_closure_drop_push+0x50>  // b.none
    44a8:	f9400276 	ldr	x22, [x19]
    44ac:	d37df297 	lsl	x23, x20, #3
    44b0:	91000694 	add	x20, x20, #0x1
    44b4:	f9000674 	str	x20, [x19, #8]
    44b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44bc:	f8376ad5 	str	x21, [x22, x23]
    44c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    44c8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44cc:	d65f03c0 	ret
    44d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    44d4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    44d8:	eb00029f 	cmp	x20, x0
    44dc:	540003e8 	b.hi	4558 <fwp_closure_drop_push+0xd8>  // b.pmore
    44e0:	d37cee99 	lsl	x25, x20, #4
    44e4:	d37ffa9a 	lsl	x26, x20, #1
    44e8:	aa1903e0 	mov	x0, x25
    44ec:	97fff8cd 	bl	2820 <malloc@plt>
    44f0:	aa0003f6 	mov	x22, x0
    44f4:	b4000380 	cbz	x0, 4564 <fwp_closure_drop_push+0xe4>
    44f8:	aa1303f8 	mov	x24, x19
    44fc:	aa1903e3 	mov	x3, x25
    4500:	d37df297 	lsl	x23, x20, #3
    4504:	aa1703e2 	mov	x2, x23
    4508:	f8418719 	ldr	x25, [x24], #24
    450c:	aa1903e1 	mov	x1, x25
    4510:	97fff8b0 	bl	27d0 <__memcpy_chk@plt>
    4514:	eb18033f 	cmp	x25, x24
    4518:	540000a0 	b.eq	452c <fwp_closure_drop_push+0xac>  // b.none
    451c:	aa1903e0 	mov	x0, x25
    4520:	97fff908 	bl	2940 <free@plt>
    4524:	f9400674 	ldr	x20, [x19, #8]
    4528:	d37df297 	lsl	x23, x20, #3
    452c:	91000694 	add	x20, x20, #0x1
    4530:	f9000276 	str	x22, [x19]
    4534:	f9000a7a 	str	x26, [x19, #16]
    4538:	a9446bf9 	ldp	x25, x26, [sp, #64]
    453c:	f9000674 	str	x20, [x19, #8]
    4540:	f8376ad5 	str	x21, [x22, x23]
    4544:	a94153f3 	ldp	x19, x20, [sp, #16]
    4548:	a9425bf5 	ldp	x21, x22, [sp, #32]
    454c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4550:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4554:	d65f03c0 	ret
    4558:	b0000040 	adrp	x0, d000 <atexit+0x10>
    455c:	91074000 	add	x0, x0, #0x1d0
    4560:	97fffe4c 	bl	3e90 <fwp_trap>
    4564:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4568:	f947e863 	ldr	x3, [x3, #4048]
    456c:	d2800262 	mov	x2, #0x13                  	// #19
    4570:	d2800021 	mov	x1, #0x1                   	// #1
    4574:	b0000040 	adrp	x0, d000 <atexit+0x10>
    4578:	9100a000 	add	x0, x0, #0x28
    457c:	f9400063 	ldr	x3, [x3]
    4580:	97fff900 	bl	2980 <fwrite@plt>
    4584:	d2800000 	mov	x0, #0x0                   	// #0
    4588:	97fff90a 	bl	29b0 <fflush@plt>
    458c:	52800cc0 	mov	w0, #0x66                  	// #102
    4590:	97fff918 	bl	29f0 <_Exit@plt>

0000000000004594 <fwp_closure_drop.part.0>:
    4594:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4598:	b0000041 	adrp	x1, d000 <atexit+0x10>
    459c:	910003fd 	mov	x29, sp
    45a0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    45a4:	f947f463 	ldr	x3, [x3, #4072]
    45a8:	a90153f3 	stp	x19, x20, [sp, #16]
    45ac:	d10883ff 	sub	sp, sp, #0x220
    45b0:	910003e2 	mov	x2, sp
    45b4:	d53bd053 	mrs	x19, tpidr_el0
    45b8:	910063f4 	add	x20, sp, #0x18
    45bc:	3dc33c20 	ldr	q0, [x1, #3312]
    45c0:	91400264 	add	x4, x19, #0x0, lsl #12
    45c4:	91004084 	add	x4, x4, #0x10
    45c8:	aa0003e1 	mov	x1, x0
    45cc:	aa0203e0 	mov	x0, x2
    45d0:	f9400062 	ldr	x2, [x3]
    45d4:	f9010fe2 	str	x2, [sp, #536]
    45d8:	d2800002 	mov	x2, #0x0                   	// #0
    45dc:	f90003f4 	str	x20, [sp]
    45e0:	f9000080 	str	x0, [x4]
    45e4:	3c8083e0 	stur	q0, [sp, #8]
    45e8:	97ffffa6 	bl	4480 <fwp_closure_drop_push>
    45ec:	f94007e0 	ldr	x0, [sp, #8]
    45f0:	b40002e0 	cbz	x0, 464c <fwp_closure_drop.part.0+0xb8>
    45f4:	f90123f5 	str	x21, [sp, #576]
    45f8:	900000f5 	adrp	x21, 20000 <__data_start>
    45fc:	9100c2b5 	add	x21, x21, #0x30
    4600:	14000006 	b	4618 <fwp_closure_drop.part.0+0x84>
    4604:	f9400422 	ldr	x2, [x1, #8]
    4608:	52800001 	mov	w1, #0x0                   	// #0
    460c:	d63f0040 	blr	x2
    4610:	f94007e0 	ldr	x0, [sp, #8]
    4614:	b40001a0 	cbz	x0, 4648 <fwp_closure_drop.part.0+0xb4>
    4618:	f94003e1 	ldr	x1, [sp]
    461c:	d1000400 	sub	x0, x0, #0x1
    4620:	f90007e0 	str	x0, [sp, #8]
    4624:	f9403ea2 	ldr	x2, [x21, #120]
    4628:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    462c:	b9400001 	ldr	w1, [x0]
    4630:	8b011441 	add	x1, x2, x1, lsl #5
    4634:	f9400c21 	ldr	x1, [x1, #24]
    4638:	b5fffe61 	cbnz	x1, 4604 <fwp_closure_drop.part.0+0x70>
    463c:	b0000040 	adrp	x0, d000 <atexit+0x10>
    4640:	9107c000 	add	x0, x0, #0x1f0
    4644:	97fffe13 	bl	3e90 <fwp_trap>
    4648:	f94123f5 	ldr	x21, [sp, #576]
    464c:	91400273 	add	x19, x19, #0x0, lsl #12
    4650:	91004273 	add	x19, x19, #0x10
    4654:	f94003e0 	ldr	x0, [sp]
    4658:	f900027f 	str	xzr, [x19]
    465c:	eb14001f 	cmp	x0, x20
    4660:	54000040 	b.eq	4668 <fwp_closure_drop.part.0+0xd4>  // b.none
    4664:	97fff8b7 	bl	2940 <free@plt>
    4668:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    466c:	f947f400 	ldr	x0, [x0, #4072]
    4670:	f9410fe2 	ldr	x2, [sp, #536]
    4674:	f9400001 	ldr	x1, [x0]
    4678:	eb010042 	subs	x2, x2, x1
    467c:	d2800001 	mov	x1, #0x0                   	// #0
    4680:	540000a1 	b.ne	4694 <fwp_closure_drop.part.0+0x100>  // b.any
    4684:	910883ff 	add	sp, sp, #0x220
    4688:	a94153f3 	ldp	x19, x20, [sp, #16]
    468c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4690:	d65f03c0 	ret
    4694:	f90123f5 	str	x21, [sp, #576]
    4698:	97fff87a 	bl	2880 <__stack_chk_fail@plt>
    469c:	d503201f 	nop

00000000000046a0 <fwp_tape_of>:
    46a0:	aa0003e1 	mov	x1, x0
    46a4:	92403c00 	and	x0, x0, #0xffff
    46a8:	b40000e0 	cbz	x0, 46c4 <fwp_tape_of+0x24>
    46ac:	d1000402 	sub	x2, x0, #0x1
    46b0:	900000e3 	adrp	x3, 20000 <__data_start>
    46b4:	9100c060 	add	x0, x3, #0x30
    46b8:	f9404000 	ldr	x0, [x0, #128]
    46bc:	eb02001f 	cmp	x0, x2
    46c0:	540000cc 	b.gt	46d8 <fwp_tape_of+0x38>
    46c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    46c8:	b0000040 	adrp	x0, d000 <atexit+0x10>
    46cc:	91088000 	add	x0, x0, #0x220
    46d0:	910003fd 	mov	x29, sp
    46d4:	97fffdef 	bl	3e90 <fwp_trap>
    46d8:	8b020440 	add	x0, x2, x2, lsl #1
    46dc:	f9401863 	ldr	x3, [x3, #48]
    46e0:	8b000842 	add	x2, x2, x0, lsl #2
    46e4:	d37df042 	lsl	x2, x2, #3
    46e8:	8b020060 	add	x0, x3, x2
    46ec:	b9400404 	ldr	w4, [x0, #4]
    46f0:	34fffea4 	cbz	w4, 46c4 <fwp_tape_of+0x24>
    46f4:	b8626862 	ldr	w2, [x3, x2]
    46f8:	9350fc21 	asr	x1, x1, #16
    46fc:	6b01005f 	cmp	w2, w1
    4700:	54fffe21 	b.ne	46c4 <fwp_tape_of+0x24>  // b.any
    4704:	d65f03c0 	ret
    4708:	d503201f 	nop
    470c:	d503201f 	nop

0000000000004710 <fwp_now_ns>:
    4710:	d100c3ff 	sub	sp, sp, #0x30
    4714:	52800020 	mov	w0, #0x1                   	// #1
    4718:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    471c:	f947f442 	ldr	x2, [x2, #4072]
    4720:	910023e1 	add	x1, sp, #0x8
    4724:	a9027bfd 	stp	x29, x30, [sp, #32]
    4728:	910083fd 	add	x29, sp, #0x20
    472c:	f9400043 	ldr	x3, [x2]
    4730:	f9000fe3 	str	x3, [sp, #24]
    4734:	d2800003 	mov	x3, #0x0                   	// #0
    4738:	97fff81e 	bl	27b0 <clock_gettime@plt>
    473c:	350002c0 	cbnz	w0, 4794 <fwp_now_ns+0x84>
    4740:	a9408be1 	ldp	x1, x2, [sp, #8]
    4744:	d2994003 	mov	x3, #0xca00                	// #51712
    4748:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    474c:	9b037c20 	mul	x0, x1, x3
    4750:	9b437c21 	smulh	x1, x1, x3
    4754:	ab020000 	adds	x0, x0, x2
    4758:	937ffc42 	asr	x2, x2, #63
    475c:	9a020021 	adc	x1, x1, x2
    4760:	f100001f 	cmp	x0, #0x0
    4764:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4768:	b50001c1 	cbnz	x1, 47a0 <fwp_now_ns+0x90>
    476c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4770:	f947f421 	ldr	x1, [x1, #4072]
    4774:	f9400fe3 	ldr	x3, [sp, #24]
    4778:	f9400022 	ldr	x2, [x1]
    477c:	eb020063 	subs	x3, x3, x2
    4780:	d2800002 	mov	x2, #0x0                   	// #0
    4784:	54000141 	b.ne	47ac <fwp_now_ns+0x9c>  // b.any
    4788:	a9427bfd 	ldp	x29, x30, [sp, #32]
    478c:	9100c3ff 	add	sp, sp, #0x30
    4790:	d65f03c0 	ret
    4794:	b0000040 	adrp	x0, d000 <atexit+0x10>
    4798:	9109c000 	add	x0, x0, #0x270
    479c:	97fffdbd 	bl	3e90 <fwp_trap>
    47a0:	b0000040 	adrp	x0, d000 <atexit+0x10>
    47a4:	910a4000 	add	x0, x0, #0x290
    47a8:	97fffdba 	bl	3e90 <fwp_trap>
    47ac:	97fff835 	bl	2880 <__stack_chk_fail@plt>

00000000000047b0 <fwp_poll_events>:
    47b0:	d10103ff 	sub	sp, sp, #0x40
    47b4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    47b8:	f947f400 	ldr	x0, [x0, #4072]
    47bc:	a9027bfd 	stp	x29, x30, [sp, #32]
    47c0:	910083fd 	add	x29, sp, #0x20
    47c4:	f9001bf3 	str	x19, [sp, #48]
    47c8:	900000f3 	adrp	x19, 20000 <__data_start>
    47cc:	f9400001 	ldr	x1, [x0]
    47d0:	f9000fe1 	str	x1, [sp, #24]
    47d4:	d2800001 	mov	x1, #0x0                   	// #0
    47d8:	97ffffce 	bl	4710 <fwp_now_ns>
    47dc:	9100c261 	add	x1, x19, #0x30
    47e0:	f9404421 	ldr	x1, [x1, #136]
    47e4:	b4000e01 	cbz	x1, 49a4 <fwp_poll_events+0x1f4>
    47e8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    47ec:	14000005 	b	4800 <fwp_poll_events+0x50>
    47f0:	f9408821 	ldr	x1, [x1, #272]
    47f4:	eb03005f 	cmp	x2, x3
    47f8:	9a83d042 	csel	x2, x2, x3, le
    47fc:	b40000c1 	cbz	x1, 4814 <fwp_poll_events+0x64>
    4800:	f9403423 	ldr	x3, [x1, #104]
    4804:	b6ffff62 	tbz	x2, #63, 47f0 <fwp_poll_events+0x40>
    4808:	f9408821 	ldr	x1, [x1, #272]
    480c:	aa0303e2 	mov	x2, x3
    4810:	b5ffff81 	cbnz	x1, 4800 <fwp_poll_events+0x50>
    4814:	b7f80c82 	tbnz	x2, #63, 49a4 <fwp_poll_events+0x1f4>
    4818:	cb000042 	sub	x2, x2, x0
    481c:	f100005f 	cmp	x2, #0x0
    4820:	540003ad 	b.le	4894 <fwp_poll_events+0xe4>
    4824:	d2869b60 	mov	x0, #0x34db                	// #13531
    4828:	d2884804 	mov	x4, #0x4240                	// #16960
    482c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4830:	f2a001e4 	movk	x4, #0xf, lsl #16
    4834:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4838:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    483c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4840:	9b407c40 	smulh	x0, x2, x0
    4844:	9352fc00 	asr	x0, x0, #18
    4848:	cb82fc00 	sub	x0, x0, x2, asr #63
    484c:	9b048802 	msub	x2, x0, x4, x2
    4850:	f100005f 	cmp	x2, #0x0
    4854:	9a800400 	cinc	x0, x0, ne	// ne = any
    4858:	eb01001f 	cmp	x0, x1
    485c:	5400098c 	b.gt	498c <fwp_poll_events+0x1dc>
    4860:	340001a0 	cbz	w0, 4894 <fwp_poll_events+0xe4>
    4864:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4868:	52807d05 	mov	w5, #0x3e8                 	// #1000
    486c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4870:	9ba17c01 	umull	x1, w0, w1
    4874:	d366fc23 	lsr	x3, x1, #38
    4878:	aa0303e2 	mov	x2, x3
    487c:	1b058063 	msub	w3, w3, w5, w0
    4880:	9b247c63 	smull	x3, w3, w4
    4884:	910023e0 	add	x0, sp, #0x8
    4888:	d2800001 	mov	x1, #0x0                   	// #0
    488c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4890:	97fff830 	bl	2950 <nanosleep@plt>
    4894:	97ffff9f 	bl	4710 <fwp_now_ns>
    4898:	9100c268 	add	x8, x19, #0x30
    489c:	aa0003e7 	mov	x7, x0
    48a0:	4f000400 	movi	v0.4s, #0x0
    48a4:	52800029 	mov	w9, #0x1                   	// #1
    48a8:	f9404506 	ldr	x6, [x8, #136]
    48ac:	d503201f 	nop
    48b0:	b40003e6 	cbz	x6, 492c <fwp_poll_events+0x17c>
    48b4:	f94034c1 	ldr	x1, [x6, #104]
    48b8:	aa0603e5 	mov	x5, x6
    48bc:	f94088c6 	ldr	x6, [x6, #272]
    48c0:	eb07003f 	cmp	x1, x7
    48c4:	54ffff6c 	b.gt	48b0 <fwp_poll_events+0x100>
    48c8:	394154a0 	ldrb	w0, [x5, #85]
    48cc:	36000120 	tbz	w0, #0, 48f0 <fwp_poll_events+0x140>
    48d0:	f94084a0 	ldr	x0, [x5, #264]
    48d4:	b4000560 	cbz	x0, 4980 <fwp_poll_events+0x1d0>
    48d8:	f9008806 	str	x6, [x0, #272]
    48dc:	b4000046 	cbz	x6, 48e4 <fwp_poll_events+0x134>
    48e0:	f90084c0 	str	x0, [x6, #264]
    48e4:	910800a0 	add	x0, x5, #0x200
    48e8:	390154bf 	strb	wzr, [x5, #85]
    48ec:	3c908000 	stur	q0, [x0, #-248]
    48f0:	f94030a0 	ldr	x0, [x5, #96]
    48f4:	390158a9 	strb	w9, [x5, #86]
    48f8:	f100001f 	cmp	x0, #0x0
    48fc:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4900:	540002cd 	b.le	4958 <fwp_poll_events+0x1a8>
    4904:	f94028a0 	ldr	x0, [x5, #80]
    4908:	f2001c1f 	tst	x0, #0xff000000ff
    490c:	54fffd21 	b.ne	48b0 <fwp_poll_events+0x100>  // b.any
    4910:	f9401500 	ldr	x0, [x8, #40]
    4914:	390150a9 	strb	w9, [x5, #84]
    4918:	f90080bf 	str	xzr, [x5, #256]
    491c:	b40002c0 	cbz	x0, 4974 <fwp_poll_events+0x1c4>
    4920:	f9001505 	str	x5, [x8, #40]
    4924:	f9008005 	str	x5, [x0, #256]
    4928:	b5fffc66 	cbnz	x6, 48b4 <fwp_poll_events+0x104>
    492c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4930:	f947f400 	ldr	x0, [x0, #4072]
    4934:	f9400fe2 	ldr	x2, [sp, #24]
    4938:	f9400001 	ldr	x1, [x0]
    493c:	eb010042 	subs	x2, x2, x1
    4940:	d2800001 	mov	x1, #0x0                   	// #0
    4944:	540002e1 	b.ne	49a0 <fwp_poll_events+0x1f0>  // b.any
    4948:	a9427bfd 	ldp	x29, x30, [sp, #32]
    494c:	f9401bf3 	ldr	x19, [sp, #48]
    4950:	910103ff 	add	sp, sp, #0x40
    4954:	d65f03c0 	ret
    4958:	394144a0 	ldrb	w0, [x5, #81]
    495c:	3707fd40 	tbnz	w0, #0, 4904 <fwp_poll_events+0x154>
    4960:	394140a0 	ldrb	w0, [x5, #80]
    4964:	3707fd00 	tbnz	w0, #0, 4904 <fwp_poll_events+0x154>
    4968:	aa0503e0 	mov	x0, x5
    496c:	97fffac1 	bl	3470 <fwp_cancel_tree.part.0>
    4970:	17ffffe5 	b	4904 <fwp_poll_events+0x154>
    4974:	f9001505 	str	x5, [x8, #40]
    4978:	f9001905 	str	x5, [x8, #48]
    497c:	17ffffeb 	b	4928 <fwp_poll_events+0x178>
    4980:	9100c261 	add	x1, x19, #0x30
    4984:	f9004426 	str	x6, [x1, #136]
    4988:	17ffffd5 	b	48dc <fwp_poll_events+0x12c>
    498c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4990:	d2989362 	mov	x2, #0xc49b                	// #50331
    4994:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4998:	f2a00402 	movk	x2, #0x20, lsl #16
    499c:	17ffffba 	b	4884 <fwp_poll_events+0xd4>
    49a0:	97fff7b8 	bl	2880 <__stack_chk_fail@plt>
    49a4:	97fff993 	bl	2ff0 <fwp_flush>
    49a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    49ac:	f947e863 	ldr	x3, [x3, #4048]
    49b0:	d2800562 	mov	x2, #0x2b                  	// #43
    49b4:	d2800021 	mov	x1, #0x1                   	// #1
    49b8:	b0000040 	adrp	x0, d000 <atexit+0x10>
    49bc:	910ae000 	add	x0, x0, #0x2b8
    49c0:	f9400063 	ldr	x3, [x3]
    49c4:	97fff7ef 	bl	2980 <fwrite@plt>
    49c8:	52800ca0 	mov	w0, #0x65                  	// #101
    49cc:	97fff759 	bl	2730 <exit@plt>

00000000000049d0 <fwp_heap_alloc_big>:
    49d0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49d4:	910003fd 	mov	x29, sp
    49d8:	a90153f3 	stp	x19, x20, [sp, #16]
    49dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    49e0:	a90363f7 	stp	x23, x24, [sp, #48]
    49e4:	aa0003f7 	mov	x23, x0
    49e8:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    49f0:	eb0002ff 	cmp	x23, x0
    49f4:	540008a8 	b.hi	4b08 <fwp_heap_alloc_big+0x138>  // b.pmore
    49f8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    49fc:	8b0002f4 	add	x20, x23, x0
    4a00:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xca0>
    4a04:	91150359 	add	x25, x26, #0x540
    4a08:	d350fe94 	lsr	x20, x20, #16
    4a0c:	2a0103f5 	mov	w21, w1
    4a10:	aa1403e0 	mov	x0, x20
    4a14:	97fff9c7 	bl	3130 <fwp_heap_chunks>
    4a18:	f949ff22 	ldr	x2, [x25, #5112]
    4a1c:	8b000813 	add	x19, x0, x0, lsl #2
    4a20:	aa0003f8 	mov	x24, x0
    4a24:	52800043 	mov	w3, #0x2                   	// #2
    4a28:	d37df273 	lsl	x19, x19, #3
    4a2c:	d2800021 	mov	x1, #0x1                   	// #1
    4a30:	8b130040 	add	x0, x2, x19
    4a34:	38336843 	strb	w3, [x2, x19]
    4a38:	39000415 	strb	w21, [x0, #1]
    4a3c:	b9000c14 	str	w20, [x0, #12]
    4a40:	f9000817 	str	x23, [x0, #16]
    4a44:	97fffd57 	bl	3fa0 <fwp_rc_prepare_chunk>
    4a48:	f100069f 	cmp	x20, #0x1
    4a4c:	54000289 	b.ls	4a9c <fwp_heap_alloc_big+0xcc>  // b.plast
    4a50:	8b180294 	add	x20, x20, x24
    4a54:	9100a273 	add	x19, x19, #0x28
    4a58:	a90573fb 	stp	x27, x28, [sp, #80]
    4a5c:	5280007b 	mov	w27, #0x3                   	// #3
    4a60:	8b140a94 	add	x20, x20, x20, lsl #2
    4a64:	2a1803fc 	mov	w28, w24
    4a68:	9adb2296 	lsl	x22, x20, x27
    4a6c:	d503201f 	nop
    4a70:	f949ff35 	ldr	x21, [x25, #5112]
    4a74:	d2800001 	mov	x1, #0x0                   	// #0
    4a78:	8b1302b4 	add	x20, x21, x19
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	97fffd48 	bl	3fa0 <fwp_rc_prepare_chunk>
    4a84:	38336abb 	strb	w27, [x21, x19]
    4a88:	9100a273 	add	x19, x19, #0x28
    4a8c:	b9000e9c 	str	w28, [x20, #12]
    4a90:	eb1302df 	cmp	x22, x19
    4a94:	54fffee1 	b.ne	4a70 <fwp_heap_alloc_big+0xa0>  // b.any
    4a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a9c:	91150353 	add	x19, x26, #0x540
    4aa0:	aa1703e2 	mov	x2, x23
    4aa4:	52800001 	mov	w1, #0x0                   	// #0
    4aa8:	f949da60 	ldr	x0, [x19, #5040]
    4aac:	8b184018 	add	x24, x0, x24, lsl #16
    4ab0:	aa1803e0 	mov	x0, x24
    4ab4:	97fff767 	bl	2850 <memset@plt>
    4ab8:	f94a1260 	ldr	x0, [x19, #5152]
    4abc:	ab170000 	adds	x0, x0, x23
    4ac0:	54000242 	b.cs	4b08 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4ac4:	f94a1661 	ldr	x1, [x19, #5160]
    4ac8:	f90a1260 	str	x0, [x19, #5152]
    4acc:	eb01001f 	cmp	x0, x1
    4ad0:	54000049 	b.ls	4ad8 <fwp_heap_alloc_big+0x108>  // b.plast
    4ad4:	f90a1660 	str	x0, [x19, #5160]
    4ad8:	9115035a 	add	x26, x26, #0x540
    4adc:	9e6202e0 	scvtf	d0, x23
    4ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae4:	aa1803e0 	mov	x0, x24
    4ae8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4af0:	1e602820 	fadd	d0, d1, d0
    4af4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4af8:	fd0a1f40 	str	d0, [x26, #5176]
    4afc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b04:	d65f03c0 	ret
    4b08:	a90573fb 	stp	x27, x28, [sp, #80]
    4b0c:	97fff949 	bl	3030 <fwp_heap_oom>

0000000000004b10 <fwp_heap_alloc_slow>:
    4b10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b14:	910003fd 	mov	x29, sp
    4b18:	a90153f3 	stp	x19, x20, [sp, #16]
    4b1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xca0>
    4b20:	91150262 	add	x2, x19, #0x540
    4b24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b28:	aa0003f5 	mov	x21, x0
    4b2c:	2a0103f4 	mov	w20, w1
    4b30:	b953a440 	ldr	w0, [x2, #5028]
    4b34:	34000600 	cbz	w0, 4bf4 <fwp_heap_alloc_slow+0xe4>
    4b38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b3c:	54000628 	b.hi	4c00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b40:	91003ea0 	add	x0, x21, #0xf
    4b44:	91150262 	add	x2, x19, #0x540
    4b48:	f9001bf7 	str	x23, [sp, #48]
    4b4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b50:	8b401040 	add	x0, x2, x0, lsr #4
    4b54:	cb34c084 	sub	x4, x4, w20, sxtw
    4b58:	d37ae484 	lsl	x4, x4, #6
    4b5c:	397e8003 	ldrb	w3, [x0, #4000]
    4b60:	910f0060 	add	x0, x3, #0x3c0
    4b64:	aa0303e1 	mov	x1, x3
    4b68:	8b030463 	add	x3, x3, x3, lsl #1
    4b6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b74:	2a1703f6 	mov	w22, w23
    4b78:	f8636844 	ldr	x4, [x2, x3]
    4b7c:	b40004e4 	cbz	x4, 4c18 <fwp_heap_alloc_slow+0x108>
    4b80:	f9400080 	ldr	x0, [x4]
    4b84:	aa2003e0 	mvn	x0, x0
    4b88:	f8236840 	str	x0, [x2, x3]
    4b8c:	7100069f 	cmp	w20, #0x1
    4b90:	aa0403e0 	mov	x0, x4
    4b94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b98:	52800001 	mov	w1, #0x0                   	// #0
    4b9c:	97fff72d 	bl	2850 <memset@plt>
    4ba0:	aa0003e4 	mov	x4, x0
    4ba4:	91150260 	add	x0, x19, #0x540
    4ba8:	f94a1001 	ldr	x1, [x0, #5152]
    4bac:	ab160021 	adds	x1, x1, x22
    4bb0:	540005c2 	b.cs	4c68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4bb4:	f94a1402 	ldr	x2, [x0, #5160]
    4bb8:	f90a1001 	str	x1, [x0, #5152]
    4bbc:	eb02003f 	cmp	x1, x2
    4bc0:	54000049 	b.ls	4bc8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4bc4:	f90a1401 	str	x1, [x0, #5160]
    4bc8:	91150273 	add	x19, x19, #0x540
    4bcc:	1e6302e1 	ucvtf	d1, w23
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	aa0403e0 	mov	x0, x4
    4bd8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bdc:	f9401bf7 	ldr	x23, [sp, #48]
    4be0:	1e612800 	fadd	d0, d0, d1
    4be4:	fd0a1e60 	str	d0, [x19, #5176]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bf0:	d65f03c0 	ret
    4bf4:	97fffbbf 	bl	3af0 <fwp_heap_init>
    4bf8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bfc:	54fffa29 	b.ls	4b40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c00:	2a1403e1 	mov	w1, w20
    4c04:	aa1503e0 	mov	x0, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c14:	17ffff6f 	b	49d0 <fwp_heap_alloc_big>
    4c18:	8b030042 	add	x2, x2, x3
    4c1c:	f9400444 	ldr	x4, [x2, #8]
    4c20:	b4000104 	cbz	x4, 4c40 <fwp_heap_alloc_slow+0x130>
    4c24:	f9400840 	ldr	x0, [x2, #16]
    4c28:	cb040000 	sub	x0, x0, x4
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54000083 	b.cc	4c40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c34:	8b160080 	add	x0, x4, x22
    4c38:	f9000440 	str	x0, [x2, #8]
    4c3c:	17ffffd4 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c40:	52800302 	mov	w2, #0x18                  	// #24
    4c44:	52807804 	mov	w4, #0x3c0                 	// #960
    4c48:	91150260 	add	x0, x19, #0x540
    4c4c:	9ba27c23 	umull	x3, w1, w2
    4c50:	2a1403e2 	mov	w2, w20
    4c54:	9b240e84 	smaddl	x4, w20, w4, x3
    4c58:	8b040000 	add	x0, x0, x4
    4c5c:	97fffd19 	bl	40c0 <fwp_heap_refill>
    4c60:	aa0003e4 	mov	x4, x0
    4c64:	17ffffca 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c68:	97fff8f2 	bl	3030 <fwp_heap_oom>
    4c6c:	d503201f 	nop

0000000000004c70 <fwp_heap_alloc>:
    4c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c74:	f140101f 	cmp	x0, #0x4, lsl #12
    4c78:	910003fd 	mov	x29, sp
    4c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4c84:	91150293 	add	x19, x20, #0x540
    4c88:	b953a662 	ldr	w2, [x19, #5028]
    4c8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c90:	54000640 	b.eq	4d58 <fwp_heap_alloc+0xe8>  // b.none
    4c94:	91003c03 	add	x3, x0, #0xf
    4c98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ca0:	8b431263 	add	x3, x19, x3, lsr #4
    4ca4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ca8:	d37ae442 	lsl	x2, x2, #6
    4cac:	397e8063 	ldrb	w3, [x3, #4000]
    4cb0:	910f0064 	add	x4, x3, #0x3c0
    4cb4:	8b030463 	add	x3, x3, x3, lsl #1
    4cb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4cbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4cc0:	2a1603f5 	mov	w21, w22
    4cc4:	f8636a64 	ldr	x4, [x19, x3]
    4cc8:	b4000384 	cbz	x4, 4d38 <fwp_heap_alloc+0xc8>
    4ccc:	f9400085 	ldr	x5, [x4]
    4cd0:	7100043f 	cmp	w1, #0x1
    4cd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cd8:	aa0403e0 	mov	x0, x4
    4cdc:	aa2503e5 	mvn	x5, x5
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	f8236a65 	str	x5, [x19, x3]
    4ce8:	97fff6da 	bl	2850 <memset@plt>
    4cec:	aa0003e4 	mov	x4, x0
    4cf0:	f94a1260 	ldr	x0, [x19, #5152]
    4cf4:	ab150000 	adds	x0, x0, x21
    4cf8:	54000442 	b.cs	4d80 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4cfc:	f94a1661 	ldr	x1, [x19, #5160]
    4d00:	f90a1260 	str	x0, [x19, #5152]
    4d04:	eb01001f 	cmp	x0, x1
    4d08:	54000049 	b.ls	4d10 <fwp_heap_alloc+0xa0>  // b.plast
    4d0c:	f90a1660 	str	x0, [x19, #5160]
    4d10:	91150294 	add	x20, x20, #0x540
    4d14:	1e6302c1 	ucvtf	d1, w22
    4d18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d1c:	aa0403e0 	mov	x0, x4
    4d20:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d24:	1e612800 	fadd	d0, d0, d1
    4d28:	fd0a1e80 	str	d0, [x20, #5176]
    4d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d34:	d65f03c0 	ret
    4d38:	8b030263 	add	x3, x19, x3
    4d3c:	f9400464 	ldr	x4, [x3, #8]
    4d40:	b40000a4 	cbz	x4, 4d54 <fwp_heap_alloc+0xe4>
    4d44:	f9400862 	ldr	x2, [x3, #16]
    4d48:	cb040042 	sub	x2, x2, x4
    4d4c:	eb15005f 	cmp	x2, x21
    4d50:	540000a2 	b.cs	4d64 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d60:	17ffff6c 	b	4b10 <fwp_heap_alloc_slow>
    4d64:	7100043f 	cmp	w1, #0x1
    4d68:	8b150085 	add	x5, x4, x21
    4d6c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d70:	52800001 	mov	w1, #0x0                   	// #0
    4d74:	aa0403e0 	mov	x0, x4
    4d78:	f9000465 	str	x5, [x3, #8]
    4d7c:	17ffffdb 	b	4ce8 <fwp_heap_alloc+0x78>
    4d80:	97fff8ac 	bl	3030 <fwp_heap_oom>

0000000000004d84 <fwp_data.part.0.constprop.0>:
    4d84:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d88:	910003fd 	mov	x29, sp
    4d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d90:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xca0>
    4d94:	91150283 	add	x3, x20, #0x540
    4d98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d9c:	aa0103f5 	mov	x21, x1
    4da0:	b953a461 	ldr	w1, [x3, #5028]
    4da4:	a90363f7 	stp	x23, x24, [sp, #48]
    4da8:	2a0003f8 	mov	w24, w0
    4dac:	34000701 	cbz	w1, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4db0:	397e8862 	ldrb	w2, [x3, #4002]
    4db4:	910f0040 	add	x0, x2, #0x3c0
    4db8:	8b020442 	add	x2, x2, x2, lsl #1
    4dbc:	d37df042 	lsl	x2, x2, #3
    4dc0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4dc4:	2a1703f6 	mov	w22, w23
    4dc8:	f8626873 	ldr	x19, [x3, x2]
    4dcc:	b40004d3 	cbz	x19, 4e64 <fwp_data.part.0.constprop.0+0xe0>
    4dd0:	f9400260 	ldr	x0, [x19]
    4dd4:	aa2003e0 	mvn	x0, x0
    4dd8:	f8226860 	str	x0, [x3, x2]
    4ddc:	f10062df 	cmp	x22, #0x18
    4de0:	540000e9 	b.ls	4dfc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4de4:	d10066c2 	sub	x2, x22, #0x19
    4de8:	91006260 	add	x0, x19, #0x18
    4dec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4df0:	52800001 	mov	w1, #0x0                   	// #0
    4df4:	91002042 	add	x2, x2, #0x8
    4df8:	97fff696 	bl	2850 <memset@plt>
    4dfc:	91150282 	add	x2, x20, #0x540
    4e00:	f94a1041 	ldr	x1, [x2, #5152]
    4e04:	ab160021 	adds	x1, x1, x22
    4e08:	540004c2 	b.cs	4ea0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e0c:	f94a1440 	ldr	x0, [x2, #5160]
    4e10:	f90a1041 	str	x1, [x2, #5152]
    4e14:	eb00003f 	cmp	x1, x0
    4e18:	54000049 	b.ls	4e20 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e1c:	f90a1441 	str	x1, [x2, #5160]
    4e20:	91150294 	add	x20, x20, #0x540
    4e24:	1e6302e1 	ucvtf	d1, w23
    4e28:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e2c:	1e612800 	fadd	d0, d0, d1
    4e30:	fd0a1e80 	str	d0, [x20, #5176]
    4e34:	52800041 	mov	w1, #0x2                   	// #2
    4e38:	29000678 	stp	w24, w1, [x19]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	f94002a1 	ldr	x1, [x21]
    4e44:	f9000661 	str	x1, [x19, #8]
    4e48:	f94006a1 	ldr	x1, [x21, #8]
    4e4c:	f9000a61 	str	x1, [x19, #16]
    4e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	8b020063 	add	x3, x3, x2
    4e68:	f9400473 	ldr	x19, [x3, #8]
    4e6c:	b4000113 	cbz	x19, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4e70:	f9400860 	ldr	x0, [x3, #16]
    4e74:	cb130000 	sub	x0, x0, x19
    4e78:	eb0002df 	cmp	x22, x0
    4e7c:	54000088 	b.hi	4e8c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4e80:	8b160260 	add	x0, x19, x22
    4e84:	f9000460 	str	x0, [x3, #8]
    4e88:	17ffffd5 	b	4ddc <fwp_data.part.0.constprop.0+0x58>
    4e8c:	52800001 	mov	w1, #0x0                   	// #0
    4e90:	d2800300 	mov	x0, #0x18                  	// #24
    4e94:	97ffff77 	bl	4c70 <fwp_heap_alloc>
    4e98:	aa0003f3 	mov	x19, x0
    4e9c:	17ffffe6 	b	4e34 <fwp_data.part.0.constprop.0+0xb0>
    4ea0:	97fff864 	bl	3030 <fwp_heap_oom>

0000000000004ea4 <fwp_tape_reserve>:
    4ea4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4ea8:	910003fd 	mov	x29, sp
    4eac:	a90153f3 	stp	x19, x20, [sp, #16]
    4eb0:	aa0003f3 	mov	x19, x0
    4eb4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4eb8:	eb00003f 	cmp	x1, x0
    4ebc:	54000868 	b.hi	4fc8 <fwp_tape_reserve+0x124>  // b.pmore
    4ec0:	f9400e74 	ldr	x20, [x19, #24]
    4ec4:	eb01029f 	cmp	x20, x1
    4ec8:	5400076a 	b.ge	4fb4 <fwp_tape_reserve+0x110>  // b.tcont
    4ecc:	f100029f 	cmp	x20, #0x0
    4ed0:	d2800802 	mov	x2, #0x40                  	// #64
    4ed4:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    4ed8:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    4edc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ee0:	a90363f7 	stp	x23, x24, [sp, #48]
    4ee4:	eb01029f 	cmp	x20, x1
    4ee8:	5400008a 	b.ge	4ef8 <fwp_tape_reserve+0x54>  // b.tcont
    4eec:	eb00029f 	cmp	x20, x0
    4ef0:	5400068d 	b.le	4fc0 <fwp_tape_reserve+0x11c>
    4ef4:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4ef8:	a940d662 	ldp	x2, x21, [x19, #8]
    4efc:	d37df297 	lsl	x23, x20, #3
    4f00:	f9401260 	ldr	x0, [x19, #32]
    4f04:	aa1703e1 	mov	x1, x23
    4f08:	f9403276 	ldr	x22, [x19, #96]
    4f0c:	cb0202b5 	sub	x21, x21, x2
    4f10:	97fff658 	bl	2870 <realloc@plt>
    4f14:	b4000b00 	cbz	x0, 5074 <fwp_tape_reserve+0x1d0>
    4f18:	f9400e61 	ldr	x1, [x19, #24]
    4f1c:	8b010801 	add	x1, x0, x1, lsl #2
    4f20:	a9020660 	stp	x0, x1, [x19, #32]
    4f24:	b40008b6 	cbz	x22, 5038 <fwp_tape_reserve+0x194>
    4f28:	f94032d7 	ldr	x23, [x22, #96]
    4f2c:	eb17029f 	cmp	x20, x23
    4f30:	5400034d 	b.le	4f98 <fwp_tape_reserve+0xf4>
    4f34:	a9046bf9 	stp	x25, x26, [sp, #64]
    4f38:	d37cee9a 	lsl	x26, x20, #4
    4f3c:	aa1a03e0 	mov	x0, x26
    4f40:	f94022d9 	ldr	x25, [x22, #64]
    4f44:	52800041 	mov	w1, #0x2                   	// #2
    4f48:	97ffff4a 	bl	4c70 <fwp_heap_alloc>
    4f4c:	aa0003f8 	mov	x24, x0
    4f50:	b4000119 	cbz	x25, 4f70 <fwp_tape_reserve+0xcc>
    4f54:	d37ceef7 	lsl	x23, x23, #4
    4f58:	aa1903e1 	mov	x1, x25
    4f5c:	eb1a02ff 	cmp	x23, x26
    4f60:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    4f64:	97fff5db 	bl	26d0 <memcpy@plt>
    4f68:	aa1903e0 	mov	x0, x25
    4f6c:	97fffc85 	bl	4180 <fwp_mem_free>
    4f70:	f94032c0 	ldr	x0, [x22, #96]
    4f74:	52800001 	mov	w1, #0x0                   	// #0
    4f78:	cb000282 	sub	x2, x20, x0
    4f7c:	8b001300 	add	x0, x24, x0, lsl #4
    4f80:	d37cec42 	lsl	x2, x2, #4
    4f84:	97fff633 	bl	2850 <memset@plt>
    4f88:	f9401260 	ldr	x0, [x19, #32]
    4f8c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f90:	f90022d8 	str	x24, [x22, #64]
    4f94:	f90032d4 	str	x20, [x22, #96]
    4f98:	d37ef696 	lsl	x22, x20, #2
    4f9c:	b5000375 	cbnz	x21, 5008 <fwp_tape_reserve+0x164>
    4fa0:	a94363f7 	ldp	x23, x24, [sp, #48]
    4fa4:	8b160000 	add	x0, x0, x22
    4fa8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fac:	f9000e74 	str	x20, [x19, #24]
    4fb0:	f9001660 	str	x0, [x19, #40]
    4fb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4fbc:	d65f03c0 	ret
    4fc0:	d37ffa94 	lsl	x20, x20, #1
    4fc4:	17ffffc8 	b	4ee4 <fwp_tape_reserve+0x40>
    4fc8:	b0000040 	adrp	x0, d000 <atexit+0x10>
    4fcc:	910c4000 	add	x0, x0, #0x310
    4fd0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fd4:	a90363f7 	stp	x23, x24, [sp, #48]
    4fd8:	a9046bf9 	stp	x25, x26, [sp, #64]
    4fdc:	97fffbad 	bl	3e90 <fwp_trap>
    4fe0:	eb1602ff 	cmp	x23, x22
    4fe4:	aa0403e0 	mov	x0, x4
    4fe8:	9a9622e3 	csel	x3, x23, x22, cs	// cs = hs, nlast
    4fec:	d37df2a2 	lsl	x2, x21, #3
    4ff0:	cb170063 	sub	x3, x3, x23
    4ff4:	97fff68b 	bl	2a20 <__memmove_chk@plt>
    4ff8:	f9401a61 	ldr	x1, [x19, #48]
    4ffc:	f9401260 	ldr	x0, [x19, #32]
    5000:	8b170021 	add	x1, x1, x23
    5004:	f9001e61 	str	x1, [x19, #56]
    5008:	f9401661 	ldr	x1, [x19, #40]
    500c:	d37ef696 	lsl	x22, x20, #2
    5010:	d37ef6a2 	lsl	x2, x21, #2
    5014:	8b160000 	add	x0, x0, x22
    5018:	97fff5b6 	bl	26f0 <memmove@plt>
    501c:	f9401260 	ldr	x0, [x19, #32]
    5020:	a94363f7 	ldp	x23, x24, [sp, #48]
    5024:	8b160000 	add	x0, x0, x22
    5028:	a9425bf5 	ldp	x21, x22, [sp, #32]
    502c:	f9000e74 	str	x20, [x19, #24]
    5030:	f9001660 	str	x0, [x19, #40]
    5034:	17ffffe0 	b	4fb4 <fwp_tape_reserve+0x110>
    5038:	f9401a60 	ldr	x0, [x19, #48]
    503c:	d37cee96 	lsl	x22, x20, #4
    5040:	aa1603e1 	mov	x1, x22
    5044:	97fff60b 	bl	2870 <realloc@plt>
    5048:	b4000160 	cbz	x0, 5074 <fwp_tape_reserve+0x1d0>
    504c:	f9400e62 	ldr	x2, [x19, #24]
    5050:	f9001a60 	str	x0, [x19, #48]
    5054:	8b170004 	add	x4, x0, x23
    5058:	8b020c01 	add	x1, x0, x2, lsl #3
    505c:	f9001e61 	str	x1, [x19, #56]
    5060:	b5fffc15 	cbnz	x21, 4fe0 <fwp_tape_reserve+0x13c>
    5064:	f9401260 	ldr	x0, [x19, #32]
    5068:	d37ef696 	lsl	x22, x20, #2
    506c:	f9001e64 	str	x4, [x19, #56]
    5070:	17ffffcc 	b	4fa0 <fwp_tape_reserve+0xfc>
    5074:	aa1303e0 	mov	x0, x19
    5078:	a9046bf9 	stp	x25, x26, [sp, #64]
    507c:	97fff7c5 	bl	2f90 <fwp_tape_unlink_scope>
    5080:	f9401260 	ldr	x0, [x19, #32]
    5084:	97fff62f 	bl	2940 <free@plt>
    5088:	f9401a60 	ldr	x0, [x19, #48]
    508c:	97fff62d 	bl	2940 <free@plt>
    5090:	f9402260 	ldr	x0, [x19, #64]
    5094:	97fff62b 	bl	2940 <free@plt>
    5098:	f9000e7f 	str	xzr, [x19, #24]
    509c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    50a0:	f947e821 	ldr	x1, [x1, #4048]
    50a4:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    50a8:	d2800262 	mov	x2, #0x13                  	// #19
    50ac:	4f000400 	movi	v0.4s, #0x0
    50b0:	90000040 	adrp	x0, d000 <atexit+0x10>
    50b4:	f9400023 	ldr	x3, [x1]
    50b8:	b900067f 	str	wzr, [x19, #4]
    50bc:	d2800021 	mov	x1, #0x1                   	// #1
    50c0:	9100a000 	add	x0, x0, #0x28
    50c4:	3c808260 	stur	q0, [x19, #8]
    50c8:	ad010260 	stp	q0, q0, [x19, #32]
    50cc:	97fff62d 	bl	2980 <fwrite@plt>
    50d0:	d2800000 	mov	x0, #0x0                   	// #0
    50d4:	97fff637 	bl	29b0 <fflush@plt>
    50d8:	52800cc0 	mov	w0, #0x66                  	// #102
    50dc:	97fff645 	bl	29f0 <_Exit@plt>

00000000000050e0 <f141.constprop.0>:
    50e0:	f100001f 	cmp	x0, #0x0
    50e4:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    50e8:	5400094b 	b.lt	5210 <f141.constprop.0+0x130>  // b.tstop
    50ec:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    50f0:	aa0003e2 	mov	x2, x0
    50f4:	910003fd 	mov	x29, sp
    50f8:	a90153f3 	stp	x19, x20, [sp, #16]
    50fc:	aa0003f4 	mov	x20, x0
    5100:	aa010000 	orr	x0, x0, x1
    5104:	a9025bf5 	stp	x21, x22, [sp, #32]
    5108:	aa0103f6 	mov	x22, x1
    510c:	f9001bf7 	str	x23, [sp, #48]
    5110:	fd001fe8 	str	d8, [sp, #56]
    5114:	b7f80180 	tbnz	x0, #63, 5144 <f141.constprop.0+0x64>
    5118:	9360fc20 	asr	x0, x1, #32
    511c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    5120:	eb82801f 	cmp	x0, x2, asr #32
    5124:	540007a1 	b.ne	5218 <f141.constprop.0+0x138>  // b.any
    5128:	97fffd5e 	bl	46a0 <fwp_tape_of>
    512c:	aa0003f3 	mov	x19, x0
    5130:	f9403000 	ldr	x0, [x0, #96]
    5134:	b40001e0 	cbz	x0, 5170 <f141.constprop.0+0x90>
    5138:	90000040 	adrp	x0, d000 <atexit+0x10>
    513c:	910de000 	add	x0, x0, #0x378
    5140:	97fffb54 	bl	3e90 <fwp_trap>
    5144:	9360fc40 	asr	x0, x2, #32
    5148:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    514c:	b6fffee2 	tbz	x2, #63, 5128 <f141.constprop.0+0x48>
    5150:	2f00e408 	movi	d8, #0x0
    5154:	9360fc20 	asr	x0, x1, #32
    5158:	aa0103f4 	mov	x20, x1
    515c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5160:	97fffd50 	bl	46a0 <fwp_tape_of>
    5164:	aa0003f3 	mov	x19, x0
    5168:	f9403000 	ldr	x0, [x0, #96]
    516c:	b5fffe60 	cbnz	x0, 5138 <f141.constprop.0+0x58>
    5170:	f9400a77 	ldr	x23, [x19, #16]
    5174:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5178:	eb0002ff 	cmp	x23, x0
    517c:	5400044c 	b.gt	5204 <f141.constprop.0+0x124>
    5180:	eb3442ff 	cmp	x23, w20, uxtw
    5184:	5400008d 	b.le	5194 <f141.constprop.0+0xb4>
    5188:	b7f800d6 	tbnz	x22, #63, 51a0 <f141.constprop.0+0xc0>
    518c:	eb3642ff 	cmp	x23, w22, uxtw
    5190:	5400008c 	b.gt	51a0 <f141.constprop.0+0xc0>
    5194:	90000040 	adrp	x0, d000 <atexit+0x10>
    5198:	910ea000 	add	x0, x0, #0x3a8
    519c:	97fffb3d 	bl	3e90 <fwp_trap>
    51a0:	f9400675 	ldr	x21, [x19, #8]
    51a4:	aa1303e0 	mov	x0, x19
    51a8:	cb1502f5 	sub	x21, x23, x21
    51ac:	910006a1 	add	x1, x21, #0x1
    51b0:	97ffff3d 	bl	4ea4 <fwp_tape_reserve>
    51b4:	a9420262 	ldp	x2, x0, [x19, #32]
    51b8:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    51bc:	f9401a61 	ldr	x1, [x19, #48]
    51c0:	b8357854 	str	w20, [x2, x21, lsl #2]
    51c4:	f9401e62 	ldr	x2, [x19, #56]
    51c8:	f10002df 	cmp	x22, #0x0
    51cc:	fc357820 	str	d0, [x1, x21, lsl #3]
    51d0:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    51d4:	b8357816 	str	w22, [x0, x21, lsl #2]
    51d8:	92607e80 	and	x0, x20, #0xffffffff00000000
    51dc:	910006e1 	add	x1, x23, #0x1
    51e0:	aa170000 	orr	x0, x0, x23
    51e4:	fc357848 	str	d8, [x2, x21, lsl #3]
    51e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51ec:	f9401bf7 	ldr	x23, [sp, #48]
    51f0:	fd401fe8 	ldr	d8, [sp, #56]
    51f4:	f9000a61 	str	x1, [x19, #16]
    51f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    51fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5200:	d65f03c0 	ret
    5204:	90000040 	adrp	x0, d000 <atexit+0x10>
    5208:	910c4000 	add	x0, x0, #0x310
    520c:	97fffb21 	bl	3e90 <fwp_trap>
    5210:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5214:	d65f03c0 	ret
    5218:	90000040 	adrp	x0, d000 <atexit+0x10>
    521c:	910cc000 	add	x0, x0, #0x330
    5220:	97fffb1c 	bl	3e90 <fwp_trap>

0000000000005224 <w120>:
    5224:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5228:	910003fd 	mov	x29, sp
    522c:	a90153f3 	stp	x19, x20, [sp, #16]
    5230:	a9025bf5 	stp	x21, x22, [sp, #32]
    5234:	aa0003f5 	mov	x21, x0
    5238:	a90363f7 	stp	x23, x24, [sp, #48]
    523c:	aa0103f7 	mov	x23, x1
    5240:	a9046bf9 	stp	x25, x26, [sp, #64]
    5244:	f9002bfb 	str	x27, [sp, #80]
    5248:	6d0627e8 	stp	d8, d9, [sp, #96]
    524c:	1e604028 	fmov	d8, d1
    5250:	1e600809 	fmul	d9, d0, d0
    5254:	6d072fea 	stp	d10, d11, [sp, #112]
    5258:	1e60400b 	fmov	d11, d0
    525c:	b7f81c80 	tbnz	x0, #63, 55ec <w120+0x3c8>
    5260:	9360fc19 	asr	x25, x0, #32
    5264:	aa1903e0 	mov	x0, x25
    5268:	97fffd0e 	bl	46a0 <fwp_tape_of>
    526c:	f9403001 	ldr	x1, [x0, #96]
    5270:	aa0003f3 	mov	x19, x0
    5274:	b4000081 	cbz	x1, 5284 <w120+0x60>
    5278:	90000040 	adrp	x0, d000 <atexit+0x10>
    527c:	910de000 	add	x0, x0, #0x378
    5280:	97fffb04 	bl	3e90 <fwp_trap>
    5284:	f9400818 	ldr	x24, [x0, #16]
    5288:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    528c:	eb01031f 	cmp	x24, x1
    5290:	54001a8c 	b.gt	55e0 <w120+0x3bc>
    5294:	eb35431f 	cmp	x24, w21, uxtw
    5298:	540019ed 	b.le	55d4 <w120+0x3b0>
    529c:	f9400416 	ldr	x22, [x0, #8]
    52a0:	92607eb4 	and	x20, x21, #0xffffffff00000000
    52a4:	aa180294 	orr	x20, x20, x24
    52a8:	cb160316 	sub	x22, x24, x22
    52ac:	910006c1 	add	x1, x22, #0x1
    52b0:	97fffefd 	bl	4ea4 <fwp_tape_reserve>
    52b4:	a9420a61 	ldp	x1, x2, [x19, #32]
    52b8:	91000700 	add	x0, x24, #0x1
    52bc:	f9401a63 	ldr	x3, [x19, #48]
    52c0:	b8367835 	str	w21, [x1, x22, lsl #2]
    52c4:	f9401e61 	ldr	x1, [x19, #56]
    52c8:	1e693908 	fsub	d8, d8, d9
    52cc:	fc36786b 	str	d11, [x3, x22, lsl #3]
    52d0:	9360fe9a 	asr	x26, x20, #32
    52d4:	b8367855 	str	w21, [x2, x22, lsl #2]
    52d8:	fc36782b 	str	d11, [x1, x22, lsl #3]
    52dc:	f9000a60 	str	x0, [x19, #16]
    52e0:	b7f80077 	tbnz	x23, #63, 52ec <w120+0xc8>
    52e4:	eb97835f 	cmp	x26, x23, asr #32
    52e8:	540019a1 	b.ne	561c <w120+0x3f8>  // b.any
    52ec:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    52f0:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    52f4:	eb19035f 	cmp	x26, x25
    52f8:	540000c0 	b.eq	5310 <w120+0xec>  // b.none
    52fc:	aa1a03e0 	mov	x0, x26
    5300:	97fffce8 	bl	46a0 <fwp_tape_of>
    5304:	aa0003f3 	mov	x19, x0
    5308:	f9403000 	ldr	x0, [x0, #96]
    530c:	b5fffb60 	cbnz	x0, 5278 <w120+0x54>
    5310:	f9400a79 	ldr	x25, [x19, #16]
    5314:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5318:	eb00033f 	cmp	x25, x0
    531c:	5400162c 	b.gt	55e0 <w120+0x3bc>
    5320:	eb34433f 	cmp	x25, w20, uxtw
    5324:	5400158d 	b.le	55d4 <w120+0x3b0>
    5328:	b7f80077 	tbnz	x23, #63, 5334 <w120+0x110>
    532c:	eb37433f 	cmp	x25, w23, uxtw
    5330:	5400152d 	b.le	55d4 <w120+0x3b0>
    5334:	f9400676 	ldr	x22, [x19, #8]
    5338:	aa1303e0 	mov	x0, x19
    533c:	cb160336 	sub	x22, x25, x22
    5340:	910006c1 	add	x1, x22, #0x1
    5344:	97fffed8 	bl	4ea4 <fwp_tape_reserve>
    5348:	a9420e62 	ldp	x2, x3, [x19, #32]
    534c:	f10002ff 	cmp	x23, #0x0
    5350:	f9401a61 	ldr	x1, [x19, #48]
    5354:	b8367854 	str	w20, [x2, x22, lsl #2]
    5358:	f9401e62 	ldr	x2, [x19, #56]
    535c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5360:	fc367829 	str	d9, [x1, x22, lsl #3]
    5364:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    5368:	b8367861 	str	w1, [x3, x22, lsl #2]
    536c:	91000737 	add	x23, x25, #0x1
    5370:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5374:	92607e94 	and	x20, x20, #0xffffffff00000000
    5378:	fc36784a 	str	d10, [x2, x22, lsl #3]
    537c:	aa190294 	orr	x20, x20, x25
    5380:	f9000a77 	str	x23, [x19, #16]
    5384:	1e6b3929 	fsub	d9, d9, d11
    5388:	b7f81675 	tbnz	x21, #63, 5654 <w120+0x430>
    538c:	9360febb 	asr	x27, x21, #32
    5390:	eb1a037f 	cmp	x27, x26
    5394:	540000e0 	b.eq	53b0 <w120+0x18c>  // b.none
    5398:	aa1b03e0 	mov	x0, x27
    539c:	97fffcc1 	bl	46a0 <fwp_tape_of>
    53a0:	aa0003f3 	mov	x19, x0
    53a4:	f9403000 	ldr	x0, [x0, #96]
    53a8:	b5fff680 	cbnz	x0, 5278 <w120+0x54>
    53ac:	f9400a77 	ldr	x23, [x19, #16]
    53b0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    53b4:	eb0002ff 	cmp	x23, x0
    53b8:	5400114c 	b.gt	55e0 <w120+0x3bc>
    53bc:	eb3542ff 	cmp	x23, w21, uxtw
    53c0:	540010ad 	b.le	55d4 <w120+0x3b0>
    53c4:	f9400676 	ldr	x22, [x19, #8]
    53c8:	aa1303e0 	mov	x0, x19
    53cc:	cb1602f6 	sub	x22, x23, x22
    53d0:	910006c1 	add	x1, x22, #0x1
    53d4:	97fffeb4 	bl	4ea4 <fwp_tape_reserve>
    53d8:	a9420261 	ldp	x1, x0, [x19, #32]
    53dc:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    53e0:	f9401a63 	ldr	x3, [x19, #48]
    53e4:	b8367835 	str	w21, [x1, x22, lsl #2]
    53e8:	f9401e61 	ldr	x1, [x19, #56]
    53ec:	12800002 	mov	w2, #0xffffffff            	// #-1
    53f0:	fc367860 	str	d0, [x3, x22, lsl #3]
    53f4:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    53f8:	b8367802 	str	w2, [x0, x22, lsl #2]
    53fc:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5400:	910006e0 	add	x0, x23, #0x1
    5404:	aa1702b7 	orr	x23, x21, x23
    5408:	fc367820 	str	d0, [x1, x22, lsl #3]
    540c:	f9000a60 	str	x0, [x19, #16]
    5410:	9360fe99 	asr	x25, x20, #32
    5414:	1e68090a 	fmul	d10, d8, d8
    5418:	eb1b033f 	cmp	x25, x27
    541c:	540000c0 	b.eq	5434 <w120+0x210>  // b.none
    5420:	aa1903e0 	mov	x0, x25
    5424:	97fffc9f 	bl	46a0 <fwp_tape_of>
    5428:	aa0003f3 	mov	x19, x0
    542c:	f9403000 	ldr	x0, [x0, #96]
    5430:	b5fff240 	cbnz	x0, 5278 <w120+0x54>
    5434:	f9400a75 	ldr	x21, [x19, #16]
    5438:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    543c:	eb0002bf 	cmp	x21, x0
    5440:	54000d0c 	b.gt	55e0 <w120+0x3bc>
    5444:	eb3442bf 	cmp	x21, w20, uxtw
    5448:	54000c6d 	b.le	55d4 <w120+0x3b0>
    544c:	f9400678 	ldr	x24, [x19, #8]
    5450:	aa1303e0 	mov	x0, x19
    5454:	92607e96 	and	x22, x20, #0xffffffff00000000
    5458:	cb1802b8 	sub	x24, x21, x24
    545c:	aa1502d6 	orr	x22, x22, x21
    5460:	91000701 	add	x1, x24, #0x1
    5464:	97fffe90 	bl	4ea4 <fwp_tape_reserve>
    5468:	a9420261 	ldp	x1, x0, [x19, #32]
    546c:	f9401a62 	ldr	x2, [x19, #48]
    5470:	b8387834 	str	w20, [x1, x24, lsl #2]
    5474:	f9401e61 	ldr	x1, [x19, #56]
    5478:	fc387848 	str	d8, [x2, x24, lsl #3]
    547c:	b8387814 	str	w20, [x0, x24, lsl #2]
    5480:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5484:	9e670000 	fmov	d0, x0
    5488:	910006b4 	add	x20, x21, #0x1
    548c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5490:	9360fed8 	asr	x24, x22, #32
    5494:	f9000a74 	str	x20, [x19, #16]
    5498:	1e60094a 	fmul	d10, d10, d0
    549c:	eb19031f 	cmp	x24, x25
    54a0:	540000e0 	b.eq	54bc <w120+0x298>  // b.none
    54a4:	aa1803e0 	mov	x0, x24
    54a8:	97fffc7e 	bl	46a0 <fwp_tape_of>
    54ac:	aa0003f3 	mov	x19, x0
    54b0:	f9403000 	ldr	x0, [x0, #96]
    54b4:	b5ffee20 	cbnz	x0, 5278 <w120+0x54>
    54b8:	f9400a74 	ldr	x20, [x19, #16]
    54bc:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54c0:	eb00029f 	cmp	x20, x0
    54c4:	540008ec 	b.gt	55e0 <w120+0x3bc>
    54c8:	eb36429f 	cmp	x20, w22, uxtw
    54cc:	5400084d 	b.le	55d4 <w120+0x3b0>
    54d0:	f9400675 	ldr	x21, [x19, #8]
    54d4:	aa1303e0 	mov	x0, x19
    54d8:	cb150295 	sub	x21, x20, x21
    54dc:	910006a1 	add	x1, x21, #0x1
    54e0:	97fffe71 	bl	4ea4 <fwp_tape_reserve>
    54e4:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    54e8:	9e670000 	fmov	d0, x0
    54ec:	a9420261 	ldp	x1, x0, [x19, #32]
    54f0:	1e690928 	fmul	d8, d9, d9
    54f4:	f9401a62 	ldr	x2, [x19, #48]
    54f8:	b8357836 	str	w22, [x1, x21, lsl #2]
    54fc:	f9401e61 	ldr	x1, [x19, #56]
    5500:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5504:	fc357840 	str	d0, [x2, x21, lsl #3]
    5508:	12800002 	mov	w2, #0xffffffff            	// #-1
    550c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5510:	91000680 	add	x0, x20, #0x1
    5514:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5518:	aa1402d6 	orr	x22, x22, x20
    551c:	f9000a60 	str	x0, [x19, #16]
    5520:	b10006ff 	cmn	x23, #0x1
    5524:	540009e0 	b.eq	5660 <w120+0x43c>  // b.none
    5528:	9360fee0 	asr	x0, x23, #32
    552c:	eb18001f 	cmp	x0, x24
    5530:	540000a0 	b.eq	5544 <w120+0x320>  // b.none
    5534:	97fffc5b 	bl	46a0 <fwp_tape_of>
    5538:	aa0003f3 	mov	x19, x0
    553c:	f9403000 	ldr	x0, [x0, #96]
    5540:	b5ffe9c0 	cbnz	x0, 5278 <w120+0x54>
    5544:	f9400a74 	ldr	x20, [x19, #16]
    5548:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    554c:	eb00029f 	cmp	x20, x0
    5550:	5400048c 	b.gt	55e0 <w120+0x3bc>
    5554:	eb37429f 	cmp	x20, w23, uxtw
    5558:	540003ed 	b.le	55d4 <w120+0x3b0>
    555c:	f9400675 	ldr	x21, [x19, #8]
    5560:	aa1303e0 	mov	x0, x19
    5564:	cb150295 	sub	x21, x20, x21
    5568:	910006a1 	add	x1, x21, #0x1
    556c:	97fffe4e 	bl	4ea4 <fwp_tape_reserve>
    5570:	a9420a61 	ldp	x1, x2, [x19, #32]
    5574:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5578:	f9401a63 	ldr	x3, [x19, #48]
    557c:	b8357837 	str	w23, [x1, x21, lsl #2]
    5580:	f9401e61 	ldr	x1, [x19, #56]
    5584:	aa140000 	orr	x0, x0, x20
    5588:	fc357869 	str	d9, [x3, x21, lsl #3]
    558c:	91000694 	add	x20, x20, #0x1
    5590:	b8357857 	str	w23, [x2, x21, lsl #2]
    5594:	fc357829 	str	d9, [x1, x21, lsl #3]
    5598:	f9000a74 	str	x20, [x19, #16]
    559c:	1e6a2908 	fadd	d8, d8, d10
    55a0:	aa1603e1 	mov	x1, x22
    55a4:	97fffecf 	bl	50e0 <f141.constprop.0>
    55a8:	aa0003e1 	mov	x1, x0
    55ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    55b0:	9e660100 	fmov	x0, d8
    55b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    55bc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    55c0:	f9402bfb 	ldr	x27, [sp, #80]
    55c4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55c8:	6d472fea 	ldp	d10, d11, [sp, #112]
    55cc:	a8c87bfd 	ldp	x29, x30, [sp], #128
    55d0:	d65f03c0 	ret
    55d4:	90000040 	adrp	x0, d000 <atexit+0x10>
    55d8:	910ea000 	add	x0, x0, #0x3a8
    55dc:	97fffa2d 	bl	3e90 <fwp_trap>
    55e0:	90000040 	adrp	x0, d000 <atexit+0x10>
    55e4:	910c4000 	add	x0, x0, #0x310
    55e8:	97fffa2a 	bl	3e90 <fwp_trap>
    55ec:	1e693828 	fsub	d8, d1, d9
    55f0:	b6f801c1 	tbz	x1, #63, 5628 <w120+0x404>
    55f4:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    55f8:	1e68090a 	fmul	d10, d8, d8
    55fc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5600:	9e670000 	fmov	d0, x0
    5604:	1e6b3828 	fsub	d8, d1, d11
    5608:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    560c:	aa1603e0 	mov	x0, x22
    5610:	1e60094a 	fmul	d10, d10, d0
    5614:	1e680908 	fmul	d8, d8, d8
    5618:	17ffffe1 	b	559c <w120+0x378>
    561c:	90000040 	adrp	x0, d000 <atexit+0x10>
    5620:	910cc000 	add	x0, x0, #0x330
    5624:	97fffa1b 	bl	3e90 <fwp_trap>
    5628:	2f00e40a 	movi	d10, #0x0
    562c:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5630:	9360fc3a 	asr	x26, x1, #32
    5634:	aa0103f4 	mov	x20, x1
    5638:	aa1a03e0 	mov	x0, x26
    563c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5640:	97fffc18 	bl	46a0 <fwp_tape_of>
    5644:	aa0003f3 	mov	x19, x0
    5648:	f9403000 	ldr	x0, [x0, #96]
    564c:	b5ffe160 	cbnz	x0, 5278 <w120+0x54>
    5650:	17ffff30 	b	5310 <w120+0xec>
    5654:	aa1a03fb 	mov	x27, x26
    5658:	aa0003f7 	mov	x23, x0
    565c:	17ffff6d 	b	5410 <w120+0x1ec>
    5660:	aa1703e0 	mov	x0, x23
    5664:	17ffffce 	b	559c <w120+0x378>
    5668:	d503201f 	nop
    566c:	d503201f 	nop

0000000000005670 <fwp_rc_share>:
    5670:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5674:	91150042 	add	x2, x2, #0x540
    5678:	f949d843 	ldr	x3, [x2, #5040]
    567c:	f949ec41 	ldr	x1, [x2, #5080]
    5680:	cb030000 	sub	x0, x0, x3
    5684:	eb01401f 	cmp	x0, x1, lsl #16
    5688:	540003a2 	b.cs	56fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    568c:	d350fc01 	lsr	x1, x0, #16
    5690:	f949fc44 	ldr	x4, [x2, #5112]
    5694:	8b010821 	add	x1, x1, x1, lsl #2
    5698:	d37df021 	lsl	x1, x1, #3
    569c:	8b010083 	add	x3, x4, x1
    56a0:	f9401062 	ldr	x2, [x3, #32]
    56a4:	b40002c2 	cbz	x2, 56fc <fwp_rc_share+0x8c>
    56a8:	38616881 	ldrb	w1, [x4, x1]
    56ac:	7100083f 	cmp	w1, #0x2
    56b0:	54000220 	b.eq	56f4 <fwp_rc_share+0x84>  // b.none
    56b4:	7100043f 	cmp	w1, #0x1
    56b8:	54000221 	b.ne	56fc <fwp_rc_share+0x8c>  // b.any
    56bc:	29430464 	ldp	w4, w1, [x3, #24]
    56c0:	92403c00 	and	x0, x0, #0xffff
    56c4:	9b047c00 	mul	x0, x0, x4
    56c8:	d360fc00 	lsr	x0, x0, #32
    56cc:	eb01001f 	cmp	x0, x1
    56d0:	54000162 	b.cs	56fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    56d4:	8b000042 	add	x2, x2, x0
    56d8:	39400040 	ldrb	w0, [x2]
    56dc:	34000100 	cbz	w0, 56fc <fwp_rc_share+0x8c>
    56e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    56e4:	90000040 	adrp	x0, d000 <atexit+0x10>
    56e8:	910f2000 	add	x0, x0, #0x3c8
    56ec:	910003fd 	mov	x29, sp
    56f0:	97fff9e8 	bl	3e90 <fwp_trap>
    56f4:	72003c1f 	tst	w0, #0xffff
    56f8:	54ffff00 	b.eq	56d8 <fwp_rc_share+0x68>  // b.none
    56fc:	d65f03c0 	ret

0000000000005700 <fwp_rc_fresh>:
    5700:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5704:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5708:	91150063 	add	x3, x3, #0x540
    570c:	910003fd 	mov	x29, sp
    5710:	a90153f3 	stp	x19, x20, [sp, #16]
    5714:	aa0003f3 	mov	x19, x0
    5718:	f949d861 	ldr	x1, [x3, #5040]
    571c:	f949ec60 	ldr	x0, [x3, #5080]
    5720:	cb010261 	sub	x1, x19, x1
    5724:	eb00403f 	cmp	x1, x0, lsl #16
    5728:	54000322 	b.cs	578c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    572c:	d350fc22 	lsr	x2, x1, #16
    5730:	f949fc63 	ldr	x3, [x3, #5112]
    5734:	8b020842 	add	x2, x2, x2, lsl #2
    5738:	d37df042 	lsl	x2, x2, #3
    573c:	8b020060 	add	x0, x3, x2
    5740:	f9401014 	ldr	x20, [x0, #32]
    5744:	b4000254 	cbz	x20, 578c <fwp_rc_fresh+0x8c>
    5748:	38626862 	ldrb	w2, [x3, x2]
    574c:	7100085f 	cmp	w2, #0x2
    5750:	54000260 	b.eq	579c <fwp_rc_fresh+0x9c>  // b.none
    5754:	7100045f 	cmp	w2, #0x1
    5758:	540001a1 	b.ne	578c <fwp_rc_fresh+0x8c>  // b.any
    575c:	29430002 	ldp	w2, w0, [x0, #24]
    5760:	92403c21 	and	x1, x1, #0xffff
    5764:	9b027c21 	mul	x1, x1, x2
    5768:	d360fc21 	lsr	x1, x1, #32
    576c:	eb00003f 	cmp	x1, x0
    5770:	540000e2 	b.cs	578c <fwp_rc_fresh+0x8c>  // b.hs, b.nlast
    5774:	8b010294 	add	x20, x20, x1
    5778:	39400280 	ldrb	w0, [x20]
    577c:	7103fc1f 	cmp	w0, #0xff
    5780:	540001a0 	b.eq	57b4 <fwp_rc_fresh+0xb4>  // b.none
    5784:	52800020 	mov	w0, #0x1                   	// #1
    5788:	39000280 	strb	w0, [x20]
    578c:	aa1303e0 	mov	x0, x19
    5790:	a94153f3 	ldp	x19, x20, [sp, #16]
    5794:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5798:	d65f03c0 	ret
    579c:	72003c3f 	tst	w1, #0xffff
    57a0:	54fffec0 	b.eq	5778 <fwp_rc_fresh+0x78>  // b.none
    57a4:	aa1303e0 	mov	x0, x19
    57a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    57ac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    57b0:	d65f03c0 	ret
    57b4:	aa1403e0 	mov	x0, x20
    57b8:	97fff9d6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    57bc:	17fffff2 	b	5784 <fwp_rc_fresh+0x84>

00000000000057c0 <fwp_rc_free_arr>:
    57c0:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    57c4:	91150063 	add	x3, x3, #0x540
    57c8:	f949d861 	ldr	x1, [x3, #5040]
    57cc:	f949ec62 	ldr	x2, [x3, #5080]
    57d0:	cb010001 	sub	x1, x0, x1
    57d4:	eb02403f 	cmp	x1, x2, lsl #16
    57d8:	54000342 	b.cs	5840 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    57dc:	d350fc22 	lsr	x2, x1, #16
    57e0:	f949fc65 	ldr	x5, [x3, #5112]
    57e4:	8b020842 	add	x2, x2, x2, lsl #2
    57e8:	d37df042 	lsl	x2, x2, #3
    57ec:	8b0200a4 	add	x4, x5, x2
    57f0:	f9401083 	ldr	x3, [x4, #32]
    57f4:	b4000263 	cbz	x3, 5840 <fwp_rc_free_arr+0x80>
    57f8:	386268a2 	ldrb	w2, [x5, x2]
    57fc:	7100085f 	cmp	w2, #0x2
    5800:	540001c0 	b.eq	5838 <fwp_rc_free_arr+0x78>  // b.none
    5804:	7100045f 	cmp	w2, #0x1
    5808:	540001c1 	b.ne	5840 <fwp_rc_free_arr+0x80>  // b.any
    580c:	29430885 	ldp	w5, w2, [x4, #24]
    5810:	92403c21 	and	x1, x1, #0xffff
    5814:	9b057c21 	mul	x1, x1, x5
    5818:	d360fc21 	lsr	x1, x1, #32
    581c:	eb02003f 	cmp	x1, x2
    5820:	54000102 	b.cs	5840 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5824:	8b010063 	add	x3, x3, x1
    5828:	39400061 	ldrb	w1, [x3]
    582c:	7100043f 	cmp	w1, #0x1
    5830:	54000081 	b.ne	5840 <fwp_rc_free_arr+0x80>  // b.any
    5834:	17fffa53 	b	4180 <fwp_mem_free>
    5838:	72003c3f 	tst	w1, #0xffff
    583c:	54ffff60 	b.eq	5828 <fwp_rc_free_arr+0x68>  // b.none
    5840:	d65f03c0 	ret

0000000000005844 <fwp_rc_dup>:
    5844:	90000162 	adrp	x2, 31000 <fwp_root_context+0xca0>
    5848:	91150042 	add	x2, x2, #0x540
    584c:	f949d841 	ldr	x1, [x2, #5040]
    5850:	f949ec43 	ldr	x3, [x2, #5080]
    5854:	cb010001 	sub	x1, x0, x1
    5858:	eb03403f 	cmp	x1, x3, lsl #16
    585c:	54000342 	b.cs	58c4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    5860:	d350fc20 	lsr	x0, x1, #16
    5864:	f949fc44 	ldr	x4, [x2, #5112]
    5868:	8b000800 	add	x0, x0, x0, lsl #2
    586c:	d37df002 	lsl	x2, x0, #3
    5870:	8b020083 	add	x3, x4, x2
    5874:	f9401060 	ldr	x0, [x3, #32]
    5878:	b4000260 	cbz	x0, 58c4 <fwp_rc_dup+0x80>
    587c:	38626882 	ldrb	w2, [x4, x2]
    5880:	7100085f 	cmp	w2, #0x2
    5884:	54000220 	b.eq	58c8 <fwp_rc_dup+0x84>  // b.none
    5888:	7100045f 	cmp	w2, #0x1
    588c:	540001c1 	b.ne	58c4 <fwp_rc_dup+0x80>  // b.any
    5890:	29430864 	ldp	w4, w2, [x3, #24]
    5894:	92403c21 	and	x1, x1, #0xffff
    5898:	9b047c21 	mul	x1, x1, x4
    589c:	d360fc21 	lsr	x1, x1, #32
    58a0:	eb02003f 	cmp	x1, x2
    58a4:	54000102 	b.cs	58c4 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    58a8:	8b010000 	add	x0, x0, x1
    58ac:	39400001 	ldrb	w1, [x0]
    58b0:	340000a1 	cbz	w1, 58c4 <fwp_rc_dup+0x80>
    58b4:	7103f43f 	cmp	w1, #0xfd
    58b8:	540000e8 	b.hi	58d4 <fwp_rc_dup+0x90>  // b.pmore
    58bc:	11000421 	add	w1, w1, #0x1
    58c0:	39000001 	strb	w1, [x0]
    58c4:	d65f03c0 	ret
    58c8:	72003c3f 	tst	w1, #0xffff
    58cc:	54ffff00 	b.eq	58ac <fwp_rc_dup+0x68>  // b.none
    58d0:	d65f03c0 	ret
    58d4:	17fffaa4 	b	4364 <fwp_rc_wide_dup>
    58d8:	d503201f 	nop
    58dc:	d503201f 	nop

00000000000058e0 <fwp_owned_entry173>:
    58e0:	d10103ff 	sub	sp, sp, #0x40
    58e4:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    58e8:	f947f442 	ldr	x2, [x2, #4072]
    58ec:	a9027bfd 	stp	x29, x30, [sp, #32]
    58f0:	910083fd 	add	x29, sp, #0x20
    58f4:	a90353f3 	stp	x19, x20, [sp, #48]
    58f8:	f9400043 	ldr	x3, [x2]
    58fc:	f9000fe3 	str	x3, [sp, #24]
    5900:	d2800003 	mov	x3, #0x0                   	// #0
    5904:	a9400c01 	ldp	x1, x3, [x0]
    5908:	f9400802 	ldr	x2, [x0, #16]
    590c:	ab020022 	adds	x2, x1, x2
    5910:	540006e6 	b.vs	59ec <fwp_owned_entry173+0x10c>
    5914:	910023e1 	add	x1, sp, #0x8
    5918:	52800000 	mov	w0, #0x0                   	// #0
    591c:	a9008be3 	stp	x3, x2, [sp, #8]
    5920:	97fffd19 	bl	4d84 <fwp_data.part.0.constprop.0>
    5924:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5928:	91150063 	add	x3, x3, #0x540
    592c:	aa0003f3 	mov	x19, x0
    5930:	f949d861 	ldr	x1, [x3, #5040]
    5934:	f949ec60 	ldr	x0, [x3, #5080]
    5938:	cb010261 	sub	x1, x19, x1
    593c:	eb00403f 	cmp	x1, x0, lsl #16
    5940:	54000322 	b.cs	59a4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5944:	d350fc22 	lsr	x2, x1, #16
    5948:	f949fc63 	ldr	x3, [x3, #5112]
    594c:	8b020842 	add	x2, x2, x2, lsl #2
    5950:	d37df042 	lsl	x2, x2, #3
    5954:	8b020060 	add	x0, x3, x2
    5958:	f9401014 	ldr	x20, [x0, #32]
    595c:	b4000254 	cbz	x20, 59a4 <fwp_owned_entry173+0xc4>
    5960:	38626862 	ldrb	w2, [x3, x2]
    5964:	7100085f 	cmp	w2, #0x2
    5968:	54000360 	b.eq	59d4 <fwp_owned_entry173+0xf4>  // b.none
    596c:	7100045f 	cmp	w2, #0x1
    5970:	540001a1 	b.ne	59a4 <fwp_owned_entry173+0xc4>  // b.any
    5974:	29430002 	ldp	w2, w0, [x0, #24]
    5978:	92403c21 	and	x1, x1, #0xffff
    597c:	9b027c21 	mul	x1, x1, x2
    5980:	d360fc21 	lsr	x1, x1, #32
    5984:	eb00003f 	cmp	x1, x0
    5988:	540000e2 	b.cs	59a4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    598c:	8b010294 	add	x20, x20, x1
    5990:	39400280 	ldrb	w0, [x20]
    5994:	7103fc1f 	cmp	w0, #0xff
    5998:	54000240 	b.eq	59e0 <fwp_owned_entry173+0x100>  // b.none
    599c:	52800020 	mov	w0, #0x1                   	// #1
    59a0:	39000280 	strb	w0, [x20]
    59a4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    59a8:	f947f400 	ldr	x0, [x0, #4072]
    59ac:	f9400fe2 	ldr	x2, [sp, #24]
    59b0:	f9400001 	ldr	x1, [x0]
    59b4:	eb010042 	subs	x2, x2, x1
    59b8:	d2800001 	mov	x1, #0x0                   	// #0
    59bc:	540001a1 	b.ne	59f0 <fwp_owned_entry173+0x110>  // b.any
    59c0:	a9427bfd 	ldp	x29, x30, [sp, #32]
    59c4:	aa1303e0 	mov	x0, x19
    59c8:	a94353f3 	ldp	x19, x20, [sp, #48]
    59cc:	910103ff 	add	sp, sp, #0x40
    59d0:	d65f03c0 	ret
    59d4:	72003c3f 	tst	w1, #0xffff
    59d8:	54fffe61 	b.ne	59a4 <fwp_owned_entry173+0xc4>  // b.any
    59dc:	17ffffed 	b	5990 <fwp_owned_entry173+0xb0>
    59e0:	aa1403e0 	mov	x0, x20
    59e4:	97fff94b 	bl	3f10 <fwp_rc_forget_slot.part.0>
    59e8:	17ffffed 	b	599c <fwp_owned_entry173+0xbc>
    59ec:	97fff425 	bl	2a80 <fwp_trap_overflow.constprop.0>
    59f0:	97fff3a4 	bl	2880 <__stack_chk_fail@plt>

00000000000059f4 <e173>:
    59f4:	d10103ff 	sub	sp, sp, #0x40
    59f8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    59fc:	f947f442 	ldr	x2, [x2, #4072]
    5a00:	a9027bfd 	stp	x29, x30, [sp, #32]
    5a04:	910083fd 	add	x29, sp, #0x20
    5a08:	a90353f3 	stp	x19, x20, [sp, #48]
    5a0c:	f9400043 	ldr	x3, [x2]
    5a10:	f9000fe3 	str	x3, [sp, #24]
    5a14:	d2800003 	mov	x3, #0x0                   	// #0
    5a18:	a9400c01 	ldp	x1, x3, [x0]
    5a1c:	f9400802 	ldr	x2, [x0, #16]
    5a20:	ab020022 	adds	x2, x1, x2
    5a24:	54000726 	b.vs	5b08 <e173+0x114>
    5a28:	910023e1 	add	x1, sp, #0x8
    5a2c:	52800000 	mov	w0, #0x0                   	// #0
    5a30:	a9008be3 	stp	x3, x2, [sp, #8]
    5a34:	97fffcd4 	bl	4d84 <fwp_data.part.0.constprop.0>
    5a38:	90000163 	adrp	x3, 31000 <fwp_root_context+0xca0>
    5a3c:	91150063 	add	x3, x3, #0x540
    5a40:	aa0003f3 	mov	x19, x0
    5a44:	f949d861 	ldr	x1, [x3, #5040]
    5a48:	f949ec60 	ldr	x0, [x3, #5080]
    5a4c:	cb010261 	sub	x1, x19, x1
    5a50:	eb00403f 	cmp	x1, x0, lsl #16
    5a54:	54000322 	b.cs	5ab8 <e173+0xc4>  // b.hs, b.nlast
    5a58:	d350fc22 	lsr	x2, x1, #16
    5a5c:	f949fc63 	ldr	x3, [x3, #5112]
    5a60:	8b020842 	add	x2, x2, x2, lsl #2
    5a64:	d37df042 	lsl	x2, x2, #3
    5a68:	8b020060 	add	x0, x3, x2
    5a6c:	f9401014 	ldr	x20, [x0, #32]
    5a70:	b4000254 	cbz	x20, 5ab8 <e173+0xc4>
    5a74:	38626862 	ldrb	w2, [x3, x2]
    5a78:	7100085f 	cmp	w2, #0x2
    5a7c:	540003a0 	b.eq	5af0 <e173+0xfc>  // b.none
    5a80:	7100045f 	cmp	w2, #0x1
    5a84:	540001a1 	b.ne	5ab8 <e173+0xc4>  // b.any
    5a88:	29430002 	ldp	w2, w0, [x0, #24]
    5a8c:	92403c21 	and	x1, x1, #0xffff
    5a90:	9b027c21 	mul	x1, x1, x2
    5a94:	d360fc21 	lsr	x1, x1, #32
    5a98:	eb00003f 	cmp	x1, x0
    5a9c:	540000e2 	b.cs	5ab8 <e173+0xc4>  // b.hs, b.nlast
    5aa0:	8b010294 	add	x20, x20, x1
    5aa4:	39400280 	ldrb	w0, [x20]
    5aa8:	7103fc1f 	cmp	w0, #0xff
    5aac:	54000280 	b.eq	5afc <e173+0x108>  // b.none
    5ab0:	52800020 	mov	w0, #0x1                   	// #1
    5ab4:	39000280 	strb	w0, [x20]
    5ab8:	aa1303e0 	mov	x0, x19
    5abc:	97fffeed 	bl	5670 <fwp_rc_share>
    5ac0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5ac4:	f947f400 	ldr	x0, [x0, #4072]
    5ac8:	f9400fe2 	ldr	x2, [sp, #24]
    5acc:	f9400001 	ldr	x1, [x0]
    5ad0:	eb010042 	subs	x2, x2, x1
    5ad4:	d2800001 	mov	x1, #0x0                   	// #0
    5ad8:	540001a1 	b.ne	5b0c <e173+0x118>  // b.any
    5adc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5ae0:	aa1303e0 	mov	x0, x19
    5ae4:	a94353f3 	ldp	x19, x20, [sp, #48]
    5ae8:	910103ff 	add	sp, sp, #0x40
    5aec:	d65f03c0 	ret
    5af0:	72003c3f 	tst	w1, #0xffff
    5af4:	54fffe21 	b.ne	5ab8 <e173+0xc4>  // b.any
    5af8:	17ffffeb 	b	5aa4 <e173+0xb0>
    5afc:	aa1403e0 	mov	x0, x20
    5b00:	97fff904 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5b04:	17ffffeb 	b	5ab0 <e173+0xbc>
    5b08:	97fff3de 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5b0c:	97fff35d 	bl	2880 <__stack_chk_fail@plt>

0000000000005b10 <fwp_drop0>:
    5b10:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5b14:	910003fd 	mov	x29, sp
    5b18:	a90153f3 	stp	x19, x20, [sp, #16]
    5b1c:	f90013f5 	str	x21, [sp, #32]
    5b20:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5b24:	911502b4 	add	x20, x21, #0x540
    5b28:	f949da81 	ldr	x1, [x20, #5040]
    5b2c:	f949ee82 	ldr	x2, [x20, #5080]
    5b30:	cb010001 	sub	x1, x0, x1
    5b34:	eb02403f 	cmp	x1, x2, lsl #16
    5b38:	54000382 	b.cs	5ba8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b3c:	d350fc22 	lsr	x2, x1, #16
    5b40:	f949fe84 	ldr	x4, [x20, #5112]
    5b44:	8b020842 	add	x2, x2, x2, lsl #2
    5b48:	d37df042 	lsl	x2, x2, #3
    5b4c:	8b020083 	add	x3, x4, x2
    5b50:	f9401073 	ldr	x19, [x3, #32]
    5b54:	b40002b3 	cbz	x19, 5ba8 <fwp_drop0+0x98>
    5b58:	38626882 	ldrb	w2, [x4, x2]
    5b5c:	7100085f 	cmp	w2, #0x2
    5b60:	540002c0 	b.eq	5bb8 <fwp_drop0+0xa8>  // b.none
    5b64:	7100045f 	cmp	w2, #0x1
    5b68:	54000201 	b.ne	5ba8 <fwp_drop0+0x98>  // b.any
    5b6c:	29430864 	ldp	w4, w2, [x3, #24]
    5b70:	92403c21 	and	x1, x1, #0xffff
    5b74:	9b047c21 	mul	x1, x1, x4
    5b78:	d360fc21 	lsr	x1, x1, #32
    5b7c:	eb02003f 	cmp	x1, x2
    5b80:	54000142 	b.cs	5ba8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b84:	8b010273 	add	x19, x19, x1
    5b88:	39400261 	ldrb	w1, [x19]
    5b8c:	340000e1 	cbz	w1, 5ba8 <fwp_drop0+0x98>
    5b90:	7100043f 	cmp	w1, #0x1
    5b94:	540001e0 	b.eq	5bd0 <fwp_drop0+0xc0>  // b.none
    5b98:	7103fc3f 	cmp	w1, #0xff
    5b9c:	540002e0 	b.eq	5bf8 <fwp_drop0+0xe8>  // b.none
    5ba0:	51000421 	sub	w1, w1, #0x1
    5ba4:	39000261 	strb	w1, [x19]
    5ba8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bac:	f94013f5 	ldr	x21, [sp, #32]
    5bb0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5bb4:	d65f03c0 	ret
    5bb8:	72003c3f 	tst	w1, #0xffff
    5bbc:	54fffe60 	b.eq	5b88 <fwp_drop0+0x78>  // b.none
    5bc0:	a94153f3 	ldp	x19, x20, [sp, #16]
    5bc4:	f94013f5 	ldr	x21, [sp, #32]
    5bc8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5bcc:	d65f03c0 	ret
    5bd0:	f9400813 	ldr	x19, [x0, #16]
    5bd4:	97fffefb 	bl	57c0 <fwp_rc_free_arr>
    5bd8:	911502a0 	add	x0, x21, #0x540
    5bdc:	f949d801 	ldr	x1, [x0, #5040]
    5be0:	f949ec00 	ldr	x0, [x0, #5080]
    5be4:	cb010261 	sub	x1, x19, x1
    5be8:	eb00403f 	cmp	x1, x0, lsl #16
    5bec:	54fffde2 	b.cs	5ba8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5bf0:	aa1303e0 	mov	x0, x19
    5bf4:	17ffffd2 	b	5b3c <fwp_drop0+0x2c>
    5bf8:	ca534660 	eor	x0, x19, x19, lsr #17
    5bfc:	911502b5 	add	x21, x21, #0x540
    5c00:	ca402400 	eor	x0, x0, x0, lsr #9
    5c04:	92401c00 	and	x0, x0, #0xff
    5c08:	910a2402 	add	x2, x0, #0x289
    5c0c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5c10:	8b020ea2 	add	x2, x21, x2, lsl #3
    5c14:	f94a2400 	ldr	x0, [x0, #5192]
    5c18:	b50000a0 	cbnz	x0, 5c2c <fwp_drop0+0x11c>
    5c1c:	14000013 	b	5c68 <fwp_drop0+0x158>
    5c20:	91004002 	add	x2, x0, #0x10
    5c24:	f9400800 	ldr	x0, [x0, #16]
    5c28:	b4000200 	cbz	x0, 5c68 <fwp_drop0+0x158>
    5c2c:	f9400001 	ldr	x1, [x0]
    5c30:	eb13003f 	cmp	x1, x19
    5c34:	54ffff61 	b.ne	5c20 <fwp_drop0+0x110>  // b.any
    5c38:	f9400041 	ldr	x1, [x2]
    5c3c:	f9400420 	ldr	x0, [x1, #8]
    5c40:	d1000400 	sub	x0, x0, #0x1
    5c44:	f9000420 	str	x0, [x1, #8]
    5c48:	f103f81f 	cmp	x0, #0xfe
    5c4c:	54fffae1 	b.ne	5ba8 <fwp_drop0+0x98>  // b.any
    5c50:	39400260 	ldrb	w0, [x19]
    5c54:	7103fc1f 	cmp	w0, #0xff
    5c58:	540000e0 	b.eq	5c74 <fwp_drop0+0x164>  // b.none
    5c5c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5c60:	39000260 	strb	w0, [x19]
    5c64:	17ffffd1 	b	5ba8 <fwp_drop0+0x98>
    5c68:	90000040 	adrp	x0, d000 <atexit+0x10>
    5c6c:	91058000 	add	x0, x0, #0x160
    5c70:	97fff888 	bl	3e90 <fwp_trap>
    5c74:	aa1303e0 	mov	x0, x19
    5c78:	97fff8a6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5c7c:	17fffff8 	b	5c5c <fwp_drop0+0x14c>

0000000000005c80 <fwp_drop1>:
    5c80:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5c84:	910003fd 	mov	x29, sp
    5c88:	a90153f3 	stp	x19, x20, [sp, #16]
    5c8c:	f90013f5 	str	x21, [sp, #32]
    5c90:	90000175 	adrp	x21, 31000 <fwp_root_context+0xca0>
    5c94:	911502b4 	add	x20, x21, #0x540
    5c98:	f949da81 	ldr	x1, [x20, #5040]
    5c9c:	f949ee82 	ldr	x2, [x20, #5080]
    5ca0:	cb010001 	sub	x1, x0, x1
    5ca4:	eb02403f 	cmp	x1, x2, lsl #16
    5ca8:	54000382 	b.cs	5d18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5cac:	d350fc22 	lsr	x2, x1, #16
    5cb0:	f949fe84 	ldr	x4, [x20, #5112]
    5cb4:	8b020842 	add	x2, x2, x2, lsl #2
    5cb8:	d37df042 	lsl	x2, x2, #3
    5cbc:	8b020083 	add	x3, x4, x2
    5cc0:	f9401073 	ldr	x19, [x3, #32]
    5cc4:	b40002b3 	cbz	x19, 5d18 <fwp_drop1+0x98>
    5cc8:	38626882 	ldrb	w2, [x4, x2]
    5ccc:	7100085f 	cmp	w2, #0x2
    5cd0:	540002c0 	b.eq	5d28 <fwp_drop1+0xa8>  // b.none
    5cd4:	7100045f 	cmp	w2, #0x1
    5cd8:	54000201 	b.ne	5d18 <fwp_drop1+0x98>  // b.any
    5cdc:	29430864 	ldp	w4, w2, [x3, #24]
    5ce0:	92403c21 	and	x1, x1, #0xffff
    5ce4:	9b047c21 	mul	x1, x1, x4
    5ce8:	d360fc21 	lsr	x1, x1, #32
    5cec:	eb02003f 	cmp	x1, x2
    5cf0:	54000142 	b.cs	5d18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5cf4:	8b010273 	add	x19, x19, x1
    5cf8:	39400261 	ldrb	w1, [x19]
    5cfc:	340000e1 	cbz	w1, 5d18 <fwp_drop1+0x98>
    5d00:	7100043f 	cmp	w1, #0x1
    5d04:	540001e0 	b.eq	5d40 <fwp_drop1+0xc0>  // b.none
    5d08:	7103fc3f 	cmp	w1, #0xff
    5d0c:	540002e0 	b.eq	5d68 <fwp_drop1+0xe8>  // b.none
    5d10:	51000421 	sub	w1, w1, #0x1
    5d14:	39000261 	strb	w1, [x19]
    5d18:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d1c:	f94013f5 	ldr	x21, [sp, #32]
    5d20:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d24:	d65f03c0 	ret
    5d28:	72003c3f 	tst	w1, #0xffff
    5d2c:	54fffe60 	b.eq	5cf8 <fwp_drop1+0x78>  // b.none
    5d30:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d34:	f94013f5 	ldr	x21, [sp, #32]
    5d38:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5d3c:	d65f03c0 	ret
    5d40:	f9400813 	ldr	x19, [x0, #16]
    5d44:	97fffe9f 	bl	57c0 <fwp_rc_free_arr>
    5d48:	911502a0 	add	x0, x21, #0x540
    5d4c:	f949d801 	ldr	x1, [x0, #5040]
    5d50:	f949ec00 	ldr	x0, [x0, #5080]
    5d54:	cb010261 	sub	x1, x19, x1
    5d58:	eb00403f 	cmp	x1, x0, lsl #16
    5d5c:	54fffde2 	b.cs	5d18 <fwp_drop1+0x98>  // b.hs, b.nlast
    5d60:	aa1303e0 	mov	x0, x19
    5d64:	17ffffd2 	b	5cac <fwp_drop1+0x2c>
    5d68:	ca534660 	eor	x0, x19, x19, lsr #17
    5d6c:	911502b5 	add	x21, x21, #0x540
    5d70:	ca402400 	eor	x0, x0, x0, lsr #9
    5d74:	92401c00 	and	x0, x0, #0xff
    5d78:	910a2402 	add	x2, x0, #0x289
    5d7c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5d80:	8b020ea2 	add	x2, x21, x2, lsl #3
    5d84:	f94a2400 	ldr	x0, [x0, #5192]
    5d88:	b50000a0 	cbnz	x0, 5d9c <fwp_drop1+0x11c>
    5d8c:	14000013 	b	5dd8 <fwp_drop1+0x158>
    5d90:	91004002 	add	x2, x0, #0x10
    5d94:	f9400800 	ldr	x0, [x0, #16]
    5d98:	b4000200 	cbz	x0, 5dd8 <fwp_drop1+0x158>
    5d9c:	f9400001 	ldr	x1, [x0]
    5da0:	eb13003f 	cmp	x1, x19
    5da4:	54ffff61 	b.ne	5d90 <fwp_drop1+0x110>  // b.any
    5da8:	f9400041 	ldr	x1, [x2]
    5dac:	f9400420 	ldr	x0, [x1, #8]
    5db0:	d1000400 	sub	x0, x0, #0x1
    5db4:	f9000420 	str	x0, [x1, #8]
    5db8:	f103f81f 	cmp	x0, #0xfe
    5dbc:	54fffae1 	b.ne	5d18 <fwp_drop1+0x98>  // b.any
    5dc0:	39400260 	ldrb	w0, [x19]
    5dc4:	7103fc1f 	cmp	w0, #0xff
    5dc8:	540000e0 	b.eq	5de4 <fwp_drop1+0x164>  // b.none
    5dcc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5dd0:	39000260 	strb	w0, [x19]
    5dd4:	17ffffd1 	b	5d18 <fwp_drop1+0x98>
    5dd8:	90000040 	adrp	x0, d000 <atexit+0x10>
    5ddc:	91058000 	add	x0, x0, #0x160
    5de0:	97fff82c 	bl	3e90 <fwp_trap>
    5de4:	aa1303e0 	mov	x0, x19
    5de8:	97fff84a 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5dec:	17fffff8 	b	5dcc <fwp_drop1+0x14c>

0000000000005df0 <fwp_closure_drop>:
    5df0:	90000165 	adrp	x5, 31000 <fwp_root_context+0xca0>
    5df4:	911500a4 	add	x4, x5, #0x540
    5df8:	aa0003e1 	mov	x1, x0
    5dfc:	f949d882 	ldr	x2, [x4, #5040]
    5e00:	f949ec80 	ldr	x0, [x4, #5080]
    5e04:	cb020022 	sub	x2, x1, x2
    5e08:	eb00405f 	cmp	x2, x0, lsl #16
    5e0c:	54000662 	b.cs	5ed8 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5e10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5e14:	d350fc43 	lsr	x3, x2, #16
    5e18:	910003fd 	mov	x29, sp
    5e1c:	8b030863 	add	x3, x3, x3, lsl #2
    5e20:	f949fc84 	ldr	x4, [x4, #5112]
    5e24:	d37df063 	lsl	x3, x3, #3
    5e28:	f9000bf3 	str	x19, [sp, #16]
    5e2c:	8b030080 	add	x0, x4, x3
    5e30:	f9401013 	ldr	x19, [x0, #32]
    5e34:	b40002b3 	cbz	x19, 5e88 <fwp_closure_drop+0x98>
    5e38:	38636883 	ldrb	w3, [x4, x3]
    5e3c:	7100087f 	cmp	w3, #0x2
    5e40:	54000420 	b.eq	5ec4 <fwp_closure_drop+0xd4>  // b.none
    5e44:	7100047f 	cmp	w3, #0x1
    5e48:	54000201 	b.ne	5e88 <fwp_closure_drop+0x98>  // b.any
    5e4c:	29430003 	ldp	w3, w0, [x0, #24]
    5e50:	92403c42 	and	x2, x2, #0xffff
    5e54:	9b037c42 	mul	x2, x2, x3
    5e58:	d360fc42 	lsr	x2, x2, #32
    5e5c:	eb00005f 	cmp	x2, x0
    5e60:	54000142 	b.cs	5e88 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5e64:	8b020273 	add	x19, x19, x2
    5e68:	39400260 	ldrb	w0, [x19]
    5e6c:	340000e0 	cbz	w0, 5e88 <fwp_closure_drop+0x98>
    5e70:	7100041f 	cmp	w0, #0x1
    5e74:	54000100 	b.eq	5e94 <fwp_closure_drop+0xa4>  // b.none
    5e78:	7103fc1f 	cmp	w0, #0xff
    5e7c:	54000300 	b.eq	5edc <fwp_closure_drop+0xec>  // b.none
    5e80:	51000400 	sub	w0, w0, #0x1
    5e84:	39000260 	strb	w0, [x19]
    5e88:	f9400bf3 	ldr	x19, [sp, #16]
    5e8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e90:	d65f03c0 	ret
    5e94:	d53bd040 	mrs	x0, tpidr_el0
    5e98:	91400000 	add	x0, x0, #0x0, lsl #12
    5e9c:	91004000 	add	x0, x0, #0x10
    5ea0:	f9400000 	ldr	x0, [x0]
    5ea4:	b4000080 	cbz	x0, 5eb4 <fwp_closure_drop+0xc4>
    5ea8:	f9400bf3 	ldr	x19, [sp, #16]
    5eac:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5eb0:	17fff974 	b	4480 <fwp_closure_drop_push>
    5eb4:	f9400bf3 	ldr	x19, [sp, #16]
    5eb8:	aa0103e0 	mov	x0, x1
    5ebc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ec0:	17fff9b5 	b	4594 <fwp_closure_drop.part.0>
    5ec4:	72003c5f 	tst	w2, #0xffff
    5ec8:	54fffd00 	b.eq	5e68 <fwp_closure_drop+0x78>  // b.none
    5ecc:	f9400bf3 	ldr	x19, [sp, #16]
    5ed0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5ed4:	d65f03c0 	ret
    5ed8:	d65f03c0 	ret
    5edc:	ca534660 	eor	x0, x19, x19, lsr #17
    5ee0:	911500a5 	add	x5, x5, #0x540
    5ee4:	ca402400 	eor	x0, x0, x0, lsr #9
    5ee8:	92401c00 	and	x0, x0, #0xff
    5eec:	910a2402 	add	x2, x0, #0x289
    5ef0:	8b000ca0 	add	x0, x5, x0, lsl #3
    5ef4:	8b020ca2 	add	x2, x5, x2, lsl #3
    5ef8:	f94a2400 	ldr	x0, [x0, #5192]
    5efc:	b50000a0 	cbnz	x0, 5f10 <fwp_closure_drop+0x120>
    5f00:	14000013 	b	5f4c <fwp_closure_drop+0x15c>
    5f04:	91004002 	add	x2, x0, #0x10
    5f08:	f9400800 	ldr	x0, [x0, #16]
    5f0c:	b4000200 	cbz	x0, 5f4c <fwp_closure_drop+0x15c>
    5f10:	f9400001 	ldr	x1, [x0]
    5f14:	eb13003f 	cmp	x1, x19
    5f18:	54ffff61 	b.ne	5f04 <fwp_closure_drop+0x114>  // b.any
    5f1c:	f9400041 	ldr	x1, [x2]
    5f20:	f9400420 	ldr	x0, [x1, #8]
    5f24:	d1000400 	sub	x0, x0, #0x1
    5f28:	f9000420 	str	x0, [x1, #8]
    5f2c:	f103f81f 	cmp	x0, #0xfe
    5f30:	54fffac1 	b.ne	5e88 <fwp_closure_drop+0x98>  // b.any
    5f34:	39400260 	ldrb	w0, [x19]
    5f38:	7103fc1f 	cmp	w0, #0xff
    5f3c:	540000e0 	b.eq	5f58 <fwp_closure_drop+0x168>  // b.none
    5f40:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5f44:	39000260 	strb	w0, [x19]
    5f48:	17ffffd0 	b	5e88 <fwp_closure_drop+0x98>
    5f4c:	90000040 	adrp	x0, d000 <atexit+0x10>
    5f50:	91058000 	add	x0, x0, #0x160
    5f54:	97fff7cf 	bl	3e90 <fwp_trap>
    5f58:	aa1303e0 	mov	x0, x19
    5f5c:	97fff7ed 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5f60:	17fffff8 	b	5f40 <fwp_closure_drop+0x150>

0000000000005f64 <fwp_owned_tape_release>:
    5f64:	b4000920 	cbz	x0, 6088 <fwp_owned_tape_release+0x124>
    5f68:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f6c:	910003fd 	mov	x29, sp
    5f70:	a90153f3 	stp	x19, x20, [sp, #16]
    5f74:	aa0003f3 	mov	x19, x0
    5f78:	f9400000 	ldr	x0, [x0]
    5f7c:	b4000060 	cbz	x0, 5f88 <fwp_owned_tape_release+0x24>
    5f80:	f9400661 	ldr	x1, [x19, #8]
    5f84:	f9000401 	str	x1, [x0, #8]
    5f88:	f9400661 	ldr	x1, [x19, #8]
    5f8c:	b4000041 	cbz	x1, 5f94 <fwp_owned_tape_release+0x30>
    5f90:	f9000020 	str	x0, [x1]
    5f94:	f9400a60 	ldr	x0, [x19, #16]
    5f98:	f9403401 	ldr	x1, [x0, #104]
    5f9c:	b40005a1 	cbz	x1, 6050 <fwp_owned_tape_release+0xec>
    5fa0:	a9450a60 	ldp	x0, x2, [x19, #80]
    5fa4:	eb00005f 	cmp	x2, x0
    5fa8:	540002cd 	b.le	6000 <fwp_owned_tape_release+0x9c>
    5fac:	d2800014 	mov	x20, #0x0                   	// #0
    5fb0:	f90013f5 	str	x21, [sp, #32]
    5fb4:	d2800015 	mov	x21, #0x0                   	// #0
    5fb8:	f9402260 	ldr	x0, [x19, #64]
    5fbc:	910006b5 	add	x21, x21, #0x1
    5fc0:	f8746800 	ldr	x0, [x0, x20]
    5fc4:	d63f0020 	blr	x1
    5fc8:	f9402260 	ldr	x0, [x19, #64]
    5fcc:	f9400a61 	ldr	x1, [x19, #16]
    5fd0:	8b140000 	add	x0, x0, x20
    5fd4:	91004294 	add	x20, x20, #0x10
    5fd8:	f9400400 	ldr	x0, [x0, #8]
    5fdc:	f9403421 	ldr	x1, [x1, #104]
    5fe0:	d63f0020 	blr	x1
    5fe4:	a9450261 	ldp	x1, x0, [x19, #80]
    5fe8:	cb010000 	sub	x0, x0, x1
    5fec:	eb15001f 	cmp	x0, x21
    5ff0:	f9400a60 	ldr	x0, [x19, #16]
    5ff4:	f9403401 	ldr	x1, [x0, #104]
    5ff8:	54fffe0c 	b.gt	5fb8 <fwp_owned_tape_release+0x54>
    5ffc:	f94013f5 	ldr	x21, [sp, #32]
    6000:	f9403663 	ldr	x3, [x19, #104]
    6004:	f9401262 	ldr	x2, [x19, #32]
    6008:	f100007f 	cmp	x3, #0x0
    600c:	540001ed 	b.le	6048 <fwp_owned_tape_release+0xe4>
    6010:	d2800014 	mov	x20, #0x0                   	// #0
    6014:	d503201f 	nop
    6018:	f9402660 	ldr	x0, [x19, #72]
    601c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6020:	eb02001f 	cmp	x0, x2
    6024:	540000c0 	b.eq	603c <fwp_owned_tape_release+0xd8>  // b.none
    6028:	d63f0020 	blr	x1
    602c:	f9400a60 	ldr	x0, [x19, #16]
    6030:	f9401262 	ldr	x2, [x19, #32]
    6034:	f9403663 	ldr	x3, [x19, #104]
    6038:	f9403401 	ldr	x1, [x0, #104]
    603c:	91000694 	add	x20, x20, #0x1
    6040:	eb14007f 	cmp	x3, x20
    6044:	54fffeac 	b.gt	6018 <fwp_owned_tape_release+0xb4>
    6048:	aa0203e0 	mov	x0, x2
    604c:	d63f0020 	blr	x1
    6050:	f9401660 	ldr	x0, [x19, #40]
    6054:	97ffff67 	bl	5df0 <fwp_closure_drop>
    6058:	f9401a60 	ldr	x0, [x19, #48]
    605c:	97ffff65 	bl	5df0 <fwp_closure_drop>
    6060:	f9401e60 	ldr	x0, [x19, #56]
    6064:	97ffff63 	bl	5df0 <fwp_closure_drop>
    6068:	f9402260 	ldr	x0, [x19, #64]
    606c:	97fff845 	bl	4180 <fwp_mem_free>
    6070:	f9402660 	ldr	x0, [x19, #72]
    6074:	97fff843 	bl	4180 <fwp_mem_free>
    6078:	aa1303e0 	mov	x0, x19
    607c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6080:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6084:	17fff83f 	b	4180 <fwp_mem_free>
    6088:	d65f03c0 	ret
    608c:	d503201f 	nop

0000000000006090 <fwp_tape_finish>:
    6090:	d10203ff 	sub	sp, sp, #0x80
    6094:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6098:	f947f421 	ldr	x1, [x1, #4072]
    609c:	a9047bfd 	stp	x29, x30, [sp, #64]
    60a0:	910103fd 	add	x29, sp, #0x40
    60a4:	a90553f3 	stp	x19, x20, [sp, #80]
    60a8:	a9065bf5 	stp	x21, x22, [sp, #96]
    60ac:	a90763f7 	stp	x23, x24, [sp, #112]
    60b0:	d00000d8 	adrp	x24, 20000 <__data_start>
    60b4:	9100c316 	add	x22, x24, #0x30
    60b8:	f9400022 	ldr	x2, [x1]
    60bc:	f9001fe2 	str	x2, [sp, #56]
    60c0:	d2800002 	mov	x2, #0x0                   	// #0
    60c4:	9100e2c0 	add	x0, x22, #0x38
    60c8:	97fff48e 	bl	3300 <fwp_tape_buffers_dispose>
    60cc:	f9003adf 	str	xzr, [x22, #112]
    60d0:	f94042c0 	ldr	x0, [x22, #128]
    60d4:	f100001f 	cmp	x0, #0x0
    60d8:	5400030d 	b.le	6138 <fwp_tape_finish+0xa8>
    60dc:	910003f7 	mov	x23, sp
    60e0:	d2800015 	mov	x21, #0x0                   	// #0
    60e4:	d2800014 	mov	x20, #0x0                   	// #0
    60e8:	f94002d3 	ldr	x19, [x22]
    60ec:	91000694 	add	x20, x20, #0x1
    60f0:	8b150273 	add	x19, x19, x21
    60f4:	9101a2b5 	add	x21, x21, #0x68
    60f8:	aa1303e0 	mov	x0, x19
    60fc:	97fff3a5 	bl	2f90 <fwp_tape_unlink_scope>
    6100:	aa1703e0 	mov	x0, x23
    6104:	f9401261 	ldr	x1, [x19, #32]
    6108:	f90003e1 	str	x1, [sp]
    610c:	f9401a62 	ldr	x2, [x19, #48]
    6110:	f9000be2 	str	x2, [sp, #16]
    6114:	f9402261 	ldr	x1, [x19, #64]
    6118:	f90013e1 	str	x1, [sp, #32]
    611c:	97fff479 	bl	3300 <fwp_tape_buffers_dispose>
    6120:	f9403260 	ldr	x0, [x19, #96]
    6124:	97ffff90 	bl	5f64 <fwp_owned_tape_release>
    6128:	f900327f 	str	xzr, [x19, #96]
    612c:	f94042c0 	ldr	x0, [x22, #128]
    6130:	eb14001f 	cmp	x0, x20
    6134:	54fffdac 	b.gt	60e8 <fwp_tape_finish+0x58>
    6138:	f9401b00 	ldr	x0, [x24, #48]
    613c:	9100c313 	add	x19, x24, #0x30
    6140:	97fff200 	bl	2940 <free@plt>
    6144:	f9001b1f 	str	xzr, [x24, #48]
    6148:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    614c:	f947f400 	ldr	x0, [x0, #4072]
    6150:	f900427f 	str	xzr, [x19, #128]
    6154:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    6158:	f9401fe2 	ldr	x2, [sp, #56]
    615c:	f9400001 	ldr	x1, [x0]
    6160:	eb010042 	subs	x2, x2, x1
    6164:	d2800001 	mov	x1, #0x0                   	// #0
    6168:	540000e1 	b.ne	6184 <fwp_tape_finish+0xf4>  // b.any
    616c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6170:	a94553f3 	ldp	x19, x20, [sp, #80]
    6174:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6178:	a94763f7 	ldp	x23, x24, [sp, #112]
    617c:	910203ff 	add	sp, sp, #0x80
    6180:	d65f03c0 	ret
    6184:	97fff1bf 	bl	2880 <__stack_chk_fail@plt>
    6188:	d503201f 	nop
    618c:	d503201f 	nop

0000000000006190 <fwp_tape_scope_release>:
    6190:	d10243ff 	sub	sp, sp, #0x90
    6194:	a9047bfd 	stp	x29, x30, [sp, #64]
    6198:	910103fd 	add	x29, sp, #0x40
    619c:	a90553f3 	stp	x19, x20, [sp, #80]
    61a0:	aa0003f4 	mov	x20, x0
    61a4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    61a8:	f947f400 	ldr	x0, [x0, #4072]
    61ac:	b9400285 	ldr	w5, [x20]
    61b0:	f9400001 	ldr	x1, [x0]
    61b4:	f9001fe1 	str	x1, [sp, #56]
    61b8:	d2800001 	mov	x1, #0x0                   	// #0
    61bc:	37f806c5 	tbnz	w5, #31, 6294 <fwp_tape_scope_release+0x104>
    61c0:	a90763f7 	stp	x23, x24, [sp, #112]
    61c4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    61c8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    61cc:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    61d0:	d00000d3 	adrp	x19, 20000 <__data_start>
    61d4:	910003f7 	mov	x23, sp
    61d8:	9100c273 	add	x19, x19, #0x30
    61dc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    61e0:	a9065bf5 	stp	x21, x22, [sp, #96]
    61e4:	52800d16 	mov	w22, #0x68                  	// #104
    61e8:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    61ec:	f90043f9 	str	x25, [sp, #128]
    61f0:	14000006 	b	6208 <fwp_tape_scope_release+0x78>
    61f4:	97fff443 	bl	3300 <fwp_tape_buffers_dispose>
    61f8:	aa1903e0 	mov	x0, x25
    61fc:	97ffff5a 	bl	5f64 <fwp_owned_tape_release>
    6200:	b9400285 	ldr	w5, [x20]
    6204:	37f80425 	tbnz	w5, #31, 6288 <fwp_tape_scope_release+0xf8>
    6208:	f9400266 	ldr	x6, [x19]
    620c:	9b367ca5 	smull	x5, w5, w22
    6210:	8b0500c0 	add	x0, x6, x5
    6214:	97fff35f 	bl	2f90 <fwp_tape_unlink_scope>
    6218:	ad410001 	ldp	q1, q0, [x0, #32]
    621c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6220:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6224:	f9400c03 	ldr	x3, [x0, #24]
    6228:	ad0003e1 	stp	q1, q0, [sp]
    622c:	b86568c1 	ldr	w1, [x6, x5]
    6230:	a9440804 	ldp	x4, x2, [x0, #64]
    6234:	b900041f 	str	wzr, [x0, #4]
    6238:	f9403019 	ldr	x25, [x0, #96]
    623c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6240:	f9000c1f 	str	xzr, [x0, #24]
    6244:	a9020fe4 	stp	x4, x3, [sp, #32]
    6248:	f9001be2 	str	x2, [sp, #48]
    624c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6250:	f900301f 	str	xzr, [x0, #96]
    6254:	6b15003f 	cmp	w1, w21
    6258:	540000e8 	b.hi	6274 <fwp_tape_scope_release+0xe4>  // b.pmore
    625c:	9343fca5 	asr	x5, x5, #3
    6260:	f9404e60 	ldr	x0, [x19, #152]
    6264:	9b187ca5 	mul	x5, x5, x24
    6268:	eb0000bf 	cmp	x5, x0
    626c:	5400004a 	b.ge	6274 <fwp_tape_scope_release+0xe4>  // b.tcont
    6270:	f9004e65 	str	x5, [x19, #152]
    6274:	aa1703e0 	mov	x0, x23
    6278:	b5fffbf9 	cbnz	x25, 61f4 <fwp_tape_scope_release+0x64>
    627c:	97fff6bd 	bl	3d70 <fwp_tape_buffers_release>
    6280:	b9400285 	ldr	w5, [x20]
    6284:	36fffc25 	tbz	w5, #31, 6208 <fwp_tape_scope_release+0x78>
    6288:	a9465bf5 	ldp	x21, x22, [sp, #96]
    628c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6290:	f94043f9 	ldr	x25, [sp, #128]
    6294:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6298:	f947f400 	ldr	x0, [x0, #4072]
    629c:	f9401fe2 	ldr	x2, [sp, #56]
    62a0:	f9400001 	ldr	x1, [x0]
    62a4:	eb010042 	subs	x2, x2, x1
    62a8:	d2800001 	mov	x1, #0x0                   	// #0
    62ac:	540000a1 	b.ne	62c0 <fwp_tape_scope_release+0x130>  // b.any
    62b0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    62b4:	a94553f3 	ldp	x19, x20, [sp, #80]
    62b8:	910243ff 	add	sp, sp, #0x90
    62bc:	d65f03c0 	ret
    62c0:	a9065bf5 	stp	x21, x22, [sp, #96]
    62c4:	a90763f7 	stp	x23, x24, [sp, #112]
    62c8:	f90043f9 	str	x25, [sp, #128]
    62cc:	97fff16d 	bl	2880 <__stack_chk_fail@plt>

00000000000062d0 <fwp_drop4>:
    62d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    62d4:	910003fd 	mov	x29, sp
    62d8:	a9025bf5 	stp	x21, x22, [sp, #32]
    62dc:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xca0>
    62e0:	911502d5 	add	x21, x22, #0x540
    62e4:	a90153f3 	stp	x19, x20, [sp, #16]
    62e8:	aa0003f3 	mov	x19, x0
    62ec:	f949daa1 	ldr	x1, [x21, #5040]
    62f0:	f949eea0 	ldr	x0, [x21, #5080]
    62f4:	cb010261 	sub	x1, x19, x1
    62f8:	eb00403f 	cmp	x1, x0, lsl #16
    62fc:	54000382 	b.cs	636c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6300:	d350fc22 	lsr	x2, x1, #16
    6304:	f949fea3 	ldr	x3, [x21, #5112]
    6308:	8b020842 	add	x2, x2, x2, lsl #2
    630c:	d37df042 	lsl	x2, x2, #3
    6310:	8b020060 	add	x0, x3, x2
    6314:	f9401014 	ldr	x20, [x0, #32]
    6318:	b40002b4 	cbz	x20, 636c <fwp_drop4+0x9c>
    631c:	38626862 	ldrb	w2, [x3, x2]
    6320:	7100085f 	cmp	w2, #0x2
    6324:	540002c0 	b.eq	637c <fwp_drop4+0xac>  // b.none
    6328:	7100045f 	cmp	w2, #0x1
    632c:	54000201 	b.ne	636c <fwp_drop4+0x9c>  // b.any
    6330:	29430002 	ldp	w2, w0, [x0, #24]
    6334:	92403c21 	and	x1, x1, #0xffff
    6338:	9b027c21 	mul	x1, x1, x2
    633c:	d360fc21 	lsr	x1, x1, #32
    6340:	eb00003f 	cmp	x1, x0
    6344:	54000142 	b.cs	636c <fwp_drop4+0x9c>  // b.hs, b.nlast
    6348:	8b010294 	add	x20, x20, x1
    634c:	39400280 	ldrb	w0, [x20]
    6350:	340000e0 	cbz	w0, 636c <fwp_drop4+0x9c>
    6354:	7100041f 	cmp	w0, #0x1
    6358:	540001e0 	b.eq	6394 <fwp_drop4+0xc4>  // b.none
    635c:	7103fc1f 	cmp	w0, #0xff
    6360:	540007c0 	b.eq	6458 <fwp_drop4+0x188>  // b.none
    6364:	51000400 	sub	w0, w0, #0x1
    6368:	39000280 	strb	w0, [x20]
    636c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6370:	a9425bf5 	ldp	x21, x22, [sp, #32]
    6374:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6378:	d65f03c0 	ret
    637c:	72003c3f 	tst	w1, #0xffff
    6380:	54fffe60 	b.eq	634c <fwp_drop4+0x7c>  // b.none
    6384:	a94153f3 	ldp	x19, x20, [sp, #16]
    6388:	a9425bf5 	ldp	x21, x22, [sp, #32]
    638c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6390:	d65f03c0 	ret
    6394:	911502c2 	add	x2, x22, #0x540
    6398:	f9400660 	ldr	x0, [x19, #8]
    639c:	f949d841 	ldr	x1, [x2, #5040]
    63a0:	f949ec42 	ldr	x2, [x2, #5080]
    63a4:	cb010001 	sub	x1, x0, x1
    63a8:	eb02403f 	cmp	x1, x2, lsl #16
    63ac:	54000362 	b.cs	6418 <fwp_drop4+0x148>  // b.hs, b.nlast
    63b0:	d350fc22 	lsr	x2, x1, #16
    63b4:	8b020842 	add	x2, x2, x2, lsl #2
    63b8:	d37df042 	lsl	x2, x2, #3
    63bc:	8b020064 	add	x4, x3, x2
    63c0:	f9401094 	ldr	x20, [x4, #32]
    63c4:	b40002b4 	cbz	x20, 6418 <fwp_drop4+0x148>
    63c8:	38626862 	ldrb	w2, [x3, x2]
    63cc:	7100085f 	cmp	w2, #0x2
    63d0:	540003e0 	b.eq	644c <fwp_drop4+0x17c>  // b.none
    63d4:	7100045f 	cmp	w2, #0x1
    63d8:	54000201 	b.ne	6418 <fwp_drop4+0x148>  // b.any
    63dc:	29430883 	ldp	w3, w2, [x4, #24]
    63e0:	92403c21 	and	x1, x1, #0xffff
    63e4:	9b037c21 	mul	x1, x1, x3
    63e8:	d360fc21 	lsr	x1, x1, #32
    63ec:	eb02003f 	cmp	x1, x2
    63f0:	54000142 	b.cs	6418 <fwp_drop4+0x148>  // b.hs, b.nlast
    63f4:	8b010294 	add	x20, x20, x1
    63f8:	39400281 	ldrb	w1, [x20]
    63fc:	340000e1 	cbz	w1, 6418 <fwp_drop4+0x148>
    6400:	7100043f 	cmp	w1, #0x1
    6404:	54000200 	b.eq	6444 <fwp_drop4+0x174>  // b.none
    6408:	7103fc3f 	cmp	w1, #0xff
    640c:	54000640 	b.eq	64d4 <fwp_drop4+0x204>  // b.none
    6410:	51000421 	sub	w1, w1, #0x1
    6414:	39000281 	strb	w1, [x20]
    6418:	f9400a74 	ldr	x20, [x19, #16]
    641c:	aa1303e0 	mov	x0, x19
    6420:	97fffce8 	bl	57c0 <fwp_rc_free_arr>
    6424:	911502c0 	add	x0, x22, #0x540
    6428:	f949d801 	ldr	x1, [x0, #5040]
    642c:	f949ec00 	ldr	x0, [x0, #5080]
    6430:	cb010281 	sub	x1, x20, x1
    6434:	eb00403f 	cmp	x1, x0, lsl #16
    6438:	54fff9a2 	b.cs	636c <fwp_drop4+0x9c>  // b.hs, b.nlast
    643c:	aa1403f3 	mov	x19, x20
    6440:	17ffffb0 	b	6300 <fwp_drop4+0x30>
    6444:	97fffcdf 	bl	57c0 <fwp_rc_free_arr>
    6448:	17fffff4 	b	6418 <fwp_drop4+0x148>
    644c:	72003c3f 	tst	w1, #0xffff
    6450:	54fffe41 	b.ne	6418 <fwp_drop4+0x148>  // b.any
    6454:	17ffffe9 	b	63f8 <fwp_drop4+0x128>
    6458:	ca544681 	eor	x1, x20, x20, lsr #17
    645c:	911502c0 	add	x0, x22, #0x540
    6460:	ca412421 	eor	x1, x1, x1, lsr #9
    6464:	92401c21 	and	x1, x1, #0xff
    6468:	910a2422 	add	x2, x1, #0x289
    646c:	8b010c01 	add	x1, x0, x1, lsl #3
    6470:	8b020c02 	add	x2, x0, x2, lsl #3
    6474:	f94a2420 	ldr	x0, [x1, #5192]
    6478:	b50000a0 	cbnz	x0, 648c <fwp_drop4+0x1bc>
    647c:	14000013 	b	64c8 <fwp_drop4+0x1f8>
    6480:	91004002 	add	x2, x0, #0x10
    6484:	f9400800 	ldr	x0, [x0, #16]
    6488:	b4000200 	cbz	x0, 64c8 <fwp_drop4+0x1f8>
    648c:	f9400001 	ldr	x1, [x0]
    6490:	eb14003f 	cmp	x1, x20
    6494:	54ffff61 	b.ne	6480 <fwp_drop4+0x1b0>  // b.any
    6498:	f9400041 	ldr	x1, [x2]
    649c:	f9400420 	ldr	x0, [x1, #8]
    64a0:	d1000400 	sub	x0, x0, #0x1
    64a4:	f9000420 	str	x0, [x1, #8]
    64a8:	f103f81f 	cmp	x0, #0xfe
    64ac:	54fff601 	b.ne	636c <fwp_drop4+0x9c>  // b.any
    64b0:	39400280 	ldrb	w0, [x20]
    64b4:	7103fc1f 	cmp	w0, #0xff
    64b8:	54000460 	b.eq	6544 <fwp_drop4+0x274>  // b.none
    64bc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    64c0:	39000280 	strb	w0, [x20]
    64c4:	17ffffaa 	b	636c <fwp_drop4+0x9c>
    64c8:	f0000020 	adrp	x0, d000 <atexit+0x10>
    64cc:	91058000 	add	x0, x0, #0x160
    64d0:	97fff670 	bl	3e90 <fwp_trap>
    64d4:	ca544680 	eor	x0, x20, x20, lsr #17
    64d8:	911502c1 	add	x1, x22, #0x540
    64dc:	ca402400 	eor	x0, x0, x0, lsr #9
    64e0:	92401c00 	and	x0, x0, #0xff
    64e4:	910a2402 	add	x2, x0, #0x289
    64e8:	8b000c20 	add	x0, x1, x0, lsl #3
    64ec:	8b020c22 	add	x2, x1, x2, lsl #3
    64f0:	f94a2400 	ldr	x0, [x0, #5192]
    64f4:	b50000a0 	cbnz	x0, 6508 <fwp_drop4+0x238>
    64f8:	17fffff4 	b	64c8 <fwp_drop4+0x1f8>
    64fc:	91004002 	add	x2, x0, #0x10
    6500:	f9400800 	ldr	x0, [x0, #16]
    6504:	b4fffe20 	cbz	x0, 64c8 <fwp_drop4+0x1f8>
    6508:	f9400001 	ldr	x1, [x0]
    650c:	eb14003f 	cmp	x1, x20
    6510:	54ffff61 	b.ne	64fc <fwp_drop4+0x22c>  // b.any
    6514:	f9400041 	ldr	x1, [x2]
    6518:	f9400420 	ldr	x0, [x1, #8]
    651c:	d1000400 	sub	x0, x0, #0x1
    6520:	f9000420 	str	x0, [x1, #8]
    6524:	f103f81f 	cmp	x0, #0xfe
    6528:	54fff781 	b.ne	6418 <fwp_drop4+0x148>  // b.any
    652c:	39400280 	ldrb	w0, [x20]
    6530:	7103fc1f 	cmp	w0, #0xff
    6534:	540000e0 	b.eq	6550 <fwp_drop4+0x280>  // b.none
    6538:	12800020 	mov	w0, #0xfffffffe            	// #-2
    653c:	39000280 	strb	w0, [x20]
    6540:	17ffffb6 	b	6418 <fwp_drop4+0x148>
    6544:	aa1403e0 	mov	x0, x20
    6548:	97fff672 	bl	3f10 <fwp_rc_forget_slot.part.0>
    654c:	17ffffdc 	b	64bc <fwp_drop4+0x1ec>
    6550:	aa1403e0 	mov	x0, x20
    6554:	97fff66f 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6558:	17fffff8 	b	6538 <fwp_drop4+0x268>
    655c:	d503201f 	nop

0000000000006560 <fwp_arg_drop37>:
    6560:	7100003f 	cmp	w1, #0x0
    6564:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6568:	54000041 	b.ne	6570 <fwp_arg_drop37+0x10>  // b.any
    656c:	d65f03c0 	ret
    6570:	f9400000 	ldr	x0, [x0]
    6574:	17ffff57 	b	62d0 <fwp_drop4>
    6578:	d503201f 	nop
    657c:	d503201f 	nop

0000000000006580 <fwp_task_dispose>:
    6580:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6584:	910003fd 	mov	x29, sp
    6588:	f9000bf3 	str	x19, [sp, #16]
    658c:	aa0003f3 	mov	x19, x0
    6590:	39414000 	ldrb	w0, [x0, #80]
    6594:	36000720 	tbz	w0, #0, 6678 <fwp_task_dispose+0xf8>
    6598:	f9400a60 	ldr	x0, [x19, #16]
    659c:	b50006e0 	cbnz	x0, 6678 <fwp_task_dispose+0xf8>
    65a0:	a9478660 	ldp	x0, x1, [x19, #120]
    65a4:	39014e7f 	strb	wzr, [x19, #83]
    65a8:	f9003e7f 	str	xzr, [x19, #120]
    65ac:	f100003f 	cmp	x1, #0x0
    65b0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    65b4:	54000040 	b.eq	65bc <fwp_task_dispose+0x3c>  // b.none
    65b8:	d63f0020 	blr	x1
    65bc:	f9405660 	ldr	x0, [x19, #168]
    65c0:	97fff6f0 	bl	4180 <fwp_mem_free>
    65c4:	f900567f 	str	xzr, [x19, #168]
    65c8:	b9405e60 	ldr	w0, [x19, #92]
    65cc:	7100041f 	cmp	w0, #0x1
    65d0:	54000420 	b.eq	6654 <fwp_task_dispose+0xd4>  // b.none
    65d4:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    65d8:	91150042 	add	x2, x2, #0x540
    65dc:	f949d840 	ldr	x0, [x2, #5040]
    65e0:	f949ec41 	ldr	x1, [x2, #5080]
    65e4:	cb000260 	sub	x0, x19, x0
    65e8:	eb01401f 	cmp	x0, x1, lsl #16
    65ec:	540002e2 	b.cs	6648 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    65f0:	d350fc01 	lsr	x1, x0, #16
    65f4:	f949fc44 	ldr	x4, [x2, #5112]
    65f8:	8b010821 	add	x1, x1, x1, lsl #2
    65fc:	d37df021 	lsl	x1, x1, #3
    6600:	8b010083 	add	x3, x4, x1
    6604:	f9401062 	ldr	x2, [x3, #32]
    6608:	b4000202 	cbz	x2, 6648 <fwp_task_dispose+0xc8>
    660c:	38616881 	ldrb	w1, [x4, x1]
    6610:	7100083f 	cmp	w1, #0x2
    6614:	54000280 	b.eq	6664 <fwp_task_dispose+0xe4>  // b.none
    6618:	7100043f 	cmp	w1, #0x1
    661c:	54000161 	b.ne	6648 <fwp_task_dispose+0xc8>  // b.any
    6620:	29430464 	ldp	w4, w1, [x3, #24]
    6624:	92403c00 	and	x0, x0, #0xffff
    6628:	9b047c00 	mul	x0, x0, x4
    662c:	d360fc00 	lsr	x0, x0, #32
    6630:	eb01001f 	cmp	x0, x1
    6634:	540000a2 	b.cs	6648 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6638:	8b000042 	add	x2, x2, x0
    663c:	39400040 	ldrb	w0, [x2]
    6640:	7100041f 	cmp	w0, #0x1
    6644:	54000080 	b.eq	6654 <fwp_task_dispose+0xd4>  // b.none
    6648:	f9400bf3 	ldr	x19, [sp, #16]
    664c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6650:	d65f03c0 	ret
    6654:	aa1303e0 	mov	x0, x19
    6658:	f9400bf3 	ldr	x19, [sp, #16]
    665c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6660:	17fff6c8 	b	4180 <fwp_mem_free>
    6664:	72003c1f 	tst	w0, #0xffff
    6668:	54fffea0 	b.eq	663c <fwp_task_dispose+0xbc>  // b.none
    666c:	f9400bf3 	ldr	x19, [sp, #16]
    6670:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6674:	d65f03c0 	ret
    6678:	97fff096 	bl	28d0 <abort@plt>
    667c:	d503201f 	nop

0000000000006680 <fwp_free_zombie>:
    6680:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6684:	910003fd 	mov	x29, sp
    6688:	a90153f3 	stp	x19, x20, [sp, #16]
    668c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6690:	9100c281 	add	x1, x20, #0x30
    6694:	f9405033 	ldr	x19, [x1, #160]
    6698:	b4000333 	cbz	x19, 66fc <fwp_free_zombie+0x7c>
    669c:	f9400820 	ldr	x0, [x1, #16]
    66a0:	eb00027f 	cmp	x19, x0
    66a4:	540002c0 	b.eq	66fc <fwp_free_zombie+0x7c>  // b.none
    66a8:	b940a822 	ldr	w2, [x1, #168]
    66ac:	f9400a60 	ldr	x0, [x19, #16]
    66b0:	7100fc5f 	cmp	w2, #0x3f
    66b4:	5400078c 	b.gt	67a4 <fwp_free_zombie+0x124>
    66b8:	9102c023 	add	x3, x1, #0xb0
    66bc:	11000444 	add	w4, w2, #0x1
    66c0:	b900a824 	str	w4, [x1, #168]
    66c4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66c8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    66cc:	a9530261 	ldp	x1, x0, [x19, #304]
    66d0:	b4000741 	cbz	x1, 67b8 <fwp_free_zombie+0x138>
    66d4:	f9009c20 	str	x0, [x1, #312]
    66d8:	b4000040 	cbz	x0, 66e0 <fwp_free_zombie+0x60>
    66dc:	f9009801 	str	x1, [x0, #304]
    66e0:	9100c294 	add	x20, x20, #0x30
    66e4:	b9405e60 	ldr	w0, [x19, #92]
    66e8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    66ec:	f900529f 	str	xzr, [x20, #160]
    66f0:	34000140 	cbz	w0, 6718 <fwp_free_zombie+0x98>
    66f4:	7100041f 	cmp	w0, #0x1
    66f8:	54000080 	b.eq	6708 <fwp_free_zombie+0x88>  // b.none
    66fc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6700:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6704:	d65f03c0 	ret
    6708:	aa1303e0 	mov	x0, x19
    670c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6710:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6714:	17ffff9b 	b	6580 <fwp_task_dispose>
    6718:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xca0>
    671c:	91150082 	add	x2, x4, #0x540
    6720:	f949d841 	ldr	x1, [x2, #5040]
    6724:	f949ec40 	ldr	x0, [x2, #5080]
    6728:	cb010261 	sub	x1, x19, x1
    672c:	eb00403f 	cmp	x1, x0, lsl #16
    6730:	54fffe62 	b.cs	66fc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6734:	d350fc20 	lsr	x0, x1, #16
    6738:	f949fc43 	ldr	x3, [x2, #5112]
    673c:	8b000800 	add	x0, x0, x0, lsl #2
    6740:	d37df000 	lsl	x0, x0, #3
    6744:	8b000062 	add	x2, x3, x0
    6748:	f9401054 	ldr	x20, [x2, #32]
    674c:	b4fffd94 	cbz	x20, 66fc <fwp_free_zombie+0x7c>
    6750:	38606860 	ldrb	w0, [x3, x0]
    6754:	7100081f 	cmp	w0, #0x2
    6758:	54000360 	b.eq	67c4 <fwp_free_zombie+0x144>  // b.none
    675c:	7100041f 	cmp	w0, #0x1
    6760:	54fffce1 	b.ne	66fc <fwp_free_zombie+0x7c>  // b.any
    6764:	29430043 	ldp	w3, w0, [x2, #24]
    6768:	92403c21 	and	x1, x1, #0xffff
    676c:	9b037c21 	mul	x1, x1, x3
    6770:	d360fc21 	lsr	x1, x1, #32
    6774:	eb00003f 	cmp	x1, x0
    6778:	54fffc22 	b.cs	66fc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    677c:	8b010294 	add	x20, x20, x1
    6780:	39400280 	ldrb	w0, [x20]
    6784:	34fffbc0 	cbz	w0, 66fc <fwp_free_zombie+0x7c>
    6788:	7100041f 	cmp	w0, #0x1
    678c:	54fffbe0 	b.eq	6708 <fwp_free_zombie+0x88>  // b.none
    6790:	7103fc1f 	cmp	w0, #0xff
    6794:	540001e0 	b.eq	67d0 <fwp_free_zombie+0x150>  // b.none
    6798:	51000400 	sub	w0, w0, #0x1
    679c:	39000280 	strb	w0, [x20]
    67a0:	17ffffd7 	b	66fc <fwp_free_zombie+0x7c>
    67a4:	f9400e61 	ldr	x1, [x19, #24]
    67a8:	97fff07e 	bl	29a0 <munmap@plt>
    67ac:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    67b0:	a9530261 	ldp	x1, x0, [x19, #304]
    67b4:	b5fff901 	cbnz	x1, 66d4 <fwp_free_zombie+0x54>
    67b8:	9100c282 	add	x2, x20, #0x30
    67bc:	f9015840 	str	x0, [x2, #688]
    67c0:	17ffffc6 	b	66d8 <fwp_free_zombie+0x58>
    67c4:	72003c3f 	tst	w1, #0xffff
    67c8:	54fff9a1 	b.ne	66fc <fwp_free_zombie+0x7c>  // b.any
    67cc:	17ffffed 	b	6780 <fwp_free_zombie+0x100>
    67d0:	ca544680 	eor	x0, x20, x20, lsr #17
    67d4:	91150084 	add	x4, x4, #0x540
    67d8:	ca402400 	eor	x0, x0, x0, lsr #9
    67dc:	92401c00 	and	x0, x0, #0xff
    67e0:	910a2402 	add	x2, x0, #0x289
    67e4:	8b000c80 	add	x0, x4, x0, lsl #3
    67e8:	8b020c82 	add	x2, x4, x2, lsl #3
    67ec:	f94a2400 	ldr	x0, [x0, #5192]
    67f0:	b50000a0 	cbnz	x0, 6804 <fwp_free_zombie+0x184>
    67f4:	14000013 	b	6840 <fwp_free_zombie+0x1c0>
    67f8:	91004002 	add	x2, x0, #0x10
    67fc:	f9400800 	ldr	x0, [x0, #16]
    6800:	b4000200 	cbz	x0, 6840 <fwp_free_zombie+0x1c0>
    6804:	f9400001 	ldr	x1, [x0]
    6808:	eb14003f 	cmp	x1, x20
    680c:	54ffff61 	b.ne	67f8 <fwp_free_zombie+0x178>  // b.any
    6810:	f9400041 	ldr	x1, [x2]
    6814:	f9400420 	ldr	x0, [x1, #8]
    6818:	d1000400 	sub	x0, x0, #0x1
    681c:	f9000420 	str	x0, [x1, #8]
    6820:	f103f81f 	cmp	x0, #0xfe
    6824:	54fff6c1 	b.ne	66fc <fwp_free_zombie+0x7c>  // b.any
    6828:	39400280 	ldrb	w0, [x20]
    682c:	7103fc1f 	cmp	w0, #0xff
    6830:	540000e0 	b.eq	684c <fwp_free_zombie+0x1cc>  // b.none
    6834:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6838:	39000280 	strb	w0, [x20]
    683c:	17ffffb0 	b	66fc <fwp_free_zombie+0x7c>
    6840:	f0000020 	adrp	x0, d000 <atexit+0x10>
    6844:	91058000 	add	x0, x0, #0x160
    6848:	97fff592 	bl	3e90 <fwp_trap>
    684c:	aa1403e0 	mov	x0, x20
    6850:	97fff5b0 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6854:	17fffff8 	b	6834 <fwp_free_zombie+0x1b4>
    6858:	d503201f 	nop
    685c:	d503201f 	nop

0000000000006860 <fwp_block>:
    6860:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6864:	910003fd 	mov	x29, sp
    6868:	a90153f3 	stp	x19, x20, [sp, #16]
    686c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6870:	9100c274 	add	x20, x19, #0x30
    6874:	f9401a82 	ldr	x2, [x20, #48]
    6878:	b4000642 	cbz	x2, 6940 <fwp_block+0xe0>
    687c:	9100c261 	add	x1, x19, #0x30
    6880:	f9408040 	ldr	x0, [x2, #256]
    6884:	f9001820 	str	x0, [x1, #48]
    6888:	b40006a0 	cbz	x0, 695c <fwp_block+0xfc>
    688c:	d503201f 	nop
    6890:	9100c263 	add	x3, x19, #0x30
    6894:	3901505f 	strb	wzr, [x2, #84]
    6898:	f9400864 	ldr	x4, [x3, #16]
    689c:	eb02009f 	cmp	x4, x2
    68a0:	54000440 	b.eq	6928 <fwp_block+0xc8>  // b.none
    68a4:	f9415c65 	ldr	x5, [x3, #696]
    68a8:	f9000862 	str	x2, [x3, #16]
    68ac:	f9400441 	ldr	x1, [x2, #8]
    68b0:	f9004885 	str	x5, [x4, #144]
    68b4:	f9416065 	ldr	x5, [x3, #704]
    68b8:	f9004c85 	str	x5, [x4, #152]
    68bc:	f9416465 	ldr	x5, [x3, #712]
    68c0:	f9005085 	str	x5, [x4, #160]
    68c4:	f9416865 	ldr	x5, [x3, #720]
    68c8:	f9005485 	str	x5, [x4, #168]
    68cc:	f9416c65 	ldr	x5, [x3, #728]
    68d0:	f9005885 	str	x5, [x4, #176]
    68d4:	f9417065 	ldr	x5, [x3, #736]
    68d8:	f9005c85 	str	x5, [x4, #184]
    68dc:	f9417465 	ldr	x5, [x3, #744]
    68e0:	f9006085 	str	x5, [x4, #192]
    68e4:	f9400480 	ldr	x0, [x4, #8]
    68e8:	f9404844 	ldr	x4, [x2, #144]
    68ec:	f9015c64 	str	x4, [x3, #696]
    68f0:	f9404c44 	ldr	x4, [x2, #152]
    68f4:	f9016064 	str	x4, [x3, #704]
    68f8:	f9405044 	ldr	x4, [x2, #160]
    68fc:	f9016464 	str	x4, [x3, #712]
    6900:	f9405444 	ldr	x4, [x2, #168]
    6904:	f9016864 	str	x4, [x3, #720]
    6908:	f9405844 	ldr	x4, [x2, #176]
    690c:	f9016c64 	str	x4, [x3, #728]
    6910:	a94b8844 	ldp	x4, x2, [x2, #184]
    6914:	f9017064 	str	x4, [x3, #736]
    6918:	f9017462 	str	x2, [x3, #744]
    691c:	97ffeff1 	bl	28e0 <swapcontext@plt>
    6920:	97ffff58 	bl	6680 <fwp_free_zombie>
    6924:	d503201f 	nop
    6928:	9100c260 	add	x0, x19, #0x30
    692c:	b942f000 	ldr	w0, [x0, #752]
    6930:	340001a0 	cbz	w0, 6964 <fwp_block+0x104>
    6934:	a94153f3 	ldp	x19, x20, [sp, #16]
    6938:	a8c27bfd 	ldp	x29, x30, [sp], #32
    693c:	d65f03c0 	ret
    6940:	97fff79c 	bl	47b0 <fwp_poll_events>
    6944:	f9401a82 	ldr	x2, [x20, #48]
    6948:	b4ffffc2 	cbz	x2, 6940 <fwp_block+0xe0>
    694c:	9100c261 	add	x1, x19, #0x30
    6950:	f9408040 	ldr	x0, [x2, #256]
    6954:	f9001820 	str	x0, [x1, #48]
    6958:	b5fff9c0 	cbnz	x0, 6890 <fwp_block+0x30>
    695c:	f900143f 	str	xzr, [x1, #40]
    6960:	17ffffcc 	b	6890 <fwp_block+0x30>
    6964:	f0000020 	adrp	x0, d000 <atexit+0x10>
    6968:	910fe000 	add	x0, x0, #0x3f8
    696c:	97fff029 	bl	2a10 <getenv@plt>
    6970:	5284e202 	mov	w2, #0x2710                	// #10000
    6974:	b4000060 	cbz	x0, 6980 <fwp_block+0x120>
    6978:	39400001 	ldrb	w1, [x0]
    697c:	350000c1 	cbnz	w1, 6994 <fwp_block+0x134>
    6980:	9100c273 	add	x19, x19, #0x30
    6984:	b902f262 	str	w2, [x19, #752]
    6988:	a94153f3 	ldp	x19, x20, [sp, #16]
    698c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6990:	d65f03c0 	ret
    6994:	52800142 	mov	w2, #0xa                   	// #10
    6998:	d2800001 	mov	x1, #0x0                   	// #0
    699c:	97ffef6d 	bl	2750 <strtoll@plt>
    69a0:	d1000403 	sub	x3, x0, #0x1
    69a4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    69a8:	eb02007f 	cmp	x3, x2
    69ac:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    69b0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    69b4:	17fffff3 	b	6980 <fwp_block+0x120>
    69b8:	d503201f 	nop
    69bc:	d503201f 	nop

00000000000069c0 <fwp_drop10>:
    69c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    69c4:	910003fd 	mov	x29, sp
    69c8:	a90153f3 	stp	x19, x20, [sp, #16]
    69cc:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xca0>
    69d0:	f90013f5 	str	x21, [sp, #32]
    69d4:	91150275 	add	x21, x19, #0x540
    69d8:	f949daa1 	ldr	x1, [x21, #5040]
    69dc:	f949eea2 	ldr	x2, [x21, #5080]
    69e0:	cb010001 	sub	x1, x0, x1
    69e4:	eb02403f 	cmp	x1, x2, lsl #16
    69e8:	54000382 	b.cs	6a58 <fwp_drop10+0x98>  // b.hs, b.nlast
    69ec:	d350fc22 	lsr	x2, x1, #16
    69f0:	f949fea3 	ldr	x3, [x21, #5112]
    69f4:	8b020842 	add	x2, x2, x2, lsl #2
    69f8:	d37df042 	lsl	x2, x2, #3
    69fc:	8b020064 	add	x4, x3, x2
    6a00:	f9401094 	ldr	x20, [x4, #32]
    6a04:	b40002b4 	cbz	x20, 6a58 <fwp_drop10+0x98>
    6a08:	38626862 	ldrb	w2, [x3, x2]
    6a0c:	7100085f 	cmp	w2, #0x2
    6a10:	540007a0 	b.eq	6b04 <fwp_drop10+0x144>  // b.none
    6a14:	7100045f 	cmp	w2, #0x1
    6a18:	54000201 	b.ne	6a58 <fwp_drop10+0x98>  // b.any
    6a1c:	29430885 	ldp	w5, w2, [x4, #24]
    6a20:	92403c21 	and	x1, x1, #0xffff
    6a24:	9b057c21 	mul	x1, x1, x5
    6a28:	d360fc21 	lsr	x1, x1, #32
    6a2c:	eb02003f 	cmp	x1, x2
    6a30:	54000142 	b.cs	6a58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a34:	8b010294 	add	x20, x20, x1
    6a38:	39400281 	ldrb	w1, [x20]
    6a3c:	340000e1 	cbz	w1, 6a58 <fwp_drop10+0x98>
    6a40:	7100043f 	cmp	w1, #0x1
    6a44:	54000120 	b.eq	6a68 <fwp_drop10+0xa8>  // b.none
    6a48:	7103fc3f 	cmp	w1, #0xff
    6a4c:	540007c0 	b.eq	6b44 <fwp_drop10+0x184>  // b.none
    6a50:	51000421 	sub	w1, w1, #0x1
    6a54:	39000281 	strb	w1, [x20]
    6a58:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a5c:	f94013f5 	ldr	x21, [sp, #32]
    6a60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a64:	d65f03c0 	ret
    6a68:	f9400001 	ldr	x1, [x0]
    6a6c:	b7f80581 	tbnz	x1, #63, 6b1c <fwp_drop10+0x15c>
    6a70:	91150273 	add	x19, x19, #0x540
    6a74:	f949da61 	ldr	x1, [x19, #5040]
    6a78:	f949ee62 	ldr	x2, [x19, #5080]
    6a7c:	cb010001 	sub	x1, x0, x1
    6a80:	eb02403f 	cmp	x1, x2, lsl #16
    6a84:	54fffea2 	b.cs	6a58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a88:	d350fc22 	lsr	x2, x1, #16
    6a8c:	8b020842 	add	x2, x2, x2, lsl #2
    6a90:	d37df042 	lsl	x2, x2, #3
    6a94:	8b020065 	add	x5, x3, x2
    6a98:	f94010a4 	ldr	x4, [x5, #32]
    6a9c:	b4fffde4 	cbz	x4, 6a58 <fwp_drop10+0x98>
    6aa0:	38626862 	ldrb	w2, [x3, x2]
    6aa4:	7100085f 	cmp	w2, #0x2
    6aa8:	54000220 	b.eq	6aec <fwp_drop10+0x12c>  // b.none
    6aac:	7100045f 	cmp	w2, #0x1
    6ab0:	54fffd41 	b.ne	6a58 <fwp_drop10+0x98>  // b.any
    6ab4:	294308a3 	ldp	w3, w2, [x5, #24]
    6ab8:	92403c21 	and	x1, x1, #0xffff
    6abc:	9b037c21 	mul	x1, x1, x3
    6ac0:	d360fc21 	lsr	x1, x1, #32
    6ac4:	eb02003f 	cmp	x1, x2
    6ac8:	54fffc82 	b.cs	6a58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6acc:	8b010084 	add	x4, x4, x1
    6ad0:	39400081 	ldrb	w1, [x4]
    6ad4:	7100043f 	cmp	w1, #0x1
    6ad8:	54fffc01 	b.ne	6a58 <fwp_drop10+0x98>  // b.any
    6adc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ae0:	f94013f5 	ldr	x21, [sp, #32]
    6ae4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ae8:	17fff5a6 	b	4180 <fwp_mem_free>
    6aec:	72003c3f 	tst	w1, #0xffff
    6af0:	54ffff00 	b.eq	6ad0 <fwp_drop10+0x110>  // b.none
    6af4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6af8:	f94013f5 	ldr	x21, [sp, #32]
    6afc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b00:	d65f03c0 	ret
    6b04:	72003c3f 	tst	w1, #0xffff
    6b08:	54fff980 	b.eq	6a38 <fwp_drop10+0x78>  // b.none
    6b0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b10:	f94013f5 	ldr	x21, [sp, #32]
    6b14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6b18:	d65f03c0 	ret
    6b1c:	f9400414 	ldr	x20, [x0, #8]
    6b20:	97fffb28 	bl	57c0 <fwp_rc_free_arr>
    6b24:	91150260 	add	x0, x19, #0x540
    6b28:	f949d801 	ldr	x1, [x0, #5040]
    6b2c:	f949ec00 	ldr	x0, [x0, #5080]
    6b30:	cb010281 	sub	x1, x20, x1
    6b34:	eb00403f 	cmp	x1, x0, lsl #16
    6b38:	54fff902 	b.cs	6a58 <fwp_drop10+0x98>  // b.hs, b.nlast
    6b3c:	aa1403e0 	mov	x0, x20
    6b40:	17ffffab 	b	69ec <fwp_drop10+0x2c>
    6b44:	ca544680 	eor	x0, x20, x20, lsr #17
    6b48:	91150273 	add	x19, x19, #0x540
    6b4c:	ca402400 	eor	x0, x0, x0, lsr #9
    6b50:	92401c00 	and	x0, x0, #0xff
    6b54:	910a2402 	add	x2, x0, #0x289
    6b58:	8b000e60 	add	x0, x19, x0, lsl #3
    6b5c:	8b020e62 	add	x2, x19, x2, lsl #3
    6b60:	f94a2400 	ldr	x0, [x0, #5192]
    6b64:	b50000a0 	cbnz	x0, 6b78 <fwp_drop10+0x1b8>
    6b68:	14000013 	b	6bb4 <fwp_drop10+0x1f4>
    6b6c:	91004002 	add	x2, x0, #0x10
    6b70:	f9400800 	ldr	x0, [x0, #16]
    6b74:	b4000200 	cbz	x0, 6bb4 <fwp_drop10+0x1f4>
    6b78:	f9400001 	ldr	x1, [x0]
    6b7c:	eb14003f 	cmp	x1, x20
    6b80:	54ffff61 	b.ne	6b6c <fwp_drop10+0x1ac>  // b.any
    6b84:	f9400041 	ldr	x1, [x2]
    6b88:	f9400420 	ldr	x0, [x1, #8]
    6b8c:	d1000400 	sub	x0, x0, #0x1
    6b90:	f9000420 	str	x0, [x1, #8]
    6b94:	f103f81f 	cmp	x0, #0xfe
    6b98:	54fff601 	b.ne	6a58 <fwp_drop10+0x98>  // b.any
    6b9c:	39400280 	ldrb	w0, [x20]
    6ba0:	7103fc1f 	cmp	w0, #0xff
    6ba4:	540000e0 	b.eq	6bc0 <fwp_drop10+0x200>  // b.none
    6ba8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6bac:	39000280 	strb	w0, [x20]
    6bb0:	17ffffaa 	b	6a58 <fwp_drop10+0x98>
    6bb4:	f0000020 	adrp	x0, d000 <atexit+0x10>
    6bb8:	91058000 	add	x0, x0, #0x160
    6bbc:	97fff4b5 	bl	3e90 <fwp_trap>
    6bc0:	aa1403e0 	mov	x0, x20
    6bc4:	97fff4d3 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6bc8:	17fffff8 	b	6ba8 <fwp_drop10+0x1e8>
    6bcc:	d503201f 	nop

0000000000006bd0 <fwp_caps173>:
    6bd0:	34000041 	cbz	w1, 6bd8 <fwp_caps173+0x8>
    6bd4:	d65f03c0 	ret
    6bd8:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xca0>
    6bdc:	91150063 	add	x3, x3, #0x540
    6be0:	f949d861 	ldr	x1, [x3, #5040]
    6be4:	f949ec62 	ldr	x2, [x3, #5080]
    6be8:	cb010001 	sub	x1, x0, x1
    6bec:	eb02403f 	cmp	x1, x2, lsl #16
    6bf0:	54ffff22 	b.cs	6bd4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6bf4:	d350fc22 	lsr	x2, x1, #16
    6bf8:	f949fc65 	ldr	x5, [x3, #5112]
    6bfc:	8b020842 	add	x2, x2, x2, lsl #2
    6c00:	d37df042 	lsl	x2, x2, #3
    6c04:	8b0200a4 	add	x4, x5, x2
    6c08:	f9401083 	ldr	x3, [x4, #32]
    6c0c:	b4fffe43 	cbz	x3, 6bd4 <fwp_caps173+0x4>
    6c10:	386268a2 	ldrb	w2, [x5, x2]
    6c14:	7100085f 	cmp	w2, #0x2
    6c18:	540001c0 	b.eq	6c50 <fwp_caps173+0x80>  // b.none
    6c1c:	7100045f 	cmp	w2, #0x1
    6c20:	54fffda1 	b.ne	6bd4 <fwp_caps173+0x4>  // b.any
    6c24:	29430885 	ldp	w5, w2, [x4, #24]
    6c28:	92403c21 	and	x1, x1, #0xffff
    6c2c:	9b057c21 	mul	x1, x1, x5
    6c30:	d360fc21 	lsr	x1, x1, #32
    6c34:	eb02003f 	cmp	x1, x2
    6c38:	54fffce2 	b.cs	6bd4 <fwp_caps173+0x4>  // b.hs, b.nlast
    6c3c:	8b010063 	add	x3, x3, x1
    6c40:	39400061 	ldrb	w1, [x3]
    6c44:	7100043f 	cmp	w1, #0x1
    6c48:	54fffc61 	b.ne	6bd4 <fwp_caps173+0x4>  // b.any
    6c4c:	17fff54d 	b	4180 <fwp_mem_free>
    6c50:	72003c3f 	tst	w1, #0xffff
    6c54:	54ffff60 	b.eq	6c40 <fwp_caps173+0x70>  // b.none
    6c58:	d65f03c0 	ret
    6c5c:	d503201f 	nop

0000000000006c60 <fwp_args37>:
    6c60:	7100003f 	cmp	w1, #0x0
    6c64:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6c68:	54000041 	b.ne	6c70 <fwp_args37+0x10>  // b.any
    6c6c:	d65f03c0 	ret
    6c70:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6c74:	91150042 	add	x2, x2, #0x540
    6c78:	f9400001 	ldr	x1, [x0]
    6c7c:	f949d843 	ldr	x3, [x2, #5040]
    6c80:	f949ec40 	ldr	x0, [x2, #5080]
    6c84:	cb030021 	sub	x1, x1, x3
    6c88:	eb00403f 	cmp	x1, x0, lsl #16
    6c8c:	54ffff02 	b.cs	6c6c <fwp_args37+0xc>  // b.hs, b.nlast
    6c90:	d350fc20 	lsr	x0, x1, #16
    6c94:	f949fc44 	ldr	x4, [x2, #5112]
    6c98:	8b000800 	add	x0, x0, x0, lsl #2
    6c9c:	d37df002 	lsl	x2, x0, #3
    6ca0:	8b020083 	add	x3, x4, x2
    6ca4:	f9401060 	ldr	x0, [x3, #32]
    6ca8:	b4fffe20 	cbz	x0, 6c6c <fwp_args37+0xc>
    6cac:	38626882 	ldrb	w2, [x4, x2]
    6cb0:	7100085f 	cmp	w2, #0x2
    6cb4:	54000220 	b.eq	6cf8 <fwp_args37+0x98>  // b.none
    6cb8:	7100045f 	cmp	w2, #0x1
    6cbc:	54fffd81 	b.ne	6c6c <fwp_args37+0xc>  // b.any
    6cc0:	29430864 	ldp	w4, w2, [x3, #24]
    6cc4:	92403c21 	and	x1, x1, #0xffff
    6cc8:	9b047c21 	mul	x1, x1, x4
    6ccc:	d360fc21 	lsr	x1, x1, #32
    6cd0:	eb02003f 	cmp	x1, x2
    6cd4:	54fffcc2 	b.cs	6c6c <fwp_args37+0xc>  // b.hs, b.nlast
    6cd8:	8b010000 	add	x0, x0, x1
    6cdc:	39400001 	ldrb	w1, [x0]
    6ce0:	34fffc61 	cbz	w1, 6c6c <fwp_args37+0xc>
    6ce4:	7103f43f 	cmp	w1, #0xfd
    6ce8:	540000e8 	b.hi	6d04 <fwp_args37+0xa4>  // b.pmore
    6cec:	11000421 	add	w1, w1, #0x1
    6cf0:	39000001 	strb	w1, [x0]
    6cf4:	d65f03c0 	ret
    6cf8:	72003c3f 	tst	w1, #0xffff
    6cfc:	54ffff00 	b.eq	6cdc <fwp_args37+0x7c>  // b.none
    6d00:	d65f03c0 	ret
    6d04:	17fff598 	b	4364 <fwp_rc_wide_dup>
    6d08:	d503201f 	nop
    6d0c:	d503201f 	nop

0000000000006d10 <fwp_caps37>:
    6d10:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6d14:	910003fd 	mov	x29, sp
    6d18:	f9000bf3 	str	x19, [sp, #16]
    6d1c:	aa0003f3 	mov	x19, x0
    6d20:	b9400400 	ldr	w0, [x0, #4]
    6d24:	340004a0 	cbz	w0, 6db8 <fwp_caps37+0xa8>
    6d28:	f9400660 	ldr	x0, [x19, #8]
    6d2c:	350004e1 	cbnz	w1, 6dc8 <fwp_caps37+0xb8>
    6d30:	97fffd68 	bl	62d0 <fwp_drop4>
    6d34:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6d38:	91150042 	add	x2, x2, #0x540
    6d3c:	f949d840 	ldr	x0, [x2, #5040]
    6d40:	f949ec41 	ldr	x1, [x2, #5080]
    6d44:	cb000260 	sub	x0, x19, x0
    6d48:	eb01401f 	cmp	x0, x1, lsl #16
    6d4c:	54000382 	b.cs	6dbc <fwp_caps37+0xac>  // b.hs, b.nlast
    6d50:	d350fc01 	lsr	x1, x0, #16
    6d54:	f949fc44 	ldr	x4, [x2, #5112]
    6d58:	8b010821 	add	x1, x1, x1, lsl #2
    6d5c:	d37df021 	lsl	x1, x1, #3
    6d60:	8b010083 	add	x3, x4, x1
    6d64:	f9401062 	ldr	x2, [x3, #32]
    6d68:	b40002a2 	cbz	x2, 6dbc <fwp_caps37+0xac>
    6d6c:	38616881 	ldrb	w1, [x4, x1]
    6d70:	7100083f 	cmp	w1, #0x2
    6d74:	540006c0 	b.eq	6e4c <fwp_caps37+0x13c>  // b.none
    6d78:	7100043f 	cmp	w1, #0x1
    6d7c:	54000201 	b.ne	6dbc <fwp_caps37+0xac>  // b.any
    6d80:	29430464 	ldp	w4, w1, [x3, #24]
    6d84:	92403c00 	and	x0, x0, #0xffff
    6d88:	9b047c00 	mul	x0, x0, x4
    6d8c:	d360fc00 	lsr	x0, x0, #32
    6d90:	eb01001f 	cmp	x0, x1
    6d94:	54000142 	b.cs	6dbc <fwp_caps37+0xac>  // b.hs, b.nlast
    6d98:	8b000042 	add	x2, x2, x0
    6d9c:	39400040 	ldrb	w0, [x2]
    6da0:	7100041f 	cmp	w0, #0x1
    6da4:	540000c1 	b.ne	6dbc <fwp_caps37+0xac>  // b.any
    6da8:	aa1303e0 	mov	x0, x19
    6dac:	f9400bf3 	ldr	x19, [sp, #16]
    6db0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6db4:	17fff4f3 	b	4180 <fwp_mem_free>
    6db8:	34fffbe1 	cbz	w1, 6d34 <fwp_caps37+0x24>
    6dbc:	f9400bf3 	ldr	x19, [sp, #16]
    6dc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6dc4:	d65f03c0 	ret
    6dc8:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xca0>
    6dcc:	91150042 	add	x2, x2, #0x540
    6dd0:	f949d843 	ldr	x3, [x2, #5040]
    6dd4:	f949ec41 	ldr	x1, [x2, #5080]
    6dd8:	cb030000 	sub	x0, x0, x3
    6ddc:	eb01401f 	cmp	x0, x1, lsl #16
    6de0:	54fffee2 	b.cs	6dbc <fwp_caps37+0xac>  // b.hs, b.nlast
    6de4:	d350fc01 	lsr	x1, x0, #16
    6de8:	f949fc44 	ldr	x4, [x2, #5112]
    6dec:	8b010821 	add	x1, x1, x1, lsl #2
    6df0:	d37df021 	lsl	x1, x1, #3
    6df4:	8b010083 	add	x3, x4, x1
    6df8:	f9401062 	ldr	x2, [x3, #32]
    6dfc:	b4fffe02 	cbz	x2, 6dbc <fwp_caps37+0xac>
    6e00:	38616881 	ldrb	w1, [x4, x1]
    6e04:	7100083f 	cmp	w1, #0x2
    6e08:	54000280 	b.eq	6e58 <fwp_caps37+0x148>  // b.none
    6e0c:	7100043f 	cmp	w1, #0x1
    6e10:	54fffd61 	b.ne	6dbc <fwp_caps37+0xac>  // b.any
    6e14:	92403c01 	and	x1, x0, #0xffff
    6e18:	29430064 	ldp	w4, w0, [x3, #24]
    6e1c:	9b047c21 	mul	x1, x1, x4
    6e20:	d360fc21 	lsr	x1, x1, #32
    6e24:	eb00003f 	cmp	x1, x0
    6e28:	54fffca2 	b.cs	6dbc <fwp_caps37+0xac>  // b.hs, b.nlast
    6e2c:	8b010042 	add	x2, x2, x1
    6e30:	39400040 	ldrb	w0, [x2]
    6e34:	34fffc40 	cbz	w0, 6dbc <fwp_caps37+0xac>
    6e38:	7103f41f 	cmp	w0, #0xfd
    6e3c:	54000148 	b.hi	6e64 <fwp_caps37+0x154>  // b.pmore
    6e40:	11000400 	add	w0, w0, #0x1
    6e44:	39000040 	strb	w0, [x2]
    6e48:	17ffffdd 	b	6dbc <fwp_caps37+0xac>
    6e4c:	72003c1f 	tst	w0, #0xffff
    6e50:	54fffb61 	b.ne	6dbc <fwp_caps37+0xac>  // b.any
    6e54:	17ffffd2 	b	6d9c <fwp_caps37+0x8c>
    6e58:	72003c1f 	tst	w0, #0xffff
    6e5c:	54fffb01 	b.ne	6dbc <fwp_caps37+0xac>  // b.any
    6e60:	17fffff4 	b	6e30 <fwp_caps37+0x120>
    6e64:	f9400bf3 	ldr	x19, [sp, #16]
    6e68:	aa0203e0 	mov	x0, x2
    6e6c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6e70:	17fff53d 	b	4364 <fwp_rc_wide_dup>

0000000000006e74 <f37>:
    6e74:	d10203ff 	sub	sp, sp, #0x80
    6e78:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6e7c:	f947f421 	ldr	x1, [x1, #4072]
    6e80:	a9027bfd 	stp	x29, x30, [sp, #32]
    6e84:	910083fd 	add	x29, sp, #0x20
    6e88:	a9045bf5 	stp	x21, x22, [sp, #64]
    6e8c:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xca0>
    6e90:	911502a3 	add	x3, x21, #0x540
    6e94:	a90353f3 	stp	x19, x20, [sp, #48]
    6e98:	aa0003f6 	mov	x22, x0
    6e9c:	a90563f7 	stp	x23, x24, [sp, #80]
    6ea0:	a9066bf9 	stp	x25, x26, [sp, #96]
    6ea4:	f949ec62 	ldr	x2, [x3, #5080]
    6ea8:	f9400024 	ldr	x4, [x1]
    6eac:	f9000fe4 	str	x4, [sp, #24]
    6eb0:	d2800004 	mov	x4, #0x0                   	// #0
    6eb4:	f949d861 	ldr	x1, [x3, #5040]
    6eb8:	d370bc42 	lsl	x2, x2, #16
    6ebc:	b4001800 	cbz	x0, 71bc <f37+0x348>
    6ec0:	f9400817 	ldr	x23, [x0, #16]
    6ec4:	cb0102e1 	sub	x1, x23, x1
    6ec8:	eb02003f 	cmp	x1, x2
    6ecc:	54000362 	b.cs	6f38 <f37+0xc4>  // b.hs, b.nlast
    6ed0:	f949fc60 	ldr	x0, [x3, #5112]
    6ed4:	d350fc22 	lsr	x2, x1, #16
    6ed8:	8b020842 	add	x2, x2, x2, lsl #2
    6edc:	8b020c02 	add	x2, x0, x2, lsl #3
    6ee0:	f9401040 	ldr	x0, [x2, #32]
    6ee4:	b40002a0 	cbz	x0, 6f38 <f37+0xc4>
    6ee8:	39400043 	ldrb	w3, [x2]
    6eec:	7100087f 	cmp	w3, #0x2
    6ef0:	54001540 	b.eq	7198 <f37+0x324>  // b.none
    6ef4:	7100047f 	cmp	w3, #0x1
    6ef8:	540001c1 	b.ne	6f30 <f37+0xbc>  // b.any
    6efc:	29430843 	ldp	w3, w2, [x2, #24]
    6f00:	92403c21 	and	x1, x1, #0xffff
    6f04:	9b037c21 	mul	x1, x1, x3
    6f08:	d360fc21 	lsr	x1, x1, #32
    6f0c:	eb02003f 	cmp	x1, x2
    6f10:	54000102 	b.cs	6f30 <f37+0xbc>  // b.hs, b.nlast
    6f14:	8b010000 	add	x0, x0, x1
    6f18:	39400001 	ldrb	w1, [x0]
    6f1c:	340000a1 	cbz	w1, 6f30 <f37+0xbc>
    6f20:	7103f43f 	cmp	w1, #0xfd
    6f24:	540017e8 	b.hi	7220 <f37+0x3ac>  // b.pmore
    6f28:	11000421 	add	w1, w1, #0x1
    6f2c:	39000001 	strb	w1, [x0]
    6f30:	d2800002 	mov	x2, #0x0                   	// #0
    6f34:	b40000d6 	cbz	x22, 6f4c <f37+0xd8>
    6f38:	aa1603e1 	mov	x1, x22
    6f3c:	d2800002 	mov	x2, #0x0                   	// #0
    6f40:	f9400821 	ldr	x1, [x1, #16]
    6f44:	91000442 	add	x2, x2, #0x1
    6f48:	b5ffffc1 	cbnz	x1, 6f40 <f37+0xcc>
    6f4c:	b40013f7 	cbz	x23, 71c8 <f37+0x354>
    6f50:	aa1703e1 	mov	x1, x23
    6f54:	d2800003 	mov	x3, #0x0                   	// #0
    6f58:	f9400821 	ldr	x1, [x1, #16]
    6f5c:	91000463 	add	x3, x3, #0x1
    6f60:	b5ffffc1 	cbnz	x1, 6f58 <f37+0xe4>
    6f64:	eb02007f 	cmp	x3, x2
    6f68:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    6f6c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    6f70:	eb00027f 	cmp	x19, x0
    6f74:	540010a8 	b.hi	7188 <f37+0x314>  // b.pmore
    6f78:	d37ffa74 	lsl	x20, x19, #1
    6f7c:	52800041 	mov	w1, #0x2                   	// #2
    6f80:	91000680 	add	x0, x20, #0x1
    6f84:	d37df000 	lsl	x0, x0, #3
    6f88:	97fff73a 	bl	4c70 <fwp_heap_alloc>
    6f8c:	aa0003f8 	mov	x24, x0
    6f90:	911502a1 	add	x1, x21, #0x540
    6f94:	aa0103e0 	mov	x0, x1
    6f98:	f9000314 	str	x20, [x24]
    6f9c:	f949d821 	ldr	x1, [x1, #5040]
    6fa0:	f949ec00 	ldr	x0, [x0, #5080]
    6fa4:	cb010301 	sub	x1, x24, x1
    6fa8:	eb00403f 	cmp	x1, x0, lsl #16
    6fac:	54000342 	b.cs	7014 <f37+0x1a0>  // b.hs, b.nlast
    6fb0:	911502a2 	add	x2, x21, #0x540
    6fb4:	d350fc20 	lsr	x0, x1, #16
    6fb8:	8b000800 	add	x0, x0, x0, lsl #2
    6fbc:	f949fc43 	ldr	x3, [x2, #5112]
    6fc0:	d37df002 	lsl	x2, x0, #3
    6fc4:	8b020060 	add	x0, x3, x2
    6fc8:	f9401014 	ldr	x20, [x0, #32]
    6fcc:	b4000254 	cbz	x20, 7014 <f37+0x1a0>
    6fd0:	38626862 	ldrb	w2, [x3, x2]
    6fd4:	7100085f 	cmp	w2, #0x2
    6fd8:	54000ec0 	b.eq	71b0 <f37+0x33c>  // b.none
    6fdc:	7100045f 	cmp	w2, #0x1
    6fe0:	540001a1 	b.ne	7014 <f37+0x1a0>  // b.any
    6fe4:	29430002 	ldp	w2, w0, [x0, #24]
    6fe8:	92403c21 	and	x1, x1, #0xffff
    6fec:	9b027c21 	mul	x1, x1, x2
    6ff0:	d360fc21 	lsr	x1, x1, #32
    6ff4:	eb00003f 	cmp	x1, x0
    6ff8:	540000e2 	b.cs	7014 <f37+0x1a0>  // b.hs, b.nlast
    6ffc:	8b010294 	add	x20, x20, x1
    7000:	39400280 	ldrb	w0, [x20]
    7004:	7103fc1f 	cmp	w0, #0xff
    7008:	54001100 	b.eq	7228 <f37+0x3b4>  // b.none
    700c:	52800020 	mov	w0, #0x1                   	// #1
    7010:	39000280 	strb	w0, [x20]
    7014:	b4000253 	cbz	x19, 705c <f37+0x1e8>
    7018:	8b131313 	add	x19, x24, x19, lsl #4
    701c:	aa1803f4 	mov	x20, x24
    7020:	aa1603fa 	mov	x26, x22
    7024:	aa1703f9 	mov	x25, x23
    7028:	f9400723 	ldr	x3, [x25, #8]
    702c:	f9400742 	ldr	x2, [x26, #8]
    7030:	f9400861 	ldr	x1, [x3, #16]
    7034:	f9400840 	ldr	x0, [x2, #16]
    7038:	fd400461 	ldr	d1, [x3, #8]
    703c:	fd400440 	ldr	d0, [x2, #8]
    7040:	97fff879 	bl	5224 <w120>
    7044:	f9000680 	str	x0, [x20, #8]
    7048:	f8010e81 	str	x1, [x20, #16]!
    704c:	f9400b39 	ldr	x25, [x25, #16]
    7050:	f9400b5a 	ldr	x26, [x26, #16]
    7054:	eb14027f 	cmp	x19, x20
    7058:	54fffe81 	b.ne	7028 <f37+0x1b4>  // b.any
    705c:	aa1703e0 	mov	x0, x23
    7060:	97fffc9c 	bl	62d0 <fwp_drop4>
    7064:	aa1603e0 	mov	x0, x22
    7068:	97fffc9a 	bl	62d0 <fwp_drop4>
    706c:	f9400316 	ldr	x22, [x24]
    7070:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    7074:	b4000236 	cbz	x22, 70b8 <f37+0x244>
    7078:	fd003be8 	str	d8, [sp, #112]
    707c:	2f00e408 	movi	d8, #0x0
    7080:	91002319 	add	x25, x24, #0x8
    7084:	91004317 	add	x23, x24, #0x10
    7088:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    708c:	d2800013 	mov	x19, #0x0                   	// #0
    7090:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    7094:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    7098:	91000a73 	add	x19, x19, #0x2
    709c:	1e602908 	fadd	d8, d8, d0
    70a0:	97fff810 	bl	50e0 <f141.constprop.0>
    70a4:	aa0003f4 	mov	x20, x0
    70a8:	eb1302df 	cmp	x22, x19
    70ac:	54ffff28 	b.hi	7090 <f37+0x21c>  // b.pmore
    70b0:	9e660116 	fmov	x22, d8
    70b4:	fd403be8 	ldr	d8, [sp, #112]
    70b8:	911502b5 	add	x21, x21, #0x540
    70bc:	aa1803e0 	mov	x0, x24
    70c0:	97fffe40 	bl	69c0 <fwp_drop10>
    70c4:	a900d3f6 	stp	x22, x20, [sp, #8]
    70c8:	910023e1 	add	x1, sp, #0x8
    70cc:	52800000 	mov	w0, #0x0                   	// #0
    70d0:	97fff72d 	bl	4d84 <fwp_data.part.0.constprop.0>
    70d4:	f949daa1 	ldr	x1, [x21, #5040]
    70d8:	aa0003f3 	mov	x19, x0
    70dc:	f949eea0 	ldr	x0, [x21, #5080]
    70e0:	cb010261 	sub	x1, x19, x1
    70e4:	eb00403f 	cmp	x1, x0, lsl #16
    70e8:	54000322 	b.cs	714c <f37+0x2d8>  // b.hs, b.nlast
    70ec:	d350fc22 	lsr	x2, x1, #16
    70f0:	f949fea3 	ldr	x3, [x21, #5112]
    70f4:	8b020842 	add	x2, x2, x2, lsl #2
    70f8:	d37df042 	lsl	x2, x2, #3
    70fc:	8b020060 	add	x0, x3, x2
    7100:	f9401014 	ldr	x20, [x0, #32]
    7104:	b4000254 	cbz	x20, 714c <f37+0x2d8>
    7108:	38626862 	ldrb	w2, [x3, x2]
    710c:	7100085f 	cmp	w2, #0x2
    7110:	540004a0 	b.eq	71a4 <f37+0x330>  // b.none
    7114:	7100045f 	cmp	w2, #0x1
    7118:	540001a1 	b.ne	714c <f37+0x2d8>  // b.any
    711c:	29430002 	ldp	w2, w0, [x0, #24]
    7120:	92403c21 	and	x1, x1, #0xffff
    7124:	9b027c21 	mul	x1, x1, x2
    7128:	d360fc21 	lsr	x1, x1, #32
    712c:	eb00003f 	cmp	x1, x0
    7130:	540000e2 	b.cs	714c <f37+0x2d8>  // b.hs, b.nlast
    7134:	8b010294 	add	x20, x20, x1
    7138:	39400280 	ldrb	w0, [x20]
    713c:	7103fc1f 	cmp	w0, #0xff
    7140:	540007a0 	b.eq	7234 <f37+0x3c0>  // b.none
    7144:	52800020 	mov	w0, #0x1                   	// #1
    7148:	39000280 	strb	w0, [x20]
    714c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7150:	f947f400 	ldr	x0, [x0, #4072]
    7154:	f9400fe2 	ldr	x2, [sp, #24]
    7158:	f9400001 	ldr	x1, [x0]
    715c:	eb010042 	subs	x2, x2, x1
    7160:	d2800001 	mov	x1, #0x0                   	// #0
    7164:	54000721 	b.ne	7248 <f37+0x3d4>  // b.any
    7168:	a9427bfd 	ldp	x29, x30, [sp, #32]
    716c:	aa1303e0 	mov	x0, x19
    7170:	a94353f3 	ldp	x19, x20, [sp, #48]
    7174:	a9445bf5 	ldp	x21, x22, [sp, #64]
    7178:	a94563f7 	ldp	x23, x24, [sp, #80]
    717c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    7180:	910203ff 	add	sp, sp, #0x80
    7184:	d65f03c0 	ret
    7188:	d0000020 	adrp	x0, d000 <atexit+0x10>
    718c:	91102000 	add	x0, x0, #0x408
    7190:	fd003be8 	str	d8, [sp, #112]
    7194:	97fff33f 	bl	3e90 <fwp_trap>
    7198:	72003c3f 	tst	w1, #0xffff
    719c:	54ffeca1 	b.ne	6f30 <f37+0xbc>  // b.any
    71a0:	17ffff5e 	b	6f18 <f37+0xa4>
    71a4:	72003c3f 	tst	w1, #0xffff
    71a8:	54fffd21 	b.ne	714c <f37+0x2d8>  // b.any
    71ac:	17ffffe3 	b	7138 <f37+0x2c4>
    71b0:	72003c3f 	tst	w1, #0xffff
    71b4:	54fff301 	b.ne	7014 <f37+0x1a0>  // b.any
    71b8:	17ffff92 	b	7000 <f37+0x18c>
    71bc:	cb0103e1 	neg	x1, x1
    71c0:	eb02003f 	cmp	x1, x2
    71c4:	540001e3 	b.cc	7200 <f37+0x38c>  // b.lo, b.ul, b.last
    71c8:	52800041 	mov	w1, #0x2                   	// #2
    71cc:	d2800100 	mov	x0, #0x8                   	// #8
    71d0:	97fff6a8 	bl	4c70 <fwp_heap_alloc>
    71d4:	aa0003f8 	mov	x24, x0
    71d8:	911502a0 	add	x0, x21, #0x540
    71dc:	f900031f 	str	xzr, [x24]
    71e0:	f949d801 	ldr	x1, [x0, #5040]
    71e4:	f949ec00 	ldr	x0, [x0, #5080]
    71e8:	cb010301 	sub	x1, x24, x1
    71ec:	eb00403f 	cmp	x1, x0, lsl #16
    71f0:	54000282 	b.cs	7240 <f37+0x3cc>  // b.hs, b.nlast
    71f4:	d2800013 	mov	x19, #0x0                   	// #0
    71f8:	d2800017 	mov	x23, #0x0                   	// #0
    71fc:	17ffff6d 	b	6fb0 <f37+0x13c>
    7200:	f949fc62 	ldr	x2, [x3, #5112]
    7204:	d350fc20 	lsr	x0, x1, #16
    7208:	8b000800 	add	x0, x0, x0, lsl #2
    720c:	8b000c42 	add	x2, x2, x0, lsl #3
    7210:	f9401040 	ldr	x0, [x2, #32]
    7214:	b4fffda0 	cbz	x0, 71c8 <f37+0x354>
    7218:	d2800017 	mov	x23, #0x0                   	// #0
    721c:	17ffff33 	b	6ee8 <f37+0x74>
    7220:	97fff451 	bl	4364 <fwp_rc_wide_dup>
    7224:	17ffff43 	b	6f30 <f37+0xbc>
    7228:	aa1403e0 	mov	x0, x20
    722c:	97fff339 	bl	3f10 <fwp_rc_forget_slot.part.0>
    7230:	17ffff77 	b	700c <f37+0x198>
    7234:	aa1403e0 	mov	x0, x20
    7238:	97fff336 	bl	3f10 <fwp_rc_forget_slot.part.0>
    723c:	17ffffc2 	b	7144 <f37+0x2d0>
    7240:	d2800017 	mov	x23, #0x0                   	// #0
    7244:	17ffff86 	b	705c <f37+0x1e8>
    7248:	fd003be8 	str	d8, [sp, #112]
    724c:	97ffed8d 	bl	2880 <__stack_chk_fail@plt>

0000000000007250 <fwp_owned_entry37>:
    7250:	f9400000 	ldr	x0, [x0]
    7254:	17ffff08 	b	6e74 <f37>
    7258:	d503201f 	nop
    725c:	d503201f 	nop

0000000000007260 <e37>:
    7260:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7264:	910003fd 	mov	x29, sp
    7268:	f9000bf3 	str	x19, [sp, #16]
    726c:	f9400013 	ldr	x19, [x0]
    7270:	aa1303e0 	mov	x0, x19
    7274:	97fff8ff 	bl	5670 <fwp_rc_share>
    7278:	aa1303e0 	mov	x0, x19
    727c:	97fffefe 	bl	6e74 <f37>
    7280:	aa0003f3 	mov	x19, x0
    7284:	97fff8fb 	bl	5670 <fwp_rc_share>
    7288:	aa1303e0 	mov	x0, x19
    728c:	f9400bf3 	ldr	x19, [sp, #16]
    7290:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7294:	d65f03c0 	ret
    7298:	d503201f 	nop
    729c:	d503201f 	nop

00000000000072a0 <fwp_write>:
    72a0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    72a4:	910003fd 	mov	x29, sp
    72a8:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    72ac:	f947f484 	ldr	x4, [x4, #4072]
    72b0:	a90153f3 	stp	x19, x20, [sp, #16]
    72b4:	d10943ff 	sub	sp, sp, #0x250
    72b8:	b9400045 	ldr	w5, [x2]
    72bc:	aa0003f4 	mov	x20, x0
    72c0:	f9400080 	ldr	x0, [x4]
    72c4:	f90127e0 	str	x0, [sp, #584]
    72c8:	d2800000 	mov	x0, #0x0                   	// #0
    72cc:	710064bf 	cmp	w5, #0x19
    72d0:	54000408 	b.hi	7350 <fwp_write+0xb0>  // b.pmore
    72d4:	d0000020 	adrp	x0, d000 <atexit+0x10>
    72d8:	aa0103f3 	mov	x19, x1
    72dc:	9131c000 	add	x0, x0, #0xc70
    72e0:	f9013bf5 	str	x21, [sp, #624]
    72e4:	f9013ff6 	str	x22, [sp, #632]
    72e8:	f90153fb 	str	x27, [sp, #672]
    72ec:	f90157fc 	str	x28, [sp, #680]
    72f0:	aa0203fc 	mov	x28, x2
    72f4:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    72f8:	10000061 	adr	x1, 7304 <fwp_write+0x64>
    72fc:	8b20a820 	add	x0, x1, w0, sxth #2
    7300:	d61f0000 	br	x0
    7304:	910123e0 	add	x0, sp, #0x48
    7308:	aa1303e5 	mov	x5, x19
    730c:	d0000024 	adrp	x4, d000 <atexit+0x10>
    7310:	aa0003f3 	mov	x19, x0
    7314:	91114084 	add	x4, x4, #0x450
    7318:	d2804003 	mov	x3, #0x200                 	// #512
    731c:	aa0303e1 	mov	x1, x3
    7320:	52800042 	mov	w2, #0x2                   	// #2
    7324:	97ffed33 	bl	27f0 <__snprintf_chk@plt>
    7328:	aa1303e0 	mov	x0, x19
    732c:	97ffecf9 	bl	2710 <strlen@plt>
    7330:	aa1303e1 	mov	x1, x19
    7334:	aa0003e2 	mov	x2, x0
    7338:	aa1403e0 	mov	x0, x20
    733c:	97fff035 	bl	3410 <buf_put>
    7340:	f9413bf5 	ldr	x21, [sp, #624]
    7344:	f9413ff6 	ldr	x22, [sp, #632]
    7348:	f94153fb 	ldr	x27, [sp, #672]
    734c:	f94157fc 	ldr	x28, [sp, #680]
    7350:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7354:	f947f400 	ldr	x0, [x0, #4072]
    7358:	f94127e2 	ldr	x2, [sp, #584]
    735c:	f9400001 	ldr	x1, [x0]
    7360:	eb010042 	subs	x2, x2, x1
    7364:	d2800001 	mov	x1, #0x0                   	// #0
    7368:	540077c1 	b.ne	8260 <fwp_write+0xfc0>  // b.any
    736c:	910943ff 	add	sp, sp, #0x250
    7370:	a94153f3 	ldp	x19, x20, [sp, #16]
    7374:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7378:	d65f03c0 	ret
    737c:	910123e0 	add	x0, sp, #0x48
    7380:	aa1303e5 	mov	x5, x19
    7384:	d0000024 	adrp	x4, d000 <atexit+0x10>
    7388:	aa0003f3 	mov	x19, x0
    738c:	91112084 	add	x4, x4, #0x448
    7390:	d2804003 	mov	x3, #0x200                 	// #512
    7394:	17ffffe2 	b	731c <fwp_write+0x7c>
    7398:	71004cbf 	cmp	w5, #0x13
    739c:	d0000020 	adrp	x0, d000 <atexit+0x10>
    73a0:	d0000021 	adrp	x1, d000 <atexit+0x10>
    73a4:	9110e000 	add	x0, x0, #0x438
    73a8:	91110021 	add	x1, x1, #0x440
    73ac:	d2800082 	mov	x2, #0x4                   	// #4
    73b0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    73b4:	aa1403e0 	mov	x0, x20
    73b8:	f90143f7 	str	x23, [sp, #640]
    73bc:	d2800016 	mov	x22, #0x0                   	// #0
    73c0:	f90147f8 	str	x24, [sp, #648]
    73c4:	97fff013 	bl	3410 <buf_put>
    73c8:	f9400260 	ldr	x0, [x19]
    73cc:	d0000037 	adrp	x23, d000 <atexit+0x10>
    73d0:	d2800015 	mov	x21, #0x0                   	// #0
    73d4:	911302f7 	add	x23, x23, #0x4c0
    73d8:	b40047a0 	cbz	x0, 7ccc <fwp_write+0xa2c>
    73dc:	b9400380 	ldr	w0, [x28]
    73e0:	52800003 	mov	w3, #0x0                   	// #0
    73e4:	f9401f82 	ldr	x2, [x28, #56]
    73e8:	71004c1f 	cmp	w0, #0x13
    73ec:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    73f0:	aa1403e0 	mov	x0, x20
    73f4:	8b010e61 	add	x1, x19, x1, lsl #3
    73f8:	f9400421 	ldr	x1, [x1, #8]
    73fc:	97ffffa9 	bl	72a0 <fwp_write>
    7400:	b9400380 	ldr	w0, [x28]
    7404:	7100481f 	cmp	w0, #0x12
    7408:	54004b40 	b.eq	7d70 <fwp_write+0xad0>  // b.none
    740c:	f9400260 	ldr	x0, [x19]
    7410:	910006b5 	add	x21, x21, #0x1
    7414:	91000ad6 	add	x22, x22, #0x2
    7418:	eb15001f 	cmp	x0, x21
    741c:	54004589 	b.ls	7ccc <fwp_write+0xa2c>  // b.plast
    7420:	aa1703e1 	mov	x1, x23
    7424:	aa1403e0 	mov	x0, x20
    7428:	d2800042 	mov	x2, #0x2                   	// #2
    742c:	97ffeff9 	bl	3410 <buf_put>
    7430:	17ffffeb 	b	73dc <fwp_write+0x13c>
    7434:	d0000021 	adrp	x1, d000 <atexit+0x10>
    7438:	9111e021 	add	x1, x1, #0x478
    743c:	d28000c2 	mov	x2, #0x6                   	// #6
    7440:	aa1403e0 	mov	x0, x20
    7444:	91004273 	add	x19, x19, #0x10
    7448:	97ffeff2 	bl	3410 <buf_put>
    744c:	aa1303e0 	mov	x0, x19
    7450:	97ffecb0 	bl	2710 <strlen@plt>
    7454:	aa1303e1 	mov	x1, x19
    7458:	aa0003e2 	mov	x2, x0
    745c:	aa1403e0 	mov	x0, x20
    7460:	97ffefec 	bl	3410 <buf_put>
    7464:	528007c3 	mov	w3, #0x3e                  	// #62
    7468:	aa1403e0 	mov	x0, x20
    746c:	91001fe1 	add	x1, sp, #0x7
    7470:	d2800022 	mov	x2, #0x1                   	// #1
    7474:	39001fe3 	strb	w3, [sp, #7]
    7478:	17ffffb1 	b	733c <fwp_write+0x9c>
    747c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7480:	f947f400 	ldr	x0, [x0, #4072]
    7484:	f94127e2 	ldr	x2, [sp, #584]
    7488:	f9400001 	ldr	x1, [x0]
    748c:	eb010042 	subs	x2, x2, x1
    7490:	d2800001 	mov	x1, #0x0                   	// #0
    7494:	540034e1 	b.ne	7b30 <fwp_write+0x890>  // b.any
    7498:	f9413bf5 	ldr	x21, [sp, #624]
    749c:	d0000021 	adrp	x1, d000 <atexit+0x10>
    74a0:	f9413ff6 	ldr	x22, [sp, #632]
    74a4:	aa1403e0 	mov	x0, x20
    74a8:	91116021 	add	x1, x1, #0x458
    74ac:	d2800142 	mov	x2, #0xa                   	// #10
    74b0:	f94153fb 	ldr	x27, [sp, #672]
    74b4:	f94157fc 	ldr	x28, [sp, #680]
    74b8:	910943ff 	add	sp, sp, #0x250
    74bc:	a94153f3 	ldp	x19, x20, [sp, #16]
    74c0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    74c4:	17ffefd3 	b	3410 <buf_put>
    74c8:	f9400456 	ldr	x22, [x2, #8]
    74cc:	f90143f7 	str	x23, [sp, #640]
    74d0:	f90147f8 	str	x24, [sp, #648]
    74d4:	b4005b16 	cbz	x22, 8034 <fwp_write+0xd94>
    74d8:	aa1603e0 	mov	x0, x22
    74dc:	d0000021 	adrp	x1, d000 <atexit+0x10>
    74e0:	91136021 	add	x1, x1, #0x4d8
    74e4:	97ffed07 	bl	2900 <strcmp@plt>
    74e8:	2a0003f5 	mov	w21, w0
    74ec:	34005fe0 	cbz	w0, 80e8 <fwp_write+0xe48>
    74f0:	aa1603e0 	mov	x0, x22
    74f4:	97ffec87 	bl	2710 <strlen@plt>
    74f8:	aa1603e1 	mov	x1, x22
    74fc:	aa0003e2 	mov	x2, x0
    7500:	aa1403e0 	mov	x0, x20
    7504:	97ffefc3 	bl	3410 <buf_put>
    7508:	52800403 	mov	w3, #0x20                  	// #32
    750c:	91001ff5 	add	x21, sp, #0x7
    7510:	aa1503e1 	mov	x1, x21
    7514:	aa1403e0 	mov	x0, x20
    7518:	d2800022 	mov	x2, #0x1                   	// #1
    751c:	39001fe3 	strb	w3, [sp, #7]
    7520:	97ffefbc 	bl	3410 <buf_put>
    7524:	52800f63 	mov	w3, #0x7b                  	// #123
    7528:	aa1403e0 	mov	x0, x20
    752c:	aa1503e1 	mov	x1, x21
    7530:	d2800022 	mov	x2, #0x1                   	// #1
    7534:	39001fe3 	strb	w3, [sp, #7]
    7538:	97ffefb6 	bl	3410 <buf_put>
    753c:	b9401380 	ldr	w0, [x28, #16]
    7540:	52800018 	mov	w24, #0x0                   	// #0
    7544:	7100001f 	cmp	w0, #0x0
    7548:	54003aad 	b.le	7c9c <fwp_write+0x9fc>
    754c:	f9014bf9 	str	x25, [sp, #656]
    7550:	d0000039 	adrp	x25, d000 <atexit+0x10>
    7554:	91140339 	add	x25, x25, #0x500
    7558:	f9014ffa 	str	x26, [sp, #664]
    755c:	d000003a 	adrp	x26, d000 <atexit+0x10>
    7560:	9113035a 	add	x26, x26, #0x4c0
    7564:	91002276 	add	x22, x19, #0x8
    7568:	d2800013 	mov	x19, #0x0                   	// #0
    756c:	b5003e93 	cbnz	x19, 7d3c <fwp_write+0xa9c>
    7570:	d37df277 	lsl	x23, x19, #3
    7574:	34003cb8 	cbz	w24, 7d08 <fwp_write+0xa68>
    7578:	f9401382 	ldr	x2, [x28, #32]
    757c:	aa1403e0 	mov	x0, x20
    7580:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    7584:	52800003 	mov	w3, #0x0                   	// #0
    7588:	f8776842 	ldr	x2, [x2, x23]
    758c:	91000673 	add	x19, x19, #0x1
    7590:	97ffff44 	bl	72a0 <fwp_write>
    7594:	b9401380 	ldr	w0, [x28, #16]
    7598:	6b13001f 	cmp	w0, w19
    759c:	54fffe8c 	b.gt	756c <fwp_write+0x2cc>
    75a0:	f9414bf9 	ldr	x25, [sp, #656]
    75a4:	f9414ffa 	ldr	x26, [sp, #664]
    75a8:	340037b8 	cbz	w24, 7c9c <fwp_write+0x9fc>
    75ac:	52800523 	mov	w3, #0x29                  	// #41
    75b0:	aa1503e1 	mov	x1, x21
    75b4:	aa1403e0 	mov	x0, x20
    75b8:	d2800022 	mov	x2, #0x1                   	// #1
    75bc:	39001fe3 	strb	w3, [sp, #7]
    75c0:	97ffef94 	bl	3410 <buf_put>
    75c4:	f9413bf5 	ldr	x21, [sp, #624]
    75c8:	f9413ff6 	ldr	x22, [sp, #632]
    75cc:	f94143f7 	ldr	x23, [sp, #640]
    75d0:	f94147f8 	ldr	x24, [sp, #648]
    75d4:	f94153fb 	ldr	x27, [sp, #672]
    75d8:	f94157fc 	ldr	x28, [sp, #680]
    75dc:	17ffff5d 	b	7350 <fwp_write+0xb0>
    75e0:	b9404855 	ldr	w21, [x2, #72]
    75e4:	aa1403e0 	mov	x0, x20
    75e8:	93407eb6 	sxtw	x22, w21
    75ec:	91000ac1 	add	x1, x22, #0x2
    75f0:	97ffef55 	bl	3344 <buf_grow>
    75f4:	a9400281 	ldp	x1, x0, [x20]
    75f8:	528e8603 	mov	w3, #0x7430                	// #29744
    75fc:	78206823 	strh	w3, [x1, x0]
    7600:	8b000022 	add	x2, x1, x0
    7604:	710002bf 	cmp	w21, #0x0
    7608:	540036cd 	b.le	7ce0 <fwp_write+0xa40>
    760c:	110006a3 	add	w3, w21, #0x1
    7610:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7614:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    7618:	91000449 	add	x9, x2, #0x1
    761c:	8b23c043 	add	x3, x2, w3, sxtw
    7620:	f28aaac6 	movk	x6, #0x5556
    7624:	f2955568 	movk	x8, #0xaaab
    7628:	1400000d 	b	765c <fwp_write+0x3bc>
    762c:	d2800021 	mov	x1, #0x1                   	// #1
    7630:	528005a5 	mov	w5, #0x2d                  	// #45
    7634:	f100001f 	cmp	x0, #0x0
    7638:	9b467e60 	smulh	x0, x19, x6
    763c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7640:	381ff465 	strb	w5, [x3], #-1
    7644:	cb040000 	sub	x0, x0, x4
    7648:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    764c:	cb020000 	sub	x0, x0, x2
    7650:	8b010013 	add	x19, x0, x1
    7654:	eb03013f 	cmp	x9, x3
    7658:	54003440 	b.eq	7ce0 <fwp_write+0xa40>  // b.none
    765c:	9b467e60 	smulh	x0, x19, x6
    7660:	937ffe64 	asr	x4, x19, #63
    7664:	52800605 	mov	w5, #0x30                  	// #48
    7668:	cb040000 	sub	x0, x0, x4
    766c:	8b000400 	add	x0, x0, x0, lsl #1
    7670:	cb000260 	sub	x0, x19, x0
    7674:	91000c01 	add	x1, x0, #0x3
    7678:	9bc87c22 	umulh	x2, x1, x8
    767c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    7680:	8b4204e2 	add	x2, x7, x2, lsr #1
    7684:	eb020021 	subs	x1, x1, x2
    7688:	54fffd60 	b.eq	7634 <fwp_write+0x394>  // b.none
    768c:	f100043f 	cmp	x1, #0x1
    7690:	54fffce1 	b.ne	762c <fwp_write+0x38c>  // b.any
    7694:	d2800001 	mov	x1, #0x0                   	// #0
    7698:	52800565 	mov	w5, #0x2b                  	// #43
    769c:	17ffffe6 	b	7634 <fwp_write+0x394>
    76a0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    76a4:	f947f400 	ldr	x0, [x0, #4072]
    76a8:	f94127e2 	ldr	x2, [sp, #584]
    76ac:	f9400001 	ldr	x1, [x0]
    76b0:	eb010042 	subs	x2, x2, x1
    76b4:	d2800001 	mov	x1, #0x0                   	// #0
    76b8:	540023c1 	b.ne	7b30 <fwp_write+0x890>  // b.any
    76bc:	f9413bf5 	ldr	x21, [sp, #624]
    76c0:	d0000021 	adrp	x1, d000 <atexit+0x10>
    76c4:	f9413ff6 	ldr	x22, [sp, #632]
    76c8:	aa1403e0 	mov	x0, x20
    76cc:	9111a021 	add	x1, x1, #0x468
    76d0:	d2800102 	mov	x2, #0x8                   	// #8
    76d4:	17ffff77 	b	74b0 <fwp_write+0x210>
    76d8:	aa1403e0 	mov	x0, x20
    76dc:	d0000021 	adrp	x1, d000 <atexit+0x10>
    76e0:	d28000c2 	mov	x2, #0x6                   	// #6
    76e4:	91132021 	add	x1, x1, #0x4c8
    76e8:	97ffef4a 	bl	3410 <buf_put>
    76ec:	d2800015 	mov	x21, #0x0                   	// #0
    76f0:	f9400263 	ldr	x3, [x19]
    76f4:	f240f87f 	tst	x3, #0x7fffffffffffffff
    76f8:	54002c60 	b.eq	7c84 <fwp_write+0x9e4>  // b.none
    76fc:	f9401f82 	ldr	x2, [x28, #56]
    7700:	f90143f7 	str	x23, [sp, #640]
    7704:	f90147f8 	str	x24, [sp, #648]
    7708:	d2800857 	mov	x23, #0x42                  	// #66
    770c:	f9014bf9 	str	x25, [sp, #656]
    7710:	d0000036 	adrp	x22, d000 <atexit+0x10>
    7714:	f9014ffa 	str	x26, [sp, #664]
    7718:	911302d6 	add	x22, x22, #0x4c0
    771c:	d2800038 	mov	x24, #0x1                   	// #1
    7720:	f2a18017 	movk	x23, #0xc00, lsl #16
    7724:	d2809099 	mov	x25, #0x484                 	// #1156
    7728:	b40004a2 	cbz	x2, 77bc <fwp_write+0x51c>
    772c:	b9400040 	ldr	w0, [x2]
    7730:	7100701f 	cmp	w0, #0x1c
    7734:	540042c0 	b.eq	7f8c <fwp_write+0xcec>  // b.none
    7738:	71006c1f 	cmp	w0, #0x1b
    773c:	54000408 	b.hi	77bc <fwp_write+0x51c>  // b.pmore
    7740:	9ac02301 	lsl	x1, x24, x0
    7744:	ea17003f 	tst	x1, x23
    7748:	540036a1 	b.ne	7e1c <fwp_write+0xb7c>  // b.any
    774c:	ea19003f 	tst	x1, x25
    7750:	54003521 	b.ne	7df4 <fwp_write+0xb54>  // b.any
    7754:	d2800424 	mov	x4, #0x21                  	// #33
    7758:	ea04003f 	tst	x1, x4
    775c:	54000300 	b.eq	77bc <fwp_write+0x51c>  // b.none
    7760:	b7f849c3 	tbnz	x3, #63, 8098 <fwp_write+0xdf8>
    7764:	91002261 	add	x1, x19, #0x8
    7768:	8b150021 	add	x1, x1, x21
    776c:	39400021 	ldrb	w1, [x1]
    7770:	7100001f 	cmp	w0, #0x0
    7774:	93401c23 	sxtb	x3, w1
    7778:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    777c:	d503201f 	nop
    7780:	aa1403e0 	mov	x0, x20
    7784:	52800003 	mov	w3, #0x0                   	// #0
    7788:	97fffec6 	bl	72a0 <fwp_write>
    778c:	910006b5 	add	x21, x21, #0x1
    7790:	f9400260 	ldr	x0, [x19]
    7794:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    7798:	eb0002bf 	cmp	x21, x0
    779c:	540026c2 	b.cs	7c74 <fwp_write+0x9d4>  // b.hs, b.nlast
    77a0:	d2800042 	mov	x2, #0x2                   	// #2
    77a4:	aa1603e1 	mov	x1, x22
    77a8:	aa1403e0 	mov	x0, x20
    77ac:	97ffef19 	bl	3410 <buf_put>
    77b0:	f9401f82 	ldr	x2, [x28, #56]
    77b4:	f9400263 	ldr	x3, [x19]
    77b8:	b5fffba2 	cbnz	x2, 772c <fwp_write+0x48c>
    77bc:	d37df2a0 	lsl	x0, x21, #3
    77c0:	b7f83f03 	tbnz	x3, #63, 7fa0 <fwp_write+0xd00>
    77c4:	91002261 	add	x1, x19, #0x8
    77c8:	8b000020 	add	x0, x1, x0
    77cc:	f9400001 	ldr	x1, [x0]
    77d0:	17ffffec 	b	7780 <fwp_write+0x4e0>
    77d4:	a9400e62 	ldp	x2, x3, [x19]
    77d8:	b7f83ca3 	tbnz	x3, #63, 7f6c <fwp_write+0xccc>
    77dc:	910123f5 	add	x21, sp, #0x48
    77e0:	aa1503e0 	mov	x0, x21
    77e4:	97ffed8f 	bl	2e20 <fwp_fmt_u128>
    77e8:	aa1503e0 	mov	x0, x21
    77ec:	97ffebc9 	bl	2710 <strlen@plt>
    77f0:	aa1503e1 	mov	x1, x21
    77f4:	aa0003e2 	mov	x2, x0
    77f8:	17fffed0 	b	7338 <fwp_write+0x98>
    77fc:	fd015be8 	str	d8, [sp, #688]
    7800:	1e270268 	fmov	s8, w19
    7804:	fd015fe9 	str	d9, [sp, #696]
    7808:	1e282100 	fcmp	s8, s8
    780c:	54004d26 	b.vs	81b0 <fwp_write+0xf10>
    7810:	1e20c101 	fabs	s1, s8
    7814:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7818:	1e270000 	fmov	s0, w0
    781c:	1e202020 	fcmp	s1, s0
    7820:	54002c0d 	b.le	7da0 <fwp_write+0xb00>
    7824:	1e202118 	fcmpe	s8, #0.0
    7828:	d0000022 	adrp	x2, d000 <atexit+0x10>
    782c:	91010042 	add	x2, x2, #0x40
    7830:	910123f5 	add	x21, sp, #0x48
    7834:	d0000021 	adrp	x1, d000 <atexit+0x10>
    7838:	91106021 	add	x1, x1, #0x418
    783c:	aa1503e0 	mov	x0, x21
    7840:	9a81c041 	csel	x1, x2, x1, gt
    7844:	97ffec5f 	bl	29c0 <strcpy@plt>
    7848:	aa1503e0 	mov	x0, x21
    784c:	97ffebb1 	bl	2710 <strlen@plt>
    7850:	aa1503e1 	mov	x1, x21
    7854:	aa0003e2 	mov	x2, x0
    7858:	aa1403e0 	mov	x0, x20
    785c:	97ffeeed 	bl	3410 <buf_put>
    7860:	f9413bf5 	ldr	x21, [sp, #624]
    7864:	f9413ff6 	ldr	x22, [sp, #632]
    7868:	f94153fb 	ldr	x27, [sp, #672]
    786c:	f94157fc 	ldr	x28, [sp, #680]
    7870:	fd415be8 	ldr	d8, [sp, #688]
    7874:	fd415fe9 	ldr	d9, [sp, #696]
    7878:	17fffeb6 	b	7350 <fwp_write+0xb0>
    787c:	f9400276 	ldr	x22, [x19]
    7880:	34002e03 	cbz	w3, 7e40 <fwp_write+0xba0>
    7884:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7888:	f947f400 	ldr	x0, [x0, #4072]
    788c:	f94127e2 	ldr	x2, [sp, #584]
    7890:	f9400001 	ldr	x1, [x0]
    7894:	eb010042 	subs	x2, x2, x1
    7898:	d2800001 	mov	x1, #0x0                   	// #0
    789c:	540014a1 	b.ne	7b30 <fwp_write+0x890>  // b.any
    78a0:	aa1603e2 	mov	x2, x22
    78a4:	91002261 	add	x1, x19, #0x8
    78a8:	f9413bf5 	ldr	x21, [sp, #624]
    78ac:	aa1403e0 	mov	x0, x20
    78b0:	f9413ff6 	ldr	x22, [sp, #632]
    78b4:	17fffeff 	b	74b0 <fwp_write+0x210>
    78b8:	fd015be8 	str	d8, [sp, #688]
    78bc:	9e670268 	fmov	d8, x19
    78c0:	fd015fe9 	str	d9, [sp, #696]
    78c4:	1e682100 	fcmp	d8, d8
    78c8:	54004746 	b.vs	81b0 <fwp_write+0xf10>
    78cc:	1e60c101 	fabs	d1, d8
    78d0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    78d4:	9e670000 	fmov	d0, x0
    78d8:	910123f5 	add	x21, sp, #0x48
    78dc:	52800033 	mov	w19, #0x1                   	// #1
    78e0:	1e602020 	fcmp	d1, d0
    78e4:	540001ad 	b.le	7918 <fwp_write+0x678>
    78e8:	1e602118 	fcmpe	d8, #0.0
    78ec:	d0000022 	adrp	x2, d000 <atexit+0x10>
    78f0:	91010042 	add	x2, x2, #0x40
    78f4:	d0000021 	adrp	x1, d000 <atexit+0x10>
    78f8:	91106021 	add	x1, x1, #0x418
    78fc:	aa1503e0 	mov	x0, x21
    7900:	9a81c041 	csel	x1, x2, x1, gt
    7904:	97ffec2f 	bl	29c0 <strcpy@plt>
    7908:	17ffffd0 	b	7848 <fwp_write+0x5a8>
    790c:	11000673 	add	w19, w19, #0x1
    7910:	71004a7f 	cmp	w19, #0x12
    7914:	54003860 	b.eq	8020 <fwp_write+0xd80>  // b.none
    7918:	1e604100 	fmov	d0, d8
    791c:	2a1303e1 	mov	w1, w19
    7920:	aa1503e0 	mov	x0, x21
    7924:	97ffef17 	bl	3580 <fwp_format_g.constprop.0>
    7928:	aa1503e0 	mov	x0, x21
    792c:	d2800001 	mov	x1, #0x0                   	// #0
    7930:	97ffeb8c 	bl	2760 <strtod@plt>
    7934:	1e602100 	fcmp	d8, d0
    7938:	54fffea1 	b.ne	790c <fwp_write+0x66c>  // b.any
    793c:	aa1503e0 	mov	x0, x21
    7940:	97ffeeed 	bl	34f4 <fwp_finish_float>
    7944:	17ffffc1 	b	7848 <fwp_write+0x5a8>
    7948:	a9400e62 	ldp	x2, x3, [x19]
    794c:	910123f3 	add	x19, sp, #0x48
    7950:	aa1303e0 	mov	x0, x19
    7954:	97ffed33 	bl	2e20 <fwp_fmt_u128>
    7958:	17fffe74 	b	7328 <fwp_write+0x88>
    795c:	f90143f7 	str	x23, [sp, #640]
    7960:	f90147f8 	str	x24, [sp, #648]
    7964:	2a1303f8 	mov	w24, w19
    7968:	f9014bf9 	str	x25, [sp, #656]
    796c:	f9014ffa 	str	x26, [sp, #664]
    7970:	f13ffe7f 	cmp	x19, #0xfff
    7974:	54000049 	b.ls	797c <fwp_write+0x6dc>  // b.plast
    7978:	b9400278 	ldr	w24, [x19]
    797c:	f9400f80 	ldr	x0, [x28, #24]
    7980:	2a1803f5 	mov	w21, w24
    7984:	d37d7f18 	ubfiz	x24, x24, #3, #32
    7988:	d37ef6b9 	lsl	x25, x21, #2
    798c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    7990:	aa1603e0 	mov	x0, x22
    7994:	97ffeb5f 	bl	2710 <strlen@plt>
    7998:	aa1603e1 	mov	x1, x22
    799c:	aa0003e2 	mov	x2, x0
    79a0:	aa1403e0 	mov	x0, x20
    79a4:	97ffee9b 	bl	3410 <buf_put>
    79a8:	f9401780 	ldr	x0, [x28, #40]
    79ac:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    79b0:	7100001f 	cmp	w0, #0x0
    79b4:	5400068d 	b.le	7a84 <fwp_write+0x7e4>
    79b8:	91002276 	add	x22, x19, #0x8
    79bc:	91001ff5 	add	x21, sp, #0x7
    79c0:	d280001b 	mov	x27, #0x0                   	// #0
    79c4:	5280041a 	mov	w26, #0x20                  	// #32
    79c8:	f9401b80 	ldr	x0, [x28, #48]
    79cc:	aa1503e1 	mov	x1, x21
    79d0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    79d4:	d2800022 	mov	x2, #0x1                   	// #1
    79d8:	f8786803 	ldr	x3, [x0, x24]
    79dc:	aa1403e0 	mov	x0, x20
    79e0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    79e4:	39001ffa 	strb	w26, [sp, #7]
    79e8:	97ffee8a 	bl	3410 <buf_put>
    79ec:	f13ffeff 	cmp	x23, #0xfff
    79f0:	b9400261 	ldr	w1, [x19]
    79f4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    79f8:	7100383f 	cmp	w1, #0xe
    79fc:	54000160 	b.eq	7a28 <fwp_write+0x788>  // b.none
    7a00:	7100403f 	cmp	w1, #0x10
    7a04:	54001a60 	b.eq	7d50 <fwp_write+0xab0>  // b.none
    7a08:	7100283f 	cmp	w1, #0xa
    7a0c:	54002aa0 	b.eq	7f60 <fwp_write+0xcc0>  // b.none
    7a10:	540014ac 	b.gt	7ca4 <fwp_write+0xa04>
    7a14:	71000c3f 	cmp	w1, #0x3
    7a18:	540029ac 	b.gt	7f4c <fwp_write+0xcac>
    7a1c:	d37ffee0 	lsr	x0, x23, #63
    7a20:	37f814a1 	tbnz	w1, #31, 7cb4 <fwp_write+0xa14>
    7a24:	d503201f 	nop
    7a28:	34001460 	cbz	w0, 7cb4 <fwp_write+0xa14>
    7a2c:	52800503 	mov	w3, #0x28                  	// #40
    7a30:	aa1503e1 	mov	x1, x21
    7a34:	aa1403e0 	mov	x0, x20
    7a38:	d2800022 	mov	x2, #0x1                   	// #1
    7a3c:	39001fe3 	strb	w3, [sp, #7]
    7a40:	97ffee74 	bl	3410 <buf_put>
    7a44:	aa1303e2 	mov	x2, x19
    7a48:	aa1703e1 	mov	x1, x23
    7a4c:	aa1403e0 	mov	x0, x20
    7a50:	52800003 	mov	w3, #0x0                   	// #0
    7a54:	97fffe13 	bl	72a0 <fwp_write>
    7a58:	52800523 	mov	w3, #0x29                  	// #41
    7a5c:	aa1503e1 	mov	x1, x21
    7a60:	aa1403e0 	mov	x0, x20
    7a64:	d2800022 	mov	x2, #0x1                   	// #1
    7a68:	39001fe3 	strb	w3, [sp, #7]
    7a6c:	97ffee69 	bl	3410 <buf_put>
    7a70:	f9401780 	ldr	x0, [x28, #40]
    7a74:	9100077b 	add	x27, x27, #0x1
    7a78:	b8796800 	ldr	w0, [x0, x25]
    7a7c:	6b1b001f 	cmp	w0, w27
    7a80:	54fffa4c 	b.gt	79c8 <fwp_write+0x728>
    7a84:	f9413bf5 	ldr	x21, [sp, #624]
    7a88:	f9413ff6 	ldr	x22, [sp, #632]
    7a8c:	f94143f7 	ldr	x23, [sp, #640]
    7a90:	f94147f8 	ldr	x24, [sp, #648]
    7a94:	f9414bf9 	ldr	x25, [sp, #656]
    7a98:	f9414ffa 	ldr	x26, [sp, #664]
    7a9c:	f94153fb 	ldr	x27, [sp, #672]
    7aa0:	f94157fc 	ldr	x28, [sp, #680]
    7aa4:	17fffe2b 	b	7350 <fwp_write+0xb0>
    7aa8:	52800783 	mov	w3, #0x3c                  	// #60
    7aac:	91001ff3 	add	x19, sp, #0x7
    7ab0:	aa1303e1 	mov	x1, x19
    7ab4:	d2800022 	mov	x2, #0x1                   	// #1
    7ab8:	aa1403e0 	mov	x0, x20
    7abc:	39001fe3 	strb	w3, [sp, #7]
    7ac0:	97ffee54 	bl	3410 <buf_put>
    7ac4:	f9400795 	ldr	x21, [x28, #8]
    7ac8:	aa1503e0 	mov	x0, x21
    7acc:	97ffeb11 	bl	2710 <strlen@plt>
    7ad0:	aa1503e1 	mov	x1, x21
    7ad4:	aa0003e2 	mov	x2, x0
    7ad8:	aa1403e0 	mov	x0, x20
    7adc:	97ffee4d 	bl	3410 <buf_put>
    7ae0:	528007c3 	mov	w3, #0x3e                  	// #62
    7ae4:	aa1303e1 	mov	x1, x19
    7ae8:	aa1403e0 	mov	x0, x20
    7aec:	d2800022 	mov	x2, #0x1                   	// #1
    7af0:	39001fe3 	strb	w3, [sp, #7]
    7af4:	17fffe12 	b	733c <fwp_write+0x9c>
    7af8:	f100067f 	cmp	x19, #0x1
    7afc:	540025a0 	b.eq	7fb0 <fwp_write+0xd10>  // b.none
    7b00:	b100067f 	cmn	x19, #0x1
    7b04:	54002bc0 	b.eq	807c <fwp_write+0xddc>  // b.none
    7b08:	d0000021 	adrp	x1, d000 <atexit+0x10>
    7b0c:	91108021 	add	x1, x1, #0x420
    7b10:	d2800022 	mov	x2, #0x1                   	// #1
    7b14:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7b18:	f947f400 	ldr	x0, [x0, #4072]
    7b1c:	f94127e4 	ldr	x4, [sp, #584]
    7b20:	f9400003 	ldr	x3, [x0]
    7b24:	eb030084 	subs	x4, x4, x3
    7b28:	d2800003 	mov	x3, #0x0                   	// #0
    7b2c:	54ffebe0 	b.eq	78a8 <fwp_write+0x608>  // b.none
    7b30:	f90143f7 	str	x23, [sp, #640]
    7b34:	f90147f8 	str	x24, [sp, #648]
    7b38:	f9014bf9 	str	x25, [sp, #656]
    7b3c:	f9014ffa 	str	x26, [sp, #664]
    7b40:	fd015be8 	str	d8, [sp, #688]
    7b44:	fd015fe9 	str	d9, [sp, #696]
    7b48:	97ffeb4e 	bl	2880 <__stack_chk_fail@plt>
    7b4c:	52800b63 	mov	w3, #0x5b                  	// #91
    7b50:	91001ff5 	add	x21, sp, #0x7
    7b54:	aa1503e1 	mov	x1, x21
    7b58:	aa1403e0 	mov	x0, x20
    7b5c:	d2800022 	mov	x2, #0x1                   	// #1
    7b60:	d0000036 	adrp	x22, d000 <atexit+0x10>
    7b64:	911302d6 	add	x22, x22, #0x4c0
    7b68:	39001fe3 	strb	w3, [sp, #7]
    7b6c:	97ffee29 	bl	3410 <buf_put>
    7b70:	b4000273 	cbz	x19, 7bbc <fwp_write+0x91c>
    7b74:	f9400661 	ldr	x1, [x19, #8]
    7b78:	aa1403e0 	mov	x0, x20
    7b7c:	f9401f82 	ldr	x2, [x28, #56]
    7b80:	52800003 	mov	w3, #0x0                   	// #0
    7b84:	97fffdc7 	bl	72a0 <fwp_write>
    7b88:	f9400a73 	ldr	x19, [x19, #16]
    7b8c:	b4000193 	cbz	x19, 7bbc <fwp_write+0x91c>
    7b90:	aa1603e1 	mov	x1, x22
    7b94:	aa1403e0 	mov	x0, x20
    7b98:	d2800042 	mov	x2, #0x2                   	// #2
    7b9c:	97ffee1d 	bl	3410 <buf_put>
    7ba0:	f9400661 	ldr	x1, [x19, #8]
    7ba4:	aa1403e0 	mov	x0, x20
    7ba8:	f9401f82 	ldr	x2, [x28, #56]
    7bac:	52800003 	mov	w3, #0x0                   	// #0
    7bb0:	97fffdbc 	bl	72a0 <fwp_write>
    7bb4:	f9400a73 	ldr	x19, [x19, #16]
    7bb8:	b5fffed3 	cbnz	x19, 7b90 <fwp_write+0x8f0>
    7bbc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7bc0:	aa1503e1 	mov	x1, x21
    7bc4:	aa1403e0 	mov	x0, x20
    7bc8:	d2800022 	mov	x2, #0x1                   	// #1
    7bcc:	39001fe3 	strb	w3, [sp, #7]
    7bd0:	17fffddb 	b	733c <fwp_write+0x9c>
    7bd4:	aa1403e0 	mov	x0, x20
    7bd8:	d0000021 	adrp	x1, d000 <atexit+0x10>
    7bdc:	d28000c2 	mov	x2, #0x6                   	// #6
    7be0:	9112c021 	add	x1, x1, #0x4b0
    7be4:	97ffee0b 	bl	3410 <buf_put>
    7be8:	f9400260 	ldr	x0, [x19]
    7bec:	b40004c0 	cbz	x0, 7c84 <fwp_write+0x9e4>
    7bf0:	910123f5 	add	x21, sp, #0x48
    7bf4:	91002276 	add	x22, x19, #0x8
    7bf8:	f90143f7 	str	x23, [sp, #640]
    7bfc:	d2800017 	mov	x23, #0x0                   	// #0
    7c00:	f90147f8 	str	x24, [sp, #648]
    7c04:	d0000038 	adrp	x24, d000 <atexit+0x10>
    7c08:	9112e318 	add	x24, x24, #0x4b8
    7c0c:	f9014bf9 	str	x25, [sp, #656]
    7c10:	d0000039 	adrp	x25, d000 <atexit+0x10>
    7c14:	91130339 	add	x25, x25, #0x4c0
    7c18:	f9014ffa 	str	x26, [sp, #664]
    7c1c:	14000005 	b	7c30 <fwp_write+0x990>
    7c20:	aa1903e1 	mov	x1, x25
    7c24:	aa1403e0 	mov	x0, x20
    7c28:	d2800042 	mov	x2, #0x2                   	// #2
    7c2c:	97ffedf9 	bl	3410 <buf_put>
    7c30:	38776ac5 	ldrb	w5, [x22, x23]
    7c34:	d2804003 	mov	x3, #0x200                 	// #512
    7c38:	aa1803e4 	mov	x4, x24
    7c3c:	aa0303e1 	mov	x1, x3
    7c40:	52800042 	mov	w2, #0x2                   	// #2
    7c44:	aa1503e0 	mov	x0, x21
    7c48:	910006f7 	add	x23, x23, #0x1
    7c4c:	97ffeae9 	bl	27f0 <__snprintf_chk@plt>
    7c50:	aa1503e0 	mov	x0, x21
    7c54:	97ffeaaf 	bl	2710 <strlen@plt>
    7c58:	aa1503e1 	mov	x1, x21
    7c5c:	aa0003e2 	mov	x2, x0
    7c60:	aa1403e0 	mov	x0, x20
    7c64:	97ffedeb 	bl	3410 <buf_put>
    7c68:	f9400260 	ldr	x0, [x19]
    7c6c:	eb17001f 	cmp	x0, x23
    7c70:	54fffd88 	b.hi	7c20 <fwp_write+0x980>  // b.pmore
    7c74:	f94143f7 	ldr	x23, [sp, #640]
    7c78:	f94147f8 	ldr	x24, [sp, #648]
    7c7c:	f9414bf9 	ldr	x25, [sp, #656]
    7c80:	f9414ffa 	ldr	x26, [sp, #664]
    7c84:	52800ba3 	mov	w3, #0x5d                  	// #93
    7c88:	aa1403e0 	mov	x0, x20
    7c8c:	91001fe1 	add	x1, sp, #0x7
    7c90:	d2800022 	mov	x2, #0x1                   	// #1
    7c94:	39001fe3 	strb	w3, [sp, #7]
    7c98:	17fffda9 	b	733c <fwp_write+0x9c>
    7c9c:	52800fa3 	mov	w3, #0x7d                  	// #125
    7ca0:	17fffe44 	b	75b0 <fwp_write+0x310>
    7ca4:	f10002ff 	cmp	x23, #0x0
    7ca8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7cac:	71002c3f 	cmp	w1, #0xb
    7cb0:	54ffebc0 	b.eq	7a28 <fwp_write+0x788>  // b.none
    7cb4:	aa1303e2 	mov	x2, x19
    7cb8:	aa1703e1 	mov	x1, x23
    7cbc:	aa1403e0 	mov	x0, x20
    7cc0:	52800003 	mov	w3, #0x0                   	// #0
    7cc4:	97fffd77 	bl	72a0 <fwp_write>
    7cc8:	17ffff6a 	b	7a70 <fwp_write+0x7d0>
    7ccc:	aa1403e0 	mov	x0, x20
    7cd0:	91001fe1 	add	x1, sp, #0x7
    7cd4:	52800fa3 	mov	w3, #0x7d                  	// #125
    7cd8:	d2800022 	mov	x2, #0x1                   	// #1
    7cdc:	17fffe38 	b	75bc <fwp_write+0x31c>
    7ce0:	a9400281 	ldp	x1, x0, [x20]
    7ce4:	91000800 	add	x0, x0, #0x2
    7ce8:	8b160000 	add	x0, x0, x22
    7cec:	f9000680 	str	x0, [x20, #8]
    7cf0:	3820683f 	strb	wzr, [x1, x0]
    7cf4:	f9413bf5 	ldr	x21, [sp, #624]
    7cf8:	f9413ff6 	ldr	x22, [sp, #632]
    7cfc:	f94153fb 	ldr	x27, [sp, #672]
    7d00:	f94157fc 	ldr	x28, [sp, #680]
    7d04:	17fffd93 	b	7350 <fwp_write+0xb0>
    7d08:	f9400f80 	ldr	x0, [x28, #24]
    7d0c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7d10:	aa1b03e0 	mov	x0, x27
    7d14:	97ffea7f 	bl	2710 <strlen@plt>
    7d18:	aa1b03e1 	mov	x1, x27
    7d1c:	aa0003e2 	mov	x2, x0
    7d20:	aa1403e0 	mov	x0, x20
    7d24:	97ffedbb 	bl	3410 <buf_put>
    7d28:	aa1903e1 	mov	x1, x25
    7d2c:	aa1403e0 	mov	x0, x20
    7d30:	d2800062 	mov	x2, #0x3                   	// #3
    7d34:	97ffedb7 	bl	3410 <buf_put>
    7d38:	17fffe10 	b	7578 <fwp_write+0x2d8>
    7d3c:	aa1a03e1 	mov	x1, x26
    7d40:	aa1403e0 	mov	x0, x20
    7d44:	d2800042 	mov	x2, #0x2                   	// #2
    7d48:	97ffedb2 	bl	3410 <buf_put>
    7d4c:	17fffe09 	b	7570 <fwp_write+0x2d0>
    7d50:	f9400660 	ldr	x0, [x19, #8]
    7d54:	b4fffb00 	cbz	x0, 7cb4 <fwp_write+0xa14>
    7d58:	d0000021 	adrp	x1, d000 <atexit+0x10>
    7d5c:	91136021 	add	x1, x1, #0x4d8
    7d60:	97ffeae8 	bl	2900 <strcmp@plt>
    7d64:	7100001f 	cmp	w0, #0x0
    7d68:	1a9f07e0 	cset	w0, ne	// ne = any
    7d6c:	17ffff2f 	b	7a28 <fwp_write+0x788>
    7d70:	aa1403e0 	mov	x0, x20
    7d74:	d2800042 	mov	x2, #0x2                   	// #2
    7d78:	d0000021 	adrp	x1, d000 <atexit+0x10>
    7d7c:	91134021 	add	x1, x1, #0x4d0
    7d80:	97ffeda4 	bl	3410 <buf_put>
    7d84:	91004261 	add	x1, x19, #0x10
    7d88:	aa1403e0 	mov	x0, x20
    7d8c:	f9402382 	ldr	x2, [x28, #64]
    7d90:	52800003 	mov	w3, #0x0                   	// #0
    7d94:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7d98:	97fffd42 	bl	72a0 <fwp_write>
    7d9c:	17fffd9c 	b	740c <fwp_write+0x16c>
    7da0:	1e22c109 	fcvt	d9, s8
    7da4:	910123f5 	add	x21, sp, #0x48
    7da8:	52800033 	mov	w19, #0x1                   	// #1
    7dac:	d503201f 	nop
    7db0:	1e604120 	fmov	d0, d9
    7db4:	2a1303e1 	mov	w1, w19
    7db8:	aa1503e0 	mov	x0, x21
    7dbc:	97ffedf1 	bl	3580 <fwp_format_g.constprop.0>
    7dc0:	aa1503e0 	mov	x0, x21
    7dc4:	d2800001 	mov	x1, #0x0                   	// #0
    7dc8:	97ffeada 	bl	2930 <strtof@plt>
    7dcc:	1e202100 	fcmp	s8, s0
    7dd0:	54ffdb60 	b.eq	793c <fwp_write+0x69c>  // b.none
    7dd4:	11000673 	add	w19, w19, #0x1
    7dd8:	71002a7f 	cmp	w19, #0xa
    7ddc:	54fffea1 	b.ne	7db0 <fwp_write+0xb10>  // b.any
    7de0:	1e604120 	fmov	d0, d9
    7de4:	aa1503e0 	mov	x0, x21
    7de8:	52800121 	mov	w1, #0x9                   	// #9
    7dec:	97ffede5 	bl	3580 <fwp_format_g.constprop.0>
    7df0:	17fffed3 	b	793c <fwp_write+0x69c>
    7df4:	d37ef6a1 	lsl	x1, x21, #2
    7df8:	b7f81563 	tbnz	x3, #63, 80a4 <fwp_write+0xe04>
    7dfc:	91002263 	add	x3, x19, #0x8
    7e00:	8b010061 	add	x1, x3, x1
    7e04:	b9400023 	ldr	w3, [x1]
    7e08:	7100081f 	cmp	w0, #0x2
    7e0c:	2a0303e1 	mov	w1, w3
    7e10:	93407c63 	sxtw	x3, w3
    7e14:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e18:	17fffe5a 	b	7780 <fwp_write+0x4e0>
    7e1c:	d37ffaa1 	lsl	x1, x21, #1
    7e20:	b7f81363 	tbnz	x3, #63, 808c <fwp_write+0xdec>
    7e24:	91002263 	add	x3, x19, #0x8
    7e28:	8b010061 	add	x1, x3, x1
    7e2c:	79400021 	ldrh	w1, [x1]
    7e30:	7100041f 	cmp	w0, #0x1
    7e34:	93403c23 	sxth	x3, w1
    7e38:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7e3c:	17fffe51 	b	7780 <fwp_write+0x4e0>
    7e40:	52800443 	mov	w3, #0x22                  	// #34
    7e44:	91001ff5 	add	x21, sp, #0x7
    7e48:	91002273 	add	x19, x19, #0x8
    7e4c:	aa1503e1 	mov	x1, x21
    7e50:	aa1403e0 	mov	x0, x20
    7e54:	d2800022 	mov	x2, #0x1                   	// #1
    7e58:	39001fe3 	strb	w3, [sp, #7]
    7e5c:	f90143f7 	str	x23, [sp, #640]
    7e60:	8b160277 	add	x23, x19, x22
    7e64:	f90147f8 	str	x24, [sp, #648]
    7e68:	97ffed6a 	bl	3410 <buf_put>
    7e6c:	b4000696 	cbz	x22, 7f3c <fwp_write+0xc9c>
    7e70:	d0000038 	adrp	x24, d000 <atexit+0x10>
    7e74:	91120318 	add	x24, x24, #0x480
    7e78:	f9014bf9 	str	x25, [sp, #656]
    7e7c:	d0000039 	adrp	x25, d000 <atexit+0x10>
    7e80:	91128339 	add	x25, x25, #0x4a0
    7e84:	f9014ffa 	str	x26, [sp, #664]
    7e88:	1400000d 	b	7ebc <fwp_write+0xc1c>
    7e8c:	710024bf 	cmp	w5, #0x9
    7e90:	54000460 	b.eq	7f1c <fwp_write+0xc7c>  // b.none
    7e94:	710028bf 	cmp	w5, #0xa
    7e98:	54000a61 	b.ne	7fe4 <fwp_write+0xd44>  // b.any
    7e9c:	d0000021 	adrp	x1, d000 <atexit+0x10>
    7ea0:	aa1403e0 	mov	x0, x20
    7ea4:	91124021 	add	x1, x1, #0x490
    7ea8:	d2800042 	mov	x2, #0x2                   	// #2
    7eac:	97ffed59 	bl	3410 <buf_put>
    7eb0:	91000673 	add	x19, x19, #0x1
    7eb4:	eb17027f 	cmp	x19, x23
    7eb8:	540003e0 	b.eq	7f34 <fwp_write+0xc94>  // b.none
    7ebc:	39400265 	ldrb	w5, [x19]
    7ec0:	710034bf 	cmp	w5, #0xd
    7ec4:	54000180 	b.eq	7ef4 <fwp_write+0xc54>  // b.none
    7ec8:	54fffe29 	b.ls	7e8c <fwp_write+0xbec>  // b.plast
    7ecc:	710088bf 	cmp	w5, #0x22
    7ed0:	540001c0 	b.eq	7f08 <fwp_write+0xc68>  // b.none
    7ed4:	710170bf 	cmp	w5, #0x5c
    7ed8:	54000741 	b.ne	7fc0 <fwp_write+0xd20>  // b.any
    7edc:	aa1403e0 	mov	x0, x20
    7ee0:	d0000021 	adrp	x1, d000 <atexit+0x10>
    7ee4:	d2800042 	mov	x2, #0x2                   	// #2
    7ee8:	91122021 	add	x1, x1, #0x488
    7eec:	97ffed49 	bl	3410 <buf_put>
    7ef0:	17fffff0 	b	7eb0 <fwp_write+0xc10>
    7ef4:	aa1903e1 	mov	x1, x25
    7ef8:	aa1403e0 	mov	x0, x20
    7efc:	d2800042 	mov	x2, #0x2                   	// #2
    7f00:	97ffed44 	bl	3410 <buf_put>
    7f04:	17ffffeb 	b	7eb0 <fwp_write+0xc10>
    7f08:	aa1803e1 	mov	x1, x24
    7f0c:	aa1403e0 	mov	x0, x20
    7f10:	d2800042 	mov	x2, #0x2                   	// #2
    7f14:	97ffed3f 	bl	3410 <buf_put>
    7f18:	17ffffe6 	b	7eb0 <fwp_write+0xc10>
    7f1c:	aa1403e0 	mov	x0, x20
    7f20:	d0000021 	adrp	x1, d000 <atexit+0x10>
    7f24:	d2800042 	mov	x2, #0x2                   	// #2
    7f28:	91126021 	add	x1, x1, #0x498
    7f2c:	97ffed39 	bl	3410 <buf_put>
    7f30:	17ffffe0 	b	7eb0 <fwp_write+0xc10>
    7f34:	f9414bf9 	ldr	x25, [sp, #656]
    7f38:	f9414ffa 	ldr	x26, [sp, #664]
    7f3c:	aa1503e1 	mov	x1, x21
    7f40:	aa1403e0 	mov	x0, x20
    7f44:	52800443 	mov	w3, #0x22                  	// #34
    7f48:	17fffd9c 	b	75b8 <fwp_write+0x318>
    7f4c:	7100103f 	cmp	w1, #0x4
    7f50:	54ffeb21 	b.ne	7cb4 <fwp_write+0xa14>  // b.any
    7f54:	f94006e0 	ldr	x0, [x23, #8]
    7f58:	d37ffc00 	lsr	x0, x0, #63
    7f5c:	17fffeb3 	b	7a28 <fwp_write+0x788>
    7f60:	710002ff 	cmp	w23, #0x0
    7f64:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7f68:	17fffeb0 	b	7a28 <fwp_write+0x788>
    7f6c:	528005a1 	mov	w1, #0x2d                  	// #45
    7f70:	eb0203e2 	negs	x2, x2
    7f74:	da0303e3 	ngc	x3, x3
    7f78:	910127e0 	add	x0, sp, #0x49
    7f7c:	910123f5 	add	x21, sp, #0x48
    7f80:	390123e1 	strb	w1, [sp, #72]
    7f84:	97ffeba7 	bl	2e20 <fwp_fmt_u128>
    7f88:	17fffe18 	b	77e8 <fwp_write+0x548>
    7f8c:	d37ceea1 	lsl	x1, x21, #4
    7f90:	b7f810a3 	tbnz	x3, #63, 81a4 <fwp_write+0xf04>
    7f94:	91002260 	add	x0, x19, #0x8
    7f98:	8b010001 	add	x1, x0, x1
    7f9c:	17fffdf9 	b	7780 <fwp_write+0x4e0>
    7fa0:	f9400a61 	ldr	x1, [x19, #16]
    7fa4:	8b010000 	add	x0, x0, x1
    7fa8:	f9400001 	ldr	x1, [x0]
    7fac:	17fffdf5 	b	7780 <fwp_write+0x4e0>
    7fb0:	d0000021 	adrp	x1, d000 <atexit+0x10>
    7fb4:	d2800042 	mov	x2, #0x2                   	// #2
    7fb8:	9110a021 	add	x1, x1, #0x428
    7fbc:	17fffed6 	b	7b14 <fwp_write+0x874>
    7fc0:	7101fcbf 	cmp	w5, #0x7f
    7fc4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7fc8:	540000e9 	b.ls	7fe4 <fwp_write+0xd44>  // b.plast
    7fcc:	aa1503e1 	mov	x1, x21
    7fd0:	aa1403e0 	mov	x0, x20
    7fd4:	d2800022 	mov	x2, #0x1                   	// #1
    7fd8:	39001fe5 	strb	w5, [sp, #7]
    7fdc:	97ffed0d 	bl	3410 <buf_put>
    7fe0:	17ffffb4 	b	7eb0 <fwp_write+0xc10>
    7fe4:	d2800203 	mov	x3, #0x10                  	// #16
    7fe8:	d0000024 	adrp	x4, d000 <atexit+0x10>
    7fec:	aa0303e1 	mov	x1, x3
    7ff0:	9112a084 	add	x4, x4, #0x4a8
    7ff4:	910123f6 	add	x22, sp, #0x48
    7ff8:	52800042 	mov	w2, #0x2                   	// #2
    7ffc:	aa1603e0 	mov	x0, x22
    8000:	97ffe9fc 	bl	27f0 <__snprintf_chk@plt>
    8004:	aa1603e0 	mov	x0, x22
    8008:	97ffe9c2 	bl	2710 <strlen@plt>
    800c:	aa1603e1 	mov	x1, x22
    8010:	aa0003e2 	mov	x2, x0
    8014:	aa1403e0 	mov	x0, x20
    8018:	97ffecfe 	bl	3410 <buf_put>
    801c:	17ffffa5 	b	7eb0 <fwp_write+0xc10>
    8020:	1e604100 	fmov	d0, d8
    8024:	aa1503e0 	mov	x0, x21
    8028:	52800221 	mov	w1, #0x11                  	// #17
    802c:	97ffed55 	bl	3580 <fwp_format_g.constprop.0>
    8030:	17fffe43 	b	793c <fwp_write+0x69c>
    8034:	b9401040 	ldr	w0, [x2, #16]
    8038:	350003c0 	cbnz	w0, 80b0 <fwp_write+0xe10>
    803c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8040:	f947f400 	ldr	x0, [x0, #4072]
    8044:	f94127e2 	ldr	x2, [sp, #584]
    8048:	f9400001 	ldr	x1, [x0]
    804c:	eb010042 	subs	x2, x2, x1
    8050:	d2800001 	mov	x1, #0x0                   	// #0
    8054:	54ffd721 	b.ne	7b38 <fwp_write+0x898>  // b.any
    8058:	f9413bf5 	ldr	x21, [sp, #624]
    805c:	b0000021 	adrp	x1, d000 <atexit+0x10>
    8060:	f9413ff6 	ldr	x22, [sp, #632]
    8064:	aa1403e0 	mov	x0, x20
    8068:	f94143f7 	ldr	x23, [sp, #640]
    806c:	9113e021 	add	x1, x1, #0x4f8
    8070:	f94147f8 	ldr	x24, [sp, #648]
    8074:	d2800042 	mov	x2, #0x2                   	// #2
    8078:	17fffd0e 	b	74b0 <fwp_write+0x210>
    807c:	b0000021 	adrp	x1, d000 <atexit+0x10>
    8080:	d2800042 	mov	x2, #0x2                   	// #2
    8084:	9110c021 	add	x1, x1, #0x430
    8088:	17fffea3 	b	7b14 <fwp_write+0x874>
    808c:	f9400a63 	ldr	x3, [x19, #16]
    8090:	8b030021 	add	x1, x1, x3
    8094:	17ffff66 	b	7e2c <fwp_write+0xb8c>
    8098:	f9400a61 	ldr	x1, [x19, #16]
    809c:	8b0102a1 	add	x1, x21, x1
    80a0:	17fffdb3 	b	776c <fwp_write+0x4cc>
    80a4:	f9400a63 	ldr	x3, [x19, #16]
    80a8:	8b030021 	add	x1, x1, x3
    80ac:	17ffff56 	b	7e04 <fwp_write+0xb64>
    80b0:	b9404840 	ldr	w0, [x2, #72]
    80b4:	91001ff5 	add	x21, sp, #0x7
    80b8:	34ffa360 	cbz	w0, 7524 <fwp_write+0x284>
    80bc:	52800503 	mov	w3, #0x28                  	// #40
    80c0:	aa1403e0 	mov	x0, x20
    80c4:	aa1503e1 	mov	x1, x21
    80c8:	d2800022 	mov	x2, #0x1                   	// #1
    80cc:	39001fe3 	strb	w3, [sp, #7]
    80d0:	97ffecd0 	bl	3410 <buf_put>
    80d4:	b9401380 	ldr	w0, [x28, #16]
    80d8:	52800038 	mov	w24, #0x1                   	// #1
    80dc:	7100001f 	cmp	w0, #0x0
    80e0:	54ffa36c 	b.gt	754c <fwp_write+0x2ac>
    80e4:	17fffd32 	b	75ac <fwp_write+0x30c>
    80e8:	f9014bf9 	str	x25, [sp, #656]
    80ec:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0xefd0>
    80f0:	f9014ffa 	str	x26, [sp, #664]
    80f4:	f9400676 	ldr	x22, [x19, #8]
    80f8:	910aa333 	add	x19, x25, #0x2a8
    80fc:	91002273 	add	x19, x19, #0x8
    8100:	937ffed8 	asr	x24, x22, #63
    8104:	aa1802c0 	orr	x0, x22, x24
    8108:	b5000320 	cbnz	x0, 816c <fwp_write+0xecc>
    810c:	110006b5 	add	w21, w21, #0x1
    8110:	710016bf 	cmp	w21, #0x5
    8114:	54ffffc1 	b.ne	810c <fwp_write+0xe6c>  // b.any
    8118:	b7f80578 	tbnz	x24, #63, 81c4 <fwp_write+0xf24>
    811c:	910023f3 	add	x19, sp, #0x8
    8120:	aa1603e2 	mov	x2, x22
    8124:	aa1303e0 	mov	x0, x19
    8128:	d2800003 	mov	x3, #0x0                   	// #0
    812c:	97ffeb3d 	bl	2e20 <fwp_fmt_u128>
    8130:	910123f5 	add	x21, sp, #0x48
    8134:	b0000023 	adrp	x3, d000 <atexit+0x10>
    8138:	aa1303e4 	mov	x4, x19
    813c:	aa1503e0 	mov	x0, x21
    8140:	9113c063 	add	x3, x3, #0x4f0
    8144:	d2804002 	mov	x2, #0x200                 	// #512
    8148:	52800041 	mov	w1, #0x2                   	// #2
    814c:	97ffe975 	bl	2720 <__sprintf_chk@plt>
    8150:	aa1503e0 	mov	x0, x21
    8154:	97ffe96f 	bl	2710 <strlen@plt>
    8158:	aa1503e1 	mov	x1, x21
    815c:	aa0003e2 	mov	x2, x0
    8160:	aa1403e0 	mov	x0, x20
    8164:	97ffecab 	bl	3410 <buf_put>
    8168:	17fffe47 	b	7a84 <fwp_write+0x7e4>
    816c:	f9400277 	ldr	x23, [x19]
    8170:	aa1603e0 	mov	x0, x22
    8174:	aa1803e1 	mov	x1, x24
    8178:	aa1703e2 	mov	x2, x23
    817c:	937ffefa 	asr	x26, x23, #63
    8180:	aa1a03e3 	mov	x3, x26
    8184:	940012bf 	bl	cc80 <__modti3>
    8188:	aa010000 	orr	x0, x0, x1
    818c:	b40002c0 	cbz	x0, 81e4 <fwp_write+0xf44>
    8190:	110006b5 	add	w21, w21, #0x1
    8194:	91004273 	add	x19, x19, #0x10
    8198:	710016bf 	cmp	w21, #0x5
    819c:	54fffe81 	b.ne	816c <fwp_write+0xecc>  // b.any
    81a0:	17ffffde 	b	8118 <fwp_write+0xe78>
    81a4:	f9400a60 	ldr	x0, [x19, #16]
    81a8:	8b000021 	add	x1, x1, x0
    81ac:	17fffd75 	b	7780 <fwp_write+0x4e0>
    81b0:	528c29c0 	mov	w0, #0x614e                	// #24910
    81b4:	910123f5 	add	x21, sp, #0x48
    81b8:	72a009c0 	movk	w0, #0x4e, lsl #16
    81bc:	b9004be0 	str	w0, [sp, #72]
    81c0:	17fffda2 	b	7848 <fwp_write+0x5a8>
    81c4:	528005a1 	mov	w1, #0x2d                  	// #45
    81c8:	eb1603e2 	negs	x2, x22
    81cc:	da1803e3 	ngc	x3, x24
    81d0:	910027e0 	add	x0, sp, #0x9
    81d4:	910023f3 	add	x19, sp, #0x8
    81d8:	390023e1 	strb	w1, [sp, #8]
    81dc:	97ffeb11 	bl	2e20 <fwp_fmt_u128>
    81e0:	17ffffd4 	b	8130 <fwp_write+0xe90>
    81e4:	aa1703e2 	mov	x2, x23
    81e8:	aa1a03e3 	mov	x3, x26
    81ec:	aa1603e0 	mov	x0, x22
    81f0:	aa1803e1 	mov	x1, x24
    81f4:	940011c3 	bl	c900 <__divti3>
    81f8:	aa0003e2 	mov	x2, x0
    81fc:	aa0103e3 	mov	x3, x1
    8200:	b7f80201 	tbnz	x1, #63, 8240 <fwp_write+0xfa0>
    8204:	910023f3 	add	x19, sp, #0x8
    8208:	aa1303e0 	mov	x0, x19
    820c:	97ffeb05 	bl	2e20 <fwp_fmt_u128>
    8210:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8214:	910aa339 	add	x25, x25, #0x2a8
    8218:	910123f5 	add	x21, sp, #0x48
    821c:	aa1303e4 	mov	x4, x19
    8220:	aa1503e0 	mov	x0, x21
    8224:	b0000023 	adrp	x3, d000 <atexit+0x10>
    8228:	f8616b25 	ldr	x5, [x25, x1]
    822c:	9113a063 	add	x3, x3, #0x4e8
    8230:	d2804002 	mov	x2, #0x200                 	// #512
    8234:	52800041 	mov	w1, #0x2                   	// #2
    8238:	97ffe93a 	bl	2720 <__sprintf_chk@plt>
    823c:	17ffffc5 	b	8150 <fwp_write+0xeb0>
    8240:	528005a4 	mov	w4, #0x2d                  	// #45
    8244:	eb0003e2 	negs	x2, x0
    8248:	da0103e3 	ngc	x3, x1
    824c:	910027e0 	add	x0, sp, #0x9
    8250:	910023f3 	add	x19, sp, #0x8
    8254:	390023e4 	strb	w4, [sp, #8]
    8258:	97ffeaf2 	bl	2e20 <fwp_fmt_u128>
    825c:	17ffffed 	b	8210 <fwp_write+0xf70>
    8260:	f9013bf5 	str	x21, [sp, #624]
    8264:	f9013ff6 	str	x22, [sp, #632]
    8268:	f90143f7 	str	x23, [sp, #640]
    826c:	f90147f8 	str	x24, [sp, #648]
    8270:	f9014bf9 	str	x25, [sp, #656]
    8274:	f9014ffa 	str	x26, [sp, #664]
    8278:	f90153fb 	str	x27, [sp, #672]
    827c:	f90157fc 	str	x28, [sp, #680]
    8280:	fd015be8 	str	d8, [sp, #688]
    8284:	fd015fe9 	str	d9, [sp, #696]
    8288:	97ffe97e 	bl	2880 <__stack_chk_fail@plt>
    828c:	d503201f 	nop

0000000000008290 <fwp_hof0.constprop.0>:
    8290:	d105c3ff 	sub	sp, sp, #0x170
    8294:	f00000a2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    8298:	f947f442 	ldr	x2, [x2, #4072]
    829c:	a9117bfd 	stp	x29, x30, [sp, #272]
    82a0:	910443fd 	add	x29, sp, #0x110
    82a4:	a91673fb 	stp	x27, x28, [sp, #352]
    82a8:	aa0003fc 	mov	x28, x0
    82ac:	f9400040 	ldr	x0, [x2]
    82b0:	f90087e0 	str	x0, [sp, #264]
    82b4:	d2800000 	mov	x0, #0x0                   	// #0
    82b8:	b4003501 	cbz	x1, 8958 <fwp_hof0.constprop.0+0x6c8>
    82bc:	910223e0 	add	x0, sp, #0x88
    82c0:	aa1c03fb 	mov	x27, x28
    82c4:	a91253f3 	stp	x19, x20, [sp, #288]
    82c8:	900000d3 	adrp	x19, 20000 <__data_start>
    82cc:	91004273 	add	x19, x19, #0x10
    82d0:	a9135bf5 	stp	x21, x22, [sp, #304]
    82d4:	b0000156 	adrp	x22, 31000 <fwp_root_context+0xca0>
    82d8:	900000d5 	adrp	x21, 20000 <__data_start>
    82dc:	a91463f7 	stp	x23, x24, [sp, #320]
    82e0:	9100c2b7 	add	x23, x21, #0x30
    82e4:	d0fffff8 	adrp	x24, 6000 <fwp_owned_tape_release+0x9c>
    82e8:	a9156bf9 	stp	x25, x26, [sp, #336]
    82ec:	911502d9 	add	x25, x22, #0x540
    82f0:	f90003e0 	str	x0, [sp]
    82f4:	910243e0 	add	x0, sp, #0x90
    82f8:	f90007e0 	str	x0, [sp, #8]
    82fc:	f9000fe1 	str	x1, [sp, #24]
    8300:	f949ef24 	ldr	x4, [x25, #5080]
    8304:	f949db21 	ldr	x1, [x25, #5040]
    8308:	d370bc84 	lsl	x4, x4, #16
    830c:	cb010363 	sub	x3, x27, x1
    8310:	eb04007f 	cmp	x3, x4
    8314:	540003e2 	b.cs	8390 <fwp_hof0.constprop.0+0x100>  // b.hs, b.nlast
    8318:	d350fc60 	lsr	x0, x3, #16
    831c:	f949ff26 	ldr	x6, [x25, #5112]
    8320:	8b000800 	add	x0, x0, x0, lsl #2
    8324:	d37df002 	lsl	x2, x0, #3
    8328:	8b0200c5 	add	x5, x6, x2
    832c:	f94010a0 	ldr	x0, [x5, #32]
    8330:	b4000300 	cbz	x0, 8390 <fwp_hof0.constprop.0+0x100>
    8334:	386268c2 	ldrb	w2, [x6, x2]
    8338:	7100085f 	cmp	w2, #0x2
    833c:	54000da0 	b.eq	84f0 <fwp_hof0.constprop.0+0x260>  // b.none
    8340:	7100045f 	cmp	w2, #0x1
    8344:	54000261 	b.ne	8390 <fwp_hof0.constprop.0+0x100>  // b.any
    8348:	92403c62 	and	x2, x3, #0xffff
    834c:	29430ca6 	ldp	w6, w3, [x5, #24]
    8350:	9b067c42 	mul	x2, x2, x6
    8354:	d360fc42 	lsr	x2, x2, #32
    8358:	eb03005f 	cmp	x2, x3
    835c:	540001a2 	b.cs	8390 <fwp_hof0.constprop.0+0x100>  // b.hs, b.nlast
    8360:	8b020000 	add	x0, x0, x2
    8364:	39400002 	ldrb	w2, [x0]
    8368:	34000142 	cbz	w2, 8390 <fwp_hof0.constprop.0+0x100>
    836c:	7103f45f 	cmp	w2, #0xfd
    8370:	54004ec8 	b.hi	8d48 <fwp_hof0.constprop.0+0xab8>  // b.pmore
    8374:	911502c1 	add	x1, x22, #0x540
    8378:	11000442 	add	w2, w2, #0x1
    837c:	39000002 	strb	w2, [x0]
    8380:	aa0103e0 	mov	x0, x1
    8384:	f949d821 	ldr	x1, [x1, #5040]
    8388:	f949ec04 	ldr	x4, [x0, #5080]
    838c:	d370bc84 	lsl	x4, x4, #16
    8390:	9106431a 	add	x26, x24, #0x190
    8394:	a90267fb 	stp	x27, x25, [sp, #32]
    8398:	aa1b03f9 	mov	x25, x27
    839c:	aa1703fb 	mov	x27, x23
    83a0:	d28018c0 	mov	x0, #0xc6                  	// #198
    83a4:	b2407bfc 	mov	x28, #0x7fffffff            	// #2147483647
    83a8:	f9000be0 	str	x0, [sp, #16]
    83ac:	f9416360 	ldr	x0, [x27, #704]
    83b0:	a9096be0 	stp	x0, x26, [sp, #144]
    83b4:	12800002 	mov	w2, #0xffffffff            	// #-1
    83b8:	f94003e0 	ldr	x0, [sp]
    83bc:	f90053e0 	str	x0, [sp, #160]
    83c0:	f94007e0 	ldr	x0, [sp, #8]
    83c4:	cb010261 	sub	x1, x19, x1
    83c8:	b9008be2 	str	w2, [sp, #136]
    83cc:	f9016360 	str	x0, [x27, #704]
    83d0:	eb04003f 	cmp	x1, x4
    83d4:	54000762 	b.cs	84c0 <fwp_hof0.constprop.0+0x230>  // b.hs, b.nlast
    83d8:	911502c2 	add	x2, x22, #0x540
    83dc:	d350fc20 	lsr	x0, x1, #16
    83e0:	8b000800 	add	x0, x0, x0, lsl #2
    83e4:	f949fc44 	ldr	x4, [x2, #5112]
    83e8:	d37df000 	lsl	x0, x0, #3
    83ec:	8b000082 	add	x2, x4, x0
    83f0:	f9401054 	ldr	x20, [x2, #32]
    83f4:	b4000674 	cbz	x20, 84c0 <fwp_hof0.constprop.0+0x230>
    83f8:	38606880 	ldrb	w0, [x4, x0]
    83fc:	7100081f 	cmp	w0, #0x2
    8400:	540007e0 	b.eq	84fc <fwp_hof0.constprop.0+0x26c>  // b.none
    8404:	7100041f 	cmp	w0, #0x1
    8408:	540005c1 	b.ne	84c0 <fwp_hof0.constprop.0+0x230>  // b.any
    840c:	29431046 	ldp	w6, w4, [x2, #24]
    8410:	92403c20 	and	x0, x1, #0xffff
    8414:	9b067c00 	mul	x0, x0, x6
    8418:	d360fc00 	lsr	x0, x0, #32
    841c:	eb04001f 	cmp	x0, x4
    8420:	54000282 	b.cs	8470 <fwp_hof0.constprop.0+0x1e0>  // b.hs, b.nlast
    8424:	8b000280 	add	x0, x20, x0
    8428:	39400004 	ldrb	w4, [x0]
    842c:	34000224 	cbz	w4, 8470 <fwp_hof0.constprop.0+0x1e0>
    8430:	7103f49f 	cmp	w4, #0xfd
    8434:	54004968 	b.hi	8d60 <fwp_hof0.constprop.0+0xad0>  // b.pmore
    8438:	11000484 	add	w4, w4, #0x1
    843c:	39000004 	strb	w4, [x0]
    8440:	911502c0 	add	x0, x22, #0x540
    8444:	f949d801 	ldr	x1, [x0, #5040]
    8448:	f949ec02 	ldr	x2, [x0, #5080]
    844c:	cb010261 	sub	x1, x19, x1
    8450:	eb02403f 	cmp	x1, x2, lsl #16
    8454:	54000362 	b.cs	84c0 <fwp_hof0.constprop.0+0x230>  // b.hs, b.nlast
    8458:	f949fc00 	ldr	x0, [x0, #5112]
    845c:	d350fc22 	lsr	x2, x1, #16
    8460:	8b020842 	add	x2, x2, x2, lsl #2
    8464:	8b020c02 	add	x2, x0, x2, lsl #3
    8468:	f9401054 	ldr	x20, [x2, #32]
    846c:	b40002b4 	cbz	x20, 84c0 <fwp_hof0.constprop.0+0x230>
    8470:	39400040 	ldrb	w0, [x2]
    8474:	7100081f 	cmp	w0, #0x2
    8478:	54000600 	b.eq	8538 <fwp_hof0.constprop.0+0x2a8>  // b.none
    847c:	7100041f 	cmp	w0, #0x1
    8480:	54000201 	b.ne	84c0 <fwp_hof0.constprop.0+0x230>  // b.any
    8484:	29430044 	ldp	w4, w0, [x2, #24]
    8488:	92403c21 	and	x1, x1, #0xffff
    848c:	9b047c21 	mul	x1, x1, x4
    8490:	d360fc21 	lsr	x1, x1, #32
    8494:	eb00003f 	cmp	x1, x0
    8498:	54000142 	b.cs	84c0 <fwp_hof0.constprop.0+0x230>  // b.hs, b.nlast
    849c:	8b010294 	add	x20, x20, x1
    84a0:	39400280 	ldrb	w0, [x20]
    84a4:	340000e0 	cbz	w0, 84c0 <fwp_hof0.constprop.0+0x230>
    84a8:	7100041f 	cmp	w0, #0x1
    84ac:	54000300 	b.eq	850c <fwp_hof0.constprop.0+0x27c>  // b.none
    84b0:	7103fc1f 	cmp	w0, #0xff
    84b4:	540045a0 	b.eq	8d68 <fwp_hof0.constprop.0+0xad8>  // b.none
    84b8:	51000400 	sub	w0, w0, #0x1
    84bc:	39000280 	strb	w0, [x20]
    84c0:	b40039f9 	cbz	x25, 8bfc <fwp_hof0.constprop.0+0x96c>
    84c4:	aa1903e0 	mov	x0, x25
    84c8:	d2800001 	mov	x1, #0x0                   	// #0
    84cc:	d503201f 	nop
    84d0:	f9400800 	ldr	x0, [x0, #16]
    84d4:	91000421 	add	x1, x1, #0x1
    84d8:	b5ffffc0 	cbnz	x0, 84d0 <fwp_hof0.constprop.0+0x240>
    84dc:	eb1c003f 	cmp	x1, x28
    84e0:	54000329 	b.ls	8544 <fwp_hof0.constprop.0+0x2b4>  // b.plast
    84e4:	b0000020 	adrp	x0, d000 <atexit+0x10>
    84e8:	91142000 	add	x0, x0, #0x508
    84ec:	97ffee69 	bl	3e90 <fwp_trap>
    84f0:	72003c7f 	tst	w3, #0xffff
    84f4:	54fff4e1 	b.ne	8390 <fwp_hof0.constprop.0+0x100>  // b.any
    84f8:	17ffff9b 	b	8364 <fwp_hof0.constprop.0+0xd4>
    84fc:	72003c3f 	tst	w1, #0xffff
    8500:	54fffb81 	b.ne	8470 <fwp_hof0.constprop.0+0x1e0>  // b.any
    8504:	aa1403e0 	mov	x0, x20
    8508:	17ffffc8 	b	8428 <fwp_hof0.constprop.0+0x198>
    850c:	d53bd040 	mrs	x0, tpidr_el0
    8510:	91400000 	add	x0, x0, #0x0, lsl #12
    8514:	91004000 	add	x0, x0, #0x10
    8518:	f9400000 	ldr	x0, [x0]
    851c:	b4000080 	cbz	x0, 852c <fwp_hof0.constprop.0+0x29c>
    8520:	aa1303e1 	mov	x1, x19
    8524:	97ffefd7 	bl	4480 <fwp_closure_drop_push>
    8528:	17ffffe6 	b	84c0 <fwp_hof0.constprop.0+0x230>
    852c:	aa1303e0 	mov	x0, x19
    8530:	97fff019 	bl	4594 <fwp_closure_drop.part.0>
    8534:	17ffffe3 	b	84c0 <fwp_hof0.constprop.0+0x230>
    8538:	72003c3f 	tst	w1, #0xffff
    853c:	54fffc21 	b.ne	84c0 <fwp_hof0.constprop.0+0x230>  // b.any
    8540:	17ffffd8 	b	84a0 <fwp_hof0.constprop.0+0x210>
    8544:	aa0103f7 	mov	x23, x1
    8548:	9100c2b4 	add	x20, x21, #0x30
    854c:	b942f680 	ldr	w0, [x20, #756]
    8550:	340021c0 	cbz	w0, 8988 <fwp_hof0.constprop.0+0x6f8>
    8554:	9100c2a0 	add	x0, x21, #0x30
    8558:	f9404002 	ldr	x2, [x0, #128]
    855c:	f9404c14 	ldr	x20, [x0, #152]
    8560:	eb02029f 	cmp	x20, x2
    8564:	540006aa 	b.ge	8638 <fwp_hof0.constprop.0+0x3a8>  // b.tcont
    8568:	f9401aa1 	ldr	x1, [x21, #48]
    856c:	8b140680 	add	x0, x20, x20, lsl #1
    8570:	528fffc4 	mov	w4, #0x7ffe                	// #32766
    8574:	8b000a80 	add	x0, x20, x0, lsl #2
    8578:	8b000c20 	add	x0, x1, x0, lsl #3
    857c:	d503201f 	nop
    8580:	b9400401 	ldr	w1, [x0, #4]
    8584:	35000081 	cbnz	w1, 8594 <fwp_hof0.constprop.0+0x304>
    8588:	b9400001 	ldr	w1, [x0]
    858c:	6b04003f 	cmp	w1, w4
    8590:	54000549 	b.ls	8638 <fwp_hof0.constprop.0+0x3a8>  // b.plast
    8594:	91000694 	add	x20, x20, #0x1
    8598:	9101a000 	add	x0, x0, #0x68
    859c:	eb02029f 	cmp	x20, x2
    85a0:	54ffff01 	b.ne	8580 <fwp_hof0.constprop.0+0x2f0>  // b.any
    85a4:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    85a8:	eb00005f 	cmp	x2, x0
    85ac:	54003c8c 	b.gt	8d3c <fwp_hof0.constprop.0+0xaac>
    85b0:	9100c2a0 	add	x0, x21, #0x30
    85b4:	f9401aa8 	ldr	x8, [x21, #48]
    85b8:	f9404800 	ldr	x0, [x0, #144]
    85bc:	eb02001f 	cmp	x0, x2
    85c0:	54000241 	b.ne	8608 <fwp_hof0.constprop.0+0x378>  // b.any
    85c4:	b4004702 	cbz	x2, 8ea4 <fwp_hof0.constprop.0+0xc14>
    85c8:	d37ff844 	lsl	x4, x2, #1
    85cc:	d29fffe0 	mov	x0, #0xffff                	// #65535
    85d0:	eb00009f 	cmp	x4, x0
    85d4:	9a80d084 	csel	x4, x4, x0, le
    85d8:	8b040481 	add	x1, x4, x4, lsl #1
    85dc:	8b010881 	add	x1, x4, x1, lsl #2
    85e0:	d37df021 	lsl	x1, x1, #3
    85e4:	aa0803e0 	mov	x0, x8
    85e8:	a9030be4 	stp	x4, x2, [sp, #48]
    85ec:	97ffe8a1 	bl	2870 <realloc@plt>
    85f0:	a9430be4 	ldp	x4, x2, [sp, #48]
    85f4:	aa0003e8 	mov	x8, x0
    85f8:	b40071c0 	cbz	x0, 9430 <fwp_hof0.constprop.0+0x11a0>
    85fc:	9100c2a0 	add	x0, x21, #0x30
    8600:	f9001aa8 	str	x8, [x21, #48]
    8604:	f9004804 	str	x4, [x0, #144]
    8608:	8b020440 	add	x0, x2, x2, lsl #1
    860c:	9100c2a1 	add	x1, x21, #0x30
    8610:	4f000400 	movi	v0.4s, #0x0
    8614:	91000444 	add	x4, x2, #0x1
    8618:	8b000840 	add	x0, x2, x0, lsl #2
    861c:	f9004024 	str	x4, [x1, #128]
    8620:	8b000d00 	add	x0, x8, x0, lsl #3
    8624:	ad000000 	stp	q0, q0, [x0]
    8628:	ad010000 	stp	q0, q0, [x0, #32]
    862c:	ad020000 	stp	q0, q0, [x0, #64]
    8630:	f900301f 	str	xzr, [x0, #96]
    8634:	14000004 	b	8644 <fwp_hof0.constprop.0+0x3b4>
    8638:	eb02029f 	cmp	x20, x2
    863c:	54fffb40 	b.eq	85a4 <fwp_hof0.constprop.0+0x314>  // b.none
    8640:	f9401aa8 	ldr	x8, [x21, #48]
    8644:	8b140684 	add	x4, x20, x20, lsl #1
    8648:	b0000020 	adrp	x0, d000 <atexit+0x10>
    864c:	9104e000 	add	x0, x0, #0x138
    8650:	8b040a84 	add	x4, x20, x4, lsl #2
    8654:	8b040d04 	add	x4, x8, x4, lsl #3
    8658:	a90323e4 	stp	x4, x8, [sp, #48]
    865c:	f900309f 	str	xzr, [x4, #96]
    8660:	97ffe8ec 	bl	2a10 <getenv@plt>
    8664:	a94323e4 	ldp	x4, x8, [sp, #48]
    8668:	b4000080 	cbz	x0, 8678 <fwp_hof0.constprop.0+0x3e8>
    866c:	39400001 	ldrb	w1, [x0]
    8670:	7100c03f 	cmp	w1, #0x30
    8674:	54000720 	b.eq	8758 <fwp_hof0.constprop.0+0x4c8>  // b.none
    8678:	9100c2a0 	add	x0, x21, #0x30
    867c:	f9403801 	ldr	x1, [x0, #112]
    8680:	b50033e1 	cbnz	x1, 8cfc <fwp_hof0.constprop.0+0xa6c>
    8684:	9100c2a0 	add	x0, x21, #0x30
    8688:	2f000400 	mvni	v0.2s, #0x0
    868c:	b9400087 	ldr	w7, [x4]
    8690:	91000689 	add	x9, x20, #0x1
    8694:	52800022 	mov	w2, #0x1                   	// #1
    8698:	a900dc97 	stp	x23, x23, [x4, #8]
    869c:	110004e7 	add	w7, w7, #0x1
    86a0:	f9416001 	ldr	x1, [x0, #704]
    86a4:	29000887 	stp	w7, w2, [x4]
    86a8:	f900289f 	str	xzr, [x4, #80]
    86ac:	f9004c09 	str	x9, [x0, #152]
    86b0:	fd002c80 	str	d0, [x4, #88]
    86b4:	b40031e1 	cbz	x1, 8cf0 <fwp_hof0.constprop.0+0xa60>
    86b8:	91064306 	add	x6, x24, #0x190
    86bc:	14000003 	b	86c8 <fwp_hof0.constprop.0+0x438>
    86c0:	f9400021 	ldr	x1, [x1]
    86c4:	b4003161 	cbz	x1, 8cf0 <fwp_hof0.constprop.0+0xa60>
    86c8:	f9400420 	ldr	x0, [x1, #8]
    86cc:	eb06001f 	cmp	x0, x6
    86d0:	54ffff81 	b.ne	86c0 <fwp_hof0.constprop.0+0x430>  // b.any
    86d4:	f9400820 	ldr	x0, [x1, #16]
    86d8:	2a1403e2 	mov	w2, w20
    86dc:	b9400001 	ldr	w1, [x0]
    86e0:	f9002880 	str	x0, [x4, #80]
    86e4:	b9005c81 	str	w1, [x4, #92]
    86e8:	37f80081 	tbnz	w1, #31, 86f8 <fwp_hof0.constprop.0+0x468>
    86ec:	52800d04 	mov	w4, #0x68                  	// #104
    86f0:	9b242021 	smaddl	x1, w1, w4, x8
    86f4:	b9005834 	str	w20, [x1, #88]
    86f8:	b9000002 	str	w2, [x0]
    86fc:	aa1903e0 	mov	x0, x25
    8700:	d2800002 	mov	x2, #0x0                   	// #0
    8704:	b4001519 	cbz	x25, 89a4 <fwp_hof0.constprop.0+0x714>
    8708:	f9400800 	ldr	x0, [x0, #16]
    870c:	91000442 	add	x2, x2, #0x1
    8710:	b5ffffc0 	cbnz	x0, 8708 <fwp_hof0.constprop.0+0x478>
    8714:	aa1903e1 	mov	x1, x25
    8718:	f9400821 	ldr	x1, [x1, #16]
    871c:	91000400 	add	x0, x0, #0x1
    8720:	b5ffffc1 	cbnz	x1, 8718 <fwp_hof0.constprop.0+0x488>
    8724:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    8728:	eb01001f 	cmp	x0, x1
    872c:	54000108 	b.hi	874c <fwp_hof0.constprop.0+0x4bc>  // b.pmore
    8730:	f100005f 	cmp	x2, #0x0
    8734:	5400138d 	b.le	89a4 <fwp_hof0.constprop.0+0x714>
    8738:	eb00005f 	cmp	x2, x0
    873c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8740:	9a809057 	csel	x23, x2, x0, ls	// ls = plast
    8744:	eb0102ff 	cmp	x23, x1
    8748:	540025e9 	b.ls	8c04 <fwp_hof0.constprop.0+0x974>  // b.plast
    874c:	b0000020 	adrp	x0, d000 <atexit+0x10>
    8750:	91102000 	add	x0, x0, #0x408
    8754:	97ffedcf 	bl	3e90 <fwp_trap>
    8758:	39400400 	ldrb	w0, [x0, #1]
    875c:	34fff940 	cbz	w0, 8684 <fwp_hof0.constprop.0+0x3f4>
    8760:	17ffffc6 	b	8678 <fwp_hof0.constprop.0+0x3e8>
    8764:	f9401be0 	ldr	x0, [sp, #48]
    8768:	d00000a2 	adrp	x2, 1e000 <__FRAME_END__+0xefd0>
    876c:	910aa042 	add	x2, x2, #0x2a8
    8770:	aa1903e1 	mov	x1, x25
    8774:	91014042 	add	x2, x2, #0x50
    8778:	52800023 	mov	w3, #0x1                   	// #1
    877c:	aa1903f4 	mov	x20, x25
    8780:	aa1b03f7 	mov	x23, x27
    8784:	a94267fb 	ldp	x27, x25, [sp, #32]
    8788:	a90c7fff 	stp	xzr, xzr, [sp, #192]
    878c:	f9006bff 	str	xzr, [sp, #208]
    8790:	97fffac4 	bl	72a0 <fwp_write>
    8794:	a94c0be3 	ldp	x3, x2, [sp, #192]
    8798:	b0000020 	adrp	x0, d000 <atexit+0x10>
    879c:	91294000 	add	x0, x0, #0xa50
    87a0:	f100007f 	cmp	x3, #0x0
    87a4:	9a830003 	csel	x3, x0, x3, eq	// eq = none
    87a8:	b100285f 	cmn	x2, #0xa
    87ac:	54008fe8 	b.hi	99a8 <fwp_hof0.constprop.0+0x1718>  // b.pmore
    87b0:	91002440 	add	x0, x2, #0x9
    87b4:	52800021 	mov	w1, #0x1                   	// #1
    87b8:	f9000be2 	str	x2, [sp, #16]
    87bc:	f90013e3 	str	x3, [sp, #32]
    87c0:	97fff12c 	bl	4c70 <fwp_heap_alloc>
    87c4:	f94013e3 	ldr	x3, [sp, #32]
    87c8:	aa0003fa 	mov	x26, x0
    87cc:	f9400be2 	ldr	x2, [sp, #16]
    87d0:	aa0303e1 	mov	x1, x3
    87d4:	aa0003e3 	mov	x3, x0
    87d8:	f90013e2 	str	x2, [sp, #32]
    87dc:	f8008462 	str	x2, [x3], #8
    87e0:	aa0303e0 	mov	x0, x3
    87e4:	f9000be3 	str	x3, [sp, #16]
    87e8:	97ffe7ba 	bl	26d0 <memcpy@plt>
    87ec:	f94013e2 	ldr	x2, [sp, #32]
    87f0:	8b020342 	add	x2, x26, x2
    87f4:	3900205f 	strb	wzr, [x2, #8]
    87f8:	f94063e0 	ldr	x0, [sp, #192]
    87fc:	97ffe851 	bl	2940 <free@plt>
    8800:	911502c2 	add	x2, x22, #0x540
    8804:	f9400be3 	ldr	x3, [sp, #16]
    8808:	f949d841 	ldr	x1, [x2, #5040]
    880c:	f949ec40 	ldr	x0, [x2, #5080]
    8810:	cb010341 	sub	x1, x26, x1
    8814:	eb00403f 	cmp	x1, x0, lsl #16
    8818:	54000322 	b.cs	887c <fwp_hof0.constprop.0+0x5ec>  // b.hs, b.nlast
    881c:	d350fc20 	lsr	x0, x1, #16
    8820:	f949fc45 	ldr	x5, [x2, #5112]
    8824:	8b000800 	add	x0, x0, x0, lsl #2
    8828:	d37df002 	lsl	x2, x0, #3
    882c:	8b0200a4 	add	x4, x5, x2
    8830:	f9401080 	ldr	x0, [x4, #32]
    8834:	b4000240 	cbz	x0, 887c <fwp_hof0.constprop.0+0x5ec>
    8838:	386268a2 	ldrb	w2, [x5, x2]
    883c:	7100085f 	cmp	w2, #0x2
    8840:	54008c60 	b.eq	99cc <fwp_hof0.constprop.0+0x173c>  // b.none
    8844:	7100045f 	cmp	w2, #0x1
    8848:	540001a1 	b.ne	887c <fwp_hof0.constprop.0+0x5ec>  // b.any
    884c:	29430885 	ldp	w5, w2, [x4, #24]
    8850:	92403c21 	and	x1, x1, #0xffff
    8854:	9b057c21 	mul	x1, x1, x5
    8858:	d360fc21 	lsr	x1, x1, #32
    885c:	eb02003f 	cmp	x1, x2
    8860:	540000e2 	b.cs	887c <fwp_hof0.constprop.0+0x5ec>  // b.hs, b.nlast
    8864:	8b010000 	add	x0, x0, x1
    8868:	39400001 	ldrb	w1, [x0]
    886c:	7103fc3f 	cmp	w1, #0xff
    8870:	54008b40 	b.eq	99d8 <fwp_hof0.constprop.0+0x1748>  // b.none
    8874:	52800021 	mov	w1, #0x1                   	// #1
    8878:	39000001 	strb	w1, [x0]
    887c:	aa1403e0 	mov	x0, x20
    8880:	f9000be3 	str	x3, [sp, #16]
    8884:	97fff4a3 	bl	5b10 <fwp_drop0>
    8888:	9100c2b4 	add	x20, x21, #0x30
    888c:	f9400be3 	ldr	x3, [sp, #16]
    8890:	d2800021 	mov	x1, #0x1                   	// #1
    8894:	f9400342 	ldr	x2, [x26]
    8898:	aa0303e0 	mov	x0, x3
    889c:	f9400683 	ldr	x3, [x20, #8]
    88a0:	97ffe838 	bl	2980 <fwrite@plt>
    88a4:	f9400681 	ldr	x1, [x20, #8]
    88a8:	52800140 	mov	w0, #0xa                   	// #10
    88ac:	97ffe7bd 	bl	27a0 <fputc@plt>
    88b0:	911502c2 	add	x2, x22, #0x540
    88b4:	f949d841 	ldr	x1, [x2, #5040]
    88b8:	f949ec40 	ldr	x0, [x2, #5080]
    88bc:	cb010341 	sub	x1, x26, x1
    88c0:	eb00403f 	cmp	x1, x0, lsl #16
    88c4:	54000382 	b.cs	8934 <fwp_hof0.constprop.0+0x6a4>  // b.hs, b.nlast
    88c8:	d350fc20 	lsr	x0, x1, #16
    88cc:	f949fc44 	ldr	x4, [x2, #5112]
    88d0:	8b000800 	add	x0, x0, x0, lsl #2
    88d4:	d37df002 	lsl	x2, x0, #3
    88d8:	8b020083 	add	x3, x4, x2
    88dc:	f9401074 	ldr	x20, [x3, #32]
    88e0:	b40002b4 	cbz	x20, 8934 <fwp_hof0.constprop.0+0x6a4>
    88e4:	38626882 	ldrb	w2, [x4, x2]
    88e8:	7100085f 	cmp	w2, #0x2
    88ec:	540086a0 	b.eq	99c0 <fwp_hof0.constprop.0+0x1730>  // b.none
    88f0:	7100045f 	cmp	w2, #0x1
    88f4:	54000201 	b.ne	8934 <fwp_hof0.constprop.0+0x6a4>  // b.any
    88f8:	29430062 	ldp	w2, w0, [x3, #24]
    88fc:	92403c21 	and	x1, x1, #0xffff
    8900:	9b027c21 	mul	x1, x1, x2
    8904:	d360fc21 	lsr	x1, x1, #32
    8908:	eb00003f 	cmp	x1, x0
    890c:	54000142 	b.cs	8934 <fwp_hof0.constprop.0+0x6a4>  // b.hs, b.nlast
    8910:	8b010294 	add	x20, x20, x1
    8914:	39400281 	ldrb	w1, [x20]
    8918:	340000e1 	cbz	w1, 8934 <fwp_hof0.constprop.0+0x6a4>
    891c:	7100043f 	cmp	w1, #0x1
    8920:	540084a0 	b.eq	99b4 <fwp_hof0.constprop.0+0x1724>  // b.none
    8924:	7103fc3f 	cmp	w1, #0xff
    8928:	54008640 	b.eq	99f0 <fwp_hof0.constprop.0+0x1760>  // b.none
    892c:	51000421 	sub	w1, w1, #0x1
    8930:	39000281 	strb	w1, [x20]
    8934:	f9400fe0 	ldr	x0, [sp, #24]
    8938:	f9400800 	ldr	x0, [x0, #16]
    893c:	f9000fe0 	str	x0, [sp, #24]
    8940:	b5ffce00 	cbnz	x0, 8300 <fwp_hof0.constprop.0+0x70>
    8944:	a95253f3 	ldp	x19, x20, [sp, #288]
    8948:	a9535bf5 	ldp	x21, x22, [sp, #304]
    894c:	a95463f7 	ldp	x23, x24, [sp, #320]
    8950:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8954:	d503201f 	nop
    8958:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    895c:	f947f400 	ldr	x0, [x0, #4072]
    8960:	f94087e2 	ldr	x2, [sp, #264]
    8964:	f9400001 	ldr	x1, [x0]
    8968:	eb010042 	subs	x2, x2, x1
    896c:	d2800001 	mov	x1, #0x0                   	// #0
    8970:	54009b01 	b.ne	9cd0 <fwp_hof0.constprop.0+0x1a40>  // b.any
    8974:	a9517bfd 	ldp	x29, x30, [sp, #272]
    8978:	d2800000 	mov	x0, #0x0                   	// #0
    897c:	a95673fb 	ldp	x27, x28, [sp, #352]
    8980:	9105c3ff 	add	sp, sp, #0x170
    8984:	d65f03c0 	ret
    8988:	d0ffffe0 	adrp	x0, 6000 <fwp_owned_tape_release+0x9c>
    898c:	91024000 	add	x0, x0, #0x90
    8990:	94001198 	bl	cff0 <atexit>
    8994:	350054e0 	cbnz	w0, 9430 <fwp_hof0.constprop.0+0x11a0>
    8998:	52800020 	mov	w0, #0x1                   	// #1
    899c:	b902f680 	str	w0, [x20, #756]
    89a0:	17fffeed 	b	8554 <fwp_hof0.constprop.0+0x2c4>
    89a4:	d3707ce7 	ubfiz	x7, x7, #16, #32
    89a8:	52800041 	mov	w1, #0x2                   	// #2
    89ac:	aa0900e0 	orr	x0, x7, x9
    89b0:	f9001be0 	str	x0, [sp, #48]
    89b4:	d2800100 	mov	x0, #0x8                   	// #8
    89b8:	97fff0ae 	bl	4c70 <fwp_heap_alloc>
    89bc:	aa0003e9 	mov	x9, x0
    89c0:	911502c0 	add	x0, x22, #0x540
    89c4:	aa0903ea 	mov	x10, x9
    89c8:	f900013f 	str	xzr, [x9]
    89cc:	f949d801 	ldr	x1, [x0, #5040]
    89d0:	f949ec00 	ldr	x0, [x0, #5080]
    89d4:	cb010121 	sub	x1, x9, x1
    89d8:	eb00403f 	cmp	x1, x0, lsl #16
    89dc:	540013c2 	b.cs	8c54 <fwp_hof0.constprop.0+0x9c4>  // b.hs, b.nlast
    89e0:	d2800017 	mov	x23, #0x0                   	// #0
    89e4:	911502c2 	add	x2, x22, #0x540
    89e8:	d350fc20 	lsr	x0, x1, #16
    89ec:	8b000800 	add	x0, x0, x0, lsl #2
    89f0:	f949fc46 	ldr	x6, [x2, #5112]
    89f4:	d37df002 	lsl	x2, x0, #3
    89f8:	8b0200c4 	add	x4, x6, x2
    89fc:	f9401094 	ldr	x20, [x4, #32]
    8a00:	b4000254 	cbz	x20, 8a48 <fwp_hof0.constprop.0+0x7b8>
    8a04:	386268c2 	ldrb	w2, [x6, x2]
    8a08:	7100085f 	cmp	w2, #0x2
    8a0c:	540012a0 	b.eq	8c60 <fwp_hof0.constprop.0+0x9d0>  // b.none
    8a10:	7100045f 	cmp	w2, #0x1
    8a14:	540001a1 	b.ne	8a48 <fwp_hof0.constprop.0+0x7b8>  // b.any
    8a18:	29430886 	ldp	w6, w2, [x4, #24]
    8a1c:	92403c21 	and	x1, x1, #0xffff
    8a20:	9b067c21 	mul	x1, x1, x6
    8a24:	d360fc21 	lsr	x1, x1, #32
    8a28:	eb02003f 	cmp	x1, x2
    8a2c:	540000e2 	b.cs	8a48 <fwp_hof0.constprop.0+0x7b8>  // b.hs, b.nlast
    8a30:	8b010294 	add	x20, x20, x1
    8a34:	39400281 	ldrb	w1, [x20]
    8a38:	7103fc3f 	cmp	w1, #0xff
    8a3c:	540049c0 	b.eq	9374 <fwp_hof0.constprop.0+0x10e4>  // b.none
    8a40:	52800021 	mov	w1, #0x1                   	// #1
    8a44:	39000281 	strb	w1, [x20]
    8a48:	b4000257 	cbz	x23, 8a90 <fwp_hof0.constprop.0+0x800>
    8a4c:	f9401be0 	ldr	x0, [sp, #48]
    8a50:	aa1903e2 	mov	x2, x25
    8a54:	f9400728 	ldr	x8, [x25, #8]
    8a58:	91002124 	add	x4, x9, #0x8
    8a5c:	d3607c07 	lsl	x7, x0, #32
    8a60:	d2800001 	mov	x1, #0x0                   	// #0
    8a64:	aa0703e6 	mov	x6, x7
    8a68:	14000005 	b	8a7c <fwp_hof0.constprop.0+0x7ec>
    8a6c:	f9400448 	ldr	x8, [x2, #8]
    8a70:	ab0100e6 	adds	x6, x7, x1
    8a74:	91004084 	add	x4, x4, #0x10
    8a78:	54009686 	b.vs	9d48 <fwp_hof0.constprop.0+0x1ab8>
    8a7c:	a9001888 	stp	x8, x6, [x4]
    8a80:	91000421 	add	x1, x1, #0x1
    8a84:	f9400842 	ldr	x2, [x2, #16]
    8a88:	eb17003f 	cmp	x1, x23
    8a8c:	54ffff03 	b.cc	8a6c <fwp_hof0.constprop.0+0x7dc>  // b.lo, b.ul, b.last
    8a90:	f9400120 	ldr	x0, [x9]
    8a94:	f100041f 	cmp	x0, #0x1
    8a98:	54000de9 	b.ls	8c54 <fwp_hof0.constprop.0+0x9c4>  // b.plast
    8a9c:	d341fc17 	lsr	x23, x0, #1
    8aa0:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    8aa4:	d10006e0 	sub	x0, x23, #0x1
    8aa8:	eb01001f 	cmp	x0, x1
    8aac:	54ffe508 	b.hi	874c <fwp_hof0.constprop.0+0x4bc>  // b.pmore
    8ab0:	b4000d20 	cbz	x0, 8c54 <fwp_hof0.constprop.0+0x9c4>
    8ab4:	91002134 	add	x20, x9, #0x8
    8ab8:	d1002121 	sub	x1, x9, #0x8
    8abc:	8b171037 	add	x23, x1, x23, lsl #4
    8ac0:	a903cfea 	stp	x10, x19, [sp, #56]
    8ac4:	aa1403f3 	mov	x19, x20
    8ac8:	aa0003f4 	mov	x20, x0
    8acc:	f90027e9 	str	x9, [sp, #72]
    8ad0:	f9400660 	ldr	x0, [x19, #8]
    8ad4:	f9400e61 	ldr	x1, [x19, #24]
    8ad8:	fd400260 	ldr	d0, [x19]
    8adc:	fd400a61 	ldr	d1, [x19, #16]
    8ae0:	97fff1d1 	bl	5224 <w120>
    8ae4:	a9000660 	stp	x0, x1, [x19]
    8ae8:	91004273 	add	x19, x19, #0x10
    8aec:	eb17027f 	cmp	x19, x23
    8af0:	54ffff01 	b.ne	8ad0 <fwp_hof0.constprop.0+0x840>  // b.any
    8af4:	a94427f3 	ldp	x19, x9, [sp, #64]
    8af8:	d37ffa81 	lsl	x1, x20, #1
    8afc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    8b00:	d2800014 	mov	x20, #0x0                   	// #0
    8b04:	aa1703e0 	mov	x0, x23
    8b08:	aa1403f7 	mov	x23, x20
    8b0c:	aa0103f4 	mov	x20, x1
    8b10:	a9046be9 	stp	x9, x26, [sp, #64]
    8b14:	aa0903e2 	mov	x2, x9
    8b18:	aa1303fa 	mov	x26, x19
    8b1c:	f8010441 	str	x1, [x2], #16
    8b20:	aa0203f3 	mov	x19, x2
    8b24:	d503201f 	nop
    8b28:	f8777a61 	ldr	x1, [x19, x23, lsl #3]
    8b2c:	91000af7 	add	x23, x23, #0x2
    8b30:	97fff16c 	bl	50e0 <f141.constprop.0>
    8b34:	eb1402ff 	cmp	x23, x20
    8b38:	54ffff83 	b.cc	8b28 <fwp_hof0.constprop.0+0x898>  // b.lo, b.ul, b.last
    8b3c:	a943a7ea 	ldp	x10, x9, [sp, #56]
    8b40:	aa1a03f3 	mov	x19, x26
    8b44:	f94027fa 	ldr	x26, [sp, #72]
    8b48:	aa0003f7 	mov	x23, x0
    8b4c:	911502c4 	add	x4, x22, #0x540
    8b50:	aa0403f4 	mov	x20, x4
    8b54:	f949d881 	ldr	x1, [x4, #5040]
    8b58:	f949ec80 	ldr	x0, [x4, #5080]
    8b5c:	cb010121 	sub	x1, x9, x1
    8b60:	eb00403f 	cmp	x1, x0, lsl #16
    8b64:	540003a2 	b.cs	8bd8 <fwp_hof0.constprop.0+0x948>  // b.hs, b.nlast
    8b68:	d350fc20 	lsr	x0, x1, #16
    8b6c:	f949fe86 	ldr	x6, [x20, #5112]
    8b70:	8b000800 	add	x0, x0, x0, lsl #2
    8b74:	d37df002 	lsl	x2, x0, #3
    8b78:	8b0200c3 	add	x3, x6, x2
    8b7c:	f9401060 	ldr	x0, [x3, #32]
    8b80:	b40002c0 	cbz	x0, 8bd8 <fwp_hof0.constprop.0+0x948>
    8b84:	386268c2 	ldrb	w2, [x6, x2]
    8b88:	7100085f 	cmp	w2, #0x2
    8b8c:	54001920 	b.eq	8eb0 <fwp_hof0.constprop.0+0xc20>  // b.none
    8b90:	7100045f 	cmp	w2, #0x1
    8b94:	54000221 	b.ne	8bd8 <fwp_hof0.constprop.0+0x948>  // b.any
    8b98:	29430864 	ldp	w4, w2, [x3, #24]
    8b9c:	92403c21 	and	x1, x1, #0xffff
    8ba0:	9b047c21 	mul	x1, x1, x4
    8ba4:	d360fc21 	lsr	x1, x1, #32
    8ba8:	eb02003f 	cmp	x1, x2
    8bac:	54000162 	b.cs	8bd8 <fwp_hof0.constprop.0+0x948>  // b.hs, b.nlast
    8bb0:	8b010000 	add	x0, x0, x1
    8bb4:	39400001 	ldrb	w1, [x0]
    8bb8:	34000101 	cbz	w1, 8bd8 <fwp_hof0.constprop.0+0x948>
    8bbc:	7100043f 	cmp	w1, #0x1
    8bc0:	54000560 	b.eq	8c6c <fwp_hof0.constprop.0+0x9dc>  // b.none
    8bc4:	7103fc3f 	cmp	w1, #0xff
    8bc8:	54003ec0 	b.eq	93a0 <fwp_hof0.constprop.0+0x1110>  // b.none
    8bcc:	51000421 	sub	w1, w1, #0x1
    8bd0:	39000001 	strb	w1, [x0]
    8bd4:	d503201f 	nop
    8bd8:	b98033f4 	ldrsw	x20, [sp, #48]
    8bdc:	aa1403e0 	mov	x0, x20
    8be0:	97ffeeb0 	bl	46a0 <fwp_tape_of>
    8be4:	f9403002 	ldr	x2, [x0, #96]
    8be8:	aa0003e6 	mov	x6, x0
    8bec:	b4000f62 	cbz	x2, 8dd8 <fwp_hof0.constprop.0+0xb48>
    8bf0:	b0000020 	adrp	x0, d000 <atexit+0x10>
    8bf4:	910de000 	add	x0, x0, #0x378
    8bf8:	97ffeca6 	bl	3e90 <fwp_trap>
    8bfc:	d2800017 	mov	x23, #0x0                   	// #0
    8c00:	17fffe52 	b	8548 <fwp_hof0.constprop.0+0x2b8>
    8c04:	d37ffae2 	lsl	x2, x23, #1
    8c08:	d3707ce7 	ubfiz	x7, x7, #16, #32
    8c0c:	91000440 	add	x0, x2, #0x1
    8c10:	aa0900e1 	orr	x1, x7, x9
    8c14:	aa0203f4 	mov	x20, x2
    8c18:	f9001be1 	str	x1, [sp, #48]
    8c1c:	d37df000 	lsl	x0, x0, #3
    8c20:	52800041 	mov	w1, #0x2                   	// #2
    8c24:	97fff013 	bl	4c70 <fwp_heap_alloc>
    8c28:	aa0003e9 	mov	x9, x0
    8c2c:	911502c1 	add	x1, x22, #0x540
    8c30:	aa0003ea 	mov	x10, x0
    8c34:	aa0103e0 	mov	x0, x1
    8c38:	f9000134 	str	x20, [x9]
    8c3c:	f949d821 	ldr	x1, [x1, #5040]
    8c40:	f949ec00 	ldr	x0, [x0, #5080]
    8c44:	cb010121 	sub	x1, x9, x1
    8c48:	eb00403f 	cmp	x1, x0, lsl #16
    8c4c:	54ffecc3 	b.cc	89e4 <fwp_hof0.constprop.0+0x754>  // b.lo, b.ul, b.last
    8c50:	b5ffeff7 	cbnz	x23, 8a4c <fwp_hof0.constprop.0+0x7bc>
    8c54:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    8c58:	f900013f 	str	xzr, [x9]
    8c5c:	17ffffbc 	b	8b4c <fwp_hof0.constprop.0+0x8bc>
    8c60:	72003c3f 	tst	w1, #0xffff
    8c64:	54ffef21 	b.ne	8a48 <fwp_hof0.constprop.0+0x7b8>  // b.any
    8c68:	17ffff73 	b	8a34 <fwp_hof0.constprop.0+0x7a4>
    8c6c:	f9400143 	ldr	x3, [x10]
    8c70:	aa0a03e4 	mov	x4, x10
    8c74:	f949ee82 	ldr	x2, [x20, #5080]
    8c78:	f949da81 	ldr	x1, [x20, #5040]
    8c7c:	d370bc47 	lsl	x7, x2, #16
    8c80:	cb010140 	sub	x0, x10, x1
    8c84:	b7f811c3 	tbnz	x3, #63, 8ebc <fwp_hof0.constprop.0+0xc2c>
    8c88:	eb07001f 	cmp	x0, x7
    8c8c:	54fffa62 	b.cs	8bd8 <fwp_hof0.constprop.0+0x948>  // b.hs, b.nlast
    8c90:	d350fc01 	lsr	x1, x0, #16
    8c94:	8b010821 	add	x1, x1, x1, lsl #2
    8c98:	d37df021 	lsl	x1, x1, #3
    8c9c:	8b0100c4 	add	x4, x6, x1
    8ca0:	f9401082 	ldr	x2, [x4, #32]
    8ca4:	b4fff9a2 	cbz	x2, 8bd8 <fwp_hof0.constprop.0+0x948>
    8ca8:	386168c1 	ldrb	w1, [x6, x1]
    8cac:	7100083f 	cmp	w1, #0x2
    8cb0:	540034c0 	b.eq	9348 <fwp_hof0.constprop.0+0x10b8>  // b.none
    8cb4:	7100043f 	cmp	w1, #0x1
    8cb8:	54fff901 	b.ne	8bd8 <fwp_hof0.constprop.0+0x948>  // b.any
    8cbc:	29430486 	ldp	w6, w1, [x4, #24]
    8cc0:	92403c00 	and	x0, x0, #0xffff
    8cc4:	9b067c00 	mul	x0, x0, x6
    8cc8:	d360fc00 	lsr	x0, x0, #32
    8ccc:	eb01001f 	cmp	x0, x1
    8cd0:	54fff842 	b.cs	8bd8 <fwp_hof0.constprop.0+0x948>  // b.hs, b.nlast
    8cd4:	8b000042 	add	x2, x2, x0
    8cd8:	39400040 	ldrb	w0, [x2]
    8cdc:	7100041f 	cmp	w0, #0x1
    8ce0:	54fff7c1 	b.ne	8bd8 <fwp_hof0.constprop.0+0x948>  // b.any
    8ce4:	aa0a03e0 	mov	x0, x10
    8ce8:	97ffed26 	bl	4180 <fwp_mem_free>
    8cec:	17ffffbb 	b	8bd8 <fwp_hof0.constprop.0+0x948>
    8cf0:	b0000020 	adrp	x0, d000 <atexit+0x10>
    8cf4:	9116a000 	add	x0, x0, #0x5a8
    8cf8:	97ffec66 	bl	3e90 <fwp_trap>
    8cfc:	3cc38002 	ldur	q2, [x0, #56]
    8d00:	9100e001 	add	x1, x0, #0x38
    8d04:	3cc48001 	ldur	q1, [x0, #72]
    8d08:	f900381f 	str	xzr, [x0, #112]
    8d0c:	4f000400 	movi	v0.4s, #0x0
    8d10:	ad010482 	stp	q2, q1, [x4, #32]
    8d14:	f9403400 	ldr	x0, [x0, #104]
    8d18:	f9002480 	str	x0, [x4, #72]
    8d1c:	f9401020 	ldr	x0, [x1, #32]
    8d20:	f9002080 	str	x0, [x4, #64]
    8d24:	f9401420 	ldr	x0, [x1, #40]
    8d28:	f9000c80 	str	x0, [x4, #24]
    8d2c:	f900183f 	str	xzr, [x1, #48]
    8d30:	ad000020 	stp	q0, q0, [x1]
    8d34:	3d800820 	str	q0, [x1, #32]
    8d38:	17fffe53 	b	8684 <fwp_hof0.constprop.0+0x3f4>
    8d3c:	b0000020 	adrp	x0, d000 <atexit+0x10>
    8d40:	9114a000 	add	x0, x0, #0x528
    8d44:	97ffec53 	bl	3e90 <fwp_trap>
    8d48:	97ffed87 	bl	4364 <fwp_rc_wide_dup>
    8d4c:	911502c0 	add	x0, x22, #0x540
    8d50:	f949ec04 	ldr	x4, [x0, #5080]
    8d54:	f949d801 	ldr	x1, [x0, #5040]
    8d58:	d370bc84 	lsl	x4, x4, #16
    8d5c:	17fffd8d 	b	8390 <fwp_hof0.constprop.0+0x100>
    8d60:	97ffed81 	bl	4364 <fwp_rc_wide_dup>
    8d64:	17fffdb7 	b	8440 <fwp_hof0.constprop.0+0x1b0>
    8d68:	ca544680 	eor	x0, x20, x20, lsr #17
    8d6c:	911502c1 	add	x1, x22, #0x540
    8d70:	ca402400 	eor	x0, x0, x0, lsr #9
    8d74:	92401c00 	and	x0, x0, #0xff
    8d78:	910a2402 	add	x2, x0, #0x289
    8d7c:	8b000c20 	add	x0, x1, x0, lsl #3
    8d80:	8b020c22 	add	x2, x1, x2, lsl #3
    8d84:	f94a2400 	ldr	x0, [x0, #5192]
    8d88:	b50000a0 	cbnz	x0, 8d9c <fwp_hof0.constprop.0+0xb0c>
    8d8c:	14000172 	b	9354 <fwp_hof0.constprop.0+0x10c4>
    8d90:	91004002 	add	x2, x0, #0x10
    8d94:	f9400800 	ldr	x0, [x0, #16]
    8d98:	b4002de0 	cbz	x0, 9354 <fwp_hof0.constprop.0+0x10c4>
    8d9c:	f9400001 	ldr	x1, [x0]
    8da0:	eb14003f 	cmp	x1, x20
    8da4:	54ffff61 	b.ne	8d90 <fwp_hof0.constprop.0+0xb00>  // b.any
    8da8:	f9400041 	ldr	x1, [x2]
    8dac:	f9400420 	ldr	x0, [x1, #8]
    8db0:	d1000400 	sub	x0, x0, #0x1
    8db4:	f9000420 	str	x0, [x1, #8]
    8db8:	f103f81f 	cmp	x0, #0xfe
    8dbc:	54ffb821 	b.ne	84c0 <fwp_hof0.constprop.0+0x230>  // b.any
    8dc0:	39400280 	ldrb	w0, [x20]
    8dc4:	7103fc1f 	cmp	w0, #0xff
    8dc8:	54002e60 	b.eq	9394 <fwp_hof0.constprop.0+0x1104>  // b.none
    8dcc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8dd0:	39000280 	strb	w0, [x20]
    8dd4:	17fffdbb 	b	84c0 <fwp_hof0.constprop.0+0x230>
    8dd8:	97ffe86e 	bl	2f90 <fwp_tape_unlink_scope>
    8ddc:	b90004df 	str	wzr, [x6, #4]
    8de0:	a94288c9 	ldp	x9, x2, [x6, #40]
    8de4:	f9001fe2 	str	x2, [sp, #56]
    8de8:	f9401cc2 	ldr	x2, [x6, #56]
    8dec:	f90023e2 	str	x2, [sp, #64]
    8df0:	b94000c1 	ldr	w1, [x6]
    8df4:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    8df8:	a940acc7 	ldp	x7, x11, [x6, #8]
    8dfc:	a941a0ca 	ldp	x10, x8, [x6, #24]
    8e00:	f94020c4 	ldr	x4, [x6, #64]
    8e04:	f94024c2 	ldr	x2, [x6, #72]
    8e08:	6b00003f 	cmp	w1, w0
    8e0c:	54000108 	b.hi	8e2c <fwp_hof0.constprop.0+0xb9c>  // b.pmore
    8e10:	9100c2a1 	add	x1, x21, #0x30
    8e14:	92403e80 	and	x0, x20, #0xffff
    8e18:	d1000400 	sub	x0, x0, #0x1
    8e1c:	f9404c2c 	ldr	x12, [x1, #152]
    8e20:	eb0c001f 	cmp	x0, x12
    8e24:	5400004a 	b.ge	8e2c <fwp_hof0.constprop.0+0xb9c>  // b.tcont
    8e28:	f9004c20 	str	x0, [x1, #152]
    8e2c:	4f000400 	movi	v0.4s, #0x0
    8e30:	9100c2a1 	add	x1, x21, #0x30
    8e34:	f9401fe0 	ldr	x0, [sp, #56]
    8e38:	f9000cdf 	str	xzr, [x6, #24]
    8e3c:	a9047cdf 	stp	xzr, xzr, [x6, #64]
    8e40:	9102a3e3 	add	x3, sp, #0xa8
    8e44:	3c8080c0 	stur	q0, [x6, #8]
    8e48:	ad0100c0 	stp	q0, q0, [x6, #32]
    8e4c:	f9006be0 	str	x0, [sp, #208]
    8e50:	f94023e0 	ldr	x0, [sp, #64]
    8e54:	f9006fe0 	str	x0, [sp, #216]
    8e58:	f9416020 	ldr	x0, [x1, #704]
    8e5c:	f90057e0 	str	x0, [sp, #168]
    8e60:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    8e64:	9135c000 	add	x0, x0, #0xd70
    8e68:	f90027e3 	str	x3, [sp, #72]
    8e6c:	f9005be0 	str	x0, [sp, #176]
    8e70:	910303e0 	add	x0, sp, #0xc0
    8e74:	f9001be0 	str	x0, [sp, #48]
    8e78:	f9005fe0 	str	x0, [sp, #184]
    8e7c:	a90c27e8 	stp	x8, x9, [sp, #192]
    8e80:	a90e2be4 	stp	x4, x10, [sp, #224]
    8e84:	f9007be2 	str	x2, [sp, #240]
    8e88:	f9016023 	str	x3, [x1, #704]
    8e8c:	b7f826b7 	tbnz	x23, #63, 9360 <fwp_hof0.constprop.0+0x10d0>
    8e90:	eb97829f 	cmp	x20, x23, asr #32
    8e94:	540005c0 	b.eq	8f4c <fwp_hof0.constprop.0+0xcbc>  // b.none
    8e98:	b0000020 	adrp	x0, d000 <atexit+0x10>
    8e9c:	910cc000 	add	x0, x0, #0x330
    8ea0:	97ffebfc 	bl	3e90 <fwp_trap>
    8ea4:	d2800d01 	mov	x1, #0x68                  	// #104
    8ea8:	d2800024 	mov	x4, #0x1                   	// #1
    8eac:	17fffdce 	b	85e4 <fwp_hof0.constprop.0+0x354>
    8eb0:	72003c3f 	tst	w1, #0xffff
    8eb4:	54ffe921 	b.ne	8bd8 <fwp_hof0.constprop.0+0x948>  // b.any
    8eb8:	17ffff3f 	b	8bb4 <fwp_hof0.constprop.0+0x924>
    8ebc:	f940054a 	ldr	x10, [x10, #8]
    8ec0:	eb07001f 	cmp	x0, x7
    8ec4:	540003c2 	b.cs	8f3c <fwp_hof0.constprop.0+0xcac>  // b.hs, b.nlast
    8ec8:	d350fc02 	lsr	x2, x0, #16
    8ecc:	8b020842 	add	x2, x2, x2, lsl #2
    8ed0:	d37df042 	lsl	x2, x2, #3
    8ed4:	8b0200c5 	add	x5, x6, x2
    8ed8:	f94010a3 	ldr	x3, [x5, #32]
    8edc:	b4000303 	cbz	x3, 8f3c <fwp_hof0.constprop.0+0xcac>
    8ee0:	386268c2 	ldrb	w2, [x6, x2]
    8ee4:	7100085f 	cmp	w2, #0x2
    8ee8:	54002500 	b.eq	9388 <fwp_hof0.constprop.0+0x10f8>  // b.none
    8eec:	7100045f 	cmp	w2, #0x1
    8ef0:	54000261 	b.ne	8f3c <fwp_hof0.constprop.0+0xcac>  // b.any
    8ef4:	92403c02 	and	x2, x0, #0xffff
    8ef8:	294300a6 	ldp	w6, w0, [x5, #24]
    8efc:	9b067c42 	mul	x2, x2, x6
    8f00:	d360fc42 	lsr	x2, x2, #32
    8f04:	eb00005f 	cmp	x2, x0
    8f08:	540001a2 	b.cs	8f3c <fwp_hof0.constprop.0+0xcac>  // b.hs, b.nlast
    8f0c:	8b020063 	add	x3, x3, x2
    8f10:	39400060 	ldrb	w0, [x3]
    8f14:	7100041f 	cmp	w0, #0x1
    8f18:	54000121 	b.ne	8f3c <fwp_hof0.constprop.0+0xcac>  // b.any
    8f1c:	aa0403e0 	mov	x0, x4
    8f20:	f9001fea 	str	x10, [sp, #56]
    8f24:	97ffec97 	bl	4180 <fwp_mem_free>
    8f28:	911502c0 	add	x0, x22, #0x540
    8f2c:	f9401fea 	ldr	x10, [sp, #56]
    8f30:	f949ec02 	ldr	x2, [x0, #5080]
    8f34:	f949d801 	ldr	x1, [x0, #5040]
    8f38:	d370bc47 	lsl	x7, x2, #16
    8f3c:	cb010141 	sub	x1, x10, x1
    8f40:	eb0100ff 	cmp	x7, x1
    8f44:	54ffe128 	b.hi	8b68 <fwp_hof0.constprop.0+0x8d8>  // b.pmore
    8f48:	17ffff24 	b	8bd8 <fwp_hof0.constprop.0+0x948>
    8f4c:	92407ee0 	and	x0, x23, #0xffffffff
    8f50:	eb37417f 	cmp	x11, w23, uxtw
    8f54:	540020ad 	b.le	9368 <fwp_hof0.constprop.0+0x10d8>
    8f58:	eb0000ff 	cmp	x7, x0
    8f5c:	9a80c4f4 	csinc	x20, x7, x0, gt
    8f60:	eb14005f 	cmp	x2, x20
    8f64:	5400256a 	b.ge	9410 <fwp_hof0.constprop.0+0x1180>  // b.tcont
    8f68:	f100005f 	cmp	x2, #0x0
    8f6c:	b24077e6 	mov	x6, #0x3fffffff            	// #1073741823
    8f70:	9a941042 	csel	x2, x2, x20, ne	// ne = any
    8f74:	14000004 	b	8f84 <fwp_hof0.constprop.0+0xcf4>
    8f78:	eb06005f 	cmp	x2, x6
    8f7c:	d37ff842 	lsl	x2, x2, #1
    8f80:	9a94d042 	csel	x2, x2, x20, le
    8f84:	eb14005f 	cmp	x2, x20
    8f88:	54ffff8b 	b.lt	8f78 <fwp_hof0.constprop.0+0xce8>  // b.tstop
    8f8c:	a905a3e7 	stp	x7, x8, [sp, #88]
    8f90:	f90037e9 	str	x9, [sp, #104]
    8f94:	b4002d04 	cbz	x4, 9534 <fwp_hof0.constprop.0+0x12a4>
    8f98:	aa0403e0 	mov	x0, x4
    8f9c:	d37df041 	lsl	x1, x2, #3
    8fa0:	f9002be2 	str	x2, [sp, #80]
    8fa4:	97ffe633 	bl	2870 <realloc@plt>
    8fa8:	a9451fe2 	ldp	x2, x7, [sp, #80]
    8fac:	aa0003e4 	mov	x4, x0
    8fb0:	a94627e8 	ldp	x8, x9, [sp, #96]
    8fb4:	b40022e4 	cbz	x4, 9410 <fwp_hof0.constprop.0+0x1180>
    8fb8:	f90073e4 	str	x4, [sp, #224]
    8fbc:	f9007be2 	str	x2, [sp, #240]
    8fc0:	b5001b14 	cbnz	x20, 9320 <fwp_hof0.constprop.0+0x1090>
    8fc4:	b7f800d7 	tbnz	x23, #63, 8fdc <fwp_hof0.constprop.0+0xd4c>
    8fc8:	92407ef7 	and	x23, x23, #0xffffffff
    8fcc:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    8fd0:	fc777880 	ldr	d0, [x4, x23, lsl #3]
    8fd4:	1e612800 	fadd	d0, d0, d1
    8fd8:	fc377880 	str	d0, [x4, x23, lsl #3]
    8fdc:	d1000680 	sub	x0, x20, #0x1
    8fe0:	d10004e6 	sub	x6, x7, #0x1
    8fe4:	eb0000ff 	cmp	x7, x0
    8fe8:	540003ec 	b.gt	9064 <fwp_hof0.constprop.0+0xdd4>
    8fec:	fc607880 	ldr	d0, [x4, x0, lsl #3]
    8ff0:	1e602008 	fcmp	d0, #0.0
    8ff4:	54000320 	b.eq	9058 <fwp_hof0.constprop.0+0xdc8>  // b.none
    8ff8:	cb070be1 	neg	x1, x7, lsl #2
    8ffc:	cb0703e3 	neg	x3, x7
    9000:	8b010102 	add	x2, x8, x1
    9004:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    9008:	37f80122 	tbnz	w2, #31, 902c <fwp_hof0.constprop.0+0xd9c>
    900c:	f9401fe5 	ldr	x5, [sp, #56]
    9010:	93407c42 	sxtw	x2, w2
    9014:	8b030ca5 	add	x5, x5, x3, lsl #3
    9018:	fc627881 	ldr	d1, [x4, x2, lsl #3]
    901c:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    9020:	1e620802 	fmul	d2, d0, d2
    9024:	1e622821 	fadd	d1, d1, d2
    9028:	fc227881 	str	d1, [x4, x2, lsl #3]
    902c:	8b010121 	add	x1, x9, x1
    9030:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    9034:	37f80121 	tbnz	w1, #31, 9058 <fwp_hof0.constprop.0+0xdc8>
    9038:	f94023e2 	ldr	x2, [sp, #64]
    903c:	93407c21 	sxtw	x1, w1
    9040:	8b030c43 	add	x3, x2, x3, lsl #3
    9044:	fc617881 	ldr	d1, [x4, x1, lsl #3]
    9048:	fc607862 	ldr	d2, [x3, x0, lsl #3]
    904c:	1e620800 	fmul	d0, d0, d2
    9050:	1e602820 	fadd	d0, d1, d0
    9054:	fc217880 	str	d0, [x4, x1, lsl #3]
    9058:	d1000400 	sub	x0, x0, #0x1
    905c:	eb06001f 	cmp	x0, x6
    9060:	54fffc61 	b.ne	8fec <fwp_hof0.constprop.0+0xd5c>  // b.any
    9064:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    9068:	eb0000ff 	cmp	x7, x0
    906c:	54001fa8 	b.hi	9460 <fwp_hof0.constprop.0+0x11d0>  // b.pmore
    9070:	910004e0 	add	x0, x7, #0x1
    9074:	52800041 	mov	w1, #0x2                   	// #2
    9078:	a90393e7 	stp	x7, x4, [sp, #56]
    907c:	d37df000 	lsl	x0, x0, #3
    9080:	97ffeefc 	bl	4c70 <fwp_heap_alloc>
    9084:	aa0003f7 	mov	x23, x0
    9088:	a94393e7 	ldp	x7, x4, [sp, #56]
    908c:	f8008407 	str	x7, [x0], #8
    9090:	d2800001 	mov	x1, #0x0                   	// #0
    9094:	b40000c7 	cbz	x7, 90ac <fwp_hof0.constprop.0+0xe1c>
    9098:	f8617882 	ldr	x2, [x4, x1, lsl #3]
    909c:	f8217802 	str	x2, [x0, x1, lsl #3]
    90a0:	91000421 	add	x1, x1, #0x1
    90a4:	eb0100ff 	cmp	x7, x1
    90a8:	54ffff81 	b.ne	9098 <fwp_hof0.constprop.0+0xe08>  // b.any
    90ac:	9100c2a1 	add	x1, x21, #0x30
    90b0:	f94027e2 	ldr	x2, [sp, #72]
    90b4:	f9416020 	ldr	x0, [x1, #704]
    90b8:	eb02001f 	cmp	x0, x2
    90bc:	54006441 	b.ne	9d44 <fwp_hof0.constprop.0+0x1ab4>  // b.any
    90c0:	f9401be0 	ldr	x0, [sp, #48]
    90c4:	f94057f4 	ldr	x20, [sp, #168]
    90c8:	f9016034 	str	x20, [x1, #704]
    90cc:	97ffeb29 	bl	3d70 <fwp_tape_buffers_release>
    90d0:	911502c2 	add	x2, x22, #0x540
    90d4:	f949d841 	ldr	x1, [x2, #5040]
    90d8:	f949ec40 	ldr	x0, [x2, #5080]
    90dc:	cb0102e1 	sub	x1, x23, x1
    90e0:	eb00403f 	cmp	x1, x0, lsl #16
    90e4:	54000322 	b.cs	9148 <fwp_hof0.constprop.0+0xeb8>  // b.hs, b.nlast
    90e8:	d350fc20 	lsr	x0, x1, #16
    90ec:	f949fc46 	ldr	x6, [x2, #5112]
    90f0:	8b000800 	add	x0, x0, x0, lsl #2
    90f4:	d37df002 	lsl	x2, x0, #3
    90f8:	8b0200c4 	add	x4, x6, x2
    90fc:	f9401080 	ldr	x0, [x4, #32]
    9100:	b4000240 	cbz	x0, 9148 <fwp_hof0.constprop.0+0xeb8>
    9104:	386268c2 	ldrb	w2, [x6, x2]
    9108:	7100085f 	cmp	w2, #0x2
    910c:	54004da0 	b.eq	9ac0 <fwp_hof0.constprop.0+0x1830>  // b.none
    9110:	7100045f 	cmp	w2, #0x1
    9114:	540001a1 	b.ne	9148 <fwp_hof0.constprop.0+0xeb8>  // b.any
    9118:	29430886 	ldp	w6, w2, [x4, #24]
    911c:	92403c21 	and	x1, x1, #0xffff
    9120:	9b067c21 	mul	x1, x1, x6
    9124:	d360fc21 	lsr	x1, x1, #32
    9128:	eb02003f 	cmp	x1, x2
    912c:	540000e2 	b.cs	9148 <fwp_hof0.constprop.0+0xeb8>  // b.hs, b.nlast
    9130:	8b010000 	add	x0, x0, x1
    9134:	39400001 	ldrb	w1, [x0]
    9138:	7103fc3f 	cmp	w1, #0xff
    913c:	54005be0 	b.eq	9cb8 <fwp_hof0.constprop.0+0x1a28>  // b.none
    9140:	52800021 	mov	w1, #0x1                   	// #1
    9144:	39000001 	strb	w1, [x0]
    9148:	f94007e0 	ldr	x0, [sp, #8]
    914c:	eb00029f 	cmp	x20, x0
    9150:	54005fa1 	b.ne	9d44 <fwp_hof0.constprop.0+0x1ab4>  // b.any
    9154:	f94003e0 	ldr	x0, [sp]
    9158:	9100c2a1 	add	x1, x21, #0x30
    915c:	f9404be2 	ldr	x2, [sp, #144]
    9160:	f9016022 	str	x2, [x1, #704]
    9164:	97fff40b 	bl	6190 <fwp_tape_scope_release>
    9168:	f94002e0 	ldr	x0, [x23]
    916c:	9240f802 	and	x2, x0, #0x7fffffffffffffff
    9170:	b7f818c0 	tbnz	x0, #63, 9488 <fwp_hof0.constprop.0+0x11f8>
    9174:	911502c4 	add	x4, x22, #0x540
    9178:	f949d880 	ldr	x0, [x4, #5040]
    917c:	f949ec81 	ldr	x1, [x4, #5080]
    9180:	cb0002e0 	sub	x0, x23, x0
    9184:	eb01401f 	cmp	x0, x1, lsl #16
    9188:	54001802 	b.cs	9488 <fwp_hof0.constprop.0+0x11f8>  // b.hs, b.nlast
    918c:	d350fc01 	lsr	x1, x0, #16
    9190:	f949fc87 	ldr	x7, [x4, #5112]
    9194:	8b010821 	add	x1, x1, x1, lsl #2
    9198:	d37df021 	lsl	x1, x1, #3
    919c:	8b0100e6 	add	x6, x7, x1
    91a0:	f94010c4 	ldr	x4, [x6, #32]
    91a4:	b4001724 	cbz	x4, 9488 <fwp_hof0.constprop.0+0x11f8>
    91a8:	386168e1 	ldrb	w1, [x7, x1]
    91ac:	7100083f 	cmp	w1, #0x2
    91b0:	54001680 	b.eq	9480 <fwp_hof0.constprop.0+0x11f0>  // b.none
    91b4:	7100043f 	cmp	w1, #0x1
    91b8:	54001681 	b.ne	9488 <fwp_hof0.constprop.0+0x11f8>  // b.any
    91bc:	294304c7 	ldp	w7, w1, [x6, #24]
    91c0:	92403c00 	and	x0, x0, #0xffff
    91c4:	9b077c00 	mul	x0, x0, x7
    91c8:	d360fc00 	lsr	x0, x0, #32
    91cc:	eb01001f 	cmp	x0, x1
    91d0:	540015c2 	b.cs	9488 <fwp_hof0.constprop.0+0x11f8>  // b.hs, b.nlast
    91d4:	8b000084 	add	x4, x4, x0
    91d8:	39400080 	ldrb	w0, [x4]
    91dc:	7100041f 	cmp	w0, #0x1
    91e0:	54001541 	b.ne	9488 <fwp_hof0.constprop.0+0x11f8>  // b.any
    91e4:	aa1703f4 	mov	x20, x23
    91e8:	d2800000 	mov	x0, #0x0                   	// #0
    91ec:	91002284 	add	x4, x20, #0x8
    91f0:	d2800001 	mov	x1, #0x0                   	// #0
    91f4:	b40001e2 	cbz	x2, 9230 <fwp_hof0.constprop.0+0xfa0>
    91f8:	90000023 	adrp	x3, d000 <atexit+0x10>
    91fc:	910022e7 	add	x7, x23, #0x8
    9200:	fd468861 	ldr	d1, [x3, #3344]
    9204:	f94002e5 	ldr	x5, [x23]
    9208:	aa0703e3 	mov	x3, x7
    920c:	b7f81365 	tbnz	x5, #63, 9478 <fwp_hof0.constprop.0+0x11e8>
    9210:	f9400285 	ldr	x5, [x20]
    9214:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    9218:	b7f812a5 	tbnz	x5, #63, 946c <fwp_hof0.constprop.0+0x11dc>
    921c:	1e600820 	fmul	d0, d1, d0
    9220:	91000421 	add	x1, x1, #0x1
    9224:	fc008480 	str	d0, [x4], #8
    9228:	eb01005f 	cmp	x2, x1
    922c:	54fffec1 	b.ne	9204 <fwp_hof0.constprop.0+0xf74>  // b.any
    9230:	97fff5e4 	bl	69c0 <fwp_drop10>
    9234:	b4004679 	cbz	x25, 9b00 <fwp_hof0.constprop.0+0x1870>
    9238:	aa1903e0 	mov	x0, x25
    923c:	d2800017 	mov	x23, #0x0                   	// #0
    9240:	f9400800 	ldr	x0, [x0, #16]
    9244:	910006f7 	add	x23, x23, #0x1
    9248:	b5ffffc0 	cbnz	x0, 9240 <fwp_hof0.constprop.0+0xfb0>
    924c:	f9400280 	ldr	x0, [x20]
    9250:	9240f804 	and	x4, x0, #0x7fffffffffffffff
    9254:	b7f81860 	tbnz	x0, #63, 9560 <fwp_hof0.constprop.0+0x12d0>
    9258:	911502c1 	add	x1, x22, #0x540
    925c:	f949d820 	ldr	x0, [x1, #5040]
    9260:	f949ec22 	ldr	x2, [x1, #5080]
    9264:	cb000280 	sub	x0, x20, x0
    9268:	eb02401f 	cmp	x0, x2, lsl #16
    926c:	54001782 	b.cs	955c <fwp_hof0.constprop.0+0x12cc>  // b.hs, b.nlast
    9270:	d350fc02 	lsr	x2, x0, #16
    9274:	d2800506 	mov	x6, #0x28                  	// #40
    9278:	f949fc27 	ldr	x7, [x1, #5112]
    927c:	9b067c42 	mul	x2, x2, x6
    9280:	8b0200e6 	add	x6, x7, x2
    9284:	f94010c1 	ldr	x1, [x6, #32]
    9288:	b40016a1 	cbz	x1, 955c <fwp_hof0.constprop.0+0x12cc>
    928c:	386268e2 	ldrb	w2, [x7, x2]
    9290:	7100085f 	cmp	w2, #0x2
    9294:	54001600 	b.eq	9554 <fwp_hof0.constprop.0+0x12c4>  // b.none
    9298:	7100045f 	cmp	w2, #0x1
    929c:	54001601 	b.ne	955c <fwp_hof0.constprop.0+0x12cc>  // b.any
    92a0:	294308c7 	ldp	w7, w2, [x6, #24]
    92a4:	92403c00 	and	x0, x0, #0xffff
    92a8:	9b077c00 	mul	x0, x0, x7
    92ac:	d360fc00 	lsr	x0, x0, #32
    92b0:	eb02001f 	cmp	x0, x2
    92b4:	54001542 	b.cs	955c <fwp_hof0.constprop.0+0x12cc>  // b.hs, b.nlast
    92b8:	8b000021 	add	x1, x1, x0
    92bc:	39400028 	ldrb	w8, [x1]
    92c0:	7100051f 	cmp	w8, #0x1
    92c4:	540014c1 	b.ne	955c <fwp_hof0.constprop.0+0x12cc>  // b.any
    92c8:	91002282 	add	x2, x20, #0x8
    92cc:	eb17009f 	cmp	x4, x23
    92d0:	9a979097 	csel	x23, x4, x23, ls	// ls = plast
    92d4:	b40040d7 	cbz	x23, 9aec <fwp_hof0.constprop.0+0x185c>
    92d8:	d37df2e7 	lsl	x7, x23, #3
    92dc:	aa1903e1 	mov	x1, x25
    92e0:	91002286 	add	x6, x20, #0x8
    92e4:	d2800000 	mov	x0, #0x0                   	// #0
    92e8:	14000009 	b	930c <fwp_hof0.constprop.0+0x107c>
    92ec:	fc606861 	ldr	d1, [x3, x0]
    92f0:	fd400420 	ldr	d0, [x1, #8]
    92f4:	1e613800 	fsub	d0, d0, d1
    92f8:	fc206840 	str	d0, [x2, x0]
    92fc:	91002000 	add	x0, x0, #0x8
    9300:	f9400821 	ldr	x1, [x1, #16]
    9304:	eb07001f 	cmp	x0, x7
    9308:	540015a0 	b.eq	95bc <fwp_hof0.constprop.0+0x132c>  // b.none
    930c:	f9400284 	ldr	x4, [x20]
    9310:	aa0603e3 	mov	x3, x6
    9314:	b6fffec4 	tbz	x4, #63, 92ec <fwp_hof0.constprop.0+0x105c>
    9318:	f9400a83 	ldr	x3, [x20, #16]
    931c:	17fffff4 	b	92ec <fwp_hof0.constprop.0+0x105c>
    9320:	aa0403e0 	mov	x0, x4
    9324:	d37df282 	lsl	x2, x20, #3
    9328:	52800001 	mov	w1, #0x0                   	// #0
    932c:	a90523e7 	stp	x7, x8, [sp, #80]
    9330:	f90033e9 	str	x9, [sp, #96]
    9334:	97ffe547 	bl	2850 <memset@plt>
    9338:	a94523e7 	ldp	x7, x8, [sp, #80]
    933c:	aa0003e4 	mov	x4, x0
    9340:	f94033e9 	ldr	x9, [sp, #96]
    9344:	17ffff20 	b	8fc4 <fwp_hof0.constprop.0+0xd34>
    9348:	72003c1f 	tst	w0, #0xffff
    934c:	54ffc461 	b.ne	8bd8 <fwp_hof0.constprop.0+0x948>  // b.any
    9350:	17fffe62 	b	8cd8 <fwp_hof0.constprop.0+0xa48>
    9354:	90000020 	adrp	x0, d000 <atexit+0x10>
    9358:	91058000 	add	x0, x0, #0x160
    935c:	97ffeacd 	bl	3e90 <fwp_trap>
    9360:	aa0703f4 	mov	x20, x7
    9364:	17fffeff 	b	8f60 <fwp_hof0.constprop.0+0xcd0>
    9368:	90000020 	adrp	x0, d000 <atexit+0x10>
    936c:	910ea000 	add	x0, x0, #0x3a8
    9370:	97ffeac8 	bl	3e90 <fwp_trap>
    9374:	aa1403e0 	mov	x0, x20
    9378:	a903a7ea 	stp	x10, x9, [sp, #56]
    937c:	97ffeae5 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9380:	a943a7ea 	ldp	x10, x9, [sp, #56]
    9384:	17fffdaf 	b	8a40 <fwp_hof0.constprop.0+0x7b0>
    9388:	72003c1f 	tst	w0, #0xffff
    938c:	54ffdd81 	b.ne	8f3c <fwp_hof0.constprop.0+0xcac>  // b.any
    9390:	17fffee0 	b	8f10 <fwp_hof0.constprop.0+0xc80>
    9394:	aa1403e0 	mov	x0, x20
    9398:	97ffeade 	bl	3f10 <fwp_rc_forget_slot.part.0>
    939c:	17fffe8c 	b	8dcc <fwp_hof0.constprop.0+0xb3c>
    93a0:	ca404401 	eor	x1, x0, x0, lsr #17
    93a4:	911502c4 	add	x4, x22, #0x540
    93a8:	ca412421 	eor	x1, x1, x1, lsr #9
    93ac:	92401c21 	and	x1, x1, #0xff
    93b0:	910a2422 	add	x2, x1, #0x289
    93b4:	8b010c81 	add	x1, x4, x1, lsl #3
    93b8:	8b020c82 	add	x2, x4, x2, lsl #3
    93bc:	f94a2421 	ldr	x1, [x1, #5192]
    93c0:	b50000a1 	cbnz	x1, 93d4 <fwp_hof0.constprop.0+0x1144>
    93c4:	17ffffe4 	b	9354 <fwp_hof0.constprop.0+0x10c4>
    93c8:	91004022 	add	x2, x1, #0x10
    93cc:	f9400821 	ldr	x1, [x1, #16]
    93d0:	b4fffc21 	cbz	x1, 9354 <fwp_hof0.constprop.0+0x10c4>
    93d4:	f9400023 	ldr	x3, [x1]
    93d8:	eb00007f 	cmp	x3, x0
    93dc:	54ffff61 	b.ne	93c8 <fwp_hof0.constprop.0+0x1138>  // b.any
    93e0:	f9400042 	ldr	x2, [x2]
    93e4:	f9400441 	ldr	x1, [x2, #8]
    93e8:	d1000421 	sub	x1, x1, #0x1
    93ec:	f9000441 	str	x1, [x2, #8]
    93f0:	f103f83f 	cmp	x1, #0xfe
    93f4:	54ffbf21 	b.ne	8bd8 <fwp_hof0.constprop.0+0x948>  // b.any
    93f8:	39400001 	ldrb	w1, [x0]
    93fc:	7103fc3f 	cmp	w1, #0xff
    9400:	54004720 	b.eq	9ce4 <fwp_hof0.constprop.0+0x1a54>  // b.none
    9404:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9408:	39000001 	strb	w1, [x0]
    940c:	17fffdf3 	b	8bd8 <fwp_hof0.constprop.0+0x948>
    9410:	f100029f 	cmp	x20, #0x0
    9414:	fa401880 	ccmp	x4, #0x0, #0x0, ne	// ne = any
    9418:	54ffdd41 	b.ne	8fc0 <fwp_hof0.constprop.0+0xd30>  // b.any
    941c:	f9401be0 	ldr	x0, [sp, #48]
    9420:	9100c2b5 	add	x21, x21, #0x30
    9424:	f94057e1 	ldr	x1, [sp, #168]
    9428:	f90162a1 	str	x1, [x21, #704]
    942c:	97ffea51 	bl	3d70 <fwp_tape_buffers_release>
    9430:	d00000a3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    9434:	f947e863 	ldr	x3, [x3, #4048]
    9438:	d2800262 	mov	x2, #0x13                  	// #19
    943c:	d2800021 	mov	x1, #0x1                   	// #1
    9440:	90000020 	adrp	x0, d000 <atexit+0x10>
    9444:	9100a000 	add	x0, x0, #0x28
    9448:	f9400063 	ldr	x3, [x3]
    944c:	97ffe54d 	bl	2980 <fwrite@plt>
    9450:	d2800000 	mov	x0, #0x0                   	// #0
    9454:	97ffe557 	bl	29b0 <fflush@plt>
    9458:	52800cc0 	mov	w0, #0x66                  	// #102
    945c:	97ffe565 	bl	29f0 <_Exit@plt>
    9460:	90000020 	adrp	x0, d000 <atexit+0x10>
    9464:	91156000 	add	x0, x0, #0x558
    9468:	97ffea8a 	bl	3e90 <fwp_trap>
    946c:	90000020 	adrp	x0, d000 <atexit+0x10>
    9470:	9115a000 	add	x0, x0, #0x568
    9474:	97ffea87 	bl	3e90 <fwp_trap>
    9478:	f9400ae3 	ldr	x3, [x23, #16]
    947c:	17ffff65 	b	9210 <fwp_hof0.constprop.0+0xf80>
    9480:	72003c1f 	tst	w0, #0xffff
    9484:	54ffeaa0 	b.eq	91d8 <fwp_hof0.constprop.0+0xf48>  // b.none
    9488:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    948c:	eb00005f 	cmp	x2, x0
    9490:	54fffe88 	b.hi	9460 <fwp_hof0.constprop.0+0x11d0>  // b.pmore
    9494:	91000440 	add	x0, x2, #0x1
    9498:	52800021 	mov	w1, #0x1                   	// #1
    949c:	f9001fe2 	str	x2, [sp, #56]
    94a0:	d37df000 	lsl	x0, x0, #3
    94a4:	97ffedf3 	bl	4c70 <fwp_heap_alloc>
    94a8:	f9401fe2 	ldr	x2, [sp, #56]
    94ac:	911502c6 	add	x6, x22, #0x540
    94b0:	f9000002 	str	x2, [x0]
    94b4:	aa0003f4 	mov	x20, x0
    94b8:	f949d8c1 	ldr	x1, [x6, #5040]
    94bc:	f949ecc0 	ldr	x0, [x6, #5080]
    94c0:	cb010281 	sub	x1, x20, x1
    94c4:	eb00403f 	cmp	x1, x0, lsl #16
    94c8:	54000322 	b.cs	952c <fwp_hof0.constprop.0+0x129c>  // b.hs, b.nlast
    94cc:	d350fc24 	lsr	x4, x1, #16
    94d0:	d2800500 	mov	x0, #0x28                  	// #40
    94d4:	f949fcc7 	ldr	x7, [x6, #5112]
    94d8:	9b007c84 	mul	x4, x4, x0
    94dc:	8b0400e6 	add	x6, x7, x4
    94e0:	f94010c0 	ldr	x0, [x6, #32]
    94e4:	b4000240 	cbz	x0, 952c <fwp_hof0.constprop.0+0x129c>
    94e8:	386468e4 	ldrb	w4, [x7, x4]
    94ec:	7100089f 	cmp	w4, #0x2
    94f0:	54004020 	b.eq	9cf4 <fwp_hof0.constprop.0+0x1a64>  // b.none
    94f4:	7100049f 	cmp	w4, #0x1
    94f8:	540001a1 	b.ne	952c <fwp_hof0.constprop.0+0x129c>  // b.any
    94fc:	294310c7 	ldp	w7, w4, [x6, #24]
    9500:	92403c21 	and	x1, x1, #0xffff
    9504:	9b077c21 	mul	x1, x1, x7
    9508:	d360fc21 	lsr	x1, x1, #32
    950c:	eb04003f 	cmp	x1, x4
    9510:	540000e2 	b.cs	952c <fwp_hof0.constprop.0+0x129c>  // b.hs, b.nlast
    9514:	8b010000 	add	x0, x0, x1
    9518:	39400001 	ldrb	w1, [x0]
    951c:	7103fc3f 	cmp	w1, #0xff
    9520:	54003ba0 	b.eq	9c94 <fwp_hof0.constprop.0+0x1a04>  // b.none
    9524:	52800021 	mov	w1, #0x1                   	// #1
    9528:	39000001 	strb	w1, [x0]
    952c:	aa1703e0 	mov	x0, x23
    9530:	17ffff2f 	b	91ec <fwp_hof0.constprop.0+0xf5c>
    9534:	aa0203e0 	mov	x0, x2
    9538:	d2800101 	mov	x1, #0x8                   	// #8
    953c:	f9002be2 	str	x2, [sp, #80]
    9540:	97ffe4c8 	bl	2860 <calloc@plt>
    9544:	a9451fe2 	ldp	x2, x7, [sp, #80]
    9548:	aa0003e4 	mov	x4, x0
    954c:	a94627e8 	ldp	x8, x9, [sp, #96]
    9550:	17fffe99 	b	8fb4 <fwp_hof0.constprop.0+0xd24>
    9554:	72003c1f 	tst	w0, #0xffff
    9558:	54ffeb20 	b.eq	92bc <fwp_hof0.constprop.0+0x102c>  // b.none
    955c:	b4002bf9 	cbz	x25, 9ad8 <fwp_hof0.constprop.0+0x1848>
    9560:	aa1903e1 	mov	x1, x25
    9564:	d2800017 	mov	x23, #0x0                   	// #0
    9568:	f9400821 	ldr	x1, [x1, #16]
    956c:	aa1703e0 	mov	x0, x23
    9570:	910006f7 	add	x23, x23, #0x1
    9574:	b5ffffa1 	cbnz	x1, 9568 <fwp_hof0.constprop.0+0x12d8>
    9578:	f9001fe4 	str	x4, [sp, #56]
    957c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    9580:	eb0102ff 	cmp	x23, x1
    9584:	54ff8e48 	b.hi	874c <fwp_hof0.constprop.0+0x4bc>  // b.pmore
    9588:	91000800 	add	x0, x0, #0x2
    958c:	52800041 	mov	w1, #0x2                   	// #2
    9590:	d37df000 	lsl	x0, x0, #3
    9594:	97ffedb7 	bl	4c70 <fwp_heap_alloc>
    9598:	f9401fe4 	ldr	x4, [sp, #56]
    959c:	aa1903e1 	mov	x1, x25
    95a0:	aa0003e2 	mov	x2, x0
    95a4:	f9400423 	ldr	x3, [x1, #8]
    95a8:	f8008403 	str	x3, [x0], #8
    95ac:	f9400821 	ldr	x1, [x1, #16]
    95b0:	b5ffffa1 	cbnz	x1, 95a4 <fwp_hof0.constprop.0+0x1314>
    95b4:	52800008 	mov	w8, #0x0                   	// #0
    95b8:	17ffff45 	b	92cc <fwp_hof0.constprop.0+0x103c>
    95bc:	b4003219 	cbz	x25, 9bfc <fwp_hof0.constprop.0+0x196c>
    95c0:	911502c0 	add	x0, x22, #0x540
    95c4:	aa1903e9 	mov	x9, x25
    95c8:	d2800006 	mov	x6, #0x0                   	// #0
    95cc:	f949ec0a 	ldr	x10, [x0, #5080]
    95d0:	f949d80b 	ldr	x11, [x0, #5040]
    95d4:	f949fc0c 	ldr	x12, [x0, #5112]
    95d8:	d370bd4a 	lsl	x10, x10, #16
    95dc:	14000006 	b	95f4 <fwp_hof0.constprop.0+0x1364>
    95e0:	f9400929 	ldr	x9, [x9, #16]
    95e4:	910004c6 	add	x6, x6, #0x1
    95e8:	f100013f 	cmp	x9, #0x0
    95ec:	fa4612e0 	ccmp	x23, x6, #0x0, ne	// ne = any
    95f0:	54000329 	b.ls	9654 <fwp_hof0.constprop.0+0x13c4>  // b.plast
    95f4:	cb0b0120 	sub	x0, x9, x11
    95f8:	eb0a001f 	cmp	x0, x10
    95fc:	540002c2 	b.cs	9654 <fwp_hof0.constprop.0+0x13c4>  // b.hs, b.nlast
    9600:	d350fc01 	lsr	x1, x0, #16
    9604:	8b010821 	add	x1, x1, x1, lsl #2
    9608:	d37df021 	lsl	x1, x1, #3
    960c:	8b010184 	add	x4, x12, x1
    9610:	f9401083 	ldr	x3, [x4, #32]
    9614:	b4000203 	cbz	x3, 9654 <fwp_hof0.constprop.0+0x13c4>
    9618:	38616981 	ldrb	w1, [x12, x1]
    961c:	7100083f 	cmp	w1, #0x2
    9620:	54002560 	b.eq	9acc <fwp_hof0.constprop.0+0x183c>  // b.none
    9624:	7100043f 	cmp	w1, #0x1
    9628:	54000161 	b.ne	9654 <fwp_hof0.constprop.0+0x13c4>  // b.any
    962c:	29430485 	ldp	w5, w1, [x4, #24]
    9630:	92403c00 	and	x0, x0, #0xffff
    9634:	9b057c00 	mul	x0, x0, x5
    9638:	d360fc00 	lsr	x0, x0, #32
    963c:	eb01001f 	cmp	x0, x1
    9640:	540000a2 	b.cs	9654 <fwp_hof0.constprop.0+0x13c4>  // b.hs, b.nlast
    9644:	8b000063 	add	x3, x3, x0
    9648:	39400060 	ldrb	w0, [x3]
    964c:	7100041f 	cmp	w0, #0x1
    9650:	54fffc80 	b.eq	95e0 <fwp_hof0.constprop.0+0x1350>  // b.none
    9654:	d2800004 	mov	x4, #0x0                   	// #0
    9658:	eb0602ff 	cmp	x23, x6
    965c:	54002ba9 	b.ls	9bd0 <fwp_hof0.constprop.0+0x1940>  // b.plast
    9660:	d1002040 	sub	x0, x2, #0x8
    9664:	911502ca 	add	x10, x22, #0x540
    9668:	d2800004 	mov	x4, #0x0                   	// #0
    966c:	a90467e0 	stp	x0, x25, [sp, #64]
    9670:	9103e3e0 	add	x0, sp, #0xf8
    9674:	aa0603f9 	mov	x25, x6
    9678:	f9001fe0 	str	x0, [sp, #56]
    967c:	f9002be2 	str	x2, [sp, #80]
    9680:	b9005be8 	str	w8, [sp, #88]
    9684:	a9064ff4 	stp	x20, x19, [sp, #96]
    9688:	aa1703f3 	mov	x19, x23
    968c:	aa0a03f4 	mov	x20, x10
    9690:	14000012 	b	96d8 <fwp_hof0.constprop.0+0x1448>
    9694:	7100045f 	cmp	w2, #0x1
    9698:	540001a1 	b.ne	96cc <fwp_hof0.constprop.0+0x143c>  // b.any
    969c:	29430865 	ldp	w5, w2, [x3, #24]
    96a0:	92403c21 	and	x1, x1, #0xffff
    96a4:	9b057c21 	mul	x1, x1, x5
    96a8:	d360fc21 	lsr	x1, x1, #32
    96ac:	eb02003f 	cmp	x1, x2
    96b0:	540000e2 	b.cs	96cc <fwp_hof0.constprop.0+0x143c>  // b.hs, b.nlast
    96b4:	8b010000 	add	x0, x0, x1
    96b8:	39400001 	ldrb	w1, [x0]
    96bc:	7103fc3f 	cmp	w1, #0xff
    96c0:	54002a20 	b.eq	9c04 <fwp_hof0.constprop.0+0x1974>  // b.none
    96c4:	52800021 	mov	w1, #0x1                   	// #1
    96c8:	39000001 	strb	w1, [x0]
    96cc:	d1000673 	sub	x19, x19, #0x1
    96d0:	eb19027f 	cmp	x19, x25
    96d4:	54000329 	b.ls	9738 <fwp_hof0.constprop.0+0x14a8>  // b.plast
    96d8:	a94383e1 	ldp	x1, x0, [sp, #56]
    96dc:	f8737800 	ldr	x0, [x0, x19, lsl #3]
    96e0:	a90f93e0 	stp	x0, x4, [sp, #248]
    96e4:	52800020 	mov	w0, #0x1                   	// #1
    96e8:	97ffeda7 	bl	4d84 <fwp_data.part.0.constprop.0>
    96ec:	aa0003e4 	mov	x4, x0
    96f0:	f949da81 	ldr	x1, [x20, #5040]
    96f4:	f949ee80 	ldr	x0, [x20, #5080]
    96f8:	cb010081 	sub	x1, x4, x1
    96fc:	eb00403f 	cmp	x1, x0, lsl #16
    9700:	54fffe62 	b.cs	96cc <fwp_hof0.constprop.0+0x143c>  // b.hs, b.nlast
    9704:	d350fc20 	lsr	x0, x1, #16
    9708:	f949fe85 	ldr	x5, [x20, #5112]
    970c:	8b000800 	add	x0, x0, x0, lsl #2
    9710:	d37df002 	lsl	x2, x0, #3
    9714:	8b0200a3 	add	x3, x5, x2
    9718:	f9401060 	ldr	x0, [x3, #32]
    971c:	b4fffd80 	cbz	x0, 96cc <fwp_hof0.constprop.0+0x143c>
    9720:	386268a2 	ldrb	w2, [x5, x2]
    9724:	7100085f 	cmp	w2, #0x2
    9728:	54fffb61 	b.ne	9694 <fwp_hof0.constprop.0+0x1404>  // b.any
    972c:	72003c3f 	tst	w1, #0xffff
    9730:	54fffce1 	b.ne	96cc <fwp_hof0.constprop.0+0x143c>  // b.any
    9734:	17ffffe1 	b	96b8 <fwp_hof0.constprop.0+0x1428>
    9738:	d10006e1 	sub	x1, x23, #0x1
    973c:	cb170320 	sub	x0, x25, x23
    9740:	eb19003f 	cmp	x1, x25
    9744:	aa1903e6 	mov	x6, x25
    9748:	9a8037e0 	csinc	x0, xzr, x0, cc	// cc = lo, ul, last
    974c:	b9405be8 	ldr	w8, [sp, #88]
    9750:	a9448bf9 	ldp	x25, x2, [sp, #72]
    9754:	8b010000 	add	x0, x0, x1
    9758:	a9464ff4 	ldp	x20, x19, [sp, #96]
    975c:	b50023a6 	cbnz	x6, 9bd0 <fwp_hof0.constprop.0+0x1940>
    9760:	7100011f 	cmp	w8, #0x0
    9764:	9a8213e2 	csel	x2, xzr, x2, ne	// ne = any
    9768:	b4001d60 	cbz	x0, 9b14 <fwp_hof0.constprop.0+0x1884>
    976c:	d1000417 	sub	x23, x0, #0x1
    9770:	911502c7 	add	x7, x22, #0x540
    9774:	a90453f9 	stp	x25, x20, [sp, #64]
    9778:	aa1703f4 	mov	x20, x23
    977c:	aa0703f9 	mov	x25, x7
    9780:	f9002bf3 	str	x19, [sp, #80]
    9784:	aa0203f3 	mov	x19, x2
    9788:	14000012 	b	97d0 <fwp_hof0.constprop.0+0x1540>
    978c:	7100047f 	cmp	w3, #0x1
    9790:	540001a1 	b.ne	97c4 <fwp_hof0.constprop.0+0x1534>  // b.any
    9794:	29430003 	ldp	w3, w0, [x0, #24]
    9798:	92403c21 	and	x1, x1, #0xffff
    979c:	9b037c21 	mul	x1, x1, x3
    97a0:	d360fc21 	lsr	x1, x1, #32
    97a4:	eb00003f 	cmp	x1, x0
    97a8:	540000e2 	b.cs	97c4 <fwp_hof0.constprop.0+0x1534>  // b.hs, b.nlast
    97ac:	8b0102f7 	add	x23, x23, x1
    97b0:	394002e0 	ldrb	w0, [x23]
    97b4:	7103fc1f 	cmp	w0, #0xff
    97b8:	54002760 	b.eq	9ca4 <fwp_hof0.constprop.0+0x1a14>  // b.none
    97bc:	52800020 	mov	w0, #0x1                   	// #1
    97c0:	390002e0 	strb	w0, [x23]
    97c4:	d1000694 	sub	x20, x20, #0x1
    97c8:	b100069f 	cmn	x20, #0x1
    97cc:	54000320 	b.eq	9830 <fwp_hof0.constprop.0+0x15a0>  // b.none
    97d0:	f9401fe1 	ldr	x1, [sp, #56]
    97d4:	f8747a60 	ldr	x0, [x19, x20, lsl #3]
    97d8:	a90f93e0 	stp	x0, x4, [sp, #248]
    97dc:	52800020 	mov	w0, #0x1                   	// #1
    97e0:	97ffed69 	bl	4d84 <fwp_data.part.0.constprop.0>
    97e4:	aa0003e4 	mov	x4, x0
    97e8:	f949db21 	ldr	x1, [x25, #5040]
    97ec:	f949ef20 	ldr	x0, [x25, #5080]
    97f0:	cb010081 	sub	x1, x4, x1
    97f4:	eb00403f 	cmp	x1, x0, lsl #16
    97f8:	54fffe62 	b.cs	97c4 <fwp_hof0.constprop.0+0x1534>  // b.hs, b.nlast
    97fc:	d350fc20 	lsr	x0, x1, #16
    9800:	f949ff26 	ldr	x6, [x25, #5112]
    9804:	8b000800 	add	x0, x0, x0, lsl #2
    9808:	d37df003 	lsl	x3, x0, #3
    980c:	8b0300c0 	add	x0, x6, x3
    9810:	f9401017 	ldr	x23, [x0, #32]
    9814:	b4fffd97 	cbz	x23, 97c4 <fwp_hof0.constprop.0+0x1534>
    9818:	386368c3 	ldrb	w3, [x6, x3]
    981c:	7100087f 	cmp	w3, #0x2
    9820:	54fffb61 	b.ne	978c <fwp_hof0.constprop.0+0x14fc>  // b.any
    9824:	72003c3f 	tst	w1, #0xffff
    9828:	54fffce1 	b.ne	97c4 <fwp_hof0.constprop.0+0x1534>  // b.any
    982c:	17ffffe1 	b	97b0 <fwp_hof0.constprop.0+0x1520>
    9830:	a94453f9 	ldp	x25, x20, [sp, #64]
    9834:	aa1303e2 	mov	x2, x19
    9838:	f9402bf3 	ldr	x19, [sp, #80]
    983c:	aa1903f7 	mov	x23, x25
    9840:	aa0403f9 	mov	x25, x4
    9844:	aa0203e0 	mov	x0, x2
    9848:	97ffea4e 	bl	4180 <fwp_mem_free>
    984c:	911502c6 	add	x6, x22, #0x540
    9850:	f9001ffa 	str	x26, [sp, #56]
    9854:	aa1303fa 	mov	x26, x19
    9858:	aa0603f3 	mov	x19, x6
    985c:	d2800507 	mov	x7, #0x28                  	// #40
    9860:	f949da61 	ldr	x1, [x19, #5040]
    9864:	f949ee60 	ldr	x0, [x19, #5080]
    9868:	cb010281 	sub	x1, x20, x1
    986c:	eb00403f 	cmp	x1, x0, lsl #16
    9870:	54001222 	b.cs	9ab4 <fwp_hof0.constprop.0+0x1824>  // b.hs, b.nlast
    9874:	d350fc22 	lsr	x2, x1, #16
    9878:	f949fe63 	ldr	x3, [x19, #5112]
    987c:	9b077c42 	mul	x2, x2, x7
    9880:	8b020068 	add	x8, x3, x2
    9884:	f9401100 	ldr	x0, [x8, #32]
    9888:	b4001160 	cbz	x0, 9ab4 <fwp_hof0.constprop.0+0x1824>
    988c:	38626864 	ldrb	w4, [x3, x2]
    9890:	7100089f 	cmp	w4, #0x2
    9894:	540010c0 	b.eq	9aac <fwp_hof0.constprop.0+0x181c>  // b.none
    9898:	7100049f 	cmp	w4, #0x1
    989c:	540010c1 	b.ne	9ab4 <fwp_hof0.constprop.0+0x1824>  // b.any
    98a0:	29430d02 	ldp	w2, w3, [x8, #24]
    98a4:	92403c21 	and	x1, x1, #0xffff
    98a8:	9b027c22 	mul	x2, x1, x2
    98ac:	d360fc42 	lsr	x2, x2, #32
    98b0:	eb03005f 	cmp	x2, x3
    98b4:	54001002 	b.cs	9ab4 <fwp_hof0.constprop.0+0x1824>  // b.hs, b.nlast
    98b8:	8b020000 	add	x0, x0, x2
    98bc:	39400002 	ldrb	w2, [x0]
    98c0:	34000fa2 	cbz	w2, 9ab4 <fwp_hof0.constprop.0+0x1824>
    98c4:	7100045f 	cmp	w2, #0x1
    98c8:	54000d60 	b.eq	9a74 <fwp_hof0.constprop.0+0x17e4>  // b.none
    98cc:	aa1a03f3 	mov	x19, x26
    98d0:	f9401ffa 	ldr	x26, [sp, #56]
    98d4:	7103fc5f 	cmp	w2, #0xff
    98d8:	54001ba0 	b.eq	9c4c <fwp_hof0.constprop.0+0x19bc>  // b.none
    98dc:	51000442 	sub	w2, w2, #0x1
    98e0:	39000002 	strb	w2, [x0]
    98e4:	911502c6 	add	x6, x22, #0x540
    98e8:	f9001ffa 	str	x26, [sp, #56]
    98ec:	aa1303fa 	mov	x26, x19
    98f0:	aa0603f3 	mov	x19, x6
    98f4:	d2800507 	mov	x7, #0x28                  	// #40
    98f8:	f949da60 	ldr	x0, [x19, #5040]
    98fc:	f949ee61 	ldr	x1, [x19, #5080]
    9900:	cb0002e0 	sub	x0, x23, x0
    9904:	eb01401f 	cmp	x0, x1, lsl #16
    9908:	54000b02 	b.cs	9a68 <fwp_hof0.constprop.0+0x17d8>  // b.hs, b.nlast
    990c:	d350fc01 	lsr	x1, x0, #16
    9910:	f949fe62 	ldr	x2, [x19, #5112]
    9914:	9b077c21 	mul	x1, x1, x7
    9918:	8b010043 	add	x3, x2, x1
    991c:	f9401074 	ldr	x20, [x3, #32]
    9920:	b4000a54 	cbz	x20, 9a68 <fwp_hof0.constprop.0+0x17d8>
    9924:	38616844 	ldrb	w4, [x2, x1]
    9928:	7100089f 	cmp	w4, #0x2
    992c:	540009a0 	b.eq	9a60 <fwp_hof0.constprop.0+0x17d0>  // b.none
    9930:	7100049f 	cmp	w4, #0x1
    9934:	540009a1 	b.ne	9a68 <fwp_hof0.constprop.0+0x17d8>  // b.any
    9938:	29430861 	ldp	w1, w2, [x3, #24]
    993c:	92403c00 	and	x0, x0, #0xffff
    9940:	9b017c01 	mul	x1, x0, x1
    9944:	d360fc21 	lsr	x1, x1, #32
    9948:	eb02003f 	cmp	x1, x2
    994c:	540008e2 	b.cs	9a68 <fwp_hof0.constprop.0+0x17d8>  // b.hs, b.nlast
    9950:	8b010294 	add	x20, x20, x1
    9954:	39400282 	ldrb	w2, [x20]
    9958:	34000882 	cbz	w2, 9a68 <fwp_hof0.constprop.0+0x17d8>
    995c:	7100045f 	cmp	w2, #0x1
    9960:	540015a0 	b.eq	9c14 <fwp_hof0.constprop.0+0x1984>  // b.none
    9964:	aa1a03f3 	mov	x19, x26
    9968:	f9401ffa 	ldr	x26, [sp, #56]
    996c:	7103fc5f 	cmp	w2, #0xff
    9970:	54000d80 	b.eq	9b20 <fwp_hof0.constprop.0+0x1890>  // b.none
    9974:	51000442 	sub	w2, w2, #0x1
    9978:	39000282 	strb	w2, [x20]
    997c:	f9400be0 	ldr	x0, [sp, #16]
    9980:	b4ff6f20 	cbz	x0, 8764 <fwp_hof0.constprop.0+0x4d4>
    9984:	f9400be0 	ldr	x0, [sp, #16]
    9988:	f1000400 	subs	x0, x0, #0x1
    998c:	f9000be0 	str	x0, [sp, #16]
    9990:	54001dc6 	b.vs	9d48 <fwp_hof0.constprop.0+0x1ab8>
    9994:	911502c0 	add	x0, x22, #0x540
    9998:	f949ec04 	ldr	x4, [x0, #5080]
    999c:	f949d801 	ldr	x1, [x0, #5040]
    99a0:	d370bc84 	lsl	x4, x4, #16
    99a4:	17fffa82 	b	83ac <fwp_hof0.constprop.0+0x11c>
    99a8:	90000020 	adrp	x0, d000 <atexit+0x10>
    99ac:	91164000 	add	x0, x0, #0x590
    99b0:	97ffe938 	bl	3e90 <fwp_trap>
    99b4:	aa1a03e0 	mov	x0, x26
    99b8:	97ffef82 	bl	57c0 <fwp_rc_free_arr>
    99bc:	17fffbde 	b	8934 <fwp_hof0.constprop.0+0x6a4>
    99c0:	72003c3f 	tst	w1, #0xffff
    99c4:	54ff7b81 	b.ne	8934 <fwp_hof0.constprop.0+0x6a4>  // b.any
    99c8:	17fffbd3 	b	8914 <fwp_hof0.constprop.0+0x684>
    99cc:	72003c3f 	tst	w1, #0xffff
    99d0:	54ff7561 	b.ne	887c <fwp_hof0.constprop.0+0x5ec>  // b.any
    99d4:	17fffba5 	b	8868 <fwp_hof0.constprop.0+0x5d8>
    99d8:	f9000be0 	str	x0, [sp, #16]
    99dc:	f90013e3 	str	x3, [sp, #32]
    99e0:	97ffe94c 	bl	3f10 <fwp_rc_forget_slot.part.0>
    99e4:	f9400be0 	ldr	x0, [sp, #16]
    99e8:	f94013e3 	ldr	x3, [sp, #32]
    99ec:	17fffba2 	b	8874 <fwp_hof0.constprop.0+0x5e4>
    99f0:	ca544681 	eor	x1, x20, x20, lsr #17
    99f4:	911502c2 	add	x2, x22, #0x540
    99f8:	ca412421 	eor	x1, x1, x1, lsr #9
    99fc:	92401c21 	and	x1, x1, #0xff
    9a00:	910a2420 	add	x0, x1, #0x289
    9a04:	8b010c41 	add	x1, x2, x1, lsl #3
    9a08:	8b000c40 	add	x0, x2, x0, lsl #3
    9a0c:	f94a2421 	ldr	x1, [x1, #5192]
    9a10:	b50000a1 	cbnz	x1, 9a24 <fwp_hof0.constprop.0+0x1794>
    9a14:	17fffe50 	b	9354 <fwp_hof0.constprop.0+0x10c4>
    9a18:	91004020 	add	x0, x1, #0x10
    9a1c:	f9400821 	ldr	x1, [x1, #16]
    9a20:	b4ffc9a1 	cbz	x1, 9354 <fwp_hof0.constprop.0+0x10c4>
    9a24:	f9400022 	ldr	x2, [x1]
    9a28:	eb14005f 	cmp	x2, x20
    9a2c:	54ffff61 	b.ne	9a18 <fwp_hof0.constprop.0+0x1788>  // b.any
    9a30:	f9400001 	ldr	x1, [x0]
    9a34:	f9400420 	ldr	x0, [x1, #8]
    9a38:	d1000400 	sub	x0, x0, #0x1
    9a3c:	f9000420 	str	x0, [x1, #8]
    9a40:	f103f81f 	cmp	x0, #0xfe
    9a44:	54ff7781 	b.ne	8934 <fwp_hof0.constprop.0+0x6a4>  // b.any
    9a48:	39400280 	ldrb	w0, [x20]
    9a4c:	7103fc1f 	cmp	w0, #0xff
    9a50:	540011c0 	b.eq	9c88 <fwp_hof0.constprop.0+0x19f8>  // b.none
    9a54:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9a58:	39000280 	strb	w0, [x20]
    9a5c:	17fffbb6 	b	8934 <fwp_hof0.constprop.0+0x6a4>
    9a60:	f2403c00 	ands	x0, x0, #0xffff
    9a64:	54fff780 	b.eq	9954 <fwp_hof0.constprop.0+0x16c4>  // b.none
    9a68:	aa1a03f3 	mov	x19, x26
    9a6c:	f9401ffa 	ldr	x26, [sp, #56]
    9a70:	17ffffc3 	b	997c <fwp_hof0.constprop.0+0x16ec>
    9a74:	f9400282 	ldr	x2, [x20]
    9a78:	aa1403e0 	mov	x0, x20
    9a7c:	b7f80742 	tbnz	x2, #63, 9b64 <fwp_hof0.constprop.0+0x18d4>
    9a80:	aa1a03f3 	mov	x19, x26
    9a84:	f9401ffa 	ldr	x26, [sp, #56]
    9a88:	7100089f 	cmp	w4, #0x2
    9a8c:	54000680 	b.eq	9b5c <fwp_hof0.constprop.0+0x18cc>  // b.none
    9a90:	29430102 	ldp	w2, w0, [x8, #24]
    9a94:	9b027c21 	mul	x1, x1, x2
    9a98:	eb41801f 	cmp	x0, x1, lsr #32
    9a9c:	54fff249 	b.ls	98e4 <fwp_hof0.constprop.0+0x1654>  // b.plast
    9aa0:	aa1403e0 	mov	x0, x20
    9aa4:	97ffe9b7 	bl	4180 <fwp_mem_free>
    9aa8:	17ffff8f 	b	98e4 <fwp_hof0.constprop.0+0x1654>
    9aac:	f2403c21 	ands	x1, x1, #0xffff
    9ab0:	54fff060 	b.eq	98bc <fwp_hof0.constprop.0+0x162c>  // b.none
    9ab4:	aa1a03f3 	mov	x19, x26
    9ab8:	f9401ffa 	ldr	x26, [sp, #56]
    9abc:	17ffff8a 	b	98e4 <fwp_hof0.constprop.0+0x1654>
    9ac0:	72003c3f 	tst	w1, #0xffff
    9ac4:	54ffb421 	b.ne	9148 <fwp_hof0.constprop.0+0xeb8>  // b.any
    9ac8:	17fffd9b 	b	9134 <fwp_hof0.constprop.0+0xea4>
    9acc:	72003c1f 	tst	w0, #0xffff
    9ad0:	54ffdc21 	b.ne	9654 <fwp_hof0.constprop.0+0x13c4>  // b.any
    9ad4:	17fffedd 	b	9648 <fwp_hof0.constprop.0+0x13b8>
    9ad8:	52800041 	mov	w1, #0x2                   	// #2
    9adc:	d2800100 	mov	x0, #0x8                   	// #8
    9ae0:	97ffec64 	bl	4c70 <fwp_heap_alloc>
    9ae4:	aa0003e2 	mov	x2, x0
    9ae8:	52800008 	mov	w8, #0x0                   	// #0
    9aec:	aa1903f7 	mov	x23, x25
    9af0:	d2800019 	mov	x25, #0x0                   	// #0
    9af4:	7100011f 	cmp	w8, #0x0
    9af8:	9a8213e2 	csel	x2, xzr, x2, ne	// ne = any
    9afc:	17ffff52 	b	9844 <fwp_hof0.constprop.0+0x15b4>
    9b00:	f9400284 	ldr	x4, [x20]
    9b04:	b7fffea4 	tbnz	x4, #63, 9ad8 <fwp_hof0.constprop.0+0x1848>
    9b08:	9240f884 	and	x4, x4, #0x7fffffffffffffff
    9b0c:	d2800017 	mov	x23, #0x0                   	// #0
    9b10:	17fffdd2 	b	9258 <fwp_hof0.constprop.0+0xfc8>
    9b14:	aa1903f7 	mov	x23, x25
    9b18:	aa0403f9 	mov	x25, x4
    9b1c:	17ffff4a 	b	9844 <fwp_hof0.constprop.0+0x15b4>
    9b20:	ca544681 	eor	x1, x20, x20, lsr #17
    9b24:	911502c0 	add	x0, x22, #0x540
    9b28:	ca412421 	eor	x1, x1, x1, lsr #9
    9b2c:	92401c21 	and	x1, x1, #0xff
    9b30:	910a2422 	add	x2, x1, #0x289
    9b34:	8b010c01 	add	x1, x0, x1, lsl #3
    9b38:	8b020c02 	add	x2, x0, x2, lsl #3
    9b3c:	f94a2420 	ldr	x0, [x1, #5192]
    9b40:	b4ffc0a0 	cbz	x0, 9354 <fwp_hof0.constprop.0+0x10c4>
    9b44:	f9400001 	ldr	x1, [x0]
    9b48:	eb01029f 	cmp	x20, x1
    9b4c:	54000200 	b.eq	9b8c <fwp_hof0.constprop.0+0x18fc>  // b.none
    9b50:	91004002 	add	x2, x0, #0x10
    9b54:	f9400800 	ldr	x0, [x0, #16]
    9b58:	17fffffa 	b	9b40 <fwp_hof0.constprop.0+0x18b0>
    9b5c:	b5ffec41 	cbnz	x1, 98e4 <fwp_hof0.constprop.0+0x1654>
    9b60:	17ffffd0 	b	9aa0 <fwp_hof0.constprop.0+0x1810>
    9b64:	f9400694 	ldr	x20, [x20, #8]
    9b68:	7100089f 	cmp	w4, #0x2
    9b6c:	54000280 	b.eq	9bbc <fwp_hof0.constprop.0+0x192c>  // b.none
    9b70:	29430903 	ldp	w3, w2, [x8, #24]
    9b74:	9b037c21 	mul	x1, x1, x3
    9b78:	eb41805f 	cmp	x2, x1, lsr #32
    9b7c:	54ffe729 	b.ls	9860 <fwp_hof0.constprop.0+0x15d0>  // b.plast
    9b80:	97ffe980 	bl	4180 <fwp_mem_free>
    9b84:	d2800507 	mov	x7, #0x28                  	// #40
    9b88:	17ffff36 	b	9860 <fwp_hof0.constprop.0+0x15d0>
    9b8c:	f9400041 	ldr	x1, [x2]
    9b90:	f9400420 	ldr	x0, [x1, #8]
    9b94:	d1000400 	sub	x0, x0, #0x1
    9b98:	f9000420 	str	x0, [x1, #8]
    9b9c:	f103f81f 	cmp	x0, #0xfe
    9ba0:	54ffeee1 	b.ne	997c <fwp_hof0.constprop.0+0x16ec>  // b.any
    9ba4:	39400280 	ldrb	w0, [x20]
    9ba8:	7103fc1f 	cmp	w0, #0xff
    9bac:	540000c0 	b.eq	9bc4 <fwp_hof0.constprop.0+0x1934>  // b.none
    9bb0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    9bb4:	39000280 	strb	w0, [x20]
    9bb8:	17ffff71 	b	997c <fwp_hof0.constprop.0+0x16ec>
    9bbc:	b5ffe521 	cbnz	x1, 9860 <fwp_hof0.constprop.0+0x15d0>
    9bc0:	17fffff0 	b	9b80 <fwp_hof0.constprop.0+0x18f0>
    9bc4:	aa1403e0 	mov	x0, x20
    9bc8:	97ffe8d2 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9bcc:	17fffff9 	b	9bb0 <fwp_hof0.constprop.0+0x1920>
    9bd0:	aa1903f7 	mov	x23, x25
    9bd4:	d2800000 	mov	x0, #0x0                   	// #0
    9bd8:	f8607841 	ldr	x1, [x2, x0, lsl #3]
    9bdc:	91000400 	add	x0, x0, #0x1
    9be0:	f90006e1 	str	x1, [x23, #8]
    9be4:	aa1703e1 	mov	x1, x23
    9be8:	f9400af7 	ldr	x23, [x23, #16]
    9bec:	eb0000df 	cmp	x6, x0
    9bf0:	54ffff48 	b.hi	9bd8 <fwp_hof0.constprop.0+0x1948>  // b.pmore
    9bf4:	f9000824 	str	x4, [x1, #16]
    9bf8:	17ffffbf 	b	9af4 <fwp_hof0.constprop.0+0x1864>
    9bfc:	d2800006 	mov	x6, #0x0                   	// #0
    9c00:	17fffe98 	b	9660 <fwp_hof0.constprop.0+0x13d0>
    9c04:	a90713e0 	stp	x0, x4, [sp, #112]
    9c08:	97ffe8c2 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9c0c:	a94713e0 	ldp	x0, x4, [sp, #112]
    9c10:	17fffead 	b	96c4 <fwp_hof0.constprop.0+0x1434>
    9c14:	aa1703e1 	mov	x1, x23
    9c18:	f9400af7 	ldr	x23, [x23, #16]
    9c1c:	7100089f 	cmp	w4, #0x2
    9c20:	54000120 	b.eq	9c44 <fwp_hof0.constprop.0+0x19b4>  // b.none
    9c24:	29430864 	ldp	w4, w2, [x3, #24]
    9c28:	9b047c00 	mul	x0, x0, x4
    9c2c:	eb40805f 	cmp	x2, x0, lsr #32
    9c30:	54ffe649 	b.ls	98f8 <fwp_hof0.constprop.0+0x1668>  // b.plast
    9c34:	aa0103e0 	mov	x0, x1
    9c38:	97ffe952 	bl	4180 <fwp_mem_free>
    9c3c:	d2800507 	mov	x7, #0x28                  	// #40
    9c40:	17ffff2e 	b	98f8 <fwp_hof0.constprop.0+0x1668>
    9c44:	b5ffe5a0 	cbnz	x0, 98f8 <fwp_hof0.constprop.0+0x1668>
    9c48:	17fffffb 	b	9c34 <fwp_hof0.constprop.0+0x19a4>
    9c4c:	ca404401 	eor	x1, x0, x0, lsr #17
    9c50:	911502c4 	add	x4, x22, #0x540
    9c54:	ca412421 	eor	x1, x1, x1, lsr #9
    9c58:	92401c21 	and	x1, x1, #0xff
    9c5c:	910a2422 	add	x2, x1, #0x289
    9c60:	8b010c81 	add	x1, x4, x1, lsl #3
    9c64:	8b020c82 	add	x2, x4, x2, lsl #3
    9c68:	f94a2421 	ldr	x1, [x1, #5192]
    9c6c:	b4ffb741 	cbz	x1, 9354 <fwp_hof0.constprop.0+0x10c4>
    9c70:	f9400023 	ldr	x3, [x1]
    9c74:	eb03001f 	cmp	x0, x3
    9c78:	54000460 	b.eq	9d04 <fwp_hof0.constprop.0+0x1a74>  // b.none
    9c7c:	91004022 	add	x2, x1, #0x10
    9c80:	f9400821 	ldr	x1, [x1, #16]
    9c84:	17fffffa 	b	9c6c <fwp_hof0.constprop.0+0x19dc>
    9c88:	aa1403e0 	mov	x0, x20
    9c8c:	97ffe8a1 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9c90:	17ffff71 	b	9a54 <fwp_hof0.constprop.0+0x17c4>
    9c94:	a9038be0 	stp	x0, x2, [sp, #56]
    9c98:	97ffe89e 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9c9c:	a9438be0 	ldp	x0, x2, [sp, #56]
    9ca0:	17fffe21 	b	9524 <fwp_hof0.constprop.0+0x1294>
    9ca4:	aa1703e0 	mov	x0, x23
    9ca8:	f9002fe4 	str	x4, [sp, #88]
    9cac:	97ffe899 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9cb0:	f9402fe4 	ldr	x4, [sp, #88]
    9cb4:	17fffec2 	b	97bc <fwp_hof0.constprop.0+0x152c>
    9cb8:	f9001fe0 	str	x0, [sp, #56]
    9cbc:	97ffe895 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9cc0:	9100c2a1 	add	x1, x21, #0x30
    9cc4:	f9401fe0 	ldr	x0, [sp, #56]
    9cc8:	f9416034 	ldr	x20, [x1, #704]
    9ccc:	17fffd1d 	b	9140 <fwp_hof0.constprop.0+0xeb0>
    9cd0:	a91253f3 	stp	x19, x20, [sp, #288]
    9cd4:	a9135bf5 	stp	x21, x22, [sp, #304]
    9cd8:	a91463f7 	stp	x23, x24, [sp, #320]
    9cdc:	a9156bf9 	stp	x25, x26, [sp, #336]
    9ce0:	97ffe2e8 	bl	2880 <__stack_chk_fail@plt>
    9ce4:	f9001fe0 	str	x0, [sp, #56]
    9ce8:	97ffe88a 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9cec:	f9401fe0 	ldr	x0, [sp, #56]
    9cf0:	17fffdc5 	b	9404 <fwp_hof0.constprop.0+0x1174>
    9cf4:	72003c3f 	tst	w1, #0xffff
    9cf8:	54ffc100 	b.eq	9518 <fwp_hof0.constprop.0+0x1288>  // b.none
    9cfc:	aa1703e0 	mov	x0, x23
    9d00:	17fffd3b 	b	91ec <fwp_hof0.constprop.0+0xf5c>
    9d04:	f9400042 	ldr	x2, [x2]
    9d08:	f9400441 	ldr	x1, [x2, #8]
    9d0c:	d1000421 	sub	x1, x1, #0x1
    9d10:	f9000441 	str	x1, [x2, #8]
    9d14:	f103f83f 	cmp	x1, #0xfe
    9d18:	54ffde61 	b.ne	98e4 <fwp_hof0.constprop.0+0x1654>  // b.any
    9d1c:	39400001 	ldrb	w1, [x0]
    9d20:	7103fc3f 	cmp	w1, #0xff
    9d24:	54000080 	b.eq	9d34 <fwp_hof0.constprop.0+0x1aa4>  // b.none
    9d28:	12800021 	mov	w1, #0xfffffffe            	// #-2
    9d2c:	39000001 	strb	w1, [x0]
    9d30:	17fffeed 	b	98e4 <fwp_hof0.constprop.0+0x1654>
    9d34:	f9001fe0 	str	x0, [sp, #56]
    9d38:	97ffe876 	bl	3f10 <fwp_rc_forget_slot.part.0>
    9d3c:	f9401fe0 	ldr	x0, [sp, #56]
    9d40:	17fffffa 	b	9d28 <fwp_hof0.constprop.0+0x1a98>
    9d44:	97ffe2e3 	bl	28d0 <abort@plt>
    9d48:	97ffe34e 	bl	2a80 <fwp_trap_overflow.constprop.0>
    9d4c:	d503201f 	nop

0000000000009d50 <f0>:
    9d50:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    9d54:	910003fd 	mov	x29, sp
    9d58:	a90153f3 	stp	x19, x20, [sp, #16]
    9d5c:	a9025bf5 	stp	x21, x22, [sp, #32]
    9d60:	a90363f7 	stp	x23, x24, [sp, #48]
    9d64:	a9046bf9 	stp	x25, x26, [sp, #64]
    9d68:	a90573fb 	stp	x27, x28, [sp, #80]
    9d6c:	d121c3ff 	sub	sp, sp, #0x870
    9d70:	f90203ff 	str	xzr, [sp, #1024]
    9d74:	f00000a0 	adrp	x0, 20000 <__data_start>
    9d78:	9100c003 	add	x3, x0, #0x30
    9d7c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    9d80:	f947f400 	ldr	x0, [x0, #4072]
    9d84:	90000154 	adrp	x20, 31000 <fwp_root_context+0xca0>
    9d88:	f9416065 	ldr	x5, [x3, #704]
    9d8c:	f9400001 	ldr	x1, [x0]
    9d90:	f90437e1 	str	x1, [sp, #2152]
    9d94:	d2800001 	mov	x1, #0x0                   	// #0
    9d98:	91150299 	add	x25, x20, #0x540
    9d9c:	912163f6 	add	x22, sp, #0x858
    9da0:	910063e4 	add	x4, sp, #0x18
    9da4:	9100c3e1 	add	x1, sp, #0x30
    9da8:	90ffffe0 	adrp	x0, 5000 <fwp_tape_reserve+0x15c>
    9dac:	b0ffffc2 	adrp	x2, 2000 <__abi_tag+0x1d50>
    9db0:	91320000 	add	x0, x0, #0xc80
    9db4:	913d4042 	add	x2, x2, #0xf50
    9db8:	d2800013 	mov	x19, #0x0                   	// #0
    9dbc:	d280011a 	mov	x26, #0x8                   	// #8
    9dc0:	d2800015 	mov	x21, #0x0                   	// #0
    9dc4:	52800037 	mov	w23, #0x1                   	// #1
    9dc8:	f90007e4 	str	x4, [sp, #8]
    9dcc:	a9018be5 	stp	x5, x2, [sp, #24]
    9dd0:	a902ffe1 	stp	x1, xzr, [sp, #40]
    9dd4:	a90403ff 	stp	xzr, x0, [sp, #64]
    9dd8:	f9016064 	str	x4, [x3, #704]
    9ddc:	d503201f 	nop
    9de0:	f100075b 	subs	x27, x26, #0x1
    9de4:	aa1603e1 	mov	x1, x22
    9de8:	da1f02b8 	sbc	x24, x21, xzr
    9dec:	52800020 	mov	w0, #0x1                   	// #1
    9df0:	f9001ffb 	str	x27, [sp, #56]
    9df4:	aa1b03fa 	mov	x26, x27
    9df8:	f9042ffb 	str	x27, [sp, #2136]
    9dfc:	aa1803f5 	mov	x21, x24
    9e00:	f90433f3 	str	x19, [sp, #2144]
    9e04:	97ffebe0 	bl	4d84 <fwp_data.part.0.constprop.0>
    9e08:	f949db22 	ldr	x2, [x25, #5040]
    9e0c:	aa0003f3 	mov	x19, x0
    9e10:	f949ef20 	ldr	x0, [x25, #5080]
    9e14:	cb020262 	sub	x2, x19, x2
    9e18:	eb00405f 	cmp	x2, x0, lsl #16
    9e1c:	54000302 	b.cs	9e7c <f0+0x12c>  // b.hs, b.nlast
    9e20:	d350fc40 	lsr	x0, x2, #16
    9e24:	f949ff25 	ldr	x5, [x25, #5112]
    9e28:	8b000800 	add	x0, x0, x0, lsl #2
    9e2c:	d37df001 	lsl	x1, x0, #3
    9e30:	8b0100a0 	add	x0, x5, x1
    9e34:	f940101c 	ldr	x28, [x0, #32]
    9e38:	b400023c 	cbz	x28, 9e7c <f0+0x12c>
    9e3c:	386168a1 	ldrb	w1, [x5, x1]
    9e40:	7100083f 	cmp	w1, #0x2
    9e44:	54010f20 	b.eq	c028 <f0+0x22d8>  // b.none
    9e48:	7100043f 	cmp	w1, #0x1
    9e4c:	54000181 	b.ne	9e7c <f0+0x12c>  // b.any
    9e50:	29430001 	ldp	w1, w0, [x0, #24]
    9e54:	92403c42 	and	x2, x2, #0xffff
    9e58:	9b017c42 	mul	x2, x2, x1
    9e5c:	d360fc42 	lsr	x2, x2, #32
    9e60:	eb00005f 	cmp	x2, x0
    9e64:	540000c2 	b.cs	9e7c <f0+0x12c>  // b.hs, b.nlast
    9e68:	8b02039c 	add	x28, x28, x2
    9e6c:	39400380 	ldrb	w0, [x28]
    9e70:	7103fc1f 	cmp	w0, #0xff
    9e74:	54010d40 	b.eq	c01c <f0+0x22cc>  // b.none
    9e78:	39000397 	strb	w23, [x28]
    9e7c:	a9037ff3 	stp	x19, xzr, [sp, #48]
    9e80:	aa18037b 	orr	x27, x27, x24
    9e84:	b5fffafb 	cbnz	x27, 9de0 <f0+0x90>
    9e88:	f00000a0 	adrp	x0, 20000 <__data_start>
    9e8c:	9100c018 	add	x24, x0, #0x30
    9e90:	f94007e1 	ldr	x1, [sp, #8]
    9e94:	f9001bff 	str	xzr, [sp, #48]
    9e98:	f9416300 	ldr	x0, [x24, #704]
    9e9c:	eb01001f 	cmp	x0, x1
    9ea0:	54012a01 	b.ne	c3e0 <f0+0x2690>  // b.any
    9ea4:	90000023 	adrp	x3, d000 <atexit+0x10>
    9ea8:	910143e1 	add	x1, sp, #0x50
    9eac:	f9400fe2 	ldr	x2, [sp, #24]
    9eb0:	52800020 	mov	w0, #0x1                   	// #1
    9eb4:	3dc34060 	ldr	q0, [x3, #3328]
    9eb8:	f9016302 	str	x2, [x24, #704]
    9ebc:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    9ec0:	3d8017e0 	str	q0, [sp, #80]
    9ec4:	97ffebb0 	bl	4d84 <fwp_data.part.0.constprop.0>
    9ec8:	97ffee0e 	bl	5700 <fwp_rc_fresh>
    9ecc:	9101a3e1 	add	x1, sp, #0x68
    9ed0:	aa0003e2 	mov	x2, x0
    9ed4:	52800020 	mov	w0, #0x1                   	// #1
    9ed8:	a9068bf5 	stp	x21, x2, [sp, #104]
    9edc:	97ffebaa 	bl	4d84 <fwp_data.part.0.constprop.0>
    9ee0:	97ffee08 	bl	5700 <fwp_rc_fresh>
    9ee4:	aa0003e2 	mov	x2, x0
    9ee8:	9101e3e1 	add	x1, sp, #0x78
    9eec:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9ef0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9ef4:	52800020 	mov	w0, #0x1                   	// #1
    9ef8:	a9078be3 	stp	x3, x2, [sp, #120]
    9efc:	97ffeba2 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f00:	97ffee00 	bl	5700 <fwp_rc_fresh>
    9f04:	aa0003e2 	mov	x2, x0
    9f08:	910223e1 	add	x1, sp, #0x88
    9f0c:	52800020 	mov	w0, #0x1                   	// #1
    9f10:	a9088bf5 	stp	x21, x2, [sp, #136]
    9f14:	97ffeb9c 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f18:	97ffedfa 	bl	5700 <fwp_rc_fresh>
    9f1c:	aa0003e2 	mov	x2, x0
    9f20:	910263e1 	add	x1, sp, #0x98
    9f24:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9f28:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9f2c:	52800020 	mov	w0, #0x1                   	// #1
    9f30:	a9098be3 	stp	x3, x2, [sp, #152]
    9f34:	97ffeb94 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f38:	97ffedf2 	bl	5700 <fwp_rc_fresh>
    9f3c:	aa0003e2 	mov	x2, x0
    9f40:	9102a3e1 	add	x1, sp, #0xa8
    9f44:	52800020 	mov	w0, #0x1                   	// #1
    9f48:	a90a8bf5 	stp	x21, x2, [sp, #168]
    9f4c:	97ffeb8e 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f50:	97ffedec 	bl	5700 <fwp_rc_fresh>
    9f54:	aa0003e2 	mov	x2, x0
    9f58:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    9f5c:	9102e3e1 	add	x1, sp, #0xb8
    9f60:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    9f64:	52800020 	mov	w0, #0x1                   	// #1
    9f68:	a90b8be3 	stp	x3, x2, [sp, #184]
    9f6c:	97ffeb86 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f70:	97ffede4 	bl	5700 <fwp_rc_fresh>
    9f74:	aa0003e2 	mov	x2, x0
    9f78:	910323e1 	add	x1, sp, #0xc8
    9f7c:	52800020 	mov	w0, #0x1                   	// #1
    9f80:	a90c8bf5 	stp	x21, x2, [sp, #200]
    9f84:	97ffeb80 	bl	4d84 <fwp_data.part.0.constprop.0>
    9f88:	91150283 	add	x3, x20, #0x540
    9f8c:	aa0003f5 	mov	x21, x0
    9f90:	f949d861 	ldr	x1, [x3, #5040]
    9f94:	f949ec60 	ldr	x0, [x3, #5080]
    9f98:	cb0102a1 	sub	x1, x21, x1
    9f9c:	eb00403f 	cmp	x1, x0, lsl #16
    9fa0:	54000322 	b.cs	a004 <f0+0x2b4>  // b.hs, b.nlast
    9fa4:	d350fc22 	lsr	x2, x1, #16
    9fa8:	f949fc63 	ldr	x3, [x3, #5112]
    9fac:	8b020842 	add	x2, x2, x2, lsl #2
    9fb0:	d37df042 	lsl	x2, x2, #3
    9fb4:	8b020060 	add	x0, x3, x2
    9fb8:	f9401017 	ldr	x23, [x0, #32]
    9fbc:	b4000257 	cbz	x23, a004 <f0+0x2b4>
    9fc0:	38626862 	ldrb	w2, [x3, x2]
    9fc4:	7100085f 	cmp	w2, #0x2
    9fc8:	54010360 	b.eq	c034 <f0+0x22e4>  // b.none
    9fcc:	7100045f 	cmp	w2, #0x1
    9fd0:	540001a1 	b.ne	a004 <f0+0x2b4>  // b.any
    9fd4:	29430002 	ldp	w2, w0, [x0, #24]
    9fd8:	92403c21 	and	x1, x1, #0xffff
    9fdc:	9b027c21 	mul	x1, x1, x2
    9fe0:	d360fc21 	lsr	x1, x1, #32
    9fe4:	eb00003f 	cmp	x1, x0
    9fe8:	540000e2 	b.cs	a004 <f0+0x2b4>  // b.hs, b.nlast
    9fec:	8b0102f7 	add	x23, x23, x1
    9ff0:	394002e0 	ldrb	w0, [x23]
    9ff4:	7103fc1f 	cmp	w0, #0xff
    9ff8:	540110e0 	b.eq	c214 <f0+0x24c4>  // b.none
    9ffc:	52800020 	mov	w0, #0x1                   	// #1
    a000:	390002e0 	strb	w0, [x23]
    a004:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a008:	910363e1 	add	x1, sp, #0xd8
    a00c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a010:	52800020 	mov	w0, #0x1                   	// #1
    a014:	a90dd7e2 	stp	x2, x21, [sp, #216]
    a018:	97ffeb5b 	bl	4d84 <fwp_data.part.0.constprop.0>
    a01c:	97ffedb9 	bl	5700 <fwp_rc_fresh>
    a020:	aa0003e2 	mov	x2, x0
    a024:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a028:	9103a3e1 	add	x1, sp, #0xe8
    a02c:	52800020 	mov	w0, #0x1                   	// #1
    a030:	a90e8be3 	stp	x3, x2, [sp, #232]
    a034:	97ffeb54 	bl	4d84 <fwp_data.part.0.constprop.0>
    a038:	91150283 	add	x3, x20, #0x540
    a03c:	aa0003f7 	mov	x23, x0
    a040:	f949d861 	ldr	x1, [x3, #5040]
    a044:	f949ec60 	ldr	x0, [x3, #5080]
    a048:	cb0102e1 	sub	x1, x23, x1
    a04c:	eb00403f 	cmp	x1, x0, lsl #16
    a050:	54000322 	b.cs	a0b4 <f0+0x364>  // b.hs, b.nlast
    a054:	d350fc22 	lsr	x2, x1, #16
    a058:	f949fc63 	ldr	x3, [x3, #5112]
    a05c:	8b020842 	add	x2, x2, x2, lsl #2
    a060:	d37df042 	lsl	x2, x2, #3
    a064:	8b020060 	add	x0, x3, x2
    a068:	f9401015 	ldr	x21, [x0, #32]
    a06c:	b4000255 	cbz	x21, a0b4 <f0+0x364>
    a070:	38626862 	ldrb	w2, [x3, x2]
    a074:	7100085f 	cmp	w2, #0x2
    a078:	5400fea0 	b.eq	c04c <f0+0x22fc>  // b.none
    a07c:	7100045f 	cmp	w2, #0x1
    a080:	540001a1 	b.ne	a0b4 <f0+0x364>  // b.any
    a084:	29430002 	ldp	w2, w0, [x0, #24]
    a088:	92403c21 	and	x1, x1, #0xffff
    a08c:	9b027c21 	mul	x1, x1, x2
    a090:	d360fc21 	lsr	x1, x1, #32
    a094:	eb00003f 	cmp	x1, x0
    a098:	540000e2 	b.cs	a0b4 <f0+0x364>  // b.hs, b.nlast
    a09c:	8b0102b5 	add	x21, x21, x1
    a0a0:	394002a0 	ldrb	w0, [x21]
    a0a4:	7103fc1f 	cmp	w0, #0xff
    a0a8:	54010bc0 	b.eq	c220 <f0+0x24d0>  // b.none
    a0ac:	52800020 	mov	w0, #0x1                   	// #1
    a0b0:	390002a0 	strb	w0, [x21]
    a0b4:	9103e3e1 	add	x1, sp, #0xf8
    a0b8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a0bc:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a0c0:	52800020 	mov	w0, #0x1                   	// #1
    a0c4:	a90fdff5 	stp	x21, x23, [sp, #248]
    a0c8:	97ffeb2f 	bl	4d84 <fwp_data.part.0.constprop.0>
    a0cc:	97ffed8d 	bl	5700 <fwp_rc_fresh>
    a0d0:	aa0003e2 	mov	x2, x0
    a0d4:	910423e1 	add	x1, sp, #0x108
    a0d8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a0dc:	52800020 	mov	w0, #0x1                   	// #1
    a0e0:	a9108bf7 	stp	x23, x2, [sp, #264]
    a0e4:	97ffeb28 	bl	4d84 <fwp_data.part.0.constprop.0>
    a0e8:	97ffed86 	bl	5700 <fwp_rc_fresh>
    a0ec:	aa0003e2 	mov	x2, x0
    a0f0:	910463e1 	add	x1, sp, #0x118
    a0f4:	52800020 	mov	w0, #0x1                   	// #1
    a0f8:	a9118bf5 	stp	x21, x2, [sp, #280]
    a0fc:	97ffeb22 	bl	4d84 <fwp_data.part.0.constprop.0>
    a100:	97ffed80 	bl	5700 <fwp_rc_fresh>
    a104:	aa0003e2 	mov	x2, x0
    a108:	9104a3e1 	add	x1, sp, #0x128
    a10c:	52800020 	mov	w0, #0x1                   	// #1
    a110:	a9128bf7 	stp	x23, x2, [sp, #296]
    a114:	97ffeb1c 	bl	4d84 <fwp_data.part.0.constprop.0>
    a118:	97ffed7a 	bl	5700 <fwp_rc_fresh>
    a11c:	aa0003e2 	mov	x2, x0
    a120:	9104e3e1 	add	x1, sp, #0x138
    a124:	52800020 	mov	w0, #0x1                   	// #1
    a128:	a9138bf5 	stp	x21, x2, [sp, #312]
    a12c:	97ffeb16 	bl	4d84 <fwp_data.part.0.constprop.0>
    a130:	97ffed74 	bl	5700 <fwp_rc_fresh>
    a134:	aa0003e2 	mov	x2, x0
    a138:	910523e1 	add	x1, sp, #0x148
    a13c:	52800020 	mov	w0, #0x1                   	// #1
    a140:	a9148bf7 	stp	x23, x2, [sp, #328]
    a144:	97ffeb10 	bl	4d84 <fwp_data.part.0.constprop.0>
    a148:	97ffed6e 	bl	5700 <fwp_rc_fresh>
    a14c:	aa0003e2 	mov	x2, x0
    a150:	910563e1 	add	x1, sp, #0x158
    a154:	52800020 	mov	w0, #0x1                   	// #1
    a158:	a9158bf5 	stp	x21, x2, [sp, #344]
    a15c:	97ffeb0a 	bl	4d84 <fwp_data.part.0.constprop.0>
    a160:	97ffed68 	bl	5700 <fwp_rc_fresh>
    a164:	aa0003e2 	mov	x2, x0
    a168:	9105a3e1 	add	x1, sp, #0x168
    a16c:	52800020 	mov	w0, #0x1                   	// #1
    a170:	a9168bf7 	stp	x23, x2, [sp, #360]
    a174:	97ffeb04 	bl	4d84 <fwp_data.part.0.constprop.0>
    a178:	97ffed62 	bl	5700 <fwp_rc_fresh>
    a17c:	aa0003e2 	mov	x2, x0
    a180:	9105e3e1 	add	x1, sp, #0x178
    a184:	52800020 	mov	w0, #0x1                   	// #1
    a188:	a9178bf5 	stp	x21, x2, [sp, #376]
    a18c:	97ffeafe 	bl	4d84 <fwp_data.part.0.constprop.0>
    a190:	97ffed5c 	bl	5700 <fwp_rc_fresh>
    a194:	aa0003e2 	mov	x2, x0
    a198:	910623e1 	add	x1, sp, #0x188
    a19c:	52800020 	mov	w0, #0x1                   	// #1
    a1a0:	a9188bf7 	stp	x23, x2, [sp, #392]
    a1a4:	97ffeaf8 	bl	4d84 <fwp_data.part.0.constprop.0>
    a1a8:	97ffed56 	bl	5700 <fwp_rc_fresh>
    a1ac:	aa0003e2 	mov	x2, x0
    a1b0:	910663e1 	add	x1, sp, #0x198
    a1b4:	52800020 	mov	w0, #0x1                   	// #1
    a1b8:	a9198bf5 	stp	x21, x2, [sp, #408]
    a1bc:	97ffeaf2 	bl	4d84 <fwp_data.part.0.constprop.0>
    a1c0:	97ffed50 	bl	5700 <fwp_rc_fresh>
    a1c4:	aa0003e2 	mov	x2, x0
    a1c8:	9106a3e1 	add	x1, sp, #0x1a8
    a1cc:	52800020 	mov	w0, #0x1                   	// #1
    a1d0:	a91a8bf7 	stp	x23, x2, [sp, #424]
    a1d4:	97ffeaec 	bl	4d84 <fwp_data.part.0.constprop.0>
    a1d8:	97ffed4a 	bl	5700 <fwp_rc_fresh>
    a1dc:	aa0003e2 	mov	x2, x0
    a1e0:	9106e3e1 	add	x1, sp, #0x1b8
    a1e4:	52800020 	mov	w0, #0x1                   	// #1
    a1e8:	a91b8bf5 	stp	x21, x2, [sp, #440]
    a1ec:	97ffeae6 	bl	4d84 <fwp_data.part.0.constprop.0>
    a1f0:	97ffed44 	bl	5700 <fwp_rc_fresh>
    a1f4:	aa0003e2 	mov	x2, x0
    a1f8:	910723e1 	add	x1, sp, #0x1c8
    a1fc:	52800020 	mov	w0, #0x1                   	// #1
    a200:	a91c8bf7 	stp	x23, x2, [sp, #456]
    a204:	97ffeae0 	bl	4d84 <fwp_data.part.0.constprop.0>
    a208:	97ffed3e 	bl	5700 <fwp_rc_fresh>
    a20c:	aa0003e2 	mov	x2, x0
    a210:	910763e1 	add	x1, sp, #0x1d8
    a214:	52800020 	mov	w0, #0x1                   	// #1
    a218:	a91d8bf5 	stp	x21, x2, [sp, #472]
    a21c:	97ffeada 	bl	4d84 <fwp_data.part.0.constprop.0>
    a220:	97ffed38 	bl	5700 <fwp_rc_fresh>
    a224:	aa0003e2 	mov	x2, x0
    a228:	9107a3e1 	add	x1, sp, #0x1e8
    a22c:	52800020 	mov	w0, #0x1                   	// #1
    a230:	a91e8bf7 	stp	x23, x2, [sp, #488]
    a234:	97ffead4 	bl	4d84 <fwp_data.part.0.constprop.0>
    a238:	97ffed32 	bl	5700 <fwp_rc_fresh>
    a23c:	aa0003e2 	mov	x2, x0
    a240:	9107e3e1 	add	x1, sp, #0x1f8
    a244:	52800020 	mov	w0, #0x1                   	// #1
    a248:	a91f8bf5 	stp	x21, x2, [sp, #504]
    a24c:	97ffeace 	bl	4d84 <fwp_data.part.0.constprop.0>
    a250:	91150283 	add	x3, x20, #0x540
    a254:	aa0003f5 	mov	x21, x0
    a258:	f949d861 	ldr	x1, [x3, #5040]
    a25c:	f949ec60 	ldr	x0, [x3, #5080]
    a260:	cb0102a1 	sub	x1, x21, x1
    a264:	eb00403f 	cmp	x1, x0, lsl #16
    a268:	54000322 	b.cs	a2cc <f0+0x57c>  // b.hs, b.nlast
    a26c:	d350fc22 	lsr	x2, x1, #16
    a270:	f949fc63 	ldr	x3, [x3, #5112]
    a274:	8b020842 	add	x2, x2, x2, lsl #2
    a278:	d37df042 	lsl	x2, x2, #3
    a27c:	8b020060 	add	x0, x3, x2
    a280:	f9401017 	ldr	x23, [x0, #32]
    a284:	b4000257 	cbz	x23, a2cc <f0+0x57c>
    a288:	38626862 	ldrb	w2, [x3, x2]
    a28c:	7100085f 	cmp	w2, #0x2
    a290:	5400ed80 	b.eq	c040 <f0+0x22f0>  // b.none
    a294:	7100045f 	cmp	w2, #0x1
    a298:	540001a1 	b.ne	a2cc <f0+0x57c>  // b.any
    a29c:	29430002 	ldp	w2, w0, [x0, #24]
    a2a0:	92403c21 	and	x1, x1, #0xffff
    a2a4:	9b027c21 	mul	x1, x1, x2
    a2a8:	d360fc21 	lsr	x1, x1, #32
    a2ac:	eb00003f 	cmp	x1, x0
    a2b0:	540000e2 	b.cs	a2cc <f0+0x57c>  // b.hs, b.nlast
    a2b4:	8b0102f7 	add	x23, x23, x1
    a2b8:	394002e0 	ldrb	w0, [x23]
    a2bc:	7103fc1f 	cmp	w0, #0xff
    a2c0:	5400fb60 	b.eq	c22c <f0+0x24dc>  // b.none
    a2c4:	52800020 	mov	w0, #0x1                   	// #1
    a2c8:	390002e0 	strb	w0, [x23]
    a2cc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a2d0:	910823e1 	add	x1, sp, #0x208
    a2d4:	52800020 	mov	w0, #0x1                   	// #1
    a2d8:	f90107e2 	str	x2, [sp, #520]
    a2dc:	f9010bf5 	str	x21, [sp, #528]
    a2e0:	97ffeaa9 	bl	4d84 <fwp_data.part.0.constprop.0>
    a2e4:	91150283 	add	x3, x20, #0x540
    a2e8:	aa0003f5 	mov	x21, x0
    a2ec:	f949d861 	ldr	x1, [x3, #5040]
    a2f0:	f949ec60 	ldr	x0, [x3, #5080]
    a2f4:	cb0102a1 	sub	x1, x21, x1
    a2f8:	eb00403f 	cmp	x1, x0, lsl #16
    a2fc:	54000322 	b.cs	a360 <f0+0x610>  // b.hs, b.nlast
    a300:	d350fc22 	lsr	x2, x1, #16
    a304:	f949fc63 	ldr	x3, [x3, #5112]
    a308:	8b020842 	add	x2, x2, x2, lsl #2
    a30c:	d37df042 	lsl	x2, x2, #3
    a310:	8b020060 	add	x0, x3, x2
    a314:	f9401017 	ldr	x23, [x0, #32]
    a318:	b4000257 	cbz	x23, a360 <f0+0x610>
    a31c:	38626862 	ldrb	w2, [x3, x2]
    a320:	7100085f 	cmp	w2, #0x2
    a324:	5400ea00 	b.eq	c064 <f0+0x2314>  // b.none
    a328:	7100045f 	cmp	w2, #0x1
    a32c:	540001a1 	b.ne	a360 <f0+0x610>  // b.any
    a330:	29430002 	ldp	w2, w0, [x0, #24]
    a334:	92403c21 	and	x1, x1, #0xffff
    a338:	9b027c21 	mul	x1, x1, x2
    a33c:	d360fc21 	lsr	x1, x1, #32
    a340:	eb00003f 	cmp	x1, x0
    a344:	540000e2 	b.cs	a360 <f0+0x610>  // b.hs, b.nlast
    a348:	8b0102f7 	add	x23, x23, x1
    a34c:	394002e0 	ldrb	w0, [x23]
    a350:	7103fc1f 	cmp	w0, #0xff
    a354:	5400f720 	b.eq	c238 <f0+0x24e8>  // b.none
    a358:	52800020 	mov	w0, #0x1                   	// #1
    a35c:	390002e0 	strb	w0, [x23]
    a360:	910863e1 	add	x1, sp, #0x218
    a364:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    a368:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    a36c:	52800020 	mov	w0, #0x1                   	// #1
    a370:	f9010ff7 	str	x23, [sp, #536]
    a374:	f90113f5 	str	x21, [sp, #544]
    a378:	97ffea83 	bl	4d84 <fwp_data.part.0.constprop.0>
    a37c:	97ffece1 	bl	5700 <fwp_rc_fresh>
    a380:	aa0003e2 	mov	x2, x0
    a384:	9108a3e1 	add	x1, sp, #0x228
    a388:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    a38c:	52800020 	mov	w0, #0x1                   	// #1
    a390:	f90117f5 	str	x21, [sp, #552]
    a394:	f9011be2 	str	x2, [sp, #560]
    a398:	97ffea7b 	bl	4d84 <fwp_data.part.0.constprop.0>
    a39c:	97ffecd9 	bl	5700 <fwp_rc_fresh>
    a3a0:	aa0003e2 	mov	x2, x0
    a3a4:	9108e3e1 	add	x1, sp, #0x238
    a3a8:	52800020 	mov	w0, #0x1                   	// #1
    a3ac:	f9011ff7 	str	x23, [sp, #568]
    a3b0:	f90123e2 	str	x2, [sp, #576]
    a3b4:	97ffea74 	bl	4d84 <fwp_data.part.0.constprop.0>
    a3b8:	97ffecd2 	bl	5700 <fwp_rc_fresh>
    a3bc:	aa0003e2 	mov	x2, x0
    a3c0:	910923e1 	add	x1, sp, #0x248
    a3c4:	52800020 	mov	w0, #0x1                   	// #1
    a3c8:	f90127f5 	str	x21, [sp, #584]
    a3cc:	f9012be2 	str	x2, [sp, #592]
    a3d0:	97ffea6d 	bl	4d84 <fwp_data.part.0.constprop.0>
    a3d4:	91150283 	add	x3, x20, #0x540
    a3d8:	aa0003f5 	mov	x21, x0
    a3dc:	f949d861 	ldr	x1, [x3, #5040]
    a3e0:	f949ec60 	ldr	x0, [x3, #5080]
    a3e4:	cb0102a1 	sub	x1, x21, x1
    a3e8:	eb00403f 	cmp	x1, x0, lsl #16
    a3ec:	54000322 	b.cs	a450 <f0+0x700>  // b.hs, b.nlast
    a3f0:	d350fc22 	lsr	x2, x1, #16
    a3f4:	f949fc63 	ldr	x3, [x3, #5112]
    a3f8:	8b020842 	add	x2, x2, x2, lsl #2
    a3fc:	d37df042 	lsl	x2, x2, #3
    a400:	8b020060 	add	x0, x3, x2
    a404:	f9401017 	ldr	x23, [x0, #32]
    a408:	b4000257 	cbz	x23, a450 <f0+0x700>
    a40c:	38626862 	ldrb	w2, [x3, x2]
    a410:	7100085f 	cmp	w2, #0x2
    a414:	5400e220 	b.eq	c058 <f0+0x2308>  // b.none
    a418:	7100045f 	cmp	w2, #0x1
    a41c:	540001a1 	b.ne	a450 <f0+0x700>  // b.any
    a420:	29430002 	ldp	w2, w0, [x0, #24]
    a424:	92403c21 	and	x1, x1, #0xffff
    a428:	9b027c21 	mul	x1, x1, x2
    a42c:	d360fc21 	lsr	x1, x1, #32
    a430:	eb00003f 	cmp	x1, x0
    a434:	540000e2 	b.cs	a450 <f0+0x700>  // b.hs, b.nlast
    a438:	8b0102f7 	add	x23, x23, x1
    a43c:	394002e0 	ldrb	w0, [x23]
    a440:	7103fc1f 	cmp	w0, #0xff
    a444:	5400f000 	b.eq	c244 <f0+0x24f4>  // b.none
    a448:	52800020 	mov	w0, #0x1                   	// #1
    a44c:	390002e0 	strb	w0, [x23]
    a450:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a454:	910963e1 	add	x1, sp, #0x258
    a458:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a45c:	52800020 	mov	w0, #0x1                   	// #1
    a460:	f9012fe2 	str	x2, [sp, #600]
    a464:	f90133f5 	str	x21, [sp, #608]
    a468:	97ffea47 	bl	4d84 <fwp_data.part.0.constprop.0>
    a46c:	97ffeca5 	bl	5700 <fwp_rc_fresh>
    a470:	aa0003e2 	mov	x2, x0
    a474:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    a478:	9109a3e1 	add	x1, sp, #0x268
    a47c:	52800020 	mov	w0, #0x1                   	// #1
    a480:	f90137e3 	str	x3, [sp, #616]
    a484:	f9013be2 	str	x2, [sp, #624]
    a488:	97ffea3f 	bl	4d84 <fwp_data.part.0.constprop.0>
    a48c:	91150283 	add	x3, x20, #0x540
    a490:	aa0003f7 	mov	x23, x0
    a494:	f949d861 	ldr	x1, [x3, #5040]
    a498:	f949ec60 	ldr	x0, [x3, #5080]
    a49c:	cb0102e1 	sub	x1, x23, x1
    a4a0:	eb00403f 	cmp	x1, x0, lsl #16
    a4a4:	54000322 	b.cs	a508 <f0+0x7b8>  // b.hs, b.nlast
    a4a8:	d350fc22 	lsr	x2, x1, #16
    a4ac:	f949fc63 	ldr	x3, [x3, #5112]
    a4b0:	8b020842 	add	x2, x2, x2, lsl #2
    a4b4:	d37df042 	lsl	x2, x2, #3
    a4b8:	8b020060 	add	x0, x3, x2
    a4bc:	f9401015 	ldr	x21, [x0, #32]
    a4c0:	b4000255 	cbz	x21, a508 <f0+0x7b8>
    a4c4:	38626862 	ldrb	w2, [x3, x2]
    a4c8:	7100085f 	cmp	w2, #0x2
    a4cc:	5400dd80 	b.eq	c07c <f0+0x232c>  // b.none
    a4d0:	7100045f 	cmp	w2, #0x1
    a4d4:	540001a1 	b.ne	a508 <f0+0x7b8>  // b.any
    a4d8:	29430002 	ldp	w2, w0, [x0, #24]
    a4dc:	92403c21 	and	x1, x1, #0xffff
    a4e0:	9b027c21 	mul	x1, x1, x2
    a4e4:	d360fc21 	lsr	x1, x1, #32
    a4e8:	eb00003f 	cmp	x1, x0
    a4ec:	540000e2 	b.cs	a508 <f0+0x7b8>  // b.hs, b.nlast
    a4f0:	8b0102b5 	add	x21, x21, x1
    a4f4:	394002a0 	ldrb	w0, [x21]
    a4f8:	7103fc1f 	cmp	w0, #0xff
    a4fc:	5400eaa0 	b.eq	c250 <f0+0x2500>  // b.none
    a500:	52800020 	mov	w0, #0x1                   	// #1
    a504:	390002a0 	strb	w0, [x21]
    a508:	9109e3e1 	add	x1, sp, #0x278
    a50c:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a510:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a514:	52800020 	mov	w0, #0x1                   	// #1
    a518:	f9013ff5 	str	x21, [sp, #632]
    a51c:	f90143f7 	str	x23, [sp, #640]
    a520:	97ffea19 	bl	4d84 <fwp_data.part.0.constprop.0>
    a524:	97ffec77 	bl	5700 <fwp_rc_fresh>
    a528:	aa0003e2 	mov	x2, x0
    a52c:	910a23e1 	add	x1, sp, #0x288
    a530:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a534:	52800020 	mov	w0, #0x1                   	// #1
    a538:	f90147f7 	str	x23, [sp, #648]
    a53c:	f9014be2 	str	x2, [sp, #656]
    a540:	97ffea11 	bl	4d84 <fwp_data.part.0.constprop.0>
    a544:	97ffec6f 	bl	5700 <fwp_rc_fresh>
    a548:	aa0003e2 	mov	x2, x0
    a54c:	910a63e1 	add	x1, sp, #0x298
    a550:	52800020 	mov	w0, #0x1                   	// #1
    a554:	f9014ff5 	str	x21, [sp, #664]
    a558:	f90153e2 	str	x2, [sp, #672]
    a55c:	97ffea0a 	bl	4d84 <fwp_data.part.0.constprop.0>
    a560:	97ffec68 	bl	5700 <fwp_rc_fresh>
    a564:	aa0003e2 	mov	x2, x0
    a568:	910aa3e1 	add	x1, sp, #0x2a8
    a56c:	52800020 	mov	w0, #0x1                   	// #1
    a570:	f90157f7 	str	x23, [sp, #680]
    a574:	f9015be2 	str	x2, [sp, #688]
    a578:	97ffea03 	bl	4d84 <fwp_data.part.0.constprop.0>
    a57c:	97ffec61 	bl	5700 <fwp_rc_fresh>
    a580:	aa0003e2 	mov	x2, x0
    a584:	910ae3e1 	add	x1, sp, #0x2b8
    a588:	52800020 	mov	w0, #0x1                   	// #1
    a58c:	f9015ff5 	str	x21, [sp, #696]
    a590:	f90163e2 	str	x2, [sp, #704]
    a594:	97ffe9fc 	bl	4d84 <fwp_data.part.0.constprop.0>
    a598:	97ffec5a 	bl	5700 <fwp_rc_fresh>
    a59c:	aa0003e2 	mov	x2, x0
    a5a0:	910b23e1 	add	x1, sp, #0x2c8
    a5a4:	52800020 	mov	w0, #0x1                   	// #1
    a5a8:	f90167f7 	str	x23, [sp, #712]
    a5ac:	f9016be2 	str	x2, [sp, #720]
    a5b0:	97ffe9f5 	bl	4d84 <fwp_data.part.0.constprop.0>
    a5b4:	97ffec53 	bl	5700 <fwp_rc_fresh>
    a5b8:	aa0003e2 	mov	x2, x0
    a5bc:	910b63e1 	add	x1, sp, #0x2d8
    a5c0:	52800020 	mov	w0, #0x1                   	// #1
    a5c4:	f9016ff5 	str	x21, [sp, #728]
    a5c8:	f90173e2 	str	x2, [sp, #736]
    a5cc:	97ffe9ee 	bl	4d84 <fwp_data.part.0.constprop.0>
    a5d0:	97ffec4c 	bl	5700 <fwp_rc_fresh>
    a5d4:	aa0003e2 	mov	x2, x0
    a5d8:	910ba3e1 	add	x1, sp, #0x2e8
    a5dc:	52800020 	mov	w0, #0x1                   	// #1
    a5e0:	f90177f7 	str	x23, [sp, #744]
    a5e4:	f9017be2 	str	x2, [sp, #752]
    a5e8:	97ffe9e7 	bl	4d84 <fwp_data.part.0.constprop.0>
    a5ec:	97ffec45 	bl	5700 <fwp_rc_fresh>
    a5f0:	aa0003e2 	mov	x2, x0
    a5f4:	910be3e1 	add	x1, sp, #0x2f8
    a5f8:	52800020 	mov	w0, #0x1                   	// #1
    a5fc:	f9017ff5 	str	x21, [sp, #760]
    a600:	f90183e2 	str	x2, [sp, #768]
    a604:	97ffe9e0 	bl	4d84 <fwp_data.part.0.constprop.0>
    a608:	97ffec3e 	bl	5700 <fwp_rc_fresh>
    a60c:	aa0003e2 	mov	x2, x0
    a610:	910c23e1 	add	x1, sp, #0x308
    a614:	52800020 	mov	w0, #0x1                   	// #1
    a618:	f90187f7 	str	x23, [sp, #776]
    a61c:	f9018be2 	str	x2, [sp, #784]
    a620:	97ffe9d9 	bl	4d84 <fwp_data.part.0.constprop.0>
    a624:	97ffec37 	bl	5700 <fwp_rc_fresh>
    a628:	aa0003e2 	mov	x2, x0
    a62c:	910c63e1 	add	x1, sp, #0x318
    a630:	52800020 	mov	w0, #0x1                   	// #1
    a634:	f9018ff5 	str	x21, [sp, #792]
    a638:	f90193e2 	str	x2, [sp, #800]
    a63c:	97ffe9d2 	bl	4d84 <fwp_data.part.0.constprop.0>
    a640:	97ffec30 	bl	5700 <fwp_rc_fresh>
    a644:	aa0003e2 	mov	x2, x0
    a648:	910ca3e1 	add	x1, sp, #0x328
    a64c:	52800020 	mov	w0, #0x1                   	// #1
    a650:	f90197f7 	str	x23, [sp, #808]
    a654:	f9019be2 	str	x2, [sp, #816]
    a658:	97ffe9cb 	bl	4d84 <fwp_data.part.0.constprop.0>
    a65c:	97ffec29 	bl	5700 <fwp_rc_fresh>
    a660:	aa0003e2 	mov	x2, x0
    a664:	910ce3e1 	add	x1, sp, #0x338
    a668:	52800020 	mov	w0, #0x1                   	// #1
    a66c:	f9019ff5 	str	x21, [sp, #824]
    a670:	f901a3e2 	str	x2, [sp, #832]
    a674:	97ffe9c4 	bl	4d84 <fwp_data.part.0.constprop.0>
    a678:	97ffec22 	bl	5700 <fwp_rc_fresh>
    a67c:	aa0003e2 	mov	x2, x0
    a680:	910d23e1 	add	x1, sp, #0x348
    a684:	52800020 	mov	w0, #0x1                   	// #1
    a688:	f901a7f7 	str	x23, [sp, #840]
    a68c:	f901abe2 	str	x2, [sp, #848]
    a690:	97ffe9bd 	bl	4d84 <fwp_data.part.0.constprop.0>
    a694:	97ffec1b 	bl	5700 <fwp_rc_fresh>
    a698:	aa0003e2 	mov	x2, x0
    a69c:	910d63e1 	add	x1, sp, #0x358
    a6a0:	52800020 	mov	w0, #0x1                   	// #1
    a6a4:	f901aff5 	str	x21, [sp, #856]
    a6a8:	f901b3e2 	str	x2, [sp, #864]
    a6ac:	97ffe9b6 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6b0:	97ffec14 	bl	5700 <fwp_rc_fresh>
    a6b4:	aa0003e2 	mov	x2, x0
    a6b8:	910da3e1 	add	x1, sp, #0x368
    a6bc:	52800020 	mov	w0, #0x1                   	// #1
    a6c0:	f901b7f7 	str	x23, [sp, #872]
    a6c4:	f901bbe2 	str	x2, [sp, #880]
    a6c8:	97ffe9af 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6cc:	97ffec0d 	bl	5700 <fwp_rc_fresh>
    a6d0:	aa0003e2 	mov	x2, x0
    a6d4:	910de3e1 	add	x1, sp, #0x378
    a6d8:	52800020 	mov	w0, #0x1                   	// #1
    a6dc:	f901bff5 	str	x21, [sp, #888]
    a6e0:	f901c3e2 	str	x2, [sp, #896]
    a6e4:	97ffe9a8 	bl	4d84 <fwp_data.part.0.constprop.0>
    a6e8:	97ffec06 	bl	5700 <fwp_rc_fresh>
    a6ec:	aa0003e2 	mov	x2, x0
    a6f0:	910e23e1 	add	x1, sp, #0x388
    a6f4:	52800020 	mov	w0, #0x1                   	// #1
    a6f8:	f901c7f7 	str	x23, [sp, #904]
    a6fc:	f901cbe2 	str	x2, [sp, #912]
    a700:	97ffe9a1 	bl	4d84 <fwp_data.part.0.constprop.0>
    a704:	97ffebff 	bl	5700 <fwp_rc_fresh>
    a708:	aa0003e2 	mov	x2, x0
    a70c:	910e63e1 	add	x1, sp, #0x398
    a710:	52800020 	mov	w0, #0x1                   	// #1
    a714:	f901cff5 	str	x21, [sp, #920]
    a718:	f901d3e2 	str	x2, [sp, #928]
    a71c:	97ffe99a 	bl	4d84 <fwp_data.part.0.constprop.0>
    a720:	91150283 	add	x3, x20, #0x540
    a724:	aa0003f5 	mov	x21, x0
    a728:	f949d861 	ldr	x1, [x3, #5040]
    a72c:	f949ec60 	ldr	x0, [x3, #5080]
    a730:	cb0102a1 	sub	x1, x21, x1
    a734:	eb00403f 	cmp	x1, x0, lsl #16
    a738:	54000322 	b.cs	a79c <f0+0xa4c>  // b.hs, b.nlast
    a73c:	d350fc22 	lsr	x2, x1, #16
    a740:	f949fc63 	ldr	x3, [x3, #5112]
    a744:	8b020842 	add	x2, x2, x2, lsl #2
    a748:	d37df042 	lsl	x2, x2, #3
    a74c:	8b020060 	add	x0, x3, x2
    a750:	f9401017 	ldr	x23, [x0, #32]
    a754:	b4000257 	cbz	x23, a79c <f0+0xa4c>
    a758:	38626862 	ldrb	w2, [x3, x2]
    a75c:	7100085f 	cmp	w2, #0x2
    a760:	5400c880 	b.eq	c070 <f0+0x2320>  // b.none
    a764:	7100045f 	cmp	w2, #0x1
    a768:	540001a1 	b.ne	a79c <f0+0xa4c>  // b.any
    a76c:	29430002 	ldp	w2, w0, [x0, #24]
    a770:	92403c21 	and	x1, x1, #0xffff
    a774:	9b027c21 	mul	x1, x1, x2
    a778:	d360fc21 	lsr	x1, x1, #32
    a77c:	eb00003f 	cmp	x1, x0
    a780:	540000e2 	b.cs	a79c <f0+0xa4c>  // b.hs, b.nlast
    a784:	8b0102f7 	add	x23, x23, x1
    a788:	394002e0 	ldrb	w0, [x23]
    a78c:	7103fc1f 	cmp	w0, #0xff
    a790:	5400d660 	b.eq	c25c <f0+0x250c>  // b.none
    a794:	52800020 	mov	w0, #0x1                   	// #1
    a798:	390002e0 	strb	w0, [x23]
    a79c:	910ea3e1 	add	x1, sp, #0x3a8
    a7a0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a7a4:	52800020 	mov	w0, #0x1                   	// #1
    a7a8:	f901d7e2 	str	x2, [sp, #936]
    a7ac:	f901dbf5 	str	x21, [sp, #944]
    a7b0:	97ffe975 	bl	4d84 <fwp_data.part.0.constprop.0>
    a7b4:	97ffebd3 	bl	5700 <fwp_rc_fresh>
    a7b8:	aa0003e2 	mov	x2, x0
    a7bc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a7c0:	910ee3e1 	add	x1, sp, #0x3b8
    a7c4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a7c8:	52800020 	mov	w0, #0x1                   	// #1
    a7cc:	f901dfe3 	str	x3, [sp, #952]
    a7d0:	f901e3e2 	str	x2, [sp, #960]
    a7d4:	97ffe96c 	bl	4d84 <fwp_data.part.0.constprop.0>
    a7d8:	91150283 	add	x3, x20, #0x540
    a7dc:	aa0003f5 	mov	x21, x0
    a7e0:	f949d861 	ldr	x1, [x3, #5040]
    a7e4:	f949ec60 	ldr	x0, [x3, #5080]
    a7e8:	cb0102a1 	sub	x1, x21, x1
    a7ec:	eb00403f 	cmp	x1, x0, lsl #16
    a7f0:	54000322 	b.cs	a854 <f0+0xb04>  // b.hs, b.nlast
    a7f4:	d350fc22 	lsr	x2, x1, #16
    a7f8:	f949fc63 	ldr	x3, [x3, #5112]
    a7fc:	8b020842 	add	x2, x2, x2, lsl #2
    a800:	d37df042 	lsl	x2, x2, #3
    a804:	8b020060 	add	x0, x3, x2
    a808:	f9401017 	ldr	x23, [x0, #32]
    a80c:	b4000257 	cbz	x23, a854 <f0+0xb04>
    a810:	38626862 	ldrb	w2, [x3, x2]
    a814:	7100085f 	cmp	w2, #0x2
    a818:	5400c9e0 	b.eq	c154 <f0+0x2404>  // b.none
    a81c:	7100045f 	cmp	w2, #0x1
    a820:	540001a1 	b.ne	a854 <f0+0xb04>  // b.any
    a824:	29430002 	ldp	w2, w0, [x0, #24]
    a828:	92403c21 	and	x1, x1, #0xffff
    a82c:	9b027c21 	mul	x1, x1, x2
    a830:	d360fc21 	lsr	x1, x1, #32
    a834:	eb00003f 	cmp	x1, x0
    a838:	540000e2 	b.cs	a854 <f0+0xb04>  // b.hs, b.nlast
    a83c:	8b0102f7 	add	x23, x23, x1
    a840:	394002e0 	ldrb	w0, [x23]
    a844:	7103fc1f 	cmp	w0, #0xff
    a848:	5400d100 	b.eq	c268 <f0+0x2518>  // b.none
    a84c:	52800020 	mov	w0, #0x1                   	// #1
    a850:	390002e0 	strb	w0, [x23]
    a854:	910f23e1 	add	x1, sp, #0x3c8
    a858:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a85c:	52800020 	mov	w0, #0x1                   	// #1
    a860:	f901e7e2 	str	x2, [sp, #968]
    a864:	f901ebf5 	str	x21, [sp, #976]
    a868:	97ffe947 	bl	4d84 <fwp_data.part.0.constprop.0>
    a86c:	97ffeba5 	bl	5700 <fwp_rc_fresh>
    a870:	aa0003e2 	mov	x2, x0
    a874:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a878:	910f63e1 	add	x1, sp, #0x3d8
    a87c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a880:	52800020 	mov	w0, #0x1                   	// #1
    a884:	f901efe3 	str	x3, [sp, #984]
    a888:	f901f3e2 	str	x2, [sp, #992]
    a88c:	97ffe93e 	bl	4d84 <fwp_data.part.0.constprop.0>
    a890:	91150283 	add	x3, x20, #0x540
    a894:	aa0003f5 	mov	x21, x0
    a898:	f949d861 	ldr	x1, [x3, #5040]
    a89c:	f949ec60 	ldr	x0, [x3, #5080]
    a8a0:	cb0102a1 	sub	x1, x21, x1
    a8a4:	eb00403f 	cmp	x1, x0, lsl #16
    a8a8:	54000322 	b.cs	a90c <f0+0xbbc>  // b.hs, b.nlast
    a8ac:	d350fc22 	lsr	x2, x1, #16
    a8b0:	f949fc63 	ldr	x3, [x3, #5112]
    a8b4:	8b020842 	add	x2, x2, x2, lsl #2
    a8b8:	d37df042 	lsl	x2, x2, #3
    a8bc:	8b020060 	add	x0, x3, x2
    a8c0:	f9401017 	ldr	x23, [x0, #32]
    a8c4:	b4000257 	cbz	x23, a90c <f0+0xbbc>
    a8c8:	38626862 	ldrb	w2, [x3, x2]
    a8cc:	7100085f 	cmp	w2, #0x2
    a8d0:	5400c3c0 	b.eq	c148 <f0+0x23f8>  // b.none
    a8d4:	7100045f 	cmp	w2, #0x1
    a8d8:	540001a1 	b.ne	a90c <f0+0xbbc>  // b.any
    a8dc:	29430002 	ldp	w2, w0, [x0, #24]
    a8e0:	92403c21 	and	x1, x1, #0xffff
    a8e4:	9b027c21 	mul	x1, x1, x2
    a8e8:	d360fc21 	lsr	x1, x1, #32
    a8ec:	eb00003f 	cmp	x1, x0
    a8f0:	540000e2 	b.cs	a90c <f0+0xbbc>  // b.hs, b.nlast
    a8f4:	8b0102f7 	add	x23, x23, x1
    a8f8:	394002e0 	ldrb	w0, [x23]
    a8fc:	7103fc1f 	cmp	w0, #0xff
    a900:	5400cba0 	b.eq	c274 <f0+0x2524>  // b.none
    a904:	52800020 	mov	w0, #0x1                   	// #1
    a908:	390002e0 	strb	w0, [x23]
    a90c:	910fa3e1 	add	x1, sp, #0x3e8
    a910:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a914:	52800020 	mov	w0, #0x1                   	// #1
    a918:	f901f7e2 	str	x2, [sp, #1000]
    a91c:	f901fbf5 	str	x21, [sp, #1008]
    a920:	97ffe919 	bl	4d84 <fwp_data.part.0.constprop.0>
    a924:	97ffeb77 	bl	5700 <fwp_rc_fresh>
    a928:	aa0003e2 	mov	x2, x0
    a92c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    a930:	910fe3e1 	add	x1, sp, #0x3f8
    a934:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    a938:	52800020 	mov	w0, #0x1                   	// #1
    a93c:	f901ffe3 	str	x3, [sp, #1016]
    a940:	f90203e2 	str	x2, [sp, #1024]
    a944:	97ffe910 	bl	4d84 <fwp_data.part.0.constprop.0>
    a948:	91150283 	add	x3, x20, #0x540
    a94c:	aa0003f5 	mov	x21, x0
    a950:	f949d861 	ldr	x1, [x3, #5040]
    a954:	f949ec60 	ldr	x0, [x3, #5080]
    a958:	cb0102a1 	sub	x1, x21, x1
    a95c:	eb00403f 	cmp	x1, x0, lsl #16
    a960:	54000322 	b.cs	a9c4 <f0+0xc74>  // b.hs, b.nlast
    a964:	d350fc22 	lsr	x2, x1, #16
    a968:	f949fc63 	ldr	x3, [x3, #5112]
    a96c:	8b020842 	add	x2, x2, x2, lsl #2
    a970:	d37df042 	lsl	x2, x2, #3
    a974:	8b020060 	add	x0, x3, x2
    a978:	f9401017 	ldr	x23, [x0, #32]
    a97c:	b4000257 	cbz	x23, a9c4 <f0+0xc74>
    a980:	38626862 	ldrb	w2, [x3, x2]
    a984:	7100085f 	cmp	w2, #0x2
    a988:	5400bf20 	b.eq	c16c <f0+0x241c>  // b.none
    a98c:	7100045f 	cmp	w2, #0x1
    a990:	540001a1 	b.ne	a9c4 <f0+0xc74>  // b.any
    a994:	29430002 	ldp	w2, w0, [x0, #24]
    a998:	92403c21 	and	x1, x1, #0xffff
    a99c:	9b027c21 	mul	x1, x1, x2
    a9a0:	d360fc21 	lsr	x1, x1, #32
    a9a4:	eb00003f 	cmp	x1, x0
    a9a8:	540000e2 	b.cs	a9c4 <f0+0xc74>  // b.hs, b.nlast
    a9ac:	8b0102f7 	add	x23, x23, x1
    a9b0:	394002e0 	ldrb	w0, [x23]
    a9b4:	7103fc1f 	cmp	w0, #0xff
    a9b8:	5400c640 	b.eq	c280 <f0+0x2530>  // b.none
    a9bc:	52800020 	mov	w0, #0x1                   	// #1
    a9c0:	390002e0 	strb	w0, [x23]
    a9c4:	911023e1 	add	x1, sp, #0x408
    a9c8:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    a9cc:	52800020 	mov	w0, #0x1                   	// #1
    a9d0:	f90207f7 	str	x23, [sp, #1032]
    a9d4:	f9020bf5 	str	x21, [sp, #1040]
    a9d8:	97ffe8eb 	bl	4d84 <fwp_data.part.0.constprop.0>
    a9dc:	97ffeb49 	bl	5700 <fwp_rc_fresh>
    a9e0:	aa0003e2 	mov	x2, x0
    a9e4:	911063e1 	add	x1, sp, #0x418
    a9e8:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    a9ec:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    a9f0:	52800020 	mov	w0, #0x1                   	// #1
    a9f4:	f9020ff5 	str	x21, [sp, #1048]
    a9f8:	f90213e2 	str	x2, [sp, #1056]
    a9fc:	97ffe8e2 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa00:	97ffeb40 	bl	5700 <fwp_rc_fresh>
    aa04:	aa0003e2 	mov	x2, x0
    aa08:	9110a3e1 	add	x1, sp, #0x428
    aa0c:	52800020 	mov	w0, #0x1                   	// #1
    aa10:	f90217f7 	str	x23, [sp, #1064]
    aa14:	f9021be2 	str	x2, [sp, #1072]
    aa18:	97ffe8db 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa1c:	97ffeb39 	bl	5700 <fwp_rc_fresh>
    aa20:	aa0003e2 	mov	x2, x0
    aa24:	9110e3e1 	add	x1, sp, #0x438
    aa28:	52800020 	mov	w0, #0x1                   	// #1
    aa2c:	f9021ff5 	str	x21, [sp, #1080]
    aa30:	f90223e2 	str	x2, [sp, #1088]
    aa34:	97ffe8d4 	bl	4d84 <fwp_data.part.0.constprop.0>
    aa38:	91150283 	add	x3, x20, #0x540
    aa3c:	aa0003f5 	mov	x21, x0
    aa40:	f949d861 	ldr	x1, [x3, #5040]
    aa44:	f949ec60 	ldr	x0, [x3, #5080]
    aa48:	cb0102a1 	sub	x1, x21, x1
    aa4c:	eb00403f 	cmp	x1, x0, lsl #16
    aa50:	54000322 	b.cs	aab4 <f0+0xd64>  // b.hs, b.nlast
    aa54:	d350fc22 	lsr	x2, x1, #16
    aa58:	f949fc63 	ldr	x3, [x3, #5112]
    aa5c:	8b020842 	add	x2, x2, x2, lsl #2
    aa60:	d37df042 	lsl	x2, x2, #3
    aa64:	8b020060 	add	x0, x3, x2
    aa68:	f9401017 	ldr	x23, [x0, #32]
    aa6c:	b4000257 	cbz	x23, aab4 <f0+0xd64>
    aa70:	38626862 	ldrb	w2, [x3, x2]
    aa74:	7100085f 	cmp	w2, #0x2
    aa78:	5400b740 	b.eq	c160 <f0+0x2410>  // b.none
    aa7c:	7100045f 	cmp	w2, #0x1
    aa80:	540001a1 	b.ne	aab4 <f0+0xd64>  // b.any
    aa84:	29430002 	ldp	w2, w0, [x0, #24]
    aa88:	92403c21 	and	x1, x1, #0xffff
    aa8c:	9b027c21 	mul	x1, x1, x2
    aa90:	d360fc21 	lsr	x1, x1, #32
    aa94:	eb00003f 	cmp	x1, x0
    aa98:	540000e2 	b.cs	aab4 <f0+0xd64>  // b.hs, b.nlast
    aa9c:	8b0102f7 	add	x23, x23, x1
    aaa0:	394002e0 	ldrb	w0, [x23]
    aaa4:	7103fc1f 	cmp	w0, #0xff
    aaa8:	5400bf20 	b.eq	c28c <f0+0x253c>  // b.none
    aaac:	52800020 	mov	w0, #0x1                   	// #1
    aab0:	390002e0 	strb	w0, [x23]
    aab4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aab8:	911123e1 	add	x1, sp, #0x448
    aabc:	52800020 	mov	w0, #0x1                   	// #1
    aac0:	f90227e2 	str	x2, [sp, #1096]
    aac4:	f9022bf5 	str	x21, [sp, #1104]
    aac8:	97ffe8af 	bl	4d84 <fwp_data.part.0.constprop.0>
    aacc:	91150283 	add	x3, x20, #0x540
    aad0:	aa0003f5 	mov	x21, x0
    aad4:	f949d861 	ldr	x1, [x3, #5040]
    aad8:	f949ec60 	ldr	x0, [x3, #5080]
    aadc:	cb0102a1 	sub	x1, x21, x1
    aae0:	eb00403f 	cmp	x1, x0, lsl #16
    aae4:	54000322 	b.cs	ab48 <f0+0xdf8>  // b.hs, b.nlast
    aae8:	d350fc22 	lsr	x2, x1, #16
    aaec:	f949fc63 	ldr	x3, [x3, #5112]
    aaf0:	8b020842 	add	x2, x2, x2, lsl #2
    aaf4:	d37df042 	lsl	x2, x2, #3
    aaf8:	8b020060 	add	x0, x3, x2
    aafc:	f9401017 	ldr	x23, [x0, #32]
    ab00:	b4000257 	cbz	x23, ab48 <f0+0xdf8>
    ab04:	38626862 	ldrb	w2, [x3, x2]
    ab08:	7100085f 	cmp	w2, #0x2
    ab0c:	5400b3c0 	b.eq	c184 <f0+0x2434>  // b.none
    ab10:	7100045f 	cmp	w2, #0x1
    ab14:	540001a1 	b.ne	ab48 <f0+0xdf8>  // b.any
    ab18:	29430002 	ldp	w2, w0, [x0, #24]
    ab1c:	92403c21 	and	x1, x1, #0xffff
    ab20:	9b027c21 	mul	x1, x1, x2
    ab24:	d360fc21 	lsr	x1, x1, #32
    ab28:	eb00003f 	cmp	x1, x0
    ab2c:	540000e2 	b.cs	ab48 <f0+0xdf8>  // b.hs, b.nlast
    ab30:	8b0102f7 	add	x23, x23, x1
    ab34:	394002e0 	ldrb	w0, [x23]
    ab38:	7103fc1f 	cmp	w0, #0xff
    ab3c:	5400bae0 	b.eq	c298 <f0+0x2548>  // b.none
    ab40:	52800020 	mov	w0, #0x1                   	// #1
    ab44:	390002e0 	strb	w0, [x23]
    ab48:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ab4c:	911163e1 	add	x1, sp, #0x458
    ab50:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ab54:	52800020 	mov	w0, #0x1                   	// #1
    ab58:	f9022fe2 	str	x2, [sp, #1112]
    ab5c:	f90233f5 	str	x21, [sp, #1120]
    ab60:	97ffe889 	bl	4d84 <fwp_data.part.0.constprop.0>
    ab64:	91150283 	add	x3, x20, #0x540
    ab68:	aa0003f5 	mov	x21, x0
    ab6c:	f949d861 	ldr	x1, [x3, #5040]
    ab70:	f949ec60 	ldr	x0, [x3, #5080]
    ab74:	cb0102a1 	sub	x1, x21, x1
    ab78:	eb00403f 	cmp	x1, x0, lsl #16
    ab7c:	54000322 	b.cs	abe0 <f0+0xe90>  // b.hs, b.nlast
    ab80:	d350fc22 	lsr	x2, x1, #16
    ab84:	f949fc63 	ldr	x3, [x3, #5112]
    ab88:	8b020842 	add	x2, x2, x2, lsl #2
    ab8c:	d37df042 	lsl	x2, x2, #3
    ab90:	8b020060 	add	x0, x3, x2
    ab94:	f9401017 	ldr	x23, [x0, #32]
    ab98:	b4000257 	cbz	x23, abe0 <f0+0xe90>
    ab9c:	38626862 	ldrb	w2, [x3, x2]
    aba0:	7100085f 	cmp	w2, #0x2
    aba4:	5400aea0 	b.eq	c178 <f0+0x2428>  // b.none
    aba8:	7100045f 	cmp	w2, #0x1
    abac:	540001a1 	b.ne	abe0 <f0+0xe90>  // b.any
    abb0:	29430002 	ldp	w2, w0, [x0, #24]
    abb4:	92403c21 	and	x1, x1, #0xffff
    abb8:	9b027c21 	mul	x1, x1, x2
    abbc:	d360fc21 	lsr	x1, x1, #32
    abc0:	eb00003f 	cmp	x1, x0
    abc4:	540000e2 	b.cs	abe0 <f0+0xe90>  // b.hs, b.nlast
    abc8:	8b0102f7 	add	x23, x23, x1
    abcc:	394002e0 	ldrb	w0, [x23]
    abd0:	7103fc1f 	cmp	w0, #0xff
    abd4:	5400b680 	b.eq	c2a4 <f0+0x2554>  // b.none
    abd8:	52800020 	mov	w0, #0x1                   	// #1
    abdc:	390002e0 	strb	w0, [x23]
    abe0:	9111a3e1 	add	x1, sp, #0x468
    abe4:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    abe8:	52800020 	mov	w0, #0x1                   	// #1
    abec:	f90237e2 	str	x2, [sp, #1128]
    abf0:	f9023bf5 	str	x21, [sp, #1136]
    abf4:	97ffe864 	bl	4d84 <fwp_data.part.0.constprop.0>
    abf8:	97ffeac2 	bl	5700 <fwp_rc_fresh>
    abfc:	aa0003e2 	mov	x2, x0
    ac00:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ac04:	9111e3e1 	add	x1, sp, #0x478
    ac08:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ac0c:	52800020 	mov	w0, #0x1                   	// #1
    ac10:	f9023fe3 	str	x3, [sp, #1144]
    ac14:	f90243e2 	str	x2, [sp, #1152]
    ac18:	97ffe85b 	bl	4d84 <fwp_data.part.0.constprop.0>
    ac1c:	91150283 	add	x3, x20, #0x540
    ac20:	aa0003f5 	mov	x21, x0
    ac24:	f949d861 	ldr	x1, [x3, #5040]
    ac28:	f949ec60 	ldr	x0, [x3, #5080]
    ac2c:	cb0102a1 	sub	x1, x21, x1
    ac30:	eb00403f 	cmp	x1, x0, lsl #16
    ac34:	54000322 	b.cs	ac98 <f0+0xf48>  // b.hs, b.nlast
    ac38:	d350fc22 	lsr	x2, x1, #16
    ac3c:	f949fc63 	ldr	x3, [x3, #5112]
    ac40:	8b020842 	add	x2, x2, x2, lsl #2
    ac44:	d37df042 	lsl	x2, x2, #3
    ac48:	8b020060 	add	x0, x3, x2
    ac4c:	f9401017 	ldr	x23, [x0, #32]
    ac50:	b4000257 	cbz	x23, ac98 <f0+0xf48>
    ac54:	38626862 	ldrb	w2, [x3, x2]
    ac58:	7100085f 	cmp	w2, #0x2
    ac5c:	5400aa00 	b.eq	c19c <f0+0x244c>  // b.none
    ac60:	7100045f 	cmp	w2, #0x1
    ac64:	540001a1 	b.ne	ac98 <f0+0xf48>  // b.any
    ac68:	29430002 	ldp	w2, w0, [x0, #24]
    ac6c:	92403c21 	and	x1, x1, #0xffff
    ac70:	9b027c21 	mul	x1, x1, x2
    ac74:	d360fc21 	lsr	x1, x1, #32
    ac78:	eb00003f 	cmp	x1, x0
    ac7c:	540000e2 	b.cs	ac98 <f0+0xf48>  // b.hs, b.nlast
    ac80:	8b0102f7 	add	x23, x23, x1
    ac84:	394002e0 	ldrb	w0, [x23]
    ac88:	7103fc1f 	cmp	w0, #0xff
    ac8c:	5400b120 	b.eq	c2b0 <f0+0x2560>  // b.none
    ac90:	52800020 	mov	w0, #0x1                   	// #1
    ac94:	390002e0 	strb	w0, [x23]
    ac98:	911223e1 	add	x1, sp, #0x488
    ac9c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aca0:	52800020 	mov	w0, #0x1                   	// #1
    aca4:	f90247e2 	str	x2, [sp, #1160]
    aca8:	f9024bf5 	str	x21, [sp, #1168]
    acac:	97ffe836 	bl	4d84 <fwp_data.part.0.constprop.0>
    acb0:	97ffea94 	bl	5700 <fwp_rc_fresh>
    acb4:	aa0003e2 	mov	x2, x0
    acb8:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    acbc:	911263e1 	add	x1, sp, #0x498
    acc0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    acc4:	52800020 	mov	w0, #0x1                   	// #1
    acc8:	f9024fe3 	str	x3, [sp, #1176]
    accc:	f90253e2 	str	x2, [sp, #1184]
    acd0:	97ffe82d 	bl	4d84 <fwp_data.part.0.constprop.0>
    acd4:	91150283 	add	x3, x20, #0x540
    acd8:	aa0003f5 	mov	x21, x0
    acdc:	f949d861 	ldr	x1, [x3, #5040]
    ace0:	f949ec60 	ldr	x0, [x3, #5080]
    ace4:	cb0102a1 	sub	x1, x21, x1
    ace8:	eb00403f 	cmp	x1, x0, lsl #16
    acec:	54000322 	b.cs	ad50 <f0+0x1000>  // b.hs, b.nlast
    acf0:	d350fc22 	lsr	x2, x1, #16
    acf4:	f949fc63 	ldr	x3, [x3, #5112]
    acf8:	8b020842 	add	x2, x2, x2, lsl #2
    acfc:	d37df042 	lsl	x2, x2, #3
    ad00:	8b020060 	add	x0, x3, x2
    ad04:	f9401017 	ldr	x23, [x0, #32]
    ad08:	b4000257 	cbz	x23, ad50 <f0+0x1000>
    ad0c:	38626862 	ldrb	w2, [x3, x2]
    ad10:	7100085f 	cmp	w2, #0x2
    ad14:	5400a3e0 	b.eq	c190 <f0+0x2440>  // b.none
    ad18:	7100045f 	cmp	w2, #0x1
    ad1c:	540001a1 	b.ne	ad50 <f0+0x1000>  // b.any
    ad20:	29430002 	ldp	w2, w0, [x0, #24]
    ad24:	92403c21 	and	x1, x1, #0xffff
    ad28:	9b027c21 	mul	x1, x1, x2
    ad2c:	d360fc21 	lsr	x1, x1, #32
    ad30:	eb00003f 	cmp	x1, x0
    ad34:	540000e2 	b.cs	ad50 <f0+0x1000>  // b.hs, b.nlast
    ad38:	8b0102f7 	add	x23, x23, x1
    ad3c:	394002e0 	ldrb	w0, [x23]
    ad40:	7103fc1f 	cmp	w0, #0xff
    ad44:	5400abc0 	b.eq	c2bc <f0+0x256c>  // b.none
    ad48:	52800020 	mov	w0, #0x1                   	// #1
    ad4c:	390002e0 	strb	w0, [x23]
    ad50:	9112a3e1 	add	x1, sp, #0x4a8
    ad54:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ad58:	52800020 	mov	w0, #0x1                   	// #1
    ad5c:	f90257f7 	str	x23, [sp, #1192]
    ad60:	f9025bf5 	str	x21, [sp, #1200]
    ad64:	97ffe808 	bl	4d84 <fwp_data.part.0.constprop.0>
    ad68:	97ffea66 	bl	5700 <fwp_rc_fresh>
    ad6c:	aa0003e2 	mov	x2, x0
    ad70:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    ad74:	9112e3e1 	add	x1, sp, #0x4b8
    ad78:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    ad7c:	52800020 	mov	w0, #0x1                   	// #1
    ad80:	f9025fe3 	str	x3, [sp, #1208]
    ad84:	f90263e2 	str	x2, [sp, #1216]
    ad88:	97ffe7ff 	bl	4d84 <fwp_data.part.0.constprop.0>
    ad8c:	97ffea5d 	bl	5700 <fwp_rc_fresh>
    ad90:	aa0003e2 	mov	x2, x0
    ad94:	911323e1 	add	x1, sp, #0x4c8
    ad98:	52800020 	mov	w0, #0x1                   	// #1
    ad9c:	f90267f7 	str	x23, [sp, #1224]
    ada0:	f9026be2 	str	x2, [sp, #1232]
    ada4:	97ffe7f8 	bl	4d84 <fwp_data.part.0.constprop.0>
    ada8:	91150283 	add	x3, x20, #0x540
    adac:	aa0003f5 	mov	x21, x0
    adb0:	f949d861 	ldr	x1, [x3, #5040]
    adb4:	f949ec60 	ldr	x0, [x3, #5080]
    adb8:	cb0102a1 	sub	x1, x21, x1
    adbc:	eb00403f 	cmp	x1, x0, lsl #16
    adc0:	54000322 	b.cs	ae24 <f0+0x10d4>  // b.hs, b.nlast
    adc4:	d350fc22 	lsr	x2, x1, #16
    adc8:	f949fc63 	ldr	x3, [x3, #5112]
    adcc:	8b020842 	add	x2, x2, x2, lsl #2
    add0:	d37df042 	lsl	x2, x2, #3
    add4:	8b020060 	add	x0, x3, x2
    add8:	f9401017 	ldr	x23, [x0, #32]
    addc:	b4000257 	cbz	x23, ae24 <f0+0x10d4>
    ade0:	38626862 	ldrb	w2, [x3, x2]
    ade4:	7100085f 	cmp	w2, #0x2
    ade8:	54009e60 	b.eq	c1b4 <f0+0x2464>  // b.none
    adec:	7100045f 	cmp	w2, #0x1
    adf0:	540001a1 	b.ne	ae24 <f0+0x10d4>  // b.any
    adf4:	29430002 	ldp	w2, w0, [x0, #24]
    adf8:	92403c21 	and	x1, x1, #0xffff
    adfc:	9b027c21 	mul	x1, x1, x2
    ae00:	d360fc21 	lsr	x1, x1, #32
    ae04:	eb00003f 	cmp	x1, x0
    ae08:	540000e2 	b.cs	ae24 <f0+0x10d4>  // b.hs, b.nlast
    ae0c:	8b0102f7 	add	x23, x23, x1
    ae10:	394002e0 	ldrb	w0, [x23]
    ae14:	7103fc1f 	cmp	w0, #0xff
    ae18:	5400a580 	b.eq	c2c8 <f0+0x2578>  // b.none
    ae1c:	52800020 	mov	w0, #0x1                   	// #1
    ae20:	390002e0 	strb	w0, [x23]
    ae24:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    ae28:	911363e1 	add	x1, sp, #0x4d8
    ae2c:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    ae30:	52800020 	mov	w0, #0x1                   	// #1
    ae34:	f9026fe2 	str	x2, [sp, #1240]
    ae38:	f90273f5 	str	x21, [sp, #1248]
    ae3c:	97ffe7d2 	bl	4d84 <fwp_data.part.0.constprop.0>
    ae40:	91150283 	add	x3, x20, #0x540
    ae44:	aa0003f5 	mov	x21, x0
    ae48:	f949d861 	ldr	x1, [x3, #5040]
    ae4c:	f949ec60 	ldr	x0, [x3, #5080]
    ae50:	cb0102a1 	sub	x1, x21, x1
    ae54:	eb00403f 	cmp	x1, x0, lsl #16
    ae58:	54000322 	b.cs	aebc <f0+0x116c>  // b.hs, b.nlast
    ae5c:	d350fc22 	lsr	x2, x1, #16
    ae60:	f949fc63 	ldr	x3, [x3, #5112]
    ae64:	8b020842 	add	x2, x2, x2, lsl #2
    ae68:	d37df042 	lsl	x2, x2, #3
    ae6c:	8b020060 	add	x0, x3, x2
    ae70:	f9401017 	ldr	x23, [x0, #32]
    ae74:	b4000257 	cbz	x23, aebc <f0+0x116c>
    ae78:	38626862 	ldrb	w2, [x3, x2]
    ae7c:	7100085f 	cmp	w2, #0x2
    ae80:	54009940 	b.eq	c1a8 <f0+0x2458>  // b.none
    ae84:	7100045f 	cmp	w2, #0x1
    ae88:	540001a1 	b.ne	aebc <f0+0x116c>  // b.any
    ae8c:	29430002 	ldp	w2, w0, [x0, #24]
    ae90:	92403c21 	and	x1, x1, #0xffff
    ae94:	9b027c21 	mul	x1, x1, x2
    ae98:	d360fc21 	lsr	x1, x1, #32
    ae9c:	eb00003f 	cmp	x1, x0
    aea0:	540000e2 	b.cs	aebc <f0+0x116c>  // b.hs, b.nlast
    aea4:	8b0102f7 	add	x23, x23, x1
    aea8:	394002e0 	ldrb	w0, [x23]
    aeac:	7103fc1f 	cmp	w0, #0xff
    aeb0:	5400a120 	b.eq	c2d4 <f0+0x2584>  // b.none
    aeb4:	52800020 	mov	w0, #0x1                   	// #1
    aeb8:	390002e0 	strb	w0, [x23]
    aebc:	9113a3e1 	add	x1, sp, #0x4e8
    aec0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    aec4:	52800020 	mov	w0, #0x1                   	// #1
    aec8:	f90277e2 	str	x2, [sp, #1256]
    aecc:	f9027bf5 	str	x21, [sp, #1264]
    aed0:	97ffe7ad 	bl	4d84 <fwp_data.part.0.constprop.0>
    aed4:	97ffea0b 	bl	5700 <fwp_rc_fresh>
    aed8:	aa0003e2 	mov	x2, x0
    aedc:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    aee0:	9113e3e1 	add	x1, sp, #0x4f8
    aee4:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    aee8:	52800020 	mov	w0, #0x1                   	// #1
    aeec:	f9027fe3 	str	x3, [sp, #1272]
    aef0:	f90283e2 	str	x2, [sp, #1280]
    aef4:	97ffe7a4 	bl	4d84 <fwp_data.part.0.constprop.0>
    aef8:	91150283 	add	x3, x20, #0x540
    aefc:	aa0003f5 	mov	x21, x0
    af00:	f949d861 	ldr	x1, [x3, #5040]
    af04:	f949ec60 	ldr	x0, [x3, #5080]
    af08:	cb0102a1 	sub	x1, x21, x1
    af0c:	eb00403f 	cmp	x1, x0, lsl #16
    af10:	54000322 	b.cs	af74 <f0+0x1224>  // b.hs, b.nlast
    af14:	d350fc22 	lsr	x2, x1, #16
    af18:	f949fc63 	ldr	x3, [x3, #5112]
    af1c:	8b020842 	add	x2, x2, x2, lsl #2
    af20:	d37df042 	lsl	x2, x2, #3
    af24:	8b020060 	add	x0, x3, x2
    af28:	f9401017 	ldr	x23, [x0, #32]
    af2c:	b4000257 	cbz	x23, af74 <f0+0x1224>
    af30:	38626862 	ldrb	w2, [x3, x2]
    af34:	7100085f 	cmp	w2, #0x2
    af38:	540094a0 	b.eq	c1cc <f0+0x247c>  // b.none
    af3c:	7100045f 	cmp	w2, #0x1
    af40:	540001a1 	b.ne	af74 <f0+0x1224>  // b.any
    af44:	29430002 	ldp	w2, w0, [x0, #24]
    af48:	92403c21 	and	x1, x1, #0xffff
    af4c:	9b027c21 	mul	x1, x1, x2
    af50:	d360fc21 	lsr	x1, x1, #32
    af54:	eb00003f 	cmp	x1, x0
    af58:	540000e2 	b.cs	af74 <f0+0x1224>  // b.hs, b.nlast
    af5c:	8b0102f7 	add	x23, x23, x1
    af60:	394002e0 	ldrb	w0, [x23]
    af64:	7103fc1f 	cmp	w0, #0xff
    af68:	54009bc0 	b.eq	c2e0 <f0+0x2590>  // b.none
    af6c:	52800020 	mov	w0, #0x1                   	// #1
    af70:	390002e0 	strb	w0, [x23]
    af74:	911423e1 	add	x1, sp, #0x508
    af78:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    af7c:	52800020 	mov	w0, #0x1                   	// #1
    af80:	f90287e2 	str	x2, [sp, #1288]
    af84:	f9028bf5 	str	x21, [sp, #1296]
    af88:	97ffe77f 	bl	4d84 <fwp_data.part.0.constprop.0>
    af8c:	97ffe9dd 	bl	5700 <fwp_rc_fresh>
    af90:	aa0003e2 	mov	x2, x0
    af94:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    af98:	911463e1 	add	x1, sp, #0x518
    af9c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    afa0:	52800020 	mov	w0, #0x1                   	// #1
    afa4:	f9028fe3 	str	x3, [sp, #1304]
    afa8:	f90293e2 	str	x2, [sp, #1312]
    afac:	97ffe776 	bl	4d84 <fwp_data.part.0.constprop.0>
    afb0:	91150283 	add	x3, x20, #0x540
    afb4:	aa0003f5 	mov	x21, x0
    afb8:	f949d861 	ldr	x1, [x3, #5040]
    afbc:	f949ec60 	ldr	x0, [x3, #5080]
    afc0:	cb0102a1 	sub	x1, x21, x1
    afc4:	eb00403f 	cmp	x1, x0, lsl #16
    afc8:	54000322 	b.cs	b02c <f0+0x12dc>  // b.hs, b.nlast
    afcc:	d350fc22 	lsr	x2, x1, #16
    afd0:	f949fc63 	ldr	x3, [x3, #5112]
    afd4:	8b020842 	add	x2, x2, x2, lsl #2
    afd8:	d37df042 	lsl	x2, x2, #3
    afdc:	8b020060 	add	x0, x3, x2
    afe0:	f9401017 	ldr	x23, [x0, #32]
    afe4:	b4000257 	cbz	x23, b02c <f0+0x12dc>
    afe8:	38626862 	ldrb	w2, [x3, x2]
    afec:	7100085f 	cmp	w2, #0x2
    aff0:	54008e80 	b.eq	c1c0 <f0+0x2470>  // b.none
    aff4:	7100045f 	cmp	w2, #0x1
    aff8:	540001a1 	b.ne	b02c <f0+0x12dc>  // b.any
    affc:	29430002 	ldp	w2, w0, [x0, #24]
    b000:	92403c21 	and	x1, x1, #0xffff
    b004:	9b027c21 	mul	x1, x1, x2
    b008:	d360fc21 	lsr	x1, x1, #32
    b00c:	eb00003f 	cmp	x1, x0
    b010:	540000e2 	b.cs	b02c <f0+0x12dc>  // b.hs, b.nlast
    b014:	8b0102f7 	add	x23, x23, x1
    b018:	394002e0 	ldrb	w0, [x23]
    b01c:	7103fc1f 	cmp	w0, #0xff
    b020:	54009660 	b.eq	c2ec <f0+0x259c>  // b.none
    b024:	52800020 	mov	w0, #0x1                   	// #1
    b028:	390002e0 	strb	w0, [x23]
    b02c:	9114a3e1 	add	x1, sp, #0x528
    b030:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b034:	52800020 	mov	w0, #0x1                   	// #1
    b038:	f90297f7 	str	x23, [sp, #1320]
    b03c:	f9029bf5 	str	x21, [sp, #1328]
    b040:	97ffe751 	bl	4d84 <fwp_data.part.0.constprop.0>
    b044:	97ffe9af 	bl	5700 <fwp_rc_fresh>
    b048:	aa0003e2 	mov	x2, x0
    b04c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b050:	9114e3e1 	add	x1, sp, #0x538
    b054:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b058:	52800020 	mov	w0, #0x1                   	// #1
    b05c:	f9029fe3 	str	x3, [sp, #1336]
    b060:	f902a3e2 	str	x2, [sp, #1344]
    b064:	97ffe748 	bl	4d84 <fwp_data.part.0.constprop.0>
    b068:	97ffe9a6 	bl	5700 <fwp_rc_fresh>
    b06c:	aa0003e2 	mov	x2, x0
    b070:	911523e1 	add	x1, sp, #0x548
    b074:	52800020 	mov	w0, #0x1                   	// #1
    b078:	f902a7f7 	str	x23, [sp, #1352]
    b07c:	f902abe2 	str	x2, [sp, #1360]
    b080:	97ffe741 	bl	4d84 <fwp_data.part.0.constprop.0>
    b084:	91150283 	add	x3, x20, #0x540
    b088:	aa0003f5 	mov	x21, x0
    b08c:	f949d861 	ldr	x1, [x3, #5040]
    b090:	f949ec60 	ldr	x0, [x3, #5080]
    b094:	cb0102a1 	sub	x1, x21, x1
    b098:	eb00403f 	cmp	x1, x0, lsl #16
    b09c:	54000322 	b.cs	b100 <f0+0x13b0>  // b.hs, b.nlast
    b0a0:	d350fc22 	lsr	x2, x1, #16
    b0a4:	f949fc63 	ldr	x3, [x3, #5112]
    b0a8:	8b020842 	add	x2, x2, x2, lsl #2
    b0ac:	d37df042 	lsl	x2, x2, #3
    b0b0:	8b020060 	add	x0, x3, x2
    b0b4:	f9401017 	ldr	x23, [x0, #32]
    b0b8:	b4000257 	cbz	x23, b100 <f0+0x13b0>
    b0bc:	38626862 	ldrb	w2, [x3, x2]
    b0c0:	7100085f 	cmp	w2, #0x2
    b0c4:	54008900 	b.eq	c1e4 <f0+0x2494>  // b.none
    b0c8:	7100045f 	cmp	w2, #0x1
    b0cc:	540001a1 	b.ne	b100 <f0+0x13b0>  // b.any
    b0d0:	29430002 	ldp	w2, w0, [x0, #24]
    b0d4:	92403c21 	and	x1, x1, #0xffff
    b0d8:	9b027c21 	mul	x1, x1, x2
    b0dc:	d360fc21 	lsr	x1, x1, #32
    b0e0:	eb00003f 	cmp	x1, x0
    b0e4:	540000e2 	b.cs	b100 <f0+0x13b0>  // b.hs, b.nlast
    b0e8:	8b0102f7 	add	x23, x23, x1
    b0ec:	394002e0 	ldrb	w0, [x23]
    b0f0:	7103fc1f 	cmp	w0, #0xff
    b0f4:	54009020 	b.eq	c2f8 <f0+0x25a8>  // b.none
    b0f8:	52800020 	mov	w0, #0x1                   	// #1
    b0fc:	390002e0 	strb	w0, [x23]
    b100:	911563e1 	add	x1, sp, #0x558
    b104:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b108:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b10c:	52800020 	mov	w0, #0x1                   	// #1
    b110:	f902aff7 	str	x23, [sp, #1368]
    b114:	f902b3f5 	str	x21, [sp, #1376]
    b118:	97ffe71b 	bl	4d84 <fwp_data.part.0.constprop.0>
    b11c:	97ffe979 	bl	5700 <fwp_rc_fresh>
    b120:	aa0003e2 	mov	x2, x0
    b124:	9115a3e1 	add	x1, sp, #0x568
    b128:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b12c:	52800020 	mov	w0, #0x1                   	// #1
    b130:	f902b7f5 	str	x21, [sp, #1384]
    b134:	f902bbe2 	str	x2, [sp, #1392]
    b138:	97ffe713 	bl	4d84 <fwp_data.part.0.constprop.0>
    b13c:	97ffe971 	bl	5700 <fwp_rc_fresh>
    b140:	aa0003e2 	mov	x2, x0
    b144:	9115e3e1 	add	x1, sp, #0x578
    b148:	52800020 	mov	w0, #0x1                   	// #1
    b14c:	f902bff7 	str	x23, [sp, #1400]
    b150:	f902c3e2 	str	x2, [sp, #1408]
    b154:	97ffe70c 	bl	4d84 <fwp_data.part.0.constprop.0>
    b158:	97ffe96a 	bl	5700 <fwp_rc_fresh>
    b15c:	aa0003e2 	mov	x2, x0
    b160:	911623e1 	add	x1, sp, #0x588
    b164:	52800020 	mov	w0, #0x1                   	// #1
    b168:	f902c7f5 	str	x21, [sp, #1416]
    b16c:	f902cbe2 	str	x2, [sp, #1424]
    b170:	97ffe705 	bl	4d84 <fwp_data.part.0.constprop.0>
    b174:	97ffe963 	bl	5700 <fwp_rc_fresh>
    b178:	aa0003e2 	mov	x2, x0
    b17c:	911663e1 	add	x1, sp, #0x598
    b180:	52800020 	mov	w0, #0x1                   	// #1
    b184:	f902cff7 	str	x23, [sp, #1432]
    b188:	f902d3e2 	str	x2, [sp, #1440]
    b18c:	97ffe6fe 	bl	4d84 <fwp_data.part.0.constprop.0>
    b190:	91150283 	add	x3, x20, #0x540
    b194:	aa0003f5 	mov	x21, x0
    b198:	f949d861 	ldr	x1, [x3, #5040]
    b19c:	f949ec60 	ldr	x0, [x3, #5080]
    b1a0:	cb0102a1 	sub	x1, x21, x1
    b1a4:	eb00403f 	cmp	x1, x0, lsl #16
    b1a8:	54000322 	b.cs	b20c <f0+0x14bc>  // b.hs, b.nlast
    b1ac:	d350fc22 	lsr	x2, x1, #16
    b1b0:	f949fc63 	ldr	x3, [x3, #5112]
    b1b4:	8b020842 	add	x2, x2, x2, lsl #2
    b1b8:	d37df042 	lsl	x2, x2, #3
    b1bc:	8b020060 	add	x0, x3, x2
    b1c0:	f9401017 	ldr	x23, [x0, #32]
    b1c4:	b4000257 	cbz	x23, b20c <f0+0x14bc>
    b1c8:	38626862 	ldrb	w2, [x3, x2]
    b1cc:	7100085f 	cmp	w2, #0x2
    b1d0:	54008040 	b.eq	c1d8 <f0+0x2488>  // b.none
    b1d4:	7100045f 	cmp	w2, #0x1
    b1d8:	540001a1 	b.ne	b20c <f0+0x14bc>  // b.any
    b1dc:	29430002 	ldp	w2, w0, [x0, #24]
    b1e0:	92403c21 	and	x1, x1, #0xffff
    b1e4:	9b027c21 	mul	x1, x1, x2
    b1e8:	d360fc21 	lsr	x1, x1, #32
    b1ec:	eb00003f 	cmp	x1, x0
    b1f0:	540000e2 	b.cs	b20c <f0+0x14bc>  // b.hs, b.nlast
    b1f4:	8b0102f7 	add	x23, x23, x1
    b1f8:	394002e0 	ldrb	w0, [x23]
    b1fc:	7103fc1f 	cmp	w0, #0xff
    b200:	54008820 	b.eq	c304 <f0+0x25b4>  // b.none
    b204:	52800020 	mov	w0, #0x1                   	// #1
    b208:	390002e0 	strb	w0, [x23]
    b20c:	9116a3e1 	add	x1, sp, #0x5a8
    b210:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b214:	52800020 	mov	w0, #0x1                   	// #1
    b218:	f902d7f7 	str	x23, [sp, #1448]
    b21c:	f902dbf5 	str	x21, [sp, #1456]
    b220:	97ffe6d9 	bl	4d84 <fwp_data.part.0.constprop.0>
    b224:	97ffe937 	bl	5700 <fwp_rc_fresh>
    b228:	aa0003e2 	mov	x2, x0
    b22c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b230:	9116e3e1 	add	x1, sp, #0x5b8
    b234:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b238:	52800020 	mov	w0, #0x1                   	// #1
    b23c:	f902dfe3 	str	x3, [sp, #1464]
    b240:	f902e3e2 	str	x2, [sp, #1472]
    b244:	97ffe6d0 	bl	4d84 <fwp_data.part.0.constprop.0>
    b248:	97ffe92e 	bl	5700 <fwp_rc_fresh>
    b24c:	aa0003e2 	mov	x2, x0
    b250:	911723e1 	add	x1, sp, #0x5c8
    b254:	52800020 	mov	w0, #0x1                   	// #1
    b258:	f902e7f7 	str	x23, [sp, #1480]
    b25c:	f902ebe2 	str	x2, [sp, #1488]
    b260:	97ffe6c9 	bl	4d84 <fwp_data.part.0.constprop.0>
    b264:	91150283 	add	x3, x20, #0x540
    b268:	aa0003f5 	mov	x21, x0
    b26c:	f949d861 	ldr	x1, [x3, #5040]
    b270:	f949ec60 	ldr	x0, [x3, #5080]
    b274:	cb0102a1 	sub	x1, x21, x1
    b278:	eb00403f 	cmp	x1, x0, lsl #16
    b27c:	54000322 	b.cs	b2e0 <f0+0x1590>  // b.hs, b.nlast
    b280:	d350fc22 	lsr	x2, x1, #16
    b284:	f949fc63 	ldr	x3, [x3, #5112]
    b288:	8b020842 	add	x2, x2, x2, lsl #2
    b28c:	d37df042 	lsl	x2, x2, #3
    b290:	8b020060 	add	x0, x3, x2
    b294:	f9401017 	ldr	x23, [x0, #32]
    b298:	b4000257 	cbz	x23, b2e0 <f0+0x1590>
    b29c:	38626862 	ldrb	w2, [x3, x2]
    b2a0:	7100085f 	cmp	w2, #0x2
    b2a4:	54007ac0 	b.eq	c1fc <f0+0x24ac>  // b.none
    b2a8:	7100045f 	cmp	w2, #0x1
    b2ac:	540001a1 	b.ne	b2e0 <f0+0x1590>  // b.any
    b2b0:	29430002 	ldp	w2, w0, [x0, #24]
    b2b4:	92403c21 	and	x1, x1, #0xffff
    b2b8:	9b027c21 	mul	x1, x1, x2
    b2bc:	d360fc21 	lsr	x1, x1, #32
    b2c0:	eb00003f 	cmp	x1, x0
    b2c4:	540000e2 	b.cs	b2e0 <f0+0x1590>  // b.hs, b.nlast
    b2c8:	8b0102f7 	add	x23, x23, x1
    b2cc:	394002e0 	ldrb	w0, [x23]
    b2d0:	7103fc1f 	cmp	w0, #0xff
    b2d4:	540081e0 	b.eq	c310 <f0+0x25c0>  // b.none
    b2d8:	52800020 	mov	w0, #0x1                   	// #1
    b2dc:	390002e0 	strb	w0, [x23]
    b2e0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b2e4:	911763e1 	add	x1, sp, #0x5d8
    b2e8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b2ec:	52800020 	mov	w0, #0x1                   	// #1
    b2f0:	f902efe2 	str	x2, [sp, #1496]
    b2f4:	f902f3f5 	str	x21, [sp, #1504]
    b2f8:	97ffe6a3 	bl	4d84 <fwp_data.part.0.constprop.0>
    b2fc:	91150283 	add	x3, x20, #0x540
    b300:	aa0003f5 	mov	x21, x0
    b304:	f949d861 	ldr	x1, [x3, #5040]
    b308:	f949ec60 	ldr	x0, [x3, #5080]
    b30c:	cb0102a1 	sub	x1, x21, x1
    b310:	eb00403f 	cmp	x1, x0, lsl #16
    b314:	54000322 	b.cs	b378 <f0+0x1628>  // b.hs, b.nlast
    b318:	d350fc22 	lsr	x2, x1, #16
    b31c:	f949fc63 	ldr	x3, [x3, #5112]
    b320:	8b020842 	add	x2, x2, x2, lsl #2
    b324:	d37df042 	lsl	x2, x2, #3
    b328:	8b020060 	add	x0, x3, x2
    b32c:	f9401017 	ldr	x23, [x0, #32]
    b330:	b4000257 	cbz	x23, b378 <f0+0x1628>
    b334:	38626862 	ldrb	w2, [x3, x2]
    b338:	7100085f 	cmp	w2, #0x2
    b33c:	540075a0 	b.eq	c1f0 <f0+0x24a0>  // b.none
    b340:	7100045f 	cmp	w2, #0x1
    b344:	540001a1 	b.ne	b378 <f0+0x1628>  // b.any
    b348:	29430002 	ldp	w2, w0, [x0, #24]
    b34c:	92403c21 	and	x1, x1, #0xffff
    b350:	9b027c21 	mul	x1, x1, x2
    b354:	d360fc21 	lsr	x1, x1, #32
    b358:	eb00003f 	cmp	x1, x0
    b35c:	540000e2 	b.cs	b378 <f0+0x1628>  // b.hs, b.nlast
    b360:	8b0102f7 	add	x23, x23, x1
    b364:	394002e0 	ldrb	w0, [x23]
    b368:	7103fc1f 	cmp	w0, #0xff
    b36c:	54007d80 	b.eq	c31c <f0+0x25cc>  // b.none
    b370:	52800020 	mov	w0, #0x1                   	// #1
    b374:	390002e0 	strb	w0, [x23]
    b378:	9117a3e1 	add	x1, sp, #0x5e8
    b37c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b380:	52800020 	mov	w0, #0x1                   	// #1
    b384:	f902f7e2 	str	x2, [sp, #1512]
    b388:	f902fbf5 	str	x21, [sp, #1520]
    b38c:	97ffe67e 	bl	4d84 <fwp_data.part.0.constprop.0>
    b390:	97ffe8dc 	bl	5700 <fwp_rc_fresh>
    b394:	aa0003e2 	mov	x2, x0
    b398:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b39c:	9117e3e1 	add	x1, sp, #0x5f8
    b3a0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b3a4:	52800020 	mov	w0, #0x1                   	// #1
    b3a8:	f902ffe3 	str	x3, [sp, #1528]
    b3ac:	f90303e2 	str	x2, [sp, #1536]
    b3b0:	97ffe675 	bl	4d84 <fwp_data.part.0.constprop.0>
    b3b4:	91150283 	add	x3, x20, #0x540
    b3b8:	aa0003f5 	mov	x21, x0
    b3bc:	f949d861 	ldr	x1, [x3, #5040]
    b3c0:	f949ec60 	ldr	x0, [x3, #5080]
    b3c4:	cb0102a1 	sub	x1, x21, x1
    b3c8:	eb00403f 	cmp	x1, x0, lsl #16
    b3cc:	54000322 	b.cs	b430 <f0+0x16e0>  // b.hs, b.nlast
    b3d0:	d350fc22 	lsr	x2, x1, #16
    b3d4:	f949fc63 	ldr	x3, [x3, #5112]
    b3d8:	8b020842 	add	x2, x2, x2, lsl #2
    b3dc:	d37df042 	lsl	x2, x2, #3
    b3e0:	8b020060 	add	x0, x3, x2
    b3e4:	f9401017 	ldr	x23, [x0, #32]
    b3e8:	b4000257 	cbz	x23, b430 <f0+0x16e0>
    b3ec:	38626862 	ldrb	w2, [x3, x2]
    b3f0:	7100085f 	cmp	w2, #0x2
    b3f4:	54006500 	b.eq	c094 <f0+0x2344>  // b.none
    b3f8:	7100045f 	cmp	w2, #0x1
    b3fc:	540001a1 	b.ne	b430 <f0+0x16e0>  // b.any
    b400:	29430002 	ldp	w2, w0, [x0, #24]
    b404:	92403c21 	and	x1, x1, #0xffff
    b408:	9b027c21 	mul	x1, x1, x2
    b40c:	d360fc21 	lsr	x1, x1, #32
    b410:	eb00003f 	cmp	x1, x0
    b414:	540000e2 	b.cs	b430 <f0+0x16e0>  // b.hs, b.nlast
    b418:	8b0102f7 	add	x23, x23, x1
    b41c:	394002e0 	ldrb	w0, [x23]
    b420:	7103fc1f 	cmp	w0, #0xff
    b424:	54007820 	b.eq	c328 <f0+0x25d8>  // b.none
    b428:	52800020 	mov	w0, #0x1                   	// #1
    b42c:	390002e0 	strb	w0, [x23]
    b430:	911823e1 	add	x1, sp, #0x608
    b434:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b438:	52800020 	mov	w0, #0x1                   	// #1
    b43c:	f90307e2 	str	x2, [sp, #1544]
    b440:	f9030bf5 	str	x21, [sp, #1552]
    b444:	97ffe650 	bl	4d84 <fwp_data.part.0.constprop.0>
    b448:	97ffe8ae 	bl	5700 <fwp_rc_fresh>
    b44c:	aa0003e2 	mov	x2, x0
    b450:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b454:	911863e1 	add	x1, sp, #0x618
    b458:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b45c:	52800020 	mov	w0, #0x1                   	// #1
    b460:	f9030fe3 	str	x3, [sp, #1560]
    b464:	f90313e2 	str	x2, [sp, #1568]
    b468:	97ffe647 	bl	4d84 <fwp_data.part.0.constprop.0>
    b46c:	91150283 	add	x3, x20, #0x540
    b470:	aa0003f5 	mov	x21, x0
    b474:	f949d861 	ldr	x1, [x3, #5040]
    b478:	f949ec60 	ldr	x0, [x3, #5080]
    b47c:	cb0102a1 	sub	x1, x21, x1
    b480:	eb00403f 	cmp	x1, x0, lsl #16
    b484:	54000322 	b.cs	b4e8 <f0+0x1798>  // b.hs, b.nlast
    b488:	d350fc22 	lsr	x2, x1, #16
    b48c:	f949fc63 	ldr	x3, [x3, #5112]
    b490:	8b020842 	add	x2, x2, x2, lsl #2
    b494:	d37df042 	lsl	x2, x2, #3
    b498:	8b020060 	add	x0, x3, x2
    b49c:	f9401017 	ldr	x23, [x0, #32]
    b4a0:	b4000257 	cbz	x23, b4e8 <f0+0x1798>
    b4a4:	38626862 	ldrb	w2, [x3, x2]
    b4a8:	7100085f 	cmp	w2, #0x2
    b4ac:	54005ee0 	b.eq	c088 <f0+0x2338>  // b.none
    b4b0:	7100045f 	cmp	w2, #0x1
    b4b4:	540001a1 	b.ne	b4e8 <f0+0x1798>  // b.any
    b4b8:	29430002 	ldp	w2, w0, [x0, #24]
    b4bc:	92403c21 	and	x1, x1, #0xffff
    b4c0:	9b027c21 	mul	x1, x1, x2
    b4c4:	d360fc21 	lsr	x1, x1, #32
    b4c8:	eb00003f 	cmp	x1, x0
    b4cc:	540000e2 	b.cs	b4e8 <f0+0x1798>  // b.hs, b.nlast
    b4d0:	8b0102f7 	add	x23, x23, x1
    b4d4:	394002e0 	ldrb	w0, [x23]
    b4d8:	7103fc1f 	cmp	w0, #0xff
    b4dc:	540072c0 	b.eq	c334 <f0+0x25e4>  // b.none
    b4e0:	52800020 	mov	w0, #0x1                   	// #1
    b4e4:	390002e0 	strb	w0, [x23]
    b4e8:	9118a3e1 	add	x1, sp, #0x628
    b4ec:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b4f0:	52800020 	mov	w0, #0x1                   	// #1
    b4f4:	f90317f7 	str	x23, [sp, #1576]
    b4f8:	f9031bf5 	str	x21, [sp, #1584]
    b4fc:	97ffe622 	bl	4d84 <fwp_data.part.0.constprop.0>
    b500:	97ffe880 	bl	5700 <fwp_rc_fresh>
    b504:	aa0003e2 	mov	x2, x0
    b508:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b50c:	9118e3e1 	add	x1, sp, #0x638
    b510:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b514:	52800020 	mov	w0, #0x1                   	// #1
    b518:	f9031fe3 	str	x3, [sp, #1592]
    b51c:	f90323e2 	str	x2, [sp, #1600]
    b520:	97ffe619 	bl	4d84 <fwp_data.part.0.constprop.0>
    b524:	97ffe877 	bl	5700 <fwp_rc_fresh>
    b528:	aa0003e2 	mov	x2, x0
    b52c:	911923e1 	add	x1, sp, #0x648
    b530:	52800020 	mov	w0, #0x1                   	// #1
    b534:	f90327f7 	str	x23, [sp, #1608]
    b538:	f9032be2 	str	x2, [sp, #1616]
    b53c:	97ffe612 	bl	4d84 <fwp_data.part.0.constprop.0>
    b540:	91150283 	add	x3, x20, #0x540
    b544:	aa0003f5 	mov	x21, x0
    b548:	f949d861 	ldr	x1, [x3, #5040]
    b54c:	f949ec60 	ldr	x0, [x3, #5080]
    b550:	cb0102a1 	sub	x1, x21, x1
    b554:	eb00403f 	cmp	x1, x0, lsl #16
    b558:	54000322 	b.cs	b5bc <f0+0x186c>  // b.hs, b.nlast
    b55c:	d350fc22 	lsr	x2, x1, #16
    b560:	f949fc63 	ldr	x3, [x3, #5112]
    b564:	8b020842 	add	x2, x2, x2, lsl #2
    b568:	d37df042 	lsl	x2, x2, #3
    b56c:	8b020060 	add	x0, x3, x2
    b570:	f9401017 	ldr	x23, [x0, #32]
    b574:	b4000257 	cbz	x23, b5bc <f0+0x186c>
    b578:	38626862 	ldrb	w2, [x3, x2]
    b57c:	7100085f 	cmp	w2, #0x2
    b580:	54005960 	b.eq	c0ac <f0+0x235c>  // b.none
    b584:	7100045f 	cmp	w2, #0x1
    b588:	540001a1 	b.ne	b5bc <f0+0x186c>  // b.any
    b58c:	29430002 	ldp	w2, w0, [x0, #24]
    b590:	92403c21 	and	x1, x1, #0xffff
    b594:	9b027c21 	mul	x1, x1, x2
    b598:	d360fc21 	lsr	x1, x1, #32
    b59c:	eb00003f 	cmp	x1, x0
    b5a0:	540000e2 	b.cs	b5bc <f0+0x186c>  // b.hs, b.nlast
    b5a4:	8b0102f7 	add	x23, x23, x1
    b5a8:	394002e0 	ldrb	w0, [x23]
    b5ac:	7103fc1f 	cmp	w0, #0xff
    b5b0:	54006c80 	b.eq	c340 <f0+0x25f0>  // b.none
    b5b4:	52800020 	mov	w0, #0x1                   	// #1
    b5b8:	390002e0 	strb	w0, [x23]
    b5bc:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b5c0:	911963e1 	add	x1, sp, #0x658
    b5c4:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b5c8:	52800020 	mov	w0, #0x1                   	// #1
    b5cc:	f9032fe2 	str	x2, [sp, #1624]
    b5d0:	f90333f5 	str	x21, [sp, #1632]
    b5d4:	97ffe5ec 	bl	4d84 <fwp_data.part.0.constprop.0>
    b5d8:	91150283 	add	x3, x20, #0x540
    b5dc:	aa0003f5 	mov	x21, x0
    b5e0:	f949d861 	ldr	x1, [x3, #5040]
    b5e4:	f949ec60 	ldr	x0, [x3, #5080]
    b5e8:	cb0102a1 	sub	x1, x21, x1
    b5ec:	eb00403f 	cmp	x1, x0, lsl #16
    b5f0:	54000322 	b.cs	b654 <f0+0x1904>  // b.hs, b.nlast
    b5f4:	d350fc22 	lsr	x2, x1, #16
    b5f8:	f949fc63 	ldr	x3, [x3, #5112]
    b5fc:	8b020842 	add	x2, x2, x2, lsl #2
    b600:	d37df042 	lsl	x2, x2, #3
    b604:	8b020060 	add	x0, x3, x2
    b608:	f9401017 	ldr	x23, [x0, #32]
    b60c:	b4000257 	cbz	x23, b654 <f0+0x1904>
    b610:	38626862 	ldrb	w2, [x3, x2]
    b614:	7100085f 	cmp	w2, #0x2
    b618:	54005440 	b.eq	c0a0 <f0+0x2350>  // b.none
    b61c:	7100045f 	cmp	w2, #0x1
    b620:	540001a1 	b.ne	b654 <f0+0x1904>  // b.any
    b624:	29430002 	ldp	w2, w0, [x0, #24]
    b628:	92403c21 	and	x1, x1, #0xffff
    b62c:	9b027c21 	mul	x1, x1, x2
    b630:	d360fc21 	lsr	x1, x1, #32
    b634:	eb00003f 	cmp	x1, x0
    b638:	540000e2 	b.cs	b654 <f0+0x1904>  // b.hs, b.nlast
    b63c:	8b0102f7 	add	x23, x23, x1
    b640:	394002e0 	ldrb	w0, [x23]
    b644:	7103fc1f 	cmp	w0, #0xff
    b648:	54006820 	b.eq	c34c <f0+0x25fc>  // b.none
    b64c:	52800020 	mov	w0, #0x1                   	// #1
    b650:	390002e0 	strb	w0, [x23]
    b654:	9119a3e1 	add	x1, sp, #0x668
    b658:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    b65c:	52800020 	mov	w0, #0x1                   	// #1
    b660:	f90337f7 	str	x23, [sp, #1640]
    b664:	f9033bf5 	str	x21, [sp, #1648]
    b668:	97ffe5c7 	bl	4d84 <fwp_data.part.0.constprop.0>
    b66c:	97ffe825 	bl	5700 <fwp_rc_fresh>
    b670:	aa0003e2 	mov	x2, x0
    b674:	9119e3e1 	add	x1, sp, #0x678
    b678:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    b67c:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    b680:	52800020 	mov	w0, #0x1                   	// #1
    b684:	f9033ff5 	str	x21, [sp, #1656]
    b688:	f90343e2 	str	x2, [sp, #1664]
    b68c:	97ffe5be 	bl	4d84 <fwp_data.part.0.constprop.0>
    b690:	97ffe81c 	bl	5700 <fwp_rc_fresh>
    b694:	aa0003e2 	mov	x2, x0
    b698:	911a23e1 	add	x1, sp, #0x688
    b69c:	52800020 	mov	w0, #0x1                   	// #1
    b6a0:	f90347f7 	str	x23, [sp, #1672]
    b6a4:	f9034be2 	str	x2, [sp, #1680]
    b6a8:	97ffe5b7 	bl	4d84 <fwp_data.part.0.constprop.0>
    b6ac:	97ffe815 	bl	5700 <fwp_rc_fresh>
    b6b0:	aa0003e2 	mov	x2, x0
    b6b4:	911a63e1 	add	x1, sp, #0x698
    b6b8:	52800020 	mov	w0, #0x1                   	// #1
    b6bc:	f9034ff5 	str	x21, [sp, #1688]
    b6c0:	f90353e2 	str	x2, [sp, #1696]
    b6c4:	97ffe5b0 	bl	4d84 <fwp_data.part.0.constprop.0>
    b6c8:	91150283 	add	x3, x20, #0x540
    b6cc:	aa0003f5 	mov	x21, x0
    b6d0:	f949d861 	ldr	x1, [x3, #5040]
    b6d4:	f949ec60 	ldr	x0, [x3, #5080]
    b6d8:	cb0102a1 	sub	x1, x21, x1
    b6dc:	eb00403f 	cmp	x1, x0, lsl #16
    b6e0:	54000322 	b.cs	b744 <f0+0x19f4>  // b.hs, b.nlast
    b6e4:	d350fc22 	lsr	x2, x1, #16
    b6e8:	f949fc63 	ldr	x3, [x3, #5112]
    b6ec:	8b020842 	add	x2, x2, x2, lsl #2
    b6f0:	d37df042 	lsl	x2, x2, #3
    b6f4:	8b020060 	add	x0, x3, x2
    b6f8:	f9401017 	ldr	x23, [x0, #32]
    b6fc:	b4000257 	cbz	x23, b744 <f0+0x19f4>
    b700:	38626862 	ldrb	w2, [x3, x2]
    b704:	7100085f 	cmp	w2, #0x2
    b708:	54004de0 	b.eq	c0c4 <f0+0x2374>  // b.none
    b70c:	7100045f 	cmp	w2, #0x1
    b710:	540001a1 	b.ne	b744 <f0+0x19f4>  // b.any
    b714:	29430002 	ldp	w2, w0, [x0, #24]
    b718:	92403c21 	and	x1, x1, #0xffff
    b71c:	9b027c21 	mul	x1, x1, x2
    b720:	d360fc21 	lsr	x1, x1, #32
    b724:	eb00003f 	cmp	x1, x0
    b728:	540000e2 	b.cs	b744 <f0+0x19f4>  // b.hs, b.nlast
    b72c:	8b0102f7 	add	x23, x23, x1
    b730:	394002e0 	ldrb	w0, [x23]
    b734:	7103fc1f 	cmp	w0, #0xff
    b738:	54006100 	b.eq	c358 <f0+0x2608>  // b.none
    b73c:	52800020 	mov	w0, #0x1                   	// #1
    b740:	390002e0 	strb	w0, [x23]
    b744:	911aa3e1 	add	x1, sp, #0x6a8
    b748:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b74c:	52800020 	mov	w0, #0x1                   	// #1
    b750:	f90357e2 	str	x2, [sp, #1704]
    b754:	f9035bf5 	str	x21, [sp, #1712]
    b758:	97ffe58b 	bl	4d84 <fwp_data.part.0.constprop.0>
    b75c:	97ffe7e9 	bl	5700 <fwp_rc_fresh>
    b760:	aa0003e2 	mov	x2, x0
    b764:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    b768:	911ae3e1 	add	x1, sp, #0x6b8
    b76c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    b770:	52800020 	mov	w0, #0x1                   	// #1
    b774:	f9035fe3 	str	x3, [sp, #1720]
    b778:	f90363e2 	str	x2, [sp, #1728]
    b77c:	97ffe582 	bl	4d84 <fwp_data.part.0.constprop.0>
    b780:	91150283 	add	x3, x20, #0x540
    b784:	aa0003f5 	mov	x21, x0
    b788:	f949d861 	ldr	x1, [x3, #5040]
    b78c:	f949ec60 	ldr	x0, [x3, #5080]
    b790:	cb0102a1 	sub	x1, x21, x1
    b794:	eb00403f 	cmp	x1, x0, lsl #16
    b798:	54000322 	b.cs	b7fc <f0+0x1aac>  // b.hs, b.nlast
    b79c:	d350fc22 	lsr	x2, x1, #16
    b7a0:	f949fc63 	ldr	x3, [x3, #5112]
    b7a4:	8b020842 	add	x2, x2, x2, lsl #2
    b7a8:	d37df042 	lsl	x2, x2, #3
    b7ac:	8b020060 	add	x0, x3, x2
    b7b0:	f9401017 	ldr	x23, [x0, #32]
    b7b4:	b4000257 	cbz	x23, b7fc <f0+0x1aac>
    b7b8:	38626862 	ldrb	w2, [x3, x2]
    b7bc:	7100085f 	cmp	w2, #0x2
    b7c0:	540047c0 	b.eq	c0b8 <f0+0x2368>  // b.none
    b7c4:	7100045f 	cmp	w2, #0x1
    b7c8:	540001a1 	b.ne	b7fc <f0+0x1aac>  // b.any
    b7cc:	29430002 	ldp	w2, w0, [x0, #24]
    b7d0:	92403c21 	and	x1, x1, #0xffff
    b7d4:	9b027c21 	mul	x1, x1, x2
    b7d8:	d360fc21 	lsr	x1, x1, #32
    b7dc:	eb00003f 	cmp	x1, x0
    b7e0:	540000e2 	b.cs	b7fc <f0+0x1aac>  // b.hs, b.nlast
    b7e4:	8b0102f7 	add	x23, x23, x1
    b7e8:	394002e0 	ldrb	w0, [x23]
    b7ec:	7103fc1f 	cmp	w0, #0xff
    b7f0:	54005ba0 	b.eq	c364 <f0+0x2614>  // b.none
    b7f4:	52800020 	mov	w0, #0x1                   	// #1
    b7f8:	390002e0 	strb	w0, [x23]
    b7fc:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    b800:	911b23e1 	add	x1, sp, #0x6c8
    b804:	52800020 	mov	w0, #0x1                   	// #1
    b808:	f90367e2 	str	x2, [sp, #1736]
    b80c:	f9036bf5 	str	x21, [sp, #1744]
    b810:	97ffe55d 	bl	4d84 <fwp_data.part.0.constprop.0>
    b814:	91150283 	add	x3, x20, #0x540
    b818:	aa0003f5 	mov	x21, x0
    b81c:	f949d861 	ldr	x1, [x3, #5040]
    b820:	f949ec60 	ldr	x0, [x3, #5080]
    b824:	cb0102a1 	sub	x1, x21, x1
    b828:	eb00403f 	cmp	x1, x0, lsl #16
    b82c:	54000322 	b.cs	b890 <f0+0x1b40>  // b.hs, b.nlast
    b830:	d350fc22 	lsr	x2, x1, #16
    b834:	f949fc63 	ldr	x3, [x3, #5112]
    b838:	8b020842 	add	x2, x2, x2, lsl #2
    b83c:	d37df042 	lsl	x2, x2, #3
    b840:	8b020060 	add	x0, x3, x2
    b844:	f9401017 	ldr	x23, [x0, #32]
    b848:	b4000257 	cbz	x23, b890 <f0+0x1b40>
    b84c:	38626862 	ldrb	w2, [x3, x2]
    b850:	7100085f 	cmp	w2, #0x2
    b854:	54004440 	b.eq	c0dc <f0+0x238c>  // b.none
    b858:	7100045f 	cmp	w2, #0x1
    b85c:	540001a1 	b.ne	b890 <f0+0x1b40>  // b.any
    b860:	29430002 	ldp	w2, w0, [x0, #24]
    b864:	92403c21 	and	x1, x1, #0xffff
    b868:	9b027c21 	mul	x1, x1, x2
    b86c:	d360fc21 	lsr	x1, x1, #32
    b870:	eb00003f 	cmp	x1, x0
    b874:	540000e2 	b.cs	b890 <f0+0x1b40>  // b.hs, b.nlast
    b878:	8b0102f7 	add	x23, x23, x1
    b87c:	394002e0 	ldrb	w0, [x23]
    b880:	7103fc1f 	cmp	w0, #0xff
    b884:	54005760 	b.eq	c370 <f0+0x2620>  // b.none
    b888:	52800020 	mov	w0, #0x1                   	// #1
    b88c:	390002e0 	strb	w0, [x23]
    b890:	911b63e1 	add	x1, sp, #0x6d8
    b894:	b200e7f7 	mov	x23, #0x3333333333333333    	// #3689348814741910323
    b898:	f2f7fe77 	movk	x23, #0xbff3, lsl #48
    b89c:	52800020 	mov	w0, #0x1                   	// #1
    b8a0:	f9036ff7 	str	x23, [sp, #1752]
    b8a4:	f90373f5 	str	x21, [sp, #1760]
    b8a8:	97ffe537 	bl	4d84 <fwp_data.part.0.constprop.0>
    b8ac:	97ffe795 	bl	5700 <fwp_rc_fresh>
    b8b0:	aa0003e2 	mov	x2, x0
    b8b4:	911ba3e1 	add	x1, sp, #0x6e8
    b8b8:	d2e7fe15 	mov	x21, #0x3ff0000000000000    	// #4607182418800017408
    b8bc:	52800020 	mov	w0, #0x1                   	// #1
    b8c0:	f90377f5 	str	x21, [sp, #1768]
    b8c4:	f9037be2 	str	x2, [sp, #1776]
    b8c8:	97ffe52f 	bl	4d84 <fwp_data.part.0.constprop.0>
    b8cc:	97ffe78d 	bl	5700 <fwp_rc_fresh>
    b8d0:	aa0003e2 	mov	x2, x0
    b8d4:	911be3e1 	add	x1, sp, #0x6f8
    b8d8:	52800020 	mov	w0, #0x1                   	// #1
    b8dc:	f9037ff7 	str	x23, [sp, #1784]
    b8e0:	f90383e2 	str	x2, [sp, #1792]
    b8e4:	97ffe528 	bl	4d84 <fwp_data.part.0.constprop.0>
    b8e8:	97ffe786 	bl	5700 <fwp_rc_fresh>
    b8ec:	aa0003e2 	mov	x2, x0
    b8f0:	911c23e1 	add	x1, sp, #0x708
    b8f4:	52800020 	mov	w0, #0x1                   	// #1
    b8f8:	f90387f5 	str	x21, [sp, #1800]
    b8fc:	f9038be2 	str	x2, [sp, #1808]
    b900:	97ffe521 	bl	4d84 <fwp_data.part.0.constprop.0>
    b904:	97ffe77f 	bl	5700 <fwp_rc_fresh>
    b908:	aa0003e2 	mov	x2, x0
    b90c:	911c63e1 	add	x1, sp, #0x718
    b910:	52800020 	mov	w0, #0x1                   	// #1
    b914:	f9038ff7 	str	x23, [sp, #1816]
    b918:	f90393e2 	str	x2, [sp, #1824]
    b91c:	97ffe51a 	bl	4d84 <fwp_data.part.0.constprop.0>
    b920:	97ffe778 	bl	5700 <fwp_rc_fresh>
    b924:	aa0003e2 	mov	x2, x0
    b928:	911ca3e1 	add	x1, sp, #0x728
    b92c:	52800020 	mov	w0, #0x1                   	// #1
    b930:	f90397f5 	str	x21, [sp, #1832]
    b934:	f9039be2 	str	x2, [sp, #1840]
    b938:	97ffe513 	bl	4d84 <fwp_data.part.0.constprop.0>
    b93c:	97ffe771 	bl	5700 <fwp_rc_fresh>
    b940:	aa0003e2 	mov	x2, x0
    b944:	911ce3e1 	add	x1, sp, #0x738
    b948:	52800020 	mov	w0, #0x1                   	// #1
    b94c:	f9039ff7 	str	x23, [sp, #1848]
    b950:	f903a3e2 	str	x2, [sp, #1856]
    b954:	97ffe50c 	bl	4d84 <fwp_data.part.0.constprop.0>
    b958:	97ffe76a 	bl	5700 <fwp_rc_fresh>
    b95c:	aa0003e2 	mov	x2, x0
    b960:	911d23e1 	add	x1, sp, #0x748
    b964:	52800020 	mov	w0, #0x1                   	// #1
    b968:	f903a7f5 	str	x21, [sp, #1864]
    b96c:	f903abe2 	str	x2, [sp, #1872]
    b970:	97ffe505 	bl	4d84 <fwp_data.part.0.constprop.0>
    b974:	91150283 	add	x3, x20, #0x540
    b978:	aa0003f5 	mov	x21, x0
    b97c:	f949d861 	ldr	x1, [x3, #5040]
    b980:	f949ec60 	ldr	x0, [x3, #5080]
    b984:	cb0102a1 	sub	x1, x21, x1
    b988:	eb00403f 	cmp	x1, x0, lsl #16
    b98c:	54000322 	b.cs	b9f0 <f0+0x1ca0>  // b.hs, b.nlast
    b990:	d350fc22 	lsr	x2, x1, #16
    b994:	f949fc63 	ldr	x3, [x3, #5112]
    b998:	8b020842 	add	x2, x2, x2, lsl #2
    b99c:	d37df042 	lsl	x2, x2, #3
    b9a0:	8b020060 	add	x0, x3, x2
    b9a4:	f9401017 	ldr	x23, [x0, #32]
    b9a8:	b4000257 	cbz	x23, b9f0 <f0+0x1ca0>
    b9ac:	38626862 	ldrb	w2, [x3, x2]
    b9b0:	7100085f 	cmp	w2, #0x2
    b9b4:	540038e0 	b.eq	c0d0 <f0+0x2380>  // b.none
    b9b8:	7100045f 	cmp	w2, #0x1
    b9bc:	540001a1 	b.ne	b9f0 <f0+0x1ca0>  // b.any
    b9c0:	29430002 	ldp	w2, w0, [x0, #24]
    b9c4:	92403c21 	and	x1, x1, #0xffff
    b9c8:	9b027c21 	mul	x1, x1, x2
    b9cc:	d360fc21 	lsr	x1, x1, #32
    b9d0:	eb00003f 	cmp	x1, x0
    b9d4:	540000e2 	b.cs	b9f0 <f0+0x1ca0>  // b.hs, b.nlast
    b9d8:	8b0102f7 	add	x23, x23, x1
    b9dc:	394002e0 	ldrb	w0, [x23]
    b9e0:	7103fc1f 	cmp	w0, #0xff
    b9e4:	54004cc0 	b.eq	c37c <f0+0x262c>  // b.none
    b9e8:	52800020 	mov	w0, #0x1                   	// #1
    b9ec:	390002e0 	strb	w0, [x23]
    b9f0:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    b9f4:	911d63e1 	add	x1, sp, #0x758
    b9f8:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    b9fc:	52800020 	mov	w0, #0x1                   	// #1
    ba00:	f903afe2 	str	x2, [sp, #1880]
    ba04:	f903b3f5 	str	x21, [sp, #1888]
    ba08:	97ffe4df 	bl	4d84 <fwp_data.part.0.constprop.0>
    ba0c:	91150283 	add	x3, x20, #0x540
    ba10:	aa0003f5 	mov	x21, x0
    ba14:	f949d861 	ldr	x1, [x3, #5040]
    ba18:	f949ec60 	ldr	x0, [x3, #5080]
    ba1c:	cb0102a1 	sub	x1, x21, x1
    ba20:	eb00403f 	cmp	x1, x0, lsl #16
    ba24:	54000322 	b.cs	ba88 <f0+0x1d38>  // b.hs, b.nlast
    ba28:	d350fc22 	lsr	x2, x1, #16
    ba2c:	f949fc63 	ldr	x3, [x3, #5112]
    ba30:	8b020842 	add	x2, x2, x2, lsl #2
    ba34:	d37df042 	lsl	x2, x2, #3
    ba38:	8b020060 	add	x0, x3, x2
    ba3c:	f9401017 	ldr	x23, [x0, #32]
    ba40:	b4000257 	cbz	x23, ba88 <f0+0x1d38>
    ba44:	38626862 	ldrb	w2, [x3, x2]
    ba48:	7100085f 	cmp	w2, #0x2
    ba4c:	54003540 	b.eq	c0f4 <f0+0x23a4>  // b.none
    ba50:	7100045f 	cmp	w2, #0x1
    ba54:	540001a1 	b.ne	ba88 <f0+0x1d38>  // b.any
    ba58:	29430002 	ldp	w2, w0, [x0, #24]
    ba5c:	92403c21 	and	x1, x1, #0xffff
    ba60:	9b027c21 	mul	x1, x1, x2
    ba64:	d360fc21 	lsr	x1, x1, #32
    ba68:	eb00003f 	cmp	x1, x0
    ba6c:	540000e2 	b.cs	ba88 <f0+0x1d38>  // b.hs, b.nlast
    ba70:	8b0102f7 	add	x23, x23, x1
    ba74:	394002e0 	ldrb	w0, [x23]
    ba78:	7103fc1f 	cmp	w0, #0xff
    ba7c:	54004860 	b.eq	c388 <f0+0x2638>  // b.none
    ba80:	52800020 	mov	w0, #0x1                   	// #1
    ba84:	390002e0 	strb	w0, [x23]
    ba88:	911da3e1 	add	x1, sp, #0x768
    ba8c:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    ba90:	52800020 	mov	w0, #0x1                   	// #1
    ba94:	f903b7f7 	str	x23, [sp, #1896]
    ba98:	f903bbf5 	str	x21, [sp, #1904]
    ba9c:	97ffe4ba 	bl	4d84 <fwp_data.part.0.constprop.0>
    baa0:	97ffe718 	bl	5700 <fwp_rc_fresh>
    baa4:	aa0003e2 	mov	x2, x0
    baa8:	911de3e1 	add	x1, sp, #0x778
    baac:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bab0:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bab4:	52800020 	mov	w0, #0x1                   	// #1
    bab8:	f903bff5 	str	x21, [sp, #1912]
    babc:	f903c3e2 	str	x2, [sp, #1920]
    bac0:	97ffe4b1 	bl	4d84 <fwp_data.part.0.constprop.0>
    bac4:	97ffe70f 	bl	5700 <fwp_rc_fresh>
    bac8:	aa0003e2 	mov	x2, x0
    bacc:	911e23e1 	add	x1, sp, #0x788
    bad0:	52800020 	mov	w0, #0x1                   	// #1
    bad4:	f903c7f7 	str	x23, [sp, #1928]
    bad8:	f903cbe2 	str	x2, [sp, #1936]
    badc:	97ffe4aa 	bl	4d84 <fwp_data.part.0.constprop.0>
    bae0:	97ffe708 	bl	5700 <fwp_rc_fresh>
    bae4:	aa0003e2 	mov	x2, x0
    bae8:	911e63e1 	add	x1, sp, #0x798
    baec:	52800020 	mov	w0, #0x1                   	// #1
    baf0:	f903cff5 	str	x21, [sp, #1944]
    baf4:	f903d3e2 	str	x2, [sp, #1952]
    baf8:	97ffe4a3 	bl	4d84 <fwp_data.part.0.constprop.0>
    bafc:	91150283 	add	x3, x20, #0x540
    bb00:	aa0003f5 	mov	x21, x0
    bb04:	f949d861 	ldr	x1, [x3, #5040]
    bb08:	f949ec60 	ldr	x0, [x3, #5080]
    bb0c:	cb0102a1 	sub	x1, x21, x1
    bb10:	eb00403f 	cmp	x1, x0, lsl #16
    bb14:	54000322 	b.cs	bb78 <f0+0x1e28>  // b.hs, b.nlast
    bb18:	d350fc22 	lsr	x2, x1, #16
    bb1c:	f949fc63 	ldr	x3, [x3, #5112]
    bb20:	8b020842 	add	x2, x2, x2, lsl #2
    bb24:	d37df042 	lsl	x2, x2, #3
    bb28:	8b020060 	add	x0, x3, x2
    bb2c:	f9401017 	ldr	x23, [x0, #32]
    bb30:	b4000257 	cbz	x23, bb78 <f0+0x1e28>
    bb34:	38626862 	ldrb	w2, [x3, x2]
    bb38:	7100085f 	cmp	w2, #0x2
    bb3c:	54002d60 	b.eq	c0e8 <f0+0x2398>  // b.none
    bb40:	7100045f 	cmp	w2, #0x1
    bb44:	540001a1 	b.ne	bb78 <f0+0x1e28>  // b.any
    bb48:	29430002 	ldp	w2, w0, [x0, #24]
    bb4c:	92403c21 	and	x1, x1, #0xffff
    bb50:	9b027c21 	mul	x1, x1, x2
    bb54:	d360fc21 	lsr	x1, x1, #32
    bb58:	eb00003f 	cmp	x1, x0
    bb5c:	540000e2 	b.cs	bb78 <f0+0x1e28>  // b.hs, b.nlast
    bb60:	8b0102f7 	add	x23, x23, x1
    bb64:	394002e0 	ldrb	w0, [x23]
    bb68:	7103fc1f 	cmp	w0, #0xff
    bb6c:	54004140 	b.eq	c394 <f0+0x2644>  // b.none
    bb70:	52800020 	mov	w0, #0x1                   	// #1
    bb74:	390002e0 	strb	w0, [x23]
    bb78:	911ea3e1 	add	x1, sp, #0x7a8
    bb7c:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bb80:	52800020 	mov	w0, #0x1                   	// #1
    bb84:	f903d7e2 	str	x2, [sp, #1960]
    bb88:	f903dbf5 	str	x21, [sp, #1968]
    bb8c:	97ffe47e 	bl	4d84 <fwp_data.part.0.constprop.0>
    bb90:	97ffe6dc 	bl	5700 <fwp_rc_fresh>
    bb94:	aa0003e2 	mov	x2, x0
    bb98:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bb9c:	911ee3e1 	add	x1, sp, #0x7b8
    bba0:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bba4:	52800020 	mov	w0, #0x1                   	// #1
    bba8:	f903dfe3 	str	x3, [sp, #1976]
    bbac:	f903e3e2 	str	x2, [sp, #1984]
    bbb0:	97ffe475 	bl	4d84 <fwp_data.part.0.constprop.0>
    bbb4:	91150283 	add	x3, x20, #0x540
    bbb8:	aa0003f5 	mov	x21, x0
    bbbc:	f949d861 	ldr	x1, [x3, #5040]
    bbc0:	f949ec60 	ldr	x0, [x3, #5080]
    bbc4:	cb0102a1 	sub	x1, x21, x1
    bbc8:	eb00403f 	cmp	x1, x0, lsl #16
    bbcc:	54000322 	b.cs	bc30 <f0+0x1ee0>  // b.hs, b.nlast
    bbd0:	d350fc22 	lsr	x2, x1, #16
    bbd4:	f949fc63 	ldr	x3, [x3, #5112]
    bbd8:	8b020842 	add	x2, x2, x2, lsl #2
    bbdc:	d37df042 	lsl	x2, x2, #3
    bbe0:	8b020060 	add	x0, x3, x2
    bbe4:	f9401017 	ldr	x23, [x0, #32]
    bbe8:	b4000257 	cbz	x23, bc30 <f0+0x1ee0>
    bbec:	38626862 	ldrb	w2, [x3, x2]
    bbf0:	7100085f 	cmp	w2, #0x2
    bbf4:	540028c0 	b.eq	c10c <f0+0x23bc>  // b.none
    bbf8:	7100045f 	cmp	w2, #0x1
    bbfc:	540001a1 	b.ne	bc30 <f0+0x1ee0>  // b.any
    bc00:	29430002 	ldp	w2, w0, [x0, #24]
    bc04:	92403c21 	and	x1, x1, #0xffff
    bc08:	9b027c21 	mul	x1, x1, x2
    bc0c:	d360fc21 	lsr	x1, x1, #32
    bc10:	eb00003f 	cmp	x1, x0
    bc14:	540000e2 	b.cs	bc30 <f0+0x1ee0>  // b.hs, b.nlast
    bc18:	8b0102f7 	add	x23, x23, x1
    bc1c:	394002e0 	ldrb	w0, [x23]
    bc20:	7103fc1f 	cmp	w0, #0xff
    bc24:	54003be0 	b.eq	c3a0 <f0+0x2650>  // b.none
    bc28:	52800020 	mov	w0, #0x1                   	// #1
    bc2c:	390002e0 	strb	w0, [x23]
    bc30:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bc34:	911f23e1 	add	x1, sp, #0x7c8
    bc38:	52800020 	mov	w0, #0x1                   	// #1
    bc3c:	f903e7e2 	str	x2, [sp, #1992]
    bc40:	f903ebf5 	str	x21, [sp, #2000]
    bc44:	97ffe450 	bl	4d84 <fwp_data.part.0.constprop.0>
    bc48:	91150283 	add	x3, x20, #0x540
    bc4c:	aa0003f5 	mov	x21, x0
    bc50:	f949d861 	ldr	x1, [x3, #5040]
    bc54:	f949ec60 	ldr	x0, [x3, #5080]
    bc58:	cb0102a1 	sub	x1, x21, x1
    bc5c:	eb00403f 	cmp	x1, x0, lsl #16
    bc60:	54000322 	b.cs	bcc4 <f0+0x1f74>  // b.hs, b.nlast
    bc64:	d350fc22 	lsr	x2, x1, #16
    bc68:	f949fc63 	ldr	x3, [x3, #5112]
    bc6c:	8b020842 	add	x2, x2, x2, lsl #2
    bc70:	d37df042 	lsl	x2, x2, #3
    bc74:	8b020060 	add	x0, x3, x2
    bc78:	f9401017 	ldr	x23, [x0, #32]
    bc7c:	b4000257 	cbz	x23, bcc4 <f0+0x1f74>
    bc80:	38626862 	ldrb	w2, [x3, x2]
    bc84:	7100085f 	cmp	w2, #0x2
    bc88:	540023c0 	b.eq	c100 <f0+0x23b0>  // b.none
    bc8c:	7100045f 	cmp	w2, #0x1
    bc90:	540001a1 	b.ne	bcc4 <f0+0x1f74>  // b.any
    bc94:	29430002 	ldp	w2, w0, [x0, #24]
    bc98:	92403c21 	and	x1, x1, #0xffff
    bc9c:	9b027c21 	mul	x1, x1, x2
    bca0:	d360fc21 	lsr	x1, x1, #32
    bca4:	eb00003f 	cmp	x1, x0
    bca8:	540000e2 	b.cs	bcc4 <f0+0x1f74>  // b.hs, b.nlast
    bcac:	8b0102f7 	add	x23, x23, x1
    bcb0:	394002e0 	ldrb	w0, [x23]
    bcb4:	7103fc1f 	cmp	w0, #0xff
    bcb8:	540037a0 	b.eq	c3ac <f0+0x265c>  // b.none
    bcbc:	52800020 	mov	w0, #0x1                   	// #1
    bcc0:	390002e0 	strb	w0, [x23]
    bcc4:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    bcc8:	911f63e1 	add	x1, sp, #0x7d8
    bccc:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    bcd0:	52800020 	mov	w0, #0x1                   	// #1
    bcd4:	f903efe2 	str	x2, [sp, #2008]
    bcd8:	f903f3f5 	str	x21, [sp, #2016]
    bcdc:	97ffe42a 	bl	4d84 <fwp_data.part.0.constprop.0>
    bce0:	91150283 	add	x3, x20, #0x540
    bce4:	aa0003f5 	mov	x21, x0
    bce8:	f949d861 	ldr	x1, [x3, #5040]
    bcec:	f949ec60 	ldr	x0, [x3, #5080]
    bcf0:	cb0102a1 	sub	x1, x21, x1
    bcf4:	eb00403f 	cmp	x1, x0, lsl #16
    bcf8:	54000322 	b.cs	bd5c <f0+0x200c>  // b.hs, b.nlast
    bcfc:	d350fc22 	lsr	x2, x1, #16
    bd00:	f949fc63 	ldr	x3, [x3, #5112]
    bd04:	8b020842 	add	x2, x2, x2, lsl #2
    bd08:	d37df042 	lsl	x2, x2, #3
    bd0c:	8b020060 	add	x0, x3, x2
    bd10:	f9401017 	ldr	x23, [x0, #32]
    bd14:	b4000257 	cbz	x23, bd5c <f0+0x200c>
    bd18:	38626862 	ldrb	w2, [x3, x2]
    bd1c:	7100085f 	cmp	w2, #0x2
    bd20:	54002020 	b.eq	c124 <f0+0x23d4>  // b.none
    bd24:	7100045f 	cmp	w2, #0x1
    bd28:	540001a1 	b.ne	bd5c <f0+0x200c>  // b.any
    bd2c:	29430002 	ldp	w2, w0, [x0, #24]
    bd30:	92403c21 	and	x1, x1, #0xffff
    bd34:	9b027c21 	mul	x1, x1, x2
    bd38:	d360fc21 	lsr	x1, x1, #32
    bd3c:	eb00003f 	cmp	x1, x0
    bd40:	540000e2 	b.cs	bd5c <f0+0x200c>  // b.hs, b.nlast
    bd44:	8b0102f7 	add	x23, x23, x1
    bd48:	394002e0 	ldrb	w0, [x23]
    bd4c:	7103fc1f 	cmp	w0, #0xff
    bd50:	54003340 	b.eq	c3b8 <f0+0x2668>  // b.none
    bd54:	52800020 	mov	w0, #0x1                   	// #1
    bd58:	390002e0 	strb	w0, [x23]
    bd5c:	911fa3e1 	add	x1, sp, #0x7e8
    bd60:	d2e7fe17 	mov	x23, #0x3ff0000000000000    	// #4607182418800017408
    bd64:	52800020 	mov	w0, #0x1                   	// #1
    bd68:	f903f7f7 	str	x23, [sp, #2024]
    bd6c:	f903fbf5 	str	x21, [sp, #2032]
    bd70:	97ffe405 	bl	4d84 <fwp_data.part.0.constprop.0>
    bd74:	97ffe663 	bl	5700 <fwp_rc_fresh>
    bd78:	aa0003e2 	mov	x2, x0
    bd7c:	911fe3e1 	add	x1, sp, #0x7f8
    bd80:	b200e7f5 	mov	x21, #0x3333333333333333    	// #3689348814741910323
    bd84:	f2f7fe75 	movk	x21, #0xbff3, lsl #48
    bd88:	52800020 	mov	w0, #0x1                   	// #1
    bd8c:	f903fff5 	str	x21, [sp, #2040]
    bd90:	f90403e2 	str	x2, [sp, #2048]
    bd94:	97ffe3fc 	bl	4d84 <fwp_data.part.0.constprop.0>
    bd98:	97ffe65a 	bl	5700 <fwp_rc_fresh>
    bd9c:	aa0003e2 	mov	x2, x0
    bda0:	912023e1 	add	x1, sp, #0x808
    bda4:	52800020 	mov	w0, #0x1                   	// #1
    bda8:	f90407f7 	str	x23, [sp, #2056]
    bdac:	f9040be2 	str	x2, [sp, #2064]
    bdb0:	97ffe3f5 	bl	4d84 <fwp_data.part.0.constprop.0>
    bdb4:	97ffe653 	bl	5700 <fwp_rc_fresh>
    bdb8:	aa0003e2 	mov	x2, x0
    bdbc:	912063e1 	add	x1, sp, #0x818
    bdc0:	52800020 	mov	w0, #0x1                   	// #1
    bdc4:	f9040ff5 	str	x21, [sp, #2072]
    bdc8:	f90413e2 	str	x2, [sp, #2080]
    bdcc:	97ffe3ee 	bl	4d84 <fwp_data.part.0.constprop.0>
    bdd0:	91150283 	add	x3, x20, #0x540
    bdd4:	aa0003f5 	mov	x21, x0
    bdd8:	f949d861 	ldr	x1, [x3, #5040]
    bddc:	f949ec60 	ldr	x0, [x3, #5080]
    bde0:	cb0102a1 	sub	x1, x21, x1
    bde4:	eb00403f 	cmp	x1, x0, lsl #16
    bde8:	54000322 	b.cs	be4c <f0+0x20fc>  // b.hs, b.nlast
    bdec:	d350fc22 	lsr	x2, x1, #16
    bdf0:	f949fc63 	ldr	x3, [x3, #5112]
    bdf4:	8b020842 	add	x2, x2, x2, lsl #2
    bdf8:	d37df042 	lsl	x2, x2, #3
    bdfc:	8b020060 	add	x0, x3, x2
    be00:	f9401017 	ldr	x23, [x0, #32]
    be04:	b4000257 	cbz	x23, be4c <f0+0x20fc>
    be08:	38626862 	ldrb	w2, [x3, x2]
    be0c:	7100085f 	cmp	w2, #0x2
    be10:	54001840 	b.eq	c118 <f0+0x23c8>  // b.none
    be14:	7100045f 	cmp	w2, #0x1
    be18:	540001a1 	b.ne	be4c <f0+0x20fc>  // b.any
    be1c:	29430002 	ldp	w2, w0, [x0, #24]
    be20:	92403c21 	and	x1, x1, #0xffff
    be24:	9b027c21 	mul	x1, x1, x2
    be28:	d360fc21 	lsr	x1, x1, #32
    be2c:	eb00003f 	cmp	x1, x0
    be30:	540000e2 	b.cs	be4c <f0+0x20fc>  // b.hs, b.nlast
    be34:	8b0102f7 	add	x23, x23, x1
    be38:	394002e0 	ldrb	w0, [x23]
    be3c:	7103fc1f 	cmp	w0, #0xff
    be40:	54002c20 	b.eq	c3c4 <f0+0x2674>  // b.none
    be44:	52800020 	mov	w0, #0x1                   	// #1
    be48:	390002e0 	strb	w0, [x23]
    be4c:	9120a3e1 	add	x1, sp, #0x828
    be50:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    be54:	52800020 	mov	w0, #0x1                   	// #1
    be58:	f90417e2 	str	x2, [sp, #2088]
    be5c:	f9041bf5 	str	x21, [sp, #2096]
    be60:	97ffe3c9 	bl	4d84 <fwp_data.part.0.constprop.0>
    be64:	97ffe627 	bl	5700 <fwp_rc_fresh>
    be68:	aa0003e2 	mov	x2, x0
    be6c:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    be70:	9120e3e1 	add	x1, sp, #0x838
    be74:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    be78:	52800020 	mov	w0, #0x1                   	// #1
    be7c:	f9041fe3 	str	x3, [sp, #2104]
    be80:	f90423e2 	str	x2, [sp, #2112]
    be84:	97ffe3c0 	bl	4d84 <fwp_data.part.0.constprop.0>
    be88:	91150283 	add	x3, x20, #0x540
    be8c:	aa0003f5 	mov	x21, x0
    be90:	f949d861 	ldr	x1, [x3, #5040]
    be94:	f949ec60 	ldr	x0, [x3, #5080]
    be98:	cb0102a1 	sub	x1, x21, x1
    be9c:	eb00403f 	cmp	x1, x0, lsl #16
    bea0:	54000322 	b.cs	bf04 <f0+0x21b4>  // b.hs, b.nlast
    bea4:	d350fc22 	lsr	x2, x1, #16
    bea8:	f949fc63 	ldr	x3, [x3, #5112]
    beac:	8b020842 	add	x2, x2, x2, lsl #2
    beb0:	d37df042 	lsl	x2, x2, #3
    beb4:	8b020060 	add	x0, x3, x2
    beb8:	f9401017 	ldr	x23, [x0, #32]
    bebc:	b4000257 	cbz	x23, bf04 <f0+0x21b4>
    bec0:	38626862 	ldrb	w2, [x3, x2]
    bec4:	7100085f 	cmp	w2, #0x2
    bec8:	540013a0 	b.eq	c13c <f0+0x23ec>  // b.none
    becc:	7100045f 	cmp	w2, #0x1
    bed0:	540001a1 	b.ne	bf04 <f0+0x21b4>  // b.any
    bed4:	29430002 	ldp	w2, w0, [x0, #24]
    bed8:	92403c21 	and	x1, x1, #0xffff
    bedc:	9b027c21 	mul	x1, x1, x2
    bee0:	d360fc21 	lsr	x1, x1, #32
    bee4:	eb00003f 	cmp	x1, x0
    bee8:	540000e2 	b.cs	bf04 <f0+0x21b4>  // b.hs, b.nlast
    beec:	8b0102f7 	add	x23, x23, x1
    bef0:	394002e0 	ldrb	w0, [x23]
    bef4:	7103fc1f 	cmp	w0, #0xff
    bef8:	540026c0 	b.eq	c3d0 <f0+0x2680>  // b.none
    befc:	52800020 	mov	w0, #0x1                   	// #1
    bf00:	390002e0 	strb	w0, [x23]
    bf04:	912123e1 	add	x1, sp, #0x848
    bf08:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    bf0c:	52800020 	mov	w0, #0x1                   	// #1
    bf10:	f90427e2 	str	x2, [sp, #2120]
    bf14:	f9042bf5 	str	x21, [sp, #2128]
    bf18:	97ffe39b 	bl	4d84 <fwp_data.part.0.constprop.0>
    bf1c:	97ffe5f9 	bl	5700 <fwp_rc_fresh>
    bf20:	aa0003e2 	mov	x2, x0
    bf24:	b200e7e3 	mov	x3, #0x3333333333333333    	// #3689348814741910323
    bf28:	91150294 	add	x20, x20, #0x540
    bf2c:	f2f7fe63 	movk	x3, #0xbff3, lsl #48
    bf30:	aa1603e1 	mov	x1, x22
    bf34:	52800020 	mov	w0, #0x1                   	// #1
    bf38:	f9042fe3 	str	x3, [sp, #2136]
    bf3c:	f90433e2 	str	x2, [sp, #2144]
    bf40:	97ffe391 	bl	4d84 <fwp_data.part.0.constprop.0>
    bf44:	f949da81 	ldr	x1, [x20, #5040]
    bf48:	aa0003f5 	mov	x21, x0
    bf4c:	f949ee80 	ldr	x0, [x20, #5080]
    bf50:	cb0102a1 	sub	x1, x21, x1
    bf54:	eb00403f 	cmp	x1, x0, lsl #16
    bf58:	54000322 	b.cs	bfbc <f0+0x226c>  // b.hs, b.nlast
    bf5c:	d350fc22 	lsr	x2, x1, #16
    bf60:	f949fe83 	ldr	x3, [x20, #5112]
    bf64:	8b020842 	add	x2, x2, x2, lsl #2
    bf68:	d37df042 	lsl	x2, x2, #3
    bf6c:	8b020060 	add	x0, x3, x2
    bf70:	f9401014 	ldr	x20, [x0, #32]
    bf74:	b4000254 	cbz	x20, bfbc <f0+0x226c>
    bf78:	38626862 	ldrb	w2, [x3, x2]
    bf7c:	7100085f 	cmp	w2, #0x2
    bf80:	54000d80 	b.eq	c130 <f0+0x23e0>  // b.none
    bf84:	7100045f 	cmp	w2, #0x1
    bf88:	540001a1 	b.ne	bfbc <f0+0x226c>  // b.any
    bf8c:	29430002 	ldp	w2, w0, [x0, #24]
    bf90:	92403c21 	and	x1, x1, #0xffff
    bf94:	9b027c21 	mul	x1, x1, x2
    bf98:	d360fc21 	lsr	x1, x1, #32
    bf9c:	eb00003f 	cmp	x1, x0
    bfa0:	540000e2 	b.cs	bfbc <f0+0x226c>  // b.hs, b.nlast
    bfa4:	8b010294 	add	x20, x20, x1
    bfa8:	39400280 	ldrb	w0, [x20]
    bfac:	7103fc1f 	cmp	w0, #0xff
    bfb0:	540012c0 	b.eq	c208 <f0+0x24b8>  // b.none
    bfb4:	52800020 	mov	w0, #0x1                   	// #1
    bfb8:	39000280 	strb	w0, [x20]
    bfbc:	aa1303e1 	mov	x1, x19
    bfc0:	aa1503e0 	mov	x0, x21
    bfc4:	97fff0b3 	bl	8290 <fwp_hof0.constprop.0>
    bfc8:	aa0003f4 	mov	x20, x0
    bfcc:	aa1503e0 	mov	x0, x21
    bfd0:	97ffe6d0 	bl	5b10 <fwp_drop0>
    bfd4:	aa1303e0 	mov	x0, x19
    bfd8:	97ffe6ce 	bl	5b10 <fwp_drop0>
    bfdc:	900000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    bfe0:	f947f400 	ldr	x0, [x0, #4072]
    bfe4:	f94437e2 	ldr	x2, [sp, #2152]
    bfe8:	f9400001 	ldr	x1, [x0]
    bfec:	eb010042 	subs	x2, x2, x1
    bff0:	d2800001 	mov	x1, #0x0                   	// #0
    bff4:	54001f41 	b.ne	c3dc <f0+0x268c>  // b.any
    bff8:	9121c3ff 	add	sp, sp, #0x870
    bffc:	aa1403e0 	mov	x0, x20
    c000:	a94153f3 	ldp	x19, x20, [sp, #16]
    c004:	a9425bf5 	ldp	x21, x22, [sp, #32]
    c008:	a94363f7 	ldp	x23, x24, [sp, #48]
    c00c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    c010:	a94573fb 	ldp	x27, x28, [sp, #80]
    c014:	a8c67bfd 	ldp	x29, x30, [sp], #96
    c018:	d65f03c0 	ret
    c01c:	aa1c03e0 	mov	x0, x28
    c020:	97ffdfbc 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c024:	17fff795 	b	9e78 <f0+0x128>
    c028:	72003c5f 	tst	w2, #0xffff
    c02c:	54fef281 	b.ne	9e7c <f0+0x12c>  // b.any
    c030:	17fff78f 	b	9e6c <f0+0x11c>
    c034:	72003c3f 	tst	w1, #0xffff
    c038:	54fefe61 	b.ne	a004 <f0+0x2b4>  // b.any
    c03c:	17fff7ed 	b	9ff0 <f0+0x2a0>
    c040:	72003c3f 	tst	w1, #0xffff
    c044:	54ff1441 	b.ne	a2cc <f0+0x57c>  // b.any
    c048:	17fff89c 	b	a2b8 <f0+0x568>
    c04c:	72003c3f 	tst	w1, #0xffff
    c050:	54ff0321 	b.ne	a0b4 <f0+0x364>  // b.any
    c054:	17fff813 	b	a0a0 <f0+0x350>
    c058:	72003c3f 	tst	w1, #0xffff
    c05c:	54ff1fa1 	b.ne	a450 <f0+0x700>  // b.any
    c060:	17fff8f7 	b	a43c <f0+0x6ec>
    c064:	72003c3f 	tst	w1, #0xffff
    c068:	54ff17c1 	b.ne	a360 <f0+0x610>  // b.any
    c06c:	17fff8b8 	b	a34c <f0+0x5fc>
    c070:	72003c3f 	tst	w1, #0xffff
    c074:	54ff3941 	b.ne	a79c <f0+0xa4c>  // b.any
    c078:	17fff9c4 	b	a788 <f0+0xa38>
    c07c:	72003c3f 	tst	w1, #0xffff
    c080:	54ff2441 	b.ne	a508 <f0+0x7b8>  // b.any
    c084:	17fff91c 	b	a4f4 <f0+0x7a4>
    c088:	72003c3f 	tst	w1, #0xffff
    c08c:	54ffa2e1 	b.ne	b4e8 <f0+0x1798>  // b.any
    c090:	17fffd11 	b	b4d4 <f0+0x1784>
    c094:	72003c3f 	tst	w1, #0xffff
    c098:	54ff9cc1 	b.ne	b430 <f0+0x16e0>  // b.any
    c09c:	17fffce0 	b	b41c <f0+0x16cc>
    c0a0:	72003c3f 	tst	w1, #0xffff
    c0a4:	54ffad81 	b.ne	b654 <f0+0x1904>  // b.any
    c0a8:	17fffd66 	b	b640 <f0+0x18f0>
    c0ac:	72003c3f 	tst	w1, #0xffff
    c0b0:	54ffa861 	b.ne	b5bc <f0+0x186c>  // b.any
    c0b4:	17fffd3d 	b	b5a8 <f0+0x1858>
    c0b8:	72003c3f 	tst	w1, #0xffff
    c0bc:	54ffba01 	b.ne	b7fc <f0+0x1aac>  // b.any
    c0c0:	17fffdca 	b	b7e8 <f0+0x1a98>
    c0c4:	72003c3f 	tst	w1, #0xffff
    c0c8:	54ffb3e1 	b.ne	b744 <f0+0x19f4>  // b.any
    c0cc:	17fffd99 	b	b730 <f0+0x19e0>
    c0d0:	72003c3f 	tst	w1, #0xffff
    c0d4:	54ffc8e1 	b.ne	b9f0 <f0+0x1ca0>  // b.any
    c0d8:	17fffe41 	b	b9dc <f0+0x1c8c>
    c0dc:	72003c3f 	tst	w1, #0xffff
    c0e0:	54ffbd81 	b.ne	b890 <f0+0x1b40>  // b.any
    c0e4:	17fffde6 	b	b87c <f0+0x1b2c>
    c0e8:	72003c3f 	tst	w1, #0xffff
    c0ec:	54ffd461 	b.ne	bb78 <f0+0x1e28>  // b.any
    c0f0:	17fffe9d 	b	bb64 <f0+0x1e14>
    c0f4:	72003c3f 	tst	w1, #0xffff
    c0f8:	54ffcc81 	b.ne	ba88 <f0+0x1d38>  // b.any
    c0fc:	17fffe5e 	b	ba74 <f0+0x1d24>
    c100:	72003c3f 	tst	w1, #0xffff
    c104:	54ffde01 	b.ne	bcc4 <f0+0x1f74>  // b.any
    c108:	17fffeea 	b	bcb0 <f0+0x1f60>
    c10c:	72003c3f 	tst	w1, #0xffff
    c110:	54ffd901 	b.ne	bc30 <f0+0x1ee0>  // b.any
    c114:	17fffec2 	b	bc1c <f0+0x1ecc>
    c118:	72003c3f 	tst	w1, #0xffff
    c11c:	54ffe981 	b.ne	be4c <f0+0x20fc>  // b.any
    c120:	17ffff46 	b	be38 <f0+0x20e8>
    c124:	72003c3f 	tst	w1, #0xffff
    c128:	54ffe1a1 	b.ne	bd5c <f0+0x200c>  // b.any
    c12c:	17ffff07 	b	bd48 <f0+0x1ff8>
    c130:	72003c3f 	tst	w1, #0xffff
    c134:	54fff441 	b.ne	bfbc <f0+0x226c>  // b.any
    c138:	17ffff9c 	b	bfa8 <f0+0x2258>
    c13c:	72003c3f 	tst	w1, #0xffff
    c140:	54ffee21 	b.ne	bf04 <f0+0x21b4>  // b.any
    c144:	17ffff6b 	b	bef0 <f0+0x21a0>
    c148:	72003c3f 	tst	w1, #0xffff
    c14c:	54ff3e01 	b.ne	a90c <f0+0xbbc>  // b.any
    c150:	17fff9ea 	b	a8f8 <f0+0xba8>
    c154:	72003c3f 	tst	w1, #0xffff
    c158:	54ff37e1 	b.ne	a854 <f0+0xb04>  // b.any
    c15c:	17fff9b9 	b	a840 <f0+0xaf0>
    c160:	72003c3f 	tst	w1, #0xffff
    c164:	54ff4a81 	b.ne	aab4 <f0+0xd64>  // b.any
    c168:	17fffa4e 	b	aaa0 <f0+0xd50>
    c16c:	72003c3f 	tst	w1, #0xffff
    c170:	54ff42a1 	b.ne	a9c4 <f0+0xc74>  // b.any
    c174:	17fffa0f 	b	a9b0 <f0+0xc60>
    c178:	72003c3f 	tst	w1, #0xffff
    c17c:	54ff5321 	b.ne	abe0 <f0+0xe90>  // b.any
    c180:	17fffa93 	b	abcc <f0+0xe7c>
    c184:	72003c3f 	tst	w1, #0xffff
    c188:	54ff4e01 	b.ne	ab48 <f0+0xdf8>  // b.any
    c18c:	17fffa6a 	b	ab34 <f0+0xde4>
    c190:	72003c3f 	tst	w1, #0xffff
    c194:	54ff5de1 	b.ne	ad50 <f0+0x1000>  // b.any
    c198:	17fffae9 	b	ad3c <f0+0xfec>
    c19c:	72003c3f 	tst	w1, #0xffff
    c1a0:	54ff57c1 	b.ne	ac98 <f0+0xf48>  // b.any
    c1a4:	17fffab8 	b	ac84 <f0+0xf34>
    c1a8:	72003c3f 	tst	w1, #0xffff
    c1ac:	54ff6881 	b.ne	aebc <f0+0x116c>  // b.any
    c1b0:	17fffb3e 	b	aea8 <f0+0x1158>
    c1b4:	72003c3f 	tst	w1, #0xffff
    c1b8:	54ff6361 	b.ne	ae24 <f0+0x10d4>  // b.any
    c1bc:	17fffb15 	b	ae10 <f0+0x10c0>
    c1c0:	72003c3f 	tst	w1, #0xffff
    c1c4:	54ff7341 	b.ne	b02c <f0+0x12dc>  // b.any
    c1c8:	17fffb94 	b	b018 <f0+0x12c8>
    c1cc:	72003c3f 	tst	w1, #0xffff
    c1d0:	54ff6d21 	b.ne	af74 <f0+0x1224>  // b.any
    c1d4:	17fffb63 	b	af60 <f0+0x1210>
    c1d8:	72003c3f 	tst	w1, #0xffff
    c1dc:	54ff8181 	b.ne	b20c <f0+0x14bc>  // b.any
    c1e0:	17fffc06 	b	b1f8 <f0+0x14a8>
    c1e4:	72003c3f 	tst	w1, #0xffff
    c1e8:	54ff78c1 	b.ne	b100 <f0+0x13b0>  // b.any
    c1ec:	17fffbc0 	b	b0ec <f0+0x139c>
    c1f0:	72003c3f 	tst	w1, #0xffff
    c1f4:	54ff8c21 	b.ne	b378 <f0+0x1628>  // b.any
    c1f8:	17fffc5b 	b	b364 <f0+0x1614>
    c1fc:	72003c3f 	tst	w1, #0xffff
    c200:	54ff8701 	b.ne	b2e0 <f0+0x1590>  // b.any
    c204:	17fffc32 	b	b2cc <f0+0x157c>
    c208:	aa1403e0 	mov	x0, x20
    c20c:	97ffdf41 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c210:	17ffff69 	b	bfb4 <f0+0x2264>
    c214:	aa1703e0 	mov	x0, x23
    c218:	97ffdf3e 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c21c:	17fff778 	b	9ffc <f0+0x2ac>
    c220:	aa1503e0 	mov	x0, x21
    c224:	97ffdf3b 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c228:	17fff7a1 	b	a0ac <f0+0x35c>
    c22c:	aa1703e0 	mov	x0, x23
    c230:	97ffdf38 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c234:	17fff824 	b	a2c4 <f0+0x574>
    c238:	aa1703e0 	mov	x0, x23
    c23c:	97ffdf35 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c240:	17fff846 	b	a358 <f0+0x608>
    c244:	aa1703e0 	mov	x0, x23
    c248:	97ffdf32 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c24c:	17fff87f 	b	a448 <f0+0x6f8>
    c250:	aa1503e0 	mov	x0, x21
    c254:	97ffdf2f 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c258:	17fff8aa 	b	a500 <f0+0x7b0>
    c25c:	aa1703e0 	mov	x0, x23
    c260:	97ffdf2c 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c264:	17fff94c 	b	a794 <f0+0xa44>
    c268:	aa1703e0 	mov	x0, x23
    c26c:	97ffdf29 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c270:	17fff977 	b	a84c <f0+0xafc>
    c274:	aa1703e0 	mov	x0, x23
    c278:	97ffdf26 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c27c:	17fff9a2 	b	a904 <f0+0xbb4>
    c280:	aa1703e0 	mov	x0, x23
    c284:	97ffdf23 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c288:	17fff9cd 	b	a9bc <f0+0xc6c>
    c28c:	aa1703e0 	mov	x0, x23
    c290:	97ffdf20 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c294:	17fffa06 	b	aaac <f0+0xd5c>
    c298:	aa1703e0 	mov	x0, x23
    c29c:	97ffdf1d 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c2a0:	17fffa28 	b	ab40 <f0+0xdf0>
    c2a4:	aa1703e0 	mov	x0, x23
    c2a8:	97ffdf1a 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c2ac:	17fffa4b 	b	abd8 <f0+0xe88>
    c2b0:	aa1703e0 	mov	x0, x23
    c2b4:	97ffdf17 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c2b8:	17fffa76 	b	ac90 <f0+0xf40>
    c2bc:	aa1703e0 	mov	x0, x23
    c2c0:	97ffdf14 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c2c4:	17fffaa1 	b	ad48 <f0+0xff8>
    c2c8:	aa1703e0 	mov	x0, x23
    c2cc:	97ffdf11 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c2d0:	17fffad3 	b	ae1c <f0+0x10cc>
    c2d4:	aa1703e0 	mov	x0, x23
    c2d8:	97ffdf0e 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c2dc:	17fffaf6 	b	aeb4 <f0+0x1164>
    c2e0:	aa1703e0 	mov	x0, x23
    c2e4:	97ffdf0b 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c2e8:	17fffb21 	b	af6c <f0+0x121c>
    c2ec:	aa1703e0 	mov	x0, x23
    c2f0:	97ffdf08 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c2f4:	17fffb4c 	b	b024 <f0+0x12d4>
    c2f8:	aa1703e0 	mov	x0, x23
    c2fc:	97ffdf05 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c300:	17fffb7e 	b	b0f8 <f0+0x13a8>
    c304:	aa1703e0 	mov	x0, x23
    c308:	97ffdf02 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c30c:	17fffbbe 	b	b204 <f0+0x14b4>
    c310:	aa1703e0 	mov	x0, x23
    c314:	97ffdeff 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c318:	17fffbf0 	b	b2d8 <f0+0x1588>
    c31c:	aa1703e0 	mov	x0, x23
    c320:	97ffdefc 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c324:	17fffc13 	b	b370 <f0+0x1620>
    c328:	aa1703e0 	mov	x0, x23
    c32c:	97ffdef9 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c330:	17fffc3e 	b	b428 <f0+0x16d8>
    c334:	aa1703e0 	mov	x0, x23
    c338:	97ffdef6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c33c:	17fffc69 	b	b4e0 <f0+0x1790>
    c340:	aa1703e0 	mov	x0, x23
    c344:	97ffdef3 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c348:	17fffc9b 	b	b5b4 <f0+0x1864>
    c34c:	aa1703e0 	mov	x0, x23
    c350:	97ffdef0 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c354:	17fffcbe 	b	b64c <f0+0x18fc>
    c358:	aa1703e0 	mov	x0, x23
    c35c:	97ffdeed 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c360:	17fffcf7 	b	b73c <f0+0x19ec>
    c364:	aa1703e0 	mov	x0, x23
    c368:	97ffdeea 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c36c:	17fffd22 	b	b7f4 <f0+0x1aa4>
    c370:	aa1703e0 	mov	x0, x23
    c374:	97ffdee7 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c378:	17fffd44 	b	b888 <f0+0x1b38>
    c37c:	aa1703e0 	mov	x0, x23
    c380:	97ffdee4 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c384:	17fffd99 	b	b9e8 <f0+0x1c98>
    c388:	aa1703e0 	mov	x0, x23
    c38c:	97ffdee1 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c390:	17fffdbc 	b	ba80 <f0+0x1d30>
    c394:	aa1703e0 	mov	x0, x23
    c398:	97ffdede 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c39c:	17fffdf5 	b	bb70 <f0+0x1e20>
    c3a0:	aa1703e0 	mov	x0, x23
    c3a4:	97ffdedb 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3a8:	17fffe20 	b	bc28 <f0+0x1ed8>
    c3ac:	aa1703e0 	mov	x0, x23
    c3b0:	97ffded8 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3b4:	17fffe42 	b	bcbc <f0+0x1f6c>
    c3b8:	aa1703e0 	mov	x0, x23
    c3bc:	97ffded5 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3c0:	17fffe65 	b	bd54 <f0+0x2004>
    c3c4:	aa1703e0 	mov	x0, x23
    c3c8:	97ffded2 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3cc:	17fffe9e 	b	be44 <f0+0x20f4>
    c3d0:	aa1703e0 	mov	x0, x23
    c3d4:	97ffdecf 	bl	3f10 <fwp_rc_forget_slot.part.0>
    c3d8:	17fffec9 	b	befc <f0+0x21ac>
    c3dc:	97ffd929 	bl	2880 <__stack_chk_fail@plt>
    c3e0:	97ffd93c 	bl	28d0 <abort@plt>

000000000000c3e4 <fwp_main_thread>:
    c3e4:	d10443ff 	sub	sp, sp, #0x110
    c3e8:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c3ec:	f947f400 	ldr	x0, [x0, #4072]
    c3f0:	a90c7bfd 	stp	x29, x30, [sp, #192]
    c3f4:	910303fd 	add	x29, sp, #0xc0
    c3f8:	a90d53f3 	stp	x19, x20, [sp, #208]
    c3fc:	b0000133 	adrp	x19, 31000 <fwp_root_context+0xca0>
    c400:	91150261 	add	x1, x19, #0x540
    c404:	a90e5bf5 	stp	x21, x22, [sp, #224]
    c408:	b953a421 	ldr	w1, [x1, #5028]
    c40c:	f9400002 	ldr	x2, [x0]
    c410:	f9005fe2 	str	x2, [sp, #184]
    c414:	d2800002 	mov	x2, #0x0                   	// #0
    c418:	34000e41 	cbz	w1, c5e0 <fwp_main_thread+0x1fc>
    c41c:	91150273 	add	x19, x19, #0x540
    c420:	b953aa60 	ldr	w0, [x19, #5032]
    c424:	35000d60 	cbnz	w0, c5d0 <fwp_main_thread+0x1ec>
    c428:	91001fe2 	add	x2, sp, #0x7
    c42c:	900000b4 	adrp	x20, 20000 <__data_start>
    c430:	900000a3 	adrp	x3, 20000 <__data_start>
    c434:	9100c293 	add	x19, x20, #0x30
    c438:	910d8063 	add	x3, x3, #0x360
    c43c:	d2a80004 	mov	x4, #0x40000000            	// #1073741824
    c440:	d2a00025 	mov	x5, #0x10000               	// #65536
    c444:	910023e0 	add	x0, sp, #0x8
    c448:	d2800001 	mov	x1, #0x0                   	// #0
    c44c:	f90007e3 	str	x3, [sp, #8]
    c450:	b90013ff 	str	wzr, [sp, #16]
    c454:	a9019262 	stp	x2, x4, [x19, #24]
    c458:	f9000fe5 	str	x5, [sp, #24]
    c45c:	97ffd8a1 	bl	26e0 <sigaltstack@plt>
    c460:	35000220 	cbnz	w0, c4a4 <fwp_main_thread+0xc0>
    c464:	4f000400 	movi	v0.4s, #0x0
    c468:	9100a3e0 	add	x0, sp, #0x28
    c46c:	f0ffffa1 	adrp	x1, 3000 <fwp_flush+0x10>
    c470:	52800082 	mov	w2, #0x4                   	// #4
    c474:	9101c021 	add	x1, x1, #0x70
    c478:	72a10002 	movk	w2, #0x800, lsl #16
    c47c:	910083f5 	add	x21, sp, #0x20
    c480:	f90013e1 	str	x1, [sp, #32]
    c484:	3d802000 	str	q0, [x0, #128]
    c488:	b900abe2 	str	w2, [sp, #168]
    c48c:	ad000000 	stp	q0, q0, [x0]
    c490:	ad010000 	stp	q0, q0, [x0, #32]
    c494:	ad020000 	stp	q0, q0, [x0, #64]
    c498:	ad030000 	stp	q0, q0, [x0, #96]
    c49c:	97ffd8e9 	bl	2840 <sigemptyset@plt>
    c4a0:	340000c0 	cbz	w0, c4b8 <fwp_main_thread+0xd4>
    c4a4:	b0000000 	adrp	x0, d000 <atexit+0x10>
    c4a8:	91176000 	add	x0, x0, #0x5d8
    c4ac:	a90f63f7 	stp	x23, x24, [sp, #240]
    c4b0:	f90083f9 	str	x25, [sp, #256]
    c4b4:	97ffde77 	bl	3e90 <fwp_trap>
    c4b8:	aa1503e1 	mov	x1, x21
    c4bc:	d2800002 	mov	x2, #0x0                   	// #0
    c4c0:	52800160 	mov	w0, #0xb                   	// #11
    c4c4:	97ffd8f7 	bl	28a0 <sigaction@plt>
    c4c8:	35fffee0 	cbnz	w0, c4a4 <fwp_main_thread+0xc0>
    c4cc:	aa1503e1 	mov	x1, x21
    c4d0:	d2800002 	mov	x2, #0x0                   	// #0
    c4d4:	528000e0 	mov	w0, #0x7                   	// #7
    c4d8:	97ffd8f2 	bl	28a0 <sigaction@plt>
    c4dc:	35fffe40 	cbnz	w0, c4a4 <fwp_main_thread+0xc0>
    c4e0:	b942fa60 	ldr	w0, [x19, #760]
    c4e4:	a90f63f7 	stp	x23, x24, [sp, #240]
    c4e8:	340019c0 	cbz	w0, c820 <fwp_main_thread+0x43c>
    c4ec:	9100c296 	add	x22, x20, #0x30
    c4f0:	f9400ad5 	ldr	x21, [x22, #16]
    c4f4:	b40007f5 	cbz	x21, c5f0 <fwp_main_thread+0x20c>
    c4f8:	910102b7 	add	x23, x21, #0x40
    c4fc:	f90083f9 	str	x25, [sp, #256]
    c500:	52800038 	mov	w24, #0x1                   	// #1
    c504:	39414ab9 	ldrb	w25, [x21, #82]
    c508:	39014ab8 	strb	w24, [x21, #82]
    c50c:	d503201f 	nop
    c510:	f94016a0 	ldr	x0, [x21, #40]
    c514:	b40006a0 	cbz	x0, c5e8 <fwp_main_thread+0x204>
    c518:	f94032a1 	ldr	x1, [x21, #96]
    c51c:	394146a0 	ldrb	w0, [x21, #81]
    c520:	b40019c1 	cbz	x1, c858 <fwp_main_thread+0x474>
    c524:	36001880 	tbz	w0, #0, c834 <fwp_main_thread+0x450>
    c528:	f9400ad3 	ldr	x19, [x22, #16]
    c52c:	f94022a0 	ldr	x0, [x21, #64]
    c530:	39414a61 	ldrb	w1, [x19, #82]
    c534:	37001be1 	tbnz	w1, #0, c8b0 <fwp_main_thread+0x4cc>
    c538:	f9403261 	ldr	x1, [x19, #96]
    c53c:	a911fe77 	stp	x23, xzr, [x19, #280]
    c540:	f9009660 	str	x0, [x19, #296]
    c544:	b4000040 	cbz	x0, c54c <fwp_main_thread+0x168>
    c548:	f9009013 	str	x19, [x0, #288]
    c54c:	f90022b3 	str	x19, [x21, #64]
    c550:	b4000101 	cbz	x1, c570 <fwp_main_thread+0x18c>
    c554:	f94046c0 	ldr	x0, [x22, #136]
    c558:	39015678 	strb	w24, [x19, #85]
    c55c:	f9003661 	str	x1, [x19, #104]
    c560:	a910827f 	stp	xzr, x0, [x19, #264]
    c564:	b4000040 	cbz	x0, c56c <fwp_main_thread+0x188>
    c568:	f9008413 	str	x19, [x0, #264]
    c56c:	f90046d3 	str	x19, [x22, #136]
    c570:	39015a7f 	strb	wzr, [x19, #86]
    c574:	97ffe8bb 	bl	6860 <fwp_block>
    c578:	f9408e62 	ldr	x2, [x19, #280]
    c57c:	b4000142 	cbz	x2, c5a4 <fwp_main_thread+0x1c0>
    c580:	a9520261 	ldp	x1, x0, [x19, #288]
    c584:	b4001a21 	cbz	x1, c8c8 <fwp_main_thread+0x4e4>
    c588:	f9009420 	str	x0, [x1, #296]
    c58c:	f9409660 	ldr	x0, [x19, #296]
    c590:	b4000040 	cbz	x0, c598 <fwp_main_thread+0x1b4>
    c594:	f9009001 	str	x1, [x0, #288]
    c598:	91080260 	add	x0, x19, #0x200
    c59c:	f900967f 	str	xzr, [x19, #296]
    c5a0:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    c5a4:	39415660 	ldrb	w0, [x19, #85]
    c5a8:	3607fb40 	tbz	w0, #0, c510 <fwp_main_thread+0x12c>
    c5ac:	a9508261 	ldp	x1, x0, [x19, #264]
    c5b0:	b4001901 	cbz	x1, c8d0 <fwp_main_thread+0x4ec>
    c5b4:	f9008820 	str	x0, [x1, #272]
    c5b8:	b4000040 	cbz	x0, c5c0 <fwp_main_thread+0x1dc>
    c5bc:	f9008401 	str	x1, [x0, #264]
    c5c0:	91080260 	add	x0, x19, #0x200
    c5c4:	3901567f 	strb	wzr, [x19, #85]
    c5c8:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    c5cc:	17ffffd1 	b	c510 <fwp_main_thread+0x12c>
    c5d0:	f0ffffa0 	adrp	x0, 3000 <fwp_flush+0x10>
    c5d4:	91261000 	add	x0, x0, #0x984
    c5d8:	94000286 	bl	cff0 <atexit>
    c5dc:	17ffff93 	b	c428 <fwp_main_thread+0x44>
    c5e0:	97ffdd44 	bl	3af0 <fwp_heap_init>
    c5e4:	17ffff8e 	b	c41c <fwp_main_thread+0x38>
    c5e8:	39014ab9 	strb	w25, [x21, #82]
    c5ec:	f94083f9 	ldr	x25, [sp, #256]
    c5f0:	9100c293 	add	x19, x20, #0x30
    c5f4:	f9416e60 	ldr	x0, [x19, #728]
    c5f8:	b5000180 	cbnz	x0, c628 <fwp_main_thread+0x244>
    c5fc:	f9417660 	ldr	x0, [x19, #744]
    c600:	b5000140 	cbnz	x0, c628 <fwp_main_thread+0x244>
    c604:	f9416a60 	ldr	x0, [x19, #720]
    c608:	97ffdede 	bl	4180 <fwp_mem_free>
    c60c:	f9016a7f 	str	xzr, [x19, #720]
    c610:	f9400a60 	ldr	x0, [x19, #16]
    c614:	f901727f 	str	xzr, [x19, #736]
    c618:	b40000c0 	cbz	x0, c630 <fwp_main_thread+0x24c>
    c61c:	f900541f 	str	xzr, [x0, #168]
    c620:	f9005c1f 	str	xzr, [x0, #184]
    c624:	14000003 	b	c630 <fwp_main_thread+0x24c>
    c628:	9100c280 	add	x0, x20, #0x30
    c62c:	f9400800 	ldr	x0, [x0, #16]
    c630:	9100c281 	add	x1, x20, #0x30
    c634:	f9418826 	ldr	x6, [x1, #784]
    c638:	b903083f 	str	wzr, [x1, #776]
    c63c:	eb0000df 	cmp	x6, x0
    c640:	54001561 	b.ne	c8ec <fwp_main_thread+0x508>  // b.any
    c644:	b4000380 	cbz	x0, c6b4 <fwp_main_thread+0x2d0>
    c648:	f9415825 	ldr	x5, [x1, #688]
    c64c:	52800021 	mov	w1, #0x1                   	// #1
    c650:	39014801 	strb	w1, [x0, #82]
    c654:	b4000305 	cbz	x5, c6b4 <fwp_main_thread+0x2d0>
    c658:	394140a0 	ldrb	w0, [x5, #80]
    c65c:	37000060 	tbnz	w0, #0, c668 <fwp_main_thread+0x284>
    c660:	aa0503e0 	mov	x0, x5
    c664:	97ffdb83 	bl	3470 <fwp_cancel_tree.part.0>
    c668:	f9409ca5 	ldr	x5, [x5, #312]
    c66c:	b5ffff65 	cbnz	x5, c658 <fwp_main_thread+0x274>
    c670:	9100c293 	add	x19, x20, #0x30
    c674:	52800035 	mov	w21, #0x1                   	// #1
    c678:	f94028c0 	ldr	x0, [x6, #80]
    c67c:	f2001c1f 	tst	x0, #0xff000000ff
    c680:	540000e1 	b.ne	c69c <fwp_main_thread+0x2b8>  // b.any
    c684:	f9401660 	ldr	x0, [x19, #40]
    c688:	390150d5 	strb	w21, [x6, #84]
    c68c:	f90080df 	str	xzr, [x6, #256]
    c690:	b40010c0 	cbz	x0, c8a8 <fwp_main_thread+0x4c4>
    c694:	f9008006 	str	x6, [x0, #256]
    c698:	f9001666 	str	x6, [x19, #40]
    c69c:	97ffe871 	bl	6860 <fwp_block>
    c6a0:	97ffe7f8 	bl	6680 <fwp_free_zombie>
    c6a4:	f9415a60 	ldr	x0, [x19, #688]
    c6a8:	b4000060 	cbz	x0, c6b4 <fwp_main_thread+0x2d0>
    c6ac:	f9418a66 	ldr	x6, [x19, #784]
    c6b0:	17fffff2 	b	c678 <fwp_main_thread+0x294>
    c6b4:	9100c295 	add	x21, x20, #0x30
    c6b8:	97ffe7f2 	bl	6680 <fwp_free_zombie>
    c6bc:	f9401aa0 	ldr	x0, [x21, #48]
    c6c0:	b5001160 	cbnz	x0, c8ec <fwp_main_thread+0x508>
    c6c4:	f94046a0 	ldr	x0, [x21, #136]
    c6c8:	b5001120 	cbnz	x0, c8ec <fwp_main_thread+0x508>
    c6cc:	b940aab3 	ldr	w19, [x21, #168]
    c6d0:	340001f3 	cbz	w19, c70c <fwp_main_thread+0x328>
    c6d4:	93407e76 	sxtw	x22, w19
    c6d8:	51000673 	sub	w19, w19, #0x1
    c6dc:	d1000ad6 	sub	x22, x22, #0x2
    c6e0:	9102c2b7 	add	x23, x21, #0xb0
    c6e4:	cb3342d6 	sub	x22, x22, w19, uxtw
    c6e8:	93407e73 	sxtw	x19, w19
    c6ec:	d503201f 	nop
    c6f0:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    c6f4:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    c6f8:	b900aab3 	str	w19, [x21, #168]
    c6fc:	d1000673 	sub	x19, x19, #0x1
    c700:	97ffd8a8 	bl	29a0 <munmap@plt>
    c704:	eb1302df 	cmp	x22, x19
    c708:	54ffff41 	b.ne	c6f0 <fwp_main_thread+0x30c>  // b.any
    c70c:	900000b3 	adrp	x19, 20000 <__data_start>
    c710:	91004260 	add	x0, x19, #0x10
    c714:	b9400800 	ldr	w0, [x0, #8]
    c718:	36f80800 	tbz	w0, #31, c818 <fwp_main_thread+0x434>
    c71c:	9100c295 	add	x21, x20, #0x30
    c720:	91004273 	add	x19, x19, #0x10
    c724:	12800001 	mov	w1, #0xffffffff            	// #-1
    c728:	f94192a0 	ldr	x0, [x21, #800]
    c72c:	b9000a61 	str	w1, [x19, #8]
    c730:	f9418ea1 	ldr	x1, [x21, #792]
    c734:	b40001e0 	cbz	x0, c770 <fwp_main_thread+0x38c>
    c738:	d2800013 	mov	x19, #0x0                   	// #0
    c73c:	d503201f 	nop
    c740:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    c744:	b40000e0 	cbz	x0, c760 <fwp_main_thread+0x37c>
    c748:	f9400001 	ldr	x1, [x0]
    c74c:	b5000d01 	cbnz	x1, c8ec <fwp_main_thread+0x508>
    c750:	f9400401 	ldr	x1, [x0, #8]
    c754:	b5000cc1 	cbnz	x1, c8ec <fwp_main_thread+0x508>
    c758:	97ffde8a 	bl	4180 <fwp_mem_free>
    c75c:	f9418ea1 	ldr	x1, [x21, #792]
    c760:	91000673 	add	x19, x19, #0x1
    c764:	f94192a0 	ldr	x0, [x21, #800]
    c768:	eb00027f 	cmp	x19, x0
    c76c:	54fffea3 	b.cc	c740 <fwp_main_thread+0x35c>  // b.lo, b.ul, b.last
    c770:	aa0103e0 	mov	x0, x1
    c774:	97ffde83 	bl	4180 <fwp_mem_free>
    c778:	9100c280 	add	x0, x20, #0x30
    c77c:	f9418813 	ldr	x19, [x0, #784]
    c780:	f9018c1f 	str	xzr, [x0, #792]
    c784:	f901901f 	str	xzr, [x0, #800]
    c788:	b40001f3 	cbz	x19, c7c4 <fwp_main_thread+0x3e0>
    c78c:	f9401661 	ldr	x1, [x19, #40]
    c790:	b5000ae1 	cbnz	x1, c8ec <fwp_main_thread+0x508>
    c794:	f9405661 	ldr	x1, [x19, #168]
    c798:	b5000aa1 	cbnz	x1, c8ec <fwp_main_thread+0x508>
    c79c:	f9416c01 	ldr	x1, [x0, #728]
    c7a0:	b5000a61 	cbnz	x1, c8ec <fwp_main_thread+0x508>
    c7a4:	f9417400 	ldr	x0, [x0, #744]
    c7a8:	b5000a20 	cbnz	x0, c8ec <fwp_main_thread+0x508>
    c7ac:	d2823a02 	mov	x2, #0x11d0                	// #4560
    c7b0:	90000120 	adrp	x0, 30000 <alt.5+0xfca0>
    c7b4:	910d8000 	add	x0, x0, #0x360
    c7b8:	97ffd826 	bl	2850 <memset@plt>
    c7bc:	aa1303e0 	mov	x0, x19
    c7c0:	97ffde70 	bl	4180 <fwp_mem_free>
    c7c4:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c7c8:	f947ec00 	ldr	x0, [x0, #4056]
    c7cc:	9100c294 	add	x20, x20, #0x30
    c7d0:	f9400000 	ldr	x0, [x0]
    c7d4:	f9000a9f 	str	xzr, [x20, #16]
    c7d8:	f9018a9f 	str	xzr, [x20, #784]
    c7dc:	97ffd875 	bl	29b0 <fflush@plt>
    c7e0:	f0000080 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    c7e4:	f947f400 	ldr	x0, [x0, #4072]
    c7e8:	f9405fe2 	ldr	x2, [sp, #184]
    c7ec:	f9400001 	ldr	x1, [x0]
    c7f0:	eb010042 	subs	x2, x2, x1
    c7f4:	d2800001 	mov	x1, #0x0                   	// #0
    c7f8:	54000761 	b.ne	c8e4 <fwp_main_thread+0x500>  // b.any
    c7fc:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    c800:	d2800000 	mov	x0, #0x0                   	// #0
    c804:	a94d53f3 	ldp	x19, x20, [sp, #208]
    c808:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    c80c:	a94f63f7 	ldp	x23, x24, [sp, #240]
    c810:	910443ff 	add	sp, sp, #0x110
    c814:	d65f03c0 	ret
    c818:	97ffd81e 	bl	2890 <close@plt>
    c81c:	17ffffc0 	b	c71c <fwp_main_thread+0x338>
    c820:	97fff54c 	bl	9d50 <f0>
    c824:	f9018260 	str	x0, [x19, #768]
    c828:	52800021 	mov	w1, #0x1                   	// #1
    c82c:	b902fa61 	str	w1, [x19, #760]
    c830:	17ffff2f 	b	c4ec <fwp_main_thread+0x108>
    c834:	97ffdfb7 	bl	4710 <fwp_now_ns>
    c838:	f94032a1 	ldr	x1, [x21, #96]
    c83c:	eb01001f 	cmp	x0, x1
    c840:	540000ab 	b.lt	c854 <fwp_main_thread+0x470>  // b.tstop
    c844:	394142a0 	ldrb	w0, [x21, #80]
    c848:	37000060 	tbnz	w0, #0, c854 <fwp_main_thread+0x470>
    c84c:	aa1503e0 	mov	x0, x21
    c850:	97ffdb08 	bl	3470 <fwp_cancel_tree.part.0>
    c854:	394146a0 	ldrb	w0, [x21, #81]
    c858:	f9400ad3 	ldr	x19, [x22, #16]
    c85c:	39414a62 	ldrb	w2, [x19, #82]
    c860:	3707e640 	tbnz	w0, #0, c528 <fwp_main_thread+0x144>
    c864:	f94032a1 	ldr	x1, [x21, #96]
    c868:	370001c2 	tbnz	w2, #0, c8a0 <fwp_main_thread+0x4bc>
    c86c:	f9403260 	ldr	x0, [x19, #96]
    c870:	b4000180 	cbz	x0, c8a0 <fwp_main_thread+0x4bc>
    c874:	b4000061 	cbz	x1, c880 <fwp_main_thread+0x49c>
    c878:	eb01001f 	cmp	x0, x1
    c87c:	9a81d000 	csel	x0, x0, x1, le
    c880:	f94022a1 	ldr	x1, [x21, #64]
    c884:	a911fe77 	stp	x23, xzr, [x19, #280]
    c888:	f9009661 	str	x1, [x19, #296]
    c88c:	b4000261 	cbz	x1, c8d8 <fwp_main_thread+0x4f4>
    c890:	f9009033 	str	x19, [x1, #288]
    c894:	aa0003e1 	mov	x1, x0
    c898:	f90022b3 	str	x19, [x21, #64]
    c89c:	17ffff2e 	b	c554 <fwp_main_thread+0x170>
    c8a0:	f94022a0 	ldr	x0, [x21, #64]
    c8a4:	17ffff26 	b	c53c <fwp_main_thread+0x158>
    c8a8:	f9001a66 	str	x6, [x19, #48]
    c8ac:	17ffff7b 	b	c698 <fwp_main_thread+0x2b4>
    c8b0:	a911fe77 	stp	x23, xzr, [x19, #280]
    c8b4:	f9009660 	str	x0, [x19, #296]
    c8b8:	b4000040 	cbz	x0, c8c0 <fwp_main_thread+0x4dc>
    c8bc:	f9009013 	str	x19, [x0, #288]
    c8c0:	f90022b3 	str	x19, [x21, #64]
    c8c4:	17ffff2b 	b	c570 <fwp_main_thread+0x18c>
    c8c8:	f9000040 	str	x0, [x2]
    c8cc:	17ffff31 	b	c590 <fwp_main_thread+0x1ac>
    c8d0:	f90046c0 	str	x0, [x22, #136]
    c8d4:	17ffff39 	b	c5b8 <fwp_main_thread+0x1d4>
    c8d8:	aa0003e1 	mov	x1, x0
    c8dc:	f90022b3 	str	x19, [x21, #64]
    c8e0:	17ffff1d 	b	c554 <fwp_main_thread+0x170>
    c8e4:	f90083f9 	str	x25, [sp, #256]
    c8e8:	97ffd7e6 	bl	2880 <__stack_chk_fail@plt>
    c8ec:	f90083f9 	str	x25, [sp, #256]
    c8f0:	97ffd7f8 	bl	28d0 <abort@plt>
    c8f4:	d503201f 	nop
    c8f8:	d503201f 	nop
    c8fc:	d503201f 	nop

000000000000c900 <__divti3>:
    c900:	d503245f 	bti	c
    c904:	d2800004 	mov	x4, #0x0                   	// #0
    c908:	b7f80721 	tbnz	x1, #63, c9ec <__divti3+0xec>
    c90c:	b6f80083 	tbz	x3, #63, c91c <__divti3+0x1c>
    c910:	eb0203e2 	negs	x2, x2
    c914:	aa2403e4 	mvn	x4, x4
    c918:	da0303e3 	ngc	x3, x3
    c91c:	aa0203e6 	mov	x6, x2
    c920:	aa0003e7 	mov	x7, x0
    c924:	aa0103e5 	mov	x5, x1
    c928:	b5000583 	cbnz	x3, c9d8 <__divti3+0xd8>
    c92c:	eb01005f 	cmp	x2, x1
    c930:	54000e69 	b.ls	cafc <__divti3+0x1fc>  // b.plast
    c934:	dac01040 	clz	x0, x2
    c938:	b40000e0 	cbz	x0, c954 <__divti3+0x54>
    c93c:	4b0003e1 	neg	w1, w0
    c940:	9ac020a5 	lsl	x5, x5, x0
    c944:	9ac02046 	lsl	x6, x2, x0
    c948:	9ac124e1 	lsr	x1, x7, x1
    c94c:	aa050025 	orr	x5, x1, x5
    c950:	9ac020e7 	lsl	x7, x7, x0
    c954:	d360fcc8 	lsr	x8, x6, #32
    c958:	92407cc2 	and	x2, x6, #0xffffffff
    c95c:	9ac808a3 	udiv	x3, x5, x8
    c960:	9b089465 	msub	x5, x3, x8, x5
    c964:	aa0303e0 	mov	x0, x3
    c968:	9b037c41 	mul	x1, x2, x3
    c96c:	93c780a5 	extr	x5, x5, x7, #32
    c970:	eb05003f 	cmp	x1, x5
    c974:	540000a9 	b.ls	c988 <__divti3+0x88>  // b.plast
    c978:	ab0500c5 	adds	x5, x6, x5
    c97c:	d1000460 	sub	x0, x3, #0x1
    c980:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    c984:	540015a8 	b.hi	cc38 <__divti3+0x338>  // b.pmore
    c988:	cb0100a5 	sub	x5, x5, x1
    c98c:	9ac808a3 	udiv	x3, x5, x8
    c990:	9b089465 	msub	x5, x3, x8, x5
    c994:	aa0303e1 	mov	x1, x3
    c998:	9b037c42 	mul	x2, x2, x3
    c99c:	aa0703e3 	mov	x3, x7
    c9a0:	b3607ca3 	bfi	x3, x5, #32, #32
    c9a4:	eb03005f 	cmp	x2, x3
    c9a8:	540000c9 	b.ls	c9c0 <__divti3+0xc0>  // b.plast
    c9ac:	ab0300c3 	adds	x3, x6, x3
    c9b0:	d1000425 	sub	x5, x1, #0x1
    c9b4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    c9b8:	d1000821 	sub	x1, x1, #0x2
    c9bc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    c9c0:	aa008020 	orr	x0, x1, x0, lsl #32
    c9c4:	d2800001 	mov	x1, #0x0                   	// #0
    c9c8:	b4000064 	cbz	x4, c9d4 <__divti3+0xd4>
    c9cc:	eb0003e0 	negs	x0, x0
    c9d0:	da0103e1 	ngc	x1, x1
    c9d4:	d65f03c0 	ret
    c9d8:	eb01007f 	cmp	x3, x1
    c9dc:	54000109 	b.ls	c9fc <__divti3+0xfc>  // b.plast
    c9e0:	d2800001 	mov	x1, #0x0                   	// #0
    c9e4:	d2800000 	mov	x0, #0x0                   	// #0
    c9e8:	17fffff8 	b	c9c8 <__divti3+0xc8>
    c9ec:	eb0003e0 	negs	x0, x0
    c9f0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    c9f4:	da0103e1 	ngc	x1, x1
    c9f8:	17ffffc5 	b	c90c <__divti3+0xc>
    c9fc:	dac01067 	clz	x7, x3
    ca00:	b40010e7 	cbz	x7, cc1c <__divti3+0x31c>
    ca04:	d2800805 	mov	x5, #0x40                  	// #64
    ca08:	cb0700a5 	sub	x5, x5, x7
    ca0c:	9ac72063 	lsl	x3, x3, x7
    ca10:	9ac52448 	lsr	x8, x2, x5
    ca14:	aa030108 	orr	x8, x8, x3
    ca18:	9ac52426 	lsr	x6, x1, x5
    ca1c:	92407d0a 	and	x10, x8, #0xffffffff
    ca20:	d360fd09 	lsr	x9, x8, #32
    ca24:	9ac52403 	lsr	x3, x0, x5
    ca28:	9ac72021 	lsl	x1, x1, x7
    ca2c:	aa010063 	orr	x3, x3, x1
    ca30:	9ac72042 	lsl	x2, x2, x7
    ca34:	9ac908cb 	udiv	x11, x6, x9
    ca38:	9b099965 	msub	x5, x11, x9, x6
    ca3c:	aa0b03e1 	mov	x1, x11
    ca40:	9b0b7d46 	mul	x6, x10, x11
    ca44:	93c380a5 	extr	x5, x5, x3, #32
    ca48:	eb0500df 	cmp	x6, x5
    ca4c:	540000a9 	b.ls	ca60 <__divti3+0x160>  // b.plast
    ca50:	ab050105 	adds	x5, x8, x5
    ca54:	d1000561 	sub	x1, x11, #0x1
    ca58:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ca5c:	54000f48 	b.hi	cc44 <__divti3+0x344>  // b.pmore
    ca60:	cb0600a6 	sub	x6, x5, x6
    ca64:	9ac908cb 	udiv	x11, x6, x9
    ca68:	9b099969 	msub	x9, x11, x9, x6
    ca6c:	aa0b03e5 	mov	x5, x11
    ca70:	9b0b7d4a 	mul	x10, x10, x11
    ca74:	b3607d23 	bfi	x3, x9, #32, #32
    ca78:	eb03015f 	cmp	x10, x3
    ca7c:	540000a9 	b.ls	ca90 <__divti3+0x190>  // b.plast
    ca80:	ab030103 	adds	x3, x8, x3
    ca84:	d1000565 	sub	x5, x11, #0x1
    ca88:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    ca8c:	54000e28 	b.hi	cc50 <__divti3+0x350>  // b.pmore
    ca90:	aa0180a1 	orr	x1, x5, x1, lsl #32
    ca94:	92407c48 	and	x8, x2, #0xffffffff
    ca98:	2a0503e5 	mov	w5, w5
    ca9c:	d360fc42 	lsr	x2, x2, #32
    caa0:	d360fc26 	lsr	x6, x1, #32
    caa4:	cb0a0063 	sub	x3, x3, x10
    caa8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    caac:	9b087caa 	mul	x10, x5, x8
    cab0:	9b087cc8 	mul	x8, x6, x8
    cab4:	9b0220a5 	madd	x5, x5, x2, x8
    cab8:	9b027cc6 	mul	x6, x6, x2
    cabc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    cac0:	8b0900c5 	add	x5, x6, x9
    cac4:	eb02011f 	cmp	x8, x2
    cac8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    cacc:	8b4280c6 	add	x6, x6, x2, lsr #32
    cad0:	eb06007f 	cmp	x3, x6
    cad4:	540000e3 	b.cc	caf0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    cad8:	92407d4a 	and	x10, x10, #0xffffffff
    cadc:	9ac72000 	lsl	x0, x0, x7
    cae0:	8b028142 	add	x2, x10, x2, lsl #32
    cae4:	eb02001f 	cmp	x0, x2
    cae8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    caec:	54000a01 	b.ne	cc2c <__divti3+0x32c>  // b.any
    caf0:	d1000420 	sub	x0, x1, #0x1
    caf4:	d2800001 	mov	x1, #0x0                   	// #0
    caf8:	17ffffb4 	b	c9c8 <__divti3+0xc8>
    cafc:	b5000062 	cbnz	x2, cb08 <__divti3+0x208>
    cb00:	d2800022 	mov	x2, #0x1                   	// #1
    cb04:	9ac30846 	udiv	x6, x2, x3
    cb08:	dac010c8 	clz	x8, x6
    cb0c:	b5000408 	cbnz	x8, cb8c <__divti3+0x28c>
    cb10:	d360fcc9 	lsr	x9, x6, #32
    cb14:	92407cc5 	and	x5, x6, #0xffffffff
    cb18:	cb060023 	sub	x3, x1, x6
    cb1c:	d2800021 	mov	x1, #0x1                   	// #1
    cb20:	9ac90868 	udiv	x8, x3, x9
    cb24:	9b098d03 	msub	x3, x8, x9, x3
    cb28:	aa0803e0 	mov	x0, x8
    cb2c:	9b057d02 	mul	x2, x8, x5
    cb30:	93c78063 	extr	x3, x3, x7, #32
    cb34:	eb03005f 	cmp	x2, x3
    cb38:	540000a9 	b.ls	cb4c <__divti3+0x24c>  // b.plast
    cb3c:	ab0300c3 	adds	x3, x6, x3
    cb40:	d1000500 	sub	x0, x8, #0x1
    cb44:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    cb48:	54000968 	b.hi	cc74 <__divti3+0x374>  // b.pmore
    cb4c:	cb020063 	sub	x3, x3, x2
    cb50:	9ac90862 	udiv	x2, x3, x9
    cb54:	aa0203e8 	mov	x8, x2
    cb58:	9b098c42 	msub	x2, x2, x9, x3
    cb5c:	aa0703e3 	mov	x3, x7
    cb60:	9b057d05 	mul	x5, x8, x5
    cb64:	b3607c43 	bfi	x3, x2, #32, #32
    cb68:	eb0300bf 	cmp	x5, x3
    cb6c:	540000c9 	b.ls	cb84 <__divti3+0x284>  // b.plast
    cb70:	ab0300c2 	adds	x2, x6, x3
    cb74:	d1000503 	sub	x3, x8, #0x1
    cb78:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    cb7c:	d1000908 	sub	x8, x8, #0x2
    cb80:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    cb84:	aa008100 	orr	x0, x8, x0, lsl #32
    cb88:	17ffff90 	b	c9c8 <__divti3+0xc8>
    cb8c:	9ac820c6 	lsl	x6, x6, x8
    cb90:	d2800803 	mov	x3, #0x40                  	// #64
    cb94:	cb080063 	sub	x3, x3, x8
    cb98:	d360fcc9 	lsr	x9, x6, #32
    cb9c:	9ac82027 	lsl	x7, x1, x8
    cba0:	92407cc5 	and	x5, x6, #0xffffffff
    cba4:	9ac32422 	lsr	x2, x1, x3
    cba8:	9ac32403 	lsr	x3, x0, x3
    cbac:	aa070063 	orr	x3, x3, x7
    cbb0:	9ac9084a 	udiv	x10, x2, x9
    cbb4:	9ac82007 	lsl	x7, x0, x8
    cbb8:	9b098940 	msub	x0, x10, x9, x2
    cbbc:	aa0a03e1 	mov	x1, x10
    cbc0:	9b0a7ca2 	mul	x2, x5, x10
    cbc4:	93c38000 	extr	x0, x0, x3, #32
    cbc8:	eb00005f 	cmp	x2, x0
    cbcc:	540000a9 	b.ls	cbe0 <__divti3+0x2e0>  // b.plast
    cbd0:	ab0000c0 	adds	x0, x6, x0
    cbd4:	d1000541 	sub	x1, x10, #0x1
    cbd8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    cbdc:	54000468 	b.hi	cc68 <__divti3+0x368>  // b.pmore
    cbe0:	cb020000 	sub	x0, x0, x2
    cbe4:	9ac9080a 	udiv	x10, x0, x9
    cbe8:	9b098140 	msub	x0, x10, x9, x0
    cbec:	aa0a03e2 	mov	x2, x10
    cbf0:	9b0a7ca8 	mul	x8, x5, x10
    cbf4:	b3607c03 	bfi	x3, x0, #32, #32
    cbf8:	eb03011f 	cmp	x8, x3
    cbfc:	540000a9 	b.ls	cc10 <__divti3+0x310>  // b.plast
    cc00:	ab0300c3 	adds	x3, x6, x3
    cc04:	d1000542 	sub	x2, x10, #0x1
    cc08:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    cc0c:	54000288 	b.hi	cc5c <__divti3+0x35c>  // b.pmore
    cc10:	cb080063 	sub	x3, x3, x8
    cc14:	aa018041 	orr	x1, x2, x1, lsl #32
    cc18:	17ffffc2 	b	cb20 <__divti3+0x220>
    cc1c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    cc20:	d2800001 	mov	x1, #0x0                   	// #0
    cc24:	9a9f87e0 	cset	x0, ls	// ls = plast
    cc28:	17ffff68 	b	c9c8 <__divti3+0xc8>
    cc2c:	aa0103e0 	mov	x0, x1
    cc30:	d2800001 	mov	x1, #0x0                   	// #0
    cc34:	17ffff65 	b	c9c8 <__divti3+0xc8>
    cc38:	d1000860 	sub	x0, x3, #0x2
    cc3c:	8b0600a5 	add	x5, x5, x6
    cc40:	17ffff52 	b	c988 <__divti3+0x88>
    cc44:	d1000961 	sub	x1, x11, #0x2
    cc48:	8b0800a5 	add	x5, x5, x8
    cc4c:	17ffff85 	b	ca60 <__divti3+0x160>
    cc50:	d1000965 	sub	x5, x11, #0x2
    cc54:	8b080063 	add	x3, x3, x8
    cc58:	17ffff8e 	b	ca90 <__divti3+0x190>
    cc5c:	d1000942 	sub	x2, x10, #0x2
    cc60:	8b060063 	add	x3, x3, x6
    cc64:	17ffffeb 	b	cc10 <__divti3+0x310>
    cc68:	d1000941 	sub	x1, x10, #0x2
    cc6c:	8b060000 	add	x0, x0, x6
    cc70:	17ffffdc 	b	cbe0 <__divti3+0x2e0>
    cc74:	d1000900 	sub	x0, x8, #0x2
    cc78:	8b060063 	add	x3, x3, x6
    cc7c:	17ffffb4 	b	cb4c <__divti3+0x24c>

000000000000cc80 <__modti3>:
    cc80:	d503245f 	bti	c
    cc84:	d2800004 	mov	x4, #0x0                   	// #0
    cc88:	b6f80081 	tbz	x1, #63, cc98 <__modti3+0x18>
    cc8c:	eb0003e0 	negs	x0, x0
    cc90:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    cc94:	da0103e1 	ngc	x1, x1
    cc98:	f100007f 	cmp	x3, #0x0
    cc9c:	5400128b 	b.lt	ceec <__modti3+0x26c>  // b.tstop
    cca0:	aa0003e7 	mov	x7, x0
    cca4:	aa0103e6 	mov	x6, x1
    cca8:	540004e1 	b.ne	cd44 <__modti3+0xc4>  // b.any
    ccac:	eb02003f 	cmp	x1, x2
    ccb0:	54000dc2 	b.cs	ce68 <__modti3+0x1e8>  // b.hs, b.nlast
    ccb4:	dac01043 	clz	x3, x2
    ccb8:	aa0303e5 	mov	x5, x3
    ccbc:	b40000e3 	cbz	x3, ccd8 <__modti3+0x58>
    ccc0:	4b0303e6 	neg	w6, w3
    ccc4:	9ac32021 	lsl	x1, x1, x3
    ccc8:	9ac32042 	lsl	x2, x2, x3
    cccc:	9ac62406 	lsr	x6, x0, x6
    ccd0:	aa0100c6 	orr	x6, x6, x1
    ccd4:	9ac32007 	lsl	x7, x0, x3
    ccd8:	d360fc40 	lsr	x0, x2, #32
    ccdc:	92407c43 	and	x3, x2, #0xffffffff
    cce0:	9ac008c1 	udiv	x1, x6, x0
    cce4:	9b009826 	msub	x6, x1, x0, x6
    cce8:	9b017c61 	mul	x1, x3, x1
    ccec:	93c780c6 	extr	x6, x6, x7, #32
    ccf0:	eb06003f 	cmp	x1, x6
    ccf4:	540000a9 	b.ls	cd08 <__modti3+0x88>  // b.plast
    ccf8:	ab060046 	adds	x6, x2, x6
    ccfc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    cd00:	8b0200c8 	add	x8, x6, x2
    cd04:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    cd08:	cb0100c6 	sub	x6, x6, x1
    cd0c:	9ac008c8 	udiv	x8, x6, x0
    cd10:	9b009901 	msub	x1, x8, x0, x6
    cd14:	aa0703e0 	mov	x0, x7
    cd18:	9b087c63 	mul	x3, x3, x8
    cd1c:	b3607c20 	bfi	x0, x1, #32, #32
    cd20:	eb00007f 	cmp	x3, x0
    cd24:	54001088 	b.hi	cf34 <__modti3+0x2b4>  // b.pmore
    cd28:	cb030000 	sub	x0, x0, x3
    cd2c:	9ac52400 	lsr	x0, x0, x5
    cd30:	d2800001 	mov	x1, #0x0                   	// #0
    cd34:	b4000064 	cbz	x4, cd40 <__modti3+0xc0>
    cd38:	eb0003e0 	negs	x0, x0
    cd3c:	da0103e1 	ngc	x1, x1
    cd40:	d65f03c0 	ret
    cd44:	dac01066 	clz	x6, x3
    cd48:	eb03003f 	cmp	x1, x3
    cd4c:	54ffff43 	b.cc	cd34 <__modti3+0xb4>  // b.lo, b.ul, b.last
    cd50:	93407cc5 	sxtw	x5, w6
    cd54:	d2800808 	mov	x8, #0x40                  	// #64
    cd58:	cb050108 	sub	x8, x8, x5
    cd5c:	9ac62063 	lsl	x3, x3, x6
    cd60:	9ac62025 	lsl	x5, x1, x6
    cd64:	9ac82447 	lsr	x7, x2, x8
    cd68:	aa0300e7 	orr	x7, x7, x3
    cd6c:	9ac82423 	lsr	x3, x1, x8
    cd70:	92407cec 	and	x12, x7, #0xffffffff
    cd74:	d360fcea 	lsr	x10, x7, #32
    cd78:	9ac82401 	lsr	x1, x0, x8
    cd7c:	aa050021 	orr	x1, x1, x5
    cd80:	9ac62042 	lsl	x2, x2, x6
    cd84:	9ac62000 	lsl	x0, x0, x6
    cd88:	9aca086b 	udiv	x11, x3, x10
    cd8c:	9b0a8d63 	msub	x3, x11, x10, x3
    cd90:	aa0b03e5 	mov	x5, x11
    cd94:	9b0b7d89 	mul	x9, x12, x11
    cd98:	93c18063 	extr	x3, x3, x1, #32
    cd9c:	eb03013f 	cmp	x9, x3
    cda0:	540000a9 	b.ls	cdb4 <__modti3+0x134>  // b.plast
    cda4:	ab0300e3 	adds	x3, x7, x3
    cda8:	d1000565 	sub	x5, x11, #0x1
    cdac:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    cdb0:	54001168 	b.hi	cfdc <__modti3+0x35c>  // b.pmore
    cdb4:	cb090063 	sub	x3, x3, x9
    cdb8:	9aca086b 	udiv	x11, x3, x10
    cdbc:	9b0a8d6a 	msub	x10, x11, x10, x3
    cdc0:	aa0b03e9 	mov	x9, x11
    cdc4:	9b0b7d8c 	mul	x12, x12, x11
    cdc8:	b3607d41 	bfi	x1, x10, #32, #32
    cdcc:	eb01019f 	cmp	x12, x1
    cdd0:	540000a9 	b.ls	cde4 <__modti3+0x164>  // b.plast
    cdd4:	ab0100e1 	adds	x1, x7, x1
    cdd8:	d1000569 	sub	x9, x11, #0x1
    cddc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    cde0:	54000f88 	b.hi	cfd0 <__modti3+0x350>  // b.pmore
    cde4:	aa058123 	orr	x3, x9, x5, lsl #32
    cde8:	92407c4b 	and	x11, x2, #0xffffffff
    cdec:	2a0903e9 	mov	w9, w9
    cdf0:	d360fc4a 	lsr	x10, x2, #32
    cdf4:	d360fc63 	lsr	x3, x3, #32
    cdf8:	cb0c0021 	sub	x1, x1, x12
    cdfc:	aa0a03ec 	mov	x12, x10
    ce00:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    ce04:	9b0b7d25 	mul	x5, x9, x11
    ce08:	9b0b7c6b 	mul	x11, x3, x11
    ce0c:	9b0a2d29 	madd	x9, x9, x10, x11
    ce10:	92407caa 	and	x10, x5, #0xffffffff
    ce14:	9b0c7c63 	mul	x3, x3, x12
    ce18:	8b458125 	add	x5, x9, x5, lsr #32
    ce1c:	8b0d0069 	add	x9, x3, x13
    ce20:	eb05017f 	cmp	x11, x5
    ce24:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    ce28:	8b058149 	add	x9, x10, x5, lsl #32
    ce2c:	8b458063 	add	x3, x3, x5, lsr #32
    ce30:	eb03003f 	cmp	x1, x3
    ce34:	54000063 	b.cc	ce40 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    ce38:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    ce3c:	54000082 	b.cs	ce4c <__modti3+0x1cc>  // b.hs, b.nlast
    ce40:	eb020129 	subs	x9, x9, x2
    ce44:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    ce48:	cb070063 	sub	x3, x3, x7
    ce4c:	eb090000 	subs	x0, x0, x9
    ce50:	da030021 	sbc	x1, x1, x3
    ce54:	9ac62400 	lsr	x0, x0, x6
    ce58:	9ac82028 	lsl	x8, x1, x8
    ce5c:	aa000100 	orr	x0, x8, x0
    ce60:	9ac62421 	lsr	x1, x1, x6
    ce64:	17ffffb4 	b	cd34 <__modti3+0xb4>
    ce68:	b5000062 	cbnz	x2, ce74 <__modti3+0x1f4>
    ce6c:	d2800023 	mov	x3, #0x1                   	// #1
    ce70:	9ac20862 	udiv	x2, x3, x2
    ce74:	dac01048 	clz	x8, x2
    ce78:	aa0803e5 	mov	x5, x8
    ce7c:	b5000668 	cbnz	x8, cf48 <__modti3+0x2c8>
    ce80:	cb020020 	sub	x0, x1, x2
    ce84:	d360fc49 	lsr	x9, x2, #32
    ce88:	92407c4a 	and	x10, x2, #0xffffffff
    ce8c:	9ac90801 	udiv	x1, x0, x9
    ce90:	9b098020 	msub	x0, x1, x9, x0
    ce94:	9b0a7c21 	mul	x1, x1, x10
    ce98:	93c78000 	extr	x0, x0, x7, #32
    ce9c:	eb00003f 	cmp	x1, x0
    cea0:	540000a9 	b.ls	ceb4 <__modti3+0x234>  // b.plast
    cea4:	ab000040 	adds	x0, x2, x0
    cea8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ceac:	8b020003 	add	x3, x0, x2
    ceb0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ceb4:	cb010001 	sub	x1, x0, x1
    ceb8:	9ac90820 	udiv	x0, x1, x9
    cebc:	9b098403 	msub	x3, x0, x9, x1
    cec0:	aa0703e1 	mov	x1, x7
    cec4:	9b0a7c00 	mul	x0, x0, x10
    cec8:	b3607c61 	bfi	x1, x3, #32, #32
    cecc:	eb01001f 	cmp	x0, x1
    ced0:	540000a9 	b.ls	cee4 <__modti3+0x264>  // b.plast
    ced4:	ab010041 	adds	x1, x2, x1
    ced8:	8b020022 	add	x2, x1, x2
    cedc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    cee0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    cee4:	cb000020 	sub	x0, x1, x0
    cee8:	17ffff91 	b	cd2c <__modti3+0xac>
    ceec:	eb0203e5 	negs	x5, x2
    cef0:	aa0003e7 	mov	x7, x0
    cef4:	da0303e8 	ngc	x8, x3
    cef8:	aa0503e2 	mov	x2, x5
    cefc:	aa0803e3 	mov	x3, x8
    cf00:	aa0103e6 	mov	x6, x1
    cf04:	b4ffed48 	cbz	x8, ccac <__modti3+0x2c>
    cf08:	eb01011f 	cmp	x8, x1
    cf0c:	54fff148 	b.hi	cd34 <__modti3+0xb4>  // b.pmore
    cf10:	dac01109 	clz	x9, x8
    cf14:	2a0903e6 	mov	w6, w9
    cf18:	b5fff1c9 	cbnz	x9, cd50 <__modti3+0xd0>
    cf1c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    cf20:	54000068 	b.hi	cf2c <__modti3+0x2ac>  // b.pmore
    cf24:	eb050007 	subs	x7, x0, x5
    cf28:	da080021 	sbc	x1, x1, x8
    cf2c:	aa0703e0 	mov	x0, x7
    cf30:	17ffff81 	b	cd34 <__modti3+0xb4>
    cf34:	ab000040 	adds	x0, x2, x0
    cf38:	8b020002 	add	x2, x0, x2
    cf3c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    cf40:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    cf44:	17ffff79 	b	cd28 <__modti3+0xa8>
    cf48:	9ac82042 	lsl	x2, x2, x8
    cf4c:	d2800803 	mov	x3, #0x40                  	// #64
    cf50:	cb080063 	sub	x3, x3, x8
    cf54:	d360fc49 	lsr	x9, x2, #32
    cf58:	9ac82027 	lsl	x7, x1, x8
    cf5c:	92407c4a 	and	x10, x2, #0xffffffff
    cf60:	9ac32426 	lsr	x6, x1, x3
    cf64:	9ac32403 	lsr	x3, x0, x3
    cf68:	aa070063 	orr	x3, x3, x7
    cf6c:	9ac908c1 	udiv	x1, x6, x9
    cf70:	9ac82007 	lsl	x7, x0, x8
    cf74:	9b099820 	msub	x0, x1, x9, x6
    cf78:	9b017d41 	mul	x1, x10, x1
    cf7c:	93c38000 	extr	x0, x0, x3, #32
    cf80:	eb00003f 	cmp	x1, x0
    cf84:	540000a9 	b.ls	cf98 <__modti3+0x318>  // b.plast
    cf88:	ab000040 	adds	x0, x2, x0
    cf8c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cf90:	8b020006 	add	x6, x0, x2
    cf94:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    cf98:	cb010000 	sub	x0, x0, x1
    cf9c:	9ac90801 	udiv	x1, x0, x9
    cfa0:	9b098026 	msub	x6, x1, x9, x0
    cfa4:	aa0303e0 	mov	x0, x3
    cfa8:	9b017d41 	mul	x1, x10, x1
    cfac:	b3607cc0 	bfi	x0, x6, #32, #32
    cfb0:	eb00003f 	cmp	x1, x0
    cfb4:	540000a9 	b.ls	cfc8 <__modti3+0x348>  // b.plast
    cfb8:	ab000040 	adds	x0, x2, x0
    cfbc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    cfc0:	8b020003 	add	x3, x0, x2
    cfc4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    cfc8:	cb010000 	sub	x0, x0, x1
    cfcc:	17ffffb0 	b	ce8c <__modti3+0x20c>
    cfd0:	d1000969 	sub	x9, x11, #0x2
    cfd4:	8b070021 	add	x1, x1, x7
    cfd8:	17ffff83 	b	cde4 <__modti3+0x164>
    cfdc:	d1000965 	sub	x5, x11, #0x2
    cfe0:	8b070063 	add	x3, x3, x7
    cfe4:	17ffff74 	b	cdb4 <__modti3+0x134>
    cfe8:	d503201f 	nop
    cfec:	d503201f 	nop

000000000000cff0 <atexit>:
    cff0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    cff4:	900000a2 	adrp	x2, 20000 <__data_start>
    cff8:	d2800001 	mov	x1, #0x0                   	// #0
    cffc:	910003fd 	mov	x29, sp
    d000:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d004:	f9400442 	ldr	x2, [x2, #8]
    d008:	17ffd5de 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000d00c <_fini>:
    d00c:	d503201f 	nop
    d010:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    d014:	910003fd 	mov	x29, sp
    d018:	a8c17bfd 	ldp	x29, x30, [sp], #16
    d01c:	d65f03c0 	ret
